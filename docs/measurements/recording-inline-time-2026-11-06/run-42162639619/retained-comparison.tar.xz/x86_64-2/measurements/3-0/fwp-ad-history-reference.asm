
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 cf 00 00 	mov    0xcfc9(%rip),%rax        # ffd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 cd 00 00    	push   0xcde2(%rip)        # fe08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 cd 00 00    	jmp    *0xcde4(%rip)        # fe10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e cc 00 00    	jmp    *0xcc4e(%rip)        # ffe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fe70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fe78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fe80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fe88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fe90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fe98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # feb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # feb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # fed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # fed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # fee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # fee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # fef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # fef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ff70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ff78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ff80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ff88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ff90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ff98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 c8 00 00    	jmp    *0xc8e6(%rip)        # ffa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de c8 00 00    	jmp    *0xc8de(%rip)        # ffa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 c8 00 00    	jmp    *0xc8d6(%rip)        # ffb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce c8 00 00    	jmp    *0xc8ce(%rip)        # ffb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 c8 00 00    	jmp    *0xc8c6(%rip)        # ffc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 89 00 00 	lea    0x897a(%rip),%r9        # c091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 89 00 00 	lea    0x8977(%rip),%r8        # c095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ad 00 00 	lea    0xad01(%rip),%rax        # e480 <fwp_fn_table>
    377f:	48 89 05 32 ec 01 00 	mov    %rax,0x1ec32(%rip)        # 223b8 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c ec 01 00 	mov    %rax,0x1ec2c(%rip)        # 223c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 8a 00 00 	lea    0x8a59(%rip),%rdi        # c1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 af 73 00 00 	lea    0x73af(%rip),%rdx        # ac10 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 89 00 00 	lea    0x8909(%rip),%rdi        # c202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e 90 00 00 	lea    0x908e(%rip),%rdi        # c998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 90 00 00 	lea    0x9048(%rip),%rdi        # c970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c 90 00 00 	lea    0x900c(%rip),%rdi        # c940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 8f 00 00 	lea    0x8fd8(%rip),%rdi        # c918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 c6 00 00    	call   *0xc653(%rip)        # ffc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 c6 00 00 	mov    0xc636(%rip),%rax        # ffd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 c6 00 00 	mov    0xc605(%rip),%rax        # ffe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 c5 00 00 	cmpq   $0x0,0xc5e2(%rip)        # ffe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce c4 01 00 	add    0x1c4ce(%rip),%rdx        # 200f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc c4 01 00 	add    0x1c4bc(%rip),%rax        # 200f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 e7 01 00 	mov    0x1e749(%rip),%rdi        # 223c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 c3 00 00 	mov    0xc394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 c3 00 00 	mov    0xc381(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 c3 00 00 	mov    0xc372(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 ca 01 00 	mov    0x1ca41(%rip),%rax        # 20740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 c3 01 00 	mov    0x1c381(%rip),%rax        # 20100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d c3 01 00 	sub    0x1c36d(%rip),%rax        # 200f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd 8c 00 00 	lea    0x8cbd(%rip),%rsi        # ca80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b dd 01 00 	mov    0x1dd5b(%rip),%rax        # 21b50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 dd 01 00 	lea    0x1dd54(%rip),%r8        # 21b50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 dd 01 00 	mov    0x1dd35(%rip),%rbx        # 21b38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 dd 01 00 	mov    0x1dd45(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 dc 01 00 	mov    0x1dce1(%rip),%rdi        # 21b40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a dd 01 00 	sub    %rsi,0x1dd2a(%rip)        # 21b90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba dc 01 00 	mov    0x1dcba(%rip),%rax        # 21b30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 dc 01 00 	add    0x1dc70(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e dc 01 00 	mov    0x1dc7e(%rip),%rsi        # 21b40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c dc 01 00 	mov    0x1dc8c(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b dc 01 00 	mov    %r12,0x1dc3b(%rip)        # 21b40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 dc 01 00 	mov    %rbp,0x1dc29(%rip)        # 21b38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e dc 01 00 	cmp    %rdi,0x1dc0e(%rip)        # 21b28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 dc 01 00 	mov    %rdi,0x1dc05(%rip)        # 21b28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 dc 01 00 	sub    %rdi,0x1dc49(%rip)        # 21b90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 db 01 00 	mov    0x1dbf1(%rip),%rax        # 21b48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea db 01 00 	lea    0x1dbea(%rip),%r8        # 21b48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd bf 00 00 	mov    0xbffd(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 7f 00 00 	lea    0x7fb4(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 c6 01 00 	cmp    0x1c689(%rip),%rdi        # 20740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f c6 01 00 	mov    0x1c64f(%rip),%rax        # 20720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d c6 01 00 	mov    %rdi,0x1c62d(%rip)        # 20720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 c6 01 00 	mov    %rdi,0x1c609(%rip)        # 20728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 80 00 00 	lea    0x8005(%rip),%rsi        # c166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 7e 00 00 	lea    0x7ea7(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 be 00 00 	mov    0xbe78(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 7e 00 00 	lea    0x7e51(%rip),%rdx        # c020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 be 00 00 	mov    0xbe60(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 bd 00 00 	mov    0xbd71(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 7d 00 00 	lea    0x7d28(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 7d 00 00 	lea    0x7d32(%rip),%rdi        # c02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 7c 00 00 	lea    0x7cba(%rip),%rdi        # c049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 82 00 00 	lea    0x8268(%rip),%rdi        # c608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 86 00 	movdqa 0x86e0(%rip),%xmm0        # caa0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a df 01 00 	add    0x1df9a(%rip),%rax        # 223b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 81 00 00 	lea    0x81c4(%rip),%rdi        # c638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 bc 01 00 	cmp    %rax,0x1bc55(%rip)        # 200e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 bc 01 00 	add    0x1bc50(%rip),%rax        # 200f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad 81 00 00 	lea    0x81ad(%rip),%rdi        # c668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 7b 00 00 	lea    0x7b92(%rip),%r8        # c065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 79 00 00 	lea    0x79e7(%rip),%r8        # c074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 78 00 00 	lea    0x7874(%rip),%r8        # c06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 76 00 00 	lea    0x764c(%rip),%rdi        # c079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 77 00 00 	lea    0x7760(%rip),%rsi        # c1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 d0 01 00 	mov    0x1d065(%rip),%r9        # 21b28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be d0 01 00 	mov    0x1d0be(%rip),%r8        # 21b88 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 7b 00 00 	lea    0x7be7(%rip),%rdx        # c6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 d0 01 00 	mov    0x1d0a6(%rip),%rcx        # 21b80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 d0 01 	movsd  0x1d0b4(%rip),%xmm1        # 21ba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 d0 01 	movsd  0x1d0a4(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 b5 00 00 	mov    0xb545(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 7f 00 	movdqa 0x7f78(%rip),%xmm0        # cab0 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f cb 01 00 	lea    0x1cb5f(%rip),%rax        # 216a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 7f 00 	movdqa 0x7fa1(%rip),%xmm2        # caf0 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 cb 01 00 	movaps %xmm0,0x1cb05(%rip)        # 21660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d 7f 00 	movdqa 0x7f5d(%rip),%xmm0        # cac0 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 cf 01 00 01 	movl   $0x1,0x1cf93(%rip)        # 21b04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 ca 01 00 	movaps %xmm0,0x1caf3(%rip)        # 21670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b 7f 00 	movdqa 0x7f4b(%rip),%xmm0        # cad0 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 f4 ca 01 00 	movaps %xmm0,0x1caf4(%rip)        # 21680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c 7f 00 	movdqa 0x7f4c(%rip),%xmm0        # cae0 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 f5 ca 01 00 	movaps %xmm0,0x1caf5(%rip)        # 21690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 bb 01 00 	lea    0x1bb75(%rip),%r8        # 20760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 ce 01 00 	mov    %rax,0x1ce90(%rip)        # 21b18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e ce 01 00 	mov    %r12,0x1ce6e(%rip)        # 21b20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 ce 01 00 	mov    %rax,0x1ce57(%rip)        # 21b10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 ce 01 00 	mov    %rbx,0x1ce70(%rip)        # 21b30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 ce 01 00 	mov    %rsi,0x1ce99(%rip)        # 21b60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 73 00 00 	lea    0x73d6(%rip),%rdi        # c0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 ce 01 00 	mov    %rax,0x1ce78(%rip)        # 21b58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc cd 01 00    	mov    %eax,0x1cdfc(%rip)        # 21b08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec b9 01 00 	mov    0x1b9ec(%rip),%r8        # 20720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c b9 01 00 	mov    %rbx,0x1b91c(%rip)        # 20728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 b9 01 00 	mov    %r8,0x1b908(%rip)        # 20720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 72 00 00 	lea    0x7239(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd b1 01 00 	lea    0x1b1dd(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 b1 01 00 	movaps %xmm0,0x1b1c5(%rip)        # 200a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 b1 01 00 	mov    %rax,0x1b1a1(%rip)        # 20088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 b1 01 00 	movaps %xmm0,0x1b1c2(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 b1 01 00 	movaps %xmm0,0x1b1c6(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 b1 01 00 	mov    %rdx,0x1b1c7(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 71 00 00 	lea    0x7190(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 b7 01 00 	mov    0x1b797(%rip),%rbx        # 20718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca af 00 00 	mov    0xafca(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d c3 76 00 00 	lea    0x76c3(%rip),%rdi        # c740 <_IO_stdin_used+0x740>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d b6 01 00 	mov    0x1b66d(%rip),%rax        # 20720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 b6 01 00 	mov    %rdx,0x1b647(%rip)        # 20720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 b5 01 00 	mov    0x1b594(%rip),%rbx        # 20718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 b5 01 00 	mov    %rbx,0x1b551(%rip)        # 20718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 b5 01 00 	mov    %rdx,0x1b551(%rip)        # 20728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 b5 01 00 	lea    0x1b566(%rip),%rsi        # 20760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 d0 01 00 	addq   $0x1,0x1d0e5(%rip)        # 223a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 97 74 00 00 	lea    0x7497(%rip),%rdi        # c770 <_IO_stdin_used+0x770>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d a8 74 00 00 	lea    0x74a8(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 6d 00 00 	lea    0x6dd4(%rip),%rdi        # c0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e b4 01 00 	lea    0x1b41e(%rip),%rcx        # 20760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f d0 01 00 	subq   $0x1,0x1d01f(%rip)        # 223a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 03 74 00 00 	lea    0x7403(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 d0 01 00 	cmpq   $0x0,0x1d000(%rip)        # 223a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 cf 01 00 	sub    %rax,0x1cf55(%rip)        # 223b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 cf 01 00 	add    %r12,0x1cf33(%rip)        # 223b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f c6 01 00 	mov    0x1c68f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c b2 01 00 	lea    0x1b28c(%rip),%rax        # 20760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 c5 01 00 	add    0x1c5e3(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 c5 01 00 	mov    0x1c5b0(%rip),%rsi        # 21b10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 c5 01 00 	mov    0x1c5d1(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 c5 01 00 	add    0x1c5c5(%rip),%r8        # 21b58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d c5 01 	addsd  0x1c58d(%rip),%xmm0        # 21ba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 b1 01 00 	lea    0x1b142(%rip),%rax        # 20760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c c5 01 00 	sub    %rdi,0x1c54c(%rip)        # 21b80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 c5 01 	movsd  %xmm0,0x1c564(%rip)        # 21ba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e c5 01 00 	sub    %rdx,0x1c51e(%rip)        # 21b80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 c5 01 	addsd  0x1c524(%rip),%xmm0        # 21ba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 c5 01 	movsd  %xmm0,0x1c518(%rip)        # 21ba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af c4 01 00 	mov    0x1c4af(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 c4 01 00 	add    %rcx,0x1c4a9(%rip)        # 21b90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 c4 01 00 	cmp    0x1c462(%rip),%r9        # 21b50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 c4 01 00 	mov    %r9,0x1c459(%rip)        # 21b50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a c4 01 00 	cmp    0x1c44a(%rip),%r9        # 21b48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d c4 01 00 	mov    %r9,0x1c43d(%rip)        # 21b48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 c3 01 00 	add    0x1c353(%rip),%rdi        # 21b58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 af 01 00 	lea    0x1af30(%rip),%r15        # 20760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 c2 01 00 	add    0x1c2a0(%rip),%r12        # 21b10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 c2 01 00 	add    0x1c2f9(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 c2 01 00 	cmp    %rax,0x1c2f8(%rip)        # 21b88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 c2 01 00 	mov    %rax,0x1c2e9(%rip)        # 21b80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 c2 01 00 	mov    %rax,0x1c2e8(%rip)        # 21b88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 c2 01 	addsd  0x1c2e4(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc c2 01 	movsd  %xmm0,0x1c2dc(%rip)        # 21b98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 c2 01 00    	mov    0x1c223(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f ae 01 00 	lea    0x1ae5f(%rip),%rdi        # 20760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 c2 01 00 	add    0x1c218(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 c2 01 00 	cmp    %rax,0x1c213(%rip)        # 21b88 <fwp_heap+0x1428>
    5975:	48 89 05 04 c2 01 00 	mov    %rax,0x1c204(%rip)        # 21b80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 c2 01 00 	mov    %rax,0x1c203(%rip)        # 21b88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff c1 01 	addsd  0x1c1ff(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 c1 01 	movsd  %xmm0,0x1c1f7(%rip)        # 21b98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae c0 01 00    	mov    0x1c0ae(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 ac 01 00 	lea    0x1ace5(%rip),%rax        # 20760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b c0 01 00 	add    0x1c09b(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a c0 01 00 	cmp    %rax,0x1c09a(%rip)        # 21b88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b c0 01 00 	mov    %rax,0x1c08b(%rip)        # 21b80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a c0 01 00 	mov    %rax,0x1c08a(%rip)        # 21b88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 c0 01 	addsd  0x1c086(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e c0 01 	movsd  %xmm0,0x1c07e(%rip)        # 21b98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_apply>:
    5b70:	55                   	push   %rbp
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	48 89 e5             	mov    %rsp,%rbp
    5b77:	41 57                	push   %r15
    5b79:	41 56                	push   %r14
    5b7b:	41 55                	push   %r13
    5b7d:	41 89 f5             	mov    %esi,%r13d
    5b80:	41 54                	push   %r12
    5b82:	53                   	push   %rbx
    5b83:	48 83 ec 28          	sub    $0x28,%rsp
    5b87:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5b8e:	00 00 
    5b90:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5b94:	49 89 d6             	mov    %rdx,%r14
    5b97:	44 8b 09             	mov    (%rcx),%r9d
    5b9a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5b9e:	49 89 e0             	mov    %rsp,%r8
    5ba1:	49 c1 e1 05          	shl    $0x5,%r9
    5ba5:	4c 03 0d 0c c8 01 00 	add    0x1c80c(%rip),%r9        # 223b8 <fwp_fns>
    5bac:	41 8b 19             	mov    (%r9),%ebx
    5baf:	45 85 e4             	test   %r12d,%r12d
    5bb2:	75 2c                	jne    5be0 <fwp_apply+0x70>
    5bb4:	41 39 dd             	cmp    %ebx,%r13d
    5bb7:	72 27                	jb     5be0 <fwp_apply+0x70>
    5bb9:	85 db                	test   %ebx,%ebx
    5bbb:	0f 84 a7 01 00 00    	je     5d68 <fwp_apply+0x1f8>
    5bc1:	4c 89 f7             	mov    %r14,%rdi
    5bc4:	41 ff 51 08          	call   *0x8(%r9)
    5bc8:	48 89 c1             	mov    %rax,%rcx
    5bcb:	41 39 dd             	cmp    %ebx,%r13d
    5bce:	0f 84 6c 01 00 00    	je     5d40 <fwp_apply+0x1d0>
    5bd4:	89 d8                	mov    %ebx,%eax
    5bd6:	41 29 dd             	sub    %ebx,%r13d
    5bd9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5bdd:	eb b8                	jmp    5b97 <fwp_apply+0x27>
    5bdf:	90                   	nop
    5be0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5be5:	41 39 df             	cmp    %ebx,%r15d
    5be8:	0f 82 cc 00 00 00    	jb     5cba <fwp_apply+0x14a>
    5bee:	41 89 df             	mov    %ebx,%r15d
    5bf1:	b8 01 00 00 00       	mov    $0x1,%eax
    5bf6:	48 89 e2             	mov    %rsp,%rdx
    5bf9:	45 29 e7             	sub    %r12d,%r15d
    5bfc:	85 db                	test   %ebx,%ebx
    5bfe:	0f 45 c3             	cmovne %ebx,%eax
    5c01:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c08:	00 
    5c09:	48 c1 e8 04          	shr    $0x4,%rax
    5c0d:	48 c1 e0 04          	shl    $0x4,%rax
    5c11:	48 89 c6             	mov    %rax,%rsi
    5c14:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c1b:	48 29 f2             	sub    %rsi,%rdx
    5c1e:	48 39 d4             	cmp    %rdx,%rsp
    5c21:	74 15                	je     5c38 <fwp_apply+0xc8>
    5c23:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c2a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c31:	00 00 
    5c33:	48 39 d4             	cmp    %rdx,%rsp
    5c36:	75 eb                	jne    5c23 <fwp_apply+0xb3>
    5c38:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c3d:	48 29 c4             	sub    %rax,%rsp
    5c40:	48 85 c0             	test   %rax,%rax
    5c43:	0f 85 49 01 00 00    	jne    5d92 <fwp_apply+0x222>
    5c49:	45 89 e2             	mov    %r12d,%r10d
    5c4c:	48 89 e6             	mov    %rsp,%rsi
    5c4f:	48 89 e7             	mov    %rsp,%rdi
    5c52:	31 c0                	xor    %eax,%eax
    5c54:	49 c1 e2 03          	shl    $0x3,%r10
    5c58:	45 85 e4             	test   %r12d,%r12d
    5c5b:	74 15                	je     5c72 <fwp_apply+0x102>
    5c5d:	0f 1f 00             	nopl   (%rax)
    5c60:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5c65:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5c69:	48 83 c0 08          	add    $0x8,%rax
    5c6d:	4c 39 d0             	cmp    %r10,%rax
    5c70:	75 ee                	jne    5c60 <fwp_apply+0xf0>
    5c72:	45 85 ff             	test   %r15d,%r15d
    5c75:	0f 84 f4 00 00 00    	je     5d6f <fwp_apply+0x1ff>
    5c7b:	44 89 fa             	mov    %r15d,%edx
    5c7e:	4c 89 f0             	mov    %r14,%rax
    5c81:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5c85:	44 89 e2             	mov    %r12d,%edx
    5c88:	66 90                	xchg   %ax,%ax
    5c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c91:	00 00 00 00 
    5c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c9c:	00 00 00 00 
    5ca0:	4c 8b 10             	mov    (%rax),%r10
    5ca3:	89 d1                	mov    %edx,%ecx
    5ca5:	48 83 c0 08          	add    $0x8,%rax
    5ca9:	83 c2 01             	add    $0x1,%edx
    5cac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5cb0:	4c 39 d8             	cmp    %r11,%rax
    5cb3:	75 eb                	jne    5ca0 <fwp_apply+0x130>
    5cb5:	e9 b5 00 00 00       	jmp    5d6f <fwp_apply+0x1ff>
    5cba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5cbe:	be 02 00 00 00       	mov    $0x2,%esi
    5cc3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5cc7:	48 c1 e7 03          	shl    $0x3,%rdi
    5ccb:	e8 80 fd ff ff       	call   5a50 <fwp_heap_alloc>
    5cd0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5cd4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5cd9:	48 89 c3             	mov    %rax,%rbx
    5cdc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5ce0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ce4:	66 0f d6 00          	movq   %xmm0,(%rax)
    5ce8:	45 85 e4             	test   %r12d,%r12d
    5ceb:	74 14                	je     5d01 <fwp_apply+0x191>
    5ced:	44 89 e2             	mov    %r12d,%edx
    5cf0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5cf4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5cf8:	48 c1 e2 03          	shl    $0x3,%rdx
    5cfc:	e8 0f d9 ff ff       	call   3610 <memmove@plt>
    5d01:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d05:	45 85 ed             	test   %r13d,%r13d
    5d08:	74 2e                	je     5d38 <fwp_apply+0x1c8>
    5d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d11:	00 00 00 00 
    5d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d1c:	00 00 00 00 
    5d20:	49 8b 16             	mov    (%r14),%rdx
    5d23:	44 89 e0             	mov    %r12d,%eax
    5d26:	49 83 c6 08          	add    $0x8,%r14
    5d2a:	41 83 c4 01          	add    $0x1,%r12d
    5d2e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d33:	49 39 ce             	cmp    %rcx,%r14
    5d36:	75 e8                	jne    5d20 <fwp_apply+0x1b0>
    5d38:	48 89 d9             	mov    %rbx,%rcx
    5d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d40:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5d44:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d4b:	00 00 
    5d4d:	75 4e                	jne    5d9d <fwp_apply+0x22d>
    5d4f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5d53:	48 89 c8             	mov    %rcx,%rax
    5d56:	5b                   	pop    %rbx
    5d57:	41 5c                	pop    %r12
    5d59:	41 5d                	pop    %r13
    5d5b:	41 5e                	pop    %r14
    5d5d:	41 5f                	pop    %r15
    5d5f:	5d                   	pop    %rbp
    5d60:	c3                   	ret
    5d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d68:	45 31 ff             	xor    %r15d,%r15d
    5d6b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5d6f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5d73:	41 ff 51 08          	call   *0x8(%r9)
    5d77:	48 89 c1             	mov    %rax,%rcx
    5d7a:	45 39 fd             	cmp    %r15d,%r13d
    5d7d:	74 c1                	je     5d40 <fwp_apply+0x1d0>
    5d7f:	45 01 e5             	add    %r12d,%r13d
    5d82:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5d86:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5d8a:	41 29 dd             	sub    %ebx,%r13d
    5d8d:	e9 05 fe ff ff       	jmp    5b97 <fwp_apply+0x27>
    5d92:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5d98:	e9 ac fe ff ff       	jmp    5c49 <fwp_apply+0xd9>
    5d9d:	e8 be d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5da2:	0f 1f 00             	nopl   (%rax)
    5da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dac:	00 00 00 00 

0000000000005db0 <fwp_p_ad_push>:
    5db0:	41 57                	push   %r15
    5db2:	41 56                	push   %r14
    5db4:	41 55                	push   %r13
    5db6:	49 89 d5             	mov    %rdx,%r13
    5db9:	41 54                	push   %r12
    5dbb:	49 89 fc             	mov    %rdi,%r12
    5dbe:	55                   	push   %rbp
    5dbf:	53                   	push   %rbx
    5dc0:	48 83 ec 48          	sub    $0x48,%rsp
    5dc4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5dc9:	48 85 ff             	test   %rdi,%rdi
    5dcc:	79 09                	jns    5dd7 <fwp_p_ad_push+0x27>
    5dce:	48 85 d2             	test   %rdx,%rdx
    5dd1:	0f 88 b9 02 00 00    	js     6090 <fwp_p_ad_push+0x2e0>
    5dd7:	48 89 f8             	mov    %rdi,%rax
    5dda:	48 89 0c 24          	mov    %rcx,(%rsp)
    5dde:	4c 89 c5             	mov    %r8,%rbp
    5de1:	48 09 d0             	or     %rdx,%rax
    5de4:	0f 89 7e 02 00 00    	jns    6068 <fwp_p_ad_push+0x2b8>
    5dea:	48 85 ff             	test   %rdi,%rdi
    5ded:	0f 89 e6 03 00 00    	jns    61d9 <fwp_p_ad_push+0x429>
    5df3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5df8:	49 89 d6             	mov    %rdx,%r14
    5dfb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5e02:	00 
    5e03:	49 89 d4             	mov    %rdx,%r12
    5e06:	49 c1 fe 20          	sar    $0x20,%r14
    5e0a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5e11:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5e17:	48 85 ed             	test   %rbp,%rbp
    5e1a:	0f 84 48 03 00 00    	je     6168 <fwp_p_ad_push+0x3b8>
    5e20:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    5e24:	0f 84 be 02 00 00    	je     60e8 <fwp_p_ad_push+0x338>
    5e2a:	4c 89 f7             	mov    %r14,%rdi
    5e2d:	e8 4e e6 ff ff       	call   4480 <fwp_tape_of>
    5e32:	48 89 c3             	mov    %rax,%rbx
    5e35:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5e3a:	0f 85 3e 03 00 00    	jne    617e <fwp_p_ad_push+0x3ce>
    5e40:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    5e44:	48 89 45 08          	mov    %rax,0x8(%rbp)
    5e48:	4c 8b 43 10          	mov    0x10(%rbx),%r8
    5e4c:	49 81 f8 fe ff ff 7f 	cmp    $0x7ffffffe,%r8
    5e53:	0f 8f cd 03 00 00    	jg     6226 <fwp_p_ad_push+0x476>
    5e59:	44 89 e0             	mov    %r12d,%eax
    5e5c:	4c 39 c0             	cmp    %r8,%rax
    5e5f:	0f 8d b5 03 00 00    	jge    621a <fwp_p_ad_push+0x46a>
    5e65:	4d 85 ed             	test   %r13,%r13
    5e68:	78 0c                	js     5e76 <fwp_p_ad_push+0xc6>
    5e6a:	44 89 e8             	mov    %r13d,%eax
    5e6d:	4c 39 c0             	cmp    %r8,%rax
    5e70:	0f 8d a4 03 00 00    	jge    621a <fwp_p_ad_push+0x46a>
    5e76:	4d 89 c7             	mov    %r8,%r15
    5e79:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    5e7d:	49 8d 47 01          	lea    0x1(%r15),%rax
    5e81:	4c 89 f9             	mov    %r15,%rcx
    5e84:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5e8a:	0f 87 96 03 00 00    	ja     6226 <fwp_p_ad_push+0x476>
    5e90:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5e94:	48 39 e8             	cmp    %rbp,%rax
    5e97:	0f 8e 23 02 00 00    	jle    60c0 <fwp_p_ad_push+0x310>
    5e9d:	48 85 ed             	test   %rbp,%rbp
    5ea0:	ba 40 00 00 00       	mov    $0x40,%edx
    5ea5:	48 0f 44 ea          	cmove  %rdx,%rbp
    5ea9:	48 39 e8             	cmp    %rbp,%rax
    5eac:	7e 22                	jle    5ed0 <fwp_p_ad_push+0x120>
    5eae:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5eb5:	0f 8f f5 01 00 00    	jg     60b0 <fwp_p_ad_push+0x300>
    5ebb:	48 01 ed             	add    %rbp,%rbp
    5ebe:	48 39 e8             	cmp    %rbp,%rax
    5ec1:	7f eb                	jg     5eae <fwp_p_ad_push+0xfe>
    5ec3:	66 90                	xchg   %ax,%ax
    5ec5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ecc:	00 00 00 00 
    5ed0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5ed7:	00 
    5ed8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5edc:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5ee1:	48 89 c6             	mov    %rax,%rsi
    5ee4:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5ee9:	4c 8b 73 60          	mov    0x60(%rbx),%r14
    5eed:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5ef2:	e8 d9 d6 ff ff       	call   35d0 <realloc@plt>
    5ef7:	48 85 c0             	test   %rax,%rax
    5efa:	0f 84 32 03 00 00    	je     6232 <fwp_p_ad_push+0x482>
    5f00:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    5f04:	4d 85 f6             	test   %r14,%r14
    5f07:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    5f0c:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5f10:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5f15:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5f19:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    5f1d:	0f 84 d5 01 00 00    	je     60f8 <fwp_p_ad_push+0x348>
    5f23:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5f27:	48 39 ea             	cmp    %rbp,%rdx
    5f2a:	0f 8d bb 00 00 00    	jge    5feb <fwp_p_ad_push+0x23b>
    5f30:	49 8b 76 40          	mov    0x40(%r14),%rsi
    5f34:	48 89 ef             	mov    %rbp,%rdi
    5f37:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5f3c:	48 c1 e7 04          	shl    $0x4,%rdi
    5f40:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5f45:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    5f4a:	be 02 00 00 00       	mov    $0x2,%esi
    5f4f:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    5f54:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    5f59:	e8 f2 fa ff ff       	call   5a50 <fwp_heap_alloc>
    5f5e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    5f63:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5f68:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5f6d:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5f72:	48 85 f6             	test   %rsi,%rsi
    5f75:	74 31                	je     5fa8 <fwp_p_ad_push+0x1f8>
    5f77:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    5f7c:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    5f81:	48 c1 e2 04          	shl    $0x4,%rdx
    5f85:	48 39 fa             	cmp    %rdi,%rdx
    5f88:	48 0f 47 d7          	cmova  %rdi,%rdx
    5f8c:	48 89 c7             	mov    %rax,%rdi
    5f8f:	e8 0c d6 ff ff       	call   35a0 <memcpy@plt>
    5f94:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    5f99:	e8 b2 f5 ff ff       	call   5550 <fwp_mem_free>
    5f9e:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5fa3:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5fa8:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5fac:	48 89 ea             	mov    %rbp,%rdx
    5faf:	31 f6                	xor    %esi,%esi
    5fb1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    5fb6:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5fbb:	48 29 fa             	sub    %rdi,%rdx
    5fbe:	48 c1 e7 04          	shl    $0x4,%rdi
    5fc2:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    5fc7:	48 c1 e2 04          	shl    $0x4,%rdx
    5fcb:	e8 f0 d4 ff ff       	call   34c0 <memset@plt>
    5fd0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5fd5:	49 89 6e 60          	mov    %rbp,0x60(%r14)
    5fd9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    5fde:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    5fe3:	49 89 46 40          	mov    %rax,0x40(%r14)
    5fe7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    5feb:	4d 85 ff             	test   %r15,%r15
    5fee:	0f 85 9c 01 00 00    	jne    6190 <fwp_p_ad_push+0x3e0>
    5ff4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    5ff8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5ffc:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6003:	00 
    6004:	49 01 c6             	add    %rax,%r14
    6007:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    600b:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    600f:	46 89 24 38          	mov    %r12d,(%rax,%r15,1)
    6013:	4d 85 ed             	test   %r13,%r13
    6016:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    601c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6023:	4c 0f 48 e8          	cmovs  %rax,%r13
    6027:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    602c:	49 8d 40 01          	lea    0x1(%r8),%rax
    6030:	f2 0f 11 0c 0a       	movsd  %xmm1,(%rdx,%rcx,1)
    6035:	47 89 2c 3e          	mov    %r13d,(%r14,%r15,1)
    6039:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    603e:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6042:	48 83 c4 48          	add    $0x48,%rsp
    6046:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    604d:	ff ff ff 
    6050:	4c 21 e0             	and    %r12,%rax
    6053:	5b                   	pop    %rbx
    6054:	5d                   	pop    %rbp
    6055:	4c 09 c0             	or     %r8,%rax
    6058:	41 5c                	pop    %r12
    605a:	41 5d                	pop    %r13
    605c:	41 5e                	pop    %r14
    605e:	41 5f                	pop    %r15
    6060:	c3                   	ret
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	48 c1 fa 20          	sar    $0x20,%rdx
    606c:	48 c1 ff 20          	sar    $0x20,%rdi
    6070:	49 89 d6             	mov    %rdx,%r14
    6073:	48 39 d7             	cmp    %rdx,%rdi
    6076:	0f 84 9b fd ff ff    	je     5e17 <fwp_p_ad_push+0x67>
    607c:	48 8d 3d 3d 67 00 00 	lea    0x673d(%rip),%rdi        # c7c0 <_IO_stdin_used+0x7c0>
    6083:	e8 18 e1 ff ff       	call   41a0 <fwp_trap>
    6088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    608f:	00 
    6090:	48 83 c4 48          	add    $0x48,%rsp
    6094:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    609b:	5b                   	pop    %rbx
    609c:	5d                   	pop    %rbp
    609d:	41 5c                	pop    %r12
    609f:	41 5d                	pop    %r13
    60a1:	41 5e                	pop    %r14
    60a3:	41 5f                	pop    %r15
    60a5:	c3                   	ret
    60a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60ad:	00 00 00 
    60b0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    60b5:	e9 16 fe ff ff       	jmp    5ed0 <fwp_p_ad_push+0x120>
    60ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    60c0:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60c4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    60c8:	48 c1 e1 03          	shl    $0x3,%rcx
    60cc:	4e 8d 3c bd 00 00 00 	lea    0x0(,%r15,4),%r15
    60d3:	00 
    60d4:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    60d8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    60dc:	e9 2e ff ff ff       	jmp    600f <fwp_p_ad_push+0x25f>
    60e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60e8:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    60ec:	e9 57 fd ff ff       	jmp    5e48 <fwp_p_ad_push+0x98>
    60f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60f8:	49 89 ee             	mov    %rbp,%r14
    60fb:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    60ff:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6104:	49 c1 e6 04          	shl    $0x4,%r14
    6108:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    610d:	4c 89 f6             	mov    %r14,%rsi
    6110:	e8 bb d4 ff ff       	call   35d0 <realloc@plt>
    6115:	48 89 c2             	mov    %rax,%rdx
    6118:	48 85 c0             	test   %rax,%rax
    611b:	0f 84 11 01 00 00    	je     6232 <fwp_p_ad_push+0x482>
    6121:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6125:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6129:	4d 85 ff             	test   %r15,%r15
    612c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6131:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6136:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    613a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    613f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6143:	48 8d 3c 02          	lea    (%rdx,%rax,1),%rdi
    6147:	0f 85 98 00 00 00    	jne    61e5 <fwp_p_ad_push+0x435>
    614d:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6151:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6155:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    615c:	00 
    615d:	45 31 ff             	xor    %r15d,%r15d
    6160:	e9 9f fe ff ff       	jmp    6004 <fwp_p_ad_push+0x254>
    6165:	0f 1f 00             	nopl   (%rax)
    6168:	4c 89 f7             	mov    %r14,%rdi
    616b:	e8 10 e3 ff ff       	call   4480 <fwp_tape_of>
    6170:	48 89 c3             	mov    %rax,%rbx
    6173:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6178:	0f 84 ca fc ff ff    	je     5e48 <fwp_p_ad_push+0x98>
    617e:	48 8d 3d 83 66 00 00 	lea    0x6683(%rip),%rdi        # c808 <_IO_stdin_used+0x808>
    6185:	e8 16 e0 ff ff       	call   41a0 <fwp_trap>
    618a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6190:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
    6197:	00 
    6198:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    619d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    61a1:	49 c1 e7 02          	shl    $0x2,%r15
    61a5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    61aa:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    61b1:	00 
    61b2:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    61b6:	4c 89 fa             	mov    %r15,%rdx
    61b9:	e8 52 d4 ff ff       	call   3610 <memmove@plt>
    61be:	48 8b 43 20          	mov    0x20(%rbx),%rax
    61c2:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    61c6:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    61ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    61cf:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    61d4:	e9 2b fe ff ff       	jmp    6004 <fwp_p_ad_push+0x254>
    61d9:	48 c1 ff 20          	sar    $0x20,%rdi
    61dd:	49 89 fe             	mov    %rdi,%r14
    61e0:	e9 32 fc ff ff       	jmp    5e17 <fwp_p_ad_push+0x67>
    61e5:	4c 39 f0             	cmp    %r14,%rax
    61e8:	4c 89 f1             	mov    %r14,%rcx
    61eb:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
    61f2:	00 
    61f3:	49 89 c6             	mov    %rax,%r14
    61f6:	48 0f 43 c8          	cmovae %rax,%rcx
    61fa:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    61ff:	48 29 c1             	sub    %rax,%rcx
    6202:	e8 59 d3 ff ff       	call   3560 <__memmove_chk@plt>
    6207:	4c 03 73 30          	add    0x30(%rbx),%r14
    620b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    620f:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6213:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6218:	eb 83                	jmp    619d <fwp_p_ad_push+0x3ed>
    621a:	48 8d 3d e3 5e 00 00 	lea    0x5ee3(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    6221:	e8 7a df ff ff       	call   41a0 <fwp_trap>
    6226:	48 8d 3d bc 5e 00 00 	lea    0x5ebc(%rip),%rdi        # c0e9 <_IO_stdin_used+0xe9>
    622d:	e8 6e df ff ff       	call   41a0 <fwp_trap>
    6232:	48 89 df             	mov    %rbx,%rdi
    6235:	e8 c6 d9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    623a:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    623e:	e8 7d d1 ff ff       	call   33c0 <free@plt>
    6243:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6247:	e8 74 d1 ff ff       	call   33c0 <free@plt>
    624c:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6250:	e8 6b d1 ff ff       	call   33c0 <free@plt>
    6255:	31 c9                	xor    %ecx,%ecx
    6257:	31 c0                	xor    %eax,%eax
    6259:	31 d2                	xor    %edx,%edx
    625b:	89 53 04             	mov    %edx,0x4(%rbx)
    625e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6262:	ba 13 00 00 00       	mov    $0x13,%edx
    6267:	be 01 00 00 00       	mov    $0x1,%esi
    626c:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6270:	48 8d 3d 91 5d 00 00 	lea    0x5d91(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    6277:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    627b:	48 8b 0d be 9d 00 00 	mov    0x9dbe(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    6282:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6286:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    628a:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    628e:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6292:	e8 e9 d3 ff ff       	call   3680 <fwrite@plt>
    6297:	31 ff                	xor    %edi,%edi
    6299:	e8 22 d3 ff ff       	call   35c0 <fflush@plt>
    629e:	bf 66 00 00 00       	mov    $0x66,%edi
    62a3:	e8 f8 d3 ff ff       	call   36a0 <_Exit@plt>
    62a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    62af:	00 

00000000000062b0 <w107>:
    62b0:	41 56                	push   %r14
    62b2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    62b6:	48 89 fa             	mov    %rdi,%rdx
    62b9:	41 55                	push   %r13
    62bb:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    62bf:	49 89 fd             	mov    %rdi,%r13
    62c2:	41 54                	push   %r12
    62c4:	55                   	push   %rbp
    62c5:	53                   	push   %rbx
    62c6:	48 83 ec 40          	sub    $0x40,%rsp
    62ca:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    62d0:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    62d5:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    62dc:	00 00 
    62de:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    62e3:	48 89 f5             	mov    %rsi,%rbp
    62e6:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    62eb:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    62f1:	48 89 f1             	mov    %rsi,%rcx
    62f4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    62fa:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    6301:	ff ff 
    6303:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    630a:	00 00 
    630c:	e8 9f fa ff ff       	call   5db0 <fwp_p_ad_push>
    6311:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6317:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    631c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6322:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6329:	00 f0 3f 
    632c:	48 89 c7             	mov    %rax,%rdi
    632f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6336:	00 f0 bf 
    6339:	48 89 ea             	mov    %rbp,%rdx
    633c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6341:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6347:	e8 64 fa ff ff       	call   5db0 <fwp_p_ad_push>
    634c:	f2 0f 10 05 dc 67 00 	movsd  0x67dc(%rip),%xmm0        # cb30 <msg.4+0xb0>
    6353:	00 
    6354:	4c 89 ef             	mov    %r13,%rdi
    6357:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    635d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6362:	49 89 c6             	mov    %rax,%r14
    6365:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    636c:	00 f0 3f 
    636f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6376:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    637d:	00 f0 bf 
    6380:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    6385:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    638b:	e8 20 fa ff ff       	call   5db0 <fwp_p_ad_push>
    6390:	4c 89 e1             	mov    %r12,%rcx
    6393:	4c 89 e6             	mov    %r12,%rsi
    6396:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    639b:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    63a1:	4c 89 f2             	mov    %r14,%rdx
    63a4:	4c 89 f7             	mov    %r14,%rdi
    63a7:	49 89 c5             	mov    %rax,%r13
    63aa:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    63ae:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63b4:	e8 f7 f9 ff ff       	call   5db0 <fwp_p_ad_push>
    63b9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    63bf:	f2 0f 59 1d 71 67 00 	mulsd  0x6771(%rip),%xmm3        # cb38 <msg.4+0xb8>
    63c6:	00 
    63c7:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    63cc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    63d1:	48 89 c2             	mov    %rax,%rdx
    63d4:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    63db:	00 59 40 
    63de:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63e5:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63eb:	e8 c0 f9 ff ff       	call   5db0 <fwp_p_ad_push>
    63f0:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    63f5:	48 89 e9             	mov    %rbp,%rcx
    63f8:	4c 89 ea             	mov    %r13,%rdx
    63fb:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6401:	48 89 ee             	mov    %rbp,%rsi
    6404:	4c 89 ef             	mov    %r13,%rdi
    6407:	49 89 c4             	mov    %rax,%r12
    640a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    640e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6414:	e8 97 f9 ff ff       	call   5db0 <fwp_p_ad_push>
    6419:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    641f:	45 31 c0             	xor    %r8d,%r8d
    6422:	4c 89 e2             	mov    %r12,%rdx
    6425:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    642b:	48 89 c7             	mov    %rax,%rdi
    642e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6435:	00 f0 3f 
    6438:	48 89 ce             	mov    %rcx,%rsi
    643b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6440:	e8 6b f9 ff ff       	call   5db0 <fwp_p_ad_push>
    6445:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    644a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6451:	00 00 
    6453:	75 12                	jne    6467 <w107+0x1b7>
    6455:	48 83 c4 40          	add    $0x40,%rsp
    6459:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    645e:	5b                   	pop    %rbx
    645f:	5d                   	pop    %rbp
    6460:	41 5c                	pop    %r12
    6462:	41 5d                	pop    %r13
    6464:	41 5e                	pop    %r14
    6466:	c3                   	ret
    6467:	e8 f4 cf ff ff       	call   3460 <__stack_chk_fail@plt>
    646c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006470 <w164.constprop.0>:
    6470:	41 54                	push   %r12
    6472:	55                   	push   %rbp
    6473:	53                   	push   %rbx
    6474:	48 83 ec 10          	sub    $0x10,%rsp
    6478:	4c 8b 27             	mov    (%rdi),%r12
    647b:	4d 85 e4             	test   %r12,%r12
    647e:	74 58                	je     64d8 <w164.constprop.0+0x68>
    6480:	48 89 fd             	mov    %rdi,%rbp
    6483:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6487:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    648e:	31 db                	xor    %ebx,%ebx
    6490:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6496:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    649b:	45 31 c0             	xor    %r8d,%r8d
    649e:	48 83 c3 02          	add    $0x2,%rbx
    64a2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    64a9:	00 f0 3f 
    64ac:	48 89 ce             	mov    %rcx,%rsi
    64af:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    64b5:	e8 f6 f8 ff ff       	call   5db0 <fwp_p_ad_push>
    64ba:	4c 39 e3             	cmp    %r12,%rbx
    64bd:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    64c3:	48 89 c7             	mov    %rax,%rdi
    64c6:	72 c8                	jb     6490 <w164.constprop.0+0x20>
    64c8:	48 83 c4 10          	add    $0x10,%rsp
    64cc:	48 89 f8             	mov    %rdi,%rax
    64cf:	5b                   	pop    %rbx
    64d0:	5d                   	pop    %rbp
    64d1:	41 5c                	pop    %r12
    64d3:	c3                   	ret
    64d4:	0f 1f 40 00          	nopl   0x0(%rax)
    64d8:	48 83 c4 10          	add    $0x10,%rsp
    64dc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    64e3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    64e7:	5b                   	pop    %rbx
    64e8:	48 89 f8             	mov    %rdi,%rax
    64eb:	5d                   	pop    %rbp
    64ec:	41 5c                	pop    %r12
    64ee:	c3                   	ret
    64ef:	90                   	nop

00000000000064f0 <fwp_data.part.0.constprop.0>:
    64f0:	41 56                	push   %r14
    64f2:	41 89 fe             	mov    %edi,%r14d
    64f5:	41 54                	push   %r12
    64f7:	49 89 f4             	mov    %rsi,%r12
    64fa:	55                   	push   %rbp
    64fb:	53                   	push   %rbx
    64fc:	48 83 ec 08          	sub    $0x8,%rsp
    6500:	8b 05 fe b5 01 00    	mov    0x1b5fe(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    6506:	85 c0                	test   %eax,%eax
    6508:	0f 84 fa 00 00 00    	je     6608 <fwp_data.part.0.constprop.0+0x118>
    650e:	0f b6 05 ed b1 01 00 	movzbl 0x1b1ed(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    6515:	48 8d 15 44 a2 01 00 	lea    0x1a244(%rip),%rdx        # 20760 <fwp_heap>
    651c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6523:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6527:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    652b:	48 8b 18             	mov    (%rax),%rbx
    652e:	48 85 db             	test   %rbx,%rbx
    6531:	0f 84 a9 00 00 00    	je     65e0 <fwp_data.part.0.constprop.0+0xf0>
    6537:	48 8b 13             	mov    (%rbx),%rdx
    653a:	48 f7 d2             	not    %rdx
    653d:	48 89 10             	mov    %rdx,(%rax)
    6540:	48 83 fd 18          	cmp    $0x18,%rbp
    6544:	76 1b                	jbe    6561 <fwp_data.part.0.constprop.0+0x71>
    6546:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    654a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    654e:	31 f6                	xor    %esi,%esi
    6550:	48 c1 e8 03          	shr    $0x3,%rax
    6554:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    655b:	00 
    655c:	e8 5f cf ff ff       	call   34c0 <memset@plt>
    6561:	48 89 e8             	mov    %rbp,%rax
    6564:	48 03 05 15 b6 01 00 	add    0x1b615(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    656b:	0f 82 a8 00 00 00    	jb     6619 <fwp_data.part.0.constprop.0+0x129>
    6571:	48 39 05 10 b6 01 00 	cmp    %rax,0x1b610(%rip)        # 21b88 <fwp_heap+0x1428>
    6578:	48 89 05 01 b6 01 00 	mov    %rax,0x1b601(%rip)        # 21b80 <fwp_heap+0x1420>
    657f:	73 07                	jae    6588 <fwp_data.part.0.constprop.0+0x98>
    6581:	48 89 05 00 b6 01 00 	mov    %rax,0x1b600(%rip)        # 21b88 <fwp_heap+0x1428>
    6588:	66 0f ef c0          	pxor   %xmm0,%xmm0
    658c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6591:	f2 0f 58 05 ff b5 01 	addsd  0x1b5ff(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    6598:	00 
    6599:	f2 0f 11 05 f7 b5 01 	movsd  %xmm0,0x1b5f7(%rip)        # 21b98 <fwp_heap+0x1438>
    65a0:	00 
    65a1:	b8 02 00 00 00       	mov    $0x2,%eax
    65a6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    65ab:	66 0f 6e c8          	movd   %eax,%xmm1
    65af:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    65b3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    65b7:	49 8b 04 24          	mov    (%r12),%rax
    65bb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    65bf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    65c4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65c8:	48 83 c4 08          	add    $0x8,%rsp
    65cc:	48 89 d8             	mov    %rbx,%rax
    65cf:	5b                   	pop    %rbx
    65d0:	5d                   	pop    %rbp
    65d1:	41 5c                	pop    %r12
    65d3:	41 5e                	pop    %r14
    65d5:	c3                   	ret
    65d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65dd:	00 00 00 
    65e0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    65e4:	48 85 db             	test   %rbx,%rbx
    65e7:	74 1f                	je     6608 <fwp_data.part.0.constprop.0+0x118>
    65e9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    65ed:	48 29 da             	sub    %rbx,%rdx
    65f0:	48 39 ea             	cmp    %rbp,%rdx
    65f3:	72 13                	jb     6608 <fwp_data.part.0.constprop.0+0x118>
    65f5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    65f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    65fd:	e9 3e ff ff ff       	jmp    6540 <fwp_data.part.0.constprop.0+0x50>
    6602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6608:	31 f6                	xor    %esi,%esi
    660a:	bf 18 00 00 00       	mov    $0x18,%edi
    660f:	e8 3c f4 ff ff       	call   5a50 <fwp_heap_alloc>
    6614:	48 89 c3             	mov    %rax,%rbx
    6617:	eb 88                	jmp    65a1 <fwp_data.part.0.constprop.0+0xb1>
    6619:	e8 92 d6 ff ff       	call   3cb0 <fwp_heap_oom>
    661e:	66 90                	xchg   %ax,%ax

0000000000006620 <fwp_rc_share>:
    6620:	48 8b 05 11 b5 01 00 	mov    0x1b511(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    6627:	48 2b 3d e2 b4 01 00 	sub    0x1b4e2(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    662e:	48 c1 e0 10          	shl    $0x10,%rax
    6632:	48 39 c7             	cmp    %rax,%rdi
    6635:	73 4a                	jae    6681 <fwp_rc_share+0x61>
    6637:	48 89 f8             	mov    %rdi,%rax
    663a:	48 c1 e8 10          	shr    $0x10,%rax
    663e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6642:	48 8b 05 0f b5 01 00 	mov    0x1b50f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    6649:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    664d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6651:	48 85 d2             	test   %rdx,%rdx
    6654:	74 2b                	je     6681 <fwp_rc_share+0x61>
    6656:	0f b6 08             	movzbl (%rax),%ecx
    6659:	80 f9 02             	cmp    $0x2,%cl
    665c:	74 2a                	je     6688 <fwp_rc_share+0x68>
    665e:	80 f9 01             	cmp    $0x1,%cl
    6661:	75 1e                	jne    6681 <fwp_rc_share+0x61>
    6663:	8b 48 18             	mov    0x18(%rax),%ecx
    6666:	0f b7 ff             	movzwl %di,%edi
    6669:	8b 40 1c             	mov    0x1c(%rax),%eax
    666c:	48 0f af f9          	imul   %rcx,%rdi
    6670:	48 c1 ef 20          	shr    $0x20,%rdi
    6674:	48 39 c7             	cmp    %rax,%rdi
    6677:	73 08                	jae    6681 <fwp_rc_share+0x61>
    6679:	48 01 fa             	add    %rdi,%rdx
    667c:	80 3a 00             	cmpb   $0x0,(%rdx)
    667f:	75 0d                	jne    668e <fwp_rc_share+0x6e>
    6681:	c3                   	ret
    6682:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6688:	66 85 ff             	test   %di,%di
    668b:	74 ef                	je     667c <fwp_rc_share+0x5c>
    668d:	c3                   	ret
    668e:	50                   	push   %rax
    668f:	48 8d 3d a2 61 00 00 	lea    0x61a2(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    6696:	e8 05 db ff ff       	call   41a0 <fwp_trap>
    669b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000066a0 <fwp_rc_free_arr>:
    66a0:	48 8b 15 91 b4 01 00 	mov    0x1b491(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    66a7:	48 89 f8             	mov    %rdi,%rax
    66aa:	48 2b 05 5f b4 01 00 	sub    0x1b45f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    66b1:	48 c1 e2 10          	shl    $0x10,%rdx
    66b5:	48 39 d0             	cmp    %rdx,%rax
    66b8:	73 5b                	jae    6715 <fwp_rc_free_arr+0x75>
    66ba:	48 89 c2             	mov    %rax,%rdx
    66bd:	48 c1 ea 10          	shr    $0x10,%rdx
    66c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66c5:	48 8b 15 8c b4 01 00 	mov    0x1b48c(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    66cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    66d0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    66d4:	48 85 c9             	test   %rcx,%rcx
    66d7:	74 3c                	je     6715 <fwp_rc_free_arr+0x75>
    66d9:	0f b6 32             	movzbl (%rdx),%esi
    66dc:	40 80 fe 02          	cmp    $0x2,%sil
    66e0:	74 2e                	je     6710 <fwp_rc_free_arr+0x70>
    66e2:	40 80 fe 01          	cmp    $0x1,%sil
    66e6:	75 2d                	jne    6715 <fwp_rc_free_arr+0x75>
    66e8:	8b 72 18             	mov    0x18(%rdx),%esi
    66eb:	0f b7 c0             	movzwl %ax,%eax
    66ee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    66f1:	48 0f af c6          	imul   %rsi,%rax
    66f5:	48 c1 e8 20          	shr    $0x20,%rax
    66f9:	48 39 d0             	cmp    %rdx,%rax
    66fc:	73 17                	jae    6715 <fwp_rc_free_arr+0x75>
    66fe:	48 01 c1             	add    %rax,%rcx
    6701:	80 39 01             	cmpb   $0x1,(%rcx)
    6704:	75 0f                	jne    6715 <fwp_rc_free_arr+0x75>
    6706:	e9 45 ee ff ff       	jmp    5550 <fwp_mem_free>
    670b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6710:	66 85 c0             	test   %ax,%ax
    6713:	74 ec                	je     6701 <fwp_rc_free_arr+0x61>
    6715:	c3                   	ret
    6716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    671d:	00 00 00 

0000000000006720 <fwp_rc_dup>:
    6720:	f3 0f 1e fa          	endbr64
    6724:	48 8b 05 0d b4 01 00 	mov    0x1b40d(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    672b:	48 2b 3d de b3 01 00 	sub    0x1b3de(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    6732:	48 c1 e0 10          	shl    $0x10,%rax
    6736:	48 39 c7             	cmp    %rax,%rdi
    6739:	73 56                	jae    6791 <fwp_rc_dup+0x71>
    673b:	48 89 f8             	mov    %rdi,%rax
    673e:	48 c1 e8 10          	shr    $0x10,%rax
    6742:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6746:	48 8b 05 0b b4 01 00 	mov    0x1b40b(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    674d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6751:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6755:	48 85 c0             	test   %rax,%rax
    6758:	74 37                	je     6791 <fwp_rc_dup+0x71>
    675a:	0f b6 0a             	movzbl (%rdx),%ecx
    675d:	80 f9 02             	cmp    $0x2,%cl
    6760:	74 36                	je     6798 <fwp_rc_dup+0x78>
    6762:	80 f9 01             	cmp    $0x1,%cl
    6765:	75 2a                	jne    6791 <fwp_rc_dup+0x71>
    6767:	8b 4a 18             	mov    0x18(%rdx),%ecx
    676a:	0f b7 ff             	movzwl %di,%edi
    676d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6770:	48 0f af f9          	imul   %rcx,%rdi
    6774:	48 c1 ef 20          	shr    $0x20,%rdi
    6778:	48 39 d7             	cmp    %rdx,%rdi
    677b:	73 14                	jae    6791 <fwp_rc_dup+0x71>
    677d:	48 01 f8             	add    %rdi,%rax
    6780:	0f b6 10             	movzbl (%rax),%edx
    6783:	84 d2                	test   %dl,%dl
    6785:	74 0a                	je     6791 <fwp_rc_dup+0x71>
    6787:	80 fa fd             	cmp    $0xfd,%dl
    678a:	77 14                	ja     67a0 <fwp_rc_dup+0x80>
    678c:	83 c2 01             	add    $0x1,%edx
    678f:	88 10                	mov    %dl,(%rax)
    6791:	c3                   	ret
    6792:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6798:	66 85 ff             	test   %di,%di
    679b:	74 e3                	je     6780 <fwp_rc_dup+0x60>
    679d:	c3                   	ret
    679e:	66 90                	xchg   %ax,%ax
    67a0:	48 89 c7             	mov    %rax,%rdi
    67a3:	e9 48 ea ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    67a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    67af:	00 

00000000000067b0 <fwp_drop0>:
    67b0:	f3 0f 1e fa          	endbr64
    67b4:	48 8b 15 7d b3 01 00 	mov    0x1b37d(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    67bb:	48 89 f8             	mov    %rdi,%rax
    67be:	48 2b 05 4b b3 01 00 	sub    0x1b34b(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    67c5:	48 c1 e2 10          	shl    $0x10,%rdx
    67c9:	48 39 d0             	cmp    %rdx,%rax
    67cc:	0f 83 be 00 00 00    	jae    6890 <fwp_drop0+0xe0>
    67d2:	48 83 ec 18          	sub    $0x18,%rsp
    67d6:	4c 8d 05 83 9f 01 00 	lea    0x19f83(%rip),%r8        # 20760 <fwp_heap>
    67dd:	48 89 c2             	mov    %rax,%rdx
    67e0:	48 c1 ea 10          	shr    $0x10,%rdx
    67e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67e8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    67ef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    67f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    67f7:	48 85 d2             	test   %rdx,%rdx
    67fa:	74 3c                	je     6838 <fwp_drop0+0x88>
    67fc:	0f b6 31             	movzbl (%rcx),%esi
    67ff:	40 80 fe 02          	cmp    $0x2,%sil
    6803:	74 3b                	je     6840 <fwp_drop0+0x90>
    6805:	40 80 fe 01          	cmp    $0x1,%sil
    6809:	75 2d                	jne    6838 <fwp_drop0+0x88>
    680b:	8b 71 18             	mov    0x18(%rcx),%esi
    680e:	0f b7 c0             	movzwl %ax,%eax
    6811:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6814:	48 0f af c6          	imul   %rsi,%rax
    6818:	48 c1 e8 20          	shr    $0x20,%rax
    681c:	48 39 c8             	cmp    %rcx,%rax
    681f:	73 17                	jae    6838 <fwp_drop0+0x88>
    6821:	48 01 c2             	add    %rax,%rdx
    6824:	0f b6 02             	movzbl (%rdx),%eax
    6827:	84 c0                	test   %al,%al
    6829:	74 0d                	je     6838 <fwp_drop0+0x88>
    682b:	3c 01                	cmp    $0x1,%al
    682d:	74 21                	je     6850 <fwp_drop0+0xa0>
    682f:	3c ff                	cmp    $0xff,%al
    6831:	74 65                	je     6898 <fwp_drop0+0xe8>
    6833:	83 e8 01             	sub    $0x1,%eax
    6836:	88 02                	mov    %al,(%rdx)
    6838:	48 83 c4 18          	add    $0x18,%rsp
    683c:	c3                   	ret
    683d:	0f 1f 00             	nopl   (%rax)
    6840:	66 85 c0             	test   %ax,%ax
    6843:	74 df                	je     6824 <fwp_drop0+0x74>
    6845:	48 83 c4 18          	add    $0x18,%rsp
    6849:	c3                   	ret
    684a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6850:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6854:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6859:	e8 42 fe ff ff       	call   66a0 <fwp_rc_free_arr>
    685e:	4c 8d 05 fb 9e 01 00 	lea    0x19efb(%rip),%r8        # 20760 <fwp_heap>
    6865:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    686a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6871:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6878:	48 c1 e2 10          	shl    $0x10,%rdx
    687c:	48 39 d0             	cmp    %rdx,%rax
    687f:	73 b7                	jae    6838 <fwp_drop0+0x88>
    6881:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6886:	e9 52 ff ff ff       	jmp    67dd <fwp_drop0+0x2d>
    688b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6890:	c3                   	ret
    6891:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6898:	48 89 d0             	mov    %rdx,%rax
    689b:	48 c1 e8 11          	shr    $0x11,%rax
    689f:	48 31 d0             	xor    %rdx,%rax
    68a2:	48 89 c1             	mov    %rax,%rcx
    68a5:	48 c1 e9 09          	shr    $0x9,%rcx
    68a9:	48 31 c8             	xor    %rcx,%rax
    68ac:	0f b6 c8             	movzbl %al,%ecx
    68af:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    68b6:	00 
    68b7:	48 85 c0             	test   %rax,%rax
    68ba:	75 0d                	jne    68c9 <fwp_drop0+0x119>
    68bc:	eb 46                	jmp    6904 <fwp_drop0+0x154>
    68be:	66 90                	xchg   %ax,%ax
    68c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    68c4:	48 85 c0             	test   %rax,%rax
    68c7:	74 3b                	je     6904 <fwp_drop0+0x154>
    68c9:	48 89 c1             	mov    %rax,%rcx
    68cc:	48 39 10             	cmp    %rdx,(%rax)
    68cf:	75 ef                	jne    68c0 <fwp_drop0+0x110>
    68d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    68d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    68d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    68dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    68e4:	0f 85 4e ff ff ff    	jne    6838 <fwp_drop0+0x88>
    68ea:	48 89 d7             	mov    %rdx,%rdi
    68ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    68f2:	e8 19 ea ff ff       	call   5310 <fwp_rc_forget_slot>
    68f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    68fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    68ff:	e9 34 ff ff ff       	jmp    6838 <fwp_drop0+0x88>
    6904:	48 8d 3d 8d 5e 00 00 	lea    0x5e8d(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    690b:	e8 90 d8 ff ff       	call   41a0 <fwp_trap>

0000000000006910 <fwp_arg_drop12>:
    6910:	f3 0f 1e fa          	endbr64
    6914:	85 f6                	test   %esi,%esi
    6916:	75 04                	jne    691c <fwp_arg_drop12+0xc>
    6918:	85 d2                	test   %edx,%edx
    691a:	75 04                	jne    6920 <fwp_arg_drop12+0x10>
    691c:	c3                   	ret
    691d:	0f 1f 00             	nopl   (%rax)
    6920:	48 8b 3f             	mov    (%rdi),%rdi
    6923:	e9 88 fe ff ff       	jmp    67b0 <fwp_drop0>
    6928:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    692f:	00 

0000000000006930 <fwp_drop1>:
    6930:	f3 0f 1e fa          	endbr64
    6934:	48 8b 15 fd b1 01 00 	mov    0x1b1fd(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    693b:	48 89 f8             	mov    %rdi,%rax
    693e:	48 2b 05 cb b1 01 00 	sub    0x1b1cb(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6945:	48 c1 e2 10          	shl    $0x10,%rdx
    6949:	48 39 d0             	cmp    %rdx,%rax
    694c:	0f 83 be 00 00 00    	jae    6a10 <fwp_drop1+0xe0>
    6952:	48 83 ec 18          	sub    $0x18,%rsp
    6956:	4c 8d 05 03 9e 01 00 	lea    0x19e03(%rip),%r8        # 20760 <fwp_heap>
    695d:	48 89 c2             	mov    %rax,%rdx
    6960:	48 c1 ea 10          	shr    $0x10,%rdx
    6964:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6968:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    696f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6973:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6977:	48 85 d2             	test   %rdx,%rdx
    697a:	74 3c                	je     69b8 <fwp_drop1+0x88>
    697c:	0f b6 31             	movzbl (%rcx),%esi
    697f:	40 80 fe 02          	cmp    $0x2,%sil
    6983:	74 3b                	je     69c0 <fwp_drop1+0x90>
    6985:	40 80 fe 01          	cmp    $0x1,%sil
    6989:	75 2d                	jne    69b8 <fwp_drop1+0x88>
    698b:	8b 71 18             	mov    0x18(%rcx),%esi
    698e:	0f b7 c0             	movzwl %ax,%eax
    6991:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6994:	48 0f af c6          	imul   %rsi,%rax
    6998:	48 c1 e8 20          	shr    $0x20,%rax
    699c:	48 39 c8             	cmp    %rcx,%rax
    699f:	73 17                	jae    69b8 <fwp_drop1+0x88>
    69a1:	48 01 c2             	add    %rax,%rdx
    69a4:	0f b6 02             	movzbl (%rdx),%eax
    69a7:	84 c0                	test   %al,%al
    69a9:	74 0d                	je     69b8 <fwp_drop1+0x88>
    69ab:	3c 01                	cmp    $0x1,%al
    69ad:	74 21                	je     69d0 <fwp_drop1+0xa0>
    69af:	3c ff                	cmp    $0xff,%al
    69b1:	74 65                	je     6a18 <fwp_drop1+0xe8>
    69b3:	83 e8 01             	sub    $0x1,%eax
    69b6:	88 02                	mov    %al,(%rdx)
    69b8:	48 83 c4 18          	add    $0x18,%rsp
    69bc:	c3                   	ret
    69bd:	0f 1f 00             	nopl   (%rax)
    69c0:	66 85 c0             	test   %ax,%ax
    69c3:	74 df                	je     69a4 <fwp_drop1+0x74>
    69c5:	48 83 c4 18          	add    $0x18,%rsp
    69c9:	c3                   	ret
    69ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    69d0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    69d4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    69d9:	e8 c2 fc ff ff       	call   66a0 <fwp_rc_free_arr>
    69de:	4c 8d 05 7b 9d 01 00 	lea    0x19d7b(%rip),%r8        # 20760 <fwp_heap>
    69e5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    69ea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    69f1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    69f8:	48 c1 e2 10          	shl    $0x10,%rdx
    69fc:	48 39 d0             	cmp    %rdx,%rax
    69ff:	73 b7                	jae    69b8 <fwp_drop1+0x88>
    6a01:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6a06:	e9 52 ff ff ff       	jmp    695d <fwp_drop1+0x2d>
    6a0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a10:	c3                   	ret
    6a11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a18:	48 89 d0             	mov    %rdx,%rax
    6a1b:	48 c1 e8 11          	shr    $0x11,%rax
    6a1f:	48 31 d0             	xor    %rdx,%rax
    6a22:	48 89 c1             	mov    %rax,%rcx
    6a25:	48 c1 e9 09          	shr    $0x9,%rcx
    6a29:	48 31 c8             	xor    %rcx,%rax
    6a2c:	0f b6 c8             	movzbl %al,%ecx
    6a2f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6a36:	00 
    6a37:	48 85 c0             	test   %rax,%rax
    6a3a:	75 0d                	jne    6a49 <fwp_drop1+0x119>
    6a3c:	eb 46                	jmp    6a84 <fwp_drop1+0x154>
    6a3e:	66 90                	xchg   %ax,%ax
    6a40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6a44:	48 85 c0             	test   %rax,%rax
    6a47:	74 3b                	je     6a84 <fwp_drop1+0x154>
    6a49:	48 89 c1             	mov    %rax,%rcx
    6a4c:	48 39 10             	cmp    %rdx,(%rax)
    6a4f:	75 ef                	jne    6a40 <fwp_drop1+0x110>
    6a51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6a55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6a59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6a5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6a64:	0f 85 4e ff ff ff    	jne    69b8 <fwp_drop1+0x88>
    6a6a:	48 89 d7             	mov    %rdx,%rdi
    6a6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6a72:	e8 99 e8 ff ff       	call   5310 <fwp_rc_forget_slot>
    6a77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6a7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6a7f:	e9 34 ff ff ff       	jmp    69b8 <fwp_drop1+0x88>
    6a84:	48 8d 3d 0d 5d 00 00 	lea    0x5d0d(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    6a8b:	e8 10 d7 ff ff       	call   41a0 <fwp_trap>

0000000000006a90 <fwp_closure_drop>:
    6a90:	48 8b 15 a1 b0 01 00 	mov    0x1b0a1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6a97:	48 89 f8             	mov    %rdi,%rax
    6a9a:	48 2b 05 6f b0 01 00 	sub    0x1b06f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6aa1:	48 c1 e2 10          	shl    $0x10,%rdx
    6aa5:	48 39 d0             	cmp    %rdx,%rax
    6aa8:	73 6b                	jae    6b15 <fwp_closure_drop+0x85>
    6aaa:	48 89 c2             	mov    %rax,%rdx
    6aad:	48 c1 ea 10          	shr    $0x10,%rdx
    6ab1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ab5:	48 8b 15 9c b0 01 00 	mov    0x1b09c(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    6abc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ac0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ac4:	48 85 d2             	test   %rdx,%rdx
    6ac7:	74 4c                	je     6b15 <fwp_closure_drop+0x85>
    6ac9:	0f b6 31             	movzbl (%rcx),%esi
    6acc:	40 80 fe 02          	cmp    $0x2,%sil
    6ad0:	74 3e                	je     6b10 <fwp_closure_drop+0x80>
    6ad2:	40 80 fe 01          	cmp    $0x1,%sil
    6ad6:	75 3d                	jne    6b15 <fwp_closure_drop+0x85>
    6ad8:	8b 71 18             	mov    0x18(%rcx),%esi
    6adb:	0f b7 c0             	movzwl %ax,%eax
    6ade:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ae1:	48 0f af c6          	imul   %rsi,%rax
    6ae5:	48 c1 e8 20          	shr    $0x20,%rax
    6ae9:	48 39 c8             	cmp    %rcx,%rax
    6aec:	73 27                	jae    6b15 <fwp_closure_drop+0x85>
    6aee:	48 01 c2             	add    %rax,%rdx
    6af1:	0f b6 02             	movzbl (%rdx),%eax
    6af4:	84 c0                	test   %al,%al
    6af6:	74 1d                	je     6b15 <fwp_closure_drop+0x85>
    6af8:	3c 01                	cmp    $0x1,%al
    6afa:	74 24                	je     6b20 <fwp_closure_drop+0x90>
    6afc:	3c ff                	cmp    $0xff,%al
    6afe:	74 48                	je     6b48 <fwp_closure_drop+0xb8>
    6b00:	83 e8 01             	sub    $0x1,%eax
    6b03:	88 02                	mov    %al,(%rdx)
    6b05:	c3                   	ret
    6b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b0d:	00 00 00 
    6b10:	66 85 c0             	test   %ax,%ax
    6b13:	74 dc                	je     6af1 <fwp_closure_drop+0x61>
    6b15:	c3                   	ret
    6b16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b1d:	00 00 00 
    6b20:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6b27:	ff ff 
    6b29:	48 85 c0             	test   %rax,%rax
    6b2c:	74 12                	je     6b40 <fwp_closure_drop+0xb0>
    6b2e:	48 89 fe             	mov    %rdi,%rsi
    6b31:	48 89 c7             	mov    %rax,%rdi
    6b34:	e9 c7 d6 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6b39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b40:	e9 6b d8 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6b45:	0f 1f 00             	nopl   (%rax)
    6b48:	48 89 d0             	mov    %rdx,%rax
    6b4b:	48 8d 35 0e 9c 01 00 	lea    0x19c0e(%rip),%rsi        # 20760 <fwp_heap>
    6b52:	48 83 ec 18          	sub    $0x18,%rsp
    6b56:	48 c1 e8 11          	shr    $0x11,%rax
    6b5a:	48 31 d0             	xor    %rdx,%rax
    6b5d:	48 89 c1             	mov    %rax,%rcx
    6b60:	48 c1 e9 09          	shr    $0x9,%rcx
    6b64:	48 31 c8             	xor    %rcx,%rax
    6b67:	0f b6 c8             	movzbl %al,%ecx
    6b6a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6b71:	00 
    6b72:	48 85 c0             	test   %rax,%rax
    6b75:	75 12                	jne    6b89 <fwp_closure_drop+0xf9>
    6b77:	eb 49                	jmp    6bc2 <fwp_closure_drop+0x132>
    6b79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b84:	48 85 c0             	test   %rax,%rax
    6b87:	74 39                	je     6bc2 <fwp_closure_drop+0x132>
    6b89:	48 89 c1             	mov    %rax,%rcx
    6b8c:	48 39 10             	cmp    %rdx,(%rax)
    6b8f:	75 ef                	jne    6b80 <fwp_closure_drop+0xf0>
    6b91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ba4:	74 05                	je     6bab <fwp_closure_drop+0x11b>
    6ba6:	48 83 c4 18          	add    $0x18,%rsp
    6baa:	c3                   	ret
    6bab:	48 89 d7             	mov    %rdx,%rdi
    6bae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6bb3:	e8 58 e7 ff ff       	call   5310 <fwp_rc_forget_slot>
    6bb8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6bbd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6bc0:	eb e4                	jmp    6ba6 <fwp_closure_drop+0x116>
    6bc2:	48 8d 3d cf 5b 00 00 	lea    0x5bcf(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    6bc9:	e8 d2 d5 ff ff       	call   41a0 <fwp_trap>
    6bce:	66 90                	xchg   %ax,%ax

0000000000006bd0 <fwp_owned_tape_release>:
    6bd0:	48 85 ff             	test   %rdi,%rdi
    6bd3:	0f 84 f7 00 00 00    	je     6cd0 <fwp_owned_tape_release+0x100>
    6bd9:	41 54                	push   %r12
    6bdb:	55                   	push   %rbp
    6bdc:	53                   	push   %rbx
    6bdd:	48 8b 07             	mov    (%rdi),%rax
    6be0:	48 85 c0             	test   %rax,%rax
    6be3:	74 08                	je     6bed <fwp_owned_tape_release+0x1d>
    6be5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6be9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6bed:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6bf1:	48 85 d2             	test   %rdx,%rdx
    6bf4:	74 03                	je     6bf9 <fwp_owned_tape_release+0x29>
    6bf6:	48 89 02             	mov    %rax,(%rdx)
    6bf9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6bfd:	48 89 fb             	mov    %rdi,%rbx
    6c00:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6c04:	48 85 c0             	test   %rax,%rax
    6c07:	0f 84 89 00 00 00    	je     6c96 <fwp_owned_tape_release+0xc6>
    6c0d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6c11:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6c15:	7e 47                	jle    6c5e <fwp_owned_tape_release+0x8e>
    6c17:	31 ed                	xor    %ebp,%ebp
    6c19:	eb 0d                	jmp    6c28 <fwp_owned_tape_release+0x58>
    6c1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c20:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6c24:	48 8b 40 68          	mov    0x68(%rax),%rax
    6c28:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6c2c:	49 89 ec             	mov    %rbp,%r12
    6c2f:	48 83 c5 01          	add    $0x1,%rbp
    6c33:	49 c1 e4 04          	shl    $0x4,%r12
    6c37:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6c3b:	ff d0                	call   *%rax
    6c3d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6c41:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6c46:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6c4a:	ff 50 68             	call   *0x68(%rax)
    6c4d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6c51:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6c55:	48 39 e8             	cmp    %rbp,%rax
    6c58:	7f c6                	jg     6c20 <fwp_owned_tape_release+0x50>
    6c5a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6c5e:	31 ed                	xor    %ebp,%ebp
    6c60:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6c65:	7e 28                	jle    6c8f <fwp_owned_tape_release+0xbf>
    6c67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c6e:	00 00 
    6c70:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6c74:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6c78:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6c7c:	74 07                	je     6c85 <fwp_owned_tape_release+0xb5>
    6c7e:	ff 52 68             	call   *0x68(%rdx)
    6c81:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6c85:	48 83 c5 01          	add    $0x1,%rbp
    6c89:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6c8d:	7f e1                	jg     6c70 <fwp_owned_tape_release+0xa0>
    6c8f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6c93:	ff 52 68             	call   *0x68(%rdx)
    6c96:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6c9a:	e8 f1 fd ff ff       	call   6a90 <fwp_closure_drop>
    6c9f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6ca3:	e8 e8 fd ff ff       	call   6a90 <fwp_closure_drop>
    6ca8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6cac:	e8 df fd ff ff       	call   6a90 <fwp_closure_drop>
    6cb1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6cb5:	e8 96 e8 ff ff       	call   5550 <fwp_mem_free>
    6cba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6cbe:	e8 8d e8 ff ff       	call   5550 <fwp_mem_free>
    6cc3:	48 89 df             	mov    %rbx,%rdi
    6cc6:	5b                   	pop    %rbx
    6cc7:	5d                   	pop    %rbp
    6cc8:	41 5c                	pop    %r12
    6cca:	e9 81 e8 ff ff       	jmp    5550 <fwp_mem_free>
    6ccf:	90                   	nop
    6cd0:	c3                   	ret
    6cd1:	0f 1f 40 00          	nopl   0x0(%rax)
    6cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cdc:	00 00 00 00 

0000000000006ce0 <fwp_tape_finish>:
    6ce0:	f3 0f 1e fa          	endbr64
    6ce4:	41 56                	push   %r14
    6ce6:	48 8d 3d b3 93 01 00 	lea    0x193b3(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    6ced:	41 55                	push   %r13
    6cef:	41 54                	push   %r12
    6cf1:	55                   	push   %rbp
    6cf2:	53                   	push   %rbx
    6cf3:	e8 78 d2 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6cf8:	48 83 3d e8 93 01 00 	cmpq   $0x0,0x193e8(%rip)        # 200e8 <fwp_ntapes>
    6cff:	00 
    6d00:	48 c7 05 7d 93 01 00 	movq   $0x0,0x1937d(%rip)        # 20088 <fwp_tape_cached_bytes>
    6d07:	00 00 00 00 
    6d0b:	7e 68                	jle    6d75 <fwp_tape_finish+0x95>
    6d0d:	45 31 e4             	xor    %r12d,%r12d
    6d10:	31 ed                	xor    %ebp,%ebp
    6d12:	0f 1f 00             	nopl   (%rax)
    6d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d1c:	00 00 00 00 
    6d20:	48 8b 1d c9 93 01 00 	mov    0x193c9(%rip),%rbx        # 200f0 <fwp_tapes>
    6d27:	48 83 c5 01          	add    $0x1,%rbp
    6d2b:	4c 01 e3             	add    %r12,%rbx
    6d2e:	49 83 c4 68          	add    $0x68,%r12
    6d32:	48 89 df             	mov    %rbx,%rdi
    6d35:	e8 c6 ce ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6d3a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6d3e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6d42:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6d46:	e8 75 c6 ff ff       	call   33c0 <free@plt>
    6d4b:	4c 89 f7             	mov    %r14,%rdi
    6d4e:	e8 6d c6 ff ff       	call   33c0 <free@plt>
    6d53:	4c 89 ef             	mov    %r13,%rdi
    6d56:	e8 65 c6 ff ff       	call   33c0 <free@plt>
    6d5b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6d5f:	e8 6c fe ff ff       	call   6bd0 <fwp_owned_tape_release>
    6d64:	48 39 2d 7d 93 01 00 	cmp    %rbp,0x1937d(%rip)        # 200e8 <fwp_ntapes>
    6d6b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6d72:	00 
    6d73:	7f ab                	jg     6d20 <fwp_tape_finish+0x40>
    6d75:	48 8b 3d 74 93 01 00 	mov    0x19374(%rip),%rdi        # 200f0 <fwp_tapes>
    6d7c:	e8 3f c6 ff ff       	call   33c0 <free@plt>
    6d81:	5b                   	pop    %rbx
    6d82:	5d                   	pop    %rbp
    6d83:	48 c7 05 62 93 01 00 	movq   $0x0,0x19362(%rip)        # 200f0 <fwp_tapes>
    6d8a:	00 00 00 00 
    6d8e:	48 c7 05 47 93 01 00 	movq   $0x0,0x19347(%rip)        # 200e0 <fwp_tapes_cap>
    6d95:	00 00 00 00 
    6d99:	41 5c                	pop    %r12
    6d9b:	48 c7 05 42 93 01 00 	movq   $0x0,0x19342(%rip)        # 200e8 <fwp_ntapes>
    6da2:	00 00 00 00 
    6da6:	41 5d                	pop    %r13
    6da8:	48 c7 05 25 93 01 00 	movq   $0x0,0x19325(%rip)        # 200d8 <fwp_tape_next_slot>
    6daf:	00 00 00 00 
    6db3:	41 5e                	pop    %r14
    6db5:	c3                   	ret
    6db6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dbd:	00 00 00 

0000000000006dc0 <fwp_tape_scope_release>:
    6dc0:	f3 0f 1e fa          	endbr64
    6dc4:	41 55                	push   %r13
    6dc6:	41 54                	push   %r12
    6dc8:	55                   	push   %rbp
    6dc9:	53                   	push   %rbx
    6dca:	48 83 ec 58          	sub    $0x58,%rsp
    6dce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6dd5:	00 00 
    6dd7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6ddc:	48 63 07             	movslq (%rdi),%rax
    6ddf:	85 c0                	test   %eax,%eax
    6de1:	0f 88 05 01 00 00    	js     6eec <fwp_tape_scope_release+0x12c>
    6de7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6dee:	ec c4 4e 
    6df1:	48 89 fb             	mov    %rdi,%rbx
    6df4:	eb 3c                	jmp    6e32 <fwp_tape_scope_release+0x72>
    6df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dfd:	00 00 00 
    6e00:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6e05:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6e09:	e8 b2 c5 ff ff       	call   33c0 <free@plt>
    6e0e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6e12:	e8 a9 c5 ff ff       	call   33c0 <free@plt>
    6e17:	4c 89 ef             	mov    %r13,%rdi
    6e1a:	e8 a1 c5 ff ff       	call   33c0 <free@plt>
    6e1f:	4c 89 e7             	mov    %r12,%rdi
    6e22:	e8 a9 fd ff ff       	call   6bd0 <fwp_owned_tape_release>
    6e27:	48 63 03             	movslq (%rbx),%rax
    6e2a:	85 c0                	test   %eax,%eax
    6e2c:	0f 88 ba 00 00 00    	js     6eec <fwp_tape_scope_release+0x12c>
    6e32:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6e36:	48 8b 35 b3 92 01 00 	mov    0x192b3(%rip),%rsi        # 200f0 <fwp_tapes>
    6e3d:	4c 01 c6             	add    %r8,%rsi
    6e40:	48 89 f7             	mov    %rsi,%rdi
    6e43:	e8 b8 cd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6e48:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6e4d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6e52:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6e59:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6e5d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6e61:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6e68:	00 
    6e69:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6e6e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6e72:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6e77:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6e7b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6e80:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6e87:	00 
    6e88:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6e8f:	00 
    6e90:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6e97:	00 
    6e98:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6e9d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6ea2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6ea6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6eaa:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6eae:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6eb4:	77 18                	ja     6ece <fwp_tape_scope_release+0x10e>
    6eb6:	49 c1 f8 03          	sar    $0x3,%r8
    6eba:	4c 0f af c5          	imul   %rbp,%r8
    6ebe:	4c 3b 05 13 92 01 00 	cmp    0x19213(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    6ec5:	7d 07                	jge    6ece <fwp_tape_scope_release+0x10e>
    6ec7:	4c 89 05 0a 92 01 00 	mov    %r8,0x1920a(%rip)        # 200d8 <fwp_tape_next_slot>
    6ece:	4d 85 e4             	test   %r12,%r12
    6ed1:	0f 85 29 ff ff ff    	jne    6e00 <fwp_tape_scope_release+0x40>
    6ed7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6edc:	e8 4f df ff ff       	call   4e30 <fwp_tape_buffers_release>
    6ee1:	48 63 03             	movslq (%rbx),%rax
    6ee4:	85 c0                	test   %eax,%eax
    6ee6:	0f 89 46 ff ff ff    	jns    6e32 <fwp_tape_scope_release+0x72>
    6eec:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6ef1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ef8:	00 00 
    6efa:	75 0b                	jne    6f07 <fwp_tape_scope_release+0x147>
    6efc:	48 83 c4 58          	add    $0x58,%rsp
    6f00:	5b                   	pop    %rbx
    6f01:	5d                   	pop    %rbp
    6f02:	41 5c                	pop    %r12
    6f04:	41 5d                	pop    %r13
    6f06:	c3                   	ret
    6f07:	e8 54 c5 ff ff       	call   3460 <__stack_chk_fail@plt>
    6f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006f10 <fwp_task_dispose>:
    6f10:	53                   	push   %rbx
    6f11:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6f15:	0f 84 2b c8 ff ff    	je     3746 <fwp_task_dispose.cold>
    6f1b:	48 89 fb             	mov    %rdi,%rbx
    6f1e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6f23:	0f 85 1d c8 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6f29:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6f2d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6f34:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6f3b:	00 
    6f3c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6f40:	48 85 ff             	test   %rdi,%rdi
    6f43:	74 07                	je     6f4c <fwp_task_dispose+0x3c>
    6f45:	48 85 c0             	test   %rax,%rax
    6f48:	74 02                	je     6f4c <fwp_task_dispose+0x3c>
    6f4a:	ff d0                	call   *%rax
    6f4c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6f53:	e8 f8 e5 ff ff       	call   5550 <fwp_mem_free>
    6f58:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6f5f:	00 00 00 00 
    6f63:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6f67:	74 6f                	je     6fd8 <fwp_task_dispose+0xc8>
    6f69:	48 8b 15 c8 ab 01 00 	mov    0x1abc8(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6f70:	48 89 d8             	mov    %rbx,%rax
    6f73:	48 2b 05 96 ab 01 00 	sub    0x1ab96(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6f7a:	48 c1 e2 10          	shl    $0x10,%rdx
    6f7e:	48 39 d0             	cmp    %rdx,%rax
    6f81:	73 4c                	jae    6fcf <fwp_task_dispose+0xbf>
    6f83:	48 89 c2             	mov    %rax,%rdx
    6f86:	48 c1 ea 10          	shr    $0x10,%rdx
    6f8a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f8e:	48 8b 15 c3 ab 01 00 	mov    0x1abc3(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    6f95:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6f99:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6f9d:	48 85 c9             	test   %rcx,%rcx
    6fa0:	74 2d                	je     6fcf <fwp_task_dispose+0xbf>
    6fa2:	0f b6 32             	movzbl (%rdx),%esi
    6fa5:	40 80 fe 02          	cmp    $0x2,%sil
    6fa9:	74 3d                	je     6fe8 <fwp_task_dispose+0xd8>
    6fab:	40 80 fe 01          	cmp    $0x1,%sil
    6faf:	75 1e                	jne    6fcf <fwp_task_dispose+0xbf>
    6fb1:	8b 72 18             	mov    0x18(%rdx),%esi
    6fb4:	0f b7 c0             	movzwl %ax,%eax
    6fb7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6fba:	48 0f af c6          	imul   %rsi,%rax
    6fbe:	48 c1 e8 20          	shr    $0x20,%rax
    6fc2:	48 39 d0             	cmp    %rdx,%rax
    6fc5:	73 08                	jae    6fcf <fwp_task_dispose+0xbf>
    6fc7:	48 01 c1             	add    %rax,%rcx
    6fca:	80 39 01             	cmpb   $0x1,(%rcx)
    6fcd:	74 09                	je     6fd8 <fwp_task_dispose+0xc8>
    6fcf:	5b                   	pop    %rbx
    6fd0:	c3                   	ret
    6fd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fd8:	48 89 df             	mov    %rbx,%rdi
    6fdb:	5b                   	pop    %rbx
    6fdc:	e9 6f e5 ff ff       	jmp    5550 <fwp_mem_free>
    6fe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fe8:	66 85 c0             	test   %ax,%ax
    6feb:	74 dd                	je     6fca <fwp_task_dispose+0xba>
    6fed:	5b                   	pop    %rbx
    6fee:	c3                   	ret
    6fef:	90                   	nop

0000000000006ff0 <fwp_free_zombie>:
    6ff0:	48 8b 15 39 97 01 00 	mov    0x19739(%rip),%rdx        # 20730 <fwp_zombie>
    6ff7:	48 85 d2             	test   %rdx,%rdx
    6ffa:	0f 84 98 00 00 00    	je     7098 <fwp_free_zombie+0xa8>
    7000:	48 3b 15 39 97 01 00 	cmp    0x19739(%rip),%rdx        # 20740 <fwp_cur>
    7007:	0f 84 8b 00 00 00    	je     7098 <fwp_free_zombie+0xa8>
    700d:	48 83 ec 18          	sub    $0x18,%rsp
    7011:	48 63 05 f4 90 01 00 	movslq 0x190f4(%rip),%rax        # 2010c <fwp_stack_pool_n>
    7018:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    701c:	83 f8 3f             	cmp    $0x3f,%eax
    701f:	7f 7f                	jg     70a0 <fwp_free_zombie+0xb0>
    7021:	8d 48 01             	lea    0x1(%rax),%ecx
    7024:	89 0d e2 90 01 00    	mov    %ecx,0x190e2(%rip)        # 2010c <fwp_stack_pool_n>
    702a:	48 8d 0d ef 90 01 00 	lea    0x190ef(%rip),%rcx        # 20120 <fwp_stack_pool>
    7031:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7035:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    703c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7040:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7047:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    704b:	48 85 c9             	test   %rcx,%rcx
    704e:	0f 84 fc 00 00 00    	je     7150 <fwp_free_zombie+0x160>
    7054:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    705b:	48 85 c0             	test   %rax,%rax
    705e:	74 07                	je     7067 <fwp_free_zombie+0x77>
    7060:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7067:	8b 42 5c             	mov    0x5c(%rdx),%eax
    706a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    706e:	48 c7 05 b7 96 01 00 	movq   $0x0,0x196b7(%rip)        # 20730 <fwp_zombie>
    7075:	00 00 00 00 
    7079:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7080:	85 c0                	test   %eax,%eax
    7082:	74 34                	je     70b8 <fwp_free_zombie+0xc8>
    7084:	83 f8 01             	cmp    $0x1,%eax
    7087:	0f 84 b3 00 00 00    	je     7140 <fwp_free_zombie+0x150>
    708d:	48 83 c4 18          	add    $0x18,%rsp
    7091:	c3                   	ret
    7092:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7098:	c3                   	ret
    7099:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70a0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    70a4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70a9:	e8 32 c5 ff ff       	call   35e0 <munmap@plt>
    70ae:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70b3:	eb 80                	jmp    7035 <fwp_free_zombie+0x45>
    70b5:	0f 1f 00             	nopl   (%rax)
    70b8:	48 8b 0d 79 aa 01 00 	mov    0x1aa79(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    70bf:	48 89 d0             	mov    %rdx,%rax
    70c2:	48 2b 05 47 aa 01 00 	sub    0x1aa47(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    70c9:	48 c1 e1 10          	shl    $0x10,%rcx
    70cd:	48 39 c8             	cmp    %rcx,%rax
    70d0:	73 bb                	jae    708d <fwp_free_zombie+0x9d>
    70d2:	48 89 c1             	mov    %rax,%rcx
    70d5:	48 c1 e9 10          	shr    $0x10,%rcx
    70d9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    70dd:	48 8b 0d 74 aa 01 00 	mov    0x1aa74(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    70e4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    70e8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    70ec:	48 85 c9             	test   %rcx,%rcx
    70ef:	74 9c                	je     708d <fwp_free_zombie+0x9d>
    70f1:	0f b6 3e             	movzbl (%rsi),%edi
    70f4:	40 80 ff 02          	cmp    $0x2,%dil
    70f8:	74 66                	je     7160 <fwp_free_zombie+0x170>
    70fa:	40 80 ff 01          	cmp    $0x1,%dil
    70fe:	75 8d                	jne    708d <fwp_free_zombie+0x9d>
    7100:	8b 7e 18             	mov    0x18(%rsi),%edi
    7103:	0f b7 c0             	movzwl %ax,%eax
    7106:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7109:	48 0f af c7          	imul   %rdi,%rax
    710d:	48 c1 e8 20          	shr    $0x20,%rax
    7111:	48 39 f0             	cmp    %rsi,%rax
    7114:	0f 83 73 ff ff ff    	jae    708d <fwp_free_zombie+0x9d>
    711a:	48 01 c1             	add    %rax,%rcx
    711d:	0f b6 01             	movzbl (%rcx),%eax
    7120:	84 c0                	test   %al,%al
    7122:	0f 84 65 ff ff ff    	je     708d <fwp_free_zombie+0x9d>
    7128:	3c 01                	cmp    $0x1,%al
    712a:	74 14                	je     7140 <fwp_free_zombie+0x150>
    712c:	3c ff                	cmp    $0xff,%al
    712e:	74 3b                	je     716b <fwp_free_zombie+0x17b>
    7130:	83 e8 01             	sub    $0x1,%eax
    7133:	88 01                	mov    %al,(%rcx)
    7135:	e9 53 ff ff ff       	jmp    708d <fwp_free_zombie+0x9d>
    713a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7140:	48 89 d7             	mov    %rdx,%rdi
    7143:	48 83 c4 18          	add    $0x18,%rsp
    7147:	e9 c4 fd ff ff       	jmp    6f10 <fwp_task_dispose>
    714c:	0f 1f 40 00          	nopl   0x0(%rax)
    7150:	48 89 05 b1 95 01 00 	mov    %rax,0x195b1(%rip)        # 20708 <fwp_tasks_active>
    7157:	e9 ff fe ff ff       	jmp    705b <fwp_free_zombie+0x6b>
    715c:	0f 1f 40 00          	nopl   0x0(%rax)
    7160:	66 85 c0             	test   %ax,%ax
    7163:	0f 85 24 ff ff ff    	jne    708d <fwp_free_zombie+0x9d>
    7169:	eb b2                	jmp    711d <fwp_free_zombie+0x12d>
    716b:	48 89 ca             	mov    %rcx,%rdx
    716e:	48 8d 35 eb 95 01 00 	lea    0x195eb(%rip),%rsi        # 20760 <fwp_heap>
    7175:	48 c1 ea 11          	shr    $0x11,%rdx
    7179:	48 31 ca             	xor    %rcx,%rdx
    717c:	48 89 d0             	mov    %rdx,%rax
    717f:	48 c1 e8 09          	shr    $0x9,%rax
    7183:	48 31 c2             	xor    %rax,%rdx
    7186:	0f b6 d2             	movzbl %dl,%edx
    7189:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7190:	00 
    7191:	48 85 c0             	test   %rax,%rax
    7194:	75 13                	jne    71a9 <fwp_free_zombie+0x1b9>
    7196:	eb 4c                	jmp    71e4 <fwp_free_zombie+0x1f4>
    7198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    719f:	00 
    71a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    71a4:	48 85 c0             	test   %rax,%rax
    71a7:	74 3b                	je     71e4 <fwp_free_zombie+0x1f4>
    71a9:	48 89 c2             	mov    %rax,%rdx
    71ac:	48 39 08             	cmp    %rcx,(%rax)
    71af:	75 ef                	jne    71a0 <fwp_free_zombie+0x1b0>
    71b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    71b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    71bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    71c4:	0f 85 c3 fe ff ff    	jne    708d <fwp_free_zombie+0x9d>
    71ca:	48 89 cf             	mov    %rcx,%rdi
    71cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    71d2:	e8 39 e1 ff ff       	call   5310 <fwp_rc_forget_slot>
    71d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    71dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    71df:	e9 a9 fe ff ff       	jmp    708d <fwp_free_zombie+0x9d>
    71e4:	48 8d 3d ad 55 00 00 	lea    0x55ad(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    71eb:	e8 b0 cf ff ff       	call   41a0 <fwp_trap>

00000000000071f0 <fwp_block>:
    71f0:	48 83 ec 08          	sub    $0x8,%rsp
    71f4:	48 8b 05 2d 95 01 00 	mov    0x1952d(%rip),%rax        # 20728 <fwp_ready_head>
    71fb:	48 85 c0             	test   %rax,%rax
    71fe:	0f 84 1c 01 00 00    	je     7320 <fwp_block+0x130>
    7204:	90                   	nop
    7205:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    720c:	00 00 00 00 
    7210:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7217:	48 89 15 0a 95 01 00 	mov    %rdx,0x1950a(%rip)        # 20728 <fwp_ready_head>
    721e:	48 85 d2             	test   %rdx,%rdx
    7221:	0f 84 19 01 00 00    	je     7340 <fwp_block+0x150>
    7227:	48 8b 15 12 95 01 00 	mov    0x19512(%rip),%rdx        # 20740 <fwp_cur>
    722e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7232:	48 39 c2             	cmp    %rax,%rdx
    7235:	0f 84 d5 00 00 00    	je     7310 <fwp_block+0x120>
    723b:	48 8b 0d 86 b1 01 00 	mov    0x1b186(%rip),%rcx        # 223c8 <fwp_state_owners>
    7242:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7246:	48 89 05 f3 94 01 00 	mov    %rax,0x194f3(%rip)        # 20740 <fwp_cur>
    724d:	f3 0f 7e 05 9b b1 01 	movq   0x1b19b(%rip),%xmm0        # 223f0 <fwp_foreign_callbacks>
    7254:	00 
    7255:	0f 16 05 84 b1 01 00 	movhps 0x1b184(%rip),%xmm0        # 223e0 <fwp_state>
    725c:	f3 0f 7e 0d 84 b1 01 	movq   0x1b184(%rip),%xmm1        # 223e8 <fwp_handlers>
    7263:	00 
    7264:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    726b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7272:	0f 16 0d 7f b1 01 00 	movhps 0x1b17f(%rip),%xmm1        # 223f8 <fwp_cleanups>
    7279:	f3 0f 7e 05 57 b1 01 	movq   0x1b157(%rip),%xmm0        # 223d8 <fwp_state_len>
    7280:	00 
    7281:	0f 16 05 48 b1 01 00 	movhps 0x1b148(%rip),%xmm0        # 223d0 <fwp_state_cap>
    7288:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    728f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7296:	48 8b 70 08          	mov    0x8(%rax),%rsi
    729a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    72a1:	48 89 0d 40 b1 01 00 	mov    %rcx,0x1b140(%rip)        # 223e8 <fwp_handlers>
    72a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    72af:	48 89 0d 42 b1 01 00 	mov    %rcx,0x1b142(%rip)        # 223f8 <fwp_cleanups>
    72b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    72bd:	48 89 0d 2c b1 01 00 	mov    %rcx,0x1b12c(%rip)        # 223f0 <fwp_foreign_callbacks>
    72c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    72cb:	48 89 0d 0e b1 01 00 	mov    %rcx,0x1b10e(%rip)        # 223e0 <fwp_state>
    72d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    72d9:	48 89 0d f8 b0 01 00 	mov    %rcx,0x1b0f8(%rip)        # 223d8 <fwp_state_len>
    72e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    72e7:	48 89 0d e2 b0 01 00 	mov    %rcx,0x1b0e2(%rip)        # 223d0 <fwp_state_cap>
    72ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    72f5:	48 89 0d cc b0 01 00 	mov    %rcx,0x1b0cc(%rip)        # 223c8 <fwp_state_owners>
    72fc:	e8 8f c1 ff ff       	call   3490 <swapcontext@plt>
    7301:	f3 0f 1e fa          	endbr64
    7305:	e8 e6 fc ff ff       	call   6ff0 <fwp_free_zombie>
    730a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7310:	8b 05 f2 8d 01 00    	mov    0x18df2(%rip),%eax        # 20108 <fwp_slice>
    7316:	85 c0                	test   %eax,%eax
    7318:	74 36                	je     7350 <fwp_block+0x160>
    731a:	48 83 c4 08          	add    $0x8,%rsp
    731e:	c3                   	ret
    731f:	90                   	nop
    7320:	e8 3b dc ff ff       	call   4f60 <fwp_poll_events>
    7325:	48 8b 05 fc 93 01 00 	mov    0x193fc(%rip),%rax        # 20728 <fwp_ready_head>
    732c:	48 85 c0             	test   %rax,%rax
    732f:	0f 85 db fe ff ff    	jne    7210 <fwp_block+0x20>
    7335:	eb e9                	jmp    7320 <fwp_block+0x130>
    7337:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    733e:	00 00 
    7340:	48 c7 05 d5 93 01 00 	movq   $0x0,0x193d5(%rip)        # 20720 <fwp_ready_tail>
    7347:	00 00 00 00 
    734b:	e9 d7 fe ff ff       	jmp    7227 <fwp_block+0x37>
    7350:	48 8d 3d ca 4d 00 00 	lea    0x4dca(%rip),%rdi        # c121 <_IO_stdin_used+0x121>
    7357:	e8 44 c0 ff ff       	call   33a0 <getenv@plt>
    735c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7361:	48 85 c0             	test   %rax,%rax
    7364:	74 05                	je     736b <fwp_block+0x17b>
    7366:	80 38 00             	cmpb   $0x0,(%rax)
    7369:	75 0b                	jne    7376 <fwp_block+0x186>
    736b:	89 15 97 8d 01 00    	mov    %edx,0x18d97(%rip)        # 20108 <fwp_slice>
    7371:	48 83 c4 08          	add    $0x8,%rsp
    7375:	c3                   	ret
    7376:	ba 0a 00 00 00       	mov    $0xa,%edx
    737b:	31 f6                	xor    %esi,%esi
    737d:	48 89 c7             	mov    %rax,%rdi
    7380:	e8 cb c1 ff ff       	call   3550 <strtoll@plt>
    7385:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7389:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7390:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7395:	0f 46 d0             	cmovbe %eax,%edx
    7398:	eb d1                	jmp    736b <fwp_block+0x17b>
    739a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000073a0 <fwp_owned_entry161>:
    73a0:	f3 0f 1e fa          	endbr64
    73a4:	41 56                	push   %r14
    73a6:	55                   	push   %rbp
    73a7:	53                   	push   %rbx
    73a8:	48 83 ec 10          	sub    $0x10,%rsp
    73ac:	48 8b 07             	mov    (%rdi),%rax
    73af:	48 03 47 10          	add    0x10(%rdi),%rax
    73b3:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    73b8:	0f 80 b7 01 00 00    	jo     7575 <fwp_owned_entry161+0x1d5>
    73be:	49 89 c6             	mov    %rax,%r14
    73c1:	8b 05 3d a7 01 00    	mov    0x1a73d(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    73c7:	48 8d 15 92 93 01 00 	lea    0x19392(%rip),%rdx        # 20760 <fwp_heap>
    73ce:	85 c0                	test   %eax,%eax
    73d0:	0f 84 52 01 00 00    	je     7528 <fwp_owned_entry161+0x188>
    73d6:	0f b6 05 25 a3 01 00 	movzbl 0x1a325(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    73dd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    73e4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    73e8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    73ec:	48 8b 18             	mov    (%rax),%rbx
    73ef:	48 85 db             	test   %rbx,%rbx
    73f2:	0f 84 08 01 00 00    	je     7500 <fwp_owned_entry161+0x160>
    73f8:	48 8b 13             	mov    (%rbx),%rdx
    73fb:	48 f7 d2             	not    %rdx
    73fe:	48 89 10             	mov    %rdx,(%rax)
    7401:	48 83 fd 18          	cmp    $0x18,%rbp
    7405:	76 27                	jbe    742e <fwp_owned_entry161+0x8e>
    7407:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    740b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    740f:	31 f6                	xor    %esi,%esi
    7411:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7417:	48 c1 e8 03          	shr    $0x3,%rax
    741b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7422:	00 
    7423:	e8 98 c0 ff ff       	call   34c0 <memset@plt>
    7428:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    742e:	48 89 e8             	mov    %rbp,%rax
    7431:	48 03 05 48 a7 01 00 	add    0x1a748(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    7438:	0f 82 3c 01 00 00    	jb     757a <fwp_owned_entry161+0x1da>
    743e:	48 39 05 43 a7 01 00 	cmp    %rax,0x1a743(%rip)        # 21b88 <fwp_heap+0x1428>
    7445:	48 89 05 34 a7 01 00 	mov    %rax,0x1a734(%rip)        # 21b80 <fwp_heap+0x1420>
    744c:	73 07                	jae    7455 <fwp_owned_entry161+0xb5>
    744e:	48 89 05 33 a7 01 00 	mov    %rax,0x1a733(%rip)        # 21b88 <fwp_heap+0x1428>
    7455:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7459:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    745e:	f2 0f 58 0d 32 a7 01 	addsd  0x1a732(%rip),%xmm1        # 21b98 <fwp_heap+0x1438>
    7465:	00 
    7466:	f2 0f 11 0d 2a a7 01 	movsd  %xmm1,0x1a72a(%rip)        # 21b98 <fwp_heap+0x1438>
    746d:	00 
    746e:	48 8b 05 cb 56 00 00 	mov    0x56cb(%rip),%rax        # cb40 <msg.4+0xc0>
    7475:	66 49 0f 6e d6       	movq   %r14,%xmm2
    747a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    747e:	48 89 03             	mov    %rax,(%rbx)
    7481:	48 89 d8             	mov    %rbx,%rax
    7484:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7488:	48 8b 15 a9 a6 01 00 	mov    0x1a6a9(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    748f:	48 2b 05 7a a6 01 00 	sub    0x1a67a(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7496:	48 c1 e2 10          	shl    $0x10,%rdx
    749a:	48 39 d0             	cmp    %rdx,%rax
    749d:	73 53                	jae    74f2 <fwp_owned_entry161+0x152>
    749f:	48 89 c2             	mov    %rax,%rdx
    74a2:	48 c1 ea 10          	shr    $0x10,%rdx
    74a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74aa:	48 8b 15 a7 a6 01 00 	mov    0x1a6a7(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    74b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74b5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    74b9:	48 85 ed             	test   %rbp,%rbp
    74bc:	74 34                	je     74f2 <fwp_owned_entry161+0x152>
    74be:	0f b6 0a             	movzbl (%rdx),%ecx
    74c1:	80 f9 02             	cmp    $0x2,%cl
    74c4:	0f 84 86 00 00 00    	je     7550 <fwp_owned_entry161+0x1b0>
    74ca:	80 f9 01             	cmp    $0x1,%cl
    74cd:	75 23                	jne    74f2 <fwp_owned_entry161+0x152>
    74cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    74d2:	0f b7 c0             	movzwl %ax,%eax
    74d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74d8:	48 0f af c1          	imul   %rcx,%rax
    74dc:	48 c1 e8 20          	shr    $0x20,%rax
    74e0:	48 39 d0             	cmp    %rdx,%rax
    74e3:	73 0d                	jae    74f2 <fwp_owned_entry161+0x152>
    74e5:	48 01 c5             	add    %rax,%rbp
    74e8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    74ec:	74 7a                	je     7568 <fwp_owned_entry161+0x1c8>
    74ee:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    74f2:	48 83 c4 10          	add    $0x10,%rsp
    74f6:	48 89 d8             	mov    %rbx,%rax
    74f9:	5b                   	pop    %rbx
    74fa:	5d                   	pop    %rbp
    74fb:	41 5e                	pop    %r14
    74fd:	c3                   	ret
    74fe:	66 90                	xchg   %ax,%ax
    7500:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7504:	48 85 db             	test   %rbx,%rbx
    7507:	74 1f                	je     7528 <fwp_owned_entry161+0x188>
    7509:	48 8b 50 10          	mov    0x10(%rax),%rdx
    750d:	48 29 da             	sub    %rbx,%rdx
    7510:	48 39 ea             	cmp    %rbp,%rdx
    7513:	72 13                	jb     7528 <fwp_owned_entry161+0x188>
    7515:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7519:	48 89 50 08          	mov    %rdx,0x8(%rax)
    751d:	e9 df fe ff ff       	jmp    7401 <fwp_owned_entry161+0x61>
    7522:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7528:	31 f6                	xor    %esi,%esi
    752a:	bf 18 00 00 00       	mov    $0x18,%edi
    752f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7535:	e8 16 e5 ff ff       	call   5a50 <fwp_heap_alloc>
    753a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7540:	48 89 c3             	mov    %rax,%rbx
    7543:	e9 26 ff ff ff       	jmp    746e <fwp_owned_entry161+0xce>
    7548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    754f:	00 
    7550:	66 85 c0             	test   %ax,%ax
    7553:	74 93                	je     74e8 <fwp_owned_entry161+0x148>
    7555:	48 83 c4 10          	add    $0x10,%rsp
    7559:	48 89 d8             	mov    %rbx,%rax
    755c:	5b                   	pop    %rbx
    755d:	5d                   	pop    %rbp
    755e:	41 5e                	pop    %r14
    7560:	c3                   	ret
    7561:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7568:	48 89 ef             	mov    %rbp,%rdi
    756b:	e8 a0 dd ff ff       	call   5310 <fwp_rc_forget_slot>
    7570:	e9 79 ff ff ff       	jmp    74ee <fwp_owned_entry161+0x14e>
    7575:	e8 86 c1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    757a:	e8 31 c7 ff ff       	call   3cb0 <fwp_heap_oom>
    757f:	90                   	nop

0000000000007580 <e161>:
    7580:	f3 0f 1e fa          	endbr64
    7584:	41 56                	push   %r14
    7586:	55                   	push   %rbp
    7587:	53                   	push   %rbx
    7588:	48 83 ec 10          	sub    $0x10,%rsp
    758c:	48 8b 07             	mov    (%rdi),%rax
    758f:	48 03 47 10          	add    0x10(%rdi),%rax
    7593:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7598:	0f 80 bf 01 00 00    	jo     775d <e161+0x1dd>
    759e:	49 89 c6             	mov    %rax,%r14
    75a1:	8b 05 5d a5 01 00    	mov    0x1a55d(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    75a7:	48 8d 15 b2 91 01 00 	lea    0x191b2(%rip),%rdx        # 20760 <fwp_heap>
    75ae:	85 c0                	test   %eax,%eax
    75b0:	0f 84 62 01 00 00    	je     7718 <e161+0x198>
    75b6:	0f b6 05 45 a1 01 00 	movzbl 0x1a145(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    75bd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    75c4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    75c8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    75cc:	48 8b 18             	mov    (%rax),%rbx
    75cf:	48 85 db             	test   %rbx,%rbx
    75d2:	0f 84 18 01 00 00    	je     76f0 <e161+0x170>
    75d8:	48 8b 13             	mov    (%rbx),%rdx
    75db:	48 f7 d2             	not    %rdx
    75de:	48 89 10             	mov    %rdx,(%rax)
    75e1:	48 83 fd 18          	cmp    $0x18,%rbp
    75e5:	76 27                	jbe    760e <e161+0x8e>
    75e7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    75eb:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    75ef:	31 f6                	xor    %esi,%esi
    75f1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    75f7:	48 c1 e8 03          	shr    $0x3,%rax
    75fb:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7602:	00 
    7603:	e8 b8 be ff ff       	call   34c0 <memset@plt>
    7608:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    760e:	48 89 e8             	mov    %rbp,%rax
    7611:	48 03 05 68 a5 01 00 	add    0x1a568(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    7618:	0f 82 44 01 00 00    	jb     7762 <e161+0x1e2>
    761e:	48 39 05 63 a5 01 00 	cmp    %rax,0x1a563(%rip)        # 21b88 <fwp_heap+0x1428>
    7625:	48 89 05 54 a5 01 00 	mov    %rax,0x1a554(%rip)        # 21b80 <fwp_heap+0x1420>
    762c:	73 07                	jae    7635 <e161+0xb5>
    762e:	48 89 05 53 a5 01 00 	mov    %rax,0x1a553(%rip)        # 21b88 <fwp_heap+0x1428>
    7635:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7639:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    763e:	f2 0f 58 0d 52 a5 01 	addsd  0x1a552(%rip),%xmm1        # 21b98 <fwp_heap+0x1438>
    7645:	00 
    7646:	f2 0f 11 0d 4a a5 01 	movsd  %xmm1,0x1a54a(%rip)        # 21b98 <fwp_heap+0x1438>
    764d:	00 
    764e:	48 8b 05 eb 54 00 00 	mov    0x54eb(%rip),%rax        # cb40 <msg.4+0xc0>
    7655:	66 49 0f 6e d6       	movq   %r14,%xmm2
    765a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    765e:	48 89 03             	mov    %rax,(%rbx)
    7661:	48 89 d8             	mov    %rbx,%rax
    7664:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7668:	48 8b 15 c9 a4 01 00 	mov    0x1a4c9(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    766f:	48 2b 05 9a a4 01 00 	sub    0x1a49a(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7676:	48 c1 e2 10          	shl    $0x10,%rdx
    767a:	48 39 d0             	cmp    %rdx,%rax
    767d:	73 57                	jae    76d6 <e161+0x156>
    767f:	48 89 c2             	mov    %rax,%rdx
    7682:	48 c1 ea 10          	shr    $0x10,%rdx
    7686:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    768a:	48 8b 15 c7 a4 01 00 	mov    0x1a4c7(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7691:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7695:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7699:	48 85 ed             	test   %rbp,%rbp
    769c:	74 38                	je     76d6 <e161+0x156>
    769e:	0f b6 0a             	movzbl (%rdx),%ecx
    76a1:	80 f9 02             	cmp    $0x2,%cl
    76a4:	0f 84 96 00 00 00    	je     7740 <e161+0x1c0>
    76aa:	80 f9 01             	cmp    $0x1,%cl
    76ad:	75 27                	jne    76d6 <e161+0x156>
    76af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    76b2:	0f b7 c0             	movzwl %ax,%eax
    76b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    76b8:	48 0f af c1          	imul   %rcx,%rax
    76bc:	48 c1 e8 20          	shr    $0x20,%rax
    76c0:	48 39 d0             	cmp    %rdx,%rax
    76c3:	73 11                	jae    76d6 <e161+0x156>
    76c5:	48 01 c5             	add    %rax,%rbp
    76c8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    76cc:	0f 84 7e 00 00 00    	je     7750 <e161+0x1d0>
    76d2:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    76d6:	48 89 df             	mov    %rbx,%rdi
    76d9:	e8 42 ef ff ff       	call   6620 <fwp_rc_share>
    76de:	48 83 c4 10          	add    $0x10,%rsp
    76e2:	48 89 d8             	mov    %rbx,%rax
    76e5:	5b                   	pop    %rbx
    76e6:	5d                   	pop    %rbp
    76e7:	41 5e                	pop    %r14
    76e9:	c3                   	ret
    76ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76f0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    76f4:	48 85 db             	test   %rbx,%rbx
    76f7:	74 1f                	je     7718 <e161+0x198>
    76f9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    76fd:	48 29 da             	sub    %rbx,%rdx
    7700:	48 39 ea             	cmp    %rbp,%rdx
    7703:	72 13                	jb     7718 <e161+0x198>
    7705:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7709:	48 89 50 08          	mov    %rdx,0x8(%rax)
    770d:	e9 cf fe ff ff       	jmp    75e1 <e161+0x61>
    7712:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7718:	31 f6                	xor    %esi,%esi
    771a:	bf 18 00 00 00       	mov    $0x18,%edi
    771f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7725:	e8 26 e3 ff ff       	call   5a50 <fwp_heap_alloc>
    772a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7730:	48 89 c3             	mov    %rax,%rbx
    7733:	e9 16 ff ff ff       	jmp    764e <e161+0xce>
    7738:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    773f:	00 
    7740:	66 85 c0             	test   %ax,%ax
    7743:	75 91                	jne    76d6 <e161+0x156>
    7745:	eb 81                	jmp    76c8 <e161+0x148>
    7747:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    774e:	00 00 
    7750:	48 89 ef             	mov    %rbp,%rdi
    7753:	e8 b8 db ff ff       	call   5310 <fwp_rc_forget_slot>
    7758:	e9 75 ff ff ff       	jmp    76d2 <e161+0x152>
    775d:	e8 9e bf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7762:	e8 49 c5 ff ff       	call   3cb0 <fwp_heap_oom>
    7767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    776e:	00 00 

0000000000007770 <fwp_drop4>:
    7770:	48 8b 15 c1 a3 01 00 	mov    0x1a3c1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7777:	48 89 f8             	mov    %rdi,%rax
    777a:	48 2b 05 8f a3 01 00 	sub    0x1a38f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7781:	48 c1 e2 10          	shl    $0x10,%rdx
    7785:	48 39 d0             	cmp    %rdx,%rax
    7788:	0f 83 52 01 00 00    	jae    78e0 <fwp_drop4+0x170>
    778e:	48 83 ec 18          	sub    $0x18,%rsp
    7792:	4c 8d 05 c7 8f 01 00 	lea    0x18fc7(%rip),%r8        # 20760 <fwp_heap>
    7799:	48 89 c2             	mov    %rax,%rdx
    779c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    77a3:	48 c1 ea 10          	shr    $0x10,%rdx
    77a7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    77ab:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    77af:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    77b3:	48 85 d2             	test   %rdx,%rdx
    77b6:	74 46                	je     77fe <fwp_drop4+0x8e>
    77b8:	44 0f b6 09          	movzbl (%rcx),%r9d
    77bc:	41 80 f9 02          	cmp    $0x2,%r9b
    77c0:	0f 84 ca 00 00 00    	je     7890 <fwp_drop4+0x120>
    77c6:	41 80 f9 01          	cmp    $0x1,%r9b
    77ca:	75 32                	jne    77fe <fwp_drop4+0x8e>
    77cc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    77d0:	0f b7 c0             	movzwl %ax,%eax
    77d3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    77d6:	49 0f af c1          	imul   %r9,%rax
    77da:	48 c1 e8 20          	shr    $0x20,%rax
    77de:	48 39 c8             	cmp    %rcx,%rax
    77e1:	73 1b                	jae    77fe <fwp_drop4+0x8e>
    77e3:	48 01 c2             	add    %rax,%rdx
    77e6:	0f b6 02             	movzbl (%rdx),%eax
    77e9:	84 c0                	test   %al,%al
    77eb:	74 11                	je     77fe <fwp_drop4+0x8e>
    77ed:	3c 01                	cmp    $0x1,%al
    77ef:	74 17                	je     7808 <fwp_drop4+0x98>
    77f1:	3c ff                	cmp    $0xff,%al
    77f3:	0f 84 ef 00 00 00    	je     78e8 <fwp_drop4+0x178>
    77f9:	83 e8 01             	sub    $0x1,%eax
    77fc:	88 02                	mov    %al,(%rdx)
    77fe:	48 83 c4 18          	add    $0x18,%rsp
    7802:	c3                   	ret
    7803:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7808:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    780c:	0f 88 8e 00 00 00    	js     78a0 <fwp_drop4+0x130>
    7812:	48 8b 15 1f a3 01 00 	mov    0x1a31f(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7819:	48 89 f8             	mov    %rdi,%rax
    781c:	48 2b 05 ed a2 01 00 	sub    0x1a2ed(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7823:	48 c1 e2 10          	shl    $0x10,%rdx
    7827:	48 39 d0             	cmp    %rdx,%rax
    782a:	73 d2                	jae    77fe <fwp_drop4+0x8e>
    782c:	48 89 c2             	mov    %rax,%rdx
    782f:	48 c1 ea 10          	shr    $0x10,%rdx
    7833:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7837:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    783b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    783f:	48 85 c9             	test   %rcx,%rcx
    7842:	74 ba                	je     77fe <fwp_drop4+0x8e>
    7844:	0f b6 32             	movzbl (%rdx),%esi
    7847:	40 80 fe 02          	cmp    $0x2,%sil
    784b:	74 33                	je     7880 <fwp_drop4+0x110>
    784d:	40 80 fe 01          	cmp    $0x1,%sil
    7851:	75 ab                	jne    77fe <fwp_drop4+0x8e>
    7853:	8b 72 18             	mov    0x18(%rdx),%esi
    7856:	0f b7 c0             	movzwl %ax,%eax
    7859:	8b 52 1c             	mov    0x1c(%rdx),%edx
    785c:	48 0f af c6          	imul   %rsi,%rax
    7860:	48 c1 e8 20          	shr    $0x20,%rax
    7864:	48 39 d0             	cmp    %rdx,%rax
    7867:	73 95                	jae    77fe <fwp_drop4+0x8e>
    7869:	48 01 c1             	add    %rax,%rcx
    786c:	80 39 01             	cmpb   $0x1,(%rcx)
    786f:	75 8d                	jne    77fe <fwp_drop4+0x8e>
    7871:	48 83 c4 18          	add    $0x18,%rsp
    7875:	e9 d6 dc ff ff       	jmp    5550 <fwp_mem_free>
    787a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7880:	66 85 c0             	test   %ax,%ax
    7883:	74 e7                	je     786c <fwp_drop4+0xfc>
    7885:	48 83 c4 18          	add    $0x18,%rsp
    7889:	c3                   	ret
    788a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7890:	66 85 c0             	test   %ax,%ax
    7893:	0f 84 4d ff ff ff    	je     77e6 <fwp_drop4+0x76>
    7899:	48 83 c4 18          	add    $0x18,%rsp
    789d:	c3                   	ret
    789e:	66 90                	xchg   %ax,%ax
    78a0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    78a4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    78a9:	e8 f2 ed ff ff       	call   66a0 <fwp_rc_free_arr>
    78ae:	4c 8d 05 ab 8e 01 00 	lea    0x18eab(%rip),%r8        # 20760 <fwp_heap>
    78b5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    78ba:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    78c1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    78c8:	48 c1 e2 10          	shl    $0x10,%rdx
    78cc:	48 39 d0             	cmp    %rdx,%rax
    78cf:	0f 83 29 ff ff ff    	jae    77fe <fwp_drop4+0x8e>
    78d5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    78da:	e9 ba fe ff ff       	jmp    7799 <fwp_drop4+0x29>
    78df:	90                   	nop
    78e0:	c3                   	ret
    78e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78e8:	48 89 d0             	mov    %rdx,%rax
    78eb:	48 c1 e8 11          	shr    $0x11,%rax
    78ef:	48 31 d0             	xor    %rdx,%rax
    78f2:	48 89 c1             	mov    %rax,%rcx
    78f5:	48 c1 e9 09          	shr    $0x9,%rcx
    78f9:	48 31 c8             	xor    %rcx,%rax
    78fc:	0f b6 c8             	movzbl %al,%ecx
    78ff:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7906:	00 
    7907:	48 85 c0             	test   %rax,%rax
    790a:	75 1d                	jne    7929 <fwp_drop4+0x1b9>
    790c:	eb 56                	jmp    7964 <fwp_drop4+0x1f4>
    790e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    791c:	00 00 00 00 
    7920:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7924:	48 85 c0             	test   %rax,%rax
    7927:	74 3b                	je     7964 <fwp_drop4+0x1f4>
    7929:	48 89 c1             	mov    %rax,%rcx
    792c:	48 39 10             	cmp    %rdx,(%rax)
    792f:	75 ef                	jne    7920 <fwp_drop4+0x1b0>
    7931:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7935:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7939:	48 89 48 08          	mov    %rcx,0x8(%rax)
    793d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7944:	0f 85 b4 fe ff ff    	jne    77fe <fwp_drop4+0x8e>
    794a:	48 89 d7             	mov    %rdx,%rdi
    794d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7952:	e8 b9 d9 ff ff       	call   5310 <fwp_rc_forget_slot>
    7957:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    795c:	c6 02 fe             	movb   $0xfe,(%rdx)
    795f:	e9 9a fe ff ff       	jmp    77fe <fwp_drop4+0x8e>
    7964:	48 8d 3d 2d 4e 00 00 	lea    0x4e2d(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    796b:	e8 30 c8 ff ff       	call   41a0 <fwp_trap>

0000000000007970 <fwp_caps161>:
    7970:	f3 0f 1e fa          	endbr64
    7974:	85 f6                	test   %esi,%esi
    7976:	74 08                	je     7980 <fwp_caps161+0x10>
    7978:	c3                   	ret
    7979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7980:	48 8b 15 b1 a1 01 00 	mov    0x1a1b1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7987:	48 89 f8             	mov    %rdi,%rax
    798a:	48 2b 05 7f a1 01 00 	sub    0x1a17f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7991:	48 c1 e2 10          	shl    $0x10,%rdx
    7995:	48 39 d0             	cmp    %rdx,%rax
    7998:	73 de                	jae    7978 <fwp_caps161+0x8>
    799a:	48 89 c2             	mov    %rax,%rdx
    799d:	48 c1 ea 10          	shr    $0x10,%rdx
    79a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    79a5:	48 8b 15 ac a1 01 00 	mov    0x1a1ac(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    79ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    79b0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    79b4:	48 85 c9             	test   %rcx,%rcx
    79b7:	74 bf                	je     7978 <fwp_caps161+0x8>
    79b9:	0f b6 32             	movzbl (%rdx),%esi
    79bc:	40 80 fe 02          	cmp    $0x2,%sil
    79c0:	74 2e                	je     79f0 <fwp_caps161+0x80>
    79c2:	40 80 fe 01          	cmp    $0x1,%sil
    79c6:	75 b0                	jne    7978 <fwp_caps161+0x8>
    79c8:	8b 72 18             	mov    0x18(%rdx),%esi
    79cb:	0f b7 c0             	movzwl %ax,%eax
    79ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79d1:	48 0f af c6          	imul   %rsi,%rax
    79d5:	48 c1 e8 20          	shr    $0x20,%rax
    79d9:	48 39 d0             	cmp    %rdx,%rax
    79dc:	73 9a                	jae    7978 <fwp_caps161+0x8>
    79de:	48 01 c1             	add    %rax,%rcx
    79e1:	80 39 01             	cmpb   $0x1,(%rcx)
    79e4:	75 92                	jne    7978 <fwp_caps161+0x8>
    79e6:	e9 65 db ff ff       	jmp    5550 <fwp_mem_free>
    79eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    79f0:	66 85 c0             	test   %ax,%ax
    79f3:	74 ec                	je     79e1 <fwp_caps161+0x71>
    79f5:	c3                   	ret
    79f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    79fd:	00 00 00 

0000000000007a00 <fwp_args12>:
    7a00:	f3 0f 1e fa          	endbr64
    7a04:	85 d2                	test   %edx,%edx
    7a06:	74 04                	je     7a0c <fwp_args12+0xc>
    7a08:	85 f6                	test   %esi,%esi
    7a0a:	74 04                	je     7a10 <fwp_args12+0x10>
    7a0c:	c3                   	ret
    7a0d:	0f 1f 00             	nopl   (%rax)
    7a10:	48 8b 15 21 a1 01 00 	mov    0x1a121(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7a17:	48 8b 07             	mov    (%rdi),%rax
    7a1a:	48 2b 05 ef a0 01 00 	sub    0x1a0ef(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7a21:	48 c1 e2 10          	shl    $0x10,%rdx
    7a25:	48 39 d0             	cmp    %rdx,%rax
    7a28:	73 e2                	jae    7a0c <fwp_args12+0xc>
    7a2a:	48 89 c2             	mov    %rax,%rdx
    7a2d:	48 c1 ea 10          	shr    $0x10,%rdx
    7a31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a35:	48 8b 15 1c a1 01 00 	mov    0x1a11c(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7a3c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a40:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7a44:	48 85 ff             	test   %rdi,%rdi
    7a47:	74 c3                	je     7a0c <fwp_args12+0xc>
    7a49:	0f b6 0a             	movzbl (%rdx),%ecx
    7a4c:	80 f9 02             	cmp    $0x2,%cl
    7a4f:	74 2f                	je     7a80 <fwp_args12+0x80>
    7a51:	80 f9 01             	cmp    $0x1,%cl
    7a54:	75 b6                	jne    7a0c <fwp_args12+0xc>
    7a56:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a59:	0f b7 c0             	movzwl %ax,%eax
    7a5c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a5f:	48 0f af c1          	imul   %rcx,%rax
    7a63:	48 c1 e8 20          	shr    $0x20,%rax
    7a67:	48 39 d0             	cmp    %rdx,%rax
    7a6a:	73 a0                	jae    7a0c <fwp_args12+0xc>
    7a6c:	48 01 c7             	add    %rax,%rdi
    7a6f:	0f b6 07             	movzbl (%rdi),%eax
    7a72:	84 c0                	test   %al,%al
    7a74:	74 96                	je     7a0c <fwp_args12+0xc>
    7a76:	3c fd                	cmp    $0xfd,%al
    7a78:	77 0c                	ja     7a86 <fwp_args12+0x86>
    7a7a:	83 c0 01             	add    $0x1,%eax
    7a7d:	88 07                	mov    %al,(%rdi)
    7a7f:	c3                   	ret
    7a80:	66 85 c0             	test   %ax,%ax
    7a83:	74 ea                	je     7a6f <fwp_args12+0x6f>
    7a85:	c3                   	ret
    7a86:	e9 65 d7 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7a8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007a90 <fwp_args23>:
    7a90:	f3 0f 1e fa          	endbr64
    7a94:	85 d2                	test   %edx,%edx
    7a96:	74 04                	je     7a9c <fwp_args23+0xc>
    7a98:	85 f6                	test   %esi,%esi
    7a9a:	74 04                	je     7aa0 <fwp_args23+0x10>
    7a9c:	c3                   	ret
    7a9d:	0f 1f 00             	nopl   (%rax)
    7aa0:	48 8b 15 91 a0 01 00 	mov    0x1a091(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7aa7:	48 8b 07             	mov    (%rdi),%rax
    7aaa:	48 2b 05 5f a0 01 00 	sub    0x1a05f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7ab1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ab5:	48 39 d0             	cmp    %rdx,%rax
    7ab8:	73 e2                	jae    7a9c <fwp_args23+0xc>
    7aba:	48 89 c2             	mov    %rax,%rdx
    7abd:	48 c1 ea 10          	shr    $0x10,%rdx
    7ac1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ac5:	48 8b 15 8c a0 01 00 	mov    0x1a08c(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7acc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ad0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ad4:	48 85 ff             	test   %rdi,%rdi
    7ad7:	74 c3                	je     7a9c <fwp_args23+0xc>
    7ad9:	0f b6 0a             	movzbl (%rdx),%ecx
    7adc:	80 f9 02             	cmp    $0x2,%cl
    7adf:	74 2f                	je     7b10 <fwp_args23+0x80>
    7ae1:	80 f9 01             	cmp    $0x1,%cl
    7ae4:	75 b6                	jne    7a9c <fwp_args23+0xc>
    7ae6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ae9:	0f b7 c0             	movzwl %ax,%eax
    7aec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aef:	48 0f af c1          	imul   %rcx,%rax
    7af3:	48 c1 e8 20          	shr    $0x20,%rax
    7af7:	48 39 d0             	cmp    %rdx,%rax
    7afa:	73 a0                	jae    7a9c <fwp_args23+0xc>
    7afc:	48 01 c7             	add    %rax,%rdi
    7aff:	0f b6 07             	movzbl (%rdi),%eax
    7b02:	84 c0                	test   %al,%al
    7b04:	74 96                	je     7a9c <fwp_args23+0xc>
    7b06:	3c fd                	cmp    $0xfd,%al
    7b08:	77 0c                	ja     7b16 <fwp_args23+0x86>
    7b0a:	83 c0 01             	add    $0x1,%eax
    7b0d:	88 07                	mov    %al,(%rdi)
    7b0f:	c3                   	ret
    7b10:	66 85 c0             	test   %ax,%ax
    7b13:	74 ea                	je     7aff <fwp_args23+0x6f>
    7b15:	c3                   	ret
    7b16:	e9 d5 d6 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7b1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007b20 <fwp_caps12>:
    7b20:	f3 0f 1e fa          	endbr64
    7b24:	48 83 ec 18          	sub    $0x18,%rsp
    7b28:	8b 57 04             	mov    0x4(%rdi),%edx
    7b2b:	48 89 f8             	mov    %rdi,%rax
    7b2e:	85 d2                	test   %edx,%edx
    7b30:	0f 84 9a 00 00 00    	je     7bd0 <fwp_caps12+0xb0>
    7b36:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7b3a:	85 f6                	test   %esi,%esi
    7b3c:	0f 85 9e 00 00 00    	jne    7be0 <fwp_caps12+0xc0>
    7b42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7b47:	e8 64 ec ff ff       	call   67b0 <fwp_drop0>
    7b4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b51:	48 8b 0d e0 9f 01 00 	mov    0x19fe0(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    7b58:	48 89 c2             	mov    %rax,%rdx
    7b5b:	48 2b 15 ae 9f 01 00 	sub    0x19fae(%rip),%rdx        # 21b10 <fwp_heap+0x13b0>
    7b62:	48 c1 e1 10          	shl    $0x10,%rcx
    7b66:	48 39 ca             	cmp    %rcx,%rdx
    7b69:	73 6d                	jae    7bd8 <fwp_caps12+0xb8>
    7b6b:	48 89 d1             	mov    %rdx,%rcx
    7b6e:	48 c1 e9 10          	shr    $0x10,%rcx
    7b72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7b76:	48 8b 0d db 9f 01 00 	mov    0x19fdb(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    7b7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7b81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7b85:	48 85 f6             	test   %rsi,%rsi
    7b88:	74 4e                	je     7bd8 <fwp_caps12+0xb8>
    7b8a:	0f b6 39             	movzbl (%rcx),%edi
    7b8d:	40 80 ff 02          	cmp    $0x2,%dil
    7b91:	0f 84 b9 00 00 00    	je     7c50 <fwp_caps12+0x130>
    7b97:	40 80 ff 01          	cmp    $0x1,%dil
    7b9b:	75 3b                	jne    7bd8 <fwp_caps12+0xb8>
    7b9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7ba0:	0f b7 d2             	movzwl %dx,%edx
    7ba3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ba6:	48 0f af d7          	imul   %rdi,%rdx
    7baa:	48 c1 ea 20          	shr    $0x20,%rdx
    7bae:	48 39 ca             	cmp    %rcx,%rdx
    7bb1:	73 25                	jae    7bd8 <fwp_caps12+0xb8>
    7bb3:	48 01 d6             	add    %rdx,%rsi
    7bb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7bb9:	75 1d                	jne    7bd8 <fwp_caps12+0xb8>
    7bbb:	48 89 c7             	mov    %rax,%rdi
    7bbe:	48 83 c4 18          	add    $0x18,%rsp
    7bc2:	e9 89 d9 ff ff       	jmp    5550 <fwp_mem_free>
    7bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bce:	00 00 
    7bd0:	85 f6                	test   %esi,%esi
    7bd2:	0f 84 79 ff ff ff    	je     7b51 <fwp_caps12+0x31>
    7bd8:	48 83 c4 18          	add    $0x18,%rsp
    7bdc:	c3                   	ret
    7bdd:	0f 1f 00             	nopl   (%rax)
    7be0:	48 8b 05 51 9f 01 00 	mov    0x19f51(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    7be7:	48 2b 3d 22 9f 01 00 	sub    0x19f22(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    7bee:	48 c1 e0 10          	shl    $0x10,%rax
    7bf2:	48 39 c7             	cmp    %rax,%rdi
    7bf5:	73 e1                	jae    7bd8 <fwp_caps12+0xb8>
    7bf7:	48 89 f8             	mov    %rdi,%rax
    7bfa:	48 c1 e8 10          	shr    $0x10,%rax
    7bfe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7c02:	48 8b 05 4f 9f 01 00 	mov    0x19f4f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    7c09:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7c0d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7c11:	48 85 c0             	test   %rax,%rax
    7c14:	74 c2                	je     7bd8 <fwp_caps12+0xb8>
    7c16:	0f b6 0a             	movzbl (%rdx),%ecx
    7c19:	80 f9 02             	cmp    $0x2,%cl
    7c1c:	74 42                	je     7c60 <fwp_caps12+0x140>
    7c1e:	80 f9 01             	cmp    $0x1,%cl
    7c21:	75 b5                	jne    7bd8 <fwp_caps12+0xb8>
    7c23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c26:	0f b7 ff             	movzwl %di,%edi
    7c29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c2c:	48 0f af f9          	imul   %rcx,%rdi
    7c30:	48 c1 ef 20          	shr    $0x20,%rdi
    7c34:	48 39 d7             	cmp    %rdx,%rdi
    7c37:	73 9f                	jae    7bd8 <fwp_caps12+0xb8>
    7c39:	48 01 f8             	add    %rdi,%rax
    7c3c:	0f b6 10             	movzbl (%rax),%edx
    7c3f:	84 d2                	test   %dl,%dl
    7c41:	74 95                	je     7bd8 <fwp_caps12+0xb8>
    7c43:	80 fa fd             	cmp    $0xfd,%dl
    7c46:	77 23                	ja     7c6b <fwp_caps12+0x14b>
    7c48:	83 c2 01             	add    $0x1,%edx
    7c4b:	88 10                	mov    %dl,(%rax)
    7c4d:	eb 89                	jmp    7bd8 <fwp_caps12+0xb8>
    7c4f:	90                   	nop
    7c50:	66 85 d2             	test   %dx,%dx
    7c53:	0f 85 7f ff ff ff    	jne    7bd8 <fwp_caps12+0xb8>
    7c59:	e9 58 ff ff ff       	jmp    7bb6 <fwp_caps12+0x96>
    7c5e:	66 90                	xchg   %ax,%ax
    7c60:	66 85 ff             	test   %di,%di
    7c63:	0f 85 6f ff ff ff    	jne    7bd8 <fwp_caps12+0xb8>
    7c69:	eb d1                	jmp    7c3c <fwp_caps12+0x11c>
    7c6b:	48 89 c7             	mov    %rax,%rdi
    7c6e:	48 83 c4 18          	add    $0x18,%rsp
    7c72:	e9 79 d5 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c7e:	00 00 

0000000000007c80 <f12>:
    7c80:	41 57                	push   %r15
    7c82:	41 56                	push   %r14
    7c84:	41 55                	push   %r13
    7c86:	4c 8d 2d 33 f1 ff ff 	lea    -0xecd(%rip),%r13        # 6dc0 <fwp_tape_scope_release>
    7c8d:	41 54                	push   %r12
    7c8f:	55                   	push   %rbp
    7c90:	53                   	push   %rbx
    7c91:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
    7c98:	48 8b 15 99 9e 01 00 	mov    0x19e99(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7c9f:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    7ca4:	4c 8d 74 24 5c       	lea    0x5c(%rsp),%r14
    7ca9:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
    7cae:	48 c1 e2 10          	shl    $0x10,%rdx
    7cb2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7cb9:	00 00 
    7cbb:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    7cc2:	00 
    7cc3:	31 c0                	xor    %eax,%eax
    7cc5:	48 8b 05 2c a7 01 00 	mov    0x1a72c(%rip),%rax        # 223f8 <fwp_cleanups>
    7ccc:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7cd3:	ff 
    7cd4:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    7cd9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7cde:	48 8d 05 2b 83 00 00 	lea    0x832b(%rip),%rax        # 10010 <fc23>
    7ce5:	48 2b 05 24 9e 01 00 	sub    0x19e24(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7cec:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
    7cf1:	4c 89 3d 00 a7 01 00 	mov    %r15,0x1a700(%rip)        # 223f8 <fwp_cleanups>
    7cf8:	48 39 d0             	cmp    %rdx,%rax
    7cfb:	73 5d                	jae    7d5a <f12+0xda>
    7cfd:	48 89 c2             	mov    %rax,%rdx
    7d00:	48 c1 ea 10          	shr    $0x10,%rdx
    7d04:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d08:	48 8b 15 49 9e 01 00 	mov    0x19e49(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7d0f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d13:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d17:	48 85 ff             	test   %rdi,%rdi
    7d1a:	74 3e                	je     7d5a <f12+0xda>
    7d1c:	0f b6 0a             	movzbl (%rdx),%ecx
    7d1f:	80 f9 02             	cmp    $0x2,%cl
    7d22:	0f 84 78 11 00 00    	je     8ea0 <f12+0x1220>
    7d28:	80 f9 01             	cmp    $0x1,%cl
    7d2b:	75 2d                	jne    7d5a <f12+0xda>
    7d2d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d30:	0f b7 c0             	movzwl %ax,%eax
    7d33:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d36:	48 0f af c1          	imul   %rcx,%rax
    7d3a:	48 c1 e8 20          	shr    $0x20,%rax
    7d3e:	48 39 d0             	cmp    %rdx,%rax
    7d41:	73 17                	jae    7d5a <f12+0xda>
    7d43:	48 01 c7             	add    %rax,%rdi
    7d46:	0f b6 07             	movzbl (%rdi),%eax
    7d49:	84 c0                	test   %al,%al
    7d4b:	74 0d                	je     7d5a <f12+0xda>
    7d4d:	3c fd                	cmp    $0xfd,%al
    7d4f:	0f 87 a7 13 00 00    	ja     90fc <f12+0x147c>
    7d55:	83 c0 01             	add    $0x1,%eax
    7d58:	88 07                	mov    %al,(%rdi)
    7d5a:	48 8d 3d af 82 00 00 	lea    0x82af(%rip),%rdi        # 10010 <fc23>
    7d61:	e8 2a ed ff ff       	call   6a90 <fwp_closure_drop>
    7d66:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    7d6b:	48 85 c0             	test   %rax,%rax
    7d6e:	0f 84 aa 12 00 00    	je     901e <f12+0x139e>
    7d74:	31 d2                	xor    %edx,%edx
    7d76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d7d:	00 00 00 
    7d80:	48 8b 40 10          	mov    0x10(%rax),%rax
    7d84:	48 83 c2 01          	add    $0x1,%rdx
    7d88:	48 85 c0             	test   %rax,%rax
    7d8b:	75 f3                	jne    7d80 <f12+0x100>
    7d8d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    7d94:	0f 87 31 14 00 00    	ja     91cb <f12+0x154b>
    7d9a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    7d9f:	44 8b 05 ba 82 00 00 	mov    0x82ba(%rip),%r8d        # 10060 <registered_finish.0>
    7da6:	45 85 c0             	test   %r8d,%r8d
    7da9:	0f 84 c1 10 00 00    	je     8e70 <f12+0x11f0>
    7daf:	48 8b 1d 22 83 01 00 	mov    0x18322(%rip),%rbx        # 200d8 <fwp_tape_next_slot>
    7db6:	4c 8b 25 2b 83 01 00 	mov    0x1832b(%rip),%r12        # 200e8 <fwp_ntapes>
    7dbd:	4c 39 e3             	cmp    %r12,%rbx
    7dc0:	0f 8d ea 00 00 00    	jge    7eb0 <f12+0x230>
    7dc6:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7dca:	48 03 05 1f 83 01 00 	add    0x1831f(%rip),%rax        # 200f0 <fwp_tapes>
    7dd1:	0f 1f 40 00          	nopl   0x0(%rax)
    7dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ddc:	00 00 00 00 
    7de0:	8b 78 04             	mov    0x4(%rax),%edi
    7de3:	85 ff                	test   %edi,%edi
    7de5:	75 0c                	jne    7df3 <f12+0x173>
    7de7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7ded:	0f 86 bd 00 00 00    	jbe    7eb0 <f12+0x230>
    7df3:	48 83 c3 01          	add    $0x1,%rbx
    7df7:	48 83 c0 68          	add    $0x68,%rax
    7dfb:	4c 39 e3             	cmp    %r12,%rbx
    7dfe:	75 e0                	jne    7de0 <f12+0x160>
    7e00:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    7e07:	0f 8f 3c 14 00 00    	jg     9249 <f12+0x15c9>
    7e0d:	4c 39 25 cc 82 01 00 	cmp    %r12,0x182cc(%rip)        # 200e0 <fwp_tapes_cap>
    7e14:	48 8b 2d d5 82 01 00 	mov    0x182d5(%rip),%rbp        # 200f0 <fwp_tapes>
    7e1b:	75 53                	jne    7e70 <f12+0x1f0>
    7e1d:	4d 85 e4             	test   %r12,%r12
    7e20:	0f 84 5a 12 00 00    	je     9080 <f12+0x1400>
    7e26:	4b 8d 0c 24          	lea    (%r12,%r12,1),%rcx
    7e2a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7e2f:	48 39 c1             	cmp    %rax,%rcx
    7e32:	48 0f 4f c8          	cmovg  %rax,%rcx
    7e36:	48 6b f1 68          	imul   $0x68,%rcx,%rsi
    7e3a:	48 89 ef             	mov    %rbp,%rdi
    7e3d:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    7e42:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    7e47:	e8 84 b7 ff ff       	call   35d0 <realloc@plt>
    7e4c:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    7e51:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    7e56:	48 85 c0             	test   %rax,%rax
    7e59:	48 89 c5             	mov    %rax,%rbp
    7e5c:	0f 84 ad 13 00 00    	je     920f <f12+0x158f>
    7e62:	48 89 05 87 82 01 00 	mov    %rax,0x18287(%rip)        # 200f0 <fwp_tapes>
    7e69:	48 89 0d 70 82 01 00 	mov    %rcx,0x18270(%rip)        # 200e0 <fwp_tapes_cap>
    7e70:	49 6b c4 68          	imul   $0x68,%r12,%rax
    7e74:	49 83 c4 01          	add    $0x1,%r12
    7e78:	48 01 e8             	add    %rbp,%rax
    7e7b:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7e7f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7e86:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7e8a:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7e91:	00 
    7e92:	48 29 f8             	sub    %rdi,%rax
    7e95:	8d 48 68             	lea    0x68(%rax),%ecx
    7e98:	31 c0                	xor    %eax,%eax
    7e9a:	c1 e9 03             	shr    $0x3,%ecx
    7e9d:	f3 48 ab             	rep stos %rax,(%rdi)
    7ea0:	4c 89 25 41 82 01 00 	mov    %r12,0x18241(%rip)        # 200e8 <fwp_ntapes>
    7ea7:	eb 17                	jmp    7ec0 <f12+0x240>
    7ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7eb0:	4c 39 e3             	cmp    %r12,%rbx
    7eb3:	0f 84 47 ff ff ff    	je     7e00 <f12+0x180>
    7eb9:	48 8b 2d 30 82 01 00 	mov    0x18230(%rip),%rbp        # 200f0 <fwp_tapes>
    7ec0:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    7ec4:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7ec8:	48 8d 3d f0 41 00 00 	lea    0x41f0(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    7ecf:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7ed3:	49 01 ec             	add    %rbp,%r12
    7ed6:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    7edd:	00 00 
    7edf:	e8 bc b4 ff ff       	call   33a0 <getenv@plt>
    7ee4:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    7ee9:	48 85 c0             	test   %rax,%rax
    7eec:	74 09                	je     7ef7 <f12+0x277>
    7eee:	80 38 30             	cmpb   $0x30,(%rax)
    7ef1:	0f 84 f9 06 00 00    	je     85f0 <f12+0x970>
    7ef7:	48 83 3d 89 81 01 00 	cmpq   $0x0,0x18189(%rip)        # 20088 <fwp_tape_cached_bytes>
    7efe:	00 
    7eff:	0f 85 fb 0f 00 00    	jne    8f00 <f12+0x1280>
    7f05:	41 8b 04 24          	mov    (%r12),%eax
    7f09:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    7f0d:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    7f14:	00 00 
    7f16:	48 89 3d bb 81 01 00 	mov    %rdi,0x181bb(%rip)        # 200d8 <fwp_tape_next_slot>
    7f1d:	8d 70 01             	lea    0x1(%rax),%esi
    7f20:	48 8b 05 d1 a4 01 00 	mov    0x1a4d1(%rip),%rax        # 223f8 <fwp_cleanups>
    7f27:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    7f2e:	00 00 
    7f30:	41 89 34 24          	mov    %esi,(%r12)
    7f34:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    7f3b:	ff ff 
    7f3d:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    7f43:	48 85 c0             	test   %rax,%rax
    7f46:	75 14                	jne    7f5c <f12+0x2dc>
    7f48:	e9 f0 12 00 00       	jmp    923d <f12+0x15bd>
    7f4d:	0f 1f 00             	nopl   (%rax)
    7f50:	48 8b 00             	mov    (%rax),%rax
    7f53:	48 85 c0             	test   %rax,%rax
    7f56:	0f 84 e1 12 00 00    	je     923d <f12+0x15bd>
    7f5c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    7f60:	75 ee                	jne    7f50 <f12+0x2d0>
    7f62:	48 8b 48 10          	mov    0x10(%rax),%rcx
    7f66:	41 89 d8             	mov    %ebx,%r8d
    7f69:	48 63 01             	movslq (%rcx),%rax
    7f6c:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    7f71:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    7f76:	85 c0                	test   %eax,%eax
    7f78:	78 08                	js     7f82 <f12+0x302>
    7f7a:	48 6b c0 68          	imul   $0x68,%rax,%rax
    7f7e:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    7f82:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
    7f87:	44 89 01             	mov    %r8d,(%rcx)
    7f8a:	31 c9                	xor    %ecx,%ecx
    7f8c:	48 89 d8             	mov    %rbx,%rax
    7f8f:	48 85 db             	test   %rbx,%rbx
    7f92:	0f 84 d8 0d 00 00    	je     8d70 <f12+0x10f0>
    7f98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7f9f:	00 
    7fa0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7fa4:	48 83 c1 01          	add    $0x1,%rcx
    7fa8:	48 85 c0             	test   %rax,%rax
    7fab:	75 f3                	jne    7fa0 <f12+0x320>
    7fad:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    7fb2:	0f 1f 00             	nopl   (%rax)
    7fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7fbc:	00 00 00 00 
    7fc0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7fc4:	48 83 c0 01          	add    $0x1,%rax
    7fc8:	48 85 d2             	test   %rdx,%rdx
    7fcb:	75 f3                	jne    7fc0 <f12+0x340>
    7fcd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    7fd4:	ff ff 1f 
    7fd7:	48 39 c2             	cmp    %rax,%rdx
    7fda:	0f 82 f7 11 00 00    	jb     91d7 <f12+0x1557>
    7fe0:	48 85 c9             	test   %rcx,%rcx
    7fe3:	0f 8e 87 0d 00 00    	jle    8d70 <f12+0x10f0>
    7fe9:	48 39 c1             	cmp    %rax,%rcx
    7fec:	48 0f 46 c1          	cmovbe %rcx,%rax
    7ff0:	49 89 c5             	mov    %rax,%r13
    7ff3:	48 c1 e8 3c          	shr    $0x3c,%rax
    7ff7:	0f 85 da 11 00 00    	jne    91d7 <f12+0x1557>
    7ffd:	48 c1 e6 10          	shl    $0x10,%rsi
    8001:	4b 8d 6c 2d 00       	lea    0x0(%r13,%r13,1),%rbp
    8006:	48 09 fe             	or     %rdi,%rsi
    8009:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8010:	00 
    8011:	49 89 f4             	mov    %rsi,%r12
    8014:	be 02 00 00 00       	mov    $0x2,%esi
    8019:	e8 32 da ff ff       	call   5a50 <fwp_heap_alloc>
    801e:	48 89 28             	mov    %rbp,(%rax)
    8021:	48 8b 15 10 9b 01 00 	mov    0x19b10(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8028:	48 89 c3             	mov    %rax,%rbx
    802b:	48 2b 05 de 9a 01 00 	sub    0x19ade(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8032:	48 c1 e2 10          	shl    $0x10,%rdx
    8036:	48 39 d0             	cmp    %rdx,%rax
    8039:	0f 83 c9 0d 00 00    	jae    8e08 <f12+0x1188>
    803f:	48 89 c2             	mov    %rax,%rdx
    8042:	48 c1 ea 10          	shr    $0x10,%rdx
    8046:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    804a:	48 8b 15 07 9b 01 00 	mov    0x19b07(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    8051:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8055:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8059:	48 85 d2             	test   %rdx,%rdx
    805c:	74 38                	je     8096 <f12+0x416>
    805e:	0f b6 31             	movzbl (%rcx),%esi
    8061:	40 80 fe 02          	cmp    $0x2,%sil
    8065:	0f 84 72 0d 00 00    	je     8ddd <f12+0x115d>
    806b:	40 80 fe 01          	cmp    $0x1,%sil
    806f:	75 25                	jne    8096 <f12+0x416>
    8071:	8b 71 18             	mov    0x18(%rcx),%esi
    8074:	0f b7 c0             	movzwl %ax,%eax
    8077:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    807a:	48 0f af c6          	imul   %rsi,%rax
    807e:	48 c1 e8 20          	shr    $0x20,%rax
    8082:	48 39 c8             	cmp    %rcx,%rax
    8085:	73 0f                	jae    8096 <f12+0x416>
    8087:	48 01 c2             	add    %rax,%rdx
    808a:	80 3a ff             	cmpb   $0xff,(%rdx)
    808d:	0f 84 fc 0f 00 00    	je     908f <f12+0x140f>
    8093:	c6 02 01             	movb   $0x1,(%rdx)
    8096:	4d 85 ed             	test   %r13,%r13
    8099:	74 58                	je     80f3 <f12+0x473>
    809b:	4c 89 e1             	mov    %r12,%rcx
    809e:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    80a3:	31 c0                	xor    %eax,%eax
    80a5:	48 c1 e1 20          	shl    $0x20,%rcx
    80a9:	90                   	nop
    80aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80b1:	00 00 00 00 
    80b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80bc:	00 00 00 00 
    80c0:	48 89 c6             	mov    %rax,%rsi
    80c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    80c8:	48 01 ce             	add    %rcx,%rsi
    80cb:	0f 80 ed 10 00 00    	jo     91be <f12+0x153e>
    80d1:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    80d6:	48 89 c6             	mov    %rax,%rsi
    80d9:	48 83 c0 01          	add    $0x1,%rax
    80dd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    80e1:	48 c1 e6 04          	shl    $0x4,%rsi
    80e5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    80ea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    80ee:	4c 39 e8             	cmp    %r13,%rax
    80f1:	72 cd                	jb     80c0 <f12+0x440>
    80f3:	48 8b 03             	mov    (%rbx),%rax
    80f6:	48 d1 e8             	shr    $1,%rax
    80f9:	0f 84 21 0d 00 00    	je     8e20 <f12+0x11a0>
    80ff:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8103:	48 89 d1             	mov    %rdx,%rcx
    8106:	48 c1 e9 3c          	shr    $0x3c,%rcx
    810a:	0f 85 c7 10 00 00    	jne    91d7 <f12+0x1557>
    8110:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    8114:	48 89 0c 24          	mov    %rcx,(%rsp)
    8118:	48 85 d2             	test   %rdx,%rdx
    811b:	74 40                	je     815d <f12+0x4dd>
    811d:	48 c1 e0 04          	shl    $0x4,%rax
    8121:	48 8d 6b 08          	lea    0x8(%rbx),%rbp
    8125:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    812a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8130:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    8135:	48 8b 75 18          	mov    0x18(%rbp),%rsi
    8139:	48 83 c5 10          	add    $0x10,%rbp
    813d:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
    8141:	f2 0f 10 4d 00       	movsd  0x0(%rbp),%xmm1
    8146:	e8 65 e1 ff ff       	call   62b0 <w107>
    814b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8150:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8154:	0f 11 45 f0          	movups %xmm0,-0x10(%rbp)
    8158:	49 39 ed             	cmp    %rbp,%r13
    815b:	75 d3                	jne    8130 <f12+0x4b0>
    815d:	48 8b 04 24          	mov    (%rsp),%rax
    8161:	48 89 df             	mov    %rbx,%rdi
    8164:	48 89 03             	mov    %rax,(%rbx)
    8167:	e8 04 e3 ff ff       	call   6470 <w164.constprop.0>
    816c:	48 89 df             	mov    %rbx,%rdi
    816f:	49 63 dc             	movslq %r12d,%rbx
    8172:	49 89 c5             	mov    %rax,%r13
    8175:	e8 f6 f5 ff ff       	call   7770 <fwp_drop4>
    817a:	48 89 df             	mov    %rbx,%rdi
    817d:	e8 fe c2 ff ff       	call   4480 <fwp_tape_of>
    8182:	48 89 c6             	mov    %rax,%rsi
    8185:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    818a:	0f 85 ca 10 00 00    	jne    925a <f12+0x15da>
    8190:	48 89 c7             	mov    %rax,%rdi
    8193:	e8 68 ba ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8198:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    819c:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    81a1:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    81a8:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    81ac:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    81b0:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    81b5:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    81ba:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    81bf:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    81c3:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    81c7:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    81cd:	77 19                	ja     81e8 <f12+0x568>
    81cf:	41 0f b7 c4          	movzwl %r12w,%eax
    81d3:	83 e8 01             	sub    $0x1,%eax
    81d6:	48 98                	cltq
    81d8:	48 3b 05 f9 7e 01 00 	cmp    0x17ef9(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    81df:	7d 07                	jge    81e8 <f12+0x568>
    81e1:	48 89 05 f0 7e 01 00 	mov    %rax,0x17ef0(%rip)        # 200d8 <fwp_tape_next_slot>
    81e8:	48 8b 05 09 a2 01 00 	mov    0x1a209(%rip),%rax        # 223f8 <fwp_cleanups>
    81ef:	66 0f ef c9          	pxor   %xmm1,%xmm1
    81f3:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    81fa:	00 
    81fb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8202:	00 
    8203:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8207:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    820e:	00 
    820f:	48 8d 05 1a cc ff ff 	lea    -0x33e6(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    8216:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    821d:	00 
    821e:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8225:	00 
    8226:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    822a:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    822e:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8235:	00 
    8236:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    823d:	00 
    823e:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    8245:	00 
    8246:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    824d:	00 
    824e:	48 89 05 a3 a1 01 00 	mov    %rax,0x1a1a3(%rip)        # 223f8 <fwp_cleanups>
    8255:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    825c:	00 
    825d:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    8264:	00 
    8265:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    826c:	00 
    826d:	4d 85 ed             	test   %r13,%r13
    8270:	0f 88 3a 0c 00 00    	js     8eb0 <f12+0x1230>
    8276:	4c 89 e8             	mov    %r13,%rax
    8279:	48 c1 f8 20          	sar    $0x20,%rax
    827d:	48 39 c3             	cmp    %rax,%rbx
    8280:	0f 85 1b 0f 00 00    	jne    91a1 <f12+0x1521>
    8286:	45 89 ea             	mov    %r13d,%r10d
    8289:	4c 89 d3             	mov    %r10,%rbx
    828c:	4c 39 d7             	cmp    %r10,%rdi
    828f:	0f 8e 00 0f 00 00    	jle    9195 <f12+0x1515>
    8295:	4c 39 d5             	cmp    %r10,%rbp
    8298:	0f 8e 92 0b 00 00    	jle    8e30 <f12+0x11b0>
    829e:	48 39 d5             	cmp    %rdx,%rbp
    82a1:	0f 8e d1 0c 00 00    	jle    8f78 <f12+0x12f8>
    82a7:	49 89 e9             	mov    %rbp,%r9
    82aa:	48 85 d2             	test   %rdx,%rdx
    82ad:	49 0f 44 d1          	cmove  %r9,%rdx
    82b1:	eb 22                	jmp    82d5 <f12+0x655>
    82b3:	66 90                	xchg   %ax,%ax
    82b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82bc:	00 00 00 00 
    82c0:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    82c4:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    82cb:	4c 89 c8             	mov    %r9,%rax
    82ce:	48 0f 4c c6          	cmovl  %rsi,%rax
    82d2:	48 89 c2             	mov    %rax,%rdx
    82d5:	49 39 d1             	cmp    %rdx,%r9
    82d8:	7f e6                	jg     82c0 <f12+0x640>
    82da:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    82df:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    82e4:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    82e9:	48 85 c9             	test   %rcx,%rcx
    82ec:	0f 84 fe 0c 00 00    	je     8ff0 <f12+0x1370>
    82f2:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    82f9:	00 
    82fa:	48 89 cf             	mov    %rcx,%rdi
    82fd:	48 89 14 24          	mov    %rdx,(%rsp)
    8301:	e8 ca b2 ff ff       	call   35d0 <realloc@plt>
    8306:	48 8b 14 24          	mov    (%rsp),%rdx
    830a:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    830f:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8315:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    831b:	48 89 c1             	mov    %rax,%rcx
    831e:	48 85 c9             	test   %rcx,%rcx
    8321:	0f 84 c8 0e 00 00    	je     91ef <f12+0x156f>
    8327:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    832e:	00 
    832f:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
    8336:	00 
    8337:	4d 85 c9             	test   %r9,%r9
    833a:	0f 85 7d 0d 00 00    	jne    90bd <f12+0x143d>
    8340:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8347:	4d 85 ed             	test   %r13,%r13
    834a:	78 17                	js     8363 <f12+0x6e3>
    834c:	45 89 ea             	mov    %r13d,%r10d
    834f:	f2 0f 10 05 d9 47 00 	movsd  0x47d9(%rip),%xmm0        # cb30 <msg.4+0xb0>
    8356:	00 
    8357:	f2 42 0f 58 04 d1    	addsd  (%rcx,%r10,8),%xmm0
    835d:	f2 42 0f 11 04 d1    	movsd  %xmm0,(%rcx,%r10,8)
    8363:	48 39 dd             	cmp    %rbx,%rbp
    8366:	0f 8f 8e 00 00 00    	jg     83fa <f12+0x77a>
    836c:	0f 12 f3             	movhlps %xmm3,%xmm6
    836f:	66 48 0f 7e de       	movq   %xmm3,%rsi
    8374:	0f 12 da             	movhlps %xmm2,%xmm3
    8377:	48 29 eb             	sub    %rbp,%rbx
    837a:	66 49 0f 7e db       	movq   %xmm3,%r11
    837f:	66 48 0f 7e f7       	movq   %xmm6,%rdi
    8384:	66 49 0f 7e d2       	movq   %xmm2,%r10
    8389:	4c 8d 0c e9          	lea    (%rcx,%rbp,8),%r9
    838d:	49 8d 14 db          	lea    (%r11,%rbx,8),%rdx
    8391:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8395:	48 29 fe             	sub    %rdi,%rsi
    8398:	48 8d 04 9f          	lea    (%rdi,%rbx,4),%rax
    839c:	4d 29 d9             	sub    %r11,%r9
    839f:	4d 29 da             	sub    %r11,%r10
    83a2:	eb 08                	jmp    83ac <f12+0x72c>
    83a4:	0f 1f 40 00          	nopl   0x0(%rax)
    83a8:	48 83 e8 04          	sub    $0x4,%rax
    83ac:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    83b2:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    83b6:	7a 02                	jp     83ba <f12+0x73a>
    83b8:	74 37                	je     83f1 <f12+0x771>
    83ba:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    83be:	45 85 db             	test   %r11d,%r11d
    83c1:	78 16                	js     83d9 <f12+0x759>
    83c3:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    83c9:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    83cd:	f2 42 0f 58 0c d9    	addsd  (%rcx,%r11,8),%xmm1
    83d3:	f2 42 0f 11 0c d9    	movsd  %xmm1,(%rcx,%r11,8)
    83d9:	4c 63 18             	movslq (%rax),%r11
    83dc:	45 85 db             	test   %r11d,%r11d
    83df:	78 10                	js     83f1 <f12+0x771>
    83e1:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    83e5:	f2 42 0f 58 04 d9    	addsd  (%rcx,%r11,8),%xmm0
    83eb:	f2 42 0f 11 04 d9    	movsd  %xmm0,(%rcx,%r11,8)
    83f1:	48 83 ea 08          	sub    $0x8,%rdx
    83f5:	48 39 c7             	cmp    %rax,%rdi
    83f8:	75 ae                	jne    83a8 <f12+0x728>
    83fa:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8401:	ff ff 1f 
    8404:	48 39 e8             	cmp    %rbp,%rax
    8407:	0f 82 d6 0d 00 00    	jb     91e3 <f12+0x1563>
    840d:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8414:	00 
    8415:	be 02 00 00 00       	mov    $0x2,%esi
    841a:	48 89 0c 24          	mov    %rcx,(%rsp)
    841e:	e8 2d d6 ff ff       	call   5a50 <fwp_heap_alloc>
    8423:	48 8b 0c 24          	mov    (%rsp),%rcx
    8427:	48 89 28             	mov    %rbp,(%rax)
    842a:	48 89 c3             	mov    %rax,%rbx
    842d:	31 c0                	xor    %eax,%eax
    842f:	48 85 ed             	test   %rbp,%rbp
    8432:	74 1e                	je     8452 <f12+0x7d2>
    8434:	90                   	nop
    8435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    843c:	00 00 00 00 
    8440:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    8444:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    8449:	48 83 c0 01          	add    $0x1,%rax
    844d:	48 39 c5             	cmp    %rax,%rbp
    8450:	75 ee                	jne    8440 <f12+0x7c0>
    8452:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    8459:	00 
    845a:	4c 89 e7             	mov    %r12,%rdi
    845d:	4c 89 2d 94 9f 01 00 	mov    %r13,0x19f94(%rip)        # 223f8 <fwp_cleanups>
    8464:	e8 c7 c9 ff ff       	call   4e30 <fwp_tape_buffers_release>
    8469:	48 8b 15 c8 96 01 00 	mov    0x196c8(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8470:	48 89 d8             	mov    %rbx,%rax
    8473:	48 2b 05 96 96 01 00 	sub    0x19696(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    847a:	48 c1 e2 10          	shl    $0x10,%rdx
    847e:	48 39 d0             	cmp    %rdx,%rax
    8481:	73 59                	jae    84dc <f12+0x85c>
    8483:	48 89 c2             	mov    %rax,%rdx
    8486:	48 c1 ea 10          	shr    $0x10,%rdx
    848a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    848e:	48 8b 15 c3 96 01 00 	mov    0x196c3(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    8495:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8499:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    849d:	4d 85 e4             	test   %r12,%r12
    84a0:	74 3a                	je     84dc <f12+0x85c>
    84a2:	0f b6 0a             	movzbl (%rdx),%ecx
    84a5:	80 f9 02             	cmp    $0x2,%cl
    84a8:	0f 84 32 0a 00 00    	je     8ee0 <f12+0x1260>
    84ae:	80 f9 01             	cmp    $0x1,%cl
    84b1:	75 29                	jne    84dc <f12+0x85c>
    84b3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84b6:	0f b7 c0             	movzwl %ax,%eax
    84b9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84bc:	48 0f af c1          	imul   %rcx,%rax
    84c0:	48 c1 e8 20          	shr    $0x20,%rax
    84c4:	48 39 d0             	cmp    %rdx,%rax
    84c7:	73 13                	jae    84dc <f12+0x85c>
    84c9:	49 01 c4             	add    %rax,%r12
    84cc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    84d1:	0f 84 cd 0b 00 00    	je     90a4 <f12+0x1424>
    84d7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    84dc:	4d 39 fd             	cmp    %r15,%r13
    84df:	0f 85 66 b2 ff ff    	jne    374b <f12.cold>
    84e5:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    84ea:	4c 89 f7             	mov    %r14,%rdi
    84ed:	48 89 05 04 9f 01 00 	mov    %rax,0x19f04(%rip)        # 223f8 <fwp_cleanups>
    84f4:	e8 c7 e8 ff ff       	call   6dc0 <fwp_tape_scope_release>
    84f9:	48 8b 03             	mov    (%rbx),%rax
    84fc:	49 89 c4             	mov    %rax,%r12
    84ff:	49 0f ba f4 3f       	btr    $0x3f,%r12
    8504:	48 85 c0             	test   %rax,%rax
    8507:	0f 88 b3 07 00 00    	js     8cc0 <f12+0x1040>
    850d:	48 8b 15 24 96 01 00 	mov    0x19624(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8514:	48 89 d8             	mov    %rbx,%rax
    8517:	48 2b 05 f2 95 01 00 	sub    0x195f2(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    851e:	48 c1 e2 10          	shl    $0x10,%rdx
    8522:	48 39 d0             	cmp    %rdx,%rax
    8525:	0f 83 95 07 00 00    	jae    8cc0 <f12+0x1040>
    852b:	48 89 c2             	mov    %rax,%rdx
    852e:	48 c1 ea 10          	shr    $0x10,%rdx
    8532:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8536:	48 8b 15 1b 96 01 00 	mov    0x1961b(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    853d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8541:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8545:	48 85 c9             	test   %rcx,%rcx
    8548:	0f 84 72 07 00 00    	je     8cc0 <f12+0x1040>
    854e:	0f b6 32             	movzbl (%rdx),%esi
    8551:	40 80 fe 02          	cmp    $0x2,%sil
    8555:	0f 84 55 07 00 00    	je     8cb0 <f12+0x1030>
    855b:	40 80 fe 01          	cmp    $0x1,%sil
    855f:	0f 85 5b 07 00 00    	jne    8cc0 <f12+0x1040>
    8565:	8b 72 18             	mov    0x18(%rdx),%esi
    8568:	0f b7 c0             	movzwl %ax,%eax
    856b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    856e:	48 0f af c6          	imul   %rsi,%rax
    8572:	48 c1 e8 20          	shr    $0x20,%rax
    8576:	48 39 d0             	cmp    %rdx,%rax
    8579:	0f 83 41 07 00 00    	jae    8cc0 <f12+0x1040>
    857f:	48 01 c1             	add    %rax,%rcx
    8582:	80 39 01             	cmpb   $0x1,(%rcx)
    8585:	0f 85 35 07 00 00    	jne    8cc0 <f12+0x1040>
    858b:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
    8590:	49 89 dd             	mov    %rbx,%r13
    8593:	31 ff                	xor    %edi,%edi
    8595:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    859a:	f2 0f 10 0d a6 45 00 	movsd  0x45a6(%rip),%xmm1        # cb48 <msg.4+0xc8>
    85a1:	00 
    85a2:	48 8d 50 08          	lea    0x8(%rax),%rdx
    85a6:	31 c0                	xor    %eax,%eax
    85a8:	4d 85 e4             	test   %r12,%r12
    85ab:	75 29                	jne    85d6 <f12+0x956>
    85ad:	eb 51                	jmp    8600 <f12+0x980>
    85af:	90                   	nop
    85b0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    85b5:	0f 88 f7 0b 00 00    	js     91b2 <f12+0x1532>
    85bb:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    85c0:	48 83 c0 01          	add    $0x1,%rax
    85c4:	48 83 c2 08          	add    $0x8,%rdx
    85c8:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    85cc:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    85d1:	49 39 c4             	cmp    %rax,%r12
    85d4:	74 2a                	je     8600 <f12+0x980>
    85d6:	48 8d 4b 08          	lea    0x8(%rbx),%rcx
    85da:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    85de:	79 d0                	jns    85b0 <f12+0x930>
    85e0:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    85e4:	eb ca                	jmp    85b0 <f12+0x930>
    85e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    85ed:	00 00 00 
    85f0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    85f4:	0f 84 0b f9 ff ff    	je     7f05 <f12+0x285>
    85fa:	e9 f8 f8 ff ff       	jmp    7ef7 <f12+0x277>
    85ff:	90                   	nop
    8600:	e8 6b f1 ff ff       	call   7770 <fwp_drop4>
    8605:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    860a:	31 d2                	xor    %edx,%edx
    860c:	48 89 c8             	mov    %rcx,%rax
    860f:	48 85 c9             	test   %rcx,%rcx
    8612:	0f 84 0f 0a 00 00    	je     9027 <f12+0x13a7>
    8618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    861f:	00 
    8620:	48 8b 40 10          	mov    0x10(%rax),%rax
    8624:	48 83 c2 01          	add    $0x1,%rdx
    8628:	48 85 c0             	test   %rax,%rax
    862b:	75 f3                	jne    8620 <f12+0x9a0>
    862d:	49 8b 45 00          	mov    0x0(%r13),%rax
    8631:	49 89 c7             	mov    %rax,%r15
    8634:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8639:	48 85 c0             	test   %rax,%rax
    863c:	0f 88 d3 05 00 00    	js     8c15 <f12+0xf95>
    8642:	48 8b 0d ef 94 01 00 	mov    0x194ef(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    8649:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    864e:	48 2b 05 bb 94 01 00 	sub    0x194bb(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8655:	48 c1 e1 10          	shl    $0x10,%rcx
    8659:	48 39 c8             	cmp    %rcx,%rax
    865c:	0f 83 b3 05 00 00    	jae    8c15 <f12+0xf95>
    8662:	48 89 c1             	mov    %rax,%rcx
    8665:	48 c1 e9 10          	shr    $0x10,%rcx
    8669:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    866d:	48 8b 0d e4 94 01 00 	mov    0x194e4(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    8674:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    8678:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    867c:	48 85 ff             	test   %rdi,%rdi
    867f:	0f 84 90 05 00 00    	je     8c15 <f12+0xf95>
    8685:	0f b6 0e             	movzbl (%rsi),%ecx
    8688:	80 f9 02             	cmp    $0x2,%cl
    868b:	0f 84 6f 05 00 00    	je     8c00 <f12+0xf80>
    8691:	80 f9 01             	cmp    $0x1,%cl
    8694:	0f 85 6f 05 00 00    	jne    8c09 <f12+0xf89>
    869a:	8b 4e 18             	mov    0x18(%rsi),%ecx
    869d:	0f b7 c0             	movzwl %ax,%eax
    86a0:	48 0f af c1          	imul   %rcx,%rax
    86a4:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    86a7:	48 c1 e8 20          	shr    $0x20,%rax
    86ab:	48 39 c8             	cmp    %rcx,%rax
    86ae:	0f 83 55 05 00 00    	jae    8c09 <f12+0xf89>
    86b4:	48 01 c7             	add    %rax,%rdi
    86b7:	80 3f 01             	cmpb   $0x1,(%rdi)
    86ba:	0f 85 49 05 00 00    	jne    8c09 <f12+0xf89>
    86c0:	4c 39 fa             	cmp    %r15,%rdx
    86c3:	4c 0f 46 fa          	cmovbe %rdx,%r15
    86c7:	4c 89 fd             	mov    %r15,%rbp
    86ca:	4d 85 ff             	test   %r15,%r15
    86cd:	0f 84 f0 0a 00 00    	je     91c3 <f12+0x1543>
    86d3:	c7 44 24 4c 01 00 00 	movl   $0x1,0x4c(%rsp)
    86da:	00 
    86db:	4d 8d 65 08          	lea    0x8(%r13),%r12
    86df:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    86e4:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    86e9:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    86f0:	00 
    86f1:	31 c0                	xor    %eax,%eax
    86f3:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    86f7:	eb 24                	jmp    871d <f12+0xa9d>
    86f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8700:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    8705:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    870a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    8710:	48 83 c0 08          	add    $0x8,%rax
    8714:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8718:	49 39 c0             	cmp    %rax,%r8
    871b:	74 1b                	je     8738 <f12+0xab8>
    871d:	48 89 fe             	mov    %rdi,%rsi
    8720:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8725:	79 d9                	jns    8700 <f12+0xa80>
    8727:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    872c:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8730:	eb ce                	jmp    8700 <f12+0xa80>
    8732:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8738:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    873d:	48 85 d2             	test   %rdx,%rdx
    8740:	0f 84 47 0a 00 00    	je     918d <f12+0x150d>
    8746:	4c 8b 05 eb 93 01 00 	mov    0x193eb(%rip),%r8        # 21b38 <fwp_heap+0x13d8>
    874d:	4c 8b 15 bc 93 01 00 	mov    0x193bc(%rip),%r10        # 21b10 <fwp_heap+0x13b0>
    8754:	45 31 ff             	xor    %r15d,%r15d
    8757:	4c 8b 1d fa 93 01 00 	mov    0x193fa(%rip),%r11        # 21b58 <fwp_heap+0x13f8>
    875e:	49 c1 e0 10          	shl    $0x10,%r8
    8762:	eb 1a                	jmp    877e <f12+0xafe>
    8764:	0f 1f 40 00          	nopl   0x0(%rax)
    8768:	49 83 c7 01          	add    $0x1,%r15
    876c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8770:	49 39 ef             	cmp    %rbp,%r15
    8773:	0f 83 27 02 00 00    	jae    89a0 <f12+0xd20>
    8779:	48 85 d2             	test   %rdx,%rdx
    877c:	74 52                	je     87d0 <f12+0xb50>
    877e:	48 89 d0             	mov    %rdx,%rax
    8781:	4c 29 d0             	sub    %r10,%rax
    8784:	4c 39 c0             	cmp    %r8,%rax
    8787:	73 47                	jae    87d0 <f12+0xb50>
    8789:	48 89 c6             	mov    %rax,%rsi
    878c:	48 c1 ee 10          	shr    $0x10,%rsi
    8790:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8794:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    8798:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    879c:	48 85 ff             	test   %rdi,%rdi
    879f:	74 2f                	je     87d0 <f12+0xb50>
    87a1:	0f b6 1e             	movzbl (%rsi),%ebx
    87a4:	80 fb 02             	cmp    $0x2,%bl
    87a7:	0f 84 d3 01 00 00    	je     8980 <f12+0xd00>
    87ad:	80 fb 01             	cmp    $0x1,%bl
    87b0:	75 1e                	jne    87d0 <f12+0xb50>
    87b2:	8b 5e 18             	mov    0x18(%rsi),%ebx
    87b5:	0f b7 c0             	movzwl %ax,%eax
    87b8:	8b 76 1c             	mov    0x1c(%rsi),%esi
    87bb:	48 0f af c3          	imul   %rbx,%rax
    87bf:	48 c1 e8 20          	shr    $0x20,%rax
    87c3:	48 39 f0             	cmp    %rsi,%rax
    87c6:	73 08                	jae    87d0 <f12+0xb50>
    87c8:	48 01 c7             	add    %rax,%rdi
    87cb:	80 3f 01             	cmpb   $0x1,(%rdi)
    87ce:	74 98                	je     8768 <f12+0xae8>
    87d0:	49 39 ef             	cmp    %rbp,%r15
    87d3:	0f 83 c7 01 00 00    	jae    89a0 <f12+0xd20>
    87d9:	4c 8b 2d 10 43 00 00 	mov    0x4310(%rip),%r13        # caf0 <msg.4+0x70>
    87e0:	45 31 f6             	xor    %r14d,%r14d
    87e3:	48 8d 1d 76 7f 01 00 	lea    0x17f76(%rip),%rbx        # 20760 <fwp_heap>
    87ea:	e9 17 01 00 00       	jmp    8906 <f12+0xc86>
    87ef:	90                   	nop
    87f0:	49 8b 10             	mov    (%r8),%rdx
    87f3:	48 f7 d2             	not    %rdx
    87f6:	48 89 10             	mov    %rdx,(%rax)
    87f9:	49 83 fb 18          	cmp    $0x18,%r11
    87fd:	76 39                	jbe    8838 <f12+0xbb8>
    87ff:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    8803:	49 8d 78 18          	lea    0x18(%r8),%rdi
    8807:	31 f6                	xor    %esi,%esi
    8809:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
    880e:	48 c1 e8 03          	shr    $0x3,%rax
    8812:	4c 89 04 24          	mov    %r8,(%rsp)
    8816:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    881d:	00 
    881e:	66 0f d6 44 24 20    	movq   %xmm0,0x20(%rsp)
    8824:	e8 97 ac ff ff       	call   34c0 <memset@plt>
    8829:	4c 8b 04 24          	mov    (%rsp),%r8
    882d:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
    8832:	f3 0f 7e 44 24 20    	movq   0x20(%rsp),%xmm0
    8838:	4c 89 d8             	mov    %r11,%rax
    883b:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8842:	0f 82 65 09 00 00    	jb     91ad <f12+0x152d>
    8848:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    884f:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8856:	73 07                	jae    885f <f12+0xbdf>
    8858:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    885f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8863:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    8868:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    886f:	00 
    8870:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8877:	00 
    8878:	66 49 0f 6e f6       	movq   %r14,%xmm6
    887d:	4d 89 28             	mov    %r13,(%r8)
    8880:	4c 89 c0             	mov    %r8,%rax
    8883:	4d 89 c6             	mov    %r8,%r14
    8886:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    888a:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    888f:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8896:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    889d:	48 c1 e2 10          	shl    $0x10,%rdx
    88a1:	48 39 d0             	cmp    %rdx,%rax
    88a4:	73 57                	jae    88fd <f12+0xc7d>
    88a6:	48 89 c2             	mov    %rax,%rdx
    88a9:	48 c1 ea 10          	shr    $0x10,%rdx
    88ad:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    88b1:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    88b8:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    88bc:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    88c0:	48 85 d2             	test   %rdx,%rdx
    88c3:	74 38                	je     88fd <f12+0xc7d>
    88c5:	0f b6 3e             	movzbl (%rsi),%edi
    88c8:	40 80 ff 02          	cmp    $0x2,%dil
    88cc:	0f 84 7e 01 00 00    	je     8a50 <f12+0xdd0>
    88d2:	40 80 ff 01          	cmp    $0x1,%dil
    88d6:	75 25                	jne    88fd <f12+0xc7d>
    88d8:	8b 7e 18             	mov    0x18(%rsi),%edi
    88db:	0f b7 c0             	movzwl %ax,%eax
    88de:	8b 76 1c             	mov    0x1c(%rsi),%esi
    88e1:	48 0f af c7          	imul   %rdi,%rax
    88e5:	48 c1 e8 20          	shr    $0x20,%rax
    88e9:	48 39 f0             	cmp    %rsi,%rax
    88ec:	73 0f                	jae    88fd <f12+0xc7d>
    88ee:	48 01 c2             	add    %rax,%rdx
    88f1:	80 3a ff             	cmpb   $0xff,(%rdx)
    88f4:	0f 84 f6 04 00 00    	je     8df0 <f12+0x1170>
    88fa:	c6 02 01             	movb   $0x1,(%rdx)
    88fd:	49 39 ef             	cmp    %rbp,%r15
    8900:	0f 83 6a 01 00 00    	jae    8a70 <f12+0xdf0>
    8906:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    890c:	48 83 ed 01          	sub    $0x1,%rbp
    8910:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8916:	85 f6                	test   %esi,%esi
    8918:	74 46                	je     8960 <f12+0xce0>
    891a:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8921:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    8928:	00 
    8929:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    892d:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8931:	4c 8b 00             	mov    (%rax),%r8
    8934:	4d 85 c0             	test   %r8,%r8
    8937:	0f 85 b3 fe ff ff    	jne    87f0 <f12+0xb70>
    893d:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8941:	4d 85 c0             	test   %r8,%r8
    8944:	74 1a                	je     8960 <f12+0xce0>
    8946:	48 8b 50 10          	mov    0x10(%rax),%rdx
    894a:	4c 29 c2             	sub    %r8,%rdx
    894d:	4c 39 da             	cmp    %r11,%rdx
    8950:	72 0e                	jb     8960 <f12+0xce0>
    8952:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8956:	48 89 50 08          	mov    %rdx,0x8(%rax)
    895a:	e9 9a fe ff ff       	jmp    87f9 <f12+0xb79>
    895f:	90                   	nop
    8960:	31 f6                	xor    %esi,%esi
    8962:	bf 18 00 00 00       	mov    $0x18,%edi
    8967:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    896c:	e8 df d0 ff ff       	call   5a50 <fwp_heap_alloc>
    8971:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8976:	49 89 c0             	mov    %rax,%r8
    8979:	e9 fa fe ff ff       	jmp    8878 <f12+0xbf8>
    897e:	66 90                	xchg   %ax,%ax
    8980:	66 85 c0             	test   %ax,%ax
    8983:	0f 84 42 fe ff ff    	je     87cb <f12+0xb4b>
    8989:	49 39 ef             	cmp    %rbp,%r15
    898c:	0f 82 47 fe ff ff    	jb     87d9 <f12+0xb59>
    8992:	0f 1f 00             	nopl   (%rax)
    8995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    899c:	00 00 00 00 
    89a0:	45 31 f6             	xor    %r14d,%r14d
    89a3:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    89a8:	4c 89 e2             	mov    %r12,%rdx
    89ab:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    89af:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    89b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    89bc:	00 00 00 00 
    89c0:	48 8b 0a             	mov    (%rdx),%rcx
    89c3:	48 83 c2 08          	add    $0x8,%rdx
    89c7:	48 89 c6             	mov    %rax,%rsi
    89ca:	48 89 48 08          	mov    %rcx,0x8(%rax)
    89ce:	48 8b 40 10          	mov    0x10(%rax),%rax
    89d2:	48 39 d7             	cmp    %rdx,%rdi
    89d5:	75 e9                	jne    89c0 <f12+0xd40>
    89d7:	8b 4c 24 4c          	mov    0x4c(%rsp),%ecx
    89db:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    89df:	85 c9                	test   %ecx,%ecx
    89e1:	0f 84 09 05 00 00    	je     8ef0 <f12+0x1270>
    89e7:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    89ec:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    89f1:	45 31 e4             	xor    %r12d,%r12d
    89f4:	90                   	nop
    89f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    89fc:	00 00 00 00 
    8a00:	4c 89 e7             	mov    %r12,%rdi
    8a03:	e8 48 cb ff ff       	call   5550 <fwp_mem_free>
    8a08:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8a0d:	e8 5e ed ff ff       	call   7770 <fwp_drop4>
    8a12:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    8a17:	e8 94 dd ff ff       	call   67b0 <fwp_drop0>
    8a1c:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
    8a23:	00 
    8a24:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a2b:	00 00 
    8a2d:	0f 85 22 08 00 00    	jne    9255 <f12+0x15d5>
    8a33:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
    8a3a:	4c 89 f0             	mov    %r14,%rax
    8a3d:	5b                   	pop    %rbx
    8a3e:	5d                   	pop    %rbp
    8a3f:	41 5c                	pop    %r12
    8a41:	41 5d                	pop    %r13
    8a43:	41 5e                	pop    %r14
    8a45:	41 5f                	pop    %r15
    8a47:	c3                   	ret
    8a48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8a4f:	00 
    8a50:	66 85 c0             	test   %ax,%ax
    8a53:	0f 84 98 fe ff ff    	je     88f1 <f12+0xc71>
    8a59:	49 39 ef             	cmp    %rbp,%r15
    8a5c:	0f 82 a4 fe ff ff    	jb     8906 <f12+0xc86>
    8a62:	0f 1f 00             	nopl   (%rax)
    8a65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a6c:	00 00 00 00 
    8a70:	4d 85 ff             	test   %r15,%r15
    8a73:	0f 85 2a ff ff ff    	jne    89a3 <f12+0xd23>
    8a79:	8b 54 24 4c          	mov    0x4c(%rsp),%edx
    8a7d:	85 d2                	test   %edx,%edx
    8a7f:	4d 0f 45 e7          	cmovne %r15,%r12
    8a83:	66 90                	xchg   %ax,%ax
    8a85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a8c:	00 00 00 00 
    8a90:	48 85 ed             	test   %rbp,%rbp
    8a93:	0f 84 67 ff ff ff    	je     8a00 <f12+0xd80>
    8a99:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    8a9f:	48 83 ed 01          	sub    $0x1,%rbp
    8aa3:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8aa9:	85 c0                	test   %eax,%eax
    8aab:	0f 84 87 06 00 00    	je     9138 <f12+0x14b8>
    8ab1:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8ab8:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    8abf:	00 
    8ac0:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8ac4:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8ac8:	4c 8b 38             	mov    (%rax),%r15
    8acb:	4d 85 ff             	test   %r15,%r15
    8ace:	0f 84 3c 06 00 00    	je     9110 <f12+0x1490>
    8ad4:	49 8b 17             	mov    (%r15),%rdx
    8ad7:	48 f7 d2             	not    %rdx
    8ada:	48 89 10             	mov    %rdx,(%rax)
    8add:	49 83 f8 18          	cmp    $0x18,%r8
    8ae1:	76 2f                	jbe    8b12 <f12+0xe92>
    8ae3:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    8ae7:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    8aeb:	31 f6                	xor    %esi,%esi
    8aed:	4c 89 04 24          	mov    %r8,(%rsp)
    8af1:	48 c1 e8 03          	shr    $0x3,%rax
    8af5:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8afb:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8b02:	00 
    8b03:	e8 b8 a9 ff ff       	call   34c0 <memset@plt>
    8b08:	4c 8b 04 24          	mov    (%rsp),%r8
    8b0c:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8b12:	4c 89 c0             	mov    %r8,%rax
    8b15:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8b1c:	0f 82 8b 06 00 00    	jb     91ad <f12+0x152d>
    8b22:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8b29:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8b30:	73 07                	jae    8b39 <f12+0xeb9>
    8b32:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8b39:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8b3d:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    8b42:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8b49:	00 
    8b4a:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8b51:	00 
    8b52:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8b57:	4d 89 2f             	mov    %r13,(%r15)
    8b5a:	4c 89 f8             	mov    %r15,%rax
    8b5d:	4d 89 fe             	mov    %r15,%r14
    8b60:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8b64:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    8b69:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8b70:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8b77:	48 c1 e2 10          	shl    $0x10,%rdx
    8b7b:	48 39 d0             	cmp    %rdx,%rax
    8b7e:	0f 83 0c ff ff ff    	jae    8a90 <f12+0xe10>
    8b84:	48 89 c2             	mov    %rax,%rdx
    8b87:	48 c1 ea 10          	shr    $0x10,%rdx
    8b8b:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8b8f:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8b96:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8b9a:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8b9e:	4d 85 ff             	test   %r15,%r15
    8ba1:	0f 84 e9 fe ff ff    	je     8a90 <f12+0xe10>
    8ba7:	0f b6 32             	movzbl (%rdx),%esi
    8baa:	40 80 fe 02          	cmp    $0x2,%sil
    8bae:	0f 84 ac 05 00 00    	je     9160 <f12+0x14e0>
    8bb4:	40 80 fe 01          	cmp    $0x1,%sil
    8bb8:	0f 85 d2 fe ff ff    	jne    8a90 <f12+0xe10>
    8bbe:	8b 72 18             	mov    0x18(%rdx),%esi
    8bc1:	0f b7 c0             	movzwl %ax,%eax
    8bc4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8bc7:	48 0f af c6          	imul   %rsi,%rax
    8bcb:	48 c1 e8 20          	shr    $0x20,%rax
    8bcf:	48 39 d0             	cmp    %rdx,%rax
    8bd2:	0f 83 b8 fe ff ff    	jae    8a90 <f12+0xe10>
    8bd8:	49 01 c7             	add    %rax,%r15
    8bdb:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8bdf:	0f 84 9b 05 00 00    	je     9180 <f12+0x1500>
    8be5:	41 c6 07 01          	movb   $0x1,(%r15)
    8be9:	48 85 ed             	test   %rbp,%rbp
    8bec:	0f 85 a7 fe ff ff    	jne    8a99 <f12+0xe19>
    8bf2:	e9 09 fe ff ff       	jmp    8a00 <f12+0xd80>
    8bf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8bfe:	00 00 
    8c00:	66 85 c0             	test   %ax,%ax
    8c03:	0f 84 ae fa ff ff    	je     86b7 <f12+0xa37>
    8c09:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
    8c0f:	0f 84 a8 03 00 00    	je     8fbd <f12+0x133d>
    8c15:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    8c1a:	31 ed                	xor    %ebp,%ebp
    8c1c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c20:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c24:	48 89 ea             	mov    %rbp,%rdx
    8c27:	48 83 c5 01          	add    $0x1,%rbp
    8c2b:	48 85 c0             	test   %rax,%rax
    8c2e:	75 f0                	jne    8c20 <f12+0xfa0>
    8c30:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8c37:	ff ff 1f 
    8c3a:	48 39 e8             	cmp    %rbp,%rax
    8c3d:	0f 82 94 05 00 00    	jb     91d7 <f12+0x1557>
    8c43:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8c4a:	00 
    8c4b:	be 02 00 00 00       	mov    $0x2,%esi
    8c50:	e8 fb cd ff ff       	call   5a50 <fwp_heap_alloc>
    8c55:	49 39 ef             	cmp    %rbp,%r15
    8c58:	49 89 c4             	mov    %rax,%r12
    8c5b:	48 89 c2             	mov    %rax,%rdx
    8c5e:	49 0f 46 ef          	cmovbe %r15,%rbp
    8c62:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    8c67:	0f 1f 00             	nopl   (%rax)
    8c6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c71:	00 00 00 00 
    8c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c7c:	00 00 00 00 
    8c80:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8c84:	48 83 c2 08          	add    $0x8,%rdx
    8c88:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    8c8c:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c90:	48 85 c0             	test   %rax,%rax
    8c93:	75 eb                	jne    8c80 <f12+0x1000>
    8c95:	48 85 ed             	test   %rbp,%rbp
    8c98:	0f 84 31 03 00 00    	je     8fcf <f12+0x134f>
    8c9e:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
    8ca5:	00 
    8ca6:	e9 34 fa ff ff       	jmp    86df <f12+0xa5f>
    8cab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8cb0:	66 85 c0             	test   %ax,%ax
    8cb3:	0f 84 c9 f8 ff ff    	je     8582 <f12+0x902>
    8cb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8cc0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8cc7:	ff ff 1f 
    8cca:	4c 39 e0             	cmp    %r12,%rax
    8ccd:	0f 82 10 05 00 00    	jb     91e3 <f12+0x1563>
    8cd3:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    8cda:	00 
    8cdb:	be 01 00 00 00       	mov    $0x1,%esi
    8ce0:	e8 6b cd ff ff       	call   5a50 <fwp_heap_alloc>
    8ce5:	4c 89 20             	mov    %r12,(%rax)
    8ce8:	48 8b 15 49 8e 01 00 	mov    0x18e49(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8cef:	49 89 c5             	mov    %rax,%r13
    8cf2:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    8cf7:	48 2b 05 12 8e 01 00 	sub    0x18e12(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8cfe:	48 c1 e2 10          	shl    $0x10,%rdx
    8d02:	48 39 d0             	cmp    %rdx,%rax
    8d05:	73 57                	jae    8d5e <f12+0x10de>
    8d07:	48 89 c2             	mov    %rax,%rdx
    8d0a:	48 c1 ea 10          	shr    $0x10,%rdx
    8d0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d12:	48 8b 15 3f 8e 01 00 	mov    0x18e3f(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    8d19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d1d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8d21:	4d 85 ff             	test   %r15,%r15
    8d24:	74 38                	je     8d5e <f12+0x10de>
    8d26:	0f b6 0a             	movzbl (%rdx),%ecx
    8d29:	80 f9 02             	cmp    $0x2,%cl
    8d2c:	0f 84 ae 02 00 00    	je     8fe0 <f12+0x1360>
    8d32:	80 f9 01             	cmp    $0x1,%cl
    8d35:	75 27                	jne    8d5e <f12+0x10de>
    8d37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d3a:	0f b7 c0             	movzwl %ax,%eax
    8d3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d40:	48 0f af c1          	imul   %rcx,%rax
    8d44:	48 c1 e8 20          	shr    $0x20,%rax
    8d48:	48 39 d0             	cmp    %rdx,%rax
    8d4b:	73 11                	jae    8d5e <f12+0x10de>
    8d4d:	49 01 c7             	add    %rax,%r15
    8d50:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8d54:	0f 84 95 03 00 00    	je     90ef <f12+0x146f>
    8d5a:	41 c6 07 01          	movb   $0x1,(%r15)
    8d5e:	48 89 df             	mov    %rbx,%rdi
    8d61:	e9 2f f8 ff ff       	jmp    8595 <f12+0x915>
    8d66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d6d:	00 00 00 
    8d70:	48 c1 e6 10          	shl    $0x10,%rsi
    8d74:	48 09 fe             	or     %rdi,%rsi
    8d77:	bf 08 00 00 00       	mov    $0x8,%edi
    8d7c:	49 89 f4             	mov    %rsi,%r12
    8d7f:	be 02 00 00 00       	mov    $0x2,%esi
    8d84:	e8 c7 cc ff ff       	call   5a50 <fwp_heap_alloc>
    8d89:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8d90:	48 8b 15 a1 8d 01 00 	mov    0x18da1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8d97:	48 89 c3             	mov    %rax,%rbx
    8d9a:	48 2b 05 6f 8d 01 00 	sub    0x18d6f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8da1:	48 c1 e2 10          	shl    $0x10,%rdx
    8da5:	48 39 d0             	cmp    %rdx,%rax
    8da8:	73 76                	jae    8e20 <f12+0x11a0>
    8daa:	48 89 c2             	mov    %rax,%rdx
    8dad:	48 c1 ea 10          	shr    $0x10,%rdx
    8db1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8db5:	48 8b 15 9c 8d 01 00 	mov    0x18d9c(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    8dbc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8dc0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8dc4:	48 85 d2             	test   %rdx,%rdx
    8dc7:	0f 84 26 f3 ff ff    	je     80f3 <f12+0x473>
    8dcd:	0f b6 31             	movzbl (%rcx),%esi
    8dd0:	45 31 ed             	xor    %r13d,%r13d
    8dd3:	40 80 fe 02          	cmp    $0x2,%sil
    8dd7:	0f 85 8e f2 ff ff    	jne    806b <f12+0x3eb>
    8ddd:	66 85 c0             	test   %ax,%ax
    8de0:	0f 85 b0 f2 ff ff    	jne    8096 <f12+0x416>
    8de6:	e9 9f f2 ff ff       	jmp    808a <f12+0x40a>
    8deb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8df0:	48 89 d7             	mov    %rdx,%rdi
    8df3:	48 89 14 24          	mov    %rdx,(%rsp)
    8df7:	e8 14 c5 ff ff       	call   5310 <fwp_rc_forget_slot>
    8dfc:	48 8b 14 24          	mov    (%rsp),%rdx
    8e00:	e9 f5 fa ff ff       	jmp    88fa <f12+0xc7a>
    8e05:	0f 1f 00             	nopl   (%rax)
    8e08:	4d 85 ed             	test   %r13,%r13
    8e0b:	0f 85 8a f2 ff ff    	jne    809b <f12+0x41b>
    8e11:	0f 1f 40 00          	nopl   0x0(%rax)
    8e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e1c:	00 00 00 00 
    8e20:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    8e27:	00 
    8e28:	e9 30 f3 ff ff       	jmp    815d <f12+0x4dd>
    8e2d:	0f 1f 00             	nopl   (%rax)
    8e30:	4d 8d 4a 01          	lea    0x1(%r10),%r9
    8e34:	4c 39 ca             	cmp    %r9,%rdx
    8e37:	0f 8c 6d f4 ff ff    	jl     82aa <f12+0x62a>
    8e3d:	48 85 c9             	test   %rcx,%rcx
    8e40:	0f 84 b2 03 00 00    	je     91f8 <f12+0x1578>
    8e46:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    8e4b:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    8e52:	00 
    8e53:	31 f6                	xor    %esi,%esi
    8e55:	48 89 cf             	mov    %rcx,%rdi
    8e58:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8e5c:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    8e61:	e9 3a 01 00 00       	jmp    8fa0 <f12+0x1320>
    8e66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e6d:	00 00 00 
    8e70:	48 8d 3d 69 de ff ff 	lea    -0x2197(%rip),%rdi        # 6ce0 <fwp_tape_finish>
    8e77:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8e7c:	e8 2f 2e 00 00       	call   bcb0 <atexit>
    8e81:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8e86:	85 c0                	test   %eax,%eax
    8e88:	0f 85 81 03 00 00    	jne    920f <f12+0x158f>
    8e8e:	c7 05 c8 71 00 00 01 	movl   $0x1,0x71c8(%rip)        # 10060 <registered_finish.0>
    8e95:	00 00 00 
    8e98:	e9 12 ef ff ff       	jmp    7daf <f12+0x12f>
    8e9d:	0f 1f 00             	nopl   (%rax)
    8ea0:	66 85 c0             	test   %ax,%ax
    8ea3:	0f 85 b1 ee ff ff    	jne    7d5a <f12+0xda>
    8ea9:	e9 98 ee ff ff       	jmp    7d46 <f12+0xc6>
    8eae:	66 90                	xchg   %ax,%ax
    8eb0:	48 39 d5             	cmp    %rdx,%rbp
    8eb3:	0f 8f ee f3 ff ff    	jg     82a7 <f12+0x627>
    8eb9:	48 85 c9             	test   %rcx,%rcx
    8ebc:	0f 85 ef 01 00 00    	jne    90b1 <f12+0x1431>
    8ec2:	48 85 ed             	test   %rbp,%rbp
    8ec5:	0f 85 2d 03 00 00    	jne    91f8 <f12+0x1578>
    8ecb:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8ed2:	e9 8c f4 ff ff       	jmp    8363 <f12+0x6e3>
    8ed7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8ede:	00 00 
    8ee0:	66 85 c0             	test   %ax,%ax
    8ee3:	0f 85 f3 f5 ff ff    	jne    84dc <f12+0x85c>
    8ee9:	e9 de f5 ff ff       	jmp    84cc <f12+0x84c>
    8eee:	66 90                	xchg   %ax,%ax
    8ef0:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    8ef5:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    8efa:	e9 01 fb ff ff       	jmp    8a00 <f12+0xd80>
    8eff:	90                   	nop
    8f00:	66 0f 6f 0d 98 71 01 	movdqa 0x17198(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    8f07:	00 
    8f08:	48 c7 05 75 71 01 00 	movq   $0x0,0x17175(%rip)        # 20088 <fwp_tape_cached_bytes>
    8f0f:	00 00 00 00 
    8f13:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    8f19:	48 8b 05 a0 71 01 00 	mov    0x171a0(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    8f20:	66 0f 6f 0d 88 71 01 	movdqa 0x17188(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    8f27:	00 
    8f28:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    8f2d:	48 8b 05 94 71 01 00 	mov    0x17194(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    8f34:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    8f3a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8f3e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    8f43:	48 8b 05 86 71 01 00 	mov    0x17186(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    8f4a:	0f 29 0d 4f 71 01 00 	movaps %xmm1,0x1714f(%rip)        # 200a0 <fwp_tape_workspace>
    8f51:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    8f56:	0f 29 0d 53 71 01 00 	movaps %xmm1,0x17153(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    8f5d:	48 c7 05 68 71 01 00 	movq   $0x0,0x17168(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    8f64:	00 00 00 00 
    8f68:	0f 29 0d 51 71 01 00 	movaps %xmm1,0x17151(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    8f6f:	e9 91 ef ff ff       	jmp    7f05 <f12+0x285>
    8f74:	0f 1f 40 00          	nopl   0x0(%rax)
    8f78:	48 85 c9             	test   %rcx,%rcx
    8f7b:	0f 84 77 02 00 00    	je     91f8 <f12+0x1578>
    8f81:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    8f86:	48 8d 5d ff          	lea    -0x1(%rbp),%rbx
    8f8a:	31 f6                	xor    %esi,%esi
    8f8c:	48 89 cf             	mov    %rcx,%rdi
    8f8f:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    8f94:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    8f9b:	00 
    8f9c:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8fa0:	e8 1b a5 ff ff       	call   34c0 <memset@plt>
    8fa5:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8faa:	66 0f 6f 5c 24 10    	movdqa 0x10(%rsp),%xmm3
    8fb0:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
    8fb5:	48 89 c1             	mov    %rax,%rcx
    8fb8:	e9 92 f3 ff ff       	jmp    834f <f12+0x6cf>
    8fbd:	be 02 00 00 00       	mov    $0x2,%esi
    8fc2:	bf 08 00 00 00       	mov    $0x8,%edi
    8fc7:	e8 84 ca ff ff       	call   5a50 <fwp_heap_alloc>
    8fcc:	49 89 c4             	mov    %rax,%r12
    8fcf:	45 31 f6             	xor    %r14d,%r14d
    8fd2:	e9 29 fa ff ff       	jmp    8a00 <f12+0xd80>
    8fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8fde:	00 00 
    8fe0:	66 85 c0             	test   %ax,%ax
    8fe3:	0f 85 75 fd ff ff    	jne    8d5e <f12+0x10de>
    8fe9:	e9 62 fd ff ff       	jmp    8d50 <f12+0x10d0>
    8fee:	66 90                	xchg   %ax,%ax
    8ff0:	48 89 d7             	mov    %rdx,%rdi
    8ff3:	be 08 00 00 00       	mov    $0x8,%esi
    8ff8:	48 89 14 24          	mov    %rdx,(%rsp)
    8ffc:	e8 1f a5 ff ff       	call   3520 <calloc@plt>
    9001:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9007:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    900d:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    9012:	48 8b 14 24          	mov    (%rsp),%rdx
    9016:	48 89 c1             	mov    %rax,%rcx
    9019:	e9 00 f3 ff ff       	jmp    831e <f12+0x69e>
    901e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9022:	e9 78 ed ff ff       	jmp    7d9f <f12+0x11f>
    9027:	49 8b 4d 00          	mov    0x0(%r13),%rcx
    902b:	48 85 c9             	test   %rcx,%rcx
    902e:	78 8d                	js     8fbd <f12+0x133d>
    9030:	48 8b 35 01 8b 01 00 	mov    0x18b01(%rip),%rsi        # 21b38 <fwp_heap+0x13d8>
    9037:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    903c:	48 2b 05 cd 8a 01 00 	sub    0x18acd(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    9043:	48 c1 e6 10          	shl    $0x10,%rsi
    9047:	48 39 f0             	cmp    %rsi,%rax
    904a:	0f 83 6d ff ff ff    	jae    8fbd <f12+0x133d>
    9050:	48 89 c6             	mov    %rax,%rsi
    9053:	48 c1 ee 10          	shr    $0x10,%rsi
    9057:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    905b:	48 8b 35 f6 8a 01 00 	mov    0x18af6(%rip),%rsi        # 21b58 <fwp_heap+0x13f8>
    9062:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9066:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    906a:	48 85 ff             	test   %rdi,%rdi
    906d:	0f 84 4a ff ff ff    	je     8fbd <f12+0x133d>
    9073:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    9078:	49 89 cf             	mov    %rcx,%r15
    907b:	e9 05 f6 ff ff       	jmp    8685 <f12+0xa05>
    9080:	be 68 00 00 00       	mov    $0x68,%esi
    9085:	b9 01 00 00 00       	mov    $0x1,%ecx
    908a:	e9 ab ed ff ff       	jmp    7e3a <f12+0x1ba>
    908f:	48 89 d7             	mov    %rdx,%rdi
    9092:	48 89 14 24          	mov    %rdx,(%rsp)
    9096:	e8 75 c2 ff ff       	call   5310 <fwp_rc_forget_slot>
    909b:	48 8b 14 24          	mov    (%rsp),%rdx
    909f:	e9 ef ef ff ff       	jmp    8093 <f12+0x413>
    90a4:	4c 89 e7             	mov    %r12,%rdi
    90a7:	e8 64 c2 ff ff       	call   5310 <fwp_rc_forget_slot>
    90ac:	e9 26 f4 ff ff       	jmp    84d7 <f12+0x857>
    90b1:	48 85 ed             	test   %rbp,%rbp
    90b4:	0f 84 11 fe ff ff    	je     8ecb <f12+0x124b>
    90ba:	49 89 e9             	mov    %rbp,%r9
    90bd:	48 89 cf             	mov    %rcx,%rdi
    90c0:	31 f6                	xor    %esi,%esi
    90c2:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    90c7:	49 8d 59 ff          	lea    -0x1(%r9),%rbx
    90cb:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    90d2:	00 
    90d3:	0f 29 14 24          	movaps %xmm2,(%rsp)
    90d7:	e8 e4 a3 ff ff       	call   34c0 <memset@plt>
    90dc:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    90e1:	66 0f 6f 5c 24 10    	movdqa 0x10(%rsp),%xmm3
    90e7:	48 89 c1             	mov    %rax,%rcx
    90ea:	e9 58 f2 ff ff       	jmp    8347 <f12+0x6c7>
    90ef:	4c 89 ff             	mov    %r15,%rdi
    90f2:	e8 19 c2 ff ff       	call   5310 <fwp_rc_forget_slot>
    90f7:	e9 5e fc ff ff       	jmp    8d5a <f12+0x10da>
    90fc:	e8 ef c0 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9101:	e9 54 ec ff ff       	jmp    7d5a <f12+0xda>
    9106:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    910d:	00 00 00 
    9110:	4c 8b 78 08          	mov    0x8(%rax),%r15
    9114:	4d 85 ff             	test   %r15,%r15
    9117:	74 1f                	je     9138 <f12+0x14b8>
    9119:	48 8b 50 10          	mov    0x10(%rax),%rdx
    911d:	4c 29 fa             	sub    %r15,%rdx
    9120:	4c 39 c2             	cmp    %r8,%rdx
    9123:	72 13                	jb     9138 <f12+0x14b8>
    9125:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    9129:	48 89 50 08          	mov    %rdx,0x8(%rax)
    912d:	e9 ab f9 ff ff       	jmp    8add <f12+0xe5d>
    9132:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9138:	31 f6                	xor    %esi,%esi
    913a:	bf 18 00 00 00       	mov    $0x18,%edi
    913f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9144:	e8 07 c9 ff ff       	call   5a50 <fwp_heap_alloc>
    9149:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    914e:	49 89 c7             	mov    %rax,%r15
    9151:	e9 fc f9 ff ff       	jmp    8b52 <f12+0xed2>
    9156:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    915d:	00 00 00 
    9160:	66 85 c0             	test   %ax,%ax
    9163:	0f 85 27 f9 ff ff    	jne    8a90 <f12+0xe10>
    9169:	41 80 3f ff          	cmpb   $0xff,(%r15)
    916d:	0f 85 72 fa ff ff    	jne    8be5 <f12+0xf65>
    9173:	66 90                	xchg   %ax,%ax
    9175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    917c:	00 00 00 00 
    9180:	4c 89 ff             	mov    %r15,%rdi
    9183:	e8 88 c1 ff ff       	call   5310 <fwp_rc_forget_slot>
    9188:	e9 58 fa ff ff       	jmp    8be5 <f12+0xf65>
    918d:	45 31 ff             	xor    %r15d,%r15d
    9190:	e9 44 f6 ff ff       	jmp    87d9 <f12+0xb59>
    9195:	48 8d 3d 68 2f 00 00 	lea    0x2f68(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    919c:	e8 ff af ff ff       	call   41a0 <fwp_trap>
    91a1:	48 8d 3d 18 36 00 00 	lea    0x3618(%rip),%rdi        # c7c0 <_IO_stdin_used+0x7c0>
    91a8:	e8 f3 af ff ff       	call   41a0 <fwp_trap>
    91ad:	e8 fe aa ff ff       	call   3cb0 <fwp_heap_oom>
    91b2:	48 8d 3d 0f 37 00 00 	lea    0x370f(%rip),%rdi        # c8c8 <_IO_stdin_used+0x8c8>
    91b9:	e8 e2 af ff ff       	call   41a0 <fwp_trap>
    91be:	e8 3d a5 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    91c3:	45 31 e4             	xor    %r12d,%r12d
    91c6:	e9 04 fe ff ff       	jmp    8fcf <f12+0x134f>
    91cb:	48 8d 3d 5b 2f 00 00 	lea    0x2f5b(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    91d2:	e8 c9 af ff ff       	call   41a0 <fwp_trap>
    91d7:	48 8d 3d 69 2f 00 00 	lea    0x2f69(%rip),%rdi        # c147 <_IO_stdin_used+0x147>
    91de:	e8 bd af ff ff       	call   41a0 <fwp_trap>
    91e3:	48 8d 3d 6b 2f 00 00 	lea    0x2f6b(%rip),%rdi        # c155 <_IO_stdin_used+0x155>
    91ea:	e8 b1 af ff ff       	call   41a0 <fwp_trap>
    91ef:	4d 85 c9             	test   %r9,%r9
    91f2:	0f 84 48 f1 ff ff    	je     8340 <f12+0x6c0>
    91f8:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    91ff:	00 
    9200:	4c 89 e7             	mov    %r12,%rdi
    9203:	48 89 05 ee 91 01 00 	mov    %rax,0x191ee(%rip)        # 223f8 <fwp_cleanups>
    920a:	e8 21 bc ff ff       	call   4e30 <fwp_tape_buffers_release>
    920f:	48 8b 0d 2a 6e 00 00 	mov    0x6e2a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    9216:	ba 13 00 00 00       	mov    $0x13,%edx
    921b:	be 01 00 00 00       	mov    $0x1,%esi
    9220:	48 8d 3d e1 2d 00 00 	lea    0x2de1(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    9227:	e8 54 a4 ff ff       	call   3680 <fwrite@plt>
    922c:	31 ff                	xor    %edi,%edi
    922e:	e8 8d a3 ff ff       	call   35c0 <fflush@plt>
    9233:	bf 66 00 00 00       	mov    $0x66,%edi
    9238:	e8 63 a4 ff ff       	call   36a0 <_Exit@plt>
    923d:	48 8d 3d 54 36 00 00 	lea    0x3654(%rip),%rdi        # c898 <_IO_stdin_used+0x898>
    9244:	e8 57 af ff ff       	call   41a0 <fwp_trap>
    9249:	48 8d 3d 18 36 00 00 	lea    0x3618(%rip),%rdi        # c868 <_IO_stdin_used+0x868>
    9250:	e8 4b af ff ff       	call   41a0 <fwp_trap>
    9255:	e8 06 a2 ff ff       	call   3460 <__stack_chk_fail@plt>
    925a:	48 8d 3d a7 35 00 00 	lea    0x35a7(%rip),%rdi        # c808 <_IO_stdin_used+0x808>
    9261:	e8 3a af ff ff       	call   41a0 <fwp_trap>
    9266:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    926d:	00 00 00 

0000000000009270 <fwp_owned_entry12>:
    9270:	f3 0f 1e fa          	endbr64
    9274:	48 8b 3f             	mov    (%rdi),%rdi
    9277:	e9 04 ea ff ff       	jmp    7c80 <f12>
    927c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009280 <e12>:
    9280:	f3 0f 1e fa          	endbr64
    9284:	53                   	push   %rbx
    9285:	48 8b 1f             	mov    (%rdi),%rbx
    9288:	48 89 df             	mov    %rbx,%rdi
    928b:	e8 90 d3 ff ff       	call   6620 <fwp_rc_share>
    9290:	48 89 df             	mov    %rbx,%rdi
    9293:	e8 e8 e9 ff ff       	call   7c80 <f12>
    9298:	48 89 c3             	mov    %rax,%rbx
    929b:	48 89 c7             	mov    %rax,%rdi
    929e:	e8 7d d3 ff ff       	call   6620 <fwp_rc_share>
    92a3:	48 89 d8             	mov    %rbx,%rax
    92a6:	5b                   	pop    %rbx
    92a7:	c3                   	ret
    92a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92af:	00 

00000000000092b0 <fwp_drop2>:
    92b0:	48 8b 0d 81 88 01 00 	mov    0x18881(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    92b7:	48 89 f8             	mov    %rdi,%rax
    92ba:	48 2b 05 4f 88 01 00 	sub    0x1884f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    92c1:	48 c1 e1 10          	shl    $0x10,%rcx
    92c5:	48 39 c8             	cmp    %rcx,%rax
    92c8:	0f 83 42 01 00 00    	jae    9410 <fwp_drop2+0x160>
    92ce:	48 83 ec 18          	sub    $0x18,%rsp
    92d2:	48 89 fa             	mov    %rdi,%rdx
    92d5:	4c 8d 05 84 74 01 00 	lea    0x17484(%rip),%r8        # 20760 <fwp_heap>
    92dc:	48 89 c1             	mov    %rax,%rcx
    92df:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    92e6:	48 c1 e9 10          	shr    $0x10,%rcx
    92ea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    92ee:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    92f2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    92f6:	48 85 c9             	test   %rcx,%rcx
    92f9:	74 40                	je     933b <fwp_drop2+0x8b>
    92fb:	0f b6 3e             	movzbl (%rsi),%edi
    92fe:	40 80 ff 02          	cmp    $0x2,%dil
    9302:	74 3c                	je     9340 <fwp_drop2+0x90>
    9304:	40 80 ff 01          	cmp    $0x1,%dil
    9308:	75 31                	jne    933b <fwp_drop2+0x8b>
    930a:	8b 7e 18             	mov    0x18(%rsi),%edi
    930d:	0f b7 c0             	movzwl %ax,%eax
    9310:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9313:	48 0f af c7          	imul   %rdi,%rax
    9317:	48 c1 e8 20          	shr    $0x20,%rax
    931b:	48 39 f0             	cmp    %rsi,%rax
    931e:	73 1b                	jae    933b <fwp_drop2+0x8b>
    9320:	48 01 c1             	add    %rax,%rcx
    9323:	0f b6 01             	movzbl (%rcx),%eax
    9326:	84 c0                	test   %al,%al
    9328:	74 11                	je     933b <fwp_drop2+0x8b>
    932a:	3c 01                	cmp    $0x1,%al
    932c:	74 22                	je     9350 <fwp_drop2+0xa0>
    932e:	3c ff                	cmp    $0xff,%al
    9330:	0f 84 0a 01 00 00    	je     9440 <fwp_drop2+0x190>
    9336:	83 e8 01             	sub    $0x1,%eax
    9339:	88 01                	mov    %al,(%rcx)
    933b:	48 83 c4 18          	add    $0x18,%rsp
    933f:	c3                   	ret
    9340:	66 85 c0             	test   %ax,%ax
    9343:	74 de                	je     9323 <fwp_drop2+0x73>
    9345:	48 83 c4 18          	add    $0x18,%rsp
    9349:	c3                   	ret
    934a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9350:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    9354:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    935b:	48 89 f8             	mov    %rdi,%rax
    935e:	48 c1 e1 10          	shl    $0x10,%rcx
    9362:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9369:	48 39 c8             	cmp    %rcx,%rax
    936c:	73 62                	jae    93d0 <fwp_drop2+0x120>
    936e:	48 89 c1             	mov    %rax,%rcx
    9371:	48 c1 e9 10          	shr    $0x10,%rcx
    9375:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9379:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    937d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9381:	48 85 c9             	test   %rcx,%rcx
    9384:	74 4a                	je     93d0 <fwp_drop2+0x120>
    9386:	44 0f b6 0e          	movzbl (%rsi),%r9d
    938a:	41 80 f9 02          	cmp    $0x2,%r9b
    938e:	0f 84 9c 00 00 00    	je     9430 <fwp_drop2+0x180>
    9394:	41 80 f9 01          	cmp    $0x1,%r9b
    9398:	75 36                	jne    93d0 <fwp_drop2+0x120>
    939a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    939e:	0f b7 c0             	movzwl %ax,%eax
    93a1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    93a4:	49 0f af c1          	imul   %r9,%rax
    93a8:	48 c1 e8 20          	shr    $0x20,%rax
    93ac:	48 39 f0             	cmp    %rsi,%rax
    93af:	73 1f                	jae    93d0 <fwp_drop2+0x120>
    93b1:	48 01 c1             	add    %rax,%rcx
    93b4:	0f b6 01             	movzbl (%rcx),%eax
    93b7:	84 c0                	test   %al,%al
    93b9:	74 15                	je     93d0 <fwp_drop2+0x120>
    93bb:	3c 01                	cmp    $0x1,%al
    93bd:	74 59                	je     9418 <fwp_drop2+0x168>
    93bf:	3c ff                	cmp    $0xff,%al
    93c1:	0f 84 ff 00 00 00    	je     94c6 <fwp_drop2+0x216>
    93c7:	83 e8 01             	sub    $0x1,%eax
    93ca:	88 01                	mov    %al,(%rcx)
    93cc:	0f 1f 40 00          	nopl   0x0(%rax)
    93d0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    93d4:	48 89 d7             	mov    %rdx,%rdi
    93d7:	48 89 0c 24          	mov    %rcx,(%rsp)
    93db:	e8 c0 d2 ff ff       	call   66a0 <fwp_rc_free_arr>
    93e0:	4c 8d 05 79 73 01 00 	lea    0x17379(%rip),%r8        # 20760 <fwp_heap>
    93e7:	48 8b 04 24          	mov    (%rsp),%rax
    93eb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    93f2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    93f9:	48 c1 e2 10          	shl    $0x10,%rdx
    93fd:	48 39 d0             	cmp    %rdx,%rax
    9400:	0f 83 35 ff ff ff    	jae    933b <fwp_drop2+0x8b>
    9406:	48 8b 14 24          	mov    (%rsp),%rdx
    940a:	e9 cd fe ff ff       	jmp    92dc <fwp_drop2+0x2c>
    940f:	90                   	nop
    9410:	c3                   	ret
    9411:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9418:	48 89 14 24          	mov    %rdx,(%rsp)
    941c:	e8 7f d2 ff ff       	call   66a0 <fwp_rc_free_arr>
    9421:	48 8b 14 24          	mov    (%rsp),%rdx
    9425:	eb a9                	jmp    93d0 <fwp_drop2+0x120>
    9427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    942e:	00 00 
    9430:	66 85 c0             	test   %ax,%ax
    9433:	75 9b                	jne    93d0 <fwp_drop2+0x120>
    9435:	e9 7a ff ff ff       	jmp    93b4 <fwp_drop2+0x104>
    943a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9440:	48 89 c8             	mov    %rcx,%rax
    9443:	48 c1 e8 11          	shr    $0x11,%rax
    9447:	48 31 c8             	xor    %rcx,%rax
    944a:	48 89 c2             	mov    %rax,%rdx
    944d:	48 c1 ea 09          	shr    $0x9,%rdx
    9451:	48 31 d0             	xor    %rdx,%rax
    9454:	0f b6 d0             	movzbl %al,%edx
    9457:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    945e:	00 
    945f:	48 85 c0             	test   %rax,%rax
    9462:	75 29                	jne    948d <fwp_drop2+0x1dd>
    9464:	e9 e3 00 00 00       	jmp    954c <fwp_drop2+0x29c>
    9469:	90                   	nop
    946a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9471:	00 00 00 00 
    9475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    947c:	00 00 00 00 
    9480:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9484:	48 85 c0             	test   %rax,%rax
    9487:	0f 84 bf 00 00 00    	je     954c <fwp_drop2+0x29c>
    948d:	48 89 c2             	mov    %rax,%rdx
    9490:	48 39 08             	cmp    %rcx,(%rax)
    9493:	75 eb                	jne    9480 <fwp_drop2+0x1d0>
    9495:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9499:	48 83 ea 01          	sub    $0x1,%rdx
    949d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    94a1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    94a8:	0f 85 8d fe ff ff    	jne    933b <fwp_drop2+0x8b>
    94ae:	48 89 cf             	mov    %rcx,%rdi
    94b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    94b5:	e8 56 be ff ff       	call   5310 <fwp_rc_forget_slot>
    94ba:	48 8b 0c 24          	mov    (%rsp),%rcx
    94be:	c6 01 fe             	movb   $0xfe,(%rcx)
    94c1:	e9 75 fe ff ff       	jmp    933b <fwp_drop2+0x8b>
    94c6:	48 89 ce             	mov    %rcx,%rsi
    94c9:	48 c1 ee 11          	shr    $0x11,%rsi
    94cd:	48 31 ce             	xor    %rcx,%rsi
    94d0:	48 89 f0             	mov    %rsi,%rax
    94d3:	48 c1 e8 09          	shr    $0x9,%rax
    94d7:	48 31 c6             	xor    %rax,%rsi
    94da:	40 0f b6 f6          	movzbl %sil,%esi
    94de:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    94e5:	00 
    94e6:	48 85 c0             	test   %rax,%rax
    94e9:	75 1e                	jne    9509 <fwp_drop2+0x259>
    94eb:	eb 5f                	jmp    954c <fwp_drop2+0x29c>
    94ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    94f4:	00 
    94f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94fc:	00 00 00 00 
    9500:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9504:	48 85 c0             	test   %rax,%rax
    9507:	74 43                	je     954c <fwp_drop2+0x29c>
    9509:	48 89 c6             	mov    %rax,%rsi
    950c:	48 39 08             	cmp    %rcx,(%rax)
    950f:	75 ef                	jne    9500 <fwp_drop2+0x250>
    9511:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9515:	48 83 ee 01          	sub    $0x1,%rsi
    9519:	48 89 70 08          	mov    %rsi,0x8(%rax)
    951d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    9524:	0f 85 a6 fe ff ff    	jne    93d0 <fwp_drop2+0x120>
    952a:	48 89 cf             	mov    %rcx,%rdi
    952d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    9532:	48 89 0c 24          	mov    %rcx,(%rsp)
    9536:	e8 d5 bd ff ff       	call   5310 <fwp_rc_forget_slot>
    953b:	48 8b 0c 24          	mov    (%rsp),%rcx
    953f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9544:	c6 01 fe             	movb   $0xfe,(%rcx)
    9547:	e9 84 fe ff ff       	jmp    93d0 <fwp_drop2+0x120>
    954c:	48 8d 3d 45 32 00 00 	lea    0x3245(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    9553:	e8 48 ac ff ff       	call   41a0 <fwp_trap>
    9558:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    955f:	00 

0000000000009560 <fwp_arg_drop23>:
    9560:	f3 0f 1e fa          	endbr64
    9564:	85 f6                	test   %esi,%esi
    9566:	75 04                	jne    956c <fwp_arg_drop23+0xc>
    9568:	85 d2                	test   %edx,%edx
    956a:	75 04                	jne    9570 <fwp_arg_drop23+0x10>
    956c:	c3                   	ret
    956d:	0f 1f 00             	nopl   (%rax)
    9570:	48 8b 3f             	mov    (%rdi),%rdi
    9573:	e9 38 fd ff ff       	jmp    92b0 <fwp_drop2>
    9578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    957f:	00 

0000000000009580 <fwp_caps23>:
    9580:	f3 0f 1e fa          	endbr64
    9584:	48 83 ec 18          	sub    $0x18,%rsp
    9588:	8b 57 04             	mov    0x4(%rdi),%edx
    958b:	48 89 f8             	mov    %rdi,%rax
    958e:	85 d2                	test   %edx,%edx
    9590:	0f 84 9a 00 00 00    	je     9630 <fwp_caps23+0xb0>
    9596:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    959a:	85 f6                	test   %esi,%esi
    959c:	0f 85 9e 00 00 00    	jne    9640 <fwp_caps23+0xc0>
    95a2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    95a7:	e8 04 fd ff ff       	call   92b0 <fwp_drop2>
    95ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    95b1:	48 8b 0d 80 85 01 00 	mov    0x18580(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    95b8:	48 89 c2             	mov    %rax,%rdx
    95bb:	48 2b 15 4e 85 01 00 	sub    0x1854e(%rip),%rdx        # 21b10 <fwp_heap+0x13b0>
    95c2:	48 c1 e1 10          	shl    $0x10,%rcx
    95c6:	48 39 ca             	cmp    %rcx,%rdx
    95c9:	73 6d                	jae    9638 <fwp_caps23+0xb8>
    95cb:	48 89 d1             	mov    %rdx,%rcx
    95ce:	48 c1 e9 10          	shr    $0x10,%rcx
    95d2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    95d6:	48 8b 0d 7b 85 01 00 	mov    0x1857b(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    95dd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    95e1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    95e5:	48 85 f6             	test   %rsi,%rsi
    95e8:	74 4e                	je     9638 <fwp_caps23+0xb8>
    95ea:	0f b6 39             	movzbl (%rcx),%edi
    95ed:	40 80 ff 02          	cmp    $0x2,%dil
    95f1:	0f 84 b9 00 00 00    	je     96b0 <fwp_caps23+0x130>
    95f7:	40 80 ff 01          	cmp    $0x1,%dil
    95fb:	75 3b                	jne    9638 <fwp_caps23+0xb8>
    95fd:	8b 79 18             	mov    0x18(%rcx),%edi
    9600:	0f b7 d2             	movzwl %dx,%edx
    9603:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9606:	48 0f af d7          	imul   %rdi,%rdx
    960a:	48 c1 ea 20          	shr    $0x20,%rdx
    960e:	48 39 ca             	cmp    %rcx,%rdx
    9611:	73 25                	jae    9638 <fwp_caps23+0xb8>
    9613:	48 01 d6             	add    %rdx,%rsi
    9616:	80 3e 01             	cmpb   $0x1,(%rsi)
    9619:	75 1d                	jne    9638 <fwp_caps23+0xb8>
    961b:	48 89 c7             	mov    %rax,%rdi
    961e:	48 83 c4 18          	add    $0x18,%rsp
    9622:	e9 29 bf ff ff       	jmp    5550 <fwp_mem_free>
    9627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    962e:	00 00 
    9630:	85 f6                	test   %esi,%esi
    9632:	0f 84 79 ff ff ff    	je     95b1 <fwp_caps23+0x31>
    9638:	48 83 c4 18          	add    $0x18,%rsp
    963c:	c3                   	ret
    963d:	0f 1f 00             	nopl   (%rax)
    9640:	48 8b 05 f1 84 01 00 	mov    0x184f1(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    9647:	48 2b 3d c2 84 01 00 	sub    0x184c2(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    964e:	48 c1 e0 10          	shl    $0x10,%rax
    9652:	48 39 c7             	cmp    %rax,%rdi
    9655:	73 e1                	jae    9638 <fwp_caps23+0xb8>
    9657:	48 89 f8             	mov    %rdi,%rax
    965a:	48 c1 e8 10          	shr    $0x10,%rax
    965e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9662:	48 8b 05 ef 84 01 00 	mov    0x184ef(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    9669:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    966d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9671:	48 85 c0             	test   %rax,%rax
    9674:	74 c2                	je     9638 <fwp_caps23+0xb8>
    9676:	0f b6 0a             	movzbl (%rdx),%ecx
    9679:	80 f9 02             	cmp    $0x2,%cl
    967c:	74 42                	je     96c0 <fwp_caps23+0x140>
    967e:	80 f9 01             	cmp    $0x1,%cl
    9681:	75 b5                	jne    9638 <fwp_caps23+0xb8>
    9683:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9686:	0f b7 ff             	movzwl %di,%edi
    9689:	8b 52 1c             	mov    0x1c(%rdx),%edx
    968c:	48 0f af f9          	imul   %rcx,%rdi
    9690:	48 c1 ef 20          	shr    $0x20,%rdi
    9694:	48 39 d7             	cmp    %rdx,%rdi
    9697:	73 9f                	jae    9638 <fwp_caps23+0xb8>
    9699:	48 01 f8             	add    %rdi,%rax
    969c:	0f b6 10             	movzbl (%rax),%edx
    969f:	84 d2                	test   %dl,%dl
    96a1:	74 95                	je     9638 <fwp_caps23+0xb8>
    96a3:	80 fa fd             	cmp    $0xfd,%dl
    96a6:	77 23                	ja     96cb <fwp_caps23+0x14b>
    96a8:	83 c2 01             	add    $0x1,%edx
    96ab:	88 10                	mov    %dl,(%rax)
    96ad:	eb 89                	jmp    9638 <fwp_caps23+0xb8>
    96af:	90                   	nop
    96b0:	66 85 d2             	test   %dx,%dx
    96b3:	0f 85 7f ff ff ff    	jne    9638 <fwp_caps23+0xb8>
    96b9:	e9 58 ff ff ff       	jmp    9616 <fwp_caps23+0x96>
    96be:	66 90                	xchg   %ax,%ax
    96c0:	66 85 ff             	test   %di,%di
    96c3:	0f 85 6f ff ff ff    	jne    9638 <fwp_caps23+0xb8>
    96c9:	eb d1                	jmp    969c <fwp_caps23+0x11c>
    96cb:	48 89 c7             	mov    %rax,%rdi
    96ce:	48 83 c4 18          	add    $0x18,%rsp
    96d2:	e9 19 bb ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    96d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96de:	00 00 

00000000000096e0 <f23>:
    96e0:	41 57                	push   %r15
    96e2:	41 56                	push   %r14
    96e4:	41 55                	push   %r13
    96e6:	41 54                	push   %r12
    96e8:	55                   	push   %rbp
    96e9:	53                   	push   %rbx
    96ea:	48 83 ec 38          	sub    $0x38,%rsp
    96ee:	48 8b 15 43 84 01 00 	mov    0x18443(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    96f5:	48 8b 0d 14 84 01 00 	mov    0x18414(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    96fc:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9703:	00 00 
    9705:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    970a:	49 89 fc             	mov    %rdi,%r12
    970d:	48 c1 e2 10          	shl    $0x10,%rdx
    9711:	48 85 ff             	test   %rdi,%rdi
    9714:	0f 84 bc 02 00 00    	je     99d6 <f23+0x2f6>
    971a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    971f:	48 89 d8             	mov    %rbx,%rax
    9722:	48 29 c8             	sub    %rcx,%rax
    9725:	48 39 d0             	cmp    %rdx,%rax
    9728:	0f 83 72 03 00 00    	jae    9aa0 <f23+0x3c0>
    972e:	48 89 c2             	mov    %rax,%rdx
    9731:	48 c1 ea 10          	shr    $0x10,%rdx
    9735:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9739:	48 8b 15 18 84 01 00 	mov    0x18418(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    9740:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9744:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9748:	48 85 ff             	test   %rdi,%rdi
    974b:	0f 84 4f 03 00 00    	je     9aa0 <f23+0x3c0>
    9751:	0f b6 0a             	movzbl (%rdx),%ecx
    9754:	80 f9 02             	cmp    $0x2,%cl
    9757:	0f 84 53 02 00 00    	je     99b0 <f23+0x2d0>
    975d:	80 f9 01             	cmp    $0x1,%cl
    9760:	75 24                	jne    9786 <f23+0xa6>
    9762:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9765:	0f b7 c0             	movzwl %ax,%eax
    9768:	8b 52 1c             	mov    0x1c(%rdx),%edx
    976b:	48 0f af c1          	imul   %rcx,%rax
    976f:	48 c1 e8 20          	shr    $0x20,%rax
    9773:	48 39 d0             	cmp    %rdx,%rax
    9776:	73 0e                	jae    9786 <f23+0xa6>
    9778:	48 01 c7             	add    %rax,%rdi
    977b:	0f b6 07             	movzbl (%rdi),%eax
    977e:	84 c0                	test   %al,%al
    9780:	0f 85 ca 02 00 00    	jne    9a50 <f23+0x370>
    9786:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    978b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    9790:	ba 01 00 00 00       	mov    $0x1,%edx
    9795:	48 85 db             	test   %rbx,%rbx
    9798:	74 13                	je     97ad <f23+0xcd>
    979a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    97a0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    97a4:	48 83 c2 01          	add    $0x1,%rdx
    97a8:	48 85 db             	test   %rbx,%rbx
    97ab:	75 f3                	jne    97a0 <f23+0xc0>
    97ad:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    97b2:	48 85 c0             	test   %rax,%rax
    97b5:	0f 84 15 03 00 00    	je     9ad0 <f23+0x3f0>
    97bb:	31 db                	xor    %ebx,%ebx
    97bd:	0f 1f 00             	nopl   (%rax)
    97c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    97c4:	48 83 c3 01          	add    $0x1,%rbx
    97c8:	48 85 c0             	test   %rax,%rax
    97cb:	75 f3                	jne    97c0 <f23+0xe0>
    97cd:	48 39 d3             	cmp    %rdx,%rbx
    97d0:	48 0f 47 da          	cmova  %rdx,%rbx
    97d4:	48 89 d8             	mov    %rbx,%rax
    97d7:	48 c1 e8 3c          	shr    $0x3c,%rax
    97db:	0f 85 8f 03 00 00    	jne    9b70 <f23+0x490>
    97e1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    97e5:	be 02 00 00 00       	mov    $0x2,%esi
    97ea:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    97f1:	00 
    97f2:	e8 59 c2 ff ff       	call   5a50 <fwp_heap_alloc>
    97f7:	48 89 28             	mov    %rbp,(%rax)
    97fa:	48 8b 15 37 83 01 00 	mov    0x18337(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9801:	49 89 c6             	mov    %rax,%r14
    9804:	48 2b 05 05 83 01 00 	sub    0x18305(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    980b:	48 c1 e2 10          	shl    $0x10,%rdx
    980f:	48 39 d0             	cmp    %rdx,%rax
    9812:	73 57                	jae    986b <f23+0x18b>
    9814:	48 89 c2             	mov    %rax,%rdx
    9817:	48 c1 ea 10          	shr    $0x10,%rdx
    981b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    981f:	48 8b 15 32 83 01 00 	mov    0x18332(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    9826:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    982a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    982e:	48 85 ed             	test   %rbp,%rbp
    9831:	74 38                	je     986b <f23+0x18b>
    9833:	0f b6 0a             	movzbl (%rdx),%ecx
    9836:	80 f9 02             	cmp    $0x2,%cl
    9839:	0f 84 51 02 00 00    	je     9a90 <f23+0x3b0>
    983f:	80 f9 01             	cmp    $0x1,%cl
    9842:	75 27                	jne    986b <f23+0x18b>
    9844:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9847:	0f b7 c0             	movzwl %ax,%eax
    984a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    984d:	48 0f af c1          	imul   %rcx,%rax
    9851:	48 c1 e8 20          	shr    $0x20,%rax
    9855:	48 39 d0             	cmp    %rdx,%rax
    9858:	73 11                	jae    986b <f23+0x18b>
    985a:	48 01 c5             	add    %rax,%rbp
    985d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9861:	0f 84 d5 02 00 00    	je     9b3c <f23+0x45c>
    9867:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    986b:	48 85 db             	test   %rbx,%rbx
    986e:	74 5d                	je     98cd <f23+0x1ed>
    9870:	48 c1 e3 04          	shl    $0x4,%rbx
    9874:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    9879:	4c 89 f5             	mov    %r14,%rbp
    987c:	4d 89 e5             	mov    %r12,%r13
    987f:	4c 01 f3             	add    %r14,%rbx
    9882:	0f 1f 00             	nopl   (%rax)
    9885:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    988c:	00 00 00 00 
    9890:	49 8b 45 08          	mov    0x8(%r13),%rax
    9894:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    9898:	48 83 c5 10          	add    $0x10,%rbp
    989c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    98a1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    98a5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    98a9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    98ae:	e8 fd c9 ff ff       	call   62b0 <w107>
    98b3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    98b8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    98bc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    98c0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    98c4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    98c8:	48 39 dd             	cmp    %rbx,%rbp
    98cb:	75 c3                	jne    9890 <f23+0x1b0>
    98cd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    98d2:	e8 d9 f9 ff ff       	call   92b0 <fwp_drop2>
    98d7:	4c 89 e7             	mov    %r12,%rdi
    98da:	e8 d1 f9 ff ff       	call   92b0 <fwp_drop2>
    98df:	4c 89 f7             	mov    %r14,%rdi
    98e2:	e8 89 cb ff ff       	call   6470 <w164.constprop.0>
    98e7:	4c 89 f7             	mov    %r14,%rdi
    98ea:	48 89 c3             	mov    %rax,%rbx
    98ed:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    98f3:	e8 78 de ff ff       	call   7770 <fwp_drop4>
    98f8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    98fe:	66 48 0f 6e db       	movq   %rbx,%xmm3
    9903:	31 ff                	xor    %edi,%edi
    9905:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    990a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    990e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9913:	e8 d8 cb ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    9918:	48 8b 15 19 82 01 00 	mov    0x18219(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    991f:	48 89 c5             	mov    %rax,%rbp
    9922:	48 2b 05 e7 81 01 00 	sub    0x181e7(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    9929:	48 c1 e2 10          	shl    $0x10,%rdx
    992d:	48 39 d0             	cmp    %rdx,%rax
    9930:	73 55                	jae    9987 <f23+0x2a7>
    9932:	48 89 c2             	mov    %rax,%rdx
    9935:	48 c1 ea 10          	shr    $0x10,%rdx
    9939:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    993d:	48 8b 15 14 82 01 00 	mov    0x18214(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    9944:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9948:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    994c:	48 85 db             	test   %rbx,%rbx
    994f:	74 36                	je     9987 <f23+0x2a7>
    9951:	0f b6 0a             	movzbl (%rdx),%ecx
    9954:	80 f9 02             	cmp    $0x2,%cl
    9957:	0f 84 1b 01 00 00    	je     9a78 <f23+0x398>
    995d:	80 f9 01             	cmp    $0x1,%cl
    9960:	75 25                	jne    9987 <f23+0x2a7>
    9962:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9965:	0f b7 c0             	movzwl %ax,%eax
    9968:	8b 52 1c             	mov    0x1c(%rdx),%edx
    996b:	48 0f af c1          	imul   %rcx,%rax
    996f:	48 c1 e8 20          	shr    $0x20,%rax
    9973:	48 39 d0             	cmp    %rdx,%rax
    9976:	73 0f                	jae    9987 <f23+0x2a7>
    9978:	48 01 c3             	add    %rax,%rbx
    997b:	80 3b ff             	cmpb   $0xff,(%rbx)
    997e:	0f 84 ab 01 00 00    	je     9b2f <f23+0x44f>
    9984:	c6 03 01             	movb   $0x1,(%rbx)
    9987:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    998c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9993:	00 00 
    9995:	0f 85 d0 01 00 00    	jne    9b6b <f23+0x48b>
    999b:	48 83 c4 38          	add    $0x38,%rsp
    999f:	48 89 e8             	mov    %rbp,%rax
    99a2:	5b                   	pop    %rbx
    99a3:	5d                   	pop    %rbp
    99a4:	41 5c                	pop    %r12
    99a6:	41 5d                	pop    %r13
    99a8:	41 5e                	pop    %r14
    99aa:	41 5f                	pop    %r15
    99ac:	c3                   	ret
    99ad:	0f 1f 00             	nopl   (%rax)
    99b0:	66 85 c0             	test   %ax,%ax
    99b3:	0f 85 cd fd ff ff    	jne    9786 <f23+0xa6>
    99b9:	0f b6 07             	movzbl (%rdi),%eax
    99bc:	84 c0                	test   %al,%al
    99be:	0f 84 c2 fd ff ff    	je     9786 <f23+0xa6>
    99c4:	3c fd                	cmp    $0xfd,%al
    99c6:	0f 87 95 01 00 00    	ja     9b61 <f23+0x481>
    99cc:	83 c0 01             	add    $0x1,%eax
    99cf:	88 07                	mov    %al,(%rdi)
    99d1:	e9 b0 fd ff ff       	jmp    9786 <f23+0xa6>
    99d6:	48 f7 d9             	neg    %rcx
    99d9:	48 39 d1             	cmp    %rdx,%rcx
    99dc:	0f 83 ee 00 00 00    	jae    9ad0 <f23+0x3f0>
    99e2:	48 89 c8             	mov    %rcx,%rax
    99e5:	48 c1 e8 10          	shr    $0x10,%rax
    99e9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    99ed:	48 8b 05 64 81 01 00 	mov    0x18164(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    99f4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    99f8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    99fc:	48 85 ff             	test   %rdi,%rdi
    99ff:	0f 84 cb 00 00 00    	je     9ad0 <f23+0x3f0>
    9a05:	0f b6 02             	movzbl (%rdx),%eax
    9a08:	3c 02                	cmp    $0x2,%al
    9a0a:	0f 84 9a 00 00 00    	je     9aaa <f23+0x3ca>
    9a10:	3c 01                	cmp    $0x1,%al
    9a12:	0f 85 b8 00 00 00    	jne    9ad0 <f23+0x3f0>
    9a18:	0f b7 c1             	movzwl %cx,%eax
    9a1b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a1e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a21:	48 0f af c1          	imul   %rcx,%rax
    9a25:	48 c1 e8 20          	shr    $0x20,%rax
    9a29:	48 39 d0             	cmp    %rdx,%rax
    9a2c:	0f 83 9e 00 00 00    	jae    9ad0 <f23+0x3f0>
    9a32:	48 01 c7             	add    %rax,%rdi
    9a35:	0f b6 07             	movzbl (%rdi),%eax
    9a38:	84 c0                	test   %al,%al
    9a3a:	0f 84 90 00 00 00    	je     9ad0 <f23+0x3f0>
    9a40:	31 db                	xor    %ebx,%ebx
    9a42:	0f 1f 00             	nopl   (%rax)
    9a45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9a4c:	00 00 00 00 
    9a50:	3c fd                	cmp    $0xfd,%al
    9a52:	0f 87 f1 00 00 00    	ja     9b49 <f23+0x469>
    9a58:	83 c0 01             	add    $0x1,%eax
    9a5b:	88 07                	mov    %al,(%rdi)
    9a5d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9a62:	31 d2                	xor    %edx,%edx
    9a64:	4d 85 e4             	test   %r12,%r12
    9a67:	0f 85 1e fd ff ff    	jne    978b <f23+0xab>
    9a6d:	e9 3b fd ff ff       	jmp    97ad <f23+0xcd>
    9a72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a78:	66 85 c0             	test   %ax,%ax
    9a7b:	0f 85 06 ff ff ff    	jne    9987 <f23+0x2a7>
    9a81:	e9 f5 fe ff ff       	jmp    997b <f23+0x29b>
    9a86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a8d:	00 00 00 
    9a90:	66 85 c0             	test   %ax,%ax
    9a93:	0f 85 d2 fd ff ff    	jne    986b <f23+0x18b>
    9a99:	e9 bf fd ff ff       	jmp    985d <f23+0x17d>
    9a9e:	66 90                	xchg   %ax,%ax
    9aa0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9aa5:	e9 e6 fc ff ff       	jmp    9790 <f23+0xb0>
    9aaa:	66 85 c9             	test   %cx,%cx
    9aad:	75 21                	jne    9ad0 <f23+0x3f0>
    9aaf:	0f b6 07             	movzbl (%rdi),%eax
    9ab2:	84 c0                	test   %al,%al
    9ab4:	74 1a                	je     9ad0 <f23+0x3f0>
    9ab6:	3c fd                	cmp    $0xfd,%al
    9ab8:	0f 87 be 00 00 00    	ja     9b7c <f23+0x49c>
    9abe:	83 c0 01             	add    $0x1,%eax
    9ac1:	88 07                	mov    %al,(%rdi)
    9ac3:	66 90                	xchg   %ax,%ax
    9ac5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9acc:	00 00 00 00 
    9ad0:	be 02 00 00 00       	mov    $0x2,%esi
    9ad5:	bf 08 00 00 00       	mov    $0x8,%edi
    9ada:	e8 71 bf ff ff       	call   5a50 <fwp_heap_alloc>
    9adf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9ae6:	48 8b 15 4b 80 01 00 	mov    0x1804b(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9aed:	49 89 c6             	mov    %rax,%r14
    9af0:	48 2b 05 19 80 01 00 	sub    0x18019(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    9af7:	48 c1 e2 10          	shl    $0x10,%rdx
    9afb:	48 39 d0             	cmp    %rdx,%rax
    9afe:	73 53                	jae    9b53 <f23+0x473>
    9b00:	48 89 c2             	mov    %rax,%rdx
    9b03:	48 c1 ea 10          	shr    $0x10,%rdx
    9b07:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b0b:	48 8b 15 46 80 01 00 	mov    0x18046(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    9b12:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b16:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9b1a:	48 85 ed             	test   %rbp,%rbp
    9b1d:	74 34                	je     9b53 <f23+0x473>
    9b1f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9b26:	00 00 
    9b28:	31 db                	xor    %ebx,%ebx
    9b2a:	e9 04 fd ff ff       	jmp    9833 <f23+0x153>
    9b2f:	48 89 df             	mov    %rbx,%rdi
    9b32:	e8 d9 b7 ff ff       	call   5310 <fwp_rc_forget_slot>
    9b37:	e9 48 fe ff ff       	jmp    9984 <f23+0x2a4>
    9b3c:	48 89 ef             	mov    %rbp,%rdi
    9b3f:	e8 cc b7 ff ff       	call   5310 <fwp_rc_forget_slot>
    9b44:	e9 1e fd ff ff       	jmp    9867 <f23+0x187>
    9b49:	e8 a2 b6 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9b4e:	e9 0a ff ff ff       	jmp    9a5d <f23+0x37d>
    9b53:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9b5a:	00 00 
    9b5c:	e9 6c fd ff ff       	jmp    98cd <f23+0x1ed>
    9b61:	e8 8a b6 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9b66:	e9 1b fc ff ff       	jmp    9786 <f23+0xa6>
    9b6b:	e8 f0 98 ff ff       	call   3460 <__stack_chk_fail@plt>
    9b70:	48 8d 3d d0 25 00 00 	lea    0x25d0(%rip),%rdi        # c147 <_IO_stdin_used+0x147>
    9b77:	e8 24 a6 ff ff       	call   41a0 <fwp_trap>
    9b7c:	e8 6f b6 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9b81:	e9 4a ff ff ff       	jmp    9ad0 <f23+0x3f0>
    9b86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b8d:	00 00 00 

0000000000009b90 <fwp_owned_entry23>:
    9b90:	f3 0f 1e fa          	endbr64
    9b94:	48 8b 3f             	mov    (%rdi),%rdi
    9b97:	e9 44 fb ff ff       	jmp    96e0 <f23>
    9b9c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009ba0 <e23>:
    9ba0:	f3 0f 1e fa          	endbr64
    9ba4:	53                   	push   %rbx
    9ba5:	48 8b 1f             	mov    (%rdi),%rbx
    9ba8:	48 89 df             	mov    %rbx,%rdi
    9bab:	e8 70 ca ff ff       	call   6620 <fwp_rc_share>
    9bb0:	48 89 df             	mov    %rbx,%rdi
    9bb3:	e8 28 fb ff ff       	call   96e0 <f23>
    9bb8:	48 89 c3             	mov    %rax,%rbx
    9bbb:	48 89 c7             	mov    %rax,%rdi
    9bbe:	e8 5d ca ff ff       	call   6620 <fwp_rc_share>
    9bc3:	48 89 d8             	mov    %rbx,%rax
    9bc6:	5b                   	pop    %rbx
    9bc7:	c3                   	ret
    9bc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9bcf:	00 

0000000000009bd0 <fwp_write>:
    9bd0:	41 57                	push   %r15
    9bd2:	41 56                	push   %r14
    9bd4:	41 55                	push   %r13
    9bd6:	41 54                	push   %r12
    9bd8:	55                   	push   %rbp
    9bd9:	53                   	push   %rbx
    9bda:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9be1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9be8:	00 00 
    9bea:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9bf1:	00 
    9bf2:	49 89 d4             	mov    %rdx,%r12
    9bf5:	8b 12                	mov    (%rdx),%edx
    9bf7:	83 fa 19             	cmp    $0x19,%edx
    9bfa:	77 6a                	ja     9c66 <fwp_write+0x96>
    9bfc:	48 89 f5             	mov    %rsi,%rbp
    9bff:	89 d0                	mov    %edx,%eax
    9c01:	89 ce                	mov    %ecx,%esi
    9c03:	48 89 fb             	mov    %rdi,%rbx
    9c06:	48 8d 0d 03 2e 00 00 	lea    0x2e03(%rip),%rcx        # ca10 <_IO_stdin_used+0xa10>
    9c0d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9c11:	48 01 c8             	add    %rcx,%rax
    9c14:	3e ff e0             	notrack jmp *%rax
    9c17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c1e:	00 00 
    9c20:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9c24:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9c28:	48 89 ca             	mov    %rcx,%rdx
    9c2b:	48 85 c9             	test   %rcx,%rcx
    9c2e:	0f 88 9c 0c 00 00    	js     a8d0 <fwp_write+0xd00>
    9c34:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9c3b:	00 
    9c3c:	48 89 c6             	mov    %rax,%rsi
    9c3f:	4c 89 e7             	mov    %r12,%rdi
    9c42:	e8 f9 9d ff ff       	call   3a40 <fwp_fmt_u128>
    9c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c4e:	00 00 
    9c50:	4c 89 e7             	mov    %r12,%rdi
    9c53:	e8 f8 97 ff ff       	call   3450 <strlen@plt>
    9c58:	4c 89 e6             	mov    %r12,%rsi
    9c5b:	48 89 df             	mov    %rbx,%rdi
    9c5e:	48 89 c2             	mov    %rax,%rdx
    9c61:	e8 0a a4 ff ff       	call   4070 <buf_put>
    9c66:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9c6d:	00 
    9c6e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c75:	00 00 
    9c77:	0f 85 28 04 00 00    	jne    a0a5 <fwp_write+0x4d5>
    9c7d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9c84:	5b                   	pop    %rbx
    9c85:	5d                   	pop    %rbp
    9c86:	41 5c                	pop    %r12
    9c88:	41 5d                	pop    %r13
    9c8a:	41 5e                	pop    %r14
    9c8c:	41 5f                	pop    %r15
    9c8e:	c3                   	ret
    9c8f:	90                   	nop
    9c90:	49 89 e9             	mov    %rbp,%r9
    9c93:	4c 8d 05 e7 24 00 00 	lea    0x24e7(%rip),%r8        # c181 <_IO_stdin_used+0x181>
    9c9a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9c9f:	ba 02 00 00 00       	mov    $0x2,%edx
    9ca4:	be 00 02 00 00       	mov    $0x200,%esi
    9ca9:	31 c0                	xor    %eax,%eax
    9cab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9cb2:	00 
    9cb3:	e8 f8 96 ff ff       	call   33b0 <__snprintf_chk@plt>
    9cb8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9cbf:	00 
    9cc0:	e8 8b 97 ff ff       	call   3450 <strlen@plt>
    9cc5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9ccc:	00 
    9ccd:	48 89 df             	mov    %rbx,%rdi
    9cd0:	48 89 c2             	mov    %rax,%rdx
    9cd3:	e8 98 a3 ff ff       	call   4070 <buf_put>
    9cd8:	eb 8c                	jmp    9c66 <fwp_write+0x96>
    9cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ce0:	49 89 e9             	mov    %rbp,%r9
    9ce3:	4c 8d 05 92 24 00 00 	lea    0x2492(%rip),%r8        # c17c <_IO_stdin_used+0x17c>
    9cea:	eb ae                	jmp    9c9a <fwp_write+0xca>
    9cec:	0f 1f 40 00          	nopl   0x0(%rax)
    9cf0:	83 fa 13             	cmp    $0x13,%edx
    9cf3:	48 8d 05 78 24 00 00 	lea    0x2478(%rip),%rax        # c172 <_IO_stdin_used+0x172>
    9cfa:	48 8d 35 76 24 00 00 	lea    0x2476(%rip),%rsi        # c177 <_IO_stdin_used+0x177>
    9d01:	ba 04 00 00 00       	mov    $0x4,%edx
    9d06:	48 0f 44 f0          	cmove  %rax,%rsi
    9d0a:	45 31 ed             	xor    %r13d,%r13d
    9d0d:	e8 5e a3 ff ff       	call   4070 <buf_put>
    9d12:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9d17:	0f 84 a3 08 00 00    	je     a5c0 <fwp_write+0x9f0>
    9d1d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9d22:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9d27:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9d2c:	48 89 df             	mov    %rbx,%rdi
    9d2f:	49 0f 44 c5          	cmove  %r13,%rax
    9d33:	31 c9                	xor    %ecx,%ecx
    9d35:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9d3a:	e8 91 fe ff ff       	call   9bd0 <fwp_write>
    9d3f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9d44:	0f 84 6e 09 00 00    	je     a6b8 <fwp_write+0xae8>
    9d4a:	49 83 c5 01          	add    $0x1,%r13
    9d4e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9d52:	0f 83 68 08 00 00    	jae    a5c0 <fwp_write+0x9f0>
    9d58:	ba 02 00 00 00       	mov    $0x2,%edx
    9d5d:	48 8d 35 5d 24 00 00 	lea    0x245d(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    9d64:	48 89 df             	mov    %rbx,%rdi
    9d67:	e8 04 a3 ff ff       	call   4070 <buf_put>
    9d6c:	eb af                	jmp    9d1d <fwp_write+0x14d>
    9d6e:	66 90                	xchg   %ax,%ax
    9d70:	ba 06 00 00 00       	mov    $0x6,%edx
    9d75:	48 8d 35 1e 24 00 00 	lea    0x241e(%rip),%rsi        # c19a <_IO_stdin_used+0x19a>
    9d7c:	48 83 c5 10          	add    $0x10,%rbp
    9d80:	e8 eb a2 ff ff       	call   4070 <buf_put>
    9d85:	48 89 ef             	mov    %rbp,%rdi
    9d88:	e8 c3 96 ff ff       	call   3450 <strlen@plt>
    9d8d:	48 89 ee             	mov    %rbp,%rsi
    9d90:	48 89 df             	mov    %rbx,%rdi
    9d93:	48 89 c2             	mov    %rax,%rdx
    9d96:	e8 d5 a2 ff ff       	call   4070 <buf_put>
    9d9b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9da0:	ba 01 00 00 00       	mov    $0x1,%edx
    9da5:	48 89 df             	mov    %rbx,%rdi
    9da8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9dad:	e8 be a2 ff ff       	call   4070 <buf_put>
    9db2:	e9 af fe ff ff       	jmp    9c66 <fwp_write+0x96>
    9db7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9dbe:	00 00 
    9dc0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9dc7:	00 
    9dc8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9dcf:	00 00 
    9dd1:	0f 85 ce 02 00 00    	jne    a0a5 <fwp_write+0x4d5>
    9dd7:	ba 0a 00 00 00       	mov    $0xa,%edx
    9ddc:	48 8d 35 a3 23 00 00 	lea    0x23a3(%rip),%rsi        # c186 <_IO_stdin_used+0x186>
    9de3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9dea:	48 89 df             	mov    %rbx,%rdi
    9ded:	5b                   	pop    %rbx
    9dee:	5d                   	pop    %rbp
    9def:	41 5c                	pop    %r12
    9df1:	41 5d                	pop    %r13
    9df3:	41 5e                	pop    %r14
    9df5:	41 5f                	pop    %r15
    9df7:	e9 74 a2 ff ff       	jmp    4070 <buf_put>
    9dfc:	0f 1f 40 00          	nopl   0x0(%rax)
    9e00:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9e05:	4d 85 ed             	test   %r13,%r13
    9e08:	0f 84 02 0c 00 00    	je     aa10 <fwp_write+0xe40>
    9e0e:	48 8d 35 b9 23 00 00 	lea    0x23b9(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    9e15:	4c 89 ef             	mov    %r13,%rdi
    9e18:	e8 13 97 ff ff       	call   3530 <strcmp@plt>
    9e1d:	41 89 c1             	mov    %eax,%r9d
    9e20:	85 c0                	test   %eax,%eax
    9e22:	0f 84 6c 0c 00 00    	je     aa94 <fwp_write+0xec4>
    9e28:	4c 89 ef             	mov    %r13,%rdi
    9e2b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9e30:	e8 1b 96 ff ff       	call   3450 <strlen@plt>
    9e35:	4c 89 ee             	mov    %r13,%rsi
    9e38:	48 89 df             	mov    %rbx,%rdi
    9e3b:	48 89 c2             	mov    %rax,%rdx
    9e3e:	e8 2d a2 ff ff       	call   4070 <buf_put>
    9e43:	ba 01 00 00 00       	mov    $0x1,%edx
    9e48:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9e4d:	48 89 df             	mov    %rbx,%rdi
    9e50:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9e55:	e8 16 a2 ff ff       	call   4070 <buf_put>
    9e5a:	ba 01 00 00 00       	mov    $0x1,%edx
    9e5f:	4c 89 fe             	mov    %r15,%rsi
    9e62:	48 89 df             	mov    %rbx,%rdi
    9e65:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9e6a:	e8 01 a2 ff ff       	call   4070 <buf_put>
    9e6f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9e74:	45 31 f6             	xor    %r14d,%r14d
    9e77:	85 d2                	test   %edx,%edx
    9e79:	0f 8e 81 0a 00 00    	jle    a900 <fwp_write+0xd30>
    9e7f:	45 31 ed             	xor    %r13d,%r13d
    9e82:	4d 85 ed             	test   %r13,%r13
    9e85:	0f 85 75 07 00 00    	jne    a600 <fwp_write+0xa30>
    9e8b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9e92:	00 
    9e93:	45 85 f6             	test   %r14d,%r14d
    9e96:	0f 84 84 07 00 00    	je     a620 <fwp_write+0xa50>
    9e9c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9ea1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9ea6:	48 89 df             	mov    %rbx,%rdi
    9ea9:	49 83 c5 01          	add    $0x1,%r13
    9ead:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9eb1:	31 c9                	xor    %ecx,%ecx
    9eb3:	e8 18 fd ff ff       	call   9bd0 <fwp_write>
    9eb8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9ebd:	7f c3                	jg     9e82 <fwp_write+0x2b2>
    9ebf:	45 85 f6             	test   %r14d,%r14d
    9ec2:	0f 84 38 0a 00 00    	je     a900 <fwp_write+0xd30>
    9ec8:	b8 29 00 00 00       	mov    $0x29,%eax
    9ecd:	ba 01 00 00 00       	mov    $0x1,%edx
    9ed2:	4c 89 fe             	mov    %r15,%rsi
    9ed5:	48 89 df             	mov    %rbx,%rdi
    9ed8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9edc:	e8 8f a1 ff ff       	call   4070 <buf_put>
    9ee1:	e9 80 fd ff ff       	jmp    9c66 <fwp_write+0x96>
    9ee6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9eed:	00 00 00 
    9ef0:	ba 01 00 00 00       	mov    $0x1,%edx
    9ef5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9efa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9eff:	e8 6c a1 ff ff       	call   4070 <buf_put>
    9f04:	48 85 ed             	test   %rbp,%rbp
    9f07:	0f 84 93 06 00 00    	je     a5a0 <fwp_write+0x9d0>
    9f0d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9f11:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9f16:	31 c9                	xor    %ecx,%ecx
    9f18:	48 89 df             	mov    %rbx,%rdi
    9f1b:	e8 b0 fc ff ff       	call   9bd0 <fwp_write>
    9f20:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9f24:	48 85 ed             	test   %rbp,%rbp
    9f27:	0f 84 73 06 00 00    	je     a5a0 <fwp_write+0x9d0>
    9f2d:	ba 02 00 00 00       	mov    $0x2,%edx
    9f32:	48 8d 35 88 22 00 00 	lea    0x2288(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    9f39:	48 89 df             	mov    %rbx,%rdi
    9f3c:	e8 2f a1 ff ff       	call   4070 <buf_put>
    9f41:	eb ca                	jmp    9f0d <fwp_write+0x33d>
    9f43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9f48:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9f4c:	85 f6                	test   %esi,%esi
    9f4e:	0f 84 fc 07 00 00    	je     a750 <fwp_write+0xb80>
    9f54:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9f5b:	00 
    9f5c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f63:	00 00 
    9f65:	0f 85 3a 01 00 00    	jne    a0a5 <fwp_write+0x4d5>
    9f6b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9f6f:	4c 89 ea             	mov    %r13,%rdx
    9f72:	e9 6c fe ff ff       	jmp    9de3 <fwp_write+0x213>
    9f77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f7e:	00 00 
    9f80:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9f85:	ba 01 00 00 00       	mov    $0x1,%edx
    9f8a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9f8f:	48 89 ee             	mov    %rbp,%rsi
    9f92:	e8 d9 a0 ff ff       	call   4070 <buf_put>
    9f97:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9f9c:	4c 89 e7             	mov    %r12,%rdi
    9f9f:	e8 ac 94 ff ff       	call   3450 <strlen@plt>
    9fa4:	4c 89 e6             	mov    %r12,%rsi
    9fa7:	48 89 df             	mov    %rbx,%rdi
    9faa:	48 89 c2             	mov    %rax,%rdx
    9fad:	e8 be a0 ff ff       	call   4070 <buf_put>
    9fb2:	ba 01 00 00 00       	mov    $0x1,%edx
    9fb7:	48 89 ee             	mov    %rbp,%rsi
    9fba:	48 89 df             	mov    %rbx,%rdi
    9fbd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9fc2:	e8 a9 a0 ff ff       	call   4070 <buf_put>
    9fc7:	e9 9a fc ff ff       	jmp    9c66 <fwp_write+0x96>
    9fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    9fd0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9fd5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9fd9:	0f 8a 8e 0b 00 00    	jp     ab6d <fwp_write+0xf9d>
    9fdf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9fe3:	66 0f 54 05 25 2b 00 	andpd  0x2b25(%rip),%xmm0        # cb10 <msg.4+0x90>
    9fea:	00 
    9feb:	bd 01 00 00 00       	mov    $0x1,%ebp
    9ff0:	66 0f 2e 05 58 2b 00 	ucomisd 0x2b58(%rip),%xmm0        # cb50 <msg.4+0xd0>
    9ff7:	00 
    9ff8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9fff:	00 
    a000:	0f 87 b2 09 00 00    	ja     a9b8 <fwp_write+0xde8>
    a006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a00d:	00 00 00 
    a010:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a014:	89 ee                	mov    %ebp,%esi
    a016:	4c 89 e7             	mov    %r12,%rdi
    a019:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a01e:	e8 9d a4 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a023:	31 f6                	xor    %esi,%esi
    a025:	4c 89 e7             	mov    %r12,%rdi
    a028:	e8 e3 93 ff ff       	call   3410 <strtod@plt>
    a02d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a032:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a036:	7a 06                	jp     a03e <fwp_write+0x46e>
    a038:	0f 84 e9 01 00 00    	je     a227 <fwp_write+0x657>
    a03e:	83 c5 01             	add    $0x1,%ebp
    a041:	83 fd 12             	cmp    $0x12,%ebp
    a044:	75 ca                	jne    a010 <fwp_write+0x440>
    a046:	be 11 00 00 00       	mov    $0x11,%esi
    a04b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a04f:	4c 89 e7             	mov    %r12,%rdi
    a052:	e8 69 a4 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a057:	e9 cb 01 00 00       	jmp    a227 <fwp_write+0x657>
    a05c:	0f 1f 40 00          	nopl   0x0(%rax)
    a060:	48 83 fd 01          	cmp    $0x1,%rbp
    a064:	0f 84 e6 08 00 00    	je     a950 <fwp_write+0xd80>
    a06a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a06e:	b8 02 00 00 00       	mov    $0x2,%eax
    a073:	ba 01 00 00 00       	mov    $0x1,%edx
    a078:	48 0f 44 d0          	cmove  %rax,%rdx
    a07c:	48 8d 35 e7 20 00 00 	lea    0x20e7(%rip),%rsi        # c16a <_IO_stdin_used+0x16a>
    a083:	48 8d 05 e5 20 00 00 	lea    0x20e5(%rip),%rax        # c16f <_IO_stdin_used+0x16f>
    a08a:	48 0f 44 f0          	cmove  %rax,%rsi
    a08e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a095:	00 
    a096:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a09d:	00 00 
    a09f:	0f 84 3e fd ff ff    	je     9de3 <fwp_write+0x213>
    a0a5:	e8 b6 93 ff ff       	call   3460 <__stack_chk_fail@plt>
    a0aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a0b0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a0b5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a0ba:	e8 f1 9e ff ff       	call   3fb0 <buf_grow>
    a0bf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a0c3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a0c9:	4c 03 0b             	add    (%rbx),%r9
    a0cc:	66 45 89 11          	mov    %r10w,(%r9)
    a0d0:	45 85 e4             	test   %r12d,%r12d
    a0d3:	0f 8e 07 05 00 00    	jle    a5e0 <fwp_write+0xa10>
    a0d9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a0e0:	55 55 55 
    a0e3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a0e8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a0ef:	aa aa aa 
    a0f2:	49 83 c1 01          	add    $0x1,%r9
    a0f6:	eb 45                	jmp    a13d <fwp_write+0x56d>
    a0f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a0ff:	00 
    a100:	be 01 00 00 00       	mov    $0x1,%esi
    a105:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a10a:	88 07                	mov    %al,(%rdi)
    a10c:	48 89 e8             	mov    %rbp,%rax
    a10f:	49 f7 e8             	imul   %r8
    a112:	48 89 e8             	mov    %rbp,%rax
    a115:	48 c1 f8 3f          	sar    $0x3f,%rax
    a119:	48 29 c2             	sub    %rax,%rdx
    a11c:	48 85 c9             	test   %rcx,%rcx
    a11f:	0f 95 c0             	setne  %al
    a122:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a126:	48 83 ef 01          	sub    $0x1,%rdi
    a12a:	48 21 c5             	and    %rax,%rbp
    a12d:	48 29 ea             	sub    %rbp,%rdx
    a130:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a134:	49 39 f9             	cmp    %rdi,%r9
    a137:	0f 84 a3 04 00 00    	je     a5e0 <fwp_write+0xa10>
    a13d:	48 89 e8             	mov    %rbp,%rax
    a140:	49 f7 e8             	imul   %r8
    a143:	48 89 e8             	mov    %rbp,%rax
    a146:	48 c1 f8 3f          	sar    $0x3f,%rax
    a14a:	48 89 d1             	mov    %rdx,%rcx
    a14d:	48 29 c1             	sub    %rax,%rcx
    a150:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a154:	48 89 e9             	mov    %rbp,%rcx
    a157:	48 29 c1             	sub    %rax,%rcx
    a15a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a15e:	49 f7 e2             	mul    %r10
    a161:	b8 30 00 00 00       	mov    $0x30,%eax
    a166:	48 89 d6             	mov    %rdx,%rsi
    a169:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a16d:	48 d1 ee             	shr    $1,%rsi
    a170:	48 01 f2             	add    %rsi,%rdx
    a173:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a177:	48 29 d6             	sub    %rdx,%rsi
    a17a:	74 8e                	je     a10a <fwp_write+0x53a>
    a17c:	48 83 fe 01          	cmp    $0x1,%rsi
    a180:	0f 85 7a ff ff ff    	jne    a100 <fwp_write+0x530>
    a186:	31 f6                	xor    %esi,%esi
    a188:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a18d:	e9 78 ff ff ff       	jmp    a10a <fwp_write+0x53a>
    a192:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a198:	66 0f 6e cd          	movd   %ebp,%xmm1
    a19c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a19f:	0f 8a c8 09 00 00    	jp     ab6d <fwp_write+0xf9d>
    a1a5:	0f 28 c1             	movaps %xmm1,%xmm0
    a1a8:	0f 54 05 51 29 00 00 	andps  0x2951(%rip),%xmm0        # cb00 <msg.4+0x80>
    a1af:	0f 2e 05 4e 1e 00 00 	ucomiss 0x1e4e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    a1b6:	0f 87 24 08 00 00    	ja     a9e0 <fwp_write+0xe10>
    a1bc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a1c0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a1c6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a1cd:	00 
    a1ce:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a1d2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a1d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1de:	00 00 
    a1e0:	44 89 ee             	mov    %r13d,%esi
    a1e3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a1e8:	4c 89 e7             	mov    %r12,%rdi
    a1eb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a1f0:	e8 cb a2 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a1f5:	31 f6                	xor    %esi,%esi
    a1f7:	4c 89 e7             	mov    %r12,%rdi
    a1fa:	e8 b1 92 ff ff       	call   34b0 <strtof@plt>
    a1ff:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a204:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a207:	7a 02                	jp     a20b <fwp_write+0x63b>
    a209:	74 1c                	je     a227 <fwp_write+0x657>
    a20b:	41 83 c5 01          	add    $0x1,%r13d
    a20f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a213:	75 cb                	jne    a1e0 <fwp_write+0x610>
    a215:	be 09 00 00 00       	mov    $0x9,%esi
    a21a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a21f:	4c 89 e7             	mov    %r12,%rdi
    a222:	e8 99 a2 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a227:	4c 89 e7             	mov    %r12,%rdi
    a22a:	e8 01 9f ff ff       	call   4130 <fwp_finish_float>
    a22f:	e9 1c fa ff ff       	jmp    9c50 <fwp_write+0x80>
    a234:	0f 1f 40 00          	nopl   0x0(%rax)
    a238:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a23c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a240:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a247:	00 
    a248:	48 89 ef             	mov    %rbp,%rdi
    a24b:	e8 f0 97 ff ff       	call   3a40 <fwp_fmt_u128>
    a250:	48 89 ef             	mov    %rbp,%rdi
    a253:	e8 f8 91 ff ff       	call   3450 <strlen@plt>
    a258:	48 89 ee             	mov    %rbp,%rsi
    a25b:	48 89 df             	mov    %rbx,%rdi
    a25e:	48 89 c2             	mov    %rax,%rdx
    a261:	e8 0a 9e ff ff       	call   4070 <buf_put>
    a266:	e9 fb f9 ff ff       	jmp    9c66 <fwp_write+0x96>
    a26b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a270:	ba 06 00 00 00       	mov    $0x6,%edx
    a275:	48 8d 35 48 1f 00 00 	lea    0x1f48(%rip),%rsi        # c1c4 <_IO_stdin_used+0x1c4>
    a27c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a282:	e8 e9 9d ff ff       	call   4070 <buf_put>
    a287:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a28e:	ff ff 7f 
    a291:	48 23 55 00          	and    0x0(%rbp),%rdx
    a295:	0f 84 86 02 00 00    	je     a521 <fwp_write+0x951>
    a29b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a2a0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a2a4:	48 85 d2             	test   %rdx,%rdx
    a2a7:	0f 84 ae 00 00 00    	je     a35b <fwp_write+0x78b>
    a2ad:	8b 0a                	mov    (%rdx),%ecx
    a2af:	83 f9 1c             	cmp    $0x1c,%ecx
    a2b2:	0f 84 58 06 00 00    	je     a910 <fwp_write+0xd40>
    a2b8:	83 f9 1b             	cmp    $0x1b,%ecx
    a2bb:	0f 87 9a 00 00 00    	ja     a35b <fwp_write+0x78b>
    a2c1:	be 01 00 00 00       	mov    $0x1,%esi
    a2c6:	48 d3 e6             	shl    %cl,%rsi
    a2c9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a2cf:	0f 85 4b 04 00 00    	jne    a720 <fwp_write+0xb50>
    a2d5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a2db:	0f 85 0f 04 00 00    	jne    a6f0 <fwp_write+0xb20>
    a2e1:	83 e6 21             	and    $0x21,%esi
    a2e4:	74 75                	je     a35b <fwp_write+0x78b>
    a2e6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a2eb:	48 85 ff             	test   %rdi,%rdi
    a2ee:	79 07                	jns    a2f7 <fwp_write+0x727>
    a2f0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a2f4:	4c 01 ee             	add    %r13,%rsi
    a2f7:	48 0f be 3e          	movsbq (%rsi),%rdi
    a2fb:	85 c9                	test   %ecx,%ecx
    a2fd:	40 0f b6 f7          	movzbl %dil,%esi
    a301:	48 0f 44 f7          	cmove  %rdi,%rsi
    a305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a30c:	00 00 00 00 
    a310:	31 c9                	xor    %ecx,%ecx
    a312:	48 89 df             	mov    %rbx,%rdi
    a315:	49 83 c5 01          	add    $0x1,%r13
    a319:	e8 b2 f8 ff ff       	call   9bd0 <fwp_write>
    a31e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a325:	ff ff 7f 
    a328:	48 23 55 00          	and    0x0(%rbp),%rdx
    a32c:	49 39 d5             	cmp    %rdx,%r13
    a32f:	0f 83 ec 01 00 00    	jae    a521 <fwp_write+0x951>
    a335:	ba 02 00 00 00       	mov    $0x2,%edx
    a33a:	48 89 df             	mov    %rbx,%rdi
    a33d:	48 8d 35 7d 1e 00 00 	lea    0x1e7d(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a344:	e8 27 9d ff ff       	call   4070 <buf_put>
    a349:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a34e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a352:	48 85 d2             	test   %rdx,%rdx
    a355:	0f 85 52 ff ff ff    	jne    a2ad <fwp_write+0x6dd>
    a35b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a360:	48 85 ff             	test   %rdi,%rdi
    a363:	0f 88 cf 05 00 00    	js     a938 <fwp_write+0xd68>
    a369:	48 8b 31             	mov    (%rcx),%rsi
    a36c:	eb a2                	jmp    a310 <fwp_write+0x740>
    a36e:	66 90                	xchg   %ax,%ax
    a370:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a377:	00 
    a378:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a37f:	00 00 
    a381:	0f 85 1e fd ff ff    	jne    a0a5 <fwp_write+0x4d5>
    a387:	ba 08 00 00 00       	mov    $0x8,%edx
    a38c:	48 8d 35 fe 1d 00 00 	lea    0x1dfe(%rip),%rsi        # c191 <_IO_stdin_used+0x191>
    a393:	e9 4b fa ff ff       	jmp    9de3 <fwp_write+0x213>
    a398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a39f:	00 
    a3a0:	89 e8                	mov    %ebp,%eax
    a3a2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a3a9:	76 03                	jbe    a3ae <fwp_write+0x7de>
    a3ab:	8b 45 00             	mov    0x0(%rbp),%eax
    a3ae:	41 89 c6             	mov    %eax,%r14d
    a3b1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a3b6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a3bb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a3bf:	4c 89 ef             	mov    %r13,%rdi
    a3c2:	e8 89 90 ff ff       	call   3450 <strlen@plt>
    a3c7:	4c 89 ee             	mov    %r13,%rsi
    a3ca:	48 89 df             	mov    %rbx,%rdi
    a3cd:	48 89 c2             	mov    %rax,%rdx
    a3d0:	e8 9b 9c ff ff       	call   4070 <buf_put>
    a3d5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a3da:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a3de:	85 f6                	test   %esi,%esi
    a3e0:	0f 8e 80 f8 ff ff    	jle    9c66 <fwp_write+0x96>
    a3e6:	45 31 ed             	xor    %r13d,%r13d
    a3e9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a3ee:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a3f3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a3f8:	ba 01 00 00 00       	mov    $0x1,%edx
    a3fd:	4c 89 fe             	mov    %r15,%rsi
    a400:	48 89 04 24          	mov    %rax,(%rsp)
    a404:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a409:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a40d:	48 89 df             	mov    %rbx,%rdi
    a410:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a414:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a419:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a41e:	e8 4d 9c ff ff       	call   4070 <buf_put>
    a423:	41 8b 06             	mov    (%r14),%eax
    a426:	83 f8 0e             	cmp    $0xe,%eax
    a429:	0f 84 71 02 00 00    	je     a6a0 <fwp_write+0xad0>
    a42f:	83 f8 10             	cmp    $0x10,%eax
    a432:	0f 84 38 02 00 00    	je     a670 <fwp_write+0xaa0>
    a438:	83 f8 0a             	cmp    $0xa,%eax
    a43b:	0f 84 7f 04 00 00    	je     a8c0 <fwp_write+0xcf0>
    a441:	0f 8f f9 00 00 00    	jg     a540 <fwp_write+0x970>
    a447:	83 f8 03             	cmp    $0x3,%eax
    a44a:	0f 8f 50 04 00 00    	jg     a8a0 <fwp_write+0xcd0>
    a450:	85 c0                	test   %eax,%eax
    a452:	78 10                	js     a464 <fwp_write+0x894>
    a454:	48 8b 04 24          	mov    (%rsp),%rax
    a458:	48 c1 e8 3f          	shr    $0x3f,%rax
    a45c:	85 c0                	test   %eax,%eax
    a45e:	0f 85 f9 00 00 00    	jne    a55d <fwp_write+0x98d>
    a464:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a469:	48 8b 34 24          	mov    (%rsp),%rsi
    a46d:	31 c9                	xor    %ecx,%ecx
    a46f:	48 89 df             	mov    %rbx,%rdi
    a472:	e8 59 f7 ff ff       	call   9bd0 <fwp_write>
    a477:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a47c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a481:	49 83 c5 01          	add    $0x1,%r13
    a485:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a489:	0f 8f 5f ff ff ff    	jg     a3ee <fwp_write+0x81e>
    a48f:	e9 d2 f7 ff ff       	jmp    9c66 <fwp_write+0x96>
    a494:	0f 1f 40 00          	nopl   0x0(%rax)
    a498:	ba 06 00 00 00       	mov    $0x6,%edx
    a49d:	48 8d 35 13 1d 00 00 	lea    0x1d13(%rip),%rsi        # c1b7 <_IO_stdin_used+0x1b7>
    a4a4:	45 31 ed             	xor    %r13d,%r13d
    a4a7:	e8 c4 9b ff ff       	call   4070 <buf_put>
    a4ac:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a4b1:	75 19                	jne    a4cc <fwp_write+0x8fc>
    a4b3:	eb 6c                	jmp    a521 <fwp_write+0x951>
    a4b5:	0f 1f 00             	nopl   (%rax)
    a4b8:	ba 02 00 00 00       	mov    $0x2,%edx
    a4bd:	48 8d 35 fd 1c 00 00 	lea    0x1cfd(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a4c4:	48 89 df             	mov    %rbx,%rdi
    a4c7:	e8 a4 9b ff ff       	call   4070 <buf_put>
    a4cc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a4d2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a4d7:	31 c0                	xor    %eax,%eax
    a4d9:	49 83 c5 01          	add    $0x1,%r13
    a4dd:	4c 8d 05 da 1c 00 00 	lea    0x1cda(%rip),%r8        # c1be <_IO_stdin_used+0x1be>
    a4e4:	ba 02 00 00 00       	mov    $0x2,%edx
    a4e9:	be 00 02 00 00       	mov    $0x200,%esi
    a4ee:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a4f5:	00 
    a4f6:	e8 b5 8e ff ff       	call   33b0 <__snprintf_chk@plt>
    a4fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a502:	00 
    a503:	e8 48 8f ff ff       	call   3450 <strlen@plt>
    a508:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a50f:	00 
    a510:	48 89 df             	mov    %rbx,%rdi
    a513:	48 89 c2             	mov    %rax,%rdx
    a516:	e8 55 9b ff ff       	call   4070 <buf_put>
    a51b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a51f:	72 97                	jb     a4b8 <fwp_write+0x8e8>
    a521:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a526:	ba 01 00 00 00       	mov    $0x1,%edx
    a52b:	48 89 df             	mov    %rbx,%rdi
    a52e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a533:	e8 38 9b ff ff       	call   4070 <buf_put>
    a538:	e9 29 f7 ff ff       	jmp    9c66 <fwp_write+0x96>
    a53d:	0f 1f 00             	nopl   (%rax)
    a540:	83 f8 0b             	cmp    $0xb,%eax
    a543:	0f 85 1b ff ff ff    	jne    a464 <fwp_write+0x894>
    a549:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a54e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a552:	83 e0 01             	and    $0x1,%eax
    a555:	85 c0                	test   %eax,%eax
    a557:	0f 84 07 ff ff ff    	je     a464 <fwp_write+0x894>
    a55d:	4c 89 fe             	mov    %r15,%rsi
    a560:	48 89 df             	mov    %rbx,%rdi
    a563:	ba 01 00 00 00       	mov    $0x1,%edx
    a568:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a56d:	e8 fe 9a ff ff       	call   4070 <buf_put>
    a572:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a577:	48 8b 34 24          	mov    (%rsp),%rsi
    a57b:	31 c9                	xor    %ecx,%ecx
    a57d:	48 89 df             	mov    %rbx,%rdi
    a580:	e8 4b f6 ff ff       	call   9bd0 <fwp_write>
    a585:	ba 01 00 00 00       	mov    $0x1,%edx
    a58a:	4c 89 fe             	mov    %r15,%rsi
    a58d:	48 89 df             	mov    %rbx,%rdi
    a590:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a595:	e8 d6 9a ff ff       	call   4070 <buf_put>
    a59a:	e9 d8 fe ff ff       	jmp    a477 <fwp_write+0x8a7>
    a59f:	90                   	nop
    a5a0:	ba 01 00 00 00       	mov    $0x1,%edx
    a5a5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a5aa:	48 89 df             	mov    %rbx,%rdi
    a5ad:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a5b2:	e8 b9 9a ff ff       	call   4070 <buf_put>
    a5b7:	e9 aa f6 ff ff       	jmp    9c66 <fwp_write+0x96>
    a5bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a5c0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a5c5:	ba 01 00 00 00       	mov    $0x1,%edx
    a5ca:	48 89 df             	mov    %rbx,%rdi
    a5cd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a5d2:	e8 99 9a ff ff       	call   4070 <buf_put>
    a5d7:	e9 8a f6 ff ff       	jmp    9c66 <fwp_write+0x96>
    a5dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a5e0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a5e4:	48 8b 13             	mov    (%rbx),%rdx
    a5e7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a5ec:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a5f0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a5f4:	e9 6d f6 ff ff       	jmp    9c66 <fwp_write+0x96>
    a5f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a600:	ba 02 00 00 00       	mov    $0x2,%edx
    a605:	48 8d 35 b5 1b 00 00 	lea    0x1bb5(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a60c:	48 89 df             	mov    %rbx,%rdi
    a60f:	e8 5c 9a ff ff       	call   4070 <buf_put>
    a614:	e9 72 f8 ff ff       	jmp    9e8b <fwp_write+0x2bb>
    a619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a620:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a625:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a62a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a62e:	48 89 f7             	mov    %rsi,%rdi
    a631:	48 89 34 24          	mov    %rsi,(%rsp)
    a635:	e8 16 8e ff ff       	call   3450 <strlen@plt>
    a63a:	48 8b 34 24          	mov    (%rsp),%rsi
    a63e:	48 89 df             	mov    %rbx,%rdi
    a641:	48 89 c2             	mov    %rax,%rdx
    a644:	e8 27 9a ff ff       	call   4070 <buf_put>
    a649:	ba 03 00 00 00       	mov    $0x3,%edx
    a64e:	48 8d 35 8f 1b 00 00 	lea    0x1b8f(%rip),%rsi        # c1e4 <_IO_stdin_used+0x1e4>
    a655:	48 89 df             	mov    %rbx,%rdi
    a658:	e8 13 9a ff ff       	call   4070 <buf_put>
    a65d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a662:	e9 35 f8 ff ff       	jmp    9e9c <fwp_write+0x2cc>
    a667:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a66e:	00 00 
    a670:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a675:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a679:	48 85 ff             	test   %rdi,%rdi
    a67c:	0f 84 e2 fd ff ff    	je     a464 <fwp_write+0x894>
    a682:	48 8d 35 45 1b 00 00 	lea    0x1b45(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    a689:	e8 a2 8e ff ff       	call   3530 <strcmp@plt>
    a68e:	85 c0                	test   %eax,%eax
    a690:	0f 95 c0             	setne  %al
    a693:	0f b6 c0             	movzbl %al,%eax
    a696:	e9 c1 fd ff ff       	jmp    a45c <fwp_write+0x88c>
    a69b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a6a0:	31 c0                	xor    %eax,%eax
    a6a2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a6a9:	00 
    a6aa:	0f 97 c0             	seta   %al
    a6ad:	e9 aa fd ff ff       	jmp    a45c <fwp_write+0x88c>
    a6b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6b8:	48 89 df             	mov    %rbx,%rdi
    a6bb:	ba 02 00 00 00       	mov    $0x2,%edx
    a6c0:	48 8d 35 04 1b 00 00 	lea    0x1b04(%rip),%rsi        # c1cb <_IO_stdin_used+0x1cb>
    a6c7:	e8 a4 99 ff ff       	call   4070 <buf_put>
    a6cc:	4c 89 e8             	mov    %r13,%rax
    a6cf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a6d4:	31 c9                	xor    %ecx,%ecx
    a6d6:	48 c1 e0 04          	shl    $0x4,%rax
    a6da:	48 89 df             	mov    %rbx,%rdi
    a6dd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a6e2:	e8 e9 f4 ff ff       	call   9bd0 <fwp_write>
    a6e7:	e9 5e f6 ff ff       	jmp    9d4a <fwp_write+0x17a>
    a6ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a6f0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a6f5:	48 85 ff             	test   %rdi,%rdi
    a6f8:	79 0c                	jns    a706 <fwp_write+0xb36>
    a6fa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a701:	00 
    a702:	48 03 75 10          	add    0x10(%rbp),%rsi
    a706:	48 63 3e             	movslq (%rsi),%rdi
    a709:	83 f9 02             	cmp    $0x2,%ecx
    a70c:	89 fe                	mov    %edi,%esi
    a70e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a712:	e9 f9 fb ff ff       	jmp    a310 <fwp_write+0x740>
    a717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a71e:	00 00 
    a720:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a725:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a72a:	48 85 ff             	test   %rdi,%rdi
    a72d:	0f 88 0f 03 00 00    	js     aa42 <fwp_write+0xe72>
    a733:	49 0f bf 38          	movswq (%r8),%rdi
    a737:	83 f9 01             	cmp    $0x1,%ecx
    a73a:	0f b7 f7             	movzwl %di,%esi
    a73d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a741:	e9 ca fb ff ff       	jmp    a310 <fwp_write+0x740>
    a746:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a74d:	00 00 00 
    a750:	ba 01 00 00 00       	mov    $0x1,%edx
    a755:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a75a:	48 83 c5 08          	add    $0x8,%rbp
    a75e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a763:	e8 08 99 ff ff       	call   4070 <buf_put>
    a768:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a76d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a772:	4d 85 ed             	test   %r13,%r13
    a775:	75 46                	jne    a7bd <fwp_write+0xbed>
    a777:	e9 04 01 00 00       	jmp    a880 <fwp_write+0xcb0>
    a77c:	0f 1f 40 00          	nopl   0x0(%rax)
    a780:	41 80 f9 09          	cmp    $0x9,%r9b
    a784:	0f 84 d6 00 00 00    	je     a860 <fwp_write+0xc90>
    a78a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a78e:	0f 85 9c 00 00 00    	jne    a830 <fwp_write+0xc60>
    a794:	ba 02 00 00 00       	mov    $0x2,%edx
    a799:	48 8d 35 07 1a 00 00 	lea    0x1a07(%rip),%rsi        # c1a7 <_IO_stdin_used+0x1a7>
    a7a0:	48 89 df             	mov    %rbx,%rdi
    a7a3:	e8 c8 98 ff ff       	call   4070 <buf_put>
    a7a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a7af:	00 
    a7b0:	48 83 c5 01          	add    $0x1,%rbp
    a7b4:	49 39 ec             	cmp    %rbp,%r12
    a7b7:	0f 84 c3 00 00 00    	je     a880 <fwp_write+0xcb0>
    a7bd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a7c2:	41 80 f9 0d          	cmp    $0xd,%r9b
    a7c6:	74 28                	je     a7f0 <fwp_write+0xc20>
    a7c8:	7e b6                	jle    a780 <fwp_write+0xbb0>
    a7ca:	41 80 f9 22          	cmp    $0x22,%r9b
    a7ce:	74 40                	je     a810 <fwp_write+0xc40>
    a7d0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a7d4:	75 5a                	jne    a830 <fwp_write+0xc60>
    a7d6:	ba 02 00 00 00       	mov    $0x2,%edx
    a7db:	48 8d 35 c2 19 00 00 	lea    0x19c2(%rip),%rsi        # c1a4 <_IO_stdin_used+0x1a4>
    a7e2:	48 89 df             	mov    %rbx,%rdi
    a7e5:	e8 86 98 ff ff       	call   4070 <buf_put>
    a7ea:	eb c4                	jmp    a7b0 <fwp_write+0xbe0>
    a7ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a7f0:	ba 02 00 00 00       	mov    $0x2,%edx
    a7f5:	48 8d 35 b1 19 00 00 	lea    0x19b1(%rip),%rsi        # c1ad <_IO_stdin_used+0x1ad>
    a7fc:	48 89 df             	mov    %rbx,%rdi
    a7ff:	e8 6c 98 ff ff       	call   4070 <buf_put>
    a804:	eb aa                	jmp    a7b0 <fwp_write+0xbe0>
    a806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a80d:	00 00 00 
    a810:	ba 02 00 00 00       	mov    $0x2,%edx
    a815:	48 8d 35 85 19 00 00 	lea    0x1985(%rip),%rsi        # c1a1 <_IO_stdin_used+0x1a1>
    a81c:	48 89 df             	mov    %rbx,%rdi
    a81f:	e8 4c 98 ff ff       	call   4070 <buf_put>
    a824:	eb 8a                	jmp    a7b0 <fwp_write+0xbe0>
    a826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a82d:	00 00 00 
    a830:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a834:	0f 86 2e 01 00 00    	jbe    a968 <fwp_write+0xd98>
    a83a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a83e:	0f 84 24 01 00 00    	je     a968 <fwp_write+0xd98>
    a844:	ba 01 00 00 00       	mov    $0x1,%edx
    a849:	4c 89 fe             	mov    %r15,%rsi
    a84c:	48 89 df             	mov    %rbx,%rdi
    a84f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a854:	e8 17 98 ff ff       	call   4070 <buf_put>
    a859:	e9 52 ff ff ff       	jmp    a7b0 <fwp_write+0xbe0>
    a85e:	66 90                	xchg   %ax,%ax
    a860:	ba 02 00 00 00       	mov    $0x2,%edx
    a865:	48 8d 35 3e 19 00 00 	lea    0x193e(%rip),%rsi        # c1aa <_IO_stdin_used+0x1aa>
    a86c:	48 89 df             	mov    %rbx,%rdi
    a86f:	e8 fc 97 ff ff       	call   4070 <buf_put>
    a874:	e9 37 ff ff ff       	jmp    a7b0 <fwp_write+0xbe0>
    a879:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a880:	ba 01 00 00 00       	mov    $0x1,%edx
    a885:	4c 89 fe             	mov    %r15,%rsi
    a888:	48 89 df             	mov    %rbx,%rdi
    a88b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a890:	e8 db 97 ff ff       	call   4070 <buf_put>
    a895:	e9 cc f3 ff ff       	jmp    9c66 <fwp_write+0x96>
    a89a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a8a0:	83 f8 04             	cmp    $0x4,%eax
    a8a3:	0f 85 bb fb ff ff    	jne    a464 <fwp_write+0x894>
    a8a9:	48 8b 04 24          	mov    (%rsp),%rax
    a8ad:	48 8b 40 08          	mov    0x8(%rax),%rax
    a8b1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a8b6:	48 c1 e8 3f          	shr    $0x3f,%rax
    a8ba:	e9 96 fc ff ff       	jmp    a555 <fwp_write+0x985>
    a8bf:	90                   	nop
    a8c0:	8b 0c 24             	mov    (%rsp),%ecx
    a8c3:	31 c0                	xor    %eax,%eax
    a8c5:	85 c9                	test   %ecx,%ecx
    a8c7:	0f 98 c0             	sets   %al
    a8ca:	e9 86 fc ff ff       	jmp    a555 <fwp_write+0x985>
    a8cf:	90                   	nop
    a8d0:	48 f7 d8             	neg    %rax
    a8d3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a8da:	00 
    a8db:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a8e2:	2d 
    a8e3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a8ea:	00 
    a8eb:	48 83 d2 00          	adc    $0x0,%rdx
    a8ef:	48 89 c6             	mov    %rax,%rsi
    a8f2:	48 f7 da             	neg    %rdx
    a8f5:	e8 46 91 ff ff       	call   3a40 <fwp_fmt_u128>
    a8fa:	e9 51 f3 ff ff       	jmp    9c50 <fwp_write+0x80>
    a8ff:	90                   	nop
    a900:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a905:	e9 c3 f5 ff ff       	jmp    9ecd <fwp_write+0x2fd>
    a90a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a910:	4c 89 e9             	mov    %r13,%rcx
    a913:	48 c1 e1 04          	shl    $0x4,%rcx
    a917:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a91c:	48 85 ff             	test   %rdi,%rdi
    a91f:	0f 89 eb f9 ff ff    	jns    a310 <fwp_write+0x740>
    a925:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a929:	48 89 ce             	mov    %rcx,%rsi
    a92c:	e9 df f9 ff ff       	jmp    a310 <fwp_write+0x740>
    a931:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a938:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a93f:	00 
    a940:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a944:	e9 20 fa ff ff       	jmp    a369 <fwp_write+0x799>
    a949:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a950:	ba 02 00 00 00       	mov    $0x2,%edx
    a955:	48 8d 35 10 18 00 00 	lea    0x1810(%rip),%rsi        # c16c <_IO_stdin_used+0x16c>
    a95c:	e9 2d f7 ff ff       	jmp    a08e <fwp_write+0x4be>
    a961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a968:	4c 8d 05 41 18 00 00 	lea    0x1841(%rip),%r8        # c1b0 <_IO_stdin_used+0x1b0>
    a96f:	b9 10 00 00 00       	mov    $0x10,%ecx
    a974:	31 c0                	xor    %eax,%eax
    a976:	ba 02 00 00 00       	mov    $0x2,%edx
    a97b:	be 10 00 00 00       	mov    $0x10,%esi
    a980:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a987:	00 
    a988:	e8 23 8a ff ff       	call   33b0 <__snprintf_chk@plt>
    a98d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a994:	00 
    a995:	e8 b6 8a ff ff       	call   3450 <strlen@plt>
    a99a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a9a1:	00 
    a9a2:	48 89 df             	mov    %rbx,%rdi
    a9a5:	48 89 c2             	mov    %rax,%rdx
    a9a8:	e8 c3 96 ff ff       	call   4070 <buf_put>
    a9ad:	e9 fe fd ff ff       	jmp    a7b0 <fwp_write+0xbe0>
    a9b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a9bc:	48 8d 35 a3 17 00 00 	lea    0x17a3(%rip),%rsi        # c166 <_IO_stdin_used+0x166>
    a9c3:	48 8d 05 9b 17 00 00 	lea    0x179b(%rip),%rax        # c165 <_IO_stdin_used+0x165>
    a9ca:	4c 89 e7             	mov    %r12,%rdi
    a9cd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a9d1:	48 0f 46 f0          	cmovbe %rax,%rsi
    a9d5:	e8 16 8a ff ff       	call   33f0 <strcpy@plt>
    a9da:	e9 71 f2 ff ff       	jmp    9c50 <fwp_write+0x80>
    a9df:	90                   	nop
    a9e0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a9e4:	48 8d 35 7b 17 00 00 	lea    0x177b(%rip),%rsi        # c166 <_IO_stdin_used+0x166>
    a9eb:	48 8d 05 73 17 00 00 	lea    0x1773(%rip),%rax        # c165 <_IO_stdin_used+0x165>
    a9f2:	0f 2f c8             	comiss %xmm0,%xmm1
    a9f5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9fc:	00 
    a9fd:	4c 89 e7             	mov    %r12,%rdi
    aa00:	48 0f 46 f0          	cmovbe %rax,%rsi
    aa04:	e8 e7 89 ff ff       	call   33f0 <strcpy@plt>
    aa09:	e9 42 f2 ff ff       	jmp    9c50 <fwp_write+0x80>
    aa0e:	66 90                	xchg   %ax,%ax
    aa10:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    aa15:	45 85 c0             	test   %r8d,%r8d
    aa18:	75 34                	jne    aa4e <fwp_write+0xe7e>
    aa1a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    aa21:	00 
    aa22:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aa29:	00 00 
    aa2b:	0f 85 74 f6 ff ff    	jne    a0a5 <fwp_write+0x4d5>
    aa31:	ba 02 00 00 00       	mov    $0x2,%edx
    aa36:	48 8d 35 a4 17 00 00 	lea    0x17a4(%rip),%rsi        # c1e1 <_IO_stdin_used+0x1e1>
    aa3d:	e9 a1 f3 ff ff       	jmp    9de3 <fwp_write+0x213>
    aa42:	48 03 75 10          	add    0x10(%rbp),%rsi
    aa46:	49 89 f0             	mov    %rsi,%r8
    aa49:	e9 e5 fc ff ff       	jmp    a733 <fwp_write+0xb63>
    aa4e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    aa53:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aa58:	85 ff                	test   %edi,%edi
    aa5a:	0f 84 fa f3 ff ff    	je     9e5a <fwp_write+0x28a>
    aa60:	ba 01 00 00 00       	mov    $0x1,%edx
    aa65:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    aa6a:	48 89 df             	mov    %rbx,%rdi
    aa6d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    aa72:	e8 f9 95 ff ff       	call   4070 <buf_put>
    aa77:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    aa7c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aa81:	41 be 01 00 00 00    	mov    $0x1,%r14d
    aa87:	85 c0                	test   %eax,%eax
    aa89:	0f 8f f0 f3 ff ff    	jg     9e7f <fwp_write+0x2af>
    aa8f:	e9 34 f4 ff ff       	jmp    9ec8 <fwp_write+0x2f8>
    aa94:	48 8b 45 08          	mov    0x8(%rbp),%rax
    aa98:	49 89 c5             	mov    %rax,%r13
    aa9b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    aaa0:	49 89 c4             	mov    %rax,%r12
    aaa3:	49 c1 fd 3f          	sar    $0x3f,%r13
    aaa7:	4c 09 e8             	or     %r13,%rax
    aaaa:	0f 84 a7 00 00 00    	je     ab57 <fwp_write+0xf87>
    aab0:	48 8d 2d 69 39 00 00 	lea    0x3969(%rip),%rbp        # e420 <units.1>
    aab7:	4d 89 e7             	mov    %r12,%r15
    aaba:	48 8b 45 08          	mov    0x8(%rbp),%rax
    aabe:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    aac3:	4c 89 ff             	mov    %r15,%rdi
    aac6:	4c 89 ee             	mov    %r13,%rsi
    aac9:	44 89 0c 24          	mov    %r9d,(%rsp)
    aacd:	48 99                	cqto
    aacf:	48 89 d1             	mov    %rdx,%rcx
    aad2:	48 89 c2             	mov    %rax,%rdx
    aad5:	e8 c6 0f 00 00       	call   baa0 <__divmodti4>
    aada:	44 8b 0c 24          	mov    (%rsp),%r9d
    aade:	48 89 c1             	mov    %rax,%rcx
    aae1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    aae6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    aaeb:	0f 84 94 00 00 00    	je     ab85 <fwp_write+0xfb5>
    aaf1:	41 83 c1 01          	add    $0x1,%r9d
    aaf5:	48 83 c5 10          	add    $0x10,%rbp
    aaf9:	41 83 f9 05          	cmp    $0x5,%r9d
    aafd:	75 bb                	jne    aaba <fwp_write+0xeea>
    aaff:	4d 85 ed             	test   %r13,%r13
    ab02:	79 53                	jns    ab57 <fwp_write+0xf87>
    ab04:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ab09:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ab0e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ab13:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ab18:	48 99                	cqto
    ab1a:	48 f7 d8             	neg    %rax
    ab1d:	48 83 d2 00          	adc    $0x0,%rdx
    ab21:	48 89 c6             	mov    %rax,%rsi
    ab24:	48 f7 da             	neg    %rdx
    ab27:	e8 14 8f ff ff       	call   3a40 <fwp_fmt_u128>
    ab2c:	49 89 e8             	mov    %rbp,%r8
    ab2f:	ba 00 02 00 00       	mov    $0x200,%edx
    ab34:	be 02 00 00 00       	mov    $0x2,%esi
    ab39:	31 c0                	xor    %eax,%eax
    ab3b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ab42:	00 
    ab43:	48 8d 0d 92 16 00 00 	lea    0x1692(%rip),%rcx        # c1dc <_IO_stdin_used+0x1dc>
    ab4a:	4c 89 e7             	mov    %r12,%rdi
    ab4d:	e8 8e 8b ff ff       	call   36e0 <__sprintf_chk@plt>
    ab52:	e9 f9 f0 ff ff       	jmp    9c50 <fwp_write+0x80>
    ab57:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ab5c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ab61:	31 d2                	xor    %edx,%edx
    ab63:	48 89 ef             	mov    %rbp,%rdi
    ab66:	e8 d5 8e ff ff       	call   3a40 <fwp_fmt_u128>
    ab6b:	eb bf                	jmp    ab2c <fwp_write+0xf5c>
    ab6d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ab74:	4e 61 4e 00 
    ab78:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ab7f:	00 
    ab80:	e9 cb f0 ff ff       	jmp    9c50 <fwp_write+0x80>
    ab85:	44 89 0c 24          	mov    %r9d,(%rsp)
    ab89:	48 89 c8             	mov    %rcx,%rax
    ab8c:	48 85 d2             	test   %rdx,%rdx
    ab8f:	78 51                	js     abe2 <fwp_write+0x1012>
    ab91:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ab96:	48 89 c6             	mov    %rax,%rsi
    ab99:	48 89 ef             	mov    %rbp,%rdi
    ab9c:	e8 9f 8e ff ff       	call   3a40 <fwp_fmt_u128>
    aba1:	44 8b 0c 24          	mov    (%rsp),%r9d
    aba5:	49 63 c1             	movslq %r9d,%rax
    aba8:	49 89 e8             	mov    %rbp,%r8
    abab:	ba 00 02 00 00       	mov    $0x200,%edx
    abb0:	be 02 00 00 00       	mov    $0x2,%esi
    abb5:	48 c1 e0 04          	shl    $0x4,%rax
    abb9:	48 8d 3d 60 38 00 00 	lea    0x3860(%rip),%rdi        # e420 <units.1>
    abc0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    abc7:	00 
    abc8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    abcc:	48 8d 0d 04 16 00 00 	lea    0x1604(%rip),%rcx        # c1d7 <_IO_stdin_used+0x1d7>
    abd3:	4c 89 e7             	mov    %r12,%rdi
    abd6:	31 c0                	xor    %eax,%eax
    abd8:	e8 03 8b ff ff       	call   36e0 <__sprintf_chk@plt>
    abdd:	e9 6e f0 ff ff       	jmp    9c50 <fwp_write+0x80>
    abe2:	48 f7 d8             	neg    %rax
    abe5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    abea:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    abef:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    abf4:	48 83 d2 00          	adc    $0x0,%rdx
    abf8:	48 89 c6             	mov    %rax,%rsi
    abfb:	48 f7 da             	neg    %rdx
    abfe:	e8 3d 8e ff ff       	call   3a40 <fwp_fmt_u128>
    ac03:	44 8b 0c 24          	mov    (%rsp),%r9d
    ac07:	eb 9c                	jmp    aba5 <fwp_write+0xfd5>
    ac09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ac10 <fwp_main_thread>:
    ac10:	f3 0f 1e fa          	endbr64
    ac14:	41 57                	push   %r15
    ac16:	41 56                	push   %r14
    ac18:	41 55                	push   %r13
    ac1a:	41 54                	push   %r12
    ac1c:	55                   	push   %rbp
    ac1d:	53                   	push   %rbx
    ac1e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    ac25:	8b 35 d9 6e 01 00    	mov    0x16ed9(%rip),%esi        # 21b04 <fwp_heap+0x13a4>
    ac2b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ac32:	00 00 
    ac34:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    ac3b:	00 
    ac3c:	31 c0                	xor    %eax,%eax
    ac3e:	85 f6                	test   %esi,%esi
    ac40:	0f 84 42 06 00 00    	je     b288 <fwp_main_thread+0x678>
    ac46:	8b 0d bc 6e 01 00    	mov    0x16ebc(%rip),%ecx        # 21b08 <fwp_heap+0x13a8>
    ac4c:	85 c9                	test   %ecx,%ecx
    ac4e:	0f 85 47 06 00 00    	jne    b29b <fwp_main_thread+0x68b>
    ac54:	48 8d 05 25 54 00 00 	lea    0x5425(%rip),%rax        # 10080 <alt.5>
    ac5b:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
    ac60:	31 f6                	xor    %esi,%esi
    ac62:	48 c7 05 8b 54 01 00 	movq   $0x40000000,0x1548b(%rip)        # 200f8 <fwp_main_stack_size>
    ac69:	00 00 00 40 
    ac6d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    ac72:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    ac77:	48 89 c7             	mov    %rax,%rdi
    ac7a:	4c 89 25 7f 54 01 00 	mov    %r12,0x1547f(%rip)        # 20100 <fwp_main_stack_top>
    ac81:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    ac88:	01 00 
    ac8a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    ac91:	00 
    ac92:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ac97:	e8 24 8a ff ff       	call   36c0 <sigaltstack@plt>
    ac9c:	85 c0                	test   %eax,%eax
    ac9e:	0f 85 b7 0d 00 00    	jne    ba5b <fwp_main_thread+0xe4b>
    aca4:	31 db                	xor    %ebx,%ebx
    aca6:	b9 12 00 00 00       	mov    $0x12,%ecx
    acab:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    acb2:	00 
    acb3:	48 89 d8             	mov    %rbx,%rax
    acb6:	4c 8d b4 24 80 00 00 	lea    0x80(%rsp),%r14
    acbd:	00 
    acbe:	f3 48 ab             	rep stos %rax,(%rdi)
    acc1:	48 8d 05 28 90 ff ff 	lea    -0x6fd8(%rip),%rax        # 3cf0 <fwp_segv>
    acc8:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    accf:	00 
    acd0:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    acd5:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    acdc:	00 
    acdd:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    ace4:	04 00 00 08 
    ace8:	e8 93 88 ff ff       	call   3580 <sigemptyset@plt>
    aced:	85 c0                	test   %eax,%eax
    acef:	0f 85 66 0d 00 00    	jne    ba5b <fwp_main_thread+0xe4b>
    acf5:	31 d2                	xor    %edx,%edx
    acf7:	4c 89 f6             	mov    %r14,%rsi
    acfa:	bf 0b 00 00 00       	mov    $0xb,%edi
    acff:	e8 fc 86 ff ff       	call   3400 <sigaction@plt>
    ad04:	85 c0                	test   %eax,%eax
    ad06:	0f 85 4f 0d 00 00    	jne    ba5b <fwp_main_thread+0xe4b>
    ad0c:	31 d2                	xor    %edx,%edx
    ad0e:	4c 89 f6             	mov    %r14,%rsi
    ad11:	bf 07 00 00 00       	mov    $0x7,%edi
    ad16:	e8 e5 86 ff ff       	call   3400 <sigaction@plt>
    ad1b:	85 c0                	test   %eax,%eax
    ad1d:	0f 85 38 0d 00 00    	jne    ba5b <fwp_main_thread+0xe4b>
    ad23:	8b 15 47 53 00 00    	mov    0x5347(%rip),%edx        # 10070 <st.3>
    ad29:	85 d2                	test   %edx,%edx
    ad2b:	0f 84 7f 05 00 00    	je     b2b0 <fwp_main_thread+0x6a0>
    ad31:	48 8b 2d 08 5a 01 00 	mov    0x15a08(%rip),%rbp        # 20740 <fwp_cur>
    ad38:	48 85 ed             	test   %rbp,%rbp
    ad3b:	0f 84 bf 01 00 00    	je     af00 <fwp_main_thread+0x2f0>
    ad41:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    ad46:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    ad4a:	48 89 eb             	mov    %rbp,%rbx
    ad4d:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ad52:	0f 84 41 01 00 00    	je     ae99 <fwp_main_thread+0x289>
    ad58:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    ad5d:	0f 84 9d 02 00 00    	je     b000 <fwp_main_thread+0x3f0>
    ad63:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ad67:	0f 84 73 02 00 00    	je     afe0 <fwp_main_thread+0x3d0>
    ad6d:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ad71:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ad75:	0f 85 05 03 00 00    	jne    b080 <fwp_main_thread+0x470>
    ad7b:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ad7f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ad86:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ad8a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ad91:	00 00 00 00 
    ad95:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ad9c:	48 85 d2             	test   %rdx,%rdx
    ad9f:	74 07                	je     ada8 <fwp_main_thread+0x198>
    ada1:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ada8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    adac:	48 85 c0             	test   %rax,%rax
    adaf:	74 34                	je     ade5 <fwp_main_thread+0x1d5>
    adb1:	48 89 43 68          	mov    %rax,0x68(%rbx)
    adb5:	48 8b 05 5c 59 01 00 	mov    0x1595c(%rip),%rax        # 20718 <fwp_timers>
    adbc:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    adc0:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    adc7:	00 00 00 00 
    adcb:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    add2:	48 85 c0             	test   %rax,%rax
    add5:	74 07                	je     adde <fwp_main_thread+0x1ce>
    add7:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    adde:	48 89 1d 33 59 01 00 	mov    %rbx,0x15933(%rip)        # 20718 <fwp_timers>
    ade5:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    ade9:	e8 02 c4 ff ff       	call   71f0 <fwp_block>
    adee:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    adf5:	48 85 c9             	test   %rcx,%rcx
    adf8:	74 47                	je     ae41 <fwp_main_thread+0x231>
    adfa:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    ae01:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ae08:	48 85 d2             	test   %rdx,%rdx
    ae0b:	0f 84 af 02 00 00    	je     b0c0 <fwp_main_thread+0x4b0>
    ae11:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    ae18:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ae1f:	48 85 c0             	test   %rax,%rax
    ae22:	74 07                	je     ae2b <fwp_main_thread+0x21b>
    ae24:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    ae2b:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    ae32:	00 00 00 00 
    ae36:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ae3a:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    ae41:	48 8b 0d f8 58 01 00 	mov    0x158f8(%rip),%rcx        # 20740 <fwp_cur>
    ae48:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    ae4c:	0f 84 1e 02 00 00    	je     b070 <fwp_main_thread+0x460>
    ae52:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    ae59:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    ae60:	48 85 d2             	test   %rdx,%rdx
    ae63:	0f 84 0f 04 00 00    	je     b278 <fwp_main_thread+0x668>
    ae69:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    ae70:	48 85 c0             	test   %rax,%rax
    ae73:	74 07                	je     ae7c <fwp_main_thread+0x26c>
    ae75:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    ae7c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    ae80:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    ae84:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    ae8b:	48 89 cb             	mov    %rcx,%rbx
    ae8e:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ae93:	0f 85 bf fe ff ff    	jne    ad58 <fwp_main_thread+0x148>
    ae99:	48 83 3d 37 75 01 00 	cmpq   $0x0,0x17537(%rip)        # 223d8 <fwp_state_len>
    aea0:	00 
    aea1:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    aea5:	74 69                	je     af10 <fwp_main_thread+0x300>
    aea7:	48 39 1d 8a 58 01 00 	cmp    %rbx,0x1588a(%rip)        # 20738 <fwp_root>
    aeae:	c7 05 c8 51 01 00 00 	movl   $0x0,0x151c8(%rip)        # 20080 <fwp_exit_code>
    aeb5:	00 00 00 
    aeb8:	0f 85 d0 0b 00 00    	jne    ba8e <fwp_main_thread+0xe7e>
    aebe:	48 85 db             	test   %rbx,%rbx
    aec1:	0f 84 21 02 00 00    	je     b0e8 <fwp_main_thread+0x4d8>
    aec7:	48 8b 15 3a 58 01 00 	mov    0x1583a(%rip),%rdx        # 20708 <fwp_tasks_active>
    aece:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    aed2:	48 85 d2             	test   %rdx,%rdx
    aed5:	0f 84 0d 02 00 00    	je     b0e8 <fwp_main_thread+0x4d8>
    aedb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aee0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    aee4:	75 08                	jne    aeee <fwp_main_thread+0x2de>
    aee6:	48 89 d7             	mov    %rdx,%rdi
    aee9:	e8 c2 91 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    aeee:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    aef5:	48 85 d2             	test   %rdx,%rdx
    aef8:	75 e6                	jne    aee0 <fwp_main_thread+0x2d0>
    aefa:	e9 ae 00 00 00       	jmp    afad <fwp_main_thread+0x39d>
    aeff:	90                   	nop
    af00:	48 83 3d d0 74 01 00 	cmpq   $0x0,0x174d0(%rip)        # 223d8 <fwp_state_len>
    af07:	00 
    af08:	0f 85 c2 01 00 00    	jne    b0d0 <fwp_main_thread+0x4c0>
    af0e:	31 db                	xor    %ebx,%ebx
    af10:	48 83 3d b0 74 01 00 	cmpq   $0x0,0x174b0(%rip)        # 223c8 <fwp_state_owners>
    af17:	00 
    af18:	75 8d                	jne    aea7 <fwp_main_thread+0x297>
    af1a:	48 8b 3d bf 74 01 00 	mov    0x174bf(%rip),%rdi        # 223e0 <fwp_state>
    af21:	e8 2a a6 ff ff       	call   5550 <fwp_mem_free>
    af26:	48 c7 05 af 74 01 00 	movq   $0x0,0x174af(%rip)        # 223e0 <fwp_state>
    af2d:	00 00 00 00 
    af31:	48 c7 05 94 74 01 00 	movq   $0x0,0x17494(%rip)        # 223d0 <fwp_state_cap>
    af38:	00 00 00 00 
    af3c:	48 85 db             	test   %rbx,%rbx
    af3f:	0f 84 1e 0a 00 00    	je     b963 <fwp_main_thread+0xd53>
    af45:	48 39 1d ec 57 01 00 	cmp    %rbx,0x157ec(%rip)        # 20738 <fwp_root>
    af4c:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    af53:	00 00 00 00 
    af57:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    af5e:	00 00 00 00 
    af62:	c7 05 14 51 01 00 00 	movl   $0x0,0x15114(%rip)        # 20080 <fwp_exit_code>
    af69:	00 00 00 
    af6c:	0f 84 55 ff ff ff    	je     aec7 <fwp_main_thread+0x2b7>
    af72:	e9 d9 87 ff ff       	jmp    3750 <fwp_main_thread.cold>
    af77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    af7e:	00 00 
    af80:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    af87:	48 89 1d 92 57 01 00 	mov    %rbx,0x15792(%rip)        # 20720 <fwp_ready_tail>
    af8e:	e8 5d c2 ff ff       	call   71f0 <fwp_block>
    af93:	e8 58 c0 ff ff       	call   6ff0 <fwp_free_zombie>
    af98:	48 83 3d 68 57 01 00 	cmpq   $0x0,0x15768(%rip)        # 20708 <fwp_tasks_active>
    af9f:	00 
    afa0:	0f 84 42 01 00 00    	je     b0e8 <fwp_main_thread+0x4d8>
    afa6:	48 8b 1d 8b 57 01 00 	mov    0x1578b(%rip),%rbx        # 20738 <fwp_root>
    afad:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    afb1:	75 db                	jne    af8e <fwp_main_thread+0x37e>
    afb3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    afb7:	75 d5                	jne    af8e <fwp_main_thread+0x37e>
    afb9:	48 8b 05 60 57 01 00 	mov    0x15760(%rip),%rax        # 20720 <fwp_ready_tail>
    afc0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    afc4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    afcb:	00 00 00 00 
    afcf:	48 85 c0             	test   %rax,%rax
    afd2:	75 ac                	jne    af80 <fwp_main_thread+0x370>
    afd4:	48 89 1d 4d 57 01 00 	mov    %rbx,0x1574d(%rip)        # 20728 <fwp_ready_head>
    afdb:	eb aa                	jmp    af87 <fwp_main_thread+0x377>
    afdd:	0f 1f 00             	nopl   (%rax)
    afe0:	e8 2b 93 ff ff       	call   4310 <fwp_now_ns>
    afe5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    afe9:	7c 15                	jl     b000 <fwp_main_thread+0x3f0>
    afeb:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    afef:	75 0f                	jne    b000 <fwp_main_thread+0x3f0>
    aff1:	48 89 ef             	mov    %rbp,%rdi
    aff4:	e8 b7 90 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    aff9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b000:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b004:	0f 85 63 fd ff ff    	jne    ad6d <fwp_main_thread+0x15d>
    b00a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b00e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b012:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b016:	0f 85 63 fd ff ff    	jne    ad7f <fwp_main_thread+0x16f>
    b01c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b020:	48 85 c9             	test   %rcx,%rcx
    b023:	0f 84 56 fd ff ff    	je     ad7f <fwp_main_thread+0x16f>
    b029:	48 39 c8             	cmp    %rcx,%rax
    b02c:	48 89 ce             	mov    %rcx,%rsi
    b02f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b036:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b03a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b041:	00 00 00 00 
    b045:	48 0f 4e f0          	cmovle %rax,%rsi
    b049:	48 85 c0             	test   %rax,%rax
    b04c:	48 89 c8             	mov    %rcx,%rax
    b04f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b056:	48 0f 45 c6          	cmovne %rsi,%rax
    b05a:	48 85 d2             	test   %rdx,%rdx
    b05d:	74 07                	je     b066 <fwp_main_thread+0x456>
    b05f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b066:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b06a:	e9 42 fd ff ff       	jmp    adb1 <fwp_main_thread+0x1a1>
    b06f:	90                   	nop
    b070:	48 89 cb             	mov    %rcx,%rbx
    b073:	e9 d5 fc ff ff       	jmp    ad4d <fwp_main_thread+0x13d>
    b078:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b07f:	00 
    b080:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b084:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b08b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b092:	00 00 00 00 
    b096:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b09d:	48 85 c0             	test   %rax,%rax
    b0a0:	0f 84 3a 08 00 00    	je     b8e0 <fwp_main_thread+0xcd0>
    b0a6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b0ad:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b0b1:	e9 2f fd ff ff       	jmp    ade5 <fwp_main_thread+0x1d5>
    b0b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b0bd:	00 00 00 
    b0c0:	48 89 01             	mov    %rax,(%rcx)
    b0c3:	e9 57 fd ff ff       	jmp    ae1f <fwp_main_thread+0x20f>
    b0c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b0cf:	00 
    b0d0:	48 83 3d 60 56 01 00 	cmpq   $0x0,0x15660(%rip)        # 20738 <fwp_root>
    b0d7:	00 
    b0d8:	c7 05 9e 4f 01 00 00 	movl   $0x0,0x14f9e(%rip)        # 20080 <fwp_exit_code>
    b0df:	00 00 00 
    b0e2:	0f 85 a1 09 00 00    	jne    ba89 <fwp_main_thread+0xe79>
    b0e8:	e8 03 bf ff ff       	call   6ff0 <fwp_free_zombie>
    b0ed:	48 83 3d 33 56 01 00 	cmpq   $0x0,0x15633(%rip)        # 20728 <fwp_ready_head>
    b0f4:	00 
    b0f5:	0f 85 55 86 ff ff    	jne    3750 <fwp_main_thread.cold>
    b0fb:	48 83 3d 15 56 01 00 	cmpq   $0x0,0x15615(%rip)        # 20718 <fwp_timers>
    b102:	00 
    b103:	0f 85 47 86 ff ff    	jne    3750 <fwp_main_thread.cold>
    b109:	8b 05 fd 4f 01 00    	mov    0x14ffd(%rip),%eax        # 2010c <fwp_stack_pool_n>
    b10f:	85 c0                	test   %eax,%eax
    b111:	74 3a                	je     b14d <fwp_main_thread+0x53d>
    b113:	83 e8 01             	sub    $0x1,%eax
    b116:	4c 8d 25 03 50 01 00 	lea    0x15003(%rip),%r12        # 20120 <fwp_stack_pool>
    b11d:	48 63 d8             	movslq %eax,%rbx
    b120:	89 c0                	mov    %eax,%eax
    b122:	48 89 da             	mov    %rbx,%rdx
    b125:	48 29 c2             	sub    %rax,%rdx
    b128:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    b12c:	0f 1f 40 00          	nopl   0x0(%rax)
    b130:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b134:	89 1d d2 4f 01 00    	mov    %ebx,0x14fd2(%rip)        # 2010c <fwp_stack_pool_n>
    b13a:	be 00 00 00 10       	mov    $0x10000000,%esi
    b13f:	48 83 eb 01          	sub    $0x1,%rbx
    b143:	e8 98 84 ff ff       	call   35e0 <munmap@plt>
    b148:	48 39 dd             	cmp    %rbx,%rbp
    b14b:	75 e3                	jne    b130 <fwp_main_thread+0x520>
    b14d:	8b 3d c5 4e 00 00    	mov    0x4ec5(%rip),%edi        # 10018 <fwp_epfd>
    b153:	85 ff                	test   %edi,%edi
    b155:	78 05                	js     b15c <fwp_main_thread+0x54c>
    b157:	e8 74 83 ff ff       	call   34d0 <close@plt>
    b15c:	4c 8b 25 bd 51 01 00 	mov    0x151bd(%rip),%r12        # 20320 <fwp_nfdws>
    b163:	48 8b 2d be 51 01 00 	mov    0x151be(%rip),%rbp        # 20328 <fwp_fdws>
    b16a:	31 db                	xor    %ebx,%ebx
    b16c:	c7 05 a2 4e 00 00 ff 	movl   $0xffffffff,0x4ea2(%rip)        # 10018 <fwp_epfd>
    b173:	ff ff ff 
    b176:	4d 85 e4             	test   %r12,%r12
    b179:	74 32                	je     b1ad <fwp_main_thread+0x59d>
    b17b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b180:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b185:	48 85 ff             	test   %rdi,%rdi
    b188:	74 1a                	je     b1a4 <fwp_main_thread+0x594>
    b18a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b18e:	0f 85 bc 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b194:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b199:	0f 85 b1 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b19f:	e8 ac a3 ff ff       	call   5550 <fwp_mem_free>
    b1a4:	48 83 c3 01          	add    $0x1,%rbx
    b1a8:	49 39 dc             	cmp    %rbx,%r12
    b1ab:	75 d3                	jne    b180 <fwp_main_thread+0x570>
    b1ad:	48 89 ef             	mov    %rbp,%rdi
    b1b0:	e8 9b a3 ff ff       	call   5550 <fwp_mem_free>
    b1b5:	48 8b 15 7c 55 01 00 	mov    0x1557c(%rip),%rdx        # 20738 <fwp_root>
    b1bc:	48 c7 05 61 51 01 00 	movq   $0x0,0x15161(%rip)        # 20328 <fwp_fdws>
    b1c3:	00 00 00 00 
    b1c7:	48 c7 05 4e 51 01 00 	movq   $0x0,0x1514e(%rip)        # 20320 <fwp_nfdws>
    b1ce:	00 00 00 00 
    b1d2:	48 85 d2             	test   %rdx,%rdx
    b1d5:	74 4e                	je     b225 <fwp_main_thread+0x615>
    b1d7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b1dc:	0f 85 6e 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1e2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b1e9:	00 
    b1ea:	0f 85 60 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1f0:	48 83 3d e0 71 01 00 	cmpq   $0x0,0x171e0(%rip)        # 223d8 <fwp_state_len>
    b1f7:	00 
    b1f8:	0f 85 52 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1fe:	48 83 3d c2 71 01 00 	cmpq   $0x0,0x171c2(%rip)        # 223c8 <fwp_state_owners>
    b205:	00 
    b206:	0f 85 44 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b20c:	b9 79 00 00 00       	mov    $0x79,%ecx
    b211:	31 c0                	xor    %eax,%eax
    b213:	48 8d 3d 26 51 01 00 	lea    0x15126(%rip),%rdi        # 20340 <fwp_root_context>
    b21a:	f3 48 ab             	rep stos %rax,(%rdi)
    b21d:	48 89 d7             	mov    %rdx,%rdi
    b220:	e8 2b a3 ff ff       	call   5550 <fwp_mem_free>
    b225:	48 8b 3d f4 4d 00 00 	mov    0x4df4(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    b22c:	48 c7 05 09 55 01 00 	movq   $0x0,0x15509(%rip)        # 20740 <fwp_cur>
    b233:	00 00 00 00 
    b237:	48 c7 05 f6 54 01 00 	movq   $0x0,0x154f6(%rip)        # 20738 <fwp_root>
    b23e:	00 00 00 00 
    b242:	e8 79 83 ff ff       	call   35c0 <fflush@plt>
    b247:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b24e:	00 
    b24f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b256:	00 00 
    b258:	0f 85 1a 08 00 00    	jne    ba78 <fwp_main_thread+0xe68>
    b25e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b265:	31 c0                	xor    %eax,%eax
    b267:	5b                   	pop    %rbx
    b268:	5d                   	pop    %rbp
    b269:	41 5c                	pop    %r12
    b26b:	41 5d                	pop    %r13
    b26d:	41 5e                	pop    %r14
    b26f:	41 5f                	pop    %r15
    b271:	c3                   	ret
    b272:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b278:	48 89 05 99 54 01 00 	mov    %rax,0x15499(%rip)        # 20718 <fwp_timers>
    b27f:	e9 ec fb ff ff       	jmp    ae70 <fwp_main_thread+0x260>
    b284:	0f 1f 40 00          	nopl   0x0(%rax)
    b288:	e8 a3 98 ff ff       	call   4b30 <fwp_heap_init>
    b28d:	8b 0d 75 68 01 00    	mov    0x16875(%rip),%ecx        # 21b08 <fwp_heap+0x13a8>
    b293:	85 c9                	test   %ecx,%ecx
    b295:	0f 84 b9 f9 ff ff    	je     ac54 <fwp_main_thread+0x44>
    b29b:	48 8d 3d 7e 97 ff ff 	lea    -0x6882(%rip),%rdi        # 4a20 <fwp_heap_report>
    b2a2:	e8 09 0a 00 00       	call   bcb0 <atexit>
    b2a7:	e9 a8 f9 ff ff       	jmp    ac54 <fwp_main_thread+0x44>
    b2ac:	0f 1f 40 00          	nopl   0x0(%rax)
    b2b0:	48 8d 05 79 b6 ff ff 	lea    -0x4987(%rip),%rax        # 6930 <fwp_drop1>
    b2b7:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    b2bc:	4c 8b 35 2d 18 00 00 	mov    0x182d(%rip),%r14        # caf0 <msg.4+0x70>
    b2c3:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b2ca:	00 00 
    b2cc:	66 48 0f 6e d8       	movq   %rax,%xmm3
    b2d1:	48 8b 05 20 71 01 00 	mov    0x17120(%rip),%rax        # 223f8 <fwp_cleanups>
    b2d8:	31 ed                	xor    %ebp,%ebp
    b2da:	4c 89 25 17 71 01 00 	mov    %r12,0x17117(%rip)        # 223f8 <fwp_cleanups>
    b2e1:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    b2e5:	41 bf ff 7f 00 00    	mov    $0x7fff,%r15d
    b2eb:	48 8d 1d 6e 54 01 00 	lea    0x1546e(%rip),%rbx        # 20760 <fwp_heap>
    b2f2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b2f7:	48 8d 05 d2 88 ff ff 	lea    -0x772e(%rip),%rax        # 3bd0 <fwp_range_release>
    b2fe:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b303:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b308:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b30d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    b312:	e9 06 01 00 00       	jmp    b41d <fwp_main_thread+0x80d>
    b317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b31e:	00 00 
    b320:	49 8b 14 24          	mov    (%r12),%rdx
    b324:	48 f7 d2             	not    %rdx
    b327:	48 89 10             	mov    %rdx,(%rax)
    b32a:	49 83 fd 18          	cmp    $0x18,%r13
    b32e:	76 1c                	jbe    b34c <fwp_main_thread+0x73c>
    b330:	49 8d 45 e7          	lea    -0x19(%r13),%rax
    b334:	49 8d 7c 24 18       	lea    0x18(%r12),%rdi
    b339:	31 f6                	xor    %esi,%esi
    b33b:	48 c1 e8 03          	shr    $0x3,%rax
    b33f:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b346:	00 
    b347:	e8 74 81 ff ff       	call   34c0 <memset@plt>
    b34c:	4c 89 e8             	mov    %r13,%rax
    b34f:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    b356:	0f 82 0b 07 00 00    	jb     ba67 <fwp_main_thread+0xe57>
    b35c:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    b363:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    b36a:	73 07                	jae    b373 <fwp_main_thread+0x763>
    b36c:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    b373:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b377:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    b37c:	f2 0f 58 83 38 14 00 	addsd  0x1438(%rbx),%xmm0
    b383:	00 
    b384:	f2 0f 11 83 38 14 00 	movsd  %xmm0,0x1438(%rbx)
    b38b:	00 
    b38c:	49 89 6c 24 10       	mov    %rbp,0x10(%r12)
    b391:	4c 89 e0             	mov    %r12,%rax
    b394:	4c 89 e5             	mov    %r12,%rbp
    b397:	4d 89 34 24          	mov    %r14,(%r12)
    b39b:	4d 89 7c 24 08       	mov    %r15,0x8(%r12)
    b3a0:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b3a7:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b3ae:	48 c1 e2 10          	shl    $0x10,%rdx
    b3b2:	48 39 d0             	cmp    %rdx,%rax
    b3b5:	73 57                	jae    b40e <fwp_main_thread+0x7fe>
    b3b7:	48 89 c2             	mov    %rax,%rdx
    b3ba:	48 c1 ea 10          	shr    $0x10,%rdx
    b3be:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b3c2:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b3c9:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b3cd:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b3d1:	48 85 d2             	test   %rdx,%rdx
    b3d4:	74 38                	je     b40e <fwp_main_thread+0x7fe>
    b3d6:	0f b6 3e             	movzbl (%rsi),%edi
    b3d9:	40 80 ff 02          	cmp    $0x2,%dil
    b3dd:	0f 84 ad 00 00 00    	je     b490 <fwp_main_thread+0x880>
    b3e3:	40 80 ff 01          	cmp    $0x1,%dil
    b3e7:	75 25                	jne    b40e <fwp_main_thread+0x7fe>
    b3e9:	8b 7e 18             	mov    0x18(%rsi),%edi
    b3ec:	0f b7 c0             	movzwl %ax,%eax
    b3ef:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b3f2:	48 0f af c7          	imul   %rdi,%rax
    b3f6:	48 c1 e8 20          	shr    $0x20,%rax
    b3fa:	48 39 f0             	cmp    %rsi,%rax
    b3fd:	73 0f                	jae    b40e <fwp_main_thread+0x7fe>
    b3ff:	48 01 c2             	add    %rax,%rdx
    b402:	80 3a ff             	cmpb   $0xff,(%rdx)
    b405:	0f 84 25 05 00 00    	je     b930 <fwp_main_thread+0xd20>
    b40b:	c6 02 01             	movb   $0x1,(%rdx)
    b40e:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b413:	49 83 ef 01          	sub    $0x1,%r15
    b417:	0f 82 93 00 00 00    	jb     b4b0 <fwp_main_thread+0x8a0>
    b41d:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    b423:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
    b428:	85 c0                	test   %eax,%eax
    b42a:	74 4c                	je     b478 <fwp_main_thread+0x868>
    b42c:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    b433:	44 8b ac 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r13d
    b43a:	00 
    b43b:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b43f:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    b443:	4c 8b 20             	mov    (%rax),%r12
    b446:	4d 85 e4             	test   %r12,%r12
    b449:	0f 85 d1 fe ff ff    	jne    b320 <fwp_main_thread+0x710>
    b44f:	4c 8b 60 08          	mov    0x8(%rax),%r12
    b453:	4d 85 e4             	test   %r12,%r12
    b456:	74 20                	je     b478 <fwp_main_thread+0x868>
    b458:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b45c:	4c 29 e2             	sub    %r12,%rdx
    b45f:	4c 39 ea             	cmp    %r13,%rdx
    b462:	72 14                	jb     b478 <fwp_main_thread+0x868>
    b464:	4b 8d 14 2c          	lea    (%r12,%r13,1),%rdx
    b468:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b46c:	e9 b9 fe ff ff       	jmp    b32a <fwp_main_thread+0x71a>
    b471:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b478:	31 f6                	xor    %esi,%esi
    b47a:	bf 18 00 00 00       	mov    $0x18,%edi
    b47f:	e8 cc a5 ff ff       	call   5a50 <fwp_heap_alloc>
    b484:	49 89 c4             	mov    %rax,%r12
    b487:	e9 00 ff ff ff       	jmp    b38c <fwp_main_thread+0x77c>
    b48c:	0f 1f 40 00          	nopl   0x0(%rax)
    b490:	66 85 c0             	test   %ax,%ax
    b493:	0f 84 69 ff ff ff    	je     b402 <fwp_main_thread+0x7f2>
    b499:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b49e:	49 83 ef 01          	sub    $0x1,%r15
    b4a2:	0f 83 75 ff ff ff    	jae    b41d <fwp_main_thread+0x80d>
    b4a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b4af:	00 
    b4b0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b4b5:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    b4ba:	bf 01 00 00 00       	mov    $0x1,%edi
    b4bf:	66 0f 6f 05 59 16 00 	movdqa 0x1659(%rip),%xmm0        # cb20 <msg.4+0xa0>
    b4c6:	00 
    b4c7:	48 89 05 2a 6f 01 00 	mov    %rax,0x16f2a(%rip)        # 223f8 <fwp_cleanups>
    b4ce:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    b4d5:	00 
    b4d6:	e8 15 b0 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b4db:	48 8b 15 56 66 01 00 	mov    0x16656(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b4e2:	49 89 c6             	mov    %rax,%r14
    b4e5:	48 2b 05 24 66 01 00 	sub    0x16624(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    b4ec:	48 c1 e2 10          	shl    $0x10,%rdx
    b4f0:	48 39 d0             	cmp    %rdx,%rax
    b4f3:	73 59                	jae    b54e <fwp_main_thread+0x93e>
    b4f5:	48 89 c2             	mov    %rax,%rdx
    b4f8:	48 c1 ea 10          	shr    $0x10,%rdx
    b4fc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b500:	48 8b 15 51 66 01 00 	mov    0x16651(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    b507:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b50b:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b50f:	4d 85 ed             	test   %r13,%r13
    b512:	74 3a                	je     b54e <fwp_main_thread+0x93e>
    b514:	0f b6 0a             	movzbl (%rdx),%ecx
    b517:	80 f9 02             	cmp    $0x2,%cl
    b51a:	0f 84 00 04 00 00    	je     b920 <fwp_main_thread+0xd10>
    b520:	80 f9 01             	cmp    $0x1,%cl
    b523:	75 29                	jne    b54e <fwp_main_thread+0x93e>
    b525:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b528:	0f b7 c0             	movzwl %ax,%eax
    b52b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b52e:	48 0f af c1          	imul   %rcx,%rax
    b532:	48 c1 e8 20          	shr    $0x20,%rax
    b536:	48 39 d0             	cmp    %rdx,%rax
    b539:	73 13                	jae    b54e <fwp_main_thread+0x93e>
    b53b:	49 01 c5             	add    %rax,%r13
    b53e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b543:	0f 84 6e 04 00 00    	je     b9b7 <fwp_main_thread+0xda7>
    b549:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b54e:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b553:	bf 01 00 00 00       	mov    $0x1,%edi
    b558:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b55d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b564:	00 f0 3f 
    b567:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b56c:	e8 7f af ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b571:	48 8b 15 c0 65 01 00 	mov    0x165c0(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b578:	49 89 c6             	mov    %rax,%r14
    b57b:	48 2b 05 8e 65 01 00 	sub    0x1658e(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    b582:	48 c1 e2 10          	shl    $0x10,%rdx
    b586:	48 39 d0             	cmp    %rdx,%rax
    b589:	73 59                	jae    b5e4 <fwp_main_thread+0x9d4>
    b58b:	48 89 c2             	mov    %rax,%rdx
    b58e:	48 c1 ea 10          	shr    $0x10,%rdx
    b592:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b596:	48 8b 15 bb 65 01 00 	mov    0x165bb(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    b59d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5a1:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b5a5:	4d 85 ed             	test   %r13,%r13
    b5a8:	74 3a                	je     b5e4 <fwp_main_thread+0x9d4>
    b5aa:	0f b6 0a             	movzbl (%rdx),%ecx
    b5ad:	80 f9 02             	cmp    $0x2,%cl
    b5b0:	0f 84 5a 03 00 00    	je     b910 <fwp_main_thread+0xd00>
    b5b6:	80 f9 01             	cmp    $0x1,%cl
    b5b9:	75 29                	jne    b5e4 <fwp_main_thread+0x9d4>
    b5bb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5be:	0f b7 c0             	movzwl %ax,%eax
    b5c1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5c4:	48 0f af c1          	imul   %rcx,%rax
    b5c8:	48 c1 e8 20          	shr    $0x20,%rax
    b5cc:	48 39 d0             	cmp    %rdx,%rax
    b5cf:	73 13                	jae    b5e4 <fwp_main_thread+0x9d4>
    b5d1:	49 01 c5             	add    %rax,%r13
    b5d4:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b5d9:	0f 84 e5 03 00 00    	je     b9c4 <fwp_main_thread+0xdb4>
    b5df:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b5e4:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b5e9:	bf 01 00 00 00       	mov    $0x1,%edi
    b5ee:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    b5f3:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b5fa:	33 f3 bf 
    b5fd:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b602:	e8 e9 ae ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b607:	48 8b 15 2a 65 01 00 	mov    0x1652a(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b60e:	48 8b 0d fb 64 01 00 	mov    0x164fb(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    b615:	49 89 c5             	mov    %rax,%r13
    b618:	48 89 d6             	mov    %rdx,%rsi
    b61b:	48 29 c8             	sub    %rcx,%rax
    b61e:	48 c1 e6 10          	shl    $0x10,%rsi
    b622:	48 39 f0             	cmp    %rsi,%rax
    b625:	73 67                	jae    b68e <fwp_main_thread+0xa7e>
    b627:	48 89 c6             	mov    %rax,%rsi
    b62a:	48 c1 ee 10          	shr    $0x10,%rsi
    b62e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b632:	48 8b 35 1f 65 01 00 	mov    0x1651f(%rip),%rsi        # 21b58 <fwp_heap+0x13f8>
    b639:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b63d:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    b641:	4d 85 f6             	test   %r14,%r14
    b644:	74 48                	je     b68e <fwp_main_thread+0xa7e>
    b646:	0f b6 3e             	movzbl (%rsi),%edi
    b649:	40 80 ff 02          	cmp    $0x2,%dil
    b64d:	0f 84 ad 02 00 00    	je     b900 <fwp_main_thread+0xcf0>
    b653:	40 80 ff 01          	cmp    $0x1,%dil
    b657:	75 35                	jne    b68e <fwp_main_thread+0xa7e>
    b659:	8b 7e 18             	mov    0x18(%rsi),%edi
    b65c:	0f b7 c0             	movzwl %ax,%eax
    b65f:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b662:	48 0f af c7          	imul   %rdi,%rax
    b666:	48 c1 e8 20          	shr    $0x20,%rax
    b66a:	48 39 f0             	cmp    %rsi,%rax
    b66d:	73 1f                	jae    b68e <fwp_main_thread+0xa7e>
    b66f:	49 01 c6             	add    %rax,%r14
    b672:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b676:	0f 84 55 03 00 00    	je     b9d1 <fwp_main_thread+0xdc1>
    b67c:	41 c6 06 01          	movb   $0x1,(%r14)
    b680:	48 8b 0d 89 64 01 00 	mov    0x16489(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    b687:	48 8b 15 aa 64 01 00 	mov    0x164aa(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b68e:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
    b693:	4c 89 e8             	mov    %r13,%rax
    b696:	48 c1 e2 10          	shl    $0x10,%rdx
    b69a:	48 29 c8             	sub    %rcx,%rax
    b69d:	48 39 d0             	cmp    %rdx,%rax
    b6a0:	73 5d                	jae    b6ff <fwp_main_thread+0xaef>
    b6a2:	48 89 c2             	mov    %rax,%rdx
    b6a5:	48 c1 ea 10          	shr    $0x10,%rdx
    b6a9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b6ad:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b6b4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b6b8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b6bc:	48 85 ff             	test   %rdi,%rdi
    b6bf:	74 3e                	je     b6ff <fwp_main_thread+0xaef>
    b6c1:	0f b6 0a             	movzbl (%rdx),%ecx
    b6c4:	80 f9 02             	cmp    $0x2,%cl
    b6c7:	0f 84 23 02 00 00    	je     b8f0 <fwp_main_thread+0xce0>
    b6cd:	80 f9 01             	cmp    $0x1,%cl
    b6d0:	75 2d                	jne    b6ff <fwp_main_thread+0xaef>
    b6d2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b6d5:	0f b7 c0             	movzwl %ax,%eax
    b6d8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b6db:	48 0f af c1          	imul   %rcx,%rax
    b6df:	48 c1 e8 20          	shr    $0x20,%rax
    b6e3:	48 39 d0             	cmp    %rdx,%rax
    b6e6:	73 17                	jae    b6ff <fwp_main_thread+0xaef>
    b6e8:	48 01 c7             	add    %rax,%rdi
    b6eb:	0f b6 07             	movzbl (%rdi),%eax
    b6ee:	84 c0                	test   %al,%al
    b6f0:	74 0d                	je     b6ff <fwp_main_thread+0xaef>
    b6f2:	3c fd                	cmp    $0xfd,%al
    b6f4:	0f 87 e4 02 00 00    	ja     b9de <fwp_main_thread+0xdce>
    b6fa:	83 c0 01             	add    $0x1,%eax
    b6fd:	88 07                	mov    %al,(%rdi)
    b6ff:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b704:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b708:	b9 01 00 00 00       	mov    $0x1,%ecx
    b70d:	4c 89 ee             	mov    %r13,%rsi
    b710:	48 8d 15 89 44 00 00 	lea    0x4489(%rip),%rdx        # fba0 <d0>
    b717:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b71c:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    b723:	00 00 
    b725:	e8 a6 e4 ff ff       	call   9bd0 <fwp_write>
    b72a:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    b72f:	4c 8b 7c 24 48       	mov    0x48(%rsp),%r15
    b734:	48 8d 05 f3 08 00 00 	lea    0x8f3(%rip),%rax        # c02e <_IO_stdin_used+0x2e>
    b73b:	4d 85 f6             	test   %r14,%r14
    b73e:	4c 0f 44 f0          	cmove  %rax,%r14
    b742:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    b746:	0f 87 31 03 00 00    	ja     ba7d <fwp_main_thread+0xe6d>
    b74c:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    b750:	be 01 00 00 00       	mov    $0x1,%esi
    b755:	e8 f6 a2 ff ff       	call   5a50 <fwp_heap_alloc>
    b75a:	4c 89 fa             	mov    %r15,%rdx
    b75d:	4c 89 f6             	mov    %r14,%rsi
    b760:	4c 89 38             	mov    %r15,(%rax)
    b763:	48 89 c5             	mov    %rax,%rbp
    b766:	48 8d 40 08          	lea    0x8(%rax),%rax
    b76a:	48 89 c7             	mov    %rax,%rdi
    b76d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    b772:	e8 29 7e ff ff       	call   35a0 <memcpy@plt>
    b777:	42 c6 44 3d 08 00    	movb   $0x0,0x8(%rbp,%r15,1)
    b77d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    b782:	e8 39 7c ff ff       	call   33c0 <free@plt>
    b787:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b78e:	48 89 e8             	mov    %rbp,%rax
    b791:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b798:	48 c1 e2 10          	shl    $0x10,%rdx
    b79c:	48 39 d0             	cmp    %rdx,%rax
    b79f:	73 57                	jae    b7f8 <fwp_main_thread+0xbe8>
    b7a1:	48 89 c2             	mov    %rax,%rdx
    b7a4:	48 c1 ea 10          	shr    $0x10,%rdx
    b7a8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7ac:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b7b3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7b7:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b7bb:	4d 85 f6             	test   %r14,%r14
    b7be:	74 38                	je     b7f8 <fwp_main_thread+0xbe8>
    b7c0:	0f b6 0a             	movzbl (%rdx),%ecx
    b7c3:	80 f9 02             	cmp    $0x2,%cl
    b7c6:	0f 84 89 01 00 00    	je     b955 <fwp_main_thread+0xd45>
    b7cc:	80 f9 01             	cmp    $0x1,%cl
    b7cf:	75 27                	jne    b7f8 <fwp_main_thread+0xbe8>
    b7d1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b7d4:	0f b7 c0             	movzwl %ax,%eax
    b7d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b7da:	48 0f af c1          	imul   %rcx,%rax
    b7de:	48 c1 e8 20          	shr    $0x20,%rax
    b7e2:	48 39 d0             	cmp    %rdx,%rax
    b7e5:	73 11                	jae    b7f8 <fwp_main_thread+0xbe8>
    b7e7:	49 01 c6             	add    %rax,%r14
    b7ea:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b7ee:	0f 84 f4 01 00 00    	je     b9e8 <fwp_main_thread+0xdd8>
    b7f4:	41 c6 06 01          	movb   $0x1,(%r14)
    b7f8:	4c 89 ef             	mov    %r13,%rdi
    b7fb:	e8 b0 af ff ff       	call   67b0 <fwp_drop0>
    b800:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    b804:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    b809:	be 01 00 00 00       	mov    $0x1,%esi
    b80e:	48 8b 0d ab 6b 01 00 	mov    0x16bab(%rip),%rcx        # 223c0 <fwp_prog_out>
    b815:	e8 66 7e ff ff       	call   3680 <fwrite@plt>
    b81a:	48 8b 35 9f 6b 01 00 	mov    0x16b9f(%rip),%rsi        # 223c0 <fwp_prog_out>
    b821:	bf 0a 00 00 00       	mov    $0xa,%edi
    b826:	e8 b5 7c ff ff       	call   34e0 <fputc@plt>
    b82b:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b832:	48 89 e8             	mov    %rbp,%rax
    b835:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b83c:	48 c1 e2 10          	shl    $0x10,%rdx
    b840:	48 39 d0             	cmp    %rdx,%rax
    b843:	73 6b                	jae    b8b0 <fwp_main_thread+0xca0>
    b845:	48 89 c2             	mov    %rax,%rdx
    b848:	48 c1 ea 10          	shr    $0x10,%rdx
    b84c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b850:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b857:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b85b:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b85f:	4d 85 f6             	test   %r14,%r14
    b862:	74 4c                	je     b8b0 <fwp_main_thread+0xca0>
    b864:	0f b6 0a             	movzbl (%rdx),%ecx
    b867:	80 f9 02             	cmp    $0x2,%cl
    b86a:	0f 84 d7 00 00 00    	je     b947 <fwp_main_thread+0xd37>
    b870:	80 f9 01             	cmp    $0x1,%cl
    b873:	75 3b                	jne    b8b0 <fwp_main_thread+0xca0>
    b875:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b878:	0f b7 c0             	movzwl %ax,%eax
    b87b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b87e:	48 0f af c1          	imul   %rcx,%rax
    b882:	48 c1 e8 20          	shr    $0x20,%rax
    b886:	48 39 d0             	cmp    %rdx,%rax
    b889:	73 25                	jae    b8b0 <fwp_main_thread+0xca0>
    b88b:	49 01 c6             	add    %rax,%r14
    b88e:	41 0f b6 06          	movzbl (%r14),%eax
    b892:	84 c0                	test   %al,%al
    b894:	74 1a                	je     b8b0 <fwp_main_thread+0xca0>
    b896:	3c 01                	cmp    $0x1,%al
    b898:	0f 84 0c 01 00 00    	je     b9aa <fwp_main_thread+0xd9a>
    b89e:	3c ff                	cmp    $0xff,%al
    b8a0:	0f 84 4f 01 00 00    	je     b9f5 <fwp_main_thread+0xde5>
    b8a6:	83 e8 01             	sub    $0x1,%eax
    b8a9:	41 88 06             	mov    %al,(%r14)
    b8ac:	0f 1f 40 00          	nopl   0x0(%rax)
    b8b0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    b8b5:	48 8b 40 10          	mov    0x10(%rax),%rax
    b8b9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b8be:	48 85 c0             	test   %rax,%rax
    b8c1:	0f 84 b9 00 00 00    	je     b980 <fwp_main_thread+0xd70>
    b8c7:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    b8ce:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b8d5:	e9 b9 fd ff ff       	jmp    b693 <fwp_main_thread+0xa83>
    b8da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b8e0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b8e4:	e9 fc f4 ff ff       	jmp    ade5 <fwp_main_thread+0x1d5>
    b8e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b8f0:	66 85 c0             	test   %ax,%ax
    b8f3:	0f 85 06 fe ff ff    	jne    b6ff <fwp_main_thread+0xaef>
    b8f9:	e9 ed fd ff ff       	jmp    b6eb <fwp_main_thread+0xadb>
    b8fe:	66 90                	xchg   %ax,%ax
    b900:	66 85 c0             	test   %ax,%ax
    b903:	0f 85 85 fd ff ff    	jne    b68e <fwp_main_thread+0xa7e>
    b909:	e9 64 fd ff ff       	jmp    b672 <fwp_main_thread+0xa62>
    b90e:	66 90                	xchg   %ax,%ax
    b910:	66 85 c0             	test   %ax,%ax
    b913:	0f 85 cb fc ff ff    	jne    b5e4 <fwp_main_thread+0x9d4>
    b919:	e9 b6 fc ff ff       	jmp    b5d4 <fwp_main_thread+0x9c4>
    b91e:	66 90                	xchg   %ax,%ax
    b920:	66 85 c0             	test   %ax,%ax
    b923:	0f 85 25 fc ff ff    	jne    b54e <fwp_main_thread+0x93e>
    b929:	e9 10 fc ff ff       	jmp    b53e <fwp_main_thread+0x92e>
    b92e:	66 90                	xchg   %ax,%ax
    b930:	48 89 d7             	mov    %rdx,%rdi
    b933:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    b938:	e8 d3 99 ff ff       	call   5310 <fwp_rc_forget_slot>
    b93d:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    b942:	e9 c4 fa ff ff       	jmp    b40b <fwp_main_thread+0x7fb>
    b947:	66 85 c0             	test   %ax,%ax
    b94a:	0f 85 60 ff ff ff    	jne    b8b0 <fwp_main_thread+0xca0>
    b950:	e9 39 ff ff ff       	jmp    b88e <fwp_main_thread+0xc7e>
    b955:	66 85 c0             	test   %ax,%ax
    b958:	0f 85 9a fe ff ff    	jne    b7f8 <fwp_main_thread+0xbe8>
    b95e:	e9 87 fe ff ff       	jmp    b7ea <fwp_main_thread+0xbda>
    b963:	48 83 3d cd 4d 01 00 	cmpq   $0x0,0x14dcd(%rip)        # 20738 <fwp_root>
    b96a:	00 
    b96b:	c7 05 0b 47 01 00 00 	movl   $0x0,0x1470b(%rip)        # 20080 <fwp_exit_code>
    b972:	00 00 00 
    b975:	0f 84 6d f7 ff ff    	je     b0e8 <fwp_main_thread+0x4d8>
    b97b:	e9 d0 7d ff ff       	jmp    3750 <fwp_main_thread.cold>
    b980:	4c 89 ef             	mov    %r13,%rdi
    b983:	e8 28 ae ff ff       	call   67b0 <fwp_drop0>
    b988:	4c 89 e7             	mov    %r12,%rdi
    b98b:	e8 20 ae ff ff       	call   67b0 <fwp_drop0>
    b990:	48 c7 05 cd 46 00 00 	movq   $0x0,0x46cd(%rip)        # 10068 <v.2>
    b997:	00 00 00 00 
    b99b:	c7 05 cb 46 00 00 01 	movl   $0x1,0x46cb(%rip)        # 10070 <st.3>
    b9a2:	00 00 00 
    b9a5:	e9 87 f3 ff ff       	jmp    ad31 <fwp_main_thread+0x121>
    b9aa:	48 89 ef             	mov    %rbp,%rdi
    b9ad:	e8 ee ac ff ff       	call   66a0 <fwp_rc_free_arr>
    b9b2:	e9 f9 fe ff ff       	jmp    b8b0 <fwp_main_thread+0xca0>
    b9b7:	4c 89 ef             	mov    %r13,%rdi
    b9ba:	e8 51 99 ff ff       	call   5310 <fwp_rc_forget_slot>
    b9bf:	e9 85 fb ff ff       	jmp    b549 <fwp_main_thread+0x939>
    b9c4:	4c 89 ef             	mov    %r13,%rdi
    b9c7:	e8 44 99 ff ff       	call   5310 <fwp_rc_forget_slot>
    b9cc:	e9 0e fc ff ff       	jmp    b5df <fwp_main_thread+0x9cf>
    b9d1:	4c 89 f7             	mov    %r14,%rdi
    b9d4:	e8 37 99 ff ff       	call   5310 <fwp_rc_forget_slot>
    b9d9:	e9 9e fc ff ff       	jmp    b67c <fwp_main_thread+0xa6c>
    b9de:	e8 0d 98 ff ff       	call   51f0 <fwp_rc_wide_dup>
    b9e3:	e9 17 fd ff ff       	jmp    b6ff <fwp_main_thread+0xaef>
    b9e8:	4c 89 f7             	mov    %r14,%rdi
    b9eb:	e8 20 99 ff ff       	call   5310 <fwp_rc_forget_slot>
    b9f0:	e9 ff fd ff ff       	jmp    b7f4 <fwp_main_thread+0xbe4>
    b9f5:	4c 89 f0             	mov    %r14,%rax
    b9f8:	48 c1 e8 11          	shr    $0x11,%rax
    b9fc:	4c 31 f0             	xor    %r14,%rax
    b9ff:	48 89 c2             	mov    %rax,%rdx
    ba02:	48 c1 ea 09          	shr    $0x9,%rdx
    ba06:	48 31 d0             	xor    %rdx,%rax
    ba09:	0f b6 d0             	movzbl %al,%edx
    ba0c:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    ba13:	00 
    ba14:	48 85 c0             	test   %rax,%rax
    ba17:	75 10                	jne    ba29 <fwp_main_thread+0xe19>
    ba19:	eb 51                	jmp    ba6c <fwp_main_thread+0xe5c>
    ba1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ba20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    ba24:	48 85 c0             	test   %rax,%rax
    ba27:	74 43                	je     ba6c <fwp_main_thread+0xe5c>
    ba29:	48 89 c2             	mov    %rax,%rdx
    ba2c:	4c 3b 30             	cmp    (%rax),%r14
    ba2f:	75 ef                	jne    ba20 <fwp_main_thread+0xe10>
    ba31:	48 8b 48 08          	mov    0x8(%rax),%rcx
    ba35:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    ba39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    ba3d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    ba44:	0f 85 66 fe ff ff    	jne    b8b0 <fwp_main_thread+0xca0>
    ba4a:	4c 89 f7             	mov    %r14,%rdi
    ba4d:	e8 be 98 ff ff       	call   5310 <fwp_rc_forget_slot>
    ba52:	41 c6 06 fe          	movb   $0xfe,(%r14)
    ba56:	e9 55 fe ff ff       	jmp    b8b0 <fwp_main_thread+0xca0>
    ba5b:	48 8d 3d 8e 0e 00 00 	lea    0xe8e(%rip),%rdi        # c8f0 <_IO_stdin_used+0x8f0>
    ba62:	e8 39 87 ff ff       	call   41a0 <fwp_trap>
    ba67:	e8 44 82 ff ff       	call   3cb0 <fwp_heap_oom>
    ba6c:	48 8d 3d 25 0d 00 00 	lea    0xd25(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    ba73:	e8 28 87 ff ff       	call   41a0 <fwp_trap>
    ba78:	e8 e3 79 ff ff       	call   3460 <__stack_chk_fail@plt>
    ba7d:	48 8d 3d 64 07 00 00 	lea    0x764(%rip),%rdi        # c1e8 <_IO_stdin_used+0x1e8>
    ba84:	e8 17 87 ff ff       	call   41a0 <fwp_trap>
    ba89:	e9 c2 7c ff ff       	jmp    3750 <fwp_main_thread.cold>
    ba8e:	e9 bd 7c ff ff       	jmp    3750 <fwp_main_thread.cold>
    ba93:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ba9a:	00 00 00 
    ba9d:	0f 1f 00             	nopl   (%rax)

000000000000baa0 <__divmodti4>:
    baa0:	f3 0f 1e fa          	endbr64
    baa4:	55                   	push   %rbp
    baa5:	49 89 f1             	mov    %rsi,%r9
    baa8:	49 89 d2             	mov    %rdx,%r10
    baab:	48 89 fe             	mov    %rdi,%rsi
    baae:	49 89 cb             	mov    %rcx,%r11
    bab1:	48 89 e5             	mov    %rsp,%rbp
    bab4:	41 57                	push   %r15
    bab6:	41 56                	push   %r14
    bab8:	41 55                	push   %r13
    baba:	41 54                	push   %r12
    babc:	53                   	push   %rbx
    babd:	4c 89 c3             	mov    %r8,%rbx
    bac0:	45 31 c0             	xor    %r8d,%r8d
    bac3:	4d 85 c9             	test   %r9,%r9
    bac6:	79 12                	jns    bada <__divmodti4+0x3a>
    bac8:	31 ff                	xor    %edi,%edi
    baca:	48 f7 de             	neg    %rsi
    bacd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bad4:	4c 19 cf             	sbb    %r9,%rdi
    bad7:	49 89 f9             	mov    %rdi,%r9
    bada:	4c 89 d8             	mov    %r11,%rax
    badd:	4d 85 db             	test   %r11,%r11
    bae0:	0f 88 1a 01 00 00    	js     bc00 <__divmodti4+0x160>
    bae6:	4c 89 d9             	mov    %r11,%rcx
    bae9:	49 89 f3             	mov    %rsi,%r11
    baec:	75 62                	jne    bb50 <__divmodti4+0xb0>
    baee:	4d 89 c4             	mov    %r8,%r12
    baf1:	4d 39 d1             	cmp    %r10,%r9
    baf4:	0f 83 46 01 00 00    	jae    bc40 <__divmodti4+0x1a0>
    bafa:	4c 89 d8             	mov    %r11,%rax
    bafd:	4c 89 ca             	mov    %r9,%rdx
    bb00:	49 f7 f2             	div    %r10
    bb03:	49 89 c3             	mov    %rax,%r11
    bb06:	31 c0                	xor    %eax,%eax
    bb08:	48 89 d6             	mov    %rdx,%rsi
    bb0b:	31 ff                	xor    %edi,%edi
    bb0d:	4c 89 d9             	mov    %r11,%rcx
    bb10:	48 89 c2             	mov    %rax,%rdx
    bb13:	48 89 c8             	mov    %rcx,%rax
    bb16:	4d 85 e4             	test   %r12,%r12
    bb19:	74 0a                	je     bb25 <__divmodti4+0x85>
    bb1b:	48 f7 d8             	neg    %rax
    bb1e:	48 83 d2 00          	adc    $0x0,%rdx
    bb22:	48 f7 da             	neg    %rdx
    bb25:	4d 85 c0             	test   %r8,%r8
    bb28:	74 0a                	je     bb34 <__divmodti4+0x94>
    bb2a:	48 f7 de             	neg    %rsi
    bb2d:	48 83 d7 00          	adc    $0x0,%rdi
    bb31:	48 f7 df             	neg    %rdi
    bb34:	48 89 33             	mov    %rsi,(%rbx)
    bb37:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bb3b:	5b                   	pop    %rbx
    bb3c:	41 5c                	pop    %r12
    bb3e:	41 5d                	pop    %r13
    bb40:	41 5e                	pop    %r14
    bb42:	41 5f                	pop    %r15
    bb44:	5d                   	pop    %rbp
    bb45:	c3                   	ret
    bb46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bb4d:	00 00 00 
    bb50:	4d 89 c4             	mov    %r8,%r12
    bb53:	49 39 c1             	cmp    %rax,%r9
    bb56:	0f 82 ce 00 00 00    	jb     bc2a <__divmodti4+0x18a>
    bb5c:	31 ff                	xor    %edi,%edi
    bb5e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bb63:	48 63 c7             	movslq %edi,%rax
    bb66:	be 40 00 00 00       	mov    $0x40,%esi
    bb6b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bb70:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bb75:	48 29 c6             	sub    %rax,%rsi
    bb78:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bb7d:	48 09 c8             	or     %rcx,%rax
    bb80:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bb85:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bb8a:	49 89 c6             	mov    %rax,%r14
    bb8d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bb91:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bb96:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bb9b:	49 09 c1             	or     %rax,%r9
    bb9e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bba2:	4c 89 c8             	mov    %r9,%rax
    bba5:	49 f7 f6             	div    %r14
    bba8:	48 89 d1             	mov    %rdx,%rcx
    bbab:	49 89 c3             	mov    %rax,%r11
    bbae:	49 89 c1             	mov    %rax,%r9
    bbb1:	49 f7 e2             	mul    %r10
    bbb4:	49 89 c6             	mov    %rax,%r14
    bbb7:	49 89 d2             	mov    %rdx,%r10
    bbba:	48 39 d1             	cmp    %rdx,%rcx
    bbbd:	72 07                	jb     bbc6 <__divmodti4+0x126>
    bbbf:	75 17                	jne    bbd8 <__divmodti4+0x138>
    bbc1:	49 39 c7             	cmp    %rax,%r15
    bbc4:	73 12                	jae    bbd8 <__divmodti4+0x138>
    bbc6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bbca:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bbce:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bbd2:	49 89 d2             	mov    %rdx,%r10
    bbd5:	49 89 c6             	mov    %rax,%r14
    bbd8:	4c 89 f8             	mov    %r15,%rax
    bbdb:	4c 29 f0             	sub    %r14,%rax
    bbde:	4c 19 d1             	sbb    %r10,%rcx
    bbe1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bbe6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bbeb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bbf0:	48 09 c6             	or     %rax,%rsi
    bbf3:	48 89 cf             	mov    %rcx,%rdi
    bbf6:	31 c0                	xor    %eax,%eax
    bbf8:	4c 89 c9             	mov    %r9,%rcx
    bbfb:	e9 10 ff ff ff       	jmp    bb10 <__divmodti4+0x70>
    bc00:	4c 89 d0             	mov    %r10,%rax
    bc03:	4c 89 da             	mov    %r11,%rdx
    bc06:	4d 89 c4             	mov    %r8,%r12
    bc09:	49 89 f3             	mov    %rsi,%r11
    bc0c:	48 f7 d8             	neg    %rax
    bc0f:	49 f7 d4             	not    %r12
    bc12:	48 83 d2 00          	adc    $0x0,%rdx
    bc16:	49 89 c2             	mov    %rax,%r10
    bc19:	48 f7 da             	neg    %rdx
    bc1c:	48 89 d1             	mov    %rdx,%rcx
    bc1f:	0f 84 cc fe ff ff    	je     baf1 <__divmodti4+0x51>
    bc25:	49 39 d1             	cmp    %rdx,%r9
    bc28:	73 46                	jae    bc70 <__divmodti4+0x1d0>
    bc2a:	4c 89 cf             	mov    %r9,%rdi
    bc2d:	31 c0                	xor    %eax,%eax
    bc2f:	31 c9                	xor    %ecx,%ecx
    bc31:	e9 da fe ff ff       	jmp    bb10 <__divmodti4+0x70>
    bc36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bc3d:	00 00 00 
    bc40:	4d 85 d2             	test   %r10,%r10
    bc43:	75 0d                	jne    bc52 <__divmodti4+0x1b2>
    bc45:	b8 01 00 00 00       	mov    $0x1,%eax
    bc4a:	31 d2                	xor    %edx,%edx
    bc4c:	49 f7 f2             	div    %r10
    bc4f:	49 89 c2             	mov    %rax,%r10
    bc52:	4c 89 c8             	mov    %r9,%rax
    bc55:	31 d2                	xor    %edx,%edx
    bc57:	49 f7 f2             	div    %r10
    bc5a:	49 89 c1             	mov    %rax,%r9
    bc5d:	4c 89 d8             	mov    %r11,%rax
    bc60:	49 f7 f2             	div    %r10
    bc63:	49 89 c3             	mov    %rax,%r11
    bc66:	4c 89 c8             	mov    %r9,%rax
    bc69:	e9 9a fe ff ff       	jmp    bb08 <__divmodti4+0x68>
    bc6e:	66 90                	xchg   %ax,%ax
    bc70:	45 31 f6             	xor    %r14d,%r14d
    bc73:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bc78:	44 89 f7             	mov    %r14d,%edi
    bc7b:	45 85 f6             	test   %r14d,%r14d
    bc7e:	0f 85 df fe ff ff    	jne    bb63 <__divmodti4+0xc3>
    bc84:	4c 39 ca             	cmp    %r9,%rdx
    bc87:	72 17                	jb     bca0 <__divmodti4+0x200>
    bc89:	31 c9                	xor    %ecx,%ecx
    bc8b:	48 39 c6             	cmp    %rax,%rsi
    bc8e:	73 10                	jae    bca0 <__divmodti4+0x200>
    bc90:	4c 89 cf             	mov    %r9,%rdi
    bc93:	31 c0                	xor    %eax,%eax
    bc95:	e9 76 fe ff ff       	jmp    bb10 <__divmodti4+0x70>
    bc9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bca0:	4c 89 de             	mov    %r11,%rsi
    bca3:	b9 01 00 00 00       	mov    $0x1,%ecx
    bca8:	48 29 c6             	sub    %rax,%rsi
    bcab:	49 19 d1             	sbb    %rdx,%r9
    bcae:	eb e0                	jmp    bc90 <__divmodti4+0x1f0>

000000000000bcb0 <atexit>:
    bcb0:	f3 0f 1e fa          	endbr64
    bcb4:	48 8b 15 4d 43 00 00 	mov    0x434d(%rip),%rdx        # 10008 <__dso_handle>
    bcbb:	31 f6                	xor    %esi,%esi
    bcbd:	e9 9e 79 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bcc4 <_fini>:
    bcc4:	f3 0f 1e fa          	endbr64
    bcc8:	48 83 ec 08          	sub    $0x8,%rsp
    bccc:	48 83 c4 08          	add    $0x8,%rsp
    bcd0:	c3                   	ret
