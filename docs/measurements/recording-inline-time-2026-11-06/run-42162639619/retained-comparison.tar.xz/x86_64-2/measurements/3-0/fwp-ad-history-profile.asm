
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 df 00 00 	mov    0xdfd1(%rip),%rax        # 10fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 dd 00 00    	push   0xddf2(%rip)        # 10e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 dd 00 00    	jmp    *0xddf4(%rip)        # 10e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 dc 00 00    	jmp    *0xdc66(%rip)        # 10ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e da 00 00    	jmp    *0xda8e(%rip)        # 10e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 da 00 00    	jmp    *0xda86(%rip)        # 10e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e da 00 00    	jmp    *0xda7e(%rip)        # 10e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 da 00 00    	jmp    *0xda76(%rip)        # 10e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e da 00 00    	jmp    *0xda6e(%rip)        # 10e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 da 00 00    	jmp    *0xda66(%rip)        # 10e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e da 00 00    	jmp    *0xda5e(%rip)        # 10e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 da 00 00    	jmp    *0xda56(%rip)        # 10e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e da 00 00    	jmp    *0xda4e(%rip)        # 10e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 da 00 00    	jmp    *0xda46(%rip)        # 10e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e da 00 00    	jmp    *0xda3e(%rip)        # 10e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 da 00 00    	jmp    *0xda36(%rip)        # 10e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e da 00 00    	jmp    *0xda2e(%rip)        # 10e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 da 00 00    	jmp    *0xda26(%rip)        # 10e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e da 00 00    	jmp    *0xda1e(%rip)        # 10e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 da 00 00    	jmp    *0xda16(%rip)        # 10ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e da 00 00    	jmp    *0xda0e(%rip)        # 10ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 da 00 00    	jmp    *0xda06(%rip)        # 10eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe d9 00 00    	jmp    *0xd9fe(%rip)        # 10eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 d9 00 00    	jmp    *0xd9f6(%rip)        # 10ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee d9 00 00    	jmp    *0xd9ee(%rip)        # 10ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 d9 00 00    	jmp    *0xd9e6(%rip)        # 10ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de d9 00 00    	jmp    *0xd9de(%rip)        # 10ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 d9 00 00    	jmp    *0xd9d6(%rip)        # 10ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce d9 00 00    	jmp    *0xd9ce(%rip)        # 10ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 d9 00 00    	jmp    *0xd9c6(%rip)        # 10ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be d9 00 00    	jmp    *0xd9be(%rip)        # 10ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 d9 00 00    	jmp    *0xd9b6(%rip)        # 10f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae d9 00 00    	jmp    *0xd9ae(%rip)        # 10f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 d9 00 00    	jmp    *0xd9a6(%rip)        # 10f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e d9 00 00    	jmp    *0xd99e(%rip)        # 10f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 d9 00 00    	jmp    *0xd996(%rip)        # 10f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e d9 00 00    	jmp    *0xd98e(%rip)        # 10f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 d9 00 00    	jmp    *0xd986(%rip)        # 10f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e d9 00 00    	jmp    *0xd97e(%rip)        # 10f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 d9 00 00    	jmp    *0xd976(%rip)        # 10f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e d9 00 00    	jmp    *0xd96e(%rip)        # 10f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 d9 00 00    	jmp    *0xd966(%rip)        # 10f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e d9 00 00    	jmp    *0xd95e(%rip)        # 10f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 d9 00 00    	jmp    *0xd956(%rip)        # 10f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e d9 00 00    	jmp    *0xd94e(%rip)        # 10f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 d9 00 00    	jmp    *0xd946(%rip)        # 10f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e d9 00 00    	jmp    *0xd93e(%rip)        # 10f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 d9 00 00    	jmp    *0xd936(%rip)        # 10f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e d9 00 00    	jmp    *0xd92e(%rip)        # 10f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 d9 00 00    	jmp    *0xd926(%rip)        # 10f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e d9 00 00    	jmp    *0xd91e(%rip)        # 10f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 d9 00 00    	jmp    *0xd916(%rip)        # 10fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e d9 00 00    	jmp    *0xd90e(%rip)        # 10fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 d9 00 00    	jmp    *0xd906(%rip)        # 10fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe d8 00 00    	jmp    *0xd8fe(%rip)        # 10fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 d8 00 00    	jmp    *0xd8f6(%rip)        # 10fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee d8 00 00    	jmp    *0xd8ee(%rip)        # 10fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 99 00 00 	lea    0x99b8(%rip),%r9        # d0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 99 00 00 	lea    0x99b5(%rip),%r8        # d0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 bd 00 00 	lea    0xbd01(%rip),%rax        # f480 <fwp_fn_table>
    377f:	48 89 05 f2 7c 06 00 	mov    %rax,0x67cf2(%rip)        # 6b478 <fwp_fns>
    3786:	48 8b 05 93 d8 00 00 	mov    0xd893(%rip),%rax        # 11020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 7c 06 00 	mov    %rax,0x67cec(%rip)        # 6b480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 9b 00 00 	lea    0x9b4e(%rip),%rdi        # d2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 d8 00 00 	mov    0xd818(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 4f 79 00 00 	lea    0x794f(%rip),%rdx        # b1b0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 d7 00 00 	mov    0xd783(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 d7 01 00    	mov    0x1d7d8(%rip),%eax        # 21080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 99 00 00 	lea    0x99fe(%rip),%rdi        # d2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 a3 00 00 	lea    0xa346(%rip),%rdi        # dc50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 a3 00 00 	lea    0xa300(%rip),%rdi        # dc28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 a2 00 00 	lea    0xa2c4(%rip),%rdi        # dbf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 a2 00 00 	lea    0xa290(%rip),%rdi        # dbd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b d6 00 00    	call   *0xd65b(%rip)        # 10fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 d6 00 00 	lea    0xd699(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 d6 00 00 	lea    0xd692(%rip),%rax        # 11020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e d6 00 00 	mov    0xd63e(%rip),%rax        # 10fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 d6 00 00 	lea    0xd669(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 d6 00 00 	lea    0xd662(%rip),%rsi        # 11020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d d6 00 00 	mov    0xd60d(%rip),%rax        # 10fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d d6 00 00 00 	cmpb   $0x0,0xd64d(%rip)        # 11048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea d5 00 00 	cmpq   $0x0,0xd5ea(%rip)        # 10ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 d5 00 00 	mov    0xd5f6(%rip),%rdi        # 11008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 d6 00 00 01 	movb   $0x1,0xd625(%rip)        # 11048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 d5 04 00 	lea    0x4d597(%rip),%r8        # 511a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b d5 04 00 	lea    0x4d53b(%rip),%rcx        # 51160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f d5 04 00 	lea    0x4d50f(%rip),%rcx        # 51140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 d5 04 00 	lea    0x4d541(%rip),%rcx        # 51180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 d5 04 	movdqa 0x4d550(%rip),%xmm0        # 511b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 d5 04 	paddq  0x4d538(%rip),%xmm0        # 511a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f d4 04 00 	cmp    %rax,0x4d49f(%rip)        # 51120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 d4 04 	movq   %xmm0,0x4d495(%rip)        # 51120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e d4 01 00 	add    0x1d43e(%rip),%rdx        # 210f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c d4 01 00 	add    0x1d42c(%rip),%rax        # 210f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 77 06 00 	mov    0x67779(%rip),%rdi        # 6b480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 d3 00 00 	mov    0xd304(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 d2 00 00 	mov    0xd2f1(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 5a 06 00 	mov    0x65ab1(%rip),%rax        # 69800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 53 06 00 	mov    0x653f9(%rip),%rax        # 691c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 53 06 00 	sub    0x653e5(%rip),%rax        # 691c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d 9f 00 00 	lea    0x9f1d(%rip),%rsi        # dd30 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 91 00 00 	lea    0x91c5(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 d1 00 00 	mov    0xd1f2(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 6d 06 00 	mov    0x66d8b(%rip),%rax        # 6ac10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 6d 06 00 	lea    0x66d84(%rip),%r8        # 6ac10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 6d 06 00 	mov    0x66d65(%rip),%rbx        # 6abf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 6d 06 00 	mov    0x66d75(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 6d 06 00 	mov    0x66d11(%rip),%rdi        # 6ac00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 6d 06 00 	sub    %rsi,0x66d5a(%rip)        # 6ac50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 6c 06 00 	mov    0x66cea(%rip),%rax        # 6abf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 6c 06 00 	add    0x66ca0(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 6c 06 00 	mov    0x66cae(%rip),%rsi        # 6ac00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 6c 06 00 	mov    0x66cbc(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 6c 06 00 	mov    %r12,0x66c6b(%rip)        # 6ac00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 6c 06 00 	mov    %rbp,0x66c59(%rip)        # 6abf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 6c 06 00 	cmp    %rdi,0x66c3e(%rip)        # 6abe8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 6c 06 00 	mov    %rdi,0x66c35(%rip)        # 6abe8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 6c 06 00 	sub    %rdi,0x66c79(%rip)        # 6ac50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 6c 06 00 	mov    0x66c21(%rip),%rax        # 6ac08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 6c 06 00 	lea    0x66c1a(%rip),%r8        # 6ac08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef 96 00 00 	lea    0x96ef(%rip),%rdx        # d6f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 d0 00 00 	mov    0xd022(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d cf 00 00 	mov    0xcf7d(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 8f 00 00 	lea    0x8f34(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 56 06 00 	cmp    0x656c9(%rip),%rdi        # 69800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 56 06 00 	mov    0x6568f(%rip),%rax        # 697e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 56 06 00 	mov    %rdi,0x6566d(%rip)        # 697e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 56 06 00 	mov    %rdi,0x65649(%rip)        # 697e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f 90 00 00 	lea    0x905f(%rip),%rsi        # d240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 8e 00 00 	lea    0x8e27(%rip),%rsi        # d01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 cf 04 	movdqa 0x4cf76(%rip),%xmm0        # 511b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e cf 04 	paddq  0x4cf5e(%rip),%xmm0        # 511a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 ce 01 00 	mov    0x1ce84(%rip),%r8        # 210f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e ce 04 00 	mov    0x4ce9e(%rip),%rcx        # 51120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 cd 00 00 	mov    0xcdb7(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 94 00 00 	lea    0x94b5(%rip),%rdx        # d748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 ce 04 00 	lea    0x4cee1(%rip),%r15        # 51180 <ad_raw_peak>
    429f:	4c 8d 35 9a ce 04 00 	lea    0x4ce9a(%rip),%r14        # 51140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 8d 00 00 	lea    0x8d79(%rip),%rax        # d02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 c9 00 	movq   0xc956(%rip),%xmm0        # 10c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f ce 04 00 	lea    0x4ce9f(%rip),%r13        # 51160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 8d 00 00 	lea    0x8d6f(%rip),%rax        # d03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 c9 00 	movq   0xc936(%rip),%xmm0        # 10c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 cd 00 00 	mov    0xcd33(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 8d 00 00 	lea    0x8d0c(%rip),%rcx        # d020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d 94 00 00 	lea    0x948d(%rip),%rdx        # d7a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 cd 00 00 	mov    0xcd04(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 8c 00 00 	lea    0x8cf8(%rip),%rdi        # d045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 cd 01 00 	cmpq   $0x0,0x1cda6(%rip)        # 21100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd cd 01 00 	mov    0x1cdbd(%rip),%r8        # 21120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be cd 01 00 	mov    0x1cdbe(%rip),%r9        # 21128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af cd 01 00 	lea    0x1cdaf(%rip),%rbx        # 21120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 8c 00 00 	lea    0x8cf4(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 cd 01 00 	mov    0x1cdb1(%rip),%rax        # 21130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 8c 00 00 	lea    0x8c9a(%rip),%r12        # d020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 cc 00 00 	mov    0xcc89(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 94 00 00 	lea    0x9429(%rip),%rdx        # d7e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 cd 01 00 	cmp    0x1cd33(%rip),%rbp        # 21100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 cc 00 00 	mov    0xcc58(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 8c 00 00 	lea    0x8c5b(%rip),%rdi        # d059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 cc 00 00 	mov    0xcc23(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 93 00 00 	lea    0x9384(%rip),%rdx        # d7a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 8c 00 00 	lea    0x8c40(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da 92 00 00 	lea    0x92da(%rip),%rdi        # d720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 cb 00 00 	mov    0xcbc8(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 8b 00 00 	lea    0x8bdf(%rip),%rdx        # d05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 cb 00 00 	mov    0xcbb0(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ca 00 00 	mov    0xcac1(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 8a 00 00 	lea    0x8a78(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 8a 00 00 	lea    0x8ac0(%rip),%rdi        # d06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 8a 00 00 	lea    0x8a48(%rip),%rdi        # d087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 91 00 00 	lea    0x91d8(%rip),%rdi        # d828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 96 00 	movdqa 0x96e0(%rip),%xmm0        # dd50 <msg.4+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 6d 06 00 	add    0x66daa(%rip),%rax        # 6b478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c 91 00 00 	lea    0x912c(%rip),%rdi        # d850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 c9 01 00 	cmp    %rax,0x1c9a5(%rip)        # 210e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 c9 01 00 	add    0x1c9a0(%rip),%rax        # 210f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 91 00 00 	lea    0x9115(%rip),%rdi        # d880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 89 00 00 	lea    0x8920(%rip),%r8        # d0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 87 00 00 	lea    0x8775(%rip),%r8        # d0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 86 00 00 	lea    0x8612(%rip),%r8        # d0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 83 00 00 	lea    0x83ea(%rip),%rdi        # d0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a 85 00 00 	lea    0x859a(%rip),%rsi        # d288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 5e 06 00 	mov    0x65e85(%rip),%r9        # 6abe8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 5e 06 00 	mov    0x65ede(%rip),%r8        # 6ac48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f 8b 00 00 	lea    0x8b5f(%rip),%rdx        # d8d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 5e 06 00 	mov    0x65ec6(%rip),%rcx        # 6ac40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 5e 06 	movsd  0x65ed4(%rip),%xmm1        # 6ac60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 5e 06 	movsd  0x65ec4(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 c2 00 00 	mov    0xc2a5(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 8f 00 	movdqa 0x8f88(%rip),%xmm0        # dd60 <msg.4+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 59 06 00 	lea    0x6597f(%rip),%rax        # 6a760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 8f 00 	movdqa 0x8fb1(%rip),%xmm2        # dda0 <msg.4+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 59 06 00 	movaps %xmm0,0x65925(%rip)        # 6a720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d 8f 00 	movdqa 0x8f6d(%rip),%xmm0        # dd70 <msg.4+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 5d 06 00 01 	movl   $0x1,0x65db3(%rip)        # 6abc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 59 06 00 	movaps %xmm0,0x65913(%rip)        # 6a730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b 8f 00 	movdqa 0x8f5b(%rip),%xmm0        # dd80 <msg.4+0x50>
    4e24:	00 
    4e25:	0f 29 05 14 59 06 00 	movaps %xmm0,0x65914(%rip)        # 6a740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c 8f 00 	movdqa 0x8f5c(%rip),%xmm0        # dd90 <msg.4+0x60>
    4e33:	00 
    4e34:	0f 29 05 15 59 06 00 	movaps %xmm0,0x65915(%rip)        # 6a750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 49 06 00 	lea    0x64995(%rip),%r8        # 69820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 5c 06 00 	mov    %rax,0x65cb0(%rip)        # 6abd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 5c 06 00 	mov    %r12,0x65c8e(%rip)        # 6abe0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 5c 06 00 	mov    %rax,0x65c77(%rip)        # 6abd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 5c 06 00 	mov    %rbx,0x65c90(%rip)        # 6abf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 5c 06 00 	mov    %rsi,0x65cb9(%rip)        # 6ac20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 81 00 00 	lea    0x8174(%rip),%rdi        # d0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 5c 06 00 	mov    %rax,0x65c98(%rip)        # 6ac18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 5c 06 00    	mov    %eax,0x65c1c(%rip)        # 6abc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 48 06 00 	mov    0x6480c(%rip),%r8        # 697e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 47 06 00 	mov    %rbx,0x6473c(%rip)        # 697e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 47 06 00 	mov    %r8,0x64728(%rip)        # 697e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 c0 04 00 	lea    0x4c0e9(%rip),%rcx        # 511c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 c0 04 00 	lea    0x4c098(%rip),%rcx        # 511a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 7f 00 00 	lea    0x7fc2(%rip),%rdi        # d0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 c0 04 00 	lea    0x4c016(%rip),%r12        # 511c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 7e 00 00 	lea    0x7ee8(%rip),%rax        # d112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 7e 00 00 	lea    0x7ecc(%rip),%rdx        # d0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 7f 00 00 	lea    0x7f04(%rip),%rdi        # d148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 7e 00 00 	lea    0x7edd(%rip),%rdi        # d12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 7e 00 00 	lea    0x7eaa(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae bd 01 00 	lea    0x1bdae(%rip),%rdi        # 210a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 bd 01 00 	movaps %xmm0,0x1bd96(%rip)        # 210a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 bd 01 00 	mov    %rsi,0x1bd72(%rip)        # 21088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 bd 01 00 	movaps %xmm0,0x1bd93(%rip)        # 210b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 bd 01 00 	movaps %xmm0,0x1bd97(%rip)        # 210c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 bd 01 00 	mov    %rax,0x1bd98(%rip)        # 210d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 7e 00 00 	lea    0x7e09(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d bd 01 00 	mov    0x1bd1d(%rip),%rsi        # 21088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d bd 01 00 	imul   $0x68,0x1bd6d(%rip),%rdx        # 210e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 be 04 00 	cmp    0x4be26(%rip),%rdx        # 511a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 be 04 00 	mov    0x4be25(%rip),%rax        # 511a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f be 04 00 	add    0x4be1f(%rip),%rax        # 511b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 be 04 00 	add    0x4be20(%rip),%rax        # 511b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c bd 01 00 	mov    0x1bd5c(%rip),%rcx        # 21100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 bd 01 00 	mov    %rdi,0x1bd45(%rip)        # 21100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 bd 01 00 	lea    0x1bd57(%rip),%rcx        # 21120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 62 85 00 00 	lea    0x8562(%rip),%rdi        # d958 <_IO_stdin_used+0x958>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 7d 00 00 	lea    0x7d6f(%rip),%rdi        # d171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 43 06 00 	mov    0x643a7(%rip),%rbx        # 697d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a bb 00 00 	mov    0xbb0a(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 4b 84 00 00 	lea    0x844b(%rip),%rdi        # d988 <_IO_stdin_used+0x988>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 42 06 00 	mov    0x6426d(%rip),%rax        # 697e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 42 06 00 	mov    %rdx,0x64247(%rip)        # 697e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 41 06 00 	mov    0x64194(%rip),%rbx        # 697d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 41 06 00 	mov    %rbx,0x64151(%rip)        # 697d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 41 06 00 	mov    %rdx,0x64151(%rip)        # 697e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 41 06 00 	lea    0x64166(%rip),%rsi        # 69820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 5c 06 00 	addq   $0x1,0x65ce5(%rip)        # 6b468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 1f 82 00 00 	lea    0x821f(%rip),%rdi        # d9b8 <_IO_stdin_used+0x9b8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 30 82 00 00 	lea    0x8230(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 79 00 00 	lea    0x79d2(%rip),%rdi        # d18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 40 06 00 	lea    0x6401e(%rip),%rcx        # 69820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 5c 06 00 	subq   $0x1,0x65c1f(%rip)        # 6b468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 8b 81 00 00 	lea    0x818b(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 5c 06 00 	cmpq   $0x0,0x65c00(%rip)        # 6b468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 5b 06 00 	sub    %rax,0x65b55(%rip)        # 6b470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 5b 06 00 	add    %r12,0x65b33(%rip)        # 6b470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 52 06 00 	mov    0x6528f(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 3e 06 00 	lea    0x63e8c(%rip),%rax        # 69820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 51 06 00 	add    0x651e3(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 51 06 00 	mov    0x651b0(%rip),%rsi        # 6abd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 51 06 00 	mov    0x651d1(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 51 06 00 	add    0x651c5(%rip),%r8        # 6ac18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 51 06 	addsd  0x6518d(%rip),%xmm0        # 6ac60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 3d 06 00 	lea    0x63d42(%rip),%rax        # 69820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 51 06 00 	sub    %rdi,0x6514c(%rip)        # 6ac40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 51 06 	movsd  %xmm0,0x65164(%rip)        # 6ac60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 51 06 00 	sub    %rdx,0x6511e(%rip)        # 6ac40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 51 06 	addsd  0x65124(%rip),%xmm0        # 6ac60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 51 06 	movsd  %xmm0,0x65118(%rip)        # 6ac60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 50 06 00 	mov    0x650af(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 50 06 00 	add    %rcx,0x650a9(%rip)        # 6ac50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 50 06 00 	cmp    0x65062(%rip),%r9        # 6ac10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 50 06 00 	mov    %r9,0x65059(%rip)        # 6ac10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 50 06 00 	cmp    0x6504a(%rip),%r9        # 6ac08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 50 06 00 	mov    %r9,0x6503d(%rip)        # 6ac08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 4f 06 00 	add    0x64f53(%rip),%rdi        # 6ac18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 3b 06 00 	lea    0x63b30(%rip),%r15        # 69820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 4e 06 00 	add    0x64ea0(%rip),%r12        # 6abd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 4e 06 00 	add    0x64ef9(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 4e 06 00 	cmp    %rax,0x64ef8(%rip)        # 6ac48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 4e 06 00 	mov    %rax,0x64ee9(%rip)        # 6ac40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 4e 06 00 	mov    %rax,0x64ee8(%rip)        # 6ac48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 4e 06 	addsd  0x64ee4(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 4e 06 	movsd  %xmm0,0x64edc(%rip)        # 6ac58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 4e 06 00    	mov    0x64e23(%rip),%eax        # 6abc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 3a 06 00 	lea    0x63a5f(%rip),%rdi        # 69820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 4e 06 00 	add    0x64e18(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 4e 06 00 	cmp    %rax,0x64e13(%rip)        # 6ac48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 4e 06 00 	mov    %rax,0x64e04(%rip)        # 6ac40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 4e 06 00 	mov    %rax,0x64e03(%rip)        # 6ac48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 4d 06 	addsd  0x64dff(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 4d 06 	movsd  %xmm0,0x64df7(%rip)        # 6ac58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 55 06 00    	mov    0x655ca(%rip),%ebx        # 6b4e8 <iteration_active>
    5f1e:	8b 05 a0 4c 06 00    	mov    0x64ca0(%rip),%eax        # 6abc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 38 06 00 	lea    0x638d4(%rip),%rax        # 69820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 4c 06 00 	add    0x64c8e(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 4c 06 00 	cmp    %rax,0x64c89(%rip)        # 6ac48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 4c 06 00 	mov    %rax,0x64c7a(%rip)        # 6ac40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 4c 06 00 	mov    %rax,0x64c79(%rip)        # 6ac48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 4c 06 	addsd  0x64c78(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 4c 06 	movsd  %xmm0,0x64c70(%rip)        # 6ac58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 4c 06 00 	mov    0x64c4d(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 54 06 	subsd  0x654bb(%rip),%xmm0        # 6b4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 54 06 	comisd 0x654ab(%rip),%xmm0        # 6b4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 54 06 	movsd  %xmm0,0x654a1(%rip)        # 6b4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 54 06 00 	addq   $0x1,0x654a4(%rip)        # 6b4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 54 06 00 	add    %rdi,0x65495(%rip)        # 6b4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_apply>:
    6100:	55                   	push   %rbp
    6101:	48 89 f9             	mov    %rdi,%rcx
    6104:	48 89 e5             	mov    %rsp,%rbp
    6107:	41 57                	push   %r15
    6109:	41 56                	push   %r14
    610b:	41 55                	push   %r13
    610d:	41 89 f5             	mov    %esi,%r13d
    6110:	41 54                	push   %r12
    6112:	53                   	push   %rbx
    6113:	48 83 ec 28          	sub    $0x28,%rsp
    6117:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    611e:	00 00 
    6120:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6124:	49 89 d6             	mov    %rdx,%r14
    6127:	44 8b 09             	mov    (%rcx),%r9d
    612a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    612e:	49 89 e0             	mov    %rsp,%r8
    6131:	49 c1 e1 05          	shl    $0x5,%r9
    6135:	4c 03 0d 3c 53 06 00 	add    0x6533c(%rip),%r9        # 6b478 <fwp_fns>
    613c:	41 8b 19             	mov    (%r9),%ebx
    613f:	45 85 e4             	test   %r12d,%r12d
    6142:	75 2c                	jne    6170 <fwp_apply+0x70>
    6144:	41 39 dd             	cmp    %ebx,%r13d
    6147:	72 27                	jb     6170 <fwp_apply+0x70>
    6149:	85 db                	test   %ebx,%ebx
    614b:	0f 84 b7 01 00 00    	je     6308 <fwp_apply+0x208>
    6151:	4c 89 f7             	mov    %r14,%rdi
    6154:	41 ff 51 08          	call   *0x8(%r9)
    6158:	48 89 c1             	mov    %rax,%rcx
    615b:	41 39 dd             	cmp    %ebx,%r13d
    615e:	0f 84 7c 01 00 00    	je     62e0 <fwp_apply+0x1e0>
    6164:	89 d8                	mov    %ebx,%eax
    6166:	41 29 dd             	sub    %ebx,%r13d
    6169:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    616d:	eb b8                	jmp    6127 <fwp_apply+0x27>
    616f:	90                   	nop
    6170:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    6175:	41 39 df             	cmp    %ebx,%r15d
    6178:	0f 82 dc 00 00 00    	jb     625a <fwp_apply+0x15a>
    617e:	41 89 df             	mov    %ebx,%r15d
    6181:	b8 01 00 00 00       	mov    $0x1,%eax
    6186:	48 89 e2             	mov    %rsp,%rdx
    6189:	45 29 e7             	sub    %r12d,%r15d
    618c:	85 db                	test   %ebx,%ebx
    618e:	0f 45 c3             	cmovne %ebx,%eax
    6191:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    6198:	00 
    6199:	48 c1 e8 04          	shr    $0x4,%rax
    619d:	48 c1 e0 04          	shl    $0x4,%rax
    61a1:	48 89 c6             	mov    %rax,%rsi
    61a4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    61ab:	48 29 f2             	sub    %rsi,%rdx
    61ae:	48 39 d4             	cmp    %rdx,%rsp
    61b1:	74 15                	je     61c8 <fwp_apply+0xc8>
    61b3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    61ba:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    61c1:	00 00 
    61c3:	48 39 d4             	cmp    %rdx,%rsp
    61c6:	75 eb                	jne    61b3 <fwp_apply+0xb3>
    61c8:	25 ff 0f 00 00       	and    $0xfff,%eax
    61cd:	48 29 c4             	sub    %rax,%rsp
    61d0:	48 85 c0             	test   %rax,%rax
    61d3:	0f 85 59 01 00 00    	jne    6332 <fwp_apply+0x232>
    61d9:	45 89 e2             	mov    %r12d,%r10d
    61dc:	48 89 e6             	mov    %rsp,%rsi
    61df:	48 89 e7             	mov    %rsp,%rdi
    61e2:	31 c0                	xor    %eax,%eax
    61e4:	49 c1 e2 03          	shl    $0x3,%r10
    61e8:	45 85 e4             	test   %r12d,%r12d
    61eb:	74 25                	je     6212 <fwp_apply+0x112>
    61ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61f4:	00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6205:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6209:	48 83 c0 08          	add    $0x8,%rax
    620d:	4c 39 d0             	cmp    %r10,%rax
    6210:	75 ee                	jne    6200 <fwp_apply+0x100>
    6212:	45 85 ff             	test   %r15d,%r15d
    6215:	0f 84 f4 00 00 00    	je     630f <fwp_apply+0x20f>
    621b:	44 89 fa             	mov    %r15d,%edx
    621e:	4c 89 f0             	mov    %r14,%rax
    6221:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6225:	44 89 e2             	mov    %r12d,%edx
    6228:	66 90                	xchg   %ax,%ax
    622a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6231:	00 00 00 00 
    6235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    623c:	00 00 00 00 
    6240:	4c 8b 10             	mov    (%rax),%r10
    6243:	89 d1                	mov    %edx,%ecx
    6245:	48 83 c0 08          	add    $0x8,%rax
    6249:	83 c2 01             	add    $0x1,%edx
    624c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    6250:	4c 39 d8             	cmp    %r11,%rax
    6253:	75 eb                	jne    6240 <fwp_apply+0x140>
    6255:	e9 b5 00 00 00       	jmp    630f <fwp_apply+0x20f>
    625a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    625e:	be 02 00 00 00       	mov    $0x2,%esi
    6263:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    6267:	48 c1 e7 03          	shl    $0x3,%rdi
    626b:	e8 a0 fc ff ff       	call   5f10 <fwp_heap_alloc>
    6270:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    6274:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    6279:	48 89 c3             	mov    %rax,%rbx
    627c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    6280:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6284:	66 0f d6 00          	movq   %xmm0,(%rax)
    6288:	45 85 e4             	test   %r12d,%r12d
    628b:	74 14                	je     62a1 <fwp_apply+0x1a1>
    628d:	44 89 e2             	mov    %r12d,%edx
    6290:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    6294:	48 8d 78 08          	lea    0x8(%rax),%rdi
    6298:	48 c1 e2 03          	shl    $0x3,%rdx
    629c:	e8 4f d3 ff ff       	call   35f0 <memmove@plt>
    62a1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    62a5:	45 85 ed             	test   %r13d,%r13d
    62a8:	74 2e                	je     62d8 <fwp_apply+0x1d8>
    62aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62b1:	00 00 00 00 
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 
    62c0:	49 8b 16             	mov    (%r14),%rdx
    62c3:	44 89 e0             	mov    %r12d,%eax
    62c6:	49 83 c6 08          	add    $0x8,%r14
    62ca:	41 83 c4 01          	add    $0x1,%r12d
    62ce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    62d3:	49 39 ce             	cmp    %rcx,%r14
    62d6:	75 e8                	jne    62c0 <fwp_apply+0x1c0>
    62d8:	48 89 d9             	mov    %rbx,%rcx
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    62e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62eb:	00 00 
    62ed:	75 4e                	jne    633d <fwp_apply+0x23d>
    62ef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    62f3:	48 89 c8             	mov    %rcx,%rax
    62f6:	5b                   	pop    %rbx
    62f7:	41 5c                	pop    %r12
    62f9:	41 5d                	pop    %r13
    62fb:	41 5e                	pop    %r14
    62fd:	41 5f                	pop    %r15
    62ff:	5d                   	pop    %rbp
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	45 31 ff             	xor    %r15d,%r15d
    630b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    630f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6313:	41 ff 51 08          	call   *0x8(%r9)
    6317:	48 89 c1             	mov    %rax,%rcx
    631a:	45 39 fd             	cmp    %r15d,%r13d
    631d:	74 c1                	je     62e0 <fwp_apply+0x1e0>
    631f:	45 01 e5             	add    %r12d,%r13d
    6322:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6326:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    632a:	41 29 dd             	sub    %ebx,%r13d
    632d:	e9 f5 fd ff ff       	jmp    6127 <fwp_apply+0x27>
    6332:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6338:	e9 9c fe ff ff       	jmp    61d9 <fwp_apply+0xd9>
    633d:	e8 0e d1 ff ff       	call   3450 <__stack_chk_fail@plt>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_tape_reserve>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	41 54                	push   %r12
    6358:	55                   	push   %rbp
    6359:	53                   	push   %rbx
    635a:	48 83 ec 18          	sub    $0x18,%rsp
    635e:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6365:	0f 87 cd 01 00 00    	ja     6538 <fwp_tape_reserve+0x1e8>
    636b:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    636f:	48 89 fd             	mov    %rdi,%rbp
    6372:	48 39 f3             	cmp    %rsi,%rbx
    6375:	0f 8d 18 01 00 00    	jge    6493 <fwp_tape_reserve+0x143>
    637b:	48 85 db             	test   %rbx,%rbx
    637e:	b8 40 00 00 00       	mov    $0x40,%eax
    6383:	48 0f 44 d8          	cmove  %rax,%rbx
    6387:	48 39 f3             	cmp    %rsi,%rbx
    638a:	7d 24                	jge    63b0 <fwp_tape_reserve+0x60>
    638c:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    6393:	0f 8f 0f 01 00 00    	jg     64a8 <fwp_tape_reserve+0x158>
    6399:	48 01 db             	add    %rbx,%rbx
    639c:	48 39 f3             	cmp    %rsi,%rbx
    639f:	7c eb                	jl     638c <fwp_tape_reserve+0x3c>
    63a1:	0f 1f 40 00          	nopl   0x0(%rax)
    63a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63ac:	00 00 00 00 
    63b0:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    63b7:	00 
    63b8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    63bc:	ba 01 00 00 00       	mov    $0x1,%edx
    63c1:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    63c5:	4c 89 ee             	mov    %r13,%rsi
    63c8:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    63cc:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    63d0:	e8 bb ed ff ff       	call   5190 <ad_raw_realloc>
    63d5:	48 85 c0             	test   %rax,%rax
    63d8:	0f 84 66 01 00 00    	je     6544 <fwp_tape_reserve+0x1f4>
    63de:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    63e2:	48 89 45 20          	mov    %rax,0x20(%rbp)
    63e6:	4d 29 fc             	sub    %r15,%r12
    63e9:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    63ed:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    63f1:	4d 85 f6             	test   %r14,%r14
    63f4:	0f 84 f6 00 00 00    	je     64f0 <fwp_tape_reserve+0x1a0>
    63fa:	49 8b 56 60          	mov    0x60(%r14),%rdx
    63fe:	48 39 da             	cmp    %rbx,%rdx
    6401:	7d 78                	jge    647b <fwp_tape_reserve+0x12b>
    6403:	48 89 d9             	mov    %rbx,%rcx
    6406:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    640a:	be 02 00 00 00       	mov    $0x2,%esi
    640f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6414:	48 c1 e1 04          	shl    $0x4,%rcx
    6418:	48 89 cf             	mov    %rcx,%rdi
    641b:	48 89 0c 24          	mov    %rcx,(%rsp)
    641f:	e8 ec fa ff ff       	call   5f10 <fwp_heap_alloc>
    6424:	49 89 c5             	mov    %rax,%r13
    6427:	4d 85 ff             	test   %r15,%r15
    642a:	74 27                	je     6453 <fwp_tape_reserve+0x103>
    642c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6431:	48 8b 0c 24          	mov    (%rsp),%rcx
    6435:	48 89 c7             	mov    %rax,%rdi
    6438:	4c 89 fe             	mov    %r15,%rsi
    643b:	48 c1 e2 04          	shl    $0x4,%rdx
    643f:	48 39 ca             	cmp    %rcx,%rdx
    6442:	48 0f 47 d1          	cmova  %rcx,%rdx
    6446:	e8 35 d1 ff ff       	call   3580 <memcpy@plt>
    644b:	4c 89 ff             	mov    %r15,%rdi
    644e:	e8 bd f5 ff ff       	call   5a10 <fwp_mem_free>
    6453:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    6457:	48 89 da             	mov    %rbx,%rdx
    645a:	31 f6                	xor    %esi,%esi
    645c:	48 29 fa             	sub    %rdi,%rdx
    645f:	48 c1 e7 04          	shl    $0x4,%rdi
    6463:	48 c1 e2 04          	shl    $0x4,%rdx
    6467:	4c 01 ef             	add    %r13,%rdi
    646a:	e8 41 d0 ff ff       	call   34b0 <memset@plt>
    646f:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    6473:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6477:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    647b:	4d 85 e4             	test   %r12,%r12
    647e:	75 4b                	jne    64cb <fwp_tape_reserve+0x17b>
    6480:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6487:	00 
    6488:	4c 01 e8             	add    %r13,%rax
    648b:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    648f:	48 89 45 28          	mov    %rax,0x28(%rbp)
    6493:	48 83 c4 18          	add    $0x18,%rsp
    6497:	5b                   	pop    %rbx
    6498:	5d                   	pop    %rbp
    6499:	41 5c                	pop    %r12
    649b:	41 5d                	pop    %r13
    649d:	41 5e                	pop    %r14
    649f:	41 5f                	pop    %r15
    64a1:	c3                   	ret
    64a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64a8:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    64ad:	e9 fe fe ff ff       	jmp    63b0 <fwp_tape_reserve+0x60>
    64b2:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    64b9:	00 
    64ba:	e8 31 d1 ff ff       	call   35f0 <memmove@plt>
    64bf:	4c 03 6d 30          	add    0x30(%rbp),%r13
    64c3:	48 8b 45 20          	mov    0x20(%rbp),%rax
    64c7:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    64cb:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    64cf:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    64d6:	00 
    64d7:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    64de:	00 
    64df:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    64e3:	e8 08 d1 ff ff       	call   35f0 <memmove@plt>
    64e8:	48 8b 45 20          	mov    0x20(%rbp),%rax
    64ec:	eb 9a                	jmp    6488 <fwp_tape_reserve+0x138>
    64ee:	66 90                	xchg   %ax,%ax
    64f0:	48 89 de             	mov    %rbx,%rsi
    64f3:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    64f7:	ba 02 00 00 00       	mov    $0x2,%edx
    64fc:	48 c1 e6 04          	shl    $0x4,%rsi
    6500:	e8 8b ec ff ff       	call   5190 <ad_raw_realloc>
    6505:	48 85 c0             	test   %rax,%rax
    6508:	74 3a                	je     6544 <fwp_tape_reserve+0x1f4>
    650a:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    650e:	48 89 45 30          	mov    %rax,0x30(%rbp)
    6512:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6516:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    651a:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    651e:	4d 85 e4             	test   %r12,%r12
    6521:	75 8f                	jne    64b2 <fwp_tape_reserve+0x162>
    6523:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    6527:	48 8b 45 20          	mov    0x20(%rbp),%rax
    652b:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6532:	00 
    6533:	e9 50 ff ff ff       	jmp    6488 <fwp_tape_reserve+0x138>
    6538:	48 8d 3d 68 6c 00 00 	lea    0x6c68(%rip),%rdi        # d1a7 <_IO_stdin_used+0x1a7>
    653f:	e8 0c df ff ff       	call   4450 <fwp_trap>
    6544:	48 89 ef             	mov    %rbp,%rdi
    6547:	e8 44 d7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    654c:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    6550:	48 85 ff             	test   %rdi,%rdi
    6553:	74 05                	je     655a <fwp_tape_reserve+0x20a>
    6555:	e8 76 eb ff ff       	call   50d0 <ad_raw_free.part.0>
    655a:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    655e:	48 85 ff             	test   %rdi,%rdi
    6561:	74 05                	je     6568 <fwp_tape_reserve+0x218>
    6563:	e8 68 eb ff ff       	call   50d0 <ad_raw_free.part.0>
    6568:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    656c:	48 85 ff             	test   %rdi,%rdi
    656f:	74 05                	je     6576 <fwp_tape_reserve+0x226>
    6571:	e8 5a eb ff ff       	call   50d0 <ad_raw_free.part.0>
    6576:	31 c9                	xor    %ecx,%ecx
    6578:	31 c0                	xor    %eax,%eax
    657a:	31 d2                	xor    %edx,%edx
    657c:	be 01 00 00 00       	mov    $0x1,%esi
    6581:	89 55 04             	mov    %edx,0x4(%rbp)
    6584:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6588:	ba 13 00 00 00       	mov    $0x13,%edx
    658d:	48 8d 3d 74 6a 00 00 	lea    0x6a74(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    6594:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    6598:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    659c:	48 8b 0d 9d aa 00 00 	mov    0xaa9d(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    65a3:	48 89 45 40          	mov    %rax,0x40(%rbp)
    65a7:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    65ab:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    65af:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    65b3:	e8 a8 d0 ff ff       	call   3660 <fwrite@plt>
    65b8:	31 ff                	xor    %edi,%edi
    65ba:	e8 e1 cf ff ff       	call   35a0 <fflush@plt>
    65bf:	bf 66 00 00 00       	mov    $0x66,%edi
    65c4:	e8 b7 d0 ff ff       	call   3680 <_Exit@plt>
    65c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000065d0 <f128.constprop.0>:
    65d0:	41 57                	push   %r15
    65d2:	41 56                	push   %r14
    65d4:	41 55                	push   %r13
    65d6:	41 54                	push   %r12
    65d8:	49 89 f4             	mov    %rsi,%r12
    65db:	55                   	push   %rbp
    65dc:	48 89 fd             	mov    %rdi,%rbp
    65df:	53                   	push   %rbx
    65e0:	48 83 ec 08          	sub    $0x8,%rsp
    65e4:	48 85 ff             	test   %rdi,%rdi
    65e7:	79 09                	jns    65f2 <f128.constprop.0+0x22>
    65e9:	48 85 f6             	test   %rsi,%rsi
    65ec:	0f 88 fe 00 00 00    	js     66f0 <f128.constprop.0+0x120>
    65f2:	48 89 f8             	mov    %rdi,%rax
    65f5:	48 09 f0             	or     %rsi,%rax
    65f8:	0f 89 d2 00 00 00    	jns    66d0 <f128.constprop.0+0x100>
    65fe:	48 89 f8             	mov    %rdi,%rax
    6601:	48 c1 f8 20          	sar    $0x20,%rax
    6605:	48 85 ff             	test   %rdi,%rdi
    6608:	0f 88 02 01 00 00    	js     6710 <f128.constprop.0+0x140>
    660e:	4c 8b 3d cb 77 00 00 	mov    0x77cb(%rip),%r15        # dde0 <msg.4+0xb0>
    6615:	48 89 c7             	mov    %rax,%rdi
    6618:	e8 13 e1 ff ff       	call   4730 <fwp_tape_of>
    661d:	48 89 c3             	mov    %rax,%rbx
    6620:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6625:	0f 85 16 01 00 00    	jne    6741 <f128.constprop.0+0x171>
    662b:	4c 8b 68 10          	mov    0x10(%rax),%r13
    662f:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6636:	0f 8f f9 00 00 00    	jg     6735 <f128.constprop.0+0x165>
    663c:	89 e8                	mov    %ebp,%eax
    663e:	49 39 c5             	cmp    %rax,%r13
    6641:	0f 8e e2 00 00 00    	jle    6729 <f128.constprop.0+0x159>
    6647:	4d 85 e4             	test   %r12,%r12
    664a:	78 0c                	js     6658 <f128.constprop.0+0x88>
    664c:	44 89 e0             	mov    %r12d,%eax
    664f:	49 39 c5             	cmp    %rax,%r13
    6652:	0f 8e d1 00 00 00    	jle    6729 <f128.constprop.0+0x159>
    6658:	4d 89 ee             	mov    %r13,%r14
    665b:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    665f:	48 89 df             	mov    %rbx,%rdi
    6662:	49 8d 76 01          	lea    0x1(%r14),%rsi
    6666:	e8 e5 fc ff ff       	call   6350 <fwp_tape_reserve>
    666b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    666f:	4d 85 e4             	test   %r12,%r12
    6672:	48 8b 0d 67 77 00 00 	mov    0x7767(%rip),%rcx        # dde0 <msg.4+0xb0>
    6679:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6680:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6684:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6688:	4c 0f 48 e2          	cmovs  %rdx,%r12
    668c:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    6690:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6694:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    6698:	48 8b 43 38          	mov    0x38(%rbx),%rax
    669c:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    66a0:	49 8d 45 01          	lea    0x1(%r13),%rax
    66a4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    66a8:	48 83 c4 08          	add    $0x8,%rsp
    66ac:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    66b3:	ff ff ff 
    66b6:	48 21 e8             	and    %rbp,%rax
    66b9:	5b                   	pop    %rbx
    66ba:	5d                   	pop    %rbp
    66bb:	4c 09 e8             	or     %r13,%rax
    66be:	41 5c                	pop    %r12
    66c0:	41 5d                	pop    %r13
    66c2:	41 5e                	pop    %r14
    66c4:	41 5f                	pop    %r15
    66c6:	c3                   	ret
    66c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    66ce:	00 00 
    66d0:	48 89 f0             	mov    %rsi,%rax
    66d3:	48 c1 ff 20          	sar    $0x20,%rdi
    66d7:	48 c1 f8 20          	sar    $0x20,%rax
    66db:	48 39 c7             	cmp    %rax,%rdi
    66de:	0f 84 2a ff ff ff    	je     660e <f128.constprop.0+0x3e>
    66e4:	48 8d 3d 1d 73 00 00 	lea    0x731d(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    66eb:	e8 60 dd ff ff       	call   4450 <fwp_trap>
    66f0:	48 83 c4 08          	add    $0x8,%rsp
    66f4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    66fb:	5b                   	pop    %rbx
    66fc:	5d                   	pop    %rbp
    66fd:	41 5c                	pop    %r12
    66ff:	41 5d                	pop    %r13
    6701:	41 5e                	pop    %r14
    6703:	41 5f                	pop    %r15
    6705:	c3                   	ret
    6706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    670d:	00 00 00 
    6710:	48 89 f0             	mov    %rsi,%rax
    6713:	48 89 f5             	mov    %rsi,%rbp
    6716:	45 31 ff             	xor    %r15d,%r15d
    6719:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6720:	48 c1 f8 20          	sar    $0x20,%rax
    6724:	e9 ec fe ff ff       	jmp    6615 <f128.constprop.0+0x45>
    6729:	48 8d 3d 92 6a 00 00 	lea    0x6a92(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    6730:	e8 1b dd ff ff       	call   4450 <fwp_trap>
    6735:	48 8d 3d 6b 6a 00 00 	lea    0x6a6b(%rip),%rdi        # d1a7 <_IO_stdin_used+0x1a7>
    673c:	e8 0f dd ff ff       	call   4450 <fwp_trap>
    6741:	48 8d 3d 08 73 00 00 	lea    0x7308(%rip),%rdi        # da50 <_IO_stdin_used+0xa50>
    6748:	e8 03 dd ff ff       	call   4450 <fwp_trap>
    674d:	0f 1f 00             	nopl   (%rax)

0000000000006750 <w107>:
    6750:	66 0f 28 d0          	movapd %xmm0,%xmm2
    6754:	41 57                	push   %r15
    6756:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    675a:	41 56                	push   %r14
    675c:	41 55                	push   %r13
    675e:	41 54                	push   %r12
    6760:	49 89 f4             	mov    %rsi,%r12
    6763:	55                   	push   %rbp
    6764:	48 89 fd             	mov    %rdi,%rbp
    6767:	53                   	push   %rbx
    6768:	48 83 ec 38          	sub    $0x38,%rsp
    676c:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    6771:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    6777:	48 85 ff             	test   %rdi,%rdi
    677a:	0f 88 d0 04 00 00    	js     6c50 <w107+0x500>
    6780:	49 89 ff             	mov    %rdi,%r15
    6783:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6789:	49 c1 ff 20          	sar    $0x20,%r15
    678d:	4c 89 ff             	mov    %r15,%rdi
    6790:	e8 9b df ff ff       	call   4730 <fwp_tape_of>
    6795:	48 89 c3             	mov    %rax,%rbx
    6798:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    679d:	0f 85 45 05 00 00    	jne    6ce8 <w107+0x598>
    67a3:	4c 8b 68 10          	mov    0x10(%rax),%r13
    67a7:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    67ae:	0f 8f 28 05 00 00    	jg     6cdc <w107+0x58c>
    67b4:	89 e8                	mov    %ebp,%eax
    67b6:	49 39 c5             	cmp    %rax,%r13
    67b9:	0f 8e 11 05 00 00    	jle    6cd0 <w107+0x580>
    67bf:	4d 89 ee             	mov    %r13,%r14
    67c2:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    67c6:	48 89 df             	mov    %rbx,%rdi
    67c9:	49 8d 76 01          	lea    0x1(%r14),%rsi
    67cd:	e8 7e fb ff ff       	call   6350 <fwp_tape_reserve>
    67d2:	48 8b 43 20          	mov    0x20(%rbx),%rax
    67d6:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    67db:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    67e1:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    67e5:	48 8b 43 30          	mov    0x30(%rbx),%rax
    67e9:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    67ef:	48 8b 43 28          	mov    0x28(%rbx),%rax
    67f3:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    67f7:	48 8b 43 38          	mov    0x38(%rbx),%rax
    67fb:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6801:	49 8d 45 01          	lea    0x1(%r13),%rax
    6805:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    680c:	ff ff ff 
    680f:	49 21 ee             	and    %rbp,%r14
    6812:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6816:	4d 09 ee             	or     %r13,%r14
    6819:	4d 89 f5             	mov    %r14,%r13
    681c:	49 c1 fd 20          	sar    $0x20,%r13
    6820:	4d 85 e4             	test   %r12,%r12
    6823:	78 10                	js     6835 <w107+0xe5>
    6825:	4c 89 e0             	mov    %r12,%rax
    6828:	48 c1 f8 20          	sar    $0x20,%rax
    682c:	4c 39 e8             	cmp    %r13,%rax
    682f:	0f 85 87 04 00 00    	jne    6cbc <w107+0x56c>
    6835:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    683b:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6841:	4d 39 ef             	cmp    %r13,%r15
    6844:	0f 84 d6 03 00 00    	je     6c20 <w107+0x4d0>
    684a:	f2 0f 10 1d 8e 75 00 	movsd  0x758e(%rip),%xmm3        # dde0 <msg.4+0xb0>
    6851:	00 
    6852:	f2 0f 10 25 8e 75 00 	movsd  0x758e(%rip),%xmm4        # dde8 <msg.4+0xb8>
    6859:	00 
    685a:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    6860:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    6866:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    686c:	4c 89 ef             	mov    %r13,%rdi
    686f:	e8 bc de ff ff       	call   4730 <fwp_tape_of>
    6874:	48 89 c3             	mov    %rax,%rbx
    6877:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    687c:	0f 85 66 04 00 00    	jne    6ce8 <w107+0x598>
    6882:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6886:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    688d:	0f 8f 49 04 00 00    	jg     6cdc <w107+0x58c>
    6893:	44 89 f0             	mov    %r14d,%eax
    6896:	49 39 c7             	cmp    %rax,%r15
    6899:	0f 8e 31 04 00 00    	jle    6cd0 <w107+0x580>
    689f:	4d 85 e4             	test   %r12,%r12
    68a2:	78 0c                	js     68b0 <w107+0x160>
    68a4:	44 89 e0             	mov    %r12d,%eax
    68a7:	49 39 c7             	cmp    %rax,%r15
    68aa:	0f 8e 20 04 00 00    	jle    6cd0 <w107+0x580>
    68b0:	4c 89 f9             	mov    %r15,%rcx
    68b3:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    68b7:	48 89 df             	mov    %rbx,%rdi
    68ba:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    68be:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    68c3:	e8 88 fa ff ff       	call   6350 <fwp_tape_reserve>
    68c8:	48 8b 43 20          	mov    0x20(%rbx),%rax
    68cc:	4d 85 e4             	test   %r12,%r12
    68cf:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    68d3:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    68d8:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    68de:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    68e4:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    68e8:	48 8b 43 30          	mov    0x30(%rbx),%rax
    68ec:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    68f1:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    68f8:	49 0f 49 c4          	cmovns %r12,%rax
    68fc:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6900:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6903:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6907:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    690c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    6910:	48 85 ed             	test   %rbp,%rbp
    6913:	0f 88 0e 04 00 00    	js     6d27 <w107+0x5d7>
    6919:	48 89 e8             	mov    %rbp,%rax
    691c:	48 c1 f8 20          	sar    $0x20,%rax
    6920:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6925:	49 39 c5             	cmp    %rax,%r13
    6928:	74 1a                	je     6944 <w107+0x1f4>
    692a:	48 89 c7             	mov    %rax,%rdi
    692d:	e8 fe dd ff ff       	call   4730 <fwp_tape_of>
    6932:	48 89 c3             	mov    %rax,%rbx
    6935:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    693a:	0f 85 a8 03 00 00    	jne    6ce8 <w107+0x598>
    6940:	4c 8b 60 10          	mov    0x10(%rax),%r12
    6944:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    694b:	0f 8f 8b 03 00 00    	jg     6cdc <w107+0x58c>
    6951:	89 e8                	mov    %ebp,%eax
    6953:	4c 39 e0             	cmp    %r12,%rax
    6956:	0f 8d 74 03 00 00    	jge    6cd0 <w107+0x580>
    695c:	4c 89 e0             	mov    %r12,%rax
    695f:	48 2b 43 08          	sub    0x8(%rbx),%rax
    6963:	48 89 df             	mov    %rbx,%rdi
    6966:	48 8d 70 01          	lea    0x1(%rax),%rsi
    696a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    696f:	e8 dc f9 ff ff       	call   6350 <fwp_tape_reserve>
    6974:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6979:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    697d:	48 8b 0d 64 74 00 00 	mov    0x7464(%rip),%rcx        # dde8 <msg.4+0xb8>
    6984:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    698a:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    698d:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6991:	66 0f 28 ee          	movapd %xmm6,%xmm5
    6995:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    699b:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    699f:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    69a3:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    69a7:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    69ae:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    69b2:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    69b7:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    69bc:	48 89 43 10          	mov    %rax,0x10(%rbx)
    69c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    69c7:	ff ff ff 
    69ca:	48 21 c5             	and    %rax,%rbp
    69cd:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    69d3:	4c 09 e5             	or     %r12,%rbp
    69d6:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    69dd:	ff ff ff 
    69e0:	49 21 c6             	and    %rax,%r14
    69e3:	4d 09 fe             	or     %r15,%r14
    69e6:	4d 89 f4             	mov    %r14,%r12
    69e9:	49 c1 fc 20          	sar    $0x20,%r12
    69ed:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    69f2:	74 16                	je     6a0a <w107+0x2ba>
    69f4:	4c 89 e7             	mov    %r12,%rdi
    69f7:	e8 34 dd ff ff       	call   4730 <fwp_tape_of>
    69fc:	48 89 c3             	mov    %rax,%rbx
    69ff:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6a04:	0f 85 de 02 00 00    	jne    6ce8 <w107+0x598>
    6a0a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6a0e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6a15:	0f 8f c1 02 00 00    	jg     6cdc <w107+0x58c>
    6a1b:	44 89 f0             	mov    %r14d,%eax
    6a1e:	49 39 c7             	cmp    %rax,%r15
    6a21:	0f 8e a9 02 00 00    	jle    6cd0 <w107+0x580>
    6a27:	4d 89 fd             	mov    %r15,%r13
    6a2a:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    6a2e:	48 89 df             	mov    %rbx,%rdi
    6a31:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6a35:	e8 16 f9 ff ff       	call   6350 <fwp_tape_reserve>
    6a3a:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6a3e:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    6a44:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    6a48:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6a4c:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    6a52:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6a56:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    6a5a:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6a5e:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    6a64:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    6a68:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6a6f:	ff ff ff 
    6a72:	49 21 c6             	and    %rax,%r14
    6a75:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    6a79:	4d 09 fe             	or     %r15,%r14
    6a7c:	4d 89 f7             	mov    %r14,%r15
    6a7f:	49 c1 ff 20          	sar    $0x20,%r15
    6a83:	4d 39 e7             	cmp    %r12,%r15
    6a86:	74 1d                	je     6aa5 <w107+0x355>
    6a88:	4c 89 ff             	mov    %r15,%rdi
    6a8b:	e8 a0 dc ff ff       	call   4730 <fwp_tape_of>
    6a90:	48 89 c3             	mov    %rax,%rbx
    6a93:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6a98:	0f 85 4a 02 00 00    	jne    6ce8 <w107+0x598>
    6a9e:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6aa2:	4d 89 fc             	mov    %r15,%r12
    6aa5:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6aac:	0f 8f 2a 02 00 00    	jg     6cdc <w107+0x58c>
    6ab2:	44 89 f0             	mov    %r14d,%eax
    6ab5:	4c 39 e8             	cmp    %r13,%rax
    6ab8:	0f 8d 12 02 00 00    	jge    6cd0 <w107+0x580>
    6abe:	f2 0f 10 3d 2a 73 00 	movsd  0x732a(%rip),%xmm7        # ddf0 <msg.4+0xc0>
    6ac5:	00 
    6ac6:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    6acc:	4d 89 ef             	mov    %r13,%r15
    6acf:	48 89 df             	mov    %rbx,%rdi
    6ad2:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6ad8:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    6add:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6ae1:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6ae5:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    6aea:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6af0:	e8 5b f8 ff ff       	call   6350 <fwp_tape_reserve>
    6af5:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6af9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6afe:	48 8b 15 eb 72 00 00 	mov    0x72eb(%rip),%rdx        # ddf0 <msg.4+0xc0>
    6b05:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6b09:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6b0d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6b11:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6b15:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6b19:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6b1d:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    6b24:	ff 
    6b25:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6b29:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    6b30:	00 
    6b31:	49 8d 45 01          	lea    0x1(%r13),%rax
    6b35:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6b39:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6b40:	ff ff ff 
    6b43:	49 21 c6             	and    %rax,%r14
    6b46:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    6b4c:	4d 09 ee             	or     %r13,%r14
    6b4f:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    6b53:	0f 84 57 01 00 00    	je     6cb0 <w107+0x560>
    6b59:	48 89 ef             	mov    %rbp,%rdi
    6b5c:	48 c1 ff 20          	sar    $0x20,%rdi
    6b60:	4c 39 e7             	cmp    %r12,%rdi
    6b63:	74 13                	je     6b78 <w107+0x428>
    6b65:	e8 c6 db ff ff       	call   4730 <fwp_tape_of>
    6b6a:	48 89 c3             	mov    %rax,%rbx
    6b6d:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6b72:	0f 85 70 01 00 00    	jne    6ce8 <w107+0x598>
    6b78:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    6b7c:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    6b83:	0f 8f 53 01 00 00    	jg     6cdc <w107+0x58c>
    6b89:	89 e8                	mov    %ebp,%eax
    6b8b:	4c 39 e0             	cmp    %r12,%rax
    6b8e:	0f 8d 3c 01 00 00    	jge    6cd0 <w107+0x580>
    6b94:	4d 89 e5             	mov    %r12,%r13
    6b97:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    6b9b:	48 89 df             	mov    %rbx,%rdi
    6b9e:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6ba2:	e8 a9 f7 ff ff       	call   6350 <fwp_tape_reserve>
    6ba7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6bab:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6bb0:	48 89 ef             	mov    %rbp,%rdi
    6bb3:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6bb7:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6bbb:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6bc1:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6bc5:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6bc9:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6bcd:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6bd3:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6bd8:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6bdc:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6be3:	ff ff ff 
    6be6:	48 21 c7             	and    %rax,%rdi
    6be9:	4c 09 e7             	or     %r12,%rdi
    6bec:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6bf2:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6bf8:	4c 89 f6             	mov    %r14,%rsi
    6bfb:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6c00:	e8 cb f9 ff ff       	call   65d0 <f128.constprop.0>
    6c05:	48 83 c4 38          	add    $0x38,%rsp
    6c09:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6c0e:	5b                   	pop    %rbx
    6c0f:	5d                   	pop    %rbp
    6c10:	41 5c                	pop    %r12
    6c12:	41 5d                	pop    %r13
    6c14:	41 5e                	pop    %r14
    6c16:	41 5f                	pop    %r15
    6c18:	c3                   	ret
    6c19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c20:	f2 0f 10 3d b8 71 00 	movsd  0x71b8(%rip),%xmm7        # dde0 <msg.4+0xb0>
    6c27:	00 
    6c28:	f2 0f 10 15 b8 71 00 	movsd  0x71b8(%rip),%xmm2        # dde8 <msg.4+0xb8>
    6c2f:	00 
    6c30:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    6c36:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    6c3c:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    6c42:	e9 3b fc ff ff       	jmp    6882 <w107+0x132>
    6c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c4e:	00 00 
    6c50:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6c56:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6c5c:	48 85 f6             	test   %rsi,%rsi
    6c5f:	0f 89 8f 00 00 00    	jns    6cf4 <w107+0x5a4>
    6c65:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6c6b:	f2 0f 10 05 6d 71 00 	movsd  0x716d(%rip),%xmm0        # dde0 <msg.4+0xb0>
    6c72:	00 
    6c73:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    6c7a:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6c81:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    6c86:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6c8a:	f2 0f 59 0d 5e 71 00 	mulsd  0x715e(%rip),%xmm1        # ddf0 <msg.4+0xc0>
    6c91:	00 
    6c92:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6c96:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6c9c:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6ca2:	e9 45 ff ff ff       	jmp    6bec <w107+0x49c>
    6ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cae:	00 00 
    6cb0:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6cb7:	e9 30 ff ff ff       	jmp    6bec <w107+0x49c>
    6cbc:	48 8d 3d 45 6d 00 00 	lea    0x6d45(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    6cc3:	e8 88 d7 ff ff       	call   4450 <fwp_trap>
    6cc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6ccf:	00 
    6cd0:	48 8d 3d eb 64 00 00 	lea    0x64eb(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    6cd7:	e8 74 d7 ff ff       	call   4450 <fwp_trap>
    6cdc:	48 8d 3d c4 64 00 00 	lea    0x64c4(%rip),%rdi        # d1a7 <_IO_stdin_used+0x1a7>
    6ce3:	e8 68 d7 ff ff       	call   4450 <fwp_trap>
    6ce8:	48 8d 3d 61 6d 00 00 	lea    0x6d61(%rip),%rdi        # da50 <_IO_stdin_used+0xa50>
    6cef:	e8 5c d7 ff ff       	call   4450 <fwp_trap>
    6cf4:	f2 0f 10 35 e4 70 00 	movsd  0x70e4(%rip),%xmm6        # dde0 <msg.4+0xb0>
    6cfb:	00 
    6cfc:	49 89 f5             	mov    %rsi,%r13
    6cff:	49 89 f6             	mov    %rsi,%r14
    6d02:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6d09:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6d10:	00 00 
    6d12:	49 c1 fd 20          	sar    $0x20,%r13
    6d16:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    6d1c:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6d22:	e9 45 fb ff ff       	jmp    686c <w107+0x11c>
    6d27:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    6d2d:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    6d32:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6d39:	66 0f 28 f4          	movapd %xmm4,%xmm6
    6d3d:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    6d41:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6d47:	e9 8a fc ff ff       	jmp    69d6 <w107+0x286>
    6d4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006d50 <fwp_data.part.0.constprop.0>:
    6d50:	41 56                	push   %r14
    6d52:	8b 05 6c 3e 06 00    	mov    0x63e6c(%rip),%eax        # 6abc4 <fwp_heap+0x13a4>
    6d58:	41 89 fe             	mov    %edi,%r14d
    6d5b:	41 55                	push   %r13
    6d5d:	44 8b 2d 84 47 06 00 	mov    0x64784(%rip),%r13d        # 6b4e8 <iteration_active>
    6d64:	41 54                	push   %r12
    6d66:	49 89 f4             	mov    %rsi,%r12
    6d69:	55                   	push   %rbp
    6d6a:	53                   	push   %rbx
    6d6b:	45 85 ed             	test   %r13d,%r13d
    6d6e:	0f 84 1c 01 00 00    	je     6e90 <fwp_data.part.0.constprop.0+0x140>
    6d74:	48 83 05 64 47 06 00 	addq   $0x1,0x64764(%rip)        # 6b4e0 <iteration_requests>
    6d7b:	01 
    6d7c:	48 83 05 54 47 06 00 	addq   $0x18,0x64754(%rip)        # 6b4d8 <iteration_bytes>
    6d83:	18 
    6d84:	85 c0                	test   %eax,%eax
    6d86:	0f 84 8c 01 00 00    	je     6f18 <fwp_data.part.0.constprop.0+0x1c8>
    6d8c:	0f b6 05 2f 3a 06 00 	movzbl 0x63a2f(%rip),%eax        # 6a7c2 <fwp_heap+0xfa2>
    6d93:	48 8d 15 86 2a 06 00 	lea    0x62a86(%rip),%rdx        # 69820 <fwp_heap>
    6d9a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6da1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6da5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6da9:	48 8b 18             	mov    (%rax),%rbx
    6dac:	48 85 db             	test   %rbx,%rbx
    6daf:	0f 84 fb 00 00 00    	je     6eb0 <fwp_data.part.0.constprop.0+0x160>
    6db5:	48 8b 13             	mov    (%rbx),%rdx
    6db8:	48 f7 d2             	not    %rdx
    6dbb:	48 89 10             	mov    %rdx,(%rax)
    6dbe:	48 83 fd 18          	cmp    $0x18,%rbp
    6dc2:	76 1b                	jbe    6ddf <fwp_data.part.0.constprop.0+0x8f>
    6dc4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6dc8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    6dcc:	31 f6                	xor    %esi,%esi
    6dce:	48 c1 e8 03          	shr    $0x3,%rax
    6dd2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6dd9:	00 
    6dda:	e8 d1 c6 ff ff       	call   34b0 <memset@plt>
    6ddf:	48 89 e8             	mov    %rbp,%rax
    6de2:	48 03 05 57 3e 06 00 	add    0x63e57(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    6de9:	0f 82 3d 01 00 00    	jb     6f2c <fwp_data.part.0.constprop.0+0x1dc>
    6def:	48 39 05 52 3e 06 00 	cmp    %rax,0x63e52(%rip)        # 6ac48 <fwp_heap+0x1428>
    6df6:	48 89 05 43 3e 06 00 	mov    %rax,0x63e43(%rip)        # 6ac40 <fwp_heap+0x1420>
    6dfd:	73 07                	jae    6e06 <fwp_data.part.0.constprop.0+0xb6>
    6dff:	48 89 05 42 3e 06 00 	mov    %rax,0x63e42(%rip)        # 6ac48 <fwp_heap+0x1428>
    6e06:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e0a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6e0f:	f2 0f 58 05 41 3e 06 	addsd  0x63e41(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    6e16:	00 
    6e17:	f2 0f 11 05 39 3e 06 	movsd  %xmm0,0x63e39(%rip)        # 6ac58 <fwp_heap+0x1438>
    6e1e:	00 
    6e1f:	45 85 ed             	test   %r13d,%r13d
    6e22:	74 33                	je     6e57 <fwp_data.part.0.constprop.0+0x107>
    6e24:	48 8b 05 15 3e 06 00 	mov    0x63e15(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    6e2b:	48 85 c0             	test   %rax,%rax
    6e2e:	0f 88 a4 00 00 00    	js     6ed8 <fwp_data.part.0.constprop.0+0x188>
    6e34:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e38:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6e3d:	f2 0f 5c 05 83 46 06 	subsd  0x64683(%rip),%xmm0        # 6b4c8 <iteration_start_charge>
    6e44:	00 
    6e45:	66 0f 2f 05 73 46 06 	comisd 0x64673(%rip),%xmm0        # 6b4c0 <iteration_peak>
    6e4c:	00 
    6e4d:	76 08                	jbe    6e57 <fwp_data.part.0.constprop.0+0x107>
    6e4f:	f2 0f 11 05 69 46 06 	movsd  %xmm0,0x64669(%rip)        # 6b4c0 <iteration_peak>
    6e56:	00 
    6e57:	b8 02 00 00 00       	mov    $0x2,%eax
    6e5c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6e61:	66 0f 6e c8          	movd   %eax,%xmm1
    6e65:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6e69:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6e6d:	49 8b 04 24          	mov    (%r12),%rax
    6e71:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6e75:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6e7a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6e7e:	48 89 d8             	mov    %rbx,%rax
    6e81:	5b                   	pop    %rbx
    6e82:	5d                   	pop    %rbp
    6e83:	41 5c                	pop    %r12
    6e85:	41 5d                	pop    %r13
    6e87:	41 5e                	pop    %r14
    6e89:	c3                   	ret
    6e8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e90:	85 c0                	test   %eax,%eax
    6e92:	0f 85 f4 fe ff ff    	jne    6d8c <fwp_data.part.0.constprop.0+0x3c>
    6e98:	31 f6                	xor    %esi,%esi
    6e9a:	bf 18 00 00 00       	mov    $0x18,%edi
    6e9f:	e8 6c f0 ff ff       	call   5f10 <fwp_heap_alloc>
    6ea4:	48 89 c3             	mov    %rax,%rbx
    6ea7:	eb ae                	jmp    6e57 <fwp_data.part.0.constprop.0+0x107>
    6ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6eb0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6eb4:	48 85 db             	test   %rbx,%rbx
    6eb7:	74 47                	je     6f00 <fwp_data.part.0.constprop.0+0x1b0>
    6eb9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6ebd:	48 29 da             	sub    %rbx,%rdx
    6ec0:	48 39 ea             	cmp    %rbp,%rdx
    6ec3:	72 3b                	jb     6f00 <fwp_data.part.0.constprop.0+0x1b0>
    6ec5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6ec9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ecd:	e9 ec fe ff ff       	jmp    6dbe <fwp_data.part.0.constprop.0+0x6e>
    6ed2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ed8:	48 89 c2             	mov    %rax,%rdx
    6edb:	83 e0 01             	and    $0x1,%eax
    6ede:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6ee2:	48 d1 ea             	shr    $1,%rdx
    6ee5:	48 09 c2             	or     %rax,%rdx
    6ee8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    6eed:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6ef1:	e9 47 ff ff ff       	jmp    6e3d <fwp_data.part.0.constprop.0+0xed>
    6ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6efd:	00 00 00 
    6f00:	31 f6                	xor    %esi,%esi
    6f02:	bf 18 00 00 00       	mov    $0x18,%edi
    6f07:	e8 04 f0 ff ff       	call   5f10 <fwp_heap_alloc>
    6f0c:	48 89 c3             	mov    %rax,%rbx
    6f0f:	e9 0b ff ff ff       	jmp    6e1f <fwp_data.part.0.constprop.0+0xcf>
    6f14:	0f 1f 40 00          	nopl   0x0(%rax)
    6f18:	31 f6                	xor    %esi,%esi
    6f1a:	bf 18 00 00 00       	mov    $0x18,%edi
    6f1f:	e8 ec ef ff ff       	call   5f10 <fwp_heap_alloc>
    6f24:	48 89 c3             	mov    %rax,%rbx
    6f27:	e9 f8 fe ff ff       	jmp    6e24 <fwp_data.part.0.constprop.0+0xd4>
    6f2c:	e8 ff ce ff ff       	call   3e30 <fwp_heap_oom>
    6f31:	0f 1f 40 00          	nopl   0x0(%rax)
    6f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f3c:	00 00 00 00 

0000000000006f40 <fwp_rc_share>:
    6f40:	48 8b 05 b1 3c 06 00 	mov    0x63cb1(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    6f47:	48 2b 3d 82 3c 06 00 	sub    0x63c82(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    6f4e:	48 c1 e0 10          	shl    $0x10,%rax
    6f52:	48 39 c7             	cmp    %rax,%rdi
    6f55:	73 4a                	jae    6fa1 <fwp_rc_share+0x61>
    6f57:	48 89 f8             	mov    %rdi,%rax
    6f5a:	48 c1 e8 10          	shr    $0x10,%rax
    6f5e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6f62:	48 8b 05 af 3c 06 00 	mov    0x63caf(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    6f69:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6f6d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6f71:	48 85 d2             	test   %rdx,%rdx
    6f74:	74 2b                	je     6fa1 <fwp_rc_share+0x61>
    6f76:	0f b6 08             	movzbl (%rax),%ecx
    6f79:	80 f9 02             	cmp    $0x2,%cl
    6f7c:	74 2a                	je     6fa8 <fwp_rc_share+0x68>
    6f7e:	80 f9 01             	cmp    $0x1,%cl
    6f81:	75 1e                	jne    6fa1 <fwp_rc_share+0x61>
    6f83:	8b 48 18             	mov    0x18(%rax),%ecx
    6f86:	0f b7 ff             	movzwl %di,%edi
    6f89:	8b 40 1c             	mov    0x1c(%rax),%eax
    6f8c:	48 0f af f9          	imul   %rcx,%rdi
    6f90:	48 c1 ef 20          	shr    $0x20,%rdi
    6f94:	48 39 c7             	cmp    %rax,%rdi
    6f97:	73 08                	jae    6fa1 <fwp_rc_share+0x61>
    6f99:	48 01 fa             	add    %rdi,%rdx
    6f9c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6f9f:	75 0d                	jne    6fae <fwp_rc_share+0x6e>
    6fa1:	c3                   	ret
    6fa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fa8:	66 85 ff             	test   %di,%di
    6fab:	74 ef                	je     6f9c <fwp_rc_share+0x5c>
    6fad:	c3                   	ret
    6fae:	50                   	push   %rax
    6faf:	48 8d 3d ca 6a 00 00 	lea    0x6aca(%rip),%rdi        # da80 <_IO_stdin_used+0xa80>
    6fb6:	e8 95 d4 ff ff       	call   4450 <fwp_trap>
    6fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006fc0 <fwp_rc_free_arr>:
    6fc0:	48 8b 15 31 3c 06 00 	mov    0x63c31(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    6fc7:	48 89 f8             	mov    %rdi,%rax
    6fca:	48 2b 05 ff 3b 06 00 	sub    0x63bff(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    6fd1:	48 c1 e2 10          	shl    $0x10,%rdx
    6fd5:	48 39 d0             	cmp    %rdx,%rax
    6fd8:	73 5b                	jae    7035 <fwp_rc_free_arr+0x75>
    6fda:	48 89 c2             	mov    %rax,%rdx
    6fdd:	48 c1 ea 10          	shr    $0x10,%rdx
    6fe1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fe5:	48 8b 15 2c 3c 06 00 	mov    0x63c2c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    6fec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6ff0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6ff4:	48 85 c9             	test   %rcx,%rcx
    6ff7:	74 3c                	je     7035 <fwp_rc_free_arr+0x75>
    6ff9:	0f b6 32             	movzbl (%rdx),%esi
    6ffc:	40 80 fe 02          	cmp    $0x2,%sil
    7000:	74 2e                	je     7030 <fwp_rc_free_arr+0x70>
    7002:	40 80 fe 01          	cmp    $0x1,%sil
    7006:	75 2d                	jne    7035 <fwp_rc_free_arr+0x75>
    7008:	8b 72 18             	mov    0x18(%rdx),%esi
    700b:	0f b7 c0             	movzwl %ax,%eax
    700e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7011:	48 0f af c6          	imul   %rsi,%rax
    7015:	48 c1 e8 20          	shr    $0x20,%rax
    7019:	48 39 d0             	cmp    %rdx,%rax
    701c:	73 17                	jae    7035 <fwp_rc_free_arr+0x75>
    701e:	48 01 c1             	add    %rax,%rcx
    7021:	80 39 01             	cmpb   $0x1,(%rcx)
    7024:	75 0f                	jne    7035 <fwp_rc_free_arr+0x75>
    7026:	e9 e5 e9 ff ff       	jmp    5a10 <fwp_mem_free>
    702b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7030:	66 85 c0             	test   %ax,%ax
    7033:	74 ec                	je     7021 <fwp_rc_free_arr+0x61>
    7035:	c3                   	ret
    7036:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    703d:	00 00 00 

0000000000007040 <fwp_rc_dup>:
    7040:	f3 0f 1e fa          	endbr64
    7044:	48 8b 05 ad 3b 06 00 	mov    0x63bad(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    704b:	48 2b 3d 7e 3b 06 00 	sub    0x63b7e(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    7052:	48 c1 e0 10          	shl    $0x10,%rax
    7056:	48 39 c7             	cmp    %rax,%rdi
    7059:	73 60                	jae    70bb <fwp_rc_dup+0x7b>
    705b:	48 89 f8             	mov    %rdi,%rax
    705e:	48 c1 e8 10          	shr    $0x10,%rax
    7062:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7066:	48 8b 05 ab 3b 06 00 	mov    0x63bab(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    706d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7071:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7075:	48 85 c0             	test   %rax,%rax
    7078:	74 41                	je     70bb <fwp_rc_dup+0x7b>
    707a:	0f b6 0a             	movzbl (%rdx),%ecx
    707d:	80 f9 02             	cmp    $0x2,%cl
    7080:	74 3e                	je     70c0 <fwp_rc_dup+0x80>
    7082:	80 f9 01             	cmp    $0x1,%cl
    7085:	75 34                	jne    70bb <fwp_rc_dup+0x7b>
    7087:	8b 4a 18             	mov    0x18(%rdx),%ecx
    708a:	0f b7 ff             	movzwl %di,%edi
    708d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7090:	48 0f af f9          	imul   %rcx,%rdi
    7094:	48 c1 ef 20          	shr    $0x20,%rdi
    7098:	48 39 d7             	cmp    %rdx,%rdi
    709b:	73 1e                	jae    70bb <fwp_rc_dup+0x7b>
    709d:	48 01 f8             	add    %rdi,%rax
    70a0:	0f b6 10             	movzbl (%rax),%edx
    70a3:	84 d2                	test   %dl,%dl
    70a5:	74 14                	je     70bb <fwp_rc_dup+0x7b>
    70a7:	8b 0d 3b 44 06 00    	mov    0x6443b(%rip),%ecx        # 6b4e8 <iteration_active>
    70ad:	85 c9                	test   %ecx,%ecx
    70af:	75 1f                	jne    70d0 <fwp_rc_dup+0x90>
    70b1:	80 fa fd             	cmp    $0xfd,%dl
    70b4:	77 2a                	ja     70e0 <fwp_rc_dup+0xa0>
    70b6:	83 c2 01             	add    $0x1,%edx
    70b9:	88 10                	mov    %dl,(%rax)
    70bb:	c3                   	ret
    70bc:	0f 1f 40 00          	nopl   0x0(%rax)
    70c0:	66 85 ff             	test   %di,%di
    70c3:	74 db                	je     70a0 <fwp_rc_dup+0x60>
    70c5:	c3                   	ret
    70c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    70cd:	00 00 00 
    70d0:	48 83 05 f8 43 06 00 	addq   $0x1,0x643f8(%rip)        # 6b4d0 <iteration_retains>
    70d7:	01 
    70d8:	eb d7                	jmp    70b1 <fwp_rc_dup+0x71>
    70da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70e0:	48 89 c7             	mov    %rax,%rdi
    70e3:	e9 c8 e5 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    70e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    70ef:	00 

00000000000070f0 <fwp_owned_entry161>:
    70f0:	f3 0f 1e fa          	endbr64
    70f4:	48 83 ec 38          	sub    $0x38,%rsp
    70f8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    70fd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7104:	00 00 
    7106:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    710b:	31 c0                	xor    %eax,%eax
    710d:	48 8b 07             	mov    (%rdi),%rax
    7110:	48 03 47 10          	add    0x10(%rdi),%rax
    7114:	0f 80 c2 00 00 00    	jo     71dc <fwp_owned_entry161+0xec>
    711a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    711f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7124:	31 ff                	xor    %edi,%edi
    7126:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    712a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    712f:	e8 1c fc ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    7134:	48 8b 15 bd 3a 06 00 	mov    0x63abd(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    713b:	48 89 c6             	mov    %rax,%rsi
    713e:	48 2b 05 8b 3a 06 00 	sub    0x63a8b(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7145:	48 c1 e2 10          	shl    $0x10,%rdx
    7149:	48 39 d0             	cmp    %rdx,%rax
    714c:	73 4f                	jae    719d <fwp_owned_entry161+0xad>
    714e:	48 89 c2             	mov    %rax,%rdx
    7151:	48 c1 ea 10          	shr    $0x10,%rdx
    7155:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7159:	48 8b 15 b8 3a 06 00 	mov    0x63ab8(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    7160:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7164:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7168:	48 85 d2             	test   %rdx,%rdx
    716b:	74 30                	je     719d <fwp_owned_entry161+0xad>
    716d:	0f b6 39             	movzbl (%rcx),%edi
    7170:	40 80 ff 02          	cmp    $0x2,%dil
    7174:	74 42                	je     71b8 <fwp_owned_entry161+0xc8>
    7176:	40 80 ff 01          	cmp    $0x1,%dil
    717a:	75 21                	jne    719d <fwp_owned_entry161+0xad>
    717c:	8b 79 18             	mov    0x18(%rcx),%edi
    717f:	0f b7 c0             	movzwl %ax,%eax
    7182:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7185:	48 0f af c7          	imul   %rdi,%rax
    7189:	48 c1 e8 20          	shr    $0x20,%rax
    718d:	48 39 c8             	cmp    %rcx,%rax
    7190:	73 0b                	jae    719d <fwp_owned_entry161+0xad>
    7192:	48 01 c2             	add    %rax,%rdx
    7195:	80 3a ff             	cmpb   $0xff,(%rdx)
    7198:	74 26                	je     71c0 <fwp_owned_entry161+0xd0>
    719a:	c6 02 01             	movb   $0x1,(%rdx)
    719d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    71a2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    71a9:	00 00 
    71ab:	75 34                	jne    71e1 <fwp_owned_entry161+0xf1>
    71ad:	48 89 f0             	mov    %rsi,%rax
    71b0:	48 83 c4 38          	add    $0x38,%rsp
    71b4:	c3                   	ret
    71b5:	0f 1f 00             	nopl   (%rax)
    71b8:	66 85 c0             	test   %ax,%ax
    71bb:	75 e0                	jne    719d <fwp_owned_entry161+0xad>
    71bd:	eb d6                	jmp    7195 <fwp_owned_entry161+0xa5>
    71bf:	90                   	nop
    71c0:	48 89 d7             	mov    %rdx,%rdi
    71c3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    71c8:	48 89 14 24          	mov    %rdx,(%rsp)
    71cc:	e8 ff e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    71d1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    71d6:	48 8b 14 24          	mov    (%rsp),%rdx
    71da:	eb be                	jmp    719a <fwp_owned_entry161+0xaa>
    71dc:	e8 1f c5 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    71e1:	e8 6a c2 ff ff       	call   3450 <__stack_chk_fail@plt>
    71e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71ed:	00 00 00 

00000000000071f0 <e161>:
    71f0:	f3 0f 1e fa          	endbr64
    71f4:	53                   	push   %rbx
    71f5:	48 83 ec 30          	sub    $0x30,%rsp
    71f9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    71fe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7205:	00 00 
    7207:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    720c:	31 c0                	xor    %eax,%eax
    720e:	48 8b 07             	mov    (%rdi),%rax
    7211:	48 03 47 10          	add    0x10(%rdi),%rax
    7215:	0f 80 c9 00 00 00    	jo     72e4 <e161+0xf4>
    721b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7220:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7225:	31 ff                	xor    %edi,%edi
    7227:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    722b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7230:	e8 1b fb ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    7235:	48 8b 15 bc 39 06 00 	mov    0x639bc(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    723c:	48 89 c3             	mov    %rax,%rbx
    723f:	48 2b 05 8a 39 06 00 	sub    0x6398a(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7246:	48 c1 e2 10          	shl    $0x10,%rdx
    724a:	48 39 d0             	cmp    %rdx,%rax
    724d:	73 4f                	jae    729e <e161+0xae>
    724f:	48 89 c2             	mov    %rax,%rdx
    7252:	48 c1 ea 10          	shr    $0x10,%rdx
    7256:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    725a:	48 8b 15 b7 39 06 00 	mov    0x639b7(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    7261:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7265:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7269:	48 85 d2             	test   %rdx,%rdx
    726c:	74 30                	je     729e <e161+0xae>
    726e:	0f b6 31             	movzbl (%rcx),%esi
    7271:	40 80 fe 02          	cmp    $0x2,%sil
    7275:	74 49                	je     72c0 <e161+0xd0>
    7277:	40 80 fe 01          	cmp    $0x1,%sil
    727b:	75 21                	jne    729e <e161+0xae>
    727d:	8b 71 18             	mov    0x18(%rcx),%esi
    7280:	0f b7 c0             	movzwl %ax,%eax
    7283:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7286:	48 0f af c6          	imul   %rsi,%rax
    728a:	48 c1 e8 20          	shr    $0x20,%rax
    728e:	48 39 c8             	cmp    %rcx,%rax
    7291:	73 0b                	jae    729e <e161+0xae>
    7293:	48 01 c2             	add    %rax,%rdx
    7296:	80 3a ff             	cmpb   $0xff,(%rdx)
    7299:	74 35                	je     72d0 <e161+0xe0>
    729b:	c6 02 01             	movb   $0x1,(%rdx)
    729e:	48 89 df             	mov    %rbx,%rdi
    72a1:	e8 9a fc ff ff       	call   6f40 <fwp_rc_share>
    72a6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    72ab:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    72b2:	00 00 
    72b4:	75 33                	jne    72e9 <e161+0xf9>
    72b6:	48 83 c4 30          	add    $0x30,%rsp
    72ba:	48 89 d8             	mov    %rbx,%rax
    72bd:	5b                   	pop    %rbx
    72be:	c3                   	ret
    72bf:	90                   	nop
    72c0:	66 85 c0             	test   %ax,%ax
    72c3:	75 d9                	jne    729e <e161+0xae>
    72c5:	eb cf                	jmp    7296 <e161+0xa6>
    72c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72ce:	00 00 
    72d0:	48 89 d7             	mov    %rdx,%rdi
    72d3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    72d8:	e8 f3 e4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    72dd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    72e2:	eb b7                	jmp    729b <e161+0xab>
    72e4:	e8 17 c4 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    72e9:	e8 62 c1 ff ff       	call   3450 <__stack_chk_fail@plt>
    72ee:	66 90                	xchg   %ax,%ax

00000000000072f0 <fwp_drop0>:
    72f0:	f3 0f 1e fa          	endbr64
    72f4:	48 8b 15 fd 38 06 00 	mov    0x638fd(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    72fb:	48 89 f8             	mov    %rdi,%rax
    72fe:	48 2b 05 cb 38 06 00 	sub    0x638cb(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7305:	48 c1 e2 10          	shl    $0x10,%rdx
    7309:	48 39 d0             	cmp    %rdx,%rax
    730c:	0f 83 be 00 00 00    	jae    73d0 <fwp_drop0+0xe0>
    7312:	48 83 ec 18          	sub    $0x18,%rsp
    7316:	4c 8d 05 03 25 06 00 	lea    0x62503(%rip),%r8        # 69820 <fwp_heap>
    731d:	48 89 c2             	mov    %rax,%rdx
    7320:	48 c1 ea 10          	shr    $0x10,%rdx
    7324:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7328:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    732f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7333:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7337:	48 85 d2             	test   %rdx,%rdx
    733a:	74 3c                	je     7378 <fwp_drop0+0x88>
    733c:	0f b6 31             	movzbl (%rcx),%esi
    733f:	40 80 fe 02          	cmp    $0x2,%sil
    7343:	74 3b                	je     7380 <fwp_drop0+0x90>
    7345:	40 80 fe 01          	cmp    $0x1,%sil
    7349:	75 2d                	jne    7378 <fwp_drop0+0x88>
    734b:	8b 71 18             	mov    0x18(%rcx),%esi
    734e:	0f b7 c0             	movzwl %ax,%eax
    7351:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7354:	48 0f af c6          	imul   %rsi,%rax
    7358:	48 c1 e8 20          	shr    $0x20,%rax
    735c:	48 39 c8             	cmp    %rcx,%rax
    735f:	73 17                	jae    7378 <fwp_drop0+0x88>
    7361:	48 01 c2             	add    %rax,%rdx
    7364:	0f b6 02             	movzbl (%rdx),%eax
    7367:	84 c0                	test   %al,%al
    7369:	74 0d                	je     7378 <fwp_drop0+0x88>
    736b:	3c 01                	cmp    $0x1,%al
    736d:	74 21                	je     7390 <fwp_drop0+0xa0>
    736f:	3c ff                	cmp    $0xff,%al
    7371:	74 65                	je     73d8 <fwp_drop0+0xe8>
    7373:	83 e8 01             	sub    $0x1,%eax
    7376:	88 02                	mov    %al,(%rdx)
    7378:	48 83 c4 18          	add    $0x18,%rsp
    737c:	c3                   	ret
    737d:	0f 1f 00             	nopl   (%rax)
    7380:	66 85 c0             	test   %ax,%ax
    7383:	74 df                	je     7364 <fwp_drop0+0x74>
    7385:	48 83 c4 18          	add    $0x18,%rsp
    7389:	c3                   	ret
    738a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7390:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7394:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7399:	e8 22 fc ff ff       	call   6fc0 <fwp_rc_free_arr>
    739e:	4c 8d 05 7b 24 06 00 	lea    0x6247b(%rip),%r8        # 69820 <fwp_heap>
    73a5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    73aa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    73b1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    73b8:	48 c1 e2 10          	shl    $0x10,%rdx
    73bc:	48 39 d0             	cmp    %rdx,%rax
    73bf:	73 b7                	jae    7378 <fwp_drop0+0x88>
    73c1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    73c6:	e9 52 ff ff ff       	jmp    731d <fwp_drop0+0x2d>
    73cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    73d0:	c3                   	ret
    73d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73d8:	48 89 d0             	mov    %rdx,%rax
    73db:	48 c1 e8 11          	shr    $0x11,%rax
    73df:	48 31 d0             	xor    %rdx,%rax
    73e2:	48 89 c1             	mov    %rax,%rcx
    73e5:	48 c1 e9 09          	shr    $0x9,%rcx
    73e9:	48 31 c8             	xor    %rcx,%rax
    73ec:	0f b6 c8             	movzbl %al,%ecx
    73ef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    73f6:	00 
    73f7:	48 85 c0             	test   %rax,%rax
    73fa:	75 0d                	jne    7409 <fwp_drop0+0x119>
    73fc:	eb 46                	jmp    7444 <fwp_drop0+0x154>
    73fe:	66 90                	xchg   %ax,%ax
    7400:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7404:	48 85 c0             	test   %rax,%rax
    7407:	74 3b                	je     7444 <fwp_drop0+0x154>
    7409:	48 89 c1             	mov    %rax,%rcx
    740c:	48 39 10             	cmp    %rdx,(%rax)
    740f:	75 ef                	jne    7400 <fwp_drop0+0x110>
    7411:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7415:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7419:	48 89 48 08          	mov    %rcx,0x8(%rax)
    741d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7424:	0f 85 4e ff ff ff    	jne    7378 <fwp_drop0+0x88>
    742a:	48 89 d7             	mov    %rdx,%rdi
    742d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7432:	e8 99 e3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7437:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    743c:	c6 02 fe             	movb   $0xfe,(%rdx)
    743f:	e9 34 ff ff ff       	jmp    7378 <fwp_drop0+0x88>
    7444:	48 8d 3d 95 65 00 00 	lea    0x6595(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    744b:	e8 00 d0 ff ff       	call   4450 <fwp_trap>

0000000000007450 <fwp_arg_drop12>:
    7450:	f3 0f 1e fa          	endbr64
    7454:	85 f6                	test   %esi,%esi
    7456:	75 04                	jne    745c <fwp_arg_drop12+0xc>
    7458:	85 d2                	test   %edx,%edx
    745a:	75 04                	jne    7460 <fwp_arg_drop12+0x10>
    745c:	c3                   	ret
    745d:	0f 1f 00             	nopl   (%rax)
    7460:	48 8b 3f             	mov    (%rdi),%rdi
    7463:	e9 88 fe ff ff       	jmp    72f0 <fwp_drop0>
    7468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    746f:	00 

0000000000007470 <fwp_drop1>:
    7470:	f3 0f 1e fa          	endbr64
    7474:	48 8b 15 7d 37 06 00 	mov    0x6377d(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    747b:	48 89 f8             	mov    %rdi,%rax
    747e:	48 2b 05 4b 37 06 00 	sub    0x6374b(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7485:	48 c1 e2 10          	shl    $0x10,%rdx
    7489:	48 39 d0             	cmp    %rdx,%rax
    748c:	0f 83 be 00 00 00    	jae    7550 <fwp_drop1+0xe0>
    7492:	48 83 ec 18          	sub    $0x18,%rsp
    7496:	4c 8d 05 83 23 06 00 	lea    0x62383(%rip),%r8        # 69820 <fwp_heap>
    749d:	48 89 c2             	mov    %rax,%rdx
    74a0:	48 c1 ea 10          	shr    $0x10,%rdx
    74a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74a8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    74af:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    74b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    74b7:	48 85 d2             	test   %rdx,%rdx
    74ba:	74 3c                	je     74f8 <fwp_drop1+0x88>
    74bc:	0f b6 31             	movzbl (%rcx),%esi
    74bf:	40 80 fe 02          	cmp    $0x2,%sil
    74c3:	74 3b                	je     7500 <fwp_drop1+0x90>
    74c5:	40 80 fe 01          	cmp    $0x1,%sil
    74c9:	75 2d                	jne    74f8 <fwp_drop1+0x88>
    74cb:	8b 71 18             	mov    0x18(%rcx),%esi
    74ce:	0f b7 c0             	movzwl %ax,%eax
    74d1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    74d4:	48 0f af c6          	imul   %rsi,%rax
    74d8:	48 c1 e8 20          	shr    $0x20,%rax
    74dc:	48 39 c8             	cmp    %rcx,%rax
    74df:	73 17                	jae    74f8 <fwp_drop1+0x88>
    74e1:	48 01 c2             	add    %rax,%rdx
    74e4:	0f b6 02             	movzbl (%rdx),%eax
    74e7:	84 c0                	test   %al,%al
    74e9:	74 0d                	je     74f8 <fwp_drop1+0x88>
    74eb:	3c 01                	cmp    $0x1,%al
    74ed:	74 21                	je     7510 <fwp_drop1+0xa0>
    74ef:	3c ff                	cmp    $0xff,%al
    74f1:	74 65                	je     7558 <fwp_drop1+0xe8>
    74f3:	83 e8 01             	sub    $0x1,%eax
    74f6:	88 02                	mov    %al,(%rdx)
    74f8:	48 83 c4 18          	add    $0x18,%rsp
    74fc:	c3                   	ret
    74fd:	0f 1f 00             	nopl   (%rax)
    7500:	66 85 c0             	test   %ax,%ax
    7503:	74 df                	je     74e4 <fwp_drop1+0x74>
    7505:	48 83 c4 18          	add    $0x18,%rsp
    7509:	c3                   	ret
    750a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7510:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7514:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7519:	e8 a2 fa ff ff       	call   6fc0 <fwp_rc_free_arr>
    751e:	4c 8d 05 fb 22 06 00 	lea    0x622fb(%rip),%r8        # 69820 <fwp_heap>
    7525:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    752a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7531:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7538:	48 c1 e2 10          	shl    $0x10,%rdx
    753c:	48 39 d0             	cmp    %rdx,%rax
    753f:	73 b7                	jae    74f8 <fwp_drop1+0x88>
    7541:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7546:	e9 52 ff ff ff       	jmp    749d <fwp_drop1+0x2d>
    754b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7550:	c3                   	ret
    7551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7558:	48 89 d0             	mov    %rdx,%rax
    755b:	48 c1 e8 11          	shr    $0x11,%rax
    755f:	48 31 d0             	xor    %rdx,%rax
    7562:	48 89 c1             	mov    %rax,%rcx
    7565:	48 c1 e9 09          	shr    $0x9,%rcx
    7569:	48 31 c8             	xor    %rcx,%rax
    756c:	0f b6 c8             	movzbl %al,%ecx
    756f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7576:	00 
    7577:	48 85 c0             	test   %rax,%rax
    757a:	75 0d                	jne    7589 <fwp_drop1+0x119>
    757c:	eb 46                	jmp    75c4 <fwp_drop1+0x154>
    757e:	66 90                	xchg   %ax,%ax
    7580:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7584:	48 85 c0             	test   %rax,%rax
    7587:	74 3b                	je     75c4 <fwp_drop1+0x154>
    7589:	48 89 c1             	mov    %rax,%rcx
    758c:	48 39 10             	cmp    %rdx,(%rax)
    758f:	75 ef                	jne    7580 <fwp_drop1+0x110>
    7591:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7595:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7599:	48 89 48 08          	mov    %rcx,0x8(%rax)
    759d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    75a4:	0f 85 4e ff ff ff    	jne    74f8 <fwp_drop1+0x88>
    75aa:	48 89 d7             	mov    %rdx,%rdi
    75ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    75b2:	e8 19 e2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    75b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    75bf:	e9 34 ff ff ff       	jmp    74f8 <fwp_drop1+0x88>
    75c4:	48 8d 3d 15 64 00 00 	lea    0x6415(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    75cb:	e8 80 ce ff ff       	call   4450 <fwp_trap>

00000000000075d0 <fwp_closure_drop>:
    75d0:	48 8b 15 21 36 06 00 	mov    0x63621(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    75d7:	48 89 f8             	mov    %rdi,%rax
    75da:	48 2b 05 ef 35 06 00 	sub    0x635ef(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    75e1:	48 c1 e2 10          	shl    $0x10,%rdx
    75e5:	48 39 d0             	cmp    %rdx,%rax
    75e8:	73 6b                	jae    7655 <fwp_closure_drop+0x85>
    75ea:	48 89 c2             	mov    %rax,%rdx
    75ed:	48 c1 ea 10          	shr    $0x10,%rdx
    75f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75f5:	48 8b 15 1c 36 06 00 	mov    0x6361c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    75fc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7600:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7604:	48 85 d2             	test   %rdx,%rdx
    7607:	74 4c                	je     7655 <fwp_closure_drop+0x85>
    7609:	0f b6 31             	movzbl (%rcx),%esi
    760c:	40 80 fe 02          	cmp    $0x2,%sil
    7610:	74 3e                	je     7650 <fwp_closure_drop+0x80>
    7612:	40 80 fe 01          	cmp    $0x1,%sil
    7616:	75 3d                	jne    7655 <fwp_closure_drop+0x85>
    7618:	8b 71 18             	mov    0x18(%rcx),%esi
    761b:	0f b7 c0             	movzwl %ax,%eax
    761e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7621:	48 0f af c6          	imul   %rsi,%rax
    7625:	48 c1 e8 20          	shr    $0x20,%rax
    7629:	48 39 c8             	cmp    %rcx,%rax
    762c:	73 27                	jae    7655 <fwp_closure_drop+0x85>
    762e:	48 01 c2             	add    %rax,%rdx
    7631:	0f b6 02             	movzbl (%rdx),%eax
    7634:	84 c0                	test   %al,%al
    7636:	74 1d                	je     7655 <fwp_closure_drop+0x85>
    7638:	3c 01                	cmp    $0x1,%al
    763a:	74 24                	je     7660 <fwp_closure_drop+0x90>
    763c:	3c ff                	cmp    $0xff,%al
    763e:	74 48                	je     7688 <fwp_closure_drop+0xb8>
    7640:	83 e8 01             	sub    $0x1,%eax
    7643:	88 02                	mov    %al,(%rdx)
    7645:	c3                   	ret
    7646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    764d:	00 00 00 
    7650:	66 85 c0             	test   %ax,%ax
    7653:	74 dc                	je     7631 <fwp_closure_drop+0x61>
    7655:	c3                   	ret
    7656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    765d:	00 00 00 
    7660:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7667:	ff ff 
    7669:	48 85 c0             	test   %rax,%rax
    766c:	74 12                	je     7680 <fwp_closure_drop+0xb0>
    766e:	48 89 fe             	mov    %rdi,%rsi
    7671:	48 89 c7             	mov    %rax,%rdi
    7674:	e9 37 ce ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7680:	e9 db cf ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7685:	0f 1f 00             	nopl   (%rax)
    7688:	48 89 d0             	mov    %rdx,%rax
    768b:	48 8d 35 8e 21 06 00 	lea    0x6218e(%rip),%rsi        # 69820 <fwp_heap>
    7692:	48 83 ec 18          	sub    $0x18,%rsp
    7696:	48 c1 e8 11          	shr    $0x11,%rax
    769a:	48 31 d0             	xor    %rdx,%rax
    769d:	48 89 c1             	mov    %rax,%rcx
    76a0:	48 c1 e9 09          	shr    $0x9,%rcx
    76a4:	48 31 c8             	xor    %rcx,%rax
    76a7:	0f b6 c8             	movzbl %al,%ecx
    76aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    76b1:	00 
    76b2:	48 85 c0             	test   %rax,%rax
    76b5:	75 12                	jne    76c9 <fwp_closure_drop+0xf9>
    76b7:	eb 49                	jmp    7702 <fwp_closure_drop+0x132>
    76b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    76c4:	48 85 c0             	test   %rax,%rax
    76c7:	74 39                	je     7702 <fwp_closure_drop+0x132>
    76c9:	48 89 c1             	mov    %rax,%rcx
    76cc:	48 39 10             	cmp    %rdx,(%rax)
    76cf:	75 ef                	jne    76c0 <fwp_closure_drop+0xf0>
    76d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    76d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    76dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    76e4:	74 05                	je     76eb <fwp_closure_drop+0x11b>
    76e6:	48 83 c4 18          	add    $0x18,%rsp
    76ea:	c3                   	ret
    76eb:	48 89 d7             	mov    %rdx,%rdi
    76ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    76f3:	e8 d8 e0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    76f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    76fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    7700:	eb e4                	jmp    76e6 <fwp_closure_drop+0x116>
    7702:	48 8d 3d d7 62 00 00 	lea    0x62d7(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    7709:	e8 42 cd ff ff       	call   4450 <fwp_trap>
    770e:	66 90                	xchg   %ax,%ax

0000000000007710 <fwp_owned_tape_release>:
    7710:	48 85 ff             	test   %rdi,%rdi
    7713:	0f 84 f7 00 00 00    	je     7810 <fwp_owned_tape_release+0x100>
    7719:	41 54                	push   %r12
    771b:	55                   	push   %rbp
    771c:	53                   	push   %rbx
    771d:	48 8b 07             	mov    (%rdi),%rax
    7720:	48 85 c0             	test   %rax,%rax
    7723:	74 08                	je     772d <fwp_owned_tape_release+0x1d>
    7725:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7729:	48 89 50 08          	mov    %rdx,0x8(%rax)
    772d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7731:	48 85 d2             	test   %rdx,%rdx
    7734:	74 03                	je     7739 <fwp_owned_tape_release+0x29>
    7736:	48 89 02             	mov    %rax,(%rdx)
    7739:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    773d:	48 89 fb             	mov    %rdi,%rbx
    7740:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7744:	48 85 c0             	test   %rax,%rax
    7747:	0f 84 89 00 00 00    	je     77d6 <fwp_owned_tape_release+0xc6>
    774d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7751:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7755:	7e 47                	jle    779e <fwp_owned_tape_release+0x8e>
    7757:	31 ed                	xor    %ebp,%ebp
    7759:	eb 0d                	jmp    7768 <fwp_owned_tape_release+0x58>
    775b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7760:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7764:	48 8b 40 68          	mov    0x68(%rax),%rax
    7768:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    776c:	49 89 ec             	mov    %rbp,%r12
    776f:	48 83 c5 01          	add    $0x1,%rbp
    7773:	49 c1 e4 04          	shl    $0x4,%r12
    7777:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    777b:	ff d0                	call   *%rax
    777d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7781:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7786:	48 8b 43 10          	mov    0x10(%rbx),%rax
    778a:	ff 50 68             	call   *0x68(%rax)
    778d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7791:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7795:	48 39 e8             	cmp    %rbp,%rax
    7798:	7f c6                	jg     7760 <fwp_owned_tape_release+0x50>
    779a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    779e:	31 ed                	xor    %ebp,%ebp
    77a0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    77a5:	7e 28                	jle    77cf <fwp_owned_tape_release+0xbf>
    77a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77ae:	00 00 
    77b0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    77b4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    77b8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    77bc:	74 07                	je     77c5 <fwp_owned_tape_release+0xb5>
    77be:	ff 52 68             	call   *0x68(%rdx)
    77c1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    77c5:	48 83 c5 01          	add    $0x1,%rbp
    77c9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    77cd:	7f e1                	jg     77b0 <fwp_owned_tape_release+0xa0>
    77cf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    77d3:	ff 52 68             	call   *0x68(%rdx)
    77d6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    77da:	e8 f1 fd ff ff       	call   75d0 <fwp_closure_drop>
    77df:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    77e3:	e8 e8 fd ff ff       	call   75d0 <fwp_closure_drop>
    77e8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    77ec:	e8 df fd ff ff       	call   75d0 <fwp_closure_drop>
    77f1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    77f5:	e8 16 e2 ff ff       	call   5a10 <fwp_mem_free>
    77fa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    77fe:	e8 0d e2 ff ff       	call   5a10 <fwp_mem_free>
    7803:	48 89 df             	mov    %rbx,%rdi
    7806:	5b                   	pop    %rbx
    7807:	5d                   	pop    %rbp
    7808:	41 5c                	pop    %r12
    780a:	e9 01 e2 ff ff       	jmp    5a10 <fwp_mem_free>
    780f:	90                   	nop
    7810:	c3                   	ret
    7811:	0f 1f 40 00          	nopl   0x0(%rax)
    7815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    781c:	00 00 00 00 

0000000000007820 <fwp_tape_finish>:
    7820:	f3 0f 1e fa          	endbr64
    7824:	41 55                	push   %r13
    7826:	41 54                	push   %r12
    7828:	55                   	push   %rbp
    7829:	53                   	push   %rbx
    782a:	48 83 ec 48          	sub    $0x48,%rsp
    782e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7835:	00 00 
    7837:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    783c:	48 8d 3d 5d 98 01 00 	lea    0x1985d(%rip),%rdi        # 210a0 <fwp_tape_workspace>
    7843:	e8 f8 d8 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7848:	48 83 3d 98 98 01 00 	cmpq   $0x0,0x19898(%rip)        # 210e8 <fwp_ntapes>
    784f:	00 
    7850:	48 c7 05 2d 98 01 00 	movq   $0x0,0x1982d(%rip)        # 21088 <fwp_tape_cached_bytes>
    7857:	00 00 00 00 
    785b:	7e 79                	jle    78d6 <fwp_tape_finish+0xb6>
    785d:	45 31 e4             	xor    %r12d,%r12d
    7860:	31 ed                	xor    %ebp,%ebp
    7862:	0f 1f 00             	nopl   (%rax)
    7865:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    786c:	00 00 00 00 
    7870:	48 8b 1d 79 98 01 00 	mov    0x19879(%rip),%rbx        # 210f0 <fwp_tapes>
    7877:	48 83 c5 01          	add    $0x1,%rbp
    787b:	4c 01 e3             	add    %r12,%rbx
    787e:	49 83 c4 68          	add    $0x68,%r12
    7882:	48 89 df             	mov    %rbx,%rdi
    7885:	e8 06 c4 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    788a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    788f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7894:	48 89 e7             	mov    %rsp,%rdi
    7897:	48 8b 43 40          	mov    0x40(%rbx),%rax
    789b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    789f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    78a4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    78a9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    78ae:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    78b2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    78b7:	e8 84 d8 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    78bc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    78c0:	e8 4b fe ff ff       	call   7710 <fwp_owned_tape_release>
    78c5:	48 39 2d 1c 98 01 00 	cmp    %rbp,0x1981c(%rip)        # 210e8 <fwp_ntapes>
    78cc:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    78d3:	00 
    78d4:	7f 9a                	jg     7870 <fwp_tape_finish+0x50>
    78d6:	48 8b 3d 13 98 01 00 	mov    0x19813(%rip),%rdi        # 210f0 <fwp_tapes>
    78dd:	48 85 ff             	test   %rdi,%rdi
    78e0:	74 05                	je     78e7 <fwp_tape_finish+0xc7>
    78e2:	e8 e9 d7 ff ff       	call   50d0 <ad_raw_free.part.0>
    78e7:	48 c7 05 fe 97 01 00 	movq   $0x0,0x197fe(%rip)        # 210f0 <fwp_tapes>
    78ee:	00 00 00 00 
    78f2:	48 c7 05 e3 97 01 00 	movq   $0x0,0x197e3(%rip)        # 210e0 <fwp_tapes_cap>
    78f9:	00 00 00 00 
    78fd:	48 c7 05 e0 97 01 00 	movq   $0x0,0x197e0(%rip)        # 210e8 <fwp_ntapes>
    7904:	00 00 00 00 
    7908:	48 c7 05 c5 97 01 00 	movq   $0x0,0x197c5(%rip)        # 210d8 <fwp_tape_next_slot>
    790f:	00 00 00 00 
    7913:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7918:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    791f:	00 00 
    7921:	75 0b                	jne    792e <fwp_tape_finish+0x10e>
    7923:	48 83 c4 48          	add    $0x48,%rsp
    7927:	5b                   	pop    %rbx
    7928:	5d                   	pop    %rbp
    7929:	41 5c                	pop    %r12
    792b:	41 5d                	pop    %r13
    792d:	c3                   	ret
    792e:	e8 1d bb ff ff       	call   3450 <__stack_chk_fail@plt>
    7933:	66 90                	xchg   %ax,%ax
    7935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    793c:	00 00 00 00 

0000000000007940 <fwp_tape_scope_release>:
    7940:	f3 0f 1e fa          	endbr64
    7944:	41 55                	push   %r13
    7946:	41 54                	push   %r12
    7948:	55                   	push   %rbp
    7949:	53                   	push   %rbx
    794a:	48 83 ec 48          	sub    $0x48,%rsp
    794e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7955:	00 00 
    7957:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    795c:	48 63 07             	movslq (%rdi),%rax
    795f:	85 c0                	test   %eax,%eax
    7961:	0f 88 e8 00 00 00    	js     7a4f <fwp_tape_scope_release+0x10f>
    7967:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    796e:	ec c4 4e 
    7971:	48 89 fb             	mov    %rdi,%rbx
    7974:	48 89 e5             	mov    %rsp,%rbp
    7977:	eb 1f                	jmp    7998 <fwp_tape_scope_release+0x58>
    7979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7980:	e8 bb d7 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7985:	4c 89 ef             	mov    %r13,%rdi
    7988:	e8 83 fd ff ff       	call   7710 <fwp_owned_tape_release>
    798d:	48 63 03             	movslq (%rbx),%rax
    7990:	85 c0                	test   %eax,%eax
    7992:	0f 88 b7 00 00 00    	js     7a4f <fwp_tape_scope_release+0x10f>
    7998:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    799c:	48 8b 35 4d 97 01 00 	mov    0x1974d(%rip),%rsi        # 210f0 <fwp_tapes>
    79a3:	4c 01 c6             	add    %r8,%rsi
    79a6:	48 89 f7             	mov    %rsi,%rdi
    79a9:	e8 e2 c2 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    79ae:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    79b3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    79b8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    79bf:	48 8b 46 40          	mov    0x40(%rsi),%rax
    79c3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    79c7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    79ce:	00 
    79cf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    79d4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    79d9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    79dd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    79e2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    79e6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    79eb:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    79f2:	00 
    79f3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    79fa:	00 
    79fb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7a02:	00 
    7a03:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7a07:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    7a0b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    7a0f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7a13:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7a19:	77 18                	ja     7a33 <fwp_tape_scope_release+0xf3>
    7a1b:	49 c1 f8 03          	sar    $0x3,%r8
    7a1f:	4d 0f af c4          	imul   %r12,%r8
    7a23:	4c 3b 05 ae 96 01 00 	cmp    0x196ae(%rip),%r8        # 210d8 <fwp_tape_next_slot>
    7a2a:	7d 07                	jge    7a33 <fwp_tape_scope_release+0xf3>
    7a2c:	4c 89 05 a5 96 01 00 	mov    %r8,0x196a5(%rip)        # 210d8 <fwp_tape_next_slot>
    7a33:	48 89 ef             	mov    %rbp,%rdi
    7a36:	4d 85 ed             	test   %r13,%r13
    7a39:	0f 85 41 ff ff ff    	jne    7980 <fwp_tape_scope_release+0x40>
    7a3f:	e8 1c d8 ff ff       	call   5260 <fwp_tape_buffers_release>
    7a44:	48 63 03             	movslq (%rbx),%rax
    7a47:	85 c0                	test   %eax,%eax
    7a49:	0f 89 49 ff ff ff    	jns    7998 <fwp_tape_scope_release+0x58>
    7a4f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7a54:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7a5b:	00 00 
    7a5d:	75 0b                	jne    7a6a <fwp_tape_scope_release+0x12a>
    7a5f:	48 83 c4 48          	add    $0x48,%rsp
    7a63:	5b                   	pop    %rbx
    7a64:	5d                   	pop    %rbp
    7a65:	41 5c                	pop    %r12
    7a67:	41 5d                	pop    %r13
    7a69:	c3                   	ret
    7a6a:	e8 e1 b9 ff ff       	call   3450 <__stack_chk_fail@plt>
    7a6f:	90                   	nop

0000000000007a70 <fwp_task_dispose>:
    7a70:	53                   	push   %rbx
    7a71:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7a75:	0f 84 cb bc ff ff    	je     3746 <fwp_task_dispose.cold>
    7a7b:	48 89 fb             	mov    %rdi,%rbx
    7a7e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7a83:	0f 85 bd bc ff ff    	jne    3746 <fwp_task_dispose.cold>
    7a89:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    7a8d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7a94:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    7a9b:	00 
    7a9c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7aa0:	48 85 ff             	test   %rdi,%rdi
    7aa3:	74 07                	je     7aac <fwp_task_dispose+0x3c>
    7aa5:	48 85 c0             	test   %rax,%rax
    7aa8:	74 02                	je     7aac <fwp_task_dispose+0x3c>
    7aaa:	ff d0                	call   *%rax
    7aac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7ab3:	e8 58 df ff ff       	call   5a10 <fwp_mem_free>
    7ab8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    7abf:	00 00 00 00 
    7ac3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7ac7:	74 6f                	je     7b38 <fwp_task_dispose+0xc8>
    7ac9:	48 8b 15 28 31 06 00 	mov    0x63128(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7ad0:	48 89 d8             	mov    %rbx,%rax
    7ad3:	48 2b 05 f6 30 06 00 	sub    0x630f6(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7ada:	48 c1 e2 10          	shl    $0x10,%rdx
    7ade:	48 39 d0             	cmp    %rdx,%rax
    7ae1:	73 4c                	jae    7b2f <fwp_task_dispose+0xbf>
    7ae3:	48 89 c2             	mov    %rax,%rdx
    7ae6:	48 c1 ea 10          	shr    $0x10,%rdx
    7aea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7aee:	48 8b 15 23 31 06 00 	mov    0x63123(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    7af5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7af9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7afd:	48 85 c9             	test   %rcx,%rcx
    7b00:	74 2d                	je     7b2f <fwp_task_dispose+0xbf>
    7b02:	0f b6 32             	movzbl (%rdx),%esi
    7b05:	40 80 fe 02          	cmp    $0x2,%sil
    7b09:	74 3d                	je     7b48 <fwp_task_dispose+0xd8>
    7b0b:	40 80 fe 01          	cmp    $0x1,%sil
    7b0f:	75 1e                	jne    7b2f <fwp_task_dispose+0xbf>
    7b11:	8b 72 18             	mov    0x18(%rdx),%esi
    7b14:	0f b7 c0             	movzwl %ax,%eax
    7b17:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b1a:	48 0f af c6          	imul   %rsi,%rax
    7b1e:	48 c1 e8 20          	shr    $0x20,%rax
    7b22:	48 39 d0             	cmp    %rdx,%rax
    7b25:	73 08                	jae    7b2f <fwp_task_dispose+0xbf>
    7b27:	48 01 c1             	add    %rax,%rcx
    7b2a:	80 39 01             	cmpb   $0x1,(%rcx)
    7b2d:	74 09                	je     7b38 <fwp_task_dispose+0xc8>
    7b2f:	5b                   	pop    %rbx
    7b30:	c3                   	ret
    7b31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b38:	48 89 df             	mov    %rbx,%rdi
    7b3b:	5b                   	pop    %rbx
    7b3c:	e9 cf de ff ff       	jmp    5a10 <fwp_mem_free>
    7b41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b48:	66 85 c0             	test   %ax,%ax
    7b4b:	74 dd                	je     7b2a <fwp_task_dispose+0xba>
    7b4d:	5b                   	pop    %rbx
    7b4e:	c3                   	ret
    7b4f:	90                   	nop

0000000000007b50 <fwp_free_zombie>:
    7b50:	48 8b 15 99 1c 06 00 	mov    0x61c99(%rip),%rdx        # 697f0 <fwp_zombie>
    7b57:	48 85 d2             	test   %rdx,%rdx
    7b5a:	0f 84 98 00 00 00    	je     7bf8 <fwp_free_zombie+0xa8>
    7b60:	48 3b 15 99 1c 06 00 	cmp    0x61c99(%rip),%rdx        # 69800 <fwp_cur>
    7b67:	0f 84 8b 00 00 00    	je     7bf8 <fwp_free_zombie+0xa8>
    7b6d:	48 83 ec 18          	sub    $0x18,%rsp
    7b71:	48 63 05 5c 16 06 00 	movslq 0x6165c(%rip),%rax        # 691d4 <fwp_stack_pool_n>
    7b78:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    7b7c:	83 f8 3f             	cmp    $0x3f,%eax
    7b7f:	7f 7f                	jg     7c00 <fwp_free_zombie+0xb0>
    7b81:	8d 48 01             	lea    0x1(%rax),%ecx
    7b84:	89 0d 4a 16 06 00    	mov    %ecx,0x6164a(%rip)        # 691d4 <fwp_stack_pool_n>
    7b8a:	48 8d 0d 4f 16 06 00 	lea    0x6164f(%rip),%rcx        # 691e0 <fwp_stack_pool>
    7b91:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7b95:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    7b9c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7ba0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7ba7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    7bab:	48 85 c9             	test   %rcx,%rcx
    7bae:	0f 84 fc 00 00 00    	je     7cb0 <fwp_free_zombie+0x160>
    7bb4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    7bbb:	48 85 c0             	test   %rax,%rax
    7bbe:	74 07                	je     7bc7 <fwp_free_zombie+0x77>
    7bc0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7bc7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    7bca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7bce:	48 c7 05 17 1c 06 00 	movq   $0x0,0x61c17(%rip)        # 697f0 <fwp_zombie>
    7bd5:	00 00 00 00 
    7bd9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7be0:	85 c0                	test   %eax,%eax
    7be2:	74 34                	je     7c18 <fwp_free_zombie+0xc8>
    7be4:	83 f8 01             	cmp    $0x1,%eax
    7be7:	0f 84 b3 00 00 00    	je     7ca0 <fwp_free_zombie+0x150>
    7bed:	48 83 c4 18          	add    $0x18,%rsp
    7bf1:	c3                   	ret
    7bf2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bf8:	c3                   	ret
    7bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c00:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7c04:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c09:	e8 b2 b9 ff ff       	call   35c0 <munmap@plt>
    7c0e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c13:	eb 80                	jmp    7b95 <fwp_free_zombie+0x45>
    7c15:	0f 1f 00             	nopl   (%rax)
    7c18:	48 8b 0d d9 2f 06 00 	mov    0x62fd9(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    7c1f:	48 89 d0             	mov    %rdx,%rax
    7c22:	48 2b 05 a7 2f 06 00 	sub    0x62fa7(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7c29:	48 c1 e1 10          	shl    $0x10,%rcx
    7c2d:	48 39 c8             	cmp    %rcx,%rax
    7c30:	73 bb                	jae    7bed <fwp_free_zombie+0x9d>
    7c32:	48 89 c1             	mov    %rax,%rcx
    7c35:	48 c1 e9 10          	shr    $0x10,%rcx
    7c39:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7c3d:	48 8b 0d d4 2f 06 00 	mov    0x62fd4(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    7c44:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7c48:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7c4c:	48 85 c9             	test   %rcx,%rcx
    7c4f:	74 9c                	je     7bed <fwp_free_zombie+0x9d>
    7c51:	0f b6 3e             	movzbl (%rsi),%edi
    7c54:	40 80 ff 02          	cmp    $0x2,%dil
    7c58:	74 66                	je     7cc0 <fwp_free_zombie+0x170>
    7c5a:	40 80 ff 01          	cmp    $0x1,%dil
    7c5e:	75 8d                	jne    7bed <fwp_free_zombie+0x9d>
    7c60:	8b 7e 18             	mov    0x18(%rsi),%edi
    7c63:	0f b7 c0             	movzwl %ax,%eax
    7c66:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7c69:	48 0f af c7          	imul   %rdi,%rax
    7c6d:	48 c1 e8 20          	shr    $0x20,%rax
    7c71:	48 39 f0             	cmp    %rsi,%rax
    7c74:	0f 83 73 ff ff ff    	jae    7bed <fwp_free_zombie+0x9d>
    7c7a:	48 01 c1             	add    %rax,%rcx
    7c7d:	0f b6 01             	movzbl (%rcx),%eax
    7c80:	84 c0                	test   %al,%al
    7c82:	0f 84 65 ff ff ff    	je     7bed <fwp_free_zombie+0x9d>
    7c88:	3c 01                	cmp    $0x1,%al
    7c8a:	74 14                	je     7ca0 <fwp_free_zombie+0x150>
    7c8c:	3c ff                	cmp    $0xff,%al
    7c8e:	74 3b                	je     7ccb <fwp_free_zombie+0x17b>
    7c90:	83 e8 01             	sub    $0x1,%eax
    7c93:	88 01                	mov    %al,(%rcx)
    7c95:	e9 53 ff ff ff       	jmp    7bed <fwp_free_zombie+0x9d>
    7c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ca0:	48 89 d7             	mov    %rdx,%rdi
    7ca3:	48 83 c4 18          	add    $0x18,%rsp
    7ca7:	e9 c4 fd ff ff       	jmp    7a70 <fwp_task_dispose>
    7cac:	0f 1f 40 00          	nopl   0x0(%rax)
    7cb0:	48 89 05 11 1b 06 00 	mov    %rax,0x61b11(%rip)        # 697c8 <fwp_tasks_active>
    7cb7:	e9 ff fe ff ff       	jmp    7bbb <fwp_free_zombie+0x6b>
    7cbc:	0f 1f 40 00          	nopl   0x0(%rax)
    7cc0:	66 85 c0             	test   %ax,%ax
    7cc3:	0f 85 24 ff ff ff    	jne    7bed <fwp_free_zombie+0x9d>
    7cc9:	eb b2                	jmp    7c7d <fwp_free_zombie+0x12d>
    7ccb:	48 89 ca             	mov    %rcx,%rdx
    7cce:	48 8d 35 4b 1b 06 00 	lea    0x61b4b(%rip),%rsi        # 69820 <fwp_heap>
    7cd5:	48 c1 ea 11          	shr    $0x11,%rdx
    7cd9:	48 31 ca             	xor    %rcx,%rdx
    7cdc:	48 89 d0             	mov    %rdx,%rax
    7cdf:	48 c1 e8 09          	shr    $0x9,%rax
    7ce3:	48 31 c2             	xor    %rax,%rdx
    7ce6:	0f b6 d2             	movzbl %dl,%edx
    7ce9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7cf0:	00 
    7cf1:	48 85 c0             	test   %rax,%rax
    7cf4:	75 13                	jne    7d09 <fwp_free_zombie+0x1b9>
    7cf6:	eb 4c                	jmp    7d44 <fwp_free_zombie+0x1f4>
    7cf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7cff:	00 
    7d00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7d04:	48 85 c0             	test   %rax,%rax
    7d07:	74 3b                	je     7d44 <fwp_free_zombie+0x1f4>
    7d09:	48 89 c2             	mov    %rax,%rdx
    7d0c:	48 39 08             	cmp    %rcx,(%rax)
    7d0f:	75 ef                	jne    7d00 <fwp_free_zombie+0x1b0>
    7d11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7d15:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7d19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7d1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7d24:	0f 85 c3 fe ff ff    	jne    7bed <fwp_free_zombie+0x9d>
    7d2a:	48 89 cf             	mov    %rcx,%rdi
    7d2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7d32:	e8 99 da ff ff       	call   57d0 <fwp_rc_forget_slot>
    7d37:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7d3c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7d3f:	e9 a9 fe ff ff       	jmp    7bed <fwp_free_zombie+0x9d>
    7d44:	48 8d 3d 95 5c 00 00 	lea    0x5c95(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    7d4b:	e8 00 c7 ff ff       	call   4450 <fwp_trap>

0000000000007d50 <fwp_block>:
    7d50:	48 83 ec 08          	sub    $0x8,%rsp
    7d54:	48 8b 05 8d 1a 06 00 	mov    0x61a8d(%rip),%rax        # 697e8 <fwp_ready_head>
    7d5b:	48 85 c0             	test   %rax,%rax
    7d5e:	0f 84 1c 01 00 00    	je     7e80 <fwp_block+0x130>
    7d64:	90                   	nop
    7d65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7d6c:	00 00 00 00 
    7d70:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7d77:	48 89 15 6a 1a 06 00 	mov    %rdx,0x61a6a(%rip)        # 697e8 <fwp_ready_head>
    7d7e:	48 85 d2             	test   %rdx,%rdx
    7d81:	0f 84 19 01 00 00    	je     7ea0 <fwp_block+0x150>
    7d87:	48 8b 15 72 1a 06 00 	mov    0x61a72(%rip),%rdx        # 69800 <fwp_cur>
    7d8e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7d92:	48 39 c2             	cmp    %rax,%rdx
    7d95:	0f 84 d5 00 00 00    	je     7e70 <fwp_block+0x120>
    7d9b:	48 8b 0d e6 36 06 00 	mov    0x636e6(%rip),%rcx        # 6b488 <fwp_state_owners>
    7da2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7da6:	48 89 05 53 1a 06 00 	mov    %rax,0x61a53(%rip)        # 69800 <fwp_cur>
    7dad:	f3 0f 7e 05 fb 36 06 	movq   0x636fb(%rip),%xmm0        # 6b4b0 <fwp_foreign_callbacks>
    7db4:	00 
    7db5:	0f 16 05 e4 36 06 00 	movhps 0x636e4(%rip),%xmm0        # 6b4a0 <fwp_state>
    7dbc:	f3 0f 7e 0d e4 36 06 	movq   0x636e4(%rip),%xmm1        # 6b4a8 <fwp_handlers>
    7dc3:	00 
    7dc4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7dcb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7dd2:	0f 16 0d df 36 06 00 	movhps 0x636df(%rip),%xmm1        # 6b4b8 <fwp_cleanups>
    7dd9:	f3 0f 7e 05 b7 36 06 	movq   0x636b7(%rip),%xmm0        # 6b498 <fwp_state_len>
    7de0:	00 
    7de1:	0f 16 05 a8 36 06 00 	movhps 0x636a8(%rip),%xmm0        # 6b490 <fwp_state_cap>
    7de8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7def:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7df6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7dfa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7e01:	48 89 0d a0 36 06 00 	mov    %rcx,0x636a0(%rip)        # 6b4a8 <fwp_handlers>
    7e08:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7e0f:	48 89 0d a2 36 06 00 	mov    %rcx,0x636a2(%rip)        # 6b4b8 <fwp_cleanups>
    7e16:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7e1d:	48 89 0d 8c 36 06 00 	mov    %rcx,0x6368c(%rip)        # 6b4b0 <fwp_foreign_callbacks>
    7e24:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7e2b:	48 89 0d 6e 36 06 00 	mov    %rcx,0x6366e(%rip)        # 6b4a0 <fwp_state>
    7e32:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7e39:	48 89 0d 58 36 06 00 	mov    %rcx,0x63658(%rip)        # 6b498 <fwp_state_len>
    7e40:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7e47:	48 89 0d 42 36 06 00 	mov    %rcx,0x63642(%rip)        # 6b490 <fwp_state_cap>
    7e4e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7e55:	48 89 0d 2c 36 06 00 	mov    %rcx,0x6362c(%rip)        # 6b488 <fwp_state_owners>
    7e5c:	e8 1f b6 ff ff       	call   3480 <swapcontext@plt>
    7e61:	f3 0f 1e fa          	endbr64
    7e65:	e8 e6 fc ff ff       	call   7b50 <fwp_free_zombie>
    7e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e70:	8b 05 5a 13 06 00    	mov    0x6135a(%rip),%eax        # 691d0 <fwp_slice>
    7e76:	85 c0                	test   %eax,%eax
    7e78:	74 36                	je     7eb0 <fwp_block+0x160>
    7e7a:	48 83 c4 08          	add    $0x8,%rsp
    7e7e:	c3                   	ret
    7e7f:	90                   	nop
    7e80:	e8 8b d5 ff ff       	call   5410 <fwp_poll_events>
    7e85:	48 8b 05 5c 19 06 00 	mov    0x6195c(%rip),%rax        # 697e8 <fwp_ready_head>
    7e8c:	48 85 c0             	test   %rax,%rax
    7e8f:	0f 85 db fe ff ff    	jne    7d70 <fwp_block+0x20>
    7e95:	eb e9                	jmp    7e80 <fwp_block+0x130>
    7e97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e9e:	00 00 
    7ea0:	48 c7 05 35 19 06 00 	movq   $0x0,0x61935(%rip)        # 697e0 <fwp_ready_tail>
    7ea7:	00 00 00 00 
    7eab:	e9 d7 fe ff ff       	jmp    7d87 <fwp_block+0x37>
    7eb0:	48 8d 3d 28 53 00 00 	lea    0x5328(%rip),%rdi        # d1df <_IO_stdin_used+0x1df>
    7eb7:	e8 d4 b4 ff ff       	call   3390 <getenv@plt>
    7ebc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7ec1:	48 85 c0             	test   %rax,%rax
    7ec4:	74 05                	je     7ecb <fwp_block+0x17b>
    7ec6:	80 38 00             	cmpb   $0x0,(%rax)
    7ec9:	75 0b                	jne    7ed6 <fwp_block+0x186>
    7ecb:	89 15 ff 12 06 00    	mov    %edx,0x612ff(%rip)        # 691d0 <fwp_slice>
    7ed1:	48 83 c4 08          	add    $0x8,%rsp
    7ed5:	c3                   	ret
    7ed6:	ba 0a 00 00 00       	mov    $0xa,%edx
    7edb:	31 f6                	xor    %esi,%esi
    7edd:	48 89 c7             	mov    %rax,%rdi
    7ee0:	e8 5b b6 ff ff       	call   3540 <strtoll@plt>
    7ee5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7ee9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7ef0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7ef5:	0f 46 d0             	cmovbe %eax,%edx
    7ef8:	eb d1                	jmp    7ecb <fwp_block+0x17b>
    7efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007f00 <fwp_drop4>:
    7f00:	48 8b 15 f1 2c 06 00 	mov    0x62cf1(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7f07:	48 89 f8             	mov    %rdi,%rax
    7f0a:	48 2b 05 bf 2c 06 00 	sub    0x62cbf(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7f11:	48 c1 e2 10          	shl    $0x10,%rdx
    7f15:	48 39 d0             	cmp    %rdx,%rax
    7f18:	0f 83 52 01 00 00    	jae    8070 <fwp_drop4+0x170>
    7f1e:	48 83 ec 18          	sub    $0x18,%rsp
    7f22:	4c 8d 05 f7 18 06 00 	lea    0x618f7(%rip),%r8        # 69820 <fwp_heap>
    7f29:	48 89 c2             	mov    %rax,%rdx
    7f2c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7f33:	48 c1 ea 10          	shr    $0x10,%rdx
    7f37:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7f3b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7f3f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7f43:	48 85 d2             	test   %rdx,%rdx
    7f46:	74 46                	je     7f8e <fwp_drop4+0x8e>
    7f48:	44 0f b6 09          	movzbl (%rcx),%r9d
    7f4c:	41 80 f9 02          	cmp    $0x2,%r9b
    7f50:	0f 84 ca 00 00 00    	je     8020 <fwp_drop4+0x120>
    7f56:	41 80 f9 01          	cmp    $0x1,%r9b
    7f5a:	75 32                	jne    7f8e <fwp_drop4+0x8e>
    7f5c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7f60:	0f b7 c0             	movzwl %ax,%eax
    7f63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f66:	49 0f af c1          	imul   %r9,%rax
    7f6a:	48 c1 e8 20          	shr    $0x20,%rax
    7f6e:	48 39 c8             	cmp    %rcx,%rax
    7f71:	73 1b                	jae    7f8e <fwp_drop4+0x8e>
    7f73:	48 01 c2             	add    %rax,%rdx
    7f76:	0f b6 02             	movzbl (%rdx),%eax
    7f79:	84 c0                	test   %al,%al
    7f7b:	74 11                	je     7f8e <fwp_drop4+0x8e>
    7f7d:	3c 01                	cmp    $0x1,%al
    7f7f:	74 17                	je     7f98 <fwp_drop4+0x98>
    7f81:	3c ff                	cmp    $0xff,%al
    7f83:	0f 84 ef 00 00 00    	je     8078 <fwp_drop4+0x178>
    7f89:	83 e8 01             	sub    $0x1,%eax
    7f8c:	88 02                	mov    %al,(%rdx)
    7f8e:	48 83 c4 18          	add    $0x18,%rsp
    7f92:	c3                   	ret
    7f93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7f98:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7f9c:	0f 88 8e 00 00 00    	js     8030 <fwp_drop4+0x130>
    7fa2:	48 8b 15 4f 2c 06 00 	mov    0x62c4f(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7fa9:	48 89 f8             	mov    %rdi,%rax
    7fac:	48 2b 05 1d 2c 06 00 	sub    0x62c1d(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7fb3:	48 c1 e2 10          	shl    $0x10,%rdx
    7fb7:	48 39 d0             	cmp    %rdx,%rax
    7fba:	73 d2                	jae    7f8e <fwp_drop4+0x8e>
    7fbc:	48 89 c2             	mov    %rax,%rdx
    7fbf:	48 c1 ea 10          	shr    $0x10,%rdx
    7fc3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7fc7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7fcb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7fcf:	48 85 c9             	test   %rcx,%rcx
    7fd2:	74 ba                	je     7f8e <fwp_drop4+0x8e>
    7fd4:	0f b6 32             	movzbl (%rdx),%esi
    7fd7:	40 80 fe 02          	cmp    $0x2,%sil
    7fdb:	74 33                	je     8010 <fwp_drop4+0x110>
    7fdd:	40 80 fe 01          	cmp    $0x1,%sil
    7fe1:	75 ab                	jne    7f8e <fwp_drop4+0x8e>
    7fe3:	8b 72 18             	mov    0x18(%rdx),%esi
    7fe6:	0f b7 c0             	movzwl %ax,%eax
    7fe9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fec:	48 0f af c6          	imul   %rsi,%rax
    7ff0:	48 c1 e8 20          	shr    $0x20,%rax
    7ff4:	48 39 d0             	cmp    %rdx,%rax
    7ff7:	73 95                	jae    7f8e <fwp_drop4+0x8e>
    7ff9:	48 01 c1             	add    %rax,%rcx
    7ffc:	80 39 01             	cmpb   $0x1,(%rcx)
    7fff:	75 8d                	jne    7f8e <fwp_drop4+0x8e>
    8001:	48 83 c4 18          	add    $0x18,%rsp
    8005:	e9 06 da ff ff       	jmp    5a10 <fwp_mem_free>
    800a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8010:	66 85 c0             	test   %ax,%ax
    8013:	74 e7                	je     7ffc <fwp_drop4+0xfc>
    8015:	48 83 c4 18          	add    $0x18,%rsp
    8019:	c3                   	ret
    801a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8020:	66 85 c0             	test   %ax,%ax
    8023:	0f 84 4d ff ff ff    	je     7f76 <fwp_drop4+0x76>
    8029:	48 83 c4 18          	add    $0x18,%rsp
    802d:	c3                   	ret
    802e:	66 90                	xchg   %ax,%ax
    8030:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    8034:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8039:	e8 82 ef ff ff       	call   6fc0 <fwp_rc_free_arr>
    803e:	4c 8d 05 db 17 06 00 	lea    0x617db(%rip),%r8        # 69820 <fwp_heap>
    8045:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    804a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    8051:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    8058:	48 c1 e2 10          	shl    $0x10,%rdx
    805c:	48 39 d0             	cmp    %rdx,%rax
    805f:	0f 83 29 ff ff ff    	jae    7f8e <fwp_drop4+0x8e>
    8065:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    806a:	e9 ba fe ff ff       	jmp    7f29 <fwp_drop4+0x29>
    806f:	90                   	nop
    8070:	c3                   	ret
    8071:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8078:	48 89 d0             	mov    %rdx,%rax
    807b:	48 c1 e8 11          	shr    $0x11,%rax
    807f:	48 31 d0             	xor    %rdx,%rax
    8082:	48 89 c1             	mov    %rax,%rcx
    8085:	48 c1 e9 09          	shr    $0x9,%rcx
    8089:	48 31 c8             	xor    %rcx,%rax
    808c:	0f b6 c8             	movzbl %al,%ecx
    808f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    8096:	00 
    8097:	48 85 c0             	test   %rax,%rax
    809a:	75 0d                	jne    80a9 <fwp_drop4+0x1a9>
    809c:	eb 46                	jmp    80e4 <fwp_drop4+0x1e4>
    809e:	66 90                	xchg   %ax,%ax
    80a0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    80a4:	48 85 c0             	test   %rax,%rax
    80a7:	74 3b                	je     80e4 <fwp_drop4+0x1e4>
    80a9:	48 89 c1             	mov    %rax,%rcx
    80ac:	48 39 10             	cmp    %rdx,(%rax)
    80af:	75 ef                	jne    80a0 <fwp_drop4+0x1a0>
    80b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    80b5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    80b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    80bd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    80c4:	0f 85 c4 fe ff ff    	jne    7f8e <fwp_drop4+0x8e>
    80ca:	48 89 d7             	mov    %rdx,%rdi
    80cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    80d2:	e8 f9 d6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    80d7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    80dc:	c6 02 fe             	movb   $0xfe,(%rdx)
    80df:	e9 aa fe ff ff       	jmp    7f8e <fwp_drop4+0x8e>
    80e4:	48 8d 3d f5 58 00 00 	lea    0x58f5(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    80eb:	e8 60 c3 ff ff       	call   4450 <fwp_trap>

00000000000080f0 <fwp_caps161>:
    80f0:	f3 0f 1e fa          	endbr64
    80f4:	85 f6                	test   %esi,%esi
    80f6:	74 08                	je     8100 <fwp_caps161+0x10>
    80f8:	c3                   	ret
    80f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8100:	48 8b 15 f1 2a 06 00 	mov    0x62af1(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    8107:	48 89 f8             	mov    %rdi,%rax
    810a:	48 2b 05 bf 2a 06 00 	sub    0x62abf(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8111:	48 c1 e2 10          	shl    $0x10,%rdx
    8115:	48 39 d0             	cmp    %rdx,%rax
    8118:	73 de                	jae    80f8 <fwp_caps161+0x8>
    811a:	48 89 c2             	mov    %rax,%rdx
    811d:	48 c1 ea 10          	shr    $0x10,%rdx
    8121:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8125:	48 8b 15 ec 2a 06 00 	mov    0x62aec(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    812c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8130:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8134:	48 85 c9             	test   %rcx,%rcx
    8137:	74 bf                	je     80f8 <fwp_caps161+0x8>
    8139:	0f b6 32             	movzbl (%rdx),%esi
    813c:	40 80 fe 02          	cmp    $0x2,%sil
    8140:	74 2e                	je     8170 <fwp_caps161+0x80>
    8142:	40 80 fe 01          	cmp    $0x1,%sil
    8146:	75 b0                	jne    80f8 <fwp_caps161+0x8>
    8148:	8b 72 18             	mov    0x18(%rdx),%esi
    814b:	0f b7 c0             	movzwl %ax,%eax
    814e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8151:	48 0f af c6          	imul   %rsi,%rax
    8155:	48 c1 e8 20          	shr    $0x20,%rax
    8159:	48 39 d0             	cmp    %rdx,%rax
    815c:	73 9a                	jae    80f8 <fwp_caps161+0x8>
    815e:	48 01 c1             	add    %rax,%rcx
    8161:	80 39 01             	cmpb   $0x1,(%rcx)
    8164:	75 92                	jne    80f8 <fwp_caps161+0x8>
    8166:	e9 a5 d8 ff ff       	jmp    5a10 <fwp_mem_free>
    816b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8170:	66 85 c0             	test   %ax,%ax
    8173:	74 ec                	je     8161 <fwp_caps161+0x71>
    8175:	c3                   	ret
    8176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    817d:	00 00 00 

0000000000008180 <f12>:
    8180:	41 57                	push   %r15
    8182:	41 56                	push   %r14
    8184:	41 55                	push   %r13
    8186:	41 54                	push   %r12
    8188:	4c 8d 25 b1 f7 ff ff 	lea    -0x84f(%rip),%r12        # 7940 <fwp_tape_scope_release>
    818f:	55                   	push   %rbp
    8190:	53                   	push   %rbx
    8191:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    8198:	48 8b 05 19 33 06 00 	mov    0x63319(%rip),%rax        # 6b4b8 <fwp_cleanups>
    819f:	48 8b 15 52 2a 06 00 	mov    0x62a52(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    81a6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    81ad:	00 00 
    81af:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    81b6:	00 
    81b7:	48 89 fd             	mov    %rdi,%rbp
    81ba:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    81c1:	ff 
    81c2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    81c7:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    81cc:	48 c1 e2 10          	shl    $0x10,%rdx
    81d0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    81d5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    81da:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    81df:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    81e4:	48 89 05 cd 32 06 00 	mov    %rax,0x632cd(%rip)        # 6b4b8 <fwp_cleanups>
    81eb:	48 8d 05 1e 8e 00 00 	lea    0x8e1e(%rip),%rax        # 11010 <fc23>
    81f2:	48 2b 05 d7 29 06 00 	sub    0x629d7(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    81f9:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    81fe:	48 39 d0             	cmp    %rdx,%rax
    8201:	73 6d                	jae    8270 <f12+0xf0>
    8203:	48 89 c2             	mov    %rax,%rdx
    8206:	48 c1 ea 10          	shr    $0x10,%rdx
    820a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    820e:	48 8b 15 03 2a 06 00 	mov    0x62a03(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8215:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8219:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    821d:	48 85 ff             	test   %rdi,%rdi
    8220:	74 4e                	je     8270 <f12+0xf0>
    8222:	0f b6 0a             	movzbl (%rdx),%ecx
    8225:	80 f9 02             	cmp    $0x2,%cl
    8228:	0f 84 f2 0e 00 00    	je     9120 <f12+0xfa0>
    822e:	80 f9 01             	cmp    $0x1,%cl
    8231:	75 3d                	jne    8270 <f12+0xf0>
    8233:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8236:	0f b7 c0             	movzwl %ax,%eax
    8239:	8b 52 1c             	mov    0x1c(%rdx),%edx
    823c:	48 0f af c1          	imul   %rcx,%rax
    8240:	48 c1 e8 20          	shr    $0x20,%rax
    8244:	48 39 d0             	cmp    %rdx,%rax
    8247:	73 27                	jae    8270 <f12+0xf0>
    8249:	48 01 c7             	add    %rax,%rdi
    824c:	0f b6 07             	movzbl (%rdi),%eax
    824f:	84 c0                	test   %al,%al
    8251:	74 1d                	je     8270 <f12+0xf0>
    8253:	44 8b 05 8e 32 06 00 	mov    0x6328e(%rip),%r8d        # 6b4e8 <iteration_active>
    825a:	45 85 c0             	test   %r8d,%r8d
    825d:	0f 85 bd 0f 00 00    	jne    9220 <f12+0x10a0>
    8263:	3c fd                	cmp    $0xfd,%al
    8265:	0f 87 62 11 00 00    	ja     93cd <f12+0x124d>
    826b:	83 c0 01             	add    $0x1,%eax
    826e:	88 07                	mov    %al,(%rdi)
    8270:	48 8d 3d 99 8d 00 00 	lea    0x8d99(%rip),%rdi        # 11010 <fc23>
    8277:	e8 54 f3 ff ff       	call   75d0 <fwp_closure_drop>
    827c:	48 85 ed             	test   %rbp,%rbp
    827f:	0f 84 ac 10 00 00    	je     9331 <f12+0x11b1>
    8285:	48 89 e8             	mov    %rbp,%rax
    8288:	31 d2                	xor    %edx,%edx
    828a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8290:	48 8b 40 10          	mov    0x10(%rax),%rax
    8294:	48 83 c2 01          	add    $0x1,%rdx
    8298:	48 85 c0             	test   %rax,%rax
    829b:	75 f3                	jne    8290 <f12+0x110>
    829d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    82a4:	0f 87 aa 11 00 00    	ja     9454 <f12+0x12d4>
    82aa:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    82af:	8b 35 ab 8d 00 00    	mov    0x8dab(%rip),%esi        # 11060 <registered_finish.0>
    82b5:	85 f6                	test   %esi,%esi
    82b7:	0f 84 33 0e 00 00    	je     90f0 <f12+0xf70>
    82bd:	48 8b 1d 14 8e 01 00 	mov    0x18e14(%rip),%rbx        # 210d8 <fwp_tape_next_slot>
    82c4:	4c 8b 2d 1d 8e 01 00 	mov    0x18e1d(%rip),%r13        # 210e8 <fwp_ntapes>
    82cb:	4c 39 eb             	cmp    %r13,%rbx
    82ce:	0f 8d d4 00 00 00    	jge    83a8 <f12+0x228>
    82d4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    82d8:	48 03 05 11 8e 01 00 	add    0x18e11(%rip),%rax        # 210f0 <fwp_tapes>
    82df:	90                   	nop
    82e0:	8b 48 04             	mov    0x4(%rax),%ecx
    82e3:	85 c9                	test   %ecx,%ecx
    82e5:	75 0c                	jne    82f3 <f12+0x173>
    82e7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    82ed:	0f 86 b5 00 00 00    	jbe    83a8 <f12+0x228>
    82f3:	48 83 c3 01          	add    $0x1,%rbx
    82f7:	48 83 c0 68          	add    $0x68,%rax
    82fb:	4c 39 eb             	cmp    %r13,%rbx
    82fe:	75 e0                	jne    82e0 <f12+0x160>
    8300:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    8307:	0f 8f c9 11 00 00    	jg     94d6 <f12+0x1356>
    830d:	4c 39 2d cc 8d 01 00 	cmp    %r13,0x18dcc(%rip)        # 210e0 <fwp_tapes_cap>
    8314:	4c 8b 3d d5 8d 01 00 	mov    0x18dd5(%rip),%r15        # 210f0 <fwp_tapes>
    831b:	75 4c                	jne    8369 <f12+0x1e9>
    831d:	4d 85 ed             	test   %r13,%r13
    8320:	0f 84 71 10 00 00    	je     9397 <f12+0x1217>
    8326:	4b 8d 5c 2d 00       	lea    0x0(%r13,%r13,1),%rbx
    832b:	b8 ff ff 00 00       	mov    $0xffff,%eax
    8330:	48 39 c3             	cmp    %rax,%rbx
    8333:	48 0f 4f d8          	cmovg  %rax,%rbx
    8337:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    833b:	31 d2                	xor    %edx,%edx
    833d:	4c 89 ff             	mov    %r15,%rdi
    8340:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8345:	e8 46 ce ff ff       	call   5190 <ad_raw_realloc>
    834a:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    834f:	48 85 c0             	test   %rax,%rax
    8352:	49 89 c7             	mov    %rax,%r15
    8355:	0f 84 1d 11 00 00    	je     9478 <f12+0x12f8>
    835b:	48 89 05 8e 8d 01 00 	mov    %rax,0x18d8e(%rip)        # 210f0 <fwp_tapes>
    8362:	48 89 1d 77 8d 01 00 	mov    %rbx,0x18d77(%rip)        # 210e0 <fwp_tapes_cap>
    8369:	49 6b c5 68          	imul   $0x68,%r13,%rax
    836d:	4c 89 eb             	mov    %r13,%rbx
    8370:	4c 01 f8             	add    %r15,%rax
    8373:	48 8d 78 08          	lea    0x8(%rax),%rdi
    8377:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    837e:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8382:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8389:	00 
    838a:	48 29 f8             	sub    %rdi,%rax
    838d:	8d 48 68             	lea    0x68(%rax),%ecx
    8390:	31 c0                	xor    %eax,%eax
    8392:	c1 e9 03             	shr    $0x3,%ecx
    8395:	f3 48 ab             	rep stos %rax,(%rdi)
    8398:	49 8d 45 01          	lea    0x1(%r13),%rax
    839c:	48 89 05 45 8d 01 00 	mov    %rax,0x18d45(%rip)        # 210e8 <fwp_ntapes>
    83a3:	eb 13                	jmp    83b8 <f12+0x238>
    83a5:	0f 1f 00             	nopl   (%rax)
    83a8:	49 39 dd             	cmp    %rbx,%r13
    83ab:	0f 84 4f ff ff ff    	je     8300 <f12+0x180>
    83b1:	4c 8b 3d 38 8d 01 00 	mov    0x18d38(%rip),%r15        # 210f0 <fwp_tapes>
    83b8:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    83bc:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    83c0:	48 8d 3d 99 4d 00 00 	lea    0x4d99(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    83c7:	0f 29 04 24          	movaps %xmm0,(%rsp)
    83cb:	4d 01 fe             	add    %r15,%r14
    83ce:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    83d5:	00 
    83d6:	e8 b5 af ff ff       	call   3390 <getenv@plt>
    83db:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    83e0:	48 85 c0             	test   %rax,%rax
    83e3:	74 09                	je     83ee <f12+0x26e>
    83e5:	80 38 30             	cmpb   $0x30,(%rax)
    83e8:	0f 84 6a 06 00 00    	je     8a58 <f12+0x8d8>
    83ee:	48 83 3d 92 8c 01 00 	cmpq   $0x0,0x18c92(%rip)        # 21088 <fwp_tape_cached_bytes>
    83f5:	00 
    83f6:	0f 85 84 0d 00 00    	jne    9180 <f12+0x1000>
    83fc:	41 8b 06             	mov    (%r14),%eax
    83ff:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    8403:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    840a:	00 
    840b:	4c 89 2d c6 8c 01 00 	mov    %r13,0x18cc6(%rip)        # 210d8 <fwp_tape_next_slot>
    8412:	8d 70 01             	lea    0x1(%rax),%esi
    8415:	48 8b 05 9c 30 06 00 	mov    0x6309c(%rip),%rax        # 6b4b8 <fwp_cleanups>
    841c:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    8421:	41 89 36             	mov    %esi,(%r14)
    8424:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    842b:	00 
    842c:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    8433:	ff 
    8434:	48 85 c0             	test   %rax,%rax
    8437:	75 13                	jne    844c <f12+0x2cc>
    8439:	e9 a9 10 00 00       	jmp    94e7 <f12+0x1367>
    843e:	66 90                	xchg   %ax,%ax
    8440:	48 8b 00             	mov    (%rax),%rax
    8443:	48 85 c0             	test   %rax,%rax
    8446:	0f 84 9b 10 00 00    	je     94e7 <f12+0x1367>
    844c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    8450:	75 ee                	jne    8440 <f12+0x2c0>
    8452:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8456:	89 d9                	mov    %ebx,%ecx
    8458:	48 63 02             	movslq (%rdx),%rax
    845b:	49 89 56 50          	mov    %rdx,0x50(%r14)
    845f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    8463:	85 c0                	test   %eax,%eax
    8465:	78 09                	js     8470 <f12+0x2f0>
    8467:	48 6b c0 68          	imul   $0x68,%rax,%rax
    846b:	41 89 5c 07 58       	mov    %ebx,0x58(%r15,%rax,1)
    8470:	89 0a                	mov    %ecx,(%rdx)
    8472:	48 89 e8             	mov    %rbp,%rax
    8475:	31 c9                	xor    %ecx,%ecx
    8477:	48 85 ed             	test   %rbp,%rbp
    847a:	0f 84 f0 0a 00 00    	je     8f70 <f12+0xdf0>
    8480:	48 8b 40 10          	mov    0x10(%rax),%rax
    8484:	48 83 c1 01          	add    $0x1,%rcx
    8488:	48 85 c0             	test   %rax,%rax
    848b:	75 f3                	jne    8480 <f12+0x300>
    848d:	48 89 ea             	mov    %rbp,%rdx
    8490:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8494:	48 83 c0 01          	add    $0x1,%rax
    8498:	48 85 d2             	test   %rdx,%rdx
    849b:	75 f3                	jne    8490 <f12+0x310>
    849d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    84a4:	ff ff 1f 
    84a7:	48 39 c2             	cmp    %rax,%rdx
    84aa:	0f 82 f6 0f 00 00    	jb     94a6 <f12+0x1326>
    84b0:	48 85 c9             	test   %rcx,%rcx
    84b3:	0f 8e b7 0a 00 00    	jle    8f70 <f12+0xdf0>
    84b9:	48 39 c1             	cmp    %rax,%rcx
    84bc:	48 0f 46 c1          	cmovbe %rcx,%rax
    84c0:	49 89 c4             	mov    %rax,%r12
    84c3:	48 c1 e8 3c          	shr    $0x3c,%rax
    84c7:	0f 85 d9 0f 00 00    	jne    94a6 <f12+0x1326>
    84cd:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    84d1:	48 c1 e6 10          	shl    $0x10,%rsi
    84d5:	49 09 f5             	or     %rsi,%r13
    84d8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    84df:	00 
    84e0:	be 02 00 00 00       	mov    $0x2,%esi
    84e5:	e8 26 da ff ff       	call   5f10 <fwp_heap_alloc>
    84ea:	4c 89 30             	mov    %r14,(%rax)
    84ed:	48 8b 15 04 27 06 00 	mov    0x62704(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    84f4:	48 89 c3             	mov    %rax,%rbx
    84f7:	48 2b 05 d2 26 06 00 	sub    0x626d2(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    84fe:	48 c1 e2 10          	shl    $0x10,%rdx
    8502:	48 39 d0             	cmp    %rdx,%rax
    8505:	0f 83 55 0d 00 00    	jae    9260 <f12+0x10e0>
    850b:	48 89 c2             	mov    %rax,%rdx
    850e:	48 c1 ea 10          	shr    $0x10,%rdx
    8512:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8516:	48 8b 15 fb 26 06 00 	mov    0x626fb(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    851d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8521:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8525:	4d 85 f6             	test   %r14,%r14
    8528:	74 38                	je     8562 <f12+0x3e2>
    852a:	0f b6 0a             	movzbl (%rdx),%ecx
    852d:	80 f9 02             	cmp    $0x2,%cl
    8530:	0f 84 a7 0a 00 00    	je     8fdd <f12+0xe5d>
    8536:	80 f9 01             	cmp    $0x1,%cl
    8539:	75 27                	jne    8562 <f12+0x3e2>
    853b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    853e:	0f b7 c0             	movzwl %ax,%eax
    8541:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8544:	48 0f af c1          	imul   %rcx,%rax
    8548:	48 c1 e8 20          	shr    $0x20,%rax
    854c:	48 39 d0             	cmp    %rdx,%rax
    854f:	73 11                	jae    8562 <f12+0x3e2>
    8551:	49 01 c6             	add    %rax,%r14
    8554:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8558:	0f 84 48 0e 00 00    	je     93a6 <f12+0x1226>
    855e:	41 c6 06 01          	movb   $0x1,(%r14)
    8562:	4d 85 e4             	test   %r12,%r12
    8565:	74 4c                	je     85b3 <f12+0x433>
    8567:	4c 89 e9             	mov    %r13,%rcx
    856a:	48 89 ea             	mov    %rbp,%rdx
    856d:	31 c0                	xor    %eax,%eax
    856f:	48 c1 e1 20          	shl    $0x20,%rcx
    8573:	66 90                	xchg   %ax,%ax
    8575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    857c:	00 00 00 00 
    8580:	48 89 c6             	mov    %rax,%rsi
    8583:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8588:	48 01 ce             	add    %rcx,%rsi
    858b:	0f 80 aa 0e 00 00    	jo     943b <f12+0x12bb>
    8591:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8596:	48 89 c6             	mov    %rax,%rsi
    8599:	48 83 c0 01          	add    $0x1,%rax
    859d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    85a1:	48 c1 e6 04          	shl    $0x4,%rsi
    85a5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    85aa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    85ae:	4c 39 e0             	cmp    %r12,%rax
    85b1:	72 cd                	jb     8580 <f12+0x400>
    85b3:	48 8b 03             	mov    (%rbx),%rax
    85b6:	48 d1 e8             	shr    $1,%rax
    85b9:	0f 85 49 0a 00 00    	jne    9008 <f12+0xe88>
    85bf:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    85c6:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    85cd:	0f 1f 00             	nopl   (%rax)
    85d0:	48 89 df             	mov    %rbx,%rdi
    85d3:	4d 63 e5             	movslq %r13d,%r12
    85d6:	e8 25 f9 ff ff       	call   7f00 <fwp_drop4>
    85db:	4c 89 e7             	mov    %r12,%rdi
    85de:	e8 4d c1 ff ff       	call   4730 <fwp_tape_of>
    85e3:	48 89 c6             	mov    %rax,%rsi
    85e6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    85eb:	0f 85 d9 0e 00 00    	jne    94ca <f12+0x134a>
    85f1:	48 89 c7             	mov    %rax,%rdi
    85f4:	e8 97 b6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    85f9:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    85fd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8602:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8609:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    860d:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8611:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8616:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    861b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8620:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    8624:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8628:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    862e:	77 19                	ja     8649 <f12+0x4c9>
    8630:	41 0f b7 c5          	movzwl %r13w,%eax
    8634:	83 e8 01             	sub    $0x1,%eax
    8637:	48 98                	cltq
    8639:	48 3b 05 98 8a 01 00 	cmp    0x18a98(%rip),%rax        # 210d8 <fwp_tape_next_slot>
    8640:	7d 07                	jge    8649 <f12+0x4c9>
    8642:	48 89 05 8f 8a 01 00 	mov    %rax,0x18a8f(%rip)        # 210d8 <fwp_tape_next_slot>
    8649:	48 8b 05 68 2e 06 00 	mov    0x62e68(%rip),%rax        # 6b4b8 <fwp_cleanups>
    8650:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8654:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    865b:	00 
    865c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8660:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8667:	00 
    8668:	48 8d 05 f1 cb ff ff 	lea    -0x340f(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    866f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8676:	00 
    8677:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    867e:	00 
    867f:	48 89 04 24          	mov    %rax,(%rsp)
    8683:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    868a:	00 
    868b:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8692:	00 
    8693:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8697:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    869b:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    86a2:	00 
    86a3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    86aa:	00 
    86ab:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    86b2:	00 
    86b3:	48 89 05 fe 2d 06 00 	mov    %rax,0x62dfe(%rip)        # 6b4b8 <fwp_cleanups>
    86ba:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    86c1:	00 
    86c2:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    86c9:	00 
    86ca:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    86d1:	00 
    86d2:	4d 85 ff             	test   %r15,%r15
    86d5:	0f 88 55 0a 00 00    	js     9130 <f12+0xfb0>
    86db:	4c 89 f8             	mov    %r15,%rax
    86de:	48 c1 f8 20          	sar    $0x20,%rax
    86e2:	49 39 c4             	cmp    %rax,%r12
    86e5:	0f 85 44 0d 00 00    	jne    942f <f12+0x12af>
    86eb:	44 89 f9             	mov    %r15d,%ecx
    86ee:	49 89 cd             	mov    %rcx,%r13
    86f1:	48 39 ca             	cmp    %rcx,%rdx
    86f4:	0f 8e 29 0d 00 00    	jle    9423 <f12+0x12a3>
    86fa:	48 39 cb             	cmp    %rcx,%rbx
    86fd:	0f 8e 9d 09 00 00    	jle    90a0 <f12+0xf20>
    8703:	4c 39 f3             	cmp    %r14,%rbx
    8706:	0f 8e e4 0a 00 00    	jle    91f0 <f12+0x1070>
    870c:	49 89 dc             	mov    %rbx,%r12
    870f:	4d 85 f6             	test   %r14,%r14
    8712:	4d 0f 44 f4          	cmove  %r12,%r14
    8716:	eb 1d                	jmp    8735 <f12+0x5b5>
    8718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    871f:	00 
    8720:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8724:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    872b:	4c 89 e0             	mov    %r12,%rax
    872e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8732:	49 89 c6             	mov    %rax,%r14
    8735:	4d 39 f4             	cmp    %r14,%r12
    8738:	7f e6                	jg     8720 <f12+0x5a0>
    873a:	4d 85 c0             	test   %r8,%r8
    873d:	0f 84 2d 0b 00 00    	je     9270 <f12+0x10f0>
    8743:	4c 89 c7             	mov    %r8,%rdi
    8746:	ba 03 00 00 00       	mov    $0x3,%edx
    874b:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8750:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    8757:	00 
    8758:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    875d:	e8 2e ca ff ff       	call   5190 <ad_raw_realloc>
    8762:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8768:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    876e:	48 85 c0             	test   %rax,%rax
    8771:	49 89 c0             	mov    %rax,%r8
    8774:	0f 84 a6 0b 00 00    	je     9320 <f12+0x11a0>
    877a:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    8781:	00 
    8782:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    8789:	00 
    878a:	4d 85 e4             	test   %r12,%r12
    878d:	0f 85 47 0c 00 00    	jne    93da <f12+0x125a>
    8793:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    879a:	4d 85 ff             	test   %r15,%r15
    879d:	78 17                	js     87b6 <f12+0x636>
    879f:	44 89 f9             	mov    %r15d,%ecx
    87a2:	f2 0f 10 05 36 56 00 	movsd  0x5636(%rip),%xmm0        # dde0 <msg.4+0xb0>
    87a9:	00 
    87aa:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    87b0:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    87b6:	4c 39 eb             	cmp    %r13,%rbx
    87b9:	0f 8f 92 00 00 00    	jg     8851 <f12+0x6d1>
    87bf:	0f 12 fb             	movhlps %xmm3,%xmm7
    87c2:	66 49 0f 7e d2       	movq   %xmm2,%r10
    87c7:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    87cc:	49 29 dd             	sub    %rbx,%r13
    87cf:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    87d4:	0f 12 fa             	movhlps %xmm2,%xmm7
    87d7:	49 8d 3c d8          	lea    (%r8,%rbx,8),%rdi
    87db:	66 49 0f 7e fb       	movq   %xmm7,%r11
    87e0:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    87e4:	66 0f ef d2          	pxor   %xmm2,%xmm2
    87e8:	48 29 f1             	sub    %rsi,%rcx
    87eb:	4b 8d 14 eb          	lea    (%r11,%r13,8),%rdx
    87ef:	4c 29 df             	sub    %r11,%rdi
    87f2:	4d 29 da             	sub    %r11,%r10
    87f5:	eb 0d                	jmp    8804 <f12+0x684>
    87f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    87fe:	00 00 
    8800:	48 83 e8 04          	sub    $0x4,%rax
    8804:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    8809:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    880d:	7a 02                	jp     8811 <f12+0x691>
    880f:	74 37                	je     8848 <f12+0x6c8>
    8811:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    8815:	45 85 db             	test   %r11d,%r11d
    8818:	78 16                	js     8830 <f12+0x6b0>
    881a:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8820:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8824:	f2 43 0f 58 0c d8    	addsd  (%r8,%r11,8),%xmm1
    882a:	f2 43 0f 11 0c d8    	movsd  %xmm1,(%r8,%r11,8)
    8830:	4c 63 18             	movslq (%rax),%r11
    8833:	45 85 db             	test   %r11d,%r11d
    8836:	78 10                	js     8848 <f12+0x6c8>
    8838:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    883c:	f2 43 0f 58 04 d8    	addsd  (%r8,%r11,8),%xmm0
    8842:	f2 43 0f 11 04 d8    	movsd  %xmm0,(%r8,%r11,8)
    8848:	48 83 ea 08          	sub    $0x8,%rdx
    884c:	48 39 c6             	cmp    %rax,%rsi
    884f:	75 af                	jne    8800 <f12+0x680>
    8851:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8858:	ff ff 1f 
    885b:	48 39 d8             	cmp    %rbx,%rax
    885e:	0f 82 4e 0c 00 00    	jb     94b2 <f12+0x1332>
    8864:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    886b:	00 
    886c:	be 02 00 00 00       	mov    $0x2,%esi
    8871:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    8876:	e8 95 d6 ff ff       	call   5f10 <fwp_heap_alloc>
    887b:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    8880:	48 89 18             	mov    %rbx,(%rax)
    8883:	49 89 c4             	mov    %rax,%r12
    8886:	31 c0                	xor    %eax,%eax
    8888:	48 85 db             	test   %rbx,%rbx
    888b:	74 25                	je     88b2 <f12+0x732>
    888d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8894:	00 
    8895:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    889c:	00 00 00 00 
    88a0:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    88a4:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    88a9:	48 83 c0 01          	add    $0x1,%rax
    88ad:	48 39 c3             	cmp    %rax,%rbx
    88b0:	75 ee                	jne    88a0 <f12+0x720>
    88b2:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    88b9:	00 
    88ba:	48 8b 3c 24          	mov    (%rsp),%rdi
    88be:	4c 89 2d f3 2b 06 00 	mov    %r13,0x62bf3(%rip)        # 6b4b8 <fwp_cleanups>
    88c5:	e8 96 c9 ff ff       	call   5260 <fwp_tape_buffers_release>
    88ca:	48 8b 15 27 23 06 00 	mov    0x62327(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    88d1:	4c 89 e0             	mov    %r12,%rax
    88d4:	48 2b 05 f5 22 06 00 	sub    0x622f5(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    88db:	48 c1 e2 10          	shl    $0x10,%rdx
    88df:	48 39 d0             	cmp    %rdx,%rax
    88e2:	73 55                	jae    8939 <f12+0x7b9>
    88e4:	48 89 c2             	mov    %rax,%rdx
    88e7:	48 c1 ea 10          	shr    $0x10,%rdx
    88eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    88ef:	48 8b 15 22 23 06 00 	mov    0x62322(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    88f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    88fa:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    88fe:	48 85 db             	test   %rbx,%rbx
    8901:	74 36                	je     8939 <f12+0x7b9>
    8903:	0f b6 0a             	movzbl (%rdx),%ecx
    8906:	80 f9 02             	cmp    $0x2,%cl
    8909:	0f 84 51 08 00 00    	je     9160 <f12+0xfe0>
    890f:	80 f9 01             	cmp    $0x1,%cl
    8912:	75 25                	jne    8939 <f12+0x7b9>
    8914:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8917:	0f b7 c0             	movzwl %ax,%eax
    891a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    891d:	48 0f af c1          	imul   %rcx,%rax
    8921:	48 c1 e8 20          	shr    $0x20,%rax
    8925:	48 39 d0             	cmp    %rdx,%rax
    8928:	73 0f                	jae    8939 <f12+0x7b9>
    892a:	48 01 c3             	add    %rax,%rbx
    892d:	80 3b ff             	cmpb   $0xff,(%rbx)
    8930:	0f 84 7d 0a 00 00    	je     93b3 <f12+0x1233>
    8936:	c6 03 01             	movb   $0x1,(%rbx)
    8939:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
    893e:	0f 85 07 ae ff ff    	jne    374b <f12.cold>
    8944:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8949:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    894e:	48 89 05 63 2b 06 00 	mov    %rax,0x62b63(%rip)        # 6b4b8 <fwp_cleanups>
    8955:	e8 e6 ef ff ff       	call   7940 <fwp_tape_scope_release>
    895a:	49 8b 04 24          	mov    (%r12),%rax
    895e:	49 89 c6             	mov    %rax,%r14
    8961:	49 0f ba f6 3f       	btr    $0x3f,%r14
    8966:	48 85 c0             	test   %rax,%rax
    8969:	0f 88 51 05 00 00    	js     8ec0 <f12+0xd40>
    896f:	48 8b 15 82 22 06 00 	mov    0x62282(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    8976:	4c 89 e0             	mov    %r12,%rax
    8979:	48 2b 05 50 22 06 00 	sub    0x62250(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8980:	48 c1 e2 10          	shl    $0x10,%rdx
    8984:	48 39 d0             	cmp    %rdx,%rax
    8987:	0f 83 33 05 00 00    	jae    8ec0 <f12+0xd40>
    898d:	48 89 c2             	mov    %rax,%rdx
    8990:	48 c1 ea 10          	shr    $0x10,%rdx
    8994:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8998:	48 8b 15 79 22 06 00 	mov    0x62279(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    899f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89a3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    89a7:	48 85 c9             	test   %rcx,%rcx
    89aa:	0f 84 10 05 00 00    	je     8ec0 <f12+0xd40>
    89b0:	0f b6 32             	movzbl (%rdx),%esi
    89b3:	40 80 fe 02          	cmp    $0x2,%sil
    89b7:	0f 84 f3 04 00 00    	je     8eb0 <f12+0xd30>
    89bd:	40 80 fe 01          	cmp    $0x1,%sil
    89c1:	0f 85 f9 04 00 00    	jne    8ec0 <f12+0xd40>
    89c7:	8b 72 18             	mov    0x18(%rdx),%esi
    89ca:	0f b7 c0             	movzwl %ax,%eax
    89cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    89d0:	48 0f af c6          	imul   %rsi,%rax
    89d4:	48 c1 e8 20          	shr    $0x20,%rax
    89d8:	48 39 d0             	cmp    %rdx,%rax
    89db:	0f 83 df 04 00 00    	jae    8ec0 <f12+0xd40>
    89e1:	48 01 c1             	add    %rax,%rcx
    89e4:	80 39 01             	cmpb   $0x1,(%rcx)
    89e7:	0f 85 d3 04 00 00    	jne    8ec0 <f12+0xd40>
    89ed:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
    89f2:	4d 89 e5             	mov    %r12,%r13
    89f5:	31 ff                	xor    %edi,%edi
    89f7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    89fc:	f2 0f 10 0d f4 53 00 	movsd  0x53f4(%rip),%xmm1        # ddf8 <msg.4+0xc8>
    8a03:	00 
    8a04:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8a08:	31 c0                	xor    %eax,%eax
    8a0a:	4d 85 f6             	test   %r14,%r14
    8a0d:	75 2f                	jne    8a3e <f12+0x8be>
    8a0f:	eb 5f                	jmp    8a70 <f12+0x8f0>
    8a11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a18:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8a1d:	0f 88 1d 0a 00 00    	js     9440 <f12+0x12c0>
    8a23:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8a28:	48 83 c0 01          	add    $0x1,%rax
    8a2c:	48 83 c2 08          	add    $0x8,%rdx
    8a30:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8a34:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8a39:	49 39 c6             	cmp    %rax,%r14
    8a3c:	74 32                	je     8a70 <f12+0x8f0>
    8a3e:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    8a43:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    8a48:	79 ce                	jns    8a18 <f12+0x898>
    8a4a:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    8a4f:	eb c7                	jmp    8a18 <f12+0x898>
    8a51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a58:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8a5c:	0f 84 9a f9 ff ff    	je     83fc <f12+0x27c>
    8a62:	e9 87 f9 ff ff       	jmp    83ee <f12+0x26e>
    8a67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a6e:	00 00 
    8a70:	e8 8b f4 ff ff       	call   7f00 <fwp_drop4>
    8a75:	48 89 e8             	mov    %rbp,%rax
    8a78:	31 d2                	xor    %edx,%edx
    8a7a:	48 85 ed             	test   %rbp,%rbp
    8a7d:	0f 84 b7 08 00 00    	je     933a <f12+0x11ba>
    8a83:	66 90                	xchg   %ax,%ax
    8a85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a8c:	00 00 00 00 
    8a90:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a94:	48 83 c2 01          	add    $0x1,%rdx
    8a98:	48 85 c0             	test   %rax,%rax
    8a9b:	75 f3                	jne    8a90 <f12+0x910>
    8a9d:	49 8b 45 00          	mov    0x0(%r13),%rax
    8aa1:	49 89 c7             	mov    %rax,%r15
    8aa4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8aa9:	48 85 c0             	test   %rax,%rax
    8aac:	0f 88 60 03 00 00    	js     8e12 <f12+0xc92>
    8ab2:	48 8b 05 3f 21 06 00 	mov    0x6213f(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    8ab9:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    8abe:	48 2b 0d 0b 21 06 00 	sub    0x6210b(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    8ac5:	48 c1 e0 10          	shl    $0x10,%rax
    8ac9:	48 39 c1             	cmp    %rax,%rcx
    8acc:	0f 83 40 03 00 00    	jae    8e12 <f12+0xc92>
    8ad2:	48 89 c8             	mov    %rcx,%rax
    8ad5:	48 c1 e8 10          	shr    $0x10,%rax
    8ad9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    8add:	48 8b 05 34 21 06 00 	mov    0x62134(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    8ae4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    8ae8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8aec:	48 85 ff             	test   %rdi,%rdi
    8aef:	0f 84 1d 03 00 00    	je     8e12 <f12+0xc92>
    8af5:	0f b6 06             	movzbl (%rsi),%eax
    8af8:	3c 02                	cmp    $0x2,%al
    8afa:	0f 84 00 03 00 00    	je     8e00 <f12+0xc80>
    8b00:	3c 01                	cmp    $0x1,%al
    8b02:	0f 85 01 03 00 00    	jne    8e09 <f12+0xc89>
    8b08:	8b 46 18             	mov    0x18(%rsi),%eax
    8b0b:	0f b7 c9             	movzwl %cx,%ecx
    8b0e:	48 0f af c8          	imul   %rax,%rcx
    8b12:	8b 46 1c             	mov    0x1c(%rsi),%eax
    8b15:	48 c1 e9 20          	shr    $0x20,%rcx
    8b19:	48 39 c1             	cmp    %rax,%rcx
    8b1c:	0f 83 e7 02 00 00    	jae    8e09 <f12+0xc89>
    8b22:	48 01 cf             	add    %rcx,%rdi
    8b25:	80 3f 01             	cmpb   $0x1,(%rdi)
    8b28:	0f 85 db 02 00 00    	jne    8e09 <f12+0xc89>
    8b2e:	49 39 d7             	cmp    %rdx,%r15
    8b31:	48 89 d0             	mov    %rdx,%rax
    8b34:	49 0f 46 c7          	cmovbe %r15,%rax
    8b38:	48 85 c0             	test   %rax,%rax
    8b3b:	0f 84 0b 09 00 00    	je     944c <f12+0x12cc>
    8b41:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    8b48:	00 
    8b49:	4d 8d 75 08          	lea    0x8(%r13),%r14
    8b4d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8b52:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    8b59:	00 
    8b5a:	48 89 e9             	mov    %rbp,%rcx
    8b5d:	31 d2                	xor    %edx,%edx
    8b5f:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8b63:	eb 38                	jmp    8b9d <f12+0xa1d>
    8b65:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b71:	00 00 00 00 
    8b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b7c:	00 00 00 00 
    8b80:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    8b85:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    8b8a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    8b90:	48 83 c2 08          	add    $0x8,%rdx
    8b94:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8b98:	49 39 d0             	cmp    %rdx,%r8
    8b9b:	74 1b                	je     8bb8 <f12+0xa38>
    8b9d:	48 89 fe             	mov    %rdi,%rsi
    8ba0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8ba5:	79 d9                	jns    8b80 <f12+0xa00>
    8ba7:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8bac:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    8bb0:	eb ce                	jmp    8b80 <f12+0xa00>
    8bb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8bb8:	48 85 ed             	test   %rbp,%rbp
    8bbb:	0f 84 5a 08 00 00    	je     941b <f12+0x129b>
    8bc1:	4c 8b 05 30 20 06 00 	mov    0x62030(%rip),%r8        # 6abf8 <fwp_heap+0x13d8>
    8bc8:	4c 8b 0d 01 20 06 00 	mov    0x62001(%rip),%r9        # 6abd0 <fwp_heap+0x13b0>
    8bcf:	48 89 e9             	mov    %rbp,%rcx
    8bd2:	45 31 ed             	xor    %r13d,%r13d
    8bd5:	4c 8b 15 3c 20 06 00 	mov    0x6203c(%rip),%r10        # 6ac18 <fwp_heap+0x13f8>
    8bdc:	49 c1 e0 10          	shl    $0x10,%r8
    8be0:	eb 1c                	jmp    8bfe <f12+0xa7e>
    8be2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8be8:	49 83 c5 01          	add    $0x1,%r13
    8bec:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8bf0:	49 39 c5             	cmp    %rax,%r13
    8bf3:	0f 83 67 01 00 00    	jae    8d60 <f12+0xbe0>
    8bf9:	48 85 c9             	test   %rcx,%rcx
    8bfc:	74 56                	je     8c54 <f12+0xad4>
    8bfe:	48 89 ca             	mov    %rcx,%rdx
    8c01:	4c 29 ca             	sub    %r9,%rdx
    8c04:	4c 39 c2             	cmp    %r8,%rdx
    8c07:	73 4b                	jae    8c54 <f12+0xad4>
    8c09:	48 89 d6             	mov    %rdx,%rsi
    8c0c:	48 c1 ee 10          	shr    $0x10,%rsi
    8c10:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8c14:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    8c18:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8c1c:	48 85 ff             	test   %rdi,%rdi
    8c1f:	74 33                	je     8c54 <f12+0xad4>
    8c21:	44 0f b6 1e          	movzbl (%rsi),%r11d
    8c25:	41 80 fb 02          	cmp    $0x2,%r11b
    8c29:	0f 84 19 01 00 00    	je     8d48 <f12+0xbc8>
    8c2f:	41 80 fb 01          	cmp    $0x1,%r11b
    8c33:	75 1f                	jne    8c54 <f12+0xad4>
    8c35:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    8c39:	0f b7 d2             	movzwl %dx,%edx
    8c3c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8c3f:	49 0f af d3          	imul   %r11,%rdx
    8c43:	48 c1 ea 20          	shr    $0x20,%rdx
    8c47:	48 39 f2             	cmp    %rsi,%rdx
    8c4a:	73 08                	jae    8c54 <f12+0xad4>
    8c4c:	48 01 d7             	add    %rdx,%rdi
    8c4f:	80 3f 01             	cmpb   $0x1,(%rdi)
    8c52:	74 94                	je     8be8 <f12+0xa68>
    8c54:	49 39 c5             	cmp    %rax,%r13
    8c57:	0f 83 03 01 00 00    	jae    8d60 <f12+0xbe0>
    8c5d:	49 89 c7             	mov    %rax,%r15
    8c60:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    8c67:	00 
    8c68:	45 31 e4             	xor    %r12d,%r12d
    8c6b:	48 89 04 24          	mov    %rax,(%rsp)
    8c6f:	48 8d 1d aa 0b 06 00 	lea    0x60baa(%rip),%rbx        # 69820 <fwp_heap>
    8c76:	eb 3a                	jmp    8cb2 <f12+0xb32>
    8c78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c7f:	00 
    8c80:	41 80 f9 01          	cmp    $0x1,%r9b
    8c84:	75 27                	jne    8cad <f12+0xb2d>
    8c86:	45 8b 48 18          	mov    0x18(%r8),%r9d
    8c8a:	0f b7 c0             	movzwl %ax,%eax
    8c8d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    8c91:	49 0f af c1          	imul   %r9,%rax
    8c95:	48 c1 e8 20          	shr    $0x20,%rax
    8c99:	4c 39 c0             	cmp    %r8,%rax
    8c9c:	73 0f                	jae    8cad <f12+0xb2d>
    8c9e:	48 01 c7             	add    %rax,%rdi
    8ca1:	80 3f ff             	cmpb   $0xff,(%rdi)
    8ca4:	0f 84 46 03 00 00    	je     8ff0 <f12+0xe70>
    8caa:	c6 07 01             	movb   $0x1,(%rdi)
    8cad:	4d 39 fd             	cmp    %r15,%r13
    8cb0:	73 7e                	jae    8d30 <f12+0xbb0>
    8cb2:	49 83 ef 01          	sub    $0x1,%r15
    8cb6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    8cbb:	48 8b 34 24          	mov    (%rsp),%rsi
    8cbf:	bf 01 00 00 00       	mov    $0x1,%edi
    8cc4:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    8cca:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8cce:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    8cd5:	00 
    8cd6:	e8 75 e0 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    8cdb:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    8ce2:	49 89 c4             	mov    %rax,%r12
    8ce5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8cec:	48 c1 e7 10          	shl    $0x10,%rdi
    8cf0:	48 39 f8             	cmp    %rdi,%rax
    8cf3:	73 b8                	jae    8cad <f12+0xb2d>
    8cf5:	48 89 c7             	mov    %rax,%rdi
    8cf8:	48 c1 ef 10          	shr    $0x10,%rdi
    8cfc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    8d00:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    8d07:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    8d0b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    8d0f:	48 85 ff             	test   %rdi,%rdi
    8d12:	74 99                	je     8cad <f12+0xb2d>
    8d14:	45 0f b6 08          	movzbl (%r8),%r9d
    8d18:	41 80 f9 02          	cmp    $0x2,%r9b
    8d1c:	0f 85 5e ff ff ff    	jne    8c80 <f12+0xb00>
    8d22:	66 85 c0             	test   %ax,%ax
    8d25:	0f 84 76 ff ff ff    	je     8ca1 <f12+0xb21>
    8d2b:	4d 39 fd             	cmp    %r15,%r13
    8d2e:	72 82                	jb     8cb2 <f12+0xb32>
    8d30:	4d 85 ed             	test   %r13,%r13
    8d33:	75 2e                	jne    8d63 <f12+0xbe3>
    8d35:	8b 44 24 40          	mov    0x40(%rsp),%eax
    8d39:	85 c0                	test   %eax,%eax
    8d3b:	4d 0f 45 f5          	cmovne %r13,%r14
    8d3f:	eb 6f                	jmp    8db0 <f12+0xc30>
    8d41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d48:	66 85 d2             	test   %dx,%dx
    8d4b:	0f 84 fe fe ff ff    	je     8c4f <f12+0xacf>
    8d51:	49 39 c5             	cmp    %rax,%r13
    8d54:	0f 82 03 ff ff ff    	jb     8c5d <f12+0xadd>
    8d5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d60:	45 31 e4             	xor    %r12d,%r12d
    8d63:	4c 89 f2             	mov    %r14,%rdx
    8d66:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    8d6a:	48 89 e8             	mov    %rbp,%rax
    8d6d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d74:	00 
    8d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d7c:	00 00 00 00 
    8d80:	48 8b 0a             	mov    (%rdx),%rcx
    8d83:	48 83 c2 08          	add    $0x8,%rdx
    8d87:	48 89 c7             	mov    %rax,%rdi
    8d8a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8d8e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8d92:	49 39 d0             	cmp    %rdx,%r8
    8d95:	75 e9                	jne    8d80 <f12+0xc00>
    8d97:	8b 54 24 40          	mov    0x40(%rsp),%edx
    8d9b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    8d9f:	85 d2                	test   %edx,%edx
    8da1:	0f 84 c9 03 00 00    	je     9170 <f12+0xff0>
    8da7:	49 89 ec             	mov    %rbp,%r12
    8daa:	45 31 f6             	xor    %r14d,%r14d
    8dad:	48 89 c5             	mov    %rax,%rbp
    8db0:	4c 89 f7             	mov    %r14,%rdi
    8db3:	e8 58 cc ff ff       	call   5a10 <fwp_mem_free>
    8db8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8dbd:	e8 3e f1 ff ff       	call   7f00 <fwp_drop4>
    8dc2:	48 89 ef             	mov    %rbp,%rdi
    8dc5:	e8 26 e5 ff ff       	call   72f0 <fwp_drop0>
    8dca:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    8dd1:	00 
    8dd2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8dd9:	00 00 
    8ddb:	0f 85 01 07 00 00    	jne    94e2 <f12+0x1362>
    8de1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    8de8:	4c 89 e0             	mov    %r12,%rax
    8deb:	5b                   	pop    %rbx
    8dec:	5d                   	pop    %rbp
    8ded:	41 5c                	pop    %r12
    8def:	41 5d                	pop    %r13
    8df1:	41 5e                	pop    %r14
    8df3:	41 5f                	pop    %r15
    8df5:	c3                   	ret
    8df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8dfd:	00 00 00 
    8e00:	66 85 c9             	test   %cx,%cx
    8e03:	0f 84 1c fd ff ff    	je     8b25 <f12+0x9a5>
    8e09:	48 85 ed             	test   %rbp,%rbp
    8e0c:	0f 84 1b 04 00 00    	je     922d <f12+0x10ad>
    8e12:	48 89 e8             	mov    %rbp,%rax
    8e15:	45 31 e4             	xor    %r12d,%r12d
    8e18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e1f:	00 
    8e20:	48 8b 40 10          	mov    0x10(%rax),%rax
    8e24:	4c 89 e2             	mov    %r12,%rdx
    8e27:	49 83 c4 01          	add    $0x1,%r12
    8e2b:	48 85 c0             	test   %rax,%rax
    8e2e:	75 f0                	jne    8e20 <f12+0xca0>
    8e30:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8e37:	ff ff 1f 
    8e3a:	4c 39 e0             	cmp    %r12,%rax
    8e3d:	0f 82 63 06 00 00    	jb     94a6 <f12+0x1326>
    8e43:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8e4a:	00 
    8e4b:	be 02 00 00 00       	mov    $0x2,%esi
    8e50:	e8 bb d0 ff ff       	call   5f10 <fwp_heap_alloc>
    8e55:	4d 39 e7             	cmp    %r12,%r15
    8e58:	48 89 ea             	mov    %rbp,%rdx
    8e5b:	49 89 c6             	mov    %rax,%r14
    8e5e:	4c 89 e0             	mov    %r12,%rax
    8e61:	49 0f 46 c7          	cmovbe %r15,%rax
    8e65:	4c 89 f1             	mov    %r14,%rcx
    8e68:	66 90                	xchg   %ax,%ax
    8e6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e71:	00 00 00 00 
    8e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e7c:	00 00 00 00 
    8e80:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    8e84:	48 83 c1 08          	add    $0x8,%rcx
    8e88:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    8e8c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8e90:	48 85 d2             	test   %rdx,%rdx
    8e93:	75 eb                	jne    8e80 <f12+0xd00>
    8e95:	48 85 c0             	test   %rax,%rax
    8e98:	0f 84 a1 03 00 00    	je     923f <f12+0x10bf>
    8e9e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    8ea5:	00 
    8ea6:	e9 a2 fc ff ff       	jmp    8b4d <f12+0x9cd>
    8eab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8eb0:	66 85 c0             	test   %ax,%ax
    8eb3:	0f 84 2b fb ff ff    	je     89e4 <f12+0x864>
    8eb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ec0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8ec7:	ff ff 1f 
    8eca:	4c 39 f0             	cmp    %r14,%rax
    8ecd:	0f 82 df 05 00 00    	jb     94b2 <f12+0x1332>
    8ed3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8eda:	00 
    8edb:	be 01 00 00 00       	mov    $0x1,%esi
    8ee0:	e8 2b d0 ff ff       	call   5f10 <fwp_heap_alloc>
    8ee5:	4c 89 30             	mov    %r14,(%rax)
    8ee8:	48 8b 15 09 1d 06 00 	mov    0x61d09(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    8eef:	49 89 c5             	mov    %rax,%r13
    8ef2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8ef7:	48 2b 05 d2 1c 06 00 	sub    0x61cd2(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8efe:	48 c1 e2 10          	shl    $0x10,%rdx
    8f02:	48 39 d0             	cmp    %rdx,%rax
    8f05:	73 57                	jae    8f5e <f12+0xdde>
    8f07:	48 89 c2             	mov    %rax,%rdx
    8f0a:	48 c1 ea 10          	shr    $0x10,%rdx
    8f0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f12:	48 8b 15 ff 1c 06 00 	mov    0x61cff(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8f19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f1d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8f21:	4d 85 ff             	test   %r15,%r15
    8f24:	74 38                	je     8f5e <f12+0xdde>
    8f26:	0f b6 0a             	movzbl (%rdx),%ecx
    8f29:	80 f9 02             	cmp    $0x2,%cl
    8f2c:	0f 84 1e 03 00 00    	je     9250 <f12+0x10d0>
    8f32:	80 f9 01             	cmp    $0x1,%cl
    8f35:	75 27                	jne    8f5e <f12+0xdde>
    8f37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f3a:	0f b7 c0             	movzwl %ax,%eax
    8f3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f40:	48 0f af c1          	imul   %rcx,%rax
    8f44:	48 c1 e8 20          	shr    $0x20,%rax
    8f48:	48 39 d0             	cmp    %rdx,%rax
    8f4b:	73 11                	jae    8f5e <f12+0xdde>
    8f4d:	49 01 c7             	add    %rax,%r15
    8f50:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8f54:	0f 84 66 04 00 00    	je     93c0 <f12+0x1240>
    8f5a:	41 c6 07 01          	movb   $0x1,(%r15)
    8f5e:	4c 89 e7             	mov    %r12,%rdi
    8f61:	e9 91 fa ff ff       	jmp    89f7 <f12+0x877>
    8f66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f6d:	00 00 00 
    8f70:	48 c1 e6 10          	shl    $0x10,%rsi
    8f74:	bf 08 00 00 00       	mov    $0x8,%edi
    8f79:	49 09 f5             	or     %rsi,%r13
    8f7c:	be 02 00 00 00       	mov    $0x2,%esi
    8f81:	e8 8a cf ff ff       	call   5f10 <fwp_heap_alloc>
    8f86:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8f8d:	48 8b 15 64 1c 06 00 	mov    0x61c64(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    8f94:	48 89 c3             	mov    %rax,%rbx
    8f97:	48 2b 05 32 1c 06 00 	sub    0x61c32(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8f9e:	48 c1 e2 10          	shl    $0x10,%rdx
    8fa2:	48 39 d0             	cmp    %rdx,%rax
    8fa5:	0f 83 14 f6 ff ff    	jae    85bf <f12+0x43f>
    8fab:	48 89 c2             	mov    %rax,%rdx
    8fae:	48 c1 ea 10          	shr    $0x10,%rdx
    8fb2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8fb6:	48 8b 15 5b 1c 06 00 	mov    0x61c5b(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8fbd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8fc1:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8fc5:	4d 85 f6             	test   %r14,%r14
    8fc8:	0f 84 e5 f5 ff ff    	je     85b3 <f12+0x433>
    8fce:	0f b6 0a             	movzbl (%rdx),%ecx
    8fd1:	45 31 e4             	xor    %r12d,%r12d
    8fd4:	80 f9 02             	cmp    $0x2,%cl
    8fd7:	0f 85 59 f5 ff ff    	jne    8536 <f12+0x3b6>
    8fdd:	66 85 c0             	test   %ax,%ax
    8fe0:	0f 85 7c f5 ff ff    	jne    8562 <f12+0x3e2>
    8fe6:	e9 69 f5 ff ff       	jmp    8554 <f12+0x3d4>
    8feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ff0:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    8ff5:	e8 d6 c7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8ffa:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    8fff:	e9 a6 fc ff ff       	jmp    8caa <f12+0xb2a>
    9004:	0f 1f 40 00          	nopl   0x0(%rax)
    9008:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    900c:	4c 89 e1             	mov    %r12,%rcx
    900f:	48 c1 e9 3c          	shr    $0x3c,%rcx
    9013:	0f 85 8d 04 00 00    	jne    94a6 <f12+0x1326>
    9019:	4d 85 e4             	test   %r12,%r12
    901c:	0f 84 9d f5 ff ff    	je     85bf <f12+0x43f>
    9022:	48 c1 e0 04          	shl    $0x4,%rax
    9026:	4d 01 e4             	add    %r12,%r12
    9029:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    902d:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    9032:	0f 1f 00             	nopl   (%rax)
    9035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    903c:	00 00 00 00 
    9040:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    9045:	49 8b 77 18          	mov    0x18(%r15),%rsi
    9049:	49 83 c7 10          	add    $0x10,%r15
    904d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    9051:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    9056:	e8 f5 d6 ff ff       	call   6750 <w107>
    905b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9060:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9064:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    9069:	4d 39 fe             	cmp    %r15,%r14
    906c:	75 d2                	jne    9040 <f12+0xec0>
    906e:	4c 89 23             	mov    %r12,(%rbx)
    9071:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    9078:	45 31 f6             	xor    %r14d,%r14d
    907b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9080:	4a 8b 74 f3 10       	mov    0x10(%rbx,%r14,8),%rsi
    9085:	4c 89 ff             	mov    %r15,%rdi
    9088:	49 83 c6 02          	add    $0x2,%r14
    908c:	e8 3f d5 ff ff       	call   65d0 <f128.constprop.0>
    9091:	49 89 c7             	mov    %rax,%r15
    9094:	4d 39 e6             	cmp    %r12,%r14
    9097:	72 e7                	jb     9080 <f12+0xf00>
    9099:	e9 32 f5 ff ff       	jmp    85d0 <f12+0x450>
    909e:	66 90                	xchg   %ax,%ax
    90a0:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    90a4:	4d 39 e6             	cmp    %r12,%r14
    90a7:	0f 8c 62 f6 ff ff    	jl     870f <f12+0x58f>
    90ad:	4d 85 c0             	test   %r8,%r8
    90b0:	0f 84 aa 03 00 00    	je     9460 <f12+0x12e0>
    90b6:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    90bb:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    90c2:	00 
    90c3:	31 f6                	xor    %esi,%esi
    90c5:	4c 89 c7             	mov    %r8,%rdi
    90c8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    90cd:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    90d2:	e8 d9 a3 ff ff       	call   34b0 <memset@plt>
    90d7:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    90dd:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    90e3:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
    90e8:	49 89 c0             	mov    %rax,%r8
    90eb:	e9 b2 f6 ff ff       	jmp    87a2 <f12+0x622>
    90f0:	48 8d 3d 29 e7 ff ff 	lea    -0x18d7(%rip),%rdi        # 7820 <fwp_tape_finish>
    90f7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    90fc:	e8 8f 31 00 00       	call   c290 <atexit>
    9101:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9106:	85 c0                	test   %eax,%eax
    9108:	0f 85 6a 03 00 00    	jne    9478 <f12+0x12f8>
    910e:	c7 05 48 7f 00 00 01 	movl   $0x1,0x7f48(%rip)        # 11060 <registered_finish.0>
    9115:	00 00 00 
    9118:	e9 a0 f1 ff ff       	jmp    82bd <f12+0x13d>
    911d:	0f 1f 00             	nopl   (%rax)
    9120:	66 85 c0             	test   %ax,%ax
    9123:	0f 85 47 f1 ff ff    	jne    8270 <f12+0xf0>
    9129:	e9 1e f1 ff ff       	jmp    824c <f12+0xcc>
    912e:	66 90                	xchg   %ax,%ax
    9130:	4c 39 f3             	cmp    %r14,%rbx
    9133:	0f 8f d3 f5 ff ff    	jg     870c <f12+0x58c>
    9139:	48 85 db             	test   %rbx,%rbx
    913c:	74 12                	je     9150 <f12+0xfd0>
    913e:	4d 85 c0             	test   %r8,%r8
    9141:	0f 84 19 03 00 00    	je     9460 <f12+0x12e0>
    9147:	48 85 db             	test   %rbx,%rbx
    914a:	0f 85 87 02 00 00    	jne    93d7 <f12+0x1257>
    9150:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    9157:	e9 5a f6 ff ff       	jmp    87b6 <f12+0x636>
    915c:	0f 1f 40 00          	nopl   0x0(%rax)
    9160:	66 85 c0             	test   %ax,%ax
    9163:	0f 85 d0 f7 ff ff    	jne    8939 <f12+0x7b9>
    9169:	e9 bf f7 ff ff       	jmp    892d <f12+0x7ad>
    916e:	66 90                	xchg   %ax,%ax
    9170:	49 89 ec             	mov    %rbp,%r12
    9173:	48 89 c5             	mov    %rax,%rbp
    9176:	e9 35 fc ff ff       	jmp    8db0 <f12+0xc30>
    917b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9180:	66 0f 6f 0d 18 7f 01 	movdqa 0x17f18(%rip),%xmm1        # 210a0 <fwp_tape_workspace>
    9187:	00 
    9188:	48 c7 05 f5 7e 01 00 	movq   $0x0,0x17ef5(%rip)        # 21088 <fwp_tape_cached_bytes>
    918f:	00 00 00 00 
    9193:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    9198:	48 8b 05 21 7f 01 00 	mov    0x17f21(%rip),%rax        # 210c0 <fwp_tape_workspace+0x20>
    919f:	66 0f 6f 0d 09 7f 01 	movdqa 0x17f09(%rip),%xmm1        # 210b0 <fwp_tape_workspace+0x10>
    91a6:	00 
    91a7:	49 89 46 40          	mov    %rax,0x40(%r14)
    91ab:	48 8b 05 16 7f 01 00 	mov    0x17f16(%rip),%rax        # 210c8 <fwp_tape_workspace+0x28>
    91b2:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    91b7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    91bb:	49 89 46 18          	mov    %rax,0x18(%r14)
    91bf:	48 8b 05 0a 7f 01 00 	mov    0x17f0a(%rip),%rax        # 210d0 <fwp_tape_workspace+0x30>
    91c6:	0f 29 0d d3 7e 01 00 	movaps %xmm1,0x17ed3(%rip)        # 210a0 <fwp_tape_workspace>
    91cd:	49 89 46 48          	mov    %rax,0x48(%r14)
    91d1:	0f 29 0d d8 7e 01 00 	movaps %xmm1,0x17ed8(%rip)        # 210b0 <fwp_tape_workspace+0x10>
    91d8:	48 c7 05 ed 7e 01 00 	movq   $0x0,0x17eed(%rip)        # 210d0 <fwp_tape_workspace+0x30>
    91df:	00 00 00 00 
    91e3:	0f 29 0d d6 7e 01 00 	movaps %xmm1,0x17ed6(%rip)        # 210c0 <fwp_tape_workspace+0x20>
    91ea:	e9 0d f2 ff ff       	jmp    83fc <f12+0x27c>
    91ef:	90                   	nop
    91f0:	4d 85 c0             	test   %r8,%r8
    91f3:	0f 84 67 02 00 00    	je     9460 <f12+0x12e0>
    91f9:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    91fe:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    9202:	31 f6                	xor    %esi,%esi
    9204:	4c 89 c7             	mov    %r8,%rdi
    9207:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    920c:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9213:	00 
    9214:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9219:	e9 b4 fe ff ff       	jmp    90d2 <f12+0xf52>
    921e:	66 90                	xchg   %ax,%ax
    9220:	48 83 05 a8 22 06 00 	addq   $0x1,0x622a8(%rip)        # 6b4d0 <iteration_retains>
    9227:	01 
    9228:	e9 36 f0 ff ff       	jmp    8263 <f12+0xe3>
    922d:	be 02 00 00 00       	mov    $0x2,%esi
    9232:	bf 08 00 00 00       	mov    $0x8,%edi
    9237:	e8 d4 cc ff ff       	call   5f10 <fwp_heap_alloc>
    923c:	49 89 c6             	mov    %rax,%r14
    923f:	45 31 e4             	xor    %r12d,%r12d
    9242:	e9 69 fb ff ff       	jmp    8db0 <f12+0xc30>
    9247:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    924e:	00 00 
    9250:	66 85 c0             	test   %ax,%ax
    9253:	0f 85 05 fd ff ff    	jne    8f5e <f12+0xdde>
    9259:	e9 f2 fc ff ff       	jmp    8f50 <f12+0xdd0>
    925e:	66 90                	xchg   %ax,%ax
    9260:	4d 85 e4             	test   %r12,%r12
    9263:	0f 85 fe f2 ff ff    	jne    8567 <f12+0x3e7>
    9269:	e9 51 f3 ff ff       	jmp    85bf <f12+0x43f>
    926e:	66 90                	xchg   %ax,%ax
    9270:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9277:	ff ff 1f 
    927a:	49 8d 46 ff          	lea    -0x1(%r14),%rax
    927e:	48 39 c2             	cmp    %rax,%rdx
    9281:	0f 82 37 02 00 00    	jb     94be <f12+0x133e>
    9287:	48 8d 05 32 7f 04 00 	lea    0x47f32(%rip),%rax        # 511c0 <ad_raw_blocks>
    928e:	45 31 ed             	xor    %r13d,%r13d
    9291:	eb 22                	jmp    92b5 <f12+0x1135>
    9293:	66 90                	xchg   %ax,%ax
    9295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    929c:	00 00 00 00 
    92a0:	49 83 c5 01          	add    $0x1,%r13
    92a4:	48 83 c0 18          	add    $0x18,%rax
    92a8:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    92af:	0f 84 5a 01 00 00    	je     940f <f12+0x128f>
    92b5:	48 83 38 00          	cmpq   $0x0,(%rax)
    92b9:	75 e5                	jne    92a0 <f12+0x1120>
    92bb:	be 08 00 00 00       	mov    $0x8,%esi
    92c0:	4c 89 f7             	mov    %r14,%rdi
    92c3:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    92c8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    92cd:	e8 3e a2 ff ff       	call   3510 <calloc@plt>
    92d2:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    92d8:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    92de:	48 8d 15 db 7e 04 00 	lea    0x47edb(%rip),%rdx        # 511c0 <ad_raw_blocks>
    92e5:	48 85 c0             	test   %rax,%rax
    92e8:	74 36                	je     9320 <f12+0x11a0>
    92ea:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    92ef:	48 89 c6             	mov    %rax,%rsi
    92f2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    92f7:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    92fb:	b9 03 00 00 00       	mov    $0x3,%ecx
    9300:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9307:	00 
    9308:	e8 f3 a8 ff ff       	call   3c00 <ad_raw_record>
    930d:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    9312:	e9 63 f4 ff ff       	jmp    877a <f12+0x5fa>
    9317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    931e:	00 00 
    9320:	4d 85 e4             	test   %r12,%r12
    9323:	0f 85 37 01 00 00    	jne    9460 <f12+0x12e0>
    9329:	45 31 c0             	xor    %r8d,%r8d
    932c:	e9 62 f4 ff ff       	jmp    8793 <f12+0x613>
    9331:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9335:	e9 75 ef ff ff       	jmp    82af <f12+0x12f>
    933a:	49 8b 45 00          	mov    0x0(%r13),%rax
    933e:	48 85 c0             	test   %rax,%rax
    9341:	0f 88 e6 fe ff ff    	js     922d <f12+0x10ad>
    9347:	48 8b 35 aa 18 06 00 	mov    0x618aa(%rip),%rsi        # 6abf8 <fwp_heap+0x13d8>
    934e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    9353:	48 2b 0d 76 18 06 00 	sub    0x61876(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    935a:	48 c1 e6 10          	shl    $0x10,%rsi
    935e:	48 39 f1             	cmp    %rsi,%rcx
    9361:	0f 83 c6 fe ff ff    	jae    922d <f12+0x10ad>
    9367:	48 89 ce             	mov    %rcx,%rsi
    936a:	48 c1 ee 10          	shr    $0x10,%rsi
    936e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9372:	48 8b 35 9f 18 06 00 	mov    0x6189f(%rip),%rsi        # 6ac18 <fwp_heap+0x13f8>
    9379:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    937d:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9381:	48 85 ff             	test   %rdi,%rdi
    9384:	0f 84 a3 fe ff ff    	je     922d <f12+0x10ad>
    938a:	48 0f ba f0 3f       	btr    $0x3f,%rax
    938f:	49 89 c7             	mov    %rax,%r15
    9392:	e9 5e f7 ff ff       	jmp    8af5 <f12+0x975>
    9397:	be 68 00 00 00       	mov    $0x68,%esi
    939c:	bb 01 00 00 00       	mov    $0x1,%ebx
    93a1:	e9 95 ef ff ff       	jmp    833b <f12+0x1bb>
    93a6:	4c 89 f7             	mov    %r14,%rdi
    93a9:	e8 22 c4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    93ae:	e9 ab f1 ff ff       	jmp    855e <f12+0x3de>
    93b3:	48 89 df             	mov    %rbx,%rdi
    93b6:	e8 15 c4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    93bb:	e9 76 f5 ff ff       	jmp    8936 <f12+0x7b6>
    93c0:	4c 89 ff             	mov    %r15,%rdi
    93c3:	e8 08 c4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    93c8:	e9 8d fb ff ff       	jmp    8f5a <f12+0xdda>
    93cd:	e8 de c2 ff ff       	call   56b0 <fwp_rc_wide_dup>
    93d2:	e9 99 ee ff ff       	jmp    8270 <f12+0xf0>
    93d7:	49 89 dc             	mov    %rbx,%r12
    93da:	4c 89 c7             	mov    %r8,%rdi
    93dd:	31 f6                	xor    %esi,%esi
    93df:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    93e4:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    93e9:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    93f0:	00 
    93f1:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    93f6:	e8 b5 a0 ff ff       	call   34b0 <memset@plt>
    93fb:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9401:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9407:	49 89 c0             	mov    %rax,%r8
    940a:	e9 8b f3 ff ff       	jmp    879a <f12+0x61a>
    940f:	48 8d 3d fc 3c 00 00 	lea    0x3cfc(%rip),%rdi        # d112 <_IO_stdin_used+0x112>
    9416:	e8 e5 ab ff ff       	call   4000 <ad_raw_fail>
    941b:	45 31 ed             	xor    %r13d,%r13d
    941e:	e9 3a f8 ff ff       	jmp    8c5d <f12+0xadd>
    9423:	48 8d 3d 98 3d 00 00 	lea    0x3d98(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    942a:	e8 21 b0 ff ff       	call   4450 <fwp_trap>
    942f:	48 8d 3d d2 45 00 00 	lea    0x45d2(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    9436:	e8 15 b0 ff ff       	call   4450 <fwp_trap>
    943b:	e8 c0 a2 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9440:	48 8d 3d c9 46 00 00 	lea    0x46c9(%rip),%rdi        # db10 <_IO_stdin_used+0xb10>
    9447:	e8 04 b0 ff ff       	call   4450 <fwp_trap>
    944c:	45 31 f6             	xor    %r14d,%r14d
    944f:	e9 eb fd ff ff       	jmp    923f <f12+0x10bf>
    9454:	48 8d 3d 90 3d 00 00 	lea    0x3d90(%rip),%rdi        # d1eb <_IO_stdin_used+0x1eb>
    945b:	e8 f0 af ff ff       	call   4450 <fwp_trap>
    9460:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9467:	00 
    9468:	48 8b 3c 24          	mov    (%rsp),%rdi
    946c:	48 89 05 45 20 06 00 	mov    %rax,0x62045(%rip)        # 6b4b8 <fwp_cleanups>
    9473:	e8 e8 bd ff ff       	call   5260 <fwp_tape_buffers_release>
    9478:	48 8b 0d c1 7b 00 00 	mov    0x7bc1(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    947f:	ba 13 00 00 00       	mov    $0x13,%edx
    9484:	be 01 00 00 00       	mov    $0x1,%esi
    9489:	48 8d 3d 78 3b 00 00 	lea    0x3b78(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    9490:	e8 cb a1 ff ff       	call   3660 <fwrite@plt>
    9495:	31 ff                	xor    %edi,%edi
    9497:	e8 04 a1 ff ff       	call   35a0 <fflush@plt>
    949c:	bf 66 00 00 00       	mov    $0x66,%edi
    94a1:	e8 da a1 ff ff       	call   3680 <_Exit@plt>
    94a6:	48 8d 3d 58 3d 00 00 	lea    0x3d58(%rip),%rdi        # d205 <_IO_stdin_used+0x205>
    94ad:	e8 9e af ff ff       	call   4450 <fwp_trap>
    94b2:	48 8d 3d 76 3d 00 00 	lea    0x3d76(%rip),%rdi        # d22f <_IO_stdin_used+0x22f>
    94b9:	e8 92 af ff ff       	call   4450 <fwp_trap>
    94be:	48 8d 3d 4e 3d 00 00 	lea    0x3d4e(%rip),%rdi        # d213 <_IO_stdin_used+0x213>
    94c5:	e8 36 ab ff ff       	call   4000 <ad_raw_fail>
    94ca:	48 8d 3d 7f 45 00 00 	lea    0x457f(%rip),%rdi        # da50 <_IO_stdin_used+0xa50>
    94d1:	e8 7a af ff ff       	call   4450 <fwp_trap>
    94d6:	48 8d 3d d3 45 00 00 	lea    0x45d3(%rip),%rdi        # dab0 <_IO_stdin_used+0xab0>
    94dd:	e8 6e af ff ff       	call   4450 <fwp_trap>
    94e2:	e8 69 9f ff ff       	call   3450 <__stack_chk_fail@plt>
    94e7:	48 8d 3d f2 45 00 00 	lea    0x45f2(%rip),%rdi        # dae0 <_IO_stdin_used+0xae0>
    94ee:	e8 5d af ff ff       	call   4450 <fwp_trap>
    94f3:	66 90                	xchg   %ax,%ax
    94f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94fc:	00 00 00 00 

0000000000009500 <fwp_owned_entry12>:
    9500:	f3 0f 1e fa          	endbr64
    9504:	48 8b 3f             	mov    (%rdi),%rdi
    9507:	e9 74 ec ff ff       	jmp    8180 <f12>
    950c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009510 <e12>:
    9510:	f3 0f 1e fa          	endbr64
    9514:	53                   	push   %rbx
    9515:	48 8b 1f             	mov    (%rdi),%rbx
    9518:	48 89 df             	mov    %rbx,%rdi
    951b:	e8 20 da ff ff       	call   6f40 <fwp_rc_share>
    9520:	48 89 df             	mov    %rbx,%rdi
    9523:	e8 58 ec ff ff       	call   8180 <f12>
    9528:	48 89 c3             	mov    %rax,%rbx
    952b:	48 89 c7             	mov    %rax,%rdi
    952e:	e8 0d da ff ff       	call   6f40 <fwp_rc_share>
    9533:	48 89 d8             	mov    %rbx,%rax
    9536:	5b                   	pop    %rbx
    9537:	c3                   	ret
    9538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    953f:	00 

0000000000009540 <fwp_drop2>:
    9540:	48 8b 0d b1 16 06 00 	mov    0x616b1(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    9547:	48 89 f8             	mov    %rdi,%rax
    954a:	48 2b 05 7f 16 06 00 	sub    0x6167f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9551:	48 c1 e1 10          	shl    $0x10,%rcx
    9555:	48 39 c8             	cmp    %rcx,%rax
    9558:	0f 83 42 01 00 00    	jae    96a0 <fwp_drop2+0x160>
    955e:	48 83 ec 18          	sub    $0x18,%rsp
    9562:	48 89 fa             	mov    %rdi,%rdx
    9565:	4c 8d 05 b4 02 06 00 	lea    0x602b4(%rip),%r8        # 69820 <fwp_heap>
    956c:	48 89 c1             	mov    %rax,%rcx
    956f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9576:	48 c1 e9 10          	shr    $0x10,%rcx
    957a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    957e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9582:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9586:	48 85 c9             	test   %rcx,%rcx
    9589:	74 40                	je     95cb <fwp_drop2+0x8b>
    958b:	0f b6 3e             	movzbl (%rsi),%edi
    958e:	40 80 ff 02          	cmp    $0x2,%dil
    9592:	74 3c                	je     95d0 <fwp_drop2+0x90>
    9594:	40 80 ff 01          	cmp    $0x1,%dil
    9598:	75 31                	jne    95cb <fwp_drop2+0x8b>
    959a:	8b 7e 18             	mov    0x18(%rsi),%edi
    959d:	0f b7 c0             	movzwl %ax,%eax
    95a0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    95a3:	48 0f af c7          	imul   %rdi,%rax
    95a7:	48 c1 e8 20          	shr    $0x20,%rax
    95ab:	48 39 f0             	cmp    %rsi,%rax
    95ae:	73 1b                	jae    95cb <fwp_drop2+0x8b>
    95b0:	48 01 c1             	add    %rax,%rcx
    95b3:	0f b6 01             	movzbl (%rcx),%eax
    95b6:	84 c0                	test   %al,%al
    95b8:	74 11                	je     95cb <fwp_drop2+0x8b>
    95ba:	3c 01                	cmp    $0x1,%al
    95bc:	74 22                	je     95e0 <fwp_drop2+0xa0>
    95be:	3c ff                	cmp    $0xff,%al
    95c0:	0f 84 0a 01 00 00    	je     96d0 <fwp_drop2+0x190>
    95c6:	83 e8 01             	sub    $0x1,%eax
    95c9:	88 01                	mov    %al,(%rcx)
    95cb:	48 83 c4 18          	add    $0x18,%rsp
    95cf:	c3                   	ret
    95d0:	66 85 c0             	test   %ax,%ax
    95d3:	74 de                	je     95b3 <fwp_drop2+0x73>
    95d5:	48 83 c4 18          	add    $0x18,%rsp
    95d9:	c3                   	ret
    95da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95e0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    95e4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    95eb:	48 89 f8             	mov    %rdi,%rax
    95ee:	48 c1 e1 10          	shl    $0x10,%rcx
    95f2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    95f9:	48 39 c8             	cmp    %rcx,%rax
    95fc:	73 62                	jae    9660 <fwp_drop2+0x120>
    95fe:	48 89 c1             	mov    %rax,%rcx
    9601:	48 c1 e9 10          	shr    $0x10,%rcx
    9605:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9609:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    960d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9611:	48 85 c9             	test   %rcx,%rcx
    9614:	74 4a                	je     9660 <fwp_drop2+0x120>
    9616:	44 0f b6 0e          	movzbl (%rsi),%r9d
    961a:	41 80 f9 02          	cmp    $0x2,%r9b
    961e:	0f 84 9c 00 00 00    	je     96c0 <fwp_drop2+0x180>
    9624:	41 80 f9 01          	cmp    $0x1,%r9b
    9628:	75 36                	jne    9660 <fwp_drop2+0x120>
    962a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    962e:	0f b7 c0             	movzwl %ax,%eax
    9631:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9634:	49 0f af c1          	imul   %r9,%rax
    9638:	48 c1 e8 20          	shr    $0x20,%rax
    963c:	48 39 f0             	cmp    %rsi,%rax
    963f:	73 1f                	jae    9660 <fwp_drop2+0x120>
    9641:	48 01 c1             	add    %rax,%rcx
    9644:	0f b6 01             	movzbl (%rcx),%eax
    9647:	84 c0                	test   %al,%al
    9649:	74 15                	je     9660 <fwp_drop2+0x120>
    964b:	3c 01                	cmp    $0x1,%al
    964d:	74 59                	je     96a8 <fwp_drop2+0x168>
    964f:	3c ff                	cmp    $0xff,%al
    9651:	0f 84 ef 00 00 00    	je     9746 <fwp_drop2+0x206>
    9657:	83 e8 01             	sub    $0x1,%eax
    965a:	88 01                	mov    %al,(%rcx)
    965c:	0f 1f 40 00          	nopl   0x0(%rax)
    9660:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9664:	48 89 d7             	mov    %rdx,%rdi
    9667:	48 89 0c 24          	mov    %rcx,(%rsp)
    966b:	e8 50 d9 ff ff       	call   6fc0 <fwp_rc_free_arr>
    9670:	4c 8d 05 a9 01 06 00 	lea    0x601a9(%rip),%r8        # 69820 <fwp_heap>
    9677:	48 8b 04 24          	mov    (%rsp),%rax
    967b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9682:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9689:	48 c1 e2 10          	shl    $0x10,%rdx
    968d:	48 39 d0             	cmp    %rdx,%rax
    9690:	0f 83 35 ff ff ff    	jae    95cb <fwp_drop2+0x8b>
    9696:	48 8b 14 24          	mov    (%rsp),%rdx
    969a:	e9 cd fe ff ff       	jmp    956c <fwp_drop2+0x2c>
    969f:	90                   	nop
    96a0:	c3                   	ret
    96a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    96a8:	48 89 14 24          	mov    %rdx,(%rsp)
    96ac:	e8 0f d9 ff ff       	call   6fc0 <fwp_rc_free_arr>
    96b1:	48 8b 14 24          	mov    (%rsp),%rdx
    96b5:	eb a9                	jmp    9660 <fwp_drop2+0x120>
    96b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96be:	00 00 
    96c0:	66 85 c0             	test   %ax,%ax
    96c3:	75 9b                	jne    9660 <fwp_drop2+0x120>
    96c5:	e9 7a ff ff ff       	jmp    9644 <fwp_drop2+0x104>
    96ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    96d0:	48 89 c8             	mov    %rcx,%rax
    96d3:	48 c1 e8 11          	shr    $0x11,%rax
    96d7:	48 31 c8             	xor    %rcx,%rax
    96da:	48 89 c2             	mov    %rax,%rdx
    96dd:	48 c1 ea 09          	shr    $0x9,%rdx
    96e1:	48 31 d0             	xor    %rdx,%rax
    96e4:	0f b6 d0             	movzbl %al,%edx
    96e7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    96ee:	00 
    96ef:	48 85 c0             	test   %rax,%rax
    96f2:	75 19                	jne    970d <fwp_drop2+0x1cd>
    96f4:	e9 d3 00 00 00       	jmp    97cc <fwp_drop2+0x28c>
    96f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9700:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9704:	48 85 c0             	test   %rax,%rax
    9707:	0f 84 bf 00 00 00    	je     97cc <fwp_drop2+0x28c>
    970d:	48 89 c2             	mov    %rax,%rdx
    9710:	48 39 08             	cmp    %rcx,(%rax)
    9713:	75 eb                	jne    9700 <fwp_drop2+0x1c0>
    9715:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9719:	48 83 ea 01          	sub    $0x1,%rdx
    971d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9721:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9728:	0f 85 9d fe ff ff    	jne    95cb <fwp_drop2+0x8b>
    972e:	48 89 cf             	mov    %rcx,%rdi
    9731:	48 89 0c 24          	mov    %rcx,(%rsp)
    9735:	e8 96 c0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    973a:	48 8b 0c 24          	mov    (%rsp),%rcx
    973e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9741:	e9 85 fe ff ff       	jmp    95cb <fwp_drop2+0x8b>
    9746:	48 89 ce             	mov    %rcx,%rsi
    9749:	48 c1 ee 11          	shr    $0x11,%rsi
    974d:	48 31 ce             	xor    %rcx,%rsi
    9750:	48 89 f0             	mov    %rsi,%rax
    9753:	48 c1 e8 09          	shr    $0x9,%rax
    9757:	48 31 c6             	xor    %rax,%rsi
    975a:	40 0f b6 f6          	movzbl %sil,%esi
    975e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9765:	00 
    9766:	48 85 c0             	test   %rax,%rax
    9769:	75 1e                	jne    9789 <fwp_drop2+0x249>
    976b:	eb 5f                	jmp    97cc <fwp_drop2+0x28c>
    976d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9774:	00 
    9775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    977c:	00 00 00 00 
    9780:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9784:	48 85 c0             	test   %rax,%rax
    9787:	74 43                	je     97cc <fwp_drop2+0x28c>
    9789:	48 89 c6             	mov    %rax,%rsi
    978c:	48 39 08             	cmp    %rcx,(%rax)
    978f:	75 ef                	jne    9780 <fwp_drop2+0x240>
    9791:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9795:	48 83 ee 01          	sub    $0x1,%rsi
    9799:	48 89 70 08          	mov    %rsi,0x8(%rax)
    979d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    97a4:	0f 85 b6 fe ff ff    	jne    9660 <fwp_drop2+0x120>
    97aa:	48 89 cf             	mov    %rcx,%rdi
    97ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    97b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    97b6:	e8 15 c0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    97bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    97bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    97c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    97c7:	e9 94 fe ff ff       	jmp    9660 <fwp_drop2+0x120>
    97cc:	48 8d 3d 0d 42 00 00 	lea    0x420d(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    97d3:	e8 78 ac ff ff       	call   4450 <fwp_trap>
    97d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97df:	00 

00000000000097e0 <fwp_arg_drop23>:
    97e0:	f3 0f 1e fa          	endbr64
    97e4:	85 f6                	test   %esi,%esi
    97e6:	75 04                	jne    97ec <fwp_arg_drop23+0xc>
    97e8:	85 d2                	test   %edx,%edx
    97ea:	75 04                	jne    97f0 <fwp_arg_drop23+0x10>
    97ec:	c3                   	ret
    97ed:	0f 1f 00             	nopl   (%rax)
    97f0:	48 8b 3f             	mov    (%rdi),%rdi
    97f3:	e9 48 fd ff ff       	jmp    9540 <fwp_drop2>
    97f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97ff:	00 

0000000000009800 <f23>:
    9800:	41 57                	push   %r15
    9802:	41 56                	push   %r14
    9804:	41 55                	push   %r13
    9806:	41 54                	push   %r12
    9808:	55                   	push   %rbp
    9809:	53                   	push   %rbx
    980a:	48 83 ec 38          	sub    $0x38,%rsp
    980e:	48 8b 15 e3 13 06 00 	mov    0x613e3(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    9815:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    981a:	48 c1 e2 10          	shl    $0x10,%rdx
    981e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    9825:	00 00 
    9827:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    982c:	48 8b 0d 9d 13 06 00 	mov    0x6139d(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    9833:	48 85 ff             	test   %rdi,%rdi
    9836:	0f 84 5e 03 00 00    	je     9b9a <f23+0x39a>
    983c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9841:	4c 8b 68 10          	mov    0x10(%rax),%r13
    9845:	4c 89 e8             	mov    %r13,%rax
    9848:	48 29 c8             	sub    %rcx,%rax
    984b:	48 39 d0             	cmp    %rdx,%rax
    984e:	0f 83 2c 03 00 00    	jae    9b80 <f23+0x380>
    9854:	48 89 c2             	mov    %rax,%rdx
    9857:	48 c1 ea 10          	shr    $0x10,%rdx
    985b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    985f:	48 8b 15 b2 13 06 00 	mov    0x613b2(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9866:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    986a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    986e:	48 85 ff             	test   %rdi,%rdi
    9871:	0f 84 09 03 00 00    	je     9b80 <f23+0x380>
    9877:	0f b6 0a             	movzbl (%rdx),%ecx
    987a:	80 f9 02             	cmp    $0x2,%cl
    987d:	0f 84 8d 02 00 00    	je     9b10 <f23+0x310>
    9883:	80 f9 01             	cmp    $0x1,%cl
    9886:	75 24                	jne    98ac <f23+0xac>
    9888:	8b 4a 18             	mov    0x18(%rdx),%ecx
    988b:	0f b7 c0             	movzwl %ax,%eax
    988e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9891:	48 0f af c1          	imul   %rcx,%rax
    9895:	48 c1 e8 20          	shr    $0x20,%rax
    9899:	48 39 d0             	cmp    %rdx,%rax
    989c:	73 0e                	jae    98ac <f23+0xac>
    989e:	48 01 c7             	add    %rax,%rdi
    98a1:	0f b6 07             	movzbl (%rdi),%eax
    98a4:	84 c0                	test   %al,%al
    98a6:	0f 85 84 02 00 00    	jne    9b30 <f23+0x330>
    98ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    98b1:	48 8b 40 10          	mov    0x10(%rax),%rax
    98b5:	ba 01 00 00 00       	mov    $0x1,%edx
    98ba:	48 85 c0             	test   %rax,%rax
    98bd:	74 0e                	je     98cd <f23+0xcd>
    98bf:	90                   	nop
    98c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    98c4:	48 83 c2 01          	add    $0x1,%rdx
    98c8:	48 85 c0             	test   %rax,%rax
    98cb:	75 f3                	jne    98c0 <f23+0xc0>
    98cd:	4d 85 ed             	test   %r13,%r13
    98d0:	0f 84 da 02 00 00    	je     9bb0 <f23+0x3b0>
    98d6:	4c 89 e8             	mov    %r13,%rax
    98d9:	31 db                	xor    %ebx,%ebx
    98db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    98e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    98e4:	48 83 c3 01          	add    $0x1,%rbx
    98e8:	48 85 c0             	test   %rax,%rax
    98eb:	75 f3                	jne    98e0 <f23+0xe0>
    98ed:	48 39 d3             	cmp    %rdx,%rbx
    98f0:	48 0f 47 da          	cmova  %rdx,%rbx
    98f4:	48 89 d8             	mov    %rbx,%rax
    98f7:	48 c1 e8 3c          	shr    $0x3c,%rax
    98fb:	0f 85 bd 03 00 00    	jne    9cbe <f23+0x4be>
    9901:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9905:	be 02 00 00 00       	mov    $0x2,%esi
    990a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9911:	00 
    9912:	e8 f9 c5 ff ff       	call   5f10 <fwp_heap_alloc>
    9917:	48 89 28             	mov    %rbp,(%rax)
    991a:	48 8b 15 d7 12 06 00 	mov    0x612d7(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    9921:	49 89 c4             	mov    %rax,%r12
    9924:	48 2b 05 a5 12 06 00 	sub    0x612a5(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    992b:	48 c1 e2 10          	shl    $0x10,%rdx
    992f:	48 39 d0             	cmp    %rdx,%rax
    9932:	73 57                	jae    998b <f23+0x18b>
    9934:	48 89 c2             	mov    %rax,%rdx
    9937:	48 c1 ea 10          	shr    $0x10,%rdx
    993b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    993f:	48 8b 15 d2 12 06 00 	mov    0x612d2(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9946:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    994a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    994e:	48 85 ed             	test   %rbp,%rbp
    9951:	74 38                	je     998b <f23+0x18b>
    9953:	0f b6 0a             	movzbl (%rdx),%ecx
    9956:	80 f9 02             	cmp    $0x2,%cl
    9959:	0f 84 11 02 00 00    	je     9b70 <f23+0x370>
    995f:	80 f9 01             	cmp    $0x1,%cl
    9962:	75 27                	jne    998b <f23+0x18b>
    9964:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9967:	0f b7 c0             	movzwl %ax,%eax
    996a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    996d:	48 0f af c1          	imul   %rcx,%rax
    9971:	48 c1 e8 20          	shr    $0x20,%rax
    9975:	48 39 d0             	cmp    %rdx,%rax
    9978:	73 11                	jae    998b <f23+0x18b>
    997a:	48 01 c5             	add    %rax,%rbp
    997d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9981:	0f 84 97 02 00 00    	je     9c1e <f23+0x41e>
    9987:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    998b:	48 85 db             	test   %rbx,%rbx
    998e:	74 5d                	je     99ed <f23+0x1ed>
    9990:	48 c1 e3 04          	shl    $0x4,%rbx
    9994:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    9999:	4c 89 e5             	mov    %r12,%rbp
    999c:	4d 89 ef             	mov    %r13,%r15
    999f:	4c 01 e3             	add    %r12,%rbx
    99a2:	0f 1f 00             	nopl   (%rax)
    99a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99ac:	00 00 00 00 
    99b0:	49 8b 46 08          	mov    0x8(%r14),%rax
    99b4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    99b8:	48 83 c5 10          	add    $0x10,%rbp
    99bc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    99c1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    99c5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    99c9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    99ce:	e8 7d cd ff ff       	call   6750 <w107>
    99d3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    99d8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    99dc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    99e0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    99e4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    99e8:	48 39 eb             	cmp    %rbp,%rbx
    99eb:	75 c3                	jne    99b0 <f23+0x1b0>
    99ed:	4c 89 ef             	mov    %r13,%rdi
    99f0:	31 db                	xor    %ebx,%ebx
    99f2:	e8 49 fb ff ff       	call   9540 <fwp_drop2>
    99f7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    99fc:	e8 3f fb ff ff       	call   9540 <fwp_drop2>
    9a01:	4d 8b 2c 24          	mov    (%r12),%r13
    9a05:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9a09:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    9a10:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    9a17:	4d 85 ed             	test   %r13,%r13
    9a1a:	74 32                	je     9a4e <f23+0x24e>
    9a1c:	0f 1f 40 00          	nopl   0x0(%rax)
    9a20:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    9a27:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    9a2c:	48 83 c3 02          	add    $0x2,%rbx
    9a30:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9a36:	e8 95 cb ff ff       	call   65d0 <f128.constprop.0>
    9a3b:	4c 39 eb             	cmp    %r13,%rbx
    9a3e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    9a44:	48 89 c7             	mov    %rax,%rdi
    9a47:	72 d7                	jb     9a20 <f23+0x220>
    9a49:	66 49 0f 7e c5       	movq   %xmm0,%r13
    9a4e:	4c 89 e7             	mov    %r12,%rdi
    9a51:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9a56:	e8 a5 e4 ff ff       	call   7f00 <fwp_drop4>
    9a5b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9a60:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    9a65:	31 ff                	xor    %edi,%edi
    9a67:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    9a6c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9a71:	e8 da d2 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    9a76:	48 8b 15 7b 11 06 00 	mov    0x6117b(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    9a7d:	48 89 c5             	mov    %rax,%rbp
    9a80:	48 2b 05 49 11 06 00 	sub    0x61149(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9a87:	48 c1 e2 10          	shl    $0x10,%rdx
    9a8b:	48 39 d0             	cmp    %rdx,%rax
    9a8e:	73 55                	jae    9ae5 <f23+0x2e5>
    9a90:	48 89 c2             	mov    %rax,%rdx
    9a93:	48 c1 ea 10          	shr    $0x10,%rdx
    9a97:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a9b:	48 8b 15 76 11 06 00 	mov    0x61176(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9aa2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9aa6:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9aaa:	48 85 db             	test   %rbx,%rbx
    9aad:	74 36                	je     9ae5 <f23+0x2e5>
    9aaf:	0f b6 0a             	movzbl (%rdx),%ecx
    9ab2:	80 f9 02             	cmp    $0x2,%cl
    9ab5:	0f 84 a5 00 00 00    	je     9b60 <f23+0x360>
    9abb:	80 f9 01             	cmp    $0x1,%cl
    9abe:	75 25                	jne    9ae5 <f23+0x2e5>
    9ac0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ac3:	0f b7 c0             	movzwl %ax,%eax
    9ac6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ac9:	48 0f af c1          	imul   %rcx,%rax
    9acd:	48 c1 e8 20          	shr    $0x20,%rax
    9ad1:	48 39 d0             	cmp    %rdx,%rax
    9ad4:	73 0f                	jae    9ae5 <f23+0x2e5>
    9ad6:	48 01 c3             	add    %rax,%rbx
    9ad9:	80 3b ff             	cmpb   $0xff,(%rbx)
    9adc:	0f 84 2f 01 00 00    	je     9c11 <f23+0x411>
    9ae2:	c6 03 01             	movb   $0x1,(%rbx)
    9ae5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9aea:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9af1:	00 00 
    9af3:	0f 85 d1 01 00 00    	jne    9cca <f23+0x4ca>
    9af9:	48 83 c4 38          	add    $0x38,%rsp
    9afd:	48 89 e8             	mov    %rbp,%rax
    9b00:	5b                   	pop    %rbx
    9b01:	5d                   	pop    %rbp
    9b02:	41 5c                	pop    %r12
    9b04:	41 5d                	pop    %r13
    9b06:	41 5e                	pop    %r14
    9b08:	41 5f                	pop    %r15
    9b0a:	c3                   	ret
    9b0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b10:	66 85 c0             	test   %ax,%ax
    9b13:	0f 85 93 fd ff ff    	jne    98ac <f23+0xac>
    9b19:	0f b6 07             	movzbl (%rdi),%eax
    9b1c:	84 c0                	test   %al,%al
    9b1e:	0f 84 88 fd ff ff    	je     98ac <f23+0xac>
    9b24:	90                   	nop
    9b25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b2c:	00 00 00 00 
    9b30:	8b 15 b2 19 06 00    	mov    0x619b2(%rip),%edx        # 6b4e8 <iteration_active>
    9b36:	85 d2                	test   %edx,%edx
    9b38:	75 56                	jne    9b90 <f23+0x390>
    9b3a:	3c fd                	cmp    $0xfd,%al
    9b3c:	0f 87 4b 01 00 00    	ja     9c8d <f23+0x48d>
    9b42:	83 c0 01             	add    $0x1,%eax
    9b45:	88 07                	mov    %al,(%rdi)
    9b47:	31 d2                	xor    %edx,%edx
    9b49:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    9b4f:	0f 85 57 fd ff ff    	jne    98ac <f23+0xac>
    9b55:	e9 73 fd ff ff       	jmp    98cd <f23+0xcd>
    9b5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b60:	66 85 c0             	test   %ax,%ax
    9b63:	0f 85 7c ff ff ff    	jne    9ae5 <f23+0x2e5>
    9b69:	e9 6b ff ff ff       	jmp    9ad9 <f23+0x2d9>
    9b6e:	66 90                	xchg   %ax,%ax
    9b70:	66 85 c0             	test   %ax,%ax
    9b73:	0f 85 12 fe ff ff    	jne    998b <f23+0x18b>
    9b79:	e9 ff fd ff ff       	jmp    997d <f23+0x17d>
    9b7e:	66 90                	xchg   %ax,%ax
    9b80:	4c 89 e8             	mov    %r13,%rax
    9b83:	e9 2d fd ff ff       	jmp    98b5 <f23+0xb5>
    9b88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9b8f:	00 
    9b90:	48 83 05 38 19 06 00 	addq   $0x1,0x61938(%rip)        # 6b4d0 <iteration_retains>
    9b97:	01 
    9b98:	eb a0                	jmp    9b3a <f23+0x33a>
    9b9a:	48 f7 d9             	neg    %rcx
    9b9d:	48 39 d1             	cmp    %rdx,%rcx
    9ba0:	0f 82 85 00 00 00    	jb     9c2b <f23+0x42b>
    9ba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9bad:	00 00 00 
    9bb0:	be 02 00 00 00       	mov    $0x2,%esi
    9bb5:	bf 08 00 00 00       	mov    $0x8,%edi
    9bba:	e8 51 c3 ff ff       	call   5f10 <fwp_heap_alloc>
    9bbf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9bc6:	48 8b 15 2b 10 06 00 	mov    0x6102b(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    9bcd:	49 89 c4             	mov    %rax,%r12
    9bd0:	48 2b 05 f9 0f 06 00 	sub    0x60ff9(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9bd7:	48 c1 e2 10          	shl    $0x10,%rdx
    9bdb:	48 39 d0             	cmp    %rdx,%rax
    9bde:	0f 83 b3 00 00 00    	jae    9c97 <f23+0x497>
    9be4:	48 89 c2             	mov    %rax,%rdx
    9be7:	45 31 ed             	xor    %r13d,%r13d
    9bea:	48 c1 ea 10          	shr    $0x10,%rdx
    9bee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bf2:	48 8b 15 1f 10 06 00 	mov    0x6101f(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9bf9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bfd:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9c01:	48 85 ed             	test   %rbp,%rbp
    9c04:	0f 84 e3 fd ff ff    	je     99ed <f23+0x1ed>
    9c0a:	31 db                	xor    %ebx,%ebx
    9c0c:	e9 42 fd ff ff       	jmp    9953 <f23+0x153>
    9c11:	48 89 df             	mov    %rbx,%rdi
    9c14:	e8 b7 bb ff ff       	call   57d0 <fwp_rc_forget_slot>
    9c19:	e9 c4 fe ff ff       	jmp    9ae2 <f23+0x2e2>
    9c1e:	48 89 ef             	mov    %rbp,%rdi
    9c21:	e8 aa bb ff ff       	call   57d0 <fwp_rc_forget_slot>
    9c26:	e9 5c fd ff ff       	jmp    9987 <f23+0x187>
    9c2b:	48 89 c8             	mov    %rcx,%rax
    9c2e:	48 c1 e8 10          	shr    $0x10,%rax
    9c32:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9c36:	48 8b 05 db 0f 06 00 	mov    0x60fdb(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    9c3d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9c41:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9c45:	48 85 ff             	test   %rdi,%rdi
    9c48:	0f 84 62 ff ff ff    	je     9bb0 <f23+0x3b0>
    9c4e:	0f b6 02             	movzbl (%rdx),%eax
    9c51:	3c 02                	cmp    $0x2,%al
    9c53:	74 4a                	je     9c9f <f23+0x49f>
    9c55:	3c 01                	cmp    $0x1,%al
    9c57:	0f 85 53 ff ff ff    	jne    9bb0 <f23+0x3b0>
    9c5d:	0f b7 c1             	movzwl %cx,%eax
    9c60:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c63:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c66:	48 0f af c1          	imul   %rcx,%rax
    9c6a:	48 c1 e8 20          	shr    $0x20,%rax
    9c6e:	48 39 d0             	cmp    %rdx,%rax
    9c71:	0f 83 39 ff ff ff    	jae    9bb0 <f23+0x3b0>
    9c77:	48 01 c7             	add    %rax,%rdi
    9c7a:	0f b6 07             	movzbl (%rdi),%eax
    9c7d:	84 c0                	test   %al,%al
    9c7f:	0f 84 2b ff ff ff    	je     9bb0 <f23+0x3b0>
    9c85:	45 31 ed             	xor    %r13d,%r13d
    9c88:	e9 a3 fe ff ff       	jmp    9b30 <f23+0x330>
    9c8d:	e8 1e ba ff ff       	call   56b0 <fwp_rc_wide_dup>
    9c92:	e9 b0 fe ff ff       	jmp    9b47 <f23+0x347>
    9c97:	45 31 ed             	xor    %r13d,%r13d
    9c9a:	e9 4e fd ff ff       	jmp    99ed <f23+0x1ed>
    9c9f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    9ca5:	49 89 cd             	mov    %rcx,%r13
    9ca8:	0f 85 02 ff ff ff    	jne    9bb0 <f23+0x3b0>
    9cae:	0f b6 07             	movzbl (%rdi),%eax
    9cb1:	84 c0                	test   %al,%al
    9cb3:	0f 85 77 fe ff ff    	jne    9b30 <f23+0x330>
    9cb9:	e9 f2 fe ff ff       	jmp    9bb0 <f23+0x3b0>
    9cbe:	48 8d 3d 40 35 00 00 	lea    0x3540(%rip),%rdi        # d205 <_IO_stdin_used+0x205>
    9cc5:	e8 86 a7 ff ff       	call   4450 <fwp_trap>
    9cca:	e8 81 97 ff ff       	call   3450 <__stack_chk_fail@plt>
    9ccf:	90                   	nop

0000000000009cd0 <fwp_owned_entry23>:
    9cd0:	f3 0f 1e fa          	endbr64
    9cd4:	48 8b 3f             	mov    (%rdi),%rdi
    9cd7:	e9 24 fb ff ff       	jmp    9800 <f23>
    9cdc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009ce0 <e23>:
    9ce0:	f3 0f 1e fa          	endbr64
    9ce4:	53                   	push   %rbx
    9ce5:	48 8b 1f             	mov    (%rdi),%rbx
    9ce8:	48 89 df             	mov    %rbx,%rdi
    9ceb:	e8 50 d2 ff ff       	call   6f40 <fwp_rc_share>
    9cf0:	48 89 df             	mov    %rbx,%rdi
    9cf3:	e8 08 fb ff ff       	call   9800 <f23>
    9cf8:	48 89 c3             	mov    %rax,%rbx
    9cfb:	48 89 c7             	mov    %rax,%rdi
    9cfe:	e8 3d d2 ff ff       	call   6f40 <fwp_rc_share>
    9d03:	48 89 d8             	mov    %rbx,%rax
    9d06:	5b                   	pop    %rbx
    9d07:	c3                   	ret
    9d08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d0f:	00 

0000000000009d10 <fwp_args12>:
    9d10:	f3 0f 1e fa          	endbr64
    9d14:	85 d2                	test   %edx,%edx
    9d16:	74 04                	je     9d1c <fwp_args12+0xc>
    9d18:	85 f6                	test   %esi,%esi
    9d1a:	74 04                	je     9d20 <fwp_args12+0x10>
    9d1c:	c3                   	ret
    9d1d:	0f 1f 00             	nopl   (%rax)
    9d20:	48 8b 15 d1 0e 06 00 	mov    0x60ed1(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    9d27:	48 8b 07             	mov    (%rdi),%rax
    9d2a:	48 2b 05 9f 0e 06 00 	sub    0x60e9f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9d31:	48 c1 e2 10          	shl    $0x10,%rdx
    9d35:	48 39 d0             	cmp    %rdx,%rax
    9d38:	73 e2                	jae    9d1c <fwp_args12+0xc>
    9d3a:	48 89 c2             	mov    %rax,%rdx
    9d3d:	48 c1 ea 10          	shr    $0x10,%rdx
    9d41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d45:	48 8b 15 cc 0e 06 00 	mov    0x60ecc(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9d4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d50:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9d54:	48 85 ff             	test   %rdi,%rdi
    9d57:	74 c3                	je     9d1c <fwp_args12+0xc>
    9d59:	0f b6 0a             	movzbl (%rdx),%ecx
    9d5c:	80 f9 02             	cmp    $0x2,%cl
    9d5f:	74 4f                	je     9db0 <fwp_args12+0xa0>
    9d61:	80 f9 01             	cmp    $0x1,%cl
    9d64:	75 b6                	jne    9d1c <fwp_args12+0xc>
    9d66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d69:	0f b7 c0             	movzwl %ax,%eax
    9d6c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d6f:	48 0f af c1          	imul   %rcx,%rax
    9d73:	48 c1 e8 20          	shr    $0x20,%rax
    9d77:	48 39 d0             	cmp    %rdx,%rax
    9d7a:	73 a0                	jae    9d1c <fwp_args12+0xc>
    9d7c:	48 01 c7             	add    %rax,%rdi
    9d7f:	0f b6 07             	movzbl (%rdi),%eax
    9d82:	84 c0                	test   %al,%al
    9d84:	74 96                	je     9d1c <fwp_args12+0xc>
    9d86:	8b 15 5c 17 06 00    	mov    0x6175c(%rip),%edx        # 6b4e8 <iteration_active>
    9d8c:	85 d2                	test   %edx,%edx
    9d8e:	75 10                	jne    9da0 <fwp_args12+0x90>
    9d90:	3c fd                	cmp    $0xfd,%al
    9d92:	77 22                	ja     9db6 <fwp_args12+0xa6>
    9d94:	83 c0 01             	add    $0x1,%eax
    9d97:	88 07                	mov    %al,(%rdi)
    9d99:	c3                   	ret
    9d9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9da0:	48 83 05 28 17 06 00 	addq   $0x1,0x61728(%rip)        # 6b4d0 <iteration_retains>
    9da7:	01 
    9da8:	eb e6                	jmp    9d90 <fwp_args12+0x80>
    9daa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9db0:	66 85 c0             	test   %ax,%ax
    9db3:	74 ca                	je     9d7f <fwp_args12+0x6f>
    9db5:	c3                   	ret
    9db6:	e9 f5 b8 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9dbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000009dc0 <fwp_args23>:
    9dc0:	f3 0f 1e fa          	endbr64
    9dc4:	85 d2                	test   %edx,%edx
    9dc6:	74 04                	je     9dcc <fwp_args23+0xc>
    9dc8:	85 f6                	test   %esi,%esi
    9dca:	74 04                	je     9dd0 <fwp_args23+0x10>
    9dcc:	c3                   	ret
    9dcd:	0f 1f 00             	nopl   (%rax)
    9dd0:	48 8b 15 21 0e 06 00 	mov    0x60e21(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    9dd7:	48 8b 07             	mov    (%rdi),%rax
    9dda:	48 2b 05 ef 0d 06 00 	sub    0x60def(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9de1:	48 c1 e2 10          	shl    $0x10,%rdx
    9de5:	48 39 d0             	cmp    %rdx,%rax
    9de8:	73 e2                	jae    9dcc <fwp_args23+0xc>
    9dea:	48 89 c2             	mov    %rax,%rdx
    9ded:	48 c1 ea 10          	shr    $0x10,%rdx
    9df1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9df5:	48 8b 15 1c 0e 06 00 	mov    0x60e1c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9dfc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e00:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9e04:	48 85 ff             	test   %rdi,%rdi
    9e07:	74 c3                	je     9dcc <fwp_args23+0xc>
    9e09:	0f b6 0a             	movzbl (%rdx),%ecx
    9e0c:	80 f9 02             	cmp    $0x2,%cl
    9e0f:	74 4f                	je     9e60 <fwp_args23+0xa0>
    9e11:	80 f9 01             	cmp    $0x1,%cl
    9e14:	75 b6                	jne    9dcc <fwp_args23+0xc>
    9e16:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e19:	0f b7 c0             	movzwl %ax,%eax
    9e1c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e1f:	48 0f af c1          	imul   %rcx,%rax
    9e23:	48 c1 e8 20          	shr    $0x20,%rax
    9e27:	48 39 d0             	cmp    %rdx,%rax
    9e2a:	73 a0                	jae    9dcc <fwp_args23+0xc>
    9e2c:	48 01 c7             	add    %rax,%rdi
    9e2f:	0f b6 07             	movzbl (%rdi),%eax
    9e32:	84 c0                	test   %al,%al
    9e34:	74 96                	je     9dcc <fwp_args23+0xc>
    9e36:	8b 15 ac 16 06 00    	mov    0x616ac(%rip),%edx        # 6b4e8 <iteration_active>
    9e3c:	85 d2                	test   %edx,%edx
    9e3e:	75 10                	jne    9e50 <fwp_args23+0x90>
    9e40:	3c fd                	cmp    $0xfd,%al
    9e42:	77 22                	ja     9e66 <fwp_args23+0xa6>
    9e44:	83 c0 01             	add    $0x1,%eax
    9e47:	88 07                	mov    %al,(%rdi)
    9e49:	c3                   	ret
    9e4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e50:	48 83 05 78 16 06 00 	addq   $0x1,0x61678(%rip)        # 6b4d0 <iteration_retains>
    9e57:	01 
    9e58:	eb e6                	jmp    9e40 <fwp_args23+0x80>
    9e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e60:	66 85 c0             	test   %ax,%ax
    9e63:	74 ca                	je     9e2f <fwp_args23+0x6f>
    9e65:	c3                   	ret
    9e66:	e9 45 b8 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9e6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000009e70 <fwp_caps12>:
    9e70:	f3 0f 1e fa          	endbr64
    9e74:	48 83 ec 18          	sub    $0x18,%rsp
    9e78:	48 89 f8             	mov    %rdi,%rax
    9e7b:	8b 7f 04             	mov    0x4(%rdi),%edi
    9e7e:	85 ff                	test   %edi,%edi
    9e80:	0f 84 9a 00 00 00    	je     9f20 <fwp_caps12+0xb0>
    9e86:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9e8a:	85 f6                	test   %esi,%esi
    9e8c:	0f 85 9e 00 00 00    	jne    9f30 <fwp_caps12+0xc0>
    9e92:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9e97:	e8 54 d4 ff ff       	call   72f0 <fwp_drop0>
    9e9c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9ea1:	48 8b 0d 50 0d 06 00 	mov    0x60d50(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    9ea8:	48 89 c2             	mov    %rax,%rdx
    9eab:	48 2b 15 1e 0d 06 00 	sub    0x60d1e(%rip),%rdx        # 6abd0 <fwp_heap+0x13b0>
    9eb2:	48 c1 e1 10          	shl    $0x10,%rcx
    9eb6:	48 39 ca             	cmp    %rcx,%rdx
    9eb9:	73 6d                	jae    9f28 <fwp_caps12+0xb8>
    9ebb:	48 89 d1             	mov    %rdx,%rcx
    9ebe:	48 c1 e9 10          	shr    $0x10,%rcx
    9ec2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9ec6:	48 8b 0d 4b 0d 06 00 	mov    0x60d4b(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    9ecd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9ed1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9ed5:	48 85 f6             	test   %rsi,%rsi
    9ed8:	74 4e                	je     9f28 <fwp_caps12+0xb8>
    9eda:	0f b6 39             	movzbl (%rcx),%edi
    9edd:	40 80 ff 02          	cmp    $0x2,%dil
    9ee1:	0f 84 c9 00 00 00    	je     9fb0 <fwp_caps12+0x140>
    9ee7:	40 80 ff 01          	cmp    $0x1,%dil
    9eeb:	75 3b                	jne    9f28 <fwp_caps12+0xb8>
    9eed:	8b 79 18             	mov    0x18(%rcx),%edi
    9ef0:	0f b7 d2             	movzwl %dx,%edx
    9ef3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9ef6:	48 0f af d7          	imul   %rdi,%rdx
    9efa:	48 c1 ea 20          	shr    $0x20,%rdx
    9efe:	48 39 ca             	cmp    %rcx,%rdx
    9f01:	73 25                	jae    9f28 <fwp_caps12+0xb8>
    9f03:	48 01 d6             	add    %rdx,%rsi
    9f06:	80 3e 01             	cmpb   $0x1,(%rsi)
    9f09:	75 1d                	jne    9f28 <fwp_caps12+0xb8>
    9f0b:	48 89 c7             	mov    %rax,%rdi
    9f0e:	48 83 c4 18          	add    $0x18,%rsp
    9f12:	e9 f9 ba ff ff       	jmp    5a10 <fwp_mem_free>
    9f17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f1e:	00 00 
    9f20:	85 f6                	test   %esi,%esi
    9f22:	0f 84 79 ff ff ff    	je     9ea1 <fwp_caps12+0x31>
    9f28:	48 83 c4 18          	add    $0x18,%rsp
    9f2c:	c3                   	ret
    9f2d:	0f 1f 00             	nopl   (%rax)
    9f30:	48 8b 05 c1 0c 06 00 	mov    0x60cc1(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    9f37:	48 2b 3d 92 0c 06 00 	sub    0x60c92(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    9f3e:	48 c1 e0 10          	shl    $0x10,%rax
    9f42:	48 39 c7             	cmp    %rax,%rdi
    9f45:	73 e1                	jae    9f28 <fwp_caps12+0xb8>
    9f47:	48 89 f8             	mov    %rdi,%rax
    9f4a:	48 c1 e8 10          	shr    $0x10,%rax
    9f4e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9f52:	48 8b 05 bf 0c 06 00 	mov    0x60cbf(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    9f59:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9f5d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9f61:	48 85 c0             	test   %rax,%rax
    9f64:	74 c2                	je     9f28 <fwp_caps12+0xb8>
    9f66:	0f b6 0a             	movzbl (%rdx),%ecx
    9f69:	80 f9 02             	cmp    $0x2,%cl
    9f6c:	74 52                	je     9fc0 <fwp_caps12+0x150>
    9f6e:	80 f9 01             	cmp    $0x1,%cl
    9f71:	75 b5                	jne    9f28 <fwp_caps12+0xb8>
    9f73:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f76:	0f b7 ff             	movzwl %di,%edi
    9f79:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f7c:	48 0f af f9          	imul   %rcx,%rdi
    9f80:	48 c1 ef 20          	shr    $0x20,%rdi
    9f84:	48 39 d7             	cmp    %rdx,%rdi
    9f87:	73 9f                	jae    9f28 <fwp_caps12+0xb8>
    9f89:	48 01 f8             	add    %rdi,%rax
    9f8c:	0f b6 10             	movzbl (%rax),%edx
    9f8f:	84 d2                	test   %dl,%dl
    9f91:	74 95                	je     9f28 <fwp_caps12+0xb8>
    9f93:	8b 0d 4f 15 06 00    	mov    0x6154f(%rip),%ecx        # 6b4e8 <iteration_active>
    9f99:	85 c9                	test   %ecx,%ecx
    9f9b:	75 33                	jne    9fd0 <fwp_caps12+0x160>
    9f9d:	80 fa fd             	cmp    $0xfd,%dl
    9fa0:	77 38                	ja     9fda <fwp_caps12+0x16a>
    9fa2:	83 c2 01             	add    $0x1,%edx
    9fa5:	88 10                	mov    %dl,(%rax)
    9fa7:	e9 7c ff ff ff       	jmp    9f28 <fwp_caps12+0xb8>
    9fac:	0f 1f 40 00          	nopl   0x0(%rax)
    9fb0:	66 85 d2             	test   %dx,%dx
    9fb3:	0f 85 6f ff ff ff    	jne    9f28 <fwp_caps12+0xb8>
    9fb9:	e9 48 ff ff ff       	jmp    9f06 <fwp_caps12+0x96>
    9fbe:	66 90                	xchg   %ax,%ax
    9fc0:	66 85 ff             	test   %di,%di
    9fc3:	0f 85 5f ff ff ff    	jne    9f28 <fwp_caps12+0xb8>
    9fc9:	eb c1                	jmp    9f8c <fwp_caps12+0x11c>
    9fcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9fd0:	48 83 05 f8 14 06 00 	addq   $0x1,0x614f8(%rip)        # 6b4d0 <iteration_retains>
    9fd7:	01 
    9fd8:	eb c3                	jmp    9f9d <fwp_caps12+0x12d>
    9fda:	48 89 c7             	mov    %rax,%rdi
    9fdd:	48 83 c4 18          	add    $0x18,%rsp
    9fe1:	e9 ca b6 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9fed:	00 00 00 

0000000000009ff0 <fwp_caps23>:
    9ff0:	f3 0f 1e fa          	endbr64
    9ff4:	48 83 ec 18          	sub    $0x18,%rsp
    9ff8:	48 89 f8             	mov    %rdi,%rax
    9ffb:	8b 7f 04             	mov    0x4(%rdi),%edi
    9ffe:	85 ff                	test   %edi,%edi
    a000:	0f 84 9a 00 00 00    	je     a0a0 <fwp_caps23+0xb0>
    a006:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a00a:	85 f6                	test   %esi,%esi
    a00c:	0f 85 9e 00 00 00    	jne    a0b0 <fwp_caps23+0xc0>
    a012:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a017:	e8 24 f5 ff ff       	call   9540 <fwp_drop2>
    a01c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a021:	48 8b 0d d0 0b 06 00 	mov    0x60bd0(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    a028:	48 89 c2             	mov    %rax,%rdx
    a02b:	48 2b 15 9e 0b 06 00 	sub    0x60b9e(%rip),%rdx        # 6abd0 <fwp_heap+0x13b0>
    a032:	48 c1 e1 10          	shl    $0x10,%rcx
    a036:	48 39 ca             	cmp    %rcx,%rdx
    a039:	73 6d                	jae    a0a8 <fwp_caps23+0xb8>
    a03b:	48 89 d1             	mov    %rdx,%rcx
    a03e:	48 c1 e9 10          	shr    $0x10,%rcx
    a042:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a046:	48 8b 0d cb 0b 06 00 	mov    0x60bcb(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    a04d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a051:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a055:	48 85 f6             	test   %rsi,%rsi
    a058:	74 4e                	je     a0a8 <fwp_caps23+0xb8>
    a05a:	0f b6 39             	movzbl (%rcx),%edi
    a05d:	40 80 ff 02          	cmp    $0x2,%dil
    a061:	0f 84 c9 00 00 00    	je     a130 <fwp_caps23+0x140>
    a067:	40 80 ff 01          	cmp    $0x1,%dil
    a06b:	75 3b                	jne    a0a8 <fwp_caps23+0xb8>
    a06d:	8b 79 18             	mov    0x18(%rcx),%edi
    a070:	0f b7 d2             	movzwl %dx,%edx
    a073:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a076:	48 0f af d7          	imul   %rdi,%rdx
    a07a:	48 c1 ea 20          	shr    $0x20,%rdx
    a07e:	48 39 ca             	cmp    %rcx,%rdx
    a081:	73 25                	jae    a0a8 <fwp_caps23+0xb8>
    a083:	48 01 d6             	add    %rdx,%rsi
    a086:	80 3e 01             	cmpb   $0x1,(%rsi)
    a089:	75 1d                	jne    a0a8 <fwp_caps23+0xb8>
    a08b:	48 89 c7             	mov    %rax,%rdi
    a08e:	48 83 c4 18          	add    $0x18,%rsp
    a092:	e9 79 b9 ff ff       	jmp    5a10 <fwp_mem_free>
    a097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a09e:	00 00 
    a0a0:	85 f6                	test   %esi,%esi
    a0a2:	0f 84 79 ff ff ff    	je     a021 <fwp_caps23+0x31>
    a0a8:	48 83 c4 18          	add    $0x18,%rsp
    a0ac:	c3                   	ret
    a0ad:	0f 1f 00             	nopl   (%rax)
    a0b0:	48 8b 05 41 0b 06 00 	mov    0x60b41(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    a0b7:	48 2b 3d 12 0b 06 00 	sub    0x60b12(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    a0be:	48 c1 e0 10          	shl    $0x10,%rax
    a0c2:	48 39 c7             	cmp    %rax,%rdi
    a0c5:	73 e1                	jae    a0a8 <fwp_caps23+0xb8>
    a0c7:	48 89 f8             	mov    %rdi,%rax
    a0ca:	48 c1 e8 10          	shr    $0x10,%rax
    a0ce:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    a0d2:	48 8b 05 3f 0b 06 00 	mov    0x60b3f(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    a0d9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    a0dd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    a0e1:	48 85 c0             	test   %rax,%rax
    a0e4:	74 c2                	je     a0a8 <fwp_caps23+0xb8>
    a0e6:	0f b6 0a             	movzbl (%rdx),%ecx
    a0e9:	80 f9 02             	cmp    $0x2,%cl
    a0ec:	74 52                	je     a140 <fwp_caps23+0x150>
    a0ee:	80 f9 01             	cmp    $0x1,%cl
    a0f1:	75 b5                	jne    a0a8 <fwp_caps23+0xb8>
    a0f3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a0f6:	0f b7 ff             	movzwl %di,%edi
    a0f9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0fc:	48 0f af f9          	imul   %rcx,%rdi
    a100:	48 c1 ef 20          	shr    $0x20,%rdi
    a104:	48 39 d7             	cmp    %rdx,%rdi
    a107:	73 9f                	jae    a0a8 <fwp_caps23+0xb8>
    a109:	48 01 f8             	add    %rdi,%rax
    a10c:	0f b6 10             	movzbl (%rax),%edx
    a10f:	84 d2                	test   %dl,%dl
    a111:	74 95                	je     a0a8 <fwp_caps23+0xb8>
    a113:	8b 0d cf 13 06 00    	mov    0x613cf(%rip),%ecx        # 6b4e8 <iteration_active>
    a119:	85 c9                	test   %ecx,%ecx
    a11b:	75 33                	jne    a150 <fwp_caps23+0x160>
    a11d:	80 fa fd             	cmp    $0xfd,%dl
    a120:	77 38                	ja     a15a <fwp_caps23+0x16a>
    a122:	83 c2 01             	add    $0x1,%edx
    a125:	88 10                	mov    %dl,(%rax)
    a127:	e9 7c ff ff ff       	jmp    a0a8 <fwp_caps23+0xb8>
    a12c:	0f 1f 40 00          	nopl   0x0(%rax)
    a130:	66 85 d2             	test   %dx,%dx
    a133:	0f 85 6f ff ff ff    	jne    a0a8 <fwp_caps23+0xb8>
    a139:	e9 48 ff ff ff       	jmp    a086 <fwp_caps23+0x96>
    a13e:	66 90                	xchg   %ax,%ax
    a140:	66 85 ff             	test   %di,%di
    a143:	0f 85 5f ff ff ff    	jne    a0a8 <fwp_caps23+0xb8>
    a149:	eb c1                	jmp    a10c <fwp_caps23+0x11c>
    a14b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a150:	48 83 05 78 13 06 00 	addq   $0x1,0x61378(%rip)        # 6b4d0 <iteration_retains>
    a157:	01 
    a158:	eb c3                	jmp    a11d <fwp_caps23+0x12d>
    a15a:	48 89 c7             	mov    %rax,%rdi
    a15d:	48 83 c4 18          	add    $0x18,%rsp
    a161:	e9 4a b5 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    a166:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a16d:	00 00 00 

000000000000a170 <fwp_write>:
    a170:	41 57                	push   %r15
    a172:	41 56                	push   %r14
    a174:	41 55                	push   %r13
    a176:	41 54                	push   %r12
    a178:	55                   	push   %rbp
    a179:	53                   	push   %rbx
    a17a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    a181:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    a188:	00 00 
    a18a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    a191:	00 
    a192:	49 89 d4             	mov    %rdx,%r12
    a195:	8b 12                	mov    (%rdx),%edx
    a197:	83 fa 19             	cmp    $0x19,%edx
    a19a:	77 6a                	ja     a206 <fwp_write+0x96>
    a19c:	48 89 f5             	mov    %rsi,%rbp
    a19f:	89 d0                	mov    %edx,%eax
    a1a1:	89 ce                	mov    %ecx,%esi
    a1a3:	48 89 fb             	mov    %rdi,%rbx
    a1a6:	48 8d 0d 13 3b 00 00 	lea    0x3b13(%rip),%rcx        # dcc0 <_IO_stdin_used+0xcc0>
    a1ad:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    a1b1:	48 01 c8             	add    %rcx,%rax
    a1b4:	3e ff e0             	notrack jmp *%rax
    a1b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1be:	00 00 
    a1c0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    a1c4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a1c8:	48 89 ca             	mov    %rcx,%rdx
    a1cb:	48 85 c9             	test   %rcx,%rcx
    a1ce:	0f 88 9c 0c 00 00    	js     ae70 <fwp_write+0xd00>
    a1d4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a1db:	00 
    a1dc:	48 89 c6             	mov    %rax,%rsi
    a1df:	4c 89 e7             	mov    %r12,%rdi
    a1e2:	e8 59 98 ff ff       	call   3a40 <fwp_fmt_u128>
    a1e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1ee:	00 00 
    a1f0:	4c 89 e7             	mov    %r12,%rdi
    a1f3:	e8 48 92 ff ff       	call   3440 <strlen@plt>
    a1f8:	4c 89 e6             	mov    %r12,%rsi
    a1fb:	48 89 df             	mov    %rbx,%rdi
    a1fe:	48 89 c2             	mov    %rax,%rdx
    a201:	e8 ea 9e ff ff       	call   40f0 <buf_put>
    a206:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a20d:	00 
    a20e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a215:	00 00 
    a217:	0f 85 28 04 00 00    	jne    a645 <fwp_write+0x4d5>
    a21d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a224:	5b                   	pop    %rbx
    a225:	5d                   	pop    %rbp
    a226:	41 5c                	pop    %r12
    a228:	41 5d                	pop    %r13
    a22a:	41 5e                	pop    %r14
    a22c:	41 5f                	pop    %r15
    a22e:	c3                   	ret
    a22f:	90                   	nop
    a230:	49 89 e9             	mov    %rbp,%r9
    a233:	4c 8d 05 21 30 00 00 	lea    0x3021(%rip),%r8        # d25b <_IO_stdin_used+0x25b>
    a23a:	b9 00 02 00 00       	mov    $0x200,%ecx
    a23f:	ba 02 00 00 00       	mov    $0x2,%edx
    a244:	be 00 02 00 00       	mov    $0x200,%esi
    a249:	31 c0                	xor    %eax,%eax
    a24b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a252:	00 
    a253:	e8 48 91 ff ff       	call   33a0 <__snprintf_chk@plt>
    a258:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a25f:	00 
    a260:	e8 db 91 ff ff       	call   3440 <strlen@plt>
    a265:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a26c:	00 
    a26d:	48 89 df             	mov    %rbx,%rdi
    a270:	48 89 c2             	mov    %rax,%rdx
    a273:	e8 78 9e ff ff       	call   40f0 <buf_put>
    a278:	eb 8c                	jmp    a206 <fwp_write+0x96>
    a27a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a280:	49 89 e9             	mov    %rbp,%r9
    a283:	4c 8d 05 cc 2f 00 00 	lea    0x2fcc(%rip),%r8        # d256 <_IO_stdin_used+0x256>
    a28a:	eb ae                	jmp    a23a <fwp_write+0xca>
    a28c:	0f 1f 40 00          	nopl   0x0(%rax)
    a290:	83 fa 13             	cmp    $0x13,%edx
    a293:	48 8d 05 b2 2f 00 00 	lea    0x2fb2(%rip),%rax        # d24c <_IO_stdin_used+0x24c>
    a29a:	48 8d 35 b0 2f 00 00 	lea    0x2fb0(%rip),%rsi        # d251 <_IO_stdin_used+0x251>
    a2a1:	ba 04 00 00 00       	mov    $0x4,%edx
    a2a6:	48 0f 44 f0          	cmove  %rax,%rsi
    a2aa:	45 31 ed             	xor    %r13d,%r13d
    a2ad:	e8 3e 9e ff ff       	call   40f0 <buf_put>
    a2b2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a2b7:	0f 84 a3 08 00 00    	je     ab60 <fwp_write+0x9f0>
    a2bd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    a2c2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    a2c7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a2cc:	48 89 df             	mov    %rbx,%rdi
    a2cf:	49 0f 44 c5          	cmove  %r13,%rax
    a2d3:	31 c9                	xor    %ecx,%ecx
    a2d5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    a2da:	e8 91 fe ff ff       	call   a170 <fwp_write>
    a2df:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    a2e4:	0f 84 6e 09 00 00    	je     ac58 <fwp_write+0xae8>
    a2ea:	49 83 c5 01          	add    $0x1,%r13
    a2ee:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a2f2:	0f 83 68 08 00 00    	jae    ab60 <fwp_write+0x9f0>
    a2f8:	ba 02 00 00 00       	mov    $0x2,%edx
    a2fd:	48 8d 35 97 2f 00 00 	lea    0x2f97(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a304:	48 89 df             	mov    %rbx,%rdi
    a307:	e8 e4 9d ff ff       	call   40f0 <buf_put>
    a30c:	eb af                	jmp    a2bd <fwp_write+0x14d>
    a30e:	66 90                	xchg   %ax,%ax
    a310:	ba 06 00 00 00       	mov    $0x6,%edx
    a315:	48 8d 35 58 2f 00 00 	lea    0x2f58(%rip),%rsi        # d274 <_IO_stdin_used+0x274>
    a31c:	48 83 c5 10          	add    $0x10,%rbp
    a320:	e8 cb 9d ff ff       	call   40f0 <buf_put>
    a325:	48 89 ef             	mov    %rbp,%rdi
    a328:	e8 13 91 ff ff       	call   3440 <strlen@plt>
    a32d:	48 89 ee             	mov    %rbp,%rsi
    a330:	48 89 df             	mov    %rbx,%rdi
    a333:	48 89 c2             	mov    %rax,%rdx
    a336:	e8 b5 9d ff ff       	call   40f0 <buf_put>
    a33b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a340:	ba 01 00 00 00       	mov    $0x1,%edx
    a345:	48 89 df             	mov    %rbx,%rdi
    a348:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a34d:	e8 9e 9d ff ff       	call   40f0 <buf_put>
    a352:	e9 af fe ff ff       	jmp    a206 <fwp_write+0x96>
    a357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a35e:	00 00 
    a360:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a367:	00 
    a368:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a36f:	00 00 
    a371:	0f 85 ce 02 00 00    	jne    a645 <fwp_write+0x4d5>
    a377:	ba 0a 00 00 00       	mov    $0xa,%edx
    a37c:	48 8d 35 dd 2e 00 00 	lea    0x2edd(%rip),%rsi        # d260 <_IO_stdin_used+0x260>
    a383:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a38a:	48 89 df             	mov    %rbx,%rdi
    a38d:	5b                   	pop    %rbx
    a38e:	5d                   	pop    %rbp
    a38f:	41 5c                	pop    %r12
    a391:	41 5d                	pop    %r13
    a393:	41 5e                	pop    %r14
    a395:	41 5f                	pop    %r15
    a397:	e9 54 9d ff ff       	jmp    40f0 <buf_put>
    a39c:	0f 1f 40 00          	nopl   0x0(%rax)
    a3a0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a3a5:	4d 85 ed             	test   %r13,%r13
    a3a8:	0f 84 02 0c 00 00    	je     afb0 <fwp_write+0xe40>
    a3ae:	48 8d 35 f3 2e 00 00 	lea    0x2ef3(%rip),%rsi        # d2a8 <_IO_stdin_used+0x2a8>
    a3b5:	4c 89 ef             	mov    %r13,%rdi
    a3b8:	e8 63 91 ff ff       	call   3520 <strcmp@plt>
    a3bd:	41 89 c1             	mov    %eax,%r9d
    a3c0:	85 c0                	test   %eax,%eax
    a3c2:	0f 84 6c 0c 00 00    	je     b034 <fwp_write+0xec4>
    a3c8:	4c 89 ef             	mov    %r13,%rdi
    a3cb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a3d0:	e8 6b 90 ff ff       	call   3440 <strlen@plt>
    a3d5:	4c 89 ee             	mov    %r13,%rsi
    a3d8:	48 89 df             	mov    %rbx,%rdi
    a3db:	48 89 c2             	mov    %rax,%rdx
    a3de:	e8 0d 9d ff ff       	call   40f0 <buf_put>
    a3e3:	ba 01 00 00 00       	mov    $0x1,%edx
    a3e8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a3ed:	48 89 df             	mov    %rbx,%rdi
    a3f0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a3f5:	e8 f6 9c ff ff       	call   40f0 <buf_put>
    a3fa:	ba 01 00 00 00       	mov    $0x1,%edx
    a3ff:	4c 89 fe             	mov    %r15,%rsi
    a402:	48 89 df             	mov    %rbx,%rdi
    a405:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a40a:	e8 e1 9c ff ff       	call   40f0 <buf_put>
    a40f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a414:	45 31 f6             	xor    %r14d,%r14d
    a417:	85 d2                	test   %edx,%edx
    a419:	0f 8e 81 0a 00 00    	jle    aea0 <fwp_write+0xd30>
    a41f:	45 31 ed             	xor    %r13d,%r13d
    a422:	4d 85 ed             	test   %r13,%r13
    a425:	0f 85 75 07 00 00    	jne    aba0 <fwp_write+0xa30>
    a42b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a432:	00 
    a433:	45 85 f6             	test   %r14d,%r14d
    a436:	0f 84 84 07 00 00    	je     abc0 <fwp_write+0xa50>
    a43c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a441:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a446:	48 89 df             	mov    %rbx,%rdi
    a449:	49 83 c5 01          	add    $0x1,%r13
    a44d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a451:	31 c9                	xor    %ecx,%ecx
    a453:	e8 18 fd ff ff       	call   a170 <fwp_write>
    a458:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a45d:	7f c3                	jg     a422 <fwp_write+0x2b2>
    a45f:	45 85 f6             	test   %r14d,%r14d
    a462:	0f 84 38 0a 00 00    	je     aea0 <fwp_write+0xd30>
    a468:	b8 29 00 00 00       	mov    $0x29,%eax
    a46d:	ba 01 00 00 00       	mov    $0x1,%edx
    a472:	4c 89 fe             	mov    %r15,%rsi
    a475:	48 89 df             	mov    %rbx,%rdi
    a478:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a47c:	e8 6f 9c ff ff       	call   40f0 <buf_put>
    a481:	e9 80 fd ff ff       	jmp    a206 <fwp_write+0x96>
    a486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a48d:	00 00 00 
    a490:	ba 01 00 00 00       	mov    $0x1,%edx
    a495:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a49a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a49f:	e8 4c 9c ff ff       	call   40f0 <buf_put>
    a4a4:	48 85 ed             	test   %rbp,%rbp
    a4a7:	0f 84 93 06 00 00    	je     ab40 <fwp_write+0x9d0>
    a4ad:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a4b1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a4b6:	31 c9                	xor    %ecx,%ecx
    a4b8:	48 89 df             	mov    %rbx,%rdi
    a4bb:	e8 b0 fc ff ff       	call   a170 <fwp_write>
    a4c0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a4c4:	48 85 ed             	test   %rbp,%rbp
    a4c7:	0f 84 73 06 00 00    	je     ab40 <fwp_write+0x9d0>
    a4cd:	ba 02 00 00 00       	mov    $0x2,%edx
    a4d2:	48 8d 35 c2 2d 00 00 	lea    0x2dc2(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a4d9:	48 89 df             	mov    %rbx,%rdi
    a4dc:	e8 0f 9c ff ff       	call   40f0 <buf_put>
    a4e1:	eb ca                	jmp    a4ad <fwp_write+0x33d>
    a4e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4e8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a4ec:	85 f6                	test   %esi,%esi
    a4ee:	0f 84 fc 07 00 00    	je     acf0 <fwp_write+0xb80>
    a4f4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a4fb:	00 
    a4fc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a503:	00 00 
    a505:	0f 85 3a 01 00 00    	jne    a645 <fwp_write+0x4d5>
    a50b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a50f:	4c 89 ea             	mov    %r13,%rdx
    a512:	e9 6c fe ff ff       	jmp    a383 <fwp_write+0x213>
    a517:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a51e:	00 00 
    a520:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a525:	ba 01 00 00 00       	mov    $0x1,%edx
    a52a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a52f:	48 89 ee             	mov    %rbp,%rsi
    a532:	e8 b9 9b ff ff       	call   40f0 <buf_put>
    a537:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a53c:	4c 89 e7             	mov    %r12,%rdi
    a53f:	e8 fc 8e ff ff       	call   3440 <strlen@plt>
    a544:	4c 89 e6             	mov    %r12,%rsi
    a547:	48 89 df             	mov    %rbx,%rdi
    a54a:	48 89 c2             	mov    %rax,%rdx
    a54d:	e8 9e 9b ff ff       	call   40f0 <buf_put>
    a552:	ba 01 00 00 00       	mov    $0x1,%edx
    a557:	48 89 ee             	mov    %rbp,%rsi
    a55a:	48 89 df             	mov    %rbx,%rdi
    a55d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a562:	e8 89 9b ff ff       	call   40f0 <buf_put>
    a567:	e9 9a fc ff ff       	jmp    a206 <fwp_write+0x96>
    a56c:	0f 1f 40 00          	nopl   0x0(%rax)
    a570:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a575:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a579:	0f 8a 8e 0b 00 00    	jp     b10d <fwp_write+0xf9d>
    a57f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a583:	66 0f 54 05 35 38 00 	andpd  0x3835(%rip),%xmm0        # ddc0 <msg.4+0x90>
    a58a:	00 
    a58b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a590:	66 0f 2e 05 68 38 00 	ucomisd 0x3868(%rip),%xmm0        # de00 <msg.4+0xd0>
    a597:	00 
    a598:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a59f:	00 
    a5a0:	0f 87 b2 09 00 00    	ja     af58 <fwp_write+0xde8>
    a5a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a5ad:	00 00 00 
    a5b0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a5b4:	89 ee                	mov    %ebp,%esi
    a5b6:	4c 89 e7             	mov    %r12,%rdi
    a5b9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a5be:	e8 ad a1 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a5c3:	31 f6                	xor    %esi,%esi
    a5c5:	4c 89 e7             	mov    %r12,%rdi
    a5c8:	e8 33 8e ff ff       	call   3400 <strtod@plt>
    a5cd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a5d2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a5d6:	7a 06                	jp     a5de <fwp_write+0x46e>
    a5d8:	0f 84 e9 01 00 00    	je     a7c7 <fwp_write+0x657>
    a5de:	83 c5 01             	add    $0x1,%ebp
    a5e1:	83 fd 12             	cmp    $0x12,%ebp
    a5e4:	75 ca                	jne    a5b0 <fwp_write+0x440>
    a5e6:	be 11 00 00 00       	mov    $0x11,%esi
    a5eb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a5ef:	4c 89 e7             	mov    %r12,%rdi
    a5f2:	e8 79 a1 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a5f7:	e9 cb 01 00 00       	jmp    a7c7 <fwp_write+0x657>
    a5fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a600:	48 83 fd 01          	cmp    $0x1,%rbp
    a604:	0f 84 e6 08 00 00    	je     aef0 <fwp_write+0xd80>
    a60a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a60e:	b8 02 00 00 00       	mov    $0x2,%eax
    a613:	ba 01 00 00 00       	mov    $0x1,%edx
    a618:	48 0f 44 d0          	cmove  %rax,%rdx
    a61c:	48 8d 35 21 2c 00 00 	lea    0x2c21(%rip),%rsi        # d244 <_IO_stdin_used+0x244>
    a623:	48 8d 05 1f 2c 00 00 	lea    0x2c1f(%rip),%rax        # d249 <_IO_stdin_used+0x249>
    a62a:	48 0f 44 f0          	cmove  %rax,%rsi
    a62e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a635:	00 
    a636:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a63d:	00 00 
    a63f:	0f 84 3e fd ff ff    	je     a383 <fwp_write+0x213>
    a645:	e8 06 8e ff ff       	call   3450 <__stack_chk_fail@plt>
    a64a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a650:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a655:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a65a:	e8 d1 99 ff ff       	call   4030 <buf_grow>
    a65f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a663:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a669:	4c 03 0b             	add    (%rbx),%r9
    a66c:	66 45 89 11          	mov    %r10w,(%r9)
    a670:	45 85 e4             	test   %r12d,%r12d
    a673:	0f 8e 07 05 00 00    	jle    ab80 <fwp_write+0xa10>
    a679:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a680:	55 55 55 
    a683:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a688:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a68f:	aa aa aa 
    a692:	49 83 c1 01          	add    $0x1,%r9
    a696:	eb 45                	jmp    a6dd <fwp_write+0x56d>
    a698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a69f:	00 
    a6a0:	be 01 00 00 00       	mov    $0x1,%esi
    a6a5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a6aa:	88 07                	mov    %al,(%rdi)
    a6ac:	48 89 e8             	mov    %rbp,%rax
    a6af:	49 f7 e8             	imul   %r8
    a6b2:	48 89 e8             	mov    %rbp,%rax
    a6b5:	48 c1 f8 3f          	sar    $0x3f,%rax
    a6b9:	48 29 c2             	sub    %rax,%rdx
    a6bc:	48 85 c9             	test   %rcx,%rcx
    a6bf:	0f 95 c0             	setne  %al
    a6c2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a6c6:	48 83 ef 01          	sub    $0x1,%rdi
    a6ca:	48 21 c5             	and    %rax,%rbp
    a6cd:	48 29 ea             	sub    %rbp,%rdx
    a6d0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a6d4:	49 39 f9             	cmp    %rdi,%r9
    a6d7:	0f 84 a3 04 00 00    	je     ab80 <fwp_write+0xa10>
    a6dd:	48 89 e8             	mov    %rbp,%rax
    a6e0:	49 f7 e8             	imul   %r8
    a6e3:	48 89 e8             	mov    %rbp,%rax
    a6e6:	48 c1 f8 3f          	sar    $0x3f,%rax
    a6ea:	48 89 d1             	mov    %rdx,%rcx
    a6ed:	48 29 c1             	sub    %rax,%rcx
    a6f0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a6f4:	48 89 e9             	mov    %rbp,%rcx
    a6f7:	48 29 c1             	sub    %rax,%rcx
    a6fa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a6fe:	49 f7 e2             	mul    %r10
    a701:	b8 30 00 00 00       	mov    $0x30,%eax
    a706:	48 89 d6             	mov    %rdx,%rsi
    a709:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a70d:	48 d1 ee             	shr    $1,%rsi
    a710:	48 01 f2             	add    %rsi,%rdx
    a713:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a717:	48 29 d6             	sub    %rdx,%rsi
    a71a:	74 8e                	je     a6aa <fwp_write+0x53a>
    a71c:	48 83 fe 01          	cmp    $0x1,%rsi
    a720:	0f 85 7a ff ff ff    	jne    a6a0 <fwp_write+0x530>
    a726:	31 f6                	xor    %esi,%esi
    a728:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a72d:	e9 78 ff ff ff       	jmp    a6aa <fwp_write+0x53a>
    a732:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a738:	66 0f 6e cd          	movd   %ebp,%xmm1
    a73c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a73f:	0f 8a c8 09 00 00    	jp     b10d <fwp_write+0xf9d>
    a745:	0f 28 c1             	movaps %xmm1,%xmm0
    a748:	0f 54 05 61 36 00 00 	andps  0x3661(%rip),%xmm0        # ddb0 <msg.4+0x80>
    a74f:	0f 2e 05 ae 28 00 00 	ucomiss 0x28ae(%rip),%xmm0        # d004 <_IO_stdin_used+0x4>
    a756:	0f 87 24 08 00 00    	ja     af80 <fwp_write+0xe10>
    a75c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a760:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a766:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a76d:	00 
    a76e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a772:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a777:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a77e:	00 00 
    a780:	44 89 ee             	mov    %r13d,%esi
    a783:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a788:	4c 89 e7             	mov    %r12,%rdi
    a78b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a790:	e8 db 9f ff ff       	call   4770 <fwp_format_g.constprop.0>
    a795:	31 f6                	xor    %esi,%esi
    a797:	4c 89 e7             	mov    %r12,%rdi
    a79a:	e8 01 8d ff ff       	call   34a0 <strtof@plt>
    a79f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a7a4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a7a7:	7a 02                	jp     a7ab <fwp_write+0x63b>
    a7a9:	74 1c                	je     a7c7 <fwp_write+0x657>
    a7ab:	41 83 c5 01          	add    $0x1,%r13d
    a7af:	41 83 fd 0a          	cmp    $0xa,%r13d
    a7b3:	75 cb                	jne    a780 <fwp_write+0x610>
    a7b5:	be 09 00 00 00       	mov    $0x9,%esi
    a7ba:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a7bf:	4c 89 e7             	mov    %r12,%rdi
    a7c2:	e8 a9 9f ff ff       	call   4770 <fwp_format_g.constprop.0>
    a7c7:	4c 89 e7             	mov    %r12,%rdi
    a7ca:	e8 e1 99 ff ff       	call   41b0 <fwp_finish_float>
    a7cf:	e9 1c fa ff ff       	jmp    a1f0 <fwp_write+0x80>
    a7d4:	0f 1f 40 00          	nopl   0x0(%rax)
    a7d8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a7dc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a7e0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a7e7:	00 
    a7e8:	48 89 ef             	mov    %rbp,%rdi
    a7eb:	e8 50 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a7f0:	48 89 ef             	mov    %rbp,%rdi
    a7f3:	e8 48 8c ff ff       	call   3440 <strlen@plt>
    a7f8:	48 89 ee             	mov    %rbp,%rsi
    a7fb:	48 89 df             	mov    %rbx,%rdi
    a7fe:	48 89 c2             	mov    %rax,%rdx
    a801:	e8 ea 98 ff ff       	call   40f0 <buf_put>
    a806:	e9 fb f9 ff ff       	jmp    a206 <fwp_write+0x96>
    a80b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a810:	ba 06 00 00 00       	mov    $0x6,%edx
    a815:	48 8d 35 82 2a 00 00 	lea    0x2a82(%rip),%rsi        # d29e <_IO_stdin_used+0x29e>
    a81c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a822:	e8 c9 98 ff ff       	call   40f0 <buf_put>
    a827:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a82e:	ff ff 7f 
    a831:	48 23 55 00          	and    0x0(%rbp),%rdx
    a835:	0f 84 86 02 00 00    	je     aac1 <fwp_write+0x951>
    a83b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a840:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a844:	48 85 d2             	test   %rdx,%rdx
    a847:	0f 84 ae 00 00 00    	je     a8fb <fwp_write+0x78b>
    a84d:	8b 0a                	mov    (%rdx),%ecx
    a84f:	83 f9 1c             	cmp    $0x1c,%ecx
    a852:	0f 84 58 06 00 00    	je     aeb0 <fwp_write+0xd40>
    a858:	83 f9 1b             	cmp    $0x1b,%ecx
    a85b:	0f 87 9a 00 00 00    	ja     a8fb <fwp_write+0x78b>
    a861:	be 01 00 00 00       	mov    $0x1,%esi
    a866:	48 d3 e6             	shl    %cl,%rsi
    a869:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a86f:	0f 85 4b 04 00 00    	jne    acc0 <fwp_write+0xb50>
    a875:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a87b:	0f 85 0f 04 00 00    	jne    ac90 <fwp_write+0xb20>
    a881:	83 e6 21             	and    $0x21,%esi
    a884:	74 75                	je     a8fb <fwp_write+0x78b>
    a886:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a88b:	48 85 ff             	test   %rdi,%rdi
    a88e:	79 07                	jns    a897 <fwp_write+0x727>
    a890:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a894:	4c 01 ee             	add    %r13,%rsi
    a897:	48 0f be 3e          	movsbq (%rsi),%rdi
    a89b:	85 c9                	test   %ecx,%ecx
    a89d:	40 0f b6 f7          	movzbl %dil,%esi
    a8a1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a8a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8ac:	00 00 00 00 
    a8b0:	31 c9                	xor    %ecx,%ecx
    a8b2:	48 89 df             	mov    %rbx,%rdi
    a8b5:	49 83 c5 01          	add    $0x1,%r13
    a8b9:	e8 b2 f8 ff ff       	call   a170 <fwp_write>
    a8be:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a8c5:	ff ff 7f 
    a8c8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a8cc:	49 39 d5             	cmp    %rdx,%r13
    a8cf:	0f 83 ec 01 00 00    	jae    aac1 <fwp_write+0x951>
    a8d5:	ba 02 00 00 00       	mov    $0x2,%edx
    a8da:	48 89 df             	mov    %rbx,%rdi
    a8dd:	48 8d 35 b7 29 00 00 	lea    0x29b7(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a8e4:	e8 07 98 ff ff       	call   40f0 <buf_put>
    a8e9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a8ee:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a8f2:	48 85 d2             	test   %rdx,%rdx
    a8f5:	0f 85 52 ff ff ff    	jne    a84d <fwp_write+0x6dd>
    a8fb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a900:	48 85 ff             	test   %rdi,%rdi
    a903:	0f 88 cf 05 00 00    	js     aed8 <fwp_write+0xd68>
    a909:	48 8b 31             	mov    (%rcx),%rsi
    a90c:	eb a2                	jmp    a8b0 <fwp_write+0x740>
    a90e:	66 90                	xchg   %ax,%ax
    a910:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a917:	00 
    a918:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a91f:	00 00 
    a921:	0f 85 1e fd ff ff    	jne    a645 <fwp_write+0x4d5>
    a927:	ba 08 00 00 00       	mov    $0x8,%edx
    a92c:	48 8d 35 38 29 00 00 	lea    0x2938(%rip),%rsi        # d26b <_IO_stdin_used+0x26b>
    a933:	e9 4b fa ff ff       	jmp    a383 <fwp_write+0x213>
    a938:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a93f:	00 
    a940:	89 e8                	mov    %ebp,%eax
    a942:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a949:	76 03                	jbe    a94e <fwp_write+0x7de>
    a94b:	8b 45 00             	mov    0x0(%rbp),%eax
    a94e:	41 89 c6             	mov    %eax,%r14d
    a951:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a956:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a95b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a95f:	4c 89 ef             	mov    %r13,%rdi
    a962:	e8 d9 8a ff ff       	call   3440 <strlen@plt>
    a967:	4c 89 ee             	mov    %r13,%rsi
    a96a:	48 89 df             	mov    %rbx,%rdi
    a96d:	48 89 c2             	mov    %rax,%rdx
    a970:	e8 7b 97 ff ff       	call   40f0 <buf_put>
    a975:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a97a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a97e:	85 f6                	test   %esi,%esi
    a980:	0f 8e 80 f8 ff ff    	jle    a206 <fwp_write+0x96>
    a986:	45 31 ed             	xor    %r13d,%r13d
    a989:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a98e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a993:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a998:	ba 01 00 00 00       	mov    $0x1,%edx
    a99d:	4c 89 fe             	mov    %r15,%rsi
    a9a0:	48 89 04 24          	mov    %rax,(%rsp)
    a9a4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a9a9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a9ad:	48 89 df             	mov    %rbx,%rdi
    a9b0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a9b4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a9b9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a9be:	e8 2d 97 ff ff       	call   40f0 <buf_put>
    a9c3:	41 8b 06             	mov    (%r14),%eax
    a9c6:	83 f8 0e             	cmp    $0xe,%eax
    a9c9:	0f 84 71 02 00 00    	je     ac40 <fwp_write+0xad0>
    a9cf:	83 f8 10             	cmp    $0x10,%eax
    a9d2:	0f 84 38 02 00 00    	je     ac10 <fwp_write+0xaa0>
    a9d8:	83 f8 0a             	cmp    $0xa,%eax
    a9db:	0f 84 7f 04 00 00    	je     ae60 <fwp_write+0xcf0>
    a9e1:	0f 8f f9 00 00 00    	jg     aae0 <fwp_write+0x970>
    a9e7:	83 f8 03             	cmp    $0x3,%eax
    a9ea:	0f 8f 50 04 00 00    	jg     ae40 <fwp_write+0xcd0>
    a9f0:	85 c0                	test   %eax,%eax
    a9f2:	78 10                	js     aa04 <fwp_write+0x894>
    a9f4:	48 8b 04 24          	mov    (%rsp),%rax
    a9f8:	48 c1 e8 3f          	shr    $0x3f,%rax
    a9fc:	85 c0                	test   %eax,%eax
    a9fe:	0f 85 f9 00 00 00    	jne    aafd <fwp_write+0x98d>
    aa04:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    aa09:	48 8b 34 24          	mov    (%rsp),%rsi
    aa0d:	31 c9                	xor    %ecx,%ecx
    aa0f:	48 89 df             	mov    %rbx,%rdi
    aa12:	e8 59 f7 ff ff       	call   a170 <fwp_write>
    aa17:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    aa1c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    aa21:	49 83 c5 01          	add    $0x1,%r13
    aa25:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    aa29:	0f 8f 5f ff ff ff    	jg     a98e <fwp_write+0x81e>
    aa2f:	e9 d2 f7 ff ff       	jmp    a206 <fwp_write+0x96>
    aa34:	0f 1f 40 00          	nopl   0x0(%rax)
    aa38:	ba 06 00 00 00       	mov    $0x6,%edx
    aa3d:	48 8d 35 4d 28 00 00 	lea    0x284d(%rip),%rsi        # d291 <_IO_stdin_used+0x291>
    aa44:	45 31 ed             	xor    %r13d,%r13d
    aa47:	e8 a4 96 ff ff       	call   40f0 <buf_put>
    aa4c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    aa51:	75 19                	jne    aa6c <fwp_write+0x8fc>
    aa53:	eb 6c                	jmp    aac1 <fwp_write+0x951>
    aa55:	0f 1f 00             	nopl   (%rax)
    aa58:	ba 02 00 00 00       	mov    $0x2,%edx
    aa5d:	48 8d 35 37 28 00 00 	lea    0x2837(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    aa64:	48 89 df             	mov    %rbx,%rdi
    aa67:	e8 84 96 ff ff       	call   40f0 <buf_put>
    aa6c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    aa72:	b9 00 02 00 00       	mov    $0x200,%ecx
    aa77:	31 c0                	xor    %eax,%eax
    aa79:	49 83 c5 01          	add    $0x1,%r13
    aa7d:	4c 8d 05 14 28 00 00 	lea    0x2814(%rip),%r8        # d298 <_IO_stdin_used+0x298>
    aa84:	ba 02 00 00 00       	mov    $0x2,%edx
    aa89:	be 00 02 00 00       	mov    $0x200,%esi
    aa8e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa95:	00 
    aa96:	e8 05 89 ff ff       	call   33a0 <__snprintf_chk@plt>
    aa9b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aaa2:	00 
    aaa3:	e8 98 89 ff ff       	call   3440 <strlen@plt>
    aaa8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aaaf:	00 
    aab0:	48 89 df             	mov    %rbx,%rdi
    aab3:	48 89 c2             	mov    %rax,%rdx
    aab6:	e8 35 96 ff ff       	call   40f0 <buf_put>
    aabb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    aabf:	72 97                	jb     aa58 <fwp_write+0x8e8>
    aac1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    aac6:	ba 01 00 00 00       	mov    $0x1,%edx
    aacb:	48 89 df             	mov    %rbx,%rdi
    aace:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    aad3:	e8 18 96 ff ff       	call   40f0 <buf_put>
    aad8:	e9 29 f7 ff ff       	jmp    a206 <fwp_write+0x96>
    aadd:	0f 1f 00             	nopl   (%rax)
    aae0:	83 f8 0b             	cmp    $0xb,%eax
    aae3:	0f 85 1b ff ff ff    	jne    aa04 <fwp_write+0x894>
    aae9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    aaee:	66 0f 50 c3          	movmskpd %xmm3,%eax
    aaf2:	83 e0 01             	and    $0x1,%eax
    aaf5:	85 c0                	test   %eax,%eax
    aaf7:	0f 84 07 ff ff ff    	je     aa04 <fwp_write+0x894>
    aafd:	4c 89 fe             	mov    %r15,%rsi
    ab00:	48 89 df             	mov    %rbx,%rdi
    ab03:	ba 01 00 00 00       	mov    $0x1,%edx
    ab08:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ab0d:	e8 de 95 ff ff       	call   40f0 <buf_put>
    ab12:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    ab17:	48 8b 34 24          	mov    (%rsp),%rsi
    ab1b:	31 c9                	xor    %ecx,%ecx
    ab1d:	48 89 df             	mov    %rbx,%rdi
    ab20:	e8 4b f6 ff ff       	call   a170 <fwp_write>
    ab25:	ba 01 00 00 00       	mov    $0x1,%edx
    ab2a:	4c 89 fe             	mov    %r15,%rsi
    ab2d:	48 89 df             	mov    %rbx,%rdi
    ab30:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    ab35:	e8 b6 95 ff ff       	call   40f0 <buf_put>
    ab3a:	e9 d8 fe ff ff       	jmp    aa17 <fwp_write+0x8a7>
    ab3f:	90                   	nop
    ab40:	ba 01 00 00 00       	mov    $0x1,%edx
    ab45:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab4a:	48 89 df             	mov    %rbx,%rdi
    ab4d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    ab52:	e8 99 95 ff ff       	call   40f0 <buf_put>
    ab57:	e9 aa f6 ff ff       	jmp    a206 <fwp_write+0x96>
    ab5c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab60:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab65:	ba 01 00 00 00       	mov    $0x1,%edx
    ab6a:	48 89 df             	mov    %rbx,%rdi
    ab6d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    ab72:	e8 79 95 ff ff       	call   40f0 <buf_put>
    ab77:	e9 8a f6 ff ff       	jmp    a206 <fwp_write+0x96>
    ab7c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab80:	48 8b 43 08          	mov    0x8(%rbx),%rax
    ab84:	48 8b 13             	mov    (%rbx),%rdx
    ab87:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    ab8c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    ab90:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    ab94:	e9 6d f6 ff ff       	jmp    a206 <fwp_write+0x96>
    ab99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aba0:	ba 02 00 00 00       	mov    $0x2,%edx
    aba5:	48 8d 35 ef 26 00 00 	lea    0x26ef(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    abac:	48 89 df             	mov    %rbx,%rdi
    abaf:	e8 3c 95 ff ff       	call   40f0 <buf_put>
    abb4:	e9 72 f8 ff ff       	jmp    a42b <fwp_write+0x2bb>
    abb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abc0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    abc5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    abca:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    abce:	48 89 f7             	mov    %rsi,%rdi
    abd1:	48 89 34 24          	mov    %rsi,(%rsp)
    abd5:	e8 66 88 ff ff       	call   3440 <strlen@plt>
    abda:	48 8b 34 24          	mov    (%rsp),%rsi
    abde:	48 89 df             	mov    %rbx,%rdi
    abe1:	48 89 c2             	mov    %rax,%rdx
    abe4:	e8 07 95 ff ff       	call   40f0 <buf_put>
    abe9:	ba 03 00 00 00       	mov    $0x3,%edx
    abee:	48 8d 35 c9 26 00 00 	lea    0x26c9(%rip),%rsi        # d2be <_IO_stdin_used+0x2be>
    abf5:	48 89 df             	mov    %rbx,%rdi
    abf8:	e8 f3 94 ff ff       	call   40f0 <buf_put>
    abfd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    ac02:	e9 35 f8 ff ff       	jmp    a43c <fwp_write+0x2cc>
    ac07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac0e:	00 00 
    ac10:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    ac15:	48 8b 78 08          	mov    0x8(%rax),%rdi
    ac19:	48 85 ff             	test   %rdi,%rdi
    ac1c:	0f 84 e2 fd ff ff    	je     aa04 <fwp_write+0x894>
    ac22:	48 8d 35 7f 26 00 00 	lea    0x267f(%rip),%rsi        # d2a8 <_IO_stdin_used+0x2a8>
    ac29:	e8 f2 88 ff ff       	call   3520 <strcmp@plt>
    ac2e:	85 c0                	test   %eax,%eax
    ac30:	0f 95 c0             	setne  %al
    ac33:	0f b6 c0             	movzbl %al,%eax
    ac36:	e9 c1 fd ff ff       	jmp    a9fc <fwp_write+0x88c>
    ac3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ac40:	31 c0                	xor    %eax,%eax
    ac42:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    ac49:	00 
    ac4a:	0f 97 c0             	seta   %al
    ac4d:	e9 aa fd ff ff       	jmp    a9fc <fwp_write+0x88c>
    ac52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac58:	48 89 df             	mov    %rbx,%rdi
    ac5b:	ba 02 00 00 00       	mov    $0x2,%edx
    ac60:	48 8d 35 3e 26 00 00 	lea    0x263e(%rip),%rsi        # d2a5 <_IO_stdin_used+0x2a5>
    ac67:	e8 84 94 ff ff       	call   40f0 <buf_put>
    ac6c:	4c 89 e8             	mov    %r13,%rax
    ac6f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    ac74:	31 c9                	xor    %ecx,%ecx
    ac76:	48 c1 e0 04          	shl    $0x4,%rax
    ac7a:	48 89 df             	mov    %rbx,%rdi
    ac7d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    ac82:	e8 e9 f4 ff ff       	call   a170 <fwp_write>
    ac87:	e9 5e f6 ff ff       	jmp    a2ea <fwp_write+0x17a>
    ac8c:	0f 1f 40 00          	nopl   0x0(%rax)
    ac90:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    ac95:	48 85 ff             	test   %rdi,%rdi
    ac98:	79 0c                	jns    aca6 <fwp_write+0xb36>
    ac9a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    aca1:	00 
    aca2:	48 03 75 10          	add    0x10(%rbp),%rsi
    aca6:	48 63 3e             	movslq (%rsi),%rdi
    aca9:	83 f9 02             	cmp    $0x2,%ecx
    acac:	89 fe                	mov    %edi,%esi
    acae:	48 0f 44 f7          	cmove  %rdi,%rsi
    acb2:	e9 f9 fb ff ff       	jmp    a8b0 <fwp_write+0x740>
    acb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    acbe:	00 00 
    acc0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    acc5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    acca:	48 85 ff             	test   %rdi,%rdi
    accd:	0f 88 0f 03 00 00    	js     afe2 <fwp_write+0xe72>
    acd3:	49 0f bf 38          	movswq (%r8),%rdi
    acd7:	83 f9 01             	cmp    $0x1,%ecx
    acda:	0f b7 f7             	movzwl %di,%esi
    acdd:	48 0f 44 f7          	cmove  %rdi,%rsi
    ace1:	e9 ca fb ff ff       	jmp    a8b0 <fwp_write+0x740>
    ace6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aced:	00 00 00 
    acf0:	ba 01 00 00 00       	mov    $0x1,%edx
    acf5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    acfa:	48 83 c5 08          	add    $0x8,%rbp
    acfe:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    ad03:	e8 e8 93 ff ff       	call   40f0 <buf_put>
    ad08:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ad0d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    ad12:	4d 85 ed             	test   %r13,%r13
    ad15:	75 46                	jne    ad5d <fwp_write+0xbed>
    ad17:	e9 04 01 00 00       	jmp    ae20 <fwp_write+0xcb0>
    ad1c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad20:	41 80 f9 09          	cmp    $0x9,%r9b
    ad24:	0f 84 d6 00 00 00    	je     ae00 <fwp_write+0xc90>
    ad2a:	41 80 f9 0a          	cmp    $0xa,%r9b
    ad2e:	0f 85 9c 00 00 00    	jne    add0 <fwp_write+0xc60>
    ad34:	ba 02 00 00 00       	mov    $0x2,%edx
    ad39:	48 8d 35 41 25 00 00 	lea    0x2541(%rip),%rsi        # d281 <_IO_stdin_used+0x281>
    ad40:	48 89 df             	mov    %rbx,%rdi
    ad43:	e8 a8 93 ff ff       	call   40f0 <buf_put>
    ad48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ad4f:	00 
    ad50:	48 83 c5 01          	add    $0x1,%rbp
    ad54:	49 39 ec             	cmp    %rbp,%r12
    ad57:	0f 84 c3 00 00 00    	je     ae20 <fwp_write+0xcb0>
    ad5d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    ad62:	41 80 f9 0d          	cmp    $0xd,%r9b
    ad66:	74 28                	je     ad90 <fwp_write+0xc20>
    ad68:	7e b6                	jle    ad20 <fwp_write+0xbb0>
    ad6a:	41 80 f9 22          	cmp    $0x22,%r9b
    ad6e:	74 40                	je     adb0 <fwp_write+0xc40>
    ad70:	41 80 f9 5c          	cmp    $0x5c,%r9b
    ad74:	75 5a                	jne    add0 <fwp_write+0xc60>
    ad76:	ba 02 00 00 00       	mov    $0x2,%edx
    ad7b:	48 8d 35 fc 24 00 00 	lea    0x24fc(%rip),%rsi        # d27e <_IO_stdin_used+0x27e>
    ad82:	48 89 df             	mov    %rbx,%rdi
    ad85:	e8 66 93 ff ff       	call   40f0 <buf_put>
    ad8a:	eb c4                	jmp    ad50 <fwp_write+0xbe0>
    ad8c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad90:	ba 02 00 00 00       	mov    $0x2,%edx
    ad95:	48 8d 35 eb 24 00 00 	lea    0x24eb(%rip),%rsi        # d287 <_IO_stdin_used+0x287>
    ad9c:	48 89 df             	mov    %rbx,%rdi
    ad9f:	e8 4c 93 ff ff       	call   40f0 <buf_put>
    ada4:	eb aa                	jmp    ad50 <fwp_write+0xbe0>
    ada6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    adad:	00 00 00 
    adb0:	ba 02 00 00 00       	mov    $0x2,%edx
    adb5:	48 8d 35 bf 24 00 00 	lea    0x24bf(%rip),%rsi        # d27b <_IO_stdin_used+0x27b>
    adbc:	48 89 df             	mov    %rbx,%rdi
    adbf:	e8 2c 93 ff ff       	call   40f0 <buf_put>
    adc4:	eb 8a                	jmp    ad50 <fwp_write+0xbe0>
    adc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    adcd:	00 00 00 
    add0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    add4:	0f 86 2e 01 00 00    	jbe    af08 <fwp_write+0xd98>
    adda:	41 80 f9 7f          	cmp    $0x7f,%r9b
    adde:	0f 84 24 01 00 00    	je     af08 <fwp_write+0xd98>
    ade4:	ba 01 00 00 00       	mov    $0x1,%edx
    ade9:	4c 89 fe             	mov    %r15,%rsi
    adec:	48 89 df             	mov    %rbx,%rdi
    adef:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    adf4:	e8 f7 92 ff ff       	call   40f0 <buf_put>
    adf9:	e9 52 ff ff ff       	jmp    ad50 <fwp_write+0xbe0>
    adfe:	66 90                	xchg   %ax,%ax
    ae00:	ba 02 00 00 00       	mov    $0x2,%edx
    ae05:	48 8d 35 78 24 00 00 	lea    0x2478(%rip),%rsi        # d284 <_IO_stdin_used+0x284>
    ae0c:	48 89 df             	mov    %rbx,%rdi
    ae0f:	e8 dc 92 ff ff       	call   40f0 <buf_put>
    ae14:	e9 37 ff ff ff       	jmp    ad50 <fwp_write+0xbe0>
    ae19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ae20:	ba 01 00 00 00       	mov    $0x1,%edx
    ae25:	4c 89 fe             	mov    %r15,%rsi
    ae28:	48 89 df             	mov    %rbx,%rdi
    ae2b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    ae30:	e8 bb 92 ff ff       	call   40f0 <buf_put>
    ae35:	e9 cc f3 ff ff       	jmp    a206 <fwp_write+0x96>
    ae3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae40:	83 f8 04             	cmp    $0x4,%eax
    ae43:	0f 85 bb fb ff ff    	jne    aa04 <fwp_write+0x894>
    ae49:	48 8b 04 24          	mov    (%rsp),%rax
    ae4d:	48 8b 40 08          	mov    0x8(%rax),%rax
    ae51:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    ae56:	48 c1 e8 3f          	shr    $0x3f,%rax
    ae5a:	e9 96 fc ff ff       	jmp    aaf5 <fwp_write+0x985>
    ae5f:	90                   	nop
    ae60:	8b 0c 24             	mov    (%rsp),%ecx
    ae63:	31 c0                	xor    %eax,%eax
    ae65:	85 c9                	test   %ecx,%ecx
    ae67:	0f 98 c0             	sets   %al
    ae6a:	e9 86 fc ff ff       	jmp    aaf5 <fwp_write+0x985>
    ae6f:	90                   	nop
    ae70:	48 f7 d8             	neg    %rax
    ae73:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    ae7a:	00 
    ae7b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    ae82:	2d 
    ae83:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae8a:	00 
    ae8b:	48 83 d2 00          	adc    $0x0,%rdx
    ae8f:	48 89 c6             	mov    %rax,%rsi
    ae92:	48 f7 da             	neg    %rdx
    ae95:	e8 a6 8b ff ff       	call   3a40 <fwp_fmt_u128>
    ae9a:	e9 51 f3 ff ff       	jmp    a1f0 <fwp_write+0x80>
    ae9f:	90                   	nop
    aea0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    aea5:	e9 c3 f5 ff ff       	jmp    a46d <fwp_write+0x2fd>
    aeaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aeb0:	4c 89 e9             	mov    %r13,%rcx
    aeb3:	48 c1 e1 04          	shl    $0x4,%rcx
    aeb7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    aebc:	48 85 ff             	test   %rdi,%rdi
    aebf:	0f 89 eb f9 ff ff    	jns    a8b0 <fwp_write+0x740>
    aec5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aec9:	48 89 ce             	mov    %rcx,%rsi
    aecc:	e9 df f9 ff ff       	jmp    a8b0 <fwp_write+0x740>
    aed1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aed8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    aedf:	00 
    aee0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aee4:	e9 20 fa ff ff       	jmp    a909 <fwp_write+0x799>
    aee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aef0:	ba 02 00 00 00       	mov    $0x2,%edx
    aef5:	48 8d 35 4a 23 00 00 	lea    0x234a(%rip),%rsi        # d246 <_IO_stdin_used+0x246>
    aefc:	e9 2d f7 ff ff       	jmp    a62e <fwp_write+0x4be>
    af01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    af08:	4c 8d 05 7b 23 00 00 	lea    0x237b(%rip),%r8        # d28a <_IO_stdin_used+0x28a>
    af0f:	b9 10 00 00 00       	mov    $0x10,%ecx
    af14:	31 c0                	xor    %eax,%eax
    af16:	ba 02 00 00 00       	mov    $0x2,%edx
    af1b:	be 10 00 00 00       	mov    $0x10,%esi
    af20:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    af27:	00 
    af28:	e8 73 84 ff ff       	call   33a0 <__snprintf_chk@plt>
    af2d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    af34:	00 
    af35:	e8 06 85 ff ff       	call   3440 <strlen@plt>
    af3a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    af41:	00 
    af42:	48 89 df             	mov    %rbx,%rdi
    af45:	48 89 c2             	mov    %rax,%rdx
    af48:	e8 a3 91 ff ff       	call   40f0 <buf_put>
    af4d:	e9 fe fd ff ff       	jmp    ad50 <fwp_write+0xbe0>
    af52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    af58:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af5c:	48 8d 35 dd 22 00 00 	lea    0x22dd(%rip),%rsi        # d240 <_IO_stdin_used+0x240>
    af63:	48 8d 05 d5 22 00 00 	lea    0x22d5(%rip),%rax        # d23f <_IO_stdin_used+0x23f>
    af6a:	4c 89 e7             	mov    %r12,%rdi
    af6d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    af71:	48 0f 46 f0          	cmovbe %rax,%rsi
    af75:	e8 66 84 ff ff       	call   33e0 <strcpy@plt>
    af7a:	e9 71 f2 ff ff       	jmp    a1f0 <fwp_write+0x80>
    af7f:	90                   	nop
    af80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af84:	48 8d 35 b5 22 00 00 	lea    0x22b5(%rip),%rsi        # d240 <_IO_stdin_used+0x240>
    af8b:	48 8d 05 ad 22 00 00 	lea    0x22ad(%rip),%rax        # d23f <_IO_stdin_used+0x23f>
    af92:	0f 2f c8             	comiss %xmm0,%xmm1
    af95:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    af9c:	00 
    af9d:	4c 89 e7             	mov    %r12,%rdi
    afa0:	48 0f 46 f0          	cmovbe %rax,%rsi
    afa4:	e8 37 84 ff ff       	call   33e0 <strcpy@plt>
    afa9:	e9 42 f2 ff ff       	jmp    a1f0 <fwp_write+0x80>
    afae:	66 90                	xchg   %ax,%ax
    afb0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    afb5:	45 85 c0             	test   %r8d,%r8d
    afb8:	75 34                	jne    afee <fwp_write+0xe7e>
    afba:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    afc1:	00 
    afc2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    afc9:	00 00 
    afcb:	0f 85 74 f6 ff ff    	jne    a645 <fwp_write+0x4d5>
    afd1:	ba 02 00 00 00       	mov    $0x2,%edx
    afd6:	48 8d 35 de 22 00 00 	lea    0x22de(%rip),%rsi        # d2bb <_IO_stdin_used+0x2bb>
    afdd:	e9 a1 f3 ff ff       	jmp    a383 <fwp_write+0x213>
    afe2:	48 03 75 10          	add    0x10(%rbp),%rsi
    afe6:	49 89 f0             	mov    %rsi,%r8
    afe9:	e9 e5 fc ff ff       	jmp    acd3 <fwp_write+0xb63>
    afee:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    aff3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aff8:	85 ff                	test   %edi,%edi
    affa:	0f 84 fa f3 ff ff    	je     a3fa <fwp_write+0x28a>
    b000:	ba 01 00 00 00       	mov    $0x1,%edx
    b005:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    b00a:	48 89 df             	mov    %rbx,%rdi
    b00d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    b012:	e8 d9 90 ff ff       	call   40f0 <buf_put>
    b017:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    b01c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    b021:	41 be 01 00 00 00    	mov    $0x1,%r14d
    b027:	85 c0                	test   %eax,%eax
    b029:	0f 8f f0 f3 ff ff    	jg     a41f <fwp_write+0x2af>
    b02f:	e9 34 f4 ff ff       	jmp    a468 <fwp_write+0x2f8>
    b034:	48 8b 45 08          	mov    0x8(%rbp),%rax
    b038:	49 89 c5             	mov    %rax,%r13
    b03b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b040:	49 89 c4             	mov    %rax,%r12
    b043:	49 c1 fd 3f          	sar    $0x3f,%r13
    b047:	4c 09 e8             	or     %r13,%rax
    b04a:	0f 84 a7 00 00 00    	je     b0f7 <fwp_write+0xf87>
    b050:	48 8d 2d c9 43 00 00 	lea    0x43c9(%rip),%rbp        # f420 <units.1>
    b057:	4d 89 e7             	mov    %r12,%r15
    b05a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    b05e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    b063:	4c 89 ff             	mov    %r15,%rdi
    b066:	4c 89 ee             	mov    %r13,%rsi
    b069:	44 89 0c 24          	mov    %r9d,(%rsp)
    b06d:	48 99                	cqto
    b06f:	48 89 d1             	mov    %rdx,%rcx
    b072:	48 89 c2             	mov    %rax,%rdx
    b075:	e8 06 10 00 00       	call   c080 <__divmodti4>
    b07a:	44 8b 0c 24          	mov    (%rsp),%r9d
    b07e:	48 89 c1             	mov    %rax,%rcx
    b081:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b086:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    b08b:	0f 84 94 00 00 00    	je     b125 <fwp_write+0xfb5>
    b091:	41 83 c1 01          	add    $0x1,%r9d
    b095:	48 83 c5 10          	add    $0x10,%rbp
    b099:	41 83 f9 05          	cmp    $0x5,%r9d
    b09d:	75 bb                	jne    b05a <fwp_write+0xeea>
    b09f:	4d 85 ed             	test   %r13,%r13
    b0a2:	79 53                	jns    b0f7 <fwp_write+0xf87>
    b0a4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b0a9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    b0ae:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    b0b3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b0b8:	48 99                	cqto
    b0ba:	48 f7 d8             	neg    %rax
    b0bd:	48 83 d2 00          	adc    $0x0,%rdx
    b0c1:	48 89 c6             	mov    %rax,%rsi
    b0c4:	48 f7 da             	neg    %rdx
    b0c7:	e8 74 89 ff ff       	call   3a40 <fwp_fmt_u128>
    b0cc:	49 89 e8             	mov    %rbp,%r8
    b0cf:	ba 00 02 00 00       	mov    $0x200,%edx
    b0d4:	be 02 00 00 00       	mov    $0x2,%esi
    b0d9:	31 c0                	xor    %eax,%eax
    b0db:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b0e2:	00 
    b0e3:	48 8d 0d cc 21 00 00 	lea    0x21cc(%rip),%rcx        # d2b6 <_IO_stdin_used+0x2b6>
    b0ea:	4c 89 e7             	mov    %r12,%rdi
    b0ed:	e8 ce 85 ff ff       	call   36c0 <__sprintf_chk@plt>
    b0f2:	e9 f9 f0 ff ff       	jmp    a1f0 <fwp_write+0x80>
    b0f7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b0fc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    b101:	31 d2                	xor    %edx,%edx
    b103:	48 89 ef             	mov    %rbp,%rdi
    b106:	e8 35 89 ff ff       	call   3a40 <fwp_fmt_u128>
    b10b:	eb bf                	jmp    b0cc <fwp_write+0xf5c>
    b10d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    b114:	4e 61 4e 00 
    b118:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b11f:	00 
    b120:	e9 cb f0 ff ff       	jmp    a1f0 <fwp_write+0x80>
    b125:	44 89 0c 24          	mov    %r9d,(%rsp)
    b129:	48 89 c8             	mov    %rcx,%rax
    b12c:	48 85 d2             	test   %rdx,%rdx
    b12f:	78 51                	js     b182 <fwp_write+0x1012>
    b131:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b136:	48 89 c6             	mov    %rax,%rsi
    b139:	48 89 ef             	mov    %rbp,%rdi
    b13c:	e8 ff 88 ff ff       	call   3a40 <fwp_fmt_u128>
    b141:	44 8b 0c 24          	mov    (%rsp),%r9d
    b145:	49 63 c1             	movslq %r9d,%rax
    b148:	49 89 e8             	mov    %rbp,%r8
    b14b:	ba 00 02 00 00       	mov    $0x200,%edx
    b150:	be 02 00 00 00       	mov    $0x2,%esi
    b155:	48 c1 e0 04          	shl    $0x4,%rax
    b159:	48 8d 3d c0 42 00 00 	lea    0x42c0(%rip),%rdi        # f420 <units.1>
    b160:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b167:	00 
    b168:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    b16c:	48 8d 0d 3e 21 00 00 	lea    0x213e(%rip),%rcx        # d2b1 <_IO_stdin_used+0x2b1>
    b173:	4c 89 e7             	mov    %r12,%rdi
    b176:	31 c0                	xor    %eax,%eax
    b178:	e8 43 85 ff ff       	call   36c0 <__sprintf_chk@plt>
    b17d:	e9 6e f0 ff ff       	jmp    a1f0 <fwp_write+0x80>
    b182:	48 f7 d8             	neg    %rax
    b185:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    b18a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    b18f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b194:	48 83 d2 00          	adc    $0x0,%rdx
    b198:	48 89 c6             	mov    %rax,%rsi
    b19b:	48 f7 da             	neg    %rdx
    b19e:	e8 9d 88 ff ff       	call   3a40 <fwp_fmt_u128>
    b1a3:	44 8b 0c 24          	mov    (%rsp),%r9d
    b1a7:	eb 9c                	jmp    b145 <fwp_write+0xfd5>
    b1a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000b1b0 <fwp_main_thread>:
    b1b0:	f3 0f 1e fa          	endbr64
    b1b4:	41 57                	push   %r15
    b1b6:	41 56                	push   %r14
    b1b8:	41 55                	push   %r13
    b1ba:	41 54                	push   %r12
    b1bc:	55                   	push   %rbp
    b1bd:	53                   	push   %rbx
    b1be:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    b1c5:	8b 3d f9 f9 05 00    	mov    0x5f9f9(%rip),%edi        # 6abc4 <fwp_heap+0x13a4>
    b1cb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b1d2:	00 00 
    b1d4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b1db:	00 
    b1dc:	31 c0                	xor    %eax,%eax
    b1de:	85 ff                	test   %edi,%edi
    b1e0:	0f 84 1a 07 00 00    	je     b900 <fwp_main_thread+0x750>
    b1e6:	8b 35 dc f9 05 00    	mov    0x5f9dc(%rip),%esi        # 6abc8 <fwp_heap+0x13a8>
    b1ec:	85 f6                	test   %esi,%esi
    b1ee:	0f 85 1f 07 00 00    	jne    b913 <fwp_main_thread+0x763>
    b1f4:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b1f9:	48 8d 5c 24 20       	lea    0x20(%rsp),%rbx
    b1fe:	31 f6                	xor    %esi,%esi
    b200:	48 c7 05 b5 df 05 00 	movq   $0x40000000,0x5dfb5(%rip)        # 691c0 <fwp_main_stack_size>
    b207:	00 00 00 40 
    b20b:	48 8d 05 6e 5e 00 00 	lea    0x5e6e(%rip),%rax        # 11080 <alt.5>
    b212:	48 89 ef             	mov    %rbp,%rdi
    b215:	48 89 1d ac df 05 00 	mov    %rbx,0x5dfac(%rip)        # 691c8 <fwp_main_stack_top>
    b21c:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    b221:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    b228:	01 00 
    b22a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    b231:	00 
    b232:	e8 69 84 ff ff       	call   36a0 <sigaltstack@plt>
    b237:	85 c0                	test   %eax,%eax
    b239:	0f 85 fc 0d 00 00    	jne    c03b <fwp_main_thread+0xe8b>
    b23f:	31 c0                	xor    %eax,%eax
    b241:	b9 12 00 00 00       	mov    $0x12,%ecx
    b246:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    b24d:	00 
    b24e:	f3 48 ab             	rep stos %rax,(%rdi)
    b251:	48 8d 05 e8 8a ff ff 	lea    -0x7518(%rip),%rax        # 3d40 <fwp_segv>
    b258:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    b25f:	00 
    b260:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    b267:	04 00 00 08 
    b26b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b272:	00 
    b273:	4c 8d ac 24 80 00 00 	lea    0x80(%rsp),%r13
    b27a:	00 
    b27b:	e8 e0 82 ff ff       	call   3560 <sigemptyset@plt>
    b280:	85 c0                	test   %eax,%eax
    b282:	0f 85 b3 0d 00 00    	jne    c03b <fwp_main_thread+0xe8b>
    b288:	31 d2                	xor    %edx,%edx
    b28a:	4c 89 ee             	mov    %r13,%rsi
    b28d:	bf 0b 00 00 00       	mov    $0xb,%edi
    b292:	e8 59 81 ff ff       	call   33f0 <sigaction@plt>
    b297:	85 c0                	test   %eax,%eax
    b299:	0f 85 9c 0d 00 00    	jne    c03b <fwp_main_thread+0xe8b>
    b29f:	31 d2                	xor    %edx,%edx
    b2a1:	4c 89 ee             	mov    %r13,%rsi
    b2a4:	bf 07 00 00 00       	mov    $0x7,%edi
    b2a9:	e8 42 81 ff ff       	call   33f0 <sigaction@plt>
    b2ae:	85 c0                	test   %eax,%eax
    b2b0:	0f 85 85 0d 00 00    	jne    c03b <fwp_main_thread+0xe8b>
    b2b6:	48 8b 05 83 f9 05 00 	mov    0x5f983(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    b2bd:	48 85 c0             	test   %rax,%rax
    b2c0:	0f 88 1a 06 00 00    	js     b8e0 <fwp_main_thread+0x730>
    b2c6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b2ca:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b2cf:	48 8d 3d 4a 8f ff ff 	lea    -0x70b6(%rip),%rdi        # 4220 <ad_raw_report>
    b2d6:	f2 0f 11 05 ea 01 06 	movsd  %xmm0,0x601ea(%rip)        # 6b4c8 <iteration_start_charge>
    b2dd:	00 
    b2de:	c7 05 00 02 06 00 01 	movl   $0x1,0x60200(%rip)        # 6b4e8 <iteration_active>
    b2e5:	00 00 00 
    b2e8:	e8 a3 0f 00 00       	call   c290 <atexit>
    b2ed:	85 c0                	test   %eax,%eax
    b2ef:	0f 85 52 0d 00 00    	jne    c047 <fwp_main_thread+0xe97>
    b2f5:	8b 0d 75 5d 00 00    	mov    0x5d75(%rip),%ecx        # 11070 <st.3>
    b2fb:	85 c9                	test   %ecx,%ecx
    b2fd:	0f 84 25 06 00 00    	je     b928 <fwp_main_thread+0x778>
    b303:	48 8b 2d f6 e4 05 00 	mov    0x5e4f6(%rip),%rbp        # 69800 <fwp_cur>
    b30a:	48 85 ed             	test   %rbp,%rbp
    b30d:	0f 84 bd 01 00 00    	je     b4d0 <fwp_main_thread+0x320>
    b313:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    b318:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    b31c:	48 89 eb             	mov    %rbp,%rbx
    b31f:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b324:	0f 84 41 01 00 00    	je     b46b <fwp_main_thread+0x2bb>
    b32a:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    b32f:	0f 84 9b 02 00 00    	je     b5d0 <fwp_main_thread+0x420>
    b335:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b339:	0f 84 71 02 00 00    	je     b5b0 <fwp_main_thread+0x400>
    b33f:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b343:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b347:	0f 85 03 03 00 00    	jne    b650 <fwp_main_thread+0x4a0>
    b34d:	48 8b 43 60          	mov    0x60(%rbx),%rax
    b351:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b358:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b35c:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b363:	00 00 00 00 
    b367:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b36e:	48 85 d2             	test   %rdx,%rdx
    b371:	74 07                	je     b37a <fwp_main_thread+0x1ca>
    b373:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b37a:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b37e:	48 85 c0             	test   %rax,%rax
    b381:	74 34                	je     b3b7 <fwp_main_thread+0x207>
    b383:	48 89 43 68          	mov    %rax,0x68(%rbx)
    b387:	48 8b 05 4a e4 05 00 	mov    0x5e44a(%rip),%rax        # 697d8 <fwp_timers>
    b38e:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    b392:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    b399:	00 00 00 00 
    b39d:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    b3a4:	48 85 c0             	test   %rax,%rax
    b3a7:	74 07                	je     b3b0 <fwp_main_thread+0x200>
    b3a9:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    b3b0:	48 89 1d 21 e4 05 00 	mov    %rbx,0x5e421(%rip)        # 697d8 <fwp_timers>
    b3b7:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    b3bb:	e8 90 c9 ff ff       	call   7d50 <fwp_block>
    b3c0:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    b3c7:	48 85 c9             	test   %rcx,%rcx
    b3ca:	74 47                	je     b413 <fwp_main_thread+0x263>
    b3cc:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    b3d3:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b3da:	48 85 d2             	test   %rdx,%rdx
    b3dd:	0f 84 ad 02 00 00    	je     b690 <fwp_main_thread+0x4e0>
    b3e3:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    b3ea:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b3f1:	48 85 c0             	test   %rax,%rax
    b3f4:	74 07                	je     b3fd <fwp_main_thread+0x24d>
    b3f6:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    b3fd:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    b404:	00 00 00 00 
    b408:	66 0f ef d2          	pxor   %xmm2,%xmm2
    b40c:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    b413:	48 8b 0d e6 e3 05 00 	mov    0x5e3e6(%rip),%rcx        # 69800 <fwp_cur>
    b41a:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    b41e:	0f 84 1c 02 00 00    	je     b640 <fwp_main_thread+0x490>
    b424:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    b42b:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    b432:	48 85 d2             	test   %rdx,%rdx
    b435:	0f 84 95 04 00 00    	je     b8d0 <fwp_main_thread+0x720>
    b43b:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    b442:	48 85 c0             	test   %rax,%rax
    b445:	74 07                	je     b44e <fwp_main_thread+0x29e>
    b447:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    b44e:	66 0f ef db          	pxor   %xmm3,%xmm3
    b452:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    b456:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    b45d:	48 89 cb             	mov    %rcx,%rbx
    b460:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b465:	0f 85 bf fe ff ff    	jne    b32a <fwp_main_thread+0x17a>
    b46b:	48 83 3d 25 00 06 00 	cmpq   $0x0,0x60025(%rip)        # 6b498 <fwp_state_len>
    b472:	00 
    b473:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    b477:	74 67                	je     b4e0 <fwp_main_thread+0x330>
    b479:	48 39 1d 78 e3 05 00 	cmp    %rbx,0x5e378(%rip)        # 697f8 <fwp_root>
    b480:	c7 05 f6 5b 01 00 00 	movl   $0x0,0x15bf6(%rip)        # 21080 <fwp_exit_code>
    b487:	00 00 00 
    b48a:	0f 85 e5 0b 00 00    	jne    c075 <fwp_main_thread+0xec5>
    b490:	48 85 db             	test   %rbx,%rbx
    b493:	0f 84 1f 02 00 00    	je     b6b8 <fwp_main_thread+0x508>
    b499:	48 8b 15 28 e3 05 00 	mov    0x5e328(%rip),%rdx        # 697c8 <fwp_tasks_active>
    b4a0:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    b4a4:	48 85 d2             	test   %rdx,%rdx
    b4a7:	0f 84 0b 02 00 00    	je     b6b8 <fwp_main_thread+0x508>
    b4ad:	0f 1f 00             	nopl   (%rax)
    b4b0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    b4b4:	75 08                	jne    b4be <fwp_main_thread+0x30e>
    b4b6:	48 89 d7             	mov    %rdx,%rdi
    b4b9:	e8 72 8c ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b4be:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    b4c5:	48 85 d2             	test   %rdx,%rdx
    b4c8:	75 e6                	jne    b4b0 <fwp_main_thread+0x300>
    b4ca:	e9 ae 00 00 00       	jmp    b57d <fwp_main_thread+0x3cd>
    b4cf:	90                   	nop
    b4d0:	48 83 3d c0 ff 05 00 	cmpq   $0x0,0x5ffc0(%rip)        # 6b498 <fwp_state_len>
    b4d7:	00 
    b4d8:	0f 85 c2 01 00 00    	jne    b6a0 <fwp_main_thread+0x4f0>
    b4de:	31 db                	xor    %ebx,%ebx
    b4e0:	48 83 3d a0 ff 05 00 	cmpq   $0x0,0x5ffa0(%rip)        # 6b488 <fwp_state_owners>
    b4e7:	00 
    b4e8:	75 8f                	jne    b479 <fwp_main_thread+0x2c9>
    b4ea:	48 8b 3d af ff 05 00 	mov    0x5ffaf(%rip),%rdi        # 6b4a0 <fwp_state>
    b4f1:	e8 1a a5 ff ff       	call   5a10 <fwp_mem_free>
    b4f6:	48 c7 05 9f ff 05 00 	movq   $0x0,0x5ff9f(%rip)        # 6b4a0 <fwp_state>
    b4fd:	00 00 00 00 
    b501:	48 c7 05 84 ff 05 00 	movq   $0x0,0x5ff84(%rip)        # 6b490 <fwp_state_cap>
    b508:	00 00 00 00 
    b50c:	48 85 db             	test   %rbx,%rbx
    b50f:	0f 84 2d 0a 00 00    	je     bf42 <fwp_main_thread+0xd92>
    b515:	48 39 1d dc e2 05 00 	cmp    %rbx,0x5e2dc(%rip)        # 697f8 <fwp_root>
    b51c:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b523:	00 00 00 00 
    b527:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b52e:	00 00 00 00 
    b532:	c7 05 44 5b 01 00 00 	movl   $0x0,0x15b44(%rip)        # 21080 <fwp_exit_code>
    b539:	00 00 00 
    b53c:	0f 84 57 ff ff ff    	je     b499 <fwp_main_thread+0x2e9>
    b542:	e9 09 82 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b547:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b54e:	00 00 
    b550:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b557:	48 89 1d 82 e2 05 00 	mov    %rbx,0x5e282(%rip)        # 697e0 <fwp_ready_tail>
    b55e:	e8 ed c7 ff ff       	call   7d50 <fwp_block>
    b563:	e8 e8 c5 ff ff       	call   7b50 <fwp_free_zombie>
    b568:	48 83 3d 58 e2 05 00 	cmpq   $0x0,0x5e258(%rip)        # 697c8 <fwp_tasks_active>
    b56f:	00 
    b570:	0f 84 42 01 00 00    	je     b6b8 <fwp_main_thread+0x508>
    b576:	48 8b 1d 7b e2 05 00 	mov    0x5e27b(%rip),%rbx        # 697f8 <fwp_root>
    b57d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b581:	75 db                	jne    b55e <fwp_main_thread+0x3ae>
    b583:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b587:	75 d5                	jne    b55e <fwp_main_thread+0x3ae>
    b589:	48 8b 05 50 e2 05 00 	mov    0x5e250(%rip),%rax        # 697e0 <fwp_ready_tail>
    b590:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b594:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b59b:	00 00 00 00 
    b59f:	48 85 c0             	test   %rax,%rax
    b5a2:	75 ac                	jne    b550 <fwp_main_thread+0x3a0>
    b5a4:	48 89 1d 3d e2 05 00 	mov    %rbx,0x5e23d(%rip)        # 697e8 <fwp_ready_head>
    b5ab:	eb aa                	jmp    b557 <fwp_main_thread+0x3a7>
    b5ad:	0f 1f 00             	nopl   (%rax)
    b5b0:	e8 0b 90 ff ff       	call   45c0 <fwp_now_ns>
    b5b5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    b5b9:	7c 15                	jl     b5d0 <fwp_main_thread+0x420>
    b5bb:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b5bf:	75 0f                	jne    b5d0 <fwp_main_thread+0x420>
    b5c1:	48 89 ef             	mov    %rbp,%rdi
    b5c4:	e8 67 8b ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b5c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b5d0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b5d4:	0f 85 65 fd ff ff    	jne    b33f <fwp_main_thread+0x18f>
    b5da:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b5de:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b5e2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b5e6:	0f 85 65 fd ff ff    	jne    b351 <fwp_main_thread+0x1a1>
    b5ec:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b5f0:	48 85 c9             	test   %rcx,%rcx
    b5f3:	0f 84 58 fd ff ff    	je     b351 <fwp_main_thread+0x1a1>
    b5f9:	48 39 c8             	cmp    %rcx,%rax
    b5fc:	48 89 ce             	mov    %rcx,%rsi
    b5ff:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b606:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b60a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b611:	00 00 00 00 
    b615:	48 0f 4e f0          	cmovle %rax,%rsi
    b619:	48 85 c0             	test   %rax,%rax
    b61c:	48 89 c8             	mov    %rcx,%rax
    b61f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b626:	48 0f 45 c6          	cmovne %rsi,%rax
    b62a:	48 85 d2             	test   %rdx,%rdx
    b62d:	74 07                	je     b636 <fwp_main_thread+0x486>
    b62f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b636:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b63a:	e9 44 fd ff ff       	jmp    b383 <fwp_main_thread+0x1d3>
    b63f:	90                   	nop
    b640:	48 89 cb             	mov    %rcx,%rbx
    b643:	e9 d7 fc ff ff       	jmp    b31f <fwp_main_thread+0x16f>
    b648:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b64f:	00 
    b650:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b654:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b65b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b662:	00 00 00 00 
    b666:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b66d:	48 85 c0             	test   %rax,%rax
    b670:	0f 84 4a 08 00 00    	je     bec0 <fwp_main_thread+0xd10>
    b676:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b67d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b681:	e9 31 fd ff ff       	jmp    b3b7 <fwp_main_thread+0x207>
    b686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b68d:	00 00 00 
    b690:	48 89 01             	mov    %rax,(%rcx)
    b693:	e9 59 fd ff ff       	jmp    b3f1 <fwp_main_thread+0x241>
    b698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b69f:	00 
    b6a0:	48 83 3d 50 e1 05 00 	cmpq   $0x0,0x5e150(%rip)        # 697f8 <fwp_root>
    b6a7:	00 
    b6a8:	c7 05 ce 59 01 00 00 	movl   $0x0,0x159ce(%rip)        # 21080 <fwp_exit_code>
    b6af:	00 00 00 
    b6b2:	0f 85 b8 09 00 00    	jne    c070 <fwp_main_thread+0xec0>
    b6b8:	e8 93 c4 ff ff       	call   7b50 <fwp_free_zombie>
    b6bd:	48 83 3d 23 e1 05 00 	cmpq   $0x0,0x5e123(%rip)        # 697e8 <fwp_ready_head>
    b6c4:	00 
    b6c5:	0f 85 85 80 ff ff    	jne    3750 <fwp_main_thread.cold>
    b6cb:	48 83 3d 05 e1 05 00 	cmpq   $0x0,0x5e105(%rip)        # 697d8 <fwp_timers>
    b6d2:	00 
    b6d3:	0f 85 77 80 ff ff    	jne    3750 <fwp_main_thread.cold>
    b6d9:	8b 05 f5 da 05 00    	mov    0x5daf5(%rip),%eax        # 691d4 <fwp_stack_pool_n>
    b6df:	85 c0                	test   %eax,%eax
    b6e1:	74 3a                	je     b71d <fwp_main_thread+0x56d>
    b6e3:	83 e8 01             	sub    $0x1,%eax
    b6e6:	4c 8d 25 f3 da 05 00 	lea    0x5daf3(%rip),%r12        # 691e0 <fwp_stack_pool>
    b6ed:	48 63 d8             	movslq %eax,%rbx
    b6f0:	89 c0                	mov    %eax,%eax
    b6f2:	48 89 da             	mov    %rbx,%rdx
    b6f5:	48 29 c2             	sub    %rax,%rdx
    b6f8:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    b6fc:	0f 1f 40 00          	nopl   0x0(%rax)
    b700:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b704:	89 1d ca da 05 00    	mov    %ebx,0x5daca(%rip)        # 691d4 <fwp_stack_pool_n>
    b70a:	be 00 00 00 10       	mov    $0x10000000,%esi
    b70f:	48 83 eb 01          	sub    $0x1,%rbx
    b713:	e8 a8 7e ff ff       	call   35c0 <munmap@plt>
    b718:	48 39 dd             	cmp    %rbx,%rbp
    b71b:	75 e3                	jne    b700 <fwp_main_thread+0x550>
    b71d:	8b 3d f5 58 00 00    	mov    0x58f5(%rip),%edi        # 11018 <fwp_epfd>
    b723:	85 ff                	test   %edi,%edi
    b725:	78 05                	js     b72c <fwp_main_thread+0x57c>
    b727:	e8 94 7d ff ff       	call   34c0 <close@plt>
    b72c:	4c 8b 25 ad dc 05 00 	mov    0x5dcad(%rip),%r12        # 693e0 <fwp_nfdws>
    b733:	48 8b 2d ae dc 05 00 	mov    0x5dcae(%rip),%rbp        # 693e8 <fwp_fdws>
    b73a:	31 db                	xor    %ebx,%ebx
    b73c:	c7 05 d2 58 00 00 ff 	movl   $0xffffffff,0x58d2(%rip)        # 11018 <fwp_epfd>
    b743:	ff ff ff 
    b746:	4d 85 e4             	test   %r12,%r12
    b749:	74 32                	je     b77d <fwp_main_thread+0x5cd>
    b74b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b750:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b755:	48 85 ff             	test   %rdi,%rdi
    b758:	74 1a                	je     b774 <fwp_main_thread+0x5c4>
    b75a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b75e:	0f 85 ec 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b764:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b769:	0f 85 e1 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b76f:	e8 9c a2 ff ff       	call   5a10 <fwp_mem_free>
    b774:	48 83 c3 01          	add    $0x1,%rbx
    b778:	49 39 dc             	cmp    %rbx,%r12
    b77b:	75 d3                	jne    b750 <fwp_main_thread+0x5a0>
    b77d:	48 89 ef             	mov    %rbp,%rdi
    b780:	e8 8b a2 ff ff       	call   5a10 <fwp_mem_free>
    b785:	48 8b 15 6c e0 05 00 	mov    0x5e06c(%rip),%rdx        # 697f8 <fwp_root>
    b78c:	48 c7 05 51 dc 05 00 	movq   $0x0,0x5dc51(%rip)        # 693e8 <fwp_fdws>
    b793:	00 00 00 00 
    b797:	48 c7 05 3e dc 05 00 	movq   $0x0,0x5dc3e(%rip)        # 693e0 <fwp_nfdws>
    b79e:	00 00 00 00 
    b7a2:	48 85 d2             	test   %rdx,%rdx
    b7a5:	74 4e                	je     b7f5 <fwp_main_thread+0x645>
    b7a7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b7ac:	0f 85 9e 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b7b2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b7b9:	00 
    b7ba:	0f 85 90 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b7c0:	48 83 3d d0 fc 05 00 	cmpq   $0x0,0x5fcd0(%rip)        # 6b498 <fwp_state_len>
    b7c7:	00 
    b7c8:	0f 85 82 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b7ce:	48 83 3d b2 fc 05 00 	cmpq   $0x0,0x5fcb2(%rip)        # 6b488 <fwp_state_owners>
    b7d5:	00 
    b7d6:	0f 85 74 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b7dc:	b9 79 00 00 00       	mov    $0x79,%ecx
    b7e1:	31 c0                	xor    %eax,%eax
    b7e3:	48 8d 3d 16 dc 05 00 	lea    0x5dc16(%rip),%rdi        # 69400 <fwp_root_context>
    b7ea:	f3 48 ab             	rep stos %rax,(%rdi)
    b7ed:	48 89 d7             	mov    %rdx,%rdi
    b7f0:	e8 1b a2 ff ff       	call   5a10 <fwp_mem_free>
    b7f5:	66 0f 6f 05 b3 59 04 	movdqa 0x459b3(%rip),%xmm0        # 511b0 <ad_raw_live+0x10>
    b7fc:	00 
    b7fd:	66 0f d4 05 9b 59 04 	paddq  0x4599b(%rip),%xmm0        # 511a0 <ad_raw_live>
    b804:	00 
    b805:	48 c7 05 f0 df 05 00 	movq   $0x0,0x5dff0(%rip)        # 69800 <fwp_cur>
    b80c:	00 00 00 00 
    b810:	48 8b 05 29 f4 05 00 	mov    0x5f429(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    b817:	48 c7 05 d6 df 05 00 	movq   $0x0,0x5dfd6(%rip)        # 697f8 <fwp_root>
    b81e:	00 00 00 00 
    b822:	c7 05 bc fc 05 00 00 	movl   $0x0,0x5fcbc(%rip)        # 6b4e8 <iteration_active>
    b829:	00 00 00 
    b82c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    b830:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    b835:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    b839:	66 0f d6 05 b7 58 01 	movq   %xmm0,0x158b7(%rip)        # 210f8 <ad_raw_before_shutdown>
    b840:	00 
    b841:	48 85 c0             	test   %rax,%rax
    b844:	0f 88 56 06 00 00    	js     bea0 <fwp_main_thread+0xcf0>
    b84a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b84e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    b853:	f2 0f 5c 0d 6d fc 05 	subsd  0x5fc6d(%rip),%xmm1        # 6b4c8 <iteration_start_charge>
    b85a:	00 
    b85b:	48 8b 3d de 57 00 00 	mov    0x57de(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    b862:	48 8d 15 f7 22 00 00 	lea    0x22f7(%rip),%rdx        # db60 <_IO_stdin_used+0xb60>
    b869:	be 02 00 00 00       	mov    $0x2,%esi
    b86e:	f2 0f 10 05 4a fc 05 	movsd  0x5fc4a(%rip),%xmm0        # 6b4c0 <iteration_peak>
    b875:	00 
    b876:	4c 8b 0d 53 fc 05 00 	mov    0x5fc53(%rip),%r9        # 6b4d0 <iteration_retains>
    b87d:	b8 02 00 00 00       	mov    $0x2,%eax
    b882:	4c 8b 05 4f fc 05 00 	mov    0x5fc4f(%rip),%r8        # 6b4d8 <iteration_bytes>
    b889:	48 8b 0d 50 fc 05 00 	mov    0x5fc50(%rip),%rcx        # 6b4e0 <iteration_requests>
    b890:	e8 db 7d ff ff       	call   3670 <__fprintf_chk@plt>
    b895:	48 8b 3d 84 57 00 00 	mov    0x5784(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    b89c:	e8 ff 7c ff ff       	call   35a0 <fflush@plt>
    b8a1:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b8a8:	00 
    b8a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b8b0:	00 00 
    b8b2:	0f 85 a7 07 00 00    	jne    c05f <fwp_main_thread+0xeaf>
    b8b8:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b8bf:	31 c0                	xor    %eax,%eax
    b8c1:	5b                   	pop    %rbx
    b8c2:	5d                   	pop    %rbp
    b8c3:	41 5c                	pop    %r12
    b8c5:	41 5d                	pop    %r13
    b8c7:	41 5e                	pop    %r14
    b8c9:	41 5f                	pop    %r15
    b8cb:	c3                   	ret
    b8cc:	0f 1f 40 00          	nopl   0x0(%rax)
    b8d0:	48 89 05 01 df 05 00 	mov    %rax,0x5df01(%rip)        # 697d8 <fwp_timers>
    b8d7:	e9 66 fb ff ff       	jmp    b442 <fwp_main_thread+0x292>
    b8dc:	0f 1f 40 00          	nopl   0x0(%rax)
    b8e0:	48 89 c2             	mov    %rax,%rdx
    b8e3:	83 e0 01             	and    $0x1,%eax
    b8e6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b8ea:	48 d1 ea             	shr    $1,%rdx
    b8ed:	48 09 c2             	or     %rax,%rdx
    b8f0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    b8f5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    b8f9:	e9 d1 f9 ff ff       	jmp    b2cf <fwp_main_thread+0x11f>
    b8fe:	66 90                	xchg   %ax,%ax
    b900:	e8 cb 94 ff ff       	call   4dd0 <fwp_heap_init>
    b905:	8b 35 bd f2 05 00    	mov    0x5f2bd(%rip),%esi        # 6abc8 <fwp_heap+0x13a8>
    b90b:	85 f6                	test   %esi,%esi
    b90d:	0f 84 e1 f8 ff ff    	je     b1f4 <fwp_main_thread+0x44>
    b913:	48 8d 3d a6 93 ff ff 	lea    -0x6c5a(%rip),%rdi        # 4cc0 <fwp_heap_report>
    b91a:	e8 71 09 00 00       	call   c290 <atexit>
    b91f:	e9 d0 f8 ff ff       	jmp    b1f4 <fwp_main_thread+0x44>
    b924:	0f 1f 40 00          	nopl   0x0(%rax)
    b928:	48 8d 05 41 bb ff ff 	lea    -0x44bf(%rip),%rax        # 7470 <fwp_drop1>
    b92f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b933:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b93a:	00 00 
    b93c:	41 be ff 7f 00 00    	mov    $0x7fff,%r14d
    b942:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b947:	48 8b 05 6a fb 05 00 	mov    0x5fb6a(%rip),%rax        # 6b4b8 <fwp_cleanups>
    b94e:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
    b953:	4c 8d 25 c6 de 05 00 	lea    0x5dec6(%rip),%r12        # 69820 <fwp_heap>
    b95a:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b95e:	48 89 1d 53 fb 05 00 	mov    %rbx,0x5fb53(%rip)        # 6b4b8 <fwp_cleanups>
    b965:	31 db                	xor    %ebx,%ebx
    b967:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b96c:	48 8d 05 5d 82 ff ff 	lea    -0x7da3(%rip),%rax        # 3bd0 <fwp_range_release>
    b973:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b978:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b97d:	eb 3b                	jmp    b9ba <fwp_main_thread+0x80a>
    b97f:	90                   	nop
    b980:	40 80 fe 01          	cmp    $0x1,%sil
    b984:	75 25                	jne    b9ab <fwp_main_thread+0x7fb>
    b986:	8b 71 18             	mov    0x18(%rcx),%esi
    b989:	0f b7 c0             	movzwl %ax,%eax
    b98c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b98f:	48 0f af c6          	imul   %rsi,%rax
    b993:	48 c1 e8 20          	shr    $0x20,%rax
    b997:	48 39 c8             	cmp    %rcx,%rax
    b99a:	73 0f                	jae    b9ab <fwp_main_thread+0x7fb>
    b99c:	48 01 c2             	add    %rax,%rdx
    b99f:	80 3a ff             	cmpb   $0xff,(%rdx)
    b9a2:	0f 84 68 05 00 00    	je     bf10 <fwp_main_thread+0xd60>
    b9a8:	c6 02 01             	movb   $0x1,(%rdx)
    b9ab:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    b9b0:	49 83 ee 01          	sub    $0x1,%r14
    b9b4:	0f 82 86 00 00 00    	jb     ba40 <fwp_main_thread+0x890>
    b9ba:	4c 89 ee             	mov    %r13,%rsi
    b9bd:	bf 01 00 00 00       	mov    $0x1,%edi
    b9c2:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
    b9c9:	00 
    b9ca:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
    b9cf:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
    b9d6:	00 
    b9d7:	e8 74 b3 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    b9dc:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b9e3:	00 
    b9e4:	48 89 c3             	mov    %rax,%rbx
    b9e7:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b9ee:	00 
    b9ef:	48 c1 e2 10          	shl    $0x10,%rdx
    b9f3:	48 39 d0             	cmp    %rdx,%rax
    b9f6:	73 b3                	jae    b9ab <fwp_main_thread+0x7fb>
    b9f8:	48 89 c2             	mov    %rax,%rdx
    b9fb:	48 c1 ea 10          	shr    $0x10,%rdx
    b9ff:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba03:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    ba0a:	00 
    ba0b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    ba0f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    ba13:	48 85 d2             	test   %rdx,%rdx
    ba16:	74 93                	je     b9ab <fwp_main_thread+0x7fb>
    ba18:	0f b6 31             	movzbl (%rcx),%esi
    ba1b:	40 80 fe 02          	cmp    $0x2,%sil
    ba1f:	0f 85 5b ff ff ff    	jne    b980 <fwp_main_thread+0x7d0>
    ba25:	66 85 c0             	test   %ax,%ax
    ba28:	0f 84 71 ff ff ff    	je     b99f <fwp_main_thread+0x7ef>
    ba2e:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    ba33:	49 83 ee 01          	sub    $0x1,%r14
    ba37:	73 81                	jae    b9ba <fwp_main_thread+0x80a>
    ba39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ba40:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ba45:	66 0f 6f 05 83 23 00 	movdqa 0x2383(%rip),%xmm0        # ddd0 <msg.4+0xa0>
    ba4c:	00 
    ba4d:	4c 89 ee             	mov    %r13,%rsi
    ba50:	bf 01 00 00 00       	mov    $0x1,%edi
    ba55:	48 89 05 5c fa 05 00 	mov    %rax,0x5fa5c(%rip)        # 6b4b8 <fwp_cleanups>
    ba5c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    ba63:	00 
    ba64:	e8 e7 b2 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ba69:	48 8b 15 88 f1 05 00 	mov    0x5f188(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    ba70:	49 89 c6             	mov    %rax,%r14
    ba73:	48 2b 05 56 f1 05 00 	sub    0x5f156(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    ba7a:	48 c1 e2 10          	shl    $0x10,%rdx
    ba7e:	48 39 d0             	cmp    %rdx,%rax
    ba81:	73 59                	jae    badc <fwp_main_thread+0x92c>
    ba83:	48 89 c2             	mov    %rax,%rdx
    ba86:	48 c1 ea 10          	shr    $0x10,%rdx
    ba8a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba8e:	48 8b 15 83 f1 05 00 	mov    0x5f183(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    ba95:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ba99:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    ba9d:	4d 85 ed             	test   %r13,%r13
    baa0:	74 3a                	je     badc <fwp_main_thread+0x92c>
    baa2:	0f b6 0a             	movzbl (%rdx),%ecx
    baa5:	80 f9 02             	cmp    $0x2,%cl
    baa8:	0f 84 52 04 00 00    	je     bf00 <fwp_main_thread+0xd50>
    baae:	80 f9 01             	cmp    $0x1,%cl
    bab1:	75 29                	jne    badc <fwp_main_thread+0x92c>
    bab3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bab6:	0f b7 c0             	movzwl %ax,%eax
    bab9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    babc:	48 0f af c1          	imul   %rcx,%rax
    bac0:	48 c1 e8 20          	shr    $0x20,%rax
    bac4:	48 39 d0             	cmp    %rdx,%rax
    bac7:	73 13                	jae    badc <fwp_main_thread+0x92c>
    bac9:	49 01 c5             	add    %rax,%r13
    bacc:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    bad1:	0f 84 c2 04 00 00    	je     bf99 <fwp_main_thread+0xde9>
    bad7:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    badc:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    bae1:	bf 01 00 00 00       	mov    $0x1,%edi
    bae6:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    baeb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    baf2:	00 f0 3f 
    baf5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    bafa:	e8 51 b2 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    baff:	48 8b 15 f2 f0 05 00 	mov    0x5f0f2(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    bb06:	49 89 c6             	mov    %rax,%r14
    bb09:	48 2b 05 c0 f0 05 00 	sub    0x5f0c0(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    bb10:	48 c1 e2 10          	shl    $0x10,%rdx
    bb14:	48 39 d0             	cmp    %rdx,%rax
    bb17:	73 59                	jae    bb72 <fwp_main_thread+0x9c2>
    bb19:	48 89 c2             	mov    %rax,%rdx
    bb1c:	48 c1 ea 10          	shr    $0x10,%rdx
    bb20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bb24:	48 8b 15 ed f0 05 00 	mov    0x5f0ed(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    bb2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bb2f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    bb33:	4d 85 ed             	test   %r13,%r13
    bb36:	74 3a                	je     bb72 <fwp_main_thread+0x9c2>
    bb38:	0f b6 0a             	movzbl (%rdx),%ecx
    bb3b:	80 f9 02             	cmp    $0x2,%cl
    bb3e:	0f 84 ac 03 00 00    	je     bef0 <fwp_main_thread+0xd40>
    bb44:	80 f9 01             	cmp    $0x1,%cl
    bb47:	75 29                	jne    bb72 <fwp_main_thread+0x9c2>
    bb49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bb4c:	0f b7 c0             	movzwl %ax,%eax
    bb4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bb52:	48 0f af c1          	imul   %rcx,%rax
    bb56:	48 c1 e8 20          	shr    $0x20,%rax
    bb5a:	48 39 d0             	cmp    %rdx,%rax
    bb5d:	73 13                	jae    bb72 <fwp_main_thread+0x9c2>
    bb5f:	49 01 c5             	add    %rax,%r13
    bb62:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    bb67:	0f 84 39 04 00 00    	je     bfa6 <fwp_main_thread+0xdf6>
    bb6d:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    bb72:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    bb77:	bf 01 00 00 00       	mov    $0x1,%edi
    bb7c:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    bb81:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bb88:	33 f3 bf 
    bb8b:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    bb90:	e8 bb b1 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    bb95:	48 8b 15 5c f0 05 00 	mov    0x5f05c(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    bb9c:	48 8b 0d 2d f0 05 00 	mov    0x5f02d(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    bba3:	49 89 c5             	mov    %rax,%r13
    bba6:	48 89 d6             	mov    %rdx,%rsi
    bba9:	48 29 c8             	sub    %rcx,%rax
    bbac:	48 c1 e6 10          	shl    $0x10,%rsi
    bbb0:	48 39 f0             	cmp    %rsi,%rax
    bbb3:	73 67                	jae    bc1c <fwp_main_thread+0xa6c>
    bbb5:	48 89 c6             	mov    %rax,%rsi
    bbb8:	48 c1 ee 10          	shr    $0x10,%rsi
    bbbc:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    bbc0:	48 8b 35 51 f0 05 00 	mov    0x5f051(%rip),%rsi        # 6ac18 <fwp_heap+0x13f8>
    bbc7:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    bbcb:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    bbcf:	4d 85 f6             	test   %r14,%r14
    bbd2:	74 48                	je     bc1c <fwp_main_thread+0xa6c>
    bbd4:	0f b6 3e             	movzbl (%rsi),%edi
    bbd7:	40 80 ff 02          	cmp    $0x2,%dil
    bbdb:	0f 84 ff 02 00 00    	je     bee0 <fwp_main_thread+0xd30>
    bbe1:	40 80 ff 01          	cmp    $0x1,%dil
    bbe5:	75 35                	jne    bc1c <fwp_main_thread+0xa6c>
    bbe7:	8b 7e 18             	mov    0x18(%rsi),%edi
    bbea:	0f b7 c0             	movzwl %ax,%eax
    bbed:	8b 76 1c             	mov    0x1c(%rsi),%esi
    bbf0:	48 0f af c7          	imul   %rdi,%rax
    bbf4:	48 c1 e8 20          	shr    $0x20,%rax
    bbf8:	48 39 f0             	cmp    %rsi,%rax
    bbfb:	73 1f                	jae    bc1c <fwp_main_thread+0xa6c>
    bbfd:	49 01 c6             	add    %rax,%r14
    bc00:	41 80 3e ff          	cmpb   $0xff,(%r14)
    bc04:	0f 84 a9 03 00 00    	je     bfb3 <fwp_main_thread+0xe03>
    bc0a:	41 c6 06 01          	movb   $0x1,(%r14)
    bc0e:	48 8b 0d bb ef 05 00 	mov    0x5efbb(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    bc15:	48 8b 15 dc ef 05 00 	mov    0x5efdc(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    bc1c:	48 89 1c 24          	mov    %rbx,(%rsp)
    bc20:	4c 89 e8             	mov    %r13,%rax
    bc23:	48 c1 e2 10          	shl    $0x10,%rdx
    bc27:	48 29 c8             	sub    %rcx,%rax
    bc2a:	48 39 d0             	cmp    %rdx,%rax
    bc2d:	73 70                	jae    bc9f <fwp_main_thread+0xaef>
    bc2f:	48 89 c2             	mov    %rax,%rdx
    bc32:	48 c1 ea 10          	shr    $0x10,%rdx
    bc36:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bc3a:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    bc41:	00 
    bc42:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bc46:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    bc4a:	48 85 ff             	test   %rdi,%rdi
    bc4d:	74 50                	je     bc9f <fwp_main_thread+0xaef>
    bc4f:	0f b6 0a             	movzbl (%rdx),%ecx
    bc52:	80 f9 02             	cmp    $0x2,%cl
    bc55:	0f 84 75 02 00 00    	je     bed0 <fwp_main_thread+0xd20>
    bc5b:	80 f9 01             	cmp    $0x1,%cl
    bc5e:	75 3f                	jne    bc9f <fwp_main_thread+0xaef>
    bc60:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bc63:	0f b7 c0             	movzwl %ax,%eax
    bc66:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bc69:	48 0f af c1          	imul   %rcx,%rax
    bc6d:	48 c1 e8 20          	shr    $0x20,%rax
    bc71:	48 39 d0             	cmp    %rdx,%rax
    bc74:	73 29                	jae    bc9f <fwp_main_thread+0xaef>
    bc76:	48 01 c7             	add    %rax,%rdi
    bc79:	0f b6 07             	movzbl (%rdi),%eax
    bc7c:	84 c0                	test   %al,%al
    bc7e:	74 1f                	je     bc9f <fwp_main_thread+0xaef>
    bc80:	8b 15 62 f8 05 00    	mov    0x5f862(%rip),%edx        # 6b4e8 <iteration_active>
    bc86:	85 d2                	test   %edx,%edx
    bc88:	74 08                	je     bc92 <fwp_main_thread+0xae2>
    bc8a:	48 83 05 3e f8 05 00 	addq   $0x1,0x5f83e(%rip)        # 6b4d0 <iteration_retains>
    bc91:	01 
    bc92:	3c fd                	cmp    $0xfd,%al
    bc94:	0f 87 26 03 00 00    	ja     bfc0 <fwp_main_thread+0xe10>
    bc9a:	83 c0 01             	add    $0x1,%eax
    bc9d:	88 07                	mov    %al,(%rdi)
    bc9f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bca3:	b9 01 00 00 00       	mov    $0x1,%ecx
    bca8:	4c 89 ee             	mov    %r13,%rsi
    bcab:	48 89 ef             	mov    %rbp,%rdi
    bcae:	48 8d 15 eb 4e 00 00 	lea    0x4eeb(%rip),%rdx        # 10ba0 <d0>
    bcb5:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    bcba:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    bcc1:	00 00 
    bcc3:	e8 a8 e4 ff ff       	call   a170 <fwp_write>
    bcc8:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    bccd:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
    bcd2:	48 8d 05 93 13 00 00 	lea    0x1393(%rip),%rax        # d06c <_IO_stdin_used+0x6c>
    bcd9:	4d 85 f6             	test   %r14,%r14
    bcdc:	4c 0f 44 f0          	cmove  %rax,%r14
    bce0:	48 83 fa f6          	cmp    $0xfffffffffffffff6,%rdx
    bce4:	0f 87 7a 03 00 00    	ja     c064 <fwp_main_thread+0xeb4>
    bcea:	48 8d 7a 09          	lea    0x9(%rdx),%rdi
    bcee:	be 01 00 00 00       	mov    $0x1,%esi
    bcf3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    bcf8:	e8 13 a2 ff ff       	call   5f10 <fwp_heap_alloc>
    bcfd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    bd02:	4c 89 f6             	mov    %r14,%rsi
    bd05:	48 8d 78 08          	lea    0x8(%rax),%rdi
    bd09:	49 89 c7             	mov    %rax,%r15
    bd0c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    bd11:	48 89 10             	mov    %rdx,(%rax)
    bd14:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    bd19:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    bd1e:	e8 5d 78 ff ff       	call   3580 <memcpy@plt>
    bd23:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    bd28:	41 c6 44 17 08 00    	movb   $0x0,0x8(%r15,%rdx,1)
    bd2e:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    bd33:	e8 78 76 ff ff       	call   33b0 <free@plt>
    bd38:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    bd3f:	00 
    bd40:	4d 2b bc 24 b0 13 00 	sub    0x13b0(%r12),%r15
    bd47:	00 
    bd48:	48 c1 e2 10          	shl    $0x10,%rdx
    bd4c:	49 39 d7             	cmp    %rdx,%r15
    bd4f:	73 59                	jae    bdaa <fwp_main_thread+0xbfa>
    bd51:	4c 89 fa             	mov    %r15,%rdx
    bd54:	48 c1 ea 10          	shr    $0x10,%rdx
    bd58:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd5c:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    bd63:	00 
    bd64:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd68:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    bd6c:	4d 85 f6             	test   %r14,%r14
    bd6f:	74 39                	je     bdaa <fwp_main_thread+0xbfa>
    bd71:	0f b6 0a             	movzbl (%rdx),%ecx
    bd74:	80 f9 02             	cmp    $0x2,%cl
    bd77:	0f 84 b6 01 00 00    	je     bf33 <fwp_main_thread+0xd83>
    bd7d:	80 f9 01             	cmp    $0x1,%cl
    bd80:	75 28                	jne    bdaa <fwp_main_thread+0xbfa>
    bd82:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bd85:	41 0f b7 c7          	movzwl %r15w,%eax
    bd89:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bd8c:	48 0f af c1          	imul   %rcx,%rax
    bd90:	48 c1 e8 20          	shr    $0x20,%rax
    bd94:	48 39 d0             	cmp    %rdx,%rax
    bd97:	73 11                	jae    bdaa <fwp_main_thread+0xbfa>
    bd99:	49 01 c6             	add    %rax,%r14
    bd9c:	41 80 3e ff          	cmpb   $0xff,(%r14)
    bda0:	0f 84 24 02 00 00    	je     bfca <fwp_main_thread+0xe1a>
    bda6:	41 c6 06 01          	movb   $0x1,(%r14)
    bdaa:	4c 89 ef             	mov    %r13,%rdi
    bdad:	e8 3e b5 ff ff       	call   72f0 <fwp_drop0>
    bdb2:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    bdb7:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    bdbc:	be 01 00 00 00       	mov    $0x1,%esi
    bdc1:	48 8b 0d b8 f6 05 00 	mov    0x5f6b8(%rip),%rcx        # 6b480 <fwp_prog_out>
    bdc8:	49 8b 17             	mov    (%r15),%rdx
    bdcb:	e8 90 78 ff ff       	call   3660 <fwrite@plt>
    bdd0:	48 8b 35 a9 f6 05 00 	mov    0x5f6a9(%rip),%rsi        # 6b480 <fwp_prog_out>
    bdd7:	bf 0a 00 00 00       	mov    $0xa,%edi
    bddc:	e8 ef 76 ff ff       	call   34d0 <fputc@plt>
    bde1:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    bde8:	00 
    bde9:	4c 89 f8             	mov    %r15,%rax
    bdec:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    bdf3:	00 
    bdf4:	48 c1 e2 10          	shl    $0x10,%rdx
    bdf8:	48 39 d0             	cmp    %rdx,%rax
    bdfb:	73 73                	jae    be70 <fwp_main_thread+0xcc0>
    bdfd:	48 89 c2             	mov    %rax,%rdx
    be00:	48 c1 ea 10          	shr    $0x10,%rdx
    be04:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be08:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    be0f:	00 
    be10:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be14:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    be18:	4d 85 f6             	test   %r14,%r14
    be1b:	74 53                	je     be70 <fwp_main_thread+0xcc0>
    be1d:	0f b6 0a             	movzbl (%rdx),%ecx
    be20:	80 f9 02             	cmp    $0x2,%cl
    be23:	0f 84 fc 00 00 00    	je     bf25 <fwp_main_thread+0xd75>
    be29:	80 f9 01             	cmp    $0x1,%cl
    be2c:	75 42                	jne    be70 <fwp_main_thread+0xcc0>
    be2e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be31:	0f b7 c0             	movzwl %ax,%eax
    be34:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be37:	48 0f af c1          	imul   %rcx,%rax
    be3b:	48 c1 e8 20          	shr    $0x20,%rax
    be3f:	48 39 d0             	cmp    %rdx,%rax
    be42:	73 2c                	jae    be70 <fwp_main_thread+0xcc0>
    be44:	49 01 c6             	add    %rax,%r14
    be47:	41 0f b6 06          	movzbl (%r14),%eax
    be4b:	84 c0                	test   %al,%al
    be4d:	74 21                	je     be70 <fwp_main_thread+0xcc0>
    be4f:	3c 01                	cmp    $0x1,%al
    be51:	0f 84 33 01 00 00    	je     bf8a <fwp_main_thread+0xdda>
    be57:	3c ff                	cmp    $0xff,%al
    be59:	0f 84 78 01 00 00    	je     bfd7 <fwp_main_thread+0xe27>
    be5f:	83 e8 01             	sub    $0x1,%eax
    be62:	41 88 06             	mov    %al,(%r14)
    be65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    be6c:	00 00 00 00 
    be70:	48 8b 04 24          	mov    (%rsp),%rax
    be74:	48 8b 40 10          	mov    0x10(%rax),%rax
    be78:	48 89 04 24          	mov    %rax,(%rsp)
    be7c:	48 85 c0             	test   %rax,%rax
    be7f:	0f 84 db 00 00 00    	je     bf60 <fwp_main_thread+0xdb0>
    be85:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    be8c:	00 
    be8d:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    be94:	00 
    be95:	e9 86 fd ff ff       	jmp    bc20 <fwp_main_thread+0xa70>
    be9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bea0:	48 89 c2             	mov    %rax,%rdx
    bea3:	83 e0 01             	and    $0x1,%eax
    bea6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    beaa:	48 d1 ea             	shr    $1,%rdx
    bead:	48 09 c2             	or     %rax,%rdx
    beb0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    beb5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    beb9:	e9 95 f9 ff ff       	jmp    b853 <fwp_main_thread+0x6a3>
    bebe:	66 90                	xchg   %ax,%ax
    bec0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    bec4:	e9 ee f4 ff ff       	jmp    b3b7 <fwp_main_thread+0x207>
    bec9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    bed0:	66 85 c0             	test   %ax,%ax
    bed3:	0f 85 c6 fd ff ff    	jne    bc9f <fwp_main_thread+0xaef>
    bed9:	e9 9b fd ff ff       	jmp    bc79 <fwp_main_thread+0xac9>
    bede:	66 90                	xchg   %ax,%ax
    bee0:	66 85 c0             	test   %ax,%ax
    bee3:	0f 85 33 fd ff ff    	jne    bc1c <fwp_main_thread+0xa6c>
    bee9:	e9 12 fd ff ff       	jmp    bc00 <fwp_main_thread+0xa50>
    beee:	66 90                	xchg   %ax,%ax
    bef0:	66 85 c0             	test   %ax,%ax
    bef3:	0f 85 79 fc ff ff    	jne    bb72 <fwp_main_thread+0x9c2>
    bef9:	e9 64 fc ff ff       	jmp    bb62 <fwp_main_thread+0x9b2>
    befe:	66 90                	xchg   %ax,%ax
    bf00:	66 85 c0             	test   %ax,%ax
    bf03:	0f 85 d3 fb ff ff    	jne    badc <fwp_main_thread+0x92c>
    bf09:	e9 be fb ff ff       	jmp    bacc <fwp_main_thread+0x91c>
    bf0e:	66 90                	xchg   %ax,%ax
    bf10:	48 89 d7             	mov    %rdx,%rdi
    bf13:	48 89 14 24          	mov    %rdx,(%rsp)
    bf17:	e8 b4 98 ff ff       	call   57d0 <fwp_rc_forget_slot>
    bf1c:	48 8b 14 24          	mov    (%rsp),%rdx
    bf20:	e9 83 fa ff ff       	jmp    b9a8 <fwp_main_thread+0x7f8>
    bf25:	66 85 c0             	test   %ax,%ax
    bf28:	0f 85 42 ff ff ff    	jne    be70 <fwp_main_thread+0xcc0>
    bf2e:	e9 14 ff ff ff       	jmp    be47 <fwp_main_thread+0xc97>
    bf33:	66 45 85 ff          	test   %r15w,%r15w
    bf37:	0f 85 6d fe ff ff    	jne    bdaa <fwp_main_thread+0xbfa>
    bf3d:	e9 5a fe ff ff       	jmp    bd9c <fwp_main_thread+0xbec>
    bf42:	48 83 3d ae d8 05 00 	cmpq   $0x0,0x5d8ae(%rip)        # 697f8 <fwp_root>
    bf49:	00 
    bf4a:	c7 05 2c 51 01 00 00 	movl   $0x0,0x1512c(%rip)        # 21080 <fwp_exit_code>
    bf51:	00 00 00 
    bf54:	0f 84 5e f7 ff ff    	je     b6b8 <fwp_main_thread+0x508>
    bf5a:	e9 f1 77 ff ff       	jmp    3750 <fwp_main_thread.cold>
    bf5f:	90                   	nop
    bf60:	4c 89 ef             	mov    %r13,%rdi
    bf63:	e8 88 b3 ff ff       	call   72f0 <fwp_drop0>
    bf68:	48 89 df             	mov    %rbx,%rdi
    bf6b:	e8 80 b3 ff ff       	call   72f0 <fwp_drop0>
    bf70:	48 c7 05 ed 50 00 00 	movq   $0x0,0x50ed(%rip)        # 11068 <v.2>
    bf77:	00 00 00 00 
    bf7b:	c7 05 eb 50 00 00 01 	movl   $0x1,0x50eb(%rip)        # 11070 <st.3>
    bf82:	00 00 00 
    bf85:	e9 79 f3 ff ff       	jmp    b303 <fwp_main_thread+0x153>
    bf8a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    bf8f:	e8 2c b0 ff ff       	call   6fc0 <fwp_rc_free_arr>
    bf94:	e9 d7 fe ff ff       	jmp    be70 <fwp_main_thread+0xcc0>
    bf99:	4c 89 ef             	mov    %r13,%rdi
    bf9c:	e8 2f 98 ff ff       	call   57d0 <fwp_rc_forget_slot>
    bfa1:	e9 31 fb ff ff       	jmp    bad7 <fwp_main_thread+0x927>
    bfa6:	4c 89 ef             	mov    %r13,%rdi
    bfa9:	e8 22 98 ff ff       	call   57d0 <fwp_rc_forget_slot>
    bfae:	e9 ba fb ff ff       	jmp    bb6d <fwp_main_thread+0x9bd>
    bfb3:	4c 89 f7             	mov    %r14,%rdi
    bfb6:	e8 15 98 ff ff       	call   57d0 <fwp_rc_forget_slot>
    bfbb:	e9 4a fc ff ff       	jmp    bc0a <fwp_main_thread+0xa5a>
    bfc0:	e8 eb 96 ff ff       	call   56b0 <fwp_rc_wide_dup>
    bfc5:	e9 d5 fc ff ff       	jmp    bc9f <fwp_main_thread+0xaef>
    bfca:	4c 89 f7             	mov    %r14,%rdi
    bfcd:	e8 fe 97 ff ff       	call   57d0 <fwp_rc_forget_slot>
    bfd2:	e9 cf fd ff ff       	jmp    bda6 <fwp_main_thread+0xbf6>
    bfd7:	4c 89 f0             	mov    %r14,%rax
    bfda:	48 c1 e8 11          	shr    $0x11,%rax
    bfde:	4c 31 f0             	xor    %r14,%rax
    bfe1:	48 89 c2             	mov    %rax,%rdx
    bfe4:	48 c1 ea 09          	shr    $0x9,%rdx
    bfe8:	48 31 d0             	xor    %rdx,%rax
    bfeb:	0f b6 d0             	movzbl %al,%edx
    bfee:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    bff5:	00 
    bff6:	48 85 c0             	test   %rax,%rax
    bff9:	75 0e                	jne    c009 <fwp_main_thread+0xe59>
    bffb:	eb 56                	jmp    c053 <fwp_main_thread+0xea3>
    bffd:	0f 1f 00             	nopl   (%rax)
    c000:	48 8b 42 10          	mov    0x10(%rdx),%rax
    c004:	48 85 c0             	test   %rax,%rax
    c007:	74 4a                	je     c053 <fwp_main_thread+0xea3>
    c009:	48 89 c2             	mov    %rax,%rdx
    c00c:	4c 3b 30             	cmp    (%rax),%r14
    c00f:	75 ef                	jne    c000 <fwp_main_thread+0xe50>
    c011:	48 8b 70 08          	mov    0x8(%rax),%rsi
    c015:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    c019:	48 89 50 08          	mov    %rdx,0x8(%rax)
    c01d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    c024:	0f 85 46 fe ff ff    	jne    be70 <fwp_main_thread+0xcc0>
    c02a:	4c 89 f7             	mov    %r14,%rdi
    c02d:	e8 9e 97 ff ff       	call   57d0 <fwp_rc_forget_slot>
    c032:	41 c6 06 fe          	movb   $0xfe,(%r14)
    c036:	e9 35 fe ff ff       	jmp    be70 <fwp_main_thread+0xcc0>
    c03b:	48 8d 3d f6 1a 00 00 	lea    0x1af6(%rip),%rdi        # db38 <_IO_stdin_used+0xb38>
    c042:	e8 09 84 ff ff       	call   4450 <fwp_trap>
    c047:	48 8d 3d 74 12 00 00 	lea    0x1274(%rip),%rdi        # d2c2 <_IO_stdin_used+0x2c2>
    c04e:	e8 ad 7f ff ff       	call   4000 <ad_raw_fail>
    c053:	48 8d 3d 86 19 00 00 	lea    0x1986(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    c05a:	e8 f1 83 ff ff       	call   4450 <fwp_trap>
    c05f:	e8 ec 73 ff ff       	call   3450 <__stack_chk_fail@plt>
    c064:	48 8d 3d 72 12 00 00 	lea    0x1272(%rip),%rdi        # d2dd <_IO_stdin_used+0x2dd>
    c06b:	e8 e0 83 ff ff       	call   4450 <fwp_trap>
    c070:	e9 db 76 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c075:	e9 d6 76 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c07a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000000c080 <__divmodti4>:
    c080:	f3 0f 1e fa          	endbr64
    c084:	55                   	push   %rbp
    c085:	49 89 f1             	mov    %rsi,%r9
    c088:	49 89 d2             	mov    %rdx,%r10
    c08b:	48 89 fe             	mov    %rdi,%rsi
    c08e:	49 89 cb             	mov    %rcx,%r11
    c091:	48 89 e5             	mov    %rsp,%rbp
    c094:	41 57                	push   %r15
    c096:	41 56                	push   %r14
    c098:	41 55                	push   %r13
    c09a:	41 54                	push   %r12
    c09c:	53                   	push   %rbx
    c09d:	4c 89 c3             	mov    %r8,%rbx
    c0a0:	45 31 c0             	xor    %r8d,%r8d
    c0a3:	4d 85 c9             	test   %r9,%r9
    c0a6:	79 12                	jns    c0ba <__divmodti4+0x3a>
    c0a8:	31 ff                	xor    %edi,%edi
    c0aa:	48 f7 de             	neg    %rsi
    c0ad:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    c0b4:	4c 19 cf             	sbb    %r9,%rdi
    c0b7:	49 89 f9             	mov    %rdi,%r9
    c0ba:	4c 89 d8             	mov    %r11,%rax
    c0bd:	4d 85 db             	test   %r11,%r11
    c0c0:	0f 88 1a 01 00 00    	js     c1e0 <__divmodti4+0x160>
    c0c6:	4c 89 d9             	mov    %r11,%rcx
    c0c9:	49 89 f3             	mov    %rsi,%r11
    c0cc:	75 62                	jne    c130 <__divmodti4+0xb0>
    c0ce:	4d 89 c4             	mov    %r8,%r12
    c0d1:	4d 39 d1             	cmp    %r10,%r9
    c0d4:	0f 83 46 01 00 00    	jae    c220 <__divmodti4+0x1a0>
    c0da:	4c 89 d8             	mov    %r11,%rax
    c0dd:	4c 89 ca             	mov    %r9,%rdx
    c0e0:	49 f7 f2             	div    %r10
    c0e3:	49 89 c3             	mov    %rax,%r11
    c0e6:	31 c0                	xor    %eax,%eax
    c0e8:	48 89 d6             	mov    %rdx,%rsi
    c0eb:	31 ff                	xor    %edi,%edi
    c0ed:	4c 89 d9             	mov    %r11,%rcx
    c0f0:	48 89 c2             	mov    %rax,%rdx
    c0f3:	48 89 c8             	mov    %rcx,%rax
    c0f6:	4d 85 e4             	test   %r12,%r12
    c0f9:	74 0a                	je     c105 <__divmodti4+0x85>
    c0fb:	48 f7 d8             	neg    %rax
    c0fe:	48 83 d2 00          	adc    $0x0,%rdx
    c102:	48 f7 da             	neg    %rdx
    c105:	4d 85 c0             	test   %r8,%r8
    c108:	74 0a                	je     c114 <__divmodti4+0x94>
    c10a:	48 f7 de             	neg    %rsi
    c10d:	48 83 d7 00          	adc    $0x0,%rdi
    c111:	48 f7 df             	neg    %rdi
    c114:	48 89 33             	mov    %rsi,(%rbx)
    c117:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    c11b:	5b                   	pop    %rbx
    c11c:	41 5c                	pop    %r12
    c11e:	41 5d                	pop    %r13
    c120:	41 5e                	pop    %r14
    c122:	41 5f                	pop    %r15
    c124:	5d                   	pop    %rbp
    c125:	c3                   	ret
    c126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c12d:	00 00 00 
    c130:	4d 89 c4             	mov    %r8,%r12
    c133:	49 39 c1             	cmp    %rax,%r9
    c136:	0f 82 ce 00 00 00    	jb     c20a <__divmodti4+0x18a>
    c13c:	31 ff                	xor    %edi,%edi
    c13e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    c143:	48 63 c7             	movslq %edi,%rax
    c146:	be 40 00 00 00       	mov    $0x40,%esi
    c14b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    c150:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    c155:	48 29 c6             	sub    %rax,%rsi
    c158:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    c15d:	48 09 c8             	or     %rcx,%rax
    c160:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    c165:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    c16a:	49 89 c6             	mov    %rax,%r14
    c16d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    c171:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    c176:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    c17b:	49 09 c1             	or     %rax,%r9
    c17e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    c182:	4c 89 c8             	mov    %r9,%rax
    c185:	49 f7 f6             	div    %r14
    c188:	48 89 d1             	mov    %rdx,%rcx
    c18b:	49 89 c3             	mov    %rax,%r11
    c18e:	49 89 c1             	mov    %rax,%r9
    c191:	49 f7 e2             	mul    %r10
    c194:	49 89 c6             	mov    %rax,%r14
    c197:	49 89 d2             	mov    %rdx,%r10
    c19a:	48 39 d1             	cmp    %rdx,%rcx
    c19d:	72 07                	jb     c1a6 <__divmodti4+0x126>
    c19f:	75 17                	jne    c1b8 <__divmodti4+0x138>
    c1a1:	49 39 c7             	cmp    %rax,%r15
    c1a4:	73 12                	jae    c1b8 <__divmodti4+0x138>
    c1a6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    c1aa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    c1ae:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    c1b2:	49 89 d2             	mov    %rdx,%r10
    c1b5:	49 89 c6             	mov    %rax,%r14
    c1b8:	4c 89 f8             	mov    %r15,%rax
    c1bb:	4c 29 f0             	sub    %r14,%rax
    c1be:	4c 19 d1             	sbb    %r10,%rcx
    c1c1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    c1c6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    c1cb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    c1d0:	48 09 c6             	or     %rax,%rsi
    c1d3:	48 89 cf             	mov    %rcx,%rdi
    c1d6:	31 c0                	xor    %eax,%eax
    c1d8:	4c 89 c9             	mov    %r9,%rcx
    c1db:	e9 10 ff ff ff       	jmp    c0f0 <__divmodti4+0x70>
    c1e0:	4c 89 d0             	mov    %r10,%rax
    c1e3:	4c 89 da             	mov    %r11,%rdx
    c1e6:	4d 89 c4             	mov    %r8,%r12
    c1e9:	49 89 f3             	mov    %rsi,%r11
    c1ec:	48 f7 d8             	neg    %rax
    c1ef:	49 f7 d4             	not    %r12
    c1f2:	48 83 d2 00          	adc    $0x0,%rdx
    c1f6:	49 89 c2             	mov    %rax,%r10
    c1f9:	48 f7 da             	neg    %rdx
    c1fc:	48 89 d1             	mov    %rdx,%rcx
    c1ff:	0f 84 cc fe ff ff    	je     c0d1 <__divmodti4+0x51>
    c205:	49 39 d1             	cmp    %rdx,%r9
    c208:	73 46                	jae    c250 <__divmodti4+0x1d0>
    c20a:	4c 89 cf             	mov    %r9,%rdi
    c20d:	31 c0                	xor    %eax,%eax
    c20f:	31 c9                	xor    %ecx,%ecx
    c211:	e9 da fe ff ff       	jmp    c0f0 <__divmodti4+0x70>
    c216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c21d:	00 00 00 
    c220:	4d 85 d2             	test   %r10,%r10
    c223:	75 0d                	jne    c232 <__divmodti4+0x1b2>
    c225:	b8 01 00 00 00       	mov    $0x1,%eax
    c22a:	31 d2                	xor    %edx,%edx
    c22c:	49 f7 f2             	div    %r10
    c22f:	49 89 c2             	mov    %rax,%r10
    c232:	4c 89 c8             	mov    %r9,%rax
    c235:	31 d2                	xor    %edx,%edx
    c237:	49 f7 f2             	div    %r10
    c23a:	49 89 c1             	mov    %rax,%r9
    c23d:	4c 89 d8             	mov    %r11,%rax
    c240:	49 f7 f2             	div    %r10
    c243:	49 89 c3             	mov    %rax,%r11
    c246:	4c 89 c8             	mov    %r9,%rax
    c249:	e9 9a fe ff ff       	jmp    c0e8 <__divmodti4+0x68>
    c24e:	66 90                	xchg   %ax,%ax
    c250:	45 31 f6             	xor    %r14d,%r14d
    c253:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    c258:	44 89 f7             	mov    %r14d,%edi
    c25b:	45 85 f6             	test   %r14d,%r14d
    c25e:	0f 85 df fe ff ff    	jne    c143 <__divmodti4+0xc3>
    c264:	4c 39 ca             	cmp    %r9,%rdx
    c267:	72 17                	jb     c280 <__divmodti4+0x200>
    c269:	31 c9                	xor    %ecx,%ecx
    c26b:	48 39 c6             	cmp    %rax,%rsi
    c26e:	73 10                	jae    c280 <__divmodti4+0x200>
    c270:	4c 89 cf             	mov    %r9,%rdi
    c273:	31 c0                	xor    %eax,%eax
    c275:	e9 76 fe ff ff       	jmp    c0f0 <__divmodti4+0x70>
    c27a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c280:	4c 89 de             	mov    %r11,%rsi
    c283:	b9 01 00 00 00       	mov    $0x1,%ecx
    c288:	48 29 c6             	sub    %rax,%rsi
    c28b:	49 19 d1             	sbb    %rdx,%r9
    c28e:	eb e0                	jmp    c270 <__divmodti4+0x1f0>

000000000000c290 <atexit>:
    c290:	f3 0f 1e fa          	endbr64
    c294:	48 8b 15 6d 4d 00 00 	mov    0x4d6d(%rip),%rdx        # 11008 <__dso_handle>
    c29b:	31 f6                	xor    %esi,%esi
    c29d:	e9 9e 73 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000c2a4 <_fini>:
    c2a4:	f3 0f 1e fa          	endbr64
    c2a8:	48 83 ec 08          	sub    $0x8,%rsp
    c2ac:	48 83 c4 08          	add    $0x8,%rsp
    c2b0:	c3                   	ret
