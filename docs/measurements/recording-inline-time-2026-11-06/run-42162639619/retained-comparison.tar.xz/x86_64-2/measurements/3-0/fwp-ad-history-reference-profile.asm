
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 df 00 00 	mov    0xdfd1(%rip),%rax        # 10fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 dd 00 00    	push   0xddf2(%rip)        # 10e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 dd 00 00    	jmp    *0xddf4(%rip)        # 10e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 dc 00 00    	jmp    *0xdc66(%rip)        # 10ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e da 00 00    	jmp    *0xda8e(%rip)        # 10e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 da 00 00    	jmp    *0xda86(%rip)        # 10e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e da 00 00    	jmp    *0xda7e(%rip)        # 10e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 da 00 00    	jmp    *0xda76(%rip)        # 10e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e da 00 00    	jmp    *0xda6e(%rip)        # 10e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 da 00 00    	jmp    *0xda66(%rip)        # 10e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e da 00 00    	jmp    *0xda5e(%rip)        # 10e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 da 00 00    	jmp    *0xda56(%rip)        # 10e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e da 00 00    	jmp    *0xda4e(%rip)        # 10e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 da 00 00    	jmp    *0xda46(%rip)        # 10e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e da 00 00    	jmp    *0xda3e(%rip)        # 10e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 da 00 00    	jmp    *0xda36(%rip)        # 10e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e da 00 00    	jmp    *0xda2e(%rip)        # 10e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 da 00 00    	jmp    *0xda26(%rip)        # 10e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e da 00 00    	jmp    *0xda1e(%rip)        # 10e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 da 00 00    	jmp    *0xda16(%rip)        # 10ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e da 00 00    	jmp    *0xda0e(%rip)        # 10ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 da 00 00    	jmp    *0xda06(%rip)        # 10eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe d9 00 00    	jmp    *0xd9fe(%rip)        # 10eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 d9 00 00    	jmp    *0xd9f6(%rip)        # 10ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee d9 00 00    	jmp    *0xd9ee(%rip)        # 10ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 d9 00 00    	jmp    *0xd9e6(%rip)        # 10ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de d9 00 00    	jmp    *0xd9de(%rip)        # 10ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 d9 00 00    	jmp    *0xd9d6(%rip)        # 10ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce d9 00 00    	jmp    *0xd9ce(%rip)        # 10ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 d9 00 00    	jmp    *0xd9c6(%rip)        # 10ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be d9 00 00    	jmp    *0xd9be(%rip)        # 10ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 d9 00 00    	jmp    *0xd9b6(%rip)        # 10f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae d9 00 00    	jmp    *0xd9ae(%rip)        # 10f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 d9 00 00    	jmp    *0xd9a6(%rip)        # 10f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e d9 00 00    	jmp    *0xd99e(%rip)        # 10f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 d9 00 00    	jmp    *0xd996(%rip)        # 10f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e d9 00 00    	jmp    *0xd98e(%rip)        # 10f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 d9 00 00    	jmp    *0xd986(%rip)        # 10f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e d9 00 00    	jmp    *0xd97e(%rip)        # 10f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 d9 00 00    	jmp    *0xd976(%rip)        # 10f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e d9 00 00    	jmp    *0xd96e(%rip)        # 10f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 d9 00 00    	jmp    *0xd966(%rip)        # 10f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e d9 00 00    	jmp    *0xd95e(%rip)        # 10f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 d9 00 00    	jmp    *0xd956(%rip)        # 10f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e d9 00 00    	jmp    *0xd94e(%rip)        # 10f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 d9 00 00    	jmp    *0xd946(%rip)        # 10f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e d9 00 00    	jmp    *0xd93e(%rip)        # 10f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 d9 00 00    	jmp    *0xd936(%rip)        # 10f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e d9 00 00    	jmp    *0xd92e(%rip)        # 10f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 d9 00 00    	jmp    *0xd926(%rip)        # 10f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e d9 00 00    	jmp    *0xd91e(%rip)        # 10f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 d9 00 00    	jmp    *0xd916(%rip)        # 10fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e d9 00 00    	jmp    *0xd90e(%rip)        # 10fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 d9 00 00    	jmp    *0xd906(%rip)        # 10fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe d8 00 00    	jmp    *0xd8fe(%rip)        # 10fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 d8 00 00    	jmp    *0xd8f6(%rip)        # 10fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee d8 00 00    	jmp    *0xd8ee(%rip)        # 10fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 99 00 00 	lea    0x99b8(%rip),%r9        # d0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 99 00 00 	lea    0x99b5(%rip),%r8        # d0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 bd 00 00 	lea    0xbd01(%rip),%rax        # f480 <fwp_fn_table>
    377f:	48 89 05 f2 7c 06 00 	mov    %rax,0x67cf2(%rip)        # 6b478 <fwp_fns>
    3786:	48 8b 05 93 d8 00 00 	mov    0xd893(%rip),%rax        # 11020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 7c 06 00 	mov    %rax,0x67cec(%rip)        # 6b480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 9b 00 00 	lea    0x9b4e(%rip),%rdi        # d2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 d8 00 00 	mov    0xd818(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ef 76 00 00 	lea    0x76ef(%rip),%rdx        # af50 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 d7 00 00 	mov    0xd783(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 d7 01 00    	mov    0x1d7d8(%rip),%eax        # 21080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 99 00 00 	lea    0x99fe(%rip),%rdi        # d2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 a3 00 00 	lea    0xa346(%rip),%rdi        # dc50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 a3 00 00 	lea    0xa300(%rip),%rdi        # dc28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 a2 00 00 	lea    0xa2c4(%rip),%rdi        # dbf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 a2 00 00 	lea    0xa290(%rip),%rdi        # dbd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b d6 00 00    	call   *0xd65b(%rip)        # 10fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 d6 00 00 	lea    0xd699(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 d6 00 00 	lea    0xd692(%rip),%rax        # 11020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e d6 00 00 	mov    0xd63e(%rip),%rax        # 10fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 d6 00 00 	lea    0xd669(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 d6 00 00 	lea    0xd662(%rip),%rsi        # 11020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d d6 00 00 	mov    0xd60d(%rip),%rax        # 10fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d d6 00 00 00 	cmpb   $0x0,0xd64d(%rip)        # 11048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea d5 00 00 	cmpq   $0x0,0xd5ea(%rip)        # 10ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 d5 00 00 	mov    0xd5f6(%rip),%rdi        # 11008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 d6 00 00 01 	movb   $0x1,0xd625(%rip)        # 11048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 d5 04 00 	lea    0x4d597(%rip),%r8        # 511a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b d5 04 00 	lea    0x4d53b(%rip),%rcx        # 51160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f d5 04 00 	lea    0x4d50f(%rip),%rcx        # 51140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 d5 04 00 	lea    0x4d541(%rip),%rcx        # 51180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 d5 04 	movdqa 0x4d550(%rip),%xmm0        # 511b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 d5 04 	paddq  0x4d538(%rip),%xmm0        # 511a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f d4 04 00 	cmp    %rax,0x4d49f(%rip)        # 51120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 d4 04 	movq   %xmm0,0x4d495(%rip)        # 51120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e d4 01 00 	add    0x1d43e(%rip),%rdx        # 210f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c d4 01 00 	add    0x1d42c(%rip),%rax        # 210f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 77 06 00 	mov    0x67779(%rip),%rdi        # 6b480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 d3 00 00 	mov    0xd304(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 d2 00 00 	mov    0xd2f1(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 5a 06 00 	mov    0x65ab1(%rip),%rax        # 69800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 53 06 00 	mov    0x653f9(%rip),%rax        # 691c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 53 06 00 	sub    0x653e5(%rip),%rax        # 691c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d 9f 00 00 	lea    0x9f1d(%rip),%rsi        # dd30 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 91 00 00 	lea    0x91c5(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 d1 00 00 	mov    0xd1f2(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 6d 06 00 	mov    0x66d8b(%rip),%rax        # 6ac10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 6d 06 00 	lea    0x66d84(%rip),%r8        # 6ac10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 6d 06 00 	mov    0x66d65(%rip),%rbx        # 6abf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 6d 06 00 	mov    0x66d75(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 6d 06 00 	mov    0x66d11(%rip),%rdi        # 6ac00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 6d 06 00 	sub    %rsi,0x66d5a(%rip)        # 6ac50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 6c 06 00 	mov    0x66cea(%rip),%rax        # 6abf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 6c 06 00 	add    0x66ca0(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 6c 06 00 	mov    0x66cae(%rip),%rsi        # 6ac00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 6c 06 00 	mov    0x66cbc(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 6c 06 00 	mov    %r12,0x66c6b(%rip)        # 6ac00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 6c 06 00 	mov    %rbp,0x66c59(%rip)        # 6abf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 6c 06 00 	cmp    %rdi,0x66c3e(%rip)        # 6abe8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 6c 06 00 	mov    %rdi,0x66c35(%rip)        # 6abe8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 6c 06 00 	sub    %rdi,0x66c79(%rip)        # 6ac50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 6c 06 00 	mov    0x66c21(%rip),%rax        # 6ac08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 6c 06 00 	lea    0x66c1a(%rip),%r8        # 6ac08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef 96 00 00 	lea    0x96ef(%rip),%rdx        # d6f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 d0 00 00 	mov    0xd022(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d cf 00 00 	mov    0xcf7d(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 8f 00 00 	lea    0x8f34(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 56 06 00 	cmp    0x656c9(%rip),%rdi        # 69800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 56 06 00 	mov    0x6568f(%rip),%rax        # 697e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 56 06 00 	mov    %rdi,0x6566d(%rip)        # 697e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 56 06 00 	mov    %rdi,0x65649(%rip)        # 697e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f 90 00 00 	lea    0x905f(%rip),%rsi        # d240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 8e 00 00 	lea    0x8e27(%rip),%rsi        # d01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 cf 04 	movdqa 0x4cf76(%rip),%xmm0        # 511b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e cf 04 	paddq  0x4cf5e(%rip),%xmm0        # 511a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 ce 01 00 	mov    0x1ce84(%rip),%r8        # 210f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e ce 04 00 	mov    0x4ce9e(%rip),%rcx        # 51120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 cd 00 00 	mov    0xcdb7(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 94 00 00 	lea    0x94b5(%rip),%rdx        # d748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 ce 04 00 	lea    0x4cee1(%rip),%r15        # 51180 <ad_raw_peak>
    429f:	4c 8d 35 9a ce 04 00 	lea    0x4ce9a(%rip),%r14        # 51140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 8d 00 00 	lea    0x8d79(%rip),%rax        # d02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 c9 00 	movq   0xc956(%rip),%xmm0        # 10c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f ce 04 00 	lea    0x4ce9f(%rip),%r13        # 51160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 8d 00 00 	lea    0x8d6f(%rip),%rax        # d03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 c9 00 	movq   0xc936(%rip),%xmm0        # 10c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 cd 00 00 	mov    0xcd33(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 8d 00 00 	lea    0x8d0c(%rip),%rcx        # d020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d 94 00 00 	lea    0x948d(%rip),%rdx        # d7a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 cd 00 00 	mov    0xcd04(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 8c 00 00 	lea    0x8cf8(%rip),%rdi        # d045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 cd 01 00 	cmpq   $0x0,0x1cda6(%rip)        # 21100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd cd 01 00 	mov    0x1cdbd(%rip),%r8        # 21120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be cd 01 00 	mov    0x1cdbe(%rip),%r9        # 21128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af cd 01 00 	lea    0x1cdaf(%rip),%rbx        # 21120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 8c 00 00 	lea    0x8cf4(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 cd 01 00 	mov    0x1cdb1(%rip),%rax        # 21130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 8c 00 00 	lea    0x8c9a(%rip),%r12        # d020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 cc 00 00 	mov    0xcc89(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 94 00 00 	lea    0x9429(%rip),%rdx        # d7e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 cd 01 00 	cmp    0x1cd33(%rip),%rbp        # 21100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 cc 00 00 	mov    0xcc58(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 8c 00 00 	lea    0x8c5b(%rip),%rdi        # d059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 cc 00 00 	mov    0xcc23(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 93 00 00 	lea    0x9384(%rip),%rdx        # d7a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 8c 00 00 	lea    0x8c40(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da 92 00 00 	lea    0x92da(%rip),%rdi        # d720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 cb 00 00 	mov    0xcbc8(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 8b 00 00 	lea    0x8bdf(%rip),%rdx        # d05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 cb 00 00 	mov    0xcbb0(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ca 00 00 	mov    0xcac1(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 8a 00 00 	lea    0x8a78(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 8a 00 00 	lea    0x8ac0(%rip),%rdi        # d06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 8a 00 00 	lea    0x8a48(%rip),%rdi        # d087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 91 00 00 	lea    0x91d8(%rip),%rdi        # d828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 96 00 	movdqa 0x96e0(%rip),%xmm0        # dd50 <msg.4+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 6d 06 00 	add    0x66daa(%rip),%rax        # 6b478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c 91 00 00 	lea    0x912c(%rip),%rdi        # d850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 c9 01 00 	cmp    %rax,0x1c9a5(%rip)        # 210e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 c9 01 00 	add    0x1c9a0(%rip),%rax        # 210f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 91 00 00 	lea    0x9115(%rip),%rdi        # d880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 89 00 00 	lea    0x8920(%rip),%r8        # d0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 87 00 00 	lea    0x8775(%rip),%r8        # d0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 86 00 00 	lea    0x8612(%rip),%r8        # d0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 83 00 00 	lea    0x83ea(%rip),%rdi        # d0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a 85 00 00 	lea    0x859a(%rip),%rsi        # d288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 5e 06 00 	mov    0x65e85(%rip),%r9        # 6abe8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 5e 06 00 	mov    0x65ede(%rip),%r8        # 6ac48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f 8b 00 00 	lea    0x8b5f(%rip),%rdx        # d8d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 5e 06 00 	mov    0x65ec6(%rip),%rcx        # 6ac40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 5e 06 	movsd  0x65ed4(%rip),%xmm1        # 6ac60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 5e 06 	movsd  0x65ec4(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 c2 00 00 	mov    0xc2a5(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 8f 00 	movdqa 0x8f88(%rip),%xmm0        # dd60 <msg.4+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 59 06 00 	lea    0x6597f(%rip),%rax        # 6a760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 8f 00 	movdqa 0x8fb1(%rip),%xmm2        # dda0 <msg.4+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 59 06 00 	movaps %xmm0,0x65925(%rip)        # 6a720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d 8f 00 	movdqa 0x8f6d(%rip),%xmm0        # dd70 <msg.4+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 5d 06 00 01 	movl   $0x1,0x65db3(%rip)        # 6abc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 59 06 00 	movaps %xmm0,0x65913(%rip)        # 6a730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b 8f 00 	movdqa 0x8f5b(%rip),%xmm0        # dd80 <msg.4+0x50>
    4e24:	00 
    4e25:	0f 29 05 14 59 06 00 	movaps %xmm0,0x65914(%rip)        # 6a740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c 8f 00 	movdqa 0x8f5c(%rip),%xmm0        # dd90 <msg.4+0x60>
    4e33:	00 
    4e34:	0f 29 05 15 59 06 00 	movaps %xmm0,0x65915(%rip)        # 6a750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 49 06 00 	lea    0x64995(%rip),%r8        # 69820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 5c 06 00 	mov    %rax,0x65cb0(%rip)        # 6abd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 5c 06 00 	mov    %r12,0x65c8e(%rip)        # 6abe0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 5c 06 00 	mov    %rax,0x65c77(%rip)        # 6abd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 5c 06 00 	mov    %rbx,0x65c90(%rip)        # 6abf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 5c 06 00 	mov    %rsi,0x65cb9(%rip)        # 6ac20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 81 00 00 	lea    0x8174(%rip),%rdi        # d0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 5c 06 00 	mov    %rax,0x65c98(%rip)        # 6ac18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 5c 06 00    	mov    %eax,0x65c1c(%rip)        # 6abc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 48 06 00 	mov    0x6480c(%rip),%r8        # 697e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 47 06 00 	mov    %rbx,0x6473c(%rip)        # 697e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 47 06 00 	mov    %r8,0x64728(%rip)        # 697e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 c0 04 00 	lea    0x4c0e9(%rip),%rcx        # 511c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 c0 04 00 	lea    0x4c098(%rip),%rcx        # 511a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 7f 00 00 	lea    0x7fc2(%rip),%rdi        # d0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 c0 04 00 	lea    0x4c016(%rip),%r12        # 511c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 7e 00 00 	lea    0x7ee8(%rip),%rax        # d112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 7e 00 00 	lea    0x7ecc(%rip),%rdx        # d0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 7f 00 00 	lea    0x7f04(%rip),%rdi        # d148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 7e 00 00 	lea    0x7edd(%rip),%rdi        # d12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 7e 00 00 	lea    0x7eaa(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae bd 01 00 	lea    0x1bdae(%rip),%rdi        # 210a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 bd 01 00 	movaps %xmm0,0x1bd96(%rip)        # 210a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 bd 01 00 	mov    %rsi,0x1bd72(%rip)        # 21088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 bd 01 00 	movaps %xmm0,0x1bd93(%rip)        # 210b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 bd 01 00 	movaps %xmm0,0x1bd97(%rip)        # 210c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 bd 01 00 	mov    %rax,0x1bd98(%rip)        # 210d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 7e 00 00 	lea    0x7e09(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d bd 01 00 	mov    0x1bd1d(%rip),%rsi        # 21088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d bd 01 00 	imul   $0x68,0x1bd6d(%rip),%rdx        # 210e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 be 04 00 	cmp    0x4be26(%rip),%rdx        # 511a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 be 04 00 	mov    0x4be25(%rip),%rax        # 511a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f be 04 00 	add    0x4be1f(%rip),%rax        # 511b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 be 04 00 	add    0x4be20(%rip),%rax        # 511b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c bd 01 00 	mov    0x1bd5c(%rip),%rcx        # 21100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 bd 01 00 	mov    %rdi,0x1bd45(%rip)        # 21100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 bd 01 00 	lea    0x1bd57(%rip),%rcx        # 21120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 62 85 00 00 	lea    0x8562(%rip),%rdi        # d958 <_IO_stdin_used+0x958>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 7d 00 00 	lea    0x7d6f(%rip),%rdi        # d171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 43 06 00 	mov    0x643a7(%rip),%rbx        # 697d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a bb 00 00 	mov    0xbb0a(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 4b 84 00 00 	lea    0x844b(%rip),%rdi        # d988 <_IO_stdin_used+0x988>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 42 06 00 	mov    0x6426d(%rip),%rax        # 697e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 42 06 00 	mov    %rdx,0x64247(%rip)        # 697e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 41 06 00 	mov    0x64194(%rip),%rbx        # 697d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 41 06 00 	mov    %rbx,0x64151(%rip)        # 697d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 41 06 00 	mov    %rdx,0x64151(%rip)        # 697e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 41 06 00 	lea    0x64166(%rip),%rsi        # 69820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 5c 06 00 	addq   $0x1,0x65ce5(%rip)        # 6b468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 1f 82 00 00 	lea    0x821f(%rip),%rdi        # d9b8 <_IO_stdin_used+0x9b8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 30 82 00 00 	lea    0x8230(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 79 00 00 	lea    0x79d2(%rip),%rdi        # d18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 40 06 00 	lea    0x6401e(%rip),%rcx        # 69820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 5c 06 00 	subq   $0x1,0x65c1f(%rip)        # 6b468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 8b 81 00 00 	lea    0x818b(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 5c 06 00 	cmpq   $0x0,0x65c00(%rip)        # 6b468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 5b 06 00 	sub    %rax,0x65b55(%rip)        # 6b470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 5b 06 00 	add    %r12,0x65b33(%rip)        # 6b470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 52 06 00 	mov    0x6528f(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 3e 06 00 	lea    0x63e8c(%rip),%rax        # 69820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 51 06 00 	add    0x651e3(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 51 06 00 	mov    0x651b0(%rip),%rsi        # 6abd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 51 06 00 	mov    0x651d1(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 51 06 00 	add    0x651c5(%rip),%r8        # 6ac18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 51 06 	addsd  0x6518d(%rip),%xmm0        # 6ac60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 3d 06 00 	lea    0x63d42(%rip),%rax        # 69820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 51 06 00 	sub    %rdi,0x6514c(%rip)        # 6ac40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 51 06 	movsd  %xmm0,0x65164(%rip)        # 6ac60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 51 06 00 	sub    %rdx,0x6511e(%rip)        # 6ac40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 51 06 	addsd  0x65124(%rip),%xmm0        # 6ac60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 51 06 	movsd  %xmm0,0x65118(%rip)        # 6ac60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 50 06 00 	mov    0x650af(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 50 06 00 	add    %rcx,0x650a9(%rip)        # 6ac50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 50 06 00 	cmp    0x65062(%rip),%r9        # 6ac10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 50 06 00 	mov    %r9,0x65059(%rip)        # 6ac10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 50 06 00 	cmp    0x6504a(%rip),%r9        # 6ac08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 50 06 00 	mov    %r9,0x6503d(%rip)        # 6ac08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 4f 06 00 	add    0x64f53(%rip),%rdi        # 6ac18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 3b 06 00 	lea    0x63b30(%rip),%r15        # 69820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 4e 06 00 	add    0x64ea0(%rip),%r12        # 6abd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 4e 06 00 	add    0x64ef9(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 4e 06 00 	cmp    %rax,0x64ef8(%rip)        # 6ac48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 4e 06 00 	mov    %rax,0x64ee9(%rip)        # 6ac40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 4e 06 00 	mov    %rax,0x64ee8(%rip)        # 6ac48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 4e 06 	addsd  0x64ee4(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 4e 06 	movsd  %xmm0,0x64edc(%rip)        # 6ac58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 4e 06 00    	mov    0x64e23(%rip),%eax        # 6abc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 3a 06 00 	lea    0x63a5f(%rip),%rdi        # 69820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 4e 06 00 	add    0x64e18(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 4e 06 00 	cmp    %rax,0x64e13(%rip)        # 6ac48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 4e 06 00 	mov    %rax,0x64e04(%rip)        # 6ac40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 4e 06 00 	mov    %rax,0x64e03(%rip)        # 6ac48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 4d 06 	addsd  0x64dff(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 4d 06 	movsd  %xmm0,0x64df7(%rip)        # 6ac58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 55 06 00    	mov    0x655ca(%rip),%ebx        # 6b4e8 <iteration_active>
    5f1e:	8b 05 a0 4c 06 00    	mov    0x64ca0(%rip),%eax        # 6abc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 38 06 00 	lea    0x638d4(%rip),%rax        # 69820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 4c 06 00 	add    0x64c8e(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 4c 06 00 	cmp    %rax,0x64c89(%rip)        # 6ac48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 4c 06 00 	mov    %rax,0x64c7a(%rip)        # 6ac40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 4c 06 00 	mov    %rax,0x64c79(%rip)        # 6ac48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 4c 06 	addsd  0x64c78(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 4c 06 	movsd  %xmm0,0x64c70(%rip)        # 6ac58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 4c 06 00 	mov    0x64c4d(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 54 06 	subsd  0x654bb(%rip),%xmm0        # 6b4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 54 06 	comisd 0x654ab(%rip),%xmm0        # 6b4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 54 06 	movsd  %xmm0,0x654a1(%rip)        # 6b4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 54 06 00 	addq   $0x1,0x654a4(%rip)        # 6b4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 54 06 00 	add    %rdi,0x65495(%rip)        # 6b4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_apply>:
    6100:	55                   	push   %rbp
    6101:	48 89 f9             	mov    %rdi,%rcx
    6104:	48 89 e5             	mov    %rsp,%rbp
    6107:	41 57                	push   %r15
    6109:	41 56                	push   %r14
    610b:	41 55                	push   %r13
    610d:	41 89 f5             	mov    %esi,%r13d
    6110:	41 54                	push   %r12
    6112:	53                   	push   %rbx
    6113:	48 83 ec 28          	sub    $0x28,%rsp
    6117:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    611e:	00 00 
    6120:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6124:	49 89 d6             	mov    %rdx,%r14
    6127:	44 8b 09             	mov    (%rcx),%r9d
    612a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    612e:	49 89 e0             	mov    %rsp,%r8
    6131:	49 c1 e1 05          	shl    $0x5,%r9
    6135:	4c 03 0d 3c 53 06 00 	add    0x6533c(%rip),%r9        # 6b478 <fwp_fns>
    613c:	41 8b 19             	mov    (%r9),%ebx
    613f:	45 85 e4             	test   %r12d,%r12d
    6142:	75 2c                	jne    6170 <fwp_apply+0x70>
    6144:	41 39 dd             	cmp    %ebx,%r13d
    6147:	72 27                	jb     6170 <fwp_apply+0x70>
    6149:	85 db                	test   %ebx,%ebx
    614b:	0f 84 b7 01 00 00    	je     6308 <fwp_apply+0x208>
    6151:	4c 89 f7             	mov    %r14,%rdi
    6154:	41 ff 51 08          	call   *0x8(%r9)
    6158:	48 89 c1             	mov    %rax,%rcx
    615b:	41 39 dd             	cmp    %ebx,%r13d
    615e:	0f 84 7c 01 00 00    	je     62e0 <fwp_apply+0x1e0>
    6164:	89 d8                	mov    %ebx,%eax
    6166:	41 29 dd             	sub    %ebx,%r13d
    6169:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    616d:	eb b8                	jmp    6127 <fwp_apply+0x27>
    616f:	90                   	nop
    6170:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    6175:	41 39 df             	cmp    %ebx,%r15d
    6178:	0f 82 dc 00 00 00    	jb     625a <fwp_apply+0x15a>
    617e:	41 89 df             	mov    %ebx,%r15d
    6181:	b8 01 00 00 00       	mov    $0x1,%eax
    6186:	48 89 e2             	mov    %rsp,%rdx
    6189:	45 29 e7             	sub    %r12d,%r15d
    618c:	85 db                	test   %ebx,%ebx
    618e:	0f 45 c3             	cmovne %ebx,%eax
    6191:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    6198:	00 
    6199:	48 c1 e8 04          	shr    $0x4,%rax
    619d:	48 c1 e0 04          	shl    $0x4,%rax
    61a1:	48 89 c6             	mov    %rax,%rsi
    61a4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    61ab:	48 29 f2             	sub    %rsi,%rdx
    61ae:	48 39 d4             	cmp    %rdx,%rsp
    61b1:	74 15                	je     61c8 <fwp_apply+0xc8>
    61b3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    61ba:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    61c1:	00 00 
    61c3:	48 39 d4             	cmp    %rdx,%rsp
    61c6:	75 eb                	jne    61b3 <fwp_apply+0xb3>
    61c8:	25 ff 0f 00 00       	and    $0xfff,%eax
    61cd:	48 29 c4             	sub    %rax,%rsp
    61d0:	48 85 c0             	test   %rax,%rax
    61d3:	0f 85 59 01 00 00    	jne    6332 <fwp_apply+0x232>
    61d9:	45 89 e2             	mov    %r12d,%r10d
    61dc:	48 89 e6             	mov    %rsp,%rsi
    61df:	48 89 e7             	mov    %rsp,%rdi
    61e2:	31 c0                	xor    %eax,%eax
    61e4:	49 c1 e2 03          	shl    $0x3,%r10
    61e8:	45 85 e4             	test   %r12d,%r12d
    61eb:	74 25                	je     6212 <fwp_apply+0x112>
    61ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61f4:	00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6205:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6209:	48 83 c0 08          	add    $0x8,%rax
    620d:	4c 39 d0             	cmp    %r10,%rax
    6210:	75 ee                	jne    6200 <fwp_apply+0x100>
    6212:	45 85 ff             	test   %r15d,%r15d
    6215:	0f 84 f4 00 00 00    	je     630f <fwp_apply+0x20f>
    621b:	44 89 fa             	mov    %r15d,%edx
    621e:	4c 89 f0             	mov    %r14,%rax
    6221:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6225:	44 89 e2             	mov    %r12d,%edx
    6228:	66 90                	xchg   %ax,%ax
    622a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6231:	00 00 00 00 
    6235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    623c:	00 00 00 00 
    6240:	4c 8b 10             	mov    (%rax),%r10
    6243:	89 d1                	mov    %edx,%ecx
    6245:	48 83 c0 08          	add    $0x8,%rax
    6249:	83 c2 01             	add    $0x1,%edx
    624c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    6250:	4c 39 d8             	cmp    %r11,%rax
    6253:	75 eb                	jne    6240 <fwp_apply+0x140>
    6255:	e9 b5 00 00 00       	jmp    630f <fwp_apply+0x20f>
    625a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    625e:	be 02 00 00 00       	mov    $0x2,%esi
    6263:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    6267:	48 c1 e7 03          	shl    $0x3,%rdi
    626b:	e8 a0 fc ff ff       	call   5f10 <fwp_heap_alloc>
    6270:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    6274:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    6279:	48 89 c3             	mov    %rax,%rbx
    627c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    6280:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6284:	66 0f d6 00          	movq   %xmm0,(%rax)
    6288:	45 85 e4             	test   %r12d,%r12d
    628b:	74 14                	je     62a1 <fwp_apply+0x1a1>
    628d:	44 89 e2             	mov    %r12d,%edx
    6290:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    6294:	48 8d 78 08          	lea    0x8(%rax),%rdi
    6298:	48 c1 e2 03          	shl    $0x3,%rdx
    629c:	e8 4f d3 ff ff       	call   35f0 <memmove@plt>
    62a1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    62a5:	45 85 ed             	test   %r13d,%r13d
    62a8:	74 2e                	je     62d8 <fwp_apply+0x1d8>
    62aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62b1:	00 00 00 00 
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 
    62c0:	49 8b 16             	mov    (%r14),%rdx
    62c3:	44 89 e0             	mov    %r12d,%eax
    62c6:	49 83 c6 08          	add    $0x8,%r14
    62ca:	41 83 c4 01          	add    $0x1,%r12d
    62ce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    62d3:	49 39 ce             	cmp    %rcx,%r14
    62d6:	75 e8                	jne    62c0 <fwp_apply+0x1c0>
    62d8:	48 89 d9             	mov    %rbx,%rcx
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    62e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62eb:	00 00 
    62ed:	75 4e                	jne    633d <fwp_apply+0x23d>
    62ef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    62f3:	48 89 c8             	mov    %rcx,%rax
    62f6:	5b                   	pop    %rbx
    62f7:	41 5c                	pop    %r12
    62f9:	41 5d                	pop    %r13
    62fb:	41 5e                	pop    %r14
    62fd:	41 5f                	pop    %r15
    62ff:	5d                   	pop    %rbp
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	45 31 ff             	xor    %r15d,%r15d
    630b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    630f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6313:	41 ff 51 08          	call   *0x8(%r9)
    6317:	48 89 c1             	mov    %rax,%rcx
    631a:	45 39 fd             	cmp    %r15d,%r13d
    631d:	74 c1                	je     62e0 <fwp_apply+0x1e0>
    631f:	45 01 e5             	add    %r12d,%r13d
    6322:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6326:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    632a:	41 29 dd             	sub    %ebx,%r13d
    632d:	e9 f5 fd ff ff       	jmp    6127 <fwp_apply+0x27>
    6332:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6338:	e9 9c fe ff ff       	jmp    61d9 <fwp_apply+0xd9>
    633d:	e8 0e d1 ff ff       	call   3450 <__stack_chk_fail@plt>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_p_ad_push>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	49 89 d5             	mov    %rdx,%r13
    6359:	41 54                	push   %r12
    635b:	49 89 fc             	mov    %rdi,%r12
    635e:	55                   	push   %rbp
    635f:	53                   	push   %rbx
    6360:	48 83 ec 48          	sub    $0x48,%rsp
    6364:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6369:	48 85 ff             	test   %rdi,%rdi
    636c:	79 09                	jns    6377 <fwp_p_ad_push+0x27>
    636e:	48 85 d2             	test   %rdx,%rdx
    6371:	0f 88 b9 02 00 00    	js     6630 <fwp_p_ad_push+0x2e0>
    6377:	48 89 f8             	mov    %rdi,%rax
    637a:	48 89 0c 24          	mov    %rcx,(%rsp)
    637e:	4c 89 c5             	mov    %r8,%rbp
    6381:	48 09 d0             	or     %rdx,%rax
    6384:	0f 89 86 02 00 00    	jns    6610 <fwp_p_ad_push+0x2c0>
    638a:	48 85 ff             	test   %rdi,%rdi
    638d:	0f 89 df 03 00 00    	jns    6772 <fwp_p_ad_push+0x422>
    6393:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6398:	49 89 d6             	mov    %rdx,%r14
    639b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    63a2:	00 
    63a3:	49 89 d4             	mov    %rdx,%r12
    63a6:	49 c1 fe 20          	sar    $0x20,%r14
    63aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    63b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63b7:	48 85 ed             	test   %rbp,%rbp
    63ba:	0f 84 40 03 00 00    	je     6700 <fwp_p_ad_push+0x3b0>
    63c0:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    63c4:	0f 84 be 02 00 00    	je     6688 <fwp_p_ad_push+0x338>
    63ca:	4c 89 f7             	mov    %r14,%rdi
    63cd:	e8 5e e3 ff ff       	call   4730 <fwp_tape_of>
    63d2:	48 89 c3             	mov    %rax,%rbx
    63d5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63da:	0f 85 36 03 00 00    	jne    6716 <fwp_p_ad_push+0x3c6>
    63e0:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    63e4:	48 89 45 08          	mov    %rax,0x8(%rbp)
    63e8:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    63ec:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63f3:	0f 8f bc 03 00 00    	jg     67b5 <fwp_p_ad_push+0x465>
    63f9:	44 89 e0             	mov    %r12d,%eax
    63fc:	4c 39 f8             	cmp    %r15,%rax
    63ff:	0f 8d a4 03 00 00    	jge    67a9 <fwp_p_ad_push+0x459>
    6405:	4d 85 ed             	test   %r13,%r13
    6408:	78 0c                	js     6416 <fwp_p_ad_push+0xc6>
    640a:	44 89 e8             	mov    %r13d,%eax
    640d:	4c 39 f8             	cmp    %r15,%rax
    6410:	0f 8d 93 03 00 00    	jge    67a9 <fwp_p_ad_push+0x459>
    6416:	4d 89 fe             	mov    %r15,%r14
    6419:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    641d:	49 8d 46 01          	lea    0x1(%r14),%rax
    6421:	4c 89 f1             	mov    %r14,%rcx
    6424:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    642a:	0f 87 85 03 00 00    	ja     67b5 <fwp_p_ad_push+0x465>
    6430:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6434:	48 39 e8             	cmp    %rbp,%rax
    6437:	0f 8e 23 02 00 00    	jle    6660 <fwp_p_ad_push+0x310>
    643d:	48 85 ed             	test   %rbp,%rbp
    6440:	ba 40 00 00 00       	mov    $0x40,%edx
    6445:	48 0f 44 ea          	cmove  %rdx,%rbp
    6449:	48 39 e8             	cmp    %rbp,%rax
    644c:	7e 22                	jle    6470 <fwp_p_ad_push+0x120>
    644e:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6455:	0f 8f f5 01 00 00    	jg     6650 <fwp_p_ad_push+0x300>
    645b:	48 01 ed             	add    %rbp,%rbp
    645e:	48 39 e8             	cmp    %rbp,%rax
    6461:	7f eb                	jg     644e <fwp_p_ad_push+0xfe>
    6463:	66 90                	xchg   %ax,%ax
    6465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    646c:	00 00 00 00 
    6470:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6477:	00 
    6478:	4c 8b 43 60          	mov    0x60(%rbx),%r8
    647c:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6480:	ba 01 00 00 00       	mov    $0x1,%edx
    6485:	48 89 c6             	mov    %rax,%rsi
    6488:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    648d:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6492:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6497:	e8 f4 ec ff ff       	call   5190 <ad_raw_realloc>
    649c:	48 85 c0             	test   %rax,%rax
    649f:	0f 84 1c 03 00 00    	je     67c1 <fwp_p_ad_push+0x471>
    64a5:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64a9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    64ae:	48 89 43 20          	mov    %rax,0x20(%rbx)
    64b2:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    64b7:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    64bb:	4d 85 c0             	test   %r8,%r8
    64be:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    64c2:	0f 84 d0 01 00 00    	je     6698 <fwp_p_ad_push+0x348>
    64c8:	49 8b 50 60          	mov    0x60(%r8),%rdx
    64cc:	48 39 ea             	cmp    %rbp,%rdx
    64cf:	0f 8d bb 00 00 00    	jge    6590 <fwp_p_ad_push+0x240>
    64d5:	49 8b 70 40          	mov    0x40(%r8),%rsi
    64d9:	48 89 ef             	mov    %rbp,%rdi
    64dc:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    64e1:	48 c1 e7 04          	shl    $0x4,%rdi
    64e5:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    64ea:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    64ef:	be 02 00 00 00       	mov    $0x2,%esi
    64f4:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    64f9:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    64fe:	e8 0d fa ff ff       	call   5f10 <fwp_heap_alloc>
    6503:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6508:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    650d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6512:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6517:	48 85 f6             	test   %rsi,%rsi
    651a:	74 31                	je     654d <fwp_p_ad_push+0x1fd>
    651c:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    6521:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    6526:	48 c1 e2 04          	shl    $0x4,%rdx
    652a:	48 39 fa             	cmp    %rdi,%rdx
    652d:	48 0f 47 d7          	cmova  %rdi,%rdx
    6531:	48 89 c7             	mov    %rax,%rdi
    6534:	e8 47 d0 ff ff       	call   3580 <memcpy@plt>
    6539:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    653e:	e8 cd f4 ff ff       	call   5a10 <fwp_mem_free>
    6543:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6548:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    654d:	49 8b 78 60          	mov    0x60(%r8),%rdi
    6551:	48 89 ea             	mov    %rbp,%rdx
    6554:	31 f6                	xor    %esi,%esi
    6556:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    655b:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6560:	48 29 fa             	sub    %rdi,%rdx
    6563:	48 c1 e7 04          	shl    $0x4,%rdi
    6567:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    656c:	48 c1 e2 04          	shl    $0x4,%rdx
    6570:	e8 3b cf ff ff       	call   34b0 <memset@plt>
    6575:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    657a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    657f:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6584:	49 89 68 60          	mov    %rbp,0x60(%r8)
    6588:	49 89 40 40          	mov    %rax,0x40(%r8)
    658c:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6590:	4d 85 f6             	test   %r14,%r14
    6593:	0f 85 8f 01 00 00    	jne    6728 <fwp_p_ad_push+0x3d8>
    6599:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    659d:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65a1:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    65a8:	00 
    65a9:	31 d2                	xor    %edx,%edx
    65ab:	49 01 c6             	add    %rax,%r14
    65ae:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    65b2:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    65b6:	44 89 24 10          	mov    %r12d,(%rax,%rdx,1)
    65ba:	4d 85 ed             	test   %r13,%r13
    65bd:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    65c3:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    65ca:	4c 0f 48 e8          	cmovs  %rax,%r13
    65ce:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    65d3:	49 8d 47 01          	lea    0x1(%r15),%rax
    65d7:	f2 0f 11 0c 0e       	movsd  %xmm1,(%rsi,%rcx,1)
    65dc:	45 89 2c 16          	mov    %r13d,(%r14,%rdx,1)
    65e0:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    65e5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65e9:	48 83 c4 48          	add    $0x48,%rsp
    65ed:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65f4:	ff ff ff 
    65f7:	4c 21 e0             	and    %r12,%rax
    65fa:	5b                   	pop    %rbx
    65fb:	5d                   	pop    %rbp
    65fc:	4c 09 f8             	or     %r15,%rax
    65ff:	41 5c                	pop    %r12
    6601:	41 5d                	pop    %r13
    6603:	41 5e                	pop    %r14
    6605:	41 5f                	pop    %r15
    6607:	c3                   	ret
    6608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    660f:	00 
    6610:	48 c1 fa 20          	sar    $0x20,%rdx
    6614:	48 c1 ff 20          	sar    $0x20,%rdi
    6618:	49 89 d6             	mov    %rdx,%r14
    661b:	48 39 d7             	cmp    %rdx,%rdi
    661e:	0f 84 93 fd ff ff    	je     63b7 <fwp_p_ad_push+0x67>
    6624:	48 8d 3d dd 73 00 00 	lea    0x73dd(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    662b:	e8 20 de ff ff       	call   4450 <fwp_trap>
    6630:	48 83 c4 48          	add    $0x48,%rsp
    6634:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    663b:	5b                   	pop    %rbx
    663c:	5d                   	pop    %rbp
    663d:	41 5c                	pop    %r12
    663f:	41 5d                	pop    %r13
    6641:	41 5e                	pop    %r14
    6643:	41 5f                	pop    %r15
    6645:	c3                   	ret
    6646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    664d:	00 00 00 
    6650:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6655:	e9 16 fe ff ff       	jmp    6470 <fwp_p_ad_push+0x120>
    665a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6660:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    6667:	00 
    6668:	48 8b 43 20          	mov    0x20(%rbx),%rax
    666c:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    6670:	48 c1 e1 03          	shl    $0x3,%rcx
    6674:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6678:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    667c:	e9 35 ff ff ff       	jmp    65b6 <fwp_p_ad_push+0x266>
    6681:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6688:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    668c:	e9 57 fd ff ff       	jmp    63e8 <fwp_p_ad_push+0x98>
    6691:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6698:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    669c:	48 89 ee             	mov    %rbp,%rsi
    669f:	ba 02 00 00 00       	mov    $0x2,%edx
    66a4:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    66a9:	48 c1 e6 04          	shl    $0x4,%rsi
    66ad:	e8 de ea ff ff       	call   5190 <ad_raw_realloc>
    66b2:	48 89 c6             	mov    %rax,%rsi
    66b5:	48 85 c0             	test   %rax,%rax
    66b8:	0f 84 03 01 00 00    	je     67c1 <fwp_p_ad_push+0x471>
    66be:	48 89 43 30          	mov    %rax,0x30(%rbx)
    66c2:	48 8b 43 18          	mov    0x18(%rbx),%rax
    66c6:	4d 85 f6             	test   %r14,%r14
    66c9:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    66ce:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    66d2:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    66d6:	48 89 43 38          	mov    %rax,0x38(%rbx)
    66da:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    66df:	0f 85 99 00 00 00    	jne    677e <fwp_p_ad_push+0x42e>
    66e5:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    66e9:	48 8b 43 20          	mov    0x20(%rbx),%rax
    66ed:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    66f4:	00 
    66f5:	31 d2                	xor    %edx,%edx
    66f7:	e9 af fe ff ff       	jmp    65ab <fwp_p_ad_push+0x25b>
    66fc:	0f 1f 40 00          	nopl   0x0(%rax)
    6700:	4c 89 f7             	mov    %r14,%rdi
    6703:	e8 28 e0 ff ff       	call   4730 <fwp_tape_of>
    6708:	48 89 c3             	mov    %rax,%rbx
    670b:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6710:	0f 84 d2 fc ff ff    	je     63e8 <fwp_p_ad_push+0x98>
    6716:	48 8d 3d 33 73 00 00 	lea    0x7333(%rip),%rdi        # da50 <_IO_stdin_used+0xa50>
    671d:	e8 2e dd ff ff       	call   4450 <fwp_trap>
    6722:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6728:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    672f:	00 
    6730:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    6735:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    673c:	00 
    673d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6741:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6748:	00 
    6749:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    674d:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    6752:	e8 99 ce ff ff       	call   35f0 <memmove@plt>
    6757:	48 8b 43 20          	mov    0x20(%rbx),%rax
    675b:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    675f:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6763:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6768:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    676d:	e9 39 fe ff ff       	jmp    65ab <fwp_p_ad_push+0x25b>
    6772:	48 c1 ff 20          	sar    $0x20,%rdi
    6776:	49 89 fe             	mov    %rdi,%r14
    6779:	e9 39 fc ff ff       	jmp    63b7 <fwp_p_ad_push+0x67>
    677e:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    6785:	00 
    6786:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    678b:	48 89 f2             	mov    %rsi,%rdx
    678e:	48 89 c6             	mov    %rax,%rsi
    6791:	e8 5a ce ff ff       	call   35f0 <memmove@plt>
    6796:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    679b:	48 03 43 30          	add    0x30(%rbx),%rax
    679f:	48 89 43 38          	mov    %rax,0x38(%rbx)
    67a3:	48 8b 43 20          	mov    0x20(%rbx),%rax
    67a7:	eb 8c                	jmp    6735 <fwp_p_ad_push+0x3e5>
    67a9:	48 8d 3d 12 6a 00 00 	lea    0x6a12(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    67b0:	e8 9b dc ff ff       	call   4450 <fwp_trap>
    67b5:	48 8d 3d eb 69 00 00 	lea    0x69eb(%rip),%rdi        # d1a7 <_IO_stdin_used+0x1a7>
    67bc:	e8 8f dc ff ff       	call   4450 <fwp_trap>
    67c1:	48 89 df             	mov    %rbx,%rdi
    67c4:	e8 c7 d4 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    67c9:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    67cd:	48 85 ff             	test   %rdi,%rdi
    67d0:	74 05                	je     67d7 <fwp_p_ad_push+0x487>
    67d2:	e8 f9 e8 ff ff       	call   50d0 <ad_raw_free.part.0>
    67d7:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    67db:	48 85 ff             	test   %rdi,%rdi
    67de:	74 05                	je     67e5 <fwp_p_ad_push+0x495>
    67e0:	e8 eb e8 ff ff       	call   50d0 <ad_raw_free.part.0>
    67e5:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    67e9:	48 85 ff             	test   %rdi,%rdi
    67ec:	74 05                	je     67f3 <fwp_p_ad_push+0x4a3>
    67ee:	e8 dd e8 ff ff       	call   50d0 <ad_raw_free.part.0>
    67f3:	31 c9                	xor    %ecx,%ecx
    67f5:	31 c0                	xor    %eax,%eax
    67f7:	31 d2                	xor    %edx,%edx
    67f9:	be 01 00 00 00       	mov    $0x1,%esi
    67fe:	89 53 04             	mov    %edx,0x4(%rbx)
    6801:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6805:	ba 13 00 00 00       	mov    $0x13,%edx
    680a:	48 8d 3d f7 67 00 00 	lea    0x67f7(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    6811:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6815:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6819:	48 8b 0d 20 a8 00 00 	mov    0xa820(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    6820:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6824:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6828:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    682c:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6830:	e8 2b ce ff ff       	call   3660 <fwrite@plt>
    6835:	31 ff                	xor    %edi,%edi
    6837:	e8 64 cd ff ff       	call   35a0 <fflush@plt>
    683c:	bf 66 00 00 00       	mov    $0x66,%edi
    6841:	e8 3a ce ff ff       	call   3680 <_Exit@plt>
    6846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    684d:	00 00 00 

0000000000006850 <w107>:
    6850:	41 56                	push   %r14
    6852:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6856:	48 89 fa             	mov    %rdi,%rdx
    6859:	41 55                	push   %r13
    685b:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    685f:	49 89 fd             	mov    %rdi,%r13
    6862:	41 54                	push   %r12
    6864:	55                   	push   %rbp
    6865:	53                   	push   %rbx
    6866:	48 83 ec 40          	sub    $0x40,%rsp
    686a:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6870:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6875:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    687c:	00 00 
    687e:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    6883:	48 89 f5             	mov    %rsi,%rbp
    6886:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    688b:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6891:	48 89 f1             	mov    %rsi,%rcx
    6894:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    689a:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    68a1:	ff ff 
    68a3:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    68aa:	00 00 
    68ac:	e8 9f fa ff ff       	call   6350 <fwp_p_ad_push>
    68b1:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    68b7:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    68bc:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    68c2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    68c9:	00 f0 3f 
    68cc:	48 89 c7             	mov    %rax,%rdi
    68cf:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    68d6:	00 f0 bf 
    68d9:	48 89 ea             	mov    %rbp,%rdx
    68dc:	66 49 0f 7e cc       	movq   %xmm1,%r12
    68e1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    68e7:	e8 64 fa ff ff       	call   6350 <fwp_p_ad_push>
    68ec:	f2 0f 10 05 ec 74 00 	movsd  0x74ec(%rip),%xmm0        # dde0 <msg.4+0xb0>
    68f3:	00 
    68f4:	4c 89 ef             	mov    %r13,%rdi
    68f7:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    68fd:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6902:	49 89 c6             	mov    %rax,%r14
    6905:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    690c:	00 f0 3f 
    690f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6916:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    691d:	00 f0 bf 
    6920:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    6925:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    692b:	e8 20 fa ff ff       	call   6350 <fwp_p_ad_push>
    6930:	4c 89 e1             	mov    %r12,%rcx
    6933:	4c 89 e6             	mov    %r12,%rsi
    6936:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    693b:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6941:	4c 89 f2             	mov    %r14,%rdx
    6944:	4c 89 f7             	mov    %r14,%rdi
    6947:	49 89 c5             	mov    %rax,%r13
    694a:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    694e:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6954:	e8 f7 f9 ff ff       	call   6350 <fwp_p_ad_push>
    6959:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    695f:	f2 0f 59 1d 81 74 00 	mulsd  0x7481(%rip),%xmm3        # dde8 <msg.4+0xb8>
    6966:	00 
    6967:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    696c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6971:	48 89 c2             	mov    %rax,%rdx
    6974:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    697b:	00 59 40 
    697e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6985:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    698b:	e8 c0 f9 ff ff       	call   6350 <fwp_p_ad_push>
    6990:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6995:	48 89 e9             	mov    %rbp,%rcx
    6998:	4c 89 ea             	mov    %r13,%rdx
    699b:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    69a1:	48 89 ee             	mov    %rbp,%rsi
    69a4:	4c 89 ef             	mov    %r13,%rdi
    69a7:	49 89 c4             	mov    %rax,%r12
    69aa:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    69ae:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    69b4:	e8 97 f9 ff ff       	call   6350 <fwp_p_ad_push>
    69b9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    69bf:	45 31 c0             	xor    %r8d,%r8d
    69c2:	4c 89 e2             	mov    %r12,%rdx
    69c5:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    69cb:	48 89 c7             	mov    %rax,%rdi
    69ce:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    69d5:	00 f0 3f 
    69d8:	48 89 ce             	mov    %rcx,%rsi
    69db:	66 48 0f 7e db       	movq   %xmm3,%rbx
    69e0:	e8 6b f9 ff ff       	call   6350 <fwp_p_ad_push>
    69e5:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    69ea:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    69f1:	00 00 
    69f3:	75 12                	jne    6a07 <w107+0x1b7>
    69f5:	48 83 c4 40          	add    $0x40,%rsp
    69f9:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    69fe:	5b                   	pop    %rbx
    69ff:	5d                   	pop    %rbp
    6a00:	41 5c                	pop    %r12
    6a02:	41 5d                	pop    %r13
    6a04:	41 5e                	pop    %r14
    6a06:	c3                   	ret
    6a07:	e8 44 ca ff ff       	call   3450 <__stack_chk_fail@plt>
    6a0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006a10 <w164.constprop.0>:
    6a10:	41 54                	push   %r12
    6a12:	55                   	push   %rbp
    6a13:	53                   	push   %rbx
    6a14:	48 83 ec 10          	sub    $0x10,%rsp
    6a18:	4c 8b 27             	mov    (%rdi),%r12
    6a1b:	4d 85 e4             	test   %r12,%r12
    6a1e:	74 58                	je     6a78 <w164.constprop.0+0x68>
    6a20:	48 89 fd             	mov    %rdi,%rbp
    6a23:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a27:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6a2e:	31 db                	xor    %ebx,%ebx
    6a30:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6a36:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    6a3b:	45 31 c0             	xor    %r8d,%r8d
    6a3e:	48 83 c3 02          	add    $0x2,%rbx
    6a42:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6a49:	00 f0 3f 
    6a4c:	48 89 ce             	mov    %rcx,%rsi
    6a4f:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6a55:	e8 f6 f8 ff ff       	call   6350 <fwp_p_ad_push>
    6a5a:	4c 39 e3             	cmp    %r12,%rbx
    6a5d:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6a63:	48 89 c7             	mov    %rax,%rdi
    6a66:	72 c8                	jb     6a30 <w164.constprop.0+0x20>
    6a68:	48 83 c4 10          	add    $0x10,%rsp
    6a6c:	48 89 f8             	mov    %rdi,%rax
    6a6f:	5b                   	pop    %rbx
    6a70:	5d                   	pop    %rbp
    6a71:	41 5c                	pop    %r12
    6a73:	c3                   	ret
    6a74:	0f 1f 40 00          	nopl   0x0(%rax)
    6a78:	48 83 c4 10          	add    $0x10,%rsp
    6a7c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6a83:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a87:	5b                   	pop    %rbx
    6a88:	48 89 f8             	mov    %rdi,%rax
    6a8b:	5d                   	pop    %rbp
    6a8c:	41 5c                	pop    %r12
    6a8e:	c3                   	ret
    6a8f:	90                   	nop

0000000000006a90 <fwp_data.part.0.constprop.0>:
    6a90:	41 56                	push   %r14
    6a92:	8b 05 2c 41 06 00    	mov    0x6412c(%rip),%eax        # 6abc4 <fwp_heap+0x13a4>
    6a98:	41 89 fe             	mov    %edi,%r14d
    6a9b:	41 55                	push   %r13
    6a9d:	44 8b 2d 44 4a 06 00 	mov    0x64a44(%rip),%r13d        # 6b4e8 <iteration_active>
    6aa4:	41 54                	push   %r12
    6aa6:	49 89 f4             	mov    %rsi,%r12
    6aa9:	55                   	push   %rbp
    6aaa:	53                   	push   %rbx
    6aab:	45 85 ed             	test   %r13d,%r13d
    6aae:	0f 84 1c 01 00 00    	je     6bd0 <fwp_data.part.0.constprop.0+0x140>
    6ab4:	48 83 05 24 4a 06 00 	addq   $0x1,0x64a24(%rip)        # 6b4e0 <iteration_requests>
    6abb:	01 
    6abc:	48 83 05 14 4a 06 00 	addq   $0x18,0x64a14(%rip)        # 6b4d8 <iteration_bytes>
    6ac3:	18 
    6ac4:	85 c0                	test   %eax,%eax
    6ac6:	0f 84 8c 01 00 00    	je     6c58 <fwp_data.part.0.constprop.0+0x1c8>
    6acc:	0f b6 05 ef 3c 06 00 	movzbl 0x63cef(%rip),%eax        # 6a7c2 <fwp_heap+0xfa2>
    6ad3:	48 8d 15 46 2d 06 00 	lea    0x62d46(%rip),%rdx        # 69820 <fwp_heap>
    6ada:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6ae1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6ae5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6ae9:	48 8b 18             	mov    (%rax),%rbx
    6aec:	48 85 db             	test   %rbx,%rbx
    6aef:	0f 84 fb 00 00 00    	je     6bf0 <fwp_data.part.0.constprop.0+0x160>
    6af5:	48 8b 13             	mov    (%rbx),%rdx
    6af8:	48 f7 d2             	not    %rdx
    6afb:	48 89 10             	mov    %rdx,(%rax)
    6afe:	48 83 fd 18          	cmp    $0x18,%rbp
    6b02:	76 1b                	jbe    6b1f <fwp_data.part.0.constprop.0+0x8f>
    6b04:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6b08:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    6b0c:	31 f6                	xor    %esi,%esi
    6b0e:	48 c1 e8 03          	shr    $0x3,%rax
    6b12:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6b19:	00 
    6b1a:	e8 91 c9 ff ff       	call   34b0 <memset@plt>
    6b1f:	48 89 e8             	mov    %rbp,%rax
    6b22:	48 03 05 17 41 06 00 	add    0x64117(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    6b29:	0f 82 3d 01 00 00    	jb     6c6c <fwp_data.part.0.constprop.0+0x1dc>
    6b2f:	48 39 05 12 41 06 00 	cmp    %rax,0x64112(%rip)        # 6ac48 <fwp_heap+0x1428>
    6b36:	48 89 05 03 41 06 00 	mov    %rax,0x64103(%rip)        # 6ac40 <fwp_heap+0x1420>
    6b3d:	73 07                	jae    6b46 <fwp_data.part.0.constprop.0+0xb6>
    6b3f:	48 89 05 02 41 06 00 	mov    %rax,0x64102(%rip)        # 6ac48 <fwp_heap+0x1428>
    6b46:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6b4a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6b4f:	f2 0f 58 05 01 41 06 	addsd  0x64101(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    6b56:	00 
    6b57:	f2 0f 11 05 f9 40 06 	movsd  %xmm0,0x640f9(%rip)        # 6ac58 <fwp_heap+0x1438>
    6b5e:	00 
    6b5f:	45 85 ed             	test   %r13d,%r13d
    6b62:	74 33                	je     6b97 <fwp_data.part.0.constprop.0+0x107>
    6b64:	48 8b 05 d5 40 06 00 	mov    0x640d5(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    6b6b:	48 85 c0             	test   %rax,%rax
    6b6e:	0f 88 a4 00 00 00    	js     6c18 <fwp_data.part.0.constprop.0+0x188>
    6b74:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6b78:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6b7d:	f2 0f 5c 05 43 49 06 	subsd  0x64943(%rip),%xmm0        # 6b4c8 <iteration_start_charge>
    6b84:	00 
    6b85:	66 0f 2f 05 33 49 06 	comisd 0x64933(%rip),%xmm0        # 6b4c0 <iteration_peak>
    6b8c:	00 
    6b8d:	76 08                	jbe    6b97 <fwp_data.part.0.constprop.0+0x107>
    6b8f:	f2 0f 11 05 29 49 06 	movsd  %xmm0,0x64929(%rip)        # 6b4c0 <iteration_peak>
    6b96:	00 
    6b97:	b8 02 00 00 00       	mov    $0x2,%eax
    6b9c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6ba1:	66 0f 6e c8          	movd   %eax,%xmm1
    6ba5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6ba9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6bad:	49 8b 04 24          	mov    (%r12),%rax
    6bb1:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6bb5:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6bba:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6bbe:	48 89 d8             	mov    %rbx,%rax
    6bc1:	5b                   	pop    %rbx
    6bc2:	5d                   	pop    %rbp
    6bc3:	41 5c                	pop    %r12
    6bc5:	41 5d                	pop    %r13
    6bc7:	41 5e                	pop    %r14
    6bc9:	c3                   	ret
    6bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bd0:	85 c0                	test   %eax,%eax
    6bd2:	0f 85 f4 fe ff ff    	jne    6acc <fwp_data.part.0.constprop.0+0x3c>
    6bd8:	31 f6                	xor    %esi,%esi
    6bda:	bf 18 00 00 00       	mov    $0x18,%edi
    6bdf:	e8 2c f3 ff ff       	call   5f10 <fwp_heap_alloc>
    6be4:	48 89 c3             	mov    %rax,%rbx
    6be7:	eb ae                	jmp    6b97 <fwp_data.part.0.constprop.0+0x107>
    6be9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bf0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6bf4:	48 85 db             	test   %rbx,%rbx
    6bf7:	74 47                	je     6c40 <fwp_data.part.0.constprop.0+0x1b0>
    6bf9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6bfd:	48 29 da             	sub    %rbx,%rdx
    6c00:	48 39 ea             	cmp    %rbp,%rdx
    6c03:	72 3b                	jb     6c40 <fwp_data.part.0.constprop.0+0x1b0>
    6c05:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6c09:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6c0d:	e9 ec fe ff ff       	jmp    6afe <fwp_data.part.0.constprop.0+0x6e>
    6c12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c18:	48 89 c2             	mov    %rax,%rdx
    6c1b:	83 e0 01             	and    $0x1,%eax
    6c1e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6c22:	48 d1 ea             	shr    $1,%rdx
    6c25:	48 09 c2             	or     %rax,%rdx
    6c28:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    6c2d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6c31:	e9 47 ff ff ff       	jmp    6b7d <fwp_data.part.0.constprop.0+0xed>
    6c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c3d:	00 00 00 
    6c40:	31 f6                	xor    %esi,%esi
    6c42:	bf 18 00 00 00       	mov    $0x18,%edi
    6c47:	e8 c4 f2 ff ff       	call   5f10 <fwp_heap_alloc>
    6c4c:	48 89 c3             	mov    %rax,%rbx
    6c4f:	e9 0b ff ff ff       	jmp    6b5f <fwp_data.part.0.constprop.0+0xcf>
    6c54:	0f 1f 40 00          	nopl   0x0(%rax)
    6c58:	31 f6                	xor    %esi,%esi
    6c5a:	bf 18 00 00 00       	mov    $0x18,%edi
    6c5f:	e8 ac f2 ff ff       	call   5f10 <fwp_heap_alloc>
    6c64:	48 89 c3             	mov    %rax,%rbx
    6c67:	e9 f8 fe ff ff       	jmp    6b64 <fwp_data.part.0.constprop.0+0xd4>
    6c6c:	e8 bf d1 ff ff       	call   3e30 <fwp_heap_oom>
    6c71:	0f 1f 40 00          	nopl   0x0(%rax)
    6c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c7c:	00 00 00 00 

0000000000006c80 <fwp_rc_share>:
    6c80:	48 8b 05 71 3f 06 00 	mov    0x63f71(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    6c87:	48 2b 3d 42 3f 06 00 	sub    0x63f42(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    6c8e:	48 c1 e0 10          	shl    $0x10,%rax
    6c92:	48 39 c7             	cmp    %rax,%rdi
    6c95:	73 4a                	jae    6ce1 <fwp_rc_share+0x61>
    6c97:	48 89 f8             	mov    %rdi,%rax
    6c9a:	48 c1 e8 10          	shr    $0x10,%rax
    6c9e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6ca2:	48 8b 05 6f 3f 06 00 	mov    0x63f6f(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    6ca9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6cad:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6cb1:	48 85 d2             	test   %rdx,%rdx
    6cb4:	74 2b                	je     6ce1 <fwp_rc_share+0x61>
    6cb6:	0f b6 08             	movzbl (%rax),%ecx
    6cb9:	80 f9 02             	cmp    $0x2,%cl
    6cbc:	74 2a                	je     6ce8 <fwp_rc_share+0x68>
    6cbe:	80 f9 01             	cmp    $0x1,%cl
    6cc1:	75 1e                	jne    6ce1 <fwp_rc_share+0x61>
    6cc3:	8b 48 18             	mov    0x18(%rax),%ecx
    6cc6:	0f b7 ff             	movzwl %di,%edi
    6cc9:	8b 40 1c             	mov    0x1c(%rax),%eax
    6ccc:	48 0f af f9          	imul   %rcx,%rdi
    6cd0:	48 c1 ef 20          	shr    $0x20,%rdi
    6cd4:	48 39 c7             	cmp    %rax,%rdi
    6cd7:	73 08                	jae    6ce1 <fwp_rc_share+0x61>
    6cd9:	48 01 fa             	add    %rdi,%rdx
    6cdc:	80 3a 00             	cmpb   $0x0,(%rdx)
    6cdf:	75 0d                	jne    6cee <fwp_rc_share+0x6e>
    6ce1:	c3                   	ret
    6ce2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ce8:	66 85 ff             	test   %di,%di
    6ceb:	74 ef                	je     6cdc <fwp_rc_share+0x5c>
    6ced:	c3                   	ret
    6cee:	50                   	push   %rax
    6cef:	48 8d 3d 8a 6d 00 00 	lea    0x6d8a(%rip),%rdi        # da80 <_IO_stdin_used+0xa80>
    6cf6:	e8 55 d7 ff ff       	call   4450 <fwp_trap>
    6cfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006d00 <fwp_rc_free_arr>:
    6d00:	48 8b 15 f1 3e 06 00 	mov    0x63ef1(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    6d07:	48 89 f8             	mov    %rdi,%rax
    6d0a:	48 2b 05 bf 3e 06 00 	sub    0x63ebf(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    6d11:	48 c1 e2 10          	shl    $0x10,%rdx
    6d15:	48 39 d0             	cmp    %rdx,%rax
    6d18:	73 5b                	jae    6d75 <fwp_rc_free_arr+0x75>
    6d1a:	48 89 c2             	mov    %rax,%rdx
    6d1d:	48 c1 ea 10          	shr    $0x10,%rdx
    6d21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d25:	48 8b 15 ec 3e 06 00 	mov    0x63eec(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    6d2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6d30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6d34:	48 85 c9             	test   %rcx,%rcx
    6d37:	74 3c                	je     6d75 <fwp_rc_free_arr+0x75>
    6d39:	0f b6 32             	movzbl (%rdx),%esi
    6d3c:	40 80 fe 02          	cmp    $0x2,%sil
    6d40:	74 2e                	je     6d70 <fwp_rc_free_arr+0x70>
    6d42:	40 80 fe 01          	cmp    $0x1,%sil
    6d46:	75 2d                	jne    6d75 <fwp_rc_free_arr+0x75>
    6d48:	8b 72 18             	mov    0x18(%rdx),%esi
    6d4b:	0f b7 c0             	movzwl %ax,%eax
    6d4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6d51:	48 0f af c6          	imul   %rsi,%rax
    6d55:	48 c1 e8 20          	shr    $0x20,%rax
    6d59:	48 39 d0             	cmp    %rdx,%rax
    6d5c:	73 17                	jae    6d75 <fwp_rc_free_arr+0x75>
    6d5e:	48 01 c1             	add    %rax,%rcx
    6d61:	80 39 01             	cmpb   $0x1,(%rcx)
    6d64:	75 0f                	jne    6d75 <fwp_rc_free_arr+0x75>
    6d66:	e9 a5 ec ff ff       	jmp    5a10 <fwp_mem_free>
    6d6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d70:	66 85 c0             	test   %ax,%ax
    6d73:	74 ec                	je     6d61 <fwp_rc_free_arr+0x61>
    6d75:	c3                   	ret
    6d76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d7d:	00 00 00 

0000000000006d80 <fwp_rc_dup>:
    6d80:	f3 0f 1e fa          	endbr64
    6d84:	48 8b 05 6d 3e 06 00 	mov    0x63e6d(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    6d8b:	48 2b 3d 3e 3e 06 00 	sub    0x63e3e(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    6d92:	48 c1 e0 10          	shl    $0x10,%rax
    6d96:	48 39 c7             	cmp    %rax,%rdi
    6d99:	73 60                	jae    6dfb <fwp_rc_dup+0x7b>
    6d9b:	48 89 f8             	mov    %rdi,%rax
    6d9e:	48 c1 e8 10          	shr    $0x10,%rax
    6da2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6da6:	48 8b 05 6b 3e 06 00 	mov    0x63e6b(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    6dad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6db1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6db5:	48 85 c0             	test   %rax,%rax
    6db8:	74 41                	je     6dfb <fwp_rc_dup+0x7b>
    6dba:	0f b6 0a             	movzbl (%rdx),%ecx
    6dbd:	80 f9 02             	cmp    $0x2,%cl
    6dc0:	74 3e                	je     6e00 <fwp_rc_dup+0x80>
    6dc2:	80 f9 01             	cmp    $0x1,%cl
    6dc5:	75 34                	jne    6dfb <fwp_rc_dup+0x7b>
    6dc7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6dca:	0f b7 ff             	movzwl %di,%edi
    6dcd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6dd0:	48 0f af f9          	imul   %rcx,%rdi
    6dd4:	48 c1 ef 20          	shr    $0x20,%rdi
    6dd8:	48 39 d7             	cmp    %rdx,%rdi
    6ddb:	73 1e                	jae    6dfb <fwp_rc_dup+0x7b>
    6ddd:	48 01 f8             	add    %rdi,%rax
    6de0:	0f b6 10             	movzbl (%rax),%edx
    6de3:	84 d2                	test   %dl,%dl
    6de5:	74 14                	je     6dfb <fwp_rc_dup+0x7b>
    6de7:	8b 0d fb 46 06 00    	mov    0x646fb(%rip),%ecx        # 6b4e8 <iteration_active>
    6ded:	85 c9                	test   %ecx,%ecx
    6def:	75 1f                	jne    6e10 <fwp_rc_dup+0x90>
    6df1:	80 fa fd             	cmp    $0xfd,%dl
    6df4:	77 2a                	ja     6e20 <fwp_rc_dup+0xa0>
    6df6:	83 c2 01             	add    $0x1,%edx
    6df9:	88 10                	mov    %dl,(%rax)
    6dfb:	c3                   	ret
    6dfc:	0f 1f 40 00          	nopl   0x0(%rax)
    6e00:	66 85 ff             	test   %di,%di
    6e03:	74 db                	je     6de0 <fwp_rc_dup+0x60>
    6e05:	c3                   	ret
    6e06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e0d:	00 00 00 
    6e10:	48 83 05 b8 46 06 00 	addq   $0x1,0x646b8(%rip)        # 6b4d0 <iteration_retains>
    6e17:	01 
    6e18:	eb d7                	jmp    6df1 <fwp_rc_dup+0x71>
    6e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e20:	48 89 c7             	mov    %rax,%rdi
    6e23:	e9 88 e8 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6e28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e2f:	00 

0000000000006e30 <fwp_owned_entry161>:
    6e30:	f3 0f 1e fa          	endbr64
    6e34:	48 83 ec 38          	sub    $0x38,%rsp
    6e38:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6e3d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6e44:	00 00 
    6e46:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6e4b:	31 c0                	xor    %eax,%eax
    6e4d:	48 8b 07             	mov    (%rdi),%rax
    6e50:	48 03 47 10          	add    0x10(%rdi),%rax
    6e54:	0f 80 c2 00 00 00    	jo     6f1c <fwp_owned_entry161+0xec>
    6e5a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6e5f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6e64:	31 ff                	xor    %edi,%edi
    6e66:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6e6a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6e6f:	e8 1c fc ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    6e74:	48 8b 15 7d 3d 06 00 	mov    0x63d7d(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    6e7b:	48 89 c6             	mov    %rax,%rsi
    6e7e:	48 2b 05 4b 3d 06 00 	sub    0x63d4b(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    6e85:	48 c1 e2 10          	shl    $0x10,%rdx
    6e89:	48 39 d0             	cmp    %rdx,%rax
    6e8c:	73 4f                	jae    6edd <fwp_owned_entry161+0xad>
    6e8e:	48 89 c2             	mov    %rax,%rdx
    6e91:	48 c1 ea 10          	shr    $0x10,%rdx
    6e95:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e99:	48 8b 15 78 3d 06 00 	mov    0x63d78(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    6ea0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ea4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ea8:	48 85 d2             	test   %rdx,%rdx
    6eab:	74 30                	je     6edd <fwp_owned_entry161+0xad>
    6ead:	0f b6 39             	movzbl (%rcx),%edi
    6eb0:	40 80 ff 02          	cmp    $0x2,%dil
    6eb4:	74 42                	je     6ef8 <fwp_owned_entry161+0xc8>
    6eb6:	40 80 ff 01          	cmp    $0x1,%dil
    6eba:	75 21                	jne    6edd <fwp_owned_entry161+0xad>
    6ebc:	8b 79 18             	mov    0x18(%rcx),%edi
    6ebf:	0f b7 c0             	movzwl %ax,%eax
    6ec2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ec5:	48 0f af c7          	imul   %rdi,%rax
    6ec9:	48 c1 e8 20          	shr    $0x20,%rax
    6ecd:	48 39 c8             	cmp    %rcx,%rax
    6ed0:	73 0b                	jae    6edd <fwp_owned_entry161+0xad>
    6ed2:	48 01 c2             	add    %rax,%rdx
    6ed5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6ed8:	74 26                	je     6f00 <fwp_owned_entry161+0xd0>
    6eda:	c6 02 01             	movb   $0x1,(%rdx)
    6edd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6ee2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ee9:	00 00 
    6eeb:	75 34                	jne    6f21 <fwp_owned_entry161+0xf1>
    6eed:	48 89 f0             	mov    %rsi,%rax
    6ef0:	48 83 c4 38          	add    $0x38,%rsp
    6ef4:	c3                   	ret
    6ef5:	0f 1f 00             	nopl   (%rax)
    6ef8:	66 85 c0             	test   %ax,%ax
    6efb:	75 e0                	jne    6edd <fwp_owned_entry161+0xad>
    6efd:	eb d6                	jmp    6ed5 <fwp_owned_entry161+0xa5>
    6eff:	90                   	nop
    6f00:	48 89 d7             	mov    %rdx,%rdi
    6f03:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6f08:	48 89 14 24          	mov    %rdx,(%rsp)
    6f0c:	e8 bf e8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6f11:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6f16:	48 8b 14 24          	mov    (%rsp),%rdx
    6f1a:	eb be                	jmp    6eda <fwp_owned_entry161+0xaa>
    6f1c:	e8 df c7 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6f21:	e8 2a c5 ff ff       	call   3450 <__stack_chk_fail@plt>
    6f26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f2d:	00 00 00 

0000000000006f30 <e161>:
    6f30:	f3 0f 1e fa          	endbr64
    6f34:	53                   	push   %rbx
    6f35:	48 83 ec 30          	sub    $0x30,%rsp
    6f39:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6f3e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f45:	00 00 
    6f47:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6f4c:	31 c0                	xor    %eax,%eax
    6f4e:	48 8b 07             	mov    (%rdi),%rax
    6f51:	48 03 47 10          	add    0x10(%rdi),%rax
    6f55:	0f 80 c9 00 00 00    	jo     7024 <e161+0xf4>
    6f5b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6f60:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6f65:	31 ff                	xor    %edi,%edi
    6f67:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6f6b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6f70:	e8 1b fb ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    6f75:	48 8b 15 7c 3c 06 00 	mov    0x63c7c(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    6f7c:	48 89 c3             	mov    %rax,%rbx
    6f7f:	48 2b 05 4a 3c 06 00 	sub    0x63c4a(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    6f86:	48 c1 e2 10          	shl    $0x10,%rdx
    6f8a:	48 39 d0             	cmp    %rdx,%rax
    6f8d:	73 4f                	jae    6fde <e161+0xae>
    6f8f:	48 89 c2             	mov    %rax,%rdx
    6f92:	48 c1 ea 10          	shr    $0x10,%rdx
    6f96:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f9a:	48 8b 15 77 3c 06 00 	mov    0x63c77(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    6fa1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6fa5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6fa9:	48 85 d2             	test   %rdx,%rdx
    6fac:	74 30                	je     6fde <e161+0xae>
    6fae:	0f b6 31             	movzbl (%rcx),%esi
    6fb1:	40 80 fe 02          	cmp    $0x2,%sil
    6fb5:	74 49                	je     7000 <e161+0xd0>
    6fb7:	40 80 fe 01          	cmp    $0x1,%sil
    6fbb:	75 21                	jne    6fde <e161+0xae>
    6fbd:	8b 71 18             	mov    0x18(%rcx),%esi
    6fc0:	0f b7 c0             	movzwl %ax,%eax
    6fc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6fc6:	48 0f af c6          	imul   %rsi,%rax
    6fca:	48 c1 e8 20          	shr    $0x20,%rax
    6fce:	48 39 c8             	cmp    %rcx,%rax
    6fd1:	73 0b                	jae    6fde <e161+0xae>
    6fd3:	48 01 c2             	add    %rax,%rdx
    6fd6:	80 3a ff             	cmpb   $0xff,(%rdx)
    6fd9:	74 35                	je     7010 <e161+0xe0>
    6fdb:	c6 02 01             	movb   $0x1,(%rdx)
    6fde:	48 89 df             	mov    %rbx,%rdi
    6fe1:	e8 9a fc ff ff       	call   6c80 <fwp_rc_share>
    6fe6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6feb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ff2:	00 00 
    6ff4:	75 33                	jne    7029 <e161+0xf9>
    6ff6:	48 83 c4 30          	add    $0x30,%rsp
    6ffa:	48 89 d8             	mov    %rbx,%rax
    6ffd:	5b                   	pop    %rbx
    6ffe:	c3                   	ret
    6fff:	90                   	nop
    7000:	66 85 c0             	test   %ax,%ax
    7003:	75 d9                	jne    6fde <e161+0xae>
    7005:	eb cf                	jmp    6fd6 <e161+0xa6>
    7007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    700e:	00 00 
    7010:	48 89 d7             	mov    %rdx,%rdi
    7013:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7018:	e8 b3 e7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    701d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7022:	eb b7                	jmp    6fdb <e161+0xab>
    7024:	e8 d7 c6 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7029:	e8 22 c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    702e:	66 90                	xchg   %ax,%ax

0000000000007030 <fwp_drop0>:
    7030:	f3 0f 1e fa          	endbr64
    7034:	48 8b 15 bd 3b 06 00 	mov    0x63bbd(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    703b:	48 89 f8             	mov    %rdi,%rax
    703e:	48 2b 05 8b 3b 06 00 	sub    0x63b8b(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7045:	48 c1 e2 10          	shl    $0x10,%rdx
    7049:	48 39 d0             	cmp    %rdx,%rax
    704c:	0f 83 be 00 00 00    	jae    7110 <fwp_drop0+0xe0>
    7052:	48 83 ec 18          	sub    $0x18,%rsp
    7056:	4c 8d 05 c3 27 06 00 	lea    0x627c3(%rip),%r8        # 69820 <fwp_heap>
    705d:	48 89 c2             	mov    %rax,%rdx
    7060:	48 c1 ea 10          	shr    $0x10,%rdx
    7064:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7068:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    706f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7073:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7077:	48 85 d2             	test   %rdx,%rdx
    707a:	74 3c                	je     70b8 <fwp_drop0+0x88>
    707c:	0f b6 31             	movzbl (%rcx),%esi
    707f:	40 80 fe 02          	cmp    $0x2,%sil
    7083:	74 3b                	je     70c0 <fwp_drop0+0x90>
    7085:	40 80 fe 01          	cmp    $0x1,%sil
    7089:	75 2d                	jne    70b8 <fwp_drop0+0x88>
    708b:	8b 71 18             	mov    0x18(%rcx),%esi
    708e:	0f b7 c0             	movzwl %ax,%eax
    7091:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7094:	48 0f af c6          	imul   %rsi,%rax
    7098:	48 c1 e8 20          	shr    $0x20,%rax
    709c:	48 39 c8             	cmp    %rcx,%rax
    709f:	73 17                	jae    70b8 <fwp_drop0+0x88>
    70a1:	48 01 c2             	add    %rax,%rdx
    70a4:	0f b6 02             	movzbl (%rdx),%eax
    70a7:	84 c0                	test   %al,%al
    70a9:	74 0d                	je     70b8 <fwp_drop0+0x88>
    70ab:	3c 01                	cmp    $0x1,%al
    70ad:	74 21                	je     70d0 <fwp_drop0+0xa0>
    70af:	3c ff                	cmp    $0xff,%al
    70b1:	74 65                	je     7118 <fwp_drop0+0xe8>
    70b3:	83 e8 01             	sub    $0x1,%eax
    70b6:	88 02                	mov    %al,(%rdx)
    70b8:	48 83 c4 18          	add    $0x18,%rsp
    70bc:	c3                   	ret
    70bd:	0f 1f 00             	nopl   (%rax)
    70c0:	66 85 c0             	test   %ax,%ax
    70c3:	74 df                	je     70a4 <fwp_drop0+0x74>
    70c5:	48 83 c4 18          	add    $0x18,%rsp
    70c9:	c3                   	ret
    70ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70d0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    70d4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    70d9:	e8 22 fc ff ff       	call   6d00 <fwp_rc_free_arr>
    70de:	4c 8d 05 3b 27 06 00 	lea    0x6273b(%rip),%r8        # 69820 <fwp_heap>
    70e5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    70ea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    70f1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    70f8:	48 c1 e2 10          	shl    $0x10,%rdx
    70fc:	48 39 d0             	cmp    %rdx,%rax
    70ff:	73 b7                	jae    70b8 <fwp_drop0+0x88>
    7101:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7106:	e9 52 ff ff ff       	jmp    705d <fwp_drop0+0x2d>
    710b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7110:	c3                   	ret
    7111:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7118:	48 89 d0             	mov    %rdx,%rax
    711b:	48 c1 e8 11          	shr    $0x11,%rax
    711f:	48 31 d0             	xor    %rdx,%rax
    7122:	48 89 c1             	mov    %rax,%rcx
    7125:	48 c1 e9 09          	shr    $0x9,%rcx
    7129:	48 31 c8             	xor    %rcx,%rax
    712c:	0f b6 c8             	movzbl %al,%ecx
    712f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7136:	00 
    7137:	48 85 c0             	test   %rax,%rax
    713a:	75 0d                	jne    7149 <fwp_drop0+0x119>
    713c:	eb 46                	jmp    7184 <fwp_drop0+0x154>
    713e:	66 90                	xchg   %ax,%ax
    7140:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7144:	48 85 c0             	test   %rax,%rax
    7147:	74 3b                	je     7184 <fwp_drop0+0x154>
    7149:	48 89 c1             	mov    %rax,%rcx
    714c:	48 39 10             	cmp    %rdx,(%rax)
    714f:	75 ef                	jne    7140 <fwp_drop0+0x110>
    7151:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7155:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7159:	48 89 48 08          	mov    %rcx,0x8(%rax)
    715d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7164:	0f 85 4e ff ff ff    	jne    70b8 <fwp_drop0+0x88>
    716a:	48 89 d7             	mov    %rdx,%rdi
    716d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7172:	e8 59 e6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7177:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    717c:	c6 02 fe             	movb   $0xfe,(%rdx)
    717f:	e9 34 ff ff ff       	jmp    70b8 <fwp_drop0+0x88>
    7184:	48 8d 3d 55 68 00 00 	lea    0x6855(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    718b:	e8 c0 d2 ff ff       	call   4450 <fwp_trap>

0000000000007190 <fwp_arg_drop12>:
    7190:	f3 0f 1e fa          	endbr64
    7194:	85 f6                	test   %esi,%esi
    7196:	75 04                	jne    719c <fwp_arg_drop12+0xc>
    7198:	85 d2                	test   %edx,%edx
    719a:	75 04                	jne    71a0 <fwp_arg_drop12+0x10>
    719c:	c3                   	ret
    719d:	0f 1f 00             	nopl   (%rax)
    71a0:	48 8b 3f             	mov    (%rdi),%rdi
    71a3:	e9 88 fe ff ff       	jmp    7030 <fwp_drop0>
    71a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    71af:	00 

00000000000071b0 <fwp_drop1>:
    71b0:	f3 0f 1e fa          	endbr64
    71b4:	48 8b 15 3d 3a 06 00 	mov    0x63a3d(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    71bb:	48 89 f8             	mov    %rdi,%rax
    71be:	48 2b 05 0b 3a 06 00 	sub    0x63a0b(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    71c5:	48 c1 e2 10          	shl    $0x10,%rdx
    71c9:	48 39 d0             	cmp    %rdx,%rax
    71cc:	0f 83 be 00 00 00    	jae    7290 <fwp_drop1+0xe0>
    71d2:	48 83 ec 18          	sub    $0x18,%rsp
    71d6:	4c 8d 05 43 26 06 00 	lea    0x62643(%rip),%r8        # 69820 <fwp_heap>
    71dd:	48 89 c2             	mov    %rax,%rdx
    71e0:	48 c1 ea 10          	shr    $0x10,%rdx
    71e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    71e8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    71ef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    71f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    71f7:	48 85 d2             	test   %rdx,%rdx
    71fa:	74 3c                	je     7238 <fwp_drop1+0x88>
    71fc:	0f b6 31             	movzbl (%rcx),%esi
    71ff:	40 80 fe 02          	cmp    $0x2,%sil
    7203:	74 3b                	je     7240 <fwp_drop1+0x90>
    7205:	40 80 fe 01          	cmp    $0x1,%sil
    7209:	75 2d                	jne    7238 <fwp_drop1+0x88>
    720b:	8b 71 18             	mov    0x18(%rcx),%esi
    720e:	0f b7 c0             	movzwl %ax,%eax
    7211:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7214:	48 0f af c6          	imul   %rsi,%rax
    7218:	48 c1 e8 20          	shr    $0x20,%rax
    721c:	48 39 c8             	cmp    %rcx,%rax
    721f:	73 17                	jae    7238 <fwp_drop1+0x88>
    7221:	48 01 c2             	add    %rax,%rdx
    7224:	0f b6 02             	movzbl (%rdx),%eax
    7227:	84 c0                	test   %al,%al
    7229:	74 0d                	je     7238 <fwp_drop1+0x88>
    722b:	3c 01                	cmp    $0x1,%al
    722d:	74 21                	je     7250 <fwp_drop1+0xa0>
    722f:	3c ff                	cmp    $0xff,%al
    7231:	74 65                	je     7298 <fwp_drop1+0xe8>
    7233:	83 e8 01             	sub    $0x1,%eax
    7236:	88 02                	mov    %al,(%rdx)
    7238:	48 83 c4 18          	add    $0x18,%rsp
    723c:	c3                   	ret
    723d:	0f 1f 00             	nopl   (%rax)
    7240:	66 85 c0             	test   %ax,%ax
    7243:	74 df                	je     7224 <fwp_drop1+0x74>
    7245:	48 83 c4 18          	add    $0x18,%rsp
    7249:	c3                   	ret
    724a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7250:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7254:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7259:	e8 a2 fa ff ff       	call   6d00 <fwp_rc_free_arr>
    725e:	4c 8d 05 bb 25 06 00 	lea    0x625bb(%rip),%r8        # 69820 <fwp_heap>
    7265:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    726a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7271:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7278:	48 c1 e2 10          	shl    $0x10,%rdx
    727c:	48 39 d0             	cmp    %rdx,%rax
    727f:	73 b7                	jae    7238 <fwp_drop1+0x88>
    7281:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7286:	e9 52 ff ff ff       	jmp    71dd <fwp_drop1+0x2d>
    728b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7290:	c3                   	ret
    7291:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7298:	48 89 d0             	mov    %rdx,%rax
    729b:	48 c1 e8 11          	shr    $0x11,%rax
    729f:	48 31 d0             	xor    %rdx,%rax
    72a2:	48 89 c1             	mov    %rax,%rcx
    72a5:	48 c1 e9 09          	shr    $0x9,%rcx
    72a9:	48 31 c8             	xor    %rcx,%rax
    72ac:	0f b6 c8             	movzbl %al,%ecx
    72af:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    72b6:	00 
    72b7:	48 85 c0             	test   %rax,%rax
    72ba:	75 0d                	jne    72c9 <fwp_drop1+0x119>
    72bc:	eb 46                	jmp    7304 <fwp_drop1+0x154>
    72be:	66 90                	xchg   %ax,%ax
    72c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    72c4:	48 85 c0             	test   %rax,%rax
    72c7:	74 3b                	je     7304 <fwp_drop1+0x154>
    72c9:	48 89 c1             	mov    %rax,%rcx
    72cc:	48 39 10             	cmp    %rdx,(%rax)
    72cf:	75 ef                	jne    72c0 <fwp_drop1+0x110>
    72d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    72d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    72d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    72dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    72e4:	0f 85 4e ff ff ff    	jne    7238 <fwp_drop1+0x88>
    72ea:	48 89 d7             	mov    %rdx,%rdi
    72ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    72f2:	e8 d9 e4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    72f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    72fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    72ff:	e9 34 ff ff ff       	jmp    7238 <fwp_drop1+0x88>
    7304:	48 8d 3d d5 66 00 00 	lea    0x66d5(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    730b:	e8 40 d1 ff ff       	call   4450 <fwp_trap>

0000000000007310 <fwp_closure_drop>:
    7310:	48 8b 15 e1 38 06 00 	mov    0x638e1(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7317:	48 89 f8             	mov    %rdi,%rax
    731a:	48 2b 05 af 38 06 00 	sub    0x638af(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7321:	48 c1 e2 10          	shl    $0x10,%rdx
    7325:	48 39 d0             	cmp    %rdx,%rax
    7328:	73 6b                	jae    7395 <fwp_closure_drop+0x85>
    732a:	48 89 c2             	mov    %rax,%rdx
    732d:	48 c1 ea 10          	shr    $0x10,%rdx
    7331:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7335:	48 8b 15 dc 38 06 00 	mov    0x638dc(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    733c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7340:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7344:	48 85 d2             	test   %rdx,%rdx
    7347:	74 4c                	je     7395 <fwp_closure_drop+0x85>
    7349:	0f b6 31             	movzbl (%rcx),%esi
    734c:	40 80 fe 02          	cmp    $0x2,%sil
    7350:	74 3e                	je     7390 <fwp_closure_drop+0x80>
    7352:	40 80 fe 01          	cmp    $0x1,%sil
    7356:	75 3d                	jne    7395 <fwp_closure_drop+0x85>
    7358:	8b 71 18             	mov    0x18(%rcx),%esi
    735b:	0f b7 c0             	movzwl %ax,%eax
    735e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7361:	48 0f af c6          	imul   %rsi,%rax
    7365:	48 c1 e8 20          	shr    $0x20,%rax
    7369:	48 39 c8             	cmp    %rcx,%rax
    736c:	73 27                	jae    7395 <fwp_closure_drop+0x85>
    736e:	48 01 c2             	add    %rax,%rdx
    7371:	0f b6 02             	movzbl (%rdx),%eax
    7374:	84 c0                	test   %al,%al
    7376:	74 1d                	je     7395 <fwp_closure_drop+0x85>
    7378:	3c 01                	cmp    $0x1,%al
    737a:	74 24                	je     73a0 <fwp_closure_drop+0x90>
    737c:	3c ff                	cmp    $0xff,%al
    737e:	74 48                	je     73c8 <fwp_closure_drop+0xb8>
    7380:	83 e8 01             	sub    $0x1,%eax
    7383:	88 02                	mov    %al,(%rdx)
    7385:	c3                   	ret
    7386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    738d:	00 00 00 
    7390:	66 85 c0             	test   %ax,%ax
    7393:	74 dc                	je     7371 <fwp_closure_drop+0x61>
    7395:	c3                   	ret
    7396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    739d:	00 00 00 
    73a0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    73a7:	ff ff 
    73a9:	48 85 c0             	test   %rax,%rax
    73ac:	74 12                	je     73c0 <fwp_closure_drop+0xb0>
    73ae:	48 89 fe             	mov    %rdi,%rsi
    73b1:	48 89 c7             	mov    %rax,%rdi
    73b4:	e9 f7 d0 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    73b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73c0:	e9 9b d2 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    73c5:	0f 1f 00             	nopl   (%rax)
    73c8:	48 89 d0             	mov    %rdx,%rax
    73cb:	48 8d 35 4e 24 06 00 	lea    0x6244e(%rip),%rsi        # 69820 <fwp_heap>
    73d2:	48 83 ec 18          	sub    $0x18,%rsp
    73d6:	48 c1 e8 11          	shr    $0x11,%rax
    73da:	48 31 d0             	xor    %rdx,%rax
    73dd:	48 89 c1             	mov    %rax,%rcx
    73e0:	48 c1 e9 09          	shr    $0x9,%rcx
    73e4:	48 31 c8             	xor    %rcx,%rax
    73e7:	0f b6 c8             	movzbl %al,%ecx
    73ea:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    73f1:	00 
    73f2:	48 85 c0             	test   %rax,%rax
    73f5:	75 12                	jne    7409 <fwp_closure_drop+0xf9>
    73f7:	eb 49                	jmp    7442 <fwp_closure_drop+0x132>
    73f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7400:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7404:	48 85 c0             	test   %rax,%rax
    7407:	74 39                	je     7442 <fwp_closure_drop+0x132>
    7409:	48 89 c1             	mov    %rax,%rcx
    740c:	48 39 10             	cmp    %rdx,(%rax)
    740f:	75 ef                	jne    7400 <fwp_closure_drop+0xf0>
    7411:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7415:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7419:	48 89 48 08          	mov    %rcx,0x8(%rax)
    741d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7424:	74 05                	je     742b <fwp_closure_drop+0x11b>
    7426:	48 83 c4 18          	add    $0x18,%rsp
    742a:	c3                   	ret
    742b:	48 89 d7             	mov    %rdx,%rdi
    742e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7433:	e8 98 e3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7438:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    743d:	c6 02 fe             	movb   $0xfe,(%rdx)
    7440:	eb e4                	jmp    7426 <fwp_closure_drop+0x116>
    7442:	48 8d 3d 97 65 00 00 	lea    0x6597(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    7449:	e8 02 d0 ff ff       	call   4450 <fwp_trap>
    744e:	66 90                	xchg   %ax,%ax

0000000000007450 <fwp_owned_tape_release>:
    7450:	48 85 ff             	test   %rdi,%rdi
    7453:	0f 84 f7 00 00 00    	je     7550 <fwp_owned_tape_release+0x100>
    7459:	41 54                	push   %r12
    745b:	55                   	push   %rbp
    745c:	53                   	push   %rbx
    745d:	48 8b 07             	mov    (%rdi),%rax
    7460:	48 85 c0             	test   %rax,%rax
    7463:	74 08                	je     746d <fwp_owned_tape_release+0x1d>
    7465:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7469:	48 89 50 08          	mov    %rdx,0x8(%rax)
    746d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7471:	48 85 d2             	test   %rdx,%rdx
    7474:	74 03                	je     7479 <fwp_owned_tape_release+0x29>
    7476:	48 89 02             	mov    %rax,(%rdx)
    7479:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    747d:	48 89 fb             	mov    %rdi,%rbx
    7480:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7484:	48 85 c0             	test   %rax,%rax
    7487:	0f 84 89 00 00 00    	je     7516 <fwp_owned_tape_release+0xc6>
    748d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7491:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7495:	7e 47                	jle    74de <fwp_owned_tape_release+0x8e>
    7497:	31 ed                	xor    %ebp,%ebp
    7499:	eb 0d                	jmp    74a8 <fwp_owned_tape_release+0x58>
    749b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    74a0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    74a4:	48 8b 40 68          	mov    0x68(%rax),%rax
    74a8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    74ac:	49 89 ec             	mov    %rbp,%r12
    74af:	48 83 c5 01          	add    $0x1,%rbp
    74b3:	49 c1 e4 04          	shl    $0x4,%r12
    74b7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    74bb:	ff d0                	call   *%rax
    74bd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    74c1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    74c6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    74ca:	ff 50 68             	call   *0x68(%rax)
    74cd:	48 8b 43 58          	mov    0x58(%rbx),%rax
    74d1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    74d5:	48 39 e8             	cmp    %rbp,%rax
    74d8:	7f c6                	jg     74a0 <fwp_owned_tape_release+0x50>
    74da:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    74de:	31 ed                	xor    %ebp,%ebp
    74e0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    74e5:	7e 28                	jle    750f <fwp_owned_tape_release+0xbf>
    74e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    74ee:	00 00 
    74f0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    74f4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    74f8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    74fc:	74 07                	je     7505 <fwp_owned_tape_release+0xb5>
    74fe:	ff 52 68             	call   *0x68(%rdx)
    7501:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7505:	48 83 c5 01          	add    $0x1,%rbp
    7509:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    750d:	7f e1                	jg     74f0 <fwp_owned_tape_release+0xa0>
    750f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7513:	ff 52 68             	call   *0x68(%rdx)
    7516:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    751a:	e8 f1 fd ff ff       	call   7310 <fwp_closure_drop>
    751f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7523:	e8 e8 fd ff ff       	call   7310 <fwp_closure_drop>
    7528:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    752c:	e8 df fd ff ff       	call   7310 <fwp_closure_drop>
    7531:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7535:	e8 d6 e4 ff ff       	call   5a10 <fwp_mem_free>
    753a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    753e:	e8 cd e4 ff ff       	call   5a10 <fwp_mem_free>
    7543:	48 89 df             	mov    %rbx,%rdi
    7546:	5b                   	pop    %rbx
    7547:	5d                   	pop    %rbp
    7548:	41 5c                	pop    %r12
    754a:	e9 c1 e4 ff ff       	jmp    5a10 <fwp_mem_free>
    754f:	90                   	nop
    7550:	c3                   	ret
    7551:	0f 1f 40 00          	nopl   0x0(%rax)
    7555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    755c:	00 00 00 00 

0000000000007560 <fwp_tape_finish>:
    7560:	f3 0f 1e fa          	endbr64
    7564:	41 55                	push   %r13
    7566:	41 54                	push   %r12
    7568:	55                   	push   %rbp
    7569:	53                   	push   %rbx
    756a:	48 83 ec 48          	sub    $0x48,%rsp
    756e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7575:	00 00 
    7577:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    757c:	48 8d 3d 1d 9b 01 00 	lea    0x19b1d(%rip),%rdi        # 210a0 <fwp_tape_workspace>
    7583:	e8 b8 db ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7588:	48 83 3d 58 9b 01 00 	cmpq   $0x0,0x19b58(%rip)        # 210e8 <fwp_ntapes>
    758f:	00 
    7590:	48 c7 05 ed 9a 01 00 	movq   $0x0,0x19aed(%rip)        # 21088 <fwp_tape_cached_bytes>
    7597:	00 00 00 00 
    759b:	7e 79                	jle    7616 <fwp_tape_finish+0xb6>
    759d:	45 31 e4             	xor    %r12d,%r12d
    75a0:	31 ed                	xor    %ebp,%ebp
    75a2:	0f 1f 00             	nopl   (%rax)
    75a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    75ac:	00 00 00 00 
    75b0:	48 8b 1d 39 9b 01 00 	mov    0x19b39(%rip),%rbx        # 210f0 <fwp_tapes>
    75b7:	48 83 c5 01          	add    $0x1,%rbp
    75bb:	4c 01 e3             	add    %r12,%rbx
    75be:	49 83 c4 68          	add    $0x68,%r12
    75c2:	48 89 df             	mov    %rbx,%rdi
    75c5:	e8 c6 c6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    75ca:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    75cf:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    75d4:	48 89 e7             	mov    %rsp,%rdi
    75d7:	48 8b 43 40          	mov    0x40(%rbx),%rax
    75db:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    75df:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    75e4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    75e9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    75ee:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    75f2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    75f7:	e8 44 db ff ff       	call   5140 <fwp_tape_buffers_dispose>
    75fc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    7600:	e8 4b fe ff ff       	call   7450 <fwp_owned_tape_release>
    7605:	48 39 2d dc 9a 01 00 	cmp    %rbp,0x19adc(%rip)        # 210e8 <fwp_ntapes>
    760c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7613:	00 
    7614:	7f 9a                	jg     75b0 <fwp_tape_finish+0x50>
    7616:	48 8b 3d d3 9a 01 00 	mov    0x19ad3(%rip),%rdi        # 210f0 <fwp_tapes>
    761d:	48 85 ff             	test   %rdi,%rdi
    7620:	74 05                	je     7627 <fwp_tape_finish+0xc7>
    7622:	e8 a9 da ff ff       	call   50d0 <ad_raw_free.part.0>
    7627:	48 c7 05 be 9a 01 00 	movq   $0x0,0x19abe(%rip)        # 210f0 <fwp_tapes>
    762e:	00 00 00 00 
    7632:	48 c7 05 a3 9a 01 00 	movq   $0x0,0x19aa3(%rip)        # 210e0 <fwp_tapes_cap>
    7639:	00 00 00 00 
    763d:	48 c7 05 a0 9a 01 00 	movq   $0x0,0x19aa0(%rip)        # 210e8 <fwp_ntapes>
    7644:	00 00 00 00 
    7648:	48 c7 05 85 9a 01 00 	movq   $0x0,0x19a85(%rip)        # 210d8 <fwp_tape_next_slot>
    764f:	00 00 00 00 
    7653:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7658:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    765f:	00 00 
    7661:	75 0b                	jne    766e <fwp_tape_finish+0x10e>
    7663:	48 83 c4 48          	add    $0x48,%rsp
    7667:	5b                   	pop    %rbx
    7668:	5d                   	pop    %rbp
    7669:	41 5c                	pop    %r12
    766b:	41 5d                	pop    %r13
    766d:	c3                   	ret
    766e:	e8 dd bd ff ff       	call   3450 <__stack_chk_fail@plt>
    7673:	66 90                	xchg   %ax,%ax
    7675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    767c:	00 00 00 00 

0000000000007680 <fwp_tape_scope_release>:
    7680:	f3 0f 1e fa          	endbr64
    7684:	41 55                	push   %r13
    7686:	41 54                	push   %r12
    7688:	55                   	push   %rbp
    7689:	53                   	push   %rbx
    768a:	48 83 ec 48          	sub    $0x48,%rsp
    768e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7695:	00 00 
    7697:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    769c:	48 63 07             	movslq (%rdi),%rax
    769f:	85 c0                	test   %eax,%eax
    76a1:	0f 88 e8 00 00 00    	js     778f <fwp_tape_scope_release+0x10f>
    76a7:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    76ae:	ec c4 4e 
    76b1:	48 89 fb             	mov    %rdi,%rbx
    76b4:	48 89 e5             	mov    %rsp,%rbp
    76b7:	eb 1f                	jmp    76d8 <fwp_tape_scope_release+0x58>
    76b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76c0:	e8 7b da ff ff       	call   5140 <fwp_tape_buffers_dispose>
    76c5:	4c 89 ef             	mov    %r13,%rdi
    76c8:	e8 83 fd ff ff       	call   7450 <fwp_owned_tape_release>
    76cd:	48 63 03             	movslq (%rbx),%rax
    76d0:	85 c0                	test   %eax,%eax
    76d2:	0f 88 b7 00 00 00    	js     778f <fwp_tape_scope_release+0x10f>
    76d8:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    76dc:	48 8b 35 0d 9a 01 00 	mov    0x19a0d(%rip),%rsi        # 210f0 <fwp_tapes>
    76e3:	4c 01 c6             	add    %r8,%rsi
    76e6:	48 89 f7             	mov    %rsi,%rdi
    76e9:	e8 a2 c5 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    76ee:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    76f3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    76f8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    76ff:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7703:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7707:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    770e:	00 
    770f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7714:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7719:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    771d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7722:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7726:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    772b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7732:	00 
    7733:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    773a:	00 
    773b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7742:	00 
    7743:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7747:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    774b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    774f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7753:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7759:	77 18                	ja     7773 <fwp_tape_scope_release+0xf3>
    775b:	49 c1 f8 03          	sar    $0x3,%r8
    775f:	4d 0f af c4          	imul   %r12,%r8
    7763:	4c 3b 05 6e 99 01 00 	cmp    0x1996e(%rip),%r8        # 210d8 <fwp_tape_next_slot>
    776a:	7d 07                	jge    7773 <fwp_tape_scope_release+0xf3>
    776c:	4c 89 05 65 99 01 00 	mov    %r8,0x19965(%rip)        # 210d8 <fwp_tape_next_slot>
    7773:	48 89 ef             	mov    %rbp,%rdi
    7776:	4d 85 ed             	test   %r13,%r13
    7779:	0f 85 41 ff ff ff    	jne    76c0 <fwp_tape_scope_release+0x40>
    777f:	e8 dc da ff ff       	call   5260 <fwp_tape_buffers_release>
    7784:	48 63 03             	movslq (%rbx),%rax
    7787:	85 c0                	test   %eax,%eax
    7789:	0f 89 49 ff ff ff    	jns    76d8 <fwp_tape_scope_release+0x58>
    778f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7794:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    779b:	00 00 
    779d:	75 0b                	jne    77aa <fwp_tape_scope_release+0x12a>
    779f:	48 83 c4 48          	add    $0x48,%rsp
    77a3:	5b                   	pop    %rbx
    77a4:	5d                   	pop    %rbp
    77a5:	41 5c                	pop    %r12
    77a7:	41 5d                	pop    %r13
    77a9:	c3                   	ret
    77aa:	e8 a1 bc ff ff       	call   3450 <__stack_chk_fail@plt>
    77af:	90                   	nop

00000000000077b0 <fwp_task_dispose>:
    77b0:	53                   	push   %rbx
    77b1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    77b5:	0f 84 8b bf ff ff    	je     3746 <fwp_task_dispose.cold>
    77bb:	48 89 fb             	mov    %rdi,%rbx
    77be:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    77c3:	0f 85 7d bf ff ff    	jne    3746 <fwp_task_dispose.cold>
    77c9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    77cd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    77d4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    77db:	00 
    77dc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    77e0:	48 85 ff             	test   %rdi,%rdi
    77e3:	74 07                	je     77ec <fwp_task_dispose+0x3c>
    77e5:	48 85 c0             	test   %rax,%rax
    77e8:	74 02                	je     77ec <fwp_task_dispose+0x3c>
    77ea:	ff d0                	call   *%rax
    77ec:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    77f3:	e8 18 e2 ff ff       	call   5a10 <fwp_mem_free>
    77f8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    77ff:	00 00 00 00 
    7803:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7807:	74 6f                	je     7878 <fwp_task_dispose+0xc8>
    7809:	48 8b 15 e8 33 06 00 	mov    0x633e8(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7810:	48 89 d8             	mov    %rbx,%rax
    7813:	48 2b 05 b6 33 06 00 	sub    0x633b6(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    781a:	48 c1 e2 10          	shl    $0x10,%rdx
    781e:	48 39 d0             	cmp    %rdx,%rax
    7821:	73 4c                	jae    786f <fwp_task_dispose+0xbf>
    7823:	48 89 c2             	mov    %rax,%rdx
    7826:	48 c1 ea 10          	shr    $0x10,%rdx
    782a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    782e:	48 8b 15 e3 33 06 00 	mov    0x633e3(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    7835:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7839:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    783d:	48 85 c9             	test   %rcx,%rcx
    7840:	74 2d                	je     786f <fwp_task_dispose+0xbf>
    7842:	0f b6 32             	movzbl (%rdx),%esi
    7845:	40 80 fe 02          	cmp    $0x2,%sil
    7849:	74 3d                	je     7888 <fwp_task_dispose+0xd8>
    784b:	40 80 fe 01          	cmp    $0x1,%sil
    784f:	75 1e                	jne    786f <fwp_task_dispose+0xbf>
    7851:	8b 72 18             	mov    0x18(%rdx),%esi
    7854:	0f b7 c0             	movzwl %ax,%eax
    7857:	8b 52 1c             	mov    0x1c(%rdx),%edx
    785a:	48 0f af c6          	imul   %rsi,%rax
    785e:	48 c1 e8 20          	shr    $0x20,%rax
    7862:	48 39 d0             	cmp    %rdx,%rax
    7865:	73 08                	jae    786f <fwp_task_dispose+0xbf>
    7867:	48 01 c1             	add    %rax,%rcx
    786a:	80 39 01             	cmpb   $0x1,(%rcx)
    786d:	74 09                	je     7878 <fwp_task_dispose+0xc8>
    786f:	5b                   	pop    %rbx
    7870:	c3                   	ret
    7871:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7878:	48 89 df             	mov    %rbx,%rdi
    787b:	5b                   	pop    %rbx
    787c:	e9 8f e1 ff ff       	jmp    5a10 <fwp_mem_free>
    7881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7888:	66 85 c0             	test   %ax,%ax
    788b:	74 dd                	je     786a <fwp_task_dispose+0xba>
    788d:	5b                   	pop    %rbx
    788e:	c3                   	ret
    788f:	90                   	nop

0000000000007890 <fwp_free_zombie>:
    7890:	48 8b 15 59 1f 06 00 	mov    0x61f59(%rip),%rdx        # 697f0 <fwp_zombie>
    7897:	48 85 d2             	test   %rdx,%rdx
    789a:	0f 84 98 00 00 00    	je     7938 <fwp_free_zombie+0xa8>
    78a0:	48 3b 15 59 1f 06 00 	cmp    0x61f59(%rip),%rdx        # 69800 <fwp_cur>
    78a7:	0f 84 8b 00 00 00    	je     7938 <fwp_free_zombie+0xa8>
    78ad:	48 83 ec 18          	sub    $0x18,%rsp
    78b1:	48 63 05 1c 19 06 00 	movslq 0x6191c(%rip),%rax        # 691d4 <fwp_stack_pool_n>
    78b8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    78bc:	83 f8 3f             	cmp    $0x3f,%eax
    78bf:	7f 7f                	jg     7940 <fwp_free_zombie+0xb0>
    78c1:	8d 48 01             	lea    0x1(%rax),%ecx
    78c4:	89 0d 0a 19 06 00    	mov    %ecx,0x6190a(%rip)        # 691d4 <fwp_stack_pool_n>
    78ca:	48 8d 0d 0f 19 06 00 	lea    0x6190f(%rip),%rcx        # 691e0 <fwp_stack_pool>
    78d1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    78d5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    78dc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    78e0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    78e7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    78eb:	48 85 c9             	test   %rcx,%rcx
    78ee:	0f 84 fc 00 00 00    	je     79f0 <fwp_free_zombie+0x160>
    78f4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    78fb:	48 85 c0             	test   %rax,%rax
    78fe:	74 07                	je     7907 <fwp_free_zombie+0x77>
    7900:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7907:	8b 42 5c             	mov    0x5c(%rdx),%eax
    790a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    790e:	48 c7 05 d7 1e 06 00 	movq   $0x0,0x61ed7(%rip)        # 697f0 <fwp_zombie>
    7915:	00 00 00 00 
    7919:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7920:	85 c0                	test   %eax,%eax
    7922:	74 34                	je     7958 <fwp_free_zombie+0xc8>
    7924:	83 f8 01             	cmp    $0x1,%eax
    7927:	0f 84 b3 00 00 00    	je     79e0 <fwp_free_zombie+0x150>
    792d:	48 83 c4 18          	add    $0x18,%rsp
    7931:	c3                   	ret
    7932:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7938:	c3                   	ret
    7939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7940:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7944:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7949:	e8 72 bc ff ff       	call   35c0 <munmap@plt>
    794e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7953:	eb 80                	jmp    78d5 <fwp_free_zombie+0x45>
    7955:	0f 1f 00             	nopl   (%rax)
    7958:	48 8b 0d 99 32 06 00 	mov    0x63299(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    795f:	48 89 d0             	mov    %rdx,%rax
    7962:	48 2b 05 67 32 06 00 	sub    0x63267(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7969:	48 c1 e1 10          	shl    $0x10,%rcx
    796d:	48 39 c8             	cmp    %rcx,%rax
    7970:	73 bb                	jae    792d <fwp_free_zombie+0x9d>
    7972:	48 89 c1             	mov    %rax,%rcx
    7975:	48 c1 e9 10          	shr    $0x10,%rcx
    7979:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    797d:	48 8b 0d 94 32 06 00 	mov    0x63294(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    7984:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7988:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    798c:	48 85 c9             	test   %rcx,%rcx
    798f:	74 9c                	je     792d <fwp_free_zombie+0x9d>
    7991:	0f b6 3e             	movzbl (%rsi),%edi
    7994:	40 80 ff 02          	cmp    $0x2,%dil
    7998:	74 66                	je     7a00 <fwp_free_zombie+0x170>
    799a:	40 80 ff 01          	cmp    $0x1,%dil
    799e:	75 8d                	jne    792d <fwp_free_zombie+0x9d>
    79a0:	8b 7e 18             	mov    0x18(%rsi),%edi
    79a3:	0f b7 c0             	movzwl %ax,%eax
    79a6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    79a9:	48 0f af c7          	imul   %rdi,%rax
    79ad:	48 c1 e8 20          	shr    $0x20,%rax
    79b1:	48 39 f0             	cmp    %rsi,%rax
    79b4:	0f 83 73 ff ff ff    	jae    792d <fwp_free_zombie+0x9d>
    79ba:	48 01 c1             	add    %rax,%rcx
    79bd:	0f b6 01             	movzbl (%rcx),%eax
    79c0:	84 c0                	test   %al,%al
    79c2:	0f 84 65 ff ff ff    	je     792d <fwp_free_zombie+0x9d>
    79c8:	3c 01                	cmp    $0x1,%al
    79ca:	74 14                	je     79e0 <fwp_free_zombie+0x150>
    79cc:	3c ff                	cmp    $0xff,%al
    79ce:	74 3b                	je     7a0b <fwp_free_zombie+0x17b>
    79d0:	83 e8 01             	sub    $0x1,%eax
    79d3:	88 01                	mov    %al,(%rcx)
    79d5:	e9 53 ff ff ff       	jmp    792d <fwp_free_zombie+0x9d>
    79da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79e0:	48 89 d7             	mov    %rdx,%rdi
    79e3:	48 83 c4 18          	add    $0x18,%rsp
    79e7:	e9 c4 fd ff ff       	jmp    77b0 <fwp_task_dispose>
    79ec:	0f 1f 40 00          	nopl   0x0(%rax)
    79f0:	48 89 05 d1 1d 06 00 	mov    %rax,0x61dd1(%rip)        # 697c8 <fwp_tasks_active>
    79f7:	e9 ff fe ff ff       	jmp    78fb <fwp_free_zombie+0x6b>
    79fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7a00:	66 85 c0             	test   %ax,%ax
    7a03:	0f 85 24 ff ff ff    	jne    792d <fwp_free_zombie+0x9d>
    7a09:	eb b2                	jmp    79bd <fwp_free_zombie+0x12d>
    7a0b:	48 89 ca             	mov    %rcx,%rdx
    7a0e:	48 8d 35 0b 1e 06 00 	lea    0x61e0b(%rip),%rsi        # 69820 <fwp_heap>
    7a15:	48 c1 ea 11          	shr    $0x11,%rdx
    7a19:	48 31 ca             	xor    %rcx,%rdx
    7a1c:	48 89 d0             	mov    %rdx,%rax
    7a1f:	48 c1 e8 09          	shr    $0x9,%rax
    7a23:	48 31 c2             	xor    %rax,%rdx
    7a26:	0f b6 d2             	movzbl %dl,%edx
    7a29:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7a30:	00 
    7a31:	48 85 c0             	test   %rax,%rax
    7a34:	75 13                	jne    7a49 <fwp_free_zombie+0x1b9>
    7a36:	eb 4c                	jmp    7a84 <fwp_free_zombie+0x1f4>
    7a38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7a3f:	00 
    7a40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7a44:	48 85 c0             	test   %rax,%rax
    7a47:	74 3b                	je     7a84 <fwp_free_zombie+0x1f4>
    7a49:	48 89 c2             	mov    %rax,%rdx
    7a4c:	48 39 08             	cmp    %rcx,(%rax)
    7a4f:	75 ef                	jne    7a40 <fwp_free_zombie+0x1b0>
    7a51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a55:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7a59:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7a5d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7a64:	0f 85 c3 fe ff ff    	jne    792d <fwp_free_zombie+0x9d>
    7a6a:	48 89 cf             	mov    %rcx,%rdi
    7a6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7a72:	e8 59 dd ff ff       	call   57d0 <fwp_rc_forget_slot>
    7a77:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7a7c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7a7f:	e9 a9 fe ff ff       	jmp    792d <fwp_free_zombie+0x9d>
    7a84:	48 8d 3d 55 5f 00 00 	lea    0x5f55(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    7a8b:	e8 c0 c9 ff ff       	call   4450 <fwp_trap>

0000000000007a90 <fwp_block>:
    7a90:	48 83 ec 08          	sub    $0x8,%rsp
    7a94:	48 8b 05 4d 1d 06 00 	mov    0x61d4d(%rip),%rax        # 697e8 <fwp_ready_head>
    7a9b:	48 85 c0             	test   %rax,%rax
    7a9e:	0f 84 1c 01 00 00    	je     7bc0 <fwp_block+0x130>
    7aa4:	90                   	nop
    7aa5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7aac:	00 00 00 00 
    7ab0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7ab7:	48 89 15 2a 1d 06 00 	mov    %rdx,0x61d2a(%rip)        # 697e8 <fwp_ready_head>
    7abe:	48 85 d2             	test   %rdx,%rdx
    7ac1:	0f 84 19 01 00 00    	je     7be0 <fwp_block+0x150>
    7ac7:	48 8b 15 32 1d 06 00 	mov    0x61d32(%rip),%rdx        # 69800 <fwp_cur>
    7ace:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7ad2:	48 39 c2             	cmp    %rax,%rdx
    7ad5:	0f 84 d5 00 00 00    	je     7bb0 <fwp_block+0x120>
    7adb:	48 8b 0d a6 39 06 00 	mov    0x639a6(%rip),%rcx        # 6b488 <fwp_state_owners>
    7ae2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7ae6:	48 89 05 13 1d 06 00 	mov    %rax,0x61d13(%rip)        # 69800 <fwp_cur>
    7aed:	f3 0f 7e 05 bb 39 06 	movq   0x639bb(%rip),%xmm0        # 6b4b0 <fwp_foreign_callbacks>
    7af4:	00 
    7af5:	0f 16 05 a4 39 06 00 	movhps 0x639a4(%rip),%xmm0        # 6b4a0 <fwp_state>
    7afc:	f3 0f 7e 0d a4 39 06 	movq   0x639a4(%rip),%xmm1        # 6b4a8 <fwp_handlers>
    7b03:	00 
    7b04:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7b0b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7b12:	0f 16 0d 9f 39 06 00 	movhps 0x6399f(%rip),%xmm1        # 6b4b8 <fwp_cleanups>
    7b19:	f3 0f 7e 05 77 39 06 	movq   0x63977(%rip),%xmm0        # 6b498 <fwp_state_len>
    7b20:	00 
    7b21:	0f 16 05 68 39 06 00 	movhps 0x63968(%rip),%xmm0        # 6b490 <fwp_state_cap>
    7b28:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7b2f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7b36:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7b3a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7b41:	48 89 0d 60 39 06 00 	mov    %rcx,0x63960(%rip)        # 6b4a8 <fwp_handlers>
    7b48:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7b4f:	48 89 0d 62 39 06 00 	mov    %rcx,0x63962(%rip)        # 6b4b8 <fwp_cleanups>
    7b56:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7b5d:	48 89 0d 4c 39 06 00 	mov    %rcx,0x6394c(%rip)        # 6b4b0 <fwp_foreign_callbacks>
    7b64:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7b6b:	48 89 0d 2e 39 06 00 	mov    %rcx,0x6392e(%rip)        # 6b4a0 <fwp_state>
    7b72:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7b79:	48 89 0d 18 39 06 00 	mov    %rcx,0x63918(%rip)        # 6b498 <fwp_state_len>
    7b80:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7b87:	48 89 0d 02 39 06 00 	mov    %rcx,0x63902(%rip)        # 6b490 <fwp_state_cap>
    7b8e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7b95:	48 89 0d ec 38 06 00 	mov    %rcx,0x638ec(%rip)        # 6b488 <fwp_state_owners>
    7b9c:	e8 df b8 ff ff       	call   3480 <swapcontext@plt>
    7ba1:	f3 0f 1e fa          	endbr64
    7ba5:	e8 e6 fc ff ff       	call   7890 <fwp_free_zombie>
    7baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bb0:	8b 05 1a 16 06 00    	mov    0x6161a(%rip),%eax        # 691d0 <fwp_slice>
    7bb6:	85 c0                	test   %eax,%eax
    7bb8:	74 36                	je     7bf0 <fwp_block+0x160>
    7bba:	48 83 c4 08          	add    $0x8,%rsp
    7bbe:	c3                   	ret
    7bbf:	90                   	nop
    7bc0:	e8 4b d8 ff ff       	call   5410 <fwp_poll_events>
    7bc5:	48 8b 05 1c 1c 06 00 	mov    0x61c1c(%rip),%rax        # 697e8 <fwp_ready_head>
    7bcc:	48 85 c0             	test   %rax,%rax
    7bcf:	0f 85 db fe ff ff    	jne    7ab0 <fwp_block+0x20>
    7bd5:	eb e9                	jmp    7bc0 <fwp_block+0x130>
    7bd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bde:	00 00 
    7be0:	48 c7 05 f5 1b 06 00 	movq   $0x0,0x61bf5(%rip)        # 697e0 <fwp_ready_tail>
    7be7:	00 00 00 00 
    7beb:	e9 d7 fe ff ff       	jmp    7ac7 <fwp_block+0x37>
    7bf0:	48 8d 3d e8 55 00 00 	lea    0x55e8(%rip),%rdi        # d1df <_IO_stdin_used+0x1df>
    7bf7:	e8 94 b7 ff ff       	call   3390 <getenv@plt>
    7bfc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7c01:	48 85 c0             	test   %rax,%rax
    7c04:	74 05                	je     7c0b <fwp_block+0x17b>
    7c06:	80 38 00             	cmpb   $0x0,(%rax)
    7c09:	75 0b                	jne    7c16 <fwp_block+0x186>
    7c0b:	89 15 bf 15 06 00    	mov    %edx,0x615bf(%rip)        # 691d0 <fwp_slice>
    7c11:	48 83 c4 08          	add    $0x8,%rsp
    7c15:	c3                   	ret
    7c16:	ba 0a 00 00 00       	mov    $0xa,%edx
    7c1b:	31 f6                	xor    %esi,%esi
    7c1d:	48 89 c7             	mov    %rax,%rdi
    7c20:	e8 1b b9 ff ff       	call   3540 <strtoll@plt>
    7c25:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7c29:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7c30:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7c35:	0f 46 d0             	cmovbe %eax,%edx
    7c38:	eb d1                	jmp    7c0b <fwp_block+0x17b>
    7c3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007c40 <fwp_drop4>:
    7c40:	48 8b 15 b1 2f 06 00 	mov    0x62fb1(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7c47:	48 89 f8             	mov    %rdi,%rax
    7c4a:	48 2b 05 7f 2f 06 00 	sub    0x62f7f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7c51:	48 c1 e2 10          	shl    $0x10,%rdx
    7c55:	48 39 d0             	cmp    %rdx,%rax
    7c58:	0f 83 52 01 00 00    	jae    7db0 <fwp_drop4+0x170>
    7c5e:	48 83 ec 18          	sub    $0x18,%rsp
    7c62:	4c 8d 05 b7 1b 06 00 	lea    0x61bb7(%rip),%r8        # 69820 <fwp_heap>
    7c69:	48 89 c2             	mov    %rax,%rdx
    7c6c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7c73:	48 c1 ea 10          	shr    $0x10,%rdx
    7c77:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7c7b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7c7f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7c83:	48 85 d2             	test   %rdx,%rdx
    7c86:	74 46                	je     7cce <fwp_drop4+0x8e>
    7c88:	44 0f b6 09          	movzbl (%rcx),%r9d
    7c8c:	41 80 f9 02          	cmp    $0x2,%r9b
    7c90:	0f 84 ca 00 00 00    	je     7d60 <fwp_drop4+0x120>
    7c96:	41 80 f9 01          	cmp    $0x1,%r9b
    7c9a:	75 32                	jne    7cce <fwp_drop4+0x8e>
    7c9c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7ca0:	0f b7 c0             	movzwl %ax,%eax
    7ca3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ca6:	49 0f af c1          	imul   %r9,%rax
    7caa:	48 c1 e8 20          	shr    $0x20,%rax
    7cae:	48 39 c8             	cmp    %rcx,%rax
    7cb1:	73 1b                	jae    7cce <fwp_drop4+0x8e>
    7cb3:	48 01 c2             	add    %rax,%rdx
    7cb6:	0f b6 02             	movzbl (%rdx),%eax
    7cb9:	84 c0                	test   %al,%al
    7cbb:	74 11                	je     7cce <fwp_drop4+0x8e>
    7cbd:	3c 01                	cmp    $0x1,%al
    7cbf:	74 17                	je     7cd8 <fwp_drop4+0x98>
    7cc1:	3c ff                	cmp    $0xff,%al
    7cc3:	0f 84 ef 00 00 00    	je     7db8 <fwp_drop4+0x178>
    7cc9:	83 e8 01             	sub    $0x1,%eax
    7ccc:	88 02                	mov    %al,(%rdx)
    7cce:	48 83 c4 18          	add    $0x18,%rsp
    7cd2:	c3                   	ret
    7cd3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7cd8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7cdc:	0f 88 8e 00 00 00    	js     7d70 <fwp_drop4+0x130>
    7ce2:	48 8b 15 0f 2f 06 00 	mov    0x62f0f(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7ce9:	48 89 f8             	mov    %rdi,%rax
    7cec:	48 2b 05 dd 2e 06 00 	sub    0x62edd(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7cf3:	48 c1 e2 10          	shl    $0x10,%rdx
    7cf7:	48 39 d0             	cmp    %rdx,%rax
    7cfa:	73 d2                	jae    7cce <fwp_drop4+0x8e>
    7cfc:	48 89 c2             	mov    %rax,%rdx
    7cff:	48 c1 ea 10          	shr    $0x10,%rdx
    7d03:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7d07:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7d0b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7d0f:	48 85 c9             	test   %rcx,%rcx
    7d12:	74 ba                	je     7cce <fwp_drop4+0x8e>
    7d14:	0f b6 32             	movzbl (%rdx),%esi
    7d17:	40 80 fe 02          	cmp    $0x2,%sil
    7d1b:	74 33                	je     7d50 <fwp_drop4+0x110>
    7d1d:	40 80 fe 01          	cmp    $0x1,%sil
    7d21:	75 ab                	jne    7cce <fwp_drop4+0x8e>
    7d23:	8b 72 18             	mov    0x18(%rdx),%esi
    7d26:	0f b7 c0             	movzwl %ax,%eax
    7d29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d2c:	48 0f af c6          	imul   %rsi,%rax
    7d30:	48 c1 e8 20          	shr    $0x20,%rax
    7d34:	48 39 d0             	cmp    %rdx,%rax
    7d37:	73 95                	jae    7cce <fwp_drop4+0x8e>
    7d39:	48 01 c1             	add    %rax,%rcx
    7d3c:	80 39 01             	cmpb   $0x1,(%rcx)
    7d3f:	75 8d                	jne    7cce <fwp_drop4+0x8e>
    7d41:	48 83 c4 18          	add    $0x18,%rsp
    7d45:	e9 c6 dc ff ff       	jmp    5a10 <fwp_mem_free>
    7d4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d50:	66 85 c0             	test   %ax,%ax
    7d53:	74 e7                	je     7d3c <fwp_drop4+0xfc>
    7d55:	48 83 c4 18          	add    $0x18,%rsp
    7d59:	c3                   	ret
    7d5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d60:	66 85 c0             	test   %ax,%ax
    7d63:	0f 84 4d ff ff ff    	je     7cb6 <fwp_drop4+0x76>
    7d69:	48 83 c4 18          	add    $0x18,%rsp
    7d6d:	c3                   	ret
    7d6e:	66 90                	xchg   %ax,%ax
    7d70:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7d74:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7d79:	e8 82 ef ff ff       	call   6d00 <fwp_rc_free_arr>
    7d7e:	4c 8d 05 9b 1a 06 00 	lea    0x61a9b(%rip),%r8        # 69820 <fwp_heap>
    7d85:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7d8a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7d91:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7d98:	48 c1 e2 10          	shl    $0x10,%rdx
    7d9c:	48 39 d0             	cmp    %rdx,%rax
    7d9f:	0f 83 29 ff ff ff    	jae    7cce <fwp_drop4+0x8e>
    7da5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7daa:	e9 ba fe ff ff       	jmp    7c69 <fwp_drop4+0x29>
    7daf:	90                   	nop
    7db0:	c3                   	ret
    7db1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7db8:	48 89 d0             	mov    %rdx,%rax
    7dbb:	48 c1 e8 11          	shr    $0x11,%rax
    7dbf:	48 31 d0             	xor    %rdx,%rax
    7dc2:	48 89 c1             	mov    %rax,%rcx
    7dc5:	48 c1 e9 09          	shr    $0x9,%rcx
    7dc9:	48 31 c8             	xor    %rcx,%rax
    7dcc:	0f b6 c8             	movzbl %al,%ecx
    7dcf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7dd6:	00 
    7dd7:	48 85 c0             	test   %rax,%rax
    7dda:	75 0d                	jne    7de9 <fwp_drop4+0x1a9>
    7ddc:	eb 46                	jmp    7e24 <fwp_drop4+0x1e4>
    7dde:	66 90                	xchg   %ax,%ax
    7de0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7de4:	48 85 c0             	test   %rax,%rax
    7de7:	74 3b                	je     7e24 <fwp_drop4+0x1e4>
    7de9:	48 89 c1             	mov    %rax,%rcx
    7dec:	48 39 10             	cmp    %rdx,(%rax)
    7def:	75 ef                	jne    7de0 <fwp_drop4+0x1a0>
    7df1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7df5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7df9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7dfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7e04:	0f 85 c4 fe ff ff    	jne    7cce <fwp_drop4+0x8e>
    7e0a:	48 89 d7             	mov    %rdx,%rdi
    7e0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e12:	e8 b9 d9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7e17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7e1f:	e9 aa fe ff ff       	jmp    7cce <fwp_drop4+0x8e>
    7e24:	48 8d 3d b5 5b 00 00 	lea    0x5bb5(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    7e2b:	e8 20 c6 ff ff       	call   4450 <fwp_trap>

0000000000007e30 <fwp_caps161>:
    7e30:	f3 0f 1e fa          	endbr64
    7e34:	85 f6                	test   %esi,%esi
    7e36:	74 08                	je     7e40 <fwp_caps161+0x10>
    7e38:	c3                   	ret
    7e39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e40:	48 8b 15 b1 2d 06 00 	mov    0x62db1(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7e47:	48 89 f8             	mov    %rdi,%rax
    7e4a:	48 2b 05 7f 2d 06 00 	sub    0x62d7f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7e51:	48 c1 e2 10          	shl    $0x10,%rdx
    7e55:	48 39 d0             	cmp    %rdx,%rax
    7e58:	73 de                	jae    7e38 <fwp_caps161+0x8>
    7e5a:	48 89 c2             	mov    %rax,%rdx
    7e5d:	48 c1 ea 10          	shr    $0x10,%rdx
    7e61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e65:	48 8b 15 ac 2d 06 00 	mov    0x62dac(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    7e6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e70:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7e74:	48 85 c9             	test   %rcx,%rcx
    7e77:	74 bf                	je     7e38 <fwp_caps161+0x8>
    7e79:	0f b6 32             	movzbl (%rdx),%esi
    7e7c:	40 80 fe 02          	cmp    $0x2,%sil
    7e80:	74 2e                	je     7eb0 <fwp_caps161+0x80>
    7e82:	40 80 fe 01          	cmp    $0x1,%sil
    7e86:	75 b0                	jne    7e38 <fwp_caps161+0x8>
    7e88:	8b 72 18             	mov    0x18(%rdx),%esi
    7e8b:	0f b7 c0             	movzwl %ax,%eax
    7e8e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e91:	48 0f af c6          	imul   %rsi,%rax
    7e95:	48 c1 e8 20          	shr    $0x20,%rax
    7e99:	48 39 d0             	cmp    %rdx,%rax
    7e9c:	73 9a                	jae    7e38 <fwp_caps161+0x8>
    7e9e:	48 01 c1             	add    %rax,%rcx
    7ea1:	80 39 01             	cmpb   $0x1,(%rcx)
    7ea4:	75 92                	jne    7e38 <fwp_caps161+0x8>
    7ea6:	e9 65 db ff ff       	jmp    5a10 <fwp_mem_free>
    7eab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7eb0:	66 85 c0             	test   %ax,%ax
    7eb3:	74 ec                	je     7ea1 <fwp_caps161+0x71>
    7eb5:	c3                   	ret
    7eb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7ebd:	00 00 00 

0000000000007ec0 <f12>:
    7ec0:	41 57                	push   %r15
    7ec2:	41 56                	push   %r14
    7ec4:	41 55                	push   %r13
    7ec6:	4c 8d 2d b3 f7 ff ff 	lea    -0x84d(%rip),%r13        # 7680 <fwp_tape_scope_release>
    7ecd:	41 54                	push   %r12
    7ecf:	55                   	push   %rbp
    7ed0:	53                   	push   %rbx
    7ed1:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    7ed8:	48 8b 05 d9 35 06 00 	mov    0x635d9(%rip),%rax        # 6b4b8 <fwp_cleanups>
    7edf:	48 8b 15 12 2d 06 00 	mov    0x62d12(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7ee6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    7eed:	00 00 
    7eef:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    7ef6:	00 
    7ef7:	48 89 fd             	mov    %rdi,%rbp
    7efa:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
    7eff:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7f06:	ff 
    7f07:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7f0c:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    7f11:	48 c1 e2 10          	shl    $0x10,%rdx
    7f15:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7f1a:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7f1f:	48 8d 05 ea 90 00 00 	lea    0x90ea(%rip),%rax        # 11010 <fc23>
    7f26:	48 2b 05 a3 2c 06 00 	sub    0x62ca3(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7f2d:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    7f32:	4c 89 3d 7f 35 06 00 	mov    %r15,0x6357f(%rip)        # 6b4b8 <fwp_cleanups>
    7f39:	48 39 d0             	cmp    %rdx,%rax
    7f3c:	73 6d                	jae    7fab <f12+0xeb>
    7f3e:	48 89 c2             	mov    %rax,%rdx
    7f41:	48 c1 ea 10          	shr    $0x10,%rdx
    7f45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f49:	48 8b 15 c8 2c 06 00 	mov    0x62cc8(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    7f50:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f54:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7f58:	48 85 ff             	test   %rdi,%rdi
    7f5b:	74 4e                	je     7fab <f12+0xeb>
    7f5d:	0f b6 0a             	movzbl (%rdx),%ecx
    7f60:	80 f9 02             	cmp    $0x2,%cl
    7f63:	0f 84 57 0f 00 00    	je     8ec0 <f12+0x1000>
    7f69:	80 f9 01             	cmp    $0x1,%cl
    7f6c:	75 3d                	jne    7fab <f12+0xeb>
    7f6e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f71:	0f b7 c0             	movzwl %ax,%eax
    7f74:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f77:	48 0f af c1          	imul   %rcx,%rax
    7f7b:	48 c1 e8 20          	shr    $0x20,%rax
    7f7f:	48 39 d0             	cmp    %rdx,%rax
    7f82:	73 27                	jae    7fab <f12+0xeb>
    7f84:	48 01 c7             	add    %rax,%rdi
    7f87:	0f b6 07             	movzbl (%rdi),%eax
    7f8a:	84 c0                	test   %al,%al
    7f8c:	74 1d                	je     7fab <f12+0xeb>
    7f8e:	44 8b 05 53 35 06 00 	mov    0x63553(%rip),%r8d        # 6b4e8 <iteration_active>
    7f95:	45 85 c0             	test   %r8d,%r8d
    7f98:	0f 85 52 10 00 00    	jne    8ff0 <f12+0x1130>
    7f9e:	3c fd                	cmp    $0xfd,%al
    7fa0:	0f 87 06 12 00 00    	ja     91ac <f12+0x12ec>
    7fa6:	83 c0 01             	add    $0x1,%eax
    7fa9:	88 07                	mov    %al,(%rdi)
    7fab:	48 8d 3d 5e 90 00 00 	lea    0x905e(%rip),%rdi        # 11010 <fc23>
    7fb2:	e8 59 f3 ff ff       	call   7310 <fwp_closure_drop>
    7fb7:	48 85 ed             	test   %rbp,%rbp
    7fba:	0f 84 41 11 00 00    	je     9101 <f12+0x1241>
    7fc0:	48 89 e8             	mov    %rbp,%rax
    7fc3:	31 d2                	xor    %edx,%edx
    7fc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7fcc:	00 00 00 00 
    7fd0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7fd4:	48 83 c2 01          	add    $0x1,%rdx
    7fd8:	48 85 c0             	test   %rax,%rax
    7fdb:	75 f3                	jne    7fd0 <f12+0x110>
    7fdd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    7fe4:	0f 87 50 12 00 00    	ja     923a <f12+0x137a>
    7fea:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    7fef:	8b 35 6b 90 00 00    	mov    0x906b(%rip),%esi        # 11060 <registered_finish.0>
    7ff5:	85 f6                	test   %esi,%esi
    7ff7:	0f 84 93 0e 00 00    	je     8e90 <f12+0xfd0>
    7ffd:	48 8b 1d d4 90 01 00 	mov    0x190d4(%rip),%rbx        # 210d8 <fwp_tape_next_slot>
    8004:	4c 8b 25 dd 90 01 00 	mov    0x190dd(%rip),%r12        # 210e8 <fwp_ntapes>
    800b:	4c 39 e3             	cmp    %r12,%rbx
    800e:	0f 8d d4 00 00 00    	jge    80e8 <f12+0x228>
    8014:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8018:	48 03 05 d1 90 01 00 	add    0x190d1(%rip),%rax        # 210f0 <fwp_tapes>
    801f:	90                   	nop
    8020:	8b 48 04             	mov    0x4(%rax),%ecx
    8023:	85 c9                	test   %ecx,%ecx
    8025:	75 0c                	jne    8033 <f12+0x173>
    8027:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    802d:	0f 86 b5 00 00 00    	jbe    80e8 <f12+0x228>
    8033:	48 83 c3 01          	add    $0x1,%rbx
    8037:	48 83 c0 68          	add    $0x68,%rax
    803b:	4c 39 e3             	cmp    %r12,%rbx
    803e:	75 e0                	jne    8020 <f12+0x160>
    8040:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    8047:	0f 8f 62 12 00 00    	jg     92af <f12+0x13ef>
    804d:	4c 39 25 8c 90 01 00 	cmp    %r12,0x1908c(%rip)        # 210e0 <fwp_tapes_cap>
    8054:	4c 8b 35 95 90 01 00 	mov    0x19095(%rip),%r14        # 210f0 <fwp_tapes>
    805b:	75 4b                	jne    80a8 <f12+0x1e8>
    805d:	4d 85 e4             	test   %r12,%r12
    8060:	0f 84 00 11 00 00    	je     9166 <f12+0x12a6>
    8066:	4b 8d 1c 24          	lea    (%r12,%r12,1),%rbx
    806a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    806f:	48 39 c3             	cmp    %rax,%rbx
    8072:	48 0f 4f d8          	cmovg  %rax,%rbx
    8076:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    807a:	31 d2                	xor    %edx,%edx
    807c:	4c 89 f7             	mov    %r14,%rdi
    807f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8084:	e8 07 d1 ff ff       	call   5190 <ad_raw_realloc>
    8089:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    808e:	48 85 c0             	test   %rax,%rax
    8091:	49 89 c6             	mov    %rax,%r14
    8094:	0f 84 db 11 00 00    	je     9275 <f12+0x13b5>
    809a:	48 89 05 4f 90 01 00 	mov    %rax,0x1904f(%rip)        # 210f0 <fwp_tapes>
    80a1:	48 89 1d 38 90 01 00 	mov    %rbx,0x19038(%rip)        # 210e0 <fwp_tapes_cap>
    80a8:	49 6b c4 68          	imul   $0x68,%r12,%rax
    80ac:	4c 89 e3             	mov    %r12,%rbx
    80af:	4c 01 f0             	add    %r14,%rax
    80b2:	48 8d 78 08          	lea    0x8(%rax),%rdi
    80b6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    80bd:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    80c1:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    80c8:	00 
    80c9:	48 29 f8             	sub    %rdi,%rax
    80cc:	8d 48 68             	lea    0x68(%rax),%ecx
    80cf:	31 c0                	xor    %eax,%eax
    80d1:	c1 e9 03             	shr    $0x3,%ecx
    80d4:	f3 48 ab             	rep stos %rax,(%rdi)
    80d7:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    80dc:	48 89 05 05 90 01 00 	mov    %rax,0x19005(%rip)        # 210e8 <fwp_ntapes>
    80e3:	eb 13                	jmp    80f8 <f12+0x238>
    80e5:	0f 1f 00             	nopl   (%rax)
    80e8:	49 39 dc             	cmp    %rbx,%r12
    80eb:	0f 84 4f ff ff ff    	je     8040 <f12+0x180>
    80f1:	4c 8b 35 f8 8f 01 00 	mov    0x18ff8(%rip),%r14        # 210f0 <fwp_tapes>
    80f8:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    80fc:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8100:	48 8d 3d 59 50 00 00 	lea    0x5059(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    8107:	0f 29 04 24          	movaps %xmm0,(%rsp)
    810b:	4d 01 f4             	add    %r14,%r12
    810e:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    8115:	00 00 
    8117:	e8 74 b2 ff ff       	call   3390 <getenv@plt>
    811c:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    8121:	48 85 c0             	test   %rax,%rax
    8124:	74 09                	je     812f <f12+0x26f>
    8126:	80 38 30             	cmpb   $0x30,(%rax)
    8129:	0f 84 11 07 00 00    	je     8840 <f12+0x980>
    812f:	48 83 3d 51 8f 01 00 	cmpq   $0x0,0x18f51(%rip)        # 21088 <fwp_tape_cached_bytes>
    8136:	00 
    8137:	0f 85 e3 0d 00 00    	jne    8f20 <f12+0x1060>
    813d:	41 8b 04 24          	mov    (%r12),%eax
    8141:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    8145:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    814c:	00 00 
    814e:	48 89 3d 83 8f 01 00 	mov    %rdi,0x18f83(%rip)        # 210d8 <fwp_tape_next_slot>
    8155:	8d 70 01             	lea    0x1(%rax),%esi
    8158:	48 8b 05 59 33 06 00 	mov    0x63359(%rip),%rax        # 6b4b8 <fwp_cleanups>
    815f:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    8166:	00 00 
    8168:	41 89 34 24          	mov    %esi,(%r12)
    816c:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    8173:	ff ff 
    8175:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    817b:	48 85 c0             	test   %rax,%rax
    817e:	75 1c                	jne    819c <f12+0x2dc>
    8180:	e9 47 11 00 00       	jmp    92cc <f12+0x140c>
    8185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    818c:	00 00 00 00 
    8190:	48 8b 00             	mov    (%rax),%rax
    8193:	48 85 c0             	test   %rax,%rax
    8196:	0f 84 30 11 00 00    	je     92cc <f12+0x140c>
    819c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    81a0:	75 ee                	jne    8190 <f12+0x2d0>
    81a2:	48 8b 50 10          	mov    0x10(%rax),%rdx
    81a6:	89 d9                	mov    %ebx,%ecx
    81a8:	48 63 02             	movslq (%rdx),%rax
    81ab:	49 89 54 24 50       	mov    %rdx,0x50(%r12)
    81b0:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    81b5:	85 c0                	test   %eax,%eax
    81b7:	78 09                	js     81c2 <f12+0x302>
    81b9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    81bd:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    81c2:	89 0a                	mov    %ecx,(%rdx)
    81c4:	48 89 e8             	mov    %rbp,%rax
    81c7:	31 c9                	xor    %ecx,%ecx
    81c9:	48 85 ed             	test   %rbp,%rbp
    81cc:	0f 84 9e 0b 00 00    	je     8d70 <f12+0xeb0>
    81d2:	0f 1f 00             	nopl   (%rax)
    81d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81dc:	00 00 00 00 
    81e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    81e4:	48 83 c1 01          	add    $0x1,%rcx
    81e8:	48 85 c0             	test   %rax,%rax
    81eb:	75 f3                	jne    81e0 <f12+0x320>
    81ed:	48 89 ea             	mov    %rbp,%rdx
    81f0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    81f4:	48 83 c0 01          	add    $0x1,%rax
    81f8:	48 85 d2             	test   %rdx,%rdx
    81fb:	75 f3                	jne    81f0 <f12+0x330>
    81fd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8204:	ff ff 1f 
    8207:	48 39 c2             	cmp    %rax,%rdx
    820a:	0f 82 36 10 00 00    	jb     9246 <f12+0x1386>
    8210:	48 85 c9             	test   %rcx,%rcx
    8213:	0f 8e 57 0b 00 00    	jle    8d70 <f12+0xeb0>
    8219:	48 39 c1             	cmp    %rax,%rcx
    821c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8220:	49 89 c5             	mov    %rax,%r13
    8223:	48 c1 e8 3c          	shr    $0x3c,%rax
    8227:	0f 85 19 10 00 00    	jne    9246 <f12+0x1386>
    822d:	48 c1 e6 10          	shl    $0x10,%rsi
    8231:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    8236:	48 09 fe             	or     %rdi,%rsi
    8239:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8240:	00 
    8241:	49 89 f4             	mov    %rsi,%r12
    8244:	be 02 00 00 00       	mov    $0x2,%esi
    8249:	e8 c2 dc ff ff       	call   5f10 <fwp_heap_alloc>
    824e:	4c 89 30             	mov    %r14,(%rax)
    8251:	48 8b 15 a0 29 06 00 	mov    0x629a0(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    8258:	48 89 c3             	mov    %rax,%rbx
    825b:	48 2b 05 6e 29 06 00 	sub    0x6296e(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8262:	48 c1 e2 10          	shl    $0x10,%rdx
    8266:	48 39 d0             	cmp    %rdx,%rax
    8269:	0f 83 99 0b 00 00    	jae    8e08 <f12+0xf48>
    826f:	48 89 c2             	mov    %rax,%rdx
    8272:	48 c1 ea 10          	shr    $0x10,%rdx
    8276:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    827a:	48 8b 15 97 29 06 00 	mov    0x62997(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8281:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8285:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8289:	48 85 d2             	test   %rdx,%rdx
    828c:	74 38                	je     82c6 <f12+0x406>
    828e:	0f b6 31             	movzbl (%rcx),%esi
    8291:	40 80 fe 02          	cmp    $0x2,%sil
    8295:	0f 84 42 0b 00 00    	je     8ddd <f12+0xf1d>
    829b:	40 80 fe 01          	cmp    $0x1,%sil
    829f:	75 25                	jne    82c6 <f12+0x406>
    82a1:	8b 71 18             	mov    0x18(%rcx),%esi
    82a4:	0f b7 c0             	movzwl %ax,%eax
    82a7:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    82aa:	48 0f af c6          	imul   %rsi,%rax
    82ae:	48 c1 e8 20          	shr    $0x20,%rax
    82b2:	48 39 c8             	cmp    %rcx,%rax
    82b5:	73 0f                	jae    82c6 <f12+0x406>
    82b7:	48 01 c2             	add    %rax,%rdx
    82ba:	80 3a ff             	cmpb   $0xff,(%rdx)
    82bd:	0f 84 b2 0e 00 00    	je     9175 <f12+0x12b5>
    82c3:	c6 02 01             	movb   $0x1,(%rdx)
    82c6:	4d 85 ed             	test   %r13,%r13
    82c9:	74 68                	je     8333 <f12+0x473>
    82cb:	4c 89 e1             	mov    %r12,%rcx
    82ce:	48 89 ea             	mov    %rbp,%rdx
    82d1:	31 c0                	xor    %eax,%eax
    82d3:	48 c1 e1 20          	shl    $0x20,%rcx
    82d7:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    82de:	00 
    82df:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82e6:	00 00 00 00 
    82ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82f1:	00 00 00 00 
    82f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82fc:	00 00 00 00 
    8300:	48 89 c6             	mov    %rax,%rsi
    8303:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8308:	48 01 ce             	add    %rcx,%rsi
    830b:	0f 80 1c 0f 00 00    	jo     922d <f12+0x136d>
    8311:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8316:	48 89 c6             	mov    %rax,%rsi
    8319:	48 83 c0 01          	add    $0x1,%rax
    831d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8321:	48 c1 e6 04          	shl    $0x4,%rsi
    8325:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    832a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    832e:	4c 39 e8             	cmp    %r13,%rax
    8331:	72 cd                	jb     8300 <f12+0x440>
    8333:	48 8b 03             	mov    (%rbx),%rax
    8336:	48 d1 e8             	shr    $1,%rax
    8339:	0f 84 e1 0a 00 00    	je     8e20 <f12+0xf60>
    833f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8343:	48 89 d1             	mov    %rdx,%rcx
    8346:	48 c1 e9 3c          	shr    $0x3c,%rcx
    834a:	0f 85 f6 0e 00 00    	jne    9246 <f12+0x1386>
    8350:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    8354:	48 89 0c 24          	mov    %rcx,(%rsp)
    8358:	48 85 d2             	test   %rdx,%rdx
    835b:	74 41                	je     839e <f12+0x4de>
    835d:	48 c1 e0 04          	shl    $0x4,%rax
    8361:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    8365:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    836a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8370:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    8375:	49 8b 76 18          	mov    0x18(%r14),%rsi
    8379:	49 83 c6 10          	add    $0x10,%r14
    837d:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    8381:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    8386:	e8 c5 e4 ff ff       	call   6850 <w107>
    838b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8390:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8394:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    8399:	4d 39 f5             	cmp    %r14,%r13
    839c:	75 d2                	jne    8370 <f12+0x4b0>
    839e:	48 8b 04 24          	mov    (%rsp),%rax
    83a2:	48 89 df             	mov    %rbx,%rdi
    83a5:	48 89 03             	mov    %rax,(%rbx)
    83a8:	e8 63 e6 ff ff       	call   6a10 <w164.constprop.0>
    83ad:	48 89 df             	mov    %rbx,%rdi
    83b0:	49 63 dc             	movslq %r12d,%rbx
    83b3:	49 89 c5             	mov    %rax,%r13
    83b6:	e8 85 f8 ff ff       	call   7c40 <fwp_drop4>
    83bb:	48 89 df             	mov    %rbx,%rdi
    83be:	e8 6d c3 ff ff       	call   4730 <fwp_tape_of>
    83c3:	48 89 c6             	mov    %rax,%rsi
    83c6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    83cb:	0f 85 ef 0e 00 00    	jne    92c0 <f12+0x1400>
    83d1:	48 89 c7             	mov    %rax,%rdi
    83d4:	e8 b7 b8 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    83d9:	4c 8b 46 48          	mov    0x48(%rsi),%r8
    83dd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    83e2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    83e9:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    83ed:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    83f1:	66 49 0f 6e f8       	movq   %r8,%xmm7
    83f6:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    83fb:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8400:	4c 8b 4e 40          	mov    0x40(%rsi),%r9
    8404:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8408:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    840e:	77 19                	ja     8429 <f12+0x569>
    8410:	41 0f b7 c4          	movzwl %r12w,%eax
    8414:	83 e8 01             	sub    $0x1,%eax
    8417:	48 98                	cltq
    8419:	48 3b 05 b8 8c 01 00 	cmp    0x18cb8(%rip),%rax        # 210d8 <fwp_tape_next_slot>
    8420:	7d 07                	jge    8429 <f12+0x569>
    8422:	48 89 05 af 8c 01 00 	mov    %rax,0x18caf(%rip)        # 210d8 <fwp_tape_next_slot>
    8429:	48 8b 05 88 30 06 00 	mov    0x63088(%rip),%rax        # 6b4b8 <fwp_cleanups>
    8430:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8434:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    843b:	00 
    843c:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8443:	00 
    8444:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8448:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    844f:	00 
    8450:	48 8d 05 09 ce ff ff 	lea    -0x31f7(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    8457:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    845e:	00 
    845f:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8466:	00 
    8467:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    846b:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    846f:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8476:	00 
    8477:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    847e:	00 
    847f:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
    8486:	00 
    8487:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    848e:	00 
    848f:	48 89 05 22 30 06 00 	mov    %rax,0x63022(%rip)        # 6b4b8 <fwp_cleanups>
    8496:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    849d:	00 
    849e:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    84a5:	00 
    84a6:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    84ad:	00 
    84ae:	4d 85 ed             	test   %r13,%r13
    84b1:	0f 88 19 0a 00 00    	js     8ed0 <f12+0x1010>
    84b7:	4c 89 e8             	mov    %r13,%rax
    84ba:	48 c1 f8 20          	sar    $0x20,%rax
    84be:	48 39 c3             	cmp    %rax,%rbx
    84c1:	0f 85 42 0d 00 00    	jne    9209 <f12+0x1349>
    84c7:	44 89 e9             	mov    %r13d,%ecx
    84ca:	48 39 ca             	cmp    %rcx,%rdx
    84cd:	0f 8e 42 0d 00 00    	jle    9215 <f12+0x1355>
    84d3:	49 39 ce             	cmp    %rcx,%r14
    84d6:	0f 8e 54 09 00 00    	jle    8e30 <f12+0xf70>
    84dc:	4d 39 c6             	cmp    %r8,%r14
    84df:	0f 8e b3 0a 00 00    	jle    8f98 <f12+0x10d8>
    84e5:	4c 89 f3             	mov    %r14,%rbx
    84e8:	4d 85 c0             	test   %r8,%r8
    84eb:	4c 0f 44 c3          	cmove  %rbx,%r8
    84ef:	eb 24                	jmp    8515 <f12+0x655>
    84f1:	0f 1f 40 00          	nopl   0x0(%rax)
    84f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    84fc:	00 00 00 00 
    8500:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    8504:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    850b:	48 89 d8             	mov    %rbx,%rax
    850e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8512:	49 89 c0             	mov    %rax,%r8
    8515:	49 39 d8             	cmp    %rbx,%r8
    8518:	7c e6                	jl     8500 <f12+0x640>
    851a:	4d 85 c9             	test   %r9,%r9
    851d:	0f 84 0d 0b 00 00    	je     9030 <f12+0x1170>
    8523:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    852a:	00 
    852b:	4c 89 cf             	mov    %r9,%rdi
    852e:	ba 03 00 00 00       	mov    $0x3,%edx
    8533:	4c 89 04 24          	mov    %r8,(%rsp)
    8537:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    853c:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8541:	e8 4a cc ff ff       	call   5190 <ad_raw_realloc>
    8546:	4c 8b 04 24          	mov    (%rsp),%r8
    854a:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8550:	48 85 c0             	test   %rax,%rax
    8553:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8559:	49 89 c1             	mov    %rax,%r9
    855c:	0f 84 8e 0b 00 00    	je     90f0 <f12+0x1230>
    8562:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
    8569:	00 
    856a:	4c 89 84 24 d0 00 00 	mov    %r8,0xd0(%rsp)
    8571:	00 
    8572:	48 85 db             	test   %rbx,%rbx
    8575:	0f 85 3e 0c 00 00    	jne    91b9 <f12+0x12f9>
    857b:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
    8582:	4d 85 ed             	test   %r13,%r13
    8585:	78 17                	js     859e <f12+0x6de>
    8587:	44 89 e9             	mov    %r13d,%ecx
    858a:	f2 0f 10 05 4e 58 00 	movsd  0x584e(%rip),%xmm0        # dde0 <msg.4+0xb0>
    8591:	00 
    8592:	f2 41 0f 58 04 c9    	addsd  (%r9,%rcx,8),%xmm0
    8598:	f2 41 0f 11 04 c9    	movsd  %xmm0,(%r9,%rcx,8)
    859e:	4d 39 de             	cmp    %r11,%r14
    85a1:	0f 8f 8a 00 00 00    	jg     8631 <f12+0x771>
    85a7:	0f 12 fb             	movhlps %xmm3,%xmm7
    85aa:	66 49 0f 7e d0       	movq   %xmm2,%r8
    85af:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    85b4:	4d 29 f3             	sub    %r14,%r11
    85b7:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    85bc:	0f 12 fa             	movhlps %xmm2,%xmm7
    85bf:	4b 8d 3c f1          	lea    (%r9,%r14,8),%rdi
    85c3:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    85c8:	4a 8d 04 9e          	lea    (%rsi,%r11,4),%rax
    85cc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    85d0:	48 29 f1             	sub    %rsi,%rcx
    85d3:	4a 8d 14 db          	lea    (%rbx,%r11,8),%rdx
    85d7:	48 29 df             	sub    %rbx,%rdi
    85da:	49 29 d8             	sub    %rbx,%r8
    85dd:	eb 05                	jmp    85e4 <f12+0x724>
    85df:	90                   	nop
    85e0:	48 83 e8 04          	sub    $0x4,%rax
    85e4:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    85e9:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    85ed:	7a 02                	jp     85f1 <f12+0x731>
    85ef:	74 37                	je     8628 <f12+0x768>
    85f1:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    85f5:	45 85 db             	test   %r11d,%r11d
    85f8:	78 16                	js     8610 <f12+0x750>
    85fa:	f2 41 0f 10 0c 10    	movsd  (%r8,%rdx,1),%xmm1
    8600:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8604:	f2 43 0f 58 0c d9    	addsd  (%r9,%r11,8),%xmm1
    860a:	f2 43 0f 11 0c d9    	movsd  %xmm1,(%r9,%r11,8)
    8610:	4c 63 18             	movslq (%rax),%r11
    8613:	45 85 db             	test   %r11d,%r11d
    8616:	78 10                	js     8628 <f12+0x768>
    8618:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    861c:	f2 43 0f 58 04 d9    	addsd  (%r9,%r11,8),%xmm0
    8622:	f2 43 0f 11 04 d9    	movsd  %xmm0,(%r9,%r11,8)
    8628:	48 83 ea 08          	sub    $0x8,%rdx
    862c:	48 39 c6             	cmp    %rax,%rsi
    862f:	75 af                	jne    85e0 <f12+0x720>
    8631:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8638:	ff ff 1f 
    863b:	4c 39 f0             	cmp    %r14,%rax
    863e:	0f 82 0e 0c 00 00    	jb     9252 <f12+0x1392>
    8644:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    864b:	00 
    864c:	be 02 00 00 00       	mov    $0x2,%esi
    8651:	4c 89 0c 24          	mov    %r9,(%rsp)
    8655:	e8 b6 d8 ff ff       	call   5f10 <fwp_heap_alloc>
    865a:	4c 8b 0c 24          	mov    (%rsp),%r9
    865e:	4c 89 30             	mov    %r14,(%rax)
    8661:	49 89 c5             	mov    %rax,%r13
    8664:	31 c0                	xor    %eax,%eax
    8666:	4d 85 f6             	test   %r14,%r14
    8669:	74 27                	je     8692 <f12+0x7d2>
    866b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8672:	00 00 00 
    8675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    867c:	00 00 00 00 
    8680:	49 8b 14 c1          	mov    (%r9,%rax,8),%rdx
    8684:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    8689:	48 83 c0 01          	add    $0x1,%rax
    868d:	49 39 c6             	cmp    %rax,%r14
    8690:	75 ee                	jne    8680 <f12+0x7c0>
    8692:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    8699:	00 
    869a:	4c 89 e7             	mov    %r12,%rdi
    869d:	48 89 0d 14 2e 06 00 	mov    %rcx,0x62e14(%rip)        # 6b4b8 <fwp_cleanups>
    86a4:	48 89 0c 24          	mov    %rcx,(%rsp)
    86a8:	e8 b3 cb ff ff       	call   5260 <fwp_tape_buffers_release>
    86ad:	48 8b 15 44 25 06 00 	mov    0x62544(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    86b4:	4c 89 e8             	mov    %r13,%rax
    86b7:	48 8b 0c 24          	mov    (%rsp),%rcx
    86bb:	48 2b 05 0e 25 06 00 	sub    0x6250e(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    86c2:	48 c1 e2 10          	shl    $0x10,%rdx
    86c6:	48 39 d0             	cmp    %rdx,%rax
    86c9:	73 57                	jae    8722 <f12+0x862>
    86cb:	48 89 c2             	mov    %rax,%rdx
    86ce:	48 c1 ea 10          	shr    $0x10,%rdx
    86d2:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    86d6:	48 8b 15 3b 25 06 00 	mov    0x6253b(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    86dd:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    86e1:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    86e5:	48 85 db             	test   %rbx,%rbx
    86e8:	74 38                	je     8722 <f12+0x862>
    86ea:	0f b6 32             	movzbl (%rdx),%esi
    86ed:	40 80 fe 02          	cmp    $0x2,%sil
    86f1:	0f 84 09 08 00 00    	je     8f00 <f12+0x1040>
    86f7:	40 80 fe 01          	cmp    $0x1,%sil
    86fb:	75 25                	jne    8722 <f12+0x862>
    86fd:	8b 72 18             	mov    0x18(%rdx),%esi
    8700:	0f b7 c0             	movzwl %ax,%eax
    8703:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8706:	48 0f af c6          	imul   %rsi,%rax
    870a:	48 c1 e8 20          	shr    $0x20,%rax
    870e:	48 39 d0             	cmp    %rdx,%rax
    8711:	73 0f                	jae    8722 <f12+0x862>
    8713:	48 01 c3             	add    %rax,%rbx
    8716:	80 3b ff             	cmpb   $0xff,(%rbx)
    8719:	0f 84 6b 0a 00 00    	je     918a <f12+0x12ca>
    871f:	c6 03 01             	movb   $0x1,(%rbx)
    8722:	4c 39 f9             	cmp    %r15,%rcx
    8725:	0f 85 20 b0 ff ff    	jne    374b <f12.cold>
    872b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8730:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8735:	48 89 05 7c 2d 06 00 	mov    %rax,0x62d7c(%rip)        # 6b4b8 <fwp_cleanups>
    873c:	e8 3f ef ff ff       	call   7680 <fwp_tape_scope_release>
    8741:	49 8b 45 00          	mov    0x0(%r13),%rax
    8745:	49 89 c4             	mov    %rax,%r12
    8748:	49 0f ba f4 3f       	btr    $0x3f,%r12
    874d:	48 85 c0             	test   %rax,%rax
    8750:	0f 88 6a 05 00 00    	js     8cc0 <f12+0xe00>
    8756:	48 8b 15 9b 24 06 00 	mov    0x6249b(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    875d:	4c 89 e8             	mov    %r13,%rax
    8760:	48 2b 05 69 24 06 00 	sub    0x62469(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8767:	48 c1 e2 10          	shl    $0x10,%rdx
    876b:	48 39 d0             	cmp    %rdx,%rax
    876e:	0f 83 4c 05 00 00    	jae    8cc0 <f12+0xe00>
    8774:	48 89 c2             	mov    %rax,%rdx
    8777:	48 c1 ea 10          	shr    $0x10,%rdx
    877b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    877f:	48 8b 15 92 24 06 00 	mov    0x62492(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8786:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    878a:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    878e:	48 85 c9             	test   %rcx,%rcx
    8791:	0f 84 29 05 00 00    	je     8cc0 <f12+0xe00>
    8797:	0f b6 32             	movzbl (%rdx),%esi
    879a:	40 80 fe 02          	cmp    $0x2,%sil
    879e:	0f 84 0c 05 00 00    	je     8cb0 <f12+0xdf0>
    87a4:	40 80 fe 01          	cmp    $0x1,%sil
    87a8:	0f 85 12 05 00 00    	jne    8cc0 <f12+0xe00>
    87ae:	8b 72 18             	mov    0x18(%rdx),%esi
    87b1:	0f b7 c0             	movzwl %ax,%eax
    87b4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87b7:	48 0f af c6          	imul   %rsi,%rax
    87bb:	48 c1 e8 20          	shr    $0x20,%rax
    87bf:	48 39 d0             	cmp    %rdx,%rax
    87c2:	0f 83 f8 04 00 00    	jae    8cc0 <f12+0xe00>
    87c8:	48 01 c1             	add    %rax,%rcx
    87cb:	80 39 01             	cmpb   $0x1,(%rcx)
    87ce:	0f 85 ec 04 00 00    	jne    8cc0 <f12+0xe00>
    87d4:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    87d9:	4d 89 ef             	mov    %r13,%r15
    87dc:	31 ff                	xor    %edi,%edi
    87de:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    87e3:	f2 0f 10 0d 05 56 00 	movsd  0x5605(%rip),%xmm1        # ddf0 <msg.4+0xc0>
    87ea:	00 
    87eb:	48 8d 50 08          	lea    0x8(%rax),%rdx
    87ef:	31 c0                	xor    %eax,%eax
    87f1:	4d 85 e4             	test   %r12,%r12
    87f4:	75 2f                	jne    8825 <f12+0x965>
    87f6:	eb 58                	jmp    8850 <f12+0x990>
    87f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    87ff:	00 
    8800:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8804:	0f 88 17 0a 00 00    	js     9221 <f12+0x1361>
    880a:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    880f:	48 83 c0 01          	add    $0x1,%rax
    8813:	48 83 c2 08          	add    $0x8,%rdx
    8817:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    881b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8820:	49 39 c4             	cmp    %rax,%r12
    8823:	74 2b                	je     8850 <f12+0x990>
    8825:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    8829:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    882e:	79 d0                	jns    8800 <f12+0x940>
    8830:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    8834:	eb ca                	jmp    8800 <f12+0x940>
    8836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    883d:	00 00 00 
    8840:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8844:	0f 84 f3 f8 ff ff    	je     813d <f12+0x27d>
    884a:	e9 e0 f8 ff ff       	jmp    812f <f12+0x26f>
    884f:	90                   	nop
    8850:	e8 eb f3 ff ff       	call   7c40 <fwp_drop4>
    8855:	48 89 e8             	mov    %rbp,%rax
    8858:	31 d2                	xor    %edx,%edx
    885a:	48 85 ed             	test   %rbp,%rbp
    885d:	0f 84 a7 08 00 00    	je     910a <f12+0x124a>
    8863:	66 90                	xchg   %ax,%ax
    8865:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    886c:	00 00 00 00 
    8870:	48 8b 40 10          	mov    0x10(%rax),%rax
    8874:	48 83 c2 01          	add    $0x1,%rdx
    8878:	48 85 c0             	test   %rax,%rax
    887b:	75 f3                	jne    8870 <f12+0x9b0>
    887d:	49 8b 07             	mov    (%r15),%rax
    8880:	49 89 c5             	mov    %rax,%r13
    8883:	49 0f ba f5 3f       	btr    $0x3f,%r13
    8888:	48 85 c0             	test   %rax,%rax
    888b:	0f 88 81 03 00 00    	js     8c12 <f12+0xd52>
    8891:	48 8b 05 60 23 06 00 	mov    0x62360(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    8898:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    889d:	48 2b 0d 2c 23 06 00 	sub    0x6232c(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    88a4:	48 c1 e0 10          	shl    $0x10,%rax
    88a8:	48 39 c1             	cmp    %rax,%rcx
    88ab:	0f 83 61 03 00 00    	jae    8c12 <f12+0xd52>
    88b1:	48 89 c8             	mov    %rcx,%rax
    88b4:	48 c1 e8 10          	shr    $0x10,%rax
    88b8:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    88bc:	48 8b 05 55 23 06 00 	mov    0x62355(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    88c3:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    88c7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    88cb:	48 85 ff             	test   %rdi,%rdi
    88ce:	0f 84 3e 03 00 00    	je     8c12 <f12+0xd52>
    88d4:	0f b6 06             	movzbl (%rsi),%eax
    88d7:	3c 02                	cmp    $0x2,%al
    88d9:	0f 84 21 03 00 00    	je     8c00 <f12+0xd40>
    88df:	3c 01                	cmp    $0x1,%al
    88e1:	0f 85 22 03 00 00    	jne    8c09 <f12+0xd49>
    88e7:	8b 46 18             	mov    0x18(%rsi),%eax
    88ea:	0f b7 c9             	movzwl %cx,%ecx
    88ed:	48 0f af c8          	imul   %rax,%rcx
    88f1:	8b 46 1c             	mov    0x1c(%rsi),%eax
    88f4:	48 c1 e9 20          	shr    $0x20,%rcx
    88f8:	48 39 c1             	cmp    %rax,%rcx
    88fb:	0f 83 08 03 00 00    	jae    8c09 <f12+0xd49>
    8901:	48 01 cf             	add    %rcx,%rdi
    8904:	80 3f 01             	cmpb   $0x1,(%rdi)
    8907:	0f 85 fc 02 00 00    	jne    8c09 <f12+0xd49>
    890d:	4c 39 ea             	cmp    %r13,%rdx
    8910:	4c 89 e8             	mov    %r13,%rax
    8913:	48 0f 46 c2          	cmovbe %rdx,%rax
    8917:	48 85 c0             	test   %rax,%rax
    891a:	0f 84 12 09 00 00    	je     9232 <f12+0x1372>
    8920:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    8927:	00 
    8928:	4d 8d 77 08          	lea    0x8(%r15),%r14
    892c:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8931:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    8938:	00 
    8939:	48 89 e9             	mov    %rbp,%rcx
    893c:	31 d2                	xor    %edx,%edx
    893e:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8942:	eb 59                	jmp    899d <f12+0xadd>
    8944:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8949:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8950:	00 00 00 00 
    8954:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    895b:	00 00 00 00 
    895f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8966:	00 00 00 00 
    896a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8971:	00 00 00 00 
    8975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    897c:	00 00 00 00 
    8980:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    8985:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    898a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    8990:	48 83 c2 08          	add    $0x8,%rdx
    8994:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8998:	49 39 d0             	cmp    %rdx,%r8
    899b:	74 1b                	je     89b8 <f12+0xaf8>
    899d:	48 89 fe             	mov    %rdi,%rsi
    89a0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    89a4:	79 da                	jns    8980 <f12+0xac0>
    89a6:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    89ab:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    89af:	eb cf                	jmp    8980 <f12+0xac0>
    89b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    89b8:	48 85 ed             	test   %rbp,%rbp
    89bb:	0f 84 40 08 00 00    	je     9201 <f12+0x1341>
    89c1:	4c 8b 05 30 22 06 00 	mov    0x62230(%rip),%r8        # 6abf8 <fwp_heap+0x13d8>
    89c8:	4c 8b 0d 01 22 06 00 	mov    0x62201(%rip),%r9        # 6abd0 <fwp_heap+0x13b0>
    89cf:	48 89 e9             	mov    %rbp,%rcx
    89d2:	45 31 ed             	xor    %r13d,%r13d
    89d5:	4c 8b 15 3c 22 06 00 	mov    0x6223c(%rip),%r10        # 6ac18 <fwp_heap+0x13f8>
    89dc:	49 c1 e0 10          	shl    $0x10,%r8
    89e0:	eb 1c                	jmp    89fe <f12+0xb3e>
    89e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    89e8:	49 83 c5 01          	add    $0x1,%r13
    89ec:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    89f0:	49 39 c5             	cmp    %rax,%r13
    89f3:	0f 83 67 01 00 00    	jae    8b60 <f12+0xca0>
    89f9:	48 85 c9             	test   %rcx,%rcx
    89fc:	74 56                	je     8a54 <f12+0xb94>
    89fe:	48 89 ca             	mov    %rcx,%rdx
    8a01:	4c 29 ca             	sub    %r9,%rdx
    8a04:	4c 39 c2             	cmp    %r8,%rdx
    8a07:	73 4b                	jae    8a54 <f12+0xb94>
    8a09:	48 89 d6             	mov    %rdx,%rsi
    8a0c:	48 c1 ee 10          	shr    $0x10,%rsi
    8a10:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8a14:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    8a18:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8a1c:	48 85 ff             	test   %rdi,%rdi
    8a1f:	74 33                	je     8a54 <f12+0xb94>
    8a21:	44 0f b6 1e          	movzbl (%rsi),%r11d
    8a25:	41 80 fb 02          	cmp    $0x2,%r11b
    8a29:	0f 84 19 01 00 00    	je     8b48 <f12+0xc88>
    8a2f:	41 80 fb 01          	cmp    $0x1,%r11b
    8a33:	75 1f                	jne    8a54 <f12+0xb94>
    8a35:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    8a39:	0f b7 d2             	movzwl %dx,%edx
    8a3c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8a3f:	49 0f af d3          	imul   %r11,%rdx
    8a43:	48 c1 ea 20          	shr    $0x20,%rdx
    8a47:	48 39 f2             	cmp    %rsi,%rdx
    8a4a:	73 08                	jae    8a54 <f12+0xb94>
    8a4c:	48 01 d7             	add    %rdx,%rdi
    8a4f:	80 3f 01             	cmpb   $0x1,(%rdi)
    8a52:	74 94                	je     89e8 <f12+0xb28>
    8a54:	49 39 c5             	cmp    %rax,%r13
    8a57:	0f 83 03 01 00 00    	jae    8b60 <f12+0xca0>
    8a5d:	49 89 c7             	mov    %rax,%r15
    8a60:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    8a67:	00 
    8a68:	45 31 e4             	xor    %r12d,%r12d
    8a6b:	48 89 04 24          	mov    %rax,(%rsp)
    8a6f:	48 8d 1d aa 0d 06 00 	lea    0x60daa(%rip),%rbx        # 69820 <fwp_heap>
    8a76:	eb 3a                	jmp    8ab2 <f12+0xbf2>
    8a78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8a7f:	00 
    8a80:	41 80 f9 01          	cmp    $0x1,%r9b
    8a84:	75 27                	jne    8aad <f12+0xbed>
    8a86:	45 8b 48 18          	mov    0x18(%r8),%r9d
    8a8a:	0f b7 c0             	movzwl %ax,%eax
    8a8d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    8a91:	49 0f af c1          	imul   %r9,%rax
    8a95:	48 c1 e8 20          	shr    $0x20,%rax
    8a99:	4c 39 c0             	cmp    %r8,%rax
    8a9c:	73 0f                	jae    8aad <f12+0xbed>
    8a9e:	48 01 c7             	add    %rax,%rdi
    8aa1:	80 3f ff             	cmpb   $0xff,(%rdi)
    8aa4:	0f 84 46 03 00 00    	je     8df0 <f12+0xf30>
    8aaa:	c6 07 01             	movb   $0x1,(%rdi)
    8aad:	4d 39 fd             	cmp    %r15,%r13
    8ab0:	73 7e                	jae    8b30 <f12+0xc70>
    8ab2:	49 83 ef 01          	sub    $0x1,%r15
    8ab6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    8abb:	48 8b 34 24          	mov    (%rsp),%rsi
    8abf:	bf 01 00 00 00       	mov    $0x1,%edi
    8ac4:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    8aca:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8ace:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    8ad5:	00 
    8ad6:	e8 b5 df ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    8adb:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    8ae2:	49 89 c4             	mov    %rax,%r12
    8ae5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8aec:	48 c1 e7 10          	shl    $0x10,%rdi
    8af0:	48 39 f8             	cmp    %rdi,%rax
    8af3:	73 b8                	jae    8aad <f12+0xbed>
    8af5:	48 89 c7             	mov    %rax,%rdi
    8af8:	48 c1 ef 10          	shr    $0x10,%rdi
    8afc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    8b00:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    8b07:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    8b0b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    8b0f:	48 85 ff             	test   %rdi,%rdi
    8b12:	74 99                	je     8aad <f12+0xbed>
    8b14:	45 0f b6 08          	movzbl (%r8),%r9d
    8b18:	41 80 f9 02          	cmp    $0x2,%r9b
    8b1c:	0f 85 5e ff ff ff    	jne    8a80 <f12+0xbc0>
    8b22:	66 85 c0             	test   %ax,%ax
    8b25:	0f 84 76 ff ff ff    	je     8aa1 <f12+0xbe1>
    8b2b:	4d 39 fd             	cmp    %r15,%r13
    8b2e:	72 82                	jb     8ab2 <f12+0xbf2>
    8b30:	4d 85 ed             	test   %r13,%r13
    8b33:	75 2e                	jne    8b63 <f12+0xca3>
    8b35:	8b 44 24 20          	mov    0x20(%rsp),%eax
    8b39:	85 c0                	test   %eax,%eax
    8b3b:	4d 0f 45 f5          	cmovne %r13,%r14
    8b3f:	eb 6f                	jmp    8bb0 <f12+0xcf0>
    8b41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b48:	66 85 d2             	test   %dx,%dx
    8b4b:	0f 84 fe fe ff ff    	je     8a4f <f12+0xb8f>
    8b51:	49 39 c5             	cmp    %rax,%r13
    8b54:	0f 82 03 ff ff ff    	jb     8a5d <f12+0xb9d>
    8b5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b60:	45 31 e4             	xor    %r12d,%r12d
    8b63:	4c 89 f2             	mov    %r14,%rdx
    8b66:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    8b6a:	48 89 e8             	mov    %rbp,%rax
    8b6d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b74:	00 
    8b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b7c:	00 00 00 00 
    8b80:	48 8b 0a             	mov    (%rdx),%rcx
    8b83:	48 83 c2 08          	add    $0x8,%rdx
    8b87:	48 89 c7             	mov    %rax,%rdi
    8b8a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8b8e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8b92:	49 39 d0             	cmp    %rdx,%r8
    8b95:	75 e9                	jne    8b80 <f12+0xcc0>
    8b97:	8b 54 24 20          	mov    0x20(%rsp),%edx
    8b9b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    8b9f:	85 d2                	test   %edx,%edx
    8ba1:	0f 84 69 03 00 00    	je     8f10 <f12+0x1050>
    8ba7:	49 89 ec             	mov    %rbp,%r12
    8baa:	45 31 f6             	xor    %r14d,%r14d
    8bad:	48 89 c5             	mov    %rax,%rbp
    8bb0:	4c 89 f7             	mov    %r14,%rdi
    8bb3:	e8 58 ce ff ff       	call   5a10 <fwp_mem_free>
    8bb8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8bbd:	e8 7e f0 ff ff       	call   7c40 <fwp_drop4>
    8bc2:	48 89 ef             	mov    %rbp,%rdi
    8bc5:	e8 66 e4 ff ff       	call   7030 <fwp_drop0>
    8bca:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    8bd1:	00 
    8bd2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8bd9:	00 00 
    8bdb:	0f 85 da 06 00 00    	jne    92bb <f12+0x13fb>
    8be1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    8be8:	4c 89 e0             	mov    %r12,%rax
    8beb:	5b                   	pop    %rbx
    8bec:	5d                   	pop    %rbp
    8bed:	41 5c                	pop    %r12
    8bef:	41 5d                	pop    %r13
    8bf1:	41 5e                	pop    %r14
    8bf3:	41 5f                	pop    %r15
    8bf5:	c3                   	ret
    8bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8bfd:	00 00 00 
    8c00:	66 85 c9             	test   %cx,%cx
    8c03:	0f 84 fb fc ff ff    	je     8904 <f12+0xa44>
    8c09:	48 85 ed             	test   %rbp,%rbp
    8c0c:	0f 84 eb 03 00 00    	je     8ffd <f12+0x113d>
    8c12:	48 89 e8             	mov    %rbp,%rax
    8c15:	45 31 e4             	xor    %r12d,%r12d
    8c18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c1f:	00 
    8c20:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c24:	4c 89 e2             	mov    %r12,%rdx
    8c27:	49 83 c4 01          	add    $0x1,%r12
    8c2b:	48 85 c0             	test   %rax,%rax
    8c2e:	75 f0                	jne    8c20 <f12+0xd60>
    8c30:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8c37:	ff ff 1f 
    8c3a:	4c 39 e0             	cmp    %r12,%rax
    8c3d:	0f 82 03 06 00 00    	jb     9246 <f12+0x1386>
    8c43:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8c4a:	00 
    8c4b:	be 02 00 00 00       	mov    $0x2,%esi
    8c50:	e8 bb d2 ff ff       	call   5f10 <fwp_heap_alloc>
    8c55:	4d 39 e5             	cmp    %r12,%r13
    8c58:	48 89 ea             	mov    %rbp,%rdx
    8c5b:	49 89 c6             	mov    %rax,%r14
    8c5e:	4c 89 e0             	mov    %r12,%rax
    8c61:	49 0f 46 c5          	cmovbe %r13,%rax
    8c65:	4c 89 f1             	mov    %r14,%rcx
    8c68:	66 90                	xchg   %ax,%ax
    8c6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c71:	00 00 00 00 
    8c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c7c:	00 00 00 00 
    8c80:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    8c84:	48 83 c1 08          	add    $0x8,%rcx
    8c88:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    8c8c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8c90:	48 85 d2             	test   %rdx,%rdx
    8c93:	75 eb                	jne    8c80 <f12+0xdc0>
    8c95:	48 85 c0             	test   %rax,%rax
    8c98:	0f 84 71 03 00 00    	je     900f <f12+0x114f>
    8c9e:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    8ca5:	00 
    8ca6:	e9 81 fc ff ff       	jmp    892c <f12+0xa6c>
    8cab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8cb0:	66 85 c0             	test   %ax,%ax
    8cb3:	0f 84 12 fb ff ff    	je     87cb <f12+0x90b>
    8cb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8cc0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8cc7:	ff ff 1f 
    8cca:	4c 39 e0             	cmp    %r12,%rax
    8ccd:	0f 82 7f 05 00 00    	jb     9252 <f12+0x1392>
    8cd3:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    8cda:	00 
    8cdb:	be 01 00 00 00       	mov    $0x1,%esi
    8ce0:	e8 2b d2 ff ff       	call   5f10 <fwp_heap_alloc>
    8ce5:	4c 89 20             	mov    %r12,(%rax)
    8ce8:	48 8b 15 09 1f 06 00 	mov    0x61f09(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    8cef:	49 89 c7             	mov    %rax,%r15
    8cf2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8cf7:	48 2b 05 d2 1e 06 00 	sub    0x61ed2(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8cfe:	48 c1 e2 10          	shl    $0x10,%rdx
    8d02:	48 39 d0             	cmp    %rdx,%rax
    8d05:	73 57                	jae    8d5e <f12+0xe9e>
    8d07:	48 89 c2             	mov    %rax,%rdx
    8d0a:	48 c1 ea 10          	shr    $0x10,%rdx
    8d0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d12:	48 8b 15 ff 1e 06 00 	mov    0x61eff(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8d19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d1d:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8d21:	4d 85 f6             	test   %r14,%r14
    8d24:	74 38                	je     8d5e <f12+0xe9e>
    8d26:	0f b6 0a             	movzbl (%rdx),%ecx
    8d29:	80 f9 02             	cmp    $0x2,%cl
    8d2c:	0f 84 ee 02 00 00    	je     9020 <f12+0x1160>
    8d32:	80 f9 01             	cmp    $0x1,%cl
    8d35:	75 27                	jne    8d5e <f12+0xe9e>
    8d37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d3a:	0f b7 c0             	movzwl %ax,%eax
    8d3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d40:	48 0f af c1          	imul   %rcx,%rax
    8d44:	48 c1 e8 20          	shr    $0x20,%rax
    8d48:	48 39 d0             	cmp    %rdx,%rax
    8d4b:	73 11                	jae    8d5e <f12+0xe9e>
    8d4d:	49 01 c6             	add    %rax,%r14
    8d50:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8d54:	0f 84 45 04 00 00    	je     919f <f12+0x12df>
    8d5a:	41 c6 06 01          	movb   $0x1,(%r14)
    8d5e:	4c 89 ef             	mov    %r13,%rdi
    8d61:	e9 78 fa ff ff       	jmp    87de <f12+0x91e>
    8d66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d6d:	00 00 00 
    8d70:	48 c1 e6 10          	shl    $0x10,%rsi
    8d74:	48 09 fe             	or     %rdi,%rsi
    8d77:	bf 08 00 00 00       	mov    $0x8,%edi
    8d7c:	49 89 f4             	mov    %rsi,%r12
    8d7f:	be 02 00 00 00       	mov    $0x2,%esi
    8d84:	e8 87 d1 ff ff       	call   5f10 <fwp_heap_alloc>
    8d89:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8d90:	48 8b 15 61 1e 06 00 	mov    0x61e61(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    8d97:	48 89 c3             	mov    %rax,%rbx
    8d9a:	48 2b 05 2f 1e 06 00 	sub    0x61e2f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8da1:	48 c1 e2 10          	shl    $0x10,%rdx
    8da5:	48 39 d0             	cmp    %rdx,%rax
    8da8:	73 76                	jae    8e20 <f12+0xf60>
    8daa:	48 89 c2             	mov    %rax,%rdx
    8dad:	48 c1 ea 10          	shr    $0x10,%rdx
    8db1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8db5:	48 8b 15 5c 1e 06 00 	mov    0x61e5c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8dbc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8dc0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8dc4:	48 85 d2             	test   %rdx,%rdx
    8dc7:	0f 84 66 f5 ff ff    	je     8333 <f12+0x473>
    8dcd:	0f b6 31             	movzbl (%rcx),%esi
    8dd0:	45 31 ed             	xor    %r13d,%r13d
    8dd3:	40 80 fe 02          	cmp    $0x2,%sil
    8dd7:	0f 85 be f4 ff ff    	jne    829b <f12+0x3db>
    8ddd:	66 85 c0             	test   %ax,%ax
    8de0:	0f 85 e0 f4 ff ff    	jne    82c6 <f12+0x406>
    8de6:	e9 cf f4 ff ff       	jmp    82ba <f12+0x3fa>
    8deb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8df0:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    8df5:	e8 d6 c9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8dfa:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8dff:	e9 a6 fc ff ff       	jmp    8aaa <f12+0xbea>
    8e04:	0f 1f 40 00          	nopl   0x0(%rax)
    8e08:	4d 85 ed             	test   %r13,%r13
    8e0b:	0f 85 ba f4 ff ff    	jne    82cb <f12+0x40b>
    8e11:	0f 1f 40 00          	nopl   0x0(%rax)
    8e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e1c:	00 00 00 00 
    8e20:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    8e27:	00 
    8e28:	e9 71 f5 ff ff       	jmp    839e <f12+0x4de>
    8e2d:	0f 1f 00             	nopl   (%rax)
    8e30:	48 8d 59 01          	lea    0x1(%rcx),%rbx
    8e34:	49 39 d8             	cmp    %rbx,%r8
    8e37:	0f 8c ab f6 ff ff    	jl     84e8 <f12+0x628>
    8e3d:	4d 85 c9             	test   %r9,%r9
    8e40:	0f 84 18 04 00 00    	je     925e <f12+0x139e>
    8e46:	4c 89 cf             	mov    %r9,%rdi
    8e49:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    8e50:	00 
    8e51:	31 f6                	xor    %esi,%esi
    8e53:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8e57:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    8e5c:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
    8e61:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    8e66:	e8 45 a6 ff ff       	call   34b0 <memset@plt>
    8e6b:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8e70:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    8e76:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    8e7b:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
    8e80:	49 89 c1             	mov    %rax,%r9
    8e83:	e9 02 f7 ff ff       	jmp    858a <f12+0x6ca>
    8e88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e8f:	00 
    8e90:	48 8d 3d c9 e6 ff ff 	lea    -0x1937(%rip),%rdi        # 7560 <fwp_tape_finish>
    8e97:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8e9c:	e8 8f 31 00 00       	call   c030 <atexit>
    8ea1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8ea6:	85 c0                	test   %eax,%eax
    8ea8:	0f 85 c7 03 00 00    	jne    9275 <f12+0x13b5>
    8eae:	c7 05 a8 81 00 00 01 	movl   $0x1,0x81a8(%rip)        # 11060 <registered_finish.0>
    8eb5:	00 00 00 
    8eb8:	e9 40 f1 ff ff       	jmp    7ffd <f12+0x13d>
    8ebd:	0f 1f 00             	nopl   (%rax)
    8ec0:	66 85 c0             	test   %ax,%ax
    8ec3:	0f 85 e2 f0 ff ff    	jne    7fab <f12+0xeb>
    8ec9:	e9 b9 f0 ff ff       	jmp    7f87 <f12+0xc7>
    8ece:	66 90                	xchg   %ax,%ax
    8ed0:	4d 39 c6             	cmp    %r8,%r14
    8ed3:	0f 8f 0c f6 ff ff    	jg     84e5 <f12+0x625>
    8ed9:	4d 85 f6             	test   %r14,%r14
    8edc:	74 12                	je     8ef0 <f12+0x1030>
    8ede:	4d 85 c9             	test   %r9,%r9
    8ee1:	0f 84 77 03 00 00    	je     925e <f12+0x139e>
    8ee7:	4d 85 f6             	test   %r14,%r14
    8eea:	0f 85 c6 02 00 00    	jne    91b6 <f12+0x12f6>
    8ef0:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
    8ef7:	e9 a2 f6 ff ff       	jmp    859e <f12+0x6de>
    8efc:	0f 1f 40 00          	nopl   0x0(%rax)
    8f00:	66 85 c0             	test   %ax,%ax
    8f03:	0f 85 19 f8 ff ff    	jne    8722 <f12+0x862>
    8f09:	e9 08 f8 ff ff       	jmp    8716 <f12+0x856>
    8f0e:	66 90                	xchg   %ax,%ax
    8f10:	49 89 ec             	mov    %rbp,%r12
    8f13:	48 89 c5             	mov    %rax,%rbp
    8f16:	e9 95 fc ff ff       	jmp    8bb0 <f12+0xcf0>
    8f1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8f20:	66 0f 6f 0d 78 81 01 	movdqa 0x18178(%rip),%xmm1        # 210a0 <fwp_tape_workspace>
    8f27:	00 
    8f28:	48 c7 05 55 81 01 00 	movq   $0x0,0x18155(%rip)        # 21088 <fwp_tape_cached_bytes>
    8f2f:	00 00 00 00 
    8f33:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    8f39:	48 8b 05 80 81 01 00 	mov    0x18180(%rip),%rax        # 210c0 <fwp_tape_workspace+0x20>
    8f40:	66 0f 6f 0d 68 81 01 	movdqa 0x18168(%rip),%xmm1        # 210b0 <fwp_tape_workspace+0x10>
    8f47:	00 
    8f48:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    8f4d:	48 8b 05 74 81 01 00 	mov    0x18174(%rip),%rax        # 210c8 <fwp_tape_workspace+0x28>
    8f54:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    8f5a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8f5e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    8f63:	48 8b 05 66 81 01 00 	mov    0x18166(%rip),%rax        # 210d0 <fwp_tape_workspace+0x30>
    8f6a:	0f 29 0d 2f 81 01 00 	movaps %xmm1,0x1812f(%rip)        # 210a0 <fwp_tape_workspace>
    8f71:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    8f76:	0f 29 0d 33 81 01 00 	movaps %xmm1,0x18133(%rip)        # 210b0 <fwp_tape_workspace+0x10>
    8f7d:	48 c7 05 48 81 01 00 	movq   $0x0,0x18148(%rip)        # 210d0 <fwp_tape_workspace+0x30>
    8f84:	00 00 00 00 
    8f88:	0f 29 0d 31 81 01 00 	movaps %xmm1,0x18131(%rip)        # 210c0 <fwp_tape_workspace+0x20>
    8f8f:	e9 a9 f1 ff ff       	jmp    813d <f12+0x27d>
    8f94:	0f 1f 40 00          	nopl   0x0(%rax)
    8f98:	4d 85 c9             	test   %r9,%r9
    8f9b:	0f 84 bd 02 00 00    	je     925e <f12+0x139e>
    8fa1:	4d 8d 5e ff          	lea    -0x1(%r14),%r11
    8fa5:	4c 89 cf             	mov    %r9,%rdi
    8fa8:	31 f6                	xor    %esi,%esi
    8faa:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
    8faf:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    8fb6:	00 
    8fb7:	4c 89 1c 24          	mov    %r11,(%rsp)
    8fbb:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8fc0:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8fc5:	e8 e6 a4 ff ff       	call   34b0 <memset@plt>
    8fca:	4c 8b 1c 24          	mov    (%rsp),%r11
    8fce:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8fd4:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8fda:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    8fdf:	49 89 c1             	mov    %rax,%r9
    8fe2:	e9 a3 f5 ff ff       	jmp    858a <f12+0x6ca>
    8fe7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8fee:	00 00 
    8ff0:	48 83 05 d8 24 06 00 	addq   $0x1,0x624d8(%rip)        # 6b4d0 <iteration_retains>
    8ff7:	01 
    8ff8:	e9 a1 ef ff ff       	jmp    7f9e <f12+0xde>
    8ffd:	be 02 00 00 00       	mov    $0x2,%esi
    9002:	bf 08 00 00 00       	mov    $0x8,%edi
    9007:	e8 04 cf ff ff       	call   5f10 <fwp_heap_alloc>
    900c:	49 89 c6             	mov    %rax,%r14
    900f:	45 31 e4             	xor    %r12d,%r12d
    9012:	e9 99 fb ff ff       	jmp    8bb0 <f12+0xcf0>
    9017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    901e:	00 00 
    9020:	66 85 c0             	test   %ax,%ax
    9023:	0f 85 35 fd ff ff    	jne    8d5e <f12+0xe9e>
    9029:	e9 22 fd ff ff       	jmp    8d50 <f12+0xe90>
    902e:	66 90                	xchg   %ax,%ax
    9030:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9037:	ff ff 1f 
    903a:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    903e:	48 39 c2             	cmp    %rax,%rdx
    9041:	0f 82 5c 02 00 00    	jb     92a3 <f12+0x13e3>
    9047:	48 8d 05 72 81 04 00 	lea    0x48172(%rip),%rax        # 511c0 <ad_raw_blocks>
    904e:	31 d2                	xor    %edx,%edx
    9050:	eb 23                	jmp    9075 <f12+0x11b5>
    9052:	0f 1f 00             	nopl   (%rax)
    9055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    905c:	00 00 00 00 
    9060:	48 83 c2 01          	add    $0x1,%rdx
    9064:	48 83 c0 18          	add    $0x18,%rax
    9068:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
    906f:	0f 84 80 01 00 00    	je     91f5 <f12+0x1335>
    9075:	48 83 38 00          	cmpq   $0x0,(%rax)
    9079:	75 e5                	jne    9060 <f12+0x11a0>
    907b:	4c 89 c7             	mov    %r8,%rdi
    907e:	be 08 00 00 00       	mov    $0x8,%esi
    9083:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    9088:	4c 89 04 24          	mov    %r8,(%rsp)
    908c:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    9091:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    9096:	e8 75 a4 ff ff       	call   3510 <calloc@plt>
    909b:	4c 8b 04 24          	mov    (%rsp),%r8
    909f:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    90a4:	48 8d 0d 15 81 04 00 	lea    0x48115(%rip),%rcx        # 511c0 <ad_raw_blocks>
    90ab:	48 85 c0             	test   %rax,%rax
    90ae:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    90b4:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    90ba:	74 34                	je     90f0 <f12+0x1230>
    90bc:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    90c0:	48 89 c6             	mov    %rax,%rsi
    90c3:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    90c8:	48 8d 3c d1          	lea    (%rcx,%rdx,8),%rdi
    90cc:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    90d3:	00 
    90d4:	b9 03 00 00 00       	mov    $0x3,%ecx
    90d9:	48 89 04 24          	mov    %rax,(%rsp)
    90dd:	e8 1e ab ff ff       	call   3c00 <ad_raw_record>
    90e2:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    90e7:	4c 8b 0c 24          	mov    (%rsp),%r9
    90eb:	e9 72 f4 ff ff       	jmp    8562 <f12+0x6a2>
    90f0:	48 85 db             	test   %rbx,%rbx
    90f3:	0f 85 65 01 00 00    	jne    925e <f12+0x139e>
    90f9:	45 31 c9             	xor    %r9d,%r9d
    90fc:	e9 7a f4 ff ff       	jmp    857b <f12+0x6bb>
    9101:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9105:	e9 e5 ee ff ff       	jmp    7fef <f12+0x12f>
    910a:	49 8b 07             	mov    (%r15),%rax
    910d:	48 85 c0             	test   %rax,%rax
    9110:	0f 88 e7 fe ff ff    	js     8ffd <f12+0x113d>
    9116:	48 8b 35 db 1a 06 00 	mov    0x61adb(%rip),%rsi        # 6abf8 <fwp_heap+0x13d8>
    911d:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    9122:	48 2b 0d a7 1a 06 00 	sub    0x61aa7(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    9129:	48 c1 e6 10          	shl    $0x10,%rsi
    912d:	48 39 f1             	cmp    %rsi,%rcx
    9130:	0f 83 c7 fe ff ff    	jae    8ffd <f12+0x113d>
    9136:	48 89 ce             	mov    %rcx,%rsi
    9139:	48 c1 ee 10          	shr    $0x10,%rsi
    913d:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9141:	48 8b 35 d0 1a 06 00 	mov    0x61ad0(%rip),%rsi        # 6ac18 <fwp_heap+0x13f8>
    9148:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    914c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9150:	48 85 ff             	test   %rdi,%rdi
    9153:	0f 84 a4 fe ff ff    	je     8ffd <f12+0x113d>
    9159:	48 0f ba f0 3f       	btr    $0x3f,%rax
    915e:	49 89 c5             	mov    %rax,%r13
    9161:	e9 6e f7 ff ff       	jmp    88d4 <f12+0xa14>
    9166:	be 68 00 00 00       	mov    $0x68,%esi
    916b:	bb 01 00 00 00       	mov    $0x1,%ebx
    9170:	e9 05 ef ff ff       	jmp    807a <f12+0x1ba>
    9175:	48 89 d7             	mov    %rdx,%rdi
    9178:	48 89 14 24          	mov    %rdx,(%rsp)
    917c:	e8 4f c6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    9181:	48 8b 14 24          	mov    (%rsp),%rdx
    9185:	e9 39 f1 ff ff       	jmp    82c3 <f12+0x403>
    918a:	48 89 df             	mov    %rbx,%rdi
    918d:	48 89 0c 24          	mov    %rcx,(%rsp)
    9191:	e8 3a c6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    9196:	48 8b 0c 24          	mov    (%rsp),%rcx
    919a:	e9 80 f5 ff ff       	jmp    871f <f12+0x85f>
    919f:	4c 89 f7             	mov    %r14,%rdi
    91a2:	e8 29 c6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    91a7:	e9 ae fb ff ff       	jmp    8d5a <f12+0xe9a>
    91ac:	e8 ff c4 ff ff       	call   56b0 <fwp_rc_wide_dup>
    91b1:	e9 f5 ed ff ff       	jmp    7fab <f12+0xeb>
    91b6:	4c 89 f3             	mov    %r14,%rbx
    91b9:	4c 8d 5b ff          	lea    -0x1(%rbx),%r11
    91bd:	4c 89 cf             	mov    %r9,%rdi
    91c0:	31 f6                	xor    %esi,%esi
    91c2:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    91c7:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    91ce:	00 
    91cf:	4c 89 1c 24          	mov    %r11,(%rsp)
    91d3:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    91d8:	e8 d3 a2 ff ff       	call   34b0 <memset@plt>
    91dd:	4c 8b 1c 24          	mov    (%rsp),%r11
    91e1:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    91e7:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    91ed:	49 89 c1             	mov    %rax,%r9
    91f0:	e9 8d f3 ff ff       	jmp    8582 <f12+0x6c2>
    91f5:	48 8d 3d 16 3f 00 00 	lea    0x3f16(%rip),%rdi        # d112 <_IO_stdin_used+0x112>
    91fc:	e8 ff ad ff ff       	call   4000 <ad_raw_fail>
    9201:	45 31 ed             	xor    %r13d,%r13d
    9204:	e9 54 f8 ff ff       	jmp    8a5d <f12+0xb9d>
    9209:	48 8d 3d f8 47 00 00 	lea    0x47f8(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    9210:	e8 3b b2 ff ff       	call   4450 <fwp_trap>
    9215:	48 8d 3d a6 3f 00 00 	lea    0x3fa6(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    921c:	e8 2f b2 ff ff       	call   4450 <fwp_trap>
    9221:	48 8d 3d e8 48 00 00 	lea    0x48e8(%rip),%rdi        # db10 <_IO_stdin_used+0xb10>
    9228:	e8 23 b2 ff ff       	call   4450 <fwp_trap>
    922d:	e8 ce a4 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9232:	45 31 f6             	xor    %r14d,%r14d
    9235:	e9 d5 fd ff ff       	jmp    900f <f12+0x114f>
    923a:	48 8d 3d aa 3f 00 00 	lea    0x3faa(%rip),%rdi        # d1eb <_IO_stdin_used+0x1eb>
    9241:	e8 0a b2 ff ff       	call   4450 <fwp_trap>
    9246:	48 8d 3d b8 3f 00 00 	lea    0x3fb8(%rip),%rdi        # d205 <_IO_stdin_used+0x205>
    924d:	e8 fe b1 ff ff       	call   4450 <fwp_trap>
    9252:	48 8d 3d d6 3f 00 00 	lea    0x3fd6(%rip),%rdi        # d22f <_IO_stdin_used+0x22f>
    9259:	e8 f2 b1 ff ff       	call   4450 <fwp_trap>
    925e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9265:	00 
    9266:	4c 89 e7             	mov    %r12,%rdi
    9269:	48 89 05 48 22 06 00 	mov    %rax,0x62248(%rip)        # 6b4b8 <fwp_cleanups>
    9270:	e8 eb bf ff ff       	call   5260 <fwp_tape_buffers_release>
    9275:	48 8b 0d c4 7d 00 00 	mov    0x7dc4(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    927c:	ba 13 00 00 00       	mov    $0x13,%edx
    9281:	be 01 00 00 00       	mov    $0x1,%esi
    9286:	48 8d 3d 7b 3d 00 00 	lea    0x3d7b(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    928d:	e8 ce a3 ff ff       	call   3660 <fwrite@plt>
    9292:	31 ff                	xor    %edi,%edi
    9294:	e8 07 a3 ff ff       	call   35a0 <fflush@plt>
    9299:	bf 66 00 00 00       	mov    $0x66,%edi
    929e:	e8 dd a3 ff ff       	call   3680 <_Exit@plt>
    92a3:	48 8d 3d 69 3f 00 00 	lea    0x3f69(%rip),%rdi        # d213 <_IO_stdin_used+0x213>
    92aa:	e8 51 ad ff ff       	call   4000 <ad_raw_fail>
    92af:	48 8d 3d fa 47 00 00 	lea    0x47fa(%rip),%rdi        # dab0 <_IO_stdin_used+0xab0>
    92b6:	e8 95 b1 ff ff       	call   4450 <fwp_trap>
    92bb:	e8 90 a1 ff ff       	call   3450 <__stack_chk_fail@plt>
    92c0:	48 8d 3d 89 47 00 00 	lea    0x4789(%rip),%rdi        # da50 <_IO_stdin_used+0xa50>
    92c7:	e8 84 b1 ff ff       	call   4450 <fwp_trap>
    92cc:	48 8d 3d 0d 48 00 00 	lea    0x480d(%rip),%rdi        # dae0 <_IO_stdin_used+0xae0>
    92d3:	e8 78 b1 ff ff       	call   4450 <fwp_trap>
    92d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92df:	00 

00000000000092e0 <fwp_owned_entry12>:
    92e0:	f3 0f 1e fa          	endbr64
    92e4:	48 8b 3f             	mov    (%rdi),%rdi
    92e7:	e9 d4 eb ff ff       	jmp    7ec0 <f12>
    92ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000092f0 <e12>:
    92f0:	f3 0f 1e fa          	endbr64
    92f4:	53                   	push   %rbx
    92f5:	48 8b 1f             	mov    (%rdi),%rbx
    92f8:	48 89 df             	mov    %rbx,%rdi
    92fb:	e8 80 d9 ff ff       	call   6c80 <fwp_rc_share>
    9300:	48 89 df             	mov    %rbx,%rdi
    9303:	e8 b8 eb ff ff       	call   7ec0 <f12>
    9308:	48 89 c3             	mov    %rax,%rbx
    930b:	48 89 c7             	mov    %rax,%rdi
    930e:	e8 6d d9 ff ff       	call   6c80 <fwp_rc_share>
    9313:	48 89 d8             	mov    %rbx,%rax
    9316:	5b                   	pop    %rbx
    9317:	c3                   	ret
    9318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    931f:	00 

0000000000009320 <fwp_drop2>:
    9320:	48 8b 0d d1 18 06 00 	mov    0x618d1(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    9327:	48 89 f8             	mov    %rdi,%rax
    932a:	48 2b 05 9f 18 06 00 	sub    0x6189f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9331:	48 c1 e1 10          	shl    $0x10,%rcx
    9335:	48 39 c8             	cmp    %rcx,%rax
    9338:	0f 83 42 01 00 00    	jae    9480 <fwp_drop2+0x160>
    933e:	48 83 ec 18          	sub    $0x18,%rsp
    9342:	48 89 fa             	mov    %rdi,%rdx
    9345:	4c 8d 05 d4 04 06 00 	lea    0x604d4(%rip),%r8        # 69820 <fwp_heap>
    934c:	48 89 c1             	mov    %rax,%rcx
    934f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9356:	48 c1 e9 10          	shr    $0x10,%rcx
    935a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    935e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9362:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9366:	48 85 c9             	test   %rcx,%rcx
    9369:	74 40                	je     93ab <fwp_drop2+0x8b>
    936b:	0f b6 3e             	movzbl (%rsi),%edi
    936e:	40 80 ff 02          	cmp    $0x2,%dil
    9372:	74 3c                	je     93b0 <fwp_drop2+0x90>
    9374:	40 80 ff 01          	cmp    $0x1,%dil
    9378:	75 31                	jne    93ab <fwp_drop2+0x8b>
    937a:	8b 7e 18             	mov    0x18(%rsi),%edi
    937d:	0f b7 c0             	movzwl %ax,%eax
    9380:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9383:	48 0f af c7          	imul   %rdi,%rax
    9387:	48 c1 e8 20          	shr    $0x20,%rax
    938b:	48 39 f0             	cmp    %rsi,%rax
    938e:	73 1b                	jae    93ab <fwp_drop2+0x8b>
    9390:	48 01 c1             	add    %rax,%rcx
    9393:	0f b6 01             	movzbl (%rcx),%eax
    9396:	84 c0                	test   %al,%al
    9398:	74 11                	je     93ab <fwp_drop2+0x8b>
    939a:	3c 01                	cmp    $0x1,%al
    939c:	74 22                	je     93c0 <fwp_drop2+0xa0>
    939e:	3c ff                	cmp    $0xff,%al
    93a0:	0f 84 0a 01 00 00    	je     94b0 <fwp_drop2+0x190>
    93a6:	83 e8 01             	sub    $0x1,%eax
    93a9:	88 01                	mov    %al,(%rcx)
    93ab:	48 83 c4 18          	add    $0x18,%rsp
    93af:	c3                   	ret
    93b0:	66 85 c0             	test   %ax,%ax
    93b3:	74 de                	je     9393 <fwp_drop2+0x73>
    93b5:	48 83 c4 18          	add    $0x18,%rsp
    93b9:	c3                   	ret
    93ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93c0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    93c4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    93cb:	48 89 f8             	mov    %rdi,%rax
    93ce:	48 c1 e1 10          	shl    $0x10,%rcx
    93d2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    93d9:	48 39 c8             	cmp    %rcx,%rax
    93dc:	73 62                	jae    9440 <fwp_drop2+0x120>
    93de:	48 89 c1             	mov    %rax,%rcx
    93e1:	48 c1 e9 10          	shr    $0x10,%rcx
    93e5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    93e9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    93ed:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    93f1:	48 85 c9             	test   %rcx,%rcx
    93f4:	74 4a                	je     9440 <fwp_drop2+0x120>
    93f6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    93fa:	41 80 f9 02          	cmp    $0x2,%r9b
    93fe:	0f 84 9c 00 00 00    	je     94a0 <fwp_drop2+0x180>
    9404:	41 80 f9 01          	cmp    $0x1,%r9b
    9408:	75 36                	jne    9440 <fwp_drop2+0x120>
    940a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    940e:	0f b7 c0             	movzwl %ax,%eax
    9411:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9414:	49 0f af c1          	imul   %r9,%rax
    9418:	48 c1 e8 20          	shr    $0x20,%rax
    941c:	48 39 f0             	cmp    %rsi,%rax
    941f:	73 1f                	jae    9440 <fwp_drop2+0x120>
    9421:	48 01 c1             	add    %rax,%rcx
    9424:	0f b6 01             	movzbl (%rcx),%eax
    9427:	84 c0                	test   %al,%al
    9429:	74 15                	je     9440 <fwp_drop2+0x120>
    942b:	3c 01                	cmp    $0x1,%al
    942d:	74 59                	je     9488 <fwp_drop2+0x168>
    942f:	3c ff                	cmp    $0xff,%al
    9431:	0f 84 ef 00 00 00    	je     9526 <fwp_drop2+0x206>
    9437:	83 e8 01             	sub    $0x1,%eax
    943a:	88 01                	mov    %al,(%rcx)
    943c:	0f 1f 40 00          	nopl   0x0(%rax)
    9440:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9444:	48 89 d7             	mov    %rdx,%rdi
    9447:	48 89 0c 24          	mov    %rcx,(%rsp)
    944b:	e8 b0 d8 ff ff       	call   6d00 <fwp_rc_free_arr>
    9450:	4c 8d 05 c9 03 06 00 	lea    0x603c9(%rip),%r8        # 69820 <fwp_heap>
    9457:	48 8b 04 24          	mov    (%rsp),%rax
    945b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9462:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9469:	48 c1 e2 10          	shl    $0x10,%rdx
    946d:	48 39 d0             	cmp    %rdx,%rax
    9470:	0f 83 35 ff ff ff    	jae    93ab <fwp_drop2+0x8b>
    9476:	48 8b 14 24          	mov    (%rsp),%rdx
    947a:	e9 cd fe ff ff       	jmp    934c <fwp_drop2+0x2c>
    947f:	90                   	nop
    9480:	c3                   	ret
    9481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9488:	48 89 14 24          	mov    %rdx,(%rsp)
    948c:	e8 6f d8 ff ff       	call   6d00 <fwp_rc_free_arr>
    9491:	48 8b 14 24          	mov    (%rsp),%rdx
    9495:	eb a9                	jmp    9440 <fwp_drop2+0x120>
    9497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    949e:	00 00 
    94a0:	66 85 c0             	test   %ax,%ax
    94a3:	75 9b                	jne    9440 <fwp_drop2+0x120>
    94a5:	e9 7a ff ff ff       	jmp    9424 <fwp_drop2+0x104>
    94aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    94b0:	48 89 c8             	mov    %rcx,%rax
    94b3:	48 c1 e8 11          	shr    $0x11,%rax
    94b7:	48 31 c8             	xor    %rcx,%rax
    94ba:	48 89 c2             	mov    %rax,%rdx
    94bd:	48 c1 ea 09          	shr    $0x9,%rdx
    94c1:	48 31 d0             	xor    %rdx,%rax
    94c4:	0f b6 d0             	movzbl %al,%edx
    94c7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    94ce:	00 
    94cf:	48 85 c0             	test   %rax,%rax
    94d2:	75 19                	jne    94ed <fwp_drop2+0x1cd>
    94d4:	e9 d3 00 00 00       	jmp    95ac <fwp_drop2+0x28c>
    94d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    94e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    94e4:	48 85 c0             	test   %rax,%rax
    94e7:	0f 84 bf 00 00 00    	je     95ac <fwp_drop2+0x28c>
    94ed:	48 89 c2             	mov    %rax,%rdx
    94f0:	48 39 08             	cmp    %rcx,(%rax)
    94f3:	75 eb                	jne    94e0 <fwp_drop2+0x1c0>
    94f5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    94f9:	48 83 ea 01          	sub    $0x1,%rdx
    94fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9501:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9508:	0f 85 9d fe ff ff    	jne    93ab <fwp_drop2+0x8b>
    950e:	48 89 cf             	mov    %rcx,%rdi
    9511:	48 89 0c 24          	mov    %rcx,(%rsp)
    9515:	e8 b6 c2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    951a:	48 8b 0c 24          	mov    (%rsp),%rcx
    951e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9521:	e9 85 fe ff ff       	jmp    93ab <fwp_drop2+0x8b>
    9526:	48 89 ce             	mov    %rcx,%rsi
    9529:	48 c1 ee 11          	shr    $0x11,%rsi
    952d:	48 31 ce             	xor    %rcx,%rsi
    9530:	48 89 f0             	mov    %rsi,%rax
    9533:	48 c1 e8 09          	shr    $0x9,%rax
    9537:	48 31 c6             	xor    %rax,%rsi
    953a:	40 0f b6 f6          	movzbl %sil,%esi
    953e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9545:	00 
    9546:	48 85 c0             	test   %rax,%rax
    9549:	75 1e                	jne    9569 <fwp_drop2+0x249>
    954b:	eb 5f                	jmp    95ac <fwp_drop2+0x28c>
    954d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9554:	00 
    9555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    955c:	00 00 00 00 
    9560:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9564:	48 85 c0             	test   %rax,%rax
    9567:	74 43                	je     95ac <fwp_drop2+0x28c>
    9569:	48 89 c6             	mov    %rax,%rsi
    956c:	48 39 08             	cmp    %rcx,(%rax)
    956f:	75 ef                	jne    9560 <fwp_drop2+0x240>
    9571:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9575:	48 83 ee 01          	sub    $0x1,%rsi
    9579:	48 89 70 08          	mov    %rsi,0x8(%rax)
    957d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    9584:	0f 85 b6 fe ff ff    	jne    9440 <fwp_drop2+0x120>
    958a:	48 89 cf             	mov    %rcx,%rdi
    958d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    9592:	48 89 0c 24          	mov    %rcx,(%rsp)
    9596:	e8 35 c2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    959b:	48 8b 0c 24          	mov    (%rsp),%rcx
    959f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    95a4:	c6 01 fe             	movb   $0xfe,(%rcx)
    95a7:	e9 94 fe ff ff       	jmp    9440 <fwp_drop2+0x120>
    95ac:	48 8d 3d 2d 44 00 00 	lea    0x442d(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    95b3:	e8 98 ae ff ff       	call   4450 <fwp_trap>
    95b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    95bf:	00 

00000000000095c0 <fwp_arg_drop23>:
    95c0:	f3 0f 1e fa          	endbr64
    95c4:	85 f6                	test   %esi,%esi
    95c6:	75 04                	jne    95cc <fwp_arg_drop23+0xc>
    95c8:	85 d2                	test   %edx,%edx
    95ca:	75 04                	jne    95d0 <fwp_arg_drop23+0x10>
    95cc:	c3                   	ret
    95cd:	0f 1f 00             	nopl   (%rax)
    95d0:	48 8b 3f             	mov    (%rdi),%rdi
    95d3:	e9 48 fd ff ff       	jmp    9320 <fwp_drop2>
    95d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    95df:	00 

00000000000095e0 <f23>:
    95e0:	41 57                	push   %r15
    95e2:	41 56                	push   %r14
    95e4:	41 55                	push   %r13
    95e6:	41 54                	push   %r12
    95e8:	55                   	push   %rbp
    95e9:	53                   	push   %rbx
    95ea:	48 83 ec 38          	sub    $0x38,%rsp
    95ee:	48 8b 15 03 16 06 00 	mov    0x61603(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    95f5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    95fa:	48 c1 e2 10          	shl    $0x10,%rdx
    95fe:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    9605:	00 00 
    9607:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    960c:	48 8b 0d bd 15 06 00 	mov    0x615bd(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    9613:	48 85 ff             	test   %rdi,%rdi
    9616:	0f 84 1e 03 00 00    	je     993a <f23+0x35a>
    961c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9621:	4c 8b 68 10          	mov    0x10(%rax),%r13
    9625:	4c 89 e8             	mov    %r13,%rax
    9628:	48 29 c8             	sub    %rcx,%rax
    962b:	48 39 d0             	cmp    %rdx,%rax
    962e:	0f 83 ec 02 00 00    	jae    9920 <f23+0x340>
    9634:	48 89 c2             	mov    %rax,%rdx
    9637:	48 c1 ea 10          	shr    $0x10,%rdx
    963b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    963f:	48 8b 15 d2 15 06 00 	mov    0x615d2(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9646:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    964a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    964e:	48 85 ff             	test   %rdi,%rdi
    9651:	0f 84 c9 02 00 00    	je     9920 <f23+0x340>
    9657:	0f b6 0a             	movzbl (%rdx),%ecx
    965a:	80 f9 02             	cmp    $0x2,%cl
    965d:	0f 84 4d 02 00 00    	je     98b0 <f23+0x2d0>
    9663:	80 f9 01             	cmp    $0x1,%cl
    9666:	75 24                	jne    968c <f23+0xac>
    9668:	8b 4a 18             	mov    0x18(%rdx),%ecx
    966b:	0f b7 c0             	movzwl %ax,%eax
    966e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9671:	48 0f af c1          	imul   %rcx,%rax
    9675:	48 c1 e8 20          	shr    $0x20,%rax
    9679:	48 39 d0             	cmp    %rdx,%rax
    967c:	73 0e                	jae    968c <f23+0xac>
    967e:	48 01 c7             	add    %rax,%rdi
    9681:	0f b6 07             	movzbl (%rdi),%eax
    9684:	84 c0                	test   %al,%al
    9686:	0f 85 44 02 00 00    	jne    98d0 <f23+0x2f0>
    968c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9691:	48 8b 40 10          	mov    0x10(%rax),%rax
    9695:	ba 01 00 00 00       	mov    $0x1,%edx
    969a:	48 85 c0             	test   %rax,%rax
    969d:	74 0e                	je     96ad <f23+0xcd>
    969f:	90                   	nop
    96a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    96a4:	48 83 c2 01          	add    $0x1,%rdx
    96a8:	48 85 c0             	test   %rax,%rax
    96ab:	75 f3                	jne    96a0 <f23+0xc0>
    96ad:	4d 85 ed             	test   %r13,%r13
    96b0:	0f 84 9a 02 00 00    	je     9950 <f23+0x370>
    96b6:	4c 89 e8             	mov    %r13,%rax
    96b9:	31 db                	xor    %ebx,%ebx
    96bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    96c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    96c4:	48 83 c3 01          	add    $0x1,%rbx
    96c8:	48 85 c0             	test   %rax,%rax
    96cb:	75 f3                	jne    96c0 <f23+0xe0>
    96cd:	48 39 d3             	cmp    %rdx,%rbx
    96d0:	48 0f 47 da          	cmova  %rdx,%rbx
    96d4:	48 89 d8             	mov    %rbx,%rax
    96d7:	48 c1 e8 3c          	shr    $0x3c,%rax
    96db:	0f 85 7d 03 00 00    	jne    9a5e <f23+0x47e>
    96e1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    96e5:	be 02 00 00 00       	mov    $0x2,%esi
    96ea:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    96f1:	00 
    96f2:	e8 19 c8 ff ff       	call   5f10 <fwp_heap_alloc>
    96f7:	48 89 28             	mov    %rbp,(%rax)
    96fa:	48 8b 15 f7 14 06 00 	mov    0x614f7(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    9701:	49 89 c4             	mov    %rax,%r12
    9704:	48 2b 05 c5 14 06 00 	sub    0x614c5(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    970b:	48 c1 e2 10          	shl    $0x10,%rdx
    970f:	48 39 d0             	cmp    %rdx,%rax
    9712:	73 57                	jae    976b <f23+0x18b>
    9714:	48 89 c2             	mov    %rax,%rdx
    9717:	48 c1 ea 10          	shr    $0x10,%rdx
    971b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    971f:	48 8b 15 f2 14 06 00 	mov    0x614f2(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9726:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    972a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    972e:	48 85 ed             	test   %rbp,%rbp
    9731:	74 38                	je     976b <f23+0x18b>
    9733:	0f b6 0a             	movzbl (%rdx),%ecx
    9736:	80 f9 02             	cmp    $0x2,%cl
    9739:	0f 84 d1 01 00 00    	je     9910 <f23+0x330>
    973f:	80 f9 01             	cmp    $0x1,%cl
    9742:	75 27                	jne    976b <f23+0x18b>
    9744:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9747:	0f b7 c0             	movzwl %ax,%eax
    974a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    974d:	48 0f af c1          	imul   %rcx,%rax
    9751:	48 c1 e8 20          	shr    $0x20,%rax
    9755:	48 39 d0             	cmp    %rdx,%rax
    9758:	73 11                	jae    976b <f23+0x18b>
    975a:	48 01 c5             	add    %rax,%rbp
    975d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9761:	0f 84 57 02 00 00    	je     99be <f23+0x3de>
    9767:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    976b:	48 85 db             	test   %rbx,%rbx
    976e:	74 5d                	je     97cd <f23+0x1ed>
    9770:	48 c1 e3 04          	shl    $0x4,%rbx
    9774:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    9779:	4c 89 e5             	mov    %r12,%rbp
    977c:	4d 89 ef             	mov    %r13,%r15
    977f:	4c 01 e3             	add    %r12,%rbx
    9782:	0f 1f 00             	nopl   (%rax)
    9785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    978c:	00 00 00 00 
    9790:	49 8b 46 08          	mov    0x8(%r14),%rax
    9794:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    9798:	48 83 c5 10          	add    $0x10,%rbp
    979c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    97a1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    97a5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    97a9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    97ae:	e8 9d d0 ff ff       	call   6850 <w107>
    97b3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    97b8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    97bc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    97c0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    97c4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    97c8:	48 39 dd             	cmp    %rbx,%rbp
    97cb:	75 c3                	jne    9790 <f23+0x1b0>
    97cd:	4c 89 ef             	mov    %r13,%rdi
    97d0:	e8 4b fb ff ff       	call   9320 <fwp_drop2>
    97d5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    97da:	e8 41 fb ff ff       	call   9320 <fwp_drop2>
    97df:	4c 89 e7             	mov    %r12,%rdi
    97e2:	e8 29 d2 ff ff       	call   6a10 <w164.constprop.0>
    97e7:	4c 89 e7             	mov    %r12,%rdi
    97ea:	48 89 c3             	mov    %rax,%rbx
    97ed:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    97f3:	e8 48 e4 ff ff       	call   7c40 <fwp_drop4>
    97f8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    97fe:	66 48 0f 6e db       	movq   %rbx,%xmm3
    9803:	31 ff                	xor    %edi,%edi
    9805:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    980a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    980e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9813:	e8 78 d2 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    9818:	48 8b 15 d9 13 06 00 	mov    0x613d9(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    981f:	48 89 c5             	mov    %rax,%rbp
    9822:	48 2b 05 a7 13 06 00 	sub    0x613a7(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9829:	48 c1 e2 10          	shl    $0x10,%rdx
    982d:	48 39 d0             	cmp    %rdx,%rax
    9830:	73 55                	jae    9887 <f23+0x2a7>
    9832:	48 89 c2             	mov    %rax,%rdx
    9835:	48 c1 ea 10          	shr    $0x10,%rdx
    9839:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    983d:	48 8b 15 d4 13 06 00 	mov    0x613d4(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9844:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9848:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    984c:	48 85 db             	test   %rbx,%rbx
    984f:	74 36                	je     9887 <f23+0x2a7>
    9851:	0f b6 0a             	movzbl (%rdx),%ecx
    9854:	80 f9 02             	cmp    $0x2,%cl
    9857:	0f 84 a3 00 00 00    	je     9900 <f23+0x320>
    985d:	80 f9 01             	cmp    $0x1,%cl
    9860:	75 25                	jne    9887 <f23+0x2a7>
    9862:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9865:	0f b7 c0             	movzwl %ax,%eax
    9868:	8b 52 1c             	mov    0x1c(%rdx),%edx
    986b:	48 0f af c1          	imul   %rcx,%rax
    986f:	48 c1 e8 20          	shr    $0x20,%rax
    9873:	48 39 d0             	cmp    %rdx,%rax
    9876:	73 0f                	jae    9887 <f23+0x2a7>
    9878:	48 01 c3             	add    %rax,%rbx
    987b:	80 3b ff             	cmpb   $0xff,(%rbx)
    987e:	0f 84 2d 01 00 00    	je     99b1 <f23+0x3d1>
    9884:	c6 03 01             	movb   $0x1,(%rbx)
    9887:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    988c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9893:	00 00 
    9895:	0f 85 cf 01 00 00    	jne    9a6a <f23+0x48a>
    989b:	48 83 c4 38          	add    $0x38,%rsp
    989f:	48 89 e8             	mov    %rbp,%rax
    98a2:	5b                   	pop    %rbx
    98a3:	5d                   	pop    %rbp
    98a4:	41 5c                	pop    %r12
    98a6:	41 5d                	pop    %r13
    98a8:	41 5e                	pop    %r14
    98aa:	41 5f                	pop    %r15
    98ac:	c3                   	ret
    98ad:	0f 1f 00             	nopl   (%rax)
    98b0:	66 85 c0             	test   %ax,%ax
    98b3:	0f 85 d3 fd ff ff    	jne    968c <f23+0xac>
    98b9:	0f b6 07             	movzbl (%rdi),%eax
    98bc:	84 c0                	test   %al,%al
    98be:	0f 84 c8 fd ff ff    	je     968c <f23+0xac>
    98c4:	90                   	nop
    98c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98cc:	00 00 00 00 
    98d0:	8b 15 12 1c 06 00    	mov    0x61c12(%rip),%edx        # 6b4e8 <iteration_active>
    98d6:	85 d2                	test   %edx,%edx
    98d8:	75 56                	jne    9930 <f23+0x350>
    98da:	3c fd                	cmp    $0xfd,%al
    98dc:	0f 87 4b 01 00 00    	ja     9a2d <f23+0x44d>
    98e2:	83 c0 01             	add    $0x1,%eax
    98e5:	88 07                	mov    %al,(%rdi)
    98e7:	31 d2                	xor    %edx,%edx
    98e9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    98ef:	0f 85 97 fd ff ff    	jne    968c <f23+0xac>
    98f5:	e9 b3 fd ff ff       	jmp    96ad <f23+0xcd>
    98fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9900:	66 85 c0             	test   %ax,%ax
    9903:	0f 85 7e ff ff ff    	jne    9887 <f23+0x2a7>
    9909:	e9 6d ff ff ff       	jmp    987b <f23+0x29b>
    990e:	66 90                	xchg   %ax,%ax
    9910:	66 85 c0             	test   %ax,%ax
    9913:	0f 85 52 fe ff ff    	jne    976b <f23+0x18b>
    9919:	e9 3f fe ff ff       	jmp    975d <f23+0x17d>
    991e:	66 90                	xchg   %ax,%ax
    9920:	4c 89 e8             	mov    %r13,%rax
    9923:	e9 6d fd ff ff       	jmp    9695 <f23+0xb5>
    9928:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    992f:	00 
    9930:	48 83 05 98 1b 06 00 	addq   $0x1,0x61b98(%rip)        # 6b4d0 <iteration_retains>
    9937:	01 
    9938:	eb a0                	jmp    98da <f23+0x2fa>
    993a:	48 f7 d9             	neg    %rcx
    993d:	48 39 d1             	cmp    %rdx,%rcx
    9940:	0f 82 85 00 00 00    	jb     99cb <f23+0x3eb>
    9946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    994d:	00 00 00 
    9950:	be 02 00 00 00       	mov    $0x2,%esi
    9955:	bf 08 00 00 00       	mov    $0x8,%edi
    995a:	e8 b1 c5 ff ff       	call   5f10 <fwp_heap_alloc>
    995f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9966:	48 8b 15 8b 12 06 00 	mov    0x6128b(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    996d:	49 89 c4             	mov    %rax,%r12
    9970:	48 2b 05 59 12 06 00 	sub    0x61259(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9977:	48 c1 e2 10          	shl    $0x10,%rdx
    997b:	48 39 d0             	cmp    %rdx,%rax
    997e:	0f 83 b3 00 00 00    	jae    9a37 <f23+0x457>
    9984:	48 89 c2             	mov    %rax,%rdx
    9987:	48 c1 ea 10          	shr    $0x10,%rdx
    998b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    998f:	48 8b 15 82 12 06 00 	mov    0x61282(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9996:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    999a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    999e:	48 85 ed             	test   %rbp,%rbp
    99a1:	0f 84 90 00 00 00    	je     9a37 <f23+0x457>
    99a7:	31 db                	xor    %ebx,%ebx
    99a9:	45 31 ed             	xor    %r13d,%r13d
    99ac:	e9 82 fd ff ff       	jmp    9733 <f23+0x153>
    99b1:	48 89 df             	mov    %rbx,%rdi
    99b4:	e8 17 be ff ff       	call   57d0 <fwp_rc_forget_slot>
    99b9:	e9 c6 fe ff ff       	jmp    9884 <f23+0x2a4>
    99be:	48 89 ef             	mov    %rbp,%rdi
    99c1:	e8 0a be ff ff       	call   57d0 <fwp_rc_forget_slot>
    99c6:	e9 9c fd ff ff       	jmp    9767 <f23+0x187>
    99cb:	48 89 c8             	mov    %rcx,%rax
    99ce:	48 c1 e8 10          	shr    $0x10,%rax
    99d2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    99d6:	48 8b 05 3b 12 06 00 	mov    0x6123b(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    99dd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    99e1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    99e5:	48 85 ff             	test   %rdi,%rdi
    99e8:	0f 84 62 ff ff ff    	je     9950 <f23+0x370>
    99ee:	0f b6 02             	movzbl (%rdx),%eax
    99f1:	3c 02                	cmp    $0x2,%al
    99f3:	74 4a                	je     9a3f <f23+0x45f>
    99f5:	3c 01                	cmp    $0x1,%al
    99f7:	0f 85 53 ff ff ff    	jne    9950 <f23+0x370>
    99fd:	0f b7 c1             	movzwl %cx,%eax
    9a00:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a03:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a06:	48 0f af c1          	imul   %rcx,%rax
    9a0a:	48 c1 e8 20          	shr    $0x20,%rax
    9a0e:	48 39 d0             	cmp    %rdx,%rax
    9a11:	0f 83 39 ff ff ff    	jae    9950 <f23+0x370>
    9a17:	48 01 c7             	add    %rax,%rdi
    9a1a:	0f b6 07             	movzbl (%rdi),%eax
    9a1d:	84 c0                	test   %al,%al
    9a1f:	0f 84 2b ff ff ff    	je     9950 <f23+0x370>
    9a25:	45 31 ed             	xor    %r13d,%r13d
    9a28:	e9 a3 fe ff ff       	jmp    98d0 <f23+0x2f0>
    9a2d:	e8 7e bc ff ff       	call   56b0 <fwp_rc_wide_dup>
    9a32:	e9 b0 fe ff ff       	jmp    98e7 <f23+0x307>
    9a37:	45 31 ed             	xor    %r13d,%r13d
    9a3a:	e9 8e fd ff ff       	jmp    97cd <f23+0x1ed>
    9a3f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    9a45:	49 89 cd             	mov    %rcx,%r13
    9a48:	0f 85 02 ff ff ff    	jne    9950 <f23+0x370>
    9a4e:	0f b6 07             	movzbl (%rdi),%eax
    9a51:	84 c0                	test   %al,%al
    9a53:	0f 85 77 fe ff ff    	jne    98d0 <f23+0x2f0>
    9a59:	e9 f2 fe ff ff       	jmp    9950 <f23+0x370>
    9a5e:	48 8d 3d a0 37 00 00 	lea    0x37a0(%rip),%rdi        # d205 <_IO_stdin_used+0x205>
    9a65:	e8 e6 a9 ff ff       	call   4450 <fwp_trap>
    9a6a:	e8 e1 99 ff ff       	call   3450 <__stack_chk_fail@plt>
    9a6f:	90                   	nop

0000000000009a70 <fwp_owned_entry23>:
    9a70:	f3 0f 1e fa          	endbr64
    9a74:	48 8b 3f             	mov    (%rdi),%rdi
    9a77:	e9 64 fb ff ff       	jmp    95e0 <f23>
    9a7c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009a80 <e23>:
    9a80:	f3 0f 1e fa          	endbr64
    9a84:	53                   	push   %rbx
    9a85:	48 8b 1f             	mov    (%rdi),%rbx
    9a88:	48 89 df             	mov    %rbx,%rdi
    9a8b:	e8 f0 d1 ff ff       	call   6c80 <fwp_rc_share>
    9a90:	48 89 df             	mov    %rbx,%rdi
    9a93:	e8 48 fb ff ff       	call   95e0 <f23>
    9a98:	48 89 c3             	mov    %rax,%rbx
    9a9b:	48 89 c7             	mov    %rax,%rdi
    9a9e:	e8 dd d1 ff ff       	call   6c80 <fwp_rc_share>
    9aa3:	48 89 d8             	mov    %rbx,%rax
    9aa6:	5b                   	pop    %rbx
    9aa7:	c3                   	ret
    9aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9aaf:	00 

0000000000009ab0 <fwp_args12>:
    9ab0:	f3 0f 1e fa          	endbr64
    9ab4:	85 d2                	test   %edx,%edx
    9ab6:	74 04                	je     9abc <fwp_args12+0xc>
    9ab8:	85 f6                	test   %esi,%esi
    9aba:	74 04                	je     9ac0 <fwp_args12+0x10>
    9abc:	c3                   	ret
    9abd:	0f 1f 00             	nopl   (%rax)
    9ac0:	48 8b 15 31 11 06 00 	mov    0x61131(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    9ac7:	48 8b 07             	mov    (%rdi),%rax
    9aca:	48 2b 05 ff 10 06 00 	sub    0x610ff(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9ad1:	48 c1 e2 10          	shl    $0x10,%rdx
    9ad5:	48 39 d0             	cmp    %rdx,%rax
    9ad8:	73 e2                	jae    9abc <fwp_args12+0xc>
    9ada:	48 89 c2             	mov    %rax,%rdx
    9add:	48 c1 ea 10          	shr    $0x10,%rdx
    9ae1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ae5:	48 8b 15 2c 11 06 00 	mov    0x6112c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9aec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9af0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9af4:	48 85 ff             	test   %rdi,%rdi
    9af7:	74 c3                	je     9abc <fwp_args12+0xc>
    9af9:	0f b6 0a             	movzbl (%rdx),%ecx
    9afc:	80 f9 02             	cmp    $0x2,%cl
    9aff:	74 4f                	je     9b50 <fwp_args12+0xa0>
    9b01:	80 f9 01             	cmp    $0x1,%cl
    9b04:	75 b6                	jne    9abc <fwp_args12+0xc>
    9b06:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b09:	0f b7 c0             	movzwl %ax,%eax
    9b0c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b0f:	48 0f af c1          	imul   %rcx,%rax
    9b13:	48 c1 e8 20          	shr    $0x20,%rax
    9b17:	48 39 d0             	cmp    %rdx,%rax
    9b1a:	73 a0                	jae    9abc <fwp_args12+0xc>
    9b1c:	48 01 c7             	add    %rax,%rdi
    9b1f:	0f b6 07             	movzbl (%rdi),%eax
    9b22:	84 c0                	test   %al,%al
    9b24:	74 96                	je     9abc <fwp_args12+0xc>
    9b26:	8b 15 bc 19 06 00    	mov    0x619bc(%rip),%edx        # 6b4e8 <iteration_active>
    9b2c:	85 d2                	test   %edx,%edx
    9b2e:	75 10                	jne    9b40 <fwp_args12+0x90>
    9b30:	3c fd                	cmp    $0xfd,%al
    9b32:	77 22                	ja     9b56 <fwp_args12+0xa6>
    9b34:	83 c0 01             	add    $0x1,%eax
    9b37:	88 07                	mov    %al,(%rdi)
    9b39:	c3                   	ret
    9b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b40:	48 83 05 88 19 06 00 	addq   $0x1,0x61988(%rip)        # 6b4d0 <iteration_retains>
    9b47:	01 
    9b48:	eb e6                	jmp    9b30 <fwp_args12+0x80>
    9b4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b50:	66 85 c0             	test   %ax,%ax
    9b53:	74 ca                	je     9b1f <fwp_args12+0x6f>
    9b55:	c3                   	ret
    9b56:	e9 55 bb ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9b5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000009b60 <fwp_args23>:
    9b60:	f3 0f 1e fa          	endbr64
    9b64:	85 d2                	test   %edx,%edx
    9b66:	74 04                	je     9b6c <fwp_args23+0xc>
    9b68:	85 f6                	test   %esi,%esi
    9b6a:	74 04                	je     9b70 <fwp_args23+0x10>
    9b6c:	c3                   	ret
    9b6d:	0f 1f 00             	nopl   (%rax)
    9b70:	48 8b 15 81 10 06 00 	mov    0x61081(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    9b77:	48 8b 07             	mov    (%rdi),%rax
    9b7a:	48 2b 05 4f 10 06 00 	sub    0x6104f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    9b81:	48 c1 e2 10          	shl    $0x10,%rdx
    9b85:	48 39 d0             	cmp    %rdx,%rax
    9b88:	73 e2                	jae    9b6c <fwp_args23+0xc>
    9b8a:	48 89 c2             	mov    %rax,%rdx
    9b8d:	48 c1 ea 10          	shr    $0x10,%rdx
    9b91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b95:	48 8b 15 7c 10 06 00 	mov    0x6107c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    9b9c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ba0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9ba4:	48 85 ff             	test   %rdi,%rdi
    9ba7:	74 c3                	je     9b6c <fwp_args23+0xc>
    9ba9:	0f b6 0a             	movzbl (%rdx),%ecx
    9bac:	80 f9 02             	cmp    $0x2,%cl
    9baf:	74 4f                	je     9c00 <fwp_args23+0xa0>
    9bb1:	80 f9 01             	cmp    $0x1,%cl
    9bb4:	75 b6                	jne    9b6c <fwp_args23+0xc>
    9bb6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9bb9:	0f b7 c0             	movzwl %ax,%eax
    9bbc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bbf:	48 0f af c1          	imul   %rcx,%rax
    9bc3:	48 c1 e8 20          	shr    $0x20,%rax
    9bc7:	48 39 d0             	cmp    %rdx,%rax
    9bca:	73 a0                	jae    9b6c <fwp_args23+0xc>
    9bcc:	48 01 c7             	add    %rax,%rdi
    9bcf:	0f b6 07             	movzbl (%rdi),%eax
    9bd2:	84 c0                	test   %al,%al
    9bd4:	74 96                	je     9b6c <fwp_args23+0xc>
    9bd6:	8b 15 0c 19 06 00    	mov    0x6190c(%rip),%edx        # 6b4e8 <iteration_active>
    9bdc:	85 d2                	test   %edx,%edx
    9bde:	75 10                	jne    9bf0 <fwp_args23+0x90>
    9be0:	3c fd                	cmp    $0xfd,%al
    9be2:	77 22                	ja     9c06 <fwp_args23+0xa6>
    9be4:	83 c0 01             	add    $0x1,%eax
    9be7:	88 07                	mov    %al,(%rdi)
    9be9:	c3                   	ret
    9bea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9bf0:	48 83 05 d8 18 06 00 	addq   $0x1,0x618d8(%rip)        # 6b4d0 <iteration_retains>
    9bf7:	01 
    9bf8:	eb e6                	jmp    9be0 <fwp_args23+0x80>
    9bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c00:	66 85 c0             	test   %ax,%ax
    9c03:	74 ca                	je     9bcf <fwp_args23+0x6f>
    9c05:	c3                   	ret
    9c06:	e9 a5 ba ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9c0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000009c10 <fwp_caps12>:
    9c10:	f3 0f 1e fa          	endbr64
    9c14:	48 83 ec 18          	sub    $0x18,%rsp
    9c18:	48 89 f8             	mov    %rdi,%rax
    9c1b:	8b 7f 04             	mov    0x4(%rdi),%edi
    9c1e:	85 ff                	test   %edi,%edi
    9c20:	0f 84 9a 00 00 00    	je     9cc0 <fwp_caps12+0xb0>
    9c26:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9c2a:	85 f6                	test   %esi,%esi
    9c2c:	0f 85 9e 00 00 00    	jne    9cd0 <fwp_caps12+0xc0>
    9c32:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9c37:	e8 f4 d3 ff ff       	call   7030 <fwp_drop0>
    9c3c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9c41:	48 8b 0d b0 0f 06 00 	mov    0x60fb0(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    9c48:	48 89 c2             	mov    %rax,%rdx
    9c4b:	48 2b 15 7e 0f 06 00 	sub    0x60f7e(%rip),%rdx        # 6abd0 <fwp_heap+0x13b0>
    9c52:	48 c1 e1 10          	shl    $0x10,%rcx
    9c56:	48 39 ca             	cmp    %rcx,%rdx
    9c59:	73 6d                	jae    9cc8 <fwp_caps12+0xb8>
    9c5b:	48 89 d1             	mov    %rdx,%rcx
    9c5e:	48 c1 e9 10          	shr    $0x10,%rcx
    9c62:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9c66:	48 8b 0d ab 0f 06 00 	mov    0x60fab(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    9c6d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9c71:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9c75:	48 85 f6             	test   %rsi,%rsi
    9c78:	74 4e                	je     9cc8 <fwp_caps12+0xb8>
    9c7a:	0f b6 39             	movzbl (%rcx),%edi
    9c7d:	40 80 ff 02          	cmp    $0x2,%dil
    9c81:	0f 84 c9 00 00 00    	je     9d50 <fwp_caps12+0x140>
    9c87:	40 80 ff 01          	cmp    $0x1,%dil
    9c8b:	75 3b                	jne    9cc8 <fwp_caps12+0xb8>
    9c8d:	8b 79 18             	mov    0x18(%rcx),%edi
    9c90:	0f b7 d2             	movzwl %dx,%edx
    9c93:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9c96:	48 0f af d7          	imul   %rdi,%rdx
    9c9a:	48 c1 ea 20          	shr    $0x20,%rdx
    9c9e:	48 39 ca             	cmp    %rcx,%rdx
    9ca1:	73 25                	jae    9cc8 <fwp_caps12+0xb8>
    9ca3:	48 01 d6             	add    %rdx,%rsi
    9ca6:	80 3e 01             	cmpb   $0x1,(%rsi)
    9ca9:	75 1d                	jne    9cc8 <fwp_caps12+0xb8>
    9cab:	48 89 c7             	mov    %rax,%rdi
    9cae:	48 83 c4 18          	add    $0x18,%rsp
    9cb2:	e9 59 bd ff ff       	jmp    5a10 <fwp_mem_free>
    9cb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cbe:	00 00 
    9cc0:	85 f6                	test   %esi,%esi
    9cc2:	0f 84 79 ff ff ff    	je     9c41 <fwp_caps12+0x31>
    9cc8:	48 83 c4 18          	add    $0x18,%rsp
    9ccc:	c3                   	ret
    9ccd:	0f 1f 00             	nopl   (%rax)
    9cd0:	48 8b 05 21 0f 06 00 	mov    0x60f21(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    9cd7:	48 2b 3d f2 0e 06 00 	sub    0x60ef2(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    9cde:	48 c1 e0 10          	shl    $0x10,%rax
    9ce2:	48 39 c7             	cmp    %rax,%rdi
    9ce5:	73 e1                	jae    9cc8 <fwp_caps12+0xb8>
    9ce7:	48 89 f8             	mov    %rdi,%rax
    9cea:	48 c1 e8 10          	shr    $0x10,%rax
    9cee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9cf2:	48 8b 05 1f 0f 06 00 	mov    0x60f1f(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    9cf9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9cfd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9d01:	48 85 c0             	test   %rax,%rax
    9d04:	74 c2                	je     9cc8 <fwp_caps12+0xb8>
    9d06:	0f b6 0a             	movzbl (%rdx),%ecx
    9d09:	80 f9 02             	cmp    $0x2,%cl
    9d0c:	74 52                	je     9d60 <fwp_caps12+0x150>
    9d0e:	80 f9 01             	cmp    $0x1,%cl
    9d11:	75 b5                	jne    9cc8 <fwp_caps12+0xb8>
    9d13:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d16:	0f b7 ff             	movzwl %di,%edi
    9d19:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d1c:	48 0f af f9          	imul   %rcx,%rdi
    9d20:	48 c1 ef 20          	shr    $0x20,%rdi
    9d24:	48 39 d7             	cmp    %rdx,%rdi
    9d27:	73 9f                	jae    9cc8 <fwp_caps12+0xb8>
    9d29:	48 01 f8             	add    %rdi,%rax
    9d2c:	0f b6 10             	movzbl (%rax),%edx
    9d2f:	84 d2                	test   %dl,%dl
    9d31:	74 95                	je     9cc8 <fwp_caps12+0xb8>
    9d33:	8b 0d af 17 06 00    	mov    0x617af(%rip),%ecx        # 6b4e8 <iteration_active>
    9d39:	85 c9                	test   %ecx,%ecx
    9d3b:	75 33                	jne    9d70 <fwp_caps12+0x160>
    9d3d:	80 fa fd             	cmp    $0xfd,%dl
    9d40:	77 38                	ja     9d7a <fwp_caps12+0x16a>
    9d42:	83 c2 01             	add    $0x1,%edx
    9d45:	88 10                	mov    %dl,(%rax)
    9d47:	e9 7c ff ff ff       	jmp    9cc8 <fwp_caps12+0xb8>
    9d4c:	0f 1f 40 00          	nopl   0x0(%rax)
    9d50:	66 85 d2             	test   %dx,%dx
    9d53:	0f 85 6f ff ff ff    	jne    9cc8 <fwp_caps12+0xb8>
    9d59:	e9 48 ff ff ff       	jmp    9ca6 <fwp_caps12+0x96>
    9d5e:	66 90                	xchg   %ax,%ax
    9d60:	66 85 ff             	test   %di,%di
    9d63:	0f 85 5f ff ff ff    	jne    9cc8 <fwp_caps12+0xb8>
    9d69:	eb c1                	jmp    9d2c <fwp_caps12+0x11c>
    9d6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d70:	48 83 05 58 17 06 00 	addq   $0x1,0x61758(%rip)        # 6b4d0 <iteration_retains>
    9d77:	01 
    9d78:	eb c3                	jmp    9d3d <fwp_caps12+0x12d>
    9d7a:	48 89 c7             	mov    %rax,%rdi
    9d7d:	48 83 c4 18          	add    $0x18,%rsp
    9d81:	e9 2a b9 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9d86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9d8d:	00 00 00 

0000000000009d90 <fwp_caps23>:
    9d90:	f3 0f 1e fa          	endbr64
    9d94:	48 83 ec 18          	sub    $0x18,%rsp
    9d98:	48 89 f8             	mov    %rdi,%rax
    9d9b:	8b 7f 04             	mov    0x4(%rdi),%edi
    9d9e:	85 ff                	test   %edi,%edi
    9da0:	0f 84 9a 00 00 00    	je     9e40 <fwp_caps23+0xb0>
    9da6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9daa:	85 f6                	test   %esi,%esi
    9dac:	0f 85 9e 00 00 00    	jne    9e50 <fwp_caps23+0xc0>
    9db2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9db7:	e8 64 f5 ff ff       	call   9320 <fwp_drop2>
    9dbc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9dc1:	48 8b 0d 30 0e 06 00 	mov    0x60e30(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    9dc8:	48 89 c2             	mov    %rax,%rdx
    9dcb:	48 2b 15 fe 0d 06 00 	sub    0x60dfe(%rip),%rdx        # 6abd0 <fwp_heap+0x13b0>
    9dd2:	48 c1 e1 10          	shl    $0x10,%rcx
    9dd6:	48 39 ca             	cmp    %rcx,%rdx
    9dd9:	73 6d                	jae    9e48 <fwp_caps23+0xb8>
    9ddb:	48 89 d1             	mov    %rdx,%rcx
    9dde:	48 c1 e9 10          	shr    $0x10,%rcx
    9de2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9de6:	48 8b 0d 2b 0e 06 00 	mov    0x60e2b(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    9ded:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9df1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9df5:	48 85 f6             	test   %rsi,%rsi
    9df8:	74 4e                	je     9e48 <fwp_caps23+0xb8>
    9dfa:	0f b6 39             	movzbl (%rcx),%edi
    9dfd:	40 80 ff 02          	cmp    $0x2,%dil
    9e01:	0f 84 c9 00 00 00    	je     9ed0 <fwp_caps23+0x140>
    9e07:	40 80 ff 01          	cmp    $0x1,%dil
    9e0b:	75 3b                	jne    9e48 <fwp_caps23+0xb8>
    9e0d:	8b 79 18             	mov    0x18(%rcx),%edi
    9e10:	0f b7 d2             	movzwl %dx,%edx
    9e13:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9e16:	48 0f af d7          	imul   %rdi,%rdx
    9e1a:	48 c1 ea 20          	shr    $0x20,%rdx
    9e1e:	48 39 ca             	cmp    %rcx,%rdx
    9e21:	73 25                	jae    9e48 <fwp_caps23+0xb8>
    9e23:	48 01 d6             	add    %rdx,%rsi
    9e26:	80 3e 01             	cmpb   $0x1,(%rsi)
    9e29:	75 1d                	jne    9e48 <fwp_caps23+0xb8>
    9e2b:	48 89 c7             	mov    %rax,%rdi
    9e2e:	48 83 c4 18          	add    $0x18,%rsp
    9e32:	e9 d9 bb ff ff       	jmp    5a10 <fwp_mem_free>
    9e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e3e:	00 00 
    9e40:	85 f6                	test   %esi,%esi
    9e42:	0f 84 79 ff ff ff    	je     9dc1 <fwp_caps23+0x31>
    9e48:	48 83 c4 18          	add    $0x18,%rsp
    9e4c:	c3                   	ret
    9e4d:	0f 1f 00             	nopl   (%rax)
    9e50:	48 8b 05 a1 0d 06 00 	mov    0x60da1(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    9e57:	48 2b 3d 72 0d 06 00 	sub    0x60d72(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    9e5e:	48 c1 e0 10          	shl    $0x10,%rax
    9e62:	48 39 c7             	cmp    %rax,%rdi
    9e65:	73 e1                	jae    9e48 <fwp_caps23+0xb8>
    9e67:	48 89 f8             	mov    %rdi,%rax
    9e6a:	48 c1 e8 10          	shr    $0x10,%rax
    9e6e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9e72:	48 8b 05 9f 0d 06 00 	mov    0x60d9f(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    9e79:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9e7d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9e81:	48 85 c0             	test   %rax,%rax
    9e84:	74 c2                	je     9e48 <fwp_caps23+0xb8>
    9e86:	0f b6 0a             	movzbl (%rdx),%ecx
    9e89:	80 f9 02             	cmp    $0x2,%cl
    9e8c:	74 52                	je     9ee0 <fwp_caps23+0x150>
    9e8e:	80 f9 01             	cmp    $0x1,%cl
    9e91:	75 b5                	jne    9e48 <fwp_caps23+0xb8>
    9e93:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e96:	0f b7 ff             	movzwl %di,%edi
    9e99:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e9c:	48 0f af f9          	imul   %rcx,%rdi
    9ea0:	48 c1 ef 20          	shr    $0x20,%rdi
    9ea4:	48 39 d7             	cmp    %rdx,%rdi
    9ea7:	73 9f                	jae    9e48 <fwp_caps23+0xb8>
    9ea9:	48 01 f8             	add    %rdi,%rax
    9eac:	0f b6 10             	movzbl (%rax),%edx
    9eaf:	84 d2                	test   %dl,%dl
    9eb1:	74 95                	je     9e48 <fwp_caps23+0xb8>
    9eb3:	8b 0d 2f 16 06 00    	mov    0x6162f(%rip),%ecx        # 6b4e8 <iteration_active>
    9eb9:	85 c9                	test   %ecx,%ecx
    9ebb:	75 33                	jne    9ef0 <fwp_caps23+0x160>
    9ebd:	80 fa fd             	cmp    $0xfd,%dl
    9ec0:	77 38                	ja     9efa <fwp_caps23+0x16a>
    9ec2:	83 c2 01             	add    $0x1,%edx
    9ec5:	88 10                	mov    %dl,(%rax)
    9ec7:	e9 7c ff ff ff       	jmp    9e48 <fwp_caps23+0xb8>
    9ecc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ed0:	66 85 d2             	test   %dx,%dx
    9ed3:	0f 85 6f ff ff ff    	jne    9e48 <fwp_caps23+0xb8>
    9ed9:	e9 48 ff ff ff       	jmp    9e26 <fwp_caps23+0x96>
    9ede:	66 90                	xchg   %ax,%ax
    9ee0:	66 85 ff             	test   %di,%di
    9ee3:	0f 85 5f ff ff ff    	jne    9e48 <fwp_caps23+0xb8>
    9ee9:	eb c1                	jmp    9eac <fwp_caps23+0x11c>
    9eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ef0:	48 83 05 d8 15 06 00 	addq   $0x1,0x615d8(%rip)        # 6b4d0 <iteration_retains>
    9ef7:	01 
    9ef8:	eb c3                	jmp    9ebd <fwp_caps23+0x12d>
    9efa:	48 89 c7             	mov    %rax,%rdi
    9efd:	48 83 c4 18          	add    $0x18,%rsp
    9f01:	e9 aa b7 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9f06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9f0d:	00 00 00 

0000000000009f10 <fwp_write>:
    9f10:	41 57                	push   %r15
    9f12:	41 56                	push   %r14
    9f14:	41 55                	push   %r13
    9f16:	41 54                	push   %r12
    9f18:	55                   	push   %rbp
    9f19:	53                   	push   %rbx
    9f1a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9f21:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9f28:	00 00 
    9f2a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9f31:	00 
    9f32:	49 89 d4             	mov    %rdx,%r12
    9f35:	8b 12                	mov    (%rdx),%edx
    9f37:	83 fa 19             	cmp    $0x19,%edx
    9f3a:	77 6a                	ja     9fa6 <fwp_write+0x96>
    9f3c:	48 89 f5             	mov    %rsi,%rbp
    9f3f:	89 d0                	mov    %edx,%eax
    9f41:	89 ce                	mov    %ecx,%esi
    9f43:	48 89 fb             	mov    %rdi,%rbx
    9f46:	48 8d 0d 73 3d 00 00 	lea    0x3d73(%rip),%rcx        # dcc0 <_IO_stdin_used+0xcc0>
    9f4d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9f51:	48 01 c8             	add    %rcx,%rax
    9f54:	3e ff e0             	notrack jmp *%rax
    9f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f5e:	00 00 
    9f60:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9f64:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9f68:	48 89 ca             	mov    %rcx,%rdx
    9f6b:	48 85 c9             	test   %rcx,%rcx
    9f6e:	0f 88 9c 0c 00 00    	js     ac10 <fwp_write+0xd00>
    9f74:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9f7b:	00 
    9f7c:	48 89 c6             	mov    %rax,%rsi
    9f7f:	4c 89 e7             	mov    %r12,%rdi
    9f82:	e8 b9 9a ff ff       	call   3a40 <fwp_fmt_u128>
    9f87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f8e:	00 00 
    9f90:	4c 89 e7             	mov    %r12,%rdi
    9f93:	e8 a8 94 ff ff       	call   3440 <strlen@plt>
    9f98:	4c 89 e6             	mov    %r12,%rsi
    9f9b:	48 89 df             	mov    %rbx,%rdi
    9f9e:	48 89 c2             	mov    %rax,%rdx
    9fa1:	e8 4a a1 ff ff       	call   40f0 <buf_put>
    9fa6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9fad:	00 
    9fae:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9fb5:	00 00 
    9fb7:	0f 85 28 04 00 00    	jne    a3e5 <fwp_write+0x4d5>
    9fbd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9fc4:	5b                   	pop    %rbx
    9fc5:	5d                   	pop    %rbp
    9fc6:	41 5c                	pop    %r12
    9fc8:	41 5d                	pop    %r13
    9fca:	41 5e                	pop    %r14
    9fcc:	41 5f                	pop    %r15
    9fce:	c3                   	ret
    9fcf:	90                   	nop
    9fd0:	49 89 e9             	mov    %rbp,%r9
    9fd3:	4c 8d 05 81 32 00 00 	lea    0x3281(%rip),%r8        # d25b <_IO_stdin_used+0x25b>
    9fda:	b9 00 02 00 00       	mov    $0x200,%ecx
    9fdf:	ba 02 00 00 00       	mov    $0x2,%edx
    9fe4:	be 00 02 00 00       	mov    $0x200,%esi
    9fe9:	31 c0                	xor    %eax,%eax
    9feb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9ff2:	00 
    9ff3:	e8 a8 93 ff ff       	call   33a0 <__snprintf_chk@plt>
    9ff8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9fff:	00 
    a000:	e8 3b 94 ff ff       	call   3440 <strlen@plt>
    a005:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a00c:	00 
    a00d:	48 89 df             	mov    %rbx,%rdi
    a010:	48 89 c2             	mov    %rax,%rdx
    a013:	e8 d8 a0 ff ff       	call   40f0 <buf_put>
    a018:	eb 8c                	jmp    9fa6 <fwp_write+0x96>
    a01a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a020:	49 89 e9             	mov    %rbp,%r9
    a023:	4c 8d 05 2c 32 00 00 	lea    0x322c(%rip),%r8        # d256 <_IO_stdin_used+0x256>
    a02a:	eb ae                	jmp    9fda <fwp_write+0xca>
    a02c:	0f 1f 40 00          	nopl   0x0(%rax)
    a030:	83 fa 13             	cmp    $0x13,%edx
    a033:	48 8d 05 12 32 00 00 	lea    0x3212(%rip),%rax        # d24c <_IO_stdin_used+0x24c>
    a03a:	48 8d 35 10 32 00 00 	lea    0x3210(%rip),%rsi        # d251 <_IO_stdin_used+0x251>
    a041:	ba 04 00 00 00       	mov    $0x4,%edx
    a046:	48 0f 44 f0          	cmove  %rax,%rsi
    a04a:	45 31 ed             	xor    %r13d,%r13d
    a04d:	e8 9e a0 ff ff       	call   40f0 <buf_put>
    a052:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a057:	0f 84 a3 08 00 00    	je     a900 <fwp_write+0x9f0>
    a05d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    a062:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    a067:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a06c:	48 89 df             	mov    %rbx,%rdi
    a06f:	49 0f 44 c5          	cmove  %r13,%rax
    a073:	31 c9                	xor    %ecx,%ecx
    a075:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    a07a:	e8 91 fe ff ff       	call   9f10 <fwp_write>
    a07f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    a084:	0f 84 6e 09 00 00    	je     a9f8 <fwp_write+0xae8>
    a08a:	49 83 c5 01          	add    $0x1,%r13
    a08e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a092:	0f 83 68 08 00 00    	jae    a900 <fwp_write+0x9f0>
    a098:	ba 02 00 00 00       	mov    $0x2,%edx
    a09d:	48 8d 35 f7 31 00 00 	lea    0x31f7(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a0a4:	48 89 df             	mov    %rbx,%rdi
    a0a7:	e8 44 a0 ff ff       	call   40f0 <buf_put>
    a0ac:	eb af                	jmp    a05d <fwp_write+0x14d>
    a0ae:	66 90                	xchg   %ax,%ax
    a0b0:	ba 06 00 00 00       	mov    $0x6,%edx
    a0b5:	48 8d 35 b8 31 00 00 	lea    0x31b8(%rip),%rsi        # d274 <_IO_stdin_used+0x274>
    a0bc:	48 83 c5 10          	add    $0x10,%rbp
    a0c0:	e8 2b a0 ff ff       	call   40f0 <buf_put>
    a0c5:	48 89 ef             	mov    %rbp,%rdi
    a0c8:	e8 73 93 ff ff       	call   3440 <strlen@plt>
    a0cd:	48 89 ee             	mov    %rbp,%rsi
    a0d0:	48 89 df             	mov    %rbx,%rdi
    a0d3:	48 89 c2             	mov    %rax,%rdx
    a0d6:	e8 15 a0 ff ff       	call   40f0 <buf_put>
    a0db:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a0e0:	ba 01 00 00 00       	mov    $0x1,%edx
    a0e5:	48 89 df             	mov    %rbx,%rdi
    a0e8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a0ed:	e8 fe 9f ff ff       	call   40f0 <buf_put>
    a0f2:	e9 af fe ff ff       	jmp    9fa6 <fwp_write+0x96>
    a0f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a0fe:	00 00 
    a100:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a107:	00 
    a108:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a10f:	00 00 
    a111:	0f 85 ce 02 00 00    	jne    a3e5 <fwp_write+0x4d5>
    a117:	ba 0a 00 00 00       	mov    $0xa,%edx
    a11c:	48 8d 35 3d 31 00 00 	lea    0x313d(%rip),%rsi        # d260 <_IO_stdin_used+0x260>
    a123:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a12a:	48 89 df             	mov    %rbx,%rdi
    a12d:	5b                   	pop    %rbx
    a12e:	5d                   	pop    %rbp
    a12f:	41 5c                	pop    %r12
    a131:	41 5d                	pop    %r13
    a133:	41 5e                	pop    %r14
    a135:	41 5f                	pop    %r15
    a137:	e9 b4 9f ff ff       	jmp    40f0 <buf_put>
    a13c:	0f 1f 40 00          	nopl   0x0(%rax)
    a140:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a145:	4d 85 ed             	test   %r13,%r13
    a148:	0f 84 02 0c 00 00    	je     ad50 <fwp_write+0xe40>
    a14e:	48 8d 35 53 31 00 00 	lea    0x3153(%rip),%rsi        # d2a8 <_IO_stdin_used+0x2a8>
    a155:	4c 89 ef             	mov    %r13,%rdi
    a158:	e8 c3 93 ff ff       	call   3520 <strcmp@plt>
    a15d:	41 89 c1             	mov    %eax,%r9d
    a160:	85 c0                	test   %eax,%eax
    a162:	0f 84 6c 0c 00 00    	je     add4 <fwp_write+0xec4>
    a168:	4c 89 ef             	mov    %r13,%rdi
    a16b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a170:	e8 cb 92 ff ff       	call   3440 <strlen@plt>
    a175:	4c 89 ee             	mov    %r13,%rsi
    a178:	48 89 df             	mov    %rbx,%rdi
    a17b:	48 89 c2             	mov    %rax,%rdx
    a17e:	e8 6d 9f ff ff       	call   40f0 <buf_put>
    a183:	ba 01 00 00 00       	mov    $0x1,%edx
    a188:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a18d:	48 89 df             	mov    %rbx,%rdi
    a190:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a195:	e8 56 9f ff ff       	call   40f0 <buf_put>
    a19a:	ba 01 00 00 00       	mov    $0x1,%edx
    a19f:	4c 89 fe             	mov    %r15,%rsi
    a1a2:	48 89 df             	mov    %rbx,%rdi
    a1a5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a1aa:	e8 41 9f ff ff       	call   40f0 <buf_put>
    a1af:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a1b4:	45 31 f6             	xor    %r14d,%r14d
    a1b7:	85 d2                	test   %edx,%edx
    a1b9:	0f 8e 81 0a 00 00    	jle    ac40 <fwp_write+0xd30>
    a1bf:	45 31 ed             	xor    %r13d,%r13d
    a1c2:	4d 85 ed             	test   %r13,%r13
    a1c5:	0f 85 75 07 00 00    	jne    a940 <fwp_write+0xa30>
    a1cb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a1d2:	00 
    a1d3:	45 85 f6             	test   %r14d,%r14d
    a1d6:	0f 84 84 07 00 00    	je     a960 <fwp_write+0xa50>
    a1dc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a1e1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a1e6:	48 89 df             	mov    %rbx,%rdi
    a1e9:	49 83 c5 01          	add    $0x1,%r13
    a1ed:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a1f1:	31 c9                	xor    %ecx,%ecx
    a1f3:	e8 18 fd ff ff       	call   9f10 <fwp_write>
    a1f8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a1fd:	7f c3                	jg     a1c2 <fwp_write+0x2b2>
    a1ff:	45 85 f6             	test   %r14d,%r14d
    a202:	0f 84 38 0a 00 00    	je     ac40 <fwp_write+0xd30>
    a208:	b8 29 00 00 00       	mov    $0x29,%eax
    a20d:	ba 01 00 00 00       	mov    $0x1,%edx
    a212:	4c 89 fe             	mov    %r15,%rsi
    a215:	48 89 df             	mov    %rbx,%rdi
    a218:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a21c:	e8 cf 9e ff ff       	call   40f0 <buf_put>
    a221:	e9 80 fd ff ff       	jmp    9fa6 <fwp_write+0x96>
    a226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a22d:	00 00 00 
    a230:	ba 01 00 00 00       	mov    $0x1,%edx
    a235:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a23a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a23f:	e8 ac 9e ff ff       	call   40f0 <buf_put>
    a244:	48 85 ed             	test   %rbp,%rbp
    a247:	0f 84 93 06 00 00    	je     a8e0 <fwp_write+0x9d0>
    a24d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a251:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a256:	31 c9                	xor    %ecx,%ecx
    a258:	48 89 df             	mov    %rbx,%rdi
    a25b:	e8 b0 fc ff ff       	call   9f10 <fwp_write>
    a260:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a264:	48 85 ed             	test   %rbp,%rbp
    a267:	0f 84 73 06 00 00    	je     a8e0 <fwp_write+0x9d0>
    a26d:	ba 02 00 00 00       	mov    $0x2,%edx
    a272:	48 8d 35 22 30 00 00 	lea    0x3022(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a279:	48 89 df             	mov    %rbx,%rdi
    a27c:	e8 6f 9e ff ff       	call   40f0 <buf_put>
    a281:	eb ca                	jmp    a24d <fwp_write+0x33d>
    a283:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a288:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a28c:	85 f6                	test   %esi,%esi
    a28e:	0f 84 fc 07 00 00    	je     aa90 <fwp_write+0xb80>
    a294:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a29b:	00 
    a29c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a2a3:	00 00 
    a2a5:	0f 85 3a 01 00 00    	jne    a3e5 <fwp_write+0x4d5>
    a2ab:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a2af:	4c 89 ea             	mov    %r13,%rdx
    a2b2:	e9 6c fe ff ff       	jmp    a123 <fwp_write+0x213>
    a2b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2be:	00 00 
    a2c0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a2c5:	ba 01 00 00 00       	mov    $0x1,%edx
    a2ca:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a2cf:	48 89 ee             	mov    %rbp,%rsi
    a2d2:	e8 19 9e ff ff       	call   40f0 <buf_put>
    a2d7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a2dc:	4c 89 e7             	mov    %r12,%rdi
    a2df:	e8 5c 91 ff ff       	call   3440 <strlen@plt>
    a2e4:	4c 89 e6             	mov    %r12,%rsi
    a2e7:	48 89 df             	mov    %rbx,%rdi
    a2ea:	48 89 c2             	mov    %rax,%rdx
    a2ed:	e8 fe 9d ff ff       	call   40f0 <buf_put>
    a2f2:	ba 01 00 00 00       	mov    $0x1,%edx
    a2f7:	48 89 ee             	mov    %rbp,%rsi
    a2fa:	48 89 df             	mov    %rbx,%rdi
    a2fd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a302:	e8 e9 9d ff ff       	call   40f0 <buf_put>
    a307:	e9 9a fc ff ff       	jmp    9fa6 <fwp_write+0x96>
    a30c:	0f 1f 40 00          	nopl   0x0(%rax)
    a310:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a315:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a319:	0f 8a 8e 0b 00 00    	jp     aead <fwp_write+0xf9d>
    a31f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a323:	66 0f 54 05 95 3a 00 	andpd  0x3a95(%rip),%xmm0        # ddc0 <msg.4+0x90>
    a32a:	00 
    a32b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a330:	66 0f 2e 05 c0 3a 00 	ucomisd 0x3ac0(%rip),%xmm0        # ddf8 <msg.4+0xc8>
    a337:	00 
    a338:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a33f:	00 
    a340:	0f 87 b2 09 00 00    	ja     acf8 <fwp_write+0xde8>
    a346:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a34d:	00 00 00 
    a350:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a354:	89 ee                	mov    %ebp,%esi
    a356:	4c 89 e7             	mov    %r12,%rdi
    a359:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a35e:	e8 0d a4 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a363:	31 f6                	xor    %esi,%esi
    a365:	4c 89 e7             	mov    %r12,%rdi
    a368:	e8 93 90 ff ff       	call   3400 <strtod@plt>
    a36d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a372:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a376:	7a 06                	jp     a37e <fwp_write+0x46e>
    a378:	0f 84 e9 01 00 00    	je     a567 <fwp_write+0x657>
    a37e:	83 c5 01             	add    $0x1,%ebp
    a381:	83 fd 12             	cmp    $0x12,%ebp
    a384:	75 ca                	jne    a350 <fwp_write+0x440>
    a386:	be 11 00 00 00       	mov    $0x11,%esi
    a38b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a38f:	4c 89 e7             	mov    %r12,%rdi
    a392:	e8 d9 a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a397:	e9 cb 01 00 00       	jmp    a567 <fwp_write+0x657>
    a39c:	0f 1f 40 00          	nopl   0x0(%rax)
    a3a0:	48 83 fd 01          	cmp    $0x1,%rbp
    a3a4:	0f 84 e6 08 00 00    	je     ac90 <fwp_write+0xd80>
    a3aa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a3ae:	b8 02 00 00 00       	mov    $0x2,%eax
    a3b3:	ba 01 00 00 00       	mov    $0x1,%edx
    a3b8:	48 0f 44 d0          	cmove  %rax,%rdx
    a3bc:	48 8d 35 81 2e 00 00 	lea    0x2e81(%rip),%rsi        # d244 <_IO_stdin_used+0x244>
    a3c3:	48 8d 05 7f 2e 00 00 	lea    0x2e7f(%rip),%rax        # d249 <_IO_stdin_used+0x249>
    a3ca:	48 0f 44 f0          	cmove  %rax,%rsi
    a3ce:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a3d5:	00 
    a3d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a3dd:	00 00 
    a3df:	0f 84 3e fd ff ff    	je     a123 <fwp_write+0x213>
    a3e5:	e8 66 90 ff ff       	call   3450 <__stack_chk_fail@plt>
    a3ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3f0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a3f5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a3fa:	e8 31 9c ff ff       	call   4030 <buf_grow>
    a3ff:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a403:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a409:	4c 03 0b             	add    (%rbx),%r9
    a40c:	66 45 89 11          	mov    %r10w,(%r9)
    a410:	45 85 e4             	test   %r12d,%r12d
    a413:	0f 8e 07 05 00 00    	jle    a920 <fwp_write+0xa10>
    a419:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a420:	55 55 55 
    a423:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a428:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a42f:	aa aa aa 
    a432:	49 83 c1 01          	add    $0x1,%r9
    a436:	eb 45                	jmp    a47d <fwp_write+0x56d>
    a438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a43f:	00 
    a440:	be 01 00 00 00       	mov    $0x1,%esi
    a445:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a44a:	88 07                	mov    %al,(%rdi)
    a44c:	48 89 e8             	mov    %rbp,%rax
    a44f:	49 f7 e8             	imul   %r8
    a452:	48 89 e8             	mov    %rbp,%rax
    a455:	48 c1 f8 3f          	sar    $0x3f,%rax
    a459:	48 29 c2             	sub    %rax,%rdx
    a45c:	48 85 c9             	test   %rcx,%rcx
    a45f:	0f 95 c0             	setne  %al
    a462:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a466:	48 83 ef 01          	sub    $0x1,%rdi
    a46a:	48 21 c5             	and    %rax,%rbp
    a46d:	48 29 ea             	sub    %rbp,%rdx
    a470:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a474:	49 39 f9             	cmp    %rdi,%r9
    a477:	0f 84 a3 04 00 00    	je     a920 <fwp_write+0xa10>
    a47d:	48 89 e8             	mov    %rbp,%rax
    a480:	49 f7 e8             	imul   %r8
    a483:	48 89 e8             	mov    %rbp,%rax
    a486:	48 c1 f8 3f          	sar    $0x3f,%rax
    a48a:	48 89 d1             	mov    %rdx,%rcx
    a48d:	48 29 c1             	sub    %rax,%rcx
    a490:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a494:	48 89 e9             	mov    %rbp,%rcx
    a497:	48 29 c1             	sub    %rax,%rcx
    a49a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a49e:	49 f7 e2             	mul    %r10
    a4a1:	b8 30 00 00 00       	mov    $0x30,%eax
    a4a6:	48 89 d6             	mov    %rdx,%rsi
    a4a9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a4ad:	48 d1 ee             	shr    $1,%rsi
    a4b0:	48 01 f2             	add    %rsi,%rdx
    a4b3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a4b7:	48 29 d6             	sub    %rdx,%rsi
    a4ba:	74 8e                	je     a44a <fwp_write+0x53a>
    a4bc:	48 83 fe 01          	cmp    $0x1,%rsi
    a4c0:	0f 85 7a ff ff ff    	jne    a440 <fwp_write+0x530>
    a4c6:	31 f6                	xor    %esi,%esi
    a4c8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a4cd:	e9 78 ff ff ff       	jmp    a44a <fwp_write+0x53a>
    a4d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4d8:	66 0f 6e cd          	movd   %ebp,%xmm1
    a4dc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a4df:	0f 8a c8 09 00 00    	jp     aead <fwp_write+0xf9d>
    a4e5:	0f 28 c1             	movaps %xmm1,%xmm0
    a4e8:	0f 54 05 c1 38 00 00 	andps  0x38c1(%rip),%xmm0        # ddb0 <msg.4+0x80>
    a4ef:	0f 2e 05 0e 2b 00 00 	ucomiss 0x2b0e(%rip),%xmm0        # d004 <_IO_stdin_used+0x4>
    a4f6:	0f 87 24 08 00 00    	ja     ad20 <fwp_write+0xe10>
    a4fc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a500:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a506:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a50d:	00 
    a50e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a512:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a517:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a51e:	00 00 
    a520:	44 89 ee             	mov    %r13d,%esi
    a523:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a528:	4c 89 e7             	mov    %r12,%rdi
    a52b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a530:	e8 3b a2 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a535:	31 f6                	xor    %esi,%esi
    a537:	4c 89 e7             	mov    %r12,%rdi
    a53a:	e8 61 8f ff ff       	call   34a0 <strtof@plt>
    a53f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a544:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a547:	7a 02                	jp     a54b <fwp_write+0x63b>
    a549:	74 1c                	je     a567 <fwp_write+0x657>
    a54b:	41 83 c5 01          	add    $0x1,%r13d
    a54f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a553:	75 cb                	jne    a520 <fwp_write+0x610>
    a555:	be 09 00 00 00       	mov    $0x9,%esi
    a55a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a55f:	4c 89 e7             	mov    %r12,%rdi
    a562:	e8 09 a2 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a567:	4c 89 e7             	mov    %r12,%rdi
    a56a:	e8 41 9c ff ff       	call   41b0 <fwp_finish_float>
    a56f:	e9 1c fa ff ff       	jmp    9f90 <fwp_write+0x80>
    a574:	0f 1f 40 00          	nopl   0x0(%rax)
    a578:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a57c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a580:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a587:	00 
    a588:	48 89 ef             	mov    %rbp,%rdi
    a58b:	e8 b0 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a590:	48 89 ef             	mov    %rbp,%rdi
    a593:	e8 a8 8e ff ff       	call   3440 <strlen@plt>
    a598:	48 89 ee             	mov    %rbp,%rsi
    a59b:	48 89 df             	mov    %rbx,%rdi
    a59e:	48 89 c2             	mov    %rax,%rdx
    a5a1:	e8 4a 9b ff ff       	call   40f0 <buf_put>
    a5a6:	e9 fb f9 ff ff       	jmp    9fa6 <fwp_write+0x96>
    a5ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a5b0:	ba 06 00 00 00       	mov    $0x6,%edx
    a5b5:	48 8d 35 e2 2c 00 00 	lea    0x2ce2(%rip),%rsi        # d29e <_IO_stdin_used+0x29e>
    a5bc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a5c2:	e8 29 9b ff ff       	call   40f0 <buf_put>
    a5c7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a5ce:	ff ff 7f 
    a5d1:	48 23 55 00          	and    0x0(%rbp),%rdx
    a5d5:	0f 84 86 02 00 00    	je     a861 <fwp_write+0x951>
    a5db:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a5e0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a5e4:	48 85 d2             	test   %rdx,%rdx
    a5e7:	0f 84 ae 00 00 00    	je     a69b <fwp_write+0x78b>
    a5ed:	8b 0a                	mov    (%rdx),%ecx
    a5ef:	83 f9 1c             	cmp    $0x1c,%ecx
    a5f2:	0f 84 58 06 00 00    	je     ac50 <fwp_write+0xd40>
    a5f8:	83 f9 1b             	cmp    $0x1b,%ecx
    a5fb:	0f 87 9a 00 00 00    	ja     a69b <fwp_write+0x78b>
    a601:	be 01 00 00 00       	mov    $0x1,%esi
    a606:	48 d3 e6             	shl    %cl,%rsi
    a609:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a60f:	0f 85 4b 04 00 00    	jne    aa60 <fwp_write+0xb50>
    a615:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a61b:	0f 85 0f 04 00 00    	jne    aa30 <fwp_write+0xb20>
    a621:	83 e6 21             	and    $0x21,%esi
    a624:	74 75                	je     a69b <fwp_write+0x78b>
    a626:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a62b:	48 85 ff             	test   %rdi,%rdi
    a62e:	79 07                	jns    a637 <fwp_write+0x727>
    a630:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a634:	4c 01 ee             	add    %r13,%rsi
    a637:	48 0f be 3e          	movsbq (%rsi),%rdi
    a63b:	85 c9                	test   %ecx,%ecx
    a63d:	40 0f b6 f7          	movzbl %dil,%esi
    a641:	48 0f 44 f7          	cmove  %rdi,%rsi
    a645:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a64c:	00 00 00 00 
    a650:	31 c9                	xor    %ecx,%ecx
    a652:	48 89 df             	mov    %rbx,%rdi
    a655:	49 83 c5 01          	add    $0x1,%r13
    a659:	e8 b2 f8 ff ff       	call   9f10 <fwp_write>
    a65e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a665:	ff ff 7f 
    a668:	48 23 55 00          	and    0x0(%rbp),%rdx
    a66c:	49 39 d5             	cmp    %rdx,%r13
    a66f:	0f 83 ec 01 00 00    	jae    a861 <fwp_write+0x951>
    a675:	ba 02 00 00 00       	mov    $0x2,%edx
    a67a:	48 89 df             	mov    %rbx,%rdi
    a67d:	48 8d 35 17 2c 00 00 	lea    0x2c17(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a684:	e8 67 9a ff ff       	call   40f0 <buf_put>
    a689:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a68e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a692:	48 85 d2             	test   %rdx,%rdx
    a695:	0f 85 52 ff ff ff    	jne    a5ed <fwp_write+0x6dd>
    a69b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a6a0:	48 85 ff             	test   %rdi,%rdi
    a6a3:	0f 88 cf 05 00 00    	js     ac78 <fwp_write+0xd68>
    a6a9:	48 8b 31             	mov    (%rcx),%rsi
    a6ac:	eb a2                	jmp    a650 <fwp_write+0x740>
    a6ae:	66 90                	xchg   %ax,%ax
    a6b0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a6b7:	00 
    a6b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a6bf:	00 00 
    a6c1:	0f 85 1e fd ff ff    	jne    a3e5 <fwp_write+0x4d5>
    a6c7:	ba 08 00 00 00       	mov    $0x8,%edx
    a6cc:	48 8d 35 98 2b 00 00 	lea    0x2b98(%rip),%rsi        # d26b <_IO_stdin_used+0x26b>
    a6d3:	e9 4b fa ff ff       	jmp    a123 <fwp_write+0x213>
    a6d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a6df:	00 
    a6e0:	89 e8                	mov    %ebp,%eax
    a6e2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a6e9:	76 03                	jbe    a6ee <fwp_write+0x7de>
    a6eb:	8b 45 00             	mov    0x0(%rbp),%eax
    a6ee:	41 89 c6             	mov    %eax,%r14d
    a6f1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a6f6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a6fb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a6ff:	4c 89 ef             	mov    %r13,%rdi
    a702:	e8 39 8d ff ff       	call   3440 <strlen@plt>
    a707:	4c 89 ee             	mov    %r13,%rsi
    a70a:	48 89 df             	mov    %rbx,%rdi
    a70d:	48 89 c2             	mov    %rax,%rdx
    a710:	e8 db 99 ff ff       	call   40f0 <buf_put>
    a715:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a71a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a71e:	85 f6                	test   %esi,%esi
    a720:	0f 8e 80 f8 ff ff    	jle    9fa6 <fwp_write+0x96>
    a726:	45 31 ed             	xor    %r13d,%r13d
    a729:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a72e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a733:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a738:	ba 01 00 00 00       	mov    $0x1,%edx
    a73d:	4c 89 fe             	mov    %r15,%rsi
    a740:	48 89 04 24          	mov    %rax,(%rsp)
    a744:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a749:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a74d:	48 89 df             	mov    %rbx,%rdi
    a750:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a754:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a759:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a75e:	e8 8d 99 ff ff       	call   40f0 <buf_put>
    a763:	41 8b 06             	mov    (%r14),%eax
    a766:	83 f8 0e             	cmp    $0xe,%eax
    a769:	0f 84 71 02 00 00    	je     a9e0 <fwp_write+0xad0>
    a76f:	83 f8 10             	cmp    $0x10,%eax
    a772:	0f 84 38 02 00 00    	je     a9b0 <fwp_write+0xaa0>
    a778:	83 f8 0a             	cmp    $0xa,%eax
    a77b:	0f 84 7f 04 00 00    	je     ac00 <fwp_write+0xcf0>
    a781:	0f 8f f9 00 00 00    	jg     a880 <fwp_write+0x970>
    a787:	83 f8 03             	cmp    $0x3,%eax
    a78a:	0f 8f 50 04 00 00    	jg     abe0 <fwp_write+0xcd0>
    a790:	85 c0                	test   %eax,%eax
    a792:	78 10                	js     a7a4 <fwp_write+0x894>
    a794:	48 8b 04 24          	mov    (%rsp),%rax
    a798:	48 c1 e8 3f          	shr    $0x3f,%rax
    a79c:	85 c0                	test   %eax,%eax
    a79e:	0f 85 f9 00 00 00    	jne    a89d <fwp_write+0x98d>
    a7a4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a7a9:	48 8b 34 24          	mov    (%rsp),%rsi
    a7ad:	31 c9                	xor    %ecx,%ecx
    a7af:	48 89 df             	mov    %rbx,%rdi
    a7b2:	e8 59 f7 ff ff       	call   9f10 <fwp_write>
    a7b7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a7bc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a7c1:	49 83 c5 01          	add    $0x1,%r13
    a7c5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a7c9:	0f 8f 5f ff ff ff    	jg     a72e <fwp_write+0x81e>
    a7cf:	e9 d2 f7 ff ff       	jmp    9fa6 <fwp_write+0x96>
    a7d4:	0f 1f 40 00          	nopl   0x0(%rax)
    a7d8:	ba 06 00 00 00       	mov    $0x6,%edx
    a7dd:	48 8d 35 ad 2a 00 00 	lea    0x2aad(%rip),%rsi        # d291 <_IO_stdin_used+0x291>
    a7e4:	45 31 ed             	xor    %r13d,%r13d
    a7e7:	e8 04 99 ff ff       	call   40f0 <buf_put>
    a7ec:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a7f1:	75 19                	jne    a80c <fwp_write+0x8fc>
    a7f3:	eb 6c                	jmp    a861 <fwp_write+0x951>
    a7f5:	0f 1f 00             	nopl   (%rax)
    a7f8:	ba 02 00 00 00       	mov    $0x2,%edx
    a7fd:	48 8d 35 97 2a 00 00 	lea    0x2a97(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a804:	48 89 df             	mov    %rbx,%rdi
    a807:	e8 e4 98 ff ff       	call   40f0 <buf_put>
    a80c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a812:	b9 00 02 00 00       	mov    $0x200,%ecx
    a817:	31 c0                	xor    %eax,%eax
    a819:	49 83 c5 01          	add    $0x1,%r13
    a81d:	4c 8d 05 74 2a 00 00 	lea    0x2a74(%rip),%r8        # d298 <_IO_stdin_used+0x298>
    a824:	ba 02 00 00 00       	mov    $0x2,%edx
    a829:	be 00 02 00 00       	mov    $0x200,%esi
    a82e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a835:	00 
    a836:	e8 65 8b ff ff       	call   33a0 <__snprintf_chk@plt>
    a83b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a842:	00 
    a843:	e8 f8 8b ff ff       	call   3440 <strlen@plt>
    a848:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a84f:	00 
    a850:	48 89 df             	mov    %rbx,%rdi
    a853:	48 89 c2             	mov    %rax,%rdx
    a856:	e8 95 98 ff ff       	call   40f0 <buf_put>
    a85b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a85f:	72 97                	jb     a7f8 <fwp_write+0x8e8>
    a861:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a866:	ba 01 00 00 00       	mov    $0x1,%edx
    a86b:	48 89 df             	mov    %rbx,%rdi
    a86e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a873:	e8 78 98 ff ff       	call   40f0 <buf_put>
    a878:	e9 29 f7 ff ff       	jmp    9fa6 <fwp_write+0x96>
    a87d:	0f 1f 00             	nopl   (%rax)
    a880:	83 f8 0b             	cmp    $0xb,%eax
    a883:	0f 85 1b ff ff ff    	jne    a7a4 <fwp_write+0x894>
    a889:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a88e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a892:	83 e0 01             	and    $0x1,%eax
    a895:	85 c0                	test   %eax,%eax
    a897:	0f 84 07 ff ff ff    	je     a7a4 <fwp_write+0x894>
    a89d:	4c 89 fe             	mov    %r15,%rsi
    a8a0:	48 89 df             	mov    %rbx,%rdi
    a8a3:	ba 01 00 00 00       	mov    $0x1,%edx
    a8a8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a8ad:	e8 3e 98 ff ff       	call   40f0 <buf_put>
    a8b2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a8b7:	48 8b 34 24          	mov    (%rsp),%rsi
    a8bb:	31 c9                	xor    %ecx,%ecx
    a8bd:	48 89 df             	mov    %rbx,%rdi
    a8c0:	e8 4b f6 ff ff       	call   9f10 <fwp_write>
    a8c5:	ba 01 00 00 00       	mov    $0x1,%edx
    a8ca:	4c 89 fe             	mov    %r15,%rsi
    a8cd:	48 89 df             	mov    %rbx,%rdi
    a8d0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a8d5:	e8 16 98 ff ff       	call   40f0 <buf_put>
    a8da:	e9 d8 fe ff ff       	jmp    a7b7 <fwp_write+0x8a7>
    a8df:	90                   	nop
    a8e0:	ba 01 00 00 00       	mov    $0x1,%edx
    a8e5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a8ea:	48 89 df             	mov    %rbx,%rdi
    a8ed:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a8f2:	e8 f9 97 ff ff       	call   40f0 <buf_put>
    a8f7:	e9 aa f6 ff ff       	jmp    9fa6 <fwp_write+0x96>
    a8fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a900:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a905:	ba 01 00 00 00       	mov    $0x1,%edx
    a90a:	48 89 df             	mov    %rbx,%rdi
    a90d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a912:	e8 d9 97 ff ff       	call   40f0 <buf_put>
    a917:	e9 8a f6 ff ff       	jmp    9fa6 <fwp_write+0x96>
    a91c:	0f 1f 40 00          	nopl   0x0(%rax)
    a920:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a924:	48 8b 13             	mov    (%rbx),%rdx
    a927:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a92c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a930:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a934:	e9 6d f6 ff ff       	jmp    9fa6 <fwp_write+0x96>
    a939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a940:	ba 02 00 00 00       	mov    $0x2,%edx
    a945:	48 8d 35 4f 29 00 00 	lea    0x294f(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a94c:	48 89 df             	mov    %rbx,%rdi
    a94f:	e8 9c 97 ff ff       	call   40f0 <buf_put>
    a954:	e9 72 f8 ff ff       	jmp    a1cb <fwp_write+0x2bb>
    a959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a960:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a965:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a96a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a96e:	48 89 f7             	mov    %rsi,%rdi
    a971:	48 89 34 24          	mov    %rsi,(%rsp)
    a975:	e8 c6 8a ff ff       	call   3440 <strlen@plt>
    a97a:	48 8b 34 24          	mov    (%rsp),%rsi
    a97e:	48 89 df             	mov    %rbx,%rdi
    a981:	48 89 c2             	mov    %rax,%rdx
    a984:	e8 67 97 ff ff       	call   40f0 <buf_put>
    a989:	ba 03 00 00 00       	mov    $0x3,%edx
    a98e:	48 8d 35 29 29 00 00 	lea    0x2929(%rip),%rsi        # d2be <_IO_stdin_used+0x2be>
    a995:	48 89 df             	mov    %rbx,%rdi
    a998:	e8 53 97 ff ff       	call   40f0 <buf_put>
    a99d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a9a2:	e9 35 f8 ff ff       	jmp    a1dc <fwp_write+0x2cc>
    a9a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a9ae:	00 00 
    a9b0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a9b5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a9b9:	48 85 ff             	test   %rdi,%rdi
    a9bc:	0f 84 e2 fd ff ff    	je     a7a4 <fwp_write+0x894>
    a9c2:	48 8d 35 df 28 00 00 	lea    0x28df(%rip),%rsi        # d2a8 <_IO_stdin_used+0x2a8>
    a9c9:	e8 52 8b ff ff       	call   3520 <strcmp@plt>
    a9ce:	85 c0                	test   %eax,%eax
    a9d0:	0f 95 c0             	setne  %al
    a9d3:	0f b6 c0             	movzbl %al,%eax
    a9d6:	e9 c1 fd ff ff       	jmp    a79c <fwp_write+0x88c>
    a9db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a9e0:	31 c0                	xor    %eax,%eax
    a9e2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a9e9:	00 
    a9ea:	0f 97 c0             	seta   %al
    a9ed:	e9 aa fd ff ff       	jmp    a79c <fwp_write+0x88c>
    a9f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9f8:	48 89 df             	mov    %rbx,%rdi
    a9fb:	ba 02 00 00 00       	mov    $0x2,%edx
    aa00:	48 8d 35 9e 28 00 00 	lea    0x289e(%rip),%rsi        # d2a5 <_IO_stdin_used+0x2a5>
    aa07:	e8 e4 96 ff ff       	call   40f0 <buf_put>
    aa0c:	4c 89 e8             	mov    %r13,%rax
    aa0f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    aa14:	31 c9                	xor    %ecx,%ecx
    aa16:	48 c1 e0 04          	shl    $0x4,%rax
    aa1a:	48 89 df             	mov    %rbx,%rdi
    aa1d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    aa22:	e8 e9 f4 ff ff       	call   9f10 <fwp_write>
    aa27:	e9 5e f6 ff ff       	jmp    a08a <fwp_write+0x17a>
    aa2c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa30:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    aa35:	48 85 ff             	test   %rdi,%rdi
    aa38:	79 0c                	jns    aa46 <fwp_write+0xb36>
    aa3a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    aa41:	00 
    aa42:	48 03 75 10          	add    0x10(%rbp),%rsi
    aa46:	48 63 3e             	movslq (%rsi),%rdi
    aa49:	83 f9 02             	cmp    $0x2,%ecx
    aa4c:	89 fe                	mov    %edi,%esi
    aa4e:	48 0f 44 f7          	cmove  %rdi,%rsi
    aa52:	e9 f9 fb ff ff       	jmp    a650 <fwp_write+0x740>
    aa57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    aa5e:	00 00 
    aa60:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    aa65:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    aa6a:	48 85 ff             	test   %rdi,%rdi
    aa6d:	0f 88 0f 03 00 00    	js     ad82 <fwp_write+0xe72>
    aa73:	49 0f bf 38          	movswq (%r8),%rdi
    aa77:	83 f9 01             	cmp    $0x1,%ecx
    aa7a:	0f b7 f7             	movzwl %di,%esi
    aa7d:	48 0f 44 f7          	cmove  %rdi,%rsi
    aa81:	e9 ca fb ff ff       	jmp    a650 <fwp_write+0x740>
    aa86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa8d:	00 00 00 
    aa90:	ba 01 00 00 00       	mov    $0x1,%edx
    aa95:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    aa9a:	48 83 c5 08          	add    $0x8,%rbp
    aa9e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    aaa3:	e8 48 96 ff ff       	call   40f0 <buf_put>
    aaa8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aaad:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    aab2:	4d 85 ed             	test   %r13,%r13
    aab5:	75 46                	jne    aafd <fwp_write+0xbed>
    aab7:	e9 04 01 00 00       	jmp    abc0 <fwp_write+0xcb0>
    aabc:	0f 1f 40 00          	nopl   0x0(%rax)
    aac0:	41 80 f9 09          	cmp    $0x9,%r9b
    aac4:	0f 84 d6 00 00 00    	je     aba0 <fwp_write+0xc90>
    aaca:	41 80 f9 0a          	cmp    $0xa,%r9b
    aace:	0f 85 9c 00 00 00    	jne    ab70 <fwp_write+0xc60>
    aad4:	ba 02 00 00 00       	mov    $0x2,%edx
    aad9:	48 8d 35 a1 27 00 00 	lea    0x27a1(%rip),%rsi        # d281 <_IO_stdin_used+0x281>
    aae0:	48 89 df             	mov    %rbx,%rdi
    aae3:	e8 08 96 ff ff       	call   40f0 <buf_put>
    aae8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aaef:	00 
    aaf0:	48 83 c5 01          	add    $0x1,%rbp
    aaf4:	49 39 ec             	cmp    %rbp,%r12
    aaf7:	0f 84 c3 00 00 00    	je     abc0 <fwp_write+0xcb0>
    aafd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    ab02:	41 80 f9 0d          	cmp    $0xd,%r9b
    ab06:	74 28                	je     ab30 <fwp_write+0xc20>
    ab08:	7e b6                	jle    aac0 <fwp_write+0xbb0>
    ab0a:	41 80 f9 22          	cmp    $0x22,%r9b
    ab0e:	74 40                	je     ab50 <fwp_write+0xc40>
    ab10:	41 80 f9 5c          	cmp    $0x5c,%r9b
    ab14:	75 5a                	jne    ab70 <fwp_write+0xc60>
    ab16:	ba 02 00 00 00       	mov    $0x2,%edx
    ab1b:	48 8d 35 5c 27 00 00 	lea    0x275c(%rip),%rsi        # d27e <_IO_stdin_used+0x27e>
    ab22:	48 89 df             	mov    %rbx,%rdi
    ab25:	e8 c6 95 ff ff       	call   40f0 <buf_put>
    ab2a:	eb c4                	jmp    aaf0 <fwp_write+0xbe0>
    ab2c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab30:	ba 02 00 00 00       	mov    $0x2,%edx
    ab35:	48 8d 35 4b 27 00 00 	lea    0x274b(%rip),%rsi        # d287 <_IO_stdin_used+0x287>
    ab3c:	48 89 df             	mov    %rbx,%rdi
    ab3f:	e8 ac 95 ff ff       	call   40f0 <buf_put>
    ab44:	eb aa                	jmp    aaf0 <fwp_write+0xbe0>
    ab46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ab4d:	00 00 00 
    ab50:	ba 02 00 00 00       	mov    $0x2,%edx
    ab55:	48 8d 35 1f 27 00 00 	lea    0x271f(%rip),%rsi        # d27b <_IO_stdin_used+0x27b>
    ab5c:	48 89 df             	mov    %rbx,%rdi
    ab5f:	e8 8c 95 ff ff       	call   40f0 <buf_put>
    ab64:	eb 8a                	jmp    aaf0 <fwp_write+0xbe0>
    ab66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ab6d:	00 00 00 
    ab70:	41 80 f9 1f          	cmp    $0x1f,%r9b
    ab74:	0f 86 2e 01 00 00    	jbe    aca8 <fwp_write+0xd98>
    ab7a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    ab7e:	0f 84 24 01 00 00    	je     aca8 <fwp_write+0xd98>
    ab84:	ba 01 00 00 00       	mov    $0x1,%edx
    ab89:	4c 89 fe             	mov    %r15,%rsi
    ab8c:	48 89 df             	mov    %rbx,%rdi
    ab8f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    ab94:	e8 57 95 ff ff       	call   40f0 <buf_put>
    ab99:	e9 52 ff ff ff       	jmp    aaf0 <fwp_write+0xbe0>
    ab9e:	66 90                	xchg   %ax,%ax
    aba0:	ba 02 00 00 00       	mov    $0x2,%edx
    aba5:	48 8d 35 d8 26 00 00 	lea    0x26d8(%rip),%rsi        # d284 <_IO_stdin_used+0x284>
    abac:	48 89 df             	mov    %rbx,%rdi
    abaf:	e8 3c 95 ff ff       	call   40f0 <buf_put>
    abb4:	e9 37 ff ff ff       	jmp    aaf0 <fwp_write+0xbe0>
    abb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abc0:	ba 01 00 00 00       	mov    $0x1,%edx
    abc5:	4c 89 fe             	mov    %r15,%rsi
    abc8:	48 89 df             	mov    %rbx,%rdi
    abcb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    abd0:	e8 1b 95 ff ff       	call   40f0 <buf_put>
    abd5:	e9 cc f3 ff ff       	jmp    9fa6 <fwp_write+0x96>
    abda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abe0:	83 f8 04             	cmp    $0x4,%eax
    abe3:	0f 85 bb fb ff ff    	jne    a7a4 <fwp_write+0x894>
    abe9:	48 8b 04 24          	mov    (%rsp),%rax
    abed:	48 8b 40 08          	mov    0x8(%rax),%rax
    abf1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    abf6:	48 c1 e8 3f          	shr    $0x3f,%rax
    abfa:	e9 96 fc ff ff       	jmp    a895 <fwp_write+0x985>
    abff:	90                   	nop
    ac00:	8b 0c 24             	mov    (%rsp),%ecx
    ac03:	31 c0                	xor    %eax,%eax
    ac05:	85 c9                	test   %ecx,%ecx
    ac07:	0f 98 c0             	sets   %al
    ac0a:	e9 86 fc ff ff       	jmp    a895 <fwp_write+0x985>
    ac0f:	90                   	nop
    ac10:	48 f7 d8             	neg    %rax
    ac13:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    ac1a:	00 
    ac1b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    ac22:	2d 
    ac23:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac2a:	00 
    ac2b:	48 83 d2 00          	adc    $0x0,%rdx
    ac2f:	48 89 c6             	mov    %rax,%rsi
    ac32:	48 f7 da             	neg    %rdx
    ac35:	e8 06 8e ff ff       	call   3a40 <fwp_fmt_u128>
    ac3a:	e9 51 f3 ff ff       	jmp    9f90 <fwp_write+0x80>
    ac3f:	90                   	nop
    ac40:	b8 7d 00 00 00       	mov    $0x7d,%eax
    ac45:	e9 c3 f5 ff ff       	jmp    a20d <fwp_write+0x2fd>
    ac4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac50:	4c 89 e9             	mov    %r13,%rcx
    ac53:	48 c1 e1 04          	shl    $0x4,%rcx
    ac57:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    ac5c:	48 85 ff             	test   %rdi,%rdi
    ac5f:	0f 89 eb f9 ff ff    	jns    a650 <fwp_write+0x740>
    ac65:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ac69:	48 89 ce             	mov    %rcx,%rsi
    ac6c:	e9 df f9 ff ff       	jmp    a650 <fwp_write+0x740>
    ac71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac78:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    ac7f:	00 
    ac80:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ac84:	e9 20 fa ff ff       	jmp    a6a9 <fwp_write+0x799>
    ac89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac90:	ba 02 00 00 00       	mov    $0x2,%edx
    ac95:	48 8d 35 aa 25 00 00 	lea    0x25aa(%rip),%rsi        # d246 <_IO_stdin_used+0x246>
    ac9c:	e9 2d f7 ff ff       	jmp    a3ce <fwp_write+0x4be>
    aca1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aca8:	4c 8d 05 db 25 00 00 	lea    0x25db(%rip),%r8        # d28a <_IO_stdin_used+0x28a>
    acaf:	b9 10 00 00 00       	mov    $0x10,%ecx
    acb4:	31 c0                	xor    %eax,%eax
    acb6:	ba 02 00 00 00       	mov    $0x2,%edx
    acbb:	be 10 00 00 00       	mov    $0x10,%esi
    acc0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    acc7:	00 
    acc8:	e8 d3 86 ff ff       	call   33a0 <__snprintf_chk@plt>
    accd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    acd4:	00 
    acd5:	e8 66 87 ff ff       	call   3440 <strlen@plt>
    acda:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ace1:	00 
    ace2:	48 89 df             	mov    %rbx,%rdi
    ace5:	48 89 c2             	mov    %rax,%rdx
    ace8:	e8 03 94 ff ff       	call   40f0 <buf_put>
    aced:	e9 fe fd ff ff       	jmp    aaf0 <fwp_write+0xbe0>
    acf2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    acf8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    acfc:	48 8d 35 3d 25 00 00 	lea    0x253d(%rip),%rsi        # d240 <_IO_stdin_used+0x240>
    ad03:	48 8d 05 35 25 00 00 	lea    0x2535(%rip),%rax        # d23f <_IO_stdin_used+0x23f>
    ad0a:	4c 89 e7             	mov    %r12,%rdi
    ad0d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    ad11:	48 0f 46 f0          	cmovbe %rax,%rsi
    ad15:	e8 c6 86 ff ff       	call   33e0 <strcpy@plt>
    ad1a:	e9 71 f2 ff ff       	jmp    9f90 <fwp_write+0x80>
    ad1f:	90                   	nop
    ad20:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ad24:	48 8d 35 15 25 00 00 	lea    0x2515(%rip),%rsi        # d240 <_IO_stdin_used+0x240>
    ad2b:	48 8d 05 0d 25 00 00 	lea    0x250d(%rip),%rax        # d23f <_IO_stdin_used+0x23f>
    ad32:	0f 2f c8             	comiss %xmm0,%xmm1
    ad35:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ad3c:	00 
    ad3d:	4c 89 e7             	mov    %r12,%rdi
    ad40:	48 0f 46 f0          	cmovbe %rax,%rsi
    ad44:	e8 97 86 ff ff       	call   33e0 <strcpy@plt>
    ad49:	e9 42 f2 ff ff       	jmp    9f90 <fwp_write+0x80>
    ad4e:	66 90                	xchg   %ax,%ax
    ad50:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    ad55:	45 85 c0             	test   %r8d,%r8d
    ad58:	75 34                	jne    ad8e <fwp_write+0xe7e>
    ad5a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    ad61:	00 
    ad62:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ad69:	00 00 
    ad6b:	0f 85 74 f6 ff ff    	jne    a3e5 <fwp_write+0x4d5>
    ad71:	ba 02 00 00 00       	mov    $0x2,%edx
    ad76:	48 8d 35 3e 25 00 00 	lea    0x253e(%rip),%rsi        # d2bb <_IO_stdin_used+0x2bb>
    ad7d:	e9 a1 f3 ff ff       	jmp    a123 <fwp_write+0x213>
    ad82:	48 03 75 10          	add    0x10(%rbp),%rsi
    ad86:	49 89 f0             	mov    %rsi,%r8
    ad89:	e9 e5 fc ff ff       	jmp    aa73 <fwp_write+0xb63>
    ad8e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ad93:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ad98:	85 ff                	test   %edi,%edi
    ad9a:	0f 84 fa f3 ff ff    	je     a19a <fwp_write+0x28a>
    ada0:	ba 01 00 00 00       	mov    $0x1,%edx
    ada5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    adaa:	48 89 df             	mov    %rbx,%rdi
    adad:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    adb2:	e8 39 93 ff ff       	call   40f0 <buf_put>
    adb7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    adbc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    adc1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    adc7:	85 c0                	test   %eax,%eax
    adc9:	0f 8f f0 f3 ff ff    	jg     a1bf <fwp_write+0x2af>
    adcf:	e9 34 f4 ff ff       	jmp    a208 <fwp_write+0x2f8>
    add4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    add8:	49 89 c5             	mov    %rax,%r13
    addb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ade0:	49 89 c4             	mov    %rax,%r12
    ade3:	49 c1 fd 3f          	sar    $0x3f,%r13
    ade7:	4c 09 e8             	or     %r13,%rax
    adea:	0f 84 a7 00 00 00    	je     ae97 <fwp_write+0xf87>
    adf0:	48 8d 2d 29 46 00 00 	lea    0x4629(%rip),%rbp        # f420 <units.1>
    adf7:	4d 89 e7             	mov    %r12,%r15
    adfa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    adfe:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ae03:	4c 89 ff             	mov    %r15,%rdi
    ae06:	4c 89 ee             	mov    %r13,%rsi
    ae09:	44 89 0c 24          	mov    %r9d,(%rsp)
    ae0d:	48 99                	cqto
    ae0f:	48 89 d1             	mov    %rdx,%rcx
    ae12:	48 89 c2             	mov    %rax,%rdx
    ae15:	e8 06 10 00 00       	call   be20 <__divmodti4>
    ae1a:	44 8b 0c 24          	mov    (%rsp),%r9d
    ae1e:	48 89 c1             	mov    %rax,%rcx
    ae21:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ae26:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    ae2b:	0f 84 94 00 00 00    	je     aec5 <fwp_write+0xfb5>
    ae31:	41 83 c1 01          	add    $0x1,%r9d
    ae35:	48 83 c5 10          	add    $0x10,%rbp
    ae39:	41 83 f9 05          	cmp    $0x5,%r9d
    ae3d:	75 bb                	jne    adfa <fwp_write+0xeea>
    ae3f:	4d 85 ed             	test   %r13,%r13
    ae42:	79 53                	jns    ae97 <fwp_write+0xf87>
    ae44:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ae49:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ae4e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ae53:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae58:	48 99                	cqto
    ae5a:	48 f7 d8             	neg    %rax
    ae5d:	48 83 d2 00          	adc    $0x0,%rdx
    ae61:	48 89 c6             	mov    %rax,%rsi
    ae64:	48 f7 da             	neg    %rdx
    ae67:	e8 d4 8b ff ff       	call   3a40 <fwp_fmt_u128>
    ae6c:	49 89 e8             	mov    %rbp,%r8
    ae6f:	ba 00 02 00 00       	mov    $0x200,%edx
    ae74:	be 02 00 00 00       	mov    $0x2,%esi
    ae79:	31 c0                	xor    %eax,%eax
    ae7b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae82:	00 
    ae83:	48 8d 0d 2c 24 00 00 	lea    0x242c(%rip),%rcx        # d2b6 <_IO_stdin_used+0x2b6>
    ae8a:	4c 89 e7             	mov    %r12,%rdi
    ae8d:	e8 2e 88 ff ff       	call   36c0 <__sprintf_chk@plt>
    ae92:	e9 f9 f0 ff ff       	jmp    9f90 <fwp_write+0x80>
    ae97:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae9c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    aea1:	31 d2                	xor    %edx,%edx
    aea3:	48 89 ef             	mov    %rbp,%rdi
    aea6:	e8 95 8b ff ff       	call   3a40 <fwp_fmt_u128>
    aeab:	eb bf                	jmp    ae6c <fwp_write+0xf5c>
    aead:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    aeb4:	4e 61 4e 00 
    aeb8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aebf:	00 
    aec0:	e9 cb f0 ff ff       	jmp    9f90 <fwp_write+0x80>
    aec5:	44 89 0c 24          	mov    %r9d,(%rsp)
    aec9:	48 89 c8             	mov    %rcx,%rax
    aecc:	48 85 d2             	test   %rdx,%rdx
    aecf:	78 51                	js     af22 <fwp_write+0x1012>
    aed1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aed6:	48 89 c6             	mov    %rax,%rsi
    aed9:	48 89 ef             	mov    %rbp,%rdi
    aedc:	e8 5f 8b ff ff       	call   3a40 <fwp_fmt_u128>
    aee1:	44 8b 0c 24          	mov    (%rsp),%r9d
    aee5:	49 63 c1             	movslq %r9d,%rax
    aee8:	49 89 e8             	mov    %rbp,%r8
    aeeb:	ba 00 02 00 00       	mov    $0x200,%edx
    aef0:	be 02 00 00 00       	mov    $0x2,%esi
    aef5:	48 c1 e0 04          	shl    $0x4,%rax
    aef9:	48 8d 3d 20 45 00 00 	lea    0x4520(%rip),%rdi        # f420 <units.1>
    af00:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    af07:	00 
    af08:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    af0c:	48 8d 0d 9e 23 00 00 	lea    0x239e(%rip),%rcx        # d2b1 <_IO_stdin_used+0x2b1>
    af13:	4c 89 e7             	mov    %r12,%rdi
    af16:	31 c0                	xor    %eax,%eax
    af18:	e8 a3 87 ff ff       	call   36c0 <__sprintf_chk@plt>
    af1d:	e9 6e f0 ff ff       	jmp    9f90 <fwp_write+0x80>
    af22:	48 f7 d8             	neg    %rax
    af25:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    af2a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    af2f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    af34:	48 83 d2 00          	adc    $0x0,%rdx
    af38:	48 89 c6             	mov    %rax,%rsi
    af3b:	48 f7 da             	neg    %rdx
    af3e:	e8 fd 8a ff ff       	call   3a40 <fwp_fmt_u128>
    af43:	44 8b 0c 24          	mov    (%rsp),%r9d
    af47:	eb 9c                	jmp    aee5 <fwp_write+0xfd5>
    af49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000af50 <fwp_main_thread>:
    af50:	f3 0f 1e fa          	endbr64
    af54:	41 57                	push   %r15
    af56:	41 56                	push   %r14
    af58:	41 55                	push   %r13
    af5a:	41 54                	push   %r12
    af5c:	55                   	push   %rbp
    af5d:	53                   	push   %rbx
    af5e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    af65:	8b 3d 59 fc 05 00    	mov    0x5fc59(%rip),%edi        # 6abc4 <fwp_heap+0x13a4>
    af6b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    af72:	00 00 
    af74:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    af7b:	00 
    af7c:	31 c0                	xor    %eax,%eax
    af7e:	85 ff                	test   %edi,%edi
    af80:	0f 84 1a 07 00 00    	je     b6a0 <fwp_main_thread+0x750>
    af86:	8b 35 3c fc 05 00    	mov    0x5fc3c(%rip),%esi        # 6abc8 <fwp_heap+0x13a8>
    af8c:	85 f6                	test   %esi,%esi
    af8e:	0f 85 1f 07 00 00    	jne    b6b3 <fwp_main_thread+0x763>
    af94:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    af99:	48 8d 5c 24 20       	lea    0x20(%rsp),%rbx
    af9e:	31 f6                	xor    %esi,%esi
    afa0:	48 c7 05 15 e2 05 00 	movq   $0x40000000,0x5e215(%rip)        # 691c0 <fwp_main_stack_size>
    afa7:	00 00 00 40 
    afab:	48 8d 05 ce 60 00 00 	lea    0x60ce(%rip),%rax        # 11080 <alt.5>
    afb2:	48 89 ef             	mov    %rbp,%rdi
    afb5:	48 89 1d 0c e2 05 00 	mov    %rbx,0x5e20c(%rip)        # 691c8 <fwp_main_stack_top>
    afbc:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    afc1:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    afc8:	01 00 
    afca:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    afd1:	00 
    afd2:	e8 c9 86 ff ff       	call   36a0 <sigaltstack@plt>
    afd7:	85 c0                	test   %eax,%eax
    afd9:	0f 85 fc 0d 00 00    	jne    bddb <fwp_main_thread+0xe8b>
    afdf:	31 c0                	xor    %eax,%eax
    afe1:	b9 12 00 00 00       	mov    $0x12,%ecx
    afe6:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    afed:	00 
    afee:	f3 48 ab             	rep stos %rax,(%rdi)
    aff1:	48 8d 05 48 8d ff ff 	lea    -0x72b8(%rip),%rax        # 3d40 <fwp_segv>
    aff8:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    afff:	00 
    b000:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    b007:	04 00 00 08 
    b00b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b012:	00 
    b013:	4c 8d ac 24 80 00 00 	lea    0x80(%rsp),%r13
    b01a:	00 
    b01b:	e8 40 85 ff ff       	call   3560 <sigemptyset@plt>
    b020:	85 c0                	test   %eax,%eax
    b022:	0f 85 b3 0d 00 00    	jne    bddb <fwp_main_thread+0xe8b>
    b028:	31 d2                	xor    %edx,%edx
    b02a:	4c 89 ee             	mov    %r13,%rsi
    b02d:	bf 0b 00 00 00       	mov    $0xb,%edi
    b032:	e8 b9 83 ff ff       	call   33f0 <sigaction@plt>
    b037:	85 c0                	test   %eax,%eax
    b039:	0f 85 9c 0d 00 00    	jne    bddb <fwp_main_thread+0xe8b>
    b03f:	31 d2                	xor    %edx,%edx
    b041:	4c 89 ee             	mov    %r13,%rsi
    b044:	bf 07 00 00 00       	mov    $0x7,%edi
    b049:	e8 a2 83 ff ff       	call   33f0 <sigaction@plt>
    b04e:	85 c0                	test   %eax,%eax
    b050:	0f 85 85 0d 00 00    	jne    bddb <fwp_main_thread+0xe8b>
    b056:	48 8b 05 e3 fb 05 00 	mov    0x5fbe3(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    b05d:	48 85 c0             	test   %rax,%rax
    b060:	0f 88 1a 06 00 00    	js     b680 <fwp_main_thread+0x730>
    b066:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b06a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b06f:	48 8d 3d aa 91 ff ff 	lea    -0x6e56(%rip),%rdi        # 4220 <ad_raw_report>
    b076:	f2 0f 11 05 4a 04 06 	movsd  %xmm0,0x6044a(%rip)        # 6b4c8 <iteration_start_charge>
    b07d:	00 
    b07e:	c7 05 60 04 06 00 01 	movl   $0x1,0x60460(%rip)        # 6b4e8 <iteration_active>
    b085:	00 00 00 
    b088:	e8 a3 0f 00 00       	call   c030 <atexit>
    b08d:	85 c0                	test   %eax,%eax
    b08f:	0f 85 52 0d 00 00    	jne    bde7 <fwp_main_thread+0xe97>
    b095:	8b 0d d5 5f 00 00    	mov    0x5fd5(%rip),%ecx        # 11070 <st.3>
    b09b:	85 c9                	test   %ecx,%ecx
    b09d:	0f 84 25 06 00 00    	je     b6c8 <fwp_main_thread+0x778>
    b0a3:	48 8b 2d 56 e7 05 00 	mov    0x5e756(%rip),%rbp        # 69800 <fwp_cur>
    b0aa:	48 85 ed             	test   %rbp,%rbp
    b0ad:	0f 84 bd 01 00 00    	je     b270 <fwp_main_thread+0x320>
    b0b3:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    b0b8:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    b0bc:	48 89 eb             	mov    %rbp,%rbx
    b0bf:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b0c4:	0f 84 41 01 00 00    	je     b20b <fwp_main_thread+0x2bb>
    b0ca:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    b0cf:	0f 84 9b 02 00 00    	je     b370 <fwp_main_thread+0x420>
    b0d5:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b0d9:	0f 84 71 02 00 00    	je     b350 <fwp_main_thread+0x400>
    b0df:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b0e3:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b0e7:	0f 85 03 03 00 00    	jne    b3f0 <fwp_main_thread+0x4a0>
    b0ed:	48 8b 43 60          	mov    0x60(%rbx),%rax
    b0f1:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b0f8:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b0fc:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b103:	00 00 00 00 
    b107:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b10e:	48 85 d2             	test   %rdx,%rdx
    b111:	74 07                	je     b11a <fwp_main_thread+0x1ca>
    b113:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b11a:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b11e:	48 85 c0             	test   %rax,%rax
    b121:	74 34                	je     b157 <fwp_main_thread+0x207>
    b123:	48 89 43 68          	mov    %rax,0x68(%rbx)
    b127:	48 8b 05 aa e6 05 00 	mov    0x5e6aa(%rip),%rax        # 697d8 <fwp_timers>
    b12e:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    b132:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    b139:	00 00 00 00 
    b13d:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    b144:	48 85 c0             	test   %rax,%rax
    b147:	74 07                	je     b150 <fwp_main_thread+0x200>
    b149:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    b150:	48 89 1d 81 e6 05 00 	mov    %rbx,0x5e681(%rip)        # 697d8 <fwp_timers>
    b157:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    b15b:	e8 30 c9 ff ff       	call   7a90 <fwp_block>
    b160:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    b167:	48 85 c9             	test   %rcx,%rcx
    b16a:	74 47                	je     b1b3 <fwp_main_thread+0x263>
    b16c:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    b173:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b17a:	48 85 d2             	test   %rdx,%rdx
    b17d:	0f 84 ad 02 00 00    	je     b430 <fwp_main_thread+0x4e0>
    b183:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    b18a:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b191:	48 85 c0             	test   %rax,%rax
    b194:	74 07                	je     b19d <fwp_main_thread+0x24d>
    b196:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    b19d:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    b1a4:	00 00 00 00 
    b1a8:	66 0f ef d2          	pxor   %xmm2,%xmm2
    b1ac:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    b1b3:	48 8b 0d 46 e6 05 00 	mov    0x5e646(%rip),%rcx        # 69800 <fwp_cur>
    b1ba:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    b1be:	0f 84 1c 02 00 00    	je     b3e0 <fwp_main_thread+0x490>
    b1c4:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    b1cb:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    b1d2:	48 85 d2             	test   %rdx,%rdx
    b1d5:	0f 84 95 04 00 00    	je     b670 <fwp_main_thread+0x720>
    b1db:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    b1e2:	48 85 c0             	test   %rax,%rax
    b1e5:	74 07                	je     b1ee <fwp_main_thread+0x29e>
    b1e7:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    b1ee:	66 0f ef db          	pxor   %xmm3,%xmm3
    b1f2:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    b1f6:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    b1fd:	48 89 cb             	mov    %rcx,%rbx
    b200:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b205:	0f 85 bf fe ff ff    	jne    b0ca <fwp_main_thread+0x17a>
    b20b:	48 83 3d 85 02 06 00 	cmpq   $0x0,0x60285(%rip)        # 6b498 <fwp_state_len>
    b212:	00 
    b213:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    b217:	74 67                	je     b280 <fwp_main_thread+0x330>
    b219:	48 39 1d d8 e5 05 00 	cmp    %rbx,0x5e5d8(%rip)        # 697f8 <fwp_root>
    b220:	c7 05 56 5e 01 00 00 	movl   $0x0,0x15e56(%rip)        # 21080 <fwp_exit_code>
    b227:	00 00 00 
    b22a:	0f 85 e5 0b 00 00    	jne    be15 <fwp_main_thread+0xec5>
    b230:	48 85 db             	test   %rbx,%rbx
    b233:	0f 84 1f 02 00 00    	je     b458 <fwp_main_thread+0x508>
    b239:	48 8b 15 88 e5 05 00 	mov    0x5e588(%rip),%rdx        # 697c8 <fwp_tasks_active>
    b240:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    b244:	48 85 d2             	test   %rdx,%rdx
    b247:	0f 84 0b 02 00 00    	je     b458 <fwp_main_thread+0x508>
    b24d:	0f 1f 00             	nopl   (%rax)
    b250:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    b254:	75 08                	jne    b25e <fwp_main_thread+0x30e>
    b256:	48 89 d7             	mov    %rdx,%rdi
    b259:	e8 d2 8e ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b25e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    b265:	48 85 d2             	test   %rdx,%rdx
    b268:	75 e6                	jne    b250 <fwp_main_thread+0x300>
    b26a:	e9 ae 00 00 00       	jmp    b31d <fwp_main_thread+0x3cd>
    b26f:	90                   	nop
    b270:	48 83 3d 20 02 06 00 	cmpq   $0x0,0x60220(%rip)        # 6b498 <fwp_state_len>
    b277:	00 
    b278:	0f 85 c2 01 00 00    	jne    b440 <fwp_main_thread+0x4f0>
    b27e:	31 db                	xor    %ebx,%ebx
    b280:	48 83 3d 00 02 06 00 	cmpq   $0x0,0x60200(%rip)        # 6b488 <fwp_state_owners>
    b287:	00 
    b288:	75 8f                	jne    b219 <fwp_main_thread+0x2c9>
    b28a:	48 8b 3d 0f 02 06 00 	mov    0x6020f(%rip),%rdi        # 6b4a0 <fwp_state>
    b291:	e8 7a a7 ff ff       	call   5a10 <fwp_mem_free>
    b296:	48 c7 05 ff 01 06 00 	movq   $0x0,0x601ff(%rip)        # 6b4a0 <fwp_state>
    b29d:	00 00 00 00 
    b2a1:	48 c7 05 e4 01 06 00 	movq   $0x0,0x601e4(%rip)        # 6b490 <fwp_state_cap>
    b2a8:	00 00 00 00 
    b2ac:	48 85 db             	test   %rbx,%rbx
    b2af:	0f 84 2d 0a 00 00    	je     bce2 <fwp_main_thread+0xd92>
    b2b5:	48 39 1d 3c e5 05 00 	cmp    %rbx,0x5e53c(%rip)        # 697f8 <fwp_root>
    b2bc:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b2c3:	00 00 00 00 
    b2c7:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b2ce:	00 00 00 00 
    b2d2:	c7 05 a4 5d 01 00 00 	movl   $0x0,0x15da4(%rip)        # 21080 <fwp_exit_code>
    b2d9:	00 00 00 
    b2dc:	0f 84 57 ff ff ff    	je     b239 <fwp_main_thread+0x2e9>
    b2e2:	e9 69 84 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b2e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b2ee:	00 00 
    b2f0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b2f7:	48 89 1d e2 e4 05 00 	mov    %rbx,0x5e4e2(%rip)        # 697e0 <fwp_ready_tail>
    b2fe:	e8 8d c7 ff ff       	call   7a90 <fwp_block>
    b303:	e8 88 c5 ff ff       	call   7890 <fwp_free_zombie>
    b308:	48 83 3d b8 e4 05 00 	cmpq   $0x0,0x5e4b8(%rip)        # 697c8 <fwp_tasks_active>
    b30f:	00 
    b310:	0f 84 42 01 00 00    	je     b458 <fwp_main_thread+0x508>
    b316:	48 8b 1d db e4 05 00 	mov    0x5e4db(%rip),%rbx        # 697f8 <fwp_root>
    b31d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b321:	75 db                	jne    b2fe <fwp_main_thread+0x3ae>
    b323:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b327:	75 d5                	jne    b2fe <fwp_main_thread+0x3ae>
    b329:	48 8b 05 b0 e4 05 00 	mov    0x5e4b0(%rip),%rax        # 697e0 <fwp_ready_tail>
    b330:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b334:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b33b:	00 00 00 00 
    b33f:	48 85 c0             	test   %rax,%rax
    b342:	75 ac                	jne    b2f0 <fwp_main_thread+0x3a0>
    b344:	48 89 1d 9d e4 05 00 	mov    %rbx,0x5e49d(%rip)        # 697e8 <fwp_ready_head>
    b34b:	eb aa                	jmp    b2f7 <fwp_main_thread+0x3a7>
    b34d:	0f 1f 00             	nopl   (%rax)
    b350:	e8 6b 92 ff ff       	call   45c0 <fwp_now_ns>
    b355:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    b359:	7c 15                	jl     b370 <fwp_main_thread+0x420>
    b35b:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b35f:	75 0f                	jne    b370 <fwp_main_thread+0x420>
    b361:	48 89 ef             	mov    %rbp,%rdi
    b364:	e8 c7 8d ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b370:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b374:	0f 85 65 fd ff ff    	jne    b0df <fwp_main_thread+0x18f>
    b37a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b37e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b382:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b386:	0f 85 65 fd ff ff    	jne    b0f1 <fwp_main_thread+0x1a1>
    b38c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b390:	48 85 c9             	test   %rcx,%rcx
    b393:	0f 84 58 fd ff ff    	je     b0f1 <fwp_main_thread+0x1a1>
    b399:	48 39 c8             	cmp    %rcx,%rax
    b39c:	48 89 ce             	mov    %rcx,%rsi
    b39f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b3a6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b3aa:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b3b1:	00 00 00 00 
    b3b5:	48 0f 4e f0          	cmovle %rax,%rsi
    b3b9:	48 85 c0             	test   %rax,%rax
    b3bc:	48 89 c8             	mov    %rcx,%rax
    b3bf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b3c6:	48 0f 45 c6          	cmovne %rsi,%rax
    b3ca:	48 85 d2             	test   %rdx,%rdx
    b3cd:	74 07                	je     b3d6 <fwp_main_thread+0x486>
    b3cf:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b3d6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b3da:	e9 44 fd ff ff       	jmp    b123 <fwp_main_thread+0x1d3>
    b3df:	90                   	nop
    b3e0:	48 89 cb             	mov    %rcx,%rbx
    b3e3:	e9 d7 fc ff ff       	jmp    b0bf <fwp_main_thread+0x16f>
    b3e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b3ef:	00 
    b3f0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b3f4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b3fb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b402:	00 00 00 00 
    b406:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b40d:	48 85 c0             	test   %rax,%rax
    b410:	0f 84 4a 08 00 00    	je     bc60 <fwp_main_thread+0xd10>
    b416:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b41d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b421:	e9 31 fd ff ff       	jmp    b157 <fwp_main_thread+0x207>
    b426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b42d:	00 00 00 
    b430:	48 89 01             	mov    %rax,(%rcx)
    b433:	e9 59 fd ff ff       	jmp    b191 <fwp_main_thread+0x241>
    b438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b43f:	00 
    b440:	48 83 3d b0 e3 05 00 	cmpq   $0x0,0x5e3b0(%rip)        # 697f8 <fwp_root>
    b447:	00 
    b448:	c7 05 2e 5c 01 00 00 	movl   $0x0,0x15c2e(%rip)        # 21080 <fwp_exit_code>
    b44f:	00 00 00 
    b452:	0f 85 b8 09 00 00    	jne    be10 <fwp_main_thread+0xec0>
    b458:	e8 33 c4 ff ff       	call   7890 <fwp_free_zombie>
    b45d:	48 83 3d 83 e3 05 00 	cmpq   $0x0,0x5e383(%rip)        # 697e8 <fwp_ready_head>
    b464:	00 
    b465:	0f 85 e5 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b46b:	48 83 3d 65 e3 05 00 	cmpq   $0x0,0x5e365(%rip)        # 697d8 <fwp_timers>
    b472:	00 
    b473:	0f 85 d7 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b479:	8b 05 55 dd 05 00    	mov    0x5dd55(%rip),%eax        # 691d4 <fwp_stack_pool_n>
    b47f:	85 c0                	test   %eax,%eax
    b481:	74 3a                	je     b4bd <fwp_main_thread+0x56d>
    b483:	83 e8 01             	sub    $0x1,%eax
    b486:	4c 8d 25 53 dd 05 00 	lea    0x5dd53(%rip),%r12        # 691e0 <fwp_stack_pool>
    b48d:	48 63 d8             	movslq %eax,%rbx
    b490:	89 c0                	mov    %eax,%eax
    b492:	48 89 da             	mov    %rbx,%rdx
    b495:	48 29 c2             	sub    %rax,%rdx
    b498:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    b49c:	0f 1f 40 00          	nopl   0x0(%rax)
    b4a0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b4a4:	89 1d 2a dd 05 00    	mov    %ebx,0x5dd2a(%rip)        # 691d4 <fwp_stack_pool_n>
    b4aa:	be 00 00 00 10       	mov    $0x10000000,%esi
    b4af:	48 83 eb 01          	sub    $0x1,%rbx
    b4b3:	e8 08 81 ff ff       	call   35c0 <munmap@plt>
    b4b8:	48 39 dd             	cmp    %rbx,%rbp
    b4bb:	75 e3                	jne    b4a0 <fwp_main_thread+0x550>
    b4bd:	8b 3d 55 5b 00 00    	mov    0x5b55(%rip),%edi        # 11018 <fwp_epfd>
    b4c3:	85 ff                	test   %edi,%edi
    b4c5:	78 05                	js     b4cc <fwp_main_thread+0x57c>
    b4c7:	e8 f4 7f ff ff       	call   34c0 <close@plt>
    b4cc:	4c 8b 25 0d df 05 00 	mov    0x5df0d(%rip),%r12        # 693e0 <fwp_nfdws>
    b4d3:	48 8b 2d 0e df 05 00 	mov    0x5df0e(%rip),%rbp        # 693e8 <fwp_fdws>
    b4da:	31 db                	xor    %ebx,%ebx
    b4dc:	c7 05 32 5b 00 00 ff 	movl   $0xffffffff,0x5b32(%rip)        # 11018 <fwp_epfd>
    b4e3:	ff ff ff 
    b4e6:	4d 85 e4             	test   %r12,%r12
    b4e9:	74 32                	je     b51d <fwp_main_thread+0x5cd>
    b4eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b4f0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b4f5:	48 85 ff             	test   %rdi,%rdi
    b4f8:	74 1a                	je     b514 <fwp_main_thread+0x5c4>
    b4fa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b4fe:	0f 85 4c 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b504:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b509:	0f 85 41 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b50f:	e8 fc a4 ff ff       	call   5a10 <fwp_mem_free>
    b514:	48 83 c3 01          	add    $0x1,%rbx
    b518:	49 39 dc             	cmp    %rbx,%r12
    b51b:	75 d3                	jne    b4f0 <fwp_main_thread+0x5a0>
    b51d:	48 89 ef             	mov    %rbp,%rdi
    b520:	e8 eb a4 ff ff       	call   5a10 <fwp_mem_free>
    b525:	48 8b 15 cc e2 05 00 	mov    0x5e2cc(%rip),%rdx        # 697f8 <fwp_root>
    b52c:	48 c7 05 b1 de 05 00 	movq   $0x0,0x5deb1(%rip)        # 693e8 <fwp_fdws>
    b533:	00 00 00 00 
    b537:	48 c7 05 9e de 05 00 	movq   $0x0,0x5de9e(%rip)        # 693e0 <fwp_nfdws>
    b53e:	00 00 00 00 
    b542:	48 85 d2             	test   %rdx,%rdx
    b545:	74 4e                	je     b595 <fwp_main_thread+0x645>
    b547:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b54c:	0f 85 fe 81 ff ff    	jne    3750 <fwp_main_thread.cold>
    b552:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b559:	00 
    b55a:	0f 85 f0 81 ff ff    	jne    3750 <fwp_main_thread.cold>
    b560:	48 83 3d 30 ff 05 00 	cmpq   $0x0,0x5ff30(%rip)        # 6b498 <fwp_state_len>
    b567:	00 
    b568:	0f 85 e2 81 ff ff    	jne    3750 <fwp_main_thread.cold>
    b56e:	48 83 3d 12 ff 05 00 	cmpq   $0x0,0x5ff12(%rip)        # 6b488 <fwp_state_owners>
    b575:	00 
    b576:	0f 85 d4 81 ff ff    	jne    3750 <fwp_main_thread.cold>
    b57c:	b9 79 00 00 00       	mov    $0x79,%ecx
    b581:	31 c0                	xor    %eax,%eax
    b583:	48 8d 3d 76 de 05 00 	lea    0x5de76(%rip),%rdi        # 69400 <fwp_root_context>
    b58a:	f3 48 ab             	rep stos %rax,(%rdi)
    b58d:	48 89 d7             	mov    %rdx,%rdi
    b590:	e8 7b a4 ff ff       	call   5a10 <fwp_mem_free>
    b595:	66 0f 6f 05 13 5c 04 	movdqa 0x45c13(%rip),%xmm0        # 511b0 <ad_raw_live+0x10>
    b59c:	00 
    b59d:	66 0f d4 05 fb 5b 04 	paddq  0x45bfb(%rip),%xmm0        # 511a0 <ad_raw_live>
    b5a4:	00 
    b5a5:	48 c7 05 50 e2 05 00 	movq   $0x0,0x5e250(%rip)        # 69800 <fwp_cur>
    b5ac:	00 00 00 00 
    b5b0:	48 8b 05 89 f6 05 00 	mov    0x5f689(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    b5b7:	48 c7 05 36 e2 05 00 	movq   $0x0,0x5e236(%rip)        # 697f8 <fwp_root>
    b5be:	00 00 00 00 
    b5c2:	c7 05 1c ff 05 00 00 	movl   $0x0,0x5ff1c(%rip)        # 6b4e8 <iteration_active>
    b5c9:	00 00 00 
    b5cc:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    b5d0:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    b5d5:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    b5d9:	66 0f d6 05 17 5b 01 	movq   %xmm0,0x15b17(%rip)        # 210f8 <ad_raw_before_shutdown>
    b5e0:	00 
    b5e1:	48 85 c0             	test   %rax,%rax
    b5e4:	0f 88 56 06 00 00    	js     bc40 <fwp_main_thread+0xcf0>
    b5ea:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b5ee:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    b5f3:	f2 0f 5c 0d cd fe 05 	subsd  0x5fecd(%rip),%xmm1        # 6b4c8 <iteration_start_charge>
    b5fa:	00 
    b5fb:	48 8b 3d 3e 5a 00 00 	mov    0x5a3e(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    b602:	48 8d 15 57 25 00 00 	lea    0x2557(%rip),%rdx        # db60 <_IO_stdin_used+0xb60>
    b609:	be 02 00 00 00       	mov    $0x2,%esi
    b60e:	f2 0f 10 05 aa fe 05 	movsd  0x5feaa(%rip),%xmm0        # 6b4c0 <iteration_peak>
    b615:	00 
    b616:	4c 8b 0d b3 fe 05 00 	mov    0x5feb3(%rip),%r9        # 6b4d0 <iteration_retains>
    b61d:	b8 02 00 00 00       	mov    $0x2,%eax
    b622:	4c 8b 05 af fe 05 00 	mov    0x5feaf(%rip),%r8        # 6b4d8 <iteration_bytes>
    b629:	48 8b 0d b0 fe 05 00 	mov    0x5feb0(%rip),%rcx        # 6b4e0 <iteration_requests>
    b630:	e8 3b 80 ff ff       	call   3670 <__fprintf_chk@plt>
    b635:	48 8b 3d e4 59 00 00 	mov    0x59e4(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    b63c:	e8 5f 7f ff ff       	call   35a0 <fflush@plt>
    b641:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b648:	00 
    b649:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b650:	00 00 
    b652:	0f 85 a7 07 00 00    	jne    bdff <fwp_main_thread+0xeaf>
    b658:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b65f:	31 c0                	xor    %eax,%eax
    b661:	5b                   	pop    %rbx
    b662:	5d                   	pop    %rbp
    b663:	41 5c                	pop    %r12
    b665:	41 5d                	pop    %r13
    b667:	41 5e                	pop    %r14
    b669:	41 5f                	pop    %r15
    b66b:	c3                   	ret
    b66c:	0f 1f 40 00          	nopl   0x0(%rax)
    b670:	48 89 05 61 e1 05 00 	mov    %rax,0x5e161(%rip)        # 697d8 <fwp_timers>
    b677:	e9 66 fb ff ff       	jmp    b1e2 <fwp_main_thread+0x292>
    b67c:	0f 1f 40 00          	nopl   0x0(%rax)
    b680:	48 89 c2             	mov    %rax,%rdx
    b683:	83 e0 01             	and    $0x1,%eax
    b686:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b68a:	48 d1 ea             	shr    $1,%rdx
    b68d:	48 09 c2             	or     %rax,%rdx
    b690:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    b695:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    b699:	e9 d1 f9 ff ff       	jmp    b06f <fwp_main_thread+0x11f>
    b69e:	66 90                	xchg   %ax,%ax
    b6a0:	e8 2b 97 ff ff       	call   4dd0 <fwp_heap_init>
    b6a5:	8b 35 1d f5 05 00    	mov    0x5f51d(%rip),%esi        # 6abc8 <fwp_heap+0x13a8>
    b6ab:	85 f6                	test   %esi,%esi
    b6ad:	0f 84 e1 f8 ff ff    	je     af94 <fwp_main_thread+0x44>
    b6b3:	48 8d 3d 06 96 ff ff 	lea    -0x69fa(%rip),%rdi        # 4cc0 <fwp_heap_report>
    b6ba:	e8 71 09 00 00       	call   c030 <atexit>
    b6bf:	e9 d0 f8 ff ff       	jmp    af94 <fwp_main_thread+0x44>
    b6c4:	0f 1f 40 00          	nopl   0x0(%rax)
    b6c8:	48 8d 05 e1 ba ff ff 	lea    -0x451f(%rip),%rax        # 71b0 <fwp_drop1>
    b6cf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b6d3:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b6da:	00 00 
    b6dc:	41 be ff 7f 00 00    	mov    $0x7fff,%r14d
    b6e2:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b6e7:	48 8b 05 ca fd 05 00 	mov    0x5fdca(%rip),%rax        # 6b4b8 <fwp_cleanups>
    b6ee:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
    b6f3:	4c 8d 25 26 e1 05 00 	lea    0x5e126(%rip),%r12        # 69820 <fwp_heap>
    b6fa:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b6fe:	48 89 1d b3 fd 05 00 	mov    %rbx,0x5fdb3(%rip)        # 6b4b8 <fwp_cleanups>
    b705:	31 db                	xor    %ebx,%ebx
    b707:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b70c:	48 8d 05 bd 84 ff ff 	lea    -0x7b43(%rip),%rax        # 3bd0 <fwp_range_release>
    b713:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b718:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b71d:	eb 3b                	jmp    b75a <fwp_main_thread+0x80a>
    b71f:	90                   	nop
    b720:	40 80 fe 01          	cmp    $0x1,%sil
    b724:	75 25                	jne    b74b <fwp_main_thread+0x7fb>
    b726:	8b 71 18             	mov    0x18(%rcx),%esi
    b729:	0f b7 c0             	movzwl %ax,%eax
    b72c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b72f:	48 0f af c6          	imul   %rsi,%rax
    b733:	48 c1 e8 20          	shr    $0x20,%rax
    b737:	48 39 c8             	cmp    %rcx,%rax
    b73a:	73 0f                	jae    b74b <fwp_main_thread+0x7fb>
    b73c:	48 01 c2             	add    %rax,%rdx
    b73f:	80 3a ff             	cmpb   $0xff,(%rdx)
    b742:	0f 84 68 05 00 00    	je     bcb0 <fwp_main_thread+0xd60>
    b748:	c6 02 01             	movb   $0x1,(%rdx)
    b74b:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    b750:	49 83 ee 01          	sub    $0x1,%r14
    b754:	0f 82 86 00 00 00    	jb     b7e0 <fwp_main_thread+0x890>
    b75a:	4c 89 ee             	mov    %r13,%rsi
    b75d:	bf 01 00 00 00       	mov    $0x1,%edi
    b762:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
    b769:	00 
    b76a:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
    b76f:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
    b776:	00 
    b777:	e8 14 b3 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    b77c:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b783:	00 
    b784:	48 89 c3             	mov    %rax,%rbx
    b787:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b78e:	00 
    b78f:	48 c1 e2 10          	shl    $0x10,%rdx
    b793:	48 39 d0             	cmp    %rdx,%rax
    b796:	73 b3                	jae    b74b <fwp_main_thread+0x7fb>
    b798:	48 89 c2             	mov    %rax,%rdx
    b79b:	48 c1 ea 10          	shr    $0x10,%rdx
    b79f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7a3:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b7aa:	00 
    b7ab:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    b7af:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    b7b3:	48 85 d2             	test   %rdx,%rdx
    b7b6:	74 93                	je     b74b <fwp_main_thread+0x7fb>
    b7b8:	0f b6 31             	movzbl (%rcx),%esi
    b7bb:	40 80 fe 02          	cmp    $0x2,%sil
    b7bf:	0f 85 5b ff ff ff    	jne    b720 <fwp_main_thread+0x7d0>
    b7c5:	66 85 c0             	test   %ax,%ax
    b7c8:	0f 84 71 ff ff ff    	je     b73f <fwp_main_thread+0x7ef>
    b7ce:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    b7d3:	49 83 ee 01          	sub    $0x1,%r14
    b7d7:	73 81                	jae    b75a <fwp_main_thread+0x80a>
    b7d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b7e0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b7e5:	66 0f 6f 05 e3 25 00 	movdqa 0x25e3(%rip),%xmm0        # ddd0 <msg.4+0xa0>
    b7ec:	00 
    b7ed:	4c 89 ee             	mov    %r13,%rsi
    b7f0:	bf 01 00 00 00       	mov    $0x1,%edi
    b7f5:	48 89 05 bc fc 05 00 	mov    %rax,0x5fcbc(%rip)        # 6b4b8 <fwp_cleanups>
    b7fc:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    b803:	00 
    b804:	e8 87 b2 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    b809:	48 8b 15 e8 f3 05 00 	mov    0x5f3e8(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    b810:	49 89 c6             	mov    %rax,%r14
    b813:	48 2b 05 b6 f3 05 00 	sub    0x5f3b6(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    b81a:	48 c1 e2 10          	shl    $0x10,%rdx
    b81e:	48 39 d0             	cmp    %rdx,%rax
    b821:	73 59                	jae    b87c <fwp_main_thread+0x92c>
    b823:	48 89 c2             	mov    %rax,%rdx
    b826:	48 c1 ea 10          	shr    $0x10,%rdx
    b82a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b82e:	48 8b 15 e3 f3 05 00 	mov    0x5f3e3(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    b835:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b839:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b83d:	4d 85 ed             	test   %r13,%r13
    b840:	74 3a                	je     b87c <fwp_main_thread+0x92c>
    b842:	0f b6 0a             	movzbl (%rdx),%ecx
    b845:	80 f9 02             	cmp    $0x2,%cl
    b848:	0f 84 52 04 00 00    	je     bca0 <fwp_main_thread+0xd50>
    b84e:	80 f9 01             	cmp    $0x1,%cl
    b851:	75 29                	jne    b87c <fwp_main_thread+0x92c>
    b853:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b856:	0f b7 c0             	movzwl %ax,%eax
    b859:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b85c:	48 0f af c1          	imul   %rcx,%rax
    b860:	48 c1 e8 20          	shr    $0x20,%rax
    b864:	48 39 d0             	cmp    %rdx,%rax
    b867:	73 13                	jae    b87c <fwp_main_thread+0x92c>
    b869:	49 01 c5             	add    %rax,%r13
    b86c:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b871:	0f 84 c2 04 00 00    	je     bd39 <fwp_main_thread+0xde9>
    b877:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b87c:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b881:	bf 01 00 00 00       	mov    $0x1,%edi
    b886:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b88b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b892:	00 f0 3f 
    b895:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b89a:	e8 f1 b1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    b89f:	48 8b 15 52 f3 05 00 	mov    0x5f352(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    b8a6:	49 89 c6             	mov    %rax,%r14
    b8a9:	48 2b 05 20 f3 05 00 	sub    0x5f320(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    b8b0:	48 c1 e2 10          	shl    $0x10,%rdx
    b8b4:	48 39 d0             	cmp    %rdx,%rax
    b8b7:	73 59                	jae    b912 <fwp_main_thread+0x9c2>
    b8b9:	48 89 c2             	mov    %rax,%rdx
    b8bc:	48 c1 ea 10          	shr    $0x10,%rdx
    b8c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b8c4:	48 8b 15 4d f3 05 00 	mov    0x5f34d(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    b8cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b8cf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b8d3:	4d 85 ed             	test   %r13,%r13
    b8d6:	74 3a                	je     b912 <fwp_main_thread+0x9c2>
    b8d8:	0f b6 0a             	movzbl (%rdx),%ecx
    b8db:	80 f9 02             	cmp    $0x2,%cl
    b8de:	0f 84 ac 03 00 00    	je     bc90 <fwp_main_thread+0xd40>
    b8e4:	80 f9 01             	cmp    $0x1,%cl
    b8e7:	75 29                	jne    b912 <fwp_main_thread+0x9c2>
    b8e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8ec:	0f b7 c0             	movzwl %ax,%eax
    b8ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b8f2:	48 0f af c1          	imul   %rcx,%rax
    b8f6:	48 c1 e8 20          	shr    $0x20,%rax
    b8fa:	48 39 d0             	cmp    %rdx,%rax
    b8fd:	73 13                	jae    b912 <fwp_main_thread+0x9c2>
    b8ff:	49 01 c5             	add    %rax,%r13
    b902:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b907:	0f 84 39 04 00 00    	je     bd46 <fwp_main_thread+0xdf6>
    b90d:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b912:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b917:	bf 01 00 00 00       	mov    $0x1,%edi
    b91c:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    b921:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b928:	33 f3 bf 
    b92b:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b930:	e8 5b b1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    b935:	48 8b 15 bc f2 05 00 	mov    0x5f2bc(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    b93c:	48 8b 0d 8d f2 05 00 	mov    0x5f28d(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    b943:	49 89 c5             	mov    %rax,%r13
    b946:	48 89 d6             	mov    %rdx,%rsi
    b949:	48 29 c8             	sub    %rcx,%rax
    b94c:	48 c1 e6 10          	shl    $0x10,%rsi
    b950:	48 39 f0             	cmp    %rsi,%rax
    b953:	73 67                	jae    b9bc <fwp_main_thread+0xa6c>
    b955:	48 89 c6             	mov    %rax,%rsi
    b958:	48 c1 ee 10          	shr    $0x10,%rsi
    b95c:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b960:	48 8b 35 b1 f2 05 00 	mov    0x5f2b1(%rip),%rsi        # 6ac18 <fwp_heap+0x13f8>
    b967:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b96b:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    b96f:	4d 85 f6             	test   %r14,%r14
    b972:	74 48                	je     b9bc <fwp_main_thread+0xa6c>
    b974:	0f b6 3e             	movzbl (%rsi),%edi
    b977:	40 80 ff 02          	cmp    $0x2,%dil
    b97b:	0f 84 ff 02 00 00    	je     bc80 <fwp_main_thread+0xd30>
    b981:	40 80 ff 01          	cmp    $0x1,%dil
    b985:	75 35                	jne    b9bc <fwp_main_thread+0xa6c>
    b987:	8b 7e 18             	mov    0x18(%rsi),%edi
    b98a:	0f b7 c0             	movzwl %ax,%eax
    b98d:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b990:	48 0f af c7          	imul   %rdi,%rax
    b994:	48 c1 e8 20          	shr    $0x20,%rax
    b998:	48 39 f0             	cmp    %rsi,%rax
    b99b:	73 1f                	jae    b9bc <fwp_main_thread+0xa6c>
    b99d:	49 01 c6             	add    %rax,%r14
    b9a0:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b9a4:	0f 84 a9 03 00 00    	je     bd53 <fwp_main_thread+0xe03>
    b9aa:	41 c6 06 01          	movb   $0x1,(%r14)
    b9ae:	48 8b 0d 1b f2 05 00 	mov    0x5f21b(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    b9b5:	48 8b 15 3c f2 05 00 	mov    0x5f23c(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    b9bc:	48 89 1c 24          	mov    %rbx,(%rsp)
    b9c0:	4c 89 e8             	mov    %r13,%rax
    b9c3:	48 c1 e2 10          	shl    $0x10,%rdx
    b9c7:	48 29 c8             	sub    %rcx,%rax
    b9ca:	48 39 d0             	cmp    %rdx,%rax
    b9cd:	73 70                	jae    ba3f <fwp_main_thread+0xaef>
    b9cf:	48 89 c2             	mov    %rax,%rdx
    b9d2:	48 c1 ea 10          	shr    $0x10,%rdx
    b9d6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b9da:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b9e1:	00 
    b9e2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b9e6:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b9ea:	48 85 ff             	test   %rdi,%rdi
    b9ed:	74 50                	je     ba3f <fwp_main_thread+0xaef>
    b9ef:	0f b6 0a             	movzbl (%rdx),%ecx
    b9f2:	80 f9 02             	cmp    $0x2,%cl
    b9f5:	0f 84 75 02 00 00    	je     bc70 <fwp_main_thread+0xd20>
    b9fb:	80 f9 01             	cmp    $0x1,%cl
    b9fe:	75 3f                	jne    ba3f <fwp_main_thread+0xaef>
    ba00:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ba03:	0f b7 c0             	movzwl %ax,%eax
    ba06:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ba09:	48 0f af c1          	imul   %rcx,%rax
    ba0d:	48 c1 e8 20          	shr    $0x20,%rax
    ba11:	48 39 d0             	cmp    %rdx,%rax
    ba14:	73 29                	jae    ba3f <fwp_main_thread+0xaef>
    ba16:	48 01 c7             	add    %rax,%rdi
    ba19:	0f b6 07             	movzbl (%rdi),%eax
    ba1c:	84 c0                	test   %al,%al
    ba1e:	74 1f                	je     ba3f <fwp_main_thread+0xaef>
    ba20:	8b 15 c2 fa 05 00    	mov    0x5fac2(%rip),%edx        # 6b4e8 <iteration_active>
    ba26:	85 d2                	test   %edx,%edx
    ba28:	74 08                	je     ba32 <fwp_main_thread+0xae2>
    ba2a:	48 83 05 9e fa 05 00 	addq   $0x1,0x5fa9e(%rip)        # 6b4d0 <iteration_retains>
    ba31:	01 
    ba32:	3c fd                	cmp    $0xfd,%al
    ba34:	0f 87 26 03 00 00    	ja     bd60 <fwp_main_thread+0xe10>
    ba3a:	83 c0 01             	add    $0x1,%eax
    ba3d:	88 07                	mov    %al,(%rdi)
    ba3f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ba43:	b9 01 00 00 00       	mov    $0x1,%ecx
    ba48:	4c 89 ee             	mov    %r13,%rsi
    ba4b:	48 89 ef             	mov    %rbp,%rdi
    ba4e:	48 8d 15 4b 51 00 00 	lea    0x514b(%rip),%rdx        # 10ba0 <d0>
    ba55:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    ba5a:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    ba61:	00 00 
    ba63:	e8 a8 e4 ff ff       	call   9f10 <fwp_write>
    ba68:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    ba6d:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
    ba72:	48 8d 05 f3 15 00 00 	lea    0x15f3(%rip),%rax        # d06c <_IO_stdin_used+0x6c>
    ba79:	4d 85 f6             	test   %r14,%r14
    ba7c:	4c 0f 44 f0          	cmove  %rax,%r14
    ba80:	48 83 fa f6          	cmp    $0xfffffffffffffff6,%rdx
    ba84:	0f 87 7a 03 00 00    	ja     be04 <fwp_main_thread+0xeb4>
    ba8a:	48 8d 7a 09          	lea    0x9(%rdx),%rdi
    ba8e:	be 01 00 00 00       	mov    $0x1,%esi
    ba93:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    ba98:	e8 73 a4 ff ff       	call   5f10 <fwp_heap_alloc>
    ba9d:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    baa2:	4c 89 f6             	mov    %r14,%rsi
    baa5:	48 8d 78 08          	lea    0x8(%rax),%rdi
    baa9:	49 89 c7             	mov    %rax,%r15
    baac:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    bab1:	48 89 10             	mov    %rdx,(%rax)
    bab4:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    bab9:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    babe:	e8 bd 7a ff ff       	call   3580 <memcpy@plt>
    bac3:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    bac8:	41 c6 44 17 08 00    	movb   $0x0,0x8(%r15,%rdx,1)
    bace:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    bad3:	e8 d8 78 ff ff       	call   33b0 <free@plt>
    bad8:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    badf:	00 
    bae0:	4d 2b bc 24 b0 13 00 	sub    0x13b0(%r12),%r15
    bae7:	00 
    bae8:	48 c1 e2 10          	shl    $0x10,%rdx
    baec:	49 39 d7             	cmp    %rdx,%r15
    baef:	73 59                	jae    bb4a <fwp_main_thread+0xbfa>
    baf1:	4c 89 fa             	mov    %r15,%rdx
    baf4:	48 c1 ea 10          	shr    $0x10,%rdx
    baf8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bafc:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    bb03:	00 
    bb04:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bb08:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    bb0c:	4d 85 f6             	test   %r14,%r14
    bb0f:	74 39                	je     bb4a <fwp_main_thread+0xbfa>
    bb11:	0f b6 0a             	movzbl (%rdx),%ecx
    bb14:	80 f9 02             	cmp    $0x2,%cl
    bb17:	0f 84 b6 01 00 00    	je     bcd3 <fwp_main_thread+0xd83>
    bb1d:	80 f9 01             	cmp    $0x1,%cl
    bb20:	75 28                	jne    bb4a <fwp_main_thread+0xbfa>
    bb22:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bb25:	41 0f b7 c7          	movzwl %r15w,%eax
    bb29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bb2c:	48 0f af c1          	imul   %rcx,%rax
    bb30:	48 c1 e8 20          	shr    $0x20,%rax
    bb34:	48 39 d0             	cmp    %rdx,%rax
    bb37:	73 11                	jae    bb4a <fwp_main_thread+0xbfa>
    bb39:	49 01 c6             	add    %rax,%r14
    bb3c:	41 80 3e ff          	cmpb   $0xff,(%r14)
    bb40:	0f 84 24 02 00 00    	je     bd6a <fwp_main_thread+0xe1a>
    bb46:	41 c6 06 01          	movb   $0x1,(%r14)
    bb4a:	4c 89 ef             	mov    %r13,%rdi
    bb4d:	e8 de b4 ff ff       	call   7030 <fwp_drop0>
    bb52:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    bb57:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    bb5c:	be 01 00 00 00       	mov    $0x1,%esi
    bb61:	48 8b 0d 18 f9 05 00 	mov    0x5f918(%rip),%rcx        # 6b480 <fwp_prog_out>
    bb68:	49 8b 17             	mov    (%r15),%rdx
    bb6b:	e8 f0 7a ff ff       	call   3660 <fwrite@plt>
    bb70:	48 8b 35 09 f9 05 00 	mov    0x5f909(%rip),%rsi        # 6b480 <fwp_prog_out>
    bb77:	bf 0a 00 00 00       	mov    $0xa,%edi
    bb7c:	e8 4f 79 ff ff       	call   34d0 <fputc@plt>
    bb81:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    bb88:	00 
    bb89:	4c 89 f8             	mov    %r15,%rax
    bb8c:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    bb93:	00 
    bb94:	48 c1 e2 10          	shl    $0x10,%rdx
    bb98:	48 39 d0             	cmp    %rdx,%rax
    bb9b:	73 73                	jae    bc10 <fwp_main_thread+0xcc0>
    bb9d:	48 89 c2             	mov    %rax,%rdx
    bba0:	48 c1 ea 10          	shr    $0x10,%rdx
    bba4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bba8:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    bbaf:	00 
    bbb0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bbb4:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    bbb8:	4d 85 f6             	test   %r14,%r14
    bbbb:	74 53                	je     bc10 <fwp_main_thread+0xcc0>
    bbbd:	0f b6 0a             	movzbl (%rdx),%ecx
    bbc0:	80 f9 02             	cmp    $0x2,%cl
    bbc3:	0f 84 fc 00 00 00    	je     bcc5 <fwp_main_thread+0xd75>
    bbc9:	80 f9 01             	cmp    $0x1,%cl
    bbcc:	75 42                	jne    bc10 <fwp_main_thread+0xcc0>
    bbce:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bbd1:	0f b7 c0             	movzwl %ax,%eax
    bbd4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bbd7:	48 0f af c1          	imul   %rcx,%rax
    bbdb:	48 c1 e8 20          	shr    $0x20,%rax
    bbdf:	48 39 d0             	cmp    %rdx,%rax
    bbe2:	73 2c                	jae    bc10 <fwp_main_thread+0xcc0>
    bbe4:	49 01 c6             	add    %rax,%r14
    bbe7:	41 0f b6 06          	movzbl (%r14),%eax
    bbeb:	84 c0                	test   %al,%al
    bbed:	74 21                	je     bc10 <fwp_main_thread+0xcc0>
    bbef:	3c 01                	cmp    $0x1,%al
    bbf1:	0f 84 33 01 00 00    	je     bd2a <fwp_main_thread+0xdda>
    bbf7:	3c ff                	cmp    $0xff,%al
    bbf9:	0f 84 78 01 00 00    	je     bd77 <fwp_main_thread+0xe27>
    bbff:	83 e8 01             	sub    $0x1,%eax
    bc02:	41 88 06             	mov    %al,(%r14)
    bc05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bc0c:	00 00 00 00 
    bc10:	48 8b 04 24          	mov    (%rsp),%rax
    bc14:	48 8b 40 10          	mov    0x10(%rax),%rax
    bc18:	48 89 04 24          	mov    %rax,(%rsp)
    bc1c:	48 85 c0             	test   %rax,%rax
    bc1f:	0f 84 db 00 00 00    	je     bd00 <fwp_main_thread+0xdb0>
    bc25:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    bc2c:	00 
    bc2d:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    bc34:	00 
    bc35:	e9 86 fd ff ff       	jmp    b9c0 <fwp_main_thread+0xa70>
    bc3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bc40:	48 89 c2             	mov    %rax,%rdx
    bc43:	83 e0 01             	and    $0x1,%eax
    bc46:	66 0f ef c9          	pxor   %xmm1,%xmm1
    bc4a:	48 d1 ea             	shr    $1,%rdx
    bc4d:	48 09 c2             	or     %rax,%rdx
    bc50:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    bc55:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    bc59:	e9 95 f9 ff ff       	jmp    b5f3 <fwp_main_thread+0x6a3>
    bc5e:	66 90                	xchg   %ax,%ax
    bc60:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    bc64:	e9 ee f4 ff ff       	jmp    b157 <fwp_main_thread+0x207>
    bc69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    bc70:	66 85 c0             	test   %ax,%ax
    bc73:	0f 85 c6 fd ff ff    	jne    ba3f <fwp_main_thread+0xaef>
    bc79:	e9 9b fd ff ff       	jmp    ba19 <fwp_main_thread+0xac9>
    bc7e:	66 90                	xchg   %ax,%ax
    bc80:	66 85 c0             	test   %ax,%ax
    bc83:	0f 85 33 fd ff ff    	jne    b9bc <fwp_main_thread+0xa6c>
    bc89:	e9 12 fd ff ff       	jmp    b9a0 <fwp_main_thread+0xa50>
    bc8e:	66 90                	xchg   %ax,%ax
    bc90:	66 85 c0             	test   %ax,%ax
    bc93:	0f 85 79 fc ff ff    	jne    b912 <fwp_main_thread+0x9c2>
    bc99:	e9 64 fc ff ff       	jmp    b902 <fwp_main_thread+0x9b2>
    bc9e:	66 90                	xchg   %ax,%ax
    bca0:	66 85 c0             	test   %ax,%ax
    bca3:	0f 85 d3 fb ff ff    	jne    b87c <fwp_main_thread+0x92c>
    bca9:	e9 be fb ff ff       	jmp    b86c <fwp_main_thread+0x91c>
    bcae:	66 90                	xchg   %ax,%ax
    bcb0:	48 89 d7             	mov    %rdx,%rdi
    bcb3:	48 89 14 24          	mov    %rdx,(%rsp)
    bcb7:	e8 14 9b ff ff       	call   57d0 <fwp_rc_forget_slot>
    bcbc:	48 8b 14 24          	mov    (%rsp),%rdx
    bcc0:	e9 83 fa ff ff       	jmp    b748 <fwp_main_thread+0x7f8>
    bcc5:	66 85 c0             	test   %ax,%ax
    bcc8:	0f 85 42 ff ff ff    	jne    bc10 <fwp_main_thread+0xcc0>
    bcce:	e9 14 ff ff ff       	jmp    bbe7 <fwp_main_thread+0xc97>
    bcd3:	66 45 85 ff          	test   %r15w,%r15w
    bcd7:	0f 85 6d fe ff ff    	jne    bb4a <fwp_main_thread+0xbfa>
    bcdd:	e9 5a fe ff ff       	jmp    bb3c <fwp_main_thread+0xbec>
    bce2:	48 83 3d 0e db 05 00 	cmpq   $0x0,0x5db0e(%rip)        # 697f8 <fwp_root>
    bce9:	00 
    bcea:	c7 05 8c 53 01 00 00 	movl   $0x0,0x1538c(%rip)        # 21080 <fwp_exit_code>
    bcf1:	00 00 00 
    bcf4:	0f 84 5e f7 ff ff    	je     b458 <fwp_main_thread+0x508>
    bcfa:	e9 51 7a ff ff       	jmp    3750 <fwp_main_thread.cold>
    bcff:	90                   	nop
    bd00:	4c 89 ef             	mov    %r13,%rdi
    bd03:	e8 28 b3 ff ff       	call   7030 <fwp_drop0>
    bd08:	48 89 df             	mov    %rbx,%rdi
    bd0b:	e8 20 b3 ff ff       	call   7030 <fwp_drop0>
    bd10:	48 c7 05 4d 53 00 00 	movq   $0x0,0x534d(%rip)        # 11068 <v.2>
    bd17:	00 00 00 00 
    bd1b:	c7 05 4b 53 00 00 01 	movl   $0x1,0x534b(%rip)        # 11070 <st.3>
    bd22:	00 00 00 
    bd25:	e9 79 f3 ff ff       	jmp    b0a3 <fwp_main_thread+0x153>
    bd2a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    bd2f:	e8 cc af ff ff       	call   6d00 <fwp_rc_free_arr>
    bd34:	e9 d7 fe ff ff       	jmp    bc10 <fwp_main_thread+0xcc0>
    bd39:	4c 89 ef             	mov    %r13,%rdi
    bd3c:	e8 8f 9a ff ff       	call   57d0 <fwp_rc_forget_slot>
    bd41:	e9 31 fb ff ff       	jmp    b877 <fwp_main_thread+0x927>
    bd46:	4c 89 ef             	mov    %r13,%rdi
    bd49:	e8 82 9a ff ff       	call   57d0 <fwp_rc_forget_slot>
    bd4e:	e9 ba fb ff ff       	jmp    b90d <fwp_main_thread+0x9bd>
    bd53:	4c 89 f7             	mov    %r14,%rdi
    bd56:	e8 75 9a ff ff       	call   57d0 <fwp_rc_forget_slot>
    bd5b:	e9 4a fc ff ff       	jmp    b9aa <fwp_main_thread+0xa5a>
    bd60:	e8 4b 99 ff ff       	call   56b0 <fwp_rc_wide_dup>
    bd65:	e9 d5 fc ff ff       	jmp    ba3f <fwp_main_thread+0xaef>
    bd6a:	4c 89 f7             	mov    %r14,%rdi
    bd6d:	e8 5e 9a ff ff       	call   57d0 <fwp_rc_forget_slot>
    bd72:	e9 cf fd ff ff       	jmp    bb46 <fwp_main_thread+0xbf6>
    bd77:	4c 89 f0             	mov    %r14,%rax
    bd7a:	48 c1 e8 11          	shr    $0x11,%rax
    bd7e:	4c 31 f0             	xor    %r14,%rax
    bd81:	48 89 c2             	mov    %rax,%rdx
    bd84:	48 c1 ea 09          	shr    $0x9,%rdx
    bd88:	48 31 d0             	xor    %rdx,%rax
    bd8b:	0f b6 d0             	movzbl %al,%edx
    bd8e:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    bd95:	00 
    bd96:	48 85 c0             	test   %rax,%rax
    bd99:	75 0e                	jne    bda9 <fwp_main_thread+0xe59>
    bd9b:	eb 56                	jmp    bdf3 <fwp_main_thread+0xea3>
    bd9d:	0f 1f 00             	nopl   (%rax)
    bda0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    bda4:	48 85 c0             	test   %rax,%rax
    bda7:	74 4a                	je     bdf3 <fwp_main_thread+0xea3>
    bda9:	48 89 c2             	mov    %rax,%rdx
    bdac:	4c 3b 30             	cmp    (%rax),%r14
    bdaf:	75 ef                	jne    bda0 <fwp_main_thread+0xe50>
    bdb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    bdb5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    bdb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    bdbd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    bdc4:	0f 85 46 fe ff ff    	jne    bc10 <fwp_main_thread+0xcc0>
    bdca:	4c 89 f7             	mov    %r14,%rdi
    bdcd:	e8 fe 99 ff ff       	call   57d0 <fwp_rc_forget_slot>
    bdd2:	41 c6 06 fe          	movb   $0xfe,(%r14)
    bdd6:	e9 35 fe ff ff       	jmp    bc10 <fwp_main_thread+0xcc0>
    bddb:	48 8d 3d 56 1d 00 00 	lea    0x1d56(%rip),%rdi        # db38 <_IO_stdin_used+0xb38>
    bde2:	e8 69 86 ff ff       	call   4450 <fwp_trap>
    bde7:	48 8d 3d d4 14 00 00 	lea    0x14d4(%rip),%rdi        # d2c2 <_IO_stdin_used+0x2c2>
    bdee:	e8 0d 82 ff ff       	call   4000 <ad_raw_fail>
    bdf3:	48 8d 3d e6 1b 00 00 	lea    0x1be6(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    bdfa:	e8 51 86 ff ff       	call   4450 <fwp_trap>
    bdff:	e8 4c 76 ff ff       	call   3450 <__stack_chk_fail@plt>
    be04:	48 8d 3d d2 14 00 00 	lea    0x14d2(%rip),%rdi        # d2dd <_IO_stdin_used+0x2dd>
    be0b:	e8 40 86 ff ff       	call   4450 <fwp_trap>
    be10:	e9 3b 79 ff ff       	jmp    3750 <fwp_main_thread.cold>
    be15:	e9 36 79 ff ff       	jmp    3750 <fwp_main_thread.cold>
    be1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000000be20 <__divmodti4>:
    be20:	f3 0f 1e fa          	endbr64
    be24:	55                   	push   %rbp
    be25:	49 89 f1             	mov    %rsi,%r9
    be28:	49 89 d2             	mov    %rdx,%r10
    be2b:	48 89 fe             	mov    %rdi,%rsi
    be2e:	49 89 cb             	mov    %rcx,%r11
    be31:	48 89 e5             	mov    %rsp,%rbp
    be34:	41 57                	push   %r15
    be36:	41 56                	push   %r14
    be38:	41 55                	push   %r13
    be3a:	41 54                	push   %r12
    be3c:	53                   	push   %rbx
    be3d:	4c 89 c3             	mov    %r8,%rbx
    be40:	45 31 c0             	xor    %r8d,%r8d
    be43:	4d 85 c9             	test   %r9,%r9
    be46:	79 12                	jns    be5a <__divmodti4+0x3a>
    be48:	31 ff                	xor    %edi,%edi
    be4a:	48 f7 de             	neg    %rsi
    be4d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    be54:	4c 19 cf             	sbb    %r9,%rdi
    be57:	49 89 f9             	mov    %rdi,%r9
    be5a:	4c 89 d8             	mov    %r11,%rax
    be5d:	4d 85 db             	test   %r11,%r11
    be60:	0f 88 1a 01 00 00    	js     bf80 <__divmodti4+0x160>
    be66:	4c 89 d9             	mov    %r11,%rcx
    be69:	49 89 f3             	mov    %rsi,%r11
    be6c:	75 62                	jne    bed0 <__divmodti4+0xb0>
    be6e:	4d 89 c4             	mov    %r8,%r12
    be71:	4d 39 d1             	cmp    %r10,%r9
    be74:	0f 83 46 01 00 00    	jae    bfc0 <__divmodti4+0x1a0>
    be7a:	4c 89 d8             	mov    %r11,%rax
    be7d:	4c 89 ca             	mov    %r9,%rdx
    be80:	49 f7 f2             	div    %r10
    be83:	49 89 c3             	mov    %rax,%r11
    be86:	31 c0                	xor    %eax,%eax
    be88:	48 89 d6             	mov    %rdx,%rsi
    be8b:	31 ff                	xor    %edi,%edi
    be8d:	4c 89 d9             	mov    %r11,%rcx
    be90:	48 89 c2             	mov    %rax,%rdx
    be93:	48 89 c8             	mov    %rcx,%rax
    be96:	4d 85 e4             	test   %r12,%r12
    be99:	74 0a                	je     bea5 <__divmodti4+0x85>
    be9b:	48 f7 d8             	neg    %rax
    be9e:	48 83 d2 00          	adc    $0x0,%rdx
    bea2:	48 f7 da             	neg    %rdx
    bea5:	4d 85 c0             	test   %r8,%r8
    bea8:	74 0a                	je     beb4 <__divmodti4+0x94>
    beaa:	48 f7 de             	neg    %rsi
    bead:	48 83 d7 00          	adc    $0x0,%rdi
    beb1:	48 f7 df             	neg    %rdi
    beb4:	48 89 33             	mov    %rsi,(%rbx)
    beb7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bebb:	5b                   	pop    %rbx
    bebc:	41 5c                	pop    %r12
    bebe:	41 5d                	pop    %r13
    bec0:	41 5e                	pop    %r14
    bec2:	41 5f                	pop    %r15
    bec4:	5d                   	pop    %rbp
    bec5:	c3                   	ret
    bec6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    becd:	00 00 00 
    bed0:	4d 89 c4             	mov    %r8,%r12
    bed3:	49 39 c1             	cmp    %rax,%r9
    bed6:	0f 82 ce 00 00 00    	jb     bfaa <__divmodti4+0x18a>
    bedc:	31 ff                	xor    %edi,%edi
    bede:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bee3:	48 63 c7             	movslq %edi,%rax
    bee6:	be 40 00 00 00       	mov    $0x40,%esi
    beeb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bef0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bef5:	48 29 c6             	sub    %rax,%rsi
    bef8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    befd:	48 09 c8             	or     %rcx,%rax
    bf00:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bf05:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bf0a:	49 89 c6             	mov    %rax,%r14
    bf0d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bf11:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bf16:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bf1b:	49 09 c1             	or     %rax,%r9
    bf1e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bf22:	4c 89 c8             	mov    %r9,%rax
    bf25:	49 f7 f6             	div    %r14
    bf28:	48 89 d1             	mov    %rdx,%rcx
    bf2b:	49 89 c3             	mov    %rax,%r11
    bf2e:	49 89 c1             	mov    %rax,%r9
    bf31:	49 f7 e2             	mul    %r10
    bf34:	49 89 c6             	mov    %rax,%r14
    bf37:	49 89 d2             	mov    %rdx,%r10
    bf3a:	48 39 d1             	cmp    %rdx,%rcx
    bf3d:	72 07                	jb     bf46 <__divmodti4+0x126>
    bf3f:	75 17                	jne    bf58 <__divmodti4+0x138>
    bf41:	49 39 c7             	cmp    %rax,%r15
    bf44:	73 12                	jae    bf58 <__divmodti4+0x138>
    bf46:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bf4a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bf4e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bf52:	49 89 d2             	mov    %rdx,%r10
    bf55:	49 89 c6             	mov    %rax,%r14
    bf58:	4c 89 f8             	mov    %r15,%rax
    bf5b:	4c 29 f0             	sub    %r14,%rax
    bf5e:	4c 19 d1             	sbb    %r10,%rcx
    bf61:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bf66:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bf6b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bf70:	48 09 c6             	or     %rax,%rsi
    bf73:	48 89 cf             	mov    %rcx,%rdi
    bf76:	31 c0                	xor    %eax,%eax
    bf78:	4c 89 c9             	mov    %r9,%rcx
    bf7b:	e9 10 ff ff ff       	jmp    be90 <__divmodti4+0x70>
    bf80:	4c 89 d0             	mov    %r10,%rax
    bf83:	4c 89 da             	mov    %r11,%rdx
    bf86:	4d 89 c4             	mov    %r8,%r12
    bf89:	49 89 f3             	mov    %rsi,%r11
    bf8c:	48 f7 d8             	neg    %rax
    bf8f:	49 f7 d4             	not    %r12
    bf92:	48 83 d2 00          	adc    $0x0,%rdx
    bf96:	49 89 c2             	mov    %rax,%r10
    bf99:	48 f7 da             	neg    %rdx
    bf9c:	48 89 d1             	mov    %rdx,%rcx
    bf9f:	0f 84 cc fe ff ff    	je     be71 <__divmodti4+0x51>
    bfa5:	49 39 d1             	cmp    %rdx,%r9
    bfa8:	73 46                	jae    bff0 <__divmodti4+0x1d0>
    bfaa:	4c 89 cf             	mov    %r9,%rdi
    bfad:	31 c0                	xor    %eax,%eax
    bfaf:	31 c9                	xor    %ecx,%ecx
    bfb1:	e9 da fe ff ff       	jmp    be90 <__divmodti4+0x70>
    bfb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bfbd:	00 00 00 
    bfc0:	4d 85 d2             	test   %r10,%r10
    bfc3:	75 0d                	jne    bfd2 <__divmodti4+0x1b2>
    bfc5:	b8 01 00 00 00       	mov    $0x1,%eax
    bfca:	31 d2                	xor    %edx,%edx
    bfcc:	49 f7 f2             	div    %r10
    bfcf:	49 89 c2             	mov    %rax,%r10
    bfd2:	4c 89 c8             	mov    %r9,%rax
    bfd5:	31 d2                	xor    %edx,%edx
    bfd7:	49 f7 f2             	div    %r10
    bfda:	49 89 c1             	mov    %rax,%r9
    bfdd:	4c 89 d8             	mov    %r11,%rax
    bfe0:	49 f7 f2             	div    %r10
    bfe3:	49 89 c3             	mov    %rax,%r11
    bfe6:	4c 89 c8             	mov    %r9,%rax
    bfe9:	e9 9a fe ff ff       	jmp    be88 <__divmodti4+0x68>
    bfee:	66 90                	xchg   %ax,%ax
    bff0:	45 31 f6             	xor    %r14d,%r14d
    bff3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bff8:	44 89 f7             	mov    %r14d,%edi
    bffb:	45 85 f6             	test   %r14d,%r14d
    bffe:	0f 85 df fe ff ff    	jne    bee3 <__divmodti4+0xc3>
    c004:	4c 39 ca             	cmp    %r9,%rdx
    c007:	72 17                	jb     c020 <__divmodti4+0x200>
    c009:	31 c9                	xor    %ecx,%ecx
    c00b:	48 39 c6             	cmp    %rax,%rsi
    c00e:	73 10                	jae    c020 <__divmodti4+0x200>
    c010:	4c 89 cf             	mov    %r9,%rdi
    c013:	31 c0                	xor    %eax,%eax
    c015:	e9 76 fe ff ff       	jmp    be90 <__divmodti4+0x70>
    c01a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c020:	4c 89 de             	mov    %r11,%rsi
    c023:	b9 01 00 00 00       	mov    $0x1,%ecx
    c028:	48 29 c6             	sub    %rax,%rsi
    c02b:	49 19 d1             	sbb    %rdx,%r9
    c02e:	eb e0                	jmp    c010 <__divmodti4+0x1f0>

000000000000c030 <atexit>:
    c030:	f3 0f 1e fa          	endbr64
    c034:	48 8b 15 cd 4f 00 00 	mov    0x4fcd(%rip),%rdx        # 11008 <__dso_handle>
    c03b:	31 f6                	xor    %esi,%esi
    c03d:	e9 fe 75 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000c044 <_fini>:
    c044:	f3 0f 1e fa          	endbr64
    c048:	48 83 ec 08          	sub    $0x8,%rsp
    c04c:	48 83 c4 08          	add    $0x8,%rsp
    c050:	c3                   	ret
