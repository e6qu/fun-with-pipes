
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 bf 00 00 	mov    0xbfc1(%rip),%rax        # efd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da bd 00 00    	push   0xbdda(%rip)        # ee00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc bd 00 00    	jmp    *0xbddc(%rip)        # ee08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 bc 00 00    	jmp    *0xbc46(%rip)        # efe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # ee60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # ee68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # ee70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # ee78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # ee80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # ee88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # ee90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # ee98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eeb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eeb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # eec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # eec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # eed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # eed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # eee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # eee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # eef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # eef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # ef60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # ef68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # ef70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # ef78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # ef80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # ef88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 b8 00 00    	jmp    *0xb8e6(%rip)        # ef90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de b8 00 00    	jmp    *0xb8de(%rip)        # ef98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 b8 00 00    	jmp    *0xb8d6(%rip)        # efa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce b8 00 00    	jmp    *0xb8ce(%rip)        # efa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 b8 00 00    	jmp    *0xb8c6(%rip)        # efb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be b8 00 00    	jmp    *0xb8be(%rip)        # efb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 79 00 00 	lea    0x79dd(%rip),%r9        # b0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 79 00 00 	lea    0x79da(%rip),%r8        # b0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 9b 00 00 	lea    0x9b81(%rip),%rax        # d300 <fwp_fn_table>
    377f:	48 89 05 92 dc 01 00 	mov    %rax,0x1dc92(%rip)        # 21418 <fwp_fns>
    3786:	48 8b 05 93 b8 00 00 	mov    0xb893(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c dc 01 00 	mov    %rax,0x1dc8c(%rip)        # 21420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d 8d 7a 00 00 	lea    0x7a8d(%rip),%rdi        # b22d <_IO_stdin_used+0x22d>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 b8 00 00 	mov    0xb818(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 3f 5e 00 00 	lea    0x5e3f(%rip),%rdx        # 96a0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 b7 00 00 	mov    0xb783(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 b7 01 00    	mov    0x1b7d8(%rip),%eax        # 1f080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 3d 79 00 00 	lea    0x793d(%rip),%rdi        # b236 <_IO_stdin_used+0x236>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d d6 80 00 00 	lea    0x80d6(%rip),%rdi        # b9e0 <_IO_stdin_used+0x9e0>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 90 80 00 00 	lea    0x8090(%rip),%rdi        # b9b8 <_IO_stdin_used+0x9b8>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 54 80 00 00 	lea    0x8054(%rip),%rdi        # b988 <_IO_stdin_used+0x988>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d 20 80 00 00 	lea    0x8020(%rip),%rdi        # b960 <_IO_stdin_used+0x960>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b b6 00 00    	call   *0xb64b(%rip)        # efc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 91 b6 00 00 	lea    0xb691(%rip),%rdi        # f018 <__TMC_END__>
    3987:	48 8d 05 8a b6 00 00 	lea    0xb68a(%rip),%rax        # f018 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e b6 00 00 	mov    0xb62e(%rip),%rax        # efc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 61 b6 00 00 	lea    0xb661(%rip),%rdi        # f018 <__TMC_END__>
    39b7:	48 8d 35 5a b6 00 00 	lea    0xb65a(%rip),%rsi        # f018 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd b5 00 00 	mov    0xb5fd(%rip),%rax        # efd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d b6 00 00 00 	cmpb   $0x0,0xb64d(%rip)        # f048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da b5 00 00 	cmpq   $0x0,0xb5da(%rip)        # efe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 b5 00 00 	mov    0xb5f6(%rip),%rdi        # f008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 b6 00 00 01 	movb   $0x1,0xb625(%rip)        # f048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce b4 01 00 	add    0x1b4ce(%rip),%rdx        # 1f0f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc b4 01 00 	add    0x1b4bc(%rip),%rax        # 1f0f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 d7 01 00 	mov    0x1d7a9(%rip),%rdi        # 21420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 b3 00 00 	mov    0xb394(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 b3 00 00 	mov    0xb381(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 73 00 00 	lea    0x7345(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 b3 00 00 	mov    0xb372(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 ba 01 00 	mov    0x1baa1(%rip),%rax        # 1f7a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 b3 01 00 	mov    0x1b3d9(%rip),%rax        # 1f158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 b3 01 00 	sub    0x1b3c5(%rip),%rax        # 1f150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 fd 7c 00 00 	lea    0x7cfd(%rip),%rsi        # bac0 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 5f 78 00 00 	lea    0x785f(%rip),%rdi        # b648 <_IO_stdin_used+0x648>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 b2 00 00 	mov    0xb242(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d dd b1 00 00 ff 	cmpl   $0xffffffff,0xb1dd(%rip)        # f010 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 71 00 00 	lea    0x71e2(%rip),%rax        # b022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 b2 01 00 	mov    0x1b2c1(%rip),%r9        # 1f108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ad 00 	movq   0xad9f(%rip),%xmm0        # ebf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 71 00 00 	lea    0x71e7(%rip),%rax        # b044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c b2 01 00 	mov    0x1b29c(%rip),%r8        # 1f100 <descent_inputs>
    3e64:	48 8b 0d a5 b2 01 00 	mov    0x1b2a5(%rip),%rcx        # 1f110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 b1 00 00 	mov    0xb1c2(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 71 00 00 	lea    0x71d8(%rip),%rax        # b061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ad 00 	movq   0xad67(%rip),%xmm0        # ebf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 f8 77 00 00 	lea    0x77f8(%rip),%rdx        # b690 <_IO_stdin_used+0x690>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 b2 01 00 	lea    0x1b271(%rip),%r12        # 1f120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ad 00 	movq   0xad44(%rip),%xmm0        # ec00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b b1 00 00 	mov    0xb15b(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 71 00 00 	lea    0x7175(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 71 00 00 	lea    0x7170(%rip),%rdx        # b06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 b1 00 00 	mov    0xb120(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 71 00 00 	lea    0x7144(%rip),%rdi        # b07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 b0 00 00 	mov    0xb0f9(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 71 00 00 	lea    0x7143(%rip),%rcx        # b091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 71 00 00 	lea    0x7119(%rip),%rdx        # b06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b cc 01 00 	mov    0x1cc1b(%rip),%rax        # 20bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 cc 01 00 	lea    0x1cc14(%rip),%r8        # 20bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 cb 01 00 	mov    0x1cbf5(%rip),%rbx        # 20b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 cc 01 00 	mov    0x1cc05(%rip),%rcx        # 20bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 cb 01 00 	mov    0x1cba1(%rip),%rdi        # 20ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea cb 01 00 	sub    %rsi,0x1cbea(%rip)        # 20bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a cb 01 00 	mov    0x1cb7a(%rip),%rax        # 20b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 cb 01 00 	add    0x1cb30(%rip),%rdi        # 20b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e cb 01 00 	mov    0x1cb3e(%rip),%rsi        # 20ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c cb 01 00 	mov    0x1cb4c(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb ca 01 00 	mov    %r12,0x1cafb(%rip)        # 20ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 ca 01 00 	mov    %rbp,0x1cae9(%rip)        # 20b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce ca 01 00 	cmp    %rdi,0x1cace(%rip)        # 20b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 ca 01 00 	mov    %rdi,0x1cac5(%rip)        # 20b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 cb 01 00 	sub    %rdi,0x1cb09(%rip)        # 20bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 ca 01 00 	mov    0x1cab1(%rip),%rax        # 20ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa ca 01 00 	lea    0x1caaa(%rip),%r8        # 20ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d ae 00 00 	mov    0xae5d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 6e 00 00 	lea    0x6e14(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d a5 ad 00 00 	movslq 0xada5(%rip),%rbp        # f010 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a ae 01 00 	mov    0x1ae7a(%rip),%rsi        # 1f118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 ae 01 00 	lea    0x1ae76(%rip),%rcx        # 1f120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b ae 01 00 	addq   $0x1,0x1ae4b(%rip)        # 1f110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 40 ad 00 00    	mov    %ebx,0xad40(%rip)        # f010 <descent_active_phase>
    42d0:	48 89 05 41 ae 01 00 	mov    %rax,0x1ae41(%rip)        # 1f118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 b4 01 00 	cmp    0x1b499(%rip),%rdi        # 1f7a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f b4 01 00 	mov    0x1b45f(%rip),%rax        # 1f780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d b4 01 00 	mov    %rdi,0x1b43d(%rip)        # 1f780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 b4 01 00 	mov    %rdi,0x1b419(%rip)        # 1f788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee 6d 00 00 	lea    0x6dee(%rip),%rsi        # b19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 6c 00 00 	lea    0x6cba(%rip),%rsi        # b07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 ac 00 00 	mov    0xac28(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 6c 00 00 	lea    0x6c64(%rip),%rdx        # b083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 ac 00 00 	mov    0xac10(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 ab 00 00 	mov    0xab21(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 6a 00 00 	lea    0x6ad8(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 6b 00 00 	lea    0x6b45(%rip),%rdi        # b092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 6a 00 00 	lea    0x6acd(%rip),%rdi        # b0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d f0 70 00 00 	lea    0x70f0(%rip),%rdi        # b6e0 <_IO_stdin_used+0x6e0>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 d0 74 00 	movdqa 0x74d0(%rip),%xmm0        # bae0 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa cd 01 00 	add    0x1cdaa(%rip),%rax        # 21418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 44 70 00 00 	lea    0x7044(%rip),%rdi        # b708 <_IO_stdin_used+0x708>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 aa 01 00 	cmp    %rax,0x1aa05(%rip)        # 1f0e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 aa 01 00 	add    0x1aa00(%rip),%rax        # 1f0f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 2d 70 00 00 	lea    0x702d(%rip),%rdi        # b738 <_IO_stdin_used+0x738>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 69 00 00 	lea    0x69a5(%rip),%r8        # b0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 67 00 00 	lea    0x67fa(%rip),%r8        # b0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 66 00 00 	lea    0x6697(%rip),%r8        # b0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 64 00 00 	lea    0x646f(%rip),%rdi        # b0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 65 00 00 	lea    0x6554(%rip),%rsi        # b1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 be 01 00 	mov    0x1be85(%rip),%r9        # 20b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de be 01 00 	mov    0x1bede(%rip),%r8        # 20be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 77 6a 00 00 	lea    0x6a77(%rip),%rdx        # b788 <_IO_stdin_used+0x788>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 be 01 00 	mov    0x1bec6(%rip),%rcx        # 20be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 be 01 	movsd  0x1bed4(%rip),%xmm1        # 20c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 be 01 	movsd  0x1bec4(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 a3 00 00 	mov    0xa305(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 78 6d 00 	movdqa 0x6d78(%rip),%xmm0        # baf0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f b9 01 00 	lea    0x1b97f(%rip),%rax        # 20700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 a1 6d 00 	movdqa 0x6da1(%rip),%xmm2        # bb30 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 b9 01 00 	movaps %xmm0,0x1b925(%rip)        # 206c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 5d 6d 00 	movdqa 0x6d5d(%rip),%xmm0        # bb00 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 bd 01 00 01 	movl   $0x1,0x1bdb3(%rip)        # 20b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 b9 01 00 	movaps %xmm0,0x1b913(%rip)        # 206d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 4b 6d 00 	movdqa 0x6d4b(%rip),%xmm0        # bb10 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 14 b9 01 00 	movaps %xmm0,0x1b914(%rip)        # 206e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 4c 6d 00 	movdqa 0x6d4c(%rip),%xmm0        # bb20 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 15 b9 01 00 	movaps %xmm0,0x1b915(%rip)        # 206f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 a9 01 00 	lea    0x1a995(%rip),%r8        # 1f7c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 bc 01 00 	mov    %rax,0x1bcb0(%rip)        # 20b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e bc 01 00 	mov    %r12,0x1bc8e(%rip)        # 20b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 bc 01 00 	mov    %rax,0x1bc77(%rip)        # 20b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 bc 01 00 	mov    %rbx,0x1bc90(%rip)        # 20b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 bc 01 00 	mov    %rsi,0x1bcb9(%rip)        # 20bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 61 00 00 	lea    0x61f9(%rip),%rdi        # b112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 bc 01 00 	mov    %rax,0x1bc98(%rip)        # 20bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c bc 01 00    	mov    %eax,0x1bc1c(%rip)        # 20b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c a8 01 00 	mov    0x1a80c(%rip),%r8        # 1f780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c a7 01 00 	mov    %rbx,0x1a73c(%rip)        # 1f788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 a7 01 00 	mov    %r8,0x1a728(%rip)        # 1f780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c 60 00 00 	lea    0x605c(%rip),%rdi        # b122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d 9f 01 00 	lea    0x19f9d(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 9f 01 00 	movaps %xmm0,0x19f85(%rip)        # 1f0a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 9f 01 00 	mov    %rax,0x19f61(%rip)        # 1f088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 9f 01 00 	movaps %xmm0,0x19f82(%rip)        # 1f0b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 9f 01 00 	movaps %xmm0,0x19f86(%rip)        # 1f0c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 9f 01 00 	mov    %rdx,0x19f87(%rip)        # 1f0d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 5f 00 00 	lea    0x5fb3(%rip),%rdi        # b122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 a5 01 00 	mov    0x1a5b7(%rip),%rbx        # 1f778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a 9d 00 00 	mov    0x9d8a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 53 65 00 00 	lea    0x6553(%rip),%rdi        # b810 <_IO_stdin_used+0x810>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d a4 01 00 	mov    0x1a48d(%rip),%rax        # 1f780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 a4 01 00 	mov    %rdx,0x1a467(%rip)        # 1f780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 a3 01 00 	mov    0x1a3b4(%rip),%rbx        # 1f778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 a3 01 00 	mov    %rbx,0x1a371(%rip)        # 1f778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 a3 01 00 	mov    %rdx,0x1a371(%rip)        # 1f788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 a3 01 00 	lea    0x1a386(%rip),%rsi        # 1f7c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 bf 01 00 	addq   $0x1,0x1bf05(%rip)        # 21408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 27 63 00 00 	lea    0x6327(%rip),%rdi        # b840 <_IO_stdin_used+0x840>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 38 63 00 00 	lea    0x6338(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 5b 00 00 	lea    0x5bf7(%rip),%rdi        # b133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e a2 01 00 	lea    0x1a23e(%rip),%rcx        # 1f7c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f be 01 00 	subq   $0x1,0x1be3f(%rip)        # 21408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d 93 62 00 00 	lea    0x6293(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 be 01 00 	cmpq   $0x0,0x1be20(%rip)        # 21408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 bd 01 00 	sub    %rax,0x1bd75(%rip)        # 21410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 bd 01 00 	add    %r12,0x1bd53(%rip)        # 21410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af b4 01 00 	mov    0x1b4af(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac a0 01 00 	lea    0x1a0ac(%rip),%rax        # 1f7c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 b4 01 00 	add    0x1b403(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 b3 01 00 	mov    0x1b3d0(%rip),%rsi        # 20b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 b3 01 00 	mov    0x1b3f1(%rip),%rax        # 20b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 b3 01 00 	add    0x1b3e5(%rip),%r8        # 20bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad b3 01 	addsd  0x1b3ad(%rip),%xmm0        # 20c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 9f 01 00 	lea    0x19f62(%rip),%rax        # 1f7c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c b3 01 00 	sub    %rdi,0x1b36c(%rip)        # 20be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 b3 01 	movsd  %xmm0,0x1b384(%rip)        # 20c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e b3 01 00 	sub    %rdx,0x1b33e(%rip)        # 20be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 b3 01 	addsd  0x1b344(%rip),%xmm0        # 20c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 b3 01 	movsd  %xmm0,0x1b338(%rip)        # 20c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf b2 01 00 	mov    0x1b2cf(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 b2 01 00 	add    %rcx,0x1b2c9(%rip)        # 20bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 b2 01 00 	cmp    0x1b282(%rip),%r9        # 20bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 b2 01 00 	mov    %r9,0x1b279(%rip)        # 20bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a b2 01 00 	cmp    0x1b26a(%rip),%r9        # 20ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d b2 01 00 	mov    %r9,0x1b25d(%rip)        # 20ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 b1 01 00 	add    0x1b173(%rip),%rdi        # 20bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 9d 01 00 	lea    0x19d50(%rip),%r15        # 1f7c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 b0 01 00 	add    0x1b0c0(%rip),%r12        # 20b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 b1 01 00 	add    0x1b119(%rip),%rax        # 20be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 b1 01 00 	cmp    %rax,0x1b118(%rip)        # 20be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 b1 01 00 	mov    %rax,0x1b109(%rip)        # 20be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 b1 01 00 	mov    %rax,0x1b108(%rip)        # 20be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 b1 01 	addsd  0x1b104(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc b0 01 	movsd  %xmm0,0x1b0fc(%rip)        # 20bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 b0 01 00    	mov    0x1b043(%rip),%eax        # 20b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f 9c 01 00 	lea    0x19c7f(%rip),%rdi        # 1f7c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 b0 01 00 	add    0x1b038(%rip),%rax        # 20be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 b0 01 00 	cmp    %rax,0x1b033(%rip)        # 20be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 b0 01 00 	mov    %rax,0x1b024(%rip)        # 20be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 b0 01 00 	mov    %rax,0x1b023(%rip)        # 20be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f b0 01 	addsd  0x1b01f(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 b0 01 	movsd  %xmm0,0x1b017(%rip)        # 20bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce ae 01 00    	mov    0x1aece(%rip),%eax        # 20b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 9b 01 00 	lea    0x19b05(%rip),%rax        # 1f7c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb ae 01 00 	add    0x1aebb(%rip),%rax        # 20be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba ae 01 00 	cmp    %rax,0x1aeba(%rip)        # 20be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab ae 01 00 	mov    %rax,0x1aeab(%rip)        # 20be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa ae 01 00 	mov    %rax,0x1aeaa(%rip)        # 20be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 ae 01 	addsd  0x1aea6(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e ae 01 	movsd  %xmm0,0x1ae9e(%rip)        # 20bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_data.part.0.constprop.0>:
    5db0:	41 56                	push   %r14
    5db2:	41 89 fe             	mov    %edi,%r14d
    5db5:	41 54                	push   %r12
    5db7:	49 89 f4             	mov    %rsi,%r12
    5dba:	55                   	push   %rbp
    5dbb:	53                   	push   %rbx
    5dbc:	48 83 ec 08          	sub    $0x8,%rsp
    5dc0:	8b 05 9e ad 01 00    	mov    0x1ad9e(%rip),%eax        # 20b64 <fwp_heap+0x13a4>
    5dc6:	85 c0                	test   %eax,%eax
    5dc8:	0f 84 fa 00 00 00    	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5dce:	0f b6 05 8d a9 01 00 	movzbl 0x1a98d(%rip),%eax        # 20762 <fwp_heap+0xfa2>
    5dd5:	48 8d 15 e4 99 01 00 	lea    0x199e4(%rip),%rdx        # 1f7c0 <fwp_heap>
    5ddc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5de3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5de7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5deb:	48 8b 18             	mov    (%rax),%rbx
    5dee:	48 85 db             	test   %rbx,%rbx
    5df1:	0f 84 a9 00 00 00    	je     5ea0 <fwp_data.part.0.constprop.0+0xf0>
    5df7:	48 8b 13             	mov    (%rbx),%rdx
    5dfa:	48 f7 d2             	not    %rdx
    5dfd:	48 89 10             	mov    %rdx,(%rax)
    5e00:	48 83 fd 18          	cmp    $0x18,%rbp
    5e04:	76 1b                	jbe    5e21 <fwp_data.part.0.constprop.0+0x71>
    5e06:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e0a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e0e:	31 f6                	xor    %esi,%esi
    5e10:	48 c1 e8 03          	shr    $0x3,%rax
    5e14:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e1b:	00 
    5e1c:	e8 9f d6 ff ff       	call   34c0 <memset@plt>
    5e21:	48 89 e8             	mov    %rbp,%rax
    5e24:	48 03 05 b5 ad 01 00 	add    0x1adb5(%rip),%rax        # 20be0 <fwp_heap+0x1420>
    5e2b:	0f 82 a8 00 00 00    	jb     5ed9 <fwp_data.part.0.constprop.0+0x129>
    5e31:	48 39 05 b0 ad 01 00 	cmp    %rax,0x1adb0(%rip)        # 20be8 <fwp_heap+0x1428>
    5e38:	48 89 05 a1 ad 01 00 	mov    %rax,0x1ada1(%rip)        # 20be0 <fwp_heap+0x1420>
    5e3f:	73 07                	jae    5e48 <fwp_data.part.0.constprop.0+0x98>
    5e41:	48 89 05 a0 ad 01 00 	mov    %rax,0x1ada0(%rip)        # 20be8 <fwp_heap+0x1428>
    5e48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e4c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e51:	f2 0f 58 05 9f ad 01 	addsd  0x1ad9f(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 97 ad 01 	movsd  %xmm0,0x1ad97(%rip)        # 20bf8 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	b8 02 00 00 00       	mov    $0x2,%eax
    5e66:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e6b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e6f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e73:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e77:	49 8b 04 24          	mov    (%r12),%rax
    5e7b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e7f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e84:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e88:	48 83 c4 08          	add    $0x8,%rsp
    5e8c:	48 89 d8             	mov    %rbx,%rax
    5e8f:	5b                   	pop    %rbx
    5e90:	5d                   	pop    %rbp
    5e91:	41 5c                	pop    %r12
    5e93:	41 5e                	pop    %r14
    5e95:	c3                   	ret
    5e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e9d:	00 00 00 
    5ea0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5ea4:	48 85 db             	test   %rbx,%rbx
    5ea7:	74 1f                	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5ea9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ead:	48 29 da             	sub    %rbx,%rdx
    5eb0:	48 39 ea             	cmp    %rbp,%rdx
    5eb3:	72 13                	jb     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5eb5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5eb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ebd:	e9 3e ff ff ff       	jmp    5e00 <fwp_data.part.0.constprop.0+0x50>
    5ec2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ec8:	31 f6                	xor    %esi,%esi
    5eca:	bf 18 00 00 00       	mov    $0x18,%edi
    5ecf:	e8 bc fd ff ff       	call   5c90 <fwp_heap_alloc>
    5ed4:	48 89 c3             	mov    %rax,%rbx
    5ed7:	eb 88                	jmp    5e61 <fwp_data.part.0.constprop.0+0xb1>
    5ed9:	e8 d2 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5ede:	66 90                	xchg   %ax,%ax

0000000000005ee0 <fwp_tape_reserve>:
    5ee0:	41 57                	push   %r15
    5ee2:	41 56                	push   %r14
    5ee4:	41 55                	push   %r13
    5ee6:	41 54                	push   %r12
    5ee8:	55                   	push   %rbp
    5ee9:	53                   	push   %rbx
    5eea:	48 83 ec 18          	sub    $0x18,%rsp
    5eee:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    5ef5:	0f 87 d3 01 00 00    	ja     60ce <fwp_tape_reserve+0x1ee>
    5efb:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5eff:	48 89 fd             	mov    %rdi,%rbp
    5f02:	48 39 f3             	cmp    %rsi,%rbx
    5f05:	0f 8d 13 01 00 00    	jge    601e <fwp_tape_reserve+0x13e>
    5f0b:	48 85 db             	test   %rbx,%rbx
    5f0e:	b8 40 00 00 00       	mov    $0x40,%eax
    5f13:	48 0f 44 d8          	cmove  %rax,%rbx
    5f17:	48 39 f3             	cmp    %rsi,%rbx
    5f1a:	7d 24                	jge    5f40 <fwp_tape_reserve+0x60>
    5f1c:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5f23:	0f 8f 07 01 00 00    	jg     6030 <fwp_tape_reserve+0x150>
    5f29:	48 01 db             	add    %rbx,%rbx
    5f2c:	48 39 f3             	cmp    %rsi,%rbx
    5f2f:	7c eb                	jl     5f1c <fwp_tape_reserve+0x3c>
    5f31:	0f 1f 40 00          	nopl   0x0(%rax)
    5f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f3c:	00 00 00 00 
    5f40:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    5f47:	00 
    5f48:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5f4c:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    5f50:	4c 89 ee             	mov    %r13,%rsi
    5f53:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    5f57:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    5f5b:	e8 70 d6 ff ff       	call   35d0 <realloc@plt>
    5f60:	48 85 c0             	test   %rax,%rax
    5f63:	0f 84 71 01 00 00    	je     60da <fwp_tape_reserve+0x1fa>
    5f69:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5f6d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5f71:	4d 29 fc             	sub    %r15,%r12
    5f74:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5f78:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    5f7c:	4d 85 f6             	test   %r14,%r14
    5f7f:	0f 84 03 01 00 00    	je     6088 <fwp_tape_reserve+0x1a8>
    5f85:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5f89:	48 39 da             	cmp    %rbx,%rdx
    5f8c:	7d 78                	jge    6006 <fwp_tape_reserve+0x126>
    5f8e:	48 89 d9             	mov    %rbx,%rcx
    5f91:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    5f95:	be 02 00 00 00       	mov    $0x2,%esi
    5f9a:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5f9f:	48 c1 e1 04          	shl    $0x4,%rcx
    5fa3:	48 89 cf             	mov    %rcx,%rdi
    5fa6:	48 89 0c 24          	mov    %rcx,(%rsp)
    5faa:	e8 e1 fc ff ff       	call   5c90 <fwp_heap_alloc>
    5faf:	49 89 c5             	mov    %rax,%r13
    5fb2:	4d 85 ff             	test   %r15,%r15
    5fb5:	74 27                	je     5fde <fwp_tape_reserve+0xfe>
    5fb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5fbc:	48 8b 0c 24          	mov    (%rsp),%rcx
    5fc0:	48 89 c7             	mov    %rax,%rdi
    5fc3:	4c 89 fe             	mov    %r15,%rsi
    5fc6:	48 c1 e2 04          	shl    $0x4,%rdx
    5fca:	48 39 ca             	cmp    %rcx,%rdx
    5fcd:	48 0f 47 d1          	cmova  %rcx,%rdx
    5fd1:	e8 ca d5 ff ff       	call   35a0 <memcpy@plt>
    5fd6:	4c 89 ff             	mov    %r15,%rdi
    5fd9:	e8 b2 f7 ff ff       	call   5790 <fwp_mem_free>
    5fde:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5fe2:	48 89 da             	mov    %rbx,%rdx
    5fe5:	31 f6                	xor    %esi,%esi
    5fe7:	48 29 fa             	sub    %rdi,%rdx
    5fea:	48 c1 e7 04          	shl    $0x4,%rdi
    5fee:	48 c1 e2 04          	shl    $0x4,%rdx
    5ff2:	4c 01 ef             	add    %r13,%rdi
    5ff5:	e8 c6 d4 ff ff       	call   34c0 <memset@plt>
    5ffa:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    5ffe:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6002:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    6006:	4d 85 e4             	test   %r12,%r12
    6009:	75 55                	jne    6060 <fwp_tape_reserve+0x180>
    600b:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6012:	00 
    6013:	4c 01 e8             	add    %r13,%rax
    6016:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    601a:	48 89 45 28          	mov    %rax,0x28(%rbp)
    601e:	48 83 c4 18          	add    $0x18,%rsp
    6022:	5b                   	pop    %rbx
    6023:	5d                   	pop    %rbp
    6024:	41 5c                	pop    %r12
    6026:	41 5d                	pop    %r13
    6028:	41 5e                	pop    %r14
    602a:	41 5f                	pop    %r15
    602c:	c3                   	ret
    602d:	0f 1f 00             	nopl   (%rax)
    6030:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    6035:	e9 06 ff ff ff       	jmp    5f40 <fwp_tape_reserve+0x60>
    603a:	4d 39 f5             	cmp    %r14,%r13
    603d:	4c 89 f1             	mov    %r14,%rcx
    6040:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    6047:	00 
    6048:	49 0f 43 cd          	cmovae %r13,%rcx
    604c:	4c 29 e9             	sub    %r13,%rcx
    604f:	e8 0c d5 ff ff       	call   3560 <__memmove_chk@plt>
    6054:	4c 03 6d 30          	add    0x30(%rbp),%r13
    6058:	48 8b 45 20          	mov    0x20(%rbp),%rax
    605c:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    6060:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    6064:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    606b:	00 
    606c:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    6073:	00 
    6074:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6078:	e8 93 d5 ff ff       	call   3610 <memmove@plt>
    607d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6081:	eb 90                	jmp    6013 <fwp_tape_reserve+0x133>
    6083:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6088:	49 89 de             	mov    %rbx,%r14
    608b:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    608f:	49 c1 e6 04          	shl    $0x4,%r14
    6093:	4c 89 f6             	mov    %r14,%rsi
    6096:	e8 35 d5 ff ff       	call   35d0 <realloc@plt>
    609b:	48 85 c0             	test   %rax,%rax
    609e:	74 3a                	je     60da <fwp_tape_reserve+0x1fa>
    60a0:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    60a4:	48 89 45 30          	mov    %rax,0x30(%rbp)
    60a8:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    60ac:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    60b0:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    60b4:	4d 85 e4             	test   %r12,%r12
    60b7:	75 81                	jne    603a <fwp_tape_reserve+0x15a>
    60b9:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    60bd:	48 8b 45 20          	mov    0x20(%rbp),%rax
    60c1:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    60c8:	00 
    60c9:	e9 45 ff ff ff       	jmp    6013 <fwp_tape_reserve+0x133>
    60ce:	48 8d 3d 77 50 00 00 	lea    0x5077(%rip),%rdi        # b14c <_IO_stdin_used+0x14c>
    60d5:	e8 16 e3 ff ff       	call   43f0 <fwp_trap>
    60da:	48 89 ef             	mov    %rbp,%rdi
    60dd:	e8 1e db ff ff       	call   3c00 <fwp_tape_unlink_scope>
    60e2:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    60e6:	e8 d5 d2 ff ff       	call   33c0 <free@plt>
    60eb:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    60ef:	e8 cc d2 ff ff       	call   33c0 <free@plt>
    60f4:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    60f8:	e8 c3 d2 ff ff       	call   33c0 <free@plt>
    60fd:	31 c9                	xor    %ecx,%ecx
    60ff:	31 c0                	xor    %eax,%eax
    6101:	31 d2                	xor    %edx,%edx
    6103:	89 55 04             	mov    %edx,0x4(%rbp)
    6106:	66 0f ef c0          	pxor   %xmm0,%xmm0
    610a:	ba 13 00 00 00       	mov    $0x13,%edx
    610f:	be 01 00 00 00       	mov    $0x1,%esi
    6114:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    6118:	48 8d 3d e9 4e 00 00 	lea    0x4ee9(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    611f:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    6123:	48 8b 0d 16 8f 00 00 	mov    0x8f16(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    612a:	48 89 45 40          	mov    %rax,0x40(%rbp)
    612e:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6132:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    6136:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    613a:	e8 41 d5 ff ff       	call   3680 <fwrite@plt>
    613f:	31 ff                	xor    %edi,%edi
    6141:	e8 7a d4 ff ff       	call   35c0 <fflush@plt>
    6146:	bf 66 00 00 00       	mov    $0x66,%edi
    614b:	e8 50 d5 ff ff       	call   36a0 <_Exit@plt>

0000000000006150 <f141.constprop.0>:
    6150:	41 57                	push   %r15
    6152:	41 56                	push   %r14
    6154:	41 55                	push   %r13
    6156:	41 54                	push   %r12
    6158:	49 89 f4             	mov    %rsi,%r12
    615b:	55                   	push   %rbp
    615c:	48 89 fd             	mov    %rdi,%rbp
    615f:	53                   	push   %rbx
    6160:	48 83 ec 08          	sub    $0x8,%rsp
    6164:	48 85 ff             	test   %rdi,%rdi
    6167:	79 09                	jns    6172 <f141.constprop.0+0x22>
    6169:	48 85 f6             	test   %rsi,%rsi
    616c:	0f 88 fe 00 00 00    	js     6270 <f141.constprop.0+0x120>
    6172:	48 89 f8             	mov    %rdi,%rax
    6175:	48 09 f0             	or     %rsi,%rax
    6178:	0f 89 d2 00 00 00    	jns    6250 <f141.constprop.0+0x100>
    617e:	48 89 f8             	mov    %rdi,%rax
    6181:	48 c1 f8 20          	sar    $0x20,%rax
    6185:	48 85 ff             	test   %rdi,%rdi
    6188:	0f 88 02 01 00 00    	js     6290 <f141.constprop.0+0x140>
    618e:	4c 8b 3d db 59 00 00 	mov    0x59db(%rip),%r15        # bb70 <msg.4+0xb0>
    6195:	48 89 c7             	mov    %rax,%rdi
    6198:	e8 33 e5 ff ff       	call   46d0 <fwp_tape_of>
    619d:	48 89 c3             	mov    %rax,%rbx
    61a0:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    61a5:	0f 85 16 01 00 00    	jne    62c1 <f141.constprop.0+0x171>
    61ab:	4c 8b 68 10          	mov    0x10(%rax),%r13
    61af:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    61b6:	0f 8f f9 00 00 00    	jg     62b5 <f141.constprop.0+0x165>
    61bc:	89 e8                	mov    %ebp,%eax
    61be:	49 39 c5             	cmp    %rax,%r13
    61c1:	0f 8e e2 00 00 00    	jle    62a9 <f141.constprop.0+0x159>
    61c7:	4d 85 e4             	test   %r12,%r12
    61ca:	78 0c                	js     61d8 <f141.constprop.0+0x88>
    61cc:	44 89 e0             	mov    %r12d,%eax
    61cf:	49 39 c5             	cmp    %rax,%r13
    61d2:	0f 8e d1 00 00 00    	jle    62a9 <f141.constprop.0+0x159>
    61d8:	4d 89 ee             	mov    %r13,%r14
    61db:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    61df:	48 89 df             	mov    %rbx,%rdi
    61e2:	49 8d 76 01          	lea    0x1(%r14),%rsi
    61e6:	e8 f5 fc ff ff       	call   5ee0 <fwp_tape_reserve>
    61eb:	48 8b 43 20          	mov    0x20(%rbx),%rax
    61ef:	4d 85 e4             	test   %r12,%r12
    61f2:	48 8b 0d 77 59 00 00 	mov    0x5977(%rip),%rcx        # bb70 <msg.4+0xb0>
    61f9:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6200:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6204:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6208:	4c 0f 48 e2          	cmovs  %rdx,%r12
    620c:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    6210:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6214:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    6218:	48 8b 43 38          	mov    0x38(%rbx),%rax
    621c:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    6220:	49 8d 45 01          	lea    0x1(%r13),%rax
    6224:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6228:	48 83 c4 08          	add    $0x8,%rsp
    622c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6233:	ff ff ff 
    6236:	48 21 e8             	and    %rbp,%rax
    6239:	5b                   	pop    %rbx
    623a:	5d                   	pop    %rbp
    623b:	4c 09 e8             	or     %r13,%rax
    623e:	41 5c                	pop    %r12
    6240:	41 5d                	pop    %r13
    6242:	41 5e                	pop    %r14
    6244:	41 5f                	pop    %r15
    6246:	c3                   	ret
    6247:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    624e:	00 00 
    6250:	48 89 f0             	mov    %rsi,%rax
    6253:	48 c1 ff 20          	sar    $0x20,%rdi
    6257:	48 c1 f8 20          	sar    $0x20,%rax
    625b:	48 39 c7             	cmp    %rax,%rdi
    625e:	0f 84 2a ff ff ff    	je     618e <f141.constprop.0+0x3e>
    6264:	48 8d 3d 25 56 00 00 	lea    0x5625(%rip),%rdi        # b890 <_IO_stdin_used+0x890>
    626b:	e8 80 e1 ff ff       	call   43f0 <fwp_trap>
    6270:	48 83 c4 08          	add    $0x8,%rsp
    6274:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    627b:	5b                   	pop    %rbx
    627c:	5d                   	pop    %rbp
    627d:	41 5c                	pop    %r12
    627f:	41 5d                	pop    %r13
    6281:	41 5e                	pop    %r14
    6283:	41 5f                	pop    %r15
    6285:	c3                   	ret
    6286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    628d:	00 00 00 
    6290:	48 89 f0             	mov    %rsi,%rax
    6293:	48 89 f5             	mov    %rsi,%rbp
    6296:	45 31 ff             	xor    %r15d,%r15d
    6299:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    62a0:	48 c1 f8 20          	sar    $0x20,%rax
    62a4:	e9 ec fe ff ff       	jmp    6195 <f141.constprop.0+0x45>
    62a9:	48 8d 3d b7 4e 00 00 	lea    0x4eb7(%rip),%rdi        # b167 <_IO_stdin_used+0x167>
    62b0:	e8 3b e1 ff ff       	call   43f0 <fwp_trap>
    62b5:	48 8d 3d 90 4e 00 00 	lea    0x4e90(%rip),%rdi        # b14c <_IO_stdin_used+0x14c>
    62bc:	e8 2f e1 ff ff       	call   43f0 <fwp_trap>
    62c1:	48 8d 3d 10 56 00 00 	lea    0x5610(%rip),%rdi        # b8d8 <_IO_stdin_used+0x8d8>
    62c8:	e8 23 e1 ff ff       	call   43f0 <fwp_trap>
    62cd:	0f 1f 00             	nopl   (%rax)

00000000000062d0 <w120>:
    62d0:	66 0f 28 d0          	movapd %xmm0,%xmm2
    62d4:	41 57                	push   %r15
    62d6:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    62da:	41 56                	push   %r14
    62dc:	41 55                	push   %r13
    62de:	41 54                	push   %r12
    62e0:	49 89 f4             	mov    %rsi,%r12
    62e3:	55                   	push   %rbp
    62e4:	48 89 fd             	mov    %rdi,%rbp
    62e7:	53                   	push   %rbx
    62e8:	48 83 ec 38          	sub    $0x38,%rsp
    62ec:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    62f1:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    62f7:	48 85 ff             	test   %rdi,%rdi
    62fa:	0f 88 d0 04 00 00    	js     67d0 <w120+0x500>
    6300:	49 89 ff             	mov    %rdi,%r15
    6303:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6309:	49 c1 ff 20          	sar    $0x20,%r15
    630d:	4c 89 ff             	mov    %r15,%rdi
    6310:	e8 bb e3 ff ff       	call   46d0 <fwp_tape_of>
    6315:	48 89 c3             	mov    %rax,%rbx
    6318:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    631d:	0f 85 45 05 00 00    	jne    6868 <w120+0x598>
    6323:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6327:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    632e:	0f 8f 28 05 00 00    	jg     685c <w120+0x58c>
    6334:	89 e8                	mov    %ebp,%eax
    6336:	49 39 c5             	cmp    %rax,%r13
    6339:	0f 8e 11 05 00 00    	jle    6850 <w120+0x580>
    633f:	4d 89 ee             	mov    %r13,%r14
    6342:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6346:	48 89 df             	mov    %rbx,%rdi
    6349:	49 8d 76 01          	lea    0x1(%r14),%rsi
    634d:	e8 8e fb ff ff       	call   5ee0 <fwp_tape_reserve>
    6352:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6356:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    635b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6361:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6365:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6369:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    636f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6373:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6377:	48 8b 43 38          	mov    0x38(%rbx),%rax
    637b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6381:	49 8d 45 01          	lea    0x1(%r13),%rax
    6385:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    638c:	ff ff ff 
    638f:	49 21 ee             	and    %rbp,%r14
    6392:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6396:	4d 09 ee             	or     %r13,%r14
    6399:	4d 89 f5             	mov    %r14,%r13
    639c:	49 c1 fd 20          	sar    $0x20,%r13
    63a0:	4d 85 e4             	test   %r12,%r12
    63a3:	78 10                	js     63b5 <w120+0xe5>
    63a5:	4c 89 e0             	mov    %r12,%rax
    63a8:	48 c1 f8 20          	sar    $0x20,%rax
    63ac:	4c 39 e8             	cmp    %r13,%rax
    63af:	0f 85 87 04 00 00    	jne    683c <w120+0x56c>
    63b5:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    63bb:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63c1:	4d 39 ef             	cmp    %r13,%r15
    63c4:	0f 84 d6 03 00 00    	je     67a0 <w120+0x4d0>
    63ca:	f2 0f 10 1d 9e 57 00 	movsd  0x579e(%rip),%xmm3        # bb70 <msg.4+0xb0>
    63d1:	00 
    63d2:	f2 0f 10 25 9e 57 00 	movsd  0x579e(%rip),%xmm4        # bb78 <msg.4+0xb8>
    63d9:	00 
    63da:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    63e0:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    63e6:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    63ec:	4c 89 ef             	mov    %r13,%rdi
    63ef:	e8 dc e2 ff ff       	call   46d0 <fwp_tape_of>
    63f4:	48 89 c3             	mov    %rax,%rbx
    63f7:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63fc:	0f 85 66 04 00 00    	jne    6868 <w120+0x598>
    6402:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6406:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    640d:	0f 8f 49 04 00 00    	jg     685c <w120+0x58c>
    6413:	44 89 f0             	mov    %r14d,%eax
    6416:	49 39 c7             	cmp    %rax,%r15
    6419:	0f 8e 31 04 00 00    	jle    6850 <w120+0x580>
    641f:	4d 85 e4             	test   %r12,%r12
    6422:	78 0c                	js     6430 <w120+0x160>
    6424:	44 89 e0             	mov    %r12d,%eax
    6427:	49 39 c7             	cmp    %rax,%r15
    642a:	0f 8e 20 04 00 00    	jle    6850 <w120+0x580>
    6430:	4c 89 f9             	mov    %r15,%rcx
    6433:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    6437:	48 89 df             	mov    %rbx,%rdi
    643a:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    643e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6443:	e8 98 fa ff ff       	call   5ee0 <fwp_tape_reserve>
    6448:	48 8b 43 20          	mov    0x20(%rbx),%rax
    644c:	4d 85 e4             	test   %r12,%r12
    644f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6453:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6458:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    645e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6464:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6468:	48 8b 43 30          	mov    0x30(%rbx),%rax
    646c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6471:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6478:	49 0f 49 c4          	cmovns %r12,%rax
    647c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6480:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6483:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6487:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    648c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    6490:	48 85 ed             	test   %rbp,%rbp
    6493:	0f 88 0e 04 00 00    	js     68a7 <w120+0x5d7>
    6499:	48 89 e8             	mov    %rbp,%rax
    649c:	48 c1 f8 20          	sar    $0x20,%rax
    64a0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    64a5:	49 39 c5             	cmp    %rax,%r13
    64a8:	74 1a                	je     64c4 <w120+0x1f4>
    64aa:	48 89 c7             	mov    %rax,%rdi
    64ad:	e8 1e e2 ff ff       	call   46d0 <fwp_tape_of>
    64b2:	48 89 c3             	mov    %rax,%rbx
    64b5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    64ba:	0f 85 a8 03 00 00    	jne    6868 <w120+0x598>
    64c0:	4c 8b 60 10          	mov    0x10(%rax),%r12
    64c4:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    64cb:	0f 8f 8b 03 00 00    	jg     685c <w120+0x58c>
    64d1:	89 e8                	mov    %ebp,%eax
    64d3:	4c 39 e0             	cmp    %r12,%rax
    64d6:	0f 8d 74 03 00 00    	jge    6850 <w120+0x580>
    64dc:	4c 89 e0             	mov    %r12,%rax
    64df:	48 2b 43 08          	sub    0x8(%rbx),%rax
    64e3:	48 89 df             	mov    %rbx,%rdi
    64e6:	48 8d 70 01          	lea    0x1(%rax),%rsi
    64ea:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    64ef:	e8 ec f9 ff ff       	call   5ee0 <fwp_tape_reserve>
    64f4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    64f9:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64fd:	48 8b 0d 74 56 00 00 	mov    0x5674(%rip),%rcx        # bb78 <msg.4+0xb8>
    6504:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    650a:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    650d:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6511:	66 0f 28 ee          	movapd %xmm6,%xmm5
    6515:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    651b:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    651f:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    6523:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    6527:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    652e:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    6532:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    6537:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    653c:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6540:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6547:	ff ff ff 
    654a:	48 21 c5             	and    %rax,%rbp
    654d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6553:	4c 09 e5             	or     %r12,%rbp
    6556:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    655d:	ff ff ff 
    6560:	49 21 c6             	and    %rax,%r14
    6563:	4d 09 fe             	or     %r15,%r14
    6566:	4d 89 f4             	mov    %r14,%r12
    6569:	49 c1 fc 20          	sar    $0x20,%r12
    656d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6572:	74 16                	je     658a <w120+0x2ba>
    6574:	4c 89 e7             	mov    %r12,%rdi
    6577:	e8 54 e1 ff ff       	call   46d0 <fwp_tape_of>
    657c:	48 89 c3             	mov    %rax,%rbx
    657f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6584:	0f 85 de 02 00 00    	jne    6868 <w120+0x598>
    658a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    658e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6595:	0f 8f c1 02 00 00    	jg     685c <w120+0x58c>
    659b:	44 89 f0             	mov    %r14d,%eax
    659e:	49 39 c7             	cmp    %rax,%r15
    65a1:	0f 8e a9 02 00 00    	jle    6850 <w120+0x580>
    65a7:	4d 89 fd             	mov    %r15,%r13
    65aa:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    65ae:	48 89 df             	mov    %rbx,%rdi
    65b1:	49 8d 75 01          	lea    0x1(%r13),%rsi
    65b5:	e8 26 f9 ff ff       	call   5ee0 <fwp_tape_reserve>
    65ba:	48 8b 43 20          	mov    0x20(%rbx),%rax
    65be:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    65c4:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    65c8:	48 8b 43 30          	mov    0x30(%rbx),%rax
    65cc:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    65d2:	48 8b 43 28          	mov    0x28(%rbx),%rax
    65d6:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    65da:	48 8b 43 38          	mov    0x38(%rbx),%rax
    65de:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    65e4:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    65e8:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65ef:	ff ff ff 
    65f2:	49 21 c6             	and    %rax,%r14
    65f5:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    65f9:	4d 09 fe             	or     %r15,%r14
    65fc:	4d 89 f7             	mov    %r14,%r15
    65ff:	49 c1 ff 20          	sar    $0x20,%r15
    6603:	4d 39 e7             	cmp    %r12,%r15
    6606:	74 1d                	je     6625 <w120+0x355>
    6608:	4c 89 ff             	mov    %r15,%rdi
    660b:	e8 c0 e0 ff ff       	call   46d0 <fwp_tape_of>
    6610:	48 89 c3             	mov    %rax,%rbx
    6613:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6618:	0f 85 4a 02 00 00    	jne    6868 <w120+0x598>
    661e:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6622:	4d 89 fc             	mov    %r15,%r12
    6625:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    662c:	0f 8f 2a 02 00 00    	jg     685c <w120+0x58c>
    6632:	44 89 f0             	mov    %r14d,%eax
    6635:	4c 39 e8             	cmp    %r13,%rax
    6638:	0f 8d 12 02 00 00    	jge    6850 <w120+0x580>
    663e:	f2 0f 10 3d 3a 55 00 	movsd  0x553a(%rip),%xmm7        # bb80 <msg.4+0xc0>
    6645:	00 
    6646:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    664c:	4d 89 ef             	mov    %r13,%r15
    664f:	48 89 df             	mov    %rbx,%rdi
    6652:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6658:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    665d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6661:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6665:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    666a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6670:	e8 6b f8 ff ff       	call   5ee0 <fwp_tape_reserve>
    6675:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6679:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    667e:	48 8b 15 fb 54 00 00 	mov    0x54fb(%rip),%rdx        # bb80 <msg.4+0xc0>
    6685:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6689:	48 8b 43 30          	mov    0x30(%rbx),%rax
    668d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6691:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6695:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6699:	48 8b 43 28          	mov    0x28(%rbx),%rax
    669d:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    66a4:	ff 
    66a5:	48 8b 43 38          	mov    0x38(%rbx),%rax
    66a9:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    66b0:	00 
    66b1:	49 8d 45 01          	lea    0x1(%r13),%rax
    66b5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    66b9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    66c0:	ff ff ff 
    66c3:	49 21 c6             	and    %rax,%r14
    66c6:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    66cc:	4d 09 ee             	or     %r13,%r14
    66cf:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    66d3:	0f 84 57 01 00 00    	je     6830 <w120+0x560>
    66d9:	48 89 ef             	mov    %rbp,%rdi
    66dc:	48 c1 ff 20          	sar    $0x20,%rdi
    66e0:	4c 39 e7             	cmp    %r12,%rdi
    66e3:	74 13                	je     66f8 <w120+0x428>
    66e5:	e8 e6 df ff ff       	call   46d0 <fwp_tape_of>
    66ea:	48 89 c3             	mov    %rax,%rbx
    66ed:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    66f2:	0f 85 70 01 00 00    	jne    6868 <w120+0x598>
    66f8:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    66fc:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    6703:	0f 8f 53 01 00 00    	jg     685c <w120+0x58c>
    6709:	89 e8                	mov    %ebp,%eax
    670b:	4c 39 e0             	cmp    %r12,%rax
    670e:	0f 8d 3c 01 00 00    	jge    6850 <w120+0x580>
    6714:	4d 89 e5             	mov    %r12,%r13
    6717:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    671b:	48 89 df             	mov    %rbx,%rdi
    671e:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6722:	e8 b9 f7 ff ff       	call   5ee0 <fwp_tape_reserve>
    6727:	48 8b 43 20          	mov    0x20(%rbx),%rax
    672b:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6730:	48 89 ef             	mov    %rbp,%rdi
    6733:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6737:	48 8b 43 30          	mov    0x30(%rbx),%rax
    673b:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6741:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6745:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6749:	48 8b 43 38          	mov    0x38(%rbx),%rax
    674d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6753:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6758:	48 89 43 10          	mov    %rax,0x10(%rbx)
    675c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6763:	ff ff ff 
    6766:	48 21 c7             	and    %rax,%rdi
    6769:	4c 09 e7             	or     %r12,%rdi
    676c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6772:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6778:	4c 89 f6             	mov    %r14,%rsi
    677b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6780:	e8 cb f9 ff ff       	call   6150 <f141.constprop.0>
    6785:	48 83 c4 38          	add    $0x38,%rsp
    6789:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    678e:	5b                   	pop    %rbx
    678f:	5d                   	pop    %rbp
    6790:	41 5c                	pop    %r12
    6792:	41 5d                	pop    %r13
    6794:	41 5e                	pop    %r14
    6796:	41 5f                	pop    %r15
    6798:	c3                   	ret
    6799:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    67a0:	f2 0f 10 3d c8 53 00 	movsd  0x53c8(%rip),%xmm7        # bb70 <msg.4+0xb0>
    67a7:	00 
    67a8:	f2 0f 10 15 c8 53 00 	movsd  0x53c8(%rip),%xmm2        # bb78 <msg.4+0xb8>
    67af:	00 
    67b0:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    67b6:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    67bc:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    67c2:	e9 3b fc ff ff       	jmp    6402 <w120+0x132>
    67c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    67ce:	00 00 
    67d0:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    67d6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    67dc:	48 85 f6             	test   %rsi,%rsi
    67df:	0f 89 8f 00 00 00    	jns    6874 <w120+0x5a4>
    67e5:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    67eb:	f2 0f 10 05 7d 53 00 	movsd  0x537d(%rip),%xmm0        # bb70 <msg.4+0xb0>
    67f2:	00 
    67f3:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    67fa:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6801:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    6806:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    680a:	f2 0f 59 0d 6e 53 00 	mulsd  0x536e(%rip),%xmm1        # bb80 <msg.4+0xc0>
    6811:	00 
    6812:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6816:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    681c:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6822:	e9 45 ff ff ff       	jmp    676c <w120+0x49c>
    6827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    682e:	00 00 
    6830:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6837:	e9 30 ff ff ff       	jmp    676c <w120+0x49c>
    683c:	48 8d 3d 4d 50 00 00 	lea    0x504d(%rip),%rdi        # b890 <_IO_stdin_used+0x890>
    6843:	e8 a8 db ff ff       	call   43f0 <fwp_trap>
    6848:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    684f:	00 
    6850:	48 8d 3d 10 49 00 00 	lea    0x4910(%rip),%rdi        # b167 <_IO_stdin_used+0x167>
    6857:	e8 94 db ff ff       	call   43f0 <fwp_trap>
    685c:	48 8d 3d e9 48 00 00 	lea    0x48e9(%rip),%rdi        # b14c <_IO_stdin_used+0x14c>
    6863:	e8 88 db ff ff       	call   43f0 <fwp_trap>
    6868:	48 8d 3d 69 50 00 00 	lea    0x5069(%rip),%rdi        # b8d8 <_IO_stdin_used+0x8d8>
    686f:	e8 7c db ff ff       	call   43f0 <fwp_trap>
    6874:	f2 0f 10 35 f4 52 00 	movsd  0x52f4(%rip),%xmm6        # bb70 <msg.4+0xb0>
    687b:	00 
    687c:	49 89 f5             	mov    %rsi,%r13
    687f:	49 89 f6             	mov    %rsi,%r14
    6882:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6889:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6890:	00 00 
    6892:	49 c1 fd 20          	sar    $0x20,%r13
    6896:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    689c:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    68a2:	e9 45 fb ff ff       	jmp    63ec <w120+0x11c>
    68a7:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    68ad:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    68b2:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    68b9:	66 0f 28 f4          	movapd %xmm4,%xmm6
    68bd:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    68c1:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    68c7:	e9 8a fc ff ff       	jmp    6556 <w120+0x286>
    68cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000068d0 <fwp_rc_share>:
    68d0:	48 8b 05 c1 a2 01 00 	mov    0x1a2c1(%rip),%rax        # 20b98 <fwp_heap+0x13d8>
    68d7:	48 2b 3d 92 a2 01 00 	sub    0x1a292(%rip),%rdi        # 20b70 <fwp_heap+0x13b0>
    68de:	48 c1 e0 10          	shl    $0x10,%rax
    68e2:	48 39 c7             	cmp    %rax,%rdi
    68e5:	73 4a                	jae    6931 <fwp_rc_share+0x61>
    68e7:	48 89 f8             	mov    %rdi,%rax
    68ea:	48 c1 e8 10          	shr    $0x10,%rax
    68ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    68f2:	48 8b 05 bf a2 01 00 	mov    0x1a2bf(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    68f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    68fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6901:	48 85 d2             	test   %rdx,%rdx
    6904:	74 2b                	je     6931 <fwp_rc_share+0x61>
    6906:	0f b6 08             	movzbl (%rax),%ecx
    6909:	80 f9 02             	cmp    $0x2,%cl
    690c:	74 2a                	je     6938 <fwp_rc_share+0x68>
    690e:	80 f9 01             	cmp    $0x1,%cl
    6911:	75 1e                	jne    6931 <fwp_rc_share+0x61>
    6913:	8b 48 18             	mov    0x18(%rax),%ecx
    6916:	0f b7 ff             	movzwl %di,%edi
    6919:	8b 40 1c             	mov    0x1c(%rax),%eax
    691c:	48 0f af f9          	imul   %rcx,%rdi
    6920:	48 c1 ef 20          	shr    $0x20,%rdi
    6924:	48 39 c7             	cmp    %rax,%rdi
    6927:	73 08                	jae    6931 <fwp_rc_share+0x61>
    6929:	48 01 fa             	add    %rdi,%rdx
    692c:	80 3a 00             	cmpb   $0x0,(%rdx)
    692f:	75 0d                	jne    693e <fwp_rc_share+0x6e>
    6931:	c3                   	ret
    6932:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6938:	66 85 ff             	test   %di,%di
    693b:	74 ef                	je     692c <fwp_rc_share+0x5c>
    693d:	c3                   	ret
    693e:	50                   	push   %rax
    693f:	48 8d 3d c2 4f 00 00 	lea    0x4fc2(%rip),%rdi        # b908 <_IO_stdin_used+0x908>
    6946:	e8 a5 da ff ff       	call   43f0 <fwp_trap>
    694b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006950 <fwp_rc_free_obj>:
    6950:	48 8b 15 41 a2 01 00 	mov    0x1a241(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    6957:	48 89 f8             	mov    %rdi,%rax
    695a:	48 2b 05 0f a2 01 00 	sub    0x1a20f(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    6961:	48 c1 e2 10          	shl    $0x10,%rdx
    6965:	48 39 d0             	cmp    %rdx,%rax
    6968:	73 5b                	jae    69c5 <fwp_rc_free_obj+0x75>
    696a:	48 89 c2             	mov    %rax,%rdx
    696d:	48 c1 ea 10          	shr    $0x10,%rdx
    6971:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6975:	48 8b 15 3c a2 01 00 	mov    0x1a23c(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    697c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6980:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6984:	48 85 c9             	test   %rcx,%rcx
    6987:	74 3c                	je     69c5 <fwp_rc_free_obj+0x75>
    6989:	0f b6 32             	movzbl (%rdx),%esi
    698c:	40 80 fe 02          	cmp    $0x2,%sil
    6990:	74 2e                	je     69c0 <fwp_rc_free_obj+0x70>
    6992:	40 80 fe 01          	cmp    $0x1,%sil
    6996:	75 2d                	jne    69c5 <fwp_rc_free_obj+0x75>
    6998:	8b 72 18             	mov    0x18(%rdx),%esi
    699b:	0f b7 c0             	movzwl %ax,%eax
    699e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69a1:	48 0f af c6          	imul   %rsi,%rax
    69a5:	48 c1 e8 20          	shr    $0x20,%rax
    69a9:	48 39 d0             	cmp    %rdx,%rax
    69ac:	73 17                	jae    69c5 <fwp_rc_free_obj+0x75>
    69ae:	48 01 c1             	add    %rax,%rcx
    69b1:	80 39 01             	cmpb   $0x1,(%rcx)
    69b4:	75 0f                	jne    69c5 <fwp_rc_free_obj+0x75>
    69b6:	e9 d5 ed ff ff       	jmp    5790 <fwp_mem_free>
    69bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    69c0:	66 85 c0             	test   %ax,%ax
    69c3:	74 ec                	je     69b1 <fwp_rc_free_obj+0x61>
    69c5:	c3                   	ret
    69c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69cd:	00 00 00 

00000000000069d0 <fwp_rc_dup>:
    69d0:	f3 0f 1e fa          	endbr64
    69d4:	48 8b 05 bd a1 01 00 	mov    0x1a1bd(%rip),%rax        # 20b98 <fwp_heap+0x13d8>
    69db:	48 2b 3d 8e a1 01 00 	sub    0x1a18e(%rip),%rdi        # 20b70 <fwp_heap+0x13b0>
    69e2:	48 c1 e0 10          	shl    $0x10,%rax
    69e6:	48 39 c7             	cmp    %rax,%rdi
    69e9:	73 56                	jae    6a41 <fwp_rc_dup+0x71>
    69eb:	48 89 f8             	mov    %rdi,%rax
    69ee:	48 c1 e8 10          	shr    $0x10,%rax
    69f2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    69f6:	48 8b 05 bb a1 01 00 	mov    0x1a1bb(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    69fd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6a01:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6a05:	48 85 c0             	test   %rax,%rax
    6a08:	74 37                	je     6a41 <fwp_rc_dup+0x71>
    6a0a:	0f b6 0a             	movzbl (%rdx),%ecx
    6a0d:	80 f9 02             	cmp    $0x2,%cl
    6a10:	74 36                	je     6a48 <fwp_rc_dup+0x78>
    6a12:	80 f9 01             	cmp    $0x1,%cl
    6a15:	75 2a                	jne    6a41 <fwp_rc_dup+0x71>
    6a17:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6a1a:	0f b7 ff             	movzwl %di,%edi
    6a1d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a20:	48 0f af f9          	imul   %rcx,%rdi
    6a24:	48 c1 ef 20          	shr    $0x20,%rdi
    6a28:	48 39 d7             	cmp    %rdx,%rdi
    6a2b:	73 14                	jae    6a41 <fwp_rc_dup+0x71>
    6a2d:	48 01 f8             	add    %rdi,%rax
    6a30:	0f b6 10             	movzbl (%rax),%edx
    6a33:	84 d2                	test   %dl,%dl
    6a35:	74 0a                	je     6a41 <fwp_rc_dup+0x71>
    6a37:	80 fa fd             	cmp    $0xfd,%dl
    6a3a:	77 14                	ja     6a50 <fwp_rc_dup+0x80>
    6a3c:	83 c2 01             	add    $0x1,%edx
    6a3f:	88 10                	mov    %dl,(%rax)
    6a41:	c3                   	ret
    6a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a48:	66 85 ff             	test   %di,%di
    6a4b:	74 e3                	je     6a30 <fwp_rc_dup+0x60>
    6a4d:	c3                   	ret
    6a4e:	66 90                	xchg   %ax,%ax
    6a50:	48 89 c7             	mov    %rax,%rdi
    6a53:	e9 d8 e9 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6a58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a5f:	00 

0000000000006a60 <fwp_owned_entry173>:
    6a60:	f3 0f 1e fa          	endbr64
    6a64:	48 83 ec 38          	sub    $0x38,%rsp
    6a68:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6a6d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6a74:	00 00 
    6a76:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6a7b:	31 c0                	xor    %eax,%eax
    6a7d:	48 8b 07             	mov    (%rdi),%rax
    6a80:	48 03 47 10          	add    0x10(%rdi),%rax
    6a84:	0f 80 c2 00 00 00    	jo     6b4c <fwp_owned_entry173+0xec>
    6a8a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6a8f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6a94:	31 ff                	xor    %edi,%edi
    6a96:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6a9a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6a9f:	e8 0c f3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    6aa4:	48 8b 15 ed a0 01 00 	mov    0x1a0ed(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    6aab:	48 89 c6             	mov    %rax,%rsi
    6aae:	48 2b 05 bb a0 01 00 	sub    0x1a0bb(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    6ab5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ab9:	48 39 d0             	cmp    %rdx,%rax
    6abc:	73 4f                	jae    6b0d <fwp_owned_entry173+0xad>
    6abe:	48 89 c2             	mov    %rax,%rdx
    6ac1:	48 c1 ea 10          	shr    $0x10,%rdx
    6ac5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ac9:	48 8b 15 e8 a0 01 00 	mov    0x1a0e8(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    6ad0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ad4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ad8:	48 85 d2             	test   %rdx,%rdx
    6adb:	74 30                	je     6b0d <fwp_owned_entry173+0xad>
    6add:	0f b6 39             	movzbl (%rcx),%edi
    6ae0:	40 80 ff 02          	cmp    $0x2,%dil
    6ae4:	74 42                	je     6b28 <fwp_owned_entry173+0xc8>
    6ae6:	40 80 ff 01          	cmp    $0x1,%dil
    6aea:	75 21                	jne    6b0d <fwp_owned_entry173+0xad>
    6aec:	8b 79 18             	mov    0x18(%rcx),%edi
    6aef:	0f b7 c0             	movzwl %ax,%eax
    6af2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6af5:	48 0f af c7          	imul   %rdi,%rax
    6af9:	48 c1 e8 20          	shr    $0x20,%rax
    6afd:	48 39 c8             	cmp    %rcx,%rax
    6b00:	73 0b                	jae    6b0d <fwp_owned_entry173+0xad>
    6b02:	48 01 c2             	add    %rax,%rdx
    6b05:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b08:	74 26                	je     6b30 <fwp_owned_entry173+0xd0>
    6b0a:	c6 02 01             	movb   $0x1,(%rdx)
    6b0d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b12:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b19:	00 00 
    6b1b:	75 34                	jne    6b51 <fwp_owned_entry173+0xf1>
    6b1d:	48 89 f0             	mov    %rsi,%rax
    6b20:	48 83 c4 38          	add    $0x38,%rsp
    6b24:	c3                   	ret
    6b25:	0f 1f 00             	nopl   (%rax)
    6b28:	66 85 c0             	test   %ax,%ax
    6b2b:	75 e0                	jne    6b0d <fwp_owned_entry173+0xad>
    6b2d:	eb d6                	jmp    6b05 <fwp_owned_entry173+0xa5>
    6b2f:	90                   	nop
    6b30:	48 89 d7             	mov    %rdx,%rdi
    6b33:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b38:	48 89 14 24          	mov    %rdx,(%rsp)
    6b3c:	e8 0f ea ff ff       	call   5550 <fwp_rc_forget_slot>
    6b41:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6b46:	48 8b 14 24          	mov    (%rsp),%rdx
    6b4a:	eb be                	jmp    6b0a <fwp_owned_entry173+0xaa>
    6b4c:	e8 af cb ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6b51:	e8 0a c9 ff ff       	call   3460 <__stack_chk_fail@plt>
    6b56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b5d:	00 00 00 

0000000000006b60 <e173>:
    6b60:	f3 0f 1e fa          	endbr64
    6b64:	53                   	push   %rbx
    6b65:	48 83 ec 30          	sub    $0x30,%rsp
    6b69:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6b6e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b75:	00 00 
    6b77:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6b7c:	31 c0                	xor    %eax,%eax
    6b7e:	48 8b 07             	mov    (%rdi),%rax
    6b81:	48 03 47 10          	add    0x10(%rdi),%rax
    6b85:	0f 80 c9 00 00 00    	jo     6c54 <e173+0xf4>
    6b8b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6b90:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6b95:	31 ff                	xor    %edi,%edi
    6b97:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6b9b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ba0:	e8 0b f2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    6ba5:	48 8b 15 ec 9f 01 00 	mov    0x19fec(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    6bac:	48 89 c3             	mov    %rax,%rbx
    6baf:	48 2b 05 ba 9f 01 00 	sub    0x19fba(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    6bb6:	48 c1 e2 10          	shl    $0x10,%rdx
    6bba:	48 39 d0             	cmp    %rdx,%rax
    6bbd:	73 4f                	jae    6c0e <e173+0xae>
    6bbf:	48 89 c2             	mov    %rax,%rdx
    6bc2:	48 c1 ea 10          	shr    $0x10,%rdx
    6bc6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bca:	48 8b 15 e7 9f 01 00 	mov    0x19fe7(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    6bd1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bd5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bd9:	48 85 d2             	test   %rdx,%rdx
    6bdc:	74 30                	je     6c0e <e173+0xae>
    6bde:	0f b6 31             	movzbl (%rcx),%esi
    6be1:	40 80 fe 02          	cmp    $0x2,%sil
    6be5:	74 49                	je     6c30 <e173+0xd0>
    6be7:	40 80 fe 01          	cmp    $0x1,%sil
    6beb:	75 21                	jne    6c0e <e173+0xae>
    6bed:	8b 71 18             	mov    0x18(%rcx),%esi
    6bf0:	0f b7 c0             	movzwl %ax,%eax
    6bf3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6bf6:	48 0f af c6          	imul   %rsi,%rax
    6bfa:	48 c1 e8 20          	shr    $0x20,%rax
    6bfe:	48 39 c8             	cmp    %rcx,%rax
    6c01:	73 0b                	jae    6c0e <e173+0xae>
    6c03:	48 01 c2             	add    %rax,%rdx
    6c06:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c09:	74 35                	je     6c40 <e173+0xe0>
    6c0b:	c6 02 01             	movb   $0x1,(%rdx)
    6c0e:	48 89 df             	mov    %rbx,%rdi
    6c11:	e8 ba fc ff ff       	call   68d0 <fwp_rc_share>
    6c16:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c1b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c22:	00 00 
    6c24:	75 33                	jne    6c59 <e173+0xf9>
    6c26:	48 83 c4 30          	add    $0x30,%rsp
    6c2a:	48 89 d8             	mov    %rbx,%rax
    6c2d:	5b                   	pop    %rbx
    6c2e:	c3                   	ret
    6c2f:	90                   	nop
    6c30:	66 85 c0             	test   %ax,%ax
    6c33:	75 d9                	jne    6c0e <e173+0xae>
    6c35:	eb cf                	jmp    6c06 <e173+0xa6>
    6c37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c3e:	00 00 
    6c40:	48 89 d7             	mov    %rdx,%rdi
    6c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c48:	e8 03 e9 ff ff       	call   5550 <fwp_rc_forget_slot>
    6c4d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c52:	eb b7                	jmp    6c0b <e173+0xab>
    6c54:	e8 a7 ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6c59:	e8 02 c8 ff ff       	call   3460 <__stack_chk_fail@plt>
    6c5e:	66 90                	xchg   %ax,%ax

0000000000006c60 <fwp_closure_drop>:
    6c60:	48 8b 15 31 9f 01 00 	mov    0x19f31(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    6c67:	48 89 f8             	mov    %rdi,%rax
    6c6a:	48 2b 05 ff 9e 01 00 	sub    0x19eff(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    6c71:	48 c1 e2 10          	shl    $0x10,%rdx
    6c75:	48 39 d0             	cmp    %rdx,%rax
    6c78:	73 6b                	jae    6ce5 <fwp_closure_drop+0x85>
    6c7a:	48 89 c2             	mov    %rax,%rdx
    6c7d:	48 c1 ea 10          	shr    $0x10,%rdx
    6c81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c85:	48 8b 15 2c 9f 01 00 	mov    0x19f2c(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    6c8c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c90:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c94:	48 85 d2             	test   %rdx,%rdx
    6c97:	74 4c                	je     6ce5 <fwp_closure_drop+0x85>
    6c99:	0f b6 31             	movzbl (%rcx),%esi
    6c9c:	40 80 fe 02          	cmp    $0x2,%sil
    6ca0:	74 3e                	je     6ce0 <fwp_closure_drop+0x80>
    6ca2:	40 80 fe 01          	cmp    $0x1,%sil
    6ca6:	75 3d                	jne    6ce5 <fwp_closure_drop+0x85>
    6ca8:	8b 71 18             	mov    0x18(%rcx),%esi
    6cab:	0f b7 c0             	movzwl %ax,%eax
    6cae:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6cb1:	48 0f af c6          	imul   %rsi,%rax
    6cb5:	48 c1 e8 20          	shr    $0x20,%rax
    6cb9:	48 39 c8             	cmp    %rcx,%rax
    6cbc:	73 27                	jae    6ce5 <fwp_closure_drop+0x85>
    6cbe:	48 01 c2             	add    %rax,%rdx
    6cc1:	0f b6 02             	movzbl (%rdx),%eax
    6cc4:	84 c0                	test   %al,%al
    6cc6:	74 1d                	je     6ce5 <fwp_closure_drop+0x85>
    6cc8:	3c 01                	cmp    $0x1,%al
    6cca:	74 24                	je     6cf0 <fwp_closure_drop+0x90>
    6ccc:	3c ff                	cmp    $0xff,%al
    6cce:	74 48                	je     6d18 <fwp_closure_drop+0xb8>
    6cd0:	83 e8 01             	sub    $0x1,%eax
    6cd3:	88 02                	mov    %al,(%rdx)
    6cd5:	c3                   	ret
    6cd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cdd:	00 00 00 
    6ce0:	66 85 c0             	test   %ax,%ax
    6ce3:	74 dc                	je     6cc1 <fwp_closure_drop+0x61>
    6ce5:	c3                   	ret
    6ce6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ced:	00 00 00 
    6cf0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6cf7:	ff ff 
    6cf9:	48 85 c0             	test   %rax,%rax
    6cfc:	74 12                	je     6d10 <fwp_closure_drop+0xb0>
    6cfe:	48 89 fe             	mov    %rdi,%rsi
    6d01:	48 89 c7             	mov    %rax,%rdi
    6d04:	e9 47 d7 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d10:	e9 eb d8 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6d15:	0f 1f 00             	nopl   (%rax)
    6d18:	48 89 d0             	mov    %rdx,%rax
    6d1b:	48 8d 35 9e 8a 01 00 	lea    0x18a9e(%rip),%rsi        # 1f7c0 <fwp_heap>
    6d22:	48 83 ec 18          	sub    $0x18,%rsp
    6d26:	48 c1 e8 11          	shr    $0x11,%rax
    6d2a:	48 31 d0             	xor    %rdx,%rax
    6d2d:	48 89 c1             	mov    %rax,%rcx
    6d30:	48 c1 e9 09          	shr    $0x9,%rcx
    6d34:	48 31 c8             	xor    %rcx,%rax
    6d37:	0f b6 c8             	movzbl %al,%ecx
    6d3a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6d41:	00 
    6d42:	48 85 c0             	test   %rax,%rax
    6d45:	75 22                	jne    6d69 <fwp_closure_drop+0x109>
    6d47:	eb 59                	jmp    6da2 <fwp_closure_drop+0x142>
    6d49:	90                   	nop
    6d4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d51:	00 00 00 00 
    6d55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d5c:	00 00 00 00 
    6d60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6d64:	48 85 c0             	test   %rax,%rax
    6d67:	74 39                	je     6da2 <fwp_closure_drop+0x142>
    6d69:	48 89 c1             	mov    %rax,%rcx
    6d6c:	48 39 10             	cmp    %rdx,(%rax)
    6d6f:	75 ef                	jne    6d60 <fwp_closure_drop+0x100>
    6d71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6d79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6d7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d84:	74 05                	je     6d8b <fwp_closure_drop+0x12b>
    6d86:	48 83 c4 18          	add    $0x18,%rsp
    6d8a:	c3                   	ret
    6d8b:	48 89 d7             	mov    %rdx,%rdi
    6d8e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d93:	e8 b8 e7 ff ff       	call   5550 <fwp_rc_forget_slot>
    6d98:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d9d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6da0:	eb e4                	jmp    6d86 <fwp_closure_drop+0x126>
    6da2:	48 8d 3d bf 4a 00 00 	lea    0x4abf(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    6da9:	e8 42 d6 ff ff       	call   43f0 <fwp_trap>
    6dae:	66 90                	xchg   %ax,%ax

0000000000006db0 <fwp_owned_tape_release>:
    6db0:	48 85 ff             	test   %rdi,%rdi
    6db3:	0f 84 f7 00 00 00    	je     6eb0 <fwp_owned_tape_release+0x100>
    6db9:	41 54                	push   %r12
    6dbb:	55                   	push   %rbp
    6dbc:	53                   	push   %rbx
    6dbd:	48 8b 07             	mov    (%rdi),%rax
    6dc0:	48 85 c0             	test   %rax,%rax
    6dc3:	74 08                	je     6dcd <fwp_owned_tape_release+0x1d>
    6dc5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6dc9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6dcd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6dd1:	48 85 d2             	test   %rdx,%rdx
    6dd4:	74 03                	je     6dd9 <fwp_owned_tape_release+0x29>
    6dd6:	48 89 02             	mov    %rax,(%rdx)
    6dd9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6ddd:	48 89 fb             	mov    %rdi,%rbx
    6de0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6de4:	48 85 c0             	test   %rax,%rax
    6de7:	0f 84 89 00 00 00    	je     6e76 <fwp_owned_tape_release+0xc6>
    6ded:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6df1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6df5:	7e 47                	jle    6e3e <fwp_owned_tape_release+0x8e>
    6df7:	31 ed                	xor    %ebp,%ebp
    6df9:	eb 0d                	jmp    6e08 <fwp_owned_tape_release+0x58>
    6dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6e00:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e04:	48 8b 40 68          	mov    0x68(%rax),%rax
    6e08:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6e0c:	49 89 ec             	mov    %rbp,%r12
    6e0f:	48 83 c5 01          	add    $0x1,%rbp
    6e13:	49 c1 e4 04          	shl    $0x4,%r12
    6e17:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6e1b:	ff d0                	call   *%rax
    6e1d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6e21:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6e26:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e2a:	ff 50 68             	call   *0x68(%rax)
    6e2d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6e31:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6e35:	48 39 e8             	cmp    %rbp,%rax
    6e38:	7f c6                	jg     6e00 <fwp_owned_tape_release+0x50>
    6e3a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e3e:	31 ed                	xor    %ebp,%ebp
    6e40:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6e45:	7e 28                	jle    6e6f <fwp_owned_tape_release+0xbf>
    6e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e4e:	00 00 
    6e50:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6e54:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6e58:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6e5c:	74 07                	je     6e65 <fwp_owned_tape_release+0xb5>
    6e5e:	ff 52 68             	call   *0x68(%rdx)
    6e61:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e65:	48 83 c5 01          	add    $0x1,%rbp
    6e69:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6e6d:	7f e1                	jg     6e50 <fwp_owned_tape_release+0xa0>
    6e6f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6e73:	ff 52 68             	call   *0x68(%rdx)
    6e76:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6e7a:	e8 e1 fd ff ff       	call   6c60 <fwp_closure_drop>
    6e7f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6e83:	e8 d8 fd ff ff       	call   6c60 <fwp_closure_drop>
    6e88:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6e8c:	e8 cf fd ff ff       	call   6c60 <fwp_closure_drop>
    6e91:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6e95:	e8 f6 e8 ff ff       	call   5790 <fwp_mem_free>
    6e9a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6e9e:	e8 ed e8 ff ff       	call   5790 <fwp_mem_free>
    6ea3:	48 89 df             	mov    %rbx,%rdi
    6ea6:	5b                   	pop    %rbx
    6ea7:	5d                   	pop    %rbp
    6ea8:	41 5c                	pop    %r12
    6eaa:	e9 e1 e8 ff ff       	jmp    5790 <fwp_mem_free>
    6eaf:	90                   	nop
    6eb0:	c3                   	ret
    6eb1:	0f 1f 40 00          	nopl   0x0(%rax)
    6eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ebc:	00 00 00 00 

0000000000006ec0 <fwp_tape_finish>:
    6ec0:	f3 0f 1e fa          	endbr64
    6ec4:	41 56                	push   %r14
    6ec6:	48 8d 3d d3 81 01 00 	lea    0x181d3(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    6ecd:	41 55                	push   %r13
    6ecf:	41 54                	push   %r12
    6ed1:	55                   	push   %rbp
    6ed2:	53                   	push   %rbx
    6ed3:	e8 38 d2 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6ed8:	48 83 3d 08 82 01 00 	cmpq   $0x0,0x18208(%rip)        # 1f0e8 <fwp_ntapes>
    6edf:	00 
    6ee0:	48 c7 05 9d 81 01 00 	movq   $0x0,0x1819d(%rip)        # 1f088 <fwp_tape_cached_bytes>
    6ee7:	00 00 00 00 
    6eeb:	7e 68                	jle    6f55 <fwp_tape_finish+0x95>
    6eed:	45 31 e4             	xor    %r12d,%r12d
    6ef0:	31 ed                	xor    %ebp,%ebp
    6ef2:	0f 1f 00             	nopl   (%rax)
    6ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6efc:	00 00 00 00 
    6f00:	48 8b 1d e9 81 01 00 	mov    0x181e9(%rip),%rbx        # 1f0f0 <fwp_tapes>
    6f07:	48 83 c5 01          	add    $0x1,%rbp
    6f0b:	4c 01 e3             	add    %r12,%rbx
    6f0e:	49 83 c4 68          	add    $0x68,%r12
    6f12:	48 89 df             	mov    %rbx,%rdi
    6f15:	e8 e6 cc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6f1a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6f1e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6f22:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6f26:	e8 95 c4 ff ff       	call   33c0 <free@plt>
    6f2b:	4c 89 f7             	mov    %r14,%rdi
    6f2e:	e8 8d c4 ff ff       	call   33c0 <free@plt>
    6f33:	4c 89 ef             	mov    %r13,%rdi
    6f36:	e8 85 c4 ff ff       	call   33c0 <free@plt>
    6f3b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6f3f:	e8 6c fe ff ff       	call   6db0 <fwp_owned_tape_release>
    6f44:	48 39 2d 9d 81 01 00 	cmp    %rbp,0x1819d(%rip)        # 1f0e8 <fwp_ntapes>
    6f4b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6f52:	00 
    6f53:	7f ab                	jg     6f00 <fwp_tape_finish+0x40>
    6f55:	48 8b 3d 94 81 01 00 	mov    0x18194(%rip),%rdi        # 1f0f0 <fwp_tapes>
    6f5c:	e8 5f c4 ff ff       	call   33c0 <free@plt>
    6f61:	5b                   	pop    %rbx
    6f62:	5d                   	pop    %rbp
    6f63:	48 c7 05 82 81 01 00 	movq   $0x0,0x18182(%rip)        # 1f0f0 <fwp_tapes>
    6f6a:	00 00 00 00 
    6f6e:	48 c7 05 67 81 01 00 	movq   $0x0,0x18167(%rip)        # 1f0e0 <fwp_tapes_cap>
    6f75:	00 00 00 00 
    6f79:	41 5c                	pop    %r12
    6f7b:	48 c7 05 62 81 01 00 	movq   $0x0,0x18162(%rip)        # 1f0e8 <fwp_ntapes>
    6f82:	00 00 00 00 
    6f86:	41 5d                	pop    %r13
    6f88:	48 c7 05 45 81 01 00 	movq   $0x0,0x18145(%rip)        # 1f0d8 <fwp_tape_next_slot>
    6f8f:	00 00 00 00 
    6f93:	41 5e                	pop    %r14
    6f95:	c3                   	ret
    6f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f9d:	00 00 00 

0000000000006fa0 <fwp_tape_scope_release>:
    6fa0:	f3 0f 1e fa          	endbr64
    6fa4:	41 55                	push   %r13
    6fa6:	41 54                	push   %r12
    6fa8:	55                   	push   %rbp
    6fa9:	53                   	push   %rbx
    6faa:	48 83 ec 58          	sub    $0x58,%rsp
    6fae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6fb5:	00 00 
    6fb7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6fbc:	48 63 07             	movslq (%rdi),%rax
    6fbf:	85 c0                	test   %eax,%eax
    6fc1:	0f 88 05 01 00 00    	js     70cc <fwp_tape_scope_release+0x12c>
    6fc7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6fce:	ec c4 4e 
    6fd1:	48 89 fb             	mov    %rdi,%rbx
    6fd4:	eb 3c                	jmp    7012 <fwp_tape_scope_release+0x72>
    6fd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6fdd:	00 00 00 
    6fe0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6fe5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6fe9:	e8 d2 c3 ff ff       	call   33c0 <free@plt>
    6fee:	48 8b 3c 24          	mov    (%rsp),%rdi
    6ff2:	e8 c9 c3 ff ff       	call   33c0 <free@plt>
    6ff7:	4c 89 ef             	mov    %r13,%rdi
    6ffa:	e8 c1 c3 ff ff       	call   33c0 <free@plt>
    6fff:	4c 89 e7             	mov    %r12,%rdi
    7002:	e8 a9 fd ff ff       	call   6db0 <fwp_owned_tape_release>
    7007:	48 63 03             	movslq (%rbx),%rax
    700a:	85 c0                	test   %eax,%eax
    700c:	0f 88 ba 00 00 00    	js     70cc <fwp_tape_scope_release+0x12c>
    7012:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    7016:	48 8b 35 d3 80 01 00 	mov    0x180d3(%rip),%rsi        # 1f0f0 <fwp_tapes>
    701d:	4c 01 c6             	add    %r8,%rsi
    7020:	48 89 f7             	mov    %rsi,%rdi
    7023:	e8 d8 cb ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7028:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    702d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7032:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7039:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    703d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    7041:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7048:	00 
    7049:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    704e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    7052:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    7057:	66 0f ef d2          	pxor   %xmm2,%xmm2
    705b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7060:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7067:	00 
    7068:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    706f:	00 
    7070:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7077:	00 
    7078:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    707d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    7082:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    7086:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    708a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    708e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7094:	77 18                	ja     70ae <fwp_tape_scope_release+0x10e>
    7096:	49 c1 f8 03          	sar    $0x3,%r8
    709a:	4c 0f af c5          	imul   %rbp,%r8
    709e:	4c 3b 05 33 80 01 00 	cmp    0x18033(%rip),%r8        # 1f0d8 <fwp_tape_next_slot>
    70a5:	7d 07                	jge    70ae <fwp_tape_scope_release+0x10e>
    70a7:	4c 89 05 2a 80 01 00 	mov    %r8,0x1802a(%rip)        # 1f0d8 <fwp_tape_next_slot>
    70ae:	4d 85 e4             	test   %r12,%r12
    70b1:	0f 85 29 ff ff ff    	jne    6fe0 <fwp_tape_scope_release+0x40>
    70b7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    70bc:	e8 af df ff ff       	call   5070 <fwp_tape_buffers_release>
    70c1:	48 63 03             	movslq (%rbx),%rax
    70c4:	85 c0                	test   %eax,%eax
    70c6:	0f 89 46 ff ff ff    	jns    7012 <fwp_tape_scope_release+0x72>
    70cc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    70d1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    70d8:	00 00 
    70da:	75 0b                	jne    70e7 <fwp_tape_scope_release+0x147>
    70dc:	48 83 c4 58          	add    $0x58,%rsp
    70e0:	5b                   	pop    %rbx
    70e1:	5d                   	pop    %rbp
    70e2:	41 5c                	pop    %r12
    70e4:	41 5d                	pop    %r13
    70e6:	c3                   	ret
    70e7:	e8 74 c3 ff ff       	call   3460 <__stack_chk_fail@plt>
    70ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000070f0 <fwp_drop4>:
    70f0:	48 8b 0d a1 9a 01 00 	mov    0x19aa1(%rip),%rcx        # 20b98 <fwp_heap+0x13d8>
    70f7:	48 89 f8             	mov    %rdi,%rax
    70fa:	48 2b 05 6f 9a 01 00 	sub    0x19a6f(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7101:	48 c1 e1 10          	shl    $0x10,%rcx
    7105:	48 39 c8             	cmp    %rcx,%rax
    7108:	0f 83 42 01 00 00    	jae    7250 <fwp_drop4+0x160>
    710e:	48 83 ec 18          	sub    $0x18,%rsp
    7112:	48 89 fa             	mov    %rdi,%rdx
    7115:	4c 8d 05 a4 86 01 00 	lea    0x186a4(%rip),%r8        # 1f7c0 <fwp_heap>
    711c:	48 89 c1             	mov    %rax,%rcx
    711f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7126:	48 c1 e9 10          	shr    $0x10,%rcx
    712a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    712e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7132:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7136:	48 85 c9             	test   %rcx,%rcx
    7139:	74 40                	je     717b <fwp_drop4+0x8b>
    713b:	0f b6 3e             	movzbl (%rsi),%edi
    713e:	40 80 ff 02          	cmp    $0x2,%dil
    7142:	74 3c                	je     7180 <fwp_drop4+0x90>
    7144:	40 80 ff 01          	cmp    $0x1,%dil
    7148:	75 31                	jne    717b <fwp_drop4+0x8b>
    714a:	8b 7e 18             	mov    0x18(%rsi),%edi
    714d:	0f b7 c0             	movzwl %ax,%eax
    7150:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7153:	48 0f af c7          	imul   %rdi,%rax
    7157:	48 c1 e8 20          	shr    $0x20,%rax
    715b:	48 39 f0             	cmp    %rsi,%rax
    715e:	73 1b                	jae    717b <fwp_drop4+0x8b>
    7160:	48 01 c1             	add    %rax,%rcx
    7163:	0f b6 01             	movzbl (%rcx),%eax
    7166:	84 c0                	test   %al,%al
    7168:	74 11                	je     717b <fwp_drop4+0x8b>
    716a:	3c 01                	cmp    $0x1,%al
    716c:	74 22                	je     7190 <fwp_drop4+0xa0>
    716e:	3c ff                	cmp    $0xff,%al
    7170:	0f 84 0a 01 00 00    	je     7280 <fwp_drop4+0x190>
    7176:	83 e8 01             	sub    $0x1,%eax
    7179:	88 01                	mov    %al,(%rcx)
    717b:	48 83 c4 18          	add    $0x18,%rsp
    717f:	c3                   	ret
    7180:	66 85 c0             	test   %ax,%ax
    7183:	74 de                	je     7163 <fwp_drop4+0x73>
    7185:	48 83 c4 18          	add    $0x18,%rsp
    7189:	c3                   	ret
    718a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7190:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7194:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    719b:	48 89 f8             	mov    %rdi,%rax
    719e:	48 c1 e1 10          	shl    $0x10,%rcx
    71a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    71a9:	48 39 c8             	cmp    %rcx,%rax
    71ac:	73 62                	jae    7210 <fwp_drop4+0x120>
    71ae:	48 89 c1             	mov    %rax,%rcx
    71b1:	48 c1 e9 10          	shr    $0x10,%rcx
    71b5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    71b9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    71bd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    71c1:	48 85 c9             	test   %rcx,%rcx
    71c4:	74 4a                	je     7210 <fwp_drop4+0x120>
    71c6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    71ca:	41 80 f9 02          	cmp    $0x2,%r9b
    71ce:	0f 84 9c 00 00 00    	je     7270 <fwp_drop4+0x180>
    71d4:	41 80 f9 01          	cmp    $0x1,%r9b
    71d8:	75 36                	jne    7210 <fwp_drop4+0x120>
    71da:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    71de:	0f b7 c0             	movzwl %ax,%eax
    71e1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71e4:	49 0f af c1          	imul   %r9,%rax
    71e8:	48 c1 e8 20          	shr    $0x20,%rax
    71ec:	48 39 f0             	cmp    %rsi,%rax
    71ef:	73 1f                	jae    7210 <fwp_drop4+0x120>
    71f1:	48 01 c1             	add    %rax,%rcx
    71f4:	0f b6 01             	movzbl (%rcx),%eax
    71f7:	84 c0                	test   %al,%al
    71f9:	74 15                	je     7210 <fwp_drop4+0x120>
    71fb:	3c 01                	cmp    $0x1,%al
    71fd:	74 59                	je     7258 <fwp_drop4+0x168>
    71ff:	3c ff                	cmp    $0xff,%al
    7201:	0f 84 ff 00 00 00    	je     7306 <fwp_drop4+0x216>
    7207:	83 e8 01             	sub    $0x1,%eax
    720a:	88 01                	mov    %al,(%rcx)
    720c:	0f 1f 40 00          	nopl   0x0(%rax)
    7210:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7214:	48 89 d7             	mov    %rdx,%rdi
    7217:	48 89 0c 24          	mov    %rcx,(%rsp)
    721b:	e8 30 f7 ff ff       	call   6950 <fwp_rc_free_obj>
    7220:	4c 8d 05 99 85 01 00 	lea    0x18599(%rip),%r8        # 1f7c0 <fwp_heap>
    7227:	48 8b 04 24          	mov    (%rsp),%rax
    722b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7232:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7239:	48 c1 e2 10          	shl    $0x10,%rdx
    723d:	48 39 d0             	cmp    %rdx,%rax
    7240:	0f 83 35 ff ff ff    	jae    717b <fwp_drop4+0x8b>
    7246:	48 8b 14 24          	mov    (%rsp),%rdx
    724a:	e9 cd fe ff ff       	jmp    711c <fwp_drop4+0x2c>
    724f:	90                   	nop
    7250:	c3                   	ret
    7251:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7258:	48 89 14 24          	mov    %rdx,(%rsp)
    725c:	e8 ef f6 ff ff       	call   6950 <fwp_rc_free_obj>
    7261:	48 8b 14 24          	mov    (%rsp),%rdx
    7265:	eb a9                	jmp    7210 <fwp_drop4+0x120>
    7267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    726e:	00 00 
    7270:	66 85 c0             	test   %ax,%ax
    7273:	75 9b                	jne    7210 <fwp_drop4+0x120>
    7275:	e9 7a ff ff ff       	jmp    71f4 <fwp_drop4+0x104>
    727a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7280:	48 89 c8             	mov    %rcx,%rax
    7283:	48 c1 e8 11          	shr    $0x11,%rax
    7287:	48 31 c8             	xor    %rcx,%rax
    728a:	48 89 c2             	mov    %rax,%rdx
    728d:	48 c1 ea 09          	shr    $0x9,%rdx
    7291:	48 31 d0             	xor    %rdx,%rax
    7294:	0f b6 d0             	movzbl %al,%edx
    7297:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    729e:	00 
    729f:	48 85 c0             	test   %rax,%rax
    72a2:	75 29                	jne    72cd <fwp_drop4+0x1dd>
    72a4:	e9 e3 00 00 00       	jmp    738c <fwp_drop4+0x29c>
    72a9:	90                   	nop
    72aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72b1:	00 00 00 00 
    72b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72bc:	00 00 00 00 
    72c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    72c4:	48 85 c0             	test   %rax,%rax
    72c7:	0f 84 bf 00 00 00    	je     738c <fwp_drop4+0x29c>
    72cd:	48 89 c2             	mov    %rax,%rdx
    72d0:	48 39 08             	cmp    %rcx,(%rax)
    72d3:	75 eb                	jne    72c0 <fwp_drop4+0x1d0>
    72d5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    72d9:	48 83 ea 01          	sub    $0x1,%rdx
    72dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    72e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    72e8:	0f 85 8d fe ff ff    	jne    717b <fwp_drop4+0x8b>
    72ee:	48 89 cf             	mov    %rcx,%rdi
    72f1:	48 89 0c 24          	mov    %rcx,(%rsp)
    72f5:	e8 56 e2 ff ff       	call   5550 <fwp_rc_forget_slot>
    72fa:	48 8b 0c 24          	mov    (%rsp),%rcx
    72fe:	c6 01 fe             	movb   $0xfe,(%rcx)
    7301:	e9 75 fe ff ff       	jmp    717b <fwp_drop4+0x8b>
    7306:	48 89 ce             	mov    %rcx,%rsi
    7309:	48 c1 ee 11          	shr    $0x11,%rsi
    730d:	48 31 ce             	xor    %rcx,%rsi
    7310:	48 89 f0             	mov    %rsi,%rax
    7313:	48 c1 e8 09          	shr    $0x9,%rax
    7317:	48 31 c6             	xor    %rax,%rsi
    731a:	40 0f b6 f6          	movzbl %sil,%esi
    731e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7325:	00 
    7326:	48 85 c0             	test   %rax,%rax
    7329:	75 1e                	jne    7349 <fwp_drop4+0x259>
    732b:	eb 5f                	jmp    738c <fwp_drop4+0x29c>
    732d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7334:	00 
    7335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    733c:	00 00 00 00 
    7340:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7344:	48 85 c0             	test   %rax,%rax
    7347:	74 43                	je     738c <fwp_drop4+0x29c>
    7349:	48 89 c6             	mov    %rax,%rsi
    734c:	48 39 08             	cmp    %rcx,(%rax)
    734f:	75 ef                	jne    7340 <fwp_drop4+0x250>
    7351:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7355:	48 83 ee 01          	sub    $0x1,%rsi
    7359:	48 89 70 08          	mov    %rsi,0x8(%rax)
    735d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7364:	0f 85 a6 fe ff ff    	jne    7210 <fwp_drop4+0x120>
    736a:	48 89 cf             	mov    %rcx,%rdi
    736d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7372:	48 89 0c 24          	mov    %rcx,(%rsp)
    7376:	e8 d5 e1 ff ff       	call   5550 <fwp_rc_forget_slot>
    737b:	48 8b 0c 24          	mov    (%rsp),%rcx
    737f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7384:	c6 01 fe             	movb   $0xfe,(%rcx)
    7387:	e9 84 fe ff ff       	jmp    7210 <fwp_drop4+0x120>
    738c:	48 8d 3d d5 44 00 00 	lea    0x44d5(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    7393:	e8 58 d0 ff ff       	call   43f0 <fwp_trap>
    7398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    739f:	00 

00000000000073a0 <fwp_arg_drop37>:
    73a0:	f3 0f 1e fa          	endbr64
    73a4:	85 f6                	test   %esi,%esi
    73a6:	75 04                	jne    73ac <fwp_arg_drop37+0xc>
    73a8:	85 d2                	test   %edx,%edx
    73aa:	75 04                	jne    73b0 <fwp_arg_drop37+0x10>
    73ac:	c3                   	ret
    73ad:	0f 1f 00             	nopl   (%rax)
    73b0:	48 8b 3f             	mov    (%rdi),%rdi
    73b3:	e9 38 fd ff ff       	jmp    70f0 <fwp_drop4>
    73b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    73bf:	00 

00000000000073c0 <fwp_task_dispose>:
    73c0:	53                   	push   %rbx
    73c1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    73c5:	0f 84 7b c3 ff ff    	je     3746 <fwp_task_dispose.cold>
    73cb:	48 89 fb             	mov    %rdi,%rbx
    73ce:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    73d3:	0f 85 6d c3 ff ff    	jne    3746 <fwp_task_dispose.cold>
    73d9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    73dd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    73e4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    73eb:	00 
    73ec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    73f0:	48 85 ff             	test   %rdi,%rdi
    73f3:	74 07                	je     73fc <fwp_task_dispose+0x3c>
    73f5:	48 85 c0             	test   %rax,%rax
    73f8:	74 02                	je     73fc <fwp_task_dispose+0x3c>
    73fa:	ff d0                	call   *%rax
    73fc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7403:	e8 88 e3 ff ff       	call   5790 <fwp_mem_free>
    7408:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    740f:	00 00 00 00 
    7413:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7417:	74 6f                	je     7488 <fwp_task_dispose+0xc8>
    7419:	48 8b 15 78 97 01 00 	mov    0x19778(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    7420:	48 89 d8             	mov    %rbx,%rax
    7423:	48 2b 05 46 97 01 00 	sub    0x19746(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    742a:	48 c1 e2 10          	shl    $0x10,%rdx
    742e:	48 39 d0             	cmp    %rdx,%rax
    7431:	73 4c                	jae    747f <fwp_task_dispose+0xbf>
    7433:	48 89 c2             	mov    %rax,%rdx
    7436:	48 c1 ea 10          	shr    $0x10,%rdx
    743a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    743e:	48 8b 15 73 97 01 00 	mov    0x19773(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    7445:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7449:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    744d:	48 85 c9             	test   %rcx,%rcx
    7450:	74 2d                	je     747f <fwp_task_dispose+0xbf>
    7452:	0f b6 32             	movzbl (%rdx),%esi
    7455:	40 80 fe 02          	cmp    $0x2,%sil
    7459:	74 3d                	je     7498 <fwp_task_dispose+0xd8>
    745b:	40 80 fe 01          	cmp    $0x1,%sil
    745f:	75 1e                	jne    747f <fwp_task_dispose+0xbf>
    7461:	8b 72 18             	mov    0x18(%rdx),%esi
    7464:	0f b7 c0             	movzwl %ax,%eax
    7467:	8b 52 1c             	mov    0x1c(%rdx),%edx
    746a:	48 0f af c6          	imul   %rsi,%rax
    746e:	48 c1 e8 20          	shr    $0x20,%rax
    7472:	48 39 d0             	cmp    %rdx,%rax
    7475:	73 08                	jae    747f <fwp_task_dispose+0xbf>
    7477:	48 01 c1             	add    %rax,%rcx
    747a:	80 39 01             	cmpb   $0x1,(%rcx)
    747d:	74 09                	je     7488 <fwp_task_dispose+0xc8>
    747f:	5b                   	pop    %rbx
    7480:	c3                   	ret
    7481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7488:	48 89 df             	mov    %rbx,%rdi
    748b:	5b                   	pop    %rbx
    748c:	e9 ff e2 ff ff       	jmp    5790 <fwp_mem_free>
    7491:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7498:	66 85 c0             	test   %ax,%ax
    749b:	74 dd                	je     747a <fwp_task_dispose+0xba>
    749d:	5b                   	pop    %rbx
    749e:	c3                   	ret
    749f:	90                   	nop

00000000000074a0 <fwp_free_zombie>:
    74a0:	48 8b 15 e9 82 01 00 	mov    0x182e9(%rip),%rdx        # 1f790 <fwp_zombie>
    74a7:	48 85 d2             	test   %rdx,%rdx
    74aa:	0f 84 98 00 00 00    	je     7548 <fwp_free_zombie+0xa8>
    74b0:	48 3b 15 e9 82 01 00 	cmp    0x182e9(%rip),%rdx        # 1f7a0 <fwp_cur>
    74b7:	0f 84 8b 00 00 00    	je     7548 <fwp_free_zombie+0xa8>
    74bd:	48 83 ec 18          	sub    $0x18,%rsp
    74c1:	48 63 05 9c 7c 01 00 	movslq 0x17c9c(%rip),%rax        # 1f164 <fwp_stack_pool_n>
    74c8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    74cc:	83 f8 3f             	cmp    $0x3f,%eax
    74cf:	7f 7f                	jg     7550 <fwp_free_zombie+0xb0>
    74d1:	8d 48 01             	lea    0x1(%rax),%ecx
    74d4:	89 0d 8a 7c 01 00    	mov    %ecx,0x17c8a(%rip)        # 1f164 <fwp_stack_pool_n>
    74da:	48 8d 0d 9f 7c 01 00 	lea    0x17c9f(%rip),%rcx        # 1f180 <fwp_stack_pool>
    74e1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    74e5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    74ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74f0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    74f7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    74fb:	48 85 c9             	test   %rcx,%rcx
    74fe:	0f 84 fc 00 00 00    	je     7600 <fwp_free_zombie+0x160>
    7504:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    750b:	48 85 c0             	test   %rax,%rax
    750e:	74 07                	je     7517 <fwp_free_zombie+0x77>
    7510:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7517:	8b 42 5c             	mov    0x5c(%rdx),%eax
    751a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    751e:	48 c7 05 67 82 01 00 	movq   $0x0,0x18267(%rip)        # 1f790 <fwp_zombie>
    7525:	00 00 00 00 
    7529:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7530:	85 c0                	test   %eax,%eax
    7532:	74 34                	je     7568 <fwp_free_zombie+0xc8>
    7534:	83 f8 01             	cmp    $0x1,%eax
    7537:	0f 84 b3 00 00 00    	je     75f0 <fwp_free_zombie+0x150>
    753d:	48 83 c4 18          	add    $0x18,%rsp
    7541:	c3                   	ret
    7542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7548:	c3                   	ret
    7549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7550:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7554:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7559:	e8 82 c0 ff ff       	call   35e0 <munmap@plt>
    755e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7563:	eb 80                	jmp    74e5 <fwp_free_zombie+0x45>
    7565:	0f 1f 00             	nopl   (%rax)
    7568:	48 8b 0d 29 96 01 00 	mov    0x19629(%rip),%rcx        # 20b98 <fwp_heap+0x13d8>
    756f:	48 89 d0             	mov    %rdx,%rax
    7572:	48 2b 05 f7 95 01 00 	sub    0x195f7(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7579:	48 c1 e1 10          	shl    $0x10,%rcx
    757d:	48 39 c8             	cmp    %rcx,%rax
    7580:	73 bb                	jae    753d <fwp_free_zombie+0x9d>
    7582:	48 89 c1             	mov    %rax,%rcx
    7585:	48 c1 e9 10          	shr    $0x10,%rcx
    7589:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    758d:	48 8b 0d 24 96 01 00 	mov    0x19624(%rip),%rcx        # 20bb8 <fwp_heap+0x13f8>
    7594:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7598:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    759c:	48 85 c9             	test   %rcx,%rcx
    759f:	74 9c                	je     753d <fwp_free_zombie+0x9d>
    75a1:	0f b6 3e             	movzbl (%rsi),%edi
    75a4:	40 80 ff 02          	cmp    $0x2,%dil
    75a8:	74 66                	je     7610 <fwp_free_zombie+0x170>
    75aa:	40 80 ff 01          	cmp    $0x1,%dil
    75ae:	75 8d                	jne    753d <fwp_free_zombie+0x9d>
    75b0:	8b 7e 18             	mov    0x18(%rsi),%edi
    75b3:	0f b7 c0             	movzwl %ax,%eax
    75b6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    75b9:	48 0f af c7          	imul   %rdi,%rax
    75bd:	48 c1 e8 20          	shr    $0x20,%rax
    75c1:	48 39 f0             	cmp    %rsi,%rax
    75c4:	0f 83 73 ff ff ff    	jae    753d <fwp_free_zombie+0x9d>
    75ca:	48 01 c1             	add    %rax,%rcx
    75cd:	0f b6 01             	movzbl (%rcx),%eax
    75d0:	84 c0                	test   %al,%al
    75d2:	0f 84 65 ff ff ff    	je     753d <fwp_free_zombie+0x9d>
    75d8:	3c 01                	cmp    $0x1,%al
    75da:	74 14                	je     75f0 <fwp_free_zombie+0x150>
    75dc:	3c ff                	cmp    $0xff,%al
    75de:	74 3b                	je     761b <fwp_free_zombie+0x17b>
    75e0:	83 e8 01             	sub    $0x1,%eax
    75e3:	88 01                	mov    %al,(%rcx)
    75e5:	e9 53 ff ff ff       	jmp    753d <fwp_free_zombie+0x9d>
    75ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75f0:	48 89 d7             	mov    %rdx,%rdi
    75f3:	48 83 c4 18          	add    $0x18,%rsp
    75f7:	e9 c4 fd ff ff       	jmp    73c0 <fwp_task_dispose>
    75fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7600:	48 89 05 61 81 01 00 	mov    %rax,0x18161(%rip)        # 1f768 <fwp_tasks_active>
    7607:	e9 ff fe ff ff       	jmp    750b <fwp_free_zombie+0x6b>
    760c:	0f 1f 40 00          	nopl   0x0(%rax)
    7610:	66 85 c0             	test   %ax,%ax
    7613:	0f 85 24 ff ff ff    	jne    753d <fwp_free_zombie+0x9d>
    7619:	eb b2                	jmp    75cd <fwp_free_zombie+0x12d>
    761b:	48 89 ca             	mov    %rcx,%rdx
    761e:	48 8d 35 9b 81 01 00 	lea    0x1819b(%rip),%rsi        # 1f7c0 <fwp_heap>
    7625:	48 c1 ea 11          	shr    $0x11,%rdx
    7629:	48 31 ca             	xor    %rcx,%rdx
    762c:	48 89 d0             	mov    %rdx,%rax
    762f:	48 c1 e8 09          	shr    $0x9,%rax
    7633:	48 31 c2             	xor    %rax,%rdx
    7636:	0f b6 d2             	movzbl %dl,%edx
    7639:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7640:	00 
    7641:	48 85 c0             	test   %rax,%rax
    7644:	75 23                	jne    7669 <fwp_free_zombie+0x1c9>
    7646:	eb 5c                	jmp    76a4 <fwp_free_zombie+0x204>
    7648:	66 90                	xchg   %ax,%ax
    764a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7651:	00 00 00 00 
    7655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    765c:	00 00 00 00 
    7660:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7664:	48 85 c0             	test   %rax,%rax
    7667:	74 3b                	je     76a4 <fwp_free_zombie+0x204>
    7669:	48 89 c2             	mov    %rax,%rdx
    766c:	48 39 08             	cmp    %rcx,(%rax)
    766f:	75 ef                	jne    7660 <fwp_free_zombie+0x1c0>
    7671:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7675:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7679:	48 89 50 08          	mov    %rdx,0x8(%rax)
    767d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7684:	0f 85 b3 fe ff ff    	jne    753d <fwp_free_zombie+0x9d>
    768a:	48 89 cf             	mov    %rcx,%rdi
    768d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7692:	e8 b9 de ff ff       	call   5550 <fwp_rc_forget_slot>
    7697:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    769c:	c6 01 fe             	movb   $0xfe,(%rcx)
    769f:	e9 99 fe ff ff       	jmp    753d <fwp_free_zombie+0x9d>
    76a4:	48 8d 3d bd 41 00 00 	lea    0x41bd(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    76ab:	e8 40 cd ff ff       	call   43f0 <fwp_trap>

00000000000076b0 <fwp_block>:
    76b0:	48 83 ec 08          	sub    $0x8,%rsp
    76b4:	48 8b 05 cd 80 01 00 	mov    0x180cd(%rip),%rax        # 1f788 <fwp_ready_head>
    76bb:	48 85 c0             	test   %rax,%rax
    76be:	0f 84 1c 01 00 00    	je     77e0 <fwp_block+0x130>
    76c4:	90                   	nop
    76c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76cc:	00 00 00 00 
    76d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    76d7:	48 89 15 aa 80 01 00 	mov    %rdx,0x180aa(%rip)        # 1f788 <fwp_ready_head>
    76de:	48 85 d2             	test   %rdx,%rdx
    76e1:	0f 84 19 01 00 00    	je     7800 <fwp_block+0x150>
    76e7:	48 8b 15 b2 80 01 00 	mov    0x180b2(%rip),%rdx        # 1f7a0 <fwp_cur>
    76ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    76f2:	48 39 c2             	cmp    %rax,%rdx
    76f5:	0f 84 d5 00 00 00    	je     77d0 <fwp_block+0x120>
    76fb:	48 8b 0d 26 9d 01 00 	mov    0x19d26(%rip),%rcx        # 21428 <fwp_state_owners>
    7702:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7706:	48 89 05 93 80 01 00 	mov    %rax,0x18093(%rip)        # 1f7a0 <fwp_cur>
    770d:	f3 0f 7e 05 3b 9d 01 	movq   0x19d3b(%rip),%xmm0        # 21450 <fwp_foreign_callbacks>
    7714:	00 
    7715:	0f 16 05 24 9d 01 00 	movhps 0x19d24(%rip),%xmm0        # 21440 <fwp_state>
    771c:	f3 0f 7e 0d 24 9d 01 	movq   0x19d24(%rip),%xmm1        # 21448 <fwp_handlers>
    7723:	00 
    7724:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    772b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7732:	0f 16 0d 1f 9d 01 00 	movhps 0x19d1f(%rip),%xmm1        # 21458 <fwp_cleanups>
    7739:	f3 0f 7e 05 f7 9c 01 	movq   0x19cf7(%rip),%xmm0        # 21438 <fwp_state_len>
    7740:	00 
    7741:	0f 16 05 e8 9c 01 00 	movhps 0x19ce8(%rip),%xmm0        # 21430 <fwp_state_cap>
    7748:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    774f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7756:	48 8b 70 08          	mov    0x8(%rax),%rsi
    775a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7761:	48 89 0d e0 9c 01 00 	mov    %rcx,0x19ce0(%rip)        # 21448 <fwp_handlers>
    7768:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    776f:	48 89 0d e2 9c 01 00 	mov    %rcx,0x19ce2(%rip)        # 21458 <fwp_cleanups>
    7776:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    777d:	48 89 0d cc 9c 01 00 	mov    %rcx,0x19ccc(%rip)        # 21450 <fwp_foreign_callbacks>
    7784:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    778b:	48 89 0d ae 9c 01 00 	mov    %rcx,0x19cae(%rip)        # 21440 <fwp_state>
    7792:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7799:	48 89 0d 98 9c 01 00 	mov    %rcx,0x19c98(%rip)        # 21438 <fwp_state_len>
    77a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    77a7:	48 89 0d 82 9c 01 00 	mov    %rcx,0x19c82(%rip)        # 21430 <fwp_state_cap>
    77ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    77b5:	48 89 0d 6c 9c 01 00 	mov    %rcx,0x19c6c(%rip)        # 21428 <fwp_state_owners>
    77bc:	e8 cf bc ff ff       	call   3490 <swapcontext@plt>
    77c1:	f3 0f 1e fa          	endbr64
    77c5:	e8 d6 fc ff ff       	call   74a0 <fwp_free_zombie>
    77ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77d0:	8b 05 8a 79 01 00    	mov    0x1798a(%rip),%eax        # 1f160 <fwp_slice>
    77d6:	85 c0                	test   %eax,%eax
    77d8:	74 36                	je     7810 <fwp_block+0x160>
    77da:	48 83 c4 08          	add    $0x8,%rsp
    77de:	c3                   	ret
    77df:	90                   	nop
    77e0:	e8 bb d9 ff ff       	call   51a0 <fwp_poll_events>
    77e5:	48 8b 05 9c 7f 01 00 	mov    0x17f9c(%rip),%rax        # 1f788 <fwp_ready_head>
    77ec:	48 85 c0             	test   %rax,%rax
    77ef:	0f 85 db fe ff ff    	jne    76d0 <fwp_block+0x20>
    77f5:	eb e9                	jmp    77e0 <fwp_block+0x130>
    77f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77fe:	00 00 
    7800:	48 c7 05 75 7f 01 00 	movq   $0x0,0x17f75(%rip)        # 1f780 <fwp_ready_tail>
    7807:	00 00 00 00 
    780b:	e9 d7 fe ff ff       	jmp    76e7 <fwp_block+0x37>
    7810:	48 8d 3d 6d 39 00 00 	lea    0x396d(%rip),%rdi        # b184 <_IO_stdin_used+0x184>
    7817:	e8 84 bb ff ff       	call   33a0 <getenv@plt>
    781c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7821:	48 85 c0             	test   %rax,%rax
    7824:	74 05                	je     782b <fwp_block+0x17b>
    7826:	80 38 00             	cmpb   $0x0,(%rax)
    7829:	75 0b                	jne    7836 <fwp_block+0x186>
    782b:	89 15 2f 79 01 00    	mov    %edx,0x1792f(%rip)        # 1f160 <fwp_slice>
    7831:	48 83 c4 08          	add    $0x8,%rsp
    7835:	c3                   	ret
    7836:	ba 0a 00 00 00       	mov    $0xa,%edx
    783b:	31 f6                	xor    %esi,%esi
    783d:	48 89 c7             	mov    %rax,%rdi
    7840:	e8 0b bd ff ff       	call   3550 <strtoll@plt>
    7845:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7849:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7850:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7855:	0f 46 d0             	cmovbe %eax,%edx
    7858:	eb d1                	jmp    782b <fwp_block+0x17b>
    785a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007860 <fwp_caps173>:
    7860:	f3 0f 1e fa          	endbr64
    7864:	85 f6                	test   %esi,%esi
    7866:	74 08                	je     7870 <fwp_caps173+0x10>
    7868:	c3                   	ret
    7869:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7870:	48 8b 15 21 93 01 00 	mov    0x19321(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    7877:	48 89 f8             	mov    %rdi,%rax
    787a:	48 2b 05 ef 92 01 00 	sub    0x192ef(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7881:	48 c1 e2 10          	shl    $0x10,%rdx
    7885:	48 39 d0             	cmp    %rdx,%rax
    7888:	73 de                	jae    7868 <fwp_caps173+0x8>
    788a:	48 89 c2             	mov    %rax,%rdx
    788d:	48 c1 ea 10          	shr    $0x10,%rdx
    7891:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7895:	48 8b 15 1c 93 01 00 	mov    0x1931c(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    789c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    78a4:	48 85 c9             	test   %rcx,%rcx
    78a7:	74 bf                	je     7868 <fwp_caps173+0x8>
    78a9:	0f b6 32             	movzbl (%rdx),%esi
    78ac:	40 80 fe 02          	cmp    $0x2,%sil
    78b0:	74 2e                	je     78e0 <fwp_caps173+0x80>
    78b2:	40 80 fe 01          	cmp    $0x1,%sil
    78b6:	75 b0                	jne    7868 <fwp_caps173+0x8>
    78b8:	8b 72 18             	mov    0x18(%rdx),%esi
    78bb:	0f b7 c0             	movzwl %ax,%eax
    78be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78c1:	48 0f af c6          	imul   %rsi,%rax
    78c5:	48 c1 e8 20          	shr    $0x20,%rax
    78c9:	48 39 d0             	cmp    %rdx,%rax
    78cc:	73 9a                	jae    7868 <fwp_caps173+0x8>
    78ce:	48 01 c1             	add    %rax,%rcx
    78d1:	80 39 01             	cmpb   $0x1,(%rcx)
    78d4:	75 92                	jne    7868 <fwp_caps173+0x8>
    78d6:	e9 b5 de ff ff       	jmp    5790 <fwp_mem_free>
    78db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    78e0:	66 85 c0             	test   %ax,%ax
    78e3:	74 ec                	je     78d1 <fwp_caps173+0x71>
    78e5:	c3                   	ret
    78e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78ed:	00 00 00 

00000000000078f0 <fwp_args37>:
    78f0:	f3 0f 1e fa          	endbr64
    78f4:	85 d2                	test   %edx,%edx
    78f6:	74 04                	je     78fc <fwp_args37+0xc>
    78f8:	85 f6                	test   %esi,%esi
    78fa:	74 04                	je     7900 <fwp_args37+0x10>
    78fc:	c3                   	ret
    78fd:	0f 1f 00             	nopl   (%rax)
    7900:	48 8b 15 91 92 01 00 	mov    0x19291(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    7907:	48 8b 07             	mov    (%rdi),%rax
    790a:	48 2b 05 5f 92 01 00 	sub    0x1925f(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7911:	48 c1 e2 10          	shl    $0x10,%rdx
    7915:	48 39 d0             	cmp    %rdx,%rax
    7918:	73 e2                	jae    78fc <fwp_args37+0xc>
    791a:	48 89 c2             	mov    %rax,%rdx
    791d:	48 c1 ea 10          	shr    $0x10,%rdx
    7921:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7925:	48 8b 15 8c 92 01 00 	mov    0x1928c(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    792c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7930:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7934:	48 85 ff             	test   %rdi,%rdi
    7937:	74 c3                	je     78fc <fwp_args37+0xc>
    7939:	0f b6 0a             	movzbl (%rdx),%ecx
    793c:	80 f9 02             	cmp    $0x2,%cl
    793f:	74 2f                	je     7970 <fwp_args37+0x80>
    7941:	80 f9 01             	cmp    $0x1,%cl
    7944:	75 b6                	jne    78fc <fwp_args37+0xc>
    7946:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7949:	0f b7 c0             	movzwl %ax,%eax
    794c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    794f:	48 0f af c1          	imul   %rcx,%rax
    7953:	48 c1 e8 20          	shr    $0x20,%rax
    7957:	48 39 d0             	cmp    %rdx,%rax
    795a:	73 a0                	jae    78fc <fwp_args37+0xc>
    795c:	48 01 c7             	add    %rax,%rdi
    795f:	0f b6 07             	movzbl (%rdi),%eax
    7962:	84 c0                	test   %al,%al
    7964:	74 96                	je     78fc <fwp_args37+0xc>
    7966:	3c fd                	cmp    $0xfd,%al
    7968:	77 0c                	ja     7976 <fwp_args37+0x86>
    796a:	83 c0 01             	add    $0x1,%eax
    796d:	88 07                	mov    %al,(%rdi)
    796f:	c3                   	ret
    7970:	66 85 c0             	test   %ax,%ax
    7973:	74 ea                	je     795f <fwp_args37+0x6f>
    7975:	c3                   	ret
    7976:	e9 b5 da ff ff       	jmp    5430 <fwp_rc_wide_dup>
    797b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007980 <fwp_caps37>:
    7980:	f3 0f 1e fa          	endbr64
    7984:	48 83 ec 18          	sub    $0x18,%rsp
    7988:	8b 57 04             	mov    0x4(%rdi),%edx
    798b:	48 89 f8             	mov    %rdi,%rax
    798e:	85 d2                	test   %edx,%edx
    7990:	0f 84 9a 00 00 00    	je     7a30 <fwp_caps37+0xb0>
    7996:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    799a:	85 f6                	test   %esi,%esi
    799c:	0f 85 9e 00 00 00    	jne    7a40 <fwp_caps37+0xc0>
    79a2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    79a7:	e8 44 f7 ff ff       	call   70f0 <fwp_drop4>
    79ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    79b1:	48 8b 0d e0 91 01 00 	mov    0x191e0(%rip),%rcx        # 20b98 <fwp_heap+0x13d8>
    79b8:	48 89 c2             	mov    %rax,%rdx
    79bb:	48 2b 15 ae 91 01 00 	sub    0x191ae(%rip),%rdx        # 20b70 <fwp_heap+0x13b0>
    79c2:	48 c1 e1 10          	shl    $0x10,%rcx
    79c6:	48 39 ca             	cmp    %rcx,%rdx
    79c9:	73 6d                	jae    7a38 <fwp_caps37+0xb8>
    79cb:	48 89 d1             	mov    %rdx,%rcx
    79ce:	48 c1 e9 10          	shr    $0x10,%rcx
    79d2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    79d6:	48 8b 0d db 91 01 00 	mov    0x191db(%rip),%rcx        # 20bb8 <fwp_heap+0x13f8>
    79dd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    79e1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    79e5:	48 85 f6             	test   %rsi,%rsi
    79e8:	74 4e                	je     7a38 <fwp_caps37+0xb8>
    79ea:	0f b6 39             	movzbl (%rcx),%edi
    79ed:	40 80 ff 02          	cmp    $0x2,%dil
    79f1:	0f 84 b9 00 00 00    	je     7ab0 <fwp_caps37+0x130>
    79f7:	40 80 ff 01          	cmp    $0x1,%dil
    79fb:	75 3b                	jne    7a38 <fwp_caps37+0xb8>
    79fd:	8b 79 18             	mov    0x18(%rcx),%edi
    7a00:	0f b7 d2             	movzwl %dx,%edx
    7a03:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a06:	48 0f af d7          	imul   %rdi,%rdx
    7a0a:	48 c1 ea 20          	shr    $0x20,%rdx
    7a0e:	48 39 ca             	cmp    %rcx,%rdx
    7a11:	73 25                	jae    7a38 <fwp_caps37+0xb8>
    7a13:	48 01 d6             	add    %rdx,%rsi
    7a16:	80 3e 01             	cmpb   $0x1,(%rsi)
    7a19:	75 1d                	jne    7a38 <fwp_caps37+0xb8>
    7a1b:	48 89 c7             	mov    %rax,%rdi
    7a1e:	48 83 c4 18          	add    $0x18,%rsp
    7a22:	e9 69 dd ff ff       	jmp    5790 <fwp_mem_free>
    7a27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a2e:	00 00 
    7a30:	85 f6                	test   %esi,%esi
    7a32:	0f 84 79 ff ff ff    	je     79b1 <fwp_caps37+0x31>
    7a38:	48 83 c4 18          	add    $0x18,%rsp
    7a3c:	c3                   	ret
    7a3d:	0f 1f 00             	nopl   (%rax)
    7a40:	48 8b 05 51 91 01 00 	mov    0x19151(%rip),%rax        # 20b98 <fwp_heap+0x13d8>
    7a47:	48 2b 3d 22 91 01 00 	sub    0x19122(%rip),%rdi        # 20b70 <fwp_heap+0x13b0>
    7a4e:	48 c1 e0 10          	shl    $0x10,%rax
    7a52:	48 39 c7             	cmp    %rax,%rdi
    7a55:	73 e1                	jae    7a38 <fwp_caps37+0xb8>
    7a57:	48 89 f8             	mov    %rdi,%rax
    7a5a:	48 c1 e8 10          	shr    $0x10,%rax
    7a5e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7a62:	48 8b 05 4f 91 01 00 	mov    0x1914f(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    7a69:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7a6d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7a71:	48 85 c0             	test   %rax,%rax
    7a74:	74 c2                	je     7a38 <fwp_caps37+0xb8>
    7a76:	0f b6 0a             	movzbl (%rdx),%ecx
    7a79:	80 f9 02             	cmp    $0x2,%cl
    7a7c:	74 42                	je     7ac0 <fwp_caps37+0x140>
    7a7e:	80 f9 01             	cmp    $0x1,%cl
    7a81:	75 b5                	jne    7a38 <fwp_caps37+0xb8>
    7a83:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a86:	0f b7 ff             	movzwl %di,%edi
    7a89:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a8c:	48 0f af f9          	imul   %rcx,%rdi
    7a90:	48 c1 ef 20          	shr    $0x20,%rdi
    7a94:	48 39 d7             	cmp    %rdx,%rdi
    7a97:	73 9f                	jae    7a38 <fwp_caps37+0xb8>
    7a99:	48 01 f8             	add    %rdi,%rax
    7a9c:	0f b6 10             	movzbl (%rax),%edx
    7a9f:	84 d2                	test   %dl,%dl
    7aa1:	74 95                	je     7a38 <fwp_caps37+0xb8>
    7aa3:	80 fa fd             	cmp    $0xfd,%dl
    7aa6:	77 23                	ja     7acb <fwp_caps37+0x14b>
    7aa8:	83 c2 01             	add    $0x1,%edx
    7aab:	88 10                	mov    %dl,(%rax)
    7aad:	eb 89                	jmp    7a38 <fwp_caps37+0xb8>
    7aaf:	90                   	nop
    7ab0:	66 85 d2             	test   %dx,%dx
    7ab3:	0f 85 7f ff ff ff    	jne    7a38 <fwp_caps37+0xb8>
    7ab9:	e9 58 ff ff ff       	jmp    7a16 <fwp_caps37+0x96>
    7abe:	66 90                	xchg   %ax,%ax
    7ac0:	66 85 ff             	test   %di,%di
    7ac3:	0f 85 6f ff ff ff    	jne    7a38 <fwp_caps37+0xb8>
    7ac9:	eb d1                	jmp    7a9c <fwp_caps37+0x11c>
    7acb:	48 89 c7             	mov    %rax,%rdi
    7ace:	48 83 c4 18          	add    $0x18,%rsp
    7ad2:	e9 59 d9 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7ad7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ade:	00 00 

0000000000007ae0 <fwp_drop0>:
    7ae0:	f3 0f 1e fa          	endbr64
    7ae4:	48 8b 15 ad 90 01 00 	mov    0x190ad(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    7aeb:	48 89 f8             	mov    %rdi,%rax
    7aee:	48 2b 05 7b 90 01 00 	sub    0x1907b(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7af5:	48 c1 e2 10          	shl    $0x10,%rdx
    7af9:	48 39 d0             	cmp    %rdx,%rax
    7afc:	0f 83 36 01 00 00    	jae    7c38 <fwp_drop0+0x158>
    7b02:	48 83 ec 18          	sub    $0x18,%rsp
    7b06:	48 8d 35 b3 7c 01 00 	lea    0x17cb3(%rip),%rsi        # 1f7c0 <fwp_heap>
    7b0d:	48 89 c2             	mov    %rax,%rdx
    7b10:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7b17:	48 c1 ea 10          	shr    $0x10,%rdx
    7b1b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b1f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7b23:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b27:	48 85 d2             	test   %rdx,%rdx
    7b2a:	74 42                	je     7b6e <fwp_drop0+0x8e>
    7b2c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7b30:	41 80 f8 02          	cmp    $0x2,%r8b
    7b34:	74 42                	je     7b78 <fwp_drop0+0x98>
    7b36:	41 80 f8 01          	cmp    $0x1,%r8b
    7b3a:	75 32                	jne    7b6e <fwp_drop0+0x8e>
    7b3c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7b40:	0f b7 c0             	movzwl %ax,%eax
    7b43:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b46:	49 0f af c0          	imul   %r8,%rax
    7b4a:	48 c1 e8 20          	shr    $0x20,%rax
    7b4e:	48 39 c8             	cmp    %rcx,%rax
    7b51:	73 1b                	jae    7b6e <fwp_drop0+0x8e>
    7b53:	48 01 c2             	add    %rax,%rdx
    7b56:	0f b6 02             	movzbl (%rdx),%eax
    7b59:	84 c0                	test   %al,%al
    7b5b:	74 11                	je     7b6e <fwp_drop0+0x8e>
    7b5d:	3c 01                	cmp    $0x1,%al
    7b5f:	74 27                	je     7b88 <fwp_drop0+0xa8>
    7b61:	3c ff                	cmp    $0xff,%al
    7b63:	0f 84 e7 00 00 00    	je     7c50 <fwp_drop0+0x170>
    7b69:	83 e8 01             	sub    $0x1,%eax
    7b6c:	88 02                	mov    %al,(%rdx)
    7b6e:	48 83 c4 18          	add    $0x18,%rsp
    7b72:	c3                   	ret
    7b73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b78:	66 85 c0             	test   %ax,%ax
    7b7b:	74 d9                	je     7b56 <fwp_drop0+0x76>
    7b7d:	48 83 c4 18          	add    $0x18,%rsp
    7b81:	c3                   	ret
    7b82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b88:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b8f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b96:	48 89 f8             	mov    %rdi,%rax
    7b99:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7b9d:	48 29 c8             	sub    %rcx,%rax
    7ba0:	48 c1 e2 10          	shl    $0x10,%rdx
    7ba4:	48 39 d0             	cmp    %rdx,%rax
    7ba7:	73 71                	jae    7c1a <fwp_drop0+0x13a>
    7ba9:	49 89 c2             	mov    %rax,%r10
    7bac:	49 c1 ea 10          	shr    $0x10,%r10
    7bb0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7bb4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7bb8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7bbc:	4d 85 d2             	test   %r10,%r10
    7bbf:	74 59                	je     7c1a <fwp_drop0+0x13a>
    7bc1:	45 0f b6 19          	movzbl (%r9),%r11d
    7bc5:	41 80 fb 02          	cmp    $0x2,%r11b
    7bc9:	74 75                	je     7c40 <fwp_drop0+0x160>
    7bcb:	41 80 fb 01          	cmp    $0x1,%r11b
    7bcf:	75 49                	jne    7c1a <fwp_drop0+0x13a>
    7bd1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7bd5:	0f b7 c0             	movzwl %ax,%eax
    7bd8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7bdc:	49 0f af c3          	imul   %r11,%rax
    7be0:	48 c1 e8 20          	shr    $0x20,%rax
    7be4:	4c 39 c8             	cmp    %r9,%rax
    7be7:	73 31                	jae    7c1a <fwp_drop0+0x13a>
    7be9:	49 01 c2             	add    %rax,%r10
    7bec:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7bf0:	75 28                	jne    7c1a <fwp_drop0+0x13a>
    7bf2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7bf7:	e8 94 db ff ff       	call   5790 <fwp_mem_free>
    7bfc:	48 8d 35 bd 7b 01 00 	lea    0x17bbd(%rip),%rsi        # 1f7c0 <fwp_heap>
    7c03:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7c08:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7c0f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c16:	48 c1 e2 10          	shl    $0x10,%rdx
    7c1a:	4c 89 c0             	mov    %r8,%rax
    7c1d:	48 29 c8             	sub    %rcx,%rax
    7c20:	48 39 d0             	cmp    %rdx,%rax
    7c23:	0f 83 45 ff ff ff    	jae    7b6e <fwp_drop0+0x8e>
    7c29:	4c 89 c7             	mov    %r8,%rdi
    7c2c:	e9 dc fe ff ff       	jmp    7b0d <fwp_drop0+0x2d>
    7c31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c38:	c3                   	ret
    7c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c40:	66 85 c0             	test   %ax,%ax
    7c43:	75 d5                	jne    7c1a <fwp_drop0+0x13a>
    7c45:	eb a5                	jmp    7bec <fwp_drop0+0x10c>
    7c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c4e:	00 00 
    7c50:	48 89 d0             	mov    %rdx,%rax
    7c53:	48 c1 e8 11          	shr    $0x11,%rax
    7c57:	48 31 d0             	xor    %rdx,%rax
    7c5a:	48 89 c1             	mov    %rax,%rcx
    7c5d:	48 c1 e9 09          	shr    $0x9,%rcx
    7c61:	48 31 c8             	xor    %rcx,%rax
    7c64:	0f b6 c8             	movzbl %al,%ecx
    7c67:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7c6e:	00 
    7c6f:	48 85 c0             	test   %rax,%rax
    7c72:	75 15                	jne    7c89 <fwp_drop0+0x1a9>
    7c74:	eb 4e                	jmp    7cc4 <fwp_drop0+0x1e4>
    7c76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c7d:	00 00 00 
    7c80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7c84:	48 85 c0             	test   %rax,%rax
    7c87:	74 3b                	je     7cc4 <fwp_drop0+0x1e4>
    7c89:	48 89 c1             	mov    %rax,%rcx
    7c8c:	48 39 10             	cmp    %rdx,(%rax)
    7c8f:	75 ef                	jne    7c80 <fwp_drop0+0x1a0>
    7c91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7c99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7c9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ca4:	0f 85 c4 fe ff ff    	jne    7b6e <fwp_drop0+0x8e>
    7caa:	48 89 d7             	mov    %rdx,%rdi
    7cad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7cb2:	e8 99 d8 ff ff       	call   5550 <fwp_rc_forget_slot>
    7cb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7cbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7cbf:	e9 aa fe ff ff       	jmp    7b6e <fwp_drop0+0x8e>
    7cc4:	48 8d 3d 9d 3b 00 00 	lea    0x3b9d(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    7ccb:	e8 20 c7 ff ff       	call   43f0 <fwp_trap>

0000000000007cd0 <fwp_drop1>:
    7cd0:	f3 0f 1e fa          	endbr64
    7cd4:	48 8b 15 bd 8e 01 00 	mov    0x18ebd(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    7cdb:	48 89 f8             	mov    %rdi,%rax
    7cde:	48 2b 05 8b 8e 01 00 	sub    0x18e8b(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7ce5:	48 c1 e2 10          	shl    $0x10,%rdx
    7ce9:	48 39 d0             	cmp    %rdx,%rax
    7cec:	0f 83 36 01 00 00    	jae    7e28 <fwp_drop1+0x158>
    7cf2:	48 83 ec 18          	sub    $0x18,%rsp
    7cf6:	48 8d 35 c3 7a 01 00 	lea    0x17ac3(%rip),%rsi        # 1f7c0 <fwp_heap>
    7cfd:	48 89 c2             	mov    %rax,%rdx
    7d00:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7d07:	48 c1 ea 10          	shr    $0x10,%rdx
    7d0b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7d0f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7d13:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7d17:	48 85 d2             	test   %rdx,%rdx
    7d1a:	74 42                	je     7d5e <fwp_drop1+0x8e>
    7d1c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7d20:	41 80 f8 02          	cmp    $0x2,%r8b
    7d24:	74 42                	je     7d68 <fwp_drop1+0x98>
    7d26:	41 80 f8 01          	cmp    $0x1,%r8b
    7d2a:	75 32                	jne    7d5e <fwp_drop1+0x8e>
    7d2c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7d30:	0f b7 c0             	movzwl %ax,%eax
    7d33:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d36:	49 0f af c0          	imul   %r8,%rax
    7d3a:	48 c1 e8 20          	shr    $0x20,%rax
    7d3e:	48 39 c8             	cmp    %rcx,%rax
    7d41:	73 1b                	jae    7d5e <fwp_drop1+0x8e>
    7d43:	48 01 c2             	add    %rax,%rdx
    7d46:	0f b6 02             	movzbl (%rdx),%eax
    7d49:	84 c0                	test   %al,%al
    7d4b:	74 11                	je     7d5e <fwp_drop1+0x8e>
    7d4d:	3c 01                	cmp    $0x1,%al
    7d4f:	74 27                	je     7d78 <fwp_drop1+0xa8>
    7d51:	3c ff                	cmp    $0xff,%al
    7d53:	0f 84 e7 00 00 00    	je     7e40 <fwp_drop1+0x170>
    7d59:	83 e8 01             	sub    $0x1,%eax
    7d5c:	88 02                	mov    %al,(%rdx)
    7d5e:	48 83 c4 18          	add    $0x18,%rsp
    7d62:	c3                   	ret
    7d63:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d68:	66 85 c0             	test   %ax,%ax
    7d6b:	74 d9                	je     7d46 <fwp_drop1+0x76>
    7d6d:	48 83 c4 18          	add    $0x18,%rsp
    7d71:	c3                   	ret
    7d72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d78:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d7f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d86:	48 89 f8             	mov    %rdi,%rax
    7d89:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7d8d:	48 29 c8             	sub    %rcx,%rax
    7d90:	48 c1 e2 10          	shl    $0x10,%rdx
    7d94:	48 39 d0             	cmp    %rdx,%rax
    7d97:	73 71                	jae    7e0a <fwp_drop1+0x13a>
    7d99:	49 89 c2             	mov    %rax,%r10
    7d9c:	49 c1 ea 10          	shr    $0x10,%r10
    7da0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7da4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7da8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7dac:	4d 85 d2             	test   %r10,%r10
    7daf:	74 59                	je     7e0a <fwp_drop1+0x13a>
    7db1:	45 0f b6 19          	movzbl (%r9),%r11d
    7db5:	41 80 fb 02          	cmp    $0x2,%r11b
    7db9:	74 75                	je     7e30 <fwp_drop1+0x160>
    7dbb:	41 80 fb 01          	cmp    $0x1,%r11b
    7dbf:	75 49                	jne    7e0a <fwp_drop1+0x13a>
    7dc1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7dc5:	0f b7 c0             	movzwl %ax,%eax
    7dc8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7dcc:	49 0f af c3          	imul   %r11,%rax
    7dd0:	48 c1 e8 20          	shr    $0x20,%rax
    7dd4:	4c 39 c8             	cmp    %r9,%rax
    7dd7:	73 31                	jae    7e0a <fwp_drop1+0x13a>
    7dd9:	49 01 c2             	add    %rax,%r10
    7ddc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7de0:	75 28                	jne    7e0a <fwp_drop1+0x13a>
    7de2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7de7:	e8 a4 d9 ff ff       	call   5790 <fwp_mem_free>
    7dec:	48 8d 35 cd 79 01 00 	lea    0x179cd(%rip),%rsi        # 1f7c0 <fwp_heap>
    7df3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7df8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7dff:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e06:	48 c1 e2 10          	shl    $0x10,%rdx
    7e0a:	4c 89 c0             	mov    %r8,%rax
    7e0d:	48 29 c8             	sub    %rcx,%rax
    7e10:	48 39 d0             	cmp    %rdx,%rax
    7e13:	0f 83 45 ff ff ff    	jae    7d5e <fwp_drop1+0x8e>
    7e19:	4c 89 c7             	mov    %r8,%rdi
    7e1c:	e9 dc fe ff ff       	jmp    7cfd <fwp_drop1+0x2d>
    7e21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e28:	c3                   	ret
    7e29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e30:	66 85 c0             	test   %ax,%ax
    7e33:	75 d5                	jne    7e0a <fwp_drop1+0x13a>
    7e35:	eb a5                	jmp    7ddc <fwp_drop1+0x10c>
    7e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e3e:	00 00 
    7e40:	48 89 d0             	mov    %rdx,%rax
    7e43:	48 c1 e8 11          	shr    $0x11,%rax
    7e47:	48 31 d0             	xor    %rdx,%rax
    7e4a:	48 89 c1             	mov    %rax,%rcx
    7e4d:	48 c1 e9 09          	shr    $0x9,%rcx
    7e51:	48 31 c8             	xor    %rcx,%rax
    7e54:	0f b6 c8             	movzbl %al,%ecx
    7e57:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7e5e:	00 
    7e5f:	48 85 c0             	test   %rax,%rax
    7e62:	75 25                	jne    7e89 <fwp_drop1+0x1b9>
    7e64:	eb 5e                	jmp    7ec4 <fwp_drop1+0x1f4>
    7e66:	0f 1f 40 00          	nopl   0x0(%rax)
    7e6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e71:	00 00 00 00 
    7e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e7c:	00 00 00 00 
    7e80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7e84:	48 85 c0             	test   %rax,%rax
    7e87:	74 3b                	je     7ec4 <fwp_drop1+0x1f4>
    7e89:	48 89 c1             	mov    %rax,%rcx
    7e8c:	48 39 10             	cmp    %rdx,(%rax)
    7e8f:	75 ef                	jne    7e80 <fwp_drop1+0x1b0>
    7e91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7e99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7e9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ea4:	0f 85 b4 fe ff ff    	jne    7d5e <fwp_drop1+0x8e>
    7eaa:	48 89 d7             	mov    %rdx,%rdi
    7ead:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7eb2:	e8 99 d6 ff ff       	call   5550 <fwp_rc_forget_slot>
    7eb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7ebc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7ebf:	e9 9a fe ff ff       	jmp    7d5e <fwp_drop1+0x8e>
    7ec4:	48 8d 3d 9d 39 00 00 	lea    0x399d(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    7ecb:	e8 20 c5 ff ff       	call   43f0 <fwp_trap>

0000000000007ed0 <fwp_drop10>:
    7ed0:	48 8b 0d c1 8c 01 00 	mov    0x18cc1(%rip),%rcx        # 20b98 <fwp_heap+0x13d8>
    7ed7:	48 89 f8             	mov    %rdi,%rax
    7eda:	48 2b 05 8f 8c 01 00 	sub    0x18c8f(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7ee1:	48 c1 e1 10          	shl    $0x10,%rcx
    7ee5:	48 39 c8             	cmp    %rcx,%rax
    7ee8:	0f 83 c2 01 00 00    	jae    80b0 <fwp_drop10+0x1e0>
    7eee:	48 83 ec 18          	sub    $0x18,%rsp
    7ef2:	48 89 fa             	mov    %rdi,%rdx
    7ef5:	48 8d 35 c4 78 01 00 	lea    0x178c4(%rip),%rsi        # 1f7c0 <fwp_heap>
    7efc:	48 89 c1             	mov    %rax,%rcx
    7eff:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7f06:	48 c1 e9 10          	shr    $0x10,%rcx
    7f0a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7f0e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7f12:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7f16:	48 85 c9             	test   %rcx,%rcx
    7f19:	74 46                	je     7f61 <fwp_drop10+0x91>
    7f1b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7f1f:	41 80 f9 02          	cmp    $0x2,%r9b
    7f23:	0f 84 d7 00 00 00    	je     8000 <fwp_drop10+0x130>
    7f29:	41 80 f9 01          	cmp    $0x1,%r9b
    7f2d:	75 32                	jne    7f61 <fwp_drop10+0x91>
    7f2f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7f33:	0f b7 c0             	movzwl %ax,%eax
    7f36:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7f39:	49 0f af c1          	imul   %r9,%rax
    7f3d:	48 c1 e8 20          	shr    $0x20,%rax
    7f41:	48 39 f8             	cmp    %rdi,%rax
    7f44:	73 1b                	jae    7f61 <fwp_drop10+0x91>
    7f46:	48 01 c1             	add    %rax,%rcx
    7f49:	0f b6 01             	movzbl (%rcx),%eax
    7f4c:	84 c0                	test   %al,%al
    7f4e:	74 11                	je     7f61 <fwp_drop10+0x91>
    7f50:	3c 01                	cmp    $0x1,%al
    7f52:	74 1c                	je     7f70 <fwp_drop10+0xa0>
    7f54:	3c ff                	cmp    $0xff,%al
    7f56:	0f 84 5c 01 00 00    	je     80b8 <fwp_drop10+0x1e8>
    7f5c:	83 e8 01             	sub    $0x1,%eax
    7f5f:	88 01                	mov    %al,(%rcx)
    7f61:	48 83 c4 18          	add    $0x18,%rsp
    7f65:	c3                   	ret
    7f66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f6d:	00 00 00 
    7f70:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7f77:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7f7e:	48 89 d0             	mov    %rdx,%rax
    7f81:	49 89 d1             	mov    %rdx,%r9
    7f84:	48 c1 e1 10          	shl    $0x10,%rcx
    7f88:	48 29 f8             	sub    %rdi,%rax
    7f8b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7f8f:	78 7f                	js     8010 <fwp_drop10+0x140>
    7f91:	48 39 c8             	cmp    %rcx,%rax
    7f94:	73 cb                	jae    7f61 <fwp_drop10+0x91>
    7f96:	48 89 c1             	mov    %rax,%rcx
    7f99:	48 c1 e9 10          	shr    $0x10,%rcx
    7f9d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7fa1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7fa5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7fa9:	48 85 f6             	test   %rsi,%rsi
    7fac:	74 b3                	je     7f61 <fwp_drop10+0x91>
    7fae:	0f b6 39             	movzbl (%rcx),%edi
    7fb1:	40 80 ff 02          	cmp    $0x2,%dil
    7fb5:	74 39                	je     7ff0 <fwp_drop10+0x120>
    7fb7:	40 80 ff 01          	cmp    $0x1,%dil
    7fbb:	75 a4                	jne    7f61 <fwp_drop10+0x91>
    7fbd:	8b 79 18             	mov    0x18(%rcx),%edi
    7fc0:	0f b7 c0             	movzwl %ax,%eax
    7fc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7fc6:	48 0f af c7          	imul   %rdi,%rax
    7fca:	48 c1 e8 20          	shr    $0x20,%rax
    7fce:	48 39 c8             	cmp    %rcx,%rax
    7fd1:	73 8e                	jae    7f61 <fwp_drop10+0x91>
    7fd3:	48 01 c6             	add    %rax,%rsi
    7fd6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7fd9:	75 86                	jne    7f61 <fwp_drop10+0x91>
    7fdb:	48 89 d7             	mov    %rdx,%rdi
    7fde:	48 83 c4 18          	add    $0x18,%rsp
    7fe2:	e9 a9 d7 ff ff       	jmp    5790 <fwp_mem_free>
    7fe7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fee:	00 00 
    7ff0:	66 85 c0             	test   %ax,%ax
    7ff3:	74 e1                	je     7fd6 <fwp_drop10+0x106>
    7ff5:	48 83 c4 18          	add    $0x18,%rsp
    7ff9:	c3                   	ret
    7ffa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8000:	66 85 c0             	test   %ax,%ax
    8003:	0f 84 40 ff ff ff    	je     7f49 <fwp_drop10+0x79>
    8009:	48 83 c4 18          	add    $0x18,%rsp
    800d:	c3                   	ret
    800e:	66 90                	xchg   %ax,%ax
    8010:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8014:	48 39 c8             	cmp    %rcx,%rax
    8017:	73 74                	jae    808d <fwp_drop10+0x1bd>
    8019:	49 89 c2             	mov    %rax,%r10
    801c:	49 c1 ea 10          	shr    $0x10,%r10
    8020:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8024:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8028:	4d 8b 50 20          	mov    0x20(%r8),%r10
    802c:	4d 85 d2             	test   %r10,%r10
    802f:	74 5c                	je     808d <fwp_drop10+0x1bd>
    8031:	45 0f b6 18          	movzbl (%r8),%r11d
    8035:	41 80 fb 02          	cmp    $0x2,%r11b
    8039:	74 6d                	je     80a8 <fwp_drop10+0x1d8>
    803b:	41 80 fb 01          	cmp    $0x1,%r11b
    803f:	75 4c                	jne    808d <fwp_drop10+0x1bd>
    8041:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8045:	0f b7 c0             	movzwl %ax,%eax
    8048:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    804c:	49 0f af c3          	imul   %r11,%rax
    8050:	48 c1 e8 20          	shr    $0x20,%rax
    8054:	4c 39 c0             	cmp    %r8,%rax
    8057:	73 34                	jae    808d <fwp_drop10+0x1bd>
    8059:	49 01 c2             	add    %rax,%r10
    805c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8060:	75 2b                	jne    808d <fwp_drop10+0x1bd>
    8062:	4c 89 cf             	mov    %r9,%rdi
    8065:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    806a:	e8 21 d7 ff ff       	call   5790 <fwp_mem_free>
    806f:	48 8d 35 4a 77 01 00 	lea    0x1774a(%rip),%rsi        # 1f7c0 <fwp_heap>
    8076:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    807b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8082:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8089:	48 c1 e1 10          	shl    $0x10,%rcx
    808d:	48 89 d0             	mov    %rdx,%rax
    8090:	48 29 f8             	sub    %rdi,%rax
    8093:	48 39 c8             	cmp    %rcx,%rax
    8096:	0f 82 60 fe ff ff    	jb     7efc <fwp_drop10+0x2c>
    809c:	e9 c0 fe ff ff       	jmp    7f61 <fwp_drop10+0x91>
    80a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80a8:	66 85 c0             	test   %ax,%ax
    80ab:	75 e0                	jne    808d <fwp_drop10+0x1bd>
    80ad:	eb ad                	jmp    805c <fwp_drop10+0x18c>
    80af:	90                   	nop
    80b0:	c3                   	ret
    80b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80b8:	48 89 c8             	mov    %rcx,%rax
    80bb:	48 c1 e8 11          	shr    $0x11,%rax
    80bf:	48 31 c8             	xor    %rcx,%rax
    80c2:	48 89 c2             	mov    %rax,%rdx
    80c5:	48 c1 ea 09          	shr    $0x9,%rdx
    80c9:	48 31 d0             	xor    %rdx,%rax
    80cc:	0f b6 d0             	movzbl %al,%edx
    80cf:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    80d6:	00 
    80d7:	48 85 c0             	test   %rax,%rax
    80da:	75 0d                	jne    80e9 <fwp_drop10+0x219>
    80dc:	eb 46                	jmp    8124 <fwp_drop10+0x254>
    80de:	66 90                	xchg   %ax,%ax
    80e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    80e4:	48 85 c0             	test   %rax,%rax
    80e7:	74 3b                	je     8124 <fwp_drop10+0x254>
    80e9:	48 89 c2             	mov    %rax,%rdx
    80ec:	48 39 08             	cmp    %rcx,(%rax)
    80ef:	75 ef                	jne    80e0 <fwp_drop10+0x210>
    80f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    80f5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    80f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    80fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8104:	0f 85 57 fe ff ff    	jne    7f61 <fwp_drop10+0x91>
    810a:	48 89 cf             	mov    %rcx,%rdi
    810d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8112:	e8 39 d4 ff ff       	call   5550 <fwp_rc_forget_slot>
    8117:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    811c:	c6 01 fe             	movb   $0xfe,(%rcx)
    811f:	e9 3d fe ff ff       	jmp    7f61 <fwp_drop10+0x91>
    8124:	48 8d 3d 3d 37 00 00 	lea    0x373d(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    812b:	e8 c0 c2 ff ff       	call   43f0 <fwp_trap>

0000000000008130 <f37>:
    8130:	41 57                	push   %r15
    8132:	41 56                	push   %r14
    8134:	41 55                	push   %r13
    8136:	41 54                	push   %r12
    8138:	55                   	push   %rbp
    8139:	53                   	push   %rbx
    813a:	48 83 ec 38          	sub    $0x38,%rsp
    813e:	48 8b 15 53 8a 01 00 	mov    0x18a53(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    8145:	48 8b 0d 24 8a 01 00 	mov    0x18a24(%rip),%rcx        # 20b70 <fwp_heap+0x13b0>
    814c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    8153:	00 00 
    8155:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    815a:	49 89 fd             	mov    %rdi,%r13
    815d:	48 c1 e2 10          	shl    $0x10,%rdx
    8161:	48 85 ff             	test   %rdi,%rdi
    8164:	0f 84 fc 02 00 00    	je     8466 <f37+0x336>
    816a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    816e:	48 89 d8             	mov    %rbx,%rax
    8171:	48 29 c8             	sub    %rcx,%rax
    8174:	48 39 d0             	cmp    %rdx,%rax
    8177:	0f 83 b3 03 00 00    	jae    8530 <f37+0x400>
    817d:	48 89 c2             	mov    %rax,%rdx
    8180:	48 c1 ea 10          	shr    $0x10,%rdx
    8184:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8188:	48 8b 15 29 8a 01 00 	mov    0x18a29(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    818f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8193:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8197:	48 85 ff             	test   %rdi,%rdi
    819a:	0f 84 90 03 00 00    	je     8530 <f37+0x400>
    81a0:	0f b6 0a             	movzbl (%rdx),%ecx
    81a3:	80 f9 02             	cmp    $0x2,%cl
    81a6:	0f 84 94 02 00 00    	je     8440 <f37+0x310>
    81ac:	80 f9 01             	cmp    $0x1,%cl
    81af:	75 24                	jne    81d5 <f37+0xa5>
    81b1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81b4:	0f b7 c0             	movzwl %ax,%eax
    81b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81ba:	48 0f af c1          	imul   %rcx,%rax
    81be:	48 c1 e8 20          	shr    $0x20,%rax
    81c2:	48 39 d0             	cmp    %rdx,%rax
    81c5:	73 0e                	jae    81d5 <f37+0xa5>
    81c7:	48 01 c7             	add    %rax,%rdi
    81ca:	0f b6 07             	movzbl (%rdi),%eax
    81cd:	84 c0                	test   %al,%al
    81cf:	0f 85 0b 03 00 00    	jne    84e0 <f37+0x3b0>
    81d5:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    81da:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    81de:	ba 01 00 00 00       	mov    $0x1,%edx
    81e3:	48 85 db             	test   %rbx,%rbx
    81e6:	74 15                	je     81fd <f37+0xcd>
    81e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    81ef:	00 
    81f0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    81f4:	48 83 c2 01          	add    $0x1,%rdx
    81f8:	48 85 db             	test   %rbx,%rbx
    81fb:	75 f3                	jne    81f0 <f37+0xc0>
    81fd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8202:	48 85 c0             	test   %rax,%rax
    8205:	0f 84 55 03 00 00    	je     8560 <f37+0x430>
    820b:	31 db                	xor    %ebx,%ebx
    820d:	0f 1f 00             	nopl   (%rax)
    8210:	48 8b 40 10          	mov    0x10(%rax),%rax
    8214:	48 83 c3 01          	add    $0x1,%rbx
    8218:	48 85 c0             	test   %rax,%rax
    821b:	75 f3                	jne    8210 <f37+0xe0>
    821d:	48 39 d3             	cmp    %rdx,%rbx
    8220:	48 0f 47 da          	cmova  %rdx,%rbx
    8224:	48 89 d8             	mov    %rbx,%rax
    8227:	48 c1 e8 3c          	shr    $0x3c,%rax
    822b:	0f 85 d3 03 00 00    	jne    8604 <f37+0x4d4>
    8231:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8235:	be 02 00 00 00       	mov    $0x2,%esi
    823a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8241:	00 
    8242:	e8 49 da ff ff       	call   5c90 <fwp_heap_alloc>
    8247:	48 89 28             	mov    %rbp,(%rax)
    824a:	48 8b 15 47 89 01 00 	mov    0x18947(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    8251:	49 89 c4             	mov    %rax,%r12
    8254:	48 2b 05 15 89 01 00 	sub    0x18915(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    825b:	48 c1 e2 10          	shl    $0x10,%rdx
    825f:	48 39 d0             	cmp    %rdx,%rax
    8262:	73 57                	jae    82bb <f37+0x18b>
    8264:	48 89 c2             	mov    %rax,%rdx
    8267:	48 c1 ea 10          	shr    $0x10,%rdx
    826b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    826f:	48 8b 15 42 89 01 00 	mov    0x18942(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    8276:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    827a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    827e:	48 85 ed             	test   %rbp,%rbp
    8281:	74 38                	je     82bb <f37+0x18b>
    8283:	0f b6 0a             	movzbl (%rdx),%ecx
    8286:	80 f9 02             	cmp    $0x2,%cl
    8289:	0f 84 91 02 00 00    	je     8520 <f37+0x3f0>
    828f:	80 f9 01             	cmp    $0x1,%cl
    8292:	75 27                	jne    82bb <f37+0x18b>
    8294:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8297:	0f b7 c0             	movzwl %ax,%eax
    829a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    829d:	48 0f af c1          	imul   %rcx,%rax
    82a1:	48 c1 e8 20          	shr    $0x20,%rax
    82a5:	48 39 d0             	cmp    %rdx,%rax
    82a8:	73 11                	jae    82bb <f37+0x18b>
    82aa:	48 01 c5             	add    %rax,%rbp
    82ad:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    82b1:	0f 84 19 03 00 00    	je     85d0 <f37+0x4a0>
    82b7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    82bb:	48 85 db             	test   %rbx,%rbx
    82be:	74 5d                	je     831d <f37+0x1ed>
    82c0:	48 c1 e3 04          	shl    $0x4,%rbx
    82c4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    82c9:	4c 89 e5             	mov    %r12,%rbp
    82cc:	4d 89 ee             	mov    %r13,%r14
    82cf:	4c 01 e3             	add    %r12,%rbx
    82d2:	0f 1f 00             	nopl   (%rax)
    82d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82dc:	00 00 00 00 
    82e0:	49 8b 46 08          	mov    0x8(%r14),%rax
    82e4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    82e8:	48 83 c5 10          	add    $0x10,%rbp
    82ec:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    82f1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    82f5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    82f9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    82fe:	e8 cd df ff ff       	call   62d0 <w120>
    8303:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8308:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    830c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8310:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8314:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8318:	48 39 eb             	cmp    %rbp,%rbx
    831b:	75 c3                	jne    82e0 <f37+0x1b0>
    831d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8322:	31 db                	xor    %ebx,%ebx
    8324:	e8 c7 ed ff ff       	call   70f0 <fwp_drop4>
    8329:	4c 89 ef             	mov    %r13,%rdi
    832c:	e8 bf ed ff ff       	call   70f0 <fwp_drop4>
    8331:	4d 8b 2c 24          	mov    (%r12),%r13
    8335:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8339:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    8340:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    8347:	4d 85 ed             	test   %r13,%r13
    834a:	74 32                	je     837e <f37+0x24e>
    834c:	0f 1f 40 00          	nopl   0x0(%rax)
    8350:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    8357:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    835c:	48 83 c3 02          	add    $0x2,%rbx
    8360:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8366:	e8 e5 dd ff ff       	call   6150 <f141.constprop.0>
    836b:	4c 39 eb             	cmp    %r13,%rbx
    836e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    8374:	48 89 c7             	mov    %rax,%rdi
    8377:	72 d7                	jb     8350 <f37+0x220>
    8379:	66 49 0f 7e c5       	movq   %xmm0,%r13
    837e:	4c 89 e7             	mov    %r12,%rdi
    8381:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8386:	e8 45 fb ff ff       	call   7ed0 <fwp_drop10>
    838b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8390:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    8395:	31 ff                	xor    %edi,%edi
    8397:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    839c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    83a1:	e8 0a da ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    83a6:	48 8b 15 eb 87 01 00 	mov    0x187eb(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    83ad:	48 89 c5             	mov    %rax,%rbp
    83b0:	48 2b 05 b9 87 01 00 	sub    0x187b9(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    83b7:	48 c1 e2 10          	shl    $0x10,%rdx
    83bb:	48 39 d0             	cmp    %rdx,%rax
    83be:	73 55                	jae    8415 <f37+0x2e5>
    83c0:	48 89 c2             	mov    %rax,%rdx
    83c3:	48 c1 ea 10          	shr    $0x10,%rdx
    83c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83cb:	48 8b 15 e6 87 01 00 	mov    0x187e6(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    83d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83d6:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    83da:	48 85 db             	test   %rbx,%rbx
    83dd:	74 36                	je     8415 <f37+0x2e5>
    83df:	0f b6 0a             	movzbl (%rdx),%ecx
    83e2:	80 f9 02             	cmp    $0x2,%cl
    83e5:	0f 84 1d 01 00 00    	je     8508 <f37+0x3d8>
    83eb:	80 f9 01             	cmp    $0x1,%cl
    83ee:	75 25                	jne    8415 <f37+0x2e5>
    83f0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83f3:	0f b7 c0             	movzwl %ax,%eax
    83f6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83f9:	48 0f af c1          	imul   %rcx,%rax
    83fd:	48 c1 e8 20          	shr    $0x20,%rax
    8401:	48 39 d0             	cmp    %rdx,%rax
    8404:	73 0f                	jae    8415 <f37+0x2e5>
    8406:	48 01 c3             	add    %rax,%rbx
    8409:	80 3b ff             	cmpb   $0xff,(%rbx)
    840c:	0f 84 b1 01 00 00    	je     85c3 <f37+0x493>
    8412:	c6 03 01             	movb   $0x1,(%rbx)
    8415:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    841a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8421:	00 00 
    8423:	0f 85 d6 01 00 00    	jne    85ff <f37+0x4cf>
    8429:	48 83 c4 38          	add    $0x38,%rsp
    842d:	48 89 e8             	mov    %rbp,%rax
    8430:	5b                   	pop    %rbx
    8431:	5d                   	pop    %rbp
    8432:	41 5c                	pop    %r12
    8434:	41 5d                	pop    %r13
    8436:	41 5e                	pop    %r14
    8438:	41 5f                	pop    %r15
    843a:	c3                   	ret
    843b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8440:	66 85 c0             	test   %ax,%ax
    8443:	0f 85 8c fd ff ff    	jne    81d5 <f37+0xa5>
    8449:	0f b6 07             	movzbl (%rdi),%eax
    844c:	84 c0                	test   %al,%al
    844e:	0f 84 81 fd ff ff    	je     81d5 <f37+0xa5>
    8454:	3c fd                	cmp    $0xfd,%al
    8456:	0f 87 99 01 00 00    	ja     85f5 <f37+0x4c5>
    845c:	83 c0 01             	add    $0x1,%eax
    845f:	88 07                	mov    %al,(%rdi)
    8461:	e9 6f fd ff ff       	jmp    81d5 <f37+0xa5>
    8466:	48 f7 d9             	neg    %rcx
    8469:	48 39 d1             	cmp    %rdx,%rcx
    846c:	0f 83 ee 00 00 00    	jae    8560 <f37+0x430>
    8472:	48 89 c8             	mov    %rcx,%rax
    8475:	48 c1 e8 10          	shr    $0x10,%rax
    8479:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    847d:	48 8b 05 34 87 01 00 	mov    0x18734(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    8484:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8488:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    848c:	48 85 ff             	test   %rdi,%rdi
    848f:	0f 84 cb 00 00 00    	je     8560 <f37+0x430>
    8495:	0f b6 02             	movzbl (%rdx),%eax
    8498:	3c 02                	cmp    $0x2,%al
    849a:	0f 84 9a 00 00 00    	je     853a <f37+0x40a>
    84a0:	3c 01                	cmp    $0x1,%al
    84a2:	0f 85 b8 00 00 00    	jne    8560 <f37+0x430>
    84a8:	0f b7 c1             	movzwl %cx,%eax
    84ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84b1:	48 0f af c1          	imul   %rcx,%rax
    84b5:	48 c1 e8 20          	shr    $0x20,%rax
    84b9:	48 39 d0             	cmp    %rdx,%rax
    84bc:	0f 83 9e 00 00 00    	jae    8560 <f37+0x430>
    84c2:	48 01 c7             	add    %rax,%rdi
    84c5:	0f b6 07             	movzbl (%rdi),%eax
    84c8:	84 c0                	test   %al,%al
    84ca:	0f 84 90 00 00 00    	je     8560 <f37+0x430>
    84d0:	31 db                	xor    %ebx,%ebx
    84d2:	0f 1f 00             	nopl   (%rax)
    84d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    84dc:	00 00 00 00 
    84e0:	3c fd                	cmp    $0xfd,%al
    84e2:	0f 87 f5 00 00 00    	ja     85dd <f37+0x4ad>
    84e8:	83 c0 01             	add    $0x1,%eax
    84eb:	88 07                	mov    %al,(%rdi)
    84ed:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    84f2:	31 d2                	xor    %edx,%edx
    84f4:	4d 85 ed             	test   %r13,%r13
    84f7:	0f 85 dd fc ff ff    	jne    81da <f37+0xaa>
    84fd:	e9 fb fc ff ff       	jmp    81fd <f37+0xcd>
    8502:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8508:	66 85 c0             	test   %ax,%ax
    850b:	0f 85 04 ff ff ff    	jne    8415 <f37+0x2e5>
    8511:	e9 f3 fe ff ff       	jmp    8409 <f37+0x2d9>
    8516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    851d:	00 00 00 
    8520:	66 85 c0             	test   %ax,%ax
    8523:	0f 85 92 fd ff ff    	jne    82bb <f37+0x18b>
    8529:	e9 7f fd ff ff       	jmp    82ad <f37+0x17d>
    852e:	66 90                	xchg   %ax,%ax
    8530:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8535:	e9 a4 fc ff ff       	jmp    81de <f37+0xae>
    853a:	66 85 c9             	test   %cx,%cx
    853d:	75 21                	jne    8560 <f37+0x430>
    853f:	0f b6 07             	movzbl (%rdi),%eax
    8542:	84 c0                	test   %al,%al
    8544:	74 1a                	je     8560 <f37+0x430>
    8546:	3c fd                	cmp    $0xfd,%al
    8548:	0f 87 c2 00 00 00    	ja     8610 <f37+0x4e0>
    854e:	83 c0 01             	add    $0x1,%eax
    8551:	88 07                	mov    %al,(%rdi)
    8553:	66 90                	xchg   %ax,%ax
    8555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    855c:	00 00 00 00 
    8560:	be 02 00 00 00       	mov    $0x2,%esi
    8565:	bf 08 00 00 00       	mov    $0x8,%edi
    856a:	e8 21 d7 ff ff       	call   5c90 <fwp_heap_alloc>
    856f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8576:	48 8b 15 1b 86 01 00 	mov    0x1861b(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    857d:	49 89 c4             	mov    %rax,%r12
    8580:	48 2b 05 e9 85 01 00 	sub    0x185e9(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    8587:	48 c1 e2 10          	shl    $0x10,%rdx
    858b:	48 39 d0             	cmp    %rdx,%rax
    858e:	73 57                	jae    85e7 <f37+0x4b7>
    8590:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8597:	00 00 
    8599:	48 89 c2             	mov    %rax,%rdx
    859c:	48 c1 ea 10          	shr    $0x10,%rdx
    85a0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85a4:	48 8b 15 0d 86 01 00 	mov    0x1860d(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    85ab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85af:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    85b3:	48 85 ed             	test   %rbp,%rbp
    85b6:	0f 84 61 fd ff ff    	je     831d <f37+0x1ed>
    85bc:	31 db                	xor    %ebx,%ebx
    85be:	e9 c0 fc ff ff       	jmp    8283 <f37+0x153>
    85c3:	48 89 df             	mov    %rbx,%rdi
    85c6:	e8 85 cf ff ff       	call   5550 <fwp_rc_forget_slot>
    85cb:	e9 42 fe ff ff       	jmp    8412 <f37+0x2e2>
    85d0:	48 89 ef             	mov    %rbp,%rdi
    85d3:	e8 78 cf ff ff       	call   5550 <fwp_rc_forget_slot>
    85d8:	e9 da fc ff ff       	jmp    82b7 <f37+0x187>
    85dd:	e8 4e ce ff ff       	call   5430 <fwp_rc_wide_dup>
    85e2:	e9 06 ff ff ff       	jmp    84ed <f37+0x3bd>
    85e7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    85ee:	00 00 
    85f0:	e9 28 fd ff ff       	jmp    831d <f37+0x1ed>
    85f5:	e8 36 ce ff ff       	call   5430 <fwp_rc_wide_dup>
    85fa:	e9 d6 fb ff ff       	jmp    81d5 <f37+0xa5>
    85ff:	e8 5c ae ff ff       	call   3460 <__stack_chk_fail@plt>
    8604:	48 8d 3d 85 2b 00 00 	lea    0x2b85(%rip),%rdi        # b190 <_IO_stdin_used+0x190>
    860b:	e8 e0 bd ff ff       	call   43f0 <fwp_trap>
    8610:	e8 1b ce ff ff       	call   5430 <fwp_rc_wide_dup>
    8615:	e9 46 ff ff ff       	jmp    8560 <f37+0x430>
    861a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000008620 <fwp_owned_entry37>:
    8620:	f3 0f 1e fa          	endbr64
    8624:	48 8b 3f             	mov    (%rdi),%rdi
    8627:	e9 04 fb ff ff       	jmp    8130 <f37>
    862c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008630 <e37>:
    8630:	f3 0f 1e fa          	endbr64
    8634:	53                   	push   %rbx
    8635:	48 8b 1f             	mov    (%rdi),%rbx
    8638:	48 89 df             	mov    %rbx,%rdi
    863b:	e8 90 e2 ff ff       	call   68d0 <fwp_rc_share>
    8640:	48 89 df             	mov    %rbx,%rdi
    8643:	e8 e8 fa ff ff       	call   8130 <f37>
    8648:	48 89 c3             	mov    %rax,%rbx
    864b:	48 89 c7             	mov    %rax,%rdi
    864e:	e8 7d e2 ff ff       	call   68d0 <fwp_rc_share>
    8653:	48 89 d8             	mov    %rbx,%rax
    8656:	5b                   	pop    %rbx
    8657:	c3                   	ret
    8658:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    865f:	00 

0000000000008660 <fwp_write>:
    8660:	41 57                	push   %r15
    8662:	41 56                	push   %r14
    8664:	41 55                	push   %r13
    8666:	41 54                	push   %r12
    8668:	55                   	push   %rbp
    8669:	53                   	push   %rbx
    866a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8671:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8678:	00 00 
    867a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8681:	00 
    8682:	49 89 d4             	mov    %rdx,%r12
    8685:	8b 12                	mov    (%rdx),%edx
    8687:	83 fa 19             	cmp    $0x19,%edx
    868a:	77 6a                	ja     86f6 <fwp_write+0x96>
    868c:	48 89 f5             	mov    %rsi,%rbp
    868f:	89 d0                	mov    %edx,%eax
    8691:	89 ce                	mov    %ecx,%esi
    8693:	48 89 fb             	mov    %rdi,%rbx
    8696:	48 8d 0d b3 33 00 00 	lea    0x33b3(%rip),%rcx        # ba50 <_IO_stdin_used+0xa50>
    869d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    86a1:	48 01 c8             	add    %rcx,%rax
    86a4:	3e ff e0             	notrack jmp *%rax
    86a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    86ae:	00 00 
    86b0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    86b4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    86b8:	48 89 ca             	mov    %rcx,%rdx
    86bb:	48 85 c9             	test   %rcx,%rcx
    86be:	0f 88 9c 0c 00 00    	js     9360 <fwp_write+0xd00>
    86c4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    86cb:	00 
    86cc:	48 89 c6             	mov    %rax,%rsi
    86cf:	4c 89 e7             	mov    %r12,%rdi
    86d2:	e8 69 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    86d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    86de:	00 00 
    86e0:	4c 89 e7             	mov    %r12,%rdi
    86e3:	e8 68 ad ff ff       	call   3450 <strlen@plt>
    86e8:	4c 89 e6             	mov    %r12,%rsi
    86eb:	48 89 df             	mov    %rbx,%rdi
    86ee:	48 89 c2             	mov    %rax,%rdx
    86f1:	e8 1a bb ff ff       	call   4210 <buf_put>
    86f6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    86fd:	00 
    86fe:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8705:	00 00 
    8707:	0f 85 28 04 00 00    	jne    8b35 <fwp_write+0x4d5>
    870d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8714:	5b                   	pop    %rbx
    8715:	5d                   	pop    %rbp
    8716:	41 5c                	pop    %r12
    8718:	41 5d                	pop    %r13
    871a:	41 5e                	pop    %r14
    871c:	41 5f                	pop    %r15
    871e:	c3                   	ret
    871f:	90                   	nop
    8720:	49 89 e9             	mov    %rbp,%r9
    8723:	4c 8d 05 4b 29 00 00 	lea    0x294b(%rip),%r8        # b075 <_IO_stdin_used+0x75>
    872a:	b9 00 02 00 00       	mov    $0x200,%ecx
    872f:	ba 02 00 00 00       	mov    $0x2,%edx
    8734:	be 00 02 00 00       	mov    $0x200,%esi
    8739:	31 c0                	xor    %eax,%eax
    873b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8742:	00 
    8743:	e8 68 ac ff ff       	call   33b0 <__snprintf_chk@plt>
    8748:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    874f:	00 
    8750:	e8 fb ac ff ff       	call   3450 <strlen@plt>
    8755:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    875c:	00 
    875d:	48 89 df             	mov    %rbx,%rdi
    8760:	48 89 c2             	mov    %rax,%rdx
    8763:	e8 a8 ba ff ff       	call   4210 <buf_put>
    8768:	eb 8c                	jmp    86f6 <fwp_write+0x96>
    876a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8770:	49 89 e9             	mov    %rbp,%r9
    8773:	4c 8d 05 3b 2a 00 00 	lea    0x2a3b(%rip),%r8        # b1b5 <_IO_stdin_used+0x1b5>
    877a:	eb ae                	jmp    872a <fwp_write+0xca>
    877c:	0f 1f 40 00          	nopl   0x0(%rax)
    8780:	83 fa 13             	cmp    $0x13,%edx
    8783:	48 8d 05 21 2a 00 00 	lea    0x2a21(%rip),%rax        # b1ab <_IO_stdin_used+0x1ab>
    878a:	48 8d 35 1f 2a 00 00 	lea    0x2a1f(%rip),%rsi        # b1b0 <_IO_stdin_used+0x1b0>
    8791:	ba 04 00 00 00       	mov    $0x4,%edx
    8796:	48 0f 44 f0          	cmove  %rax,%rsi
    879a:	45 31 ed             	xor    %r13d,%r13d
    879d:	e8 6e ba ff ff       	call   4210 <buf_put>
    87a2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    87a7:	0f 84 a3 08 00 00    	je     9050 <fwp_write+0x9f0>
    87ad:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    87b2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    87b7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    87bc:	48 89 df             	mov    %rbx,%rdi
    87bf:	49 0f 44 c5          	cmove  %r13,%rax
    87c3:	31 c9                	xor    %ecx,%ecx
    87c5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    87ca:	e8 91 fe ff ff       	call   8660 <fwp_write>
    87cf:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    87d4:	0f 84 6e 09 00 00    	je     9148 <fwp_write+0xae8>
    87da:	49 83 c5 01          	add    $0x1,%r13
    87de:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    87e2:	0f 83 68 08 00 00    	jae    9050 <fwp_write+0x9f0>
    87e8:	ba 02 00 00 00       	mov    $0x2,%edx
    87ed:	48 8d 35 01 2a 00 00 	lea    0x2a01(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    87f4:	48 89 df             	mov    %rbx,%rdi
    87f7:	e8 14 ba ff ff       	call   4210 <buf_put>
    87fc:	eb af                	jmp    87ad <fwp_write+0x14d>
    87fe:	66 90                	xchg   %ax,%ax
    8800:	ba 06 00 00 00       	mov    $0x6,%edx
    8805:	48 8d 35 c2 29 00 00 	lea    0x29c2(%rip),%rsi        # b1ce <_IO_stdin_used+0x1ce>
    880c:	48 83 c5 10          	add    $0x10,%rbp
    8810:	e8 fb b9 ff ff       	call   4210 <buf_put>
    8815:	48 89 ef             	mov    %rbp,%rdi
    8818:	e8 33 ac ff ff       	call   3450 <strlen@plt>
    881d:	48 89 ee             	mov    %rbp,%rsi
    8820:	48 89 df             	mov    %rbx,%rdi
    8823:	48 89 c2             	mov    %rax,%rdx
    8826:	e8 e5 b9 ff ff       	call   4210 <buf_put>
    882b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8830:	ba 01 00 00 00       	mov    $0x1,%edx
    8835:	48 89 df             	mov    %rbx,%rdi
    8838:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    883d:	e8 ce b9 ff ff       	call   4210 <buf_put>
    8842:	e9 af fe ff ff       	jmp    86f6 <fwp_write+0x96>
    8847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    884e:	00 00 
    8850:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8857:	00 
    8858:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    885f:	00 00 
    8861:	0f 85 ce 02 00 00    	jne    8b35 <fwp_write+0x4d5>
    8867:	ba 0a 00 00 00       	mov    $0xa,%edx
    886c:	48 8d 35 47 29 00 00 	lea    0x2947(%rip),%rsi        # b1ba <_IO_stdin_used+0x1ba>
    8873:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    887a:	48 89 df             	mov    %rbx,%rdi
    887d:	5b                   	pop    %rbx
    887e:	5d                   	pop    %rbp
    887f:	41 5c                	pop    %r12
    8881:	41 5d                	pop    %r13
    8883:	41 5e                	pop    %r14
    8885:	41 5f                	pop    %r15
    8887:	e9 84 b9 ff ff       	jmp    4210 <buf_put>
    888c:	0f 1f 40 00          	nopl   0x0(%rax)
    8890:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8895:	4d 85 ed             	test   %r13,%r13
    8898:	0f 84 02 0c 00 00    	je     94a0 <fwp_write+0xe40>
    889e:	48 8d 35 5d 29 00 00 	lea    0x295d(%rip),%rsi        # b202 <_IO_stdin_used+0x202>
    88a5:	4c 89 ef             	mov    %r13,%rdi
    88a8:	e8 83 ac ff ff       	call   3530 <strcmp@plt>
    88ad:	41 89 c1             	mov    %eax,%r9d
    88b0:	85 c0                	test   %eax,%eax
    88b2:	0f 84 6c 0c 00 00    	je     9524 <fwp_write+0xec4>
    88b8:	4c 89 ef             	mov    %r13,%rdi
    88bb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    88c0:	e8 8b ab ff ff       	call   3450 <strlen@plt>
    88c5:	4c 89 ee             	mov    %r13,%rsi
    88c8:	48 89 df             	mov    %rbx,%rdi
    88cb:	48 89 c2             	mov    %rax,%rdx
    88ce:	e8 3d b9 ff ff       	call   4210 <buf_put>
    88d3:	ba 01 00 00 00       	mov    $0x1,%edx
    88d8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    88dd:	48 89 df             	mov    %rbx,%rdi
    88e0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    88e5:	e8 26 b9 ff ff       	call   4210 <buf_put>
    88ea:	ba 01 00 00 00       	mov    $0x1,%edx
    88ef:	4c 89 fe             	mov    %r15,%rsi
    88f2:	48 89 df             	mov    %rbx,%rdi
    88f5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    88fa:	e8 11 b9 ff ff       	call   4210 <buf_put>
    88ff:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8904:	45 31 f6             	xor    %r14d,%r14d
    8907:	85 d2                	test   %edx,%edx
    8909:	0f 8e 81 0a 00 00    	jle    9390 <fwp_write+0xd30>
    890f:	45 31 ed             	xor    %r13d,%r13d
    8912:	4d 85 ed             	test   %r13,%r13
    8915:	0f 85 75 07 00 00    	jne    9090 <fwp_write+0xa30>
    891b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8922:	00 
    8923:	45 85 f6             	test   %r14d,%r14d
    8926:	0f 84 84 07 00 00    	je     90b0 <fwp_write+0xa50>
    892c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8931:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8936:	48 89 df             	mov    %rbx,%rdi
    8939:	49 83 c5 01          	add    $0x1,%r13
    893d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8941:	31 c9                	xor    %ecx,%ecx
    8943:	e8 18 fd ff ff       	call   8660 <fwp_write>
    8948:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    894d:	7f c3                	jg     8912 <fwp_write+0x2b2>
    894f:	45 85 f6             	test   %r14d,%r14d
    8952:	0f 84 38 0a 00 00    	je     9390 <fwp_write+0xd30>
    8958:	b8 29 00 00 00       	mov    $0x29,%eax
    895d:	ba 01 00 00 00       	mov    $0x1,%edx
    8962:	4c 89 fe             	mov    %r15,%rsi
    8965:	48 89 df             	mov    %rbx,%rdi
    8968:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    896c:	e8 9f b8 ff ff       	call   4210 <buf_put>
    8971:	e9 80 fd ff ff       	jmp    86f6 <fwp_write+0x96>
    8976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    897d:	00 00 00 
    8980:	ba 01 00 00 00       	mov    $0x1,%edx
    8985:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    898a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    898f:	e8 7c b8 ff ff       	call   4210 <buf_put>
    8994:	48 85 ed             	test   %rbp,%rbp
    8997:	0f 84 93 06 00 00    	je     9030 <fwp_write+0x9d0>
    899d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    89a1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    89a6:	31 c9                	xor    %ecx,%ecx
    89a8:	48 89 df             	mov    %rbx,%rdi
    89ab:	e8 b0 fc ff ff       	call   8660 <fwp_write>
    89b0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    89b4:	48 85 ed             	test   %rbp,%rbp
    89b7:	0f 84 73 06 00 00    	je     9030 <fwp_write+0x9d0>
    89bd:	ba 02 00 00 00       	mov    $0x2,%edx
    89c2:	48 8d 35 2c 28 00 00 	lea    0x282c(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    89c9:	48 89 df             	mov    %rbx,%rdi
    89cc:	e8 3f b8 ff ff       	call   4210 <buf_put>
    89d1:	eb ca                	jmp    899d <fwp_write+0x33d>
    89d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    89d8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    89dc:	85 f6                	test   %esi,%esi
    89de:	0f 84 fc 07 00 00    	je     91e0 <fwp_write+0xb80>
    89e4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    89eb:	00 
    89ec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89f3:	00 00 
    89f5:	0f 85 3a 01 00 00    	jne    8b35 <fwp_write+0x4d5>
    89fb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    89ff:	4c 89 ea             	mov    %r13,%rdx
    8a02:	e9 6c fe ff ff       	jmp    8873 <fwp_write+0x213>
    8a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a0e:	00 00 
    8a10:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8a15:	ba 01 00 00 00       	mov    $0x1,%edx
    8a1a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8a1f:	48 89 ee             	mov    %rbp,%rsi
    8a22:	e8 e9 b7 ff ff       	call   4210 <buf_put>
    8a27:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8a2c:	4c 89 e7             	mov    %r12,%rdi
    8a2f:	e8 1c aa ff ff       	call   3450 <strlen@plt>
    8a34:	4c 89 e6             	mov    %r12,%rsi
    8a37:	48 89 df             	mov    %rbx,%rdi
    8a3a:	48 89 c2             	mov    %rax,%rdx
    8a3d:	e8 ce b7 ff ff       	call   4210 <buf_put>
    8a42:	ba 01 00 00 00       	mov    $0x1,%edx
    8a47:	48 89 ee             	mov    %rbp,%rsi
    8a4a:	48 89 df             	mov    %rbx,%rdi
    8a4d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8a52:	e8 b9 b7 ff ff       	call   4210 <buf_put>
    8a57:	e9 9a fc ff ff       	jmp    86f6 <fwp_write+0x96>
    8a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a60:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8a65:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8a69:	0f 8a 8e 0b 00 00    	jp     95fd <fwp_write+0xf9d>
    8a6f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a73:	66 0f 54 05 d5 30 00 	andpd  0x30d5(%rip),%xmm0        # bb50 <msg.4+0x90>
    8a7a:	00 
    8a7b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8a80:	66 0f 2e 05 00 31 00 	ucomisd 0x3100(%rip),%xmm0        # bb88 <msg.4+0xc8>
    8a87:	00 
    8a88:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8a8f:	00 
    8a90:	0f 87 b2 09 00 00    	ja     9448 <fwp_write+0xde8>
    8a96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a9d:	00 00 00 
    8aa0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8aa4:	89 ee                	mov    %ebp,%esi
    8aa6:	4c 89 e7             	mov    %r12,%rdi
    8aa9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8aae:	e8 5d bc ff ff       	call   4710 <fwp_format_g.constprop.0>
    8ab3:	31 f6                	xor    %esi,%esi
    8ab5:	4c 89 e7             	mov    %r12,%rdi
    8ab8:	e8 53 a9 ff ff       	call   3410 <strtod@plt>
    8abd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8ac2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8ac6:	7a 06                	jp     8ace <fwp_write+0x46e>
    8ac8:	0f 84 e9 01 00 00    	je     8cb7 <fwp_write+0x657>
    8ace:	83 c5 01             	add    $0x1,%ebp
    8ad1:	83 fd 12             	cmp    $0x12,%ebp
    8ad4:	75 ca                	jne    8aa0 <fwp_write+0x440>
    8ad6:	be 11 00 00 00       	mov    $0x11,%esi
    8adb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8adf:	4c 89 e7             	mov    %r12,%rdi
    8ae2:	e8 29 bc ff ff       	call   4710 <fwp_format_g.constprop.0>
    8ae7:	e9 cb 01 00 00       	jmp    8cb7 <fwp_write+0x657>
    8aec:	0f 1f 40 00          	nopl   0x0(%rax)
    8af0:	48 83 fd 01          	cmp    $0x1,%rbp
    8af4:	0f 84 e6 08 00 00    	je     93e0 <fwp_write+0xd80>
    8afa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8afe:	b8 02 00 00 00       	mov    $0x2,%eax
    8b03:	ba 01 00 00 00       	mov    $0x1,%edx
    8b08:	48 0f 44 d0          	cmove  %rax,%rdx
    8b0c:	48 8d 35 90 26 00 00 	lea    0x2690(%rip),%rsi        # b1a3 <_IO_stdin_used+0x1a3>
    8b13:	48 8d 05 8e 26 00 00 	lea    0x268e(%rip),%rax        # b1a8 <_IO_stdin_used+0x1a8>
    8b1a:	48 0f 44 f0          	cmove  %rax,%rsi
    8b1e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b25:	00 
    8b26:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b2d:	00 00 
    8b2f:	0f 84 3e fd ff ff    	je     8873 <fwp_write+0x213>
    8b35:	e8 26 a9 ff ff       	call   3460 <__stack_chk_fail@plt>
    8b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b40:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8b45:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8b4a:	e8 01 b6 ff ff       	call   4150 <buf_grow>
    8b4f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8b53:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8b59:	4c 03 0b             	add    (%rbx),%r9
    8b5c:	66 45 89 11          	mov    %r10w,(%r9)
    8b60:	45 85 e4             	test   %r12d,%r12d
    8b63:	0f 8e 07 05 00 00    	jle    9070 <fwp_write+0xa10>
    8b69:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8b70:	55 55 55 
    8b73:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8b78:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8b7f:	aa aa aa 
    8b82:	49 83 c1 01          	add    $0x1,%r9
    8b86:	eb 45                	jmp    8bcd <fwp_write+0x56d>
    8b88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b8f:	00 
    8b90:	be 01 00 00 00       	mov    $0x1,%esi
    8b95:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8b9a:	88 07                	mov    %al,(%rdi)
    8b9c:	48 89 e8             	mov    %rbp,%rax
    8b9f:	49 f7 e8             	imul   %r8
    8ba2:	48 89 e8             	mov    %rbp,%rax
    8ba5:	48 c1 f8 3f          	sar    $0x3f,%rax
    8ba9:	48 29 c2             	sub    %rax,%rdx
    8bac:	48 85 c9             	test   %rcx,%rcx
    8baf:	0f 95 c0             	setne  %al
    8bb2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8bb6:	48 83 ef 01          	sub    $0x1,%rdi
    8bba:	48 21 c5             	and    %rax,%rbp
    8bbd:	48 29 ea             	sub    %rbp,%rdx
    8bc0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8bc4:	49 39 f9             	cmp    %rdi,%r9
    8bc7:	0f 84 a3 04 00 00    	je     9070 <fwp_write+0xa10>
    8bcd:	48 89 e8             	mov    %rbp,%rax
    8bd0:	49 f7 e8             	imul   %r8
    8bd3:	48 89 e8             	mov    %rbp,%rax
    8bd6:	48 c1 f8 3f          	sar    $0x3f,%rax
    8bda:	48 89 d1             	mov    %rdx,%rcx
    8bdd:	48 29 c1             	sub    %rax,%rcx
    8be0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8be4:	48 89 e9             	mov    %rbp,%rcx
    8be7:	48 29 c1             	sub    %rax,%rcx
    8bea:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8bee:	49 f7 e2             	mul    %r10
    8bf1:	b8 30 00 00 00       	mov    $0x30,%eax
    8bf6:	48 89 d6             	mov    %rdx,%rsi
    8bf9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8bfd:	48 d1 ee             	shr    $1,%rsi
    8c00:	48 01 f2             	add    %rsi,%rdx
    8c03:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8c07:	48 29 d6             	sub    %rdx,%rsi
    8c0a:	74 8e                	je     8b9a <fwp_write+0x53a>
    8c0c:	48 83 fe 01          	cmp    $0x1,%rsi
    8c10:	0f 85 7a ff ff ff    	jne    8b90 <fwp_write+0x530>
    8c16:	31 f6                	xor    %esi,%esi
    8c18:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8c1d:	e9 78 ff ff ff       	jmp    8b9a <fwp_write+0x53a>
    8c22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c28:	66 0f 6e cd          	movd   %ebp,%xmm1
    8c2c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8c2f:	0f 8a c8 09 00 00    	jp     95fd <fwp_write+0xf9d>
    8c35:	0f 28 c1             	movaps %xmm1,%xmm0
    8c38:	0f 54 05 01 2f 00 00 	andps  0x2f01(%rip),%xmm0        # bb40 <msg.4+0x80>
    8c3f:	0f 2e 05 be 23 00 00 	ucomiss 0x23be(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    8c46:	0f 87 24 08 00 00    	ja     9470 <fwp_write+0xe10>
    8c4c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8c50:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8c56:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c5d:	00 
    8c5e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8c62:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8c67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c6e:	00 00 
    8c70:	44 89 ee             	mov    %r13d,%esi
    8c73:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8c78:	4c 89 e7             	mov    %r12,%rdi
    8c7b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8c80:	e8 8b ba ff ff       	call   4710 <fwp_format_g.constprop.0>
    8c85:	31 f6                	xor    %esi,%esi
    8c87:	4c 89 e7             	mov    %r12,%rdi
    8c8a:	e8 21 a8 ff ff       	call   34b0 <strtof@plt>
    8c8f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8c94:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8c97:	7a 02                	jp     8c9b <fwp_write+0x63b>
    8c99:	74 1c                	je     8cb7 <fwp_write+0x657>
    8c9b:	41 83 c5 01          	add    $0x1,%r13d
    8c9f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8ca3:	75 cb                	jne    8c70 <fwp_write+0x610>
    8ca5:	be 09 00 00 00       	mov    $0x9,%esi
    8caa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8caf:	4c 89 e7             	mov    %r12,%rdi
    8cb2:	e8 59 ba ff ff       	call   4710 <fwp_format_g.constprop.0>
    8cb7:	4c 89 e7             	mov    %r12,%rdi
    8cba:	e8 c1 b6 ff ff       	call   4380 <fwp_finish_float>
    8cbf:	e9 1c fa ff ff       	jmp    86e0 <fwp_write+0x80>
    8cc4:	0f 1f 40 00          	nopl   0x0(%rax)
    8cc8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8ccc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8cd0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8cd7:	00 
    8cd8:	48 89 ef             	mov    %rbp,%rdi
    8cdb:	e8 60 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8ce0:	48 89 ef             	mov    %rbp,%rdi
    8ce3:	e8 68 a7 ff ff       	call   3450 <strlen@plt>
    8ce8:	48 89 ee             	mov    %rbp,%rsi
    8ceb:	48 89 df             	mov    %rbx,%rdi
    8cee:	48 89 c2             	mov    %rax,%rdx
    8cf1:	e8 1a b5 ff ff       	call   4210 <buf_put>
    8cf6:	e9 fb f9 ff ff       	jmp    86f6 <fwp_write+0x96>
    8cfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8d00:	ba 06 00 00 00       	mov    $0x6,%edx
    8d05:	48 8d 35 ec 24 00 00 	lea    0x24ec(%rip),%rsi        # b1f8 <_IO_stdin_used+0x1f8>
    8d0c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8d12:	e8 f9 b4 ff ff       	call   4210 <buf_put>
    8d17:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d1e:	ff ff 7f 
    8d21:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d25:	0f 84 86 02 00 00    	je     8fb1 <fwp_write+0x951>
    8d2b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d30:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d34:	48 85 d2             	test   %rdx,%rdx
    8d37:	0f 84 ae 00 00 00    	je     8deb <fwp_write+0x78b>
    8d3d:	8b 0a                	mov    (%rdx),%ecx
    8d3f:	83 f9 1c             	cmp    $0x1c,%ecx
    8d42:	0f 84 58 06 00 00    	je     93a0 <fwp_write+0xd40>
    8d48:	83 f9 1b             	cmp    $0x1b,%ecx
    8d4b:	0f 87 9a 00 00 00    	ja     8deb <fwp_write+0x78b>
    8d51:	be 01 00 00 00       	mov    $0x1,%esi
    8d56:	48 d3 e6             	shl    %cl,%rsi
    8d59:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8d5f:	0f 85 4b 04 00 00    	jne    91b0 <fwp_write+0xb50>
    8d65:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8d6b:	0f 85 0f 04 00 00    	jne    9180 <fwp_write+0xb20>
    8d71:	83 e6 21             	and    $0x21,%esi
    8d74:	74 75                	je     8deb <fwp_write+0x78b>
    8d76:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8d7b:	48 85 ff             	test   %rdi,%rdi
    8d7e:	79 07                	jns    8d87 <fwp_write+0x727>
    8d80:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8d84:	4c 01 ee             	add    %r13,%rsi
    8d87:	48 0f be 3e          	movsbq (%rsi),%rdi
    8d8b:	85 c9                	test   %ecx,%ecx
    8d8d:	40 0f b6 f7          	movzbl %dil,%esi
    8d91:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d9c:	00 00 00 00 
    8da0:	31 c9                	xor    %ecx,%ecx
    8da2:	48 89 df             	mov    %rbx,%rdi
    8da5:	49 83 c5 01          	add    $0x1,%r13
    8da9:	e8 b2 f8 ff ff       	call   8660 <fwp_write>
    8dae:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8db5:	ff ff 7f 
    8db8:	48 23 55 00          	and    0x0(%rbp),%rdx
    8dbc:	49 39 d5             	cmp    %rdx,%r13
    8dbf:	0f 83 ec 01 00 00    	jae    8fb1 <fwp_write+0x951>
    8dc5:	ba 02 00 00 00       	mov    $0x2,%edx
    8dca:	48 89 df             	mov    %rbx,%rdi
    8dcd:	48 8d 35 21 24 00 00 	lea    0x2421(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8dd4:	e8 37 b4 ff ff       	call   4210 <buf_put>
    8dd9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8dde:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8de2:	48 85 d2             	test   %rdx,%rdx
    8de5:	0f 85 52 ff ff ff    	jne    8d3d <fwp_write+0x6dd>
    8deb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8df0:	48 85 ff             	test   %rdi,%rdi
    8df3:	0f 88 cf 05 00 00    	js     93c8 <fwp_write+0xd68>
    8df9:	48 8b 31             	mov    (%rcx),%rsi
    8dfc:	eb a2                	jmp    8da0 <fwp_write+0x740>
    8dfe:	66 90                	xchg   %ax,%ax
    8e00:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e07:	00 
    8e08:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e0f:	00 00 
    8e11:	0f 85 1e fd ff ff    	jne    8b35 <fwp_write+0x4d5>
    8e17:	ba 08 00 00 00       	mov    $0x8,%edx
    8e1c:	48 8d 35 a2 23 00 00 	lea    0x23a2(%rip),%rsi        # b1c5 <_IO_stdin_used+0x1c5>
    8e23:	e9 4b fa ff ff       	jmp    8873 <fwp_write+0x213>
    8e28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e2f:	00 
    8e30:	89 e8                	mov    %ebp,%eax
    8e32:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8e39:	76 03                	jbe    8e3e <fwp_write+0x7de>
    8e3b:	8b 45 00             	mov    0x0(%rbp),%eax
    8e3e:	41 89 c6             	mov    %eax,%r14d
    8e41:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8e46:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8e4b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8e4f:	4c 89 ef             	mov    %r13,%rdi
    8e52:	e8 f9 a5 ff ff       	call   3450 <strlen@plt>
    8e57:	4c 89 ee             	mov    %r13,%rsi
    8e5a:	48 89 df             	mov    %rbx,%rdi
    8e5d:	48 89 c2             	mov    %rax,%rdx
    8e60:	e8 ab b3 ff ff       	call   4210 <buf_put>
    8e65:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8e6a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8e6e:	85 f6                	test   %esi,%esi
    8e70:	0f 8e 80 f8 ff ff    	jle    86f6 <fwp_write+0x96>
    8e76:	45 31 ed             	xor    %r13d,%r13d
    8e79:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e7e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8e83:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8e88:	ba 01 00 00 00       	mov    $0x1,%edx
    8e8d:	4c 89 fe             	mov    %r15,%rsi
    8e90:	48 89 04 24          	mov    %rax,(%rsp)
    8e94:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8e99:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8e9d:	48 89 df             	mov    %rbx,%rdi
    8ea0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8ea4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8ea9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8eae:	e8 5d b3 ff ff       	call   4210 <buf_put>
    8eb3:	41 8b 06             	mov    (%r14),%eax
    8eb6:	83 f8 0e             	cmp    $0xe,%eax
    8eb9:	0f 84 71 02 00 00    	je     9130 <fwp_write+0xad0>
    8ebf:	83 f8 10             	cmp    $0x10,%eax
    8ec2:	0f 84 38 02 00 00    	je     9100 <fwp_write+0xaa0>
    8ec8:	83 f8 0a             	cmp    $0xa,%eax
    8ecb:	0f 84 7f 04 00 00    	je     9350 <fwp_write+0xcf0>
    8ed1:	0f 8f f9 00 00 00    	jg     8fd0 <fwp_write+0x970>
    8ed7:	83 f8 03             	cmp    $0x3,%eax
    8eda:	0f 8f 50 04 00 00    	jg     9330 <fwp_write+0xcd0>
    8ee0:	85 c0                	test   %eax,%eax
    8ee2:	78 10                	js     8ef4 <fwp_write+0x894>
    8ee4:	48 8b 04 24          	mov    (%rsp),%rax
    8ee8:	48 c1 e8 3f          	shr    $0x3f,%rax
    8eec:	85 c0                	test   %eax,%eax
    8eee:	0f 85 f9 00 00 00    	jne    8fed <fwp_write+0x98d>
    8ef4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8ef9:	48 8b 34 24          	mov    (%rsp),%rsi
    8efd:	31 c9                	xor    %ecx,%ecx
    8eff:	48 89 df             	mov    %rbx,%rdi
    8f02:	e8 59 f7 ff ff       	call   8660 <fwp_write>
    8f07:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8f0c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8f11:	49 83 c5 01          	add    $0x1,%r13
    8f15:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8f19:	0f 8f 5f ff ff ff    	jg     8e7e <fwp_write+0x81e>
    8f1f:	e9 d2 f7 ff ff       	jmp    86f6 <fwp_write+0x96>
    8f24:	0f 1f 40 00          	nopl   0x0(%rax)
    8f28:	ba 06 00 00 00       	mov    $0x6,%edx
    8f2d:	48 8d 35 b7 22 00 00 	lea    0x22b7(%rip),%rsi        # b1eb <_IO_stdin_used+0x1eb>
    8f34:	45 31 ed             	xor    %r13d,%r13d
    8f37:	e8 d4 b2 ff ff       	call   4210 <buf_put>
    8f3c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8f41:	75 19                	jne    8f5c <fwp_write+0x8fc>
    8f43:	eb 6c                	jmp    8fb1 <fwp_write+0x951>
    8f45:	0f 1f 00             	nopl   (%rax)
    8f48:	ba 02 00 00 00       	mov    $0x2,%edx
    8f4d:	48 8d 35 a1 22 00 00 	lea    0x22a1(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8f54:	48 89 df             	mov    %rbx,%rdi
    8f57:	e8 b4 b2 ff ff       	call   4210 <buf_put>
    8f5c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8f62:	b9 00 02 00 00       	mov    $0x200,%ecx
    8f67:	31 c0                	xor    %eax,%eax
    8f69:	49 83 c5 01          	add    $0x1,%r13
    8f6d:	4c 8d 05 7e 22 00 00 	lea    0x227e(%rip),%r8        # b1f2 <_IO_stdin_used+0x1f2>
    8f74:	ba 02 00 00 00       	mov    $0x2,%edx
    8f79:	be 00 02 00 00       	mov    $0x200,%esi
    8f7e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f85:	00 
    8f86:	e8 25 a4 ff ff       	call   33b0 <__snprintf_chk@plt>
    8f8b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f92:	00 
    8f93:	e8 b8 a4 ff ff       	call   3450 <strlen@plt>
    8f98:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8f9f:	00 
    8fa0:	48 89 df             	mov    %rbx,%rdi
    8fa3:	48 89 c2             	mov    %rax,%rdx
    8fa6:	e8 65 b2 ff ff       	call   4210 <buf_put>
    8fab:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8faf:	72 97                	jb     8f48 <fwp_write+0x8e8>
    8fb1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8fb6:	ba 01 00 00 00       	mov    $0x1,%edx
    8fbb:	48 89 df             	mov    %rbx,%rdi
    8fbe:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8fc3:	e8 48 b2 ff ff       	call   4210 <buf_put>
    8fc8:	e9 29 f7 ff ff       	jmp    86f6 <fwp_write+0x96>
    8fcd:	0f 1f 00             	nopl   (%rax)
    8fd0:	83 f8 0b             	cmp    $0xb,%eax
    8fd3:	0f 85 1b ff ff ff    	jne    8ef4 <fwp_write+0x894>
    8fd9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8fde:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8fe2:	83 e0 01             	and    $0x1,%eax
    8fe5:	85 c0                	test   %eax,%eax
    8fe7:	0f 84 07 ff ff ff    	je     8ef4 <fwp_write+0x894>
    8fed:	4c 89 fe             	mov    %r15,%rsi
    8ff0:	48 89 df             	mov    %rbx,%rdi
    8ff3:	ba 01 00 00 00       	mov    $0x1,%edx
    8ff8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8ffd:	e8 0e b2 ff ff       	call   4210 <buf_put>
    9002:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9007:	48 8b 34 24          	mov    (%rsp),%rsi
    900b:	31 c9                	xor    %ecx,%ecx
    900d:	48 89 df             	mov    %rbx,%rdi
    9010:	e8 4b f6 ff ff       	call   8660 <fwp_write>
    9015:	ba 01 00 00 00       	mov    $0x1,%edx
    901a:	4c 89 fe             	mov    %r15,%rsi
    901d:	48 89 df             	mov    %rbx,%rdi
    9020:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9025:	e8 e6 b1 ff ff       	call   4210 <buf_put>
    902a:	e9 d8 fe ff ff       	jmp    8f07 <fwp_write+0x8a7>
    902f:	90                   	nop
    9030:	ba 01 00 00 00       	mov    $0x1,%edx
    9035:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    903a:	48 89 df             	mov    %rbx,%rdi
    903d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9042:	e8 c9 b1 ff ff       	call   4210 <buf_put>
    9047:	e9 aa f6 ff ff       	jmp    86f6 <fwp_write+0x96>
    904c:	0f 1f 40 00          	nopl   0x0(%rax)
    9050:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9055:	ba 01 00 00 00       	mov    $0x1,%edx
    905a:	48 89 df             	mov    %rbx,%rdi
    905d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9062:	e8 a9 b1 ff ff       	call   4210 <buf_put>
    9067:	e9 8a f6 ff ff       	jmp    86f6 <fwp_write+0x96>
    906c:	0f 1f 40 00          	nopl   0x0(%rax)
    9070:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9074:	48 8b 13             	mov    (%rbx),%rdx
    9077:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    907c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9080:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9084:	e9 6d f6 ff ff       	jmp    86f6 <fwp_write+0x96>
    9089:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9090:	ba 02 00 00 00       	mov    $0x2,%edx
    9095:	48 8d 35 59 21 00 00 	lea    0x2159(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    909c:	48 89 df             	mov    %rbx,%rdi
    909f:	e8 6c b1 ff ff       	call   4210 <buf_put>
    90a4:	e9 72 f8 ff ff       	jmp    891b <fwp_write+0x2bb>
    90a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90b0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    90b5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    90ba:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    90be:	48 89 f7             	mov    %rsi,%rdi
    90c1:	48 89 34 24          	mov    %rsi,(%rsp)
    90c5:	e8 86 a3 ff ff       	call   3450 <strlen@plt>
    90ca:	48 8b 34 24          	mov    (%rsp),%rsi
    90ce:	48 89 df             	mov    %rbx,%rdi
    90d1:	48 89 c2             	mov    %rax,%rdx
    90d4:	e8 37 b1 ff ff       	call   4210 <buf_put>
    90d9:	ba 03 00 00 00       	mov    $0x3,%edx
    90de:	48 8d 35 33 21 00 00 	lea    0x2133(%rip),%rsi        # b218 <_IO_stdin_used+0x218>
    90e5:	48 89 df             	mov    %rbx,%rdi
    90e8:	e8 23 b1 ff ff       	call   4210 <buf_put>
    90ed:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    90f2:	e9 35 f8 ff ff       	jmp    892c <fwp_write+0x2cc>
    90f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    90fe:	00 00 
    9100:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9105:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9109:	48 85 ff             	test   %rdi,%rdi
    910c:	0f 84 e2 fd ff ff    	je     8ef4 <fwp_write+0x894>
    9112:	48 8d 35 e9 20 00 00 	lea    0x20e9(%rip),%rsi        # b202 <_IO_stdin_used+0x202>
    9119:	e8 12 a4 ff ff       	call   3530 <strcmp@plt>
    911e:	85 c0                	test   %eax,%eax
    9120:	0f 95 c0             	setne  %al
    9123:	0f b6 c0             	movzbl %al,%eax
    9126:	e9 c1 fd ff ff       	jmp    8eec <fwp_write+0x88c>
    912b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9130:	31 c0                	xor    %eax,%eax
    9132:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9139:	00 
    913a:	0f 97 c0             	seta   %al
    913d:	e9 aa fd ff ff       	jmp    8eec <fwp_write+0x88c>
    9142:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9148:	48 89 df             	mov    %rbx,%rdi
    914b:	ba 02 00 00 00       	mov    $0x2,%edx
    9150:	48 8d 35 a8 20 00 00 	lea    0x20a8(%rip),%rsi        # b1ff <_IO_stdin_used+0x1ff>
    9157:	e8 b4 b0 ff ff       	call   4210 <buf_put>
    915c:	4c 89 e8             	mov    %r13,%rax
    915f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9164:	31 c9                	xor    %ecx,%ecx
    9166:	48 c1 e0 04          	shl    $0x4,%rax
    916a:	48 89 df             	mov    %rbx,%rdi
    916d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9172:	e8 e9 f4 ff ff       	call   8660 <fwp_write>
    9177:	e9 5e f6 ff ff       	jmp    87da <fwp_write+0x17a>
    917c:	0f 1f 40 00          	nopl   0x0(%rax)
    9180:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9185:	48 85 ff             	test   %rdi,%rdi
    9188:	79 0c                	jns    9196 <fwp_write+0xb36>
    918a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9191:	00 
    9192:	48 03 75 10          	add    0x10(%rbp),%rsi
    9196:	48 63 3e             	movslq (%rsi),%rdi
    9199:	83 f9 02             	cmp    $0x2,%ecx
    919c:	89 fe                	mov    %edi,%esi
    919e:	48 0f 44 f7          	cmove  %rdi,%rsi
    91a2:	e9 f9 fb ff ff       	jmp    8da0 <fwp_write+0x740>
    91a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    91ae:	00 00 
    91b0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    91b5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    91ba:	48 85 ff             	test   %rdi,%rdi
    91bd:	0f 88 0f 03 00 00    	js     94d2 <fwp_write+0xe72>
    91c3:	49 0f bf 38          	movswq (%r8),%rdi
    91c7:	83 f9 01             	cmp    $0x1,%ecx
    91ca:	0f b7 f7             	movzwl %di,%esi
    91cd:	48 0f 44 f7          	cmove  %rdi,%rsi
    91d1:	e9 ca fb ff ff       	jmp    8da0 <fwp_write+0x740>
    91d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    91dd:	00 00 00 
    91e0:	ba 01 00 00 00       	mov    $0x1,%edx
    91e5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    91ea:	48 83 c5 08          	add    $0x8,%rbp
    91ee:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    91f3:	e8 18 b0 ff ff       	call   4210 <buf_put>
    91f8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    91fd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9202:	4d 85 ed             	test   %r13,%r13
    9205:	75 46                	jne    924d <fwp_write+0xbed>
    9207:	e9 04 01 00 00       	jmp    9310 <fwp_write+0xcb0>
    920c:	0f 1f 40 00          	nopl   0x0(%rax)
    9210:	41 80 f9 09          	cmp    $0x9,%r9b
    9214:	0f 84 d6 00 00 00    	je     92f0 <fwp_write+0xc90>
    921a:	41 80 f9 0a          	cmp    $0xa,%r9b
    921e:	0f 85 9c 00 00 00    	jne    92c0 <fwp_write+0xc60>
    9224:	ba 02 00 00 00       	mov    $0x2,%edx
    9229:	48 8d 35 ab 1f 00 00 	lea    0x1fab(%rip),%rsi        # b1db <_IO_stdin_used+0x1db>
    9230:	48 89 df             	mov    %rbx,%rdi
    9233:	e8 d8 af ff ff       	call   4210 <buf_put>
    9238:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    923f:	00 
    9240:	48 83 c5 01          	add    $0x1,%rbp
    9244:	49 39 ec             	cmp    %rbp,%r12
    9247:	0f 84 c3 00 00 00    	je     9310 <fwp_write+0xcb0>
    924d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9252:	41 80 f9 0d          	cmp    $0xd,%r9b
    9256:	74 28                	je     9280 <fwp_write+0xc20>
    9258:	7e b6                	jle    9210 <fwp_write+0xbb0>
    925a:	41 80 f9 22          	cmp    $0x22,%r9b
    925e:	74 40                	je     92a0 <fwp_write+0xc40>
    9260:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9264:	75 5a                	jne    92c0 <fwp_write+0xc60>
    9266:	ba 02 00 00 00       	mov    $0x2,%edx
    926b:	48 8d 35 66 1f 00 00 	lea    0x1f66(%rip),%rsi        # b1d8 <_IO_stdin_used+0x1d8>
    9272:	48 89 df             	mov    %rbx,%rdi
    9275:	e8 96 af ff ff       	call   4210 <buf_put>
    927a:	eb c4                	jmp    9240 <fwp_write+0xbe0>
    927c:	0f 1f 40 00          	nopl   0x0(%rax)
    9280:	ba 02 00 00 00       	mov    $0x2,%edx
    9285:	48 8d 35 55 1f 00 00 	lea    0x1f55(%rip),%rsi        # b1e1 <_IO_stdin_used+0x1e1>
    928c:	48 89 df             	mov    %rbx,%rdi
    928f:	e8 7c af ff ff       	call   4210 <buf_put>
    9294:	eb aa                	jmp    9240 <fwp_write+0xbe0>
    9296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    929d:	00 00 00 
    92a0:	ba 02 00 00 00       	mov    $0x2,%edx
    92a5:	48 8d 35 29 1f 00 00 	lea    0x1f29(%rip),%rsi        # b1d5 <_IO_stdin_used+0x1d5>
    92ac:	48 89 df             	mov    %rbx,%rdi
    92af:	e8 5c af ff ff       	call   4210 <buf_put>
    92b4:	eb 8a                	jmp    9240 <fwp_write+0xbe0>
    92b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92bd:	00 00 00 
    92c0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    92c4:	0f 86 2e 01 00 00    	jbe    93f8 <fwp_write+0xd98>
    92ca:	41 80 f9 7f          	cmp    $0x7f,%r9b
    92ce:	0f 84 24 01 00 00    	je     93f8 <fwp_write+0xd98>
    92d4:	ba 01 00 00 00       	mov    $0x1,%edx
    92d9:	4c 89 fe             	mov    %r15,%rsi
    92dc:	48 89 df             	mov    %rbx,%rdi
    92df:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    92e4:	e8 27 af ff ff       	call   4210 <buf_put>
    92e9:	e9 52 ff ff ff       	jmp    9240 <fwp_write+0xbe0>
    92ee:	66 90                	xchg   %ax,%ax
    92f0:	ba 02 00 00 00       	mov    $0x2,%edx
    92f5:	48 8d 35 e2 1e 00 00 	lea    0x1ee2(%rip),%rsi        # b1de <_IO_stdin_used+0x1de>
    92fc:	48 89 df             	mov    %rbx,%rdi
    92ff:	e8 0c af ff ff       	call   4210 <buf_put>
    9304:	e9 37 ff ff ff       	jmp    9240 <fwp_write+0xbe0>
    9309:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9310:	ba 01 00 00 00       	mov    $0x1,%edx
    9315:	4c 89 fe             	mov    %r15,%rsi
    9318:	48 89 df             	mov    %rbx,%rdi
    931b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9320:	e8 eb ae ff ff       	call   4210 <buf_put>
    9325:	e9 cc f3 ff ff       	jmp    86f6 <fwp_write+0x96>
    932a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9330:	83 f8 04             	cmp    $0x4,%eax
    9333:	0f 85 bb fb ff ff    	jne    8ef4 <fwp_write+0x894>
    9339:	48 8b 04 24          	mov    (%rsp),%rax
    933d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9341:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9346:	48 c1 e8 3f          	shr    $0x3f,%rax
    934a:	e9 96 fc ff ff       	jmp    8fe5 <fwp_write+0x985>
    934f:	90                   	nop
    9350:	8b 0c 24             	mov    (%rsp),%ecx
    9353:	31 c0                	xor    %eax,%eax
    9355:	85 c9                	test   %ecx,%ecx
    9357:	0f 98 c0             	sets   %al
    935a:	e9 86 fc ff ff       	jmp    8fe5 <fwp_write+0x985>
    935f:	90                   	nop
    9360:	48 f7 d8             	neg    %rax
    9363:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    936a:	00 
    936b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9372:	2d 
    9373:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    937a:	00 
    937b:	48 83 d2 00          	adc    $0x0,%rdx
    937f:	48 89 c6             	mov    %rax,%rsi
    9382:	48 f7 da             	neg    %rdx
    9385:	e8 b6 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    938a:	e9 51 f3 ff ff       	jmp    86e0 <fwp_write+0x80>
    938f:	90                   	nop
    9390:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9395:	e9 c3 f5 ff ff       	jmp    895d <fwp_write+0x2fd>
    939a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93a0:	4c 89 e9             	mov    %r13,%rcx
    93a3:	48 c1 e1 04          	shl    $0x4,%rcx
    93a7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    93ac:	48 85 ff             	test   %rdi,%rdi
    93af:	0f 89 eb f9 ff ff    	jns    8da0 <fwp_write+0x740>
    93b5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    93b9:	48 89 ce             	mov    %rcx,%rsi
    93bc:	e9 df f9 ff ff       	jmp    8da0 <fwp_write+0x740>
    93c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93c8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    93cf:	00 
    93d0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    93d4:	e9 20 fa ff ff       	jmp    8df9 <fwp_write+0x799>
    93d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93e0:	ba 02 00 00 00       	mov    $0x2,%edx
    93e5:	48 8d 35 b9 1d 00 00 	lea    0x1db9(%rip),%rsi        # b1a5 <_IO_stdin_used+0x1a5>
    93ec:	e9 2d f7 ff ff       	jmp    8b1e <fwp_write+0x4be>
    93f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93f8:	4c 8d 05 e5 1d 00 00 	lea    0x1de5(%rip),%r8        # b1e4 <_IO_stdin_used+0x1e4>
    93ff:	b9 10 00 00 00       	mov    $0x10,%ecx
    9404:	31 c0                	xor    %eax,%eax
    9406:	ba 02 00 00 00       	mov    $0x2,%edx
    940b:	be 10 00 00 00       	mov    $0x10,%esi
    9410:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9417:	00 
    9418:	e8 93 9f ff ff       	call   33b0 <__snprintf_chk@plt>
    941d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9424:	00 
    9425:	e8 26 a0 ff ff       	call   3450 <strlen@plt>
    942a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9431:	00 
    9432:	48 89 df             	mov    %rbx,%rdi
    9435:	48 89 c2             	mov    %rax,%rdx
    9438:	e8 d3 ad ff ff       	call   4210 <buf_put>
    943d:	e9 fe fd ff ff       	jmp    9240 <fwp_write+0xbe0>
    9442:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9448:	66 0f ef c0          	pxor   %xmm0,%xmm0
    944c:	48 8d 35 4c 1d 00 00 	lea    0x1d4c(%rip),%rsi        # b19f <_IO_stdin_used+0x19f>
    9453:	48 8d 05 44 1d 00 00 	lea    0x1d44(%rip),%rax        # b19e <_IO_stdin_used+0x19e>
    945a:	4c 89 e7             	mov    %r12,%rdi
    945d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9461:	48 0f 46 f0          	cmovbe %rax,%rsi
    9465:	e8 86 9f ff ff       	call   33f0 <strcpy@plt>
    946a:	e9 71 f2 ff ff       	jmp    86e0 <fwp_write+0x80>
    946f:	90                   	nop
    9470:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9474:	48 8d 35 24 1d 00 00 	lea    0x1d24(%rip),%rsi        # b19f <_IO_stdin_used+0x19f>
    947b:	48 8d 05 1c 1d 00 00 	lea    0x1d1c(%rip),%rax        # b19e <_IO_stdin_used+0x19e>
    9482:	0f 2f c8             	comiss %xmm0,%xmm1
    9485:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    948c:	00 
    948d:	4c 89 e7             	mov    %r12,%rdi
    9490:	48 0f 46 f0          	cmovbe %rax,%rsi
    9494:	e8 57 9f ff ff       	call   33f0 <strcpy@plt>
    9499:	e9 42 f2 ff ff       	jmp    86e0 <fwp_write+0x80>
    949e:	66 90                	xchg   %ax,%ax
    94a0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    94a5:	45 85 c0             	test   %r8d,%r8d
    94a8:	75 34                	jne    94de <fwp_write+0xe7e>
    94aa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    94b1:	00 
    94b2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    94b9:	00 00 
    94bb:	0f 85 74 f6 ff ff    	jne    8b35 <fwp_write+0x4d5>
    94c1:	ba 02 00 00 00       	mov    $0x2,%edx
    94c6:	48 8d 35 48 1d 00 00 	lea    0x1d48(%rip),%rsi        # b215 <_IO_stdin_used+0x215>
    94cd:	e9 a1 f3 ff ff       	jmp    8873 <fwp_write+0x213>
    94d2:	48 03 75 10          	add    0x10(%rbp),%rsi
    94d6:	49 89 f0             	mov    %rsi,%r8
    94d9:	e9 e5 fc ff ff       	jmp    91c3 <fwp_write+0xb63>
    94de:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    94e3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    94e8:	85 ff                	test   %edi,%edi
    94ea:	0f 84 fa f3 ff ff    	je     88ea <fwp_write+0x28a>
    94f0:	ba 01 00 00 00       	mov    $0x1,%edx
    94f5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    94fa:	48 89 df             	mov    %rbx,%rdi
    94fd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9502:	e8 09 ad ff ff       	call   4210 <buf_put>
    9507:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    950c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9511:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9517:	85 c0                	test   %eax,%eax
    9519:	0f 8f f0 f3 ff ff    	jg     890f <fwp_write+0x2af>
    951f:	e9 34 f4 ff ff       	jmp    8958 <fwp_write+0x2f8>
    9524:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9528:	49 89 c5             	mov    %rax,%r13
    952b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9530:	49 89 c4             	mov    %rax,%r12
    9533:	49 c1 fd 3f          	sar    $0x3f,%r13
    9537:	4c 09 e8             	or     %r13,%rax
    953a:	0f 84 a7 00 00 00    	je     95e7 <fwp_write+0xf87>
    9540:	48 8d 2d 59 3d 00 00 	lea    0x3d59(%rip),%rbp        # d2a0 <units.0>
    9547:	4d 89 e7             	mov    %r12,%r15
    954a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    954e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9553:	4c 89 ff             	mov    %r15,%rdi
    9556:	4c 89 ee             	mov    %r13,%rsi
    9559:	44 89 0c 24          	mov    %r9d,(%rsp)
    955d:	48 99                	cqto
    955f:	48 89 d1             	mov    %rdx,%rcx
    9562:	48 89 c2             	mov    %rax,%rdx
    9565:	e8 66 0f 00 00       	call   a4d0 <__divmodti4>
    956a:	44 8b 0c 24          	mov    (%rsp),%r9d
    956e:	48 89 c1             	mov    %rax,%rcx
    9571:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9576:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    957b:	0f 84 94 00 00 00    	je     9615 <fwp_write+0xfb5>
    9581:	41 83 c1 01          	add    $0x1,%r9d
    9585:	48 83 c5 10          	add    $0x10,%rbp
    9589:	41 83 f9 05          	cmp    $0x5,%r9d
    958d:	75 bb                	jne    954a <fwp_write+0xeea>
    958f:	4d 85 ed             	test   %r13,%r13
    9592:	79 53                	jns    95e7 <fwp_write+0xf87>
    9594:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9599:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    959e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    95a3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95a8:	48 99                	cqto
    95aa:	48 f7 d8             	neg    %rax
    95ad:	48 83 d2 00          	adc    $0x0,%rdx
    95b1:	48 89 c6             	mov    %rax,%rsi
    95b4:	48 f7 da             	neg    %rdx
    95b7:	e8 84 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    95bc:	49 89 e8             	mov    %rbp,%r8
    95bf:	ba 00 02 00 00       	mov    $0x200,%edx
    95c4:	be 02 00 00 00       	mov    $0x2,%esi
    95c9:	31 c0                	xor    %eax,%eax
    95cb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95d2:	00 
    95d3:	48 8d 0d 36 1c 00 00 	lea    0x1c36(%rip),%rcx        # b210 <_IO_stdin_used+0x210>
    95da:	4c 89 e7             	mov    %r12,%rdi
    95dd:	e8 fe a0 ff ff       	call   36e0 <__sprintf_chk@plt>
    95e2:	e9 f9 f0 ff ff       	jmp    86e0 <fwp_write+0x80>
    95e7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95ec:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    95f1:	31 d2                	xor    %edx,%edx
    95f3:	48 89 ef             	mov    %rbp,%rdi
    95f6:	e8 45 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    95fb:	eb bf                	jmp    95bc <fwp_write+0xf5c>
    95fd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9604:	4e 61 4e 00 
    9608:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    960f:	00 
    9610:	e9 cb f0 ff ff       	jmp    86e0 <fwp_write+0x80>
    9615:	44 89 0c 24          	mov    %r9d,(%rsp)
    9619:	48 89 c8             	mov    %rcx,%rax
    961c:	48 85 d2             	test   %rdx,%rdx
    961f:	78 51                	js     9672 <fwp_write+0x1012>
    9621:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9626:	48 89 c6             	mov    %rax,%rsi
    9629:	48 89 ef             	mov    %rbp,%rdi
    962c:	e8 0f a4 ff ff       	call   3a40 <fwp_fmt_u128>
    9631:	44 8b 0c 24          	mov    (%rsp),%r9d
    9635:	49 63 c1             	movslq %r9d,%rax
    9638:	49 89 e8             	mov    %rbp,%r8
    963b:	ba 00 02 00 00       	mov    $0x200,%edx
    9640:	be 02 00 00 00       	mov    $0x2,%esi
    9645:	48 c1 e0 04          	shl    $0x4,%rax
    9649:	48 8d 3d 50 3c 00 00 	lea    0x3c50(%rip),%rdi        # d2a0 <units.0>
    9650:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9657:	00 
    9658:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    965c:	48 8d 0d a8 1b 00 00 	lea    0x1ba8(%rip),%rcx        # b20b <_IO_stdin_used+0x20b>
    9663:	4c 89 e7             	mov    %r12,%rdi
    9666:	31 c0                	xor    %eax,%eax
    9668:	e8 73 a0 ff ff       	call   36e0 <__sprintf_chk@plt>
    966d:	e9 6e f0 ff ff       	jmp    86e0 <fwp_write+0x80>
    9672:	48 f7 d8             	neg    %rax
    9675:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    967a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    967f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9684:	48 83 d2 00          	adc    $0x0,%rdx
    9688:	48 89 c6             	mov    %rax,%rsi
    968b:	48 f7 da             	neg    %rdx
    968e:	e8 ad a3 ff ff       	call   3a40 <fwp_fmt_u128>
    9693:	44 8b 0c 24          	mov    (%rsp),%r9d
    9697:	eb 9c                	jmp    9635 <fwp_write+0xfd5>
    9699:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000096a0 <fwp_main_thread>:
    96a0:	f3 0f 1e fa          	endbr64
    96a4:	41 57                	push   %r15
    96a6:	41 56                	push   %r14
    96a8:	41 55                	push   %r13
    96aa:	41 54                	push   %r12
    96ac:	55                   	push   %rbp
    96ad:	53                   	push   %rbx
    96ae:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    96b5:	8b 35 a9 74 01 00    	mov    0x174a9(%rip),%esi        # 20b64 <fwp_heap+0x13a4>
    96bb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    96c2:	00 00 
    96c4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    96cb:	00 
    96cc:	31 c0                	xor    %eax,%eax
    96ce:	85 f6                	test   %esi,%esi
    96d0:	0f 84 f2 0b 00 00    	je     a2c8 <fwp_main_thread+0xc28>
    96d6:	8b 0d 8c 74 01 00    	mov    0x1748c(%rip),%ecx        # 20b68 <fwp_heap+0x13a8>
    96dc:	85 c9                	test   %ecx,%ecx
    96de:	0f 85 cc 0b 00 00    	jne    a2b0 <fwp_main_thread+0xc10>
    96e4:	48 8d 05 95 59 00 00 	lea    0x5995(%rip),%rax        # f080 <alt.5>
    96eb:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
    96f0:	31 f6                	xor    %esi,%esi
    96f2:	48 c7 05 53 5a 01 00 	movq   $0x40000000,0x15a53(%rip)        # 1f150 <fwp_main_stack_size>
    96f9:	00 00 00 40 
    96fd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9702:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9707:	48 89 c7             	mov    %rax,%rdi
    970a:	48 89 2d 47 5a 01 00 	mov    %rbp,0x15a47(%rip)        # 1f158 <fwp_main_stack_top>
    9711:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9718:	01 00 
    971a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    9721:	00 
    9722:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9727:	e8 94 9f ff ff       	call   36c0 <sigaltstack@plt>
    972c:	85 c0                	test   %eax,%eax
    972e:	0f 85 63 0d 00 00    	jne    a497 <fwp_main_thread+0xdf7>
    9734:	31 c0                	xor    %eax,%eax
    9736:	b9 12 00 00 00       	mov    $0x12,%ecx
    973b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9742:	00 
    9743:	f3 48 ab             	rep stos %rax,(%rdi)
    9746:	48 8d 05 a3 a5 ff ff 	lea    -0x5a5d(%rip),%rax        # 3cf0 <fwp_segv>
    974d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9754:	00 
    9755:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    975c:	04 00 00 08 
    9760:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9767:	00 
    9768:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    976f:	00 
    9770:	e8 0b 9e ff ff       	call   3580 <sigemptyset@plt>
    9775:	85 c0                	test   %eax,%eax
    9777:	0f 85 1a 0d 00 00    	jne    a497 <fwp_main_thread+0xdf7>
    977d:	31 d2                	xor    %edx,%edx
    977f:	48 89 de             	mov    %rbx,%rsi
    9782:	bf 0b 00 00 00       	mov    $0xb,%edi
    9787:	e8 74 9c ff ff       	call   3400 <sigaction@plt>
    978c:	85 c0                	test   %eax,%eax
    978e:	0f 85 03 0d 00 00    	jne    a497 <fwp_main_thread+0xdf7>
    9794:	31 d2                	xor    %edx,%edx
    9796:	48 89 de             	mov    %rbx,%rsi
    9799:	bf 07 00 00 00       	mov    $0x7,%edi
    979e:	e8 5d 9c ff ff       	call   3400 <sigaction@plt>
    97a3:	85 c0                	test   %eax,%eax
    97a5:	0f 85 ec 0c 00 00    	jne    a497 <fwp_main_thread+0xdf7>
    97ab:	8b 15 47 59 01 00    	mov    0x15947(%rip),%edx        # 1f0f8 <descent_registered>
    97b1:	85 d2                	test   %edx,%edx
    97b3:	0f 84 77 05 00 00    	je     9d30 <fwp_main_thread+0x690>
    97b9:	8b 05 a9 58 00 00    	mov    0x58a9(%rip),%eax        # f068 <st.3>
    97bf:	85 c0                	test   %eax,%eax
    97c1:	0f 84 95 05 00 00    	je     9d5c <fwp_main_thread+0x6bc>
    97c7:	48 8b 2d d2 5f 01 00 	mov    0x15fd2(%rip),%rbp        # 1f7a0 <fwp_cur>
    97ce:	48 85 ed             	test   %rbp,%rbp
    97d1:	0f 84 09 03 00 00    	je     9ae0 <fwp_main_thread+0x440>
    97d7:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    97dc:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    97e0:	48 89 eb             	mov    %rbp,%rbx
    97e3:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    97e8:	0f 84 41 01 00 00    	je     992f <fwp_main_thread+0x28f>
    97ee:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    97f3:	0f 84 17 02 00 00    	je     9a10 <fwp_main_thread+0x370>
    97f9:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    97fd:	0f 84 fd 01 00 00    	je     9a00 <fwp_main_thread+0x360>
    9803:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9807:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    980b:	0f 85 7f 02 00 00    	jne    9a90 <fwp_main_thread+0x3f0>
    9811:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9815:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    981c:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9820:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9827:	00 00 00 00 
    982b:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9832:	48 85 d2             	test   %rdx,%rdx
    9835:	74 07                	je     983e <fwp_main_thread+0x19e>
    9837:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    983e:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9842:	48 85 c0             	test   %rax,%rax
    9845:	74 34                	je     987b <fwp_main_thread+0x1db>
    9847:	48 89 43 68          	mov    %rax,0x68(%rbx)
    984b:	48 8b 05 26 5f 01 00 	mov    0x15f26(%rip),%rax        # 1f778 <fwp_timers>
    9852:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9856:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    985d:	00 00 00 00 
    9861:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9868:	48 85 c0             	test   %rax,%rax
    986b:	74 07                	je     9874 <fwp_main_thread+0x1d4>
    986d:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9874:	48 89 1d fd 5e 01 00 	mov    %rbx,0x15efd(%rip)        # 1f778 <fwp_timers>
    987b:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    987f:	e8 2c de ff ff       	call   76b0 <fwp_block>
    9884:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    988b:	48 85 c9             	test   %rcx,%rcx
    988e:	74 47                	je     98d7 <fwp_main_thread+0x237>
    9890:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9897:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    989e:	48 85 d2             	test   %rdx,%rdx
    98a1:	0f 84 29 02 00 00    	je     9ad0 <fwp_main_thread+0x430>
    98a7:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    98ae:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    98b5:	48 85 c0             	test   %rax,%rax
    98b8:	74 07                	je     98c1 <fwp_main_thread+0x221>
    98ba:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    98c1:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    98c8:	00 00 00 00 
    98cc:	66 0f ef c9          	pxor   %xmm1,%xmm1
    98d0:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    98d7:	48 8b 0d c2 5e 01 00 	mov    0x15ec2(%rip),%rcx        # 1f7a0 <fwp_cur>
    98de:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    98e2:	0f 84 98 01 00 00    	je     9a80 <fwp_main_thread+0x3e0>
    98e8:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    98ef:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    98f6:	48 85 d2             	test   %rdx,%rdx
    98f9:	0f 84 99 03 00 00    	je     9c98 <fwp_main_thread+0x5f8>
    98ff:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9906:	48 85 c0             	test   %rax,%rax
    9909:	74 07                	je     9912 <fwp_main_thread+0x272>
    990b:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9912:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9916:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    991a:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    9921:	48 89 cb             	mov    %rcx,%rbx
    9924:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9929:	0f 85 bf fe ff ff    	jne    97ee <fwp_main_thread+0x14e>
    992f:	48 83 3d 01 7b 01 00 	cmpq   $0x0,0x17b01(%rip)        # 21438 <fwp_state_len>
    9936:	00 
    9937:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    993b:	0f 84 81 03 00 00    	je     9cc2 <fwp_main_thread+0x622>
    9941:	48 39 1d 50 5e 01 00 	cmp    %rbx,0x15e50(%rip)        # 1f798 <fwp_root>
    9948:	c7 05 2e 57 01 00 00 	movl   $0x0,0x1572e(%rip)        # 1f080 <fwp_exit_code>
    994f:	00 00 00 
    9952:	0f 85 6d 0b 00 00    	jne    a4c5 <fwp_main_thread+0xe25>
    9958:	48 85 db             	test   %rbx,%rbx
    995b:	0f 84 a5 01 00 00    	je     9b06 <fwp_main_thread+0x466>
    9961:	48 8b 15 00 5e 01 00 	mov    0x15e00(%rip),%rdx        # 1f768 <fwp_tasks_active>
    9968:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    996c:	48 85 d2             	test   %rdx,%rdx
    996f:	0f 84 91 01 00 00    	je     9b06 <fwp_main_thread+0x466>
    9975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    997c:	00 00 00 00 
    9980:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9984:	75 08                	jne    998e <fwp_main_thread+0x2ee>
    9986:	48 89 d7             	mov    %rdx,%rdi
    9989:	e8 72 a9 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    998e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9995:	48 85 d2             	test   %rdx,%rdx
    9998:	75 e6                	jne    9980 <fwp_main_thread+0x2e0>
    999a:	eb 31                	jmp    99cd <fwp_main_thread+0x32d>
    999c:	0f 1f 40 00          	nopl   0x0(%rax)
    99a0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    99a7:	48 89 1d d2 5d 01 00 	mov    %rbx,0x15dd2(%rip)        # 1f780 <fwp_ready_tail>
    99ae:	e8 fd dc ff ff       	call   76b0 <fwp_block>
    99b3:	e8 e8 da ff ff       	call   74a0 <fwp_free_zombie>
    99b8:	48 83 3d a8 5d 01 00 	cmpq   $0x0,0x15da8(%rip)        # 1f768 <fwp_tasks_active>
    99bf:	00 
    99c0:	0f 84 40 01 00 00    	je     9b06 <fwp_main_thread+0x466>
    99c6:	48 8b 1d cb 5d 01 00 	mov    0x15dcb(%rip),%rbx        # 1f798 <fwp_root>
    99cd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    99d1:	75 db                	jne    99ae <fwp_main_thread+0x30e>
    99d3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    99d7:	75 d5                	jne    99ae <fwp_main_thread+0x30e>
    99d9:	48 8b 05 a0 5d 01 00 	mov    0x15da0(%rip),%rax        # 1f780 <fwp_ready_tail>
    99e0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    99e4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    99eb:	00 00 00 00 
    99ef:	48 85 c0             	test   %rax,%rax
    99f2:	75 ac                	jne    99a0 <fwp_main_thread+0x300>
    99f4:	48 89 1d 8d 5d 01 00 	mov    %rbx,0x15d8d(%rip)        # 1f788 <fwp_ready_head>
    99fb:	eb aa                	jmp    99a7 <fwp_main_thread+0x307>
    99fd:	0f 1f 00             	nopl   (%rax)
    9a00:	e8 5b ab ff ff       	call   4560 <fwp_now_ns>
    9a05:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9a09:	0f 8d 99 02 00 00    	jge    9ca8 <fwp_main_thread+0x608>
    9a0f:	90                   	nop
    9a10:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9a14:	0f 85 e9 fd ff ff    	jne    9803 <fwp_main_thread+0x163>
    9a1a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9a1e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9a22:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9a26:	0f 85 e9 fd ff ff    	jne    9815 <fwp_main_thread+0x175>
    9a2c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9a30:	48 85 c9             	test   %rcx,%rcx
    9a33:	0f 84 dc fd ff ff    	je     9815 <fwp_main_thread+0x175>
    9a39:	48 39 c8             	cmp    %rcx,%rax
    9a3c:	48 89 ce             	mov    %rcx,%rsi
    9a3f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9a46:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9a4a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9a51:	00 00 00 00 
    9a55:	48 0f 4e f0          	cmovle %rax,%rsi
    9a59:	48 85 c0             	test   %rax,%rax
    9a5c:	48 89 c8             	mov    %rcx,%rax
    9a5f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9a66:	48 0f 45 c6          	cmovne %rsi,%rax
    9a6a:	48 85 d2             	test   %rdx,%rdx
    9a6d:	74 07                	je     9a76 <fwp_main_thread+0x3d6>
    9a6f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9a76:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9a7a:	e9 c8 fd ff ff       	jmp    9847 <fwp_main_thread+0x1a7>
    9a7f:	90                   	nop
    9a80:	48 89 cb             	mov    %rcx,%rbx
    9a83:	e9 5b fd ff ff       	jmp    97e3 <fwp_main_thread+0x143>
    9a88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a8f:	00 
    9a90:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9a94:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9a9b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9aa2:	00 00 00 00 
    9aa6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9aad:	48 85 c0             	test   %rax,%rax
    9ab0:	0f 84 ba 08 00 00    	je     a370 <fwp_main_thread+0xcd0>
    9ab6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9abd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9ac1:	e9 b5 fd ff ff       	jmp    987b <fwp_main_thread+0x1db>
    9ac6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9acd:	00 00 00 
    9ad0:	48 89 01             	mov    %rax,(%rcx)
    9ad3:	e9 dd fd ff ff       	jmp    98b5 <fwp_main_thread+0x215>
    9ad8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9adf:	00 
    9ae0:	48 83 3d 50 79 01 00 	cmpq   $0x0,0x17950(%rip)        # 21438 <fwp_state_len>
    9ae7:	00 
    9ae8:	0f 84 d2 01 00 00    	je     9cc0 <fwp_main_thread+0x620>
    9aee:	48 83 3d a2 5c 01 00 	cmpq   $0x0,0x15ca2(%rip)        # 1f798 <fwp_root>
    9af5:	00 
    9af6:	c7 05 80 55 01 00 00 	movl   $0x0,0x15580(%rip)        # 1f080 <fwp_exit_code>
    9afd:	00 00 00 
    9b00:	0f 85 c4 09 00 00    	jne    a4ca <fwp_main_thread+0xe2a>
    9b06:	e8 95 d9 ff ff       	call   74a0 <fwp_free_zombie>
    9b0b:	48 83 3d 75 5c 01 00 	cmpq   $0x0,0x15c75(%rip)        # 1f788 <fwp_ready_head>
    9b12:	00 
    9b13:	0f 85 32 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9b19:	48 83 3d 57 5c 01 00 	cmpq   $0x0,0x15c57(%rip)        # 1f778 <fwp_timers>
    9b20:	00 
    9b21:	0f 85 24 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9b27:	8b 05 37 56 01 00    	mov    0x15637(%rip),%eax        # 1f164 <fwp_stack_pool_n>
    9b2d:	85 c0                	test   %eax,%eax
    9b2f:	74 3c                	je     9b6d <fwp_main_thread+0x4cd>
    9b31:	83 e8 01             	sub    $0x1,%eax
    9b34:	4c 8d 25 45 56 01 00 	lea    0x15645(%rip),%r12        # 1f180 <fwp_stack_pool>
    9b3b:	48 63 d8             	movslq %eax,%rbx
    9b3e:	89 c0                	mov    %eax,%eax
    9b40:	48 89 da             	mov    %rbx,%rdx
    9b43:	48 29 c2             	sub    %rax,%rdx
    9b46:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9b4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b50:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9b54:	89 1d 0a 56 01 00    	mov    %ebx,0x1560a(%rip)        # 1f164 <fwp_stack_pool_n>
    9b5a:	be 00 00 00 10       	mov    $0x10000000,%esi
    9b5f:	48 83 eb 01          	sub    $0x1,%rbx
    9b63:	e8 78 9a ff ff       	call   35e0 <munmap@plt>
    9b68:	48 39 dd             	cmp    %rbx,%rbp
    9b6b:	75 e3                	jne    9b50 <fwp_main_thread+0x4b0>
    9b6d:	8b 3d a1 54 00 00    	mov    0x54a1(%rip),%edi        # f014 <fwp_epfd>
    9b73:	85 ff                	test   %edi,%edi
    9b75:	78 05                	js     9b7c <fwp_main_thread+0x4dc>
    9b77:	e8 54 99 ff ff       	call   34d0 <close@plt>
    9b7c:	4c 8b 25 fd 57 01 00 	mov    0x157fd(%rip),%r12        # 1f380 <fwp_nfdws>
    9b83:	48 8b 2d fe 57 01 00 	mov    0x157fe(%rip),%rbp        # 1f388 <fwp_fdws>
    9b8a:	31 db                	xor    %ebx,%ebx
    9b8c:	c7 05 7e 54 00 00 ff 	movl   $0xffffffff,0x547e(%rip)        # f014 <fwp_epfd>
    9b93:	ff ff ff 
    9b96:	4d 85 e4             	test   %r12,%r12
    9b99:	74 32                	je     9bcd <fwp_main_thread+0x52d>
    9b9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ba0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9ba5:	48 85 ff             	test   %rdi,%rdi
    9ba8:	74 1a                	je     9bc4 <fwp_main_thread+0x524>
    9baa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9bae:	0f 85 97 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9bb4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9bb9:	0f 85 8c 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9bbf:	e8 cc bb ff ff       	call   5790 <fwp_mem_free>
    9bc4:	48 83 c3 01          	add    $0x1,%rbx
    9bc8:	49 39 dc             	cmp    %rbx,%r12
    9bcb:	75 d3                	jne    9ba0 <fwp_main_thread+0x500>
    9bcd:	48 89 ef             	mov    %rbp,%rdi
    9bd0:	e8 bb bb ff ff       	call   5790 <fwp_mem_free>
    9bd5:	48 8b 15 bc 5b 01 00 	mov    0x15bbc(%rip),%rdx        # 1f798 <fwp_root>
    9bdc:	48 c7 05 a1 57 01 00 	movq   $0x0,0x157a1(%rip)        # 1f388 <fwp_fdws>
    9be3:	00 00 00 00 
    9be7:	48 c7 05 8e 57 01 00 	movq   $0x0,0x1578e(%rip)        # 1f380 <fwp_nfdws>
    9bee:	00 00 00 00 
    9bf2:	48 85 d2             	test   %rdx,%rdx
    9bf5:	74 4e                	je     9c45 <fwp_main_thread+0x5a5>
    9bf7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9bfc:	0f 85 49 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9c02:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9c09:	00 
    9c0a:	0f 85 3b 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9c10:	48 83 3d 20 78 01 00 	cmpq   $0x0,0x17820(%rip)        # 21438 <fwp_state_len>
    9c17:	00 
    9c18:	0f 85 2d 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9c1e:	48 83 3d 02 78 01 00 	cmpq   $0x0,0x17802(%rip)        # 21428 <fwp_state_owners>
    9c25:	00 
    9c26:	0f 85 1f 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9c2c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9c31:	31 c0                	xor    %eax,%eax
    9c33:	48 8d 3d 66 57 01 00 	lea    0x15766(%rip),%rdi        # 1f3a0 <fwp_root_context>
    9c3a:	f3 48 ab             	rep stos %rax,(%rdi)
    9c3d:	48 89 d7             	mov    %rdx,%rdi
    9c40:	e8 4b bb ff ff       	call   5790 <fwp_mem_free>
    9c45:	48 8b 3d d4 53 00 00 	mov    0x53d4(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    9c4c:	48 c7 05 49 5b 01 00 	movq   $0x0,0x15b49(%rip)        # 1f7a0 <fwp_cur>
    9c53:	00 00 00 00 
    9c57:	48 c7 05 36 5b 01 00 	movq   $0x0,0x15b36(%rip)        # 1f798 <fwp_root>
    9c5e:	00 00 00 00 
    9c62:	e8 59 99 ff ff       	call   35c0 <fflush@plt>
    9c67:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    9c6e:	00 
    9c6f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c76:	00 00 
    9c78:	0f 85 36 08 00 00    	jne    a4b4 <fwp_main_thread+0xe14>
    9c7e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9c85:	31 c0                	xor    %eax,%eax
    9c87:	5b                   	pop    %rbx
    9c88:	5d                   	pop    %rbp
    9c89:	41 5c                	pop    %r12
    9c8b:	41 5d                	pop    %r13
    9c8d:	41 5e                	pop    %r14
    9c8f:	41 5f                	pop    %r15
    9c91:	c3                   	ret
    9c92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c98:	48 89 05 d9 5a 01 00 	mov    %rax,0x15ad9(%rip)        # 1f778 <fwp_timers>
    9c9f:	e9 62 fc ff ff       	jmp    9906 <fwp_main_thread+0x266>
    9ca4:	0f 1f 40 00          	nopl   0x0(%rax)
    9ca8:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9cac:	0f 85 5e fd ff ff    	jne    9a10 <fwp_main_thread+0x370>
    9cb2:	48 89 ef             	mov    %rbp,%rdi
    9cb5:	e8 46 a6 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    9cba:	e9 51 fd ff ff       	jmp    9a10 <fwp_main_thread+0x370>
    9cbf:	90                   	nop
    9cc0:	31 db                	xor    %ebx,%ebx
    9cc2:	48 83 3d 5e 77 01 00 	cmpq   $0x0,0x1775e(%rip)        # 21428 <fwp_state_owners>
    9cc9:	00 
    9cca:	0f 85 71 fc ff ff    	jne    9941 <fwp_main_thread+0x2a1>
    9cd0:	48 8b 3d 69 77 01 00 	mov    0x17769(%rip),%rdi        # 21440 <fwp_state>
    9cd7:	e8 b4 ba ff ff       	call   5790 <fwp_mem_free>
    9cdc:	48 c7 05 59 77 01 00 	movq   $0x0,0x17759(%rip)        # 21440 <fwp_state>
    9ce3:	00 00 00 00 
    9ce7:	48 c7 05 3e 77 01 00 	movq   $0x0,0x1773e(%rip)        # 21430 <fwp_state_cap>
    9cee:	00 00 00 00 
    9cf2:	48 85 db             	test   %rbx,%rbx
    9cf5:	0f 84 4f 07 00 00    	je     a44a <fwp_main_thread+0xdaa>
    9cfb:	48 39 1d 96 5a 01 00 	cmp    %rbx,0x15a96(%rip)        # 1f798 <fwp_root>
    9d02:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9d09:	00 00 00 00 
    9d0d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9d14:	00 00 00 00 
    9d18:	c7 05 5e 53 01 00 00 	movl   $0x0,0x1535e(%rip)        # 1f080 <fwp_exit_code>
    9d1f:	00 00 00 
    9d22:	0f 84 39 fc ff ff    	je     9961 <fwp_main_thread+0x2c1>
    9d28:	e9 1e 9a ff ff       	jmp    374b <fwp_main_thread.cold>
    9d2d:	0f 1f 00             	nopl   (%rax)
    9d30:	48 8d 3d d9 a0 ff ff 	lea    -0x5f27(%rip),%rdi        # 3e10 <descent_phase_report>
    9d37:	e8 a4 09 00 00       	call   a6e0 <atexit>
    9d3c:	85 c0                	test   %eax,%eax
    9d3e:	0f 85 6b 07 00 00    	jne    a4af <fwp_main_thread+0xe0f>
    9d44:	c7 05 aa 53 01 00 01 	movl   $0x1,0x153aa(%rip)        # 1f0f8 <descent_registered>
    9d4b:	00 00 00 
    9d4e:	8b 05 14 53 00 00    	mov    0x5314(%rip),%eax        # f068 <st.3>
    9d54:	85 c0                	test   %eax,%eax
    9d56:	0f 85 6b fa ff ff    	jne    97c7 <fwp_main_thread+0x127>
    9d5c:	48 8d 05 6d df ff ff 	lea    -0x2093(%rip),%rax        # 7cd0 <fwp_drop1>
    9d63:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9d67:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    9d6e:	00 00 
    9d70:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    9d76:	66 48 0f 6e d8       	movq   %rax,%xmm3
    9d7b:	48 8b 05 d6 76 01 00 	mov    0x176d6(%rip),%rax        # 21458 <fwp_cleanups>
    9d82:	4c 8d 3d 37 5a 01 00 	lea    0x15a37(%rip),%r15        # 1f7c0 <fwp_heap>
    9d89:	48 89 2d c8 76 01 00 	mov    %rbp,0x176c8(%rip)        # 21458 <fwp_cleanups>
    9d90:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9d94:	31 ed                	xor    %ebp,%ebp
    9d96:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9d9b:	48 8d 05 2e 9e ff ff 	lea    -0x61d2(%rip),%rax        # 3bd0 <fwp_range_release>
    9da2:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9da7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9dac:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    9db1:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9db6:	eb 45                	jmp    9dfd <fwp_main_thread+0x75d>
    9db8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9dbf:	00 
    9dc0:	80 f9 01             	cmp    $0x1,%cl
    9dc3:	75 29                	jne    9dee <fwp_main_thread+0x74e>
    9dc5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9dc8:	0f b7 c0             	movzwl %ax,%eax
    9dcb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9dce:	48 0f af c1          	imul   %rcx,%rax
    9dd2:	48 c1 e8 20          	shr    $0x20,%rax
    9dd6:	48 39 d0             	cmp    %rdx,%rax
    9dd9:	73 13                	jae    9dee <fwp_main_thread+0x74e>
    9ddb:	49 01 c5             	add    %rax,%r13
    9dde:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9de3:	0f 84 c7 05 00 00    	je     a3b0 <fwp_main_thread+0xd10>
    9de9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9dee:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9df3:	49 83 ec 01          	sub    $0x1,%r12
    9df7:	0f 82 83 00 00 00    	jb     9e80 <fwp_main_thread+0x7e0>
    9dfd:	48 89 de             	mov    %rbx,%rsi
    9e00:	bf 01 00 00 00       	mov    $0x1,%edi
    9e05:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    9e0c:	00 
    9e0d:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    9e12:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    9e19:	00 
    9e1a:	e8 91 bf ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9e1f:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9e26:	48 89 c5             	mov    %rax,%rbp
    9e29:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9e30:	48 c1 e2 10          	shl    $0x10,%rdx
    9e34:	48 39 d0             	cmp    %rdx,%rax
    9e37:	73 b5                	jae    9dee <fwp_main_thread+0x74e>
    9e39:	48 89 c2             	mov    %rax,%rdx
    9e3c:	48 c1 ea 10          	shr    $0x10,%rdx
    9e40:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e44:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9e4b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e4f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9e53:	4d 85 ed             	test   %r13,%r13
    9e56:	74 96                	je     9dee <fwp_main_thread+0x74e>
    9e58:	0f b6 0a             	movzbl (%rdx),%ecx
    9e5b:	80 f9 02             	cmp    $0x2,%cl
    9e5e:	0f 85 5c ff ff ff    	jne    9dc0 <fwp_main_thread+0x720>
    9e64:	66 85 c0             	test   %ax,%ax
    9e67:	0f 84 71 ff ff ff    	je     9dde <fwp_main_thread+0x73e>
    9e6d:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9e72:	49 83 ec 01          	sub    $0x1,%r12
    9e76:	73 85                	jae    9dfd <fwp_main_thread+0x75d>
    9e78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e7f:	00 
    9e80:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9e85:	66 0f 6f 05 d3 1c 00 	movdqa 0x1cd3(%rip),%xmm0        # bb60 <msg.4+0xa0>
    9e8c:	00 
    9e8d:	48 89 de             	mov    %rbx,%rsi
    9e90:	bf 01 00 00 00       	mov    $0x1,%edi
    9e95:	48 89 05 bc 75 01 00 	mov    %rax,0x175bc(%rip)        # 21458 <fwp_cleanups>
    9e9c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    9ea3:	00 
    9ea4:	e8 07 bf ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9ea9:	48 8b 15 e8 6c 01 00 	mov    0x16ce8(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    9eb0:	49 89 c4             	mov    %rax,%r12
    9eb3:	48 2b 05 b6 6c 01 00 	sub    0x16cb6(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    9eba:	48 c1 e2 10          	shl    $0x10,%rdx
    9ebe:	48 39 d0             	cmp    %rdx,%rax
    9ec1:	73 55                	jae    9f18 <fwp_main_thread+0x878>
    9ec3:	48 89 c2             	mov    %rax,%rdx
    9ec6:	48 c1 ea 10          	shr    $0x10,%rdx
    9eca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ece:	48 8b 15 e3 6c 01 00 	mov    0x16ce3(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    9ed5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ed9:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9edd:	48 85 db             	test   %rbx,%rbx
    9ee0:	74 36                	je     9f18 <fwp_main_thread+0x878>
    9ee2:	0f b6 0a             	movzbl (%rdx),%ecx
    9ee5:	80 f9 02             	cmp    $0x2,%cl
    9ee8:	0f 84 b2 04 00 00    	je     a3a0 <fwp_main_thread+0xd00>
    9eee:	80 f9 01             	cmp    $0x1,%cl
    9ef1:	75 25                	jne    9f18 <fwp_main_thread+0x878>
    9ef3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ef6:	0f b7 c0             	movzwl %ax,%eax
    9ef9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9efc:	48 0f af c1          	imul   %rcx,%rax
    9f00:	48 c1 e8 20          	shr    $0x20,%rax
    9f04:	48 39 d0             	cmp    %rdx,%rax
    9f07:	73 0f                	jae    9f18 <fwp_main_thread+0x878>
    9f09:	48 01 c3             	add    %rax,%rbx
    9f0c:	80 3b ff             	cmpb   $0xff,(%rbx)
    9f0f:	0f 84 5b 05 00 00    	je     a470 <fwp_main_thread+0xdd0>
    9f15:	c6 03 01             	movb   $0x1,(%rbx)
    9f18:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    9f1d:	bf 01 00 00 00       	mov    $0x1,%edi
    9f22:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    9f27:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9f2e:	00 f0 3f 
    9f31:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9f36:	e8 75 be ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9f3b:	48 8b 15 56 6c 01 00 	mov    0x16c56(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    9f42:	49 89 c4             	mov    %rax,%r12
    9f45:	48 2b 05 24 6c 01 00 	sub    0x16c24(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    9f4c:	48 c1 e2 10          	shl    $0x10,%rdx
    9f50:	48 39 d0             	cmp    %rdx,%rax
    9f53:	73 55                	jae    9faa <fwp_main_thread+0x90a>
    9f55:	48 89 c2             	mov    %rax,%rdx
    9f58:	48 c1 ea 10          	shr    $0x10,%rdx
    9f5c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f60:	48 8b 15 51 6c 01 00 	mov    0x16c51(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    9f67:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f6b:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9f6f:	48 85 db             	test   %rbx,%rbx
    9f72:	74 36                	je     9faa <fwp_main_thread+0x90a>
    9f74:	0f b6 0a             	movzbl (%rdx),%ecx
    9f77:	80 f9 02             	cmp    $0x2,%cl
    9f7a:	0f 84 10 04 00 00    	je     a390 <fwp_main_thread+0xcf0>
    9f80:	80 f9 01             	cmp    $0x1,%cl
    9f83:	75 25                	jne    9faa <fwp_main_thread+0x90a>
    9f85:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f88:	0f b7 c0             	movzwl %ax,%eax
    9f8b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f8e:	48 0f af c1          	imul   %rcx,%rax
    9f92:	48 c1 e8 20          	shr    $0x20,%rax
    9f96:	48 39 d0             	cmp    %rdx,%rax
    9f99:	73 0f                	jae    9faa <fwp_main_thread+0x90a>
    9f9b:	48 01 c3             	add    %rax,%rbx
    9f9e:	80 3b ff             	cmpb   $0xff,(%rbx)
    9fa1:	0f 84 d6 04 00 00    	je     a47d <fwp_main_thread+0xddd>
    9fa7:	c6 03 01             	movb   $0x1,(%rbx)
    9faa:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    9faf:	bf 01 00 00 00       	mov    $0x1,%edi
    9fb4:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    9fb9:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9fc0:	33 f3 bf 
    9fc3:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    9fc8:	e8 e3 bd ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9fcd:	48 8b 15 c4 6b 01 00 	mov    0x16bc4(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    9fd4:	48 8b 0d 95 6b 01 00 	mov    0x16b95(%rip),%rcx        # 20b70 <fwp_heap+0x13b0>
    9fdb:	49 89 c4             	mov    %rax,%r12
    9fde:	48 89 d6             	mov    %rdx,%rsi
    9fe1:	48 29 c8             	sub    %rcx,%rax
    9fe4:	48 c1 e6 10          	shl    $0x10,%rsi
    9fe8:	48 39 f0             	cmp    %rsi,%rax
    9feb:	73 65                	jae    a052 <fwp_main_thread+0x9b2>
    9fed:	48 89 c6             	mov    %rax,%rsi
    9ff0:	48 c1 ee 10          	shr    $0x10,%rsi
    9ff4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9ff8:	48 8b 35 b9 6b 01 00 	mov    0x16bb9(%rip),%rsi        # 20bb8 <fwp_heap+0x13f8>
    9fff:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a003:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    a007:	48 85 db             	test   %rbx,%rbx
    a00a:	74 46                	je     a052 <fwp_main_thread+0x9b2>
    a00c:	0f b6 3e             	movzbl (%rsi),%edi
    a00f:	40 80 ff 02          	cmp    $0x2,%dil
    a013:	0f 84 67 03 00 00    	je     a380 <fwp_main_thread+0xce0>
    a019:	40 80 ff 01          	cmp    $0x1,%dil
    a01d:	75 33                	jne    a052 <fwp_main_thread+0x9b2>
    a01f:	8b 7e 18             	mov    0x18(%rsi),%edi
    a022:	0f b7 c0             	movzwl %ax,%eax
    a025:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a028:	48 0f af c7          	imul   %rdi,%rax
    a02c:	48 c1 e8 20          	shr    $0x20,%rax
    a030:	48 39 f0             	cmp    %rsi,%rax
    a033:	73 1d                	jae    a052 <fwp_main_thread+0x9b2>
    a035:	48 01 c3             	add    %rax,%rbx
    a038:	80 3b ff             	cmpb   $0xff,(%rbx)
    a03b:	0f 84 49 04 00 00    	je     a48a <fwp_main_thread+0xdea>
    a041:	c6 03 01             	movb   $0x1,(%rbx)
    a044:	48 8b 0d 25 6b 01 00 	mov    0x16b25(%rip),%rcx        # 20b70 <fwp_heap+0x13b0>
    a04b:	48 8b 15 46 6b 01 00 	mov    0x16b46(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    a052:	49 89 ed             	mov    %rbp,%r13
    a055:	e9 01 02 00 00       	jmp    a25b <fwp_main_thread+0xbbb>
    a05a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a060:	80 f9 01             	cmp    $0x1,%cl
    a063:	75 2d                	jne    a092 <fwp_main_thread+0x9f2>
    a065:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a068:	0f b7 c0             	movzwl %ax,%eax
    a06b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a06e:	48 0f af c1          	imul   %rcx,%rax
    a072:	48 c1 e8 20          	shr    $0x20,%rax
    a076:	48 39 d0             	cmp    %rdx,%rax
    a079:	73 17                	jae    a092 <fwp_main_thread+0x9f2>
    a07b:	48 01 c7             	add    %rax,%rdi
    a07e:	0f b6 07             	movzbl (%rdi),%eax
    a081:	84 c0                	test   %al,%al
    a083:	74 0d                	je     a092 <fwp_main_thread+0x9f2>
    a085:	3c fd                	cmp    $0xfd,%al
    a087:	0f 87 b3 03 00 00    	ja     a440 <fwp_main_thread+0xda0>
    a08d:	83 c0 01             	add    $0x1,%eax
    a090:	88 07                	mov    %al,(%rdi)
    a092:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a097:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a09b:	b9 01 00 00 00       	mov    $0x1,%ecx
    a0a0:	4c 89 e6             	mov    %r12,%rsi
    a0a3:	48 8d 15 d6 4a 00 00 	lea    0x4ad6(%rip),%rdx        # eb80 <d0>
    a0aa:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    a0af:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    a0b6:	00 00 
    a0b8:	e8 a3 e5 ff ff       	call   8660 <fwp_write>
    a0bd:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    a0c2:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    a0c7:	48 8d 05 c3 0f 00 00 	lea    0xfc3(%rip),%rax        # b091 <_IO_stdin_used+0x91>
    a0ce:	48 85 c9             	test   %rcx,%rcx
    a0d1:	48 0f 44 c8          	cmove  %rax,%rcx
    a0d5:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    a0d9:	0f 87 c4 03 00 00    	ja     a4a3 <fwp_main_thread+0xe03>
    a0df:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    a0e3:	be 01 00 00 00       	mov    $0x1,%esi
    a0e8:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a0ed:	e8 9e bb ff ff       	call   5c90 <fwp_heap_alloc>
    a0f2:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a0f7:	4c 89 f2             	mov    %r14,%rdx
    a0fa:	4c 89 30             	mov    %r14,(%rax)
    a0fd:	48 89 c3             	mov    %rax,%rbx
    a100:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a104:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    a109:	e8 92 94 ff ff       	call   35a0 <memcpy@plt>
    a10e:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    a114:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a119:	e8 a2 92 ff ff       	call   33c0 <free@plt>
    a11e:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a125:	48 89 d8             	mov    %rbx,%rax
    a128:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a12f:	48 c1 e2 10          	shl    $0x10,%rdx
    a133:	48 39 d0             	cmp    %rdx,%rax
    a136:	73 55                	jae    a18d <fwp_main_thread+0xaed>
    a138:	48 89 c2             	mov    %rax,%rdx
    a13b:	48 c1 ea 10          	shr    $0x10,%rdx
    a13f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a143:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a14a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a14e:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    a152:	48 85 f6             	test   %rsi,%rsi
    a155:	74 36                	je     a18d <fwp_main_thread+0xaed>
    a157:	0f b6 0a             	movzbl (%rdx),%ecx
    a15a:	80 f9 02             	cmp    $0x2,%cl
    a15d:	0f 84 bd 01 00 00    	je     a320 <fwp_main_thread+0xc80>
    a163:	80 f9 01             	cmp    $0x1,%cl
    a166:	75 25                	jne    a18d <fwp_main_thread+0xaed>
    a168:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a16b:	0f b7 c0             	movzwl %ax,%eax
    a16e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a171:	48 0f af c1          	imul   %rcx,%rax
    a175:	48 c1 e8 20          	shr    $0x20,%rax
    a179:	48 39 d0             	cmp    %rdx,%rax
    a17c:	73 0f                	jae    a18d <fwp_main_thread+0xaed>
    a17e:	48 01 c6             	add    %rax,%rsi
    a181:	80 3e ff             	cmpb   $0xff,(%rsi)
    a184:	0f 84 b6 01 00 00    	je     a340 <fwp_main_thread+0xca0>
    a18a:	c6 06 01             	movb   $0x1,(%rsi)
    a18d:	4c 89 e7             	mov    %r12,%rdi
    a190:	e8 4b d9 ff ff       	call   7ae0 <fwp_drop0>
    a195:	48 8b 13             	mov    (%rbx),%rdx
    a198:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a19d:	be 01 00 00 00       	mov    $0x1,%esi
    a1a2:	48 8b 0d 77 72 01 00 	mov    0x17277(%rip),%rcx        # 21420 <fwp_prog_out>
    a1a9:	e8 d2 94 ff ff       	call   3680 <fwrite@plt>
    a1ae:	48 8b 35 6b 72 01 00 	mov    0x1726b(%rip),%rsi        # 21420 <fwp_prog_out>
    a1b5:	bf 0a 00 00 00       	mov    $0xa,%edi
    a1ba:	e8 21 93 ff ff       	call   34e0 <fputc@plt>
    a1bf:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a1c6:	48 89 d8             	mov    %rbx,%rax
    a1c9:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a1d0:	48 c1 e2 10          	shl    $0x10,%rdx
    a1d4:	48 39 d0             	cmp    %rdx,%rax
    a1d7:	73 67                	jae    a240 <fwp_main_thread+0xba0>
    a1d9:	48 89 c2             	mov    %rax,%rdx
    a1dc:	48 c1 ea 10          	shr    $0x10,%rdx
    a1e0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a1e4:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a1eb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1ef:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a1f3:	4d 85 f6             	test   %r14,%r14
    a1f6:	74 48                	je     a240 <fwp_main_thread+0xba0>
    a1f8:	0f b6 0a             	movzbl (%rdx),%ecx
    a1fb:	80 f9 02             	cmp    $0x2,%cl
    a1fe:	0f 84 d4 00 00 00    	je     a2d8 <fwp_main_thread+0xc38>
    a204:	80 f9 01             	cmp    $0x1,%cl
    a207:	75 37                	jne    a240 <fwp_main_thread+0xba0>
    a209:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a20c:	0f b7 c0             	movzwl %ax,%eax
    a20f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a212:	48 0f af c1          	imul   %rcx,%rax
    a216:	48 c1 e8 20          	shr    $0x20,%rax
    a21a:	48 39 d0             	cmp    %rdx,%rax
    a21d:	73 21                	jae    a240 <fwp_main_thread+0xba0>
    a21f:	49 01 c6             	add    %rax,%r14
    a222:	41 0f b6 06          	movzbl (%r14),%eax
    a226:	84 c0                	test   %al,%al
    a228:	74 16                	je     a240 <fwp_main_thread+0xba0>
    a22a:	3c 01                	cmp    $0x1,%al
    a22c:	0f 84 2e 01 00 00    	je     a360 <fwp_main_thread+0xcc0>
    a232:	3c ff                	cmp    $0xff,%al
    a234:	0f 84 86 01 00 00    	je     a3c0 <fwp_main_thread+0xd20>
    a23a:	83 e8 01             	sub    $0x1,%eax
    a23d:	41 88 06             	mov    %al,(%r14)
    a240:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a244:	4d 85 ed             	test   %r13,%r13
    a247:	0f 84 a3 00 00 00    	je     a2f0 <fwp_main_thread+0xc50>
    a24d:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    a254:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a25b:	4c 89 e0             	mov    %r12,%rax
    a25e:	48 c1 e2 10          	shl    $0x10,%rdx
    a262:	48 29 c8             	sub    %rcx,%rax
    a265:	48 39 d0             	cmp    %rdx,%rax
    a268:	0f 83 24 fe ff ff    	jae    a092 <fwp_main_thread+0x9f2>
    a26e:	48 89 c2             	mov    %rax,%rdx
    a271:	48 c1 ea 10          	shr    $0x10,%rdx
    a275:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a279:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a280:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a284:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a288:	48 85 ff             	test   %rdi,%rdi
    a28b:	0f 84 01 fe ff ff    	je     a092 <fwp_main_thread+0x9f2>
    a291:	0f b6 0a             	movzbl (%rdx),%ecx
    a294:	80 f9 02             	cmp    $0x2,%cl
    a297:	0f 85 c3 fd ff ff    	jne    a060 <fwp_main_thread+0x9c0>
    a29d:	66 85 c0             	test   %ax,%ax
    a2a0:	0f 85 ec fd ff ff    	jne    a092 <fwp_main_thread+0x9f2>
    a2a6:	e9 d3 fd ff ff       	jmp    a07e <fwp_main_thread+0x9de>
    a2ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a2b0:	48 8d 3d a9 a9 ff ff 	lea    -0x5657(%rip),%rdi        # 4c60 <fwp_heap_report>
    a2b7:	e8 24 04 00 00       	call   a6e0 <atexit>
    a2bc:	e9 23 f4 ff ff       	jmp    96e4 <fwp_main_thread+0x44>
    a2c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a2c8:	e8 a3 aa ff ff       	call   4d70 <fwp_heap_init>
    a2cd:	e9 04 f4 ff ff       	jmp    96d6 <fwp_main_thread+0x36>
    a2d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2d8:	66 85 c0             	test   %ax,%ax
    a2db:	0f 84 41 ff ff ff    	je     a222 <fwp_main_thread+0xb82>
    a2e1:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a2e5:	4d 85 ed             	test   %r13,%r13
    a2e8:	0f 85 5f ff ff ff    	jne    a24d <fwp_main_thread+0xbad>
    a2ee:	66 90                	xchg   %ax,%ax
    a2f0:	4c 89 e7             	mov    %r12,%rdi
    a2f3:	e8 e8 d7 ff ff       	call   7ae0 <fwp_drop0>
    a2f8:	48 89 ef             	mov    %rbp,%rdi
    a2fb:	e8 e0 d7 ff ff       	call   7ae0 <fwp_drop0>
    a300:	48 c7 05 55 4d 00 00 	movq   $0x0,0x4d55(%rip)        # f060 <v.2>
    a307:	00 00 00 00 
    a30b:	c7 05 53 4d 00 00 01 	movl   $0x1,0x4d53(%rip)        # f068 <st.3>
    a312:	00 00 00 
    a315:	e9 ad f4 ff ff       	jmp    97c7 <fwp_main_thread+0x127>
    a31a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a320:	66 85 c0             	test   %ax,%ax
    a323:	0f 85 64 fe ff ff    	jne    a18d <fwp_main_thread+0xaed>
    a329:	80 3e ff             	cmpb   $0xff,(%rsi)
    a32c:	0f 85 58 fe ff ff    	jne    a18a <fwp_main_thread+0xaea>
    a332:	0f 1f 00             	nopl   (%rax)
    a335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a33c:	00 00 00 00 
    a340:	48 89 f7             	mov    %rsi,%rdi
    a343:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    a348:	e8 03 b2 ff ff       	call   5550 <fwp_rc_forget_slot>
    a34d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a352:	e9 33 fe ff ff       	jmp    a18a <fwp_main_thread+0xaea>
    a357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a35e:	00 00 
    a360:	48 89 df             	mov    %rbx,%rdi
    a363:	e8 28 b4 ff ff       	call   5790 <fwp_mem_free>
    a368:	e9 d3 fe ff ff       	jmp    a240 <fwp_main_thread+0xba0>
    a36d:	0f 1f 00             	nopl   (%rax)
    a370:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a374:	e9 02 f5 ff ff       	jmp    987b <fwp_main_thread+0x1db>
    a379:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a380:	66 85 c0             	test   %ax,%ax
    a383:	0f 85 c9 fc ff ff    	jne    a052 <fwp_main_thread+0x9b2>
    a389:	e9 aa fc ff ff       	jmp    a038 <fwp_main_thread+0x998>
    a38e:	66 90                	xchg   %ax,%ax
    a390:	66 85 c0             	test   %ax,%ax
    a393:	0f 85 11 fc ff ff    	jne    9faa <fwp_main_thread+0x90a>
    a399:	e9 00 fc ff ff       	jmp    9f9e <fwp_main_thread+0x8fe>
    a39e:	66 90                	xchg   %ax,%ax
    a3a0:	66 85 c0             	test   %ax,%ax
    a3a3:	0f 85 6f fb ff ff    	jne    9f18 <fwp_main_thread+0x878>
    a3a9:	e9 5e fb ff ff       	jmp    9f0c <fwp_main_thread+0x86c>
    a3ae:	66 90                	xchg   %ax,%ax
    a3b0:	4c 89 ef             	mov    %r13,%rdi
    a3b3:	e8 98 b1 ff ff       	call   5550 <fwp_rc_forget_slot>
    a3b8:	e9 2c fa ff ff       	jmp    9de9 <fwp_main_thread+0x749>
    a3bd:	0f 1f 00             	nopl   (%rax)
    a3c0:	4c 89 f0             	mov    %r14,%rax
    a3c3:	48 c1 e8 11          	shr    $0x11,%rax
    a3c7:	4c 31 f0             	xor    %r14,%rax
    a3ca:	48 89 c2             	mov    %rax,%rdx
    a3cd:	48 c1 ea 09          	shr    $0x9,%rdx
    a3d1:	48 31 d0             	xor    %rdx,%rax
    a3d4:	0f b6 d0             	movzbl %al,%edx
    a3d7:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    a3de:	00 
    a3df:	48 85 c0             	test   %rax,%rax
    a3e2:	75 29                	jne    a40d <fwp_main_thread+0xd6d>
    a3e4:	e9 d0 00 00 00       	jmp    a4b9 <fwp_main_thread+0xe19>
    a3e9:	90                   	nop
    a3ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3f1:	00 00 00 00 
    a3f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3fc:	00 00 00 00 
    a400:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a404:	48 85 c0             	test   %rax,%rax
    a407:	0f 84 ac 00 00 00    	je     a4b9 <fwp_main_thread+0xe19>
    a40d:	48 89 c2             	mov    %rax,%rdx
    a410:	4c 3b 30             	cmp    (%rax),%r14
    a413:	75 eb                	jne    a400 <fwp_main_thread+0xd60>
    a415:	48 8b 70 08          	mov    0x8(%rax),%rsi
    a419:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    a41d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a421:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a428:	0f 85 12 fe ff ff    	jne    a240 <fwp_main_thread+0xba0>
    a42e:	4c 89 f7             	mov    %r14,%rdi
    a431:	e8 1a b1 ff ff       	call   5550 <fwp_rc_forget_slot>
    a436:	41 c6 06 fe          	movb   $0xfe,(%r14)
    a43a:	e9 01 fe ff ff       	jmp    a240 <fwp_main_thread+0xba0>
    a43f:	90                   	nop
    a440:	e8 eb af ff ff       	call   5430 <fwp_rc_wide_dup>
    a445:	e9 48 fc ff ff       	jmp    a092 <fwp_main_thread+0x9f2>
    a44a:	48 83 3d 46 53 01 00 	cmpq   $0x0,0x15346(%rip)        # 1f798 <fwp_root>
    a451:	00 
    a452:	c7 05 24 4c 01 00 00 	movl   $0x0,0x14c24(%rip)        # 1f080 <fwp_exit_code>
    a459:	00 00 00 
    a45c:	0f 84 a4 f6 ff ff    	je     9b06 <fwp_main_thread+0x466>
    a462:	e9 e4 92 ff ff       	jmp    374b <fwp_main_thread.cold>
    a467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a46e:	00 00 
    a470:	48 89 df             	mov    %rbx,%rdi
    a473:	e8 d8 b0 ff ff       	call   5550 <fwp_rc_forget_slot>
    a478:	e9 98 fa ff ff       	jmp    9f15 <fwp_main_thread+0x875>
    a47d:	48 89 df             	mov    %rbx,%rdi
    a480:	e8 cb b0 ff ff       	call   5550 <fwp_rc_forget_slot>
    a485:	e9 1d fb ff ff       	jmp    9fa7 <fwp_main_thread+0x907>
    a48a:	48 89 df             	mov    %rbx,%rdi
    a48d:	e8 be b0 ff ff       	call   5550 <fwp_rc_forget_slot>
    a492:	e9 aa fb ff ff       	jmp    a041 <fwp_main_thread+0x9a1>
    a497:	48 8d 3d 9a 14 00 00 	lea    0x149a(%rip),%rdi        # b938 <_IO_stdin_used+0x938>
    a49e:	e8 4d 9f ff ff       	call   43f0 <fwp_trap>
    a4a3:	48 8d 3d 72 0d 00 00 	lea    0xd72(%rip),%rdi        # b21c <_IO_stdin_used+0x21c>
    a4aa:	e8 41 9f ff ff       	call   43f0 <fwp_trap>
    a4af:	e8 2c 99 ff ff       	call   3de0 <descent_phase_fail>
    a4b4:	e8 a7 8f ff ff       	call   3460 <__stack_chk_fail@plt>
    a4b9:	48 8d 3d a8 13 00 00 	lea    0x13a8(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    a4c0:	e8 2b 9f ff ff       	call   43f0 <fwp_trap>
    a4c5:	e9 81 92 ff ff       	jmp    374b <fwp_main_thread.cold>
    a4ca:	e9 7c 92 ff ff       	jmp    374b <fwp_main_thread.cold>
    a4cf:	90                   	nop

000000000000a4d0 <__divmodti4>:
    a4d0:	f3 0f 1e fa          	endbr64
    a4d4:	55                   	push   %rbp
    a4d5:	49 89 f1             	mov    %rsi,%r9
    a4d8:	49 89 d2             	mov    %rdx,%r10
    a4db:	48 89 fe             	mov    %rdi,%rsi
    a4de:	49 89 cb             	mov    %rcx,%r11
    a4e1:	48 89 e5             	mov    %rsp,%rbp
    a4e4:	41 57                	push   %r15
    a4e6:	41 56                	push   %r14
    a4e8:	41 55                	push   %r13
    a4ea:	41 54                	push   %r12
    a4ec:	53                   	push   %rbx
    a4ed:	4c 89 c3             	mov    %r8,%rbx
    a4f0:	45 31 c0             	xor    %r8d,%r8d
    a4f3:	4d 85 c9             	test   %r9,%r9
    a4f6:	79 12                	jns    a50a <__divmodti4+0x3a>
    a4f8:	31 ff                	xor    %edi,%edi
    a4fa:	48 f7 de             	neg    %rsi
    a4fd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a504:	4c 19 cf             	sbb    %r9,%rdi
    a507:	49 89 f9             	mov    %rdi,%r9
    a50a:	4c 89 d8             	mov    %r11,%rax
    a50d:	4d 85 db             	test   %r11,%r11
    a510:	0f 88 1a 01 00 00    	js     a630 <__divmodti4+0x160>
    a516:	4c 89 d9             	mov    %r11,%rcx
    a519:	49 89 f3             	mov    %rsi,%r11
    a51c:	75 62                	jne    a580 <__divmodti4+0xb0>
    a51e:	4d 89 c4             	mov    %r8,%r12
    a521:	4d 39 d1             	cmp    %r10,%r9
    a524:	0f 83 46 01 00 00    	jae    a670 <__divmodti4+0x1a0>
    a52a:	4c 89 d8             	mov    %r11,%rax
    a52d:	4c 89 ca             	mov    %r9,%rdx
    a530:	49 f7 f2             	div    %r10
    a533:	49 89 c3             	mov    %rax,%r11
    a536:	31 c0                	xor    %eax,%eax
    a538:	48 89 d6             	mov    %rdx,%rsi
    a53b:	31 ff                	xor    %edi,%edi
    a53d:	4c 89 d9             	mov    %r11,%rcx
    a540:	48 89 c2             	mov    %rax,%rdx
    a543:	48 89 c8             	mov    %rcx,%rax
    a546:	4d 85 e4             	test   %r12,%r12
    a549:	74 0a                	je     a555 <__divmodti4+0x85>
    a54b:	48 f7 d8             	neg    %rax
    a54e:	48 83 d2 00          	adc    $0x0,%rdx
    a552:	48 f7 da             	neg    %rdx
    a555:	4d 85 c0             	test   %r8,%r8
    a558:	74 0a                	je     a564 <__divmodti4+0x94>
    a55a:	48 f7 de             	neg    %rsi
    a55d:	48 83 d7 00          	adc    $0x0,%rdi
    a561:	48 f7 df             	neg    %rdi
    a564:	48 89 33             	mov    %rsi,(%rbx)
    a567:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a56b:	5b                   	pop    %rbx
    a56c:	41 5c                	pop    %r12
    a56e:	41 5d                	pop    %r13
    a570:	41 5e                	pop    %r14
    a572:	41 5f                	pop    %r15
    a574:	5d                   	pop    %rbp
    a575:	c3                   	ret
    a576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a57d:	00 00 00 
    a580:	4d 89 c4             	mov    %r8,%r12
    a583:	49 39 c1             	cmp    %rax,%r9
    a586:	0f 82 ce 00 00 00    	jb     a65a <__divmodti4+0x18a>
    a58c:	31 ff                	xor    %edi,%edi
    a58e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a593:	48 63 c7             	movslq %edi,%rax
    a596:	be 40 00 00 00       	mov    $0x40,%esi
    a59b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a5a0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a5a5:	48 29 c6             	sub    %rax,%rsi
    a5a8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a5ad:	48 09 c8             	or     %rcx,%rax
    a5b0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a5b5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a5ba:	49 89 c6             	mov    %rax,%r14
    a5bd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a5c1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a5c6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a5cb:	49 09 c1             	or     %rax,%r9
    a5ce:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a5d2:	4c 89 c8             	mov    %r9,%rax
    a5d5:	49 f7 f6             	div    %r14
    a5d8:	48 89 d1             	mov    %rdx,%rcx
    a5db:	49 89 c3             	mov    %rax,%r11
    a5de:	49 89 c1             	mov    %rax,%r9
    a5e1:	49 f7 e2             	mul    %r10
    a5e4:	49 89 c6             	mov    %rax,%r14
    a5e7:	49 89 d2             	mov    %rdx,%r10
    a5ea:	48 39 d1             	cmp    %rdx,%rcx
    a5ed:	72 07                	jb     a5f6 <__divmodti4+0x126>
    a5ef:	75 17                	jne    a608 <__divmodti4+0x138>
    a5f1:	49 39 c7             	cmp    %rax,%r15
    a5f4:	73 12                	jae    a608 <__divmodti4+0x138>
    a5f6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a5fa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a5fe:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a602:	49 89 d2             	mov    %rdx,%r10
    a605:	49 89 c6             	mov    %rax,%r14
    a608:	4c 89 f8             	mov    %r15,%rax
    a60b:	4c 29 f0             	sub    %r14,%rax
    a60e:	4c 19 d1             	sbb    %r10,%rcx
    a611:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a616:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a61b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a620:	48 09 c6             	or     %rax,%rsi
    a623:	48 89 cf             	mov    %rcx,%rdi
    a626:	31 c0                	xor    %eax,%eax
    a628:	4c 89 c9             	mov    %r9,%rcx
    a62b:	e9 10 ff ff ff       	jmp    a540 <__divmodti4+0x70>
    a630:	4c 89 d0             	mov    %r10,%rax
    a633:	4c 89 da             	mov    %r11,%rdx
    a636:	4d 89 c4             	mov    %r8,%r12
    a639:	49 89 f3             	mov    %rsi,%r11
    a63c:	48 f7 d8             	neg    %rax
    a63f:	49 f7 d4             	not    %r12
    a642:	48 83 d2 00          	adc    $0x0,%rdx
    a646:	49 89 c2             	mov    %rax,%r10
    a649:	48 f7 da             	neg    %rdx
    a64c:	48 89 d1             	mov    %rdx,%rcx
    a64f:	0f 84 cc fe ff ff    	je     a521 <__divmodti4+0x51>
    a655:	49 39 d1             	cmp    %rdx,%r9
    a658:	73 46                	jae    a6a0 <__divmodti4+0x1d0>
    a65a:	4c 89 cf             	mov    %r9,%rdi
    a65d:	31 c0                	xor    %eax,%eax
    a65f:	31 c9                	xor    %ecx,%ecx
    a661:	e9 da fe ff ff       	jmp    a540 <__divmodti4+0x70>
    a666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a66d:	00 00 00 
    a670:	4d 85 d2             	test   %r10,%r10
    a673:	75 0d                	jne    a682 <__divmodti4+0x1b2>
    a675:	b8 01 00 00 00       	mov    $0x1,%eax
    a67a:	31 d2                	xor    %edx,%edx
    a67c:	49 f7 f2             	div    %r10
    a67f:	49 89 c2             	mov    %rax,%r10
    a682:	4c 89 c8             	mov    %r9,%rax
    a685:	31 d2                	xor    %edx,%edx
    a687:	49 f7 f2             	div    %r10
    a68a:	49 89 c1             	mov    %rax,%r9
    a68d:	4c 89 d8             	mov    %r11,%rax
    a690:	49 f7 f2             	div    %r10
    a693:	49 89 c3             	mov    %rax,%r11
    a696:	4c 89 c8             	mov    %r9,%rax
    a699:	e9 9a fe ff ff       	jmp    a538 <__divmodti4+0x68>
    a69e:	66 90                	xchg   %ax,%ax
    a6a0:	45 31 f6             	xor    %r14d,%r14d
    a6a3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a6a8:	44 89 f7             	mov    %r14d,%edi
    a6ab:	45 85 f6             	test   %r14d,%r14d
    a6ae:	0f 85 df fe ff ff    	jne    a593 <__divmodti4+0xc3>
    a6b4:	4c 39 ca             	cmp    %r9,%rdx
    a6b7:	72 17                	jb     a6d0 <__divmodti4+0x200>
    a6b9:	31 c9                	xor    %ecx,%ecx
    a6bb:	48 39 c6             	cmp    %rax,%rsi
    a6be:	73 10                	jae    a6d0 <__divmodti4+0x200>
    a6c0:	4c 89 cf             	mov    %r9,%rdi
    a6c3:	31 c0                	xor    %eax,%eax
    a6c5:	e9 76 fe ff ff       	jmp    a540 <__divmodti4+0x70>
    a6ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6d0:	4c 89 de             	mov    %r11,%rsi
    a6d3:	b9 01 00 00 00       	mov    $0x1,%ecx
    a6d8:	48 29 c6             	sub    %rax,%rsi
    a6db:	49 19 d1             	sbb    %rdx,%r9
    a6de:	eb e0                	jmp    a6c0 <__divmodti4+0x1f0>

000000000000a6e0 <atexit>:
    a6e0:	f3 0f 1e fa          	endbr64
    a6e4:	48 8b 15 1d 49 00 00 	mov    0x491d(%rip),%rdx        # f008 <__dso_handle>
    a6eb:	31 f6                	xor    %esi,%esi
    a6ed:	e9 6e 8f ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a6f4 <_fini>:
    a6f4:	f3 0f 1e fa          	endbr64
    a6f8:	48 83 ec 08          	sub    $0x8,%rsp
    a6fc:	48 83 c4 08          	add    $0x8,%rsp
    a700:	c3                   	ret
