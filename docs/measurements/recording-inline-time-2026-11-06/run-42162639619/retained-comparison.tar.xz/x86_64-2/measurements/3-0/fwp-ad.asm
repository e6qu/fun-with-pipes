
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 bf 00 00 	mov    0xbfc9(%rip),%rax        # efd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 bd 00 00    	push   0xbde2(%rip)        # ee08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 bd 00 00    	jmp    *0xbde4(%rip)        # ee10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e bc 00 00    	jmp    *0xbc4e(%rip)        # efe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # ee18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # ee70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # ee78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # ee80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # ee88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # ee90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # ee98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # eea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # eea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eeb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eeb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # eed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # eed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # eee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # eee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # eef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # eef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # ef00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # ef08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # ef70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # ef78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # ef80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # ef88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # ef90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # ef98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 b8 00 00    	jmp    *0xb8e6(%rip)        # efa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de b8 00 00    	jmp    *0xb8de(%rip)        # efa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 b8 00 00    	jmp    *0xb8d6(%rip)        # efb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce b8 00 00    	jmp    *0xb8ce(%rip)        # efb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 b8 00 00    	jmp    *0xb8c6(%rip)        # efc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 79 00 00 	lea    0x797a(%rip),%r9        # b091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 79 00 00 	lea    0x7977(%rip),%r8        # b095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 9b 00 00 	lea    0x9ba1(%rip),%rax        # d320 <fwp_fn_table>
    377f:	48 89 05 32 dc 01 00 	mov    %rax,0x1dc32(%rip)        # 213b8 <fwp_fns>
    3786:	48 8b 05 93 b8 00 00 	mov    0xb893(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c dc 01 00 	mov    %rax,0x1dc2c(%rip)        # 213c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 2f 7a 00 00 	lea    0x7a2f(%rip),%rdi        # b1cf <_IO_stdin_used+0x1cf>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 b8 00 00 	mov    0xb818(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ff 5b 00 00 	lea    0x5bff(%rip),%rdx        # 9460 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 b7 00 00 	mov    0xb783(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 b7 01 00    	mov    0x1b7d8(%rip),%eax        # 1f080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d df 78 00 00 	lea    0x78df(%rip),%rdi        # b1d8 <_IO_stdin_used+0x1d8>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d e6 7f 00 00 	lea    0x7fe6(%rip),%rdi        # b8f0 <_IO_stdin_used+0x8f0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d a0 7f 00 00 	lea    0x7fa0(%rip),%rdi        # b8c8 <_IO_stdin_used+0x8c8>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 64 7f 00 00 	lea    0x7f64(%rip),%rdi        # b898 <_IO_stdin_used+0x898>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d 30 7f 00 00 	lea    0x7f30(%rip),%rdi        # b870 <_IO_stdin_used+0x870>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 b6 00 00    	call   *0xb653(%rip)        # efc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 91 b6 00 00 	lea    0xb691(%rip),%rdi        # f018 <__TMC_END__>
    3987:	48 8d 05 8a b6 00 00 	lea    0xb68a(%rip),%rax        # f018 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 b6 00 00 	mov    0xb636(%rip),%rax        # efd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 61 b6 00 00 	lea    0xb661(%rip),%rdi        # f018 <__TMC_END__>
    39b7:	48 8d 35 5a b6 00 00 	lea    0xb65a(%rip),%rsi        # f018 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 b6 00 00 	mov    0xb605(%rip),%rax        # efe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d b6 00 00 00 	cmpb   $0x0,0xb64d(%rip)        # f048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 b5 00 00 	cmpq   $0x0,0xb5e2(%rip)        # efe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 b5 00 00 	mov    0xb5f6(%rip),%rdi        # f008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 b6 00 00 01 	movb   $0x1,0xb625(%rip)        # f048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce b4 01 00 	add    0x1b4ce(%rip),%rdx        # 1f0f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc b4 01 00 	add    0x1b4bc(%rip),%rax        # 1f0f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 d7 01 00 	mov    0x1d749(%rip),%rdi        # 213c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 b3 00 00 	mov    0xb394(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 b3 00 00 	mov    0xb381(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 73 00 00 	lea    0x7345(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 b3 00 00 	mov    0xb372(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 ba 01 00 	mov    0x1ba41(%rip),%rax        # 1f740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 b3 01 00 	mov    0x1b381(%rip),%rax        # 1f100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d b3 01 00 	sub    0x1b36d(%rip),%rax        # 1f0f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 0d 7c 00 00 	lea    0x7c0d(%rip),%rsi        # b9d0 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b cd 01 00 	mov    0x1cd5b(%rip),%rax        # 20b50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 cd 01 00 	lea    0x1cd54(%rip),%r8        # 20b50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 cd 01 00 	mov    0x1cd35(%rip),%rbx        # 20b38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 cd 01 00 	mov    0x1cd45(%rip),%rcx        # 20b58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 cc 01 00 	mov    0x1cce1(%rip),%rdi        # 20b40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a cd 01 00 	sub    %rsi,0x1cd2a(%rip)        # 20b90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba cc 01 00 	mov    0x1ccba(%rip),%rax        # 20b30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 cc 01 00 	add    0x1cc70(%rip),%rdi        # 20b10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e cc 01 00 	mov    0x1cc7e(%rip),%rsi        # 20b40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c cc 01 00 	mov    0x1cc8c(%rip),%rax        # 20b58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b cc 01 00 	mov    %r12,0x1cc3b(%rip)        # 20b40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 cc 01 00 	mov    %rbp,0x1cc29(%rip)        # 20b38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e cc 01 00 	cmp    %rdi,0x1cc0e(%rip)        # 20b28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 cc 01 00 	mov    %rdi,0x1cc05(%rip)        # 20b28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 cc 01 00 	sub    %rdi,0x1cc49(%rip)        # 20b90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 cb 01 00 	mov    0x1cbf1(%rip),%rax        # 20b48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea cb 01 00 	lea    0x1cbea(%rip),%r8        # 20b48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd af 00 00 	mov    0xaffd(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 6f 00 00 	lea    0x6fb4(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 b6 01 00 	cmp    0x1b689(%rip),%rdi        # 1f740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f b6 01 00 	mov    0x1b64f(%rip),%rax        # 1f720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d b6 01 00 	mov    %rdi,0x1b62d(%rip)        # 1f720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 b6 01 00 	mov    %rdi,0x1b609(%rip)        # 1f728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db 6f 00 00 	lea    0x6fdb(%rip),%rsi        # b13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 6e 00 00 	lea    0x6ea7(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 ae 00 00 	mov    0xae78(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 6e 00 00 	lea    0x6e51(%rip),%rdx        # b020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 ae 00 00 	mov    0xae60(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 ad 00 00 	mov    0xad71(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 6d 00 00 	lea    0x6d28(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 6d 00 00 	lea    0x6d32(%rip),%rdi        # b02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 6c 00 00 	lea    0x6cba(%rip),%rdi        # b049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 48 72 00 00 	lea    0x7248(%rip),%rdi        # b5e8 <_IO_stdin_used+0x5e8>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 30 76 00 	movdqa 0x7630(%rip),%xmm0        # b9f0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a cf 01 00 	add    0x1cf9a(%rip),%rax        # 213b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d a4 71 00 00 	lea    0x71a4(%rip),%rdi        # b618 <_IO_stdin_used+0x618>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 ac 01 00 	cmp    %rax,0x1ac55(%rip)        # 1f0e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 ac 01 00 	add    0x1ac50(%rip),%rax        # 1f0f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d 8d 71 00 00 	lea    0x718d(%rip),%rdi        # b648 <_IO_stdin_used+0x648>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 6b 00 00 	lea    0x6b92(%rip),%r8        # b065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 69 00 00 	lea    0x69e7(%rip),%r8        # b074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 68 00 00 	lea    0x6874(%rip),%r8        # b06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 66 00 00 	lea    0x664c(%rip),%rdi        # b079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 67 00 00 	lea    0x6736(%rip),%rsi        # b184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 c0 01 00 	mov    0x1c065(%rip),%r9        # 20b28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be c0 01 00 	mov    0x1c0be(%rip),%r8        # 20b88 <fwp_heap+0x1428>
    4aca:	48 8d 15 c7 6b 00 00 	lea    0x6bc7(%rip),%rdx        # b698 <_IO_stdin_used+0x698>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 c0 01 00 	mov    0x1c0a6(%rip),%rcx        # 20b80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 c0 01 	movsd  0x1c0b4(%rip),%xmm1        # 20ba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 c0 01 	movsd  0x1c0a4(%rip),%xmm0        # 20b98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 a5 00 00 	mov    0xa545(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 c8 6e 00 	movdqa 0x6ec8(%rip),%xmm0        # ba00 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f bb 01 00 	lea    0x1bb5f(%rip),%rax        # 206a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 f1 6e 00 	movdqa 0x6ef1(%rip),%xmm2        # ba40 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 bb 01 00 	movaps %xmm0,0x1bb05(%rip)        # 20660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 ad 6e 00 	movdqa 0x6ead(%rip),%xmm0        # ba10 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 bf 01 00 01 	movl   $0x1,0x1bf93(%rip)        # 20b04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 ba 01 00 	movaps %xmm0,0x1baf3(%rip)        # 20670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 9b 6e 00 	movdqa 0x6e9b(%rip),%xmm0        # ba20 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 f4 ba 01 00 	movaps %xmm0,0x1baf4(%rip)        # 20680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 9c 6e 00 	movdqa 0x6e9c(%rip),%xmm0        # ba30 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 f5 ba 01 00 	movaps %xmm0,0x1baf5(%rip)        # 20690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 ab 01 00 	lea    0x1ab75(%rip),%r8        # 1f760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 be 01 00 	mov    %rax,0x1be90(%rip)        # 20b18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e be 01 00 	mov    %r12,0x1be6e(%rip)        # 20b20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 be 01 00 	mov    %rax,0x1be57(%rip)        # 20b10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 be 01 00 	mov    %rbx,0x1be70(%rip)        # 20b30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 be 01 00 	mov    %rsi,0x1be99(%rip)        # 20b60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 63 00 00 	lea    0x63d6(%rip),%rdi        # b0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 be 01 00 	mov    %rax,0x1be78(%rip)        # 20b58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc bd 01 00    	mov    %eax,0x1bdfc(%rip)        # 20b08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec a9 01 00 	mov    0x1a9ec(%rip),%r8        # 1f720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c a9 01 00 	mov    %rbx,0x1a91c(%rip)        # 1f728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 a9 01 00 	mov    %r8,0x1a908(%rip)        # 1f720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 62 00 00 	lea    0x6239(%rip),%rdi        # b0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd a1 01 00 	lea    0x1a1dd(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 a1 01 00 	movaps %xmm0,0x1a1c5(%rip)        # 1f0a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 a1 01 00 	mov    %rax,0x1a1a1(%rip)        # 1f088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 a1 01 00 	movaps %xmm0,0x1a1c2(%rip)        # 1f0b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 a1 01 00 	movaps %xmm0,0x1a1c6(%rip)        # 1f0c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 a1 01 00 	mov    %rdx,0x1a1c7(%rip)        # 1f0d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 61 00 00 	lea    0x6190(%rip),%rdi        # b0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 a7 01 00 	mov    0x1a797(%rip),%rbx        # 1f718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca 9f 00 00 	mov    0x9fca(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d a3 66 00 00 	lea    0x66a3(%rip),%rdi        # b720 <_IO_stdin_used+0x720>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d a6 01 00 	mov    0x1a66d(%rip),%rax        # 1f720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 a6 01 00 	mov    %rdx,0x1a647(%rip)        # 1f720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 a5 01 00 	mov    0x1a594(%rip),%rbx        # 1f718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 a5 01 00 	mov    %rbx,0x1a551(%rip)        # 1f718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 a5 01 00 	mov    %rdx,0x1a551(%rip)        # 1f728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 a5 01 00 	lea    0x1a566(%rip),%rsi        # 1f760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 c0 01 00 	addq   $0x1,0x1c0e5(%rip)        # 213a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 77 64 00 00 	lea    0x6477(%rip),%rdi        # b750 <_IO_stdin_used+0x750>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d 88 64 00 00 	lea    0x6488(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 5d 00 00 	lea    0x5dd4(%rip),%rdi        # b0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e a4 01 00 	lea    0x1a41e(%rip),%rcx        # 1f760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f c0 01 00 	subq   $0x1,0x1c01f(%rip)        # 213a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d e3 63 00 00 	lea    0x63e3(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 c0 01 00 	cmpq   $0x0,0x1c000(%rip)        # 213a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 bf 01 00 	sub    %rax,0x1bf55(%rip)        # 213b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 bf 01 00 	add    %r12,0x1bf33(%rip)        # 213b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f b6 01 00 	mov    0x1b68f(%rip),%rax        # 20b58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c a2 01 00 	lea    0x1a28c(%rip),%rax        # 1f760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 b5 01 00 	add    0x1b5e3(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 b5 01 00 	mov    0x1b5b0(%rip),%rsi        # 20b10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 b5 01 00 	mov    0x1b5d1(%rip),%rax        # 20b38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 b5 01 00 	add    0x1b5c5(%rip),%r8        # 20b58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d b5 01 	addsd  0x1b58d(%rip),%xmm0        # 20ba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 a1 01 00 	lea    0x1a142(%rip),%rax        # 1f760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c b5 01 00 	sub    %rdi,0x1b54c(%rip)        # 20b80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 b5 01 	movsd  %xmm0,0x1b564(%rip)        # 20ba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e b5 01 00 	sub    %rdx,0x1b51e(%rip)        # 20b80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 b5 01 	addsd  0x1b524(%rip),%xmm0        # 20ba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 b5 01 	movsd  %xmm0,0x1b518(%rip)        # 20ba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af b4 01 00 	mov    0x1b4af(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 b4 01 00 	add    %rcx,0x1b4a9(%rip)        # 20b90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 b4 01 00 	cmp    0x1b462(%rip),%r9        # 20b50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 b4 01 00 	mov    %r9,0x1b459(%rip)        # 20b50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a b4 01 00 	cmp    0x1b44a(%rip),%r9        # 20b48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d b4 01 00 	mov    %r9,0x1b43d(%rip)        # 20b48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 b3 01 00 	add    0x1b353(%rip),%rdi        # 20b58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 9f 01 00 	lea    0x19f30(%rip),%r15        # 1f760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 b2 01 00 	add    0x1b2a0(%rip),%r12        # 20b10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 b2 01 00 	add    0x1b2f9(%rip),%rax        # 20b80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 b2 01 00 	cmp    %rax,0x1b2f8(%rip)        # 20b88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 b2 01 00 	mov    %rax,0x1b2e9(%rip)        # 20b80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 b2 01 00 	mov    %rax,0x1b2e8(%rip)        # 20b88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 b2 01 	addsd  0x1b2e4(%rip),%xmm0        # 20b98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc b2 01 	movsd  %xmm0,0x1b2dc(%rip)        # 20b98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 b2 01 00    	mov    0x1b223(%rip),%eax        # 20b04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f 9e 01 00 	lea    0x19e5f(%rip),%rdi        # 1f760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 b2 01 00 	add    0x1b218(%rip),%rax        # 20b80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 b2 01 00 	cmp    %rax,0x1b213(%rip)        # 20b88 <fwp_heap+0x1428>
    5975:	48 89 05 04 b2 01 00 	mov    %rax,0x1b204(%rip)        # 20b80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 b2 01 00 	mov    %rax,0x1b203(%rip)        # 20b88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff b1 01 	addsd  0x1b1ff(%rip),%xmm0        # 20b98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 b1 01 	movsd  %xmm0,0x1b1f7(%rip)        # 20b98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae b0 01 00    	mov    0x1b0ae(%rip),%eax        # 20b04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 9c 01 00 	lea    0x19ce5(%rip),%rax        # 1f760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b b0 01 00 	add    0x1b09b(%rip),%rax        # 20b80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a b0 01 00 	cmp    %rax,0x1b09a(%rip)        # 20b88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b b0 01 00 	mov    %rax,0x1b08b(%rip)        # 20b80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a b0 01 00 	mov    %rax,0x1b08a(%rip)        # 20b88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 b0 01 	addsd  0x1b086(%rip),%xmm0        # 20b98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e b0 01 	movsd  %xmm0,0x1b07e(%rip)        # 20b98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_data.part.0.constprop.0>:
    5b70:	41 56                	push   %r14
    5b72:	41 89 fe             	mov    %edi,%r14d
    5b75:	41 54                	push   %r12
    5b77:	49 89 f4             	mov    %rsi,%r12
    5b7a:	55                   	push   %rbp
    5b7b:	53                   	push   %rbx
    5b7c:	48 83 ec 08          	sub    $0x8,%rsp
    5b80:	8b 05 7e af 01 00    	mov    0x1af7e(%rip),%eax        # 20b04 <fwp_heap+0x13a4>
    5b86:	85 c0                	test   %eax,%eax
    5b88:	0f 84 fa 00 00 00    	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5b8e:	0f b6 05 6d ab 01 00 	movzbl 0x1ab6d(%rip),%eax        # 20702 <fwp_heap+0xfa2>
    5b95:	48 8d 15 c4 9b 01 00 	lea    0x19bc4(%rip),%rdx        # 1f760 <fwp_heap>
    5b9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5ba3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ba7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5bab:	48 8b 18             	mov    (%rax),%rbx
    5bae:	48 85 db             	test   %rbx,%rbx
    5bb1:	0f 84 a9 00 00 00    	je     5c60 <fwp_data.part.0.constprop.0+0xf0>
    5bb7:	48 8b 13             	mov    (%rbx),%rdx
    5bba:	48 f7 d2             	not    %rdx
    5bbd:	48 89 10             	mov    %rdx,(%rax)
    5bc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5bc4:	76 1b                	jbe    5be1 <fwp_data.part.0.constprop.0+0x71>
    5bc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5bca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5bce:	31 f6                	xor    %esi,%esi
    5bd0:	48 c1 e8 03          	shr    $0x3,%rax
    5bd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5bdb:	00 
    5bdc:	e8 df d8 ff ff       	call   34c0 <memset@plt>
    5be1:	48 89 e8             	mov    %rbp,%rax
    5be4:	48 03 05 95 af 01 00 	add    0x1af95(%rip),%rax        # 20b80 <fwp_heap+0x1420>
    5beb:	0f 82 a8 00 00 00    	jb     5c99 <fwp_data.part.0.constprop.0+0x129>
    5bf1:	48 39 05 90 af 01 00 	cmp    %rax,0x1af90(%rip)        # 20b88 <fwp_heap+0x1428>
    5bf8:	48 89 05 81 af 01 00 	mov    %rax,0x1af81(%rip)        # 20b80 <fwp_heap+0x1420>
    5bff:	73 07                	jae    5c08 <fwp_data.part.0.constprop.0+0x98>
    5c01:	48 89 05 80 af 01 00 	mov    %rax,0x1af80(%rip)        # 20b88 <fwp_heap+0x1428>
    5c08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c11:	f2 0f 58 05 7f af 01 	addsd  0x1af7f(%rip),%xmm0        # 20b98 <fwp_heap+0x1438>
    5c18:	00 
    5c19:	f2 0f 11 05 77 af 01 	movsd  %xmm0,0x1af77(%rip)        # 20b98 <fwp_heap+0x1438>
    5c20:	00 
    5c21:	b8 02 00 00 00       	mov    $0x2,%eax
    5c26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c37:	49 8b 04 24          	mov    (%r12),%rax
    5c3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c48:	48 83 c4 08          	add    $0x8,%rsp
    5c4c:	48 89 d8             	mov    %rbx,%rax
    5c4f:	5b                   	pop    %rbx
    5c50:	5d                   	pop    %rbp
    5c51:	41 5c                	pop    %r12
    5c53:	41 5e                	pop    %r14
    5c55:	c3                   	ret
    5c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c5d:	00 00 00 
    5c60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c64:	48 85 db             	test   %rbx,%rbx
    5c67:	74 1f                	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c6d:	48 29 da             	sub    %rbx,%rdx
    5c70:	48 39 ea             	cmp    %rbp,%rdx
    5c73:	72 13                	jb     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c7d:	e9 3e ff ff ff       	jmp    5bc0 <fwp_data.part.0.constprop.0+0x50>
    5c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c88:	31 f6                	xor    %esi,%esi
    5c8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c8f:	e8 bc fd ff ff       	call   5a50 <fwp_heap_alloc>
    5c94:	48 89 c3             	mov    %rax,%rbx
    5c97:	eb 88                	jmp    5c21 <fwp_data.part.0.constprop.0+0xb1>
    5c99:	e8 12 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c9e:	66 90                	xchg   %ax,%ax

0000000000005ca0 <fwp_tape_reserve>:
    5ca0:	41 57                	push   %r15
    5ca2:	41 56                	push   %r14
    5ca4:	41 55                	push   %r13
    5ca6:	41 54                	push   %r12
    5ca8:	55                   	push   %rbp
    5ca9:	53                   	push   %rbx
    5caa:	48 83 ec 18          	sub    $0x18,%rsp
    5cae:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    5cb5:	0f 87 d3 01 00 00    	ja     5e8e <fwp_tape_reserve+0x1ee>
    5cbb:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5cbf:	48 89 fd             	mov    %rdi,%rbp
    5cc2:	48 39 f3             	cmp    %rsi,%rbx
    5cc5:	0f 8d 13 01 00 00    	jge    5dde <fwp_tape_reserve+0x13e>
    5ccb:	48 85 db             	test   %rbx,%rbx
    5cce:	b8 40 00 00 00       	mov    $0x40,%eax
    5cd3:	48 0f 44 d8          	cmove  %rax,%rbx
    5cd7:	48 39 f3             	cmp    %rsi,%rbx
    5cda:	7d 24                	jge    5d00 <fwp_tape_reserve+0x60>
    5cdc:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5ce3:	0f 8f 07 01 00 00    	jg     5df0 <fwp_tape_reserve+0x150>
    5ce9:	48 01 db             	add    %rbx,%rbx
    5cec:	48 39 f3             	cmp    %rsi,%rbx
    5cef:	7c eb                	jl     5cdc <fwp_tape_reserve+0x3c>
    5cf1:	0f 1f 40 00          	nopl   0x0(%rax)
    5cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5cfc:	00 00 00 00 
    5d00:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    5d07:	00 
    5d08:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5d0c:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    5d10:	4c 89 ee             	mov    %r13,%rsi
    5d13:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    5d17:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    5d1b:	e8 b0 d8 ff ff       	call   35d0 <realloc@plt>
    5d20:	48 85 c0             	test   %rax,%rax
    5d23:	0f 84 71 01 00 00    	je     5e9a <fwp_tape_reserve+0x1fa>
    5d29:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5d2d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5d31:	4d 29 fc             	sub    %r15,%r12
    5d34:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5d38:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    5d3c:	4d 85 f6             	test   %r14,%r14
    5d3f:	0f 84 03 01 00 00    	je     5e48 <fwp_tape_reserve+0x1a8>
    5d45:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5d49:	48 39 da             	cmp    %rbx,%rdx
    5d4c:	7d 78                	jge    5dc6 <fwp_tape_reserve+0x126>
    5d4e:	48 89 d9             	mov    %rbx,%rcx
    5d51:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    5d55:	be 02 00 00 00       	mov    $0x2,%esi
    5d5a:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5d5f:	48 c1 e1 04          	shl    $0x4,%rcx
    5d63:	48 89 cf             	mov    %rcx,%rdi
    5d66:	48 89 0c 24          	mov    %rcx,(%rsp)
    5d6a:	e8 e1 fc ff ff       	call   5a50 <fwp_heap_alloc>
    5d6f:	49 89 c5             	mov    %rax,%r13
    5d72:	4d 85 ff             	test   %r15,%r15
    5d75:	74 27                	je     5d9e <fwp_tape_reserve+0xfe>
    5d77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5d7c:	48 8b 0c 24          	mov    (%rsp),%rcx
    5d80:	48 89 c7             	mov    %rax,%rdi
    5d83:	4c 89 fe             	mov    %r15,%rsi
    5d86:	48 c1 e2 04          	shl    $0x4,%rdx
    5d8a:	48 39 ca             	cmp    %rcx,%rdx
    5d8d:	48 0f 47 d1          	cmova  %rcx,%rdx
    5d91:	e8 0a d8 ff ff       	call   35a0 <memcpy@plt>
    5d96:	4c 89 ff             	mov    %r15,%rdi
    5d99:	e8 b2 f7 ff ff       	call   5550 <fwp_mem_free>
    5d9e:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5da2:	48 89 da             	mov    %rbx,%rdx
    5da5:	31 f6                	xor    %esi,%esi
    5da7:	48 29 fa             	sub    %rdi,%rdx
    5daa:	48 c1 e7 04          	shl    $0x4,%rdi
    5dae:	48 c1 e2 04          	shl    $0x4,%rdx
    5db2:	4c 01 ef             	add    %r13,%rdi
    5db5:	e8 06 d7 ff ff       	call   34c0 <memset@plt>
    5dba:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    5dbe:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5dc2:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    5dc6:	4d 85 e4             	test   %r12,%r12
    5dc9:	75 55                	jne    5e20 <fwp_tape_reserve+0x180>
    5dcb:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5dd2:	00 
    5dd3:	4c 01 e8             	add    %r13,%rax
    5dd6:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    5dda:	48 89 45 28          	mov    %rax,0x28(%rbp)
    5dde:	48 83 c4 18          	add    $0x18,%rsp
    5de2:	5b                   	pop    %rbx
    5de3:	5d                   	pop    %rbp
    5de4:	41 5c                	pop    %r12
    5de6:	41 5d                	pop    %r13
    5de8:	41 5e                	pop    %r14
    5dea:	41 5f                	pop    %r15
    5dec:	c3                   	ret
    5ded:	0f 1f 00             	nopl   (%rax)
    5df0:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    5df5:	e9 06 ff ff ff       	jmp    5d00 <fwp_tape_reserve+0x60>
    5dfa:	4d 39 f5             	cmp    %r14,%r13
    5dfd:	4c 89 f1             	mov    %r14,%rcx
    5e00:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    5e07:	00 
    5e08:	49 0f 43 cd          	cmovae %r13,%rcx
    5e0c:	4c 29 e9             	sub    %r13,%rcx
    5e0f:	e8 4c d7 ff ff       	call   3560 <__memmove_chk@plt>
    5e14:	4c 03 6d 30          	add    0x30(%rbp),%r13
    5e18:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5e1c:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    5e20:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    5e24:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5e2b:	00 
    5e2c:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    5e33:	00 
    5e34:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    5e38:	e8 d3 d7 ff ff       	call   3610 <memmove@plt>
    5e3d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5e41:	eb 90                	jmp    5dd3 <fwp_tape_reserve+0x133>
    5e43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e48:	49 89 de             	mov    %rbx,%r14
    5e4b:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5e4f:	49 c1 e6 04          	shl    $0x4,%r14
    5e53:	4c 89 f6             	mov    %r14,%rsi
    5e56:	e8 75 d7 ff ff       	call   35d0 <realloc@plt>
    5e5b:	48 85 c0             	test   %rax,%rax
    5e5e:	74 3a                	je     5e9a <fwp_tape_reserve+0x1fa>
    5e60:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5e64:	48 89 45 30          	mov    %rax,0x30(%rbp)
    5e68:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    5e6c:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    5e70:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    5e74:	4d 85 e4             	test   %r12,%r12
    5e77:	75 81                	jne    5dfa <fwp_tape_reserve+0x15a>
    5e79:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    5e7d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5e81:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5e88:	00 
    5e89:	e9 45 ff ff ff       	jmp    5dd3 <fwp_tape_reserve+0x133>
    5e8e:	48 8d 3d 54 52 00 00 	lea    0x5254(%rip),%rdi        # b0e9 <_IO_stdin_used+0xe9>
    5e95:	e8 06 e3 ff ff       	call   41a0 <fwp_trap>
    5e9a:	48 89 ef             	mov    %rbp,%rdi
    5e9d:	e8 5e dd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    5ea2:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5ea6:	e8 15 d5 ff ff       	call   33c0 <free@plt>
    5eab:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5eaf:	e8 0c d5 ff ff       	call   33c0 <free@plt>
    5eb4:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    5eb8:	e8 03 d5 ff ff       	call   33c0 <free@plt>
    5ebd:	31 c9                	xor    %ecx,%ecx
    5ebf:	31 c0                	xor    %eax,%eax
    5ec1:	31 d2                	xor    %edx,%edx
    5ec3:	89 55 04             	mov    %edx,0x4(%rbp)
    5ec6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5eca:	ba 13 00 00 00       	mov    $0x13,%edx
    5ecf:	be 01 00 00 00       	mov    $0x1,%esi
    5ed4:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    5ed8:	48 8d 3d 29 51 00 00 	lea    0x5129(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    5edf:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    5ee3:	48 8b 0d 56 91 00 00 	mov    0x9156(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    5eea:	48 89 45 40          	mov    %rax,0x40(%rbp)
    5eee:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    5ef2:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    5ef6:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    5efa:	e8 81 d7 ff ff       	call   3680 <fwrite@plt>
    5eff:	31 ff                	xor    %edi,%edi
    5f01:	e8 ba d6 ff ff       	call   35c0 <fflush@plt>
    5f06:	bf 66 00 00 00       	mov    $0x66,%edi
    5f0b:	e8 90 d7 ff ff       	call   36a0 <_Exit@plt>

0000000000005f10 <f141.constprop.0>:
    5f10:	41 57                	push   %r15
    5f12:	41 56                	push   %r14
    5f14:	41 55                	push   %r13
    5f16:	41 54                	push   %r12
    5f18:	49 89 f4             	mov    %rsi,%r12
    5f1b:	55                   	push   %rbp
    5f1c:	48 89 fd             	mov    %rdi,%rbp
    5f1f:	53                   	push   %rbx
    5f20:	48 83 ec 08          	sub    $0x8,%rsp
    5f24:	48 85 ff             	test   %rdi,%rdi
    5f27:	79 09                	jns    5f32 <f141.constprop.0+0x22>
    5f29:	48 85 f6             	test   %rsi,%rsi
    5f2c:	0f 88 fe 00 00 00    	js     6030 <f141.constprop.0+0x120>
    5f32:	48 89 f8             	mov    %rdi,%rax
    5f35:	48 09 f0             	or     %rsi,%rax
    5f38:	0f 89 d2 00 00 00    	jns    6010 <f141.constprop.0+0x100>
    5f3e:	48 89 f8             	mov    %rdi,%rax
    5f41:	48 c1 f8 20          	sar    $0x20,%rax
    5f45:	48 85 ff             	test   %rdi,%rdi
    5f48:	0f 88 02 01 00 00    	js     6050 <f141.constprop.0+0x140>
    5f4e:	4c 8b 3d 2b 5b 00 00 	mov    0x5b2b(%rip),%r15        # ba80 <msg.4+0xb0>
    5f55:	48 89 c7             	mov    %rax,%rdi
    5f58:	e8 23 e5 ff ff       	call   4480 <fwp_tape_of>
    5f5d:	48 89 c3             	mov    %rax,%rbx
    5f60:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5f65:	0f 85 16 01 00 00    	jne    6081 <f141.constprop.0+0x171>
    5f6b:	4c 8b 68 10          	mov    0x10(%rax),%r13
    5f6f:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    5f76:	0f 8f f9 00 00 00    	jg     6075 <f141.constprop.0+0x165>
    5f7c:	89 e8                	mov    %ebp,%eax
    5f7e:	49 39 c5             	cmp    %rax,%r13
    5f81:	0f 8e e2 00 00 00    	jle    6069 <f141.constprop.0+0x159>
    5f87:	4d 85 e4             	test   %r12,%r12
    5f8a:	78 0c                	js     5f98 <f141.constprop.0+0x88>
    5f8c:	44 89 e0             	mov    %r12d,%eax
    5f8f:	49 39 c5             	cmp    %rax,%r13
    5f92:	0f 8e d1 00 00 00    	jle    6069 <f141.constprop.0+0x159>
    5f98:	4d 89 ee             	mov    %r13,%r14
    5f9b:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5f9f:	48 89 df             	mov    %rbx,%rdi
    5fa2:	49 8d 76 01          	lea    0x1(%r14),%rsi
    5fa6:	e8 f5 fc ff ff       	call   5ca0 <fwp_tape_reserve>
    5fab:	48 8b 43 20          	mov    0x20(%rbx),%rax
    5faf:	4d 85 e4             	test   %r12,%r12
    5fb2:	48 8b 0d c7 5a 00 00 	mov    0x5ac7(%rip),%rcx        # ba80 <msg.4+0xb0>
    5fb9:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    5fc0:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    5fc4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5fc8:	4c 0f 48 e2          	cmovs  %rdx,%r12
    5fcc:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    5fd0:	48 8b 43 28          	mov    0x28(%rbx),%rax
    5fd4:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    5fd8:	48 8b 43 38          	mov    0x38(%rbx),%rax
    5fdc:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    5fe0:	49 8d 45 01          	lea    0x1(%r13),%rax
    5fe4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5fe8:	48 83 c4 08          	add    $0x8,%rsp
    5fec:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5ff3:	ff ff ff 
    5ff6:	48 21 e8             	and    %rbp,%rax
    5ff9:	5b                   	pop    %rbx
    5ffa:	5d                   	pop    %rbp
    5ffb:	4c 09 e8             	or     %r13,%rax
    5ffe:	41 5c                	pop    %r12
    6000:	41 5d                	pop    %r13
    6002:	41 5e                	pop    %r14
    6004:	41 5f                	pop    %r15
    6006:	c3                   	ret
    6007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    600e:	00 00 
    6010:	48 89 f0             	mov    %rsi,%rax
    6013:	48 c1 ff 20          	sar    $0x20,%rdi
    6017:	48 c1 f8 20          	sar    $0x20,%rax
    601b:	48 39 c7             	cmp    %rax,%rdi
    601e:	0f 84 2a ff ff ff    	je     5f4e <f141.constprop.0+0x3e>
    6024:	48 8d 3d 75 57 00 00 	lea    0x5775(%rip),%rdi        # b7a0 <_IO_stdin_used+0x7a0>
    602b:	e8 70 e1 ff ff       	call   41a0 <fwp_trap>
    6030:	48 83 c4 08          	add    $0x8,%rsp
    6034:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    603b:	5b                   	pop    %rbx
    603c:	5d                   	pop    %rbp
    603d:	41 5c                	pop    %r12
    603f:	41 5d                	pop    %r13
    6041:	41 5e                	pop    %r14
    6043:	41 5f                	pop    %r15
    6045:	c3                   	ret
    6046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    604d:	00 00 00 
    6050:	48 89 f0             	mov    %rsi,%rax
    6053:	48 89 f5             	mov    %rsi,%rbp
    6056:	45 31 ff             	xor    %r15d,%r15d
    6059:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6060:	48 c1 f8 20          	sar    $0x20,%rax
    6064:	e9 ec fe ff ff       	jmp    5f55 <f141.constprop.0+0x45>
    6069:	48 8d 3d 94 50 00 00 	lea    0x5094(%rip),%rdi        # b104 <_IO_stdin_used+0x104>
    6070:	e8 2b e1 ff ff       	call   41a0 <fwp_trap>
    6075:	48 8d 3d 6d 50 00 00 	lea    0x506d(%rip),%rdi        # b0e9 <_IO_stdin_used+0xe9>
    607c:	e8 1f e1 ff ff       	call   41a0 <fwp_trap>
    6081:	48 8d 3d 60 57 00 00 	lea    0x5760(%rip),%rdi        # b7e8 <_IO_stdin_used+0x7e8>
    6088:	e8 13 e1 ff ff       	call   41a0 <fwp_trap>
    608d:	0f 1f 00             	nopl   (%rax)

0000000000006090 <w120>:
    6090:	66 0f 28 d0          	movapd %xmm0,%xmm2
    6094:	41 57                	push   %r15
    6096:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    609a:	41 56                	push   %r14
    609c:	41 55                	push   %r13
    609e:	41 54                	push   %r12
    60a0:	49 89 f4             	mov    %rsi,%r12
    60a3:	55                   	push   %rbp
    60a4:	48 89 fd             	mov    %rdi,%rbp
    60a7:	53                   	push   %rbx
    60a8:	48 83 ec 38          	sub    $0x38,%rsp
    60ac:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    60b1:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    60b7:	48 85 ff             	test   %rdi,%rdi
    60ba:	0f 88 d0 04 00 00    	js     6590 <w120+0x500>
    60c0:	49 89 ff             	mov    %rdi,%r15
    60c3:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    60c9:	49 c1 ff 20          	sar    $0x20,%r15
    60cd:	4c 89 ff             	mov    %r15,%rdi
    60d0:	e8 ab e3 ff ff       	call   4480 <fwp_tape_of>
    60d5:	48 89 c3             	mov    %rax,%rbx
    60d8:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    60dd:	0f 85 45 05 00 00    	jne    6628 <w120+0x598>
    60e3:	4c 8b 68 10          	mov    0x10(%rax),%r13
    60e7:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    60ee:	0f 8f 28 05 00 00    	jg     661c <w120+0x58c>
    60f4:	89 e8                	mov    %ebp,%eax
    60f6:	49 39 c5             	cmp    %rax,%r13
    60f9:	0f 8e 11 05 00 00    	jle    6610 <w120+0x580>
    60ff:	4d 89 ee             	mov    %r13,%r14
    6102:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6106:	48 89 df             	mov    %rbx,%rdi
    6109:	49 8d 76 01          	lea    0x1(%r14),%rsi
    610d:	e8 8e fb ff ff       	call   5ca0 <fwp_tape_reserve>
    6112:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6116:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    611b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6121:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6125:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6129:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    612f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6133:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6137:	48 8b 43 38          	mov    0x38(%rbx),%rax
    613b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6141:	49 8d 45 01          	lea    0x1(%r13),%rax
    6145:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    614c:	ff ff ff 
    614f:	49 21 ee             	and    %rbp,%r14
    6152:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6156:	4d 09 ee             	or     %r13,%r14
    6159:	4d 89 f5             	mov    %r14,%r13
    615c:	49 c1 fd 20          	sar    $0x20,%r13
    6160:	4d 85 e4             	test   %r12,%r12
    6163:	78 10                	js     6175 <w120+0xe5>
    6165:	4c 89 e0             	mov    %r12,%rax
    6168:	48 c1 f8 20          	sar    $0x20,%rax
    616c:	4c 39 e8             	cmp    %r13,%rax
    616f:	0f 85 87 04 00 00    	jne    65fc <w120+0x56c>
    6175:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    617b:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6181:	4d 39 ef             	cmp    %r13,%r15
    6184:	0f 84 d6 03 00 00    	je     6560 <w120+0x4d0>
    618a:	f2 0f 10 1d ee 58 00 	movsd  0x58ee(%rip),%xmm3        # ba80 <msg.4+0xb0>
    6191:	00 
    6192:	f2 0f 10 25 ee 58 00 	movsd  0x58ee(%rip),%xmm4        # ba88 <msg.4+0xb8>
    6199:	00 
    619a:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    61a0:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    61a6:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    61ac:	4c 89 ef             	mov    %r13,%rdi
    61af:	e8 cc e2 ff ff       	call   4480 <fwp_tape_of>
    61b4:	48 89 c3             	mov    %rax,%rbx
    61b7:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    61bc:	0f 85 66 04 00 00    	jne    6628 <w120+0x598>
    61c2:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    61c6:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    61cd:	0f 8f 49 04 00 00    	jg     661c <w120+0x58c>
    61d3:	44 89 f0             	mov    %r14d,%eax
    61d6:	49 39 c7             	cmp    %rax,%r15
    61d9:	0f 8e 31 04 00 00    	jle    6610 <w120+0x580>
    61df:	4d 85 e4             	test   %r12,%r12
    61e2:	78 0c                	js     61f0 <w120+0x160>
    61e4:	44 89 e0             	mov    %r12d,%eax
    61e7:	49 39 c7             	cmp    %rax,%r15
    61ea:	0f 8e 20 04 00 00    	jle    6610 <w120+0x580>
    61f0:	4c 89 f9             	mov    %r15,%rcx
    61f3:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    61f7:	48 89 df             	mov    %rbx,%rdi
    61fa:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    61fe:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6203:	e8 98 fa ff ff       	call   5ca0 <fwp_tape_reserve>
    6208:	48 8b 43 20          	mov    0x20(%rbx),%rax
    620c:	4d 85 e4             	test   %r12,%r12
    620f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6213:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6218:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    621e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6224:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6228:	48 8b 43 30          	mov    0x30(%rbx),%rax
    622c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6231:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6238:	49 0f 49 c4          	cmovns %r12,%rax
    623c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6240:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6243:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6247:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    624c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    6250:	48 85 ed             	test   %rbp,%rbp
    6253:	0f 88 0e 04 00 00    	js     6667 <w120+0x5d7>
    6259:	48 89 e8             	mov    %rbp,%rax
    625c:	48 c1 f8 20          	sar    $0x20,%rax
    6260:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6265:	49 39 c5             	cmp    %rax,%r13
    6268:	74 1a                	je     6284 <w120+0x1f4>
    626a:	48 89 c7             	mov    %rax,%rdi
    626d:	e8 0e e2 ff ff       	call   4480 <fwp_tape_of>
    6272:	48 89 c3             	mov    %rax,%rbx
    6275:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    627a:	0f 85 a8 03 00 00    	jne    6628 <w120+0x598>
    6280:	4c 8b 60 10          	mov    0x10(%rax),%r12
    6284:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    628b:	0f 8f 8b 03 00 00    	jg     661c <w120+0x58c>
    6291:	89 e8                	mov    %ebp,%eax
    6293:	4c 39 e0             	cmp    %r12,%rax
    6296:	0f 8d 74 03 00 00    	jge    6610 <w120+0x580>
    629c:	4c 89 e0             	mov    %r12,%rax
    629f:	48 2b 43 08          	sub    0x8(%rbx),%rax
    62a3:	48 89 df             	mov    %rbx,%rdi
    62a6:	48 8d 70 01          	lea    0x1(%rax),%rsi
    62aa:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    62af:	e8 ec f9 ff ff       	call   5ca0 <fwp_tape_reserve>
    62b4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    62b9:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    62bd:	48 8b 0d c4 57 00 00 	mov    0x57c4(%rip),%rcx        # ba88 <msg.4+0xb8>
    62c4:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    62ca:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    62cd:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    62d1:	66 0f 28 ee          	movapd %xmm6,%xmm5
    62d5:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    62db:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    62df:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    62e3:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    62e7:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    62ee:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    62f2:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    62f7:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    62fc:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6300:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6307:	ff ff ff 
    630a:	48 21 c5             	and    %rax,%rbp
    630d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6313:	4c 09 e5             	or     %r12,%rbp
    6316:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    631d:	ff ff ff 
    6320:	49 21 c6             	and    %rax,%r14
    6323:	4d 09 fe             	or     %r15,%r14
    6326:	4d 89 f4             	mov    %r14,%r12
    6329:	49 c1 fc 20          	sar    $0x20,%r12
    632d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6332:	74 16                	je     634a <w120+0x2ba>
    6334:	4c 89 e7             	mov    %r12,%rdi
    6337:	e8 44 e1 ff ff       	call   4480 <fwp_tape_of>
    633c:	48 89 c3             	mov    %rax,%rbx
    633f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6344:	0f 85 de 02 00 00    	jne    6628 <w120+0x598>
    634a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    634e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6355:	0f 8f c1 02 00 00    	jg     661c <w120+0x58c>
    635b:	44 89 f0             	mov    %r14d,%eax
    635e:	49 39 c7             	cmp    %rax,%r15
    6361:	0f 8e a9 02 00 00    	jle    6610 <w120+0x580>
    6367:	4d 89 fd             	mov    %r15,%r13
    636a:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    636e:	48 89 df             	mov    %rbx,%rdi
    6371:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6375:	e8 26 f9 ff ff       	call   5ca0 <fwp_tape_reserve>
    637a:	48 8b 43 20          	mov    0x20(%rbx),%rax
    637e:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    6384:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    6388:	48 8b 43 30          	mov    0x30(%rbx),%rax
    638c:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    6392:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6396:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    639a:	48 8b 43 38          	mov    0x38(%rbx),%rax
    639e:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    63a4:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    63a8:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    63af:	ff ff ff 
    63b2:	49 21 c6             	and    %rax,%r14
    63b5:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    63b9:	4d 09 fe             	or     %r15,%r14
    63bc:	4d 89 f7             	mov    %r14,%r15
    63bf:	49 c1 ff 20          	sar    $0x20,%r15
    63c3:	4d 39 e7             	cmp    %r12,%r15
    63c6:	74 1d                	je     63e5 <w120+0x355>
    63c8:	4c 89 ff             	mov    %r15,%rdi
    63cb:	e8 b0 e0 ff ff       	call   4480 <fwp_tape_of>
    63d0:	48 89 c3             	mov    %rax,%rbx
    63d3:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63d8:	0f 85 4a 02 00 00    	jne    6628 <w120+0x598>
    63de:	4c 8b 68 10          	mov    0x10(%rax),%r13
    63e2:	4d 89 fc             	mov    %r15,%r12
    63e5:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    63ec:	0f 8f 2a 02 00 00    	jg     661c <w120+0x58c>
    63f2:	44 89 f0             	mov    %r14d,%eax
    63f5:	4c 39 e8             	cmp    %r13,%rax
    63f8:	0f 8d 12 02 00 00    	jge    6610 <w120+0x580>
    63fe:	f2 0f 10 3d 8a 56 00 	movsd  0x568a(%rip),%xmm7        # ba90 <msg.4+0xc0>
    6405:	00 
    6406:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    640c:	4d 89 ef             	mov    %r13,%r15
    640f:	48 89 df             	mov    %rbx,%rdi
    6412:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6418:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    641d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6421:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6425:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    642a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6430:	e8 6b f8 ff ff       	call   5ca0 <fwp_tape_reserve>
    6435:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6439:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    643e:	48 8b 15 4b 56 00 00 	mov    0x564b(%rip),%rdx        # ba90 <msg.4+0xc0>
    6445:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6449:	48 8b 43 30          	mov    0x30(%rbx),%rax
    644d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6451:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6455:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6459:	48 8b 43 28          	mov    0x28(%rbx),%rax
    645d:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    6464:	ff 
    6465:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6469:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    6470:	00 
    6471:	49 8d 45 01          	lea    0x1(%r13),%rax
    6475:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6479:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6480:	ff ff ff 
    6483:	49 21 c6             	and    %rax,%r14
    6486:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    648c:	4d 09 ee             	or     %r13,%r14
    648f:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    6493:	0f 84 57 01 00 00    	je     65f0 <w120+0x560>
    6499:	48 89 ef             	mov    %rbp,%rdi
    649c:	48 c1 ff 20          	sar    $0x20,%rdi
    64a0:	4c 39 e7             	cmp    %r12,%rdi
    64a3:	74 13                	je     64b8 <w120+0x428>
    64a5:	e8 d6 df ff ff       	call   4480 <fwp_tape_of>
    64aa:	48 89 c3             	mov    %rax,%rbx
    64ad:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    64b2:	0f 85 70 01 00 00    	jne    6628 <w120+0x598>
    64b8:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    64bc:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    64c3:	0f 8f 53 01 00 00    	jg     661c <w120+0x58c>
    64c9:	89 e8                	mov    %ebp,%eax
    64cb:	4c 39 e0             	cmp    %r12,%rax
    64ce:	0f 8d 3c 01 00 00    	jge    6610 <w120+0x580>
    64d4:	4d 89 e5             	mov    %r12,%r13
    64d7:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    64db:	48 89 df             	mov    %rbx,%rdi
    64de:	49 8d 75 01          	lea    0x1(%r13),%rsi
    64e2:	e8 b9 f7 ff ff       	call   5ca0 <fwp_tape_reserve>
    64e7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    64eb:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    64f0:	48 89 ef             	mov    %rbp,%rdi
    64f3:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    64f7:	48 8b 43 30          	mov    0x30(%rbx),%rax
    64fb:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6501:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6505:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6509:	48 8b 43 38          	mov    0x38(%rbx),%rax
    650d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6513:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6518:	48 89 43 10          	mov    %rax,0x10(%rbx)
    651c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6523:	ff ff ff 
    6526:	48 21 c7             	and    %rax,%rdi
    6529:	4c 09 e7             	or     %r12,%rdi
    652c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6532:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6538:	4c 89 f6             	mov    %r14,%rsi
    653b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6540:	e8 cb f9 ff ff       	call   5f10 <f141.constprop.0>
    6545:	48 83 c4 38          	add    $0x38,%rsp
    6549:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    654e:	5b                   	pop    %rbx
    654f:	5d                   	pop    %rbp
    6550:	41 5c                	pop    %r12
    6552:	41 5d                	pop    %r13
    6554:	41 5e                	pop    %r14
    6556:	41 5f                	pop    %r15
    6558:	c3                   	ret
    6559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6560:	f2 0f 10 3d 18 55 00 	movsd  0x5518(%rip),%xmm7        # ba80 <msg.4+0xb0>
    6567:	00 
    6568:	f2 0f 10 15 18 55 00 	movsd  0x5518(%rip),%xmm2        # ba88 <msg.4+0xb8>
    656f:	00 
    6570:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    6576:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    657c:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    6582:	e9 3b fc ff ff       	jmp    61c2 <w120+0x132>
    6587:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    658e:	00 00 
    6590:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6596:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    659c:	48 85 f6             	test   %rsi,%rsi
    659f:	0f 89 8f 00 00 00    	jns    6634 <w120+0x5a4>
    65a5:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    65ab:	f2 0f 10 05 cd 54 00 	movsd  0x54cd(%rip),%xmm0        # ba80 <msg.4+0xb0>
    65b2:	00 
    65b3:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    65ba:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    65c1:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    65c6:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    65ca:	f2 0f 59 0d be 54 00 	mulsd  0x54be(%rip),%xmm1        # ba90 <msg.4+0xc0>
    65d1:	00 
    65d2:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    65d6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    65dc:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    65e2:	e9 45 ff ff ff       	jmp    652c <w120+0x49c>
    65e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    65ee:	00 00 
    65f0:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    65f7:	e9 30 ff ff ff       	jmp    652c <w120+0x49c>
    65fc:	48 8d 3d 9d 51 00 00 	lea    0x519d(%rip),%rdi        # b7a0 <_IO_stdin_used+0x7a0>
    6603:	e8 98 db ff ff       	call   41a0 <fwp_trap>
    6608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    660f:	00 
    6610:	48 8d 3d ed 4a 00 00 	lea    0x4aed(%rip),%rdi        # b104 <_IO_stdin_used+0x104>
    6617:	e8 84 db ff ff       	call   41a0 <fwp_trap>
    661c:	48 8d 3d c6 4a 00 00 	lea    0x4ac6(%rip),%rdi        # b0e9 <_IO_stdin_used+0xe9>
    6623:	e8 78 db ff ff       	call   41a0 <fwp_trap>
    6628:	48 8d 3d b9 51 00 00 	lea    0x51b9(%rip),%rdi        # b7e8 <_IO_stdin_used+0x7e8>
    662f:	e8 6c db ff ff       	call   41a0 <fwp_trap>
    6634:	f2 0f 10 35 44 54 00 	movsd  0x5444(%rip),%xmm6        # ba80 <msg.4+0xb0>
    663b:	00 
    663c:	49 89 f5             	mov    %rsi,%r13
    663f:	49 89 f6             	mov    %rsi,%r14
    6642:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6649:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6650:	00 00 
    6652:	49 c1 fd 20          	sar    $0x20,%r13
    6656:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    665c:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6662:	e9 45 fb ff ff       	jmp    61ac <w120+0x11c>
    6667:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    666d:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    6672:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6679:	66 0f 28 f4          	movapd %xmm4,%xmm6
    667d:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    6681:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6687:	e9 8a fc ff ff       	jmp    6316 <w120+0x286>
    668c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006690 <fwp_rc_share>:
    6690:	48 8b 05 a1 a4 01 00 	mov    0x1a4a1(%rip),%rax        # 20b38 <fwp_heap+0x13d8>
    6697:	48 2b 3d 72 a4 01 00 	sub    0x1a472(%rip),%rdi        # 20b10 <fwp_heap+0x13b0>
    669e:	48 c1 e0 10          	shl    $0x10,%rax
    66a2:	48 39 c7             	cmp    %rax,%rdi
    66a5:	73 4a                	jae    66f1 <fwp_rc_share+0x61>
    66a7:	48 89 f8             	mov    %rdi,%rax
    66aa:	48 c1 e8 10          	shr    $0x10,%rax
    66ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    66b2:	48 8b 05 9f a4 01 00 	mov    0x1a49f(%rip),%rax        # 20b58 <fwp_heap+0x13f8>
    66b9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    66bd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    66c1:	48 85 d2             	test   %rdx,%rdx
    66c4:	74 2b                	je     66f1 <fwp_rc_share+0x61>
    66c6:	0f b6 08             	movzbl (%rax),%ecx
    66c9:	80 f9 02             	cmp    $0x2,%cl
    66cc:	74 2a                	je     66f8 <fwp_rc_share+0x68>
    66ce:	80 f9 01             	cmp    $0x1,%cl
    66d1:	75 1e                	jne    66f1 <fwp_rc_share+0x61>
    66d3:	8b 48 18             	mov    0x18(%rax),%ecx
    66d6:	0f b7 ff             	movzwl %di,%edi
    66d9:	8b 40 1c             	mov    0x1c(%rax),%eax
    66dc:	48 0f af f9          	imul   %rcx,%rdi
    66e0:	48 c1 ef 20          	shr    $0x20,%rdi
    66e4:	48 39 c7             	cmp    %rax,%rdi
    66e7:	73 08                	jae    66f1 <fwp_rc_share+0x61>
    66e9:	48 01 fa             	add    %rdi,%rdx
    66ec:	80 3a 00             	cmpb   $0x0,(%rdx)
    66ef:	75 0d                	jne    66fe <fwp_rc_share+0x6e>
    66f1:	c3                   	ret
    66f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66f8:	66 85 ff             	test   %di,%di
    66fb:	74 ef                	je     66ec <fwp_rc_share+0x5c>
    66fd:	c3                   	ret
    66fe:	50                   	push   %rax
    66ff:	48 8d 3d 12 51 00 00 	lea    0x5112(%rip),%rdi        # b818 <_IO_stdin_used+0x818>
    6706:	e8 95 da ff ff       	call   41a0 <fwp_trap>
    670b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006710 <fwp_rc_free_obj>:
    6710:	48 8b 15 21 a4 01 00 	mov    0x1a421(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    6717:	48 89 f8             	mov    %rdi,%rax
    671a:	48 2b 05 ef a3 01 00 	sub    0x1a3ef(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    6721:	48 c1 e2 10          	shl    $0x10,%rdx
    6725:	48 39 d0             	cmp    %rdx,%rax
    6728:	73 5b                	jae    6785 <fwp_rc_free_obj+0x75>
    672a:	48 89 c2             	mov    %rax,%rdx
    672d:	48 c1 ea 10          	shr    $0x10,%rdx
    6731:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6735:	48 8b 15 1c a4 01 00 	mov    0x1a41c(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    673c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6740:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6744:	48 85 c9             	test   %rcx,%rcx
    6747:	74 3c                	je     6785 <fwp_rc_free_obj+0x75>
    6749:	0f b6 32             	movzbl (%rdx),%esi
    674c:	40 80 fe 02          	cmp    $0x2,%sil
    6750:	74 2e                	je     6780 <fwp_rc_free_obj+0x70>
    6752:	40 80 fe 01          	cmp    $0x1,%sil
    6756:	75 2d                	jne    6785 <fwp_rc_free_obj+0x75>
    6758:	8b 72 18             	mov    0x18(%rdx),%esi
    675b:	0f b7 c0             	movzwl %ax,%eax
    675e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6761:	48 0f af c6          	imul   %rsi,%rax
    6765:	48 c1 e8 20          	shr    $0x20,%rax
    6769:	48 39 d0             	cmp    %rdx,%rax
    676c:	73 17                	jae    6785 <fwp_rc_free_obj+0x75>
    676e:	48 01 c1             	add    %rax,%rcx
    6771:	80 39 01             	cmpb   $0x1,(%rcx)
    6774:	75 0f                	jne    6785 <fwp_rc_free_obj+0x75>
    6776:	e9 d5 ed ff ff       	jmp    5550 <fwp_mem_free>
    677b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6780:	66 85 c0             	test   %ax,%ax
    6783:	74 ec                	je     6771 <fwp_rc_free_obj+0x61>
    6785:	c3                   	ret
    6786:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    678d:	00 00 00 

0000000000006790 <fwp_rc_dup>:
    6790:	f3 0f 1e fa          	endbr64
    6794:	48 8b 05 9d a3 01 00 	mov    0x1a39d(%rip),%rax        # 20b38 <fwp_heap+0x13d8>
    679b:	48 2b 3d 6e a3 01 00 	sub    0x1a36e(%rip),%rdi        # 20b10 <fwp_heap+0x13b0>
    67a2:	48 c1 e0 10          	shl    $0x10,%rax
    67a6:	48 39 c7             	cmp    %rax,%rdi
    67a9:	73 56                	jae    6801 <fwp_rc_dup+0x71>
    67ab:	48 89 f8             	mov    %rdi,%rax
    67ae:	48 c1 e8 10          	shr    $0x10,%rax
    67b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    67b6:	48 8b 05 9b a3 01 00 	mov    0x1a39b(%rip),%rax        # 20b58 <fwp_heap+0x13f8>
    67bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    67c1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    67c5:	48 85 c0             	test   %rax,%rax
    67c8:	74 37                	je     6801 <fwp_rc_dup+0x71>
    67ca:	0f b6 0a             	movzbl (%rdx),%ecx
    67cd:	80 f9 02             	cmp    $0x2,%cl
    67d0:	74 36                	je     6808 <fwp_rc_dup+0x78>
    67d2:	80 f9 01             	cmp    $0x1,%cl
    67d5:	75 2a                	jne    6801 <fwp_rc_dup+0x71>
    67d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    67da:	0f b7 ff             	movzwl %di,%edi
    67dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    67e0:	48 0f af f9          	imul   %rcx,%rdi
    67e4:	48 c1 ef 20          	shr    $0x20,%rdi
    67e8:	48 39 d7             	cmp    %rdx,%rdi
    67eb:	73 14                	jae    6801 <fwp_rc_dup+0x71>
    67ed:	48 01 f8             	add    %rdi,%rax
    67f0:	0f b6 10             	movzbl (%rax),%edx
    67f3:	84 d2                	test   %dl,%dl
    67f5:	74 0a                	je     6801 <fwp_rc_dup+0x71>
    67f7:	80 fa fd             	cmp    $0xfd,%dl
    67fa:	77 14                	ja     6810 <fwp_rc_dup+0x80>
    67fc:	83 c2 01             	add    $0x1,%edx
    67ff:	88 10                	mov    %dl,(%rax)
    6801:	c3                   	ret
    6802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6808:	66 85 ff             	test   %di,%di
    680b:	74 e3                	je     67f0 <fwp_rc_dup+0x60>
    680d:	c3                   	ret
    680e:	66 90                	xchg   %ax,%ax
    6810:	48 89 c7             	mov    %rax,%rdi
    6813:	e9 d8 e9 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    681f:	00 

0000000000006820 <fwp_owned_entry173>:
    6820:	f3 0f 1e fa          	endbr64
    6824:	48 83 ec 38          	sub    $0x38,%rsp
    6828:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    682d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6834:	00 00 
    6836:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    683b:	31 c0                	xor    %eax,%eax
    683d:	48 8b 07             	mov    (%rdi),%rax
    6840:	48 03 47 10          	add    0x10(%rdi),%rax
    6844:	0f 80 c2 00 00 00    	jo     690c <fwp_owned_entry173+0xec>
    684a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    684f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6854:	31 ff                	xor    %edi,%edi
    6856:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    685a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    685f:	e8 0c f3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6864:	48 8b 15 cd a2 01 00 	mov    0x1a2cd(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    686b:	48 89 c6             	mov    %rax,%rsi
    686e:	48 2b 05 9b a2 01 00 	sub    0x1a29b(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    6875:	48 c1 e2 10          	shl    $0x10,%rdx
    6879:	48 39 d0             	cmp    %rdx,%rax
    687c:	73 4f                	jae    68cd <fwp_owned_entry173+0xad>
    687e:	48 89 c2             	mov    %rax,%rdx
    6881:	48 c1 ea 10          	shr    $0x10,%rdx
    6885:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6889:	48 8b 15 c8 a2 01 00 	mov    0x1a2c8(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    6890:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6894:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6898:	48 85 d2             	test   %rdx,%rdx
    689b:	74 30                	je     68cd <fwp_owned_entry173+0xad>
    689d:	0f b6 39             	movzbl (%rcx),%edi
    68a0:	40 80 ff 02          	cmp    $0x2,%dil
    68a4:	74 42                	je     68e8 <fwp_owned_entry173+0xc8>
    68a6:	40 80 ff 01          	cmp    $0x1,%dil
    68aa:	75 21                	jne    68cd <fwp_owned_entry173+0xad>
    68ac:	8b 79 18             	mov    0x18(%rcx),%edi
    68af:	0f b7 c0             	movzwl %ax,%eax
    68b2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68b5:	48 0f af c7          	imul   %rdi,%rax
    68b9:	48 c1 e8 20          	shr    $0x20,%rax
    68bd:	48 39 c8             	cmp    %rcx,%rax
    68c0:	73 0b                	jae    68cd <fwp_owned_entry173+0xad>
    68c2:	48 01 c2             	add    %rax,%rdx
    68c5:	80 3a ff             	cmpb   $0xff,(%rdx)
    68c8:	74 26                	je     68f0 <fwp_owned_entry173+0xd0>
    68ca:	c6 02 01             	movb   $0x1,(%rdx)
    68cd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    68d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    68d9:	00 00 
    68db:	75 34                	jne    6911 <fwp_owned_entry173+0xf1>
    68dd:	48 89 f0             	mov    %rsi,%rax
    68e0:	48 83 c4 38          	add    $0x38,%rsp
    68e4:	c3                   	ret
    68e5:	0f 1f 00             	nopl   (%rax)
    68e8:	66 85 c0             	test   %ax,%ax
    68eb:	75 e0                	jne    68cd <fwp_owned_entry173+0xad>
    68ed:	eb d6                	jmp    68c5 <fwp_owned_entry173+0xa5>
    68ef:	90                   	nop
    68f0:	48 89 d7             	mov    %rdx,%rdi
    68f3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    68f8:	48 89 14 24          	mov    %rdx,(%rsp)
    68fc:	e8 0f ea ff ff       	call   5310 <fwp_rc_forget_slot>
    6901:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6906:	48 8b 14 24          	mov    (%rsp),%rdx
    690a:	eb be                	jmp    68ca <fwp_owned_entry173+0xaa>
    690c:	e8 ef cd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6911:	e8 4a cb ff ff       	call   3460 <__stack_chk_fail@plt>
    6916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    691d:	00 00 00 

0000000000006920 <e173>:
    6920:	f3 0f 1e fa          	endbr64
    6924:	53                   	push   %rbx
    6925:	48 83 ec 30          	sub    $0x30,%rsp
    6929:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    692e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6935:	00 00 
    6937:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    693c:	31 c0                	xor    %eax,%eax
    693e:	48 8b 07             	mov    (%rdi),%rax
    6941:	48 03 47 10          	add    0x10(%rdi),%rax
    6945:	0f 80 c9 00 00 00    	jo     6a14 <e173+0xf4>
    694b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6950:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6955:	31 ff                	xor    %edi,%edi
    6957:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    695b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6960:	e8 0b f2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6965:	48 8b 15 cc a1 01 00 	mov    0x1a1cc(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    696c:	48 89 c3             	mov    %rax,%rbx
    696f:	48 2b 05 9a a1 01 00 	sub    0x1a19a(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    6976:	48 c1 e2 10          	shl    $0x10,%rdx
    697a:	48 39 d0             	cmp    %rdx,%rax
    697d:	73 4f                	jae    69ce <e173+0xae>
    697f:	48 89 c2             	mov    %rax,%rdx
    6982:	48 c1 ea 10          	shr    $0x10,%rdx
    6986:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    698a:	48 8b 15 c7 a1 01 00 	mov    0x1a1c7(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    6991:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6995:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6999:	48 85 d2             	test   %rdx,%rdx
    699c:	74 30                	je     69ce <e173+0xae>
    699e:	0f b6 31             	movzbl (%rcx),%esi
    69a1:	40 80 fe 02          	cmp    $0x2,%sil
    69a5:	74 49                	je     69f0 <e173+0xd0>
    69a7:	40 80 fe 01          	cmp    $0x1,%sil
    69ab:	75 21                	jne    69ce <e173+0xae>
    69ad:	8b 71 18             	mov    0x18(%rcx),%esi
    69b0:	0f b7 c0             	movzwl %ax,%eax
    69b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69b6:	48 0f af c6          	imul   %rsi,%rax
    69ba:	48 c1 e8 20          	shr    $0x20,%rax
    69be:	48 39 c8             	cmp    %rcx,%rax
    69c1:	73 0b                	jae    69ce <e173+0xae>
    69c3:	48 01 c2             	add    %rax,%rdx
    69c6:	80 3a ff             	cmpb   $0xff,(%rdx)
    69c9:	74 35                	je     6a00 <e173+0xe0>
    69cb:	c6 02 01             	movb   $0x1,(%rdx)
    69ce:	48 89 df             	mov    %rbx,%rdi
    69d1:	e8 ba fc ff ff       	call   6690 <fwp_rc_share>
    69d6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    69db:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    69e2:	00 00 
    69e4:	75 33                	jne    6a19 <e173+0xf9>
    69e6:	48 83 c4 30          	add    $0x30,%rsp
    69ea:	48 89 d8             	mov    %rbx,%rax
    69ed:	5b                   	pop    %rbx
    69ee:	c3                   	ret
    69ef:	90                   	nop
    69f0:	66 85 c0             	test   %ax,%ax
    69f3:	75 d9                	jne    69ce <e173+0xae>
    69f5:	eb cf                	jmp    69c6 <e173+0xa6>
    69f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    69fe:	00 00 
    6a00:	48 89 d7             	mov    %rdx,%rdi
    6a03:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6a08:	e8 03 e9 ff ff       	call   5310 <fwp_rc_forget_slot>
    6a0d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6a12:	eb b7                	jmp    69cb <e173+0xab>
    6a14:	e8 e7 cc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6a19:	e8 42 ca ff ff       	call   3460 <__stack_chk_fail@plt>
    6a1e:	66 90                	xchg   %ax,%ax

0000000000006a20 <fwp_closure_drop>:
    6a20:	48 8b 15 11 a1 01 00 	mov    0x1a111(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    6a27:	48 89 f8             	mov    %rdi,%rax
    6a2a:	48 2b 05 df a0 01 00 	sub    0x1a0df(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    6a31:	48 c1 e2 10          	shl    $0x10,%rdx
    6a35:	48 39 d0             	cmp    %rdx,%rax
    6a38:	73 6b                	jae    6aa5 <fwp_closure_drop+0x85>
    6a3a:	48 89 c2             	mov    %rax,%rdx
    6a3d:	48 c1 ea 10          	shr    $0x10,%rdx
    6a41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a45:	48 8b 15 0c a1 01 00 	mov    0x1a10c(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    6a4c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a50:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a54:	48 85 d2             	test   %rdx,%rdx
    6a57:	74 4c                	je     6aa5 <fwp_closure_drop+0x85>
    6a59:	0f b6 31             	movzbl (%rcx),%esi
    6a5c:	40 80 fe 02          	cmp    $0x2,%sil
    6a60:	74 3e                	je     6aa0 <fwp_closure_drop+0x80>
    6a62:	40 80 fe 01          	cmp    $0x1,%sil
    6a66:	75 3d                	jne    6aa5 <fwp_closure_drop+0x85>
    6a68:	8b 71 18             	mov    0x18(%rcx),%esi
    6a6b:	0f b7 c0             	movzwl %ax,%eax
    6a6e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a71:	48 0f af c6          	imul   %rsi,%rax
    6a75:	48 c1 e8 20          	shr    $0x20,%rax
    6a79:	48 39 c8             	cmp    %rcx,%rax
    6a7c:	73 27                	jae    6aa5 <fwp_closure_drop+0x85>
    6a7e:	48 01 c2             	add    %rax,%rdx
    6a81:	0f b6 02             	movzbl (%rdx),%eax
    6a84:	84 c0                	test   %al,%al
    6a86:	74 1d                	je     6aa5 <fwp_closure_drop+0x85>
    6a88:	3c 01                	cmp    $0x1,%al
    6a8a:	74 24                	je     6ab0 <fwp_closure_drop+0x90>
    6a8c:	3c ff                	cmp    $0xff,%al
    6a8e:	74 48                	je     6ad8 <fwp_closure_drop+0xb8>
    6a90:	83 e8 01             	sub    $0x1,%eax
    6a93:	88 02                	mov    %al,(%rdx)
    6a95:	c3                   	ret
    6a96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a9d:	00 00 00 
    6aa0:	66 85 c0             	test   %ax,%ax
    6aa3:	74 dc                	je     6a81 <fwp_closure_drop+0x61>
    6aa5:	c3                   	ret
    6aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6aad:	00 00 00 
    6ab0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6ab7:	ff ff 
    6ab9:	48 85 c0             	test   %rax,%rax
    6abc:	74 12                	je     6ad0 <fwp_closure_drop+0xb0>
    6abe:	48 89 fe             	mov    %rdi,%rsi
    6ac1:	48 89 c7             	mov    %rax,%rdi
    6ac4:	e9 37 d7 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6ac9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ad0:	e9 db d8 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6ad5:	0f 1f 00             	nopl   (%rax)
    6ad8:	48 89 d0             	mov    %rdx,%rax
    6adb:	48 8d 35 7e 8c 01 00 	lea    0x18c7e(%rip),%rsi        # 1f760 <fwp_heap>
    6ae2:	48 83 ec 18          	sub    $0x18,%rsp
    6ae6:	48 c1 e8 11          	shr    $0x11,%rax
    6aea:	48 31 d0             	xor    %rdx,%rax
    6aed:	48 89 c1             	mov    %rax,%rcx
    6af0:	48 c1 e9 09          	shr    $0x9,%rcx
    6af4:	48 31 c8             	xor    %rcx,%rax
    6af7:	0f b6 c8             	movzbl %al,%ecx
    6afa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6b01:	00 
    6b02:	48 85 c0             	test   %rax,%rax
    6b05:	75 22                	jne    6b29 <fwp_closure_drop+0x109>
    6b07:	eb 59                	jmp    6b62 <fwp_closure_drop+0x142>
    6b09:	90                   	nop
    6b0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b11:	00 00 00 00 
    6b15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b1c:	00 00 00 00 
    6b20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b24:	48 85 c0             	test   %rax,%rax
    6b27:	74 39                	je     6b62 <fwp_closure_drop+0x142>
    6b29:	48 89 c1             	mov    %rax,%rcx
    6b2c:	48 39 10             	cmp    %rdx,(%rax)
    6b2f:	75 ef                	jne    6b20 <fwp_closure_drop+0x100>
    6b31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6b44:	74 05                	je     6b4b <fwp_closure_drop+0x12b>
    6b46:	48 83 c4 18          	add    $0x18,%rsp
    6b4a:	c3                   	ret
    6b4b:	48 89 d7             	mov    %rdx,%rdi
    6b4e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6b53:	e8 b8 e7 ff ff       	call   5310 <fwp_rc_forget_slot>
    6b58:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6b5d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6b60:	eb e4                	jmp    6b46 <fwp_closure_drop+0x126>
    6b62:	48 8d 3d 0f 4c 00 00 	lea    0x4c0f(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    6b69:	e8 32 d6 ff ff       	call   41a0 <fwp_trap>
    6b6e:	66 90                	xchg   %ax,%ax

0000000000006b70 <fwp_owned_tape_release>:
    6b70:	48 85 ff             	test   %rdi,%rdi
    6b73:	0f 84 f7 00 00 00    	je     6c70 <fwp_owned_tape_release+0x100>
    6b79:	41 54                	push   %r12
    6b7b:	55                   	push   %rbp
    6b7c:	53                   	push   %rbx
    6b7d:	48 8b 07             	mov    (%rdi),%rax
    6b80:	48 85 c0             	test   %rax,%rax
    6b83:	74 08                	je     6b8d <fwp_owned_tape_release+0x1d>
    6b85:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6b89:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6b8d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6b91:	48 85 d2             	test   %rdx,%rdx
    6b94:	74 03                	je     6b99 <fwp_owned_tape_release+0x29>
    6b96:	48 89 02             	mov    %rax,(%rdx)
    6b99:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6b9d:	48 89 fb             	mov    %rdi,%rbx
    6ba0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6ba4:	48 85 c0             	test   %rax,%rax
    6ba7:	0f 84 89 00 00 00    	je     6c36 <fwp_owned_tape_release+0xc6>
    6bad:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6bb1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6bb5:	7e 47                	jle    6bfe <fwp_owned_tape_release+0x8e>
    6bb7:	31 ed                	xor    %ebp,%ebp
    6bb9:	eb 0d                	jmp    6bc8 <fwp_owned_tape_release+0x58>
    6bbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6bc0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6bc4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6bc8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6bcc:	49 89 ec             	mov    %rbp,%r12
    6bcf:	48 83 c5 01          	add    $0x1,%rbp
    6bd3:	49 c1 e4 04          	shl    $0x4,%r12
    6bd7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6bdb:	ff d0                	call   *%rax
    6bdd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6be1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6be6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6bea:	ff 50 68             	call   *0x68(%rax)
    6bed:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6bf1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6bf5:	48 39 e8             	cmp    %rbp,%rax
    6bf8:	7f c6                	jg     6bc0 <fwp_owned_tape_release+0x50>
    6bfa:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6bfe:	31 ed                	xor    %ebp,%ebp
    6c00:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6c05:	7e 28                	jle    6c2f <fwp_owned_tape_release+0xbf>
    6c07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c0e:	00 00 
    6c10:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6c14:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6c18:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6c1c:	74 07                	je     6c25 <fwp_owned_tape_release+0xb5>
    6c1e:	ff 52 68             	call   *0x68(%rdx)
    6c21:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6c25:	48 83 c5 01          	add    $0x1,%rbp
    6c29:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6c2d:	7f e1                	jg     6c10 <fwp_owned_tape_release+0xa0>
    6c2f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6c33:	ff 52 68             	call   *0x68(%rdx)
    6c36:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6c3a:	e8 e1 fd ff ff       	call   6a20 <fwp_closure_drop>
    6c3f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6c43:	e8 d8 fd ff ff       	call   6a20 <fwp_closure_drop>
    6c48:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6c4c:	e8 cf fd ff ff       	call   6a20 <fwp_closure_drop>
    6c51:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6c55:	e8 f6 e8 ff ff       	call   5550 <fwp_mem_free>
    6c5a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6c5e:	e8 ed e8 ff ff       	call   5550 <fwp_mem_free>
    6c63:	48 89 df             	mov    %rbx,%rdi
    6c66:	5b                   	pop    %rbx
    6c67:	5d                   	pop    %rbp
    6c68:	41 5c                	pop    %r12
    6c6a:	e9 e1 e8 ff ff       	jmp    5550 <fwp_mem_free>
    6c6f:	90                   	nop
    6c70:	c3                   	ret
    6c71:	0f 1f 40 00          	nopl   0x0(%rax)
    6c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c7c:	00 00 00 00 

0000000000006c80 <fwp_tape_finish>:
    6c80:	f3 0f 1e fa          	endbr64
    6c84:	41 56                	push   %r14
    6c86:	48 8d 3d 13 84 01 00 	lea    0x18413(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    6c8d:	41 55                	push   %r13
    6c8f:	41 54                	push   %r12
    6c91:	55                   	push   %rbp
    6c92:	53                   	push   %rbx
    6c93:	e8 d8 d2 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6c98:	48 83 3d 48 84 01 00 	cmpq   $0x0,0x18448(%rip)        # 1f0e8 <fwp_ntapes>
    6c9f:	00 
    6ca0:	48 c7 05 dd 83 01 00 	movq   $0x0,0x183dd(%rip)        # 1f088 <fwp_tape_cached_bytes>
    6ca7:	00 00 00 00 
    6cab:	7e 68                	jle    6d15 <fwp_tape_finish+0x95>
    6cad:	45 31 e4             	xor    %r12d,%r12d
    6cb0:	31 ed                	xor    %ebp,%ebp
    6cb2:	0f 1f 00             	nopl   (%rax)
    6cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cbc:	00 00 00 00 
    6cc0:	48 8b 1d 29 84 01 00 	mov    0x18429(%rip),%rbx        # 1f0f0 <fwp_tapes>
    6cc7:	48 83 c5 01          	add    $0x1,%rbp
    6ccb:	4c 01 e3             	add    %r12,%rbx
    6cce:	49 83 c4 68          	add    $0x68,%r12
    6cd2:	48 89 df             	mov    %rbx,%rdi
    6cd5:	e8 26 cf ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6cda:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6cde:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6ce2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6ce6:	e8 d5 c6 ff ff       	call   33c0 <free@plt>
    6ceb:	4c 89 f7             	mov    %r14,%rdi
    6cee:	e8 cd c6 ff ff       	call   33c0 <free@plt>
    6cf3:	4c 89 ef             	mov    %r13,%rdi
    6cf6:	e8 c5 c6 ff ff       	call   33c0 <free@plt>
    6cfb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6cff:	e8 6c fe ff ff       	call   6b70 <fwp_owned_tape_release>
    6d04:	48 39 2d dd 83 01 00 	cmp    %rbp,0x183dd(%rip)        # 1f0e8 <fwp_ntapes>
    6d0b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6d12:	00 
    6d13:	7f ab                	jg     6cc0 <fwp_tape_finish+0x40>
    6d15:	48 8b 3d d4 83 01 00 	mov    0x183d4(%rip),%rdi        # 1f0f0 <fwp_tapes>
    6d1c:	e8 9f c6 ff ff       	call   33c0 <free@plt>
    6d21:	5b                   	pop    %rbx
    6d22:	5d                   	pop    %rbp
    6d23:	48 c7 05 c2 83 01 00 	movq   $0x0,0x183c2(%rip)        # 1f0f0 <fwp_tapes>
    6d2a:	00 00 00 00 
    6d2e:	48 c7 05 a7 83 01 00 	movq   $0x0,0x183a7(%rip)        # 1f0e0 <fwp_tapes_cap>
    6d35:	00 00 00 00 
    6d39:	41 5c                	pop    %r12
    6d3b:	48 c7 05 a2 83 01 00 	movq   $0x0,0x183a2(%rip)        # 1f0e8 <fwp_ntapes>
    6d42:	00 00 00 00 
    6d46:	41 5d                	pop    %r13
    6d48:	48 c7 05 85 83 01 00 	movq   $0x0,0x18385(%rip)        # 1f0d8 <fwp_tape_next_slot>
    6d4f:	00 00 00 00 
    6d53:	41 5e                	pop    %r14
    6d55:	c3                   	ret
    6d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d5d:	00 00 00 

0000000000006d60 <fwp_tape_scope_release>:
    6d60:	f3 0f 1e fa          	endbr64
    6d64:	41 55                	push   %r13
    6d66:	41 54                	push   %r12
    6d68:	55                   	push   %rbp
    6d69:	53                   	push   %rbx
    6d6a:	48 83 ec 58          	sub    $0x58,%rsp
    6d6e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6d75:	00 00 
    6d77:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6d7c:	48 63 07             	movslq (%rdi),%rax
    6d7f:	85 c0                	test   %eax,%eax
    6d81:	0f 88 05 01 00 00    	js     6e8c <fwp_tape_scope_release+0x12c>
    6d87:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6d8e:	ec c4 4e 
    6d91:	48 89 fb             	mov    %rdi,%rbx
    6d94:	eb 3c                	jmp    6dd2 <fwp_tape_scope_release+0x72>
    6d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d9d:	00 00 00 
    6da0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6da5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6da9:	e8 12 c6 ff ff       	call   33c0 <free@plt>
    6dae:	48 8b 3c 24          	mov    (%rsp),%rdi
    6db2:	e8 09 c6 ff ff       	call   33c0 <free@plt>
    6db7:	4c 89 ef             	mov    %r13,%rdi
    6dba:	e8 01 c6 ff ff       	call   33c0 <free@plt>
    6dbf:	4c 89 e7             	mov    %r12,%rdi
    6dc2:	e8 a9 fd ff ff       	call   6b70 <fwp_owned_tape_release>
    6dc7:	48 63 03             	movslq (%rbx),%rax
    6dca:	85 c0                	test   %eax,%eax
    6dcc:	0f 88 ba 00 00 00    	js     6e8c <fwp_tape_scope_release+0x12c>
    6dd2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6dd6:	48 8b 35 13 83 01 00 	mov    0x18313(%rip),%rsi        # 1f0f0 <fwp_tapes>
    6ddd:	4c 01 c6             	add    %r8,%rsi
    6de0:	48 89 f7             	mov    %rsi,%rdi
    6de3:	e8 18 ce ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6de8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6ded:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6df2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6df9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6dfd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6e01:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6e08:	00 
    6e09:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6e0e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6e12:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6e17:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6e1b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6e20:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6e27:	00 
    6e28:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6e2f:	00 
    6e30:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6e37:	00 
    6e38:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6e3d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6e42:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6e46:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6e4a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6e4e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6e54:	77 18                	ja     6e6e <fwp_tape_scope_release+0x10e>
    6e56:	49 c1 f8 03          	sar    $0x3,%r8
    6e5a:	4c 0f af c5          	imul   %rbp,%r8
    6e5e:	4c 3b 05 73 82 01 00 	cmp    0x18273(%rip),%r8        # 1f0d8 <fwp_tape_next_slot>
    6e65:	7d 07                	jge    6e6e <fwp_tape_scope_release+0x10e>
    6e67:	4c 89 05 6a 82 01 00 	mov    %r8,0x1826a(%rip)        # 1f0d8 <fwp_tape_next_slot>
    6e6e:	4d 85 e4             	test   %r12,%r12
    6e71:	0f 85 29 ff ff ff    	jne    6da0 <fwp_tape_scope_release+0x40>
    6e77:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6e7c:	e8 af df ff ff       	call   4e30 <fwp_tape_buffers_release>
    6e81:	48 63 03             	movslq (%rbx),%rax
    6e84:	85 c0                	test   %eax,%eax
    6e86:	0f 89 46 ff ff ff    	jns    6dd2 <fwp_tape_scope_release+0x72>
    6e8c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6e91:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e98:	00 00 
    6e9a:	75 0b                	jne    6ea7 <fwp_tape_scope_release+0x147>
    6e9c:	48 83 c4 58          	add    $0x58,%rsp
    6ea0:	5b                   	pop    %rbx
    6ea1:	5d                   	pop    %rbp
    6ea2:	41 5c                	pop    %r12
    6ea4:	41 5d                	pop    %r13
    6ea6:	c3                   	ret
    6ea7:	e8 b4 c5 ff ff       	call   3460 <__stack_chk_fail@plt>
    6eac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006eb0 <fwp_drop4>:
    6eb0:	48 8b 0d 81 9c 01 00 	mov    0x19c81(%rip),%rcx        # 20b38 <fwp_heap+0x13d8>
    6eb7:	48 89 f8             	mov    %rdi,%rax
    6eba:	48 2b 05 4f 9c 01 00 	sub    0x19c4f(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    6ec1:	48 c1 e1 10          	shl    $0x10,%rcx
    6ec5:	48 39 c8             	cmp    %rcx,%rax
    6ec8:	0f 83 42 01 00 00    	jae    7010 <fwp_drop4+0x160>
    6ece:	48 83 ec 18          	sub    $0x18,%rsp
    6ed2:	48 89 fa             	mov    %rdi,%rdx
    6ed5:	4c 8d 05 84 88 01 00 	lea    0x18884(%rip),%r8        # 1f760 <fwp_heap>
    6edc:	48 89 c1             	mov    %rax,%rcx
    6edf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6ee6:	48 c1 e9 10          	shr    $0x10,%rcx
    6eea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6eee:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6ef2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6ef6:	48 85 c9             	test   %rcx,%rcx
    6ef9:	74 40                	je     6f3b <fwp_drop4+0x8b>
    6efb:	0f b6 3e             	movzbl (%rsi),%edi
    6efe:	40 80 ff 02          	cmp    $0x2,%dil
    6f02:	74 3c                	je     6f40 <fwp_drop4+0x90>
    6f04:	40 80 ff 01          	cmp    $0x1,%dil
    6f08:	75 31                	jne    6f3b <fwp_drop4+0x8b>
    6f0a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6f0d:	0f b7 c0             	movzwl %ax,%eax
    6f10:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6f13:	48 0f af c7          	imul   %rdi,%rax
    6f17:	48 c1 e8 20          	shr    $0x20,%rax
    6f1b:	48 39 f0             	cmp    %rsi,%rax
    6f1e:	73 1b                	jae    6f3b <fwp_drop4+0x8b>
    6f20:	48 01 c1             	add    %rax,%rcx
    6f23:	0f b6 01             	movzbl (%rcx),%eax
    6f26:	84 c0                	test   %al,%al
    6f28:	74 11                	je     6f3b <fwp_drop4+0x8b>
    6f2a:	3c 01                	cmp    $0x1,%al
    6f2c:	74 22                	je     6f50 <fwp_drop4+0xa0>
    6f2e:	3c ff                	cmp    $0xff,%al
    6f30:	0f 84 0a 01 00 00    	je     7040 <fwp_drop4+0x190>
    6f36:	83 e8 01             	sub    $0x1,%eax
    6f39:	88 01                	mov    %al,(%rcx)
    6f3b:	48 83 c4 18          	add    $0x18,%rsp
    6f3f:	c3                   	ret
    6f40:	66 85 c0             	test   %ax,%ax
    6f43:	74 de                	je     6f23 <fwp_drop4+0x73>
    6f45:	48 83 c4 18          	add    $0x18,%rsp
    6f49:	c3                   	ret
    6f4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f50:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6f54:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6f5b:	48 89 f8             	mov    %rdi,%rax
    6f5e:	48 c1 e1 10          	shl    $0x10,%rcx
    6f62:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6f69:	48 39 c8             	cmp    %rcx,%rax
    6f6c:	73 62                	jae    6fd0 <fwp_drop4+0x120>
    6f6e:	48 89 c1             	mov    %rax,%rcx
    6f71:	48 c1 e9 10          	shr    $0x10,%rcx
    6f75:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6f79:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6f7d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6f81:	48 85 c9             	test   %rcx,%rcx
    6f84:	74 4a                	je     6fd0 <fwp_drop4+0x120>
    6f86:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6f8a:	41 80 f9 02          	cmp    $0x2,%r9b
    6f8e:	0f 84 9c 00 00 00    	je     7030 <fwp_drop4+0x180>
    6f94:	41 80 f9 01          	cmp    $0x1,%r9b
    6f98:	75 36                	jne    6fd0 <fwp_drop4+0x120>
    6f9a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6f9e:	0f b7 c0             	movzwl %ax,%eax
    6fa1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6fa4:	49 0f af c1          	imul   %r9,%rax
    6fa8:	48 c1 e8 20          	shr    $0x20,%rax
    6fac:	48 39 f0             	cmp    %rsi,%rax
    6faf:	73 1f                	jae    6fd0 <fwp_drop4+0x120>
    6fb1:	48 01 c1             	add    %rax,%rcx
    6fb4:	0f b6 01             	movzbl (%rcx),%eax
    6fb7:	84 c0                	test   %al,%al
    6fb9:	74 15                	je     6fd0 <fwp_drop4+0x120>
    6fbb:	3c 01                	cmp    $0x1,%al
    6fbd:	74 59                	je     7018 <fwp_drop4+0x168>
    6fbf:	3c ff                	cmp    $0xff,%al
    6fc1:	0f 84 ff 00 00 00    	je     70c6 <fwp_drop4+0x216>
    6fc7:	83 e8 01             	sub    $0x1,%eax
    6fca:	88 01                	mov    %al,(%rcx)
    6fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    6fd0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6fd4:	48 89 d7             	mov    %rdx,%rdi
    6fd7:	48 89 0c 24          	mov    %rcx,(%rsp)
    6fdb:	e8 30 f7 ff ff       	call   6710 <fwp_rc_free_obj>
    6fe0:	4c 8d 05 79 87 01 00 	lea    0x18779(%rip),%r8        # 1f760 <fwp_heap>
    6fe7:	48 8b 04 24          	mov    (%rsp),%rax
    6feb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6ff2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ff9:	48 c1 e2 10          	shl    $0x10,%rdx
    6ffd:	48 39 d0             	cmp    %rdx,%rax
    7000:	0f 83 35 ff ff ff    	jae    6f3b <fwp_drop4+0x8b>
    7006:	48 8b 14 24          	mov    (%rsp),%rdx
    700a:	e9 cd fe ff ff       	jmp    6edc <fwp_drop4+0x2c>
    700f:	90                   	nop
    7010:	c3                   	ret
    7011:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7018:	48 89 14 24          	mov    %rdx,(%rsp)
    701c:	e8 ef f6 ff ff       	call   6710 <fwp_rc_free_obj>
    7021:	48 8b 14 24          	mov    (%rsp),%rdx
    7025:	eb a9                	jmp    6fd0 <fwp_drop4+0x120>
    7027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    702e:	00 00 
    7030:	66 85 c0             	test   %ax,%ax
    7033:	75 9b                	jne    6fd0 <fwp_drop4+0x120>
    7035:	e9 7a ff ff ff       	jmp    6fb4 <fwp_drop4+0x104>
    703a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7040:	48 89 c8             	mov    %rcx,%rax
    7043:	48 c1 e8 11          	shr    $0x11,%rax
    7047:	48 31 c8             	xor    %rcx,%rax
    704a:	48 89 c2             	mov    %rax,%rdx
    704d:	48 c1 ea 09          	shr    $0x9,%rdx
    7051:	48 31 d0             	xor    %rdx,%rax
    7054:	0f b6 d0             	movzbl %al,%edx
    7057:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    705e:	00 
    705f:	48 85 c0             	test   %rax,%rax
    7062:	75 29                	jne    708d <fwp_drop4+0x1dd>
    7064:	e9 e3 00 00 00       	jmp    714c <fwp_drop4+0x29c>
    7069:	90                   	nop
    706a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7071:	00 00 00 00 
    7075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    707c:	00 00 00 00 
    7080:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7084:	48 85 c0             	test   %rax,%rax
    7087:	0f 84 bf 00 00 00    	je     714c <fwp_drop4+0x29c>
    708d:	48 89 c2             	mov    %rax,%rdx
    7090:	48 39 08             	cmp    %rcx,(%rax)
    7093:	75 eb                	jne    7080 <fwp_drop4+0x1d0>
    7095:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7099:	48 83 ea 01          	sub    $0x1,%rdx
    709d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    70a1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    70a8:	0f 85 8d fe ff ff    	jne    6f3b <fwp_drop4+0x8b>
    70ae:	48 89 cf             	mov    %rcx,%rdi
    70b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    70b5:	e8 56 e2 ff ff       	call   5310 <fwp_rc_forget_slot>
    70ba:	48 8b 0c 24          	mov    (%rsp),%rcx
    70be:	c6 01 fe             	movb   $0xfe,(%rcx)
    70c1:	e9 75 fe ff ff       	jmp    6f3b <fwp_drop4+0x8b>
    70c6:	48 89 ce             	mov    %rcx,%rsi
    70c9:	48 c1 ee 11          	shr    $0x11,%rsi
    70cd:	48 31 ce             	xor    %rcx,%rsi
    70d0:	48 89 f0             	mov    %rsi,%rax
    70d3:	48 c1 e8 09          	shr    $0x9,%rax
    70d7:	48 31 c6             	xor    %rax,%rsi
    70da:	40 0f b6 f6          	movzbl %sil,%esi
    70de:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    70e5:	00 
    70e6:	48 85 c0             	test   %rax,%rax
    70e9:	75 1e                	jne    7109 <fwp_drop4+0x259>
    70eb:	eb 5f                	jmp    714c <fwp_drop4+0x29c>
    70ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    70f4:	00 
    70f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70fc:	00 00 00 00 
    7100:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7104:	48 85 c0             	test   %rax,%rax
    7107:	74 43                	je     714c <fwp_drop4+0x29c>
    7109:	48 89 c6             	mov    %rax,%rsi
    710c:	48 39 08             	cmp    %rcx,(%rax)
    710f:	75 ef                	jne    7100 <fwp_drop4+0x250>
    7111:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7115:	48 83 ee 01          	sub    $0x1,%rsi
    7119:	48 89 70 08          	mov    %rsi,0x8(%rax)
    711d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7124:	0f 85 a6 fe ff ff    	jne    6fd0 <fwp_drop4+0x120>
    712a:	48 89 cf             	mov    %rcx,%rdi
    712d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7132:	48 89 0c 24          	mov    %rcx,(%rsp)
    7136:	e8 d5 e1 ff ff       	call   5310 <fwp_rc_forget_slot>
    713b:	48 8b 0c 24          	mov    (%rsp),%rcx
    713f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7144:	c6 01 fe             	movb   $0xfe,(%rcx)
    7147:	e9 84 fe ff ff       	jmp    6fd0 <fwp_drop4+0x120>
    714c:	48 8d 3d 25 46 00 00 	lea    0x4625(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    7153:	e8 48 d0 ff ff       	call   41a0 <fwp_trap>
    7158:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    715f:	00 

0000000000007160 <fwp_arg_drop37>:
    7160:	f3 0f 1e fa          	endbr64
    7164:	85 f6                	test   %esi,%esi
    7166:	75 04                	jne    716c <fwp_arg_drop37+0xc>
    7168:	85 d2                	test   %edx,%edx
    716a:	75 04                	jne    7170 <fwp_arg_drop37+0x10>
    716c:	c3                   	ret
    716d:	0f 1f 00             	nopl   (%rax)
    7170:	48 8b 3f             	mov    (%rdi),%rdi
    7173:	e9 38 fd ff ff       	jmp    6eb0 <fwp_drop4>
    7178:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    717f:	00 

0000000000007180 <fwp_task_dispose>:
    7180:	53                   	push   %rbx
    7181:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7185:	0f 84 bb c5 ff ff    	je     3746 <fwp_task_dispose.cold>
    718b:	48 89 fb             	mov    %rdi,%rbx
    718e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7193:	0f 85 ad c5 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7199:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    719d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    71a4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    71ab:	00 
    71ac:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    71b0:	48 85 ff             	test   %rdi,%rdi
    71b3:	74 07                	je     71bc <fwp_task_dispose+0x3c>
    71b5:	48 85 c0             	test   %rax,%rax
    71b8:	74 02                	je     71bc <fwp_task_dispose+0x3c>
    71ba:	ff d0                	call   *%rax
    71bc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    71c3:	e8 88 e3 ff ff       	call   5550 <fwp_mem_free>
    71c8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    71cf:	00 00 00 00 
    71d3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    71d7:	74 6f                	je     7248 <fwp_task_dispose+0xc8>
    71d9:	48 8b 15 58 99 01 00 	mov    0x19958(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    71e0:	48 89 d8             	mov    %rbx,%rax
    71e3:	48 2b 05 26 99 01 00 	sub    0x19926(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    71ea:	48 c1 e2 10          	shl    $0x10,%rdx
    71ee:	48 39 d0             	cmp    %rdx,%rax
    71f1:	73 4c                	jae    723f <fwp_task_dispose+0xbf>
    71f3:	48 89 c2             	mov    %rax,%rdx
    71f6:	48 c1 ea 10          	shr    $0x10,%rdx
    71fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    71fe:	48 8b 15 53 99 01 00 	mov    0x19953(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    7205:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7209:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    720d:	48 85 c9             	test   %rcx,%rcx
    7210:	74 2d                	je     723f <fwp_task_dispose+0xbf>
    7212:	0f b6 32             	movzbl (%rdx),%esi
    7215:	40 80 fe 02          	cmp    $0x2,%sil
    7219:	74 3d                	je     7258 <fwp_task_dispose+0xd8>
    721b:	40 80 fe 01          	cmp    $0x1,%sil
    721f:	75 1e                	jne    723f <fwp_task_dispose+0xbf>
    7221:	8b 72 18             	mov    0x18(%rdx),%esi
    7224:	0f b7 c0             	movzwl %ax,%eax
    7227:	8b 52 1c             	mov    0x1c(%rdx),%edx
    722a:	48 0f af c6          	imul   %rsi,%rax
    722e:	48 c1 e8 20          	shr    $0x20,%rax
    7232:	48 39 d0             	cmp    %rdx,%rax
    7235:	73 08                	jae    723f <fwp_task_dispose+0xbf>
    7237:	48 01 c1             	add    %rax,%rcx
    723a:	80 39 01             	cmpb   $0x1,(%rcx)
    723d:	74 09                	je     7248 <fwp_task_dispose+0xc8>
    723f:	5b                   	pop    %rbx
    7240:	c3                   	ret
    7241:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7248:	48 89 df             	mov    %rbx,%rdi
    724b:	5b                   	pop    %rbx
    724c:	e9 ff e2 ff ff       	jmp    5550 <fwp_mem_free>
    7251:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7258:	66 85 c0             	test   %ax,%ax
    725b:	74 dd                	je     723a <fwp_task_dispose+0xba>
    725d:	5b                   	pop    %rbx
    725e:	c3                   	ret
    725f:	90                   	nop

0000000000007260 <fwp_free_zombie>:
    7260:	48 8b 15 c9 84 01 00 	mov    0x184c9(%rip),%rdx        # 1f730 <fwp_zombie>
    7267:	48 85 d2             	test   %rdx,%rdx
    726a:	0f 84 98 00 00 00    	je     7308 <fwp_free_zombie+0xa8>
    7270:	48 3b 15 c9 84 01 00 	cmp    0x184c9(%rip),%rdx        # 1f740 <fwp_cur>
    7277:	0f 84 8b 00 00 00    	je     7308 <fwp_free_zombie+0xa8>
    727d:	48 83 ec 18          	sub    $0x18,%rsp
    7281:	48 63 05 84 7e 01 00 	movslq 0x17e84(%rip),%rax        # 1f10c <fwp_stack_pool_n>
    7288:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    728c:	83 f8 3f             	cmp    $0x3f,%eax
    728f:	7f 7f                	jg     7310 <fwp_free_zombie+0xb0>
    7291:	8d 48 01             	lea    0x1(%rax),%ecx
    7294:	89 0d 72 7e 01 00    	mov    %ecx,0x17e72(%rip)        # 1f10c <fwp_stack_pool_n>
    729a:	48 8d 0d 7f 7e 01 00 	lea    0x17e7f(%rip),%rcx        # 1f120 <fwp_stack_pool>
    72a1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    72a5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    72ac:	66 0f ef c0          	pxor   %xmm0,%xmm0
    72b0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    72b7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    72bb:	48 85 c9             	test   %rcx,%rcx
    72be:	0f 84 fc 00 00 00    	je     73c0 <fwp_free_zombie+0x160>
    72c4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    72cb:	48 85 c0             	test   %rax,%rax
    72ce:	74 07                	je     72d7 <fwp_free_zombie+0x77>
    72d0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    72d7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    72da:	66 0f ef c0          	pxor   %xmm0,%xmm0
    72de:	48 c7 05 47 84 01 00 	movq   $0x0,0x18447(%rip)        # 1f730 <fwp_zombie>
    72e5:	00 00 00 00 
    72e9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    72f0:	85 c0                	test   %eax,%eax
    72f2:	74 34                	je     7328 <fwp_free_zombie+0xc8>
    72f4:	83 f8 01             	cmp    $0x1,%eax
    72f7:	0f 84 b3 00 00 00    	je     73b0 <fwp_free_zombie+0x150>
    72fd:	48 83 c4 18          	add    $0x18,%rsp
    7301:	c3                   	ret
    7302:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7308:	c3                   	ret
    7309:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7310:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7314:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7319:	e8 c2 c2 ff ff       	call   35e0 <munmap@plt>
    731e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7323:	eb 80                	jmp    72a5 <fwp_free_zombie+0x45>
    7325:	0f 1f 00             	nopl   (%rax)
    7328:	48 8b 0d 09 98 01 00 	mov    0x19809(%rip),%rcx        # 20b38 <fwp_heap+0x13d8>
    732f:	48 89 d0             	mov    %rdx,%rax
    7332:	48 2b 05 d7 97 01 00 	sub    0x197d7(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    7339:	48 c1 e1 10          	shl    $0x10,%rcx
    733d:	48 39 c8             	cmp    %rcx,%rax
    7340:	73 bb                	jae    72fd <fwp_free_zombie+0x9d>
    7342:	48 89 c1             	mov    %rax,%rcx
    7345:	48 c1 e9 10          	shr    $0x10,%rcx
    7349:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    734d:	48 8b 0d 04 98 01 00 	mov    0x19804(%rip),%rcx        # 20b58 <fwp_heap+0x13f8>
    7354:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7358:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    735c:	48 85 c9             	test   %rcx,%rcx
    735f:	74 9c                	je     72fd <fwp_free_zombie+0x9d>
    7361:	0f b6 3e             	movzbl (%rsi),%edi
    7364:	40 80 ff 02          	cmp    $0x2,%dil
    7368:	74 66                	je     73d0 <fwp_free_zombie+0x170>
    736a:	40 80 ff 01          	cmp    $0x1,%dil
    736e:	75 8d                	jne    72fd <fwp_free_zombie+0x9d>
    7370:	8b 7e 18             	mov    0x18(%rsi),%edi
    7373:	0f b7 c0             	movzwl %ax,%eax
    7376:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7379:	48 0f af c7          	imul   %rdi,%rax
    737d:	48 c1 e8 20          	shr    $0x20,%rax
    7381:	48 39 f0             	cmp    %rsi,%rax
    7384:	0f 83 73 ff ff ff    	jae    72fd <fwp_free_zombie+0x9d>
    738a:	48 01 c1             	add    %rax,%rcx
    738d:	0f b6 01             	movzbl (%rcx),%eax
    7390:	84 c0                	test   %al,%al
    7392:	0f 84 65 ff ff ff    	je     72fd <fwp_free_zombie+0x9d>
    7398:	3c 01                	cmp    $0x1,%al
    739a:	74 14                	je     73b0 <fwp_free_zombie+0x150>
    739c:	3c ff                	cmp    $0xff,%al
    739e:	74 3b                	je     73db <fwp_free_zombie+0x17b>
    73a0:	83 e8 01             	sub    $0x1,%eax
    73a3:	88 01                	mov    %al,(%rcx)
    73a5:	e9 53 ff ff ff       	jmp    72fd <fwp_free_zombie+0x9d>
    73aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73b0:	48 89 d7             	mov    %rdx,%rdi
    73b3:	48 83 c4 18          	add    $0x18,%rsp
    73b7:	e9 c4 fd ff ff       	jmp    7180 <fwp_task_dispose>
    73bc:	0f 1f 40 00          	nopl   0x0(%rax)
    73c0:	48 89 05 41 83 01 00 	mov    %rax,0x18341(%rip)        # 1f708 <fwp_tasks_active>
    73c7:	e9 ff fe ff ff       	jmp    72cb <fwp_free_zombie+0x6b>
    73cc:	0f 1f 40 00          	nopl   0x0(%rax)
    73d0:	66 85 c0             	test   %ax,%ax
    73d3:	0f 85 24 ff ff ff    	jne    72fd <fwp_free_zombie+0x9d>
    73d9:	eb b2                	jmp    738d <fwp_free_zombie+0x12d>
    73db:	48 89 ca             	mov    %rcx,%rdx
    73de:	48 8d 35 7b 83 01 00 	lea    0x1837b(%rip),%rsi        # 1f760 <fwp_heap>
    73e5:	48 c1 ea 11          	shr    $0x11,%rdx
    73e9:	48 31 ca             	xor    %rcx,%rdx
    73ec:	48 89 d0             	mov    %rdx,%rax
    73ef:	48 c1 e8 09          	shr    $0x9,%rax
    73f3:	48 31 c2             	xor    %rax,%rdx
    73f6:	0f b6 d2             	movzbl %dl,%edx
    73f9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7400:	00 
    7401:	48 85 c0             	test   %rax,%rax
    7404:	75 23                	jne    7429 <fwp_free_zombie+0x1c9>
    7406:	eb 5c                	jmp    7464 <fwp_free_zombie+0x204>
    7408:	66 90                	xchg   %ax,%ax
    740a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7411:	00 00 00 00 
    7415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    741c:	00 00 00 00 
    7420:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7424:	48 85 c0             	test   %rax,%rax
    7427:	74 3b                	je     7464 <fwp_free_zombie+0x204>
    7429:	48 89 c2             	mov    %rax,%rdx
    742c:	48 39 08             	cmp    %rcx,(%rax)
    742f:	75 ef                	jne    7420 <fwp_free_zombie+0x1c0>
    7431:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7435:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7439:	48 89 50 08          	mov    %rdx,0x8(%rax)
    743d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7444:	0f 85 b3 fe ff ff    	jne    72fd <fwp_free_zombie+0x9d>
    744a:	48 89 cf             	mov    %rcx,%rdi
    744d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7452:	e8 b9 de ff ff       	call   5310 <fwp_rc_forget_slot>
    7457:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    745c:	c6 01 fe             	movb   $0xfe,(%rcx)
    745f:	e9 99 fe ff ff       	jmp    72fd <fwp_free_zombie+0x9d>
    7464:	48 8d 3d 0d 43 00 00 	lea    0x430d(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    746b:	e8 30 cd ff ff       	call   41a0 <fwp_trap>

0000000000007470 <fwp_block>:
    7470:	48 83 ec 08          	sub    $0x8,%rsp
    7474:	48 8b 05 ad 82 01 00 	mov    0x182ad(%rip),%rax        # 1f728 <fwp_ready_head>
    747b:	48 85 c0             	test   %rax,%rax
    747e:	0f 84 1c 01 00 00    	je     75a0 <fwp_block+0x130>
    7484:	90                   	nop
    7485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    748c:	00 00 00 00 
    7490:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7497:	48 89 15 8a 82 01 00 	mov    %rdx,0x1828a(%rip)        # 1f728 <fwp_ready_head>
    749e:	48 85 d2             	test   %rdx,%rdx
    74a1:	0f 84 19 01 00 00    	je     75c0 <fwp_block+0x150>
    74a7:	48 8b 15 92 82 01 00 	mov    0x18292(%rip),%rdx        # 1f740 <fwp_cur>
    74ae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    74b2:	48 39 c2             	cmp    %rax,%rdx
    74b5:	0f 84 d5 00 00 00    	je     7590 <fwp_block+0x120>
    74bb:	48 8b 0d 06 9f 01 00 	mov    0x19f06(%rip),%rcx        # 213c8 <fwp_state_owners>
    74c2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    74c6:	48 89 05 73 82 01 00 	mov    %rax,0x18273(%rip)        # 1f740 <fwp_cur>
    74cd:	f3 0f 7e 05 1b 9f 01 	movq   0x19f1b(%rip),%xmm0        # 213f0 <fwp_foreign_callbacks>
    74d4:	00 
    74d5:	0f 16 05 04 9f 01 00 	movhps 0x19f04(%rip),%xmm0        # 213e0 <fwp_state>
    74dc:	f3 0f 7e 0d 04 9f 01 	movq   0x19f04(%rip),%xmm1        # 213e8 <fwp_handlers>
    74e3:	00 
    74e4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    74eb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    74f2:	0f 16 0d ff 9e 01 00 	movhps 0x19eff(%rip),%xmm1        # 213f8 <fwp_cleanups>
    74f9:	f3 0f 7e 05 d7 9e 01 	movq   0x19ed7(%rip),%xmm0        # 213d8 <fwp_state_len>
    7500:	00 
    7501:	0f 16 05 c8 9e 01 00 	movhps 0x19ec8(%rip),%xmm0        # 213d0 <fwp_state_cap>
    7508:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    750f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7516:	48 8b 70 08          	mov    0x8(%rax),%rsi
    751a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7521:	48 89 0d c0 9e 01 00 	mov    %rcx,0x19ec0(%rip)        # 213e8 <fwp_handlers>
    7528:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    752f:	48 89 0d c2 9e 01 00 	mov    %rcx,0x19ec2(%rip)        # 213f8 <fwp_cleanups>
    7536:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    753d:	48 89 0d ac 9e 01 00 	mov    %rcx,0x19eac(%rip)        # 213f0 <fwp_foreign_callbacks>
    7544:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    754b:	48 89 0d 8e 9e 01 00 	mov    %rcx,0x19e8e(%rip)        # 213e0 <fwp_state>
    7552:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7559:	48 89 0d 78 9e 01 00 	mov    %rcx,0x19e78(%rip)        # 213d8 <fwp_state_len>
    7560:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7567:	48 89 0d 62 9e 01 00 	mov    %rcx,0x19e62(%rip)        # 213d0 <fwp_state_cap>
    756e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7575:	48 89 0d 4c 9e 01 00 	mov    %rcx,0x19e4c(%rip)        # 213c8 <fwp_state_owners>
    757c:	e8 0f bf ff ff       	call   3490 <swapcontext@plt>
    7581:	f3 0f 1e fa          	endbr64
    7585:	e8 d6 fc ff ff       	call   7260 <fwp_free_zombie>
    758a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7590:	8b 05 72 7b 01 00    	mov    0x17b72(%rip),%eax        # 1f108 <fwp_slice>
    7596:	85 c0                	test   %eax,%eax
    7598:	74 36                	je     75d0 <fwp_block+0x160>
    759a:	48 83 c4 08          	add    $0x8,%rsp
    759e:	c3                   	ret
    759f:	90                   	nop
    75a0:	e8 bb d9 ff ff       	call   4f60 <fwp_poll_events>
    75a5:	48 8b 05 7c 81 01 00 	mov    0x1817c(%rip),%rax        # 1f728 <fwp_ready_head>
    75ac:	48 85 c0             	test   %rax,%rax
    75af:	0f 85 db fe ff ff    	jne    7490 <fwp_block+0x20>
    75b5:	eb e9                	jmp    75a0 <fwp_block+0x130>
    75b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75be:	00 00 
    75c0:	48 c7 05 55 81 01 00 	movq   $0x0,0x18155(%rip)        # 1f720 <fwp_ready_tail>
    75c7:	00 00 00 00 
    75cb:	e9 d7 fe ff ff       	jmp    74a7 <fwp_block+0x37>
    75d0:	48 8d 3d 4a 3b 00 00 	lea    0x3b4a(%rip),%rdi        # b121 <_IO_stdin_used+0x121>
    75d7:	e8 c4 bd ff ff       	call   33a0 <getenv@plt>
    75dc:	ba 10 27 00 00       	mov    $0x2710,%edx
    75e1:	48 85 c0             	test   %rax,%rax
    75e4:	74 05                	je     75eb <fwp_block+0x17b>
    75e6:	80 38 00             	cmpb   $0x0,(%rax)
    75e9:	75 0b                	jne    75f6 <fwp_block+0x186>
    75eb:	89 15 17 7b 01 00    	mov    %edx,0x17b17(%rip)        # 1f108 <fwp_slice>
    75f1:	48 83 c4 08          	add    $0x8,%rsp
    75f5:	c3                   	ret
    75f6:	ba 0a 00 00 00       	mov    $0xa,%edx
    75fb:	31 f6                	xor    %esi,%esi
    75fd:	48 89 c7             	mov    %rax,%rdi
    7600:	e8 4b bf ff ff       	call   3550 <strtoll@plt>
    7605:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7609:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7610:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7615:	0f 46 d0             	cmovbe %eax,%edx
    7618:	eb d1                	jmp    75eb <fwp_block+0x17b>
    761a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007620 <fwp_caps173>:
    7620:	f3 0f 1e fa          	endbr64
    7624:	85 f6                	test   %esi,%esi
    7626:	74 08                	je     7630 <fwp_caps173+0x10>
    7628:	c3                   	ret
    7629:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7630:	48 8b 15 01 95 01 00 	mov    0x19501(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    7637:	48 89 f8             	mov    %rdi,%rax
    763a:	48 2b 05 cf 94 01 00 	sub    0x194cf(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    7641:	48 c1 e2 10          	shl    $0x10,%rdx
    7645:	48 39 d0             	cmp    %rdx,%rax
    7648:	73 de                	jae    7628 <fwp_caps173+0x8>
    764a:	48 89 c2             	mov    %rax,%rdx
    764d:	48 c1 ea 10          	shr    $0x10,%rdx
    7651:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7655:	48 8b 15 fc 94 01 00 	mov    0x194fc(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    765c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7660:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7664:	48 85 c9             	test   %rcx,%rcx
    7667:	74 bf                	je     7628 <fwp_caps173+0x8>
    7669:	0f b6 32             	movzbl (%rdx),%esi
    766c:	40 80 fe 02          	cmp    $0x2,%sil
    7670:	74 2e                	je     76a0 <fwp_caps173+0x80>
    7672:	40 80 fe 01          	cmp    $0x1,%sil
    7676:	75 b0                	jne    7628 <fwp_caps173+0x8>
    7678:	8b 72 18             	mov    0x18(%rdx),%esi
    767b:	0f b7 c0             	movzwl %ax,%eax
    767e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7681:	48 0f af c6          	imul   %rsi,%rax
    7685:	48 c1 e8 20          	shr    $0x20,%rax
    7689:	48 39 d0             	cmp    %rdx,%rax
    768c:	73 9a                	jae    7628 <fwp_caps173+0x8>
    768e:	48 01 c1             	add    %rax,%rcx
    7691:	80 39 01             	cmpb   $0x1,(%rcx)
    7694:	75 92                	jne    7628 <fwp_caps173+0x8>
    7696:	e9 b5 de ff ff       	jmp    5550 <fwp_mem_free>
    769b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    76a0:	66 85 c0             	test   %ax,%ax
    76a3:	74 ec                	je     7691 <fwp_caps173+0x71>
    76a5:	c3                   	ret
    76a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    76ad:	00 00 00 

00000000000076b0 <fwp_args37>:
    76b0:	f3 0f 1e fa          	endbr64
    76b4:	85 d2                	test   %edx,%edx
    76b6:	74 04                	je     76bc <fwp_args37+0xc>
    76b8:	85 f6                	test   %esi,%esi
    76ba:	74 04                	je     76c0 <fwp_args37+0x10>
    76bc:	c3                   	ret
    76bd:	0f 1f 00             	nopl   (%rax)
    76c0:	48 8b 15 71 94 01 00 	mov    0x19471(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    76c7:	48 8b 07             	mov    (%rdi),%rax
    76ca:	48 2b 05 3f 94 01 00 	sub    0x1943f(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    76d1:	48 c1 e2 10          	shl    $0x10,%rdx
    76d5:	48 39 d0             	cmp    %rdx,%rax
    76d8:	73 e2                	jae    76bc <fwp_args37+0xc>
    76da:	48 89 c2             	mov    %rax,%rdx
    76dd:	48 c1 ea 10          	shr    $0x10,%rdx
    76e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    76e5:	48 8b 15 6c 94 01 00 	mov    0x1946c(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    76ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    76f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    76f4:	48 85 ff             	test   %rdi,%rdi
    76f7:	74 c3                	je     76bc <fwp_args37+0xc>
    76f9:	0f b6 0a             	movzbl (%rdx),%ecx
    76fc:	80 f9 02             	cmp    $0x2,%cl
    76ff:	74 2f                	je     7730 <fwp_args37+0x80>
    7701:	80 f9 01             	cmp    $0x1,%cl
    7704:	75 b6                	jne    76bc <fwp_args37+0xc>
    7706:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7709:	0f b7 c0             	movzwl %ax,%eax
    770c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    770f:	48 0f af c1          	imul   %rcx,%rax
    7713:	48 c1 e8 20          	shr    $0x20,%rax
    7717:	48 39 d0             	cmp    %rdx,%rax
    771a:	73 a0                	jae    76bc <fwp_args37+0xc>
    771c:	48 01 c7             	add    %rax,%rdi
    771f:	0f b6 07             	movzbl (%rdi),%eax
    7722:	84 c0                	test   %al,%al
    7724:	74 96                	je     76bc <fwp_args37+0xc>
    7726:	3c fd                	cmp    $0xfd,%al
    7728:	77 0c                	ja     7736 <fwp_args37+0x86>
    772a:	83 c0 01             	add    $0x1,%eax
    772d:	88 07                	mov    %al,(%rdi)
    772f:	c3                   	ret
    7730:	66 85 c0             	test   %ax,%ax
    7733:	74 ea                	je     771f <fwp_args37+0x6f>
    7735:	c3                   	ret
    7736:	e9 b5 da ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    773b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007740 <fwp_caps37>:
    7740:	f3 0f 1e fa          	endbr64
    7744:	48 83 ec 18          	sub    $0x18,%rsp
    7748:	8b 57 04             	mov    0x4(%rdi),%edx
    774b:	48 89 f8             	mov    %rdi,%rax
    774e:	85 d2                	test   %edx,%edx
    7750:	0f 84 9a 00 00 00    	je     77f0 <fwp_caps37+0xb0>
    7756:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    775a:	85 f6                	test   %esi,%esi
    775c:	0f 85 9e 00 00 00    	jne    7800 <fwp_caps37+0xc0>
    7762:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7767:	e8 44 f7 ff ff       	call   6eb0 <fwp_drop4>
    776c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7771:	48 8b 0d c0 93 01 00 	mov    0x193c0(%rip),%rcx        # 20b38 <fwp_heap+0x13d8>
    7778:	48 89 c2             	mov    %rax,%rdx
    777b:	48 2b 15 8e 93 01 00 	sub    0x1938e(%rip),%rdx        # 20b10 <fwp_heap+0x13b0>
    7782:	48 c1 e1 10          	shl    $0x10,%rcx
    7786:	48 39 ca             	cmp    %rcx,%rdx
    7789:	73 6d                	jae    77f8 <fwp_caps37+0xb8>
    778b:	48 89 d1             	mov    %rdx,%rcx
    778e:	48 c1 e9 10          	shr    $0x10,%rcx
    7792:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7796:	48 8b 0d bb 93 01 00 	mov    0x193bb(%rip),%rcx        # 20b58 <fwp_heap+0x13f8>
    779d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    77a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    77a5:	48 85 f6             	test   %rsi,%rsi
    77a8:	74 4e                	je     77f8 <fwp_caps37+0xb8>
    77aa:	0f b6 39             	movzbl (%rcx),%edi
    77ad:	40 80 ff 02          	cmp    $0x2,%dil
    77b1:	0f 84 b9 00 00 00    	je     7870 <fwp_caps37+0x130>
    77b7:	40 80 ff 01          	cmp    $0x1,%dil
    77bb:	75 3b                	jne    77f8 <fwp_caps37+0xb8>
    77bd:	8b 79 18             	mov    0x18(%rcx),%edi
    77c0:	0f b7 d2             	movzwl %dx,%edx
    77c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    77c6:	48 0f af d7          	imul   %rdi,%rdx
    77ca:	48 c1 ea 20          	shr    $0x20,%rdx
    77ce:	48 39 ca             	cmp    %rcx,%rdx
    77d1:	73 25                	jae    77f8 <fwp_caps37+0xb8>
    77d3:	48 01 d6             	add    %rdx,%rsi
    77d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    77d9:	75 1d                	jne    77f8 <fwp_caps37+0xb8>
    77db:	48 89 c7             	mov    %rax,%rdi
    77de:	48 83 c4 18          	add    $0x18,%rsp
    77e2:	e9 69 dd ff ff       	jmp    5550 <fwp_mem_free>
    77e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77ee:	00 00 
    77f0:	85 f6                	test   %esi,%esi
    77f2:	0f 84 79 ff ff ff    	je     7771 <fwp_caps37+0x31>
    77f8:	48 83 c4 18          	add    $0x18,%rsp
    77fc:	c3                   	ret
    77fd:	0f 1f 00             	nopl   (%rax)
    7800:	48 8b 05 31 93 01 00 	mov    0x19331(%rip),%rax        # 20b38 <fwp_heap+0x13d8>
    7807:	48 2b 3d 02 93 01 00 	sub    0x19302(%rip),%rdi        # 20b10 <fwp_heap+0x13b0>
    780e:	48 c1 e0 10          	shl    $0x10,%rax
    7812:	48 39 c7             	cmp    %rax,%rdi
    7815:	73 e1                	jae    77f8 <fwp_caps37+0xb8>
    7817:	48 89 f8             	mov    %rdi,%rax
    781a:	48 c1 e8 10          	shr    $0x10,%rax
    781e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7822:	48 8b 05 2f 93 01 00 	mov    0x1932f(%rip),%rax        # 20b58 <fwp_heap+0x13f8>
    7829:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    782d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7831:	48 85 c0             	test   %rax,%rax
    7834:	74 c2                	je     77f8 <fwp_caps37+0xb8>
    7836:	0f b6 0a             	movzbl (%rdx),%ecx
    7839:	80 f9 02             	cmp    $0x2,%cl
    783c:	74 42                	je     7880 <fwp_caps37+0x140>
    783e:	80 f9 01             	cmp    $0x1,%cl
    7841:	75 b5                	jne    77f8 <fwp_caps37+0xb8>
    7843:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7846:	0f b7 ff             	movzwl %di,%edi
    7849:	8b 52 1c             	mov    0x1c(%rdx),%edx
    784c:	48 0f af f9          	imul   %rcx,%rdi
    7850:	48 c1 ef 20          	shr    $0x20,%rdi
    7854:	48 39 d7             	cmp    %rdx,%rdi
    7857:	73 9f                	jae    77f8 <fwp_caps37+0xb8>
    7859:	48 01 f8             	add    %rdi,%rax
    785c:	0f b6 10             	movzbl (%rax),%edx
    785f:	84 d2                	test   %dl,%dl
    7861:	74 95                	je     77f8 <fwp_caps37+0xb8>
    7863:	80 fa fd             	cmp    $0xfd,%dl
    7866:	77 23                	ja     788b <fwp_caps37+0x14b>
    7868:	83 c2 01             	add    $0x1,%edx
    786b:	88 10                	mov    %dl,(%rax)
    786d:	eb 89                	jmp    77f8 <fwp_caps37+0xb8>
    786f:	90                   	nop
    7870:	66 85 d2             	test   %dx,%dx
    7873:	0f 85 7f ff ff ff    	jne    77f8 <fwp_caps37+0xb8>
    7879:	e9 58 ff ff ff       	jmp    77d6 <fwp_caps37+0x96>
    787e:	66 90                	xchg   %ax,%ax
    7880:	66 85 ff             	test   %di,%di
    7883:	0f 85 6f ff ff ff    	jne    77f8 <fwp_caps37+0xb8>
    7889:	eb d1                	jmp    785c <fwp_caps37+0x11c>
    788b:	48 89 c7             	mov    %rax,%rdi
    788e:	48 83 c4 18          	add    $0x18,%rsp
    7892:	e9 59 d9 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7897:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    789e:	00 00 

00000000000078a0 <fwp_drop0>:
    78a0:	f3 0f 1e fa          	endbr64
    78a4:	48 8b 15 8d 92 01 00 	mov    0x1928d(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    78ab:	48 89 f8             	mov    %rdi,%rax
    78ae:	48 2b 05 5b 92 01 00 	sub    0x1925b(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    78b5:	48 c1 e2 10          	shl    $0x10,%rdx
    78b9:	48 39 d0             	cmp    %rdx,%rax
    78bc:	0f 83 36 01 00 00    	jae    79f8 <fwp_drop0+0x158>
    78c2:	48 83 ec 18          	sub    $0x18,%rsp
    78c6:	48 8d 35 93 7e 01 00 	lea    0x17e93(%rip),%rsi        # 1f760 <fwp_heap>
    78cd:	48 89 c2             	mov    %rax,%rdx
    78d0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    78d7:	48 c1 ea 10          	shr    $0x10,%rdx
    78db:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    78df:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    78e3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    78e7:	48 85 d2             	test   %rdx,%rdx
    78ea:	74 42                	je     792e <fwp_drop0+0x8e>
    78ec:	44 0f b6 01          	movzbl (%rcx),%r8d
    78f0:	41 80 f8 02          	cmp    $0x2,%r8b
    78f4:	74 42                	je     7938 <fwp_drop0+0x98>
    78f6:	41 80 f8 01          	cmp    $0x1,%r8b
    78fa:	75 32                	jne    792e <fwp_drop0+0x8e>
    78fc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7900:	0f b7 c0             	movzwl %ax,%eax
    7903:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7906:	49 0f af c0          	imul   %r8,%rax
    790a:	48 c1 e8 20          	shr    $0x20,%rax
    790e:	48 39 c8             	cmp    %rcx,%rax
    7911:	73 1b                	jae    792e <fwp_drop0+0x8e>
    7913:	48 01 c2             	add    %rax,%rdx
    7916:	0f b6 02             	movzbl (%rdx),%eax
    7919:	84 c0                	test   %al,%al
    791b:	74 11                	je     792e <fwp_drop0+0x8e>
    791d:	3c 01                	cmp    $0x1,%al
    791f:	74 27                	je     7948 <fwp_drop0+0xa8>
    7921:	3c ff                	cmp    $0xff,%al
    7923:	0f 84 e7 00 00 00    	je     7a10 <fwp_drop0+0x170>
    7929:	83 e8 01             	sub    $0x1,%eax
    792c:	88 02                	mov    %al,(%rdx)
    792e:	48 83 c4 18          	add    $0x18,%rsp
    7932:	c3                   	ret
    7933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7938:	66 85 c0             	test   %ax,%ax
    793b:	74 d9                	je     7916 <fwp_drop0+0x76>
    793d:	48 83 c4 18          	add    $0x18,%rsp
    7941:	c3                   	ret
    7942:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7948:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    794f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7956:	48 89 f8             	mov    %rdi,%rax
    7959:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    795d:	48 29 c8             	sub    %rcx,%rax
    7960:	48 c1 e2 10          	shl    $0x10,%rdx
    7964:	48 39 d0             	cmp    %rdx,%rax
    7967:	73 71                	jae    79da <fwp_drop0+0x13a>
    7969:	49 89 c2             	mov    %rax,%r10
    796c:	49 c1 ea 10          	shr    $0x10,%r10
    7970:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7974:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7978:	4d 8b 51 20          	mov    0x20(%r9),%r10
    797c:	4d 85 d2             	test   %r10,%r10
    797f:	74 59                	je     79da <fwp_drop0+0x13a>
    7981:	45 0f b6 19          	movzbl (%r9),%r11d
    7985:	41 80 fb 02          	cmp    $0x2,%r11b
    7989:	74 75                	je     7a00 <fwp_drop0+0x160>
    798b:	41 80 fb 01          	cmp    $0x1,%r11b
    798f:	75 49                	jne    79da <fwp_drop0+0x13a>
    7991:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7995:	0f b7 c0             	movzwl %ax,%eax
    7998:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    799c:	49 0f af c3          	imul   %r11,%rax
    79a0:	48 c1 e8 20          	shr    $0x20,%rax
    79a4:	4c 39 c8             	cmp    %r9,%rax
    79a7:	73 31                	jae    79da <fwp_drop0+0x13a>
    79a9:	49 01 c2             	add    %rax,%r10
    79ac:	41 80 3a 01          	cmpb   $0x1,(%r10)
    79b0:	75 28                	jne    79da <fwp_drop0+0x13a>
    79b2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    79b7:	e8 94 db ff ff       	call   5550 <fwp_mem_free>
    79bc:	48 8d 35 9d 7d 01 00 	lea    0x17d9d(%rip),%rsi        # 1f760 <fwp_heap>
    79c3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    79c8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    79cf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    79d6:	48 c1 e2 10          	shl    $0x10,%rdx
    79da:	4c 89 c0             	mov    %r8,%rax
    79dd:	48 29 c8             	sub    %rcx,%rax
    79e0:	48 39 d0             	cmp    %rdx,%rax
    79e3:	0f 83 45 ff ff ff    	jae    792e <fwp_drop0+0x8e>
    79e9:	4c 89 c7             	mov    %r8,%rdi
    79ec:	e9 dc fe ff ff       	jmp    78cd <fwp_drop0+0x2d>
    79f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79f8:	c3                   	ret
    79f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a00:	66 85 c0             	test   %ax,%ax
    7a03:	75 d5                	jne    79da <fwp_drop0+0x13a>
    7a05:	eb a5                	jmp    79ac <fwp_drop0+0x10c>
    7a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a0e:	00 00 
    7a10:	48 89 d0             	mov    %rdx,%rax
    7a13:	48 c1 e8 11          	shr    $0x11,%rax
    7a17:	48 31 d0             	xor    %rdx,%rax
    7a1a:	48 89 c1             	mov    %rax,%rcx
    7a1d:	48 c1 e9 09          	shr    $0x9,%rcx
    7a21:	48 31 c8             	xor    %rcx,%rax
    7a24:	0f b6 c8             	movzbl %al,%ecx
    7a27:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7a2e:	00 
    7a2f:	48 85 c0             	test   %rax,%rax
    7a32:	75 15                	jne    7a49 <fwp_drop0+0x1a9>
    7a34:	eb 4e                	jmp    7a84 <fwp_drop0+0x1e4>
    7a36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a3d:	00 00 00 
    7a40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7a44:	48 85 c0             	test   %rax,%rax
    7a47:	74 3b                	je     7a84 <fwp_drop0+0x1e4>
    7a49:	48 89 c1             	mov    %rax,%rcx
    7a4c:	48 39 10             	cmp    %rdx,(%rax)
    7a4f:	75 ef                	jne    7a40 <fwp_drop0+0x1a0>
    7a51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7a59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7a5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7a64:	0f 85 c4 fe ff ff    	jne    792e <fwp_drop0+0x8e>
    7a6a:	48 89 d7             	mov    %rdx,%rdi
    7a6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a72:	e8 99 d8 ff ff       	call   5310 <fwp_rc_forget_slot>
    7a77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7a7f:	e9 aa fe ff ff       	jmp    792e <fwp_drop0+0x8e>
    7a84:	48 8d 3d ed 3c 00 00 	lea    0x3ced(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    7a8b:	e8 10 c7 ff ff       	call   41a0 <fwp_trap>

0000000000007a90 <fwp_drop1>:
    7a90:	f3 0f 1e fa          	endbr64
    7a94:	48 8b 15 9d 90 01 00 	mov    0x1909d(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    7a9b:	48 89 f8             	mov    %rdi,%rax
    7a9e:	48 2b 05 6b 90 01 00 	sub    0x1906b(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    7aa5:	48 c1 e2 10          	shl    $0x10,%rdx
    7aa9:	48 39 d0             	cmp    %rdx,%rax
    7aac:	0f 83 36 01 00 00    	jae    7be8 <fwp_drop1+0x158>
    7ab2:	48 83 ec 18          	sub    $0x18,%rsp
    7ab6:	48 8d 35 a3 7c 01 00 	lea    0x17ca3(%rip),%rsi        # 1f760 <fwp_heap>
    7abd:	48 89 c2             	mov    %rax,%rdx
    7ac0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7ac7:	48 c1 ea 10          	shr    $0x10,%rdx
    7acb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7acf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7ad3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7ad7:	48 85 d2             	test   %rdx,%rdx
    7ada:	74 42                	je     7b1e <fwp_drop1+0x8e>
    7adc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7ae0:	41 80 f8 02          	cmp    $0x2,%r8b
    7ae4:	74 42                	je     7b28 <fwp_drop1+0x98>
    7ae6:	41 80 f8 01          	cmp    $0x1,%r8b
    7aea:	75 32                	jne    7b1e <fwp_drop1+0x8e>
    7aec:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7af0:	0f b7 c0             	movzwl %ax,%eax
    7af3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7af6:	49 0f af c0          	imul   %r8,%rax
    7afa:	48 c1 e8 20          	shr    $0x20,%rax
    7afe:	48 39 c8             	cmp    %rcx,%rax
    7b01:	73 1b                	jae    7b1e <fwp_drop1+0x8e>
    7b03:	48 01 c2             	add    %rax,%rdx
    7b06:	0f b6 02             	movzbl (%rdx),%eax
    7b09:	84 c0                	test   %al,%al
    7b0b:	74 11                	je     7b1e <fwp_drop1+0x8e>
    7b0d:	3c 01                	cmp    $0x1,%al
    7b0f:	74 27                	je     7b38 <fwp_drop1+0xa8>
    7b11:	3c ff                	cmp    $0xff,%al
    7b13:	0f 84 e7 00 00 00    	je     7c00 <fwp_drop1+0x170>
    7b19:	83 e8 01             	sub    $0x1,%eax
    7b1c:	88 02                	mov    %al,(%rdx)
    7b1e:	48 83 c4 18          	add    $0x18,%rsp
    7b22:	c3                   	ret
    7b23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b28:	66 85 c0             	test   %ax,%ax
    7b2b:	74 d9                	je     7b06 <fwp_drop1+0x76>
    7b2d:	48 83 c4 18          	add    $0x18,%rsp
    7b31:	c3                   	ret
    7b32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b38:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b3f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b46:	48 89 f8             	mov    %rdi,%rax
    7b49:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7b4d:	48 29 c8             	sub    %rcx,%rax
    7b50:	48 c1 e2 10          	shl    $0x10,%rdx
    7b54:	48 39 d0             	cmp    %rdx,%rax
    7b57:	73 71                	jae    7bca <fwp_drop1+0x13a>
    7b59:	49 89 c2             	mov    %rax,%r10
    7b5c:	49 c1 ea 10          	shr    $0x10,%r10
    7b60:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7b64:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7b68:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7b6c:	4d 85 d2             	test   %r10,%r10
    7b6f:	74 59                	je     7bca <fwp_drop1+0x13a>
    7b71:	45 0f b6 19          	movzbl (%r9),%r11d
    7b75:	41 80 fb 02          	cmp    $0x2,%r11b
    7b79:	74 75                	je     7bf0 <fwp_drop1+0x160>
    7b7b:	41 80 fb 01          	cmp    $0x1,%r11b
    7b7f:	75 49                	jne    7bca <fwp_drop1+0x13a>
    7b81:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7b85:	0f b7 c0             	movzwl %ax,%eax
    7b88:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7b8c:	49 0f af c3          	imul   %r11,%rax
    7b90:	48 c1 e8 20          	shr    $0x20,%rax
    7b94:	4c 39 c8             	cmp    %r9,%rax
    7b97:	73 31                	jae    7bca <fwp_drop1+0x13a>
    7b99:	49 01 c2             	add    %rax,%r10
    7b9c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7ba0:	75 28                	jne    7bca <fwp_drop1+0x13a>
    7ba2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7ba7:	e8 a4 d9 ff ff       	call   5550 <fwp_mem_free>
    7bac:	48 8d 35 ad 7b 01 00 	lea    0x17bad(%rip),%rsi        # 1f760 <fwp_heap>
    7bb3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7bb8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7bbf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7bc6:	48 c1 e2 10          	shl    $0x10,%rdx
    7bca:	4c 89 c0             	mov    %r8,%rax
    7bcd:	48 29 c8             	sub    %rcx,%rax
    7bd0:	48 39 d0             	cmp    %rdx,%rax
    7bd3:	0f 83 45 ff ff ff    	jae    7b1e <fwp_drop1+0x8e>
    7bd9:	4c 89 c7             	mov    %r8,%rdi
    7bdc:	e9 dc fe ff ff       	jmp    7abd <fwp_drop1+0x2d>
    7be1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7be8:	c3                   	ret
    7be9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bf0:	66 85 c0             	test   %ax,%ax
    7bf3:	75 d5                	jne    7bca <fwp_drop1+0x13a>
    7bf5:	eb a5                	jmp    7b9c <fwp_drop1+0x10c>
    7bf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bfe:	00 00 
    7c00:	48 89 d0             	mov    %rdx,%rax
    7c03:	48 c1 e8 11          	shr    $0x11,%rax
    7c07:	48 31 d0             	xor    %rdx,%rax
    7c0a:	48 89 c1             	mov    %rax,%rcx
    7c0d:	48 c1 e9 09          	shr    $0x9,%rcx
    7c11:	48 31 c8             	xor    %rcx,%rax
    7c14:	0f b6 c8             	movzbl %al,%ecx
    7c17:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7c1e:	00 
    7c1f:	48 85 c0             	test   %rax,%rax
    7c22:	75 25                	jne    7c49 <fwp_drop1+0x1b9>
    7c24:	eb 5e                	jmp    7c84 <fwp_drop1+0x1f4>
    7c26:	0f 1f 40 00          	nopl   0x0(%rax)
    7c2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c31:	00 00 00 00 
    7c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c3c:	00 00 00 00 
    7c40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7c44:	48 85 c0             	test   %rax,%rax
    7c47:	74 3b                	je     7c84 <fwp_drop1+0x1f4>
    7c49:	48 89 c1             	mov    %rax,%rcx
    7c4c:	48 39 10             	cmp    %rdx,(%rax)
    7c4f:	75 ef                	jne    7c40 <fwp_drop1+0x1b0>
    7c51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7c59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7c5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7c64:	0f 85 b4 fe ff ff    	jne    7b1e <fwp_drop1+0x8e>
    7c6a:	48 89 d7             	mov    %rdx,%rdi
    7c6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c72:	e8 99 d6 ff ff       	call   5310 <fwp_rc_forget_slot>
    7c77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7c7f:	e9 9a fe ff ff       	jmp    7b1e <fwp_drop1+0x8e>
    7c84:	48 8d 3d ed 3a 00 00 	lea    0x3aed(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    7c8b:	e8 10 c5 ff ff       	call   41a0 <fwp_trap>

0000000000007c90 <fwp_drop10>:
    7c90:	48 8b 0d a1 8e 01 00 	mov    0x18ea1(%rip),%rcx        # 20b38 <fwp_heap+0x13d8>
    7c97:	48 89 f8             	mov    %rdi,%rax
    7c9a:	48 2b 05 6f 8e 01 00 	sub    0x18e6f(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    7ca1:	48 c1 e1 10          	shl    $0x10,%rcx
    7ca5:	48 39 c8             	cmp    %rcx,%rax
    7ca8:	0f 83 c2 01 00 00    	jae    7e70 <fwp_drop10+0x1e0>
    7cae:	48 83 ec 18          	sub    $0x18,%rsp
    7cb2:	48 89 fa             	mov    %rdi,%rdx
    7cb5:	48 8d 35 a4 7a 01 00 	lea    0x17aa4(%rip),%rsi        # 1f760 <fwp_heap>
    7cbc:	48 89 c1             	mov    %rax,%rcx
    7cbf:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7cc6:	48 c1 e9 10          	shr    $0x10,%rcx
    7cca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7cce:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7cd2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7cd6:	48 85 c9             	test   %rcx,%rcx
    7cd9:	74 46                	je     7d21 <fwp_drop10+0x91>
    7cdb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7cdf:	41 80 f9 02          	cmp    $0x2,%r9b
    7ce3:	0f 84 d7 00 00 00    	je     7dc0 <fwp_drop10+0x130>
    7ce9:	41 80 f9 01          	cmp    $0x1,%r9b
    7ced:	75 32                	jne    7d21 <fwp_drop10+0x91>
    7cef:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7cf3:	0f b7 c0             	movzwl %ax,%eax
    7cf6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7cf9:	49 0f af c1          	imul   %r9,%rax
    7cfd:	48 c1 e8 20          	shr    $0x20,%rax
    7d01:	48 39 f8             	cmp    %rdi,%rax
    7d04:	73 1b                	jae    7d21 <fwp_drop10+0x91>
    7d06:	48 01 c1             	add    %rax,%rcx
    7d09:	0f b6 01             	movzbl (%rcx),%eax
    7d0c:	84 c0                	test   %al,%al
    7d0e:	74 11                	je     7d21 <fwp_drop10+0x91>
    7d10:	3c 01                	cmp    $0x1,%al
    7d12:	74 1c                	je     7d30 <fwp_drop10+0xa0>
    7d14:	3c ff                	cmp    $0xff,%al
    7d16:	0f 84 5c 01 00 00    	je     7e78 <fwp_drop10+0x1e8>
    7d1c:	83 e8 01             	sub    $0x1,%eax
    7d1f:	88 01                	mov    %al,(%rcx)
    7d21:	48 83 c4 18          	add    $0x18,%rsp
    7d25:	c3                   	ret
    7d26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d2d:	00 00 00 
    7d30:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7d37:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7d3e:	48 89 d0             	mov    %rdx,%rax
    7d41:	49 89 d1             	mov    %rdx,%r9
    7d44:	48 c1 e1 10          	shl    $0x10,%rcx
    7d48:	48 29 f8             	sub    %rdi,%rax
    7d4b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7d4f:	78 7f                	js     7dd0 <fwp_drop10+0x140>
    7d51:	48 39 c8             	cmp    %rcx,%rax
    7d54:	73 cb                	jae    7d21 <fwp_drop10+0x91>
    7d56:	48 89 c1             	mov    %rax,%rcx
    7d59:	48 c1 e9 10          	shr    $0x10,%rcx
    7d5d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7d61:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7d65:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7d69:	48 85 f6             	test   %rsi,%rsi
    7d6c:	74 b3                	je     7d21 <fwp_drop10+0x91>
    7d6e:	0f b6 39             	movzbl (%rcx),%edi
    7d71:	40 80 ff 02          	cmp    $0x2,%dil
    7d75:	74 39                	je     7db0 <fwp_drop10+0x120>
    7d77:	40 80 ff 01          	cmp    $0x1,%dil
    7d7b:	75 a4                	jne    7d21 <fwp_drop10+0x91>
    7d7d:	8b 79 18             	mov    0x18(%rcx),%edi
    7d80:	0f b7 c0             	movzwl %ax,%eax
    7d83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d86:	48 0f af c7          	imul   %rdi,%rax
    7d8a:	48 c1 e8 20          	shr    $0x20,%rax
    7d8e:	48 39 c8             	cmp    %rcx,%rax
    7d91:	73 8e                	jae    7d21 <fwp_drop10+0x91>
    7d93:	48 01 c6             	add    %rax,%rsi
    7d96:	80 3e 01             	cmpb   $0x1,(%rsi)
    7d99:	75 86                	jne    7d21 <fwp_drop10+0x91>
    7d9b:	48 89 d7             	mov    %rdx,%rdi
    7d9e:	48 83 c4 18          	add    $0x18,%rsp
    7da2:	e9 a9 d7 ff ff       	jmp    5550 <fwp_mem_free>
    7da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7dae:	00 00 
    7db0:	66 85 c0             	test   %ax,%ax
    7db3:	74 e1                	je     7d96 <fwp_drop10+0x106>
    7db5:	48 83 c4 18          	add    $0x18,%rsp
    7db9:	c3                   	ret
    7dba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7dc0:	66 85 c0             	test   %ax,%ax
    7dc3:	0f 84 40 ff ff ff    	je     7d09 <fwp_drop10+0x79>
    7dc9:	48 83 c4 18          	add    $0x18,%rsp
    7dcd:	c3                   	ret
    7dce:	66 90                	xchg   %ax,%ax
    7dd0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7dd4:	48 39 c8             	cmp    %rcx,%rax
    7dd7:	73 74                	jae    7e4d <fwp_drop10+0x1bd>
    7dd9:	49 89 c2             	mov    %rax,%r10
    7ddc:	49 c1 ea 10          	shr    $0x10,%r10
    7de0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7de4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7de8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7dec:	4d 85 d2             	test   %r10,%r10
    7def:	74 5c                	je     7e4d <fwp_drop10+0x1bd>
    7df1:	45 0f b6 18          	movzbl (%r8),%r11d
    7df5:	41 80 fb 02          	cmp    $0x2,%r11b
    7df9:	74 6d                	je     7e68 <fwp_drop10+0x1d8>
    7dfb:	41 80 fb 01          	cmp    $0x1,%r11b
    7dff:	75 4c                	jne    7e4d <fwp_drop10+0x1bd>
    7e01:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7e05:	0f b7 c0             	movzwl %ax,%eax
    7e08:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7e0c:	49 0f af c3          	imul   %r11,%rax
    7e10:	48 c1 e8 20          	shr    $0x20,%rax
    7e14:	4c 39 c0             	cmp    %r8,%rax
    7e17:	73 34                	jae    7e4d <fwp_drop10+0x1bd>
    7e19:	49 01 c2             	add    %rax,%r10
    7e1c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7e20:	75 2b                	jne    7e4d <fwp_drop10+0x1bd>
    7e22:	4c 89 cf             	mov    %r9,%rdi
    7e25:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e2a:	e8 21 d7 ff ff       	call   5550 <fwp_mem_free>
    7e2f:	48 8d 35 2a 79 01 00 	lea    0x1792a(%rip),%rsi        # 1f760 <fwp_heap>
    7e36:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e3b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7e42:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7e49:	48 c1 e1 10          	shl    $0x10,%rcx
    7e4d:	48 89 d0             	mov    %rdx,%rax
    7e50:	48 29 f8             	sub    %rdi,%rax
    7e53:	48 39 c8             	cmp    %rcx,%rax
    7e56:	0f 82 60 fe ff ff    	jb     7cbc <fwp_drop10+0x2c>
    7e5c:	e9 c0 fe ff ff       	jmp    7d21 <fwp_drop10+0x91>
    7e61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e68:	66 85 c0             	test   %ax,%ax
    7e6b:	75 e0                	jne    7e4d <fwp_drop10+0x1bd>
    7e6d:	eb ad                	jmp    7e1c <fwp_drop10+0x18c>
    7e6f:	90                   	nop
    7e70:	c3                   	ret
    7e71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e78:	48 89 c8             	mov    %rcx,%rax
    7e7b:	48 c1 e8 11          	shr    $0x11,%rax
    7e7f:	48 31 c8             	xor    %rcx,%rax
    7e82:	48 89 c2             	mov    %rax,%rdx
    7e85:	48 c1 ea 09          	shr    $0x9,%rdx
    7e89:	48 31 d0             	xor    %rdx,%rax
    7e8c:	0f b6 d0             	movzbl %al,%edx
    7e8f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7e96:	00 
    7e97:	48 85 c0             	test   %rax,%rax
    7e9a:	75 0d                	jne    7ea9 <fwp_drop10+0x219>
    7e9c:	eb 46                	jmp    7ee4 <fwp_drop10+0x254>
    7e9e:	66 90                	xchg   %ax,%ax
    7ea0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7ea4:	48 85 c0             	test   %rax,%rax
    7ea7:	74 3b                	je     7ee4 <fwp_drop10+0x254>
    7ea9:	48 89 c2             	mov    %rax,%rdx
    7eac:	48 39 08             	cmp    %rcx,(%rax)
    7eaf:	75 ef                	jne    7ea0 <fwp_drop10+0x210>
    7eb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7eb5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7eb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7ebd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7ec4:	0f 85 57 fe ff ff    	jne    7d21 <fwp_drop10+0x91>
    7eca:	48 89 cf             	mov    %rcx,%rdi
    7ecd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7ed2:	e8 39 d4 ff ff       	call   5310 <fwp_rc_forget_slot>
    7ed7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7edc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7edf:	e9 3d fe ff ff       	jmp    7d21 <fwp_drop10+0x91>
    7ee4:	48 8d 3d 8d 38 00 00 	lea    0x388d(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    7eeb:	e8 b0 c2 ff ff       	call   41a0 <fwp_trap>

0000000000007ef0 <f37>:
    7ef0:	41 57                	push   %r15
    7ef2:	41 56                	push   %r14
    7ef4:	41 55                	push   %r13
    7ef6:	41 54                	push   %r12
    7ef8:	55                   	push   %rbp
    7ef9:	53                   	push   %rbx
    7efa:	48 83 ec 38          	sub    $0x38,%rsp
    7efe:	48 8b 15 33 8c 01 00 	mov    0x18c33(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    7f05:	48 8b 0d 04 8c 01 00 	mov    0x18c04(%rip),%rcx        # 20b10 <fwp_heap+0x13b0>
    7f0c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    7f13:	00 00 
    7f15:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    7f1a:	49 89 fd             	mov    %rdi,%r13
    7f1d:	48 c1 e2 10          	shl    $0x10,%rdx
    7f21:	48 85 ff             	test   %rdi,%rdi
    7f24:	0f 84 fc 02 00 00    	je     8226 <f37+0x336>
    7f2a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7f2e:	48 89 d8             	mov    %rbx,%rax
    7f31:	48 29 c8             	sub    %rcx,%rax
    7f34:	48 39 d0             	cmp    %rdx,%rax
    7f37:	0f 83 b3 03 00 00    	jae    82f0 <f37+0x400>
    7f3d:	48 89 c2             	mov    %rax,%rdx
    7f40:	48 c1 ea 10          	shr    $0x10,%rdx
    7f44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f48:	48 8b 15 09 8c 01 00 	mov    0x18c09(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    7f4f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f53:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7f57:	48 85 ff             	test   %rdi,%rdi
    7f5a:	0f 84 90 03 00 00    	je     82f0 <f37+0x400>
    7f60:	0f b6 0a             	movzbl (%rdx),%ecx
    7f63:	80 f9 02             	cmp    $0x2,%cl
    7f66:	0f 84 94 02 00 00    	je     8200 <f37+0x310>
    7f6c:	80 f9 01             	cmp    $0x1,%cl
    7f6f:	75 24                	jne    7f95 <f37+0xa5>
    7f71:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f74:	0f b7 c0             	movzwl %ax,%eax
    7f77:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f7a:	48 0f af c1          	imul   %rcx,%rax
    7f7e:	48 c1 e8 20          	shr    $0x20,%rax
    7f82:	48 39 d0             	cmp    %rdx,%rax
    7f85:	73 0e                	jae    7f95 <f37+0xa5>
    7f87:	48 01 c7             	add    %rax,%rdi
    7f8a:	0f b6 07             	movzbl (%rdi),%eax
    7f8d:	84 c0                	test   %al,%al
    7f8f:	0f 85 0b 03 00 00    	jne    82a0 <f37+0x3b0>
    7f95:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7f9a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7f9e:	ba 01 00 00 00       	mov    $0x1,%edx
    7fa3:	48 85 db             	test   %rbx,%rbx
    7fa6:	74 15                	je     7fbd <f37+0xcd>
    7fa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7faf:	00 
    7fb0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7fb4:	48 83 c2 01          	add    $0x1,%rdx
    7fb8:	48 85 db             	test   %rbx,%rbx
    7fbb:	75 f3                	jne    7fb0 <f37+0xc0>
    7fbd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7fc2:	48 85 c0             	test   %rax,%rax
    7fc5:	0f 84 55 03 00 00    	je     8320 <f37+0x430>
    7fcb:	31 db                	xor    %ebx,%ebx
    7fcd:	0f 1f 00             	nopl   (%rax)
    7fd0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7fd4:	48 83 c3 01          	add    $0x1,%rbx
    7fd8:	48 85 c0             	test   %rax,%rax
    7fdb:	75 f3                	jne    7fd0 <f37+0xe0>
    7fdd:	48 39 d3             	cmp    %rdx,%rbx
    7fe0:	48 0f 47 da          	cmova  %rdx,%rbx
    7fe4:	48 89 d8             	mov    %rbx,%rax
    7fe7:	48 c1 e8 3c          	shr    $0x3c,%rax
    7feb:	0f 85 d3 03 00 00    	jne    83c4 <f37+0x4d4>
    7ff1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7ff5:	be 02 00 00 00       	mov    $0x2,%esi
    7ffa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8001:	00 
    8002:	e8 49 da ff ff       	call   5a50 <fwp_heap_alloc>
    8007:	48 89 28             	mov    %rbp,(%rax)
    800a:	48 8b 15 27 8b 01 00 	mov    0x18b27(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    8011:	49 89 c4             	mov    %rax,%r12
    8014:	48 2b 05 f5 8a 01 00 	sub    0x18af5(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    801b:	48 c1 e2 10          	shl    $0x10,%rdx
    801f:	48 39 d0             	cmp    %rdx,%rax
    8022:	73 57                	jae    807b <f37+0x18b>
    8024:	48 89 c2             	mov    %rax,%rdx
    8027:	48 c1 ea 10          	shr    $0x10,%rdx
    802b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    802f:	48 8b 15 22 8b 01 00 	mov    0x18b22(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    8036:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    803a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    803e:	48 85 ed             	test   %rbp,%rbp
    8041:	74 38                	je     807b <f37+0x18b>
    8043:	0f b6 0a             	movzbl (%rdx),%ecx
    8046:	80 f9 02             	cmp    $0x2,%cl
    8049:	0f 84 91 02 00 00    	je     82e0 <f37+0x3f0>
    804f:	80 f9 01             	cmp    $0x1,%cl
    8052:	75 27                	jne    807b <f37+0x18b>
    8054:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8057:	0f b7 c0             	movzwl %ax,%eax
    805a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    805d:	48 0f af c1          	imul   %rcx,%rax
    8061:	48 c1 e8 20          	shr    $0x20,%rax
    8065:	48 39 d0             	cmp    %rdx,%rax
    8068:	73 11                	jae    807b <f37+0x18b>
    806a:	48 01 c5             	add    %rax,%rbp
    806d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8071:	0f 84 19 03 00 00    	je     8390 <f37+0x4a0>
    8077:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    807b:	48 85 db             	test   %rbx,%rbx
    807e:	74 5d                	je     80dd <f37+0x1ed>
    8080:	48 c1 e3 04          	shl    $0x4,%rbx
    8084:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    8089:	4c 89 e5             	mov    %r12,%rbp
    808c:	4d 89 ee             	mov    %r13,%r14
    808f:	4c 01 e3             	add    %r12,%rbx
    8092:	0f 1f 00             	nopl   (%rax)
    8095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    809c:	00 00 00 00 
    80a0:	49 8b 46 08          	mov    0x8(%r14),%rax
    80a4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    80a8:	48 83 c5 10          	add    $0x10,%rbp
    80ac:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    80b1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    80b5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    80b9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    80be:	e8 cd df ff ff       	call   6090 <w120>
    80c3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    80c8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    80cc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    80d0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    80d4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    80d8:	48 39 eb             	cmp    %rbp,%rbx
    80db:	75 c3                	jne    80a0 <f37+0x1b0>
    80dd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    80e2:	31 db                	xor    %ebx,%ebx
    80e4:	e8 c7 ed ff ff       	call   6eb0 <fwp_drop4>
    80e9:	4c 89 ef             	mov    %r13,%rdi
    80ec:	e8 bf ed ff ff       	call   6eb0 <fwp_drop4>
    80f1:	4d 8b 2c 24          	mov    (%r12),%r13
    80f5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    80f9:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    8100:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    8107:	4d 85 ed             	test   %r13,%r13
    810a:	74 32                	je     813e <f37+0x24e>
    810c:	0f 1f 40 00          	nopl   0x0(%rax)
    8110:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    8117:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    811c:	48 83 c3 02          	add    $0x2,%rbx
    8120:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8126:	e8 e5 dd ff ff       	call   5f10 <f141.constprop.0>
    812b:	4c 39 eb             	cmp    %r13,%rbx
    812e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    8134:	48 89 c7             	mov    %rax,%rdi
    8137:	72 d7                	jb     8110 <f37+0x220>
    8139:	66 49 0f 7e c5       	movq   %xmm0,%r13
    813e:	4c 89 e7             	mov    %r12,%rdi
    8141:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8146:	e8 45 fb ff ff       	call   7c90 <fwp_drop10>
    814b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8150:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    8155:	31 ff                	xor    %edi,%edi
    8157:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    815c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8161:	e8 0a da ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    8166:	48 8b 15 cb 89 01 00 	mov    0x189cb(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    816d:	48 89 c5             	mov    %rax,%rbp
    8170:	48 2b 05 99 89 01 00 	sub    0x18999(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    8177:	48 c1 e2 10          	shl    $0x10,%rdx
    817b:	48 39 d0             	cmp    %rdx,%rax
    817e:	73 55                	jae    81d5 <f37+0x2e5>
    8180:	48 89 c2             	mov    %rax,%rdx
    8183:	48 c1 ea 10          	shr    $0x10,%rdx
    8187:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    818b:	48 8b 15 c6 89 01 00 	mov    0x189c6(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    8192:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8196:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    819a:	48 85 db             	test   %rbx,%rbx
    819d:	74 36                	je     81d5 <f37+0x2e5>
    819f:	0f b6 0a             	movzbl (%rdx),%ecx
    81a2:	80 f9 02             	cmp    $0x2,%cl
    81a5:	0f 84 1d 01 00 00    	je     82c8 <f37+0x3d8>
    81ab:	80 f9 01             	cmp    $0x1,%cl
    81ae:	75 25                	jne    81d5 <f37+0x2e5>
    81b0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81b3:	0f b7 c0             	movzwl %ax,%eax
    81b6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81b9:	48 0f af c1          	imul   %rcx,%rax
    81bd:	48 c1 e8 20          	shr    $0x20,%rax
    81c1:	48 39 d0             	cmp    %rdx,%rax
    81c4:	73 0f                	jae    81d5 <f37+0x2e5>
    81c6:	48 01 c3             	add    %rax,%rbx
    81c9:	80 3b ff             	cmpb   $0xff,(%rbx)
    81cc:	0f 84 b1 01 00 00    	je     8383 <f37+0x493>
    81d2:	c6 03 01             	movb   $0x1,(%rbx)
    81d5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    81da:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    81e1:	00 00 
    81e3:	0f 85 d6 01 00 00    	jne    83bf <f37+0x4cf>
    81e9:	48 83 c4 38          	add    $0x38,%rsp
    81ed:	48 89 e8             	mov    %rbp,%rax
    81f0:	5b                   	pop    %rbx
    81f1:	5d                   	pop    %rbp
    81f2:	41 5c                	pop    %r12
    81f4:	41 5d                	pop    %r13
    81f6:	41 5e                	pop    %r14
    81f8:	41 5f                	pop    %r15
    81fa:	c3                   	ret
    81fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8200:	66 85 c0             	test   %ax,%ax
    8203:	0f 85 8c fd ff ff    	jne    7f95 <f37+0xa5>
    8209:	0f b6 07             	movzbl (%rdi),%eax
    820c:	84 c0                	test   %al,%al
    820e:	0f 84 81 fd ff ff    	je     7f95 <f37+0xa5>
    8214:	3c fd                	cmp    $0xfd,%al
    8216:	0f 87 99 01 00 00    	ja     83b5 <f37+0x4c5>
    821c:	83 c0 01             	add    $0x1,%eax
    821f:	88 07                	mov    %al,(%rdi)
    8221:	e9 6f fd ff ff       	jmp    7f95 <f37+0xa5>
    8226:	48 f7 d9             	neg    %rcx
    8229:	48 39 d1             	cmp    %rdx,%rcx
    822c:	0f 83 ee 00 00 00    	jae    8320 <f37+0x430>
    8232:	48 89 c8             	mov    %rcx,%rax
    8235:	48 c1 e8 10          	shr    $0x10,%rax
    8239:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    823d:	48 8b 05 14 89 01 00 	mov    0x18914(%rip),%rax        # 20b58 <fwp_heap+0x13f8>
    8244:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8248:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    824c:	48 85 ff             	test   %rdi,%rdi
    824f:	0f 84 cb 00 00 00    	je     8320 <f37+0x430>
    8255:	0f b6 02             	movzbl (%rdx),%eax
    8258:	3c 02                	cmp    $0x2,%al
    825a:	0f 84 9a 00 00 00    	je     82fa <f37+0x40a>
    8260:	3c 01                	cmp    $0x1,%al
    8262:	0f 85 b8 00 00 00    	jne    8320 <f37+0x430>
    8268:	0f b7 c1             	movzwl %cx,%eax
    826b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    826e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8271:	48 0f af c1          	imul   %rcx,%rax
    8275:	48 c1 e8 20          	shr    $0x20,%rax
    8279:	48 39 d0             	cmp    %rdx,%rax
    827c:	0f 83 9e 00 00 00    	jae    8320 <f37+0x430>
    8282:	48 01 c7             	add    %rax,%rdi
    8285:	0f b6 07             	movzbl (%rdi),%eax
    8288:	84 c0                	test   %al,%al
    828a:	0f 84 90 00 00 00    	je     8320 <f37+0x430>
    8290:	31 db                	xor    %ebx,%ebx
    8292:	0f 1f 00             	nopl   (%rax)
    8295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    829c:	00 00 00 00 
    82a0:	3c fd                	cmp    $0xfd,%al
    82a2:	0f 87 f5 00 00 00    	ja     839d <f37+0x4ad>
    82a8:	83 c0 01             	add    $0x1,%eax
    82ab:	88 07                	mov    %al,(%rdi)
    82ad:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    82b2:	31 d2                	xor    %edx,%edx
    82b4:	4d 85 ed             	test   %r13,%r13
    82b7:	0f 85 dd fc ff ff    	jne    7f9a <f37+0xaa>
    82bd:	e9 fb fc ff ff       	jmp    7fbd <f37+0xcd>
    82c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    82c8:	66 85 c0             	test   %ax,%ax
    82cb:	0f 85 04 ff ff ff    	jne    81d5 <f37+0x2e5>
    82d1:	e9 f3 fe ff ff       	jmp    81c9 <f37+0x2d9>
    82d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    82dd:	00 00 00 
    82e0:	66 85 c0             	test   %ax,%ax
    82e3:	0f 85 92 fd ff ff    	jne    807b <f37+0x18b>
    82e9:	e9 7f fd ff ff       	jmp    806d <f37+0x17d>
    82ee:	66 90                	xchg   %ax,%ax
    82f0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    82f5:	e9 a4 fc ff ff       	jmp    7f9e <f37+0xae>
    82fa:	66 85 c9             	test   %cx,%cx
    82fd:	75 21                	jne    8320 <f37+0x430>
    82ff:	0f b6 07             	movzbl (%rdi),%eax
    8302:	84 c0                	test   %al,%al
    8304:	74 1a                	je     8320 <f37+0x430>
    8306:	3c fd                	cmp    $0xfd,%al
    8308:	0f 87 c2 00 00 00    	ja     83d0 <f37+0x4e0>
    830e:	83 c0 01             	add    $0x1,%eax
    8311:	88 07                	mov    %al,(%rdi)
    8313:	66 90                	xchg   %ax,%ax
    8315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    831c:	00 00 00 00 
    8320:	be 02 00 00 00       	mov    $0x2,%esi
    8325:	bf 08 00 00 00       	mov    $0x8,%edi
    832a:	e8 21 d7 ff ff       	call   5a50 <fwp_heap_alloc>
    832f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8336:	48 8b 15 fb 87 01 00 	mov    0x187fb(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    833d:	49 89 c4             	mov    %rax,%r12
    8340:	48 2b 05 c9 87 01 00 	sub    0x187c9(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    8347:	48 c1 e2 10          	shl    $0x10,%rdx
    834b:	48 39 d0             	cmp    %rdx,%rax
    834e:	73 57                	jae    83a7 <f37+0x4b7>
    8350:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8357:	00 00 
    8359:	48 89 c2             	mov    %rax,%rdx
    835c:	48 c1 ea 10          	shr    $0x10,%rdx
    8360:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8364:	48 8b 15 ed 87 01 00 	mov    0x187ed(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    836b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    836f:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8373:	48 85 ed             	test   %rbp,%rbp
    8376:	0f 84 61 fd ff ff    	je     80dd <f37+0x1ed>
    837c:	31 db                	xor    %ebx,%ebx
    837e:	e9 c0 fc ff ff       	jmp    8043 <f37+0x153>
    8383:	48 89 df             	mov    %rbx,%rdi
    8386:	e8 85 cf ff ff       	call   5310 <fwp_rc_forget_slot>
    838b:	e9 42 fe ff ff       	jmp    81d2 <f37+0x2e2>
    8390:	48 89 ef             	mov    %rbp,%rdi
    8393:	e8 78 cf ff ff       	call   5310 <fwp_rc_forget_slot>
    8398:	e9 da fc ff ff       	jmp    8077 <f37+0x187>
    839d:	e8 4e ce ff ff       	call   51f0 <fwp_rc_wide_dup>
    83a2:	e9 06 ff ff ff       	jmp    82ad <f37+0x3bd>
    83a7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    83ae:	00 00 
    83b0:	e9 28 fd ff ff       	jmp    80dd <f37+0x1ed>
    83b5:	e8 36 ce ff ff       	call   51f0 <fwp_rc_wide_dup>
    83ba:	e9 d6 fb ff ff       	jmp    7f95 <f37+0xa5>
    83bf:	e8 9c b0 ff ff       	call   3460 <__stack_chk_fail@plt>
    83c4:	48 8d 3d 62 2d 00 00 	lea    0x2d62(%rip),%rdi        # b12d <_IO_stdin_used+0x12d>
    83cb:	e8 d0 bd ff ff       	call   41a0 <fwp_trap>
    83d0:	e8 1b ce ff ff       	call   51f0 <fwp_rc_wide_dup>
    83d5:	e9 46 ff ff ff       	jmp    8320 <f37+0x430>
    83da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000083e0 <fwp_owned_entry37>:
    83e0:	f3 0f 1e fa          	endbr64
    83e4:	48 8b 3f             	mov    (%rdi),%rdi
    83e7:	e9 04 fb ff ff       	jmp    7ef0 <f37>
    83ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000083f0 <e37>:
    83f0:	f3 0f 1e fa          	endbr64
    83f4:	53                   	push   %rbx
    83f5:	48 8b 1f             	mov    (%rdi),%rbx
    83f8:	48 89 df             	mov    %rbx,%rdi
    83fb:	e8 90 e2 ff ff       	call   6690 <fwp_rc_share>
    8400:	48 89 df             	mov    %rbx,%rdi
    8403:	e8 e8 fa ff ff       	call   7ef0 <f37>
    8408:	48 89 c3             	mov    %rax,%rbx
    840b:	48 89 c7             	mov    %rax,%rdi
    840e:	e8 7d e2 ff ff       	call   6690 <fwp_rc_share>
    8413:	48 89 d8             	mov    %rbx,%rax
    8416:	5b                   	pop    %rbx
    8417:	c3                   	ret
    8418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    841f:	00 

0000000000008420 <fwp_write>:
    8420:	41 57                	push   %r15
    8422:	41 56                	push   %r14
    8424:	41 55                	push   %r13
    8426:	41 54                	push   %r12
    8428:	55                   	push   %rbp
    8429:	53                   	push   %rbx
    842a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8431:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8438:	00 00 
    843a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8441:	00 
    8442:	49 89 d4             	mov    %rdx,%r12
    8445:	8b 12                	mov    (%rdx),%edx
    8447:	83 fa 19             	cmp    $0x19,%edx
    844a:	77 6a                	ja     84b6 <fwp_write+0x96>
    844c:	48 89 f5             	mov    %rsi,%rbp
    844f:	89 d0                	mov    %edx,%eax
    8451:	89 ce                	mov    %ecx,%esi
    8453:	48 89 fb             	mov    %rdi,%rbx
    8456:	48 8d 0d 03 35 00 00 	lea    0x3503(%rip),%rcx        # b960 <_IO_stdin_used+0x960>
    845d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8461:	48 01 c8             	add    %rcx,%rax
    8464:	3e ff e0             	notrack jmp *%rax
    8467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    846e:	00 00 
    8470:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8474:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8478:	48 89 ca             	mov    %rcx,%rdx
    847b:	48 85 c9             	test   %rcx,%rcx
    847e:	0f 88 9c 0c 00 00    	js     9120 <fwp_write+0xd00>
    8484:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    848b:	00 
    848c:	48 89 c6             	mov    %rax,%rsi
    848f:	4c 89 e7             	mov    %r12,%rdi
    8492:	e8 a9 b5 ff ff       	call   3a40 <fwp_fmt_u128>
    8497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    849e:	00 00 
    84a0:	4c 89 e7             	mov    %r12,%rdi
    84a3:	e8 a8 af ff ff       	call   3450 <strlen@plt>
    84a8:	4c 89 e6             	mov    %r12,%rsi
    84ab:	48 89 df             	mov    %rbx,%rdi
    84ae:	48 89 c2             	mov    %rax,%rdx
    84b1:	e8 ba bb ff ff       	call   4070 <buf_put>
    84b6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    84bd:	00 
    84be:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    84c5:	00 00 
    84c7:	0f 85 28 04 00 00    	jne    88f5 <fwp_write+0x4d5>
    84cd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    84d4:	5b                   	pop    %rbx
    84d5:	5d                   	pop    %rbp
    84d6:	41 5c                	pop    %r12
    84d8:	41 5d                	pop    %r13
    84da:	41 5e                	pop    %r14
    84dc:	41 5f                	pop    %r15
    84de:	c3                   	ret
    84df:	90                   	nop
    84e0:	49 89 e9             	mov    %rbp,%r9
    84e3:	4c 8d 05 6d 2c 00 00 	lea    0x2c6d(%rip),%r8        # b157 <_IO_stdin_used+0x157>
    84ea:	b9 00 02 00 00       	mov    $0x200,%ecx
    84ef:	ba 02 00 00 00       	mov    $0x2,%edx
    84f4:	be 00 02 00 00       	mov    $0x200,%esi
    84f9:	31 c0                	xor    %eax,%eax
    84fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8502:	00 
    8503:	e8 a8 ae ff ff       	call   33b0 <__snprintf_chk@plt>
    8508:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    850f:	00 
    8510:	e8 3b af ff ff       	call   3450 <strlen@plt>
    8515:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    851c:	00 
    851d:	48 89 df             	mov    %rbx,%rdi
    8520:	48 89 c2             	mov    %rax,%rdx
    8523:	e8 48 bb ff ff       	call   4070 <buf_put>
    8528:	eb 8c                	jmp    84b6 <fwp_write+0x96>
    852a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8530:	49 89 e9             	mov    %rbp,%r9
    8533:	4c 8d 05 18 2c 00 00 	lea    0x2c18(%rip),%r8        # b152 <_IO_stdin_used+0x152>
    853a:	eb ae                	jmp    84ea <fwp_write+0xca>
    853c:	0f 1f 40 00          	nopl   0x0(%rax)
    8540:	83 fa 13             	cmp    $0x13,%edx
    8543:	48 8d 05 fe 2b 00 00 	lea    0x2bfe(%rip),%rax        # b148 <_IO_stdin_used+0x148>
    854a:	48 8d 35 fc 2b 00 00 	lea    0x2bfc(%rip),%rsi        # b14d <_IO_stdin_used+0x14d>
    8551:	ba 04 00 00 00       	mov    $0x4,%edx
    8556:	48 0f 44 f0          	cmove  %rax,%rsi
    855a:	45 31 ed             	xor    %r13d,%r13d
    855d:	e8 0e bb ff ff       	call   4070 <buf_put>
    8562:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8567:	0f 84 a3 08 00 00    	je     8e10 <fwp_write+0x9f0>
    856d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8572:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8577:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    857c:	48 89 df             	mov    %rbx,%rdi
    857f:	49 0f 44 c5          	cmove  %r13,%rax
    8583:	31 c9                	xor    %ecx,%ecx
    8585:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    858a:	e8 91 fe ff ff       	call   8420 <fwp_write>
    858f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8594:	0f 84 6e 09 00 00    	je     8f08 <fwp_write+0xae8>
    859a:	49 83 c5 01          	add    $0x1,%r13
    859e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    85a2:	0f 83 68 08 00 00    	jae    8e10 <fwp_write+0x9f0>
    85a8:	ba 02 00 00 00       	mov    $0x2,%edx
    85ad:	48 8d 35 e3 2b 00 00 	lea    0x2be3(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    85b4:	48 89 df             	mov    %rbx,%rdi
    85b7:	e8 b4 ba ff ff       	call   4070 <buf_put>
    85bc:	eb af                	jmp    856d <fwp_write+0x14d>
    85be:	66 90                	xchg   %ax,%ax
    85c0:	ba 06 00 00 00       	mov    $0x6,%edx
    85c5:	48 8d 35 a4 2b 00 00 	lea    0x2ba4(%rip),%rsi        # b170 <_IO_stdin_used+0x170>
    85cc:	48 83 c5 10          	add    $0x10,%rbp
    85d0:	e8 9b ba ff ff       	call   4070 <buf_put>
    85d5:	48 89 ef             	mov    %rbp,%rdi
    85d8:	e8 73 ae ff ff       	call   3450 <strlen@plt>
    85dd:	48 89 ee             	mov    %rbp,%rsi
    85e0:	48 89 df             	mov    %rbx,%rdi
    85e3:	48 89 c2             	mov    %rax,%rdx
    85e6:	e8 85 ba ff ff       	call   4070 <buf_put>
    85eb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    85f0:	ba 01 00 00 00       	mov    $0x1,%edx
    85f5:	48 89 df             	mov    %rbx,%rdi
    85f8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    85fd:	e8 6e ba ff ff       	call   4070 <buf_put>
    8602:	e9 af fe ff ff       	jmp    84b6 <fwp_write+0x96>
    8607:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    860e:	00 00 
    8610:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8617:	00 
    8618:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    861f:	00 00 
    8621:	0f 85 ce 02 00 00    	jne    88f5 <fwp_write+0x4d5>
    8627:	ba 0a 00 00 00       	mov    $0xa,%edx
    862c:	48 8d 35 29 2b 00 00 	lea    0x2b29(%rip),%rsi        # b15c <_IO_stdin_used+0x15c>
    8633:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    863a:	48 89 df             	mov    %rbx,%rdi
    863d:	5b                   	pop    %rbx
    863e:	5d                   	pop    %rbp
    863f:	41 5c                	pop    %r12
    8641:	41 5d                	pop    %r13
    8643:	41 5e                	pop    %r14
    8645:	41 5f                	pop    %r15
    8647:	e9 24 ba ff ff       	jmp    4070 <buf_put>
    864c:	0f 1f 40 00          	nopl   0x0(%rax)
    8650:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8655:	4d 85 ed             	test   %r13,%r13
    8658:	0f 84 02 0c 00 00    	je     9260 <fwp_write+0xe40>
    865e:	48 8d 35 3f 2b 00 00 	lea    0x2b3f(%rip),%rsi        # b1a4 <_IO_stdin_used+0x1a4>
    8665:	4c 89 ef             	mov    %r13,%rdi
    8668:	e8 c3 ae ff ff       	call   3530 <strcmp@plt>
    866d:	41 89 c1             	mov    %eax,%r9d
    8670:	85 c0                	test   %eax,%eax
    8672:	0f 84 6c 0c 00 00    	je     92e4 <fwp_write+0xec4>
    8678:	4c 89 ef             	mov    %r13,%rdi
    867b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8680:	e8 cb ad ff ff       	call   3450 <strlen@plt>
    8685:	4c 89 ee             	mov    %r13,%rsi
    8688:	48 89 df             	mov    %rbx,%rdi
    868b:	48 89 c2             	mov    %rax,%rdx
    868e:	e8 dd b9 ff ff       	call   4070 <buf_put>
    8693:	ba 01 00 00 00       	mov    $0x1,%edx
    8698:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    869d:	48 89 df             	mov    %rbx,%rdi
    86a0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    86a5:	e8 c6 b9 ff ff       	call   4070 <buf_put>
    86aa:	ba 01 00 00 00       	mov    $0x1,%edx
    86af:	4c 89 fe             	mov    %r15,%rsi
    86b2:	48 89 df             	mov    %rbx,%rdi
    86b5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    86ba:	e8 b1 b9 ff ff       	call   4070 <buf_put>
    86bf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    86c4:	45 31 f6             	xor    %r14d,%r14d
    86c7:	85 d2                	test   %edx,%edx
    86c9:	0f 8e 81 0a 00 00    	jle    9150 <fwp_write+0xd30>
    86cf:	45 31 ed             	xor    %r13d,%r13d
    86d2:	4d 85 ed             	test   %r13,%r13
    86d5:	0f 85 75 07 00 00    	jne    8e50 <fwp_write+0xa30>
    86db:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    86e2:	00 
    86e3:	45 85 f6             	test   %r14d,%r14d
    86e6:	0f 84 84 07 00 00    	je     8e70 <fwp_write+0xa50>
    86ec:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    86f1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    86f6:	48 89 df             	mov    %rbx,%rdi
    86f9:	49 83 c5 01          	add    $0x1,%r13
    86fd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8701:	31 c9                	xor    %ecx,%ecx
    8703:	e8 18 fd ff ff       	call   8420 <fwp_write>
    8708:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    870d:	7f c3                	jg     86d2 <fwp_write+0x2b2>
    870f:	45 85 f6             	test   %r14d,%r14d
    8712:	0f 84 38 0a 00 00    	je     9150 <fwp_write+0xd30>
    8718:	b8 29 00 00 00       	mov    $0x29,%eax
    871d:	ba 01 00 00 00       	mov    $0x1,%edx
    8722:	4c 89 fe             	mov    %r15,%rsi
    8725:	48 89 df             	mov    %rbx,%rdi
    8728:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    872c:	e8 3f b9 ff ff       	call   4070 <buf_put>
    8731:	e9 80 fd ff ff       	jmp    84b6 <fwp_write+0x96>
    8736:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    873d:	00 00 00 
    8740:	ba 01 00 00 00       	mov    $0x1,%edx
    8745:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    874a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    874f:	e8 1c b9 ff ff       	call   4070 <buf_put>
    8754:	48 85 ed             	test   %rbp,%rbp
    8757:	0f 84 93 06 00 00    	je     8df0 <fwp_write+0x9d0>
    875d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8761:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8766:	31 c9                	xor    %ecx,%ecx
    8768:	48 89 df             	mov    %rbx,%rdi
    876b:	e8 b0 fc ff ff       	call   8420 <fwp_write>
    8770:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8774:	48 85 ed             	test   %rbp,%rbp
    8777:	0f 84 73 06 00 00    	je     8df0 <fwp_write+0x9d0>
    877d:	ba 02 00 00 00       	mov    $0x2,%edx
    8782:	48 8d 35 0e 2a 00 00 	lea    0x2a0e(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    8789:	48 89 df             	mov    %rbx,%rdi
    878c:	e8 df b8 ff ff       	call   4070 <buf_put>
    8791:	eb ca                	jmp    875d <fwp_write+0x33d>
    8793:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8798:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    879c:	85 f6                	test   %esi,%esi
    879e:	0f 84 fc 07 00 00    	je     8fa0 <fwp_write+0xb80>
    87a4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    87ab:	00 
    87ac:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87b3:	00 00 
    87b5:	0f 85 3a 01 00 00    	jne    88f5 <fwp_write+0x4d5>
    87bb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    87bf:	4c 89 ea             	mov    %r13,%rdx
    87c2:	e9 6c fe ff ff       	jmp    8633 <fwp_write+0x213>
    87c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    87ce:	00 00 
    87d0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    87d5:	ba 01 00 00 00       	mov    $0x1,%edx
    87da:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    87df:	48 89 ee             	mov    %rbp,%rsi
    87e2:	e8 89 b8 ff ff       	call   4070 <buf_put>
    87e7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    87ec:	4c 89 e7             	mov    %r12,%rdi
    87ef:	e8 5c ac ff ff       	call   3450 <strlen@plt>
    87f4:	4c 89 e6             	mov    %r12,%rsi
    87f7:	48 89 df             	mov    %rbx,%rdi
    87fa:	48 89 c2             	mov    %rax,%rdx
    87fd:	e8 6e b8 ff ff       	call   4070 <buf_put>
    8802:	ba 01 00 00 00       	mov    $0x1,%edx
    8807:	48 89 ee             	mov    %rbp,%rsi
    880a:	48 89 df             	mov    %rbx,%rdi
    880d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8812:	e8 59 b8 ff ff       	call   4070 <buf_put>
    8817:	e9 9a fc ff ff       	jmp    84b6 <fwp_write+0x96>
    881c:	0f 1f 40 00          	nopl   0x0(%rax)
    8820:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8825:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8829:	0f 8a 8e 0b 00 00    	jp     93bd <fwp_write+0xf9d>
    882f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8833:	66 0f 54 05 25 32 00 	andpd  0x3225(%rip),%xmm0        # ba60 <msg.4+0x90>
    883a:	00 
    883b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8840:	66 0f 2e 05 50 32 00 	ucomisd 0x3250(%rip),%xmm0        # ba98 <msg.4+0xc8>
    8847:	00 
    8848:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    884f:	00 
    8850:	0f 87 b2 09 00 00    	ja     9208 <fwp_write+0xde8>
    8856:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    885d:	00 00 00 
    8860:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8864:	89 ee                	mov    %ebp,%esi
    8866:	4c 89 e7             	mov    %r12,%rdi
    8869:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    886e:	e8 4d bc ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8873:	31 f6                	xor    %esi,%esi
    8875:	4c 89 e7             	mov    %r12,%rdi
    8878:	e8 93 ab ff ff       	call   3410 <strtod@plt>
    887d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8882:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8886:	7a 06                	jp     888e <fwp_write+0x46e>
    8888:	0f 84 e9 01 00 00    	je     8a77 <fwp_write+0x657>
    888e:	83 c5 01             	add    $0x1,%ebp
    8891:	83 fd 12             	cmp    $0x12,%ebp
    8894:	75 ca                	jne    8860 <fwp_write+0x440>
    8896:	be 11 00 00 00       	mov    $0x11,%esi
    889b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    889f:	4c 89 e7             	mov    %r12,%rdi
    88a2:	e8 19 bc ff ff       	call   44c0 <fwp_format_g.constprop.0>
    88a7:	e9 cb 01 00 00       	jmp    8a77 <fwp_write+0x657>
    88ac:	0f 1f 40 00          	nopl   0x0(%rax)
    88b0:	48 83 fd 01          	cmp    $0x1,%rbp
    88b4:	0f 84 e6 08 00 00    	je     91a0 <fwp_write+0xd80>
    88ba:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    88be:	b8 02 00 00 00       	mov    $0x2,%eax
    88c3:	ba 01 00 00 00       	mov    $0x1,%edx
    88c8:	48 0f 44 d0          	cmove  %rax,%rdx
    88cc:	48 8d 35 6d 28 00 00 	lea    0x286d(%rip),%rsi        # b140 <_IO_stdin_used+0x140>
    88d3:	48 8d 05 6b 28 00 00 	lea    0x286b(%rip),%rax        # b145 <_IO_stdin_used+0x145>
    88da:	48 0f 44 f0          	cmove  %rax,%rsi
    88de:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    88e5:	00 
    88e6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88ed:	00 00 
    88ef:	0f 84 3e fd ff ff    	je     8633 <fwp_write+0x213>
    88f5:	e8 66 ab ff ff       	call   3460 <__stack_chk_fail@plt>
    88fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8900:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8905:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    890a:	e8 a1 b6 ff ff       	call   3fb0 <buf_grow>
    890f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8913:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8919:	4c 03 0b             	add    (%rbx),%r9
    891c:	66 45 89 11          	mov    %r10w,(%r9)
    8920:	45 85 e4             	test   %r12d,%r12d
    8923:	0f 8e 07 05 00 00    	jle    8e30 <fwp_write+0xa10>
    8929:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8930:	55 55 55 
    8933:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8938:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    893f:	aa aa aa 
    8942:	49 83 c1 01          	add    $0x1,%r9
    8946:	eb 45                	jmp    898d <fwp_write+0x56d>
    8948:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    894f:	00 
    8950:	be 01 00 00 00       	mov    $0x1,%esi
    8955:	b8 2d 00 00 00       	mov    $0x2d,%eax
    895a:	88 07                	mov    %al,(%rdi)
    895c:	48 89 e8             	mov    %rbp,%rax
    895f:	49 f7 e8             	imul   %r8
    8962:	48 89 e8             	mov    %rbp,%rax
    8965:	48 c1 f8 3f          	sar    $0x3f,%rax
    8969:	48 29 c2             	sub    %rax,%rdx
    896c:	48 85 c9             	test   %rcx,%rcx
    896f:	0f 95 c0             	setne  %al
    8972:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8976:	48 83 ef 01          	sub    $0x1,%rdi
    897a:	48 21 c5             	and    %rax,%rbp
    897d:	48 29 ea             	sub    %rbp,%rdx
    8980:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8984:	49 39 f9             	cmp    %rdi,%r9
    8987:	0f 84 a3 04 00 00    	je     8e30 <fwp_write+0xa10>
    898d:	48 89 e8             	mov    %rbp,%rax
    8990:	49 f7 e8             	imul   %r8
    8993:	48 89 e8             	mov    %rbp,%rax
    8996:	48 c1 f8 3f          	sar    $0x3f,%rax
    899a:	48 89 d1             	mov    %rdx,%rcx
    899d:	48 29 c1             	sub    %rax,%rcx
    89a0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    89a4:	48 89 e9             	mov    %rbp,%rcx
    89a7:	48 29 c1             	sub    %rax,%rcx
    89aa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    89ae:	49 f7 e2             	mul    %r10
    89b1:	b8 30 00 00 00       	mov    $0x30,%eax
    89b6:	48 89 d6             	mov    %rdx,%rsi
    89b9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    89bd:	48 d1 ee             	shr    $1,%rsi
    89c0:	48 01 f2             	add    %rsi,%rdx
    89c3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    89c7:	48 29 d6             	sub    %rdx,%rsi
    89ca:	74 8e                	je     895a <fwp_write+0x53a>
    89cc:	48 83 fe 01          	cmp    $0x1,%rsi
    89d0:	0f 85 7a ff ff ff    	jne    8950 <fwp_write+0x530>
    89d6:	31 f6                	xor    %esi,%esi
    89d8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    89dd:	e9 78 ff ff ff       	jmp    895a <fwp_write+0x53a>
    89e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    89e8:	66 0f 6e cd          	movd   %ebp,%xmm1
    89ec:	0f 2e c9             	ucomiss %xmm1,%xmm1
    89ef:	0f 8a c8 09 00 00    	jp     93bd <fwp_write+0xf9d>
    89f5:	0f 28 c1             	movaps %xmm1,%xmm0
    89f8:	0f 54 05 51 30 00 00 	andps  0x3051(%rip),%xmm0        # ba50 <msg.4+0x80>
    89ff:	0f 2e 05 fe 25 00 00 	ucomiss 0x25fe(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    8a06:	0f 87 24 08 00 00    	ja     9230 <fwp_write+0xe10>
    8a0c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8a10:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8a16:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8a1d:	00 
    8a1e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8a22:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8a27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a2e:	00 00 
    8a30:	44 89 ee             	mov    %r13d,%esi
    8a33:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8a38:	4c 89 e7             	mov    %r12,%rdi
    8a3b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8a40:	e8 7b ba ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8a45:	31 f6                	xor    %esi,%esi
    8a47:	4c 89 e7             	mov    %r12,%rdi
    8a4a:	e8 61 aa ff ff       	call   34b0 <strtof@plt>
    8a4f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8a54:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8a57:	7a 02                	jp     8a5b <fwp_write+0x63b>
    8a59:	74 1c                	je     8a77 <fwp_write+0x657>
    8a5b:	41 83 c5 01          	add    $0x1,%r13d
    8a5f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8a63:	75 cb                	jne    8a30 <fwp_write+0x610>
    8a65:	be 09 00 00 00       	mov    $0x9,%esi
    8a6a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8a6f:	4c 89 e7             	mov    %r12,%rdi
    8a72:	e8 49 ba ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8a77:	4c 89 e7             	mov    %r12,%rdi
    8a7a:	e8 b1 b6 ff ff       	call   4130 <fwp_finish_float>
    8a7f:	e9 1c fa ff ff       	jmp    84a0 <fwp_write+0x80>
    8a84:	0f 1f 40 00          	nopl   0x0(%rax)
    8a88:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8a8c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8a90:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8a97:	00 
    8a98:	48 89 ef             	mov    %rbp,%rdi
    8a9b:	e8 a0 af ff ff       	call   3a40 <fwp_fmt_u128>
    8aa0:	48 89 ef             	mov    %rbp,%rdi
    8aa3:	e8 a8 a9 ff ff       	call   3450 <strlen@plt>
    8aa8:	48 89 ee             	mov    %rbp,%rsi
    8aab:	48 89 df             	mov    %rbx,%rdi
    8aae:	48 89 c2             	mov    %rax,%rdx
    8ab1:	e8 ba b5 ff ff       	call   4070 <buf_put>
    8ab6:	e9 fb f9 ff ff       	jmp    84b6 <fwp_write+0x96>
    8abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ac0:	ba 06 00 00 00       	mov    $0x6,%edx
    8ac5:	48 8d 35 ce 26 00 00 	lea    0x26ce(%rip),%rsi        # b19a <_IO_stdin_used+0x19a>
    8acc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8ad2:	e8 99 b5 ff ff       	call   4070 <buf_put>
    8ad7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8ade:	ff ff 7f 
    8ae1:	48 23 55 00          	and    0x0(%rbp),%rdx
    8ae5:	0f 84 86 02 00 00    	je     8d71 <fwp_write+0x951>
    8aeb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8af0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8af4:	48 85 d2             	test   %rdx,%rdx
    8af7:	0f 84 ae 00 00 00    	je     8bab <fwp_write+0x78b>
    8afd:	8b 0a                	mov    (%rdx),%ecx
    8aff:	83 f9 1c             	cmp    $0x1c,%ecx
    8b02:	0f 84 58 06 00 00    	je     9160 <fwp_write+0xd40>
    8b08:	83 f9 1b             	cmp    $0x1b,%ecx
    8b0b:	0f 87 9a 00 00 00    	ja     8bab <fwp_write+0x78b>
    8b11:	be 01 00 00 00       	mov    $0x1,%esi
    8b16:	48 d3 e6             	shl    %cl,%rsi
    8b19:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8b1f:	0f 85 4b 04 00 00    	jne    8f70 <fwp_write+0xb50>
    8b25:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8b2b:	0f 85 0f 04 00 00    	jne    8f40 <fwp_write+0xb20>
    8b31:	83 e6 21             	and    $0x21,%esi
    8b34:	74 75                	je     8bab <fwp_write+0x78b>
    8b36:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8b3b:	48 85 ff             	test   %rdi,%rdi
    8b3e:	79 07                	jns    8b47 <fwp_write+0x727>
    8b40:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8b44:	4c 01 ee             	add    %r13,%rsi
    8b47:	48 0f be 3e          	movsbq (%rsi),%rdi
    8b4b:	85 c9                	test   %ecx,%ecx
    8b4d:	40 0f b6 f7          	movzbl %dil,%esi
    8b51:	48 0f 44 f7          	cmove  %rdi,%rsi
    8b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b5c:	00 00 00 00 
    8b60:	31 c9                	xor    %ecx,%ecx
    8b62:	48 89 df             	mov    %rbx,%rdi
    8b65:	49 83 c5 01          	add    $0x1,%r13
    8b69:	e8 b2 f8 ff ff       	call   8420 <fwp_write>
    8b6e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8b75:	ff ff 7f 
    8b78:	48 23 55 00          	and    0x0(%rbp),%rdx
    8b7c:	49 39 d5             	cmp    %rdx,%r13
    8b7f:	0f 83 ec 01 00 00    	jae    8d71 <fwp_write+0x951>
    8b85:	ba 02 00 00 00       	mov    $0x2,%edx
    8b8a:	48 89 df             	mov    %rbx,%rdi
    8b8d:	48 8d 35 03 26 00 00 	lea    0x2603(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    8b94:	e8 d7 b4 ff ff       	call   4070 <buf_put>
    8b99:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8b9e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8ba2:	48 85 d2             	test   %rdx,%rdx
    8ba5:	0f 85 52 ff ff ff    	jne    8afd <fwp_write+0x6dd>
    8bab:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8bb0:	48 85 ff             	test   %rdi,%rdi
    8bb3:	0f 88 cf 05 00 00    	js     9188 <fwp_write+0xd68>
    8bb9:	48 8b 31             	mov    (%rcx),%rsi
    8bbc:	eb a2                	jmp    8b60 <fwp_write+0x740>
    8bbe:	66 90                	xchg   %ax,%ax
    8bc0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8bc7:	00 
    8bc8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8bcf:	00 00 
    8bd1:	0f 85 1e fd ff ff    	jne    88f5 <fwp_write+0x4d5>
    8bd7:	ba 08 00 00 00       	mov    $0x8,%edx
    8bdc:	48 8d 35 84 25 00 00 	lea    0x2584(%rip),%rsi        # b167 <_IO_stdin_used+0x167>
    8be3:	e9 4b fa ff ff       	jmp    8633 <fwp_write+0x213>
    8be8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bef:	00 
    8bf0:	89 e8                	mov    %ebp,%eax
    8bf2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8bf9:	76 03                	jbe    8bfe <fwp_write+0x7de>
    8bfb:	8b 45 00             	mov    0x0(%rbp),%eax
    8bfe:	41 89 c6             	mov    %eax,%r14d
    8c01:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8c06:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8c0b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8c0f:	4c 89 ef             	mov    %r13,%rdi
    8c12:	e8 39 a8 ff ff       	call   3450 <strlen@plt>
    8c17:	4c 89 ee             	mov    %r13,%rsi
    8c1a:	48 89 df             	mov    %rbx,%rdi
    8c1d:	48 89 c2             	mov    %rax,%rdx
    8c20:	e8 4b b4 ff ff       	call   4070 <buf_put>
    8c25:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8c2a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8c2e:	85 f6                	test   %esi,%esi
    8c30:	0f 8e 80 f8 ff ff    	jle    84b6 <fwp_write+0x96>
    8c36:	45 31 ed             	xor    %r13d,%r13d
    8c39:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8c3e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8c43:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8c48:	ba 01 00 00 00       	mov    $0x1,%edx
    8c4d:	4c 89 fe             	mov    %r15,%rsi
    8c50:	48 89 04 24          	mov    %rax,(%rsp)
    8c54:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8c59:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8c5d:	48 89 df             	mov    %rbx,%rdi
    8c60:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8c64:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8c69:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8c6e:	e8 fd b3 ff ff       	call   4070 <buf_put>
    8c73:	41 8b 06             	mov    (%r14),%eax
    8c76:	83 f8 0e             	cmp    $0xe,%eax
    8c79:	0f 84 71 02 00 00    	je     8ef0 <fwp_write+0xad0>
    8c7f:	83 f8 10             	cmp    $0x10,%eax
    8c82:	0f 84 38 02 00 00    	je     8ec0 <fwp_write+0xaa0>
    8c88:	83 f8 0a             	cmp    $0xa,%eax
    8c8b:	0f 84 7f 04 00 00    	je     9110 <fwp_write+0xcf0>
    8c91:	0f 8f f9 00 00 00    	jg     8d90 <fwp_write+0x970>
    8c97:	83 f8 03             	cmp    $0x3,%eax
    8c9a:	0f 8f 50 04 00 00    	jg     90f0 <fwp_write+0xcd0>
    8ca0:	85 c0                	test   %eax,%eax
    8ca2:	78 10                	js     8cb4 <fwp_write+0x894>
    8ca4:	48 8b 04 24          	mov    (%rsp),%rax
    8ca8:	48 c1 e8 3f          	shr    $0x3f,%rax
    8cac:	85 c0                	test   %eax,%eax
    8cae:	0f 85 f9 00 00 00    	jne    8dad <fwp_write+0x98d>
    8cb4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8cb9:	48 8b 34 24          	mov    (%rsp),%rsi
    8cbd:	31 c9                	xor    %ecx,%ecx
    8cbf:	48 89 df             	mov    %rbx,%rdi
    8cc2:	e8 59 f7 ff ff       	call   8420 <fwp_write>
    8cc7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8ccc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8cd1:	49 83 c5 01          	add    $0x1,%r13
    8cd5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8cd9:	0f 8f 5f ff ff ff    	jg     8c3e <fwp_write+0x81e>
    8cdf:	e9 d2 f7 ff ff       	jmp    84b6 <fwp_write+0x96>
    8ce4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ce8:	ba 06 00 00 00       	mov    $0x6,%edx
    8ced:	48 8d 35 99 24 00 00 	lea    0x2499(%rip),%rsi        # b18d <_IO_stdin_used+0x18d>
    8cf4:	45 31 ed             	xor    %r13d,%r13d
    8cf7:	e8 74 b3 ff ff       	call   4070 <buf_put>
    8cfc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8d01:	75 19                	jne    8d1c <fwp_write+0x8fc>
    8d03:	eb 6c                	jmp    8d71 <fwp_write+0x951>
    8d05:	0f 1f 00             	nopl   (%rax)
    8d08:	ba 02 00 00 00       	mov    $0x2,%edx
    8d0d:	48 8d 35 83 24 00 00 	lea    0x2483(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    8d14:	48 89 df             	mov    %rbx,%rdi
    8d17:	e8 54 b3 ff ff       	call   4070 <buf_put>
    8d1c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8d22:	b9 00 02 00 00       	mov    $0x200,%ecx
    8d27:	31 c0                	xor    %eax,%eax
    8d29:	49 83 c5 01          	add    $0x1,%r13
    8d2d:	4c 8d 05 60 24 00 00 	lea    0x2460(%rip),%r8        # b194 <_IO_stdin_used+0x194>
    8d34:	ba 02 00 00 00       	mov    $0x2,%edx
    8d39:	be 00 02 00 00       	mov    $0x200,%esi
    8d3e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d45:	00 
    8d46:	e8 65 a6 ff ff       	call   33b0 <__snprintf_chk@plt>
    8d4b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d52:	00 
    8d53:	e8 f8 a6 ff ff       	call   3450 <strlen@plt>
    8d58:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8d5f:	00 
    8d60:	48 89 df             	mov    %rbx,%rdi
    8d63:	48 89 c2             	mov    %rax,%rdx
    8d66:	e8 05 b3 ff ff       	call   4070 <buf_put>
    8d6b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8d6f:	72 97                	jb     8d08 <fwp_write+0x8e8>
    8d71:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d76:	ba 01 00 00 00       	mov    $0x1,%edx
    8d7b:	48 89 df             	mov    %rbx,%rdi
    8d7e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8d83:	e8 e8 b2 ff ff       	call   4070 <buf_put>
    8d88:	e9 29 f7 ff ff       	jmp    84b6 <fwp_write+0x96>
    8d8d:	0f 1f 00             	nopl   (%rax)
    8d90:	83 f8 0b             	cmp    $0xb,%eax
    8d93:	0f 85 1b ff ff ff    	jne    8cb4 <fwp_write+0x894>
    8d99:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8d9e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8da2:	83 e0 01             	and    $0x1,%eax
    8da5:	85 c0                	test   %eax,%eax
    8da7:	0f 84 07 ff ff ff    	je     8cb4 <fwp_write+0x894>
    8dad:	4c 89 fe             	mov    %r15,%rsi
    8db0:	48 89 df             	mov    %rbx,%rdi
    8db3:	ba 01 00 00 00       	mov    $0x1,%edx
    8db8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8dbd:	e8 ae b2 ff ff       	call   4070 <buf_put>
    8dc2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8dc7:	48 8b 34 24          	mov    (%rsp),%rsi
    8dcb:	31 c9                	xor    %ecx,%ecx
    8dcd:	48 89 df             	mov    %rbx,%rdi
    8dd0:	e8 4b f6 ff ff       	call   8420 <fwp_write>
    8dd5:	ba 01 00 00 00       	mov    $0x1,%edx
    8dda:	4c 89 fe             	mov    %r15,%rsi
    8ddd:	48 89 df             	mov    %rbx,%rdi
    8de0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8de5:	e8 86 b2 ff ff       	call   4070 <buf_put>
    8dea:	e9 d8 fe ff ff       	jmp    8cc7 <fwp_write+0x8a7>
    8def:	90                   	nop
    8df0:	ba 01 00 00 00       	mov    $0x1,%edx
    8df5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8dfa:	48 89 df             	mov    %rbx,%rdi
    8dfd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8e02:	e8 69 b2 ff ff       	call   4070 <buf_put>
    8e07:	e9 aa f6 ff ff       	jmp    84b6 <fwp_write+0x96>
    8e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e10:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e15:	ba 01 00 00 00       	mov    $0x1,%edx
    8e1a:	48 89 df             	mov    %rbx,%rdi
    8e1d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8e22:	e8 49 b2 ff ff       	call   4070 <buf_put>
    8e27:	e9 8a f6 ff ff       	jmp    84b6 <fwp_write+0x96>
    8e2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e30:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8e34:	48 8b 13             	mov    (%rbx),%rdx
    8e37:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8e3c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8e40:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8e44:	e9 6d f6 ff ff       	jmp    84b6 <fwp_write+0x96>
    8e49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e50:	ba 02 00 00 00       	mov    $0x2,%edx
    8e55:	48 8d 35 3b 23 00 00 	lea    0x233b(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    8e5c:	48 89 df             	mov    %rbx,%rdi
    8e5f:	e8 0c b2 ff ff       	call   4070 <buf_put>
    8e64:	e9 72 f8 ff ff       	jmp    86db <fwp_write+0x2bb>
    8e69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e70:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8e75:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8e7a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8e7e:	48 89 f7             	mov    %rsi,%rdi
    8e81:	48 89 34 24          	mov    %rsi,(%rsp)
    8e85:	e8 c6 a5 ff ff       	call   3450 <strlen@plt>
    8e8a:	48 8b 34 24          	mov    (%rsp),%rsi
    8e8e:	48 89 df             	mov    %rbx,%rdi
    8e91:	48 89 c2             	mov    %rax,%rdx
    8e94:	e8 d7 b1 ff ff       	call   4070 <buf_put>
    8e99:	ba 03 00 00 00       	mov    $0x3,%edx
    8e9e:	48 8d 35 15 23 00 00 	lea    0x2315(%rip),%rsi        # b1ba <_IO_stdin_used+0x1ba>
    8ea5:	48 89 df             	mov    %rbx,%rdi
    8ea8:	e8 c3 b1 ff ff       	call   4070 <buf_put>
    8ead:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8eb2:	e9 35 f8 ff ff       	jmp    86ec <fwp_write+0x2cc>
    8eb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8ebe:	00 00 
    8ec0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8ec5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8ec9:	48 85 ff             	test   %rdi,%rdi
    8ecc:	0f 84 e2 fd ff ff    	je     8cb4 <fwp_write+0x894>
    8ed2:	48 8d 35 cb 22 00 00 	lea    0x22cb(%rip),%rsi        # b1a4 <_IO_stdin_used+0x1a4>
    8ed9:	e8 52 a6 ff ff       	call   3530 <strcmp@plt>
    8ede:	85 c0                	test   %eax,%eax
    8ee0:	0f 95 c0             	setne  %al
    8ee3:	0f b6 c0             	movzbl %al,%eax
    8ee6:	e9 c1 fd ff ff       	jmp    8cac <fwp_write+0x88c>
    8eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ef0:	31 c0                	xor    %eax,%eax
    8ef2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8ef9:	00 
    8efa:	0f 97 c0             	seta   %al
    8efd:	e9 aa fd ff ff       	jmp    8cac <fwp_write+0x88c>
    8f02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f08:	48 89 df             	mov    %rbx,%rdi
    8f0b:	ba 02 00 00 00       	mov    $0x2,%edx
    8f10:	48 8d 35 8a 22 00 00 	lea    0x228a(%rip),%rsi        # b1a1 <_IO_stdin_used+0x1a1>
    8f17:	e8 54 b1 ff ff       	call   4070 <buf_put>
    8f1c:	4c 89 e8             	mov    %r13,%rax
    8f1f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8f24:	31 c9                	xor    %ecx,%ecx
    8f26:	48 c1 e0 04          	shl    $0x4,%rax
    8f2a:	48 89 df             	mov    %rbx,%rdi
    8f2d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8f32:	e8 e9 f4 ff ff       	call   8420 <fwp_write>
    8f37:	e9 5e f6 ff ff       	jmp    859a <fwp_write+0x17a>
    8f3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8f40:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8f45:	48 85 ff             	test   %rdi,%rdi
    8f48:	79 0c                	jns    8f56 <fwp_write+0xb36>
    8f4a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8f51:	00 
    8f52:	48 03 75 10          	add    0x10(%rbp),%rsi
    8f56:	48 63 3e             	movslq (%rsi),%rdi
    8f59:	83 f9 02             	cmp    $0x2,%ecx
    8f5c:	89 fe                	mov    %edi,%esi
    8f5e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8f62:	e9 f9 fb ff ff       	jmp    8b60 <fwp_write+0x740>
    8f67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8f6e:	00 00 
    8f70:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8f75:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8f7a:	48 85 ff             	test   %rdi,%rdi
    8f7d:	0f 88 0f 03 00 00    	js     9292 <fwp_write+0xe72>
    8f83:	49 0f bf 38          	movswq (%r8),%rdi
    8f87:	83 f9 01             	cmp    $0x1,%ecx
    8f8a:	0f b7 f7             	movzwl %di,%esi
    8f8d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8f91:	e9 ca fb ff ff       	jmp    8b60 <fwp_write+0x740>
    8f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f9d:	00 00 00 
    8fa0:	ba 01 00 00 00       	mov    $0x1,%edx
    8fa5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8faa:	48 83 c5 08          	add    $0x8,%rbp
    8fae:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8fb3:	e8 b8 b0 ff ff       	call   4070 <buf_put>
    8fb8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8fbd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8fc2:	4d 85 ed             	test   %r13,%r13
    8fc5:	75 46                	jne    900d <fwp_write+0xbed>
    8fc7:	e9 04 01 00 00       	jmp    90d0 <fwp_write+0xcb0>
    8fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    8fd0:	41 80 f9 09          	cmp    $0x9,%r9b
    8fd4:	0f 84 d6 00 00 00    	je     90b0 <fwp_write+0xc90>
    8fda:	41 80 f9 0a          	cmp    $0xa,%r9b
    8fde:	0f 85 9c 00 00 00    	jne    9080 <fwp_write+0xc60>
    8fe4:	ba 02 00 00 00       	mov    $0x2,%edx
    8fe9:	48 8d 35 8d 21 00 00 	lea    0x218d(%rip),%rsi        # b17d <_IO_stdin_used+0x17d>
    8ff0:	48 89 df             	mov    %rbx,%rdi
    8ff3:	e8 78 b0 ff ff       	call   4070 <buf_put>
    8ff8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8fff:	00 
    9000:	48 83 c5 01          	add    $0x1,%rbp
    9004:	49 39 ec             	cmp    %rbp,%r12
    9007:	0f 84 c3 00 00 00    	je     90d0 <fwp_write+0xcb0>
    900d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9012:	41 80 f9 0d          	cmp    $0xd,%r9b
    9016:	74 28                	je     9040 <fwp_write+0xc20>
    9018:	7e b6                	jle    8fd0 <fwp_write+0xbb0>
    901a:	41 80 f9 22          	cmp    $0x22,%r9b
    901e:	74 40                	je     9060 <fwp_write+0xc40>
    9020:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9024:	75 5a                	jne    9080 <fwp_write+0xc60>
    9026:	ba 02 00 00 00       	mov    $0x2,%edx
    902b:	48 8d 35 48 21 00 00 	lea    0x2148(%rip),%rsi        # b17a <_IO_stdin_used+0x17a>
    9032:	48 89 df             	mov    %rbx,%rdi
    9035:	e8 36 b0 ff ff       	call   4070 <buf_put>
    903a:	eb c4                	jmp    9000 <fwp_write+0xbe0>
    903c:	0f 1f 40 00          	nopl   0x0(%rax)
    9040:	ba 02 00 00 00       	mov    $0x2,%edx
    9045:	48 8d 35 37 21 00 00 	lea    0x2137(%rip),%rsi        # b183 <_IO_stdin_used+0x183>
    904c:	48 89 df             	mov    %rbx,%rdi
    904f:	e8 1c b0 ff ff       	call   4070 <buf_put>
    9054:	eb aa                	jmp    9000 <fwp_write+0xbe0>
    9056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    905d:	00 00 00 
    9060:	ba 02 00 00 00       	mov    $0x2,%edx
    9065:	48 8d 35 0b 21 00 00 	lea    0x210b(%rip),%rsi        # b177 <_IO_stdin_used+0x177>
    906c:	48 89 df             	mov    %rbx,%rdi
    906f:	e8 fc af ff ff       	call   4070 <buf_put>
    9074:	eb 8a                	jmp    9000 <fwp_write+0xbe0>
    9076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    907d:	00 00 00 
    9080:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9084:	0f 86 2e 01 00 00    	jbe    91b8 <fwp_write+0xd98>
    908a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    908e:	0f 84 24 01 00 00    	je     91b8 <fwp_write+0xd98>
    9094:	ba 01 00 00 00       	mov    $0x1,%edx
    9099:	4c 89 fe             	mov    %r15,%rsi
    909c:	48 89 df             	mov    %rbx,%rdi
    909f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    90a4:	e8 c7 af ff ff       	call   4070 <buf_put>
    90a9:	e9 52 ff ff ff       	jmp    9000 <fwp_write+0xbe0>
    90ae:	66 90                	xchg   %ax,%ax
    90b0:	ba 02 00 00 00       	mov    $0x2,%edx
    90b5:	48 8d 35 c4 20 00 00 	lea    0x20c4(%rip),%rsi        # b180 <_IO_stdin_used+0x180>
    90bc:	48 89 df             	mov    %rbx,%rdi
    90bf:	e8 ac af ff ff       	call   4070 <buf_put>
    90c4:	e9 37 ff ff ff       	jmp    9000 <fwp_write+0xbe0>
    90c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90d0:	ba 01 00 00 00       	mov    $0x1,%edx
    90d5:	4c 89 fe             	mov    %r15,%rsi
    90d8:	48 89 df             	mov    %rbx,%rdi
    90db:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    90e0:	e8 8b af ff ff       	call   4070 <buf_put>
    90e5:	e9 cc f3 ff ff       	jmp    84b6 <fwp_write+0x96>
    90ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90f0:	83 f8 04             	cmp    $0x4,%eax
    90f3:	0f 85 bb fb ff ff    	jne    8cb4 <fwp_write+0x894>
    90f9:	48 8b 04 24          	mov    (%rsp),%rax
    90fd:	48 8b 40 08          	mov    0x8(%rax),%rax
    9101:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9106:	48 c1 e8 3f          	shr    $0x3f,%rax
    910a:	e9 96 fc ff ff       	jmp    8da5 <fwp_write+0x985>
    910f:	90                   	nop
    9110:	8b 0c 24             	mov    (%rsp),%ecx
    9113:	31 c0                	xor    %eax,%eax
    9115:	85 c9                	test   %ecx,%ecx
    9117:	0f 98 c0             	sets   %al
    911a:	e9 86 fc ff ff       	jmp    8da5 <fwp_write+0x985>
    911f:	90                   	nop
    9120:	48 f7 d8             	neg    %rax
    9123:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    912a:	00 
    912b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9132:	2d 
    9133:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    913a:	00 
    913b:	48 83 d2 00          	adc    $0x0,%rdx
    913f:	48 89 c6             	mov    %rax,%rsi
    9142:	48 f7 da             	neg    %rdx
    9145:	e8 f6 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    914a:	e9 51 f3 ff ff       	jmp    84a0 <fwp_write+0x80>
    914f:	90                   	nop
    9150:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9155:	e9 c3 f5 ff ff       	jmp    871d <fwp_write+0x2fd>
    915a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9160:	4c 89 e9             	mov    %r13,%rcx
    9163:	48 c1 e1 04          	shl    $0x4,%rcx
    9167:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    916c:	48 85 ff             	test   %rdi,%rdi
    916f:	0f 89 eb f9 ff ff    	jns    8b60 <fwp_write+0x740>
    9175:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9179:	48 89 ce             	mov    %rcx,%rsi
    917c:	e9 df f9 ff ff       	jmp    8b60 <fwp_write+0x740>
    9181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9188:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    918f:	00 
    9190:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9194:	e9 20 fa ff ff       	jmp    8bb9 <fwp_write+0x799>
    9199:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    91a0:	ba 02 00 00 00       	mov    $0x2,%edx
    91a5:	48 8d 35 96 1f 00 00 	lea    0x1f96(%rip),%rsi        # b142 <_IO_stdin_used+0x142>
    91ac:	e9 2d f7 ff ff       	jmp    88de <fwp_write+0x4be>
    91b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    91b8:	4c 8d 05 c7 1f 00 00 	lea    0x1fc7(%rip),%r8        # b186 <_IO_stdin_used+0x186>
    91bf:	b9 10 00 00 00       	mov    $0x10,%ecx
    91c4:	31 c0                	xor    %eax,%eax
    91c6:	ba 02 00 00 00       	mov    $0x2,%edx
    91cb:	be 10 00 00 00       	mov    $0x10,%esi
    91d0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    91d7:	00 
    91d8:	e8 d3 a1 ff ff       	call   33b0 <__snprintf_chk@plt>
    91dd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    91e4:	00 
    91e5:	e8 66 a2 ff ff       	call   3450 <strlen@plt>
    91ea:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    91f1:	00 
    91f2:	48 89 df             	mov    %rbx,%rdi
    91f5:	48 89 c2             	mov    %rax,%rdx
    91f8:	e8 73 ae ff ff       	call   4070 <buf_put>
    91fd:	e9 fe fd ff ff       	jmp    9000 <fwp_write+0xbe0>
    9202:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9208:	66 0f ef c0          	pxor   %xmm0,%xmm0
    920c:	48 8d 35 29 1f 00 00 	lea    0x1f29(%rip),%rsi        # b13c <_IO_stdin_used+0x13c>
    9213:	48 8d 05 21 1f 00 00 	lea    0x1f21(%rip),%rax        # b13b <_IO_stdin_used+0x13b>
    921a:	4c 89 e7             	mov    %r12,%rdi
    921d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9221:	48 0f 46 f0          	cmovbe %rax,%rsi
    9225:	e8 c6 a1 ff ff       	call   33f0 <strcpy@plt>
    922a:	e9 71 f2 ff ff       	jmp    84a0 <fwp_write+0x80>
    922f:	90                   	nop
    9230:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9234:	48 8d 35 01 1f 00 00 	lea    0x1f01(%rip),%rsi        # b13c <_IO_stdin_used+0x13c>
    923b:	48 8d 05 f9 1e 00 00 	lea    0x1ef9(%rip),%rax        # b13b <_IO_stdin_used+0x13b>
    9242:	0f 2f c8             	comiss %xmm0,%xmm1
    9245:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    924c:	00 
    924d:	4c 89 e7             	mov    %r12,%rdi
    9250:	48 0f 46 f0          	cmovbe %rax,%rsi
    9254:	e8 97 a1 ff ff       	call   33f0 <strcpy@plt>
    9259:	e9 42 f2 ff ff       	jmp    84a0 <fwp_write+0x80>
    925e:	66 90                	xchg   %ax,%ax
    9260:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9265:	45 85 c0             	test   %r8d,%r8d
    9268:	75 34                	jne    929e <fwp_write+0xe7e>
    926a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9271:	00 
    9272:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9279:	00 00 
    927b:	0f 85 74 f6 ff ff    	jne    88f5 <fwp_write+0x4d5>
    9281:	ba 02 00 00 00       	mov    $0x2,%edx
    9286:	48 8d 35 2a 1f 00 00 	lea    0x1f2a(%rip),%rsi        # b1b7 <_IO_stdin_used+0x1b7>
    928d:	e9 a1 f3 ff ff       	jmp    8633 <fwp_write+0x213>
    9292:	48 03 75 10          	add    0x10(%rbp),%rsi
    9296:	49 89 f0             	mov    %rsi,%r8
    9299:	e9 e5 fc ff ff       	jmp    8f83 <fwp_write+0xb63>
    929e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    92a3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    92a8:	85 ff                	test   %edi,%edi
    92aa:	0f 84 fa f3 ff ff    	je     86aa <fwp_write+0x28a>
    92b0:	ba 01 00 00 00       	mov    $0x1,%edx
    92b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    92ba:	48 89 df             	mov    %rbx,%rdi
    92bd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    92c2:	e8 a9 ad ff ff       	call   4070 <buf_put>
    92c7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    92cc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    92d1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    92d7:	85 c0                	test   %eax,%eax
    92d9:	0f 8f f0 f3 ff ff    	jg     86cf <fwp_write+0x2af>
    92df:	e9 34 f4 ff ff       	jmp    8718 <fwp_write+0x2f8>
    92e4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    92e8:	49 89 c5             	mov    %rax,%r13
    92eb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    92f0:	49 89 c4             	mov    %rax,%r12
    92f3:	49 c1 fd 3f          	sar    $0x3f,%r13
    92f7:	4c 09 e8             	or     %r13,%rax
    92fa:	0f 84 a7 00 00 00    	je     93a7 <fwp_write+0xf87>
    9300:	48 8d 2d b9 3f 00 00 	lea    0x3fb9(%rip),%rbp        # d2c0 <units.0>
    9307:	4d 89 e7             	mov    %r12,%r15
    930a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    930e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9313:	4c 89 ff             	mov    %r15,%rdi
    9316:	4c 89 ee             	mov    %r13,%rsi
    9319:	44 89 0c 24          	mov    %r9d,(%rsp)
    931d:	48 99                	cqto
    931f:	48 89 d1             	mov    %rdx,%rcx
    9322:	48 89 c2             	mov    %rax,%rdx
    9325:	e8 26 0f 00 00       	call   a250 <__divmodti4>
    932a:	44 8b 0c 24          	mov    (%rsp),%r9d
    932e:	48 89 c1             	mov    %rax,%rcx
    9331:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9336:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    933b:	0f 84 94 00 00 00    	je     93d5 <fwp_write+0xfb5>
    9341:	41 83 c1 01          	add    $0x1,%r9d
    9345:	48 83 c5 10          	add    $0x10,%rbp
    9349:	41 83 f9 05          	cmp    $0x5,%r9d
    934d:	75 bb                	jne    930a <fwp_write+0xeea>
    934f:	4d 85 ed             	test   %r13,%r13
    9352:	79 53                	jns    93a7 <fwp_write+0xf87>
    9354:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9359:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    935e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9363:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9368:	48 99                	cqto
    936a:	48 f7 d8             	neg    %rax
    936d:	48 83 d2 00          	adc    $0x0,%rdx
    9371:	48 89 c6             	mov    %rax,%rsi
    9374:	48 f7 da             	neg    %rdx
    9377:	e8 c4 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    937c:	49 89 e8             	mov    %rbp,%r8
    937f:	ba 00 02 00 00       	mov    $0x200,%edx
    9384:	be 02 00 00 00       	mov    $0x2,%esi
    9389:	31 c0                	xor    %eax,%eax
    938b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9392:	00 
    9393:	48 8d 0d 18 1e 00 00 	lea    0x1e18(%rip),%rcx        # b1b2 <_IO_stdin_used+0x1b2>
    939a:	4c 89 e7             	mov    %r12,%rdi
    939d:	e8 3e a3 ff ff       	call   36e0 <__sprintf_chk@plt>
    93a2:	e9 f9 f0 ff ff       	jmp    84a0 <fwp_write+0x80>
    93a7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    93ac:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    93b1:	31 d2                	xor    %edx,%edx
    93b3:	48 89 ef             	mov    %rbp,%rdi
    93b6:	e8 85 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    93bb:	eb bf                	jmp    937c <fwp_write+0xf5c>
    93bd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    93c4:	4e 61 4e 00 
    93c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    93cf:	00 
    93d0:	e9 cb f0 ff ff       	jmp    84a0 <fwp_write+0x80>
    93d5:	44 89 0c 24          	mov    %r9d,(%rsp)
    93d9:	48 89 c8             	mov    %rcx,%rax
    93dc:	48 85 d2             	test   %rdx,%rdx
    93df:	78 51                	js     9432 <fwp_write+0x1012>
    93e1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    93e6:	48 89 c6             	mov    %rax,%rsi
    93e9:	48 89 ef             	mov    %rbp,%rdi
    93ec:	e8 4f a6 ff ff       	call   3a40 <fwp_fmt_u128>
    93f1:	44 8b 0c 24          	mov    (%rsp),%r9d
    93f5:	49 63 c1             	movslq %r9d,%rax
    93f8:	49 89 e8             	mov    %rbp,%r8
    93fb:	ba 00 02 00 00       	mov    $0x200,%edx
    9400:	be 02 00 00 00       	mov    $0x2,%esi
    9405:	48 c1 e0 04          	shl    $0x4,%rax
    9409:	48 8d 3d b0 3e 00 00 	lea    0x3eb0(%rip),%rdi        # d2c0 <units.0>
    9410:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9417:	00 
    9418:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    941c:	48 8d 0d 8a 1d 00 00 	lea    0x1d8a(%rip),%rcx        # b1ad <_IO_stdin_used+0x1ad>
    9423:	4c 89 e7             	mov    %r12,%rdi
    9426:	31 c0                	xor    %eax,%eax
    9428:	e8 b3 a2 ff ff       	call   36e0 <__sprintf_chk@plt>
    942d:	e9 6e f0 ff ff       	jmp    84a0 <fwp_write+0x80>
    9432:	48 f7 d8             	neg    %rax
    9435:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    943a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    943f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9444:	48 83 d2 00          	adc    $0x0,%rdx
    9448:	48 89 c6             	mov    %rax,%rsi
    944b:	48 f7 da             	neg    %rdx
    944e:	e8 ed a5 ff ff       	call   3a40 <fwp_fmt_u128>
    9453:	44 8b 0c 24          	mov    (%rsp),%r9d
    9457:	eb 9c                	jmp    93f5 <fwp_write+0xfd5>
    9459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009460 <fwp_main_thread>:
    9460:	f3 0f 1e fa          	endbr64
    9464:	41 57                	push   %r15
    9466:	41 56                	push   %r14
    9468:	41 55                	push   %r13
    946a:	41 54                	push   %r12
    946c:	55                   	push   %rbp
    946d:	53                   	push   %rbx
    946e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9475:	8b 0d 89 76 01 00    	mov    0x17689(%rip),%ecx        # 20b04 <fwp_heap+0x13a4>
    947b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9482:	00 00 
    9484:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    948b:	00 
    948c:	31 c0                	xor    %eax,%eax
    948e:	85 c9                	test   %ecx,%ecx
    9490:	0f 84 62 06 00 00    	je     9af8 <fwp_main_thread+0x698>
    9496:	8b 15 6c 76 01 00    	mov    0x1766c(%rip),%edx        # 20b08 <fwp_heap+0x13a8>
    949c:	85 d2                	test   %edx,%edx
    949e:	0f 85 3c 06 00 00    	jne    9ae0 <fwp_main_thread+0x680>
    94a4:	48 8d 05 d5 5b 00 00 	lea    0x5bd5(%rip),%rax        # f080 <alt.5>
    94ab:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
    94b0:	31 f6                	xor    %esi,%esi
    94b2:	48 c7 05 3b 5c 01 00 	movq   $0x40000000,0x15c3b(%rip)        # 1f0f8 <fwp_main_stack_size>
    94b9:	00 00 00 40 
    94bd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    94c2:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    94c7:	48 89 c7             	mov    %rax,%rdi
    94ca:	4c 89 25 2f 5c 01 00 	mov    %r12,0x15c2f(%rip)        # 1f100 <fwp_main_stack_top>
    94d1:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    94d8:	01 00 
    94da:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    94e1:	00 
    94e2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    94e7:	e8 d4 a1 ff ff       	call   36c0 <sigaltstack@plt>
    94ec:	85 c0                	test   %eax,%eax
    94ee:	0f 85 23 0d 00 00    	jne    a217 <fwp_main_thread+0xdb7>
    94f4:	31 ed                	xor    %ebp,%ebp
    94f6:	b9 12 00 00 00       	mov    $0x12,%ecx
    94fb:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9502:	00 
    9503:	48 89 e8             	mov    %rbp,%rax
    9506:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    950d:	00 
    950e:	f3 48 ab             	rep stos %rax,(%rdi)
    9511:	48 8d 05 d8 a7 ff ff 	lea    -0x5828(%rip),%rax        # 3cf0 <fwp_segv>
    9518:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    951f:	00 
    9520:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    9527:	04 00 00 08 
    952b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9532:	00 
    9533:	e8 48 a0 ff ff       	call   3580 <sigemptyset@plt>
    9538:	85 c0                	test   %eax,%eax
    953a:	0f 85 d7 0c 00 00    	jne    a217 <fwp_main_thread+0xdb7>
    9540:	31 d2                	xor    %edx,%edx
    9542:	48 89 de             	mov    %rbx,%rsi
    9545:	bf 0b 00 00 00       	mov    $0xb,%edi
    954a:	e8 b1 9e ff ff       	call   3400 <sigaction@plt>
    954f:	85 c0                	test   %eax,%eax
    9551:	0f 85 c0 0c 00 00    	jne    a217 <fwp_main_thread+0xdb7>
    9557:	31 d2                	xor    %edx,%edx
    9559:	48 89 de             	mov    %rbx,%rsi
    955c:	bf 07 00 00 00       	mov    $0x7,%edi
    9561:	e8 9a 9e ff ff       	call   3400 <sigaction@plt>
    9566:	85 c0                	test   %eax,%eax
    9568:	0f 85 a9 0c 00 00    	jne    a217 <fwp_main_thread+0xdb7>
    956e:	8b 05 f4 5a 00 00    	mov    0x5af4(%rip),%eax        # f068 <st.3>
    9574:	85 c0                	test   %eax,%eax
    9576:	0f 84 8c 05 00 00    	je     9b08 <fwp_main_thread+0x6a8>
    957c:	48 8b 2d bd 61 01 00 	mov    0x161bd(%rip),%rbp        # 1f740 <fwp_cur>
    9583:	48 85 ed             	test   %rbp,%rbp
    9586:	0f 84 04 03 00 00    	je     9890 <fwp_main_thread+0x430>
    958c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    9591:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9595:	48 89 eb             	mov    %rbp,%rbx
    9598:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    959d:	0f 84 41 01 00 00    	je     96e4 <fwp_main_thread+0x284>
    95a3:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    95a8:	0f 84 12 02 00 00    	je     97c0 <fwp_main_thread+0x360>
    95ae:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    95b2:	0f 84 f8 01 00 00    	je     97b0 <fwp_main_thread+0x350>
    95b8:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    95bc:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    95c0:	0f 85 7a 02 00 00    	jne    9840 <fwp_main_thread+0x3e0>
    95c6:	48 8b 43 60          	mov    0x60(%rbx),%rax
    95ca:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    95d1:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    95d5:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    95dc:	00 00 00 00 
    95e0:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    95e7:	48 85 d2             	test   %rdx,%rdx
    95ea:	74 07                	je     95f3 <fwp_main_thread+0x193>
    95ec:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    95f3:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    95f7:	48 85 c0             	test   %rax,%rax
    95fa:	74 34                	je     9630 <fwp_main_thread+0x1d0>
    95fc:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9600:	48 8b 05 11 61 01 00 	mov    0x16111(%rip),%rax        # 1f718 <fwp_timers>
    9607:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    960b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9612:	00 00 00 00 
    9616:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    961d:	48 85 c0             	test   %rax,%rax
    9620:	74 07                	je     9629 <fwp_main_thread+0x1c9>
    9622:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9629:	48 89 1d e8 60 01 00 	mov    %rbx,0x160e8(%rip)        # 1f718 <fwp_timers>
    9630:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9634:	e8 37 de ff ff       	call   7470 <fwp_block>
    9639:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9640:	48 85 c9             	test   %rcx,%rcx
    9643:	74 47                	je     968c <fwp_main_thread+0x22c>
    9645:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    964c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9653:	48 85 d2             	test   %rdx,%rdx
    9656:	0f 84 24 02 00 00    	je     9880 <fwp_main_thread+0x420>
    965c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9663:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    966a:	48 85 c0             	test   %rax,%rax
    966d:	74 07                	je     9676 <fwp_main_thread+0x216>
    966f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9676:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    967d:	00 00 00 00 
    9681:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9685:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    968c:	48 8b 0d ad 60 01 00 	mov    0x160ad(%rip),%rcx        # 1f740 <fwp_cur>
    9693:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9697:	0f 84 93 01 00 00    	je     9830 <fwp_main_thread+0x3d0>
    969d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    96a4:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    96ab:	48 85 d2             	test   %rdx,%rdx
    96ae:	0f 84 94 03 00 00    	je     9a48 <fwp_main_thread+0x5e8>
    96b4:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    96bb:	48 85 c0             	test   %rax,%rax
    96be:	74 07                	je     96c7 <fwp_main_thread+0x267>
    96c0:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    96c7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    96cb:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    96cf:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    96d6:	48 89 cb             	mov    %rcx,%rbx
    96d9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    96de:	0f 85 bf fe ff ff    	jne    95a3 <fwp_main_thread+0x143>
    96e4:	48 83 3d ec 7c 01 00 	cmpq   $0x0,0x17cec(%rip)        # 213d8 <fwp_state_len>
    96eb:	00 
    96ec:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    96f0:	0f 84 7c 03 00 00    	je     9a72 <fwp_main_thread+0x612>
    96f6:	48 39 1d 3b 60 01 00 	cmp    %rbx,0x1603b(%rip)        # 1f738 <fwp_root>
    96fd:	c7 05 79 59 01 00 00 	movl   $0x0,0x15979(%rip)        # 1f080 <fwp_exit_code>
    9704:	00 00 00 
    9707:	0f 85 38 0b 00 00    	jne    a245 <fwp_main_thread+0xde5>
    970d:	48 85 db             	test   %rbx,%rbx
    9710:	0f 84 a0 01 00 00    	je     98b6 <fwp_main_thread+0x456>
    9716:	48 8b 15 eb 5f 01 00 	mov    0x15feb(%rip),%rdx        # 1f708 <fwp_tasks_active>
    971d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9721:	48 85 d2             	test   %rdx,%rdx
    9724:	0f 84 8c 01 00 00    	je     98b6 <fwp_main_thread+0x456>
    972a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9730:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9734:	75 08                	jne    973e <fwp_main_thread+0x2de>
    9736:	48 89 d7             	mov    %rdx,%rdi
    9739:	e8 72 a9 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    973e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9745:	48 85 d2             	test   %rdx,%rdx
    9748:	75 e6                	jne    9730 <fwp_main_thread+0x2d0>
    974a:	eb 31                	jmp    977d <fwp_main_thread+0x31d>
    974c:	0f 1f 40 00          	nopl   0x0(%rax)
    9750:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9757:	48 89 1d c2 5f 01 00 	mov    %rbx,0x15fc2(%rip)        # 1f720 <fwp_ready_tail>
    975e:	e8 0d dd ff ff       	call   7470 <fwp_block>
    9763:	e8 f8 da ff ff       	call   7260 <fwp_free_zombie>
    9768:	48 83 3d 98 5f 01 00 	cmpq   $0x0,0x15f98(%rip)        # 1f708 <fwp_tasks_active>
    976f:	00 
    9770:	0f 84 40 01 00 00    	je     98b6 <fwp_main_thread+0x456>
    9776:	48 8b 1d bb 5f 01 00 	mov    0x15fbb(%rip),%rbx        # 1f738 <fwp_root>
    977d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9781:	75 db                	jne    975e <fwp_main_thread+0x2fe>
    9783:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9787:	75 d5                	jne    975e <fwp_main_thread+0x2fe>
    9789:	48 8b 05 90 5f 01 00 	mov    0x15f90(%rip),%rax        # 1f720 <fwp_ready_tail>
    9790:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9794:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    979b:	00 00 00 00 
    979f:	48 85 c0             	test   %rax,%rax
    97a2:	75 ac                	jne    9750 <fwp_main_thread+0x2f0>
    97a4:	48 89 1d 7d 5f 01 00 	mov    %rbx,0x15f7d(%rip)        # 1f728 <fwp_ready_head>
    97ab:	eb aa                	jmp    9757 <fwp_main_thread+0x2f7>
    97ad:	0f 1f 00             	nopl   (%rax)
    97b0:	e8 5b ab ff ff       	call   4310 <fwp_now_ns>
    97b5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    97b9:	0f 8d 99 02 00 00    	jge    9a58 <fwp_main_thread+0x5f8>
    97bf:	90                   	nop
    97c0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    97c4:	0f 85 ee fd ff ff    	jne    95b8 <fwp_main_thread+0x158>
    97ca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    97ce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    97d2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    97d6:	0f 85 ee fd ff ff    	jne    95ca <fwp_main_thread+0x16a>
    97dc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    97e0:	48 85 c9             	test   %rcx,%rcx
    97e3:	0f 84 e1 fd ff ff    	je     95ca <fwp_main_thread+0x16a>
    97e9:	48 39 c8             	cmp    %rcx,%rax
    97ec:	48 89 ce             	mov    %rcx,%rsi
    97ef:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    97f6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    97fa:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9801:	00 00 00 00 
    9805:	48 0f 4e f0          	cmovle %rax,%rsi
    9809:	48 85 c0             	test   %rax,%rax
    980c:	48 89 c8             	mov    %rcx,%rax
    980f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9816:	48 0f 45 c6          	cmovne %rsi,%rax
    981a:	48 85 d2             	test   %rdx,%rdx
    981d:	74 07                	je     9826 <fwp_main_thread+0x3c6>
    981f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9826:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    982a:	e9 cd fd ff ff       	jmp    95fc <fwp_main_thread+0x19c>
    982f:	90                   	nop
    9830:	48 89 cb             	mov    %rcx,%rbx
    9833:	e9 60 fd ff ff       	jmp    9598 <fwp_main_thread+0x138>
    9838:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    983f:	00 
    9840:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9844:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    984b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9852:	00 00 00 00 
    9856:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    985d:	48 85 c0             	test   %rax,%rax
    9860:	0f 84 8a 08 00 00    	je     a0f0 <fwp_main_thread+0xc90>
    9866:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    986d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9871:	e9 ba fd ff ff       	jmp    9630 <fwp_main_thread+0x1d0>
    9876:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    987d:	00 00 00 
    9880:	48 89 01             	mov    %rax,(%rcx)
    9883:	e9 e2 fd ff ff       	jmp    966a <fwp_main_thread+0x20a>
    9888:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    988f:	00 
    9890:	48 83 3d 40 7b 01 00 	cmpq   $0x0,0x17b40(%rip)        # 213d8 <fwp_state_len>
    9897:	00 
    9898:	0f 84 d2 01 00 00    	je     9a70 <fwp_main_thread+0x610>
    989e:	48 83 3d 92 5e 01 00 	cmpq   $0x0,0x15e92(%rip)        # 1f738 <fwp_root>
    98a5:	00 
    98a6:	c7 05 d0 57 01 00 00 	movl   $0x0,0x157d0(%rip)        # 1f080 <fwp_exit_code>
    98ad:	00 00 00 
    98b0:	0f 85 8a 09 00 00    	jne    a240 <fwp_main_thread+0xde0>
    98b6:	e8 a5 d9 ff ff       	call   7260 <fwp_free_zombie>
    98bb:	48 83 3d 65 5e 01 00 	cmpq   $0x0,0x15e65(%rip)        # 1f728 <fwp_ready_head>
    98c2:	00 
    98c3:	0f 85 82 9e ff ff    	jne    374b <fwp_main_thread.cold>
    98c9:	48 83 3d 47 5e 01 00 	cmpq   $0x0,0x15e47(%rip)        # 1f718 <fwp_timers>
    98d0:	00 
    98d1:	0f 85 74 9e ff ff    	jne    374b <fwp_main_thread.cold>
    98d7:	8b 05 2f 58 01 00    	mov    0x1582f(%rip),%eax        # 1f10c <fwp_stack_pool_n>
    98dd:	85 c0                	test   %eax,%eax
    98df:	74 3c                	je     991d <fwp_main_thread+0x4bd>
    98e1:	83 e8 01             	sub    $0x1,%eax
    98e4:	4c 8d 25 35 58 01 00 	lea    0x15835(%rip),%r12        # 1f120 <fwp_stack_pool>
    98eb:	48 63 d8             	movslq %eax,%rbx
    98ee:	89 c0                	mov    %eax,%eax
    98f0:	48 89 da             	mov    %rbx,%rdx
    98f3:	48 29 c2             	sub    %rax,%rdx
    98f6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    98fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9900:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9904:	89 1d 02 58 01 00    	mov    %ebx,0x15802(%rip)        # 1f10c <fwp_stack_pool_n>
    990a:	be 00 00 00 10       	mov    $0x10000000,%esi
    990f:	48 83 eb 01          	sub    $0x1,%rbx
    9913:	e8 c8 9c ff ff       	call   35e0 <munmap@plt>
    9918:	48 39 dd             	cmp    %rbx,%rbp
    991b:	75 e3                	jne    9900 <fwp_main_thread+0x4a0>
    991d:	8b 3d ed 56 00 00    	mov    0x56ed(%rip),%edi        # f010 <fwp_epfd>
    9923:	85 ff                	test   %edi,%edi
    9925:	78 05                	js     992c <fwp_main_thread+0x4cc>
    9927:	e8 a4 9b ff ff       	call   34d0 <close@plt>
    992c:	4c 8b 25 ed 59 01 00 	mov    0x159ed(%rip),%r12        # 1f320 <fwp_nfdws>
    9933:	48 8b 2d ee 59 01 00 	mov    0x159ee(%rip),%rbp        # 1f328 <fwp_fdws>
    993a:	31 db                	xor    %ebx,%ebx
    993c:	c7 05 ca 56 00 00 ff 	movl   $0xffffffff,0x56ca(%rip)        # f010 <fwp_epfd>
    9943:	ff ff ff 
    9946:	4d 85 e4             	test   %r12,%r12
    9949:	74 32                	je     997d <fwp_main_thread+0x51d>
    994b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9950:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9955:	48 85 ff             	test   %rdi,%rdi
    9958:	74 1a                	je     9974 <fwp_main_thread+0x514>
    995a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    995e:	0f 85 e7 9d ff ff    	jne    374b <fwp_main_thread.cold>
    9964:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9969:	0f 85 dc 9d ff ff    	jne    374b <fwp_main_thread.cold>
    996f:	e8 dc bb ff ff       	call   5550 <fwp_mem_free>
    9974:	48 83 c3 01          	add    $0x1,%rbx
    9978:	49 39 dc             	cmp    %rbx,%r12
    997b:	75 d3                	jne    9950 <fwp_main_thread+0x4f0>
    997d:	48 89 ef             	mov    %rbp,%rdi
    9980:	e8 cb bb ff ff       	call   5550 <fwp_mem_free>
    9985:	48 8b 15 ac 5d 01 00 	mov    0x15dac(%rip),%rdx        # 1f738 <fwp_root>
    998c:	48 c7 05 91 59 01 00 	movq   $0x0,0x15991(%rip)        # 1f328 <fwp_fdws>
    9993:	00 00 00 00 
    9997:	48 c7 05 7e 59 01 00 	movq   $0x0,0x1597e(%rip)        # 1f320 <fwp_nfdws>
    999e:	00 00 00 00 
    99a2:	48 85 d2             	test   %rdx,%rdx
    99a5:	74 4e                	je     99f5 <fwp_main_thread+0x595>
    99a7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    99ac:	0f 85 99 9d ff ff    	jne    374b <fwp_main_thread.cold>
    99b2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    99b9:	00 
    99ba:	0f 85 8b 9d ff ff    	jne    374b <fwp_main_thread.cold>
    99c0:	48 83 3d 10 7a 01 00 	cmpq   $0x0,0x17a10(%rip)        # 213d8 <fwp_state_len>
    99c7:	00 
    99c8:	0f 85 7d 9d ff ff    	jne    374b <fwp_main_thread.cold>
    99ce:	48 83 3d f2 79 01 00 	cmpq   $0x0,0x179f2(%rip)        # 213c8 <fwp_state_owners>
    99d5:	00 
    99d6:	0f 85 6f 9d ff ff    	jne    374b <fwp_main_thread.cold>
    99dc:	b9 79 00 00 00       	mov    $0x79,%ecx
    99e1:	31 c0                	xor    %eax,%eax
    99e3:	48 8d 3d 56 59 01 00 	lea    0x15956(%rip),%rdi        # 1f340 <fwp_root_context>
    99ea:	f3 48 ab             	rep stos %rax,(%rdi)
    99ed:	48 89 d7             	mov    %rdx,%rdi
    99f0:	e8 5b bb ff ff       	call   5550 <fwp_mem_free>
    99f5:	48 8b 3d 24 56 00 00 	mov    0x5624(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    99fc:	48 c7 05 39 5d 01 00 	movq   $0x0,0x15d39(%rip)        # 1f740 <fwp_cur>
    9a03:	00 00 00 00 
    9a07:	48 c7 05 26 5d 01 00 	movq   $0x0,0x15d26(%rip)        # 1f738 <fwp_root>
    9a0e:	00 00 00 00 
    9a12:	e8 a9 9b ff ff       	call   35c0 <fflush@plt>
    9a17:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    9a1e:	00 
    9a1f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9a26:	00 00 
    9a28:	0f 85 01 08 00 00    	jne    a22f <fwp_main_thread+0xdcf>
    9a2e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9a35:	31 c0                	xor    %eax,%eax
    9a37:	5b                   	pop    %rbx
    9a38:	5d                   	pop    %rbp
    9a39:	41 5c                	pop    %r12
    9a3b:	41 5d                	pop    %r13
    9a3d:	41 5e                	pop    %r14
    9a3f:	41 5f                	pop    %r15
    9a41:	c3                   	ret
    9a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a48:	48 89 05 c9 5c 01 00 	mov    %rax,0x15cc9(%rip)        # 1f718 <fwp_timers>
    9a4f:	e9 67 fc ff ff       	jmp    96bb <fwp_main_thread+0x25b>
    9a54:	0f 1f 40 00          	nopl   0x0(%rax)
    9a58:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9a5c:	0f 85 5e fd ff ff    	jne    97c0 <fwp_main_thread+0x360>
    9a62:	48 89 ef             	mov    %rbp,%rdi
    9a65:	e8 46 a6 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    9a6a:	e9 51 fd ff ff       	jmp    97c0 <fwp_main_thread+0x360>
    9a6f:	90                   	nop
    9a70:	31 db                	xor    %ebx,%ebx
    9a72:	48 83 3d 4e 79 01 00 	cmpq   $0x0,0x1794e(%rip)        # 213c8 <fwp_state_owners>
    9a79:	00 
    9a7a:	0f 85 76 fc ff ff    	jne    96f6 <fwp_main_thread+0x296>
    9a80:	48 8b 3d 59 79 01 00 	mov    0x17959(%rip),%rdi        # 213e0 <fwp_state>
    9a87:	e8 c4 ba ff ff       	call   5550 <fwp_mem_free>
    9a8c:	48 c7 05 49 79 01 00 	movq   $0x0,0x17949(%rip)        # 213e0 <fwp_state>
    9a93:	00 00 00 00 
    9a97:	48 c7 05 2e 79 01 00 	movq   $0x0,0x1792e(%rip)        # 213d0 <fwp_state_cap>
    9a9e:	00 00 00 00 
    9aa2:	48 85 db             	test   %rbx,%rbx
    9aa5:	0f 84 1f 07 00 00    	je     a1ca <fwp_main_thread+0xd6a>
    9aab:	48 39 1d 86 5c 01 00 	cmp    %rbx,0x15c86(%rip)        # 1f738 <fwp_root>
    9ab2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9ab9:	00 00 00 00 
    9abd:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9ac4:	00 00 00 00 
    9ac8:	c7 05 ae 55 01 00 00 	movl   $0x0,0x155ae(%rip)        # 1f080 <fwp_exit_code>
    9acf:	00 00 00 
    9ad2:	0f 84 3e fc ff ff    	je     9716 <fwp_main_thread+0x2b6>
    9ad8:	e9 6e 9c ff ff       	jmp    374b <fwp_main_thread.cold>
    9add:	0f 1f 00             	nopl   (%rax)
    9ae0:	48 8d 3d 39 af ff ff 	lea    -0x50c7(%rip),%rdi        # 4a20 <fwp_heap_report>
    9ae7:	e8 74 09 00 00       	call   a460 <atexit>
    9aec:	e9 b3 f9 ff ff       	jmp    94a4 <fwp_main_thread+0x44>
    9af1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9af8:	e8 33 b0 ff ff       	call   4b30 <fwp_heap_init>
    9afd:	e9 94 f9 ff ff       	jmp    9496 <fwp_main_thread+0x36>
    9b02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b08:	48 8d 05 81 df ff ff 	lea    -0x207f(%rip),%rax        # 7a90 <fwp_drop1>
    9b0f:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    9b14:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    9b1b:	00 00 
    9b1d:	4c 8d 3d 3c 5c 01 00 	lea    0x15c3c(%rip),%r15        # 1f760 <fwp_heap>
    9b24:	66 48 0f 6e d8       	movq   %rax,%xmm3
    9b29:	48 8b 05 c8 78 01 00 	mov    0x178c8(%rip),%rax        # 213f8 <fwp_cleanups>
    9b30:	4c 89 25 c1 78 01 00 	mov    %r12,0x178c1(%rip)        # 213f8 <fwp_cleanups>
    9b37:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    9b3d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9b41:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9b46:	48 8d 05 83 a0 ff ff 	lea    -0x5f7d(%rip),%rax        # 3bd0 <fwp_range_release>
    9b4d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9b52:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9b57:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    9b5c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9b61:	eb 3e                	jmp    9ba1 <fwp_main_thread+0x741>
    9b63:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b68:	80 f9 01             	cmp    $0x1,%cl
    9b6b:	75 29                	jne    9b96 <fwp_main_thread+0x736>
    9b6d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b70:	0f b7 c0             	movzwl %ax,%eax
    9b73:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b76:	48 0f af c1          	imul   %rcx,%rax
    9b7a:	48 c1 e8 20          	shr    $0x20,%rax
    9b7e:	48 39 d0             	cmp    %rdx,%rax
    9b81:	73 13                	jae    9b96 <fwp_main_thread+0x736>
    9b83:	49 01 c5             	add    %rax,%r13
    9b86:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9b8b:	0f 84 9f 05 00 00    	je     a130 <fwp_main_thread+0xcd0>
    9b91:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9b96:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9b9b:	49 83 ec 01          	sub    $0x1,%r12
    9b9f:	72 7f                	jb     9c20 <fwp_main_thread+0x7c0>
    9ba1:	48 89 de             	mov    %rbx,%rsi
    9ba4:	bf 01 00 00 00       	mov    $0x1,%edi
    9ba9:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    9bb0:	00 
    9bb1:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    9bb6:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    9bbd:	00 
    9bbe:	e8 ad bf ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9bc3:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9bca:	48 89 c5             	mov    %rax,%rbp
    9bcd:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9bd4:	48 c1 e2 10          	shl    $0x10,%rdx
    9bd8:	48 39 d0             	cmp    %rdx,%rax
    9bdb:	73 b9                	jae    9b96 <fwp_main_thread+0x736>
    9bdd:	48 89 c2             	mov    %rax,%rdx
    9be0:	48 c1 ea 10          	shr    $0x10,%rdx
    9be4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9be8:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9bef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bf3:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9bf7:	4d 85 ed             	test   %r13,%r13
    9bfa:	74 9a                	je     9b96 <fwp_main_thread+0x736>
    9bfc:	0f b6 0a             	movzbl (%rdx),%ecx
    9bff:	80 f9 02             	cmp    $0x2,%cl
    9c02:	0f 85 60 ff ff ff    	jne    9b68 <fwp_main_thread+0x708>
    9c08:	66 85 c0             	test   %ax,%ax
    9c0b:	0f 84 75 ff ff ff    	je     9b86 <fwp_main_thread+0x726>
    9c11:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9c16:	49 83 ec 01          	sub    $0x1,%r12
    9c1a:	73 85                	jae    9ba1 <fwp_main_thread+0x741>
    9c1c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c20:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9c25:	66 0f 6f 05 43 1e 00 	movdqa 0x1e43(%rip),%xmm0        # ba70 <msg.4+0xa0>
    9c2c:	00 
    9c2d:	48 89 de             	mov    %rbx,%rsi
    9c30:	bf 01 00 00 00       	mov    $0x1,%edi
    9c35:	48 89 05 bc 77 01 00 	mov    %rax,0x177bc(%rip)        # 213f8 <fwp_cleanups>
    9c3c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    9c43:	00 
    9c44:	e8 27 bf ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9c49:	48 8b 15 e8 6e 01 00 	mov    0x16ee8(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    9c50:	49 89 c4             	mov    %rax,%r12
    9c53:	48 2b 05 b6 6e 01 00 	sub    0x16eb6(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    9c5a:	48 c1 e2 10          	shl    $0x10,%rdx
    9c5e:	48 39 d0             	cmp    %rdx,%rax
    9c61:	73 55                	jae    9cb8 <fwp_main_thread+0x858>
    9c63:	48 89 c2             	mov    %rax,%rdx
    9c66:	48 c1 ea 10          	shr    $0x10,%rdx
    9c6a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c6e:	48 8b 15 e3 6e 01 00 	mov    0x16ee3(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    9c75:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c79:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9c7d:	48 85 db             	test   %rbx,%rbx
    9c80:	74 36                	je     9cb8 <fwp_main_thread+0x858>
    9c82:	0f b6 0a             	movzbl (%rdx),%ecx
    9c85:	80 f9 02             	cmp    $0x2,%cl
    9c88:	0f 84 92 04 00 00    	je     a120 <fwp_main_thread+0xcc0>
    9c8e:	80 f9 01             	cmp    $0x1,%cl
    9c91:	75 25                	jne    9cb8 <fwp_main_thread+0x858>
    9c93:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c96:	0f b7 c0             	movzwl %ax,%eax
    9c99:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c9c:	48 0f af c1          	imul   %rcx,%rax
    9ca0:	48 c1 e8 20          	shr    $0x20,%rax
    9ca4:	48 39 d0             	cmp    %rdx,%rax
    9ca7:	73 0f                	jae    9cb8 <fwp_main_thread+0x858>
    9ca9:	48 01 c3             	add    %rax,%rbx
    9cac:	80 3b ff             	cmpb   $0xff,(%rbx)
    9caf:	0f 84 3b 05 00 00    	je     a1f0 <fwp_main_thread+0xd90>
    9cb5:	c6 03 01             	movb   $0x1,(%rbx)
    9cb8:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    9cbd:	bf 01 00 00 00       	mov    $0x1,%edi
    9cc2:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    9cc7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9cce:	00 f0 3f 
    9cd1:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9cd6:	e8 95 be ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9cdb:	48 8b 15 56 6e 01 00 	mov    0x16e56(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    9ce2:	49 89 c4             	mov    %rax,%r12
    9ce5:	48 2b 05 24 6e 01 00 	sub    0x16e24(%rip),%rax        # 20b10 <fwp_heap+0x13b0>
    9cec:	48 c1 e2 10          	shl    $0x10,%rdx
    9cf0:	48 39 d0             	cmp    %rdx,%rax
    9cf3:	73 55                	jae    9d4a <fwp_main_thread+0x8ea>
    9cf5:	48 89 c2             	mov    %rax,%rdx
    9cf8:	48 c1 ea 10          	shr    $0x10,%rdx
    9cfc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d00:	48 8b 15 51 6e 01 00 	mov    0x16e51(%rip),%rdx        # 20b58 <fwp_heap+0x13f8>
    9d07:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d0b:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9d0f:	48 85 db             	test   %rbx,%rbx
    9d12:	74 36                	je     9d4a <fwp_main_thread+0x8ea>
    9d14:	0f b6 0a             	movzbl (%rdx),%ecx
    9d17:	80 f9 02             	cmp    $0x2,%cl
    9d1a:	0f 84 f0 03 00 00    	je     a110 <fwp_main_thread+0xcb0>
    9d20:	80 f9 01             	cmp    $0x1,%cl
    9d23:	75 25                	jne    9d4a <fwp_main_thread+0x8ea>
    9d25:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d28:	0f b7 c0             	movzwl %ax,%eax
    9d2b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d2e:	48 0f af c1          	imul   %rcx,%rax
    9d32:	48 c1 e8 20          	shr    $0x20,%rax
    9d36:	48 39 d0             	cmp    %rdx,%rax
    9d39:	73 0f                	jae    9d4a <fwp_main_thread+0x8ea>
    9d3b:	48 01 c3             	add    %rax,%rbx
    9d3e:	80 3b ff             	cmpb   $0xff,(%rbx)
    9d41:	0f 84 b6 04 00 00    	je     a1fd <fwp_main_thread+0xd9d>
    9d47:	c6 03 01             	movb   $0x1,(%rbx)
    9d4a:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    9d4f:	bf 01 00 00 00       	mov    $0x1,%edi
    9d54:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    9d59:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9d60:	33 f3 bf 
    9d63:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    9d68:	e8 03 be ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9d6d:	48 8b 15 c4 6d 01 00 	mov    0x16dc4(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    9d74:	48 8b 0d 95 6d 01 00 	mov    0x16d95(%rip),%rcx        # 20b10 <fwp_heap+0x13b0>
    9d7b:	49 89 c4             	mov    %rax,%r12
    9d7e:	48 89 d6             	mov    %rdx,%rsi
    9d81:	48 29 c8             	sub    %rcx,%rax
    9d84:	48 c1 e6 10          	shl    $0x10,%rsi
    9d88:	48 39 f0             	cmp    %rsi,%rax
    9d8b:	73 65                	jae    9df2 <fwp_main_thread+0x992>
    9d8d:	48 89 c6             	mov    %rax,%rsi
    9d90:	48 c1 ee 10          	shr    $0x10,%rsi
    9d94:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9d98:	48 8b 35 b9 6d 01 00 	mov    0x16db9(%rip),%rsi        # 20b58 <fwp_heap+0x13f8>
    9d9f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9da3:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    9da7:	48 85 db             	test   %rbx,%rbx
    9daa:	74 46                	je     9df2 <fwp_main_thread+0x992>
    9dac:	0f b6 3e             	movzbl (%rsi),%edi
    9daf:	40 80 ff 02          	cmp    $0x2,%dil
    9db3:	0f 84 47 03 00 00    	je     a100 <fwp_main_thread+0xca0>
    9db9:	40 80 ff 01          	cmp    $0x1,%dil
    9dbd:	75 33                	jne    9df2 <fwp_main_thread+0x992>
    9dbf:	8b 7e 18             	mov    0x18(%rsi),%edi
    9dc2:	0f b7 c0             	movzwl %ax,%eax
    9dc5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9dc8:	48 0f af c7          	imul   %rdi,%rax
    9dcc:	48 c1 e8 20          	shr    $0x20,%rax
    9dd0:	48 39 f0             	cmp    %rsi,%rax
    9dd3:	73 1d                	jae    9df2 <fwp_main_thread+0x992>
    9dd5:	48 01 c3             	add    %rax,%rbx
    9dd8:	80 3b ff             	cmpb   $0xff,(%rbx)
    9ddb:	0f 84 29 04 00 00    	je     a20a <fwp_main_thread+0xdaa>
    9de1:	c6 03 01             	movb   $0x1,(%rbx)
    9de4:	48 8b 0d 25 6d 01 00 	mov    0x16d25(%rip),%rcx        # 20b10 <fwp_heap+0x13b0>
    9deb:	48 8b 15 46 6d 01 00 	mov    0x16d46(%rip),%rdx        # 20b38 <fwp_heap+0x13d8>
    9df2:	49 89 ed             	mov    %rbp,%r13
    9df5:	e9 01 02 00 00       	jmp    9ffb <fwp_main_thread+0xb9b>
    9dfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e00:	80 f9 01             	cmp    $0x1,%cl
    9e03:	75 2d                	jne    9e32 <fwp_main_thread+0x9d2>
    9e05:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e08:	0f b7 c0             	movzwl %ax,%eax
    9e0b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e0e:	48 0f af c1          	imul   %rcx,%rax
    9e12:	48 c1 e8 20          	shr    $0x20,%rax
    9e16:	48 39 d0             	cmp    %rdx,%rax
    9e19:	73 17                	jae    9e32 <fwp_main_thread+0x9d2>
    9e1b:	48 01 c7             	add    %rax,%rdi
    9e1e:	0f b6 07             	movzbl (%rdi),%eax
    9e21:	84 c0                	test   %al,%al
    9e23:	74 0d                	je     9e32 <fwp_main_thread+0x9d2>
    9e25:	3c fd                	cmp    $0xfd,%al
    9e27:	0f 87 93 03 00 00    	ja     a1c0 <fwp_main_thread+0xd60>
    9e2d:	83 c0 01             	add    $0x1,%eax
    9e30:	88 07                	mov    %al,(%rdi)
    9e32:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9e37:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9e3b:	b9 01 00 00 00       	mov    $0x1,%ecx
    9e40:	4c 89 e6             	mov    %r12,%rsi
    9e43:	48 8d 15 56 4d 00 00 	lea    0x4d56(%rip),%rdx        # eba0 <d0>
    9e4a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    9e4f:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    9e56:	00 00 
    9e58:	e8 c3 e5 ff ff       	call   8420 <fwp_write>
    9e5d:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    9e62:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    9e67:	48 8d 05 c0 11 00 00 	lea    0x11c0(%rip),%rax        # b02e <_IO_stdin_used+0x2e>
    9e6e:	48 85 c9             	test   %rcx,%rcx
    9e71:	48 0f 44 c8          	cmove  %rax,%rcx
    9e75:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    9e79:	0f 87 a4 03 00 00    	ja     a223 <fwp_main_thread+0xdc3>
    9e7f:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    9e83:	be 01 00 00 00       	mov    $0x1,%esi
    9e88:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    9e8d:	e8 be bb ff ff       	call   5a50 <fwp_heap_alloc>
    9e92:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9e97:	4c 89 f2             	mov    %r14,%rdx
    9e9a:	4c 89 30             	mov    %r14,(%rax)
    9e9d:	48 89 c3             	mov    %rax,%rbx
    9ea0:	48 8d 78 08          	lea    0x8(%rax),%rdi
    9ea4:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    9ea9:	e8 f2 96 ff ff       	call   35a0 <memcpy@plt>
    9eae:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    9eb4:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    9eb9:	e8 02 95 ff ff       	call   33c0 <free@plt>
    9ebe:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9ec5:	48 89 d8             	mov    %rbx,%rax
    9ec8:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9ecf:	48 c1 e2 10          	shl    $0x10,%rdx
    9ed3:	48 39 d0             	cmp    %rdx,%rax
    9ed6:	73 55                	jae    9f2d <fwp_main_thread+0xacd>
    9ed8:	48 89 c2             	mov    %rax,%rdx
    9edb:	48 c1 ea 10          	shr    $0x10,%rdx
    9edf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ee3:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9eea:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9eee:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    9ef2:	48 85 f6             	test   %rsi,%rsi
    9ef5:	74 36                	je     9f2d <fwp_main_thread+0xacd>
    9ef7:	0f b6 0a             	movzbl (%rdx),%ecx
    9efa:	80 f9 02             	cmp    $0x2,%cl
    9efd:	0f 84 9d 01 00 00    	je     a0a0 <fwp_main_thread+0xc40>
    9f03:	80 f9 01             	cmp    $0x1,%cl
    9f06:	75 25                	jne    9f2d <fwp_main_thread+0xacd>
    9f08:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f0b:	0f b7 c0             	movzwl %ax,%eax
    9f0e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f11:	48 0f af c1          	imul   %rcx,%rax
    9f15:	48 c1 e8 20          	shr    $0x20,%rax
    9f19:	48 39 d0             	cmp    %rdx,%rax
    9f1c:	73 0f                	jae    9f2d <fwp_main_thread+0xacd>
    9f1e:	48 01 c6             	add    %rax,%rsi
    9f21:	80 3e ff             	cmpb   $0xff,(%rsi)
    9f24:	0f 84 96 01 00 00    	je     a0c0 <fwp_main_thread+0xc60>
    9f2a:	c6 06 01             	movb   $0x1,(%rsi)
    9f2d:	4c 89 e7             	mov    %r12,%rdi
    9f30:	e8 6b d9 ff ff       	call   78a0 <fwp_drop0>
    9f35:	48 8b 13             	mov    (%rbx),%rdx
    9f38:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9f3d:	be 01 00 00 00       	mov    $0x1,%esi
    9f42:	48 8b 0d 77 74 01 00 	mov    0x17477(%rip),%rcx        # 213c0 <fwp_prog_out>
    9f49:	e8 32 97 ff ff       	call   3680 <fwrite@plt>
    9f4e:	48 8b 35 6b 74 01 00 	mov    0x1746b(%rip),%rsi        # 213c0 <fwp_prog_out>
    9f55:	bf 0a 00 00 00       	mov    $0xa,%edi
    9f5a:	e8 81 95 ff ff       	call   34e0 <fputc@plt>
    9f5f:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9f66:	48 89 d8             	mov    %rbx,%rax
    9f69:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9f70:	48 c1 e2 10          	shl    $0x10,%rdx
    9f74:	48 39 d0             	cmp    %rdx,%rax
    9f77:	73 67                	jae    9fe0 <fwp_main_thread+0xb80>
    9f79:	48 89 c2             	mov    %rax,%rdx
    9f7c:	48 c1 ea 10          	shr    $0x10,%rdx
    9f80:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f84:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9f8b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f8f:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9f93:	4d 85 f6             	test   %r14,%r14
    9f96:	74 48                	je     9fe0 <fwp_main_thread+0xb80>
    9f98:	0f b6 0a             	movzbl (%rdx),%ecx
    9f9b:	80 f9 02             	cmp    $0x2,%cl
    9f9e:	0f 84 ac 00 00 00    	je     a050 <fwp_main_thread+0xbf0>
    9fa4:	80 f9 01             	cmp    $0x1,%cl
    9fa7:	75 37                	jne    9fe0 <fwp_main_thread+0xb80>
    9fa9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9fac:	0f b7 c0             	movzwl %ax,%eax
    9faf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9fb2:	48 0f af c1          	imul   %rcx,%rax
    9fb6:	48 c1 e8 20          	shr    $0x20,%rax
    9fba:	48 39 d0             	cmp    %rdx,%rax
    9fbd:	73 21                	jae    9fe0 <fwp_main_thread+0xb80>
    9fbf:	49 01 c6             	add    %rax,%r14
    9fc2:	41 0f b6 06          	movzbl (%r14),%eax
    9fc6:	84 c0                	test   %al,%al
    9fc8:	74 16                	je     9fe0 <fwp_main_thread+0xb80>
    9fca:	3c 01                	cmp    $0x1,%al
    9fcc:	0f 84 0e 01 00 00    	je     a0e0 <fwp_main_thread+0xc80>
    9fd2:	3c ff                	cmp    $0xff,%al
    9fd4:	0f 84 66 01 00 00    	je     a140 <fwp_main_thread+0xce0>
    9fda:	83 e8 01             	sub    $0x1,%eax
    9fdd:	41 88 06             	mov    %al,(%r14)
    9fe0:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9fe4:	4d 85 ed             	test   %r13,%r13
    9fe7:	0f 84 83 00 00 00    	je     a070 <fwp_main_thread+0xc10>
    9fed:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    9ff4:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9ffb:	4c 89 e0             	mov    %r12,%rax
    9ffe:	48 c1 e2 10          	shl    $0x10,%rdx
    a002:	48 29 c8             	sub    %rcx,%rax
    a005:	48 39 d0             	cmp    %rdx,%rax
    a008:	0f 83 24 fe ff ff    	jae    9e32 <fwp_main_thread+0x9d2>
    a00e:	48 89 c2             	mov    %rax,%rdx
    a011:	48 c1 ea 10          	shr    $0x10,%rdx
    a015:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a019:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a020:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a024:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a028:	48 85 ff             	test   %rdi,%rdi
    a02b:	0f 84 01 fe ff ff    	je     9e32 <fwp_main_thread+0x9d2>
    a031:	0f b6 0a             	movzbl (%rdx),%ecx
    a034:	80 f9 02             	cmp    $0x2,%cl
    a037:	0f 85 c3 fd ff ff    	jne    9e00 <fwp_main_thread+0x9a0>
    a03d:	66 85 c0             	test   %ax,%ax
    a040:	0f 85 ec fd ff ff    	jne    9e32 <fwp_main_thread+0x9d2>
    a046:	e9 d3 fd ff ff       	jmp    9e1e <fwp_main_thread+0x9be>
    a04b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a050:	66 85 c0             	test   %ax,%ax
    a053:	0f 84 69 ff ff ff    	je     9fc2 <fwp_main_thread+0xb62>
    a059:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a05d:	4d 85 ed             	test   %r13,%r13
    a060:	75 8b                	jne    9fed <fwp_main_thread+0xb8d>
    a062:	0f 1f 00             	nopl   (%rax)
    a065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a06c:	00 00 00 00 
    a070:	4c 89 e7             	mov    %r12,%rdi
    a073:	e8 28 d8 ff ff       	call   78a0 <fwp_drop0>
    a078:	48 89 ef             	mov    %rbp,%rdi
    a07b:	e8 20 d8 ff ff       	call   78a0 <fwp_drop0>
    a080:	48 c7 05 d5 4f 00 00 	movq   $0x0,0x4fd5(%rip)        # f060 <v.2>
    a087:	00 00 00 00 
    a08b:	c7 05 d3 4f 00 00 01 	movl   $0x1,0x4fd3(%rip)        # f068 <st.3>
    a092:	00 00 00 
    a095:	e9 e2 f4 ff ff       	jmp    957c <fwp_main_thread+0x11c>
    a09a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a0a0:	66 85 c0             	test   %ax,%ax
    a0a3:	0f 85 84 fe ff ff    	jne    9f2d <fwp_main_thread+0xacd>
    a0a9:	80 3e ff             	cmpb   $0xff,(%rsi)
    a0ac:	0f 85 78 fe ff ff    	jne    9f2a <fwp_main_thread+0xaca>
    a0b2:	0f 1f 00             	nopl   (%rax)
    a0b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a0bc:	00 00 00 00 
    a0c0:	48 89 f7             	mov    %rsi,%rdi
    a0c3:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    a0c8:	e8 43 b2 ff ff       	call   5310 <fwp_rc_forget_slot>
    a0cd:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a0d2:	e9 53 fe ff ff       	jmp    9f2a <fwp_main_thread+0xaca>
    a0d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a0de:	00 00 
    a0e0:	48 89 df             	mov    %rbx,%rdi
    a0e3:	e8 68 b4 ff ff       	call   5550 <fwp_mem_free>
    a0e8:	e9 f3 fe ff ff       	jmp    9fe0 <fwp_main_thread+0xb80>
    a0ed:	0f 1f 00             	nopl   (%rax)
    a0f0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a0f4:	e9 37 f5 ff ff       	jmp    9630 <fwp_main_thread+0x1d0>
    a0f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a100:	66 85 c0             	test   %ax,%ax
    a103:	0f 85 e9 fc ff ff    	jne    9df2 <fwp_main_thread+0x992>
    a109:	e9 ca fc ff ff       	jmp    9dd8 <fwp_main_thread+0x978>
    a10e:	66 90                	xchg   %ax,%ax
    a110:	66 85 c0             	test   %ax,%ax
    a113:	0f 85 31 fc ff ff    	jne    9d4a <fwp_main_thread+0x8ea>
    a119:	e9 20 fc ff ff       	jmp    9d3e <fwp_main_thread+0x8de>
    a11e:	66 90                	xchg   %ax,%ax
    a120:	66 85 c0             	test   %ax,%ax
    a123:	0f 85 8f fb ff ff    	jne    9cb8 <fwp_main_thread+0x858>
    a129:	e9 7e fb ff ff       	jmp    9cac <fwp_main_thread+0x84c>
    a12e:	66 90                	xchg   %ax,%ax
    a130:	4c 89 ef             	mov    %r13,%rdi
    a133:	e8 d8 b1 ff ff       	call   5310 <fwp_rc_forget_slot>
    a138:	e9 54 fa ff ff       	jmp    9b91 <fwp_main_thread+0x731>
    a13d:	0f 1f 00             	nopl   (%rax)
    a140:	4c 89 f0             	mov    %r14,%rax
    a143:	48 c1 e8 11          	shr    $0x11,%rax
    a147:	4c 31 f0             	xor    %r14,%rax
    a14a:	48 89 c2             	mov    %rax,%rdx
    a14d:	48 c1 ea 09          	shr    $0x9,%rdx
    a151:	48 31 d0             	xor    %rdx,%rax
    a154:	0f b6 d0             	movzbl %al,%edx
    a157:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    a15e:	00 
    a15f:	48 85 c0             	test   %rax,%rax
    a162:	75 29                	jne    a18d <fwp_main_thread+0xd2d>
    a164:	e9 cb 00 00 00       	jmp    a234 <fwp_main_thread+0xdd4>
    a169:	90                   	nop
    a16a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a171:	00 00 00 00 
    a175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a17c:	00 00 00 00 
    a180:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a184:	48 85 c0             	test   %rax,%rax
    a187:	0f 84 a7 00 00 00    	je     a234 <fwp_main_thread+0xdd4>
    a18d:	48 89 c2             	mov    %rax,%rdx
    a190:	4c 3b 30             	cmp    (%rax),%r14
    a193:	75 eb                	jne    a180 <fwp_main_thread+0xd20>
    a195:	48 8b 70 08          	mov    0x8(%rax),%rsi
    a199:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    a19d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a1a1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a1a8:	0f 85 32 fe ff ff    	jne    9fe0 <fwp_main_thread+0xb80>
    a1ae:	4c 89 f7             	mov    %r14,%rdi
    a1b1:	e8 5a b1 ff ff       	call   5310 <fwp_rc_forget_slot>
    a1b6:	41 c6 06 fe          	movb   $0xfe,(%r14)
    a1ba:	e9 21 fe ff ff       	jmp    9fe0 <fwp_main_thread+0xb80>
    a1bf:	90                   	nop
    a1c0:	e8 2b b0 ff ff       	call   51f0 <fwp_rc_wide_dup>
    a1c5:	e9 68 fc ff ff       	jmp    9e32 <fwp_main_thread+0x9d2>
    a1ca:	48 83 3d 66 55 01 00 	cmpq   $0x0,0x15566(%rip)        # 1f738 <fwp_root>
    a1d1:	00 
    a1d2:	c7 05 a4 4e 01 00 00 	movl   $0x0,0x14ea4(%rip)        # 1f080 <fwp_exit_code>
    a1d9:	00 00 00 
    a1dc:	0f 84 d4 f6 ff ff    	je     98b6 <fwp_main_thread+0x456>
    a1e2:	e9 64 95 ff ff       	jmp    374b <fwp_main_thread.cold>
    a1e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1ee:	00 00 
    a1f0:	48 89 df             	mov    %rbx,%rdi
    a1f3:	e8 18 b1 ff ff       	call   5310 <fwp_rc_forget_slot>
    a1f8:	e9 b8 fa ff ff       	jmp    9cb5 <fwp_main_thread+0x855>
    a1fd:	48 89 df             	mov    %rbx,%rdi
    a200:	e8 0b b1 ff ff       	call   5310 <fwp_rc_forget_slot>
    a205:	e9 3d fb ff ff       	jmp    9d47 <fwp_main_thread+0x8e7>
    a20a:	48 89 df             	mov    %rbx,%rdi
    a20d:	e8 fe b0 ff ff       	call   5310 <fwp_rc_forget_slot>
    a212:	e9 ca fb ff ff       	jmp    9de1 <fwp_main_thread+0x981>
    a217:	48 8d 3d 2a 16 00 00 	lea    0x162a(%rip),%rdi        # b848 <_IO_stdin_used+0x848>
    a21e:	e8 7d 9f ff ff       	call   41a0 <fwp_trap>
    a223:	48 8d 3d 94 0f 00 00 	lea    0xf94(%rip),%rdi        # b1be <_IO_stdin_used+0x1be>
    a22a:	e8 71 9f ff ff       	call   41a0 <fwp_trap>
    a22f:	e8 2c 92 ff ff       	call   3460 <__stack_chk_fail@plt>
    a234:	48 8d 3d 3d 15 00 00 	lea    0x153d(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    a23b:	e8 60 9f ff ff       	call   41a0 <fwp_trap>
    a240:	e9 06 95 ff ff       	jmp    374b <fwp_main_thread.cold>
    a245:	e9 01 95 ff ff       	jmp    374b <fwp_main_thread.cold>
    a24a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000000a250 <__divmodti4>:
    a250:	f3 0f 1e fa          	endbr64
    a254:	55                   	push   %rbp
    a255:	49 89 f1             	mov    %rsi,%r9
    a258:	49 89 d2             	mov    %rdx,%r10
    a25b:	48 89 fe             	mov    %rdi,%rsi
    a25e:	49 89 cb             	mov    %rcx,%r11
    a261:	48 89 e5             	mov    %rsp,%rbp
    a264:	41 57                	push   %r15
    a266:	41 56                	push   %r14
    a268:	41 55                	push   %r13
    a26a:	41 54                	push   %r12
    a26c:	53                   	push   %rbx
    a26d:	4c 89 c3             	mov    %r8,%rbx
    a270:	45 31 c0             	xor    %r8d,%r8d
    a273:	4d 85 c9             	test   %r9,%r9
    a276:	79 12                	jns    a28a <__divmodti4+0x3a>
    a278:	31 ff                	xor    %edi,%edi
    a27a:	48 f7 de             	neg    %rsi
    a27d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a284:	4c 19 cf             	sbb    %r9,%rdi
    a287:	49 89 f9             	mov    %rdi,%r9
    a28a:	4c 89 d8             	mov    %r11,%rax
    a28d:	4d 85 db             	test   %r11,%r11
    a290:	0f 88 1a 01 00 00    	js     a3b0 <__divmodti4+0x160>
    a296:	4c 89 d9             	mov    %r11,%rcx
    a299:	49 89 f3             	mov    %rsi,%r11
    a29c:	75 62                	jne    a300 <__divmodti4+0xb0>
    a29e:	4d 89 c4             	mov    %r8,%r12
    a2a1:	4d 39 d1             	cmp    %r10,%r9
    a2a4:	0f 83 46 01 00 00    	jae    a3f0 <__divmodti4+0x1a0>
    a2aa:	4c 89 d8             	mov    %r11,%rax
    a2ad:	4c 89 ca             	mov    %r9,%rdx
    a2b0:	49 f7 f2             	div    %r10
    a2b3:	49 89 c3             	mov    %rax,%r11
    a2b6:	31 c0                	xor    %eax,%eax
    a2b8:	48 89 d6             	mov    %rdx,%rsi
    a2bb:	31 ff                	xor    %edi,%edi
    a2bd:	4c 89 d9             	mov    %r11,%rcx
    a2c0:	48 89 c2             	mov    %rax,%rdx
    a2c3:	48 89 c8             	mov    %rcx,%rax
    a2c6:	4d 85 e4             	test   %r12,%r12
    a2c9:	74 0a                	je     a2d5 <__divmodti4+0x85>
    a2cb:	48 f7 d8             	neg    %rax
    a2ce:	48 83 d2 00          	adc    $0x0,%rdx
    a2d2:	48 f7 da             	neg    %rdx
    a2d5:	4d 85 c0             	test   %r8,%r8
    a2d8:	74 0a                	je     a2e4 <__divmodti4+0x94>
    a2da:	48 f7 de             	neg    %rsi
    a2dd:	48 83 d7 00          	adc    $0x0,%rdi
    a2e1:	48 f7 df             	neg    %rdi
    a2e4:	48 89 33             	mov    %rsi,(%rbx)
    a2e7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a2eb:	5b                   	pop    %rbx
    a2ec:	41 5c                	pop    %r12
    a2ee:	41 5d                	pop    %r13
    a2f0:	41 5e                	pop    %r14
    a2f2:	41 5f                	pop    %r15
    a2f4:	5d                   	pop    %rbp
    a2f5:	c3                   	ret
    a2f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a2fd:	00 00 00 
    a300:	4d 89 c4             	mov    %r8,%r12
    a303:	49 39 c1             	cmp    %rax,%r9
    a306:	0f 82 ce 00 00 00    	jb     a3da <__divmodti4+0x18a>
    a30c:	31 ff                	xor    %edi,%edi
    a30e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a313:	48 63 c7             	movslq %edi,%rax
    a316:	be 40 00 00 00       	mov    $0x40,%esi
    a31b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a320:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a325:	48 29 c6             	sub    %rax,%rsi
    a328:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a32d:	48 09 c8             	or     %rcx,%rax
    a330:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a335:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a33a:	49 89 c6             	mov    %rax,%r14
    a33d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a341:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a346:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a34b:	49 09 c1             	or     %rax,%r9
    a34e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a352:	4c 89 c8             	mov    %r9,%rax
    a355:	49 f7 f6             	div    %r14
    a358:	48 89 d1             	mov    %rdx,%rcx
    a35b:	49 89 c3             	mov    %rax,%r11
    a35e:	49 89 c1             	mov    %rax,%r9
    a361:	49 f7 e2             	mul    %r10
    a364:	49 89 c6             	mov    %rax,%r14
    a367:	49 89 d2             	mov    %rdx,%r10
    a36a:	48 39 d1             	cmp    %rdx,%rcx
    a36d:	72 07                	jb     a376 <__divmodti4+0x126>
    a36f:	75 17                	jne    a388 <__divmodti4+0x138>
    a371:	49 39 c7             	cmp    %rax,%r15
    a374:	73 12                	jae    a388 <__divmodti4+0x138>
    a376:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a37a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a37e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a382:	49 89 d2             	mov    %rdx,%r10
    a385:	49 89 c6             	mov    %rax,%r14
    a388:	4c 89 f8             	mov    %r15,%rax
    a38b:	4c 29 f0             	sub    %r14,%rax
    a38e:	4c 19 d1             	sbb    %r10,%rcx
    a391:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a396:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a39b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a3a0:	48 09 c6             	or     %rax,%rsi
    a3a3:	48 89 cf             	mov    %rcx,%rdi
    a3a6:	31 c0                	xor    %eax,%eax
    a3a8:	4c 89 c9             	mov    %r9,%rcx
    a3ab:	e9 10 ff ff ff       	jmp    a2c0 <__divmodti4+0x70>
    a3b0:	4c 89 d0             	mov    %r10,%rax
    a3b3:	4c 89 da             	mov    %r11,%rdx
    a3b6:	4d 89 c4             	mov    %r8,%r12
    a3b9:	49 89 f3             	mov    %rsi,%r11
    a3bc:	48 f7 d8             	neg    %rax
    a3bf:	49 f7 d4             	not    %r12
    a3c2:	48 83 d2 00          	adc    $0x0,%rdx
    a3c6:	49 89 c2             	mov    %rax,%r10
    a3c9:	48 f7 da             	neg    %rdx
    a3cc:	48 89 d1             	mov    %rdx,%rcx
    a3cf:	0f 84 cc fe ff ff    	je     a2a1 <__divmodti4+0x51>
    a3d5:	49 39 d1             	cmp    %rdx,%r9
    a3d8:	73 46                	jae    a420 <__divmodti4+0x1d0>
    a3da:	4c 89 cf             	mov    %r9,%rdi
    a3dd:	31 c0                	xor    %eax,%eax
    a3df:	31 c9                	xor    %ecx,%ecx
    a3e1:	e9 da fe ff ff       	jmp    a2c0 <__divmodti4+0x70>
    a3e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a3ed:	00 00 00 
    a3f0:	4d 85 d2             	test   %r10,%r10
    a3f3:	75 0d                	jne    a402 <__divmodti4+0x1b2>
    a3f5:	b8 01 00 00 00       	mov    $0x1,%eax
    a3fa:	31 d2                	xor    %edx,%edx
    a3fc:	49 f7 f2             	div    %r10
    a3ff:	49 89 c2             	mov    %rax,%r10
    a402:	4c 89 c8             	mov    %r9,%rax
    a405:	31 d2                	xor    %edx,%edx
    a407:	49 f7 f2             	div    %r10
    a40a:	49 89 c1             	mov    %rax,%r9
    a40d:	4c 89 d8             	mov    %r11,%rax
    a410:	49 f7 f2             	div    %r10
    a413:	49 89 c3             	mov    %rax,%r11
    a416:	4c 89 c8             	mov    %r9,%rax
    a419:	e9 9a fe ff ff       	jmp    a2b8 <__divmodti4+0x68>
    a41e:	66 90                	xchg   %ax,%ax
    a420:	45 31 f6             	xor    %r14d,%r14d
    a423:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a428:	44 89 f7             	mov    %r14d,%edi
    a42b:	45 85 f6             	test   %r14d,%r14d
    a42e:	0f 85 df fe ff ff    	jne    a313 <__divmodti4+0xc3>
    a434:	4c 39 ca             	cmp    %r9,%rdx
    a437:	72 17                	jb     a450 <__divmodti4+0x200>
    a439:	31 c9                	xor    %ecx,%ecx
    a43b:	48 39 c6             	cmp    %rax,%rsi
    a43e:	73 10                	jae    a450 <__divmodti4+0x200>
    a440:	4c 89 cf             	mov    %r9,%rdi
    a443:	31 c0                	xor    %eax,%eax
    a445:	e9 76 fe ff ff       	jmp    a2c0 <__divmodti4+0x70>
    a44a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a450:	4c 89 de             	mov    %r11,%rsi
    a453:	b9 01 00 00 00       	mov    $0x1,%ecx
    a458:	48 29 c6             	sub    %rax,%rsi
    a45b:	49 19 d1             	sbb    %rdx,%r9
    a45e:	eb e0                	jmp    a440 <__divmodti4+0x1f0>

000000000000a460 <atexit>:
    a460:	f3 0f 1e fa          	endbr64
    a464:	48 8b 15 9d 4b 00 00 	mov    0x4b9d(%rip),%rdx        # f008 <__dso_handle>
    a46b:	31 f6                	xor    %esi,%esi
    a46d:	e9 ee 91 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a474 <_fini>:
    a474:	f3 0f 1e fa          	endbr64
    a478:	48 83 ec 08          	sub    $0x8,%rsp
    a47c:	48 83 c4 08          	add    $0x8,%rsp
    a480:	c3                   	ret
