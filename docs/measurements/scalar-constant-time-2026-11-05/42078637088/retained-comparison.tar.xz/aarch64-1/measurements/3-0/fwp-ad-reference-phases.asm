
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000025 	adrp	x5, 9000 <__divti3+0x370>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	9119a0a5 	add	x5, x5, #0x668
    2b20:	f0000024 	adrp	x4, 9000 <__divti3+0x370>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	9119c084 	add	x4, x4, #0x670
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	91018261 	add	x1, x19, #0x60
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x12c30>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	f0000020 	adrp	x0, 9000 <__divti3+0x370>
    2bb4:	91264000 	add	x0, x0, #0x990
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000022 	adrp	x2, 8000 <fwp_write+0xefc>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	9103c042 	add	x2, x2, #0xf0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	91018273 	add	x19, x19, #0x60
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9437a60 	ldr	w0, [x19, #888]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	f0000020 	adrp	x0, 9000 <__divti3+0x370>
    2cfc:	91268000 	add	x0, x0, #0x9a0
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	f0000020 	adrp	x0, 9000 <__divti3+0x370>
    2d0c:	91290000 	add	x0, x0, #0xa40
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	f0000020 	adrp	x0, 9000 <__divti3+0x370>
    2d24:	91286000 	add	x0, x0, #0xa18
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	f0000020 	adrp	x0, 9000 <__divti3+0x370>
    2d30:	9127a000 	add	x0, x0, #0x9e8
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	f0000020 	adrp	x0, 9000 <__divti3+0x370>
    2d3c:	91270000 	add	x0, x0, #0x9c0
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91014000 	add	x0, x0, #0x50
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91014021 	add	x1, x1, #0x50
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91014000 	add	x0, x0, #0x50
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91014021 	add	x1, x1, #0x50
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39414260 	ldrb	w0, [x19, #80]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39014260 	strb	w0, [x19, #80]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	90000041 	adrp	x1, a000 <_IO_stdin_used+0xc50>
    2f34:	91030021 	add	x1, x1, #0xc0
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403084 	ldr	x4, [x4, #96]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403063 	ldr	x3, [x3, #96]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403400 	ldr	x0, [x0, #104]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    30d0:	910ee000 	add	x0, x0, #0x3b8
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	91018043 	add	x3, x2, #0x60
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	91018042 	add	x2, x2, #0x60
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0xc50>
    3198:	91028021 	add	x1, x1, #0xa0
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    31d0:	910f4000 	add	x0, x0, #0x3d0
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	91018294 	add	x20, x20, #0x60
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	d0000022 	adrp	x2, 9000 <__divti3+0x370>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	d0000036 	adrp	x22, 9000 <__divti3+0x370>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	d0000038 	adrp	x24, 9000 <__divti3+0x370>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	91106042 	add	x2, x2, #0x418
    3260:	9111c2d6 	add	x22, x22, #0x470
    3264:	91392318 	add	x24, x24, #0xe48
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	d0000039 	adrp	x25, 9000 <__divti3+0x370>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	9111a323 	add	x3, x25, #0x468
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	91120000 	add	x0, x0, #0x480
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc00>
    3344:	911782a1 	add	x1, x21, #0x5e0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa20>
    3358:	912740a5 	add	x5, x5, #0x9d0
    335c:	911782a1 	add	x1, x21, #0x5e0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911782b7 	add	x23, x21, #0x5e0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911782b5 	add	x21, x21, #0x5e0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911782b5 	add	x21, x21, #0x5e0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa20>
    34e8:	912720a5 	add	x5, x5, #0x9c8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    35f0:	910ee000 	add	x0, x0, #0x3b8
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	91018022 	add	x2, x1, #0x60
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	91018023 	add	x3, x1, #0x60
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	91018021 	add	x1, x1, #0x60
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	91018022 	add	x2, x1, #0x60
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	91018021 	add	x1, x1, #0x60
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	d0000021 	adrp	x1, 9000 <__divti3+0x370>
    3830:	aa1303e0 	mov	x0, x19
    3834:	91122021 	add	x1, x1, #0x488
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000021 	adrp	x1, 9000 <__divti3+0x370>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91124021 	add	x1, x1, #0x490
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000021 	adrp	x1, 9000 <__divti3+0x370>
    3860:	91126021 	add	x1, x1, #0x498
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	d0000022 	adrp	x2, 9000 <__divti3+0x370>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	91128042 	add	x2, x2, #0x4a0
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    39d0:	910ee000 	add	x0, x0, #0x3b8
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    39f0:	9112c000 	add	x0, x0, #0x4b0
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    3a88:	91134000 	add	x0, x0, #0x4d0
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    3a98:	9113c000 	add	x0, x0, #0x4f0
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0xc50>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc03420 	ldr	q0, [x1, #208]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	910182b5 	add	x21, x21, #0x60
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    3b98:	91146000 	add	x0, x0, #0x518
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	91018062 	add	x2, x3, #0x60
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403063 	ldr	x3, [x3, #96]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	d0000020 	adrp	x0, 9000 <__divti3+0x370>
    3c08:	91152000 	add	x0, x0, #0x548
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	d0000024 	adrp	x4, 9000 <__divti3+0x370>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	91166084 	add	x4, x4, #0x598
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	d0000024 	adrp	x4, 9000 <__divti3+0x370>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	9116c084 	add	x4, x4, #0x5b0
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	d0000024 	adrp	x4, 9000 <__divti3+0x370>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	91168084 	add	x4, x4, #0x5a0
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xc00>
    4028:	91178042 	add	x2, x2, #0x5e0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	b0000021 	adrp	x1, 9000 <__divti3+0x370>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	9116e021 	add	x1, x1, #0x5b8
    4084:	91170000 	add	x0, x0, #0x5c0
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	b0000022 	adrp	x2, 9000 <__divti3+0x370>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	91178042 	add	x2, x2, #0x5e0
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa20>
    418c:	91138061 	add	x1, x3, #0x4e0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc00>
    419c:	91178262 	add	x2, x19, #0x5e0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	d0000022 	adrp	x2, a000 <_IO_stdin_used+0xc50>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa20>
    41cc:	91148021 	add	x1, x1, #0x520
    41d0:	3dc03843 	ldr	q3, [x2, #224]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa20>
    41fc:	91138063 	add	x3, x3, #0x4e0
    4200:	91160084 	add	x4, x4, #0x580
    4204:	91178266 	add	x6, x19, #0x5e0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	91178275 	add	x21, x19, #0x5e0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    42e8:	911a4000 	add	x0, x0, #0x690
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	91178273 	add	x19, x19, #0x5e0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <caf75>:
    4344:	900000e2 	adrp	x2, 20000 <__data_start>
    4348:	91018041 	add	x1, x2, #0x60
    434c:	b9409820 	ldr	w0, [x1, #152]
    4350:	34000060 	cbz	w0, 435c <caf75+0x18>
    4354:	f9405020 	ldr	x0, [x1, #160]
    4358:	d65f03c0 	ret
    435c:	b940a820 	ldr	w0, [x1, #168]
    4360:	340000e0 	cbz	w0, 437c <caf75+0x38>
    4364:	f9405820 	ldr	x0, [x1, #176]
    4368:	91018042 	add	x2, x2, #0x60
    436c:	52800021 	mov	w1, #0x1                   	// #1
    4370:	b9009841 	str	w1, [x2, #152]
    4374:	f9005040 	str	x0, [x2, #160]
    4378:	d65f03c0 	ret
    437c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4380:	52800024 	mov	w4, #0x1                   	// #1
    4384:	aa0303e0 	mov	x0, x3
    4388:	b900a824 	str	w4, [x1, #168]
    438c:	f9005823 	str	x3, [x1, #176]
    4390:	17fffff6 	b	4368 <caf75+0x24>

0000000000004394 <fwp_wake_io>:
    4394:	900000e9 	adrp	x9, 20000 <__data_start>
    4398:	91018122 	add	x2, x9, #0x60
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	5280000a 	mov	w10, #0x0                   	// #0
    43a4:	f9403c46 	ldr	x6, [x2, #120]
    43a8:	52800008 	mov	w8, #0x0                   	// #0
    43ac:	4f000400 	movi	v0.4s, #0x0
    43b0:	52800027 	mov	w7, #0x1                   	// #1
    43b4:	aa0103e2 	mov	x2, x1
    43b8:	b4000321 	cbz	x1, 441c <fwp_wake_io+0x88>
    43bc:	f9408c25 	ldr	x5, [x1, #280]
    43c0:	39015c27 	strb	w7, [x1, #87]
    43c4:	b4000165 	cbz	x5, 43f0 <fwp_wake_io+0x5c>
    43c8:	a9520c24 	ldp	x4, x3, [x1, #288]
    43cc:	b4000364 	cbz	x4, 4438 <fwp_wake_io+0xa4>
    43d0:	f9009483 	str	x3, [x4, #296]
    43d4:	f9409423 	ldr	x3, [x1, #296]
    43d8:	b4000043 	cbz	x3, 43e0 <fwp_wake_io+0x4c>
    43dc:	f9009064 	str	x4, [x3, #288]
    43e0:	91080023 	add	x3, x1, #0x200
    43e4:	f900943f 	str	xzr, [x1, #296]
    43e8:	3c918060 	stur	q0, [x3, #-232]
    43ec:	f9400001 	ldr	x1, [x0]
    43f0:	f9402843 	ldr	x3, [x2, #80]
    43f4:	f2001c7f 	tst	x3, #0xff000000ff
    43f8:	54fffde1 	b.ne	43b4 <fwp_wake_io+0x20>  // b.any
    43fc:	39015047 	strb	w7, [x2, #84]
    4400:	f900805f 	str	xzr, [x2, #256]
    4404:	b40001e6 	cbz	x6, 4440 <fwp_wake_io+0xac>
    4408:	f90080c2 	str	x2, [x6, #256]
    440c:	aa0203e6 	mov	x6, x2
    4410:	52800028 	mov	w8, #0x1                   	// #1
    4414:	aa0103e2 	mov	x2, x1
    4418:	b5fffd21 	cbnz	x1, 43bc <fwp_wake_io+0x28>
    441c:	3400006a 	cbz	w10, 4428 <fwp_wake_io+0x94>
    4420:	91018120 	add	x0, x9, #0x60
    4424:	f900400b 	str	x11, [x0, #128]
    4428:	34000068 	cbz	w8, 4434 <fwp_wake_io+0xa0>
    442c:	91018129 	add	x9, x9, #0x60
    4430:	f9003d26 	str	x6, [x9, #120]
    4434:	d65f03c0 	ret
    4438:	f90000a3 	str	x3, [x5]
    443c:	17ffffe7 	b	43d8 <fwp_wake_io+0x44>
    4440:	aa0203eb 	mov	x11, x2
    4444:	5280002a 	mov	w10, #0x1                   	// #1
    4448:	17fffff1 	b	440c <fwp_wake_io+0x78>
    444c:	d503201f 	nop

0000000000004450 <fwp_tape_buffers_release>:
    4450:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4454:	910003fd 	mov	x29, sp
    4458:	a90153f3 	stp	x19, x20, [sp, #16]
    445c:	aa0003f3 	mov	x19, x0
    4460:	f9401400 	ldr	x0, [x0, #40]
    4464:	b7f80760 	tbnz	x0, #63, 4550 <fwp_tape_buffers_release+0x100>
    4468:	f9401a61 	ldr	x1, [x19, #48]
    446c:	b7f80301 	tbnz	x1, #63, 44cc <fwp_tape_buffers_release+0x7c>
    4470:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4474:	eb02001f 	cmp	x0, x2
    4478:	540002a8 	b.hi	44cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    447c:	8b000400 	add	x0, x0, x0, lsl #1
    4480:	d2a00102 	mov	x2, #0x80000               	// #524288
    4484:	d37df000 	lsl	x0, x0, #3
    4488:	cb000042 	sub	x2, x2, x0
    448c:	eb420c3f 	cmp	x1, x2, lsr #3
    4490:	540001e8 	b.hi	44cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    4494:	8b010c14 	add	x20, x0, x1, lsl #3
    4498:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    449c:	911a8000 	add	x0, x0, #0x6a0
    44a0:	97fff980 	bl	2aa0 <getenv@plt>
    44a4:	b4000240 	cbz	x0, 44ec <fwp_tape_buffers_release+0x9c>
    44a8:	39400001 	ldrb	w1, [x0]
    44ac:	7100c03f 	cmp	w1, #0x30
    44b0:	540001e1 	b.ne	44ec <fwp_tape_buffers_release+0x9c>  // b.any
    44b4:	39400400 	ldrb	w0, [x0, #1]
    44b8:	350001a0 	cbnz	w0, 44ec <fwp_tape_buffers_release+0x9c>
    44bc:	aa1303e0 	mov	x0, x19
    44c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44c8:	17fffc0e 	b	3500 <fwp_tape_buffers_dispose>
    44cc:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    44d0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    44d4:	911a8000 	add	x0, x0, #0x6a0
    44d8:	97fff972 	bl	2aa0 <getenv@plt>
    44dc:	b4ffff00 	cbz	x0, 44bc <fwp_tape_buffers_release+0x6c>
    44e0:	39400001 	ldrb	w1, [x0]
    44e4:	7100c03f 	cmp	w1, #0x30
    44e8:	54fffe60 	b.eq	44b4 <fwp_tape_buffers_release+0x64>  // b.none
    44ec:	d1000681 	sub	x1, x20, #0x1
    44f0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44f4:	eb00003f 	cmp	x1, x0
    44f8:	54fffe28 	b.hi	44bc <fwp_tape_buffers_release+0x6c>  // b.pmore
    44fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4500:	900000f6 	adrp	x22, 20000 <__data_start>
    4504:	910182d6 	add	x22, x22, #0x60
    4508:	9102e2d5 	add	x21, x22, #0xb8
    450c:	aa1503e0 	mov	x0, x21
    4510:	97fffbfc 	bl	3500 <fwp_tape_buffers_dispose>
    4514:	ad400a61 	ldp	q1, q2, [x19]
    4518:	f9007ad4 	str	x20, [x22, #240]
    451c:	4f000400 	movi	v0.4s, #0x0
    4520:	ad000aa1 	stp	q1, q2, [x21]
    4524:	3dc00a61 	ldr	q1, [x19, #32]
    4528:	3d800aa1 	str	q1, [x21, #32]
    452c:	f9401a60 	ldr	x0, [x19, #48]
    4530:	f9001aa0 	str	x0, [x21, #48]
    4534:	f9001a7f 	str	xzr, [x19, #48]
    4538:	ad000260 	stp	q0, q0, [x19]
    453c:	3d800a60 	str	q0, [x19, #32]
    4540:	a94153f3 	ldp	x19, x20, [sp, #16]
    4544:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4548:	a8c37bfd 	ldp	x29, x30, [sp], #48
    454c:	d65f03c0 	ret
    4550:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    4554:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4558:	911a8000 	add	x0, x0, #0x6a0
    455c:	97fff951 	bl	2aa0 <getenv@plt>
    4560:	b5fffa40 	cbnz	x0, 44a8 <fwp_tape_buffers_release+0x58>
    4564:	17ffffd6 	b	44bc <fwp_tape_buffers_release+0x6c>
    4568:	d503201f 	nop
    456c:	d503201f 	nop

0000000000004570 <fwp_poll_events>:
    4570:	d10103ff 	sub	sp, sp, #0x40
    4574:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4578:	f947f400 	ldr	x0, [x0, #4072]
    457c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4580:	910083fd 	add	x29, sp, #0x20
    4584:	a90353f3 	stp	x19, x20, [sp, #48]
    4588:	900000f4 	adrp	x20, 20000 <__data_start>
    458c:	f9400001 	ldr	x1, [x0]
    4590:	f9000fe1 	str	x1, [sp, #24]
    4594:	d2800001 	mov	x1, #0x0                   	// #0
    4598:	97fffd1a 	bl	3a00 <fwp_now_ns>
    459c:	91018281 	add	x1, x20, #0x60
    45a0:	f9407c33 	ldr	x19, [x1, #248]
    45a4:	b4000e93 	cbz	x19, 4774 <fwp_poll_events+0x204>
    45a8:	aa1303e1 	mov	x1, x19
    45ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    45b0:	14000005 	b	45c4 <fwp_poll_events+0x54>
    45b4:	f9408821 	ldr	x1, [x1, #272]
    45b8:	eb03005f 	cmp	x2, x3
    45bc:	9a83d042 	csel	x2, x2, x3, le
    45c0:	b40000c1 	cbz	x1, 45d8 <fwp_poll_events+0x68>
    45c4:	f9403423 	ldr	x3, [x1, #104]
    45c8:	b6ffff62 	tbz	x2, #63, 45b4 <fwp_poll_events+0x44>
    45cc:	f9408821 	ldr	x1, [x1, #272]
    45d0:	aa0303e2 	mov	x2, x3
    45d4:	b5ffff81 	cbnz	x1, 45c4 <fwp_poll_events+0x54>
    45d8:	b7f80ce2 	tbnz	x2, #63, 4774 <fwp_poll_events+0x204>
    45dc:	cb000042 	sub	x2, x2, x0
    45e0:	f100005f 	cmp	x2, #0x0
    45e4:	540005cd 	b.le	469c <fwp_poll_events+0x12c>
    45e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    45ec:	d2884801 	mov	x1, #0x4240                	// #16960
    45f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4600:	f2e86360 	movk	x0, #0x431b, lsl #48
    4604:	9b407c40 	smulh	x0, x2, x0
    4608:	9352fc00 	asr	x0, x0, #18
    460c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4610:	9b018802 	msub	x2, x0, x1, x2
    4614:	f100005f 	cmp	x2, #0x0
    4618:	9a800400 	cinc	x0, x0, ne	// ne = any
    461c:	eb03001f 	cmp	x0, x3
    4620:	54000a0c 	b.gt	4760 <fwp_poll_events+0x1f0>
    4624:	340003c0 	cbz	w0, 469c <fwp_poll_events+0x12c>
    4628:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    462c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4630:	72a20c42 	movk	w2, #0x1062, lsl #16
    4634:	9ba27c02 	umull	x2, w0, w2
    4638:	d366fc43 	lsr	x3, x2, #38
    463c:	aa0303e2 	mov	x2, x3
    4640:	1b048063 	msub	w3, w3, w4, w0
    4644:	9b217c63 	smull	x3, w3, w1
    4648:	d2800001 	mov	x1, #0x0                   	// #0
    464c:	910023e0 	add	x0, sp, #0x8
    4650:	a9008fe2 	stp	x2, x3, [sp, #8]
    4654:	97fff8e3 	bl	29e0 <nanosleep@plt>
    4658:	91018280 	add	x0, x20, #0x60
    465c:	f9407c13 	ldr	x19, [x0, #248]
    4660:	97fffce8 	bl	3a00 <fwp_now_ns>
    4664:	aa0003e6 	mov	x6, x0
    4668:	b50001f3 	cbnz	x19, 46a4 <fwp_poll_events+0x134>
    466c:	d503201f 	nop
    4670:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4674:	f947f400 	ldr	x0, [x0, #4072]
    4678:	f9400fe2 	ldr	x2, [sp, #24]
    467c:	f9400001 	ldr	x1, [x0]
    4680:	eb010042 	subs	x2, x2, x1
    4684:	d2800001 	mov	x1, #0x0                   	// #0
    4688:	540008c1 	b.ne	47a0 <fwp_poll_events+0x230>  // b.any
    468c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4690:	a94353f3 	ldp	x19, x20, [sp, #48]
    4694:	910103ff 	add	sp, sp, #0x40
    4698:	d65f03c0 	ret
    469c:	97fffcd9 	bl	3a00 <fwp_now_ns>
    46a0:	aa0003e6 	mov	x6, x0
    46a4:	4f000400 	movi	v0.4s, #0x0
    46a8:	91018288 	add	x8, x20, #0x60
    46ac:	52800027 	mov	w7, #0x1                   	// #1
    46b0:	f9403661 	ldr	x1, [x19, #104]
    46b4:	aa1303e5 	mov	x5, x19
    46b8:	f9408a73 	ldr	x19, [x19, #272]
    46bc:	eb06003f 	cmp	x1, x6
    46c0:	5400032c 	b.gt	4724 <fwp_poll_events+0x1b4>
    46c4:	394154a0 	ldrb	w0, [x5, #85]
    46c8:	36000120 	tbz	w0, #0, 46ec <fwp_poll_events+0x17c>
    46cc:	f94084a0 	ldr	x0, [x5, #264]
    46d0:	b40003c0 	cbz	x0, 4748 <fwp_poll_events+0x1d8>
    46d4:	f9008813 	str	x19, [x0, #272]
    46d8:	b4000053 	cbz	x19, 46e0 <fwp_poll_events+0x170>
    46dc:	f9008660 	str	x0, [x19, #264]
    46e0:	910800a0 	add	x0, x5, #0x200
    46e4:	390154bf 	strb	wzr, [x5, #85]
    46e8:	3c908000 	stur	q0, [x0, #-248]
    46ec:	f94030a0 	ldr	x0, [x5, #96]
    46f0:	390158a7 	strb	w7, [x5, #86]
    46f4:	f100001f 	cmp	x0, #0x0
    46f8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46fc:	5400018d 	b.le	472c <fwp_poll_events+0x1bc>
    4700:	f94028a0 	ldr	x0, [x5, #80]
    4704:	f2001c1f 	tst	x0, #0xff000000ff
    4708:	540000e1 	b.ne	4724 <fwp_poll_events+0x1b4>  // b.any
    470c:	f9403d00 	ldr	x0, [x8, #120]
    4710:	390150a7 	strb	w7, [x5, #84]
    4714:	f90080bf 	str	xzr, [x5, #256]
    4718:	b40001e0 	cbz	x0, 4754 <fwp_poll_events+0x1e4>
    471c:	f9003d05 	str	x5, [x8, #120]
    4720:	f9008005 	str	x5, [x0, #256]
    4724:	b5fffc73 	cbnz	x19, 46b0 <fwp_poll_events+0x140>
    4728:	17ffffd2 	b	4670 <fwp_poll_events+0x100>
    472c:	394144a0 	ldrb	w0, [x5, #81]
    4730:	3707fe80 	tbnz	w0, #0, 4700 <fwp_poll_events+0x190>
    4734:	394140a0 	ldrb	w0, [x5, #80]
    4738:	3707fe40 	tbnz	w0, #0, 4700 <fwp_poll_events+0x190>
    473c:	aa0503e0 	mov	x0, x5
    4740:	97fffc0c 	bl	3770 <fwp_cancel_tree.part.0>
    4744:	17ffffef 	b	4700 <fwp_poll_events+0x190>
    4748:	91018281 	add	x1, x20, #0x60
    474c:	f9007c33 	str	x19, [x1, #248]
    4750:	17ffffe2 	b	46d8 <fwp_poll_events+0x168>
    4754:	f9003d05 	str	x5, [x8, #120]
    4758:	f9004105 	str	x5, [x8, #128]
    475c:	17fffff2 	b	4724 <fwp_poll_events+0x1b4>
    4760:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4764:	d2989362 	mov	x2, #0xc49b                	// #50331
    4768:	f2a4d203 	movk	x3, #0x2690, lsl #16
    476c:	f2a00402 	movk	x2, #0x20, lsl #16
    4770:	17ffffb6 	b	4648 <fwp_poll_events+0xd8>
    4774:	97fffa3f 	bl	3070 <fwp_flush>
    4778:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    477c:	f947e863 	ldr	x3, [x3, #4048]
    4780:	d2800562 	mov	x2, #0x2b                  	// #43
    4784:	d2800021 	mov	x1, #0x1                   	// #1
    4788:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    478c:	911ae000 	add	x0, x0, #0x6b8
    4790:	f9400063 	ldr	x3, [x3]
    4794:	97fff89f 	bl	2a10 <fwrite@plt>
    4798:	52800ca0 	mov	w0, #0x65                  	// #101
    479c:	97fff809 	bl	27c0 <exit@plt>
    47a0:	97fff85c 	bl	2910 <__stack_chk_fail@plt>

00000000000047a4 <fwp_rc_wide_dup>:
    47a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    47a8:	910003fd 	mov	x29, sp
    47ac:	a90153f3 	stp	x19, x20, [sp, #16]
    47b0:	aa0003f3 	mov	x19, x0
    47b4:	ca404400 	eor	x0, x0, x0, lsr #17
    47b8:	f90013f5 	str	x21, [sp, #32]
    47bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc00>
    47c0:	ca402400 	eor	x0, x0, x0, lsr #9
    47c4:	911782a2 	add	x2, x21, #0x5e0
    47c8:	92401c00 	and	x0, x0, #0xff
    47cc:	910a2403 	add	x3, x0, #0x289
    47d0:	8b000c40 	add	x0, x2, x0, lsl #3
    47d4:	8b030c54 	add	x20, x2, x3, lsl #3
    47d8:	f94a2401 	ldr	x1, [x0, #5192]
    47dc:	b50000a1 	cbnz	x1, 47f0 <fwp_rc_wide_dup+0x4c>
    47e0:	1400002d 	b	4894 <fwp_rc_wide_dup+0xf0>
    47e4:	91004034 	add	x20, x1, #0x10
    47e8:	f9400821 	ldr	x1, [x1, #16]
    47ec:	b4000241 	cbz	x1, 4834 <fwp_rc_wide_dup+0x90>
    47f0:	f9400022 	ldr	x2, [x1]
    47f4:	eb02027f 	cmp	x19, x2
    47f8:	54ffff61 	b.ne	47e4 <fwp_rc_wide_dup+0x40>  // b.any
    47fc:	f9400281 	ldr	x1, [x20]
    4800:	39400260 	ldrb	w0, [x19]
    4804:	7103f81f 	cmp	w0, #0xfe
    4808:	54000220 	b.eq	484c <fwp_rc_wide_dup+0xa8>  // b.none
    480c:	b40001a1 	cbz	x1, 4840 <fwp_rc_wide_dup+0x9c>
    4810:	f9400420 	ldr	x0, [x1, #8]
    4814:	b100041f 	cmn	x0, #0x1
    4818:	540004a0 	b.eq	48ac <fwp_rc_wide_dup+0x108>  // b.none
    481c:	91000400 	add	x0, x0, #0x1
    4820:	f9000420 	str	x0, [x1, #8]
    4824:	a94153f3 	ldp	x19, x20, [sp, #16]
    4828:	f94013f5 	ldr	x21, [sp, #32]
    482c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4830:	d65f03c0 	ret
    4834:	39400260 	ldrb	w0, [x19]
    4838:	7103f81f 	cmp	w0, #0xfe
    483c:	540000a0 	b.eq	4850 <fwp_rc_wide_dup+0xac>  // b.none
    4840:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    4844:	911c4000 	add	x0, x0, #0x710
    4848:	97fffc0e 	bl	3880 <fwp_trap>
    484c:	b5000281 	cbnz	x1, 489c <fwp_rc_wide_dup+0xf8>
    4850:	d2800300 	mov	x0, #0x18                  	// #24
    4854:	97fff817 	bl	28b0 <malloc@plt>
    4858:	b4000280 	cbz	x0, 48a8 <fwp_rc_wide_dup+0x104>
    485c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4860:	a9000413 	stp	x19, x1, [x0]
    4864:	911782b5 	add	x21, x21, #0x5e0
    4868:	f900081f 	str	xzr, [x0, #16]
    486c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4870:	f9000280 	str	x0, [x20]
    4874:	39000261 	strb	w1, [x19]
    4878:	f94e26a0 	ldr	x0, [x21, #7240]
    487c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4880:	91000400 	add	x0, x0, #0x1
    4884:	f90e26a0 	str	x0, [x21, #7240]
    4888:	f94013f5 	ldr	x21, [sp, #32]
    488c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4890:	d65f03c0 	ret
    4894:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4898:	17ffffda 	b	4800 <fwp_rc_wide_dup+0x5c>
    489c:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    48a0:	911ba000 	add	x0, x0, #0x6e8
    48a4:	97fffbf7 	bl	3880 <fwp_trap>
    48a8:	97fffa02 	bl	30b0 <fwp_heap_oom>
    48ac:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    48b0:	911ce000 	add	x0, x0, #0x738
    48b4:	97fffbf3 	bl	3880 <fwp_trap>
    48b8:	d503201f 	nop
    48bc:	d503201f 	nop

00000000000048c0 <fwp_rc_forget_slot>:
    48c0:	aa0003e1 	mov	x1, x0
    48c4:	39400000 	ldrb	w0, [x0]
    48c8:	7103fc1f 	cmp	w0, #0xff
    48cc:	54000040 	b.eq	48d4 <fwp_rc_forget_slot+0x14>  // b.none
    48d0:	d65f03c0 	ret
    48d4:	ca414420 	eor	x0, x1, x1, lsr #17
    48d8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    48dc:	ca402400 	eor	x0, x0, x0, lsr #9
    48e0:	910003fd 	mov	x29, sp
    48e4:	92401c00 	and	x0, x0, #0xff
    48e8:	f9000bf3 	str	x19, [sp, #16]
    48ec:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc00>
    48f0:	91178262 	add	x2, x19, #0x5e0
    48f4:	910a2403 	add	x3, x0, #0x289
    48f8:	8b000c40 	add	x0, x2, x0, lsl #3
    48fc:	8b030c43 	add	x3, x2, x3, lsl #3
    4900:	f94a2400 	ldr	x0, [x0, #5192]
    4904:	b50000a0 	cbnz	x0, 4918 <fwp_rc_forget_slot+0x58>
    4908:	14000011 	b	494c <fwp_rc_forget_slot+0x8c>
    490c:	91004003 	add	x3, x0, #0x10
    4910:	f9400800 	ldr	x0, [x0, #16]
    4914:	b40001c0 	cbz	x0, 494c <fwp_rc_forget_slot+0x8c>
    4918:	f9400002 	ldr	x2, [x0]
    491c:	eb02003f 	cmp	x1, x2
    4920:	54ffff61 	b.ne	490c <fwp_rc_forget_slot+0x4c>  // b.any
    4924:	f9400801 	ldr	x1, [x0, #16]
    4928:	91178273 	add	x19, x19, #0x5e0
    492c:	f9000061 	str	x1, [x3]
    4930:	97fff828 	bl	29d0 <free@plt>
    4934:	f94e2660 	ldr	x0, [x19, #7240]
    4938:	d1000400 	sub	x0, x0, #0x1
    493c:	f90e2660 	str	x0, [x19, #7240]
    4940:	f9400bf3 	ldr	x19, [sp, #16]
    4944:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4948:	d65f03c0 	ret
    494c:	b0000020 	adrp	x0, 9000 <__divti3+0x370>
    4950:	911c4000 	add	x0, x0, #0x710
    4954:	97fffbcb 	bl	3880 <fwp_trap>
    4958:	d503201f 	nop
    495c:	d503201f 	nop

0000000000004960 <fwp_rc_prepare_chunk>:
    4960:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4964:	910003fd 	mov	x29, sp
    4968:	a9025bf5 	stp	x21, x22, [sp, #32]
    496c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc00>
    4970:	911782c2 	add	x2, x22, #0x5e0
    4974:	b9401c03 	ldr	w3, [x0, #28]
    4978:	aa0103f5 	mov	x21, x1
    497c:	a90153f3 	stp	x19, x20, [sp, #16]
    4980:	aa0003f4 	mov	x20, x0
    4984:	f94e2440 	ldr	x0, [x2, #7240]
    4988:	b4000440 	cbz	x0, 4a10 <fwp_rc_prepare_chunk+0xb0>
    498c:	d2800013 	mov	x19, #0x0                   	// #0
    4990:	35000203 	cbnz	w3, 49d0 <fwp_rc_prepare_chunk+0x70>
    4994:	b4000361 	cbz	x1, 4a00 <fwp_rc_prepare_chunk+0xa0>
    4998:	f9401280 	ldr	x0, [x20, #32]
    499c:	97fff80d 	bl	29d0 <free@plt>
    49a0:	aa1503e0 	mov	x0, x21
    49a4:	d2800021 	mov	x1, #0x1                   	// #1
    49a8:	97fff7d2 	bl	28f0 <calloc@plt>
    49ac:	f9001280 	str	x0, [x20, #32]
    49b0:	b5000460 	cbnz	x0, 4a3c <fwp_rc_prepare_chunk+0xdc>
    49b4:	97fff9bf 	bl	30b0 <fwp_heap_oom>
    49b8:	97ffffc2 	bl	48c0 <fwp_rc_forget_slot>
    49bc:	91000673 	add	x19, x19, #0x1
    49c0:	b9401e83 	ldr	w3, [x20, #28]
    49c4:	eb13007f 	cmp	x3, x19
    49c8:	54000169 	b.ls	49f4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    49cc:	d503201f 	nop
    49d0:	f9401283 	ldr	x3, [x20, #32]
    49d4:	8b130060 	add	x0, x3, x19
    49d8:	38736863 	ldrb	w3, [x3, x19]
    49dc:	7103fc7f 	cmp	w3, #0xff
    49e0:	54fffec0 	b.eq	49b8 <fwp_rc_prepare_chunk+0x58>  // b.none
    49e4:	b9401e83 	ldr	w3, [x20, #28]
    49e8:	91000673 	add	x19, x19, #0x1
    49ec:	eb13007f 	cmp	x3, x19
    49f0:	54ffff08 	b.hi	49d0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49f4:	eb0302bf 	cmp	x21, x3
    49f8:	54000121 	b.ne	4a1c <fwp_rc_prepare_chunk+0xbc>  // b.any
    49fc:	b5000335 	cbnz	x21, 4a60 <fwp_rc_prepare_chunk+0x100>
    4a00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	2a0303e3 	mov	w3, w3
    4a14:	eb0302bf 	cmp	x21, x3
    4a18:	54ffff20 	b.eq	49fc <fwp_rc_prepare_chunk+0x9c>  // b.none
    4a1c:	911782c2 	add	x2, x22, #0x5e0
    4a20:	f9401280 	ldr	x0, [x20, #32]
    4a24:	f94e2841 	ldr	x1, [x2, #7248]
    4a28:	cb030021 	sub	x1, x1, x3
    4a2c:	f90e2841 	str	x1, [x2, #7248]
    4a30:	97fff7e8 	bl	29d0 <free@plt>
    4a34:	b5fffb75 	cbnz	x21, 49a0 <fwp_rc_prepare_chunk+0x40>
    4a38:	f900129f 	str	xzr, [x20, #32]
    4a3c:	911782d6 	add	x22, x22, #0x5e0
    4a40:	f94e2ac0 	ldr	x0, [x22, #7248]
    4a44:	b9001e95 	str	w21, [x20, #28]
    4a48:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a4c:	8b150000 	add	x0, x0, x21
    4a50:	f90e2ac0 	str	x0, [x22, #7248]
    4a54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a5c:	d65f03c0 	ret
    4a60:	f9401280 	ldr	x0, [x20, #32]
    4a64:	aa1503e2 	mov	x2, x21
    4a68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a6c:	52800001 	mov	w1, #0x0                   	// #0
    4a70:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a74:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a78:	17fff79a 	b	28e0 <memset@plt>
    4a7c:	d503201f 	nop

0000000000004a80 <fwp_heap_refill>:
    4a80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a84:	910003fd 	mov	x29, sp
    4a88:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a8c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc00>
    4a90:	911782b5 	add	x21, x21, #0x5e0
    4a94:	aa0003f6 	mov	x22, x0
    4a98:	d2800020 	mov	x0, #0x1                   	// #1
    4a9c:	a90153f3 	stp	x19, x20, [sp, #16]
    4aa0:	a90363f7 	stp	x23, x24, [sp, #48]
    4aa4:	2a0103f7 	mov	w23, w1
    4aa8:	2a0203f8 	mov	w24, w2
    4aac:	97fffa21 	bl	3330 <fwp_heap_chunks>
    4ab0:	aa0003f3 	mov	x19, x0
    4ab4:	f949fea2 	ldr	x2, [x21, #5112]
    4ab8:	8b000800 	add	x0, x0, x0, lsl #2
    4abc:	2a1703e1 	mov	w1, w23
    4ac0:	52800025 	mov	w5, #0x1                   	// #1
    4ac4:	d37df000 	lsl	x0, x0, #3
    4ac8:	910f0021 	add	x1, x1, #0x3c0
    4acc:	8b000054 	add	x20, x2, x0
    4ad0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4ad4:	52a00024 	mov	w4, #0x10000               	// #65536
    4ad8:	38206845 	strb	w5, [x2, x0]
    4adc:	aa1403e0 	mov	x0, x20
    4ae0:	39000698 	strb	w24, [x20, #1]
    4ae4:	39000a97 	strb	w23, [x20, #2]
    4ae8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4aec:	b9000681 	str	w1, [x20, #4]
    4af0:	2a0103e5 	mov	w5, w1
    4af4:	8b0300a2 	add	x2, x5, x3
    4af8:	1ac10881 	udiv	w1, w4, w1
    4afc:	9ac50842 	udiv	x2, x2, x5
    4b00:	b9000a81 	str	w1, [x20, #8]
    4b04:	92404021 	and	x1, x1, #0x1ffff
    4b08:	b9001a82 	str	w2, [x20, #24]
    4b0c:	97ffff95 	bl	4960 <fwp_rc_prepare_chunk>
    4b10:	f949daa0 	ldr	x0, [x21, #5040]
    4b14:	29408a81 	ldp	w1, w2, [x20, #4]
    4b18:	8b134000 	add	x0, x0, x19, lsl #16
    4b1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b20:	8b214003 	add	x3, x0, w1, uxtw
    4b24:	9ba20021 	umaddl	x1, w1, w2, x0
    4b28:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b2c:	a90086c3 	stp	x3, x1, [x22, #8]
    4b30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b34:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b38:	d65f03c0 	ret
    4b3c:	d503201f 	nop

0000000000004b40 <fwp_mem_free>:
    4b40:	b40003c0 	cbz	x0, 4bb8 <fwp_mem_free+0x78>
    4b44:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4b48:	910003fd 	mov	x29, sp
    4b4c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b50:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc00>
    4b54:	911782a1 	add	x1, x21, #0x5e0
    4b58:	a90153f3 	stp	x19, x20, [sp, #16]
    4b5c:	aa0003f3 	mov	x19, x0
    4b60:	f949d823 	ldr	x3, [x1, #5040]
    4b64:	f949ec22 	ldr	x2, [x1, #5080]
    4b68:	cb030000 	sub	x0, x0, x3
    4b6c:	eb02401f 	cmp	x0, x2, lsl #16
    4b70:	540001c2 	b.cs	4ba8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b74:	d350fc16 	lsr	x22, x0, #16
    4b78:	a90363f7 	stp	x23, x24, [sp, #48]
    4b7c:	f949fc22 	ldr	x2, [x1, #5112]
    4b80:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b84:	d37df294 	lsl	x20, x20, #3
    4b88:	ab140057 	adds	x23, x2, x20
    4b8c:	540000c0 	b.eq	4ba4 <fwp_mem_free+0x64>  // b.none
    4b90:	38746842 	ldrb	w2, [x2, x20]
    4b94:	7100045f 	cmp	w2, #0x1
    4b98:	54000120 	b.eq	4bbc <fwp_mem_free+0x7c>  // b.none
    4b9c:	7100085f 	cmp	w2, #0x2
    4ba0:	540005e0 	b.eq	4c5c <fwp_mem_free+0x11c>  // b.none
    4ba4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ba8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bb0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4bb4:	d65f03c0 	ret
    4bb8:	d65f03c0 	ret
    4bbc:	f94012f8 	ldr	x24, [x23, #32]
    4bc0:	b94006e1 	ldr	w1, [x23, #4]
    4bc4:	f90023f9 	str	x25, [sp, #64]
    4bc8:	2a0103e2 	mov	w2, w1
    4bcc:	394006f9 	ldrb	w25, [x23, #1]
    4bd0:	39400af4 	ldrb	w20, [x23, #2]
    4bd4:	b4000158 	cbz	x24, 4bfc <fwp_mem_free+0xbc>
    4bd8:	92403e76 	and	x22, x19, #0xffff
    4bdc:	9ac20ad6 	udiv	x22, x22, x2
    4be0:	38766b01 	ldrb	w1, [x24, x22]
    4be4:	8b160300 	add	x0, x24, x22
    4be8:	7103fc3f 	cmp	w1, #0xff
    4bec:	54000980 	b.eq	4d1c <fwp_mem_free+0x1dc>  // b.none
    4bf0:	38366b1f 	strb	wzr, [x24, x22]
    4bf4:	b94006e1 	ldr	w1, [x23, #4]
    4bf8:	2a0103e2 	mov	w2, w1
    4bfc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4c00:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4c04:	cb390000 	sub	x0, x0, w25, uxtb
    4c08:	8b340074 	add	x20, x3, w20, uxtb
    4c0c:	911782b5 	add	x21, x21, #0x5e0
    4c10:	1e630021 	ucvtf	d1, w1
    4c14:	d37ae400 	lsl	x0, x0, #6
    4c18:	8b140c14 	add	x20, x0, x20, lsl #3
    4c1c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c20:	f8746aa0 	ldr	x0, [x21, x20]
    4c24:	f94023f9 	ldr	x25, [sp, #64]
    4c28:	aa2003e0 	mvn	x0, x0
    4c2c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4c30:	f9000260 	str	x0, [x19]
    4c34:	f8346ab3 	str	x19, [x21, x20]
    4c38:	f94a12a0 	ldr	x0, [x21, #5152]
    4c3c:	1e612800 	fadd	d0, d0, d1
    4c40:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c44:	cb020000 	sub	x0, x0, x2
    4c48:	f90a12a0 	str	x0, [x21, #5152]
    4c4c:	fd0a22a0 	str	d0, [x21, #5184]
    4c50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c54:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c58:	d65f03c0 	ret
    4c5c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c60:	8b000063 	add	x3, x3, x0
    4c64:	eb03027f 	cmp	x19, x3
    4c68:	54fff9e1 	b.ne	4ba4 <fwp_mem_free+0x64>  // b.any
    4c6c:	fd400ae1 	ldr	d1, [x23, #16]
    4c70:	fd4a2020 	ldr	d0, [x1, #5184]
    4c74:	f9400ae0 	ldr	x0, [x23, #16]
    4c78:	7e61d821 	ucvtf	d1, d1
    4c7c:	f94a1022 	ldr	x2, [x1, #5152]
    4c80:	f94012f3 	ldr	x19, [x23, #32]
    4c84:	1e612800 	fadd	d0, d0, d1
    4c88:	cb000042 	sub	x2, x2, x0
    4c8c:	f90a1022 	str	x2, [x1, #5152]
    4c90:	fd0a2020 	str	d0, [x1, #5184]
    4c94:	b40000b3 	cbz	x19, 4ca8 <fwp_mem_free+0x168>
    4c98:	39400260 	ldrb	w0, [x19]
    4c9c:	7103fc1f 	cmp	w0, #0xff
    4ca0:	54000380 	b.eq	4d10 <fwp_mem_free+0x1d0>  // b.none
    4ca4:	3900027f 	strb	wzr, [x19]
    4ca8:	b9400ee2 	ldr	w2, [x23, #12]
    4cac:	b4000142 	cbz	x2, 4cd4 <fwp_mem_free+0x194>
    4cb0:	911782a1 	add	x1, x21, #0x5e0
    4cb4:	8b160040 	add	x0, x2, x22
    4cb8:	8b000800 	add	x0, x0, x0, lsl #2
    4cbc:	f949fc21 	ldr	x1, [x1, #5112]
    4cc0:	8b140034 	add	x20, x1, x20
    4cc4:	8b000c20 	add	x0, x1, x0, lsl #3
    4cc8:	3802869f 	strb	wzr, [x20], #40
    4ccc:	eb00029f 	cmp	x20, x0
    4cd0:	54ffffc1 	b.ne	4cc8 <fwp_mem_free+0x188>  // b.any
    4cd4:	911782a0 	add	x0, x21, #0x5e0
    4cd8:	f94a1801 	ldr	x1, [x0, #5168]
    4cdc:	f949f803 	ldr	x3, [x0, #5104]
    4ce0:	8b020021 	add	x1, x1, x2
    4ce4:	f90a1801 	str	x1, [x0, #5168]
    4ce8:	eb16007f 	cmp	x3, x22
    4cec:	54000049 	b.ls	4cf4 <fwp_mem_free+0x1b4>  // b.plast
    4cf0:	f909f816 	str	x22, [x0, #5104]
    4cf4:	911782b5 	add	x21, x21, #0x5e0
    4cf8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cfc:	eb16001f 	cmp	x0, x22
    4d00:	54fff529 	b.ls	4ba4 <fwp_mem_free+0x64>  // b.plast
    4d04:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d08:	f909f6b6 	str	x22, [x21, #5096]
    4d0c:	17ffffa7 	b	4ba8 <fwp_mem_free+0x68>
    4d10:	aa1303e0 	mov	x0, x19
    4d14:	97fffeeb 	bl	48c0 <fwp_rc_forget_slot>
    4d18:	17ffffe3 	b	4ca4 <fwp_mem_free+0x164>
    4d1c:	97fffee9 	bl	48c0 <fwp_rc_forget_slot>
    4d20:	17ffffb4 	b	4bf0 <fwp_mem_free+0xb0>

0000000000004d24 <fwp_heap_alloc_big>:
    4d24:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4d28:	910003fd 	mov	x29, sp
    4d2c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d30:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d34:	a90363f7 	stp	x23, x24, [sp, #48]
    4d38:	aa0003f7 	mov	x23, x0
    4d3c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4d40:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d44:	eb0002ff 	cmp	x23, x0
    4d48:	54000888 	b.hi	4e58 <fwp_heap_alloc_big+0x134>  // b.pmore
    4d4c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d50:	8b0002f4 	add	x20, x23, x0
    4d54:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc00>
    4d58:	91178359 	add	x25, x26, #0x5e0
    4d5c:	d350fe94 	lsr	x20, x20, #16
    4d60:	2a0103f5 	mov	w21, w1
    4d64:	aa1403e0 	mov	x0, x20
    4d68:	97fff972 	bl	3330 <fwp_heap_chunks>
    4d6c:	f949ff22 	ldr	x2, [x25, #5112]
    4d70:	8b000813 	add	x19, x0, x0, lsl #2
    4d74:	aa0003f8 	mov	x24, x0
    4d78:	52800043 	mov	w3, #0x2                   	// #2
    4d7c:	d37df273 	lsl	x19, x19, #3
    4d80:	d2800021 	mov	x1, #0x1                   	// #1
    4d84:	8b130040 	add	x0, x2, x19
    4d88:	38336843 	strb	w3, [x2, x19]
    4d8c:	39000415 	strb	w21, [x0, #1]
    4d90:	b9000c14 	str	w20, [x0, #12]
    4d94:	f9000817 	str	x23, [x0, #16]
    4d98:	97fffef2 	bl	4960 <fwp_rc_prepare_chunk>
    4d9c:	f100069f 	cmp	x20, #0x1
    4da0:	54000269 	b.ls	4dec <fwp_heap_alloc_big+0xc8>  // b.plast
    4da4:	8b180294 	add	x20, x20, x24
    4da8:	9100a273 	add	x19, x19, #0x28
    4dac:	a90573fb 	stp	x27, x28, [sp, #80]
    4db0:	5280007b 	mov	w27, #0x3                   	// #3
    4db4:	8b140a94 	add	x20, x20, x20, lsl #2
    4db8:	2a1803fc 	mov	w28, w24
    4dbc:	9adb2296 	lsl	x22, x20, x27
    4dc0:	f949ff35 	ldr	x21, [x25, #5112]
    4dc4:	d2800001 	mov	x1, #0x0                   	// #0
    4dc8:	8b1302b4 	add	x20, x21, x19
    4dcc:	aa1403e0 	mov	x0, x20
    4dd0:	97fffee4 	bl	4960 <fwp_rc_prepare_chunk>
    4dd4:	38336abb 	strb	w27, [x21, x19]
    4dd8:	9100a273 	add	x19, x19, #0x28
    4ddc:	b9000e9c 	str	w28, [x20, #12]
    4de0:	eb1302df 	cmp	x22, x19
    4de4:	54fffee1 	b.ne	4dc0 <fwp_heap_alloc_big+0x9c>  // b.any
    4de8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4dec:	91178353 	add	x19, x26, #0x5e0
    4df0:	aa1703e2 	mov	x2, x23
    4df4:	52800001 	mov	w1, #0x0                   	// #0
    4df8:	f949da60 	ldr	x0, [x19, #5040]
    4dfc:	8b184018 	add	x24, x0, x24, lsl #16
    4e00:	aa1803e0 	mov	x0, x24
    4e04:	97fff6b7 	bl	28e0 <memset@plt>
    4e08:	f94a1260 	ldr	x0, [x19, #5152]
    4e0c:	ab170000 	adds	x0, x0, x23
    4e10:	54000242 	b.cs	4e58 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4e14:	f94a1661 	ldr	x1, [x19, #5160]
    4e18:	f90a1260 	str	x0, [x19, #5152]
    4e1c:	eb01001f 	cmp	x0, x1
    4e20:	54000049 	b.ls	4e28 <fwp_heap_alloc_big+0x104>  // b.plast
    4e24:	f90a1660 	str	x0, [x19, #5160]
    4e28:	9117835a 	add	x26, x26, #0x5e0
    4e2c:	9e6202e0 	scvtf	d0, x23
    4e30:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e34:	aa1803e0 	mov	x0, x24
    4e38:	fd4a1f41 	ldr	d1, [x26, #5176]
    4e3c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e40:	1e602820 	fadd	d0, d1, d0
    4e44:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e48:	fd0a1f40 	str	d0, [x26, #5176]
    4e4c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e50:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e54:	d65f03c0 	ret
    4e58:	a90573fb 	stp	x27, x28, [sp, #80]
    4e5c:	97fff895 	bl	30b0 <fwp_heap_oom>

0000000000004e60 <fwp_heap_alloc_slow>:
    4e60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e64:	910003fd 	mov	x29, sp
    4e68:	a90153f3 	stp	x19, x20, [sp, #16]
    4e6c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc00>
    4e70:	91178262 	add	x2, x19, #0x5e0
    4e74:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e78:	aa0003f5 	mov	x21, x0
    4e7c:	2a0103f4 	mov	w20, w1
    4e80:	b953a440 	ldr	w0, [x2, #5028]
    4e84:	34000600 	cbz	w0, 4f44 <fwp_heap_alloc_slow+0xe4>
    4e88:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e8c:	54000628 	b.hi	4f50 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e90:	91003ea0 	add	x0, x21, #0xf
    4e94:	91178262 	add	x2, x19, #0x5e0
    4e98:	f9001bf7 	str	x23, [sp, #48]
    4e9c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ea0:	8b401040 	add	x0, x2, x0, lsr #4
    4ea4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ea8:	d37ae484 	lsl	x4, x4, #6
    4eac:	397e8003 	ldrb	w3, [x0, #4000]
    4eb0:	910f0060 	add	x0, x3, #0x3c0
    4eb4:	aa0303e1 	mov	x1, x3
    4eb8:	8b030463 	add	x3, x3, x3, lsl #1
    4ebc:	8b030c83 	add	x3, x4, x3, lsl #3
    4ec0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4ec4:	2a1703f6 	mov	w22, w23
    4ec8:	f8636844 	ldr	x4, [x2, x3]
    4ecc:	b40004e4 	cbz	x4, 4f68 <fwp_heap_alloc_slow+0x108>
    4ed0:	f9400080 	ldr	x0, [x4]
    4ed4:	aa2003e0 	mvn	x0, x0
    4ed8:	f8236840 	str	x0, [x2, x3]
    4edc:	7100069f 	cmp	w20, #0x1
    4ee0:	aa0403e0 	mov	x0, x4
    4ee4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4ee8:	52800001 	mov	w1, #0x0                   	// #0
    4eec:	97fff67d 	bl	28e0 <memset@plt>
    4ef0:	aa0003e4 	mov	x4, x0
    4ef4:	91178260 	add	x0, x19, #0x5e0
    4ef8:	f94a1001 	ldr	x1, [x0, #5152]
    4efc:	ab160021 	adds	x1, x1, x22
    4f00:	540005c2 	b.cs	4fb8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4f04:	f94a1402 	ldr	x2, [x0, #5160]
    4f08:	f90a1001 	str	x1, [x0, #5152]
    4f0c:	eb02003f 	cmp	x1, x2
    4f10:	54000049 	b.ls	4f18 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4f14:	f90a1401 	str	x1, [x0, #5160]
    4f18:	91178273 	add	x19, x19, #0x5e0
    4f1c:	1e6302e1 	ucvtf	d1, w23
    4f20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f24:	aa0403e0 	mov	x0, x4
    4f28:	fd4a1e60 	ldr	d0, [x19, #5176]
    4f2c:	f9401bf7 	ldr	x23, [sp, #48]
    4f30:	1e612800 	fadd	d0, d0, d1
    4f34:	fd0a1e60 	str	d0, [x19, #5176]
    4f38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f3c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f40:	d65f03c0 	ret
    4f44:	97fffc90 	bl	4184 <fwp_heap_init>
    4f48:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f4c:	54fffa29 	b.ls	4e90 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f50:	2a1403e1 	mov	w1, w20
    4f54:	aa1503e0 	mov	x0, x21
    4f58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f60:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f64:	17ffff70 	b	4d24 <fwp_heap_alloc_big>
    4f68:	8b030042 	add	x2, x2, x3
    4f6c:	f9400444 	ldr	x4, [x2, #8]
    4f70:	b4000104 	cbz	x4, 4f90 <fwp_heap_alloc_slow+0x130>
    4f74:	f9400840 	ldr	x0, [x2, #16]
    4f78:	cb040000 	sub	x0, x0, x4
    4f7c:	eb16001f 	cmp	x0, x22
    4f80:	54000083 	b.cc	4f90 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f84:	8b160080 	add	x0, x4, x22
    4f88:	f9000440 	str	x0, [x2, #8]
    4f8c:	17ffffd4 	b	4edc <fwp_heap_alloc_slow+0x7c>
    4f90:	52800302 	mov	w2, #0x18                  	// #24
    4f94:	52807804 	mov	w4, #0x3c0                 	// #960
    4f98:	91178260 	add	x0, x19, #0x5e0
    4f9c:	9ba27c23 	umull	x3, w1, w2
    4fa0:	2a1403e2 	mov	w2, w20
    4fa4:	9b240e84 	smaddl	x4, w20, w4, x3
    4fa8:	8b040000 	add	x0, x0, x4
    4fac:	97fffeb5 	bl	4a80 <fwp_heap_refill>
    4fb0:	aa0003e4 	mov	x4, x0
    4fb4:	17ffffca 	b	4edc <fwp_heap_alloc_slow+0x7c>
    4fb8:	97fff83e 	bl	30b0 <fwp_heap_oom>
    4fbc:	d503201f 	nop

0000000000004fc0 <fwp_heap_alloc>:
    4fc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4fc4:	f140101f 	cmp	x0, #0x4, lsl #12
    4fc8:	910003fd 	mov	x29, sp
    4fcc:	a90153f3 	stp	x19, x20, [sp, #16]
    4fd0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc00>
    4fd4:	91178293 	add	x19, x20, #0x5e0
    4fd8:	b953a662 	ldr	w2, [x19, #5028]
    4fdc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4fe0:	54000640 	b.eq	50a8 <fwp_heap_alloc+0xe8>  // b.none
    4fe4:	91003c03 	add	x3, x0, #0xf
    4fe8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fec:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ff0:	8b431263 	add	x3, x19, x3, lsr #4
    4ff4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ff8:	d37ae442 	lsl	x2, x2, #6
    4ffc:	397e8063 	ldrb	w3, [x3, #4000]
    5000:	910f0064 	add	x4, x3, #0x3c0
    5004:	8b030463 	add	x3, x3, x3, lsl #1
    5008:	8b030c43 	add	x3, x2, x3, lsl #3
    500c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    5010:	2a1603f5 	mov	w21, w22
    5014:	f8636a64 	ldr	x4, [x19, x3]
    5018:	b4000384 	cbz	x4, 5088 <fwp_heap_alloc+0xc8>
    501c:	f9400085 	ldr	x5, [x4]
    5020:	7100043f 	cmp	w1, #0x1
    5024:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5028:	aa0403e0 	mov	x0, x4
    502c:	aa2503e5 	mvn	x5, x5
    5030:	52800001 	mov	w1, #0x0                   	// #0
    5034:	f8236a65 	str	x5, [x19, x3]
    5038:	97fff62a 	bl	28e0 <memset@plt>
    503c:	aa0003e4 	mov	x4, x0
    5040:	f94a1260 	ldr	x0, [x19, #5152]
    5044:	ab150000 	adds	x0, x0, x21
    5048:	54000442 	b.cs	50d0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    504c:	f94a1661 	ldr	x1, [x19, #5160]
    5050:	f90a1260 	str	x0, [x19, #5152]
    5054:	eb01001f 	cmp	x0, x1
    5058:	54000049 	b.ls	5060 <fwp_heap_alloc+0xa0>  // b.plast
    505c:	f90a1660 	str	x0, [x19, #5160]
    5060:	91178294 	add	x20, x20, #0x5e0
    5064:	1e6302c1 	ucvtf	d1, w22
    5068:	a9425bf5 	ldp	x21, x22, [sp, #32]
    506c:	aa0403e0 	mov	x0, x4
    5070:	fd4a1e80 	ldr	d0, [x20, #5176]
    5074:	1e612800 	fadd	d0, d0, d1
    5078:	fd0a1e80 	str	d0, [x20, #5176]
    507c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5080:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5084:	d65f03c0 	ret
    5088:	8b030263 	add	x3, x19, x3
    508c:	f9400464 	ldr	x4, [x3, #8]
    5090:	b40000a4 	cbz	x4, 50a4 <fwp_heap_alloc+0xe4>
    5094:	f9400862 	ldr	x2, [x3, #16]
    5098:	cb040042 	sub	x2, x2, x4
    509c:	eb15005f 	cmp	x2, x21
    50a0:	540000a2 	b.cs	50b4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    50a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    50b0:	17ffff6c 	b	4e60 <fwp_heap_alloc_slow>
    50b4:	7100043f 	cmp	w1, #0x1
    50b8:	8b150085 	add	x5, x4, x21
    50bc:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    50c0:	52800001 	mov	w1, #0x0                   	// #0
    50c4:	aa0403e0 	mov	x0, x4
    50c8:	f9000465 	str	x5, [x3, #8]
    50cc:	17ffffdb 	b	5038 <fwp_heap_alloc+0x78>
    50d0:	97fff7f8 	bl	30b0 <fwp_heap_oom>

00000000000050d4 <fwp_data.part.0.constprop.0>:
    50d4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    50d8:	910003fd 	mov	x29, sp
    50dc:	a90153f3 	stp	x19, x20, [sp, #16]
    50e0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc00>
    50e4:	91178283 	add	x3, x20, #0x5e0
    50e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    50ec:	aa0103f5 	mov	x21, x1
    50f0:	b953a461 	ldr	w1, [x3, #5028]
    50f4:	a90363f7 	stp	x23, x24, [sp, #48]
    50f8:	2a0003f8 	mov	w24, w0
    50fc:	34000701 	cbz	w1, 51dc <fwp_data.part.0.constprop.0+0x108>
    5100:	397e8862 	ldrb	w2, [x3, #4002]
    5104:	910f0040 	add	x0, x2, #0x3c0
    5108:	8b020442 	add	x2, x2, x2, lsl #1
    510c:	d37df042 	lsl	x2, x2, #3
    5110:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5114:	2a1703f6 	mov	w22, w23
    5118:	f8626873 	ldr	x19, [x3, x2]
    511c:	b40004d3 	cbz	x19, 51b4 <fwp_data.part.0.constprop.0+0xe0>
    5120:	f9400260 	ldr	x0, [x19]
    5124:	aa2003e0 	mvn	x0, x0
    5128:	f8226860 	str	x0, [x3, x2]
    512c:	f10062df 	cmp	x22, #0x18
    5130:	540000e9 	b.ls	514c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5134:	d10066c2 	sub	x2, x22, #0x19
    5138:	91006260 	add	x0, x19, #0x18
    513c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5140:	52800001 	mov	w1, #0x0                   	// #0
    5144:	91002042 	add	x2, x2, #0x8
    5148:	97fff5e6 	bl	28e0 <memset@plt>
    514c:	91178282 	add	x2, x20, #0x5e0
    5150:	f94a1041 	ldr	x1, [x2, #5152]
    5154:	ab160021 	adds	x1, x1, x22
    5158:	540004c2 	b.cs	51f0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    515c:	f94a1440 	ldr	x0, [x2, #5160]
    5160:	f90a1041 	str	x1, [x2, #5152]
    5164:	eb00003f 	cmp	x1, x0
    5168:	54000049 	b.ls	5170 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    516c:	f90a1441 	str	x1, [x2, #5160]
    5170:	91178294 	add	x20, x20, #0x5e0
    5174:	1e6302e1 	ucvtf	d1, w23
    5178:	fd4a1e80 	ldr	d0, [x20, #5176]
    517c:	1e612800 	fadd	d0, d0, d1
    5180:	fd0a1e80 	str	d0, [x20, #5176]
    5184:	52800041 	mov	w1, #0x2                   	// #2
    5188:	29000678 	stp	w24, w1, [x19]
    518c:	aa1303e0 	mov	x0, x19
    5190:	f94002a1 	ldr	x1, [x21]
    5194:	f9000661 	str	x1, [x19, #8]
    5198:	f94006a1 	ldr	x1, [x21, #8]
    519c:	f9000a61 	str	x1, [x19, #16]
    51a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    51a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    51ac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51b0:	d65f03c0 	ret
    51b4:	8b020063 	add	x3, x3, x2
    51b8:	f9400473 	ldr	x19, [x3, #8]
    51bc:	b4000113 	cbz	x19, 51dc <fwp_data.part.0.constprop.0+0x108>
    51c0:	f9400860 	ldr	x0, [x3, #16]
    51c4:	cb130000 	sub	x0, x0, x19
    51c8:	eb0002df 	cmp	x22, x0
    51cc:	54000088 	b.hi	51dc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    51d0:	8b160260 	add	x0, x19, x22
    51d4:	f9000460 	str	x0, [x3, #8]
    51d8:	17ffffd5 	b	512c <fwp_data.part.0.constprop.0+0x58>
    51dc:	52800001 	mov	w1, #0x0                   	// #0
    51e0:	d2800300 	mov	x0, #0x18                  	// #24
    51e4:	97ffff77 	bl	4fc0 <fwp_heap_alloc>
    51e8:	aa0003f3 	mov	x19, x0
    51ec:	17ffffe6 	b	5184 <fwp_data.part.0.constprop.0+0xb0>
    51f0:	97fff7b0 	bl	30b0 <fwp_heap_oom>

00000000000051f4 <fwp_p_ad_push>:
    51f4:	f100001f 	cmp	x0, #0x0
    51f8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51fc:	54000e8b 	b.lt	53cc <fwp_p_ad_push+0x1d8>  // b.tstop
    5200:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5204:	aa0003e4 	mov	x4, x0
    5208:	910003fd 	mov	x29, sp
    520c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5210:	aa0003f5 	mov	x21, x0
    5214:	aa020000 	orr	x0, x0, x2
    5218:	a90363f7 	stp	x23, x24, [sp, #48]
    521c:	aa0203f7 	mov	x23, x2
    5220:	6d0627e8 	stp	d8, d9, [sp, #96]
    5224:	9e670029 	fmov	d9, x1
    5228:	9e670068 	fmov	d8, x3
    522c:	b6f80900 	tbz	x0, #63, 534c <fwp_p_ad_push+0x158>
    5230:	a90153f3 	stp	x19, x20, [sp, #16]
    5234:	9360fc80 	asr	x0, x4, #32
    5238:	b6f800c4 	tbz	x4, #63, 5250 <fwp_p_ad_push+0x5c>
    523c:	1e604109 	fmov	d9, d8
    5240:	2f00e408 	movi	d8, #0x0
    5244:	9360fc40 	asr	x0, x2, #32
    5248:	aa0203f5 	mov	x21, x2
    524c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5250:	97fffa58 	bl	3bb0 <fwp_tape_of>
    5254:	aa0003f3 	mov	x19, x0
    5258:	f9403000 	ldr	x0, [x0, #96]
    525c:	b5001280 	cbnz	x0, 54ac <fwp_p_ad_push+0x2b8>
    5260:	f9400a76 	ldr	x22, [x19, #16]
    5264:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5268:	eb0002df 	cmp	x22, x0
    526c:	54000e2c 	b.gt	5430 <fwp_p_ad_push+0x23c>
    5270:	eb3542df 	cmp	x22, w21, uxtw
    5274:	54000d4d 	b.le	541c <fwp_p_ad_push+0x228>
    5278:	b7f80077 	tbnz	x23, #63, 5284 <fwp_p_ad_push+0x90>
    527c:	eb3742df 	cmp	x22, w23, uxtw
    5280:	54000ced 	b.le	541c <fwp_p_ad_push+0x228>
    5284:	f9400678 	ldr	x24, [x19, #8]
    5288:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    528c:	cb1802d8 	sub	x24, x22, x24
    5290:	91000701 	add	x1, x24, #0x1
    5294:	eb00003f 	cmp	x1, x0
    5298:	54000cc8 	b.hi	5430 <fwp_p_ad_push+0x23c>  // b.pmore
    529c:	a9418274 	ldp	x20, x0, [x19, #24]
    52a0:	a90573fb 	stp	x27, x28, [sp, #80]
    52a4:	eb14003f 	cmp	x1, x20
    52a8:	5400068d 	b.le	5378 <fwp_p_ad_push+0x184>
    52ac:	f100029f 	cmp	x20, #0x0
    52b0:	d2800803 	mov	x3, #0x40                  	// #64
    52b4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    52b8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    52bc:	a9046bf9 	stp	x25, x26, [sp, #64]
    52c0:	eb14003f 	cmp	x1, x20
    52c4:	5400008d 	b.le	52d4 <fwp_p_ad_push+0xe0>
    52c8:	eb02029f 	cmp	x20, x2
    52cc:	5400052d 	b.le	5370 <fwp_p_ad_push+0x17c>
    52d0:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    52d4:	d37df299 	lsl	x25, x20, #3
    52d8:	aa1903e1 	mov	x1, x25
    52dc:	97fff589 	bl	2900 <realloc@plt>
    52e0:	aa0003e1 	mov	x1, x0
    52e4:	b4000b00 	cbz	x0, 5444 <fwp_p_ad_push+0x250>
    52e8:	f9400e62 	ldr	x2, [x19, #24]
    52ec:	f9001261 	str	x1, [x19, #32]
    52f0:	f9401a60 	ldr	x0, [x19, #48]
    52f4:	d37cee9a 	lsl	x26, x20, #4
    52f8:	8b020821 	add	x1, x1, x2, lsl #2
    52fc:	f9001661 	str	x1, [x19, #40]
    5300:	aa1a03e1 	mov	x1, x26
    5304:	97fff57f 	bl	2900 <realloc@plt>
    5308:	aa0003e2 	mov	x2, x0
    530c:	b40009c0 	cbz	x0, 5444 <fwp_p_ad_push+0x250>
    5310:	f9400e61 	ldr	x1, [x19, #24]
    5314:	d37df31b 	lsl	x27, x24, #3
    5318:	d37ef685 	lsl	x5, x20, #2
    531c:	d37ef71c 	lsl	x28, x24, #2
    5320:	8b190004 	add	x4, x0, x25
    5324:	8b010c01 	add	x1, x0, x1, lsl #3
    5328:	a9030660 	stp	x0, x1, [x19, #48]
    532c:	b5000558 	cbnz	x24, 53d4 <fwp_p_ad_push+0x1e0>
    5330:	f9001e64 	str	x4, [x19, #56]
    5334:	f9401260 	ldr	x0, [x19, #32]
    5338:	a9446bf9 	ldp	x25, x26, [sp, #64]
    533c:	8b050001 	add	x1, x0, x5
    5340:	f9000e74 	str	x20, [x19, #24]
    5344:	f9001661 	str	x1, [x19, #40]
    5348:	14000010 	b	5388 <fwp_p_ad_push+0x194>
    534c:	9360fc40 	asr	x0, x2, #32
    5350:	a90153f3 	stp	x19, x20, [sp, #16]
    5354:	eb84801f 	cmp	x0, x4, asr #32
    5358:	54fff7c0 	b.eq	5250 <fwp_p_ad_push+0x5c>  // b.none
    535c:	90000020 	adrp	x0, 9000 <__divti3+0x370>
    5360:	911d6000 	add	x0, x0, #0x758
    5364:	a9046bf9 	stp	x25, x26, [sp, #64]
    5368:	a90573fb 	stp	x27, x28, [sp, #80]
    536c:	97fff945 	bl	3880 <fwp_trap>
    5370:	d37ffa94 	lsl	x20, x20, #1
    5374:	17ffffd3 	b	52c0 <fwp_p_ad_push+0xcc>
    5378:	a9428a61 	ldp	x1, x2, [x19, #40]
    537c:	d37ef71c 	lsl	x28, x24, #2
    5380:	f9401e64 	ldr	x4, [x19, #56]
    5384:	d37df31b 	lsl	x27, x24, #3
    5388:	b83c6815 	str	w21, [x0, x28]
    538c:	f10002ff 	cmp	x23, #0x0
    5390:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5394:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5398:	fc3b6849 	str	d9, [x2, x27]
    539c:	aa1602a0 	orr	x0, x21, x22
    53a0:	b83c6837 	str	w23, [x1, x28]
    53a4:	910006d6 	add	x22, x22, #0x1
    53a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    53ac:	fc3b6888 	str	d8, [x4, x27]
    53b0:	a94573fb 	ldp	x27, x28, [sp, #80]
    53b4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    53b8:	f9000a76 	str	x22, [x19, #16]
    53bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    53c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53c4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    53c8:	d65f03c0 	ret
    53cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53d0:	d65f03c0 	ret
    53d4:	eb1a033f 	cmp	x25, x26
    53d8:	aa0403e0 	mov	x0, x4
    53dc:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    53e0:	aa1b03e2 	mov	x2, x27
    53e4:	cb190063 	sub	x3, x3, x25
    53e8:	f9003fe5 	str	x5, [sp, #120]
    53ec:	97fff5b1 	bl	2ab0 <__memmove_chk@plt>
    53f0:	a9420660 	ldp	x0, x1, [x19, #32]
    53f4:	aa1c03e2 	mov	x2, x28
    53f8:	f9401a63 	ldr	x3, [x19, #48]
    53fc:	f9403fe5 	ldr	x5, [sp, #120]
    5400:	8b190063 	add	x3, x3, x25
    5404:	f9001e63 	str	x3, [x19, #56]
    5408:	8b050000 	add	x0, x0, x5
    540c:	97fff4dd 	bl	2780 <memmove@plt>
    5410:	a9431262 	ldp	x2, x4, [x19, #48]
    5414:	f9403fe5 	ldr	x5, [sp, #120]
    5418:	17ffffc7 	b	5334 <fwp_p_ad_push+0x140>
    541c:	90000020 	adrp	x0, 9000 <__divti3+0x370>
    5420:	911fc000 	add	x0, x0, #0x7f0
    5424:	a9046bf9 	stp	x25, x26, [sp, #64]
    5428:	a90573fb 	stp	x27, x28, [sp, #80]
    542c:	97fff915 	bl	3880 <fwp_trap>
    5430:	90000020 	adrp	x0, 9000 <__divti3+0x370>
    5434:	911f4000 	add	x0, x0, #0x7d0
    5438:	a9046bf9 	stp	x25, x26, [sp, #64]
    543c:	a90573fb 	stp	x27, x28, [sp, #80]
    5440:	97fff910 	bl	3880 <fwp_trap>
    5444:	aa1303e0 	mov	x0, x19
    5448:	97fff6f2 	bl	3010 <fwp_tape_unlink_scope>
    544c:	f9401260 	ldr	x0, [x19, #32]
    5450:	97fff560 	bl	29d0 <free@plt>
    5454:	f9401a60 	ldr	x0, [x19, #48]
    5458:	97fff55e 	bl	29d0 <free@plt>
    545c:	f9402260 	ldr	x0, [x19, #64]
    5460:	97fff55c 	bl	29d0 <free@plt>
    5464:	f9000e7f 	str	xzr, [x19, #24]
    5468:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    546c:	f947e821 	ldr	x1, [x1, #4048]
    5470:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5474:	d2800262 	mov	x2, #0x13                  	// #19
    5478:	4f000400 	movi	v0.4s, #0x0
    547c:	90000020 	adrp	x0, 9000 <__divti3+0x370>
    5480:	f9400023 	ldr	x3, [x1]
    5484:	b900067f 	str	wzr, [x19, #4]
    5488:	d2800021 	mov	x1, #0x1                   	// #1
    548c:	910ee000 	add	x0, x0, #0x3b8
    5490:	3c808260 	stur	q0, [x19, #8]
    5494:	ad010260 	stp	q0, q0, [x19, #32]
    5498:	97fff55e 	bl	2a10 <fwrite@plt>
    549c:	d2800000 	mov	x0, #0x0                   	// #0
    54a0:	97fff568 	bl	2a40 <fflush@plt>
    54a4:	52800cc0 	mov	w0, #0x66                  	// #102
    54a8:	97fff576 	bl	2a80 <_Exit@plt>
    54ac:	90000020 	adrp	x0, 9000 <__divti3+0x370>
    54b0:	911e8000 	add	x0, x0, #0x7a0
    54b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54b8:	a90573fb 	stp	x27, x28, [sp, #80]
    54bc:	97fff8f1 	bl	3880 <fwp_trap>

00000000000054c0 <w120>:
    54c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    54c4:	9e660003 	fmov	x3, d0
    54c8:	aa0003e2 	mov	x2, x0
    54cc:	910003fd 	mov	x29, sp
    54d0:	fd001fea 	str	d10, [sp, #56]
    54d4:	1e60400a 	fmov	d10, d0
    54d8:	6d0427e8 	stp	d8, d9, [sp, #64]
    54dc:	1e604028 	fmov	d8, d1
    54e0:	1e600809 	fmul	d9, d0, d0
    54e4:	a90153f3 	stp	x19, x20, [sp, #16]
    54e8:	aa0103f4 	mov	x20, x1
    54ec:	aa0303e1 	mov	x1, x3
    54f0:	aa0003f3 	mov	x19, x0
    54f4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54f8:	f9001bf7 	str	x23, [sp, #48]
    54fc:	97ffff3e 	bl	51f4 <fwp_p_ad_push>
    5500:	aa0003e5 	mov	x5, x0
    5504:	97fffb90 	bl	4344 <caf75>
    5508:	9e670000 	fmov	d0, x0
    550c:	97fffb8e 	bl	4344 <caf75>
    5510:	1e693908 	fsub	d8, d8, d9
    5514:	aa1403e2 	mov	x2, x20
    5518:	1e614000 	fneg	d0, d0
    551c:	aa0003e3 	mov	x3, x0
    5520:	aa0503e0 	mov	x0, x5
    5524:	9e660117 	fmov	x23, d8
    5528:	9e660001 	fmov	x1, d0
    552c:	97ffff32 	bl	51f4 <fwp_p_ad_push>
    5530:	aa0003f5 	mov	x21, x0
    5534:	97fffb84 	bl	4344 <caf75>
    5538:	9e670000 	fmov	d0, x0
    553c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5540:	97fffb81 	bl	4344 <caf75>
    5544:	1e614000 	fneg	d0, d0
    5548:	aa0003e3 	mov	x3, x0
    554c:	1e6a3929 	fsub	d9, d9, d10
    5550:	aa1303e0 	mov	x0, x19
    5554:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5558:	9e660001 	fmov	x1, d0
    555c:	9e660136 	fmov	x22, d9
    5560:	97ffff25 	bl	51f4 <fwp_p_ad_push>
    5564:	1e680908 	fmul	d8, d8, d8
    5568:	aa0003f4 	mov	x20, x0
    556c:	aa1703e3 	mov	x3, x23
    5570:	aa1703e1 	mov	x1, x23
    5574:	aa1503e2 	mov	x2, x21
    5578:	aa1503e0 	mov	x0, x21
    557c:	97ffff1e 	bl	51f4 <fwp_p_ad_push>
    5580:	aa0003e2 	mov	x2, x0
    5584:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5588:	9e670020 	fmov	d0, x1
    558c:	9e660101 	fmov	x1, d8
    5590:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5594:	1e600908 	fmul	d8, d8, d0
    5598:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    559c:	97ffff16 	bl	51f4 <fwp_p_ad_push>
    55a0:	1e690929 	fmul	d9, d9, d9
    55a4:	aa1603e3 	mov	x3, x22
    55a8:	aa1603e1 	mov	x1, x22
    55ac:	aa1403e2 	mov	x2, x20
    55b0:	aa0003f3 	mov	x19, x0
    55b4:	aa1403e0 	mov	x0, x20
    55b8:	97ffff0f 	bl	51f4 <fwp_p_ad_push>
    55bc:	aa0003e5 	mov	x5, x0
    55c0:	97fffb61 	bl	4344 <caf75>
    55c4:	aa0003e6 	mov	x6, x0
    55c8:	97fffb5f 	bl	4344 <caf75>
    55cc:	1e692908 	fadd	d8, d8, d9
    55d0:	aa1303e2 	mov	x2, x19
    55d4:	aa0603e1 	mov	x1, x6
    55d8:	aa0003e3 	mov	x3, x0
    55dc:	aa0503e0 	mov	x0, x5
    55e0:	97ffff05 	bl	51f4 <fwp_p_ad_push>
    55e4:	aa0003e1 	mov	x1, x0
    55e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    55ec:	9e660100 	fmov	x0, d8
    55f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55f4:	f9401bf7 	ldr	x23, [sp, #48]
    55f8:	fd401fea 	ldr	d10, [sp, #56]
    55fc:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5600:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5604:	d65f03c0 	ret
    5608:	d503201f 	nop
    560c:	d503201f 	nop

0000000000005610 <w176.constprop.0>:
    5610:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5614:	910003fd 	mov	x29, sp
    5618:	a9025bf5 	stp	x21, x22, [sp, #32]
    561c:	fd001be8 	str	d8, [sp, #48]
    5620:	f9400015 	ldr	x21, [x0]
    5624:	b40003b5 	cbz	x21, 5698 <w176.constprop.0+0x88>
    5628:	2f00e408 	movi	d8, #0x0
    562c:	91002016 	add	x22, x0, #0x8
    5630:	a90153f3 	stp	x19, x20, [sp, #16]
    5634:	91004014 	add	x20, x0, #0x10
    5638:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    563c:	d2800013 	mov	x19, #0x0                   	// #0
    5640:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5644:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    5648:	97fffb3f 	bl	4344 <caf75>
    564c:	aa0003e6 	mov	x6, x0
    5650:	97fffb3d 	bl	4344 <caf75>
    5654:	1e602908 	fadd	d8, d8, d0
    5658:	aa0003e3 	mov	x3, x0
    565c:	aa0703e2 	mov	x2, x7
    5660:	aa0503e0 	mov	x0, x5
    5664:	aa0603e1 	mov	x1, x6
    5668:	91000a73 	add	x19, x19, #0x2
    566c:	97fffee2 	bl	51f4 <fwp_p_ad_push>
    5670:	aa0003e5 	mov	x5, x0
    5674:	eb1302bf 	cmp	x21, x19
    5678:	54fffe48 	b.hi	5640 <w176.constprop.0+0x30>  // b.pmore
    567c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5680:	9e660100 	fmov	x0, d8
    5684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5688:	aa0503e1 	mov	x1, x5
    568c:	fd401be8 	ldr	d8, [sp, #48]
    5690:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5694:	d65f03c0 	ret
    5698:	2f00e408 	movi	d8, #0x0
    569c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    56a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56a4:	aa0503e1 	mov	x1, x5
    56a8:	9e660100 	fmov	x0, d8
    56ac:	fd401be8 	ldr	d8, [sp, #48]
    56b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    56b4:	d65f03c0 	ret
    56b8:	d503201f 	nop
    56bc:	d503201f 	nop

00000000000056c0 <fwp_rc_share>:
    56c0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc00>
    56c4:	91178042 	add	x2, x2, #0x5e0
    56c8:	f949d843 	ldr	x3, [x2, #5040]
    56cc:	f949ec41 	ldr	x1, [x2, #5080]
    56d0:	cb030000 	sub	x0, x0, x3
    56d4:	eb01401f 	cmp	x0, x1, lsl #16
    56d8:	540002c2 	b.cs	5730 <fwp_rc_share+0x70>  // b.hs, b.nlast
    56dc:	d350fc01 	lsr	x1, x0, #16
    56e0:	f949fc44 	ldr	x4, [x2, #5112]
    56e4:	8b010821 	add	x1, x1, x1, lsl #2
    56e8:	d37df021 	lsl	x1, x1, #3
    56ec:	8b010083 	add	x3, x4, x1
    56f0:	f9401062 	ldr	x2, [x3, #32]
    56f4:	b40001e2 	cbz	x2, 5730 <fwp_rc_share+0x70>
    56f8:	38616881 	ldrb	w1, [x4, x1]
    56fc:	7100083f 	cmp	w1, #0x2
    5700:	540001a0 	b.eq	5734 <fwp_rc_share+0x74>  // b.none
    5704:	7100043f 	cmp	w1, #0x1
    5708:	54000141 	b.ne	5730 <fwp_rc_share+0x70>  // b.any
    570c:	29430464 	ldp	w4, w1, [x3, #24]
    5710:	92403c00 	and	x0, x0, #0xffff
    5714:	9b047c00 	mul	x0, x0, x4
    5718:	d360fc00 	lsr	x0, x0, #32
    571c:	eb01001f 	cmp	x0, x1
    5720:	54000082 	b.cs	5730 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5724:	8b000042 	add	x2, x2, x0
    5728:	39400040 	ldrb	w0, [x2]
    572c:	350000a0 	cbnz	w0, 5740 <fwp_rc_share+0x80>
    5730:	d65f03c0 	ret
    5734:	72003c1f 	tst	w0, #0xffff
    5738:	54ffff80 	b.eq	5728 <fwp_rc_share+0x68>  // b.none
    573c:	d65f03c0 	ret
    5740:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5744:	90000020 	adrp	x0, 9000 <__divti3+0x370>
    5748:	91204000 	add	x0, x0, #0x810
    574c:	910003fd 	mov	x29, sp
    5750:	97fff84c 	bl	3880 <fwp_trap>

0000000000005754 <fwp_rc_free_arr>:
    5754:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc00>
    5758:	91178063 	add	x3, x3, #0x5e0
    575c:	f949d861 	ldr	x1, [x3, #5040]
    5760:	f949ec62 	ldr	x2, [x3, #5080]
    5764:	cb010001 	sub	x1, x0, x1
    5768:	eb02403f 	cmp	x1, x2, lsl #16
    576c:	54000342 	b.cs	57d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5770:	d350fc22 	lsr	x2, x1, #16
    5774:	f949fc65 	ldr	x5, [x3, #5112]
    5778:	8b020842 	add	x2, x2, x2, lsl #2
    577c:	d37df042 	lsl	x2, x2, #3
    5780:	8b0200a4 	add	x4, x5, x2
    5784:	f9401083 	ldr	x3, [x4, #32]
    5788:	b4000263 	cbz	x3, 57d4 <fwp_rc_free_arr+0x80>
    578c:	386268a2 	ldrb	w2, [x5, x2]
    5790:	7100085f 	cmp	w2, #0x2
    5794:	540001c0 	b.eq	57cc <fwp_rc_free_arr+0x78>  // b.none
    5798:	7100045f 	cmp	w2, #0x1
    579c:	540001c1 	b.ne	57d4 <fwp_rc_free_arr+0x80>  // b.any
    57a0:	29430885 	ldp	w5, w2, [x4, #24]
    57a4:	92403c21 	and	x1, x1, #0xffff
    57a8:	9b057c21 	mul	x1, x1, x5
    57ac:	d360fc21 	lsr	x1, x1, #32
    57b0:	eb02003f 	cmp	x1, x2
    57b4:	54000102 	b.cs	57d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    57b8:	8b010063 	add	x3, x3, x1
    57bc:	39400061 	ldrb	w1, [x3]
    57c0:	7100043f 	cmp	w1, #0x1
    57c4:	54000081 	b.ne	57d4 <fwp_rc_free_arr+0x80>  // b.any
    57c8:	17fffcde 	b	4b40 <fwp_mem_free>
    57cc:	72003c3f 	tst	w1, #0xffff
    57d0:	54ffff60 	b.eq	57bc <fwp_rc_free_arr+0x68>  // b.none
    57d4:	d65f03c0 	ret
    57d8:	d503201f 	nop
    57dc:	d503201f 	nop

00000000000057e0 <fwp_rc_dup>:
    57e0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc00>
    57e4:	91178042 	add	x2, x2, #0x5e0
    57e8:	f949d841 	ldr	x1, [x2, #5040]
    57ec:	f949ec43 	ldr	x3, [x2, #5080]
    57f0:	cb010001 	sub	x1, x0, x1
    57f4:	eb03403f 	cmp	x1, x3, lsl #16
    57f8:	54000342 	b.cs	5860 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    57fc:	d350fc20 	lsr	x0, x1, #16
    5800:	f949fc44 	ldr	x4, [x2, #5112]
    5804:	8b000800 	add	x0, x0, x0, lsl #2
    5808:	d37df002 	lsl	x2, x0, #3
    580c:	8b020083 	add	x3, x4, x2
    5810:	f9401060 	ldr	x0, [x3, #32]
    5814:	b4000260 	cbz	x0, 5860 <fwp_rc_dup+0x80>
    5818:	38626882 	ldrb	w2, [x4, x2]
    581c:	7100085f 	cmp	w2, #0x2
    5820:	54000220 	b.eq	5864 <fwp_rc_dup+0x84>  // b.none
    5824:	7100045f 	cmp	w2, #0x1
    5828:	540001c1 	b.ne	5860 <fwp_rc_dup+0x80>  // b.any
    582c:	29430864 	ldp	w4, w2, [x3, #24]
    5830:	92403c21 	and	x1, x1, #0xffff
    5834:	9b047c21 	mul	x1, x1, x4
    5838:	d360fc21 	lsr	x1, x1, #32
    583c:	eb02003f 	cmp	x1, x2
    5840:	54000102 	b.cs	5860 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5844:	8b010000 	add	x0, x0, x1
    5848:	39400001 	ldrb	w1, [x0]
    584c:	340000a1 	cbz	w1, 5860 <fwp_rc_dup+0x80>
    5850:	7103f43f 	cmp	w1, #0xfd
    5854:	540000e8 	b.hi	5870 <fwp_rc_dup+0x90>  // b.pmore
    5858:	11000421 	add	w1, w1, #0x1
    585c:	39000001 	strb	w1, [x0]
    5860:	d65f03c0 	ret
    5864:	72003c3f 	tst	w1, #0xffff
    5868:	54ffff00 	b.eq	5848 <fwp_rc_dup+0x68>  // b.none
    586c:	d65f03c0 	ret
    5870:	17fffbcd 	b	47a4 <fwp_rc_wide_dup>

0000000000005874 <fwp_owned_entry173>:
    5874:	d10103ff 	sub	sp, sp, #0x40
    5878:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    587c:	f947f442 	ldr	x2, [x2, #4072]
    5880:	a9027bfd 	stp	x29, x30, [sp, #32]
    5884:	910083fd 	add	x29, sp, #0x20
    5888:	a90353f3 	stp	x19, x20, [sp, #48]
    588c:	f9400043 	ldr	x3, [x2]
    5890:	f9000fe3 	str	x3, [sp, #24]
    5894:	d2800003 	mov	x3, #0x0                   	// #0
    5898:	a9400c01 	ldp	x1, x3, [x0]
    589c:	f9400802 	ldr	x2, [x0, #16]
    58a0:	ab020022 	adds	x2, x1, x2
    58a4:	540006e6 	b.vs	5980 <fwp_owned_entry173+0x10c>
    58a8:	910023e1 	add	x1, sp, #0x8
    58ac:	52800000 	mov	w0, #0x0                   	// #0
    58b0:	a9008be3 	stp	x3, x2, [sp, #8]
    58b4:	97fffe08 	bl	50d4 <fwp_data.part.0.constprop.0>
    58b8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc00>
    58bc:	91178063 	add	x3, x3, #0x5e0
    58c0:	aa0003f3 	mov	x19, x0
    58c4:	f949d861 	ldr	x1, [x3, #5040]
    58c8:	f949ec60 	ldr	x0, [x3, #5080]
    58cc:	cb010261 	sub	x1, x19, x1
    58d0:	eb00403f 	cmp	x1, x0, lsl #16
    58d4:	54000322 	b.cs	5938 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    58d8:	d350fc22 	lsr	x2, x1, #16
    58dc:	f949fc63 	ldr	x3, [x3, #5112]
    58e0:	8b020842 	add	x2, x2, x2, lsl #2
    58e4:	d37df042 	lsl	x2, x2, #3
    58e8:	8b020060 	add	x0, x3, x2
    58ec:	f9401014 	ldr	x20, [x0, #32]
    58f0:	b4000254 	cbz	x20, 5938 <fwp_owned_entry173+0xc4>
    58f4:	38626862 	ldrb	w2, [x3, x2]
    58f8:	7100085f 	cmp	w2, #0x2
    58fc:	54000360 	b.eq	5968 <fwp_owned_entry173+0xf4>  // b.none
    5900:	7100045f 	cmp	w2, #0x1
    5904:	540001a1 	b.ne	5938 <fwp_owned_entry173+0xc4>  // b.any
    5908:	29430002 	ldp	w2, w0, [x0, #24]
    590c:	92403c21 	and	x1, x1, #0xffff
    5910:	9b027c21 	mul	x1, x1, x2
    5914:	d360fc21 	lsr	x1, x1, #32
    5918:	eb00003f 	cmp	x1, x0
    591c:	540000e2 	b.cs	5938 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5920:	8b010294 	add	x20, x20, x1
    5924:	39400280 	ldrb	w0, [x20]
    5928:	7103fc1f 	cmp	w0, #0xff
    592c:	54000240 	b.eq	5974 <fwp_owned_entry173+0x100>  // b.none
    5930:	52800020 	mov	w0, #0x1                   	// #1
    5934:	39000280 	strb	w0, [x20]
    5938:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    593c:	f947f400 	ldr	x0, [x0, #4072]
    5940:	f9400fe2 	ldr	x2, [sp, #24]
    5944:	f9400001 	ldr	x1, [x0]
    5948:	eb010042 	subs	x2, x2, x1
    594c:	d2800001 	mov	x1, #0x0                   	// #0
    5950:	540001a1 	b.ne	5984 <fwp_owned_entry173+0x110>  // b.any
    5954:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5958:	aa1303e0 	mov	x0, x19
    595c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5960:	910103ff 	add	sp, sp, #0x40
    5964:	d65f03c0 	ret
    5968:	72003c3f 	tst	w1, #0xffff
    596c:	54fffe61 	b.ne	5938 <fwp_owned_entry173+0xc4>  // b.any
    5970:	17ffffed 	b	5924 <fwp_owned_entry173+0xb0>
    5974:	aa1403e0 	mov	x0, x20
    5978:	97fffbd2 	bl	48c0 <fwp_rc_forget_slot>
    597c:	17ffffed 	b	5930 <fwp_owned_entry173+0xbc>
    5980:	97fff460 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5984:	97fff3e3 	bl	2910 <__stack_chk_fail@plt>
    5988:	d503201f 	nop
    598c:	d503201f 	nop

0000000000005990 <e173>:
    5990:	d10103ff 	sub	sp, sp, #0x40
    5994:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5998:	f947f442 	ldr	x2, [x2, #4072]
    599c:	a9027bfd 	stp	x29, x30, [sp, #32]
    59a0:	910083fd 	add	x29, sp, #0x20
    59a4:	a90353f3 	stp	x19, x20, [sp, #48]
    59a8:	f9400043 	ldr	x3, [x2]
    59ac:	f9000fe3 	str	x3, [sp, #24]
    59b0:	d2800003 	mov	x3, #0x0                   	// #0
    59b4:	a9400c01 	ldp	x1, x3, [x0]
    59b8:	f9400802 	ldr	x2, [x0, #16]
    59bc:	ab020022 	adds	x2, x1, x2
    59c0:	54000726 	b.vs	5aa4 <e173+0x114>
    59c4:	910023e1 	add	x1, sp, #0x8
    59c8:	52800000 	mov	w0, #0x0                   	// #0
    59cc:	a9008be3 	stp	x3, x2, [sp, #8]
    59d0:	97fffdc1 	bl	50d4 <fwp_data.part.0.constprop.0>
    59d4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc00>
    59d8:	91178063 	add	x3, x3, #0x5e0
    59dc:	aa0003f3 	mov	x19, x0
    59e0:	f949d861 	ldr	x1, [x3, #5040]
    59e4:	f949ec60 	ldr	x0, [x3, #5080]
    59e8:	cb010261 	sub	x1, x19, x1
    59ec:	eb00403f 	cmp	x1, x0, lsl #16
    59f0:	54000322 	b.cs	5a54 <e173+0xc4>  // b.hs, b.nlast
    59f4:	d350fc22 	lsr	x2, x1, #16
    59f8:	f949fc63 	ldr	x3, [x3, #5112]
    59fc:	8b020842 	add	x2, x2, x2, lsl #2
    5a00:	d37df042 	lsl	x2, x2, #3
    5a04:	8b020060 	add	x0, x3, x2
    5a08:	f9401014 	ldr	x20, [x0, #32]
    5a0c:	b4000254 	cbz	x20, 5a54 <e173+0xc4>
    5a10:	38626862 	ldrb	w2, [x3, x2]
    5a14:	7100085f 	cmp	w2, #0x2
    5a18:	540003a0 	b.eq	5a8c <e173+0xfc>  // b.none
    5a1c:	7100045f 	cmp	w2, #0x1
    5a20:	540001a1 	b.ne	5a54 <e173+0xc4>  // b.any
    5a24:	29430002 	ldp	w2, w0, [x0, #24]
    5a28:	92403c21 	and	x1, x1, #0xffff
    5a2c:	9b027c21 	mul	x1, x1, x2
    5a30:	d360fc21 	lsr	x1, x1, #32
    5a34:	eb00003f 	cmp	x1, x0
    5a38:	540000e2 	b.cs	5a54 <e173+0xc4>  // b.hs, b.nlast
    5a3c:	8b010294 	add	x20, x20, x1
    5a40:	39400280 	ldrb	w0, [x20]
    5a44:	7103fc1f 	cmp	w0, #0xff
    5a48:	54000280 	b.eq	5a98 <e173+0x108>  // b.none
    5a4c:	52800020 	mov	w0, #0x1                   	// #1
    5a50:	39000280 	strb	w0, [x20]
    5a54:	aa1303e0 	mov	x0, x19
    5a58:	97ffff1a 	bl	56c0 <fwp_rc_share>
    5a5c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5a60:	f947f400 	ldr	x0, [x0, #4072]
    5a64:	f9400fe2 	ldr	x2, [sp, #24]
    5a68:	f9400001 	ldr	x1, [x0]
    5a6c:	eb010042 	subs	x2, x2, x1
    5a70:	d2800001 	mov	x1, #0x0                   	// #0
    5a74:	540001a1 	b.ne	5aa8 <e173+0x118>  // b.any
    5a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a7c:	aa1303e0 	mov	x0, x19
    5a80:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a84:	910103ff 	add	sp, sp, #0x40
    5a88:	d65f03c0 	ret
    5a8c:	72003c3f 	tst	w1, #0xffff
    5a90:	54fffe21 	b.ne	5a54 <e173+0xc4>  // b.any
    5a94:	17ffffeb 	b	5a40 <e173+0xb0>
    5a98:	aa1403e0 	mov	x0, x20
    5a9c:	97fffb89 	bl	48c0 <fwp_rc_forget_slot>
    5aa0:	17ffffeb 	b	5a4c <e173+0xbc>
    5aa4:	97fff417 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5aa8:	97fff39a 	bl	2910 <__stack_chk_fail@plt>
    5aac:	d503201f 	nop

0000000000005ab0 <fwp_drop1>:
    5ab0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ab4:	910003fd 	mov	x29, sp
    5ab8:	a90153f3 	stp	x19, x20, [sp, #16]
    5abc:	f90013f5 	str	x21, [sp, #32]
    5ac0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc00>
    5ac4:	911782b4 	add	x20, x21, #0x5e0
    5ac8:	f949da81 	ldr	x1, [x20, #5040]
    5acc:	f949ee82 	ldr	x2, [x20, #5080]
    5ad0:	cb010001 	sub	x1, x0, x1
    5ad4:	eb02403f 	cmp	x1, x2, lsl #16
    5ad8:	54000382 	b.cs	5b48 <fwp_drop1+0x98>  // b.hs, b.nlast
    5adc:	d350fc22 	lsr	x2, x1, #16
    5ae0:	f949fe84 	ldr	x4, [x20, #5112]
    5ae4:	8b020842 	add	x2, x2, x2, lsl #2
    5ae8:	d37df042 	lsl	x2, x2, #3
    5aec:	8b020083 	add	x3, x4, x2
    5af0:	f9401073 	ldr	x19, [x3, #32]
    5af4:	b40002b3 	cbz	x19, 5b48 <fwp_drop1+0x98>
    5af8:	38626882 	ldrb	w2, [x4, x2]
    5afc:	7100085f 	cmp	w2, #0x2
    5b00:	540002c0 	b.eq	5b58 <fwp_drop1+0xa8>  // b.none
    5b04:	7100045f 	cmp	w2, #0x1
    5b08:	54000201 	b.ne	5b48 <fwp_drop1+0x98>  // b.any
    5b0c:	29430864 	ldp	w4, w2, [x3, #24]
    5b10:	92403c21 	and	x1, x1, #0xffff
    5b14:	9b047c21 	mul	x1, x1, x4
    5b18:	d360fc21 	lsr	x1, x1, #32
    5b1c:	eb02003f 	cmp	x1, x2
    5b20:	54000142 	b.cs	5b48 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b24:	8b010273 	add	x19, x19, x1
    5b28:	39400261 	ldrb	w1, [x19]
    5b2c:	340000e1 	cbz	w1, 5b48 <fwp_drop1+0x98>
    5b30:	7100043f 	cmp	w1, #0x1
    5b34:	540001e0 	b.eq	5b70 <fwp_drop1+0xc0>  // b.none
    5b38:	7103fc3f 	cmp	w1, #0xff
    5b3c:	540002e0 	b.eq	5b98 <fwp_drop1+0xe8>  // b.none
    5b40:	51000421 	sub	w1, w1, #0x1
    5b44:	39000261 	strb	w1, [x19]
    5b48:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b4c:	f94013f5 	ldr	x21, [sp, #32]
    5b50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b54:	d65f03c0 	ret
    5b58:	72003c3f 	tst	w1, #0xffff
    5b5c:	54fffe60 	b.eq	5b28 <fwp_drop1+0x78>  // b.none
    5b60:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b64:	f94013f5 	ldr	x21, [sp, #32]
    5b68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b6c:	d65f03c0 	ret
    5b70:	f9400813 	ldr	x19, [x0, #16]
    5b74:	97fffef8 	bl	5754 <fwp_rc_free_arr>
    5b78:	911782a0 	add	x0, x21, #0x5e0
    5b7c:	f949d801 	ldr	x1, [x0, #5040]
    5b80:	f949ec00 	ldr	x0, [x0, #5080]
    5b84:	cb010261 	sub	x1, x19, x1
    5b88:	eb00403f 	cmp	x1, x0, lsl #16
    5b8c:	54fffde2 	b.cs	5b48 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b90:	aa1303e0 	mov	x0, x19
    5b94:	17ffffd2 	b	5adc <fwp_drop1+0x2c>
    5b98:	ca534660 	eor	x0, x19, x19, lsr #17
    5b9c:	911782b5 	add	x21, x21, #0x5e0
    5ba0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ba4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5ba8:	f94a2400 	ldr	x0, [x0, #5192]
    5bac:	b5000080 	cbnz	x0, 5bbc <fwp_drop1+0x10c>
    5bb0:	14000010 	b	5bf0 <fwp_drop1+0x140>
    5bb4:	f9400800 	ldr	x0, [x0, #16]
    5bb8:	b40001c0 	cbz	x0, 5bf0 <fwp_drop1+0x140>
    5bbc:	f9400001 	ldr	x1, [x0]
    5bc0:	eb13003f 	cmp	x1, x19
    5bc4:	54ffff81 	b.ne	5bb4 <fwp_drop1+0x104>  // b.any
    5bc8:	f9400401 	ldr	x1, [x0, #8]
    5bcc:	d1000421 	sub	x1, x1, #0x1
    5bd0:	f9000401 	str	x1, [x0, #8]
    5bd4:	f103f83f 	cmp	x1, #0xfe
    5bd8:	54fffb81 	b.ne	5b48 <fwp_drop1+0x98>  // b.any
    5bdc:	aa1303e0 	mov	x0, x19
    5be0:	97fffb38 	bl	48c0 <fwp_rc_forget_slot>
    5be4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5be8:	39000260 	strb	w0, [x19]
    5bec:	17ffffd7 	b	5b48 <fwp_drop1+0x98>
    5bf0:	90000020 	adrp	x0, 9000 <__divti3+0x370>
    5bf4:	911c4000 	add	x0, x0, #0x710
    5bf8:	97fff722 	bl	3880 <fwp_trap>
    5bfc:	d503201f 	nop

0000000000005c00 <fwp_drop0>:
    5c00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c04:	910003fd 	mov	x29, sp
    5c08:	a90153f3 	stp	x19, x20, [sp, #16]
    5c0c:	f90013f5 	str	x21, [sp, #32]
    5c10:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc00>
    5c14:	911782b4 	add	x20, x21, #0x5e0
    5c18:	f949da81 	ldr	x1, [x20, #5040]
    5c1c:	f949ee82 	ldr	x2, [x20, #5080]
    5c20:	cb010001 	sub	x1, x0, x1
    5c24:	eb02403f 	cmp	x1, x2, lsl #16
    5c28:	54000382 	b.cs	5c98 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c2c:	d350fc22 	lsr	x2, x1, #16
    5c30:	f949fe84 	ldr	x4, [x20, #5112]
    5c34:	8b020842 	add	x2, x2, x2, lsl #2
    5c38:	d37df042 	lsl	x2, x2, #3
    5c3c:	8b020083 	add	x3, x4, x2
    5c40:	f9401073 	ldr	x19, [x3, #32]
    5c44:	b40002b3 	cbz	x19, 5c98 <fwp_drop0+0x98>
    5c48:	38626882 	ldrb	w2, [x4, x2]
    5c4c:	7100085f 	cmp	w2, #0x2
    5c50:	540002c0 	b.eq	5ca8 <fwp_drop0+0xa8>  // b.none
    5c54:	7100045f 	cmp	w2, #0x1
    5c58:	54000201 	b.ne	5c98 <fwp_drop0+0x98>  // b.any
    5c5c:	29430864 	ldp	w4, w2, [x3, #24]
    5c60:	92403c21 	and	x1, x1, #0xffff
    5c64:	9b047c21 	mul	x1, x1, x4
    5c68:	d360fc21 	lsr	x1, x1, #32
    5c6c:	eb02003f 	cmp	x1, x2
    5c70:	54000142 	b.cs	5c98 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c74:	8b010273 	add	x19, x19, x1
    5c78:	39400261 	ldrb	w1, [x19]
    5c7c:	340000e1 	cbz	w1, 5c98 <fwp_drop0+0x98>
    5c80:	7100043f 	cmp	w1, #0x1
    5c84:	540001e0 	b.eq	5cc0 <fwp_drop0+0xc0>  // b.none
    5c88:	7103fc3f 	cmp	w1, #0xff
    5c8c:	540002e0 	b.eq	5ce8 <fwp_drop0+0xe8>  // b.none
    5c90:	51000421 	sub	w1, w1, #0x1
    5c94:	39000261 	strb	w1, [x19]
    5c98:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c9c:	f94013f5 	ldr	x21, [sp, #32]
    5ca0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ca4:	d65f03c0 	ret
    5ca8:	72003c3f 	tst	w1, #0xffff
    5cac:	54fffe60 	b.eq	5c78 <fwp_drop0+0x78>  // b.none
    5cb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cb4:	f94013f5 	ldr	x21, [sp, #32]
    5cb8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cbc:	d65f03c0 	ret
    5cc0:	f9400813 	ldr	x19, [x0, #16]
    5cc4:	97fffea4 	bl	5754 <fwp_rc_free_arr>
    5cc8:	911782a0 	add	x0, x21, #0x5e0
    5ccc:	f949d801 	ldr	x1, [x0, #5040]
    5cd0:	f949ec00 	ldr	x0, [x0, #5080]
    5cd4:	cb010261 	sub	x1, x19, x1
    5cd8:	eb00403f 	cmp	x1, x0, lsl #16
    5cdc:	54fffde2 	b.cs	5c98 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ce0:	aa1303e0 	mov	x0, x19
    5ce4:	17ffffd2 	b	5c2c <fwp_drop0+0x2c>
    5ce8:	ca534660 	eor	x0, x19, x19, lsr #17
    5cec:	911782b5 	add	x21, x21, #0x5e0
    5cf0:	ca402400 	eor	x0, x0, x0, lsr #9
    5cf4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5cf8:	f94a2400 	ldr	x0, [x0, #5192]
    5cfc:	b5000080 	cbnz	x0, 5d0c <fwp_drop0+0x10c>
    5d00:	14000010 	b	5d40 <fwp_drop0+0x140>
    5d04:	f9400800 	ldr	x0, [x0, #16]
    5d08:	b40001c0 	cbz	x0, 5d40 <fwp_drop0+0x140>
    5d0c:	f9400001 	ldr	x1, [x0]
    5d10:	eb13003f 	cmp	x1, x19
    5d14:	54ffff81 	b.ne	5d04 <fwp_drop0+0x104>  // b.any
    5d18:	f9400401 	ldr	x1, [x0, #8]
    5d1c:	d1000421 	sub	x1, x1, #0x1
    5d20:	f9000401 	str	x1, [x0, #8]
    5d24:	f103f83f 	cmp	x1, #0xfe
    5d28:	54fffb81 	b.ne	5c98 <fwp_drop0+0x98>  // b.any
    5d2c:	aa1303e0 	mov	x0, x19
    5d30:	97fffae4 	bl	48c0 <fwp_rc_forget_slot>
    5d34:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d38:	39000260 	strb	w0, [x19]
    5d3c:	17ffffd7 	b	5c98 <fwp_drop0+0x98>
    5d40:	90000020 	adrp	x0, 9000 <__divti3+0x370>
    5d44:	911c4000 	add	x0, x0, #0x710
    5d48:	97fff6ce 	bl	3880 <fwp_trap>
    5d4c:	d503201f 	nop

0000000000005d50 <fwp_closure_drop>:
    5d50:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc00>
    5d54:	911780a4 	add	x4, x5, #0x5e0
    5d58:	aa0003e1 	mov	x1, x0
    5d5c:	f949d882 	ldr	x2, [x4, #5040]
    5d60:	f949ec80 	ldr	x0, [x4, #5080]
    5d64:	cb020022 	sub	x2, x1, x2
    5d68:	eb00405f 	cmp	x2, x0, lsl #16
    5d6c:	54000662 	b.cs	5e38 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5d70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5d74:	d350fc43 	lsr	x3, x2, #16
    5d78:	910003fd 	mov	x29, sp
    5d7c:	8b030863 	add	x3, x3, x3, lsl #2
    5d80:	f949fc84 	ldr	x4, [x4, #5112]
    5d84:	d37df063 	lsl	x3, x3, #3
    5d88:	f9000bf3 	str	x19, [sp, #16]
    5d8c:	8b030080 	add	x0, x4, x3
    5d90:	f9401013 	ldr	x19, [x0, #32]
    5d94:	b40002b3 	cbz	x19, 5de8 <fwp_closure_drop+0x98>
    5d98:	38636883 	ldrb	w3, [x4, x3]
    5d9c:	7100087f 	cmp	w3, #0x2
    5da0:	54000420 	b.eq	5e24 <fwp_closure_drop+0xd4>  // b.none
    5da4:	7100047f 	cmp	w3, #0x1
    5da8:	54000201 	b.ne	5de8 <fwp_closure_drop+0x98>  // b.any
    5dac:	29430003 	ldp	w3, w0, [x0, #24]
    5db0:	92403c42 	and	x2, x2, #0xffff
    5db4:	9b037c42 	mul	x2, x2, x3
    5db8:	d360fc42 	lsr	x2, x2, #32
    5dbc:	eb00005f 	cmp	x2, x0
    5dc0:	54000142 	b.cs	5de8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5dc4:	8b020273 	add	x19, x19, x2
    5dc8:	39400260 	ldrb	w0, [x19]
    5dcc:	340000e0 	cbz	w0, 5de8 <fwp_closure_drop+0x98>
    5dd0:	7100041f 	cmp	w0, #0x1
    5dd4:	54000100 	b.eq	5df4 <fwp_closure_drop+0xa4>  // b.none
    5dd8:	7103fc1f 	cmp	w0, #0xff
    5ddc:	54000300 	b.eq	5e3c <fwp_closure_drop+0xec>  // b.none
    5de0:	51000400 	sub	w0, w0, #0x1
    5de4:	39000260 	strb	w0, [x19]
    5de8:	f9400bf3 	ldr	x19, [sp, #16]
    5dec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5df0:	d65f03c0 	ret
    5df4:	d53bd040 	mrs	x0, tpidr_el0
    5df8:	91400000 	add	x0, x0, #0x0, lsl #12
    5dfc:	91004000 	add	x0, x0, #0x10
    5e00:	f9400000 	ldr	x0, [x0]
    5e04:	b4000080 	cbz	x0, 5e14 <fwp_closure_drop+0xc4>
    5e08:	f9400bf3 	ldr	x19, [sp, #16]
    5e0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e10:	17fff6b5 	b	38e4 <fwp_closure_drop_push>
    5e14:	f9400bf3 	ldr	x19, [sp, #16]
    5e18:	aa0103e0 	mov	x0, x1
    5e1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e20:	17fff720 	b	3aa0 <fwp_closure_drop.part.0>
    5e24:	72003c5f 	tst	w2, #0xffff
    5e28:	54fffd00 	b.eq	5dc8 <fwp_closure_drop+0x78>  // b.none
    5e2c:	f9400bf3 	ldr	x19, [sp, #16]
    5e30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e34:	d65f03c0 	ret
    5e38:	d65f03c0 	ret
    5e3c:	ca534660 	eor	x0, x19, x19, lsr #17
    5e40:	911780a5 	add	x5, x5, #0x5e0
    5e44:	ca402400 	eor	x0, x0, x0, lsr #9
    5e48:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5e4c:	f94a2400 	ldr	x0, [x0, #5192]
    5e50:	b5000080 	cbnz	x0, 5e60 <fwp_closure_drop+0x110>
    5e54:	14000010 	b	5e94 <fwp_closure_drop+0x144>
    5e58:	f9400800 	ldr	x0, [x0, #16]
    5e5c:	b40001c0 	cbz	x0, 5e94 <fwp_closure_drop+0x144>
    5e60:	f9400001 	ldr	x1, [x0]
    5e64:	eb13003f 	cmp	x1, x19
    5e68:	54ffff81 	b.ne	5e58 <fwp_closure_drop+0x108>  // b.any
    5e6c:	f9400401 	ldr	x1, [x0, #8]
    5e70:	d1000421 	sub	x1, x1, #0x1
    5e74:	f9000401 	str	x1, [x0, #8]
    5e78:	f103f83f 	cmp	x1, #0xfe
    5e7c:	54fffb61 	b.ne	5de8 <fwp_closure_drop+0x98>  // b.any
    5e80:	aa1303e0 	mov	x0, x19
    5e84:	97fffa8f 	bl	48c0 <fwp_rc_forget_slot>
    5e88:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e8c:	39000260 	strb	w0, [x19]
    5e90:	17ffffd6 	b	5de8 <fwp_closure_drop+0x98>
    5e94:	90000020 	adrp	x0, 9000 <__divti3+0x370>
    5e98:	911c4000 	add	x0, x0, #0x710
    5e9c:	97fff679 	bl	3880 <fwp_trap>

0000000000005ea0 <fwp_owned_tape_release>:
    5ea0:	b4000940 	cbz	x0, 5fc8 <fwp_owned_tape_release+0x128>
    5ea4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ea8:	910003fd 	mov	x29, sp
    5eac:	a90153f3 	stp	x19, x20, [sp, #16]
    5eb0:	aa0003f3 	mov	x19, x0
    5eb4:	f9400000 	ldr	x0, [x0]
    5eb8:	b4000060 	cbz	x0, 5ec4 <fwp_owned_tape_release+0x24>
    5ebc:	f9400661 	ldr	x1, [x19, #8]
    5ec0:	f9000401 	str	x1, [x0, #8]
    5ec4:	f9400661 	ldr	x1, [x19, #8]
    5ec8:	b4000041 	cbz	x1, 5ed0 <fwp_owned_tape_release+0x30>
    5ecc:	f9000020 	str	x0, [x1]
    5ed0:	f9400a60 	ldr	x0, [x19, #16]
    5ed4:	f9403401 	ldr	x1, [x0, #104]
    5ed8:	b40005c1 	cbz	x1, 5f90 <fwp_owned_tape_release+0xf0>
    5edc:	a9450a60 	ldp	x0, x2, [x19, #80]
    5ee0:	eb00005f 	cmp	x2, x0
    5ee4:	540002ed 	b.le	5f40 <fwp_owned_tape_release+0xa0>
    5ee8:	d2800014 	mov	x20, #0x0                   	// #0
    5eec:	f90013f5 	str	x21, [sp, #32]
    5ef0:	d2800015 	mov	x21, #0x0                   	// #0
    5ef4:	d503201f 	nop
    5ef8:	f9402260 	ldr	x0, [x19, #64]
    5efc:	910006b5 	add	x21, x21, #0x1
    5f00:	f8746800 	ldr	x0, [x0, x20]
    5f04:	d63f0020 	blr	x1
    5f08:	f9402260 	ldr	x0, [x19, #64]
    5f0c:	f9400a61 	ldr	x1, [x19, #16]
    5f10:	8b140000 	add	x0, x0, x20
    5f14:	91004294 	add	x20, x20, #0x10
    5f18:	f9400400 	ldr	x0, [x0, #8]
    5f1c:	f9403421 	ldr	x1, [x1, #104]
    5f20:	d63f0020 	blr	x1
    5f24:	a9450261 	ldp	x1, x0, [x19, #80]
    5f28:	cb010000 	sub	x0, x0, x1
    5f2c:	eb15001f 	cmp	x0, x21
    5f30:	f9400a60 	ldr	x0, [x19, #16]
    5f34:	f9403401 	ldr	x1, [x0, #104]
    5f38:	54fffe0c 	b.gt	5ef8 <fwp_owned_tape_release+0x58>
    5f3c:	f94013f5 	ldr	x21, [sp, #32]
    5f40:	f9403663 	ldr	x3, [x19, #104]
    5f44:	f9401262 	ldr	x2, [x19, #32]
    5f48:	f100007f 	cmp	x3, #0x0
    5f4c:	540001ed 	b.le	5f88 <fwp_owned_tape_release+0xe8>
    5f50:	d2800014 	mov	x20, #0x0                   	// #0
    5f54:	d503201f 	nop
    5f58:	f9402660 	ldr	x0, [x19, #72]
    5f5c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5f60:	eb02001f 	cmp	x0, x2
    5f64:	540000c0 	b.eq	5f7c <fwp_owned_tape_release+0xdc>  // b.none
    5f68:	d63f0020 	blr	x1
    5f6c:	f9400a60 	ldr	x0, [x19, #16]
    5f70:	f9401262 	ldr	x2, [x19, #32]
    5f74:	f9403663 	ldr	x3, [x19, #104]
    5f78:	f9403401 	ldr	x1, [x0, #104]
    5f7c:	91000694 	add	x20, x20, #0x1
    5f80:	eb14007f 	cmp	x3, x20
    5f84:	54fffeac 	b.gt	5f58 <fwp_owned_tape_release+0xb8>
    5f88:	aa0203e0 	mov	x0, x2
    5f8c:	d63f0020 	blr	x1
    5f90:	f9401660 	ldr	x0, [x19, #40]
    5f94:	97ffff6f 	bl	5d50 <fwp_closure_drop>
    5f98:	f9401a60 	ldr	x0, [x19, #48]
    5f9c:	97ffff6d 	bl	5d50 <fwp_closure_drop>
    5fa0:	f9401e60 	ldr	x0, [x19, #56]
    5fa4:	97ffff6b 	bl	5d50 <fwp_closure_drop>
    5fa8:	f9402260 	ldr	x0, [x19, #64]
    5fac:	97fffae5 	bl	4b40 <fwp_mem_free>
    5fb0:	f9402660 	ldr	x0, [x19, #72]
    5fb4:	97fffae3 	bl	4b40 <fwp_mem_free>
    5fb8:	aa1303e0 	mov	x0, x19
    5fbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fc0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fc4:	17fffadf 	b	4b40 <fwp_mem_free>
    5fc8:	d65f03c0 	ret
    5fcc:	d503201f 	nop

0000000000005fd0 <fwp_tape_finish>:
    5fd0:	d10203ff 	sub	sp, sp, #0x80
    5fd4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5fd8:	f947f421 	ldr	x1, [x1, #4072]
    5fdc:	a9047bfd 	stp	x29, x30, [sp, #64]
    5fe0:	910103fd 	add	x29, sp, #0x40
    5fe4:	a90553f3 	stp	x19, x20, [sp, #80]
    5fe8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5fec:	a90763f7 	stp	x23, x24, [sp, #112]
    5ff0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5ff4:	91018316 	add	x22, x24, #0x60
    5ff8:	f9400022 	ldr	x2, [x1]
    5ffc:	f9001fe2 	str	x2, [sp, #56]
    6000:	d2800002 	mov	x2, #0x0                   	// #0
    6004:	9102e2c0 	add	x0, x22, #0xb8
    6008:	97fff53e 	bl	3500 <fwp_tape_buffers_dispose>
    600c:	f9007adf 	str	xzr, [x22, #240]
    6010:	f9404ac0 	ldr	x0, [x22, #144]
    6014:	f100001f 	cmp	x0, #0x0
    6018:	5400030d 	b.le	6078 <fwp_tape_finish+0xa8>
    601c:	910003f7 	mov	x23, sp
    6020:	d2800015 	mov	x21, #0x0                   	// #0
    6024:	d2800014 	mov	x20, #0x0                   	// #0
    6028:	f94002d3 	ldr	x19, [x22]
    602c:	91000694 	add	x20, x20, #0x1
    6030:	8b150273 	add	x19, x19, x21
    6034:	9101a2b5 	add	x21, x21, #0x68
    6038:	aa1303e0 	mov	x0, x19
    603c:	97fff3f5 	bl	3010 <fwp_tape_unlink_scope>
    6040:	aa1703e0 	mov	x0, x23
    6044:	f9401261 	ldr	x1, [x19, #32]
    6048:	f90003e1 	str	x1, [sp]
    604c:	f9401a62 	ldr	x2, [x19, #48]
    6050:	f9000be2 	str	x2, [sp, #16]
    6054:	f9402261 	ldr	x1, [x19, #64]
    6058:	f90013e1 	str	x1, [sp, #32]
    605c:	97fff529 	bl	3500 <fwp_tape_buffers_dispose>
    6060:	f9403260 	ldr	x0, [x19, #96]
    6064:	97ffff8f 	bl	5ea0 <fwp_owned_tape_release>
    6068:	f900327f 	str	xzr, [x19, #96]
    606c:	f9404ac0 	ldr	x0, [x22, #144]
    6070:	eb14001f 	cmp	x0, x20
    6074:	54fffdac 	b.gt	6028 <fwp_tape_finish+0x58>
    6078:	f9403300 	ldr	x0, [x24, #96]
    607c:	91018313 	add	x19, x24, #0x60
    6080:	97fff254 	bl	29d0 <free@plt>
    6084:	f900331f 	str	xzr, [x24, #96]
    6088:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    608c:	f947f400 	ldr	x0, [x0, #4072]
    6090:	f9004a7f 	str	xzr, [x19, #144]
    6094:	a9107e7f 	stp	xzr, xzr, [x19, #256]
    6098:	f9401fe2 	ldr	x2, [sp, #56]
    609c:	f9400001 	ldr	x1, [x0]
    60a0:	eb010042 	subs	x2, x2, x1
    60a4:	d2800001 	mov	x1, #0x0                   	// #0
    60a8:	540000e1 	b.ne	60c4 <fwp_tape_finish+0xf4>  // b.any
    60ac:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60b0:	a94553f3 	ldp	x19, x20, [sp, #80]
    60b4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    60b8:	a94763f7 	ldp	x23, x24, [sp, #112]
    60bc:	910203ff 	add	sp, sp, #0x80
    60c0:	d65f03c0 	ret
    60c4:	97fff213 	bl	2910 <__stack_chk_fail@plt>
    60c8:	d503201f 	nop
    60cc:	d503201f 	nop

00000000000060d0 <fwp_tape_scope_release>:
    60d0:	d10243ff 	sub	sp, sp, #0x90
    60d4:	a9047bfd 	stp	x29, x30, [sp, #64]
    60d8:	910103fd 	add	x29, sp, #0x40
    60dc:	a90553f3 	stp	x19, x20, [sp, #80]
    60e0:	aa0003f4 	mov	x20, x0
    60e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    60e8:	f947f400 	ldr	x0, [x0, #4072]
    60ec:	b9400285 	ldr	w5, [x20]
    60f0:	f9400001 	ldr	x1, [x0]
    60f4:	f9001fe1 	str	x1, [sp, #56]
    60f8:	d2800001 	mov	x1, #0x0                   	// #0
    60fc:	37f806c5 	tbnz	w5, #31, 61d4 <fwp_tape_scope_release+0x104>
    6100:	a90763f7 	stp	x23, x24, [sp, #112]
    6104:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6108:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    610c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6110:	d00000d3 	adrp	x19, 20000 <__data_start>
    6114:	910003f7 	mov	x23, sp
    6118:	91018273 	add	x19, x19, #0x60
    611c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6120:	a9065bf5 	stp	x21, x22, [sp, #96]
    6124:	52800d16 	mov	w22, #0x68                  	// #104
    6128:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    612c:	f90043f9 	str	x25, [sp, #128]
    6130:	14000006 	b	6148 <fwp_tape_scope_release+0x78>
    6134:	97fff4f3 	bl	3500 <fwp_tape_buffers_dispose>
    6138:	aa1903e0 	mov	x0, x25
    613c:	97ffff59 	bl	5ea0 <fwp_owned_tape_release>
    6140:	b9400285 	ldr	w5, [x20]
    6144:	37f80425 	tbnz	w5, #31, 61c8 <fwp_tape_scope_release+0xf8>
    6148:	f9400266 	ldr	x6, [x19]
    614c:	9b367ca5 	smull	x5, w5, w22
    6150:	8b0500c0 	add	x0, x6, x5
    6154:	97fff3af 	bl	3010 <fwp_tape_unlink_scope>
    6158:	ad410001 	ldp	q1, q0, [x0, #32]
    615c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6160:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6164:	f9400c03 	ldr	x3, [x0, #24]
    6168:	ad0003e1 	stp	q1, q0, [sp]
    616c:	b86568c1 	ldr	w1, [x6, x5]
    6170:	a9440804 	ldp	x4, x2, [x0, #64]
    6174:	b900041f 	str	wzr, [x0, #4]
    6178:	f9403019 	ldr	x25, [x0, #96]
    617c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6180:	f9000c1f 	str	xzr, [x0, #24]
    6184:	a9020fe4 	stp	x4, x3, [sp, #32]
    6188:	f9001be2 	str	x2, [sp, #48]
    618c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6190:	f900301f 	str	xzr, [x0, #96]
    6194:	6b15003f 	cmp	w1, w21
    6198:	540000e8 	b.hi	61b4 <fwp_tape_scope_release+0xe4>  // b.pmore
    619c:	9343fca5 	asr	x5, x5, #3
    61a0:	f9408660 	ldr	x0, [x19, #264]
    61a4:	9b187ca5 	mul	x5, x5, x24
    61a8:	eb0000bf 	cmp	x5, x0
    61ac:	5400004a 	b.ge	61b4 <fwp_tape_scope_release+0xe4>  // b.tcont
    61b0:	f9008665 	str	x5, [x19, #264]
    61b4:	aa1703e0 	mov	x0, x23
    61b8:	b5fffbf9 	cbnz	x25, 6134 <fwp_tape_scope_release+0x64>
    61bc:	97fff8a5 	bl	4450 <fwp_tape_buffers_release>
    61c0:	b9400285 	ldr	w5, [x20]
    61c4:	36fffc25 	tbz	w5, #31, 6148 <fwp_tape_scope_release+0x78>
    61c8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    61cc:	a94763f7 	ldp	x23, x24, [sp, #112]
    61d0:	f94043f9 	ldr	x25, [sp, #128]
    61d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    61d8:	f947f400 	ldr	x0, [x0, #4072]
    61dc:	f9401fe2 	ldr	x2, [sp, #56]
    61e0:	f9400001 	ldr	x1, [x0]
    61e4:	eb010042 	subs	x2, x2, x1
    61e8:	d2800001 	mov	x1, #0x0                   	// #0
    61ec:	540000a1 	b.ne	6200 <fwp_tape_scope_release+0x130>  // b.any
    61f0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    61f4:	a94553f3 	ldp	x19, x20, [sp, #80]
    61f8:	910243ff 	add	sp, sp, #0x90
    61fc:	d65f03c0 	ret
    6200:	a9065bf5 	stp	x21, x22, [sp, #96]
    6204:	a90763f7 	stp	x23, x24, [sp, #112]
    6208:	f90043f9 	str	x25, [sp, #128]
    620c:	97fff1c1 	bl	2910 <__stack_chk_fail@plt>

0000000000006210 <fwp_drop4>:
    6210:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6214:	910003fd 	mov	x29, sp
    6218:	a9025bf5 	stp	x21, x22, [sp, #32]
    621c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc00>
    6220:	911782d5 	add	x21, x22, #0x5e0
    6224:	a90153f3 	stp	x19, x20, [sp, #16]
    6228:	aa0003f3 	mov	x19, x0
    622c:	f949daa1 	ldr	x1, [x21, #5040]
    6230:	f949eea0 	ldr	x0, [x21, #5080]
    6234:	cb010261 	sub	x1, x19, x1
    6238:	eb00403f 	cmp	x1, x0, lsl #16
    623c:	54000382 	b.cs	62ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6240:	d350fc22 	lsr	x2, x1, #16
    6244:	f949fea3 	ldr	x3, [x21, #5112]
    6248:	8b020842 	add	x2, x2, x2, lsl #2
    624c:	d37df042 	lsl	x2, x2, #3
    6250:	8b020060 	add	x0, x3, x2
    6254:	f9401014 	ldr	x20, [x0, #32]
    6258:	b40002b4 	cbz	x20, 62ac <fwp_drop4+0x9c>
    625c:	38626862 	ldrb	w2, [x3, x2]
    6260:	7100085f 	cmp	w2, #0x2
    6264:	540002c0 	b.eq	62bc <fwp_drop4+0xac>  // b.none
    6268:	7100045f 	cmp	w2, #0x1
    626c:	54000201 	b.ne	62ac <fwp_drop4+0x9c>  // b.any
    6270:	29430002 	ldp	w2, w0, [x0, #24]
    6274:	92403c21 	and	x1, x1, #0xffff
    6278:	9b027c21 	mul	x1, x1, x2
    627c:	d360fc21 	lsr	x1, x1, #32
    6280:	eb00003f 	cmp	x1, x0
    6284:	54000142 	b.cs	62ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6288:	8b010294 	add	x20, x20, x1
    628c:	39400280 	ldrb	w0, [x20]
    6290:	340000e0 	cbz	w0, 62ac <fwp_drop4+0x9c>
    6294:	7100041f 	cmp	w0, #0x1
    6298:	540001e0 	b.eq	62d4 <fwp_drop4+0xc4>  // b.none
    629c:	7103fc1f 	cmp	w0, #0xff
    62a0:	540007c0 	b.eq	6398 <fwp_drop4+0x188>  // b.none
    62a4:	51000400 	sub	w0, w0, #0x1
    62a8:	39000280 	strb	w0, [x20]
    62ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    62b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    62b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62b8:	d65f03c0 	ret
    62bc:	72003c3f 	tst	w1, #0xffff
    62c0:	54fffe60 	b.eq	628c <fwp_drop4+0x7c>  // b.none
    62c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    62c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    62cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62d0:	d65f03c0 	ret
    62d4:	911782c2 	add	x2, x22, #0x5e0
    62d8:	f9400660 	ldr	x0, [x19, #8]
    62dc:	f949d841 	ldr	x1, [x2, #5040]
    62e0:	f949ec42 	ldr	x2, [x2, #5080]
    62e4:	cb010001 	sub	x1, x0, x1
    62e8:	eb02403f 	cmp	x1, x2, lsl #16
    62ec:	54000362 	b.cs	6358 <fwp_drop4+0x148>  // b.hs, b.nlast
    62f0:	d350fc22 	lsr	x2, x1, #16
    62f4:	8b020842 	add	x2, x2, x2, lsl #2
    62f8:	d37df042 	lsl	x2, x2, #3
    62fc:	8b020064 	add	x4, x3, x2
    6300:	f9401094 	ldr	x20, [x4, #32]
    6304:	b40002b4 	cbz	x20, 6358 <fwp_drop4+0x148>
    6308:	38626862 	ldrb	w2, [x3, x2]
    630c:	7100085f 	cmp	w2, #0x2
    6310:	540003e0 	b.eq	638c <fwp_drop4+0x17c>  // b.none
    6314:	7100045f 	cmp	w2, #0x1
    6318:	54000201 	b.ne	6358 <fwp_drop4+0x148>  // b.any
    631c:	29430883 	ldp	w3, w2, [x4, #24]
    6320:	92403c21 	and	x1, x1, #0xffff
    6324:	9b037c21 	mul	x1, x1, x3
    6328:	d360fc21 	lsr	x1, x1, #32
    632c:	eb02003f 	cmp	x1, x2
    6330:	54000142 	b.cs	6358 <fwp_drop4+0x148>  // b.hs, b.nlast
    6334:	8b010294 	add	x20, x20, x1
    6338:	39400281 	ldrb	w1, [x20]
    633c:	340000e1 	cbz	w1, 6358 <fwp_drop4+0x148>
    6340:	7100043f 	cmp	w1, #0x1
    6344:	54000200 	b.eq	6384 <fwp_drop4+0x174>  // b.none
    6348:	7103fc3f 	cmp	w1, #0xff
    634c:	54000580 	b.eq	63fc <fwp_drop4+0x1ec>  // b.none
    6350:	51000421 	sub	w1, w1, #0x1
    6354:	39000281 	strb	w1, [x20]
    6358:	f9400a74 	ldr	x20, [x19, #16]
    635c:	aa1303e0 	mov	x0, x19
    6360:	97fffcfd 	bl	5754 <fwp_rc_free_arr>
    6364:	911782c0 	add	x0, x22, #0x5e0
    6368:	f949d801 	ldr	x1, [x0, #5040]
    636c:	f949ec00 	ldr	x0, [x0, #5080]
    6370:	cb010281 	sub	x1, x20, x1
    6374:	eb00403f 	cmp	x1, x0, lsl #16
    6378:	54fff9a2 	b.cs	62ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    637c:	aa1403f3 	mov	x19, x20
    6380:	17ffffb0 	b	6240 <fwp_drop4+0x30>
    6384:	97fffcf4 	bl	5754 <fwp_rc_free_arr>
    6388:	17fffff4 	b	6358 <fwp_drop4+0x148>
    638c:	72003c3f 	tst	w1, #0xffff
    6390:	54fffe41 	b.ne	6358 <fwp_drop4+0x148>  // b.any
    6394:	17ffffe9 	b	6338 <fwp_drop4+0x128>
    6398:	ca544681 	eor	x1, x20, x20, lsr #17
    639c:	911782c0 	add	x0, x22, #0x5e0
    63a0:	ca412421 	eor	x1, x1, x1, lsr #9
    63a4:	8b210c01 	add	x1, x0, w1, uxtb #3
    63a8:	f94a2420 	ldr	x0, [x1, #5192]
    63ac:	b5000080 	cbnz	x0, 63bc <fwp_drop4+0x1ac>
    63b0:	14000010 	b	63f0 <fwp_drop4+0x1e0>
    63b4:	f9400800 	ldr	x0, [x0, #16]
    63b8:	b40001c0 	cbz	x0, 63f0 <fwp_drop4+0x1e0>
    63bc:	f9400001 	ldr	x1, [x0]
    63c0:	eb14003f 	cmp	x1, x20
    63c4:	54ffff81 	b.ne	63b4 <fwp_drop4+0x1a4>  // b.any
    63c8:	f9400401 	ldr	x1, [x0, #8]
    63cc:	d1000421 	sub	x1, x1, #0x1
    63d0:	f9000401 	str	x1, [x0, #8]
    63d4:	f103f83f 	cmp	x1, #0xfe
    63d8:	54fff6a1 	b.ne	62ac <fwp_drop4+0x9c>  // b.any
    63dc:	aa1403e0 	mov	x0, x20
    63e0:	97fff938 	bl	48c0 <fwp_rc_forget_slot>
    63e4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    63e8:	39000280 	strb	w0, [x20]
    63ec:	17ffffb0 	b	62ac <fwp_drop4+0x9c>
    63f0:	f0000000 	adrp	x0, 9000 <__divti3+0x370>
    63f4:	911c4000 	add	x0, x0, #0x710
    63f8:	97fff522 	bl	3880 <fwp_trap>
    63fc:	ca544680 	eor	x0, x20, x20, lsr #17
    6400:	911782c1 	add	x1, x22, #0x5e0
    6404:	ca402400 	eor	x0, x0, x0, lsr #9
    6408:	8b200c20 	add	x0, x1, w0, uxtb #3
    640c:	f94a2400 	ldr	x0, [x0, #5192]
    6410:	b5000080 	cbnz	x0, 6420 <fwp_drop4+0x210>
    6414:	17fffff7 	b	63f0 <fwp_drop4+0x1e0>
    6418:	f9400800 	ldr	x0, [x0, #16]
    641c:	b4fffea0 	cbz	x0, 63f0 <fwp_drop4+0x1e0>
    6420:	f9400001 	ldr	x1, [x0]
    6424:	eb14003f 	cmp	x1, x20
    6428:	54ffff81 	b.ne	6418 <fwp_drop4+0x208>  // b.any
    642c:	f9400401 	ldr	x1, [x0, #8]
    6430:	d1000421 	sub	x1, x1, #0x1
    6434:	f9000401 	str	x1, [x0, #8]
    6438:	f103f83f 	cmp	x1, #0xfe
    643c:	54fff8e1 	b.ne	6358 <fwp_drop4+0x148>  // b.any
    6440:	aa1403e0 	mov	x0, x20
    6444:	97fff91f 	bl	48c0 <fwp_rc_forget_slot>
    6448:	12800020 	mov	w0, #0xfffffffe            	// #-2
    644c:	39000280 	strb	w0, [x20]
    6450:	17ffffc2 	b	6358 <fwp_drop4+0x148>

0000000000006454 <fwp_arg_drop37>:
    6454:	7100003f 	cmp	w1, #0x0
    6458:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    645c:	54000041 	b.ne	6464 <fwp_arg_drop37+0x10>  // b.any
    6460:	d65f03c0 	ret
    6464:	f9400000 	ldr	x0, [x0]
    6468:	17ffff6a 	b	6210 <fwp_drop4>
    646c:	d503201f 	nop

0000000000006470 <fwp_task_dispose>:
    6470:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6474:	910003fd 	mov	x29, sp
    6478:	f9000bf3 	str	x19, [sp, #16]
    647c:	aa0003f3 	mov	x19, x0
    6480:	39414000 	ldrb	w0, [x0, #80]
    6484:	36000720 	tbz	w0, #0, 6568 <fwp_task_dispose+0xf8>
    6488:	f9400a60 	ldr	x0, [x19, #16]
    648c:	b50006e0 	cbnz	x0, 6568 <fwp_task_dispose+0xf8>
    6490:	a9478660 	ldp	x0, x1, [x19, #120]
    6494:	39014e7f 	strb	wzr, [x19, #83]
    6498:	f9003e7f 	str	xzr, [x19, #120]
    649c:	f100003f 	cmp	x1, #0x0
    64a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    64a4:	54000040 	b.eq	64ac <fwp_task_dispose+0x3c>  // b.none
    64a8:	d63f0020 	blr	x1
    64ac:	f9405660 	ldr	x0, [x19, #168]
    64b0:	97fff9a4 	bl	4b40 <fwp_mem_free>
    64b4:	f900567f 	str	xzr, [x19, #168]
    64b8:	b9405e60 	ldr	w0, [x19, #92]
    64bc:	7100041f 	cmp	w0, #0x1
    64c0:	54000420 	b.eq	6544 <fwp_task_dispose+0xd4>  // b.none
    64c4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc00>
    64c8:	91178042 	add	x2, x2, #0x5e0
    64cc:	f949d840 	ldr	x0, [x2, #5040]
    64d0:	f949ec41 	ldr	x1, [x2, #5080]
    64d4:	cb000260 	sub	x0, x19, x0
    64d8:	eb01401f 	cmp	x0, x1, lsl #16
    64dc:	540002e2 	b.cs	6538 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    64e0:	d350fc01 	lsr	x1, x0, #16
    64e4:	f949fc44 	ldr	x4, [x2, #5112]
    64e8:	8b010821 	add	x1, x1, x1, lsl #2
    64ec:	d37df021 	lsl	x1, x1, #3
    64f0:	8b010083 	add	x3, x4, x1
    64f4:	f9401062 	ldr	x2, [x3, #32]
    64f8:	b4000202 	cbz	x2, 6538 <fwp_task_dispose+0xc8>
    64fc:	38616881 	ldrb	w1, [x4, x1]
    6500:	7100083f 	cmp	w1, #0x2
    6504:	54000280 	b.eq	6554 <fwp_task_dispose+0xe4>  // b.none
    6508:	7100043f 	cmp	w1, #0x1
    650c:	54000161 	b.ne	6538 <fwp_task_dispose+0xc8>  // b.any
    6510:	29430464 	ldp	w4, w1, [x3, #24]
    6514:	92403c00 	and	x0, x0, #0xffff
    6518:	9b047c00 	mul	x0, x0, x4
    651c:	d360fc00 	lsr	x0, x0, #32
    6520:	eb01001f 	cmp	x0, x1
    6524:	540000a2 	b.cs	6538 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6528:	8b000042 	add	x2, x2, x0
    652c:	39400040 	ldrb	w0, [x2]
    6530:	7100041f 	cmp	w0, #0x1
    6534:	54000080 	b.eq	6544 <fwp_task_dispose+0xd4>  // b.none
    6538:	f9400bf3 	ldr	x19, [sp, #16]
    653c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6540:	d65f03c0 	ret
    6544:	aa1303e0 	mov	x0, x19
    6548:	f9400bf3 	ldr	x19, [sp, #16]
    654c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6550:	17fff97c 	b	4b40 <fwp_mem_free>
    6554:	72003c1f 	tst	w0, #0xffff
    6558:	54fffea0 	b.eq	652c <fwp_task_dispose+0xbc>  // b.none
    655c:	f9400bf3 	ldr	x19, [sp, #16]
    6560:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6564:	d65f03c0 	ret
    6568:	97fff0fe 	bl	2960 <abort@plt>
    656c:	d503201f 	nop

0000000000006570 <fwp_free_zombie>:
    6570:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6574:	910003fd 	mov	x29, sp
    6578:	a90153f3 	stp	x19, x20, [sp, #16]
    657c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6580:	91018281 	add	x1, x20, #0x60
    6584:	f9408833 	ldr	x19, [x1, #272]
    6588:	b4000333 	cbz	x19, 65ec <fwp_free_zombie+0x7c>
    658c:	f9400820 	ldr	x0, [x1, #16]
    6590:	eb00027f 	cmp	x19, x0
    6594:	540002c0 	b.eq	65ec <fwp_free_zombie+0x7c>  // b.none
    6598:	b9411822 	ldr	w2, [x1, #280]
    659c:	f9400a60 	ldr	x0, [x19, #16]
    65a0:	7100fc5f 	cmp	w2, #0x3f
    65a4:	5400078c 	b.gt	6694 <fwp_free_zombie+0x124>
    65a8:	91048023 	add	x3, x1, #0x120
    65ac:	11000444 	add	w4, w2, #0x1
    65b0:	b9011824 	str	w4, [x1, #280]
    65b4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    65b8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    65bc:	a9530261 	ldp	x1, x0, [x19, #304]
    65c0:	b4000741 	cbz	x1, 66a8 <fwp_free_zombie+0x138>
    65c4:	f9009c20 	str	x0, [x1, #312]
    65c8:	b4000040 	cbz	x0, 65d0 <fwp_free_zombie+0x60>
    65cc:	f9009801 	str	x1, [x0, #304]
    65d0:	91018294 	add	x20, x20, #0x60
    65d4:	b9405e60 	ldr	w0, [x19, #92]
    65d8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    65dc:	f9008a9f 	str	xzr, [x20, #272]
    65e0:	34000140 	cbz	w0, 6608 <fwp_free_zombie+0x98>
    65e4:	7100041f 	cmp	w0, #0x1
    65e8:	54000080 	b.eq	65f8 <fwp_free_zombie+0x88>  // b.none
    65ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    65f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65f4:	d65f03c0 	ret
    65f8:	aa1303e0 	mov	x0, x19
    65fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6600:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6604:	17ffff9b 	b	6470 <fwp_task_dispose>
    6608:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc00>
    660c:	91178082 	add	x2, x4, #0x5e0
    6610:	f949d841 	ldr	x1, [x2, #5040]
    6614:	f949ec40 	ldr	x0, [x2, #5080]
    6618:	cb010261 	sub	x1, x19, x1
    661c:	eb00403f 	cmp	x1, x0, lsl #16
    6620:	54fffe62 	b.cs	65ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6624:	d350fc20 	lsr	x0, x1, #16
    6628:	f949fc43 	ldr	x3, [x2, #5112]
    662c:	8b000800 	add	x0, x0, x0, lsl #2
    6630:	d37df000 	lsl	x0, x0, #3
    6634:	8b000062 	add	x2, x3, x0
    6638:	f9401054 	ldr	x20, [x2, #32]
    663c:	b4fffd94 	cbz	x20, 65ec <fwp_free_zombie+0x7c>
    6640:	38606860 	ldrb	w0, [x3, x0]
    6644:	7100081f 	cmp	w0, #0x2
    6648:	54000360 	b.eq	66b4 <fwp_free_zombie+0x144>  // b.none
    664c:	7100041f 	cmp	w0, #0x1
    6650:	54fffce1 	b.ne	65ec <fwp_free_zombie+0x7c>  // b.any
    6654:	29430043 	ldp	w3, w0, [x2, #24]
    6658:	92403c21 	and	x1, x1, #0xffff
    665c:	9b037c21 	mul	x1, x1, x3
    6660:	d360fc21 	lsr	x1, x1, #32
    6664:	eb00003f 	cmp	x1, x0
    6668:	54fffc22 	b.cs	65ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    666c:	8b010294 	add	x20, x20, x1
    6670:	39400280 	ldrb	w0, [x20]
    6674:	34fffbc0 	cbz	w0, 65ec <fwp_free_zombie+0x7c>
    6678:	7100041f 	cmp	w0, #0x1
    667c:	54fffbe0 	b.eq	65f8 <fwp_free_zombie+0x88>  // b.none
    6680:	7103fc1f 	cmp	w0, #0xff
    6684:	540001e0 	b.eq	66c0 <fwp_free_zombie+0x150>  // b.none
    6688:	51000400 	sub	w0, w0, #0x1
    668c:	39000280 	strb	w0, [x20]
    6690:	17ffffd7 	b	65ec <fwp_free_zombie+0x7c>
    6694:	f9400e61 	ldr	x1, [x19, #24]
    6698:	97fff0e6 	bl	2a30 <munmap@plt>
    669c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66a0:	a9530261 	ldp	x1, x0, [x19, #304]
    66a4:	b5fff901 	cbnz	x1, 65c4 <fwp_free_zombie+0x54>
    66a8:	91018282 	add	x2, x20, #0x60
    66ac:	f9019040 	str	x0, [x2, #800]
    66b0:	17ffffc6 	b	65c8 <fwp_free_zombie+0x58>
    66b4:	72003c3f 	tst	w1, #0xffff
    66b8:	54fff9a1 	b.ne	65ec <fwp_free_zombie+0x7c>  // b.any
    66bc:	17ffffed 	b	6670 <fwp_free_zombie+0x100>
    66c0:	ca544680 	eor	x0, x20, x20, lsr #17
    66c4:	91178084 	add	x4, x4, #0x5e0
    66c8:	ca402400 	eor	x0, x0, x0, lsr #9
    66cc:	8b200c80 	add	x0, x4, w0, uxtb #3
    66d0:	f94a2400 	ldr	x0, [x0, #5192]
    66d4:	b5000080 	cbnz	x0, 66e4 <fwp_free_zombie+0x174>
    66d8:	14000010 	b	6718 <fwp_free_zombie+0x1a8>
    66dc:	f9400800 	ldr	x0, [x0, #16]
    66e0:	b40001c0 	cbz	x0, 6718 <fwp_free_zombie+0x1a8>
    66e4:	f9400001 	ldr	x1, [x0]
    66e8:	eb14003f 	cmp	x1, x20
    66ec:	54ffff81 	b.ne	66dc <fwp_free_zombie+0x16c>  // b.any
    66f0:	f9400401 	ldr	x1, [x0, #8]
    66f4:	d1000421 	sub	x1, x1, #0x1
    66f8:	f9000401 	str	x1, [x0, #8]
    66fc:	f103f83f 	cmp	x1, #0xfe
    6700:	54fff761 	b.ne	65ec <fwp_free_zombie+0x7c>  // b.any
    6704:	aa1403e0 	mov	x0, x20
    6708:	97fff86e 	bl	48c0 <fwp_rc_forget_slot>
    670c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6710:	39000280 	strb	w0, [x20]
    6714:	17ffffb6 	b	65ec <fwp_free_zombie+0x7c>
    6718:	f0000000 	adrp	x0, 9000 <__divti3+0x370>
    671c:	911c4000 	add	x0, x0, #0x710
    6720:	97fff458 	bl	3880 <fwp_trap>

0000000000006724 <fwp_block>:
    6724:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6728:	910003fd 	mov	x29, sp
    672c:	a90153f3 	stp	x19, x20, [sp, #16]
    6730:	d00000d3 	adrp	x19, 20000 <__data_start>
    6734:	91018274 	add	x20, x19, #0x60
    6738:	f9404282 	ldr	x2, [x20, #128]
    673c:	b4000622 	cbz	x2, 6800 <fwp_block+0xdc>
    6740:	91018261 	add	x1, x19, #0x60
    6744:	f9408040 	ldr	x0, [x2, #256]
    6748:	f9004020 	str	x0, [x1, #128]
    674c:	b4000680 	cbz	x0, 681c <fwp_block+0xf8>
    6750:	91018263 	add	x3, x19, #0x60
    6754:	3901505f 	strb	wzr, [x2, #84]
    6758:	f9400864 	ldr	x4, [x3, #16]
    675c:	eb02009f 	cmp	x4, x2
    6760:	54000440 	b.eq	67e8 <fwp_block+0xc4>  // b.none
    6764:	f9419465 	ldr	x5, [x3, #808]
    6768:	f9000862 	str	x2, [x3, #16]
    676c:	f9400441 	ldr	x1, [x2, #8]
    6770:	f9004885 	str	x5, [x4, #144]
    6774:	f9419865 	ldr	x5, [x3, #816]
    6778:	f9004c85 	str	x5, [x4, #152]
    677c:	f9419c65 	ldr	x5, [x3, #824]
    6780:	f9005085 	str	x5, [x4, #160]
    6784:	f941a065 	ldr	x5, [x3, #832]
    6788:	f9005485 	str	x5, [x4, #168]
    678c:	f941a465 	ldr	x5, [x3, #840]
    6790:	f9005885 	str	x5, [x4, #176]
    6794:	f941a865 	ldr	x5, [x3, #848]
    6798:	f9005c85 	str	x5, [x4, #184]
    679c:	f941ac65 	ldr	x5, [x3, #856]
    67a0:	f9006085 	str	x5, [x4, #192]
    67a4:	f9400480 	ldr	x0, [x4, #8]
    67a8:	f9404844 	ldr	x4, [x2, #144]
    67ac:	f9019464 	str	x4, [x3, #808]
    67b0:	f9404c44 	ldr	x4, [x2, #152]
    67b4:	f9019864 	str	x4, [x3, #816]
    67b8:	f9405044 	ldr	x4, [x2, #160]
    67bc:	f9019c64 	str	x4, [x3, #824]
    67c0:	f9405444 	ldr	x4, [x2, #168]
    67c4:	f901a064 	str	x4, [x3, #832]
    67c8:	f9405844 	ldr	x4, [x2, #176]
    67cc:	f901a464 	str	x4, [x3, #840]
    67d0:	a94b8844 	ldp	x4, x2, [x2, #184]
    67d4:	f901a864 	str	x4, [x3, #848]
    67d8:	f901ac62 	str	x2, [x3, #856]
    67dc:	97fff065 	bl	2970 <swapcontext@plt>
    67e0:	97ffff64 	bl	6570 <fwp_free_zombie>
    67e4:	d503201f 	nop
    67e8:	91018260 	add	x0, x19, #0x60
    67ec:	b9436000 	ldr	w0, [x0, #864]
    67f0:	340001a0 	cbz	w0, 6824 <fwp_block+0x100>
    67f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    67f8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67fc:	d65f03c0 	ret
    6800:	97fff75c 	bl	4570 <fwp_poll_events>
    6804:	f9404282 	ldr	x2, [x20, #128]
    6808:	b4ffffc2 	cbz	x2, 6800 <fwp_block+0xdc>
    680c:	91018261 	add	x1, x19, #0x60
    6810:	f9408040 	ldr	x0, [x2, #256]
    6814:	f9004020 	str	x0, [x1, #128]
    6818:	b5fff9c0 	cbnz	x0, 6750 <fwp_block+0x2c>
    681c:	f9003c3f 	str	xzr, [x1, #120]
    6820:	17ffffcc 	b	6750 <fwp_block+0x2c>
    6824:	f0000000 	adrp	x0, 9000 <__divti3+0x370>
    6828:	91210000 	add	x0, x0, #0x840
    682c:	97fff09d 	bl	2aa0 <getenv@plt>
    6830:	5284e202 	mov	w2, #0x2710                	// #10000
    6834:	b4000060 	cbz	x0, 6840 <fwp_block+0x11c>
    6838:	39400001 	ldrb	w1, [x0]
    683c:	350000c1 	cbnz	w1, 6854 <fwp_block+0x130>
    6840:	91018273 	add	x19, x19, #0x60
    6844:	b9036262 	str	w2, [x19, #864]
    6848:	a94153f3 	ldp	x19, x20, [sp, #16]
    684c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6850:	d65f03c0 	ret
    6854:	52800142 	mov	w2, #0xa                   	// #10
    6858:	d2800001 	mov	x1, #0x0                   	// #0
    685c:	97ffefe1 	bl	27e0 <strtoll@plt>
    6860:	d1000403 	sub	x3, x0, #0x1
    6864:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6868:	eb02007f 	cmp	x3, x2
    686c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6870:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6874:	17fffff3 	b	6840 <fwp_block+0x11c>
    6878:	d503201f 	nop
    687c:	d503201f 	nop

0000000000006880 <fwp_drop10>:
    6880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6884:	910003fd 	mov	x29, sp
    6888:	a90153f3 	stp	x19, x20, [sp, #16]
    688c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc00>
    6890:	f90013f5 	str	x21, [sp, #32]
    6894:	91178275 	add	x21, x19, #0x5e0
    6898:	f949daa1 	ldr	x1, [x21, #5040]
    689c:	f949eea2 	ldr	x2, [x21, #5080]
    68a0:	cb010001 	sub	x1, x0, x1
    68a4:	eb02403f 	cmp	x1, x2, lsl #16
    68a8:	54000382 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    68ac:	d350fc22 	lsr	x2, x1, #16
    68b0:	f949fea3 	ldr	x3, [x21, #5112]
    68b4:	8b020842 	add	x2, x2, x2, lsl #2
    68b8:	d37df042 	lsl	x2, x2, #3
    68bc:	8b020064 	add	x4, x3, x2
    68c0:	f9401094 	ldr	x20, [x4, #32]
    68c4:	b40002b4 	cbz	x20, 6918 <fwp_drop10+0x98>
    68c8:	38626862 	ldrb	w2, [x3, x2]
    68cc:	7100085f 	cmp	w2, #0x2
    68d0:	540007a0 	b.eq	69c4 <fwp_drop10+0x144>  // b.none
    68d4:	7100045f 	cmp	w2, #0x1
    68d8:	54000201 	b.ne	6918 <fwp_drop10+0x98>  // b.any
    68dc:	29430885 	ldp	w5, w2, [x4, #24]
    68e0:	92403c21 	and	x1, x1, #0xffff
    68e4:	9b057c21 	mul	x1, x1, x5
    68e8:	d360fc21 	lsr	x1, x1, #32
    68ec:	eb02003f 	cmp	x1, x2
    68f0:	54000142 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    68f4:	8b010294 	add	x20, x20, x1
    68f8:	39400281 	ldrb	w1, [x20]
    68fc:	340000e1 	cbz	w1, 6918 <fwp_drop10+0x98>
    6900:	7100043f 	cmp	w1, #0x1
    6904:	54000120 	b.eq	6928 <fwp_drop10+0xa8>  // b.none
    6908:	7103fc3f 	cmp	w1, #0xff
    690c:	540007c0 	b.eq	6a04 <fwp_drop10+0x184>  // b.none
    6910:	51000421 	sub	w1, w1, #0x1
    6914:	39000281 	strb	w1, [x20]
    6918:	a94153f3 	ldp	x19, x20, [sp, #16]
    691c:	f94013f5 	ldr	x21, [sp, #32]
    6920:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6924:	d65f03c0 	ret
    6928:	f9400001 	ldr	x1, [x0]
    692c:	b7f80581 	tbnz	x1, #63, 69dc <fwp_drop10+0x15c>
    6930:	91178273 	add	x19, x19, #0x5e0
    6934:	f949da61 	ldr	x1, [x19, #5040]
    6938:	f949ee62 	ldr	x2, [x19, #5080]
    693c:	cb010001 	sub	x1, x0, x1
    6940:	eb02403f 	cmp	x1, x2, lsl #16
    6944:	54fffea2 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    6948:	d350fc22 	lsr	x2, x1, #16
    694c:	8b020842 	add	x2, x2, x2, lsl #2
    6950:	d37df042 	lsl	x2, x2, #3
    6954:	8b020065 	add	x5, x3, x2
    6958:	f94010a4 	ldr	x4, [x5, #32]
    695c:	b4fffde4 	cbz	x4, 6918 <fwp_drop10+0x98>
    6960:	38626862 	ldrb	w2, [x3, x2]
    6964:	7100085f 	cmp	w2, #0x2
    6968:	54000220 	b.eq	69ac <fwp_drop10+0x12c>  // b.none
    696c:	7100045f 	cmp	w2, #0x1
    6970:	54fffd41 	b.ne	6918 <fwp_drop10+0x98>  // b.any
    6974:	294308a3 	ldp	w3, w2, [x5, #24]
    6978:	92403c21 	and	x1, x1, #0xffff
    697c:	9b037c21 	mul	x1, x1, x3
    6980:	d360fc21 	lsr	x1, x1, #32
    6984:	eb02003f 	cmp	x1, x2
    6988:	54fffc82 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    698c:	8b010084 	add	x4, x4, x1
    6990:	39400081 	ldrb	w1, [x4]
    6994:	7100043f 	cmp	w1, #0x1
    6998:	54fffc01 	b.ne	6918 <fwp_drop10+0x98>  // b.any
    699c:	a94153f3 	ldp	x19, x20, [sp, #16]
    69a0:	f94013f5 	ldr	x21, [sp, #32]
    69a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69a8:	17fff866 	b	4b40 <fwp_mem_free>
    69ac:	72003c3f 	tst	w1, #0xffff
    69b0:	54ffff00 	b.eq	6990 <fwp_drop10+0x110>  // b.none
    69b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    69b8:	f94013f5 	ldr	x21, [sp, #32]
    69bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69c0:	d65f03c0 	ret
    69c4:	72003c3f 	tst	w1, #0xffff
    69c8:	54fff980 	b.eq	68f8 <fwp_drop10+0x78>  // b.none
    69cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    69d0:	f94013f5 	ldr	x21, [sp, #32]
    69d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69d8:	d65f03c0 	ret
    69dc:	f9400414 	ldr	x20, [x0, #8]
    69e0:	97fffb5d 	bl	5754 <fwp_rc_free_arr>
    69e4:	91178260 	add	x0, x19, #0x5e0
    69e8:	f949d801 	ldr	x1, [x0, #5040]
    69ec:	f949ec00 	ldr	x0, [x0, #5080]
    69f0:	cb010281 	sub	x1, x20, x1
    69f4:	eb00403f 	cmp	x1, x0, lsl #16
    69f8:	54fff902 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    69fc:	aa1403e0 	mov	x0, x20
    6a00:	17ffffab 	b	68ac <fwp_drop10+0x2c>
    6a04:	ca544680 	eor	x0, x20, x20, lsr #17
    6a08:	91178273 	add	x19, x19, #0x5e0
    6a0c:	ca402400 	eor	x0, x0, x0, lsr #9
    6a10:	8b200e60 	add	x0, x19, w0, uxtb #3
    6a14:	f94a2400 	ldr	x0, [x0, #5192]
    6a18:	b5000080 	cbnz	x0, 6a28 <fwp_drop10+0x1a8>
    6a1c:	14000010 	b	6a5c <fwp_drop10+0x1dc>
    6a20:	f9400800 	ldr	x0, [x0, #16]
    6a24:	b40001c0 	cbz	x0, 6a5c <fwp_drop10+0x1dc>
    6a28:	f9400001 	ldr	x1, [x0]
    6a2c:	eb14003f 	cmp	x1, x20
    6a30:	54ffff81 	b.ne	6a20 <fwp_drop10+0x1a0>  // b.any
    6a34:	f9400401 	ldr	x1, [x0, #8]
    6a38:	d1000421 	sub	x1, x1, #0x1
    6a3c:	f9000401 	str	x1, [x0, #8]
    6a40:	f103f83f 	cmp	x1, #0xfe
    6a44:	54fff6a1 	b.ne	6918 <fwp_drop10+0x98>  // b.any
    6a48:	aa1403e0 	mov	x0, x20
    6a4c:	97fff79d 	bl	48c0 <fwp_rc_forget_slot>
    6a50:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a54:	39000280 	strb	w0, [x20]
    6a58:	17ffffb0 	b	6918 <fwp_drop10+0x98>
    6a5c:	f0000000 	adrp	x0, 9000 <__divti3+0x370>
    6a60:	911c4000 	add	x0, x0, #0x710
    6a64:	97fff387 	bl	3880 <fwp_trap>
    6a68:	d503201f 	nop
    6a6c:	d503201f 	nop

0000000000006a70 <fwp_caps173>:
    6a70:	34000041 	cbz	w1, 6a78 <fwp_caps173+0x8>
    6a74:	d65f03c0 	ret
    6a78:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc00>
    6a7c:	91178063 	add	x3, x3, #0x5e0
    6a80:	f949d861 	ldr	x1, [x3, #5040]
    6a84:	f949ec62 	ldr	x2, [x3, #5080]
    6a88:	cb010001 	sub	x1, x0, x1
    6a8c:	eb02403f 	cmp	x1, x2, lsl #16
    6a90:	54ffff22 	b.cs	6a74 <fwp_caps173+0x4>  // b.hs, b.nlast
    6a94:	d350fc22 	lsr	x2, x1, #16
    6a98:	f949fc65 	ldr	x5, [x3, #5112]
    6a9c:	8b020842 	add	x2, x2, x2, lsl #2
    6aa0:	d37df042 	lsl	x2, x2, #3
    6aa4:	8b0200a4 	add	x4, x5, x2
    6aa8:	f9401083 	ldr	x3, [x4, #32]
    6aac:	b4fffe43 	cbz	x3, 6a74 <fwp_caps173+0x4>
    6ab0:	386268a2 	ldrb	w2, [x5, x2]
    6ab4:	7100085f 	cmp	w2, #0x2
    6ab8:	540001c0 	b.eq	6af0 <fwp_caps173+0x80>  // b.none
    6abc:	7100045f 	cmp	w2, #0x1
    6ac0:	54fffda1 	b.ne	6a74 <fwp_caps173+0x4>  // b.any
    6ac4:	29430885 	ldp	w5, w2, [x4, #24]
    6ac8:	92403c21 	and	x1, x1, #0xffff
    6acc:	9b057c21 	mul	x1, x1, x5
    6ad0:	d360fc21 	lsr	x1, x1, #32
    6ad4:	eb02003f 	cmp	x1, x2
    6ad8:	54fffce2 	b.cs	6a74 <fwp_caps173+0x4>  // b.hs, b.nlast
    6adc:	8b010063 	add	x3, x3, x1
    6ae0:	39400061 	ldrb	w1, [x3]
    6ae4:	7100043f 	cmp	w1, #0x1
    6ae8:	54fffc61 	b.ne	6a74 <fwp_caps173+0x4>  // b.any
    6aec:	17fff815 	b	4b40 <fwp_mem_free>
    6af0:	72003c3f 	tst	w1, #0xffff
    6af4:	54ffff60 	b.eq	6ae0 <fwp_caps173+0x70>  // b.none
    6af8:	d65f03c0 	ret
    6afc:	d503201f 	nop

0000000000006b00 <f37>:
    6b00:	d101c3ff 	sub	sp, sp, #0x70
    6b04:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6b08:	f947f421 	ldr	x1, [x1, #4072]
    6b0c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6b10:	910083fd 	add	x29, sp, #0x20
    6b14:	a90563f7 	stp	x23, x24, [sp, #80]
    6b18:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc00>
    6b1c:	911782e3 	add	x3, x23, #0x5e0
    6b20:	a90353f3 	stp	x19, x20, [sp, #48]
    6b24:	a9045bf5 	stp	x21, x22, [sp, #64]
    6b28:	aa0003f6 	mov	x22, x0
    6b2c:	a9066bf9 	stp	x25, x26, [sp, #96]
    6b30:	f949ec62 	ldr	x2, [x3, #5080]
    6b34:	f9400024 	ldr	x4, [x1]
    6b38:	f9000fe4 	str	x4, [sp, #24]
    6b3c:	d2800004 	mov	x4, #0x0                   	// #0
    6b40:	f949d861 	ldr	x1, [x3, #5040]
    6b44:	d370bc42 	lsl	x2, x2, #16
    6b48:	b40015c0 	cbz	x0, 6e00 <f37+0x300>
    6b4c:	f9400818 	ldr	x24, [x0, #16]
    6b50:	cb010301 	sub	x1, x24, x1
    6b54:	eb02003f 	cmp	x1, x2
    6b58:	54000362 	b.cs	6bc4 <f37+0xc4>  // b.hs, b.nlast
    6b5c:	f949fc60 	ldr	x0, [x3, #5112]
    6b60:	d350fc22 	lsr	x2, x1, #16
    6b64:	8b020842 	add	x2, x2, x2, lsl #2
    6b68:	8b020c02 	add	x2, x0, x2, lsl #3
    6b6c:	f9401040 	ldr	x0, [x2, #32]
    6b70:	b40002a0 	cbz	x0, 6bc4 <f37+0xc4>
    6b74:	39400043 	ldrb	w3, [x2]
    6b78:	7100087f 	cmp	w3, #0x2
    6b7c:	540013c0 	b.eq	6df4 <f37+0x2f4>  // b.none
    6b80:	7100047f 	cmp	w3, #0x1
    6b84:	540001c1 	b.ne	6bbc <f37+0xbc>  // b.any
    6b88:	29430843 	ldp	w3, w2, [x2, #24]
    6b8c:	92403c21 	and	x1, x1, #0xffff
    6b90:	9b037c21 	mul	x1, x1, x3
    6b94:	d360fc21 	lsr	x1, x1, #32
    6b98:	eb02003f 	cmp	x1, x2
    6b9c:	54000102 	b.cs	6bbc <f37+0xbc>  // b.hs, b.nlast
    6ba0:	8b010000 	add	x0, x0, x1
    6ba4:	39400001 	ldrb	w1, [x0]
    6ba8:	340000a1 	cbz	w1, 6bbc <f37+0xbc>
    6bac:	7103f43f 	cmp	w1, #0xfd
    6bb0:	540016a8 	b.hi	6e84 <f37+0x384>  // b.pmore
    6bb4:	11000421 	add	w1, w1, #0x1
    6bb8:	39000001 	strb	w1, [x0]
    6bbc:	d2800000 	mov	x0, #0x0                   	// #0
    6bc0:	b40000f6 	cbz	x22, 6bdc <f37+0xdc>
    6bc4:	aa1603e1 	mov	x1, x22
    6bc8:	d2800000 	mov	x0, #0x0                   	// #0
    6bcc:	d503201f 	nop
    6bd0:	f9400821 	ldr	x1, [x1, #16]
    6bd4:	91000400 	add	x0, x0, #0x1
    6bd8:	b5ffffc1 	cbnz	x1, 6bd0 <f37+0xd0>
    6bdc:	b40011b8 	cbz	x24, 6e10 <f37+0x310>
    6be0:	aa1803e1 	mov	x1, x24
    6be4:	d2800002 	mov	x2, #0x0                   	// #0
    6be8:	f9400821 	ldr	x1, [x1, #16]
    6bec:	91000442 	add	x2, x2, #0x1
    6bf0:	b5ffffc1 	cbnz	x1, 6be8 <f37+0xe8>
    6bf4:	eb00005f 	cmp	x2, x0
    6bf8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6bfc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6c00:	eb01033f 	cmp	x25, x1
    6c04:	54001468 	b.hi	6e90 <f37+0x390>  // b.pmore
    6c08:	d37ffb33 	lsl	x19, x25, #1
    6c0c:	52800041 	mov	w1, #0x2                   	// #2
    6c10:	91000660 	add	x0, x19, #0x1
    6c14:	d37df000 	lsl	x0, x0, #3
    6c18:	97fff8ea 	bl	4fc0 <fwp_heap_alloc>
    6c1c:	911782e1 	add	x1, x23, #0x5e0
    6c20:	aa0003fa 	mov	x26, x0
    6c24:	f9000013 	str	x19, [x0]
    6c28:	aa0103e0 	mov	x0, x1
    6c2c:	f949d821 	ldr	x1, [x1, #5040]
    6c30:	f949ec00 	ldr	x0, [x0, #5080]
    6c34:	cb010341 	sub	x1, x26, x1
    6c38:	eb00403f 	cmp	x1, x0, lsl #16
    6c3c:	54000342 	b.cs	6ca4 <f37+0x1a4>  // b.hs, b.nlast
    6c40:	911782e2 	add	x2, x23, #0x5e0
    6c44:	d350fc20 	lsr	x0, x1, #16
    6c48:	8b000800 	add	x0, x0, x0, lsl #2
    6c4c:	f949fc43 	ldr	x3, [x2, #5112]
    6c50:	d37df002 	lsl	x2, x0, #3
    6c54:	8b020060 	add	x0, x3, x2
    6c58:	f9401013 	ldr	x19, [x0, #32]
    6c5c:	b4000253 	cbz	x19, 6ca4 <f37+0x1a4>
    6c60:	38626862 	ldrb	w2, [x3, x2]
    6c64:	7100085f 	cmp	w2, #0x2
    6c68:	54000c00 	b.eq	6de8 <f37+0x2e8>  // b.none
    6c6c:	7100045f 	cmp	w2, #0x1
    6c70:	540001a1 	b.ne	6ca4 <f37+0x1a4>  // b.any
    6c74:	29430002 	ldp	w2, w0, [x0, #24]
    6c78:	92403c21 	and	x1, x1, #0xffff
    6c7c:	9b027c21 	mul	x1, x1, x2
    6c80:	d360fc21 	lsr	x1, x1, #32
    6c84:	eb00003f 	cmp	x1, x0
    6c88:	540000e2 	b.cs	6ca4 <f37+0x1a4>  // b.hs, b.nlast
    6c8c:	8b010273 	add	x19, x19, x1
    6c90:	39400260 	ldrb	w0, [x19]
    6c94:	7103fc1f 	cmp	w0, #0xff
    6c98:	54000da0 	b.eq	6e4c <f37+0x34c>  // b.none
    6c9c:	52800020 	mov	w0, #0x1                   	// #1
    6ca0:	39000260 	strb	w0, [x19]
    6ca4:	b4000259 	cbz	x25, 6cec <f37+0x1ec>
    6ca8:	8b191359 	add	x25, x26, x25, lsl #4
    6cac:	aa1a03f3 	mov	x19, x26
    6cb0:	aa1603f5 	mov	x21, x22
    6cb4:	aa1803f4 	mov	x20, x24
    6cb8:	f9400683 	ldr	x3, [x20, #8]
    6cbc:	f94006a2 	ldr	x2, [x21, #8]
    6cc0:	f9400861 	ldr	x1, [x3, #16]
    6cc4:	f9400840 	ldr	x0, [x2, #16]
    6cc8:	fd400461 	ldr	d1, [x3, #8]
    6ccc:	fd400440 	ldr	d0, [x2, #8]
    6cd0:	97fff9fc 	bl	54c0 <w120>
    6cd4:	f9000660 	str	x0, [x19, #8]
    6cd8:	f8010e61 	str	x1, [x19, #16]!
    6cdc:	f9400a94 	ldr	x20, [x20, #16]
    6ce0:	f9400ab5 	ldr	x21, [x21, #16]
    6ce4:	eb13033f 	cmp	x25, x19
    6ce8:	54fffe81 	b.ne	6cb8 <f37+0x1b8>  // b.any
    6cec:	aa1803e0 	mov	x0, x24
    6cf0:	97fffd48 	bl	6210 <fwp_drop4>
    6cf4:	aa1603e0 	mov	x0, x22
    6cf8:	97fffd46 	bl	6210 <fwp_drop4>
    6cfc:	911782f7 	add	x23, x23, #0x5e0
    6d00:	aa1a03e0 	mov	x0, x26
    6d04:	97fffa43 	bl	5610 <w176.constprop.0>
    6d08:	aa0103f3 	mov	x19, x1
    6d0c:	aa0003f4 	mov	x20, x0
    6d10:	aa1a03e0 	mov	x0, x26
    6d14:	97fffedb 	bl	6880 <fwp_drop10>
    6d18:	a900cff4 	stp	x20, x19, [sp, #8]
    6d1c:	910023e1 	add	x1, sp, #0x8
    6d20:	52800000 	mov	w0, #0x0                   	// #0
    6d24:	97fff8ec 	bl	50d4 <fwp_data.part.0.constprop.0>
    6d28:	f949dae1 	ldr	x1, [x23, #5040]
    6d2c:	aa0003f3 	mov	x19, x0
    6d30:	f949eee0 	ldr	x0, [x23, #5080]
    6d34:	cb010261 	sub	x1, x19, x1
    6d38:	eb00403f 	cmp	x1, x0, lsl #16
    6d3c:	54000322 	b.cs	6da0 <f37+0x2a0>  // b.hs, b.nlast
    6d40:	d350fc22 	lsr	x2, x1, #16
    6d44:	f949fee3 	ldr	x3, [x23, #5112]
    6d48:	8b020842 	add	x2, x2, x2, lsl #2
    6d4c:	d37df042 	lsl	x2, x2, #3
    6d50:	8b020060 	add	x0, x3, x2
    6d54:	f9401014 	ldr	x20, [x0, #32]
    6d58:	b4000254 	cbz	x20, 6da0 <f37+0x2a0>
    6d5c:	38626862 	ldrb	w2, [x3, x2]
    6d60:	7100085f 	cmp	w2, #0x2
    6d64:	540003c0 	b.eq	6ddc <f37+0x2dc>  // b.none
    6d68:	7100045f 	cmp	w2, #0x1
    6d6c:	540001a1 	b.ne	6da0 <f37+0x2a0>  // b.any
    6d70:	29430002 	ldp	w2, w0, [x0, #24]
    6d74:	92403c21 	and	x1, x1, #0xffff
    6d78:	9b027c21 	mul	x1, x1, x2
    6d7c:	d360fc21 	lsr	x1, x1, #32
    6d80:	eb00003f 	cmp	x1, x0
    6d84:	540000e2 	b.cs	6da0 <f37+0x2a0>  // b.hs, b.nlast
    6d88:	8b010294 	add	x20, x20, x1
    6d8c:	39400280 	ldrb	w0, [x20]
    6d90:	7103fc1f 	cmp	w0, #0xff
    6d94:	54000620 	b.eq	6e58 <f37+0x358>  // b.none
    6d98:	52800020 	mov	w0, #0x1                   	// #1
    6d9c:	39000280 	strb	w0, [x20]
    6da0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6da4:	f947f400 	ldr	x0, [x0, #4072]
    6da8:	f9400fe2 	ldr	x2, [sp, #24]
    6dac:	f9400001 	ldr	x1, [x0]
    6db0:	eb010042 	subs	x2, x2, x1
    6db4:	d2800001 	mov	x1, #0x0                   	// #0
    6db8:	540006a1 	b.ne	6e8c <f37+0x38c>  // b.any
    6dbc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6dc0:	aa1303e0 	mov	x0, x19
    6dc4:	a94353f3 	ldp	x19, x20, [sp, #48]
    6dc8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6dcc:	a94563f7 	ldp	x23, x24, [sp, #80]
    6dd0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6dd4:	9101c3ff 	add	sp, sp, #0x70
    6dd8:	d65f03c0 	ret
    6ddc:	72003c3f 	tst	w1, #0xffff
    6de0:	54fffe01 	b.ne	6da0 <f37+0x2a0>  // b.any
    6de4:	17ffffea 	b	6d8c <f37+0x28c>
    6de8:	72003c3f 	tst	w1, #0xffff
    6dec:	54fff5c1 	b.ne	6ca4 <f37+0x1a4>  // b.any
    6df0:	17ffffa8 	b	6c90 <f37+0x190>
    6df4:	72003c3f 	tst	w1, #0xffff
    6df8:	54ffee21 	b.ne	6bbc <f37+0xbc>  // b.any
    6dfc:	17ffff6a 	b	6ba4 <f37+0xa4>
    6e00:	cb0103e1 	neg	x1, x1
    6e04:	eb02003f 	cmp	x1, x2
    6e08:	540002e3 	b.cc	6e64 <f37+0x364>  // b.lo, b.ul, b.last
    6e0c:	d503201f 	nop
    6e10:	52800041 	mov	w1, #0x2                   	// #2
    6e14:	d2800100 	mov	x0, #0x8                   	// #8
    6e18:	97fff86a 	bl	4fc0 <fwp_heap_alloc>
    6e1c:	aa0003e1 	mov	x1, x0
    6e20:	911782e0 	add	x0, x23, #0x5e0
    6e24:	aa0103fa 	mov	x26, x1
    6e28:	d2800018 	mov	x24, #0x0                   	// #0
    6e2c:	f900003f 	str	xzr, [x1]
    6e30:	f949d801 	ldr	x1, [x0, #5040]
    6e34:	f949ec00 	ldr	x0, [x0, #5080]
    6e38:	cb010341 	sub	x1, x26, x1
    6e3c:	eb00403f 	cmp	x1, x0, lsl #16
    6e40:	54fff562 	b.cs	6cec <f37+0x1ec>  // b.hs, b.nlast
    6e44:	d2800019 	mov	x25, #0x0                   	// #0
    6e48:	17ffff7e 	b	6c40 <f37+0x140>
    6e4c:	aa1303e0 	mov	x0, x19
    6e50:	97fff69c 	bl	48c0 <fwp_rc_forget_slot>
    6e54:	17ffff92 	b	6c9c <f37+0x19c>
    6e58:	aa1403e0 	mov	x0, x20
    6e5c:	97fff699 	bl	48c0 <fwp_rc_forget_slot>
    6e60:	17ffffce 	b	6d98 <f37+0x298>
    6e64:	f949fc62 	ldr	x2, [x3, #5112]
    6e68:	d350fc20 	lsr	x0, x1, #16
    6e6c:	8b000800 	add	x0, x0, x0, lsl #2
    6e70:	8b000c42 	add	x2, x2, x0, lsl #3
    6e74:	f9401040 	ldr	x0, [x2, #32]
    6e78:	b4fffcc0 	cbz	x0, 6e10 <f37+0x310>
    6e7c:	d2800018 	mov	x24, #0x0                   	// #0
    6e80:	17ffff3d 	b	6b74 <f37+0x74>
    6e84:	97fff648 	bl	47a4 <fwp_rc_wide_dup>
    6e88:	17ffff4d 	b	6bbc <f37+0xbc>
    6e8c:	97ffeea1 	bl	2910 <__stack_chk_fail@plt>
    6e90:	f0000000 	adrp	x0, 9000 <__divti3+0x370>
    6e94:	91214000 	add	x0, x0, #0x850
    6e98:	97fff27a 	bl	3880 <fwp_trap>
    6e9c:	d503201f 	nop

0000000000006ea0 <fwp_owned_entry37>:
    6ea0:	f9400000 	ldr	x0, [x0]
    6ea4:	17ffff17 	b	6b00 <f37>
    6ea8:	d503201f 	nop
    6eac:	d503201f 	nop

0000000000006eb0 <e37>:
    6eb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6eb4:	910003fd 	mov	x29, sp
    6eb8:	f9000bf3 	str	x19, [sp, #16]
    6ebc:	f9400013 	ldr	x19, [x0]
    6ec0:	aa1303e0 	mov	x0, x19
    6ec4:	97fff9ff 	bl	56c0 <fwp_rc_share>
    6ec8:	aa1303e0 	mov	x0, x19
    6ecc:	97ffff0d 	bl	6b00 <f37>
    6ed0:	aa0003f3 	mov	x19, x0
    6ed4:	97fff9fb 	bl	56c0 <fwp_rc_share>
    6ed8:	aa1303e0 	mov	x0, x19
    6edc:	f9400bf3 	ldr	x19, [sp, #16]
    6ee0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ee4:	d65f03c0 	ret
    6ee8:	d503201f 	nop
    6eec:	d503201f 	nop

0000000000006ef0 <fwp_args37>:
    6ef0:	7100003f 	cmp	w1, #0x0
    6ef4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6ef8:	54000041 	b.ne	6f00 <fwp_args37+0x10>  // b.any
    6efc:	d65f03c0 	ret
    6f00:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc00>
    6f04:	91178042 	add	x2, x2, #0x5e0
    6f08:	f9400001 	ldr	x1, [x0]
    6f0c:	f949d843 	ldr	x3, [x2, #5040]
    6f10:	f949ec40 	ldr	x0, [x2, #5080]
    6f14:	cb030021 	sub	x1, x1, x3
    6f18:	eb00403f 	cmp	x1, x0, lsl #16
    6f1c:	54ffff02 	b.cs	6efc <fwp_args37+0xc>  // b.hs, b.nlast
    6f20:	d350fc20 	lsr	x0, x1, #16
    6f24:	f949fc44 	ldr	x4, [x2, #5112]
    6f28:	8b000800 	add	x0, x0, x0, lsl #2
    6f2c:	d37df002 	lsl	x2, x0, #3
    6f30:	8b020083 	add	x3, x4, x2
    6f34:	f9401060 	ldr	x0, [x3, #32]
    6f38:	b4fffe20 	cbz	x0, 6efc <fwp_args37+0xc>
    6f3c:	38626882 	ldrb	w2, [x4, x2]
    6f40:	7100085f 	cmp	w2, #0x2
    6f44:	54000220 	b.eq	6f88 <fwp_args37+0x98>  // b.none
    6f48:	7100045f 	cmp	w2, #0x1
    6f4c:	54fffd81 	b.ne	6efc <fwp_args37+0xc>  // b.any
    6f50:	29430864 	ldp	w4, w2, [x3, #24]
    6f54:	92403c21 	and	x1, x1, #0xffff
    6f58:	9b047c21 	mul	x1, x1, x4
    6f5c:	d360fc21 	lsr	x1, x1, #32
    6f60:	eb02003f 	cmp	x1, x2
    6f64:	54fffcc2 	b.cs	6efc <fwp_args37+0xc>  // b.hs, b.nlast
    6f68:	8b010000 	add	x0, x0, x1
    6f6c:	39400001 	ldrb	w1, [x0]
    6f70:	34fffc61 	cbz	w1, 6efc <fwp_args37+0xc>
    6f74:	7103f43f 	cmp	w1, #0xfd
    6f78:	540000e8 	b.hi	6f94 <fwp_args37+0xa4>  // b.pmore
    6f7c:	11000421 	add	w1, w1, #0x1
    6f80:	39000001 	strb	w1, [x0]
    6f84:	d65f03c0 	ret
    6f88:	72003c3f 	tst	w1, #0xffff
    6f8c:	54ffff00 	b.eq	6f6c <fwp_args37+0x7c>  // b.none
    6f90:	d65f03c0 	ret
    6f94:	17fff604 	b	47a4 <fwp_rc_wide_dup>
    6f98:	d503201f 	nop
    6f9c:	d503201f 	nop

0000000000006fa0 <fwp_caps37>:
    6fa0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6fa4:	910003fd 	mov	x29, sp
    6fa8:	f9000bf3 	str	x19, [sp, #16]
    6fac:	aa0003f3 	mov	x19, x0
    6fb0:	b9400400 	ldr	w0, [x0, #4]
    6fb4:	340004a0 	cbz	w0, 7048 <fwp_caps37+0xa8>
    6fb8:	f9400660 	ldr	x0, [x19, #8]
    6fbc:	350004e1 	cbnz	w1, 7058 <fwp_caps37+0xb8>
    6fc0:	97fffc94 	bl	6210 <fwp_drop4>
    6fc4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc00>
    6fc8:	91178042 	add	x2, x2, #0x5e0
    6fcc:	f949d840 	ldr	x0, [x2, #5040]
    6fd0:	f949ec41 	ldr	x1, [x2, #5080]
    6fd4:	cb000260 	sub	x0, x19, x0
    6fd8:	eb01401f 	cmp	x0, x1, lsl #16
    6fdc:	54000382 	b.cs	704c <fwp_caps37+0xac>  // b.hs, b.nlast
    6fe0:	d350fc01 	lsr	x1, x0, #16
    6fe4:	f949fc44 	ldr	x4, [x2, #5112]
    6fe8:	8b010821 	add	x1, x1, x1, lsl #2
    6fec:	d37df021 	lsl	x1, x1, #3
    6ff0:	8b010083 	add	x3, x4, x1
    6ff4:	f9401062 	ldr	x2, [x3, #32]
    6ff8:	b40002a2 	cbz	x2, 704c <fwp_caps37+0xac>
    6ffc:	38616881 	ldrb	w1, [x4, x1]
    7000:	7100083f 	cmp	w1, #0x2
    7004:	540006c0 	b.eq	70dc <fwp_caps37+0x13c>  // b.none
    7008:	7100043f 	cmp	w1, #0x1
    700c:	54000201 	b.ne	704c <fwp_caps37+0xac>  // b.any
    7010:	29430464 	ldp	w4, w1, [x3, #24]
    7014:	92403c00 	and	x0, x0, #0xffff
    7018:	9b047c00 	mul	x0, x0, x4
    701c:	d360fc00 	lsr	x0, x0, #32
    7020:	eb01001f 	cmp	x0, x1
    7024:	54000142 	b.cs	704c <fwp_caps37+0xac>  // b.hs, b.nlast
    7028:	8b000042 	add	x2, x2, x0
    702c:	39400040 	ldrb	w0, [x2]
    7030:	7100041f 	cmp	w0, #0x1
    7034:	540000c1 	b.ne	704c <fwp_caps37+0xac>  // b.any
    7038:	aa1303e0 	mov	x0, x19
    703c:	f9400bf3 	ldr	x19, [sp, #16]
    7040:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7044:	17fff6bf 	b	4b40 <fwp_mem_free>
    7048:	34fffbe1 	cbz	w1, 6fc4 <fwp_caps37+0x24>
    704c:	f9400bf3 	ldr	x19, [sp, #16]
    7050:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7054:	d65f03c0 	ret
    7058:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc00>
    705c:	91178042 	add	x2, x2, #0x5e0
    7060:	f949d843 	ldr	x3, [x2, #5040]
    7064:	f949ec41 	ldr	x1, [x2, #5080]
    7068:	cb030000 	sub	x0, x0, x3
    706c:	eb01401f 	cmp	x0, x1, lsl #16
    7070:	54fffee2 	b.cs	704c <fwp_caps37+0xac>  // b.hs, b.nlast
    7074:	d350fc01 	lsr	x1, x0, #16
    7078:	f949fc44 	ldr	x4, [x2, #5112]
    707c:	8b010821 	add	x1, x1, x1, lsl #2
    7080:	d37df021 	lsl	x1, x1, #3
    7084:	8b010083 	add	x3, x4, x1
    7088:	f9401062 	ldr	x2, [x3, #32]
    708c:	b4fffe02 	cbz	x2, 704c <fwp_caps37+0xac>
    7090:	38616881 	ldrb	w1, [x4, x1]
    7094:	7100083f 	cmp	w1, #0x2
    7098:	54000280 	b.eq	70e8 <fwp_caps37+0x148>  // b.none
    709c:	7100043f 	cmp	w1, #0x1
    70a0:	54fffd61 	b.ne	704c <fwp_caps37+0xac>  // b.any
    70a4:	92403c01 	and	x1, x0, #0xffff
    70a8:	29430064 	ldp	w4, w0, [x3, #24]
    70ac:	9b047c21 	mul	x1, x1, x4
    70b0:	d360fc21 	lsr	x1, x1, #32
    70b4:	eb00003f 	cmp	x1, x0
    70b8:	54fffca2 	b.cs	704c <fwp_caps37+0xac>  // b.hs, b.nlast
    70bc:	8b010042 	add	x2, x2, x1
    70c0:	39400040 	ldrb	w0, [x2]
    70c4:	34fffc40 	cbz	w0, 704c <fwp_caps37+0xac>
    70c8:	7103f41f 	cmp	w0, #0xfd
    70cc:	54000148 	b.hi	70f4 <fwp_caps37+0x154>  // b.pmore
    70d0:	11000400 	add	w0, w0, #0x1
    70d4:	39000040 	strb	w0, [x2]
    70d8:	17ffffdd 	b	704c <fwp_caps37+0xac>
    70dc:	72003c1f 	tst	w0, #0xffff
    70e0:	54fffb61 	b.ne	704c <fwp_caps37+0xac>  // b.any
    70e4:	17ffffd2 	b	702c <fwp_caps37+0x8c>
    70e8:	72003c1f 	tst	w0, #0xffff
    70ec:	54fffb01 	b.ne	704c <fwp_caps37+0xac>  // b.any
    70f0:	17fffff4 	b	70c0 <fwp_caps37+0x120>
    70f4:	f9400bf3 	ldr	x19, [sp, #16]
    70f8:	aa0203e0 	mov	x0, x2
    70fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7100:	17fff5a9 	b	47a4 <fwp_rc_wide_dup>

0000000000007104 <fwp_write>:
    7104:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7108:	910003fd 	mov	x29, sp
    710c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    7110:	f947f484 	ldr	x4, [x4, #4072]
    7114:	a90153f3 	stp	x19, x20, [sp, #16]
    7118:	d10943ff 	sub	sp, sp, #0x250
    711c:	b9400045 	ldr	w5, [x2]
    7120:	aa0003f4 	mov	x20, x0
    7124:	f9400080 	ldr	x0, [x4]
    7128:	f90127e0 	str	x0, [sp, #584]
    712c:	d2800000 	mov	x0, #0x0                   	// #0
    7130:	710064bf 	cmp	w5, #0x19
    7134:	54000408 	b.hi	71b4 <fwp_write+0xb0>  // b.pmore
    7138:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0xc50>
    713c:	aa0103f3 	mov	x19, x1
    7140:	91018000 	add	x0, x0, #0x60
    7144:	f9013bf5 	str	x21, [sp, #624]
    7148:	f9013ff6 	str	x22, [sp, #632]
    714c:	f90153fb 	str	x27, [sp, #672]
    7150:	f90157fc 	str	x28, [sp, #680]
    7154:	aa0203fc 	mov	x28, x2
    7158:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    715c:	10000061 	adr	x1, 7168 <fwp_write+0x64>
    7160:	8b20a820 	add	x0, x1, w0, sxth #2
    7164:	d61f0000 	br	x0
    7168:	910123e0 	add	x0, sp, #0x48
    716c:	aa1303e5 	mov	x5, x19
    7170:	d0000004 	adrp	x4, 9000 <__divti3+0x370>
    7174:	aa0003f3 	mov	x19, x0
    7178:	91226084 	add	x4, x4, #0x898
    717c:	d2804003 	mov	x3, #0x200                 	// #512
    7180:	aa0303e1 	mov	x1, x3
    7184:	52800042 	mov	w2, #0x2                   	// #2
    7188:	97ffedbe 	bl	2880 <__snprintf_chk@plt>
    718c:	aa1303e0 	mov	x0, x19
    7190:	97ffed84 	bl	27a0 <strlen@plt>
    7194:	aa1303e1 	mov	x1, x19
    7198:	aa0003e2 	mov	x2, x0
    719c:	aa1403e0 	mov	x0, x20
    71a0:	97fff11c 	bl	3610 <buf_put>
    71a4:	f9413bf5 	ldr	x21, [sp, #624]
    71a8:	f9413ff6 	ldr	x22, [sp, #632]
    71ac:	f94153fb 	ldr	x27, [sp, #672]
    71b0:	f94157fc 	ldr	x28, [sp, #680]
    71b4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    71b8:	f947f400 	ldr	x0, [x0, #4072]
    71bc:	f94127e2 	ldr	x2, [sp, #584]
    71c0:	f9400001 	ldr	x1, [x0]
    71c4:	eb010042 	subs	x2, x2, x1
    71c8:	d2800001 	mov	x1, #0x0                   	// #0
    71cc:	540077a1 	b.ne	80c0 <fwp_write+0xfbc>  // b.any
    71d0:	910943ff 	add	sp, sp, #0x250
    71d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    71d8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    71dc:	d65f03c0 	ret
    71e0:	910123e0 	add	x0, sp, #0x48
    71e4:	aa1303e5 	mov	x5, x19
    71e8:	d0000004 	adrp	x4, 9000 <__divti3+0x370>
    71ec:	aa0003f3 	mov	x19, x0
    71f0:	91224084 	add	x4, x4, #0x890
    71f4:	d2804003 	mov	x3, #0x200                 	// #512
    71f8:	17ffffe2 	b	7180 <fwp_write+0x7c>
    71fc:	71004cbf 	cmp	w5, #0x13
    7200:	d0000000 	adrp	x0, 9000 <__divti3+0x370>
    7204:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7208:	91220000 	add	x0, x0, #0x880
    720c:	91222021 	add	x1, x1, #0x888
    7210:	d2800082 	mov	x2, #0x4                   	// #4
    7214:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7218:	aa1403e0 	mov	x0, x20
    721c:	f90143f7 	str	x23, [sp, #640]
    7220:	d2800016 	mov	x22, #0x0                   	// #0
    7224:	f90147f8 	str	x24, [sp, #648]
    7228:	97fff0fa 	bl	3610 <buf_put>
    722c:	f9400260 	ldr	x0, [x19]
    7230:	d0000017 	adrp	x23, 9000 <__divti3+0x370>
    7234:	d2800015 	mov	x21, #0x0                   	// #0
    7238:	912422f7 	add	x23, x23, #0x908
    723c:	b4004780 	cbz	x0, 7b2c <fwp_write+0xa28>
    7240:	b9400380 	ldr	w0, [x28]
    7244:	52800003 	mov	w3, #0x0                   	// #0
    7248:	f9401f82 	ldr	x2, [x28, #56]
    724c:	71004c1f 	cmp	w0, #0x13
    7250:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7254:	aa1403e0 	mov	x0, x20
    7258:	8b010e61 	add	x1, x19, x1, lsl #3
    725c:	f9400421 	ldr	x1, [x1, #8]
    7260:	97ffffa9 	bl	7104 <fwp_write>
    7264:	b9400380 	ldr	w0, [x28]
    7268:	7100481f 	cmp	w0, #0x12
    726c:	54004b20 	b.eq	7bd0 <fwp_write+0xacc>  // b.none
    7270:	f9400260 	ldr	x0, [x19]
    7274:	910006b5 	add	x21, x21, #0x1
    7278:	91000ad6 	add	x22, x22, #0x2
    727c:	eb15001f 	cmp	x0, x21
    7280:	54004569 	b.ls	7b2c <fwp_write+0xa28>  // b.plast
    7284:	aa1703e1 	mov	x1, x23
    7288:	aa1403e0 	mov	x0, x20
    728c:	d2800042 	mov	x2, #0x2                   	// #2
    7290:	97fff0e0 	bl	3610 <buf_put>
    7294:	17ffffeb 	b	7240 <fwp_write+0x13c>
    7298:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    729c:	91230021 	add	x1, x1, #0x8c0
    72a0:	d28000c2 	mov	x2, #0x6                   	// #6
    72a4:	aa1403e0 	mov	x0, x20
    72a8:	91004273 	add	x19, x19, #0x10
    72ac:	97fff0d9 	bl	3610 <buf_put>
    72b0:	aa1303e0 	mov	x0, x19
    72b4:	97ffed3b 	bl	27a0 <strlen@plt>
    72b8:	aa1303e1 	mov	x1, x19
    72bc:	aa0003e2 	mov	x2, x0
    72c0:	aa1403e0 	mov	x0, x20
    72c4:	97fff0d3 	bl	3610 <buf_put>
    72c8:	528007c3 	mov	w3, #0x3e                  	// #62
    72cc:	aa1403e0 	mov	x0, x20
    72d0:	91001fe1 	add	x1, sp, #0x7
    72d4:	d2800022 	mov	x2, #0x1                   	// #1
    72d8:	39001fe3 	strb	w3, [sp, #7]
    72dc:	17ffffb1 	b	71a0 <fwp_write+0x9c>
    72e0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    72e4:	f947f400 	ldr	x0, [x0, #4072]
    72e8:	f94127e2 	ldr	x2, [sp, #584]
    72ec:	f9400001 	ldr	x1, [x0]
    72f0:	eb010042 	subs	x2, x2, x1
    72f4:	d2800001 	mov	x1, #0x0                   	// #0
    72f8:	540034c1 	b.ne	7990 <fwp_write+0x88c>  // b.any
    72fc:	f9413bf5 	ldr	x21, [sp, #624]
    7300:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7304:	f9413ff6 	ldr	x22, [sp, #632]
    7308:	aa1403e0 	mov	x0, x20
    730c:	91228021 	add	x1, x1, #0x8a0
    7310:	d2800142 	mov	x2, #0xa                   	// #10
    7314:	f94153fb 	ldr	x27, [sp, #672]
    7318:	f94157fc 	ldr	x28, [sp, #680]
    731c:	910943ff 	add	sp, sp, #0x250
    7320:	a94153f3 	ldp	x19, x20, [sp, #16]
    7324:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7328:	17fff0ba 	b	3610 <buf_put>
    732c:	f9400456 	ldr	x22, [x2, #8]
    7330:	f90143f7 	str	x23, [sp, #640]
    7334:	f90147f8 	str	x24, [sp, #648]
    7338:	b4005af6 	cbz	x22, 7e94 <fwp_write+0xd90>
    733c:	aa1603e0 	mov	x0, x22
    7340:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7344:	91248021 	add	x1, x1, #0x920
    7348:	97ffed92 	bl	2990 <strcmp@plt>
    734c:	2a0003f5 	mov	w21, w0
    7350:	34005fc0 	cbz	w0, 7f48 <fwp_write+0xe44>
    7354:	aa1603e0 	mov	x0, x22
    7358:	97ffed12 	bl	27a0 <strlen@plt>
    735c:	aa1603e1 	mov	x1, x22
    7360:	aa0003e2 	mov	x2, x0
    7364:	aa1403e0 	mov	x0, x20
    7368:	97fff0aa 	bl	3610 <buf_put>
    736c:	52800403 	mov	w3, #0x20                  	// #32
    7370:	91001ff5 	add	x21, sp, #0x7
    7374:	aa1503e1 	mov	x1, x21
    7378:	aa1403e0 	mov	x0, x20
    737c:	d2800022 	mov	x2, #0x1                   	// #1
    7380:	39001fe3 	strb	w3, [sp, #7]
    7384:	97fff0a3 	bl	3610 <buf_put>
    7388:	52800f63 	mov	w3, #0x7b                  	// #123
    738c:	aa1403e0 	mov	x0, x20
    7390:	aa1503e1 	mov	x1, x21
    7394:	d2800022 	mov	x2, #0x1                   	// #1
    7398:	39001fe3 	strb	w3, [sp, #7]
    739c:	97fff09d 	bl	3610 <buf_put>
    73a0:	b9401380 	ldr	w0, [x28, #16]
    73a4:	52800018 	mov	w24, #0x0                   	// #0
    73a8:	7100001f 	cmp	w0, #0x0
    73ac:	54003a8d 	b.le	7afc <fwp_write+0x9f8>
    73b0:	f9014bf9 	str	x25, [sp, #656]
    73b4:	d0000019 	adrp	x25, 9000 <__divti3+0x370>
    73b8:	91252339 	add	x25, x25, #0x948
    73bc:	f9014ffa 	str	x26, [sp, #664]
    73c0:	d000001a 	adrp	x26, 9000 <__divti3+0x370>
    73c4:	9124235a 	add	x26, x26, #0x908
    73c8:	91002276 	add	x22, x19, #0x8
    73cc:	d2800013 	mov	x19, #0x0                   	// #0
    73d0:	b5003e73 	cbnz	x19, 7b9c <fwp_write+0xa98>
    73d4:	d37df277 	lsl	x23, x19, #3
    73d8:	34003c98 	cbz	w24, 7b68 <fwp_write+0xa64>
    73dc:	f9401382 	ldr	x2, [x28, #32]
    73e0:	aa1403e0 	mov	x0, x20
    73e4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    73e8:	52800003 	mov	w3, #0x0                   	// #0
    73ec:	f8776842 	ldr	x2, [x2, x23]
    73f0:	91000673 	add	x19, x19, #0x1
    73f4:	97ffff44 	bl	7104 <fwp_write>
    73f8:	b9401380 	ldr	w0, [x28, #16]
    73fc:	6b13001f 	cmp	w0, w19
    7400:	54fffe8c 	b.gt	73d0 <fwp_write+0x2cc>
    7404:	f9414bf9 	ldr	x25, [sp, #656]
    7408:	f9414ffa 	ldr	x26, [sp, #664]
    740c:	34003798 	cbz	w24, 7afc <fwp_write+0x9f8>
    7410:	52800523 	mov	w3, #0x29                  	// #41
    7414:	aa1503e1 	mov	x1, x21
    7418:	aa1403e0 	mov	x0, x20
    741c:	d2800022 	mov	x2, #0x1                   	// #1
    7420:	39001fe3 	strb	w3, [sp, #7]
    7424:	97fff07b 	bl	3610 <buf_put>
    7428:	f9413bf5 	ldr	x21, [sp, #624]
    742c:	f9413ff6 	ldr	x22, [sp, #632]
    7430:	f94143f7 	ldr	x23, [sp, #640]
    7434:	f94147f8 	ldr	x24, [sp, #648]
    7438:	f94153fb 	ldr	x27, [sp, #672]
    743c:	f94157fc 	ldr	x28, [sp, #680]
    7440:	17ffff5d 	b	71b4 <fwp_write+0xb0>
    7444:	b9404855 	ldr	w21, [x2, #72]
    7448:	aa1403e0 	mov	x0, x20
    744c:	93407eb6 	sxtw	x22, w21
    7450:	91000ac1 	add	x1, x22, #0x2
    7454:	97fff03c 	bl	3544 <buf_grow>
    7458:	a9400281 	ldp	x1, x0, [x20]
    745c:	528e8603 	mov	w3, #0x7430                	// #29744
    7460:	78206823 	strh	w3, [x1, x0]
    7464:	8b000022 	add	x2, x1, x0
    7468:	710002bf 	cmp	w21, #0x0
    746c:	540036ad 	b.le	7b40 <fwp_write+0xa3c>
    7470:	110006a3 	add	w3, w21, #0x1
    7474:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7478:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    747c:	91000449 	add	x9, x2, #0x1
    7480:	8b23c043 	add	x3, x2, w3, sxtw
    7484:	f28aaac6 	movk	x6, #0x5556
    7488:	f2955568 	movk	x8, #0xaaab
    748c:	1400000d 	b	74c0 <fwp_write+0x3bc>
    7490:	d2800021 	mov	x1, #0x1                   	// #1
    7494:	528005a5 	mov	w5, #0x2d                  	// #45
    7498:	f100001f 	cmp	x0, #0x0
    749c:	9b467e60 	smulh	x0, x19, x6
    74a0:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    74a4:	381ff465 	strb	w5, [x3], #-1
    74a8:	cb040000 	sub	x0, x0, x4
    74ac:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    74b0:	cb020000 	sub	x0, x0, x2
    74b4:	8b010013 	add	x19, x0, x1
    74b8:	eb03013f 	cmp	x9, x3
    74bc:	54003420 	b.eq	7b40 <fwp_write+0xa3c>  // b.none
    74c0:	9b467e60 	smulh	x0, x19, x6
    74c4:	937ffe64 	asr	x4, x19, #63
    74c8:	52800605 	mov	w5, #0x30                  	// #48
    74cc:	cb040000 	sub	x0, x0, x4
    74d0:	8b000400 	add	x0, x0, x0, lsl #1
    74d4:	cb000260 	sub	x0, x19, x0
    74d8:	91000c01 	add	x1, x0, #0x3
    74dc:	9bc87c22 	umulh	x2, x1, x8
    74e0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    74e4:	8b4204e2 	add	x2, x7, x2, lsr #1
    74e8:	eb020021 	subs	x1, x1, x2
    74ec:	54fffd60 	b.eq	7498 <fwp_write+0x394>  // b.none
    74f0:	f100043f 	cmp	x1, #0x1
    74f4:	54fffce1 	b.ne	7490 <fwp_write+0x38c>  // b.any
    74f8:	d2800001 	mov	x1, #0x0                   	// #0
    74fc:	52800565 	mov	w5, #0x2b                  	// #43
    7500:	17ffffe6 	b	7498 <fwp_write+0x394>
    7504:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7508:	f947f400 	ldr	x0, [x0, #4072]
    750c:	f94127e2 	ldr	x2, [sp, #584]
    7510:	f9400001 	ldr	x1, [x0]
    7514:	eb010042 	subs	x2, x2, x1
    7518:	d2800001 	mov	x1, #0x0                   	// #0
    751c:	540023a1 	b.ne	7990 <fwp_write+0x88c>  // b.any
    7520:	f9413bf5 	ldr	x21, [sp, #624]
    7524:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7528:	f9413ff6 	ldr	x22, [sp, #632]
    752c:	aa1403e0 	mov	x0, x20
    7530:	9122c021 	add	x1, x1, #0x8b0
    7534:	d2800102 	mov	x2, #0x8                   	// #8
    7538:	17ffff77 	b	7314 <fwp_write+0x210>
    753c:	aa1403e0 	mov	x0, x20
    7540:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7544:	d28000c2 	mov	x2, #0x6                   	// #6
    7548:	91244021 	add	x1, x1, #0x910
    754c:	97fff031 	bl	3610 <buf_put>
    7550:	d2800015 	mov	x21, #0x0                   	// #0
    7554:	f9400263 	ldr	x3, [x19]
    7558:	f240f87f 	tst	x3, #0x7fffffffffffffff
    755c:	54002c40 	b.eq	7ae4 <fwp_write+0x9e0>  // b.none
    7560:	f9401f82 	ldr	x2, [x28, #56]
    7564:	f90143f7 	str	x23, [sp, #640]
    7568:	f90147f8 	str	x24, [sp, #648]
    756c:	d2800857 	mov	x23, #0x42                  	// #66
    7570:	f9014bf9 	str	x25, [sp, #656]
    7574:	d0000016 	adrp	x22, 9000 <__divti3+0x370>
    7578:	f9014ffa 	str	x26, [sp, #664]
    757c:	912422d6 	add	x22, x22, #0x908
    7580:	d2800038 	mov	x24, #0x1                   	// #1
    7584:	f2a18017 	movk	x23, #0xc00, lsl #16
    7588:	d2809099 	mov	x25, #0x484                 	// #1156
    758c:	b4000482 	cbz	x2, 761c <fwp_write+0x518>
    7590:	b9400040 	ldr	w0, [x2]
    7594:	7100701f 	cmp	w0, #0x1c
    7598:	540042a0 	b.eq	7dec <fwp_write+0xce8>  // b.none
    759c:	71006c1f 	cmp	w0, #0x1b
    75a0:	540003e8 	b.hi	761c <fwp_write+0x518>  // b.pmore
    75a4:	9ac02301 	lsl	x1, x24, x0
    75a8:	ea17003f 	tst	x1, x23
    75ac:	54003681 	b.ne	7c7c <fwp_write+0xb78>  // b.any
    75b0:	ea19003f 	tst	x1, x25
    75b4:	54003501 	b.ne	7c54 <fwp_write+0xb50>  // b.any
    75b8:	d2800424 	mov	x4, #0x21                  	// #33
    75bc:	ea04003f 	tst	x1, x4
    75c0:	540002e0 	b.eq	761c <fwp_write+0x518>  // b.none
    75c4:	b7f849a3 	tbnz	x3, #63, 7ef8 <fwp_write+0xdf4>
    75c8:	91002261 	add	x1, x19, #0x8
    75cc:	8b150021 	add	x1, x1, x21
    75d0:	39400021 	ldrb	w1, [x1]
    75d4:	7100001f 	cmp	w0, #0x0
    75d8:	93401c23 	sxtb	x3, w1
    75dc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    75e0:	aa1403e0 	mov	x0, x20
    75e4:	52800003 	mov	w3, #0x0                   	// #0
    75e8:	97fffec7 	bl	7104 <fwp_write>
    75ec:	910006b5 	add	x21, x21, #0x1
    75f0:	f9400260 	ldr	x0, [x19]
    75f4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    75f8:	eb0002bf 	cmp	x21, x0
    75fc:	540026c2 	b.cs	7ad4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7600:	d2800042 	mov	x2, #0x2                   	// #2
    7604:	aa1603e1 	mov	x1, x22
    7608:	aa1403e0 	mov	x0, x20
    760c:	97fff001 	bl	3610 <buf_put>
    7610:	f9401f82 	ldr	x2, [x28, #56]
    7614:	f9400263 	ldr	x3, [x19]
    7618:	b5fffbc2 	cbnz	x2, 7590 <fwp_write+0x48c>
    761c:	d37df2a0 	lsl	x0, x21, #3
    7620:	b7f83f03 	tbnz	x3, #63, 7e00 <fwp_write+0xcfc>
    7624:	91002261 	add	x1, x19, #0x8
    7628:	8b000020 	add	x0, x1, x0
    762c:	f9400001 	ldr	x1, [x0]
    7630:	17ffffec 	b	75e0 <fwp_write+0x4dc>
    7634:	a9400e62 	ldp	x2, x3, [x19]
    7638:	b7f83ca3 	tbnz	x3, #63, 7dcc <fwp_write+0xcc8>
    763c:	910123f5 	add	x21, sp, #0x48
    7640:	aa1503e0 	mov	x0, x21
    7644:	97ffee17 	bl	2ea0 <fwp_fmt_u128>
    7648:	aa1503e0 	mov	x0, x21
    764c:	97ffec55 	bl	27a0 <strlen@plt>
    7650:	aa1503e1 	mov	x1, x21
    7654:	aa0003e2 	mov	x2, x0
    7658:	17fffed1 	b	719c <fwp_write+0x98>
    765c:	fd015be8 	str	d8, [sp, #688]
    7660:	1e270268 	fmov	s8, w19
    7664:	fd015fe9 	str	d9, [sp, #696]
    7668:	1e282100 	fcmp	s8, s8
    766c:	54004d26 	b.vs	8010 <fwp_write+0xf0c>
    7670:	1e20c101 	fabs	s1, s8
    7674:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7678:	1e270000 	fmov	s0, w0
    767c:	1e202020 	fcmp	s1, s0
    7680:	54002c0d 	b.le	7c00 <fwp_write+0xafc>
    7684:	1e202118 	fcmpe	s8, #0.0
    7688:	d0000002 	adrp	x2, 9000 <__divti3+0x370>
    768c:	91122042 	add	x2, x2, #0x488
    7690:	910123f5 	add	x21, sp, #0x48
    7694:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7698:	91218021 	add	x1, x1, #0x860
    769c:	aa1503e0 	mov	x0, x21
    76a0:	9a81c041 	csel	x1, x2, x1, gt
    76a4:	97ffeceb 	bl	2a50 <strcpy@plt>
    76a8:	aa1503e0 	mov	x0, x21
    76ac:	97ffec3d 	bl	27a0 <strlen@plt>
    76b0:	aa1503e1 	mov	x1, x21
    76b4:	aa0003e2 	mov	x2, x0
    76b8:	aa1403e0 	mov	x0, x20
    76bc:	97ffefd5 	bl	3610 <buf_put>
    76c0:	f9413bf5 	ldr	x21, [sp, #624]
    76c4:	f9413ff6 	ldr	x22, [sp, #632]
    76c8:	f94153fb 	ldr	x27, [sp, #672]
    76cc:	f94157fc 	ldr	x28, [sp, #680]
    76d0:	fd415be8 	ldr	d8, [sp, #688]
    76d4:	fd415fe9 	ldr	d9, [sp, #696]
    76d8:	17fffeb7 	b	71b4 <fwp_write+0xb0>
    76dc:	f9400276 	ldr	x22, [x19]
    76e0:	34002e03 	cbz	w3, 7ca0 <fwp_write+0xb9c>
    76e4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    76e8:	f947f400 	ldr	x0, [x0, #4072]
    76ec:	f94127e2 	ldr	x2, [sp, #584]
    76f0:	f9400001 	ldr	x1, [x0]
    76f4:	eb010042 	subs	x2, x2, x1
    76f8:	d2800001 	mov	x1, #0x0                   	// #0
    76fc:	540014a1 	b.ne	7990 <fwp_write+0x88c>  // b.any
    7700:	aa1603e2 	mov	x2, x22
    7704:	91002261 	add	x1, x19, #0x8
    7708:	f9413bf5 	ldr	x21, [sp, #624]
    770c:	aa1403e0 	mov	x0, x20
    7710:	f9413ff6 	ldr	x22, [sp, #632]
    7714:	17ffff00 	b	7314 <fwp_write+0x210>
    7718:	fd015be8 	str	d8, [sp, #688]
    771c:	9e670268 	fmov	d8, x19
    7720:	fd015fe9 	str	d9, [sp, #696]
    7724:	1e682100 	fcmp	d8, d8
    7728:	54004746 	b.vs	8010 <fwp_write+0xf0c>
    772c:	1e60c101 	fabs	d1, d8
    7730:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7734:	9e670000 	fmov	d0, x0
    7738:	910123f5 	add	x21, sp, #0x48
    773c:	52800033 	mov	w19, #0x1                   	// #1
    7740:	1e602020 	fcmp	d1, d0
    7744:	540001ad 	b.le	7778 <fwp_write+0x674>
    7748:	1e602118 	fcmpe	d8, #0.0
    774c:	d0000002 	adrp	x2, 9000 <__divti3+0x370>
    7750:	91122042 	add	x2, x2, #0x488
    7754:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7758:	91218021 	add	x1, x1, #0x860
    775c:	aa1503e0 	mov	x0, x21
    7760:	9a81c041 	csel	x1, x2, x1, gt
    7764:	97ffecbb 	bl	2a50 <strcpy@plt>
    7768:	17ffffd0 	b	76a8 <fwp_write+0x5a4>
    776c:	11000673 	add	w19, w19, #0x1
    7770:	71004a7f 	cmp	w19, #0x12
    7774:	54003860 	b.eq	7e80 <fwp_write+0xd7c>  // b.none
    7778:	1e604100 	fmov	d0, d8
    777c:	2a1303e1 	mov	w1, w19
    7780:	aa1503e0 	mov	x0, x21
    7784:	97fff124 	bl	3c14 <fwp_format_g.constprop.0>
    7788:	aa1503e0 	mov	x0, x21
    778c:	d2800001 	mov	x1, #0x0                   	// #0
    7790:	97ffec18 	bl	27f0 <strtod@plt>
    7794:	1e602100 	fcmp	d8, d0
    7798:	54fffea1 	b.ne	776c <fwp_write+0x668>  // b.any
    779c:	aa1503e0 	mov	x0, x21
    77a0:	97fff015 	bl	37f4 <fwp_finish_float>
    77a4:	17ffffc1 	b	76a8 <fwp_write+0x5a4>
    77a8:	a9400e62 	ldp	x2, x3, [x19]
    77ac:	910123f3 	add	x19, sp, #0x48
    77b0:	aa1303e0 	mov	x0, x19
    77b4:	97ffedbb 	bl	2ea0 <fwp_fmt_u128>
    77b8:	17fffe75 	b	718c <fwp_write+0x88>
    77bc:	f90143f7 	str	x23, [sp, #640]
    77c0:	f90147f8 	str	x24, [sp, #648]
    77c4:	2a1303f8 	mov	w24, w19
    77c8:	f9014bf9 	str	x25, [sp, #656]
    77cc:	f9014ffa 	str	x26, [sp, #664]
    77d0:	f13ffe7f 	cmp	x19, #0xfff
    77d4:	54000049 	b.ls	77dc <fwp_write+0x6d8>  // b.plast
    77d8:	b9400278 	ldr	w24, [x19]
    77dc:	f9400f80 	ldr	x0, [x28, #24]
    77e0:	2a1803f5 	mov	w21, w24
    77e4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    77e8:	d37ef6b9 	lsl	x25, x21, #2
    77ec:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    77f0:	aa1603e0 	mov	x0, x22
    77f4:	97ffebeb 	bl	27a0 <strlen@plt>
    77f8:	aa1603e1 	mov	x1, x22
    77fc:	aa0003e2 	mov	x2, x0
    7800:	aa1403e0 	mov	x0, x20
    7804:	97ffef83 	bl	3610 <buf_put>
    7808:	f9401780 	ldr	x0, [x28, #40]
    780c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7810:	7100001f 	cmp	w0, #0x0
    7814:	5400068d 	b.le	78e4 <fwp_write+0x7e0>
    7818:	91002276 	add	x22, x19, #0x8
    781c:	91001ff5 	add	x21, sp, #0x7
    7820:	d280001b 	mov	x27, #0x0                   	// #0
    7824:	5280041a 	mov	w26, #0x20                  	// #32
    7828:	f9401b80 	ldr	x0, [x28, #48]
    782c:	aa1503e1 	mov	x1, x21
    7830:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7834:	d2800022 	mov	x2, #0x1                   	// #1
    7838:	f8786803 	ldr	x3, [x0, x24]
    783c:	aa1403e0 	mov	x0, x20
    7840:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7844:	39001ffa 	strb	w26, [sp, #7]
    7848:	97ffef72 	bl	3610 <buf_put>
    784c:	f13ffeff 	cmp	x23, #0xfff
    7850:	b9400261 	ldr	w1, [x19]
    7854:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7858:	7100383f 	cmp	w1, #0xe
    785c:	54000160 	b.eq	7888 <fwp_write+0x784>  // b.none
    7860:	7100403f 	cmp	w1, #0x10
    7864:	54001a60 	b.eq	7bb0 <fwp_write+0xaac>  // b.none
    7868:	7100283f 	cmp	w1, #0xa
    786c:	54002aa0 	b.eq	7dc0 <fwp_write+0xcbc>  // b.none
    7870:	540014ac 	b.gt	7b04 <fwp_write+0xa00>
    7874:	71000c3f 	cmp	w1, #0x3
    7878:	540029ac 	b.gt	7dac <fwp_write+0xca8>
    787c:	d37ffee0 	lsr	x0, x23, #63
    7880:	37f814a1 	tbnz	w1, #31, 7b14 <fwp_write+0xa10>
    7884:	d503201f 	nop
    7888:	34001460 	cbz	w0, 7b14 <fwp_write+0xa10>
    788c:	52800503 	mov	w3, #0x28                  	// #40
    7890:	aa1503e1 	mov	x1, x21
    7894:	aa1403e0 	mov	x0, x20
    7898:	d2800022 	mov	x2, #0x1                   	// #1
    789c:	39001fe3 	strb	w3, [sp, #7]
    78a0:	97ffef5c 	bl	3610 <buf_put>
    78a4:	aa1303e2 	mov	x2, x19
    78a8:	aa1703e1 	mov	x1, x23
    78ac:	aa1403e0 	mov	x0, x20
    78b0:	52800003 	mov	w3, #0x0                   	// #0
    78b4:	97fffe14 	bl	7104 <fwp_write>
    78b8:	52800523 	mov	w3, #0x29                  	// #41
    78bc:	aa1503e1 	mov	x1, x21
    78c0:	aa1403e0 	mov	x0, x20
    78c4:	d2800022 	mov	x2, #0x1                   	// #1
    78c8:	39001fe3 	strb	w3, [sp, #7]
    78cc:	97ffef51 	bl	3610 <buf_put>
    78d0:	f9401780 	ldr	x0, [x28, #40]
    78d4:	9100077b 	add	x27, x27, #0x1
    78d8:	b8796800 	ldr	w0, [x0, x25]
    78dc:	6b1b001f 	cmp	w0, w27
    78e0:	54fffa4c 	b.gt	7828 <fwp_write+0x724>
    78e4:	f9413bf5 	ldr	x21, [sp, #624]
    78e8:	f9413ff6 	ldr	x22, [sp, #632]
    78ec:	f94143f7 	ldr	x23, [sp, #640]
    78f0:	f94147f8 	ldr	x24, [sp, #648]
    78f4:	f9414bf9 	ldr	x25, [sp, #656]
    78f8:	f9414ffa 	ldr	x26, [sp, #664]
    78fc:	f94153fb 	ldr	x27, [sp, #672]
    7900:	f94157fc 	ldr	x28, [sp, #680]
    7904:	17fffe2c 	b	71b4 <fwp_write+0xb0>
    7908:	52800783 	mov	w3, #0x3c                  	// #60
    790c:	91001ff3 	add	x19, sp, #0x7
    7910:	aa1303e1 	mov	x1, x19
    7914:	d2800022 	mov	x2, #0x1                   	// #1
    7918:	aa1403e0 	mov	x0, x20
    791c:	39001fe3 	strb	w3, [sp, #7]
    7920:	97ffef3c 	bl	3610 <buf_put>
    7924:	f9400795 	ldr	x21, [x28, #8]
    7928:	aa1503e0 	mov	x0, x21
    792c:	97ffeb9d 	bl	27a0 <strlen@plt>
    7930:	aa1503e1 	mov	x1, x21
    7934:	aa0003e2 	mov	x2, x0
    7938:	aa1403e0 	mov	x0, x20
    793c:	97ffef35 	bl	3610 <buf_put>
    7940:	528007c3 	mov	w3, #0x3e                  	// #62
    7944:	aa1303e1 	mov	x1, x19
    7948:	aa1403e0 	mov	x0, x20
    794c:	d2800022 	mov	x2, #0x1                   	// #1
    7950:	39001fe3 	strb	w3, [sp, #7]
    7954:	17fffe13 	b	71a0 <fwp_write+0x9c>
    7958:	f100067f 	cmp	x19, #0x1
    795c:	540025a0 	b.eq	7e10 <fwp_write+0xd0c>  // b.none
    7960:	b100067f 	cmn	x19, #0x1
    7964:	54002bc0 	b.eq	7edc <fwp_write+0xdd8>  // b.none
    7968:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    796c:	9121a021 	add	x1, x1, #0x868
    7970:	d2800022 	mov	x2, #0x1                   	// #1
    7974:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7978:	f947f400 	ldr	x0, [x0, #4072]
    797c:	f94127e4 	ldr	x4, [sp, #584]
    7980:	f9400003 	ldr	x3, [x0]
    7984:	eb030084 	subs	x4, x4, x3
    7988:	d2800003 	mov	x3, #0x0                   	// #0
    798c:	54ffebe0 	b.eq	7708 <fwp_write+0x604>  // b.none
    7990:	f90143f7 	str	x23, [sp, #640]
    7994:	f90147f8 	str	x24, [sp, #648]
    7998:	f9014bf9 	str	x25, [sp, #656]
    799c:	f9014ffa 	str	x26, [sp, #664]
    79a0:	fd015be8 	str	d8, [sp, #688]
    79a4:	fd015fe9 	str	d9, [sp, #696]
    79a8:	97ffebda 	bl	2910 <__stack_chk_fail@plt>
    79ac:	52800b63 	mov	w3, #0x5b                  	// #91
    79b0:	91001ff5 	add	x21, sp, #0x7
    79b4:	aa1503e1 	mov	x1, x21
    79b8:	aa1403e0 	mov	x0, x20
    79bc:	d2800022 	mov	x2, #0x1                   	// #1
    79c0:	d0000016 	adrp	x22, 9000 <__divti3+0x370>
    79c4:	912422d6 	add	x22, x22, #0x908
    79c8:	39001fe3 	strb	w3, [sp, #7]
    79cc:	97ffef11 	bl	3610 <buf_put>
    79d0:	b4000273 	cbz	x19, 7a1c <fwp_write+0x918>
    79d4:	f9400661 	ldr	x1, [x19, #8]
    79d8:	aa1403e0 	mov	x0, x20
    79dc:	f9401f82 	ldr	x2, [x28, #56]
    79e0:	52800003 	mov	w3, #0x0                   	// #0
    79e4:	97fffdc8 	bl	7104 <fwp_write>
    79e8:	f9400a73 	ldr	x19, [x19, #16]
    79ec:	b4000193 	cbz	x19, 7a1c <fwp_write+0x918>
    79f0:	aa1603e1 	mov	x1, x22
    79f4:	aa1403e0 	mov	x0, x20
    79f8:	d2800042 	mov	x2, #0x2                   	// #2
    79fc:	97ffef05 	bl	3610 <buf_put>
    7a00:	f9400661 	ldr	x1, [x19, #8]
    7a04:	aa1403e0 	mov	x0, x20
    7a08:	f9401f82 	ldr	x2, [x28, #56]
    7a0c:	52800003 	mov	w3, #0x0                   	// #0
    7a10:	97fffdbd 	bl	7104 <fwp_write>
    7a14:	f9400a73 	ldr	x19, [x19, #16]
    7a18:	b5fffed3 	cbnz	x19, 79f0 <fwp_write+0x8ec>
    7a1c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7a20:	aa1503e1 	mov	x1, x21
    7a24:	aa1403e0 	mov	x0, x20
    7a28:	d2800022 	mov	x2, #0x1                   	// #1
    7a2c:	39001fe3 	strb	w3, [sp, #7]
    7a30:	17fffddc 	b	71a0 <fwp_write+0x9c>
    7a34:	aa1403e0 	mov	x0, x20
    7a38:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7a3c:	d28000c2 	mov	x2, #0x6                   	// #6
    7a40:	9123e021 	add	x1, x1, #0x8f8
    7a44:	97ffeef3 	bl	3610 <buf_put>
    7a48:	f9400260 	ldr	x0, [x19]
    7a4c:	b40004c0 	cbz	x0, 7ae4 <fwp_write+0x9e0>
    7a50:	910123f5 	add	x21, sp, #0x48
    7a54:	91002276 	add	x22, x19, #0x8
    7a58:	f90143f7 	str	x23, [sp, #640]
    7a5c:	d2800017 	mov	x23, #0x0                   	// #0
    7a60:	f90147f8 	str	x24, [sp, #648]
    7a64:	d0000018 	adrp	x24, 9000 <__divti3+0x370>
    7a68:	91240318 	add	x24, x24, #0x900
    7a6c:	f9014bf9 	str	x25, [sp, #656]
    7a70:	d0000019 	adrp	x25, 9000 <__divti3+0x370>
    7a74:	91242339 	add	x25, x25, #0x908
    7a78:	f9014ffa 	str	x26, [sp, #664]
    7a7c:	14000005 	b	7a90 <fwp_write+0x98c>
    7a80:	aa1903e1 	mov	x1, x25
    7a84:	aa1403e0 	mov	x0, x20
    7a88:	d2800042 	mov	x2, #0x2                   	// #2
    7a8c:	97ffeee1 	bl	3610 <buf_put>
    7a90:	38776ac5 	ldrb	w5, [x22, x23]
    7a94:	d2804003 	mov	x3, #0x200                 	// #512
    7a98:	aa1803e4 	mov	x4, x24
    7a9c:	aa0303e1 	mov	x1, x3
    7aa0:	52800042 	mov	w2, #0x2                   	// #2
    7aa4:	aa1503e0 	mov	x0, x21
    7aa8:	910006f7 	add	x23, x23, #0x1
    7aac:	97ffeb75 	bl	2880 <__snprintf_chk@plt>
    7ab0:	aa1503e0 	mov	x0, x21
    7ab4:	97ffeb3b 	bl	27a0 <strlen@plt>
    7ab8:	aa1503e1 	mov	x1, x21
    7abc:	aa0003e2 	mov	x2, x0
    7ac0:	aa1403e0 	mov	x0, x20
    7ac4:	97ffeed3 	bl	3610 <buf_put>
    7ac8:	f9400260 	ldr	x0, [x19]
    7acc:	eb17001f 	cmp	x0, x23
    7ad0:	54fffd88 	b.hi	7a80 <fwp_write+0x97c>  // b.pmore
    7ad4:	f94143f7 	ldr	x23, [sp, #640]
    7ad8:	f94147f8 	ldr	x24, [sp, #648]
    7adc:	f9414bf9 	ldr	x25, [sp, #656]
    7ae0:	f9414ffa 	ldr	x26, [sp, #664]
    7ae4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ae8:	aa1403e0 	mov	x0, x20
    7aec:	91001fe1 	add	x1, sp, #0x7
    7af0:	d2800022 	mov	x2, #0x1                   	// #1
    7af4:	39001fe3 	strb	w3, [sp, #7]
    7af8:	17fffdaa 	b	71a0 <fwp_write+0x9c>
    7afc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7b00:	17fffe45 	b	7414 <fwp_write+0x310>
    7b04:	f10002ff 	cmp	x23, #0x0
    7b08:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7b0c:	71002c3f 	cmp	w1, #0xb
    7b10:	54ffebc0 	b.eq	7888 <fwp_write+0x784>  // b.none
    7b14:	aa1303e2 	mov	x2, x19
    7b18:	aa1703e1 	mov	x1, x23
    7b1c:	aa1403e0 	mov	x0, x20
    7b20:	52800003 	mov	w3, #0x0                   	// #0
    7b24:	97fffd78 	bl	7104 <fwp_write>
    7b28:	17ffff6a 	b	78d0 <fwp_write+0x7cc>
    7b2c:	aa1403e0 	mov	x0, x20
    7b30:	91001fe1 	add	x1, sp, #0x7
    7b34:	52800fa3 	mov	w3, #0x7d                  	// #125
    7b38:	d2800022 	mov	x2, #0x1                   	// #1
    7b3c:	17fffe39 	b	7420 <fwp_write+0x31c>
    7b40:	a9400281 	ldp	x1, x0, [x20]
    7b44:	91000800 	add	x0, x0, #0x2
    7b48:	8b160000 	add	x0, x0, x22
    7b4c:	f9000680 	str	x0, [x20, #8]
    7b50:	3820683f 	strb	wzr, [x1, x0]
    7b54:	f9413bf5 	ldr	x21, [sp, #624]
    7b58:	f9413ff6 	ldr	x22, [sp, #632]
    7b5c:	f94153fb 	ldr	x27, [sp, #672]
    7b60:	f94157fc 	ldr	x28, [sp, #680]
    7b64:	17fffd94 	b	71b4 <fwp_write+0xb0>
    7b68:	f9400f80 	ldr	x0, [x28, #24]
    7b6c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7b70:	aa1b03e0 	mov	x0, x27
    7b74:	97ffeb0b 	bl	27a0 <strlen@plt>
    7b78:	aa1b03e1 	mov	x1, x27
    7b7c:	aa0003e2 	mov	x2, x0
    7b80:	aa1403e0 	mov	x0, x20
    7b84:	97ffeea3 	bl	3610 <buf_put>
    7b88:	aa1903e1 	mov	x1, x25
    7b8c:	aa1403e0 	mov	x0, x20
    7b90:	d2800062 	mov	x2, #0x3                   	// #3
    7b94:	97ffee9f 	bl	3610 <buf_put>
    7b98:	17fffe11 	b	73dc <fwp_write+0x2d8>
    7b9c:	aa1a03e1 	mov	x1, x26
    7ba0:	aa1403e0 	mov	x0, x20
    7ba4:	d2800042 	mov	x2, #0x2                   	// #2
    7ba8:	97ffee9a 	bl	3610 <buf_put>
    7bac:	17fffe0a 	b	73d4 <fwp_write+0x2d0>
    7bb0:	f9400660 	ldr	x0, [x19, #8]
    7bb4:	b4fffb00 	cbz	x0, 7b14 <fwp_write+0xa10>
    7bb8:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7bbc:	91248021 	add	x1, x1, #0x920
    7bc0:	97ffeb74 	bl	2990 <strcmp@plt>
    7bc4:	7100001f 	cmp	w0, #0x0
    7bc8:	1a9f07e0 	cset	w0, ne	// ne = any
    7bcc:	17ffff2f 	b	7888 <fwp_write+0x784>
    7bd0:	aa1403e0 	mov	x0, x20
    7bd4:	d2800042 	mov	x2, #0x2                   	// #2
    7bd8:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7bdc:	91246021 	add	x1, x1, #0x918
    7be0:	97ffee8c 	bl	3610 <buf_put>
    7be4:	91004261 	add	x1, x19, #0x10
    7be8:	aa1403e0 	mov	x0, x20
    7bec:	f9402382 	ldr	x2, [x28, #64]
    7bf0:	52800003 	mov	w3, #0x0                   	// #0
    7bf4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7bf8:	97fffd43 	bl	7104 <fwp_write>
    7bfc:	17fffd9d 	b	7270 <fwp_write+0x16c>
    7c00:	1e22c109 	fcvt	d9, s8
    7c04:	910123f5 	add	x21, sp, #0x48
    7c08:	52800033 	mov	w19, #0x1                   	// #1
    7c0c:	d503201f 	nop
    7c10:	1e604120 	fmov	d0, d9
    7c14:	2a1303e1 	mov	w1, w19
    7c18:	aa1503e0 	mov	x0, x21
    7c1c:	97ffeffe 	bl	3c14 <fwp_format_g.constprop.0>
    7c20:	aa1503e0 	mov	x0, x21
    7c24:	d2800001 	mov	x1, #0x0                   	// #0
    7c28:	97ffeb66 	bl	29c0 <strtof@plt>
    7c2c:	1e202100 	fcmp	s8, s0
    7c30:	54ffdb60 	b.eq	779c <fwp_write+0x698>  // b.none
    7c34:	11000673 	add	w19, w19, #0x1
    7c38:	71002a7f 	cmp	w19, #0xa
    7c3c:	54fffea1 	b.ne	7c10 <fwp_write+0xb0c>  // b.any
    7c40:	1e604120 	fmov	d0, d9
    7c44:	aa1503e0 	mov	x0, x21
    7c48:	52800121 	mov	w1, #0x9                   	// #9
    7c4c:	97ffeff2 	bl	3c14 <fwp_format_g.constprop.0>
    7c50:	17fffed3 	b	779c <fwp_write+0x698>
    7c54:	d37ef6a1 	lsl	x1, x21, #2
    7c58:	b7f81563 	tbnz	x3, #63, 7f04 <fwp_write+0xe00>
    7c5c:	91002263 	add	x3, x19, #0x8
    7c60:	8b010061 	add	x1, x3, x1
    7c64:	b9400023 	ldr	w3, [x1]
    7c68:	7100081f 	cmp	w0, #0x2
    7c6c:	2a0303e1 	mov	w1, w3
    7c70:	93407c63 	sxtw	x3, w3
    7c74:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7c78:	17fffe5a 	b	75e0 <fwp_write+0x4dc>
    7c7c:	d37ffaa1 	lsl	x1, x21, #1
    7c80:	b7f81363 	tbnz	x3, #63, 7eec <fwp_write+0xde8>
    7c84:	91002263 	add	x3, x19, #0x8
    7c88:	8b010061 	add	x1, x3, x1
    7c8c:	79400021 	ldrh	w1, [x1]
    7c90:	7100041f 	cmp	w0, #0x1
    7c94:	93403c23 	sxth	x3, w1
    7c98:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7c9c:	17fffe51 	b	75e0 <fwp_write+0x4dc>
    7ca0:	52800443 	mov	w3, #0x22                  	// #34
    7ca4:	91001ff5 	add	x21, sp, #0x7
    7ca8:	91002273 	add	x19, x19, #0x8
    7cac:	aa1503e1 	mov	x1, x21
    7cb0:	aa1403e0 	mov	x0, x20
    7cb4:	d2800022 	mov	x2, #0x1                   	// #1
    7cb8:	39001fe3 	strb	w3, [sp, #7]
    7cbc:	f90143f7 	str	x23, [sp, #640]
    7cc0:	8b160277 	add	x23, x19, x22
    7cc4:	f90147f8 	str	x24, [sp, #648]
    7cc8:	97ffee52 	bl	3610 <buf_put>
    7ccc:	b4000696 	cbz	x22, 7d9c <fwp_write+0xc98>
    7cd0:	d0000018 	adrp	x24, 9000 <__divti3+0x370>
    7cd4:	91232318 	add	x24, x24, #0x8c8
    7cd8:	f9014bf9 	str	x25, [sp, #656]
    7cdc:	d0000019 	adrp	x25, 9000 <__divti3+0x370>
    7ce0:	9123a339 	add	x25, x25, #0x8e8
    7ce4:	f9014ffa 	str	x26, [sp, #664]
    7ce8:	1400000d 	b	7d1c <fwp_write+0xc18>
    7cec:	710024bf 	cmp	w5, #0x9
    7cf0:	54000460 	b.eq	7d7c <fwp_write+0xc78>  // b.none
    7cf4:	710028bf 	cmp	w5, #0xa
    7cf8:	54000a61 	b.ne	7e44 <fwp_write+0xd40>  // b.any
    7cfc:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7d00:	aa1403e0 	mov	x0, x20
    7d04:	91236021 	add	x1, x1, #0x8d8
    7d08:	d2800042 	mov	x2, #0x2                   	// #2
    7d0c:	97ffee41 	bl	3610 <buf_put>
    7d10:	91000673 	add	x19, x19, #0x1
    7d14:	eb17027f 	cmp	x19, x23
    7d18:	540003e0 	b.eq	7d94 <fwp_write+0xc90>  // b.none
    7d1c:	39400265 	ldrb	w5, [x19]
    7d20:	710034bf 	cmp	w5, #0xd
    7d24:	54000180 	b.eq	7d54 <fwp_write+0xc50>  // b.none
    7d28:	54fffe29 	b.ls	7cec <fwp_write+0xbe8>  // b.plast
    7d2c:	710088bf 	cmp	w5, #0x22
    7d30:	540001c0 	b.eq	7d68 <fwp_write+0xc64>  // b.none
    7d34:	710170bf 	cmp	w5, #0x5c
    7d38:	54000741 	b.ne	7e20 <fwp_write+0xd1c>  // b.any
    7d3c:	aa1403e0 	mov	x0, x20
    7d40:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7d44:	d2800042 	mov	x2, #0x2                   	// #2
    7d48:	91234021 	add	x1, x1, #0x8d0
    7d4c:	97ffee31 	bl	3610 <buf_put>
    7d50:	17fffff0 	b	7d10 <fwp_write+0xc0c>
    7d54:	aa1903e1 	mov	x1, x25
    7d58:	aa1403e0 	mov	x0, x20
    7d5c:	d2800042 	mov	x2, #0x2                   	// #2
    7d60:	97ffee2c 	bl	3610 <buf_put>
    7d64:	17ffffeb 	b	7d10 <fwp_write+0xc0c>
    7d68:	aa1803e1 	mov	x1, x24
    7d6c:	aa1403e0 	mov	x0, x20
    7d70:	d2800042 	mov	x2, #0x2                   	// #2
    7d74:	97ffee27 	bl	3610 <buf_put>
    7d78:	17ffffe6 	b	7d10 <fwp_write+0xc0c>
    7d7c:	aa1403e0 	mov	x0, x20
    7d80:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7d84:	d2800042 	mov	x2, #0x2                   	// #2
    7d88:	91238021 	add	x1, x1, #0x8e0
    7d8c:	97ffee21 	bl	3610 <buf_put>
    7d90:	17ffffe0 	b	7d10 <fwp_write+0xc0c>
    7d94:	f9414bf9 	ldr	x25, [sp, #656]
    7d98:	f9414ffa 	ldr	x26, [sp, #664]
    7d9c:	aa1503e1 	mov	x1, x21
    7da0:	aa1403e0 	mov	x0, x20
    7da4:	52800443 	mov	w3, #0x22                  	// #34
    7da8:	17fffd9d 	b	741c <fwp_write+0x318>
    7dac:	7100103f 	cmp	w1, #0x4
    7db0:	54ffeb21 	b.ne	7b14 <fwp_write+0xa10>  // b.any
    7db4:	f94006e0 	ldr	x0, [x23, #8]
    7db8:	d37ffc00 	lsr	x0, x0, #63
    7dbc:	17fffeb3 	b	7888 <fwp_write+0x784>
    7dc0:	710002ff 	cmp	w23, #0x0
    7dc4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7dc8:	17fffeb0 	b	7888 <fwp_write+0x784>
    7dcc:	528005a1 	mov	w1, #0x2d                  	// #45
    7dd0:	eb0203e2 	negs	x2, x2
    7dd4:	da0303e3 	ngc	x3, x3
    7dd8:	910127e0 	add	x0, sp, #0x49
    7ddc:	910123f5 	add	x21, sp, #0x48
    7de0:	390123e1 	strb	w1, [sp, #72]
    7de4:	97ffec2f 	bl	2ea0 <fwp_fmt_u128>
    7de8:	17fffe18 	b	7648 <fwp_write+0x544>
    7dec:	d37ceea1 	lsl	x1, x21, #4
    7df0:	b7f810a3 	tbnz	x3, #63, 8004 <fwp_write+0xf00>
    7df4:	91002260 	add	x0, x19, #0x8
    7df8:	8b010001 	add	x1, x0, x1
    7dfc:	17fffdf9 	b	75e0 <fwp_write+0x4dc>
    7e00:	f9400a61 	ldr	x1, [x19, #16]
    7e04:	8b010000 	add	x0, x0, x1
    7e08:	f9400001 	ldr	x1, [x0]
    7e0c:	17fffdf5 	b	75e0 <fwp_write+0x4dc>
    7e10:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7e14:	d2800042 	mov	x2, #0x2                   	// #2
    7e18:	9121c021 	add	x1, x1, #0x870
    7e1c:	17fffed6 	b	7974 <fwp_write+0x870>
    7e20:	7101fcbf 	cmp	w5, #0x7f
    7e24:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7e28:	540000e9 	b.ls	7e44 <fwp_write+0xd40>  // b.plast
    7e2c:	aa1503e1 	mov	x1, x21
    7e30:	aa1403e0 	mov	x0, x20
    7e34:	d2800022 	mov	x2, #0x1                   	// #1
    7e38:	39001fe5 	strb	w5, [sp, #7]
    7e3c:	97ffedf5 	bl	3610 <buf_put>
    7e40:	17ffffb4 	b	7d10 <fwp_write+0xc0c>
    7e44:	d2800203 	mov	x3, #0x10                  	// #16
    7e48:	d0000004 	adrp	x4, 9000 <__divti3+0x370>
    7e4c:	aa0303e1 	mov	x1, x3
    7e50:	9123c084 	add	x4, x4, #0x8f0
    7e54:	910123f6 	add	x22, sp, #0x48
    7e58:	52800042 	mov	w2, #0x2                   	// #2
    7e5c:	aa1603e0 	mov	x0, x22
    7e60:	97ffea88 	bl	2880 <__snprintf_chk@plt>
    7e64:	aa1603e0 	mov	x0, x22
    7e68:	97ffea4e 	bl	27a0 <strlen@plt>
    7e6c:	aa1603e1 	mov	x1, x22
    7e70:	aa0003e2 	mov	x2, x0
    7e74:	aa1403e0 	mov	x0, x20
    7e78:	97ffede6 	bl	3610 <buf_put>
    7e7c:	17ffffa5 	b	7d10 <fwp_write+0xc0c>
    7e80:	1e604100 	fmov	d0, d8
    7e84:	aa1503e0 	mov	x0, x21
    7e88:	52800221 	mov	w1, #0x11                  	// #17
    7e8c:	97ffef62 	bl	3c14 <fwp_format_g.constprop.0>
    7e90:	17fffe43 	b	779c <fwp_write+0x698>
    7e94:	b9401040 	ldr	w0, [x2, #16]
    7e98:	350003c0 	cbnz	w0, 7f10 <fwp_write+0xe0c>
    7e9c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ea0:	f947f400 	ldr	x0, [x0, #4072]
    7ea4:	f94127e2 	ldr	x2, [sp, #584]
    7ea8:	f9400001 	ldr	x1, [x0]
    7eac:	eb010042 	subs	x2, x2, x1
    7eb0:	d2800001 	mov	x1, #0x0                   	// #0
    7eb4:	54ffd721 	b.ne	7998 <fwp_write+0x894>  // b.any
    7eb8:	f9413bf5 	ldr	x21, [sp, #624]
    7ebc:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7ec0:	f9413ff6 	ldr	x22, [sp, #632]
    7ec4:	aa1403e0 	mov	x0, x20
    7ec8:	f94143f7 	ldr	x23, [sp, #640]
    7ecc:	91250021 	add	x1, x1, #0x940
    7ed0:	f94147f8 	ldr	x24, [sp, #648]
    7ed4:	d2800042 	mov	x2, #0x2                   	// #2
    7ed8:	17fffd0f 	b	7314 <fwp_write+0x210>
    7edc:	d0000001 	adrp	x1, 9000 <__divti3+0x370>
    7ee0:	d2800042 	mov	x2, #0x2                   	// #2
    7ee4:	9121e021 	add	x1, x1, #0x878
    7ee8:	17fffea3 	b	7974 <fwp_write+0x870>
    7eec:	f9400a63 	ldr	x3, [x19, #16]
    7ef0:	8b030021 	add	x1, x1, x3
    7ef4:	17ffff66 	b	7c8c <fwp_write+0xb88>
    7ef8:	f9400a61 	ldr	x1, [x19, #16]
    7efc:	8b0102a1 	add	x1, x21, x1
    7f00:	17fffdb4 	b	75d0 <fwp_write+0x4cc>
    7f04:	f9400a63 	ldr	x3, [x19, #16]
    7f08:	8b030021 	add	x1, x1, x3
    7f0c:	17ffff56 	b	7c64 <fwp_write+0xb60>
    7f10:	b9404840 	ldr	w0, [x2, #72]
    7f14:	91001ff5 	add	x21, sp, #0x7
    7f18:	34ffa380 	cbz	w0, 7388 <fwp_write+0x284>
    7f1c:	52800503 	mov	w3, #0x28                  	// #40
    7f20:	aa1403e0 	mov	x0, x20
    7f24:	aa1503e1 	mov	x1, x21
    7f28:	d2800022 	mov	x2, #0x1                   	// #1
    7f2c:	39001fe3 	strb	w3, [sp, #7]
    7f30:	97ffedb8 	bl	3610 <buf_put>
    7f34:	b9401380 	ldr	w0, [x28, #16]
    7f38:	52800038 	mov	w24, #0x1                   	// #1
    7f3c:	7100001f 	cmp	w0, #0x0
    7f40:	54ffa38c 	b.gt	73b0 <fwp_write+0x2ac>
    7f44:	17fffd33 	b	7410 <fwp_write+0x30c>
    7f48:	f9014bf9 	str	x25, [sp, #656]
    7f4c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x12c30>
    7f50:	f9014ffa 	str	x26, [sp, #664]
    7f54:	f9400676 	ldr	x22, [x19, #8]
    7f58:	910aa333 	add	x19, x25, #0x2a8
    7f5c:	91002273 	add	x19, x19, #0x8
    7f60:	937ffed8 	asr	x24, x22, #63
    7f64:	aa1802c0 	orr	x0, x22, x24
    7f68:	b5000320 	cbnz	x0, 7fcc <fwp_write+0xec8>
    7f6c:	110006b5 	add	w21, w21, #0x1
    7f70:	710016bf 	cmp	w21, #0x5
    7f74:	54ffffc1 	b.ne	7f6c <fwp_write+0xe68>  // b.any
    7f78:	b7f80578 	tbnz	x24, #63, 8024 <fwp_write+0xf20>
    7f7c:	910023f3 	add	x19, sp, #0x8
    7f80:	aa1603e2 	mov	x2, x22
    7f84:	aa1303e0 	mov	x0, x19
    7f88:	d2800003 	mov	x3, #0x0                   	// #0
    7f8c:	97ffebc5 	bl	2ea0 <fwp_fmt_u128>
    7f90:	910123f5 	add	x21, sp, #0x48
    7f94:	d0000003 	adrp	x3, 9000 <__divti3+0x370>
    7f98:	aa1303e4 	mov	x4, x19
    7f9c:	aa1503e0 	mov	x0, x21
    7fa0:	9124e063 	add	x3, x3, #0x938
    7fa4:	d2804002 	mov	x2, #0x200                 	// #512
    7fa8:	52800041 	mov	w1, #0x2                   	// #2
    7fac:	97ffea01 	bl	27b0 <__sprintf_chk@plt>
    7fb0:	aa1503e0 	mov	x0, x21
    7fb4:	97ffe9fb 	bl	27a0 <strlen@plt>
    7fb8:	aa1503e1 	mov	x1, x21
    7fbc:	aa0003e2 	mov	x2, x0
    7fc0:	aa1403e0 	mov	x0, x20
    7fc4:	97ffed93 	bl	3610 <buf_put>
    7fc8:	17fffe47 	b	78e4 <fwp_write+0x7e0>
    7fcc:	f9400277 	ldr	x23, [x19]
    7fd0:	aa1603e0 	mov	x0, x22
    7fd4:	aa1803e1 	mov	x1, x24
    7fd8:	aa1703e2 	mov	x2, x23
    7fdc:	937ffefa 	asr	x26, x23, #63
    7fe0:	aa1a03e3 	mov	x3, x26
    7fe4:	9400040b 	bl	9010 <__modti3>
    7fe8:	aa010000 	orr	x0, x0, x1
    7fec:	b40002c0 	cbz	x0, 8044 <fwp_write+0xf40>
    7ff0:	110006b5 	add	w21, w21, #0x1
    7ff4:	91004273 	add	x19, x19, #0x10
    7ff8:	710016bf 	cmp	w21, #0x5
    7ffc:	54fffe81 	b.ne	7fcc <fwp_write+0xec8>  // b.any
    8000:	17ffffde 	b	7f78 <fwp_write+0xe74>
    8004:	f9400a60 	ldr	x0, [x19, #16]
    8008:	8b000021 	add	x1, x1, x0
    800c:	17fffd75 	b	75e0 <fwp_write+0x4dc>
    8010:	528c29c0 	mov	w0, #0x614e                	// #24910
    8014:	910123f5 	add	x21, sp, #0x48
    8018:	72a009c0 	movk	w0, #0x4e, lsl #16
    801c:	b9004be0 	str	w0, [sp, #72]
    8020:	17fffda2 	b	76a8 <fwp_write+0x5a4>
    8024:	528005a1 	mov	w1, #0x2d                  	// #45
    8028:	eb1603e2 	negs	x2, x22
    802c:	da1803e3 	ngc	x3, x24
    8030:	910027e0 	add	x0, sp, #0x9
    8034:	910023f3 	add	x19, sp, #0x8
    8038:	390023e1 	strb	w1, [sp, #8]
    803c:	97ffeb99 	bl	2ea0 <fwp_fmt_u128>
    8040:	17ffffd4 	b	7f90 <fwp_write+0xe8c>
    8044:	aa1703e2 	mov	x2, x23
    8048:	aa1a03e3 	mov	x3, x26
    804c:	aa1603e0 	mov	x0, x22
    8050:	aa1803e1 	mov	x1, x24
    8054:	9400030f 	bl	8c90 <__divti3>
    8058:	aa0003e2 	mov	x2, x0
    805c:	aa0103e3 	mov	x3, x1
    8060:	b7f80201 	tbnz	x1, #63, 80a0 <fwp_write+0xf9c>
    8064:	910023f3 	add	x19, sp, #0x8
    8068:	aa1303e0 	mov	x0, x19
    806c:	97ffeb8d 	bl	2ea0 <fwp_fmt_u128>
    8070:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8074:	910aa339 	add	x25, x25, #0x2a8
    8078:	910123f5 	add	x21, sp, #0x48
    807c:	aa1303e4 	mov	x4, x19
    8080:	aa1503e0 	mov	x0, x21
    8084:	b0000003 	adrp	x3, 9000 <__divti3+0x370>
    8088:	f8616b25 	ldr	x5, [x25, x1]
    808c:	9124c063 	add	x3, x3, #0x930
    8090:	d2804002 	mov	x2, #0x200                 	// #512
    8094:	52800041 	mov	w1, #0x2                   	// #2
    8098:	97ffe9c6 	bl	27b0 <__sprintf_chk@plt>
    809c:	17ffffc5 	b	7fb0 <fwp_write+0xeac>
    80a0:	528005a4 	mov	w4, #0x2d                  	// #45
    80a4:	eb0003e2 	negs	x2, x0
    80a8:	da0103e3 	ngc	x3, x1
    80ac:	910027e0 	add	x0, sp, #0x9
    80b0:	910023f3 	add	x19, sp, #0x8
    80b4:	390023e4 	strb	w4, [sp, #8]
    80b8:	97ffeb7a 	bl	2ea0 <fwp_fmt_u128>
    80bc:	17ffffed 	b	8070 <fwp_write+0xf6c>
    80c0:	f9013bf5 	str	x21, [sp, #624]
    80c4:	f9013ff6 	str	x22, [sp, #632]
    80c8:	f90143f7 	str	x23, [sp, #640]
    80cc:	f90147f8 	str	x24, [sp, #648]
    80d0:	f9014bf9 	str	x25, [sp, #656]
    80d4:	f9014ffa 	str	x26, [sp, #664]
    80d8:	f90153fb 	str	x27, [sp, #672]
    80dc:	f90157fc 	str	x28, [sp, #680]
    80e0:	fd015be8 	str	d8, [sp, #688]
    80e4:	fd015fe9 	str	d9, [sp, #696]
    80e8:	97ffea0a 	bl	2910 <__stack_chk_fail@plt>
    80ec:	d503201f 	nop

00000000000080f0 <fwp_main_thread>:
    80f0:	d10603ff 	sub	sp, sp, #0x180
    80f4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    80f8:	f947f400 	ldr	x0, [x0, #4072]
    80fc:	a9127bfd 	stp	x29, x30, [sp, #288]
    8100:	910483fd 	add	x29, sp, #0x120
    8104:	a91563f7 	stp	x23, x24, [sp, #336]
    8108:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xc00>
    810c:	911782e1 	add	x1, x23, #0x5e0
    8110:	a91353f3 	stp	x19, x20, [sp, #304]
    8114:	a9145bf5 	stp	x21, x22, [sp, #320]
    8118:	b953a421 	ldr	w1, [x1, #5028]
    811c:	a91773fb 	stp	x27, x28, [sp, #368]
    8120:	f9400002 	ldr	x2, [x0]
    8124:	f9008fe2 	str	x2, [sp, #280]
    8128:	d2800002 	mov	x2, #0x0                   	// #0
    812c:	34004ec1 	cbz	w1, 8b04 <fwp_main_thread+0xa14>
    8130:	911782e0 	add	x0, x23, #0x5e0
    8134:	b953a800 	ldr	w0, [x0, #5032]
    8138:	35004de0 	cbnz	w0, 8af4 <fwp_main_thread+0xa04>
    813c:	900000d5 	adrp	x21, 20000 <__data_start>
    8140:	900000c2 	adrp	x2, 20000 <__data_start>
    8144:	910182b3 	add	x19, x21, #0x60
    8148:	91100042 	add	x2, x2, #0x400
    814c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    8150:	d2a00024 	mov	x4, #0x10000               	// #65536
    8154:	910103e0 	add	x0, sp, #0x40
    8158:	9100a3fb 	add	x27, sp, #0x28
    815c:	d2800001 	mov	x1, #0x0                   	// #0
    8160:	f90003e0 	str	x0, [sp]
    8164:	a9018e7b 	stp	x27, x3, [x19, #24]
    8168:	f90023e2 	str	x2, [sp, #64]
    816c:	b9004bff 	str	wzr, [sp, #72]
    8170:	f9002be4 	str	x4, [sp, #80]
    8174:	97ffe97f 	bl	2770 <sigaltstack@plt>
    8178:	35005780 	cbnz	w0, 8c68 <fwp_main_thread+0xb78>
    817c:	4f000400 	movi	v0.4s, #0x0
    8180:	910223e0 	add	x0, sp, #0x88
    8184:	f0ffffc1 	adrp	x1, 3000 <fwp_range_release+0x30>
    8188:	9103c021 	add	x1, x1, #0xf0
    818c:	f90043e1 	str	x1, [sp, #128]
    8190:	52800082 	mov	w2, #0x4                   	// #4
    8194:	72a10002 	movk	w2, #0x800, lsl #16
    8198:	910203f4 	add	x20, sp, #0x80
    819c:	3d802000 	str	q0, [x0, #128]
    81a0:	b9010be2 	str	w2, [sp, #264]
    81a4:	ad000000 	stp	q0, q0, [x0]
    81a8:	ad010000 	stp	q0, q0, [x0, #32]
    81ac:	ad020000 	stp	q0, q0, [x0, #64]
    81b0:	ad030000 	stp	q0, q0, [x0, #96]
    81b4:	97ffe9c7 	bl	28d0 <sigemptyset@plt>
    81b8:	35005580 	cbnz	w0, 8c68 <fwp_main_thread+0xb78>
    81bc:	aa1403e1 	mov	x1, x20
    81c0:	d2800002 	mov	x2, #0x0                   	// #0
    81c4:	52800160 	mov	w0, #0xb                   	// #11
    81c8:	97ffe9da 	bl	2930 <sigaction@plt>
    81cc:	350054e0 	cbnz	w0, 8c68 <fwp_main_thread+0xb78>
    81d0:	aa1403e1 	mov	x1, x20
    81d4:	d2800002 	mov	x2, #0x0                   	// #0
    81d8:	528000e0 	mov	w0, #0x7                   	// #7
    81dc:	97ffe9d5 	bl	2930 <sigaction@plt>
    81e0:	35005440 	cbnz	w0, 8c68 <fwp_main_thread+0xb78>
    81e4:	b9436660 	ldr	w0, [x19, #868]
    81e8:	340012a0 	cbz	w0, 843c <fwp_main_thread+0x34c>
    81ec:	910182a0 	add	x0, x21, #0x60
    81f0:	b9436801 	ldr	w1, [x0, #872]
    81f4:	34001361 	cbz	w1, 8460 <fwp_main_thread+0x370>
    81f8:	910182b6 	add	x22, x21, #0x60
    81fc:	f9400ad4 	ldr	x20, [x22, #16]
    8200:	b4000c74 	cbz	x20, 838c <fwp_main_thread+0x29c>
    8204:	aa1403f3 	mov	x19, x20
    8208:	91010298 	add	x24, x20, #0x40
    820c:	a9166bf9 	stp	x25, x26, [sp, #352]
    8210:	52800037 	mov	w23, #0x1                   	// #1
    8214:	39414a99 	ldrb	w25, [x20, #82]
    8218:	39014a97 	strb	w23, [x20, #82]
    821c:	f9401680 	ldr	x0, [x20, #40]
    8220:	b4000620 	cbz	x0, 82e4 <fwp_main_thread+0x1f4>
    8224:	f9403281 	ldr	x1, [x20, #96]
    8228:	39414680 	ldrb	w0, [x20, #81]
    822c:	b4000ca1 	cbz	x1, 83c0 <fwp_main_thread+0x2d0>
    8230:	36000b60 	tbz	w0, #0, 839c <fwp_main_thread+0x2ac>
    8234:	39414a62 	ldrb	w2, [x19, #82]
    8238:	f9402280 	ldr	x0, [x20, #64]
    823c:	37000ec2 	tbnz	w2, #0, 8414 <fwp_main_thread+0x324>
    8240:	f9403261 	ldr	x1, [x19, #96]
    8244:	a911fe78 	stp	x24, xzr, [x19, #280]
    8248:	f9009660 	str	x0, [x19, #296]
    824c:	b4000040 	cbz	x0, 8254 <fwp_main_thread+0x164>
    8250:	f9009013 	str	x19, [x0, #288]
    8254:	f9002293 	str	x19, [x20, #64]
    8258:	b4000101 	cbz	x1, 8278 <fwp_main_thread+0x188>
    825c:	f9407ec0 	ldr	x0, [x22, #248]
    8260:	39015677 	strb	w23, [x19, #85]
    8264:	f9003661 	str	x1, [x19, #104]
    8268:	a910827f 	stp	xzr, x0, [x19, #264]
    826c:	b4000040 	cbz	x0, 8274 <fwp_main_thread+0x184>
    8270:	f9008413 	str	x19, [x0, #264]
    8274:	f9007ed3 	str	x19, [x22, #248]
    8278:	39015a7f 	strb	wzr, [x19, #86]
    827c:	97fff92a 	bl	6724 <fwp_block>
    8280:	f9408e62 	ldr	x2, [x19, #280]
    8284:	b4000142 	cbz	x2, 82ac <fwp_main_thread+0x1bc>
    8288:	a9520261 	ldp	x1, x0, [x19, #288]
    828c:	b4000d01 	cbz	x1, 842c <fwp_main_thread+0x33c>
    8290:	f9009420 	str	x0, [x1, #296]
    8294:	f9409660 	ldr	x0, [x19, #296]
    8298:	b4000040 	cbz	x0, 82a0 <fwp_main_thread+0x1b0>
    829c:	f9009001 	str	x1, [x0, #288]
    82a0:	91080260 	add	x0, x19, #0x200
    82a4:	f900967f 	str	xzr, [x19, #296]
    82a8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    82ac:	39415660 	ldrb	w0, [x19, #85]
    82b0:	f9400ac2 	ldr	x2, [x22, #16]
    82b4:	36000ac0 	tbz	w0, #0, 840c <fwp_main_thread+0x31c>
    82b8:	a9508261 	ldp	x1, x0, [x19, #264]
    82bc:	b4000bc1 	cbz	x1, 8434 <fwp_main_thread+0x344>
    82c0:	f9008820 	str	x0, [x1, #272]
    82c4:	b4000040 	cbz	x0, 82cc <fwp_main_thread+0x1dc>
    82c8:	f9008401 	str	x1, [x0, #264]
    82cc:	91080260 	add	x0, x19, #0x200
    82d0:	3901567f 	strb	wzr, [x19, #85]
    82d4:	aa0203f3 	mov	x19, x2
    82d8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    82dc:	f9401680 	ldr	x0, [x20, #40]
    82e0:	b5fffa20 	cbnz	x0, 8224 <fwp_main_thread+0x134>
    82e4:	910182a0 	add	x0, x21, #0x60
    82e8:	39014a99 	strb	w25, [x20, #82]
    82ec:	a9566bf9 	ldp	x25, x26, [sp, #352]
    82f0:	f941a400 	ldr	x0, [x0, #840]
    82f4:	b5000080 	cbnz	x0, 8304 <fwp_main_thread+0x214>
    82f8:	910182b4 	add	x20, x21, #0x60
    82fc:	f941ae80 	ldr	x0, [x20, #856]
    8300:	b4004440 	cbz	x0, 8b88 <fwp_main_thread+0xa98>
    8304:	910182a0 	add	x0, x21, #0x60
    8308:	f941c001 	ldr	x1, [x0, #896]
    830c:	b903781f 	str	wzr, [x0, #888]
    8310:	eb13003f 	cmp	x1, x19
    8314:	54004501 	b.ne	8bb4 <fwp_main_thread+0xac4>  // b.any
    8318:	b40033f3 	cbz	x19, 8994 <fwp_main_thread+0x8a4>
    831c:	910182a0 	add	x0, x21, #0x60
    8320:	52800021 	mov	w1, #0x1                   	// #1
    8324:	39014a61 	strb	w1, [x19, #82]
    8328:	f9419005 	ldr	x5, [x0, #800]
    832c:	b4003345 	cbz	x5, 8994 <fwp_main_thread+0x8a4>
    8330:	394140a0 	ldrb	w0, [x5, #80]
    8334:	37000060 	tbnz	w0, #0, 8340 <fwp_main_thread+0x250>
    8338:	aa0503e0 	mov	x0, x5
    833c:	97ffed0d 	bl	3770 <fwp_cancel_tree.part.0>
    8340:	f9409ca5 	ldr	x5, [x5, #312]
    8344:	b5ffff65 	cbnz	x5, 8330 <fwp_main_thread+0x240>
    8348:	910182b4 	add	x20, x21, #0x60
    834c:	52800036 	mov	w22, #0x1                   	// #1
    8350:	f9402a60 	ldr	x0, [x19, #80]
    8354:	f2001c1f 	tst	x0, #0xff000000ff
    8358:	540000e1 	b.ne	8374 <fwp_main_thread+0x284>  // b.any
    835c:	f9403e80 	ldr	x0, [x20, #120]
    8360:	39015276 	strb	w22, [x19, #84]
    8364:	f900827f 	str	xzr, [x19, #256]
    8368:	b40030c0 	cbz	x0, 8980 <fwp_main_thread+0x890>
    836c:	f9008013 	str	x19, [x0, #256]
    8370:	f9003e93 	str	x19, [x20, #120]
    8374:	97fff8ec 	bl	6724 <fwp_block>
    8378:	97fff87e 	bl	6570 <fwp_free_zombie>
    837c:	f9419280 	ldr	x0, [x20, #800]
    8380:	b40030a0 	cbz	x0, 8994 <fwp_main_thread+0x8a4>
    8384:	f941c293 	ldr	x19, [x20, #896]
    8388:	17fffff2 	b	8350 <fwp_main_thread+0x260>
    838c:	f941a6c0 	ldr	x0, [x22, #840]
    8390:	b5002fc0 	cbnz	x0, 8988 <fwp_main_thread+0x898>
    8394:	d2800013 	mov	x19, #0x0                   	// #0
    8398:	17ffffd8 	b	82f8 <fwp_main_thread+0x208>
    839c:	97ffed99 	bl	3a00 <fwp_now_ns>
    83a0:	f9403281 	ldr	x1, [x20, #96]
    83a4:	eb01001f 	cmp	x0, x1
    83a8:	540000ab 	b.lt	83bc <fwp_main_thread+0x2cc>  // b.tstop
    83ac:	39414280 	ldrb	w0, [x20, #80]
    83b0:	37000060 	tbnz	w0, #0, 83bc <fwp_main_thread+0x2cc>
    83b4:	aa1403e0 	mov	x0, x20
    83b8:	97ffecee 	bl	3770 <fwp_cancel_tree.part.0>
    83bc:	39414680 	ldrb	w0, [x20, #81]
    83c0:	39414a62 	ldrb	w2, [x19, #82]
    83c4:	3707f3a0 	tbnz	w0, #0, 8238 <fwp_main_thread+0x148>
    83c8:	f9403281 	ldr	x1, [x20, #96]
    83cc:	370001c2 	tbnz	w2, #0, 8404 <fwp_main_thread+0x314>
    83d0:	f9403260 	ldr	x0, [x19, #96]
    83d4:	b4000180 	cbz	x0, 8404 <fwp_main_thread+0x314>
    83d8:	b4000061 	cbz	x1, 83e4 <fwp_main_thread+0x2f4>
    83dc:	eb01001f 	cmp	x0, x1
    83e0:	9a81d000 	csel	x0, x0, x1, le
    83e4:	f9402281 	ldr	x1, [x20, #64]
    83e8:	a911fe78 	stp	x24, xzr, [x19, #280]
    83ec:	f9009661 	str	x1, [x19, #296]
    83f0:	b4003c61 	cbz	x1, 8b7c <fwp_main_thread+0xa8c>
    83f4:	f9009033 	str	x19, [x1, #288]
    83f8:	aa0003e1 	mov	x1, x0
    83fc:	f9002293 	str	x19, [x20, #64]
    8400:	17ffff97 	b	825c <fwp_main_thread+0x16c>
    8404:	f9402280 	ldr	x0, [x20, #64]
    8408:	17ffff8f 	b	8244 <fwp_main_thread+0x154>
    840c:	aa0203f3 	mov	x19, x2
    8410:	17ffff83 	b	821c <fwp_main_thread+0x12c>
    8414:	a911fe78 	stp	x24, xzr, [x19, #280]
    8418:	f9009660 	str	x0, [x19, #296]
    841c:	b4000040 	cbz	x0, 8424 <fwp_main_thread+0x334>
    8420:	f9009013 	str	x19, [x0, #288]
    8424:	f9002293 	str	x19, [x20, #64]
    8428:	17ffff94 	b	8278 <fwp_main_thread+0x188>
    842c:	f9000040 	str	x0, [x2]
    8430:	17ffff9a 	b	8298 <fwp_main_thread+0x1a8>
    8434:	f9007ec0 	str	x0, [x22, #248]
    8438:	17ffffa3 	b	82c4 <fwp_main_thread+0x1d4>
    843c:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    8440:	91078000 	add	x0, x0, #0x1e0
    8444:	940003cf 	bl	9380 <atexit>
    8448:	35004180 	cbnz	w0, 8c78 <fwp_main_thread+0xb88>
    844c:	52800020 	mov	w0, #0x1                   	// #1
    8450:	b9036660 	str	w0, [x19, #868]
    8454:	910182a0 	add	x0, x21, #0x60
    8458:	b9436801 	ldr	w1, [x0, #872]
    845c:	35ffece1 	cbnz	w1, 81f8 <fwp_main_thread+0x108>
    8460:	f9419803 	ldr	x3, [x0, #816]
    8464:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    8468:	913f4042 	add	x2, x2, #0xfd0
    846c:	a9028be3 	stp	x3, x2, [sp, #40]
    8470:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x40>
    8474:	f94003e2 	ldr	x2, [sp]
    8478:	a9166bf9 	stp	x25, x26, [sp, #352]
    847c:	912ac021 	add	x1, x1, #0xab0
    8480:	911782f9 	add	x25, x23, #0x5e0
    8484:	d2800013 	mov	x19, #0x0                   	// #0
    8488:	d290001a 	mov	x26, #0x8000                	// #32768
    848c:	d2800016 	mov	x22, #0x0                   	// #0
    8490:	f9001fe2 	str	x2, [sp, #56]
    8494:	f90023ff 	str	xzr, [sp, #64]
    8498:	a90507ff 	stp	xzr, x1, [sp, #80]
    849c:	f901981b 	str	x27, [x0, #816]
    84a0:	14000012 	b	84e8 <fwp_main_thread+0x3f8>
    84a4:	7100045f 	cmp	w2, #0x1
    84a8:	540001a1 	b.ne	84dc <fwp_main_thread+0x3ec>  // b.any
    84ac:	29430002 	ldp	w2, w0, [x0, #24]
    84b0:	92403c21 	and	x1, x1, #0xffff
    84b4:	9b027c21 	mul	x1, x1, x2
    84b8:	d360fc21 	lsr	x1, x1, #32
    84bc:	eb00003f 	cmp	x1, x0
    84c0:	540000e2 	b.cs	84dc <fwp_main_thread+0x3ec>  // b.hs, b.nlast
    84c4:	8b01039c 	add	x28, x28, x1
    84c8:	39400380 	ldrb	w0, [x28]
    84cc:	7103fc1f 	cmp	w0, #0xff
    84d0:	54003500 	b.eq	8b70 <fwp_main_thread+0xa80>  // b.none
    84d4:	52800020 	mov	w0, #0x1                   	// #1
    84d8:	39000380 	strb	w0, [x28]
    84dc:	f90023f3 	str	x19, [sp, #64]
    84e0:	aa18037b 	orr	x27, x27, x24
    84e4:	b40003fb 	cbz	x27, 8560 <fwp_main_thread+0x470>
    84e8:	f100075b 	subs	x27, x26, #0x1
    84ec:	aa1403e1 	mov	x1, x20
    84f0:	da1f02d8 	sbc	x24, x22, xzr
    84f4:	52800020 	mov	w0, #0x1                   	// #1
    84f8:	f90027fb 	str	x27, [sp, #72]
    84fc:	aa1b03fa 	mov	x26, x27
    8500:	a9084ffb 	stp	x27, x19, [sp, #128]
    8504:	97fff2f4 	bl	50d4 <fwp_data.part.0.constprop.0>
    8508:	aa0003f3 	mov	x19, x0
    850c:	f949db21 	ldr	x1, [x25, #5040]
    8510:	aa1803f6 	mov	x22, x24
    8514:	f949ef20 	ldr	x0, [x25, #5080]
    8518:	cb010261 	sub	x1, x19, x1
    851c:	eb00403f 	cmp	x1, x0, lsl #16
    8520:	54fffde2 	b.cs	84dc <fwp_main_thread+0x3ec>  // b.hs, b.nlast
    8524:	d350fc20 	lsr	x0, x1, #16
    8528:	f949ff25 	ldr	x5, [x25, #5112]
    852c:	8b000800 	add	x0, x0, x0, lsl #2
    8530:	d37df002 	lsl	x2, x0, #3
    8534:	8b0200a0 	add	x0, x5, x2
    8538:	f940101c 	ldr	x28, [x0, #32]
    853c:	b4fffd1c 	cbz	x28, 84dc <fwp_main_thread+0x3ec>
    8540:	386268a2 	ldrb	w2, [x5, x2]
    8544:	7100085f 	cmp	w2, #0x2
    8548:	54fffae1 	b.ne	84a4 <fwp_main_thread+0x3b4>  // b.any
    854c:	72003c3f 	tst	w1, #0xffff
    8550:	54fffbc0 	b.eq	84c8 <fwp_main_thread+0x3d8>  // b.none
    8554:	f90023f3 	str	x19, [sp, #64]
    8558:	aa18037b 	orr	x27, x27, x24
    855c:	b5fffc7b 	cbnz	x27, 84e8 <fwp_main_thread+0x3f8>
    8560:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0xc50>
    8564:	910182a2 	add	x2, x21, #0x60
    8568:	f94017e3 	ldr	x3, [sp, #40]
    856c:	910183e1 	add	x1, sp, #0x60
    8570:	3dc03c00 	ldr	q0, [x0, #240]
    8574:	52800020 	mov	w0, #0x1                   	// #1
    8578:	f9019843 	str	x3, [x2, #816]
    857c:	3d801be0 	str	q0, [sp, #96]
    8580:	97fff2d5 	bl	50d4 <fwp_data.part.0.constprop.0>
    8584:	911782e2 	add	x2, x23, #0x5e0
    8588:	aa0003f9 	mov	x25, x0
    858c:	f949d841 	ldr	x1, [x2, #5040]
    8590:	f949ec40 	ldr	x0, [x2, #5080]
    8594:	cb010321 	sub	x1, x25, x1
    8598:	eb00403f 	cmp	x1, x0, lsl #16
    859c:	54000322 	b.cs	8600 <fwp_main_thread+0x510>  // b.hs, b.nlast
    85a0:	d350fc20 	lsr	x0, x1, #16
    85a4:	f949fc43 	ldr	x3, [x2, #5112]
    85a8:	8b000800 	add	x0, x0, x0, lsl #2
    85ac:	d37df002 	lsl	x2, x0, #3
    85b0:	8b020060 	add	x0, x3, x2
    85b4:	f9401016 	ldr	x22, [x0, #32]
    85b8:	b4000256 	cbz	x22, 8600 <fwp_main_thread+0x510>
    85bc:	38626862 	ldrb	w2, [x3, x2]
    85c0:	7100085f 	cmp	w2, #0x2
    85c4:	54002bc0 	b.eq	8b3c <fwp_main_thread+0xa4c>  // b.none
    85c8:	7100045f 	cmp	w2, #0x1
    85cc:	540001a1 	b.ne	8600 <fwp_main_thread+0x510>  // b.any
    85d0:	29430002 	ldp	w2, w0, [x0, #24]
    85d4:	92403c21 	and	x1, x1, #0xffff
    85d8:	9b027c21 	mul	x1, x1, x2
    85dc:	d360fc21 	lsr	x1, x1, #32
    85e0:	eb00003f 	cmp	x1, x0
    85e4:	540000e2 	b.cs	8600 <fwp_main_thread+0x510>  // b.hs, b.nlast
    85e8:	8b0102d6 	add	x22, x22, x1
    85ec:	394002c0 	ldrb	w0, [x22]
    85f0:	7103fc1f 	cmp	w0, #0xff
    85f4:	54003280 	b.eq	8c44 <fwp_main_thread+0xb54>  // b.none
    85f8:	52800020 	mov	w0, #0x1                   	// #1
    85fc:	390002c0 	strb	w0, [x22]
    8600:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8604:	aa1403e1 	mov	x1, x20
    8608:	52800020 	mov	w0, #0x1                   	// #1
    860c:	a90867e2 	stp	x2, x25, [sp, #128]
    8610:	97fff2b1 	bl	50d4 <fwp_data.part.0.constprop.0>
    8614:	911782e2 	add	x2, x23, #0x5e0
    8618:	aa0003f6 	mov	x22, x0
    861c:	f949d841 	ldr	x1, [x2, #5040]
    8620:	f949ec40 	ldr	x0, [x2, #5080]
    8624:	cb0102c1 	sub	x1, x22, x1
    8628:	eb00403f 	cmp	x1, x0, lsl #16
    862c:	54000322 	b.cs	8690 <fwp_main_thread+0x5a0>  // b.hs, b.nlast
    8630:	d350fc20 	lsr	x0, x1, #16
    8634:	f949fc43 	ldr	x3, [x2, #5112]
    8638:	8b000800 	add	x0, x0, x0, lsl #2
    863c:	d37df002 	lsl	x2, x0, #3
    8640:	8b020060 	add	x0, x3, x2
    8644:	f9401014 	ldr	x20, [x0, #32]
    8648:	b4000254 	cbz	x20, 8690 <fwp_main_thread+0x5a0>
    864c:	38626862 	ldrb	w2, [x3, x2]
    8650:	7100085f 	cmp	w2, #0x2
    8654:	54002800 	b.eq	8b54 <fwp_main_thread+0xa64>  // b.none
    8658:	7100045f 	cmp	w2, #0x1
    865c:	540001a1 	b.ne	8690 <fwp_main_thread+0x5a0>  // b.any
    8660:	29430002 	ldp	w2, w0, [x0, #24]
    8664:	92403c21 	and	x1, x1, #0xffff
    8668:	9b027c21 	mul	x1, x1, x2
    866c:	d360fc21 	lsr	x1, x1, #32
    8670:	eb00003f 	cmp	x1, x0
    8674:	540000e2 	b.cs	8690 <fwp_main_thread+0x5a0>  // b.hs, b.nlast
    8678:	8b010294 	add	x20, x20, x1
    867c:	39400280 	ldrb	w0, [x20]
    8680:	7103fc1f 	cmp	w0, #0xff
    8684:	54002d40 	b.eq	8c2c <fwp_main_thread+0xb3c>  // b.none
    8688:	52800020 	mov	w0, #0x1                   	// #1
    868c:	39000280 	strb	w0, [x20]
    8690:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8694:	9101c3e1 	add	x1, sp, #0x70
    8698:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    869c:	52800020 	mov	w0, #0x1                   	// #1
    86a0:	a9075be2 	stp	x2, x22, [sp, #112]
    86a4:	97fff28c 	bl	50d4 <fwp_data.part.0.constprop.0>
    86a8:	911782e2 	add	x2, x23, #0x5e0
    86ac:	aa0003f4 	mov	x20, x0
    86b0:	f949d841 	ldr	x1, [x2, #5040]
    86b4:	f949ec40 	ldr	x0, [x2, #5080]
    86b8:	cb010281 	sub	x1, x20, x1
    86bc:	eb00403f 	cmp	x1, x0, lsl #16
    86c0:	54000322 	b.cs	8724 <fwp_main_thread+0x634>  // b.hs, b.nlast
    86c4:	d350fc20 	lsr	x0, x1, #16
    86c8:	f949fc43 	ldr	x3, [x2, #5112]
    86cc:	8b000800 	add	x0, x0, x0, lsl #2
    86d0:	d37df002 	lsl	x2, x0, #3
    86d4:	8b020060 	add	x0, x3, x2
    86d8:	f9401016 	ldr	x22, [x0, #32]
    86dc:	b4000256 	cbz	x22, 8724 <fwp_main_thread+0x634>
    86e0:	38626862 	ldrb	w2, [x3, x2]
    86e4:	7100085f 	cmp	w2, #0x2
    86e8:	54002300 	b.eq	8b48 <fwp_main_thread+0xa58>  // b.none
    86ec:	7100045f 	cmp	w2, #0x1
    86f0:	540001a1 	b.ne	8724 <fwp_main_thread+0x634>  // b.any
    86f4:	29430002 	ldp	w2, w0, [x0, #24]
    86f8:	92403c21 	and	x1, x1, #0xffff
    86fc:	9b027c21 	mul	x1, x1, x2
    8700:	d360fc21 	lsr	x1, x1, #32
    8704:	eb00003f 	cmp	x1, x0
    8708:	540000e2 	b.cs	8724 <fwp_main_thread+0x634>  // b.hs, b.nlast
    870c:	8b0102d6 	add	x22, x22, x1
    8710:	394002c0 	ldrb	w0, [x22]
    8714:	7103fc1f 	cmp	w0, #0xff
    8718:	54002900 	b.eq	8c38 <fwp_main_thread+0xb48>  // b.none
    871c:	52800020 	mov	w0, #0x1                   	// #1
    8720:	390002c0 	strb	w0, [x22]
    8724:	aa1303f6 	mov	x22, x19
    8728:	d00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x12c30>
    872c:	b4001173 	cbz	x19, 8958 <fwp_main_thread+0x868>
    8730:	910aa000 	add	x0, x0, #0x2a8
    8734:	911782fb 	add	x27, x23, #0x5e0
    8738:	91014000 	add	x0, x0, #0x50
    873c:	b000001a 	adrp	x26, 9000 <__divti3+0x370>
    8740:	52800038 	mov	w24, #0x1                   	// #1
    8744:	f90007e0 	str	x0, [sp, #8]
    8748:	91392340 	add	x0, x26, #0xe48
    874c:	f9000be0 	str	x0, [sp, #16]
    8750:	f949db61 	ldr	x1, [x27, #5040]
    8754:	f949ef60 	ldr	x0, [x27, #5080]
    8758:	cb010281 	sub	x1, x20, x1
    875c:	eb00403f 	cmp	x1, x0, lsl #16
    8760:	54000342 	b.cs	87c8 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    8764:	d350fc20 	lsr	x0, x1, #16
    8768:	f949ff65 	ldr	x5, [x27, #5112]
    876c:	8b000800 	add	x0, x0, x0, lsl #2
    8770:	d37df002 	lsl	x2, x0, #3
    8774:	8b0200a3 	add	x3, x5, x2
    8778:	f9401060 	ldr	x0, [x3, #32]
    877c:	b4000260 	cbz	x0, 87c8 <fwp_main_thread+0x6d8>
    8780:	386268a2 	ldrb	w2, [x5, x2]
    8784:	7100085f 	cmp	w2, #0x2
    8788:	54001c80 	b.eq	8b18 <fwp_main_thread+0xa28>  // b.none
    878c:	7100045f 	cmp	w2, #0x1
    8790:	540001c1 	b.ne	87c8 <fwp_main_thread+0x6d8>  // b.any
    8794:	29430865 	ldp	w5, w2, [x3, #24]
    8798:	92403c21 	and	x1, x1, #0xffff
    879c:	9b057c21 	mul	x1, x1, x5
    87a0:	d360fc21 	lsr	x1, x1, #32
    87a4:	eb02003f 	cmp	x1, x2
    87a8:	54000102 	b.cs	87c8 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    87ac:	8b010000 	add	x0, x0, x1
    87b0:	39400001 	ldrb	w1, [x0]
    87b4:	340000a1 	cbz	w1, 87c8 <fwp_main_thread+0x6d8>
    87b8:	7103f43f 	cmp	w1, #0xfd
    87bc:	54002008 	b.hi	8bbc <fwp_main_thread+0xacc>  // b.pmore
    87c0:	11000421 	add	w1, w1, #0x1
    87c4:	39000001 	strb	w1, [x0]
    87c8:	a9400be0 	ldp	x0, x2, [sp]
    87cc:	aa1403e1 	mov	x1, x20
    87d0:	52800023 	mov	w3, #0x1                   	// #1
    87d4:	a9047fff 	stp	xzr, xzr, [sp, #64]
    87d8:	f9002bff 	str	xzr, [sp, #80]
    87dc:	97fffa4a 	bl	7104 <fwp_write>
    87e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    87e4:	f9400be0 	ldr	x0, [sp, #16]
    87e8:	f100033f 	cmp	x25, #0x0
    87ec:	9a990019 	csel	x25, x0, x25, eq	// eq = none
    87f0:	b1002b5f 	cmn	x26, #0xa
    87f4:	540022e8 	b.hi	8c50 <fwp_main_thread+0xb60>  // b.pmore
    87f8:	52800021 	mov	w1, #0x1                   	// #1
    87fc:	91002740 	add	x0, x26, #0x9
    8800:	97fff1f0 	bl	4fc0 <fwp_heap_alloc>
    8804:	aa0003fc 	mov	x28, x0
    8808:	aa1903e1 	mov	x1, x25
    880c:	aa0003f9 	mov	x25, x0
    8810:	aa1a03e2 	mov	x2, x26
    8814:	f800873a 	str	x26, [x25], #8
    8818:	aa1903e0 	mov	x0, x25
    881c:	97ffe7d1 	bl	2760 <memcpy@plt>
    8820:	8b1a0382 	add	x2, x28, x26
    8824:	3900205f 	strb	wzr, [x2, #8]
    8828:	f94023e0 	ldr	x0, [sp, #64]
    882c:	97ffe869 	bl	29d0 <free@plt>
    8830:	f949db62 	ldr	x2, [x27, #5040]
    8834:	f949ef60 	ldr	x0, [x27, #5080]
    8838:	cb020382 	sub	x2, x28, x2
    883c:	eb00405f 	cmp	x2, x0, lsl #16
    8840:	54000302 	b.cs	88a0 <fwp_main_thread+0x7b0>  // b.hs, b.nlast
    8844:	d350fc40 	lsr	x0, x2, #16
    8848:	f949ff66 	ldr	x6, [x27, #5112]
    884c:	8b000800 	add	x0, x0, x0, lsl #2
    8850:	d37df001 	lsl	x1, x0, #3
    8854:	8b0100c5 	add	x5, x6, x1
    8858:	f94010a0 	ldr	x0, [x5, #32]
    885c:	b4000220 	cbz	x0, 88a0 <fwp_main_thread+0x7b0>
    8860:	386168c1 	ldrb	w1, [x6, x1]
    8864:	7100083f 	cmp	w1, #0x2
    8868:	540015e0 	b.eq	8b24 <fwp_main_thread+0xa34>  // b.none
    886c:	7100043f 	cmp	w1, #0x1
    8870:	54000181 	b.ne	88a0 <fwp_main_thread+0x7b0>  // b.any
    8874:	92403c41 	and	x1, x2, #0xffff
    8878:	294308a6 	ldp	w6, w2, [x5, #24]
    887c:	9b067c21 	mul	x1, x1, x6
    8880:	d360fc21 	lsr	x1, x1, #32
    8884:	eb02003f 	cmp	x1, x2
    8888:	540000c2 	b.cs	88a0 <fwp_main_thread+0x7b0>  // b.hs, b.nlast
    888c:	8b010000 	add	x0, x0, x1
    8890:	39400001 	ldrb	w1, [x0]
    8894:	7103fc3f 	cmp	w1, #0xff
    8898:	54001640 	b.eq	8b60 <fwp_main_thread+0xa70>  // b.none
    889c:	39000018 	strb	w24, [x0]
    88a0:	aa1403e0 	mov	x0, x20
    88a4:	97fff4d7 	bl	5c00 <fwp_drop0>
    88a8:	910182a5 	add	x5, x21, #0x60
    88ac:	aa1903e0 	mov	x0, x25
    88b0:	f9400382 	ldr	x2, [x28]
    88b4:	aa0503f9 	mov	x25, x5
    88b8:	f94004a3 	ldr	x3, [x5, #8]
    88bc:	d2800021 	mov	x1, #0x1                   	// #1
    88c0:	97ffe854 	bl	2a10 <fwrite@plt>
    88c4:	f9400721 	ldr	x1, [x25, #8]
    88c8:	52800140 	mov	w0, #0xa                   	// #10
    88cc:	97ffe7d9 	bl	2830 <fputc@plt>
    88d0:	f949db62 	ldr	x2, [x27, #5040]
    88d4:	f949ef60 	ldr	x0, [x27, #5080]
    88d8:	cb020382 	sub	x2, x28, x2
    88dc:	eb00405f 	cmp	x2, x0, lsl #16
    88e0:	54000382 	b.cs	8950 <fwp_main_thread+0x860>  // b.hs, b.nlast
    88e4:	d350fc40 	lsr	x0, x2, #16
    88e8:	f949ff65 	ldr	x5, [x27, #5112]
    88ec:	8b000800 	add	x0, x0, x0, lsl #2
    88f0:	d37df001 	lsl	x1, x0, #3
    88f4:	8b0100a3 	add	x3, x5, x1
    88f8:	f9401060 	ldr	x0, [x3, #32]
    88fc:	b40002a0 	cbz	x0, 8950 <fwp_main_thread+0x860>
    8900:	386168a1 	ldrb	w1, [x5, x1]
    8904:	7100083f 	cmp	w1, #0x2
    8908:	54001140 	b.eq	8b30 <fwp_main_thread+0xa40>  // b.none
    890c:	7100043f 	cmp	w1, #0x1
    8910:	54000201 	b.ne	8950 <fwp_main_thread+0x860>  // b.any
    8914:	92403c41 	and	x1, x2, #0xffff
    8918:	29430865 	ldp	w5, w2, [x3, #24]
    891c:	9b057c21 	mul	x1, x1, x5
    8920:	d360fc21 	lsr	x1, x1, #32
    8924:	eb02003f 	cmp	x1, x2
    8928:	54000142 	b.cs	8950 <fwp_main_thread+0x860>  // b.hs, b.nlast
    892c:	8b010000 	add	x0, x0, x1
    8930:	39400001 	ldrb	w1, [x0]
    8934:	340000e1 	cbz	w1, 8950 <fwp_main_thread+0x860>
    8938:	7100043f 	cmp	w1, #0x1
    893c:	54000e80 	b.eq	8b0c <fwp_main_thread+0xa1c>  // b.none
    8940:	7103fc3f 	cmp	w1, #0xff
    8944:	54001400 	b.eq	8bc4 <fwp_main_thread+0xad4>  // b.none
    8948:	51000421 	sub	w1, w1, #0x1
    894c:	39000001 	strb	w1, [x0]
    8950:	f9400ad6 	ldr	x22, [x22, #16]
    8954:	b5ffeff6 	cbnz	x22, 8750 <fwp_main_thread+0x660>
    8958:	aa1403e0 	mov	x0, x20
    895c:	97fff4a9 	bl	5c00 <fwp_drop0>
    8960:	aa1303e0 	mov	x0, x19
    8964:	97fff4a7 	bl	5c00 <fwp_drop0>
    8968:	910182a0 	add	x0, x21, #0x60
    896c:	52800021 	mov	w1, #0x1                   	// #1
    8970:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8974:	b9036801 	str	w1, [x0, #872]
    8978:	f901b81f 	str	xzr, [x0, #880]
    897c:	17fffe1f 	b	81f8 <fwp_main_thread+0x108>
    8980:	f9004293 	str	x19, [x20, #128]
    8984:	17fffe7b 	b	8370 <fwp_main_thread+0x280>
    8988:	f941c2c0 	ldr	x0, [x22, #896]
    898c:	b9037adf 	str	wzr, [x22, #888]
    8990:	b5001120 	cbnz	x0, 8bb4 <fwp_main_thread+0xac4>
    8994:	910182b4 	add	x20, x21, #0x60
    8998:	97fff6f6 	bl	6570 <fwp_free_zombie>
    899c:	f9404280 	ldr	x0, [x20, #128]
    89a0:	b50010a0 	cbnz	x0, 8bb4 <fwp_main_thread+0xac4>
    89a4:	f9407e80 	ldr	x0, [x20, #248]
    89a8:	b5001060 	cbnz	x0, 8bb4 <fwp_main_thread+0xac4>
    89ac:	b9411a80 	ldr	w0, [x20, #280]
    89b0:	340001e0 	cbz	w0, 89ec <fwp_main_thread+0x8fc>
    89b4:	93407c16 	sxtw	x22, w0
    89b8:	51000400 	sub	w0, w0, #0x1
    89bc:	d1000ad6 	sub	x22, x22, #0x2
    89c0:	91048297 	add	x23, x20, #0x120
    89c4:	cb2042d6 	sub	x22, x22, w0, uxtw
    89c8:	93407c13 	sxtw	x19, w0
    89cc:	d503201f 	nop
    89d0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    89d4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    89d8:	b9011a93 	str	w19, [x20, #280]
    89dc:	d1000673 	sub	x19, x19, #0x1
    89e0:	97ffe814 	bl	2a30 <munmap@plt>
    89e4:	eb1302df 	cmp	x22, x19
    89e8:	54ffff41 	b.ne	89d0 <fwp_main_thread+0x8e0>  // b.any
    89ec:	900000d3 	adrp	x19, 20000 <__data_start>
    89f0:	91004260 	add	x0, x19, #0x10
    89f4:	b9403800 	ldr	w0, [x0, #56]
    89f8:	37f80040 	tbnz	w0, #31, 8a00 <fwp_main_thread+0x910>
    89fc:	97ffe7c9 	bl	2920 <close@plt>
    8a00:	910182a0 	add	x0, x21, #0x60
    8a04:	91004261 	add	x1, x19, #0x10
    8a08:	12800002 	mov	w2, #0xffffffff            	// #-1
    8a0c:	d2800013 	mov	x19, #0x0                   	// #0
    8a10:	f941c416 	ldr	x22, [x0, #904]
    8a14:	b9003822 	str	w2, [x1, #56]
    8a18:	f941c814 	ldr	x20, [x0, #912]
    8a1c:	b4000176 	cbz	x22, 8a48 <fwp_main_thread+0x958>
    8a20:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    8a24:	b40000c0 	cbz	x0, 8a3c <fwp_main_thread+0x94c>
    8a28:	f9400001 	ldr	x1, [x0]
    8a2c:	b5000c41 	cbnz	x1, 8bb4 <fwp_main_thread+0xac4>
    8a30:	f9400401 	ldr	x1, [x0, #8]
    8a34:	b5000c01 	cbnz	x1, 8bb4 <fwp_main_thread+0xac4>
    8a38:	97fff042 	bl	4b40 <fwp_mem_free>
    8a3c:	91000673 	add	x19, x19, #0x1
    8a40:	eb16027f 	cmp	x19, x22
    8a44:	54fffee1 	b.ne	8a20 <fwp_main_thread+0x930>  // b.any
    8a48:	aa1403e0 	mov	x0, x20
    8a4c:	97fff03d 	bl	4b40 <fwp_mem_free>
    8a50:	910182a0 	add	x0, x21, #0x60
    8a54:	f941c013 	ldr	x19, [x0, #896]
    8a58:	f901c41f 	str	xzr, [x0, #904]
    8a5c:	f901c81f 	str	xzr, [x0, #912]
    8a60:	b40001f3 	cbz	x19, 8a9c <fwp_main_thread+0x9ac>
    8a64:	f9401661 	ldr	x1, [x19, #40]
    8a68:	b5000a61 	cbnz	x1, 8bb4 <fwp_main_thread+0xac4>
    8a6c:	f9405661 	ldr	x1, [x19, #168]
    8a70:	b5000a21 	cbnz	x1, 8bb4 <fwp_main_thread+0xac4>
    8a74:	f941a401 	ldr	x1, [x0, #840]
    8a78:	b50009e1 	cbnz	x1, 8bb4 <fwp_main_thread+0xac4>
    8a7c:	f941ac00 	ldr	x0, [x0, #856]
    8a80:	b50009a0 	cbnz	x0, 8bb4 <fwp_main_thread+0xac4>
    8a84:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8a88:	90000140 	adrp	x0, 30000 <alt.9+0xfc00>
    8a8c:	91100000 	add	x0, x0, #0x400
    8a90:	97ffe794 	bl	28e0 <memset@plt>
    8a94:	aa1303e0 	mov	x0, x19
    8a98:	97fff02a 	bl	4b40 <fwp_mem_free>
    8a9c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8aa0:	f947ec00 	ldr	x0, [x0, #4056]
    8aa4:	910182b5 	add	x21, x21, #0x60
    8aa8:	f9400000 	ldr	x0, [x0]
    8aac:	f9000abf 	str	xzr, [x21, #16]
    8ab0:	f901c2bf 	str	xzr, [x21, #896]
    8ab4:	97ffe7e3 	bl	2a40 <fflush@plt>
    8ab8:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8abc:	f947f400 	ldr	x0, [x0, #4072]
    8ac0:	f9408fe2 	ldr	x2, [sp, #280]
    8ac4:	f9400001 	ldr	x1, [x0]
    8ac8:	eb010042 	subs	x2, x2, x1
    8acc:	d2800001 	mov	x1, #0x0                   	// #0
    8ad0:	54000d81 	b.ne	8c80 <fwp_main_thread+0xb90>  // b.any
    8ad4:	a9527bfd 	ldp	x29, x30, [sp, #288]
    8ad8:	d2800000 	mov	x0, #0x0                   	// #0
    8adc:	a95353f3 	ldp	x19, x20, [sp, #304]
    8ae0:	a9545bf5 	ldp	x21, x22, [sp, #320]
    8ae4:	a95563f7 	ldp	x23, x24, [sp, #336]
    8ae8:	a95773fb 	ldp	x27, x28, [sp, #368]
    8aec:	910603ff 	add	sp, sp, #0x180
    8af0:	d65f03c0 	ret
    8af4:	90ffffe0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    8af8:	91008000 	add	x0, x0, #0x20
    8afc:	94000221 	bl	9380 <atexit>
    8b00:	17fffd8f 	b	813c <fwp_main_thread+0x4c>
    8b04:	97ffeda0 	bl	4184 <fwp_heap_init>
    8b08:	17fffd8a 	b	8130 <fwp_main_thread+0x40>
    8b0c:	aa1c03e0 	mov	x0, x28
    8b10:	97fff311 	bl	5754 <fwp_rc_free_arr>
    8b14:	17ffff8f 	b	8950 <fwp_main_thread+0x860>
    8b18:	72003c3f 	tst	w1, #0xffff
    8b1c:	54ffe561 	b.ne	87c8 <fwp_main_thread+0x6d8>  // b.any
    8b20:	17ffff24 	b	87b0 <fwp_main_thread+0x6c0>
    8b24:	72003c5f 	tst	w2, #0xffff
    8b28:	54ffebc1 	b.ne	88a0 <fwp_main_thread+0x7b0>  // b.any
    8b2c:	17ffff59 	b	8890 <fwp_main_thread+0x7a0>
    8b30:	72003c5f 	tst	w2, #0xffff
    8b34:	54fff0e1 	b.ne	8950 <fwp_main_thread+0x860>  // b.any
    8b38:	17ffff7e 	b	8930 <fwp_main_thread+0x840>
    8b3c:	72003c3f 	tst	w1, #0xffff
    8b40:	54ffd601 	b.ne	8600 <fwp_main_thread+0x510>  // b.any
    8b44:	17fffeaa 	b	85ec <fwp_main_thread+0x4fc>
    8b48:	72003c3f 	tst	w1, #0xffff
    8b4c:	54ffdec1 	b.ne	8724 <fwp_main_thread+0x634>  // b.any
    8b50:	17fffef0 	b	8710 <fwp_main_thread+0x620>
    8b54:	72003c3f 	tst	w1, #0xffff
    8b58:	54ffd9c1 	b.ne	8690 <fwp_main_thread+0x5a0>  // b.any
    8b5c:	17fffec8 	b	867c <fwp_main_thread+0x58c>
    8b60:	f9000fe0 	str	x0, [sp, #24]
    8b64:	97ffef57 	bl	48c0 <fwp_rc_forget_slot>
    8b68:	f9400fe0 	ldr	x0, [sp, #24]
    8b6c:	17ffff4c 	b	889c <fwp_main_thread+0x7ac>
    8b70:	aa1c03e0 	mov	x0, x28
    8b74:	97ffef53 	bl	48c0 <fwp_rc_forget_slot>
    8b78:	17fffe57 	b	84d4 <fwp_main_thread+0x3e4>
    8b7c:	aa0003e1 	mov	x1, x0
    8b80:	f9002293 	str	x19, [x20, #64]
    8b84:	17fffdb6 	b	825c <fwp_main_thread+0x16c>
    8b88:	f941a280 	ldr	x0, [x20, #832]
    8b8c:	97ffefed 	bl	4b40 <fwp_mem_free>
    8b90:	f901a29f 	str	xzr, [x20, #832]
    8b94:	f901aa9f 	str	xzr, [x20, #848]
    8b98:	f941c280 	ldr	x0, [x20, #896]
    8b9c:	b4000433 	cbz	x19, 8c20 <fwp_main_thread+0xb30>
    8ba0:	f900567f 	str	xzr, [x19, #168]
    8ba4:	f9005e7f 	str	xzr, [x19, #184]
    8ba8:	b9037a9f 	str	wzr, [x20, #888]
    8bac:	eb13001f 	cmp	x0, x19
    8bb0:	54ffbb60 	b.eq	831c <fwp_main_thread+0x22c>  // b.none
    8bb4:	a9166bf9 	stp	x25, x26, [sp, #352]
    8bb8:	97ffe76a 	bl	2960 <abort@plt>
    8bbc:	97ffeefa 	bl	47a4 <fwp_rc_wide_dup>
    8bc0:	17ffff02 	b	87c8 <fwp_main_thread+0x6d8>
    8bc4:	ca404401 	eor	x1, x0, x0, lsr #17
    8bc8:	911782e2 	add	x2, x23, #0x5e0
    8bcc:	ca412421 	eor	x1, x1, x1, lsr #9
    8bd0:	8b210c41 	add	x1, x2, w1, uxtb #3
    8bd4:	f94a2421 	ldr	x1, [x1, #5192]
    8bd8:	b5000081 	cbnz	x1, 8be8 <fwp_main_thread+0xaf8>
    8bdc:	14000020 	b	8c5c <fwp_main_thread+0xb6c>
    8be0:	f9400821 	ldr	x1, [x1, #16]
    8be4:	b40003c1 	cbz	x1, 8c5c <fwp_main_thread+0xb6c>
    8be8:	f9400022 	ldr	x2, [x1]
    8bec:	eb02001f 	cmp	x0, x2
    8bf0:	54ffff81 	b.ne	8be0 <fwp_main_thread+0xaf0>  // b.any
    8bf4:	f9400422 	ldr	x2, [x1, #8]
    8bf8:	d1000442 	sub	x2, x2, #0x1
    8bfc:	f9000422 	str	x2, [x1, #8]
    8c00:	f103f85f 	cmp	x2, #0xfe
    8c04:	54ffea61 	b.ne	8950 <fwp_main_thread+0x860>  // b.any
    8c08:	f9000fe0 	str	x0, [sp, #24]
    8c0c:	97ffef2d 	bl	48c0 <fwp_rc_forget_slot>
    8c10:	f9400fe0 	ldr	x0, [sp, #24]
    8c14:	12800021 	mov	w1, #0xfffffffe            	// #-2
    8c18:	39000001 	strb	w1, [x0]
    8c1c:	17ffff4d 	b	8950 <fwp_main_thread+0x860>
    8c20:	b9037a9f 	str	wzr, [x20, #888]
    8c24:	b4ffeb80 	cbz	x0, 8994 <fwp_main_thread+0x8a4>
    8c28:	17ffffe3 	b	8bb4 <fwp_main_thread+0xac4>
    8c2c:	aa1403e0 	mov	x0, x20
    8c30:	97ffef24 	bl	48c0 <fwp_rc_forget_slot>
    8c34:	17fffe95 	b	8688 <fwp_main_thread+0x598>
    8c38:	aa1603e0 	mov	x0, x22
    8c3c:	97ffef21 	bl	48c0 <fwp_rc_forget_slot>
    8c40:	17fffeb7 	b	871c <fwp_main_thread+0x62c>
    8c44:	aa1603e0 	mov	x0, x22
    8c48:	97ffef1e 	bl	48c0 <fwp_rc_forget_slot>
    8c4c:	17fffe6b 	b	85f8 <fwp_main_thread+0x508>
    8c50:	b0000000 	adrp	x0, 9000 <__divti3+0x370>
    8c54:	9125e000 	add	x0, x0, #0x978
    8c58:	97ffeb0a 	bl	3880 <fwp_trap>
    8c5c:	b0000000 	adrp	x0, 9000 <__divti3+0x370>
    8c60:	911c4000 	add	x0, x0, #0x710
    8c64:	97ffeb07 	bl	3880 <fwp_trap>
    8c68:	b0000000 	adrp	x0, 9000 <__divti3+0x370>
    8c6c:	91254000 	add	x0, x0, #0x950
    8c70:	a9166bf9 	stp	x25, x26, [sp, #352]
    8c74:	97ffeb03 	bl	3880 <fwp_trap>
    8c78:	a9166bf9 	stp	x25, x26, [sp, #352]
    8c7c:	97ffe94d 	bl	31b0 <descent_phase_fail>
    8c80:	a9166bf9 	stp	x25, x26, [sp, #352]
    8c84:	97ffe723 	bl	2910 <__stack_chk_fail@plt>
    8c88:	d503201f 	nop
    8c8c:	d503201f 	nop

0000000000008c90 <__divti3>:
    8c90:	d503245f 	bti	c
    8c94:	d2800004 	mov	x4, #0x0                   	// #0
    8c98:	b7f80721 	tbnz	x1, #63, 8d7c <__divti3+0xec>
    8c9c:	b6f80083 	tbz	x3, #63, 8cac <__divti3+0x1c>
    8ca0:	eb0203e2 	negs	x2, x2
    8ca4:	aa2403e4 	mvn	x4, x4
    8ca8:	da0303e3 	ngc	x3, x3
    8cac:	aa0203e6 	mov	x6, x2
    8cb0:	aa0003e7 	mov	x7, x0
    8cb4:	aa0103e5 	mov	x5, x1
    8cb8:	b5000583 	cbnz	x3, 8d68 <__divti3+0xd8>
    8cbc:	eb01005f 	cmp	x2, x1
    8cc0:	54000e69 	b.ls	8e8c <__divti3+0x1fc>  // b.plast
    8cc4:	dac01040 	clz	x0, x2
    8cc8:	b40000e0 	cbz	x0, 8ce4 <__divti3+0x54>
    8ccc:	4b0003e1 	neg	w1, w0
    8cd0:	9ac020a5 	lsl	x5, x5, x0
    8cd4:	9ac02046 	lsl	x6, x2, x0
    8cd8:	9ac124e1 	lsr	x1, x7, x1
    8cdc:	aa050025 	orr	x5, x1, x5
    8ce0:	9ac020e7 	lsl	x7, x7, x0
    8ce4:	d360fcc8 	lsr	x8, x6, #32
    8ce8:	92407cc2 	and	x2, x6, #0xffffffff
    8cec:	9ac808a3 	udiv	x3, x5, x8
    8cf0:	9b089465 	msub	x5, x3, x8, x5
    8cf4:	aa0303e0 	mov	x0, x3
    8cf8:	9b037c41 	mul	x1, x2, x3
    8cfc:	93c780a5 	extr	x5, x5, x7, #32
    8d00:	eb05003f 	cmp	x1, x5
    8d04:	540000a9 	b.ls	8d18 <__divti3+0x88>  // b.plast
    8d08:	ab0500c5 	adds	x5, x6, x5
    8d0c:	d1000460 	sub	x0, x3, #0x1
    8d10:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8d14:	540015a8 	b.hi	8fc8 <__divti3+0x338>  // b.pmore
    8d18:	cb0100a5 	sub	x5, x5, x1
    8d1c:	9ac808a3 	udiv	x3, x5, x8
    8d20:	9b089465 	msub	x5, x3, x8, x5
    8d24:	aa0303e1 	mov	x1, x3
    8d28:	9b037c42 	mul	x2, x2, x3
    8d2c:	aa0703e3 	mov	x3, x7
    8d30:	b3607ca3 	bfi	x3, x5, #32, #32
    8d34:	eb03005f 	cmp	x2, x3
    8d38:	540000c9 	b.ls	8d50 <__divti3+0xc0>  // b.plast
    8d3c:	ab0300c3 	adds	x3, x6, x3
    8d40:	d1000425 	sub	x5, x1, #0x1
    8d44:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8d48:	d1000821 	sub	x1, x1, #0x2
    8d4c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8d50:	aa008020 	orr	x0, x1, x0, lsl #32
    8d54:	d2800001 	mov	x1, #0x0                   	// #0
    8d58:	b4000064 	cbz	x4, 8d64 <__divti3+0xd4>
    8d5c:	eb0003e0 	negs	x0, x0
    8d60:	da0103e1 	ngc	x1, x1
    8d64:	d65f03c0 	ret
    8d68:	eb01007f 	cmp	x3, x1
    8d6c:	54000109 	b.ls	8d8c <__divti3+0xfc>  // b.plast
    8d70:	d2800001 	mov	x1, #0x0                   	// #0
    8d74:	d2800000 	mov	x0, #0x0                   	// #0
    8d78:	17fffff8 	b	8d58 <__divti3+0xc8>
    8d7c:	eb0003e0 	negs	x0, x0
    8d80:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8d84:	da0103e1 	ngc	x1, x1
    8d88:	17ffffc5 	b	8c9c <__divti3+0xc>
    8d8c:	dac01067 	clz	x7, x3
    8d90:	b40010e7 	cbz	x7, 8fac <__divti3+0x31c>
    8d94:	d2800805 	mov	x5, #0x40                  	// #64
    8d98:	cb0700a5 	sub	x5, x5, x7
    8d9c:	9ac72063 	lsl	x3, x3, x7
    8da0:	9ac52448 	lsr	x8, x2, x5
    8da4:	aa030108 	orr	x8, x8, x3
    8da8:	9ac52426 	lsr	x6, x1, x5
    8dac:	92407d0a 	and	x10, x8, #0xffffffff
    8db0:	d360fd09 	lsr	x9, x8, #32
    8db4:	9ac52403 	lsr	x3, x0, x5
    8db8:	9ac72021 	lsl	x1, x1, x7
    8dbc:	aa010063 	orr	x3, x3, x1
    8dc0:	9ac72042 	lsl	x2, x2, x7
    8dc4:	9ac908cb 	udiv	x11, x6, x9
    8dc8:	9b099965 	msub	x5, x11, x9, x6
    8dcc:	aa0b03e1 	mov	x1, x11
    8dd0:	9b0b7d46 	mul	x6, x10, x11
    8dd4:	93c380a5 	extr	x5, x5, x3, #32
    8dd8:	eb0500df 	cmp	x6, x5
    8ddc:	540000a9 	b.ls	8df0 <__divti3+0x160>  // b.plast
    8de0:	ab050105 	adds	x5, x8, x5
    8de4:	d1000561 	sub	x1, x11, #0x1
    8de8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    8dec:	54000f48 	b.hi	8fd4 <__divti3+0x344>  // b.pmore
    8df0:	cb0600a6 	sub	x6, x5, x6
    8df4:	9ac908cb 	udiv	x11, x6, x9
    8df8:	9b099969 	msub	x9, x11, x9, x6
    8dfc:	aa0b03e5 	mov	x5, x11
    8e00:	9b0b7d4a 	mul	x10, x10, x11
    8e04:	b3607d23 	bfi	x3, x9, #32, #32
    8e08:	eb03015f 	cmp	x10, x3
    8e0c:	540000a9 	b.ls	8e20 <__divti3+0x190>  // b.plast
    8e10:	ab030103 	adds	x3, x8, x3
    8e14:	d1000565 	sub	x5, x11, #0x1
    8e18:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    8e1c:	54000e28 	b.hi	8fe0 <__divti3+0x350>  // b.pmore
    8e20:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8e24:	92407c48 	and	x8, x2, #0xffffffff
    8e28:	2a0503e5 	mov	w5, w5
    8e2c:	d360fc42 	lsr	x2, x2, #32
    8e30:	d360fc26 	lsr	x6, x1, #32
    8e34:	cb0a0063 	sub	x3, x3, x10
    8e38:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    8e3c:	9b087caa 	mul	x10, x5, x8
    8e40:	9b087cc8 	mul	x8, x6, x8
    8e44:	9b0220a5 	madd	x5, x5, x2, x8
    8e48:	9b027cc6 	mul	x6, x6, x2
    8e4c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8e50:	8b0900c5 	add	x5, x6, x9
    8e54:	eb02011f 	cmp	x8, x2
    8e58:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    8e5c:	8b4280c6 	add	x6, x6, x2, lsr #32
    8e60:	eb06007f 	cmp	x3, x6
    8e64:	540000e3 	b.cc	8e80 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    8e68:	92407d4a 	and	x10, x10, #0xffffffff
    8e6c:	9ac72000 	lsl	x0, x0, x7
    8e70:	8b028142 	add	x2, x10, x2, lsl #32
    8e74:	eb02001f 	cmp	x0, x2
    8e78:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    8e7c:	54000a01 	b.ne	8fbc <__divti3+0x32c>  // b.any
    8e80:	d1000420 	sub	x0, x1, #0x1
    8e84:	d2800001 	mov	x1, #0x0                   	// #0
    8e88:	17ffffb4 	b	8d58 <__divti3+0xc8>
    8e8c:	b5000062 	cbnz	x2, 8e98 <__divti3+0x208>
    8e90:	d2800022 	mov	x2, #0x1                   	// #1
    8e94:	9ac30846 	udiv	x6, x2, x3
    8e98:	dac010c8 	clz	x8, x6
    8e9c:	b5000408 	cbnz	x8, 8f1c <__divti3+0x28c>
    8ea0:	d360fcc9 	lsr	x9, x6, #32
    8ea4:	92407cc5 	and	x5, x6, #0xffffffff
    8ea8:	cb060023 	sub	x3, x1, x6
    8eac:	d2800021 	mov	x1, #0x1                   	// #1
    8eb0:	9ac90868 	udiv	x8, x3, x9
    8eb4:	9b098d03 	msub	x3, x8, x9, x3
    8eb8:	aa0803e0 	mov	x0, x8
    8ebc:	9b057d02 	mul	x2, x8, x5
    8ec0:	93c78063 	extr	x3, x3, x7, #32
    8ec4:	eb03005f 	cmp	x2, x3
    8ec8:	540000a9 	b.ls	8edc <__divti3+0x24c>  // b.plast
    8ecc:	ab0300c3 	adds	x3, x6, x3
    8ed0:	d1000500 	sub	x0, x8, #0x1
    8ed4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8ed8:	54000968 	b.hi	9004 <__divti3+0x374>  // b.pmore
    8edc:	cb020063 	sub	x3, x3, x2
    8ee0:	9ac90862 	udiv	x2, x3, x9
    8ee4:	aa0203e8 	mov	x8, x2
    8ee8:	9b098c42 	msub	x2, x2, x9, x3
    8eec:	aa0703e3 	mov	x3, x7
    8ef0:	9b057d05 	mul	x5, x8, x5
    8ef4:	b3607c43 	bfi	x3, x2, #32, #32
    8ef8:	eb0300bf 	cmp	x5, x3
    8efc:	540000c9 	b.ls	8f14 <__divti3+0x284>  // b.plast
    8f00:	ab0300c2 	adds	x2, x6, x3
    8f04:	d1000503 	sub	x3, x8, #0x1
    8f08:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    8f0c:	d1000908 	sub	x8, x8, #0x2
    8f10:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8f14:	aa008100 	orr	x0, x8, x0, lsl #32
    8f18:	17ffff90 	b	8d58 <__divti3+0xc8>
    8f1c:	9ac820c6 	lsl	x6, x6, x8
    8f20:	d2800803 	mov	x3, #0x40                  	// #64
    8f24:	cb080063 	sub	x3, x3, x8
    8f28:	d360fcc9 	lsr	x9, x6, #32
    8f2c:	9ac82027 	lsl	x7, x1, x8
    8f30:	92407cc5 	and	x5, x6, #0xffffffff
    8f34:	9ac32422 	lsr	x2, x1, x3
    8f38:	9ac32403 	lsr	x3, x0, x3
    8f3c:	aa070063 	orr	x3, x3, x7
    8f40:	9ac9084a 	udiv	x10, x2, x9
    8f44:	9ac82007 	lsl	x7, x0, x8
    8f48:	9b098940 	msub	x0, x10, x9, x2
    8f4c:	aa0a03e1 	mov	x1, x10
    8f50:	9b0a7ca2 	mul	x2, x5, x10
    8f54:	93c38000 	extr	x0, x0, x3, #32
    8f58:	eb00005f 	cmp	x2, x0
    8f5c:	540000a9 	b.ls	8f70 <__divti3+0x2e0>  // b.plast
    8f60:	ab0000c0 	adds	x0, x6, x0
    8f64:	d1000541 	sub	x1, x10, #0x1
    8f68:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    8f6c:	54000468 	b.hi	8ff8 <__divti3+0x368>  // b.pmore
    8f70:	cb020000 	sub	x0, x0, x2
    8f74:	9ac9080a 	udiv	x10, x0, x9
    8f78:	9b098140 	msub	x0, x10, x9, x0
    8f7c:	aa0a03e2 	mov	x2, x10
    8f80:	9b0a7ca8 	mul	x8, x5, x10
    8f84:	b3607c03 	bfi	x3, x0, #32, #32
    8f88:	eb03011f 	cmp	x8, x3
    8f8c:	540000a9 	b.ls	8fa0 <__divti3+0x310>  // b.plast
    8f90:	ab0300c3 	adds	x3, x6, x3
    8f94:	d1000542 	sub	x2, x10, #0x1
    8f98:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    8f9c:	54000288 	b.hi	8fec <__divti3+0x35c>  // b.pmore
    8fa0:	cb080063 	sub	x3, x3, x8
    8fa4:	aa018041 	orr	x1, x2, x1, lsl #32
    8fa8:	17ffffc2 	b	8eb0 <__divti3+0x220>
    8fac:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    8fb0:	d2800001 	mov	x1, #0x0                   	// #0
    8fb4:	9a9f87e0 	cset	x0, ls	// ls = plast
    8fb8:	17ffff68 	b	8d58 <__divti3+0xc8>
    8fbc:	aa0103e0 	mov	x0, x1
    8fc0:	d2800001 	mov	x1, #0x0                   	// #0
    8fc4:	17ffff65 	b	8d58 <__divti3+0xc8>
    8fc8:	d1000860 	sub	x0, x3, #0x2
    8fcc:	8b0600a5 	add	x5, x5, x6
    8fd0:	17ffff52 	b	8d18 <__divti3+0x88>
    8fd4:	d1000961 	sub	x1, x11, #0x2
    8fd8:	8b0800a5 	add	x5, x5, x8
    8fdc:	17ffff85 	b	8df0 <__divti3+0x160>
    8fe0:	d1000965 	sub	x5, x11, #0x2
    8fe4:	8b080063 	add	x3, x3, x8
    8fe8:	17ffff8e 	b	8e20 <__divti3+0x190>
    8fec:	d1000942 	sub	x2, x10, #0x2
    8ff0:	8b060063 	add	x3, x3, x6
    8ff4:	17ffffeb 	b	8fa0 <__divti3+0x310>
    8ff8:	d1000941 	sub	x1, x10, #0x2
    8ffc:	8b060000 	add	x0, x0, x6
    9000:	17ffffdc 	b	8f70 <__divti3+0x2e0>
    9004:	d1000900 	sub	x0, x8, #0x2
    9008:	8b060063 	add	x3, x3, x6
    900c:	17ffffb4 	b	8edc <__divti3+0x24c>

0000000000009010 <__modti3>:
    9010:	d503245f 	bti	c
    9014:	d2800004 	mov	x4, #0x0                   	// #0
    9018:	b6f80081 	tbz	x1, #63, 9028 <__modti3+0x18>
    901c:	eb0003e0 	negs	x0, x0
    9020:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9024:	da0103e1 	ngc	x1, x1
    9028:	f100007f 	cmp	x3, #0x0
    902c:	5400128b 	b.lt	927c <__modti3+0x26c>  // b.tstop
    9030:	aa0003e7 	mov	x7, x0
    9034:	aa0103e6 	mov	x6, x1
    9038:	540004e1 	b.ne	90d4 <__modti3+0xc4>  // b.any
    903c:	eb02003f 	cmp	x1, x2
    9040:	54000dc2 	b.cs	91f8 <__modti3+0x1e8>  // b.hs, b.nlast
    9044:	dac01043 	clz	x3, x2
    9048:	aa0303e5 	mov	x5, x3
    904c:	b40000e3 	cbz	x3, 9068 <__modti3+0x58>
    9050:	4b0303e6 	neg	w6, w3
    9054:	9ac32021 	lsl	x1, x1, x3
    9058:	9ac32042 	lsl	x2, x2, x3
    905c:	9ac62406 	lsr	x6, x0, x6
    9060:	aa0100c6 	orr	x6, x6, x1
    9064:	9ac32007 	lsl	x7, x0, x3
    9068:	d360fc40 	lsr	x0, x2, #32
    906c:	92407c43 	and	x3, x2, #0xffffffff
    9070:	9ac008c1 	udiv	x1, x6, x0
    9074:	9b009826 	msub	x6, x1, x0, x6
    9078:	9b017c61 	mul	x1, x3, x1
    907c:	93c780c6 	extr	x6, x6, x7, #32
    9080:	eb06003f 	cmp	x1, x6
    9084:	540000a9 	b.ls	9098 <__modti3+0x88>  // b.plast
    9088:	ab060046 	adds	x6, x2, x6
    908c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9090:	8b0200c8 	add	x8, x6, x2
    9094:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9098:	cb0100c6 	sub	x6, x6, x1
    909c:	9ac008c8 	udiv	x8, x6, x0
    90a0:	9b009901 	msub	x1, x8, x0, x6
    90a4:	aa0703e0 	mov	x0, x7
    90a8:	9b087c63 	mul	x3, x3, x8
    90ac:	b3607c20 	bfi	x0, x1, #32, #32
    90b0:	eb00007f 	cmp	x3, x0
    90b4:	54001088 	b.hi	92c4 <__modti3+0x2b4>  // b.pmore
    90b8:	cb030000 	sub	x0, x0, x3
    90bc:	9ac52400 	lsr	x0, x0, x5
    90c0:	d2800001 	mov	x1, #0x0                   	// #0
    90c4:	b4000064 	cbz	x4, 90d0 <__modti3+0xc0>
    90c8:	eb0003e0 	negs	x0, x0
    90cc:	da0103e1 	ngc	x1, x1
    90d0:	d65f03c0 	ret
    90d4:	dac01066 	clz	x6, x3
    90d8:	eb03003f 	cmp	x1, x3
    90dc:	54ffff43 	b.cc	90c4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    90e0:	93407cc5 	sxtw	x5, w6
    90e4:	d2800808 	mov	x8, #0x40                  	// #64
    90e8:	cb050108 	sub	x8, x8, x5
    90ec:	9ac62063 	lsl	x3, x3, x6
    90f0:	9ac62025 	lsl	x5, x1, x6
    90f4:	9ac82447 	lsr	x7, x2, x8
    90f8:	aa0300e7 	orr	x7, x7, x3
    90fc:	9ac82423 	lsr	x3, x1, x8
    9100:	92407cec 	and	x12, x7, #0xffffffff
    9104:	d360fcea 	lsr	x10, x7, #32
    9108:	9ac82401 	lsr	x1, x0, x8
    910c:	aa050021 	orr	x1, x1, x5
    9110:	9ac62042 	lsl	x2, x2, x6
    9114:	9ac62000 	lsl	x0, x0, x6
    9118:	9aca086b 	udiv	x11, x3, x10
    911c:	9b0a8d63 	msub	x3, x11, x10, x3
    9120:	aa0b03e5 	mov	x5, x11
    9124:	9b0b7d89 	mul	x9, x12, x11
    9128:	93c18063 	extr	x3, x3, x1, #32
    912c:	eb03013f 	cmp	x9, x3
    9130:	540000a9 	b.ls	9144 <__modti3+0x134>  // b.plast
    9134:	ab0300e3 	adds	x3, x7, x3
    9138:	d1000565 	sub	x5, x11, #0x1
    913c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    9140:	54001168 	b.hi	936c <__modti3+0x35c>  // b.pmore
    9144:	cb090063 	sub	x3, x3, x9
    9148:	9aca086b 	udiv	x11, x3, x10
    914c:	9b0a8d6a 	msub	x10, x11, x10, x3
    9150:	aa0b03e9 	mov	x9, x11
    9154:	9b0b7d8c 	mul	x12, x12, x11
    9158:	b3607d41 	bfi	x1, x10, #32, #32
    915c:	eb01019f 	cmp	x12, x1
    9160:	540000a9 	b.ls	9174 <__modti3+0x164>  // b.plast
    9164:	ab0100e1 	adds	x1, x7, x1
    9168:	d1000569 	sub	x9, x11, #0x1
    916c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9170:	54000f88 	b.hi	9360 <__modti3+0x350>  // b.pmore
    9174:	aa058123 	orr	x3, x9, x5, lsl #32
    9178:	92407c4b 	and	x11, x2, #0xffffffff
    917c:	2a0903e9 	mov	w9, w9
    9180:	d360fc4a 	lsr	x10, x2, #32
    9184:	d360fc63 	lsr	x3, x3, #32
    9188:	cb0c0021 	sub	x1, x1, x12
    918c:	aa0a03ec 	mov	x12, x10
    9190:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9194:	9b0b7d25 	mul	x5, x9, x11
    9198:	9b0b7c6b 	mul	x11, x3, x11
    919c:	9b0a2d29 	madd	x9, x9, x10, x11
    91a0:	92407caa 	and	x10, x5, #0xffffffff
    91a4:	9b0c7c63 	mul	x3, x3, x12
    91a8:	8b458125 	add	x5, x9, x5, lsr #32
    91ac:	8b0d0069 	add	x9, x3, x13
    91b0:	eb05017f 	cmp	x11, x5
    91b4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    91b8:	8b058149 	add	x9, x10, x5, lsl #32
    91bc:	8b458063 	add	x3, x3, x5, lsr #32
    91c0:	eb03003f 	cmp	x1, x3
    91c4:	54000063 	b.cc	91d0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    91c8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    91cc:	54000082 	b.cs	91dc <__modti3+0x1cc>  // b.hs, b.nlast
    91d0:	eb020129 	subs	x9, x9, x2
    91d4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    91d8:	cb070063 	sub	x3, x3, x7
    91dc:	eb090000 	subs	x0, x0, x9
    91e0:	da030021 	sbc	x1, x1, x3
    91e4:	9ac62400 	lsr	x0, x0, x6
    91e8:	9ac82028 	lsl	x8, x1, x8
    91ec:	aa000100 	orr	x0, x8, x0
    91f0:	9ac62421 	lsr	x1, x1, x6
    91f4:	17ffffb4 	b	90c4 <__modti3+0xb4>
    91f8:	b5000062 	cbnz	x2, 9204 <__modti3+0x1f4>
    91fc:	d2800023 	mov	x3, #0x1                   	// #1
    9200:	9ac20862 	udiv	x2, x3, x2
    9204:	dac01048 	clz	x8, x2
    9208:	aa0803e5 	mov	x5, x8
    920c:	b5000668 	cbnz	x8, 92d8 <__modti3+0x2c8>
    9210:	cb020020 	sub	x0, x1, x2
    9214:	d360fc49 	lsr	x9, x2, #32
    9218:	92407c4a 	and	x10, x2, #0xffffffff
    921c:	9ac90801 	udiv	x1, x0, x9
    9220:	9b098020 	msub	x0, x1, x9, x0
    9224:	9b0a7c21 	mul	x1, x1, x10
    9228:	93c78000 	extr	x0, x0, x7, #32
    922c:	eb00003f 	cmp	x1, x0
    9230:	540000a9 	b.ls	9244 <__modti3+0x234>  // b.plast
    9234:	ab000040 	adds	x0, x2, x0
    9238:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    923c:	8b020003 	add	x3, x0, x2
    9240:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9244:	cb010001 	sub	x1, x0, x1
    9248:	9ac90820 	udiv	x0, x1, x9
    924c:	9b098403 	msub	x3, x0, x9, x1
    9250:	aa0703e1 	mov	x1, x7
    9254:	9b0a7c00 	mul	x0, x0, x10
    9258:	b3607c61 	bfi	x1, x3, #32, #32
    925c:	eb01001f 	cmp	x0, x1
    9260:	540000a9 	b.ls	9274 <__modti3+0x264>  // b.plast
    9264:	ab010041 	adds	x1, x2, x1
    9268:	8b020022 	add	x2, x1, x2
    926c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9270:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9274:	cb000020 	sub	x0, x1, x0
    9278:	17ffff91 	b	90bc <__modti3+0xac>
    927c:	eb0203e5 	negs	x5, x2
    9280:	aa0003e7 	mov	x7, x0
    9284:	da0303e8 	ngc	x8, x3
    9288:	aa0503e2 	mov	x2, x5
    928c:	aa0803e3 	mov	x3, x8
    9290:	aa0103e6 	mov	x6, x1
    9294:	b4ffed48 	cbz	x8, 903c <__modti3+0x2c>
    9298:	eb01011f 	cmp	x8, x1
    929c:	54fff148 	b.hi	90c4 <__modti3+0xb4>  // b.pmore
    92a0:	dac01109 	clz	x9, x8
    92a4:	2a0903e6 	mov	w6, w9
    92a8:	b5fff1c9 	cbnz	x9, 90e0 <__modti3+0xd0>
    92ac:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    92b0:	54000068 	b.hi	92bc <__modti3+0x2ac>  // b.pmore
    92b4:	eb050007 	subs	x7, x0, x5
    92b8:	da080021 	sbc	x1, x1, x8
    92bc:	aa0703e0 	mov	x0, x7
    92c0:	17ffff81 	b	90c4 <__modti3+0xb4>
    92c4:	ab000040 	adds	x0, x2, x0
    92c8:	8b020002 	add	x2, x0, x2
    92cc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    92d0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    92d4:	17ffff79 	b	90b8 <__modti3+0xa8>
    92d8:	9ac82042 	lsl	x2, x2, x8
    92dc:	d2800803 	mov	x3, #0x40                  	// #64
    92e0:	cb080063 	sub	x3, x3, x8
    92e4:	d360fc49 	lsr	x9, x2, #32
    92e8:	9ac82027 	lsl	x7, x1, x8
    92ec:	92407c4a 	and	x10, x2, #0xffffffff
    92f0:	9ac32426 	lsr	x6, x1, x3
    92f4:	9ac32403 	lsr	x3, x0, x3
    92f8:	aa070063 	orr	x3, x3, x7
    92fc:	9ac908c1 	udiv	x1, x6, x9
    9300:	9ac82007 	lsl	x7, x0, x8
    9304:	9b099820 	msub	x0, x1, x9, x6
    9308:	9b017d41 	mul	x1, x10, x1
    930c:	93c38000 	extr	x0, x0, x3, #32
    9310:	eb00003f 	cmp	x1, x0
    9314:	540000a9 	b.ls	9328 <__modti3+0x318>  // b.plast
    9318:	ab000040 	adds	x0, x2, x0
    931c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9320:	8b020006 	add	x6, x0, x2
    9324:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    9328:	cb010000 	sub	x0, x0, x1
    932c:	9ac90801 	udiv	x1, x0, x9
    9330:	9b098026 	msub	x6, x1, x9, x0
    9334:	aa0303e0 	mov	x0, x3
    9338:	9b017d41 	mul	x1, x10, x1
    933c:	b3607cc0 	bfi	x0, x6, #32, #32
    9340:	eb00003f 	cmp	x1, x0
    9344:	540000a9 	b.ls	9358 <__modti3+0x348>  // b.plast
    9348:	ab000040 	adds	x0, x2, x0
    934c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9350:	8b020003 	add	x3, x0, x2
    9354:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9358:	cb010000 	sub	x0, x0, x1
    935c:	17ffffb0 	b	921c <__modti3+0x20c>
    9360:	d1000969 	sub	x9, x11, #0x2
    9364:	8b070021 	add	x1, x1, x7
    9368:	17ffff83 	b	9174 <__modti3+0x164>
    936c:	d1000965 	sub	x5, x11, #0x2
    9370:	8b070063 	add	x3, x3, x7
    9374:	17ffff74 	b	9144 <__modti3+0x134>
    9378:	d503201f 	nop
    937c:	d503201f 	nop

0000000000009380 <atexit>:
    9380:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9384:	f00000a2 	adrp	x2, 20000 <__data_start>
    9388:	d2800001 	mov	x1, #0x0                   	// #0
    938c:	910003fd 	mov	x29, sp
    9390:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9394:	f9400442 	ldr	x2, [x2, #8]
    9398:	17ffe51e 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000939c <_fini>:
    939c:	d503201f 	nop
    93a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    93a4:	910003fd 	mov	x29, sp
    93a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    93ac:	d65f03c0 	ret
