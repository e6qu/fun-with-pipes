
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000025 	adrp	x5, 9000 <__modti3+0xe0>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	9115e0a5 	add	x5, x5, #0x578
    2b20:	f0000024 	adrp	x4, 9000 <__modti3+0xe0>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	91160084 	add	x4, x4, #0x580
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	91018261 	add	x1, x19, #0x60
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x12d80>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	f0000020 	adrp	x0, 9000 <__modti3+0xe0>
    2bb4:	91228000 	add	x0, x0, #0x8a0
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000022 	adrp	x2, 8000 <fwp_main_thread>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	91000042 	add	x2, x2, #0x0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	91018273 	add	x19, x19, #0x60
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435a60 	ldr	w0, [x19, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	f0000020 	adrp	x0, 9000 <__modti3+0xe0>
    2cfc:	9122c000 	add	x0, x0, #0x8b0
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	f0000020 	adrp	x0, 9000 <__modti3+0xe0>
    2d0c:	91254000 	add	x0, x0, #0x950
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	f0000020 	adrp	x0, 9000 <__modti3+0xe0>
    2d24:	9124a000 	add	x0, x0, #0x928
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	f0000020 	adrp	x0, 9000 <__modti3+0xe0>
    2d30:	9123e000 	add	x0, x0, #0x8f8
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	f0000020 	adrp	x0, 9000 <__modti3+0xe0>
    2d3c:	91234000 	add	x0, x0, #0x8d0
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91014000 	add	x0, x0, #0x50
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91014021 	add	x1, x1, #0x50
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91014000 	add	x0, x0, #0x50
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91014021 	add	x1, x1, #0x50
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39414260 	ldrb	w0, [x19, #80]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39014260 	strb	w0, [x19, #80]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	f0000021 	adrp	x1, 9000 <__modti3+0xe0>
    2f34:	913f4021 	add	x1, x1, #0xfd0
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403084 	ldr	x4, [x4, #96]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403063 	ldr	x3, [x3, #96]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403400 	ldr	x0, [x0, #104]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    30d0:	910b2000 	add	x0, x0, #0x2c8
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	91018043 	add	x3, x2, #0x60
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	91018042 	add	x2, x2, #0x60
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	d0000021 	adrp	x1, 9000 <__modti3+0xe0>
    3198:	913ec021 	add	x1, x1, #0xfb0
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    31d0:	910b8000 	add	x0, x0, #0x2e0
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	91018294 	add	x20, x20, #0x60
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	d0000022 	adrp	x2, 9000 <__modti3+0xe0>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	d0000036 	adrp	x22, 9000 <__modti3+0xe0>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	d0000038 	adrp	x24, 9000 <__modti3+0xe0>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	910ca042 	add	x2, x2, #0x328
    3260:	910e02d6 	add	x22, x22, #0x380
    3264:	91356318 	add	x24, x24, #0xd58
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	d0000039 	adrp	x25, 9000 <__modti3+0xe0>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	910de323 	add	x3, x25, #0x378
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	910e4000 	add	x0, x0, #0x390
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    3344:	911702a1 	add	x1, x21, #0x5c0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    3358:	9126c0a5 	add	x5, x5, #0x9b0
    335c:	911702a1 	add	x1, x21, #0x5c0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911702b7 	add	x23, x21, #0x5c0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911702b5 	add	x21, x21, #0x5c0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911702b5 	add	x21, x21, #0x5c0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    34e8:	9126a0a5 	add	x5, x5, #0x9a8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    35f0:	910b2000 	add	x0, x0, #0x2c8
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	91018022 	add	x2, x1, #0x60
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	91018023 	add	x3, x1, #0x60
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	91018021 	add	x1, x1, #0x60
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	91018022 	add	x2, x1, #0x60
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	91018021 	add	x1, x1, #0x60
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	d0000021 	adrp	x1, 9000 <__modti3+0xe0>
    3830:	aa1303e0 	mov	x0, x19
    3834:	910e6021 	add	x1, x1, #0x398
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000021 	adrp	x1, 9000 <__modti3+0xe0>
    3844:	aa1303e0 	mov	x0, x19
    3848:	910e8021 	add	x1, x1, #0x3a0
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000021 	adrp	x1, 9000 <__modti3+0xe0>
    3860:	910ea021 	add	x1, x1, #0x3a8
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	d0000022 	adrp	x2, 9000 <__modti3+0xe0>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	910ec042 	add	x2, x2, #0x3b0
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    39d0:	910b2000 	add	x0, x0, #0x2c8
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    39f0:	910f0000 	add	x0, x0, #0x3c0
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    3a88:	910f8000 	add	x0, x0, #0x3e0
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    3a98:	91100000 	add	x0, x0, #0x400
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	d0000021 	adrp	x1, 9000 <__modti3+0xe0>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc3f820 	ldr	q0, [x1, #4064]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	910182b5 	add	x21, x21, #0x60
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    3b98:	9110a000 	add	x0, x0, #0x428
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	91018062 	add	x2, x3, #0x60
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403063 	ldr	x3, [x3, #96]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	d0000020 	adrp	x0, 9000 <__modti3+0xe0>
    3c08:	91116000 	add	x0, x0, #0x458
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	d0000024 	adrp	x4, 9000 <__modti3+0xe0>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	9112a084 	add	x4, x4, #0x4a8
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	d0000024 	adrp	x4, 9000 <__modti3+0xe0>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	91130084 	add	x4, x4, #0x4c0
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	d0000024 	adrp	x4, 9000 <__modti3+0xe0>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	9112c084 	add	x4, x4, #0x4b0
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    4028:	91170042 	add	x2, x2, #0x5c0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	b0000021 	adrp	x1, 9000 <__modti3+0xe0>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	91132021 	add	x1, x1, #0x4c8
    4084:	91134000 	add	x0, x0, #0x4d0
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	b0000022 	adrp	x2, 9000 <__modti3+0xe0>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	9113c042 	add	x2, x2, #0x4f0
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa40>
    418c:	91130061 	add	x1, x3, #0x4c0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    419c:	91170262 	add	x2, x19, #0x5c0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	b0000022 	adrp	x2, 9000 <__modti3+0xe0>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa40>
    41cc:	91140021 	add	x1, x1, #0x500
    41d0:	3dc3fc43 	ldr	q3, [x2, #4080]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa40>
    41fc:	91130063 	add	x3, x3, #0x4c0
    4200:	91158084 	add	x4, x4, #0x560
    4204:	91170266 	add	x6, x19, #0x5c0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	91170275 	add	x21, x19, #0x5c0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    42e8:	91168000 	add	x0, x0, #0x5a0
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	91170273 	add	x19, x19, #0x5c0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <fwp_wake_io>:
    4344:	900000e9 	adrp	x9, 20000 <__data_start>
    4348:	91018122 	add	x2, x9, #0x60
    434c:	f9400001 	ldr	x1, [x0]
    4350:	5280000a 	mov	w10, #0x0                   	// #0
    4354:	f9403c46 	ldr	x6, [x2, #120]
    4358:	52800008 	mov	w8, #0x0                   	// #0
    435c:	4f000400 	movi	v0.4s, #0x0
    4360:	52800027 	mov	w7, #0x1                   	// #1
    4364:	aa0103e2 	mov	x2, x1
    4368:	b4000321 	cbz	x1, 43cc <fwp_wake_io+0x88>
    436c:	f9408c25 	ldr	x5, [x1, #280]
    4370:	39015c27 	strb	w7, [x1, #87]
    4374:	b4000165 	cbz	x5, 43a0 <fwp_wake_io+0x5c>
    4378:	a9520c24 	ldp	x4, x3, [x1, #288]
    437c:	b4000364 	cbz	x4, 43e8 <fwp_wake_io+0xa4>
    4380:	f9009483 	str	x3, [x4, #296]
    4384:	f9409423 	ldr	x3, [x1, #296]
    4388:	b4000043 	cbz	x3, 4390 <fwp_wake_io+0x4c>
    438c:	f9009064 	str	x4, [x3, #288]
    4390:	91080023 	add	x3, x1, #0x200
    4394:	f900943f 	str	xzr, [x1, #296]
    4398:	3c918060 	stur	q0, [x3, #-232]
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	f9402843 	ldr	x3, [x2, #80]
    43a4:	f2001c7f 	tst	x3, #0xff000000ff
    43a8:	54fffde1 	b.ne	4364 <fwp_wake_io+0x20>  // b.any
    43ac:	39015047 	strb	w7, [x2, #84]
    43b0:	f900805f 	str	xzr, [x2, #256]
    43b4:	b40001e6 	cbz	x6, 43f0 <fwp_wake_io+0xac>
    43b8:	f90080c2 	str	x2, [x6, #256]
    43bc:	aa0203e6 	mov	x6, x2
    43c0:	52800028 	mov	w8, #0x1                   	// #1
    43c4:	aa0103e2 	mov	x2, x1
    43c8:	b5fffd21 	cbnz	x1, 436c <fwp_wake_io+0x28>
    43cc:	3400006a 	cbz	w10, 43d8 <fwp_wake_io+0x94>
    43d0:	91018120 	add	x0, x9, #0x60
    43d4:	f900400b 	str	x11, [x0, #128]
    43d8:	34000068 	cbz	w8, 43e4 <fwp_wake_io+0xa0>
    43dc:	91018129 	add	x9, x9, #0x60
    43e0:	f9003d26 	str	x6, [x9, #120]
    43e4:	d65f03c0 	ret
    43e8:	f90000a3 	str	x3, [x5]
    43ec:	17ffffe7 	b	4388 <fwp_wake_io+0x44>
    43f0:	aa0203eb 	mov	x11, x2
    43f4:	5280002a 	mov	w10, #0x1                   	// #1
    43f8:	17fffff1 	b	43bc <fwp_wake_io+0x78>
    43fc:	d503201f 	nop

0000000000004400 <fwp_tape_buffers_release>:
    4400:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	f9401400 	ldr	x0, [x0, #40]
    4414:	b7f80760 	tbnz	x0, #63, 4500 <fwp_tape_buffers_release+0x100>
    4418:	f9401a61 	ldr	x1, [x19, #48]
    441c:	b7f80301 	tbnz	x1, #63, 447c <fwp_tape_buffers_release+0x7c>
    4420:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4424:	eb02001f 	cmp	x0, x2
    4428:	540002a8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    442c:	8b000400 	add	x0, x0, x0, lsl #1
    4430:	d2a00102 	mov	x2, #0x80000               	// #524288
    4434:	d37df000 	lsl	x0, x0, #3
    4438:	cb000042 	sub	x2, x2, x0
    443c:	eb420c3f 	cmp	x1, x2, lsr #3
    4440:	540001e8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4444:	8b010c14 	add	x20, x0, x1, lsl #3
    4448:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    444c:	9116c000 	add	x0, x0, #0x5b0
    4450:	97fff994 	bl	2aa0 <getenv@plt>
    4454:	b4000240 	cbz	x0, 449c <fwp_tape_buffers_release+0x9c>
    4458:	39400001 	ldrb	w1, [x0]
    445c:	7100c03f 	cmp	w1, #0x30
    4460:	540001e1 	b.ne	449c <fwp_tape_buffers_release+0x9c>  // b.any
    4464:	39400400 	ldrb	w0, [x0, #1]
    4468:	350001a0 	cbnz	w0, 449c <fwp_tape_buffers_release+0x9c>
    446c:	aa1303e0 	mov	x0, x19
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4478:	17fffc22 	b	3500 <fwp_tape_buffers_dispose>
    447c:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    4480:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4484:	9116c000 	add	x0, x0, #0x5b0
    4488:	97fff986 	bl	2aa0 <getenv@plt>
    448c:	b4ffff00 	cbz	x0, 446c <fwp_tape_buffers_release+0x6c>
    4490:	39400001 	ldrb	w1, [x0]
    4494:	7100c03f 	cmp	w1, #0x30
    4498:	54fffe60 	b.eq	4464 <fwp_tape_buffers_release+0x64>  // b.none
    449c:	d1000681 	sub	x1, x20, #0x1
    44a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44a4:	eb00003f 	cmp	x1, x0
    44a8:	54fffe28 	b.hi	446c <fwp_tape_buffers_release+0x6c>  // b.pmore
    44ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    44b0:	900000f6 	adrp	x22, 20000 <__data_start>
    44b4:	910182d6 	add	x22, x22, #0x60
    44b8:	910262d5 	add	x21, x22, #0x98
    44bc:	aa1503e0 	mov	x0, x21
    44c0:	97fffc10 	bl	3500 <fwp_tape_buffers_dispose>
    44c4:	ad400a61 	ldp	q1, q2, [x19]
    44c8:	f9006ad4 	str	x20, [x22, #208]
    44cc:	4f000400 	movi	v0.4s, #0x0
    44d0:	ad000aa1 	stp	q1, q2, [x21]
    44d4:	3dc00a61 	ldr	q1, [x19, #32]
    44d8:	3d800aa1 	str	q1, [x21, #32]
    44dc:	f9401a60 	ldr	x0, [x19, #48]
    44e0:	f9001aa0 	str	x0, [x21, #48]
    44e4:	f9001a7f 	str	xzr, [x19, #48]
    44e8:	ad000260 	stp	q0, q0, [x19]
    44ec:	3d800a60 	str	q0, [x19, #32]
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44fc:	d65f03c0 	ret
    4500:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    4504:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4508:	9116c000 	add	x0, x0, #0x5b0
    450c:	97fff965 	bl	2aa0 <getenv@plt>
    4510:	b5fffa40 	cbnz	x0, 4458 <fwp_tape_buffers_release+0x58>
    4514:	17ffffd6 	b	446c <fwp_tape_buffers_release+0x6c>
    4518:	d503201f 	nop
    451c:	d503201f 	nop

0000000000004520 <fwp_poll_events>:
    4520:	d10103ff 	sub	sp, sp, #0x40
    4524:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4528:	f947f400 	ldr	x0, [x0, #4072]
    452c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4530:	910083fd 	add	x29, sp, #0x20
    4534:	a90353f3 	stp	x19, x20, [sp, #48]
    4538:	900000f4 	adrp	x20, 20000 <__data_start>
    453c:	f9400001 	ldr	x1, [x0]
    4540:	f9000fe1 	str	x1, [sp, #24]
    4544:	d2800001 	mov	x1, #0x0                   	// #0
    4548:	97fffd2e 	bl	3a00 <fwp_now_ns>
    454c:	91018281 	add	x1, x20, #0x60
    4550:	f9406c33 	ldr	x19, [x1, #216]
    4554:	b4000e93 	cbz	x19, 4724 <fwp_poll_events+0x204>
    4558:	aa1303e1 	mov	x1, x19
    455c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4560:	14000005 	b	4574 <fwp_poll_events+0x54>
    4564:	f9408821 	ldr	x1, [x1, #272]
    4568:	eb03005f 	cmp	x2, x3
    456c:	9a83d042 	csel	x2, x2, x3, le
    4570:	b40000c1 	cbz	x1, 4588 <fwp_poll_events+0x68>
    4574:	f9403423 	ldr	x3, [x1, #104]
    4578:	b6ffff62 	tbz	x2, #63, 4564 <fwp_poll_events+0x44>
    457c:	f9408821 	ldr	x1, [x1, #272]
    4580:	aa0303e2 	mov	x2, x3
    4584:	b5ffff81 	cbnz	x1, 4574 <fwp_poll_events+0x54>
    4588:	b7f80ce2 	tbnz	x2, #63, 4724 <fwp_poll_events+0x204>
    458c:	cb000042 	sub	x2, x2, x0
    4590:	f100005f 	cmp	x2, #0x0
    4594:	540005cd 	b.le	464c <fwp_poll_events+0x12c>
    4598:	d2869b60 	mov	x0, #0x34db                	// #13531
    459c:	d2884801 	mov	x1, #0x4240                	// #16960
    45a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    45b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    45b4:	9b407c40 	smulh	x0, x2, x0
    45b8:	9352fc00 	asr	x0, x0, #18
    45bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    45c0:	9b018802 	msub	x2, x0, x1, x2
    45c4:	f100005f 	cmp	x2, #0x0
    45c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    45cc:	eb03001f 	cmp	x0, x3
    45d0:	54000a0c 	b.gt	4710 <fwp_poll_events+0x1f0>
    45d4:	340003c0 	cbz	w0, 464c <fwp_poll_events+0x12c>
    45d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    45dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    45e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    45e4:	9ba27c02 	umull	x2, w0, w2
    45e8:	d366fc43 	lsr	x3, x2, #38
    45ec:	aa0303e2 	mov	x2, x3
    45f0:	1b048063 	msub	w3, w3, w4, w0
    45f4:	9b217c63 	smull	x3, w3, w1
    45f8:	d2800001 	mov	x1, #0x0                   	// #0
    45fc:	910023e0 	add	x0, sp, #0x8
    4600:	a9008fe2 	stp	x2, x3, [sp, #8]
    4604:	97fff8f7 	bl	29e0 <nanosleep@plt>
    4608:	91018280 	add	x0, x20, #0x60
    460c:	f9406c13 	ldr	x19, [x0, #216]
    4610:	97fffcfc 	bl	3a00 <fwp_now_ns>
    4614:	aa0003e6 	mov	x6, x0
    4618:	b50001f3 	cbnz	x19, 4654 <fwp_poll_events+0x134>
    461c:	d503201f 	nop
    4620:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4624:	f947f400 	ldr	x0, [x0, #4072]
    4628:	f9400fe2 	ldr	x2, [sp, #24]
    462c:	f9400001 	ldr	x1, [x0]
    4630:	eb010042 	subs	x2, x2, x1
    4634:	d2800001 	mov	x1, #0x0                   	// #0
    4638:	540008c1 	b.ne	4750 <fwp_poll_events+0x230>  // b.any
    463c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4640:	a94353f3 	ldp	x19, x20, [sp, #48]
    4644:	910103ff 	add	sp, sp, #0x40
    4648:	d65f03c0 	ret
    464c:	97fffced 	bl	3a00 <fwp_now_ns>
    4650:	aa0003e6 	mov	x6, x0
    4654:	4f000400 	movi	v0.4s, #0x0
    4658:	91018288 	add	x8, x20, #0x60
    465c:	52800027 	mov	w7, #0x1                   	// #1
    4660:	f9403661 	ldr	x1, [x19, #104]
    4664:	aa1303e5 	mov	x5, x19
    4668:	f9408a73 	ldr	x19, [x19, #272]
    466c:	eb06003f 	cmp	x1, x6
    4670:	5400032c 	b.gt	46d4 <fwp_poll_events+0x1b4>
    4674:	394154a0 	ldrb	w0, [x5, #85]
    4678:	36000120 	tbz	w0, #0, 469c <fwp_poll_events+0x17c>
    467c:	f94084a0 	ldr	x0, [x5, #264]
    4680:	b40003c0 	cbz	x0, 46f8 <fwp_poll_events+0x1d8>
    4684:	f9008813 	str	x19, [x0, #272]
    4688:	b4000053 	cbz	x19, 4690 <fwp_poll_events+0x170>
    468c:	f9008660 	str	x0, [x19, #264]
    4690:	910800a0 	add	x0, x5, #0x200
    4694:	390154bf 	strb	wzr, [x5, #85]
    4698:	3c908000 	stur	q0, [x0, #-248]
    469c:	f94030a0 	ldr	x0, [x5, #96]
    46a0:	390158a7 	strb	w7, [x5, #86]
    46a4:	f100001f 	cmp	x0, #0x0
    46a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46ac:	5400018d 	b.le	46dc <fwp_poll_events+0x1bc>
    46b0:	f94028a0 	ldr	x0, [x5, #80]
    46b4:	f2001c1f 	tst	x0, #0xff000000ff
    46b8:	540000e1 	b.ne	46d4 <fwp_poll_events+0x1b4>  // b.any
    46bc:	f9403d00 	ldr	x0, [x8, #120]
    46c0:	390150a7 	strb	w7, [x5, #84]
    46c4:	f90080bf 	str	xzr, [x5, #256]
    46c8:	b40001e0 	cbz	x0, 4704 <fwp_poll_events+0x1e4>
    46cc:	f9003d05 	str	x5, [x8, #120]
    46d0:	f9008005 	str	x5, [x0, #256]
    46d4:	b5fffc73 	cbnz	x19, 4660 <fwp_poll_events+0x140>
    46d8:	17ffffd2 	b	4620 <fwp_poll_events+0x100>
    46dc:	394144a0 	ldrb	w0, [x5, #81]
    46e0:	3707fe80 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46e4:	394140a0 	ldrb	w0, [x5, #80]
    46e8:	3707fe40 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46ec:	aa0503e0 	mov	x0, x5
    46f0:	97fffc20 	bl	3770 <fwp_cancel_tree.part.0>
    46f4:	17ffffef 	b	46b0 <fwp_poll_events+0x190>
    46f8:	91018281 	add	x1, x20, #0x60
    46fc:	f9006c33 	str	x19, [x1, #216]
    4700:	17ffffe2 	b	4688 <fwp_poll_events+0x168>
    4704:	f9003d05 	str	x5, [x8, #120]
    4708:	f9004105 	str	x5, [x8, #128]
    470c:	17fffff2 	b	46d4 <fwp_poll_events+0x1b4>
    4710:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4714:	d2989362 	mov	x2, #0xc49b                	// #50331
    4718:	f2a4d203 	movk	x3, #0x2690, lsl #16
    471c:	f2a00402 	movk	x2, #0x20, lsl #16
    4720:	17ffffb6 	b	45f8 <fwp_poll_events+0xd8>
    4724:	97fffa53 	bl	3070 <fwp_flush>
    4728:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    472c:	f947e863 	ldr	x3, [x3, #4048]
    4730:	d2800562 	mov	x2, #0x2b                  	// #43
    4734:	d2800021 	mov	x1, #0x1                   	// #1
    4738:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    473c:	91172000 	add	x0, x0, #0x5c8
    4740:	f9400063 	ldr	x3, [x3]
    4744:	97fff8b3 	bl	2a10 <fwrite@plt>
    4748:	52800ca0 	mov	w0, #0x65                  	// #101
    474c:	97fff81d 	bl	27c0 <exit@plt>
    4750:	97fff870 	bl	2910 <__stack_chk_fail@plt>

0000000000004754 <fwp_rc_wide_dup>:
    4754:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4758:	910003fd 	mov	x29, sp
    475c:	a90153f3 	stp	x19, x20, [sp, #16]
    4760:	aa0003f3 	mov	x19, x0
    4764:	ca404400 	eor	x0, x0, x0, lsr #17
    4768:	f90013f5 	str	x21, [sp, #32]
    476c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4770:	ca402400 	eor	x0, x0, x0, lsr #9
    4774:	911702a2 	add	x2, x21, #0x5c0
    4778:	92401c00 	and	x0, x0, #0xff
    477c:	910a2403 	add	x3, x0, #0x289
    4780:	8b000c40 	add	x0, x2, x0, lsl #3
    4784:	8b030c54 	add	x20, x2, x3, lsl #3
    4788:	f94a2401 	ldr	x1, [x0, #5192]
    478c:	b50000a1 	cbnz	x1, 47a0 <fwp_rc_wide_dup+0x4c>
    4790:	1400002d 	b	4844 <fwp_rc_wide_dup+0xf0>
    4794:	91004034 	add	x20, x1, #0x10
    4798:	f9400821 	ldr	x1, [x1, #16]
    479c:	b4000241 	cbz	x1, 47e4 <fwp_rc_wide_dup+0x90>
    47a0:	f9400022 	ldr	x2, [x1]
    47a4:	eb02027f 	cmp	x19, x2
    47a8:	54ffff61 	b.ne	4794 <fwp_rc_wide_dup+0x40>  // b.any
    47ac:	f9400281 	ldr	x1, [x20]
    47b0:	39400260 	ldrb	w0, [x19]
    47b4:	7103f81f 	cmp	w0, #0xfe
    47b8:	54000220 	b.eq	47fc <fwp_rc_wide_dup+0xa8>  // b.none
    47bc:	b40001a1 	cbz	x1, 47f0 <fwp_rc_wide_dup+0x9c>
    47c0:	f9400420 	ldr	x0, [x1, #8]
    47c4:	b100041f 	cmn	x0, #0x1
    47c8:	540004a0 	b.eq	485c <fwp_rc_wide_dup+0x108>  // b.none
    47cc:	91000400 	add	x0, x0, #0x1
    47d0:	f9000420 	str	x0, [x1, #8]
    47d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d8:	f94013f5 	ldr	x21, [sp, #32]
    47dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47e0:	d65f03c0 	ret
    47e4:	39400260 	ldrb	w0, [x19]
    47e8:	7103f81f 	cmp	w0, #0xfe
    47ec:	540000a0 	b.eq	4800 <fwp_rc_wide_dup+0xac>  // b.none
    47f0:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    47f4:	91188000 	add	x0, x0, #0x620
    47f8:	97fffc22 	bl	3880 <fwp_trap>
    47fc:	b5000281 	cbnz	x1, 484c <fwp_rc_wide_dup+0xf8>
    4800:	d2800300 	mov	x0, #0x18                  	// #24
    4804:	97fff82b 	bl	28b0 <malloc@plt>
    4808:	b4000280 	cbz	x0, 4858 <fwp_rc_wide_dup+0x104>
    480c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4810:	a9000413 	stp	x19, x1, [x0]
    4814:	911702b5 	add	x21, x21, #0x5c0
    4818:	f900081f 	str	xzr, [x0, #16]
    481c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4820:	f9000280 	str	x0, [x20]
    4824:	39000261 	strb	w1, [x19]
    4828:	f94e26a0 	ldr	x0, [x21, #7240]
    482c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4830:	91000400 	add	x0, x0, #0x1
    4834:	f90e26a0 	str	x0, [x21, #7240]
    4838:	f94013f5 	ldr	x21, [sp, #32]
    483c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4840:	d65f03c0 	ret
    4844:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4848:	17ffffda 	b	47b0 <fwp_rc_wide_dup+0x5c>
    484c:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    4850:	9117e000 	add	x0, x0, #0x5f8
    4854:	97fffc0b 	bl	3880 <fwp_trap>
    4858:	97fffa16 	bl	30b0 <fwp_heap_oom>
    485c:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    4860:	91192000 	add	x0, x0, #0x648
    4864:	97fffc07 	bl	3880 <fwp_trap>
    4868:	d503201f 	nop
    486c:	d503201f 	nop

0000000000004870 <fwp_rc_forget_slot>:
    4870:	aa0003e1 	mov	x1, x0
    4874:	39400000 	ldrb	w0, [x0]
    4878:	7103fc1f 	cmp	w0, #0xff
    487c:	54000040 	b.eq	4884 <fwp_rc_forget_slot+0x14>  // b.none
    4880:	d65f03c0 	ret
    4884:	ca414420 	eor	x0, x1, x1, lsr #17
    4888:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    488c:	ca402400 	eor	x0, x0, x0, lsr #9
    4890:	910003fd 	mov	x29, sp
    4894:	92401c00 	and	x0, x0, #0xff
    4898:	f9000bf3 	str	x19, [sp, #16]
    489c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    48a0:	91170262 	add	x2, x19, #0x5c0
    48a4:	910a2403 	add	x3, x0, #0x289
    48a8:	8b000c40 	add	x0, x2, x0, lsl #3
    48ac:	8b030c43 	add	x3, x2, x3, lsl #3
    48b0:	f94a2400 	ldr	x0, [x0, #5192]
    48b4:	b50000a0 	cbnz	x0, 48c8 <fwp_rc_forget_slot+0x58>
    48b8:	14000011 	b	48fc <fwp_rc_forget_slot+0x8c>
    48bc:	91004003 	add	x3, x0, #0x10
    48c0:	f9400800 	ldr	x0, [x0, #16]
    48c4:	b40001c0 	cbz	x0, 48fc <fwp_rc_forget_slot+0x8c>
    48c8:	f9400002 	ldr	x2, [x0]
    48cc:	eb02003f 	cmp	x1, x2
    48d0:	54ffff61 	b.ne	48bc <fwp_rc_forget_slot+0x4c>  // b.any
    48d4:	f9400801 	ldr	x1, [x0, #16]
    48d8:	91170273 	add	x19, x19, #0x5c0
    48dc:	f9000061 	str	x1, [x3]
    48e0:	97fff83c 	bl	29d0 <free@plt>
    48e4:	f94e2660 	ldr	x0, [x19, #7240]
    48e8:	d1000400 	sub	x0, x0, #0x1
    48ec:	f90e2660 	str	x0, [x19, #7240]
    48f0:	f9400bf3 	ldr	x19, [sp, #16]
    48f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48f8:	d65f03c0 	ret
    48fc:	b0000020 	adrp	x0, 9000 <__modti3+0xe0>
    4900:	91188000 	add	x0, x0, #0x620
    4904:	97fffbdf 	bl	3880 <fwp_trap>
    4908:	d503201f 	nop
    490c:	d503201f 	nop

0000000000004910 <fwp_rc_prepare_chunk>:
    4910:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4914:	910003fd 	mov	x29, sp
    4918:	a9025bf5 	stp	x21, x22, [sp, #32]
    491c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc20>
    4920:	911702c2 	add	x2, x22, #0x5c0
    4924:	b9401c03 	ldr	w3, [x0, #28]
    4928:	aa0103f5 	mov	x21, x1
    492c:	a90153f3 	stp	x19, x20, [sp, #16]
    4930:	aa0003f4 	mov	x20, x0
    4934:	f94e2440 	ldr	x0, [x2, #7240]
    4938:	b4000440 	cbz	x0, 49c0 <fwp_rc_prepare_chunk+0xb0>
    493c:	d2800013 	mov	x19, #0x0                   	// #0
    4940:	35000203 	cbnz	w3, 4980 <fwp_rc_prepare_chunk+0x70>
    4944:	b4000361 	cbz	x1, 49b0 <fwp_rc_prepare_chunk+0xa0>
    4948:	f9401280 	ldr	x0, [x20, #32]
    494c:	97fff821 	bl	29d0 <free@plt>
    4950:	aa1503e0 	mov	x0, x21
    4954:	d2800021 	mov	x1, #0x1                   	// #1
    4958:	97fff7e6 	bl	28f0 <calloc@plt>
    495c:	f9001280 	str	x0, [x20, #32]
    4960:	b5000460 	cbnz	x0, 49ec <fwp_rc_prepare_chunk+0xdc>
    4964:	97fff9d3 	bl	30b0 <fwp_heap_oom>
    4968:	97ffffc2 	bl	4870 <fwp_rc_forget_slot>
    496c:	91000673 	add	x19, x19, #0x1
    4970:	b9401e83 	ldr	w3, [x20, #28]
    4974:	eb13007f 	cmp	x3, x19
    4978:	54000169 	b.ls	49a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    497c:	d503201f 	nop
    4980:	f9401283 	ldr	x3, [x20, #32]
    4984:	8b130060 	add	x0, x3, x19
    4988:	38736863 	ldrb	w3, [x3, x19]
    498c:	7103fc7f 	cmp	w3, #0xff
    4990:	54fffec0 	b.eq	4968 <fwp_rc_prepare_chunk+0x58>  // b.none
    4994:	b9401e83 	ldr	w3, [x20, #28]
    4998:	91000673 	add	x19, x19, #0x1
    499c:	eb13007f 	cmp	x3, x19
    49a0:	54ffff08 	b.hi	4980 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49a4:	eb0302bf 	cmp	x21, x3
    49a8:	54000121 	b.ne	49cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    49ac:	b5000335 	cbnz	x21, 4a10 <fwp_rc_prepare_chunk+0x100>
    49b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    49b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49bc:	d65f03c0 	ret
    49c0:	2a0303e3 	mov	w3, w3
    49c4:	eb0302bf 	cmp	x21, x3
    49c8:	54ffff20 	b.eq	49ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    49cc:	911702c2 	add	x2, x22, #0x5c0
    49d0:	f9401280 	ldr	x0, [x20, #32]
    49d4:	f94e2841 	ldr	x1, [x2, #7248]
    49d8:	cb030021 	sub	x1, x1, x3
    49dc:	f90e2841 	str	x1, [x2, #7248]
    49e0:	97fff7fc 	bl	29d0 <free@plt>
    49e4:	b5fffb75 	cbnz	x21, 4950 <fwp_rc_prepare_chunk+0x40>
    49e8:	f900129f 	str	xzr, [x20, #32]
    49ec:	911702d6 	add	x22, x22, #0x5c0
    49f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    49f4:	b9001e95 	str	w21, [x20, #28]
    49f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49fc:	8b150000 	add	x0, x0, x21
    4a00:	f90e2ac0 	str	x0, [x22, #7248]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	f9401280 	ldr	x0, [x20, #32]
    4a14:	aa1503e2 	mov	x2, x21
    4a18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a1c:	52800001 	mov	w1, #0x0                   	// #0
    4a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a28:	17fff7ae 	b	28e0 <memset@plt>
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_heap_refill>:
    4a30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4a40:	911702b5 	add	x21, x21, #0x5c0
    4a44:	aa0003f6 	mov	x22, x0
    4a48:	d2800020 	mov	x0, #0x1                   	// #1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	a90363f7 	stp	x23, x24, [sp, #48]
    4a54:	2a0103f7 	mov	w23, w1
    4a58:	2a0203f8 	mov	w24, w2
    4a5c:	97fffa35 	bl	3330 <fwp_heap_chunks>
    4a60:	aa0003f3 	mov	x19, x0
    4a64:	f949fea2 	ldr	x2, [x21, #5112]
    4a68:	8b000800 	add	x0, x0, x0, lsl #2
    4a6c:	2a1703e1 	mov	w1, w23
    4a70:	52800025 	mov	w5, #0x1                   	// #1
    4a74:	d37df000 	lsl	x0, x0, #3
    4a78:	910f0021 	add	x1, x1, #0x3c0
    4a7c:	8b000054 	add	x20, x2, x0
    4a80:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a84:	52a00024 	mov	w4, #0x10000               	// #65536
    4a88:	38206845 	strb	w5, [x2, x0]
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	39000698 	strb	w24, [x20, #1]
    4a94:	39000a97 	strb	w23, [x20, #2]
    4a98:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a9c:	b9000681 	str	w1, [x20, #4]
    4aa0:	2a0103e5 	mov	w5, w1
    4aa4:	8b0300a2 	add	x2, x5, x3
    4aa8:	1ac10881 	udiv	w1, w4, w1
    4aac:	9ac50842 	udiv	x2, x2, x5
    4ab0:	b9000a81 	str	w1, [x20, #8]
    4ab4:	92404021 	and	x1, x1, #0x1ffff
    4ab8:	b9001a82 	str	w2, [x20, #24]
    4abc:	97ffff95 	bl	4910 <fwp_rc_prepare_chunk>
    4ac0:	f949daa0 	ldr	x0, [x21, #5040]
    4ac4:	29408a81 	ldp	w1, w2, [x20, #4]
    4ac8:	8b134000 	add	x0, x0, x19, lsl #16
    4acc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad0:	8b214003 	add	x3, x0, w1, uxtw
    4ad4:	9ba20021 	umaddl	x1, w1, w2, x0
    4ad8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4adc:	a90086c3 	stp	x3, x1, [x22, #8]
    4ae0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ae8:	d65f03c0 	ret
    4aec:	d503201f 	nop

0000000000004af0 <fwp_mem_free>:
    4af0:	b40003c0 	cbz	x0, 4b68 <fwp_mem_free+0x78>
    4af4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4af8:	910003fd 	mov	x29, sp
    4afc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b00:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4b04:	911702a1 	add	x1, x21, #0x5c0
    4b08:	a90153f3 	stp	x19, x20, [sp, #16]
    4b0c:	aa0003f3 	mov	x19, x0
    4b10:	f949d823 	ldr	x3, [x1, #5040]
    4b14:	f949ec22 	ldr	x2, [x1, #5080]
    4b18:	cb030000 	sub	x0, x0, x3
    4b1c:	eb02401f 	cmp	x0, x2, lsl #16
    4b20:	540001c2 	b.cs	4b58 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b24:	d350fc16 	lsr	x22, x0, #16
    4b28:	a90363f7 	stp	x23, x24, [sp, #48]
    4b2c:	f949fc22 	ldr	x2, [x1, #5112]
    4b30:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b34:	d37df294 	lsl	x20, x20, #3
    4b38:	ab140057 	adds	x23, x2, x20
    4b3c:	540000c0 	b.eq	4b54 <fwp_mem_free+0x64>  // b.none
    4b40:	38746842 	ldrb	w2, [x2, x20]
    4b44:	7100045f 	cmp	w2, #0x1
    4b48:	54000120 	b.eq	4b6c <fwp_mem_free+0x7c>  // b.none
    4b4c:	7100085f 	cmp	w2, #0x2
    4b50:	540005e0 	b.eq	4c0c <fwp_mem_free+0x11c>  // b.none
    4b54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b60:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b64:	d65f03c0 	ret
    4b68:	d65f03c0 	ret
    4b6c:	f94012f8 	ldr	x24, [x23, #32]
    4b70:	b94006e1 	ldr	w1, [x23, #4]
    4b74:	f90023f9 	str	x25, [sp, #64]
    4b78:	2a0103e2 	mov	w2, w1
    4b7c:	394006f9 	ldrb	w25, [x23, #1]
    4b80:	39400af4 	ldrb	w20, [x23, #2]
    4b84:	b4000158 	cbz	x24, 4bac <fwp_mem_free+0xbc>
    4b88:	92403e76 	and	x22, x19, #0xffff
    4b8c:	9ac20ad6 	udiv	x22, x22, x2
    4b90:	38766b01 	ldrb	w1, [x24, x22]
    4b94:	8b160300 	add	x0, x24, x22
    4b98:	7103fc3f 	cmp	w1, #0xff
    4b9c:	54000980 	b.eq	4ccc <fwp_mem_free+0x1dc>  // b.none
    4ba0:	38366b1f 	strb	wzr, [x24, x22]
    4ba4:	b94006e1 	ldr	w1, [x23, #4]
    4ba8:	2a0103e2 	mov	w2, w1
    4bac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4bb0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4bb4:	cb390000 	sub	x0, x0, w25, uxtb
    4bb8:	8b340074 	add	x20, x3, w20, uxtb
    4bbc:	911702b5 	add	x21, x21, #0x5c0
    4bc0:	1e630021 	ucvtf	d1, w1
    4bc4:	d37ae400 	lsl	x0, x0, #6
    4bc8:	8b140c14 	add	x20, x0, x20, lsl #3
    4bcc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bd0:	f8746aa0 	ldr	x0, [x21, x20]
    4bd4:	f94023f9 	ldr	x25, [sp, #64]
    4bd8:	aa2003e0 	mvn	x0, x0
    4bdc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4be0:	f9000260 	str	x0, [x19]
    4be4:	f8346ab3 	str	x19, [x21, x20]
    4be8:	f94a12a0 	ldr	x0, [x21, #5152]
    4bec:	1e612800 	fadd	d0, d0, d1
    4bf0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf4:	cb020000 	sub	x0, x0, x2
    4bf8:	f90a12a0 	str	x0, [x21, #5152]
    4bfc:	fd0a22a0 	str	d0, [x21, #5184]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c08:	d65f03c0 	ret
    4c0c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c10:	8b000063 	add	x3, x3, x0
    4c14:	eb03027f 	cmp	x19, x3
    4c18:	54fff9e1 	b.ne	4b54 <fwp_mem_free+0x64>  // b.any
    4c1c:	fd400ae1 	ldr	d1, [x23, #16]
    4c20:	fd4a2020 	ldr	d0, [x1, #5184]
    4c24:	f9400ae0 	ldr	x0, [x23, #16]
    4c28:	7e61d821 	ucvtf	d1, d1
    4c2c:	f94a1022 	ldr	x2, [x1, #5152]
    4c30:	f94012f3 	ldr	x19, [x23, #32]
    4c34:	1e612800 	fadd	d0, d0, d1
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f90a1022 	str	x2, [x1, #5152]
    4c40:	fd0a2020 	str	d0, [x1, #5184]
    4c44:	b40000b3 	cbz	x19, 4c58 <fwp_mem_free+0x168>
    4c48:	39400260 	ldrb	w0, [x19]
    4c4c:	7103fc1f 	cmp	w0, #0xff
    4c50:	54000380 	b.eq	4cc0 <fwp_mem_free+0x1d0>  // b.none
    4c54:	3900027f 	strb	wzr, [x19]
    4c58:	b9400ee2 	ldr	w2, [x23, #12]
    4c5c:	b4000142 	cbz	x2, 4c84 <fwp_mem_free+0x194>
    4c60:	911702a1 	add	x1, x21, #0x5c0
    4c64:	8b160040 	add	x0, x2, x22
    4c68:	8b000800 	add	x0, x0, x0, lsl #2
    4c6c:	f949fc21 	ldr	x1, [x1, #5112]
    4c70:	8b140034 	add	x20, x1, x20
    4c74:	8b000c20 	add	x0, x1, x0, lsl #3
    4c78:	3802869f 	strb	wzr, [x20], #40
    4c7c:	eb00029f 	cmp	x20, x0
    4c80:	54ffffc1 	b.ne	4c78 <fwp_mem_free+0x188>  // b.any
    4c84:	911702a0 	add	x0, x21, #0x5c0
    4c88:	f94a1801 	ldr	x1, [x0, #5168]
    4c8c:	f949f803 	ldr	x3, [x0, #5104]
    4c90:	8b020021 	add	x1, x1, x2
    4c94:	f90a1801 	str	x1, [x0, #5168]
    4c98:	eb16007f 	cmp	x3, x22
    4c9c:	54000049 	b.ls	4ca4 <fwp_mem_free+0x1b4>  // b.plast
    4ca0:	f909f816 	str	x22, [x0, #5104]
    4ca4:	911702b5 	add	x21, x21, #0x5c0
    4ca8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cac:	eb16001f 	cmp	x0, x22
    4cb0:	54fff529 	b.ls	4b54 <fwp_mem_free+0x64>  // b.plast
    4cb4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cb8:	f909f6b6 	str	x22, [x21, #5096]
    4cbc:	17ffffa7 	b	4b58 <fwp_mem_free+0x68>
    4cc0:	aa1303e0 	mov	x0, x19
    4cc4:	97fffeeb 	bl	4870 <fwp_rc_forget_slot>
    4cc8:	17ffffe3 	b	4c54 <fwp_mem_free+0x164>
    4ccc:	97fffee9 	bl	4870 <fwp_rc_forget_slot>
    4cd0:	17ffffb4 	b	4ba0 <fwp_mem_free+0xb0>

0000000000004cd4 <fwp_heap_alloc_big>:
    4cd4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd8:	910003fd 	mov	x29, sp
    4cdc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ce0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce4:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce8:	aa0003f7 	mov	x23, x0
    4cec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cf0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf4:	eb0002ff 	cmp	x23, x0
    4cf8:	54000888 	b.hi	4e08 <fwp_heap_alloc_big+0x134>  // b.pmore
    4cfc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d00:	8b0002f4 	add	x20, x23, x0
    4d04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc20>
    4d08:	91170359 	add	x25, x26, #0x5c0
    4d0c:	d350fe94 	lsr	x20, x20, #16
    4d10:	2a0103f5 	mov	w21, w1
    4d14:	aa1403e0 	mov	x0, x20
    4d18:	97fff986 	bl	3330 <fwp_heap_chunks>
    4d1c:	f949ff22 	ldr	x2, [x25, #5112]
    4d20:	8b000813 	add	x19, x0, x0, lsl #2
    4d24:	aa0003f8 	mov	x24, x0
    4d28:	52800043 	mov	w3, #0x2                   	// #2
    4d2c:	d37df273 	lsl	x19, x19, #3
    4d30:	d2800021 	mov	x1, #0x1                   	// #1
    4d34:	8b130040 	add	x0, x2, x19
    4d38:	38336843 	strb	w3, [x2, x19]
    4d3c:	39000415 	strb	w21, [x0, #1]
    4d40:	b9000c14 	str	w20, [x0, #12]
    4d44:	f9000817 	str	x23, [x0, #16]
    4d48:	97fffef2 	bl	4910 <fwp_rc_prepare_chunk>
    4d4c:	f100069f 	cmp	x20, #0x1
    4d50:	54000269 	b.ls	4d9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4d54:	8b180294 	add	x20, x20, x24
    4d58:	9100a273 	add	x19, x19, #0x28
    4d5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4d60:	5280007b 	mov	w27, #0x3                   	// #3
    4d64:	8b140a94 	add	x20, x20, x20, lsl #2
    4d68:	2a1803fc 	mov	w28, w24
    4d6c:	9adb2296 	lsl	x22, x20, x27
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffee4 	bl	4910 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0x9c>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91170353 	add	x19, x26, #0x5c0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x104>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117035a 	add	x26, x26, #0x5c0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    4e20:	91170262 	add	x2, x19, #0x5c0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91170262 	add	x2, x19, #0x5c0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91170260 	add	x0, x19, #0x5c0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91170273 	add	x19, x19, #0x5c0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffca4 	bl	4184 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff70 	b	4cd4 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91170260 	add	x0, x19, #0x5c0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffeb5 	bl	4a30 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    4f84:	91170293 	add	x19, x20, #0x5c0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91170294 	add	x20, x20, #0x5c0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    5094:	91170283 	add	x3, x20, #0x5c0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91170282 	add	x2, x20, #0x5c0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91170294 	add	x20, x20, #0x5c0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_p_ad_push>:
    51a4:	f100001f 	cmp	x0, #0x0
    51a8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51ac:	54000e8b 	b.lt	537c <fwp_p_ad_push+0x1d8>  // b.tstop
    51b0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    51b4:	aa0003e4 	mov	x4, x0
    51b8:	910003fd 	mov	x29, sp
    51bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51c0:	aa0003f5 	mov	x21, x0
    51c4:	aa020000 	orr	x0, x0, x2
    51c8:	a90363f7 	stp	x23, x24, [sp, #48]
    51cc:	aa0203f7 	mov	x23, x2
    51d0:	6d0627e8 	stp	d8, d9, [sp, #96]
    51d4:	9e670029 	fmov	d9, x1
    51d8:	9e670068 	fmov	d8, x3
    51dc:	b6f80900 	tbz	x0, #63, 52fc <fwp_p_ad_push+0x158>
    51e0:	a90153f3 	stp	x19, x20, [sp, #16]
    51e4:	9360fc80 	asr	x0, x4, #32
    51e8:	b6f800c4 	tbz	x4, #63, 5200 <fwp_p_ad_push+0x5c>
    51ec:	1e604109 	fmov	d9, d8
    51f0:	2f00e408 	movi	d8, #0x0
    51f4:	9360fc40 	asr	x0, x2, #32
    51f8:	aa0203f5 	mov	x21, x2
    51fc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5200:	97fffa6c 	bl	3bb0 <fwp_tape_of>
    5204:	aa0003f3 	mov	x19, x0
    5208:	f9403000 	ldr	x0, [x0, #96]
    520c:	b5001280 	cbnz	x0, 545c <fwp_p_ad_push+0x2b8>
    5210:	f9400a76 	ldr	x22, [x19, #16]
    5214:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5218:	eb0002df 	cmp	x22, x0
    521c:	54000e2c 	b.gt	53e0 <fwp_p_ad_push+0x23c>
    5220:	eb3542df 	cmp	x22, w21, uxtw
    5224:	54000d4d 	b.le	53cc <fwp_p_ad_push+0x228>
    5228:	b7f80077 	tbnz	x23, #63, 5234 <fwp_p_ad_push+0x90>
    522c:	eb3742df 	cmp	x22, w23, uxtw
    5230:	54000ced 	b.le	53cc <fwp_p_ad_push+0x228>
    5234:	f9400678 	ldr	x24, [x19, #8]
    5238:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    523c:	cb1802d8 	sub	x24, x22, x24
    5240:	91000701 	add	x1, x24, #0x1
    5244:	eb00003f 	cmp	x1, x0
    5248:	54000cc8 	b.hi	53e0 <fwp_p_ad_push+0x23c>  // b.pmore
    524c:	a9418274 	ldp	x20, x0, [x19, #24]
    5250:	a90573fb 	stp	x27, x28, [sp, #80]
    5254:	eb14003f 	cmp	x1, x20
    5258:	5400068d 	b.le	5328 <fwp_p_ad_push+0x184>
    525c:	f100029f 	cmp	x20, #0x0
    5260:	d2800803 	mov	x3, #0x40                  	// #64
    5264:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5268:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    526c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5270:	eb14003f 	cmp	x1, x20
    5274:	5400008d 	b.le	5284 <fwp_p_ad_push+0xe0>
    5278:	eb02029f 	cmp	x20, x2
    527c:	5400052d 	b.le	5320 <fwp_p_ad_push+0x17c>
    5280:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5284:	d37df299 	lsl	x25, x20, #3
    5288:	aa1903e1 	mov	x1, x25
    528c:	97fff59d 	bl	2900 <realloc@plt>
    5290:	aa0003e1 	mov	x1, x0
    5294:	b4000b00 	cbz	x0, 53f4 <fwp_p_ad_push+0x250>
    5298:	f9400e62 	ldr	x2, [x19, #24]
    529c:	f9001261 	str	x1, [x19, #32]
    52a0:	f9401a60 	ldr	x0, [x19, #48]
    52a4:	d37cee9a 	lsl	x26, x20, #4
    52a8:	8b020821 	add	x1, x1, x2, lsl #2
    52ac:	f9001661 	str	x1, [x19, #40]
    52b0:	aa1a03e1 	mov	x1, x26
    52b4:	97fff593 	bl	2900 <realloc@plt>
    52b8:	aa0003e2 	mov	x2, x0
    52bc:	b40009c0 	cbz	x0, 53f4 <fwp_p_ad_push+0x250>
    52c0:	f9400e61 	ldr	x1, [x19, #24]
    52c4:	d37df31b 	lsl	x27, x24, #3
    52c8:	d37ef685 	lsl	x5, x20, #2
    52cc:	d37ef71c 	lsl	x28, x24, #2
    52d0:	8b190004 	add	x4, x0, x25
    52d4:	8b010c01 	add	x1, x0, x1, lsl #3
    52d8:	a9030660 	stp	x0, x1, [x19, #48]
    52dc:	b5000558 	cbnz	x24, 5384 <fwp_p_ad_push+0x1e0>
    52e0:	f9001e64 	str	x4, [x19, #56]
    52e4:	f9401260 	ldr	x0, [x19, #32]
    52e8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    52ec:	8b050001 	add	x1, x0, x5
    52f0:	f9000e74 	str	x20, [x19, #24]
    52f4:	f9001661 	str	x1, [x19, #40]
    52f8:	14000010 	b	5338 <fwp_p_ad_push+0x194>
    52fc:	9360fc40 	asr	x0, x2, #32
    5300:	a90153f3 	stp	x19, x20, [sp, #16]
    5304:	eb84801f 	cmp	x0, x4, asr #32
    5308:	54fff7c0 	b.eq	5200 <fwp_p_ad_push+0x5c>  // b.none
    530c:	90000020 	adrp	x0, 9000 <__modti3+0xe0>
    5310:	9119a000 	add	x0, x0, #0x668
    5314:	a9046bf9 	stp	x25, x26, [sp, #64]
    5318:	a90573fb 	stp	x27, x28, [sp, #80]
    531c:	97fff959 	bl	3880 <fwp_trap>
    5320:	d37ffa94 	lsl	x20, x20, #1
    5324:	17ffffd3 	b	5270 <fwp_p_ad_push+0xcc>
    5328:	a9428a61 	ldp	x1, x2, [x19, #40]
    532c:	d37ef71c 	lsl	x28, x24, #2
    5330:	f9401e64 	ldr	x4, [x19, #56]
    5334:	d37df31b 	lsl	x27, x24, #3
    5338:	b83c6815 	str	w21, [x0, x28]
    533c:	f10002ff 	cmp	x23, #0x0
    5340:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5344:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5348:	fc3b6849 	str	d9, [x2, x27]
    534c:	aa1602a0 	orr	x0, x21, x22
    5350:	b83c6837 	str	w23, [x1, x28]
    5354:	910006d6 	add	x22, x22, #0x1
    5358:	a94363f7 	ldp	x23, x24, [sp, #48]
    535c:	fc3b6888 	str	d8, [x4, x27]
    5360:	a94573fb 	ldp	x27, x28, [sp, #80]
    5364:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5368:	f9000a76 	str	x22, [x19, #16]
    536c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5370:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5374:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5378:	d65f03c0 	ret
    537c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5380:	d65f03c0 	ret
    5384:	eb1a033f 	cmp	x25, x26
    5388:	aa0403e0 	mov	x0, x4
    538c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5390:	aa1b03e2 	mov	x2, x27
    5394:	cb190063 	sub	x3, x3, x25
    5398:	f9003fe5 	str	x5, [sp, #120]
    539c:	97fff5c5 	bl	2ab0 <__memmove_chk@plt>
    53a0:	a9420660 	ldp	x0, x1, [x19, #32]
    53a4:	aa1c03e2 	mov	x2, x28
    53a8:	f9401a63 	ldr	x3, [x19, #48]
    53ac:	f9403fe5 	ldr	x5, [sp, #120]
    53b0:	8b190063 	add	x3, x3, x25
    53b4:	f9001e63 	str	x3, [x19, #56]
    53b8:	8b050000 	add	x0, x0, x5
    53bc:	97fff4f1 	bl	2780 <memmove@plt>
    53c0:	a9431262 	ldp	x2, x4, [x19, #48]
    53c4:	f9403fe5 	ldr	x5, [sp, #120]
    53c8:	17ffffc7 	b	52e4 <fwp_p_ad_push+0x140>
    53cc:	90000020 	adrp	x0, 9000 <__modti3+0xe0>
    53d0:	911c0000 	add	x0, x0, #0x700
    53d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    53d8:	a90573fb 	stp	x27, x28, [sp, #80]
    53dc:	97fff929 	bl	3880 <fwp_trap>
    53e0:	90000020 	adrp	x0, 9000 <__modti3+0xe0>
    53e4:	911b8000 	add	x0, x0, #0x6e0
    53e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    53ec:	a90573fb 	stp	x27, x28, [sp, #80]
    53f0:	97fff924 	bl	3880 <fwp_trap>
    53f4:	aa1303e0 	mov	x0, x19
    53f8:	97fff706 	bl	3010 <fwp_tape_unlink_scope>
    53fc:	f9401260 	ldr	x0, [x19, #32]
    5400:	97fff574 	bl	29d0 <free@plt>
    5404:	f9401a60 	ldr	x0, [x19, #48]
    5408:	97fff572 	bl	29d0 <free@plt>
    540c:	f9402260 	ldr	x0, [x19, #64]
    5410:	97fff570 	bl	29d0 <free@plt>
    5414:	f9000e7f 	str	xzr, [x19, #24]
    5418:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    541c:	f947e821 	ldr	x1, [x1, #4048]
    5420:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5424:	d2800262 	mov	x2, #0x13                  	// #19
    5428:	4f000400 	movi	v0.4s, #0x0
    542c:	90000020 	adrp	x0, 9000 <__modti3+0xe0>
    5430:	f9400023 	ldr	x3, [x1]
    5434:	b900067f 	str	wzr, [x19, #4]
    5438:	d2800021 	mov	x1, #0x1                   	// #1
    543c:	910b2000 	add	x0, x0, #0x2c8
    5440:	3c808260 	stur	q0, [x19, #8]
    5444:	ad010260 	stp	q0, q0, [x19, #32]
    5448:	97fff572 	bl	2a10 <fwrite@plt>
    544c:	d2800000 	mov	x0, #0x0                   	// #0
    5450:	97fff57c 	bl	2a40 <fflush@plt>
    5454:	52800cc0 	mov	w0, #0x66                  	// #102
    5458:	97fff58a 	bl	2a80 <_Exit@plt>
    545c:	90000020 	adrp	x0, 9000 <__modti3+0xe0>
    5460:	911ac000 	add	x0, x0, #0x6b0
    5464:	a9046bf9 	stp	x25, x26, [sp, #64]
    5468:	a90573fb 	stp	x27, x28, [sp, #80]
    546c:	97fff905 	bl	3880 <fwp_trap>

0000000000005470 <w120>:
    5470:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5474:	9e660003 	fmov	x3, d0
    5478:	aa0003e2 	mov	x2, x0
    547c:	910003fd 	mov	x29, sp
    5480:	6d0327e8 	stp	d8, d9, [sp, #48]
    5484:	1e604028 	fmov	d8, d1
    5488:	1e600809 	fmul	d9, d0, d0
    548c:	fd0023ea 	str	d10, [sp, #64]
    5490:	1e60400a 	fmov	d10, d0
    5494:	a90153f3 	stp	x19, x20, [sp, #16]
    5498:	aa0003f3 	mov	x19, x0
    549c:	aa0103f4 	mov	x20, x1
    54a0:	aa0303e1 	mov	x1, x3
    54a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54a8:	97ffff3f 	bl	51a4 <fwp_p_ad_push>
    54ac:	1e693908 	fsub	d8, d8, d9
    54b0:	aa1403e2 	mov	x2, x20
    54b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54b8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54bc:	9e660116 	fmov	x22, d8
    54c0:	97ffff39 	bl	51a4 <fwp_p_ad_push>
    54c4:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    54c8:	aa0003e1 	mov	x1, x0
    54cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54d0:	aa1303e0 	mov	x0, x19
    54d4:	1e6a3929 	fsub	d9, d9, d10
    54d8:	aa0103f3 	mov	x19, x1
    54dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    54e0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54e4:	9e660135 	fmov	x21, d9
    54e8:	97ffff2f 	bl	51a4 <fwp_p_ad_push>
    54ec:	1e680908 	fmul	d8, d8, d8
    54f0:	aa0003f4 	mov	x20, x0
    54f4:	aa1603e3 	mov	x3, x22
    54f8:	aa1603e1 	mov	x1, x22
    54fc:	aa1303e2 	mov	x2, x19
    5500:	aa1303e0 	mov	x0, x19
    5504:	97ffff28 	bl	51a4 <fwp_p_ad_push>
    5508:	aa0003e2 	mov	x2, x0
    550c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5510:	9e670020 	fmov	d0, x1
    5514:	9e660101 	fmov	x1, d8
    5518:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    551c:	1e600908 	fmul	d8, d8, d0
    5520:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5524:	97ffff20 	bl	51a4 <fwp_p_ad_push>
    5528:	1e690929 	fmul	d9, d9, d9
    552c:	aa0003f3 	mov	x19, x0
    5530:	aa1503e3 	mov	x3, x21
    5534:	aa1503e1 	mov	x1, x21
    5538:	aa1403e2 	mov	x2, x20
    553c:	aa1403e0 	mov	x0, x20
    5540:	97ffff19 	bl	51a4 <fwp_p_ad_push>
    5544:	1e692908 	fadd	d8, d8, d9
    5548:	aa1303e2 	mov	x2, x19
    554c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5550:	aa0303e1 	mov	x1, x3
    5554:	97ffff14 	bl	51a4 <fwp_p_ad_push>
    5558:	aa0003e1 	mov	x1, x0
    555c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5560:	9e660100 	fmov	x0, d8
    5564:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5568:	6d4327e8 	ldp	d8, d9, [sp, #48]
    556c:	fd4023ea 	ldr	d10, [sp, #64]
    5570:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5574:	d65f03c0 	ret
    5578:	d503201f 	nop
    557c:	d503201f 	nop

0000000000005580 <fwp_rc_share>:
    5580:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    5584:	91170042 	add	x2, x2, #0x5c0
    5588:	f949d843 	ldr	x3, [x2, #5040]
    558c:	f949ec41 	ldr	x1, [x2, #5080]
    5590:	cb030000 	sub	x0, x0, x3
    5594:	eb01401f 	cmp	x0, x1, lsl #16
    5598:	540002c2 	b.cs	55f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    559c:	d350fc01 	lsr	x1, x0, #16
    55a0:	f949fc44 	ldr	x4, [x2, #5112]
    55a4:	8b010821 	add	x1, x1, x1, lsl #2
    55a8:	d37df021 	lsl	x1, x1, #3
    55ac:	8b010083 	add	x3, x4, x1
    55b0:	f9401062 	ldr	x2, [x3, #32]
    55b4:	b40001e2 	cbz	x2, 55f0 <fwp_rc_share+0x70>
    55b8:	38616881 	ldrb	w1, [x4, x1]
    55bc:	7100083f 	cmp	w1, #0x2
    55c0:	540001a0 	b.eq	55f4 <fwp_rc_share+0x74>  // b.none
    55c4:	7100043f 	cmp	w1, #0x1
    55c8:	54000141 	b.ne	55f0 <fwp_rc_share+0x70>  // b.any
    55cc:	29430464 	ldp	w4, w1, [x3, #24]
    55d0:	92403c00 	and	x0, x0, #0xffff
    55d4:	9b047c00 	mul	x0, x0, x4
    55d8:	d360fc00 	lsr	x0, x0, #32
    55dc:	eb01001f 	cmp	x0, x1
    55e0:	54000082 	b.cs	55f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    55e4:	8b000042 	add	x2, x2, x0
    55e8:	39400040 	ldrb	w0, [x2]
    55ec:	350000a0 	cbnz	w0, 5600 <fwp_rc_share+0x80>
    55f0:	d65f03c0 	ret
    55f4:	72003c1f 	tst	w0, #0xffff
    55f8:	54ffff80 	b.eq	55e8 <fwp_rc_share+0x68>  // b.none
    55fc:	d65f03c0 	ret
    5600:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5604:	90000020 	adrp	x0, 9000 <__modti3+0xe0>
    5608:	911c8000 	add	x0, x0, #0x720
    560c:	910003fd 	mov	x29, sp
    5610:	97fff89c 	bl	3880 <fwp_trap>

0000000000005614 <fwp_rc_free_arr>:
    5614:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5618:	91170063 	add	x3, x3, #0x5c0
    561c:	f949d861 	ldr	x1, [x3, #5040]
    5620:	f949ec62 	ldr	x2, [x3, #5080]
    5624:	cb010001 	sub	x1, x0, x1
    5628:	eb02403f 	cmp	x1, x2, lsl #16
    562c:	54000342 	b.cs	5694 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5630:	d350fc22 	lsr	x2, x1, #16
    5634:	f949fc65 	ldr	x5, [x3, #5112]
    5638:	8b020842 	add	x2, x2, x2, lsl #2
    563c:	d37df042 	lsl	x2, x2, #3
    5640:	8b0200a4 	add	x4, x5, x2
    5644:	f9401083 	ldr	x3, [x4, #32]
    5648:	b4000263 	cbz	x3, 5694 <fwp_rc_free_arr+0x80>
    564c:	386268a2 	ldrb	w2, [x5, x2]
    5650:	7100085f 	cmp	w2, #0x2
    5654:	540001c0 	b.eq	568c <fwp_rc_free_arr+0x78>  // b.none
    5658:	7100045f 	cmp	w2, #0x1
    565c:	540001c1 	b.ne	5694 <fwp_rc_free_arr+0x80>  // b.any
    5660:	29430885 	ldp	w5, w2, [x4, #24]
    5664:	92403c21 	and	x1, x1, #0xffff
    5668:	9b057c21 	mul	x1, x1, x5
    566c:	d360fc21 	lsr	x1, x1, #32
    5670:	eb02003f 	cmp	x1, x2
    5674:	54000102 	b.cs	5694 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5678:	8b010063 	add	x3, x3, x1
    567c:	39400061 	ldrb	w1, [x3]
    5680:	7100043f 	cmp	w1, #0x1
    5684:	54000081 	b.ne	5694 <fwp_rc_free_arr+0x80>  // b.any
    5688:	17fffd1a 	b	4af0 <fwp_mem_free>
    568c:	72003c3f 	tst	w1, #0xffff
    5690:	54ffff60 	b.eq	567c <fwp_rc_free_arr+0x68>  // b.none
    5694:	d65f03c0 	ret
    5698:	d503201f 	nop
    569c:	d503201f 	nop

00000000000056a0 <fwp_rc_dup>:
    56a0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    56a4:	91170042 	add	x2, x2, #0x5c0
    56a8:	f949d841 	ldr	x1, [x2, #5040]
    56ac:	f949ec43 	ldr	x3, [x2, #5080]
    56b0:	cb010001 	sub	x1, x0, x1
    56b4:	eb03403f 	cmp	x1, x3, lsl #16
    56b8:	54000342 	b.cs	5720 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    56bc:	d350fc20 	lsr	x0, x1, #16
    56c0:	f949fc44 	ldr	x4, [x2, #5112]
    56c4:	8b000800 	add	x0, x0, x0, lsl #2
    56c8:	d37df002 	lsl	x2, x0, #3
    56cc:	8b020083 	add	x3, x4, x2
    56d0:	f9401060 	ldr	x0, [x3, #32]
    56d4:	b4000260 	cbz	x0, 5720 <fwp_rc_dup+0x80>
    56d8:	38626882 	ldrb	w2, [x4, x2]
    56dc:	7100085f 	cmp	w2, #0x2
    56e0:	54000220 	b.eq	5724 <fwp_rc_dup+0x84>  // b.none
    56e4:	7100045f 	cmp	w2, #0x1
    56e8:	540001c1 	b.ne	5720 <fwp_rc_dup+0x80>  // b.any
    56ec:	29430864 	ldp	w4, w2, [x3, #24]
    56f0:	92403c21 	and	x1, x1, #0xffff
    56f4:	9b047c21 	mul	x1, x1, x4
    56f8:	d360fc21 	lsr	x1, x1, #32
    56fc:	eb02003f 	cmp	x1, x2
    5700:	54000102 	b.cs	5720 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5704:	8b010000 	add	x0, x0, x1
    5708:	39400001 	ldrb	w1, [x0]
    570c:	340000a1 	cbz	w1, 5720 <fwp_rc_dup+0x80>
    5710:	7103f43f 	cmp	w1, #0xfd
    5714:	540000e8 	b.hi	5730 <fwp_rc_dup+0x90>  // b.pmore
    5718:	11000421 	add	w1, w1, #0x1
    571c:	39000001 	strb	w1, [x0]
    5720:	d65f03c0 	ret
    5724:	72003c3f 	tst	w1, #0xffff
    5728:	54ffff00 	b.eq	5708 <fwp_rc_dup+0x68>  // b.none
    572c:	d65f03c0 	ret
    5730:	17fffc09 	b	4754 <fwp_rc_wide_dup>

0000000000005734 <fwp_owned_entry173>:
    5734:	d10103ff 	sub	sp, sp, #0x40
    5738:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    573c:	f947f442 	ldr	x2, [x2, #4072]
    5740:	a9027bfd 	stp	x29, x30, [sp, #32]
    5744:	910083fd 	add	x29, sp, #0x20
    5748:	a90353f3 	stp	x19, x20, [sp, #48]
    574c:	f9400043 	ldr	x3, [x2]
    5750:	f9000fe3 	str	x3, [sp, #24]
    5754:	d2800003 	mov	x3, #0x0                   	// #0
    5758:	a9400c01 	ldp	x1, x3, [x0]
    575c:	f9400802 	ldr	x2, [x0, #16]
    5760:	ab020022 	adds	x2, x1, x2
    5764:	540006e6 	b.vs	5840 <fwp_owned_entry173+0x10c>
    5768:	910023e1 	add	x1, sp, #0x8
    576c:	52800000 	mov	w0, #0x0                   	// #0
    5770:	a9008be3 	stp	x3, x2, [sp, #8]
    5774:	97fffe44 	bl	5084 <fwp_data.part.0.constprop.0>
    5778:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    577c:	91170063 	add	x3, x3, #0x5c0
    5780:	aa0003f3 	mov	x19, x0
    5784:	f949d861 	ldr	x1, [x3, #5040]
    5788:	f949ec60 	ldr	x0, [x3, #5080]
    578c:	cb010261 	sub	x1, x19, x1
    5790:	eb00403f 	cmp	x1, x0, lsl #16
    5794:	54000322 	b.cs	57f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5798:	d350fc22 	lsr	x2, x1, #16
    579c:	f949fc63 	ldr	x3, [x3, #5112]
    57a0:	8b020842 	add	x2, x2, x2, lsl #2
    57a4:	d37df042 	lsl	x2, x2, #3
    57a8:	8b020060 	add	x0, x3, x2
    57ac:	f9401014 	ldr	x20, [x0, #32]
    57b0:	b4000254 	cbz	x20, 57f8 <fwp_owned_entry173+0xc4>
    57b4:	38626862 	ldrb	w2, [x3, x2]
    57b8:	7100085f 	cmp	w2, #0x2
    57bc:	54000360 	b.eq	5828 <fwp_owned_entry173+0xf4>  // b.none
    57c0:	7100045f 	cmp	w2, #0x1
    57c4:	540001a1 	b.ne	57f8 <fwp_owned_entry173+0xc4>  // b.any
    57c8:	29430002 	ldp	w2, w0, [x0, #24]
    57cc:	92403c21 	and	x1, x1, #0xffff
    57d0:	9b027c21 	mul	x1, x1, x2
    57d4:	d360fc21 	lsr	x1, x1, #32
    57d8:	eb00003f 	cmp	x1, x0
    57dc:	540000e2 	b.cs	57f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    57e0:	8b010294 	add	x20, x20, x1
    57e4:	39400280 	ldrb	w0, [x20]
    57e8:	7103fc1f 	cmp	w0, #0xff
    57ec:	54000240 	b.eq	5834 <fwp_owned_entry173+0x100>  // b.none
    57f0:	52800020 	mov	w0, #0x1                   	// #1
    57f4:	39000280 	strb	w0, [x20]
    57f8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    57fc:	f947f400 	ldr	x0, [x0, #4072]
    5800:	f9400fe2 	ldr	x2, [sp, #24]
    5804:	f9400001 	ldr	x1, [x0]
    5808:	eb010042 	subs	x2, x2, x1
    580c:	d2800001 	mov	x1, #0x0                   	// #0
    5810:	540001a1 	b.ne	5844 <fwp_owned_entry173+0x110>  // b.any
    5814:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5818:	aa1303e0 	mov	x0, x19
    581c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5820:	910103ff 	add	sp, sp, #0x40
    5824:	d65f03c0 	ret
    5828:	72003c3f 	tst	w1, #0xffff
    582c:	54fffe61 	b.ne	57f8 <fwp_owned_entry173+0xc4>  // b.any
    5830:	17ffffed 	b	57e4 <fwp_owned_entry173+0xb0>
    5834:	aa1403e0 	mov	x0, x20
    5838:	97fffc0e 	bl	4870 <fwp_rc_forget_slot>
    583c:	17ffffed 	b	57f0 <fwp_owned_entry173+0xbc>
    5840:	97fff4b0 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5844:	97fff433 	bl	2910 <__stack_chk_fail@plt>
    5848:	d503201f 	nop
    584c:	d503201f 	nop

0000000000005850 <e173>:
    5850:	d10103ff 	sub	sp, sp, #0x40
    5854:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5858:	f947f442 	ldr	x2, [x2, #4072]
    585c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5860:	910083fd 	add	x29, sp, #0x20
    5864:	a90353f3 	stp	x19, x20, [sp, #48]
    5868:	f9400043 	ldr	x3, [x2]
    586c:	f9000fe3 	str	x3, [sp, #24]
    5870:	d2800003 	mov	x3, #0x0                   	// #0
    5874:	a9400c01 	ldp	x1, x3, [x0]
    5878:	f9400802 	ldr	x2, [x0, #16]
    587c:	ab020022 	adds	x2, x1, x2
    5880:	54000726 	b.vs	5964 <e173+0x114>
    5884:	910023e1 	add	x1, sp, #0x8
    5888:	52800000 	mov	w0, #0x0                   	// #0
    588c:	a9008be3 	stp	x3, x2, [sp, #8]
    5890:	97fffdfd 	bl	5084 <fwp_data.part.0.constprop.0>
    5894:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5898:	91170063 	add	x3, x3, #0x5c0
    589c:	aa0003f3 	mov	x19, x0
    58a0:	f949d861 	ldr	x1, [x3, #5040]
    58a4:	f949ec60 	ldr	x0, [x3, #5080]
    58a8:	cb010261 	sub	x1, x19, x1
    58ac:	eb00403f 	cmp	x1, x0, lsl #16
    58b0:	54000322 	b.cs	5914 <e173+0xc4>  // b.hs, b.nlast
    58b4:	d350fc22 	lsr	x2, x1, #16
    58b8:	f949fc63 	ldr	x3, [x3, #5112]
    58bc:	8b020842 	add	x2, x2, x2, lsl #2
    58c0:	d37df042 	lsl	x2, x2, #3
    58c4:	8b020060 	add	x0, x3, x2
    58c8:	f9401014 	ldr	x20, [x0, #32]
    58cc:	b4000254 	cbz	x20, 5914 <e173+0xc4>
    58d0:	38626862 	ldrb	w2, [x3, x2]
    58d4:	7100085f 	cmp	w2, #0x2
    58d8:	540003a0 	b.eq	594c <e173+0xfc>  // b.none
    58dc:	7100045f 	cmp	w2, #0x1
    58e0:	540001a1 	b.ne	5914 <e173+0xc4>  // b.any
    58e4:	29430002 	ldp	w2, w0, [x0, #24]
    58e8:	92403c21 	and	x1, x1, #0xffff
    58ec:	9b027c21 	mul	x1, x1, x2
    58f0:	d360fc21 	lsr	x1, x1, #32
    58f4:	eb00003f 	cmp	x1, x0
    58f8:	540000e2 	b.cs	5914 <e173+0xc4>  // b.hs, b.nlast
    58fc:	8b010294 	add	x20, x20, x1
    5900:	39400280 	ldrb	w0, [x20]
    5904:	7103fc1f 	cmp	w0, #0xff
    5908:	54000280 	b.eq	5958 <e173+0x108>  // b.none
    590c:	52800020 	mov	w0, #0x1                   	// #1
    5910:	39000280 	strb	w0, [x20]
    5914:	aa1303e0 	mov	x0, x19
    5918:	97ffff1a 	bl	5580 <fwp_rc_share>
    591c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5920:	f947f400 	ldr	x0, [x0, #4072]
    5924:	f9400fe2 	ldr	x2, [sp, #24]
    5928:	f9400001 	ldr	x1, [x0]
    592c:	eb010042 	subs	x2, x2, x1
    5930:	d2800001 	mov	x1, #0x0                   	// #0
    5934:	540001a1 	b.ne	5968 <e173+0x118>  // b.any
    5938:	a9427bfd 	ldp	x29, x30, [sp, #32]
    593c:	aa1303e0 	mov	x0, x19
    5940:	a94353f3 	ldp	x19, x20, [sp, #48]
    5944:	910103ff 	add	sp, sp, #0x40
    5948:	d65f03c0 	ret
    594c:	72003c3f 	tst	w1, #0xffff
    5950:	54fffe21 	b.ne	5914 <e173+0xc4>  // b.any
    5954:	17ffffeb 	b	5900 <e173+0xb0>
    5958:	aa1403e0 	mov	x0, x20
    595c:	97fffbc5 	bl	4870 <fwp_rc_forget_slot>
    5960:	17ffffeb 	b	590c <e173+0xbc>
    5964:	97fff467 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5968:	97fff3ea 	bl	2910 <__stack_chk_fail@plt>
    596c:	d503201f 	nop

0000000000005970 <fwp_drop1>:
    5970:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5974:	910003fd 	mov	x29, sp
    5978:	a90153f3 	stp	x19, x20, [sp, #16]
    597c:	f90013f5 	str	x21, [sp, #32]
    5980:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    5984:	911702b4 	add	x20, x21, #0x5c0
    5988:	f949da81 	ldr	x1, [x20, #5040]
    598c:	f949ee82 	ldr	x2, [x20, #5080]
    5990:	cb010001 	sub	x1, x0, x1
    5994:	eb02403f 	cmp	x1, x2, lsl #16
    5998:	54000382 	b.cs	5a08 <fwp_drop1+0x98>  // b.hs, b.nlast
    599c:	d350fc22 	lsr	x2, x1, #16
    59a0:	f949fe84 	ldr	x4, [x20, #5112]
    59a4:	8b020842 	add	x2, x2, x2, lsl #2
    59a8:	d37df042 	lsl	x2, x2, #3
    59ac:	8b020083 	add	x3, x4, x2
    59b0:	f9401073 	ldr	x19, [x3, #32]
    59b4:	b40002b3 	cbz	x19, 5a08 <fwp_drop1+0x98>
    59b8:	38626882 	ldrb	w2, [x4, x2]
    59bc:	7100085f 	cmp	w2, #0x2
    59c0:	540002c0 	b.eq	5a18 <fwp_drop1+0xa8>  // b.none
    59c4:	7100045f 	cmp	w2, #0x1
    59c8:	54000201 	b.ne	5a08 <fwp_drop1+0x98>  // b.any
    59cc:	29430864 	ldp	w4, w2, [x3, #24]
    59d0:	92403c21 	and	x1, x1, #0xffff
    59d4:	9b047c21 	mul	x1, x1, x4
    59d8:	d360fc21 	lsr	x1, x1, #32
    59dc:	eb02003f 	cmp	x1, x2
    59e0:	54000142 	b.cs	5a08 <fwp_drop1+0x98>  // b.hs, b.nlast
    59e4:	8b010273 	add	x19, x19, x1
    59e8:	39400261 	ldrb	w1, [x19]
    59ec:	340000e1 	cbz	w1, 5a08 <fwp_drop1+0x98>
    59f0:	7100043f 	cmp	w1, #0x1
    59f4:	540001e0 	b.eq	5a30 <fwp_drop1+0xc0>  // b.none
    59f8:	7103fc3f 	cmp	w1, #0xff
    59fc:	540002e0 	b.eq	5a58 <fwp_drop1+0xe8>  // b.none
    5a00:	51000421 	sub	w1, w1, #0x1
    5a04:	39000261 	strb	w1, [x19]
    5a08:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a0c:	f94013f5 	ldr	x21, [sp, #32]
    5a10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a14:	d65f03c0 	ret
    5a18:	72003c3f 	tst	w1, #0xffff
    5a1c:	54fffe60 	b.eq	59e8 <fwp_drop1+0x78>  // b.none
    5a20:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a24:	f94013f5 	ldr	x21, [sp, #32]
    5a28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a2c:	d65f03c0 	ret
    5a30:	f9400813 	ldr	x19, [x0, #16]
    5a34:	97fffef8 	bl	5614 <fwp_rc_free_arr>
    5a38:	911702a0 	add	x0, x21, #0x5c0
    5a3c:	f949d801 	ldr	x1, [x0, #5040]
    5a40:	f949ec00 	ldr	x0, [x0, #5080]
    5a44:	cb010261 	sub	x1, x19, x1
    5a48:	eb00403f 	cmp	x1, x0, lsl #16
    5a4c:	54fffde2 	b.cs	5a08 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a50:	aa1303e0 	mov	x0, x19
    5a54:	17ffffd2 	b	599c <fwp_drop1+0x2c>
    5a58:	ca534660 	eor	x0, x19, x19, lsr #17
    5a5c:	911702b5 	add	x21, x21, #0x5c0
    5a60:	ca402400 	eor	x0, x0, x0, lsr #9
    5a64:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5a68:	f94a2400 	ldr	x0, [x0, #5192]
    5a6c:	b5000080 	cbnz	x0, 5a7c <fwp_drop1+0x10c>
    5a70:	14000010 	b	5ab0 <fwp_drop1+0x140>
    5a74:	f9400800 	ldr	x0, [x0, #16]
    5a78:	b40001c0 	cbz	x0, 5ab0 <fwp_drop1+0x140>
    5a7c:	f9400001 	ldr	x1, [x0]
    5a80:	eb13003f 	cmp	x1, x19
    5a84:	54ffff81 	b.ne	5a74 <fwp_drop1+0x104>  // b.any
    5a88:	f9400401 	ldr	x1, [x0, #8]
    5a8c:	d1000421 	sub	x1, x1, #0x1
    5a90:	f9000401 	str	x1, [x0, #8]
    5a94:	f103f83f 	cmp	x1, #0xfe
    5a98:	54fffb81 	b.ne	5a08 <fwp_drop1+0x98>  // b.any
    5a9c:	aa1303e0 	mov	x0, x19
    5aa0:	97fffb74 	bl	4870 <fwp_rc_forget_slot>
    5aa4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5aa8:	39000260 	strb	w0, [x19]
    5aac:	17ffffd7 	b	5a08 <fwp_drop1+0x98>
    5ab0:	90000020 	adrp	x0, 9000 <__modti3+0xe0>
    5ab4:	91188000 	add	x0, x0, #0x620
    5ab8:	97fff772 	bl	3880 <fwp_trap>
    5abc:	d503201f 	nop

0000000000005ac0 <fwp_drop0>:
    5ac0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ac4:	910003fd 	mov	x29, sp
    5ac8:	a90153f3 	stp	x19, x20, [sp, #16]
    5acc:	f90013f5 	str	x21, [sp, #32]
    5ad0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    5ad4:	911702b4 	add	x20, x21, #0x5c0
    5ad8:	f949da81 	ldr	x1, [x20, #5040]
    5adc:	f949ee82 	ldr	x2, [x20, #5080]
    5ae0:	cb010001 	sub	x1, x0, x1
    5ae4:	eb02403f 	cmp	x1, x2, lsl #16
    5ae8:	54000382 	b.cs	5b58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5aec:	d350fc22 	lsr	x2, x1, #16
    5af0:	f949fe84 	ldr	x4, [x20, #5112]
    5af4:	8b020842 	add	x2, x2, x2, lsl #2
    5af8:	d37df042 	lsl	x2, x2, #3
    5afc:	8b020083 	add	x3, x4, x2
    5b00:	f9401073 	ldr	x19, [x3, #32]
    5b04:	b40002b3 	cbz	x19, 5b58 <fwp_drop0+0x98>
    5b08:	38626882 	ldrb	w2, [x4, x2]
    5b0c:	7100085f 	cmp	w2, #0x2
    5b10:	540002c0 	b.eq	5b68 <fwp_drop0+0xa8>  // b.none
    5b14:	7100045f 	cmp	w2, #0x1
    5b18:	54000201 	b.ne	5b58 <fwp_drop0+0x98>  // b.any
    5b1c:	29430864 	ldp	w4, w2, [x3, #24]
    5b20:	92403c21 	and	x1, x1, #0xffff
    5b24:	9b047c21 	mul	x1, x1, x4
    5b28:	d360fc21 	lsr	x1, x1, #32
    5b2c:	eb02003f 	cmp	x1, x2
    5b30:	54000142 	b.cs	5b58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b34:	8b010273 	add	x19, x19, x1
    5b38:	39400261 	ldrb	w1, [x19]
    5b3c:	340000e1 	cbz	w1, 5b58 <fwp_drop0+0x98>
    5b40:	7100043f 	cmp	w1, #0x1
    5b44:	540001e0 	b.eq	5b80 <fwp_drop0+0xc0>  // b.none
    5b48:	7103fc3f 	cmp	w1, #0xff
    5b4c:	540002e0 	b.eq	5ba8 <fwp_drop0+0xe8>  // b.none
    5b50:	51000421 	sub	w1, w1, #0x1
    5b54:	39000261 	strb	w1, [x19]
    5b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b5c:	f94013f5 	ldr	x21, [sp, #32]
    5b60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b64:	d65f03c0 	ret
    5b68:	72003c3f 	tst	w1, #0xffff
    5b6c:	54fffe60 	b.eq	5b38 <fwp_drop0+0x78>  // b.none
    5b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b74:	f94013f5 	ldr	x21, [sp, #32]
    5b78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b7c:	d65f03c0 	ret
    5b80:	f9400813 	ldr	x19, [x0, #16]
    5b84:	97fffea4 	bl	5614 <fwp_rc_free_arr>
    5b88:	911702a0 	add	x0, x21, #0x5c0
    5b8c:	f949d801 	ldr	x1, [x0, #5040]
    5b90:	f949ec00 	ldr	x0, [x0, #5080]
    5b94:	cb010261 	sub	x1, x19, x1
    5b98:	eb00403f 	cmp	x1, x0, lsl #16
    5b9c:	54fffde2 	b.cs	5b58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ba0:	aa1303e0 	mov	x0, x19
    5ba4:	17ffffd2 	b	5aec <fwp_drop0+0x2c>
    5ba8:	ca534660 	eor	x0, x19, x19, lsr #17
    5bac:	911702b5 	add	x21, x21, #0x5c0
    5bb0:	ca402400 	eor	x0, x0, x0, lsr #9
    5bb4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5bb8:	f94a2400 	ldr	x0, [x0, #5192]
    5bbc:	b5000080 	cbnz	x0, 5bcc <fwp_drop0+0x10c>
    5bc0:	14000010 	b	5c00 <fwp_drop0+0x140>
    5bc4:	f9400800 	ldr	x0, [x0, #16]
    5bc8:	b40001c0 	cbz	x0, 5c00 <fwp_drop0+0x140>
    5bcc:	f9400001 	ldr	x1, [x0]
    5bd0:	eb13003f 	cmp	x1, x19
    5bd4:	54ffff81 	b.ne	5bc4 <fwp_drop0+0x104>  // b.any
    5bd8:	f9400401 	ldr	x1, [x0, #8]
    5bdc:	d1000421 	sub	x1, x1, #0x1
    5be0:	f9000401 	str	x1, [x0, #8]
    5be4:	f103f83f 	cmp	x1, #0xfe
    5be8:	54fffb81 	b.ne	5b58 <fwp_drop0+0x98>  // b.any
    5bec:	aa1303e0 	mov	x0, x19
    5bf0:	97fffb20 	bl	4870 <fwp_rc_forget_slot>
    5bf4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5bf8:	39000260 	strb	w0, [x19]
    5bfc:	17ffffd7 	b	5b58 <fwp_drop0+0x98>
    5c00:	90000020 	adrp	x0, 9000 <__modti3+0xe0>
    5c04:	91188000 	add	x0, x0, #0x620
    5c08:	97fff71e 	bl	3880 <fwp_trap>
    5c0c:	d503201f 	nop

0000000000005c10 <fwp_closure_drop>:
    5c10:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc20>
    5c14:	911700a4 	add	x4, x5, #0x5c0
    5c18:	aa0003e1 	mov	x1, x0
    5c1c:	f949d882 	ldr	x2, [x4, #5040]
    5c20:	f949ec80 	ldr	x0, [x4, #5080]
    5c24:	cb020022 	sub	x2, x1, x2
    5c28:	eb00405f 	cmp	x2, x0, lsl #16
    5c2c:	54000662 	b.cs	5cf8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5c30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5c34:	d350fc43 	lsr	x3, x2, #16
    5c38:	910003fd 	mov	x29, sp
    5c3c:	8b030863 	add	x3, x3, x3, lsl #2
    5c40:	f949fc84 	ldr	x4, [x4, #5112]
    5c44:	d37df063 	lsl	x3, x3, #3
    5c48:	f9000bf3 	str	x19, [sp, #16]
    5c4c:	8b030080 	add	x0, x4, x3
    5c50:	f9401013 	ldr	x19, [x0, #32]
    5c54:	b40002b3 	cbz	x19, 5ca8 <fwp_closure_drop+0x98>
    5c58:	38636883 	ldrb	w3, [x4, x3]
    5c5c:	7100087f 	cmp	w3, #0x2
    5c60:	54000420 	b.eq	5ce4 <fwp_closure_drop+0xd4>  // b.none
    5c64:	7100047f 	cmp	w3, #0x1
    5c68:	54000201 	b.ne	5ca8 <fwp_closure_drop+0x98>  // b.any
    5c6c:	29430003 	ldp	w3, w0, [x0, #24]
    5c70:	92403c42 	and	x2, x2, #0xffff
    5c74:	9b037c42 	mul	x2, x2, x3
    5c78:	d360fc42 	lsr	x2, x2, #32
    5c7c:	eb00005f 	cmp	x2, x0
    5c80:	54000142 	b.cs	5ca8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5c84:	8b020273 	add	x19, x19, x2
    5c88:	39400260 	ldrb	w0, [x19]
    5c8c:	340000e0 	cbz	w0, 5ca8 <fwp_closure_drop+0x98>
    5c90:	7100041f 	cmp	w0, #0x1
    5c94:	54000100 	b.eq	5cb4 <fwp_closure_drop+0xa4>  // b.none
    5c98:	7103fc1f 	cmp	w0, #0xff
    5c9c:	54000300 	b.eq	5cfc <fwp_closure_drop+0xec>  // b.none
    5ca0:	51000400 	sub	w0, w0, #0x1
    5ca4:	39000260 	strb	w0, [x19]
    5ca8:	f9400bf3 	ldr	x19, [sp, #16]
    5cac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cb0:	d65f03c0 	ret
    5cb4:	d53bd040 	mrs	x0, tpidr_el0
    5cb8:	91400000 	add	x0, x0, #0x0, lsl #12
    5cbc:	91004000 	add	x0, x0, #0x10
    5cc0:	f9400000 	ldr	x0, [x0]
    5cc4:	b4000080 	cbz	x0, 5cd4 <fwp_closure_drop+0xc4>
    5cc8:	f9400bf3 	ldr	x19, [sp, #16]
    5ccc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cd0:	17fff705 	b	38e4 <fwp_closure_drop_push>
    5cd4:	f9400bf3 	ldr	x19, [sp, #16]
    5cd8:	aa0103e0 	mov	x0, x1
    5cdc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ce0:	17fff770 	b	3aa0 <fwp_closure_drop.part.0>
    5ce4:	72003c5f 	tst	w2, #0xffff
    5ce8:	54fffd00 	b.eq	5c88 <fwp_closure_drop+0x78>  // b.none
    5cec:	f9400bf3 	ldr	x19, [sp, #16]
    5cf0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cf4:	d65f03c0 	ret
    5cf8:	d65f03c0 	ret
    5cfc:	ca534660 	eor	x0, x19, x19, lsr #17
    5d00:	911700a5 	add	x5, x5, #0x5c0
    5d04:	ca402400 	eor	x0, x0, x0, lsr #9
    5d08:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5d0c:	f94a2400 	ldr	x0, [x0, #5192]
    5d10:	b5000080 	cbnz	x0, 5d20 <fwp_closure_drop+0x110>
    5d14:	14000010 	b	5d54 <fwp_closure_drop+0x144>
    5d18:	f9400800 	ldr	x0, [x0, #16]
    5d1c:	b40001c0 	cbz	x0, 5d54 <fwp_closure_drop+0x144>
    5d20:	f9400001 	ldr	x1, [x0]
    5d24:	eb13003f 	cmp	x1, x19
    5d28:	54ffff81 	b.ne	5d18 <fwp_closure_drop+0x108>  // b.any
    5d2c:	f9400401 	ldr	x1, [x0, #8]
    5d30:	d1000421 	sub	x1, x1, #0x1
    5d34:	f9000401 	str	x1, [x0, #8]
    5d38:	f103f83f 	cmp	x1, #0xfe
    5d3c:	54fffb61 	b.ne	5ca8 <fwp_closure_drop+0x98>  // b.any
    5d40:	aa1303e0 	mov	x0, x19
    5d44:	97fffacb 	bl	4870 <fwp_rc_forget_slot>
    5d48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d4c:	39000260 	strb	w0, [x19]
    5d50:	17ffffd6 	b	5ca8 <fwp_closure_drop+0x98>
    5d54:	90000020 	adrp	x0, 9000 <__modti3+0xe0>
    5d58:	91188000 	add	x0, x0, #0x620
    5d5c:	97fff6c9 	bl	3880 <fwp_trap>

0000000000005d60 <fwp_owned_tape_release>:
    5d60:	b4000940 	cbz	x0, 5e88 <fwp_owned_tape_release+0x128>
    5d64:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d68:	910003fd 	mov	x29, sp
    5d6c:	a90153f3 	stp	x19, x20, [sp, #16]
    5d70:	aa0003f3 	mov	x19, x0
    5d74:	f9400000 	ldr	x0, [x0]
    5d78:	b4000060 	cbz	x0, 5d84 <fwp_owned_tape_release+0x24>
    5d7c:	f9400661 	ldr	x1, [x19, #8]
    5d80:	f9000401 	str	x1, [x0, #8]
    5d84:	f9400661 	ldr	x1, [x19, #8]
    5d88:	b4000041 	cbz	x1, 5d90 <fwp_owned_tape_release+0x30>
    5d8c:	f9000020 	str	x0, [x1]
    5d90:	f9400a60 	ldr	x0, [x19, #16]
    5d94:	f9403401 	ldr	x1, [x0, #104]
    5d98:	b40005c1 	cbz	x1, 5e50 <fwp_owned_tape_release+0xf0>
    5d9c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5da0:	eb00005f 	cmp	x2, x0
    5da4:	540002ed 	b.le	5e00 <fwp_owned_tape_release+0xa0>
    5da8:	d2800014 	mov	x20, #0x0                   	// #0
    5dac:	f90013f5 	str	x21, [sp, #32]
    5db0:	d2800015 	mov	x21, #0x0                   	// #0
    5db4:	d503201f 	nop
    5db8:	f9402260 	ldr	x0, [x19, #64]
    5dbc:	910006b5 	add	x21, x21, #0x1
    5dc0:	f8746800 	ldr	x0, [x0, x20]
    5dc4:	d63f0020 	blr	x1
    5dc8:	f9402260 	ldr	x0, [x19, #64]
    5dcc:	f9400a61 	ldr	x1, [x19, #16]
    5dd0:	8b140000 	add	x0, x0, x20
    5dd4:	91004294 	add	x20, x20, #0x10
    5dd8:	f9400400 	ldr	x0, [x0, #8]
    5ddc:	f9403421 	ldr	x1, [x1, #104]
    5de0:	d63f0020 	blr	x1
    5de4:	a9450261 	ldp	x1, x0, [x19, #80]
    5de8:	cb010000 	sub	x0, x0, x1
    5dec:	eb15001f 	cmp	x0, x21
    5df0:	f9400a60 	ldr	x0, [x19, #16]
    5df4:	f9403401 	ldr	x1, [x0, #104]
    5df8:	54fffe0c 	b.gt	5db8 <fwp_owned_tape_release+0x58>
    5dfc:	f94013f5 	ldr	x21, [sp, #32]
    5e00:	f9403663 	ldr	x3, [x19, #104]
    5e04:	f9401262 	ldr	x2, [x19, #32]
    5e08:	f100007f 	cmp	x3, #0x0
    5e0c:	540001ed 	b.le	5e48 <fwp_owned_tape_release+0xe8>
    5e10:	d2800014 	mov	x20, #0x0                   	// #0
    5e14:	d503201f 	nop
    5e18:	f9402660 	ldr	x0, [x19, #72]
    5e1c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5e20:	eb02001f 	cmp	x0, x2
    5e24:	540000c0 	b.eq	5e3c <fwp_owned_tape_release+0xdc>  // b.none
    5e28:	d63f0020 	blr	x1
    5e2c:	f9400a60 	ldr	x0, [x19, #16]
    5e30:	f9401262 	ldr	x2, [x19, #32]
    5e34:	f9403663 	ldr	x3, [x19, #104]
    5e38:	f9403401 	ldr	x1, [x0, #104]
    5e3c:	91000694 	add	x20, x20, #0x1
    5e40:	eb14007f 	cmp	x3, x20
    5e44:	54fffeac 	b.gt	5e18 <fwp_owned_tape_release+0xb8>
    5e48:	aa0203e0 	mov	x0, x2
    5e4c:	d63f0020 	blr	x1
    5e50:	f9401660 	ldr	x0, [x19, #40]
    5e54:	97ffff6f 	bl	5c10 <fwp_closure_drop>
    5e58:	f9401a60 	ldr	x0, [x19, #48]
    5e5c:	97ffff6d 	bl	5c10 <fwp_closure_drop>
    5e60:	f9401e60 	ldr	x0, [x19, #56]
    5e64:	97ffff6b 	bl	5c10 <fwp_closure_drop>
    5e68:	f9402260 	ldr	x0, [x19, #64]
    5e6c:	97fffb21 	bl	4af0 <fwp_mem_free>
    5e70:	f9402660 	ldr	x0, [x19, #72]
    5e74:	97fffb1f 	bl	4af0 <fwp_mem_free>
    5e78:	aa1303e0 	mov	x0, x19
    5e7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e84:	17fffb1b 	b	4af0 <fwp_mem_free>
    5e88:	d65f03c0 	ret
    5e8c:	d503201f 	nop

0000000000005e90 <fwp_tape_finish>:
    5e90:	d10203ff 	sub	sp, sp, #0x80
    5e94:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5e98:	f947f421 	ldr	x1, [x1, #4072]
    5e9c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5ea0:	910103fd 	add	x29, sp, #0x40
    5ea4:	a90553f3 	stp	x19, x20, [sp, #80]
    5ea8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5eac:	a90763f7 	stp	x23, x24, [sp, #112]
    5eb0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5eb4:	91018316 	add	x22, x24, #0x60
    5eb8:	f9400022 	ldr	x2, [x1]
    5ebc:	f9001fe2 	str	x2, [sp, #56]
    5ec0:	d2800002 	mov	x2, #0x0                   	// #0
    5ec4:	910262c0 	add	x0, x22, #0x98
    5ec8:	97fff58e 	bl	3500 <fwp_tape_buffers_dispose>
    5ecc:	f9006adf 	str	xzr, [x22, #208]
    5ed0:	f9404ac0 	ldr	x0, [x22, #144]
    5ed4:	f100001f 	cmp	x0, #0x0
    5ed8:	5400030d 	b.le	5f38 <fwp_tape_finish+0xa8>
    5edc:	910003f7 	mov	x23, sp
    5ee0:	d2800015 	mov	x21, #0x0                   	// #0
    5ee4:	d2800014 	mov	x20, #0x0                   	// #0
    5ee8:	f94002d3 	ldr	x19, [x22]
    5eec:	91000694 	add	x20, x20, #0x1
    5ef0:	8b150273 	add	x19, x19, x21
    5ef4:	9101a2b5 	add	x21, x21, #0x68
    5ef8:	aa1303e0 	mov	x0, x19
    5efc:	97fff445 	bl	3010 <fwp_tape_unlink_scope>
    5f00:	aa1703e0 	mov	x0, x23
    5f04:	f9401261 	ldr	x1, [x19, #32]
    5f08:	f90003e1 	str	x1, [sp]
    5f0c:	f9401a62 	ldr	x2, [x19, #48]
    5f10:	f9000be2 	str	x2, [sp, #16]
    5f14:	f9402261 	ldr	x1, [x19, #64]
    5f18:	f90013e1 	str	x1, [sp, #32]
    5f1c:	97fff579 	bl	3500 <fwp_tape_buffers_dispose>
    5f20:	f9403260 	ldr	x0, [x19, #96]
    5f24:	97ffff8f 	bl	5d60 <fwp_owned_tape_release>
    5f28:	f900327f 	str	xzr, [x19, #96]
    5f2c:	f9404ac0 	ldr	x0, [x22, #144]
    5f30:	eb14001f 	cmp	x0, x20
    5f34:	54fffdac 	b.gt	5ee8 <fwp_tape_finish+0x58>
    5f38:	f9403300 	ldr	x0, [x24, #96]
    5f3c:	91018313 	add	x19, x24, #0x60
    5f40:	97fff2a4 	bl	29d0 <free@plt>
    5f44:	f900331f 	str	xzr, [x24, #96]
    5f48:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5f4c:	f947f400 	ldr	x0, [x0, #4072]
    5f50:	f9004a7f 	str	xzr, [x19, #144]
    5f54:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    5f58:	f9401fe2 	ldr	x2, [sp, #56]
    5f5c:	f9400001 	ldr	x1, [x0]
    5f60:	eb010042 	subs	x2, x2, x1
    5f64:	d2800001 	mov	x1, #0x0                   	// #0
    5f68:	540000e1 	b.ne	5f84 <fwp_tape_finish+0xf4>  // b.any
    5f6c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5f70:	a94553f3 	ldp	x19, x20, [sp, #80]
    5f74:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5f78:	a94763f7 	ldp	x23, x24, [sp, #112]
    5f7c:	910203ff 	add	sp, sp, #0x80
    5f80:	d65f03c0 	ret
    5f84:	97fff263 	bl	2910 <__stack_chk_fail@plt>
    5f88:	d503201f 	nop
    5f8c:	d503201f 	nop

0000000000005f90 <fwp_tape_scope_release>:
    5f90:	d10243ff 	sub	sp, sp, #0x90
    5f94:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f98:	910103fd 	add	x29, sp, #0x40
    5f9c:	a90553f3 	stp	x19, x20, [sp, #80]
    5fa0:	aa0003f4 	mov	x20, x0
    5fa4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5fa8:	f947f400 	ldr	x0, [x0, #4072]
    5fac:	b9400285 	ldr	w5, [x20]
    5fb0:	f9400001 	ldr	x1, [x0]
    5fb4:	f9001fe1 	str	x1, [sp, #56]
    5fb8:	d2800001 	mov	x1, #0x0                   	// #0
    5fbc:	37f806c5 	tbnz	w5, #31, 6094 <fwp_tape_scope_release+0x104>
    5fc0:	a90763f7 	stp	x23, x24, [sp, #112]
    5fc4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5fc8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5fcc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5fd0:	f00000d3 	adrp	x19, 20000 <__data_start>
    5fd4:	910003f7 	mov	x23, sp
    5fd8:	91018273 	add	x19, x19, #0x60
    5fdc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5fe0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5fe4:	52800d16 	mov	w22, #0x68                  	// #104
    5fe8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5fec:	f90043f9 	str	x25, [sp, #128]
    5ff0:	14000006 	b	6008 <fwp_tape_scope_release+0x78>
    5ff4:	97fff543 	bl	3500 <fwp_tape_buffers_dispose>
    5ff8:	aa1903e0 	mov	x0, x25
    5ffc:	97ffff59 	bl	5d60 <fwp_owned_tape_release>
    6000:	b9400285 	ldr	w5, [x20]
    6004:	37f80425 	tbnz	w5, #31, 6088 <fwp_tape_scope_release+0xf8>
    6008:	f9400266 	ldr	x6, [x19]
    600c:	9b367ca5 	smull	x5, w5, w22
    6010:	8b0500c0 	add	x0, x6, x5
    6014:	97fff3ff 	bl	3010 <fwp_tape_unlink_scope>
    6018:	ad410001 	ldp	q1, q0, [x0, #32]
    601c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6020:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6024:	f9400c03 	ldr	x3, [x0, #24]
    6028:	ad0003e1 	stp	q1, q0, [sp]
    602c:	b86568c1 	ldr	w1, [x6, x5]
    6030:	a9440804 	ldp	x4, x2, [x0, #64]
    6034:	b900041f 	str	wzr, [x0, #4]
    6038:	f9403019 	ldr	x25, [x0, #96]
    603c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6040:	f9000c1f 	str	xzr, [x0, #24]
    6044:	a9020fe4 	stp	x4, x3, [sp, #32]
    6048:	f9001be2 	str	x2, [sp, #48]
    604c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6050:	f900301f 	str	xzr, [x0, #96]
    6054:	6b15003f 	cmp	w1, w21
    6058:	540000e8 	b.hi	6074 <fwp_tape_scope_release+0xe4>  // b.pmore
    605c:	9343fca5 	asr	x5, x5, #3
    6060:	f9407660 	ldr	x0, [x19, #232]
    6064:	9b187ca5 	mul	x5, x5, x24
    6068:	eb0000bf 	cmp	x5, x0
    606c:	5400004a 	b.ge	6074 <fwp_tape_scope_release+0xe4>  // b.tcont
    6070:	f9007665 	str	x5, [x19, #232]
    6074:	aa1703e0 	mov	x0, x23
    6078:	b5fffbf9 	cbnz	x25, 5ff4 <fwp_tape_scope_release+0x64>
    607c:	97fff8e1 	bl	4400 <fwp_tape_buffers_release>
    6080:	b9400285 	ldr	w5, [x20]
    6084:	36fffc25 	tbz	w5, #31, 6008 <fwp_tape_scope_release+0x78>
    6088:	a9465bf5 	ldp	x21, x22, [sp, #96]
    608c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6090:	f94043f9 	ldr	x25, [sp, #128]
    6094:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6098:	f947f400 	ldr	x0, [x0, #4072]
    609c:	f9401fe2 	ldr	x2, [sp, #56]
    60a0:	f9400001 	ldr	x1, [x0]
    60a4:	eb010042 	subs	x2, x2, x1
    60a8:	d2800001 	mov	x1, #0x0                   	// #0
    60ac:	540000a1 	b.ne	60c0 <fwp_tape_scope_release+0x130>  // b.any
    60b0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60b4:	a94553f3 	ldp	x19, x20, [sp, #80]
    60b8:	910243ff 	add	sp, sp, #0x90
    60bc:	d65f03c0 	ret
    60c0:	a9065bf5 	stp	x21, x22, [sp, #96]
    60c4:	a90763f7 	stp	x23, x24, [sp, #112]
    60c8:	f90043f9 	str	x25, [sp, #128]
    60cc:	97fff211 	bl	2910 <__stack_chk_fail@plt>

00000000000060d0 <fwp_drop4>:
    60d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    60d4:	910003fd 	mov	x29, sp
    60d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    60dc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc20>
    60e0:	911702d5 	add	x21, x22, #0x5c0
    60e4:	a90153f3 	stp	x19, x20, [sp, #16]
    60e8:	aa0003f3 	mov	x19, x0
    60ec:	f949daa1 	ldr	x1, [x21, #5040]
    60f0:	f949eea0 	ldr	x0, [x21, #5080]
    60f4:	cb010261 	sub	x1, x19, x1
    60f8:	eb00403f 	cmp	x1, x0, lsl #16
    60fc:	54000382 	b.cs	616c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6100:	d350fc22 	lsr	x2, x1, #16
    6104:	f949fea3 	ldr	x3, [x21, #5112]
    6108:	8b020842 	add	x2, x2, x2, lsl #2
    610c:	d37df042 	lsl	x2, x2, #3
    6110:	8b020060 	add	x0, x3, x2
    6114:	f9401014 	ldr	x20, [x0, #32]
    6118:	b40002b4 	cbz	x20, 616c <fwp_drop4+0x9c>
    611c:	38626862 	ldrb	w2, [x3, x2]
    6120:	7100085f 	cmp	w2, #0x2
    6124:	540002c0 	b.eq	617c <fwp_drop4+0xac>  // b.none
    6128:	7100045f 	cmp	w2, #0x1
    612c:	54000201 	b.ne	616c <fwp_drop4+0x9c>  // b.any
    6130:	29430002 	ldp	w2, w0, [x0, #24]
    6134:	92403c21 	and	x1, x1, #0xffff
    6138:	9b027c21 	mul	x1, x1, x2
    613c:	d360fc21 	lsr	x1, x1, #32
    6140:	eb00003f 	cmp	x1, x0
    6144:	54000142 	b.cs	616c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6148:	8b010294 	add	x20, x20, x1
    614c:	39400280 	ldrb	w0, [x20]
    6150:	340000e0 	cbz	w0, 616c <fwp_drop4+0x9c>
    6154:	7100041f 	cmp	w0, #0x1
    6158:	540001e0 	b.eq	6194 <fwp_drop4+0xc4>  // b.none
    615c:	7103fc1f 	cmp	w0, #0xff
    6160:	540007c0 	b.eq	6258 <fwp_drop4+0x188>  // b.none
    6164:	51000400 	sub	w0, w0, #0x1
    6168:	39000280 	strb	w0, [x20]
    616c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6170:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6174:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6178:	d65f03c0 	ret
    617c:	72003c3f 	tst	w1, #0xffff
    6180:	54fffe60 	b.eq	614c <fwp_drop4+0x7c>  // b.none
    6184:	a94153f3 	ldp	x19, x20, [sp, #16]
    6188:	a9425bf5 	ldp	x21, x22, [sp, #32]
    618c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6190:	d65f03c0 	ret
    6194:	911702c2 	add	x2, x22, #0x5c0
    6198:	f9400660 	ldr	x0, [x19, #8]
    619c:	f949d841 	ldr	x1, [x2, #5040]
    61a0:	f949ec42 	ldr	x2, [x2, #5080]
    61a4:	cb010001 	sub	x1, x0, x1
    61a8:	eb02403f 	cmp	x1, x2, lsl #16
    61ac:	54000362 	b.cs	6218 <fwp_drop4+0x148>  // b.hs, b.nlast
    61b0:	d350fc22 	lsr	x2, x1, #16
    61b4:	8b020842 	add	x2, x2, x2, lsl #2
    61b8:	d37df042 	lsl	x2, x2, #3
    61bc:	8b020064 	add	x4, x3, x2
    61c0:	f9401094 	ldr	x20, [x4, #32]
    61c4:	b40002b4 	cbz	x20, 6218 <fwp_drop4+0x148>
    61c8:	38626862 	ldrb	w2, [x3, x2]
    61cc:	7100085f 	cmp	w2, #0x2
    61d0:	540003e0 	b.eq	624c <fwp_drop4+0x17c>  // b.none
    61d4:	7100045f 	cmp	w2, #0x1
    61d8:	54000201 	b.ne	6218 <fwp_drop4+0x148>  // b.any
    61dc:	29430883 	ldp	w3, w2, [x4, #24]
    61e0:	92403c21 	and	x1, x1, #0xffff
    61e4:	9b037c21 	mul	x1, x1, x3
    61e8:	d360fc21 	lsr	x1, x1, #32
    61ec:	eb02003f 	cmp	x1, x2
    61f0:	54000142 	b.cs	6218 <fwp_drop4+0x148>  // b.hs, b.nlast
    61f4:	8b010294 	add	x20, x20, x1
    61f8:	39400281 	ldrb	w1, [x20]
    61fc:	340000e1 	cbz	w1, 6218 <fwp_drop4+0x148>
    6200:	7100043f 	cmp	w1, #0x1
    6204:	54000200 	b.eq	6244 <fwp_drop4+0x174>  // b.none
    6208:	7103fc3f 	cmp	w1, #0xff
    620c:	54000580 	b.eq	62bc <fwp_drop4+0x1ec>  // b.none
    6210:	51000421 	sub	w1, w1, #0x1
    6214:	39000281 	strb	w1, [x20]
    6218:	f9400a74 	ldr	x20, [x19, #16]
    621c:	aa1303e0 	mov	x0, x19
    6220:	97fffcfd 	bl	5614 <fwp_rc_free_arr>
    6224:	911702c0 	add	x0, x22, #0x5c0
    6228:	f949d801 	ldr	x1, [x0, #5040]
    622c:	f949ec00 	ldr	x0, [x0, #5080]
    6230:	cb010281 	sub	x1, x20, x1
    6234:	eb00403f 	cmp	x1, x0, lsl #16
    6238:	54fff9a2 	b.cs	616c <fwp_drop4+0x9c>  // b.hs, b.nlast
    623c:	aa1403f3 	mov	x19, x20
    6240:	17ffffb0 	b	6100 <fwp_drop4+0x30>
    6244:	97fffcf4 	bl	5614 <fwp_rc_free_arr>
    6248:	17fffff4 	b	6218 <fwp_drop4+0x148>
    624c:	72003c3f 	tst	w1, #0xffff
    6250:	54fffe41 	b.ne	6218 <fwp_drop4+0x148>  // b.any
    6254:	17ffffe9 	b	61f8 <fwp_drop4+0x128>
    6258:	ca544681 	eor	x1, x20, x20, lsr #17
    625c:	911702c0 	add	x0, x22, #0x5c0
    6260:	ca412421 	eor	x1, x1, x1, lsr #9
    6264:	8b210c01 	add	x1, x0, w1, uxtb #3
    6268:	f94a2420 	ldr	x0, [x1, #5192]
    626c:	b5000080 	cbnz	x0, 627c <fwp_drop4+0x1ac>
    6270:	14000010 	b	62b0 <fwp_drop4+0x1e0>
    6274:	f9400800 	ldr	x0, [x0, #16]
    6278:	b40001c0 	cbz	x0, 62b0 <fwp_drop4+0x1e0>
    627c:	f9400001 	ldr	x1, [x0]
    6280:	eb14003f 	cmp	x1, x20
    6284:	54ffff81 	b.ne	6274 <fwp_drop4+0x1a4>  // b.any
    6288:	f9400401 	ldr	x1, [x0, #8]
    628c:	d1000421 	sub	x1, x1, #0x1
    6290:	f9000401 	str	x1, [x0, #8]
    6294:	f103f83f 	cmp	x1, #0xfe
    6298:	54fff6a1 	b.ne	616c <fwp_drop4+0x9c>  // b.any
    629c:	aa1403e0 	mov	x0, x20
    62a0:	97fff974 	bl	4870 <fwp_rc_forget_slot>
    62a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62a8:	39000280 	strb	w0, [x20]
    62ac:	17ffffb0 	b	616c <fwp_drop4+0x9c>
    62b0:	f0000000 	adrp	x0, 9000 <__modti3+0xe0>
    62b4:	91188000 	add	x0, x0, #0x620
    62b8:	97fff572 	bl	3880 <fwp_trap>
    62bc:	ca544680 	eor	x0, x20, x20, lsr #17
    62c0:	911702c1 	add	x1, x22, #0x5c0
    62c4:	ca402400 	eor	x0, x0, x0, lsr #9
    62c8:	8b200c20 	add	x0, x1, w0, uxtb #3
    62cc:	f94a2400 	ldr	x0, [x0, #5192]
    62d0:	b5000080 	cbnz	x0, 62e0 <fwp_drop4+0x210>
    62d4:	17fffff7 	b	62b0 <fwp_drop4+0x1e0>
    62d8:	f9400800 	ldr	x0, [x0, #16]
    62dc:	b4fffea0 	cbz	x0, 62b0 <fwp_drop4+0x1e0>
    62e0:	f9400001 	ldr	x1, [x0]
    62e4:	eb14003f 	cmp	x1, x20
    62e8:	54ffff81 	b.ne	62d8 <fwp_drop4+0x208>  // b.any
    62ec:	f9400401 	ldr	x1, [x0, #8]
    62f0:	d1000421 	sub	x1, x1, #0x1
    62f4:	f9000401 	str	x1, [x0, #8]
    62f8:	f103f83f 	cmp	x1, #0xfe
    62fc:	54fff8e1 	b.ne	6218 <fwp_drop4+0x148>  // b.any
    6300:	aa1403e0 	mov	x0, x20
    6304:	97fff95b 	bl	4870 <fwp_rc_forget_slot>
    6308:	12800020 	mov	w0, #0xfffffffe            	// #-2
    630c:	39000280 	strb	w0, [x20]
    6310:	17ffffc2 	b	6218 <fwp_drop4+0x148>

0000000000006314 <fwp_arg_drop37>:
    6314:	7100003f 	cmp	w1, #0x0
    6318:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    631c:	54000041 	b.ne	6324 <fwp_arg_drop37+0x10>  // b.any
    6320:	d65f03c0 	ret
    6324:	f9400000 	ldr	x0, [x0]
    6328:	17ffff6a 	b	60d0 <fwp_drop4>
    632c:	d503201f 	nop

0000000000006330 <fwp_task_dispose>:
    6330:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6334:	910003fd 	mov	x29, sp
    6338:	f9000bf3 	str	x19, [sp, #16]
    633c:	aa0003f3 	mov	x19, x0
    6340:	39414000 	ldrb	w0, [x0, #80]
    6344:	36000720 	tbz	w0, #0, 6428 <fwp_task_dispose+0xf8>
    6348:	f9400a60 	ldr	x0, [x19, #16]
    634c:	b50006e0 	cbnz	x0, 6428 <fwp_task_dispose+0xf8>
    6350:	a9478660 	ldp	x0, x1, [x19, #120]
    6354:	39014e7f 	strb	wzr, [x19, #83]
    6358:	f9003e7f 	str	xzr, [x19, #120]
    635c:	f100003f 	cmp	x1, #0x0
    6360:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6364:	54000040 	b.eq	636c <fwp_task_dispose+0x3c>  // b.none
    6368:	d63f0020 	blr	x1
    636c:	f9405660 	ldr	x0, [x19, #168]
    6370:	97fff9e0 	bl	4af0 <fwp_mem_free>
    6374:	f900567f 	str	xzr, [x19, #168]
    6378:	b9405e60 	ldr	w0, [x19, #92]
    637c:	7100041f 	cmp	w0, #0x1
    6380:	54000420 	b.eq	6404 <fwp_task_dispose+0xd4>  // b.none
    6384:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    6388:	91170042 	add	x2, x2, #0x5c0
    638c:	f949d840 	ldr	x0, [x2, #5040]
    6390:	f949ec41 	ldr	x1, [x2, #5080]
    6394:	cb000260 	sub	x0, x19, x0
    6398:	eb01401f 	cmp	x0, x1, lsl #16
    639c:	540002e2 	b.cs	63f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    63a0:	d350fc01 	lsr	x1, x0, #16
    63a4:	f949fc44 	ldr	x4, [x2, #5112]
    63a8:	8b010821 	add	x1, x1, x1, lsl #2
    63ac:	d37df021 	lsl	x1, x1, #3
    63b0:	8b010083 	add	x3, x4, x1
    63b4:	f9401062 	ldr	x2, [x3, #32]
    63b8:	b4000202 	cbz	x2, 63f8 <fwp_task_dispose+0xc8>
    63bc:	38616881 	ldrb	w1, [x4, x1]
    63c0:	7100083f 	cmp	w1, #0x2
    63c4:	54000280 	b.eq	6414 <fwp_task_dispose+0xe4>  // b.none
    63c8:	7100043f 	cmp	w1, #0x1
    63cc:	54000161 	b.ne	63f8 <fwp_task_dispose+0xc8>  // b.any
    63d0:	29430464 	ldp	w4, w1, [x3, #24]
    63d4:	92403c00 	and	x0, x0, #0xffff
    63d8:	9b047c00 	mul	x0, x0, x4
    63dc:	d360fc00 	lsr	x0, x0, #32
    63e0:	eb01001f 	cmp	x0, x1
    63e4:	540000a2 	b.cs	63f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    63e8:	8b000042 	add	x2, x2, x0
    63ec:	39400040 	ldrb	w0, [x2]
    63f0:	7100041f 	cmp	w0, #0x1
    63f4:	54000080 	b.eq	6404 <fwp_task_dispose+0xd4>  // b.none
    63f8:	f9400bf3 	ldr	x19, [sp, #16]
    63fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6400:	d65f03c0 	ret
    6404:	aa1303e0 	mov	x0, x19
    6408:	f9400bf3 	ldr	x19, [sp, #16]
    640c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6410:	17fff9b8 	b	4af0 <fwp_mem_free>
    6414:	72003c1f 	tst	w0, #0xffff
    6418:	54fffea0 	b.eq	63ec <fwp_task_dispose+0xbc>  // b.none
    641c:	f9400bf3 	ldr	x19, [sp, #16]
    6420:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6424:	d65f03c0 	ret
    6428:	97fff14e 	bl	2960 <abort@plt>
    642c:	d503201f 	nop

0000000000006430 <fwp_free_zombie>:
    6430:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6434:	910003fd 	mov	x29, sp
    6438:	a90153f3 	stp	x19, x20, [sp, #16]
    643c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6440:	91018281 	add	x1, x20, #0x60
    6444:	f9407833 	ldr	x19, [x1, #240]
    6448:	b4000333 	cbz	x19, 64ac <fwp_free_zombie+0x7c>
    644c:	f9400820 	ldr	x0, [x1, #16]
    6450:	eb00027f 	cmp	x19, x0
    6454:	540002c0 	b.eq	64ac <fwp_free_zombie+0x7c>  // b.none
    6458:	b940f822 	ldr	w2, [x1, #248]
    645c:	f9400a60 	ldr	x0, [x19, #16]
    6460:	7100fc5f 	cmp	w2, #0x3f
    6464:	5400078c 	b.gt	6554 <fwp_free_zombie+0x124>
    6468:	91040023 	add	x3, x1, #0x100
    646c:	11000444 	add	w4, w2, #0x1
    6470:	b900f824 	str	w4, [x1, #248]
    6474:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6478:	f822d860 	str	x0, [x3, w2, sxtw #3]
    647c:	a9530261 	ldp	x1, x0, [x19, #304]
    6480:	b4000741 	cbz	x1, 6568 <fwp_free_zombie+0x138>
    6484:	f9009c20 	str	x0, [x1, #312]
    6488:	b4000040 	cbz	x0, 6490 <fwp_free_zombie+0x60>
    648c:	f9009801 	str	x1, [x0, #304]
    6490:	91018294 	add	x20, x20, #0x60
    6494:	b9405e60 	ldr	w0, [x19, #92]
    6498:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    649c:	f9007a9f 	str	xzr, [x20, #240]
    64a0:	34000140 	cbz	w0, 64c8 <fwp_free_zombie+0x98>
    64a4:	7100041f 	cmp	w0, #0x1
    64a8:	54000080 	b.eq	64b8 <fwp_free_zombie+0x88>  // b.none
    64ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    64b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64b4:	d65f03c0 	ret
    64b8:	aa1303e0 	mov	x0, x19
    64bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    64c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64c4:	17ffff9b 	b	6330 <fwp_task_dispose>
    64c8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc20>
    64cc:	91170082 	add	x2, x4, #0x5c0
    64d0:	f949d841 	ldr	x1, [x2, #5040]
    64d4:	f949ec40 	ldr	x0, [x2, #5080]
    64d8:	cb010261 	sub	x1, x19, x1
    64dc:	eb00403f 	cmp	x1, x0, lsl #16
    64e0:	54fffe62 	b.cs	64ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    64e4:	d350fc20 	lsr	x0, x1, #16
    64e8:	f949fc43 	ldr	x3, [x2, #5112]
    64ec:	8b000800 	add	x0, x0, x0, lsl #2
    64f0:	d37df000 	lsl	x0, x0, #3
    64f4:	8b000062 	add	x2, x3, x0
    64f8:	f9401054 	ldr	x20, [x2, #32]
    64fc:	b4fffd94 	cbz	x20, 64ac <fwp_free_zombie+0x7c>
    6500:	38606860 	ldrb	w0, [x3, x0]
    6504:	7100081f 	cmp	w0, #0x2
    6508:	54000360 	b.eq	6574 <fwp_free_zombie+0x144>  // b.none
    650c:	7100041f 	cmp	w0, #0x1
    6510:	54fffce1 	b.ne	64ac <fwp_free_zombie+0x7c>  // b.any
    6514:	29430043 	ldp	w3, w0, [x2, #24]
    6518:	92403c21 	and	x1, x1, #0xffff
    651c:	9b037c21 	mul	x1, x1, x3
    6520:	d360fc21 	lsr	x1, x1, #32
    6524:	eb00003f 	cmp	x1, x0
    6528:	54fffc22 	b.cs	64ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    652c:	8b010294 	add	x20, x20, x1
    6530:	39400280 	ldrb	w0, [x20]
    6534:	34fffbc0 	cbz	w0, 64ac <fwp_free_zombie+0x7c>
    6538:	7100041f 	cmp	w0, #0x1
    653c:	54fffbe0 	b.eq	64b8 <fwp_free_zombie+0x88>  // b.none
    6540:	7103fc1f 	cmp	w0, #0xff
    6544:	540001e0 	b.eq	6580 <fwp_free_zombie+0x150>  // b.none
    6548:	51000400 	sub	w0, w0, #0x1
    654c:	39000280 	strb	w0, [x20]
    6550:	17ffffd7 	b	64ac <fwp_free_zombie+0x7c>
    6554:	f9400e61 	ldr	x1, [x19, #24]
    6558:	97fff136 	bl	2a30 <munmap@plt>
    655c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6560:	a9530261 	ldp	x1, x0, [x19, #304]
    6564:	b5fff901 	cbnz	x1, 6484 <fwp_free_zombie+0x54>
    6568:	91018282 	add	x2, x20, #0x60
    656c:	f9018040 	str	x0, [x2, #768]
    6570:	17ffffc6 	b	6488 <fwp_free_zombie+0x58>
    6574:	72003c3f 	tst	w1, #0xffff
    6578:	54fff9a1 	b.ne	64ac <fwp_free_zombie+0x7c>  // b.any
    657c:	17ffffed 	b	6530 <fwp_free_zombie+0x100>
    6580:	ca544680 	eor	x0, x20, x20, lsr #17
    6584:	91170084 	add	x4, x4, #0x5c0
    6588:	ca402400 	eor	x0, x0, x0, lsr #9
    658c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6590:	f94a2400 	ldr	x0, [x0, #5192]
    6594:	b5000080 	cbnz	x0, 65a4 <fwp_free_zombie+0x174>
    6598:	14000010 	b	65d8 <fwp_free_zombie+0x1a8>
    659c:	f9400800 	ldr	x0, [x0, #16]
    65a0:	b40001c0 	cbz	x0, 65d8 <fwp_free_zombie+0x1a8>
    65a4:	f9400001 	ldr	x1, [x0]
    65a8:	eb14003f 	cmp	x1, x20
    65ac:	54ffff81 	b.ne	659c <fwp_free_zombie+0x16c>  // b.any
    65b0:	f9400401 	ldr	x1, [x0, #8]
    65b4:	d1000421 	sub	x1, x1, #0x1
    65b8:	f9000401 	str	x1, [x0, #8]
    65bc:	f103f83f 	cmp	x1, #0xfe
    65c0:	54fff761 	b.ne	64ac <fwp_free_zombie+0x7c>  // b.any
    65c4:	aa1403e0 	mov	x0, x20
    65c8:	97fff8aa 	bl	4870 <fwp_rc_forget_slot>
    65cc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65d0:	39000280 	strb	w0, [x20]
    65d4:	17ffffb6 	b	64ac <fwp_free_zombie+0x7c>
    65d8:	f0000000 	adrp	x0, 9000 <__modti3+0xe0>
    65dc:	91188000 	add	x0, x0, #0x620
    65e0:	97fff4a8 	bl	3880 <fwp_trap>

00000000000065e4 <fwp_block>:
    65e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65e8:	910003fd 	mov	x29, sp
    65ec:	a90153f3 	stp	x19, x20, [sp, #16]
    65f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    65f4:	91018274 	add	x20, x19, #0x60
    65f8:	f9404282 	ldr	x2, [x20, #128]
    65fc:	b4000622 	cbz	x2, 66c0 <fwp_block+0xdc>
    6600:	91018261 	add	x1, x19, #0x60
    6604:	f9408040 	ldr	x0, [x2, #256]
    6608:	f9004020 	str	x0, [x1, #128]
    660c:	b4000680 	cbz	x0, 66dc <fwp_block+0xf8>
    6610:	91018263 	add	x3, x19, #0x60
    6614:	3901505f 	strb	wzr, [x2, #84]
    6618:	f9400864 	ldr	x4, [x3, #16]
    661c:	eb02009f 	cmp	x4, x2
    6620:	54000440 	b.eq	66a8 <fwp_block+0xc4>  // b.none
    6624:	f9418465 	ldr	x5, [x3, #776]
    6628:	f9000862 	str	x2, [x3, #16]
    662c:	f9400441 	ldr	x1, [x2, #8]
    6630:	f9004885 	str	x5, [x4, #144]
    6634:	f9418865 	ldr	x5, [x3, #784]
    6638:	f9004c85 	str	x5, [x4, #152]
    663c:	f9418c65 	ldr	x5, [x3, #792]
    6640:	f9005085 	str	x5, [x4, #160]
    6644:	f9419065 	ldr	x5, [x3, #800]
    6648:	f9005485 	str	x5, [x4, #168]
    664c:	f9419465 	ldr	x5, [x3, #808]
    6650:	f9005885 	str	x5, [x4, #176]
    6654:	f9419865 	ldr	x5, [x3, #816]
    6658:	f9005c85 	str	x5, [x4, #184]
    665c:	f9419c65 	ldr	x5, [x3, #824]
    6660:	f9006085 	str	x5, [x4, #192]
    6664:	f9400480 	ldr	x0, [x4, #8]
    6668:	f9404844 	ldr	x4, [x2, #144]
    666c:	f9018464 	str	x4, [x3, #776]
    6670:	f9404c44 	ldr	x4, [x2, #152]
    6674:	f9018864 	str	x4, [x3, #784]
    6678:	f9405044 	ldr	x4, [x2, #160]
    667c:	f9018c64 	str	x4, [x3, #792]
    6680:	f9405444 	ldr	x4, [x2, #168]
    6684:	f9019064 	str	x4, [x3, #800]
    6688:	f9405844 	ldr	x4, [x2, #176]
    668c:	f9019464 	str	x4, [x3, #808]
    6690:	a94b8844 	ldp	x4, x2, [x2, #184]
    6694:	f9019864 	str	x4, [x3, #816]
    6698:	f9019c62 	str	x2, [x3, #824]
    669c:	97fff0b5 	bl	2970 <swapcontext@plt>
    66a0:	97ffff64 	bl	6430 <fwp_free_zombie>
    66a4:	d503201f 	nop
    66a8:	91018260 	add	x0, x19, #0x60
    66ac:	b9434000 	ldr	w0, [x0, #832]
    66b0:	340001a0 	cbz	w0, 66e4 <fwp_block+0x100>
    66b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66bc:	d65f03c0 	ret
    66c0:	97fff798 	bl	4520 <fwp_poll_events>
    66c4:	f9404282 	ldr	x2, [x20, #128]
    66c8:	b4ffffc2 	cbz	x2, 66c0 <fwp_block+0xdc>
    66cc:	91018261 	add	x1, x19, #0x60
    66d0:	f9408040 	ldr	x0, [x2, #256]
    66d4:	f9004020 	str	x0, [x1, #128]
    66d8:	b5fff9c0 	cbnz	x0, 6610 <fwp_block+0x2c>
    66dc:	f9003c3f 	str	xzr, [x1, #120]
    66e0:	17ffffcc 	b	6610 <fwp_block+0x2c>
    66e4:	f0000000 	adrp	x0, 9000 <__modti3+0xe0>
    66e8:	911d4000 	add	x0, x0, #0x750
    66ec:	97fff0ed 	bl	2aa0 <getenv@plt>
    66f0:	5284e202 	mov	w2, #0x2710                	// #10000
    66f4:	b4000060 	cbz	x0, 6700 <fwp_block+0x11c>
    66f8:	39400001 	ldrb	w1, [x0]
    66fc:	350000c1 	cbnz	w1, 6714 <fwp_block+0x130>
    6700:	91018273 	add	x19, x19, #0x60
    6704:	b9034262 	str	w2, [x19, #832]
    6708:	a94153f3 	ldp	x19, x20, [sp, #16]
    670c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6710:	d65f03c0 	ret
    6714:	52800142 	mov	w2, #0xa                   	// #10
    6718:	d2800001 	mov	x1, #0x0                   	// #0
    671c:	97fff031 	bl	27e0 <strtoll@plt>
    6720:	d1000403 	sub	x3, x0, #0x1
    6724:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6728:	eb02007f 	cmp	x3, x2
    672c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6730:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6734:	17fffff3 	b	6700 <fwp_block+0x11c>
    6738:	d503201f 	nop
    673c:	d503201f 	nop

0000000000006740 <fwp_drop10>:
    6740:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6744:	910003fd 	mov	x29, sp
    6748:	a90153f3 	stp	x19, x20, [sp, #16]
    674c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc20>
    6750:	f90013f5 	str	x21, [sp, #32]
    6754:	91170275 	add	x21, x19, #0x5c0
    6758:	f949daa1 	ldr	x1, [x21, #5040]
    675c:	f949eea2 	ldr	x2, [x21, #5080]
    6760:	cb010001 	sub	x1, x0, x1
    6764:	eb02403f 	cmp	x1, x2, lsl #16
    6768:	54000382 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    676c:	d350fc22 	lsr	x2, x1, #16
    6770:	f949fea3 	ldr	x3, [x21, #5112]
    6774:	8b020842 	add	x2, x2, x2, lsl #2
    6778:	d37df042 	lsl	x2, x2, #3
    677c:	8b020064 	add	x4, x3, x2
    6780:	f9401094 	ldr	x20, [x4, #32]
    6784:	b40002b4 	cbz	x20, 67d8 <fwp_drop10+0x98>
    6788:	38626862 	ldrb	w2, [x3, x2]
    678c:	7100085f 	cmp	w2, #0x2
    6790:	540007a0 	b.eq	6884 <fwp_drop10+0x144>  // b.none
    6794:	7100045f 	cmp	w2, #0x1
    6798:	54000201 	b.ne	67d8 <fwp_drop10+0x98>  // b.any
    679c:	29430885 	ldp	w5, w2, [x4, #24]
    67a0:	92403c21 	and	x1, x1, #0xffff
    67a4:	9b057c21 	mul	x1, x1, x5
    67a8:	d360fc21 	lsr	x1, x1, #32
    67ac:	eb02003f 	cmp	x1, x2
    67b0:	54000142 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    67b4:	8b010294 	add	x20, x20, x1
    67b8:	39400281 	ldrb	w1, [x20]
    67bc:	340000e1 	cbz	w1, 67d8 <fwp_drop10+0x98>
    67c0:	7100043f 	cmp	w1, #0x1
    67c4:	54000120 	b.eq	67e8 <fwp_drop10+0xa8>  // b.none
    67c8:	7103fc3f 	cmp	w1, #0xff
    67cc:	540007c0 	b.eq	68c4 <fwp_drop10+0x184>  // b.none
    67d0:	51000421 	sub	w1, w1, #0x1
    67d4:	39000281 	strb	w1, [x20]
    67d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    67dc:	f94013f5 	ldr	x21, [sp, #32]
    67e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    67e4:	d65f03c0 	ret
    67e8:	f9400001 	ldr	x1, [x0]
    67ec:	b7f80581 	tbnz	x1, #63, 689c <fwp_drop10+0x15c>
    67f0:	91170273 	add	x19, x19, #0x5c0
    67f4:	f949da61 	ldr	x1, [x19, #5040]
    67f8:	f949ee62 	ldr	x2, [x19, #5080]
    67fc:	cb010001 	sub	x1, x0, x1
    6800:	eb02403f 	cmp	x1, x2, lsl #16
    6804:	54fffea2 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6808:	d350fc22 	lsr	x2, x1, #16
    680c:	8b020842 	add	x2, x2, x2, lsl #2
    6810:	d37df042 	lsl	x2, x2, #3
    6814:	8b020065 	add	x5, x3, x2
    6818:	f94010a4 	ldr	x4, [x5, #32]
    681c:	b4fffde4 	cbz	x4, 67d8 <fwp_drop10+0x98>
    6820:	38626862 	ldrb	w2, [x3, x2]
    6824:	7100085f 	cmp	w2, #0x2
    6828:	54000220 	b.eq	686c <fwp_drop10+0x12c>  // b.none
    682c:	7100045f 	cmp	w2, #0x1
    6830:	54fffd41 	b.ne	67d8 <fwp_drop10+0x98>  // b.any
    6834:	294308a3 	ldp	w3, w2, [x5, #24]
    6838:	92403c21 	and	x1, x1, #0xffff
    683c:	9b037c21 	mul	x1, x1, x3
    6840:	d360fc21 	lsr	x1, x1, #32
    6844:	eb02003f 	cmp	x1, x2
    6848:	54fffc82 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    684c:	8b010084 	add	x4, x4, x1
    6850:	39400081 	ldrb	w1, [x4]
    6854:	7100043f 	cmp	w1, #0x1
    6858:	54fffc01 	b.ne	67d8 <fwp_drop10+0x98>  // b.any
    685c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6860:	f94013f5 	ldr	x21, [sp, #32]
    6864:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6868:	17fff8a2 	b	4af0 <fwp_mem_free>
    686c:	72003c3f 	tst	w1, #0xffff
    6870:	54ffff00 	b.eq	6850 <fwp_drop10+0x110>  // b.none
    6874:	a94153f3 	ldp	x19, x20, [sp, #16]
    6878:	f94013f5 	ldr	x21, [sp, #32]
    687c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6880:	d65f03c0 	ret
    6884:	72003c3f 	tst	w1, #0xffff
    6888:	54fff980 	b.eq	67b8 <fwp_drop10+0x78>  // b.none
    688c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6890:	f94013f5 	ldr	x21, [sp, #32]
    6894:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6898:	d65f03c0 	ret
    689c:	f9400414 	ldr	x20, [x0, #8]
    68a0:	97fffb5d 	bl	5614 <fwp_rc_free_arr>
    68a4:	91170260 	add	x0, x19, #0x5c0
    68a8:	f949d801 	ldr	x1, [x0, #5040]
    68ac:	f949ec00 	ldr	x0, [x0, #5080]
    68b0:	cb010281 	sub	x1, x20, x1
    68b4:	eb00403f 	cmp	x1, x0, lsl #16
    68b8:	54fff902 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    68bc:	aa1403e0 	mov	x0, x20
    68c0:	17ffffab 	b	676c <fwp_drop10+0x2c>
    68c4:	ca544680 	eor	x0, x20, x20, lsr #17
    68c8:	91170273 	add	x19, x19, #0x5c0
    68cc:	ca402400 	eor	x0, x0, x0, lsr #9
    68d0:	8b200e60 	add	x0, x19, w0, uxtb #3
    68d4:	f94a2400 	ldr	x0, [x0, #5192]
    68d8:	b5000080 	cbnz	x0, 68e8 <fwp_drop10+0x1a8>
    68dc:	14000010 	b	691c <fwp_drop10+0x1dc>
    68e0:	f9400800 	ldr	x0, [x0, #16]
    68e4:	b40001c0 	cbz	x0, 691c <fwp_drop10+0x1dc>
    68e8:	f9400001 	ldr	x1, [x0]
    68ec:	eb14003f 	cmp	x1, x20
    68f0:	54ffff81 	b.ne	68e0 <fwp_drop10+0x1a0>  // b.any
    68f4:	f9400401 	ldr	x1, [x0, #8]
    68f8:	d1000421 	sub	x1, x1, #0x1
    68fc:	f9000401 	str	x1, [x0, #8]
    6900:	f103f83f 	cmp	x1, #0xfe
    6904:	54fff6a1 	b.ne	67d8 <fwp_drop10+0x98>  // b.any
    6908:	aa1403e0 	mov	x0, x20
    690c:	97fff7d9 	bl	4870 <fwp_rc_forget_slot>
    6910:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6914:	39000280 	strb	w0, [x20]
    6918:	17ffffb0 	b	67d8 <fwp_drop10+0x98>
    691c:	f0000000 	adrp	x0, 9000 <__modti3+0xe0>
    6920:	91188000 	add	x0, x0, #0x620
    6924:	97fff3d7 	bl	3880 <fwp_trap>
    6928:	d503201f 	nop
    692c:	d503201f 	nop

0000000000006930 <fwp_caps173>:
    6930:	34000041 	cbz	w1, 6938 <fwp_caps173+0x8>
    6934:	d65f03c0 	ret
    6938:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc20>
    693c:	91170063 	add	x3, x3, #0x5c0
    6940:	f949d861 	ldr	x1, [x3, #5040]
    6944:	f949ec62 	ldr	x2, [x3, #5080]
    6948:	cb010001 	sub	x1, x0, x1
    694c:	eb02403f 	cmp	x1, x2, lsl #16
    6950:	54ffff22 	b.cs	6934 <fwp_caps173+0x4>  // b.hs, b.nlast
    6954:	d350fc22 	lsr	x2, x1, #16
    6958:	f949fc65 	ldr	x5, [x3, #5112]
    695c:	8b020842 	add	x2, x2, x2, lsl #2
    6960:	d37df042 	lsl	x2, x2, #3
    6964:	8b0200a4 	add	x4, x5, x2
    6968:	f9401083 	ldr	x3, [x4, #32]
    696c:	b4fffe43 	cbz	x3, 6934 <fwp_caps173+0x4>
    6970:	386268a2 	ldrb	w2, [x5, x2]
    6974:	7100085f 	cmp	w2, #0x2
    6978:	540001c0 	b.eq	69b0 <fwp_caps173+0x80>  // b.none
    697c:	7100045f 	cmp	w2, #0x1
    6980:	54fffda1 	b.ne	6934 <fwp_caps173+0x4>  // b.any
    6984:	29430885 	ldp	w5, w2, [x4, #24]
    6988:	92403c21 	and	x1, x1, #0xffff
    698c:	9b057c21 	mul	x1, x1, x5
    6990:	d360fc21 	lsr	x1, x1, #32
    6994:	eb02003f 	cmp	x1, x2
    6998:	54fffce2 	b.cs	6934 <fwp_caps173+0x4>  // b.hs, b.nlast
    699c:	8b010063 	add	x3, x3, x1
    69a0:	39400061 	ldrb	w1, [x3]
    69a4:	7100043f 	cmp	w1, #0x1
    69a8:	54fffc61 	b.ne	6934 <fwp_caps173+0x4>  // b.any
    69ac:	17fff851 	b	4af0 <fwp_mem_free>
    69b0:	72003c3f 	tst	w1, #0xffff
    69b4:	54ffff60 	b.eq	69a0 <fwp_caps173+0x70>  // b.none
    69b8:	d65f03c0 	ret
    69bc:	d503201f 	nop

00000000000069c0 <f37>:
    69c0:	d10203ff 	sub	sp, sp, #0x80
    69c4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    69c8:	f947f421 	ldr	x1, [x1, #4072]
    69cc:	a9027bfd 	stp	x29, x30, [sp, #32]
    69d0:	910083fd 	add	x29, sp, #0x20
    69d4:	a9045bf5 	stp	x21, x22, [sp, #64]
    69d8:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc20>
    69dc:	911702c3 	add	x3, x22, #0x5c0
    69e0:	a90353f3 	stp	x19, x20, [sp, #48]
    69e4:	a90563f7 	stp	x23, x24, [sp, #80]
    69e8:	aa0003f8 	mov	x24, x0
    69ec:	a9066bf9 	stp	x25, x26, [sp, #96]
    69f0:	f949ec62 	ldr	x2, [x3, #5080]
    69f4:	f9400024 	ldr	x4, [x1]
    69f8:	f9000fe4 	str	x4, [sp, #24]
    69fc:	d2800004 	mov	x4, #0x0                   	// #0
    6a00:	f949d861 	ldr	x1, [x3, #5040]
    6a04:	d370bc42 	lsl	x2, x2, #16
    6a08:	b40017e0 	cbz	x0, 6d04 <f37+0x344>
    6a0c:	f9400819 	ldr	x25, [x0, #16]
    6a10:	cb010321 	sub	x1, x25, x1
    6a14:	eb02003f 	cmp	x1, x2
    6a18:	54000362 	b.cs	6a84 <f37+0xc4>  // b.hs, b.nlast
    6a1c:	f949fc60 	ldr	x0, [x3, #5112]
    6a20:	d350fc22 	lsr	x2, x1, #16
    6a24:	8b020842 	add	x2, x2, x2, lsl #2
    6a28:	8b020c02 	add	x2, x0, x2, lsl #3
    6a2c:	f9401040 	ldr	x0, [x2, #32]
    6a30:	b40002a0 	cbz	x0, 6a84 <f37+0xc4>
    6a34:	39400043 	ldrb	w3, [x2]
    6a38:	7100087f 	cmp	w3, #0x2
    6a3c:	540015e0 	b.eq	6cf8 <f37+0x338>  // b.none
    6a40:	7100047f 	cmp	w3, #0x1
    6a44:	540001c1 	b.ne	6a7c <f37+0xbc>  // b.any
    6a48:	29430843 	ldp	w3, w2, [x2, #24]
    6a4c:	92403c21 	and	x1, x1, #0xffff
    6a50:	9b037c21 	mul	x1, x1, x3
    6a54:	d360fc21 	lsr	x1, x1, #32
    6a58:	eb02003f 	cmp	x1, x2
    6a5c:	54000102 	b.cs	6a7c <f37+0xbc>  // b.hs, b.nlast
    6a60:	8b010000 	add	x0, x0, x1
    6a64:	39400001 	ldrb	w1, [x0]
    6a68:	340000a1 	cbz	w1, 6a7c <f37+0xbc>
    6a6c:	7103f43f 	cmp	w1, #0xfd
    6a70:	54001888 	b.hi	6d80 <f37+0x3c0>  // b.pmore
    6a74:	11000421 	add	w1, w1, #0x1
    6a78:	39000001 	strb	w1, [x0]
    6a7c:	d2800000 	mov	x0, #0x0                   	// #0
    6a80:	b40000f8 	cbz	x24, 6a9c <f37+0xdc>
    6a84:	aa1803e1 	mov	x1, x24
    6a88:	d2800000 	mov	x0, #0x0                   	// #0
    6a8c:	d503201f 	nop
    6a90:	f9400821 	ldr	x1, [x1, #16]
    6a94:	91000400 	add	x0, x0, #0x1
    6a98:	b5ffffc1 	cbnz	x1, 6a90 <f37+0xd0>
    6a9c:	b40013b9 	cbz	x25, 6d10 <f37+0x350>
    6aa0:	aa1903e1 	mov	x1, x25
    6aa4:	d2800002 	mov	x2, #0x0                   	// #0
    6aa8:	f9400821 	ldr	x1, [x1, #16]
    6aac:	91000442 	add	x2, x2, #0x1
    6ab0:	b5ffffc1 	cbnz	x1, 6aa8 <f37+0xe8>
    6ab4:	eb00005f 	cmp	x2, x0
    6ab8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6abc:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    6ac0:	eb01035f 	cmp	x26, x1
    6ac4:	54001668 	b.hi	6d90 <f37+0x3d0>  // b.pmore
    6ac8:	d37ffb53 	lsl	x19, x26, #1
    6acc:	52800041 	mov	w1, #0x2                   	// #2
    6ad0:	91000660 	add	x0, x19, #0x1
    6ad4:	d37df000 	lsl	x0, x0, #3
    6ad8:	97fff926 	bl	4f70 <fwp_heap_alloc>
    6adc:	aa0003f7 	mov	x23, x0
    6ae0:	911702c1 	add	x1, x22, #0x5c0
    6ae4:	aa0103e0 	mov	x0, x1
    6ae8:	f90002f3 	str	x19, [x23]
    6aec:	f949d821 	ldr	x1, [x1, #5040]
    6af0:	f949ec00 	ldr	x0, [x0, #5080]
    6af4:	cb0102e1 	sub	x1, x23, x1
    6af8:	eb00403f 	cmp	x1, x0, lsl #16
    6afc:	54000342 	b.cs	6b64 <f37+0x1a4>  // b.hs, b.nlast
    6b00:	911702c2 	add	x2, x22, #0x5c0
    6b04:	d350fc20 	lsr	x0, x1, #16
    6b08:	8b000800 	add	x0, x0, x0, lsl #2
    6b0c:	f949fc43 	ldr	x3, [x2, #5112]
    6b10:	d37df002 	lsl	x2, x0, #3
    6b14:	8b020060 	add	x0, x3, x2
    6b18:	f9401013 	ldr	x19, [x0, #32]
    6b1c:	b4000253 	cbz	x19, 6b64 <f37+0x1a4>
    6b20:	38626862 	ldrb	w2, [x3, x2]
    6b24:	7100085f 	cmp	w2, #0x2
    6b28:	54000e20 	b.eq	6cec <f37+0x32c>  // b.none
    6b2c:	7100045f 	cmp	w2, #0x1
    6b30:	540001a1 	b.ne	6b64 <f37+0x1a4>  // b.any
    6b34:	29430002 	ldp	w2, w0, [x0, #24]
    6b38:	92403c21 	and	x1, x1, #0xffff
    6b3c:	9b027c21 	mul	x1, x1, x2
    6b40:	d360fc21 	lsr	x1, x1, #32
    6b44:	eb00003f 	cmp	x1, x0
    6b48:	540000e2 	b.cs	6b64 <f37+0x1a4>  // b.hs, b.nlast
    6b4c:	8b010273 	add	x19, x19, x1
    6b50:	39400260 	ldrb	w0, [x19]
    6b54:	7103fc1f 	cmp	w0, #0xff
    6b58:	54000f80 	b.eq	6d48 <f37+0x388>  // b.none
    6b5c:	52800020 	mov	w0, #0x1                   	// #1
    6b60:	39000260 	strb	w0, [x19]
    6b64:	b400025a 	cbz	x26, 6bac <f37+0x1ec>
    6b68:	8b1a12fa 	add	x26, x23, x26, lsl #4
    6b6c:	aa1703f3 	mov	x19, x23
    6b70:	aa1803f5 	mov	x21, x24
    6b74:	aa1903f4 	mov	x20, x25
    6b78:	f9400683 	ldr	x3, [x20, #8]
    6b7c:	f94006a2 	ldr	x2, [x21, #8]
    6b80:	f9400861 	ldr	x1, [x3, #16]
    6b84:	f9400840 	ldr	x0, [x2, #16]
    6b88:	fd400461 	ldr	d1, [x3, #8]
    6b8c:	fd400440 	ldr	d0, [x2, #8]
    6b90:	97fffa38 	bl	5470 <w120>
    6b94:	f9000660 	str	x0, [x19, #8]
    6b98:	f8010e61 	str	x1, [x19, #16]!
    6b9c:	f9400a94 	ldr	x20, [x20, #16]
    6ba0:	f9400ab5 	ldr	x21, [x21, #16]
    6ba4:	eb13035f 	cmp	x26, x19
    6ba8:	54fffe81 	b.ne	6b78 <f37+0x1b8>  // b.any
    6bac:	aa1903e0 	mov	x0, x25
    6bb0:	97fffd48 	bl	60d0 <fwp_drop4>
    6bb4:	aa1803e0 	mov	x0, x24
    6bb8:	97fffd46 	bl	60d0 <fwp_drop4>
    6bbc:	f94002f5 	ldr	x21, [x23]
    6bc0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6bc4:	b4000275 	cbz	x21, 6c10 <f37+0x250>
    6bc8:	fd003be8 	str	d8, [sp, #112]
    6bcc:	2f00e408 	movi	d8, #0x0
    6bd0:	910022f9 	add	x25, x23, #0x8
    6bd4:	910042f8 	add	x24, x23, #0x10
    6bd8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    6bdc:	d2800013 	mov	x19, #0x0                   	// #0
    6be0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    6be4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6be8:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    6bec:	aa0303e1 	mov	x1, x3
    6bf0:	1e602908 	fadd	d8, d8, d0
    6bf4:	91000a73 	add	x19, x19, #0x2
    6bf8:	97fff96b 	bl	51a4 <fwp_p_ad_push>
    6bfc:	aa0003f4 	mov	x20, x0
    6c00:	eb1302bf 	cmp	x21, x19
    6c04:	54fffee8 	b.hi	6be0 <f37+0x220>  // b.pmore
    6c08:	9e660115 	fmov	x21, d8
    6c0c:	fd403be8 	ldr	d8, [sp, #112]
    6c10:	911702d6 	add	x22, x22, #0x5c0
    6c14:	aa1703e0 	mov	x0, x23
    6c18:	97fffeca 	bl	6740 <fwp_drop10>
    6c1c:	a900d3f5 	stp	x21, x20, [sp, #8]
    6c20:	910023e1 	add	x1, sp, #0x8
    6c24:	52800000 	mov	w0, #0x0                   	// #0
    6c28:	97fff917 	bl	5084 <fwp_data.part.0.constprop.0>
    6c2c:	f949dac1 	ldr	x1, [x22, #5040]
    6c30:	aa0003f3 	mov	x19, x0
    6c34:	f949eec0 	ldr	x0, [x22, #5080]
    6c38:	cb010261 	sub	x1, x19, x1
    6c3c:	eb00403f 	cmp	x1, x0, lsl #16
    6c40:	54000322 	b.cs	6ca4 <f37+0x2e4>  // b.hs, b.nlast
    6c44:	d350fc22 	lsr	x2, x1, #16
    6c48:	f949fec3 	ldr	x3, [x22, #5112]
    6c4c:	8b020842 	add	x2, x2, x2, lsl #2
    6c50:	d37df042 	lsl	x2, x2, #3
    6c54:	8b020060 	add	x0, x3, x2
    6c58:	f9401014 	ldr	x20, [x0, #32]
    6c5c:	b4000254 	cbz	x20, 6ca4 <f37+0x2e4>
    6c60:	38626862 	ldrb	w2, [x3, x2]
    6c64:	7100085f 	cmp	w2, #0x2
    6c68:	540003c0 	b.eq	6ce0 <f37+0x320>  // b.none
    6c6c:	7100045f 	cmp	w2, #0x1
    6c70:	540001a1 	b.ne	6ca4 <f37+0x2e4>  // b.any
    6c74:	29430002 	ldp	w2, w0, [x0, #24]
    6c78:	92403c21 	and	x1, x1, #0xffff
    6c7c:	9b027c21 	mul	x1, x1, x2
    6c80:	d360fc21 	lsr	x1, x1, #32
    6c84:	eb00003f 	cmp	x1, x0
    6c88:	540000e2 	b.cs	6ca4 <f37+0x2e4>  // b.hs, b.nlast
    6c8c:	8b010294 	add	x20, x20, x1
    6c90:	39400280 	ldrb	w0, [x20]
    6c94:	7103fc1f 	cmp	w0, #0xff
    6c98:	540005e0 	b.eq	6d54 <f37+0x394>  // b.none
    6c9c:	52800020 	mov	w0, #0x1                   	// #1
    6ca0:	39000280 	strb	w0, [x20]
    6ca4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6ca8:	f947f400 	ldr	x0, [x0, #4072]
    6cac:	f9400fe2 	ldr	x2, [sp, #24]
    6cb0:	f9400001 	ldr	x1, [x0]
    6cb4:	eb010042 	subs	x2, x2, x1
    6cb8:	d2800001 	mov	x1, #0x0                   	// #0
    6cbc:	54000721 	b.ne	6da0 <f37+0x3e0>  // b.any
    6cc0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6cc4:	aa1303e0 	mov	x0, x19
    6cc8:	a94353f3 	ldp	x19, x20, [sp, #48]
    6ccc:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6cd0:	a94563f7 	ldp	x23, x24, [sp, #80]
    6cd4:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6cd8:	910203ff 	add	sp, sp, #0x80
    6cdc:	d65f03c0 	ret
    6ce0:	72003c3f 	tst	w1, #0xffff
    6ce4:	54fffe01 	b.ne	6ca4 <f37+0x2e4>  // b.any
    6ce8:	17ffffea 	b	6c90 <f37+0x2d0>
    6cec:	72003c3f 	tst	w1, #0xffff
    6cf0:	54fff3a1 	b.ne	6b64 <f37+0x1a4>  // b.any
    6cf4:	17ffff97 	b	6b50 <f37+0x190>
    6cf8:	72003c3f 	tst	w1, #0xffff
    6cfc:	54ffec01 	b.ne	6a7c <f37+0xbc>  // b.any
    6d00:	17ffff59 	b	6a64 <f37+0xa4>
    6d04:	cb0103e1 	neg	x1, x1
    6d08:	eb02003f 	cmp	x1, x2
    6d0c:	540002a3 	b.cc	6d60 <f37+0x3a0>  // b.lo, b.ul, b.last
    6d10:	52800041 	mov	w1, #0x2                   	// #2
    6d14:	d2800100 	mov	x0, #0x8                   	// #8
    6d18:	97fff896 	bl	4f70 <fwp_heap_alloc>
    6d1c:	aa0003f7 	mov	x23, x0
    6d20:	911702c0 	add	x0, x22, #0x5c0
    6d24:	f90002ff 	str	xzr, [x23]
    6d28:	f949d801 	ldr	x1, [x0, #5040]
    6d2c:	f949ec00 	ldr	x0, [x0, #5080]
    6d30:	cb0102e1 	sub	x1, x23, x1
    6d34:	eb00403f 	cmp	x1, x0, lsl #16
    6d38:	54000282 	b.cs	6d88 <f37+0x3c8>  // b.hs, b.nlast
    6d3c:	d280001a 	mov	x26, #0x0                   	// #0
    6d40:	d2800019 	mov	x25, #0x0                   	// #0
    6d44:	17ffff6f 	b	6b00 <f37+0x140>
    6d48:	aa1303e0 	mov	x0, x19
    6d4c:	97fff6c9 	bl	4870 <fwp_rc_forget_slot>
    6d50:	17ffff83 	b	6b5c <f37+0x19c>
    6d54:	aa1403e0 	mov	x0, x20
    6d58:	97fff6c6 	bl	4870 <fwp_rc_forget_slot>
    6d5c:	17ffffd0 	b	6c9c <f37+0x2dc>
    6d60:	f949fc62 	ldr	x2, [x3, #5112]
    6d64:	d350fc20 	lsr	x0, x1, #16
    6d68:	8b000800 	add	x0, x0, x0, lsl #2
    6d6c:	8b000c42 	add	x2, x2, x0, lsl #3
    6d70:	f9401040 	ldr	x0, [x2, #32]
    6d74:	b4fffce0 	cbz	x0, 6d10 <f37+0x350>
    6d78:	d2800019 	mov	x25, #0x0                   	// #0
    6d7c:	17ffff2e 	b	6a34 <f37+0x74>
    6d80:	97fff675 	bl	4754 <fwp_rc_wide_dup>
    6d84:	17ffff3e 	b	6a7c <f37+0xbc>
    6d88:	d2800019 	mov	x25, #0x0                   	// #0
    6d8c:	17ffff88 	b	6bac <f37+0x1ec>
    6d90:	f0000000 	adrp	x0, 9000 <__modti3+0xe0>
    6d94:	911d8000 	add	x0, x0, #0x760
    6d98:	fd003be8 	str	d8, [sp, #112]
    6d9c:	97fff2b9 	bl	3880 <fwp_trap>
    6da0:	fd003be8 	str	d8, [sp, #112]
    6da4:	97ffeedb 	bl	2910 <__stack_chk_fail@plt>
    6da8:	d503201f 	nop
    6dac:	d503201f 	nop

0000000000006db0 <fwp_owned_entry37>:
    6db0:	f9400000 	ldr	x0, [x0]
    6db4:	17ffff03 	b	69c0 <f37>
    6db8:	d503201f 	nop
    6dbc:	d503201f 	nop

0000000000006dc0 <e37>:
    6dc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6dc4:	910003fd 	mov	x29, sp
    6dc8:	f9000bf3 	str	x19, [sp, #16]
    6dcc:	f9400013 	ldr	x19, [x0]
    6dd0:	aa1303e0 	mov	x0, x19
    6dd4:	97fff9eb 	bl	5580 <fwp_rc_share>
    6dd8:	aa1303e0 	mov	x0, x19
    6ddc:	97fffef9 	bl	69c0 <f37>
    6de0:	aa0003f3 	mov	x19, x0
    6de4:	97fff9e7 	bl	5580 <fwp_rc_share>
    6de8:	aa1303e0 	mov	x0, x19
    6dec:	f9400bf3 	ldr	x19, [sp, #16]
    6df0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6df4:	d65f03c0 	ret
    6df8:	d503201f 	nop
    6dfc:	d503201f 	nop

0000000000006e00 <fwp_args37>:
    6e00:	7100003f 	cmp	w1, #0x0
    6e04:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6e08:	54000041 	b.ne	6e10 <fwp_args37+0x10>  // b.any
    6e0c:	d65f03c0 	ret
    6e10:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    6e14:	91170042 	add	x2, x2, #0x5c0
    6e18:	f9400001 	ldr	x1, [x0]
    6e1c:	f949d843 	ldr	x3, [x2, #5040]
    6e20:	f949ec40 	ldr	x0, [x2, #5080]
    6e24:	cb030021 	sub	x1, x1, x3
    6e28:	eb00403f 	cmp	x1, x0, lsl #16
    6e2c:	54ffff02 	b.cs	6e0c <fwp_args37+0xc>  // b.hs, b.nlast
    6e30:	d350fc20 	lsr	x0, x1, #16
    6e34:	f949fc44 	ldr	x4, [x2, #5112]
    6e38:	8b000800 	add	x0, x0, x0, lsl #2
    6e3c:	d37df002 	lsl	x2, x0, #3
    6e40:	8b020083 	add	x3, x4, x2
    6e44:	f9401060 	ldr	x0, [x3, #32]
    6e48:	b4fffe20 	cbz	x0, 6e0c <fwp_args37+0xc>
    6e4c:	38626882 	ldrb	w2, [x4, x2]
    6e50:	7100085f 	cmp	w2, #0x2
    6e54:	54000220 	b.eq	6e98 <fwp_args37+0x98>  // b.none
    6e58:	7100045f 	cmp	w2, #0x1
    6e5c:	54fffd81 	b.ne	6e0c <fwp_args37+0xc>  // b.any
    6e60:	29430864 	ldp	w4, w2, [x3, #24]
    6e64:	92403c21 	and	x1, x1, #0xffff
    6e68:	9b047c21 	mul	x1, x1, x4
    6e6c:	d360fc21 	lsr	x1, x1, #32
    6e70:	eb02003f 	cmp	x1, x2
    6e74:	54fffcc2 	b.cs	6e0c <fwp_args37+0xc>  // b.hs, b.nlast
    6e78:	8b010000 	add	x0, x0, x1
    6e7c:	39400001 	ldrb	w1, [x0]
    6e80:	34fffc61 	cbz	w1, 6e0c <fwp_args37+0xc>
    6e84:	7103f43f 	cmp	w1, #0xfd
    6e88:	540000e8 	b.hi	6ea4 <fwp_args37+0xa4>  // b.pmore
    6e8c:	11000421 	add	w1, w1, #0x1
    6e90:	39000001 	strb	w1, [x0]
    6e94:	d65f03c0 	ret
    6e98:	72003c3f 	tst	w1, #0xffff
    6e9c:	54ffff00 	b.eq	6e7c <fwp_args37+0x7c>  // b.none
    6ea0:	d65f03c0 	ret
    6ea4:	17fff62c 	b	4754 <fwp_rc_wide_dup>
    6ea8:	d503201f 	nop
    6eac:	d503201f 	nop

0000000000006eb0 <fwp_caps37>:
    6eb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6eb4:	910003fd 	mov	x29, sp
    6eb8:	f9000bf3 	str	x19, [sp, #16]
    6ebc:	aa0003f3 	mov	x19, x0
    6ec0:	b9400400 	ldr	w0, [x0, #4]
    6ec4:	340004a0 	cbz	w0, 6f58 <fwp_caps37+0xa8>
    6ec8:	f9400660 	ldr	x0, [x19, #8]
    6ecc:	350004e1 	cbnz	w1, 6f68 <fwp_caps37+0xb8>
    6ed0:	97fffc80 	bl	60d0 <fwp_drop4>
    6ed4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    6ed8:	91170042 	add	x2, x2, #0x5c0
    6edc:	f949d840 	ldr	x0, [x2, #5040]
    6ee0:	f949ec41 	ldr	x1, [x2, #5080]
    6ee4:	cb000260 	sub	x0, x19, x0
    6ee8:	eb01401f 	cmp	x0, x1, lsl #16
    6eec:	54000382 	b.cs	6f5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6ef0:	d350fc01 	lsr	x1, x0, #16
    6ef4:	f949fc44 	ldr	x4, [x2, #5112]
    6ef8:	8b010821 	add	x1, x1, x1, lsl #2
    6efc:	d37df021 	lsl	x1, x1, #3
    6f00:	8b010083 	add	x3, x4, x1
    6f04:	f9401062 	ldr	x2, [x3, #32]
    6f08:	b40002a2 	cbz	x2, 6f5c <fwp_caps37+0xac>
    6f0c:	38616881 	ldrb	w1, [x4, x1]
    6f10:	7100083f 	cmp	w1, #0x2
    6f14:	540006c0 	b.eq	6fec <fwp_caps37+0x13c>  // b.none
    6f18:	7100043f 	cmp	w1, #0x1
    6f1c:	54000201 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    6f20:	29430464 	ldp	w4, w1, [x3, #24]
    6f24:	92403c00 	and	x0, x0, #0xffff
    6f28:	9b047c00 	mul	x0, x0, x4
    6f2c:	d360fc00 	lsr	x0, x0, #32
    6f30:	eb01001f 	cmp	x0, x1
    6f34:	54000142 	b.cs	6f5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6f38:	8b000042 	add	x2, x2, x0
    6f3c:	39400040 	ldrb	w0, [x2]
    6f40:	7100041f 	cmp	w0, #0x1
    6f44:	540000c1 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    6f48:	aa1303e0 	mov	x0, x19
    6f4c:	f9400bf3 	ldr	x19, [sp, #16]
    6f50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f54:	17fff6e7 	b	4af0 <fwp_mem_free>
    6f58:	34fffbe1 	cbz	w1, 6ed4 <fwp_caps37+0x24>
    6f5c:	f9400bf3 	ldr	x19, [sp, #16]
    6f60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f64:	d65f03c0 	ret
    6f68:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    6f6c:	91170042 	add	x2, x2, #0x5c0
    6f70:	f949d843 	ldr	x3, [x2, #5040]
    6f74:	f949ec41 	ldr	x1, [x2, #5080]
    6f78:	cb030000 	sub	x0, x0, x3
    6f7c:	eb01401f 	cmp	x0, x1, lsl #16
    6f80:	54fffee2 	b.cs	6f5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6f84:	d350fc01 	lsr	x1, x0, #16
    6f88:	f949fc44 	ldr	x4, [x2, #5112]
    6f8c:	8b010821 	add	x1, x1, x1, lsl #2
    6f90:	d37df021 	lsl	x1, x1, #3
    6f94:	8b010083 	add	x3, x4, x1
    6f98:	f9401062 	ldr	x2, [x3, #32]
    6f9c:	b4fffe02 	cbz	x2, 6f5c <fwp_caps37+0xac>
    6fa0:	38616881 	ldrb	w1, [x4, x1]
    6fa4:	7100083f 	cmp	w1, #0x2
    6fa8:	54000280 	b.eq	6ff8 <fwp_caps37+0x148>  // b.none
    6fac:	7100043f 	cmp	w1, #0x1
    6fb0:	54fffd61 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    6fb4:	92403c01 	and	x1, x0, #0xffff
    6fb8:	29430064 	ldp	w4, w0, [x3, #24]
    6fbc:	9b047c21 	mul	x1, x1, x4
    6fc0:	d360fc21 	lsr	x1, x1, #32
    6fc4:	eb00003f 	cmp	x1, x0
    6fc8:	54fffca2 	b.cs	6f5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6fcc:	8b010042 	add	x2, x2, x1
    6fd0:	39400040 	ldrb	w0, [x2]
    6fd4:	34fffc40 	cbz	w0, 6f5c <fwp_caps37+0xac>
    6fd8:	7103f41f 	cmp	w0, #0xfd
    6fdc:	54000148 	b.hi	7004 <fwp_caps37+0x154>  // b.pmore
    6fe0:	11000400 	add	w0, w0, #0x1
    6fe4:	39000040 	strb	w0, [x2]
    6fe8:	17ffffdd 	b	6f5c <fwp_caps37+0xac>
    6fec:	72003c1f 	tst	w0, #0xffff
    6ff0:	54fffb61 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    6ff4:	17ffffd2 	b	6f3c <fwp_caps37+0x8c>
    6ff8:	72003c1f 	tst	w0, #0xffff
    6ffc:	54fffb01 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    7000:	17fffff4 	b	6fd0 <fwp_caps37+0x120>
    7004:	f9400bf3 	ldr	x19, [sp, #16]
    7008:	aa0203e0 	mov	x0, x2
    700c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7010:	17fff5d1 	b	4754 <fwp_rc_wide_dup>

0000000000007014 <fwp_write>:
    7014:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7018:	910003fd 	mov	x29, sp
    701c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    7020:	f947f484 	ldr	x4, [x4, #4072]
    7024:	a90153f3 	stp	x19, x20, [sp, #16]
    7028:	d10943ff 	sub	sp, sp, #0x250
    702c:	b9400045 	ldr	w5, [x2]
    7030:	aa0003f4 	mov	x20, x0
    7034:	f9400080 	ldr	x0, [x4]
    7038:	f90127e0 	str	x0, [sp, #584]
    703c:	d2800000 	mov	x0, #0x0                   	// #0
    7040:	710064bf 	cmp	w5, #0x19
    7044:	54000408 	b.hi	70c4 <fwp_write+0xb0>  // b.pmore
    7048:	d0000000 	adrp	x0, 9000 <__modti3+0xe0>
    704c:	aa0103f3 	mov	x19, x1
    7050:	913dc000 	add	x0, x0, #0xf70
    7054:	f9013bf5 	str	x21, [sp, #624]
    7058:	f9013ff6 	str	x22, [sp, #632]
    705c:	f90153fb 	str	x27, [sp, #672]
    7060:	f90157fc 	str	x28, [sp, #680]
    7064:	aa0203fc 	mov	x28, x2
    7068:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    706c:	10000061 	adr	x1, 7078 <fwp_write+0x64>
    7070:	8b20a820 	add	x0, x1, w0, sxth #2
    7074:	d61f0000 	br	x0
    7078:	910123e0 	add	x0, sp, #0x48
    707c:	aa1303e5 	mov	x5, x19
    7080:	d0000004 	adrp	x4, 9000 <__modti3+0xe0>
    7084:	aa0003f3 	mov	x19, x0
    7088:	911ea084 	add	x4, x4, #0x7a8
    708c:	d2804003 	mov	x3, #0x200                 	// #512
    7090:	aa0303e1 	mov	x1, x3
    7094:	52800042 	mov	w2, #0x2                   	// #2
    7098:	97ffedfa 	bl	2880 <__snprintf_chk@plt>
    709c:	aa1303e0 	mov	x0, x19
    70a0:	97ffedc0 	bl	27a0 <strlen@plt>
    70a4:	aa1303e1 	mov	x1, x19
    70a8:	aa0003e2 	mov	x2, x0
    70ac:	aa1403e0 	mov	x0, x20
    70b0:	97fff158 	bl	3610 <buf_put>
    70b4:	f9413bf5 	ldr	x21, [sp, #624]
    70b8:	f9413ff6 	ldr	x22, [sp, #632]
    70bc:	f94153fb 	ldr	x27, [sp, #672]
    70c0:	f94157fc 	ldr	x28, [sp, #680]
    70c4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    70c8:	f947f400 	ldr	x0, [x0, #4072]
    70cc:	f94127e2 	ldr	x2, [sp, #584]
    70d0:	f9400001 	ldr	x1, [x0]
    70d4:	eb010042 	subs	x2, x2, x1
    70d8:	d2800001 	mov	x1, #0x0                   	// #0
    70dc:	540077a1 	b.ne	7fd0 <fwp_write+0xfbc>  // b.any
    70e0:	910943ff 	add	sp, sp, #0x250
    70e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    70e8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    70ec:	d65f03c0 	ret
    70f0:	910123e0 	add	x0, sp, #0x48
    70f4:	aa1303e5 	mov	x5, x19
    70f8:	d0000004 	adrp	x4, 9000 <__modti3+0xe0>
    70fc:	aa0003f3 	mov	x19, x0
    7100:	911e8084 	add	x4, x4, #0x7a0
    7104:	d2804003 	mov	x3, #0x200                 	// #512
    7108:	17ffffe2 	b	7090 <fwp_write+0x7c>
    710c:	71004cbf 	cmp	w5, #0x13
    7110:	d0000000 	adrp	x0, 9000 <__modti3+0xe0>
    7114:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7118:	911e4000 	add	x0, x0, #0x790
    711c:	911e6021 	add	x1, x1, #0x798
    7120:	d2800082 	mov	x2, #0x4                   	// #4
    7124:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7128:	aa1403e0 	mov	x0, x20
    712c:	f90143f7 	str	x23, [sp, #640]
    7130:	d2800016 	mov	x22, #0x0                   	// #0
    7134:	f90147f8 	str	x24, [sp, #648]
    7138:	97fff136 	bl	3610 <buf_put>
    713c:	f9400260 	ldr	x0, [x19]
    7140:	d0000017 	adrp	x23, 9000 <__modti3+0xe0>
    7144:	d2800015 	mov	x21, #0x0                   	// #0
    7148:	912062f7 	add	x23, x23, #0x818
    714c:	b4004780 	cbz	x0, 7a3c <fwp_write+0xa28>
    7150:	b9400380 	ldr	w0, [x28]
    7154:	52800003 	mov	w3, #0x0                   	// #0
    7158:	f9401f82 	ldr	x2, [x28, #56]
    715c:	71004c1f 	cmp	w0, #0x13
    7160:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7164:	aa1403e0 	mov	x0, x20
    7168:	8b010e61 	add	x1, x19, x1, lsl #3
    716c:	f9400421 	ldr	x1, [x1, #8]
    7170:	97ffffa9 	bl	7014 <fwp_write>
    7174:	b9400380 	ldr	w0, [x28]
    7178:	7100481f 	cmp	w0, #0x12
    717c:	54004b20 	b.eq	7ae0 <fwp_write+0xacc>  // b.none
    7180:	f9400260 	ldr	x0, [x19]
    7184:	910006b5 	add	x21, x21, #0x1
    7188:	91000ad6 	add	x22, x22, #0x2
    718c:	eb15001f 	cmp	x0, x21
    7190:	54004569 	b.ls	7a3c <fwp_write+0xa28>  // b.plast
    7194:	aa1703e1 	mov	x1, x23
    7198:	aa1403e0 	mov	x0, x20
    719c:	d2800042 	mov	x2, #0x2                   	// #2
    71a0:	97fff11c 	bl	3610 <buf_put>
    71a4:	17ffffeb 	b	7150 <fwp_write+0x13c>
    71a8:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    71ac:	911f4021 	add	x1, x1, #0x7d0
    71b0:	d28000c2 	mov	x2, #0x6                   	// #6
    71b4:	aa1403e0 	mov	x0, x20
    71b8:	91004273 	add	x19, x19, #0x10
    71bc:	97fff115 	bl	3610 <buf_put>
    71c0:	aa1303e0 	mov	x0, x19
    71c4:	97ffed77 	bl	27a0 <strlen@plt>
    71c8:	aa1303e1 	mov	x1, x19
    71cc:	aa0003e2 	mov	x2, x0
    71d0:	aa1403e0 	mov	x0, x20
    71d4:	97fff10f 	bl	3610 <buf_put>
    71d8:	528007c3 	mov	w3, #0x3e                  	// #62
    71dc:	aa1403e0 	mov	x0, x20
    71e0:	91001fe1 	add	x1, sp, #0x7
    71e4:	d2800022 	mov	x2, #0x1                   	// #1
    71e8:	39001fe3 	strb	w3, [sp, #7]
    71ec:	17ffffb1 	b	70b0 <fwp_write+0x9c>
    71f0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    71f4:	f947f400 	ldr	x0, [x0, #4072]
    71f8:	f94127e2 	ldr	x2, [sp, #584]
    71fc:	f9400001 	ldr	x1, [x0]
    7200:	eb010042 	subs	x2, x2, x1
    7204:	d2800001 	mov	x1, #0x0                   	// #0
    7208:	540034c1 	b.ne	78a0 <fwp_write+0x88c>  // b.any
    720c:	f9413bf5 	ldr	x21, [sp, #624]
    7210:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7214:	f9413ff6 	ldr	x22, [sp, #632]
    7218:	aa1403e0 	mov	x0, x20
    721c:	911ec021 	add	x1, x1, #0x7b0
    7220:	d2800142 	mov	x2, #0xa                   	// #10
    7224:	f94153fb 	ldr	x27, [sp, #672]
    7228:	f94157fc 	ldr	x28, [sp, #680]
    722c:	910943ff 	add	sp, sp, #0x250
    7230:	a94153f3 	ldp	x19, x20, [sp, #16]
    7234:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7238:	17fff0f6 	b	3610 <buf_put>
    723c:	f9400456 	ldr	x22, [x2, #8]
    7240:	f90143f7 	str	x23, [sp, #640]
    7244:	f90147f8 	str	x24, [sp, #648]
    7248:	b4005af6 	cbz	x22, 7da4 <fwp_write+0xd90>
    724c:	aa1603e0 	mov	x0, x22
    7250:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7254:	9120c021 	add	x1, x1, #0x830
    7258:	97ffedce 	bl	2990 <strcmp@plt>
    725c:	2a0003f5 	mov	w21, w0
    7260:	34005fc0 	cbz	w0, 7e58 <fwp_write+0xe44>
    7264:	aa1603e0 	mov	x0, x22
    7268:	97ffed4e 	bl	27a0 <strlen@plt>
    726c:	aa1603e1 	mov	x1, x22
    7270:	aa0003e2 	mov	x2, x0
    7274:	aa1403e0 	mov	x0, x20
    7278:	97fff0e6 	bl	3610 <buf_put>
    727c:	52800403 	mov	w3, #0x20                  	// #32
    7280:	91001ff5 	add	x21, sp, #0x7
    7284:	aa1503e1 	mov	x1, x21
    7288:	aa1403e0 	mov	x0, x20
    728c:	d2800022 	mov	x2, #0x1                   	// #1
    7290:	39001fe3 	strb	w3, [sp, #7]
    7294:	97fff0df 	bl	3610 <buf_put>
    7298:	52800f63 	mov	w3, #0x7b                  	// #123
    729c:	aa1403e0 	mov	x0, x20
    72a0:	aa1503e1 	mov	x1, x21
    72a4:	d2800022 	mov	x2, #0x1                   	// #1
    72a8:	39001fe3 	strb	w3, [sp, #7]
    72ac:	97fff0d9 	bl	3610 <buf_put>
    72b0:	b9401380 	ldr	w0, [x28, #16]
    72b4:	52800018 	mov	w24, #0x0                   	// #0
    72b8:	7100001f 	cmp	w0, #0x0
    72bc:	54003a8d 	b.le	7a0c <fwp_write+0x9f8>
    72c0:	f9014bf9 	str	x25, [sp, #656]
    72c4:	d0000019 	adrp	x25, 9000 <__modti3+0xe0>
    72c8:	91216339 	add	x25, x25, #0x858
    72cc:	f9014ffa 	str	x26, [sp, #664]
    72d0:	d000001a 	adrp	x26, 9000 <__modti3+0xe0>
    72d4:	9120635a 	add	x26, x26, #0x818
    72d8:	91002276 	add	x22, x19, #0x8
    72dc:	d2800013 	mov	x19, #0x0                   	// #0
    72e0:	b5003e73 	cbnz	x19, 7aac <fwp_write+0xa98>
    72e4:	d37df277 	lsl	x23, x19, #3
    72e8:	34003c98 	cbz	w24, 7a78 <fwp_write+0xa64>
    72ec:	f9401382 	ldr	x2, [x28, #32]
    72f0:	aa1403e0 	mov	x0, x20
    72f4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    72f8:	52800003 	mov	w3, #0x0                   	// #0
    72fc:	f8776842 	ldr	x2, [x2, x23]
    7300:	91000673 	add	x19, x19, #0x1
    7304:	97ffff44 	bl	7014 <fwp_write>
    7308:	b9401380 	ldr	w0, [x28, #16]
    730c:	6b13001f 	cmp	w0, w19
    7310:	54fffe8c 	b.gt	72e0 <fwp_write+0x2cc>
    7314:	f9414bf9 	ldr	x25, [sp, #656]
    7318:	f9414ffa 	ldr	x26, [sp, #664]
    731c:	34003798 	cbz	w24, 7a0c <fwp_write+0x9f8>
    7320:	52800523 	mov	w3, #0x29                  	// #41
    7324:	aa1503e1 	mov	x1, x21
    7328:	aa1403e0 	mov	x0, x20
    732c:	d2800022 	mov	x2, #0x1                   	// #1
    7330:	39001fe3 	strb	w3, [sp, #7]
    7334:	97fff0b7 	bl	3610 <buf_put>
    7338:	f9413bf5 	ldr	x21, [sp, #624]
    733c:	f9413ff6 	ldr	x22, [sp, #632]
    7340:	f94143f7 	ldr	x23, [sp, #640]
    7344:	f94147f8 	ldr	x24, [sp, #648]
    7348:	f94153fb 	ldr	x27, [sp, #672]
    734c:	f94157fc 	ldr	x28, [sp, #680]
    7350:	17ffff5d 	b	70c4 <fwp_write+0xb0>
    7354:	b9404855 	ldr	w21, [x2, #72]
    7358:	aa1403e0 	mov	x0, x20
    735c:	93407eb6 	sxtw	x22, w21
    7360:	91000ac1 	add	x1, x22, #0x2
    7364:	97fff078 	bl	3544 <buf_grow>
    7368:	a9400281 	ldp	x1, x0, [x20]
    736c:	528e8603 	mov	w3, #0x7430                	// #29744
    7370:	78206823 	strh	w3, [x1, x0]
    7374:	8b000022 	add	x2, x1, x0
    7378:	710002bf 	cmp	w21, #0x0
    737c:	540036ad 	b.le	7a50 <fwp_write+0xa3c>
    7380:	110006a3 	add	w3, w21, #0x1
    7384:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7388:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    738c:	91000449 	add	x9, x2, #0x1
    7390:	8b23c043 	add	x3, x2, w3, sxtw
    7394:	f28aaac6 	movk	x6, #0x5556
    7398:	f2955568 	movk	x8, #0xaaab
    739c:	1400000d 	b	73d0 <fwp_write+0x3bc>
    73a0:	d2800021 	mov	x1, #0x1                   	// #1
    73a4:	528005a5 	mov	w5, #0x2d                  	// #45
    73a8:	f100001f 	cmp	x0, #0x0
    73ac:	9b467e60 	smulh	x0, x19, x6
    73b0:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    73b4:	381ff465 	strb	w5, [x3], #-1
    73b8:	cb040000 	sub	x0, x0, x4
    73bc:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    73c0:	cb020000 	sub	x0, x0, x2
    73c4:	8b010013 	add	x19, x0, x1
    73c8:	eb03013f 	cmp	x9, x3
    73cc:	54003420 	b.eq	7a50 <fwp_write+0xa3c>  // b.none
    73d0:	9b467e60 	smulh	x0, x19, x6
    73d4:	937ffe64 	asr	x4, x19, #63
    73d8:	52800605 	mov	w5, #0x30                  	// #48
    73dc:	cb040000 	sub	x0, x0, x4
    73e0:	8b000400 	add	x0, x0, x0, lsl #1
    73e4:	cb000260 	sub	x0, x19, x0
    73e8:	91000c01 	add	x1, x0, #0x3
    73ec:	9bc87c22 	umulh	x2, x1, x8
    73f0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    73f4:	8b4204e2 	add	x2, x7, x2, lsr #1
    73f8:	eb020021 	subs	x1, x1, x2
    73fc:	54fffd60 	b.eq	73a8 <fwp_write+0x394>  // b.none
    7400:	f100043f 	cmp	x1, #0x1
    7404:	54fffce1 	b.ne	73a0 <fwp_write+0x38c>  // b.any
    7408:	d2800001 	mov	x1, #0x0                   	// #0
    740c:	52800565 	mov	w5, #0x2b                  	// #43
    7410:	17ffffe6 	b	73a8 <fwp_write+0x394>
    7414:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7418:	f947f400 	ldr	x0, [x0, #4072]
    741c:	f94127e2 	ldr	x2, [sp, #584]
    7420:	f9400001 	ldr	x1, [x0]
    7424:	eb010042 	subs	x2, x2, x1
    7428:	d2800001 	mov	x1, #0x0                   	// #0
    742c:	540023a1 	b.ne	78a0 <fwp_write+0x88c>  // b.any
    7430:	f9413bf5 	ldr	x21, [sp, #624]
    7434:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7438:	f9413ff6 	ldr	x22, [sp, #632]
    743c:	aa1403e0 	mov	x0, x20
    7440:	911f0021 	add	x1, x1, #0x7c0
    7444:	d2800102 	mov	x2, #0x8                   	// #8
    7448:	17ffff77 	b	7224 <fwp_write+0x210>
    744c:	aa1403e0 	mov	x0, x20
    7450:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7454:	d28000c2 	mov	x2, #0x6                   	// #6
    7458:	91208021 	add	x1, x1, #0x820
    745c:	97fff06d 	bl	3610 <buf_put>
    7460:	d2800015 	mov	x21, #0x0                   	// #0
    7464:	f9400263 	ldr	x3, [x19]
    7468:	f240f87f 	tst	x3, #0x7fffffffffffffff
    746c:	54002c40 	b.eq	79f4 <fwp_write+0x9e0>  // b.none
    7470:	f9401f82 	ldr	x2, [x28, #56]
    7474:	f90143f7 	str	x23, [sp, #640]
    7478:	f90147f8 	str	x24, [sp, #648]
    747c:	d2800857 	mov	x23, #0x42                  	// #66
    7480:	f9014bf9 	str	x25, [sp, #656]
    7484:	d0000016 	adrp	x22, 9000 <__modti3+0xe0>
    7488:	f9014ffa 	str	x26, [sp, #664]
    748c:	912062d6 	add	x22, x22, #0x818
    7490:	d2800038 	mov	x24, #0x1                   	// #1
    7494:	f2a18017 	movk	x23, #0xc00, lsl #16
    7498:	d2809099 	mov	x25, #0x484                 	// #1156
    749c:	b4000482 	cbz	x2, 752c <fwp_write+0x518>
    74a0:	b9400040 	ldr	w0, [x2]
    74a4:	7100701f 	cmp	w0, #0x1c
    74a8:	540042a0 	b.eq	7cfc <fwp_write+0xce8>  // b.none
    74ac:	71006c1f 	cmp	w0, #0x1b
    74b0:	540003e8 	b.hi	752c <fwp_write+0x518>  // b.pmore
    74b4:	9ac02301 	lsl	x1, x24, x0
    74b8:	ea17003f 	tst	x1, x23
    74bc:	54003681 	b.ne	7b8c <fwp_write+0xb78>  // b.any
    74c0:	ea19003f 	tst	x1, x25
    74c4:	54003501 	b.ne	7b64 <fwp_write+0xb50>  // b.any
    74c8:	d2800424 	mov	x4, #0x21                  	// #33
    74cc:	ea04003f 	tst	x1, x4
    74d0:	540002e0 	b.eq	752c <fwp_write+0x518>  // b.none
    74d4:	b7f849a3 	tbnz	x3, #63, 7e08 <fwp_write+0xdf4>
    74d8:	91002261 	add	x1, x19, #0x8
    74dc:	8b150021 	add	x1, x1, x21
    74e0:	39400021 	ldrb	w1, [x1]
    74e4:	7100001f 	cmp	w0, #0x0
    74e8:	93401c23 	sxtb	x3, w1
    74ec:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    74f0:	aa1403e0 	mov	x0, x20
    74f4:	52800003 	mov	w3, #0x0                   	// #0
    74f8:	97fffec7 	bl	7014 <fwp_write>
    74fc:	910006b5 	add	x21, x21, #0x1
    7500:	f9400260 	ldr	x0, [x19]
    7504:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7508:	eb0002bf 	cmp	x21, x0
    750c:	540026c2 	b.cs	79e4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7510:	d2800042 	mov	x2, #0x2                   	// #2
    7514:	aa1603e1 	mov	x1, x22
    7518:	aa1403e0 	mov	x0, x20
    751c:	97fff03d 	bl	3610 <buf_put>
    7520:	f9401f82 	ldr	x2, [x28, #56]
    7524:	f9400263 	ldr	x3, [x19]
    7528:	b5fffbc2 	cbnz	x2, 74a0 <fwp_write+0x48c>
    752c:	d37df2a0 	lsl	x0, x21, #3
    7530:	b7f83f03 	tbnz	x3, #63, 7d10 <fwp_write+0xcfc>
    7534:	91002261 	add	x1, x19, #0x8
    7538:	8b000020 	add	x0, x1, x0
    753c:	f9400001 	ldr	x1, [x0]
    7540:	17ffffec 	b	74f0 <fwp_write+0x4dc>
    7544:	a9400e62 	ldp	x2, x3, [x19]
    7548:	b7f83ca3 	tbnz	x3, #63, 7cdc <fwp_write+0xcc8>
    754c:	910123f5 	add	x21, sp, #0x48
    7550:	aa1503e0 	mov	x0, x21
    7554:	97ffee53 	bl	2ea0 <fwp_fmt_u128>
    7558:	aa1503e0 	mov	x0, x21
    755c:	97ffec91 	bl	27a0 <strlen@plt>
    7560:	aa1503e1 	mov	x1, x21
    7564:	aa0003e2 	mov	x2, x0
    7568:	17fffed1 	b	70ac <fwp_write+0x98>
    756c:	fd015be8 	str	d8, [sp, #688]
    7570:	1e270268 	fmov	s8, w19
    7574:	fd015fe9 	str	d9, [sp, #696]
    7578:	1e282100 	fcmp	s8, s8
    757c:	54004d26 	b.vs	7f20 <fwp_write+0xf0c>
    7580:	1e20c101 	fabs	s1, s8
    7584:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7588:	1e270000 	fmov	s0, w0
    758c:	1e202020 	fcmp	s1, s0
    7590:	54002c0d 	b.le	7b10 <fwp_write+0xafc>
    7594:	1e202118 	fcmpe	s8, #0.0
    7598:	d0000002 	adrp	x2, 9000 <__modti3+0xe0>
    759c:	910e6042 	add	x2, x2, #0x398
    75a0:	910123f5 	add	x21, sp, #0x48
    75a4:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    75a8:	911dc021 	add	x1, x1, #0x770
    75ac:	aa1503e0 	mov	x0, x21
    75b0:	9a81c041 	csel	x1, x2, x1, gt
    75b4:	97ffed27 	bl	2a50 <strcpy@plt>
    75b8:	aa1503e0 	mov	x0, x21
    75bc:	97ffec79 	bl	27a0 <strlen@plt>
    75c0:	aa1503e1 	mov	x1, x21
    75c4:	aa0003e2 	mov	x2, x0
    75c8:	aa1403e0 	mov	x0, x20
    75cc:	97fff011 	bl	3610 <buf_put>
    75d0:	f9413bf5 	ldr	x21, [sp, #624]
    75d4:	f9413ff6 	ldr	x22, [sp, #632]
    75d8:	f94153fb 	ldr	x27, [sp, #672]
    75dc:	f94157fc 	ldr	x28, [sp, #680]
    75e0:	fd415be8 	ldr	d8, [sp, #688]
    75e4:	fd415fe9 	ldr	d9, [sp, #696]
    75e8:	17fffeb7 	b	70c4 <fwp_write+0xb0>
    75ec:	f9400276 	ldr	x22, [x19]
    75f0:	34002e03 	cbz	w3, 7bb0 <fwp_write+0xb9c>
    75f4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    75f8:	f947f400 	ldr	x0, [x0, #4072]
    75fc:	f94127e2 	ldr	x2, [sp, #584]
    7600:	f9400001 	ldr	x1, [x0]
    7604:	eb010042 	subs	x2, x2, x1
    7608:	d2800001 	mov	x1, #0x0                   	// #0
    760c:	540014a1 	b.ne	78a0 <fwp_write+0x88c>  // b.any
    7610:	aa1603e2 	mov	x2, x22
    7614:	91002261 	add	x1, x19, #0x8
    7618:	f9413bf5 	ldr	x21, [sp, #624]
    761c:	aa1403e0 	mov	x0, x20
    7620:	f9413ff6 	ldr	x22, [sp, #632]
    7624:	17ffff00 	b	7224 <fwp_write+0x210>
    7628:	fd015be8 	str	d8, [sp, #688]
    762c:	9e670268 	fmov	d8, x19
    7630:	fd015fe9 	str	d9, [sp, #696]
    7634:	1e682100 	fcmp	d8, d8
    7638:	54004746 	b.vs	7f20 <fwp_write+0xf0c>
    763c:	1e60c101 	fabs	d1, d8
    7640:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7644:	9e670000 	fmov	d0, x0
    7648:	910123f5 	add	x21, sp, #0x48
    764c:	52800033 	mov	w19, #0x1                   	// #1
    7650:	1e602020 	fcmp	d1, d0
    7654:	540001ad 	b.le	7688 <fwp_write+0x674>
    7658:	1e602118 	fcmpe	d8, #0.0
    765c:	d0000002 	adrp	x2, 9000 <__modti3+0xe0>
    7660:	910e6042 	add	x2, x2, #0x398
    7664:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7668:	911dc021 	add	x1, x1, #0x770
    766c:	aa1503e0 	mov	x0, x21
    7670:	9a81c041 	csel	x1, x2, x1, gt
    7674:	97ffecf7 	bl	2a50 <strcpy@plt>
    7678:	17ffffd0 	b	75b8 <fwp_write+0x5a4>
    767c:	11000673 	add	w19, w19, #0x1
    7680:	71004a7f 	cmp	w19, #0x12
    7684:	54003860 	b.eq	7d90 <fwp_write+0xd7c>  // b.none
    7688:	1e604100 	fmov	d0, d8
    768c:	2a1303e1 	mov	w1, w19
    7690:	aa1503e0 	mov	x0, x21
    7694:	97fff160 	bl	3c14 <fwp_format_g.constprop.0>
    7698:	aa1503e0 	mov	x0, x21
    769c:	d2800001 	mov	x1, #0x0                   	// #0
    76a0:	97ffec54 	bl	27f0 <strtod@plt>
    76a4:	1e602100 	fcmp	d8, d0
    76a8:	54fffea1 	b.ne	767c <fwp_write+0x668>  // b.any
    76ac:	aa1503e0 	mov	x0, x21
    76b0:	97fff051 	bl	37f4 <fwp_finish_float>
    76b4:	17ffffc1 	b	75b8 <fwp_write+0x5a4>
    76b8:	a9400e62 	ldp	x2, x3, [x19]
    76bc:	910123f3 	add	x19, sp, #0x48
    76c0:	aa1303e0 	mov	x0, x19
    76c4:	97ffedf7 	bl	2ea0 <fwp_fmt_u128>
    76c8:	17fffe75 	b	709c <fwp_write+0x88>
    76cc:	f90143f7 	str	x23, [sp, #640]
    76d0:	f90147f8 	str	x24, [sp, #648]
    76d4:	2a1303f8 	mov	w24, w19
    76d8:	f9014bf9 	str	x25, [sp, #656]
    76dc:	f9014ffa 	str	x26, [sp, #664]
    76e0:	f13ffe7f 	cmp	x19, #0xfff
    76e4:	54000049 	b.ls	76ec <fwp_write+0x6d8>  // b.plast
    76e8:	b9400278 	ldr	w24, [x19]
    76ec:	f9400f80 	ldr	x0, [x28, #24]
    76f0:	2a1803f5 	mov	w21, w24
    76f4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    76f8:	d37ef6b9 	lsl	x25, x21, #2
    76fc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7700:	aa1603e0 	mov	x0, x22
    7704:	97ffec27 	bl	27a0 <strlen@plt>
    7708:	aa1603e1 	mov	x1, x22
    770c:	aa0003e2 	mov	x2, x0
    7710:	aa1403e0 	mov	x0, x20
    7714:	97ffefbf 	bl	3610 <buf_put>
    7718:	f9401780 	ldr	x0, [x28, #40]
    771c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7720:	7100001f 	cmp	w0, #0x0
    7724:	5400068d 	b.le	77f4 <fwp_write+0x7e0>
    7728:	91002276 	add	x22, x19, #0x8
    772c:	91001ff5 	add	x21, sp, #0x7
    7730:	d280001b 	mov	x27, #0x0                   	// #0
    7734:	5280041a 	mov	w26, #0x20                  	// #32
    7738:	f9401b80 	ldr	x0, [x28, #48]
    773c:	aa1503e1 	mov	x1, x21
    7740:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7744:	d2800022 	mov	x2, #0x1                   	// #1
    7748:	f8786803 	ldr	x3, [x0, x24]
    774c:	aa1403e0 	mov	x0, x20
    7750:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7754:	39001ffa 	strb	w26, [sp, #7]
    7758:	97ffefae 	bl	3610 <buf_put>
    775c:	f13ffeff 	cmp	x23, #0xfff
    7760:	b9400261 	ldr	w1, [x19]
    7764:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7768:	7100383f 	cmp	w1, #0xe
    776c:	54000160 	b.eq	7798 <fwp_write+0x784>  // b.none
    7770:	7100403f 	cmp	w1, #0x10
    7774:	54001a60 	b.eq	7ac0 <fwp_write+0xaac>  // b.none
    7778:	7100283f 	cmp	w1, #0xa
    777c:	54002aa0 	b.eq	7cd0 <fwp_write+0xcbc>  // b.none
    7780:	540014ac 	b.gt	7a14 <fwp_write+0xa00>
    7784:	71000c3f 	cmp	w1, #0x3
    7788:	540029ac 	b.gt	7cbc <fwp_write+0xca8>
    778c:	d37ffee0 	lsr	x0, x23, #63
    7790:	37f814a1 	tbnz	w1, #31, 7a24 <fwp_write+0xa10>
    7794:	d503201f 	nop
    7798:	34001460 	cbz	w0, 7a24 <fwp_write+0xa10>
    779c:	52800503 	mov	w3, #0x28                  	// #40
    77a0:	aa1503e1 	mov	x1, x21
    77a4:	aa1403e0 	mov	x0, x20
    77a8:	d2800022 	mov	x2, #0x1                   	// #1
    77ac:	39001fe3 	strb	w3, [sp, #7]
    77b0:	97ffef98 	bl	3610 <buf_put>
    77b4:	aa1303e2 	mov	x2, x19
    77b8:	aa1703e1 	mov	x1, x23
    77bc:	aa1403e0 	mov	x0, x20
    77c0:	52800003 	mov	w3, #0x0                   	// #0
    77c4:	97fffe14 	bl	7014 <fwp_write>
    77c8:	52800523 	mov	w3, #0x29                  	// #41
    77cc:	aa1503e1 	mov	x1, x21
    77d0:	aa1403e0 	mov	x0, x20
    77d4:	d2800022 	mov	x2, #0x1                   	// #1
    77d8:	39001fe3 	strb	w3, [sp, #7]
    77dc:	97ffef8d 	bl	3610 <buf_put>
    77e0:	f9401780 	ldr	x0, [x28, #40]
    77e4:	9100077b 	add	x27, x27, #0x1
    77e8:	b8796800 	ldr	w0, [x0, x25]
    77ec:	6b1b001f 	cmp	w0, w27
    77f0:	54fffa4c 	b.gt	7738 <fwp_write+0x724>
    77f4:	f9413bf5 	ldr	x21, [sp, #624]
    77f8:	f9413ff6 	ldr	x22, [sp, #632]
    77fc:	f94143f7 	ldr	x23, [sp, #640]
    7800:	f94147f8 	ldr	x24, [sp, #648]
    7804:	f9414bf9 	ldr	x25, [sp, #656]
    7808:	f9414ffa 	ldr	x26, [sp, #664]
    780c:	f94153fb 	ldr	x27, [sp, #672]
    7810:	f94157fc 	ldr	x28, [sp, #680]
    7814:	17fffe2c 	b	70c4 <fwp_write+0xb0>
    7818:	52800783 	mov	w3, #0x3c                  	// #60
    781c:	91001ff3 	add	x19, sp, #0x7
    7820:	aa1303e1 	mov	x1, x19
    7824:	d2800022 	mov	x2, #0x1                   	// #1
    7828:	aa1403e0 	mov	x0, x20
    782c:	39001fe3 	strb	w3, [sp, #7]
    7830:	97ffef78 	bl	3610 <buf_put>
    7834:	f9400795 	ldr	x21, [x28, #8]
    7838:	aa1503e0 	mov	x0, x21
    783c:	97ffebd9 	bl	27a0 <strlen@plt>
    7840:	aa1503e1 	mov	x1, x21
    7844:	aa0003e2 	mov	x2, x0
    7848:	aa1403e0 	mov	x0, x20
    784c:	97ffef71 	bl	3610 <buf_put>
    7850:	528007c3 	mov	w3, #0x3e                  	// #62
    7854:	aa1303e1 	mov	x1, x19
    7858:	aa1403e0 	mov	x0, x20
    785c:	d2800022 	mov	x2, #0x1                   	// #1
    7860:	39001fe3 	strb	w3, [sp, #7]
    7864:	17fffe13 	b	70b0 <fwp_write+0x9c>
    7868:	f100067f 	cmp	x19, #0x1
    786c:	540025a0 	b.eq	7d20 <fwp_write+0xd0c>  // b.none
    7870:	b100067f 	cmn	x19, #0x1
    7874:	54002bc0 	b.eq	7dec <fwp_write+0xdd8>  // b.none
    7878:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    787c:	911de021 	add	x1, x1, #0x778
    7880:	d2800022 	mov	x2, #0x1                   	// #1
    7884:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7888:	f947f400 	ldr	x0, [x0, #4072]
    788c:	f94127e4 	ldr	x4, [sp, #584]
    7890:	f9400003 	ldr	x3, [x0]
    7894:	eb030084 	subs	x4, x4, x3
    7898:	d2800003 	mov	x3, #0x0                   	// #0
    789c:	54ffebe0 	b.eq	7618 <fwp_write+0x604>  // b.none
    78a0:	f90143f7 	str	x23, [sp, #640]
    78a4:	f90147f8 	str	x24, [sp, #648]
    78a8:	f9014bf9 	str	x25, [sp, #656]
    78ac:	f9014ffa 	str	x26, [sp, #664]
    78b0:	fd015be8 	str	d8, [sp, #688]
    78b4:	fd015fe9 	str	d9, [sp, #696]
    78b8:	97ffec16 	bl	2910 <__stack_chk_fail@plt>
    78bc:	52800b63 	mov	w3, #0x5b                  	// #91
    78c0:	91001ff5 	add	x21, sp, #0x7
    78c4:	aa1503e1 	mov	x1, x21
    78c8:	aa1403e0 	mov	x0, x20
    78cc:	d2800022 	mov	x2, #0x1                   	// #1
    78d0:	d0000016 	adrp	x22, 9000 <__modti3+0xe0>
    78d4:	912062d6 	add	x22, x22, #0x818
    78d8:	39001fe3 	strb	w3, [sp, #7]
    78dc:	97ffef4d 	bl	3610 <buf_put>
    78e0:	b4000273 	cbz	x19, 792c <fwp_write+0x918>
    78e4:	f9400661 	ldr	x1, [x19, #8]
    78e8:	aa1403e0 	mov	x0, x20
    78ec:	f9401f82 	ldr	x2, [x28, #56]
    78f0:	52800003 	mov	w3, #0x0                   	// #0
    78f4:	97fffdc8 	bl	7014 <fwp_write>
    78f8:	f9400a73 	ldr	x19, [x19, #16]
    78fc:	b4000193 	cbz	x19, 792c <fwp_write+0x918>
    7900:	aa1603e1 	mov	x1, x22
    7904:	aa1403e0 	mov	x0, x20
    7908:	d2800042 	mov	x2, #0x2                   	// #2
    790c:	97ffef41 	bl	3610 <buf_put>
    7910:	f9400661 	ldr	x1, [x19, #8]
    7914:	aa1403e0 	mov	x0, x20
    7918:	f9401f82 	ldr	x2, [x28, #56]
    791c:	52800003 	mov	w3, #0x0                   	// #0
    7920:	97fffdbd 	bl	7014 <fwp_write>
    7924:	f9400a73 	ldr	x19, [x19, #16]
    7928:	b5fffed3 	cbnz	x19, 7900 <fwp_write+0x8ec>
    792c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7930:	aa1503e1 	mov	x1, x21
    7934:	aa1403e0 	mov	x0, x20
    7938:	d2800022 	mov	x2, #0x1                   	// #1
    793c:	39001fe3 	strb	w3, [sp, #7]
    7940:	17fffddc 	b	70b0 <fwp_write+0x9c>
    7944:	aa1403e0 	mov	x0, x20
    7948:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    794c:	d28000c2 	mov	x2, #0x6                   	// #6
    7950:	91202021 	add	x1, x1, #0x808
    7954:	97ffef2f 	bl	3610 <buf_put>
    7958:	f9400260 	ldr	x0, [x19]
    795c:	b40004c0 	cbz	x0, 79f4 <fwp_write+0x9e0>
    7960:	910123f5 	add	x21, sp, #0x48
    7964:	91002276 	add	x22, x19, #0x8
    7968:	f90143f7 	str	x23, [sp, #640]
    796c:	d2800017 	mov	x23, #0x0                   	// #0
    7970:	f90147f8 	str	x24, [sp, #648]
    7974:	d0000018 	adrp	x24, 9000 <__modti3+0xe0>
    7978:	91204318 	add	x24, x24, #0x810
    797c:	f9014bf9 	str	x25, [sp, #656]
    7980:	d0000019 	adrp	x25, 9000 <__modti3+0xe0>
    7984:	91206339 	add	x25, x25, #0x818
    7988:	f9014ffa 	str	x26, [sp, #664]
    798c:	14000005 	b	79a0 <fwp_write+0x98c>
    7990:	aa1903e1 	mov	x1, x25
    7994:	aa1403e0 	mov	x0, x20
    7998:	d2800042 	mov	x2, #0x2                   	// #2
    799c:	97ffef1d 	bl	3610 <buf_put>
    79a0:	38776ac5 	ldrb	w5, [x22, x23]
    79a4:	d2804003 	mov	x3, #0x200                 	// #512
    79a8:	aa1803e4 	mov	x4, x24
    79ac:	aa0303e1 	mov	x1, x3
    79b0:	52800042 	mov	w2, #0x2                   	// #2
    79b4:	aa1503e0 	mov	x0, x21
    79b8:	910006f7 	add	x23, x23, #0x1
    79bc:	97ffebb1 	bl	2880 <__snprintf_chk@plt>
    79c0:	aa1503e0 	mov	x0, x21
    79c4:	97ffeb77 	bl	27a0 <strlen@plt>
    79c8:	aa1503e1 	mov	x1, x21
    79cc:	aa0003e2 	mov	x2, x0
    79d0:	aa1403e0 	mov	x0, x20
    79d4:	97ffef0f 	bl	3610 <buf_put>
    79d8:	f9400260 	ldr	x0, [x19]
    79dc:	eb17001f 	cmp	x0, x23
    79e0:	54fffd88 	b.hi	7990 <fwp_write+0x97c>  // b.pmore
    79e4:	f94143f7 	ldr	x23, [sp, #640]
    79e8:	f94147f8 	ldr	x24, [sp, #648]
    79ec:	f9414bf9 	ldr	x25, [sp, #656]
    79f0:	f9414ffa 	ldr	x26, [sp, #664]
    79f4:	52800ba3 	mov	w3, #0x5d                  	// #93
    79f8:	aa1403e0 	mov	x0, x20
    79fc:	91001fe1 	add	x1, sp, #0x7
    7a00:	d2800022 	mov	x2, #0x1                   	// #1
    7a04:	39001fe3 	strb	w3, [sp, #7]
    7a08:	17fffdaa 	b	70b0 <fwp_write+0x9c>
    7a0c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7a10:	17fffe45 	b	7324 <fwp_write+0x310>
    7a14:	f10002ff 	cmp	x23, #0x0
    7a18:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7a1c:	71002c3f 	cmp	w1, #0xb
    7a20:	54ffebc0 	b.eq	7798 <fwp_write+0x784>  // b.none
    7a24:	aa1303e2 	mov	x2, x19
    7a28:	aa1703e1 	mov	x1, x23
    7a2c:	aa1403e0 	mov	x0, x20
    7a30:	52800003 	mov	w3, #0x0                   	// #0
    7a34:	97fffd78 	bl	7014 <fwp_write>
    7a38:	17ffff6a 	b	77e0 <fwp_write+0x7cc>
    7a3c:	aa1403e0 	mov	x0, x20
    7a40:	91001fe1 	add	x1, sp, #0x7
    7a44:	52800fa3 	mov	w3, #0x7d                  	// #125
    7a48:	d2800022 	mov	x2, #0x1                   	// #1
    7a4c:	17fffe39 	b	7330 <fwp_write+0x31c>
    7a50:	a9400281 	ldp	x1, x0, [x20]
    7a54:	91000800 	add	x0, x0, #0x2
    7a58:	8b160000 	add	x0, x0, x22
    7a5c:	f9000680 	str	x0, [x20, #8]
    7a60:	3820683f 	strb	wzr, [x1, x0]
    7a64:	f9413bf5 	ldr	x21, [sp, #624]
    7a68:	f9413ff6 	ldr	x22, [sp, #632]
    7a6c:	f94153fb 	ldr	x27, [sp, #672]
    7a70:	f94157fc 	ldr	x28, [sp, #680]
    7a74:	17fffd94 	b	70c4 <fwp_write+0xb0>
    7a78:	f9400f80 	ldr	x0, [x28, #24]
    7a7c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7a80:	aa1b03e0 	mov	x0, x27
    7a84:	97ffeb47 	bl	27a0 <strlen@plt>
    7a88:	aa1b03e1 	mov	x1, x27
    7a8c:	aa0003e2 	mov	x2, x0
    7a90:	aa1403e0 	mov	x0, x20
    7a94:	97ffeedf 	bl	3610 <buf_put>
    7a98:	aa1903e1 	mov	x1, x25
    7a9c:	aa1403e0 	mov	x0, x20
    7aa0:	d2800062 	mov	x2, #0x3                   	// #3
    7aa4:	97ffeedb 	bl	3610 <buf_put>
    7aa8:	17fffe11 	b	72ec <fwp_write+0x2d8>
    7aac:	aa1a03e1 	mov	x1, x26
    7ab0:	aa1403e0 	mov	x0, x20
    7ab4:	d2800042 	mov	x2, #0x2                   	// #2
    7ab8:	97ffeed6 	bl	3610 <buf_put>
    7abc:	17fffe0a 	b	72e4 <fwp_write+0x2d0>
    7ac0:	f9400660 	ldr	x0, [x19, #8]
    7ac4:	b4fffb00 	cbz	x0, 7a24 <fwp_write+0xa10>
    7ac8:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7acc:	9120c021 	add	x1, x1, #0x830
    7ad0:	97ffebb0 	bl	2990 <strcmp@plt>
    7ad4:	7100001f 	cmp	w0, #0x0
    7ad8:	1a9f07e0 	cset	w0, ne	// ne = any
    7adc:	17ffff2f 	b	7798 <fwp_write+0x784>
    7ae0:	aa1403e0 	mov	x0, x20
    7ae4:	d2800042 	mov	x2, #0x2                   	// #2
    7ae8:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7aec:	9120a021 	add	x1, x1, #0x828
    7af0:	97ffeec8 	bl	3610 <buf_put>
    7af4:	91004261 	add	x1, x19, #0x10
    7af8:	aa1403e0 	mov	x0, x20
    7afc:	f9402382 	ldr	x2, [x28, #64]
    7b00:	52800003 	mov	w3, #0x0                   	// #0
    7b04:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7b08:	97fffd43 	bl	7014 <fwp_write>
    7b0c:	17fffd9d 	b	7180 <fwp_write+0x16c>
    7b10:	1e22c109 	fcvt	d9, s8
    7b14:	910123f5 	add	x21, sp, #0x48
    7b18:	52800033 	mov	w19, #0x1                   	// #1
    7b1c:	d503201f 	nop
    7b20:	1e604120 	fmov	d0, d9
    7b24:	2a1303e1 	mov	w1, w19
    7b28:	aa1503e0 	mov	x0, x21
    7b2c:	97fff03a 	bl	3c14 <fwp_format_g.constprop.0>
    7b30:	aa1503e0 	mov	x0, x21
    7b34:	d2800001 	mov	x1, #0x0                   	// #0
    7b38:	97ffeba2 	bl	29c0 <strtof@plt>
    7b3c:	1e202100 	fcmp	s8, s0
    7b40:	54ffdb60 	b.eq	76ac <fwp_write+0x698>  // b.none
    7b44:	11000673 	add	w19, w19, #0x1
    7b48:	71002a7f 	cmp	w19, #0xa
    7b4c:	54fffea1 	b.ne	7b20 <fwp_write+0xb0c>  // b.any
    7b50:	1e604120 	fmov	d0, d9
    7b54:	aa1503e0 	mov	x0, x21
    7b58:	52800121 	mov	w1, #0x9                   	// #9
    7b5c:	97fff02e 	bl	3c14 <fwp_format_g.constprop.0>
    7b60:	17fffed3 	b	76ac <fwp_write+0x698>
    7b64:	d37ef6a1 	lsl	x1, x21, #2
    7b68:	b7f81563 	tbnz	x3, #63, 7e14 <fwp_write+0xe00>
    7b6c:	91002263 	add	x3, x19, #0x8
    7b70:	8b010061 	add	x1, x3, x1
    7b74:	b9400023 	ldr	w3, [x1]
    7b78:	7100081f 	cmp	w0, #0x2
    7b7c:	2a0303e1 	mov	w1, w3
    7b80:	93407c63 	sxtw	x3, w3
    7b84:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7b88:	17fffe5a 	b	74f0 <fwp_write+0x4dc>
    7b8c:	d37ffaa1 	lsl	x1, x21, #1
    7b90:	b7f81363 	tbnz	x3, #63, 7dfc <fwp_write+0xde8>
    7b94:	91002263 	add	x3, x19, #0x8
    7b98:	8b010061 	add	x1, x3, x1
    7b9c:	79400021 	ldrh	w1, [x1]
    7ba0:	7100041f 	cmp	w0, #0x1
    7ba4:	93403c23 	sxth	x3, w1
    7ba8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7bac:	17fffe51 	b	74f0 <fwp_write+0x4dc>
    7bb0:	52800443 	mov	w3, #0x22                  	// #34
    7bb4:	91001ff5 	add	x21, sp, #0x7
    7bb8:	91002273 	add	x19, x19, #0x8
    7bbc:	aa1503e1 	mov	x1, x21
    7bc0:	aa1403e0 	mov	x0, x20
    7bc4:	d2800022 	mov	x2, #0x1                   	// #1
    7bc8:	39001fe3 	strb	w3, [sp, #7]
    7bcc:	f90143f7 	str	x23, [sp, #640]
    7bd0:	8b160277 	add	x23, x19, x22
    7bd4:	f90147f8 	str	x24, [sp, #648]
    7bd8:	97ffee8e 	bl	3610 <buf_put>
    7bdc:	b4000696 	cbz	x22, 7cac <fwp_write+0xc98>
    7be0:	d0000018 	adrp	x24, 9000 <__modti3+0xe0>
    7be4:	911f6318 	add	x24, x24, #0x7d8
    7be8:	f9014bf9 	str	x25, [sp, #656]
    7bec:	d0000019 	adrp	x25, 9000 <__modti3+0xe0>
    7bf0:	911fe339 	add	x25, x25, #0x7f8
    7bf4:	f9014ffa 	str	x26, [sp, #664]
    7bf8:	1400000d 	b	7c2c <fwp_write+0xc18>
    7bfc:	710024bf 	cmp	w5, #0x9
    7c00:	54000460 	b.eq	7c8c <fwp_write+0xc78>  // b.none
    7c04:	710028bf 	cmp	w5, #0xa
    7c08:	54000a61 	b.ne	7d54 <fwp_write+0xd40>  // b.any
    7c0c:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7c10:	aa1403e0 	mov	x0, x20
    7c14:	911fa021 	add	x1, x1, #0x7e8
    7c18:	d2800042 	mov	x2, #0x2                   	// #2
    7c1c:	97ffee7d 	bl	3610 <buf_put>
    7c20:	91000673 	add	x19, x19, #0x1
    7c24:	eb17027f 	cmp	x19, x23
    7c28:	540003e0 	b.eq	7ca4 <fwp_write+0xc90>  // b.none
    7c2c:	39400265 	ldrb	w5, [x19]
    7c30:	710034bf 	cmp	w5, #0xd
    7c34:	54000180 	b.eq	7c64 <fwp_write+0xc50>  // b.none
    7c38:	54fffe29 	b.ls	7bfc <fwp_write+0xbe8>  // b.plast
    7c3c:	710088bf 	cmp	w5, #0x22
    7c40:	540001c0 	b.eq	7c78 <fwp_write+0xc64>  // b.none
    7c44:	710170bf 	cmp	w5, #0x5c
    7c48:	54000741 	b.ne	7d30 <fwp_write+0xd1c>  // b.any
    7c4c:	aa1403e0 	mov	x0, x20
    7c50:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7c54:	d2800042 	mov	x2, #0x2                   	// #2
    7c58:	911f8021 	add	x1, x1, #0x7e0
    7c5c:	97ffee6d 	bl	3610 <buf_put>
    7c60:	17fffff0 	b	7c20 <fwp_write+0xc0c>
    7c64:	aa1903e1 	mov	x1, x25
    7c68:	aa1403e0 	mov	x0, x20
    7c6c:	d2800042 	mov	x2, #0x2                   	// #2
    7c70:	97ffee68 	bl	3610 <buf_put>
    7c74:	17ffffeb 	b	7c20 <fwp_write+0xc0c>
    7c78:	aa1803e1 	mov	x1, x24
    7c7c:	aa1403e0 	mov	x0, x20
    7c80:	d2800042 	mov	x2, #0x2                   	// #2
    7c84:	97ffee63 	bl	3610 <buf_put>
    7c88:	17ffffe6 	b	7c20 <fwp_write+0xc0c>
    7c8c:	aa1403e0 	mov	x0, x20
    7c90:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7c94:	d2800042 	mov	x2, #0x2                   	// #2
    7c98:	911fc021 	add	x1, x1, #0x7f0
    7c9c:	97ffee5d 	bl	3610 <buf_put>
    7ca0:	17ffffe0 	b	7c20 <fwp_write+0xc0c>
    7ca4:	f9414bf9 	ldr	x25, [sp, #656]
    7ca8:	f9414ffa 	ldr	x26, [sp, #664]
    7cac:	aa1503e1 	mov	x1, x21
    7cb0:	aa1403e0 	mov	x0, x20
    7cb4:	52800443 	mov	w3, #0x22                  	// #34
    7cb8:	17fffd9d 	b	732c <fwp_write+0x318>
    7cbc:	7100103f 	cmp	w1, #0x4
    7cc0:	54ffeb21 	b.ne	7a24 <fwp_write+0xa10>  // b.any
    7cc4:	f94006e0 	ldr	x0, [x23, #8]
    7cc8:	d37ffc00 	lsr	x0, x0, #63
    7ccc:	17fffeb3 	b	7798 <fwp_write+0x784>
    7cd0:	710002ff 	cmp	w23, #0x0
    7cd4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7cd8:	17fffeb0 	b	7798 <fwp_write+0x784>
    7cdc:	528005a1 	mov	w1, #0x2d                  	// #45
    7ce0:	eb0203e2 	negs	x2, x2
    7ce4:	da0303e3 	ngc	x3, x3
    7ce8:	910127e0 	add	x0, sp, #0x49
    7cec:	910123f5 	add	x21, sp, #0x48
    7cf0:	390123e1 	strb	w1, [sp, #72]
    7cf4:	97ffec6b 	bl	2ea0 <fwp_fmt_u128>
    7cf8:	17fffe18 	b	7558 <fwp_write+0x544>
    7cfc:	d37ceea1 	lsl	x1, x21, #4
    7d00:	b7f810a3 	tbnz	x3, #63, 7f14 <fwp_write+0xf00>
    7d04:	91002260 	add	x0, x19, #0x8
    7d08:	8b010001 	add	x1, x0, x1
    7d0c:	17fffdf9 	b	74f0 <fwp_write+0x4dc>
    7d10:	f9400a61 	ldr	x1, [x19, #16]
    7d14:	8b010000 	add	x0, x0, x1
    7d18:	f9400001 	ldr	x1, [x0]
    7d1c:	17fffdf5 	b	74f0 <fwp_write+0x4dc>
    7d20:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7d24:	d2800042 	mov	x2, #0x2                   	// #2
    7d28:	911e0021 	add	x1, x1, #0x780
    7d2c:	17fffed6 	b	7884 <fwp_write+0x870>
    7d30:	7101fcbf 	cmp	w5, #0x7f
    7d34:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7d38:	540000e9 	b.ls	7d54 <fwp_write+0xd40>  // b.plast
    7d3c:	aa1503e1 	mov	x1, x21
    7d40:	aa1403e0 	mov	x0, x20
    7d44:	d2800022 	mov	x2, #0x1                   	// #1
    7d48:	39001fe5 	strb	w5, [sp, #7]
    7d4c:	97ffee31 	bl	3610 <buf_put>
    7d50:	17ffffb4 	b	7c20 <fwp_write+0xc0c>
    7d54:	d2800203 	mov	x3, #0x10                  	// #16
    7d58:	d0000004 	adrp	x4, 9000 <__modti3+0xe0>
    7d5c:	aa0303e1 	mov	x1, x3
    7d60:	91200084 	add	x4, x4, #0x800
    7d64:	910123f6 	add	x22, sp, #0x48
    7d68:	52800042 	mov	w2, #0x2                   	// #2
    7d6c:	aa1603e0 	mov	x0, x22
    7d70:	97ffeac4 	bl	2880 <__snprintf_chk@plt>
    7d74:	aa1603e0 	mov	x0, x22
    7d78:	97ffea8a 	bl	27a0 <strlen@plt>
    7d7c:	aa1603e1 	mov	x1, x22
    7d80:	aa0003e2 	mov	x2, x0
    7d84:	aa1403e0 	mov	x0, x20
    7d88:	97ffee22 	bl	3610 <buf_put>
    7d8c:	17ffffa5 	b	7c20 <fwp_write+0xc0c>
    7d90:	1e604100 	fmov	d0, d8
    7d94:	aa1503e0 	mov	x0, x21
    7d98:	52800221 	mov	w1, #0x11                  	// #17
    7d9c:	97ffef9e 	bl	3c14 <fwp_format_g.constprop.0>
    7da0:	17fffe43 	b	76ac <fwp_write+0x698>
    7da4:	b9401040 	ldr	w0, [x2, #16]
    7da8:	350003c0 	cbnz	w0, 7e20 <fwp_write+0xe0c>
    7dac:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7db0:	f947f400 	ldr	x0, [x0, #4072]
    7db4:	f94127e2 	ldr	x2, [sp, #584]
    7db8:	f9400001 	ldr	x1, [x0]
    7dbc:	eb010042 	subs	x2, x2, x1
    7dc0:	d2800001 	mov	x1, #0x0                   	// #0
    7dc4:	54ffd721 	b.ne	78a8 <fwp_write+0x894>  // b.any
    7dc8:	f9413bf5 	ldr	x21, [sp, #624]
    7dcc:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7dd0:	f9413ff6 	ldr	x22, [sp, #632]
    7dd4:	aa1403e0 	mov	x0, x20
    7dd8:	f94143f7 	ldr	x23, [sp, #640]
    7ddc:	91214021 	add	x1, x1, #0x850
    7de0:	f94147f8 	ldr	x24, [sp, #648]
    7de4:	d2800042 	mov	x2, #0x2                   	// #2
    7de8:	17fffd0f 	b	7224 <fwp_write+0x210>
    7dec:	d0000001 	adrp	x1, 9000 <__modti3+0xe0>
    7df0:	d2800042 	mov	x2, #0x2                   	// #2
    7df4:	911e2021 	add	x1, x1, #0x788
    7df8:	17fffea3 	b	7884 <fwp_write+0x870>
    7dfc:	f9400a63 	ldr	x3, [x19, #16]
    7e00:	8b030021 	add	x1, x1, x3
    7e04:	17ffff66 	b	7b9c <fwp_write+0xb88>
    7e08:	f9400a61 	ldr	x1, [x19, #16]
    7e0c:	8b0102a1 	add	x1, x21, x1
    7e10:	17fffdb4 	b	74e0 <fwp_write+0x4cc>
    7e14:	f9400a63 	ldr	x3, [x19, #16]
    7e18:	8b030021 	add	x1, x1, x3
    7e1c:	17ffff56 	b	7b74 <fwp_write+0xb60>
    7e20:	b9404840 	ldr	w0, [x2, #72]
    7e24:	91001ff5 	add	x21, sp, #0x7
    7e28:	34ffa380 	cbz	w0, 7298 <fwp_write+0x284>
    7e2c:	52800503 	mov	w3, #0x28                  	// #40
    7e30:	aa1403e0 	mov	x0, x20
    7e34:	aa1503e1 	mov	x1, x21
    7e38:	d2800022 	mov	x2, #0x1                   	// #1
    7e3c:	39001fe3 	strb	w3, [sp, #7]
    7e40:	97ffedf4 	bl	3610 <buf_put>
    7e44:	b9401380 	ldr	w0, [x28, #16]
    7e48:	52800038 	mov	w24, #0x1                   	// #1
    7e4c:	7100001f 	cmp	w0, #0x0
    7e50:	54ffa38c 	b.gt	72c0 <fwp_write+0x2ac>
    7e54:	17fffd33 	b	7320 <fwp_write+0x30c>
    7e58:	f9014bf9 	str	x25, [sp, #656]
    7e5c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x12d80>
    7e60:	f9014ffa 	str	x26, [sp, #664]
    7e64:	f9400676 	ldr	x22, [x19, #8]
    7e68:	910aa333 	add	x19, x25, #0x2a8
    7e6c:	91002273 	add	x19, x19, #0x8
    7e70:	937ffed8 	asr	x24, x22, #63
    7e74:	aa1802c0 	orr	x0, x22, x24
    7e78:	b5000320 	cbnz	x0, 7edc <fwp_write+0xec8>
    7e7c:	110006b5 	add	w21, w21, #0x1
    7e80:	710016bf 	cmp	w21, #0x5
    7e84:	54ffffc1 	b.ne	7e7c <fwp_write+0xe68>  // b.any
    7e88:	b7f80578 	tbnz	x24, #63, 7f34 <fwp_write+0xf20>
    7e8c:	910023f3 	add	x19, sp, #0x8
    7e90:	aa1603e2 	mov	x2, x22
    7e94:	aa1303e0 	mov	x0, x19
    7e98:	d2800003 	mov	x3, #0x0                   	// #0
    7e9c:	97ffec01 	bl	2ea0 <fwp_fmt_u128>
    7ea0:	910123f5 	add	x21, sp, #0x48
    7ea4:	d0000003 	adrp	x3, 9000 <__modti3+0xe0>
    7ea8:	aa1303e4 	mov	x4, x19
    7eac:	aa1503e0 	mov	x0, x21
    7eb0:	91212063 	add	x3, x3, #0x848
    7eb4:	d2804002 	mov	x2, #0x200                 	// #512
    7eb8:	52800041 	mov	w1, #0x2                   	// #2
    7ebc:	97ffea3d 	bl	27b0 <__sprintf_chk@plt>
    7ec0:	aa1503e0 	mov	x0, x21
    7ec4:	97ffea37 	bl	27a0 <strlen@plt>
    7ec8:	aa1503e1 	mov	x1, x21
    7ecc:	aa0003e2 	mov	x2, x0
    7ed0:	aa1403e0 	mov	x0, x20
    7ed4:	97ffedcf 	bl	3610 <buf_put>
    7ed8:	17fffe47 	b	77f4 <fwp_write+0x7e0>
    7edc:	f9400277 	ldr	x23, [x19]
    7ee0:	aa1603e0 	mov	x0, x22
    7ee4:	aa1803e1 	mov	x1, x24
    7ee8:	aa1703e2 	mov	x2, x23
    7eec:	937ffefa 	asr	x26, x23, #63
    7ef0:	aa1a03e3 	mov	x3, x26
    7ef4:	9400040b 	bl	8f20 <__modti3>
    7ef8:	aa010000 	orr	x0, x0, x1
    7efc:	b40002c0 	cbz	x0, 7f54 <fwp_write+0xf40>
    7f00:	110006b5 	add	w21, w21, #0x1
    7f04:	91004273 	add	x19, x19, #0x10
    7f08:	710016bf 	cmp	w21, #0x5
    7f0c:	54fffe81 	b.ne	7edc <fwp_write+0xec8>  // b.any
    7f10:	17ffffde 	b	7e88 <fwp_write+0xe74>
    7f14:	f9400a60 	ldr	x0, [x19, #16]
    7f18:	8b000021 	add	x1, x1, x0
    7f1c:	17fffd75 	b	74f0 <fwp_write+0x4dc>
    7f20:	528c29c0 	mov	w0, #0x614e                	// #24910
    7f24:	910123f5 	add	x21, sp, #0x48
    7f28:	72a009c0 	movk	w0, #0x4e, lsl #16
    7f2c:	b9004be0 	str	w0, [sp, #72]
    7f30:	17fffda2 	b	75b8 <fwp_write+0x5a4>
    7f34:	528005a1 	mov	w1, #0x2d                  	// #45
    7f38:	eb1603e2 	negs	x2, x22
    7f3c:	da1803e3 	ngc	x3, x24
    7f40:	910027e0 	add	x0, sp, #0x9
    7f44:	910023f3 	add	x19, sp, #0x8
    7f48:	390023e1 	strb	w1, [sp, #8]
    7f4c:	97ffebd5 	bl	2ea0 <fwp_fmt_u128>
    7f50:	17ffffd4 	b	7ea0 <fwp_write+0xe8c>
    7f54:	aa1703e2 	mov	x2, x23
    7f58:	aa1a03e3 	mov	x3, x26
    7f5c:	aa1603e0 	mov	x0, x22
    7f60:	aa1803e1 	mov	x1, x24
    7f64:	9400030f 	bl	8ba0 <__divti3>
    7f68:	aa0003e2 	mov	x2, x0
    7f6c:	aa0103e3 	mov	x3, x1
    7f70:	b7f80201 	tbnz	x1, #63, 7fb0 <fwp_write+0xf9c>
    7f74:	910023f3 	add	x19, sp, #0x8
    7f78:	aa1303e0 	mov	x0, x19
    7f7c:	97ffebc9 	bl	2ea0 <fwp_fmt_u128>
    7f80:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7f84:	910aa339 	add	x25, x25, #0x2a8
    7f88:	910123f5 	add	x21, sp, #0x48
    7f8c:	aa1303e4 	mov	x4, x19
    7f90:	aa1503e0 	mov	x0, x21
    7f94:	d0000003 	adrp	x3, 9000 <__modti3+0xe0>
    7f98:	f8616b25 	ldr	x5, [x25, x1]
    7f9c:	91210063 	add	x3, x3, #0x840
    7fa0:	d2804002 	mov	x2, #0x200                 	// #512
    7fa4:	52800041 	mov	w1, #0x2                   	// #2
    7fa8:	97ffea02 	bl	27b0 <__sprintf_chk@plt>
    7fac:	17ffffc5 	b	7ec0 <fwp_write+0xeac>
    7fb0:	528005a4 	mov	w4, #0x2d                  	// #45
    7fb4:	eb0003e2 	negs	x2, x0
    7fb8:	da0103e3 	ngc	x3, x1
    7fbc:	910027e0 	add	x0, sp, #0x9
    7fc0:	910023f3 	add	x19, sp, #0x8
    7fc4:	390023e4 	strb	w4, [sp, #8]
    7fc8:	97ffebb6 	bl	2ea0 <fwp_fmt_u128>
    7fcc:	17ffffed 	b	7f80 <fwp_write+0xf6c>
    7fd0:	f9013bf5 	str	x21, [sp, #624]
    7fd4:	f9013ff6 	str	x22, [sp, #632]
    7fd8:	f90143f7 	str	x23, [sp, #640]
    7fdc:	f90147f8 	str	x24, [sp, #648]
    7fe0:	f9014bf9 	str	x25, [sp, #656]
    7fe4:	f9014ffa 	str	x26, [sp, #664]
    7fe8:	f90153fb 	str	x27, [sp, #672]
    7fec:	f90157fc 	str	x28, [sp, #680]
    7ff0:	fd015be8 	str	d8, [sp, #688]
    7ff4:	fd015fe9 	str	d9, [sp, #696]
    7ff8:	97ffea46 	bl	2910 <__stack_chk_fail@plt>
    7ffc:	d503201f 	nop

0000000000008000 <fwp_main_thread>:
    8000:	d10603ff 	sub	sp, sp, #0x180
    8004:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8008:	f947f400 	ldr	x0, [x0, #4072]
    800c:	a9127bfd 	stp	x29, x30, [sp, #288]
    8010:	910483fd 	add	x29, sp, #0x120
    8014:	a91563f7 	stp	x23, x24, [sp, #336]
    8018:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xc20>
    801c:	911702e1 	add	x1, x23, #0x5c0
    8020:	a91353f3 	stp	x19, x20, [sp, #304]
    8024:	a9145bf5 	stp	x21, x22, [sp, #320]
    8028:	b953a421 	ldr	w1, [x1, #5028]
    802c:	a91773fb 	stp	x27, x28, [sp, #368]
    8030:	f9400002 	ldr	x2, [x0]
    8034:	f9008fe2 	str	x2, [sp, #280]
    8038:	d2800002 	mov	x2, #0x0                   	// #0
    803c:	34004ec1 	cbz	w1, 8a14 <fwp_main_thread+0xa14>
    8040:	911702e0 	add	x0, x23, #0x5c0
    8044:	b953a800 	ldr	w0, [x0, #5032]
    8048:	35004de0 	cbnz	w0, 8a04 <fwp_main_thread+0xa04>
    804c:	900000d5 	adrp	x21, 20000 <__data_start>
    8050:	900000c2 	adrp	x2, 20000 <__data_start>
    8054:	910182b3 	add	x19, x21, #0x60
    8058:	910f8042 	add	x2, x2, #0x3e0
    805c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    8060:	d2a00024 	mov	x4, #0x10000               	// #65536
    8064:	910103e0 	add	x0, sp, #0x40
    8068:	9100a3fb 	add	x27, sp, #0x28
    806c:	d2800001 	mov	x1, #0x0                   	// #0
    8070:	f90003e0 	str	x0, [sp]
    8074:	a9018e7b 	stp	x27, x3, [x19, #24]
    8078:	f90023e2 	str	x2, [sp, #64]
    807c:	b9004bff 	str	wzr, [sp, #72]
    8080:	f9002be4 	str	x4, [sp, #80]
    8084:	97ffe9bb 	bl	2770 <sigaltstack@plt>
    8088:	35005780 	cbnz	w0, 8b78 <fwp_main_thread+0xb78>
    808c:	4f000400 	movi	v0.4s, #0x0
    8090:	910223e0 	add	x0, sp, #0x88
    8094:	f0ffffc1 	adrp	x1, 3000 <fwp_range_release+0x30>
    8098:	9103c021 	add	x1, x1, #0xf0
    809c:	f90043e1 	str	x1, [sp, #128]
    80a0:	52800082 	mov	w2, #0x4                   	// #4
    80a4:	72a10002 	movk	w2, #0x800, lsl #16
    80a8:	910203f4 	add	x20, sp, #0x80
    80ac:	3d802000 	str	q0, [x0, #128]
    80b0:	b9010be2 	str	w2, [sp, #264]
    80b4:	ad000000 	stp	q0, q0, [x0]
    80b8:	ad010000 	stp	q0, q0, [x0, #32]
    80bc:	ad020000 	stp	q0, q0, [x0, #64]
    80c0:	ad030000 	stp	q0, q0, [x0, #96]
    80c4:	97ffea03 	bl	28d0 <sigemptyset@plt>
    80c8:	35005580 	cbnz	w0, 8b78 <fwp_main_thread+0xb78>
    80cc:	aa1403e1 	mov	x1, x20
    80d0:	d2800002 	mov	x2, #0x0                   	// #0
    80d4:	52800160 	mov	w0, #0xb                   	// #11
    80d8:	97ffea16 	bl	2930 <sigaction@plt>
    80dc:	350054e0 	cbnz	w0, 8b78 <fwp_main_thread+0xb78>
    80e0:	aa1403e1 	mov	x1, x20
    80e4:	d2800002 	mov	x2, #0x0                   	// #0
    80e8:	528000e0 	mov	w0, #0x7                   	// #7
    80ec:	97ffea11 	bl	2930 <sigaction@plt>
    80f0:	35005440 	cbnz	w0, 8b78 <fwp_main_thread+0xb78>
    80f4:	b9434660 	ldr	w0, [x19, #836]
    80f8:	340012a0 	cbz	w0, 834c <fwp_main_thread+0x34c>
    80fc:	910182a0 	add	x0, x21, #0x60
    8100:	b9434801 	ldr	w1, [x0, #840]
    8104:	34001361 	cbz	w1, 8370 <fwp_main_thread+0x370>
    8108:	910182b6 	add	x22, x21, #0x60
    810c:	f9400ad4 	ldr	x20, [x22, #16]
    8110:	b4000c74 	cbz	x20, 829c <fwp_main_thread+0x29c>
    8114:	aa1403f3 	mov	x19, x20
    8118:	91010298 	add	x24, x20, #0x40
    811c:	a9166bf9 	stp	x25, x26, [sp, #352]
    8120:	52800037 	mov	w23, #0x1                   	// #1
    8124:	39414a99 	ldrb	w25, [x20, #82]
    8128:	39014a97 	strb	w23, [x20, #82]
    812c:	f9401680 	ldr	x0, [x20, #40]
    8130:	b4000620 	cbz	x0, 81f4 <fwp_main_thread+0x1f4>
    8134:	f9403281 	ldr	x1, [x20, #96]
    8138:	39414680 	ldrb	w0, [x20, #81]
    813c:	b4000ca1 	cbz	x1, 82d0 <fwp_main_thread+0x2d0>
    8140:	36000b60 	tbz	w0, #0, 82ac <fwp_main_thread+0x2ac>
    8144:	39414a62 	ldrb	w2, [x19, #82]
    8148:	f9402280 	ldr	x0, [x20, #64]
    814c:	37000ec2 	tbnz	w2, #0, 8324 <fwp_main_thread+0x324>
    8150:	f9403261 	ldr	x1, [x19, #96]
    8154:	a911fe78 	stp	x24, xzr, [x19, #280]
    8158:	f9009660 	str	x0, [x19, #296]
    815c:	b4000040 	cbz	x0, 8164 <fwp_main_thread+0x164>
    8160:	f9009013 	str	x19, [x0, #288]
    8164:	f9002293 	str	x19, [x20, #64]
    8168:	b4000101 	cbz	x1, 8188 <fwp_main_thread+0x188>
    816c:	f9406ec0 	ldr	x0, [x22, #216]
    8170:	39015677 	strb	w23, [x19, #85]
    8174:	f9003661 	str	x1, [x19, #104]
    8178:	a910827f 	stp	xzr, x0, [x19, #264]
    817c:	b4000040 	cbz	x0, 8184 <fwp_main_thread+0x184>
    8180:	f9008413 	str	x19, [x0, #264]
    8184:	f9006ed3 	str	x19, [x22, #216]
    8188:	39015a7f 	strb	wzr, [x19, #86]
    818c:	97fff916 	bl	65e4 <fwp_block>
    8190:	f9408e62 	ldr	x2, [x19, #280]
    8194:	b4000142 	cbz	x2, 81bc <fwp_main_thread+0x1bc>
    8198:	a9520261 	ldp	x1, x0, [x19, #288]
    819c:	b4000d01 	cbz	x1, 833c <fwp_main_thread+0x33c>
    81a0:	f9009420 	str	x0, [x1, #296]
    81a4:	f9409660 	ldr	x0, [x19, #296]
    81a8:	b4000040 	cbz	x0, 81b0 <fwp_main_thread+0x1b0>
    81ac:	f9009001 	str	x1, [x0, #288]
    81b0:	91080260 	add	x0, x19, #0x200
    81b4:	f900967f 	str	xzr, [x19, #296]
    81b8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    81bc:	39415660 	ldrb	w0, [x19, #85]
    81c0:	f9400ac2 	ldr	x2, [x22, #16]
    81c4:	36000ac0 	tbz	w0, #0, 831c <fwp_main_thread+0x31c>
    81c8:	a9508261 	ldp	x1, x0, [x19, #264]
    81cc:	b4000bc1 	cbz	x1, 8344 <fwp_main_thread+0x344>
    81d0:	f9008820 	str	x0, [x1, #272]
    81d4:	b4000040 	cbz	x0, 81dc <fwp_main_thread+0x1dc>
    81d8:	f9008401 	str	x1, [x0, #264]
    81dc:	91080260 	add	x0, x19, #0x200
    81e0:	3901567f 	strb	wzr, [x19, #85]
    81e4:	aa0203f3 	mov	x19, x2
    81e8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    81ec:	f9401680 	ldr	x0, [x20, #40]
    81f0:	b5fffa20 	cbnz	x0, 8134 <fwp_main_thread+0x134>
    81f4:	910182a0 	add	x0, x21, #0x60
    81f8:	39014a99 	strb	w25, [x20, #82]
    81fc:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8200:	f9419400 	ldr	x0, [x0, #808]
    8204:	b5000080 	cbnz	x0, 8214 <fwp_main_thread+0x214>
    8208:	910182b4 	add	x20, x21, #0x60
    820c:	f9419e80 	ldr	x0, [x20, #824]
    8210:	b4004440 	cbz	x0, 8a98 <fwp_main_thread+0xa98>
    8214:	910182a0 	add	x0, x21, #0x60
    8218:	f941b001 	ldr	x1, [x0, #864]
    821c:	b903581f 	str	wzr, [x0, #856]
    8220:	eb13003f 	cmp	x1, x19
    8224:	54004501 	b.ne	8ac4 <fwp_main_thread+0xac4>  // b.any
    8228:	b40033f3 	cbz	x19, 88a4 <fwp_main_thread+0x8a4>
    822c:	910182a0 	add	x0, x21, #0x60
    8230:	52800021 	mov	w1, #0x1                   	// #1
    8234:	39014a61 	strb	w1, [x19, #82]
    8238:	f9418005 	ldr	x5, [x0, #768]
    823c:	b4003345 	cbz	x5, 88a4 <fwp_main_thread+0x8a4>
    8240:	394140a0 	ldrb	w0, [x5, #80]
    8244:	37000060 	tbnz	w0, #0, 8250 <fwp_main_thread+0x250>
    8248:	aa0503e0 	mov	x0, x5
    824c:	97ffed49 	bl	3770 <fwp_cancel_tree.part.0>
    8250:	f9409ca5 	ldr	x5, [x5, #312]
    8254:	b5ffff65 	cbnz	x5, 8240 <fwp_main_thread+0x240>
    8258:	910182b4 	add	x20, x21, #0x60
    825c:	52800036 	mov	w22, #0x1                   	// #1
    8260:	f9402a60 	ldr	x0, [x19, #80]
    8264:	f2001c1f 	tst	x0, #0xff000000ff
    8268:	540000e1 	b.ne	8284 <fwp_main_thread+0x284>  // b.any
    826c:	f9403e80 	ldr	x0, [x20, #120]
    8270:	39015276 	strb	w22, [x19, #84]
    8274:	f900827f 	str	xzr, [x19, #256]
    8278:	b40030c0 	cbz	x0, 8890 <fwp_main_thread+0x890>
    827c:	f9008013 	str	x19, [x0, #256]
    8280:	f9003e93 	str	x19, [x20, #120]
    8284:	97fff8d8 	bl	65e4 <fwp_block>
    8288:	97fff86a 	bl	6430 <fwp_free_zombie>
    828c:	f9418280 	ldr	x0, [x20, #768]
    8290:	b40030a0 	cbz	x0, 88a4 <fwp_main_thread+0x8a4>
    8294:	f941b293 	ldr	x19, [x20, #864]
    8298:	17fffff2 	b	8260 <fwp_main_thread+0x260>
    829c:	f94196c0 	ldr	x0, [x22, #808]
    82a0:	b5002fc0 	cbnz	x0, 8898 <fwp_main_thread+0x898>
    82a4:	d2800013 	mov	x19, #0x0                   	// #0
    82a8:	17ffffd8 	b	8208 <fwp_main_thread+0x208>
    82ac:	97ffedd5 	bl	3a00 <fwp_now_ns>
    82b0:	f9403281 	ldr	x1, [x20, #96]
    82b4:	eb01001f 	cmp	x0, x1
    82b8:	540000ab 	b.lt	82cc <fwp_main_thread+0x2cc>  // b.tstop
    82bc:	39414280 	ldrb	w0, [x20, #80]
    82c0:	37000060 	tbnz	w0, #0, 82cc <fwp_main_thread+0x2cc>
    82c4:	aa1403e0 	mov	x0, x20
    82c8:	97ffed2a 	bl	3770 <fwp_cancel_tree.part.0>
    82cc:	39414680 	ldrb	w0, [x20, #81]
    82d0:	39414a62 	ldrb	w2, [x19, #82]
    82d4:	3707f3a0 	tbnz	w0, #0, 8148 <fwp_main_thread+0x148>
    82d8:	f9403281 	ldr	x1, [x20, #96]
    82dc:	370001c2 	tbnz	w2, #0, 8314 <fwp_main_thread+0x314>
    82e0:	f9403260 	ldr	x0, [x19, #96]
    82e4:	b4000180 	cbz	x0, 8314 <fwp_main_thread+0x314>
    82e8:	b4000061 	cbz	x1, 82f4 <fwp_main_thread+0x2f4>
    82ec:	eb01001f 	cmp	x0, x1
    82f0:	9a81d000 	csel	x0, x0, x1, le
    82f4:	f9402281 	ldr	x1, [x20, #64]
    82f8:	a911fe78 	stp	x24, xzr, [x19, #280]
    82fc:	f9009661 	str	x1, [x19, #296]
    8300:	b4003c61 	cbz	x1, 8a8c <fwp_main_thread+0xa8c>
    8304:	f9009033 	str	x19, [x1, #288]
    8308:	aa0003e1 	mov	x1, x0
    830c:	f9002293 	str	x19, [x20, #64]
    8310:	17ffff97 	b	816c <fwp_main_thread+0x16c>
    8314:	f9402280 	ldr	x0, [x20, #64]
    8318:	17ffff8f 	b	8154 <fwp_main_thread+0x154>
    831c:	aa0203f3 	mov	x19, x2
    8320:	17ffff83 	b	812c <fwp_main_thread+0x12c>
    8324:	a911fe78 	stp	x24, xzr, [x19, #280]
    8328:	f9009660 	str	x0, [x19, #296]
    832c:	b4000040 	cbz	x0, 8334 <fwp_main_thread+0x334>
    8330:	f9009013 	str	x19, [x0, #288]
    8334:	f9002293 	str	x19, [x20, #64]
    8338:	17ffff94 	b	8188 <fwp_main_thread+0x188>
    833c:	f9000040 	str	x0, [x2]
    8340:	17ffff9a 	b	81a8 <fwp_main_thread+0x1a8>
    8344:	f9006ec0 	str	x0, [x22, #216]
    8348:	17ffffa3 	b	81d4 <fwp_main_thread+0x1d4>
    834c:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    8350:	91078000 	add	x0, x0, #0x1e0
    8354:	940003cf 	bl	9290 <atexit>
    8358:	35004180 	cbnz	w0, 8b88 <fwp_main_thread+0xb88>
    835c:	52800020 	mov	w0, #0x1                   	// #1
    8360:	b9034660 	str	w0, [x19, #836]
    8364:	910182a0 	add	x0, x21, #0x60
    8368:	b9434801 	ldr	w1, [x0, #840]
    836c:	35ffece1 	cbnz	w1, 8108 <fwp_main_thread+0x108>
    8370:	f9418803 	ldr	x3, [x0, #784]
    8374:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    8378:	913f4042 	add	x2, x2, #0xfd0
    837c:	a9028be3 	stp	x3, x2, [sp, #40]
    8380:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    8384:	f94003e2 	ldr	x2, [sp]
    8388:	a9166bf9 	stp	x25, x26, [sp, #352]
    838c:	9125c021 	add	x1, x1, #0x970
    8390:	911702f9 	add	x25, x23, #0x5c0
    8394:	d2800013 	mov	x19, #0x0                   	// #0
    8398:	d290001a 	mov	x26, #0x8000                	// #32768
    839c:	d2800016 	mov	x22, #0x0                   	// #0
    83a0:	f9001fe2 	str	x2, [sp, #56]
    83a4:	f90023ff 	str	xzr, [sp, #64]
    83a8:	a90507ff 	stp	xzr, x1, [sp, #80]
    83ac:	f901881b 	str	x27, [x0, #784]
    83b0:	14000012 	b	83f8 <fwp_main_thread+0x3f8>
    83b4:	7100045f 	cmp	w2, #0x1
    83b8:	540001a1 	b.ne	83ec <fwp_main_thread+0x3ec>  // b.any
    83bc:	29430002 	ldp	w2, w0, [x0, #24]
    83c0:	92403c21 	and	x1, x1, #0xffff
    83c4:	9b027c21 	mul	x1, x1, x2
    83c8:	d360fc21 	lsr	x1, x1, #32
    83cc:	eb00003f 	cmp	x1, x0
    83d0:	540000e2 	b.cs	83ec <fwp_main_thread+0x3ec>  // b.hs, b.nlast
    83d4:	8b01039c 	add	x28, x28, x1
    83d8:	39400380 	ldrb	w0, [x28]
    83dc:	7103fc1f 	cmp	w0, #0xff
    83e0:	54003500 	b.eq	8a80 <fwp_main_thread+0xa80>  // b.none
    83e4:	52800020 	mov	w0, #0x1                   	// #1
    83e8:	39000380 	strb	w0, [x28]
    83ec:	f90023f3 	str	x19, [sp, #64]
    83f0:	aa18037b 	orr	x27, x27, x24
    83f4:	b40003fb 	cbz	x27, 8470 <fwp_main_thread+0x470>
    83f8:	f100075b 	subs	x27, x26, #0x1
    83fc:	aa1403e1 	mov	x1, x20
    8400:	da1f02d8 	sbc	x24, x22, xzr
    8404:	52800020 	mov	w0, #0x1                   	// #1
    8408:	f90027fb 	str	x27, [sp, #72]
    840c:	aa1b03fa 	mov	x26, x27
    8410:	a9084ffb 	stp	x27, x19, [sp, #128]
    8414:	97fff31c 	bl	5084 <fwp_data.part.0.constprop.0>
    8418:	aa0003f3 	mov	x19, x0
    841c:	f949db21 	ldr	x1, [x25, #5040]
    8420:	aa1803f6 	mov	x22, x24
    8424:	f949ef20 	ldr	x0, [x25, #5080]
    8428:	cb010261 	sub	x1, x19, x1
    842c:	eb00403f 	cmp	x1, x0, lsl #16
    8430:	54fffde2 	b.cs	83ec <fwp_main_thread+0x3ec>  // b.hs, b.nlast
    8434:	d350fc20 	lsr	x0, x1, #16
    8438:	f949ff25 	ldr	x5, [x25, #5112]
    843c:	8b000800 	add	x0, x0, x0, lsl #2
    8440:	d37df002 	lsl	x2, x0, #3
    8444:	8b0200a0 	add	x0, x5, x2
    8448:	f940101c 	ldr	x28, [x0, #32]
    844c:	b4fffd1c 	cbz	x28, 83ec <fwp_main_thread+0x3ec>
    8450:	386268a2 	ldrb	w2, [x5, x2]
    8454:	7100085f 	cmp	w2, #0x2
    8458:	54fffae1 	b.ne	83b4 <fwp_main_thread+0x3b4>  // b.any
    845c:	72003c3f 	tst	w1, #0xffff
    8460:	54fffbc0 	b.eq	83d8 <fwp_main_thread+0x3d8>  // b.none
    8464:	f90023f3 	str	x19, [sp, #64]
    8468:	aa18037b 	orr	x27, x27, x24
    846c:	b5fffc7b 	cbnz	x27, 83f8 <fwp_main_thread+0x3f8>
    8470:	d0000000 	adrp	x0, a000 <msg.4+0x50>
    8474:	910182a2 	add	x2, x21, #0x60
    8478:	f94017e3 	ldr	x3, [sp, #40]
    847c:	910183e1 	add	x1, sp, #0x60
    8480:	3dc00000 	ldr	q0, [x0]
    8484:	52800020 	mov	w0, #0x1                   	// #1
    8488:	f9018843 	str	x3, [x2, #784]
    848c:	3d801be0 	str	q0, [sp, #96]
    8490:	97fff2fd 	bl	5084 <fwp_data.part.0.constprop.0>
    8494:	911702e2 	add	x2, x23, #0x5c0
    8498:	aa0003f9 	mov	x25, x0
    849c:	f949d841 	ldr	x1, [x2, #5040]
    84a0:	f949ec40 	ldr	x0, [x2, #5080]
    84a4:	cb010321 	sub	x1, x25, x1
    84a8:	eb00403f 	cmp	x1, x0, lsl #16
    84ac:	54000322 	b.cs	8510 <fwp_main_thread+0x510>  // b.hs, b.nlast
    84b0:	d350fc20 	lsr	x0, x1, #16
    84b4:	f949fc43 	ldr	x3, [x2, #5112]
    84b8:	8b000800 	add	x0, x0, x0, lsl #2
    84bc:	d37df002 	lsl	x2, x0, #3
    84c0:	8b020060 	add	x0, x3, x2
    84c4:	f9401016 	ldr	x22, [x0, #32]
    84c8:	b4000256 	cbz	x22, 8510 <fwp_main_thread+0x510>
    84cc:	38626862 	ldrb	w2, [x3, x2]
    84d0:	7100085f 	cmp	w2, #0x2
    84d4:	54002bc0 	b.eq	8a4c <fwp_main_thread+0xa4c>  // b.none
    84d8:	7100045f 	cmp	w2, #0x1
    84dc:	540001a1 	b.ne	8510 <fwp_main_thread+0x510>  // b.any
    84e0:	29430002 	ldp	w2, w0, [x0, #24]
    84e4:	92403c21 	and	x1, x1, #0xffff
    84e8:	9b027c21 	mul	x1, x1, x2
    84ec:	d360fc21 	lsr	x1, x1, #32
    84f0:	eb00003f 	cmp	x1, x0
    84f4:	540000e2 	b.cs	8510 <fwp_main_thread+0x510>  // b.hs, b.nlast
    84f8:	8b0102d6 	add	x22, x22, x1
    84fc:	394002c0 	ldrb	w0, [x22]
    8500:	7103fc1f 	cmp	w0, #0xff
    8504:	54003280 	b.eq	8b54 <fwp_main_thread+0xb54>  // b.none
    8508:	52800020 	mov	w0, #0x1                   	// #1
    850c:	390002c0 	strb	w0, [x22]
    8510:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8514:	aa1403e1 	mov	x1, x20
    8518:	52800020 	mov	w0, #0x1                   	// #1
    851c:	a90867e2 	stp	x2, x25, [sp, #128]
    8520:	97fff2d9 	bl	5084 <fwp_data.part.0.constprop.0>
    8524:	911702e2 	add	x2, x23, #0x5c0
    8528:	aa0003f6 	mov	x22, x0
    852c:	f949d841 	ldr	x1, [x2, #5040]
    8530:	f949ec40 	ldr	x0, [x2, #5080]
    8534:	cb0102c1 	sub	x1, x22, x1
    8538:	eb00403f 	cmp	x1, x0, lsl #16
    853c:	54000322 	b.cs	85a0 <fwp_main_thread+0x5a0>  // b.hs, b.nlast
    8540:	d350fc20 	lsr	x0, x1, #16
    8544:	f949fc43 	ldr	x3, [x2, #5112]
    8548:	8b000800 	add	x0, x0, x0, lsl #2
    854c:	d37df002 	lsl	x2, x0, #3
    8550:	8b020060 	add	x0, x3, x2
    8554:	f9401014 	ldr	x20, [x0, #32]
    8558:	b4000254 	cbz	x20, 85a0 <fwp_main_thread+0x5a0>
    855c:	38626862 	ldrb	w2, [x3, x2]
    8560:	7100085f 	cmp	w2, #0x2
    8564:	54002800 	b.eq	8a64 <fwp_main_thread+0xa64>  // b.none
    8568:	7100045f 	cmp	w2, #0x1
    856c:	540001a1 	b.ne	85a0 <fwp_main_thread+0x5a0>  // b.any
    8570:	29430002 	ldp	w2, w0, [x0, #24]
    8574:	92403c21 	and	x1, x1, #0xffff
    8578:	9b027c21 	mul	x1, x1, x2
    857c:	d360fc21 	lsr	x1, x1, #32
    8580:	eb00003f 	cmp	x1, x0
    8584:	540000e2 	b.cs	85a0 <fwp_main_thread+0x5a0>  // b.hs, b.nlast
    8588:	8b010294 	add	x20, x20, x1
    858c:	39400280 	ldrb	w0, [x20]
    8590:	7103fc1f 	cmp	w0, #0xff
    8594:	54002d40 	b.eq	8b3c <fwp_main_thread+0xb3c>  // b.none
    8598:	52800020 	mov	w0, #0x1                   	// #1
    859c:	39000280 	strb	w0, [x20]
    85a0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    85a4:	9101c3e1 	add	x1, sp, #0x70
    85a8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    85ac:	52800020 	mov	w0, #0x1                   	// #1
    85b0:	a9075be2 	stp	x2, x22, [sp, #112]
    85b4:	97fff2b4 	bl	5084 <fwp_data.part.0.constprop.0>
    85b8:	911702e2 	add	x2, x23, #0x5c0
    85bc:	aa0003f4 	mov	x20, x0
    85c0:	f949d841 	ldr	x1, [x2, #5040]
    85c4:	f949ec40 	ldr	x0, [x2, #5080]
    85c8:	cb010281 	sub	x1, x20, x1
    85cc:	eb00403f 	cmp	x1, x0, lsl #16
    85d0:	54000322 	b.cs	8634 <fwp_main_thread+0x634>  // b.hs, b.nlast
    85d4:	d350fc20 	lsr	x0, x1, #16
    85d8:	f949fc43 	ldr	x3, [x2, #5112]
    85dc:	8b000800 	add	x0, x0, x0, lsl #2
    85e0:	d37df002 	lsl	x2, x0, #3
    85e4:	8b020060 	add	x0, x3, x2
    85e8:	f9401016 	ldr	x22, [x0, #32]
    85ec:	b4000256 	cbz	x22, 8634 <fwp_main_thread+0x634>
    85f0:	38626862 	ldrb	w2, [x3, x2]
    85f4:	7100085f 	cmp	w2, #0x2
    85f8:	54002300 	b.eq	8a58 <fwp_main_thread+0xa58>  // b.none
    85fc:	7100045f 	cmp	w2, #0x1
    8600:	540001a1 	b.ne	8634 <fwp_main_thread+0x634>  // b.any
    8604:	29430002 	ldp	w2, w0, [x0, #24]
    8608:	92403c21 	and	x1, x1, #0xffff
    860c:	9b027c21 	mul	x1, x1, x2
    8610:	d360fc21 	lsr	x1, x1, #32
    8614:	eb00003f 	cmp	x1, x0
    8618:	540000e2 	b.cs	8634 <fwp_main_thread+0x634>  // b.hs, b.nlast
    861c:	8b0102d6 	add	x22, x22, x1
    8620:	394002c0 	ldrb	w0, [x22]
    8624:	7103fc1f 	cmp	w0, #0xff
    8628:	54002900 	b.eq	8b48 <fwp_main_thread+0xb48>  // b.none
    862c:	52800020 	mov	w0, #0x1                   	// #1
    8630:	390002c0 	strb	w0, [x22]
    8634:	aa1303f6 	mov	x22, x19
    8638:	d00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x12d80>
    863c:	b4001173 	cbz	x19, 8868 <fwp_main_thread+0x868>
    8640:	910aa000 	add	x0, x0, #0x2a8
    8644:	911702fb 	add	x27, x23, #0x5c0
    8648:	91014000 	add	x0, x0, #0x50
    864c:	b000001a 	adrp	x26, 9000 <__modti3+0xe0>
    8650:	52800038 	mov	w24, #0x1                   	// #1
    8654:	f90007e0 	str	x0, [sp, #8]
    8658:	91356340 	add	x0, x26, #0xd58
    865c:	f9000be0 	str	x0, [sp, #16]
    8660:	f949db61 	ldr	x1, [x27, #5040]
    8664:	f949ef60 	ldr	x0, [x27, #5080]
    8668:	cb010281 	sub	x1, x20, x1
    866c:	eb00403f 	cmp	x1, x0, lsl #16
    8670:	54000342 	b.cs	86d8 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    8674:	d350fc20 	lsr	x0, x1, #16
    8678:	f949ff65 	ldr	x5, [x27, #5112]
    867c:	8b000800 	add	x0, x0, x0, lsl #2
    8680:	d37df002 	lsl	x2, x0, #3
    8684:	8b0200a3 	add	x3, x5, x2
    8688:	f9401060 	ldr	x0, [x3, #32]
    868c:	b4000260 	cbz	x0, 86d8 <fwp_main_thread+0x6d8>
    8690:	386268a2 	ldrb	w2, [x5, x2]
    8694:	7100085f 	cmp	w2, #0x2
    8698:	54001c80 	b.eq	8a28 <fwp_main_thread+0xa28>  // b.none
    869c:	7100045f 	cmp	w2, #0x1
    86a0:	540001c1 	b.ne	86d8 <fwp_main_thread+0x6d8>  // b.any
    86a4:	29430865 	ldp	w5, w2, [x3, #24]
    86a8:	92403c21 	and	x1, x1, #0xffff
    86ac:	9b057c21 	mul	x1, x1, x5
    86b0:	d360fc21 	lsr	x1, x1, #32
    86b4:	eb02003f 	cmp	x1, x2
    86b8:	54000102 	b.cs	86d8 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    86bc:	8b010000 	add	x0, x0, x1
    86c0:	39400001 	ldrb	w1, [x0]
    86c4:	340000a1 	cbz	w1, 86d8 <fwp_main_thread+0x6d8>
    86c8:	7103f43f 	cmp	w1, #0xfd
    86cc:	54002008 	b.hi	8acc <fwp_main_thread+0xacc>  // b.pmore
    86d0:	11000421 	add	w1, w1, #0x1
    86d4:	39000001 	strb	w1, [x0]
    86d8:	a9400be0 	ldp	x0, x2, [sp]
    86dc:	aa1403e1 	mov	x1, x20
    86e0:	52800023 	mov	w3, #0x1                   	// #1
    86e4:	a9047fff 	stp	xzr, xzr, [sp, #64]
    86e8:	f9002bff 	str	xzr, [sp, #80]
    86ec:	97fffa4a 	bl	7014 <fwp_write>
    86f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    86f4:	f9400be0 	ldr	x0, [sp, #16]
    86f8:	f100033f 	cmp	x25, #0x0
    86fc:	9a990019 	csel	x25, x0, x25, eq	// eq = none
    8700:	b1002b5f 	cmn	x26, #0xa
    8704:	540022e8 	b.hi	8b60 <fwp_main_thread+0xb60>  // b.pmore
    8708:	52800021 	mov	w1, #0x1                   	// #1
    870c:	91002740 	add	x0, x26, #0x9
    8710:	97fff218 	bl	4f70 <fwp_heap_alloc>
    8714:	aa0003fc 	mov	x28, x0
    8718:	aa1903e1 	mov	x1, x25
    871c:	aa0003f9 	mov	x25, x0
    8720:	aa1a03e2 	mov	x2, x26
    8724:	f800873a 	str	x26, [x25], #8
    8728:	aa1903e0 	mov	x0, x25
    872c:	97ffe80d 	bl	2760 <memcpy@plt>
    8730:	8b1a0382 	add	x2, x28, x26
    8734:	3900205f 	strb	wzr, [x2, #8]
    8738:	f94023e0 	ldr	x0, [sp, #64]
    873c:	97ffe8a5 	bl	29d0 <free@plt>
    8740:	f949db62 	ldr	x2, [x27, #5040]
    8744:	f949ef60 	ldr	x0, [x27, #5080]
    8748:	cb020382 	sub	x2, x28, x2
    874c:	eb00405f 	cmp	x2, x0, lsl #16
    8750:	54000302 	b.cs	87b0 <fwp_main_thread+0x7b0>  // b.hs, b.nlast
    8754:	d350fc40 	lsr	x0, x2, #16
    8758:	f949ff66 	ldr	x6, [x27, #5112]
    875c:	8b000800 	add	x0, x0, x0, lsl #2
    8760:	d37df001 	lsl	x1, x0, #3
    8764:	8b0100c5 	add	x5, x6, x1
    8768:	f94010a0 	ldr	x0, [x5, #32]
    876c:	b4000220 	cbz	x0, 87b0 <fwp_main_thread+0x7b0>
    8770:	386168c1 	ldrb	w1, [x6, x1]
    8774:	7100083f 	cmp	w1, #0x2
    8778:	540015e0 	b.eq	8a34 <fwp_main_thread+0xa34>  // b.none
    877c:	7100043f 	cmp	w1, #0x1
    8780:	54000181 	b.ne	87b0 <fwp_main_thread+0x7b0>  // b.any
    8784:	92403c41 	and	x1, x2, #0xffff
    8788:	294308a6 	ldp	w6, w2, [x5, #24]
    878c:	9b067c21 	mul	x1, x1, x6
    8790:	d360fc21 	lsr	x1, x1, #32
    8794:	eb02003f 	cmp	x1, x2
    8798:	540000c2 	b.cs	87b0 <fwp_main_thread+0x7b0>  // b.hs, b.nlast
    879c:	8b010000 	add	x0, x0, x1
    87a0:	39400001 	ldrb	w1, [x0]
    87a4:	7103fc3f 	cmp	w1, #0xff
    87a8:	54001640 	b.eq	8a70 <fwp_main_thread+0xa70>  // b.none
    87ac:	39000018 	strb	w24, [x0]
    87b0:	aa1403e0 	mov	x0, x20
    87b4:	97fff4c3 	bl	5ac0 <fwp_drop0>
    87b8:	910182a5 	add	x5, x21, #0x60
    87bc:	aa1903e0 	mov	x0, x25
    87c0:	f9400382 	ldr	x2, [x28]
    87c4:	aa0503f9 	mov	x25, x5
    87c8:	f94004a3 	ldr	x3, [x5, #8]
    87cc:	d2800021 	mov	x1, #0x1                   	// #1
    87d0:	97ffe890 	bl	2a10 <fwrite@plt>
    87d4:	f9400721 	ldr	x1, [x25, #8]
    87d8:	52800140 	mov	w0, #0xa                   	// #10
    87dc:	97ffe815 	bl	2830 <fputc@plt>
    87e0:	f949db62 	ldr	x2, [x27, #5040]
    87e4:	f949ef60 	ldr	x0, [x27, #5080]
    87e8:	cb020382 	sub	x2, x28, x2
    87ec:	eb00405f 	cmp	x2, x0, lsl #16
    87f0:	54000382 	b.cs	8860 <fwp_main_thread+0x860>  // b.hs, b.nlast
    87f4:	d350fc40 	lsr	x0, x2, #16
    87f8:	f949ff65 	ldr	x5, [x27, #5112]
    87fc:	8b000800 	add	x0, x0, x0, lsl #2
    8800:	d37df001 	lsl	x1, x0, #3
    8804:	8b0100a3 	add	x3, x5, x1
    8808:	f9401060 	ldr	x0, [x3, #32]
    880c:	b40002a0 	cbz	x0, 8860 <fwp_main_thread+0x860>
    8810:	386168a1 	ldrb	w1, [x5, x1]
    8814:	7100083f 	cmp	w1, #0x2
    8818:	54001140 	b.eq	8a40 <fwp_main_thread+0xa40>  // b.none
    881c:	7100043f 	cmp	w1, #0x1
    8820:	54000201 	b.ne	8860 <fwp_main_thread+0x860>  // b.any
    8824:	92403c41 	and	x1, x2, #0xffff
    8828:	29430865 	ldp	w5, w2, [x3, #24]
    882c:	9b057c21 	mul	x1, x1, x5
    8830:	d360fc21 	lsr	x1, x1, #32
    8834:	eb02003f 	cmp	x1, x2
    8838:	54000142 	b.cs	8860 <fwp_main_thread+0x860>  // b.hs, b.nlast
    883c:	8b010000 	add	x0, x0, x1
    8840:	39400001 	ldrb	w1, [x0]
    8844:	340000e1 	cbz	w1, 8860 <fwp_main_thread+0x860>
    8848:	7100043f 	cmp	w1, #0x1
    884c:	54000e80 	b.eq	8a1c <fwp_main_thread+0xa1c>  // b.none
    8850:	7103fc3f 	cmp	w1, #0xff
    8854:	54001400 	b.eq	8ad4 <fwp_main_thread+0xad4>  // b.none
    8858:	51000421 	sub	w1, w1, #0x1
    885c:	39000001 	strb	w1, [x0]
    8860:	f9400ad6 	ldr	x22, [x22, #16]
    8864:	b5ffeff6 	cbnz	x22, 8660 <fwp_main_thread+0x660>
    8868:	aa1403e0 	mov	x0, x20
    886c:	97fff495 	bl	5ac0 <fwp_drop0>
    8870:	aa1303e0 	mov	x0, x19
    8874:	97fff493 	bl	5ac0 <fwp_drop0>
    8878:	910182a0 	add	x0, x21, #0x60
    887c:	52800021 	mov	w1, #0x1                   	// #1
    8880:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8884:	b9034801 	str	w1, [x0, #840]
    8888:	f901a81f 	str	xzr, [x0, #848]
    888c:	17fffe1f 	b	8108 <fwp_main_thread+0x108>
    8890:	f9004293 	str	x19, [x20, #128]
    8894:	17fffe7b 	b	8280 <fwp_main_thread+0x280>
    8898:	f941b2c0 	ldr	x0, [x22, #864]
    889c:	b9035adf 	str	wzr, [x22, #856]
    88a0:	b5001120 	cbnz	x0, 8ac4 <fwp_main_thread+0xac4>
    88a4:	910182b4 	add	x20, x21, #0x60
    88a8:	97fff6e2 	bl	6430 <fwp_free_zombie>
    88ac:	f9404280 	ldr	x0, [x20, #128]
    88b0:	b50010a0 	cbnz	x0, 8ac4 <fwp_main_thread+0xac4>
    88b4:	f9406e80 	ldr	x0, [x20, #216]
    88b8:	b5001060 	cbnz	x0, 8ac4 <fwp_main_thread+0xac4>
    88bc:	b940fa80 	ldr	w0, [x20, #248]
    88c0:	340001e0 	cbz	w0, 88fc <fwp_main_thread+0x8fc>
    88c4:	93407c16 	sxtw	x22, w0
    88c8:	51000400 	sub	w0, w0, #0x1
    88cc:	d1000ad6 	sub	x22, x22, #0x2
    88d0:	91040297 	add	x23, x20, #0x100
    88d4:	cb2042d6 	sub	x22, x22, w0, uxtw
    88d8:	93407c13 	sxtw	x19, w0
    88dc:	d503201f 	nop
    88e0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    88e4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    88e8:	b900fa93 	str	w19, [x20, #248]
    88ec:	d1000673 	sub	x19, x19, #0x1
    88f0:	97ffe850 	bl	2a30 <munmap@plt>
    88f4:	eb1302df 	cmp	x22, x19
    88f8:	54ffff41 	b.ne	88e0 <fwp_main_thread+0x8e0>  // b.any
    88fc:	900000d3 	adrp	x19, 20000 <__data_start>
    8900:	91004260 	add	x0, x19, #0x10
    8904:	b9403800 	ldr	w0, [x0, #56]
    8908:	37f80040 	tbnz	w0, #31, 8910 <fwp_main_thread+0x910>
    890c:	97ffe805 	bl	2920 <close@plt>
    8910:	910182a0 	add	x0, x21, #0x60
    8914:	91004261 	add	x1, x19, #0x10
    8918:	12800002 	mov	w2, #0xffffffff            	// #-1
    891c:	d2800013 	mov	x19, #0x0                   	// #0
    8920:	f941b416 	ldr	x22, [x0, #872]
    8924:	b9003822 	str	w2, [x1, #56]
    8928:	f941b814 	ldr	x20, [x0, #880]
    892c:	b4000176 	cbz	x22, 8958 <fwp_main_thread+0x958>
    8930:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    8934:	b40000c0 	cbz	x0, 894c <fwp_main_thread+0x94c>
    8938:	f9400001 	ldr	x1, [x0]
    893c:	b5000c41 	cbnz	x1, 8ac4 <fwp_main_thread+0xac4>
    8940:	f9400401 	ldr	x1, [x0, #8]
    8944:	b5000c01 	cbnz	x1, 8ac4 <fwp_main_thread+0xac4>
    8948:	97fff06a 	bl	4af0 <fwp_mem_free>
    894c:	91000673 	add	x19, x19, #0x1
    8950:	eb16027f 	cmp	x19, x22
    8954:	54fffee1 	b.ne	8930 <fwp_main_thread+0x930>  // b.any
    8958:	aa1403e0 	mov	x0, x20
    895c:	97fff065 	bl	4af0 <fwp_mem_free>
    8960:	910182a0 	add	x0, x21, #0x60
    8964:	f941b013 	ldr	x19, [x0, #864]
    8968:	f901b41f 	str	xzr, [x0, #872]
    896c:	f901b81f 	str	xzr, [x0, #880]
    8970:	b40001f3 	cbz	x19, 89ac <fwp_main_thread+0x9ac>
    8974:	f9401661 	ldr	x1, [x19, #40]
    8978:	b5000a61 	cbnz	x1, 8ac4 <fwp_main_thread+0xac4>
    897c:	f9405661 	ldr	x1, [x19, #168]
    8980:	b5000a21 	cbnz	x1, 8ac4 <fwp_main_thread+0xac4>
    8984:	f9419401 	ldr	x1, [x0, #808]
    8988:	b50009e1 	cbnz	x1, 8ac4 <fwp_main_thread+0xac4>
    898c:	f9419c00 	ldr	x0, [x0, #824]
    8990:	b50009a0 	cbnz	x0, 8ac4 <fwp_main_thread+0xac4>
    8994:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8998:	90000140 	adrp	x0, 30000 <alt.5+0xfc20>
    899c:	910f8000 	add	x0, x0, #0x3e0
    89a0:	97ffe7d0 	bl	28e0 <memset@plt>
    89a4:	aa1303e0 	mov	x0, x19
    89a8:	97fff052 	bl	4af0 <fwp_mem_free>
    89ac:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    89b0:	f947ec00 	ldr	x0, [x0, #4056]
    89b4:	910182b5 	add	x21, x21, #0x60
    89b8:	f9400000 	ldr	x0, [x0]
    89bc:	f9000abf 	str	xzr, [x21, #16]
    89c0:	f901b2bf 	str	xzr, [x21, #864]
    89c4:	97ffe81f 	bl	2a40 <fflush@plt>
    89c8:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    89cc:	f947f400 	ldr	x0, [x0, #4072]
    89d0:	f9408fe2 	ldr	x2, [sp, #280]
    89d4:	f9400001 	ldr	x1, [x0]
    89d8:	eb010042 	subs	x2, x2, x1
    89dc:	d2800001 	mov	x1, #0x0                   	// #0
    89e0:	54000d81 	b.ne	8b90 <fwp_main_thread+0xb90>  // b.any
    89e4:	a9527bfd 	ldp	x29, x30, [sp, #288]
    89e8:	d2800000 	mov	x0, #0x0                   	// #0
    89ec:	a95353f3 	ldp	x19, x20, [sp, #304]
    89f0:	a9545bf5 	ldp	x21, x22, [sp, #320]
    89f4:	a95563f7 	ldp	x23, x24, [sp, #336]
    89f8:	a95773fb 	ldp	x27, x28, [sp, #368]
    89fc:	910603ff 	add	sp, sp, #0x180
    8a00:	d65f03c0 	ret
    8a04:	90ffffe0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    8a08:	91008000 	add	x0, x0, #0x20
    8a0c:	94000221 	bl	9290 <atexit>
    8a10:	17fffd8f 	b	804c <fwp_main_thread+0x4c>
    8a14:	97ffeddc 	bl	4184 <fwp_heap_init>
    8a18:	17fffd8a 	b	8040 <fwp_main_thread+0x40>
    8a1c:	aa1c03e0 	mov	x0, x28
    8a20:	97fff2fd 	bl	5614 <fwp_rc_free_arr>
    8a24:	17ffff8f 	b	8860 <fwp_main_thread+0x860>
    8a28:	72003c3f 	tst	w1, #0xffff
    8a2c:	54ffe561 	b.ne	86d8 <fwp_main_thread+0x6d8>  // b.any
    8a30:	17ffff24 	b	86c0 <fwp_main_thread+0x6c0>
    8a34:	72003c5f 	tst	w2, #0xffff
    8a38:	54ffebc1 	b.ne	87b0 <fwp_main_thread+0x7b0>  // b.any
    8a3c:	17ffff59 	b	87a0 <fwp_main_thread+0x7a0>
    8a40:	72003c5f 	tst	w2, #0xffff
    8a44:	54fff0e1 	b.ne	8860 <fwp_main_thread+0x860>  // b.any
    8a48:	17ffff7e 	b	8840 <fwp_main_thread+0x840>
    8a4c:	72003c3f 	tst	w1, #0xffff
    8a50:	54ffd601 	b.ne	8510 <fwp_main_thread+0x510>  // b.any
    8a54:	17fffeaa 	b	84fc <fwp_main_thread+0x4fc>
    8a58:	72003c3f 	tst	w1, #0xffff
    8a5c:	54ffdec1 	b.ne	8634 <fwp_main_thread+0x634>  // b.any
    8a60:	17fffef0 	b	8620 <fwp_main_thread+0x620>
    8a64:	72003c3f 	tst	w1, #0xffff
    8a68:	54ffd9c1 	b.ne	85a0 <fwp_main_thread+0x5a0>  // b.any
    8a6c:	17fffec8 	b	858c <fwp_main_thread+0x58c>
    8a70:	f9000fe0 	str	x0, [sp, #24]
    8a74:	97ffef7f 	bl	4870 <fwp_rc_forget_slot>
    8a78:	f9400fe0 	ldr	x0, [sp, #24]
    8a7c:	17ffff4c 	b	87ac <fwp_main_thread+0x7ac>
    8a80:	aa1c03e0 	mov	x0, x28
    8a84:	97ffef7b 	bl	4870 <fwp_rc_forget_slot>
    8a88:	17fffe57 	b	83e4 <fwp_main_thread+0x3e4>
    8a8c:	aa0003e1 	mov	x1, x0
    8a90:	f9002293 	str	x19, [x20, #64]
    8a94:	17fffdb6 	b	816c <fwp_main_thread+0x16c>
    8a98:	f9419280 	ldr	x0, [x20, #800]
    8a9c:	97fff015 	bl	4af0 <fwp_mem_free>
    8aa0:	f901929f 	str	xzr, [x20, #800]
    8aa4:	f9019a9f 	str	xzr, [x20, #816]
    8aa8:	f941b280 	ldr	x0, [x20, #864]
    8aac:	b4000433 	cbz	x19, 8b30 <fwp_main_thread+0xb30>
    8ab0:	f900567f 	str	xzr, [x19, #168]
    8ab4:	f9005e7f 	str	xzr, [x19, #184]
    8ab8:	b9035a9f 	str	wzr, [x20, #856]
    8abc:	eb13001f 	cmp	x0, x19
    8ac0:	54ffbb60 	b.eq	822c <fwp_main_thread+0x22c>  // b.none
    8ac4:	a9166bf9 	stp	x25, x26, [sp, #352]
    8ac8:	97ffe7a6 	bl	2960 <abort@plt>
    8acc:	97ffef22 	bl	4754 <fwp_rc_wide_dup>
    8ad0:	17ffff02 	b	86d8 <fwp_main_thread+0x6d8>
    8ad4:	ca404401 	eor	x1, x0, x0, lsr #17
    8ad8:	911702e2 	add	x2, x23, #0x5c0
    8adc:	ca412421 	eor	x1, x1, x1, lsr #9
    8ae0:	8b210c41 	add	x1, x2, w1, uxtb #3
    8ae4:	f94a2421 	ldr	x1, [x1, #5192]
    8ae8:	b5000081 	cbnz	x1, 8af8 <fwp_main_thread+0xaf8>
    8aec:	14000020 	b	8b6c <fwp_main_thread+0xb6c>
    8af0:	f9400821 	ldr	x1, [x1, #16]
    8af4:	b40003c1 	cbz	x1, 8b6c <fwp_main_thread+0xb6c>
    8af8:	f9400022 	ldr	x2, [x1]
    8afc:	eb02001f 	cmp	x0, x2
    8b00:	54ffff81 	b.ne	8af0 <fwp_main_thread+0xaf0>  // b.any
    8b04:	f9400422 	ldr	x2, [x1, #8]
    8b08:	d1000442 	sub	x2, x2, #0x1
    8b0c:	f9000422 	str	x2, [x1, #8]
    8b10:	f103f85f 	cmp	x2, #0xfe
    8b14:	54ffea61 	b.ne	8860 <fwp_main_thread+0x860>  // b.any
    8b18:	f9000fe0 	str	x0, [sp, #24]
    8b1c:	97ffef55 	bl	4870 <fwp_rc_forget_slot>
    8b20:	f9400fe0 	ldr	x0, [sp, #24]
    8b24:	12800021 	mov	w1, #0xfffffffe            	// #-2
    8b28:	39000001 	strb	w1, [x0]
    8b2c:	17ffff4d 	b	8860 <fwp_main_thread+0x860>
    8b30:	b9035a9f 	str	wzr, [x20, #856]
    8b34:	b4ffeb80 	cbz	x0, 88a4 <fwp_main_thread+0x8a4>
    8b38:	17ffffe3 	b	8ac4 <fwp_main_thread+0xac4>
    8b3c:	aa1403e0 	mov	x0, x20
    8b40:	97ffef4c 	bl	4870 <fwp_rc_forget_slot>
    8b44:	17fffe95 	b	8598 <fwp_main_thread+0x598>
    8b48:	aa1603e0 	mov	x0, x22
    8b4c:	97ffef49 	bl	4870 <fwp_rc_forget_slot>
    8b50:	17fffeb7 	b	862c <fwp_main_thread+0x62c>
    8b54:	aa1603e0 	mov	x0, x22
    8b58:	97ffef46 	bl	4870 <fwp_rc_forget_slot>
    8b5c:	17fffe6b 	b	8508 <fwp_main_thread+0x508>
    8b60:	b0000000 	adrp	x0, 9000 <__modti3+0xe0>
    8b64:	91222000 	add	x0, x0, #0x888
    8b68:	97ffeb46 	bl	3880 <fwp_trap>
    8b6c:	b0000000 	adrp	x0, 9000 <__modti3+0xe0>
    8b70:	91188000 	add	x0, x0, #0x620
    8b74:	97ffeb43 	bl	3880 <fwp_trap>
    8b78:	b0000000 	adrp	x0, 9000 <__modti3+0xe0>
    8b7c:	91218000 	add	x0, x0, #0x860
    8b80:	a9166bf9 	stp	x25, x26, [sp, #352]
    8b84:	97ffeb3f 	bl	3880 <fwp_trap>
    8b88:	a9166bf9 	stp	x25, x26, [sp, #352]
    8b8c:	97ffe989 	bl	31b0 <descent_phase_fail>
    8b90:	a9166bf9 	stp	x25, x26, [sp, #352]
    8b94:	97ffe75f 	bl	2910 <__stack_chk_fail@plt>
    8b98:	d503201f 	nop
    8b9c:	d503201f 	nop

0000000000008ba0 <__divti3>:
    8ba0:	d503245f 	bti	c
    8ba4:	d2800004 	mov	x4, #0x0                   	// #0
    8ba8:	b7f80721 	tbnz	x1, #63, 8c8c <__divti3+0xec>
    8bac:	b6f80083 	tbz	x3, #63, 8bbc <__divti3+0x1c>
    8bb0:	eb0203e2 	negs	x2, x2
    8bb4:	aa2403e4 	mvn	x4, x4
    8bb8:	da0303e3 	ngc	x3, x3
    8bbc:	aa0203e6 	mov	x6, x2
    8bc0:	aa0003e7 	mov	x7, x0
    8bc4:	aa0103e5 	mov	x5, x1
    8bc8:	b5000583 	cbnz	x3, 8c78 <__divti3+0xd8>
    8bcc:	eb01005f 	cmp	x2, x1
    8bd0:	54000e69 	b.ls	8d9c <__divti3+0x1fc>  // b.plast
    8bd4:	dac01040 	clz	x0, x2
    8bd8:	b40000e0 	cbz	x0, 8bf4 <__divti3+0x54>
    8bdc:	4b0003e1 	neg	w1, w0
    8be0:	9ac020a5 	lsl	x5, x5, x0
    8be4:	9ac02046 	lsl	x6, x2, x0
    8be8:	9ac124e1 	lsr	x1, x7, x1
    8bec:	aa050025 	orr	x5, x1, x5
    8bf0:	9ac020e7 	lsl	x7, x7, x0
    8bf4:	d360fcc8 	lsr	x8, x6, #32
    8bf8:	92407cc2 	and	x2, x6, #0xffffffff
    8bfc:	9ac808a3 	udiv	x3, x5, x8
    8c00:	9b089465 	msub	x5, x3, x8, x5
    8c04:	aa0303e0 	mov	x0, x3
    8c08:	9b037c41 	mul	x1, x2, x3
    8c0c:	93c780a5 	extr	x5, x5, x7, #32
    8c10:	eb05003f 	cmp	x1, x5
    8c14:	540000a9 	b.ls	8c28 <__divti3+0x88>  // b.plast
    8c18:	ab0500c5 	adds	x5, x6, x5
    8c1c:	d1000460 	sub	x0, x3, #0x1
    8c20:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8c24:	540015a8 	b.hi	8ed8 <__divti3+0x338>  // b.pmore
    8c28:	cb0100a5 	sub	x5, x5, x1
    8c2c:	9ac808a3 	udiv	x3, x5, x8
    8c30:	9b089465 	msub	x5, x3, x8, x5
    8c34:	aa0303e1 	mov	x1, x3
    8c38:	9b037c42 	mul	x2, x2, x3
    8c3c:	aa0703e3 	mov	x3, x7
    8c40:	b3607ca3 	bfi	x3, x5, #32, #32
    8c44:	eb03005f 	cmp	x2, x3
    8c48:	540000c9 	b.ls	8c60 <__divti3+0xc0>  // b.plast
    8c4c:	ab0300c3 	adds	x3, x6, x3
    8c50:	d1000425 	sub	x5, x1, #0x1
    8c54:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8c58:	d1000821 	sub	x1, x1, #0x2
    8c5c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8c60:	aa008020 	orr	x0, x1, x0, lsl #32
    8c64:	d2800001 	mov	x1, #0x0                   	// #0
    8c68:	b4000064 	cbz	x4, 8c74 <__divti3+0xd4>
    8c6c:	eb0003e0 	negs	x0, x0
    8c70:	da0103e1 	ngc	x1, x1
    8c74:	d65f03c0 	ret
    8c78:	eb01007f 	cmp	x3, x1
    8c7c:	54000109 	b.ls	8c9c <__divti3+0xfc>  // b.plast
    8c80:	d2800001 	mov	x1, #0x0                   	// #0
    8c84:	d2800000 	mov	x0, #0x0                   	// #0
    8c88:	17fffff8 	b	8c68 <__divti3+0xc8>
    8c8c:	eb0003e0 	negs	x0, x0
    8c90:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8c94:	da0103e1 	ngc	x1, x1
    8c98:	17ffffc5 	b	8bac <__divti3+0xc>
    8c9c:	dac01067 	clz	x7, x3
    8ca0:	b40010e7 	cbz	x7, 8ebc <__divti3+0x31c>
    8ca4:	d2800805 	mov	x5, #0x40                  	// #64
    8ca8:	cb0700a5 	sub	x5, x5, x7
    8cac:	9ac72063 	lsl	x3, x3, x7
    8cb0:	9ac52448 	lsr	x8, x2, x5
    8cb4:	aa030108 	orr	x8, x8, x3
    8cb8:	9ac52426 	lsr	x6, x1, x5
    8cbc:	92407d0a 	and	x10, x8, #0xffffffff
    8cc0:	d360fd09 	lsr	x9, x8, #32
    8cc4:	9ac52403 	lsr	x3, x0, x5
    8cc8:	9ac72021 	lsl	x1, x1, x7
    8ccc:	aa010063 	orr	x3, x3, x1
    8cd0:	9ac72042 	lsl	x2, x2, x7
    8cd4:	9ac908cb 	udiv	x11, x6, x9
    8cd8:	9b099965 	msub	x5, x11, x9, x6
    8cdc:	aa0b03e1 	mov	x1, x11
    8ce0:	9b0b7d46 	mul	x6, x10, x11
    8ce4:	93c380a5 	extr	x5, x5, x3, #32
    8ce8:	eb0500df 	cmp	x6, x5
    8cec:	540000a9 	b.ls	8d00 <__divti3+0x160>  // b.plast
    8cf0:	ab050105 	adds	x5, x8, x5
    8cf4:	d1000561 	sub	x1, x11, #0x1
    8cf8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    8cfc:	54000f48 	b.hi	8ee4 <__divti3+0x344>  // b.pmore
    8d00:	cb0600a6 	sub	x6, x5, x6
    8d04:	9ac908cb 	udiv	x11, x6, x9
    8d08:	9b099969 	msub	x9, x11, x9, x6
    8d0c:	aa0b03e5 	mov	x5, x11
    8d10:	9b0b7d4a 	mul	x10, x10, x11
    8d14:	b3607d23 	bfi	x3, x9, #32, #32
    8d18:	eb03015f 	cmp	x10, x3
    8d1c:	540000a9 	b.ls	8d30 <__divti3+0x190>  // b.plast
    8d20:	ab030103 	adds	x3, x8, x3
    8d24:	d1000565 	sub	x5, x11, #0x1
    8d28:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    8d2c:	54000e28 	b.hi	8ef0 <__divti3+0x350>  // b.pmore
    8d30:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8d34:	92407c48 	and	x8, x2, #0xffffffff
    8d38:	2a0503e5 	mov	w5, w5
    8d3c:	d360fc42 	lsr	x2, x2, #32
    8d40:	d360fc26 	lsr	x6, x1, #32
    8d44:	cb0a0063 	sub	x3, x3, x10
    8d48:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    8d4c:	9b087caa 	mul	x10, x5, x8
    8d50:	9b087cc8 	mul	x8, x6, x8
    8d54:	9b0220a5 	madd	x5, x5, x2, x8
    8d58:	9b027cc6 	mul	x6, x6, x2
    8d5c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8d60:	8b0900c5 	add	x5, x6, x9
    8d64:	eb02011f 	cmp	x8, x2
    8d68:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    8d6c:	8b4280c6 	add	x6, x6, x2, lsr #32
    8d70:	eb06007f 	cmp	x3, x6
    8d74:	540000e3 	b.cc	8d90 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    8d78:	92407d4a 	and	x10, x10, #0xffffffff
    8d7c:	9ac72000 	lsl	x0, x0, x7
    8d80:	8b028142 	add	x2, x10, x2, lsl #32
    8d84:	eb02001f 	cmp	x0, x2
    8d88:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    8d8c:	54000a01 	b.ne	8ecc <__divti3+0x32c>  // b.any
    8d90:	d1000420 	sub	x0, x1, #0x1
    8d94:	d2800001 	mov	x1, #0x0                   	// #0
    8d98:	17ffffb4 	b	8c68 <__divti3+0xc8>
    8d9c:	b5000062 	cbnz	x2, 8da8 <__divti3+0x208>
    8da0:	d2800022 	mov	x2, #0x1                   	// #1
    8da4:	9ac30846 	udiv	x6, x2, x3
    8da8:	dac010c8 	clz	x8, x6
    8dac:	b5000408 	cbnz	x8, 8e2c <__divti3+0x28c>
    8db0:	d360fcc9 	lsr	x9, x6, #32
    8db4:	92407cc5 	and	x5, x6, #0xffffffff
    8db8:	cb060023 	sub	x3, x1, x6
    8dbc:	d2800021 	mov	x1, #0x1                   	// #1
    8dc0:	9ac90868 	udiv	x8, x3, x9
    8dc4:	9b098d03 	msub	x3, x8, x9, x3
    8dc8:	aa0803e0 	mov	x0, x8
    8dcc:	9b057d02 	mul	x2, x8, x5
    8dd0:	93c78063 	extr	x3, x3, x7, #32
    8dd4:	eb03005f 	cmp	x2, x3
    8dd8:	540000a9 	b.ls	8dec <__divti3+0x24c>  // b.plast
    8ddc:	ab0300c3 	adds	x3, x6, x3
    8de0:	d1000500 	sub	x0, x8, #0x1
    8de4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8de8:	54000968 	b.hi	8f14 <__divti3+0x374>  // b.pmore
    8dec:	cb020063 	sub	x3, x3, x2
    8df0:	9ac90862 	udiv	x2, x3, x9
    8df4:	aa0203e8 	mov	x8, x2
    8df8:	9b098c42 	msub	x2, x2, x9, x3
    8dfc:	aa0703e3 	mov	x3, x7
    8e00:	9b057d05 	mul	x5, x8, x5
    8e04:	b3607c43 	bfi	x3, x2, #32, #32
    8e08:	eb0300bf 	cmp	x5, x3
    8e0c:	540000c9 	b.ls	8e24 <__divti3+0x284>  // b.plast
    8e10:	ab0300c2 	adds	x2, x6, x3
    8e14:	d1000503 	sub	x3, x8, #0x1
    8e18:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    8e1c:	d1000908 	sub	x8, x8, #0x2
    8e20:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8e24:	aa008100 	orr	x0, x8, x0, lsl #32
    8e28:	17ffff90 	b	8c68 <__divti3+0xc8>
    8e2c:	9ac820c6 	lsl	x6, x6, x8
    8e30:	d2800803 	mov	x3, #0x40                  	// #64
    8e34:	cb080063 	sub	x3, x3, x8
    8e38:	d360fcc9 	lsr	x9, x6, #32
    8e3c:	9ac82027 	lsl	x7, x1, x8
    8e40:	92407cc5 	and	x5, x6, #0xffffffff
    8e44:	9ac32422 	lsr	x2, x1, x3
    8e48:	9ac32403 	lsr	x3, x0, x3
    8e4c:	aa070063 	orr	x3, x3, x7
    8e50:	9ac9084a 	udiv	x10, x2, x9
    8e54:	9ac82007 	lsl	x7, x0, x8
    8e58:	9b098940 	msub	x0, x10, x9, x2
    8e5c:	aa0a03e1 	mov	x1, x10
    8e60:	9b0a7ca2 	mul	x2, x5, x10
    8e64:	93c38000 	extr	x0, x0, x3, #32
    8e68:	eb00005f 	cmp	x2, x0
    8e6c:	540000a9 	b.ls	8e80 <__divti3+0x2e0>  // b.plast
    8e70:	ab0000c0 	adds	x0, x6, x0
    8e74:	d1000541 	sub	x1, x10, #0x1
    8e78:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    8e7c:	54000468 	b.hi	8f08 <__divti3+0x368>  // b.pmore
    8e80:	cb020000 	sub	x0, x0, x2
    8e84:	9ac9080a 	udiv	x10, x0, x9
    8e88:	9b098140 	msub	x0, x10, x9, x0
    8e8c:	aa0a03e2 	mov	x2, x10
    8e90:	9b0a7ca8 	mul	x8, x5, x10
    8e94:	b3607c03 	bfi	x3, x0, #32, #32
    8e98:	eb03011f 	cmp	x8, x3
    8e9c:	540000a9 	b.ls	8eb0 <__divti3+0x310>  // b.plast
    8ea0:	ab0300c3 	adds	x3, x6, x3
    8ea4:	d1000542 	sub	x2, x10, #0x1
    8ea8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    8eac:	54000288 	b.hi	8efc <__divti3+0x35c>  // b.pmore
    8eb0:	cb080063 	sub	x3, x3, x8
    8eb4:	aa018041 	orr	x1, x2, x1, lsl #32
    8eb8:	17ffffc2 	b	8dc0 <__divti3+0x220>
    8ebc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    8ec0:	d2800001 	mov	x1, #0x0                   	// #0
    8ec4:	9a9f87e0 	cset	x0, ls	// ls = plast
    8ec8:	17ffff68 	b	8c68 <__divti3+0xc8>
    8ecc:	aa0103e0 	mov	x0, x1
    8ed0:	d2800001 	mov	x1, #0x0                   	// #0
    8ed4:	17ffff65 	b	8c68 <__divti3+0xc8>
    8ed8:	d1000860 	sub	x0, x3, #0x2
    8edc:	8b0600a5 	add	x5, x5, x6
    8ee0:	17ffff52 	b	8c28 <__divti3+0x88>
    8ee4:	d1000961 	sub	x1, x11, #0x2
    8ee8:	8b0800a5 	add	x5, x5, x8
    8eec:	17ffff85 	b	8d00 <__divti3+0x160>
    8ef0:	d1000965 	sub	x5, x11, #0x2
    8ef4:	8b080063 	add	x3, x3, x8
    8ef8:	17ffff8e 	b	8d30 <__divti3+0x190>
    8efc:	d1000942 	sub	x2, x10, #0x2
    8f00:	8b060063 	add	x3, x3, x6
    8f04:	17ffffeb 	b	8eb0 <__divti3+0x310>
    8f08:	d1000941 	sub	x1, x10, #0x2
    8f0c:	8b060000 	add	x0, x0, x6
    8f10:	17ffffdc 	b	8e80 <__divti3+0x2e0>
    8f14:	d1000900 	sub	x0, x8, #0x2
    8f18:	8b060063 	add	x3, x3, x6
    8f1c:	17ffffb4 	b	8dec <__divti3+0x24c>

0000000000008f20 <__modti3>:
    8f20:	d503245f 	bti	c
    8f24:	d2800004 	mov	x4, #0x0                   	// #0
    8f28:	b6f80081 	tbz	x1, #63, 8f38 <__modti3+0x18>
    8f2c:	eb0003e0 	negs	x0, x0
    8f30:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8f34:	da0103e1 	ngc	x1, x1
    8f38:	f100007f 	cmp	x3, #0x0
    8f3c:	5400128b 	b.lt	918c <__modti3+0x26c>  // b.tstop
    8f40:	aa0003e7 	mov	x7, x0
    8f44:	aa0103e6 	mov	x6, x1
    8f48:	540004e1 	b.ne	8fe4 <__modti3+0xc4>  // b.any
    8f4c:	eb02003f 	cmp	x1, x2
    8f50:	54000dc2 	b.cs	9108 <__modti3+0x1e8>  // b.hs, b.nlast
    8f54:	dac01043 	clz	x3, x2
    8f58:	aa0303e5 	mov	x5, x3
    8f5c:	b40000e3 	cbz	x3, 8f78 <__modti3+0x58>
    8f60:	4b0303e6 	neg	w6, w3
    8f64:	9ac32021 	lsl	x1, x1, x3
    8f68:	9ac32042 	lsl	x2, x2, x3
    8f6c:	9ac62406 	lsr	x6, x0, x6
    8f70:	aa0100c6 	orr	x6, x6, x1
    8f74:	9ac32007 	lsl	x7, x0, x3
    8f78:	d360fc40 	lsr	x0, x2, #32
    8f7c:	92407c43 	and	x3, x2, #0xffffffff
    8f80:	9ac008c1 	udiv	x1, x6, x0
    8f84:	9b009826 	msub	x6, x1, x0, x6
    8f88:	9b017c61 	mul	x1, x3, x1
    8f8c:	93c780c6 	extr	x6, x6, x7, #32
    8f90:	eb06003f 	cmp	x1, x6
    8f94:	540000a9 	b.ls	8fa8 <__modti3+0x88>  // b.plast
    8f98:	ab060046 	adds	x6, x2, x6
    8f9c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    8fa0:	8b0200c8 	add	x8, x6, x2
    8fa4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    8fa8:	cb0100c6 	sub	x6, x6, x1
    8fac:	9ac008c8 	udiv	x8, x6, x0
    8fb0:	9b009901 	msub	x1, x8, x0, x6
    8fb4:	aa0703e0 	mov	x0, x7
    8fb8:	9b087c63 	mul	x3, x3, x8
    8fbc:	b3607c20 	bfi	x0, x1, #32, #32
    8fc0:	eb00007f 	cmp	x3, x0
    8fc4:	54001088 	b.hi	91d4 <__modti3+0x2b4>  // b.pmore
    8fc8:	cb030000 	sub	x0, x0, x3
    8fcc:	9ac52400 	lsr	x0, x0, x5
    8fd0:	d2800001 	mov	x1, #0x0                   	// #0
    8fd4:	b4000064 	cbz	x4, 8fe0 <__modti3+0xc0>
    8fd8:	eb0003e0 	negs	x0, x0
    8fdc:	da0103e1 	ngc	x1, x1
    8fe0:	d65f03c0 	ret
    8fe4:	dac01066 	clz	x6, x3
    8fe8:	eb03003f 	cmp	x1, x3
    8fec:	54ffff43 	b.cc	8fd4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    8ff0:	93407cc5 	sxtw	x5, w6
    8ff4:	d2800808 	mov	x8, #0x40                  	// #64
    8ff8:	cb050108 	sub	x8, x8, x5
    8ffc:	9ac62063 	lsl	x3, x3, x6
    9000:	9ac62025 	lsl	x5, x1, x6
    9004:	9ac82447 	lsr	x7, x2, x8
    9008:	aa0300e7 	orr	x7, x7, x3
    900c:	9ac82423 	lsr	x3, x1, x8
    9010:	92407cec 	and	x12, x7, #0xffffffff
    9014:	d360fcea 	lsr	x10, x7, #32
    9018:	9ac82401 	lsr	x1, x0, x8
    901c:	aa050021 	orr	x1, x1, x5
    9020:	9ac62042 	lsl	x2, x2, x6
    9024:	9ac62000 	lsl	x0, x0, x6
    9028:	9aca086b 	udiv	x11, x3, x10
    902c:	9b0a8d63 	msub	x3, x11, x10, x3
    9030:	aa0b03e5 	mov	x5, x11
    9034:	9b0b7d89 	mul	x9, x12, x11
    9038:	93c18063 	extr	x3, x3, x1, #32
    903c:	eb03013f 	cmp	x9, x3
    9040:	540000a9 	b.ls	9054 <__modti3+0x134>  // b.plast
    9044:	ab0300e3 	adds	x3, x7, x3
    9048:	d1000565 	sub	x5, x11, #0x1
    904c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    9050:	54001168 	b.hi	927c <__modti3+0x35c>  // b.pmore
    9054:	cb090063 	sub	x3, x3, x9
    9058:	9aca086b 	udiv	x11, x3, x10
    905c:	9b0a8d6a 	msub	x10, x11, x10, x3
    9060:	aa0b03e9 	mov	x9, x11
    9064:	9b0b7d8c 	mul	x12, x12, x11
    9068:	b3607d41 	bfi	x1, x10, #32, #32
    906c:	eb01019f 	cmp	x12, x1
    9070:	540000a9 	b.ls	9084 <__modti3+0x164>  // b.plast
    9074:	ab0100e1 	adds	x1, x7, x1
    9078:	d1000569 	sub	x9, x11, #0x1
    907c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9080:	54000f88 	b.hi	9270 <__modti3+0x350>  // b.pmore
    9084:	aa058123 	orr	x3, x9, x5, lsl #32
    9088:	92407c4b 	and	x11, x2, #0xffffffff
    908c:	2a0903e9 	mov	w9, w9
    9090:	d360fc4a 	lsr	x10, x2, #32
    9094:	d360fc63 	lsr	x3, x3, #32
    9098:	cb0c0021 	sub	x1, x1, x12
    909c:	aa0a03ec 	mov	x12, x10
    90a0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    90a4:	9b0b7d25 	mul	x5, x9, x11
    90a8:	9b0b7c6b 	mul	x11, x3, x11
    90ac:	9b0a2d29 	madd	x9, x9, x10, x11
    90b0:	92407caa 	and	x10, x5, #0xffffffff
    90b4:	9b0c7c63 	mul	x3, x3, x12
    90b8:	8b458125 	add	x5, x9, x5, lsr #32
    90bc:	8b0d0069 	add	x9, x3, x13
    90c0:	eb05017f 	cmp	x11, x5
    90c4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    90c8:	8b058149 	add	x9, x10, x5, lsl #32
    90cc:	8b458063 	add	x3, x3, x5, lsr #32
    90d0:	eb03003f 	cmp	x1, x3
    90d4:	54000063 	b.cc	90e0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    90d8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    90dc:	54000082 	b.cs	90ec <__modti3+0x1cc>  // b.hs, b.nlast
    90e0:	eb020129 	subs	x9, x9, x2
    90e4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    90e8:	cb070063 	sub	x3, x3, x7
    90ec:	eb090000 	subs	x0, x0, x9
    90f0:	da030021 	sbc	x1, x1, x3
    90f4:	9ac62400 	lsr	x0, x0, x6
    90f8:	9ac82028 	lsl	x8, x1, x8
    90fc:	aa000100 	orr	x0, x8, x0
    9100:	9ac62421 	lsr	x1, x1, x6
    9104:	17ffffb4 	b	8fd4 <__modti3+0xb4>
    9108:	b5000062 	cbnz	x2, 9114 <__modti3+0x1f4>
    910c:	d2800023 	mov	x3, #0x1                   	// #1
    9110:	9ac20862 	udiv	x2, x3, x2
    9114:	dac01048 	clz	x8, x2
    9118:	aa0803e5 	mov	x5, x8
    911c:	b5000668 	cbnz	x8, 91e8 <__modti3+0x2c8>
    9120:	cb020020 	sub	x0, x1, x2
    9124:	d360fc49 	lsr	x9, x2, #32
    9128:	92407c4a 	and	x10, x2, #0xffffffff
    912c:	9ac90801 	udiv	x1, x0, x9
    9130:	9b098020 	msub	x0, x1, x9, x0
    9134:	9b0a7c21 	mul	x1, x1, x10
    9138:	93c78000 	extr	x0, x0, x7, #32
    913c:	eb00003f 	cmp	x1, x0
    9140:	540000a9 	b.ls	9154 <__modti3+0x234>  // b.plast
    9144:	ab000040 	adds	x0, x2, x0
    9148:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    914c:	8b020003 	add	x3, x0, x2
    9150:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9154:	cb010001 	sub	x1, x0, x1
    9158:	9ac90820 	udiv	x0, x1, x9
    915c:	9b098403 	msub	x3, x0, x9, x1
    9160:	aa0703e1 	mov	x1, x7
    9164:	9b0a7c00 	mul	x0, x0, x10
    9168:	b3607c61 	bfi	x1, x3, #32, #32
    916c:	eb01001f 	cmp	x0, x1
    9170:	540000a9 	b.ls	9184 <__modti3+0x264>  // b.plast
    9174:	ab010041 	adds	x1, x2, x1
    9178:	8b020022 	add	x2, x1, x2
    917c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9180:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9184:	cb000020 	sub	x0, x1, x0
    9188:	17ffff91 	b	8fcc <__modti3+0xac>
    918c:	eb0203e5 	negs	x5, x2
    9190:	aa0003e7 	mov	x7, x0
    9194:	da0303e8 	ngc	x8, x3
    9198:	aa0503e2 	mov	x2, x5
    919c:	aa0803e3 	mov	x3, x8
    91a0:	aa0103e6 	mov	x6, x1
    91a4:	b4ffed48 	cbz	x8, 8f4c <__modti3+0x2c>
    91a8:	eb01011f 	cmp	x8, x1
    91ac:	54fff148 	b.hi	8fd4 <__modti3+0xb4>  // b.pmore
    91b0:	dac01109 	clz	x9, x8
    91b4:	2a0903e6 	mov	w6, w9
    91b8:	b5fff1c9 	cbnz	x9, 8ff0 <__modti3+0xd0>
    91bc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    91c0:	54000068 	b.hi	91cc <__modti3+0x2ac>  // b.pmore
    91c4:	eb050007 	subs	x7, x0, x5
    91c8:	da080021 	sbc	x1, x1, x8
    91cc:	aa0703e0 	mov	x0, x7
    91d0:	17ffff81 	b	8fd4 <__modti3+0xb4>
    91d4:	ab000040 	adds	x0, x2, x0
    91d8:	8b020002 	add	x2, x0, x2
    91dc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    91e0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    91e4:	17ffff79 	b	8fc8 <__modti3+0xa8>
    91e8:	9ac82042 	lsl	x2, x2, x8
    91ec:	d2800803 	mov	x3, #0x40                  	// #64
    91f0:	cb080063 	sub	x3, x3, x8
    91f4:	d360fc49 	lsr	x9, x2, #32
    91f8:	9ac82027 	lsl	x7, x1, x8
    91fc:	92407c4a 	and	x10, x2, #0xffffffff
    9200:	9ac32426 	lsr	x6, x1, x3
    9204:	9ac32403 	lsr	x3, x0, x3
    9208:	aa070063 	orr	x3, x3, x7
    920c:	9ac908c1 	udiv	x1, x6, x9
    9210:	9ac82007 	lsl	x7, x0, x8
    9214:	9b099820 	msub	x0, x1, x9, x6
    9218:	9b017d41 	mul	x1, x10, x1
    921c:	93c38000 	extr	x0, x0, x3, #32
    9220:	eb00003f 	cmp	x1, x0
    9224:	540000a9 	b.ls	9238 <__modti3+0x318>  // b.plast
    9228:	ab000040 	adds	x0, x2, x0
    922c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9230:	8b020006 	add	x6, x0, x2
    9234:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    9238:	cb010000 	sub	x0, x0, x1
    923c:	9ac90801 	udiv	x1, x0, x9
    9240:	9b098026 	msub	x6, x1, x9, x0
    9244:	aa0303e0 	mov	x0, x3
    9248:	9b017d41 	mul	x1, x10, x1
    924c:	b3607cc0 	bfi	x0, x6, #32, #32
    9250:	eb00003f 	cmp	x1, x0
    9254:	540000a9 	b.ls	9268 <__modti3+0x348>  // b.plast
    9258:	ab000040 	adds	x0, x2, x0
    925c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9260:	8b020003 	add	x3, x0, x2
    9264:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9268:	cb010000 	sub	x0, x0, x1
    926c:	17ffffb0 	b	912c <__modti3+0x20c>
    9270:	d1000969 	sub	x9, x11, #0x2
    9274:	8b070021 	add	x1, x1, x7
    9278:	17ffff83 	b	9084 <__modti3+0x164>
    927c:	d1000965 	sub	x5, x11, #0x2
    9280:	8b070063 	add	x3, x3, x7
    9284:	17ffff74 	b	9054 <__modti3+0x134>
    9288:	d503201f 	nop
    928c:	d503201f 	nop

0000000000009290 <atexit>:
    9290:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9294:	f00000a2 	adrp	x2, 20000 <__data_start>
    9298:	d2800001 	mov	x1, #0x0                   	// #0
    929c:	910003fd 	mov	x29, sp
    92a0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    92a4:	f9400442 	ldr	x2, [x2, #8]
    92a8:	17ffe55a 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

00000000000092ac <_fini>:
    92ac:	d503201f 	nop
    92b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    92b4:	910003fd 	mov	x29, sp
    92b8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    92bc:	d65f03c0 	ret
