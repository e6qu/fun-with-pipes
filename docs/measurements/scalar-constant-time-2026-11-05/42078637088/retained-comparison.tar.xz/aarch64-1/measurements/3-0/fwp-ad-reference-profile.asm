
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000025 	adrp	x5, 9000 <__divti3+0x10>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	9129a0a5 	add	x5, x5, #0xa68
    2aa0:	f0000024 	adrp	x4, 9000 <__divti3+0x10>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	9129c084 	add	x4, x4, #0xa70
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	91014261 	add	x1, x19, #0x50
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x12708>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9006820 	str	x0, [x1, #208]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000020 	adrp	x0, 9000 <__divti3+0x10>
    2b34:	913b8000 	add	x0, x0, #0xee0
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0xc0c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	910f8042 	add	x2, x2, #0x3e0
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	91014273 	add	x19, x19, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943f260 	ldr	w0, [x19, #1008]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff50 	bl	2990 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000020 	adrp	x0, 9000 <__divti3+0x10>
    2c7c:	913bc000 	add	x0, x0, #0xef0
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97ffff07 	bl	28a0 <__stack_chk_fail@plt>
    2c88:	f0000020 	adrp	x0, 9000 <__divti3+0x10>
    2c8c:	913e4000 	add	x0, x0, #0xf90
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffeee 	bl	2850 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000020 	adrp	x0, 9000 <__divti3+0x10>
    2ca4:	913da000 	add	x0, x0, #0xf68
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000020 	adrp	x0, 9000 <__divti3+0x10>
    2cb0:	913ce000 	add	x0, x0, #0xf38
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000020 	adrp	x0, 9000 <__divti3+0x10>
    2cbc:	913c4000 	add	x0, x0, #0xf10
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	9100e000 	add	x0, x0, #0x38
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	9100e021 	add	x1, x1, #0x38
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	9100e000 	add	x0, x0, #0x38
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	9100e021 	add	x1, x1, #0x38
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000041 	adrp	x1, a000 <_IO_stdin_used+0x8f0>
    2eb4:	91178021 	add	x1, x1, #0x5e0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x8f0>
    3158:	91170021 	add	x1, x1, #0x5c0
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    3190:	911c6000 	add	x0, x0, #0x718
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    31c4:	911902a1 	add	x1, x21, #0x640
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    31d8:	9128c0a5 	add	x5, x5, #0xa30
    31dc:	911902a1 	add	x1, x21, #0x640
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	911902b7 	add	x23, x21, #0x640
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	911902b5 	add	x21, x21, #0x640
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	911902b5 	add	x21, x21, #0x640
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    3368:	9128a0a5 	add	x5, x5, #0xa28
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000022 	adrp	x2, 9000 <__divti3+0x10>
    339c:	911cc042 	add	x2, x2, #0x730
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000022 	adrp	x2, 9000 <__divti3+0x10>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	911e2042 	add	x2, x2, #0x788
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000039 	adrp	x25, 9000 <__divti3+0x10>
    3428:	d000003a 	adrp	x26, 9000 <__divti3+0x10>
    342c:	911fa339 	add	x25, x25, #0x7e8
    3430:	911d435a 	add	x26, x26, #0x750
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000003b 	adrp	x27, 9000 <__divti3+0x10>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	911d6377 	add	x23, x27, #0x758
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	9120a000 	add	x0, x0, #0x828
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.9+0xfba0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.9+0xfba0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.9+0xfba0>
    34fc:	d0000023 	adrp	x3, 9000 <__divti3+0x10>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000035 	adrp	x21, 9000 <__divti3+0x10>
    3508:	f9423024 	ldr	x4, [x1, #1120]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f94234a5 	ldr	x5, [x5, #1128]
    3514:	91118033 	add	x19, x1, #0x460
    3518:	f9423846 	ldr	x6, [x2, #1136]
    351c:	911d4063 	add	x3, x3, #0x750
    3520:	912102b5 	add	x21, x21, #0x840
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	91220000 	add	x0, x0, #0x880
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    35ac:	911d8000 	add	x0, x0, #0x760
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    366c:	911c6000 	add	x0, x0, #0x718
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000021 	adrp	x1, 9000 <__divti3+0x10>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91222021 	add	x1, x1, #0x888
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000021 	adrp	x1, 9000 <__divti3+0x10>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91224021 	add	x1, x1, #0x890
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000021 	adrp	x1, 9000 <__divti3+0x10>
    37e0:	91226021 	add	x1, x1, #0x898
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffe12 	bl	3074 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000022 	adrp	x2, 9000 <__divti3+0x10>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91228042 	add	x2, x2, #0x8a0
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc33 	bl	2910 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc60 	bl	29d0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc6e 	bl	2a10 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbbc 	bl	2750 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbdc 	bl	2840 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbbf 	bl	27f0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc17 	bl	2960 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    3950:	911c6000 	add	x0, x0, #0x718
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc12 	bl	29a0 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc1c 	bl	29d0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc2a 	bl	2a10 <_Exit@plt>
    396c:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    3970:	9122c000 	add	x0, x0, #0x8b0
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb8a 	bl	27d0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    3a08:	91234000 	add	x0, x0, #0x8d0
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffba4 	bl	28a0 <__stack_chk_fail@plt>
    3a14:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    3a18:	9123c000 	add	x0, x0, #0x8f0
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x8f0>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc17c20 	ldr	q0, [x1, #1520]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	910142b5 	add	x21, x21, #0x50
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f9406aa2 	ldr	x2, [x21, #208]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb9f 	bl	2960 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    3b18:	91246000 	add	x0, x0, #0x918
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb5f 	bl	28a0 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b3c:	91014063 	add	x3, x3, #0x50
    3b40:	9350fc01 	asr	x1, x0, #16
    3b44:	d1000440 	sub	x0, x2, #0x1
    3b48:	f9406c62 	ldr	x2, [x3, #216]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9404463 	ldr	x3, [x3, #136]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    3b88:	91252000 	add	x0, x0, #0x948
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000024 	adrp	x4, 9000 <__divti3+0x10>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	91266084 	add	x4, x4, #0x998
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffb06 	bl	2810 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb5f 	bl	2980 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb4a 	bl	2940 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa93 	bl	26f0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffacb 	bl	27f0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffabc 	bl	27f0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa74 	bl	26f0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa80 	bl	2730 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb10 	bl	2980 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000024 	adrp	x4, 9000 <__divti3+0x10>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	9126c084 	add	x4, x4, #0x9b0
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa90 	bl	2810 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa7f 	bl	27f0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffadf 	bl	2980 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000024 	adrp	x4, 9000 <__divti3+0x10>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	91268084 	add	x4, x4, #0x9a0
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa68 	bl	2810 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa52 	bl	27f0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa26 	bl	27f0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa42 	bl	28a0 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    3fa8:	91190042 	add	x2, x2, #0x640
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000021 	adrp	x1, 9000 <__divti3+0x10>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000020 	adrp	x0, 9000 <__divti3+0x10>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	9126e021 	add	x1, x1, #0x9b8
    4004:	91270000 	add	x0, x0, #0x9c0
    4008:	97fffa0a 	bl	2830 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa87 	bl	2a50 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa35 	bl	2940 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa74 	bl	2a50 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9e5 	bl	2820 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000022 	adrp	x2, 9000 <__divti3+0x10>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	91278042 	add	x2, x2, #0x9e0
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa08 	b	2910 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9c0>
    410c:	91150061 	add	x1, x3, #0x540
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    411c:	91190262 	add	x2, x19, #0x640
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000022 	adrp	x2, a000 <_IO_stdin_used+0x8f0>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9c0>
    414c:	91160021 	add	x1, x1, #0x580
    4150:	3dc18043 	ldr	q3, [x2, #1536]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9c0>
    417c:	91150063 	add	x3, x3, #0x540
    4180:	91178084 	add	x4, x4, #0x5e0
    4184:	91190266 	add	x6, x19, #0x640
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9cd 	bl	2930 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91190275 	add	x21, x19, #0x640
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9b7 	bl	2930 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    4268:	912a4000 	add	x0, x0, #0xa90
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9f0 	bl	2a30 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91190273 	add	x19, x19, #0x640
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffbac 	bl	3170 <fwp_heap_oom>

00000000000042c4 <caf75>:
    42c4:	900000e2 	adrp	x2, 20000 <__data_start>
    42c8:	91014041 	add	x1, x2, #0x50
    42cc:	b940e020 	ldr	w0, [x1, #224]
    42d0:	34000060 	cbz	w0, 42dc <caf75+0x18>
    42d4:	f9407420 	ldr	x0, [x1, #232]
    42d8:	d65f03c0 	ret
    42dc:	b940f020 	ldr	w0, [x1, #240]
    42e0:	340000e0 	cbz	w0, 42fc <caf75+0x38>
    42e4:	f9407c20 	ldr	x0, [x1, #248]
    42e8:	91014042 	add	x2, x2, #0x50
    42ec:	52800021 	mov	w1, #0x1                   	// #1
    42f0:	b900e041 	str	w1, [x2, #224]
    42f4:	f9007440 	str	x0, [x2, #232]
    42f8:	d65f03c0 	ret
    42fc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4300:	52800024 	mov	w4, #0x1                   	// #1
    4304:	aa0303e0 	mov	x0, x3
    4308:	b900f024 	str	w4, [x1, #240]
    430c:	f9007c23 	str	x3, [x1, #248]
    4310:	17fffff6 	b	42e8 <caf75+0x24>

0000000000004314 <fwp_wake_io>:
    4314:	900000e9 	adrp	x9, 20000 <__data_start>
    4318:	91014122 	add	x2, x9, #0x50
    431c:	f9400001 	ldr	x1, [x0]
    4320:	5280000a 	mov	w10, #0x0                   	// #0
    4324:	f9406046 	ldr	x6, [x2, #192]
    4328:	52800008 	mov	w8, #0x0                   	// #0
    432c:	4f000400 	movi	v0.4s, #0x0
    4330:	52800027 	mov	w7, #0x1                   	// #1
    4334:	aa0103e2 	mov	x2, x1
    4338:	b4000321 	cbz	x1, 439c <fwp_wake_io+0x88>
    433c:	f9408c25 	ldr	x5, [x1, #280]
    4340:	39015c27 	strb	w7, [x1, #87]
    4344:	b4000165 	cbz	x5, 4370 <fwp_wake_io+0x5c>
    4348:	a9520c24 	ldp	x4, x3, [x1, #288]
    434c:	b4000364 	cbz	x4, 43b8 <fwp_wake_io+0xa4>
    4350:	f9009483 	str	x3, [x4, #296]
    4354:	f9409423 	ldr	x3, [x1, #296]
    4358:	b4000043 	cbz	x3, 4360 <fwp_wake_io+0x4c>
    435c:	f9009064 	str	x4, [x3, #288]
    4360:	91080023 	add	x3, x1, #0x200
    4364:	f900943f 	str	xzr, [x1, #296]
    4368:	3c918060 	stur	q0, [x3, #-232]
    436c:	f9400001 	ldr	x1, [x0]
    4370:	f9402843 	ldr	x3, [x2, #80]
    4374:	f2001c7f 	tst	x3, #0xff000000ff
    4378:	54fffde1 	b.ne	4334 <fwp_wake_io+0x20>  // b.any
    437c:	39015047 	strb	w7, [x2, #84]
    4380:	f900805f 	str	xzr, [x2, #256]
    4384:	b40001e6 	cbz	x6, 43c0 <fwp_wake_io+0xac>
    4388:	f90080c2 	str	x2, [x6, #256]
    438c:	aa0203e6 	mov	x6, x2
    4390:	52800028 	mov	w8, #0x1                   	// #1
    4394:	aa0103e2 	mov	x2, x1
    4398:	b5fffd21 	cbnz	x1, 433c <fwp_wake_io+0x28>
    439c:	3400006a 	cbz	w10, 43a8 <fwp_wake_io+0x94>
    43a0:	91014120 	add	x0, x9, #0x50
    43a4:	f900640b 	str	x11, [x0, #200]
    43a8:	34000068 	cbz	w8, 43b4 <fwp_wake_io+0xa0>
    43ac:	91014129 	add	x9, x9, #0x50
    43b0:	f9006126 	str	x6, [x9, #192]
    43b4:	d65f03c0 	ret
    43b8:	f90000a3 	str	x3, [x5]
    43bc:	17ffffe7 	b	4358 <fwp_wake_io+0x44>
    43c0:	aa0203eb 	mov	x11, x2
    43c4:	5280002a 	mov	w10, #0x1                   	// #1
    43c8:	17fffff1 	b	438c <fwp_wake_io+0x78>
    43cc:	d503201f 	nop

00000000000043d0 <ad_raw_free.part.0>:
    43d0:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fba0>
    43d4:	d2800001 	mov	x1, #0x0                   	// #0
    43d8:	91118082 	add	x2, x4, #0x460
    43dc:	14000005 	b	43f0 <ad_raw_free.part.0+0x20>
    43e0:	91000421 	add	x1, x1, #0x1
    43e4:	91006042 	add	x2, x2, #0x18
    43e8:	f140043f 	cmp	x1, #0x1, lsl #12
    43ec:	54000220 	b.eq	4430 <ad_raw_free.part.0+0x60>  // b.none
    43f0:	f9400043 	ldr	x3, [x2]
    43f4:	eb03001f 	cmp	x0, x3
    43f8:	54ffff41 	b.ne	43e0 <ad_raw_free.part.0+0x10>  // b.any
    43fc:	8b010421 	add	x1, x1, x1, lsl #1
    4400:	91118084 	add	x4, x4, #0x460
    4404:	900000e2 	adrp	x2, 20000 <__data_start>
    4408:	91014042 	add	x2, x2, #0x50
    440c:	8b010c81 	add	x1, x4, x1, lsl #3
    4410:	b9401024 	ldr	w4, [x1, #16]
    4414:	f9400425 	ldr	x5, [x1, #8]
    4418:	a9007c3f 	stp	xzr, xzr, [x1]
    441c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4420:	f900083f 	str	xzr, [x1, #16]
    4424:	cb050061 	sub	x1, x3, x5
    4428:	f8247841 	str	x1, [x2, x4, lsl #3]
    442c:	17fff94d 	b	2960 <free@plt>
    4430:	f100001f 	cmp	x0, #0x0
    4434:	b0000021 	adrp	x1, 9000 <__divti3+0x10>
    4438:	912ae021 	add	x1, x1, #0xab8
    443c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4440:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    4444:	912a8000 	add	x0, x0, #0xaa0
    4448:	910003fd 	mov	x29, sp
    444c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4450:	97fffbcc 	bl	3380 <ad_raw_fail>

0000000000004454 <fwp_tape_buffers_dispose>:
    4454:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4458:	910003fd 	mov	x29, sp
    445c:	f9000bf3 	str	x19, [sp, #16]
    4460:	aa0003f3 	mov	x19, x0
    4464:	f9400000 	ldr	x0, [x0]
    4468:	b4000040 	cbz	x0, 4470 <fwp_tape_buffers_dispose+0x1c>
    446c:	97ffffd9 	bl	43d0 <ad_raw_free.part.0>
    4470:	f9400a60 	ldr	x0, [x19, #16]
    4474:	b4000040 	cbz	x0, 447c <fwp_tape_buffers_dispose+0x28>
    4478:	97ffffd6 	bl	43d0 <ad_raw_free.part.0>
    447c:	f9401260 	ldr	x0, [x19, #32]
    4480:	b4000040 	cbz	x0, 4488 <fwp_tape_buffers_dispose+0x34>
    4484:	97ffffd3 	bl	43d0 <ad_raw_free.part.0>
    4488:	4f000400 	movi	v0.4s, #0x0
    448c:	f9001a7f 	str	xzr, [x19, #48]
    4490:	ad000260 	stp	q0, q0, [x19]
    4494:	3d800a60 	str	q0, [x19, #32]
    4498:	f9400bf3 	ldr	x19, [sp, #16]
    449c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    44a0:	d65f03c0 	ret

00000000000044a4 <ad_raw_realloc>:
    44a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	f90013f5 	str	x21, [sp, #32]
    44b4:	b40005a1 	cbz	x1, 4568 <ad_raw_realloc+0xc4>
    44b8:	aa0103f4 	mov	x20, x1
    44bc:	2a0203f5 	mov	w21, w2
    44c0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fba0>
    44c4:	d2800004 	mov	x4, #0x0                   	// #0
    44c8:	91118025 	add	x5, x1, #0x460
    44cc:	14000005 	b	44e0 <ad_raw_realloc+0x3c>
    44d0:	91000484 	add	x4, x4, #0x1
    44d4:	910060a5 	add	x5, x5, #0x18
    44d8:	f140049f 	cmp	x4, #0x1, lsl #12
    44dc:	54000320 	b.eq	4540 <ad_raw_realloc+0x9c>  // b.none
    44e0:	f94000a6 	ldr	x6, [x5]
    44e4:	eb06001f 	cmp	x0, x6
    44e8:	54ffff41 	b.ne	44d0 <ad_raw_realloc+0x2c>  // b.any
    44ec:	8b040484 	add	x4, x4, x4, lsl #1
    44f0:	91118021 	add	x1, x1, #0x460
    44f4:	8b040c33 	add	x19, x1, x4, lsl #3
    44f8:	b4000080 	cbz	x0, 4508 <ad_raw_realloc+0x64>
    44fc:	b9401261 	ldr	w1, [x19, #16]
    4500:	6b15003f 	cmp	w1, w21
    4504:	540002c1 	b.ne	455c <ad_raw_realloc+0xb8>  // b.any
    4508:	aa1403e1 	mov	x1, x20
    450c:	97fff8e1 	bl	2890 <realloc@plt>
    4510:	aa0003ed 	mov	x13, x0
    4514:	b40000c0 	cbz	x0, 452c <ad_raw_realloc+0x88>
    4518:	2a1503e3 	mov	w3, w21
    451c:	aa1403e2 	mov	x2, x20
    4520:	aa1303e0 	mov	x0, x19
    4524:	aa0d03e1 	mov	x1, x13
    4528:	97fffa9a 	bl	2f90 <ad_raw_record>
    452c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4530:	aa0d03e0 	mov	x0, x13
    4534:	f94013f5 	ldr	x21, [sp, #32]
    4538:	a8c37bfd 	ldp	x29, x30, [sp], #48
    453c:	d65f03c0 	ret
    4540:	f100001f 	cmp	x0, #0x0
    4544:	b0000021 	adrp	x1, 9000 <__divti3+0x10>
    4548:	912ae021 	add	x1, x1, #0xab8
    454c:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    4550:	912a8000 	add	x0, x0, #0xaa0
    4554:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4558:	97fffb8a 	bl	3380 <ad_raw_fail>
    455c:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    4560:	912be000 	add	x0, x0, #0xaf8
    4564:	97fffb87 	bl	3380 <ad_raw_fail>
    4568:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    456c:	912b6000 	add	x0, x0, #0xad8
    4570:	97fffb84 	bl	3380 <ad_raw_fail>

0000000000004574 <fwp_tape_buffers_release>:
    4574:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4578:	910003fd 	mov	x29, sp
    457c:	a90153f3 	stp	x19, x20, [sp, #16]
    4580:	aa0003f4 	mov	x20, x0
    4584:	f9401400 	ldr	x0, [x0, #40]
    4588:	a9025bf5 	stp	x21, x22, [sp, #32]
    458c:	b7f80560 	tbnz	x0, #63, 4638 <fwp_tape_buffers_release+0xc4>
    4590:	f9401a93 	ldr	x19, [x20, #48]
    4594:	b7f80533 	tbnz	x19, #63, 4638 <fwp_tape_buffers_release+0xc4>
    4598:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    459c:	eb01001f 	cmp	x0, x1
    45a0:	540004c8 	b.hi	4638 <fwp_tape_buffers_release+0xc4>  // b.pmore
    45a4:	8b000400 	add	x0, x0, x0, lsl #1
    45a8:	d2a00101 	mov	x1, #0x80000               	// #524288
    45ac:	d37df000 	lsl	x0, x0, #3
    45b0:	cb000021 	sub	x1, x1, x0
    45b4:	eb410e7f 	cmp	x19, x1, lsr #3
    45b8:	54000408 	b.hi	4638 <fwp_tape_buffers_release+0xc4>  // b.pmore
    45bc:	8b130c13 	add	x19, x0, x19, lsl #3
    45c0:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    45c4:	912c4000 	add	x0, x0, #0xb10
    45c8:	97fff91a 	bl	2a30 <getenv@plt>
    45cc:	b4000080 	cbz	x0, 45dc <fwp_tape_buffers_release+0x68>
    45d0:	39400001 	ldrb	w1, [x0]
    45d4:	7100c03f 	cmp	w1, #0x30
    45d8:	54000880 	b.eq	46e8 <fwp_tape_buffers_release+0x174>  // b.none
    45dc:	d1000661 	sub	x1, x19, #0x1
    45e0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    45e4:	eb00003f 	cmp	x1, x0
    45e8:	54000328 	b.hi	464c <fwp_tape_buffers_release+0xd8>  // b.pmore
    45ec:	900000f5 	adrp	x21, 20000 <__data_start>
    45f0:	f9001bf7 	str	x23, [sp, #48]
    45f4:	910142b7 	add	x23, x21, #0x50
    45f8:	910402f6 	add	x22, x23, #0x100
    45fc:	aa1603e0 	mov	x0, x22
    4600:	97ffff95 	bl	4454 <fwp_tape_buffers_dispose>
    4604:	ad400a81 	ldp	q1, q2, [x20]
    4608:	f9009ef3 	str	x19, [x23, #312]
    460c:	4f000400 	movi	v0.4s, #0x0
    4610:	ad000ac1 	stp	q1, q2, [x22]
    4614:	3dc00a81 	ldr	q1, [x20, #32]
    4618:	3d800ac1 	str	q1, [x22, #32]
    461c:	f9401a80 	ldr	x0, [x20, #48]
    4620:	f9001ac0 	str	x0, [x22, #48]
    4624:	f9001a9f 	str	xzr, [x20, #48]
    4628:	ad000280 	stp	q0, q0, [x20]
    462c:	3d800a80 	str	q0, [x20, #32]
    4630:	f9401bf7 	ldr	x23, [sp, #48]
    4634:	1400000b 	b	4660 <fwp_tape_buffers_release+0xec>
    4638:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    463c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4640:	912c4000 	add	x0, x0, #0xb10
    4644:	97fff8fb 	bl	2a30 <getenv@plt>
    4648:	b5fffc40 	cbnz	x0, 45d0 <fwp_tape_buffers_release+0x5c>
    464c:	aa1403e0 	mov	x0, x20
    4650:	97ffff81 	bl	4454 <fwp_tape_buffers_dispose>
    4654:	900000f5 	adrp	x21, 20000 <__data_start>
    4658:	910142a0 	add	x0, x21, #0x50
    465c:	f9409c13 	ldr	x19, [x0, #312]
    4660:	910142a2 	add	x2, x21, #0x50
    4664:	f940a044 	ldr	x4, [x2, #320]
    4668:	a9400c45 	ldp	x5, x3, [x2]
    466c:	8b040481 	add	x1, x4, x4, lsl #1
    4670:	f9400840 	ldr	x0, [x2, #16]
    4674:	8b010881 	add	x1, x4, x1, lsl #2
    4678:	f9400c44 	ldr	x4, [x2, #24]
    467c:	8b0300a3 	add	x3, x5, x3
    4680:	d37df021 	lsl	x1, x1, #3
    4684:	8b040000 	add	x0, x0, x4
    4688:	8b030000 	add	x0, x0, x3
    468c:	eb05003f 	cmp	x1, x5
    4690:	54000321 	b.ne	46f4 <fwp_tape_buffers_release+0x180>  // b.any
    4694:	8b130023 	add	x3, x1, x19
    4698:	eb00007f 	cmp	x3, x0
    469c:	540002c8 	b.hi	46f4 <fwp_tape_buffers_release+0x180>  // b.pmore
    46a0:	f9405c43 	ldr	x3, [x2, #184]
    46a4:	f140087f 	cmp	x3, #0x2, lsl #12
    46a8:	540002e0 	b.eq	4704 <fwp_tape_buffers_release+0x190>  // b.none
    46ac:	8b030464 	add	x4, x3, x3, lsl #1
    46b0:	90000165 	adrp	x5, 30000 <alt.9+0xfba0>
    46b4:	911180a5 	add	x5, x5, #0x460
    46b8:	cb010000 	sub	x0, x0, x1
    46bc:	d37df084 	lsl	x4, x4, #3
    46c0:	cb130000 	sub	x0, x0, x19
    46c4:	8b0400a6 	add	x6, x5, x4
    46c8:	91000463 	add	x3, x3, #0x1
    46cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46d0:	f82468a1 	str	x1, [x5, x4]
    46d4:	a90080d3 	stp	x19, x0, [x6, #8]
    46d8:	f9005c43 	str	x3, [x2, #184]
    46dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    46e0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    46e4:	d65f03c0 	ret
    46e8:	39400400 	ldrb	w0, [x0, #1]
    46ec:	34fffb00 	cbz	w0, 464c <fwp_tape_buffers_release+0xd8>
    46f0:	17ffffbb 	b	45dc <fwp_tape_buffers_release+0x68>
    46f4:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    46f8:	912ca000 	add	x0, x0, #0xb28
    46fc:	f9001bf7 	str	x23, [sp, #48]
    4700:	97fffb20 	bl	3380 <ad_raw_fail>
    4704:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    4708:	912d6000 	add	x0, x0, #0xb58
    470c:	f9001bf7 	str	x23, [sp, #48]
    4710:	97fffb1c 	bl	3380 <ad_raw_fail>

0000000000004714 <fwp_poll_events>:
    4714:	d10103ff 	sub	sp, sp, #0x40
    4718:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    471c:	f947f400 	ldr	x0, [x0, #4072]
    4720:	a9027bfd 	stp	x29, x30, [sp, #32]
    4724:	910083fd 	add	x29, sp, #0x20
    4728:	a90353f3 	stp	x19, x20, [sp, #48]
    472c:	900000f4 	adrp	x20, 20000 <__data_start>
    4730:	f9400001 	ldr	x1, [x0]
    4734:	f9000fe1 	str	x1, [sp, #24]
    4738:	d2800001 	mov	x1, #0x0                   	// #0
    473c:	97fffc91 	bl	3980 <fwp_now_ns>
    4740:	91014281 	add	x1, x20, #0x50
    4744:	f940a433 	ldr	x19, [x1, #328]
    4748:	b4000e73 	cbz	x19, 4914 <fwp_poll_events+0x200>
    474c:	aa1303e1 	mov	x1, x19
    4750:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4754:	14000005 	b	4768 <fwp_poll_events+0x54>
    4758:	f9408821 	ldr	x1, [x1, #272]
    475c:	eb03005f 	cmp	x2, x3
    4760:	9a83d042 	csel	x2, x2, x3, le
    4764:	b40000c1 	cbz	x1, 477c <fwp_poll_events+0x68>
    4768:	f9403423 	ldr	x3, [x1, #104]
    476c:	b6ffff62 	tbz	x2, #63, 4758 <fwp_poll_events+0x44>
    4770:	f9408821 	ldr	x1, [x1, #272]
    4774:	aa0303e2 	mov	x2, x3
    4778:	b5ffff81 	cbnz	x1, 4768 <fwp_poll_events+0x54>
    477c:	b7f80cc2 	tbnz	x2, #63, 4914 <fwp_poll_events+0x200>
    4780:	cb000042 	sub	x2, x2, x0
    4784:	f100005f 	cmp	x2, #0x0
    4788:	540005ad 	b.le	483c <fwp_poll_events+0x128>
    478c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4790:	d2884801 	mov	x1, #0x4240                	// #16960
    4794:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4798:	f2a001e1 	movk	x1, #0xf, lsl #16
    479c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    47a0:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    47a4:	f2e86360 	movk	x0, #0x431b, lsl #48
    47a8:	9b407c40 	smulh	x0, x2, x0
    47ac:	9352fc00 	asr	x0, x0, #18
    47b0:	cb82fc00 	sub	x0, x0, x2, asr #63
    47b4:	9b018802 	msub	x2, x0, x1, x2
    47b8:	f100005f 	cmp	x2, #0x0
    47bc:	9a800400 	cinc	x0, x0, ne	// ne = any
    47c0:	eb03001f 	cmp	x0, x3
    47c4:	540009ec 	b.gt	4900 <fwp_poll_events+0x1ec>
    47c8:	340003a0 	cbz	w0, 483c <fwp_poll_events+0x128>
    47cc:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    47d0:	52807d04 	mov	w4, #0x3e8                 	// #1000
    47d4:	72a20c42 	movk	w2, #0x1062, lsl #16
    47d8:	9ba27c02 	umull	x2, w0, w2
    47dc:	d366fc43 	lsr	x3, x2, #38
    47e0:	aa0303e2 	mov	x2, x3
    47e4:	1b048063 	msub	w3, w3, w4, w0
    47e8:	9b217c63 	smull	x3, w3, w1
    47ec:	d2800001 	mov	x1, #0x0                   	// #0
    47f0:	910023e0 	add	x0, sp, #0x8
    47f4:	a9008fe2 	stp	x2, x3, [sp, #8]
    47f8:	97fff85e 	bl	2970 <nanosleep@plt>
    47fc:	91014280 	add	x0, x20, #0x50
    4800:	f940a413 	ldr	x19, [x0, #328]
    4804:	97fffc5f 	bl	3980 <fwp_now_ns>
    4808:	aa0003e6 	mov	x6, x0
    480c:	b50001d3 	cbnz	x19, 4844 <fwp_poll_events+0x130>
    4810:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4814:	f947f400 	ldr	x0, [x0, #4072]
    4818:	f9400fe2 	ldr	x2, [sp, #24]
    481c:	f9400001 	ldr	x1, [x0]
    4820:	eb010042 	subs	x2, x2, x1
    4824:	d2800001 	mov	x1, #0x0                   	// #0
    4828:	540008c1 	b.ne	4940 <fwp_poll_events+0x22c>  // b.any
    482c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4830:	a94353f3 	ldp	x19, x20, [sp, #48]
    4834:	910103ff 	add	sp, sp, #0x40
    4838:	d65f03c0 	ret
    483c:	97fffc51 	bl	3980 <fwp_now_ns>
    4840:	aa0003e6 	mov	x6, x0
    4844:	4f000400 	movi	v0.4s, #0x0
    4848:	91014288 	add	x8, x20, #0x50
    484c:	52800027 	mov	w7, #0x1                   	// #1
    4850:	f9403661 	ldr	x1, [x19, #104]
    4854:	aa1303e5 	mov	x5, x19
    4858:	f9408a73 	ldr	x19, [x19, #272]
    485c:	eb06003f 	cmp	x1, x6
    4860:	5400032c 	b.gt	48c4 <fwp_poll_events+0x1b0>
    4864:	394154a0 	ldrb	w0, [x5, #85]
    4868:	36000120 	tbz	w0, #0, 488c <fwp_poll_events+0x178>
    486c:	f94084a0 	ldr	x0, [x5, #264]
    4870:	b40003c0 	cbz	x0, 48e8 <fwp_poll_events+0x1d4>
    4874:	f9008813 	str	x19, [x0, #272]
    4878:	b4000053 	cbz	x19, 4880 <fwp_poll_events+0x16c>
    487c:	f9008660 	str	x0, [x19, #264]
    4880:	910800a0 	add	x0, x5, #0x200
    4884:	390154bf 	strb	wzr, [x5, #85]
    4888:	3c908000 	stur	q0, [x0, #-248]
    488c:	f94030a0 	ldr	x0, [x5, #96]
    4890:	390158a7 	strb	w7, [x5, #86]
    4894:	f100001f 	cmp	x0, #0x0
    4898:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    489c:	5400018d 	b.le	48cc <fwp_poll_events+0x1b8>
    48a0:	f94028a0 	ldr	x0, [x5, #80]
    48a4:	f2001c1f 	tst	x0, #0xff000000ff
    48a8:	540000e1 	b.ne	48c4 <fwp_poll_events+0x1b0>  // b.any
    48ac:	f9406100 	ldr	x0, [x8, #192]
    48b0:	390150a7 	strb	w7, [x5, #84]
    48b4:	f90080bf 	str	xzr, [x5, #256]
    48b8:	b40001e0 	cbz	x0, 48f4 <fwp_poll_events+0x1e0>
    48bc:	f9006105 	str	x5, [x8, #192]
    48c0:	f9008005 	str	x5, [x0, #256]
    48c4:	b5fffc73 	cbnz	x19, 4850 <fwp_poll_events+0x13c>
    48c8:	17ffffd2 	b	4810 <fwp_poll_events+0xfc>
    48cc:	394144a0 	ldrb	w0, [x5, #81]
    48d0:	3707fe80 	tbnz	w0, #0, 48a0 <fwp_poll_events+0x18c>
    48d4:	394140a0 	ldrb	w0, [x5, #80]
    48d8:	3707fe40 	tbnz	w0, #0, 48a0 <fwp_poll_events+0x18c>
    48dc:	aa0503e0 	mov	x0, x5
    48e0:	97fffb84 	bl	36f0 <fwp_cancel_tree.part.0>
    48e4:	17ffffef 	b	48a0 <fwp_poll_events+0x18c>
    48e8:	91014281 	add	x1, x20, #0x50
    48ec:	f900a433 	str	x19, [x1, #328]
    48f0:	17ffffe2 	b	4878 <fwp_poll_events+0x164>
    48f4:	f9006105 	str	x5, [x8, #192]
    48f8:	f9006505 	str	x5, [x8, #200]
    48fc:	17fffff2 	b	48c4 <fwp_poll_events+0x1b0>
    4900:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4904:	d2989362 	mov	x2, #0xc49b                	// #50331
    4908:	f2a4d203 	movk	x3, #0x2690, lsl #16
    490c:	f2a00402 	movk	x2, #0x20, lsl #16
    4910:	17ffffb7 	b	47ec <fwp_poll_events+0xd8>
    4914:	97fff9d8 	bl	3074 <fwp_flush>
    4918:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    491c:	f947e863 	ldr	x3, [x3, #4048]
    4920:	d2800562 	mov	x2, #0x2b                  	// #43
    4924:	d2800021 	mov	x1, #0x1                   	// #1
    4928:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    492c:	912de000 	add	x0, x0, #0xb78
    4930:	f9400063 	ldr	x3, [x3]
    4934:	97fff81b 	bl	29a0 <fwrite@plt>
    4938:	52800ca0 	mov	w0, #0x65                  	// #101
    493c:	97fff785 	bl	2750 <exit@plt>
    4940:	97fff7d8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004944 <fwp_rc_wide_dup>:
    4944:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4948:	910003fd 	mov	x29, sp
    494c:	a90153f3 	stp	x19, x20, [sp, #16]
    4950:	aa0003f3 	mov	x19, x0
    4954:	ca404400 	eor	x0, x0, x0, lsr #17
    4958:	f90013f5 	str	x21, [sp, #32]
    495c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4960:	ca402400 	eor	x0, x0, x0, lsr #9
    4964:	911902a2 	add	x2, x21, #0x640
    4968:	92401c00 	and	x0, x0, #0xff
    496c:	910a2403 	add	x3, x0, #0x289
    4970:	8b000c40 	add	x0, x2, x0, lsl #3
    4974:	8b030c54 	add	x20, x2, x3, lsl #3
    4978:	f94a2401 	ldr	x1, [x0, #5192]
    497c:	b50000a1 	cbnz	x1, 4990 <fwp_rc_wide_dup+0x4c>
    4980:	1400002d 	b	4a34 <fwp_rc_wide_dup+0xf0>
    4984:	91004034 	add	x20, x1, #0x10
    4988:	f9400821 	ldr	x1, [x1, #16]
    498c:	b4000241 	cbz	x1, 49d4 <fwp_rc_wide_dup+0x90>
    4990:	f9400022 	ldr	x2, [x1]
    4994:	eb02027f 	cmp	x19, x2
    4998:	54ffff61 	b.ne	4984 <fwp_rc_wide_dup+0x40>  // b.any
    499c:	f9400281 	ldr	x1, [x20]
    49a0:	39400260 	ldrb	w0, [x19]
    49a4:	7103f81f 	cmp	w0, #0xfe
    49a8:	54000220 	b.eq	49ec <fwp_rc_wide_dup+0xa8>  // b.none
    49ac:	b40001a1 	cbz	x1, 49e0 <fwp_rc_wide_dup+0x9c>
    49b0:	f9400420 	ldr	x0, [x1, #8]
    49b4:	b100041f 	cmn	x0, #0x1
    49b8:	540004a0 	b.eq	4a4c <fwp_rc_wide_dup+0x108>  // b.none
    49bc:	91000400 	add	x0, x0, #0x1
    49c0:	f9000420 	str	x0, [x1, #8]
    49c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    49c8:	f94013f5 	ldr	x21, [sp, #32]
    49cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49d0:	d65f03c0 	ret
    49d4:	39400260 	ldrb	w0, [x19]
    49d8:	7103f81f 	cmp	w0, #0xfe
    49dc:	540000a0 	b.eq	49f0 <fwp_rc_wide_dup+0xac>  // b.none
    49e0:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    49e4:	912f4000 	add	x0, x0, #0xbd0
    49e8:	97fffb86 	bl	3800 <fwp_trap>
    49ec:	b5000281 	cbnz	x1, 4a3c <fwp_rc_wide_dup+0xf8>
    49f0:	d2800300 	mov	x0, #0x18                  	// #24
    49f4:	97fff793 	bl	2840 <malloc@plt>
    49f8:	b4000280 	cbz	x0, 4a48 <fwp_rc_wide_dup+0x104>
    49fc:	d2801fe1 	mov	x1, #0xff                  	// #255
    4a00:	a9000413 	stp	x19, x1, [x0]
    4a04:	911902b5 	add	x21, x21, #0x640
    4a08:	f900081f 	str	xzr, [x0, #16]
    4a0c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4a10:	f9000280 	str	x0, [x20]
    4a14:	39000261 	strb	w1, [x19]
    4a18:	f94e26a0 	ldr	x0, [x21, #7240]
    4a1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a20:	91000400 	add	x0, x0, #0x1
    4a24:	f90e26a0 	str	x0, [x21, #7240]
    4a28:	f94013f5 	ldr	x21, [sp, #32]
    4a2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a30:	d65f03c0 	ret
    4a34:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4a38:	17ffffda 	b	49a0 <fwp_rc_wide_dup+0x5c>
    4a3c:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    4a40:	912ea000 	add	x0, x0, #0xba8
    4a44:	97fffb6f 	bl	3800 <fwp_trap>
    4a48:	97fff9ca 	bl	3170 <fwp_heap_oom>
    4a4c:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    4a50:	912fe000 	add	x0, x0, #0xbf8
    4a54:	97fffb6b 	bl	3800 <fwp_trap>
    4a58:	d503201f 	nop
    4a5c:	d503201f 	nop

0000000000004a60 <fwp_rc_forget_slot>:
    4a60:	aa0003e1 	mov	x1, x0
    4a64:	39400000 	ldrb	w0, [x0]
    4a68:	7103fc1f 	cmp	w0, #0xff
    4a6c:	54000040 	b.eq	4a74 <fwp_rc_forget_slot+0x14>  // b.none
    4a70:	d65f03c0 	ret
    4a74:	ca414420 	eor	x0, x1, x1, lsr #17
    4a78:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4a7c:	ca402400 	eor	x0, x0, x0, lsr #9
    4a80:	910003fd 	mov	x29, sp
    4a84:	92401c00 	and	x0, x0, #0xff
    4a88:	f9000bf3 	str	x19, [sp, #16]
    4a8c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    4a90:	91190262 	add	x2, x19, #0x640
    4a94:	910a2403 	add	x3, x0, #0x289
    4a98:	8b000c40 	add	x0, x2, x0, lsl #3
    4a9c:	8b030c43 	add	x3, x2, x3, lsl #3
    4aa0:	f94a2400 	ldr	x0, [x0, #5192]
    4aa4:	b50000a0 	cbnz	x0, 4ab8 <fwp_rc_forget_slot+0x58>
    4aa8:	14000011 	b	4aec <fwp_rc_forget_slot+0x8c>
    4aac:	91004003 	add	x3, x0, #0x10
    4ab0:	f9400800 	ldr	x0, [x0, #16]
    4ab4:	b40001c0 	cbz	x0, 4aec <fwp_rc_forget_slot+0x8c>
    4ab8:	f9400002 	ldr	x2, [x0]
    4abc:	eb02003f 	cmp	x1, x2
    4ac0:	54ffff61 	b.ne	4aac <fwp_rc_forget_slot+0x4c>  // b.any
    4ac4:	f9400801 	ldr	x1, [x0, #16]
    4ac8:	91190273 	add	x19, x19, #0x640
    4acc:	f9000061 	str	x1, [x3]
    4ad0:	97fff7a4 	bl	2960 <free@plt>
    4ad4:	f94e2660 	ldr	x0, [x19, #7240]
    4ad8:	d1000400 	sub	x0, x0, #0x1
    4adc:	f90e2660 	str	x0, [x19, #7240]
    4ae0:	f9400bf3 	ldr	x19, [sp, #16]
    4ae4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4ae8:	d65f03c0 	ret
    4aec:	b0000020 	adrp	x0, 9000 <__divti3+0x10>
    4af0:	912f4000 	add	x0, x0, #0xbd0
    4af4:	97fffb43 	bl	3800 <fwp_trap>
    4af8:	d503201f 	nop
    4afc:	d503201f 	nop

0000000000004b00 <fwp_rc_prepare_chunk>:
    4b00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4b04:	910003fd 	mov	x29, sp
    4b08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b0c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xba0>
    4b10:	911902c2 	add	x2, x22, #0x640
    4b14:	b9401c03 	ldr	w3, [x0, #28]
    4b18:	aa0103f5 	mov	x21, x1
    4b1c:	a90153f3 	stp	x19, x20, [sp, #16]
    4b20:	aa0003f4 	mov	x20, x0
    4b24:	f94e2440 	ldr	x0, [x2, #7240]
    4b28:	b4000440 	cbz	x0, 4bb0 <fwp_rc_prepare_chunk+0xb0>
    4b2c:	d2800013 	mov	x19, #0x0                   	// #0
    4b30:	35000203 	cbnz	w3, 4b70 <fwp_rc_prepare_chunk+0x70>
    4b34:	b4000361 	cbz	x1, 4ba0 <fwp_rc_prepare_chunk+0xa0>
    4b38:	f9401280 	ldr	x0, [x20, #32]
    4b3c:	97fff789 	bl	2960 <free@plt>
    4b40:	aa1503e0 	mov	x0, x21
    4b44:	d2800021 	mov	x1, #0x1                   	// #1
    4b48:	97fff74e 	bl	2880 <calloc@plt>
    4b4c:	f9001280 	str	x0, [x20, #32]
    4b50:	b5000460 	cbnz	x0, 4bdc <fwp_rc_prepare_chunk+0xdc>
    4b54:	97fff987 	bl	3170 <fwp_heap_oom>
    4b58:	97ffffc2 	bl	4a60 <fwp_rc_forget_slot>
    4b5c:	91000673 	add	x19, x19, #0x1
    4b60:	b9401e83 	ldr	w3, [x20, #28]
    4b64:	eb13007f 	cmp	x3, x19
    4b68:	54000169 	b.ls	4b94 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4b6c:	d503201f 	nop
    4b70:	f9401283 	ldr	x3, [x20, #32]
    4b74:	8b130060 	add	x0, x3, x19
    4b78:	38736863 	ldrb	w3, [x3, x19]
    4b7c:	7103fc7f 	cmp	w3, #0xff
    4b80:	54fffec0 	b.eq	4b58 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b84:	b9401e83 	ldr	w3, [x20, #28]
    4b88:	91000673 	add	x19, x19, #0x1
    4b8c:	eb13007f 	cmp	x3, x19
    4b90:	54ffff08 	b.hi	4b70 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b94:	eb0302bf 	cmp	x21, x3
    4b98:	54000121 	b.ne	4bbc <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b9c:	b5000335 	cbnz	x21, 4c00 <fwp_rc_prepare_chunk+0x100>
    4ba0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bac:	d65f03c0 	ret
    4bb0:	2a0303e3 	mov	w3, w3
    4bb4:	eb0302bf 	cmp	x21, x3
    4bb8:	54ffff20 	b.eq	4b9c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4bbc:	911902c2 	add	x2, x22, #0x640
    4bc0:	f9401280 	ldr	x0, [x20, #32]
    4bc4:	f94e2841 	ldr	x1, [x2, #7248]
    4bc8:	cb030021 	sub	x1, x1, x3
    4bcc:	f90e2841 	str	x1, [x2, #7248]
    4bd0:	97fff764 	bl	2960 <free@plt>
    4bd4:	b5fffb75 	cbnz	x21, 4b40 <fwp_rc_prepare_chunk+0x40>
    4bd8:	f900129f 	str	xzr, [x20, #32]
    4bdc:	911902d6 	add	x22, x22, #0x640
    4be0:	f94e2ac0 	ldr	x0, [x22, #7248]
    4be4:	b9001e95 	str	w21, [x20, #28]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	8b150000 	add	x0, x0, x21
    4bf0:	f90e2ac0 	str	x0, [x22, #7248]
    4bf4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bf8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bfc:	d65f03c0 	ret
    4c00:	f9401280 	ldr	x0, [x20, #32]
    4c04:	aa1503e2 	mov	x2, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	52800001 	mov	w1, #0x0                   	// #0
    4c10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4c18:	17fff716 	b	2870 <memset@plt>
    4c1c:	d503201f 	nop

0000000000004c20 <fwp_heap_refill>:
    4c20:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4c24:	910003fd 	mov	x29, sp
    4c28:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c2c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4c30:	911902b5 	add	x21, x21, #0x640
    4c34:	aa0003f6 	mov	x22, x0
    4c38:	d2800020 	mov	x0, #0x1                   	// #1
    4c3c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c40:	a90363f7 	stp	x23, x24, [sp, #48]
    4c44:	2a0103f7 	mov	w23, w1
    4c48:	2a0203f8 	mov	w24, w2
    4c4c:	97fff959 	bl	31b0 <fwp_heap_chunks>
    4c50:	aa0003f3 	mov	x19, x0
    4c54:	f949fea2 	ldr	x2, [x21, #5112]
    4c58:	8b000800 	add	x0, x0, x0, lsl #2
    4c5c:	2a1703e1 	mov	w1, w23
    4c60:	52800025 	mov	w5, #0x1                   	// #1
    4c64:	d37df000 	lsl	x0, x0, #3
    4c68:	910f0021 	add	x1, x1, #0x3c0
    4c6c:	8b000054 	add	x20, x2, x0
    4c70:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4c74:	52a00024 	mov	w4, #0x10000               	// #65536
    4c78:	38206845 	strb	w5, [x2, x0]
    4c7c:	aa1403e0 	mov	x0, x20
    4c80:	39000698 	strb	w24, [x20, #1]
    4c84:	39000a97 	strb	w23, [x20, #2]
    4c88:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c8c:	b9000681 	str	w1, [x20, #4]
    4c90:	2a0103e5 	mov	w5, w1
    4c94:	8b0300a2 	add	x2, x5, x3
    4c98:	1ac10881 	udiv	w1, w4, w1
    4c9c:	9ac50842 	udiv	x2, x2, x5
    4ca0:	b9000a81 	str	w1, [x20, #8]
    4ca4:	92404021 	and	x1, x1, #0x1ffff
    4ca8:	b9001a82 	str	w2, [x20, #24]
    4cac:	97ffff95 	bl	4b00 <fwp_rc_prepare_chunk>
    4cb0:	f949daa0 	ldr	x0, [x21, #5040]
    4cb4:	29408a81 	ldp	w1, w2, [x20, #4]
    4cb8:	8b134000 	add	x0, x0, x19, lsl #16
    4cbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cc0:	8b214003 	add	x3, x0, w1, uxtw
    4cc4:	9ba20021 	umaddl	x1, w1, w2, x0
    4cc8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ccc:	a90086c3 	stp	x3, x1, [x22, #8]
    4cd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4cd8:	d65f03c0 	ret
    4cdc:	d503201f 	nop

0000000000004ce0 <fwp_mem_free>:
    4ce0:	b40003c0 	cbz	x0, 4d58 <fwp_mem_free+0x78>
    4ce4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4ce8:	910003fd 	mov	x29, sp
    4cec:	a9025bf5 	stp	x21, x22, [sp, #32]
    4cf0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4cf4:	911902a1 	add	x1, x21, #0x640
    4cf8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cfc:	aa0003f3 	mov	x19, x0
    4d00:	f949d823 	ldr	x3, [x1, #5040]
    4d04:	f949ec22 	ldr	x2, [x1, #5080]
    4d08:	cb030000 	sub	x0, x0, x3
    4d0c:	eb02401f 	cmp	x0, x2, lsl #16
    4d10:	540001c2 	b.cs	4d48 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4d14:	d350fc16 	lsr	x22, x0, #16
    4d18:	a90363f7 	stp	x23, x24, [sp, #48]
    4d1c:	f949fc22 	ldr	x2, [x1, #5112]
    4d20:	8b160ad4 	add	x20, x22, x22, lsl #2
    4d24:	d37df294 	lsl	x20, x20, #3
    4d28:	ab140057 	adds	x23, x2, x20
    4d2c:	540000c0 	b.eq	4d44 <fwp_mem_free+0x64>  // b.none
    4d30:	38746842 	ldrb	w2, [x2, x20]
    4d34:	7100045f 	cmp	w2, #0x1
    4d38:	54000120 	b.eq	4d5c <fwp_mem_free+0x7c>  // b.none
    4d3c:	7100085f 	cmp	w2, #0x2
    4d40:	540005e0 	b.eq	4dfc <fwp_mem_free+0x11c>  // b.none
    4d44:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d4c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d50:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d54:	d65f03c0 	ret
    4d58:	d65f03c0 	ret
    4d5c:	f94012f8 	ldr	x24, [x23, #32]
    4d60:	b94006e1 	ldr	w1, [x23, #4]
    4d64:	f90023f9 	str	x25, [sp, #64]
    4d68:	2a0103e2 	mov	w2, w1
    4d6c:	394006f9 	ldrb	w25, [x23, #1]
    4d70:	39400af4 	ldrb	w20, [x23, #2]
    4d74:	b4000158 	cbz	x24, 4d9c <fwp_mem_free+0xbc>
    4d78:	92403e76 	and	x22, x19, #0xffff
    4d7c:	9ac20ad6 	udiv	x22, x22, x2
    4d80:	38766b01 	ldrb	w1, [x24, x22]
    4d84:	8b160300 	add	x0, x24, x22
    4d88:	7103fc3f 	cmp	w1, #0xff
    4d8c:	54000980 	b.eq	4ebc <fwp_mem_free+0x1dc>  // b.none
    4d90:	38366b1f 	strb	wzr, [x24, x22]
    4d94:	b94006e1 	ldr	w1, [x23, #4]
    4d98:	2a0103e2 	mov	w2, w1
    4d9c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4da0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4da4:	cb390000 	sub	x0, x0, w25, uxtb
    4da8:	8b340074 	add	x20, x3, w20, uxtb
    4dac:	911902b5 	add	x21, x21, #0x640
    4db0:	1e630021 	ucvtf	d1, w1
    4db4:	d37ae400 	lsl	x0, x0, #6
    4db8:	8b140c14 	add	x20, x0, x20, lsl #3
    4dbc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dc0:	f8746aa0 	ldr	x0, [x21, x20]
    4dc4:	f94023f9 	ldr	x25, [sp, #64]
    4dc8:	aa2003e0 	mvn	x0, x0
    4dcc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4dd0:	f9000260 	str	x0, [x19]
    4dd4:	f8346ab3 	str	x19, [x21, x20]
    4dd8:	f94a12a0 	ldr	x0, [x21, #5152]
    4ddc:	1e612800 	fadd	d0, d0, d1
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	cb020000 	sub	x0, x0, x2
    4de8:	f90a12a0 	str	x0, [x21, #5152]
    4dec:	fd0a22a0 	str	d0, [x21, #5184]
    4df0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4df8:	d65f03c0 	ret
    4dfc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4e00:	8b000063 	add	x3, x3, x0
    4e04:	eb03027f 	cmp	x19, x3
    4e08:	54fff9e1 	b.ne	4d44 <fwp_mem_free+0x64>  // b.any
    4e0c:	fd400ae1 	ldr	d1, [x23, #16]
    4e10:	fd4a2020 	ldr	d0, [x1, #5184]
    4e14:	f9400ae0 	ldr	x0, [x23, #16]
    4e18:	7e61d821 	ucvtf	d1, d1
    4e1c:	f94a1022 	ldr	x2, [x1, #5152]
    4e20:	f94012f3 	ldr	x19, [x23, #32]
    4e24:	1e612800 	fadd	d0, d0, d1
    4e28:	cb000042 	sub	x2, x2, x0
    4e2c:	f90a1022 	str	x2, [x1, #5152]
    4e30:	fd0a2020 	str	d0, [x1, #5184]
    4e34:	b40000b3 	cbz	x19, 4e48 <fwp_mem_free+0x168>
    4e38:	39400260 	ldrb	w0, [x19]
    4e3c:	7103fc1f 	cmp	w0, #0xff
    4e40:	54000380 	b.eq	4eb0 <fwp_mem_free+0x1d0>  // b.none
    4e44:	3900027f 	strb	wzr, [x19]
    4e48:	b9400ee2 	ldr	w2, [x23, #12]
    4e4c:	b4000142 	cbz	x2, 4e74 <fwp_mem_free+0x194>
    4e50:	911902a1 	add	x1, x21, #0x640
    4e54:	8b160040 	add	x0, x2, x22
    4e58:	8b000800 	add	x0, x0, x0, lsl #2
    4e5c:	f949fc21 	ldr	x1, [x1, #5112]
    4e60:	8b140034 	add	x20, x1, x20
    4e64:	8b000c20 	add	x0, x1, x0, lsl #3
    4e68:	3802869f 	strb	wzr, [x20], #40
    4e6c:	eb00029f 	cmp	x20, x0
    4e70:	54ffffc1 	b.ne	4e68 <fwp_mem_free+0x188>  // b.any
    4e74:	911902a0 	add	x0, x21, #0x640
    4e78:	f94a1801 	ldr	x1, [x0, #5168]
    4e7c:	f949f803 	ldr	x3, [x0, #5104]
    4e80:	8b020021 	add	x1, x1, x2
    4e84:	f90a1801 	str	x1, [x0, #5168]
    4e88:	eb16007f 	cmp	x3, x22
    4e8c:	54000049 	b.ls	4e94 <fwp_mem_free+0x1b4>  // b.plast
    4e90:	f909f816 	str	x22, [x0, #5104]
    4e94:	911902b5 	add	x21, x21, #0x640
    4e98:	f949f6a0 	ldr	x0, [x21, #5096]
    4e9c:	eb16001f 	cmp	x0, x22
    4ea0:	54fff529 	b.ls	4d44 <fwp_mem_free+0x64>  // b.plast
    4ea4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ea8:	f909f6b6 	str	x22, [x21, #5096]
    4eac:	17ffffa7 	b	4d48 <fwp_mem_free+0x68>
    4eb0:	aa1303e0 	mov	x0, x19
    4eb4:	97fffeeb 	bl	4a60 <fwp_rc_forget_slot>
    4eb8:	17ffffe3 	b	4e44 <fwp_mem_free+0x164>
    4ebc:	97fffee9 	bl	4a60 <fwp_rc_forget_slot>
    4ec0:	17ffffb4 	b	4d90 <fwp_mem_free+0xb0>

0000000000004ec4 <fwp_heap_alloc_big>:
    4ec4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4ec8:	910003fd 	mov	x29, sp
    4ecc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ed0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ed4:	a90363f7 	stp	x23, x24, [sp, #48]
    4ed8:	aa0003f7 	mov	x23, x0
    4edc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4ee0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4ee4:	eb0002ff 	cmp	x23, x0
    4ee8:	54000888 	b.hi	4ff8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4eec:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4ef0:	8b0002f4 	add	x20, x23, x0
    4ef4:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xba0>
    4ef8:	91190359 	add	x25, x26, #0x640
    4efc:	d350fe94 	lsr	x20, x20, #16
    4f00:	2a0103f5 	mov	w21, w1
    4f04:	aa1403e0 	mov	x0, x20
    4f08:	97fff8aa 	bl	31b0 <fwp_heap_chunks>
    4f0c:	f949ff22 	ldr	x2, [x25, #5112]
    4f10:	8b000813 	add	x19, x0, x0, lsl #2
    4f14:	aa0003f8 	mov	x24, x0
    4f18:	52800043 	mov	w3, #0x2                   	// #2
    4f1c:	d37df273 	lsl	x19, x19, #3
    4f20:	d2800021 	mov	x1, #0x1                   	// #1
    4f24:	8b130040 	add	x0, x2, x19
    4f28:	38336843 	strb	w3, [x2, x19]
    4f2c:	39000415 	strb	w21, [x0, #1]
    4f30:	b9000c14 	str	w20, [x0, #12]
    4f34:	f9000817 	str	x23, [x0, #16]
    4f38:	97fffef2 	bl	4b00 <fwp_rc_prepare_chunk>
    4f3c:	f100069f 	cmp	x20, #0x1
    4f40:	54000269 	b.ls	4f8c <fwp_heap_alloc_big+0xc8>  // b.plast
    4f44:	8b180294 	add	x20, x20, x24
    4f48:	9100a273 	add	x19, x19, #0x28
    4f4c:	a90573fb 	stp	x27, x28, [sp, #80]
    4f50:	5280007b 	mov	w27, #0x3                   	// #3
    4f54:	8b140a94 	add	x20, x20, x20, lsl #2
    4f58:	2a1803fc 	mov	w28, w24
    4f5c:	9adb2296 	lsl	x22, x20, x27
    4f60:	f949ff35 	ldr	x21, [x25, #5112]
    4f64:	d2800001 	mov	x1, #0x0                   	// #0
    4f68:	8b1302b4 	add	x20, x21, x19
    4f6c:	aa1403e0 	mov	x0, x20
    4f70:	97fffee4 	bl	4b00 <fwp_rc_prepare_chunk>
    4f74:	38336abb 	strb	w27, [x21, x19]
    4f78:	9100a273 	add	x19, x19, #0x28
    4f7c:	b9000e9c 	str	w28, [x20, #12]
    4f80:	eb1302df 	cmp	x22, x19
    4f84:	54fffee1 	b.ne	4f60 <fwp_heap_alloc_big+0x9c>  // b.any
    4f88:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f8c:	91190353 	add	x19, x26, #0x640
    4f90:	aa1703e2 	mov	x2, x23
    4f94:	52800001 	mov	w1, #0x0                   	// #0
    4f98:	f949da60 	ldr	x0, [x19, #5040]
    4f9c:	8b184018 	add	x24, x0, x24, lsl #16
    4fa0:	aa1803e0 	mov	x0, x24
    4fa4:	97fff633 	bl	2870 <memset@plt>
    4fa8:	f94a1260 	ldr	x0, [x19, #5152]
    4fac:	ab170000 	adds	x0, x0, x23
    4fb0:	54000242 	b.cs	4ff8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4fb4:	f94a1661 	ldr	x1, [x19, #5160]
    4fb8:	f90a1260 	str	x0, [x19, #5152]
    4fbc:	eb01001f 	cmp	x0, x1
    4fc0:	54000049 	b.ls	4fc8 <fwp_heap_alloc_big+0x104>  // b.plast
    4fc4:	f90a1660 	str	x0, [x19, #5160]
    4fc8:	9119035a 	add	x26, x26, #0x640
    4fcc:	9e6202e0 	scvtf	d0, x23
    4fd0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fd4:	aa1803e0 	mov	x0, x24
    4fd8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4fdc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fe0:	1e602820 	fadd	d0, d1, d0
    4fe4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4fe8:	fd0a1f40 	str	d0, [x26, #5176]
    4fec:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ff0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4ff4:	d65f03c0 	ret
    4ff8:	a90573fb 	stp	x27, x28, [sp, #80]
    4ffc:	97fff85d 	bl	3170 <fwp_heap_oom>

0000000000005000 <fwp_heap_alloc_slow>:
    5000:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5004:	910003fd 	mov	x29, sp
    5008:	a90153f3 	stp	x19, x20, [sp, #16]
    500c:	900003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    5010:	91190262 	add	x2, x19, #0x640
    5014:	a9025bf5 	stp	x21, x22, [sp, #32]
    5018:	aa0003f5 	mov	x21, x0
    501c:	2a0103f4 	mov	w20, w1
    5020:	b953a440 	ldr	w0, [x2, #5028]
    5024:	34000600 	cbz	w0, 50e4 <fwp_heap_alloc_slow+0xe4>
    5028:	f14012bf 	cmp	x21, #0x4, lsl #12
    502c:	54000628 	b.hi	50f0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    5030:	91003ea0 	add	x0, x21, #0xf
    5034:	91190262 	add	x2, x19, #0x640
    5038:	f9001bf7 	str	x23, [sp, #48]
    503c:	937c7e84 	sbfiz	x4, x20, #4, #32
    5040:	8b401040 	add	x0, x2, x0, lsr #4
    5044:	cb34c084 	sub	x4, x4, w20, sxtw
    5048:	d37ae484 	lsl	x4, x4, #6
    504c:	397e8003 	ldrb	w3, [x0, #4000]
    5050:	910f0060 	add	x0, x3, #0x3c0
    5054:	aa0303e1 	mov	x1, x3
    5058:	8b030463 	add	x3, x3, x3, lsl #1
    505c:	8b030c83 	add	x3, x4, x3, lsl #3
    5060:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5064:	2a1703f6 	mov	w22, w23
    5068:	f8636844 	ldr	x4, [x2, x3]
    506c:	b40004e4 	cbz	x4, 5108 <fwp_heap_alloc_slow+0x108>
    5070:	f9400080 	ldr	x0, [x4]
    5074:	aa2003e0 	mvn	x0, x0
    5078:	f8236840 	str	x0, [x2, x3]
    507c:	7100069f 	cmp	w20, #0x1
    5080:	aa0403e0 	mov	x0, x4
    5084:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5088:	52800001 	mov	w1, #0x0                   	// #0
    508c:	97fff5f9 	bl	2870 <memset@plt>
    5090:	aa0003e4 	mov	x4, x0
    5094:	91190260 	add	x0, x19, #0x640
    5098:	f94a1001 	ldr	x1, [x0, #5152]
    509c:	ab160021 	adds	x1, x1, x22
    50a0:	540005c2 	b.cs	5158 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    50a4:	f94a1402 	ldr	x2, [x0, #5160]
    50a8:	f90a1001 	str	x1, [x0, #5152]
    50ac:	eb02003f 	cmp	x1, x2
    50b0:	54000049 	b.ls	50b8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    50b4:	f90a1401 	str	x1, [x0, #5160]
    50b8:	91190273 	add	x19, x19, #0x640
    50bc:	1e6302e1 	ucvtf	d1, w23
    50c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50c4:	aa0403e0 	mov	x0, x4
    50c8:	fd4a1e60 	ldr	d0, [x19, #5176]
    50cc:	f9401bf7 	ldr	x23, [sp, #48]
    50d0:	1e612800 	fadd	d0, d0, d1
    50d4:	fd0a1e60 	str	d0, [x19, #5176]
    50d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50dc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50e0:	d65f03c0 	ret
    50e4:	97fffc08 	bl	4104 <fwp_heap_init>
    50e8:	f14012bf 	cmp	x21, #0x4, lsl #12
    50ec:	54fffa29 	b.ls	5030 <fwp_heap_alloc_slow+0x30>  // b.plast
    50f0:	2a1403e1 	mov	w1, w20
    50f4:	aa1503e0 	mov	x0, x21
    50f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5100:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5104:	17ffff70 	b	4ec4 <fwp_heap_alloc_big>
    5108:	8b030042 	add	x2, x2, x3
    510c:	f9400444 	ldr	x4, [x2, #8]
    5110:	b4000104 	cbz	x4, 5130 <fwp_heap_alloc_slow+0x130>
    5114:	f9400840 	ldr	x0, [x2, #16]
    5118:	cb040000 	sub	x0, x0, x4
    511c:	eb16001f 	cmp	x0, x22
    5120:	54000083 	b.cc	5130 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5124:	8b160080 	add	x0, x4, x22
    5128:	f9000440 	str	x0, [x2, #8]
    512c:	17ffffd4 	b	507c <fwp_heap_alloc_slow+0x7c>
    5130:	52800302 	mov	w2, #0x18                  	// #24
    5134:	52807804 	mov	w4, #0x3c0                 	// #960
    5138:	91190260 	add	x0, x19, #0x640
    513c:	9ba27c23 	umull	x3, w1, w2
    5140:	2a1403e2 	mov	w2, w20
    5144:	9b240e84 	smaddl	x4, w20, w4, x3
    5148:	8b040000 	add	x0, x0, x4
    514c:	97fffeb5 	bl	4c20 <fwp_heap_refill>
    5150:	aa0003e4 	mov	x4, x0
    5154:	17ffffca 	b	507c <fwp_heap_alloc_slow+0x7c>
    5158:	97fff806 	bl	3170 <fwp_heap_oom>
    515c:	d503201f 	nop

0000000000005160 <fwp_heap_alloc>:
    5160:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5164:	910003fd 	mov	x29, sp
    5168:	a9025bf5 	stp	x21, x22, [sp, #32]
    516c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5170:	910142c2 	add	x2, x22, #0x50
    5174:	a90363f7 	stp	x23, x24, [sp, #48]
    5178:	b9415058 	ldr	w24, [x2, #336]
    517c:	a90153f3 	stp	x19, x20, [sp, #16]
    5180:	7100031f 	cmp	w24, #0x0
    5184:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5188:	54000861 	b.ne	5294 <fwp_heap_alloc+0x134>  // b.any
    518c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xba0>
    5190:	911902f3 	add	x19, x23, #0x640
    5194:	f140101f 	cmp	x0, #0x4, lsl #12
    5198:	b953a662 	ldr	w2, [x19, #5028]
    519c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    51a0:	54000740 	b.eq	5288 <fwp_heap_alloc+0x128>  // b.none
    51a4:	91003c03 	add	x3, x0, #0xf
    51a8:	937c7c22 	sbfiz	x2, x1, #4, #32
    51ac:	cb21c042 	sub	x2, x2, w1, sxtw
    51b0:	8b431263 	add	x3, x19, x3, lsr #4
    51b4:	d37ae442 	lsl	x2, x2, #6
    51b8:	397e8063 	ldrb	w3, [x3, #4000]
    51bc:	910f0064 	add	x4, x3, #0x3c0
    51c0:	8b030463 	add	x3, x3, x3, lsl #1
    51c4:	8b030c43 	add	x3, x2, x3, lsl #3
    51c8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    51cc:	2a1503f4 	mov	w20, w21
    51d0:	f8636a64 	ldr	x4, [x19, x3]
    51d4:	b40004c4 	cbz	x4, 526c <fwp_heap_alloc+0x10c>
    51d8:	f9400085 	ldr	x5, [x4]
    51dc:	7100043f 	cmp	w1, #0x1
    51e0:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    51e4:	aa0403e0 	mov	x0, x4
    51e8:	aa2503e5 	mvn	x5, x5
    51ec:	52800001 	mov	w1, #0x0                   	// #0
    51f0:	f8236a65 	str	x5, [x19, x3]
    51f4:	97fff59f 	bl	2870 <memset@plt>
    51f8:	aa0003e4 	mov	x4, x0
    51fc:	f94a1260 	ldr	x0, [x19, #5152]
    5200:	ab140000 	adds	x0, x0, x20
    5204:	540006e2 	b.cs	52e0 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5208:	f94a1661 	ldr	x1, [x19, #5160]
    520c:	f90a1260 	str	x0, [x19, #5152]
    5210:	eb01001f 	cmp	x0, x1
    5214:	54000049 	b.ls	521c <fwp_heap_alloc+0xbc>  // b.plast
    5218:	f90a1660 	str	x0, [x19, #5160]
    521c:	911902e0 	add	x0, x23, #0x640
    5220:	1e6302a1 	ucvtf	d1, w21
    5224:	fd4a1c00 	ldr	d0, [x0, #5176]
    5228:	1e612800 	fadd	d0, d0, d1
    522c:	fd0a1c00 	str	d0, [x0, #5176]
    5230:	34000138 	cbz	w24, 5254 <fwp_heap_alloc+0xf4>
    5234:	911902e1 	add	x1, x23, #0x640
    5238:	910142c0 	add	x0, x22, #0x50
    523c:	fd4a1020 	ldr	d0, [x1, #5152]
    5240:	6d568402 	ldp	d2, d1, [x0, #360]
    5244:	7e61d800 	ucvtf	d0, d0
    5248:	1e623800 	fsub	d0, d0, d2
    524c:	1e612010 	fcmpe	d0, d1
    5250:	540002cc 	b.gt	52a8 <fwp_heap_alloc+0x148>
    5254:	a94153f3 	ldp	x19, x20, [sp, #16]
    5258:	aa0403e0 	mov	x0, x4
    525c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5260:	a94363f7 	ldp	x23, x24, [sp, #48]
    5264:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5268:	d65f03c0 	ret
    526c:	8b030263 	add	x3, x19, x3
    5270:	f9400464 	ldr	x4, [x3, #8]
    5274:	b40000a4 	cbz	x4, 5288 <fwp_heap_alloc+0x128>
    5278:	f9400862 	ldr	x2, [x3, #16]
    527c:	cb040042 	sub	x2, x2, x4
    5280:	eb02029f 	cmp	x20, x2
    5284:	54000209 	b.ls	52c4 <fwp_heap_alloc+0x164>  // b.plast
    5288:	97ffff5e 	bl	5000 <fwp_heap_alloc_slow>
    528c:	aa0003e4 	mov	x4, x0
    5290:	17ffffe8 	b	5230 <fwp_heap_alloc+0xd0>
    5294:	a9558c44 	ldp	x4, x3, [x2, #344]
    5298:	91000484 	add	x4, x4, #0x1
    529c:	8b000063 	add	x3, x3, x0
    52a0:	a9158c44 	stp	x4, x3, [x2, #344]
    52a4:	17ffffba 	b	518c <fwp_heap_alloc+0x2c>
    52a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    52ac:	fd00b800 	str	d0, [x0, #368]
    52b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52b4:	aa0403e0 	mov	x0, x4
    52b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    52bc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    52c0:	d65f03c0 	ret
    52c4:	7100043f 	cmp	w1, #0x1
    52c8:	8b140085 	add	x5, x4, x20
    52cc:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    52d0:	52800001 	mov	w1, #0x0                   	// #0
    52d4:	aa0403e0 	mov	x0, x4
    52d8:	f9000465 	str	x5, [x3, #8]
    52dc:	17ffffc6 	b	51f4 <fwp_heap_alloc+0x94>
    52e0:	97fff7a4 	bl	3170 <fwp_heap_oom>

00000000000052e4 <fwp_data.part.0.constprop.0>:
    52e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    52e8:	910003fd 	mov	x29, sp
    52ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    52f0:	f00000d6 	adrp	x22, 20000 <__data_start>
    52f4:	910142c2 	add	x2, x22, #0x50
    52f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52fc:	b9415059 	ldr	w25, [x2, #336]
    5300:	a90153f3 	stp	x19, x20, [sp, #16]
    5304:	aa0103f4 	mov	x20, x1
    5308:	a90363f7 	stp	x23, x24, [sp, #48]
    530c:	2a0003f7 	mov	w23, w0
    5310:	340000b9 	cbz	w25, 5324 <fwp_data.part.0.constprop.0+0x40>
    5314:	a9558041 	ldp	x1, x0, [x2, #344]
    5318:	91000421 	add	x1, x1, #0x1
    531c:	91006000 	add	x0, x0, #0x18
    5320:	a9158041 	stp	x1, x0, [x2, #344]
    5324:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5328:	911902a3 	add	x3, x21, #0x640
    532c:	b953a460 	ldr	w0, [x3, #5028]
    5330:	34000840 	cbz	w0, 5438 <fwp_data.part.0.constprop.0+0x154>
    5334:	397e8862 	ldrb	w2, [x3, #4002]
    5338:	910f0040 	add	x0, x2, #0x3c0
    533c:	8b020442 	add	x2, x2, x2, lsl #1
    5340:	d37df042 	lsl	x2, x2, #3
    5344:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5348:	2a1a03f8 	mov	w24, w26
    534c:	f8626873 	ldr	x19, [x3, x2]
    5350:	b4000613 	cbz	x19, 5410 <fwp_data.part.0.constprop.0+0x12c>
    5354:	f9400260 	ldr	x0, [x19]
    5358:	aa2003e0 	mvn	x0, x0
    535c:	f8226860 	str	x0, [x3, x2]
    5360:	f100631f 	cmp	x24, #0x18
    5364:	540000e9 	b.ls	5380 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5368:	d1006702 	sub	x2, x24, #0x19
    536c:	91006260 	add	x0, x19, #0x18
    5370:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5374:	52800001 	mov	w1, #0x0                   	// #0
    5378:	91002042 	add	x2, x2, #0x8
    537c:	97fff53d 	bl	2870 <memset@plt>
    5380:	911902a0 	add	x0, x21, #0x640
    5384:	f94a1001 	ldr	x1, [x0, #5152]
    5388:	ab180021 	adds	x1, x1, x24
    538c:	54000642 	b.cs	5454 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5390:	f94a1402 	ldr	x2, [x0, #5160]
    5394:	f90a1001 	str	x1, [x0, #5152]
    5398:	eb02003f 	cmp	x1, x2
    539c:	54000049 	b.ls	53a4 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    53a0:	f90a1401 	str	x1, [x0, #5160]
    53a4:	911902a0 	add	x0, x21, #0x640
    53a8:	1e630341 	ucvtf	d1, w26
    53ac:	fd4a1c00 	ldr	d0, [x0, #5176]
    53b0:	1e612800 	fadd	d0, d0, d1
    53b4:	fd0a1c00 	str	d0, [x0, #5176]
    53b8:	34000139 	cbz	w25, 53dc <fwp_data.part.0.constprop.0+0xf8>
    53bc:	911902b5 	add	x21, x21, #0x640
    53c0:	910142d6 	add	x22, x22, #0x50
    53c4:	fd4a12a0 	ldr	d0, [x21, #5152]
    53c8:	6d5686c2 	ldp	d2, d1, [x22, #360]
    53cc:	7e61d800 	ucvtf	d0, d0
    53d0:	1e623800 	fsub	d0, d0, d2
    53d4:	1e612010 	fcmpe	d0, d1
    53d8:	540003ac 	b.gt	544c <fwp_data.part.0.constprop.0+0x168>
    53dc:	52800040 	mov	w0, #0x2                   	// #2
    53e0:	29000277 	stp	w23, w0, [x19]
    53e4:	aa1303e0 	mov	x0, x19
    53e8:	f9400281 	ldr	x1, [x20]
    53ec:	f9000661 	str	x1, [x19, #8]
    53f0:	f9400681 	ldr	x1, [x20, #8]
    53f4:	f9000a61 	str	x1, [x19, #16]
    53f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    53fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5400:	a94363f7 	ldp	x23, x24, [sp, #48]
    5404:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5408:	a8c57bfd 	ldp	x29, x30, [sp], #80
    540c:	d65f03c0 	ret
    5410:	8b020063 	add	x3, x3, x2
    5414:	f9400473 	ldr	x19, [x3, #8]
    5418:	b4000113 	cbz	x19, 5438 <fwp_data.part.0.constprop.0+0x154>
    541c:	f9400860 	ldr	x0, [x3, #16]
    5420:	cb130000 	sub	x0, x0, x19
    5424:	eb00031f 	cmp	x24, x0
    5428:	54000088 	b.hi	5438 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    542c:	8b180260 	add	x0, x19, x24
    5430:	f9000460 	str	x0, [x3, #8]
    5434:	17ffffcb 	b	5360 <fwp_data.part.0.constprop.0+0x7c>
    5438:	52800001 	mov	w1, #0x0                   	// #0
    543c:	d2800300 	mov	x0, #0x18                  	// #24
    5440:	97ffff48 	bl	5160 <fwp_heap_alloc>
    5444:	aa0003f3 	mov	x19, x0
    5448:	17ffffdc 	b	53b8 <fwp_data.part.0.constprop.0+0xd4>
    544c:	fd00bac0 	str	d0, [x22, #368]
    5450:	17ffffe3 	b	53dc <fwp_data.part.0.constprop.0+0xf8>
    5454:	97fff747 	bl	3170 <fwp_heap_oom>
    5458:	d503201f 	nop
    545c:	d503201f 	nop

0000000000005460 <fwp_p_ad_push>:
    5460:	f100001f 	cmp	x0, #0x0
    5464:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    5468:	54000eab 	b.lt	563c <fwp_p_ad_push+0x1dc>  // b.tstop
    546c:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5470:	aa0003e4 	mov	x4, x0
    5474:	910003fd 	mov	x29, sp
    5478:	a9025bf5 	stp	x21, x22, [sp, #32]
    547c:	aa0003f5 	mov	x21, x0
    5480:	aa020000 	orr	x0, x0, x2
    5484:	a90363f7 	stp	x23, x24, [sp, #48]
    5488:	aa0203f7 	mov	x23, x2
    548c:	6d0627e8 	stp	d8, d9, [sp, #96]
    5490:	9e670029 	fmov	d9, x1
    5494:	9e670068 	fmov	d8, x3
    5498:	b6f80920 	tbz	x0, #63, 55bc <fwp_p_ad_push+0x15c>
    549c:	a90153f3 	stp	x19, x20, [sp, #16]
    54a0:	9360fc80 	asr	x0, x4, #32
    54a4:	b6f800c4 	tbz	x4, #63, 54bc <fwp_p_ad_push+0x5c>
    54a8:	1e604109 	fmov	d9, d8
    54ac:	2f00e408 	movi	d8, #0x0
    54b0:	9360fc40 	asr	x0, x2, #32
    54b4:	aa0203f5 	mov	x21, x2
    54b8:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    54bc:	97fff99d 	bl	3b30 <fwp_tape_of>
    54c0:	aa0003f3 	mov	x19, x0
    54c4:	f9403000 	ldr	x0, [x0, #96]
    54c8:	b5001240 	cbnz	x0, 5710 <fwp_p_ad_push+0x2b0>
    54cc:	f9400a76 	ldr	x22, [x19, #16]
    54d0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54d4:	eb0002df 	cmp	x22, x0
    54d8:	54000d8c 	b.gt	5688 <fwp_p_ad_push+0x228>
    54dc:	eb3542df 	cmp	x22, w21, uxtw
    54e0:	54000cad 	b.le	5674 <fwp_p_ad_push+0x214>
    54e4:	b7f80077 	tbnz	x23, #63, 54f0 <fwp_p_ad_push+0x90>
    54e8:	eb3742df 	cmp	x22, w23, uxtw
    54ec:	54000c4d 	b.le	5674 <fwp_p_ad_push+0x214>
    54f0:	f9400678 	ldr	x24, [x19, #8]
    54f4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54f8:	cb1802d8 	sub	x24, x22, x24
    54fc:	91000701 	add	x1, x24, #0x1
    5500:	eb00003f 	cmp	x1, x0
    5504:	54000c28 	b.hi	5688 <fwp_p_ad_push+0x228>  // b.pmore
    5508:	a9418274 	ldp	x20, x0, [x19, #24]
    550c:	a90573fb 	stp	x27, x28, [sp, #80]
    5510:	eb14003f 	cmp	x1, x20
    5514:	540006ad 	b.le	55e8 <fwp_p_ad_push+0x188>
    5518:	f100029f 	cmp	x20, #0x0
    551c:	d2800803 	mov	x3, #0x40                  	// #64
    5520:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5524:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5528:	a9046bf9 	stp	x25, x26, [sp, #64]
    552c:	eb14003f 	cmp	x1, x20
    5530:	5400008d 	b.le	5540 <fwp_p_ad_push+0xe0>
    5534:	eb02029f 	cmp	x20, x2
    5538:	5400054d 	b.le	55e0 <fwp_p_ad_push+0x180>
    553c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5540:	d37df299 	lsl	x25, x20, #3
    5544:	52800022 	mov	w2, #0x1                   	// #1
    5548:	aa1903e1 	mov	x1, x25
    554c:	97fffbd6 	bl	44a4 <ad_raw_realloc>
    5550:	aa0003e1 	mov	x1, x0
    5554:	b4000a40 	cbz	x0, 569c <fwp_p_ad_push+0x23c>
    5558:	f9400e63 	ldr	x3, [x19, #24]
    555c:	f9001261 	str	x1, [x19, #32]
    5560:	f9401a60 	ldr	x0, [x19, #48]
    5564:	52800042 	mov	w2, #0x2                   	// #2
    5568:	8b030821 	add	x1, x1, x3, lsl #2
    556c:	f9001661 	str	x1, [x19, #40]
    5570:	d37cee81 	lsl	x1, x20, #4
    5574:	97fffbcc 	bl	44a4 <ad_raw_realloc>
    5578:	aa0003e2 	mov	x2, x0
    557c:	b4000900 	cbz	x0, 569c <fwp_p_ad_push+0x23c>
    5580:	f9400e61 	ldr	x1, [x19, #24]
    5584:	d37df31b 	lsl	x27, x24, #3
    5588:	d37ef69a 	lsl	x26, x20, #2
    558c:	d37ef71c 	lsl	x28, x24, #2
    5590:	8b190003 	add	x3, x0, x25
    5594:	8b010c01 	add	x1, x0, x1, lsl #3
    5598:	a9030660 	stp	x0, x1, [x19, #48]
    559c:	b5000558 	cbnz	x24, 5644 <fwp_p_ad_push+0x1e4>
    55a0:	f9001e63 	str	x3, [x19, #56]
    55a4:	f9401260 	ldr	x0, [x19, #32]
    55a8:	8b1a0001 	add	x1, x0, x26
    55ac:	a9446bf9 	ldp	x25, x26, [sp, #64]
    55b0:	f9000e74 	str	x20, [x19, #24]
    55b4:	f9001661 	str	x1, [x19, #40]
    55b8:	14000010 	b	55f8 <fwp_p_ad_push+0x198>
    55bc:	9360fc40 	asr	x0, x2, #32
    55c0:	a90153f3 	stp	x19, x20, [sp, #16]
    55c4:	eb84801f 	cmp	x0, x4, asr #32
    55c8:	54fff7a0 	b.eq	54bc <fwp_p_ad_push+0x5c>  // b.none
    55cc:	90000020 	adrp	x0, 9000 <__divti3+0x10>
    55d0:	91306000 	add	x0, x0, #0xc18
    55d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    55d8:	a90573fb 	stp	x27, x28, [sp, #80]
    55dc:	97fff889 	bl	3800 <fwp_trap>
    55e0:	d37ffa94 	lsl	x20, x20, #1
    55e4:	17ffffd2 	b	552c <fwp_p_ad_push+0xcc>
    55e8:	a9428a61 	ldp	x1, x2, [x19, #40]
    55ec:	d37ef71c 	lsl	x28, x24, #2
    55f0:	f9401e63 	ldr	x3, [x19, #56]
    55f4:	d37df31b 	lsl	x27, x24, #3
    55f8:	b83c6815 	str	w21, [x0, x28]
    55fc:	f10002ff 	cmp	x23, #0x0
    5600:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5604:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5608:	fc3b6849 	str	d9, [x2, x27]
    560c:	aa1602a0 	orr	x0, x21, x22
    5610:	b83c6837 	str	w23, [x1, x28]
    5614:	910006d6 	add	x22, x22, #0x1
    5618:	a94363f7 	ldp	x23, x24, [sp, #48]
    561c:	fc3b6868 	str	d8, [x3, x27]
    5620:	a94573fb 	ldp	x27, x28, [sp, #80]
    5624:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5628:	f9000a76 	str	x22, [x19, #16]
    562c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5630:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5634:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5638:	d65f03c0 	ret
    563c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5640:	d65f03c0 	ret
    5644:	aa0303e0 	mov	x0, x3
    5648:	aa1b03e2 	mov	x2, x27
    564c:	97fff431 	bl	2710 <memmove@plt>
    5650:	a9420660 	ldp	x0, x1, [x19, #32]
    5654:	aa1c03e2 	mov	x2, x28
    5658:	f9401a63 	ldr	x3, [x19, #48]
    565c:	8b190063 	add	x3, x3, x25
    5660:	f9001e63 	str	x3, [x19, #56]
    5664:	8b1a0000 	add	x0, x0, x26
    5668:	97fff42a 	bl	2710 <memmove@plt>
    566c:	a9430e62 	ldp	x2, x3, [x19, #48]
    5670:	17ffffcd 	b	55a4 <fwp_p_ad_push+0x144>
    5674:	90000020 	adrp	x0, 9000 <__divti3+0x10>
    5678:	9132c000 	add	x0, x0, #0xcb0
    567c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5680:	a90573fb 	stp	x27, x28, [sp, #80]
    5684:	97fff85f 	bl	3800 <fwp_trap>
    5688:	90000020 	adrp	x0, 9000 <__divti3+0x10>
    568c:	91324000 	add	x0, x0, #0xc90
    5690:	a9046bf9 	stp	x25, x26, [sp, #64]
    5694:	a90573fb 	stp	x27, x28, [sp, #80]
    5698:	97fff85a 	bl	3800 <fwp_trap>
    569c:	aa1303e0 	mov	x0, x19
    56a0:	97fff65d 	bl	3014 <fwp_tape_unlink_scope>
    56a4:	f9401260 	ldr	x0, [x19, #32]
    56a8:	b4000040 	cbz	x0, 56b0 <fwp_p_ad_push+0x250>
    56ac:	97fffb49 	bl	43d0 <ad_raw_free.part.0>
    56b0:	f9401a60 	ldr	x0, [x19, #48]
    56b4:	b4000040 	cbz	x0, 56bc <fwp_p_ad_push+0x25c>
    56b8:	97fffb46 	bl	43d0 <ad_raw_free.part.0>
    56bc:	f9402260 	ldr	x0, [x19, #64]
    56c0:	b4000040 	cbz	x0, 56c8 <fwp_p_ad_push+0x268>
    56c4:	97fffb43 	bl	43d0 <ad_raw_free.part.0>
    56c8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    56cc:	f947e821 	ldr	x1, [x1, #4048]
    56d0:	f9000e7f 	str	xzr, [x19, #24]
    56d4:	4f000400 	movi	v0.4s, #0x0
    56d8:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    56dc:	d2800262 	mov	x2, #0x13                  	// #19
    56e0:	f9400023 	ldr	x3, [x1]
    56e4:	b900067f 	str	wzr, [x19, #4]
    56e8:	d2800021 	mov	x1, #0x1                   	// #1
    56ec:	90000020 	adrp	x0, 9000 <__divti3+0x10>
    56f0:	911c6000 	add	x0, x0, #0x718
    56f4:	3c808260 	stur	q0, [x19, #8]
    56f8:	ad010260 	stp	q0, q0, [x19, #32]
    56fc:	97fff4a9 	bl	29a0 <fwrite@plt>
    5700:	d2800000 	mov	x0, #0x0                   	// #0
    5704:	97fff4b3 	bl	29d0 <fflush@plt>
    5708:	52800cc0 	mov	w0, #0x66                  	// #102
    570c:	97fff4c1 	bl	2a10 <_Exit@plt>
    5710:	90000020 	adrp	x0, 9000 <__divti3+0x10>
    5714:	91318000 	add	x0, x0, #0xc60
    5718:	a9046bf9 	stp	x25, x26, [sp, #64]
    571c:	a90573fb 	stp	x27, x28, [sp, #80]
    5720:	97fff838 	bl	3800 <fwp_trap>

0000000000005724 <w120>:
    5724:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5728:	9e660003 	fmov	x3, d0
    572c:	aa0003e2 	mov	x2, x0
    5730:	910003fd 	mov	x29, sp
    5734:	fd001fea 	str	d10, [sp, #56]
    5738:	1e60400a 	fmov	d10, d0
    573c:	6d0427e8 	stp	d8, d9, [sp, #64]
    5740:	1e604028 	fmov	d8, d1
    5744:	1e600809 	fmul	d9, d0, d0
    5748:	a90153f3 	stp	x19, x20, [sp, #16]
    574c:	aa0103f4 	mov	x20, x1
    5750:	aa0303e1 	mov	x1, x3
    5754:	aa0003f3 	mov	x19, x0
    5758:	a9025bf5 	stp	x21, x22, [sp, #32]
    575c:	f9001bf7 	str	x23, [sp, #48]
    5760:	97ffff40 	bl	5460 <fwp_p_ad_push>
    5764:	aa0003e5 	mov	x5, x0
    5768:	97fffad7 	bl	42c4 <caf75>
    576c:	9e670000 	fmov	d0, x0
    5770:	97fffad5 	bl	42c4 <caf75>
    5774:	1e693908 	fsub	d8, d8, d9
    5778:	aa1403e2 	mov	x2, x20
    577c:	1e614000 	fneg	d0, d0
    5780:	aa0003e3 	mov	x3, x0
    5784:	aa0503e0 	mov	x0, x5
    5788:	9e660117 	fmov	x23, d8
    578c:	9e660001 	fmov	x1, d0
    5790:	97ffff34 	bl	5460 <fwp_p_ad_push>
    5794:	aa0003f5 	mov	x21, x0
    5798:	97fffacb 	bl	42c4 <caf75>
    579c:	9e670000 	fmov	d0, x0
    57a0:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    57a4:	97fffac8 	bl	42c4 <caf75>
    57a8:	1e614000 	fneg	d0, d0
    57ac:	aa0003e3 	mov	x3, x0
    57b0:	1e6a3929 	fsub	d9, d9, d10
    57b4:	aa1303e0 	mov	x0, x19
    57b8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    57bc:	9e660001 	fmov	x1, d0
    57c0:	9e660136 	fmov	x22, d9
    57c4:	97ffff27 	bl	5460 <fwp_p_ad_push>
    57c8:	1e680908 	fmul	d8, d8, d8
    57cc:	aa0003f4 	mov	x20, x0
    57d0:	aa1703e3 	mov	x3, x23
    57d4:	aa1703e1 	mov	x1, x23
    57d8:	aa1503e2 	mov	x2, x21
    57dc:	aa1503e0 	mov	x0, x21
    57e0:	97ffff20 	bl	5460 <fwp_p_ad_push>
    57e4:	aa0003e2 	mov	x2, x0
    57e8:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    57ec:	9e670020 	fmov	d0, x1
    57f0:	9e660101 	fmov	x1, d8
    57f4:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    57f8:	1e600908 	fmul	d8, d8, d0
    57fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5800:	97ffff18 	bl	5460 <fwp_p_ad_push>
    5804:	1e690929 	fmul	d9, d9, d9
    5808:	aa1603e3 	mov	x3, x22
    580c:	aa1603e1 	mov	x1, x22
    5810:	aa1403e2 	mov	x2, x20
    5814:	aa0003f3 	mov	x19, x0
    5818:	aa1403e0 	mov	x0, x20
    581c:	97ffff11 	bl	5460 <fwp_p_ad_push>
    5820:	aa0003e5 	mov	x5, x0
    5824:	97fffaa8 	bl	42c4 <caf75>
    5828:	aa0003e6 	mov	x6, x0
    582c:	97fffaa6 	bl	42c4 <caf75>
    5830:	1e692908 	fadd	d8, d8, d9
    5834:	aa1303e2 	mov	x2, x19
    5838:	aa0603e1 	mov	x1, x6
    583c:	aa0003e3 	mov	x3, x0
    5840:	aa0503e0 	mov	x0, x5
    5844:	97ffff07 	bl	5460 <fwp_p_ad_push>
    5848:	aa0003e1 	mov	x1, x0
    584c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5850:	9e660100 	fmov	x0, d8
    5854:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5858:	f9401bf7 	ldr	x23, [sp, #48]
    585c:	fd401fea 	ldr	d10, [sp, #56]
    5860:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5864:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5868:	d65f03c0 	ret
    586c:	d503201f 	nop

0000000000005870 <w176.constprop.0>:
    5870:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5874:	910003fd 	mov	x29, sp
    5878:	a9025bf5 	stp	x21, x22, [sp, #32]
    587c:	fd001be8 	str	d8, [sp, #48]
    5880:	f9400015 	ldr	x21, [x0]
    5884:	b40003b5 	cbz	x21, 58f8 <w176.constprop.0+0x88>
    5888:	2f00e408 	movi	d8, #0x0
    588c:	91002016 	add	x22, x0, #0x8
    5890:	a90153f3 	stp	x19, x20, [sp, #16]
    5894:	91004014 	add	x20, x0, #0x10
    5898:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    589c:	d2800013 	mov	x19, #0x0                   	// #0
    58a0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    58a4:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    58a8:	97fffa87 	bl	42c4 <caf75>
    58ac:	aa0003e6 	mov	x6, x0
    58b0:	97fffa85 	bl	42c4 <caf75>
    58b4:	1e602908 	fadd	d8, d8, d0
    58b8:	aa0003e3 	mov	x3, x0
    58bc:	aa0703e2 	mov	x2, x7
    58c0:	aa0503e0 	mov	x0, x5
    58c4:	aa0603e1 	mov	x1, x6
    58c8:	91000a73 	add	x19, x19, #0x2
    58cc:	97fffee5 	bl	5460 <fwp_p_ad_push>
    58d0:	aa0003e5 	mov	x5, x0
    58d4:	eb1302bf 	cmp	x21, x19
    58d8:	54fffe48 	b.hi	58a0 <w176.constprop.0+0x30>  // b.pmore
    58dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    58e0:	9e660100 	fmov	x0, d8
    58e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    58e8:	aa0503e1 	mov	x1, x5
    58ec:	fd401be8 	ldr	d8, [sp, #48]
    58f0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    58f4:	d65f03c0 	ret
    58f8:	2f00e408 	movi	d8, #0x0
    58fc:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    5900:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5904:	aa0503e1 	mov	x1, x5
    5908:	9e660100 	fmov	x0, d8
    590c:	fd401be8 	ldr	d8, [sp, #48]
    5910:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5914:	d65f03c0 	ret
    5918:	d503201f 	nop
    591c:	d503201f 	nop

0000000000005920 <fwp_rc_share>:
    5920:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5924:	91190042 	add	x2, x2, #0x640
    5928:	f949d843 	ldr	x3, [x2, #5040]
    592c:	f949ec41 	ldr	x1, [x2, #5080]
    5930:	cb030000 	sub	x0, x0, x3
    5934:	eb01401f 	cmp	x0, x1, lsl #16
    5938:	540002c2 	b.cs	5990 <fwp_rc_share+0x70>  // b.hs, b.nlast
    593c:	d350fc01 	lsr	x1, x0, #16
    5940:	f949fc44 	ldr	x4, [x2, #5112]
    5944:	8b010821 	add	x1, x1, x1, lsl #2
    5948:	d37df021 	lsl	x1, x1, #3
    594c:	8b010083 	add	x3, x4, x1
    5950:	f9401062 	ldr	x2, [x3, #32]
    5954:	b40001e2 	cbz	x2, 5990 <fwp_rc_share+0x70>
    5958:	38616881 	ldrb	w1, [x4, x1]
    595c:	7100083f 	cmp	w1, #0x2
    5960:	540001a0 	b.eq	5994 <fwp_rc_share+0x74>  // b.none
    5964:	7100043f 	cmp	w1, #0x1
    5968:	54000141 	b.ne	5990 <fwp_rc_share+0x70>  // b.any
    596c:	29430464 	ldp	w4, w1, [x3, #24]
    5970:	92403c00 	and	x0, x0, #0xffff
    5974:	9b047c00 	mul	x0, x0, x4
    5978:	d360fc00 	lsr	x0, x0, #32
    597c:	eb01001f 	cmp	x0, x1
    5980:	54000082 	b.cs	5990 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5984:	8b000042 	add	x2, x2, x0
    5988:	39400040 	ldrb	w0, [x2]
    598c:	350000a0 	cbnz	w0, 59a0 <fwp_rc_share+0x80>
    5990:	d65f03c0 	ret
    5994:	72003c1f 	tst	w0, #0xffff
    5998:	54ffff80 	b.eq	5988 <fwp_rc_share+0x68>  // b.none
    599c:	d65f03c0 	ret
    59a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    59a4:	90000020 	adrp	x0, 9000 <__divti3+0x10>
    59a8:	91334000 	add	x0, x0, #0xcd0
    59ac:	910003fd 	mov	x29, sp
    59b0:	97fff794 	bl	3800 <fwp_trap>

00000000000059b4 <fwp_rc_free_arr>:
    59b4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    59b8:	91190063 	add	x3, x3, #0x640
    59bc:	f949d861 	ldr	x1, [x3, #5040]
    59c0:	f949ec62 	ldr	x2, [x3, #5080]
    59c4:	cb010001 	sub	x1, x0, x1
    59c8:	eb02403f 	cmp	x1, x2, lsl #16
    59cc:	54000342 	b.cs	5a34 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    59d0:	d350fc22 	lsr	x2, x1, #16
    59d4:	f949fc65 	ldr	x5, [x3, #5112]
    59d8:	8b020842 	add	x2, x2, x2, lsl #2
    59dc:	d37df042 	lsl	x2, x2, #3
    59e0:	8b0200a4 	add	x4, x5, x2
    59e4:	f9401083 	ldr	x3, [x4, #32]
    59e8:	b4000263 	cbz	x3, 5a34 <fwp_rc_free_arr+0x80>
    59ec:	386268a2 	ldrb	w2, [x5, x2]
    59f0:	7100085f 	cmp	w2, #0x2
    59f4:	540001c0 	b.eq	5a2c <fwp_rc_free_arr+0x78>  // b.none
    59f8:	7100045f 	cmp	w2, #0x1
    59fc:	540001c1 	b.ne	5a34 <fwp_rc_free_arr+0x80>  // b.any
    5a00:	29430885 	ldp	w5, w2, [x4, #24]
    5a04:	92403c21 	and	x1, x1, #0xffff
    5a08:	9b057c21 	mul	x1, x1, x5
    5a0c:	d360fc21 	lsr	x1, x1, #32
    5a10:	eb02003f 	cmp	x1, x2
    5a14:	54000102 	b.cs	5a34 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a18:	8b010063 	add	x3, x3, x1
    5a1c:	39400061 	ldrb	w1, [x3]
    5a20:	7100043f 	cmp	w1, #0x1
    5a24:	54000081 	b.ne	5a34 <fwp_rc_free_arr+0x80>  // b.any
    5a28:	17fffcae 	b	4ce0 <fwp_mem_free>
    5a2c:	72003c3f 	tst	w1, #0xffff
    5a30:	54ffff60 	b.eq	5a1c <fwp_rc_free_arr+0x68>  // b.none
    5a34:	d65f03c0 	ret
    5a38:	d503201f 	nop
    5a3c:	d503201f 	nop

0000000000005a40 <fwp_rc_dup>:
    5a40:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5a44:	91190042 	add	x2, x2, #0x640
    5a48:	f949d841 	ldr	x1, [x2, #5040]
    5a4c:	f949ec43 	ldr	x3, [x2, #5080]
    5a50:	cb010001 	sub	x1, x0, x1
    5a54:	eb03403f 	cmp	x1, x3, lsl #16
    5a58:	540003c2 	b.cs	5ad0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5a5c:	d350fc20 	lsr	x0, x1, #16
    5a60:	f949fc44 	ldr	x4, [x2, #5112]
    5a64:	8b000800 	add	x0, x0, x0, lsl #2
    5a68:	d37df002 	lsl	x2, x0, #3
    5a6c:	8b020083 	add	x3, x4, x2
    5a70:	f9401060 	ldr	x0, [x3, #32]
    5a74:	b40002e0 	cbz	x0, 5ad0 <fwp_rc_dup+0x90>
    5a78:	38626882 	ldrb	w2, [x4, x2]
    5a7c:	7100085f 	cmp	w2, #0x2
    5a80:	540002a0 	b.eq	5ad4 <fwp_rc_dup+0x94>  // b.none
    5a84:	7100045f 	cmp	w2, #0x1
    5a88:	54000241 	b.ne	5ad0 <fwp_rc_dup+0x90>  // b.any
    5a8c:	29430864 	ldp	w4, w2, [x3, #24]
    5a90:	92403c21 	and	x1, x1, #0xffff
    5a94:	9b047c21 	mul	x1, x1, x4
    5a98:	d360fc21 	lsr	x1, x1, #32
    5a9c:	eb02003f 	cmp	x1, x2
    5aa0:	54000182 	b.cs	5ad0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5aa4:	8b010000 	add	x0, x0, x1
    5aa8:	39400001 	ldrb	w1, [x0]
    5aac:	34000121 	cbz	w1, 5ad0 <fwp_rc_dup+0x90>
    5ab0:	f00000c2 	adrp	x2, 20000 <__data_start>
    5ab4:	91014042 	add	x2, x2, #0x50
    5ab8:	b9415043 	ldr	w3, [x2, #336]
    5abc:	35000123 	cbnz	w3, 5ae0 <fwp_rc_dup+0xa0>
    5ac0:	7103f43f 	cmp	w1, #0xfd
    5ac4:	54000168 	b.hi	5af0 <fwp_rc_dup+0xb0>  // b.pmore
    5ac8:	11000421 	add	w1, w1, #0x1
    5acc:	39000001 	strb	w1, [x0]
    5ad0:	d65f03c0 	ret
    5ad4:	72003c3f 	tst	w1, #0xffff
    5ad8:	54fffe80 	b.eq	5aa8 <fwp_rc_dup+0x68>  // b.none
    5adc:	d65f03c0 	ret
    5ae0:	f940bc43 	ldr	x3, [x2, #376]
    5ae4:	91000463 	add	x3, x3, #0x1
    5ae8:	f900bc43 	str	x3, [x2, #376]
    5aec:	17fffff5 	b	5ac0 <fwp_rc_dup+0x80>
    5af0:	17fffb95 	b	4944 <fwp_rc_wide_dup>

0000000000005af4 <fwp_owned_entry173>:
    5af4:	d10103ff 	sub	sp, sp, #0x40
    5af8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5afc:	f947f442 	ldr	x2, [x2, #4072]
    5b00:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b04:	910083fd 	add	x29, sp, #0x20
    5b08:	a90353f3 	stp	x19, x20, [sp, #48]
    5b0c:	f9400043 	ldr	x3, [x2]
    5b10:	f9000fe3 	str	x3, [sp, #24]
    5b14:	d2800003 	mov	x3, #0x0                   	// #0
    5b18:	a9400c01 	ldp	x1, x3, [x0]
    5b1c:	f9400802 	ldr	x2, [x0, #16]
    5b20:	ab020022 	adds	x2, x1, x2
    5b24:	540006e6 	b.vs	5c00 <fwp_owned_entry173+0x10c>
    5b28:	910023e1 	add	x1, sp, #0x8
    5b2c:	52800000 	mov	w0, #0x0                   	// #0
    5b30:	a9008be3 	stp	x3, x2, [sp, #8]
    5b34:	97fffdec 	bl	52e4 <fwp_data.part.0.constprop.0>
    5b38:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5b3c:	91190063 	add	x3, x3, #0x640
    5b40:	aa0003f3 	mov	x19, x0
    5b44:	f949d861 	ldr	x1, [x3, #5040]
    5b48:	f949ec60 	ldr	x0, [x3, #5080]
    5b4c:	cb010261 	sub	x1, x19, x1
    5b50:	eb00403f 	cmp	x1, x0, lsl #16
    5b54:	54000322 	b.cs	5bb8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5b58:	d350fc22 	lsr	x2, x1, #16
    5b5c:	f949fc63 	ldr	x3, [x3, #5112]
    5b60:	8b020842 	add	x2, x2, x2, lsl #2
    5b64:	d37df042 	lsl	x2, x2, #3
    5b68:	8b020060 	add	x0, x3, x2
    5b6c:	f9401014 	ldr	x20, [x0, #32]
    5b70:	b4000254 	cbz	x20, 5bb8 <fwp_owned_entry173+0xc4>
    5b74:	38626862 	ldrb	w2, [x3, x2]
    5b78:	7100085f 	cmp	w2, #0x2
    5b7c:	54000360 	b.eq	5be8 <fwp_owned_entry173+0xf4>  // b.none
    5b80:	7100045f 	cmp	w2, #0x1
    5b84:	540001a1 	b.ne	5bb8 <fwp_owned_entry173+0xc4>  // b.any
    5b88:	29430002 	ldp	w2, w0, [x0, #24]
    5b8c:	92403c21 	and	x1, x1, #0xffff
    5b90:	9b027c21 	mul	x1, x1, x2
    5b94:	d360fc21 	lsr	x1, x1, #32
    5b98:	eb00003f 	cmp	x1, x0
    5b9c:	540000e2 	b.cs	5bb8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5ba0:	8b010294 	add	x20, x20, x1
    5ba4:	39400280 	ldrb	w0, [x20]
    5ba8:	7103fc1f 	cmp	w0, #0xff
    5bac:	54000240 	b.eq	5bf4 <fwp_owned_entry173+0x100>  // b.none
    5bb0:	52800020 	mov	w0, #0x1                   	// #1
    5bb4:	39000280 	strb	w0, [x20]
    5bb8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5bbc:	f947f400 	ldr	x0, [x0, #4072]
    5bc0:	f9400fe2 	ldr	x2, [sp, #24]
    5bc4:	f9400001 	ldr	x1, [x0]
    5bc8:	eb010042 	subs	x2, x2, x1
    5bcc:	d2800001 	mov	x1, #0x0                   	// #0
    5bd0:	540001a1 	b.ne	5c04 <fwp_owned_entry173+0x110>  // b.any
    5bd4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5bd8:	aa1303e0 	mov	x0, x19
    5bdc:	a94353f3 	ldp	x19, x20, [sp, #48]
    5be0:	910103ff 	add	sp, sp, #0x40
    5be4:	d65f03c0 	ret
    5be8:	72003c3f 	tst	w1, #0xffff
    5bec:	54fffe61 	b.ne	5bb8 <fwp_owned_entry173+0xc4>  // b.any
    5bf0:	17ffffed 	b	5ba4 <fwp_owned_entry173+0xb0>
    5bf4:	aa1403e0 	mov	x0, x20
    5bf8:	97fffb9a 	bl	4a60 <fwp_rc_forget_slot>
    5bfc:	17ffffed 	b	5bb0 <fwp_owned_entry173+0xbc>
    5c00:	97fff3a0 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5c04:	97fff327 	bl	28a0 <__stack_chk_fail@plt>
    5c08:	d503201f 	nop
    5c0c:	d503201f 	nop

0000000000005c10 <e173>:
    5c10:	d10103ff 	sub	sp, sp, #0x40
    5c14:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5c18:	f947f442 	ldr	x2, [x2, #4072]
    5c1c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c20:	910083fd 	add	x29, sp, #0x20
    5c24:	a90353f3 	stp	x19, x20, [sp, #48]
    5c28:	f9400043 	ldr	x3, [x2]
    5c2c:	f9000fe3 	str	x3, [sp, #24]
    5c30:	d2800003 	mov	x3, #0x0                   	// #0
    5c34:	a9400c01 	ldp	x1, x3, [x0]
    5c38:	f9400802 	ldr	x2, [x0, #16]
    5c3c:	ab020022 	adds	x2, x1, x2
    5c40:	54000726 	b.vs	5d24 <e173+0x114>
    5c44:	910023e1 	add	x1, sp, #0x8
    5c48:	52800000 	mov	w0, #0x0                   	// #0
    5c4c:	a9008be3 	stp	x3, x2, [sp, #8]
    5c50:	97fffda5 	bl	52e4 <fwp_data.part.0.constprop.0>
    5c54:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5c58:	91190063 	add	x3, x3, #0x640
    5c5c:	aa0003f3 	mov	x19, x0
    5c60:	f949d861 	ldr	x1, [x3, #5040]
    5c64:	f949ec60 	ldr	x0, [x3, #5080]
    5c68:	cb010261 	sub	x1, x19, x1
    5c6c:	eb00403f 	cmp	x1, x0, lsl #16
    5c70:	54000322 	b.cs	5cd4 <e173+0xc4>  // b.hs, b.nlast
    5c74:	d350fc22 	lsr	x2, x1, #16
    5c78:	f949fc63 	ldr	x3, [x3, #5112]
    5c7c:	8b020842 	add	x2, x2, x2, lsl #2
    5c80:	d37df042 	lsl	x2, x2, #3
    5c84:	8b020060 	add	x0, x3, x2
    5c88:	f9401014 	ldr	x20, [x0, #32]
    5c8c:	b4000254 	cbz	x20, 5cd4 <e173+0xc4>
    5c90:	38626862 	ldrb	w2, [x3, x2]
    5c94:	7100085f 	cmp	w2, #0x2
    5c98:	540003a0 	b.eq	5d0c <e173+0xfc>  // b.none
    5c9c:	7100045f 	cmp	w2, #0x1
    5ca0:	540001a1 	b.ne	5cd4 <e173+0xc4>  // b.any
    5ca4:	29430002 	ldp	w2, w0, [x0, #24]
    5ca8:	92403c21 	and	x1, x1, #0xffff
    5cac:	9b027c21 	mul	x1, x1, x2
    5cb0:	d360fc21 	lsr	x1, x1, #32
    5cb4:	eb00003f 	cmp	x1, x0
    5cb8:	540000e2 	b.cs	5cd4 <e173+0xc4>  // b.hs, b.nlast
    5cbc:	8b010294 	add	x20, x20, x1
    5cc0:	39400280 	ldrb	w0, [x20]
    5cc4:	7103fc1f 	cmp	w0, #0xff
    5cc8:	54000280 	b.eq	5d18 <e173+0x108>  // b.none
    5ccc:	52800020 	mov	w0, #0x1                   	// #1
    5cd0:	39000280 	strb	w0, [x20]
    5cd4:	aa1303e0 	mov	x0, x19
    5cd8:	97ffff12 	bl	5920 <fwp_rc_share>
    5cdc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5ce0:	f947f400 	ldr	x0, [x0, #4072]
    5ce4:	f9400fe2 	ldr	x2, [sp, #24]
    5ce8:	f9400001 	ldr	x1, [x0]
    5cec:	eb010042 	subs	x2, x2, x1
    5cf0:	d2800001 	mov	x1, #0x0                   	// #0
    5cf4:	540001a1 	b.ne	5d28 <e173+0x118>  // b.any
    5cf8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5cfc:	aa1303e0 	mov	x0, x19
    5d00:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d04:	910103ff 	add	sp, sp, #0x40
    5d08:	d65f03c0 	ret
    5d0c:	72003c3f 	tst	w1, #0xffff
    5d10:	54fffe21 	b.ne	5cd4 <e173+0xc4>  // b.any
    5d14:	17ffffeb 	b	5cc0 <e173+0xb0>
    5d18:	aa1403e0 	mov	x0, x20
    5d1c:	97fffb51 	bl	4a60 <fwp_rc_forget_slot>
    5d20:	17ffffeb 	b	5ccc <e173+0xbc>
    5d24:	97fff357 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5d28:	97fff2de 	bl	28a0 <__stack_chk_fail@plt>
    5d2c:	d503201f 	nop

0000000000005d30 <fwp_drop1>:
    5d30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d34:	910003fd 	mov	x29, sp
    5d38:	a90153f3 	stp	x19, x20, [sp, #16]
    5d3c:	f90013f5 	str	x21, [sp, #32]
    5d40:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5d44:	911902b4 	add	x20, x21, #0x640
    5d48:	f949da81 	ldr	x1, [x20, #5040]
    5d4c:	f949ee82 	ldr	x2, [x20, #5080]
    5d50:	cb010001 	sub	x1, x0, x1
    5d54:	eb02403f 	cmp	x1, x2, lsl #16
    5d58:	54000382 	b.cs	5dc8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d5c:	d350fc22 	lsr	x2, x1, #16
    5d60:	f949fe84 	ldr	x4, [x20, #5112]
    5d64:	8b020842 	add	x2, x2, x2, lsl #2
    5d68:	d37df042 	lsl	x2, x2, #3
    5d6c:	8b020083 	add	x3, x4, x2
    5d70:	f9401073 	ldr	x19, [x3, #32]
    5d74:	b40002b3 	cbz	x19, 5dc8 <fwp_drop1+0x98>
    5d78:	38626882 	ldrb	w2, [x4, x2]
    5d7c:	7100085f 	cmp	w2, #0x2
    5d80:	540002c0 	b.eq	5dd8 <fwp_drop1+0xa8>  // b.none
    5d84:	7100045f 	cmp	w2, #0x1
    5d88:	54000201 	b.ne	5dc8 <fwp_drop1+0x98>  // b.any
    5d8c:	29430864 	ldp	w4, w2, [x3, #24]
    5d90:	92403c21 	and	x1, x1, #0xffff
    5d94:	9b047c21 	mul	x1, x1, x4
    5d98:	d360fc21 	lsr	x1, x1, #32
    5d9c:	eb02003f 	cmp	x1, x2
    5da0:	54000142 	b.cs	5dc8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5da4:	8b010273 	add	x19, x19, x1
    5da8:	39400261 	ldrb	w1, [x19]
    5dac:	340000e1 	cbz	w1, 5dc8 <fwp_drop1+0x98>
    5db0:	7100043f 	cmp	w1, #0x1
    5db4:	540001e0 	b.eq	5df0 <fwp_drop1+0xc0>  // b.none
    5db8:	7103fc3f 	cmp	w1, #0xff
    5dbc:	540002e0 	b.eq	5e18 <fwp_drop1+0xe8>  // b.none
    5dc0:	51000421 	sub	w1, w1, #0x1
    5dc4:	39000261 	strb	w1, [x19]
    5dc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dcc:	f94013f5 	ldr	x21, [sp, #32]
    5dd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5dd4:	d65f03c0 	ret
    5dd8:	72003c3f 	tst	w1, #0xffff
    5ddc:	54fffe60 	b.eq	5da8 <fwp_drop1+0x78>  // b.none
    5de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5de4:	f94013f5 	ldr	x21, [sp, #32]
    5de8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5dec:	d65f03c0 	ret
    5df0:	f9400813 	ldr	x19, [x0, #16]
    5df4:	97fffef0 	bl	59b4 <fwp_rc_free_arr>
    5df8:	911902a0 	add	x0, x21, #0x640
    5dfc:	f949d801 	ldr	x1, [x0, #5040]
    5e00:	f949ec00 	ldr	x0, [x0, #5080]
    5e04:	cb010261 	sub	x1, x19, x1
    5e08:	eb00403f 	cmp	x1, x0, lsl #16
    5e0c:	54fffde2 	b.cs	5dc8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e10:	aa1303e0 	mov	x0, x19
    5e14:	17ffffd2 	b	5d5c <fwp_drop1+0x2c>
    5e18:	ca534660 	eor	x0, x19, x19, lsr #17
    5e1c:	911902b5 	add	x21, x21, #0x640
    5e20:	ca402400 	eor	x0, x0, x0, lsr #9
    5e24:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5e28:	f94a2400 	ldr	x0, [x0, #5192]
    5e2c:	b5000080 	cbnz	x0, 5e3c <fwp_drop1+0x10c>
    5e30:	14000010 	b	5e70 <fwp_drop1+0x140>
    5e34:	f9400800 	ldr	x0, [x0, #16]
    5e38:	b40001c0 	cbz	x0, 5e70 <fwp_drop1+0x140>
    5e3c:	f9400001 	ldr	x1, [x0]
    5e40:	eb13003f 	cmp	x1, x19
    5e44:	54ffff81 	b.ne	5e34 <fwp_drop1+0x104>  // b.any
    5e48:	f9400401 	ldr	x1, [x0, #8]
    5e4c:	d1000421 	sub	x1, x1, #0x1
    5e50:	f9000401 	str	x1, [x0, #8]
    5e54:	f103f83f 	cmp	x1, #0xfe
    5e58:	54fffb81 	b.ne	5dc8 <fwp_drop1+0x98>  // b.any
    5e5c:	aa1303e0 	mov	x0, x19
    5e60:	97fffb00 	bl	4a60 <fwp_rc_forget_slot>
    5e64:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e68:	39000260 	strb	w0, [x19]
    5e6c:	17ffffd7 	b	5dc8 <fwp_drop1+0x98>
    5e70:	90000020 	adrp	x0, 9000 <__divti3+0x10>
    5e74:	912f4000 	add	x0, x0, #0xbd0
    5e78:	97fff662 	bl	3800 <fwp_trap>
    5e7c:	d503201f 	nop

0000000000005e80 <fwp_drop0>:
    5e80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e84:	910003fd 	mov	x29, sp
    5e88:	a90153f3 	stp	x19, x20, [sp, #16]
    5e8c:	f90013f5 	str	x21, [sp, #32]
    5e90:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5e94:	911902b4 	add	x20, x21, #0x640
    5e98:	f949da81 	ldr	x1, [x20, #5040]
    5e9c:	f949ee82 	ldr	x2, [x20, #5080]
    5ea0:	cb010001 	sub	x1, x0, x1
    5ea4:	eb02403f 	cmp	x1, x2, lsl #16
    5ea8:	54000382 	b.cs	5f18 <fwp_drop0+0x98>  // b.hs, b.nlast
    5eac:	d350fc22 	lsr	x2, x1, #16
    5eb0:	f949fe84 	ldr	x4, [x20, #5112]
    5eb4:	8b020842 	add	x2, x2, x2, lsl #2
    5eb8:	d37df042 	lsl	x2, x2, #3
    5ebc:	8b020083 	add	x3, x4, x2
    5ec0:	f9401073 	ldr	x19, [x3, #32]
    5ec4:	b40002b3 	cbz	x19, 5f18 <fwp_drop0+0x98>
    5ec8:	38626882 	ldrb	w2, [x4, x2]
    5ecc:	7100085f 	cmp	w2, #0x2
    5ed0:	540002c0 	b.eq	5f28 <fwp_drop0+0xa8>  // b.none
    5ed4:	7100045f 	cmp	w2, #0x1
    5ed8:	54000201 	b.ne	5f18 <fwp_drop0+0x98>  // b.any
    5edc:	29430864 	ldp	w4, w2, [x3, #24]
    5ee0:	92403c21 	and	x1, x1, #0xffff
    5ee4:	9b047c21 	mul	x1, x1, x4
    5ee8:	d360fc21 	lsr	x1, x1, #32
    5eec:	eb02003f 	cmp	x1, x2
    5ef0:	54000142 	b.cs	5f18 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ef4:	8b010273 	add	x19, x19, x1
    5ef8:	39400261 	ldrb	w1, [x19]
    5efc:	340000e1 	cbz	w1, 5f18 <fwp_drop0+0x98>
    5f00:	7100043f 	cmp	w1, #0x1
    5f04:	540001e0 	b.eq	5f40 <fwp_drop0+0xc0>  // b.none
    5f08:	7103fc3f 	cmp	w1, #0xff
    5f0c:	540002e0 	b.eq	5f68 <fwp_drop0+0xe8>  // b.none
    5f10:	51000421 	sub	w1, w1, #0x1
    5f14:	39000261 	strb	w1, [x19]
    5f18:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f1c:	f94013f5 	ldr	x21, [sp, #32]
    5f20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f24:	d65f03c0 	ret
    5f28:	72003c3f 	tst	w1, #0xffff
    5f2c:	54fffe60 	b.eq	5ef8 <fwp_drop0+0x78>  // b.none
    5f30:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f34:	f94013f5 	ldr	x21, [sp, #32]
    5f38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f3c:	d65f03c0 	ret
    5f40:	f9400813 	ldr	x19, [x0, #16]
    5f44:	97fffe9c 	bl	59b4 <fwp_rc_free_arr>
    5f48:	911902a0 	add	x0, x21, #0x640
    5f4c:	f949d801 	ldr	x1, [x0, #5040]
    5f50:	f949ec00 	ldr	x0, [x0, #5080]
    5f54:	cb010261 	sub	x1, x19, x1
    5f58:	eb00403f 	cmp	x1, x0, lsl #16
    5f5c:	54fffde2 	b.cs	5f18 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f60:	aa1303e0 	mov	x0, x19
    5f64:	17ffffd2 	b	5eac <fwp_drop0+0x2c>
    5f68:	ca534660 	eor	x0, x19, x19, lsr #17
    5f6c:	911902b5 	add	x21, x21, #0x640
    5f70:	ca402400 	eor	x0, x0, x0, lsr #9
    5f74:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5f78:	f94a2400 	ldr	x0, [x0, #5192]
    5f7c:	b5000080 	cbnz	x0, 5f8c <fwp_drop0+0x10c>
    5f80:	14000010 	b	5fc0 <fwp_drop0+0x140>
    5f84:	f9400800 	ldr	x0, [x0, #16]
    5f88:	b40001c0 	cbz	x0, 5fc0 <fwp_drop0+0x140>
    5f8c:	f9400001 	ldr	x1, [x0]
    5f90:	eb13003f 	cmp	x1, x19
    5f94:	54ffff81 	b.ne	5f84 <fwp_drop0+0x104>  // b.any
    5f98:	f9400401 	ldr	x1, [x0, #8]
    5f9c:	d1000421 	sub	x1, x1, #0x1
    5fa0:	f9000401 	str	x1, [x0, #8]
    5fa4:	f103f83f 	cmp	x1, #0xfe
    5fa8:	54fffb81 	b.ne	5f18 <fwp_drop0+0x98>  // b.any
    5fac:	aa1303e0 	mov	x0, x19
    5fb0:	97fffaac 	bl	4a60 <fwp_rc_forget_slot>
    5fb4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5fb8:	39000260 	strb	w0, [x19]
    5fbc:	17ffffd7 	b	5f18 <fwp_drop0+0x98>
    5fc0:	90000020 	adrp	x0, 9000 <__divti3+0x10>
    5fc4:	912f4000 	add	x0, x0, #0xbd0
    5fc8:	97fff60e 	bl	3800 <fwp_trap>
    5fcc:	d503201f 	nop

0000000000005fd0 <fwp_closure_drop>:
    5fd0:	900003a5 	adrp	x5, 79000 <fwp_root_context+0xba0>
    5fd4:	911900a4 	add	x4, x5, #0x640
    5fd8:	aa0003e1 	mov	x1, x0
    5fdc:	f949d882 	ldr	x2, [x4, #5040]
    5fe0:	f949ec80 	ldr	x0, [x4, #5080]
    5fe4:	cb020022 	sub	x2, x1, x2
    5fe8:	eb00405f 	cmp	x2, x0, lsl #16
    5fec:	54000662 	b.cs	60b8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5ff0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5ff4:	d350fc43 	lsr	x3, x2, #16
    5ff8:	910003fd 	mov	x29, sp
    5ffc:	8b030863 	add	x3, x3, x3, lsl #2
    6000:	f949fc84 	ldr	x4, [x4, #5112]
    6004:	d37df063 	lsl	x3, x3, #3
    6008:	f9000bf3 	str	x19, [sp, #16]
    600c:	8b030080 	add	x0, x4, x3
    6010:	f9401013 	ldr	x19, [x0, #32]
    6014:	b40002b3 	cbz	x19, 6068 <fwp_closure_drop+0x98>
    6018:	38636883 	ldrb	w3, [x4, x3]
    601c:	7100087f 	cmp	w3, #0x2
    6020:	54000420 	b.eq	60a4 <fwp_closure_drop+0xd4>  // b.none
    6024:	7100047f 	cmp	w3, #0x1
    6028:	54000201 	b.ne	6068 <fwp_closure_drop+0x98>  // b.any
    602c:	29430003 	ldp	w3, w0, [x0, #24]
    6030:	92403c42 	and	x2, x2, #0xffff
    6034:	9b037c42 	mul	x2, x2, x3
    6038:	d360fc42 	lsr	x2, x2, #32
    603c:	eb00005f 	cmp	x2, x0
    6040:	54000142 	b.cs	6068 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6044:	8b020273 	add	x19, x19, x2
    6048:	39400260 	ldrb	w0, [x19]
    604c:	340000e0 	cbz	w0, 6068 <fwp_closure_drop+0x98>
    6050:	7100041f 	cmp	w0, #0x1
    6054:	54000100 	b.eq	6074 <fwp_closure_drop+0xa4>  // b.none
    6058:	7103fc1f 	cmp	w0, #0xff
    605c:	54000300 	b.eq	60bc <fwp_closure_drop+0xec>  // b.none
    6060:	51000400 	sub	w0, w0, #0x1
    6064:	39000260 	strb	w0, [x19]
    6068:	f9400bf3 	ldr	x19, [sp, #16]
    606c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6070:	d65f03c0 	ret
    6074:	d53bd040 	mrs	x0, tpidr_el0
    6078:	91400000 	add	x0, x0, #0x0, lsl #12
    607c:	91004000 	add	x0, x0, #0x10
    6080:	f9400000 	ldr	x0, [x0]
    6084:	b4000080 	cbz	x0, 6094 <fwp_closure_drop+0xc4>
    6088:	f9400bf3 	ldr	x19, [sp, #16]
    608c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6090:	17fff5f5 	b	3864 <fwp_closure_drop_push>
    6094:	f9400bf3 	ldr	x19, [sp, #16]
    6098:	aa0103e0 	mov	x0, x1
    609c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60a0:	17fff660 	b	3a20 <fwp_closure_drop.part.0>
    60a4:	72003c5f 	tst	w2, #0xffff
    60a8:	54fffd00 	b.eq	6048 <fwp_closure_drop+0x78>  // b.none
    60ac:	f9400bf3 	ldr	x19, [sp, #16]
    60b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60b4:	d65f03c0 	ret
    60b8:	d65f03c0 	ret
    60bc:	ca534660 	eor	x0, x19, x19, lsr #17
    60c0:	911900a5 	add	x5, x5, #0x640
    60c4:	ca402400 	eor	x0, x0, x0, lsr #9
    60c8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    60cc:	f94a2400 	ldr	x0, [x0, #5192]
    60d0:	b5000080 	cbnz	x0, 60e0 <fwp_closure_drop+0x110>
    60d4:	14000010 	b	6114 <fwp_closure_drop+0x144>
    60d8:	f9400800 	ldr	x0, [x0, #16]
    60dc:	b40001c0 	cbz	x0, 6114 <fwp_closure_drop+0x144>
    60e0:	f9400001 	ldr	x1, [x0]
    60e4:	eb13003f 	cmp	x1, x19
    60e8:	54ffff81 	b.ne	60d8 <fwp_closure_drop+0x108>  // b.any
    60ec:	f9400401 	ldr	x1, [x0, #8]
    60f0:	d1000421 	sub	x1, x1, #0x1
    60f4:	f9000401 	str	x1, [x0, #8]
    60f8:	f103f83f 	cmp	x1, #0xfe
    60fc:	54fffb61 	b.ne	6068 <fwp_closure_drop+0x98>  // b.any
    6100:	aa1303e0 	mov	x0, x19
    6104:	97fffa57 	bl	4a60 <fwp_rc_forget_slot>
    6108:	12800020 	mov	w0, #0xfffffffe            	// #-2
    610c:	39000260 	strb	w0, [x19]
    6110:	17ffffd6 	b	6068 <fwp_closure_drop+0x98>
    6114:	f0000000 	adrp	x0, 9000 <__divti3+0x10>
    6118:	912f4000 	add	x0, x0, #0xbd0
    611c:	97fff5b9 	bl	3800 <fwp_trap>

0000000000006120 <fwp_owned_tape_release>:
    6120:	b4000940 	cbz	x0, 6248 <fwp_owned_tape_release+0x128>
    6124:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6128:	910003fd 	mov	x29, sp
    612c:	a90153f3 	stp	x19, x20, [sp, #16]
    6130:	aa0003f3 	mov	x19, x0
    6134:	f9400000 	ldr	x0, [x0]
    6138:	b4000060 	cbz	x0, 6144 <fwp_owned_tape_release+0x24>
    613c:	f9400661 	ldr	x1, [x19, #8]
    6140:	f9000401 	str	x1, [x0, #8]
    6144:	f9400661 	ldr	x1, [x19, #8]
    6148:	b4000041 	cbz	x1, 6150 <fwp_owned_tape_release+0x30>
    614c:	f9000020 	str	x0, [x1]
    6150:	f9400a60 	ldr	x0, [x19, #16]
    6154:	f9403401 	ldr	x1, [x0, #104]
    6158:	b40005c1 	cbz	x1, 6210 <fwp_owned_tape_release+0xf0>
    615c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6160:	eb00005f 	cmp	x2, x0
    6164:	540002ed 	b.le	61c0 <fwp_owned_tape_release+0xa0>
    6168:	d2800014 	mov	x20, #0x0                   	// #0
    616c:	f90013f5 	str	x21, [sp, #32]
    6170:	d2800015 	mov	x21, #0x0                   	// #0
    6174:	d503201f 	nop
    6178:	f9402260 	ldr	x0, [x19, #64]
    617c:	910006b5 	add	x21, x21, #0x1
    6180:	f8746800 	ldr	x0, [x0, x20]
    6184:	d63f0020 	blr	x1
    6188:	f9402260 	ldr	x0, [x19, #64]
    618c:	f9400a61 	ldr	x1, [x19, #16]
    6190:	8b140000 	add	x0, x0, x20
    6194:	91004294 	add	x20, x20, #0x10
    6198:	f9400400 	ldr	x0, [x0, #8]
    619c:	f9403421 	ldr	x1, [x1, #104]
    61a0:	d63f0020 	blr	x1
    61a4:	a9450261 	ldp	x1, x0, [x19, #80]
    61a8:	cb010000 	sub	x0, x0, x1
    61ac:	eb15001f 	cmp	x0, x21
    61b0:	f9400a60 	ldr	x0, [x19, #16]
    61b4:	f9403401 	ldr	x1, [x0, #104]
    61b8:	54fffe0c 	b.gt	6178 <fwp_owned_tape_release+0x58>
    61bc:	f94013f5 	ldr	x21, [sp, #32]
    61c0:	f9403663 	ldr	x3, [x19, #104]
    61c4:	f9401262 	ldr	x2, [x19, #32]
    61c8:	f100007f 	cmp	x3, #0x0
    61cc:	540001ed 	b.le	6208 <fwp_owned_tape_release+0xe8>
    61d0:	d2800014 	mov	x20, #0x0                   	// #0
    61d4:	d503201f 	nop
    61d8:	f9402660 	ldr	x0, [x19, #72]
    61dc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    61e0:	eb02001f 	cmp	x0, x2
    61e4:	540000c0 	b.eq	61fc <fwp_owned_tape_release+0xdc>  // b.none
    61e8:	d63f0020 	blr	x1
    61ec:	f9400a60 	ldr	x0, [x19, #16]
    61f0:	f9401262 	ldr	x2, [x19, #32]
    61f4:	f9403663 	ldr	x3, [x19, #104]
    61f8:	f9403401 	ldr	x1, [x0, #104]
    61fc:	91000694 	add	x20, x20, #0x1
    6200:	eb14007f 	cmp	x3, x20
    6204:	54fffeac 	b.gt	61d8 <fwp_owned_tape_release+0xb8>
    6208:	aa0203e0 	mov	x0, x2
    620c:	d63f0020 	blr	x1
    6210:	f9401660 	ldr	x0, [x19, #40]
    6214:	97ffff6f 	bl	5fd0 <fwp_closure_drop>
    6218:	f9401a60 	ldr	x0, [x19, #48]
    621c:	97ffff6d 	bl	5fd0 <fwp_closure_drop>
    6220:	f9401e60 	ldr	x0, [x19, #56]
    6224:	97ffff6b 	bl	5fd0 <fwp_closure_drop>
    6228:	f9402260 	ldr	x0, [x19, #64]
    622c:	97fffaad 	bl	4ce0 <fwp_mem_free>
    6230:	f9402660 	ldr	x0, [x19, #72]
    6234:	97fffaab 	bl	4ce0 <fwp_mem_free>
    6238:	aa1303e0 	mov	x0, x19
    623c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6240:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6244:	17fffaa7 	b	4ce0 <fwp_mem_free>
    6248:	d65f03c0 	ret
    624c:	d503201f 	nop

0000000000006250 <fwp_tape_finish>:
    6250:	d10203ff 	sub	sp, sp, #0x80
    6254:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6258:	f947f421 	ldr	x1, [x1, #4072]
    625c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6260:	910103fd 	add	x29, sp, #0x40
    6264:	a9065bf5 	stp	x21, x22, [sp, #96]
    6268:	a90763f7 	stp	x23, x24, [sp, #112]
    626c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6270:	910142f6 	add	x22, x23, #0x50
    6274:	f9400022 	ldr	x2, [x1]
    6278:	f9001fe2 	str	x2, [sp, #56]
    627c:	d2800002 	mov	x2, #0x0                   	// #0
    6280:	910402c0 	add	x0, x22, #0x100
    6284:	97fff874 	bl	4454 <fwp_tape_buffers_dispose>
    6288:	f9009edf 	str	xzr, [x22, #312]
    628c:	f9406ec0 	ldr	x0, [x22, #216]
    6290:	f100001f 	cmp	x0, #0x0
    6294:	5400034d 	b.le	62fc <fwp_tape_finish+0xac>
    6298:	910003f8 	mov	x24, sp
    629c:	d2800015 	mov	x21, #0x0                   	// #0
    62a0:	a90553f3 	stp	x19, x20, [sp, #80]
    62a4:	d2800014 	mov	x20, #0x0                   	// #0
    62a8:	91000694 	add	x20, x20, #0x1
    62ac:	f94046d3 	ldr	x19, [x22, #136]
    62b0:	8b150273 	add	x19, x19, x21
    62b4:	9101a2b5 	add	x21, x21, #0x68
    62b8:	aa1303e0 	mov	x0, x19
    62bc:	97fff356 	bl	3014 <fwp_tape_unlink_scope>
    62c0:	aa1803e0 	mov	x0, x24
    62c4:	a9440663 	ldp	x3, x1, [x19, #64]
    62c8:	f9001be1 	str	x1, [sp, #48]
    62cc:	f9400e62 	ldr	x2, [x19, #24]
    62d0:	a9020be3 	stp	x3, x2, [sp, #32]
    62d4:	ad410261 	ldp	q1, q0, [x19, #32]
    62d8:	ad0003e1 	stp	q1, q0, [sp]
    62dc:	97fff85e 	bl	4454 <fwp_tape_buffers_dispose>
    62e0:	f9403260 	ldr	x0, [x19, #96]
    62e4:	97ffff8f 	bl	6120 <fwp_owned_tape_release>
    62e8:	f900327f 	str	xzr, [x19, #96]
    62ec:	f9406ec0 	ldr	x0, [x22, #216]
    62f0:	eb14001f 	cmp	x0, x20
    62f4:	54fffdac 	b.gt	62a8 <fwp_tape_finish+0x58>
    62f8:	a94553f3 	ldp	x19, x20, [sp, #80]
    62fc:	910142e0 	add	x0, x23, #0x50
    6300:	f9404400 	ldr	x0, [x0, #136]
    6304:	b4000040 	cbz	x0, 630c <fwp_tape_finish+0xbc>
    6308:	97fff832 	bl	43d0 <ad_raw_free.part.0>
    630c:	910142f7 	add	x23, x23, #0x50
    6310:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6314:	f947f400 	ldr	x0, [x0, #4072]
    6318:	f90046ff 	str	xzr, [x23, #136]
    631c:	f9006eff 	str	xzr, [x23, #216]
    6320:	f900a2ff 	str	xzr, [x23, #320]
    6324:	f900c2ff 	str	xzr, [x23, #384]
    6328:	f9401fe2 	ldr	x2, [sp, #56]
    632c:	f9400001 	ldr	x1, [x0]
    6330:	eb010042 	subs	x2, x2, x1
    6334:	d2800001 	mov	x1, #0x0                   	// #0
    6338:	540000c1 	b.ne	6350 <fwp_tape_finish+0x100>  // b.any
    633c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6340:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6344:	a94763f7 	ldp	x23, x24, [sp, #112]
    6348:	910203ff 	add	sp, sp, #0x80
    634c:	d65f03c0 	ret
    6350:	a90553f3 	stp	x19, x20, [sp, #80]
    6354:	97fff153 	bl	28a0 <__stack_chk_fail@plt>
    6358:	d503201f 	nop
    635c:	d503201f 	nop

0000000000006360 <fwp_tape_scope_release>:
    6360:	d10243ff 	sub	sp, sp, #0x90
    6364:	a9047bfd 	stp	x29, x30, [sp, #64]
    6368:	910103fd 	add	x29, sp, #0x40
    636c:	a90553f3 	stp	x19, x20, [sp, #80]
    6370:	aa0003f4 	mov	x20, x0
    6374:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6378:	f947f400 	ldr	x0, [x0, #4072]
    637c:	b9400285 	ldr	w5, [x20]
    6380:	f9400001 	ldr	x1, [x0]
    6384:	f9001fe1 	str	x1, [sp, #56]
    6388:	d2800001 	mov	x1, #0x0                   	// #0
    638c:	37f806c5 	tbnz	w5, #31, 6464 <fwp_tape_scope_release+0x104>
    6390:	a90763f7 	stp	x23, x24, [sp, #112]
    6394:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6398:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    639c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    63a0:	d00000d3 	adrp	x19, 20000 <__data_start>
    63a4:	910003f7 	mov	x23, sp
    63a8:	91014273 	add	x19, x19, #0x50
    63ac:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    63b0:	a9065bf5 	stp	x21, x22, [sp, #96]
    63b4:	52800d16 	mov	w22, #0x68                  	// #104
    63b8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    63bc:	f90043f9 	str	x25, [sp, #128]
    63c0:	14000006 	b	63d8 <fwp_tape_scope_release+0x78>
    63c4:	97fff824 	bl	4454 <fwp_tape_buffers_dispose>
    63c8:	aa1903e0 	mov	x0, x25
    63cc:	97ffff55 	bl	6120 <fwp_owned_tape_release>
    63d0:	b9400285 	ldr	w5, [x20]
    63d4:	37f80425 	tbnz	w5, #31, 6458 <fwp_tape_scope_release+0xf8>
    63d8:	f9404666 	ldr	x6, [x19, #136]
    63dc:	9b367ca5 	smull	x5, w5, w22
    63e0:	8b0500c0 	add	x0, x6, x5
    63e4:	97fff30c 	bl	3014 <fwp_tape_unlink_scope>
    63e8:	ad410001 	ldp	q1, q0, [x0, #32]
    63ec:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    63f0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    63f4:	f9400c03 	ldr	x3, [x0, #24]
    63f8:	ad0003e1 	stp	q1, q0, [sp]
    63fc:	b86568c1 	ldr	w1, [x6, x5]
    6400:	a9440804 	ldp	x4, x2, [x0, #64]
    6404:	b900041f 	str	wzr, [x0, #4]
    6408:	f9403019 	ldr	x25, [x0, #96]
    640c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6410:	f9000c1f 	str	xzr, [x0, #24]
    6414:	a9020fe4 	stp	x4, x3, [sp, #32]
    6418:	f9001be2 	str	x2, [sp, #48]
    641c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6420:	f900301f 	str	xzr, [x0, #96]
    6424:	6b15003f 	cmp	w1, w21
    6428:	540000e8 	b.hi	6444 <fwp_tape_scope_release+0xe4>  // b.pmore
    642c:	9343fca5 	asr	x5, x5, #3
    6430:	f940c260 	ldr	x0, [x19, #384]
    6434:	9b187ca5 	mul	x5, x5, x24
    6438:	eb0000bf 	cmp	x5, x0
    643c:	5400004a 	b.ge	6444 <fwp_tape_scope_release+0xe4>  // b.tcont
    6440:	f900c265 	str	x5, [x19, #384]
    6444:	aa1703e0 	mov	x0, x23
    6448:	b5fffbf9 	cbnz	x25, 63c4 <fwp_tape_scope_release+0x64>
    644c:	97fff84a 	bl	4574 <fwp_tape_buffers_release>
    6450:	b9400285 	ldr	w5, [x20]
    6454:	36fffc25 	tbz	w5, #31, 63d8 <fwp_tape_scope_release+0x78>
    6458:	a9465bf5 	ldp	x21, x22, [sp, #96]
    645c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6460:	f94043f9 	ldr	x25, [sp, #128]
    6464:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6468:	f947f400 	ldr	x0, [x0, #4072]
    646c:	f9401fe2 	ldr	x2, [sp, #56]
    6470:	f9400001 	ldr	x1, [x0]
    6474:	eb010042 	subs	x2, x2, x1
    6478:	d2800001 	mov	x1, #0x0                   	// #0
    647c:	540000a1 	b.ne	6490 <fwp_tape_scope_release+0x130>  // b.any
    6480:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6484:	a94553f3 	ldp	x19, x20, [sp, #80]
    6488:	910243ff 	add	sp, sp, #0x90
    648c:	d65f03c0 	ret
    6490:	a9065bf5 	stp	x21, x22, [sp, #96]
    6494:	a90763f7 	stp	x23, x24, [sp, #112]
    6498:	f90043f9 	str	x25, [sp, #128]
    649c:	97fff101 	bl	28a0 <__stack_chk_fail@plt>

00000000000064a0 <fwp_drop4>:
    64a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    64a4:	910003fd 	mov	x29, sp
    64a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    64ac:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xba0>
    64b0:	911902d5 	add	x21, x22, #0x640
    64b4:	a90153f3 	stp	x19, x20, [sp, #16]
    64b8:	aa0003f3 	mov	x19, x0
    64bc:	f949daa1 	ldr	x1, [x21, #5040]
    64c0:	f949eea0 	ldr	x0, [x21, #5080]
    64c4:	cb010261 	sub	x1, x19, x1
    64c8:	eb00403f 	cmp	x1, x0, lsl #16
    64cc:	54000382 	b.cs	653c <fwp_drop4+0x9c>  // b.hs, b.nlast
    64d0:	d350fc22 	lsr	x2, x1, #16
    64d4:	f949fea3 	ldr	x3, [x21, #5112]
    64d8:	8b020842 	add	x2, x2, x2, lsl #2
    64dc:	d37df042 	lsl	x2, x2, #3
    64e0:	8b020060 	add	x0, x3, x2
    64e4:	f9401014 	ldr	x20, [x0, #32]
    64e8:	b40002b4 	cbz	x20, 653c <fwp_drop4+0x9c>
    64ec:	38626862 	ldrb	w2, [x3, x2]
    64f0:	7100085f 	cmp	w2, #0x2
    64f4:	540002c0 	b.eq	654c <fwp_drop4+0xac>  // b.none
    64f8:	7100045f 	cmp	w2, #0x1
    64fc:	54000201 	b.ne	653c <fwp_drop4+0x9c>  // b.any
    6500:	29430002 	ldp	w2, w0, [x0, #24]
    6504:	92403c21 	and	x1, x1, #0xffff
    6508:	9b027c21 	mul	x1, x1, x2
    650c:	d360fc21 	lsr	x1, x1, #32
    6510:	eb00003f 	cmp	x1, x0
    6514:	54000142 	b.cs	653c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6518:	8b010294 	add	x20, x20, x1
    651c:	39400280 	ldrb	w0, [x20]
    6520:	340000e0 	cbz	w0, 653c <fwp_drop4+0x9c>
    6524:	7100041f 	cmp	w0, #0x1
    6528:	540001e0 	b.eq	6564 <fwp_drop4+0xc4>  // b.none
    652c:	7103fc1f 	cmp	w0, #0xff
    6530:	540007c0 	b.eq	6628 <fwp_drop4+0x188>  // b.none
    6534:	51000400 	sub	w0, w0, #0x1
    6538:	39000280 	strb	w0, [x20]
    653c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6540:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6544:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6548:	d65f03c0 	ret
    654c:	72003c3f 	tst	w1, #0xffff
    6550:	54fffe60 	b.eq	651c <fwp_drop4+0x7c>  // b.none
    6554:	a94153f3 	ldp	x19, x20, [sp, #16]
    6558:	a9425bf5 	ldp	x21, x22, [sp, #32]
    655c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6560:	d65f03c0 	ret
    6564:	911902c2 	add	x2, x22, #0x640
    6568:	f9400660 	ldr	x0, [x19, #8]
    656c:	f949d841 	ldr	x1, [x2, #5040]
    6570:	f949ec42 	ldr	x2, [x2, #5080]
    6574:	cb010001 	sub	x1, x0, x1
    6578:	eb02403f 	cmp	x1, x2, lsl #16
    657c:	54000362 	b.cs	65e8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6580:	d350fc22 	lsr	x2, x1, #16
    6584:	8b020842 	add	x2, x2, x2, lsl #2
    6588:	d37df042 	lsl	x2, x2, #3
    658c:	8b020064 	add	x4, x3, x2
    6590:	f9401094 	ldr	x20, [x4, #32]
    6594:	b40002b4 	cbz	x20, 65e8 <fwp_drop4+0x148>
    6598:	38626862 	ldrb	w2, [x3, x2]
    659c:	7100085f 	cmp	w2, #0x2
    65a0:	540003e0 	b.eq	661c <fwp_drop4+0x17c>  // b.none
    65a4:	7100045f 	cmp	w2, #0x1
    65a8:	54000201 	b.ne	65e8 <fwp_drop4+0x148>  // b.any
    65ac:	29430883 	ldp	w3, w2, [x4, #24]
    65b0:	92403c21 	and	x1, x1, #0xffff
    65b4:	9b037c21 	mul	x1, x1, x3
    65b8:	d360fc21 	lsr	x1, x1, #32
    65bc:	eb02003f 	cmp	x1, x2
    65c0:	54000142 	b.cs	65e8 <fwp_drop4+0x148>  // b.hs, b.nlast
    65c4:	8b010294 	add	x20, x20, x1
    65c8:	39400281 	ldrb	w1, [x20]
    65cc:	340000e1 	cbz	w1, 65e8 <fwp_drop4+0x148>
    65d0:	7100043f 	cmp	w1, #0x1
    65d4:	54000200 	b.eq	6614 <fwp_drop4+0x174>  // b.none
    65d8:	7103fc3f 	cmp	w1, #0xff
    65dc:	54000580 	b.eq	668c <fwp_drop4+0x1ec>  // b.none
    65e0:	51000421 	sub	w1, w1, #0x1
    65e4:	39000281 	strb	w1, [x20]
    65e8:	f9400a74 	ldr	x20, [x19, #16]
    65ec:	aa1303e0 	mov	x0, x19
    65f0:	97fffcf1 	bl	59b4 <fwp_rc_free_arr>
    65f4:	911902c0 	add	x0, x22, #0x640
    65f8:	f949d801 	ldr	x1, [x0, #5040]
    65fc:	f949ec00 	ldr	x0, [x0, #5080]
    6600:	cb010281 	sub	x1, x20, x1
    6604:	eb00403f 	cmp	x1, x0, lsl #16
    6608:	54fff9a2 	b.cs	653c <fwp_drop4+0x9c>  // b.hs, b.nlast
    660c:	aa1403f3 	mov	x19, x20
    6610:	17ffffb0 	b	64d0 <fwp_drop4+0x30>
    6614:	97fffce8 	bl	59b4 <fwp_rc_free_arr>
    6618:	17fffff4 	b	65e8 <fwp_drop4+0x148>
    661c:	72003c3f 	tst	w1, #0xffff
    6620:	54fffe41 	b.ne	65e8 <fwp_drop4+0x148>  // b.any
    6624:	17ffffe9 	b	65c8 <fwp_drop4+0x128>
    6628:	ca544681 	eor	x1, x20, x20, lsr #17
    662c:	911902c0 	add	x0, x22, #0x640
    6630:	ca412421 	eor	x1, x1, x1, lsr #9
    6634:	8b210c01 	add	x1, x0, w1, uxtb #3
    6638:	f94a2420 	ldr	x0, [x1, #5192]
    663c:	b5000080 	cbnz	x0, 664c <fwp_drop4+0x1ac>
    6640:	14000010 	b	6680 <fwp_drop4+0x1e0>
    6644:	f9400800 	ldr	x0, [x0, #16]
    6648:	b40001c0 	cbz	x0, 6680 <fwp_drop4+0x1e0>
    664c:	f9400001 	ldr	x1, [x0]
    6650:	eb14003f 	cmp	x1, x20
    6654:	54ffff81 	b.ne	6644 <fwp_drop4+0x1a4>  // b.any
    6658:	f9400401 	ldr	x1, [x0, #8]
    665c:	d1000421 	sub	x1, x1, #0x1
    6660:	f9000401 	str	x1, [x0, #8]
    6664:	f103f83f 	cmp	x1, #0xfe
    6668:	54fff6a1 	b.ne	653c <fwp_drop4+0x9c>  // b.any
    666c:	aa1403e0 	mov	x0, x20
    6670:	97fff8fc 	bl	4a60 <fwp_rc_forget_slot>
    6674:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6678:	39000280 	strb	w0, [x20]
    667c:	17ffffb0 	b	653c <fwp_drop4+0x9c>
    6680:	f0000000 	adrp	x0, 9000 <__divti3+0x10>
    6684:	912f4000 	add	x0, x0, #0xbd0
    6688:	97fff45e 	bl	3800 <fwp_trap>
    668c:	ca544680 	eor	x0, x20, x20, lsr #17
    6690:	911902c1 	add	x1, x22, #0x640
    6694:	ca402400 	eor	x0, x0, x0, lsr #9
    6698:	8b200c20 	add	x0, x1, w0, uxtb #3
    669c:	f94a2400 	ldr	x0, [x0, #5192]
    66a0:	b5000080 	cbnz	x0, 66b0 <fwp_drop4+0x210>
    66a4:	17fffff7 	b	6680 <fwp_drop4+0x1e0>
    66a8:	f9400800 	ldr	x0, [x0, #16]
    66ac:	b4fffea0 	cbz	x0, 6680 <fwp_drop4+0x1e0>
    66b0:	f9400001 	ldr	x1, [x0]
    66b4:	eb14003f 	cmp	x1, x20
    66b8:	54ffff81 	b.ne	66a8 <fwp_drop4+0x208>  // b.any
    66bc:	f9400401 	ldr	x1, [x0, #8]
    66c0:	d1000421 	sub	x1, x1, #0x1
    66c4:	f9000401 	str	x1, [x0, #8]
    66c8:	f103f83f 	cmp	x1, #0xfe
    66cc:	54fff8e1 	b.ne	65e8 <fwp_drop4+0x148>  // b.any
    66d0:	aa1403e0 	mov	x0, x20
    66d4:	97fff8e3 	bl	4a60 <fwp_rc_forget_slot>
    66d8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    66dc:	39000280 	strb	w0, [x20]
    66e0:	17ffffc2 	b	65e8 <fwp_drop4+0x148>

00000000000066e4 <fwp_arg_drop37>:
    66e4:	7100003f 	cmp	w1, #0x0
    66e8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    66ec:	54000041 	b.ne	66f4 <fwp_arg_drop37+0x10>  // b.any
    66f0:	d65f03c0 	ret
    66f4:	f9400000 	ldr	x0, [x0]
    66f8:	17ffff6a 	b	64a0 <fwp_drop4>
    66fc:	d503201f 	nop

0000000000006700 <fwp_task_dispose>:
    6700:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6704:	910003fd 	mov	x29, sp
    6708:	f9000bf3 	str	x19, [sp, #16]
    670c:	aa0003f3 	mov	x19, x0
    6710:	39414000 	ldrb	w0, [x0, #80]
    6714:	36000720 	tbz	w0, #0, 67f8 <fwp_task_dispose+0xf8>
    6718:	f9400a60 	ldr	x0, [x19, #16]
    671c:	b50006e0 	cbnz	x0, 67f8 <fwp_task_dispose+0xf8>
    6720:	a9478660 	ldp	x0, x1, [x19, #120]
    6724:	39014e7f 	strb	wzr, [x19, #83]
    6728:	f9003e7f 	str	xzr, [x19, #120]
    672c:	f100003f 	cmp	x1, #0x0
    6730:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6734:	54000040 	b.eq	673c <fwp_task_dispose+0x3c>  // b.none
    6738:	d63f0020 	blr	x1
    673c:	f9405660 	ldr	x0, [x19, #168]
    6740:	97fff968 	bl	4ce0 <fwp_mem_free>
    6744:	f900567f 	str	xzr, [x19, #168]
    6748:	b9405e60 	ldr	w0, [x19, #92]
    674c:	7100041f 	cmp	w0, #0x1
    6750:	54000420 	b.eq	67d4 <fwp_task_dispose+0xd4>  // b.none
    6754:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    6758:	91190042 	add	x2, x2, #0x640
    675c:	f949d840 	ldr	x0, [x2, #5040]
    6760:	f949ec41 	ldr	x1, [x2, #5080]
    6764:	cb000260 	sub	x0, x19, x0
    6768:	eb01401f 	cmp	x0, x1, lsl #16
    676c:	540002e2 	b.cs	67c8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6770:	d350fc01 	lsr	x1, x0, #16
    6774:	f949fc44 	ldr	x4, [x2, #5112]
    6778:	8b010821 	add	x1, x1, x1, lsl #2
    677c:	d37df021 	lsl	x1, x1, #3
    6780:	8b010083 	add	x3, x4, x1
    6784:	f9401062 	ldr	x2, [x3, #32]
    6788:	b4000202 	cbz	x2, 67c8 <fwp_task_dispose+0xc8>
    678c:	38616881 	ldrb	w1, [x4, x1]
    6790:	7100083f 	cmp	w1, #0x2
    6794:	54000280 	b.eq	67e4 <fwp_task_dispose+0xe4>  // b.none
    6798:	7100043f 	cmp	w1, #0x1
    679c:	54000161 	b.ne	67c8 <fwp_task_dispose+0xc8>  // b.any
    67a0:	29430464 	ldp	w4, w1, [x3, #24]
    67a4:	92403c00 	and	x0, x0, #0xffff
    67a8:	9b047c00 	mul	x0, x0, x4
    67ac:	d360fc00 	lsr	x0, x0, #32
    67b0:	eb01001f 	cmp	x0, x1
    67b4:	540000a2 	b.cs	67c8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    67b8:	8b000042 	add	x2, x2, x0
    67bc:	39400040 	ldrb	w0, [x2]
    67c0:	7100041f 	cmp	w0, #0x1
    67c4:	54000080 	b.eq	67d4 <fwp_task_dispose+0xd4>  // b.none
    67c8:	f9400bf3 	ldr	x19, [sp, #16]
    67cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67d0:	d65f03c0 	ret
    67d4:	aa1303e0 	mov	x0, x19
    67d8:	f9400bf3 	ldr	x19, [sp, #16]
    67dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67e0:	17fff940 	b	4ce0 <fwp_mem_free>
    67e4:	72003c1f 	tst	w0, #0xffff
    67e8:	54fffea0 	b.eq	67bc <fwp_task_dispose+0xbc>  // b.none
    67ec:	f9400bf3 	ldr	x19, [sp, #16]
    67f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67f4:	d65f03c0 	ret
    67f8:	97fff03e 	bl	28f0 <abort@plt>
    67fc:	d503201f 	nop

0000000000006800 <fwp_free_zombie>:
    6800:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6804:	910003fd 	mov	x29, sp
    6808:	a90153f3 	stp	x19, x20, [sp, #16]
    680c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6810:	91014281 	add	x1, x20, #0x50
    6814:	f940c433 	ldr	x19, [x1, #392]
    6818:	b4000333 	cbz	x19, 687c <fwp_free_zombie+0x7c>
    681c:	f9404c20 	ldr	x0, [x1, #152]
    6820:	eb00027f 	cmp	x19, x0
    6824:	540002c0 	b.eq	687c <fwp_free_zombie+0x7c>  // b.none
    6828:	b9419022 	ldr	w2, [x1, #400]
    682c:	f9400a60 	ldr	x0, [x19, #16]
    6830:	7100fc5f 	cmp	w2, #0x3f
    6834:	5400078c 	b.gt	6924 <fwp_free_zombie+0x124>
    6838:	91068023 	add	x3, x1, #0x1a0
    683c:	11000444 	add	w4, w2, #0x1
    6840:	b9019024 	str	w4, [x1, #400]
    6844:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6848:	f822d860 	str	x0, [x3, w2, sxtw #3]
    684c:	a9530261 	ldp	x1, x0, [x19, #304]
    6850:	b4000741 	cbz	x1, 6938 <fwp_free_zombie+0x138>
    6854:	f9009c20 	str	x0, [x1, #312]
    6858:	b4000040 	cbz	x0, 6860 <fwp_free_zombie+0x60>
    685c:	f9009801 	str	x1, [x0, #304]
    6860:	91014294 	add	x20, x20, #0x50
    6864:	b9405e60 	ldr	w0, [x19, #92]
    6868:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    686c:	f900c69f 	str	xzr, [x20, #392]
    6870:	34000140 	cbz	w0, 6898 <fwp_free_zombie+0x98>
    6874:	7100041f 	cmp	w0, #0x1
    6878:	54000080 	b.eq	6888 <fwp_free_zombie+0x88>  // b.none
    687c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6880:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6884:	d65f03c0 	ret
    6888:	aa1303e0 	mov	x0, x19
    688c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6890:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6894:	17ffff9b 	b	6700 <fwp_task_dispose>
    6898:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xba0>
    689c:	91190082 	add	x2, x4, #0x640
    68a0:	f949d841 	ldr	x1, [x2, #5040]
    68a4:	f949ec40 	ldr	x0, [x2, #5080]
    68a8:	cb010261 	sub	x1, x19, x1
    68ac:	eb00403f 	cmp	x1, x0, lsl #16
    68b0:	54fffe62 	b.cs	687c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    68b4:	d350fc20 	lsr	x0, x1, #16
    68b8:	f949fc43 	ldr	x3, [x2, #5112]
    68bc:	8b000800 	add	x0, x0, x0, lsl #2
    68c0:	d37df000 	lsl	x0, x0, #3
    68c4:	8b000062 	add	x2, x3, x0
    68c8:	f9401054 	ldr	x20, [x2, #32]
    68cc:	b4fffd94 	cbz	x20, 687c <fwp_free_zombie+0x7c>
    68d0:	38606860 	ldrb	w0, [x3, x0]
    68d4:	7100081f 	cmp	w0, #0x2
    68d8:	54000360 	b.eq	6944 <fwp_free_zombie+0x144>  // b.none
    68dc:	7100041f 	cmp	w0, #0x1
    68e0:	54fffce1 	b.ne	687c <fwp_free_zombie+0x7c>  // b.any
    68e4:	29430043 	ldp	w3, w0, [x2, #24]
    68e8:	92403c21 	and	x1, x1, #0xffff
    68ec:	9b037c21 	mul	x1, x1, x3
    68f0:	d360fc21 	lsr	x1, x1, #32
    68f4:	eb00003f 	cmp	x1, x0
    68f8:	54fffc22 	b.cs	687c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    68fc:	8b010294 	add	x20, x20, x1
    6900:	39400280 	ldrb	w0, [x20]
    6904:	34fffbc0 	cbz	w0, 687c <fwp_free_zombie+0x7c>
    6908:	7100041f 	cmp	w0, #0x1
    690c:	54fffbe0 	b.eq	6888 <fwp_free_zombie+0x88>  // b.none
    6910:	7103fc1f 	cmp	w0, #0xff
    6914:	540001e0 	b.eq	6950 <fwp_free_zombie+0x150>  // b.none
    6918:	51000400 	sub	w0, w0, #0x1
    691c:	39000280 	strb	w0, [x20]
    6920:	17ffffd7 	b	687c <fwp_free_zombie+0x7c>
    6924:	f9400e61 	ldr	x1, [x19, #24]
    6928:	97fff026 	bl	29c0 <munmap@plt>
    692c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6930:	a9530261 	ldp	x1, x0, [x19, #304]
    6934:	b5fff901 	cbnz	x1, 6854 <fwp_free_zombie+0x54>
    6938:	91014282 	add	x2, x20, #0x50
    693c:	f901d040 	str	x0, [x2, #928]
    6940:	17ffffc6 	b	6858 <fwp_free_zombie+0x58>
    6944:	72003c3f 	tst	w1, #0xffff
    6948:	54fff9a1 	b.ne	687c <fwp_free_zombie+0x7c>  // b.any
    694c:	17ffffed 	b	6900 <fwp_free_zombie+0x100>
    6950:	ca544680 	eor	x0, x20, x20, lsr #17
    6954:	91190084 	add	x4, x4, #0x640
    6958:	ca402400 	eor	x0, x0, x0, lsr #9
    695c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6960:	f94a2400 	ldr	x0, [x0, #5192]
    6964:	b5000080 	cbnz	x0, 6974 <fwp_free_zombie+0x174>
    6968:	14000010 	b	69a8 <fwp_free_zombie+0x1a8>
    696c:	f9400800 	ldr	x0, [x0, #16]
    6970:	b40001c0 	cbz	x0, 69a8 <fwp_free_zombie+0x1a8>
    6974:	f9400001 	ldr	x1, [x0]
    6978:	eb14003f 	cmp	x1, x20
    697c:	54ffff81 	b.ne	696c <fwp_free_zombie+0x16c>  // b.any
    6980:	f9400401 	ldr	x1, [x0, #8]
    6984:	d1000421 	sub	x1, x1, #0x1
    6988:	f9000401 	str	x1, [x0, #8]
    698c:	f103f83f 	cmp	x1, #0xfe
    6990:	54fff761 	b.ne	687c <fwp_free_zombie+0x7c>  // b.any
    6994:	aa1403e0 	mov	x0, x20
    6998:	97fff832 	bl	4a60 <fwp_rc_forget_slot>
    699c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    69a0:	39000280 	strb	w0, [x20]
    69a4:	17ffffb6 	b	687c <fwp_free_zombie+0x7c>
    69a8:	f0000000 	adrp	x0, 9000 <__divti3+0x10>
    69ac:	912f4000 	add	x0, x0, #0xbd0
    69b0:	97fff394 	bl	3800 <fwp_trap>

00000000000069b4 <fwp_block>:
    69b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    69b8:	910003fd 	mov	x29, sp
    69bc:	a90153f3 	stp	x19, x20, [sp, #16]
    69c0:	d00000d3 	adrp	x19, 20000 <__data_start>
    69c4:	91014274 	add	x20, x19, #0x50
    69c8:	f9406682 	ldr	x2, [x20, #200]
    69cc:	b4000622 	cbz	x2, 6a90 <fwp_block+0xdc>
    69d0:	91014261 	add	x1, x19, #0x50
    69d4:	f9408040 	ldr	x0, [x2, #256]
    69d8:	f9006420 	str	x0, [x1, #200]
    69dc:	b4000680 	cbz	x0, 6aac <fwp_block+0xf8>
    69e0:	91014263 	add	x3, x19, #0x50
    69e4:	3901505f 	strb	wzr, [x2, #84]
    69e8:	f9404c64 	ldr	x4, [x3, #152]
    69ec:	eb02009f 	cmp	x4, x2
    69f0:	54000440 	b.eq	6a78 <fwp_block+0xc4>  // b.none
    69f4:	f941d465 	ldr	x5, [x3, #936]
    69f8:	f9004c62 	str	x2, [x3, #152]
    69fc:	f9400441 	ldr	x1, [x2, #8]
    6a00:	f9004885 	str	x5, [x4, #144]
    6a04:	f941d865 	ldr	x5, [x3, #944]
    6a08:	f9004c85 	str	x5, [x4, #152]
    6a0c:	f941dc65 	ldr	x5, [x3, #952]
    6a10:	f9005085 	str	x5, [x4, #160]
    6a14:	f941e065 	ldr	x5, [x3, #960]
    6a18:	f9005485 	str	x5, [x4, #168]
    6a1c:	f941e465 	ldr	x5, [x3, #968]
    6a20:	f9005885 	str	x5, [x4, #176]
    6a24:	f941e865 	ldr	x5, [x3, #976]
    6a28:	f9005c85 	str	x5, [x4, #184]
    6a2c:	f941ec65 	ldr	x5, [x3, #984]
    6a30:	f9006085 	str	x5, [x4, #192]
    6a34:	f9400480 	ldr	x0, [x4, #8]
    6a38:	f9404844 	ldr	x4, [x2, #144]
    6a3c:	f901d464 	str	x4, [x3, #936]
    6a40:	f9404c44 	ldr	x4, [x2, #152]
    6a44:	f901d864 	str	x4, [x3, #944]
    6a48:	f9405044 	ldr	x4, [x2, #160]
    6a4c:	f901dc64 	str	x4, [x3, #952]
    6a50:	f9405444 	ldr	x4, [x2, #168]
    6a54:	f901e064 	str	x4, [x3, #960]
    6a58:	f9405844 	ldr	x4, [x2, #176]
    6a5c:	f901e464 	str	x4, [x3, #968]
    6a60:	a94b8844 	ldp	x4, x2, [x2, #184]
    6a64:	f901e864 	str	x4, [x3, #976]
    6a68:	f901ec62 	str	x2, [x3, #984]
    6a6c:	97ffefa5 	bl	2900 <swapcontext@plt>
    6a70:	97ffff64 	bl	6800 <fwp_free_zombie>
    6a74:	d503201f 	nop
    6a78:	91014260 	add	x0, x19, #0x50
    6a7c:	b943e000 	ldr	w0, [x0, #992]
    6a80:	340001a0 	cbz	w0, 6ab4 <fwp_block+0x100>
    6a84:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a88:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a8c:	d65f03c0 	ret
    6a90:	97fff721 	bl	4714 <fwp_poll_events>
    6a94:	f9406682 	ldr	x2, [x20, #200]
    6a98:	b4ffffc2 	cbz	x2, 6a90 <fwp_block+0xdc>
    6a9c:	91014261 	add	x1, x19, #0x50
    6aa0:	f9408040 	ldr	x0, [x2, #256]
    6aa4:	f9006420 	str	x0, [x1, #200]
    6aa8:	b5fff9c0 	cbnz	x0, 69e0 <fwp_block+0x2c>
    6aac:	f900603f 	str	xzr, [x1, #192]
    6ab0:	17ffffcc 	b	69e0 <fwp_block+0x2c>
    6ab4:	f0000000 	adrp	x0, 9000 <__divti3+0x10>
    6ab8:	91340000 	add	x0, x0, #0xd00
    6abc:	97ffefdd 	bl	2a30 <getenv@plt>
    6ac0:	5284e202 	mov	w2, #0x2710                	// #10000
    6ac4:	b4000060 	cbz	x0, 6ad0 <fwp_block+0x11c>
    6ac8:	39400001 	ldrb	w1, [x0]
    6acc:	350000c1 	cbnz	w1, 6ae4 <fwp_block+0x130>
    6ad0:	91014273 	add	x19, x19, #0x50
    6ad4:	b903e262 	str	w2, [x19, #992]
    6ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6adc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ae0:	d65f03c0 	ret
    6ae4:	52800142 	mov	w2, #0xa                   	// #10
    6ae8:	d2800001 	mov	x1, #0x0                   	// #0
    6aec:	97ffef21 	bl	2770 <strtoll@plt>
    6af0:	d1000403 	sub	x3, x0, #0x1
    6af4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6af8:	eb02007f 	cmp	x3, x2
    6afc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6b00:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6b04:	17fffff3 	b	6ad0 <fwp_block+0x11c>
    6b08:	d503201f 	nop
    6b0c:	d503201f 	nop

0000000000006b10 <fwp_drop10>:
    6b10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6b14:	910003fd 	mov	x29, sp
    6b18:	a90153f3 	stp	x19, x20, [sp, #16]
    6b1c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xba0>
    6b20:	f90013f5 	str	x21, [sp, #32]
    6b24:	91190275 	add	x21, x19, #0x640
    6b28:	f949daa1 	ldr	x1, [x21, #5040]
    6b2c:	f949eea2 	ldr	x2, [x21, #5080]
    6b30:	cb010001 	sub	x1, x0, x1
    6b34:	eb02403f 	cmp	x1, x2, lsl #16
    6b38:	54000382 	b.cs	6ba8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b3c:	d350fc22 	lsr	x2, x1, #16
    6b40:	f949fea3 	ldr	x3, [x21, #5112]
    6b44:	8b020842 	add	x2, x2, x2, lsl #2
    6b48:	d37df042 	lsl	x2, x2, #3
    6b4c:	8b020064 	add	x4, x3, x2
    6b50:	f9401094 	ldr	x20, [x4, #32]
    6b54:	b40002b4 	cbz	x20, 6ba8 <fwp_drop10+0x98>
    6b58:	38626862 	ldrb	w2, [x3, x2]
    6b5c:	7100085f 	cmp	w2, #0x2
    6b60:	540007a0 	b.eq	6c54 <fwp_drop10+0x144>  // b.none
    6b64:	7100045f 	cmp	w2, #0x1
    6b68:	54000201 	b.ne	6ba8 <fwp_drop10+0x98>  // b.any
    6b6c:	29430885 	ldp	w5, w2, [x4, #24]
    6b70:	92403c21 	and	x1, x1, #0xffff
    6b74:	9b057c21 	mul	x1, x1, x5
    6b78:	d360fc21 	lsr	x1, x1, #32
    6b7c:	eb02003f 	cmp	x1, x2
    6b80:	54000142 	b.cs	6ba8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b84:	8b010294 	add	x20, x20, x1
    6b88:	39400281 	ldrb	w1, [x20]
    6b8c:	340000e1 	cbz	w1, 6ba8 <fwp_drop10+0x98>
    6b90:	7100043f 	cmp	w1, #0x1
    6b94:	54000120 	b.eq	6bb8 <fwp_drop10+0xa8>  // b.none
    6b98:	7103fc3f 	cmp	w1, #0xff
    6b9c:	540007c0 	b.eq	6c94 <fwp_drop10+0x184>  // b.none
    6ba0:	51000421 	sub	w1, w1, #0x1
    6ba4:	39000281 	strb	w1, [x20]
    6ba8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bac:	f94013f5 	ldr	x21, [sp, #32]
    6bb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bb4:	d65f03c0 	ret
    6bb8:	f9400001 	ldr	x1, [x0]
    6bbc:	b7f80581 	tbnz	x1, #63, 6c6c <fwp_drop10+0x15c>
    6bc0:	91190273 	add	x19, x19, #0x640
    6bc4:	f949da61 	ldr	x1, [x19, #5040]
    6bc8:	f949ee62 	ldr	x2, [x19, #5080]
    6bcc:	cb010001 	sub	x1, x0, x1
    6bd0:	eb02403f 	cmp	x1, x2, lsl #16
    6bd4:	54fffea2 	b.cs	6ba8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6bd8:	d350fc22 	lsr	x2, x1, #16
    6bdc:	8b020842 	add	x2, x2, x2, lsl #2
    6be0:	d37df042 	lsl	x2, x2, #3
    6be4:	8b020065 	add	x5, x3, x2
    6be8:	f94010a4 	ldr	x4, [x5, #32]
    6bec:	b4fffde4 	cbz	x4, 6ba8 <fwp_drop10+0x98>
    6bf0:	38626862 	ldrb	w2, [x3, x2]
    6bf4:	7100085f 	cmp	w2, #0x2
    6bf8:	54000220 	b.eq	6c3c <fwp_drop10+0x12c>  // b.none
    6bfc:	7100045f 	cmp	w2, #0x1
    6c00:	54fffd41 	b.ne	6ba8 <fwp_drop10+0x98>  // b.any
    6c04:	294308a3 	ldp	w3, w2, [x5, #24]
    6c08:	92403c21 	and	x1, x1, #0xffff
    6c0c:	9b037c21 	mul	x1, x1, x3
    6c10:	d360fc21 	lsr	x1, x1, #32
    6c14:	eb02003f 	cmp	x1, x2
    6c18:	54fffc82 	b.cs	6ba8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c1c:	8b010084 	add	x4, x4, x1
    6c20:	39400081 	ldrb	w1, [x4]
    6c24:	7100043f 	cmp	w1, #0x1
    6c28:	54fffc01 	b.ne	6ba8 <fwp_drop10+0x98>  // b.any
    6c2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c30:	f94013f5 	ldr	x21, [sp, #32]
    6c34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c38:	17fff82a 	b	4ce0 <fwp_mem_free>
    6c3c:	72003c3f 	tst	w1, #0xffff
    6c40:	54ffff00 	b.eq	6c20 <fwp_drop10+0x110>  // b.none
    6c44:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c48:	f94013f5 	ldr	x21, [sp, #32]
    6c4c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c50:	d65f03c0 	ret
    6c54:	72003c3f 	tst	w1, #0xffff
    6c58:	54fff980 	b.eq	6b88 <fwp_drop10+0x78>  // b.none
    6c5c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c60:	f94013f5 	ldr	x21, [sp, #32]
    6c64:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c68:	d65f03c0 	ret
    6c6c:	f9400414 	ldr	x20, [x0, #8]
    6c70:	97fffb51 	bl	59b4 <fwp_rc_free_arr>
    6c74:	91190260 	add	x0, x19, #0x640
    6c78:	f949d801 	ldr	x1, [x0, #5040]
    6c7c:	f949ec00 	ldr	x0, [x0, #5080]
    6c80:	cb010281 	sub	x1, x20, x1
    6c84:	eb00403f 	cmp	x1, x0, lsl #16
    6c88:	54fff902 	b.cs	6ba8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c8c:	aa1403e0 	mov	x0, x20
    6c90:	17ffffab 	b	6b3c <fwp_drop10+0x2c>
    6c94:	ca544680 	eor	x0, x20, x20, lsr #17
    6c98:	91190273 	add	x19, x19, #0x640
    6c9c:	ca402400 	eor	x0, x0, x0, lsr #9
    6ca0:	8b200e60 	add	x0, x19, w0, uxtb #3
    6ca4:	f94a2400 	ldr	x0, [x0, #5192]
    6ca8:	b5000080 	cbnz	x0, 6cb8 <fwp_drop10+0x1a8>
    6cac:	14000010 	b	6cec <fwp_drop10+0x1dc>
    6cb0:	f9400800 	ldr	x0, [x0, #16]
    6cb4:	b40001c0 	cbz	x0, 6cec <fwp_drop10+0x1dc>
    6cb8:	f9400001 	ldr	x1, [x0]
    6cbc:	eb14003f 	cmp	x1, x20
    6cc0:	54ffff81 	b.ne	6cb0 <fwp_drop10+0x1a0>  // b.any
    6cc4:	f9400401 	ldr	x1, [x0, #8]
    6cc8:	d1000421 	sub	x1, x1, #0x1
    6ccc:	f9000401 	str	x1, [x0, #8]
    6cd0:	f103f83f 	cmp	x1, #0xfe
    6cd4:	54fff6a1 	b.ne	6ba8 <fwp_drop10+0x98>  // b.any
    6cd8:	aa1403e0 	mov	x0, x20
    6cdc:	97fff761 	bl	4a60 <fwp_rc_forget_slot>
    6ce0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6ce4:	39000280 	strb	w0, [x20]
    6ce8:	17ffffb0 	b	6ba8 <fwp_drop10+0x98>
    6cec:	f0000000 	adrp	x0, 9000 <__divti3+0x10>
    6cf0:	912f4000 	add	x0, x0, #0xbd0
    6cf4:	97fff2c3 	bl	3800 <fwp_trap>
    6cf8:	d503201f 	nop
    6cfc:	d503201f 	nop

0000000000006d00 <fwp_caps173>:
    6d00:	34000041 	cbz	w1, 6d08 <fwp_caps173+0x8>
    6d04:	d65f03c0 	ret
    6d08:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xba0>
    6d0c:	91190063 	add	x3, x3, #0x640
    6d10:	f949d861 	ldr	x1, [x3, #5040]
    6d14:	f949ec62 	ldr	x2, [x3, #5080]
    6d18:	cb010001 	sub	x1, x0, x1
    6d1c:	eb02403f 	cmp	x1, x2, lsl #16
    6d20:	54ffff22 	b.cs	6d04 <fwp_caps173+0x4>  // b.hs, b.nlast
    6d24:	d350fc22 	lsr	x2, x1, #16
    6d28:	f949fc65 	ldr	x5, [x3, #5112]
    6d2c:	8b020842 	add	x2, x2, x2, lsl #2
    6d30:	d37df042 	lsl	x2, x2, #3
    6d34:	8b0200a4 	add	x4, x5, x2
    6d38:	f9401083 	ldr	x3, [x4, #32]
    6d3c:	b4fffe43 	cbz	x3, 6d04 <fwp_caps173+0x4>
    6d40:	386268a2 	ldrb	w2, [x5, x2]
    6d44:	7100085f 	cmp	w2, #0x2
    6d48:	540001c0 	b.eq	6d80 <fwp_caps173+0x80>  // b.none
    6d4c:	7100045f 	cmp	w2, #0x1
    6d50:	54fffda1 	b.ne	6d04 <fwp_caps173+0x4>  // b.any
    6d54:	29430885 	ldp	w5, w2, [x4, #24]
    6d58:	92403c21 	and	x1, x1, #0xffff
    6d5c:	9b057c21 	mul	x1, x1, x5
    6d60:	d360fc21 	lsr	x1, x1, #32
    6d64:	eb02003f 	cmp	x1, x2
    6d68:	54fffce2 	b.cs	6d04 <fwp_caps173+0x4>  // b.hs, b.nlast
    6d6c:	8b010063 	add	x3, x3, x1
    6d70:	39400061 	ldrb	w1, [x3]
    6d74:	7100043f 	cmp	w1, #0x1
    6d78:	54fffc61 	b.ne	6d04 <fwp_caps173+0x4>  // b.any
    6d7c:	17fff7d9 	b	4ce0 <fwp_mem_free>
    6d80:	72003c3f 	tst	w1, #0xffff
    6d84:	54ffff60 	b.eq	6d70 <fwp_caps173+0x70>  // b.none
    6d88:	d65f03c0 	ret
    6d8c:	d503201f 	nop

0000000000006d90 <f37>:
    6d90:	d101c3ff 	sub	sp, sp, #0x70
    6d94:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6d98:	f947f421 	ldr	x1, [x1, #4072]
    6d9c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6da0:	910083fd 	add	x29, sp, #0x20
    6da4:	a90563f7 	stp	x23, x24, [sp, #80]
    6da8:	f0000397 	adrp	x23, 79000 <fwp_root_context+0xba0>
    6dac:	911902e3 	add	x3, x23, #0x640
    6db0:	a90353f3 	stp	x19, x20, [sp, #48]
    6db4:	a9045bf5 	stp	x21, x22, [sp, #64]
    6db8:	aa0003f6 	mov	x22, x0
    6dbc:	a9066bf9 	stp	x25, x26, [sp, #96]
    6dc0:	f949ec62 	ldr	x2, [x3, #5080]
    6dc4:	f9400024 	ldr	x4, [x1]
    6dc8:	f9000fe4 	str	x4, [sp, #24]
    6dcc:	d2800004 	mov	x4, #0x0                   	// #0
    6dd0:	f949d861 	ldr	x1, [x3, #5040]
    6dd4:	d370bc42 	lsl	x2, x2, #16
    6dd8:	b40016c0 	cbz	x0, 70b0 <f37+0x320>
    6ddc:	f9400818 	ldr	x24, [x0, #16]
    6de0:	cb010301 	sub	x1, x24, x1
    6de4:	eb02003f 	cmp	x1, x2
    6de8:	540003e2 	b.cs	6e64 <f37+0xd4>  // b.hs, b.nlast
    6dec:	f949fc60 	ldr	x0, [x3, #5112]
    6df0:	d350fc22 	lsr	x2, x1, #16
    6df4:	8b020842 	add	x2, x2, x2, lsl #2
    6df8:	8b020c02 	add	x2, x0, x2, lsl #3
    6dfc:	f9401040 	ldr	x0, [x2, #32]
    6e00:	b4000320 	cbz	x0, 6e64 <f37+0xd4>
    6e04:	39400043 	ldrb	w3, [x2]
    6e08:	7100087f 	cmp	w3, #0x2
    6e0c:	54001440 	b.eq	7094 <f37+0x304>  // b.none
    6e10:	7100047f 	cmp	w3, #0x1
    6e14:	54000241 	b.ne	6e5c <f37+0xcc>  // b.any
    6e18:	29430843 	ldp	w3, w2, [x2, #24]
    6e1c:	92403c21 	and	x1, x1, #0xffff
    6e20:	9b037c21 	mul	x1, x1, x3
    6e24:	d360fc21 	lsr	x1, x1, #32
    6e28:	eb02003f 	cmp	x1, x2
    6e2c:	54000182 	b.cs	6e5c <f37+0xcc>  // b.hs, b.nlast
    6e30:	8b010000 	add	x0, x0, x1
    6e34:	39400001 	ldrb	w1, [x0]
    6e38:	34000121 	cbz	w1, 6e5c <f37+0xcc>
    6e3c:	d00000c2 	adrp	x2, 20000 <__data_start>
    6e40:	91014042 	add	x2, x2, #0x50
    6e44:	b9415043 	ldr	w3, [x2, #336]
    6e48:	350012c3 	cbnz	w3, 70a0 <f37+0x310>
    6e4c:	7103f43f 	cmp	w1, #0xfd
    6e50:	54001728 	b.hi	7134 <f37+0x3a4>  // b.pmore
    6e54:	11000421 	add	w1, w1, #0x1
    6e58:	39000001 	strb	w1, [x0]
    6e5c:	d2800000 	mov	x0, #0x0                   	// #0
    6e60:	b40000f6 	cbz	x22, 6e7c <f37+0xec>
    6e64:	aa1603e1 	mov	x1, x22
    6e68:	d2800000 	mov	x0, #0x0                   	// #0
    6e6c:	d503201f 	nop
    6e70:	f9400821 	ldr	x1, [x1, #16]
    6e74:	91000400 	add	x0, x0, #0x1
    6e78:	b5ffffc1 	cbnz	x1, 6e70 <f37+0xe0>
    6e7c:	b4001238 	cbz	x24, 70c0 <f37+0x330>
    6e80:	aa1803e1 	mov	x1, x24
    6e84:	d2800002 	mov	x2, #0x0                   	// #0
    6e88:	f9400821 	ldr	x1, [x1, #16]
    6e8c:	91000442 	add	x2, x2, #0x1
    6e90:	b5ffffc1 	cbnz	x1, 6e88 <f37+0xf8>
    6e94:	eb00005f 	cmp	x2, x0
    6e98:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6e9c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6ea0:	eb01033f 	cmp	x25, x1
    6ea4:	540014e8 	b.hi	7140 <f37+0x3b0>  // b.pmore
    6ea8:	d37ffb33 	lsl	x19, x25, #1
    6eac:	52800041 	mov	w1, #0x2                   	// #2
    6eb0:	91000660 	add	x0, x19, #0x1
    6eb4:	d37df000 	lsl	x0, x0, #3
    6eb8:	97fff8aa 	bl	5160 <fwp_heap_alloc>
    6ebc:	911902e1 	add	x1, x23, #0x640
    6ec0:	aa0003fa 	mov	x26, x0
    6ec4:	f9000013 	str	x19, [x0]
    6ec8:	aa0103e0 	mov	x0, x1
    6ecc:	f949d821 	ldr	x1, [x1, #5040]
    6ed0:	f949ec00 	ldr	x0, [x0, #5080]
    6ed4:	cb010341 	sub	x1, x26, x1
    6ed8:	eb00403f 	cmp	x1, x0, lsl #16
    6edc:	54000342 	b.cs	6f44 <f37+0x1b4>  // b.hs, b.nlast
    6ee0:	911902e2 	add	x2, x23, #0x640
    6ee4:	d350fc20 	lsr	x0, x1, #16
    6ee8:	8b000800 	add	x0, x0, x0, lsl #2
    6eec:	f949fc43 	ldr	x3, [x2, #5112]
    6ef0:	d37df002 	lsl	x2, x0, #3
    6ef4:	8b020060 	add	x0, x3, x2
    6ef8:	f9401013 	ldr	x19, [x0, #32]
    6efc:	b4000253 	cbz	x19, 6f44 <f37+0x1b4>
    6f00:	38626862 	ldrb	w2, [x3, x2]
    6f04:	7100085f 	cmp	w2, #0x2
    6f08:	54000c00 	b.eq	7088 <f37+0x2f8>  // b.none
    6f0c:	7100045f 	cmp	w2, #0x1
    6f10:	540001a1 	b.ne	6f44 <f37+0x1b4>  // b.any
    6f14:	29430002 	ldp	w2, w0, [x0, #24]
    6f18:	92403c21 	and	x1, x1, #0xffff
    6f1c:	9b027c21 	mul	x1, x1, x2
    6f20:	d360fc21 	lsr	x1, x1, #32
    6f24:	eb00003f 	cmp	x1, x0
    6f28:	540000e2 	b.cs	6f44 <f37+0x1b4>  // b.hs, b.nlast
    6f2c:	8b010273 	add	x19, x19, x1
    6f30:	39400260 	ldrb	w0, [x19]
    6f34:	7103fc1f 	cmp	w0, #0xff
    6f38:	54000e80 	b.eq	7108 <f37+0x378>  // b.none
    6f3c:	52800020 	mov	w0, #0x1                   	// #1
    6f40:	39000260 	strb	w0, [x19]
    6f44:	b4000259 	cbz	x25, 6f8c <f37+0x1fc>
    6f48:	8b191359 	add	x25, x26, x25, lsl #4
    6f4c:	aa1a03f3 	mov	x19, x26
    6f50:	aa1603f5 	mov	x21, x22
    6f54:	aa1803f4 	mov	x20, x24
    6f58:	f9400683 	ldr	x3, [x20, #8]
    6f5c:	f94006a2 	ldr	x2, [x21, #8]
    6f60:	f9400861 	ldr	x1, [x3, #16]
    6f64:	f9400840 	ldr	x0, [x2, #16]
    6f68:	fd400461 	ldr	d1, [x3, #8]
    6f6c:	fd400440 	ldr	d0, [x2, #8]
    6f70:	97fff9ed 	bl	5724 <w120>
    6f74:	f9000660 	str	x0, [x19, #8]
    6f78:	f8010e61 	str	x1, [x19, #16]!
    6f7c:	f9400a94 	ldr	x20, [x20, #16]
    6f80:	f9400ab5 	ldr	x21, [x21, #16]
    6f84:	eb13033f 	cmp	x25, x19
    6f88:	54fffe81 	b.ne	6f58 <f37+0x1c8>  // b.any
    6f8c:	aa1803e0 	mov	x0, x24
    6f90:	97fffd44 	bl	64a0 <fwp_drop4>
    6f94:	aa1603e0 	mov	x0, x22
    6f98:	97fffd42 	bl	64a0 <fwp_drop4>
    6f9c:	911902f7 	add	x23, x23, #0x640
    6fa0:	aa1a03e0 	mov	x0, x26
    6fa4:	97fffa33 	bl	5870 <w176.constprop.0>
    6fa8:	aa0103f3 	mov	x19, x1
    6fac:	aa0003f4 	mov	x20, x0
    6fb0:	aa1a03e0 	mov	x0, x26
    6fb4:	97fffed7 	bl	6b10 <fwp_drop10>
    6fb8:	a900cff4 	stp	x20, x19, [sp, #8]
    6fbc:	910023e1 	add	x1, sp, #0x8
    6fc0:	52800000 	mov	w0, #0x0                   	// #0
    6fc4:	97fff8c8 	bl	52e4 <fwp_data.part.0.constprop.0>
    6fc8:	f949dae1 	ldr	x1, [x23, #5040]
    6fcc:	aa0003f3 	mov	x19, x0
    6fd0:	f949eee0 	ldr	x0, [x23, #5080]
    6fd4:	cb010261 	sub	x1, x19, x1
    6fd8:	eb00403f 	cmp	x1, x0, lsl #16
    6fdc:	54000322 	b.cs	7040 <f37+0x2b0>  // b.hs, b.nlast
    6fe0:	d350fc22 	lsr	x2, x1, #16
    6fe4:	f949fee3 	ldr	x3, [x23, #5112]
    6fe8:	8b020842 	add	x2, x2, x2, lsl #2
    6fec:	d37df042 	lsl	x2, x2, #3
    6ff0:	8b020060 	add	x0, x3, x2
    6ff4:	f9401014 	ldr	x20, [x0, #32]
    6ff8:	b4000254 	cbz	x20, 7040 <f37+0x2b0>
    6ffc:	38626862 	ldrb	w2, [x3, x2]
    7000:	7100085f 	cmp	w2, #0x2
    7004:	540003c0 	b.eq	707c <f37+0x2ec>  // b.none
    7008:	7100045f 	cmp	w2, #0x1
    700c:	540001a1 	b.ne	7040 <f37+0x2b0>  // b.any
    7010:	29430002 	ldp	w2, w0, [x0, #24]
    7014:	92403c21 	and	x1, x1, #0xffff
    7018:	9b027c21 	mul	x1, x1, x2
    701c:	d360fc21 	lsr	x1, x1, #32
    7020:	eb00003f 	cmp	x1, x0
    7024:	540000e2 	b.cs	7040 <f37+0x2b0>  // b.hs, b.nlast
    7028:	8b010294 	add	x20, x20, x1
    702c:	39400280 	ldrb	w0, [x20]
    7030:	7103fc1f 	cmp	w0, #0xff
    7034:	54000640 	b.eq	70fc <f37+0x36c>  // b.none
    7038:	52800020 	mov	w0, #0x1                   	// #1
    703c:	39000280 	strb	w0, [x20]
    7040:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7044:	f947f400 	ldr	x0, [x0, #4072]
    7048:	f9400fe2 	ldr	x2, [sp, #24]
    704c:	f9400001 	ldr	x1, [x0]
    7050:	eb010042 	subs	x2, x2, x1
    7054:	d2800001 	mov	x1, #0x0                   	// #0
    7058:	54000721 	b.ne	713c <f37+0x3ac>  // b.any
    705c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7060:	aa1303e0 	mov	x0, x19
    7064:	a94353f3 	ldp	x19, x20, [sp, #48]
    7068:	a9445bf5 	ldp	x21, x22, [sp, #64]
    706c:	a94563f7 	ldp	x23, x24, [sp, #80]
    7070:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7074:	9101c3ff 	add	sp, sp, #0x70
    7078:	d65f03c0 	ret
    707c:	72003c3f 	tst	w1, #0xffff
    7080:	54fffe01 	b.ne	7040 <f37+0x2b0>  // b.any
    7084:	17ffffea 	b	702c <f37+0x29c>
    7088:	72003c3f 	tst	w1, #0xffff
    708c:	54fff5c1 	b.ne	6f44 <f37+0x1b4>  // b.any
    7090:	17ffffa8 	b	6f30 <f37+0x1a0>
    7094:	72003c3f 	tst	w1, #0xffff
    7098:	54ffee21 	b.ne	6e5c <f37+0xcc>  // b.any
    709c:	17ffff66 	b	6e34 <f37+0xa4>
    70a0:	f940bc43 	ldr	x3, [x2, #376]
    70a4:	91000463 	add	x3, x3, #0x1
    70a8:	f900bc43 	str	x3, [x2, #376]
    70ac:	17ffff68 	b	6e4c <f37+0xbc>
    70b0:	cb0103e1 	neg	x1, x1
    70b4:	eb02003f 	cmp	x1, x2
    70b8:	540002e3 	b.cc	7114 <f37+0x384>  // b.lo, b.ul, b.last
    70bc:	d503201f 	nop
    70c0:	52800041 	mov	w1, #0x2                   	// #2
    70c4:	d2800100 	mov	x0, #0x8                   	// #8
    70c8:	97fff826 	bl	5160 <fwp_heap_alloc>
    70cc:	aa0003e1 	mov	x1, x0
    70d0:	911902e0 	add	x0, x23, #0x640
    70d4:	aa0103fa 	mov	x26, x1
    70d8:	d2800018 	mov	x24, #0x0                   	// #0
    70dc:	f900003f 	str	xzr, [x1]
    70e0:	f949d801 	ldr	x1, [x0, #5040]
    70e4:	f949ec00 	ldr	x0, [x0, #5080]
    70e8:	cb010341 	sub	x1, x26, x1
    70ec:	eb00403f 	cmp	x1, x0, lsl #16
    70f0:	54fff4e2 	b.cs	6f8c <f37+0x1fc>  // b.hs, b.nlast
    70f4:	d2800019 	mov	x25, #0x0                   	// #0
    70f8:	17ffff7a 	b	6ee0 <f37+0x150>
    70fc:	aa1403e0 	mov	x0, x20
    7100:	97fff658 	bl	4a60 <fwp_rc_forget_slot>
    7104:	17ffffcd 	b	7038 <f37+0x2a8>
    7108:	aa1303e0 	mov	x0, x19
    710c:	97fff655 	bl	4a60 <fwp_rc_forget_slot>
    7110:	17ffff8b 	b	6f3c <f37+0x1ac>
    7114:	f949fc62 	ldr	x2, [x3, #5112]
    7118:	d350fc20 	lsr	x0, x1, #16
    711c:	8b000800 	add	x0, x0, x0, lsl #2
    7120:	8b000c42 	add	x2, x2, x0, lsl #3
    7124:	f9401040 	ldr	x0, [x2, #32]
    7128:	b4fffcc0 	cbz	x0, 70c0 <f37+0x330>
    712c:	d2800018 	mov	x24, #0x0                   	// #0
    7130:	17ffff35 	b	6e04 <f37+0x74>
    7134:	97fff604 	bl	4944 <fwp_rc_wide_dup>
    7138:	17ffff49 	b	6e5c <f37+0xcc>
    713c:	97ffedd9 	bl	28a0 <__stack_chk_fail@plt>
    7140:	d0000000 	adrp	x0, 9000 <__divti3+0x10>
    7144:	91344000 	add	x0, x0, #0xd10
    7148:	97fff1ae 	bl	3800 <fwp_trap>
    714c:	d503201f 	nop

0000000000007150 <fwp_owned_entry37>:
    7150:	f9400000 	ldr	x0, [x0]
    7154:	17ffff0f 	b	6d90 <f37>
    7158:	d503201f 	nop
    715c:	d503201f 	nop

0000000000007160 <e37>:
    7160:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7164:	910003fd 	mov	x29, sp
    7168:	f9000bf3 	str	x19, [sp, #16]
    716c:	f9400013 	ldr	x19, [x0]
    7170:	aa1303e0 	mov	x0, x19
    7174:	97fff9eb 	bl	5920 <fwp_rc_share>
    7178:	aa1303e0 	mov	x0, x19
    717c:	97ffff05 	bl	6d90 <f37>
    7180:	aa0003f3 	mov	x19, x0
    7184:	97fff9e7 	bl	5920 <fwp_rc_share>
    7188:	aa1303e0 	mov	x0, x19
    718c:	f9400bf3 	ldr	x19, [sp, #16]
    7190:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7194:	d65f03c0 	ret
    7198:	d503201f 	nop
    719c:	d503201f 	nop

00000000000071a0 <fwp_args37>:
    71a0:	7100003f 	cmp	w1, #0x0
    71a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    71a8:	54000041 	b.ne	71b0 <fwp_args37+0x10>  // b.any
    71ac:	d65f03c0 	ret
    71b0:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    71b4:	91190042 	add	x2, x2, #0x640
    71b8:	f9400001 	ldr	x1, [x0]
    71bc:	f949d843 	ldr	x3, [x2, #5040]
    71c0:	f949ec40 	ldr	x0, [x2, #5080]
    71c4:	cb030021 	sub	x1, x1, x3
    71c8:	eb00403f 	cmp	x1, x0, lsl #16
    71cc:	54ffff02 	b.cs	71ac <fwp_args37+0xc>  // b.hs, b.nlast
    71d0:	d350fc20 	lsr	x0, x1, #16
    71d4:	f949fc44 	ldr	x4, [x2, #5112]
    71d8:	8b000800 	add	x0, x0, x0, lsl #2
    71dc:	d37df002 	lsl	x2, x0, #3
    71e0:	8b020083 	add	x3, x4, x2
    71e4:	f9401060 	ldr	x0, [x3, #32]
    71e8:	b4fffe20 	cbz	x0, 71ac <fwp_args37+0xc>
    71ec:	38626882 	ldrb	w2, [x4, x2]
    71f0:	7100085f 	cmp	w2, #0x2
    71f4:	54000320 	b.eq	7258 <fwp_args37+0xb8>  // b.none
    71f8:	7100045f 	cmp	w2, #0x1
    71fc:	54fffd81 	b.ne	71ac <fwp_args37+0xc>  // b.any
    7200:	29430864 	ldp	w4, w2, [x3, #24]
    7204:	92403c21 	and	x1, x1, #0xffff
    7208:	9b047c21 	mul	x1, x1, x4
    720c:	d360fc21 	lsr	x1, x1, #32
    7210:	eb02003f 	cmp	x1, x2
    7214:	54fffcc2 	b.cs	71ac <fwp_args37+0xc>  // b.hs, b.nlast
    7218:	8b010000 	add	x0, x0, x1
    721c:	39400001 	ldrb	w1, [x0]
    7220:	34fffc61 	cbz	w1, 71ac <fwp_args37+0xc>
    7224:	b00000c2 	adrp	x2, 20000 <__data_start>
    7228:	91014042 	add	x2, x2, #0x50
    722c:	b9415043 	ldr	w3, [x2, #336]
    7230:	350000c3 	cbnz	w3, 7248 <fwp_args37+0xa8>
    7234:	7103f43f 	cmp	w1, #0xfd
    7238:	54000168 	b.hi	7264 <fwp_args37+0xc4>  // b.pmore
    723c:	11000421 	add	w1, w1, #0x1
    7240:	39000001 	strb	w1, [x0]
    7244:	d65f03c0 	ret
    7248:	f940bc43 	ldr	x3, [x2, #376]
    724c:	91000463 	add	x3, x3, #0x1
    7250:	f900bc43 	str	x3, [x2, #376]
    7254:	17fffff8 	b	7234 <fwp_args37+0x94>
    7258:	72003c3f 	tst	w1, #0xffff
    725c:	54fffe00 	b.eq	721c <fwp_args37+0x7c>  // b.none
    7260:	d65f03c0 	ret
    7264:	17fff5b8 	b	4944 <fwp_rc_wide_dup>
    7268:	d503201f 	nop
    726c:	d503201f 	nop

0000000000007270 <fwp_caps37>:
    7270:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7274:	910003fd 	mov	x29, sp
    7278:	f9000bf3 	str	x19, [sp, #16]
    727c:	aa0003f3 	mov	x19, x0
    7280:	b9400400 	ldr	w0, [x0, #4]
    7284:	340004a0 	cbz	w0, 7318 <fwp_caps37+0xa8>
    7288:	f9400660 	ldr	x0, [x19, #8]
    728c:	350004e1 	cbnz	w1, 7328 <fwp_caps37+0xb8>
    7290:	97fffc84 	bl	64a0 <fwp_drop4>
    7294:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    7298:	91190042 	add	x2, x2, #0x640
    729c:	f949d840 	ldr	x0, [x2, #5040]
    72a0:	f949ec41 	ldr	x1, [x2, #5080]
    72a4:	cb000260 	sub	x0, x19, x0
    72a8:	eb01401f 	cmp	x0, x1, lsl #16
    72ac:	54000382 	b.cs	731c <fwp_caps37+0xac>  // b.hs, b.nlast
    72b0:	d350fc01 	lsr	x1, x0, #16
    72b4:	f949fc44 	ldr	x4, [x2, #5112]
    72b8:	8b010821 	add	x1, x1, x1, lsl #2
    72bc:	d37df021 	lsl	x1, x1, #3
    72c0:	8b010083 	add	x3, x4, x1
    72c4:	f9401062 	ldr	x2, [x3, #32]
    72c8:	b40002a2 	cbz	x2, 731c <fwp_caps37+0xac>
    72cc:	38616881 	ldrb	w1, [x4, x1]
    72d0:	7100083f 	cmp	w1, #0x2
    72d4:	54000740 	b.eq	73bc <fwp_caps37+0x14c>  // b.none
    72d8:	7100043f 	cmp	w1, #0x1
    72dc:	54000201 	b.ne	731c <fwp_caps37+0xac>  // b.any
    72e0:	29430464 	ldp	w4, w1, [x3, #24]
    72e4:	92403c00 	and	x0, x0, #0xffff
    72e8:	9b047c00 	mul	x0, x0, x4
    72ec:	d360fc00 	lsr	x0, x0, #32
    72f0:	eb01001f 	cmp	x0, x1
    72f4:	54000142 	b.cs	731c <fwp_caps37+0xac>  // b.hs, b.nlast
    72f8:	8b000042 	add	x2, x2, x0
    72fc:	39400040 	ldrb	w0, [x2]
    7300:	7100041f 	cmp	w0, #0x1
    7304:	540000c1 	b.ne	731c <fwp_caps37+0xac>  // b.any
    7308:	aa1303e0 	mov	x0, x19
    730c:	f9400bf3 	ldr	x19, [sp, #16]
    7310:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7314:	17fff673 	b	4ce0 <fwp_mem_free>
    7318:	34fffbe1 	cbz	w1, 7294 <fwp_caps37+0x24>
    731c:	f9400bf3 	ldr	x19, [sp, #16]
    7320:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7324:	d65f03c0 	ret
    7328:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    732c:	91190042 	add	x2, x2, #0x640
    7330:	f949d843 	ldr	x3, [x2, #5040]
    7334:	f949ec41 	ldr	x1, [x2, #5080]
    7338:	cb030000 	sub	x0, x0, x3
    733c:	eb01401f 	cmp	x0, x1, lsl #16
    7340:	54fffee2 	b.cs	731c <fwp_caps37+0xac>  // b.hs, b.nlast
    7344:	d350fc01 	lsr	x1, x0, #16
    7348:	f949fc44 	ldr	x4, [x2, #5112]
    734c:	8b010821 	add	x1, x1, x1, lsl #2
    7350:	d37df021 	lsl	x1, x1, #3
    7354:	8b010083 	add	x3, x4, x1
    7358:	f9401062 	ldr	x2, [x3, #32]
    735c:	b4fffe02 	cbz	x2, 731c <fwp_caps37+0xac>
    7360:	38616881 	ldrb	w1, [x4, x1]
    7364:	7100083f 	cmp	w1, #0x2
    7368:	54000300 	b.eq	73c8 <fwp_caps37+0x158>  // b.none
    736c:	7100043f 	cmp	w1, #0x1
    7370:	54fffd61 	b.ne	731c <fwp_caps37+0xac>  // b.any
    7374:	92403c01 	and	x1, x0, #0xffff
    7378:	29430064 	ldp	w4, w0, [x3, #24]
    737c:	9b047c21 	mul	x1, x1, x4
    7380:	d360fc21 	lsr	x1, x1, #32
    7384:	eb00003f 	cmp	x1, x0
    7388:	54fffca2 	b.cs	731c <fwp_caps37+0xac>  // b.hs, b.nlast
    738c:	8b010042 	add	x2, x2, x1
    7390:	39400040 	ldrb	w0, [x2]
    7394:	34fffc40 	cbz	w0, 731c <fwp_caps37+0xac>
    7398:	b00000c1 	adrp	x1, 20000 <__data_start>
    739c:	91014021 	add	x1, x1, #0x50
    73a0:	b9415023 	ldr	w3, [x1, #336]
    73a4:	35000183 	cbnz	w3, 73d4 <fwp_caps37+0x164>
    73a8:	7103f41f 	cmp	w0, #0xfd
    73ac:	540001c8 	b.hi	73e4 <fwp_caps37+0x174>  // b.pmore
    73b0:	11000400 	add	w0, w0, #0x1
    73b4:	39000040 	strb	w0, [x2]
    73b8:	17ffffd9 	b	731c <fwp_caps37+0xac>
    73bc:	72003c1f 	tst	w0, #0xffff
    73c0:	54fffae1 	b.ne	731c <fwp_caps37+0xac>  // b.any
    73c4:	17ffffce 	b	72fc <fwp_caps37+0x8c>
    73c8:	72003c1f 	tst	w0, #0xffff
    73cc:	54fffa81 	b.ne	731c <fwp_caps37+0xac>  // b.any
    73d0:	17fffff0 	b	7390 <fwp_caps37+0x120>
    73d4:	f940bc23 	ldr	x3, [x1, #376]
    73d8:	91000463 	add	x3, x3, #0x1
    73dc:	f900bc23 	str	x3, [x1, #376]
    73e0:	17fffff2 	b	73a8 <fwp_caps37+0x138>
    73e4:	f9400bf3 	ldr	x19, [sp, #16]
    73e8:	aa0203e0 	mov	x0, x2
    73ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    73f0:	17fff555 	b	4944 <fwp_rc_wide_dup>

00000000000073f4 <fwp_write>:
    73f4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    73f8:	910003fd 	mov	x29, sp
    73fc:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    7400:	f947f484 	ldr	x4, [x4, #4072]
    7404:	a90153f3 	stp	x19, x20, [sp, #16]
    7408:	d10943ff 	sub	sp, sp, #0x250
    740c:	b9400045 	ldr	w5, [x2]
    7410:	aa0003f4 	mov	x20, x0
    7414:	f9400080 	ldr	x0, [x4]
    7418:	f90127e0 	str	x0, [sp, #584]
    741c:	d2800000 	mov	x0, #0x0                   	// #0
    7420:	710064bf 	cmp	w5, #0x19
    7424:	54000408 	b.hi	74a4 <fwp_write+0xb0>  // b.pmore
    7428:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x8f0>
    742c:	aa0103f3 	mov	x19, x1
    7430:	91160000 	add	x0, x0, #0x580
    7434:	f9013bf5 	str	x21, [sp, #624]
    7438:	f9013ff6 	str	x22, [sp, #632]
    743c:	f90153fb 	str	x27, [sp, #672]
    7440:	f90157fc 	str	x28, [sp, #680]
    7444:	aa0203fc 	mov	x28, x2
    7448:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    744c:	10000061 	adr	x1, 7458 <fwp_write+0x64>
    7450:	8b20a820 	add	x0, x1, w0, sxth #2
    7454:	d61f0000 	br	x0
    7458:	910123e0 	add	x0, sp, #0x48
    745c:	aa1303e5 	mov	x5, x19
    7460:	d0000004 	adrp	x4, 9000 <__divti3+0x10>
    7464:	aa0003f3 	mov	x19, x0
    7468:	91356084 	add	x4, x4, #0xd58
    746c:	d2804003 	mov	x3, #0x200                 	// #512
    7470:	aa0303e1 	mov	x1, x3
    7474:	52800042 	mov	w2, #0x2                   	// #2
    7478:	97ffece6 	bl	2810 <__snprintf_chk@plt>
    747c:	aa1303e0 	mov	x0, x19
    7480:	97ffecac 	bl	2730 <strlen@plt>
    7484:	aa1303e1 	mov	x1, x19
    7488:	aa0003e2 	mov	x2, x0
    748c:	aa1403e0 	mov	x0, x20
    7490:	97fff080 	bl	3690 <buf_put>
    7494:	f9413bf5 	ldr	x21, [sp, #624]
    7498:	f9413ff6 	ldr	x22, [sp, #632]
    749c:	f94153fb 	ldr	x27, [sp, #672]
    74a0:	f94157fc 	ldr	x28, [sp, #680]
    74a4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    74a8:	f947f400 	ldr	x0, [x0, #4072]
    74ac:	f94127e2 	ldr	x2, [sp, #584]
    74b0:	f9400001 	ldr	x1, [x0]
    74b4:	eb010042 	subs	x2, x2, x1
    74b8:	d2800001 	mov	x1, #0x0                   	// #0
    74bc:	540077a1 	b.ne	83b0 <fwp_write+0xfbc>  // b.any
    74c0:	910943ff 	add	sp, sp, #0x250
    74c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    74c8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    74cc:	d65f03c0 	ret
    74d0:	910123e0 	add	x0, sp, #0x48
    74d4:	aa1303e5 	mov	x5, x19
    74d8:	d0000004 	adrp	x4, 9000 <__divti3+0x10>
    74dc:	aa0003f3 	mov	x19, x0
    74e0:	91354084 	add	x4, x4, #0xd50
    74e4:	d2804003 	mov	x3, #0x200                 	// #512
    74e8:	17ffffe2 	b	7470 <fwp_write+0x7c>
    74ec:	71004cbf 	cmp	w5, #0x13
    74f0:	d0000000 	adrp	x0, 9000 <__divti3+0x10>
    74f4:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    74f8:	91350000 	add	x0, x0, #0xd40
    74fc:	91352021 	add	x1, x1, #0xd48
    7500:	d2800082 	mov	x2, #0x4                   	// #4
    7504:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7508:	aa1403e0 	mov	x0, x20
    750c:	f90143f7 	str	x23, [sp, #640]
    7510:	d2800016 	mov	x22, #0x0                   	// #0
    7514:	f90147f8 	str	x24, [sp, #648]
    7518:	97fff05e 	bl	3690 <buf_put>
    751c:	f9400260 	ldr	x0, [x19]
    7520:	d0000017 	adrp	x23, 9000 <__divti3+0x10>
    7524:	d2800015 	mov	x21, #0x0                   	// #0
    7528:	913722f7 	add	x23, x23, #0xdc8
    752c:	b4004780 	cbz	x0, 7e1c <fwp_write+0xa28>
    7530:	b9400380 	ldr	w0, [x28]
    7534:	52800003 	mov	w3, #0x0                   	// #0
    7538:	f9401f82 	ldr	x2, [x28, #56]
    753c:	71004c1f 	cmp	w0, #0x13
    7540:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7544:	aa1403e0 	mov	x0, x20
    7548:	8b010e61 	add	x1, x19, x1, lsl #3
    754c:	f9400421 	ldr	x1, [x1, #8]
    7550:	97ffffa9 	bl	73f4 <fwp_write>
    7554:	b9400380 	ldr	w0, [x28]
    7558:	7100481f 	cmp	w0, #0x12
    755c:	54004b20 	b.eq	7ec0 <fwp_write+0xacc>  // b.none
    7560:	f9400260 	ldr	x0, [x19]
    7564:	910006b5 	add	x21, x21, #0x1
    7568:	91000ad6 	add	x22, x22, #0x2
    756c:	eb15001f 	cmp	x0, x21
    7570:	54004569 	b.ls	7e1c <fwp_write+0xa28>  // b.plast
    7574:	aa1703e1 	mov	x1, x23
    7578:	aa1403e0 	mov	x0, x20
    757c:	d2800042 	mov	x2, #0x2                   	// #2
    7580:	97fff044 	bl	3690 <buf_put>
    7584:	17ffffeb 	b	7530 <fwp_write+0x13c>
    7588:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    758c:	91360021 	add	x1, x1, #0xd80
    7590:	d28000c2 	mov	x2, #0x6                   	// #6
    7594:	aa1403e0 	mov	x0, x20
    7598:	91004273 	add	x19, x19, #0x10
    759c:	97fff03d 	bl	3690 <buf_put>
    75a0:	aa1303e0 	mov	x0, x19
    75a4:	97ffec63 	bl	2730 <strlen@plt>
    75a8:	aa1303e1 	mov	x1, x19
    75ac:	aa0003e2 	mov	x2, x0
    75b0:	aa1403e0 	mov	x0, x20
    75b4:	97fff037 	bl	3690 <buf_put>
    75b8:	528007c3 	mov	w3, #0x3e                  	// #62
    75bc:	aa1403e0 	mov	x0, x20
    75c0:	91001fe1 	add	x1, sp, #0x7
    75c4:	d2800022 	mov	x2, #0x1                   	// #1
    75c8:	39001fe3 	strb	w3, [sp, #7]
    75cc:	17ffffb1 	b	7490 <fwp_write+0x9c>
    75d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    75d4:	f947f400 	ldr	x0, [x0, #4072]
    75d8:	f94127e2 	ldr	x2, [sp, #584]
    75dc:	f9400001 	ldr	x1, [x0]
    75e0:	eb010042 	subs	x2, x2, x1
    75e4:	d2800001 	mov	x1, #0x0                   	// #0
    75e8:	540034c1 	b.ne	7c80 <fwp_write+0x88c>  // b.any
    75ec:	f9413bf5 	ldr	x21, [sp, #624]
    75f0:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    75f4:	f9413ff6 	ldr	x22, [sp, #632]
    75f8:	aa1403e0 	mov	x0, x20
    75fc:	91358021 	add	x1, x1, #0xd60
    7600:	d2800142 	mov	x2, #0xa                   	// #10
    7604:	f94153fb 	ldr	x27, [sp, #672]
    7608:	f94157fc 	ldr	x28, [sp, #680]
    760c:	910943ff 	add	sp, sp, #0x250
    7610:	a94153f3 	ldp	x19, x20, [sp, #16]
    7614:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7618:	17fff01e 	b	3690 <buf_put>
    761c:	f9400456 	ldr	x22, [x2, #8]
    7620:	f90143f7 	str	x23, [sp, #640]
    7624:	f90147f8 	str	x24, [sp, #648]
    7628:	b4005af6 	cbz	x22, 8184 <fwp_write+0xd90>
    762c:	aa1603e0 	mov	x0, x22
    7630:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7634:	91378021 	add	x1, x1, #0xde0
    7638:	97ffecba 	bl	2920 <strcmp@plt>
    763c:	2a0003f5 	mov	w21, w0
    7640:	34005fc0 	cbz	w0, 8238 <fwp_write+0xe44>
    7644:	aa1603e0 	mov	x0, x22
    7648:	97ffec3a 	bl	2730 <strlen@plt>
    764c:	aa1603e1 	mov	x1, x22
    7650:	aa0003e2 	mov	x2, x0
    7654:	aa1403e0 	mov	x0, x20
    7658:	97fff00e 	bl	3690 <buf_put>
    765c:	52800403 	mov	w3, #0x20                  	// #32
    7660:	91001ff5 	add	x21, sp, #0x7
    7664:	aa1503e1 	mov	x1, x21
    7668:	aa1403e0 	mov	x0, x20
    766c:	d2800022 	mov	x2, #0x1                   	// #1
    7670:	39001fe3 	strb	w3, [sp, #7]
    7674:	97fff007 	bl	3690 <buf_put>
    7678:	52800f63 	mov	w3, #0x7b                  	// #123
    767c:	aa1403e0 	mov	x0, x20
    7680:	aa1503e1 	mov	x1, x21
    7684:	d2800022 	mov	x2, #0x1                   	// #1
    7688:	39001fe3 	strb	w3, [sp, #7]
    768c:	97fff001 	bl	3690 <buf_put>
    7690:	b9401380 	ldr	w0, [x28, #16]
    7694:	52800018 	mov	w24, #0x0                   	// #0
    7698:	7100001f 	cmp	w0, #0x0
    769c:	54003a8d 	b.le	7dec <fwp_write+0x9f8>
    76a0:	f9014bf9 	str	x25, [sp, #656]
    76a4:	d0000019 	adrp	x25, 9000 <__divti3+0x10>
    76a8:	91382339 	add	x25, x25, #0xe08
    76ac:	f9014ffa 	str	x26, [sp, #664]
    76b0:	d000001a 	adrp	x26, 9000 <__divti3+0x10>
    76b4:	9137235a 	add	x26, x26, #0xdc8
    76b8:	91002276 	add	x22, x19, #0x8
    76bc:	d2800013 	mov	x19, #0x0                   	// #0
    76c0:	b5003e73 	cbnz	x19, 7e8c <fwp_write+0xa98>
    76c4:	d37df277 	lsl	x23, x19, #3
    76c8:	34003c98 	cbz	w24, 7e58 <fwp_write+0xa64>
    76cc:	f9401382 	ldr	x2, [x28, #32]
    76d0:	aa1403e0 	mov	x0, x20
    76d4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    76d8:	52800003 	mov	w3, #0x0                   	// #0
    76dc:	f8776842 	ldr	x2, [x2, x23]
    76e0:	91000673 	add	x19, x19, #0x1
    76e4:	97ffff44 	bl	73f4 <fwp_write>
    76e8:	b9401380 	ldr	w0, [x28, #16]
    76ec:	6b13001f 	cmp	w0, w19
    76f0:	54fffe8c 	b.gt	76c0 <fwp_write+0x2cc>
    76f4:	f9414bf9 	ldr	x25, [sp, #656]
    76f8:	f9414ffa 	ldr	x26, [sp, #664]
    76fc:	34003798 	cbz	w24, 7dec <fwp_write+0x9f8>
    7700:	52800523 	mov	w3, #0x29                  	// #41
    7704:	aa1503e1 	mov	x1, x21
    7708:	aa1403e0 	mov	x0, x20
    770c:	d2800022 	mov	x2, #0x1                   	// #1
    7710:	39001fe3 	strb	w3, [sp, #7]
    7714:	97ffefdf 	bl	3690 <buf_put>
    7718:	f9413bf5 	ldr	x21, [sp, #624]
    771c:	f9413ff6 	ldr	x22, [sp, #632]
    7720:	f94143f7 	ldr	x23, [sp, #640]
    7724:	f94147f8 	ldr	x24, [sp, #648]
    7728:	f94153fb 	ldr	x27, [sp, #672]
    772c:	f94157fc 	ldr	x28, [sp, #680]
    7730:	17ffff5d 	b	74a4 <fwp_write+0xb0>
    7734:	b9404855 	ldr	w21, [x2, #72]
    7738:	aa1403e0 	mov	x0, x20
    773c:	93407eb6 	sxtw	x22, w21
    7740:	91000ac1 	add	x1, x22, #0x2
    7744:	97ffef9f 	bl	35c0 <buf_grow>
    7748:	a9400281 	ldp	x1, x0, [x20]
    774c:	528e8603 	mov	w3, #0x7430                	// #29744
    7750:	78206823 	strh	w3, [x1, x0]
    7754:	8b000022 	add	x2, x1, x0
    7758:	710002bf 	cmp	w21, #0x0
    775c:	540036ad 	b.le	7e30 <fwp_write+0xa3c>
    7760:	110006a3 	add	w3, w21, #0x1
    7764:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7768:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    776c:	91000449 	add	x9, x2, #0x1
    7770:	8b23c043 	add	x3, x2, w3, sxtw
    7774:	f28aaac6 	movk	x6, #0x5556
    7778:	f2955568 	movk	x8, #0xaaab
    777c:	1400000d 	b	77b0 <fwp_write+0x3bc>
    7780:	d2800021 	mov	x1, #0x1                   	// #1
    7784:	528005a5 	mov	w5, #0x2d                  	// #45
    7788:	f100001f 	cmp	x0, #0x0
    778c:	9b467e60 	smulh	x0, x19, x6
    7790:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7794:	381ff465 	strb	w5, [x3], #-1
    7798:	cb040000 	sub	x0, x0, x4
    779c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    77a0:	cb020000 	sub	x0, x0, x2
    77a4:	8b010013 	add	x19, x0, x1
    77a8:	eb03013f 	cmp	x9, x3
    77ac:	54003420 	b.eq	7e30 <fwp_write+0xa3c>  // b.none
    77b0:	9b467e60 	smulh	x0, x19, x6
    77b4:	937ffe64 	asr	x4, x19, #63
    77b8:	52800605 	mov	w5, #0x30                  	// #48
    77bc:	cb040000 	sub	x0, x0, x4
    77c0:	8b000400 	add	x0, x0, x0, lsl #1
    77c4:	cb000260 	sub	x0, x19, x0
    77c8:	91000c01 	add	x1, x0, #0x3
    77cc:	9bc87c22 	umulh	x2, x1, x8
    77d0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    77d4:	8b4204e2 	add	x2, x7, x2, lsr #1
    77d8:	eb020021 	subs	x1, x1, x2
    77dc:	54fffd60 	b.eq	7788 <fwp_write+0x394>  // b.none
    77e0:	f100043f 	cmp	x1, #0x1
    77e4:	54fffce1 	b.ne	7780 <fwp_write+0x38c>  // b.any
    77e8:	d2800001 	mov	x1, #0x0                   	// #0
    77ec:	52800565 	mov	w5, #0x2b                  	// #43
    77f0:	17ffffe6 	b	7788 <fwp_write+0x394>
    77f4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    77f8:	f947f400 	ldr	x0, [x0, #4072]
    77fc:	f94127e2 	ldr	x2, [sp, #584]
    7800:	f9400001 	ldr	x1, [x0]
    7804:	eb010042 	subs	x2, x2, x1
    7808:	d2800001 	mov	x1, #0x0                   	// #0
    780c:	540023a1 	b.ne	7c80 <fwp_write+0x88c>  // b.any
    7810:	f9413bf5 	ldr	x21, [sp, #624]
    7814:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7818:	f9413ff6 	ldr	x22, [sp, #632]
    781c:	aa1403e0 	mov	x0, x20
    7820:	9135c021 	add	x1, x1, #0xd70
    7824:	d2800102 	mov	x2, #0x8                   	// #8
    7828:	17ffff77 	b	7604 <fwp_write+0x210>
    782c:	aa1403e0 	mov	x0, x20
    7830:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7834:	d28000c2 	mov	x2, #0x6                   	// #6
    7838:	91374021 	add	x1, x1, #0xdd0
    783c:	97ffef95 	bl	3690 <buf_put>
    7840:	d2800015 	mov	x21, #0x0                   	// #0
    7844:	f9400263 	ldr	x3, [x19]
    7848:	f240f87f 	tst	x3, #0x7fffffffffffffff
    784c:	54002c40 	b.eq	7dd4 <fwp_write+0x9e0>  // b.none
    7850:	f9401f82 	ldr	x2, [x28, #56]
    7854:	f90143f7 	str	x23, [sp, #640]
    7858:	f90147f8 	str	x24, [sp, #648]
    785c:	d2800857 	mov	x23, #0x42                  	// #66
    7860:	f9014bf9 	str	x25, [sp, #656]
    7864:	d0000016 	adrp	x22, 9000 <__divti3+0x10>
    7868:	f9014ffa 	str	x26, [sp, #664]
    786c:	913722d6 	add	x22, x22, #0xdc8
    7870:	d2800038 	mov	x24, #0x1                   	// #1
    7874:	f2a18017 	movk	x23, #0xc00, lsl #16
    7878:	d2809099 	mov	x25, #0x484                 	// #1156
    787c:	b4000482 	cbz	x2, 790c <fwp_write+0x518>
    7880:	b9400040 	ldr	w0, [x2]
    7884:	7100701f 	cmp	w0, #0x1c
    7888:	540042a0 	b.eq	80dc <fwp_write+0xce8>  // b.none
    788c:	71006c1f 	cmp	w0, #0x1b
    7890:	540003e8 	b.hi	790c <fwp_write+0x518>  // b.pmore
    7894:	9ac02301 	lsl	x1, x24, x0
    7898:	ea17003f 	tst	x1, x23
    789c:	54003681 	b.ne	7f6c <fwp_write+0xb78>  // b.any
    78a0:	ea19003f 	tst	x1, x25
    78a4:	54003501 	b.ne	7f44 <fwp_write+0xb50>  // b.any
    78a8:	d2800424 	mov	x4, #0x21                  	// #33
    78ac:	ea04003f 	tst	x1, x4
    78b0:	540002e0 	b.eq	790c <fwp_write+0x518>  // b.none
    78b4:	b7f849a3 	tbnz	x3, #63, 81e8 <fwp_write+0xdf4>
    78b8:	91002261 	add	x1, x19, #0x8
    78bc:	8b150021 	add	x1, x1, x21
    78c0:	39400021 	ldrb	w1, [x1]
    78c4:	7100001f 	cmp	w0, #0x0
    78c8:	93401c23 	sxtb	x3, w1
    78cc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    78d0:	aa1403e0 	mov	x0, x20
    78d4:	52800003 	mov	w3, #0x0                   	// #0
    78d8:	97fffec7 	bl	73f4 <fwp_write>
    78dc:	910006b5 	add	x21, x21, #0x1
    78e0:	f9400260 	ldr	x0, [x19]
    78e4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    78e8:	eb0002bf 	cmp	x21, x0
    78ec:	540026c2 	b.cs	7dc4 <fwp_write+0x9d0>  // b.hs, b.nlast
    78f0:	d2800042 	mov	x2, #0x2                   	// #2
    78f4:	aa1603e1 	mov	x1, x22
    78f8:	aa1403e0 	mov	x0, x20
    78fc:	97ffef65 	bl	3690 <buf_put>
    7900:	f9401f82 	ldr	x2, [x28, #56]
    7904:	f9400263 	ldr	x3, [x19]
    7908:	b5fffbc2 	cbnz	x2, 7880 <fwp_write+0x48c>
    790c:	d37df2a0 	lsl	x0, x21, #3
    7910:	b7f83f03 	tbnz	x3, #63, 80f0 <fwp_write+0xcfc>
    7914:	91002261 	add	x1, x19, #0x8
    7918:	8b000020 	add	x0, x1, x0
    791c:	f9400001 	ldr	x1, [x0]
    7920:	17ffffec 	b	78d0 <fwp_write+0x4dc>
    7924:	a9400e62 	ldp	x2, x3, [x19]
    7928:	b7f83ca3 	tbnz	x3, #63, 80bc <fwp_write+0xcc8>
    792c:	910123f5 	add	x21, sp, #0x48
    7930:	aa1503e0 	mov	x0, x21
    7934:	97ffed3b 	bl	2e20 <fwp_fmt_u128>
    7938:	aa1503e0 	mov	x0, x21
    793c:	97ffeb7d 	bl	2730 <strlen@plt>
    7940:	aa1503e1 	mov	x1, x21
    7944:	aa0003e2 	mov	x2, x0
    7948:	17fffed1 	b	748c <fwp_write+0x98>
    794c:	fd015be8 	str	d8, [sp, #688]
    7950:	1e270268 	fmov	s8, w19
    7954:	fd015fe9 	str	d9, [sp, #696]
    7958:	1e282100 	fcmp	s8, s8
    795c:	54004d26 	b.vs	8300 <fwp_write+0xf0c>
    7960:	1e20c101 	fabs	s1, s8
    7964:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7968:	1e270000 	fmov	s0, w0
    796c:	1e202020 	fcmp	s1, s0
    7970:	54002c0d 	b.le	7ef0 <fwp_write+0xafc>
    7974:	1e202118 	fcmpe	s8, #0.0
    7978:	d0000002 	adrp	x2, 9000 <__divti3+0x10>
    797c:	91222042 	add	x2, x2, #0x888
    7980:	910123f5 	add	x21, sp, #0x48
    7984:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7988:	91348021 	add	x1, x1, #0xd20
    798c:	aa1503e0 	mov	x0, x21
    7990:	9a81c041 	csel	x1, x2, x1, gt
    7994:	97ffec13 	bl	29e0 <strcpy@plt>
    7998:	aa1503e0 	mov	x0, x21
    799c:	97ffeb65 	bl	2730 <strlen@plt>
    79a0:	aa1503e1 	mov	x1, x21
    79a4:	aa0003e2 	mov	x2, x0
    79a8:	aa1403e0 	mov	x0, x20
    79ac:	97ffef39 	bl	3690 <buf_put>
    79b0:	f9413bf5 	ldr	x21, [sp, #624]
    79b4:	f9413ff6 	ldr	x22, [sp, #632]
    79b8:	f94153fb 	ldr	x27, [sp, #672]
    79bc:	f94157fc 	ldr	x28, [sp, #680]
    79c0:	fd415be8 	ldr	d8, [sp, #688]
    79c4:	fd415fe9 	ldr	d9, [sp, #696]
    79c8:	17fffeb7 	b	74a4 <fwp_write+0xb0>
    79cc:	f9400276 	ldr	x22, [x19]
    79d0:	34002e03 	cbz	w3, 7f90 <fwp_write+0xb9c>
    79d4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    79d8:	f947f400 	ldr	x0, [x0, #4072]
    79dc:	f94127e2 	ldr	x2, [sp, #584]
    79e0:	f9400001 	ldr	x1, [x0]
    79e4:	eb010042 	subs	x2, x2, x1
    79e8:	d2800001 	mov	x1, #0x0                   	// #0
    79ec:	540014a1 	b.ne	7c80 <fwp_write+0x88c>  // b.any
    79f0:	aa1603e2 	mov	x2, x22
    79f4:	91002261 	add	x1, x19, #0x8
    79f8:	f9413bf5 	ldr	x21, [sp, #624]
    79fc:	aa1403e0 	mov	x0, x20
    7a00:	f9413ff6 	ldr	x22, [sp, #632]
    7a04:	17ffff00 	b	7604 <fwp_write+0x210>
    7a08:	fd015be8 	str	d8, [sp, #688]
    7a0c:	9e670268 	fmov	d8, x19
    7a10:	fd015fe9 	str	d9, [sp, #696]
    7a14:	1e682100 	fcmp	d8, d8
    7a18:	54004746 	b.vs	8300 <fwp_write+0xf0c>
    7a1c:	1e60c101 	fabs	d1, d8
    7a20:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7a24:	9e670000 	fmov	d0, x0
    7a28:	910123f5 	add	x21, sp, #0x48
    7a2c:	52800033 	mov	w19, #0x1                   	// #1
    7a30:	1e602020 	fcmp	d1, d0
    7a34:	540001ad 	b.le	7a68 <fwp_write+0x674>
    7a38:	1e602118 	fcmpe	d8, #0.0
    7a3c:	d0000002 	adrp	x2, 9000 <__divti3+0x10>
    7a40:	91222042 	add	x2, x2, #0x888
    7a44:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7a48:	91348021 	add	x1, x1, #0xd20
    7a4c:	aa1503e0 	mov	x0, x21
    7a50:	9a81c041 	csel	x1, x2, x1, gt
    7a54:	97ffebe3 	bl	29e0 <strcpy@plt>
    7a58:	17ffffd0 	b	7998 <fwp_write+0x5a4>
    7a5c:	11000673 	add	w19, w19, #0x1
    7a60:	71004a7f 	cmp	w19, #0x12
    7a64:	54003860 	b.eq	8170 <fwp_write+0xd7c>  // b.none
    7a68:	1e604100 	fmov	d0, d8
    7a6c:	2a1303e1 	mov	w1, w19
    7a70:	aa1503e0 	mov	x0, x21
    7a74:	97fff048 	bl	3b94 <fwp_format_g.constprop.0>
    7a78:	aa1503e0 	mov	x0, x21
    7a7c:	d2800001 	mov	x1, #0x0                   	// #0
    7a80:	97ffeb40 	bl	2780 <strtod@plt>
    7a84:	1e602100 	fcmp	d8, d0
    7a88:	54fffea1 	b.ne	7a5c <fwp_write+0x668>  // b.any
    7a8c:	aa1503e0 	mov	x0, x21
    7a90:	97ffef39 	bl	3774 <fwp_finish_float>
    7a94:	17ffffc1 	b	7998 <fwp_write+0x5a4>
    7a98:	a9400e62 	ldp	x2, x3, [x19]
    7a9c:	910123f3 	add	x19, sp, #0x48
    7aa0:	aa1303e0 	mov	x0, x19
    7aa4:	97ffecdf 	bl	2e20 <fwp_fmt_u128>
    7aa8:	17fffe75 	b	747c <fwp_write+0x88>
    7aac:	f90143f7 	str	x23, [sp, #640]
    7ab0:	f90147f8 	str	x24, [sp, #648]
    7ab4:	2a1303f8 	mov	w24, w19
    7ab8:	f9014bf9 	str	x25, [sp, #656]
    7abc:	f9014ffa 	str	x26, [sp, #664]
    7ac0:	f13ffe7f 	cmp	x19, #0xfff
    7ac4:	54000049 	b.ls	7acc <fwp_write+0x6d8>  // b.plast
    7ac8:	b9400278 	ldr	w24, [x19]
    7acc:	f9400f80 	ldr	x0, [x28, #24]
    7ad0:	2a1803f5 	mov	w21, w24
    7ad4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7ad8:	d37ef6b9 	lsl	x25, x21, #2
    7adc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7ae0:	aa1603e0 	mov	x0, x22
    7ae4:	97ffeb13 	bl	2730 <strlen@plt>
    7ae8:	aa1603e1 	mov	x1, x22
    7aec:	aa0003e2 	mov	x2, x0
    7af0:	aa1403e0 	mov	x0, x20
    7af4:	97ffeee7 	bl	3690 <buf_put>
    7af8:	f9401780 	ldr	x0, [x28, #40]
    7afc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7b00:	7100001f 	cmp	w0, #0x0
    7b04:	5400068d 	b.le	7bd4 <fwp_write+0x7e0>
    7b08:	91002276 	add	x22, x19, #0x8
    7b0c:	91001ff5 	add	x21, sp, #0x7
    7b10:	d280001b 	mov	x27, #0x0                   	// #0
    7b14:	5280041a 	mov	w26, #0x20                  	// #32
    7b18:	f9401b80 	ldr	x0, [x28, #48]
    7b1c:	aa1503e1 	mov	x1, x21
    7b20:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7b24:	d2800022 	mov	x2, #0x1                   	// #1
    7b28:	f8786803 	ldr	x3, [x0, x24]
    7b2c:	aa1403e0 	mov	x0, x20
    7b30:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7b34:	39001ffa 	strb	w26, [sp, #7]
    7b38:	97ffeed6 	bl	3690 <buf_put>
    7b3c:	f13ffeff 	cmp	x23, #0xfff
    7b40:	b9400261 	ldr	w1, [x19]
    7b44:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7b48:	7100383f 	cmp	w1, #0xe
    7b4c:	54000160 	b.eq	7b78 <fwp_write+0x784>  // b.none
    7b50:	7100403f 	cmp	w1, #0x10
    7b54:	54001a60 	b.eq	7ea0 <fwp_write+0xaac>  // b.none
    7b58:	7100283f 	cmp	w1, #0xa
    7b5c:	54002aa0 	b.eq	80b0 <fwp_write+0xcbc>  // b.none
    7b60:	540014ac 	b.gt	7df4 <fwp_write+0xa00>
    7b64:	71000c3f 	cmp	w1, #0x3
    7b68:	540029ac 	b.gt	809c <fwp_write+0xca8>
    7b6c:	d37ffee0 	lsr	x0, x23, #63
    7b70:	37f814a1 	tbnz	w1, #31, 7e04 <fwp_write+0xa10>
    7b74:	d503201f 	nop
    7b78:	34001460 	cbz	w0, 7e04 <fwp_write+0xa10>
    7b7c:	52800503 	mov	w3, #0x28                  	// #40
    7b80:	aa1503e1 	mov	x1, x21
    7b84:	aa1403e0 	mov	x0, x20
    7b88:	d2800022 	mov	x2, #0x1                   	// #1
    7b8c:	39001fe3 	strb	w3, [sp, #7]
    7b90:	97ffeec0 	bl	3690 <buf_put>
    7b94:	aa1303e2 	mov	x2, x19
    7b98:	aa1703e1 	mov	x1, x23
    7b9c:	aa1403e0 	mov	x0, x20
    7ba0:	52800003 	mov	w3, #0x0                   	// #0
    7ba4:	97fffe14 	bl	73f4 <fwp_write>
    7ba8:	52800523 	mov	w3, #0x29                  	// #41
    7bac:	aa1503e1 	mov	x1, x21
    7bb0:	aa1403e0 	mov	x0, x20
    7bb4:	d2800022 	mov	x2, #0x1                   	// #1
    7bb8:	39001fe3 	strb	w3, [sp, #7]
    7bbc:	97ffeeb5 	bl	3690 <buf_put>
    7bc0:	f9401780 	ldr	x0, [x28, #40]
    7bc4:	9100077b 	add	x27, x27, #0x1
    7bc8:	b8796800 	ldr	w0, [x0, x25]
    7bcc:	6b1b001f 	cmp	w0, w27
    7bd0:	54fffa4c 	b.gt	7b18 <fwp_write+0x724>
    7bd4:	f9413bf5 	ldr	x21, [sp, #624]
    7bd8:	f9413ff6 	ldr	x22, [sp, #632]
    7bdc:	f94143f7 	ldr	x23, [sp, #640]
    7be0:	f94147f8 	ldr	x24, [sp, #648]
    7be4:	f9414bf9 	ldr	x25, [sp, #656]
    7be8:	f9414ffa 	ldr	x26, [sp, #664]
    7bec:	f94153fb 	ldr	x27, [sp, #672]
    7bf0:	f94157fc 	ldr	x28, [sp, #680]
    7bf4:	17fffe2c 	b	74a4 <fwp_write+0xb0>
    7bf8:	52800783 	mov	w3, #0x3c                  	// #60
    7bfc:	91001ff3 	add	x19, sp, #0x7
    7c00:	aa1303e1 	mov	x1, x19
    7c04:	d2800022 	mov	x2, #0x1                   	// #1
    7c08:	aa1403e0 	mov	x0, x20
    7c0c:	39001fe3 	strb	w3, [sp, #7]
    7c10:	97ffeea0 	bl	3690 <buf_put>
    7c14:	f9400795 	ldr	x21, [x28, #8]
    7c18:	aa1503e0 	mov	x0, x21
    7c1c:	97ffeac5 	bl	2730 <strlen@plt>
    7c20:	aa1503e1 	mov	x1, x21
    7c24:	aa0003e2 	mov	x2, x0
    7c28:	aa1403e0 	mov	x0, x20
    7c2c:	97ffee99 	bl	3690 <buf_put>
    7c30:	528007c3 	mov	w3, #0x3e                  	// #62
    7c34:	aa1303e1 	mov	x1, x19
    7c38:	aa1403e0 	mov	x0, x20
    7c3c:	d2800022 	mov	x2, #0x1                   	// #1
    7c40:	39001fe3 	strb	w3, [sp, #7]
    7c44:	17fffe13 	b	7490 <fwp_write+0x9c>
    7c48:	f100067f 	cmp	x19, #0x1
    7c4c:	540025a0 	b.eq	8100 <fwp_write+0xd0c>  // b.none
    7c50:	b100067f 	cmn	x19, #0x1
    7c54:	54002bc0 	b.eq	81cc <fwp_write+0xdd8>  // b.none
    7c58:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7c5c:	9134a021 	add	x1, x1, #0xd28
    7c60:	d2800022 	mov	x2, #0x1                   	// #1
    7c64:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7c68:	f947f400 	ldr	x0, [x0, #4072]
    7c6c:	f94127e4 	ldr	x4, [sp, #584]
    7c70:	f9400003 	ldr	x3, [x0]
    7c74:	eb030084 	subs	x4, x4, x3
    7c78:	d2800003 	mov	x3, #0x0                   	// #0
    7c7c:	54ffebe0 	b.eq	79f8 <fwp_write+0x604>  // b.none
    7c80:	f90143f7 	str	x23, [sp, #640]
    7c84:	f90147f8 	str	x24, [sp, #648]
    7c88:	f9014bf9 	str	x25, [sp, #656]
    7c8c:	f9014ffa 	str	x26, [sp, #664]
    7c90:	fd015be8 	str	d8, [sp, #688]
    7c94:	fd015fe9 	str	d9, [sp, #696]
    7c98:	97ffeb02 	bl	28a0 <__stack_chk_fail@plt>
    7c9c:	52800b63 	mov	w3, #0x5b                  	// #91
    7ca0:	91001ff5 	add	x21, sp, #0x7
    7ca4:	aa1503e1 	mov	x1, x21
    7ca8:	aa1403e0 	mov	x0, x20
    7cac:	d2800022 	mov	x2, #0x1                   	// #1
    7cb0:	d0000016 	adrp	x22, 9000 <__divti3+0x10>
    7cb4:	913722d6 	add	x22, x22, #0xdc8
    7cb8:	39001fe3 	strb	w3, [sp, #7]
    7cbc:	97ffee75 	bl	3690 <buf_put>
    7cc0:	b4000273 	cbz	x19, 7d0c <fwp_write+0x918>
    7cc4:	f9400661 	ldr	x1, [x19, #8]
    7cc8:	aa1403e0 	mov	x0, x20
    7ccc:	f9401f82 	ldr	x2, [x28, #56]
    7cd0:	52800003 	mov	w3, #0x0                   	// #0
    7cd4:	97fffdc8 	bl	73f4 <fwp_write>
    7cd8:	f9400a73 	ldr	x19, [x19, #16]
    7cdc:	b4000193 	cbz	x19, 7d0c <fwp_write+0x918>
    7ce0:	aa1603e1 	mov	x1, x22
    7ce4:	aa1403e0 	mov	x0, x20
    7ce8:	d2800042 	mov	x2, #0x2                   	// #2
    7cec:	97ffee69 	bl	3690 <buf_put>
    7cf0:	f9400661 	ldr	x1, [x19, #8]
    7cf4:	aa1403e0 	mov	x0, x20
    7cf8:	f9401f82 	ldr	x2, [x28, #56]
    7cfc:	52800003 	mov	w3, #0x0                   	// #0
    7d00:	97fffdbd 	bl	73f4 <fwp_write>
    7d04:	f9400a73 	ldr	x19, [x19, #16]
    7d08:	b5fffed3 	cbnz	x19, 7ce0 <fwp_write+0x8ec>
    7d0c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7d10:	aa1503e1 	mov	x1, x21
    7d14:	aa1403e0 	mov	x0, x20
    7d18:	d2800022 	mov	x2, #0x1                   	// #1
    7d1c:	39001fe3 	strb	w3, [sp, #7]
    7d20:	17fffddc 	b	7490 <fwp_write+0x9c>
    7d24:	aa1403e0 	mov	x0, x20
    7d28:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7d2c:	d28000c2 	mov	x2, #0x6                   	// #6
    7d30:	9136e021 	add	x1, x1, #0xdb8
    7d34:	97ffee57 	bl	3690 <buf_put>
    7d38:	f9400260 	ldr	x0, [x19]
    7d3c:	b40004c0 	cbz	x0, 7dd4 <fwp_write+0x9e0>
    7d40:	910123f5 	add	x21, sp, #0x48
    7d44:	91002276 	add	x22, x19, #0x8
    7d48:	f90143f7 	str	x23, [sp, #640]
    7d4c:	d2800017 	mov	x23, #0x0                   	// #0
    7d50:	f90147f8 	str	x24, [sp, #648]
    7d54:	d0000018 	adrp	x24, 9000 <__divti3+0x10>
    7d58:	91370318 	add	x24, x24, #0xdc0
    7d5c:	f9014bf9 	str	x25, [sp, #656]
    7d60:	d0000019 	adrp	x25, 9000 <__divti3+0x10>
    7d64:	91372339 	add	x25, x25, #0xdc8
    7d68:	f9014ffa 	str	x26, [sp, #664]
    7d6c:	14000005 	b	7d80 <fwp_write+0x98c>
    7d70:	aa1903e1 	mov	x1, x25
    7d74:	aa1403e0 	mov	x0, x20
    7d78:	d2800042 	mov	x2, #0x2                   	// #2
    7d7c:	97ffee45 	bl	3690 <buf_put>
    7d80:	38776ac5 	ldrb	w5, [x22, x23]
    7d84:	d2804003 	mov	x3, #0x200                 	// #512
    7d88:	aa1803e4 	mov	x4, x24
    7d8c:	aa0303e1 	mov	x1, x3
    7d90:	52800042 	mov	w2, #0x2                   	// #2
    7d94:	aa1503e0 	mov	x0, x21
    7d98:	910006f7 	add	x23, x23, #0x1
    7d9c:	97ffea9d 	bl	2810 <__snprintf_chk@plt>
    7da0:	aa1503e0 	mov	x0, x21
    7da4:	97ffea63 	bl	2730 <strlen@plt>
    7da8:	aa1503e1 	mov	x1, x21
    7dac:	aa0003e2 	mov	x2, x0
    7db0:	aa1403e0 	mov	x0, x20
    7db4:	97ffee37 	bl	3690 <buf_put>
    7db8:	f9400260 	ldr	x0, [x19]
    7dbc:	eb17001f 	cmp	x0, x23
    7dc0:	54fffd88 	b.hi	7d70 <fwp_write+0x97c>  // b.pmore
    7dc4:	f94143f7 	ldr	x23, [sp, #640]
    7dc8:	f94147f8 	ldr	x24, [sp, #648]
    7dcc:	f9414bf9 	ldr	x25, [sp, #656]
    7dd0:	f9414ffa 	ldr	x26, [sp, #664]
    7dd4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7dd8:	aa1403e0 	mov	x0, x20
    7ddc:	91001fe1 	add	x1, sp, #0x7
    7de0:	d2800022 	mov	x2, #0x1                   	// #1
    7de4:	39001fe3 	strb	w3, [sp, #7]
    7de8:	17fffdaa 	b	7490 <fwp_write+0x9c>
    7dec:	52800fa3 	mov	w3, #0x7d                  	// #125
    7df0:	17fffe45 	b	7704 <fwp_write+0x310>
    7df4:	f10002ff 	cmp	x23, #0x0
    7df8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7dfc:	71002c3f 	cmp	w1, #0xb
    7e00:	54ffebc0 	b.eq	7b78 <fwp_write+0x784>  // b.none
    7e04:	aa1303e2 	mov	x2, x19
    7e08:	aa1703e1 	mov	x1, x23
    7e0c:	aa1403e0 	mov	x0, x20
    7e10:	52800003 	mov	w3, #0x0                   	// #0
    7e14:	97fffd78 	bl	73f4 <fwp_write>
    7e18:	17ffff6a 	b	7bc0 <fwp_write+0x7cc>
    7e1c:	aa1403e0 	mov	x0, x20
    7e20:	91001fe1 	add	x1, sp, #0x7
    7e24:	52800fa3 	mov	w3, #0x7d                  	// #125
    7e28:	d2800022 	mov	x2, #0x1                   	// #1
    7e2c:	17fffe39 	b	7710 <fwp_write+0x31c>
    7e30:	a9400281 	ldp	x1, x0, [x20]
    7e34:	91000800 	add	x0, x0, #0x2
    7e38:	8b160000 	add	x0, x0, x22
    7e3c:	f9000680 	str	x0, [x20, #8]
    7e40:	3820683f 	strb	wzr, [x1, x0]
    7e44:	f9413bf5 	ldr	x21, [sp, #624]
    7e48:	f9413ff6 	ldr	x22, [sp, #632]
    7e4c:	f94153fb 	ldr	x27, [sp, #672]
    7e50:	f94157fc 	ldr	x28, [sp, #680]
    7e54:	17fffd94 	b	74a4 <fwp_write+0xb0>
    7e58:	f9400f80 	ldr	x0, [x28, #24]
    7e5c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7e60:	aa1b03e0 	mov	x0, x27
    7e64:	97ffea33 	bl	2730 <strlen@plt>
    7e68:	aa1b03e1 	mov	x1, x27
    7e6c:	aa0003e2 	mov	x2, x0
    7e70:	aa1403e0 	mov	x0, x20
    7e74:	97ffee07 	bl	3690 <buf_put>
    7e78:	aa1903e1 	mov	x1, x25
    7e7c:	aa1403e0 	mov	x0, x20
    7e80:	d2800062 	mov	x2, #0x3                   	// #3
    7e84:	97ffee03 	bl	3690 <buf_put>
    7e88:	17fffe11 	b	76cc <fwp_write+0x2d8>
    7e8c:	aa1a03e1 	mov	x1, x26
    7e90:	aa1403e0 	mov	x0, x20
    7e94:	d2800042 	mov	x2, #0x2                   	// #2
    7e98:	97ffedfe 	bl	3690 <buf_put>
    7e9c:	17fffe0a 	b	76c4 <fwp_write+0x2d0>
    7ea0:	f9400660 	ldr	x0, [x19, #8]
    7ea4:	b4fffb00 	cbz	x0, 7e04 <fwp_write+0xa10>
    7ea8:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7eac:	91378021 	add	x1, x1, #0xde0
    7eb0:	97ffea9c 	bl	2920 <strcmp@plt>
    7eb4:	7100001f 	cmp	w0, #0x0
    7eb8:	1a9f07e0 	cset	w0, ne	// ne = any
    7ebc:	17ffff2f 	b	7b78 <fwp_write+0x784>
    7ec0:	aa1403e0 	mov	x0, x20
    7ec4:	d2800042 	mov	x2, #0x2                   	// #2
    7ec8:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7ecc:	91376021 	add	x1, x1, #0xdd8
    7ed0:	97ffedf0 	bl	3690 <buf_put>
    7ed4:	91004261 	add	x1, x19, #0x10
    7ed8:	aa1403e0 	mov	x0, x20
    7edc:	f9402382 	ldr	x2, [x28, #64]
    7ee0:	52800003 	mov	w3, #0x0                   	// #0
    7ee4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7ee8:	97fffd43 	bl	73f4 <fwp_write>
    7eec:	17fffd9d 	b	7560 <fwp_write+0x16c>
    7ef0:	1e22c109 	fcvt	d9, s8
    7ef4:	910123f5 	add	x21, sp, #0x48
    7ef8:	52800033 	mov	w19, #0x1                   	// #1
    7efc:	d503201f 	nop
    7f00:	1e604120 	fmov	d0, d9
    7f04:	2a1303e1 	mov	w1, w19
    7f08:	aa1503e0 	mov	x0, x21
    7f0c:	97ffef22 	bl	3b94 <fwp_format_g.constprop.0>
    7f10:	aa1503e0 	mov	x0, x21
    7f14:	d2800001 	mov	x1, #0x0                   	// #0
    7f18:	97ffea8e 	bl	2950 <strtof@plt>
    7f1c:	1e202100 	fcmp	s8, s0
    7f20:	54ffdb60 	b.eq	7a8c <fwp_write+0x698>  // b.none
    7f24:	11000673 	add	w19, w19, #0x1
    7f28:	71002a7f 	cmp	w19, #0xa
    7f2c:	54fffea1 	b.ne	7f00 <fwp_write+0xb0c>  // b.any
    7f30:	1e604120 	fmov	d0, d9
    7f34:	aa1503e0 	mov	x0, x21
    7f38:	52800121 	mov	w1, #0x9                   	// #9
    7f3c:	97ffef16 	bl	3b94 <fwp_format_g.constprop.0>
    7f40:	17fffed3 	b	7a8c <fwp_write+0x698>
    7f44:	d37ef6a1 	lsl	x1, x21, #2
    7f48:	b7f81563 	tbnz	x3, #63, 81f4 <fwp_write+0xe00>
    7f4c:	91002263 	add	x3, x19, #0x8
    7f50:	8b010061 	add	x1, x3, x1
    7f54:	b9400023 	ldr	w3, [x1]
    7f58:	7100081f 	cmp	w0, #0x2
    7f5c:	2a0303e1 	mov	w1, w3
    7f60:	93407c63 	sxtw	x3, w3
    7f64:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7f68:	17fffe5a 	b	78d0 <fwp_write+0x4dc>
    7f6c:	d37ffaa1 	lsl	x1, x21, #1
    7f70:	b7f81363 	tbnz	x3, #63, 81dc <fwp_write+0xde8>
    7f74:	91002263 	add	x3, x19, #0x8
    7f78:	8b010061 	add	x1, x3, x1
    7f7c:	79400021 	ldrh	w1, [x1]
    7f80:	7100041f 	cmp	w0, #0x1
    7f84:	93403c23 	sxth	x3, w1
    7f88:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7f8c:	17fffe51 	b	78d0 <fwp_write+0x4dc>
    7f90:	52800443 	mov	w3, #0x22                  	// #34
    7f94:	91001ff5 	add	x21, sp, #0x7
    7f98:	91002273 	add	x19, x19, #0x8
    7f9c:	aa1503e1 	mov	x1, x21
    7fa0:	aa1403e0 	mov	x0, x20
    7fa4:	d2800022 	mov	x2, #0x1                   	// #1
    7fa8:	39001fe3 	strb	w3, [sp, #7]
    7fac:	f90143f7 	str	x23, [sp, #640]
    7fb0:	8b160277 	add	x23, x19, x22
    7fb4:	f90147f8 	str	x24, [sp, #648]
    7fb8:	97ffedb6 	bl	3690 <buf_put>
    7fbc:	b4000696 	cbz	x22, 808c <fwp_write+0xc98>
    7fc0:	d0000018 	adrp	x24, 9000 <__divti3+0x10>
    7fc4:	91362318 	add	x24, x24, #0xd88
    7fc8:	f9014bf9 	str	x25, [sp, #656]
    7fcc:	d0000019 	adrp	x25, 9000 <__divti3+0x10>
    7fd0:	9136a339 	add	x25, x25, #0xda8
    7fd4:	f9014ffa 	str	x26, [sp, #664]
    7fd8:	1400000d 	b	800c <fwp_write+0xc18>
    7fdc:	710024bf 	cmp	w5, #0x9
    7fe0:	54000460 	b.eq	806c <fwp_write+0xc78>  // b.none
    7fe4:	710028bf 	cmp	w5, #0xa
    7fe8:	54000a61 	b.ne	8134 <fwp_write+0xd40>  // b.any
    7fec:	d0000001 	adrp	x1, 9000 <__divti3+0x10>
    7ff0:	aa1403e0 	mov	x0, x20
    7ff4:	91366021 	add	x1, x1, #0xd98
    7ff8:	d2800042 	mov	x2, #0x2                   	// #2
    7ffc:	97ffeda5 	bl	3690 <buf_put>
    8000:	91000673 	add	x19, x19, #0x1
    8004:	eb17027f 	cmp	x19, x23
    8008:	540003e0 	b.eq	8084 <fwp_write+0xc90>  // b.none
    800c:	39400265 	ldrb	w5, [x19]
    8010:	710034bf 	cmp	w5, #0xd
    8014:	54000180 	b.eq	8044 <fwp_write+0xc50>  // b.none
    8018:	54fffe29 	b.ls	7fdc <fwp_write+0xbe8>  // b.plast
    801c:	710088bf 	cmp	w5, #0x22
    8020:	540001c0 	b.eq	8058 <fwp_write+0xc64>  // b.none
    8024:	710170bf 	cmp	w5, #0x5c
    8028:	54000741 	b.ne	8110 <fwp_write+0xd1c>  // b.any
    802c:	aa1403e0 	mov	x0, x20
    8030:	b0000001 	adrp	x1, 9000 <__divti3+0x10>
    8034:	d2800042 	mov	x2, #0x2                   	// #2
    8038:	91364021 	add	x1, x1, #0xd90
    803c:	97ffed95 	bl	3690 <buf_put>
    8040:	17fffff0 	b	8000 <fwp_write+0xc0c>
    8044:	aa1903e1 	mov	x1, x25
    8048:	aa1403e0 	mov	x0, x20
    804c:	d2800042 	mov	x2, #0x2                   	// #2
    8050:	97ffed90 	bl	3690 <buf_put>
    8054:	17ffffeb 	b	8000 <fwp_write+0xc0c>
    8058:	aa1803e1 	mov	x1, x24
    805c:	aa1403e0 	mov	x0, x20
    8060:	d2800042 	mov	x2, #0x2                   	// #2
    8064:	97ffed8b 	bl	3690 <buf_put>
    8068:	17ffffe6 	b	8000 <fwp_write+0xc0c>
    806c:	aa1403e0 	mov	x0, x20
    8070:	b0000001 	adrp	x1, 9000 <__divti3+0x10>
    8074:	d2800042 	mov	x2, #0x2                   	// #2
    8078:	91368021 	add	x1, x1, #0xda0
    807c:	97ffed85 	bl	3690 <buf_put>
    8080:	17ffffe0 	b	8000 <fwp_write+0xc0c>
    8084:	f9414bf9 	ldr	x25, [sp, #656]
    8088:	f9414ffa 	ldr	x26, [sp, #664]
    808c:	aa1503e1 	mov	x1, x21
    8090:	aa1403e0 	mov	x0, x20
    8094:	52800443 	mov	w3, #0x22                  	// #34
    8098:	17fffd9d 	b	770c <fwp_write+0x318>
    809c:	7100103f 	cmp	w1, #0x4
    80a0:	54ffeb21 	b.ne	7e04 <fwp_write+0xa10>  // b.any
    80a4:	f94006e0 	ldr	x0, [x23, #8]
    80a8:	d37ffc00 	lsr	x0, x0, #63
    80ac:	17fffeb3 	b	7b78 <fwp_write+0x784>
    80b0:	710002ff 	cmp	w23, #0x0
    80b4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    80b8:	17fffeb0 	b	7b78 <fwp_write+0x784>
    80bc:	528005a1 	mov	w1, #0x2d                  	// #45
    80c0:	eb0203e2 	negs	x2, x2
    80c4:	da0303e3 	ngc	x3, x3
    80c8:	910127e0 	add	x0, sp, #0x49
    80cc:	910123f5 	add	x21, sp, #0x48
    80d0:	390123e1 	strb	w1, [sp, #72]
    80d4:	97ffeb53 	bl	2e20 <fwp_fmt_u128>
    80d8:	17fffe18 	b	7938 <fwp_write+0x544>
    80dc:	d37ceea1 	lsl	x1, x21, #4
    80e0:	b7f810a3 	tbnz	x3, #63, 82f4 <fwp_write+0xf00>
    80e4:	91002260 	add	x0, x19, #0x8
    80e8:	8b010001 	add	x1, x0, x1
    80ec:	17fffdf9 	b	78d0 <fwp_write+0x4dc>
    80f0:	f9400a61 	ldr	x1, [x19, #16]
    80f4:	8b010000 	add	x0, x0, x1
    80f8:	f9400001 	ldr	x1, [x0]
    80fc:	17fffdf5 	b	78d0 <fwp_write+0x4dc>
    8100:	b0000001 	adrp	x1, 9000 <__divti3+0x10>
    8104:	d2800042 	mov	x2, #0x2                   	// #2
    8108:	9134c021 	add	x1, x1, #0xd30
    810c:	17fffed6 	b	7c64 <fwp_write+0x870>
    8110:	7101fcbf 	cmp	w5, #0x7f
    8114:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8118:	540000e9 	b.ls	8134 <fwp_write+0xd40>  // b.plast
    811c:	aa1503e1 	mov	x1, x21
    8120:	aa1403e0 	mov	x0, x20
    8124:	d2800022 	mov	x2, #0x1                   	// #1
    8128:	39001fe5 	strb	w5, [sp, #7]
    812c:	97ffed59 	bl	3690 <buf_put>
    8130:	17ffffb4 	b	8000 <fwp_write+0xc0c>
    8134:	d2800203 	mov	x3, #0x10                  	// #16
    8138:	b0000004 	adrp	x4, 9000 <__divti3+0x10>
    813c:	aa0303e1 	mov	x1, x3
    8140:	9136c084 	add	x4, x4, #0xdb0
    8144:	910123f6 	add	x22, sp, #0x48
    8148:	52800042 	mov	w2, #0x2                   	// #2
    814c:	aa1603e0 	mov	x0, x22
    8150:	97ffe9b0 	bl	2810 <__snprintf_chk@plt>
    8154:	aa1603e0 	mov	x0, x22
    8158:	97ffe976 	bl	2730 <strlen@plt>
    815c:	aa1603e1 	mov	x1, x22
    8160:	aa0003e2 	mov	x2, x0
    8164:	aa1403e0 	mov	x0, x20
    8168:	97ffed4a 	bl	3690 <buf_put>
    816c:	17ffffa5 	b	8000 <fwp_write+0xc0c>
    8170:	1e604100 	fmov	d0, d8
    8174:	aa1503e0 	mov	x0, x21
    8178:	52800221 	mov	w1, #0x11                  	// #17
    817c:	97ffee86 	bl	3b94 <fwp_format_g.constprop.0>
    8180:	17fffe43 	b	7a8c <fwp_write+0x698>
    8184:	b9401040 	ldr	w0, [x2, #16]
    8188:	350003c0 	cbnz	w0, 8200 <fwp_write+0xe0c>
    818c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8190:	f947f400 	ldr	x0, [x0, #4072]
    8194:	f94127e2 	ldr	x2, [sp, #584]
    8198:	f9400001 	ldr	x1, [x0]
    819c:	eb010042 	subs	x2, x2, x1
    81a0:	d2800001 	mov	x1, #0x0                   	// #0
    81a4:	54ffd721 	b.ne	7c88 <fwp_write+0x894>  // b.any
    81a8:	f9413bf5 	ldr	x21, [sp, #624]
    81ac:	b0000001 	adrp	x1, 9000 <__divti3+0x10>
    81b0:	f9413ff6 	ldr	x22, [sp, #632]
    81b4:	aa1403e0 	mov	x0, x20
    81b8:	f94143f7 	ldr	x23, [sp, #640]
    81bc:	91380021 	add	x1, x1, #0xe00
    81c0:	f94147f8 	ldr	x24, [sp, #648]
    81c4:	d2800042 	mov	x2, #0x2                   	// #2
    81c8:	17fffd0f 	b	7604 <fwp_write+0x210>
    81cc:	b0000001 	adrp	x1, 9000 <__divti3+0x10>
    81d0:	d2800042 	mov	x2, #0x2                   	// #2
    81d4:	9134e021 	add	x1, x1, #0xd38
    81d8:	17fffea3 	b	7c64 <fwp_write+0x870>
    81dc:	f9400a63 	ldr	x3, [x19, #16]
    81e0:	8b030021 	add	x1, x1, x3
    81e4:	17ffff66 	b	7f7c <fwp_write+0xb88>
    81e8:	f9400a61 	ldr	x1, [x19, #16]
    81ec:	8b0102a1 	add	x1, x21, x1
    81f0:	17fffdb4 	b	78c0 <fwp_write+0x4cc>
    81f4:	f9400a63 	ldr	x3, [x19, #16]
    81f8:	8b030021 	add	x1, x1, x3
    81fc:	17ffff56 	b	7f54 <fwp_write+0xb60>
    8200:	b9404840 	ldr	w0, [x2, #72]
    8204:	91001ff5 	add	x21, sp, #0x7
    8208:	34ffa380 	cbz	w0, 7678 <fwp_write+0x284>
    820c:	52800503 	mov	w3, #0x28                  	// #40
    8210:	aa1403e0 	mov	x0, x20
    8214:	aa1503e1 	mov	x1, x21
    8218:	d2800022 	mov	x2, #0x1                   	// #1
    821c:	39001fe3 	strb	w3, [sp, #7]
    8220:	97ffed1c 	bl	3690 <buf_put>
    8224:	b9401380 	ldr	w0, [x28, #16]
    8228:	52800038 	mov	w24, #0x1                   	// #1
    822c:	7100001f 	cmp	w0, #0x0
    8230:	54ffa38c 	b.gt	76a0 <fwp_write+0x2ac>
    8234:	17fffd33 	b	7700 <fwp_write+0x30c>
    8238:	f9014bf9 	str	x25, [sp, #656]
    823c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x12708>
    8240:	f9014ffa 	str	x26, [sp, #664]
    8244:	f9400676 	ldr	x22, [x19, #8]
    8248:	910ac333 	add	x19, x25, #0x2b0
    824c:	91002273 	add	x19, x19, #0x8
    8250:	937ffed8 	asr	x24, x22, #63
    8254:	aa1802c0 	orr	x0, x22, x24
    8258:	b5000320 	cbnz	x0, 82bc <fwp_write+0xec8>
    825c:	110006b5 	add	w21, w21, #0x1
    8260:	710016bf 	cmp	w21, #0x5
    8264:	54ffffc1 	b.ne	825c <fwp_write+0xe68>  // b.any
    8268:	b7f80578 	tbnz	x24, #63, 8314 <fwp_write+0xf20>
    826c:	910023f3 	add	x19, sp, #0x8
    8270:	aa1603e2 	mov	x2, x22
    8274:	aa1303e0 	mov	x0, x19
    8278:	d2800003 	mov	x3, #0x0                   	// #0
    827c:	97ffeae9 	bl	2e20 <fwp_fmt_u128>
    8280:	910123f5 	add	x21, sp, #0x48
    8284:	b0000003 	adrp	x3, 9000 <__divti3+0x10>
    8288:	aa1303e4 	mov	x4, x19
    828c:	aa1503e0 	mov	x0, x21
    8290:	9137e063 	add	x3, x3, #0xdf8
    8294:	d2804002 	mov	x2, #0x200                 	// #512
    8298:	52800041 	mov	w1, #0x2                   	// #2
    829c:	97ffe929 	bl	2740 <__sprintf_chk@plt>
    82a0:	aa1503e0 	mov	x0, x21
    82a4:	97ffe923 	bl	2730 <strlen@plt>
    82a8:	aa1503e1 	mov	x1, x21
    82ac:	aa0003e2 	mov	x2, x0
    82b0:	aa1403e0 	mov	x0, x20
    82b4:	97ffecf7 	bl	3690 <buf_put>
    82b8:	17fffe47 	b	7bd4 <fwp_write+0x7e0>
    82bc:	f9400277 	ldr	x23, [x19]
    82c0:	aa1603e0 	mov	x0, x22
    82c4:	aa1803e1 	mov	x1, x24
    82c8:	aa1703e2 	mov	x2, x23
    82cc:	937ffefa 	asr	x26, x23, #63
    82d0:	aa1a03e3 	mov	x3, x26
    82d4:	94000427 	bl	9370 <__modti3>
    82d8:	aa010000 	orr	x0, x0, x1
    82dc:	b40002c0 	cbz	x0, 8334 <fwp_write+0xf40>
    82e0:	110006b5 	add	w21, w21, #0x1
    82e4:	91004273 	add	x19, x19, #0x10
    82e8:	710016bf 	cmp	w21, #0x5
    82ec:	54fffe81 	b.ne	82bc <fwp_write+0xec8>  // b.any
    82f0:	17ffffde 	b	8268 <fwp_write+0xe74>
    82f4:	f9400a60 	ldr	x0, [x19, #16]
    82f8:	8b000021 	add	x1, x1, x0
    82fc:	17fffd75 	b	78d0 <fwp_write+0x4dc>
    8300:	528c29c0 	mov	w0, #0x614e                	// #24910
    8304:	910123f5 	add	x21, sp, #0x48
    8308:	72a009c0 	movk	w0, #0x4e, lsl #16
    830c:	b9004be0 	str	w0, [sp, #72]
    8310:	17fffda2 	b	7998 <fwp_write+0x5a4>
    8314:	528005a1 	mov	w1, #0x2d                  	// #45
    8318:	eb1603e2 	negs	x2, x22
    831c:	da1803e3 	ngc	x3, x24
    8320:	910027e0 	add	x0, sp, #0x9
    8324:	910023f3 	add	x19, sp, #0x8
    8328:	390023e1 	strb	w1, [sp, #8]
    832c:	97ffeabd 	bl	2e20 <fwp_fmt_u128>
    8330:	17ffffd4 	b	8280 <fwp_write+0xe8c>
    8334:	aa1703e2 	mov	x2, x23
    8338:	aa1a03e3 	mov	x3, x26
    833c:	aa1603e0 	mov	x0, x22
    8340:	aa1803e1 	mov	x1, x24
    8344:	9400032b 	bl	8ff0 <__divti3>
    8348:	aa0003e2 	mov	x2, x0
    834c:	aa0103e3 	mov	x3, x1
    8350:	b7f80201 	tbnz	x1, #63, 8390 <fwp_write+0xf9c>
    8354:	910023f3 	add	x19, sp, #0x8
    8358:	aa1303e0 	mov	x0, x19
    835c:	97ffeab1 	bl	2e20 <fwp_fmt_u128>
    8360:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8364:	910ac339 	add	x25, x25, #0x2b0
    8368:	910123f5 	add	x21, sp, #0x48
    836c:	aa1303e4 	mov	x4, x19
    8370:	aa1503e0 	mov	x0, x21
    8374:	b0000003 	adrp	x3, 9000 <__divti3+0x10>
    8378:	f8616b25 	ldr	x5, [x25, x1]
    837c:	9137c063 	add	x3, x3, #0xdf0
    8380:	d2804002 	mov	x2, #0x200                 	// #512
    8384:	52800041 	mov	w1, #0x2                   	// #2
    8388:	97ffe8ee 	bl	2740 <__sprintf_chk@plt>
    838c:	17ffffc5 	b	82a0 <fwp_write+0xeac>
    8390:	528005a4 	mov	w4, #0x2d                  	// #45
    8394:	eb0003e2 	negs	x2, x0
    8398:	da0103e3 	ngc	x3, x1
    839c:	910027e0 	add	x0, sp, #0x9
    83a0:	910023f3 	add	x19, sp, #0x8
    83a4:	390023e4 	strb	w4, [sp, #8]
    83a8:	97ffea9e 	bl	2e20 <fwp_fmt_u128>
    83ac:	17ffffed 	b	8360 <fwp_write+0xf6c>
    83b0:	f9013bf5 	str	x21, [sp, #624]
    83b4:	f9013ff6 	str	x22, [sp, #632]
    83b8:	f90143f7 	str	x23, [sp, #640]
    83bc:	f90147f8 	str	x24, [sp, #648]
    83c0:	f9014bf9 	str	x25, [sp, #656]
    83c4:	f9014ffa 	str	x26, [sp, #664]
    83c8:	f90153fb 	str	x27, [sp, #672]
    83cc:	f90157fc 	str	x28, [sp, #680]
    83d0:	fd015be8 	str	d8, [sp, #688]
    83d4:	fd015fe9 	str	d9, [sp, #696]
    83d8:	97ffe932 	bl	28a0 <__stack_chk_fail@plt>
    83dc:	d503201f 	nop

00000000000083e0 <fwp_main_thread>:
    83e0:	d10603ff 	sub	sp, sp, #0x180
    83e4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    83e8:	f947f400 	ldr	x0, [x0, #4072]
    83ec:	a9127bfd 	stp	x29, x30, [sp, #288]
    83f0:	910483fd 	add	x29, sp, #0x120
    83f4:	a9145bf5 	stp	x21, x22, [sp, #320]
    83f8:	b0000395 	adrp	x21, 79000 <fwp_root_context+0xba0>
    83fc:	911902a1 	add	x1, x21, #0x640
    8400:	a91353f3 	stp	x19, x20, [sp, #304]
    8404:	a91563f7 	stp	x23, x24, [sp, #336]
    8408:	b953a421 	ldr	w1, [x1, #5028]
    840c:	a9166bf9 	stp	x25, x26, [sp, #352]
    8410:	a91773fb 	stp	x27, x28, [sp, #368]
    8414:	f9400002 	ldr	x2, [x0]
    8418:	f9008fe2 	str	x2, [sp, #280]
    841c:	d2800002 	mov	x2, #0x0                   	// #0
    8420:	34002761 	cbz	w1, 890c <fwp_main_thread+0x52c>
    8424:	911902a0 	add	x0, x21, #0x640
    8428:	b953a800 	ldr	w0, [x0, #5032]
    842c:	35002780 	cbnz	w0, 891c <fwp_main_thread+0x53c>
    8430:	900000d4 	adrp	x20, 20000 <__data_start>
    8434:	900000c2 	adrp	x2, 20000 <__data_start>
    8438:	9101429a 	add	x26, x20, #0x50
    843c:	91118042 	add	x2, x2, #0x460
    8440:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    8444:	d2a00024 	mov	x4, #0x10000               	// #65536
    8448:	910103f7 	add	x23, sp, #0x40
    844c:	9100a3fb 	add	x27, sp, #0x28
    8450:	aa1703e0 	mov	x0, x23
    8454:	d2800001 	mov	x1, #0x0                   	// #0
    8458:	f90023e2 	str	x2, [sp, #64]
    845c:	b9004bff 	str	wzr, [sp, #72]
    8460:	f9002be4 	str	x4, [sp, #80]
    8464:	a90a0f5b 	stp	x27, x3, [x26, #160]
    8468:	97ffe8a6 	bl	2700 <sigaltstack@plt>
    846c:	35005a80 	cbnz	w0, 8fbc <fwp_main_thread+0xbdc>
    8470:	4f000400 	movi	v0.4s, #0x0
    8474:	910223e0 	add	x0, sp, #0x88
    8478:	f0ffffc1 	adrp	x1, 3000 <ad_raw_record+0x70>
    847c:	9102c021 	add	x1, x1, #0xb0
    8480:	f90043e1 	str	x1, [sp, #128]
    8484:	52800082 	mov	w2, #0x4                   	// #4
    8488:	72a10002 	movk	w2, #0x800, lsl #16
    848c:	910203f3 	add	x19, sp, #0x80
    8490:	3d802000 	str	q0, [x0, #128]
    8494:	b9010be2 	str	w2, [sp, #264]
    8498:	ad000000 	stp	q0, q0, [x0]
    849c:	ad010000 	stp	q0, q0, [x0, #32]
    84a0:	ad020000 	stp	q0, q0, [x0, #64]
    84a4:	ad030000 	stp	q0, q0, [x0, #96]
    84a8:	97ffe8ee 	bl	2860 <sigemptyset@plt>
    84ac:	35005880 	cbnz	w0, 8fbc <fwp_main_thread+0xbdc>
    84b0:	aa1303e1 	mov	x1, x19
    84b4:	d2800002 	mov	x2, #0x0                   	// #0
    84b8:	52800160 	mov	w0, #0xb                   	// #11
    84bc:	97ffe901 	bl	28c0 <sigaction@plt>
    84c0:	350057e0 	cbnz	w0, 8fbc <fwp_main_thread+0xbdc>
    84c4:	aa1303e1 	mov	x1, x19
    84c8:	d2800002 	mov	x2, #0x0                   	// #0
    84cc:	528000e0 	mov	w0, #0x7                   	// #7
    84d0:	97ffe8fc 	bl	28c0 <sigaction@plt>
    84d4:	35005740 	cbnz	w0, 8fbc <fwp_main_thread+0xbdc>
    84d8:	911902bc 	add	x28, x21, #0x640
    84dc:	52800036 	mov	w22, #0x1                   	// #1
    84e0:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    84e4:	910ec000 	add	x0, x0, #0x3b0
    84e8:	b9015356 	str	w22, [x26, #336]
    84ec:	fd4a1380 	ldr	d0, [x28, #5152]
    84f0:	7e61d800 	ucvtf	d0, d0
    84f4:	fd00b740 	str	d0, [x26, #360]
    84f8:	9400047a 	bl	96e0 <atexit>
    84fc:	35005680 	cbnz	w0, 8fcc <fwp_main_thread+0xbec>
    8500:	b943e740 	ldr	w0, [x26, #996]
    8504:	34002140 	cbz	w0, 892c <fwp_main_thread+0x54c>
    8508:	9101429a 	add	x26, x20, #0x50
    850c:	f9404f56 	ldr	x22, [x26, #152]
    8510:	b4000c36 	cbz	x22, 8694 <fwp_main_thread+0x2b4>
    8514:	aa1603f3 	mov	x19, x22
    8518:	910102d7 	add	x23, x22, #0x40
    851c:	39414ad9 	ldrb	w25, [x22, #82]
    8520:	52800038 	mov	w24, #0x1                   	// #1
    8524:	39014ad8 	strb	w24, [x22, #82]
    8528:	f94016c0 	ldr	x0, [x22, #40]
    852c:	b4000620 	cbz	x0, 85f0 <fwp_main_thread+0x210>
    8530:	f94032c1 	ldr	x1, [x22, #96]
    8534:	394146c0 	ldrb	w0, [x22, #81]
    8538:	b4000c81 	cbz	x1, 86c8 <fwp_main_thread+0x2e8>
    853c:	36000b40 	tbz	w0, #0, 86a4 <fwp_main_thread+0x2c4>
    8540:	39414a62 	ldrb	w2, [x19, #82]
    8544:	f94022c0 	ldr	x0, [x22, #64]
    8548:	37000ea2 	tbnz	w2, #0, 871c <fwp_main_thread+0x33c>
    854c:	f9403261 	ldr	x1, [x19, #96]
    8550:	a911fe77 	stp	x23, xzr, [x19, #280]
    8554:	f9009660 	str	x0, [x19, #296]
    8558:	b4000040 	cbz	x0, 8560 <fwp_main_thread+0x180>
    855c:	f9009013 	str	x19, [x0, #288]
    8560:	f90022d3 	str	x19, [x22, #64]
    8564:	b4000101 	cbz	x1, 8584 <fwp_main_thread+0x1a4>
    8568:	f940a740 	ldr	x0, [x26, #328]
    856c:	39015678 	strb	w24, [x19, #85]
    8570:	f9003661 	str	x1, [x19, #104]
    8574:	a910827f 	stp	xzr, x0, [x19, #264]
    8578:	b4000040 	cbz	x0, 8580 <fwp_main_thread+0x1a0>
    857c:	f9008413 	str	x19, [x0, #264]
    8580:	f900a753 	str	x19, [x26, #328]
    8584:	39015a7f 	strb	wzr, [x19, #86]
    8588:	97fff90b 	bl	69b4 <fwp_block>
    858c:	f9408e62 	ldr	x2, [x19, #280]
    8590:	b4000142 	cbz	x2, 85b8 <fwp_main_thread+0x1d8>
    8594:	a9520261 	ldp	x1, x0, [x19, #288]
    8598:	b4000ce1 	cbz	x1, 8734 <fwp_main_thread+0x354>
    859c:	f9009420 	str	x0, [x1, #296]
    85a0:	f9409660 	ldr	x0, [x19, #296]
    85a4:	b4000040 	cbz	x0, 85ac <fwp_main_thread+0x1cc>
    85a8:	f9009001 	str	x1, [x0, #288]
    85ac:	91080260 	add	x0, x19, #0x200
    85b0:	f900967f 	str	xzr, [x19, #296]
    85b4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    85b8:	39415660 	ldrb	w0, [x19, #85]
    85bc:	f9404f42 	ldr	x2, [x26, #152]
    85c0:	36000aa0 	tbz	w0, #0, 8714 <fwp_main_thread+0x334>
    85c4:	a9508261 	ldp	x1, x0, [x19, #264]
    85c8:	b4000ba1 	cbz	x1, 873c <fwp_main_thread+0x35c>
    85cc:	f9008820 	str	x0, [x1, #272]
    85d0:	b4000040 	cbz	x0, 85d8 <fwp_main_thread+0x1f8>
    85d4:	f9008401 	str	x1, [x0, #264]
    85d8:	91080260 	add	x0, x19, #0x200
    85dc:	3901567f 	strb	wzr, [x19, #85]
    85e0:	aa0203f3 	mov	x19, x2
    85e4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    85e8:	f94016c0 	ldr	x0, [x22, #40]
    85ec:	b5fffa20 	cbnz	x0, 8530 <fwp_main_thread+0x150>
    85f0:	91014280 	add	x0, x20, #0x50
    85f4:	39014ad9 	strb	w25, [x22, #82]
    85f8:	f941e400 	ldr	x0, [x0, #968]
    85fc:	b5000080 	cbnz	x0, 860c <fwp_main_thread+0x22c>
    8600:	91014296 	add	x22, x20, #0x50
    8604:	f941eec0 	ldr	x0, [x22, #984]
    8608:	b40046a0 	cbz	x0, 8edc <fwp_main_thread+0xafc>
    860c:	91014280 	add	x0, x20, #0x50
    8610:	f941fc01 	ldr	x1, [x0, #1016]
    8614:	b903f01f 	str	wzr, [x0, #1008]
    8618:	eb13003f 	cmp	x1, x19
    861c:	54004761 	b.ne	8f08 <fwp_main_thread+0xb28>  // b.any
    8620:	b40009d3 	cbz	x19, 8758 <fwp_main_thread+0x378>
    8624:	91014280 	add	x0, x20, #0x50
    8628:	52800021 	mov	w1, #0x1                   	// #1
    862c:	39014a61 	strb	w1, [x19, #82]
    8630:	f941d005 	ldr	x5, [x0, #928]
    8634:	b4000925 	cbz	x5, 8758 <fwp_main_thread+0x378>
    8638:	394140a0 	ldrb	w0, [x5, #80]
    863c:	37000060 	tbnz	w0, #0, 8648 <fwp_main_thread+0x268>
    8640:	aa0503e0 	mov	x0, x5
    8644:	97ffec2b 	bl	36f0 <fwp_cancel_tree.part.0>
    8648:	f9409ca5 	ldr	x5, [x5, #312]
    864c:	b5ffff65 	cbnz	x5, 8638 <fwp_main_thread+0x258>
    8650:	91014296 	add	x22, x20, #0x50
    8654:	52800037 	mov	w23, #0x1                   	// #1
    8658:	f9402a60 	ldr	x0, [x19, #80]
    865c:	f2001c1f 	tst	x0, #0xff000000ff
    8660:	540000e1 	b.ne	867c <fwp_main_thread+0x29c>  // b.any
    8664:	f94062c0 	ldr	x0, [x22, #192]
    8668:	39015277 	strb	w23, [x19, #84]
    866c:	f900827f 	str	xzr, [x19, #256]
    8670:	b40006a0 	cbz	x0, 8744 <fwp_main_thread+0x364>
    8674:	f9008013 	str	x19, [x0, #256]
    8678:	f90062d3 	str	x19, [x22, #192]
    867c:	97fff8ce 	bl	69b4 <fwp_block>
    8680:	97fff860 	bl	6800 <fwp_free_zombie>
    8684:	f941d2c0 	ldr	x0, [x22, #928]
    8688:	b4000680 	cbz	x0, 8758 <fwp_main_thread+0x378>
    868c:	f941fed3 	ldr	x19, [x22, #1016]
    8690:	17fffff2 	b	8658 <fwp_main_thread+0x278>
    8694:	f941e740 	ldr	x0, [x26, #968]
    8698:	b50005a0 	cbnz	x0, 874c <fwp_main_thread+0x36c>
    869c:	d2800013 	mov	x19, #0x0                   	// #0
    86a0:	17ffffd8 	b	8600 <fwp_main_thread+0x220>
    86a4:	97ffecb7 	bl	3980 <fwp_now_ns>
    86a8:	f94032c1 	ldr	x1, [x22, #96]
    86ac:	eb01001f 	cmp	x0, x1
    86b0:	540000ab 	b.lt	86c4 <fwp_main_thread+0x2e4>  // b.tstop
    86b4:	394142c0 	ldrb	w0, [x22, #80]
    86b8:	37000060 	tbnz	w0, #0, 86c4 <fwp_main_thread+0x2e4>
    86bc:	aa1603e0 	mov	x0, x22
    86c0:	97ffec0c 	bl	36f0 <fwp_cancel_tree.part.0>
    86c4:	394146c0 	ldrb	w0, [x22, #81]
    86c8:	39414a62 	ldrb	w2, [x19, #82]
    86cc:	3707f3c0 	tbnz	w0, #0, 8544 <fwp_main_thread+0x164>
    86d0:	f94032c1 	ldr	x1, [x22, #96]
    86d4:	370001c2 	tbnz	w2, #0, 870c <fwp_main_thread+0x32c>
    86d8:	f9403260 	ldr	x0, [x19, #96]
    86dc:	b4000180 	cbz	x0, 870c <fwp_main_thread+0x32c>
    86e0:	b4000061 	cbz	x1, 86ec <fwp_main_thread+0x30c>
    86e4:	eb01001f 	cmp	x0, x1
    86e8:	9a81d000 	csel	x0, x0, x1, le
    86ec:	f94022c1 	ldr	x1, [x22, #64]
    86f0:	a911fe77 	stp	x23, xzr, [x19, #280]
    86f4:	f9009661 	str	x1, [x19, #296]
    86f8:	b4003ec1 	cbz	x1, 8ed0 <fwp_main_thread+0xaf0>
    86fc:	f9009033 	str	x19, [x1, #288]
    8700:	aa0003e1 	mov	x1, x0
    8704:	f90022d3 	str	x19, [x22, #64]
    8708:	17ffff98 	b	8568 <fwp_main_thread+0x188>
    870c:	f94022c0 	ldr	x0, [x22, #64]
    8710:	17ffff90 	b	8550 <fwp_main_thread+0x170>
    8714:	aa0203f3 	mov	x19, x2
    8718:	17ffff84 	b	8528 <fwp_main_thread+0x148>
    871c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8720:	f9009660 	str	x0, [x19, #296]
    8724:	b4000040 	cbz	x0, 872c <fwp_main_thread+0x34c>
    8728:	f9009013 	str	x19, [x0, #288]
    872c:	f90022d3 	str	x19, [x22, #64]
    8730:	17ffff95 	b	8584 <fwp_main_thread+0x1a4>
    8734:	f9000040 	str	x0, [x2]
    8738:	17ffff9b 	b	85a4 <fwp_main_thread+0x1c4>
    873c:	f900a740 	str	x0, [x26, #328]
    8740:	17ffffa4 	b	85d0 <fwp_main_thread+0x1f0>
    8744:	f90066d3 	str	x19, [x22, #200]
    8748:	17ffffcc 	b	8678 <fwp_main_thread+0x298>
    874c:	f941ff40 	ldr	x0, [x26, #1016]
    8750:	b903f35f 	str	wzr, [x26, #1008]
    8754:	b5003da0 	cbnz	x0, 8f08 <fwp_main_thread+0xb28>
    8758:	91014296 	add	x22, x20, #0x50
    875c:	97fff829 	bl	6800 <fwp_free_zombie>
    8760:	f94066c0 	ldr	x0, [x22, #200]
    8764:	b5003d20 	cbnz	x0, 8f08 <fwp_main_thread+0xb28>
    8768:	f940a6c0 	ldr	x0, [x22, #328]
    876c:	b5003ce0 	cbnz	x0, 8f08 <fwp_main_thread+0xb28>
    8770:	b94192c0 	ldr	w0, [x22, #400]
    8774:	340001c0 	cbz	w0, 87ac <fwp_main_thread+0x3cc>
    8778:	93407c17 	sxtw	x23, w0
    877c:	51000400 	sub	w0, w0, #0x1
    8780:	d1000af7 	sub	x23, x23, #0x2
    8784:	910682d8 	add	x24, x22, #0x1a0
    8788:	cb2042f7 	sub	x23, x23, w0, uxtw
    878c:	93407c13 	sxtw	x19, w0
    8790:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    8794:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8798:	b90192d3 	str	w19, [x22, #400]
    879c:	d1000673 	sub	x19, x19, #0x1
    87a0:	97ffe888 	bl	29c0 <munmap@plt>
    87a4:	eb1302ff 	cmp	x23, x19
    87a8:	54ffff41 	b.ne	8790 <fwp_main_thread+0x3b0>  // b.any
    87ac:	900000d3 	adrp	x19, 20000 <__data_start>
    87b0:	91004260 	add	x0, x19, #0x10
    87b4:	b9402000 	ldr	w0, [x0, #32]
    87b8:	37f80040 	tbnz	w0, #31, 87c0 <fwp_main_thread+0x3e0>
    87bc:	97ffe83d 	bl	28b0 <close@plt>
    87c0:	91014280 	add	x0, x20, #0x50
    87c4:	91004261 	add	x1, x19, #0x10
    87c8:	12800002 	mov	w2, #0xffffffff            	// #-1
    87cc:	d2800013 	mov	x19, #0x0                   	// #0
    87d0:	f9420017 	ldr	x23, [x0, #1024]
    87d4:	b9002022 	str	w2, [x1, #32]
    87d8:	f9420416 	ldr	x22, [x0, #1032]
    87dc:	b4000177 	cbz	x23, 8808 <fwp_main_thread+0x428>
    87e0:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    87e4:	b40000c0 	cbz	x0, 87fc <fwp_main_thread+0x41c>
    87e8:	f9400001 	ldr	x1, [x0]
    87ec:	b50038e1 	cbnz	x1, 8f08 <fwp_main_thread+0xb28>
    87f0:	f9400401 	ldr	x1, [x0, #8]
    87f4:	b50038a1 	cbnz	x1, 8f08 <fwp_main_thread+0xb28>
    87f8:	97fff13a 	bl	4ce0 <fwp_mem_free>
    87fc:	91000673 	add	x19, x19, #0x1
    8800:	eb17027f 	cmp	x19, x23
    8804:	54fffee1 	b.ne	87e0 <fwp_main_thread+0x400>  // b.any
    8808:	aa1603e0 	mov	x0, x22
    880c:	97fff135 	bl	4ce0 <fwp_mem_free>
    8810:	91014280 	add	x0, x20, #0x50
    8814:	f941fc13 	ldr	x19, [x0, #1016]
    8818:	f902001f 	str	xzr, [x0, #1024]
    881c:	f902041f 	str	xzr, [x0, #1032]
    8820:	b40001f3 	cbz	x19, 885c <fwp_main_thread+0x47c>
    8824:	f9401661 	ldr	x1, [x19, #40]
    8828:	b5003701 	cbnz	x1, 8f08 <fwp_main_thread+0xb28>
    882c:	f9405661 	ldr	x1, [x19, #168]
    8830:	b50036c1 	cbnz	x1, 8f08 <fwp_main_thread+0xb28>
    8834:	f941e401 	ldr	x1, [x0, #968]
    8838:	b5003681 	cbnz	x1, 8f08 <fwp_main_thread+0xb28>
    883c:	f941ec00 	ldr	x0, [x0, #984]
    8840:	b5003640 	cbnz	x0, 8f08 <fwp_main_thread+0xb28>
    8844:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8848:	90000380 	adrp	x0, 78000 <ad_raw_blocks+0x17ba0>
    884c:	91118000 	add	x0, x0, #0x460
    8850:	97ffe808 	bl	2870 <memset@plt>
    8854:	aa1303e0 	mov	x0, x19
    8858:	97fff122 	bl	4ce0 <fwp_mem_free>
    885c:	91014286 	add	x6, x20, #0x50
    8860:	911902b5 	add	x21, x21, #0x640
    8864:	3dc01682 	ldr	q2, [x20, #80]
    8868:	52800041 	mov	w1, #0x2                   	// #2
    886c:	3dc004c1 	ldr	q1, [x6, #16]
    8870:	b0000002 	adrp	x2, 9000 <__divti3+0x10>
    8874:	fd4a12a0 	ldr	d0, [x21, #5152]
    8878:	9139c042 	add	x2, x2, #0xe70
    887c:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    8880:	fd40b4c1 	ldr	d1, [x6, #360]
    8884:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8888:	f947e800 	ldr	x0, [x0, #4048]
    888c:	7e61d800 	ucvtf	d0, d0
    8890:	a95590c3 	ldp	x3, x4, [x6, #344]
    8894:	f9004cdf 	str	xzr, [x6, #152]
    8898:	f9400000 	ldr	x0, [x0]
    889c:	1e613801 	fsub	d1, d0, d1
    88a0:	f940bcc5 	ldr	x5, [x6, #376]
    88a4:	b90150df 	str	wzr, [x6, #336]
    88a8:	5ef1b842 	addp	d2, v2.2d
    88ac:	fd40b8c0 	ldr	d0, [x6, #368]
    88b0:	f901fcdf 	str	xzr, [x6, #1016]
    88b4:	fd0058c2 	str	d2, [x6, #176]
    88b8:	97ffe816 	bl	2910 <__fprintf_chk@plt>
    88bc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    88c0:	f947ec00 	ldr	x0, [x0, #4056]
    88c4:	f9400000 	ldr	x0, [x0]
    88c8:	97ffe842 	bl	29d0 <fflush@plt>
    88cc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    88d0:	f947f400 	ldr	x0, [x0, #4072]
    88d4:	f9408fe2 	ldr	x2, [sp, #280]
    88d8:	f9400001 	ldr	x1, [x0]
    88dc:	eb010042 	subs	x2, x2, x1
    88e0:	d2800001 	mov	x1, #0x0                   	// #0
    88e4:	54003721 	b.ne	8fc8 <fwp_main_thread+0xbe8>  // b.any
    88e8:	a9527bfd 	ldp	x29, x30, [sp, #288]
    88ec:	d2800000 	mov	x0, #0x0                   	// #0
    88f0:	a95353f3 	ldp	x19, x20, [sp, #304]
    88f4:	a9545bf5 	ldp	x21, x22, [sp, #320]
    88f8:	a95563f7 	ldp	x23, x24, [sp, #336]
    88fc:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8900:	a95773fb 	ldp	x27, x28, [sp, #368]
    8904:	910603ff 	add	sp, sp, #0x180
    8908:	d65f03c0 	ret
    890c:	97ffedfe 	bl	4104 <fwp_heap_init>
    8910:	911902a0 	add	x0, x21, #0x640
    8914:	b953a800 	ldr	w0, [x0, #5032]
    8918:	34ffd8c0 	cbz	w0, 8430 <fwp_main_thread+0x50>
    891c:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    8920:	913e8000 	add	x0, x0, #0xfa0
    8924:	9400036f 	bl	96e0 <atexit>
    8928:	17fffec2 	b	8430 <fwp_main_thread+0x50>
    892c:	f941db42 	ldr	x2, [x26, #944]
    8930:	b0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc_slow>
    8934:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    8938:	9134c000 	add	x0, x0, #0xd30
    893c:	913d4021 	add	x1, x1, #0xf50
    8940:	d2800018 	mov	x24, #0x0                   	// #0
    8944:	d2900019 	mov	x25, #0x8000                	// #32768
    8948:	390023f6 	strb	w22, [sp, #8]
    894c:	d2800016 	mov	x22, #0x0                   	// #0
    8950:	a90287e2 	stp	x2, x1, [sp, #40]
    8954:	a903fff7 	stp	x23, xzr, [sp, #56]
    8958:	a90503ff 	stp	xzr, x0, [sp, #80]
    895c:	f901db5b 	str	x27, [x26, #944]
    8960:	14000012 	b	89a8 <fwp_main_thread+0x5c8>
    8964:	7100045f 	cmp	w2, #0x1
    8968:	540001a1 	b.ne	899c <fwp_main_thread+0x5bc>  // b.any
    896c:	29430865 	ldp	w5, w2, [x3, #24]
    8970:	92403c21 	and	x1, x1, #0xffff
    8974:	9b057c21 	mul	x1, x1, x5
    8978:	d360fc21 	lsr	x1, x1, #32
    897c:	eb02003f 	cmp	x1, x2
    8980:	540000e2 	b.cs	899c <fwp_main_thread+0x5bc>  // b.hs, b.nlast
    8984:	8b010000 	add	x0, x0, x1
    8988:	39400001 	ldrb	w1, [x0]
    898c:	7103fc3f 	cmp	w1, #0xff
    8990:	54002980 	b.eq	8ec0 <fwp_main_thread+0xae0>  // b.none
    8994:	394023e1 	ldrb	w1, [sp, #8]
    8998:	39000001 	strb	w1, [x0]
    899c:	f90023f8 	str	x24, [sp, #64]
    89a0:	aa1b035a 	orr	x26, x26, x27
    89a4:	b40003fa 	cbz	x26, 8a20 <fwp_main_thread+0x640>
    89a8:	f100073a 	subs	x26, x25, #0x1
    89ac:	aa1303e1 	mov	x1, x19
    89b0:	da1f02db 	sbc	x27, x22, xzr
    89b4:	52800020 	mov	w0, #0x1                   	// #1
    89b8:	f90027fa 	str	x26, [sp, #72]
    89bc:	aa1a03f9 	mov	x25, x26
    89c0:	a90863fa 	stp	x26, x24, [sp, #128]
    89c4:	97fff248 	bl	52e4 <fwp_data.part.0.constprop.0>
    89c8:	aa0003f8 	mov	x24, x0
    89cc:	f949db81 	ldr	x1, [x28, #5040]
    89d0:	aa1b03f6 	mov	x22, x27
    89d4:	f949ef80 	ldr	x0, [x28, #5080]
    89d8:	cb010301 	sub	x1, x24, x1
    89dc:	eb00403f 	cmp	x1, x0, lsl #16
    89e0:	54fffde2 	b.cs	899c <fwp_main_thread+0x5bc>  // b.hs, b.nlast
    89e4:	d350fc22 	lsr	x2, x1, #16
    89e8:	f949ff85 	ldr	x5, [x28, #5112]
    89ec:	8b020842 	add	x2, x2, x2, lsl #2
    89f0:	d37df042 	lsl	x2, x2, #3
    89f4:	8b0200a3 	add	x3, x5, x2
    89f8:	f9401060 	ldr	x0, [x3, #32]
    89fc:	b4fffd00 	cbz	x0, 899c <fwp_main_thread+0x5bc>
    8a00:	386268a2 	ldrb	w2, [x5, x2]
    8a04:	7100085f 	cmp	w2, #0x2
    8a08:	54fffae1 	b.ne	8964 <fwp_main_thread+0x584>  // b.any
    8a0c:	72003c3f 	tst	w1, #0xffff
    8a10:	54fffbc0 	b.eq	8988 <fwp_main_thread+0x5a8>  // b.none
    8a14:	f90023f8 	str	x24, [sp, #64]
    8a18:	aa1b035a 	orr	x26, x26, x27
    8a1c:	b5fffc7a 	cbnz	x26, 89a8 <fwp_main_thread+0x5c8>
    8a20:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x8f0>
    8a24:	91014282 	add	x2, x20, #0x50
    8a28:	f94017e3 	ldr	x3, [sp, #40]
    8a2c:	910183e1 	add	x1, sp, #0x60
    8a30:	3dc18400 	ldr	q0, [x0, #1552]
    8a34:	52800020 	mov	w0, #0x1                   	// #1
    8a38:	f901d843 	str	x3, [x2, #944]
    8a3c:	3d801be0 	str	q0, [sp, #96]
    8a40:	97fff229 	bl	52e4 <fwp_data.part.0.constprop.0>
    8a44:	911902a1 	add	x1, x21, #0x640
    8a48:	aa0003f6 	mov	x22, x0
    8a4c:	f949d822 	ldr	x2, [x1, #5040]
    8a50:	f949ec20 	ldr	x0, [x1, #5080]
    8a54:	cb0202c2 	sub	x2, x22, x2
    8a58:	eb00405f 	cmp	x2, x0, lsl #16
    8a5c:	54000322 	b.cs	8ac0 <fwp_main_thread+0x6e0>  // b.hs, b.nlast
    8a60:	d350fc40 	lsr	x0, x2, #16
    8a64:	f949fc23 	ldr	x3, [x1, #5112]
    8a68:	8b000800 	add	x0, x0, x0, lsl #2
    8a6c:	d37df001 	lsl	x1, x0, #3
    8a70:	8b010060 	add	x0, x3, x1
    8a74:	f9401019 	ldr	x25, [x0, #32]
    8a78:	b4000259 	cbz	x25, 8ac0 <fwp_main_thread+0x6e0>
    8a7c:	38616861 	ldrb	w1, [x3, x1]
    8a80:	7100083f 	cmp	w1, #0x2
    8a84:	54002080 	b.eq	8e94 <fwp_main_thread+0xab4>  // b.none
    8a88:	7100043f 	cmp	w1, #0x1
    8a8c:	540001a1 	b.ne	8ac0 <fwp_main_thread+0x6e0>  // b.any
    8a90:	29430003 	ldp	w3, w0, [x0, #24]
    8a94:	92403c41 	and	x1, x2, #0xffff
    8a98:	9b037c21 	mul	x1, x1, x3
    8a9c:	d360fc21 	lsr	x1, x1, #32
    8aa0:	eb00003f 	cmp	x1, x0
    8aa4:	540000e2 	b.cs	8ac0 <fwp_main_thread+0x6e0>  // b.hs, b.nlast
    8aa8:	8b010339 	add	x25, x25, x1
    8aac:	39400320 	ldrb	w0, [x25]
    8ab0:	7103fc1f 	cmp	w0, #0xff
    8ab4:	540023e0 	b.eq	8f30 <fwp_main_thread+0xb50>  // b.none
    8ab8:	52800020 	mov	w0, #0x1                   	// #1
    8abc:	39000320 	strb	w0, [x25]
    8ac0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8ac4:	aa1303e1 	mov	x1, x19
    8ac8:	52800020 	mov	w0, #0x1                   	// #1
    8acc:	a9085be2 	stp	x2, x22, [sp, #128]
    8ad0:	97fff205 	bl	52e4 <fwp_data.part.0.constprop.0>
    8ad4:	911902a1 	add	x1, x21, #0x640
    8ad8:	aa0003f3 	mov	x19, x0
    8adc:	f949d822 	ldr	x2, [x1, #5040]
    8ae0:	f949ec20 	ldr	x0, [x1, #5080]
    8ae4:	cb020262 	sub	x2, x19, x2
    8ae8:	eb00405f 	cmp	x2, x0, lsl #16
    8aec:	54000322 	b.cs	8b50 <fwp_main_thread+0x770>  // b.hs, b.nlast
    8af0:	d350fc40 	lsr	x0, x2, #16
    8af4:	f949fc23 	ldr	x3, [x1, #5112]
    8af8:	8b000800 	add	x0, x0, x0, lsl #2
    8afc:	d37df001 	lsl	x1, x0, #3
    8b00:	8b010060 	add	x0, x3, x1
    8b04:	f9401016 	ldr	x22, [x0, #32]
    8b08:	b4000256 	cbz	x22, 8b50 <fwp_main_thread+0x770>
    8b0c:	38616861 	ldrb	w1, [x3, x1]
    8b10:	7100083f 	cmp	w1, #0x2
    8b14:	54001b40 	b.eq	8e7c <fwp_main_thread+0xa9c>  // b.none
    8b18:	7100043f 	cmp	w1, #0x1
    8b1c:	540001a1 	b.ne	8b50 <fwp_main_thread+0x770>  // b.any
    8b20:	29430003 	ldp	w3, w0, [x0, #24]
    8b24:	92403c41 	and	x1, x2, #0xffff
    8b28:	9b037c21 	mul	x1, x1, x3
    8b2c:	d360fc21 	lsr	x1, x1, #32
    8b30:	eb00003f 	cmp	x1, x0
    8b34:	540000e2 	b.cs	8b50 <fwp_main_thread+0x770>  // b.hs, b.nlast
    8b38:	8b0102d6 	add	x22, x22, x1
    8b3c:	394002c0 	ldrb	w0, [x22]
    8b40:	7103fc1f 	cmp	w0, #0xff
    8b44:	54001fc0 	b.eq	8f3c <fwp_main_thread+0xb5c>  // b.none
    8b48:	52800020 	mov	w0, #0x1                   	// #1
    8b4c:	390002c0 	strb	w0, [x22]
    8b50:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8b54:	9101c3e1 	add	x1, sp, #0x70
    8b58:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8b5c:	52800020 	mov	w0, #0x1                   	// #1
    8b60:	a9074fe2 	stp	x2, x19, [sp, #112]
    8b64:	97fff1e0 	bl	52e4 <fwp_data.part.0.constprop.0>
    8b68:	911902a1 	add	x1, x21, #0x640
    8b6c:	aa0003f3 	mov	x19, x0
    8b70:	f949d822 	ldr	x2, [x1, #5040]
    8b74:	f949ec20 	ldr	x0, [x1, #5080]
    8b78:	cb020262 	sub	x2, x19, x2
    8b7c:	eb00405f 	cmp	x2, x0, lsl #16
    8b80:	54000322 	b.cs	8be4 <fwp_main_thread+0x804>  // b.hs, b.nlast
    8b84:	d350fc40 	lsr	x0, x2, #16
    8b88:	f949fc23 	ldr	x3, [x1, #5112]
    8b8c:	8b000800 	add	x0, x0, x0, lsl #2
    8b90:	d37df001 	lsl	x1, x0, #3
    8b94:	8b010060 	add	x0, x3, x1
    8b98:	f9401016 	ldr	x22, [x0, #32]
    8b9c:	b4000256 	cbz	x22, 8be4 <fwp_main_thread+0x804>
    8ba0:	38616861 	ldrb	w1, [x3, x1]
    8ba4:	7100083f 	cmp	w1, #0x2
    8ba8:	54001700 	b.eq	8e88 <fwp_main_thread+0xaa8>  // b.none
    8bac:	7100043f 	cmp	w1, #0x1
    8bb0:	540001a1 	b.ne	8be4 <fwp_main_thread+0x804>  // b.any
    8bb4:	29430003 	ldp	w3, w0, [x0, #24]
    8bb8:	92403c41 	and	x1, x2, #0xffff
    8bbc:	9b037c21 	mul	x1, x1, x3
    8bc0:	d360fc21 	lsr	x1, x1, #32
    8bc4:	eb00003f 	cmp	x1, x0
    8bc8:	540000e2 	b.cs	8be4 <fwp_main_thread+0x804>  // b.hs, b.nlast
    8bcc:	8b0102d6 	add	x22, x22, x1
    8bd0:	394002c0 	ldrb	w0, [x22]
    8bd4:	7103fc1f 	cmp	w0, #0xff
    8bd8:	54001b80 	b.eq	8f48 <fwp_main_thread+0xb68>  // b.none
    8bdc:	52800020 	mov	w0, #0x1                   	// #1
    8be0:	390002c0 	strb	w0, [x22]
    8be4:	aa1803f9 	mov	x25, x24
    8be8:	d00000b6 	adrp	x22, 1e000 <__FRAME_END__+0x12708>
    8bec:	b40011f8 	cbz	x24, 8e28 <fwp_main_thread+0xa48>
    8bf0:	910ac2d6 	add	x22, x22, #0x2b0
    8bf4:	911902bb 	add	x27, x21, #0x640
    8bf8:	910142c0 	add	x0, x22, #0x50
    8bfc:	b000001a 	adrp	x26, 9000 <__divti3+0x10>
    8c00:	f90007e0 	str	x0, [sp, #8]
    8c04:	911d4340 	add	x0, x26, #0x750
    8c08:	f9000be0 	str	x0, [sp, #16]
    8c0c:	f949db61 	ldr	x1, [x27, #5040]
    8c10:	f949ef60 	ldr	x0, [x27, #5080]
    8c14:	cb010261 	sub	x1, x19, x1
    8c18:	eb00403f 	cmp	x1, x0, lsl #16
    8c1c:	540003a2 	b.cs	8c90 <fwp_main_thread+0x8b0>  // b.hs, b.nlast
    8c20:	d350fc20 	lsr	x0, x1, #16
    8c24:	f949ff65 	ldr	x5, [x27, #5112]
    8c28:	8b000800 	add	x0, x0, x0, lsl #2
    8c2c:	d37df002 	lsl	x2, x0, #3
    8c30:	8b0200a3 	add	x3, x5, x2
    8c34:	f9401060 	ldr	x0, [x3, #32]
    8c38:	b40002c0 	cbz	x0, 8c90 <fwp_main_thread+0x8b0>
    8c3c:	386268a2 	ldrb	w2, [x5, x2]
    8c40:	7100085f 	cmp	w2, #0x2
    8c44:	540010e0 	b.eq	8e60 <fwp_main_thread+0xa80>  // b.none
    8c48:	7100045f 	cmp	w2, #0x1
    8c4c:	54000221 	b.ne	8c90 <fwp_main_thread+0x8b0>  // b.any
    8c50:	29430865 	ldp	w5, w2, [x3, #24]
    8c54:	92403c21 	and	x1, x1, #0xffff
    8c58:	9b057c21 	mul	x1, x1, x5
    8c5c:	d360fc21 	lsr	x1, x1, #32
    8c60:	eb02003f 	cmp	x1, x2
    8c64:	54000162 	b.cs	8c90 <fwp_main_thread+0x8b0>  // b.hs, b.nlast
    8c68:	8b010000 	add	x0, x0, x1
    8c6c:	39400001 	ldrb	w1, [x0]
    8c70:	34000101 	cbz	w1, 8c90 <fwp_main_thread+0x8b0>
    8c74:	91014282 	add	x2, x20, #0x50
    8c78:	b9415043 	ldr	w3, [x2, #336]
    8c7c:	35000f83 	cbnz	w3, 8e6c <fwp_main_thread+0xa8c>
    8c80:	7103f43f 	cmp	w1, #0xfd
    8c84:	54001528 	b.hi	8f28 <fwp_main_thread+0xb48>  // b.pmore
    8c88:	11000421 	add	w1, w1, #0x1
    8c8c:	39000001 	strb	w1, [x0]
    8c90:	f94007e2 	ldr	x2, [sp, #8]
    8c94:	aa1703e0 	mov	x0, x23
    8c98:	aa1303e1 	mov	x1, x19
    8c9c:	52800023 	mov	w3, #0x1                   	// #1
    8ca0:	a9047fff 	stp	xzr, xzr, [sp, #64]
    8ca4:	f9002bff 	str	xzr, [sp, #80]
    8ca8:	97fff9d3 	bl	73f4 <fwp_write>
    8cac:	a9446bf6 	ldp	x22, x26, [sp, #64]
    8cb0:	f9400be0 	ldr	x0, [sp, #16]
    8cb4:	f10002df 	cmp	x22, #0x0
    8cb8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    8cbc:	b1002b5f 	cmn	x26, #0xa
    8cc0:	540018c8 	b.hi	8fd8 <fwp_main_thread+0xbf8>  // b.pmore
    8cc4:	52800021 	mov	w1, #0x1                   	// #1
    8cc8:	91002740 	add	x0, x26, #0x9
    8ccc:	97fff125 	bl	5160 <fwp_heap_alloc>
    8cd0:	aa0003fc 	mov	x28, x0
    8cd4:	aa1603e1 	mov	x1, x22
    8cd8:	aa0003f6 	mov	x22, x0
    8cdc:	aa1a03e2 	mov	x2, x26
    8ce0:	f80086da 	str	x26, [x22], #8
    8ce4:	aa1603e0 	mov	x0, x22
    8ce8:	97ffe682 	bl	26f0 <memcpy@plt>
    8cec:	8b1a0382 	add	x2, x28, x26
    8cf0:	3900205f 	strb	wzr, [x2, #8]
    8cf4:	f94023e0 	ldr	x0, [sp, #64]
    8cf8:	97ffe71a 	bl	2960 <free@plt>
    8cfc:	f949db62 	ldr	x2, [x27, #5040]
    8d00:	f949ef60 	ldr	x0, [x27, #5080]
    8d04:	cb020382 	sub	x2, x28, x2
    8d08:	eb00405f 	cmp	x2, x0, lsl #16
    8d0c:	54000322 	b.cs	8d70 <fwp_main_thread+0x990>  // b.hs, b.nlast
    8d10:	d350fc40 	lsr	x0, x2, #16
    8d14:	f949ff66 	ldr	x6, [x27, #5112]
    8d18:	8b000800 	add	x0, x0, x0, lsl #2
    8d1c:	d37df001 	lsl	x1, x0, #3
    8d20:	8b0100c5 	add	x5, x6, x1
    8d24:	f94010a0 	ldr	x0, [x5, #32]
    8d28:	b4000240 	cbz	x0, 8d70 <fwp_main_thread+0x990>
    8d2c:	386168c1 	ldrb	w1, [x6, x1]
    8d30:	7100083f 	cmp	w1, #0x2
    8d34:	54000c00 	b.eq	8eb4 <fwp_main_thread+0xad4>  // b.none
    8d38:	7100043f 	cmp	w1, #0x1
    8d3c:	540001a1 	b.ne	8d70 <fwp_main_thread+0x990>  // b.any
    8d40:	92403c41 	and	x1, x2, #0xffff
    8d44:	294308a6 	ldp	w6, w2, [x5, #24]
    8d48:	9b067c21 	mul	x1, x1, x6
    8d4c:	d360fc21 	lsr	x1, x1, #32
    8d50:	eb02003f 	cmp	x1, x2
    8d54:	540000e2 	b.cs	8d70 <fwp_main_thread+0x990>  // b.hs, b.nlast
    8d58:	8b010000 	add	x0, x0, x1
    8d5c:	39400001 	ldrb	w1, [x0]
    8d60:	7103fc3f 	cmp	w1, #0xff
    8d64:	54000d40 	b.eq	8f0c <fwp_main_thread+0xb2c>  // b.none
    8d68:	52800021 	mov	w1, #0x1                   	// #1
    8d6c:	39000001 	strb	w1, [x0]
    8d70:	aa1303e0 	mov	x0, x19
    8d74:	97fff443 	bl	5e80 <fwp_drop0>
    8d78:	91014285 	add	x5, x20, #0x50
    8d7c:	aa1603e0 	mov	x0, x22
    8d80:	f9400382 	ldr	x2, [x28]
    8d84:	aa0503f6 	mov	x22, x5
    8d88:	f94048a3 	ldr	x3, [x5, #144]
    8d8c:	d2800021 	mov	x1, #0x1                   	// #1
    8d90:	97ffe704 	bl	29a0 <fwrite@plt>
    8d94:	f9404ac1 	ldr	x1, [x22, #144]
    8d98:	52800140 	mov	w0, #0xa                   	// #10
    8d9c:	97ffe689 	bl	27c0 <fputc@plt>
    8da0:	f949db62 	ldr	x2, [x27, #5040]
    8da4:	f949ef60 	ldr	x0, [x27, #5080]
    8da8:	cb020382 	sub	x2, x28, x2
    8dac:	eb00405f 	cmp	x2, x0, lsl #16
    8db0:	54000382 	b.cs	8e20 <fwp_main_thread+0xa40>  // b.hs, b.nlast
    8db4:	d350fc40 	lsr	x0, x2, #16
    8db8:	f949ff65 	ldr	x5, [x27, #5112]
    8dbc:	8b000800 	add	x0, x0, x0, lsl #2
    8dc0:	d37df001 	lsl	x1, x0, #3
    8dc4:	8b0100a3 	add	x3, x5, x1
    8dc8:	f9401060 	ldr	x0, [x3, #32]
    8dcc:	b40002a0 	cbz	x0, 8e20 <fwp_main_thread+0xa40>
    8dd0:	386168a1 	ldrb	w1, [x5, x1]
    8dd4:	7100083f 	cmp	w1, #0x2
    8dd8:	54000640 	b.eq	8ea0 <fwp_main_thread+0xac0>  // b.none
    8ddc:	7100043f 	cmp	w1, #0x1
    8de0:	54000201 	b.ne	8e20 <fwp_main_thread+0xa40>  // b.any
    8de4:	92403c41 	and	x1, x2, #0xffff
    8de8:	29430865 	ldp	w5, w2, [x3, #24]
    8dec:	9b057c21 	mul	x1, x1, x5
    8df0:	d360fc21 	lsr	x1, x1, #32
    8df4:	eb02003f 	cmp	x1, x2
    8df8:	54000142 	b.cs	8e20 <fwp_main_thread+0xa40>  // b.hs, b.nlast
    8dfc:	8b010000 	add	x0, x0, x1
    8e00:	39400001 	ldrb	w1, [x0]
    8e04:	340000e1 	cbz	w1, 8e20 <fwp_main_thread+0xa40>
    8e08:	7100043f 	cmp	w1, #0x1
    8e0c:	54000200 	b.eq	8e4c <fwp_main_thread+0xa6c>  // b.none
    8e10:	7103fc3f 	cmp	w1, #0xff
    8e14:	54000a00 	b.eq	8f54 <fwp_main_thread+0xb74>  // b.none
    8e18:	51000421 	sub	w1, w1, #0x1
    8e1c:	39000001 	strb	w1, [x0]
    8e20:	f9400b39 	ldr	x25, [x25, #16]
    8e24:	b5ffef59 	cbnz	x25, 8c0c <fwp_main_thread+0x82c>
    8e28:	aa1303e0 	mov	x0, x19
    8e2c:	97fff415 	bl	5e80 <fwp_drop0>
    8e30:	aa1803e0 	mov	x0, x24
    8e34:	97fff413 	bl	5e80 <fwp_drop0>
    8e38:	91014280 	add	x0, x20, #0x50
    8e3c:	52800021 	mov	w1, #0x1                   	// #1
    8e40:	b903e401 	str	w1, [x0, #996]
    8e44:	f901f41f 	str	xzr, [x0, #1000]
    8e48:	17fffdb0 	b	8508 <fwp_main_thread+0x128>
    8e4c:	aa1c03e0 	mov	x0, x28
    8e50:	97fff2d9 	bl	59b4 <fwp_rc_free_arr>
    8e54:	f9400b39 	ldr	x25, [x25, #16]
    8e58:	b5ffedb9 	cbnz	x25, 8c0c <fwp_main_thread+0x82c>
    8e5c:	17fffff3 	b	8e28 <fwp_main_thread+0xa48>
    8e60:	72003c3f 	tst	w1, #0xffff
    8e64:	54fff161 	b.ne	8c90 <fwp_main_thread+0x8b0>  // b.any
    8e68:	17ffff81 	b	8c6c <fwp_main_thread+0x88c>
    8e6c:	f940bc43 	ldr	x3, [x2, #376]
    8e70:	91000463 	add	x3, x3, #0x1
    8e74:	f900bc43 	str	x3, [x2, #376]
    8e78:	17ffff82 	b	8c80 <fwp_main_thread+0x8a0>
    8e7c:	72003c5f 	tst	w2, #0xffff
    8e80:	54ffe681 	b.ne	8b50 <fwp_main_thread+0x770>  // b.any
    8e84:	17ffff2e 	b	8b3c <fwp_main_thread+0x75c>
    8e88:	72003c5f 	tst	w2, #0xffff
    8e8c:	54ffeac1 	b.ne	8be4 <fwp_main_thread+0x804>  // b.any
    8e90:	17ffff50 	b	8bd0 <fwp_main_thread+0x7f0>
    8e94:	72003c5f 	tst	w2, #0xffff
    8e98:	54ffe141 	b.ne	8ac0 <fwp_main_thread+0x6e0>  // b.any
    8e9c:	17ffff04 	b	8aac <fwp_main_thread+0x6cc>
    8ea0:	72003c5f 	tst	w2, #0xffff
    8ea4:	54fffae0 	b.eq	8e00 <fwp_main_thread+0xa20>  // b.none
    8ea8:	f9400b39 	ldr	x25, [x25, #16]
    8eac:	b5ffeb19 	cbnz	x25, 8c0c <fwp_main_thread+0x82c>
    8eb0:	17ffffde 	b	8e28 <fwp_main_thread+0xa48>
    8eb4:	72003c5f 	tst	w2, #0xffff
    8eb8:	54fff5c1 	b.ne	8d70 <fwp_main_thread+0x990>  // b.any
    8ebc:	17ffffa8 	b	8d5c <fwp_main_thread+0x97c>
    8ec0:	f9000be0 	str	x0, [sp, #16]
    8ec4:	97ffeee7 	bl	4a60 <fwp_rc_forget_slot>
    8ec8:	f9400be0 	ldr	x0, [sp, #16]
    8ecc:	17fffeb2 	b	8994 <fwp_main_thread+0x5b4>
    8ed0:	aa0003e1 	mov	x1, x0
    8ed4:	f90022d3 	str	x19, [x22, #64]
    8ed8:	17fffda4 	b	8568 <fwp_main_thread+0x188>
    8edc:	f941e2c0 	ldr	x0, [x22, #960]
    8ee0:	97ffef80 	bl	4ce0 <fwp_mem_free>
    8ee4:	f901e2df 	str	xzr, [x22, #960]
    8ee8:	f901eadf 	str	xzr, [x22, #976]
    8eec:	f941fec0 	ldr	x0, [x22, #1016]
    8ef0:	b4000173 	cbz	x19, 8f1c <fwp_main_thread+0xb3c>
    8ef4:	f900567f 	str	xzr, [x19, #168]
    8ef8:	f9005e7f 	str	xzr, [x19, #184]
    8efc:	b903f2df 	str	wzr, [x22, #1008]
    8f00:	eb13001f 	cmp	x0, x19
    8f04:	54ffb900 	b.eq	8624 <fwp_main_thread+0x244>  // b.none
    8f08:	97ffe67a 	bl	28f0 <abort@plt>
    8f0c:	f9000fe0 	str	x0, [sp, #24]
    8f10:	97ffeed4 	bl	4a60 <fwp_rc_forget_slot>
    8f14:	f9400fe0 	ldr	x0, [sp, #24]
    8f18:	17ffff94 	b	8d68 <fwp_main_thread+0x988>
    8f1c:	b903f2df 	str	wzr, [x22, #1008]
    8f20:	b4ffc1c0 	cbz	x0, 8758 <fwp_main_thread+0x378>
    8f24:	97ffe673 	bl	28f0 <abort@plt>
    8f28:	97ffee87 	bl	4944 <fwp_rc_wide_dup>
    8f2c:	17ffff59 	b	8c90 <fwp_main_thread+0x8b0>
    8f30:	aa1903e0 	mov	x0, x25
    8f34:	97ffeecb 	bl	4a60 <fwp_rc_forget_slot>
    8f38:	17fffee0 	b	8ab8 <fwp_main_thread+0x6d8>
    8f3c:	aa1603e0 	mov	x0, x22
    8f40:	97ffeec8 	bl	4a60 <fwp_rc_forget_slot>
    8f44:	17ffff01 	b	8b48 <fwp_main_thread+0x768>
    8f48:	aa1603e0 	mov	x0, x22
    8f4c:	97ffeec5 	bl	4a60 <fwp_rc_forget_slot>
    8f50:	17ffff23 	b	8bdc <fwp_main_thread+0x7fc>
    8f54:	ca404401 	eor	x1, x0, x0, lsr #17
    8f58:	911902a2 	add	x2, x21, #0x640
    8f5c:	ca412421 	eor	x1, x1, x1, lsr #9
    8f60:	8b210c41 	add	x1, x2, w1, uxtb #3
    8f64:	f94a2421 	ldr	x1, [x1, #5192]
    8f68:	b5000081 	cbnz	x1, 8f78 <fwp_main_thread+0xb98>
    8f6c:	14000011 	b	8fb0 <fwp_main_thread+0xbd0>
    8f70:	f9400821 	ldr	x1, [x1, #16]
    8f74:	b40001e1 	cbz	x1, 8fb0 <fwp_main_thread+0xbd0>
    8f78:	f9400022 	ldr	x2, [x1]
    8f7c:	eb02001f 	cmp	x0, x2
    8f80:	54ffff81 	b.ne	8f70 <fwp_main_thread+0xb90>  // b.any
    8f84:	f9400422 	ldr	x2, [x1, #8]
    8f88:	d1000442 	sub	x2, x2, #0x1
    8f8c:	f9000422 	str	x2, [x1, #8]
    8f90:	f103f85f 	cmp	x2, #0xfe
    8f94:	54fff461 	b.ne	8e20 <fwp_main_thread+0xa40>  // b.any
    8f98:	f9000fe0 	str	x0, [sp, #24]
    8f9c:	97ffeeb1 	bl	4a60 <fwp_rc_forget_slot>
    8fa0:	f9400fe0 	ldr	x0, [sp, #24]
    8fa4:	12800021 	mov	w1, #0xfffffffe            	// #-2
    8fa8:	39000001 	strb	w1, [x0]
    8fac:	17ffff9d 	b	8e20 <fwp_main_thread+0xa40>
    8fb0:	b0000000 	adrp	x0, 9000 <__divti3+0x10>
    8fb4:	912f4000 	add	x0, x0, #0xbd0
    8fb8:	97ffea12 	bl	3800 <fwp_trap>
    8fbc:	b0000000 	adrp	x0, 9000 <__divti3+0x10>
    8fc0:	91384000 	add	x0, x0, #0xe10
    8fc4:	97ffea0f 	bl	3800 <fwp_trap>
    8fc8:	97ffe636 	bl	28a0 <__stack_chk_fail@plt>
    8fcc:	b0000000 	adrp	x0, 9000 <__divti3+0x10>
    8fd0:	9138e000 	add	x0, x0, #0xe38
    8fd4:	97ffe8eb 	bl	3380 <ad_raw_fail>
    8fd8:	b0000000 	adrp	x0, 9000 <__divti3+0x10>
    8fdc:	91396000 	add	x0, x0, #0xe58
    8fe0:	97ffea08 	bl	3800 <fwp_trap>
    8fe4:	d503201f 	nop
    8fe8:	d503201f 	nop
    8fec:	d503201f 	nop

0000000000008ff0 <__divti3>:
    8ff0:	d503245f 	bti	c
    8ff4:	d2800004 	mov	x4, #0x0                   	// #0
    8ff8:	b7f80721 	tbnz	x1, #63, 90dc <__divti3+0xec>
    8ffc:	b6f80083 	tbz	x3, #63, 900c <__divti3+0x1c>
    9000:	eb0203e2 	negs	x2, x2
    9004:	aa2403e4 	mvn	x4, x4
    9008:	da0303e3 	ngc	x3, x3
    900c:	aa0203e6 	mov	x6, x2
    9010:	aa0003e7 	mov	x7, x0
    9014:	aa0103e5 	mov	x5, x1
    9018:	b5000583 	cbnz	x3, 90c8 <__divti3+0xd8>
    901c:	eb01005f 	cmp	x2, x1
    9020:	54000e69 	b.ls	91ec <__divti3+0x1fc>  // b.plast
    9024:	dac01040 	clz	x0, x2
    9028:	b40000e0 	cbz	x0, 9044 <__divti3+0x54>
    902c:	4b0003e1 	neg	w1, w0
    9030:	9ac020a5 	lsl	x5, x5, x0
    9034:	9ac02046 	lsl	x6, x2, x0
    9038:	9ac124e1 	lsr	x1, x7, x1
    903c:	aa050025 	orr	x5, x1, x5
    9040:	9ac020e7 	lsl	x7, x7, x0
    9044:	d360fcc8 	lsr	x8, x6, #32
    9048:	92407cc2 	and	x2, x6, #0xffffffff
    904c:	9ac808a3 	udiv	x3, x5, x8
    9050:	9b089465 	msub	x5, x3, x8, x5
    9054:	aa0303e0 	mov	x0, x3
    9058:	9b037c41 	mul	x1, x2, x3
    905c:	93c780a5 	extr	x5, x5, x7, #32
    9060:	eb05003f 	cmp	x1, x5
    9064:	540000a9 	b.ls	9078 <__divti3+0x88>  // b.plast
    9068:	ab0500c5 	adds	x5, x6, x5
    906c:	d1000460 	sub	x0, x3, #0x1
    9070:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    9074:	540015a8 	b.hi	9328 <__divti3+0x338>  // b.pmore
    9078:	cb0100a5 	sub	x5, x5, x1
    907c:	9ac808a3 	udiv	x3, x5, x8
    9080:	9b089465 	msub	x5, x3, x8, x5
    9084:	aa0303e1 	mov	x1, x3
    9088:	9b037c42 	mul	x2, x2, x3
    908c:	aa0703e3 	mov	x3, x7
    9090:	b3607ca3 	bfi	x3, x5, #32, #32
    9094:	eb03005f 	cmp	x2, x3
    9098:	540000c9 	b.ls	90b0 <__divti3+0xc0>  // b.plast
    909c:	ab0300c3 	adds	x3, x6, x3
    90a0:	d1000425 	sub	x5, x1, #0x1
    90a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    90a8:	d1000821 	sub	x1, x1, #0x2
    90ac:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    90b0:	aa008020 	orr	x0, x1, x0, lsl #32
    90b4:	d2800001 	mov	x1, #0x0                   	// #0
    90b8:	b4000064 	cbz	x4, 90c4 <__divti3+0xd4>
    90bc:	eb0003e0 	negs	x0, x0
    90c0:	da0103e1 	ngc	x1, x1
    90c4:	d65f03c0 	ret
    90c8:	eb01007f 	cmp	x3, x1
    90cc:	54000109 	b.ls	90ec <__divti3+0xfc>  // b.plast
    90d0:	d2800001 	mov	x1, #0x0                   	// #0
    90d4:	d2800000 	mov	x0, #0x0                   	// #0
    90d8:	17fffff8 	b	90b8 <__divti3+0xc8>
    90dc:	eb0003e0 	negs	x0, x0
    90e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    90e4:	da0103e1 	ngc	x1, x1
    90e8:	17ffffc5 	b	8ffc <__divti3+0xc>
    90ec:	dac01067 	clz	x7, x3
    90f0:	b40010e7 	cbz	x7, 930c <__divti3+0x31c>
    90f4:	d2800805 	mov	x5, #0x40                  	// #64
    90f8:	cb0700a5 	sub	x5, x5, x7
    90fc:	9ac72063 	lsl	x3, x3, x7
    9100:	9ac52448 	lsr	x8, x2, x5
    9104:	aa030108 	orr	x8, x8, x3
    9108:	9ac52426 	lsr	x6, x1, x5
    910c:	92407d0a 	and	x10, x8, #0xffffffff
    9110:	d360fd09 	lsr	x9, x8, #32
    9114:	9ac52403 	lsr	x3, x0, x5
    9118:	9ac72021 	lsl	x1, x1, x7
    911c:	aa010063 	orr	x3, x3, x1
    9120:	9ac72042 	lsl	x2, x2, x7
    9124:	9ac908cb 	udiv	x11, x6, x9
    9128:	9b099965 	msub	x5, x11, x9, x6
    912c:	aa0b03e1 	mov	x1, x11
    9130:	9b0b7d46 	mul	x6, x10, x11
    9134:	93c380a5 	extr	x5, x5, x3, #32
    9138:	eb0500df 	cmp	x6, x5
    913c:	540000a9 	b.ls	9150 <__divti3+0x160>  // b.plast
    9140:	ab050105 	adds	x5, x8, x5
    9144:	d1000561 	sub	x1, x11, #0x1
    9148:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    914c:	54000f48 	b.hi	9334 <__divti3+0x344>  // b.pmore
    9150:	cb0600a6 	sub	x6, x5, x6
    9154:	9ac908cb 	udiv	x11, x6, x9
    9158:	9b099969 	msub	x9, x11, x9, x6
    915c:	aa0b03e5 	mov	x5, x11
    9160:	9b0b7d4a 	mul	x10, x10, x11
    9164:	b3607d23 	bfi	x3, x9, #32, #32
    9168:	eb03015f 	cmp	x10, x3
    916c:	540000a9 	b.ls	9180 <__divti3+0x190>  // b.plast
    9170:	ab030103 	adds	x3, x8, x3
    9174:	d1000565 	sub	x5, x11, #0x1
    9178:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    917c:	54000e28 	b.hi	9340 <__divti3+0x350>  // b.pmore
    9180:	aa0180a1 	orr	x1, x5, x1, lsl #32
    9184:	92407c48 	and	x8, x2, #0xffffffff
    9188:	2a0503e5 	mov	w5, w5
    918c:	d360fc42 	lsr	x2, x2, #32
    9190:	d360fc26 	lsr	x6, x1, #32
    9194:	cb0a0063 	sub	x3, x3, x10
    9198:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    919c:	9b087caa 	mul	x10, x5, x8
    91a0:	9b087cc8 	mul	x8, x6, x8
    91a4:	9b0220a5 	madd	x5, x5, x2, x8
    91a8:	9b027cc6 	mul	x6, x6, x2
    91ac:	8b4a80a2 	add	x2, x5, x10, lsr #32
    91b0:	8b0900c5 	add	x5, x6, x9
    91b4:	eb02011f 	cmp	x8, x2
    91b8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    91bc:	8b4280c6 	add	x6, x6, x2, lsr #32
    91c0:	eb06007f 	cmp	x3, x6
    91c4:	540000e3 	b.cc	91e0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    91c8:	92407d4a 	and	x10, x10, #0xffffffff
    91cc:	9ac72000 	lsl	x0, x0, x7
    91d0:	8b028142 	add	x2, x10, x2, lsl #32
    91d4:	eb02001f 	cmp	x0, x2
    91d8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    91dc:	54000a01 	b.ne	931c <__divti3+0x32c>  // b.any
    91e0:	d1000420 	sub	x0, x1, #0x1
    91e4:	d2800001 	mov	x1, #0x0                   	// #0
    91e8:	17ffffb4 	b	90b8 <__divti3+0xc8>
    91ec:	b5000062 	cbnz	x2, 91f8 <__divti3+0x208>
    91f0:	d2800022 	mov	x2, #0x1                   	// #1
    91f4:	9ac30846 	udiv	x6, x2, x3
    91f8:	dac010c8 	clz	x8, x6
    91fc:	b5000408 	cbnz	x8, 927c <__divti3+0x28c>
    9200:	d360fcc9 	lsr	x9, x6, #32
    9204:	92407cc5 	and	x5, x6, #0xffffffff
    9208:	cb060023 	sub	x3, x1, x6
    920c:	d2800021 	mov	x1, #0x1                   	// #1
    9210:	9ac90868 	udiv	x8, x3, x9
    9214:	9b098d03 	msub	x3, x8, x9, x3
    9218:	aa0803e0 	mov	x0, x8
    921c:	9b057d02 	mul	x2, x8, x5
    9220:	93c78063 	extr	x3, x3, x7, #32
    9224:	eb03005f 	cmp	x2, x3
    9228:	540000a9 	b.ls	923c <__divti3+0x24c>  // b.plast
    922c:	ab0300c3 	adds	x3, x6, x3
    9230:	d1000500 	sub	x0, x8, #0x1
    9234:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9238:	54000968 	b.hi	9364 <__divti3+0x374>  // b.pmore
    923c:	cb020063 	sub	x3, x3, x2
    9240:	9ac90862 	udiv	x2, x3, x9
    9244:	aa0203e8 	mov	x8, x2
    9248:	9b098c42 	msub	x2, x2, x9, x3
    924c:	aa0703e3 	mov	x3, x7
    9250:	9b057d05 	mul	x5, x8, x5
    9254:	b3607c43 	bfi	x3, x2, #32, #32
    9258:	eb0300bf 	cmp	x5, x3
    925c:	540000c9 	b.ls	9274 <__divti3+0x284>  // b.plast
    9260:	ab0300c2 	adds	x2, x6, x3
    9264:	d1000503 	sub	x3, x8, #0x1
    9268:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    926c:	d1000908 	sub	x8, x8, #0x2
    9270:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    9274:	aa008100 	orr	x0, x8, x0, lsl #32
    9278:	17ffff90 	b	90b8 <__divti3+0xc8>
    927c:	9ac820c6 	lsl	x6, x6, x8
    9280:	d2800803 	mov	x3, #0x40                  	// #64
    9284:	cb080063 	sub	x3, x3, x8
    9288:	d360fcc9 	lsr	x9, x6, #32
    928c:	9ac82027 	lsl	x7, x1, x8
    9290:	92407cc5 	and	x5, x6, #0xffffffff
    9294:	9ac32422 	lsr	x2, x1, x3
    9298:	9ac32403 	lsr	x3, x0, x3
    929c:	aa070063 	orr	x3, x3, x7
    92a0:	9ac9084a 	udiv	x10, x2, x9
    92a4:	9ac82007 	lsl	x7, x0, x8
    92a8:	9b098940 	msub	x0, x10, x9, x2
    92ac:	aa0a03e1 	mov	x1, x10
    92b0:	9b0a7ca2 	mul	x2, x5, x10
    92b4:	93c38000 	extr	x0, x0, x3, #32
    92b8:	eb00005f 	cmp	x2, x0
    92bc:	540000a9 	b.ls	92d0 <__divti3+0x2e0>  // b.plast
    92c0:	ab0000c0 	adds	x0, x6, x0
    92c4:	d1000541 	sub	x1, x10, #0x1
    92c8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    92cc:	54000468 	b.hi	9358 <__divti3+0x368>  // b.pmore
    92d0:	cb020000 	sub	x0, x0, x2
    92d4:	9ac9080a 	udiv	x10, x0, x9
    92d8:	9b098140 	msub	x0, x10, x9, x0
    92dc:	aa0a03e2 	mov	x2, x10
    92e0:	9b0a7ca8 	mul	x8, x5, x10
    92e4:	b3607c03 	bfi	x3, x0, #32, #32
    92e8:	eb03011f 	cmp	x8, x3
    92ec:	540000a9 	b.ls	9300 <__divti3+0x310>  // b.plast
    92f0:	ab0300c3 	adds	x3, x6, x3
    92f4:	d1000542 	sub	x2, x10, #0x1
    92f8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    92fc:	54000288 	b.hi	934c <__divti3+0x35c>  // b.pmore
    9300:	cb080063 	sub	x3, x3, x8
    9304:	aa018041 	orr	x1, x2, x1, lsl #32
    9308:	17ffffc2 	b	9210 <__divti3+0x220>
    930c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9310:	d2800001 	mov	x1, #0x0                   	// #0
    9314:	9a9f87e0 	cset	x0, ls	// ls = plast
    9318:	17ffff68 	b	90b8 <__divti3+0xc8>
    931c:	aa0103e0 	mov	x0, x1
    9320:	d2800001 	mov	x1, #0x0                   	// #0
    9324:	17ffff65 	b	90b8 <__divti3+0xc8>
    9328:	d1000860 	sub	x0, x3, #0x2
    932c:	8b0600a5 	add	x5, x5, x6
    9330:	17ffff52 	b	9078 <__divti3+0x88>
    9334:	d1000961 	sub	x1, x11, #0x2
    9338:	8b0800a5 	add	x5, x5, x8
    933c:	17ffff85 	b	9150 <__divti3+0x160>
    9340:	d1000965 	sub	x5, x11, #0x2
    9344:	8b080063 	add	x3, x3, x8
    9348:	17ffff8e 	b	9180 <__divti3+0x190>
    934c:	d1000942 	sub	x2, x10, #0x2
    9350:	8b060063 	add	x3, x3, x6
    9354:	17ffffeb 	b	9300 <__divti3+0x310>
    9358:	d1000941 	sub	x1, x10, #0x2
    935c:	8b060000 	add	x0, x0, x6
    9360:	17ffffdc 	b	92d0 <__divti3+0x2e0>
    9364:	d1000900 	sub	x0, x8, #0x2
    9368:	8b060063 	add	x3, x3, x6
    936c:	17ffffb4 	b	923c <__divti3+0x24c>

0000000000009370 <__modti3>:
    9370:	d503245f 	bti	c
    9374:	d2800004 	mov	x4, #0x0                   	// #0
    9378:	b6f80081 	tbz	x1, #63, 9388 <__modti3+0x18>
    937c:	eb0003e0 	negs	x0, x0
    9380:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9384:	da0103e1 	ngc	x1, x1
    9388:	f100007f 	cmp	x3, #0x0
    938c:	5400128b 	b.lt	95dc <__modti3+0x26c>  // b.tstop
    9390:	aa0003e7 	mov	x7, x0
    9394:	aa0103e6 	mov	x6, x1
    9398:	540004e1 	b.ne	9434 <__modti3+0xc4>  // b.any
    939c:	eb02003f 	cmp	x1, x2
    93a0:	54000dc2 	b.cs	9558 <__modti3+0x1e8>  // b.hs, b.nlast
    93a4:	dac01043 	clz	x3, x2
    93a8:	aa0303e5 	mov	x5, x3
    93ac:	b40000e3 	cbz	x3, 93c8 <__modti3+0x58>
    93b0:	4b0303e6 	neg	w6, w3
    93b4:	9ac32021 	lsl	x1, x1, x3
    93b8:	9ac32042 	lsl	x2, x2, x3
    93bc:	9ac62406 	lsr	x6, x0, x6
    93c0:	aa0100c6 	orr	x6, x6, x1
    93c4:	9ac32007 	lsl	x7, x0, x3
    93c8:	d360fc40 	lsr	x0, x2, #32
    93cc:	92407c43 	and	x3, x2, #0xffffffff
    93d0:	9ac008c1 	udiv	x1, x6, x0
    93d4:	9b009826 	msub	x6, x1, x0, x6
    93d8:	9b017c61 	mul	x1, x3, x1
    93dc:	93c780c6 	extr	x6, x6, x7, #32
    93e0:	eb06003f 	cmp	x1, x6
    93e4:	540000a9 	b.ls	93f8 <__modti3+0x88>  // b.plast
    93e8:	ab060046 	adds	x6, x2, x6
    93ec:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    93f0:	8b0200c8 	add	x8, x6, x2
    93f4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    93f8:	cb0100c6 	sub	x6, x6, x1
    93fc:	9ac008c8 	udiv	x8, x6, x0
    9400:	9b009901 	msub	x1, x8, x0, x6
    9404:	aa0703e0 	mov	x0, x7
    9408:	9b087c63 	mul	x3, x3, x8
    940c:	b3607c20 	bfi	x0, x1, #32, #32
    9410:	eb00007f 	cmp	x3, x0
    9414:	54001088 	b.hi	9624 <__modti3+0x2b4>  // b.pmore
    9418:	cb030000 	sub	x0, x0, x3
    941c:	9ac52400 	lsr	x0, x0, x5
    9420:	d2800001 	mov	x1, #0x0                   	// #0
    9424:	b4000064 	cbz	x4, 9430 <__modti3+0xc0>
    9428:	eb0003e0 	negs	x0, x0
    942c:	da0103e1 	ngc	x1, x1
    9430:	d65f03c0 	ret
    9434:	dac01066 	clz	x6, x3
    9438:	eb03003f 	cmp	x1, x3
    943c:	54ffff43 	b.cc	9424 <__modti3+0xb4>  // b.lo, b.ul, b.last
    9440:	93407cc5 	sxtw	x5, w6
    9444:	d2800808 	mov	x8, #0x40                  	// #64
    9448:	cb050108 	sub	x8, x8, x5
    944c:	9ac62063 	lsl	x3, x3, x6
    9450:	9ac62025 	lsl	x5, x1, x6
    9454:	9ac82447 	lsr	x7, x2, x8
    9458:	aa0300e7 	orr	x7, x7, x3
    945c:	9ac82423 	lsr	x3, x1, x8
    9460:	92407cec 	and	x12, x7, #0xffffffff
    9464:	d360fcea 	lsr	x10, x7, #32
    9468:	9ac82401 	lsr	x1, x0, x8
    946c:	aa050021 	orr	x1, x1, x5
    9470:	9ac62042 	lsl	x2, x2, x6
    9474:	9ac62000 	lsl	x0, x0, x6
    9478:	9aca086b 	udiv	x11, x3, x10
    947c:	9b0a8d63 	msub	x3, x11, x10, x3
    9480:	aa0b03e5 	mov	x5, x11
    9484:	9b0b7d89 	mul	x9, x12, x11
    9488:	93c18063 	extr	x3, x3, x1, #32
    948c:	eb03013f 	cmp	x9, x3
    9490:	540000a9 	b.ls	94a4 <__modti3+0x134>  // b.plast
    9494:	ab0300e3 	adds	x3, x7, x3
    9498:	d1000565 	sub	x5, x11, #0x1
    949c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    94a0:	54001168 	b.hi	96cc <__modti3+0x35c>  // b.pmore
    94a4:	cb090063 	sub	x3, x3, x9
    94a8:	9aca086b 	udiv	x11, x3, x10
    94ac:	9b0a8d6a 	msub	x10, x11, x10, x3
    94b0:	aa0b03e9 	mov	x9, x11
    94b4:	9b0b7d8c 	mul	x12, x12, x11
    94b8:	b3607d41 	bfi	x1, x10, #32, #32
    94bc:	eb01019f 	cmp	x12, x1
    94c0:	540000a9 	b.ls	94d4 <__modti3+0x164>  // b.plast
    94c4:	ab0100e1 	adds	x1, x7, x1
    94c8:	d1000569 	sub	x9, x11, #0x1
    94cc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    94d0:	54000f88 	b.hi	96c0 <__modti3+0x350>  // b.pmore
    94d4:	aa058123 	orr	x3, x9, x5, lsl #32
    94d8:	92407c4b 	and	x11, x2, #0xffffffff
    94dc:	2a0903e9 	mov	w9, w9
    94e0:	d360fc4a 	lsr	x10, x2, #32
    94e4:	d360fc63 	lsr	x3, x3, #32
    94e8:	cb0c0021 	sub	x1, x1, x12
    94ec:	aa0a03ec 	mov	x12, x10
    94f0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    94f4:	9b0b7d25 	mul	x5, x9, x11
    94f8:	9b0b7c6b 	mul	x11, x3, x11
    94fc:	9b0a2d29 	madd	x9, x9, x10, x11
    9500:	92407caa 	and	x10, x5, #0xffffffff
    9504:	9b0c7c63 	mul	x3, x3, x12
    9508:	8b458125 	add	x5, x9, x5, lsr #32
    950c:	8b0d0069 	add	x9, x3, x13
    9510:	eb05017f 	cmp	x11, x5
    9514:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9518:	8b058149 	add	x9, x10, x5, lsl #32
    951c:	8b458063 	add	x3, x3, x5, lsr #32
    9520:	eb03003f 	cmp	x1, x3
    9524:	54000063 	b.cc	9530 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9528:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    952c:	54000082 	b.cs	953c <__modti3+0x1cc>  // b.hs, b.nlast
    9530:	eb020129 	subs	x9, x9, x2
    9534:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9538:	cb070063 	sub	x3, x3, x7
    953c:	eb090000 	subs	x0, x0, x9
    9540:	da030021 	sbc	x1, x1, x3
    9544:	9ac62400 	lsr	x0, x0, x6
    9548:	9ac82028 	lsl	x8, x1, x8
    954c:	aa000100 	orr	x0, x8, x0
    9550:	9ac62421 	lsr	x1, x1, x6
    9554:	17ffffb4 	b	9424 <__modti3+0xb4>
    9558:	b5000062 	cbnz	x2, 9564 <__modti3+0x1f4>
    955c:	d2800023 	mov	x3, #0x1                   	// #1
    9560:	9ac20862 	udiv	x2, x3, x2
    9564:	dac01048 	clz	x8, x2
    9568:	aa0803e5 	mov	x5, x8
    956c:	b5000668 	cbnz	x8, 9638 <__modti3+0x2c8>
    9570:	cb020020 	sub	x0, x1, x2
    9574:	d360fc49 	lsr	x9, x2, #32
    9578:	92407c4a 	and	x10, x2, #0xffffffff
    957c:	9ac90801 	udiv	x1, x0, x9
    9580:	9b098020 	msub	x0, x1, x9, x0
    9584:	9b0a7c21 	mul	x1, x1, x10
    9588:	93c78000 	extr	x0, x0, x7, #32
    958c:	eb00003f 	cmp	x1, x0
    9590:	540000a9 	b.ls	95a4 <__modti3+0x234>  // b.plast
    9594:	ab000040 	adds	x0, x2, x0
    9598:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    959c:	8b020003 	add	x3, x0, x2
    95a0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    95a4:	cb010001 	sub	x1, x0, x1
    95a8:	9ac90820 	udiv	x0, x1, x9
    95ac:	9b098403 	msub	x3, x0, x9, x1
    95b0:	aa0703e1 	mov	x1, x7
    95b4:	9b0a7c00 	mul	x0, x0, x10
    95b8:	b3607c61 	bfi	x1, x3, #32, #32
    95bc:	eb01001f 	cmp	x0, x1
    95c0:	540000a9 	b.ls	95d4 <__modti3+0x264>  // b.plast
    95c4:	ab010041 	adds	x1, x2, x1
    95c8:	8b020022 	add	x2, x1, x2
    95cc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    95d0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    95d4:	cb000020 	sub	x0, x1, x0
    95d8:	17ffff91 	b	941c <__modti3+0xac>
    95dc:	eb0203e5 	negs	x5, x2
    95e0:	aa0003e7 	mov	x7, x0
    95e4:	da0303e8 	ngc	x8, x3
    95e8:	aa0503e2 	mov	x2, x5
    95ec:	aa0803e3 	mov	x3, x8
    95f0:	aa0103e6 	mov	x6, x1
    95f4:	b4ffed48 	cbz	x8, 939c <__modti3+0x2c>
    95f8:	eb01011f 	cmp	x8, x1
    95fc:	54fff148 	b.hi	9424 <__modti3+0xb4>  // b.pmore
    9600:	dac01109 	clz	x9, x8
    9604:	2a0903e6 	mov	w6, w9
    9608:	b5fff1c9 	cbnz	x9, 9440 <__modti3+0xd0>
    960c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9610:	54000068 	b.hi	961c <__modti3+0x2ac>  // b.pmore
    9614:	eb050007 	subs	x7, x0, x5
    9618:	da080021 	sbc	x1, x1, x8
    961c:	aa0703e0 	mov	x0, x7
    9620:	17ffff81 	b	9424 <__modti3+0xb4>
    9624:	ab000040 	adds	x0, x2, x0
    9628:	8b020002 	add	x2, x0, x2
    962c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9630:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9634:	17ffff79 	b	9418 <__modti3+0xa8>
    9638:	9ac82042 	lsl	x2, x2, x8
    963c:	d2800803 	mov	x3, #0x40                  	// #64
    9640:	cb080063 	sub	x3, x3, x8
    9644:	d360fc49 	lsr	x9, x2, #32
    9648:	9ac82027 	lsl	x7, x1, x8
    964c:	92407c4a 	and	x10, x2, #0xffffffff
    9650:	9ac32426 	lsr	x6, x1, x3
    9654:	9ac32403 	lsr	x3, x0, x3
    9658:	aa070063 	orr	x3, x3, x7
    965c:	9ac908c1 	udiv	x1, x6, x9
    9660:	9ac82007 	lsl	x7, x0, x8
    9664:	9b099820 	msub	x0, x1, x9, x6
    9668:	9b017d41 	mul	x1, x10, x1
    966c:	93c38000 	extr	x0, x0, x3, #32
    9670:	eb00003f 	cmp	x1, x0
    9674:	540000a9 	b.ls	9688 <__modti3+0x318>  // b.plast
    9678:	ab000040 	adds	x0, x2, x0
    967c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9680:	8b020006 	add	x6, x0, x2
    9684:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    9688:	cb010000 	sub	x0, x0, x1
    968c:	9ac90801 	udiv	x1, x0, x9
    9690:	9b098026 	msub	x6, x1, x9, x0
    9694:	aa0303e0 	mov	x0, x3
    9698:	9b017d41 	mul	x1, x10, x1
    969c:	b3607cc0 	bfi	x0, x6, #32, #32
    96a0:	eb00003f 	cmp	x1, x0
    96a4:	540000a9 	b.ls	96b8 <__modti3+0x348>  // b.plast
    96a8:	ab000040 	adds	x0, x2, x0
    96ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    96b0:	8b020003 	add	x3, x0, x2
    96b4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    96b8:	cb010000 	sub	x0, x0, x1
    96bc:	17ffffb0 	b	957c <__modti3+0x20c>
    96c0:	d1000969 	sub	x9, x11, #0x2
    96c4:	8b070021 	add	x1, x1, x7
    96c8:	17ffff83 	b	94d4 <__modti3+0x164>
    96cc:	d1000965 	sub	x5, x11, #0x2
    96d0:	8b070063 	add	x3, x3, x7
    96d4:	17ffff74 	b	94a4 <__modti3+0x134>
    96d8:	d503201f 	nop
    96dc:	d503201f 	nop

00000000000096e0 <atexit>:
    96e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    96e4:	f00000a2 	adrp	x2, 20000 <__data_start>
    96e8:	d2800001 	mov	x1, #0x0                   	// #0
    96ec:	910003fd 	mov	x29, sp
    96f0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    96f4:	f9400442 	ldr	x2, [x2, #8]
    96f8:	17ffe42a 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

00000000000096fc <_fini>:
    96fc:	d503201f 	nop
    9700:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9704:	910003fd 	mov	x29, sp
    9708:	a8c17bfd 	ldp	x29, x30, [sp], #16
    970c:	d65f03c0 	ret
