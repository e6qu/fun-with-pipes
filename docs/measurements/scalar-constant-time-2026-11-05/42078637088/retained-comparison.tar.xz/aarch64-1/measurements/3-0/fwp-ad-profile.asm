
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000025 	adrp	x5, 9000 <__divti3+0x100>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	9125e0a5 	add	x5, x5, #0x978
    2aa0:	f0000024 	adrp	x4, 9000 <__divti3+0x100>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91260084 	add	x4, x4, #0x980
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	91014261 	add	x1, x19, #0x50
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x12858>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9006820 	str	x0, [x1, #208]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000020 	adrp	x0, 9000 <__divti3+0x100>
    2b34:	9137c000 	add	x0, x0, #0xdf0
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0xcfc>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	910bc042 	add	x2, x2, #0x2f0
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	91014273 	add	x19, x19, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943d260 	ldr	w0, [x19, #976]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff50 	bl	2990 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000020 	adrp	x0, 9000 <__divti3+0x100>
    2c7c:	91380000 	add	x0, x0, #0xe00
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97ffff07 	bl	28a0 <__stack_chk_fail@plt>
    2c88:	f0000020 	adrp	x0, 9000 <__divti3+0x100>
    2c8c:	913a8000 	add	x0, x0, #0xea0
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffeee 	bl	2850 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000020 	adrp	x0, 9000 <__divti3+0x100>
    2ca4:	9139e000 	add	x0, x0, #0xe78
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000020 	adrp	x0, 9000 <__divti3+0x100>
    2cb0:	91392000 	add	x0, x0, #0xe48
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000020 	adrp	x0, 9000 <__divti3+0x100>
    2cbc:	91388000 	add	x0, x0, #0xe20
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	9100e000 	add	x0, x0, #0x38
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	9100e021 	add	x1, x1, #0x38
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	9100e000 	add	x0, x0, #0x38
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	9100e021 	add	x1, x1, #0x38
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000041 	adrp	x1, a000 <_IO_stdin_used+0x9e0>
    2eb4:	9113c021 	add	x1, x1, #0x4f0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x9e0>
    3158:	91134021 	add	x1, x1, #0x4d0
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    3190:	9118a000 	add	x0, x0, #0x628
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    31c4:	911882a1 	add	x1, x21, #0x620
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    31d8:	912840a5 	add	x5, x5, #0xa10
    31dc:	911882a1 	add	x1, x21, #0x620
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	911882b7 	add	x23, x21, #0x620
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	911882b5 	add	x21, x21, #0x620
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	911882b5 	add	x21, x21, #0x620
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    3368:	912820a5 	add	x5, x5, #0xa08
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000022 	adrp	x2, 9000 <__divti3+0x100>
    339c:	91190042 	add	x2, x2, #0x640
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000022 	adrp	x2, 9000 <__divti3+0x100>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	911a6042 	add	x2, x2, #0x698
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000039 	adrp	x25, 9000 <__divti3+0x100>
    3428:	d000003a 	adrp	x26, 9000 <__divti3+0x100>
    342c:	911be339 	add	x25, x25, #0x6f8
    3430:	9119835a 	add	x26, x26, #0x660
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000003b 	adrp	x27, 9000 <__divti3+0x100>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	9119a377 	add	x23, x27, #0x668
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	911ce000 	add	x0, x0, #0x738
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbc0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbc0>
    34fc:	d0000023 	adrp	x3, 9000 <__divti3+0x100>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000035 	adrp	x21, 9000 <__divti3+0x100>
    3508:	f9422024 	ldr	x4, [x1, #1088]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f94224a5 	ldr	x5, [x5, #1096]
    3514:	91110033 	add	x19, x1, #0x440
    3518:	f9422846 	ldr	x6, [x2, #1104]
    351c:	91198063 	add	x3, x3, #0x660
    3520:	911d42b5 	add	x21, x21, #0x750
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	911e4000 	add	x0, x0, #0x790
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    35ac:	9119c000 	add	x0, x0, #0x670
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    366c:	9118a000 	add	x0, x0, #0x628
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000021 	adrp	x1, 9000 <__divti3+0x100>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	911e6021 	add	x1, x1, #0x798
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000021 	adrp	x1, 9000 <__divti3+0x100>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	911e8021 	add	x1, x1, #0x7a0
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000021 	adrp	x1, 9000 <__divti3+0x100>
    37e0:	911ea021 	add	x1, x1, #0x7a8
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffe12 	bl	3074 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000022 	adrp	x2, 9000 <__divti3+0x100>
    3838:	aa1303e3 	mov	x3, x19
    383c:	911ec042 	add	x2, x2, #0x7b0
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc33 	bl	2910 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc60 	bl	29d0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc6e 	bl	2a10 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbbc 	bl	2750 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbdc 	bl	2840 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbbf 	bl	27f0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc17 	bl	2960 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    3950:	9118a000 	add	x0, x0, #0x628
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc12 	bl	29a0 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc1c 	bl	29d0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc2a 	bl	2a10 <_Exit@plt>
    396c:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    3970:	911f0000 	add	x0, x0, #0x7c0
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb8a 	bl	27d0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    3a08:	911f8000 	add	x0, x0, #0x7e0
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffba4 	bl	28a0 <__stack_chk_fail@plt>
    3a14:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    3a18:	91200000 	add	x0, x0, #0x800
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x9e0>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc14020 	ldr	q0, [x1, #1280]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	910142b5 	add	x21, x21, #0x50
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f9406aa2 	ldr	x2, [x21, #208]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb9f 	bl	2960 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    3b18:	9120a000 	add	x0, x0, #0x828
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb5f 	bl	28a0 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b3c:	91014063 	add	x3, x3, #0x50
    3b40:	9350fc01 	asr	x1, x0, #16
    3b44:	d1000440 	sub	x0, x2, #0x1
    3b48:	f9406c62 	ldr	x2, [x3, #216]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9404463 	ldr	x3, [x3, #136]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    3b88:	91216000 	add	x0, x0, #0x858
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000024 	adrp	x4, 9000 <__divti3+0x100>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	9122a084 	add	x4, x4, #0x8a8
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffb06 	bl	2810 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb5f 	bl	2980 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb4a 	bl	2940 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa93 	bl	26f0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffacb 	bl	27f0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffabc 	bl	27f0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa74 	bl	26f0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa80 	bl	2730 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb10 	bl	2980 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000024 	adrp	x4, 9000 <__divti3+0x100>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	91230084 	add	x4, x4, #0x8c0
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa90 	bl	2810 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa7f 	bl	27f0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffadf 	bl	2980 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000024 	adrp	x4, 9000 <__divti3+0x100>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	9122c084 	add	x4, x4, #0x8b0
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa68 	bl	2810 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa52 	bl	27f0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa26 	bl	27f0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa42 	bl	28a0 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    3fa8:	91188042 	add	x2, x2, #0x620
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000021 	adrp	x1, 9000 <__divti3+0x100>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000020 	adrp	x0, 9000 <__divti3+0x100>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	91232021 	add	x1, x1, #0x8c8
    4004:	91234000 	add	x0, x0, #0x8d0
    4008:	97fffa0a 	bl	2830 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa87 	bl	2a50 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa35 	bl	2940 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa74 	bl	2a50 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9e5 	bl	2820 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000022 	adrp	x2, 9000 <__divti3+0x100>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	9123c042 	add	x2, x2, #0x8f0
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa08 	b	2910 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9e0>
    410c:	91148061 	add	x1, x3, #0x520
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    411c:	91188262 	add	x2, x19, #0x620
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000022 	adrp	x2, a000 <_IO_stdin_used+0x9e0>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9e0>
    414c:	91158021 	add	x1, x1, #0x560
    4150:	3dc14443 	ldr	q3, [x2, #1296]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9e0>
    417c:	91148063 	add	x3, x3, #0x520
    4180:	91170084 	add	x4, x4, #0x5c0
    4184:	91188266 	add	x6, x19, #0x620
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9cd 	bl	2930 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91188275 	add	x21, x19, #0x620
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9b7 	bl	2930 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    4268:	91268000 	add	x0, x0, #0x9a0
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9f0 	bl	2a30 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91188273 	add	x19, x19, #0x620
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffbac 	bl	3170 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	91014122 	add	x2, x9, #0x50
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9406046 	ldr	x6, [x2, #192]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	91014120 	add	x0, x9, #0x50
    4354:	f900640b 	str	x11, [x0, #200]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	91014129 	add	x9, x9, #0x50
    4360:	f9006126 	str	x6, [x9, #192]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <ad_raw_free.part.0>:
    4380:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbc0>
    4384:	d2800001 	mov	x1, #0x0                   	// #0
    4388:	91110082 	add	x2, x4, #0x440
    438c:	14000005 	b	43a0 <ad_raw_free.part.0+0x20>
    4390:	91000421 	add	x1, x1, #0x1
    4394:	91006042 	add	x2, x2, #0x18
    4398:	f140043f 	cmp	x1, #0x1, lsl #12
    439c:	54000220 	b.eq	43e0 <ad_raw_free.part.0+0x60>  // b.none
    43a0:	f9400043 	ldr	x3, [x2]
    43a4:	eb03001f 	cmp	x0, x3
    43a8:	54ffff41 	b.ne	4390 <ad_raw_free.part.0+0x10>  // b.any
    43ac:	8b010421 	add	x1, x1, x1, lsl #1
    43b0:	91110084 	add	x4, x4, #0x440
    43b4:	900000e2 	adrp	x2, 20000 <__data_start>
    43b8:	91014042 	add	x2, x2, #0x50
    43bc:	8b010c81 	add	x1, x4, x1, lsl #3
    43c0:	b9401024 	ldr	w4, [x1, #16]
    43c4:	f9400425 	ldr	x5, [x1, #8]
    43c8:	a9007c3f 	stp	xzr, xzr, [x1]
    43cc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    43d0:	f900083f 	str	xzr, [x1, #16]
    43d4:	cb050061 	sub	x1, x3, x5
    43d8:	f8247841 	str	x1, [x2, x4, lsl #3]
    43dc:	17fff961 	b	2960 <free@plt>
    43e0:	f100001f 	cmp	x0, #0x0
    43e4:	b0000021 	adrp	x1, 9000 <__divti3+0x100>
    43e8:	91272021 	add	x1, x1, #0x9c8
    43ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    43f0:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    43f4:	9126c000 	add	x0, x0, #0x9b0
    43f8:	910003fd 	mov	x29, sp
    43fc:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4400:	97fffbe0 	bl	3380 <ad_raw_fail>

0000000000004404 <fwp_tape_buffers_dispose>:
    4404:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4408:	910003fd 	mov	x29, sp
    440c:	f9000bf3 	str	x19, [sp, #16]
    4410:	aa0003f3 	mov	x19, x0
    4414:	f9400000 	ldr	x0, [x0]
    4418:	b4000040 	cbz	x0, 4420 <fwp_tape_buffers_dispose+0x1c>
    441c:	97ffffd9 	bl	4380 <ad_raw_free.part.0>
    4420:	f9400a60 	ldr	x0, [x19, #16]
    4424:	b4000040 	cbz	x0, 442c <fwp_tape_buffers_dispose+0x28>
    4428:	97ffffd6 	bl	4380 <ad_raw_free.part.0>
    442c:	f9401260 	ldr	x0, [x19, #32]
    4430:	b4000040 	cbz	x0, 4438 <fwp_tape_buffers_dispose+0x34>
    4434:	97ffffd3 	bl	4380 <ad_raw_free.part.0>
    4438:	4f000400 	movi	v0.4s, #0x0
    443c:	f9001a7f 	str	xzr, [x19, #48]
    4440:	ad000260 	stp	q0, q0, [x19]
    4444:	3d800a60 	str	q0, [x19, #32]
    4448:	f9400bf3 	ldr	x19, [sp, #16]
    444c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4450:	d65f03c0 	ret

0000000000004454 <ad_raw_realloc>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	f90013f5 	str	x21, [sp, #32]
    4464:	b40005a1 	cbz	x1, 4518 <ad_raw_realloc+0xc4>
    4468:	aa0103f4 	mov	x20, x1
    446c:	2a0203f5 	mov	w21, w2
    4470:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbc0>
    4474:	d2800004 	mov	x4, #0x0                   	// #0
    4478:	91110025 	add	x5, x1, #0x440
    447c:	14000005 	b	4490 <ad_raw_realloc+0x3c>
    4480:	91000484 	add	x4, x4, #0x1
    4484:	910060a5 	add	x5, x5, #0x18
    4488:	f140049f 	cmp	x4, #0x1, lsl #12
    448c:	54000320 	b.eq	44f0 <ad_raw_realloc+0x9c>  // b.none
    4490:	f94000a6 	ldr	x6, [x5]
    4494:	eb06001f 	cmp	x0, x6
    4498:	54ffff41 	b.ne	4480 <ad_raw_realloc+0x2c>  // b.any
    449c:	8b040484 	add	x4, x4, x4, lsl #1
    44a0:	91110021 	add	x1, x1, #0x440
    44a4:	8b040c33 	add	x19, x1, x4, lsl #3
    44a8:	b4000080 	cbz	x0, 44b8 <ad_raw_realloc+0x64>
    44ac:	b9401261 	ldr	w1, [x19, #16]
    44b0:	6b15003f 	cmp	w1, w21
    44b4:	540002c1 	b.ne	450c <ad_raw_realloc+0xb8>  // b.any
    44b8:	aa1403e1 	mov	x1, x20
    44bc:	97fff8f5 	bl	2890 <realloc@plt>
    44c0:	aa0003ed 	mov	x13, x0
    44c4:	b40000c0 	cbz	x0, 44dc <ad_raw_realloc+0x88>
    44c8:	2a1503e3 	mov	w3, w21
    44cc:	aa1403e2 	mov	x2, x20
    44d0:	aa1303e0 	mov	x0, x19
    44d4:	aa0d03e1 	mov	x1, x13
    44d8:	97fffaae 	bl	2f90 <ad_raw_record>
    44dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e0:	aa0d03e0 	mov	x0, x13
    44e4:	f94013f5 	ldr	x21, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	f100001f 	cmp	x0, #0x0
    44f4:	b0000021 	adrp	x1, 9000 <__divti3+0x100>
    44f8:	91272021 	add	x1, x1, #0x9c8
    44fc:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    4500:	9126c000 	add	x0, x0, #0x9b0
    4504:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4508:	97fffb9e 	bl	3380 <ad_raw_fail>
    450c:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    4510:	91282000 	add	x0, x0, #0xa08
    4514:	97fffb9b 	bl	3380 <ad_raw_fail>
    4518:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    451c:	9127a000 	add	x0, x0, #0x9e8
    4520:	97fffb98 	bl	3380 <ad_raw_fail>

0000000000004524 <fwp_tape_buffers_release>:
    4524:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4528:	910003fd 	mov	x29, sp
    452c:	a90153f3 	stp	x19, x20, [sp, #16]
    4530:	aa0003f4 	mov	x20, x0
    4534:	f9401400 	ldr	x0, [x0, #40]
    4538:	a9025bf5 	stp	x21, x22, [sp, #32]
    453c:	b7f80560 	tbnz	x0, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4540:	f9401a93 	ldr	x19, [x20, #48]
    4544:	b7f80533 	tbnz	x19, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4548:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    454c:	eb01001f 	cmp	x0, x1
    4550:	540004c8 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4554:	8b000400 	add	x0, x0, x0, lsl #1
    4558:	d2a00101 	mov	x1, #0x80000               	// #524288
    455c:	d37df000 	lsl	x0, x0, #3
    4560:	cb000021 	sub	x1, x1, x0
    4564:	eb410e7f 	cmp	x19, x1, lsr #3
    4568:	54000408 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    456c:	8b130c13 	add	x19, x0, x19, lsl #3
    4570:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    4574:	91288000 	add	x0, x0, #0xa20
    4578:	97fff92e 	bl	2a30 <getenv@plt>
    457c:	b4000080 	cbz	x0, 458c <fwp_tape_buffers_release+0x68>
    4580:	39400001 	ldrb	w1, [x0]
    4584:	7100c03f 	cmp	w1, #0x30
    4588:	54000880 	b.eq	4698 <fwp_tape_buffers_release+0x174>  // b.none
    458c:	d1000661 	sub	x1, x19, #0x1
    4590:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4594:	eb00003f 	cmp	x1, x0
    4598:	54000328 	b.hi	45fc <fwp_tape_buffers_release+0xd8>  // b.pmore
    459c:	900000f5 	adrp	x21, 20000 <__data_start>
    45a0:	f9001bf7 	str	x23, [sp, #48]
    45a4:	910142b7 	add	x23, x21, #0x50
    45a8:	910382f6 	add	x22, x23, #0xe0
    45ac:	aa1603e0 	mov	x0, x22
    45b0:	97ffff95 	bl	4404 <fwp_tape_buffers_dispose>
    45b4:	ad400a81 	ldp	q1, q2, [x20]
    45b8:	f9008ef3 	str	x19, [x23, #280]
    45bc:	4f000400 	movi	v0.4s, #0x0
    45c0:	ad000ac1 	stp	q1, q2, [x22]
    45c4:	3dc00a81 	ldr	q1, [x20, #32]
    45c8:	3d800ac1 	str	q1, [x22, #32]
    45cc:	f9401a80 	ldr	x0, [x20, #48]
    45d0:	f9001ac0 	str	x0, [x22, #48]
    45d4:	f9001a9f 	str	xzr, [x20, #48]
    45d8:	ad000280 	stp	q0, q0, [x20]
    45dc:	3d800a80 	str	q0, [x20, #32]
    45e0:	f9401bf7 	ldr	x23, [sp, #48]
    45e4:	1400000b 	b	4610 <fwp_tape_buffers_release+0xec>
    45e8:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    45ec:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    45f0:	91288000 	add	x0, x0, #0xa20
    45f4:	97fff90f 	bl	2a30 <getenv@plt>
    45f8:	b5fffc40 	cbnz	x0, 4580 <fwp_tape_buffers_release+0x5c>
    45fc:	aa1403e0 	mov	x0, x20
    4600:	97ffff81 	bl	4404 <fwp_tape_buffers_dispose>
    4604:	900000f5 	adrp	x21, 20000 <__data_start>
    4608:	910142a0 	add	x0, x21, #0x50
    460c:	f9408c13 	ldr	x19, [x0, #280]
    4610:	910142a2 	add	x2, x21, #0x50
    4614:	f9409044 	ldr	x4, [x2, #288]
    4618:	a9400c45 	ldp	x5, x3, [x2]
    461c:	8b040481 	add	x1, x4, x4, lsl #1
    4620:	f9400840 	ldr	x0, [x2, #16]
    4624:	8b010881 	add	x1, x4, x1, lsl #2
    4628:	f9400c44 	ldr	x4, [x2, #24]
    462c:	8b0300a3 	add	x3, x5, x3
    4630:	d37df021 	lsl	x1, x1, #3
    4634:	8b040000 	add	x0, x0, x4
    4638:	8b030000 	add	x0, x0, x3
    463c:	eb05003f 	cmp	x1, x5
    4640:	54000321 	b.ne	46a4 <fwp_tape_buffers_release+0x180>  // b.any
    4644:	8b130023 	add	x3, x1, x19
    4648:	eb00007f 	cmp	x3, x0
    464c:	540002c8 	b.hi	46a4 <fwp_tape_buffers_release+0x180>  // b.pmore
    4650:	f9405c43 	ldr	x3, [x2, #184]
    4654:	f140087f 	cmp	x3, #0x2, lsl #12
    4658:	540002e0 	b.eq	46b4 <fwp_tape_buffers_release+0x190>  // b.none
    465c:	8b030464 	add	x4, x3, x3, lsl #1
    4660:	90000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    4664:	911100a5 	add	x5, x5, #0x440
    4668:	cb010000 	sub	x0, x0, x1
    466c:	d37df084 	lsl	x4, x4, #3
    4670:	cb130000 	sub	x0, x0, x19
    4674:	8b0400a6 	add	x6, x5, x4
    4678:	91000463 	add	x3, x3, #0x1
    467c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4680:	f82468a1 	str	x1, [x5, x4]
    4684:	a90080d3 	stp	x19, x0, [x6, #8]
    4688:	f9005c43 	str	x3, [x2, #184]
    468c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4690:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4694:	d65f03c0 	ret
    4698:	39400400 	ldrb	w0, [x0, #1]
    469c:	34fffb00 	cbz	w0, 45fc <fwp_tape_buffers_release+0xd8>
    46a0:	17ffffbb 	b	458c <fwp_tape_buffers_release+0x68>
    46a4:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    46a8:	9128e000 	add	x0, x0, #0xa38
    46ac:	f9001bf7 	str	x23, [sp, #48]
    46b0:	97fffb34 	bl	3380 <ad_raw_fail>
    46b4:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    46b8:	9129a000 	add	x0, x0, #0xa68
    46bc:	f9001bf7 	str	x23, [sp, #48]
    46c0:	97fffb30 	bl	3380 <ad_raw_fail>

00000000000046c4 <fwp_poll_events>:
    46c4:	d10103ff 	sub	sp, sp, #0x40
    46c8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    46cc:	f947f400 	ldr	x0, [x0, #4072]
    46d0:	a9027bfd 	stp	x29, x30, [sp, #32]
    46d4:	910083fd 	add	x29, sp, #0x20
    46d8:	a90353f3 	stp	x19, x20, [sp, #48]
    46dc:	900000f4 	adrp	x20, 20000 <__data_start>
    46e0:	f9400001 	ldr	x1, [x0]
    46e4:	f9000fe1 	str	x1, [sp, #24]
    46e8:	d2800001 	mov	x1, #0x0                   	// #0
    46ec:	97fffca5 	bl	3980 <fwp_now_ns>
    46f0:	91014281 	add	x1, x20, #0x50
    46f4:	f9409433 	ldr	x19, [x1, #296]
    46f8:	b4000e73 	cbz	x19, 48c4 <fwp_poll_events+0x200>
    46fc:	aa1303e1 	mov	x1, x19
    4700:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4704:	14000005 	b	4718 <fwp_poll_events+0x54>
    4708:	f9408821 	ldr	x1, [x1, #272]
    470c:	eb03005f 	cmp	x2, x3
    4710:	9a83d042 	csel	x2, x2, x3, le
    4714:	b40000c1 	cbz	x1, 472c <fwp_poll_events+0x68>
    4718:	f9403423 	ldr	x3, [x1, #104]
    471c:	b6ffff62 	tbz	x2, #63, 4708 <fwp_poll_events+0x44>
    4720:	f9408821 	ldr	x1, [x1, #272]
    4724:	aa0303e2 	mov	x2, x3
    4728:	b5ffff81 	cbnz	x1, 4718 <fwp_poll_events+0x54>
    472c:	b7f80cc2 	tbnz	x2, #63, 48c4 <fwp_poll_events+0x200>
    4730:	cb000042 	sub	x2, x2, x0
    4734:	f100005f 	cmp	x2, #0x0
    4738:	540005ad 	b.le	47ec <fwp_poll_events+0x128>
    473c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4740:	d2884801 	mov	x1, #0x4240                	// #16960
    4744:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4748:	f2a001e1 	movk	x1, #0xf, lsl #16
    474c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4750:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4754:	f2e86360 	movk	x0, #0x431b, lsl #48
    4758:	9b407c40 	smulh	x0, x2, x0
    475c:	9352fc00 	asr	x0, x0, #18
    4760:	cb82fc00 	sub	x0, x0, x2, asr #63
    4764:	9b018802 	msub	x2, x0, x1, x2
    4768:	f100005f 	cmp	x2, #0x0
    476c:	9a800400 	cinc	x0, x0, ne	// ne = any
    4770:	eb03001f 	cmp	x0, x3
    4774:	540009ec 	b.gt	48b0 <fwp_poll_events+0x1ec>
    4778:	340003a0 	cbz	w0, 47ec <fwp_poll_events+0x128>
    477c:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4780:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4784:	72a20c42 	movk	w2, #0x1062, lsl #16
    4788:	9ba27c02 	umull	x2, w0, w2
    478c:	d366fc43 	lsr	x3, x2, #38
    4790:	aa0303e2 	mov	x2, x3
    4794:	1b048063 	msub	w3, w3, w4, w0
    4798:	9b217c63 	smull	x3, w3, w1
    479c:	d2800001 	mov	x1, #0x0                   	// #0
    47a0:	910023e0 	add	x0, sp, #0x8
    47a4:	a9008fe2 	stp	x2, x3, [sp, #8]
    47a8:	97fff872 	bl	2970 <nanosleep@plt>
    47ac:	91014280 	add	x0, x20, #0x50
    47b0:	f9409413 	ldr	x19, [x0, #296]
    47b4:	97fffc73 	bl	3980 <fwp_now_ns>
    47b8:	aa0003e6 	mov	x6, x0
    47bc:	b50001d3 	cbnz	x19, 47f4 <fwp_poll_events+0x130>
    47c0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    47c4:	f947f400 	ldr	x0, [x0, #4072]
    47c8:	f9400fe2 	ldr	x2, [sp, #24]
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	eb010042 	subs	x2, x2, x1
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	540008c1 	b.ne	48f0 <fwp_poll_events+0x22c>  // b.any
    47dc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    47e0:	a94353f3 	ldp	x19, x20, [sp, #48]
    47e4:	910103ff 	add	sp, sp, #0x40
    47e8:	d65f03c0 	ret
    47ec:	97fffc65 	bl	3980 <fwp_now_ns>
    47f0:	aa0003e6 	mov	x6, x0
    47f4:	4f000400 	movi	v0.4s, #0x0
    47f8:	91014288 	add	x8, x20, #0x50
    47fc:	52800027 	mov	w7, #0x1                   	// #1
    4800:	f9403661 	ldr	x1, [x19, #104]
    4804:	aa1303e5 	mov	x5, x19
    4808:	f9408a73 	ldr	x19, [x19, #272]
    480c:	eb06003f 	cmp	x1, x6
    4810:	5400032c 	b.gt	4874 <fwp_poll_events+0x1b0>
    4814:	394154a0 	ldrb	w0, [x5, #85]
    4818:	36000120 	tbz	w0, #0, 483c <fwp_poll_events+0x178>
    481c:	f94084a0 	ldr	x0, [x5, #264]
    4820:	b40003c0 	cbz	x0, 4898 <fwp_poll_events+0x1d4>
    4824:	f9008813 	str	x19, [x0, #272]
    4828:	b4000053 	cbz	x19, 4830 <fwp_poll_events+0x16c>
    482c:	f9008660 	str	x0, [x19, #264]
    4830:	910800a0 	add	x0, x5, #0x200
    4834:	390154bf 	strb	wzr, [x5, #85]
    4838:	3c908000 	stur	q0, [x0, #-248]
    483c:	f94030a0 	ldr	x0, [x5, #96]
    4840:	390158a7 	strb	w7, [x5, #86]
    4844:	f100001f 	cmp	x0, #0x0
    4848:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    484c:	5400018d 	b.le	487c <fwp_poll_events+0x1b8>
    4850:	f94028a0 	ldr	x0, [x5, #80]
    4854:	f2001c1f 	tst	x0, #0xff000000ff
    4858:	540000e1 	b.ne	4874 <fwp_poll_events+0x1b0>  // b.any
    485c:	f9406100 	ldr	x0, [x8, #192]
    4860:	390150a7 	strb	w7, [x5, #84]
    4864:	f90080bf 	str	xzr, [x5, #256]
    4868:	b40001e0 	cbz	x0, 48a4 <fwp_poll_events+0x1e0>
    486c:	f9006105 	str	x5, [x8, #192]
    4870:	f9008005 	str	x5, [x0, #256]
    4874:	b5fffc73 	cbnz	x19, 4800 <fwp_poll_events+0x13c>
    4878:	17ffffd2 	b	47c0 <fwp_poll_events+0xfc>
    487c:	394144a0 	ldrb	w0, [x5, #81]
    4880:	3707fe80 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    4884:	394140a0 	ldrb	w0, [x5, #80]
    4888:	3707fe40 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    488c:	aa0503e0 	mov	x0, x5
    4890:	97fffb98 	bl	36f0 <fwp_cancel_tree.part.0>
    4894:	17ffffef 	b	4850 <fwp_poll_events+0x18c>
    4898:	91014281 	add	x1, x20, #0x50
    489c:	f9009433 	str	x19, [x1, #296]
    48a0:	17ffffe2 	b	4828 <fwp_poll_events+0x164>
    48a4:	f9006105 	str	x5, [x8, #192]
    48a8:	f9006505 	str	x5, [x8, #200]
    48ac:	17fffff2 	b	4874 <fwp_poll_events+0x1b0>
    48b0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    48b4:	d2989362 	mov	x2, #0xc49b                	// #50331
    48b8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    48bc:	f2a00402 	movk	x2, #0x20, lsl #16
    48c0:	17ffffb7 	b	479c <fwp_poll_events+0xd8>
    48c4:	97fff9ec 	bl	3074 <fwp_flush>
    48c8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    48cc:	f947e863 	ldr	x3, [x3, #4048]
    48d0:	d2800562 	mov	x2, #0x2b                  	// #43
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    48dc:	912a2000 	add	x0, x0, #0xa88
    48e0:	f9400063 	ldr	x3, [x3]
    48e4:	97fff82f 	bl	29a0 <fwrite@plt>
    48e8:	52800ca0 	mov	w0, #0x65                  	// #101
    48ec:	97fff799 	bl	2750 <exit@plt>
    48f0:	97fff7ec 	bl	28a0 <__stack_chk_fail@plt>

00000000000048f4 <fwp_rc_wide_dup>:
    48f4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48f8:	910003fd 	mov	x29, sp
    48fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4900:	aa0003f3 	mov	x19, x0
    4904:	ca404400 	eor	x0, x0, x0, lsr #17
    4908:	f90013f5 	str	x21, [sp, #32]
    490c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4910:	ca402400 	eor	x0, x0, x0, lsr #9
    4914:	911882a2 	add	x2, x21, #0x620
    4918:	92401c00 	and	x0, x0, #0xff
    491c:	910a2403 	add	x3, x0, #0x289
    4920:	8b000c40 	add	x0, x2, x0, lsl #3
    4924:	8b030c54 	add	x20, x2, x3, lsl #3
    4928:	f94a2401 	ldr	x1, [x0, #5192]
    492c:	b50000a1 	cbnz	x1, 4940 <fwp_rc_wide_dup+0x4c>
    4930:	1400002d 	b	49e4 <fwp_rc_wide_dup+0xf0>
    4934:	91004034 	add	x20, x1, #0x10
    4938:	f9400821 	ldr	x1, [x1, #16]
    493c:	b4000241 	cbz	x1, 4984 <fwp_rc_wide_dup+0x90>
    4940:	f9400022 	ldr	x2, [x1]
    4944:	eb02027f 	cmp	x19, x2
    4948:	54ffff61 	b.ne	4934 <fwp_rc_wide_dup+0x40>  // b.any
    494c:	f9400281 	ldr	x1, [x20]
    4950:	39400260 	ldrb	w0, [x19]
    4954:	7103f81f 	cmp	w0, #0xfe
    4958:	54000220 	b.eq	499c <fwp_rc_wide_dup+0xa8>  // b.none
    495c:	b40001a1 	cbz	x1, 4990 <fwp_rc_wide_dup+0x9c>
    4960:	f9400420 	ldr	x0, [x1, #8]
    4964:	b100041f 	cmn	x0, #0x1
    4968:	540004a0 	b.eq	49fc <fwp_rc_wide_dup+0x108>  // b.none
    496c:	91000400 	add	x0, x0, #0x1
    4970:	f9000420 	str	x0, [x1, #8]
    4974:	a94153f3 	ldp	x19, x20, [sp, #16]
    4978:	f94013f5 	ldr	x21, [sp, #32]
    497c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4980:	d65f03c0 	ret
    4984:	39400260 	ldrb	w0, [x19]
    4988:	7103f81f 	cmp	w0, #0xfe
    498c:	540000a0 	b.eq	49a0 <fwp_rc_wide_dup+0xac>  // b.none
    4990:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    4994:	912b8000 	add	x0, x0, #0xae0
    4998:	97fffb9a 	bl	3800 <fwp_trap>
    499c:	b5000281 	cbnz	x1, 49ec <fwp_rc_wide_dup+0xf8>
    49a0:	d2800300 	mov	x0, #0x18                  	// #24
    49a4:	97fff7a7 	bl	2840 <malloc@plt>
    49a8:	b4000280 	cbz	x0, 49f8 <fwp_rc_wide_dup+0x104>
    49ac:	d2801fe1 	mov	x1, #0xff                  	// #255
    49b0:	a9000413 	stp	x19, x1, [x0]
    49b4:	911882b5 	add	x21, x21, #0x620
    49b8:	f900081f 	str	xzr, [x0, #16]
    49bc:	12800001 	mov	w1, #0xffffffff            	// #-1
    49c0:	f9000280 	str	x0, [x20]
    49c4:	39000261 	strb	w1, [x19]
    49c8:	f94e26a0 	ldr	x0, [x21, #7240]
    49cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    49d0:	91000400 	add	x0, x0, #0x1
    49d4:	f90e26a0 	str	x0, [x21, #7240]
    49d8:	f94013f5 	ldr	x21, [sp, #32]
    49dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49e0:	d65f03c0 	ret
    49e4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    49e8:	17ffffda 	b	4950 <fwp_rc_wide_dup+0x5c>
    49ec:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    49f0:	912ae000 	add	x0, x0, #0xab8
    49f4:	97fffb83 	bl	3800 <fwp_trap>
    49f8:	97fff9de 	bl	3170 <fwp_heap_oom>
    49fc:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    4a00:	912c2000 	add	x0, x0, #0xb08
    4a04:	97fffb7f 	bl	3800 <fwp_trap>
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_rc_forget_slot>:
    4a10:	aa0003e1 	mov	x1, x0
    4a14:	39400000 	ldrb	w0, [x0]
    4a18:	7103fc1f 	cmp	w0, #0xff
    4a1c:	54000040 	b.eq	4a24 <fwp_rc_forget_slot+0x14>  // b.none
    4a20:	d65f03c0 	ret
    4a24:	ca414420 	eor	x0, x1, x1, lsr #17
    4a28:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4a2c:	ca402400 	eor	x0, x0, x0, lsr #9
    4a30:	910003fd 	mov	x29, sp
    4a34:	92401c00 	and	x0, x0, #0xff
    4a38:	f9000bf3 	str	x19, [sp, #16]
    4a3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    4a40:	91188262 	add	x2, x19, #0x620
    4a44:	910a2403 	add	x3, x0, #0x289
    4a48:	8b000c40 	add	x0, x2, x0, lsl #3
    4a4c:	8b030c43 	add	x3, x2, x3, lsl #3
    4a50:	f94a2400 	ldr	x0, [x0, #5192]
    4a54:	b50000a0 	cbnz	x0, 4a68 <fwp_rc_forget_slot+0x58>
    4a58:	14000011 	b	4a9c <fwp_rc_forget_slot+0x8c>
    4a5c:	91004003 	add	x3, x0, #0x10
    4a60:	f9400800 	ldr	x0, [x0, #16]
    4a64:	b40001c0 	cbz	x0, 4a9c <fwp_rc_forget_slot+0x8c>
    4a68:	f9400002 	ldr	x2, [x0]
    4a6c:	eb02003f 	cmp	x1, x2
    4a70:	54ffff61 	b.ne	4a5c <fwp_rc_forget_slot+0x4c>  // b.any
    4a74:	f9400801 	ldr	x1, [x0, #16]
    4a78:	91188273 	add	x19, x19, #0x620
    4a7c:	f9000061 	str	x1, [x3]
    4a80:	97fff7b8 	bl	2960 <free@plt>
    4a84:	f94e2660 	ldr	x0, [x19, #7240]
    4a88:	d1000400 	sub	x0, x0, #0x1
    4a8c:	f90e2660 	str	x0, [x19, #7240]
    4a90:	f9400bf3 	ldr	x19, [sp, #16]
    4a94:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a98:	d65f03c0 	ret
    4a9c:	b0000020 	adrp	x0, 9000 <__divti3+0x100>
    4aa0:	912b8000 	add	x0, x0, #0xae0
    4aa4:	97fffb57 	bl	3800 <fwp_trap>
    4aa8:	d503201f 	nop
    4aac:	d503201f 	nop

0000000000004ab0 <fwp_rc_prepare_chunk>:
    4ab0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ab4:	910003fd 	mov	x29, sp
    4ab8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4abc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    4ac0:	911882c2 	add	x2, x22, #0x620
    4ac4:	b9401c03 	ldr	w3, [x0, #28]
    4ac8:	aa0103f5 	mov	x21, x1
    4acc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ad0:	aa0003f4 	mov	x20, x0
    4ad4:	f94e2440 	ldr	x0, [x2, #7240]
    4ad8:	b4000440 	cbz	x0, 4b60 <fwp_rc_prepare_chunk+0xb0>
    4adc:	d2800013 	mov	x19, #0x0                   	// #0
    4ae0:	35000203 	cbnz	w3, 4b20 <fwp_rc_prepare_chunk+0x70>
    4ae4:	b4000361 	cbz	x1, 4b50 <fwp_rc_prepare_chunk+0xa0>
    4ae8:	f9401280 	ldr	x0, [x20, #32]
    4aec:	97fff79d 	bl	2960 <free@plt>
    4af0:	aa1503e0 	mov	x0, x21
    4af4:	d2800021 	mov	x1, #0x1                   	// #1
    4af8:	97fff762 	bl	2880 <calloc@plt>
    4afc:	f9001280 	str	x0, [x20, #32]
    4b00:	b5000460 	cbnz	x0, 4b8c <fwp_rc_prepare_chunk+0xdc>
    4b04:	97fff99b 	bl	3170 <fwp_heap_oom>
    4b08:	97ffffc2 	bl	4a10 <fwp_rc_forget_slot>
    4b0c:	91000673 	add	x19, x19, #0x1
    4b10:	b9401e83 	ldr	w3, [x20, #28]
    4b14:	eb13007f 	cmp	x3, x19
    4b18:	54000169 	b.ls	4b44 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4b1c:	d503201f 	nop
    4b20:	f9401283 	ldr	x3, [x20, #32]
    4b24:	8b130060 	add	x0, x3, x19
    4b28:	38736863 	ldrb	w3, [x3, x19]
    4b2c:	7103fc7f 	cmp	w3, #0xff
    4b30:	54fffec0 	b.eq	4b08 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b34:	b9401e83 	ldr	w3, [x20, #28]
    4b38:	91000673 	add	x19, x19, #0x1
    4b3c:	eb13007f 	cmp	x3, x19
    4b40:	54ffff08 	b.hi	4b20 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b44:	eb0302bf 	cmp	x21, x3
    4b48:	54000121 	b.ne	4b6c <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b4c:	b5000335 	cbnz	x21, 4bb0 <fwp_rc_prepare_chunk+0x100>
    4b50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b5c:	d65f03c0 	ret
    4b60:	2a0303e3 	mov	w3, w3
    4b64:	eb0302bf 	cmp	x21, x3
    4b68:	54ffff20 	b.eq	4b4c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4b6c:	911882c2 	add	x2, x22, #0x620
    4b70:	f9401280 	ldr	x0, [x20, #32]
    4b74:	f94e2841 	ldr	x1, [x2, #7248]
    4b78:	cb030021 	sub	x1, x1, x3
    4b7c:	f90e2841 	str	x1, [x2, #7248]
    4b80:	97fff778 	bl	2960 <free@plt>
    4b84:	b5fffb75 	cbnz	x21, 4af0 <fwp_rc_prepare_chunk+0x40>
    4b88:	f900129f 	str	xzr, [x20, #32]
    4b8c:	911882d6 	add	x22, x22, #0x620
    4b90:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b94:	b9001e95 	str	w21, [x20, #28]
    4b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b9c:	8b150000 	add	x0, x0, x21
    4ba0:	f90e2ac0 	str	x0, [x22, #7248]
    4ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bac:	d65f03c0 	ret
    4bb0:	f9401280 	ldr	x0, [x20, #32]
    4bb4:	aa1503e2 	mov	x2, x21
    4bb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bbc:	52800001 	mov	w1, #0x0                   	// #0
    4bc0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bc8:	17fff72a 	b	2870 <memset@plt>
    4bcc:	d503201f 	nop

0000000000004bd0 <fwp_heap_refill>:
    4bd0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4bd4:	910003fd 	mov	x29, sp
    4bd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4bdc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4be0:	911882b5 	add	x21, x21, #0x620
    4be4:	aa0003f6 	mov	x22, x0
    4be8:	d2800020 	mov	x0, #0x1                   	// #1
    4bec:	a90153f3 	stp	x19, x20, [sp, #16]
    4bf0:	a90363f7 	stp	x23, x24, [sp, #48]
    4bf4:	2a0103f7 	mov	w23, w1
    4bf8:	2a0203f8 	mov	w24, w2
    4bfc:	97fff96d 	bl	31b0 <fwp_heap_chunks>
    4c00:	aa0003f3 	mov	x19, x0
    4c04:	f949fea2 	ldr	x2, [x21, #5112]
    4c08:	8b000800 	add	x0, x0, x0, lsl #2
    4c0c:	2a1703e1 	mov	w1, w23
    4c10:	52800025 	mov	w5, #0x1                   	// #1
    4c14:	d37df000 	lsl	x0, x0, #3
    4c18:	910f0021 	add	x1, x1, #0x3c0
    4c1c:	8b000054 	add	x20, x2, x0
    4c20:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4c24:	52a00024 	mov	w4, #0x10000               	// #65536
    4c28:	38206845 	strb	w5, [x2, x0]
    4c2c:	aa1403e0 	mov	x0, x20
    4c30:	39000698 	strb	w24, [x20, #1]
    4c34:	39000a97 	strb	w23, [x20, #2]
    4c38:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c3c:	b9000681 	str	w1, [x20, #4]
    4c40:	2a0103e5 	mov	w5, w1
    4c44:	8b0300a2 	add	x2, x5, x3
    4c48:	1ac10881 	udiv	w1, w4, w1
    4c4c:	9ac50842 	udiv	x2, x2, x5
    4c50:	b9000a81 	str	w1, [x20, #8]
    4c54:	92404021 	and	x1, x1, #0x1ffff
    4c58:	b9001a82 	str	w2, [x20, #24]
    4c5c:	97ffff95 	bl	4ab0 <fwp_rc_prepare_chunk>
    4c60:	f949daa0 	ldr	x0, [x21, #5040]
    4c64:	29408a81 	ldp	w1, w2, [x20, #4]
    4c68:	8b134000 	add	x0, x0, x19, lsl #16
    4c6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c70:	8b214003 	add	x3, x0, w1, uxtw
    4c74:	9ba20021 	umaddl	x1, w1, w2, x0
    4c78:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c7c:	a90086c3 	stp	x3, x1, [x22, #8]
    4c80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c84:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c88:	d65f03c0 	ret
    4c8c:	d503201f 	nop

0000000000004c90 <fwp_mem_free>:
    4c90:	b40003c0 	cbz	x0, 4d08 <fwp_mem_free+0x78>
    4c94:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c98:	910003fd 	mov	x29, sp
    4c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ca0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4ca4:	911882a1 	add	x1, x21, #0x620
    4ca8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cac:	aa0003f3 	mov	x19, x0
    4cb0:	f949d823 	ldr	x3, [x1, #5040]
    4cb4:	f949ec22 	ldr	x2, [x1, #5080]
    4cb8:	cb030000 	sub	x0, x0, x3
    4cbc:	eb02401f 	cmp	x0, x2, lsl #16
    4cc0:	540001c2 	b.cs	4cf8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4cc4:	d350fc16 	lsr	x22, x0, #16
    4cc8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ccc:	f949fc22 	ldr	x2, [x1, #5112]
    4cd0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4cd4:	d37df294 	lsl	x20, x20, #3
    4cd8:	ab140057 	adds	x23, x2, x20
    4cdc:	540000c0 	b.eq	4cf4 <fwp_mem_free+0x64>  // b.none
    4ce0:	38746842 	ldrb	w2, [x2, x20]
    4ce4:	7100045f 	cmp	w2, #0x1
    4ce8:	54000120 	b.eq	4d0c <fwp_mem_free+0x7c>  // b.none
    4cec:	7100085f 	cmp	w2, #0x2
    4cf0:	540005e0 	b.eq	4dac <fwp_mem_free+0x11c>  // b.none
    4cf4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d00:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d04:	d65f03c0 	ret
    4d08:	d65f03c0 	ret
    4d0c:	f94012f8 	ldr	x24, [x23, #32]
    4d10:	b94006e1 	ldr	w1, [x23, #4]
    4d14:	f90023f9 	str	x25, [sp, #64]
    4d18:	2a0103e2 	mov	w2, w1
    4d1c:	394006f9 	ldrb	w25, [x23, #1]
    4d20:	39400af4 	ldrb	w20, [x23, #2]
    4d24:	b4000158 	cbz	x24, 4d4c <fwp_mem_free+0xbc>
    4d28:	92403e76 	and	x22, x19, #0xffff
    4d2c:	9ac20ad6 	udiv	x22, x22, x2
    4d30:	38766b01 	ldrb	w1, [x24, x22]
    4d34:	8b160300 	add	x0, x24, x22
    4d38:	7103fc3f 	cmp	w1, #0xff
    4d3c:	54000980 	b.eq	4e6c <fwp_mem_free+0x1dc>  // b.none
    4d40:	38366b1f 	strb	wzr, [x24, x22]
    4d44:	b94006e1 	ldr	w1, [x23, #4]
    4d48:	2a0103e2 	mov	w2, w1
    4d4c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4d50:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4d54:	cb390000 	sub	x0, x0, w25, uxtb
    4d58:	8b340074 	add	x20, x3, w20, uxtb
    4d5c:	911882b5 	add	x21, x21, #0x620
    4d60:	1e630021 	ucvtf	d1, w1
    4d64:	d37ae400 	lsl	x0, x0, #6
    4d68:	8b140c14 	add	x20, x0, x20, lsl #3
    4d6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d70:	f8746aa0 	ldr	x0, [x21, x20]
    4d74:	f94023f9 	ldr	x25, [sp, #64]
    4d78:	aa2003e0 	mvn	x0, x0
    4d7c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d80:	f9000260 	str	x0, [x19]
    4d84:	f8346ab3 	str	x19, [x21, x20]
    4d88:	f94a12a0 	ldr	x0, [x21, #5152]
    4d8c:	1e612800 	fadd	d0, d0, d1
    4d90:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d94:	cb020000 	sub	x0, x0, x2
    4d98:	f90a12a0 	str	x0, [x21, #5152]
    4d9c:	fd0a22a0 	str	d0, [x21, #5184]
    4da0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4da4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4da8:	d65f03c0 	ret
    4dac:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4db0:	8b000063 	add	x3, x3, x0
    4db4:	eb03027f 	cmp	x19, x3
    4db8:	54fff9e1 	b.ne	4cf4 <fwp_mem_free+0x64>  // b.any
    4dbc:	fd400ae1 	ldr	d1, [x23, #16]
    4dc0:	fd4a2020 	ldr	d0, [x1, #5184]
    4dc4:	f9400ae0 	ldr	x0, [x23, #16]
    4dc8:	7e61d821 	ucvtf	d1, d1
    4dcc:	f94a1022 	ldr	x2, [x1, #5152]
    4dd0:	f94012f3 	ldr	x19, [x23, #32]
    4dd4:	1e612800 	fadd	d0, d0, d1
    4dd8:	cb000042 	sub	x2, x2, x0
    4ddc:	f90a1022 	str	x2, [x1, #5152]
    4de0:	fd0a2020 	str	d0, [x1, #5184]
    4de4:	b40000b3 	cbz	x19, 4df8 <fwp_mem_free+0x168>
    4de8:	39400260 	ldrb	w0, [x19]
    4dec:	7103fc1f 	cmp	w0, #0xff
    4df0:	54000380 	b.eq	4e60 <fwp_mem_free+0x1d0>  // b.none
    4df4:	3900027f 	strb	wzr, [x19]
    4df8:	b9400ee2 	ldr	w2, [x23, #12]
    4dfc:	b4000142 	cbz	x2, 4e24 <fwp_mem_free+0x194>
    4e00:	911882a1 	add	x1, x21, #0x620
    4e04:	8b160040 	add	x0, x2, x22
    4e08:	8b000800 	add	x0, x0, x0, lsl #2
    4e0c:	f949fc21 	ldr	x1, [x1, #5112]
    4e10:	8b140034 	add	x20, x1, x20
    4e14:	8b000c20 	add	x0, x1, x0, lsl #3
    4e18:	3802869f 	strb	wzr, [x20], #40
    4e1c:	eb00029f 	cmp	x20, x0
    4e20:	54ffffc1 	b.ne	4e18 <fwp_mem_free+0x188>  // b.any
    4e24:	911882a0 	add	x0, x21, #0x620
    4e28:	f94a1801 	ldr	x1, [x0, #5168]
    4e2c:	f949f803 	ldr	x3, [x0, #5104]
    4e30:	8b020021 	add	x1, x1, x2
    4e34:	f90a1801 	str	x1, [x0, #5168]
    4e38:	eb16007f 	cmp	x3, x22
    4e3c:	54000049 	b.ls	4e44 <fwp_mem_free+0x1b4>  // b.plast
    4e40:	f909f816 	str	x22, [x0, #5104]
    4e44:	911882b5 	add	x21, x21, #0x620
    4e48:	f949f6a0 	ldr	x0, [x21, #5096]
    4e4c:	eb16001f 	cmp	x0, x22
    4e50:	54fff529 	b.ls	4cf4 <fwp_mem_free+0x64>  // b.plast
    4e54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e58:	f909f6b6 	str	x22, [x21, #5096]
    4e5c:	17ffffa7 	b	4cf8 <fwp_mem_free+0x68>
    4e60:	aa1303e0 	mov	x0, x19
    4e64:	97fffeeb 	bl	4a10 <fwp_rc_forget_slot>
    4e68:	17ffffe3 	b	4df4 <fwp_mem_free+0x164>
    4e6c:	97fffee9 	bl	4a10 <fwp_rc_forget_slot>
    4e70:	17ffffb4 	b	4d40 <fwp_mem_free+0xb0>

0000000000004e74 <fwp_heap_alloc_big>:
    4e74:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e78:	910003fd 	mov	x29, sp
    4e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4e80:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e84:	a90363f7 	stp	x23, x24, [sp, #48]
    4e88:	aa0003f7 	mov	x23, x0
    4e8c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e90:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e94:	eb0002ff 	cmp	x23, x0
    4e98:	54000888 	b.hi	4fa8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e9c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4ea0:	8b0002f4 	add	x20, x23, x0
    4ea4:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbc0>
    4ea8:	91188359 	add	x25, x26, #0x620
    4eac:	d350fe94 	lsr	x20, x20, #16
    4eb0:	2a0103f5 	mov	w21, w1
    4eb4:	aa1403e0 	mov	x0, x20
    4eb8:	97fff8be 	bl	31b0 <fwp_heap_chunks>
    4ebc:	f949ff22 	ldr	x2, [x25, #5112]
    4ec0:	8b000813 	add	x19, x0, x0, lsl #2
    4ec4:	aa0003f8 	mov	x24, x0
    4ec8:	52800043 	mov	w3, #0x2                   	// #2
    4ecc:	d37df273 	lsl	x19, x19, #3
    4ed0:	d2800021 	mov	x1, #0x1                   	// #1
    4ed4:	8b130040 	add	x0, x2, x19
    4ed8:	38336843 	strb	w3, [x2, x19]
    4edc:	39000415 	strb	w21, [x0, #1]
    4ee0:	b9000c14 	str	w20, [x0, #12]
    4ee4:	f9000817 	str	x23, [x0, #16]
    4ee8:	97fffef2 	bl	4ab0 <fwp_rc_prepare_chunk>
    4eec:	f100069f 	cmp	x20, #0x1
    4ef0:	54000269 	b.ls	4f3c <fwp_heap_alloc_big+0xc8>  // b.plast
    4ef4:	8b180294 	add	x20, x20, x24
    4ef8:	9100a273 	add	x19, x19, #0x28
    4efc:	a90573fb 	stp	x27, x28, [sp, #80]
    4f00:	5280007b 	mov	w27, #0x3                   	// #3
    4f04:	8b140a94 	add	x20, x20, x20, lsl #2
    4f08:	2a1803fc 	mov	w28, w24
    4f0c:	9adb2296 	lsl	x22, x20, x27
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffee4 	bl	4ab0 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0x9c>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	91188353 	add	x19, x26, #0x620
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x104>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118835a 	add	x26, x26, #0x620
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    4fc0:	91188262 	add	x2, x19, #0x620
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	91188262 	add	x2, x19, #0x620
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	91188260 	add	x0, x19, #0x620
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	91188273 	add	x19, x19, #0x620
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffc1c 	bl	4104 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff70 	b	4e74 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	91188260 	add	x0, x19, #0x620
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffeb5 	bl	4bd0 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	54000861 	b.ne	5244 <fwp_heap_alloc+0x134>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbc0>
    5140:	911882f3 	add	x19, x23, #0x620
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	540006e2 	b.cs	5290 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	911882e0 	add	x0, x23, #0x620
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	911882e1 	add	x1, x23, #0x620
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	540002cc 	b.gt	5258 <fwp_heap_alloc+0x148>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000209 	b.ls	5274 <fwp_heap_alloc+0x164>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	17ffffe8 	b	51e0 <fwp_heap_alloc+0xd0>
    5244:	a9538c44 	ldp	x4, x3, [x2, #312]
    5248:	91000484 	add	x4, x4, #0x1
    524c:	8b000063 	add	x3, x3, x0
    5250:	a9138c44 	stp	x4, x3, [x2, #312]
    5254:	17ffffba 	b	513c <fwp_heap_alloc+0x2c>
    5258:	a94153f3 	ldp	x19, x20, [sp, #16]
    525c:	fd00a800 	str	d0, [x0, #336]
    5260:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5264:	aa0403e0 	mov	x0, x4
    5268:	a94363f7 	ldp	x23, x24, [sp, #48]
    526c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5270:	d65f03c0 	ret
    5274:	7100043f 	cmp	w1, #0x1
    5278:	8b140085 	add	x5, x4, x20
    527c:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5280:	52800001 	mov	w1, #0x0                   	// #0
    5284:	aa0403e0 	mov	x0, x4
    5288:	f9000465 	str	x5, [x3, #8]
    528c:	17ffffc6 	b	51a4 <fwp_heap_alloc+0x94>
    5290:	97fff7b8 	bl	3170 <fwp_heap_oom>

0000000000005294 <fwp_data.part.0.constprop.0>:
    5294:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5298:	910003fd 	mov	x29, sp
    529c:	a9025bf5 	stp	x21, x22, [sp, #32]
    52a0:	f00000d6 	adrp	x22, 20000 <__data_start>
    52a4:	910142c2 	add	x2, x22, #0x50
    52a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52ac:	b9413059 	ldr	w25, [x2, #304]
    52b0:	a90153f3 	stp	x19, x20, [sp, #16]
    52b4:	aa0103f4 	mov	x20, x1
    52b8:	a90363f7 	stp	x23, x24, [sp, #48]
    52bc:	2a0003f7 	mov	w23, w0
    52c0:	340000b9 	cbz	w25, 52d4 <fwp_data.part.0.constprop.0+0x40>
    52c4:	a9538041 	ldp	x1, x0, [x2, #312]
    52c8:	91000421 	add	x1, x1, #0x1
    52cc:	91006000 	add	x0, x0, #0x18
    52d0:	a9138041 	stp	x1, x0, [x2, #312]
    52d4:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    52d8:	911882a3 	add	x3, x21, #0x620
    52dc:	b953a460 	ldr	w0, [x3, #5028]
    52e0:	34000840 	cbz	w0, 53e8 <fwp_data.part.0.constprop.0+0x154>
    52e4:	397e8862 	ldrb	w2, [x3, #4002]
    52e8:	910f0040 	add	x0, x2, #0x3c0
    52ec:	8b020442 	add	x2, x2, x2, lsl #1
    52f0:	d37df042 	lsl	x2, x2, #3
    52f4:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    52f8:	2a1a03f8 	mov	w24, w26
    52fc:	f8626873 	ldr	x19, [x3, x2]
    5300:	b4000613 	cbz	x19, 53c0 <fwp_data.part.0.constprop.0+0x12c>
    5304:	f9400260 	ldr	x0, [x19]
    5308:	aa2003e0 	mvn	x0, x0
    530c:	f8226860 	str	x0, [x3, x2]
    5310:	f100631f 	cmp	x24, #0x18
    5314:	540000e9 	b.ls	5330 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5318:	d1006702 	sub	x2, x24, #0x19
    531c:	91006260 	add	x0, x19, #0x18
    5320:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5324:	52800001 	mov	w1, #0x0                   	// #0
    5328:	91002042 	add	x2, x2, #0x8
    532c:	97fff551 	bl	2870 <memset@plt>
    5330:	911882a0 	add	x0, x21, #0x620
    5334:	f94a1001 	ldr	x1, [x0, #5152]
    5338:	ab180021 	adds	x1, x1, x24
    533c:	54000642 	b.cs	5404 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5340:	f94a1402 	ldr	x2, [x0, #5160]
    5344:	f90a1001 	str	x1, [x0, #5152]
    5348:	eb02003f 	cmp	x1, x2
    534c:	54000049 	b.ls	5354 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5350:	f90a1401 	str	x1, [x0, #5160]
    5354:	911882a0 	add	x0, x21, #0x620
    5358:	1e630341 	ucvtf	d1, w26
    535c:	fd4a1c00 	ldr	d0, [x0, #5176]
    5360:	1e612800 	fadd	d0, d0, d1
    5364:	fd0a1c00 	str	d0, [x0, #5176]
    5368:	34000139 	cbz	w25, 538c <fwp_data.part.0.constprop.0+0xf8>
    536c:	911882b5 	add	x21, x21, #0x620
    5370:	910142d6 	add	x22, x22, #0x50
    5374:	fd4a12a0 	ldr	d0, [x21, #5152]
    5378:	6d5486c2 	ldp	d2, d1, [x22, #328]
    537c:	7e61d800 	ucvtf	d0, d0
    5380:	1e623800 	fsub	d0, d0, d2
    5384:	1e612010 	fcmpe	d0, d1
    5388:	540003ac 	b.gt	53fc <fwp_data.part.0.constprop.0+0x168>
    538c:	52800040 	mov	w0, #0x2                   	// #2
    5390:	29000277 	stp	w23, w0, [x19]
    5394:	aa1303e0 	mov	x0, x19
    5398:	f9400281 	ldr	x1, [x20]
    539c:	f9000661 	str	x1, [x19, #8]
    53a0:	f9400681 	ldr	x1, [x20, #8]
    53a4:	f9000a61 	str	x1, [x19, #16]
    53a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    53ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53b4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53bc:	d65f03c0 	ret
    53c0:	8b020063 	add	x3, x3, x2
    53c4:	f9400473 	ldr	x19, [x3, #8]
    53c8:	b4000113 	cbz	x19, 53e8 <fwp_data.part.0.constprop.0+0x154>
    53cc:	f9400860 	ldr	x0, [x3, #16]
    53d0:	cb130000 	sub	x0, x0, x19
    53d4:	eb00031f 	cmp	x24, x0
    53d8:	54000088 	b.hi	53e8 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53dc:	8b180260 	add	x0, x19, x24
    53e0:	f9000460 	str	x0, [x3, #8]
    53e4:	17ffffcb 	b	5310 <fwp_data.part.0.constprop.0+0x7c>
    53e8:	52800001 	mov	w1, #0x0                   	// #0
    53ec:	d2800300 	mov	x0, #0x18                  	// #24
    53f0:	97ffff48 	bl	5110 <fwp_heap_alloc>
    53f4:	aa0003f3 	mov	x19, x0
    53f8:	17ffffdc 	b	5368 <fwp_data.part.0.constprop.0+0xd4>
    53fc:	fd00aac0 	str	d0, [x22, #336]
    5400:	17ffffe3 	b	538c <fwp_data.part.0.constprop.0+0xf8>
    5404:	97fff75b 	bl	3170 <fwp_heap_oom>
    5408:	d503201f 	nop
    540c:	d503201f 	nop

0000000000005410 <fwp_p_ad_push>:
    5410:	f100001f 	cmp	x0, #0x0
    5414:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    5418:	54000eab 	b.lt	55ec <fwp_p_ad_push+0x1dc>  // b.tstop
    541c:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5420:	aa0003e4 	mov	x4, x0
    5424:	910003fd 	mov	x29, sp
    5428:	a9025bf5 	stp	x21, x22, [sp, #32]
    542c:	aa0003f5 	mov	x21, x0
    5430:	aa020000 	orr	x0, x0, x2
    5434:	a90363f7 	stp	x23, x24, [sp, #48]
    5438:	aa0203f7 	mov	x23, x2
    543c:	6d0627e8 	stp	d8, d9, [sp, #96]
    5440:	9e670029 	fmov	d9, x1
    5444:	9e670068 	fmov	d8, x3
    5448:	b6f80920 	tbz	x0, #63, 556c <fwp_p_ad_push+0x15c>
    544c:	a90153f3 	stp	x19, x20, [sp, #16]
    5450:	9360fc80 	asr	x0, x4, #32
    5454:	b6f800c4 	tbz	x4, #63, 546c <fwp_p_ad_push+0x5c>
    5458:	1e604109 	fmov	d9, d8
    545c:	2f00e408 	movi	d8, #0x0
    5460:	9360fc40 	asr	x0, x2, #32
    5464:	aa0203f5 	mov	x21, x2
    5468:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    546c:	97fff9b1 	bl	3b30 <fwp_tape_of>
    5470:	aa0003f3 	mov	x19, x0
    5474:	f9403000 	ldr	x0, [x0, #96]
    5478:	b5001240 	cbnz	x0, 56c0 <fwp_p_ad_push+0x2b0>
    547c:	f9400a76 	ldr	x22, [x19, #16]
    5480:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5484:	eb0002df 	cmp	x22, x0
    5488:	54000d8c 	b.gt	5638 <fwp_p_ad_push+0x228>
    548c:	eb3542df 	cmp	x22, w21, uxtw
    5490:	54000cad 	b.le	5624 <fwp_p_ad_push+0x214>
    5494:	b7f80077 	tbnz	x23, #63, 54a0 <fwp_p_ad_push+0x90>
    5498:	eb3742df 	cmp	x22, w23, uxtw
    549c:	54000c4d 	b.le	5624 <fwp_p_ad_push+0x214>
    54a0:	f9400678 	ldr	x24, [x19, #8]
    54a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54a8:	cb1802d8 	sub	x24, x22, x24
    54ac:	91000701 	add	x1, x24, #0x1
    54b0:	eb00003f 	cmp	x1, x0
    54b4:	54000c28 	b.hi	5638 <fwp_p_ad_push+0x228>  // b.pmore
    54b8:	a9418274 	ldp	x20, x0, [x19, #24]
    54bc:	a90573fb 	stp	x27, x28, [sp, #80]
    54c0:	eb14003f 	cmp	x1, x20
    54c4:	540006ad 	b.le	5598 <fwp_p_ad_push+0x188>
    54c8:	f100029f 	cmp	x20, #0x0
    54cc:	d2800803 	mov	x3, #0x40                  	// #64
    54d0:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54d4:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54d8:	a9046bf9 	stp	x25, x26, [sp, #64]
    54dc:	eb14003f 	cmp	x1, x20
    54e0:	5400008d 	b.le	54f0 <fwp_p_ad_push+0xe0>
    54e4:	eb02029f 	cmp	x20, x2
    54e8:	5400054d 	b.le	5590 <fwp_p_ad_push+0x180>
    54ec:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    54f0:	d37df299 	lsl	x25, x20, #3
    54f4:	52800022 	mov	w2, #0x1                   	// #1
    54f8:	aa1903e1 	mov	x1, x25
    54fc:	97fffbd6 	bl	4454 <ad_raw_realloc>
    5500:	aa0003e1 	mov	x1, x0
    5504:	b4000a40 	cbz	x0, 564c <fwp_p_ad_push+0x23c>
    5508:	f9400e63 	ldr	x3, [x19, #24]
    550c:	f9001261 	str	x1, [x19, #32]
    5510:	f9401a60 	ldr	x0, [x19, #48]
    5514:	52800042 	mov	w2, #0x2                   	// #2
    5518:	8b030821 	add	x1, x1, x3, lsl #2
    551c:	f9001661 	str	x1, [x19, #40]
    5520:	d37cee81 	lsl	x1, x20, #4
    5524:	97fffbcc 	bl	4454 <ad_raw_realloc>
    5528:	aa0003e2 	mov	x2, x0
    552c:	b4000900 	cbz	x0, 564c <fwp_p_ad_push+0x23c>
    5530:	f9400e61 	ldr	x1, [x19, #24]
    5534:	d37df31b 	lsl	x27, x24, #3
    5538:	d37ef69a 	lsl	x26, x20, #2
    553c:	d37ef71c 	lsl	x28, x24, #2
    5540:	8b190003 	add	x3, x0, x25
    5544:	8b010c01 	add	x1, x0, x1, lsl #3
    5548:	a9030660 	stp	x0, x1, [x19, #48]
    554c:	b5000558 	cbnz	x24, 55f4 <fwp_p_ad_push+0x1e4>
    5550:	f9001e63 	str	x3, [x19, #56]
    5554:	f9401260 	ldr	x0, [x19, #32]
    5558:	8b1a0001 	add	x1, x0, x26
    555c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5560:	f9000e74 	str	x20, [x19, #24]
    5564:	f9001661 	str	x1, [x19, #40]
    5568:	14000010 	b	55a8 <fwp_p_ad_push+0x198>
    556c:	9360fc40 	asr	x0, x2, #32
    5570:	a90153f3 	stp	x19, x20, [sp, #16]
    5574:	eb84801f 	cmp	x0, x4, asr #32
    5578:	54fff7a0 	b.eq	546c <fwp_p_ad_push+0x5c>  // b.none
    557c:	90000020 	adrp	x0, 9000 <__divti3+0x100>
    5580:	912ca000 	add	x0, x0, #0xb28
    5584:	a9046bf9 	stp	x25, x26, [sp, #64]
    5588:	a90573fb 	stp	x27, x28, [sp, #80]
    558c:	97fff89d 	bl	3800 <fwp_trap>
    5590:	d37ffa94 	lsl	x20, x20, #1
    5594:	17ffffd2 	b	54dc <fwp_p_ad_push+0xcc>
    5598:	a9428a61 	ldp	x1, x2, [x19, #40]
    559c:	d37ef71c 	lsl	x28, x24, #2
    55a0:	f9401e63 	ldr	x3, [x19, #56]
    55a4:	d37df31b 	lsl	x27, x24, #3
    55a8:	b83c6815 	str	w21, [x0, x28]
    55ac:	f10002ff 	cmp	x23, #0x0
    55b0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    55b4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55b8:	fc3b6849 	str	d9, [x2, x27]
    55bc:	aa1602a0 	orr	x0, x21, x22
    55c0:	b83c6837 	str	w23, [x1, x28]
    55c4:	910006d6 	add	x22, x22, #0x1
    55c8:	a94363f7 	ldp	x23, x24, [sp, #48]
    55cc:	fc3b6868 	str	d8, [x3, x27]
    55d0:	a94573fb 	ldp	x27, x28, [sp, #80]
    55d4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55d8:	f9000a76 	str	x22, [x19, #16]
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    55e8:	d65f03c0 	ret
    55ec:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55f0:	d65f03c0 	ret
    55f4:	aa0303e0 	mov	x0, x3
    55f8:	aa1b03e2 	mov	x2, x27
    55fc:	97fff445 	bl	2710 <memmove@plt>
    5600:	a9420660 	ldp	x0, x1, [x19, #32]
    5604:	aa1c03e2 	mov	x2, x28
    5608:	f9401a63 	ldr	x3, [x19, #48]
    560c:	8b190063 	add	x3, x3, x25
    5610:	f9001e63 	str	x3, [x19, #56]
    5614:	8b1a0000 	add	x0, x0, x26
    5618:	97fff43e 	bl	2710 <memmove@plt>
    561c:	a9430e62 	ldp	x2, x3, [x19, #48]
    5620:	17ffffcd 	b	5554 <fwp_p_ad_push+0x144>
    5624:	90000020 	adrp	x0, 9000 <__divti3+0x100>
    5628:	912f0000 	add	x0, x0, #0xbc0
    562c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5630:	a90573fb 	stp	x27, x28, [sp, #80]
    5634:	97fff873 	bl	3800 <fwp_trap>
    5638:	90000020 	adrp	x0, 9000 <__divti3+0x100>
    563c:	912e8000 	add	x0, x0, #0xba0
    5640:	a9046bf9 	stp	x25, x26, [sp, #64]
    5644:	a90573fb 	stp	x27, x28, [sp, #80]
    5648:	97fff86e 	bl	3800 <fwp_trap>
    564c:	aa1303e0 	mov	x0, x19
    5650:	97fff671 	bl	3014 <fwp_tape_unlink_scope>
    5654:	f9401260 	ldr	x0, [x19, #32]
    5658:	b4000040 	cbz	x0, 5660 <fwp_p_ad_push+0x250>
    565c:	97fffb49 	bl	4380 <ad_raw_free.part.0>
    5660:	f9401a60 	ldr	x0, [x19, #48]
    5664:	b4000040 	cbz	x0, 566c <fwp_p_ad_push+0x25c>
    5668:	97fffb46 	bl	4380 <ad_raw_free.part.0>
    566c:	f9402260 	ldr	x0, [x19, #64]
    5670:	b4000040 	cbz	x0, 5678 <fwp_p_ad_push+0x268>
    5674:	97fffb43 	bl	4380 <ad_raw_free.part.0>
    5678:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    567c:	f947e821 	ldr	x1, [x1, #4048]
    5680:	f9000e7f 	str	xzr, [x19, #24]
    5684:	4f000400 	movi	v0.4s, #0x0
    5688:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    568c:	d2800262 	mov	x2, #0x13                  	// #19
    5690:	f9400023 	ldr	x3, [x1]
    5694:	b900067f 	str	wzr, [x19, #4]
    5698:	d2800021 	mov	x1, #0x1                   	// #1
    569c:	90000020 	adrp	x0, 9000 <__divti3+0x100>
    56a0:	9118a000 	add	x0, x0, #0x628
    56a4:	3c808260 	stur	q0, [x19, #8]
    56a8:	ad010260 	stp	q0, q0, [x19, #32]
    56ac:	97fff4bd 	bl	29a0 <fwrite@plt>
    56b0:	d2800000 	mov	x0, #0x0                   	// #0
    56b4:	97fff4c7 	bl	29d0 <fflush@plt>
    56b8:	52800cc0 	mov	w0, #0x66                  	// #102
    56bc:	97fff4d5 	bl	2a10 <_Exit@plt>
    56c0:	90000020 	adrp	x0, 9000 <__divti3+0x100>
    56c4:	912dc000 	add	x0, x0, #0xb70
    56c8:	a9046bf9 	stp	x25, x26, [sp, #64]
    56cc:	a90573fb 	stp	x27, x28, [sp, #80]
    56d0:	97fff84c 	bl	3800 <fwp_trap>

00000000000056d4 <w120>:
    56d4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    56d8:	9e660003 	fmov	x3, d0
    56dc:	aa0003e2 	mov	x2, x0
    56e0:	910003fd 	mov	x29, sp
    56e4:	6d0327e8 	stp	d8, d9, [sp, #48]
    56e8:	1e604028 	fmov	d8, d1
    56ec:	1e600809 	fmul	d9, d0, d0
    56f0:	fd0023ea 	str	d10, [sp, #64]
    56f4:	1e60400a 	fmov	d10, d0
    56f8:	a90153f3 	stp	x19, x20, [sp, #16]
    56fc:	aa0003f3 	mov	x19, x0
    5700:	aa0103f4 	mov	x20, x1
    5704:	aa0303e1 	mov	x1, x3
    5708:	a9025bf5 	stp	x21, x22, [sp, #32]
    570c:	97ffff41 	bl	5410 <fwp_p_ad_push>
    5710:	1e693908 	fsub	d8, d8, d9
    5714:	aa1403e2 	mov	x2, x20
    5718:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    571c:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5720:	9e660116 	fmov	x22, d8
    5724:	97ffff3b 	bl	5410 <fwp_p_ad_push>
    5728:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    572c:	aa0003e1 	mov	x1, x0
    5730:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5734:	aa1303e0 	mov	x0, x19
    5738:	1e6a3929 	fsub	d9, d9, d10
    573c:	aa0103f3 	mov	x19, x1
    5740:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5744:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5748:	9e660135 	fmov	x21, d9
    574c:	97ffff31 	bl	5410 <fwp_p_ad_push>
    5750:	1e680908 	fmul	d8, d8, d8
    5754:	aa0003f4 	mov	x20, x0
    5758:	aa1603e3 	mov	x3, x22
    575c:	aa1603e1 	mov	x1, x22
    5760:	aa1303e2 	mov	x2, x19
    5764:	aa1303e0 	mov	x0, x19
    5768:	97ffff2a 	bl	5410 <fwp_p_ad_push>
    576c:	aa0003e2 	mov	x2, x0
    5770:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5774:	9e670020 	fmov	d0, x1
    5778:	9e660101 	fmov	x1, d8
    577c:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5780:	1e600908 	fmul	d8, d8, d0
    5784:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5788:	97ffff22 	bl	5410 <fwp_p_ad_push>
    578c:	1e690929 	fmul	d9, d9, d9
    5790:	aa0003f3 	mov	x19, x0
    5794:	aa1503e3 	mov	x3, x21
    5798:	aa1503e1 	mov	x1, x21
    579c:	aa1403e2 	mov	x2, x20
    57a0:	aa1403e0 	mov	x0, x20
    57a4:	97ffff1b 	bl	5410 <fwp_p_ad_push>
    57a8:	1e692908 	fadd	d8, d8, d9
    57ac:	aa1303e2 	mov	x2, x19
    57b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    57b4:	aa0303e1 	mov	x1, x3
    57b8:	97ffff16 	bl	5410 <fwp_p_ad_push>
    57bc:	aa0003e1 	mov	x1, x0
    57c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c4:	9e660100 	fmov	x0, d8
    57c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57cc:	6d4327e8 	ldp	d8, d9, [sp, #48]
    57d0:	fd4023ea 	ldr	d10, [sp, #64]
    57d4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    57d8:	d65f03c0 	ret
    57dc:	d503201f 	nop

00000000000057e0 <fwp_rc_share>:
    57e0:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    57e4:	91188042 	add	x2, x2, #0x620
    57e8:	f949d843 	ldr	x3, [x2, #5040]
    57ec:	f949ec41 	ldr	x1, [x2, #5080]
    57f0:	cb030000 	sub	x0, x0, x3
    57f4:	eb01401f 	cmp	x0, x1, lsl #16
    57f8:	540002c2 	b.cs	5850 <fwp_rc_share+0x70>  // b.hs, b.nlast
    57fc:	d350fc01 	lsr	x1, x0, #16
    5800:	f949fc44 	ldr	x4, [x2, #5112]
    5804:	8b010821 	add	x1, x1, x1, lsl #2
    5808:	d37df021 	lsl	x1, x1, #3
    580c:	8b010083 	add	x3, x4, x1
    5810:	f9401062 	ldr	x2, [x3, #32]
    5814:	b40001e2 	cbz	x2, 5850 <fwp_rc_share+0x70>
    5818:	38616881 	ldrb	w1, [x4, x1]
    581c:	7100083f 	cmp	w1, #0x2
    5820:	540001a0 	b.eq	5854 <fwp_rc_share+0x74>  // b.none
    5824:	7100043f 	cmp	w1, #0x1
    5828:	54000141 	b.ne	5850 <fwp_rc_share+0x70>  // b.any
    582c:	29430464 	ldp	w4, w1, [x3, #24]
    5830:	92403c00 	and	x0, x0, #0xffff
    5834:	9b047c00 	mul	x0, x0, x4
    5838:	d360fc00 	lsr	x0, x0, #32
    583c:	eb01001f 	cmp	x0, x1
    5840:	54000082 	b.cs	5850 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5844:	8b000042 	add	x2, x2, x0
    5848:	39400040 	ldrb	w0, [x2]
    584c:	350000a0 	cbnz	w0, 5860 <fwp_rc_share+0x80>
    5850:	d65f03c0 	ret
    5854:	72003c1f 	tst	w0, #0xffff
    5858:	54ffff80 	b.eq	5848 <fwp_rc_share+0x68>  // b.none
    585c:	d65f03c0 	ret
    5860:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5864:	90000020 	adrp	x0, 9000 <__divti3+0x100>
    5868:	912f8000 	add	x0, x0, #0xbe0
    586c:	910003fd 	mov	x29, sp
    5870:	97fff7e4 	bl	3800 <fwp_trap>

0000000000005874 <fwp_rc_free_arr>:
    5874:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5878:	91188063 	add	x3, x3, #0x620
    587c:	f949d861 	ldr	x1, [x3, #5040]
    5880:	f949ec62 	ldr	x2, [x3, #5080]
    5884:	cb010001 	sub	x1, x0, x1
    5888:	eb02403f 	cmp	x1, x2, lsl #16
    588c:	54000342 	b.cs	58f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5890:	d350fc22 	lsr	x2, x1, #16
    5894:	f949fc65 	ldr	x5, [x3, #5112]
    5898:	8b020842 	add	x2, x2, x2, lsl #2
    589c:	d37df042 	lsl	x2, x2, #3
    58a0:	8b0200a4 	add	x4, x5, x2
    58a4:	f9401083 	ldr	x3, [x4, #32]
    58a8:	b4000263 	cbz	x3, 58f4 <fwp_rc_free_arr+0x80>
    58ac:	386268a2 	ldrb	w2, [x5, x2]
    58b0:	7100085f 	cmp	w2, #0x2
    58b4:	540001c0 	b.eq	58ec <fwp_rc_free_arr+0x78>  // b.none
    58b8:	7100045f 	cmp	w2, #0x1
    58bc:	540001c1 	b.ne	58f4 <fwp_rc_free_arr+0x80>  // b.any
    58c0:	29430885 	ldp	w5, w2, [x4, #24]
    58c4:	92403c21 	and	x1, x1, #0xffff
    58c8:	9b057c21 	mul	x1, x1, x5
    58cc:	d360fc21 	lsr	x1, x1, #32
    58d0:	eb02003f 	cmp	x1, x2
    58d4:	54000102 	b.cs	58f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    58d8:	8b010063 	add	x3, x3, x1
    58dc:	39400061 	ldrb	w1, [x3]
    58e0:	7100043f 	cmp	w1, #0x1
    58e4:	54000081 	b.ne	58f4 <fwp_rc_free_arr+0x80>  // b.any
    58e8:	17fffcea 	b	4c90 <fwp_mem_free>
    58ec:	72003c3f 	tst	w1, #0xffff
    58f0:	54ffff60 	b.eq	58dc <fwp_rc_free_arr+0x68>  // b.none
    58f4:	d65f03c0 	ret
    58f8:	d503201f 	nop
    58fc:	d503201f 	nop

0000000000005900 <fwp_rc_dup>:
    5900:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    5904:	91188042 	add	x2, x2, #0x620
    5908:	f949d841 	ldr	x1, [x2, #5040]
    590c:	f949ec43 	ldr	x3, [x2, #5080]
    5910:	cb010001 	sub	x1, x0, x1
    5914:	eb03403f 	cmp	x1, x3, lsl #16
    5918:	540003c2 	b.cs	5990 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    591c:	d350fc20 	lsr	x0, x1, #16
    5920:	f949fc44 	ldr	x4, [x2, #5112]
    5924:	8b000800 	add	x0, x0, x0, lsl #2
    5928:	d37df002 	lsl	x2, x0, #3
    592c:	8b020083 	add	x3, x4, x2
    5930:	f9401060 	ldr	x0, [x3, #32]
    5934:	b40002e0 	cbz	x0, 5990 <fwp_rc_dup+0x90>
    5938:	38626882 	ldrb	w2, [x4, x2]
    593c:	7100085f 	cmp	w2, #0x2
    5940:	540002a0 	b.eq	5994 <fwp_rc_dup+0x94>  // b.none
    5944:	7100045f 	cmp	w2, #0x1
    5948:	54000241 	b.ne	5990 <fwp_rc_dup+0x90>  // b.any
    594c:	29430864 	ldp	w4, w2, [x3, #24]
    5950:	92403c21 	and	x1, x1, #0xffff
    5954:	9b047c21 	mul	x1, x1, x4
    5958:	d360fc21 	lsr	x1, x1, #32
    595c:	eb02003f 	cmp	x1, x2
    5960:	54000182 	b.cs	5990 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5964:	8b010000 	add	x0, x0, x1
    5968:	39400001 	ldrb	w1, [x0]
    596c:	34000121 	cbz	w1, 5990 <fwp_rc_dup+0x90>
    5970:	f00000c2 	adrp	x2, 20000 <__data_start>
    5974:	91014042 	add	x2, x2, #0x50
    5978:	b9413043 	ldr	w3, [x2, #304]
    597c:	35000123 	cbnz	w3, 59a0 <fwp_rc_dup+0xa0>
    5980:	7103f43f 	cmp	w1, #0xfd
    5984:	54000168 	b.hi	59b0 <fwp_rc_dup+0xb0>  // b.pmore
    5988:	11000421 	add	w1, w1, #0x1
    598c:	39000001 	strb	w1, [x0]
    5990:	d65f03c0 	ret
    5994:	72003c3f 	tst	w1, #0xffff
    5998:	54fffe80 	b.eq	5968 <fwp_rc_dup+0x68>  // b.none
    599c:	d65f03c0 	ret
    59a0:	f940ac43 	ldr	x3, [x2, #344]
    59a4:	91000463 	add	x3, x3, #0x1
    59a8:	f900ac43 	str	x3, [x2, #344]
    59ac:	17fffff5 	b	5980 <fwp_rc_dup+0x80>
    59b0:	17fffbd1 	b	48f4 <fwp_rc_wide_dup>

00000000000059b4 <fwp_owned_entry173>:
    59b4:	d10103ff 	sub	sp, sp, #0x40
    59b8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    59bc:	f947f442 	ldr	x2, [x2, #4072]
    59c0:	a9027bfd 	stp	x29, x30, [sp, #32]
    59c4:	910083fd 	add	x29, sp, #0x20
    59c8:	a90353f3 	stp	x19, x20, [sp, #48]
    59cc:	f9400043 	ldr	x3, [x2]
    59d0:	f9000fe3 	str	x3, [sp, #24]
    59d4:	d2800003 	mov	x3, #0x0                   	// #0
    59d8:	a9400c01 	ldp	x1, x3, [x0]
    59dc:	f9400802 	ldr	x2, [x0, #16]
    59e0:	ab020022 	adds	x2, x1, x2
    59e4:	540006e6 	b.vs	5ac0 <fwp_owned_entry173+0x10c>
    59e8:	910023e1 	add	x1, sp, #0x8
    59ec:	52800000 	mov	w0, #0x0                   	// #0
    59f0:	a9008be3 	stp	x3, x2, [sp, #8]
    59f4:	97fffe28 	bl	5294 <fwp_data.part.0.constprop.0>
    59f8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    59fc:	91188063 	add	x3, x3, #0x620
    5a00:	aa0003f3 	mov	x19, x0
    5a04:	f949d861 	ldr	x1, [x3, #5040]
    5a08:	f949ec60 	ldr	x0, [x3, #5080]
    5a0c:	cb010261 	sub	x1, x19, x1
    5a10:	eb00403f 	cmp	x1, x0, lsl #16
    5a14:	54000322 	b.cs	5a78 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5a18:	d350fc22 	lsr	x2, x1, #16
    5a1c:	f949fc63 	ldr	x3, [x3, #5112]
    5a20:	8b020842 	add	x2, x2, x2, lsl #2
    5a24:	d37df042 	lsl	x2, x2, #3
    5a28:	8b020060 	add	x0, x3, x2
    5a2c:	f9401014 	ldr	x20, [x0, #32]
    5a30:	b4000254 	cbz	x20, 5a78 <fwp_owned_entry173+0xc4>
    5a34:	38626862 	ldrb	w2, [x3, x2]
    5a38:	7100085f 	cmp	w2, #0x2
    5a3c:	54000360 	b.eq	5aa8 <fwp_owned_entry173+0xf4>  // b.none
    5a40:	7100045f 	cmp	w2, #0x1
    5a44:	540001a1 	b.ne	5a78 <fwp_owned_entry173+0xc4>  // b.any
    5a48:	29430002 	ldp	w2, w0, [x0, #24]
    5a4c:	92403c21 	and	x1, x1, #0xffff
    5a50:	9b027c21 	mul	x1, x1, x2
    5a54:	d360fc21 	lsr	x1, x1, #32
    5a58:	eb00003f 	cmp	x1, x0
    5a5c:	540000e2 	b.cs	5a78 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5a60:	8b010294 	add	x20, x20, x1
    5a64:	39400280 	ldrb	w0, [x20]
    5a68:	7103fc1f 	cmp	w0, #0xff
    5a6c:	54000240 	b.eq	5ab4 <fwp_owned_entry173+0x100>  // b.none
    5a70:	52800020 	mov	w0, #0x1                   	// #1
    5a74:	39000280 	strb	w0, [x20]
    5a78:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5a7c:	f947f400 	ldr	x0, [x0, #4072]
    5a80:	f9400fe2 	ldr	x2, [sp, #24]
    5a84:	f9400001 	ldr	x1, [x0]
    5a88:	eb010042 	subs	x2, x2, x1
    5a8c:	d2800001 	mov	x1, #0x0                   	// #0
    5a90:	540001a1 	b.ne	5ac4 <fwp_owned_entry173+0x110>  // b.any
    5a94:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a98:	aa1303e0 	mov	x0, x19
    5a9c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5aa0:	910103ff 	add	sp, sp, #0x40
    5aa4:	d65f03c0 	ret
    5aa8:	72003c3f 	tst	w1, #0xffff
    5aac:	54fffe61 	b.ne	5a78 <fwp_owned_entry173+0xc4>  // b.any
    5ab0:	17ffffed 	b	5a64 <fwp_owned_entry173+0xb0>
    5ab4:	aa1403e0 	mov	x0, x20
    5ab8:	97fffbd6 	bl	4a10 <fwp_rc_forget_slot>
    5abc:	17ffffed 	b	5a70 <fwp_owned_entry173+0xbc>
    5ac0:	97fff3f0 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5ac4:	97fff377 	bl	28a0 <__stack_chk_fail@plt>
    5ac8:	d503201f 	nop
    5acc:	d503201f 	nop

0000000000005ad0 <e173>:
    5ad0:	d10103ff 	sub	sp, sp, #0x40
    5ad4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5ad8:	f947f442 	ldr	x2, [x2, #4072]
    5adc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ae0:	910083fd 	add	x29, sp, #0x20
    5ae4:	a90353f3 	stp	x19, x20, [sp, #48]
    5ae8:	f9400043 	ldr	x3, [x2]
    5aec:	f9000fe3 	str	x3, [sp, #24]
    5af0:	d2800003 	mov	x3, #0x0                   	// #0
    5af4:	a9400c01 	ldp	x1, x3, [x0]
    5af8:	f9400802 	ldr	x2, [x0, #16]
    5afc:	ab020022 	adds	x2, x1, x2
    5b00:	54000726 	b.vs	5be4 <e173+0x114>
    5b04:	910023e1 	add	x1, sp, #0x8
    5b08:	52800000 	mov	w0, #0x0                   	// #0
    5b0c:	a9008be3 	stp	x3, x2, [sp, #8]
    5b10:	97fffde1 	bl	5294 <fwp_data.part.0.constprop.0>
    5b14:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5b18:	91188063 	add	x3, x3, #0x620
    5b1c:	aa0003f3 	mov	x19, x0
    5b20:	f949d861 	ldr	x1, [x3, #5040]
    5b24:	f949ec60 	ldr	x0, [x3, #5080]
    5b28:	cb010261 	sub	x1, x19, x1
    5b2c:	eb00403f 	cmp	x1, x0, lsl #16
    5b30:	54000322 	b.cs	5b94 <e173+0xc4>  // b.hs, b.nlast
    5b34:	d350fc22 	lsr	x2, x1, #16
    5b38:	f949fc63 	ldr	x3, [x3, #5112]
    5b3c:	8b020842 	add	x2, x2, x2, lsl #2
    5b40:	d37df042 	lsl	x2, x2, #3
    5b44:	8b020060 	add	x0, x3, x2
    5b48:	f9401014 	ldr	x20, [x0, #32]
    5b4c:	b4000254 	cbz	x20, 5b94 <e173+0xc4>
    5b50:	38626862 	ldrb	w2, [x3, x2]
    5b54:	7100085f 	cmp	w2, #0x2
    5b58:	540003a0 	b.eq	5bcc <e173+0xfc>  // b.none
    5b5c:	7100045f 	cmp	w2, #0x1
    5b60:	540001a1 	b.ne	5b94 <e173+0xc4>  // b.any
    5b64:	29430002 	ldp	w2, w0, [x0, #24]
    5b68:	92403c21 	and	x1, x1, #0xffff
    5b6c:	9b027c21 	mul	x1, x1, x2
    5b70:	d360fc21 	lsr	x1, x1, #32
    5b74:	eb00003f 	cmp	x1, x0
    5b78:	540000e2 	b.cs	5b94 <e173+0xc4>  // b.hs, b.nlast
    5b7c:	8b010294 	add	x20, x20, x1
    5b80:	39400280 	ldrb	w0, [x20]
    5b84:	7103fc1f 	cmp	w0, #0xff
    5b88:	54000280 	b.eq	5bd8 <e173+0x108>  // b.none
    5b8c:	52800020 	mov	w0, #0x1                   	// #1
    5b90:	39000280 	strb	w0, [x20]
    5b94:	aa1303e0 	mov	x0, x19
    5b98:	97ffff12 	bl	57e0 <fwp_rc_share>
    5b9c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5ba0:	f947f400 	ldr	x0, [x0, #4072]
    5ba4:	f9400fe2 	ldr	x2, [sp, #24]
    5ba8:	f9400001 	ldr	x1, [x0]
    5bac:	eb010042 	subs	x2, x2, x1
    5bb0:	d2800001 	mov	x1, #0x0                   	// #0
    5bb4:	540001a1 	b.ne	5be8 <e173+0x118>  // b.any
    5bb8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5bbc:	aa1303e0 	mov	x0, x19
    5bc0:	a94353f3 	ldp	x19, x20, [sp, #48]
    5bc4:	910103ff 	add	sp, sp, #0x40
    5bc8:	d65f03c0 	ret
    5bcc:	72003c3f 	tst	w1, #0xffff
    5bd0:	54fffe21 	b.ne	5b94 <e173+0xc4>  // b.any
    5bd4:	17ffffeb 	b	5b80 <e173+0xb0>
    5bd8:	aa1403e0 	mov	x0, x20
    5bdc:	97fffb8d 	bl	4a10 <fwp_rc_forget_slot>
    5be0:	17ffffeb 	b	5b8c <e173+0xbc>
    5be4:	97fff3a7 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5be8:	97fff32e 	bl	28a0 <__stack_chk_fail@plt>
    5bec:	d503201f 	nop

0000000000005bf0 <fwp_drop1>:
    5bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5bf4:	910003fd 	mov	x29, sp
    5bf8:	a90153f3 	stp	x19, x20, [sp, #16]
    5bfc:	f90013f5 	str	x21, [sp, #32]
    5c00:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    5c04:	911882b4 	add	x20, x21, #0x620
    5c08:	f949da81 	ldr	x1, [x20, #5040]
    5c0c:	f949ee82 	ldr	x2, [x20, #5080]
    5c10:	cb010001 	sub	x1, x0, x1
    5c14:	eb02403f 	cmp	x1, x2, lsl #16
    5c18:	54000382 	b.cs	5c88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c1c:	d350fc22 	lsr	x2, x1, #16
    5c20:	f949fe84 	ldr	x4, [x20, #5112]
    5c24:	8b020842 	add	x2, x2, x2, lsl #2
    5c28:	d37df042 	lsl	x2, x2, #3
    5c2c:	8b020083 	add	x3, x4, x2
    5c30:	f9401073 	ldr	x19, [x3, #32]
    5c34:	b40002b3 	cbz	x19, 5c88 <fwp_drop1+0x98>
    5c38:	38626882 	ldrb	w2, [x4, x2]
    5c3c:	7100085f 	cmp	w2, #0x2
    5c40:	540002c0 	b.eq	5c98 <fwp_drop1+0xa8>  // b.none
    5c44:	7100045f 	cmp	w2, #0x1
    5c48:	54000201 	b.ne	5c88 <fwp_drop1+0x98>  // b.any
    5c4c:	29430864 	ldp	w4, w2, [x3, #24]
    5c50:	92403c21 	and	x1, x1, #0xffff
    5c54:	9b047c21 	mul	x1, x1, x4
    5c58:	d360fc21 	lsr	x1, x1, #32
    5c5c:	eb02003f 	cmp	x1, x2
    5c60:	54000142 	b.cs	5c88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c64:	8b010273 	add	x19, x19, x1
    5c68:	39400261 	ldrb	w1, [x19]
    5c6c:	340000e1 	cbz	w1, 5c88 <fwp_drop1+0x98>
    5c70:	7100043f 	cmp	w1, #0x1
    5c74:	540001e0 	b.eq	5cb0 <fwp_drop1+0xc0>  // b.none
    5c78:	7103fc3f 	cmp	w1, #0xff
    5c7c:	540002e0 	b.eq	5cd8 <fwp_drop1+0xe8>  // b.none
    5c80:	51000421 	sub	w1, w1, #0x1
    5c84:	39000261 	strb	w1, [x19]
    5c88:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c8c:	f94013f5 	ldr	x21, [sp, #32]
    5c90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c94:	d65f03c0 	ret
    5c98:	72003c3f 	tst	w1, #0xffff
    5c9c:	54fffe60 	b.eq	5c68 <fwp_drop1+0x78>  // b.none
    5ca0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ca4:	f94013f5 	ldr	x21, [sp, #32]
    5ca8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cac:	d65f03c0 	ret
    5cb0:	f9400813 	ldr	x19, [x0, #16]
    5cb4:	97fffef0 	bl	5874 <fwp_rc_free_arr>
    5cb8:	911882a0 	add	x0, x21, #0x620
    5cbc:	f949d801 	ldr	x1, [x0, #5040]
    5cc0:	f949ec00 	ldr	x0, [x0, #5080]
    5cc4:	cb010261 	sub	x1, x19, x1
    5cc8:	eb00403f 	cmp	x1, x0, lsl #16
    5ccc:	54fffde2 	b.cs	5c88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cd0:	aa1303e0 	mov	x0, x19
    5cd4:	17ffffd2 	b	5c1c <fwp_drop1+0x2c>
    5cd8:	ca534660 	eor	x0, x19, x19, lsr #17
    5cdc:	911882b5 	add	x21, x21, #0x620
    5ce0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ce4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5ce8:	f94a2400 	ldr	x0, [x0, #5192]
    5cec:	b5000080 	cbnz	x0, 5cfc <fwp_drop1+0x10c>
    5cf0:	14000010 	b	5d30 <fwp_drop1+0x140>
    5cf4:	f9400800 	ldr	x0, [x0, #16]
    5cf8:	b40001c0 	cbz	x0, 5d30 <fwp_drop1+0x140>
    5cfc:	f9400001 	ldr	x1, [x0]
    5d00:	eb13003f 	cmp	x1, x19
    5d04:	54ffff81 	b.ne	5cf4 <fwp_drop1+0x104>  // b.any
    5d08:	f9400401 	ldr	x1, [x0, #8]
    5d0c:	d1000421 	sub	x1, x1, #0x1
    5d10:	f9000401 	str	x1, [x0, #8]
    5d14:	f103f83f 	cmp	x1, #0xfe
    5d18:	54fffb81 	b.ne	5c88 <fwp_drop1+0x98>  // b.any
    5d1c:	aa1303e0 	mov	x0, x19
    5d20:	97fffb3c 	bl	4a10 <fwp_rc_forget_slot>
    5d24:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d28:	39000260 	strb	w0, [x19]
    5d2c:	17ffffd7 	b	5c88 <fwp_drop1+0x98>
    5d30:	90000020 	adrp	x0, 9000 <__divti3+0x100>
    5d34:	912b8000 	add	x0, x0, #0xae0
    5d38:	97fff6b2 	bl	3800 <fwp_trap>
    5d3c:	d503201f 	nop

0000000000005d40 <fwp_drop0>:
    5d40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d44:	910003fd 	mov	x29, sp
    5d48:	a90153f3 	stp	x19, x20, [sp, #16]
    5d4c:	f90013f5 	str	x21, [sp, #32]
    5d50:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    5d54:	911882b4 	add	x20, x21, #0x620
    5d58:	f949da81 	ldr	x1, [x20, #5040]
    5d5c:	f949ee82 	ldr	x2, [x20, #5080]
    5d60:	cb010001 	sub	x1, x0, x1
    5d64:	eb02403f 	cmp	x1, x2, lsl #16
    5d68:	54000382 	b.cs	5dd8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d6c:	d350fc22 	lsr	x2, x1, #16
    5d70:	f949fe84 	ldr	x4, [x20, #5112]
    5d74:	8b020842 	add	x2, x2, x2, lsl #2
    5d78:	d37df042 	lsl	x2, x2, #3
    5d7c:	8b020083 	add	x3, x4, x2
    5d80:	f9401073 	ldr	x19, [x3, #32]
    5d84:	b40002b3 	cbz	x19, 5dd8 <fwp_drop0+0x98>
    5d88:	38626882 	ldrb	w2, [x4, x2]
    5d8c:	7100085f 	cmp	w2, #0x2
    5d90:	540002c0 	b.eq	5de8 <fwp_drop0+0xa8>  // b.none
    5d94:	7100045f 	cmp	w2, #0x1
    5d98:	54000201 	b.ne	5dd8 <fwp_drop0+0x98>  // b.any
    5d9c:	29430864 	ldp	w4, w2, [x3, #24]
    5da0:	92403c21 	and	x1, x1, #0xffff
    5da4:	9b047c21 	mul	x1, x1, x4
    5da8:	d360fc21 	lsr	x1, x1, #32
    5dac:	eb02003f 	cmp	x1, x2
    5db0:	54000142 	b.cs	5dd8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5db4:	8b010273 	add	x19, x19, x1
    5db8:	39400261 	ldrb	w1, [x19]
    5dbc:	340000e1 	cbz	w1, 5dd8 <fwp_drop0+0x98>
    5dc0:	7100043f 	cmp	w1, #0x1
    5dc4:	540001e0 	b.eq	5e00 <fwp_drop0+0xc0>  // b.none
    5dc8:	7103fc3f 	cmp	w1, #0xff
    5dcc:	540002e0 	b.eq	5e28 <fwp_drop0+0xe8>  // b.none
    5dd0:	51000421 	sub	w1, w1, #0x1
    5dd4:	39000261 	strb	w1, [x19]
    5dd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ddc:	f94013f5 	ldr	x21, [sp, #32]
    5de0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5de4:	d65f03c0 	ret
    5de8:	72003c3f 	tst	w1, #0xffff
    5dec:	54fffe60 	b.eq	5db8 <fwp_drop0+0x78>  // b.none
    5df0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5df4:	f94013f5 	ldr	x21, [sp, #32]
    5df8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5dfc:	d65f03c0 	ret
    5e00:	f9400813 	ldr	x19, [x0, #16]
    5e04:	97fffe9c 	bl	5874 <fwp_rc_free_arr>
    5e08:	911882a0 	add	x0, x21, #0x620
    5e0c:	f949d801 	ldr	x1, [x0, #5040]
    5e10:	f949ec00 	ldr	x0, [x0, #5080]
    5e14:	cb010261 	sub	x1, x19, x1
    5e18:	eb00403f 	cmp	x1, x0, lsl #16
    5e1c:	54fffde2 	b.cs	5dd8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e20:	aa1303e0 	mov	x0, x19
    5e24:	17ffffd2 	b	5d6c <fwp_drop0+0x2c>
    5e28:	ca534660 	eor	x0, x19, x19, lsr #17
    5e2c:	911882b5 	add	x21, x21, #0x620
    5e30:	ca402400 	eor	x0, x0, x0, lsr #9
    5e34:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5e38:	f94a2400 	ldr	x0, [x0, #5192]
    5e3c:	b5000080 	cbnz	x0, 5e4c <fwp_drop0+0x10c>
    5e40:	14000010 	b	5e80 <fwp_drop0+0x140>
    5e44:	f9400800 	ldr	x0, [x0, #16]
    5e48:	b40001c0 	cbz	x0, 5e80 <fwp_drop0+0x140>
    5e4c:	f9400001 	ldr	x1, [x0]
    5e50:	eb13003f 	cmp	x1, x19
    5e54:	54ffff81 	b.ne	5e44 <fwp_drop0+0x104>  // b.any
    5e58:	f9400401 	ldr	x1, [x0, #8]
    5e5c:	d1000421 	sub	x1, x1, #0x1
    5e60:	f9000401 	str	x1, [x0, #8]
    5e64:	f103f83f 	cmp	x1, #0xfe
    5e68:	54fffb81 	b.ne	5dd8 <fwp_drop0+0x98>  // b.any
    5e6c:	aa1303e0 	mov	x0, x19
    5e70:	97fffae8 	bl	4a10 <fwp_rc_forget_slot>
    5e74:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e78:	39000260 	strb	w0, [x19]
    5e7c:	17ffffd7 	b	5dd8 <fwp_drop0+0x98>
    5e80:	90000020 	adrp	x0, 9000 <__divti3+0x100>
    5e84:	912b8000 	add	x0, x0, #0xae0
    5e88:	97fff65e 	bl	3800 <fwp_trap>
    5e8c:	d503201f 	nop

0000000000005e90 <fwp_closure_drop>:
    5e90:	900003a5 	adrp	x5, 79000 <fwp_root_context+0xbc0>
    5e94:	911880a4 	add	x4, x5, #0x620
    5e98:	aa0003e1 	mov	x1, x0
    5e9c:	f949d882 	ldr	x2, [x4, #5040]
    5ea0:	f949ec80 	ldr	x0, [x4, #5080]
    5ea4:	cb020022 	sub	x2, x1, x2
    5ea8:	eb00405f 	cmp	x2, x0, lsl #16
    5eac:	54000662 	b.cs	5f78 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5eb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5eb4:	d350fc43 	lsr	x3, x2, #16
    5eb8:	910003fd 	mov	x29, sp
    5ebc:	8b030863 	add	x3, x3, x3, lsl #2
    5ec0:	f949fc84 	ldr	x4, [x4, #5112]
    5ec4:	d37df063 	lsl	x3, x3, #3
    5ec8:	f9000bf3 	str	x19, [sp, #16]
    5ecc:	8b030080 	add	x0, x4, x3
    5ed0:	f9401013 	ldr	x19, [x0, #32]
    5ed4:	b40002b3 	cbz	x19, 5f28 <fwp_closure_drop+0x98>
    5ed8:	38636883 	ldrb	w3, [x4, x3]
    5edc:	7100087f 	cmp	w3, #0x2
    5ee0:	54000420 	b.eq	5f64 <fwp_closure_drop+0xd4>  // b.none
    5ee4:	7100047f 	cmp	w3, #0x1
    5ee8:	54000201 	b.ne	5f28 <fwp_closure_drop+0x98>  // b.any
    5eec:	29430003 	ldp	w3, w0, [x0, #24]
    5ef0:	92403c42 	and	x2, x2, #0xffff
    5ef4:	9b037c42 	mul	x2, x2, x3
    5ef8:	d360fc42 	lsr	x2, x2, #32
    5efc:	eb00005f 	cmp	x2, x0
    5f00:	54000142 	b.cs	5f28 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5f04:	8b020273 	add	x19, x19, x2
    5f08:	39400260 	ldrb	w0, [x19]
    5f0c:	340000e0 	cbz	w0, 5f28 <fwp_closure_drop+0x98>
    5f10:	7100041f 	cmp	w0, #0x1
    5f14:	54000100 	b.eq	5f34 <fwp_closure_drop+0xa4>  // b.none
    5f18:	7103fc1f 	cmp	w0, #0xff
    5f1c:	54000300 	b.eq	5f7c <fwp_closure_drop+0xec>  // b.none
    5f20:	51000400 	sub	w0, w0, #0x1
    5f24:	39000260 	strb	w0, [x19]
    5f28:	f9400bf3 	ldr	x19, [sp, #16]
    5f2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f30:	d65f03c0 	ret
    5f34:	d53bd040 	mrs	x0, tpidr_el0
    5f38:	91400000 	add	x0, x0, #0x0, lsl #12
    5f3c:	91004000 	add	x0, x0, #0x10
    5f40:	f9400000 	ldr	x0, [x0]
    5f44:	b4000080 	cbz	x0, 5f54 <fwp_closure_drop+0xc4>
    5f48:	f9400bf3 	ldr	x19, [sp, #16]
    5f4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f50:	17fff645 	b	3864 <fwp_closure_drop_push>
    5f54:	f9400bf3 	ldr	x19, [sp, #16]
    5f58:	aa0103e0 	mov	x0, x1
    5f5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f60:	17fff6b0 	b	3a20 <fwp_closure_drop.part.0>
    5f64:	72003c5f 	tst	w2, #0xffff
    5f68:	54fffd00 	b.eq	5f08 <fwp_closure_drop+0x78>  // b.none
    5f6c:	f9400bf3 	ldr	x19, [sp, #16]
    5f70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f74:	d65f03c0 	ret
    5f78:	d65f03c0 	ret
    5f7c:	ca534660 	eor	x0, x19, x19, lsr #17
    5f80:	911880a5 	add	x5, x5, #0x620
    5f84:	ca402400 	eor	x0, x0, x0, lsr #9
    5f88:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5f8c:	f94a2400 	ldr	x0, [x0, #5192]
    5f90:	b5000080 	cbnz	x0, 5fa0 <fwp_closure_drop+0x110>
    5f94:	14000010 	b	5fd4 <fwp_closure_drop+0x144>
    5f98:	f9400800 	ldr	x0, [x0, #16]
    5f9c:	b40001c0 	cbz	x0, 5fd4 <fwp_closure_drop+0x144>
    5fa0:	f9400001 	ldr	x1, [x0]
    5fa4:	eb13003f 	cmp	x1, x19
    5fa8:	54ffff81 	b.ne	5f98 <fwp_closure_drop+0x108>  // b.any
    5fac:	f9400401 	ldr	x1, [x0, #8]
    5fb0:	d1000421 	sub	x1, x1, #0x1
    5fb4:	f9000401 	str	x1, [x0, #8]
    5fb8:	f103f83f 	cmp	x1, #0xfe
    5fbc:	54fffb61 	b.ne	5f28 <fwp_closure_drop+0x98>  // b.any
    5fc0:	aa1303e0 	mov	x0, x19
    5fc4:	97fffa93 	bl	4a10 <fwp_rc_forget_slot>
    5fc8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5fcc:	39000260 	strb	w0, [x19]
    5fd0:	17ffffd6 	b	5f28 <fwp_closure_drop+0x98>
    5fd4:	90000020 	adrp	x0, 9000 <__divti3+0x100>
    5fd8:	912b8000 	add	x0, x0, #0xae0
    5fdc:	97fff609 	bl	3800 <fwp_trap>

0000000000005fe0 <fwp_owned_tape_release>:
    5fe0:	b4000940 	cbz	x0, 6108 <fwp_owned_tape_release+0x128>
    5fe4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fe8:	910003fd 	mov	x29, sp
    5fec:	a90153f3 	stp	x19, x20, [sp, #16]
    5ff0:	aa0003f3 	mov	x19, x0
    5ff4:	f9400000 	ldr	x0, [x0]
    5ff8:	b4000060 	cbz	x0, 6004 <fwp_owned_tape_release+0x24>
    5ffc:	f9400661 	ldr	x1, [x19, #8]
    6000:	f9000401 	str	x1, [x0, #8]
    6004:	f9400661 	ldr	x1, [x19, #8]
    6008:	b4000041 	cbz	x1, 6010 <fwp_owned_tape_release+0x30>
    600c:	f9000020 	str	x0, [x1]
    6010:	f9400a60 	ldr	x0, [x19, #16]
    6014:	f9403401 	ldr	x1, [x0, #104]
    6018:	b40005c1 	cbz	x1, 60d0 <fwp_owned_tape_release+0xf0>
    601c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6020:	eb00005f 	cmp	x2, x0
    6024:	540002ed 	b.le	6080 <fwp_owned_tape_release+0xa0>
    6028:	d2800014 	mov	x20, #0x0                   	// #0
    602c:	f90013f5 	str	x21, [sp, #32]
    6030:	d2800015 	mov	x21, #0x0                   	// #0
    6034:	d503201f 	nop
    6038:	f9402260 	ldr	x0, [x19, #64]
    603c:	910006b5 	add	x21, x21, #0x1
    6040:	f8746800 	ldr	x0, [x0, x20]
    6044:	d63f0020 	blr	x1
    6048:	f9402260 	ldr	x0, [x19, #64]
    604c:	f9400a61 	ldr	x1, [x19, #16]
    6050:	8b140000 	add	x0, x0, x20
    6054:	91004294 	add	x20, x20, #0x10
    6058:	f9400400 	ldr	x0, [x0, #8]
    605c:	f9403421 	ldr	x1, [x1, #104]
    6060:	d63f0020 	blr	x1
    6064:	a9450261 	ldp	x1, x0, [x19, #80]
    6068:	cb010000 	sub	x0, x0, x1
    606c:	eb15001f 	cmp	x0, x21
    6070:	f9400a60 	ldr	x0, [x19, #16]
    6074:	f9403401 	ldr	x1, [x0, #104]
    6078:	54fffe0c 	b.gt	6038 <fwp_owned_tape_release+0x58>
    607c:	f94013f5 	ldr	x21, [sp, #32]
    6080:	f9403663 	ldr	x3, [x19, #104]
    6084:	f9401262 	ldr	x2, [x19, #32]
    6088:	f100007f 	cmp	x3, #0x0
    608c:	540001ed 	b.le	60c8 <fwp_owned_tape_release+0xe8>
    6090:	d2800014 	mov	x20, #0x0                   	// #0
    6094:	d503201f 	nop
    6098:	f9402660 	ldr	x0, [x19, #72]
    609c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    60a0:	eb02001f 	cmp	x0, x2
    60a4:	540000c0 	b.eq	60bc <fwp_owned_tape_release+0xdc>  // b.none
    60a8:	d63f0020 	blr	x1
    60ac:	f9400a60 	ldr	x0, [x19, #16]
    60b0:	f9401262 	ldr	x2, [x19, #32]
    60b4:	f9403663 	ldr	x3, [x19, #104]
    60b8:	f9403401 	ldr	x1, [x0, #104]
    60bc:	91000694 	add	x20, x20, #0x1
    60c0:	eb14007f 	cmp	x3, x20
    60c4:	54fffeac 	b.gt	6098 <fwp_owned_tape_release+0xb8>
    60c8:	aa0203e0 	mov	x0, x2
    60cc:	d63f0020 	blr	x1
    60d0:	f9401660 	ldr	x0, [x19, #40]
    60d4:	97ffff6f 	bl	5e90 <fwp_closure_drop>
    60d8:	f9401a60 	ldr	x0, [x19, #48]
    60dc:	97ffff6d 	bl	5e90 <fwp_closure_drop>
    60e0:	f9401e60 	ldr	x0, [x19, #56]
    60e4:	97ffff6b 	bl	5e90 <fwp_closure_drop>
    60e8:	f9402260 	ldr	x0, [x19, #64]
    60ec:	97fffae9 	bl	4c90 <fwp_mem_free>
    60f0:	f9402660 	ldr	x0, [x19, #72]
    60f4:	97fffae7 	bl	4c90 <fwp_mem_free>
    60f8:	aa1303e0 	mov	x0, x19
    60fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6100:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6104:	17fffae3 	b	4c90 <fwp_mem_free>
    6108:	d65f03c0 	ret
    610c:	d503201f 	nop

0000000000006110 <fwp_tape_finish>:
    6110:	d10203ff 	sub	sp, sp, #0x80
    6114:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6118:	f947f421 	ldr	x1, [x1, #4072]
    611c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6120:	910103fd 	add	x29, sp, #0x40
    6124:	a9065bf5 	stp	x21, x22, [sp, #96]
    6128:	a90763f7 	stp	x23, x24, [sp, #112]
    612c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6130:	910142f6 	add	x22, x23, #0x50
    6134:	f9400022 	ldr	x2, [x1]
    6138:	f9001fe2 	str	x2, [sp, #56]
    613c:	d2800002 	mov	x2, #0x0                   	// #0
    6140:	910382c0 	add	x0, x22, #0xe0
    6144:	97fff8b0 	bl	4404 <fwp_tape_buffers_dispose>
    6148:	f9008edf 	str	xzr, [x22, #280]
    614c:	f9406ec0 	ldr	x0, [x22, #216]
    6150:	f100001f 	cmp	x0, #0x0
    6154:	5400034d 	b.le	61bc <fwp_tape_finish+0xac>
    6158:	910003f8 	mov	x24, sp
    615c:	d2800015 	mov	x21, #0x0                   	// #0
    6160:	a90553f3 	stp	x19, x20, [sp, #80]
    6164:	d2800014 	mov	x20, #0x0                   	// #0
    6168:	91000694 	add	x20, x20, #0x1
    616c:	f94046d3 	ldr	x19, [x22, #136]
    6170:	8b150273 	add	x19, x19, x21
    6174:	9101a2b5 	add	x21, x21, #0x68
    6178:	aa1303e0 	mov	x0, x19
    617c:	97fff3a6 	bl	3014 <fwp_tape_unlink_scope>
    6180:	aa1803e0 	mov	x0, x24
    6184:	a9440663 	ldp	x3, x1, [x19, #64]
    6188:	f9001be1 	str	x1, [sp, #48]
    618c:	f9400e62 	ldr	x2, [x19, #24]
    6190:	a9020be3 	stp	x3, x2, [sp, #32]
    6194:	ad410261 	ldp	q1, q0, [x19, #32]
    6198:	ad0003e1 	stp	q1, q0, [sp]
    619c:	97fff89a 	bl	4404 <fwp_tape_buffers_dispose>
    61a0:	f9403260 	ldr	x0, [x19, #96]
    61a4:	97ffff8f 	bl	5fe0 <fwp_owned_tape_release>
    61a8:	f900327f 	str	xzr, [x19, #96]
    61ac:	f9406ec0 	ldr	x0, [x22, #216]
    61b0:	eb14001f 	cmp	x0, x20
    61b4:	54fffdac 	b.gt	6168 <fwp_tape_finish+0x58>
    61b8:	a94553f3 	ldp	x19, x20, [sp, #80]
    61bc:	910142e0 	add	x0, x23, #0x50
    61c0:	f9404400 	ldr	x0, [x0, #136]
    61c4:	b4000040 	cbz	x0, 61cc <fwp_tape_finish+0xbc>
    61c8:	97fff86e 	bl	4380 <ad_raw_free.part.0>
    61cc:	910142f7 	add	x23, x23, #0x50
    61d0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    61d4:	f947f400 	ldr	x0, [x0, #4072]
    61d8:	f90046ff 	str	xzr, [x23, #136]
    61dc:	f9006eff 	str	xzr, [x23, #216]
    61e0:	f90092ff 	str	xzr, [x23, #288]
    61e4:	f900b2ff 	str	xzr, [x23, #352]
    61e8:	f9401fe2 	ldr	x2, [sp, #56]
    61ec:	f9400001 	ldr	x1, [x0]
    61f0:	eb010042 	subs	x2, x2, x1
    61f4:	d2800001 	mov	x1, #0x0                   	// #0
    61f8:	540000c1 	b.ne	6210 <fwp_tape_finish+0x100>  // b.any
    61fc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6200:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6204:	a94763f7 	ldp	x23, x24, [sp, #112]
    6208:	910203ff 	add	sp, sp, #0x80
    620c:	d65f03c0 	ret
    6210:	a90553f3 	stp	x19, x20, [sp, #80]
    6214:	97fff1a3 	bl	28a0 <__stack_chk_fail@plt>
    6218:	d503201f 	nop
    621c:	d503201f 	nop

0000000000006220 <fwp_tape_scope_release>:
    6220:	d10243ff 	sub	sp, sp, #0x90
    6224:	a9047bfd 	stp	x29, x30, [sp, #64]
    6228:	910103fd 	add	x29, sp, #0x40
    622c:	a90553f3 	stp	x19, x20, [sp, #80]
    6230:	aa0003f4 	mov	x20, x0
    6234:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6238:	f947f400 	ldr	x0, [x0, #4072]
    623c:	b9400285 	ldr	w5, [x20]
    6240:	f9400001 	ldr	x1, [x0]
    6244:	f9001fe1 	str	x1, [sp, #56]
    6248:	d2800001 	mov	x1, #0x0                   	// #0
    624c:	37f806c5 	tbnz	w5, #31, 6324 <fwp_tape_scope_release+0x104>
    6250:	a90763f7 	stp	x23, x24, [sp, #112]
    6254:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6258:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    625c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6260:	d00000d3 	adrp	x19, 20000 <__data_start>
    6264:	910003f7 	mov	x23, sp
    6268:	91014273 	add	x19, x19, #0x50
    626c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6270:	a9065bf5 	stp	x21, x22, [sp, #96]
    6274:	52800d16 	mov	w22, #0x68                  	// #104
    6278:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    627c:	f90043f9 	str	x25, [sp, #128]
    6280:	14000006 	b	6298 <fwp_tape_scope_release+0x78>
    6284:	97fff860 	bl	4404 <fwp_tape_buffers_dispose>
    6288:	aa1903e0 	mov	x0, x25
    628c:	97ffff55 	bl	5fe0 <fwp_owned_tape_release>
    6290:	b9400285 	ldr	w5, [x20]
    6294:	37f80425 	tbnz	w5, #31, 6318 <fwp_tape_scope_release+0xf8>
    6298:	f9404666 	ldr	x6, [x19, #136]
    629c:	9b367ca5 	smull	x5, w5, w22
    62a0:	8b0500c0 	add	x0, x6, x5
    62a4:	97fff35c 	bl	3014 <fwp_tape_unlink_scope>
    62a8:	ad410001 	ldp	q1, q0, [x0, #32]
    62ac:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    62b0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    62b4:	f9400c03 	ldr	x3, [x0, #24]
    62b8:	ad0003e1 	stp	q1, q0, [sp]
    62bc:	b86568c1 	ldr	w1, [x6, x5]
    62c0:	a9440804 	ldp	x4, x2, [x0, #64]
    62c4:	b900041f 	str	wzr, [x0, #4]
    62c8:	f9403019 	ldr	x25, [x0, #96]
    62cc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    62d0:	f9000c1f 	str	xzr, [x0, #24]
    62d4:	a9020fe4 	stp	x4, x3, [sp, #32]
    62d8:	f9001be2 	str	x2, [sp, #48]
    62dc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    62e0:	f900301f 	str	xzr, [x0, #96]
    62e4:	6b15003f 	cmp	w1, w21
    62e8:	540000e8 	b.hi	6304 <fwp_tape_scope_release+0xe4>  // b.pmore
    62ec:	9343fca5 	asr	x5, x5, #3
    62f0:	f940b260 	ldr	x0, [x19, #352]
    62f4:	9b187ca5 	mul	x5, x5, x24
    62f8:	eb0000bf 	cmp	x5, x0
    62fc:	5400004a 	b.ge	6304 <fwp_tape_scope_release+0xe4>  // b.tcont
    6300:	f900b265 	str	x5, [x19, #352]
    6304:	aa1703e0 	mov	x0, x23
    6308:	b5fffbf9 	cbnz	x25, 6284 <fwp_tape_scope_release+0x64>
    630c:	97fff886 	bl	4524 <fwp_tape_buffers_release>
    6310:	b9400285 	ldr	w5, [x20]
    6314:	36fffc25 	tbz	w5, #31, 6298 <fwp_tape_scope_release+0x78>
    6318:	a9465bf5 	ldp	x21, x22, [sp, #96]
    631c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6320:	f94043f9 	ldr	x25, [sp, #128]
    6324:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6328:	f947f400 	ldr	x0, [x0, #4072]
    632c:	f9401fe2 	ldr	x2, [sp, #56]
    6330:	f9400001 	ldr	x1, [x0]
    6334:	eb010042 	subs	x2, x2, x1
    6338:	d2800001 	mov	x1, #0x0                   	// #0
    633c:	540000a1 	b.ne	6350 <fwp_tape_scope_release+0x130>  // b.any
    6340:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6344:	a94553f3 	ldp	x19, x20, [sp, #80]
    6348:	910243ff 	add	sp, sp, #0x90
    634c:	d65f03c0 	ret
    6350:	a9065bf5 	stp	x21, x22, [sp, #96]
    6354:	a90763f7 	stp	x23, x24, [sp, #112]
    6358:	f90043f9 	str	x25, [sp, #128]
    635c:	97fff151 	bl	28a0 <__stack_chk_fail@plt>

0000000000006360 <fwp_drop4>:
    6360:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6364:	910003fd 	mov	x29, sp
    6368:	a9025bf5 	stp	x21, x22, [sp, #32]
    636c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    6370:	911882d5 	add	x21, x22, #0x620
    6374:	a90153f3 	stp	x19, x20, [sp, #16]
    6378:	aa0003f3 	mov	x19, x0
    637c:	f949daa1 	ldr	x1, [x21, #5040]
    6380:	f949eea0 	ldr	x0, [x21, #5080]
    6384:	cb010261 	sub	x1, x19, x1
    6388:	eb00403f 	cmp	x1, x0, lsl #16
    638c:	54000382 	b.cs	63fc <fwp_drop4+0x9c>  // b.hs, b.nlast
    6390:	d350fc22 	lsr	x2, x1, #16
    6394:	f949fea3 	ldr	x3, [x21, #5112]
    6398:	8b020842 	add	x2, x2, x2, lsl #2
    639c:	d37df042 	lsl	x2, x2, #3
    63a0:	8b020060 	add	x0, x3, x2
    63a4:	f9401014 	ldr	x20, [x0, #32]
    63a8:	b40002b4 	cbz	x20, 63fc <fwp_drop4+0x9c>
    63ac:	38626862 	ldrb	w2, [x3, x2]
    63b0:	7100085f 	cmp	w2, #0x2
    63b4:	540002c0 	b.eq	640c <fwp_drop4+0xac>  // b.none
    63b8:	7100045f 	cmp	w2, #0x1
    63bc:	54000201 	b.ne	63fc <fwp_drop4+0x9c>  // b.any
    63c0:	29430002 	ldp	w2, w0, [x0, #24]
    63c4:	92403c21 	and	x1, x1, #0xffff
    63c8:	9b027c21 	mul	x1, x1, x2
    63cc:	d360fc21 	lsr	x1, x1, #32
    63d0:	eb00003f 	cmp	x1, x0
    63d4:	54000142 	b.cs	63fc <fwp_drop4+0x9c>  // b.hs, b.nlast
    63d8:	8b010294 	add	x20, x20, x1
    63dc:	39400280 	ldrb	w0, [x20]
    63e0:	340000e0 	cbz	w0, 63fc <fwp_drop4+0x9c>
    63e4:	7100041f 	cmp	w0, #0x1
    63e8:	540001e0 	b.eq	6424 <fwp_drop4+0xc4>  // b.none
    63ec:	7103fc1f 	cmp	w0, #0xff
    63f0:	540007c0 	b.eq	64e8 <fwp_drop4+0x188>  // b.none
    63f4:	51000400 	sub	w0, w0, #0x1
    63f8:	39000280 	strb	w0, [x20]
    63fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6400:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6404:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6408:	d65f03c0 	ret
    640c:	72003c3f 	tst	w1, #0xffff
    6410:	54fffe60 	b.eq	63dc <fwp_drop4+0x7c>  // b.none
    6414:	a94153f3 	ldp	x19, x20, [sp, #16]
    6418:	a9425bf5 	ldp	x21, x22, [sp, #32]
    641c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6420:	d65f03c0 	ret
    6424:	911882c2 	add	x2, x22, #0x620
    6428:	f9400660 	ldr	x0, [x19, #8]
    642c:	f949d841 	ldr	x1, [x2, #5040]
    6430:	f949ec42 	ldr	x2, [x2, #5080]
    6434:	cb010001 	sub	x1, x0, x1
    6438:	eb02403f 	cmp	x1, x2, lsl #16
    643c:	54000362 	b.cs	64a8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6440:	d350fc22 	lsr	x2, x1, #16
    6444:	8b020842 	add	x2, x2, x2, lsl #2
    6448:	d37df042 	lsl	x2, x2, #3
    644c:	8b020064 	add	x4, x3, x2
    6450:	f9401094 	ldr	x20, [x4, #32]
    6454:	b40002b4 	cbz	x20, 64a8 <fwp_drop4+0x148>
    6458:	38626862 	ldrb	w2, [x3, x2]
    645c:	7100085f 	cmp	w2, #0x2
    6460:	540003e0 	b.eq	64dc <fwp_drop4+0x17c>  // b.none
    6464:	7100045f 	cmp	w2, #0x1
    6468:	54000201 	b.ne	64a8 <fwp_drop4+0x148>  // b.any
    646c:	29430883 	ldp	w3, w2, [x4, #24]
    6470:	92403c21 	and	x1, x1, #0xffff
    6474:	9b037c21 	mul	x1, x1, x3
    6478:	d360fc21 	lsr	x1, x1, #32
    647c:	eb02003f 	cmp	x1, x2
    6480:	54000142 	b.cs	64a8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6484:	8b010294 	add	x20, x20, x1
    6488:	39400281 	ldrb	w1, [x20]
    648c:	340000e1 	cbz	w1, 64a8 <fwp_drop4+0x148>
    6490:	7100043f 	cmp	w1, #0x1
    6494:	54000200 	b.eq	64d4 <fwp_drop4+0x174>  // b.none
    6498:	7103fc3f 	cmp	w1, #0xff
    649c:	54000580 	b.eq	654c <fwp_drop4+0x1ec>  // b.none
    64a0:	51000421 	sub	w1, w1, #0x1
    64a4:	39000281 	strb	w1, [x20]
    64a8:	f9400a74 	ldr	x20, [x19, #16]
    64ac:	aa1303e0 	mov	x0, x19
    64b0:	97fffcf1 	bl	5874 <fwp_rc_free_arr>
    64b4:	911882c0 	add	x0, x22, #0x620
    64b8:	f949d801 	ldr	x1, [x0, #5040]
    64bc:	f949ec00 	ldr	x0, [x0, #5080]
    64c0:	cb010281 	sub	x1, x20, x1
    64c4:	eb00403f 	cmp	x1, x0, lsl #16
    64c8:	54fff9a2 	b.cs	63fc <fwp_drop4+0x9c>  // b.hs, b.nlast
    64cc:	aa1403f3 	mov	x19, x20
    64d0:	17ffffb0 	b	6390 <fwp_drop4+0x30>
    64d4:	97fffce8 	bl	5874 <fwp_rc_free_arr>
    64d8:	17fffff4 	b	64a8 <fwp_drop4+0x148>
    64dc:	72003c3f 	tst	w1, #0xffff
    64e0:	54fffe41 	b.ne	64a8 <fwp_drop4+0x148>  // b.any
    64e4:	17ffffe9 	b	6488 <fwp_drop4+0x128>
    64e8:	ca544681 	eor	x1, x20, x20, lsr #17
    64ec:	911882c0 	add	x0, x22, #0x620
    64f0:	ca412421 	eor	x1, x1, x1, lsr #9
    64f4:	8b210c01 	add	x1, x0, w1, uxtb #3
    64f8:	f94a2420 	ldr	x0, [x1, #5192]
    64fc:	b5000080 	cbnz	x0, 650c <fwp_drop4+0x1ac>
    6500:	14000010 	b	6540 <fwp_drop4+0x1e0>
    6504:	f9400800 	ldr	x0, [x0, #16]
    6508:	b40001c0 	cbz	x0, 6540 <fwp_drop4+0x1e0>
    650c:	f9400001 	ldr	x1, [x0]
    6510:	eb14003f 	cmp	x1, x20
    6514:	54ffff81 	b.ne	6504 <fwp_drop4+0x1a4>  // b.any
    6518:	f9400401 	ldr	x1, [x0, #8]
    651c:	d1000421 	sub	x1, x1, #0x1
    6520:	f9000401 	str	x1, [x0, #8]
    6524:	f103f83f 	cmp	x1, #0xfe
    6528:	54fff6a1 	b.ne	63fc <fwp_drop4+0x9c>  // b.any
    652c:	aa1403e0 	mov	x0, x20
    6530:	97fff938 	bl	4a10 <fwp_rc_forget_slot>
    6534:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6538:	39000280 	strb	w0, [x20]
    653c:	17ffffb0 	b	63fc <fwp_drop4+0x9c>
    6540:	f0000000 	adrp	x0, 9000 <__divti3+0x100>
    6544:	912b8000 	add	x0, x0, #0xae0
    6548:	97fff4ae 	bl	3800 <fwp_trap>
    654c:	ca544680 	eor	x0, x20, x20, lsr #17
    6550:	911882c1 	add	x1, x22, #0x620
    6554:	ca402400 	eor	x0, x0, x0, lsr #9
    6558:	8b200c20 	add	x0, x1, w0, uxtb #3
    655c:	f94a2400 	ldr	x0, [x0, #5192]
    6560:	b5000080 	cbnz	x0, 6570 <fwp_drop4+0x210>
    6564:	17fffff7 	b	6540 <fwp_drop4+0x1e0>
    6568:	f9400800 	ldr	x0, [x0, #16]
    656c:	b4fffea0 	cbz	x0, 6540 <fwp_drop4+0x1e0>
    6570:	f9400001 	ldr	x1, [x0]
    6574:	eb14003f 	cmp	x1, x20
    6578:	54ffff81 	b.ne	6568 <fwp_drop4+0x208>  // b.any
    657c:	f9400401 	ldr	x1, [x0, #8]
    6580:	d1000421 	sub	x1, x1, #0x1
    6584:	f9000401 	str	x1, [x0, #8]
    6588:	f103f83f 	cmp	x1, #0xfe
    658c:	54fff8e1 	b.ne	64a8 <fwp_drop4+0x148>  // b.any
    6590:	aa1403e0 	mov	x0, x20
    6594:	97fff91f 	bl	4a10 <fwp_rc_forget_slot>
    6598:	12800020 	mov	w0, #0xfffffffe            	// #-2
    659c:	39000280 	strb	w0, [x20]
    65a0:	17ffffc2 	b	64a8 <fwp_drop4+0x148>

00000000000065a4 <fwp_arg_drop37>:
    65a4:	7100003f 	cmp	w1, #0x0
    65a8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    65ac:	54000041 	b.ne	65b4 <fwp_arg_drop37+0x10>  // b.any
    65b0:	d65f03c0 	ret
    65b4:	f9400000 	ldr	x0, [x0]
    65b8:	17ffff6a 	b	6360 <fwp_drop4>
    65bc:	d503201f 	nop

00000000000065c0 <fwp_task_dispose>:
    65c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65c4:	910003fd 	mov	x29, sp
    65c8:	f9000bf3 	str	x19, [sp, #16]
    65cc:	aa0003f3 	mov	x19, x0
    65d0:	39414000 	ldrb	w0, [x0, #80]
    65d4:	36000720 	tbz	w0, #0, 66b8 <fwp_task_dispose+0xf8>
    65d8:	f9400a60 	ldr	x0, [x19, #16]
    65dc:	b50006e0 	cbnz	x0, 66b8 <fwp_task_dispose+0xf8>
    65e0:	a9478660 	ldp	x0, x1, [x19, #120]
    65e4:	39014e7f 	strb	wzr, [x19, #83]
    65e8:	f9003e7f 	str	xzr, [x19, #120]
    65ec:	f100003f 	cmp	x1, #0x0
    65f0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    65f4:	54000040 	b.eq	65fc <fwp_task_dispose+0x3c>  // b.none
    65f8:	d63f0020 	blr	x1
    65fc:	f9405660 	ldr	x0, [x19, #168]
    6600:	97fff9a4 	bl	4c90 <fwp_mem_free>
    6604:	f900567f 	str	xzr, [x19, #168]
    6608:	b9405e60 	ldr	w0, [x19, #92]
    660c:	7100041f 	cmp	w0, #0x1
    6610:	54000420 	b.eq	6694 <fwp_task_dispose+0xd4>  // b.none
    6614:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    6618:	91188042 	add	x2, x2, #0x620
    661c:	f949d840 	ldr	x0, [x2, #5040]
    6620:	f949ec41 	ldr	x1, [x2, #5080]
    6624:	cb000260 	sub	x0, x19, x0
    6628:	eb01401f 	cmp	x0, x1, lsl #16
    662c:	540002e2 	b.cs	6688 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6630:	d350fc01 	lsr	x1, x0, #16
    6634:	f949fc44 	ldr	x4, [x2, #5112]
    6638:	8b010821 	add	x1, x1, x1, lsl #2
    663c:	d37df021 	lsl	x1, x1, #3
    6640:	8b010083 	add	x3, x4, x1
    6644:	f9401062 	ldr	x2, [x3, #32]
    6648:	b4000202 	cbz	x2, 6688 <fwp_task_dispose+0xc8>
    664c:	38616881 	ldrb	w1, [x4, x1]
    6650:	7100083f 	cmp	w1, #0x2
    6654:	54000280 	b.eq	66a4 <fwp_task_dispose+0xe4>  // b.none
    6658:	7100043f 	cmp	w1, #0x1
    665c:	54000161 	b.ne	6688 <fwp_task_dispose+0xc8>  // b.any
    6660:	29430464 	ldp	w4, w1, [x3, #24]
    6664:	92403c00 	and	x0, x0, #0xffff
    6668:	9b047c00 	mul	x0, x0, x4
    666c:	d360fc00 	lsr	x0, x0, #32
    6670:	eb01001f 	cmp	x0, x1
    6674:	540000a2 	b.cs	6688 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6678:	8b000042 	add	x2, x2, x0
    667c:	39400040 	ldrb	w0, [x2]
    6680:	7100041f 	cmp	w0, #0x1
    6684:	54000080 	b.eq	6694 <fwp_task_dispose+0xd4>  // b.none
    6688:	f9400bf3 	ldr	x19, [sp, #16]
    668c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6690:	d65f03c0 	ret
    6694:	aa1303e0 	mov	x0, x19
    6698:	f9400bf3 	ldr	x19, [sp, #16]
    669c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66a0:	17fff97c 	b	4c90 <fwp_mem_free>
    66a4:	72003c1f 	tst	w0, #0xffff
    66a8:	54fffea0 	b.eq	667c <fwp_task_dispose+0xbc>  // b.none
    66ac:	f9400bf3 	ldr	x19, [sp, #16]
    66b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66b4:	d65f03c0 	ret
    66b8:	97fff08e 	bl	28f0 <abort@plt>
    66bc:	d503201f 	nop

00000000000066c0 <fwp_free_zombie>:
    66c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66c4:	910003fd 	mov	x29, sp
    66c8:	a90153f3 	stp	x19, x20, [sp, #16]
    66cc:	d00000d4 	adrp	x20, 20000 <__data_start>
    66d0:	91014281 	add	x1, x20, #0x50
    66d4:	f940b433 	ldr	x19, [x1, #360]
    66d8:	b4000333 	cbz	x19, 673c <fwp_free_zombie+0x7c>
    66dc:	f9404c20 	ldr	x0, [x1, #152]
    66e0:	eb00027f 	cmp	x19, x0
    66e4:	540002c0 	b.eq	673c <fwp_free_zombie+0x7c>  // b.none
    66e8:	b9417022 	ldr	w2, [x1, #368]
    66ec:	f9400a60 	ldr	x0, [x19, #16]
    66f0:	7100fc5f 	cmp	w2, #0x3f
    66f4:	5400078c 	b.gt	67e4 <fwp_free_zombie+0x124>
    66f8:	91060023 	add	x3, x1, #0x180
    66fc:	11000444 	add	w4, w2, #0x1
    6700:	b9017024 	str	w4, [x1, #368]
    6704:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6708:	f822d860 	str	x0, [x3, w2, sxtw #3]
    670c:	a9530261 	ldp	x1, x0, [x19, #304]
    6710:	b4000741 	cbz	x1, 67f8 <fwp_free_zombie+0x138>
    6714:	f9009c20 	str	x0, [x1, #312]
    6718:	b4000040 	cbz	x0, 6720 <fwp_free_zombie+0x60>
    671c:	f9009801 	str	x1, [x0, #304]
    6720:	91014294 	add	x20, x20, #0x50
    6724:	b9405e60 	ldr	w0, [x19, #92]
    6728:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    672c:	f900b69f 	str	xzr, [x20, #360]
    6730:	34000140 	cbz	w0, 6758 <fwp_free_zombie+0x98>
    6734:	7100041f 	cmp	w0, #0x1
    6738:	54000080 	b.eq	6748 <fwp_free_zombie+0x88>  // b.none
    673c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6740:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6744:	d65f03c0 	ret
    6748:	aa1303e0 	mov	x0, x19
    674c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6750:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6754:	17ffff9b 	b	65c0 <fwp_task_dispose>
    6758:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbc0>
    675c:	91188082 	add	x2, x4, #0x620
    6760:	f949d841 	ldr	x1, [x2, #5040]
    6764:	f949ec40 	ldr	x0, [x2, #5080]
    6768:	cb010261 	sub	x1, x19, x1
    676c:	eb00403f 	cmp	x1, x0, lsl #16
    6770:	54fffe62 	b.cs	673c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6774:	d350fc20 	lsr	x0, x1, #16
    6778:	f949fc43 	ldr	x3, [x2, #5112]
    677c:	8b000800 	add	x0, x0, x0, lsl #2
    6780:	d37df000 	lsl	x0, x0, #3
    6784:	8b000062 	add	x2, x3, x0
    6788:	f9401054 	ldr	x20, [x2, #32]
    678c:	b4fffd94 	cbz	x20, 673c <fwp_free_zombie+0x7c>
    6790:	38606860 	ldrb	w0, [x3, x0]
    6794:	7100081f 	cmp	w0, #0x2
    6798:	54000360 	b.eq	6804 <fwp_free_zombie+0x144>  // b.none
    679c:	7100041f 	cmp	w0, #0x1
    67a0:	54fffce1 	b.ne	673c <fwp_free_zombie+0x7c>  // b.any
    67a4:	29430043 	ldp	w3, w0, [x2, #24]
    67a8:	92403c21 	and	x1, x1, #0xffff
    67ac:	9b037c21 	mul	x1, x1, x3
    67b0:	d360fc21 	lsr	x1, x1, #32
    67b4:	eb00003f 	cmp	x1, x0
    67b8:	54fffc22 	b.cs	673c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    67bc:	8b010294 	add	x20, x20, x1
    67c0:	39400280 	ldrb	w0, [x20]
    67c4:	34fffbc0 	cbz	w0, 673c <fwp_free_zombie+0x7c>
    67c8:	7100041f 	cmp	w0, #0x1
    67cc:	54fffbe0 	b.eq	6748 <fwp_free_zombie+0x88>  // b.none
    67d0:	7103fc1f 	cmp	w0, #0xff
    67d4:	540001e0 	b.eq	6810 <fwp_free_zombie+0x150>  // b.none
    67d8:	51000400 	sub	w0, w0, #0x1
    67dc:	39000280 	strb	w0, [x20]
    67e0:	17ffffd7 	b	673c <fwp_free_zombie+0x7c>
    67e4:	f9400e61 	ldr	x1, [x19, #24]
    67e8:	97fff076 	bl	29c0 <munmap@plt>
    67ec:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67f0:	a9530261 	ldp	x1, x0, [x19, #304]
    67f4:	b5fff901 	cbnz	x1, 6714 <fwp_free_zombie+0x54>
    67f8:	91014282 	add	x2, x20, #0x50
    67fc:	f901c040 	str	x0, [x2, #896]
    6800:	17ffffc6 	b	6718 <fwp_free_zombie+0x58>
    6804:	72003c3f 	tst	w1, #0xffff
    6808:	54fff9a1 	b.ne	673c <fwp_free_zombie+0x7c>  // b.any
    680c:	17ffffed 	b	67c0 <fwp_free_zombie+0x100>
    6810:	ca544680 	eor	x0, x20, x20, lsr #17
    6814:	91188084 	add	x4, x4, #0x620
    6818:	ca402400 	eor	x0, x0, x0, lsr #9
    681c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6820:	f94a2400 	ldr	x0, [x0, #5192]
    6824:	b5000080 	cbnz	x0, 6834 <fwp_free_zombie+0x174>
    6828:	14000010 	b	6868 <fwp_free_zombie+0x1a8>
    682c:	f9400800 	ldr	x0, [x0, #16]
    6830:	b40001c0 	cbz	x0, 6868 <fwp_free_zombie+0x1a8>
    6834:	f9400001 	ldr	x1, [x0]
    6838:	eb14003f 	cmp	x1, x20
    683c:	54ffff81 	b.ne	682c <fwp_free_zombie+0x16c>  // b.any
    6840:	f9400401 	ldr	x1, [x0, #8]
    6844:	d1000421 	sub	x1, x1, #0x1
    6848:	f9000401 	str	x1, [x0, #8]
    684c:	f103f83f 	cmp	x1, #0xfe
    6850:	54fff761 	b.ne	673c <fwp_free_zombie+0x7c>  // b.any
    6854:	aa1403e0 	mov	x0, x20
    6858:	97fff86e 	bl	4a10 <fwp_rc_forget_slot>
    685c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6860:	39000280 	strb	w0, [x20]
    6864:	17ffffb6 	b	673c <fwp_free_zombie+0x7c>
    6868:	f0000000 	adrp	x0, 9000 <__divti3+0x100>
    686c:	912b8000 	add	x0, x0, #0xae0
    6870:	97fff3e4 	bl	3800 <fwp_trap>

0000000000006874 <fwp_block>:
    6874:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6878:	910003fd 	mov	x29, sp
    687c:	a90153f3 	stp	x19, x20, [sp, #16]
    6880:	d00000d3 	adrp	x19, 20000 <__data_start>
    6884:	91014274 	add	x20, x19, #0x50
    6888:	f9406682 	ldr	x2, [x20, #200]
    688c:	b4000622 	cbz	x2, 6950 <fwp_block+0xdc>
    6890:	91014261 	add	x1, x19, #0x50
    6894:	f9408040 	ldr	x0, [x2, #256]
    6898:	f9006420 	str	x0, [x1, #200]
    689c:	b4000680 	cbz	x0, 696c <fwp_block+0xf8>
    68a0:	91014263 	add	x3, x19, #0x50
    68a4:	3901505f 	strb	wzr, [x2, #84]
    68a8:	f9404c64 	ldr	x4, [x3, #152]
    68ac:	eb02009f 	cmp	x4, x2
    68b0:	54000440 	b.eq	6938 <fwp_block+0xc4>  // b.none
    68b4:	f941c465 	ldr	x5, [x3, #904]
    68b8:	f9004c62 	str	x2, [x3, #152]
    68bc:	f9400441 	ldr	x1, [x2, #8]
    68c0:	f9004885 	str	x5, [x4, #144]
    68c4:	f941c865 	ldr	x5, [x3, #912]
    68c8:	f9004c85 	str	x5, [x4, #152]
    68cc:	f941cc65 	ldr	x5, [x3, #920]
    68d0:	f9005085 	str	x5, [x4, #160]
    68d4:	f941d065 	ldr	x5, [x3, #928]
    68d8:	f9005485 	str	x5, [x4, #168]
    68dc:	f941d465 	ldr	x5, [x3, #936]
    68e0:	f9005885 	str	x5, [x4, #176]
    68e4:	f941d865 	ldr	x5, [x3, #944]
    68e8:	f9005c85 	str	x5, [x4, #184]
    68ec:	f941dc65 	ldr	x5, [x3, #952]
    68f0:	f9006085 	str	x5, [x4, #192]
    68f4:	f9400480 	ldr	x0, [x4, #8]
    68f8:	f9404844 	ldr	x4, [x2, #144]
    68fc:	f901c464 	str	x4, [x3, #904]
    6900:	f9404c44 	ldr	x4, [x2, #152]
    6904:	f901c864 	str	x4, [x3, #912]
    6908:	f9405044 	ldr	x4, [x2, #160]
    690c:	f901cc64 	str	x4, [x3, #920]
    6910:	f9405444 	ldr	x4, [x2, #168]
    6914:	f901d064 	str	x4, [x3, #928]
    6918:	f9405844 	ldr	x4, [x2, #176]
    691c:	f901d464 	str	x4, [x3, #936]
    6920:	a94b8844 	ldp	x4, x2, [x2, #184]
    6924:	f901d864 	str	x4, [x3, #944]
    6928:	f901dc62 	str	x2, [x3, #952]
    692c:	97ffeff5 	bl	2900 <swapcontext@plt>
    6930:	97ffff64 	bl	66c0 <fwp_free_zombie>
    6934:	d503201f 	nop
    6938:	91014260 	add	x0, x19, #0x50
    693c:	b943c000 	ldr	w0, [x0, #960]
    6940:	340001a0 	cbz	w0, 6974 <fwp_block+0x100>
    6944:	a94153f3 	ldp	x19, x20, [sp, #16]
    6948:	a8c27bfd 	ldp	x29, x30, [sp], #32
    694c:	d65f03c0 	ret
    6950:	97fff75d 	bl	46c4 <fwp_poll_events>
    6954:	f9406682 	ldr	x2, [x20, #200]
    6958:	b4ffffc2 	cbz	x2, 6950 <fwp_block+0xdc>
    695c:	91014261 	add	x1, x19, #0x50
    6960:	f9408040 	ldr	x0, [x2, #256]
    6964:	f9006420 	str	x0, [x1, #200]
    6968:	b5fff9c0 	cbnz	x0, 68a0 <fwp_block+0x2c>
    696c:	f900603f 	str	xzr, [x1, #192]
    6970:	17ffffcc 	b	68a0 <fwp_block+0x2c>
    6974:	f0000000 	adrp	x0, 9000 <__divti3+0x100>
    6978:	91304000 	add	x0, x0, #0xc10
    697c:	97fff02d 	bl	2a30 <getenv@plt>
    6980:	5284e202 	mov	w2, #0x2710                	// #10000
    6984:	b4000060 	cbz	x0, 6990 <fwp_block+0x11c>
    6988:	39400001 	ldrb	w1, [x0]
    698c:	350000c1 	cbnz	w1, 69a4 <fwp_block+0x130>
    6990:	91014273 	add	x19, x19, #0x50
    6994:	b903c262 	str	w2, [x19, #960]
    6998:	a94153f3 	ldp	x19, x20, [sp, #16]
    699c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69a0:	d65f03c0 	ret
    69a4:	52800142 	mov	w2, #0xa                   	// #10
    69a8:	d2800001 	mov	x1, #0x0                   	// #0
    69ac:	97ffef71 	bl	2770 <strtoll@plt>
    69b0:	d1000403 	sub	x3, x0, #0x1
    69b4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    69b8:	eb02007f 	cmp	x3, x2
    69bc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69c0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69c4:	17fffff3 	b	6990 <fwp_block+0x11c>
    69c8:	d503201f 	nop
    69cc:	d503201f 	nop

00000000000069d0 <fwp_drop10>:
    69d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69d4:	910003fd 	mov	x29, sp
    69d8:	a90153f3 	stp	x19, x20, [sp, #16]
    69dc:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    69e0:	f90013f5 	str	x21, [sp, #32]
    69e4:	91188275 	add	x21, x19, #0x620
    69e8:	f949daa1 	ldr	x1, [x21, #5040]
    69ec:	f949eea2 	ldr	x2, [x21, #5080]
    69f0:	cb010001 	sub	x1, x0, x1
    69f4:	eb02403f 	cmp	x1, x2, lsl #16
    69f8:	54000382 	b.cs	6a68 <fwp_drop10+0x98>  // b.hs, b.nlast
    69fc:	d350fc22 	lsr	x2, x1, #16
    6a00:	f949fea3 	ldr	x3, [x21, #5112]
    6a04:	8b020842 	add	x2, x2, x2, lsl #2
    6a08:	d37df042 	lsl	x2, x2, #3
    6a0c:	8b020064 	add	x4, x3, x2
    6a10:	f9401094 	ldr	x20, [x4, #32]
    6a14:	b40002b4 	cbz	x20, 6a68 <fwp_drop10+0x98>
    6a18:	38626862 	ldrb	w2, [x3, x2]
    6a1c:	7100085f 	cmp	w2, #0x2
    6a20:	540007a0 	b.eq	6b14 <fwp_drop10+0x144>  // b.none
    6a24:	7100045f 	cmp	w2, #0x1
    6a28:	54000201 	b.ne	6a68 <fwp_drop10+0x98>  // b.any
    6a2c:	29430885 	ldp	w5, w2, [x4, #24]
    6a30:	92403c21 	and	x1, x1, #0xffff
    6a34:	9b057c21 	mul	x1, x1, x5
    6a38:	d360fc21 	lsr	x1, x1, #32
    6a3c:	eb02003f 	cmp	x1, x2
    6a40:	54000142 	b.cs	6a68 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a44:	8b010294 	add	x20, x20, x1
    6a48:	39400281 	ldrb	w1, [x20]
    6a4c:	340000e1 	cbz	w1, 6a68 <fwp_drop10+0x98>
    6a50:	7100043f 	cmp	w1, #0x1
    6a54:	54000120 	b.eq	6a78 <fwp_drop10+0xa8>  // b.none
    6a58:	7103fc3f 	cmp	w1, #0xff
    6a5c:	540007c0 	b.eq	6b54 <fwp_drop10+0x184>  // b.none
    6a60:	51000421 	sub	w1, w1, #0x1
    6a64:	39000281 	strb	w1, [x20]
    6a68:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a6c:	f94013f5 	ldr	x21, [sp, #32]
    6a70:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a74:	d65f03c0 	ret
    6a78:	f9400001 	ldr	x1, [x0]
    6a7c:	b7f80581 	tbnz	x1, #63, 6b2c <fwp_drop10+0x15c>
    6a80:	91188273 	add	x19, x19, #0x620
    6a84:	f949da61 	ldr	x1, [x19, #5040]
    6a88:	f949ee62 	ldr	x2, [x19, #5080]
    6a8c:	cb010001 	sub	x1, x0, x1
    6a90:	eb02403f 	cmp	x1, x2, lsl #16
    6a94:	54fffea2 	b.cs	6a68 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a98:	d350fc22 	lsr	x2, x1, #16
    6a9c:	8b020842 	add	x2, x2, x2, lsl #2
    6aa0:	d37df042 	lsl	x2, x2, #3
    6aa4:	8b020065 	add	x5, x3, x2
    6aa8:	f94010a4 	ldr	x4, [x5, #32]
    6aac:	b4fffde4 	cbz	x4, 6a68 <fwp_drop10+0x98>
    6ab0:	38626862 	ldrb	w2, [x3, x2]
    6ab4:	7100085f 	cmp	w2, #0x2
    6ab8:	54000220 	b.eq	6afc <fwp_drop10+0x12c>  // b.none
    6abc:	7100045f 	cmp	w2, #0x1
    6ac0:	54fffd41 	b.ne	6a68 <fwp_drop10+0x98>  // b.any
    6ac4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ac8:	92403c21 	and	x1, x1, #0xffff
    6acc:	9b037c21 	mul	x1, x1, x3
    6ad0:	d360fc21 	lsr	x1, x1, #32
    6ad4:	eb02003f 	cmp	x1, x2
    6ad8:	54fffc82 	b.cs	6a68 <fwp_drop10+0x98>  // b.hs, b.nlast
    6adc:	8b010084 	add	x4, x4, x1
    6ae0:	39400081 	ldrb	w1, [x4]
    6ae4:	7100043f 	cmp	w1, #0x1
    6ae8:	54fffc01 	b.ne	6a68 <fwp_drop10+0x98>  // b.any
    6aec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6af0:	f94013f5 	ldr	x21, [sp, #32]
    6af4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6af8:	17fff866 	b	4c90 <fwp_mem_free>
    6afc:	72003c3f 	tst	w1, #0xffff
    6b00:	54ffff00 	b.eq	6ae0 <fwp_drop10+0x110>  // b.none
    6b04:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b08:	f94013f5 	ldr	x21, [sp, #32]
    6b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b10:	d65f03c0 	ret
    6b14:	72003c3f 	tst	w1, #0xffff
    6b18:	54fff980 	b.eq	6a48 <fwp_drop10+0x78>  // b.none
    6b1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b20:	f94013f5 	ldr	x21, [sp, #32]
    6b24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b28:	d65f03c0 	ret
    6b2c:	f9400414 	ldr	x20, [x0, #8]
    6b30:	97fffb51 	bl	5874 <fwp_rc_free_arr>
    6b34:	91188260 	add	x0, x19, #0x620
    6b38:	f949d801 	ldr	x1, [x0, #5040]
    6b3c:	f949ec00 	ldr	x0, [x0, #5080]
    6b40:	cb010281 	sub	x1, x20, x1
    6b44:	eb00403f 	cmp	x1, x0, lsl #16
    6b48:	54fff902 	b.cs	6a68 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b4c:	aa1403e0 	mov	x0, x20
    6b50:	17ffffab 	b	69fc <fwp_drop10+0x2c>
    6b54:	ca544680 	eor	x0, x20, x20, lsr #17
    6b58:	91188273 	add	x19, x19, #0x620
    6b5c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b60:	8b200e60 	add	x0, x19, w0, uxtb #3
    6b64:	f94a2400 	ldr	x0, [x0, #5192]
    6b68:	b5000080 	cbnz	x0, 6b78 <fwp_drop10+0x1a8>
    6b6c:	14000010 	b	6bac <fwp_drop10+0x1dc>
    6b70:	f9400800 	ldr	x0, [x0, #16]
    6b74:	b40001c0 	cbz	x0, 6bac <fwp_drop10+0x1dc>
    6b78:	f9400001 	ldr	x1, [x0]
    6b7c:	eb14003f 	cmp	x1, x20
    6b80:	54ffff81 	b.ne	6b70 <fwp_drop10+0x1a0>  // b.any
    6b84:	f9400401 	ldr	x1, [x0, #8]
    6b88:	d1000421 	sub	x1, x1, #0x1
    6b8c:	f9000401 	str	x1, [x0, #8]
    6b90:	f103f83f 	cmp	x1, #0xfe
    6b94:	54fff6a1 	b.ne	6a68 <fwp_drop10+0x98>  // b.any
    6b98:	aa1403e0 	mov	x0, x20
    6b9c:	97fff79d 	bl	4a10 <fwp_rc_forget_slot>
    6ba0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6ba4:	39000280 	strb	w0, [x20]
    6ba8:	17ffffb0 	b	6a68 <fwp_drop10+0x98>
    6bac:	f0000000 	adrp	x0, 9000 <__divti3+0x100>
    6bb0:	912b8000 	add	x0, x0, #0xae0
    6bb4:	97fff313 	bl	3800 <fwp_trap>
    6bb8:	d503201f 	nop
    6bbc:	d503201f 	nop

0000000000006bc0 <fwp_caps173>:
    6bc0:	34000041 	cbz	w1, 6bc8 <fwp_caps173+0x8>
    6bc4:	d65f03c0 	ret
    6bc8:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    6bcc:	91188063 	add	x3, x3, #0x620
    6bd0:	f949d861 	ldr	x1, [x3, #5040]
    6bd4:	f949ec62 	ldr	x2, [x3, #5080]
    6bd8:	cb010001 	sub	x1, x0, x1
    6bdc:	eb02403f 	cmp	x1, x2, lsl #16
    6be0:	54ffff22 	b.cs	6bc4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6be4:	d350fc22 	lsr	x2, x1, #16
    6be8:	f949fc65 	ldr	x5, [x3, #5112]
    6bec:	8b020842 	add	x2, x2, x2, lsl #2
    6bf0:	d37df042 	lsl	x2, x2, #3
    6bf4:	8b0200a4 	add	x4, x5, x2
    6bf8:	f9401083 	ldr	x3, [x4, #32]
    6bfc:	b4fffe43 	cbz	x3, 6bc4 <fwp_caps173+0x4>
    6c00:	386268a2 	ldrb	w2, [x5, x2]
    6c04:	7100085f 	cmp	w2, #0x2
    6c08:	540001c0 	b.eq	6c40 <fwp_caps173+0x80>  // b.none
    6c0c:	7100045f 	cmp	w2, #0x1
    6c10:	54fffda1 	b.ne	6bc4 <fwp_caps173+0x4>  // b.any
    6c14:	29430885 	ldp	w5, w2, [x4, #24]
    6c18:	92403c21 	and	x1, x1, #0xffff
    6c1c:	9b057c21 	mul	x1, x1, x5
    6c20:	d360fc21 	lsr	x1, x1, #32
    6c24:	eb02003f 	cmp	x1, x2
    6c28:	54fffce2 	b.cs	6bc4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c2c:	8b010063 	add	x3, x3, x1
    6c30:	39400061 	ldrb	w1, [x3]
    6c34:	7100043f 	cmp	w1, #0x1
    6c38:	54fffc61 	b.ne	6bc4 <fwp_caps173+0x4>  // b.any
    6c3c:	17fff815 	b	4c90 <fwp_mem_free>
    6c40:	72003c3f 	tst	w1, #0xffff
    6c44:	54ffff60 	b.eq	6c30 <fwp_caps173+0x70>  // b.none
    6c48:	d65f03c0 	ret
    6c4c:	d503201f 	nop

0000000000006c50 <f37>:
    6c50:	d10203ff 	sub	sp, sp, #0x80
    6c54:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6c58:	f947f421 	ldr	x1, [x1, #4072]
    6c5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6c60:	910083fd 	add	x29, sp, #0x20
    6c64:	a9045bf5 	stp	x21, x22, [sp, #64]
    6c68:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    6c6c:	911882c3 	add	x3, x22, #0x620
    6c70:	a90353f3 	stp	x19, x20, [sp, #48]
    6c74:	a90563f7 	stp	x23, x24, [sp, #80]
    6c78:	aa0003f8 	mov	x24, x0
    6c7c:	a9066bf9 	stp	x25, x26, [sp, #96]
    6c80:	f949ec62 	ldr	x2, [x3, #5080]
    6c84:	f9400024 	ldr	x4, [x1]
    6c88:	f9000fe4 	str	x4, [sp, #24]
    6c8c:	d2800004 	mov	x4, #0x0                   	// #0
    6c90:	f949d861 	ldr	x1, [x3, #5040]
    6c94:	d370bc42 	lsl	x2, x2, #16
    6c98:	b40018e0 	cbz	x0, 6fb4 <f37+0x364>
    6c9c:	f9400819 	ldr	x25, [x0, #16]
    6ca0:	cb010321 	sub	x1, x25, x1
    6ca4:	eb02003f 	cmp	x1, x2
    6ca8:	540003e2 	b.cs	6d24 <f37+0xd4>  // b.hs, b.nlast
    6cac:	f949fc60 	ldr	x0, [x3, #5112]
    6cb0:	d350fc22 	lsr	x2, x1, #16
    6cb4:	8b020842 	add	x2, x2, x2, lsl #2
    6cb8:	8b020c02 	add	x2, x0, x2, lsl #3
    6cbc:	f9401040 	ldr	x0, [x2, #32]
    6cc0:	b4000320 	cbz	x0, 6d24 <f37+0xd4>
    6cc4:	39400043 	ldrb	w3, [x2]
    6cc8:	7100087f 	cmp	w3, #0x2
    6ccc:	54001660 	b.eq	6f98 <f37+0x348>  // b.none
    6cd0:	7100047f 	cmp	w3, #0x1
    6cd4:	54000241 	b.ne	6d1c <f37+0xcc>  // b.any
    6cd8:	29430843 	ldp	w3, w2, [x2, #24]
    6cdc:	92403c21 	and	x1, x1, #0xffff
    6ce0:	9b037c21 	mul	x1, x1, x3
    6ce4:	d360fc21 	lsr	x1, x1, #32
    6ce8:	eb02003f 	cmp	x1, x2
    6cec:	54000182 	b.cs	6d1c <f37+0xcc>  // b.hs, b.nlast
    6cf0:	8b010000 	add	x0, x0, x1
    6cf4:	39400001 	ldrb	w1, [x0]
    6cf8:	34000121 	cbz	w1, 6d1c <f37+0xcc>
    6cfc:	d00000c2 	adrp	x2, 20000 <__data_start>
    6d00:	91014042 	add	x2, x2, #0x50
    6d04:	b9413043 	ldr	w3, [x2, #304]
    6d08:	350014e3 	cbnz	w3, 6fa4 <f37+0x354>
    6d0c:	7103f43f 	cmp	w1, #0xfd
    6d10:	54001908 	b.hi	7030 <f37+0x3e0>  // b.pmore
    6d14:	11000421 	add	w1, w1, #0x1
    6d18:	39000001 	strb	w1, [x0]
    6d1c:	d2800000 	mov	x0, #0x0                   	// #0
    6d20:	b40000f8 	cbz	x24, 6d3c <f37+0xec>
    6d24:	aa1803e1 	mov	x1, x24
    6d28:	d2800000 	mov	x0, #0x0                   	// #0
    6d2c:	d503201f 	nop
    6d30:	f9400821 	ldr	x1, [x1, #16]
    6d34:	91000400 	add	x0, x0, #0x1
    6d38:	b5ffffc1 	cbnz	x1, 6d30 <f37+0xe0>
    6d3c:	b4001439 	cbz	x25, 6fc0 <f37+0x370>
    6d40:	aa1903e1 	mov	x1, x25
    6d44:	d2800002 	mov	x2, #0x0                   	// #0
    6d48:	f9400821 	ldr	x1, [x1, #16]
    6d4c:	91000442 	add	x2, x2, #0x1
    6d50:	b5ffffc1 	cbnz	x1, 6d48 <f37+0xf8>
    6d54:	eb00005f 	cmp	x2, x0
    6d58:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6d5c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    6d60:	eb01035f 	cmp	x26, x1
    6d64:	540016e8 	b.hi	7040 <f37+0x3f0>  // b.pmore
    6d68:	d37ffb53 	lsl	x19, x26, #1
    6d6c:	52800041 	mov	w1, #0x2                   	// #2
    6d70:	91000660 	add	x0, x19, #0x1
    6d74:	d37df000 	lsl	x0, x0, #3
    6d78:	97fff8e6 	bl	5110 <fwp_heap_alloc>
    6d7c:	aa0003f7 	mov	x23, x0
    6d80:	911882c1 	add	x1, x22, #0x620
    6d84:	aa0103e0 	mov	x0, x1
    6d88:	f90002f3 	str	x19, [x23]
    6d8c:	f949d821 	ldr	x1, [x1, #5040]
    6d90:	f949ec00 	ldr	x0, [x0, #5080]
    6d94:	cb0102e1 	sub	x1, x23, x1
    6d98:	eb00403f 	cmp	x1, x0, lsl #16
    6d9c:	54000342 	b.cs	6e04 <f37+0x1b4>  // b.hs, b.nlast
    6da0:	911882c2 	add	x2, x22, #0x620
    6da4:	d350fc20 	lsr	x0, x1, #16
    6da8:	8b000800 	add	x0, x0, x0, lsl #2
    6dac:	f949fc43 	ldr	x3, [x2, #5112]
    6db0:	d37df002 	lsl	x2, x0, #3
    6db4:	8b020060 	add	x0, x3, x2
    6db8:	f9401013 	ldr	x19, [x0, #32]
    6dbc:	b4000253 	cbz	x19, 6e04 <f37+0x1b4>
    6dc0:	38626862 	ldrb	w2, [x3, x2]
    6dc4:	7100085f 	cmp	w2, #0x2
    6dc8:	54000e20 	b.eq	6f8c <f37+0x33c>  // b.none
    6dcc:	7100045f 	cmp	w2, #0x1
    6dd0:	540001a1 	b.ne	6e04 <f37+0x1b4>  // b.any
    6dd4:	29430002 	ldp	w2, w0, [x0, #24]
    6dd8:	92403c21 	and	x1, x1, #0xffff
    6ddc:	9b027c21 	mul	x1, x1, x2
    6de0:	d360fc21 	lsr	x1, x1, #32
    6de4:	eb00003f 	cmp	x1, x0
    6de8:	540000e2 	b.cs	6e04 <f37+0x1b4>  // b.hs, b.nlast
    6dec:	8b010273 	add	x19, x19, x1
    6df0:	39400260 	ldrb	w0, [x19]
    6df4:	7103fc1f 	cmp	w0, #0xff
    6df8:	54001060 	b.eq	7004 <f37+0x3b4>  // b.none
    6dfc:	52800020 	mov	w0, #0x1                   	// #1
    6e00:	39000260 	strb	w0, [x19]
    6e04:	b400025a 	cbz	x26, 6e4c <f37+0x1fc>
    6e08:	8b1a12fa 	add	x26, x23, x26, lsl #4
    6e0c:	aa1703f3 	mov	x19, x23
    6e10:	aa1803f5 	mov	x21, x24
    6e14:	aa1903f4 	mov	x20, x25
    6e18:	f9400683 	ldr	x3, [x20, #8]
    6e1c:	f94006a2 	ldr	x2, [x21, #8]
    6e20:	f9400861 	ldr	x1, [x3, #16]
    6e24:	f9400840 	ldr	x0, [x2, #16]
    6e28:	fd400461 	ldr	d1, [x3, #8]
    6e2c:	fd400440 	ldr	d0, [x2, #8]
    6e30:	97fffa29 	bl	56d4 <w120>
    6e34:	f9000660 	str	x0, [x19, #8]
    6e38:	f8010e61 	str	x1, [x19, #16]!
    6e3c:	f9400a94 	ldr	x20, [x20, #16]
    6e40:	f9400ab5 	ldr	x21, [x21, #16]
    6e44:	eb13035f 	cmp	x26, x19
    6e48:	54fffe81 	b.ne	6e18 <f37+0x1c8>  // b.any
    6e4c:	aa1903e0 	mov	x0, x25
    6e50:	97fffd44 	bl	6360 <fwp_drop4>
    6e54:	aa1803e0 	mov	x0, x24
    6e58:	97fffd42 	bl	6360 <fwp_drop4>
    6e5c:	f94002f5 	ldr	x21, [x23]
    6e60:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6e64:	b4000275 	cbz	x21, 6eb0 <f37+0x260>
    6e68:	fd003be8 	str	d8, [sp, #112]
    6e6c:	2f00e408 	movi	d8, #0x0
    6e70:	910022f9 	add	x25, x23, #0x8
    6e74:	910042f8 	add	x24, x23, #0x10
    6e78:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    6e7c:	d2800013 	mov	x19, #0x0                   	// #0
    6e80:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    6e84:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6e88:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    6e8c:	aa0303e1 	mov	x1, x3
    6e90:	1e602908 	fadd	d8, d8, d0
    6e94:	91000a73 	add	x19, x19, #0x2
    6e98:	97fff95e 	bl	5410 <fwp_p_ad_push>
    6e9c:	aa0003f4 	mov	x20, x0
    6ea0:	eb1302bf 	cmp	x21, x19
    6ea4:	54fffee8 	b.hi	6e80 <f37+0x230>  // b.pmore
    6ea8:	9e660115 	fmov	x21, d8
    6eac:	fd403be8 	ldr	d8, [sp, #112]
    6eb0:	911882d6 	add	x22, x22, #0x620
    6eb4:	aa1703e0 	mov	x0, x23
    6eb8:	97fffec6 	bl	69d0 <fwp_drop10>
    6ebc:	a900d3f5 	stp	x21, x20, [sp, #8]
    6ec0:	910023e1 	add	x1, sp, #0x8
    6ec4:	52800000 	mov	w0, #0x0                   	// #0
    6ec8:	97fff8f3 	bl	5294 <fwp_data.part.0.constprop.0>
    6ecc:	f949dac1 	ldr	x1, [x22, #5040]
    6ed0:	aa0003f3 	mov	x19, x0
    6ed4:	f949eec0 	ldr	x0, [x22, #5080]
    6ed8:	cb010261 	sub	x1, x19, x1
    6edc:	eb00403f 	cmp	x1, x0, lsl #16
    6ee0:	54000322 	b.cs	6f44 <f37+0x2f4>  // b.hs, b.nlast
    6ee4:	d350fc22 	lsr	x2, x1, #16
    6ee8:	f949fec3 	ldr	x3, [x22, #5112]
    6eec:	8b020842 	add	x2, x2, x2, lsl #2
    6ef0:	d37df042 	lsl	x2, x2, #3
    6ef4:	8b020060 	add	x0, x3, x2
    6ef8:	f9401014 	ldr	x20, [x0, #32]
    6efc:	b4000254 	cbz	x20, 6f44 <f37+0x2f4>
    6f00:	38626862 	ldrb	w2, [x3, x2]
    6f04:	7100085f 	cmp	w2, #0x2
    6f08:	540003c0 	b.eq	6f80 <f37+0x330>  // b.none
    6f0c:	7100045f 	cmp	w2, #0x1
    6f10:	540001a1 	b.ne	6f44 <f37+0x2f4>  // b.any
    6f14:	29430002 	ldp	w2, w0, [x0, #24]
    6f18:	92403c21 	and	x1, x1, #0xffff
    6f1c:	9b027c21 	mul	x1, x1, x2
    6f20:	d360fc21 	lsr	x1, x1, #32
    6f24:	eb00003f 	cmp	x1, x0
    6f28:	540000e2 	b.cs	6f44 <f37+0x2f4>  // b.hs, b.nlast
    6f2c:	8b010294 	add	x20, x20, x1
    6f30:	39400280 	ldrb	w0, [x20]
    6f34:	7103fc1f 	cmp	w0, #0xff
    6f38:	54000600 	b.eq	6ff8 <f37+0x3a8>  // b.none
    6f3c:	52800020 	mov	w0, #0x1                   	// #1
    6f40:	39000280 	strb	w0, [x20]
    6f44:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6f48:	f947f400 	ldr	x0, [x0, #4072]
    6f4c:	f9400fe2 	ldr	x2, [sp, #24]
    6f50:	f9400001 	ldr	x1, [x0]
    6f54:	eb010042 	subs	x2, x2, x1
    6f58:	d2800001 	mov	x1, #0x0                   	// #0
    6f5c:	540007a1 	b.ne	7050 <f37+0x400>  // b.any
    6f60:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6f64:	aa1303e0 	mov	x0, x19
    6f68:	a94353f3 	ldp	x19, x20, [sp, #48]
    6f6c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6f70:	a94563f7 	ldp	x23, x24, [sp, #80]
    6f74:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6f78:	910203ff 	add	sp, sp, #0x80
    6f7c:	d65f03c0 	ret
    6f80:	72003c3f 	tst	w1, #0xffff
    6f84:	54fffe01 	b.ne	6f44 <f37+0x2f4>  // b.any
    6f88:	17ffffea 	b	6f30 <f37+0x2e0>
    6f8c:	72003c3f 	tst	w1, #0xffff
    6f90:	54fff3a1 	b.ne	6e04 <f37+0x1b4>  // b.any
    6f94:	17ffff97 	b	6df0 <f37+0x1a0>
    6f98:	72003c3f 	tst	w1, #0xffff
    6f9c:	54ffec01 	b.ne	6d1c <f37+0xcc>  // b.any
    6fa0:	17ffff55 	b	6cf4 <f37+0xa4>
    6fa4:	f940ac43 	ldr	x3, [x2, #344]
    6fa8:	91000463 	add	x3, x3, #0x1
    6fac:	f900ac43 	str	x3, [x2, #344]
    6fb0:	17ffff57 	b	6d0c <f37+0xbc>
    6fb4:	cb0103e1 	neg	x1, x1
    6fb8:	eb02003f 	cmp	x1, x2
    6fbc:	540002a3 	b.cc	7010 <f37+0x3c0>  // b.lo, b.ul, b.last
    6fc0:	52800041 	mov	w1, #0x2                   	// #2
    6fc4:	d2800100 	mov	x0, #0x8                   	// #8
    6fc8:	97fff852 	bl	5110 <fwp_heap_alloc>
    6fcc:	aa0003f7 	mov	x23, x0
    6fd0:	911882c0 	add	x0, x22, #0x620
    6fd4:	f90002ff 	str	xzr, [x23]
    6fd8:	f949d801 	ldr	x1, [x0, #5040]
    6fdc:	f949ec00 	ldr	x0, [x0, #5080]
    6fe0:	cb0102e1 	sub	x1, x23, x1
    6fe4:	eb00403f 	cmp	x1, x0, lsl #16
    6fe8:	54000282 	b.cs	7038 <f37+0x3e8>  // b.hs, b.nlast
    6fec:	d280001a 	mov	x26, #0x0                   	// #0
    6ff0:	d2800019 	mov	x25, #0x0                   	// #0
    6ff4:	17ffff6b 	b	6da0 <f37+0x150>
    6ff8:	aa1403e0 	mov	x0, x20
    6ffc:	97fff685 	bl	4a10 <fwp_rc_forget_slot>
    7000:	17ffffcf 	b	6f3c <f37+0x2ec>
    7004:	aa1303e0 	mov	x0, x19
    7008:	97fff682 	bl	4a10 <fwp_rc_forget_slot>
    700c:	17ffff7c 	b	6dfc <f37+0x1ac>
    7010:	f949fc62 	ldr	x2, [x3, #5112]
    7014:	d350fc20 	lsr	x0, x1, #16
    7018:	8b000800 	add	x0, x0, x0, lsl #2
    701c:	8b000c42 	add	x2, x2, x0, lsl #3
    7020:	f9401040 	ldr	x0, [x2, #32]
    7024:	b4fffce0 	cbz	x0, 6fc0 <f37+0x370>
    7028:	d2800019 	mov	x25, #0x0                   	// #0
    702c:	17ffff26 	b	6cc4 <f37+0x74>
    7030:	97fff631 	bl	48f4 <fwp_rc_wide_dup>
    7034:	17ffff3a 	b	6d1c <f37+0xcc>
    7038:	d2800019 	mov	x25, #0x0                   	// #0
    703c:	17ffff84 	b	6e4c <f37+0x1fc>
    7040:	d0000000 	adrp	x0, 9000 <__divti3+0x100>
    7044:	91308000 	add	x0, x0, #0xc20
    7048:	fd003be8 	str	d8, [sp, #112]
    704c:	97fff1ed 	bl	3800 <fwp_trap>
    7050:	fd003be8 	str	d8, [sp, #112]
    7054:	97ffee13 	bl	28a0 <__stack_chk_fail@plt>
    7058:	d503201f 	nop
    705c:	d503201f 	nop

0000000000007060 <fwp_owned_entry37>:
    7060:	f9400000 	ldr	x0, [x0]
    7064:	17fffefb 	b	6c50 <f37>
    7068:	d503201f 	nop
    706c:	d503201f 	nop

0000000000007070 <e37>:
    7070:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7074:	910003fd 	mov	x29, sp
    7078:	f9000bf3 	str	x19, [sp, #16]
    707c:	f9400013 	ldr	x19, [x0]
    7080:	aa1303e0 	mov	x0, x19
    7084:	97fff9d7 	bl	57e0 <fwp_rc_share>
    7088:	aa1303e0 	mov	x0, x19
    708c:	97fffef1 	bl	6c50 <f37>
    7090:	aa0003f3 	mov	x19, x0
    7094:	97fff9d3 	bl	57e0 <fwp_rc_share>
    7098:	aa1303e0 	mov	x0, x19
    709c:	f9400bf3 	ldr	x19, [sp, #16]
    70a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70a4:	d65f03c0 	ret
    70a8:	d503201f 	nop
    70ac:	d503201f 	nop

00000000000070b0 <fwp_args37>:
    70b0:	7100003f 	cmp	w1, #0x0
    70b4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    70b8:	54000041 	b.ne	70c0 <fwp_args37+0x10>  // b.any
    70bc:	d65f03c0 	ret
    70c0:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    70c4:	91188042 	add	x2, x2, #0x620
    70c8:	f9400001 	ldr	x1, [x0]
    70cc:	f949d843 	ldr	x3, [x2, #5040]
    70d0:	f949ec40 	ldr	x0, [x2, #5080]
    70d4:	cb030021 	sub	x1, x1, x3
    70d8:	eb00403f 	cmp	x1, x0, lsl #16
    70dc:	54ffff02 	b.cs	70bc <fwp_args37+0xc>  // b.hs, b.nlast
    70e0:	d350fc20 	lsr	x0, x1, #16
    70e4:	f949fc44 	ldr	x4, [x2, #5112]
    70e8:	8b000800 	add	x0, x0, x0, lsl #2
    70ec:	d37df002 	lsl	x2, x0, #3
    70f0:	8b020083 	add	x3, x4, x2
    70f4:	f9401060 	ldr	x0, [x3, #32]
    70f8:	b4fffe20 	cbz	x0, 70bc <fwp_args37+0xc>
    70fc:	38626882 	ldrb	w2, [x4, x2]
    7100:	7100085f 	cmp	w2, #0x2
    7104:	54000320 	b.eq	7168 <fwp_args37+0xb8>  // b.none
    7108:	7100045f 	cmp	w2, #0x1
    710c:	54fffd81 	b.ne	70bc <fwp_args37+0xc>  // b.any
    7110:	29430864 	ldp	w4, w2, [x3, #24]
    7114:	92403c21 	and	x1, x1, #0xffff
    7118:	9b047c21 	mul	x1, x1, x4
    711c:	d360fc21 	lsr	x1, x1, #32
    7120:	eb02003f 	cmp	x1, x2
    7124:	54fffcc2 	b.cs	70bc <fwp_args37+0xc>  // b.hs, b.nlast
    7128:	8b010000 	add	x0, x0, x1
    712c:	39400001 	ldrb	w1, [x0]
    7130:	34fffc61 	cbz	w1, 70bc <fwp_args37+0xc>
    7134:	b00000c2 	adrp	x2, 20000 <__data_start>
    7138:	91014042 	add	x2, x2, #0x50
    713c:	b9413043 	ldr	w3, [x2, #304]
    7140:	350000c3 	cbnz	w3, 7158 <fwp_args37+0xa8>
    7144:	7103f43f 	cmp	w1, #0xfd
    7148:	54000168 	b.hi	7174 <fwp_args37+0xc4>  // b.pmore
    714c:	11000421 	add	w1, w1, #0x1
    7150:	39000001 	strb	w1, [x0]
    7154:	d65f03c0 	ret
    7158:	f940ac43 	ldr	x3, [x2, #344]
    715c:	91000463 	add	x3, x3, #0x1
    7160:	f900ac43 	str	x3, [x2, #344]
    7164:	17fffff8 	b	7144 <fwp_args37+0x94>
    7168:	72003c3f 	tst	w1, #0xffff
    716c:	54fffe00 	b.eq	712c <fwp_args37+0x7c>  // b.none
    7170:	d65f03c0 	ret
    7174:	17fff5e0 	b	48f4 <fwp_rc_wide_dup>
    7178:	d503201f 	nop
    717c:	d503201f 	nop

0000000000007180 <fwp_caps37>:
    7180:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7184:	910003fd 	mov	x29, sp
    7188:	f9000bf3 	str	x19, [sp, #16]
    718c:	aa0003f3 	mov	x19, x0
    7190:	b9400400 	ldr	w0, [x0, #4]
    7194:	340004a0 	cbz	w0, 7228 <fwp_caps37+0xa8>
    7198:	f9400660 	ldr	x0, [x19, #8]
    719c:	350004e1 	cbnz	w1, 7238 <fwp_caps37+0xb8>
    71a0:	97fffc70 	bl	6360 <fwp_drop4>
    71a4:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    71a8:	91188042 	add	x2, x2, #0x620
    71ac:	f949d840 	ldr	x0, [x2, #5040]
    71b0:	f949ec41 	ldr	x1, [x2, #5080]
    71b4:	cb000260 	sub	x0, x19, x0
    71b8:	eb01401f 	cmp	x0, x1, lsl #16
    71bc:	54000382 	b.cs	722c <fwp_caps37+0xac>  // b.hs, b.nlast
    71c0:	d350fc01 	lsr	x1, x0, #16
    71c4:	f949fc44 	ldr	x4, [x2, #5112]
    71c8:	8b010821 	add	x1, x1, x1, lsl #2
    71cc:	d37df021 	lsl	x1, x1, #3
    71d0:	8b010083 	add	x3, x4, x1
    71d4:	f9401062 	ldr	x2, [x3, #32]
    71d8:	b40002a2 	cbz	x2, 722c <fwp_caps37+0xac>
    71dc:	38616881 	ldrb	w1, [x4, x1]
    71e0:	7100083f 	cmp	w1, #0x2
    71e4:	54000740 	b.eq	72cc <fwp_caps37+0x14c>  // b.none
    71e8:	7100043f 	cmp	w1, #0x1
    71ec:	54000201 	b.ne	722c <fwp_caps37+0xac>  // b.any
    71f0:	29430464 	ldp	w4, w1, [x3, #24]
    71f4:	92403c00 	and	x0, x0, #0xffff
    71f8:	9b047c00 	mul	x0, x0, x4
    71fc:	d360fc00 	lsr	x0, x0, #32
    7200:	eb01001f 	cmp	x0, x1
    7204:	54000142 	b.cs	722c <fwp_caps37+0xac>  // b.hs, b.nlast
    7208:	8b000042 	add	x2, x2, x0
    720c:	39400040 	ldrb	w0, [x2]
    7210:	7100041f 	cmp	w0, #0x1
    7214:	540000c1 	b.ne	722c <fwp_caps37+0xac>  // b.any
    7218:	aa1303e0 	mov	x0, x19
    721c:	f9400bf3 	ldr	x19, [sp, #16]
    7220:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7224:	17fff69b 	b	4c90 <fwp_mem_free>
    7228:	34fffbe1 	cbz	w1, 71a4 <fwp_caps37+0x24>
    722c:	f9400bf3 	ldr	x19, [sp, #16]
    7230:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7234:	d65f03c0 	ret
    7238:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    723c:	91188042 	add	x2, x2, #0x620
    7240:	f949d843 	ldr	x3, [x2, #5040]
    7244:	f949ec41 	ldr	x1, [x2, #5080]
    7248:	cb030000 	sub	x0, x0, x3
    724c:	eb01401f 	cmp	x0, x1, lsl #16
    7250:	54fffee2 	b.cs	722c <fwp_caps37+0xac>  // b.hs, b.nlast
    7254:	d350fc01 	lsr	x1, x0, #16
    7258:	f949fc44 	ldr	x4, [x2, #5112]
    725c:	8b010821 	add	x1, x1, x1, lsl #2
    7260:	d37df021 	lsl	x1, x1, #3
    7264:	8b010083 	add	x3, x4, x1
    7268:	f9401062 	ldr	x2, [x3, #32]
    726c:	b4fffe02 	cbz	x2, 722c <fwp_caps37+0xac>
    7270:	38616881 	ldrb	w1, [x4, x1]
    7274:	7100083f 	cmp	w1, #0x2
    7278:	54000300 	b.eq	72d8 <fwp_caps37+0x158>  // b.none
    727c:	7100043f 	cmp	w1, #0x1
    7280:	54fffd61 	b.ne	722c <fwp_caps37+0xac>  // b.any
    7284:	92403c01 	and	x1, x0, #0xffff
    7288:	29430064 	ldp	w4, w0, [x3, #24]
    728c:	9b047c21 	mul	x1, x1, x4
    7290:	d360fc21 	lsr	x1, x1, #32
    7294:	eb00003f 	cmp	x1, x0
    7298:	54fffca2 	b.cs	722c <fwp_caps37+0xac>  // b.hs, b.nlast
    729c:	8b010042 	add	x2, x2, x1
    72a0:	39400040 	ldrb	w0, [x2]
    72a4:	34fffc40 	cbz	w0, 722c <fwp_caps37+0xac>
    72a8:	b00000c1 	adrp	x1, 20000 <__data_start>
    72ac:	91014021 	add	x1, x1, #0x50
    72b0:	b9413023 	ldr	w3, [x1, #304]
    72b4:	35000183 	cbnz	w3, 72e4 <fwp_caps37+0x164>
    72b8:	7103f41f 	cmp	w0, #0xfd
    72bc:	540001c8 	b.hi	72f4 <fwp_caps37+0x174>  // b.pmore
    72c0:	11000400 	add	w0, w0, #0x1
    72c4:	39000040 	strb	w0, [x2]
    72c8:	17ffffd9 	b	722c <fwp_caps37+0xac>
    72cc:	72003c1f 	tst	w0, #0xffff
    72d0:	54fffae1 	b.ne	722c <fwp_caps37+0xac>  // b.any
    72d4:	17ffffce 	b	720c <fwp_caps37+0x8c>
    72d8:	72003c1f 	tst	w0, #0xffff
    72dc:	54fffa81 	b.ne	722c <fwp_caps37+0xac>  // b.any
    72e0:	17fffff0 	b	72a0 <fwp_caps37+0x120>
    72e4:	f940ac23 	ldr	x3, [x1, #344]
    72e8:	91000463 	add	x3, x3, #0x1
    72ec:	f900ac23 	str	x3, [x1, #344]
    72f0:	17fffff2 	b	72b8 <fwp_caps37+0x138>
    72f4:	f9400bf3 	ldr	x19, [sp, #16]
    72f8:	aa0203e0 	mov	x0, x2
    72fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7300:	17fff57d 	b	48f4 <fwp_rc_wide_dup>

0000000000007304 <fwp_write>:
    7304:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7308:	910003fd 	mov	x29, sp
    730c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    7310:	f947f484 	ldr	x4, [x4, #4072]
    7314:	a90153f3 	stp	x19, x20, [sp, #16]
    7318:	d10943ff 	sub	sp, sp, #0x250
    731c:	b9400045 	ldr	w5, [x2]
    7320:	aa0003f4 	mov	x20, x0
    7324:	f9400080 	ldr	x0, [x4]
    7328:	f90127e0 	str	x0, [sp, #584]
    732c:	d2800000 	mov	x0, #0x0                   	// #0
    7330:	710064bf 	cmp	w5, #0x19
    7334:	54000408 	b.hi	73b4 <fwp_write+0xb0>  // b.pmore
    7338:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x9e0>
    733c:	aa0103f3 	mov	x19, x1
    7340:	91124000 	add	x0, x0, #0x490
    7344:	f9013bf5 	str	x21, [sp, #624]
    7348:	f9013ff6 	str	x22, [sp, #632]
    734c:	f90153fb 	str	x27, [sp, #672]
    7350:	f90157fc 	str	x28, [sp, #680]
    7354:	aa0203fc 	mov	x28, x2
    7358:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    735c:	10000061 	adr	x1, 7368 <fwp_write+0x64>
    7360:	8b20a820 	add	x0, x1, w0, sxth #2
    7364:	d61f0000 	br	x0
    7368:	910123e0 	add	x0, sp, #0x48
    736c:	aa1303e5 	mov	x5, x19
    7370:	d0000004 	adrp	x4, 9000 <__divti3+0x100>
    7374:	aa0003f3 	mov	x19, x0
    7378:	9131a084 	add	x4, x4, #0xc68
    737c:	d2804003 	mov	x3, #0x200                 	// #512
    7380:	aa0303e1 	mov	x1, x3
    7384:	52800042 	mov	w2, #0x2                   	// #2
    7388:	97ffed22 	bl	2810 <__snprintf_chk@plt>
    738c:	aa1303e0 	mov	x0, x19
    7390:	97ffece8 	bl	2730 <strlen@plt>
    7394:	aa1303e1 	mov	x1, x19
    7398:	aa0003e2 	mov	x2, x0
    739c:	aa1403e0 	mov	x0, x20
    73a0:	97fff0bc 	bl	3690 <buf_put>
    73a4:	f9413bf5 	ldr	x21, [sp, #624]
    73a8:	f9413ff6 	ldr	x22, [sp, #632]
    73ac:	f94153fb 	ldr	x27, [sp, #672]
    73b0:	f94157fc 	ldr	x28, [sp, #680]
    73b4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    73b8:	f947f400 	ldr	x0, [x0, #4072]
    73bc:	f94127e2 	ldr	x2, [sp, #584]
    73c0:	f9400001 	ldr	x1, [x0]
    73c4:	eb010042 	subs	x2, x2, x1
    73c8:	d2800001 	mov	x1, #0x0                   	// #0
    73cc:	540077a1 	b.ne	82c0 <fwp_write+0xfbc>  // b.any
    73d0:	910943ff 	add	sp, sp, #0x250
    73d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    73d8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    73dc:	d65f03c0 	ret
    73e0:	910123e0 	add	x0, sp, #0x48
    73e4:	aa1303e5 	mov	x5, x19
    73e8:	d0000004 	adrp	x4, 9000 <__divti3+0x100>
    73ec:	aa0003f3 	mov	x19, x0
    73f0:	91318084 	add	x4, x4, #0xc60
    73f4:	d2804003 	mov	x3, #0x200                 	// #512
    73f8:	17ffffe2 	b	7380 <fwp_write+0x7c>
    73fc:	71004cbf 	cmp	w5, #0x13
    7400:	d0000000 	adrp	x0, 9000 <__divti3+0x100>
    7404:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7408:	91314000 	add	x0, x0, #0xc50
    740c:	91316021 	add	x1, x1, #0xc58
    7410:	d2800082 	mov	x2, #0x4                   	// #4
    7414:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7418:	aa1403e0 	mov	x0, x20
    741c:	f90143f7 	str	x23, [sp, #640]
    7420:	d2800016 	mov	x22, #0x0                   	// #0
    7424:	f90147f8 	str	x24, [sp, #648]
    7428:	97fff09a 	bl	3690 <buf_put>
    742c:	f9400260 	ldr	x0, [x19]
    7430:	d0000017 	adrp	x23, 9000 <__divti3+0x100>
    7434:	d2800015 	mov	x21, #0x0                   	// #0
    7438:	913362f7 	add	x23, x23, #0xcd8
    743c:	b4004780 	cbz	x0, 7d2c <fwp_write+0xa28>
    7440:	b9400380 	ldr	w0, [x28]
    7444:	52800003 	mov	w3, #0x0                   	// #0
    7448:	f9401f82 	ldr	x2, [x28, #56]
    744c:	71004c1f 	cmp	w0, #0x13
    7450:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7454:	aa1403e0 	mov	x0, x20
    7458:	8b010e61 	add	x1, x19, x1, lsl #3
    745c:	f9400421 	ldr	x1, [x1, #8]
    7460:	97ffffa9 	bl	7304 <fwp_write>
    7464:	b9400380 	ldr	w0, [x28]
    7468:	7100481f 	cmp	w0, #0x12
    746c:	54004b20 	b.eq	7dd0 <fwp_write+0xacc>  // b.none
    7470:	f9400260 	ldr	x0, [x19]
    7474:	910006b5 	add	x21, x21, #0x1
    7478:	91000ad6 	add	x22, x22, #0x2
    747c:	eb15001f 	cmp	x0, x21
    7480:	54004569 	b.ls	7d2c <fwp_write+0xa28>  // b.plast
    7484:	aa1703e1 	mov	x1, x23
    7488:	aa1403e0 	mov	x0, x20
    748c:	d2800042 	mov	x2, #0x2                   	// #2
    7490:	97fff080 	bl	3690 <buf_put>
    7494:	17ffffeb 	b	7440 <fwp_write+0x13c>
    7498:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    749c:	91324021 	add	x1, x1, #0xc90
    74a0:	d28000c2 	mov	x2, #0x6                   	// #6
    74a4:	aa1403e0 	mov	x0, x20
    74a8:	91004273 	add	x19, x19, #0x10
    74ac:	97fff079 	bl	3690 <buf_put>
    74b0:	aa1303e0 	mov	x0, x19
    74b4:	97ffec9f 	bl	2730 <strlen@plt>
    74b8:	aa1303e1 	mov	x1, x19
    74bc:	aa0003e2 	mov	x2, x0
    74c0:	aa1403e0 	mov	x0, x20
    74c4:	97fff073 	bl	3690 <buf_put>
    74c8:	528007c3 	mov	w3, #0x3e                  	// #62
    74cc:	aa1403e0 	mov	x0, x20
    74d0:	91001fe1 	add	x1, sp, #0x7
    74d4:	d2800022 	mov	x2, #0x1                   	// #1
    74d8:	39001fe3 	strb	w3, [sp, #7]
    74dc:	17ffffb1 	b	73a0 <fwp_write+0x9c>
    74e0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    74e4:	f947f400 	ldr	x0, [x0, #4072]
    74e8:	f94127e2 	ldr	x2, [sp, #584]
    74ec:	f9400001 	ldr	x1, [x0]
    74f0:	eb010042 	subs	x2, x2, x1
    74f4:	d2800001 	mov	x1, #0x0                   	// #0
    74f8:	540034c1 	b.ne	7b90 <fwp_write+0x88c>  // b.any
    74fc:	f9413bf5 	ldr	x21, [sp, #624]
    7500:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7504:	f9413ff6 	ldr	x22, [sp, #632]
    7508:	aa1403e0 	mov	x0, x20
    750c:	9131c021 	add	x1, x1, #0xc70
    7510:	d2800142 	mov	x2, #0xa                   	// #10
    7514:	f94153fb 	ldr	x27, [sp, #672]
    7518:	f94157fc 	ldr	x28, [sp, #680]
    751c:	910943ff 	add	sp, sp, #0x250
    7520:	a94153f3 	ldp	x19, x20, [sp, #16]
    7524:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7528:	17fff05a 	b	3690 <buf_put>
    752c:	f9400456 	ldr	x22, [x2, #8]
    7530:	f90143f7 	str	x23, [sp, #640]
    7534:	f90147f8 	str	x24, [sp, #648]
    7538:	b4005af6 	cbz	x22, 8094 <fwp_write+0xd90>
    753c:	aa1603e0 	mov	x0, x22
    7540:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7544:	9133c021 	add	x1, x1, #0xcf0
    7548:	97ffecf6 	bl	2920 <strcmp@plt>
    754c:	2a0003f5 	mov	w21, w0
    7550:	34005fc0 	cbz	w0, 8148 <fwp_write+0xe44>
    7554:	aa1603e0 	mov	x0, x22
    7558:	97ffec76 	bl	2730 <strlen@plt>
    755c:	aa1603e1 	mov	x1, x22
    7560:	aa0003e2 	mov	x2, x0
    7564:	aa1403e0 	mov	x0, x20
    7568:	97fff04a 	bl	3690 <buf_put>
    756c:	52800403 	mov	w3, #0x20                  	// #32
    7570:	91001ff5 	add	x21, sp, #0x7
    7574:	aa1503e1 	mov	x1, x21
    7578:	aa1403e0 	mov	x0, x20
    757c:	d2800022 	mov	x2, #0x1                   	// #1
    7580:	39001fe3 	strb	w3, [sp, #7]
    7584:	97fff043 	bl	3690 <buf_put>
    7588:	52800f63 	mov	w3, #0x7b                  	// #123
    758c:	aa1403e0 	mov	x0, x20
    7590:	aa1503e1 	mov	x1, x21
    7594:	d2800022 	mov	x2, #0x1                   	// #1
    7598:	39001fe3 	strb	w3, [sp, #7]
    759c:	97fff03d 	bl	3690 <buf_put>
    75a0:	b9401380 	ldr	w0, [x28, #16]
    75a4:	52800018 	mov	w24, #0x0                   	// #0
    75a8:	7100001f 	cmp	w0, #0x0
    75ac:	54003a8d 	b.le	7cfc <fwp_write+0x9f8>
    75b0:	f9014bf9 	str	x25, [sp, #656]
    75b4:	d0000019 	adrp	x25, 9000 <__divti3+0x100>
    75b8:	91346339 	add	x25, x25, #0xd18
    75bc:	f9014ffa 	str	x26, [sp, #664]
    75c0:	d000001a 	adrp	x26, 9000 <__divti3+0x100>
    75c4:	9133635a 	add	x26, x26, #0xcd8
    75c8:	91002276 	add	x22, x19, #0x8
    75cc:	d2800013 	mov	x19, #0x0                   	// #0
    75d0:	b5003e73 	cbnz	x19, 7d9c <fwp_write+0xa98>
    75d4:	d37df277 	lsl	x23, x19, #3
    75d8:	34003c98 	cbz	w24, 7d68 <fwp_write+0xa64>
    75dc:	f9401382 	ldr	x2, [x28, #32]
    75e0:	aa1403e0 	mov	x0, x20
    75e4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    75e8:	52800003 	mov	w3, #0x0                   	// #0
    75ec:	f8776842 	ldr	x2, [x2, x23]
    75f0:	91000673 	add	x19, x19, #0x1
    75f4:	97ffff44 	bl	7304 <fwp_write>
    75f8:	b9401380 	ldr	w0, [x28, #16]
    75fc:	6b13001f 	cmp	w0, w19
    7600:	54fffe8c 	b.gt	75d0 <fwp_write+0x2cc>
    7604:	f9414bf9 	ldr	x25, [sp, #656]
    7608:	f9414ffa 	ldr	x26, [sp, #664]
    760c:	34003798 	cbz	w24, 7cfc <fwp_write+0x9f8>
    7610:	52800523 	mov	w3, #0x29                  	// #41
    7614:	aa1503e1 	mov	x1, x21
    7618:	aa1403e0 	mov	x0, x20
    761c:	d2800022 	mov	x2, #0x1                   	// #1
    7620:	39001fe3 	strb	w3, [sp, #7]
    7624:	97fff01b 	bl	3690 <buf_put>
    7628:	f9413bf5 	ldr	x21, [sp, #624]
    762c:	f9413ff6 	ldr	x22, [sp, #632]
    7630:	f94143f7 	ldr	x23, [sp, #640]
    7634:	f94147f8 	ldr	x24, [sp, #648]
    7638:	f94153fb 	ldr	x27, [sp, #672]
    763c:	f94157fc 	ldr	x28, [sp, #680]
    7640:	17ffff5d 	b	73b4 <fwp_write+0xb0>
    7644:	b9404855 	ldr	w21, [x2, #72]
    7648:	aa1403e0 	mov	x0, x20
    764c:	93407eb6 	sxtw	x22, w21
    7650:	91000ac1 	add	x1, x22, #0x2
    7654:	97ffefdb 	bl	35c0 <buf_grow>
    7658:	a9400281 	ldp	x1, x0, [x20]
    765c:	528e8603 	mov	w3, #0x7430                	// #29744
    7660:	78206823 	strh	w3, [x1, x0]
    7664:	8b000022 	add	x2, x1, x0
    7668:	710002bf 	cmp	w21, #0x0
    766c:	540036ad 	b.le	7d40 <fwp_write+0xa3c>
    7670:	110006a3 	add	w3, w21, #0x1
    7674:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7678:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    767c:	91000449 	add	x9, x2, #0x1
    7680:	8b23c043 	add	x3, x2, w3, sxtw
    7684:	f28aaac6 	movk	x6, #0x5556
    7688:	f2955568 	movk	x8, #0xaaab
    768c:	1400000d 	b	76c0 <fwp_write+0x3bc>
    7690:	d2800021 	mov	x1, #0x1                   	// #1
    7694:	528005a5 	mov	w5, #0x2d                  	// #45
    7698:	f100001f 	cmp	x0, #0x0
    769c:	9b467e60 	smulh	x0, x19, x6
    76a0:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    76a4:	381ff465 	strb	w5, [x3], #-1
    76a8:	cb040000 	sub	x0, x0, x4
    76ac:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    76b0:	cb020000 	sub	x0, x0, x2
    76b4:	8b010013 	add	x19, x0, x1
    76b8:	eb03013f 	cmp	x9, x3
    76bc:	54003420 	b.eq	7d40 <fwp_write+0xa3c>  // b.none
    76c0:	9b467e60 	smulh	x0, x19, x6
    76c4:	937ffe64 	asr	x4, x19, #63
    76c8:	52800605 	mov	w5, #0x30                  	// #48
    76cc:	cb040000 	sub	x0, x0, x4
    76d0:	8b000400 	add	x0, x0, x0, lsl #1
    76d4:	cb000260 	sub	x0, x19, x0
    76d8:	91000c01 	add	x1, x0, #0x3
    76dc:	9bc87c22 	umulh	x2, x1, x8
    76e0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    76e4:	8b4204e2 	add	x2, x7, x2, lsr #1
    76e8:	eb020021 	subs	x1, x1, x2
    76ec:	54fffd60 	b.eq	7698 <fwp_write+0x394>  // b.none
    76f0:	f100043f 	cmp	x1, #0x1
    76f4:	54fffce1 	b.ne	7690 <fwp_write+0x38c>  // b.any
    76f8:	d2800001 	mov	x1, #0x0                   	// #0
    76fc:	52800565 	mov	w5, #0x2b                  	// #43
    7700:	17ffffe6 	b	7698 <fwp_write+0x394>
    7704:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7708:	f947f400 	ldr	x0, [x0, #4072]
    770c:	f94127e2 	ldr	x2, [sp, #584]
    7710:	f9400001 	ldr	x1, [x0]
    7714:	eb010042 	subs	x2, x2, x1
    7718:	d2800001 	mov	x1, #0x0                   	// #0
    771c:	540023a1 	b.ne	7b90 <fwp_write+0x88c>  // b.any
    7720:	f9413bf5 	ldr	x21, [sp, #624]
    7724:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7728:	f9413ff6 	ldr	x22, [sp, #632]
    772c:	aa1403e0 	mov	x0, x20
    7730:	91320021 	add	x1, x1, #0xc80
    7734:	d2800102 	mov	x2, #0x8                   	// #8
    7738:	17ffff77 	b	7514 <fwp_write+0x210>
    773c:	aa1403e0 	mov	x0, x20
    7740:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7744:	d28000c2 	mov	x2, #0x6                   	// #6
    7748:	91338021 	add	x1, x1, #0xce0
    774c:	97ffefd1 	bl	3690 <buf_put>
    7750:	d2800015 	mov	x21, #0x0                   	// #0
    7754:	f9400263 	ldr	x3, [x19]
    7758:	f240f87f 	tst	x3, #0x7fffffffffffffff
    775c:	54002c40 	b.eq	7ce4 <fwp_write+0x9e0>  // b.none
    7760:	f9401f82 	ldr	x2, [x28, #56]
    7764:	f90143f7 	str	x23, [sp, #640]
    7768:	f90147f8 	str	x24, [sp, #648]
    776c:	d2800857 	mov	x23, #0x42                  	// #66
    7770:	f9014bf9 	str	x25, [sp, #656]
    7774:	d0000016 	adrp	x22, 9000 <__divti3+0x100>
    7778:	f9014ffa 	str	x26, [sp, #664]
    777c:	913362d6 	add	x22, x22, #0xcd8
    7780:	d2800038 	mov	x24, #0x1                   	// #1
    7784:	f2a18017 	movk	x23, #0xc00, lsl #16
    7788:	d2809099 	mov	x25, #0x484                 	// #1156
    778c:	b4000482 	cbz	x2, 781c <fwp_write+0x518>
    7790:	b9400040 	ldr	w0, [x2]
    7794:	7100701f 	cmp	w0, #0x1c
    7798:	540042a0 	b.eq	7fec <fwp_write+0xce8>  // b.none
    779c:	71006c1f 	cmp	w0, #0x1b
    77a0:	540003e8 	b.hi	781c <fwp_write+0x518>  // b.pmore
    77a4:	9ac02301 	lsl	x1, x24, x0
    77a8:	ea17003f 	tst	x1, x23
    77ac:	54003681 	b.ne	7e7c <fwp_write+0xb78>  // b.any
    77b0:	ea19003f 	tst	x1, x25
    77b4:	54003501 	b.ne	7e54 <fwp_write+0xb50>  // b.any
    77b8:	d2800424 	mov	x4, #0x21                  	// #33
    77bc:	ea04003f 	tst	x1, x4
    77c0:	540002e0 	b.eq	781c <fwp_write+0x518>  // b.none
    77c4:	b7f849a3 	tbnz	x3, #63, 80f8 <fwp_write+0xdf4>
    77c8:	91002261 	add	x1, x19, #0x8
    77cc:	8b150021 	add	x1, x1, x21
    77d0:	39400021 	ldrb	w1, [x1]
    77d4:	7100001f 	cmp	w0, #0x0
    77d8:	93401c23 	sxtb	x3, w1
    77dc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    77e0:	aa1403e0 	mov	x0, x20
    77e4:	52800003 	mov	w3, #0x0                   	// #0
    77e8:	97fffec7 	bl	7304 <fwp_write>
    77ec:	910006b5 	add	x21, x21, #0x1
    77f0:	f9400260 	ldr	x0, [x19]
    77f4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    77f8:	eb0002bf 	cmp	x21, x0
    77fc:	540026c2 	b.cs	7cd4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7800:	d2800042 	mov	x2, #0x2                   	// #2
    7804:	aa1603e1 	mov	x1, x22
    7808:	aa1403e0 	mov	x0, x20
    780c:	97ffefa1 	bl	3690 <buf_put>
    7810:	f9401f82 	ldr	x2, [x28, #56]
    7814:	f9400263 	ldr	x3, [x19]
    7818:	b5fffbc2 	cbnz	x2, 7790 <fwp_write+0x48c>
    781c:	d37df2a0 	lsl	x0, x21, #3
    7820:	b7f83f03 	tbnz	x3, #63, 8000 <fwp_write+0xcfc>
    7824:	91002261 	add	x1, x19, #0x8
    7828:	8b000020 	add	x0, x1, x0
    782c:	f9400001 	ldr	x1, [x0]
    7830:	17ffffec 	b	77e0 <fwp_write+0x4dc>
    7834:	a9400e62 	ldp	x2, x3, [x19]
    7838:	b7f83ca3 	tbnz	x3, #63, 7fcc <fwp_write+0xcc8>
    783c:	910123f5 	add	x21, sp, #0x48
    7840:	aa1503e0 	mov	x0, x21
    7844:	97ffed77 	bl	2e20 <fwp_fmt_u128>
    7848:	aa1503e0 	mov	x0, x21
    784c:	97ffebb9 	bl	2730 <strlen@plt>
    7850:	aa1503e1 	mov	x1, x21
    7854:	aa0003e2 	mov	x2, x0
    7858:	17fffed1 	b	739c <fwp_write+0x98>
    785c:	fd015be8 	str	d8, [sp, #688]
    7860:	1e270268 	fmov	s8, w19
    7864:	fd015fe9 	str	d9, [sp, #696]
    7868:	1e282100 	fcmp	s8, s8
    786c:	54004d26 	b.vs	8210 <fwp_write+0xf0c>
    7870:	1e20c101 	fabs	s1, s8
    7874:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7878:	1e270000 	fmov	s0, w0
    787c:	1e202020 	fcmp	s1, s0
    7880:	54002c0d 	b.le	7e00 <fwp_write+0xafc>
    7884:	1e202118 	fcmpe	s8, #0.0
    7888:	d0000002 	adrp	x2, 9000 <__divti3+0x100>
    788c:	911e6042 	add	x2, x2, #0x798
    7890:	910123f5 	add	x21, sp, #0x48
    7894:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7898:	9130c021 	add	x1, x1, #0xc30
    789c:	aa1503e0 	mov	x0, x21
    78a0:	9a81c041 	csel	x1, x2, x1, gt
    78a4:	97ffec4f 	bl	29e0 <strcpy@plt>
    78a8:	aa1503e0 	mov	x0, x21
    78ac:	97ffeba1 	bl	2730 <strlen@plt>
    78b0:	aa1503e1 	mov	x1, x21
    78b4:	aa0003e2 	mov	x2, x0
    78b8:	aa1403e0 	mov	x0, x20
    78bc:	97ffef75 	bl	3690 <buf_put>
    78c0:	f9413bf5 	ldr	x21, [sp, #624]
    78c4:	f9413ff6 	ldr	x22, [sp, #632]
    78c8:	f94153fb 	ldr	x27, [sp, #672]
    78cc:	f94157fc 	ldr	x28, [sp, #680]
    78d0:	fd415be8 	ldr	d8, [sp, #688]
    78d4:	fd415fe9 	ldr	d9, [sp, #696]
    78d8:	17fffeb7 	b	73b4 <fwp_write+0xb0>
    78dc:	f9400276 	ldr	x22, [x19]
    78e0:	34002e03 	cbz	w3, 7ea0 <fwp_write+0xb9c>
    78e4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    78e8:	f947f400 	ldr	x0, [x0, #4072]
    78ec:	f94127e2 	ldr	x2, [sp, #584]
    78f0:	f9400001 	ldr	x1, [x0]
    78f4:	eb010042 	subs	x2, x2, x1
    78f8:	d2800001 	mov	x1, #0x0                   	// #0
    78fc:	540014a1 	b.ne	7b90 <fwp_write+0x88c>  // b.any
    7900:	aa1603e2 	mov	x2, x22
    7904:	91002261 	add	x1, x19, #0x8
    7908:	f9413bf5 	ldr	x21, [sp, #624]
    790c:	aa1403e0 	mov	x0, x20
    7910:	f9413ff6 	ldr	x22, [sp, #632]
    7914:	17ffff00 	b	7514 <fwp_write+0x210>
    7918:	fd015be8 	str	d8, [sp, #688]
    791c:	9e670268 	fmov	d8, x19
    7920:	fd015fe9 	str	d9, [sp, #696]
    7924:	1e682100 	fcmp	d8, d8
    7928:	54004746 	b.vs	8210 <fwp_write+0xf0c>
    792c:	1e60c101 	fabs	d1, d8
    7930:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7934:	9e670000 	fmov	d0, x0
    7938:	910123f5 	add	x21, sp, #0x48
    793c:	52800033 	mov	w19, #0x1                   	// #1
    7940:	1e602020 	fcmp	d1, d0
    7944:	540001ad 	b.le	7978 <fwp_write+0x674>
    7948:	1e602118 	fcmpe	d8, #0.0
    794c:	d0000002 	adrp	x2, 9000 <__divti3+0x100>
    7950:	911e6042 	add	x2, x2, #0x798
    7954:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7958:	9130c021 	add	x1, x1, #0xc30
    795c:	aa1503e0 	mov	x0, x21
    7960:	9a81c041 	csel	x1, x2, x1, gt
    7964:	97ffec1f 	bl	29e0 <strcpy@plt>
    7968:	17ffffd0 	b	78a8 <fwp_write+0x5a4>
    796c:	11000673 	add	w19, w19, #0x1
    7970:	71004a7f 	cmp	w19, #0x12
    7974:	54003860 	b.eq	8080 <fwp_write+0xd7c>  // b.none
    7978:	1e604100 	fmov	d0, d8
    797c:	2a1303e1 	mov	w1, w19
    7980:	aa1503e0 	mov	x0, x21
    7984:	97fff084 	bl	3b94 <fwp_format_g.constprop.0>
    7988:	aa1503e0 	mov	x0, x21
    798c:	d2800001 	mov	x1, #0x0                   	// #0
    7990:	97ffeb7c 	bl	2780 <strtod@plt>
    7994:	1e602100 	fcmp	d8, d0
    7998:	54fffea1 	b.ne	796c <fwp_write+0x668>  // b.any
    799c:	aa1503e0 	mov	x0, x21
    79a0:	97ffef75 	bl	3774 <fwp_finish_float>
    79a4:	17ffffc1 	b	78a8 <fwp_write+0x5a4>
    79a8:	a9400e62 	ldp	x2, x3, [x19]
    79ac:	910123f3 	add	x19, sp, #0x48
    79b0:	aa1303e0 	mov	x0, x19
    79b4:	97ffed1b 	bl	2e20 <fwp_fmt_u128>
    79b8:	17fffe75 	b	738c <fwp_write+0x88>
    79bc:	f90143f7 	str	x23, [sp, #640]
    79c0:	f90147f8 	str	x24, [sp, #648]
    79c4:	2a1303f8 	mov	w24, w19
    79c8:	f9014bf9 	str	x25, [sp, #656]
    79cc:	f9014ffa 	str	x26, [sp, #664]
    79d0:	f13ffe7f 	cmp	x19, #0xfff
    79d4:	54000049 	b.ls	79dc <fwp_write+0x6d8>  // b.plast
    79d8:	b9400278 	ldr	w24, [x19]
    79dc:	f9400f80 	ldr	x0, [x28, #24]
    79e0:	2a1803f5 	mov	w21, w24
    79e4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    79e8:	d37ef6b9 	lsl	x25, x21, #2
    79ec:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    79f0:	aa1603e0 	mov	x0, x22
    79f4:	97ffeb4f 	bl	2730 <strlen@plt>
    79f8:	aa1603e1 	mov	x1, x22
    79fc:	aa0003e2 	mov	x2, x0
    7a00:	aa1403e0 	mov	x0, x20
    7a04:	97ffef23 	bl	3690 <buf_put>
    7a08:	f9401780 	ldr	x0, [x28, #40]
    7a0c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7a10:	7100001f 	cmp	w0, #0x0
    7a14:	5400068d 	b.le	7ae4 <fwp_write+0x7e0>
    7a18:	91002276 	add	x22, x19, #0x8
    7a1c:	91001ff5 	add	x21, sp, #0x7
    7a20:	d280001b 	mov	x27, #0x0                   	// #0
    7a24:	5280041a 	mov	w26, #0x20                  	// #32
    7a28:	f9401b80 	ldr	x0, [x28, #48]
    7a2c:	aa1503e1 	mov	x1, x21
    7a30:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7a34:	d2800022 	mov	x2, #0x1                   	// #1
    7a38:	f8786803 	ldr	x3, [x0, x24]
    7a3c:	aa1403e0 	mov	x0, x20
    7a40:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7a44:	39001ffa 	strb	w26, [sp, #7]
    7a48:	97ffef12 	bl	3690 <buf_put>
    7a4c:	f13ffeff 	cmp	x23, #0xfff
    7a50:	b9400261 	ldr	w1, [x19]
    7a54:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7a58:	7100383f 	cmp	w1, #0xe
    7a5c:	54000160 	b.eq	7a88 <fwp_write+0x784>  // b.none
    7a60:	7100403f 	cmp	w1, #0x10
    7a64:	54001a60 	b.eq	7db0 <fwp_write+0xaac>  // b.none
    7a68:	7100283f 	cmp	w1, #0xa
    7a6c:	54002aa0 	b.eq	7fc0 <fwp_write+0xcbc>  // b.none
    7a70:	540014ac 	b.gt	7d04 <fwp_write+0xa00>
    7a74:	71000c3f 	cmp	w1, #0x3
    7a78:	540029ac 	b.gt	7fac <fwp_write+0xca8>
    7a7c:	d37ffee0 	lsr	x0, x23, #63
    7a80:	37f814a1 	tbnz	w1, #31, 7d14 <fwp_write+0xa10>
    7a84:	d503201f 	nop
    7a88:	34001460 	cbz	w0, 7d14 <fwp_write+0xa10>
    7a8c:	52800503 	mov	w3, #0x28                  	// #40
    7a90:	aa1503e1 	mov	x1, x21
    7a94:	aa1403e0 	mov	x0, x20
    7a98:	d2800022 	mov	x2, #0x1                   	// #1
    7a9c:	39001fe3 	strb	w3, [sp, #7]
    7aa0:	97ffeefc 	bl	3690 <buf_put>
    7aa4:	aa1303e2 	mov	x2, x19
    7aa8:	aa1703e1 	mov	x1, x23
    7aac:	aa1403e0 	mov	x0, x20
    7ab0:	52800003 	mov	w3, #0x0                   	// #0
    7ab4:	97fffe14 	bl	7304 <fwp_write>
    7ab8:	52800523 	mov	w3, #0x29                  	// #41
    7abc:	aa1503e1 	mov	x1, x21
    7ac0:	aa1403e0 	mov	x0, x20
    7ac4:	d2800022 	mov	x2, #0x1                   	// #1
    7ac8:	39001fe3 	strb	w3, [sp, #7]
    7acc:	97ffeef1 	bl	3690 <buf_put>
    7ad0:	f9401780 	ldr	x0, [x28, #40]
    7ad4:	9100077b 	add	x27, x27, #0x1
    7ad8:	b8796800 	ldr	w0, [x0, x25]
    7adc:	6b1b001f 	cmp	w0, w27
    7ae0:	54fffa4c 	b.gt	7a28 <fwp_write+0x724>
    7ae4:	f9413bf5 	ldr	x21, [sp, #624]
    7ae8:	f9413ff6 	ldr	x22, [sp, #632]
    7aec:	f94143f7 	ldr	x23, [sp, #640]
    7af0:	f94147f8 	ldr	x24, [sp, #648]
    7af4:	f9414bf9 	ldr	x25, [sp, #656]
    7af8:	f9414ffa 	ldr	x26, [sp, #664]
    7afc:	f94153fb 	ldr	x27, [sp, #672]
    7b00:	f94157fc 	ldr	x28, [sp, #680]
    7b04:	17fffe2c 	b	73b4 <fwp_write+0xb0>
    7b08:	52800783 	mov	w3, #0x3c                  	// #60
    7b0c:	91001ff3 	add	x19, sp, #0x7
    7b10:	aa1303e1 	mov	x1, x19
    7b14:	d2800022 	mov	x2, #0x1                   	// #1
    7b18:	aa1403e0 	mov	x0, x20
    7b1c:	39001fe3 	strb	w3, [sp, #7]
    7b20:	97ffeedc 	bl	3690 <buf_put>
    7b24:	f9400795 	ldr	x21, [x28, #8]
    7b28:	aa1503e0 	mov	x0, x21
    7b2c:	97ffeb01 	bl	2730 <strlen@plt>
    7b30:	aa1503e1 	mov	x1, x21
    7b34:	aa0003e2 	mov	x2, x0
    7b38:	aa1403e0 	mov	x0, x20
    7b3c:	97ffeed5 	bl	3690 <buf_put>
    7b40:	528007c3 	mov	w3, #0x3e                  	// #62
    7b44:	aa1303e1 	mov	x1, x19
    7b48:	aa1403e0 	mov	x0, x20
    7b4c:	d2800022 	mov	x2, #0x1                   	// #1
    7b50:	39001fe3 	strb	w3, [sp, #7]
    7b54:	17fffe13 	b	73a0 <fwp_write+0x9c>
    7b58:	f100067f 	cmp	x19, #0x1
    7b5c:	540025a0 	b.eq	8010 <fwp_write+0xd0c>  // b.none
    7b60:	b100067f 	cmn	x19, #0x1
    7b64:	54002bc0 	b.eq	80dc <fwp_write+0xdd8>  // b.none
    7b68:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7b6c:	9130e021 	add	x1, x1, #0xc38
    7b70:	d2800022 	mov	x2, #0x1                   	// #1
    7b74:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7b78:	f947f400 	ldr	x0, [x0, #4072]
    7b7c:	f94127e4 	ldr	x4, [sp, #584]
    7b80:	f9400003 	ldr	x3, [x0]
    7b84:	eb030084 	subs	x4, x4, x3
    7b88:	d2800003 	mov	x3, #0x0                   	// #0
    7b8c:	54ffebe0 	b.eq	7908 <fwp_write+0x604>  // b.none
    7b90:	f90143f7 	str	x23, [sp, #640]
    7b94:	f90147f8 	str	x24, [sp, #648]
    7b98:	f9014bf9 	str	x25, [sp, #656]
    7b9c:	f9014ffa 	str	x26, [sp, #664]
    7ba0:	fd015be8 	str	d8, [sp, #688]
    7ba4:	fd015fe9 	str	d9, [sp, #696]
    7ba8:	97ffeb3e 	bl	28a0 <__stack_chk_fail@plt>
    7bac:	52800b63 	mov	w3, #0x5b                  	// #91
    7bb0:	91001ff5 	add	x21, sp, #0x7
    7bb4:	aa1503e1 	mov	x1, x21
    7bb8:	aa1403e0 	mov	x0, x20
    7bbc:	d2800022 	mov	x2, #0x1                   	// #1
    7bc0:	d0000016 	adrp	x22, 9000 <__divti3+0x100>
    7bc4:	913362d6 	add	x22, x22, #0xcd8
    7bc8:	39001fe3 	strb	w3, [sp, #7]
    7bcc:	97ffeeb1 	bl	3690 <buf_put>
    7bd0:	b4000273 	cbz	x19, 7c1c <fwp_write+0x918>
    7bd4:	f9400661 	ldr	x1, [x19, #8]
    7bd8:	aa1403e0 	mov	x0, x20
    7bdc:	f9401f82 	ldr	x2, [x28, #56]
    7be0:	52800003 	mov	w3, #0x0                   	// #0
    7be4:	97fffdc8 	bl	7304 <fwp_write>
    7be8:	f9400a73 	ldr	x19, [x19, #16]
    7bec:	b4000193 	cbz	x19, 7c1c <fwp_write+0x918>
    7bf0:	aa1603e1 	mov	x1, x22
    7bf4:	aa1403e0 	mov	x0, x20
    7bf8:	d2800042 	mov	x2, #0x2                   	// #2
    7bfc:	97ffeea5 	bl	3690 <buf_put>
    7c00:	f9400661 	ldr	x1, [x19, #8]
    7c04:	aa1403e0 	mov	x0, x20
    7c08:	f9401f82 	ldr	x2, [x28, #56]
    7c0c:	52800003 	mov	w3, #0x0                   	// #0
    7c10:	97fffdbd 	bl	7304 <fwp_write>
    7c14:	f9400a73 	ldr	x19, [x19, #16]
    7c18:	b5fffed3 	cbnz	x19, 7bf0 <fwp_write+0x8ec>
    7c1c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7c20:	aa1503e1 	mov	x1, x21
    7c24:	aa1403e0 	mov	x0, x20
    7c28:	d2800022 	mov	x2, #0x1                   	// #1
    7c2c:	39001fe3 	strb	w3, [sp, #7]
    7c30:	17fffddc 	b	73a0 <fwp_write+0x9c>
    7c34:	aa1403e0 	mov	x0, x20
    7c38:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7c3c:	d28000c2 	mov	x2, #0x6                   	// #6
    7c40:	91332021 	add	x1, x1, #0xcc8
    7c44:	97ffee93 	bl	3690 <buf_put>
    7c48:	f9400260 	ldr	x0, [x19]
    7c4c:	b40004c0 	cbz	x0, 7ce4 <fwp_write+0x9e0>
    7c50:	910123f5 	add	x21, sp, #0x48
    7c54:	91002276 	add	x22, x19, #0x8
    7c58:	f90143f7 	str	x23, [sp, #640]
    7c5c:	d2800017 	mov	x23, #0x0                   	// #0
    7c60:	f90147f8 	str	x24, [sp, #648]
    7c64:	d0000018 	adrp	x24, 9000 <__divti3+0x100>
    7c68:	91334318 	add	x24, x24, #0xcd0
    7c6c:	f9014bf9 	str	x25, [sp, #656]
    7c70:	d0000019 	adrp	x25, 9000 <__divti3+0x100>
    7c74:	91336339 	add	x25, x25, #0xcd8
    7c78:	f9014ffa 	str	x26, [sp, #664]
    7c7c:	14000005 	b	7c90 <fwp_write+0x98c>
    7c80:	aa1903e1 	mov	x1, x25
    7c84:	aa1403e0 	mov	x0, x20
    7c88:	d2800042 	mov	x2, #0x2                   	// #2
    7c8c:	97ffee81 	bl	3690 <buf_put>
    7c90:	38776ac5 	ldrb	w5, [x22, x23]
    7c94:	d2804003 	mov	x3, #0x200                 	// #512
    7c98:	aa1803e4 	mov	x4, x24
    7c9c:	aa0303e1 	mov	x1, x3
    7ca0:	52800042 	mov	w2, #0x2                   	// #2
    7ca4:	aa1503e0 	mov	x0, x21
    7ca8:	910006f7 	add	x23, x23, #0x1
    7cac:	97ffead9 	bl	2810 <__snprintf_chk@plt>
    7cb0:	aa1503e0 	mov	x0, x21
    7cb4:	97ffea9f 	bl	2730 <strlen@plt>
    7cb8:	aa1503e1 	mov	x1, x21
    7cbc:	aa0003e2 	mov	x2, x0
    7cc0:	aa1403e0 	mov	x0, x20
    7cc4:	97ffee73 	bl	3690 <buf_put>
    7cc8:	f9400260 	ldr	x0, [x19]
    7ccc:	eb17001f 	cmp	x0, x23
    7cd0:	54fffd88 	b.hi	7c80 <fwp_write+0x97c>  // b.pmore
    7cd4:	f94143f7 	ldr	x23, [sp, #640]
    7cd8:	f94147f8 	ldr	x24, [sp, #648]
    7cdc:	f9414bf9 	ldr	x25, [sp, #656]
    7ce0:	f9414ffa 	ldr	x26, [sp, #664]
    7ce4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ce8:	aa1403e0 	mov	x0, x20
    7cec:	91001fe1 	add	x1, sp, #0x7
    7cf0:	d2800022 	mov	x2, #0x1                   	// #1
    7cf4:	39001fe3 	strb	w3, [sp, #7]
    7cf8:	17fffdaa 	b	73a0 <fwp_write+0x9c>
    7cfc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7d00:	17fffe45 	b	7614 <fwp_write+0x310>
    7d04:	f10002ff 	cmp	x23, #0x0
    7d08:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7d0c:	71002c3f 	cmp	w1, #0xb
    7d10:	54ffebc0 	b.eq	7a88 <fwp_write+0x784>  // b.none
    7d14:	aa1303e2 	mov	x2, x19
    7d18:	aa1703e1 	mov	x1, x23
    7d1c:	aa1403e0 	mov	x0, x20
    7d20:	52800003 	mov	w3, #0x0                   	// #0
    7d24:	97fffd78 	bl	7304 <fwp_write>
    7d28:	17ffff6a 	b	7ad0 <fwp_write+0x7cc>
    7d2c:	aa1403e0 	mov	x0, x20
    7d30:	91001fe1 	add	x1, sp, #0x7
    7d34:	52800fa3 	mov	w3, #0x7d                  	// #125
    7d38:	d2800022 	mov	x2, #0x1                   	// #1
    7d3c:	17fffe39 	b	7620 <fwp_write+0x31c>
    7d40:	a9400281 	ldp	x1, x0, [x20]
    7d44:	91000800 	add	x0, x0, #0x2
    7d48:	8b160000 	add	x0, x0, x22
    7d4c:	f9000680 	str	x0, [x20, #8]
    7d50:	3820683f 	strb	wzr, [x1, x0]
    7d54:	f9413bf5 	ldr	x21, [sp, #624]
    7d58:	f9413ff6 	ldr	x22, [sp, #632]
    7d5c:	f94153fb 	ldr	x27, [sp, #672]
    7d60:	f94157fc 	ldr	x28, [sp, #680]
    7d64:	17fffd94 	b	73b4 <fwp_write+0xb0>
    7d68:	f9400f80 	ldr	x0, [x28, #24]
    7d6c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7d70:	aa1b03e0 	mov	x0, x27
    7d74:	97ffea6f 	bl	2730 <strlen@plt>
    7d78:	aa1b03e1 	mov	x1, x27
    7d7c:	aa0003e2 	mov	x2, x0
    7d80:	aa1403e0 	mov	x0, x20
    7d84:	97ffee43 	bl	3690 <buf_put>
    7d88:	aa1903e1 	mov	x1, x25
    7d8c:	aa1403e0 	mov	x0, x20
    7d90:	d2800062 	mov	x2, #0x3                   	// #3
    7d94:	97ffee3f 	bl	3690 <buf_put>
    7d98:	17fffe11 	b	75dc <fwp_write+0x2d8>
    7d9c:	aa1a03e1 	mov	x1, x26
    7da0:	aa1403e0 	mov	x0, x20
    7da4:	d2800042 	mov	x2, #0x2                   	// #2
    7da8:	97ffee3a 	bl	3690 <buf_put>
    7dac:	17fffe0a 	b	75d4 <fwp_write+0x2d0>
    7db0:	f9400660 	ldr	x0, [x19, #8]
    7db4:	b4fffb00 	cbz	x0, 7d14 <fwp_write+0xa10>
    7db8:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7dbc:	9133c021 	add	x1, x1, #0xcf0
    7dc0:	97ffead8 	bl	2920 <strcmp@plt>
    7dc4:	7100001f 	cmp	w0, #0x0
    7dc8:	1a9f07e0 	cset	w0, ne	// ne = any
    7dcc:	17ffff2f 	b	7a88 <fwp_write+0x784>
    7dd0:	aa1403e0 	mov	x0, x20
    7dd4:	d2800042 	mov	x2, #0x2                   	// #2
    7dd8:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7ddc:	9133a021 	add	x1, x1, #0xce8
    7de0:	97ffee2c 	bl	3690 <buf_put>
    7de4:	91004261 	add	x1, x19, #0x10
    7de8:	aa1403e0 	mov	x0, x20
    7dec:	f9402382 	ldr	x2, [x28, #64]
    7df0:	52800003 	mov	w3, #0x0                   	// #0
    7df4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7df8:	97fffd43 	bl	7304 <fwp_write>
    7dfc:	17fffd9d 	b	7470 <fwp_write+0x16c>
    7e00:	1e22c109 	fcvt	d9, s8
    7e04:	910123f5 	add	x21, sp, #0x48
    7e08:	52800033 	mov	w19, #0x1                   	// #1
    7e0c:	d503201f 	nop
    7e10:	1e604120 	fmov	d0, d9
    7e14:	2a1303e1 	mov	w1, w19
    7e18:	aa1503e0 	mov	x0, x21
    7e1c:	97ffef5e 	bl	3b94 <fwp_format_g.constprop.0>
    7e20:	aa1503e0 	mov	x0, x21
    7e24:	d2800001 	mov	x1, #0x0                   	// #0
    7e28:	97ffeaca 	bl	2950 <strtof@plt>
    7e2c:	1e202100 	fcmp	s8, s0
    7e30:	54ffdb60 	b.eq	799c <fwp_write+0x698>  // b.none
    7e34:	11000673 	add	w19, w19, #0x1
    7e38:	71002a7f 	cmp	w19, #0xa
    7e3c:	54fffea1 	b.ne	7e10 <fwp_write+0xb0c>  // b.any
    7e40:	1e604120 	fmov	d0, d9
    7e44:	aa1503e0 	mov	x0, x21
    7e48:	52800121 	mov	w1, #0x9                   	// #9
    7e4c:	97ffef52 	bl	3b94 <fwp_format_g.constprop.0>
    7e50:	17fffed3 	b	799c <fwp_write+0x698>
    7e54:	d37ef6a1 	lsl	x1, x21, #2
    7e58:	b7f81563 	tbnz	x3, #63, 8104 <fwp_write+0xe00>
    7e5c:	91002263 	add	x3, x19, #0x8
    7e60:	8b010061 	add	x1, x3, x1
    7e64:	b9400023 	ldr	w3, [x1]
    7e68:	7100081f 	cmp	w0, #0x2
    7e6c:	2a0303e1 	mov	w1, w3
    7e70:	93407c63 	sxtw	x3, w3
    7e74:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e78:	17fffe5a 	b	77e0 <fwp_write+0x4dc>
    7e7c:	d37ffaa1 	lsl	x1, x21, #1
    7e80:	b7f81363 	tbnz	x3, #63, 80ec <fwp_write+0xde8>
    7e84:	91002263 	add	x3, x19, #0x8
    7e88:	8b010061 	add	x1, x3, x1
    7e8c:	79400021 	ldrh	w1, [x1]
    7e90:	7100041f 	cmp	w0, #0x1
    7e94:	93403c23 	sxth	x3, w1
    7e98:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e9c:	17fffe51 	b	77e0 <fwp_write+0x4dc>
    7ea0:	52800443 	mov	w3, #0x22                  	// #34
    7ea4:	91001ff5 	add	x21, sp, #0x7
    7ea8:	91002273 	add	x19, x19, #0x8
    7eac:	aa1503e1 	mov	x1, x21
    7eb0:	aa1403e0 	mov	x0, x20
    7eb4:	d2800022 	mov	x2, #0x1                   	// #1
    7eb8:	39001fe3 	strb	w3, [sp, #7]
    7ebc:	f90143f7 	str	x23, [sp, #640]
    7ec0:	8b160277 	add	x23, x19, x22
    7ec4:	f90147f8 	str	x24, [sp, #648]
    7ec8:	97ffedf2 	bl	3690 <buf_put>
    7ecc:	b4000696 	cbz	x22, 7f9c <fwp_write+0xc98>
    7ed0:	d0000018 	adrp	x24, 9000 <__divti3+0x100>
    7ed4:	91326318 	add	x24, x24, #0xc98
    7ed8:	f9014bf9 	str	x25, [sp, #656]
    7edc:	d0000019 	adrp	x25, 9000 <__divti3+0x100>
    7ee0:	9132e339 	add	x25, x25, #0xcb8
    7ee4:	f9014ffa 	str	x26, [sp, #664]
    7ee8:	1400000d 	b	7f1c <fwp_write+0xc18>
    7eec:	710024bf 	cmp	w5, #0x9
    7ef0:	54000460 	b.eq	7f7c <fwp_write+0xc78>  // b.none
    7ef4:	710028bf 	cmp	w5, #0xa
    7ef8:	54000a61 	b.ne	8044 <fwp_write+0xd40>  // b.any
    7efc:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7f00:	aa1403e0 	mov	x0, x20
    7f04:	9132a021 	add	x1, x1, #0xca8
    7f08:	d2800042 	mov	x2, #0x2                   	// #2
    7f0c:	97ffede1 	bl	3690 <buf_put>
    7f10:	91000673 	add	x19, x19, #0x1
    7f14:	eb17027f 	cmp	x19, x23
    7f18:	540003e0 	b.eq	7f94 <fwp_write+0xc90>  // b.none
    7f1c:	39400265 	ldrb	w5, [x19]
    7f20:	710034bf 	cmp	w5, #0xd
    7f24:	54000180 	b.eq	7f54 <fwp_write+0xc50>  // b.none
    7f28:	54fffe29 	b.ls	7eec <fwp_write+0xbe8>  // b.plast
    7f2c:	710088bf 	cmp	w5, #0x22
    7f30:	540001c0 	b.eq	7f68 <fwp_write+0xc64>  // b.none
    7f34:	710170bf 	cmp	w5, #0x5c
    7f38:	54000741 	b.ne	8020 <fwp_write+0xd1c>  // b.any
    7f3c:	aa1403e0 	mov	x0, x20
    7f40:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7f44:	d2800042 	mov	x2, #0x2                   	// #2
    7f48:	91328021 	add	x1, x1, #0xca0
    7f4c:	97ffedd1 	bl	3690 <buf_put>
    7f50:	17fffff0 	b	7f10 <fwp_write+0xc0c>
    7f54:	aa1903e1 	mov	x1, x25
    7f58:	aa1403e0 	mov	x0, x20
    7f5c:	d2800042 	mov	x2, #0x2                   	// #2
    7f60:	97ffedcc 	bl	3690 <buf_put>
    7f64:	17ffffeb 	b	7f10 <fwp_write+0xc0c>
    7f68:	aa1803e1 	mov	x1, x24
    7f6c:	aa1403e0 	mov	x0, x20
    7f70:	d2800042 	mov	x2, #0x2                   	// #2
    7f74:	97ffedc7 	bl	3690 <buf_put>
    7f78:	17ffffe6 	b	7f10 <fwp_write+0xc0c>
    7f7c:	aa1403e0 	mov	x0, x20
    7f80:	d0000001 	adrp	x1, 9000 <__divti3+0x100>
    7f84:	d2800042 	mov	x2, #0x2                   	// #2
    7f88:	9132c021 	add	x1, x1, #0xcb0
    7f8c:	97ffedc1 	bl	3690 <buf_put>
    7f90:	17ffffe0 	b	7f10 <fwp_write+0xc0c>
    7f94:	f9414bf9 	ldr	x25, [sp, #656]
    7f98:	f9414ffa 	ldr	x26, [sp, #664]
    7f9c:	aa1503e1 	mov	x1, x21
    7fa0:	aa1403e0 	mov	x0, x20
    7fa4:	52800443 	mov	w3, #0x22                  	// #34
    7fa8:	17fffd9d 	b	761c <fwp_write+0x318>
    7fac:	7100103f 	cmp	w1, #0x4
    7fb0:	54ffeb21 	b.ne	7d14 <fwp_write+0xa10>  // b.any
    7fb4:	f94006e0 	ldr	x0, [x23, #8]
    7fb8:	d37ffc00 	lsr	x0, x0, #63
    7fbc:	17fffeb3 	b	7a88 <fwp_write+0x784>
    7fc0:	710002ff 	cmp	w23, #0x0
    7fc4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7fc8:	17fffeb0 	b	7a88 <fwp_write+0x784>
    7fcc:	528005a1 	mov	w1, #0x2d                  	// #45
    7fd0:	eb0203e2 	negs	x2, x2
    7fd4:	da0303e3 	ngc	x3, x3
    7fd8:	910127e0 	add	x0, sp, #0x49
    7fdc:	910123f5 	add	x21, sp, #0x48
    7fe0:	390123e1 	strb	w1, [sp, #72]
    7fe4:	97ffeb8f 	bl	2e20 <fwp_fmt_u128>
    7fe8:	17fffe18 	b	7848 <fwp_write+0x544>
    7fec:	d37ceea1 	lsl	x1, x21, #4
    7ff0:	b7f810a3 	tbnz	x3, #63, 8204 <fwp_write+0xf00>
    7ff4:	91002260 	add	x0, x19, #0x8
    7ff8:	8b010001 	add	x1, x0, x1
    7ffc:	17fffdf9 	b	77e0 <fwp_write+0x4dc>
    8000:	f9400a61 	ldr	x1, [x19, #16]
    8004:	8b010000 	add	x0, x0, x1
    8008:	f9400001 	ldr	x1, [x0]
    800c:	17fffdf5 	b	77e0 <fwp_write+0x4dc>
    8010:	b0000001 	adrp	x1, 9000 <__divti3+0x100>
    8014:	d2800042 	mov	x2, #0x2                   	// #2
    8018:	91310021 	add	x1, x1, #0xc40
    801c:	17fffed6 	b	7b74 <fwp_write+0x870>
    8020:	7101fcbf 	cmp	w5, #0x7f
    8024:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8028:	540000e9 	b.ls	8044 <fwp_write+0xd40>  // b.plast
    802c:	aa1503e1 	mov	x1, x21
    8030:	aa1403e0 	mov	x0, x20
    8034:	d2800022 	mov	x2, #0x1                   	// #1
    8038:	39001fe5 	strb	w5, [sp, #7]
    803c:	97ffed95 	bl	3690 <buf_put>
    8040:	17ffffb4 	b	7f10 <fwp_write+0xc0c>
    8044:	d2800203 	mov	x3, #0x10                  	// #16
    8048:	b0000004 	adrp	x4, 9000 <__divti3+0x100>
    804c:	aa0303e1 	mov	x1, x3
    8050:	91330084 	add	x4, x4, #0xcc0
    8054:	910123f6 	add	x22, sp, #0x48
    8058:	52800042 	mov	w2, #0x2                   	// #2
    805c:	aa1603e0 	mov	x0, x22
    8060:	97ffe9ec 	bl	2810 <__snprintf_chk@plt>
    8064:	aa1603e0 	mov	x0, x22
    8068:	97ffe9b2 	bl	2730 <strlen@plt>
    806c:	aa1603e1 	mov	x1, x22
    8070:	aa0003e2 	mov	x2, x0
    8074:	aa1403e0 	mov	x0, x20
    8078:	97ffed86 	bl	3690 <buf_put>
    807c:	17ffffa5 	b	7f10 <fwp_write+0xc0c>
    8080:	1e604100 	fmov	d0, d8
    8084:	aa1503e0 	mov	x0, x21
    8088:	52800221 	mov	w1, #0x11                  	// #17
    808c:	97ffeec2 	bl	3b94 <fwp_format_g.constprop.0>
    8090:	17fffe43 	b	799c <fwp_write+0x698>
    8094:	b9401040 	ldr	w0, [x2, #16]
    8098:	350003c0 	cbnz	w0, 8110 <fwp_write+0xe0c>
    809c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    80a0:	f947f400 	ldr	x0, [x0, #4072]
    80a4:	f94127e2 	ldr	x2, [sp, #584]
    80a8:	f9400001 	ldr	x1, [x0]
    80ac:	eb010042 	subs	x2, x2, x1
    80b0:	d2800001 	mov	x1, #0x0                   	// #0
    80b4:	54ffd721 	b.ne	7b98 <fwp_write+0x894>  // b.any
    80b8:	f9413bf5 	ldr	x21, [sp, #624]
    80bc:	b0000001 	adrp	x1, 9000 <__divti3+0x100>
    80c0:	f9413ff6 	ldr	x22, [sp, #632]
    80c4:	aa1403e0 	mov	x0, x20
    80c8:	f94143f7 	ldr	x23, [sp, #640]
    80cc:	91344021 	add	x1, x1, #0xd10
    80d0:	f94147f8 	ldr	x24, [sp, #648]
    80d4:	d2800042 	mov	x2, #0x2                   	// #2
    80d8:	17fffd0f 	b	7514 <fwp_write+0x210>
    80dc:	b0000001 	adrp	x1, 9000 <__divti3+0x100>
    80e0:	d2800042 	mov	x2, #0x2                   	// #2
    80e4:	91312021 	add	x1, x1, #0xc48
    80e8:	17fffea3 	b	7b74 <fwp_write+0x870>
    80ec:	f9400a63 	ldr	x3, [x19, #16]
    80f0:	8b030021 	add	x1, x1, x3
    80f4:	17ffff66 	b	7e8c <fwp_write+0xb88>
    80f8:	f9400a61 	ldr	x1, [x19, #16]
    80fc:	8b0102a1 	add	x1, x21, x1
    8100:	17fffdb4 	b	77d0 <fwp_write+0x4cc>
    8104:	f9400a63 	ldr	x3, [x19, #16]
    8108:	8b030021 	add	x1, x1, x3
    810c:	17ffff56 	b	7e64 <fwp_write+0xb60>
    8110:	b9404840 	ldr	w0, [x2, #72]
    8114:	91001ff5 	add	x21, sp, #0x7
    8118:	34ffa380 	cbz	w0, 7588 <fwp_write+0x284>
    811c:	52800503 	mov	w3, #0x28                  	// #40
    8120:	aa1403e0 	mov	x0, x20
    8124:	aa1503e1 	mov	x1, x21
    8128:	d2800022 	mov	x2, #0x1                   	// #1
    812c:	39001fe3 	strb	w3, [sp, #7]
    8130:	97ffed58 	bl	3690 <buf_put>
    8134:	b9401380 	ldr	w0, [x28, #16]
    8138:	52800038 	mov	w24, #0x1                   	// #1
    813c:	7100001f 	cmp	w0, #0x0
    8140:	54ffa38c 	b.gt	75b0 <fwp_write+0x2ac>
    8144:	17fffd33 	b	7610 <fwp_write+0x30c>
    8148:	f9014bf9 	str	x25, [sp, #656]
    814c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x12858>
    8150:	f9014ffa 	str	x26, [sp, #664]
    8154:	f9400676 	ldr	x22, [x19, #8]
    8158:	910ac333 	add	x19, x25, #0x2b0
    815c:	91002273 	add	x19, x19, #0x8
    8160:	937ffed8 	asr	x24, x22, #63
    8164:	aa1802c0 	orr	x0, x22, x24
    8168:	b5000320 	cbnz	x0, 81cc <fwp_write+0xec8>
    816c:	110006b5 	add	w21, w21, #0x1
    8170:	710016bf 	cmp	w21, #0x5
    8174:	54ffffc1 	b.ne	816c <fwp_write+0xe68>  // b.any
    8178:	b7f80578 	tbnz	x24, #63, 8224 <fwp_write+0xf20>
    817c:	910023f3 	add	x19, sp, #0x8
    8180:	aa1603e2 	mov	x2, x22
    8184:	aa1303e0 	mov	x0, x19
    8188:	d2800003 	mov	x3, #0x0                   	// #0
    818c:	97ffeb25 	bl	2e20 <fwp_fmt_u128>
    8190:	910123f5 	add	x21, sp, #0x48
    8194:	b0000003 	adrp	x3, 9000 <__divti3+0x100>
    8198:	aa1303e4 	mov	x4, x19
    819c:	aa1503e0 	mov	x0, x21
    81a0:	91342063 	add	x3, x3, #0xd08
    81a4:	d2804002 	mov	x2, #0x200                 	// #512
    81a8:	52800041 	mov	w1, #0x2                   	// #2
    81ac:	97ffe965 	bl	2740 <__sprintf_chk@plt>
    81b0:	aa1503e0 	mov	x0, x21
    81b4:	97ffe95f 	bl	2730 <strlen@plt>
    81b8:	aa1503e1 	mov	x1, x21
    81bc:	aa0003e2 	mov	x2, x0
    81c0:	aa1403e0 	mov	x0, x20
    81c4:	97ffed33 	bl	3690 <buf_put>
    81c8:	17fffe47 	b	7ae4 <fwp_write+0x7e0>
    81cc:	f9400277 	ldr	x23, [x19]
    81d0:	aa1603e0 	mov	x0, x22
    81d4:	aa1803e1 	mov	x1, x24
    81d8:	aa1703e2 	mov	x2, x23
    81dc:	937ffefa 	asr	x26, x23, #63
    81e0:	aa1a03e3 	mov	x3, x26
    81e4:	94000427 	bl	9280 <__modti3>
    81e8:	aa010000 	orr	x0, x0, x1
    81ec:	b40002c0 	cbz	x0, 8244 <fwp_write+0xf40>
    81f0:	110006b5 	add	w21, w21, #0x1
    81f4:	91004273 	add	x19, x19, #0x10
    81f8:	710016bf 	cmp	w21, #0x5
    81fc:	54fffe81 	b.ne	81cc <fwp_write+0xec8>  // b.any
    8200:	17ffffde 	b	8178 <fwp_write+0xe74>
    8204:	f9400a60 	ldr	x0, [x19, #16]
    8208:	8b000021 	add	x1, x1, x0
    820c:	17fffd75 	b	77e0 <fwp_write+0x4dc>
    8210:	528c29c0 	mov	w0, #0x614e                	// #24910
    8214:	910123f5 	add	x21, sp, #0x48
    8218:	72a009c0 	movk	w0, #0x4e, lsl #16
    821c:	b9004be0 	str	w0, [sp, #72]
    8220:	17fffda2 	b	78a8 <fwp_write+0x5a4>
    8224:	528005a1 	mov	w1, #0x2d                  	// #45
    8228:	eb1603e2 	negs	x2, x22
    822c:	da1803e3 	ngc	x3, x24
    8230:	910027e0 	add	x0, sp, #0x9
    8234:	910023f3 	add	x19, sp, #0x8
    8238:	390023e1 	strb	w1, [sp, #8]
    823c:	97ffeaf9 	bl	2e20 <fwp_fmt_u128>
    8240:	17ffffd4 	b	8190 <fwp_write+0xe8c>
    8244:	aa1703e2 	mov	x2, x23
    8248:	aa1a03e3 	mov	x3, x26
    824c:	aa1603e0 	mov	x0, x22
    8250:	aa1803e1 	mov	x1, x24
    8254:	9400032b 	bl	8f00 <__divti3>
    8258:	aa0003e2 	mov	x2, x0
    825c:	aa0103e3 	mov	x3, x1
    8260:	b7f80201 	tbnz	x1, #63, 82a0 <fwp_write+0xf9c>
    8264:	910023f3 	add	x19, sp, #0x8
    8268:	aa1303e0 	mov	x0, x19
    826c:	97ffeaed 	bl	2e20 <fwp_fmt_u128>
    8270:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8274:	910ac339 	add	x25, x25, #0x2b0
    8278:	910123f5 	add	x21, sp, #0x48
    827c:	aa1303e4 	mov	x4, x19
    8280:	aa1503e0 	mov	x0, x21
    8284:	b0000003 	adrp	x3, 9000 <__divti3+0x100>
    8288:	f8616b25 	ldr	x5, [x25, x1]
    828c:	91340063 	add	x3, x3, #0xd00
    8290:	d2804002 	mov	x2, #0x200                 	// #512
    8294:	52800041 	mov	w1, #0x2                   	// #2
    8298:	97ffe92a 	bl	2740 <__sprintf_chk@plt>
    829c:	17ffffc5 	b	81b0 <fwp_write+0xeac>
    82a0:	528005a4 	mov	w4, #0x2d                  	// #45
    82a4:	eb0003e2 	negs	x2, x0
    82a8:	da0103e3 	ngc	x3, x1
    82ac:	910027e0 	add	x0, sp, #0x9
    82b0:	910023f3 	add	x19, sp, #0x8
    82b4:	390023e4 	strb	w4, [sp, #8]
    82b8:	97ffeada 	bl	2e20 <fwp_fmt_u128>
    82bc:	17ffffed 	b	8270 <fwp_write+0xf6c>
    82c0:	f9013bf5 	str	x21, [sp, #624]
    82c4:	f9013ff6 	str	x22, [sp, #632]
    82c8:	f90143f7 	str	x23, [sp, #640]
    82cc:	f90147f8 	str	x24, [sp, #648]
    82d0:	f9014bf9 	str	x25, [sp, #656]
    82d4:	f9014ffa 	str	x26, [sp, #664]
    82d8:	f90153fb 	str	x27, [sp, #672]
    82dc:	f90157fc 	str	x28, [sp, #680]
    82e0:	fd015be8 	str	d8, [sp, #688]
    82e4:	fd015fe9 	str	d9, [sp, #696]
    82e8:	97ffe96e 	bl	28a0 <__stack_chk_fail@plt>
    82ec:	d503201f 	nop

00000000000082f0 <fwp_main_thread>:
    82f0:	d10603ff 	sub	sp, sp, #0x180
    82f4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    82f8:	f947f400 	ldr	x0, [x0, #4072]
    82fc:	a9127bfd 	stp	x29, x30, [sp, #288]
    8300:	910483fd 	add	x29, sp, #0x120
    8304:	a9145bf5 	stp	x21, x22, [sp, #320]
    8308:	b0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    830c:	911882a1 	add	x1, x21, #0x620
    8310:	a91353f3 	stp	x19, x20, [sp, #304]
    8314:	a91563f7 	stp	x23, x24, [sp, #336]
    8318:	b953a421 	ldr	w1, [x1, #5028]
    831c:	a9166bf9 	stp	x25, x26, [sp, #352]
    8320:	a91773fb 	stp	x27, x28, [sp, #368]
    8324:	f9400002 	ldr	x2, [x0]
    8328:	f9008fe2 	str	x2, [sp, #280]
    832c:	d2800002 	mov	x2, #0x0                   	// #0
    8330:	34002761 	cbz	w1, 881c <fwp_main_thread+0x52c>
    8334:	911882a0 	add	x0, x21, #0x620
    8338:	b953a800 	ldr	w0, [x0, #5032]
    833c:	35002780 	cbnz	w0, 882c <fwp_main_thread+0x53c>
    8340:	900000d4 	adrp	x20, 20000 <__data_start>
    8344:	900000c2 	adrp	x2, 20000 <__data_start>
    8348:	9101429a 	add	x26, x20, #0x50
    834c:	91110042 	add	x2, x2, #0x440
    8350:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    8354:	d2a00024 	mov	x4, #0x10000               	// #65536
    8358:	910103f7 	add	x23, sp, #0x40
    835c:	9100a3fb 	add	x27, sp, #0x28
    8360:	aa1703e0 	mov	x0, x23
    8364:	d2800001 	mov	x1, #0x0                   	// #0
    8368:	f90023e2 	str	x2, [sp, #64]
    836c:	b9004bff 	str	wzr, [sp, #72]
    8370:	f9002be4 	str	x4, [sp, #80]
    8374:	a90a0f5b 	stp	x27, x3, [x26, #160]
    8378:	97ffe8e2 	bl	2700 <sigaltstack@plt>
    837c:	35005a80 	cbnz	w0, 8ecc <fwp_main_thread+0xbdc>
    8380:	4f000400 	movi	v0.4s, #0x0
    8384:	910223e0 	add	x0, sp, #0x88
    8388:	f0ffffc1 	adrp	x1, 3000 <ad_raw_record+0x70>
    838c:	9102c021 	add	x1, x1, #0xb0
    8390:	f90043e1 	str	x1, [sp, #128]
    8394:	52800082 	mov	w2, #0x4                   	// #4
    8398:	72a10002 	movk	w2, #0x800, lsl #16
    839c:	910203f3 	add	x19, sp, #0x80
    83a0:	3d802000 	str	q0, [x0, #128]
    83a4:	b9010be2 	str	w2, [sp, #264]
    83a8:	ad000000 	stp	q0, q0, [x0]
    83ac:	ad010000 	stp	q0, q0, [x0, #32]
    83b0:	ad020000 	stp	q0, q0, [x0, #64]
    83b4:	ad030000 	stp	q0, q0, [x0, #96]
    83b8:	97ffe92a 	bl	2860 <sigemptyset@plt>
    83bc:	35005880 	cbnz	w0, 8ecc <fwp_main_thread+0xbdc>
    83c0:	aa1303e1 	mov	x1, x19
    83c4:	d2800002 	mov	x2, #0x0                   	// #0
    83c8:	52800160 	mov	w0, #0xb                   	// #11
    83cc:	97ffe93d 	bl	28c0 <sigaction@plt>
    83d0:	350057e0 	cbnz	w0, 8ecc <fwp_main_thread+0xbdc>
    83d4:	aa1303e1 	mov	x1, x19
    83d8:	d2800002 	mov	x2, #0x0                   	// #0
    83dc:	528000e0 	mov	w0, #0x7                   	// #7
    83e0:	97ffe938 	bl	28c0 <sigaction@plt>
    83e4:	35005740 	cbnz	w0, 8ecc <fwp_main_thread+0xbdc>
    83e8:	911882bc 	add	x28, x21, #0x620
    83ec:	52800036 	mov	w22, #0x1                   	// #1
    83f0:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    83f4:	910ec000 	add	x0, x0, #0x3b0
    83f8:	b9013356 	str	w22, [x26, #304]
    83fc:	fd4a1380 	ldr	d0, [x28, #5152]
    8400:	7e61d800 	ucvtf	d0, d0
    8404:	fd00a740 	str	d0, [x26, #328]
    8408:	9400047a 	bl	95f0 <atexit>
    840c:	35005680 	cbnz	w0, 8edc <fwp_main_thread+0xbec>
    8410:	b943c740 	ldr	w0, [x26, #964]
    8414:	34002140 	cbz	w0, 883c <fwp_main_thread+0x54c>
    8418:	9101429a 	add	x26, x20, #0x50
    841c:	f9404f56 	ldr	x22, [x26, #152]
    8420:	b4000c36 	cbz	x22, 85a4 <fwp_main_thread+0x2b4>
    8424:	aa1603f3 	mov	x19, x22
    8428:	910102d7 	add	x23, x22, #0x40
    842c:	39414ad9 	ldrb	w25, [x22, #82]
    8430:	52800038 	mov	w24, #0x1                   	// #1
    8434:	39014ad8 	strb	w24, [x22, #82]
    8438:	f94016c0 	ldr	x0, [x22, #40]
    843c:	b4000620 	cbz	x0, 8500 <fwp_main_thread+0x210>
    8440:	f94032c1 	ldr	x1, [x22, #96]
    8444:	394146c0 	ldrb	w0, [x22, #81]
    8448:	b4000c81 	cbz	x1, 85d8 <fwp_main_thread+0x2e8>
    844c:	36000b40 	tbz	w0, #0, 85b4 <fwp_main_thread+0x2c4>
    8450:	39414a62 	ldrb	w2, [x19, #82]
    8454:	f94022c0 	ldr	x0, [x22, #64]
    8458:	37000ea2 	tbnz	w2, #0, 862c <fwp_main_thread+0x33c>
    845c:	f9403261 	ldr	x1, [x19, #96]
    8460:	a911fe77 	stp	x23, xzr, [x19, #280]
    8464:	f9009660 	str	x0, [x19, #296]
    8468:	b4000040 	cbz	x0, 8470 <fwp_main_thread+0x180>
    846c:	f9009013 	str	x19, [x0, #288]
    8470:	f90022d3 	str	x19, [x22, #64]
    8474:	b4000101 	cbz	x1, 8494 <fwp_main_thread+0x1a4>
    8478:	f9409740 	ldr	x0, [x26, #296]
    847c:	39015678 	strb	w24, [x19, #85]
    8480:	f9003661 	str	x1, [x19, #104]
    8484:	a910827f 	stp	xzr, x0, [x19, #264]
    8488:	b4000040 	cbz	x0, 8490 <fwp_main_thread+0x1a0>
    848c:	f9008413 	str	x19, [x0, #264]
    8490:	f9009753 	str	x19, [x26, #296]
    8494:	39015a7f 	strb	wzr, [x19, #86]
    8498:	97fff8f7 	bl	6874 <fwp_block>
    849c:	f9408e62 	ldr	x2, [x19, #280]
    84a0:	b4000142 	cbz	x2, 84c8 <fwp_main_thread+0x1d8>
    84a4:	a9520261 	ldp	x1, x0, [x19, #288]
    84a8:	b4000ce1 	cbz	x1, 8644 <fwp_main_thread+0x354>
    84ac:	f9009420 	str	x0, [x1, #296]
    84b0:	f9409660 	ldr	x0, [x19, #296]
    84b4:	b4000040 	cbz	x0, 84bc <fwp_main_thread+0x1cc>
    84b8:	f9009001 	str	x1, [x0, #288]
    84bc:	91080260 	add	x0, x19, #0x200
    84c0:	f900967f 	str	xzr, [x19, #296]
    84c4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    84c8:	39415660 	ldrb	w0, [x19, #85]
    84cc:	f9404f42 	ldr	x2, [x26, #152]
    84d0:	36000aa0 	tbz	w0, #0, 8624 <fwp_main_thread+0x334>
    84d4:	a9508261 	ldp	x1, x0, [x19, #264]
    84d8:	b4000ba1 	cbz	x1, 864c <fwp_main_thread+0x35c>
    84dc:	f9008820 	str	x0, [x1, #272]
    84e0:	b4000040 	cbz	x0, 84e8 <fwp_main_thread+0x1f8>
    84e4:	f9008401 	str	x1, [x0, #264]
    84e8:	91080260 	add	x0, x19, #0x200
    84ec:	3901567f 	strb	wzr, [x19, #85]
    84f0:	aa0203f3 	mov	x19, x2
    84f4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    84f8:	f94016c0 	ldr	x0, [x22, #40]
    84fc:	b5fffa20 	cbnz	x0, 8440 <fwp_main_thread+0x150>
    8500:	91014280 	add	x0, x20, #0x50
    8504:	39014ad9 	strb	w25, [x22, #82]
    8508:	f941d400 	ldr	x0, [x0, #936]
    850c:	b5000080 	cbnz	x0, 851c <fwp_main_thread+0x22c>
    8510:	91014296 	add	x22, x20, #0x50
    8514:	f941dec0 	ldr	x0, [x22, #952]
    8518:	b40046a0 	cbz	x0, 8dec <fwp_main_thread+0xafc>
    851c:	91014280 	add	x0, x20, #0x50
    8520:	f941ec01 	ldr	x1, [x0, #984]
    8524:	b903d01f 	str	wzr, [x0, #976]
    8528:	eb13003f 	cmp	x1, x19
    852c:	54004761 	b.ne	8e18 <fwp_main_thread+0xb28>  // b.any
    8530:	b40009d3 	cbz	x19, 8668 <fwp_main_thread+0x378>
    8534:	91014280 	add	x0, x20, #0x50
    8538:	52800021 	mov	w1, #0x1                   	// #1
    853c:	39014a61 	strb	w1, [x19, #82]
    8540:	f941c005 	ldr	x5, [x0, #896]
    8544:	b4000925 	cbz	x5, 8668 <fwp_main_thread+0x378>
    8548:	394140a0 	ldrb	w0, [x5, #80]
    854c:	37000060 	tbnz	w0, #0, 8558 <fwp_main_thread+0x268>
    8550:	aa0503e0 	mov	x0, x5
    8554:	97ffec67 	bl	36f0 <fwp_cancel_tree.part.0>
    8558:	f9409ca5 	ldr	x5, [x5, #312]
    855c:	b5ffff65 	cbnz	x5, 8548 <fwp_main_thread+0x258>
    8560:	91014296 	add	x22, x20, #0x50
    8564:	52800037 	mov	w23, #0x1                   	// #1
    8568:	f9402a60 	ldr	x0, [x19, #80]
    856c:	f2001c1f 	tst	x0, #0xff000000ff
    8570:	540000e1 	b.ne	858c <fwp_main_thread+0x29c>  // b.any
    8574:	f94062c0 	ldr	x0, [x22, #192]
    8578:	39015277 	strb	w23, [x19, #84]
    857c:	f900827f 	str	xzr, [x19, #256]
    8580:	b40006a0 	cbz	x0, 8654 <fwp_main_thread+0x364>
    8584:	f9008013 	str	x19, [x0, #256]
    8588:	f90062d3 	str	x19, [x22, #192]
    858c:	97fff8ba 	bl	6874 <fwp_block>
    8590:	97fff84c 	bl	66c0 <fwp_free_zombie>
    8594:	f941c2c0 	ldr	x0, [x22, #896]
    8598:	b4000680 	cbz	x0, 8668 <fwp_main_thread+0x378>
    859c:	f941eed3 	ldr	x19, [x22, #984]
    85a0:	17fffff2 	b	8568 <fwp_main_thread+0x278>
    85a4:	f941d740 	ldr	x0, [x26, #936]
    85a8:	b50005a0 	cbnz	x0, 865c <fwp_main_thread+0x36c>
    85ac:	d2800013 	mov	x19, #0x0                   	// #0
    85b0:	17ffffd8 	b	8510 <fwp_main_thread+0x220>
    85b4:	97ffecf3 	bl	3980 <fwp_now_ns>
    85b8:	f94032c1 	ldr	x1, [x22, #96]
    85bc:	eb01001f 	cmp	x0, x1
    85c0:	540000ab 	b.lt	85d4 <fwp_main_thread+0x2e4>  // b.tstop
    85c4:	394142c0 	ldrb	w0, [x22, #80]
    85c8:	37000060 	tbnz	w0, #0, 85d4 <fwp_main_thread+0x2e4>
    85cc:	aa1603e0 	mov	x0, x22
    85d0:	97ffec48 	bl	36f0 <fwp_cancel_tree.part.0>
    85d4:	394146c0 	ldrb	w0, [x22, #81]
    85d8:	39414a62 	ldrb	w2, [x19, #82]
    85dc:	3707f3c0 	tbnz	w0, #0, 8454 <fwp_main_thread+0x164>
    85e0:	f94032c1 	ldr	x1, [x22, #96]
    85e4:	370001c2 	tbnz	w2, #0, 861c <fwp_main_thread+0x32c>
    85e8:	f9403260 	ldr	x0, [x19, #96]
    85ec:	b4000180 	cbz	x0, 861c <fwp_main_thread+0x32c>
    85f0:	b4000061 	cbz	x1, 85fc <fwp_main_thread+0x30c>
    85f4:	eb01001f 	cmp	x0, x1
    85f8:	9a81d000 	csel	x0, x0, x1, le
    85fc:	f94022c1 	ldr	x1, [x22, #64]
    8600:	a911fe77 	stp	x23, xzr, [x19, #280]
    8604:	f9009661 	str	x1, [x19, #296]
    8608:	b4003ec1 	cbz	x1, 8de0 <fwp_main_thread+0xaf0>
    860c:	f9009033 	str	x19, [x1, #288]
    8610:	aa0003e1 	mov	x1, x0
    8614:	f90022d3 	str	x19, [x22, #64]
    8618:	17ffff98 	b	8478 <fwp_main_thread+0x188>
    861c:	f94022c0 	ldr	x0, [x22, #64]
    8620:	17ffff90 	b	8460 <fwp_main_thread+0x170>
    8624:	aa0203f3 	mov	x19, x2
    8628:	17ffff84 	b	8438 <fwp_main_thread+0x148>
    862c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8630:	f9009660 	str	x0, [x19, #296]
    8634:	b4000040 	cbz	x0, 863c <fwp_main_thread+0x34c>
    8638:	f9009013 	str	x19, [x0, #288]
    863c:	f90022d3 	str	x19, [x22, #64]
    8640:	17ffff95 	b	8494 <fwp_main_thread+0x1a4>
    8644:	f9000040 	str	x0, [x2]
    8648:	17ffff9b 	b	84b4 <fwp_main_thread+0x1c4>
    864c:	f9009740 	str	x0, [x26, #296]
    8650:	17ffffa4 	b	84e0 <fwp_main_thread+0x1f0>
    8654:	f90066d3 	str	x19, [x22, #200]
    8658:	17ffffcc 	b	8588 <fwp_main_thread+0x298>
    865c:	f941ef40 	ldr	x0, [x26, #984]
    8660:	b903d35f 	str	wzr, [x26, #976]
    8664:	b5003da0 	cbnz	x0, 8e18 <fwp_main_thread+0xb28>
    8668:	91014296 	add	x22, x20, #0x50
    866c:	97fff815 	bl	66c0 <fwp_free_zombie>
    8670:	f94066c0 	ldr	x0, [x22, #200]
    8674:	b5003d20 	cbnz	x0, 8e18 <fwp_main_thread+0xb28>
    8678:	f94096c0 	ldr	x0, [x22, #296]
    867c:	b5003ce0 	cbnz	x0, 8e18 <fwp_main_thread+0xb28>
    8680:	b94172c0 	ldr	w0, [x22, #368]
    8684:	340001c0 	cbz	w0, 86bc <fwp_main_thread+0x3cc>
    8688:	93407c17 	sxtw	x23, w0
    868c:	51000400 	sub	w0, w0, #0x1
    8690:	d1000af7 	sub	x23, x23, #0x2
    8694:	910602d8 	add	x24, x22, #0x180
    8698:	cb2042f7 	sub	x23, x23, w0, uxtw
    869c:	93407c13 	sxtw	x19, w0
    86a0:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    86a4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    86a8:	b90172d3 	str	w19, [x22, #368]
    86ac:	d1000673 	sub	x19, x19, #0x1
    86b0:	97ffe8c4 	bl	29c0 <munmap@plt>
    86b4:	eb1302ff 	cmp	x23, x19
    86b8:	54ffff41 	b.ne	86a0 <fwp_main_thread+0x3b0>  // b.any
    86bc:	900000d3 	adrp	x19, 20000 <__data_start>
    86c0:	91004260 	add	x0, x19, #0x10
    86c4:	b9402000 	ldr	w0, [x0, #32]
    86c8:	37f80040 	tbnz	w0, #31, 86d0 <fwp_main_thread+0x3e0>
    86cc:	97ffe879 	bl	28b0 <close@plt>
    86d0:	91014280 	add	x0, x20, #0x50
    86d4:	91004261 	add	x1, x19, #0x10
    86d8:	12800002 	mov	w2, #0xffffffff            	// #-1
    86dc:	d2800013 	mov	x19, #0x0                   	// #0
    86e0:	f941f017 	ldr	x23, [x0, #992]
    86e4:	b9002022 	str	w2, [x1, #32]
    86e8:	f941f416 	ldr	x22, [x0, #1000]
    86ec:	b4000177 	cbz	x23, 8718 <fwp_main_thread+0x428>
    86f0:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    86f4:	b40000c0 	cbz	x0, 870c <fwp_main_thread+0x41c>
    86f8:	f9400001 	ldr	x1, [x0]
    86fc:	b50038e1 	cbnz	x1, 8e18 <fwp_main_thread+0xb28>
    8700:	f9400401 	ldr	x1, [x0, #8]
    8704:	b50038a1 	cbnz	x1, 8e18 <fwp_main_thread+0xb28>
    8708:	97fff162 	bl	4c90 <fwp_mem_free>
    870c:	91000673 	add	x19, x19, #0x1
    8710:	eb17027f 	cmp	x19, x23
    8714:	54fffee1 	b.ne	86f0 <fwp_main_thread+0x400>  // b.any
    8718:	aa1603e0 	mov	x0, x22
    871c:	97fff15d 	bl	4c90 <fwp_mem_free>
    8720:	91014280 	add	x0, x20, #0x50
    8724:	f941ec13 	ldr	x19, [x0, #984]
    8728:	f901f01f 	str	xzr, [x0, #992]
    872c:	f901f41f 	str	xzr, [x0, #1000]
    8730:	b40001f3 	cbz	x19, 876c <fwp_main_thread+0x47c>
    8734:	f9401661 	ldr	x1, [x19, #40]
    8738:	b5003701 	cbnz	x1, 8e18 <fwp_main_thread+0xb28>
    873c:	f9405661 	ldr	x1, [x19, #168]
    8740:	b50036c1 	cbnz	x1, 8e18 <fwp_main_thread+0xb28>
    8744:	f941d401 	ldr	x1, [x0, #936]
    8748:	b5003681 	cbnz	x1, 8e18 <fwp_main_thread+0xb28>
    874c:	f941dc00 	ldr	x0, [x0, #952]
    8750:	b5003640 	cbnz	x0, 8e18 <fwp_main_thread+0xb28>
    8754:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8758:	90000380 	adrp	x0, 78000 <ad_raw_blocks+0x17bc0>
    875c:	91110000 	add	x0, x0, #0x440
    8760:	97ffe844 	bl	2870 <memset@plt>
    8764:	aa1303e0 	mov	x0, x19
    8768:	97fff14a 	bl	4c90 <fwp_mem_free>
    876c:	91014286 	add	x6, x20, #0x50
    8770:	911882b5 	add	x21, x21, #0x620
    8774:	3dc01682 	ldr	q2, [x20, #80]
    8778:	52800041 	mov	w1, #0x2                   	// #2
    877c:	3dc004c1 	ldr	q1, [x6, #16]
    8780:	b0000002 	adrp	x2, 9000 <__divti3+0x100>
    8784:	fd4a12a0 	ldr	d0, [x21, #5152]
    8788:	91360042 	add	x2, x2, #0xd80
    878c:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    8790:	fd40a4c1 	ldr	d1, [x6, #328]
    8794:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8798:	f947e800 	ldr	x0, [x0, #4048]
    879c:	7e61d800 	ucvtf	d0, d0
    87a0:	a95390c3 	ldp	x3, x4, [x6, #312]
    87a4:	f9004cdf 	str	xzr, [x6, #152]
    87a8:	f9400000 	ldr	x0, [x0]
    87ac:	1e613801 	fsub	d1, d0, d1
    87b0:	f940acc5 	ldr	x5, [x6, #344]
    87b4:	b90130df 	str	wzr, [x6, #304]
    87b8:	5ef1b842 	addp	d2, v2.2d
    87bc:	fd40a8c0 	ldr	d0, [x6, #336]
    87c0:	f901ecdf 	str	xzr, [x6, #984]
    87c4:	fd0058c2 	str	d2, [x6, #176]
    87c8:	97ffe852 	bl	2910 <__fprintf_chk@plt>
    87cc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    87d0:	f947ec00 	ldr	x0, [x0, #4056]
    87d4:	f9400000 	ldr	x0, [x0]
    87d8:	97ffe87e 	bl	29d0 <fflush@plt>
    87dc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    87e0:	f947f400 	ldr	x0, [x0, #4072]
    87e4:	f9408fe2 	ldr	x2, [sp, #280]
    87e8:	f9400001 	ldr	x1, [x0]
    87ec:	eb010042 	subs	x2, x2, x1
    87f0:	d2800001 	mov	x1, #0x0                   	// #0
    87f4:	54003721 	b.ne	8ed8 <fwp_main_thread+0xbe8>  // b.any
    87f8:	a9527bfd 	ldp	x29, x30, [sp, #288]
    87fc:	d2800000 	mov	x0, #0x0                   	// #0
    8800:	a95353f3 	ldp	x19, x20, [sp, #304]
    8804:	a9545bf5 	ldp	x21, x22, [sp, #320]
    8808:	a95563f7 	ldp	x23, x24, [sp, #336]
    880c:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8810:	a95773fb 	ldp	x27, x28, [sp, #368]
    8814:	910603ff 	add	sp, sp, #0x180
    8818:	d65f03c0 	ret
    881c:	97ffee3a 	bl	4104 <fwp_heap_init>
    8820:	911882a0 	add	x0, x21, #0x620
    8824:	b953a800 	ldr	w0, [x0, #5032]
    8828:	34ffd8c0 	cbz	w0, 8340 <fwp_main_thread+0x50>
    882c:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    8830:	913e8000 	add	x0, x0, #0xfa0
    8834:	9400036f 	bl	95f0 <atexit>
    8838:	17fffec2 	b	8340 <fwp_main_thread+0x50>
    883c:	f941cb42 	ldr	x2, [x26, #912]
    8840:	b0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc_slow+0x50>
    8844:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    8848:	912fc000 	add	x0, x0, #0xbf0
    884c:	913d4021 	add	x1, x1, #0xf50
    8850:	d2800018 	mov	x24, #0x0                   	// #0
    8854:	d2900019 	mov	x25, #0x8000                	// #32768
    8858:	390023f6 	strb	w22, [sp, #8]
    885c:	d2800016 	mov	x22, #0x0                   	// #0
    8860:	a90287e2 	stp	x2, x1, [sp, #40]
    8864:	a903fff7 	stp	x23, xzr, [sp, #56]
    8868:	a90503ff 	stp	xzr, x0, [sp, #80]
    886c:	f901cb5b 	str	x27, [x26, #912]
    8870:	14000012 	b	88b8 <fwp_main_thread+0x5c8>
    8874:	7100045f 	cmp	w2, #0x1
    8878:	540001a1 	b.ne	88ac <fwp_main_thread+0x5bc>  // b.any
    887c:	29430865 	ldp	w5, w2, [x3, #24]
    8880:	92403c21 	and	x1, x1, #0xffff
    8884:	9b057c21 	mul	x1, x1, x5
    8888:	d360fc21 	lsr	x1, x1, #32
    888c:	eb02003f 	cmp	x1, x2
    8890:	540000e2 	b.cs	88ac <fwp_main_thread+0x5bc>  // b.hs, b.nlast
    8894:	8b010000 	add	x0, x0, x1
    8898:	39400001 	ldrb	w1, [x0]
    889c:	7103fc3f 	cmp	w1, #0xff
    88a0:	54002980 	b.eq	8dd0 <fwp_main_thread+0xae0>  // b.none
    88a4:	394023e1 	ldrb	w1, [sp, #8]
    88a8:	39000001 	strb	w1, [x0]
    88ac:	f90023f8 	str	x24, [sp, #64]
    88b0:	aa1b035a 	orr	x26, x26, x27
    88b4:	b40003fa 	cbz	x26, 8930 <fwp_main_thread+0x640>
    88b8:	f100073a 	subs	x26, x25, #0x1
    88bc:	aa1303e1 	mov	x1, x19
    88c0:	da1f02db 	sbc	x27, x22, xzr
    88c4:	52800020 	mov	w0, #0x1                   	// #1
    88c8:	f90027fa 	str	x26, [sp, #72]
    88cc:	aa1a03f9 	mov	x25, x26
    88d0:	a90863fa 	stp	x26, x24, [sp, #128]
    88d4:	97fff270 	bl	5294 <fwp_data.part.0.constprop.0>
    88d8:	aa0003f8 	mov	x24, x0
    88dc:	f949db81 	ldr	x1, [x28, #5040]
    88e0:	aa1b03f6 	mov	x22, x27
    88e4:	f949ef80 	ldr	x0, [x28, #5080]
    88e8:	cb010301 	sub	x1, x24, x1
    88ec:	eb00403f 	cmp	x1, x0, lsl #16
    88f0:	54fffde2 	b.cs	88ac <fwp_main_thread+0x5bc>  // b.hs, b.nlast
    88f4:	d350fc22 	lsr	x2, x1, #16
    88f8:	f949ff85 	ldr	x5, [x28, #5112]
    88fc:	8b020842 	add	x2, x2, x2, lsl #2
    8900:	d37df042 	lsl	x2, x2, #3
    8904:	8b0200a3 	add	x3, x5, x2
    8908:	f9401060 	ldr	x0, [x3, #32]
    890c:	b4fffd00 	cbz	x0, 88ac <fwp_main_thread+0x5bc>
    8910:	386268a2 	ldrb	w2, [x5, x2]
    8914:	7100085f 	cmp	w2, #0x2
    8918:	54fffae1 	b.ne	8874 <fwp_main_thread+0x584>  // b.any
    891c:	72003c3f 	tst	w1, #0xffff
    8920:	54fffbc0 	b.eq	8898 <fwp_main_thread+0x5a8>  // b.none
    8924:	f90023f8 	str	x24, [sp, #64]
    8928:	aa1b035a 	orr	x26, x26, x27
    892c:	b5fffc7a 	cbnz	x26, 88b8 <fwp_main_thread+0x5c8>
    8930:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x9e0>
    8934:	91014282 	add	x2, x20, #0x50
    8938:	f94017e3 	ldr	x3, [sp, #40]
    893c:	910183e1 	add	x1, sp, #0x60
    8940:	3dc14800 	ldr	q0, [x0, #1312]
    8944:	52800020 	mov	w0, #0x1                   	// #1
    8948:	f901c843 	str	x3, [x2, #912]
    894c:	3d801be0 	str	q0, [sp, #96]
    8950:	97fff251 	bl	5294 <fwp_data.part.0.constprop.0>
    8954:	911882a1 	add	x1, x21, #0x620
    8958:	aa0003f6 	mov	x22, x0
    895c:	f949d822 	ldr	x2, [x1, #5040]
    8960:	f949ec20 	ldr	x0, [x1, #5080]
    8964:	cb0202c2 	sub	x2, x22, x2
    8968:	eb00405f 	cmp	x2, x0, lsl #16
    896c:	54000322 	b.cs	89d0 <fwp_main_thread+0x6e0>  // b.hs, b.nlast
    8970:	d350fc40 	lsr	x0, x2, #16
    8974:	f949fc23 	ldr	x3, [x1, #5112]
    8978:	8b000800 	add	x0, x0, x0, lsl #2
    897c:	d37df001 	lsl	x1, x0, #3
    8980:	8b010060 	add	x0, x3, x1
    8984:	f9401019 	ldr	x25, [x0, #32]
    8988:	b4000259 	cbz	x25, 89d0 <fwp_main_thread+0x6e0>
    898c:	38616861 	ldrb	w1, [x3, x1]
    8990:	7100083f 	cmp	w1, #0x2
    8994:	54002080 	b.eq	8da4 <fwp_main_thread+0xab4>  // b.none
    8998:	7100043f 	cmp	w1, #0x1
    899c:	540001a1 	b.ne	89d0 <fwp_main_thread+0x6e0>  // b.any
    89a0:	29430003 	ldp	w3, w0, [x0, #24]
    89a4:	92403c41 	and	x1, x2, #0xffff
    89a8:	9b037c21 	mul	x1, x1, x3
    89ac:	d360fc21 	lsr	x1, x1, #32
    89b0:	eb00003f 	cmp	x1, x0
    89b4:	540000e2 	b.cs	89d0 <fwp_main_thread+0x6e0>  // b.hs, b.nlast
    89b8:	8b010339 	add	x25, x25, x1
    89bc:	39400320 	ldrb	w0, [x25]
    89c0:	7103fc1f 	cmp	w0, #0xff
    89c4:	540023e0 	b.eq	8e40 <fwp_main_thread+0xb50>  // b.none
    89c8:	52800020 	mov	w0, #0x1                   	// #1
    89cc:	39000320 	strb	w0, [x25]
    89d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    89d4:	aa1303e1 	mov	x1, x19
    89d8:	52800020 	mov	w0, #0x1                   	// #1
    89dc:	a9085be2 	stp	x2, x22, [sp, #128]
    89e0:	97fff22d 	bl	5294 <fwp_data.part.0.constprop.0>
    89e4:	911882a1 	add	x1, x21, #0x620
    89e8:	aa0003f3 	mov	x19, x0
    89ec:	f949d822 	ldr	x2, [x1, #5040]
    89f0:	f949ec20 	ldr	x0, [x1, #5080]
    89f4:	cb020262 	sub	x2, x19, x2
    89f8:	eb00405f 	cmp	x2, x0, lsl #16
    89fc:	54000322 	b.cs	8a60 <fwp_main_thread+0x770>  // b.hs, b.nlast
    8a00:	d350fc40 	lsr	x0, x2, #16
    8a04:	f949fc23 	ldr	x3, [x1, #5112]
    8a08:	8b000800 	add	x0, x0, x0, lsl #2
    8a0c:	d37df001 	lsl	x1, x0, #3
    8a10:	8b010060 	add	x0, x3, x1
    8a14:	f9401016 	ldr	x22, [x0, #32]
    8a18:	b4000256 	cbz	x22, 8a60 <fwp_main_thread+0x770>
    8a1c:	38616861 	ldrb	w1, [x3, x1]
    8a20:	7100083f 	cmp	w1, #0x2
    8a24:	54001b40 	b.eq	8d8c <fwp_main_thread+0xa9c>  // b.none
    8a28:	7100043f 	cmp	w1, #0x1
    8a2c:	540001a1 	b.ne	8a60 <fwp_main_thread+0x770>  // b.any
    8a30:	29430003 	ldp	w3, w0, [x0, #24]
    8a34:	92403c41 	and	x1, x2, #0xffff
    8a38:	9b037c21 	mul	x1, x1, x3
    8a3c:	d360fc21 	lsr	x1, x1, #32
    8a40:	eb00003f 	cmp	x1, x0
    8a44:	540000e2 	b.cs	8a60 <fwp_main_thread+0x770>  // b.hs, b.nlast
    8a48:	8b0102d6 	add	x22, x22, x1
    8a4c:	394002c0 	ldrb	w0, [x22]
    8a50:	7103fc1f 	cmp	w0, #0xff
    8a54:	54001fc0 	b.eq	8e4c <fwp_main_thread+0xb5c>  // b.none
    8a58:	52800020 	mov	w0, #0x1                   	// #1
    8a5c:	390002c0 	strb	w0, [x22]
    8a60:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8a64:	9101c3e1 	add	x1, sp, #0x70
    8a68:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8a6c:	52800020 	mov	w0, #0x1                   	// #1
    8a70:	a9074fe2 	stp	x2, x19, [sp, #112]
    8a74:	97fff208 	bl	5294 <fwp_data.part.0.constprop.0>
    8a78:	911882a1 	add	x1, x21, #0x620
    8a7c:	aa0003f3 	mov	x19, x0
    8a80:	f949d822 	ldr	x2, [x1, #5040]
    8a84:	f949ec20 	ldr	x0, [x1, #5080]
    8a88:	cb020262 	sub	x2, x19, x2
    8a8c:	eb00405f 	cmp	x2, x0, lsl #16
    8a90:	54000322 	b.cs	8af4 <fwp_main_thread+0x804>  // b.hs, b.nlast
    8a94:	d350fc40 	lsr	x0, x2, #16
    8a98:	f949fc23 	ldr	x3, [x1, #5112]
    8a9c:	8b000800 	add	x0, x0, x0, lsl #2
    8aa0:	d37df001 	lsl	x1, x0, #3
    8aa4:	8b010060 	add	x0, x3, x1
    8aa8:	f9401016 	ldr	x22, [x0, #32]
    8aac:	b4000256 	cbz	x22, 8af4 <fwp_main_thread+0x804>
    8ab0:	38616861 	ldrb	w1, [x3, x1]
    8ab4:	7100083f 	cmp	w1, #0x2
    8ab8:	54001700 	b.eq	8d98 <fwp_main_thread+0xaa8>  // b.none
    8abc:	7100043f 	cmp	w1, #0x1
    8ac0:	540001a1 	b.ne	8af4 <fwp_main_thread+0x804>  // b.any
    8ac4:	29430003 	ldp	w3, w0, [x0, #24]
    8ac8:	92403c41 	and	x1, x2, #0xffff
    8acc:	9b037c21 	mul	x1, x1, x3
    8ad0:	d360fc21 	lsr	x1, x1, #32
    8ad4:	eb00003f 	cmp	x1, x0
    8ad8:	540000e2 	b.cs	8af4 <fwp_main_thread+0x804>  // b.hs, b.nlast
    8adc:	8b0102d6 	add	x22, x22, x1
    8ae0:	394002c0 	ldrb	w0, [x22]
    8ae4:	7103fc1f 	cmp	w0, #0xff
    8ae8:	54001b80 	b.eq	8e58 <fwp_main_thread+0xb68>  // b.none
    8aec:	52800020 	mov	w0, #0x1                   	// #1
    8af0:	390002c0 	strb	w0, [x22]
    8af4:	aa1803f9 	mov	x25, x24
    8af8:	d00000b6 	adrp	x22, 1e000 <__FRAME_END__+0x12858>
    8afc:	b40011f8 	cbz	x24, 8d38 <fwp_main_thread+0xa48>
    8b00:	910ac2d6 	add	x22, x22, #0x2b0
    8b04:	911882bb 	add	x27, x21, #0x620
    8b08:	910142c0 	add	x0, x22, #0x50
    8b0c:	b000001a 	adrp	x26, 9000 <__divti3+0x100>
    8b10:	f90007e0 	str	x0, [sp, #8]
    8b14:	91198340 	add	x0, x26, #0x660
    8b18:	f9000be0 	str	x0, [sp, #16]
    8b1c:	f949db61 	ldr	x1, [x27, #5040]
    8b20:	f949ef60 	ldr	x0, [x27, #5080]
    8b24:	cb010261 	sub	x1, x19, x1
    8b28:	eb00403f 	cmp	x1, x0, lsl #16
    8b2c:	540003a2 	b.cs	8ba0 <fwp_main_thread+0x8b0>  // b.hs, b.nlast
    8b30:	d350fc20 	lsr	x0, x1, #16
    8b34:	f949ff65 	ldr	x5, [x27, #5112]
    8b38:	8b000800 	add	x0, x0, x0, lsl #2
    8b3c:	d37df002 	lsl	x2, x0, #3
    8b40:	8b0200a3 	add	x3, x5, x2
    8b44:	f9401060 	ldr	x0, [x3, #32]
    8b48:	b40002c0 	cbz	x0, 8ba0 <fwp_main_thread+0x8b0>
    8b4c:	386268a2 	ldrb	w2, [x5, x2]
    8b50:	7100085f 	cmp	w2, #0x2
    8b54:	540010e0 	b.eq	8d70 <fwp_main_thread+0xa80>  // b.none
    8b58:	7100045f 	cmp	w2, #0x1
    8b5c:	54000221 	b.ne	8ba0 <fwp_main_thread+0x8b0>  // b.any
    8b60:	29430865 	ldp	w5, w2, [x3, #24]
    8b64:	92403c21 	and	x1, x1, #0xffff
    8b68:	9b057c21 	mul	x1, x1, x5
    8b6c:	d360fc21 	lsr	x1, x1, #32
    8b70:	eb02003f 	cmp	x1, x2
    8b74:	54000162 	b.cs	8ba0 <fwp_main_thread+0x8b0>  // b.hs, b.nlast
    8b78:	8b010000 	add	x0, x0, x1
    8b7c:	39400001 	ldrb	w1, [x0]
    8b80:	34000101 	cbz	w1, 8ba0 <fwp_main_thread+0x8b0>
    8b84:	91014282 	add	x2, x20, #0x50
    8b88:	b9413043 	ldr	w3, [x2, #304]
    8b8c:	35000f83 	cbnz	w3, 8d7c <fwp_main_thread+0xa8c>
    8b90:	7103f43f 	cmp	w1, #0xfd
    8b94:	54001528 	b.hi	8e38 <fwp_main_thread+0xb48>  // b.pmore
    8b98:	11000421 	add	w1, w1, #0x1
    8b9c:	39000001 	strb	w1, [x0]
    8ba0:	f94007e2 	ldr	x2, [sp, #8]
    8ba4:	aa1703e0 	mov	x0, x23
    8ba8:	aa1303e1 	mov	x1, x19
    8bac:	52800023 	mov	w3, #0x1                   	// #1
    8bb0:	a9047fff 	stp	xzr, xzr, [sp, #64]
    8bb4:	f9002bff 	str	xzr, [sp, #80]
    8bb8:	97fff9d3 	bl	7304 <fwp_write>
    8bbc:	a9446bf6 	ldp	x22, x26, [sp, #64]
    8bc0:	f9400be0 	ldr	x0, [sp, #16]
    8bc4:	f10002df 	cmp	x22, #0x0
    8bc8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    8bcc:	b1002b5f 	cmn	x26, #0xa
    8bd0:	540018c8 	b.hi	8ee8 <fwp_main_thread+0xbf8>  // b.pmore
    8bd4:	52800021 	mov	w1, #0x1                   	// #1
    8bd8:	91002740 	add	x0, x26, #0x9
    8bdc:	97fff14d 	bl	5110 <fwp_heap_alloc>
    8be0:	aa0003fc 	mov	x28, x0
    8be4:	aa1603e1 	mov	x1, x22
    8be8:	aa0003f6 	mov	x22, x0
    8bec:	aa1a03e2 	mov	x2, x26
    8bf0:	f80086da 	str	x26, [x22], #8
    8bf4:	aa1603e0 	mov	x0, x22
    8bf8:	97ffe6be 	bl	26f0 <memcpy@plt>
    8bfc:	8b1a0382 	add	x2, x28, x26
    8c00:	3900205f 	strb	wzr, [x2, #8]
    8c04:	f94023e0 	ldr	x0, [sp, #64]
    8c08:	97ffe756 	bl	2960 <free@plt>
    8c0c:	f949db62 	ldr	x2, [x27, #5040]
    8c10:	f949ef60 	ldr	x0, [x27, #5080]
    8c14:	cb020382 	sub	x2, x28, x2
    8c18:	eb00405f 	cmp	x2, x0, lsl #16
    8c1c:	54000322 	b.cs	8c80 <fwp_main_thread+0x990>  // b.hs, b.nlast
    8c20:	d350fc40 	lsr	x0, x2, #16
    8c24:	f949ff66 	ldr	x6, [x27, #5112]
    8c28:	8b000800 	add	x0, x0, x0, lsl #2
    8c2c:	d37df001 	lsl	x1, x0, #3
    8c30:	8b0100c5 	add	x5, x6, x1
    8c34:	f94010a0 	ldr	x0, [x5, #32]
    8c38:	b4000240 	cbz	x0, 8c80 <fwp_main_thread+0x990>
    8c3c:	386168c1 	ldrb	w1, [x6, x1]
    8c40:	7100083f 	cmp	w1, #0x2
    8c44:	54000c00 	b.eq	8dc4 <fwp_main_thread+0xad4>  // b.none
    8c48:	7100043f 	cmp	w1, #0x1
    8c4c:	540001a1 	b.ne	8c80 <fwp_main_thread+0x990>  // b.any
    8c50:	92403c41 	and	x1, x2, #0xffff
    8c54:	294308a6 	ldp	w6, w2, [x5, #24]
    8c58:	9b067c21 	mul	x1, x1, x6
    8c5c:	d360fc21 	lsr	x1, x1, #32
    8c60:	eb02003f 	cmp	x1, x2
    8c64:	540000e2 	b.cs	8c80 <fwp_main_thread+0x990>  // b.hs, b.nlast
    8c68:	8b010000 	add	x0, x0, x1
    8c6c:	39400001 	ldrb	w1, [x0]
    8c70:	7103fc3f 	cmp	w1, #0xff
    8c74:	54000d40 	b.eq	8e1c <fwp_main_thread+0xb2c>  // b.none
    8c78:	52800021 	mov	w1, #0x1                   	// #1
    8c7c:	39000001 	strb	w1, [x0]
    8c80:	aa1303e0 	mov	x0, x19
    8c84:	97fff42f 	bl	5d40 <fwp_drop0>
    8c88:	91014285 	add	x5, x20, #0x50
    8c8c:	aa1603e0 	mov	x0, x22
    8c90:	f9400382 	ldr	x2, [x28]
    8c94:	aa0503f6 	mov	x22, x5
    8c98:	f94048a3 	ldr	x3, [x5, #144]
    8c9c:	d2800021 	mov	x1, #0x1                   	// #1
    8ca0:	97ffe740 	bl	29a0 <fwrite@plt>
    8ca4:	f9404ac1 	ldr	x1, [x22, #144]
    8ca8:	52800140 	mov	w0, #0xa                   	// #10
    8cac:	97ffe6c5 	bl	27c0 <fputc@plt>
    8cb0:	f949db62 	ldr	x2, [x27, #5040]
    8cb4:	f949ef60 	ldr	x0, [x27, #5080]
    8cb8:	cb020382 	sub	x2, x28, x2
    8cbc:	eb00405f 	cmp	x2, x0, lsl #16
    8cc0:	54000382 	b.cs	8d30 <fwp_main_thread+0xa40>  // b.hs, b.nlast
    8cc4:	d350fc40 	lsr	x0, x2, #16
    8cc8:	f949ff65 	ldr	x5, [x27, #5112]
    8ccc:	8b000800 	add	x0, x0, x0, lsl #2
    8cd0:	d37df001 	lsl	x1, x0, #3
    8cd4:	8b0100a3 	add	x3, x5, x1
    8cd8:	f9401060 	ldr	x0, [x3, #32]
    8cdc:	b40002a0 	cbz	x0, 8d30 <fwp_main_thread+0xa40>
    8ce0:	386168a1 	ldrb	w1, [x5, x1]
    8ce4:	7100083f 	cmp	w1, #0x2
    8ce8:	54000640 	b.eq	8db0 <fwp_main_thread+0xac0>  // b.none
    8cec:	7100043f 	cmp	w1, #0x1
    8cf0:	54000201 	b.ne	8d30 <fwp_main_thread+0xa40>  // b.any
    8cf4:	92403c41 	and	x1, x2, #0xffff
    8cf8:	29430865 	ldp	w5, w2, [x3, #24]
    8cfc:	9b057c21 	mul	x1, x1, x5
    8d00:	d360fc21 	lsr	x1, x1, #32
    8d04:	eb02003f 	cmp	x1, x2
    8d08:	54000142 	b.cs	8d30 <fwp_main_thread+0xa40>  // b.hs, b.nlast
    8d0c:	8b010000 	add	x0, x0, x1
    8d10:	39400001 	ldrb	w1, [x0]
    8d14:	340000e1 	cbz	w1, 8d30 <fwp_main_thread+0xa40>
    8d18:	7100043f 	cmp	w1, #0x1
    8d1c:	54000200 	b.eq	8d5c <fwp_main_thread+0xa6c>  // b.none
    8d20:	7103fc3f 	cmp	w1, #0xff
    8d24:	54000a00 	b.eq	8e64 <fwp_main_thread+0xb74>  // b.none
    8d28:	51000421 	sub	w1, w1, #0x1
    8d2c:	39000001 	strb	w1, [x0]
    8d30:	f9400b39 	ldr	x25, [x25, #16]
    8d34:	b5ffef59 	cbnz	x25, 8b1c <fwp_main_thread+0x82c>
    8d38:	aa1303e0 	mov	x0, x19
    8d3c:	97fff401 	bl	5d40 <fwp_drop0>
    8d40:	aa1803e0 	mov	x0, x24
    8d44:	97fff3ff 	bl	5d40 <fwp_drop0>
    8d48:	91014280 	add	x0, x20, #0x50
    8d4c:	52800021 	mov	w1, #0x1                   	// #1
    8d50:	b903c401 	str	w1, [x0, #964]
    8d54:	f901e41f 	str	xzr, [x0, #968]
    8d58:	17fffdb0 	b	8418 <fwp_main_thread+0x128>
    8d5c:	aa1c03e0 	mov	x0, x28
    8d60:	97fff2c5 	bl	5874 <fwp_rc_free_arr>
    8d64:	f9400b39 	ldr	x25, [x25, #16]
    8d68:	b5ffedb9 	cbnz	x25, 8b1c <fwp_main_thread+0x82c>
    8d6c:	17fffff3 	b	8d38 <fwp_main_thread+0xa48>
    8d70:	72003c3f 	tst	w1, #0xffff
    8d74:	54fff161 	b.ne	8ba0 <fwp_main_thread+0x8b0>  // b.any
    8d78:	17ffff81 	b	8b7c <fwp_main_thread+0x88c>
    8d7c:	f940ac43 	ldr	x3, [x2, #344]
    8d80:	91000463 	add	x3, x3, #0x1
    8d84:	f900ac43 	str	x3, [x2, #344]
    8d88:	17ffff82 	b	8b90 <fwp_main_thread+0x8a0>
    8d8c:	72003c5f 	tst	w2, #0xffff
    8d90:	54ffe681 	b.ne	8a60 <fwp_main_thread+0x770>  // b.any
    8d94:	17ffff2e 	b	8a4c <fwp_main_thread+0x75c>
    8d98:	72003c5f 	tst	w2, #0xffff
    8d9c:	54ffeac1 	b.ne	8af4 <fwp_main_thread+0x804>  // b.any
    8da0:	17ffff50 	b	8ae0 <fwp_main_thread+0x7f0>
    8da4:	72003c5f 	tst	w2, #0xffff
    8da8:	54ffe141 	b.ne	89d0 <fwp_main_thread+0x6e0>  // b.any
    8dac:	17ffff04 	b	89bc <fwp_main_thread+0x6cc>
    8db0:	72003c5f 	tst	w2, #0xffff
    8db4:	54fffae0 	b.eq	8d10 <fwp_main_thread+0xa20>  // b.none
    8db8:	f9400b39 	ldr	x25, [x25, #16]
    8dbc:	b5ffeb19 	cbnz	x25, 8b1c <fwp_main_thread+0x82c>
    8dc0:	17ffffde 	b	8d38 <fwp_main_thread+0xa48>
    8dc4:	72003c5f 	tst	w2, #0xffff
    8dc8:	54fff5c1 	b.ne	8c80 <fwp_main_thread+0x990>  // b.any
    8dcc:	17ffffa8 	b	8c6c <fwp_main_thread+0x97c>
    8dd0:	f9000be0 	str	x0, [sp, #16]
    8dd4:	97ffef0f 	bl	4a10 <fwp_rc_forget_slot>
    8dd8:	f9400be0 	ldr	x0, [sp, #16]
    8ddc:	17fffeb2 	b	88a4 <fwp_main_thread+0x5b4>
    8de0:	aa0003e1 	mov	x1, x0
    8de4:	f90022d3 	str	x19, [x22, #64]
    8de8:	17fffda4 	b	8478 <fwp_main_thread+0x188>
    8dec:	f941d2c0 	ldr	x0, [x22, #928]
    8df0:	97ffefa8 	bl	4c90 <fwp_mem_free>
    8df4:	f901d2df 	str	xzr, [x22, #928]
    8df8:	f901dadf 	str	xzr, [x22, #944]
    8dfc:	f941eec0 	ldr	x0, [x22, #984]
    8e00:	b4000173 	cbz	x19, 8e2c <fwp_main_thread+0xb3c>
    8e04:	f900567f 	str	xzr, [x19, #168]
    8e08:	f9005e7f 	str	xzr, [x19, #184]
    8e0c:	b903d2df 	str	wzr, [x22, #976]
    8e10:	eb13001f 	cmp	x0, x19
    8e14:	54ffb900 	b.eq	8534 <fwp_main_thread+0x244>  // b.none
    8e18:	97ffe6b6 	bl	28f0 <abort@plt>
    8e1c:	f9000fe0 	str	x0, [sp, #24]
    8e20:	97ffeefc 	bl	4a10 <fwp_rc_forget_slot>
    8e24:	f9400fe0 	ldr	x0, [sp, #24]
    8e28:	17ffff94 	b	8c78 <fwp_main_thread+0x988>
    8e2c:	b903d2df 	str	wzr, [x22, #976]
    8e30:	b4ffc1c0 	cbz	x0, 8668 <fwp_main_thread+0x378>
    8e34:	97ffe6af 	bl	28f0 <abort@plt>
    8e38:	97ffeeaf 	bl	48f4 <fwp_rc_wide_dup>
    8e3c:	17ffff59 	b	8ba0 <fwp_main_thread+0x8b0>
    8e40:	aa1903e0 	mov	x0, x25
    8e44:	97ffeef3 	bl	4a10 <fwp_rc_forget_slot>
    8e48:	17fffee0 	b	89c8 <fwp_main_thread+0x6d8>
    8e4c:	aa1603e0 	mov	x0, x22
    8e50:	97ffeef0 	bl	4a10 <fwp_rc_forget_slot>
    8e54:	17ffff01 	b	8a58 <fwp_main_thread+0x768>
    8e58:	aa1603e0 	mov	x0, x22
    8e5c:	97ffeeed 	bl	4a10 <fwp_rc_forget_slot>
    8e60:	17ffff23 	b	8aec <fwp_main_thread+0x7fc>
    8e64:	ca404401 	eor	x1, x0, x0, lsr #17
    8e68:	911882a2 	add	x2, x21, #0x620
    8e6c:	ca412421 	eor	x1, x1, x1, lsr #9
    8e70:	8b210c41 	add	x1, x2, w1, uxtb #3
    8e74:	f94a2421 	ldr	x1, [x1, #5192]
    8e78:	b5000081 	cbnz	x1, 8e88 <fwp_main_thread+0xb98>
    8e7c:	14000011 	b	8ec0 <fwp_main_thread+0xbd0>
    8e80:	f9400821 	ldr	x1, [x1, #16]
    8e84:	b40001e1 	cbz	x1, 8ec0 <fwp_main_thread+0xbd0>
    8e88:	f9400022 	ldr	x2, [x1]
    8e8c:	eb02001f 	cmp	x0, x2
    8e90:	54ffff81 	b.ne	8e80 <fwp_main_thread+0xb90>  // b.any
    8e94:	f9400422 	ldr	x2, [x1, #8]
    8e98:	d1000442 	sub	x2, x2, #0x1
    8e9c:	f9000422 	str	x2, [x1, #8]
    8ea0:	f103f85f 	cmp	x2, #0xfe
    8ea4:	54fff461 	b.ne	8d30 <fwp_main_thread+0xa40>  // b.any
    8ea8:	f9000fe0 	str	x0, [sp, #24]
    8eac:	97ffeed9 	bl	4a10 <fwp_rc_forget_slot>
    8eb0:	f9400fe0 	ldr	x0, [sp, #24]
    8eb4:	12800021 	mov	w1, #0xfffffffe            	// #-2
    8eb8:	39000001 	strb	w1, [x0]
    8ebc:	17ffff9d 	b	8d30 <fwp_main_thread+0xa40>
    8ec0:	b0000000 	adrp	x0, 9000 <__divti3+0x100>
    8ec4:	912b8000 	add	x0, x0, #0xae0
    8ec8:	97ffea4e 	bl	3800 <fwp_trap>
    8ecc:	b0000000 	adrp	x0, 9000 <__divti3+0x100>
    8ed0:	91348000 	add	x0, x0, #0xd20
    8ed4:	97ffea4b 	bl	3800 <fwp_trap>
    8ed8:	97ffe672 	bl	28a0 <__stack_chk_fail@plt>
    8edc:	b0000000 	adrp	x0, 9000 <__divti3+0x100>
    8ee0:	91352000 	add	x0, x0, #0xd48
    8ee4:	97ffe927 	bl	3380 <ad_raw_fail>
    8ee8:	b0000000 	adrp	x0, 9000 <__divti3+0x100>
    8eec:	9135a000 	add	x0, x0, #0xd68
    8ef0:	97ffea44 	bl	3800 <fwp_trap>
    8ef4:	d503201f 	nop
    8ef8:	d503201f 	nop
    8efc:	d503201f 	nop

0000000000008f00 <__divti3>:
    8f00:	d503245f 	bti	c
    8f04:	d2800004 	mov	x4, #0x0                   	// #0
    8f08:	b7f80721 	tbnz	x1, #63, 8fec <__divti3+0xec>
    8f0c:	b6f80083 	tbz	x3, #63, 8f1c <__divti3+0x1c>
    8f10:	eb0203e2 	negs	x2, x2
    8f14:	aa2403e4 	mvn	x4, x4
    8f18:	da0303e3 	ngc	x3, x3
    8f1c:	aa0203e6 	mov	x6, x2
    8f20:	aa0003e7 	mov	x7, x0
    8f24:	aa0103e5 	mov	x5, x1
    8f28:	b5000583 	cbnz	x3, 8fd8 <__divti3+0xd8>
    8f2c:	eb01005f 	cmp	x2, x1
    8f30:	54000e69 	b.ls	90fc <__divti3+0x1fc>  // b.plast
    8f34:	dac01040 	clz	x0, x2
    8f38:	b40000e0 	cbz	x0, 8f54 <__divti3+0x54>
    8f3c:	4b0003e1 	neg	w1, w0
    8f40:	9ac020a5 	lsl	x5, x5, x0
    8f44:	9ac02046 	lsl	x6, x2, x0
    8f48:	9ac124e1 	lsr	x1, x7, x1
    8f4c:	aa050025 	orr	x5, x1, x5
    8f50:	9ac020e7 	lsl	x7, x7, x0
    8f54:	d360fcc8 	lsr	x8, x6, #32
    8f58:	92407cc2 	and	x2, x6, #0xffffffff
    8f5c:	9ac808a3 	udiv	x3, x5, x8
    8f60:	9b089465 	msub	x5, x3, x8, x5
    8f64:	aa0303e0 	mov	x0, x3
    8f68:	9b037c41 	mul	x1, x2, x3
    8f6c:	93c780a5 	extr	x5, x5, x7, #32
    8f70:	eb05003f 	cmp	x1, x5
    8f74:	540000a9 	b.ls	8f88 <__divti3+0x88>  // b.plast
    8f78:	ab0500c5 	adds	x5, x6, x5
    8f7c:	d1000460 	sub	x0, x3, #0x1
    8f80:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8f84:	540015a8 	b.hi	9238 <__divti3+0x338>  // b.pmore
    8f88:	cb0100a5 	sub	x5, x5, x1
    8f8c:	9ac808a3 	udiv	x3, x5, x8
    8f90:	9b089465 	msub	x5, x3, x8, x5
    8f94:	aa0303e1 	mov	x1, x3
    8f98:	9b037c42 	mul	x2, x2, x3
    8f9c:	aa0703e3 	mov	x3, x7
    8fa0:	b3607ca3 	bfi	x3, x5, #32, #32
    8fa4:	eb03005f 	cmp	x2, x3
    8fa8:	540000c9 	b.ls	8fc0 <__divti3+0xc0>  // b.plast
    8fac:	ab0300c3 	adds	x3, x6, x3
    8fb0:	d1000425 	sub	x5, x1, #0x1
    8fb4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8fb8:	d1000821 	sub	x1, x1, #0x2
    8fbc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8fc0:	aa008020 	orr	x0, x1, x0, lsl #32
    8fc4:	d2800001 	mov	x1, #0x0                   	// #0
    8fc8:	b4000064 	cbz	x4, 8fd4 <__divti3+0xd4>
    8fcc:	eb0003e0 	negs	x0, x0
    8fd0:	da0103e1 	ngc	x1, x1
    8fd4:	d65f03c0 	ret
    8fd8:	eb01007f 	cmp	x3, x1
    8fdc:	54000109 	b.ls	8ffc <__divti3+0xfc>  // b.plast
    8fe0:	d2800001 	mov	x1, #0x0                   	// #0
    8fe4:	d2800000 	mov	x0, #0x0                   	// #0
    8fe8:	17fffff8 	b	8fc8 <__divti3+0xc8>
    8fec:	eb0003e0 	negs	x0, x0
    8ff0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8ff4:	da0103e1 	ngc	x1, x1
    8ff8:	17ffffc5 	b	8f0c <__divti3+0xc>
    8ffc:	dac01067 	clz	x7, x3
    9000:	b40010e7 	cbz	x7, 921c <__divti3+0x31c>
    9004:	d2800805 	mov	x5, #0x40                  	// #64
    9008:	cb0700a5 	sub	x5, x5, x7
    900c:	9ac72063 	lsl	x3, x3, x7
    9010:	9ac52448 	lsr	x8, x2, x5
    9014:	aa030108 	orr	x8, x8, x3
    9018:	9ac52426 	lsr	x6, x1, x5
    901c:	92407d0a 	and	x10, x8, #0xffffffff
    9020:	d360fd09 	lsr	x9, x8, #32
    9024:	9ac52403 	lsr	x3, x0, x5
    9028:	9ac72021 	lsl	x1, x1, x7
    902c:	aa010063 	orr	x3, x3, x1
    9030:	9ac72042 	lsl	x2, x2, x7
    9034:	9ac908cb 	udiv	x11, x6, x9
    9038:	9b099965 	msub	x5, x11, x9, x6
    903c:	aa0b03e1 	mov	x1, x11
    9040:	9b0b7d46 	mul	x6, x10, x11
    9044:	93c380a5 	extr	x5, x5, x3, #32
    9048:	eb0500df 	cmp	x6, x5
    904c:	540000a9 	b.ls	9060 <__divti3+0x160>  // b.plast
    9050:	ab050105 	adds	x5, x8, x5
    9054:	d1000561 	sub	x1, x11, #0x1
    9058:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    905c:	54000f48 	b.hi	9244 <__divti3+0x344>  // b.pmore
    9060:	cb0600a6 	sub	x6, x5, x6
    9064:	9ac908cb 	udiv	x11, x6, x9
    9068:	9b099969 	msub	x9, x11, x9, x6
    906c:	aa0b03e5 	mov	x5, x11
    9070:	9b0b7d4a 	mul	x10, x10, x11
    9074:	b3607d23 	bfi	x3, x9, #32, #32
    9078:	eb03015f 	cmp	x10, x3
    907c:	540000a9 	b.ls	9090 <__divti3+0x190>  // b.plast
    9080:	ab030103 	adds	x3, x8, x3
    9084:	d1000565 	sub	x5, x11, #0x1
    9088:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    908c:	54000e28 	b.hi	9250 <__divti3+0x350>  // b.pmore
    9090:	aa0180a1 	orr	x1, x5, x1, lsl #32
    9094:	92407c48 	and	x8, x2, #0xffffffff
    9098:	2a0503e5 	mov	w5, w5
    909c:	d360fc42 	lsr	x2, x2, #32
    90a0:	d360fc26 	lsr	x6, x1, #32
    90a4:	cb0a0063 	sub	x3, x3, x10
    90a8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    90ac:	9b087caa 	mul	x10, x5, x8
    90b0:	9b087cc8 	mul	x8, x6, x8
    90b4:	9b0220a5 	madd	x5, x5, x2, x8
    90b8:	9b027cc6 	mul	x6, x6, x2
    90bc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    90c0:	8b0900c5 	add	x5, x6, x9
    90c4:	eb02011f 	cmp	x8, x2
    90c8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    90cc:	8b4280c6 	add	x6, x6, x2, lsr #32
    90d0:	eb06007f 	cmp	x3, x6
    90d4:	540000e3 	b.cc	90f0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    90d8:	92407d4a 	and	x10, x10, #0xffffffff
    90dc:	9ac72000 	lsl	x0, x0, x7
    90e0:	8b028142 	add	x2, x10, x2, lsl #32
    90e4:	eb02001f 	cmp	x0, x2
    90e8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    90ec:	54000a01 	b.ne	922c <__divti3+0x32c>  // b.any
    90f0:	d1000420 	sub	x0, x1, #0x1
    90f4:	d2800001 	mov	x1, #0x0                   	// #0
    90f8:	17ffffb4 	b	8fc8 <__divti3+0xc8>
    90fc:	b5000062 	cbnz	x2, 9108 <__divti3+0x208>
    9100:	d2800022 	mov	x2, #0x1                   	// #1
    9104:	9ac30846 	udiv	x6, x2, x3
    9108:	dac010c8 	clz	x8, x6
    910c:	b5000408 	cbnz	x8, 918c <__divti3+0x28c>
    9110:	d360fcc9 	lsr	x9, x6, #32
    9114:	92407cc5 	and	x5, x6, #0xffffffff
    9118:	cb060023 	sub	x3, x1, x6
    911c:	d2800021 	mov	x1, #0x1                   	// #1
    9120:	9ac90868 	udiv	x8, x3, x9
    9124:	9b098d03 	msub	x3, x8, x9, x3
    9128:	aa0803e0 	mov	x0, x8
    912c:	9b057d02 	mul	x2, x8, x5
    9130:	93c78063 	extr	x3, x3, x7, #32
    9134:	eb03005f 	cmp	x2, x3
    9138:	540000a9 	b.ls	914c <__divti3+0x24c>  // b.plast
    913c:	ab0300c3 	adds	x3, x6, x3
    9140:	d1000500 	sub	x0, x8, #0x1
    9144:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9148:	54000968 	b.hi	9274 <__divti3+0x374>  // b.pmore
    914c:	cb020063 	sub	x3, x3, x2
    9150:	9ac90862 	udiv	x2, x3, x9
    9154:	aa0203e8 	mov	x8, x2
    9158:	9b098c42 	msub	x2, x2, x9, x3
    915c:	aa0703e3 	mov	x3, x7
    9160:	9b057d05 	mul	x5, x8, x5
    9164:	b3607c43 	bfi	x3, x2, #32, #32
    9168:	eb0300bf 	cmp	x5, x3
    916c:	540000c9 	b.ls	9184 <__divti3+0x284>  // b.plast
    9170:	ab0300c2 	adds	x2, x6, x3
    9174:	d1000503 	sub	x3, x8, #0x1
    9178:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    917c:	d1000908 	sub	x8, x8, #0x2
    9180:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    9184:	aa008100 	orr	x0, x8, x0, lsl #32
    9188:	17ffff90 	b	8fc8 <__divti3+0xc8>
    918c:	9ac820c6 	lsl	x6, x6, x8
    9190:	d2800803 	mov	x3, #0x40                  	// #64
    9194:	cb080063 	sub	x3, x3, x8
    9198:	d360fcc9 	lsr	x9, x6, #32
    919c:	9ac82027 	lsl	x7, x1, x8
    91a0:	92407cc5 	and	x5, x6, #0xffffffff
    91a4:	9ac32422 	lsr	x2, x1, x3
    91a8:	9ac32403 	lsr	x3, x0, x3
    91ac:	aa070063 	orr	x3, x3, x7
    91b0:	9ac9084a 	udiv	x10, x2, x9
    91b4:	9ac82007 	lsl	x7, x0, x8
    91b8:	9b098940 	msub	x0, x10, x9, x2
    91bc:	aa0a03e1 	mov	x1, x10
    91c0:	9b0a7ca2 	mul	x2, x5, x10
    91c4:	93c38000 	extr	x0, x0, x3, #32
    91c8:	eb00005f 	cmp	x2, x0
    91cc:	540000a9 	b.ls	91e0 <__divti3+0x2e0>  // b.plast
    91d0:	ab0000c0 	adds	x0, x6, x0
    91d4:	d1000541 	sub	x1, x10, #0x1
    91d8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    91dc:	54000468 	b.hi	9268 <__divti3+0x368>  // b.pmore
    91e0:	cb020000 	sub	x0, x0, x2
    91e4:	9ac9080a 	udiv	x10, x0, x9
    91e8:	9b098140 	msub	x0, x10, x9, x0
    91ec:	aa0a03e2 	mov	x2, x10
    91f0:	9b0a7ca8 	mul	x8, x5, x10
    91f4:	b3607c03 	bfi	x3, x0, #32, #32
    91f8:	eb03011f 	cmp	x8, x3
    91fc:	540000a9 	b.ls	9210 <__divti3+0x310>  // b.plast
    9200:	ab0300c3 	adds	x3, x6, x3
    9204:	d1000542 	sub	x2, x10, #0x1
    9208:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    920c:	54000288 	b.hi	925c <__divti3+0x35c>  // b.pmore
    9210:	cb080063 	sub	x3, x3, x8
    9214:	aa018041 	orr	x1, x2, x1, lsl #32
    9218:	17ffffc2 	b	9120 <__divti3+0x220>
    921c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9220:	d2800001 	mov	x1, #0x0                   	// #0
    9224:	9a9f87e0 	cset	x0, ls	// ls = plast
    9228:	17ffff68 	b	8fc8 <__divti3+0xc8>
    922c:	aa0103e0 	mov	x0, x1
    9230:	d2800001 	mov	x1, #0x0                   	// #0
    9234:	17ffff65 	b	8fc8 <__divti3+0xc8>
    9238:	d1000860 	sub	x0, x3, #0x2
    923c:	8b0600a5 	add	x5, x5, x6
    9240:	17ffff52 	b	8f88 <__divti3+0x88>
    9244:	d1000961 	sub	x1, x11, #0x2
    9248:	8b0800a5 	add	x5, x5, x8
    924c:	17ffff85 	b	9060 <__divti3+0x160>
    9250:	d1000965 	sub	x5, x11, #0x2
    9254:	8b080063 	add	x3, x3, x8
    9258:	17ffff8e 	b	9090 <__divti3+0x190>
    925c:	d1000942 	sub	x2, x10, #0x2
    9260:	8b060063 	add	x3, x3, x6
    9264:	17ffffeb 	b	9210 <__divti3+0x310>
    9268:	d1000941 	sub	x1, x10, #0x2
    926c:	8b060000 	add	x0, x0, x6
    9270:	17ffffdc 	b	91e0 <__divti3+0x2e0>
    9274:	d1000900 	sub	x0, x8, #0x2
    9278:	8b060063 	add	x3, x3, x6
    927c:	17ffffb4 	b	914c <__divti3+0x24c>

0000000000009280 <__modti3>:
    9280:	d503245f 	bti	c
    9284:	d2800004 	mov	x4, #0x0                   	// #0
    9288:	b6f80081 	tbz	x1, #63, 9298 <__modti3+0x18>
    928c:	eb0003e0 	negs	x0, x0
    9290:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9294:	da0103e1 	ngc	x1, x1
    9298:	f100007f 	cmp	x3, #0x0
    929c:	5400128b 	b.lt	94ec <__modti3+0x26c>  // b.tstop
    92a0:	aa0003e7 	mov	x7, x0
    92a4:	aa0103e6 	mov	x6, x1
    92a8:	540004e1 	b.ne	9344 <__modti3+0xc4>  // b.any
    92ac:	eb02003f 	cmp	x1, x2
    92b0:	54000dc2 	b.cs	9468 <__modti3+0x1e8>  // b.hs, b.nlast
    92b4:	dac01043 	clz	x3, x2
    92b8:	aa0303e5 	mov	x5, x3
    92bc:	b40000e3 	cbz	x3, 92d8 <__modti3+0x58>
    92c0:	4b0303e6 	neg	w6, w3
    92c4:	9ac32021 	lsl	x1, x1, x3
    92c8:	9ac32042 	lsl	x2, x2, x3
    92cc:	9ac62406 	lsr	x6, x0, x6
    92d0:	aa0100c6 	orr	x6, x6, x1
    92d4:	9ac32007 	lsl	x7, x0, x3
    92d8:	d360fc40 	lsr	x0, x2, #32
    92dc:	92407c43 	and	x3, x2, #0xffffffff
    92e0:	9ac008c1 	udiv	x1, x6, x0
    92e4:	9b009826 	msub	x6, x1, x0, x6
    92e8:	9b017c61 	mul	x1, x3, x1
    92ec:	93c780c6 	extr	x6, x6, x7, #32
    92f0:	eb06003f 	cmp	x1, x6
    92f4:	540000a9 	b.ls	9308 <__modti3+0x88>  // b.plast
    92f8:	ab060046 	adds	x6, x2, x6
    92fc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9300:	8b0200c8 	add	x8, x6, x2
    9304:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9308:	cb0100c6 	sub	x6, x6, x1
    930c:	9ac008c8 	udiv	x8, x6, x0
    9310:	9b009901 	msub	x1, x8, x0, x6
    9314:	aa0703e0 	mov	x0, x7
    9318:	9b087c63 	mul	x3, x3, x8
    931c:	b3607c20 	bfi	x0, x1, #32, #32
    9320:	eb00007f 	cmp	x3, x0
    9324:	54001088 	b.hi	9534 <__modti3+0x2b4>  // b.pmore
    9328:	cb030000 	sub	x0, x0, x3
    932c:	9ac52400 	lsr	x0, x0, x5
    9330:	d2800001 	mov	x1, #0x0                   	// #0
    9334:	b4000064 	cbz	x4, 9340 <__modti3+0xc0>
    9338:	eb0003e0 	negs	x0, x0
    933c:	da0103e1 	ngc	x1, x1
    9340:	d65f03c0 	ret
    9344:	dac01066 	clz	x6, x3
    9348:	eb03003f 	cmp	x1, x3
    934c:	54ffff43 	b.cc	9334 <__modti3+0xb4>  // b.lo, b.ul, b.last
    9350:	93407cc5 	sxtw	x5, w6
    9354:	d2800808 	mov	x8, #0x40                  	// #64
    9358:	cb050108 	sub	x8, x8, x5
    935c:	9ac62063 	lsl	x3, x3, x6
    9360:	9ac62025 	lsl	x5, x1, x6
    9364:	9ac82447 	lsr	x7, x2, x8
    9368:	aa0300e7 	orr	x7, x7, x3
    936c:	9ac82423 	lsr	x3, x1, x8
    9370:	92407cec 	and	x12, x7, #0xffffffff
    9374:	d360fcea 	lsr	x10, x7, #32
    9378:	9ac82401 	lsr	x1, x0, x8
    937c:	aa050021 	orr	x1, x1, x5
    9380:	9ac62042 	lsl	x2, x2, x6
    9384:	9ac62000 	lsl	x0, x0, x6
    9388:	9aca086b 	udiv	x11, x3, x10
    938c:	9b0a8d63 	msub	x3, x11, x10, x3
    9390:	aa0b03e5 	mov	x5, x11
    9394:	9b0b7d89 	mul	x9, x12, x11
    9398:	93c18063 	extr	x3, x3, x1, #32
    939c:	eb03013f 	cmp	x9, x3
    93a0:	540000a9 	b.ls	93b4 <__modti3+0x134>  // b.plast
    93a4:	ab0300e3 	adds	x3, x7, x3
    93a8:	d1000565 	sub	x5, x11, #0x1
    93ac:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    93b0:	54001168 	b.hi	95dc <__modti3+0x35c>  // b.pmore
    93b4:	cb090063 	sub	x3, x3, x9
    93b8:	9aca086b 	udiv	x11, x3, x10
    93bc:	9b0a8d6a 	msub	x10, x11, x10, x3
    93c0:	aa0b03e9 	mov	x9, x11
    93c4:	9b0b7d8c 	mul	x12, x12, x11
    93c8:	b3607d41 	bfi	x1, x10, #32, #32
    93cc:	eb01019f 	cmp	x12, x1
    93d0:	540000a9 	b.ls	93e4 <__modti3+0x164>  // b.plast
    93d4:	ab0100e1 	adds	x1, x7, x1
    93d8:	d1000569 	sub	x9, x11, #0x1
    93dc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    93e0:	54000f88 	b.hi	95d0 <__modti3+0x350>  // b.pmore
    93e4:	aa058123 	orr	x3, x9, x5, lsl #32
    93e8:	92407c4b 	and	x11, x2, #0xffffffff
    93ec:	2a0903e9 	mov	w9, w9
    93f0:	d360fc4a 	lsr	x10, x2, #32
    93f4:	d360fc63 	lsr	x3, x3, #32
    93f8:	cb0c0021 	sub	x1, x1, x12
    93fc:	aa0a03ec 	mov	x12, x10
    9400:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9404:	9b0b7d25 	mul	x5, x9, x11
    9408:	9b0b7c6b 	mul	x11, x3, x11
    940c:	9b0a2d29 	madd	x9, x9, x10, x11
    9410:	92407caa 	and	x10, x5, #0xffffffff
    9414:	9b0c7c63 	mul	x3, x3, x12
    9418:	8b458125 	add	x5, x9, x5, lsr #32
    941c:	8b0d0069 	add	x9, x3, x13
    9420:	eb05017f 	cmp	x11, x5
    9424:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9428:	8b058149 	add	x9, x10, x5, lsl #32
    942c:	8b458063 	add	x3, x3, x5, lsr #32
    9430:	eb03003f 	cmp	x1, x3
    9434:	54000063 	b.cc	9440 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9438:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    943c:	54000082 	b.cs	944c <__modti3+0x1cc>  // b.hs, b.nlast
    9440:	eb020129 	subs	x9, x9, x2
    9444:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9448:	cb070063 	sub	x3, x3, x7
    944c:	eb090000 	subs	x0, x0, x9
    9450:	da030021 	sbc	x1, x1, x3
    9454:	9ac62400 	lsr	x0, x0, x6
    9458:	9ac82028 	lsl	x8, x1, x8
    945c:	aa000100 	orr	x0, x8, x0
    9460:	9ac62421 	lsr	x1, x1, x6
    9464:	17ffffb4 	b	9334 <__modti3+0xb4>
    9468:	b5000062 	cbnz	x2, 9474 <__modti3+0x1f4>
    946c:	d2800023 	mov	x3, #0x1                   	// #1
    9470:	9ac20862 	udiv	x2, x3, x2
    9474:	dac01048 	clz	x8, x2
    9478:	aa0803e5 	mov	x5, x8
    947c:	b5000668 	cbnz	x8, 9548 <__modti3+0x2c8>
    9480:	cb020020 	sub	x0, x1, x2
    9484:	d360fc49 	lsr	x9, x2, #32
    9488:	92407c4a 	and	x10, x2, #0xffffffff
    948c:	9ac90801 	udiv	x1, x0, x9
    9490:	9b098020 	msub	x0, x1, x9, x0
    9494:	9b0a7c21 	mul	x1, x1, x10
    9498:	93c78000 	extr	x0, x0, x7, #32
    949c:	eb00003f 	cmp	x1, x0
    94a0:	540000a9 	b.ls	94b4 <__modti3+0x234>  // b.plast
    94a4:	ab000040 	adds	x0, x2, x0
    94a8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    94ac:	8b020003 	add	x3, x0, x2
    94b0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    94b4:	cb010001 	sub	x1, x0, x1
    94b8:	9ac90820 	udiv	x0, x1, x9
    94bc:	9b098403 	msub	x3, x0, x9, x1
    94c0:	aa0703e1 	mov	x1, x7
    94c4:	9b0a7c00 	mul	x0, x0, x10
    94c8:	b3607c61 	bfi	x1, x3, #32, #32
    94cc:	eb01001f 	cmp	x0, x1
    94d0:	540000a9 	b.ls	94e4 <__modti3+0x264>  // b.plast
    94d4:	ab010041 	adds	x1, x2, x1
    94d8:	8b020022 	add	x2, x1, x2
    94dc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    94e0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    94e4:	cb000020 	sub	x0, x1, x0
    94e8:	17ffff91 	b	932c <__modti3+0xac>
    94ec:	eb0203e5 	negs	x5, x2
    94f0:	aa0003e7 	mov	x7, x0
    94f4:	da0303e8 	ngc	x8, x3
    94f8:	aa0503e2 	mov	x2, x5
    94fc:	aa0803e3 	mov	x3, x8
    9500:	aa0103e6 	mov	x6, x1
    9504:	b4ffed48 	cbz	x8, 92ac <__modti3+0x2c>
    9508:	eb01011f 	cmp	x8, x1
    950c:	54fff148 	b.hi	9334 <__modti3+0xb4>  // b.pmore
    9510:	dac01109 	clz	x9, x8
    9514:	2a0903e6 	mov	w6, w9
    9518:	b5fff1c9 	cbnz	x9, 9350 <__modti3+0xd0>
    951c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9520:	54000068 	b.hi	952c <__modti3+0x2ac>  // b.pmore
    9524:	eb050007 	subs	x7, x0, x5
    9528:	da080021 	sbc	x1, x1, x8
    952c:	aa0703e0 	mov	x0, x7
    9530:	17ffff81 	b	9334 <__modti3+0xb4>
    9534:	ab000040 	adds	x0, x2, x0
    9538:	8b020002 	add	x2, x0, x2
    953c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9540:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9544:	17ffff79 	b	9328 <__modti3+0xa8>
    9548:	9ac82042 	lsl	x2, x2, x8
    954c:	d2800803 	mov	x3, #0x40                  	// #64
    9550:	cb080063 	sub	x3, x3, x8
    9554:	d360fc49 	lsr	x9, x2, #32
    9558:	9ac82027 	lsl	x7, x1, x8
    955c:	92407c4a 	and	x10, x2, #0xffffffff
    9560:	9ac32426 	lsr	x6, x1, x3
    9564:	9ac32403 	lsr	x3, x0, x3
    9568:	aa070063 	orr	x3, x3, x7
    956c:	9ac908c1 	udiv	x1, x6, x9
    9570:	9ac82007 	lsl	x7, x0, x8
    9574:	9b099820 	msub	x0, x1, x9, x6
    9578:	9b017d41 	mul	x1, x10, x1
    957c:	93c38000 	extr	x0, x0, x3, #32
    9580:	eb00003f 	cmp	x1, x0
    9584:	540000a9 	b.ls	9598 <__modti3+0x318>  // b.plast
    9588:	ab000040 	adds	x0, x2, x0
    958c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9590:	8b020006 	add	x6, x0, x2
    9594:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    9598:	cb010000 	sub	x0, x0, x1
    959c:	9ac90801 	udiv	x1, x0, x9
    95a0:	9b098026 	msub	x6, x1, x9, x0
    95a4:	aa0303e0 	mov	x0, x3
    95a8:	9b017d41 	mul	x1, x10, x1
    95ac:	b3607cc0 	bfi	x0, x6, #32, #32
    95b0:	eb00003f 	cmp	x1, x0
    95b4:	540000a9 	b.ls	95c8 <__modti3+0x348>  // b.plast
    95b8:	ab000040 	adds	x0, x2, x0
    95bc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    95c0:	8b020003 	add	x3, x0, x2
    95c4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    95c8:	cb010000 	sub	x0, x0, x1
    95cc:	17ffffb0 	b	948c <__modti3+0x20c>
    95d0:	d1000969 	sub	x9, x11, #0x2
    95d4:	8b070021 	add	x1, x1, x7
    95d8:	17ffff83 	b	93e4 <__modti3+0x164>
    95dc:	d1000965 	sub	x5, x11, #0x2
    95e0:	8b070063 	add	x3, x3, x7
    95e4:	17ffff74 	b	93b4 <__modti3+0x134>
    95e8:	d503201f 	nop
    95ec:	d503201f 	nop

00000000000095f0 <atexit>:
    95f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    95f4:	f00000a2 	adrp	x2, 20000 <__data_start>
    95f8:	d2800001 	mov	x1, #0x0                   	// #0
    95fc:	910003fd 	mov	x29, sp
    9600:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9604:	f9400442 	ldr	x2, [x2, #8]
    9608:	17ffe466 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000960c <_fini>:
    960c:	d503201f 	nop
    9610:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9614:	910003fd 	mov	x29, sp
    9618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    961c:	d65f03c0 	ret
