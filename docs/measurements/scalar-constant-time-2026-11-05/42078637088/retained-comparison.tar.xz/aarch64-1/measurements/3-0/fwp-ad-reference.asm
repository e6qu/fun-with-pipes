
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000025 	adrp	x5, 9000 <__modti3+0x330>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	9109c0a5 	add	x5, x5, #0x270
    2aa0:	f0000024 	adrp	x4, 9000 <__modti3+0x330>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	9109e084 	add	x4, x4, #0x278
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940002ac 	bl	3580 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9100c261 	add	x1, x19, #0x30
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x13110>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9001c20 	str	x0, [x1, #56]
    2b2c:	940002f5 	bl	3700 <fwp_now_ns>
    2b30:	f0000020 	adrp	x0, 9000 <__modti3+0x330>
    2b34:	91166000 	add	x0, x0, #0x598
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	b0000022 	adrp	x2, 7000 <fwp_write+0x1fc>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	9137c042 	add	x2, x2, #0xdf0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c273 	add	x19, x19, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9432260 	ldr	w0, [x19, #800]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000020 	adrp	x0, 9000 <__modti3+0x330>
    2c7c:	9116a000 	add	x0, x0, #0x5a8
    2c80:	94000240 	bl	3580 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	f0000020 	adrp	x0, 9000 <__modti3+0x330>
    2c8c:	91192000 	add	x0, x0, #0x648
    2c90:	9400023c 	bl	3580 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000020 	adrp	x0, 9000 <__modti3+0x330>
    2ca4:	91188000 	add	x0, x0, #0x620
    2ca8:	94000236 	bl	3580 <fwp_trap>
    2cac:	f0000020 	adrp	x0, 9000 <__modti3+0x330>
    2cb0:	9117c000 	add	x0, x0, #0x5f0
    2cb4:	94000233 	bl	3580 <fwp_trap>
    2cb8:	f0000020 	adrp	x0, 9000 <__modti3+0x330>
    2cbc:	91172000 	add	x0, x0, #0x5c8
    2cc0:	94000230 	bl	3580 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91006000 	add	x0, x0, #0x18
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91006021 	add	x1, x1, #0x18
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91006000 	add	x0, x0, #0x18
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91006021 	add	x1, x1, #0x18
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	f0000021 	adrp	x1, 9000 <__modti3+0x330>
    2eb4:	91318021 	add	x1, x1, #0xc60
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    3050:	9101e000 	add	x0, x0, #0x78
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	d0000021 	adrp	x1, 9000 <__modti3+0x330>
    3118:	91310021 	add	x1, x1, #0xc40
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    3144:	911542a1 	add	x1, x21, #0x550
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    3158:	912500a5 	add	x5, x5, #0x940
    315c:	911542a1 	add	x1, x21, #0x550
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911542b7 	add	x23, x21, #0x550
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911542b5 	add	x21, x21, #0x550
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911542b5 	add	x21, x21, #0x550
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    32e8:	9124e0a5 	add	x5, x5, #0x938
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    33f0:	9101e000 	add	x0, x0, #0x78
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	d0000021 	adrp	x1, 9000 <__modti3+0x330>
    3530:	aa1303e0 	mov	x0, x19
    3534:	91024021 	add	x1, x1, #0x90
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	d0000021 	adrp	x1, 9000 <__modti3+0x330>
    3544:	aa1303e0 	mov	x0, x19
    3548:	91026021 	add	x1, x1, #0x98
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	d0000021 	adrp	x1, 9000 <__modti3+0x330>
    3560:	91028021 	add	x1, x1, #0xa0
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_trap>:
    3580:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3584:	d53bd041 	mrs	x1, tpidr_el0
    3588:	91400021 	add	x1, x1, #0x0, lsl #12
    358c:	91004021 	add	x1, x1, #0x10
    3590:	910003fd 	mov	x29, sp
    3594:	a90153f3 	stp	x19, x20, [sp, #16]
    3598:	aa0003f3 	mov	x19, x0
    359c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    35a0:	f947ea94 	ldr	x20, [x20, #4048]
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	f9400035 	ldr	x21, [x1]
    35ac:	97fffe91 	bl	2ff0 <fwp_flush>
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	d0000022 	adrp	x2, 9000 <__modti3+0x330>
    35b8:	aa1303e3 	mov	x3, x19
    35bc:	9102a042 	add	x2, x2, #0xa8
    35c0:	52800041 	mov	w1, #0x2                   	// #2
    35c4:	97fffccb 	bl	28f0 <__fprintf_chk@plt>
    35c8:	b40000b5 	cbz	x21, 35dc <fwp_trap+0x5c>
    35cc:	f9400280 	ldr	x0, [x20]
    35d0:	97fffcf8 	bl	29b0 <fflush@plt>
    35d4:	52800ca0 	mov	w0, #0x65                  	// #101
    35d8:	97fffd06 	bl	29f0 <_Exit@plt>
    35dc:	52800ca0 	mov	w0, #0x65                  	// #101
    35e0:	97fffc54 	bl	2730 <exit@plt>

00000000000035e4 <fwp_closure_drop_push>:
    35e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    35e8:	910003fd 	mov	x29, sp
    35ec:	a90153f3 	stp	x19, x20, [sp, #16]
    35f0:	aa0003f3 	mov	x19, x0
    35f4:	a9408014 	ldp	x20, x0, [x0, #8]
    35f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    35fc:	aa0103f5 	mov	x21, x1
    3600:	a90363f7 	stp	x23, x24, [sp, #48]
    3604:	eb00029f 	cmp	x20, x0
    3608:	54000160 	b.eq	3634 <fwp_closure_drop_push+0x50>  // b.none
    360c:	f9400276 	ldr	x22, [x19]
    3610:	d37df297 	lsl	x23, x20, #3
    3614:	91000694 	add	x20, x20, #0x1
    3618:	f9000674 	str	x20, [x19, #8]
    361c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3620:	f8376ad5 	str	x21, [x22, x23]
    3624:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3628:	a94363f7 	ldp	x23, x24, [sp, #48]
    362c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3630:	d65f03c0 	ret
    3634:	a9046bf9 	stp	x25, x26, [sp, #64]
    3638:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    363c:	eb00029f 	cmp	x20, x0
    3640:	54000568 	b.hi	36ec <fwp_closure_drop_push+0x108>  // b.pmore
    3644:	d37cee99 	lsl	x25, x20, #4
    3648:	d37ffa9a 	lsl	x26, x20, #1
    364c:	aa1903e0 	mov	x0, x25
    3650:	97fffc74 	bl	2820 <malloc@plt>
    3654:	aa0003f6 	mov	x22, x0
    3658:	b4000320 	cbz	x0, 36bc <fwp_closure_drop_push+0xd8>
    365c:	aa1303f8 	mov	x24, x19
    3660:	aa1903e3 	mov	x3, x25
    3664:	d37df297 	lsl	x23, x20, #3
    3668:	aa1703e2 	mov	x2, x23
    366c:	f8418719 	ldr	x25, [x24], #24
    3670:	aa1903e1 	mov	x1, x25
    3674:	97fffc57 	bl	27d0 <__memcpy_chk@plt>
    3678:	eb18033f 	cmp	x25, x24
    367c:	540000a0 	b.eq	3690 <fwp_closure_drop_push+0xac>  // b.none
    3680:	aa1903e0 	mov	x0, x25
    3684:	97fffcaf 	bl	2940 <free@plt>
    3688:	f9400674 	ldr	x20, [x19, #8]
    368c:	d37df297 	lsl	x23, x20, #3
    3690:	91000694 	add	x20, x20, #0x1
    3694:	f9000276 	str	x22, [x19]
    3698:	f9000a7a 	str	x26, [x19, #16]
    369c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    36a0:	f9000674 	str	x20, [x19, #8]
    36a4:	f8376ad5 	str	x21, [x22, x23]
    36a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    36b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    36b8:	d65f03c0 	ret
    36bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    36c0:	f947e863 	ldr	x3, [x3, #4048]
    36c4:	d2800262 	mov	x2, #0x13                  	// #19
    36c8:	d2800021 	mov	x1, #0x1                   	// #1
    36cc:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    36d0:	9101e000 	add	x0, x0, #0x78
    36d4:	f9400063 	ldr	x3, [x3]
    36d8:	97fffcaa 	bl	2980 <fwrite@plt>
    36dc:	d2800000 	mov	x0, #0x0                   	// #0
    36e0:	97fffcb4 	bl	29b0 <fflush@plt>
    36e4:	52800cc0 	mov	w0, #0x66                  	// #102
    36e8:	97fffcc2 	bl	29f0 <_Exit@plt>
    36ec:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    36f0:	9102e000 	add	x0, x0, #0xb8
    36f4:	97ffffa3 	bl	3580 <fwp_trap>
    36f8:	d503201f 	nop
    36fc:	d503201f 	nop

0000000000003700 <fwp_now_ns>:
    3700:	d100c3ff 	sub	sp, sp, #0x30
    3704:	52800020 	mov	w0, #0x1                   	// #1
    3708:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    370c:	f947f442 	ldr	x2, [x2, #4072]
    3710:	910023e1 	add	x1, sp, #0x8
    3714:	a9027bfd 	stp	x29, x30, [sp, #32]
    3718:	910083fd 	add	x29, sp, #0x20
    371c:	f9400043 	ldr	x3, [x2]
    3720:	f9000fe3 	str	x3, [sp, #24]
    3724:	d2800003 	mov	x3, #0x0                   	// #0
    3728:	97fffc22 	bl	27b0 <clock_gettime@plt>
    372c:	350002c0 	cbnz	w0, 3784 <fwp_now_ns+0x84>
    3730:	a9408be1 	ldp	x1, x2, [sp, #8]
    3734:	d2994003 	mov	x3, #0xca00                	// #51712
    3738:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    373c:	9b037c20 	mul	x0, x1, x3
    3740:	9b437c21 	smulh	x1, x1, x3
    3744:	ab020000 	adds	x0, x0, x2
    3748:	937ffc42 	asr	x2, x2, #63
    374c:	9a020021 	adc	x1, x1, x2
    3750:	f100001f 	cmp	x0, #0x0
    3754:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3758:	b50001e1 	cbnz	x1, 3794 <fwp_now_ns+0x94>
    375c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3760:	f947f421 	ldr	x1, [x1, #4072]
    3764:	f9400fe3 	ldr	x3, [sp, #24]
    3768:	f9400022 	ldr	x2, [x1]
    376c:	eb020063 	subs	x3, x3, x2
    3770:	d2800002 	mov	x2, #0x0                   	// #0
    3774:	540000e1 	b.ne	3790 <fwp_now_ns+0x90>  // b.any
    3778:	a9427bfd 	ldp	x29, x30, [sp, #32]
    377c:	9100c3ff 	add	sp, sp, #0x30
    3780:	d65f03c0 	ret
    3784:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    3788:	91036000 	add	x0, x0, #0xd8
    378c:	97ffff7d 	bl	3580 <fwp_trap>
    3790:	97fffc3c 	bl	2880 <__stack_chk_fail@plt>
    3794:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    3798:	9103e000 	add	x0, x0, #0xf8
    379c:	97ffff79 	bl	3580 <fwp_trap>

00000000000037a0 <fwp_closure_drop.part.0>:
    37a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37a4:	d0000021 	adrp	x1, 9000 <__modti3+0x330>
    37a8:	910003fd 	mov	x29, sp
    37ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    37b0:	f947f463 	ldr	x3, [x3, #4072]
    37b4:	a90153f3 	stp	x19, x20, [sp, #16]
    37b8:	d10883ff 	sub	sp, sp, #0x220
    37bc:	910003e2 	mov	x2, sp
    37c0:	d53bd053 	mrs	x19, tpidr_el0
    37c4:	910063f4 	add	x20, sp, #0x18
    37c8:	3dc31c20 	ldr	q0, [x1, #3184]
    37cc:	91400264 	add	x4, x19, #0x0, lsl #12
    37d0:	91004084 	add	x4, x4, #0x10
    37d4:	aa0003e1 	mov	x1, x0
    37d8:	aa0203e0 	mov	x0, x2
    37dc:	f9400062 	ldr	x2, [x3]
    37e0:	f9010fe2 	str	x2, [sp, #536]
    37e4:	d2800002 	mov	x2, #0x0                   	// #0
    37e8:	f90003f4 	str	x20, [sp]
    37ec:	f9000080 	str	x0, [x4]
    37f0:	3c8083e0 	stur	q0, [sp, #8]
    37f4:	97ffff7c 	bl	35e4 <fwp_closure_drop_push>
    37f8:	f94007e0 	ldr	x0, [sp, #8]
    37fc:	b4000280 	cbz	x0, 384c <fwp_closure_drop.part.0+0xac>
    3800:	f90123f5 	str	x21, [sp, #576]
    3804:	b00000f5 	adrp	x21, 20000 <__data_start>
    3808:	9100c2b5 	add	x21, x21, #0x30
    380c:	d503201f 	nop
    3810:	f94003e1 	ldr	x1, [sp]
    3814:	d1000400 	sub	x0, x0, #0x1
    3818:	f90007e0 	str	x0, [sp, #8]
    381c:	f9401ea2 	ldr	x2, [x21, #56]
    3820:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3824:	b9400001 	ldr	w1, [x0]
    3828:	8b011441 	add	x1, x2, x1, lsl #5
    382c:	f9400c21 	ldr	x1, [x1, #24]
    3830:	b4000321 	cbz	x1, 3894 <fwp_closure_drop.part.0+0xf4>
    3834:	f9400422 	ldr	x2, [x1, #8]
    3838:	52800001 	mov	w1, #0x0                   	// #0
    383c:	d63f0040 	blr	x2
    3840:	f94007e0 	ldr	x0, [sp, #8]
    3844:	b5fffe60 	cbnz	x0, 3810 <fwp_closure_drop.part.0+0x70>
    3848:	f94123f5 	ldr	x21, [sp, #576]
    384c:	91400273 	add	x19, x19, #0x0, lsl #12
    3850:	91004273 	add	x19, x19, #0x10
    3854:	f94003e0 	ldr	x0, [sp]
    3858:	f900027f 	str	xzr, [x19]
    385c:	eb14001f 	cmp	x0, x20
    3860:	54000040 	b.eq	3868 <fwp_closure_drop.part.0+0xc8>  // b.none
    3864:	97fffc37 	bl	2940 <free@plt>
    3868:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    386c:	f947f400 	ldr	x0, [x0, #4072]
    3870:	f9410fe2 	ldr	x2, [sp, #536]
    3874:	f9400001 	ldr	x1, [x0]
    3878:	eb010042 	subs	x2, x2, x1
    387c:	d2800001 	mov	x1, #0x0                   	// #0
    3880:	54000101 	b.ne	38a0 <fwp_closure_drop.part.0+0x100>  // b.any
    3884:	910883ff 	add	sp, sp, #0x220
    3888:	a94153f3 	ldp	x19, x20, [sp, #16]
    388c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3890:	d65f03c0 	ret
    3894:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    3898:	91048000 	add	x0, x0, #0x120
    389c:	97ffff39 	bl	3580 <fwp_trap>
    38a0:	f90123f5 	str	x21, [sp, #576]
    38a4:	97fffbf7 	bl	2880 <__stack_chk_fail@plt>
    38a8:	d503201f 	nop
    38ac:	d503201f 	nop

00000000000038b0 <fwp_tape_of>:
    38b0:	92403c02 	and	x2, x0, #0xffff
    38b4:	b4000262 	cbz	x2, 3900 <fwp_tape_of+0x50>
    38b8:	9350fc01 	asr	x1, x0, #16
    38bc:	b00000e3 	adrp	x3, 20000 <__data_start>
    38c0:	d1000440 	sub	x0, x2, #0x1
    38c4:	9100c062 	add	x2, x3, #0x30
    38c8:	f9402042 	ldr	x2, [x2, #64]
    38cc:	eb00005f 	cmp	x2, x0
    38d0:	5400018d 	b.le	3900 <fwp_tape_of+0x50>
    38d4:	8b000402 	add	x2, x0, x0, lsl #1
    38d8:	f9401863 	ldr	x3, [x3, #48]
    38dc:	8b020802 	add	x2, x0, x2, lsl #2
    38e0:	d37df042 	lsl	x2, x2, #3
    38e4:	8b020060 	add	x0, x3, x2
    38e8:	b9400404 	ldr	w4, [x0, #4]
    38ec:	340000a4 	cbz	w4, 3900 <fwp_tape_of+0x50>
    38f0:	b8626862 	ldr	w2, [x3, x2]
    38f4:	6b01005f 	cmp	w2, w1
    38f8:	54000041 	b.ne	3900 <fwp_tape_of+0x50>  // b.any
    38fc:	d65f03c0 	ret
    3900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3904:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    3908:	91054000 	add	x0, x0, #0x150
    390c:	910003fd 	mov	x29, sp
    3910:	97ffff1c 	bl	3580 <fwp_trap>

0000000000003914 <fwp_format_g.constprop.0>:
    3914:	d10483ff 	sub	sp, sp, #0x120
    3918:	d0000024 	adrp	x4, 9000 <__modti3+0x330>
    391c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3920:	f947f442 	ldr	x2, [x2, #4072]
    3924:	91068084 	add	x4, x4, #0x1a0
    3928:	a90b7bfd 	stp	x29, x30, [sp, #176]
    392c:	9102c3fd 	add	x29, sp, #0xb0
    3930:	d2800803 	mov	x3, #0x40                  	// #64
    3934:	a90e63f7 	stp	x23, x24, [sp, #224]
    3938:	93407c38 	sxtw	x24, w1
    393c:	aa0303e1 	mov	x1, x3
    3940:	fd008be8 	str	d8, [sp, #272]
    3944:	1e604008 	fmov	d8, d0
    3948:	a90c53f3 	stp	x19, x20, [sp, #192]
    394c:	910083f4 	add	x20, sp, #0x20
    3950:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3954:	aa0003f5 	mov	x21, x0
    3958:	a91073fb 	stp	x27, x28, [sp, #256]
    395c:	5100071c 	sub	w28, w24, #0x1
    3960:	2a1c03e5 	mov	w5, w28
    3964:	f9400040 	ldr	x0, [x2]
    3968:	f90057e0 	str	x0, [sp, #168]
    396c:	d2800000 	mov	x0, #0x0                   	// #0
    3970:	52800042 	mov	w2, #0x2                   	// #2
    3974:	aa1403e0 	mov	x0, x20
    3978:	97fffb9e 	bl	27f0 <__snprintf_chk@plt>
    397c:	52800ca1 	mov	w1, #0x65                  	// #101
    3980:	aa1403e0 	mov	x0, x20
    3984:	97fffbf7 	bl	2960 <strchr@plt>
    3988:	aa0003f3 	mov	x19, x0
    398c:	52800142 	mov	w2, #0xa                   	// #10
    3990:	91000400 	add	x0, x0, #0x1
    3994:	d2800001 	mov	x1, #0x0                   	// #0
    3998:	97fffbe2 	bl	2920 <strtol@plt>
    399c:	aa0003f7 	mov	x23, x0
    39a0:	11001400 	add	w0, w0, #0x5
    39a4:	7100541f 	cmp	w0, #0x15
    39a8:	54000d88 	b.hi	3b58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    39ac:	4b170385 	sub	w5, w28, w23
    39b0:	710000bf 	cmp	w5, #0x0
    39b4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    39b8:	54000ba0 	b.eq	3b2c <fwp_format_g.constprop.0+0x218>  // b.none
    39bc:	394083e0 	ldrb	w0, [sp, #32]
    39c0:	cb180273 	sub	x19, x19, x24
    39c4:	91000673 	add	x19, x19, #0x1
    39c8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39cc:	7100b41f 	cmp	w0, #0x2d
    39d0:	9a941681 	cinc	x1, x20, eq	// eq = none
    39d4:	1a9f17e4 	cset	w4, eq	// eq = none
    39d8:	cb010266 	sub	x6, x19, x1
    39dc:	d10004da 	sub	x26, x6, #0x1
    39e0:	540018c0 	b.eq	3cf8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    39e4:	910183f9 	add	x25, sp, #0x60
    39e8:	d280091b 	mov	x27, #0x48                  	// #72
    39ec:	aa1903e7 	mov	x7, x25
    39f0:	91000423 	add	x3, x1, #0x1
    39f4:	91011cc6 	add	x6, x6, #0x47
    39f8:	910004f6 	add	x22, x7, #0x1
    39fc:	37f81017 	tbnz	w23, #31, 3bfc <fwp_format_g.constprop.0+0x2e8>
    3a00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3a04:	93407ef7 	sxtw	x23, w23
    3a08:	390000e4 	strb	w4, [x7]
    3a0c:	aa1303e1 	mov	x1, x19
    3a10:	aa1703e2 	mov	x2, x23
    3a14:	aa1603e0 	mov	x0, x22
    3a18:	b9000be5 	str	w5, [sp, #8]
    3a1c:	cb170374 	sub	x20, x27, x23
    3a20:	a9011be3 	stp	x3, x6, [sp, #16]
    3a24:	97fffb2b 	bl	26d0 <memcpy@plt>
    3a28:	d1000694 	sub	x20, x20, #0x1
    3a2c:	f9400be3 	ldr	x3, [sp, #16]
    3a30:	8b1702d6 	add	x22, x22, x23
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	aa1a03e2 	mov	x2, x26
    3a3c:	aa0303e1 	mov	x1, x3
    3a40:	aa1403e3 	mov	x3, x20
    3a44:	97fffb63 	bl	27d0 <__memcpy_chk@plt>
    3a48:	8b1a02d6 	add	x22, x22, x26
    3a4c:	f9400fe6 	ldr	x6, [sp, #24]
    3a50:	d2800900 	mov	x0, #0x48                  	// #72
    3a54:	b9400be5 	ldr	w5, [sp, #8]
    3a58:	8b170261 	add	x1, x19, x23
    3a5c:	cb1400c3 	sub	x3, x6, x20
    3a60:	cb060294 	sub	x20, x20, x6
    3a64:	f101207f 	cmp	x3, #0x48
    3a68:	93407cb8 	sxtw	x24, w5
    3a6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3a70:	aa1803e2 	mov	x2, x24
    3a74:	8b1802d3 	add	x19, x22, x24
    3a78:	8b140063 	add	x3, x3, x20
    3a7c:	aa1603e0 	mov	x0, x22
    3a80:	97fffb54 	bl	27d0 <__memcpy_chk@plt>
    3a84:	cb190273 	sub	x19, x19, x25
    3a88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a8c:	eb00027f 	cmp	x19, x0
    3a90:	aa1903e1 	mov	x1, x25
    3a94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a98:	aa1503e0 	mov	x0, x21
    3a9c:	aa1303e2 	mov	x2, x19
    3aa0:	97fffb0c 	bl	26d0 <memcpy@plt>
    3aa4:	38336abf 	strb	wzr, [x21, x19]
    3aa8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aac:	aa1503e0 	mov	x0, x21
    3ab0:	97fffb18 	bl	2710 <strlen@plt>
    3ab4:	aa0003f3 	mov	x19, x0
    3ab8:	528005c1 	mov	w1, #0x2e                  	// #46
    3abc:	aa1503e0 	mov	x0, x21
    3ac0:	97fffba8 	bl	2960 <strchr@plt>
    3ac4:	b4000160 	cbz	x0, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3ac8:	b4000153 	cbz	x19, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3acc:	d503201f 	nop
    3ad0:	aa1303e1 	mov	x1, x19
    3ad4:	d1000673 	sub	x19, x19, #0x1
    3ad8:	38736aa0 	ldrb	w0, [x21, x19]
    3adc:	7100c01f 	cmp	w0, #0x30
    3ae0:	54001001 	b.ne	3ce0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ae4:	38336abf 	strb	wzr, [x21, x19]
    3ae8:	b5ffff53 	cbnz	x19, 3ad0 <fwp_format_g.constprop.0+0x1bc>
    3aec:	d503201f 	nop
    3af0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3af4:	f947f400 	ldr	x0, [x0, #4072]
    3af8:	f94057e2 	ldr	x2, [sp, #168]
    3afc:	f9400001 	ldr	x1, [x0]
    3b00:	eb010042 	subs	x2, x2, x1
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	54001061 	b.ne	3d14 <fwp_format_g.constprop.0+0x400>  // b.any
    3b0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3b10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3b14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3b18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3b1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3b20:	fd408be8 	ldr	d8, [sp, #272]
    3b24:	910483ff 	add	sp, sp, #0x120
    3b28:	d65f03c0 	ret
    3b2c:	1e604100 	fmov	d0, d8
    3b30:	710000bf 	cmp	w5, #0x0
    3b34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	d0000024 	adrp	x4, 9000 <__modti3+0x330>
    3b40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b44:	9106e084 	add	x4, x4, #0x1b8
    3b48:	52800042 	mov	w2, #0x2                   	// #2
    3b4c:	d2803201 	mov	x1, #0x190                 	// #400
    3b50:	97fffb28 	bl	27f0 <__snprintf_chk@plt>
    3b54:	17ffffd6 	b	3aac <fwp_format_g.constprop.0+0x198>
    3b58:	cb140273 	sub	x19, x19, x20
    3b5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b60:	910183f9 	add	x25, sp, #0x60
    3b64:	aa1303e2 	mov	x2, x19
    3b68:	aa1403e1 	mov	x1, x20
    3b6c:	aa1903e0 	mov	x0, x25
    3b70:	d2800803 	mov	x3, #0x40                  	// #64
    3b74:	97fffb17 	bl	27d0 <__memcpy_chk@plt>
    3b78:	38336b3f 	strb	wzr, [x25, x19]
    3b7c:	aa1903e0 	mov	x0, x25
    3b80:	528005c1 	mov	w1, #0x2e                  	// #46
    3b84:	97fffb77 	bl	2960 <strchr@plt>
    3b88:	b40001c0 	cbz	x0, 3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b8c:	b50000b3 	cbnz	x19, 3ba0 <fwp_format_g.constprop.0+0x28c>
    3b90:	1400000c 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b94:	381ff01f 	sturb	wzr, [x0, #-1]
    3b98:	f1000673 	subs	x19, x19, #0x1
    3b9c:	54000120 	b.eq	3bc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ba0:	8b130320 	add	x0, x25, x19
    3ba4:	385ff001 	ldurb	w1, [x0, #-1]
    3ba8:	7100c03f 	cmp	w1, #0x30
    3bac:	54ffff40 	b.eq	3b94 <fwp_format_g.constprop.0+0x280>  // b.none
    3bb0:	d1000673 	sub	x19, x19, #0x1
    3bb4:	38736b20 	ldrb	w0, [x25, x19]
    3bb8:	7100b81f 	cmp	w0, #0x2e
    3bbc:	54000a80 	b.eq	3d0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3bc0:	710002ff 	cmp	w23, #0x0
    3bc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3bc8:	aa1903e5 	mov	x5, x25
    3bcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3bd0:	aa1503e0 	mov	x0, x21
    3bd4:	52800566 	mov	w6, #0x2b                  	// #43
    3bd8:	d0000024 	adrp	x4, 9000 <__modti3+0x330>
    3bdc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3be0:	9106a084 	add	x4, x4, #0x1a8
    3be4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3be8:	52800042 	mov	w2, #0x2                   	// #2
    3bec:	d2803201 	mov	x1, #0x190                 	// #400
    3bf0:	97fffb00 	bl	27f0 <__snprintf_chk@plt>
    3bf4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3bf8:	17ffffbe 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3bfc:	52800605 	mov	w5, #0x30                  	// #48
    3c00:	390000e5 	strb	w5, [x7]
    3c04:	d100077b 	sub	x27, x27, #0x1
    3c08:	aa0303e1 	mov	x1, x3
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	aa1b03e3 	mov	x3, x27
    3c14:	aa1a03e2 	mov	x2, x26
    3c18:	f90007e6 	str	x6, [sp, #8]
    3c1c:	b90013e4 	str	w4, [sp, #16]
    3c20:	8b1a02d6 	add	x22, x22, x26
    3c24:	b9001be5 	str	w5, [sp, #24]
    3c28:	97fffaea 	bl	27d0 <__memcpy_chk@plt>
    3c2c:	f94007e6 	ldr	x6, [sp, #8]
    3c30:	2a3703e7 	mvn	w7, w23
    3c34:	b94013e4 	ldr	w4, [sp, #16]
    3c38:	cb1b00c1 	sub	x1, x6, x27
    3c3c:	cb06037b 	sub	x27, x27, x6
    3c40:	f101203f 	cmp	x1, #0x48
    3c44:	d2800906 	mov	x6, #0x48                  	// #72
    3c48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3c4c:	8b1b0023 	add	x3, x1, x27
    3c50:	310006ff 	cmn	w23, #0x1
    3c54:	54000220 	b.eq	3c98 <fwp_format_g.constprop.0+0x384>  // b.none
    3c58:	b9401be5 	ldr	w5, [sp, #24]
    3c5c:	d2800001 	mov	x1, #0x0                   	// #0
    3c60:	f101207f 	cmp	x3, #0x48
    3c64:	d1000462 	sub	x2, x3, #0x1
    3c68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3c6c:	38216ac5 	strb	w5, [x22, x1]
    3c70:	cb030003 	sub	x3, x0, x3
    3c74:	91000421 	add	x1, x1, #0x1
    3c78:	91000463 	add	x3, x3, #0x1
    3c7c:	eb00007f 	cmp	x3, x0
    3c80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c84:	cb000063 	sub	x3, x3, x0
    3c88:	8b020063 	add	x3, x3, x2
    3c8c:	6b0100ff 	cmp	w7, w1
    3c90:	54fffe8c 	b.gt	3c60 <fwp_format_g.constprop.0+0x34c>
    3c94:	8b2742d6 	add	x22, x22, w7, uxtw
    3c98:	f101207f 	cmp	x3, #0x48
    3c9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ca0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ca4:	aa1603e0 	mov	x0, x22
    3ca8:	cb0300a1 	sub	x1, x5, x3
    3cac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3cb0:	91000421 	add	x1, x1, #0x1
    3cb4:	d1000463 	sub	x3, x3, #0x1
    3cb8:	eb05003f 	cmp	x1, x5
    3cbc:	38001402 	strb	w2, [x0], #1
    3cc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3cc4:	93407f82 	sxtw	x2, w28
    3cc8:	cb050025 	sub	x5, x1, x5
    3ccc:	aa1303e1 	mov	x1, x19
    3cd0:	8b0300a3 	add	x3, x5, x3
    3cd4:	8b1802d3 	add	x19, x22, x24
    3cd8:	97fffabe 	bl	27d0 <__memcpy_chk@plt>
    3cdc:	17ffff6a 	b	3a84 <fwp_format_g.constprop.0+0x170>
    3ce0:	d1000421 	sub	x1, x1, #0x1
    3ce4:	38616aa0 	ldrb	w0, [x21, x1]
    3ce8:	7100b81f 	cmp	w0, #0x2e
    3cec:	54fff021 	b.ne	3af0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3cf0:	38216abf 	strb	wzr, [x21, x1]
    3cf4:	17ffff7f 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3cf8:	910187e7 	add	x7, sp, #0x61
    3cfc:	910183f9 	add	x25, sp, #0x60
    3d00:	d28008fb 	mov	x27, #0x47                  	// #71
    3d04:	390183e0 	strb	w0, [sp, #96]
    3d08:	17ffff3a 	b	39f0 <fwp_format_g.constprop.0+0xdc>
    3d0c:	38336b3f 	strb	wzr, [x25, x19]
    3d10:	17ffffac 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3d14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d18:	97fffada 	bl	2880 <__stack_chk_fail@plt>
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_heap_report>:
    3d20:	d105c3ff 	sub	sp, sp, #0x170
    3d24:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    3d28:	91154042 	add	x2, x2, #0x550
    3d2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3d30:	f947e821 	ldr	x1, [x1, #4048]
    3d34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3d38:	910443fd 	add	x29, sp, #0x110
    3d3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d40:	f947f400 	ldr	x0, [x0, #4072]
    3d44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3d48:	a91463f7 	stp	x23, x24, [sp, #320]
    3d4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3d50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3d54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3d58:	fd4a2049 	ldr	d9, [x2, #5184]
    3d5c:	f9400036 	ldr	x22, [x1]
    3d60:	f9400001 	ldr	x1, [x0]
    3d64:	f90087e1 	str	x1, [sp, #264]
    3d68:	d2800001 	mov	x1, #0x0                   	// #0
    3d6c:	f949e459 	ldr	x25, [x2, #5064]
    3d70:	d0000021 	adrp	x1, 9000 <__modti3+0x330>
    3d74:	f94a1057 	ldr	x23, [x2, #5152]
    3d78:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    3d7c:	f94a1458 	ldr	x24, [x2, #5160]
    3d80:	91070021 	add	x1, x1, #0x1c0
    3d84:	91072000 	add	x0, x0, #0x1c8
    3d88:	97fffaa2 	bl	2810 <fopen@plt>
    3d8c:	b4000740 	cbz	x0, 3e74 <fwp_heap_report+0x154>
    3d90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d94:	a91253f3 	stp	x19, x20, [sp, #288]
    3d98:	aa0003f4 	mov	x20, x0
    3d9c:	910023f3 	add	x19, sp, #0x8
    3da0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3da4:	72aae915 	movk	w21, #0x5748, lsl #16
    3da8:	aa1403e2 	mov	x2, x20
    3dac:	aa1303e0 	mov	x0, x19
    3db0:	52802001 	mov	w1, #0x100                 	// #256
    3db4:	97fffb23 	bl	2a40 <fgets@plt>
    3db8:	b4000280 	cbz	x0, 3e08 <fwp_heap_report+0xe8>
    3dbc:	b9400261 	ldr	w1, [x19]
    3dc0:	6b15003f 	cmp	w1, w21
    3dc4:	54ffff21 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dc8:	39401260 	ldrb	w0, [x19, #4]
    3dcc:	7101341f 	cmp	w0, #0x4d
    3dd0:	54fffec1 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dd4:	394037e0 	ldrb	w0, [sp, #13]
    3dd8:	7100e81f 	cmp	w0, #0x3a
    3ddc:	54fffe61 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3de0:	52800142 	mov	w2, #0xa                   	// #10
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	91003be0 	add	x0, sp, #0xe
    3dec:	97fffacd 	bl	2920 <strtol@plt>
    3df0:	aa1403e2 	mov	x2, x20
    3df4:	aa0003fa 	mov	x26, x0
    3df8:	52802001 	mov	w1, #0x100                 	// #256
    3dfc:	aa1303e0 	mov	x0, x19
    3e00:	97fffb10 	bl	2a40 <fgets@plt>
    3e04:	b5fffdc0 	cbnz	x0, 3dbc <fwp_heap_report+0x9c>
    3e08:	aa1403e0 	mov	x0, x20
    3e0c:	97fffa7d 	bl	2800 <fclose@plt>
    3e10:	a95253f3 	ldp	x19, x20, [sp, #288]
    3e14:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3e18:	f947f400 	ldr	x0, [x0, #4072]
    3e1c:	f94087e2 	ldr	x2, [sp, #264]
    3e20:	f9400001 	ldr	x1, [x0]
    3e24:	eb010042 	subs	x2, x2, x1
    3e28:	d2800001 	mov	x1, #0x0                   	// #0
    3e2c:	54000281 	b.ne	3e7c <fwp_heap_report+0x15c>  // b.any
    3e30:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3e34:	aa1a03e6 	mov	x6, x26
    3e38:	aa1903e5 	mov	x5, x25
    3e3c:	aa1803e4 	mov	x4, x24
    3e40:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3e44:	aa1703e3 	mov	x3, x23
    3e48:	a95463f7 	ldp	x23, x24, [sp, #320]
    3e4c:	aa1603e0 	mov	x0, x22
    3e50:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3e54:	1e604121 	fmov	d1, d9
    3e58:	1e604100 	fmov	d0, d8
    3e5c:	d0000022 	adrp	x2, 9000 <__modti3+0x330>
    3e60:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3e64:	9107a042 	add	x2, x2, #0x1e8
    3e68:	9105c3ff 	add	sp, sp, #0x170
    3e6c:	52800041 	mov	w1, #0x2                   	// #2
    3e70:	17fffaa0 	b	28f0 <__fprintf_chk@plt>
    3e74:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3e78:	17ffffe7 	b	3e14 <fwp_heap_report+0xf4>
    3e7c:	a91253f3 	stp	x19, x20, [sp, #288]
    3e80:	97fffa80 	bl	2880 <__stack_chk_fail@plt>

0000000000003e84 <fwp_heap_init>:
    3e84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e88:	f0000163 	adrp	x3, 32000 <fwp_heap+0xab0>
    3e8c:	91114061 	add	x1, x3, #0x450
    3e90:	910003fd 	mov	x29, sp
    3e94:	a90153f3 	stp	x19, x20, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3e9c:	91154262 	add	x2, x19, #0x550
    3ea0:	a9025bf5 	stp	x21, x22, [sp, #32]
    3ea4:	52800024 	mov	w4, #0x1                   	// #1
    3ea8:	52800200 	mov	w0, #0x10                  	// #16
    3eac:	b913a444 	str	w4, [x2, #5028]
    3eb0:	b8004420 	str	w0, [x1], #4
    3eb4:	11004000 	add	w0, w0, #0x10
    3eb8:	7104401f 	cmp	w0, #0x110
    3ebc:	54ffffa1 	b.ne	3eb0 <fwp_heap_init+0x2c>  // b.any
    3ec0:	d0000022 	adrp	x2, 9000 <__modti3+0x330>
    3ec4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ec8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xab0>
    3ecc:	91124021 	add	x1, x1, #0x490
    3ed0:	3dc32043 	ldr	q3, [x2, #3200]
    3ed4:	d2800000 	mov	x0, #0x0                   	// #0
    3ed8:	4e040401 	dup	v1.4s, v0.s[0]
    3edc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ee0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ee4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ee8:	3ca06821 	str	q1, [x1, x0]
    3eec:	91004000 	add	x0, x0, #0x10
    3ef0:	f101801f 	cmp	x0, #0x60
    3ef4:	54ffff21 	b.ne	3ed8 <fwp_heap_init+0x54>  // b.any
    3ef8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xab0>
    3efc:	91114063 	add	x3, x3, #0x450
    3f00:	9113c084 	add	x4, x4, #0x4f0
    3f04:	91154266 	add	x6, x19, #0x550
    3f08:	d2800002 	mov	x2, #0x0                   	// #0
    3f0c:	d2800000 	mov	x0, #0x0                   	// #0
    3f10:	d2880205 	mov	x5, #0x4010                	// #16400
    3f14:	d503201f 	nop
    3f18:	910f0001 	add	x1, x0, #0x3c0
    3f1c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3f20:	eb02003f 	cmp	x1, x2
    3f24:	540000a2 	b.cs	3f38 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3f28:	91000400 	add	x0, x0, #0x1
    3f2c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3f30:	eb02003f 	cmp	x1, x2
    3f34:	54ffffa3 	b.cc	3f28 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3f38:	91004042 	add	x2, x2, #0x10
    3f3c:	38001480 	strb	w0, [x4], #1
    3f40:	eb05005f 	cmp	x2, x5
    3f44:	54fffea1 	b.ne	3f18 <fwp_heap_init+0x94>  // b.any
    3f48:	528000b5 	mov	w21, #0x5                   	// #5
    3f4c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3f50:	14000004 	b	3f60 <fwp_heap_init+0xdc>
    3f54:	d342fe94 	lsr	x20, x20, #2
    3f58:	710006b5 	subs	w21, w21, #0x1
    3f5c:	54000720 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3f60:	91404296 	add	x22, x20, #0x10, lsl #12
    3f64:	d2800005 	mov	x5, #0x0                   	// #0
    3f68:	aa1603e1 	mov	x1, x22
    3f6c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f70:	52880443 	mov	w3, #0x4022                	// #16418
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	d2800000 	mov	x0, #0x0                   	// #0
    3f7c:	97fffa65 	bl	2910 <mmap@plt>
    3f80:	aa0003e6 	mov	x6, x0
    3f84:	b100041f 	cmn	x0, #0x1
    3f88:	54fffe60 	b.eq	3f54 <fwp_heap_init+0xd0>  // b.none
    3f8c:	b40005a0 	cbz	x0, 4040 <fwp_heap_init+0x1bc>
    3f90:	d350fe94 	lsr	x20, x20, #16
    3f94:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f98:	8b0000c7 	add	x7, x6, x0
    3f9c:	91154275 	add	x21, x19, #0x550
    3fa0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3fa4:	8b140a81 	add	x1, x20, x20, lsl #2
    3fa8:	d2800005 	mov	x5, #0x0                   	// #0
    3fac:	12800004 	mov	w4, #0xffffffff            	// #-1
    3fb0:	d37df021 	lsl	x1, x1, #3
    3fb4:	52880443 	mov	w3, #0x4022                	// #16418
    3fb8:	52800002 	mov	w2, #0x0                   	// #0
    3fbc:	d2800000 	mov	x0, #0x0                   	// #0
    3fc0:	f909daa7 	str	x7, [x21, #5040]
    3fc4:	f909dea6 	str	x6, [x21, #5048]
    3fc8:	f909e2b6 	str	x22, [x21, #5056]
    3fcc:	f909eab4 	str	x20, [x21, #5072]
    3fd0:	f90a02a1 	str	x1, [x21, #5120]
    3fd4:	97fffa4f 	bl	2910 <mmap@plt>
    3fd8:	aa0003e1 	mov	x1, x0
    3fdc:	b100041f 	cmn	x0, #0x1
    3fe0:	54000300 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3fe4:	d0000020 	adrp	x0, 9000 <__modti3+0x330>
    3fe8:	910a6000 	add	x0, x0, #0x298
    3fec:	f909fea1 	str	x1, [x21, #5112]
    3ff0:	97fffa88 	bl	2a10 <getenv@plt>
    3ff4:	52800002 	mov	w2, #0x0                   	// #0
    3ff8:	aa0003e1 	mov	x1, x0
    3ffc:	b40000e0 	cbz	x0, 4018 <fwp_heap_init+0x194>
    4000:	39400000 	ldrb	w0, [x0]
    4004:	340000a0 	cbz	w0, 4018 <fwp_heap_init+0x194>
    4008:	7100c000 	subs	w0, w0, #0x30
    400c:	54000120 	b.eq	4030 <fwp_heap_init+0x1ac>  // b.none
    4010:	7100001f 	cmp	w0, #0x0
    4014:	1a9f07e2 	cset	w2, ne	// ne = any
    4018:	91154273 	add	x19, x19, #0x550
    401c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4020:	b913aa62 	str	w2, [x19, #5032]
    4024:	a94153f3 	ldp	x19, x20, [sp, #16]
    4028:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402c:	d65f03c0 	ret
    4030:	39400420 	ldrb	w0, [x1, #1]
    4034:	7100001f 	cmp	w0, #0x0
    4038:	1a9f07e2 	cset	w2, ne	// ne = any
    403c:	17fffff7 	b	4018 <fwp_heap_init+0x194>
    4040:	97fffbfc 	bl	3030 <fwp_heap_oom>

0000000000004044 <caf75>:
    4044:	900000e2 	adrp	x2, 20000 <__data_start>
    4048:	9100c041 	add	x1, x2, #0x30
    404c:	b9404820 	ldr	w0, [x1, #72]
    4050:	34000060 	cbz	w0, 405c <caf75+0x18>
    4054:	f9402820 	ldr	x0, [x1, #80]
    4058:	d65f03c0 	ret
    405c:	b9405820 	ldr	w0, [x1, #88]
    4060:	340000e0 	cbz	w0, 407c <caf75+0x38>
    4064:	f9403020 	ldr	x0, [x1, #96]
    4068:	9100c042 	add	x2, x2, #0x30
    406c:	52800021 	mov	w1, #0x1                   	// #1
    4070:	b9004841 	str	w1, [x2, #72]
    4074:	f9002840 	str	x0, [x2, #80]
    4078:	d65f03c0 	ret
    407c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4080:	52800024 	mov	w4, #0x1                   	// #1
    4084:	aa0303e0 	mov	x0, x3
    4088:	b9005824 	str	w4, [x1, #88]
    408c:	f9003023 	str	x3, [x1, #96]
    4090:	17fffff6 	b	4068 <caf75+0x24>

0000000000004094 <fwp_wake_io>:
    4094:	900000e9 	adrp	x9, 20000 <__data_start>
    4098:	9100c122 	add	x2, x9, #0x30
    409c:	f9400001 	ldr	x1, [x0]
    40a0:	5280000a 	mov	w10, #0x0                   	// #0
    40a4:	f9401446 	ldr	x6, [x2, #40]
    40a8:	52800008 	mov	w8, #0x0                   	// #0
    40ac:	4f000400 	movi	v0.4s, #0x0
    40b0:	52800027 	mov	w7, #0x1                   	// #1
    40b4:	aa0103e2 	mov	x2, x1
    40b8:	b4000321 	cbz	x1, 411c <fwp_wake_io+0x88>
    40bc:	f9408c25 	ldr	x5, [x1, #280]
    40c0:	39015c27 	strb	w7, [x1, #87]
    40c4:	b4000165 	cbz	x5, 40f0 <fwp_wake_io+0x5c>
    40c8:	a9520c24 	ldp	x4, x3, [x1, #288]
    40cc:	b4000364 	cbz	x4, 4138 <fwp_wake_io+0xa4>
    40d0:	f9009483 	str	x3, [x4, #296]
    40d4:	f9409423 	ldr	x3, [x1, #296]
    40d8:	b4000043 	cbz	x3, 40e0 <fwp_wake_io+0x4c>
    40dc:	f9009064 	str	x4, [x3, #288]
    40e0:	91080023 	add	x3, x1, #0x200
    40e4:	f900943f 	str	xzr, [x1, #296]
    40e8:	3c918060 	stur	q0, [x3, #-232]
    40ec:	f9400001 	ldr	x1, [x0]
    40f0:	f9402843 	ldr	x3, [x2, #80]
    40f4:	f2001c7f 	tst	x3, #0xff000000ff
    40f8:	54fffde1 	b.ne	40b4 <fwp_wake_io+0x20>  // b.any
    40fc:	39015047 	strb	w7, [x2, #84]
    4100:	f900805f 	str	xzr, [x2, #256]
    4104:	b40001e6 	cbz	x6, 4140 <fwp_wake_io+0xac>
    4108:	f90080c2 	str	x2, [x6, #256]
    410c:	aa0203e6 	mov	x6, x2
    4110:	52800028 	mov	w8, #0x1                   	// #1
    4114:	aa0103e2 	mov	x2, x1
    4118:	b5fffd21 	cbnz	x1, 40bc <fwp_wake_io+0x28>
    411c:	3400006a 	cbz	w10, 4128 <fwp_wake_io+0x94>
    4120:	9100c120 	add	x0, x9, #0x30
    4124:	f900180b 	str	x11, [x0, #48]
    4128:	34000068 	cbz	w8, 4134 <fwp_wake_io+0xa0>
    412c:	9100c129 	add	x9, x9, #0x30
    4130:	f9001526 	str	x6, [x9, #40]
    4134:	d65f03c0 	ret
    4138:	f90000a3 	str	x3, [x5]
    413c:	17ffffe7 	b	40d8 <fwp_wake_io+0x44>
    4140:	aa0203eb 	mov	x11, x2
    4144:	5280002a 	mov	w10, #0x1                   	// #1
    4148:	17fffff1 	b	410c <fwp_wake_io+0x78>
    414c:	d503201f 	nop

0000000000004150 <fwp_tape_buffers_release>:
    4150:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4154:	910003fd 	mov	x29, sp
    4158:	a90153f3 	stp	x19, x20, [sp, #16]
    415c:	aa0003f3 	mov	x19, x0
    4160:	f9401400 	ldr	x0, [x0, #40]
    4164:	b7f80760 	tbnz	x0, #63, 4250 <fwp_tape_buffers_release+0x100>
    4168:	f9401a61 	ldr	x1, [x19, #48]
    416c:	b7f80301 	tbnz	x1, #63, 41cc <fwp_tape_buffers_release+0x7c>
    4170:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4174:	eb02001f 	cmp	x0, x2
    4178:	540002a8 	b.hi	41cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    417c:	8b000400 	add	x0, x0, x0, lsl #1
    4180:	d2a00102 	mov	x2, #0x80000               	// #524288
    4184:	d37df000 	lsl	x0, x0, #3
    4188:	cb000042 	sub	x2, x2, x0
    418c:	eb420c3f 	cmp	x1, x2, lsr #3
    4190:	540001e8 	b.hi	41cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    4194:	8b010c14 	add	x20, x0, x1, lsl #3
    4198:	b0000020 	adrp	x0, 9000 <__modti3+0x330>
    419c:	910aa000 	add	x0, x0, #0x2a8
    41a0:	97fffa1c 	bl	2a10 <getenv@plt>
    41a4:	b4000240 	cbz	x0, 41ec <fwp_tape_buffers_release+0x9c>
    41a8:	39400001 	ldrb	w1, [x0]
    41ac:	7100c03f 	cmp	w1, #0x30
    41b0:	540001e1 	b.ne	41ec <fwp_tape_buffers_release+0x9c>  // b.any
    41b4:	39400400 	ldrb	w0, [x0, #1]
    41b8:	350001a0 	cbnz	w0, 41ec <fwp_tape_buffers_release+0x9c>
    41bc:	aa1303e0 	mov	x0, x19
    41c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41c8:	17fffc4e 	b	3300 <fwp_tape_buffers_dispose>
    41cc:	b0000020 	adrp	x0, 9000 <__modti3+0x330>
    41d0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    41d4:	910aa000 	add	x0, x0, #0x2a8
    41d8:	97fffa0e 	bl	2a10 <getenv@plt>
    41dc:	b4ffff00 	cbz	x0, 41bc <fwp_tape_buffers_release+0x6c>
    41e0:	39400001 	ldrb	w1, [x0]
    41e4:	7100c03f 	cmp	w1, #0x30
    41e8:	54fffe60 	b.eq	41b4 <fwp_tape_buffers_release+0x64>  // b.none
    41ec:	d1000681 	sub	x1, x20, #0x1
    41f0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41f4:	eb00003f 	cmp	x1, x0
    41f8:	54fffe28 	b.hi	41bc <fwp_tape_buffers_release+0x6c>  // b.pmore
    41fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4200:	900000f6 	adrp	x22, 20000 <__data_start>
    4204:	9100c2d6 	add	x22, x22, #0x30
    4208:	9101a2d5 	add	x21, x22, #0x68
    420c:	aa1503e0 	mov	x0, x21
    4210:	97fffc3c 	bl	3300 <fwp_tape_buffers_dispose>
    4214:	ad400a61 	ldp	q1, q2, [x19]
    4218:	f90052d4 	str	x20, [x22, #160]
    421c:	4f000400 	movi	v0.4s, #0x0
    4220:	ad000aa1 	stp	q1, q2, [x21]
    4224:	3dc00a61 	ldr	q1, [x19, #32]
    4228:	3d800aa1 	str	q1, [x21, #32]
    422c:	f9401a60 	ldr	x0, [x19, #48]
    4230:	f9001aa0 	str	x0, [x21, #48]
    4234:	f9001a7f 	str	xzr, [x19, #48]
    4238:	ad000260 	stp	q0, q0, [x19]
    423c:	3d800a60 	str	q0, [x19, #32]
    4240:	a94153f3 	ldp	x19, x20, [sp, #16]
    4244:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4248:	a8c37bfd 	ldp	x29, x30, [sp], #48
    424c:	d65f03c0 	ret
    4250:	b0000020 	adrp	x0, 9000 <__modti3+0x330>
    4254:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4258:	910aa000 	add	x0, x0, #0x2a8
    425c:	97fff9ed 	bl	2a10 <getenv@plt>
    4260:	b5fffa40 	cbnz	x0, 41a8 <fwp_tape_buffers_release+0x58>
    4264:	17ffffd6 	b	41bc <fwp_tape_buffers_release+0x6c>
    4268:	d503201f 	nop
    426c:	d503201f 	nop

0000000000004270 <fwp_poll_events>:
    4270:	d10103ff 	sub	sp, sp, #0x40
    4274:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4278:	f947f400 	ldr	x0, [x0, #4072]
    427c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4280:	910083fd 	add	x29, sp, #0x20
    4284:	a90353f3 	stp	x19, x20, [sp, #48]
    4288:	900000f4 	adrp	x20, 20000 <__data_start>
    428c:	f9400001 	ldr	x1, [x0]
    4290:	f9000fe1 	str	x1, [sp, #24]
    4294:	d2800001 	mov	x1, #0x0                   	// #0
    4298:	97fffd1a 	bl	3700 <fwp_now_ns>
    429c:	9100c281 	add	x1, x20, #0x30
    42a0:	f9405433 	ldr	x19, [x1, #168]
    42a4:	b4000e93 	cbz	x19, 4474 <fwp_poll_events+0x204>
    42a8:	aa1303e1 	mov	x1, x19
    42ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    42b0:	14000005 	b	42c4 <fwp_poll_events+0x54>
    42b4:	f9408821 	ldr	x1, [x1, #272]
    42b8:	eb03005f 	cmp	x2, x3
    42bc:	9a83d042 	csel	x2, x2, x3, le
    42c0:	b40000c1 	cbz	x1, 42d8 <fwp_poll_events+0x68>
    42c4:	f9403423 	ldr	x3, [x1, #104]
    42c8:	b6ffff62 	tbz	x2, #63, 42b4 <fwp_poll_events+0x44>
    42cc:	f9408821 	ldr	x1, [x1, #272]
    42d0:	aa0303e2 	mov	x2, x3
    42d4:	b5ffff81 	cbnz	x1, 42c4 <fwp_poll_events+0x54>
    42d8:	b7f80ce2 	tbnz	x2, #63, 4474 <fwp_poll_events+0x204>
    42dc:	cb000042 	sub	x2, x2, x0
    42e0:	f100005f 	cmp	x2, #0x0
    42e4:	540005cd 	b.le	439c <fwp_poll_events+0x12c>
    42e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    42ec:	d2884801 	mov	x1, #0x4240                	// #16960
    42f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    42f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    42f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    42fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4300:	f2e86360 	movk	x0, #0x431b, lsl #48
    4304:	9b407c40 	smulh	x0, x2, x0
    4308:	9352fc00 	asr	x0, x0, #18
    430c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4310:	9b018802 	msub	x2, x0, x1, x2
    4314:	f100005f 	cmp	x2, #0x0
    4318:	9a800400 	cinc	x0, x0, ne	// ne = any
    431c:	eb03001f 	cmp	x0, x3
    4320:	54000a0c 	b.gt	4460 <fwp_poll_events+0x1f0>
    4324:	340003c0 	cbz	w0, 439c <fwp_poll_events+0x12c>
    4328:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    432c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4330:	72a20c42 	movk	w2, #0x1062, lsl #16
    4334:	9ba27c02 	umull	x2, w0, w2
    4338:	d366fc43 	lsr	x3, x2, #38
    433c:	aa0303e2 	mov	x2, x3
    4340:	1b048063 	msub	w3, w3, w4, w0
    4344:	9b217c63 	smull	x3, w3, w1
    4348:	d2800001 	mov	x1, #0x0                   	// #0
    434c:	910023e0 	add	x0, sp, #0x8
    4350:	a9008fe2 	stp	x2, x3, [sp, #8]
    4354:	97fff97f 	bl	2950 <nanosleep@plt>
    4358:	9100c280 	add	x0, x20, #0x30
    435c:	f9405413 	ldr	x19, [x0, #168]
    4360:	97fffce8 	bl	3700 <fwp_now_ns>
    4364:	aa0003e6 	mov	x6, x0
    4368:	b50001f3 	cbnz	x19, 43a4 <fwp_poll_events+0x134>
    436c:	d503201f 	nop
    4370:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4374:	f947f400 	ldr	x0, [x0, #4072]
    4378:	f9400fe2 	ldr	x2, [sp, #24]
    437c:	f9400001 	ldr	x1, [x0]
    4380:	eb010042 	subs	x2, x2, x1
    4384:	d2800001 	mov	x1, #0x0                   	// #0
    4388:	540008c1 	b.ne	44a0 <fwp_poll_events+0x230>  // b.any
    438c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4390:	a94353f3 	ldp	x19, x20, [sp, #48]
    4394:	910103ff 	add	sp, sp, #0x40
    4398:	d65f03c0 	ret
    439c:	97fffcd9 	bl	3700 <fwp_now_ns>
    43a0:	aa0003e6 	mov	x6, x0
    43a4:	4f000400 	movi	v0.4s, #0x0
    43a8:	9100c288 	add	x8, x20, #0x30
    43ac:	52800027 	mov	w7, #0x1                   	// #1
    43b0:	f9403661 	ldr	x1, [x19, #104]
    43b4:	aa1303e5 	mov	x5, x19
    43b8:	f9408a73 	ldr	x19, [x19, #272]
    43bc:	eb06003f 	cmp	x1, x6
    43c0:	5400032c 	b.gt	4424 <fwp_poll_events+0x1b4>
    43c4:	394154a0 	ldrb	w0, [x5, #85]
    43c8:	36000120 	tbz	w0, #0, 43ec <fwp_poll_events+0x17c>
    43cc:	f94084a0 	ldr	x0, [x5, #264]
    43d0:	b40003c0 	cbz	x0, 4448 <fwp_poll_events+0x1d8>
    43d4:	f9008813 	str	x19, [x0, #272]
    43d8:	b4000053 	cbz	x19, 43e0 <fwp_poll_events+0x170>
    43dc:	f9008660 	str	x0, [x19, #264]
    43e0:	910800a0 	add	x0, x5, #0x200
    43e4:	390154bf 	strb	wzr, [x5, #85]
    43e8:	3c908000 	stur	q0, [x0, #-248]
    43ec:	f94030a0 	ldr	x0, [x5, #96]
    43f0:	390158a7 	strb	w7, [x5, #86]
    43f4:	f100001f 	cmp	x0, #0x0
    43f8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    43fc:	5400018d 	b.le	442c <fwp_poll_events+0x1bc>
    4400:	f94028a0 	ldr	x0, [x5, #80]
    4404:	f2001c1f 	tst	x0, #0xff000000ff
    4408:	540000e1 	b.ne	4424 <fwp_poll_events+0x1b4>  // b.any
    440c:	f9401500 	ldr	x0, [x8, #40]
    4410:	390150a7 	strb	w7, [x5, #84]
    4414:	f90080bf 	str	xzr, [x5, #256]
    4418:	b40001e0 	cbz	x0, 4454 <fwp_poll_events+0x1e4>
    441c:	f9001505 	str	x5, [x8, #40]
    4420:	f9008005 	str	x5, [x0, #256]
    4424:	b5fffc73 	cbnz	x19, 43b0 <fwp_poll_events+0x140>
    4428:	17ffffd2 	b	4370 <fwp_poll_events+0x100>
    442c:	394144a0 	ldrb	w0, [x5, #81]
    4430:	3707fe80 	tbnz	w0, #0, 4400 <fwp_poll_events+0x190>
    4434:	394140a0 	ldrb	w0, [x5, #80]
    4438:	3707fe40 	tbnz	w0, #0, 4400 <fwp_poll_events+0x190>
    443c:	aa0503e0 	mov	x0, x5
    4440:	97fffc0c 	bl	3470 <fwp_cancel_tree.part.0>
    4444:	17ffffef 	b	4400 <fwp_poll_events+0x190>
    4448:	9100c281 	add	x1, x20, #0x30
    444c:	f9005433 	str	x19, [x1, #168]
    4450:	17ffffe2 	b	43d8 <fwp_poll_events+0x168>
    4454:	f9001505 	str	x5, [x8, #40]
    4458:	f9001905 	str	x5, [x8, #48]
    445c:	17fffff2 	b	4424 <fwp_poll_events+0x1b4>
    4460:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4464:	d2989362 	mov	x2, #0xc49b                	// #50331
    4468:	f2a4d203 	movk	x3, #0x2690, lsl #16
    446c:	f2a00402 	movk	x2, #0x20, lsl #16
    4470:	17ffffb6 	b	4348 <fwp_poll_events+0xd8>
    4474:	97fffadf 	bl	2ff0 <fwp_flush>
    4478:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    447c:	f947e863 	ldr	x3, [x3, #4048]
    4480:	d2800562 	mov	x2, #0x2b                  	// #43
    4484:	d2800021 	mov	x1, #0x1                   	// #1
    4488:	b0000020 	adrp	x0, 9000 <__modti3+0x330>
    448c:	910b0000 	add	x0, x0, #0x2c0
    4490:	f9400063 	ldr	x3, [x3]
    4494:	97fff93b 	bl	2980 <fwrite@plt>
    4498:	52800ca0 	mov	w0, #0x65                  	// #101
    449c:	97fff8a5 	bl	2730 <exit@plt>
    44a0:	97fff8f8 	bl	2880 <__stack_chk_fail@plt>

00000000000044a4 <fwp_rc_wide_dup>:
    44a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	aa0003f3 	mov	x19, x0
    44b4:	ca404400 	eor	x0, x0, x0, lsr #17
    44b8:	f90013f5 	str	x21, [sp, #32]
    44bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    44c0:	ca402400 	eor	x0, x0, x0, lsr #9
    44c4:	911542a2 	add	x2, x21, #0x550
    44c8:	92401c00 	and	x0, x0, #0xff
    44cc:	910a2403 	add	x3, x0, #0x289
    44d0:	8b000c40 	add	x0, x2, x0, lsl #3
    44d4:	8b030c54 	add	x20, x2, x3, lsl #3
    44d8:	f94a2401 	ldr	x1, [x0, #5192]
    44dc:	b50000a1 	cbnz	x1, 44f0 <fwp_rc_wide_dup+0x4c>
    44e0:	1400002d 	b	4594 <fwp_rc_wide_dup+0xf0>
    44e4:	91004034 	add	x20, x1, #0x10
    44e8:	f9400821 	ldr	x1, [x1, #16]
    44ec:	b4000241 	cbz	x1, 4534 <fwp_rc_wide_dup+0x90>
    44f0:	f9400022 	ldr	x2, [x1]
    44f4:	eb02027f 	cmp	x19, x2
    44f8:	54ffff61 	b.ne	44e4 <fwp_rc_wide_dup+0x40>  // b.any
    44fc:	f9400281 	ldr	x1, [x20]
    4500:	39400260 	ldrb	w0, [x19]
    4504:	7103f81f 	cmp	w0, #0xfe
    4508:	54000220 	b.eq	454c <fwp_rc_wide_dup+0xa8>  // b.none
    450c:	b40001a1 	cbz	x1, 4540 <fwp_rc_wide_dup+0x9c>
    4510:	f9400420 	ldr	x0, [x1, #8]
    4514:	b100041f 	cmn	x0, #0x1
    4518:	540004a0 	b.eq	45ac <fwp_rc_wide_dup+0x108>  // b.none
    451c:	91000400 	add	x0, x0, #0x1
    4520:	f9000420 	str	x0, [x1, #8]
    4524:	a94153f3 	ldp	x19, x20, [sp, #16]
    4528:	f94013f5 	ldr	x21, [sp, #32]
    452c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4530:	d65f03c0 	ret
    4534:	39400260 	ldrb	w0, [x19]
    4538:	7103f81f 	cmp	w0, #0xfe
    453c:	540000a0 	b.eq	4550 <fwp_rc_wide_dup+0xac>  // b.none
    4540:	b0000020 	adrp	x0, 9000 <__modti3+0x330>
    4544:	910c6000 	add	x0, x0, #0x318
    4548:	97fffc0e 	bl	3580 <fwp_trap>
    454c:	b5000281 	cbnz	x1, 459c <fwp_rc_wide_dup+0xf8>
    4550:	d2800300 	mov	x0, #0x18                  	// #24
    4554:	97fff8b3 	bl	2820 <malloc@plt>
    4558:	b4000280 	cbz	x0, 45a8 <fwp_rc_wide_dup+0x104>
    455c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4560:	a9000413 	stp	x19, x1, [x0]
    4564:	911542b5 	add	x21, x21, #0x550
    4568:	f900081f 	str	xzr, [x0, #16]
    456c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4570:	f9000280 	str	x0, [x20]
    4574:	39000261 	strb	w1, [x19]
    4578:	f94e26a0 	ldr	x0, [x21, #7240]
    457c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4580:	91000400 	add	x0, x0, #0x1
    4584:	f90e26a0 	str	x0, [x21, #7240]
    4588:	f94013f5 	ldr	x21, [sp, #32]
    458c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4590:	d65f03c0 	ret
    4594:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4598:	17ffffda 	b	4500 <fwp_rc_wide_dup+0x5c>
    459c:	b0000020 	adrp	x0, 9000 <__modti3+0x330>
    45a0:	910bc000 	add	x0, x0, #0x2f0
    45a4:	97fffbf7 	bl	3580 <fwp_trap>
    45a8:	97fffaa2 	bl	3030 <fwp_heap_oom>
    45ac:	b0000020 	adrp	x0, 9000 <__modti3+0x330>
    45b0:	910d0000 	add	x0, x0, #0x340
    45b4:	97fffbf3 	bl	3580 <fwp_trap>
    45b8:	d503201f 	nop
    45bc:	d503201f 	nop

00000000000045c0 <fwp_rc_forget_slot>:
    45c0:	aa0003e1 	mov	x1, x0
    45c4:	39400000 	ldrb	w0, [x0]
    45c8:	7103fc1f 	cmp	w0, #0xff
    45cc:	54000040 	b.eq	45d4 <fwp_rc_forget_slot+0x14>  // b.none
    45d0:	d65f03c0 	ret
    45d4:	ca414420 	eor	x0, x1, x1, lsr #17
    45d8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    45dc:	ca402400 	eor	x0, x0, x0, lsr #9
    45e0:	910003fd 	mov	x29, sp
    45e4:	92401c00 	and	x0, x0, #0xff
    45e8:	f9000bf3 	str	x19, [sp, #16]
    45ec:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    45f0:	91154262 	add	x2, x19, #0x550
    45f4:	910a2403 	add	x3, x0, #0x289
    45f8:	8b000c40 	add	x0, x2, x0, lsl #3
    45fc:	8b030c43 	add	x3, x2, x3, lsl #3
    4600:	f94a2400 	ldr	x0, [x0, #5192]
    4604:	b50000a0 	cbnz	x0, 4618 <fwp_rc_forget_slot+0x58>
    4608:	14000011 	b	464c <fwp_rc_forget_slot+0x8c>
    460c:	91004003 	add	x3, x0, #0x10
    4610:	f9400800 	ldr	x0, [x0, #16]
    4614:	b40001c0 	cbz	x0, 464c <fwp_rc_forget_slot+0x8c>
    4618:	f9400002 	ldr	x2, [x0]
    461c:	eb02003f 	cmp	x1, x2
    4620:	54ffff61 	b.ne	460c <fwp_rc_forget_slot+0x4c>  // b.any
    4624:	f9400801 	ldr	x1, [x0, #16]
    4628:	91154273 	add	x19, x19, #0x550
    462c:	f9000061 	str	x1, [x3]
    4630:	97fff8c4 	bl	2940 <free@plt>
    4634:	f94e2660 	ldr	x0, [x19, #7240]
    4638:	d1000400 	sub	x0, x0, #0x1
    463c:	f90e2660 	str	x0, [x19, #7240]
    4640:	f9400bf3 	ldr	x19, [sp, #16]
    4644:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4648:	d65f03c0 	ret
    464c:	b0000020 	adrp	x0, 9000 <__modti3+0x330>
    4650:	910c6000 	add	x0, x0, #0x318
    4654:	97fffbcb 	bl	3580 <fwp_trap>
    4658:	d503201f 	nop
    465c:	d503201f 	nop

0000000000004660 <fwp_rc_prepare_chunk>:
    4660:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4664:	910003fd 	mov	x29, sp
    4668:	a9025bf5 	stp	x21, x22, [sp, #32]
    466c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    4670:	911542c2 	add	x2, x22, #0x550
    4674:	b9401c03 	ldr	w3, [x0, #28]
    4678:	aa0103f5 	mov	x21, x1
    467c:	a90153f3 	stp	x19, x20, [sp, #16]
    4680:	aa0003f4 	mov	x20, x0
    4684:	f94e2440 	ldr	x0, [x2, #7240]
    4688:	b4000440 	cbz	x0, 4710 <fwp_rc_prepare_chunk+0xb0>
    468c:	d2800013 	mov	x19, #0x0                   	// #0
    4690:	35000203 	cbnz	w3, 46d0 <fwp_rc_prepare_chunk+0x70>
    4694:	b4000361 	cbz	x1, 4700 <fwp_rc_prepare_chunk+0xa0>
    4698:	f9401280 	ldr	x0, [x20, #32]
    469c:	97fff8a9 	bl	2940 <free@plt>
    46a0:	aa1503e0 	mov	x0, x21
    46a4:	d2800021 	mov	x1, #0x1                   	// #1
    46a8:	97fff86e 	bl	2860 <calloc@plt>
    46ac:	f9001280 	str	x0, [x20, #32]
    46b0:	b5000460 	cbnz	x0, 473c <fwp_rc_prepare_chunk+0xdc>
    46b4:	97fffa5f 	bl	3030 <fwp_heap_oom>
    46b8:	97ffffc2 	bl	45c0 <fwp_rc_forget_slot>
    46bc:	91000673 	add	x19, x19, #0x1
    46c0:	b9401e83 	ldr	w3, [x20, #28]
    46c4:	eb13007f 	cmp	x3, x19
    46c8:	54000169 	b.ls	46f4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    46cc:	d503201f 	nop
    46d0:	f9401283 	ldr	x3, [x20, #32]
    46d4:	8b130060 	add	x0, x3, x19
    46d8:	38736863 	ldrb	w3, [x3, x19]
    46dc:	7103fc7f 	cmp	w3, #0xff
    46e0:	54fffec0 	b.eq	46b8 <fwp_rc_prepare_chunk+0x58>  // b.none
    46e4:	b9401e83 	ldr	w3, [x20, #28]
    46e8:	91000673 	add	x19, x19, #0x1
    46ec:	eb13007f 	cmp	x3, x19
    46f0:	54ffff08 	b.hi	46d0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    46f4:	eb0302bf 	cmp	x21, x3
    46f8:	54000121 	b.ne	471c <fwp_rc_prepare_chunk+0xbc>  // b.any
    46fc:	b5000335 	cbnz	x21, 4760 <fwp_rc_prepare_chunk+0x100>
    4700:	a94153f3 	ldp	x19, x20, [sp, #16]
    4704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4708:	a8c37bfd 	ldp	x29, x30, [sp], #48
    470c:	d65f03c0 	ret
    4710:	2a0303e3 	mov	w3, w3
    4714:	eb0302bf 	cmp	x21, x3
    4718:	54ffff20 	b.eq	46fc <fwp_rc_prepare_chunk+0x9c>  // b.none
    471c:	911542c2 	add	x2, x22, #0x550
    4720:	f9401280 	ldr	x0, [x20, #32]
    4724:	f94e2841 	ldr	x1, [x2, #7248]
    4728:	cb030021 	sub	x1, x1, x3
    472c:	f90e2841 	str	x1, [x2, #7248]
    4730:	97fff884 	bl	2940 <free@plt>
    4734:	b5fffb75 	cbnz	x21, 46a0 <fwp_rc_prepare_chunk+0x40>
    4738:	f900129f 	str	xzr, [x20, #32]
    473c:	911542d6 	add	x22, x22, #0x550
    4740:	f94e2ac0 	ldr	x0, [x22, #7248]
    4744:	b9001e95 	str	w21, [x20, #28]
    4748:	a94153f3 	ldp	x19, x20, [sp, #16]
    474c:	8b150000 	add	x0, x0, x21
    4750:	f90e2ac0 	str	x0, [x22, #7248]
    4754:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4758:	a8c37bfd 	ldp	x29, x30, [sp], #48
    475c:	d65f03c0 	ret
    4760:	f9401280 	ldr	x0, [x20, #32]
    4764:	aa1503e2 	mov	x2, x21
    4768:	a94153f3 	ldp	x19, x20, [sp, #16]
    476c:	52800001 	mov	w1, #0x0                   	// #0
    4770:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4774:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4778:	17fff836 	b	2850 <memset@plt>
    477c:	d503201f 	nop

0000000000004780 <fwp_heap_refill>:
    4780:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4784:	910003fd 	mov	x29, sp
    4788:	a9025bf5 	stp	x21, x22, [sp, #32]
    478c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4790:	911542b5 	add	x21, x21, #0x550
    4794:	aa0003f6 	mov	x22, x0
    4798:	d2800020 	mov	x0, #0x1                   	// #1
    479c:	a90153f3 	stp	x19, x20, [sp, #16]
    47a0:	a90363f7 	stp	x23, x24, [sp, #48]
    47a4:	2a0103f7 	mov	w23, w1
    47a8:	2a0203f8 	mov	w24, w2
    47ac:	97fffa61 	bl	3130 <fwp_heap_chunks>
    47b0:	aa0003f3 	mov	x19, x0
    47b4:	f949fea2 	ldr	x2, [x21, #5112]
    47b8:	8b000800 	add	x0, x0, x0, lsl #2
    47bc:	2a1703e1 	mov	w1, w23
    47c0:	52800025 	mov	w5, #0x1                   	// #1
    47c4:	d37df000 	lsl	x0, x0, #3
    47c8:	910f0021 	add	x1, x1, #0x3c0
    47cc:	8b000054 	add	x20, x2, x0
    47d0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    47d4:	52a00024 	mov	w4, #0x10000               	// #65536
    47d8:	38206845 	strb	w5, [x2, x0]
    47dc:	aa1403e0 	mov	x0, x20
    47e0:	39000698 	strb	w24, [x20, #1]
    47e4:	39000a97 	strb	w23, [x20, #2]
    47e8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    47ec:	b9000681 	str	w1, [x20, #4]
    47f0:	2a0103e5 	mov	w5, w1
    47f4:	8b0300a2 	add	x2, x5, x3
    47f8:	1ac10881 	udiv	w1, w4, w1
    47fc:	9ac50842 	udiv	x2, x2, x5
    4800:	b9000a81 	str	w1, [x20, #8]
    4804:	92404021 	and	x1, x1, #0x1ffff
    4808:	b9001a82 	str	w2, [x20, #24]
    480c:	97ffff95 	bl	4660 <fwp_rc_prepare_chunk>
    4810:	f949daa0 	ldr	x0, [x21, #5040]
    4814:	29408a81 	ldp	w1, w2, [x20, #4]
    4818:	8b134000 	add	x0, x0, x19, lsl #16
    481c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4820:	8b214003 	add	x3, x0, w1, uxtw
    4824:	9ba20021 	umaddl	x1, w1, w2, x0
    4828:	a94363f7 	ldp	x23, x24, [sp, #48]
    482c:	a90086c3 	stp	x3, x1, [x22, #8]
    4830:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4834:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4838:	d65f03c0 	ret
    483c:	d503201f 	nop

0000000000004840 <fwp_mem_free>:
    4840:	b40003c0 	cbz	x0, 48b8 <fwp_mem_free+0x78>
    4844:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4848:	910003fd 	mov	x29, sp
    484c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4850:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4854:	911542a1 	add	x1, x21, #0x550
    4858:	a90153f3 	stp	x19, x20, [sp, #16]
    485c:	aa0003f3 	mov	x19, x0
    4860:	f949d823 	ldr	x3, [x1, #5040]
    4864:	f949ec22 	ldr	x2, [x1, #5080]
    4868:	cb030000 	sub	x0, x0, x3
    486c:	eb02401f 	cmp	x0, x2, lsl #16
    4870:	540001c2 	b.cs	48a8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4874:	d350fc16 	lsr	x22, x0, #16
    4878:	a90363f7 	stp	x23, x24, [sp, #48]
    487c:	f949fc22 	ldr	x2, [x1, #5112]
    4880:	8b160ad4 	add	x20, x22, x22, lsl #2
    4884:	d37df294 	lsl	x20, x20, #3
    4888:	ab140057 	adds	x23, x2, x20
    488c:	540000c0 	b.eq	48a4 <fwp_mem_free+0x64>  // b.none
    4890:	38746842 	ldrb	w2, [x2, x20]
    4894:	7100045f 	cmp	w2, #0x1
    4898:	54000120 	b.eq	48bc <fwp_mem_free+0x7c>  // b.none
    489c:	7100085f 	cmp	w2, #0x2
    48a0:	540005e0 	b.eq	495c <fwp_mem_free+0x11c>  // b.none
    48a4:	a94363f7 	ldp	x23, x24, [sp, #48]
    48a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    48b0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    48b4:	d65f03c0 	ret
    48b8:	d65f03c0 	ret
    48bc:	f94012f8 	ldr	x24, [x23, #32]
    48c0:	b94006e1 	ldr	w1, [x23, #4]
    48c4:	f90023f9 	str	x25, [sp, #64]
    48c8:	2a0103e2 	mov	w2, w1
    48cc:	394006f9 	ldrb	w25, [x23, #1]
    48d0:	39400af4 	ldrb	w20, [x23, #2]
    48d4:	b4000158 	cbz	x24, 48fc <fwp_mem_free+0xbc>
    48d8:	92403e76 	and	x22, x19, #0xffff
    48dc:	9ac20ad6 	udiv	x22, x22, x2
    48e0:	38766b01 	ldrb	w1, [x24, x22]
    48e4:	8b160300 	add	x0, x24, x22
    48e8:	7103fc3f 	cmp	w1, #0xff
    48ec:	54000980 	b.eq	4a1c <fwp_mem_free+0x1dc>  // b.none
    48f0:	38366b1f 	strb	wzr, [x24, x22]
    48f4:	b94006e1 	ldr	w1, [x23, #4]
    48f8:	2a0103e2 	mov	w2, w1
    48fc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4900:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4904:	cb390000 	sub	x0, x0, w25, uxtb
    4908:	8b340074 	add	x20, x3, w20, uxtb
    490c:	911542b5 	add	x21, x21, #0x550
    4910:	1e630021 	ucvtf	d1, w1
    4914:	d37ae400 	lsl	x0, x0, #6
    4918:	8b140c14 	add	x20, x0, x20, lsl #3
    491c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4920:	f8746aa0 	ldr	x0, [x21, x20]
    4924:	f94023f9 	ldr	x25, [sp, #64]
    4928:	aa2003e0 	mvn	x0, x0
    492c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4930:	f9000260 	str	x0, [x19]
    4934:	f8346ab3 	str	x19, [x21, x20]
    4938:	f94a12a0 	ldr	x0, [x21, #5152]
    493c:	1e612800 	fadd	d0, d0, d1
    4940:	a94153f3 	ldp	x19, x20, [sp, #16]
    4944:	cb020000 	sub	x0, x0, x2
    4948:	f90a12a0 	str	x0, [x21, #5152]
    494c:	fd0a22a0 	str	d0, [x21, #5184]
    4950:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4954:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4958:	d65f03c0 	ret
    495c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4960:	8b000063 	add	x3, x3, x0
    4964:	eb03027f 	cmp	x19, x3
    4968:	54fff9e1 	b.ne	48a4 <fwp_mem_free+0x64>  // b.any
    496c:	fd400ae1 	ldr	d1, [x23, #16]
    4970:	fd4a2020 	ldr	d0, [x1, #5184]
    4974:	f9400ae0 	ldr	x0, [x23, #16]
    4978:	7e61d821 	ucvtf	d1, d1
    497c:	f94a1022 	ldr	x2, [x1, #5152]
    4980:	f94012f3 	ldr	x19, [x23, #32]
    4984:	1e612800 	fadd	d0, d0, d1
    4988:	cb000042 	sub	x2, x2, x0
    498c:	f90a1022 	str	x2, [x1, #5152]
    4990:	fd0a2020 	str	d0, [x1, #5184]
    4994:	b40000b3 	cbz	x19, 49a8 <fwp_mem_free+0x168>
    4998:	39400260 	ldrb	w0, [x19]
    499c:	7103fc1f 	cmp	w0, #0xff
    49a0:	54000380 	b.eq	4a10 <fwp_mem_free+0x1d0>  // b.none
    49a4:	3900027f 	strb	wzr, [x19]
    49a8:	b9400ee2 	ldr	w2, [x23, #12]
    49ac:	b4000142 	cbz	x2, 49d4 <fwp_mem_free+0x194>
    49b0:	911542a1 	add	x1, x21, #0x550
    49b4:	8b160040 	add	x0, x2, x22
    49b8:	8b000800 	add	x0, x0, x0, lsl #2
    49bc:	f949fc21 	ldr	x1, [x1, #5112]
    49c0:	8b140034 	add	x20, x1, x20
    49c4:	8b000c20 	add	x0, x1, x0, lsl #3
    49c8:	3802869f 	strb	wzr, [x20], #40
    49cc:	eb00029f 	cmp	x20, x0
    49d0:	54ffffc1 	b.ne	49c8 <fwp_mem_free+0x188>  // b.any
    49d4:	911542a0 	add	x0, x21, #0x550
    49d8:	f94a1801 	ldr	x1, [x0, #5168]
    49dc:	f949f803 	ldr	x3, [x0, #5104]
    49e0:	8b020021 	add	x1, x1, x2
    49e4:	f90a1801 	str	x1, [x0, #5168]
    49e8:	eb16007f 	cmp	x3, x22
    49ec:	54000049 	b.ls	49f4 <fwp_mem_free+0x1b4>  // b.plast
    49f0:	f909f816 	str	x22, [x0, #5104]
    49f4:	911542b5 	add	x21, x21, #0x550
    49f8:	f949f6a0 	ldr	x0, [x21, #5096]
    49fc:	eb16001f 	cmp	x0, x22
    4a00:	54fff529 	b.ls	48a4 <fwp_mem_free+0x64>  // b.plast
    4a04:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a08:	f909f6b6 	str	x22, [x21, #5096]
    4a0c:	17ffffa7 	b	48a8 <fwp_mem_free+0x68>
    4a10:	aa1303e0 	mov	x0, x19
    4a14:	97fffeeb 	bl	45c0 <fwp_rc_forget_slot>
    4a18:	17ffffe3 	b	49a4 <fwp_mem_free+0x164>
    4a1c:	97fffee9 	bl	45c0 <fwp_rc_forget_slot>
    4a20:	17ffffb4 	b	48f0 <fwp_mem_free+0xb0>

0000000000004a24 <fwp_heap_alloc_big>:
    4a24:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4a28:	910003fd 	mov	x29, sp
    4a2c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a30:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a34:	a90363f7 	stp	x23, x24, [sp, #48]
    4a38:	aa0003f7 	mov	x23, x0
    4a3c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4a40:	a9046bf9 	stp	x25, x26, [sp, #64]
    4a44:	eb0002ff 	cmp	x23, x0
    4a48:	54000888 	b.hi	4b58 <fwp_heap_alloc_big+0x134>  // b.pmore
    4a4c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4a50:	8b0002f4 	add	x20, x23, x0
    4a54:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc90>
    4a58:	91154359 	add	x25, x26, #0x550
    4a5c:	d350fe94 	lsr	x20, x20, #16
    4a60:	2a0103f5 	mov	w21, w1
    4a64:	aa1403e0 	mov	x0, x20
    4a68:	97fff9b2 	bl	3130 <fwp_heap_chunks>
    4a6c:	f949ff22 	ldr	x2, [x25, #5112]
    4a70:	8b000813 	add	x19, x0, x0, lsl #2
    4a74:	aa0003f8 	mov	x24, x0
    4a78:	52800043 	mov	w3, #0x2                   	// #2
    4a7c:	d37df273 	lsl	x19, x19, #3
    4a80:	d2800021 	mov	x1, #0x1                   	// #1
    4a84:	8b130040 	add	x0, x2, x19
    4a88:	38336843 	strb	w3, [x2, x19]
    4a8c:	39000415 	strb	w21, [x0, #1]
    4a90:	b9000c14 	str	w20, [x0, #12]
    4a94:	f9000817 	str	x23, [x0, #16]
    4a98:	97fffef2 	bl	4660 <fwp_rc_prepare_chunk>
    4a9c:	f100069f 	cmp	x20, #0x1
    4aa0:	54000269 	b.ls	4aec <fwp_heap_alloc_big+0xc8>  // b.plast
    4aa4:	8b180294 	add	x20, x20, x24
    4aa8:	9100a273 	add	x19, x19, #0x28
    4aac:	a90573fb 	stp	x27, x28, [sp, #80]
    4ab0:	5280007b 	mov	w27, #0x3                   	// #3
    4ab4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ab8:	2a1803fc 	mov	w28, w24
    4abc:	9adb2296 	lsl	x22, x20, x27
    4ac0:	f949ff35 	ldr	x21, [x25, #5112]
    4ac4:	d2800001 	mov	x1, #0x0                   	// #0
    4ac8:	8b1302b4 	add	x20, x21, x19
    4acc:	aa1403e0 	mov	x0, x20
    4ad0:	97fffee4 	bl	4660 <fwp_rc_prepare_chunk>
    4ad4:	38336abb 	strb	w27, [x21, x19]
    4ad8:	9100a273 	add	x19, x19, #0x28
    4adc:	b9000e9c 	str	w28, [x20, #12]
    4ae0:	eb1302df 	cmp	x22, x19
    4ae4:	54fffee1 	b.ne	4ac0 <fwp_heap_alloc_big+0x9c>  // b.any
    4ae8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4aec:	91154353 	add	x19, x26, #0x550
    4af0:	aa1703e2 	mov	x2, x23
    4af4:	52800001 	mov	w1, #0x0                   	// #0
    4af8:	f949da60 	ldr	x0, [x19, #5040]
    4afc:	8b184018 	add	x24, x0, x24, lsl #16
    4b00:	aa1803e0 	mov	x0, x24
    4b04:	97fff753 	bl	2850 <memset@plt>
    4b08:	f94a1260 	ldr	x0, [x19, #5152]
    4b0c:	ab170000 	adds	x0, x0, x23
    4b10:	54000242 	b.cs	4b58 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4b14:	f94a1661 	ldr	x1, [x19, #5160]
    4b18:	f90a1260 	str	x0, [x19, #5152]
    4b1c:	eb01001f 	cmp	x0, x1
    4b20:	54000049 	b.ls	4b28 <fwp_heap_alloc_big+0x104>  // b.plast
    4b24:	f90a1660 	str	x0, [x19, #5160]
    4b28:	9115435a 	add	x26, x26, #0x550
    4b2c:	9e6202e0 	scvtf	d0, x23
    4b30:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b34:	aa1803e0 	mov	x0, x24
    4b38:	fd4a1f41 	ldr	d1, [x26, #5176]
    4b3c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b40:	1e602820 	fadd	d0, d1, d0
    4b44:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b48:	fd0a1f40 	str	d0, [x26, #5176]
    4b4c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b50:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b54:	d65f03c0 	ret
    4b58:	a90573fb 	stp	x27, x28, [sp, #80]
    4b5c:	97fff935 	bl	3030 <fwp_heap_oom>

0000000000004b60 <fwp_heap_alloc_slow>:
    4b60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b64:	910003fd 	mov	x29, sp
    4b68:	a90153f3 	stp	x19, x20, [sp, #16]
    4b6c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4b70:	91154262 	add	x2, x19, #0x550
    4b74:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b78:	aa0003f5 	mov	x21, x0
    4b7c:	2a0103f4 	mov	w20, w1
    4b80:	b953a440 	ldr	w0, [x2, #5028]
    4b84:	34000600 	cbz	w0, 4c44 <fwp_heap_alloc_slow+0xe4>
    4b88:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b8c:	54000628 	b.hi	4c50 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b90:	91003ea0 	add	x0, x21, #0xf
    4b94:	91154262 	add	x2, x19, #0x550
    4b98:	f9001bf7 	str	x23, [sp, #48]
    4b9c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ba0:	8b401040 	add	x0, x2, x0, lsr #4
    4ba4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ba8:	d37ae484 	lsl	x4, x4, #6
    4bac:	397e8003 	ldrb	w3, [x0, #4000]
    4bb0:	910f0060 	add	x0, x3, #0x3c0
    4bb4:	aa0303e1 	mov	x1, x3
    4bb8:	8b030463 	add	x3, x3, x3, lsl #1
    4bbc:	8b030c83 	add	x3, x4, x3, lsl #3
    4bc0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4bc4:	2a1703f6 	mov	w22, w23
    4bc8:	f8636844 	ldr	x4, [x2, x3]
    4bcc:	b40004e4 	cbz	x4, 4c68 <fwp_heap_alloc_slow+0x108>
    4bd0:	f9400080 	ldr	x0, [x4]
    4bd4:	aa2003e0 	mvn	x0, x0
    4bd8:	f8236840 	str	x0, [x2, x3]
    4bdc:	7100069f 	cmp	w20, #0x1
    4be0:	aa0403e0 	mov	x0, x4
    4be4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4be8:	52800001 	mov	w1, #0x0                   	// #0
    4bec:	97fff719 	bl	2850 <memset@plt>
    4bf0:	aa0003e4 	mov	x4, x0
    4bf4:	91154260 	add	x0, x19, #0x550
    4bf8:	f94a1001 	ldr	x1, [x0, #5152]
    4bfc:	ab160021 	adds	x1, x1, x22
    4c00:	540005c2 	b.cs	4cb8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4c04:	f94a1402 	ldr	x2, [x0, #5160]
    4c08:	f90a1001 	str	x1, [x0, #5152]
    4c0c:	eb02003f 	cmp	x1, x2
    4c10:	54000049 	b.ls	4c18 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4c14:	f90a1401 	str	x1, [x0, #5160]
    4c18:	91154273 	add	x19, x19, #0x550
    4c1c:	1e6302e1 	ucvtf	d1, w23
    4c20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c24:	aa0403e0 	mov	x0, x4
    4c28:	fd4a1e60 	ldr	d0, [x19, #5176]
    4c2c:	f9401bf7 	ldr	x23, [sp, #48]
    4c30:	1e612800 	fadd	d0, d0, d1
    4c34:	fd0a1e60 	str	d0, [x19, #5176]
    4c38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c3c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c40:	d65f03c0 	ret
    4c44:	97fffc90 	bl	3e84 <fwp_heap_init>
    4c48:	f14012bf 	cmp	x21, #0x4, lsl #12
    4c4c:	54fffa29 	b.ls	4b90 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c50:	2a1403e1 	mov	w1, w20
    4c54:	aa1503e0 	mov	x0, x21
    4c58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c60:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c64:	17ffff70 	b	4a24 <fwp_heap_alloc_big>
    4c68:	8b030042 	add	x2, x2, x3
    4c6c:	f9400444 	ldr	x4, [x2, #8]
    4c70:	b4000104 	cbz	x4, 4c90 <fwp_heap_alloc_slow+0x130>
    4c74:	f9400840 	ldr	x0, [x2, #16]
    4c78:	cb040000 	sub	x0, x0, x4
    4c7c:	eb16001f 	cmp	x0, x22
    4c80:	54000083 	b.cc	4c90 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c84:	8b160080 	add	x0, x4, x22
    4c88:	f9000440 	str	x0, [x2, #8]
    4c8c:	17ffffd4 	b	4bdc <fwp_heap_alloc_slow+0x7c>
    4c90:	52800302 	mov	w2, #0x18                  	// #24
    4c94:	52807804 	mov	w4, #0x3c0                 	// #960
    4c98:	91154260 	add	x0, x19, #0x550
    4c9c:	9ba27c23 	umull	x3, w1, w2
    4ca0:	2a1403e2 	mov	w2, w20
    4ca4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ca8:	8b040000 	add	x0, x0, x4
    4cac:	97fffeb5 	bl	4780 <fwp_heap_refill>
    4cb0:	aa0003e4 	mov	x4, x0
    4cb4:	17ffffca 	b	4bdc <fwp_heap_alloc_slow+0x7c>
    4cb8:	97fff8de 	bl	3030 <fwp_heap_oom>
    4cbc:	d503201f 	nop

0000000000004cc0 <fwp_heap_alloc>:
    4cc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4cc4:	f140101f 	cmp	x0, #0x4, lsl #12
    4cc8:	910003fd 	mov	x29, sp
    4ccc:	a90153f3 	stp	x19, x20, [sp, #16]
    4cd0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4cd4:	91154293 	add	x19, x20, #0x550
    4cd8:	b953a662 	ldr	w2, [x19, #5028]
    4cdc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4ce0:	54000640 	b.eq	4da8 <fwp_heap_alloc+0xe8>  // b.none
    4ce4:	91003c03 	add	x3, x0, #0xf
    4ce8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4cec:	937c7c22 	sbfiz	x2, x1, #4, #32
    4cf0:	8b431263 	add	x3, x19, x3, lsr #4
    4cf4:	cb21c042 	sub	x2, x2, w1, sxtw
    4cf8:	d37ae442 	lsl	x2, x2, #6
    4cfc:	397e8063 	ldrb	w3, [x3, #4000]
    4d00:	910f0064 	add	x4, x3, #0x3c0
    4d04:	8b030463 	add	x3, x3, x3, lsl #1
    4d08:	8b030c43 	add	x3, x2, x3, lsl #3
    4d0c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4d10:	2a1603f5 	mov	w21, w22
    4d14:	f8636a64 	ldr	x4, [x19, x3]
    4d18:	b4000384 	cbz	x4, 4d88 <fwp_heap_alloc+0xc8>
    4d1c:	f9400085 	ldr	x5, [x4]
    4d20:	7100043f 	cmp	w1, #0x1
    4d24:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d28:	aa0403e0 	mov	x0, x4
    4d2c:	aa2503e5 	mvn	x5, x5
    4d30:	52800001 	mov	w1, #0x0                   	// #0
    4d34:	f8236a65 	str	x5, [x19, x3]
    4d38:	97fff6c6 	bl	2850 <memset@plt>
    4d3c:	aa0003e4 	mov	x4, x0
    4d40:	f94a1260 	ldr	x0, [x19, #5152]
    4d44:	ab150000 	adds	x0, x0, x21
    4d48:	54000442 	b.cs	4dd0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4d4c:	f94a1661 	ldr	x1, [x19, #5160]
    4d50:	f90a1260 	str	x0, [x19, #5152]
    4d54:	eb01001f 	cmp	x0, x1
    4d58:	54000049 	b.ls	4d60 <fwp_heap_alloc+0xa0>  // b.plast
    4d5c:	f90a1660 	str	x0, [x19, #5160]
    4d60:	91154294 	add	x20, x20, #0x550
    4d64:	1e6302c1 	ucvtf	d1, w22
    4d68:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d6c:	aa0403e0 	mov	x0, x4
    4d70:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d74:	1e612800 	fadd	d0, d0, d1
    4d78:	fd0a1e80 	str	d0, [x20, #5176]
    4d7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d84:	d65f03c0 	ret
    4d88:	8b030263 	add	x3, x19, x3
    4d8c:	f9400464 	ldr	x4, [x3, #8]
    4d90:	b40000a4 	cbz	x4, 4da4 <fwp_heap_alloc+0xe4>
    4d94:	f9400862 	ldr	x2, [x3, #16]
    4d98:	cb040042 	sub	x2, x2, x4
    4d9c:	eb15005f 	cmp	x2, x21
    4da0:	540000a2 	b.cs	4db4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4da4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4da8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4dac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4db0:	17ffff6c 	b	4b60 <fwp_heap_alloc_slow>
    4db4:	7100043f 	cmp	w1, #0x1
    4db8:	8b150085 	add	x5, x4, x21
    4dbc:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4dc0:	52800001 	mov	w1, #0x0                   	// #0
    4dc4:	aa0403e0 	mov	x0, x4
    4dc8:	f9000465 	str	x5, [x3, #8]
    4dcc:	17ffffdb 	b	4d38 <fwp_heap_alloc+0x78>
    4dd0:	97fff898 	bl	3030 <fwp_heap_oom>

0000000000004dd4 <fwp_data.part.0.constprop.0>:
    4dd4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4dd8:	910003fd 	mov	x29, sp
    4ddc:	a90153f3 	stp	x19, x20, [sp, #16]
    4de0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4de4:	91154283 	add	x3, x20, #0x550
    4de8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4dec:	aa0103f5 	mov	x21, x1
    4df0:	b953a461 	ldr	w1, [x3, #5028]
    4df4:	a90363f7 	stp	x23, x24, [sp, #48]
    4df8:	2a0003f8 	mov	w24, w0
    4dfc:	34000701 	cbz	w1, 4edc <fwp_data.part.0.constprop.0+0x108>
    4e00:	397e8862 	ldrb	w2, [x3, #4002]
    4e04:	910f0040 	add	x0, x2, #0x3c0
    4e08:	8b020442 	add	x2, x2, x2, lsl #1
    4e0c:	d37df042 	lsl	x2, x2, #3
    4e10:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4e14:	2a1703f6 	mov	w22, w23
    4e18:	f8626873 	ldr	x19, [x3, x2]
    4e1c:	b40004d3 	cbz	x19, 4eb4 <fwp_data.part.0.constprop.0+0xe0>
    4e20:	f9400260 	ldr	x0, [x19]
    4e24:	aa2003e0 	mvn	x0, x0
    4e28:	f8226860 	str	x0, [x3, x2]
    4e2c:	f10062df 	cmp	x22, #0x18
    4e30:	540000e9 	b.ls	4e4c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4e34:	d10066c2 	sub	x2, x22, #0x19
    4e38:	91006260 	add	x0, x19, #0x18
    4e3c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4e40:	52800001 	mov	w1, #0x0                   	// #0
    4e44:	91002042 	add	x2, x2, #0x8
    4e48:	97fff682 	bl	2850 <memset@plt>
    4e4c:	91154282 	add	x2, x20, #0x550
    4e50:	f94a1041 	ldr	x1, [x2, #5152]
    4e54:	ab160021 	adds	x1, x1, x22
    4e58:	540004c2 	b.cs	4ef0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e5c:	f94a1440 	ldr	x0, [x2, #5160]
    4e60:	f90a1041 	str	x1, [x2, #5152]
    4e64:	eb00003f 	cmp	x1, x0
    4e68:	54000049 	b.ls	4e70 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e6c:	f90a1441 	str	x1, [x2, #5160]
    4e70:	91154294 	add	x20, x20, #0x550
    4e74:	1e6302e1 	ucvtf	d1, w23
    4e78:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e7c:	1e612800 	fadd	d0, d0, d1
    4e80:	fd0a1e80 	str	d0, [x20, #5176]
    4e84:	52800041 	mov	w1, #0x2                   	// #2
    4e88:	29000678 	stp	w24, w1, [x19]
    4e8c:	aa1303e0 	mov	x0, x19
    4e90:	f94002a1 	ldr	x1, [x21]
    4e94:	f9000661 	str	x1, [x19, #8]
    4e98:	f94006a1 	ldr	x1, [x21, #8]
    4e9c:	f9000a61 	str	x1, [x19, #16]
    4ea0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ea4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ea8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4eac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4eb0:	d65f03c0 	ret
    4eb4:	8b020063 	add	x3, x3, x2
    4eb8:	f9400473 	ldr	x19, [x3, #8]
    4ebc:	b4000113 	cbz	x19, 4edc <fwp_data.part.0.constprop.0+0x108>
    4ec0:	f9400860 	ldr	x0, [x3, #16]
    4ec4:	cb130000 	sub	x0, x0, x19
    4ec8:	eb0002df 	cmp	x22, x0
    4ecc:	54000088 	b.hi	4edc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4ed0:	8b160260 	add	x0, x19, x22
    4ed4:	f9000460 	str	x0, [x3, #8]
    4ed8:	17ffffd5 	b	4e2c <fwp_data.part.0.constprop.0+0x58>
    4edc:	52800001 	mov	w1, #0x0                   	// #0
    4ee0:	d2800300 	mov	x0, #0x18                  	// #24
    4ee4:	97ffff77 	bl	4cc0 <fwp_heap_alloc>
    4ee8:	aa0003f3 	mov	x19, x0
    4eec:	17ffffe6 	b	4e84 <fwp_data.part.0.constprop.0+0xb0>
    4ef0:	97fff850 	bl	3030 <fwp_heap_oom>

0000000000004ef4 <fwp_p_ad_push>:
    4ef4:	f100001f 	cmp	x0, #0x0
    4ef8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4efc:	54000e8b 	b.lt	50cc <fwp_p_ad_push+0x1d8>  // b.tstop
    4f00:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f04:	aa0003e4 	mov	x4, x0
    4f08:	910003fd 	mov	x29, sp
    4f0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f10:	aa0003f5 	mov	x21, x0
    4f14:	aa020000 	orr	x0, x0, x2
    4f18:	a90363f7 	stp	x23, x24, [sp, #48]
    4f1c:	aa0203f7 	mov	x23, x2
    4f20:	6d0627e8 	stp	d8, d9, [sp, #96]
    4f24:	9e670029 	fmov	d9, x1
    4f28:	9e670068 	fmov	d8, x3
    4f2c:	b6f80900 	tbz	x0, #63, 504c <fwp_p_ad_push+0x158>
    4f30:	a90153f3 	stp	x19, x20, [sp, #16]
    4f34:	9360fc80 	asr	x0, x4, #32
    4f38:	b6f800c4 	tbz	x4, #63, 4f50 <fwp_p_ad_push+0x5c>
    4f3c:	1e604109 	fmov	d9, d8
    4f40:	2f00e408 	movi	d8, #0x0
    4f44:	9360fc40 	asr	x0, x2, #32
    4f48:	aa0203f5 	mov	x21, x2
    4f4c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f50:	97fffa58 	bl	38b0 <fwp_tape_of>
    4f54:	aa0003f3 	mov	x19, x0
    4f58:	f9403000 	ldr	x0, [x0, #96]
    4f5c:	b5001280 	cbnz	x0, 51ac <fwp_p_ad_push+0x2b8>
    4f60:	f9400a76 	ldr	x22, [x19, #16]
    4f64:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f68:	eb0002df 	cmp	x22, x0
    4f6c:	54000e2c 	b.gt	5130 <fwp_p_ad_push+0x23c>
    4f70:	eb3542df 	cmp	x22, w21, uxtw
    4f74:	54000d4d 	b.le	511c <fwp_p_ad_push+0x228>
    4f78:	b7f80077 	tbnz	x23, #63, 4f84 <fwp_p_ad_push+0x90>
    4f7c:	eb3742df 	cmp	x22, w23, uxtw
    4f80:	54000ced 	b.le	511c <fwp_p_ad_push+0x228>
    4f84:	f9400678 	ldr	x24, [x19, #8]
    4f88:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f8c:	cb1802d8 	sub	x24, x22, x24
    4f90:	91000701 	add	x1, x24, #0x1
    4f94:	eb00003f 	cmp	x1, x0
    4f98:	54000cc8 	b.hi	5130 <fwp_p_ad_push+0x23c>  // b.pmore
    4f9c:	a9418274 	ldp	x20, x0, [x19, #24]
    4fa0:	a90573fb 	stp	x27, x28, [sp, #80]
    4fa4:	eb14003f 	cmp	x1, x20
    4fa8:	5400068d 	b.le	5078 <fwp_p_ad_push+0x184>
    4fac:	f100029f 	cmp	x20, #0x0
    4fb0:	d2800803 	mov	x3, #0x40                  	// #64
    4fb4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4fb8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4fbc:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fc0:	eb14003f 	cmp	x1, x20
    4fc4:	5400008d 	b.le	4fd4 <fwp_p_ad_push+0xe0>
    4fc8:	eb02029f 	cmp	x20, x2
    4fcc:	5400052d 	b.le	5070 <fwp_p_ad_push+0x17c>
    4fd0:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4fd4:	d37df299 	lsl	x25, x20, #3
    4fd8:	aa1903e1 	mov	x1, x25
    4fdc:	97fff625 	bl	2870 <realloc@plt>
    4fe0:	aa0003e1 	mov	x1, x0
    4fe4:	b4000b00 	cbz	x0, 5144 <fwp_p_ad_push+0x250>
    4fe8:	f9400e62 	ldr	x2, [x19, #24]
    4fec:	f9001261 	str	x1, [x19, #32]
    4ff0:	f9401a60 	ldr	x0, [x19, #48]
    4ff4:	d37cee9a 	lsl	x26, x20, #4
    4ff8:	8b020821 	add	x1, x1, x2, lsl #2
    4ffc:	f9001661 	str	x1, [x19, #40]
    5000:	aa1a03e1 	mov	x1, x26
    5004:	97fff61b 	bl	2870 <realloc@plt>
    5008:	aa0003e2 	mov	x2, x0
    500c:	b40009c0 	cbz	x0, 5144 <fwp_p_ad_push+0x250>
    5010:	f9400e61 	ldr	x1, [x19, #24]
    5014:	d37df31b 	lsl	x27, x24, #3
    5018:	d37ef685 	lsl	x5, x20, #2
    501c:	d37ef71c 	lsl	x28, x24, #2
    5020:	8b190004 	add	x4, x0, x25
    5024:	8b010c01 	add	x1, x0, x1, lsl #3
    5028:	a9030660 	stp	x0, x1, [x19, #48]
    502c:	b5000558 	cbnz	x24, 50d4 <fwp_p_ad_push+0x1e0>
    5030:	f9001e64 	str	x4, [x19, #56]
    5034:	f9401260 	ldr	x0, [x19, #32]
    5038:	a9446bf9 	ldp	x25, x26, [sp, #64]
    503c:	8b050001 	add	x1, x0, x5
    5040:	f9000e74 	str	x20, [x19, #24]
    5044:	f9001661 	str	x1, [x19, #40]
    5048:	14000010 	b	5088 <fwp_p_ad_push+0x194>
    504c:	9360fc40 	asr	x0, x2, #32
    5050:	a90153f3 	stp	x19, x20, [sp, #16]
    5054:	eb84801f 	cmp	x0, x4, asr #32
    5058:	54fff7c0 	b.eq	4f50 <fwp_p_ad_push+0x5c>  // b.none
    505c:	90000020 	adrp	x0, 9000 <__modti3+0x330>
    5060:	910d8000 	add	x0, x0, #0x360
    5064:	a9046bf9 	stp	x25, x26, [sp, #64]
    5068:	a90573fb 	stp	x27, x28, [sp, #80]
    506c:	97fff945 	bl	3580 <fwp_trap>
    5070:	d37ffa94 	lsl	x20, x20, #1
    5074:	17ffffd3 	b	4fc0 <fwp_p_ad_push+0xcc>
    5078:	a9428a61 	ldp	x1, x2, [x19, #40]
    507c:	d37ef71c 	lsl	x28, x24, #2
    5080:	f9401e64 	ldr	x4, [x19, #56]
    5084:	d37df31b 	lsl	x27, x24, #3
    5088:	b83c6815 	str	w21, [x0, x28]
    508c:	f10002ff 	cmp	x23, #0x0
    5090:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5094:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5098:	fc3b6849 	str	d9, [x2, x27]
    509c:	aa1602a0 	orr	x0, x21, x22
    50a0:	b83c6837 	str	w23, [x1, x28]
    50a4:	910006d6 	add	x22, x22, #0x1
    50a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50ac:	fc3b6888 	str	d8, [x4, x27]
    50b0:	a94573fb 	ldp	x27, x28, [sp, #80]
    50b4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    50b8:	f9000a76 	str	x22, [x19, #16]
    50bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    50c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50c4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    50c8:	d65f03c0 	ret
    50cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    50d0:	d65f03c0 	ret
    50d4:	eb1a033f 	cmp	x25, x26
    50d8:	aa0403e0 	mov	x0, x4
    50dc:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    50e0:	aa1b03e2 	mov	x2, x27
    50e4:	cb190063 	sub	x3, x3, x25
    50e8:	f9003fe5 	str	x5, [sp, #120]
    50ec:	97fff64d 	bl	2a20 <__memmove_chk@plt>
    50f0:	a9420660 	ldp	x0, x1, [x19, #32]
    50f4:	aa1c03e2 	mov	x2, x28
    50f8:	f9401a63 	ldr	x3, [x19, #48]
    50fc:	f9403fe5 	ldr	x5, [sp, #120]
    5100:	8b190063 	add	x3, x3, x25
    5104:	f9001e63 	str	x3, [x19, #56]
    5108:	8b050000 	add	x0, x0, x5
    510c:	97fff579 	bl	26f0 <memmove@plt>
    5110:	a9431262 	ldp	x2, x4, [x19, #48]
    5114:	f9403fe5 	ldr	x5, [sp, #120]
    5118:	17ffffc7 	b	5034 <fwp_p_ad_push+0x140>
    511c:	90000020 	adrp	x0, 9000 <__modti3+0x330>
    5120:	910fe000 	add	x0, x0, #0x3f8
    5124:	a9046bf9 	stp	x25, x26, [sp, #64]
    5128:	a90573fb 	stp	x27, x28, [sp, #80]
    512c:	97fff915 	bl	3580 <fwp_trap>
    5130:	90000020 	adrp	x0, 9000 <__modti3+0x330>
    5134:	910f6000 	add	x0, x0, #0x3d8
    5138:	a9046bf9 	stp	x25, x26, [sp, #64]
    513c:	a90573fb 	stp	x27, x28, [sp, #80]
    5140:	97fff910 	bl	3580 <fwp_trap>
    5144:	aa1303e0 	mov	x0, x19
    5148:	97fff792 	bl	2f90 <fwp_tape_unlink_scope>
    514c:	f9401260 	ldr	x0, [x19, #32]
    5150:	97fff5fc 	bl	2940 <free@plt>
    5154:	f9401a60 	ldr	x0, [x19, #48]
    5158:	97fff5fa 	bl	2940 <free@plt>
    515c:	f9402260 	ldr	x0, [x19, #64]
    5160:	97fff5f8 	bl	2940 <free@plt>
    5164:	f9000e7f 	str	xzr, [x19, #24]
    5168:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    516c:	f947e821 	ldr	x1, [x1, #4048]
    5170:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5174:	d2800262 	mov	x2, #0x13                  	// #19
    5178:	4f000400 	movi	v0.4s, #0x0
    517c:	90000020 	adrp	x0, 9000 <__modti3+0x330>
    5180:	f9400023 	ldr	x3, [x1]
    5184:	b900067f 	str	wzr, [x19, #4]
    5188:	d2800021 	mov	x1, #0x1                   	// #1
    518c:	9101e000 	add	x0, x0, #0x78
    5190:	3c808260 	stur	q0, [x19, #8]
    5194:	ad010260 	stp	q0, q0, [x19, #32]
    5198:	97fff5fa 	bl	2980 <fwrite@plt>
    519c:	d2800000 	mov	x0, #0x0                   	// #0
    51a0:	97fff604 	bl	29b0 <fflush@plt>
    51a4:	52800cc0 	mov	w0, #0x66                  	// #102
    51a8:	97fff612 	bl	29f0 <_Exit@plt>
    51ac:	90000020 	adrp	x0, 9000 <__modti3+0x330>
    51b0:	910ea000 	add	x0, x0, #0x3a8
    51b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    51b8:	a90573fb 	stp	x27, x28, [sp, #80]
    51bc:	97fff8f1 	bl	3580 <fwp_trap>

00000000000051c0 <w120>:
    51c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51c4:	9e660003 	fmov	x3, d0
    51c8:	aa0003e2 	mov	x2, x0
    51cc:	910003fd 	mov	x29, sp
    51d0:	fd001fea 	str	d10, [sp, #56]
    51d4:	1e60400a 	fmov	d10, d0
    51d8:	6d0427e8 	stp	d8, d9, [sp, #64]
    51dc:	1e604028 	fmov	d8, d1
    51e0:	1e600809 	fmul	d9, d0, d0
    51e4:	a90153f3 	stp	x19, x20, [sp, #16]
    51e8:	aa0103f4 	mov	x20, x1
    51ec:	aa0303e1 	mov	x1, x3
    51f0:	aa0003f3 	mov	x19, x0
    51f4:	a9025bf5 	stp	x21, x22, [sp, #32]
    51f8:	f9001bf7 	str	x23, [sp, #48]
    51fc:	97ffff3e 	bl	4ef4 <fwp_p_ad_push>
    5200:	aa0003e5 	mov	x5, x0
    5204:	97fffb90 	bl	4044 <caf75>
    5208:	9e670000 	fmov	d0, x0
    520c:	97fffb8e 	bl	4044 <caf75>
    5210:	1e693908 	fsub	d8, d8, d9
    5214:	aa1403e2 	mov	x2, x20
    5218:	1e614000 	fneg	d0, d0
    521c:	aa0003e3 	mov	x3, x0
    5220:	aa0503e0 	mov	x0, x5
    5224:	9e660117 	fmov	x23, d8
    5228:	9e660001 	fmov	x1, d0
    522c:	97ffff32 	bl	4ef4 <fwp_p_ad_push>
    5230:	aa0003f5 	mov	x21, x0
    5234:	97fffb84 	bl	4044 <caf75>
    5238:	9e670000 	fmov	d0, x0
    523c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5240:	97fffb81 	bl	4044 <caf75>
    5244:	1e614000 	fneg	d0, d0
    5248:	aa0003e3 	mov	x3, x0
    524c:	1e6a3929 	fsub	d9, d9, d10
    5250:	aa1303e0 	mov	x0, x19
    5254:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5258:	9e660001 	fmov	x1, d0
    525c:	9e660136 	fmov	x22, d9
    5260:	97ffff25 	bl	4ef4 <fwp_p_ad_push>
    5264:	1e680908 	fmul	d8, d8, d8
    5268:	aa0003f4 	mov	x20, x0
    526c:	aa1703e3 	mov	x3, x23
    5270:	aa1703e1 	mov	x1, x23
    5274:	aa1503e2 	mov	x2, x21
    5278:	aa1503e0 	mov	x0, x21
    527c:	97ffff1e 	bl	4ef4 <fwp_p_ad_push>
    5280:	aa0003e2 	mov	x2, x0
    5284:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5288:	9e670020 	fmov	d0, x1
    528c:	9e660101 	fmov	x1, d8
    5290:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5294:	1e600908 	fmul	d8, d8, d0
    5298:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    529c:	97ffff16 	bl	4ef4 <fwp_p_ad_push>
    52a0:	1e690929 	fmul	d9, d9, d9
    52a4:	aa1603e3 	mov	x3, x22
    52a8:	aa1603e1 	mov	x1, x22
    52ac:	aa1403e2 	mov	x2, x20
    52b0:	aa0003f3 	mov	x19, x0
    52b4:	aa1403e0 	mov	x0, x20
    52b8:	97ffff0f 	bl	4ef4 <fwp_p_ad_push>
    52bc:	aa0003e5 	mov	x5, x0
    52c0:	97fffb61 	bl	4044 <caf75>
    52c4:	aa0003e6 	mov	x6, x0
    52c8:	97fffb5f 	bl	4044 <caf75>
    52cc:	1e692908 	fadd	d8, d8, d9
    52d0:	aa1303e2 	mov	x2, x19
    52d4:	aa0603e1 	mov	x1, x6
    52d8:	aa0003e3 	mov	x3, x0
    52dc:	aa0503e0 	mov	x0, x5
    52e0:	97ffff05 	bl	4ef4 <fwp_p_ad_push>
    52e4:	aa0003e1 	mov	x1, x0
    52e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    52ec:	9e660100 	fmov	x0, d8
    52f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52f4:	f9401bf7 	ldr	x23, [sp, #48]
    52f8:	fd401fea 	ldr	d10, [sp, #56]
    52fc:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5300:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5304:	d65f03c0 	ret
    5308:	d503201f 	nop
    530c:	d503201f 	nop

0000000000005310 <w176.constprop.0>:
    5310:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5314:	910003fd 	mov	x29, sp
    5318:	a9025bf5 	stp	x21, x22, [sp, #32]
    531c:	fd001be8 	str	d8, [sp, #48]
    5320:	f9400015 	ldr	x21, [x0]
    5324:	b40003b5 	cbz	x21, 5398 <w176.constprop.0+0x88>
    5328:	2f00e408 	movi	d8, #0x0
    532c:	91002016 	add	x22, x0, #0x8
    5330:	a90153f3 	stp	x19, x20, [sp, #16]
    5334:	91004014 	add	x20, x0, #0x10
    5338:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    533c:	d2800013 	mov	x19, #0x0                   	// #0
    5340:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5344:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    5348:	97fffb3f 	bl	4044 <caf75>
    534c:	aa0003e6 	mov	x6, x0
    5350:	97fffb3d 	bl	4044 <caf75>
    5354:	1e602908 	fadd	d8, d8, d0
    5358:	aa0003e3 	mov	x3, x0
    535c:	aa0703e2 	mov	x2, x7
    5360:	aa0503e0 	mov	x0, x5
    5364:	aa0603e1 	mov	x1, x6
    5368:	91000a73 	add	x19, x19, #0x2
    536c:	97fffee2 	bl	4ef4 <fwp_p_ad_push>
    5370:	aa0003e5 	mov	x5, x0
    5374:	eb1302bf 	cmp	x21, x19
    5378:	54fffe48 	b.hi	5340 <w176.constprop.0+0x30>  // b.pmore
    537c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5380:	9e660100 	fmov	x0, d8
    5384:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5388:	aa0503e1 	mov	x1, x5
    538c:	fd401be8 	ldr	d8, [sp, #48]
    5390:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5394:	d65f03c0 	ret
    5398:	2f00e408 	movi	d8, #0x0
    539c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    53a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53a4:	aa0503e1 	mov	x1, x5
    53a8:	9e660100 	fmov	x0, d8
    53ac:	fd401be8 	ldr	d8, [sp, #48]
    53b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    53b4:	d65f03c0 	ret
    53b8:	d503201f 	nop
    53bc:	d503201f 	nop

00000000000053c0 <fwp_rc_share>:
    53c0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    53c4:	91154042 	add	x2, x2, #0x550
    53c8:	f949d843 	ldr	x3, [x2, #5040]
    53cc:	f949ec41 	ldr	x1, [x2, #5080]
    53d0:	cb030000 	sub	x0, x0, x3
    53d4:	eb01401f 	cmp	x0, x1, lsl #16
    53d8:	540002c2 	b.cs	5430 <fwp_rc_share+0x70>  // b.hs, b.nlast
    53dc:	d350fc01 	lsr	x1, x0, #16
    53e0:	f949fc44 	ldr	x4, [x2, #5112]
    53e4:	8b010821 	add	x1, x1, x1, lsl #2
    53e8:	d37df021 	lsl	x1, x1, #3
    53ec:	8b010083 	add	x3, x4, x1
    53f0:	f9401062 	ldr	x2, [x3, #32]
    53f4:	b40001e2 	cbz	x2, 5430 <fwp_rc_share+0x70>
    53f8:	38616881 	ldrb	w1, [x4, x1]
    53fc:	7100083f 	cmp	w1, #0x2
    5400:	540001a0 	b.eq	5434 <fwp_rc_share+0x74>  // b.none
    5404:	7100043f 	cmp	w1, #0x1
    5408:	54000141 	b.ne	5430 <fwp_rc_share+0x70>  // b.any
    540c:	29430464 	ldp	w4, w1, [x3, #24]
    5410:	92403c00 	and	x0, x0, #0xffff
    5414:	9b047c00 	mul	x0, x0, x4
    5418:	d360fc00 	lsr	x0, x0, #32
    541c:	eb01001f 	cmp	x0, x1
    5420:	54000082 	b.cs	5430 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5424:	8b000042 	add	x2, x2, x0
    5428:	39400040 	ldrb	w0, [x2]
    542c:	350000a0 	cbnz	w0, 5440 <fwp_rc_share+0x80>
    5430:	d65f03c0 	ret
    5434:	72003c1f 	tst	w0, #0xffff
    5438:	54ffff80 	b.eq	5428 <fwp_rc_share+0x68>  // b.none
    543c:	d65f03c0 	ret
    5440:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5444:	90000020 	adrp	x0, 9000 <__modti3+0x330>
    5448:	91106000 	add	x0, x0, #0x418
    544c:	910003fd 	mov	x29, sp
    5450:	97fff84c 	bl	3580 <fwp_trap>

0000000000005454 <fwp_rc_free_arr>:
    5454:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5458:	91154063 	add	x3, x3, #0x550
    545c:	f949d861 	ldr	x1, [x3, #5040]
    5460:	f949ec62 	ldr	x2, [x3, #5080]
    5464:	cb010001 	sub	x1, x0, x1
    5468:	eb02403f 	cmp	x1, x2, lsl #16
    546c:	54000342 	b.cs	54d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5470:	d350fc22 	lsr	x2, x1, #16
    5474:	f949fc65 	ldr	x5, [x3, #5112]
    5478:	8b020842 	add	x2, x2, x2, lsl #2
    547c:	d37df042 	lsl	x2, x2, #3
    5480:	8b0200a4 	add	x4, x5, x2
    5484:	f9401083 	ldr	x3, [x4, #32]
    5488:	b4000263 	cbz	x3, 54d4 <fwp_rc_free_arr+0x80>
    548c:	386268a2 	ldrb	w2, [x5, x2]
    5490:	7100085f 	cmp	w2, #0x2
    5494:	540001c0 	b.eq	54cc <fwp_rc_free_arr+0x78>  // b.none
    5498:	7100045f 	cmp	w2, #0x1
    549c:	540001c1 	b.ne	54d4 <fwp_rc_free_arr+0x80>  // b.any
    54a0:	29430885 	ldp	w5, w2, [x4, #24]
    54a4:	92403c21 	and	x1, x1, #0xffff
    54a8:	9b057c21 	mul	x1, x1, x5
    54ac:	d360fc21 	lsr	x1, x1, #32
    54b0:	eb02003f 	cmp	x1, x2
    54b4:	54000102 	b.cs	54d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    54b8:	8b010063 	add	x3, x3, x1
    54bc:	39400061 	ldrb	w1, [x3]
    54c0:	7100043f 	cmp	w1, #0x1
    54c4:	54000081 	b.ne	54d4 <fwp_rc_free_arr+0x80>  // b.any
    54c8:	17fffcde 	b	4840 <fwp_mem_free>
    54cc:	72003c3f 	tst	w1, #0xffff
    54d0:	54ffff60 	b.eq	54bc <fwp_rc_free_arr+0x68>  // b.none
    54d4:	d65f03c0 	ret
    54d8:	d503201f 	nop
    54dc:	d503201f 	nop

00000000000054e0 <fwp_rc_dup>:
    54e0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    54e4:	91154042 	add	x2, x2, #0x550
    54e8:	f949d841 	ldr	x1, [x2, #5040]
    54ec:	f949ec43 	ldr	x3, [x2, #5080]
    54f0:	cb010001 	sub	x1, x0, x1
    54f4:	eb03403f 	cmp	x1, x3, lsl #16
    54f8:	54000342 	b.cs	5560 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    54fc:	d350fc20 	lsr	x0, x1, #16
    5500:	f949fc44 	ldr	x4, [x2, #5112]
    5504:	8b000800 	add	x0, x0, x0, lsl #2
    5508:	d37df002 	lsl	x2, x0, #3
    550c:	8b020083 	add	x3, x4, x2
    5510:	f9401060 	ldr	x0, [x3, #32]
    5514:	b4000260 	cbz	x0, 5560 <fwp_rc_dup+0x80>
    5518:	38626882 	ldrb	w2, [x4, x2]
    551c:	7100085f 	cmp	w2, #0x2
    5520:	54000220 	b.eq	5564 <fwp_rc_dup+0x84>  // b.none
    5524:	7100045f 	cmp	w2, #0x1
    5528:	540001c1 	b.ne	5560 <fwp_rc_dup+0x80>  // b.any
    552c:	29430864 	ldp	w4, w2, [x3, #24]
    5530:	92403c21 	and	x1, x1, #0xffff
    5534:	9b047c21 	mul	x1, x1, x4
    5538:	d360fc21 	lsr	x1, x1, #32
    553c:	eb02003f 	cmp	x1, x2
    5540:	54000102 	b.cs	5560 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5544:	8b010000 	add	x0, x0, x1
    5548:	39400001 	ldrb	w1, [x0]
    554c:	340000a1 	cbz	w1, 5560 <fwp_rc_dup+0x80>
    5550:	7103f43f 	cmp	w1, #0xfd
    5554:	540000e8 	b.hi	5570 <fwp_rc_dup+0x90>  // b.pmore
    5558:	11000421 	add	w1, w1, #0x1
    555c:	39000001 	strb	w1, [x0]
    5560:	d65f03c0 	ret
    5564:	72003c3f 	tst	w1, #0xffff
    5568:	54ffff00 	b.eq	5548 <fwp_rc_dup+0x68>  // b.none
    556c:	d65f03c0 	ret
    5570:	17fffbcd 	b	44a4 <fwp_rc_wide_dup>

0000000000005574 <fwp_owned_entry173>:
    5574:	d10103ff 	sub	sp, sp, #0x40
    5578:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    557c:	f947f442 	ldr	x2, [x2, #4072]
    5580:	a9027bfd 	stp	x29, x30, [sp, #32]
    5584:	910083fd 	add	x29, sp, #0x20
    5588:	a90353f3 	stp	x19, x20, [sp, #48]
    558c:	f9400043 	ldr	x3, [x2]
    5590:	f9000fe3 	str	x3, [sp, #24]
    5594:	d2800003 	mov	x3, #0x0                   	// #0
    5598:	a9400c01 	ldp	x1, x3, [x0]
    559c:	f9400802 	ldr	x2, [x0, #16]
    55a0:	ab020022 	adds	x2, x1, x2
    55a4:	540006e6 	b.vs	5680 <fwp_owned_entry173+0x10c>
    55a8:	910023e1 	add	x1, sp, #0x8
    55ac:	52800000 	mov	w0, #0x0                   	// #0
    55b0:	a9008be3 	stp	x3, x2, [sp, #8]
    55b4:	97fffe08 	bl	4dd4 <fwp_data.part.0.constprop.0>
    55b8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    55bc:	91154063 	add	x3, x3, #0x550
    55c0:	aa0003f3 	mov	x19, x0
    55c4:	f949d861 	ldr	x1, [x3, #5040]
    55c8:	f949ec60 	ldr	x0, [x3, #5080]
    55cc:	cb010261 	sub	x1, x19, x1
    55d0:	eb00403f 	cmp	x1, x0, lsl #16
    55d4:	54000322 	b.cs	5638 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    55d8:	d350fc22 	lsr	x2, x1, #16
    55dc:	f949fc63 	ldr	x3, [x3, #5112]
    55e0:	8b020842 	add	x2, x2, x2, lsl #2
    55e4:	d37df042 	lsl	x2, x2, #3
    55e8:	8b020060 	add	x0, x3, x2
    55ec:	f9401014 	ldr	x20, [x0, #32]
    55f0:	b4000254 	cbz	x20, 5638 <fwp_owned_entry173+0xc4>
    55f4:	38626862 	ldrb	w2, [x3, x2]
    55f8:	7100085f 	cmp	w2, #0x2
    55fc:	54000360 	b.eq	5668 <fwp_owned_entry173+0xf4>  // b.none
    5600:	7100045f 	cmp	w2, #0x1
    5604:	540001a1 	b.ne	5638 <fwp_owned_entry173+0xc4>  // b.any
    5608:	29430002 	ldp	w2, w0, [x0, #24]
    560c:	92403c21 	and	x1, x1, #0xffff
    5610:	9b027c21 	mul	x1, x1, x2
    5614:	d360fc21 	lsr	x1, x1, #32
    5618:	eb00003f 	cmp	x1, x0
    561c:	540000e2 	b.cs	5638 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5620:	8b010294 	add	x20, x20, x1
    5624:	39400280 	ldrb	w0, [x20]
    5628:	7103fc1f 	cmp	w0, #0xff
    562c:	54000240 	b.eq	5674 <fwp_owned_entry173+0x100>  // b.none
    5630:	52800020 	mov	w0, #0x1                   	// #1
    5634:	39000280 	strb	w0, [x20]
    5638:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    563c:	f947f400 	ldr	x0, [x0, #4072]
    5640:	f9400fe2 	ldr	x2, [sp, #24]
    5644:	f9400001 	ldr	x1, [x0]
    5648:	eb010042 	subs	x2, x2, x1
    564c:	d2800001 	mov	x1, #0x0                   	// #0
    5650:	540001a1 	b.ne	5684 <fwp_owned_entry173+0x110>  // b.any
    5654:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5658:	aa1303e0 	mov	x0, x19
    565c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5660:	910103ff 	add	sp, sp, #0x40
    5664:	d65f03c0 	ret
    5668:	72003c3f 	tst	w1, #0xffff
    566c:	54fffe61 	b.ne	5638 <fwp_owned_entry173+0xc4>  // b.any
    5670:	17ffffed 	b	5624 <fwp_owned_entry173+0xb0>
    5674:	aa1403e0 	mov	x0, x20
    5678:	97fffbd2 	bl	45c0 <fwp_rc_forget_slot>
    567c:	17ffffed 	b	5630 <fwp_owned_entry173+0xbc>
    5680:	97fff500 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5684:	97fff47f 	bl	2880 <__stack_chk_fail@plt>
    5688:	d503201f 	nop
    568c:	d503201f 	nop

0000000000005690 <e173>:
    5690:	d10103ff 	sub	sp, sp, #0x40
    5694:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5698:	f947f442 	ldr	x2, [x2, #4072]
    569c:	a9027bfd 	stp	x29, x30, [sp, #32]
    56a0:	910083fd 	add	x29, sp, #0x20
    56a4:	a90353f3 	stp	x19, x20, [sp, #48]
    56a8:	f9400043 	ldr	x3, [x2]
    56ac:	f9000fe3 	str	x3, [sp, #24]
    56b0:	d2800003 	mov	x3, #0x0                   	// #0
    56b4:	a9400c01 	ldp	x1, x3, [x0]
    56b8:	f9400802 	ldr	x2, [x0, #16]
    56bc:	ab020022 	adds	x2, x1, x2
    56c0:	54000726 	b.vs	57a4 <e173+0x114>
    56c4:	910023e1 	add	x1, sp, #0x8
    56c8:	52800000 	mov	w0, #0x0                   	// #0
    56cc:	a9008be3 	stp	x3, x2, [sp, #8]
    56d0:	97fffdc1 	bl	4dd4 <fwp_data.part.0.constprop.0>
    56d4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    56d8:	91154063 	add	x3, x3, #0x550
    56dc:	aa0003f3 	mov	x19, x0
    56e0:	f949d861 	ldr	x1, [x3, #5040]
    56e4:	f949ec60 	ldr	x0, [x3, #5080]
    56e8:	cb010261 	sub	x1, x19, x1
    56ec:	eb00403f 	cmp	x1, x0, lsl #16
    56f0:	54000322 	b.cs	5754 <e173+0xc4>  // b.hs, b.nlast
    56f4:	d350fc22 	lsr	x2, x1, #16
    56f8:	f949fc63 	ldr	x3, [x3, #5112]
    56fc:	8b020842 	add	x2, x2, x2, lsl #2
    5700:	d37df042 	lsl	x2, x2, #3
    5704:	8b020060 	add	x0, x3, x2
    5708:	f9401014 	ldr	x20, [x0, #32]
    570c:	b4000254 	cbz	x20, 5754 <e173+0xc4>
    5710:	38626862 	ldrb	w2, [x3, x2]
    5714:	7100085f 	cmp	w2, #0x2
    5718:	540003a0 	b.eq	578c <e173+0xfc>  // b.none
    571c:	7100045f 	cmp	w2, #0x1
    5720:	540001a1 	b.ne	5754 <e173+0xc4>  // b.any
    5724:	29430002 	ldp	w2, w0, [x0, #24]
    5728:	92403c21 	and	x1, x1, #0xffff
    572c:	9b027c21 	mul	x1, x1, x2
    5730:	d360fc21 	lsr	x1, x1, #32
    5734:	eb00003f 	cmp	x1, x0
    5738:	540000e2 	b.cs	5754 <e173+0xc4>  // b.hs, b.nlast
    573c:	8b010294 	add	x20, x20, x1
    5740:	39400280 	ldrb	w0, [x20]
    5744:	7103fc1f 	cmp	w0, #0xff
    5748:	54000280 	b.eq	5798 <e173+0x108>  // b.none
    574c:	52800020 	mov	w0, #0x1                   	// #1
    5750:	39000280 	strb	w0, [x20]
    5754:	aa1303e0 	mov	x0, x19
    5758:	97ffff1a 	bl	53c0 <fwp_rc_share>
    575c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5760:	f947f400 	ldr	x0, [x0, #4072]
    5764:	f9400fe2 	ldr	x2, [sp, #24]
    5768:	f9400001 	ldr	x1, [x0]
    576c:	eb010042 	subs	x2, x2, x1
    5770:	d2800001 	mov	x1, #0x0                   	// #0
    5774:	540001a1 	b.ne	57a8 <e173+0x118>  // b.any
    5778:	a9427bfd 	ldp	x29, x30, [sp, #32]
    577c:	aa1303e0 	mov	x0, x19
    5780:	a94353f3 	ldp	x19, x20, [sp, #48]
    5784:	910103ff 	add	sp, sp, #0x40
    5788:	d65f03c0 	ret
    578c:	72003c3f 	tst	w1, #0xffff
    5790:	54fffe21 	b.ne	5754 <e173+0xc4>  // b.any
    5794:	17ffffeb 	b	5740 <e173+0xb0>
    5798:	aa1403e0 	mov	x0, x20
    579c:	97fffb89 	bl	45c0 <fwp_rc_forget_slot>
    57a0:	17ffffeb 	b	574c <e173+0xbc>
    57a4:	97fff4b7 	bl	2a80 <fwp_trap_overflow.constprop.0>
    57a8:	97fff436 	bl	2880 <__stack_chk_fail@plt>
    57ac:	d503201f 	nop

00000000000057b0 <fwp_drop0>:
    57b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    57b4:	910003fd 	mov	x29, sp
    57b8:	a90153f3 	stp	x19, x20, [sp, #16]
    57bc:	f90013f5 	str	x21, [sp, #32]
    57c0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    57c4:	911542b4 	add	x20, x21, #0x550
    57c8:	f949da81 	ldr	x1, [x20, #5040]
    57cc:	f949ee82 	ldr	x2, [x20, #5080]
    57d0:	cb010001 	sub	x1, x0, x1
    57d4:	eb02403f 	cmp	x1, x2, lsl #16
    57d8:	54000382 	b.cs	5848 <fwp_drop0+0x98>  // b.hs, b.nlast
    57dc:	d350fc22 	lsr	x2, x1, #16
    57e0:	f949fe84 	ldr	x4, [x20, #5112]
    57e4:	8b020842 	add	x2, x2, x2, lsl #2
    57e8:	d37df042 	lsl	x2, x2, #3
    57ec:	8b020083 	add	x3, x4, x2
    57f0:	f9401073 	ldr	x19, [x3, #32]
    57f4:	b40002b3 	cbz	x19, 5848 <fwp_drop0+0x98>
    57f8:	38626882 	ldrb	w2, [x4, x2]
    57fc:	7100085f 	cmp	w2, #0x2
    5800:	540002c0 	b.eq	5858 <fwp_drop0+0xa8>  // b.none
    5804:	7100045f 	cmp	w2, #0x1
    5808:	54000201 	b.ne	5848 <fwp_drop0+0x98>  // b.any
    580c:	29430864 	ldp	w4, w2, [x3, #24]
    5810:	92403c21 	and	x1, x1, #0xffff
    5814:	9b047c21 	mul	x1, x1, x4
    5818:	d360fc21 	lsr	x1, x1, #32
    581c:	eb02003f 	cmp	x1, x2
    5820:	54000142 	b.cs	5848 <fwp_drop0+0x98>  // b.hs, b.nlast
    5824:	8b010273 	add	x19, x19, x1
    5828:	39400261 	ldrb	w1, [x19]
    582c:	340000e1 	cbz	w1, 5848 <fwp_drop0+0x98>
    5830:	7100043f 	cmp	w1, #0x1
    5834:	540001e0 	b.eq	5870 <fwp_drop0+0xc0>  // b.none
    5838:	7103fc3f 	cmp	w1, #0xff
    583c:	540002e0 	b.eq	5898 <fwp_drop0+0xe8>  // b.none
    5840:	51000421 	sub	w1, w1, #0x1
    5844:	39000261 	strb	w1, [x19]
    5848:	a94153f3 	ldp	x19, x20, [sp, #16]
    584c:	f94013f5 	ldr	x21, [sp, #32]
    5850:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5854:	d65f03c0 	ret
    5858:	72003c3f 	tst	w1, #0xffff
    585c:	54fffe60 	b.eq	5828 <fwp_drop0+0x78>  // b.none
    5860:	a94153f3 	ldp	x19, x20, [sp, #16]
    5864:	f94013f5 	ldr	x21, [sp, #32]
    5868:	a8c37bfd 	ldp	x29, x30, [sp], #48
    586c:	d65f03c0 	ret
    5870:	f9400813 	ldr	x19, [x0, #16]
    5874:	97fffef8 	bl	5454 <fwp_rc_free_arr>
    5878:	911542a0 	add	x0, x21, #0x550
    587c:	f949d801 	ldr	x1, [x0, #5040]
    5880:	f949ec00 	ldr	x0, [x0, #5080]
    5884:	cb010261 	sub	x1, x19, x1
    5888:	eb00403f 	cmp	x1, x0, lsl #16
    588c:	54fffde2 	b.cs	5848 <fwp_drop0+0x98>  // b.hs, b.nlast
    5890:	aa1303e0 	mov	x0, x19
    5894:	17ffffd2 	b	57dc <fwp_drop0+0x2c>
    5898:	ca534660 	eor	x0, x19, x19, lsr #17
    589c:	911542b5 	add	x21, x21, #0x550
    58a0:	ca402400 	eor	x0, x0, x0, lsr #9
    58a4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    58a8:	f94a2400 	ldr	x0, [x0, #5192]
    58ac:	b5000080 	cbnz	x0, 58bc <fwp_drop0+0x10c>
    58b0:	14000010 	b	58f0 <fwp_drop0+0x140>
    58b4:	f9400800 	ldr	x0, [x0, #16]
    58b8:	b40001c0 	cbz	x0, 58f0 <fwp_drop0+0x140>
    58bc:	f9400001 	ldr	x1, [x0]
    58c0:	eb13003f 	cmp	x1, x19
    58c4:	54ffff81 	b.ne	58b4 <fwp_drop0+0x104>  // b.any
    58c8:	f9400401 	ldr	x1, [x0, #8]
    58cc:	d1000421 	sub	x1, x1, #0x1
    58d0:	f9000401 	str	x1, [x0, #8]
    58d4:	f103f83f 	cmp	x1, #0xfe
    58d8:	54fffb81 	b.ne	5848 <fwp_drop0+0x98>  // b.any
    58dc:	aa1303e0 	mov	x0, x19
    58e0:	97fffb38 	bl	45c0 <fwp_rc_forget_slot>
    58e4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    58e8:	39000260 	strb	w0, [x19]
    58ec:	17ffffd7 	b	5848 <fwp_drop0+0x98>
    58f0:	90000020 	adrp	x0, 9000 <__modti3+0x330>
    58f4:	910c6000 	add	x0, x0, #0x318
    58f8:	97fff722 	bl	3580 <fwp_trap>
    58fc:	d503201f 	nop

0000000000005900 <fwp_drop1>:
    5900:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5904:	910003fd 	mov	x29, sp
    5908:	a90153f3 	stp	x19, x20, [sp, #16]
    590c:	f90013f5 	str	x21, [sp, #32]
    5910:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5914:	911542b4 	add	x20, x21, #0x550
    5918:	f949da81 	ldr	x1, [x20, #5040]
    591c:	f949ee82 	ldr	x2, [x20, #5080]
    5920:	cb010001 	sub	x1, x0, x1
    5924:	eb02403f 	cmp	x1, x2, lsl #16
    5928:	54000382 	b.cs	5998 <fwp_drop1+0x98>  // b.hs, b.nlast
    592c:	d350fc22 	lsr	x2, x1, #16
    5930:	f949fe84 	ldr	x4, [x20, #5112]
    5934:	8b020842 	add	x2, x2, x2, lsl #2
    5938:	d37df042 	lsl	x2, x2, #3
    593c:	8b020083 	add	x3, x4, x2
    5940:	f9401073 	ldr	x19, [x3, #32]
    5944:	b40002b3 	cbz	x19, 5998 <fwp_drop1+0x98>
    5948:	38626882 	ldrb	w2, [x4, x2]
    594c:	7100085f 	cmp	w2, #0x2
    5950:	540002c0 	b.eq	59a8 <fwp_drop1+0xa8>  // b.none
    5954:	7100045f 	cmp	w2, #0x1
    5958:	54000201 	b.ne	5998 <fwp_drop1+0x98>  // b.any
    595c:	29430864 	ldp	w4, w2, [x3, #24]
    5960:	92403c21 	and	x1, x1, #0xffff
    5964:	9b047c21 	mul	x1, x1, x4
    5968:	d360fc21 	lsr	x1, x1, #32
    596c:	eb02003f 	cmp	x1, x2
    5970:	54000142 	b.cs	5998 <fwp_drop1+0x98>  // b.hs, b.nlast
    5974:	8b010273 	add	x19, x19, x1
    5978:	39400261 	ldrb	w1, [x19]
    597c:	340000e1 	cbz	w1, 5998 <fwp_drop1+0x98>
    5980:	7100043f 	cmp	w1, #0x1
    5984:	540001e0 	b.eq	59c0 <fwp_drop1+0xc0>  // b.none
    5988:	7103fc3f 	cmp	w1, #0xff
    598c:	540002e0 	b.eq	59e8 <fwp_drop1+0xe8>  // b.none
    5990:	51000421 	sub	w1, w1, #0x1
    5994:	39000261 	strb	w1, [x19]
    5998:	a94153f3 	ldp	x19, x20, [sp, #16]
    599c:	f94013f5 	ldr	x21, [sp, #32]
    59a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    59a4:	d65f03c0 	ret
    59a8:	72003c3f 	tst	w1, #0xffff
    59ac:	54fffe60 	b.eq	5978 <fwp_drop1+0x78>  // b.none
    59b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    59b4:	f94013f5 	ldr	x21, [sp, #32]
    59b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    59bc:	d65f03c0 	ret
    59c0:	f9400813 	ldr	x19, [x0, #16]
    59c4:	97fffea4 	bl	5454 <fwp_rc_free_arr>
    59c8:	911542a0 	add	x0, x21, #0x550
    59cc:	f949d801 	ldr	x1, [x0, #5040]
    59d0:	f949ec00 	ldr	x0, [x0, #5080]
    59d4:	cb010261 	sub	x1, x19, x1
    59d8:	eb00403f 	cmp	x1, x0, lsl #16
    59dc:	54fffde2 	b.cs	5998 <fwp_drop1+0x98>  // b.hs, b.nlast
    59e0:	aa1303e0 	mov	x0, x19
    59e4:	17ffffd2 	b	592c <fwp_drop1+0x2c>
    59e8:	ca534660 	eor	x0, x19, x19, lsr #17
    59ec:	911542b5 	add	x21, x21, #0x550
    59f0:	ca402400 	eor	x0, x0, x0, lsr #9
    59f4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    59f8:	f94a2400 	ldr	x0, [x0, #5192]
    59fc:	b5000080 	cbnz	x0, 5a0c <fwp_drop1+0x10c>
    5a00:	14000010 	b	5a40 <fwp_drop1+0x140>
    5a04:	f9400800 	ldr	x0, [x0, #16]
    5a08:	b40001c0 	cbz	x0, 5a40 <fwp_drop1+0x140>
    5a0c:	f9400001 	ldr	x1, [x0]
    5a10:	eb13003f 	cmp	x1, x19
    5a14:	54ffff81 	b.ne	5a04 <fwp_drop1+0x104>  // b.any
    5a18:	f9400401 	ldr	x1, [x0, #8]
    5a1c:	d1000421 	sub	x1, x1, #0x1
    5a20:	f9000401 	str	x1, [x0, #8]
    5a24:	f103f83f 	cmp	x1, #0xfe
    5a28:	54fffb81 	b.ne	5998 <fwp_drop1+0x98>  // b.any
    5a2c:	aa1303e0 	mov	x0, x19
    5a30:	97fffae4 	bl	45c0 <fwp_rc_forget_slot>
    5a34:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5a38:	39000260 	strb	w0, [x19]
    5a3c:	17ffffd7 	b	5998 <fwp_drop1+0x98>
    5a40:	90000020 	adrp	x0, 9000 <__modti3+0x330>
    5a44:	910c6000 	add	x0, x0, #0x318
    5a48:	97fff6ce 	bl	3580 <fwp_trap>
    5a4c:	d503201f 	nop

0000000000005a50 <fwp_closure_drop>:
    5a50:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc90>
    5a54:	911540a4 	add	x4, x5, #0x550
    5a58:	aa0003e1 	mov	x1, x0
    5a5c:	f949d882 	ldr	x2, [x4, #5040]
    5a60:	f949ec80 	ldr	x0, [x4, #5080]
    5a64:	cb020022 	sub	x2, x1, x2
    5a68:	eb00405f 	cmp	x2, x0, lsl #16
    5a6c:	54000662 	b.cs	5b38 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5a70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5a74:	d350fc43 	lsr	x3, x2, #16
    5a78:	910003fd 	mov	x29, sp
    5a7c:	8b030863 	add	x3, x3, x3, lsl #2
    5a80:	f949fc84 	ldr	x4, [x4, #5112]
    5a84:	d37df063 	lsl	x3, x3, #3
    5a88:	f9000bf3 	str	x19, [sp, #16]
    5a8c:	8b030080 	add	x0, x4, x3
    5a90:	f9401013 	ldr	x19, [x0, #32]
    5a94:	b40002b3 	cbz	x19, 5ae8 <fwp_closure_drop+0x98>
    5a98:	38636883 	ldrb	w3, [x4, x3]
    5a9c:	7100087f 	cmp	w3, #0x2
    5aa0:	54000420 	b.eq	5b24 <fwp_closure_drop+0xd4>  // b.none
    5aa4:	7100047f 	cmp	w3, #0x1
    5aa8:	54000201 	b.ne	5ae8 <fwp_closure_drop+0x98>  // b.any
    5aac:	29430003 	ldp	w3, w0, [x0, #24]
    5ab0:	92403c42 	and	x2, x2, #0xffff
    5ab4:	9b037c42 	mul	x2, x2, x3
    5ab8:	d360fc42 	lsr	x2, x2, #32
    5abc:	eb00005f 	cmp	x2, x0
    5ac0:	54000142 	b.cs	5ae8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5ac4:	8b020273 	add	x19, x19, x2
    5ac8:	39400260 	ldrb	w0, [x19]
    5acc:	340000e0 	cbz	w0, 5ae8 <fwp_closure_drop+0x98>
    5ad0:	7100041f 	cmp	w0, #0x1
    5ad4:	54000100 	b.eq	5af4 <fwp_closure_drop+0xa4>  // b.none
    5ad8:	7103fc1f 	cmp	w0, #0xff
    5adc:	54000300 	b.eq	5b3c <fwp_closure_drop+0xec>  // b.none
    5ae0:	51000400 	sub	w0, w0, #0x1
    5ae4:	39000260 	strb	w0, [x19]
    5ae8:	f9400bf3 	ldr	x19, [sp, #16]
    5aec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5af0:	d65f03c0 	ret
    5af4:	d53bd040 	mrs	x0, tpidr_el0
    5af8:	91400000 	add	x0, x0, #0x0, lsl #12
    5afc:	91004000 	add	x0, x0, #0x10
    5b00:	f9400000 	ldr	x0, [x0]
    5b04:	b4000080 	cbz	x0, 5b14 <fwp_closure_drop+0xc4>
    5b08:	f9400bf3 	ldr	x19, [sp, #16]
    5b0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b10:	17fff6b5 	b	35e4 <fwp_closure_drop_push>
    5b14:	f9400bf3 	ldr	x19, [sp, #16]
    5b18:	aa0103e0 	mov	x0, x1
    5b1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b20:	17fff720 	b	37a0 <fwp_closure_drop.part.0>
    5b24:	72003c5f 	tst	w2, #0xffff
    5b28:	54fffd00 	b.eq	5ac8 <fwp_closure_drop+0x78>  // b.none
    5b2c:	f9400bf3 	ldr	x19, [sp, #16]
    5b30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b34:	d65f03c0 	ret
    5b38:	d65f03c0 	ret
    5b3c:	ca534660 	eor	x0, x19, x19, lsr #17
    5b40:	911540a5 	add	x5, x5, #0x550
    5b44:	ca402400 	eor	x0, x0, x0, lsr #9
    5b48:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5b4c:	f94a2400 	ldr	x0, [x0, #5192]
    5b50:	b5000080 	cbnz	x0, 5b60 <fwp_closure_drop+0x110>
    5b54:	14000010 	b	5b94 <fwp_closure_drop+0x144>
    5b58:	f9400800 	ldr	x0, [x0, #16]
    5b5c:	b40001c0 	cbz	x0, 5b94 <fwp_closure_drop+0x144>
    5b60:	f9400001 	ldr	x1, [x0]
    5b64:	eb13003f 	cmp	x1, x19
    5b68:	54ffff81 	b.ne	5b58 <fwp_closure_drop+0x108>  // b.any
    5b6c:	f9400401 	ldr	x1, [x0, #8]
    5b70:	d1000421 	sub	x1, x1, #0x1
    5b74:	f9000401 	str	x1, [x0, #8]
    5b78:	f103f83f 	cmp	x1, #0xfe
    5b7c:	54fffb61 	b.ne	5ae8 <fwp_closure_drop+0x98>  // b.any
    5b80:	aa1303e0 	mov	x0, x19
    5b84:	97fffa8f 	bl	45c0 <fwp_rc_forget_slot>
    5b88:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b8c:	39000260 	strb	w0, [x19]
    5b90:	17ffffd6 	b	5ae8 <fwp_closure_drop+0x98>
    5b94:	90000020 	adrp	x0, 9000 <__modti3+0x330>
    5b98:	910c6000 	add	x0, x0, #0x318
    5b9c:	97fff679 	bl	3580 <fwp_trap>

0000000000005ba0 <fwp_owned_tape_release>:
    5ba0:	b4000940 	cbz	x0, 5cc8 <fwp_owned_tape_release+0x128>
    5ba4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ba8:	910003fd 	mov	x29, sp
    5bac:	a90153f3 	stp	x19, x20, [sp, #16]
    5bb0:	aa0003f3 	mov	x19, x0
    5bb4:	f9400000 	ldr	x0, [x0]
    5bb8:	b4000060 	cbz	x0, 5bc4 <fwp_owned_tape_release+0x24>
    5bbc:	f9400661 	ldr	x1, [x19, #8]
    5bc0:	f9000401 	str	x1, [x0, #8]
    5bc4:	f9400661 	ldr	x1, [x19, #8]
    5bc8:	b4000041 	cbz	x1, 5bd0 <fwp_owned_tape_release+0x30>
    5bcc:	f9000020 	str	x0, [x1]
    5bd0:	f9400a60 	ldr	x0, [x19, #16]
    5bd4:	f9403401 	ldr	x1, [x0, #104]
    5bd8:	b40005c1 	cbz	x1, 5c90 <fwp_owned_tape_release+0xf0>
    5bdc:	a9450a60 	ldp	x0, x2, [x19, #80]
    5be0:	eb00005f 	cmp	x2, x0
    5be4:	540002ed 	b.le	5c40 <fwp_owned_tape_release+0xa0>
    5be8:	d2800014 	mov	x20, #0x0                   	// #0
    5bec:	f90013f5 	str	x21, [sp, #32]
    5bf0:	d2800015 	mov	x21, #0x0                   	// #0
    5bf4:	d503201f 	nop
    5bf8:	f9402260 	ldr	x0, [x19, #64]
    5bfc:	910006b5 	add	x21, x21, #0x1
    5c00:	f8746800 	ldr	x0, [x0, x20]
    5c04:	d63f0020 	blr	x1
    5c08:	f9402260 	ldr	x0, [x19, #64]
    5c0c:	f9400a61 	ldr	x1, [x19, #16]
    5c10:	8b140000 	add	x0, x0, x20
    5c14:	91004294 	add	x20, x20, #0x10
    5c18:	f9400400 	ldr	x0, [x0, #8]
    5c1c:	f9403421 	ldr	x1, [x1, #104]
    5c20:	d63f0020 	blr	x1
    5c24:	a9450261 	ldp	x1, x0, [x19, #80]
    5c28:	cb010000 	sub	x0, x0, x1
    5c2c:	eb15001f 	cmp	x0, x21
    5c30:	f9400a60 	ldr	x0, [x19, #16]
    5c34:	f9403401 	ldr	x1, [x0, #104]
    5c38:	54fffe0c 	b.gt	5bf8 <fwp_owned_tape_release+0x58>
    5c3c:	f94013f5 	ldr	x21, [sp, #32]
    5c40:	f9403663 	ldr	x3, [x19, #104]
    5c44:	f9401262 	ldr	x2, [x19, #32]
    5c48:	f100007f 	cmp	x3, #0x0
    5c4c:	540001ed 	b.le	5c88 <fwp_owned_tape_release+0xe8>
    5c50:	d2800014 	mov	x20, #0x0                   	// #0
    5c54:	d503201f 	nop
    5c58:	f9402660 	ldr	x0, [x19, #72]
    5c5c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5c60:	eb02001f 	cmp	x0, x2
    5c64:	540000c0 	b.eq	5c7c <fwp_owned_tape_release+0xdc>  // b.none
    5c68:	d63f0020 	blr	x1
    5c6c:	f9400a60 	ldr	x0, [x19, #16]
    5c70:	f9401262 	ldr	x2, [x19, #32]
    5c74:	f9403663 	ldr	x3, [x19, #104]
    5c78:	f9403401 	ldr	x1, [x0, #104]
    5c7c:	91000694 	add	x20, x20, #0x1
    5c80:	eb14007f 	cmp	x3, x20
    5c84:	54fffeac 	b.gt	5c58 <fwp_owned_tape_release+0xb8>
    5c88:	aa0203e0 	mov	x0, x2
    5c8c:	d63f0020 	blr	x1
    5c90:	f9401660 	ldr	x0, [x19, #40]
    5c94:	97ffff6f 	bl	5a50 <fwp_closure_drop>
    5c98:	f9401a60 	ldr	x0, [x19, #48]
    5c9c:	97ffff6d 	bl	5a50 <fwp_closure_drop>
    5ca0:	f9401e60 	ldr	x0, [x19, #56]
    5ca4:	97ffff6b 	bl	5a50 <fwp_closure_drop>
    5ca8:	f9402260 	ldr	x0, [x19, #64]
    5cac:	97fffae5 	bl	4840 <fwp_mem_free>
    5cb0:	f9402660 	ldr	x0, [x19, #72]
    5cb4:	97fffae3 	bl	4840 <fwp_mem_free>
    5cb8:	aa1303e0 	mov	x0, x19
    5cbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cc0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cc4:	17fffadf 	b	4840 <fwp_mem_free>
    5cc8:	d65f03c0 	ret
    5ccc:	d503201f 	nop

0000000000005cd0 <fwp_tape_finish>:
    5cd0:	d10203ff 	sub	sp, sp, #0x80
    5cd4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5cd8:	f947f421 	ldr	x1, [x1, #4072]
    5cdc:	a9047bfd 	stp	x29, x30, [sp, #64]
    5ce0:	910103fd 	add	x29, sp, #0x40
    5ce4:	a90553f3 	stp	x19, x20, [sp, #80]
    5ce8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5cec:	a90763f7 	stp	x23, x24, [sp, #112]
    5cf0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5cf4:	9100c316 	add	x22, x24, #0x30
    5cf8:	f9400022 	ldr	x2, [x1]
    5cfc:	f9001fe2 	str	x2, [sp, #56]
    5d00:	d2800002 	mov	x2, #0x0                   	// #0
    5d04:	9101a2c0 	add	x0, x22, #0x68
    5d08:	97fff57e 	bl	3300 <fwp_tape_buffers_dispose>
    5d0c:	f90052df 	str	xzr, [x22, #160]
    5d10:	f94022c0 	ldr	x0, [x22, #64]
    5d14:	f100001f 	cmp	x0, #0x0
    5d18:	5400030d 	b.le	5d78 <fwp_tape_finish+0xa8>
    5d1c:	910003f7 	mov	x23, sp
    5d20:	d2800015 	mov	x21, #0x0                   	// #0
    5d24:	d2800014 	mov	x20, #0x0                   	// #0
    5d28:	f94002d3 	ldr	x19, [x22]
    5d2c:	91000694 	add	x20, x20, #0x1
    5d30:	8b150273 	add	x19, x19, x21
    5d34:	9101a2b5 	add	x21, x21, #0x68
    5d38:	aa1303e0 	mov	x0, x19
    5d3c:	97fff495 	bl	2f90 <fwp_tape_unlink_scope>
    5d40:	aa1703e0 	mov	x0, x23
    5d44:	f9401261 	ldr	x1, [x19, #32]
    5d48:	f90003e1 	str	x1, [sp]
    5d4c:	f9401a62 	ldr	x2, [x19, #48]
    5d50:	f9000be2 	str	x2, [sp, #16]
    5d54:	f9402261 	ldr	x1, [x19, #64]
    5d58:	f90013e1 	str	x1, [sp, #32]
    5d5c:	97fff569 	bl	3300 <fwp_tape_buffers_dispose>
    5d60:	f9403260 	ldr	x0, [x19, #96]
    5d64:	97ffff8f 	bl	5ba0 <fwp_owned_tape_release>
    5d68:	f900327f 	str	xzr, [x19, #96]
    5d6c:	f94022c0 	ldr	x0, [x22, #64]
    5d70:	eb14001f 	cmp	x0, x20
    5d74:	54fffdac 	b.gt	5d28 <fwp_tape_finish+0x58>
    5d78:	f9401b00 	ldr	x0, [x24, #48]
    5d7c:	9100c313 	add	x19, x24, #0x30
    5d80:	97fff2f0 	bl	2940 <free@plt>
    5d84:	f9001b1f 	str	xzr, [x24, #48]
    5d88:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5d8c:	f947f400 	ldr	x0, [x0, #4072]
    5d90:	f900227f 	str	xzr, [x19, #64]
    5d94:	a90b7e7f 	stp	xzr, xzr, [x19, #176]
    5d98:	f9401fe2 	ldr	x2, [sp, #56]
    5d9c:	f9400001 	ldr	x1, [x0]
    5da0:	eb010042 	subs	x2, x2, x1
    5da4:	d2800001 	mov	x1, #0x0                   	// #0
    5da8:	540000e1 	b.ne	5dc4 <fwp_tape_finish+0xf4>  // b.any
    5dac:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5db0:	a94553f3 	ldp	x19, x20, [sp, #80]
    5db4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5db8:	a94763f7 	ldp	x23, x24, [sp, #112]
    5dbc:	910203ff 	add	sp, sp, #0x80
    5dc0:	d65f03c0 	ret
    5dc4:	97fff2af 	bl	2880 <__stack_chk_fail@plt>
    5dc8:	d503201f 	nop
    5dcc:	d503201f 	nop

0000000000005dd0 <fwp_tape_scope_release>:
    5dd0:	d10243ff 	sub	sp, sp, #0x90
    5dd4:	a9047bfd 	stp	x29, x30, [sp, #64]
    5dd8:	910103fd 	add	x29, sp, #0x40
    5ddc:	a90553f3 	stp	x19, x20, [sp, #80]
    5de0:	aa0003f4 	mov	x20, x0
    5de4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5de8:	f947f400 	ldr	x0, [x0, #4072]
    5dec:	b9400285 	ldr	w5, [x20]
    5df0:	f9400001 	ldr	x1, [x0]
    5df4:	f9001fe1 	str	x1, [sp, #56]
    5df8:	d2800001 	mov	x1, #0x0                   	// #0
    5dfc:	37f806c5 	tbnz	w5, #31, 5ed4 <fwp_tape_scope_release+0x104>
    5e00:	a90763f7 	stp	x23, x24, [sp, #112]
    5e04:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5e08:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5e0c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5e10:	f00000d3 	adrp	x19, 20000 <__data_start>
    5e14:	910003f7 	mov	x23, sp
    5e18:	9100c273 	add	x19, x19, #0x30
    5e1c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5e20:	a9065bf5 	stp	x21, x22, [sp, #96]
    5e24:	52800d16 	mov	w22, #0x68                  	// #104
    5e28:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5e2c:	f90043f9 	str	x25, [sp, #128]
    5e30:	14000006 	b	5e48 <fwp_tape_scope_release+0x78>
    5e34:	97fff533 	bl	3300 <fwp_tape_buffers_dispose>
    5e38:	aa1903e0 	mov	x0, x25
    5e3c:	97ffff59 	bl	5ba0 <fwp_owned_tape_release>
    5e40:	b9400285 	ldr	w5, [x20]
    5e44:	37f80425 	tbnz	w5, #31, 5ec8 <fwp_tape_scope_release+0xf8>
    5e48:	f9400266 	ldr	x6, [x19]
    5e4c:	9b367ca5 	smull	x5, w5, w22
    5e50:	8b0500c0 	add	x0, x6, x5
    5e54:	97fff44f 	bl	2f90 <fwp_tape_unlink_scope>
    5e58:	ad410001 	ldp	q1, q0, [x0, #32]
    5e5c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5e60:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5e64:	f9400c03 	ldr	x3, [x0, #24]
    5e68:	ad0003e1 	stp	q1, q0, [sp]
    5e6c:	b86568c1 	ldr	w1, [x6, x5]
    5e70:	a9440804 	ldp	x4, x2, [x0, #64]
    5e74:	b900041f 	str	wzr, [x0, #4]
    5e78:	f9403019 	ldr	x25, [x0, #96]
    5e7c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5e80:	f9000c1f 	str	xzr, [x0, #24]
    5e84:	a9020fe4 	stp	x4, x3, [sp, #32]
    5e88:	f9001be2 	str	x2, [sp, #48]
    5e8c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5e90:	f900301f 	str	xzr, [x0, #96]
    5e94:	6b15003f 	cmp	w1, w21
    5e98:	540000e8 	b.hi	5eb4 <fwp_tape_scope_release+0xe4>  // b.pmore
    5e9c:	9343fca5 	asr	x5, x5, #3
    5ea0:	f9405e60 	ldr	x0, [x19, #184]
    5ea4:	9b187ca5 	mul	x5, x5, x24
    5ea8:	eb0000bf 	cmp	x5, x0
    5eac:	5400004a 	b.ge	5eb4 <fwp_tape_scope_release+0xe4>  // b.tcont
    5eb0:	f9005e65 	str	x5, [x19, #184]
    5eb4:	aa1703e0 	mov	x0, x23
    5eb8:	b5fffbf9 	cbnz	x25, 5e34 <fwp_tape_scope_release+0x64>
    5ebc:	97fff8a5 	bl	4150 <fwp_tape_buffers_release>
    5ec0:	b9400285 	ldr	w5, [x20]
    5ec4:	36fffc25 	tbz	w5, #31, 5e48 <fwp_tape_scope_release+0x78>
    5ec8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5ecc:	a94763f7 	ldp	x23, x24, [sp, #112]
    5ed0:	f94043f9 	ldr	x25, [sp, #128]
    5ed4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ed8:	f947f400 	ldr	x0, [x0, #4072]
    5edc:	f9401fe2 	ldr	x2, [sp, #56]
    5ee0:	f9400001 	ldr	x1, [x0]
    5ee4:	eb010042 	subs	x2, x2, x1
    5ee8:	d2800001 	mov	x1, #0x0                   	// #0
    5eec:	540000a1 	b.ne	5f00 <fwp_tape_scope_release+0x130>  // b.any
    5ef0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5ef4:	a94553f3 	ldp	x19, x20, [sp, #80]
    5ef8:	910243ff 	add	sp, sp, #0x90
    5efc:	d65f03c0 	ret
    5f00:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f04:	a90763f7 	stp	x23, x24, [sp, #112]
    5f08:	f90043f9 	str	x25, [sp, #128]
    5f0c:	97fff25d 	bl	2880 <__stack_chk_fail@plt>

0000000000005f10 <fwp_drop4>:
    5f10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f14:	910003fd 	mov	x29, sp
    5f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    5f1c:	90000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    5f20:	911542d5 	add	x21, x22, #0x550
    5f24:	a90153f3 	stp	x19, x20, [sp, #16]
    5f28:	aa0003f3 	mov	x19, x0
    5f2c:	f949daa1 	ldr	x1, [x21, #5040]
    5f30:	f949eea0 	ldr	x0, [x21, #5080]
    5f34:	cb010261 	sub	x1, x19, x1
    5f38:	eb00403f 	cmp	x1, x0, lsl #16
    5f3c:	54000382 	b.cs	5fac <fwp_drop4+0x9c>  // b.hs, b.nlast
    5f40:	d350fc22 	lsr	x2, x1, #16
    5f44:	f949fea3 	ldr	x3, [x21, #5112]
    5f48:	8b020842 	add	x2, x2, x2, lsl #2
    5f4c:	d37df042 	lsl	x2, x2, #3
    5f50:	8b020060 	add	x0, x3, x2
    5f54:	f9401014 	ldr	x20, [x0, #32]
    5f58:	b40002b4 	cbz	x20, 5fac <fwp_drop4+0x9c>
    5f5c:	38626862 	ldrb	w2, [x3, x2]
    5f60:	7100085f 	cmp	w2, #0x2
    5f64:	540002c0 	b.eq	5fbc <fwp_drop4+0xac>  // b.none
    5f68:	7100045f 	cmp	w2, #0x1
    5f6c:	54000201 	b.ne	5fac <fwp_drop4+0x9c>  // b.any
    5f70:	29430002 	ldp	w2, w0, [x0, #24]
    5f74:	92403c21 	and	x1, x1, #0xffff
    5f78:	9b027c21 	mul	x1, x1, x2
    5f7c:	d360fc21 	lsr	x1, x1, #32
    5f80:	eb00003f 	cmp	x1, x0
    5f84:	54000142 	b.cs	5fac <fwp_drop4+0x9c>  // b.hs, b.nlast
    5f88:	8b010294 	add	x20, x20, x1
    5f8c:	39400280 	ldrb	w0, [x20]
    5f90:	340000e0 	cbz	w0, 5fac <fwp_drop4+0x9c>
    5f94:	7100041f 	cmp	w0, #0x1
    5f98:	540001e0 	b.eq	5fd4 <fwp_drop4+0xc4>  // b.none
    5f9c:	7103fc1f 	cmp	w0, #0xff
    5fa0:	540007c0 	b.eq	6098 <fwp_drop4+0x188>  // b.none
    5fa4:	51000400 	sub	w0, w0, #0x1
    5fa8:	39000280 	strb	w0, [x20]
    5fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fb0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5fb4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fb8:	d65f03c0 	ret
    5fbc:	72003c3f 	tst	w1, #0xffff
    5fc0:	54fffe60 	b.eq	5f8c <fwp_drop4+0x7c>  // b.none
    5fc4:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fc8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5fcc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fd0:	d65f03c0 	ret
    5fd4:	911542c2 	add	x2, x22, #0x550
    5fd8:	f9400660 	ldr	x0, [x19, #8]
    5fdc:	f949d841 	ldr	x1, [x2, #5040]
    5fe0:	f949ec42 	ldr	x2, [x2, #5080]
    5fe4:	cb010001 	sub	x1, x0, x1
    5fe8:	eb02403f 	cmp	x1, x2, lsl #16
    5fec:	54000362 	b.cs	6058 <fwp_drop4+0x148>  // b.hs, b.nlast
    5ff0:	d350fc22 	lsr	x2, x1, #16
    5ff4:	8b020842 	add	x2, x2, x2, lsl #2
    5ff8:	d37df042 	lsl	x2, x2, #3
    5ffc:	8b020064 	add	x4, x3, x2
    6000:	f9401094 	ldr	x20, [x4, #32]
    6004:	b40002b4 	cbz	x20, 6058 <fwp_drop4+0x148>
    6008:	38626862 	ldrb	w2, [x3, x2]
    600c:	7100085f 	cmp	w2, #0x2
    6010:	540003e0 	b.eq	608c <fwp_drop4+0x17c>  // b.none
    6014:	7100045f 	cmp	w2, #0x1
    6018:	54000201 	b.ne	6058 <fwp_drop4+0x148>  // b.any
    601c:	29430883 	ldp	w3, w2, [x4, #24]
    6020:	92403c21 	and	x1, x1, #0xffff
    6024:	9b037c21 	mul	x1, x1, x3
    6028:	d360fc21 	lsr	x1, x1, #32
    602c:	eb02003f 	cmp	x1, x2
    6030:	54000142 	b.cs	6058 <fwp_drop4+0x148>  // b.hs, b.nlast
    6034:	8b010294 	add	x20, x20, x1
    6038:	39400281 	ldrb	w1, [x20]
    603c:	340000e1 	cbz	w1, 6058 <fwp_drop4+0x148>
    6040:	7100043f 	cmp	w1, #0x1
    6044:	54000200 	b.eq	6084 <fwp_drop4+0x174>  // b.none
    6048:	7103fc3f 	cmp	w1, #0xff
    604c:	54000580 	b.eq	60fc <fwp_drop4+0x1ec>  // b.none
    6050:	51000421 	sub	w1, w1, #0x1
    6054:	39000281 	strb	w1, [x20]
    6058:	f9400a74 	ldr	x20, [x19, #16]
    605c:	aa1303e0 	mov	x0, x19
    6060:	97fffcfd 	bl	5454 <fwp_rc_free_arr>
    6064:	911542c0 	add	x0, x22, #0x550
    6068:	f949d801 	ldr	x1, [x0, #5040]
    606c:	f949ec00 	ldr	x0, [x0, #5080]
    6070:	cb010281 	sub	x1, x20, x1
    6074:	eb00403f 	cmp	x1, x0, lsl #16
    6078:	54fff9a2 	b.cs	5fac <fwp_drop4+0x9c>  // b.hs, b.nlast
    607c:	aa1403f3 	mov	x19, x20
    6080:	17ffffb0 	b	5f40 <fwp_drop4+0x30>
    6084:	97fffcf4 	bl	5454 <fwp_rc_free_arr>
    6088:	17fffff4 	b	6058 <fwp_drop4+0x148>
    608c:	72003c3f 	tst	w1, #0xffff
    6090:	54fffe41 	b.ne	6058 <fwp_drop4+0x148>  // b.any
    6094:	17ffffe9 	b	6038 <fwp_drop4+0x128>
    6098:	ca544681 	eor	x1, x20, x20, lsr #17
    609c:	911542c0 	add	x0, x22, #0x550
    60a0:	ca412421 	eor	x1, x1, x1, lsr #9
    60a4:	8b210c01 	add	x1, x0, w1, uxtb #3
    60a8:	f94a2420 	ldr	x0, [x1, #5192]
    60ac:	b5000080 	cbnz	x0, 60bc <fwp_drop4+0x1ac>
    60b0:	14000010 	b	60f0 <fwp_drop4+0x1e0>
    60b4:	f9400800 	ldr	x0, [x0, #16]
    60b8:	b40001c0 	cbz	x0, 60f0 <fwp_drop4+0x1e0>
    60bc:	f9400001 	ldr	x1, [x0]
    60c0:	eb14003f 	cmp	x1, x20
    60c4:	54ffff81 	b.ne	60b4 <fwp_drop4+0x1a4>  // b.any
    60c8:	f9400401 	ldr	x1, [x0, #8]
    60cc:	d1000421 	sub	x1, x1, #0x1
    60d0:	f9000401 	str	x1, [x0, #8]
    60d4:	f103f83f 	cmp	x1, #0xfe
    60d8:	54fff6a1 	b.ne	5fac <fwp_drop4+0x9c>  // b.any
    60dc:	aa1403e0 	mov	x0, x20
    60e0:	97fff938 	bl	45c0 <fwp_rc_forget_slot>
    60e4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    60e8:	39000280 	strb	w0, [x20]
    60ec:	17ffffb0 	b	5fac <fwp_drop4+0x9c>
    60f0:	f0000000 	adrp	x0, 9000 <__modti3+0x330>
    60f4:	910c6000 	add	x0, x0, #0x318
    60f8:	97fff522 	bl	3580 <fwp_trap>
    60fc:	ca544680 	eor	x0, x20, x20, lsr #17
    6100:	911542c1 	add	x1, x22, #0x550
    6104:	ca402400 	eor	x0, x0, x0, lsr #9
    6108:	8b200c20 	add	x0, x1, w0, uxtb #3
    610c:	f94a2400 	ldr	x0, [x0, #5192]
    6110:	b5000080 	cbnz	x0, 6120 <fwp_drop4+0x210>
    6114:	17fffff7 	b	60f0 <fwp_drop4+0x1e0>
    6118:	f9400800 	ldr	x0, [x0, #16]
    611c:	b4fffea0 	cbz	x0, 60f0 <fwp_drop4+0x1e0>
    6120:	f9400001 	ldr	x1, [x0]
    6124:	eb14003f 	cmp	x1, x20
    6128:	54ffff81 	b.ne	6118 <fwp_drop4+0x208>  // b.any
    612c:	f9400401 	ldr	x1, [x0, #8]
    6130:	d1000421 	sub	x1, x1, #0x1
    6134:	f9000401 	str	x1, [x0, #8]
    6138:	f103f83f 	cmp	x1, #0xfe
    613c:	54fff8e1 	b.ne	6058 <fwp_drop4+0x148>  // b.any
    6140:	aa1403e0 	mov	x0, x20
    6144:	97fff91f 	bl	45c0 <fwp_rc_forget_slot>
    6148:	12800020 	mov	w0, #0xfffffffe            	// #-2
    614c:	39000280 	strb	w0, [x20]
    6150:	17ffffc2 	b	6058 <fwp_drop4+0x148>

0000000000006154 <fwp_arg_drop37>:
    6154:	7100003f 	cmp	w1, #0x0
    6158:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    615c:	54000041 	b.ne	6164 <fwp_arg_drop37+0x10>  // b.any
    6160:	d65f03c0 	ret
    6164:	f9400000 	ldr	x0, [x0]
    6168:	17ffff6a 	b	5f10 <fwp_drop4>
    616c:	d503201f 	nop

0000000000006170 <fwp_task_dispose>:
    6170:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6174:	910003fd 	mov	x29, sp
    6178:	f9000bf3 	str	x19, [sp, #16]
    617c:	aa0003f3 	mov	x19, x0
    6180:	39414000 	ldrb	w0, [x0, #80]
    6184:	36000720 	tbz	w0, #0, 6268 <fwp_task_dispose+0xf8>
    6188:	f9400a60 	ldr	x0, [x19, #16]
    618c:	b50006e0 	cbnz	x0, 6268 <fwp_task_dispose+0xf8>
    6190:	a9478660 	ldp	x0, x1, [x19, #120]
    6194:	39014e7f 	strb	wzr, [x19, #83]
    6198:	f9003e7f 	str	xzr, [x19, #120]
    619c:	f100003f 	cmp	x1, #0x0
    61a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    61a4:	54000040 	b.eq	61ac <fwp_task_dispose+0x3c>  // b.none
    61a8:	d63f0020 	blr	x1
    61ac:	f9405660 	ldr	x0, [x19, #168]
    61b0:	97fff9a4 	bl	4840 <fwp_mem_free>
    61b4:	f900567f 	str	xzr, [x19, #168]
    61b8:	b9405e60 	ldr	w0, [x19, #92]
    61bc:	7100041f 	cmp	w0, #0x1
    61c0:	54000420 	b.eq	6244 <fwp_task_dispose+0xd4>  // b.none
    61c4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    61c8:	91154042 	add	x2, x2, #0x550
    61cc:	f949d840 	ldr	x0, [x2, #5040]
    61d0:	f949ec41 	ldr	x1, [x2, #5080]
    61d4:	cb000260 	sub	x0, x19, x0
    61d8:	eb01401f 	cmp	x0, x1, lsl #16
    61dc:	540002e2 	b.cs	6238 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    61e0:	d350fc01 	lsr	x1, x0, #16
    61e4:	f949fc44 	ldr	x4, [x2, #5112]
    61e8:	8b010821 	add	x1, x1, x1, lsl #2
    61ec:	d37df021 	lsl	x1, x1, #3
    61f0:	8b010083 	add	x3, x4, x1
    61f4:	f9401062 	ldr	x2, [x3, #32]
    61f8:	b4000202 	cbz	x2, 6238 <fwp_task_dispose+0xc8>
    61fc:	38616881 	ldrb	w1, [x4, x1]
    6200:	7100083f 	cmp	w1, #0x2
    6204:	54000280 	b.eq	6254 <fwp_task_dispose+0xe4>  // b.none
    6208:	7100043f 	cmp	w1, #0x1
    620c:	54000161 	b.ne	6238 <fwp_task_dispose+0xc8>  // b.any
    6210:	29430464 	ldp	w4, w1, [x3, #24]
    6214:	92403c00 	and	x0, x0, #0xffff
    6218:	9b047c00 	mul	x0, x0, x4
    621c:	d360fc00 	lsr	x0, x0, #32
    6220:	eb01001f 	cmp	x0, x1
    6224:	540000a2 	b.cs	6238 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6228:	8b000042 	add	x2, x2, x0
    622c:	39400040 	ldrb	w0, [x2]
    6230:	7100041f 	cmp	w0, #0x1
    6234:	54000080 	b.eq	6244 <fwp_task_dispose+0xd4>  // b.none
    6238:	f9400bf3 	ldr	x19, [sp, #16]
    623c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6240:	d65f03c0 	ret
    6244:	aa1303e0 	mov	x0, x19
    6248:	f9400bf3 	ldr	x19, [sp, #16]
    624c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6250:	17fff97c 	b	4840 <fwp_mem_free>
    6254:	72003c1f 	tst	w0, #0xffff
    6258:	54fffea0 	b.eq	622c <fwp_task_dispose+0xbc>  // b.none
    625c:	f9400bf3 	ldr	x19, [sp, #16]
    6260:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6264:	d65f03c0 	ret
    6268:	97fff19a 	bl	28d0 <abort@plt>
    626c:	d503201f 	nop

0000000000006270 <fwp_free_zombie>:
    6270:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6274:	910003fd 	mov	x29, sp
    6278:	a90153f3 	stp	x19, x20, [sp, #16]
    627c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6280:	9100c281 	add	x1, x20, #0x30
    6284:	f9406033 	ldr	x19, [x1, #192]
    6288:	b4000333 	cbz	x19, 62ec <fwp_free_zombie+0x7c>
    628c:	f9400820 	ldr	x0, [x1, #16]
    6290:	eb00027f 	cmp	x19, x0
    6294:	540002c0 	b.eq	62ec <fwp_free_zombie+0x7c>  // b.none
    6298:	b940c822 	ldr	w2, [x1, #200]
    629c:	f9400a60 	ldr	x0, [x19, #16]
    62a0:	7100fc5f 	cmp	w2, #0x3f
    62a4:	5400078c 	b.gt	6394 <fwp_free_zombie+0x124>
    62a8:	91034023 	add	x3, x1, #0xd0
    62ac:	11000444 	add	w4, w2, #0x1
    62b0:	b900c824 	str	w4, [x1, #200]
    62b4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    62b8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    62bc:	a9530261 	ldp	x1, x0, [x19, #304]
    62c0:	b4000741 	cbz	x1, 63a8 <fwp_free_zombie+0x138>
    62c4:	f9009c20 	str	x0, [x1, #312]
    62c8:	b4000040 	cbz	x0, 62d0 <fwp_free_zombie+0x60>
    62cc:	f9009801 	str	x1, [x0, #304]
    62d0:	9100c294 	add	x20, x20, #0x30
    62d4:	b9405e60 	ldr	w0, [x19, #92]
    62d8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    62dc:	f900629f 	str	xzr, [x20, #192]
    62e0:	34000140 	cbz	w0, 6308 <fwp_free_zombie+0x98>
    62e4:	7100041f 	cmp	w0, #0x1
    62e8:	54000080 	b.eq	62f8 <fwp_free_zombie+0x88>  // b.none
    62ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    62f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62f4:	d65f03c0 	ret
    62f8:	aa1303e0 	mov	x0, x19
    62fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6300:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6304:	17ffff9b 	b	6170 <fwp_task_dispose>
    6308:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc90>
    630c:	91154082 	add	x2, x4, #0x550
    6310:	f949d841 	ldr	x1, [x2, #5040]
    6314:	f949ec40 	ldr	x0, [x2, #5080]
    6318:	cb010261 	sub	x1, x19, x1
    631c:	eb00403f 	cmp	x1, x0, lsl #16
    6320:	54fffe62 	b.cs	62ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6324:	d350fc20 	lsr	x0, x1, #16
    6328:	f949fc43 	ldr	x3, [x2, #5112]
    632c:	8b000800 	add	x0, x0, x0, lsl #2
    6330:	d37df000 	lsl	x0, x0, #3
    6334:	8b000062 	add	x2, x3, x0
    6338:	f9401054 	ldr	x20, [x2, #32]
    633c:	b4fffd94 	cbz	x20, 62ec <fwp_free_zombie+0x7c>
    6340:	38606860 	ldrb	w0, [x3, x0]
    6344:	7100081f 	cmp	w0, #0x2
    6348:	54000360 	b.eq	63b4 <fwp_free_zombie+0x144>  // b.none
    634c:	7100041f 	cmp	w0, #0x1
    6350:	54fffce1 	b.ne	62ec <fwp_free_zombie+0x7c>  // b.any
    6354:	29430043 	ldp	w3, w0, [x2, #24]
    6358:	92403c21 	and	x1, x1, #0xffff
    635c:	9b037c21 	mul	x1, x1, x3
    6360:	d360fc21 	lsr	x1, x1, #32
    6364:	eb00003f 	cmp	x1, x0
    6368:	54fffc22 	b.cs	62ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    636c:	8b010294 	add	x20, x20, x1
    6370:	39400280 	ldrb	w0, [x20]
    6374:	34fffbc0 	cbz	w0, 62ec <fwp_free_zombie+0x7c>
    6378:	7100041f 	cmp	w0, #0x1
    637c:	54fffbe0 	b.eq	62f8 <fwp_free_zombie+0x88>  // b.none
    6380:	7103fc1f 	cmp	w0, #0xff
    6384:	540001e0 	b.eq	63c0 <fwp_free_zombie+0x150>  // b.none
    6388:	51000400 	sub	w0, w0, #0x1
    638c:	39000280 	strb	w0, [x20]
    6390:	17ffffd7 	b	62ec <fwp_free_zombie+0x7c>
    6394:	f9400e61 	ldr	x1, [x19, #24]
    6398:	97fff182 	bl	29a0 <munmap@plt>
    639c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    63a0:	a9530261 	ldp	x1, x0, [x19, #304]
    63a4:	b5fff901 	cbnz	x1, 62c4 <fwp_free_zombie+0x54>
    63a8:	9100c282 	add	x2, x20, #0x30
    63ac:	f9016840 	str	x0, [x2, #720]
    63b0:	17ffffc6 	b	62c8 <fwp_free_zombie+0x58>
    63b4:	72003c3f 	tst	w1, #0xffff
    63b8:	54fff9a1 	b.ne	62ec <fwp_free_zombie+0x7c>  // b.any
    63bc:	17ffffed 	b	6370 <fwp_free_zombie+0x100>
    63c0:	ca544680 	eor	x0, x20, x20, lsr #17
    63c4:	91154084 	add	x4, x4, #0x550
    63c8:	ca402400 	eor	x0, x0, x0, lsr #9
    63cc:	8b200c80 	add	x0, x4, w0, uxtb #3
    63d0:	f94a2400 	ldr	x0, [x0, #5192]
    63d4:	b5000080 	cbnz	x0, 63e4 <fwp_free_zombie+0x174>
    63d8:	14000010 	b	6418 <fwp_free_zombie+0x1a8>
    63dc:	f9400800 	ldr	x0, [x0, #16]
    63e0:	b40001c0 	cbz	x0, 6418 <fwp_free_zombie+0x1a8>
    63e4:	f9400001 	ldr	x1, [x0]
    63e8:	eb14003f 	cmp	x1, x20
    63ec:	54ffff81 	b.ne	63dc <fwp_free_zombie+0x16c>  // b.any
    63f0:	f9400401 	ldr	x1, [x0, #8]
    63f4:	d1000421 	sub	x1, x1, #0x1
    63f8:	f9000401 	str	x1, [x0, #8]
    63fc:	f103f83f 	cmp	x1, #0xfe
    6400:	54fff761 	b.ne	62ec <fwp_free_zombie+0x7c>  // b.any
    6404:	aa1403e0 	mov	x0, x20
    6408:	97fff86e 	bl	45c0 <fwp_rc_forget_slot>
    640c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6410:	39000280 	strb	w0, [x20]
    6414:	17ffffb6 	b	62ec <fwp_free_zombie+0x7c>
    6418:	f0000000 	adrp	x0, 9000 <__modti3+0x330>
    641c:	910c6000 	add	x0, x0, #0x318
    6420:	97fff458 	bl	3580 <fwp_trap>

0000000000006424 <fwp_block>:
    6424:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6428:	910003fd 	mov	x29, sp
    642c:	a90153f3 	stp	x19, x20, [sp, #16]
    6430:	d00000d3 	adrp	x19, 20000 <__data_start>
    6434:	9100c274 	add	x20, x19, #0x30
    6438:	f9401a82 	ldr	x2, [x20, #48]
    643c:	b4000622 	cbz	x2, 6500 <fwp_block+0xdc>
    6440:	9100c261 	add	x1, x19, #0x30
    6444:	f9408040 	ldr	x0, [x2, #256]
    6448:	f9001820 	str	x0, [x1, #48]
    644c:	b4000680 	cbz	x0, 651c <fwp_block+0xf8>
    6450:	9100c263 	add	x3, x19, #0x30
    6454:	3901505f 	strb	wzr, [x2, #84]
    6458:	f9400864 	ldr	x4, [x3, #16]
    645c:	eb02009f 	cmp	x4, x2
    6460:	54000440 	b.eq	64e8 <fwp_block+0xc4>  // b.none
    6464:	f9416c65 	ldr	x5, [x3, #728]
    6468:	f9000862 	str	x2, [x3, #16]
    646c:	f9400441 	ldr	x1, [x2, #8]
    6470:	f9004885 	str	x5, [x4, #144]
    6474:	f9417065 	ldr	x5, [x3, #736]
    6478:	f9004c85 	str	x5, [x4, #152]
    647c:	f9417465 	ldr	x5, [x3, #744]
    6480:	f9005085 	str	x5, [x4, #160]
    6484:	f9417865 	ldr	x5, [x3, #752]
    6488:	f9005485 	str	x5, [x4, #168]
    648c:	f9417c65 	ldr	x5, [x3, #760]
    6490:	f9005885 	str	x5, [x4, #176]
    6494:	f9418065 	ldr	x5, [x3, #768]
    6498:	f9005c85 	str	x5, [x4, #184]
    649c:	f9418465 	ldr	x5, [x3, #776]
    64a0:	f9006085 	str	x5, [x4, #192]
    64a4:	f9400480 	ldr	x0, [x4, #8]
    64a8:	f9404844 	ldr	x4, [x2, #144]
    64ac:	f9016c64 	str	x4, [x3, #728]
    64b0:	f9404c44 	ldr	x4, [x2, #152]
    64b4:	f9017064 	str	x4, [x3, #736]
    64b8:	f9405044 	ldr	x4, [x2, #160]
    64bc:	f9017464 	str	x4, [x3, #744]
    64c0:	f9405444 	ldr	x4, [x2, #168]
    64c4:	f9017864 	str	x4, [x3, #752]
    64c8:	f9405844 	ldr	x4, [x2, #176]
    64cc:	f9017c64 	str	x4, [x3, #760]
    64d0:	a94b8844 	ldp	x4, x2, [x2, #184]
    64d4:	f9018064 	str	x4, [x3, #768]
    64d8:	f9018462 	str	x2, [x3, #776]
    64dc:	97fff101 	bl	28e0 <swapcontext@plt>
    64e0:	97ffff64 	bl	6270 <fwp_free_zombie>
    64e4:	d503201f 	nop
    64e8:	9100c260 	add	x0, x19, #0x30
    64ec:	b9431000 	ldr	w0, [x0, #784]
    64f0:	340001a0 	cbz	w0, 6524 <fwp_block+0x100>
    64f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    64f8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64fc:	d65f03c0 	ret
    6500:	97fff75c 	bl	4270 <fwp_poll_events>
    6504:	f9401a82 	ldr	x2, [x20, #48]
    6508:	b4ffffc2 	cbz	x2, 6500 <fwp_block+0xdc>
    650c:	9100c261 	add	x1, x19, #0x30
    6510:	f9408040 	ldr	x0, [x2, #256]
    6514:	f9001820 	str	x0, [x1, #48]
    6518:	b5fff9c0 	cbnz	x0, 6450 <fwp_block+0x2c>
    651c:	f900143f 	str	xzr, [x1, #40]
    6520:	17ffffcc 	b	6450 <fwp_block+0x2c>
    6524:	f0000000 	adrp	x0, 9000 <__modti3+0x330>
    6528:	91112000 	add	x0, x0, #0x448
    652c:	97fff139 	bl	2a10 <getenv@plt>
    6530:	5284e202 	mov	w2, #0x2710                	// #10000
    6534:	b4000060 	cbz	x0, 6540 <fwp_block+0x11c>
    6538:	39400001 	ldrb	w1, [x0]
    653c:	350000c1 	cbnz	w1, 6554 <fwp_block+0x130>
    6540:	9100c273 	add	x19, x19, #0x30
    6544:	b9031262 	str	w2, [x19, #784]
    6548:	a94153f3 	ldp	x19, x20, [sp, #16]
    654c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6550:	d65f03c0 	ret
    6554:	52800142 	mov	w2, #0xa                   	// #10
    6558:	d2800001 	mov	x1, #0x0                   	// #0
    655c:	97fff07d 	bl	2750 <strtoll@plt>
    6560:	d1000403 	sub	x3, x0, #0x1
    6564:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6568:	eb02007f 	cmp	x3, x2
    656c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6570:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6574:	17fffff3 	b	6540 <fwp_block+0x11c>
    6578:	d503201f 	nop
    657c:	d503201f 	nop

0000000000006580 <fwp_drop10>:
    6580:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6584:	910003fd 	mov	x29, sp
    6588:	a90153f3 	stp	x19, x20, [sp, #16]
    658c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc90>
    6590:	f90013f5 	str	x21, [sp, #32]
    6594:	91154275 	add	x21, x19, #0x550
    6598:	f949daa1 	ldr	x1, [x21, #5040]
    659c:	f949eea2 	ldr	x2, [x21, #5080]
    65a0:	cb010001 	sub	x1, x0, x1
    65a4:	eb02403f 	cmp	x1, x2, lsl #16
    65a8:	54000382 	b.cs	6618 <fwp_drop10+0x98>  // b.hs, b.nlast
    65ac:	d350fc22 	lsr	x2, x1, #16
    65b0:	f949fea3 	ldr	x3, [x21, #5112]
    65b4:	8b020842 	add	x2, x2, x2, lsl #2
    65b8:	d37df042 	lsl	x2, x2, #3
    65bc:	8b020064 	add	x4, x3, x2
    65c0:	f9401094 	ldr	x20, [x4, #32]
    65c4:	b40002b4 	cbz	x20, 6618 <fwp_drop10+0x98>
    65c8:	38626862 	ldrb	w2, [x3, x2]
    65cc:	7100085f 	cmp	w2, #0x2
    65d0:	540007a0 	b.eq	66c4 <fwp_drop10+0x144>  // b.none
    65d4:	7100045f 	cmp	w2, #0x1
    65d8:	54000201 	b.ne	6618 <fwp_drop10+0x98>  // b.any
    65dc:	29430885 	ldp	w5, w2, [x4, #24]
    65e0:	92403c21 	and	x1, x1, #0xffff
    65e4:	9b057c21 	mul	x1, x1, x5
    65e8:	d360fc21 	lsr	x1, x1, #32
    65ec:	eb02003f 	cmp	x1, x2
    65f0:	54000142 	b.cs	6618 <fwp_drop10+0x98>  // b.hs, b.nlast
    65f4:	8b010294 	add	x20, x20, x1
    65f8:	39400281 	ldrb	w1, [x20]
    65fc:	340000e1 	cbz	w1, 6618 <fwp_drop10+0x98>
    6600:	7100043f 	cmp	w1, #0x1
    6604:	54000120 	b.eq	6628 <fwp_drop10+0xa8>  // b.none
    6608:	7103fc3f 	cmp	w1, #0xff
    660c:	540007c0 	b.eq	6704 <fwp_drop10+0x184>  // b.none
    6610:	51000421 	sub	w1, w1, #0x1
    6614:	39000281 	strb	w1, [x20]
    6618:	a94153f3 	ldp	x19, x20, [sp, #16]
    661c:	f94013f5 	ldr	x21, [sp, #32]
    6620:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6624:	d65f03c0 	ret
    6628:	f9400001 	ldr	x1, [x0]
    662c:	b7f80581 	tbnz	x1, #63, 66dc <fwp_drop10+0x15c>
    6630:	91154273 	add	x19, x19, #0x550
    6634:	f949da61 	ldr	x1, [x19, #5040]
    6638:	f949ee62 	ldr	x2, [x19, #5080]
    663c:	cb010001 	sub	x1, x0, x1
    6640:	eb02403f 	cmp	x1, x2, lsl #16
    6644:	54fffea2 	b.cs	6618 <fwp_drop10+0x98>  // b.hs, b.nlast
    6648:	d350fc22 	lsr	x2, x1, #16
    664c:	8b020842 	add	x2, x2, x2, lsl #2
    6650:	d37df042 	lsl	x2, x2, #3
    6654:	8b020065 	add	x5, x3, x2
    6658:	f94010a4 	ldr	x4, [x5, #32]
    665c:	b4fffde4 	cbz	x4, 6618 <fwp_drop10+0x98>
    6660:	38626862 	ldrb	w2, [x3, x2]
    6664:	7100085f 	cmp	w2, #0x2
    6668:	54000220 	b.eq	66ac <fwp_drop10+0x12c>  // b.none
    666c:	7100045f 	cmp	w2, #0x1
    6670:	54fffd41 	b.ne	6618 <fwp_drop10+0x98>  // b.any
    6674:	294308a3 	ldp	w3, w2, [x5, #24]
    6678:	92403c21 	and	x1, x1, #0xffff
    667c:	9b037c21 	mul	x1, x1, x3
    6680:	d360fc21 	lsr	x1, x1, #32
    6684:	eb02003f 	cmp	x1, x2
    6688:	54fffc82 	b.cs	6618 <fwp_drop10+0x98>  // b.hs, b.nlast
    668c:	8b010084 	add	x4, x4, x1
    6690:	39400081 	ldrb	w1, [x4]
    6694:	7100043f 	cmp	w1, #0x1
    6698:	54fffc01 	b.ne	6618 <fwp_drop10+0x98>  // b.any
    669c:	a94153f3 	ldp	x19, x20, [sp, #16]
    66a0:	f94013f5 	ldr	x21, [sp, #32]
    66a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66a8:	17fff866 	b	4840 <fwp_mem_free>
    66ac:	72003c3f 	tst	w1, #0xffff
    66b0:	54ffff00 	b.eq	6690 <fwp_drop10+0x110>  // b.none
    66b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66b8:	f94013f5 	ldr	x21, [sp, #32]
    66bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66c0:	d65f03c0 	ret
    66c4:	72003c3f 	tst	w1, #0xffff
    66c8:	54fff980 	b.eq	65f8 <fwp_drop10+0x78>  // b.none
    66cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    66d0:	f94013f5 	ldr	x21, [sp, #32]
    66d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66d8:	d65f03c0 	ret
    66dc:	f9400414 	ldr	x20, [x0, #8]
    66e0:	97fffb5d 	bl	5454 <fwp_rc_free_arr>
    66e4:	91154260 	add	x0, x19, #0x550
    66e8:	f949d801 	ldr	x1, [x0, #5040]
    66ec:	f949ec00 	ldr	x0, [x0, #5080]
    66f0:	cb010281 	sub	x1, x20, x1
    66f4:	eb00403f 	cmp	x1, x0, lsl #16
    66f8:	54fff902 	b.cs	6618 <fwp_drop10+0x98>  // b.hs, b.nlast
    66fc:	aa1403e0 	mov	x0, x20
    6700:	17ffffab 	b	65ac <fwp_drop10+0x2c>
    6704:	ca544680 	eor	x0, x20, x20, lsr #17
    6708:	91154273 	add	x19, x19, #0x550
    670c:	ca402400 	eor	x0, x0, x0, lsr #9
    6710:	8b200e60 	add	x0, x19, w0, uxtb #3
    6714:	f94a2400 	ldr	x0, [x0, #5192]
    6718:	b5000080 	cbnz	x0, 6728 <fwp_drop10+0x1a8>
    671c:	14000010 	b	675c <fwp_drop10+0x1dc>
    6720:	f9400800 	ldr	x0, [x0, #16]
    6724:	b40001c0 	cbz	x0, 675c <fwp_drop10+0x1dc>
    6728:	f9400001 	ldr	x1, [x0]
    672c:	eb14003f 	cmp	x1, x20
    6730:	54ffff81 	b.ne	6720 <fwp_drop10+0x1a0>  // b.any
    6734:	f9400401 	ldr	x1, [x0, #8]
    6738:	d1000421 	sub	x1, x1, #0x1
    673c:	f9000401 	str	x1, [x0, #8]
    6740:	f103f83f 	cmp	x1, #0xfe
    6744:	54fff6a1 	b.ne	6618 <fwp_drop10+0x98>  // b.any
    6748:	aa1403e0 	mov	x0, x20
    674c:	97fff79d 	bl	45c0 <fwp_rc_forget_slot>
    6750:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6754:	39000280 	strb	w0, [x20]
    6758:	17ffffb0 	b	6618 <fwp_drop10+0x98>
    675c:	f0000000 	adrp	x0, 9000 <__modti3+0x330>
    6760:	910c6000 	add	x0, x0, #0x318
    6764:	97fff387 	bl	3580 <fwp_trap>
    6768:	d503201f 	nop
    676c:	d503201f 	nop

0000000000006770 <fwp_caps173>:
    6770:	34000041 	cbz	w1, 6778 <fwp_caps173+0x8>
    6774:	d65f03c0 	ret
    6778:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc90>
    677c:	91154063 	add	x3, x3, #0x550
    6780:	f949d861 	ldr	x1, [x3, #5040]
    6784:	f949ec62 	ldr	x2, [x3, #5080]
    6788:	cb010001 	sub	x1, x0, x1
    678c:	eb02403f 	cmp	x1, x2, lsl #16
    6790:	54ffff22 	b.cs	6774 <fwp_caps173+0x4>  // b.hs, b.nlast
    6794:	d350fc22 	lsr	x2, x1, #16
    6798:	f949fc65 	ldr	x5, [x3, #5112]
    679c:	8b020842 	add	x2, x2, x2, lsl #2
    67a0:	d37df042 	lsl	x2, x2, #3
    67a4:	8b0200a4 	add	x4, x5, x2
    67a8:	f9401083 	ldr	x3, [x4, #32]
    67ac:	b4fffe43 	cbz	x3, 6774 <fwp_caps173+0x4>
    67b0:	386268a2 	ldrb	w2, [x5, x2]
    67b4:	7100085f 	cmp	w2, #0x2
    67b8:	540001c0 	b.eq	67f0 <fwp_caps173+0x80>  // b.none
    67bc:	7100045f 	cmp	w2, #0x1
    67c0:	54fffda1 	b.ne	6774 <fwp_caps173+0x4>  // b.any
    67c4:	29430885 	ldp	w5, w2, [x4, #24]
    67c8:	92403c21 	and	x1, x1, #0xffff
    67cc:	9b057c21 	mul	x1, x1, x5
    67d0:	d360fc21 	lsr	x1, x1, #32
    67d4:	eb02003f 	cmp	x1, x2
    67d8:	54fffce2 	b.cs	6774 <fwp_caps173+0x4>  // b.hs, b.nlast
    67dc:	8b010063 	add	x3, x3, x1
    67e0:	39400061 	ldrb	w1, [x3]
    67e4:	7100043f 	cmp	w1, #0x1
    67e8:	54fffc61 	b.ne	6774 <fwp_caps173+0x4>  // b.any
    67ec:	17fff815 	b	4840 <fwp_mem_free>
    67f0:	72003c3f 	tst	w1, #0xffff
    67f4:	54ffff60 	b.eq	67e0 <fwp_caps173+0x70>  // b.none
    67f8:	d65f03c0 	ret
    67fc:	d503201f 	nop

0000000000006800 <f37>:
    6800:	d101c3ff 	sub	sp, sp, #0x70
    6804:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6808:	f947f421 	ldr	x1, [x1, #4072]
    680c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6810:	910083fd 	add	x29, sp, #0x20
    6814:	a90563f7 	stp	x23, x24, [sp, #80]
    6818:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc90>
    681c:	911542e3 	add	x3, x23, #0x550
    6820:	a90353f3 	stp	x19, x20, [sp, #48]
    6824:	a9045bf5 	stp	x21, x22, [sp, #64]
    6828:	aa0003f6 	mov	x22, x0
    682c:	a9066bf9 	stp	x25, x26, [sp, #96]
    6830:	f949ec62 	ldr	x2, [x3, #5080]
    6834:	f9400024 	ldr	x4, [x1]
    6838:	f9000fe4 	str	x4, [sp, #24]
    683c:	d2800004 	mov	x4, #0x0                   	// #0
    6840:	f949d861 	ldr	x1, [x3, #5040]
    6844:	d370bc42 	lsl	x2, x2, #16
    6848:	b40015c0 	cbz	x0, 6b00 <f37+0x300>
    684c:	f9400818 	ldr	x24, [x0, #16]
    6850:	cb010301 	sub	x1, x24, x1
    6854:	eb02003f 	cmp	x1, x2
    6858:	54000362 	b.cs	68c4 <f37+0xc4>  // b.hs, b.nlast
    685c:	f949fc60 	ldr	x0, [x3, #5112]
    6860:	d350fc22 	lsr	x2, x1, #16
    6864:	8b020842 	add	x2, x2, x2, lsl #2
    6868:	8b020c02 	add	x2, x0, x2, lsl #3
    686c:	f9401040 	ldr	x0, [x2, #32]
    6870:	b40002a0 	cbz	x0, 68c4 <f37+0xc4>
    6874:	39400043 	ldrb	w3, [x2]
    6878:	7100087f 	cmp	w3, #0x2
    687c:	540013c0 	b.eq	6af4 <f37+0x2f4>  // b.none
    6880:	7100047f 	cmp	w3, #0x1
    6884:	540001c1 	b.ne	68bc <f37+0xbc>  // b.any
    6888:	29430843 	ldp	w3, w2, [x2, #24]
    688c:	92403c21 	and	x1, x1, #0xffff
    6890:	9b037c21 	mul	x1, x1, x3
    6894:	d360fc21 	lsr	x1, x1, #32
    6898:	eb02003f 	cmp	x1, x2
    689c:	54000102 	b.cs	68bc <f37+0xbc>  // b.hs, b.nlast
    68a0:	8b010000 	add	x0, x0, x1
    68a4:	39400001 	ldrb	w1, [x0]
    68a8:	340000a1 	cbz	w1, 68bc <f37+0xbc>
    68ac:	7103f43f 	cmp	w1, #0xfd
    68b0:	540016a8 	b.hi	6b84 <f37+0x384>  // b.pmore
    68b4:	11000421 	add	w1, w1, #0x1
    68b8:	39000001 	strb	w1, [x0]
    68bc:	d2800000 	mov	x0, #0x0                   	// #0
    68c0:	b40000f6 	cbz	x22, 68dc <f37+0xdc>
    68c4:	aa1603e1 	mov	x1, x22
    68c8:	d2800000 	mov	x0, #0x0                   	// #0
    68cc:	d503201f 	nop
    68d0:	f9400821 	ldr	x1, [x1, #16]
    68d4:	91000400 	add	x0, x0, #0x1
    68d8:	b5ffffc1 	cbnz	x1, 68d0 <f37+0xd0>
    68dc:	b40011b8 	cbz	x24, 6b10 <f37+0x310>
    68e0:	aa1803e1 	mov	x1, x24
    68e4:	d2800002 	mov	x2, #0x0                   	// #0
    68e8:	f9400821 	ldr	x1, [x1, #16]
    68ec:	91000442 	add	x2, x2, #0x1
    68f0:	b5ffffc1 	cbnz	x1, 68e8 <f37+0xe8>
    68f4:	eb00005f 	cmp	x2, x0
    68f8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    68fc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6900:	eb01033f 	cmp	x25, x1
    6904:	54001468 	b.hi	6b90 <f37+0x390>  // b.pmore
    6908:	d37ffb33 	lsl	x19, x25, #1
    690c:	52800041 	mov	w1, #0x2                   	// #2
    6910:	91000660 	add	x0, x19, #0x1
    6914:	d37df000 	lsl	x0, x0, #3
    6918:	97fff8ea 	bl	4cc0 <fwp_heap_alloc>
    691c:	911542e1 	add	x1, x23, #0x550
    6920:	aa0003fa 	mov	x26, x0
    6924:	f9000013 	str	x19, [x0]
    6928:	aa0103e0 	mov	x0, x1
    692c:	f949d821 	ldr	x1, [x1, #5040]
    6930:	f949ec00 	ldr	x0, [x0, #5080]
    6934:	cb010341 	sub	x1, x26, x1
    6938:	eb00403f 	cmp	x1, x0, lsl #16
    693c:	54000342 	b.cs	69a4 <f37+0x1a4>  // b.hs, b.nlast
    6940:	911542e2 	add	x2, x23, #0x550
    6944:	d350fc20 	lsr	x0, x1, #16
    6948:	8b000800 	add	x0, x0, x0, lsl #2
    694c:	f949fc43 	ldr	x3, [x2, #5112]
    6950:	d37df002 	lsl	x2, x0, #3
    6954:	8b020060 	add	x0, x3, x2
    6958:	f9401013 	ldr	x19, [x0, #32]
    695c:	b4000253 	cbz	x19, 69a4 <f37+0x1a4>
    6960:	38626862 	ldrb	w2, [x3, x2]
    6964:	7100085f 	cmp	w2, #0x2
    6968:	54000c00 	b.eq	6ae8 <f37+0x2e8>  // b.none
    696c:	7100045f 	cmp	w2, #0x1
    6970:	540001a1 	b.ne	69a4 <f37+0x1a4>  // b.any
    6974:	29430002 	ldp	w2, w0, [x0, #24]
    6978:	92403c21 	and	x1, x1, #0xffff
    697c:	9b027c21 	mul	x1, x1, x2
    6980:	d360fc21 	lsr	x1, x1, #32
    6984:	eb00003f 	cmp	x1, x0
    6988:	540000e2 	b.cs	69a4 <f37+0x1a4>  // b.hs, b.nlast
    698c:	8b010273 	add	x19, x19, x1
    6990:	39400260 	ldrb	w0, [x19]
    6994:	7103fc1f 	cmp	w0, #0xff
    6998:	54000da0 	b.eq	6b4c <f37+0x34c>  // b.none
    699c:	52800020 	mov	w0, #0x1                   	// #1
    69a0:	39000260 	strb	w0, [x19]
    69a4:	b4000259 	cbz	x25, 69ec <f37+0x1ec>
    69a8:	8b191359 	add	x25, x26, x25, lsl #4
    69ac:	aa1a03f3 	mov	x19, x26
    69b0:	aa1603f5 	mov	x21, x22
    69b4:	aa1803f4 	mov	x20, x24
    69b8:	f9400683 	ldr	x3, [x20, #8]
    69bc:	f94006a2 	ldr	x2, [x21, #8]
    69c0:	f9400861 	ldr	x1, [x3, #16]
    69c4:	f9400840 	ldr	x0, [x2, #16]
    69c8:	fd400461 	ldr	d1, [x3, #8]
    69cc:	fd400440 	ldr	d0, [x2, #8]
    69d0:	97fff9fc 	bl	51c0 <w120>
    69d4:	f9000660 	str	x0, [x19, #8]
    69d8:	f8010e61 	str	x1, [x19, #16]!
    69dc:	f9400a94 	ldr	x20, [x20, #16]
    69e0:	f9400ab5 	ldr	x21, [x21, #16]
    69e4:	eb13033f 	cmp	x25, x19
    69e8:	54fffe81 	b.ne	69b8 <f37+0x1b8>  // b.any
    69ec:	aa1803e0 	mov	x0, x24
    69f0:	97fffd48 	bl	5f10 <fwp_drop4>
    69f4:	aa1603e0 	mov	x0, x22
    69f8:	97fffd46 	bl	5f10 <fwp_drop4>
    69fc:	911542f7 	add	x23, x23, #0x550
    6a00:	aa1a03e0 	mov	x0, x26
    6a04:	97fffa43 	bl	5310 <w176.constprop.0>
    6a08:	aa0103f3 	mov	x19, x1
    6a0c:	aa0003f4 	mov	x20, x0
    6a10:	aa1a03e0 	mov	x0, x26
    6a14:	97fffedb 	bl	6580 <fwp_drop10>
    6a18:	a900cff4 	stp	x20, x19, [sp, #8]
    6a1c:	910023e1 	add	x1, sp, #0x8
    6a20:	52800000 	mov	w0, #0x0                   	// #0
    6a24:	97fff8ec 	bl	4dd4 <fwp_data.part.0.constprop.0>
    6a28:	f949dae1 	ldr	x1, [x23, #5040]
    6a2c:	aa0003f3 	mov	x19, x0
    6a30:	f949eee0 	ldr	x0, [x23, #5080]
    6a34:	cb010261 	sub	x1, x19, x1
    6a38:	eb00403f 	cmp	x1, x0, lsl #16
    6a3c:	54000322 	b.cs	6aa0 <f37+0x2a0>  // b.hs, b.nlast
    6a40:	d350fc22 	lsr	x2, x1, #16
    6a44:	f949fee3 	ldr	x3, [x23, #5112]
    6a48:	8b020842 	add	x2, x2, x2, lsl #2
    6a4c:	d37df042 	lsl	x2, x2, #3
    6a50:	8b020060 	add	x0, x3, x2
    6a54:	f9401014 	ldr	x20, [x0, #32]
    6a58:	b4000254 	cbz	x20, 6aa0 <f37+0x2a0>
    6a5c:	38626862 	ldrb	w2, [x3, x2]
    6a60:	7100085f 	cmp	w2, #0x2
    6a64:	540003c0 	b.eq	6adc <f37+0x2dc>  // b.none
    6a68:	7100045f 	cmp	w2, #0x1
    6a6c:	540001a1 	b.ne	6aa0 <f37+0x2a0>  // b.any
    6a70:	29430002 	ldp	w2, w0, [x0, #24]
    6a74:	92403c21 	and	x1, x1, #0xffff
    6a78:	9b027c21 	mul	x1, x1, x2
    6a7c:	d360fc21 	lsr	x1, x1, #32
    6a80:	eb00003f 	cmp	x1, x0
    6a84:	540000e2 	b.cs	6aa0 <f37+0x2a0>  // b.hs, b.nlast
    6a88:	8b010294 	add	x20, x20, x1
    6a8c:	39400280 	ldrb	w0, [x20]
    6a90:	7103fc1f 	cmp	w0, #0xff
    6a94:	54000620 	b.eq	6b58 <f37+0x358>  // b.none
    6a98:	52800020 	mov	w0, #0x1                   	// #1
    6a9c:	39000280 	strb	w0, [x20]
    6aa0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6aa4:	f947f400 	ldr	x0, [x0, #4072]
    6aa8:	f9400fe2 	ldr	x2, [sp, #24]
    6aac:	f9400001 	ldr	x1, [x0]
    6ab0:	eb010042 	subs	x2, x2, x1
    6ab4:	d2800001 	mov	x1, #0x0                   	// #0
    6ab8:	540006a1 	b.ne	6b8c <f37+0x38c>  // b.any
    6abc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6ac0:	aa1303e0 	mov	x0, x19
    6ac4:	a94353f3 	ldp	x19, x20, [sp, #48]
    6ac8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6acc:	a94563f7 	ldp	x23, x24, [sp, #80]
    6ad0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6ad4:	9101c3ff 	add	sp, sp, #0x70
    6ad8:	d65f03c0 	ret
    6adc:	72003c3f 	tst	w1, #0xffff
    6ae0:	54fffe01 	b.ne	6aa0 <f37+0x2a0>  // b.any
    6ae4:	17ffffea 	b	6a8c <f37+0x28c>
    6ae8:	72003c3f 	tst	w1, #0xffff
    6aec:	54fff5c1 	b.ne	69a4 <f37+0x1a4>  // b.any
    6af0:	17ffffa8 	b	6990 <f37+0x190>
    6af4:	72003c3f 	tst	w1, #0xffff
    6af8:	54ffee21 	b.ne	68bc <f37+0xbc>  // b.any
    6afc:	17ffff6a 	b	68a4 <f37+0xa4>
    6b00:	cb0103e1 	neg	x1, x1
    6b04:	eb02003f 	cmp	x1, x2
    6b08:	540002e3 	b.cc	6b64 <f37+0x364>  // b.lo, b.ul, b.last
    6b0c:	d503201f 	nop
    6b10:	52800041 	mov	w1, #0x2                   	// #2
    6b14:	d2800100 	mov	x0, #0x8                   	// #8
    6b18:	97fff86a 	bl	4cc0 <fwp_heap_alloc>
    6b1c:	aa0003e1 	mov	x1, x0
    6b20:	911542e0 	add	x0, x23, #0x550
    6b24:	aa0103fa 	mov	x26, x1
    6b28:	d2800018 	mov	x24, #0x0                   	// #0
    6b2c:	f900003f 	str	xzr, [x1]
    6b30:	f949d801 	ldr	x1, [x0, #5040]
    6b34:	f949ec00 	ldr	x0, [x0, #5080]
    6b38:	cb010341 	sub	x1, x26, x1
    6b3c:	eb00403f 	cmp	x1, x0, lsl #16
    6b40:	54fff562 	b.cs	69ec <f37+0x1ec>  // b.hs, b.nlast
    6b44:	d2800019 	mov	x25, #0x0                   	// #0
    6b48:	17ffff7e 	b	6940 <f37+0x140>
    6b4c:	aa1303e0 	mov	x0, x19
    6b50:	97fff69c 	bl	45c0 <fwp_rc_forget_slot>
    6b54:	17ffff92 	b	699c <f37+0x19c>
    6b58:	aa1403e0 	mov	x0, x20
    6b5c:	97fff699 	bl	45c0 <fwp_rc_forget_slot>
    6b60:	17ffffce 	b	6a98 <f37+0x298>
    6b64:	f949fc62 	ldr	x2, [x3, #5112]
    6b68:	d350fc20 	lsr	x0, x1, #16
    6b6c:	8b000800 	add	x0, x0, x0, lsl #2
    6b70:	8b000c42 	add	x2, x2, x0, lsl #3
    6b74:	f9401040 	ldr	x0, [x2, #32]
    6b78:	b4fffcc0 	cbz	x0, 6b10 <f37+0x310>
    6b7c:	d2800018 	mov	x24, #0x0                   	// #0
    6b80:	17ffff3d 	b	6874 <f37+0x74>
    6b84:	97fff648 	bl	44a4 <fwp_rc_wide_dup>
    6b88:	17ffff4d 	b	68bc <f37+0xbc>
    6b8c:	97ffef3d 	bl	2880 <__stack_chk_fail@plt>
    6b90:	f0000000 	adrp	x0, 9000 <__modti3+0x330>
    6b94:	91116000 	add	x0, x0, #0x458
    6b98:	97fff27a 	bl	3580 <fwp_trap>
    6b9c:	d503201f 	nop

0000000000006ba0 <fwp_owned_entry37>:
    6ba0:	f9400000 	ldr	x0, [x0]
    6ba4:	17ffff17 	b	6800 <f37>
    6ba8:	d503201f 	nop
    6bac:	d503201f 	nop

0000000000006bb0 <e37>:
    6bb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6bb4:	910003fd 	mov	x29, sp
    6bb8:	f9000bf3 	str	x19, [sp, #16]
    6bbc:	f9400013 	ldr	x19, [x0]
    6bc0:	aa1303e0 	mov	x0, x19
    6bc4:	97fff9ff 	bl	53c0 <fwp_rc_share>
    6bc8:	aa1303e0 	mov	x0, x19
    6bcc:	97ffff0d 	bl	6800 <f37>
    6bd0:	aa0003f3 	mov	x19, x0
    6bd4:	97fff9fb 	bl	53c0 <fwp_rc_share>
    6bd8:	aa1303e0 	mov	x0, x19
    6bdc:	f9400bf3 	ldr	x19, [sp, #16]
    6be0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6be4:	d65f03c0 	ret
    6be8:	d503201f 	nop
    6bec:	d503201f 	nop

0000000000006bf0 <fwp_args37>:
    6bf0:	7100003f 	cmp	w1, #0x0
    6bf4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6bf8:	54000041 	b.ne	6c00 <fwp_args37+0x10>  // b.any
    6bfc:	d65f03c0 	ret
    6c00:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6c04:	91154042 	add	x2, x2, #0x550
    6c08:	f9400001 	ldr	x1, [x0]
    6c0c:	f949d843 	ldr	x3, [x2, #5040]
    6c10:	f949ec40 	ldr	x0, [x2, #5080]
    6c14:	cb030021 	sub	x1, x1, x3
    6c18:	eb00403f 	cmp	x1, x0, lsl #16
    6c1c:	54ffff02 	b.cs	6bfc <fwp_args37+0xc>  // b.hs, b.nlast
    6c20:	d350fc20 	lsr	x0, x1, #16
    6c24:	f949fc44 	ldr	x4, [x2, #5112]
    6c28:	8b000800 	add	x0, x0, x0, lsl #2
    6c2c:	d37df002 	lsl	x2, x0, #3
    6c30:	8b020083 	add	x3, x4, x2
    6c34:	f9401060 	ldr	x0, [x3, #32]
    6c38:	b4fffe20 	cbz	x0, 6bfc <fwp_args37+0xc>
    6c3c:	38626882 	ldrb	w2, [x4, x2]
    6c40:	7100085f 	cmp	w2, #0x2
    6c44:	54000220 	b.eq	6c88 <fwp_args37+0x98>  // b.none
    6c48:	7100045f 	cmp	w2, #0x1
    6c4c:	54fffd81 	b.ne	6bfc <fwp_args37+0xc>  // b.any
    6c50:	29430864 	ldp	w4, w2, [x3, #24]
    6c54:	92403c21 	and	x1, x1, #0xffff
    6c58:	9b047c21 	mul	x1, x1, x4
    6c5c:	d360fc21 	lsr	x1, x1, #32
    6c60:	eb02003f 	cmp	x1, x2
    6c64:	54fffcc2 	b.cs	6bfc <fwp_args37+0xc>  // b.hs, b.nlast
    6c68:	8b010000 	add	x0, x0, x1
    6c6c:	39400001 	ldrb	w1, [x0]
    6c70:	34fffc61 	cbz	w1, 6bfc <fwp_args37+0xc>
    6c74:	7103f43f 	cmp	w1, #0xfd
    6c78:	540000e8 	b.hi	6c94 <fwp_args37+0xa4>  // b.pmore
    6c7c:	11000421 	add	w1, w1, #0x1
    6c80:	39000001 	strb	w1, [x0]
    6c84:	d65f03c0 	ret
    6c88:	72003c3f 	tst	w1, #0xffff
    6c8c:	54ffff00 	b.eq	6c6c <fwp_args37+0x7c>  // b.none
    6c90:	d65f03c0 	ret
    6c94:	17fff604 	b	44a4 <fwp_rc_wide_dup>
    6c98:	d503201f 	nop
    6c9c:	d503201f 	nop

0000000000006ca0 <fwp_caps37>:
    6ca0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6ca4:	910003fd 	mov	x29, sp
    6ca8:	f9000bf3 	str	x19, [sp, #16]
    6cac:	aa0003f3 	mov	x19, x0
    6cb0:	b9400400 	ldr	w0, [x0, #4]
    6cb4:	340004a0 	cbz	w0, 6d48 <fwp_caps37+0xa8>
    6cb8:	f9400660 	ldr	x0, [x19, #8]
    6cbc:	350004e1 	cbnz	w1, 6d58 <fwp_caps37+0xb8>
    6cc0:	97fffc94 	bl	5f10 <fwp_drop4>
    6cc4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6cc8:	91154042 	add	x2, x2, #0x550
    6ccc:	f949d840 	ldr	x0, [x2, #5040]
    6cd0:	f949ec41 	ldr	x1, [x2, #5080]
    6cd4:	cb000260 	sub	x0, x19, x0
    6cd8:	eb01401f 	cmp	x0, x1, lsl #16
    6cdc:	54000382 	b.cs	6d4c <fwp_caps37+0xac>  // b.hs, b.nlast
    6ce0:	d350fc01 	lsr	x1, x0, #16
    6ce4:	f949fc44 	ldr	x4, [x2, #5112]
    6ce8:	8b010821 	add	x1, x1, x1, lsl #2
    6cec:	d37df021 	lsl	x1, x1, #3
    6cf0:	8b010083 	add	x3, x4, x1
    6cf4:	f9401062 	ldr	x2, [x3, #32]
    6cf8:	b40002a2 	cbz	x2, 6d4c <fwp_caps37+0xac>
    6cfc:	38616881 	ldrb	w1, [x4, x1]
    6d00:	7100083f 	cmp	w1, #0x2
    6d04:	540006c0 	b.eq	6ddc <fwp_caps37+0x13c>  // b.none
    6d08:	7100043f 	cmp	w1, #0x1
    6d0c:	54000201 	b.ne	6d4c <fwp_caps37+0xac>  // b.any
    6d10:	29430464 	ldp	w4, w1, [x3, #24]
    6d14:	92403c00 	and	x0, x0, #0xffff
    6d18:	9b047c00 	mul	x0, x0, x4
    6d1c:	d360fc00 	lsr	x0, x0, #32
    6d20:	eb01001f 	cmp	x0, x1
    6d24:	54000142 	b.cs	6d4c <fwp_caps37+0xac>  // b.hs, b.nlast
    6d28:	8b000042 	add	x2, x2, x0
    6d2c:	39400040 	ldrb	w0, [x2]
    6d30:	7100041f 	cmp	w0, #0x1
    6d34:	540000c1 	b.ne	6d4c <fwp_caps37+0xac>  // b.any
    6d38:	aa1303e0 	mov	x0, x19
    6d3c:	f9400bf3 	ldr	x19, [sp, #16]
    6d40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d44:	17fff6bf 	b	4840 <fwp_mem_free>
    6d48:	34fffbe1 	cbz	w1, 6cc4 <fwp_caps37+0x24>
    6d4c:	f9400bf3 	ldr	x19, [sp, #16]
    6d50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d54:	d65f03c0 	ret
    6d58:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6d5c:	91154042 	add	x2, x2, #0x550
    6d60:	f949d843 	ldr	x3, [x2, #5040]
    6d64:	f949ec41 	ldr	x1, [x2, #5080]
    6d68:	cb030000 	sub	x0, x0, x3
    6d6c:	eb01401f 	cmp	x0, x1, lsl #16
    6d70:	54fffee2 	b.cs	6d4c <fwp_caps37+0xac>  // b.hs, b.nlast
    6d74:	d350fc01 	lsr	x1, x0, #16
    6d78:	f949fc44 	ldr	x4, [x2, #5112]
    6d7c:	8b010821 	add	x1, x1, x1, lsl #2
    6d80:	d37df021 	lsl	x1, x1, #3
    6d84:	8b010083 	add	x3, x4, x1
    6d88:	f9401062 	ldr	x2, [x3, #32]
    6d8c:	b4fffe02 	cbz	x2, 6d4c <fwp_caps37+0xac>
    6d90:	38616881 	ldrb	w1, [x4, x1]
    6d94:	7100083f 	cmp	w1, #0x2
    6d98:	54000280 	b.eq	6de8 <fwp_caps37+0x148>  // b.none
    6d9c:	7100043f 	cmp	w1, #0x1
    6da0:	54fffd61 	b.ne	6d4c <fwp_caps37+0xac>  // b.any
    6da4:	92403c01 	and	x1, x0, #0xffff
    6da8:	29430064 	ldp	w4, w0, [x3, #24]
    6dac:	9b047c21 	mul	x1, x1, x4
    6db0:	d360fc21 	lsr	x1, x1, #32
    6db4:	eb00003f 	cmp	x1, x0
    6db8:	54fffca2 	b.cs	6d4c <fwp_caps37+0xac>  // b.hs, b.nlast
    6dbc:	8b010042 	add	x2, x2, x1
    6dc0:	39400040 	ldrb	w0, [x2]
    6dc4:	34fffc40 	cbz	w0, 6d4c <fwp_caps37+0xac>
    6dc8:	7103f41f 	cmp	w0, #0xfd
    6dcc:	54000148 	b.hi	6df4 <fwp_caps37+0x154>  // b.pmore
    6dd0:	11000400 	add	w0, w0, #0x1
    6dd4:	39000040 	strb	w0, [x2]
    6dd8:	17ffffdd 	b	6d4c <fwp_caps37+0xac>
    6ddc:	72003c1f 	tst	w0, #0xffff
    6de0:	54fffb61 	b.ne	6d4c <fwp_caps37+0xac>  // b.any
    6de4:	17ffffd2 	b	6d2c <fwp_caps37+0x8c>
    6de8:	72003c1f 	tst	w0, #0xffff
    6dec:	54fffb01 	b.ne	6d4c <fwp_caps37+0xac>  // b.any
    6df0:	17fffff4 	b	6dc0 <fwp_caps37+0x120>
    6df4:	f9400bf3 	ldr	x19, [sp, #16]
    6df8:	aa0203e0 	mov	x0, x2
    6dfc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e00:	17fff5a9 	b	44a4 <fwp_rc_wide_dup>

0000000000006e04 <fwp_write>:
    6e04:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    6e08:	910003fd 	mov	x29, sp
    6e0c:	b00000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    6e10:	f947f484 	ldr	x4, [x4, #4072]
    6e14:	a90153f3 	stp	x19, x20, [sp, #16]
    6e18:	d10943ff 	sub	sp, sp, #0x250
    6e1c:	b9400045 	ldr	w5, [x2]
    6e20:	aa0003f4 	mov	x20, x0
    6e24:	f9400080 	ldr	x0, [x4]
    6e28:	f90127e0 	str	x0, [sp, #584]
    6e2c:	d2800000 	mov	x0, #0x0                   	// #0
    6e30:	710064bf 	cmp	w5, #0x19
    6e34:	54000408 	b.hi	6eb4 <fwp_write+0xb0>  // b.pmore
    6e38:	f0000000 	adrp	x0, 9000 <__modti3+0x330>
    6e3c:	aa0103f3 	mov	x19, x1
    6e40:	91300000 	add	x0, x0, #0xc00
    6e44:	f9013bf5 	str	x21, [sp, #624]
    6e48:	f9013ff6 	str	x22, [sp, #632]
    6e4c:	f90153fb 	str	x27, [sp, #672]
    6e50:	f90157fc 	str	x28, [sp, #680]
    6e54:	aa0203fc 	mov	x28, x2
    6e58:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    6e5c:	10000061 	adr	x1, 6e68 <fwp_write+0x64>
    6e60:	8b20a820 	add	x0, x1, w0, sxth #2
    6e64:	d61f0000 	br	x0
    6e68:	910123e0 	add	x0, sp, #0x48
    6e6c:	aa1303e5 	mov	x5, x19
    6e70:	f0000004 	adrp	x4, 9000 <__modti3+0x330>
    6e74:	aa0003f3 	mov	x19, x0
    6e78:	91128084 	add	x4, x4, #0x4a0
    6e7c:	d2804003 	mov	x3, #0x200                 	// #512
    6e80:	aa0303e1 	mov	x1, x3
    6e84:	52800042 	mov	w2, #0x2                   	// #2
    6e88:	97ffee5a 	bl	27f0 <__snprintf_chk@plt>
    6e8c:	aa1303e0 	mov	x0, x19
    6e90:	97ffee20 	bl	2710 <strlen@plt>
    6e94:	aa1303e1 	mov	x1, x19
    6e98:	aa0003e2 	mov	x2, x0
    6e9c:	aa1403e0 	mov	x0, x20
    6ea0:	97fff15c 	bl	3410 <buf_put>
    6ea4:	f9413bf5 	ldr	x21, [sp, #624]
    6ea8:	f9413ff6 	ldr	x22, [sp, #632]
    6eac:	f94153fb 	ldr	x27, [sp, #672]
    6eb0:	f94157fc 	ldr	x28, [sp, #680]
    6eb4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6eb8:	f947f400 	ldr	x0, [x0, #4072]
    6ebc:	f94127e2 	ldr	x2, [sp, #584]
    6ec0:	f9400001 	ldr	x1, [x0]
    6ec4:	eb010042 	subs	x2, x2, x1
    6ec8:	d2800001 	mov	x1, #0x0                   	// #0
    6ecc:	540077a1 	b.ne	7dc0 <fwp_write+0xfbc>  // b.any
    6ed0:	910943ff 	add	sp, sp, #0x250
    6ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ed8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6edc:	d65f03c0 	ret
    6ee0:	910123e0 	add	x0, sp, #0x48
    6ee4:	aa1303e5 	mov	x5, x19
    6ee8:	f0000004 	adrp	x4, 9000 <__modti3+0x330>
    6eec:	aa0003f3 	mov	x19, x0
    6ef0:	91126084 	add	x4, x4, #0x498
    6ef4:	d2804003 	mov	x3, #0x200                 	// #512
    6ef8:	17ffffe2 	b	6e80 <fwp_write+0x7c>
    6efc:	71004cbf 	cmp	w5, #0x13
    6f00:	f0000000 	adrp	x0, 9000 <__modti3+0x330>
    6f04:	f0000001 	adrp	x1, 9000 <__modti3+0x330>
    6f08:	91122000 	add	x0, x0, #0x488
    6f0c:	91124021 	add	x1, x1, #0x490
    6f10:	d2800082 	mov	x2, #0x4                   	// #4
    6f14:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    6f18:	aa1403e0 	mov	x0, x20
    6f1c:	f90143f7 	str	x23, [sp, #640]
    6f20:	d2800016 	mov	x22, #0x0                   	// #0
    6f24:	f90147f8 	str	x24, [sp, #648]
    6f28:	97fff13a 	bl	3410 <buf_put>
    6f2c:	f9400260 	ldr	x0, [x19]
    6f30:	f0000017 	adrp	x23, 9000 <__modti3+0x330>
    6f34:	d2800015 	mov	x21, #0x0                   	// #0
    6f38:	911442f7 	add	x23, x23, #0x510
    6f3c:	b4004780 	cbz	x0, 782c <fwp_write+0xa28>
    6f40:	b9400380 	ldr	w0, [x28]
    6f44:	52800003 	mov	w3, #0x0                   	// #0
    6f48:	f9401f82 	ldr	x2, [x28, #56]
    6f4c:	71004c1f 	cmp	w0, #0x13
    6f50:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    6f54:	aa1403e0 	mov	x0, x20
    6f58:	8b010e61 	add	x1, x19, x1, lsl #3
    6f5c:	f9400421 	ldr	x1, [x1, #8]
    6f60:	97ffffa9 	bl	6e04 <fwp_write>
    6f64:	b9400380 	ldr	w0, [x28]
    6f68:	7100481f 	cmp	w0, #0x12
    6f6c:	54004b20 	b.eq	78d0 <fwp_write+0xacc>  // b.none
    6f70:	f9400260 	ldr	x0, [x19]
    6f74:	910006b5 	add	x21, x21, #0x1
    6f78:	91000ad6 	add	x22, x22, #0x2
    6f7c:	eb15001f 	cmp	x0, x21
    6f80:	54004569 	b.ls	782c <fwp_write+0xa28>  // b.plast
    6f84:	aa1703e1 	mov	x1, x23
    6f88:	aa1403e0 	mov	x0, x20
    6f8c:	d2800042 	mov	x2, #0x2                   	// #2
    6f90:	97fff120 	bl	3410 <buf_put>
    6f94:	17ffffeb 	b	6f40 <fwp_write+0x13c>
    6f98:	f0000001 	adrp	x1, 9000 <__modti3+0x330>
    6f9c:	91132021 	add	x1, x1, #0x4c8
    6fa0:	d28000c2 	mov	x2, #0x6                   	// #6
    6fa4:	aa1403e0 	mov	x0, x20
    6fa8:	91004273 	add	x19, x19, #0x10
    6fac:	97fff119 	bl	3410 <buf_put>
    6fb0:	aa1303e0 	mov	x0, x19
    6fb4:	97ffedd7 	bl	2710 <strlen@plt>
    6fb8:	aa1303e1 	mov	x1, x19
    6fbc:	aa0003e2 	mov	x2, x0
    6fc0:	aa1403e0 	mov	x0, x20
    6fc4:	97fff113 	bl	3410 <buf_put>
    6fc8:	528007c3 	mov	w3, #0x3e                  	// #62
    6fcc:	aa1403e0 	mov	x0, x20
    6fd0:	91001fe1 	add	x1, sp, #0x7
    6fd4:	d2800022 	mov	x2, #0x1                   	// #1
    6fd8:	39001fe3 	strb	w3, [sp, #7]
    6fdc:	17ffffb1 	b	6ea0 <fwp_write+0x9c>
    6fe0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6fe4:	f947f400 	ldr	x0, [x0, #4072]
    6fe8:	f94127e2 	ldr	x2, [sp, #584]
    6fec:	f9400001 	ldr	x1, [x0]
    6ff0:	eb010042 	subs	x2, x2, x1
    6ff4:	d2800001 	mov	x1, #0x0                   	// #0
    6ff8:	540034c1 	b.ne	7690 <fwp_write+0x88c>  // b.any
    6ffc:	f9413bf5 	ldr	x21, [sp, #624]
    7000:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7004:	f9413ff6 	ldr	x22, [sp, #632]
    7008:	aa1403e0 	mov	x0, x20
    700c:	9112a021 	add	x1, x1, #0x4a8
    7010:	d2800142 	mov	x2, #0xa                   	// #10
    7014:	f94153fb 	ldr	x27, [sp, #672]
    7018:	f94157fc 	ldr	x28, [sp, #680]
    701c:	910943ff 	add	sp, sp, #0x250
    7020:	a94153f3 	ldp	x19, x20, [sp, #16]
    7024:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7028:	17fff0fa 	b	3410 <buf_put>
    702c:	f9400456 	ldr	x22, [x2, #8]
    7030:	f90143f7 	str	x23, [sp, #640]
    7034:	f90147f8 	str	x24, [sp, #648]
    7038:	b4005af6 	cbz	x22, 7b94 <fwp_write+0xd90>
    703c:	aa1603e0 	mov	x0, x22
    7040:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7044:	9114a021 	add	x1, x1, #0x528
    7048:	97ffee2e 	bl	2900 <strcmp@plt>
    704c:	2a0003f5 	mov	w21, w0
    7050:	34005fc0 	cbz	w0, 7c48 <fwp_write+0xe44>
    7054:	aa1603e0 	mov	x0, x22
    7058:	97ffedae 	bl	2710 <strlen@plt>
    705c:	aa1603e1 	mov	x1, x22
    7060:	aa0003e2 	mov	x2, x0
    7064:	aa1403e0 	mov	x0, x20
    7068:	97fff0ea 	bl	3410 <buf_put>
    706c:	52800403 	mov	w3, #0x20                  	// #32
    7070:	91001ff5 	add	x21, sp, #0x7
    7074:	aa1503e1 	mov	x1, x21
    7078:	aa1403e0 	mov	x0, x20
    707c:	d2800022 	mov	x2, #0x1                   	// #1
    7080:	39001fe3 	strb	w3, [sp, #7]
    7084:	97fff0e3 	bl	3410 <buf_put>
    7088:	52800f63 	mov	w3, #0x7b                  	// #123
    708c:	aa1403e0 	mov	x0, x20
    7090:	aa1503e1 	mov	x1, x21
    7094:	d2800022 	mov	x2, #0x1                   	// #1
    7098:	39001fe3 	strb	w3, [sp, #7]
    709c:	97fff0dd 	bl	3410 <buf_put>
    70a0:	b9401380 	ldr	w0, [x28, #16]
    70a4:	52800018 	mov	w24, #0x0                   	// #0
    70a8:	7100001f 	cmp	w0, #0x0
    70ac:	54003a8d 	b.le	77fc <fwp_write+0x9f8>
    70b0:	f9014bf9 	str	x25, [sp, #656]
    70b4:	d0000019 	adrp	x25, 9000 <__modti3+0x330>
    70b8:	91154339 	add	x25, x25, #0x550
    70bc:	f9014ffa 	str	x26, [sp, #664]
    70c0:	d000001a 	adrp	x26, 9000 <__modti3+0x330>
    70c4:	9114435a 	add	x26, x26, #0x510
    70c8:	91002276 	add	x22, x19, #0x8
    70cc:	d2800013 	mov	x19, #0x0                   	// #0
    70d0:	b5003e73 	cbnz	x19, 789c <fwp_write+0xa98>
    70d4:	d37df277 	lsl	x23, x19, #3
    70d8:	34003c98 	cbz	w24, 7868 <fwp_write+0xa64>
    70dc:	f9401382 	ldr	x2, [x28, #32]
    70e0:	aa1403e0 	mov	x0, x20
    70e4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    70e8:	52800003 	mov	w3, #0x0                   	// #0
    70ec:	f8776842 	ldr	x2, [x2, x23]
    70f0:	91000673 	add	x19, x19, #0x1
    70f4:	97ffff44 	bl	6e04 <fwp_write>
    70f8:	b9401380 	ldr	w0, [x28, #16]
    70fc:	6b13001f 	cmp	w0, w19
    7100:	54fffe8c 	b.gt	70d0 <fwp_write+0x2cc>
    7104:	f9414bf9 	ldr	x25, [sp, #656]
    7108:	f9414ffa 	ldr	x26, [sp, #664]
    710c:	34003798 	cbz	w24, 77fc <fwp_write+0x9f8>
    7110:	52800523 	mov	w3, #0x29                  	// #41
    7114:	aa1503e1 	mov	x1, x21
    7118:	aa1403e0 	mov	x0, x20
    711c:	d2800022 	mov	x2, #0x1                   	// #1
    7120:	39001fe3 	strb	w3, [sp, #7]
    7124:	97fff0bb 	bl	3410 <buf_put>
    7128:	f9413bf5 	ldr	x21, [sp, #624]
    712c:	f9413ff6 	ldr	x22, [sp, #632]
    7130:	f94143f7 	ldr	x23, [sp, #640]
    7134:	f94147f8 	ldr	x24, [sp, #648]
    7138:	f94153fb 	ldr	x27, [sp, #672]
    713c:	f94157fc 	ldr	x28, [sp, #680]
    7140:	17ffff5d 	b	6eb4 <fwp_write+0xb0>
    7144:	b9404855 	ldr	w21, [x2, #72]
    7148:	aa1403e0 	mov	x0, x20
    714c:	93407eb6 	sxtw	x22, w21
    7150:	91000ac1 	add	x1, x22, #0x2
    7154:	97fff07c 	bl	3344 <buf_grow>
    7158:	a9400281 	ldp	x1, x0, [x20]
    715c:	528e8603 	mov	w3, #0x7430                	// #29744
    7160:	78206823 	strh	w3, [x1, x0]
    7164:	8b000022 	add	x2, x1, x0
    7168:	710002bf 	cmp	w21, #0x0
    716c:	540036ad 	b.le	7840 <fwp_write+0xa3c>
    7170:	110006a3 	add	w3, w21, #0x1
    7174:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7178:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    717c:	91000449 	add	x9, x2, #0x1
    7180:	8b23c043 	add	x3, x2, w3, sxtw
    7184:	f28aaac6 	movk	x6, #0x5556
    7188:	f2955568 	movk	x8, #0xaaab
    718c:	1400000d 	b	71c0 <fwp_write+0x3bc>
    7190:	d2800021 	mov	x1, #0x1                   	// #1
    7194:	528005a5 	mov	w5, #0x2d                  	// #45
    7198:	f100001f 	cmp	x0, #0x0
    719c:	9b467e60 	smulh	x0, x19, x6
    71a0:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    71a4:	381ff465 	strb	w5, [x3], #-1
    71a8:	cb040000 	sub	x0, x0, x4
    71ac:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    71b0:	cb020000 	sub	x0, x0, x2
    71b4:	8b010013 	add	x19, x0, x1
    71b8:	eb03013f 	cmp	x9, x3
    71bc:	54003420 	b.eq	7840 <fwp_write+0xa3c>  // b.none
    71c0:	9b467e60 	smulh	x0, x19, x6
    71c4:	937ffe64 	asr	x4, x19, #63
    71c8:	52800605 	mov	w5, #0x30                  	// #48
    71cc:	cb040000 	sub	x0, x0, x4
    71d0:	8b000400 	add	x0, x0, x0, lsl #1
    71d4:	cb000260 	sub	x0, x19, x0
    71d8:	91000c01 	add	x1, x0, #0x3
    71dc:	9bc87c22 	umulh	x2, x1, x8
    71e0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    71e4:	8b4204e2 	add	x2, x7, x2, lsr #1
    71e8:	eb020021 	subs	x1, x1, x2
    71ec:	54fffd60 	b.eq	7198 <fwp_write+0x394>  // b.none
    71f0:	f100043f 	cmp	x1, #0x1
    71f4:	54fffce1 	b.ne	7190 <fwp_write+0x38c>  // b.any
    71f8:	d2800001 	mov	x1, #0x0                   	// #0
    71fc:	52800565 	mov	w5, #0x2b                  	// #43
    7200:	17ffffe6 	b	7198 <fwp_write+0x394>
    7204:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7208:	f947f400 	ldr	x0, [x0, #4072]
    720c:	f94127e2 	ldr	x2, [sp, #584]
    7210:	f9400001 	ldr	x1, [x0]
    7214:	eb010042 	subs	x2, x2, x1
    7218:	d2800001 	mov	x1, #0x0                   	// #0
    721c:	540023a1 	b.ne	7690 <fwp_write+0x88c>  // b.any
    7220:	f9413bf5 	ldr	x21, [sp, #624]
    7224:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7228:	f9413ff6 	ldr	x22, [sp, #632]
    722c:	aa1403e0 	mov	x0, x20
    7230:	9112e021 	add	x1, x1, #0x4b8
    7234:	d2800102 	mov	x2, #0x8                   	// #8
    7238:	17ffff77 	b	7014 <fwp_write+0x210>
    723c:	aa1403e0 	mov	x0, x20
    7240:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7244:	d28000c2 	mov	x2, #0x6                   	// #6
    7248:	91146021 	add	x1, x1, #0x518
    724c:	97fff071 	bl	3410 <buf_put>
    7250:	d2800015 	mov	x21, #0x0                   	// #0
    7254:	f9400263 	ldr	x3, [x19]
    7258:	f240f87f 	tst	x3, #0x7fffffffffffffff
    725c:	54002c40 	b.eq	77e4 <fwp_write+0x9e0>  // b.none
    7260:	f9401f82 	ldr	x2, [x28, #56]
    7264:	f90143f7 	str	x23, [sp, #640]
    7268:	f90147f8 	str	x24, [sp, #648]
    726c:	d2800857 	mov	x23, #0x42                  	// #66
    7270:	f9014bf9 	str	x25, [sp, #656]
    7274:	d0000016 	adrp	x22, 9000 <__modti3+0x330>
    7278:	f9014ffa 	str	x26, [sp, #664]
    727c:	911442d6 	add	x22, x22, #0x510
    7280:	d2800038 	mov	x24, #0x1                   	// #1
    7284:	f2a18017 	movk	x23, #0xc00, lsl #16
    7288:	d2809099 	mov	x25, #0x484                 	// #1156
    728c:	b4000482 	cbz	x2, 731c <fwp_write+0x518>
    7290:	b9400040 	ldr	w0, [x2]
    7294:	7100701f 	cmp	w0, #0x1c
    7298:	540042a0 	b.eq	7aec <fwp_write+0xce8>  // b.none
    729c:	71006c1f 	cmp	w0, #0x1b
    72a0:	540003e8 	b.hi	731c <fwp_write+0x518>  // b.pmore
    72a4:	9ac02301 	lsl	x1, x24, x0
    72a8:	ea17003f 	tst	x1, x23
    72ac:	54003681 	b.ne	797c <fwp_write+0xb78>  // b.any
    72b0:	ea19003f 	tst	x1, x25
    72b4:	54003501 	b.ne	7954 <fwp_write+0xb50>  // b.any
    72b8:	d2800424 	mov	x4, #0x21                  	// #33
    72bc:	ea04003f 	tst	x1, x4
    72c0:	540002e0 	b.eq	731c <fwp_write+0x518>  // b.none
    72c4:	b7f849a3 	tbnz	x3, #63, 7bf8 <fwp_write+0xdf4>
    72c8:	91002261 	add	x1, x19, #0x8
    72cc:	8b150021 	add	x1, x1, x21
    72d0:	39400021 	ldrb	w1, [x1]
    72d4:	7100001f 	cmp	w0, #0x0
    72d8:	93401c23 	sxtb	x3, w1
    72dc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    72e0:	aa1403e0 	mov	x0, x20
    72e4:	52800003 	mov	w3, #0x0                   	// #0
    72e8:	97fffec7 	bl	6e04 <fwp_write>
    72ec:	910006b5 	add	x21, x21, #0x1
    72f0:	f9400260 	ldr	x0, [x19]
    72f4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    72f8:	eb0002bf 	cmp	x21, x0
    72fc:	540026c2 	b.cs	77d4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7300:	d2800042 	mov	x2, #0x2                   	// #2
    7304:	aa1603e1 	mov	x1, x22
    7308:	aa1403e0 	mov	x0, x20
    730c:	97fff041 	bl	3410 <buf_put>
    7310:	f9401f82 	ldr	x2, [x28, #56]
    7314:	f9400263 	ldr	x3, [x19]
    7318:	b5fffbc2 	cbnz	x2, 7290 <fwp_write+0x48c>
    731c:	d37df2a0 	lsl	x0, x21, #3
    7320:	b7f83f03 	tbnz	x3, #63, 7b00 <fwp_write+0xcfc>
    7324:	91002261 	add	x1, x19, #0x8
    7328:	8b000020 	add	x0, x1, x0
    732c:	f9400001 	ldr	x1, [x0]
    7330:	17ffffec 	b	72e0 <fwp_write+0x4dc>
    7334:	a9400e62 	ldp	x2, x3, [x19]
    7338:	b7f83ca3 	tbnz	x3, #63, 7acc <fwp_write+0xcc8>
    733c:	910123f5 	add	x21, sp, #0x48
    7340:	aa1503e0 	mov	x0, x21
    7344:	97ffeeb7 	bl	2e20 <fwp_fmt_u128>
    7348:	aa1503e0 	mov	x0, x21
    734c:	97ffecf1 	bl	2710 <strlen@plt>
    7350:	aa1503e1 	mov	x1, x21
    7354:	aa0003e2 	mov	x2, x0
    7358:	17fffed1 	b	6e9c <fwp_write+0x98>
    735c:	fd015be8 	str	d8, [sp, #688]
    7360:	1e270268 	fmov	s8, w19
    7364:	fd015fe9 	str	d9, [sp, #696]
    7368:	1e282100 	fcmp	s8, s8
    736c:	54004d26 	b.vs	7d10 <fwp_write+0xf0c>
    7370:	1e20c101 	fabs	s1, s8
    7374:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7378:	1e270000 	fmov	s0, w0
    737c:	1e202020 	fcmp	s1, s0
    7380:	54002c0d 	b.le	7900 <fwp_write+0xafc>
    7384:	1e202118 	fcmpe	s8, #0.0
    7388:	d0000002 	adrp	x2, 9000 <__modti3+0x330>
    738c:	91024042 	add	x2, x2, #0x90
    7390:	910123f5 	add	x21, sp, #0x48
    7394:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7398:	9111a021 	add	x1, x1, #0x468
    739c:	aa1503e0 	mov	x0, x21
    73a0:	9a81c041 	csel	x1, x2, x1, gt
    73a4:	97ffed87 	bl	29c0 <strcpy@plt>
    73a8:	aa1503e0 	mov	x0, x21
    73ac:	97ffecd9 	bl	2710 <strlen@plt>
    73b0:	aa1503e1 	mov	x1, x21
    73b4:	aa0003e2 	mov	x2, x0
    73b8:	aa1403e0 	mov	x0, x20
    73bc:	97fff015 	bl	3410 <buf_put>
    73c0:	f9413bf5 	ldr	x21, [sp, #624]
    73c4:	f9413ff6 	ldr	x22, [sp, #632]
    73c8:	f94153fb 	ldr	x27, [sp, #672]
    73cc:	f94157fc 	ldr	x28, [sp, #680]
    73d0:	fd415be8 	ldr	d8, [sp, #688]
    73d4:	fd415fe9 	ldr	d9, [sp, #696]
    73d8:	17fffeb7 	b	6eb4 <fwp_write+0xb0>
    73dc:	f9400276 	ldr	x22, [x19]
    73e0:	34002e03 	cbz	w3, 79a0 <fwp_write+0xb9c>
    73e4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    73e8:	f947f400 	ldr	x0, [x0, #4072]
    73ec:	f94127e2 	ldr	x2, [sp, #584]
    73f0:	f9400001 	ldr	x1, [x0]
    73f4:	eb010042 	subs	x2, x2, x1
    73f8:	d2800001 	mov	x1, #0x0                   	// #0
    73fc:	540014a1 	b.ne	7690 <fwp_write+0x88c>  // b.any
    7400:	aa1603e2 	mov	x2, x22
    7404:	91002261 	add	x1, x19, #0x8
    7408:	f9413bf5 	ldr	x21, [sp, #624]
    740c:	aa1403e0 	mov	x0, x20
    7410:	f9413ff6 	ldr	x22, [sp, #632]
    7414:	17ffff00 	b	7014 <fwp_write+0x210>
    7418:	fd015be8 	str	d8, [sp, #688]
    741c:	9e670268 	fmov	d8, x19
    7420:	fd015fe9 	str	d9, [sp, #696]
    7424:	1e682100 	fcmp	d8, d8
    7428:	54004746 	b.vs	7d10 <fwp_write+0xf0c>
    742c:	1e60c101 	fabs	d1, d8
    7430:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7434:	9e670000 	fmov	d0, x0
    7438:	910123f5 	add	x21, sp, #0x48
    743c:	52800033 	mov	w19, #0x1                   	// #1
    7440:	1e602020 	fcmp	d1, d0
    7444:	540001ad 	b.le	7478 <fwp_write+0x674>
    7448:	1e602118 	fcmpe	d8, #0.0
    744c:	d0000002 	adrp	x2, 9000 <__modti3+0x330>
    7450:	91024042 	add	x2, x2, #0x90
    7454:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7458:	9111a021 	add	x1, x1, #0x468
    745c:	aa1503e0 	mov	x0, x21
    7460:	9a81c041 	csel	x1, x2, x1, gt
    7464:	97ffed57 	bl	29c0 <strcpy@plt>
    7468:	17ffffd0 	b	73a8 <fwp_write+0x5a4>
    746c:	11000673 	add	w19, w19, #0x1
    7470:	71004a7f 	cmp	w19, #0x12
    7474:	54003860 	b.eq	7b80 <fwp_write+0xd7c>  // b.none
    7478:	1e604100 	fmov	d0, d8
    747c:	2a1303e1 	mov	w1, w19
    7480:	aa1503e0 	mov	x0, x21
    7484:	97fff124 	bl	3914 <fwp_format_g.constprop.0>
    7488:	aa1503e0 	mov	x0, x21
    748c:	d2800001 	mov	x1, #0x0                   	// #0
    7490:	97ffecb4 	bl	2760 <strtod@plt>
    7494:	1e602100 	fcmp	d8, d0
    7498:	54fffea1 	b.ne	746c <fwp_write+0x668>  // b.any
    749c:	aa1503e0 	mov	x0, x21
    74a0:	97fff015 	bl	34f4 <fwp_finish_float>
    74a4:	17ffffc1 	b	73a8 <fwp_write+0x5a4>
    74a8:	a9400e62 	ldp	x2, x3, [x19]
    74ac:	910123f3 	add	x19, sp, #0x48
    74b0:	aa1303e0 	mov	x0, x19
    74b4:	97ffee5b 	bl	2e20 <fwp_fmt_u128>
    74b8:	17fffe75 	b	6e8c <fwp_write+0x88>
    74bc:	f90143f7 	str	x23, [sp, #640]
    74c0:	f90147f8 	str	x24, [sp, #648]
    74c4:	2a1303f8 	mov	w24, w19
    74c8:	f9014bf9 	str	x25, [sp, #656]
    74cc:	f9014ffa 	str	x26, [sp, #664]
    74d0:	f13ffe7f 	cmp	x19, #0xfff
    74d4:	54000049 	b.ls	74dc <fwp_write+0x6d8>  // b.plast
    74d8:	b9400278 	ldr	w24, [x19]
    74dc:	f9400f80 	ldr	x0, [x28, #24]
    74e0:	2a1803f5 	mov	w21, w24
    74e4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    74e8:	d37ef6b9 	lsl	x25, x21, #2
    74ec:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    74f0:	aa1603e0 	mov	x0, x22
    74f4:	97ffec87 	bl	2710 <strlen@plt>
    74f8:	aa1603e1 	mov	x1, x22
    74fc:	aa0003e2 	mov	x2, x0
    7500:	aa1403e0 	mov	x0, x20
    7504:	97ffefc3 	bl	3410 <buf_put>
    7508:	f9401780 	ldr	x0, [x28, #40]
    750c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7510:	7100001f 	cmp	w0, #0x0
    7514:	5400068d 	b.le	75e4 <fwp_write+0x7e0>
    7518:	91002276 	add	x22, x19, #0x8
    751c:	91001ff5 	add	x21, sp, #0x7
    7520:	d280001b 	mov	x27, #0x0                   	// #0
    7524:	5280041a 	mov	w26, #0x20                  	// #32
    7528:	f9401b80 	ldr	x0, [x28, #48]
    752c:	aa1503e1 	mov	x1, x21
    7530:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7534:	d2800022 	mov	x2, #0x1                   	// #1
    7538:	f8786803 	ldr	x3, [x0, x24]
    753c:	aa1403e0 	mov	x0, x20
    7540:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7544:	39001ffa 	strb	w26, [sp, #7]
    7548:	97ffefb2 	bl	3410 <buf_put>
    754c:	f13ffeff 	cmp	x23, #0xfff
    7550:	b9400261 	ldr	w1, [x19]
    7554:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7558:	7100383f 	cmp	w1, #0xe
    755c:	54000160 	b.eq	7588 <fwp_write+0x784>  // b.none
    7560:	7100403f 	cmp	w1, #0x10
    7564:	54001a60 	b.eq	78b0 <fwp_write+0xaac>  // b.none
    7568:	7100283f 	cmp	w1, #0xa
    756c:	54002aa0 	b.eq	7ac0 <fwp_write+0xcbc>  // b.none
    7570:	540014ac 	b.gt	7804 <fwp_write+0xa00>
    7574:	71000c3f 	cmp	w1, #0x3
    7578:	540029ac 	b.gt	7aac <fwp_write+0xca8>
    757c:	d37ffee0 	lsr	x0, x23, #63
    7580:	37f814a1 	tbnz	w1, #31, 7814 <fwp_write+0xa10>
    7584:	d503201f 	nop
    7588:	34001460 	cbz	w0, 7814 <fwp_write+0xa10>
    758c:	52800503 	mov	w3, #0x28                  	// #40
    7590:	aa1503e1 	mov	x1, x21
    7594:	aa1403e0 	mov	x0, x20
    7598:	d2800022 	mov	x2, #0x1                   	// #1
    759c:	39001fe3 	strb	w3, [sp, #7]
    75a0:	97ffef9c 	bl	3410 <buf_put>
    75a4:	aa1303e2 	mov	x2, x19
    75a8:	aa1703e1 	mov	x1, x23
    75ac:	aa1403e0 	mov	x0, x20
    75b0:	52800003 	mov	w3, #0x0                   	// #0
    75b4:	97fffe14 	bl	6e04 <fwp_write>
    75b8:	52800523 	mov	w3, #0x29                  	// #41
    75bc:	aa1503e1 	mov	x1, x21
    75c0:	aa1403e0 	mov	x0, x20
    75c4:	d2800022 	mov	x2, #0x1                   	// #1
    75c8:	39001fe3 	strb	w3, [sp, #7]
    75cc:	97ffef91 	bl	3410 <buf_put>
    75d0:	f9401780 	ldr	x0, [x28, #40]
    75d4:	9100077b 	add	x27, x27, #0x1
    75d8:	b8796800 	ldr	w0, [x0, x25]
    75dc:	6b1b001f 	cmp	w0, w27
    75e0:	54fffa4c 	b.gt	7528 <fwp_write+0x724>
    75e4:	f9413bf5 	ldr	x21, [sp, #624]
    75e8:	f9413ff6 	ldr	x22, [sp, #632]
    75ec:	f94143f7 	ldr	x23, [sp, #640]
    75f0:	f94147f8 	ldr	x24, [sp, #648]
    75f4:	f9414bf9 	ldr	x25, [sp, #656]
    75f8:	f9414ffa 	ldr	x26, [sp, #664]
    75fc:	f94153fb 	ldr	x27, [sp, #672]
    7600:	f94157fc 	ldr	x28, [sp, #680]
    7604:	17fffe2c 	b	6eb4 <fwp_write+0xb0>
    7608:	52800783 	mov	w3, #0x3c                  	// #60
    760c:	91001ff3 	add	x19, sp, #0x7
    7610:	aa1303e1 	mov	x1, x19
    7614:	d2800022 	mov	x2, #0x1                   	// #1
    7618:	aa1403e0 	mov	x0, x20
    761c:	39001fe3 	strb	w3, [sp, #7]
    7620:	97ffef7c 	bl	3410 <buf_put>
    7624:	f9400795 	ldr	x21, [x28, #8]
    7628:	aa1503e0 	mov	x0, x21
    762c:	97ffec39 	bl	2710 <strlen@plt>
    7630:	aa1503e1 	mov	x1, x21
    7634:	aa0003e2 	mov	x2, x0
    7638:	aa1403e0 	mov	x0, x20
    763c:	97ffef75 	bl	3410 <buf_put>
    7640:	528007c3 	mov	w3, #0x3e                  	// #62
    7644:	aa1303e1 	mov	x1, x19
    7648:	aa1403e0 	mov	x0, x20
    764c:	d2800022 	mov	x2, #0x1                   	// #1
    7650:	39001fe3 	strb	w3, [sp, #7]
    7654:	17fffe13 	b	6ea0 <fwp_write+0x9c>
    7658:	f100067f 	cmp	x19, #0x1
    765c:	540025a0 	b.eq	7b10 <fwp_write+0xd0c>  // b.none
    7660:	b100067f 	cmn	x19, #0x1
    7664:	54002bc0 	b.eq	7bdc <fwp_write+0xdd8>  // b.none
    7668:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    766c:	9111c021 	add	x1, x1, #0x470
    7670:	d2800022 	mov	x2, #0x1                   	// #1
    7674:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7678:	f947f400 	ldr	x0, [x0, #4072]
    767c:	f94127e4 	ldr	x4, [sp, #584]
    7680:	f9400003 	ldr	x3, [x0]
    7684:	eb030084 	subs	x4, x4, x3
    7688:	d2800003 	mov	x3, #0x0                   	// #0
    768c:	54ffebe0 	b.eq	7408 <fwp_write+0x604>  // b.none
    7690:	f90143f7 	str	x23, [sp, #640]
    7694:	f90147f8 	str	x24, [sp, #648]
    7698:	f9014bf9 	str	x25, [sp, #656]
    769c:	f9014ffa 	str	x26, [sp, #664]
    76a0:	fd015be8 	str	d8, [sp, #688]
    76a4:	fd015fe9 	str	d9, [sp, #696]
    76a8:	97ffec76 	bl	2880 <__stack_chk_fail@plt>
    76ac:	52800b63 	mov	w3, #0x5b                  	// #91
    76b0:	91001ff5 	add	x21, sp, #0x7
    76b4:	aa1503e1 	mov	x1, x21
    76b8:	aa1403e0 	mov	x0, x20
    76bc:	d2800022 	mov	x2, #0x1                   	// #1
    76c0:	d0000016 	adrp	x22, 9000 <__modti3+0x330>
    76c4:	911442d6 	add	x22, x22, #0x510
    76c8:	39001fe3 	strb	w3, [sp, #7]
    76cc:	97ffef51 	bl	3410 <buf_put>
    76d0:	b4000273 	cbz	x19, 771c <fwp_write+0x918>
    76d4:	f9400661 	ldr	x1, [x19, #8]
    76d8:	aa1403e0 	mov	x0, x20
    76dc:	f9401f82 	ldr	x2, [x28, #56]
    76e0:	52800003 	mov	w3, #0x0                   	// #0
    76e4:	97fffdc8 	bl	6e04 <fwp_write>
    76e8:	f9400a73 	ldr	x19, [x19, #16]
    76ec:	b4000193 	cbz	x19, 771c <fwp_write+0x918>
    76f0:	aa1603e1 	mov	x1, x22
    76f4:	aa1403e0 	mov	x0, x20
    76f8:	d2800042 	mov	x2, #0x2                   	// #2
    76fc:	97ffef45 	bl	3410 <buf_put>
    7700:	f9400661 	ldr	x1, [x19, #8]
    7704:	aa1403e0 	mov	x0, x20
    7708:	f9401f82 	ldr	x2, [x28, #56]
    770c:	52800003 	mov	w3, #0x0                   	// #0
    7710:	97fffdbd 	bl	6e04 <fwp_write>
    7714:	f9400a73 	ldr	x19, [x19, #16]
    7718:	b5fffed3 	cbnz	x19, 76f0 <fwp_write+0x8ec>
    771c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7720:	aa1503e1 	mov	x1, x21
    7724:	aa1403e0 	mov	x0, x20
    7728:	d2800022 	mov	x2, #0x1                   	// #1
    772c:	39001fe3 	strb	w3, [sp, #7]
    7730:	17fffddc 	b	6ea0 <fwp_write+0x9c>
    7734:	aa1403e0 	mov	x0, x20
    7738:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    773c:	d28000c2 	mov	x2, #0x6                   	// #6
    7740:	91140021 	add	x1, x1, #0x500
    7744:	97ffef33 	bl	3410 <buf_put>
    7748:	f9400260 	ldr	x0, [x19]
    774c:	b40004c0 	cbz	x0, 77e4 <fwp_write+0x9e0>
    7750:	910123f5 	add	x21, sp, #0x48
    7754:	91002276 	add	x22, x19, #0x8
    7758:	f90143f7 	str	x23, [sp, #640]
    775c:	d2800017 	mov	x23, #0x0                   	// #0
    7760:	f90147f8 	str	x24, [sp, #648]
    7764:	d0000018 	adrp	x24, 9000 <__modti3+0x330>
    7768:	91142318 	add	x24, x24, #0x508
    776c:	f9014bf9 	str	x25, [sp, #656]
    7770:	d0000019 	adrp	x25, 9000 <__modti3+0x330>
    7774:	91144339 	add	x25, x25, #0x510
    7778:	f9014ffa 	str	x26, [sp, #664]
    777c:	14000005 	b	7790 <fwp_write+0x98c>
    7780:	aa1903e1 	mov	x1, x25
    7784:	aa1403e0 	mov	x0, x20
    7788:	d2800042 	mov	x2, #0x2                   	// #2
    778c:	97ffef21 	bl	3410 <buf_put>
    7790:	38776ac5 	ldrb	w5, [x22, x23]
    7794:	d2804003 	mov	x3, #0x200                 	// #512
    7798:	aa1803e4 	mov	x4, x24
    779c:	aa0303e1 	mov	x1, x3
    77a0:	52800042 	mov	w2, #0x2                   	// #2
    77a4:	aa1503e0 	mov	x0, x21
    77a8:	910006f7 	add	x23, x23, #0x1
    77ac:	97ffec11 	bl	27f0 <__snprintf_chk@plt>
    77b0:	aa1503e0 	mov	x0, x21
    77b4:	97ffebd7 	bl	2710 <strlen@plt>
    77b8:	aa1503e1 	mov	x1, x21
    77bc:	aa0003e2 	mov	x2, x0
    77c0:	aa1403e0 	mov	x0, x20
    77c4:	97ffef13 	bl	3410 <buf_put>
    77c8:	f9400260 	ldr	x0, [x19]
    77cc:	eb17001f 	cmp	x0, x23
    77d0:	54fffd88 	b.hi	7780 <fwp_write+0x97c>  // b.pmore
    77d4:	f94143f7 	ldr	x23, [sp, #640]
    77d8:	f94147f8 	ldr	x24, [sp, #648]
    77dc:	f9414bf9 	ldr	x25, [sp, #656]
    77e0:	f9414ffa 	ldr	x26, [sp, #664]
    77e4:	52800ba3 	mov	w3, #0x5d                  	// #93
    77e8:	aa1403e0 	mov	x0, x20
    77ec:	91001fe1 	add	x1, sp, #0x7
    77f0:	d2800022 	mov	x2, #0x1                   	// #1
    77f4:	39001fe3 	strb	w3, [sp, #7]
    77f8:	17fffdaa 	b	6ea0 <fwp_write+0x9c>
    77fc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7800:	17fffe45 	b	7114 <fwp_write+0x310>
    7804:	f10002ff 	cmp	x23, #0x0
    7808:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    780c:	71002c3f 	cmp	w1, #0xb
    7810:	54ffebc0 	b.eq	7588 <fwp_write+0x784>  // b.none
    7814:	aa1303e2 	mov	x2, x19
    7818:	aa1703e1 	mov	x1, x23
    781c:	aa1403e0 	mov	x0, x20
    7820:	52800003 	mov	w3, #0x0                   	// #0
    7824:	97fffd78 	bl	6e04 <fwp_write>
    7828:	17ffff6a 	b	75d0 <fwp_write+0x7cc>
    782c:	aa1403e0 	mov	x0, x20
    7830:	91001fe1 	add	x1, sp, #0x7
    7834:	52800fa3 	mov	w3, #0x7d                  	// #125
    7838:	d2800022 	mov	x2, #0x1                   	// #1
    783c:	17fffe39 	b	7120 <fwp_write+0x31c>
    7840:	a9400281 	ldp	x1, x0, [x20]
    7844:	91000800 	add	x0, x0, #0x2
    7848:	8b160000 	add	x0, x0, x22
    784c:	f9000680 	str	x0, [x20, #8]
    7850:	3820683f 	strb	wzr, [x1, x0]
    7854:	f9413bf5 	ldr	x21, [sp, #624]
    7858:	f9413ff6 	ldr	x22, [sp, #632]
    785c:	f94153fb 	ldr	x27, [sp, #672]
    7860:	f94157fc 	ldr	x28, [sp, #680]
    7864:	17fffd94 	b	6eb4 <fwp_write+0xb0>
    7868:	f9400f80 	ldr	x0, [x28, #24]
    786c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7870:	aa1b03e0 	mov	x0, x27
    7874:	97ffeba7 	bl	2710 <strlen@plt>
    7878:	aa1b03e1 	mov	x1, x27
    787c:	aa0003e2 	mov	x2, x0
    7880:	aa1403e0 	mov	x0, x20
    7884:	97ffeee3 	bl	3410 <buf_put>
    7888:	aa1903e1 	mov	x1, x25
    788c:	aa1403e0 	mov	x0, x20
    7890:	d2800062 	mov	x2, #0x3                   	// #3
    7894:	97ffeedf 	bl	3410 <buf_put>
    7898:	17fffe11 	b	70dc <fwp_write+0x2d8>
    789c:	aa1a03e1 	mov	x1, x26
    78a0:	aa1403e0 	mov	x0, x20
    78a4:	d2800042 	mov	x2, #0x2                   	// #2
    78a8:	97ffeeda 	bl	3410 <buf_put>
    78ac:	17fffe0a 	b	70d4 <fwp_write+0x2d0>
    78b0:	f9400660 	ldr	x0, [x19, #8]
    78b4:	b4fffb00 	cbz	x0, 7814 <fwp_write+0xa10>
    78b8:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    78bc:	9114a021 	add	x1, x1, #0x528
    78c0:	97ffec10 	bl	2900 <strcmp@plt>
    78c4:	7100001f 	cmp	w0, #0x0
    78c8:	1a9f07e0 	cset	w0, ne	// ne = any
    78cc:	17ffff2f 	b	7588 <fwp_write+0x784>
    78d0:	aa1403e0 	mov	x0, x20
    78d4:	d2800042 	mov	x2, #0x2                   	// #2
    78d8:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    78dc:	91148021 	add	x1, x1, #0x520
    78e0:	97ffeecc 	bl	3410 <buf_put>
    78e4:	91004261 	add	x1, x19, #0x10
    78e8:	aa1403e0 	mov	x0, x20
    78ec:	f9402382 	ldr	x2, [x28, #64]
    78f0:	52800003 	mov	w3, #0x0                   	// #0
    78f4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    78f8:	97fffd43 	bl	6e04 <fwp_write>
    78fc:	17fffd9d 	b	6f70 <fwp_write+0x16c>
    7900:	1e22c109 	fcvt	d9, s8
    7904:	910123f5 	add	x21, sp, #0x48
    7908:	52800033 	mov	w19, #0x1                   	// #1
    790c:	d503201f 	nop
    7910:	1e604120 	fmov	d0, d9
    7914:	2a1303e1 	mov	w1, w19
    7918:	aa1503e0 	mov	x0, x21
    791c:	97ffeffe 	bl	3914 <fwp_format_g.constprop.0>
    7920:	aa1503e0 	mov	x0, x21
    7924:	d2800001 	mov	x1, #0x0                   	// #0
    7928:	97ffec02 	bl	2930 <strtof@plt>
    792c:	1e202100 	fcmp	s8, s0
    7930:	54ffdb60 	b.eq	749c <fwp_write+0x698>  // b.none
    7934:	11000673 	add	w19, w19, #0x1
    7938:	71002a7f 	cmp	w19, #0xa
    793c:	54fffea1 	b.ne	7910 <fwp_write+0xb0c>  // b.any
    7940:	1e604120 	fmov	d0, d9
    7944:	aa1503e0 	mov	x0, x21
    7948:	52800121 	mov	w1, #0x9                   	// #9
    794c:	97ffeff2 	bl	3914 <fwp_format_g.constprop.0>
    7950:	17fffed3 	b	749c <fwp_write+0x698>
    7954:	d37ef6a1 	lsl	x1, x21, #2
    7958:	b7f81563 	tbnz	x3, #63, 7c04 <fwp_write+0xe00>
    795c:	91002263 	add	x3, x19, #0x8
    7960:	8b010061 	add	x1, x3, x1
    7964:	b9400023 	ldr	w3, [x1]
    7968:	7100081f 	cmp	w0, #0x2
    796c:	2a0303e1 	mov	w1, w3
    7970:	93407c63 	sxtw	x3, w3
    7974:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7978:	17fffe5a 	b	72e0 <fwp_write+0x4dc>
    797c:	d37ffaa1 	lsl	x1, x21, #1
    7980:	b7f81363 	tbnz	x3, #63, 7bec <fwp_write+0xde8>
    7984:	91002263 	add	x3, x19, #0x8
    7988:	8b010061 	add	x1, x3, x1
    798c:	79400021 	ldrh	w1, [x1]
    7990:	7100041f 	cmp	w0, #0x1
    7994:	93403c23 	sxth	x3, w1
    7998:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    799c:	17fffe51 	b	72e0 <fwp_write+0x4dc>
    79a0:	52800443 	mov	w3, #0x22                  	// #34
    79a4:	91001ff5 	add	x21, sp, #0x7
    79a8:	91002273 	add	x19, x19, #0x8
    79ac:	aa1503e1 	mov	x1, x21
    79b0:	aa1403e0 	mov	x0, x20
    79b4:	d2800022 	mov	x2, #0x1                   	// #1
    79b8:	39001fe3 	strb	w3, [sp, #7]
    79bc:	f90143f7 	str	x23, [sp, #640]
    79c0:	8b160277 	add	x23, x19, x22
    79c4:	f90147f8 	str	x24, [sp, #648]
    79c8:	97ffee92 	bl	3410 <buf_put>
    79cc:	b4000696 	cbz	x22, 7a9c <fwp_write+0xc98>
    79d0:	d0000018 	adrp	x24, 9000 <__modti3+0x330>
    79d4:	91134318 	add	x24, x24, #0x4d0
    79d8:	f9014bf9 	str	x25, [sp, #656]
    79dc:	d0000019 	adrp	x25, 9000 <__modti3+0x330>
    79e0:	9113c339 	add	x25, x25, #0x4f0
    79e4:	f9014ffa 	str	x26, [sp, #664]
    79e8:	1400000d 	b	7a1c <fwp_write+0xc18>
    79ec:	710024bf 	cmp	w5, #0x9
    79f0:	54000460 	b.eq	7a7c <fwp_write+0xc78>  // b.none
    79f4:	710028bf 	cmp	w5, #0xa
    79f8:	54000a61 	b.ne	7b44 <fwp_write+0xd40>  // b.any
    79fc:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7a00:	aa1403e0 	mov	x0, x20
    7a04:	91138021 	add	x1, x1, #0x4e0
    7a08:	d2800042 	mov	x2, #0x2                   	// #2
    7a0c:	97ffee81 	bl	3410 <buf_put>
    7a10:	91000673 	add	x19, x19, #0x1
    7a14:	eb17027f 	cmp	x19, x23
    7a18:	540003e0 	b.eq	7a94 <fwp_write+0xc90>  // b.none
    7a1c:	39400265 	ldrb	w5, [x19]
    7a20:	710034bf 	cmp	w5, #0xd
    7a24:	54000180 	b.eq	7a54 <fwp_write+0xc50>  // b.none
    7a28:	54fffe29 	b.ls	79ec <fwp_write+0xbe8>  // b.plast
    7a2c:	710088bf 	cmp	w5, #0x22
    7a30:	540001c0 	b.eq	7a68 <fwp_write+0xc64>  // b.none
    7a34:	710170bf 	cmp	w5, #0x5c
    7a38:	54000741 	b.ne	7b20 <fwp_write+0xd1c>  // b.any
    7a3c:	aa1403e0 	mov	x0, x20
    7a40:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7a44:	d2800042 	mov	x2, #0x2                   	// #2
    7a48:	91136021 	add	x1, x1, #0x4d8
    7a4c:	97ffee71 	bl	3410 <buf_put>
    7a50:	17fffff0 	b	7a10 <fwp_write+0xc0c>
    7a54:	aa1903e1 	mov	x1, x25
    7a58:	aa1403e0 	mov	x0, x20
    7a5c:	d2800042 	mov	x2, #0x2                   	// #2
    7a60:	97ffee6c 	bl	3410 <buf_put>
    7a64:	17ffffeb 	b	7a10 <fwp_write+0xc0c>
    7a68:	aa1803e1 	mov	x1, x24
    7a6c:	aa1403e0 	mov	x0, x20
    7a70:	d2800042 	mov	x2, #0x2                   	// #2
    7a74:	97ffee67 	bl	3410 <buf_put>
    7a78:	17ffffe6 	b	7a10 <fwp_write+0xc0c>
    7a7c:	aa1403e0 	mov	x0, x20
    7a80:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7a84:	d2800042 	mov	x2, #0x2                   	// #2
    7a88:	9113a021 	add	x1, x1, #0x4e8
    7a8c:	97ffee61 	bl	3410 <buf_put>
    7a90:	17ffffe0 	b	7a10 <fwp_write+0xc0c>
    7a94:	f9414bf9 	ldr	x25, [sp, #656]
    7a98:	f9414ffa 	ldr	x26, [sp, #664]
    7a9c:	aa1503e1 	mov	x1, x21
    7aa0:	aa1403e0 	mov	x0, x20
    7aa4:	52800443 	mov	w3, #0x22                  	// #34
    7aa8:	17fffd9d 	b	711c <fwp_write+0x318>
    7aac:	7100103f 	cmp	w1, #0x4
    7ab0:	54ffeb21 	b.ne	7814 <fwp_write+0xa10>  // b.any
    7ab4:	f94006e0 	ldr	x0, [x23, #8]
    7ab8:	d37ffc00 	lsr	x0, x0, #63
    7abc:	17fffeb3 	b	7588 <fwp_write+0x784>
    7ac0:	710002ff 	cmp	w23, #0x0
    7ac4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7ac8:	17fffeb0 	b	7588 <fwp_write+0x784>
    7acc:	528005a1 	mov	w1, #0x2d                  	// #45
    7ad0:	eb0203e2 	negs	x2, x2
    7ad4:	da0303e3 	ngc	x3, x3
    7ad8:	910127e0 	add	x0, sp, #0x49
    7adc:	910123f5 	add	x21, sp, #0x48
    7ae0:	390123e1 	strb	w1, [sp, #72]
    7ae4:	97ffeccf 	bl	2e20 <fwp_fmt_u128>
    7ae8:	17fffe18 	b	7348 <fwp_write+0x544>
    7aec:	d37ceea1 	lsl	x1, x21, #4
    7af0:	b7f810a3 	tbnz	x3, #63, 7d04 <fwp_write+0xf00>
    7af4:	91002260 	add	x0, x19, #0x8
    7af8:	8b010001 	add	x1, x0, x1
    7afc:	17fffdf9 	b	72e0 <fwp_write+0x4dc>
    7b00:	f9400a61 	ldr	x1, [x19, #16]
    7b04:	8b010000 	add	x0, x0, x1
    7b08:	f9400001 	ldr	x1, [x0]
    7b0c:	17fffdf5 	b	72e0 <fwp_write+0x4dc>
    7b10:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7b14:	d2800042 	mov	x2, #0x2                   	// #2
    7b18:	9111e021 	add	x1, x1, #0x478
    7b1c:	17fffed6 	b	7674 <fwp_write+0x870>
    7b20:	7101fcbf 	cmp	w5, #0x7f
    7b24:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7b28:	540000e9 	b.ls	7b44 <fwp_write+0xd40>  // b.plast
    7b2c:	aa1503e1 	mov	x1, x21
    7b30:	aa1403e0 	mov	x0, x20
    7b34:	d2800022 	mov	x2, #0x1                   	// #1
    7b38:	39001fe5 	strb	w5, [sp, #7]
    7b3c:	97ffee35 	bl	3410 <buf_put>
    7b40:	17ffffb4 	b	7a10 <fwp_write+0xc0c>
    7b44:	d2800203 	mov	x3, #0x10                  	// #16
    7b48:	d0000004 	adrp	x4, 9000 <__modti3+0x330>
    7b4c:	aa0303e1 	mov	x1, x3
    7b50:	9113e084 	add	x4, x4, #0x4f8
    7b54:	910123f6 	add	x22, sp, #0x48
    7b58:	52800042 	mov	w2, #0x2                   	// #2
    7b5c:	aa1603e0 	mov	x0, x22
    7b60:	97ffeb24 	bl	27f0 <__snprintf_chk@plt>
    7b64:	aa1603e0 	mov	x0, x22
    7b68:	97ffeaea 	bl	2710 <strlen@plt>
    7b6c:	aa1603e1 	mov	x1, x22
    7b70:	aa0003e2 	mov	x2, x0
    7b74:	aa1403e0 	mov	x0, x20
    7b78:	97ffee26 	bl	3410 <buf_put>
    7b7c:	17ffffa5 	b	7a10 <fwp_write+0xc0c>
    7b80:	1e604100 	fmov	d0, d8
    7b84:	aa1503e0 	mov	x0, x21
    7b88:	52800221 	mov	w1, #0x11                  	// #17
    7b8c:	97ffef62 	bl	3914 <fwp_format_g.constprop.0>
    7b90:	17fffe43 	b	749c <fwp_write+0x698>
    7b94:	b9401040 	ldr	w0, [x2, #16]
    7b98:	350003c0 	cbnz	w0, 7c10 <fwp_write+0xe0c>
    7b9c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ba0:	f947f400 	ldr	x0, [x0, #4072]
    7ba4:	f94127e2 	ldr	x2, [sp, #584]
    7ba8:	f9400001 	ldr	x1, [x0]
    7bac:	eb010042 	subs	x2, x2, x1
    7bb0:	d2800001 	mov	x1, #0x0                   	// #0
    7bb4:	54ffd721 	b.ne	7698 <fwp_write+0x894>  // b.any
    7bb8:	f9413bf5 	ldr	x21, [sp, #624]
    7bbc:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7bc0:	f9413ff6 	ldr	x22, [sp, #632]
    7bc4:	aa1403e0 	mov	x0, x20
    7bc8:	f94143f7 	ldr	x23, [sp, #640]
    7bcc:	91152021 	add	x1, x1, #0x548
    7bd0:	f94147f8 	ldr	x24, [sp, #648]
    7bd4:	d2800042 	mov	x2, #0x2                   	// #2
    7bd8:	17fffd0f 	b	7014 <fwp_write+0x210>
    7bdc:	d0000001 	adrp	x1, 9000 <__modti3+0x330>
    7be0:	d2800042 	mov	x2, #0x2                   	// #2
    7be4:	91120021 	add	x1, x1, #0x480
    7be8:	17fffea3 	b	7674 <fwp_write+0x870>
    7bec:	f9400a63 	ldr	x3, [x19, #16]
    7bf0:	8b030021 	add	x1, x1, x3
    7bf4:	17ffff66 	b	798c <fwp_write+0xb88>
    7bf8:	f9400a61 	ldr	x1, [x19, #16]
    7bfc:	8b0102a1 	add	x1, x21, x1
    7c00:	17fffdb4 	b	72d0 <fwp_write+0x4cc>
    7c04:	f9400a63 	ldr	x3, [x19, #16]
    7c08:	8b030021 	add	x1, x1, x3
    7c0c:	17ffff56 	b	7964 <fwp_write+0xb60>
    7c10:	b9404840 	ldr	w0, [x2, #72]
    7c14:	91001ff5 	add	x21, sp, #0x7
    7c18:	34ffa380 	cbz	w0, 7088 <fwp_write+0x284>
    7c1c:	52800503 	mov	w3, #0x28                  	// #40
    7c20:	aa1403e0 	mov	x0, x20
    7c24:	aa1503e1 	mov	x1, x21
    7c28:	d2800022 	mov	x2, #0x1                   	// #1
    7c2c:	39001fe3 	strb	w3, [sp, #7]
    7c30:	97ffedf8 	bl	3410 <buf_put>
    7c34:	b9401380 	ldr	w0, [x28, #16]
    7c38:	52800038 	mov	w24, #0x1                   	// #1
    7c3c:	7100001f 	cmp	w0, #0x0
    7c40:	54ffa38c 	b.gt	70b0 <fwp_write+0x2ac>
    7c44:	17fffd33 	b	7110 <fwp_write+0x30c>
    7c48:	f9014bf9 	str	x25, [sp, #656]
    7c4c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x13110>
    7c50:	f9014ffa 	str	x26, [sp, #664]
    7c54:	f9400676 	ldr	x22, [x19, #8]
    7c58:	910aa333 	add	x19, x25, #0x2a8
    7c5c:	91002273 	add	x19, x19, #0x8
    7c60:	937ffed8 	asr	x24, x22, #63
    7c64:	aa1802c0 	orr	x0, x22, x24
    7c68:	b5000320 	cbnz	x0, 7ccc <fwp_write+0xec8>
    7c6c:	110006b5 	add	w21, w21, #0x1
    7c70:	710016bf 	cmp	w21, #0x5
    7c74:	54ffffc1 	b.ne	7c6c <fwp_write+0xe68>  // b.any
    7c78:	b7f80578 	tbnz	x24, #63, 7d24 <fwp_write+0xf20>
    7c7c:	910023f3 	add	x19, sp, #0x8
    7c80:	aa1603e2 	mov	x2, x22
    7c84:	aa1303e0 	mov	x0, x19
    7c88:	d2800003 	mov	x3, #0x0                   	// #0
    7c8c:	97ffec65 	bl	2e20 <fwp_fmt_u128>
    7c90:	910123f5 	add	x21, sp, #0x48
    7c94:	d0000003 	adrp	x3, 9000 <__modti3+0x330>
    7c98:	aa1303e4 	mov	x4, x19
    7c9c:	aa1503e0 	mov	x0, x21
    7ca0:	91150063 	add	x3, x3, #0x540
    7ca4:	d2804002 	mov	x2, #0x200                 	// #512
    7ca8:	52800041 	mov	w1, #0x2                   	// #2
    7cac:	97ffea9d 	bl	2720 <__sprintf_chk@plt>
    7cb0:	aa1503e0 	mov	x0, x21
    7cb4:	97ffea97 	bl	2710 <strlen@plt>
    7cb8:	aa1503e1 	mov	x1, x21
    7cbc:	aa0003e2 	mov	x2, x0
    7cc0:	aa1403e0 	mov	x0, x20
    7cc4:	97ffedd3 	bl	3410 <buf_put>
    7cc8:	17fffe47 	b	75e4 <fwp_write+0x7e0>
    7ccc:	f9400277 	ldr	x23, [x19]
    7cd0:	aa1603e0 	mov	x0, x22
    7cd4:	aa1803e1 	mov	x1, x24
    7cd8:	aa1703e2 	mov	x2, x23
    7cdc:	937ffefa 	asr	x26, x23, #63
    7ce0:	aa1a03e3 	mov	x3, x26
    7ce4:	940003fb 	bl	8cd0 <__modti3>
    7ce8:	aa010000 	orr	x0, x0, x1
    7cec:	b40002c0 	cbz	x0, 7d44 <fwp_write+0xf40>
    7cf0:	110006b5 	add	w21, w21, #0x1
    7cf4:	91004273 	add	x19, x19, #0x10
    7cf8:	710016bf 	cmp	w21, #0x5
    7cfc:	54fffe81 	b.ne	7ccc <fwp_write+0xec8>  // b.any
    7d00:	17ffffde 	b	7c78 <fwp_write+0xe74>
    7d04:	f9400a60 	ldr	x0, [x19, #16]
    7d08:	8b000021 	add	x1, x1, x0
    7d0c:	17fffd75 	b	72e0 <fwp_write+0x4dc>
    7d10:	528c29c0 	mov	w0, #0x614e                	// #24910
    7d14:	910123f5 	add	x21, sp, #0x48
    7d18:	72a009c0 	movk	w0, #0x4e, lsl #16
    7d1c:	b9004be0 	str	w0, [sp, #72]
    7d20:	17fffda2 	b	73a8 <fwp_write+0x5a4>
    7d24:	528005a1 	mov	w1, #0x2d                  	// #45
    7d28:	eb1603e2 	negs	x2, x22
    7d2c:	da1803e3 	ngc	x3, x24
    7d30:	910027e0 	add	x0, sp, #0x9
    7d34:	910023f3 	add	x19, sp, #0x8
    7d38:	390023e1 	strb	w1, [sp, #8]
    7d3c:	97ffec39 	bl	2e20 <fwp_fmt_u128>
    7d40:	17ffffd4 	b	7c90 <fwp_write+0xe8c>
    7d44:	aa1703e2 	mov	x2, x23
    7d48:	aa1a03e3 	mov	x3, x26
    7d4c:	aa1603e0 	mov	x0, x22
    7d50:	aa1803e1 	mov	x1, x24
    7d54:	940002ff 	bl	8950 <__divti3>
    7d58:	aa0003e2 	mov	x2, x0
    7d5c:	aa0103e3 	mov	x3, x1
    7d60:	b7f80201 	tbnz	x1, #63, 7da0 <fwp_write+0xf9c>
    7d64:	910023f3 	add	x19, sp, #0x8
    7d68:	aa1303e0 	mov	x0, x19
    7d6c:	97ffec2d 	bl	2e20 <fwp_fmt_u128>
    7d70:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7d74:	910aa339 	add	x25, x25, #0x2a8
    7d78:	910123f5 	add	x21, sp, #0x48
    7d7c:	aa1303e4 	mov	x4, x19
    7d80:	aa1503e0 	mov	x0, x21
    7d84:	d0000003 	adrp	x3, 9000 <__modti3+0x330>
    7d88:	f8616b25 	ldr	x5, [x25, x1]
    7d8c:	9114e063 	add	x3, x3, #0x538
    7d90:	d2804002 	mov	x2, #0x200                 	// #512
    7d94:	52800041 	mov	w1, #0x2                   	// #2
    7d98:	97ffea62 	bl	2720 <__sprintf_chk@plt>
    7d9c:	17ffffc5 	b	7cb0 <fwp_write+0xeac>
    7da0:	528005a4 	mov	w4, #0x2d                  	// #45
    7da4:	eb0003e2 	negs	x2, x0
    7da8:	da0103e3 	ngc	x3, x1
    7dac:	910027e0 	add	x0, sp, #0x9
    7db0:	910023f3 	add	x19, sp, #0x8
    7db4:	390023e4 	strb	w4, [sp, #8]
    7db8:	97ffec1a 	bl	2e20 <fwp_fmt_u128>
    7dbc:	17ffffed 	b	7d70 <fwp_write+0xf6c>
    7dc0:	f9013bf5 	str	x21, [sp, #624]
    7dc4:	f9013ff6 	str	x22, [sp, #632]
    7dc8:	f90143f7 	str	x23, [sp, #640]
    7dcc:	f90147f8 	str	x24, [sp, #648]
    7dd0:	f9014bf9 	str	x25, [sp, #656]
    7dd4:	f9014ffa 	str	x26, [sp, #664]
    7dd8:	f90153fb 	str	x27, [sp, #672]
    7ddc:	f90157fc 	str	x28, [sp, #680]
    7de0:	fd015be8 	str	d8, [sp, #688]
    7de4:	fd015fe9 	str	d9, [sp, #696]
    7de8:	97ffeaa6 	bl	2880 <__stack_chk_fail@plt>
    7dec:	d503201f 	nop

0000000000007df0 <fwp_main_thread>:
    7df0:	d10603ff 	sub	sp, sp, #0x180
    7df4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7df8:	f947f400 	ldr	x0, [x0, #4072]
    7dfc:	a9127bfd 	stp	x29, x30, [sp, #288]
    7e00:	910483fd 	add	x29, sp, #0x120
    7e04:	a91563f7 	stp	x23, x24, [sp, #336]
    7e08:	d0000157 	adrp	x23, 31000 <fwp_root_context+0xc90>
    7e0c:	911542e1 	add	x1, x23, #0x550
    7e10:	a9145bf5 	stp	x21, x22, [sp, #320]
    7e14:	a91773fb 	stp	x27, x28, [sp, #368]
    7e18:	b953a421 	ldr	w1, [x1, #5028]
    7e1c:	f9400002 	ldr	x2, [x0]
    7e20:	f9008fe2 	str	x2, [sp, #280]
    7e24:	d2800002 	mov	x2, #0x0                   	// #0
    7e28:	340023a1 	cbz	w1, 829c <fwp_main_thread+0x4ac>
    7e2c:	911542e0 	add	x0, x23, #0x550
    7e30:	b953a800 	ldr	w0, [x0, #5032]
    7e34:	350023c0 	cbnz	w0, 82ac <fwp_main_thread+0x4bc>
    7e38:	b00000d5 	adrp	x21, 20000 <__data_start>
    7e3c:	b00000c2 	adrp	x2, 20000 <__data_start>
    7e40:	9100c2bb 	add	x27, x21, #0x30
    7e44:	910dc042 	add	x2, x2, #0x370
    7e48:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    7e4c:	d2a00024 	mov	x4, #0x10000               	// #65536
    7e50:	910103e0 	add	x0, sp, #0x40
    7e54:	9100a3fc 	add	x28, sp, #0x28
    7e58:	d2800001 	mov	x1, #0x0                   	// #0
    7e5c:	f90003e0 	str	x0, [sp]
    7e60:	a9018f7c 	stp	x28, x3, [x27, #24]
    7e64:	f90023e2 	str	x2, [sp, #64]
    7e68:	b9004bff 	str	wzr, [sp, #72]
    7e6c:	f9002be4 	str	x4, [sp, #80]
    7e70:	97ffea1c 	bl	26e0 <sigaltstack@plt>
    7e74:	a91353f3 	stp	x19, x20, [sp, #304]
    7e78:	35005540 	cbnz	w0, 8920 <fwp_main_thread+0xb30>
    7e7c:	4f000400 	movi	v0.4s, #0x0
    7e80:	910223e0 	add	x0, sp, #0x88
    7e84:	90ffffe1 	adrp	x1, 3000 <fwp_flush+0x10>
    7e88:	9101c021 	add	x1, x1, #0x70
    7e8c:	f90043e1 	str	x1, [sp, #128]
    7e90:	52800082 	mov	w2, #0x4                   	// #4
    7e94:	72a10002 	movk	w2, #0x800, lsl #16
    7e98:	910203f4 	add	x20, sp, #0x80
    7e9c:	3d802000 	str	q0, [x0, #128]
    7ea0:	b9010be2 	str	w2, [sp, #264]
    7ea4:	ad000000 	stp	q0, q0, [x0]
    7ea8:	ad010000 	stp	q0, q0, [x0, #32]
    7eac:	ad020000 	stp	q0, q0, [x0, #64]
    7eb0:	ad030000 	stp	q0, q0, [x0, #96]
    7eb4:	97ffea63 	bl	2840 <sigemptyset@plt>
    7eb8:	35005340 	cbnz	w0, 8920 <fwp_main_thread+0xb30>
    7ebc:	aa1403e1 	mov	x1, x20
    7ec0:	d2800002 	mov	x2, #0x0                   	// #0
    7ec4:	52800160 	mov	w0, #0xb                   	// #11
    7ec8:	97ffea76 	bl	28a0 <sigaction@plt>
    7ecc:	350052a0 	cbnz	w0, 8920 <fwp_main_thread+0xb30>
    7ed0:	aa1403e1 	mov	x1, x20
    7ed4:	d2800002 	mov	x2, #0x0                   	// #0
    7ed8:	528000e0 	mov	w0, #0x7                   	// #7
    7edc:	97ffea71 	bl	28a0 <sigaction@plt>
    7ee0:	35005200 	cbnz	w0, 8920 <fwp_main_thread+0xb30>
    7ee4:	b9431760 	ldr	w0, [x27, #788]
    7ee8:	34001ea0 	cbz	w0, 82bc <fwp_main_thread+0x4cc>
    7eec:	9100c2b6 	add	x22, x21, #0x30
    7ef0:	f9400ad4 	ldr	x20, [x22, #16]
    7ef4:	b4000c94 	cbz	x20, 8084 <fwp_main_thread+0x294>
    7ef8:	aa1403f3 	mov	x19, x20
    7efc:	91010298 	add	x24, x20, #0x40
    7f00:	a9166bf9 	stp	x25, x26, [sp, #352]
    7f04:	52800037 	mov	w23, #0x1                   	// #1
    7f08:	39414a99 	ldrb	w25, [x20, #82]
    7f0c:	39014a97 	strb	w23, [x20, #82]
    7f10:	f9401680 	ldr	x0, [x20, #40]
    7f14:	b4000620 	cbz	x0, 7fd8 <fwp_main_thread+0x1e8>
    7f18:	f9403281 	ldr	x1, [x20, #96]
    7f1c:	39414680 	ldrb	w0, [x20, #81]
    7f20:	b4000cc1 	cbz	x1, 80b8 <fwp_main_thread+0x2c8>
    7f24:	36000b80 	tbz	w0, #0, 8094 <fwp_main_thread+0x2a4>
    7f28:	39414a62 	ldrb	w2, [x19, #82]
    7f2c:	f9402280 	ldr	x0, [x20, #64]
    7f30:	37000ee2 	tbnz	w2, #0, 810c <fwp_main_thread+0x31c>
    7f34:	f9403261 	ldr	x1, [x19, #96]
    7f38:	a911fe78 	stp	x24, xzr, [x19, #280]
    7f3c:	f9009660 	str	x0, [x19, #296]
    7f40:	b4000040 	cbz	x0, 7f48 <fwp_main_thread+0x158>
    7f44:	f9009013 	str	x19, [x0, #288]
    7f48:	f9002293 	str	x19, [x20, #64]
    7f4c:	b4000101 	cbz	x1, 7f6c <fwp_main_thread+0x17c>
    7f50:	f94056c0 	ldr	x0, [x22, #168]
    7f54:	39015677 	strb	w23, [x19, #85]
    7f58:	f9003661 	str	x1, [x19, #104]
    7f5c:	a910827f 	stp	xzr, x0, [x19, #264]
    7f60:	b4000040 	cbz	x0, 7f68 <fwp_main_thread+0x178>
    7f64:	f9008413 	str	x19, [x0, #264]
    7f68:	f90056d3 	str	x19, [x22, #168]
    7f6c:	39015a7f 	strb	wzr, [x19, #86]
    7f70:	97fff92d 	bl	6424 <fwp_block>
    7f74:	f9408e62 	ldr	x2, [x19, #280]
    7f78:	b4000142 	cbz	x2, 7fa0 <fwp_main_thread+0x1b0>
    7f7c:	a9520261 	ldp	x1, x0, [x19, #288]
    7f80:	b4000d21 	cbz	x1, 8124 <fwp_main_thread+0x334>
    7f84:	f9009420 	str	x0, [x1, #296]
    7f88:	f9409660 	ldr	x0, [x19, #296]
    7f8c:	b4000040 	cbz	x0, 7f94 <fwp_main_thread+0x1a4>
    7f90:	f9009001 	str	x1, [x0, #288]
    7f94:	91080260 	add	x0, x19, #0x200
    7f98:	f900967f 	str	xzr, [x19, #296]
    7f9c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    7fa0:	39415660 	ldrb	w0, [x19, #85]
    7fa4:	f9400ac2 	ldr	x2, [x22, #16]
    7fa8:	36000ae0 	tbz	w0, #0, 8104 <fwp_main_thread+0x314>
    7fac:	a9508261 	ldp	x1, x0, [x19, #264]
    7fb0:	b4000be1 	cbz	x1, 812c <fwp_main_thread+0x33c>
    7fb4:	f9008820 	str	x0, [x1, #272]
    7fb8:	b4000040 	cbz	x0, 7fc0 <fwp_main_thread+0x1d0>
    7fbc:	f9008401 	str	x1, [x0, #264]
    7fc0:	91080260 	add	x0, x19, #0x200
    7fc4:	3901567f 	strb	wzr, [x19, #85]
    7fc8:	aa0203f3 	mov	x19, x2
    7fcc:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    7fd0:	f9401680 	ldr	x0, [x20, #40]
    7fd4:	b5fffa20 	cbnz	x0, 7f18 <fwp_main_thread+0x128>
    7fd8:	9100c2a0 	add	x0, x21, #0x30
    7fdc:	39014a99 	strb	w25, [x20, #82]
    7fe0:	a9566bf9 	ldp	x25, x26, [sp, #352]
    7fe4:	f9417c00 	ldr	x0, [x0, #760]
    7fe8:	b5000080 	cbnz	x0, 7ff8 <fwp_main_thread+0x208>
    7fec:	9100c2b4 	add	x20, x21, #0x30
    7ff0:	f9418680 	ldr	x0, [x20, #776]
    7ff4:	b4004320 	cbz	x0, 8858 <fwp_main_thread+0xa68>
    7ff8:	9100c2a0 	add	x0, x21, #0x30
    7ffc:	f9419401 	ldr	x1, [x0, #808]
    8000:	b903201f 	str	wzr, [x0, #800]
    8004:	eb13003f 	cmp	x1, x19
    8008:	540043e1 	b.ne	8884 <fwp_main_thread+0xa94>  // b.any
    800c:	b40009f3 	cbz	x19, 8148 <fwp_main_thread+0x358>
    8010:	9100c2a0 	add	x0, x21, #0x30
    8014:	52800021 	mov	w1, #0x1                   	// #1
    8018:	39014a61 	strb	w1, [x19, #82]
    801c:	f9416805 	ldr	x5, [x0, #720]
    8020:	b4000945 	cbz	x5, 8148 <fwp_main_thread+0x358>
    8024:	d503201f 	nop
    8028:	394140a0 	ldrb	w0, [x5, #80]
    802c:	37000060 	tbnz	w0, #0, 8038 <fwp_main_thread+0x248>
    8030:	aa0503e0 	mov	x0, x5
    8034:	97ffed0f 	bl	3470 <fwp_cancel_tree.part.0>
    8038:	f9409ca5 	ldr	x5, [x5, #312]
    803c:	b5ffff65 	cbnz	x5, 8028 <fwp_main_thread+0x238>
    8040:	9100c2b4 	add	x20, x21, #0x30
    8044:	52800036 	mov	w22, #0x1                   	// #1
    8048:	f9402a60 	ldr	x0, [x19, #80]
    804c:	f2001c1f 	tst	x0, #0xff000000ff
    8050:	540000e1 	b.ne	806c <fwp_main_thread+0x27c>  // b.any
    8054:	f9401680 	ldr	x0, [x20, #40]
    8058:	39015276 	strb	w22, [x19, #84]
    805c:	f900827f 	str	xzr, [x19, #256]
    8060:	b40006a0 	cbz	x0, 8134 <fwp_main_thread+0x344>
    8064:	f9008013 	str	x19, [x0, #256]
    8068:	f9001693 	str	x19, [x20, #40]
    806c:	97fff8ee 	bl	6424 <fwp_block>
    8070:	97fff880 	bl	6270 <fwp_free_zombie>
    8074:	f9416a80 	ldr	x0, [x20, #720]
    8078:	b4000680 	cbz	x0, 8148 <fwp_main_thread+0x358>
    807c:	f9419693 	ldr	x19, [x20, #808]
    8080:	17fffff2 	b	8048 <fwp_main_thread+0x258>
    8084:	f9417ec0 	ldr	x0, [x22, #760]
    8088:	b50005a0 	cbnz	x0, 813c <fwp_main_thread+0x34c>
    808c:	d2800013 	mov	x19, #0x0                   	// #0
    8090:	17ffffd7 	b	7fec <fwp_main_thread+0x1fc>
    8094:	97ffed9b 	bl	3700 <fwp_now_ns>
    8098:	f9403281 	ldr	x1, [x20, #96]
    809c:	eb01001f 	cmp	x0, x1
    80a0:	540000ab 	b.lt	80b4 <fwp_main_thread+0x2c4>  // b.tstop
    80a4:	39414280 	ldrb	w0, [x20, #80]
    80a8:	37000060 	tbnz	w0, #0, 80b4 <fwp_main_thread+0x2c4>
    80ac:	aa1403e0 	mov	x0, x20
    80b0:	97ffecf0 	bl	3470 <fwp_cancel_tree.part.0>
    80b4:	39414680 	ldrb	w0, [x20, #81]
    80b8:	39414a62 	ldrb	w2, [x19, #82]
    80bc:	3707f380 	tbnz	w0, #0, 7f2c <fwp_main_thread+0x13c>
    80c0:	f9403281 	ldr	x1, [x20, #96]
    80c4:	370001c2 	tbnz	w2, #0, 80fc <fwp_main_thread+0x30c>
    80c8:	f9403260 	ldr	x0, [x19, #96]
    80cc:	b4000180 	cbz	x0, 80fc <fwp_main_thread+0x30c>
    80d0:	b4000061 	cbz	x1, 80dc <fwp_main_thread+0x2ec>
    80d4:	eb01001f 	cmp	x0, x1
    80d8:	9a81d000 	csel	x0, x0, x1, le
    80dc:	f9402281 	ldr	x1, [x20, #64]
    80e0:	a911fe78 	stp	x24, xzr, [x19, #280]
    80e4:	f9009661 	str	x1, [x19, #296]
    80e8:	b4003b21 	cbz	x1, 884c <fwp_main_thread+0xa5c>
    80ec:	f9009033 	str	x19, [x1, #288]
    80f0:	aa0003e1 	mov	x1, x0
    80f4:	f9002293 	str	x19, [x20, #64]
    80f8:	17ffff96 	b	7f50 <fwp_main_thread+0x160>
    80fc:	f9402280 	ldr	x0, [x20, #64]
    8100:	17ffff8e 	b	7f38 <fwp_main_thread+0x148>
    8104:	aa0203f3 	mov	x19, x2
    8108:	17ffff82 	b	7f10 <fwp_main_thread+0x120>
    810c:	a911fe78 	stp	x24, xzr, [x19, #280]
    8110:	f9009660 	str	x0, [x19, #296]
    8114:	b4000040 	cbz	x0, 811c <fwp_main_thread+0x32c>
    8118:	f9009013 	str	x19, [x0, #288]
    811c:	f9002293 	str	x19, [x20, #64]
    8120:	17ffff93 	b	7f6c <fwp_main_thread+0x17c>
    8124:	f9000040 	str	x0, [x2]
    8128:	17ffff99 	b	7f8c <fwp_main_thread+0x19c>
    812c:	f90056c0 	str	x0, [x22, #168]
    8130:	17ffffa2 	b	7fb8 <fwp_main_thread+0x1c8>
    8134:	f9001a93 	str	x19, [x20, #48]
    8138:	17ffffcc 	b	8068 <fwp_main_thread+0x278>
    813c:	f94196c0 	ldr	x0, [x22, #808]
    8140:	b90322df 	str	wzr, [x22, #800]
    8144:	b5003a00 	cbnz	x0, 8884 <fwp_main_thread+0xa94>
    8148:	9100c2b4 	add	x20, x21, #0x30
    814c:	97fff849 	bl	6270 <fwp_free_zombie>
    8150:	f9401a80 	ldr	x0, [x20, #48]
    8154:	b5003980 	cbnz	x0, 8884 <fwp_main_thread+0xa94>
    8158:	f9405680 	ldr	x0, [x20, #168]
    815c:	b5003940 	cbnz	x0, 8884 <fwp_main_thread+0xa94>
    8160:	b940ca80 	ldr	w0, [x20, #200]
    8164:	340001c0 	cbz	w0, 819c <fwp_main_thread+0x3ac>
    8168:	93407c16 	sxtw	x22, w0
    816c:	51000400 	sub	w0, w0, #0x1
    8170:	d1000ad6 	sub	x22, x22, #0x2
    8174:	91034297 	add	x23, x20, #0xd0
    8178:	cb2042d6 	sub	x22, x22, w0, uxtw
    817c:	93407c13 	sxtw	x19, w0
    8180:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    8184:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8188:	b900ca93 	str	w19, [x20, #200]
    818c:	d1000673 	sub	x19, x19, #0x1
    8190:	97ffea04 	bl	29a0 <munmap@plt>
    8194:	eb1302df 	cmp	x22, x19
    8198:	54ffff41 	b.ne	8180 <fwp_main_thread+0x390>  // b.any
    819c:	900000d3 	adrp	x19, 20000 <__data_start>
    81a0:	b9401260 	ldr	w0, [x19, #16]
    81a4:	37f80040 	tbnz	w0, #31, 81ac <fwp_main_thread+0x3bc>
    81a8:	97ffe9ba 	bl	2890 <close@plt>
    81ac:	9100c2a0 	add	x0, x21, #0x30
    81b0:	12800001 	mov	w1, #0xffffffff            	// #-1
    81b4:	b9001261 	str	w1, [x19, #16]
    81b8:	d2800013 	mov	x19, #0x0                   	// #0
    81bc:	f9419816 	ldr	x22, [x0, #816]
    81c0:	f9419c14 	ldr	x20, [x0, #824]
    81c4:	b4000176 	cbz	x22, 81f0 <fwp_main_thread+0x400>
    81c8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    81cc:	b40000c0 	cbz	x0, 81e4 <fwp_main_thread+0x3f4>
    81d0:	f9400001 	ldr	x1, [x0]
    81d4:	b5003581 	cbnz	x1, 8884 <fwp_main_thread+0xa94>
    81d8:	f9400401 	ldr	x1, [x0, #8]
    81dc:	b5003541 	cbnz	x1, 8884 <fwp_main_thread+0xa94>
    81e0:	97fff198 	bl	4840 <fwp_mem_free>
    81e4:	91000673 	add	x19, x19, #0x1
    81e8:	eb16027f 	cmp	x19, x22
    81ec:	54fffee1 	b.ne	81c8 <fwp_main_thread+0x3d8>  // b.any
    81f0:	aa1403e0 	mov	x0, x20
    81f4:	97fff193 	bl	4840 <fwp_mem_free>
    81f8:	9100c2a0 	add	x0, x21, #0x30
    81fc:	f9419413 	ldr	x19, [x0, #808]
    8200:	f901981f 	str	xzr, [x0, #816]
    8204:	f9019c1f 	str	xzr, [x0, #824]
    8208:	b40001f3 	cbz	x19, 8244 <fwp_main_thread+0x454>
    820c:	f9401661 	ldr	x1, [x19, #40]
    8210:	b50033a1 	cbnz	x1, 8884 <fwp_main_thread+0xa94>
    8214:	f9405661 	ldr	x1, [x19, #168]
    8218:	b5003361 	cbnz	x1, 8884 <fwp_main_thread+0xa94>
    821c:	f9417c01 	ldr	x1, [x0, #760]
    8220:	b5003321 	cbnz	x1, 8884 <fwp_main_thread+0xa94>
    8224:	f9418400 	ldr	x0, [x0, #776]
    8228:	b50032e0 	cbnz	x0, 8884 <fwp_main_thread+0xa94>
    822c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8230:	90000140 	adrp	x0, 30000 <alt.9+0xfc90>
    8234:	910dc000 	add	x0, x0, #0x370
    8238:	97ffe986 	bl	2850 <memset@plt>
    823c:	aa1303e0 	mov	x0, x19
    8240:	97fff180 	bl	4840 <fwp_mem_free>
    8244:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8248:	f947ec00 	ldr	x0, [x0, #4056]
    824c:	9100c2b5 	add	x21, x21, #0x30
    8250:	f9400000 	ldr	x0, [x0]
    8254:	f9000abf 	str	xzr, [x21, #16]
    8258:	f90196bf 	str	xzr, [x21, #808]
    825c:	97ffe9d5 	bl	29b0 <fflush@plt>
    8260:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8264:	f947f400 	ldr	x0, [x0, #4072]
    8268:	f9408fe2 	ldr	x2, [sp, #280]
    826c:	f9400001 	ldr	x1, [x0]
    8270:	eb010042 	subs	x2, x2, x1
    8274:	d2800001 	mov	x1, #0x0                   	// #0
    8278:	54003621 	b.ne	893c <fwp_main_thread+0xb4c>  // b.any
    827c:	a9527bfd 	ldp	x29, x30, [sp, #288]
    8280:	d2800000 	mov	x0, #0x0                   	// #0
    8284:	a95353f3 	ldp	x19, x20, [sp, #304]
    8288:	a9545bf5 	ldp	x21, x22, [sp, #320]
    828c:	a95563f7 	ldp	x23, x24, [sp, #336]
    8290:	a95773fb 	ldp	x27, x28, [sp, #368]
    8294:	910603ff 	add	sp, sp, #0x180
    8298:	d65f03c0 	ret
    829c:	97ffeefa 	bl	3e84 <fwp_heap_init>
    82a0:	911542e0 	add	x0, x23, #0x550
    82a4:	b953a800 	ldr	w0, [x0, #5032]
    82a8:	34ffdc80 	cbz	w0, 7e38 <fwp_main_thread+0x48>
    82ac:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    82b0:	91348000 	add	x0, x0, #0xd20
    82b4:	94000363 	bl	9040 <atexit>
    82b8:	17fffee0 	b	7e38 <fwp_main_thread+0x48>
    82bc:	f9417362 	ldr	x2, [x27, #736]
    82c0:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    82c4:	913d4021 	add	x1, x1, #0xf50
    82c8:	a90287e2 	stp	x2, x1, [sp, #40]
    82cc:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x10c>
    82d0:	f94003e1 	ldr	x1, [sp]
    82d4:	a9166bf9 	stp	x25, x26, [sp, #352]
    82d8:	91240000 	add	x0, x0, #0x900
    82dc:	911542f9 	add	x25, x23, #0x550
    82e0:	d2800013 	mov	x19, #0x0                   	// #0
    82e4:	d290001a 	mov	x26, #0x8000                	// #32768
    82e8:	d2800016 	mov	x22, #0x0                   	// #0
    82ec:	f9001fe1 	str	x1, [sp, #56]
    82f0:	f90023ff 	str	xzr, [sp, #64]
    82f4:	a90503ff 	stp	xzr, x0, [sp, #80]
    82f8:	f901737c 	str	x28, [x27, #736]
    82fc:	14000012 	b	8344 <fwp_main_thread+0x554>
    8300:	7100045f 	cmp	w2, #0x1
    8304:	540001a1 	b.ne	8338 <fwp_main_thread+0x548>  // b.any
    8308:	29430002 	ldp	w2, w0, [x0, #24]
    830c:	92403c21 	and	x1, x1, #0xffff
    8310:	9b027c21 	mul	x1, x1, x2
    8314:	d360fc21 	lsr	x1, x1, #32
    8318:	eb00003f 	cmp	x1, x0
    831c:	540000e2 	b.cs	8338 <fwp_main_thread+0x548>  // b.hs, b.nlast
    8320:	8b01039c 	add	x28, x28, x1
    8324:	39400380 	ldrb	w0, [x28]
    8328:	7103fc1f 	cmp	w0, #0xff
    832c:	540028a0 	b.eq	8840 <fwp_main_thread+0xa50>  // b.none
    8330:	52800020 	mov	w0, #0x1                   	// #1
    8334:	39000380 	strb	w0, [x28]
    8338:	f90023f3 	str	x19, [sp, #64]
    833c:	aa18037b 	orr	x27, x27, x24
    8340:	b40003fb 	cbz	x27, 83bc <fwp_main_thread+0x5cc>
    8344:	f100075b 	subs	x27, x26, #0x1
    8348:	aa1403e1 	mov	x1, x20
    834c:	da1f02d8 	sbc	x24, x22, xzr
    8350:	52800020 	mov	w0, #0x1                   	// #1
    8354:	f90027fb 	str	x27, [sp, #72]
    8358:	aa1b03fa 	mov	x26, x27
    835c:	a9084ffb 	stp	x27, x19, [sp, #128]
    8360:	97fff29d 	bl	4dd4 <fwp_data.part.0.constprop.0>
    8364:	aa0003f3 	mov	x19, x0
    8368:	f949db21 	ldr	x1, [x25, #5040]
    836c:	aa1803f6 	mov	x22, x24
    8370:	f949ef20 	ldr	x0, [x25, #5080]
    8374:	cb010261 	sub	x1, x19, x1
    8378:	eb00403f 	cmp	x1, x0, lsl #16
    837c:	54fffde2 	b.cs	8338 <fwp_main_thread+0x548>  // b.hs, b.nlast
    8380:	d350fc20 	lsr	x0, x1, #16
    8384:	f949ff25 	ldr	x5, [x25, #5112]
    8388:	8b000800 	add	x0, x0, x0, lsl #2
    838c:	d37df002 	lsl	x2, x0, #3
    8390:	8b0200a0 	add	x0, x5, x2
    8394:	f940101c 	ldr	x28, [x0, #32]
    8398:	b4fffd1c 	cbz	x28, 8338 <fwp_main_thread+0x548>
    839c:	386268a2 	ldrb	w2, [x5, x2]
    83a0:	7100085f 	cmp	w2, #0x2
    83a4:	54fffae1 	b.ne	8300 <fwp_main_thread+0x510>  // b.any
    83a8:	72003c3f 	tst	w1, #0xffff
    83ac:	54fffbc0 	b.eq	8324 <fwp_main_thread+0x534>  // b.none
    83b0:	f90023f3 	str	x19, [sp, #64]
    83b4:	aa18037b 	orr	x27, x27, x24
    83b8:	b5fffc7b 	cbnz	x27, 8344 <fwp_main_thread+0x554>
    83bc:	b0000000 	adrp	x0, 9000 <__modti3+0x330>
    83c0:	9100c2a2 	add	x2, x21, #0x30
    83c4:	f94017e3 	ldr	x3, [sp, #40]
    83c8:	910183e1 	add	x1, sp, #0x60
    83cc:	3dc32400 	ldr	q0, [x0, #3216]
    83d0:	52800020 	mov	w0, #0x1                   	// #1
    83d4:	f9017043 	str	x3, [x2, #736]
    83d8:	3d801be0 	str	q0, [sp, #96]
    83dc:	97fff27e 	bl	4dd4 <fwp_data.part.0.constprop.0>
    83e0:	911542e2 	add	x2, x23, #0x550
    83e4:	aa0003f9 	mov	x25, x0
    83e8:	f949d841 	ldr	x1, [x2, #5040]
    83ec:	f949ec40 	ldr	x0, [x2, #5080]
    83f0:	cb010321 	sub	x1, x25, x1
    83f4:	eb00403f 	cmp	x1, x0, lsl #16
    83f8:	54000322 	b.cs	845c <fwp_main_thread+0x66c>  // b.hs, b.nlast
    83fc:	d350fc20 	lsr	x0, x1, #16
    8400:	f949fc43 	ldr	x3, [x2, #5112]
    8404:	8b000800 	add	x0, x0, x0, lsl #2
    8408:	d37df002 	lsl	x2, x0, #3
    840c:	8b020060 	add	x0, x3, x2
    8410:	f9401016 	ldr	x22, [x0, #32]
    8414:	b4000256 	cbz	x22, 845c <fwp_main_thread+0x66c>
    8418:	38626862 	ldrb	w2, [x3, x2]
    841c:	7100085f 	cmp	w2, #0x2
    8420:	540020a0 	b.eq	8834 <fwp_main_thread+0xa44>  // b.none
    8424:	7100045f 	cmp	w2, #0x1
    8428:	540001a1 	b.ne	845c <fwp_main_thread+0x66c>  // b.any
    842c:	29430002 	ldp	w2, w0, [x0, #24]
    8430:	92403c21 	and	x1, x1, #0xffff
    8434:	9b027c21 	mul	x1, x1, x2
    8438:	d360fc21 	lsr	x1, x1, #32
    843c:	eb00003f 	cmp	x1, x0
    8440:	540000e2 	b.cs	845c <fwp_main_thread+0x66c>  // b.hs, b.nlast
    8444:	8b0102d6 	add	x22, x22, x1
    8448:	394002c0 	ldrb	w0, [x22]
    844c:	7103fc1f 	cmp	w0, #0xff
    8450:	54002620 	b.eq	8914 <fwp_main_thread+0xb24>  // b.none
    8454:	52800020 	mov	w0, #0x1                   	// #1
    8458:	390002c0 	strb	w0, [x22]
    845c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8460:	aa1403e1 	mov	x1, x20
    8464:	52800020 	mov	w0, #0x1                   	// #1
    8468:	a90867e2 	stp	x2, x25, [sp, #128]
    846c:	97fff25a 	bl	4dd4 <fwp_data.part.0.constprop.0>
    8470:	911542e2 	add	x2, x23, #0x550
    8474:	aa0003f6 	mov	x22, x0
    8478:	f949d841 	ldr	x1, [x2, #5040]
    847c:	f949ec40 	ldr	x0, [x2, #5080]
    8480:	cb0102c1 	sub	x1, x22, x1
    8484:	eb00403f 	cmp	x1, x0, lsl #16
    8488:	54000322 	b.cs	84ec <fwp_main_thread+0x6fc>  // b.hs, b.nlast
    848c:	d350fc20 	lsr	x0, x1, #16
    8490:	f949fc43 	ldr	x3, [x2, #5112]
    8494:	8b000800 	add	x0, x0, x0, lsl #2
    8498:	d37df002 	lsl	x2, x0, #3
    849c:	8b020060 	add	x0, x3, x2
    84a0:	f9401014 	ldr	x20, [x0, #32]
    84a4:	b4000254 	cbz	x20, 84ec <fwp_main_thread+0x6fc>
    84a8:	38626862 	ldrb	w2, [x3, x2]
    84ac:	7100085f 	cmp	w2, #0x2
    84b0:	54001bc0 	b.eq	8828 <fwp_main_thread+0xa38>  // b.none
    84b4:	7100045f 	cmp	w2, #0x1
    84b8:	540001a1 	b.ne	84ec <fwp_main_thread+0x6fc>  // b.any
    84bc:	29430002 	ldp	w2, w0, [x0, #24]
    84c0:	92403c21 	and	x1, x1, #0xffff
    84c4:	9b027c21 	mul	x1, x1, x2
    84c8:	d360fc21 	lsr	x1, x1, #32
    84cc:	eb00003f 	cmp	x1, x0
    84d0:	540000e2 	b.cs	84ec <fwp_main_thread+0x6fc>  // b.hs, b.nlast
    84d4:	8b010294 	add	x20, x20, x1
    84d8:	39400280 	ldrb	w0, [x20]
    84dc:	7103fc1f 	cmp	w0, #0xff
    84e0:	540020e0 	b.eq	88fc <fwp_main_thread+0xb0c>  // b.none
    84e4:	52800020 	mov	w0, #0x1                   	// #1
    84e8:	39000280 	strb	w0, [x20]
    84ec:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    84f0:	9101c3e1 	add	x1, sp, #0x70
    84f4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    84f8:	52800020 	mov	w0, #0x1                   	// #1
    84fc:	a9075be2 	stp	x2, x22, [sp, #112]
    8500:	97fff235 	bl	4dd4 <fwp_data.part.0.constprop.0>
    8504:	911542e2 	add	x2, x23, #0x550
    8508:	aa0003f4 	mov	x20, x0
    850c:	f949d841 	ldr	x1, [x2, #5040]
    8510:	f949ec40 	ldr	x0, [x2, #5080]
    8514:	cb010281 	sub	x1, x20, x1
    8518:	eb00403f 	cmp	x1, x0, lsl #16
    851c:	54000322 	b.cs	8580 <fwp_main_thread+0x790>  // b.hs, b.nlast
    8520:	d350fc20 	lsr	x0, x1, #16
    8524:	f949fc43 	ldr	x3, [x2, #5112]
    8528:	8b000800 	add	x0, x0, x0, lsl #2
    852c:	d37df002 	lsl	x2, x0, #3
    8530:	8b020060 	add	x0, x3, x2
    8534:	f9401016 	ldr	x22, [x0, #32]
    8538:	b4000256 	cbz	x22, 8580 <fwp_main_thread+0x790>
    853c:	38626862 	ldrb	w2, [x3, x2]
    8540:	7100085f 	cmp	w2, #0x2
    8544:	54001640 	b.eq	880c <fwp_main_thread+0xa1c>  // b.none
    8548:	7100045f 	cmp	w2, #0x1
    854c:	540001a1 	b.ne	8580 <fwp_main_thread+0x790>  // b.any
    8550:	29430002 	ldp	w2, w0, [x0, #24]
    8554:	92403c21 	and	x1, x1, #0xffff
    8558:	9b027c21 	mul	x1, x1, x2
    855c:	d360fc21 	lsr	x1, x1, #32
    8560:	eb00003f 	cmp	x1, x0
    8564:	540000e2 	b.cs	8580 <fwp_main_thread+0x790>  // b.hs, b.nlast
    8568:	8b0102d6 	add	x22, x22, x1
    856c:	394002c0 	ldrb	w0, [x22]
    8570:	7103fc1f 	cmp	w0, #0xff
    8574:	54001ca0 	b.eq	8908 <fwp_main_thread+0xb18>  // b.none
    8578:	52800020 	mov	w0, #0x1                   	// #1
    857c:	390002c0 	strb	w0, [x22]
    8580:	aa1303f6 	mov	x22, x19
    8584:	d00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x13110>
    8588:	b4001173 	cbz	x19, 87b4 <fwp_main_thread+0x9c4>
    858c:	910aa000 	add	x0, x0, #0x2a8
    8590:	911542fb 	add	x27, x23, #0x550
    8594:	91014000 	add	x0, x0, #0x50
    8598:	b000001a 	adrp	x26, 9000 <__modti3+0x330>
    859c:	52800038 	mov	w24, #0x1                   	// #1
    85a0:	f90007e0 	str	x0, [sp, #8]
    85a4:	9127a340 	add	x0, x26, #0x9e8
    85a8:	f9000be0 	str	x0, [sp, #16]
    85ac:	f949db61 	ldr	x1, [x27, #5040]
    85b0:	f949ef60 	ldr	x0, [x27, #5080]
    85b4:	cb010281 	sub	x1, x20, x1
    85b8:	eb00403f 	cmp	x1, x0, lsl #16
    85bc:	54000342 	b.cs	8624 <fwp_main_thread+0x834>  // b.hs, b.nlast
    85c0:	d350fc20 	lsr	x0, x1, #16
    85c4:	f949ff65 	ldr	x5, [x27, #5112]
    85c8:	8b000800 	add	x0, x0, x0, lsl #2
    85cc:	d37df002 	lsl	x2, x0, #3
    85d0:	8b0200a3 	add	x3, x5, x2
    85d4:	f9401060 	ldr	x0, [x3, #32]
    85d8:	b4000260 	cbz	x0, 8624 <fwp_main_thread+0x834>
    85dc:	386268a2 	ldrb	w2, [x5, x2]
    85e0:	7100085f 	cmp	w2, #0x2
    85e4:	54001020 	b.eq	87e8 <fwp_main_thread+0x9f8>  // b.none
    85e8:	7100045f 	cmp	w2, #0x1
    85ec:	540001c1 	b.ne	8624 <fwp_main_thread+0x834>  // b.any
    85f0:	29430865 	ldp	w5, w2, [x3, #24]
    85f4:	92403c21 	and	x1, x1, #0xffff
    85f8:	9b057c21 	mul	x1, x1, x5
    85fc:	d360fc21 	lsr	x1, x1, #32
    8600:	eb02003f 	cmp	x1, x2
    8604:	54000102 	b.cs	8624 <fwp_main_thread+0x834>  // b.hs, b.nlast
    8608:	8b010000 	add	x0, x0, x1
    860c:	39400001 	ldrb	w1, [x0]
    8610:	340000a1 	cbz	w1, 8624 <fwp_main_thread+0x834>
    8614:	7103f43f 	cmp	w1, #0xfd
    8618:	54001688 	b.hi	88e8 <fwp_main_thread+0xaf8>  // b.pmore
    861c:	11000421 	add	w1, w1, #0x1
    8620:	39000001 	strb	w1, [x0]
    8624:	a9400be0 	ldp	x0, x2, [sp]
    8628:	aa1403e1 	mov	x1, x20
    862c:	52800023 	mov	w3, #0x1                   	// #1
    8630:	a9047fff 	stp	xzr, xzr, [sp, #64]
    8634:	f9002bff 	str	xzr, [sp, #80]
    8638:	97fff9f3 	bl	6e04 <fwp_write>
    863c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    8640:	f9400be0 	ldr	x0, [sp, #16]
    8644:	f100033f 	cmp	x25, #0x0
    8648:	9a990019 	csel	x25, x0, x25, eq	// eq = none
    864c:	b1002b5f 	cmn	x26, #0xa
    8650:	540017a8 	b.hi	8944 <fwp_main_thread+0xb54>  // b.pmore
    8654:	52800021 	mov	w1, #0x1                   	// #1
    8658:	91002740 	add	x0, x26, #0x9
    865c:	97fff199 	bl	4cc0 <fwp_heap_alloc>
    8660:	aa0003fc 	mov	x28, x0
    8664:	aa1903e1 	mov	x1, x25
    8668:	aa0003f9 	mov	x25, x0
    866c:	aa1a03e2 	mov	x2, x26
    8670:	f800873a 	str	x26, [x25], #8
    8674:	aa1903e0 	mov	x0, x25
    8678:	97ffe816 	bl	26d0 <memcpy@plt>
    867c:	8b1a0382 	add	x2, x28, x26
    8680:	3900205f 	strb	wzr, [x2, #8]
    8684:	f94023e0 	ldr	x0, [sp, #64]
    8688:	97ffe8ae 	bl	2940 <free@plt>
    868c:	f949db62 	ldr	x2, [x27, #5040]
    8690:	f949ef60 	ldr	x0, [x27, #5080]
    8694:	cb020382 	sub	x2, x28, x2
    8698:	eb00405f 	cmp	x2, x0, lsl #16
    869c:	54000302 	b.cs	86fc <fwp_main_thread+0x90c>  // b.hs, b.nlast
    86a0:	d350fc40 	lsr	x0, x2, #16
    86a4:	f949ff66 	ldr	x6, [x27, #5112]
    86a8:	8b000800 	add	x0, x0, x0, lsl #2
    86ac:	d37df001 	lsl	x1, x0, #3
    86b0:	8b0100c5 	add	x5, x6, x1
    86b4:	f94010a0 	ldr	x0, [x5, #32]
    86b8:	b4000220 	cbz	x0, 86fc <fwp_main_thread+0x90c>
    86bc:	386168c1 	ldrb	w1, [x6, x1]
    86c0:	7100083f 	cmp	w1, #0x2
    86c4:	54000980 	b.eq	87f4 <fwp_main_thread+0xa04>  // b.none
    86c8:	7100043f 	cmp	w1, #0x1
    86cc:	54000181 	b.ne	86fc <fwp_main_thread+0x90c>  // b.any
    86d0:	92403c41 	and	x1, x2, #0xffff
    86d4:	294308a6 	ldp	w6, w2, [x5, #24]
    86d8:	9b067c21 	mul	x1, x1, x6
    86dc:	d360fc21 	lsr	x1, x1, #32
    86e0:	eb02003f 	cmp	x1, x2
    86e4:	540000c2 	b.cs	86fc <fwp_main_thread+0x90c>  // b.hs, b.nlast
    86e8:	8b010000 	add	x0, x0, x1
    86ec:	39400001 	ldrb	w1, [x0]
    86f0:	7103fc3f 	cmp	w1, #0xff
    86f4:	54000920 	b.eq	8818 <fwp_main_thread+0xa28>  // b.none
    86f8:	39000018 	strb	w24, [x0]
    86fc:	aa1403e0 	mov	x0, x20
    8700:	97fff42c 	bl	57b0 <fwp_drop0>
    8704:	9100c2a5 	add	x5, x21, #0x30
    8708:	aa1903e0 	mov	x0, x25
    870c:	f9400382 	ldr	x2, [x28]
    8710:	aa0503f9 	mov	x25, x5
    8714:	f94004a3 	ldr	x3, [x5, #8]
    8718:	d2800021 	mov	x1, #0x1                   	// #1
    871c:	97ffe899 	bl	2980 <fwrite@plt>
    8720:	f9400721 	ldr	x1, [x25, #8]
    8724:	52800140 	mov	w0, #0xa                   	// #10
    8728:	97ffe81e 	bl	27a0 <fputc@plt>
    872c:	f949db62 	ldr	x2, [x27, #5040]
    8730:	f949ef60 	ldr	x0, [x27, #5080]
    8734:	cb020382 	sub	x2, x28, x2
    8738:	eb00405f 	cmp	x2, x0, lsl #16
    873c:	54000382 	b.cs	87ac <fwp_main_thread+0x9bc>  // b.hs, b.nlast
    8740:	d350fc40 	lsr	x0, x2, #16
    8744:	f949ff65 	ldr	x5, [x27, #5112]
    8748:	8b000800 	add	x0, x0, x0, lsl #2
    874c:	d37df001 	lsl	x1, x0, #3
    8750:	8b0100a3 	add	x3, x5, x1
    8754:	f9401060 	ldr	x0, [x3, #32]
    8758:	b40002a0 	cbz	x0, 87ac <fwp_main_thread+0x9bc>
    875c:	386168a1 	ldrb	w1, [x5, x1]
    8760:	7100083f 	cmp	w1, #0x2
    8764:	540004e0 	b.eq	8800 <fwp_main_thread+0xa10>  // b.none
    8768:	7100043f 	cmp	w1, #0x1
    876c:	54000201 	b.ne	87ac <fwp_main_thread+0x9bc>  // b.any
    8770:	92403c41 	and	x1, x2, #0xffff
    8774:	29430865 	ldp	w5, w2, [x3, #24]
    8778:	9b057c21 	mul	x1, x1, x5
    877c:	d360fc21 	lsr	x1, x1, #32
    8780:	eb02003f 	cmp	x1, x2
    8784:	54000142 	b.cs	87ac <fwp_main_thread+0x9bc>  // b.hs, b.nlast
    8788:	8b010000 	add	x0, x0, x1
    878c:	39400001 	ldrb	w1, [x0]
    8790:	340000e1 	cbz	w1, 87ac <fwp_main_thread+0x9bc>
    8794:	7100043f 	cmp	w1, #0x1
    8798:	54000220 	b.eq	87dc <fwp_main_thread+0x9ec>  // b.none
    879c:	7103fc3f 	cmp	w1, #0xff
    87a0:	54000760 	b.eq	888c <fwp_main_thread+0xa9c>  // b.none
    87a4:	51000421 	sub	w1, w1, #0x1
    87a8:	39000001 	strb	w1, [x0]
    87ac:	f9400ad6 	ldr	x22, [x22, #16]
    87b0:	b5ffeff6 	cbnz	x22, 85ac <fwp_main_thread+0x7bc>
    87b4:	aa1403e0 	mov	x0, x20
    87b8:	97fff3fe 	bl	57b0 <fwp_drop0>
    87bc:	aa1303e0 	mov	x0, x19
    87c0:	97fff3fc 	bl	57b0 <fwp_drop0>
    87c4:	9100c2a0 	add	x0, x21, #0x30
    87c8:	52800021 	mov	w1, #0x1                   	// #1
    87cc:	a9566bf9 	ldp	x25, x26, [sp, #352]
    87d0:	b9031401 	str	w1, [x0, #788]
    87d4:	f9018c1f 	str	xzr, [x0, #792]
    87d8:	17fffdc5 	b	7eec <fwp_main_thread+0xfc>
    87dc:	aa1c03e0 	mov	x0, x28
    87e0:	97fff31d 	bl	5454 <fwp_rc_free_arr>
    87e4:	17fffff2 	b	87ac <fwp_main_thread+0x9bc>
    87e8:	72003c3f 	tst	w1, #0xffff
    87ec:	54fff1c1 	b.ne	8624 <fwp_main_thread+0x834>  // b.any
    87f0:	17ffff87 	b	860c <fwp_main_thread+0x81c>
    87f4:	72003c5f 	tst	w2, #0xffff
    87f8:	54fff821 	b.ne	86fc <fwp_main_thread+0x90c>  // b.any
    87fc:	17ffffbc 	b	86ec <fwp_main_thread+0x8fc>
    8800:	72003c5f 	tst	w2, #0xffff
    8804:	54fffd41 	b.ne	87ac <fwp_main_thread+0x9bc>  // b.any
    8808:	17ffffe1 	b	878c <fwp_main_thread+0x99c>
    880c:	72003c3f 	tst	w1, #0xffff
    8810:	54ffeb81 	b.ne	8580 <fwp_main_thread+0x790>  // b.any
    8814:	17ffff56 	b	856c <fwp_main_thread+0x77c>
    8818:	f9000fe0 	str	x0, [sp, #24]
    881c:	97ffef69 	bl	45c0 <fwp_rc_forget_slot>
    8820:	f9400fe0 	ldr	x0, [sp, #24]
    8824:	17ffffb5 	b	86f8 <fwp_main_thread+0x908>
    8828:	72003c3f 	tst	w1, #0xffff
    882c:	54ffe601 	b.ne	84ec <fwp_main_thread+0x6fc>  // b.any
    8830:	17ffff2a 	b	84d8 <fwp_main_thread+0x6e8>
    8834:	72003c3f 	tst	w1, #0xffff
    8838:	54ffe121 	b.ne	845c <fwp_main_thread+0x66c>  // b.any
    883c:	17ffff03 	b	8448 <fwp_main_thread+0x658>
    8840:	aa1c03e0 	mov	x0, x28
    8844:	97ffef5f 	bl	45c0 <fwp_rc_forget_slot>
    8848:	17fffeba 	b	8330 <fwp_main_thread+0x540>
    884c:	aa0003e1 	mov	x1, x0
    8850:	f9002293 	str	x19, [x20, #64]
    8854:	17fffdbf 	b	7f50 <fwp_main_thread+0x160>
    8858:	f9417a80 	ldr	x0, [x20, #752]
    885c:	97ffeff9 	bl	4840 <fwp_mem_free>
    8860:	f9017a9f 	str	xzr, [x20, #752]
    8864:	f901829f 	str	xzr, [x20, #768]
    8868:	f9419680 	ldr	x0, [x20, #808]
    886c:	b4000433 	cbz	x19, 88f0 <fwp_main_thread+0xb00>
    8870:	f900567f 	str	xzr, [x19, #168]
    8874:	f9005e7f 	str	xzr, [x19, #184]
    8878:	b903229f 	str	wzr, [x20, #800]
    887c:	eb13001f 	cmp	x0, x19
    8880:	54ffbc80 	b.eq	8010 <fwp_main_thread+0x220>  // b.none
    8884:	a9166bf9 	stp	x25, x26, [sp, #352]
    8888:	97ffe812 	bl	28d0 <abort@plt>
    888c:	ca404401 	eor	x1, x0, x0, lsr #17
    8890:	911542e2 	add	x2, x23, #0x550
    8894:	ca412421 	eor	x1, x1, x1, lsr #9
    8898:	8b210c41 	add	x1, x2, w1, uxtb #3
    889c:	f94a2421 	ldr	x1, [x1, #5192]
    88a0:	b5000081 	cbnz	x1, 88b0 <fwp_main_thread+0xac0>
    88a4:	14000023 	b	8930 <fwp_main_thread+0xb40>
    88a8:	f9400821 	ldr	x1, [x1, #16]
    88ac:	b4000421 	cbz	x1, 8930 <fwp_main_thread+0xb40>
    88b0:	f9400022 	ldr	x2, [x1]
    88b4:	eb02001f 	cmp	x0, x2
    88b8:	54ffff81 	b.ne	88a8 <fwp_main_thread+0xab8>  // b.any
    88bc:	f9400422 	ldr	x2, [x1, #8]
    88c0:	d1000442 	sub	x2, x2, #0x1
    88c4:	f9000422 	str	x2, [x1, #8]
    88c8:	f103f85f 	cmp	x2, #0xfe
    88cc:	54fff701 	b.ne	87ac <fwp_main_thread+0x9bc>  // b.any
    88d0:	f9000fe0 	str	x0, [sp, #24]
    88d4:	97ffef3b 	bl	45c0 <fwp_rc_forget_slot>
    88d8:	f9400fe0 	ldr	x0, [sp, #24]
    88dc:	12800021 	mov	w1, #0xfffffffe            	// #-2
    88e0:	39000001 	strb	w1, [x0]
    88e4:	17ffffb2 	b	87ac <fwp_main_thread+0x9bc>
    88e8:	97ffeeef 	bl	44a4 <fwp_rc_wide_dup>
    88ec:	17ffff4e 	b	8624 <fwp_main_thread+0x834>
    88f0:	b903229f 	str	wzr, [x20, #800]
    88f4:	b4ffc2a0 	cbz	x0, 8148 <fwp_main_thread+0x358>
    88f8:	17ffffe3 	b	8884 <fwp_main_thread+0xa94>
    88fc:	aa1403e0 	mov	x0, x20
    8900:	97ffef30 	bl	45c0 <fwp_rc_forget_slot>
    8904:	17fffef8 	b	84e4 <fwp_main_thread+0x6f4>
    8908:	aa1603e0 	mov	x0, x22
    890c:	97ffef2d 	bl	45c0 <fwp_rc_forget_slot>
    8910:	17ffff1a 	b	8578 <fwp_main_thread+0x788>
    8914:	aa1603e0 	mov	x0, x22
    8918:	97ffef2a 	bl	45c0 <fwp_rc_forget_slot>
    891c:	17fffece 	b	8454 <fwp_main_thread+0x664>
    8920:	b0000000 	adrp	x0, 9000 <__modti3+0x330>
    8924:	91156000 	add	x0, x0, #0x558
    8928:	a9166bf9 	stp	x25, x26, [sp, #352]
    892c:	97ffeb15 	bl	3580 <fwp_trap>
    8930:	b0000000 	adrp	x0, 9000 <__modti3+0x330>
    8934:	910c6000 	add	x0, x0, #0x318
    8938:	97ffeb12 	bl	3580 <fwp_trap>
    893c:	a9166bf9 	stp	x25, x26, [sp, #352]
    8940:	97ffe7d0 	bl	2880 <__stack_chk_fail@plt>
    8944:	b0000000 	adrp	x0, 9000 <__modti3+0x330>
    8948:	91160000 	add	x0, x0, #0x580
    894c:	97ffeb0d 	bl	3580 <fwp_trap>

0000000000008950 <__divti3>:
    8950:	d503245f 	bti	c
    8954:	d2800004 	mov	x4, #0x0                   	// #0
    8958:	b7f80721 	tbnz	x1, #63, 8a3c <__divti3+0xec>
    895c:	b6f80083 	tbz	x3, #63, 896c <__divti3+0x1c>
    8960:	eb0203e2 	negs	x2, x2
    8964:	aa2403e4 	mvn	x4, x4
    8968:	da0303e3 	ngc	x3, x3
    896c:	aa0203e6 	mov	x6, x2
    8970:	aa0003e7 	mov	x7, x0
    8974:	aa0103e5 	mov	x5, x1
    8978:	b5000583 	cbnz	x3, 8a28 <__divti3+0xd8>
    897c:	eb01005f 	cmp	x2, x1
    8980:	54000e69 	b.ls	8b4c <__divti3+0x1fc>  // b.plast
    8984:	dac01040 	clz	x0, x2
    8988:	b40000e0 	cbz	x0, 89a4 <__divti3+0x54>
    898c:	4b0003e1 	neg	w1, w0
    8990:	9ac020a5 	lsl	x5, x5, x0
    8994:	9ac02046 	lsl	x6, x2, x0
    8998:	9ac124e1 	lsr	x1, x7, x1
    899c:	aa050025 	orr	x5, x1, x5
    89a0:	9ac020e7 	lsl	x7, x7, x0
    89a4:	d360fcc8 	lsr	x8, x6, #32
    89a8:	92407cc2 	and	x2, x6, #0xffffffff
    89ac:	9ac808a3 	udiv	x3, x5, x8
    89b0:	9b089465 	msub	x5, x3, x8, x5
    89b4:	aa0303e0 	mov	x0, x3
    89b8:	9b037c41 	mul	x1, x2, x3
    89bc:	93c780a5 	extr	x5, x5, x7, #32
    89c0:	eb05003f 	cmp	x1, x5
    89c4:	540000a9 	b.ls	89d8 <__divti3+0x88>  // b.plast
    89c8:	ab0500c5 	adds	x5, x6, x5
    89cc:	d1000460 	sub	x0, x3, #0x1
    89d0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    89d4:	540015a8 	b.hi	8c88 <__divti3+0x338>  // b.pmore
    89d8:	cb0100a5 	sub	x5, x5, x1
    89dc:	9ac808a3 	udiv	x3, x5, x8
    89e0:	9b089465 	msub	x5, x3, x8, x5
    89e4:	aa0303e1 	mov	x1, x3
    89e8:	9b037c42 	mul	x2, x2, x3
    89ec:	aa0703e3 	mov	x3, x7
    89f0:	b3607ca3 	bfi	x3, x5, #32, #32
    89f4:	eb03005f 	cmp	x2, x3
    89f8:	540000c9 	b.ls	8a10 <__divti3+0xc0>  // b.plast
    89fc:	ab0300c3 	adds	x3, x6, x3
    8a00:	d1000425 	sub	x5, x1, #0x1
    8a04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8a08:	d1000821 	sub	x1, x1, #0x2
    8a0c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8a10:	aa008020 	orr	x0, x1, x0, lsl #32
    8a14:	d2800001 	mov	x1, #0x0                   	// #0
    8a18:	b4000064 	cbz	x4, 8a24 <__divti3+0xd4>
    8a1c:	eb0003e0 	negs	x0, x0
    8a20:	da0103e1 	ngc	x1, x1
    8a24:	d65f03c0 	ret
    8a28:	eb01007f 	cmp	x3, x1
    8a2c:	54000109 	b.ls	8a4c <__divti3+0xfc>  // b.plast
    8a30:	d2800001 	mov	x1, #0x0                   	// #0
    8a34:	d2800000 	mov	x0, #0x0                   	// #0
    8a38:	17fffff8 	b	8a18 <__divti3+0xc8>
    8a3c:	eb0003e0 	negs	x0, x0
    8a40:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8a44:	da0103e1 	ngc	x1, x1
    8a48:	17ffffc5 	b	895c <__divti3+0xc>
    8a4c:	dac01067 	clz	x7, x3
    8a50:	b40010e7 	cbz	x7, 8c6c <__divti3+0x31c>
    8a54:	d2800805 	mov	x5, #0x40                  	// #64
    8a58:	cb0700a5 	sub	x5, x5, x7
    8a5c:	9ac72063 	lsl	x3, x3, x7
    8a60:	9ac52448 	lsr	x8, x2, x5
    8a64:	aa030108 	orr	x8, x8, x3
    8a68:	9ac52426 	lsr	x6, x1, x5
    8a6c:	92407d0a 	and	x10, x8, #0xffffffff
    8a70:	d360fd09 	lsr	x9, x8, #32
    8a74:	9ac52403 	lsr	x3, x0, x5
    8a78:	9ac72021 	lsl	x1, x1, x7
    8a7c:	aa010063 	orr	x3, x3, x1
    8a80:	9ac72042 	lsl	x2, x2, x7
    8a84:	9ac908cb 	udiv	x11, x6, x9
    8a88:	9b099965 	msub	x5, x11, x9, x6
    8a8c:	aa0b03e1 	mov	x1, x11
    8a90:	9b0b7d46 	mul	x6, x10, x11
    8a94:	93c380a5 	extr	x5, x5, x3, #32
    8a98:	eb0500df 	cmp	x6, x5
    8a9c:	540000a9 	b.ls	8ab0 <__divti3+0x160>  // b.plast
    8aa0:	ab050105 	adds	x5, x8, x5
    8aa4:	d1000561 	sub	x1, x11, #0x1
    8aa8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    8aac:	54000f48 	b.hi	8c94 <__divti3+0x344>  // b.pmore
    8ab0:	cb0600a6 	sub	x6, x5, x6
    8ab4:	9ac908cb 	udiv	x11, x6, x9
    8ab8:	9b099969 	msub	x9, x11, x9, x6
    8abc:	aa0b03e5 	mov	x5, x11
    8ac0:	9b0b7d4a 	mul	x10, x10, x11
    8ac4:	b3607d23 	bfi	x3, x9, #32, #32
    8ac8:	eb03015f 	cmp	x10, x3
    8acc:	540000a9 	b.ls	8ae0 <__divti3+0x190>  // b.plast
    8ad0:	ab030103 	adds	x3, x8, x3
    8ad4:	d1000565 	sub	x5, x11, #0x1
    8ad8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    8adc:	54000e28 	b.hi	8ca0 <__divti3+0x350>  // b.pmore
    8ae0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8ae4:	92407c48 	and	x8, x2, #0xffffffff
    8ae8:	2a0503e5 	mov	w5, w5
    8aec:	d360fc42 	lsr	x2, x2, #32
    8af0:	d360fc26 	lsr	x6, x1, #32
    8af4:	cb0a0063 	sub	x3, x3, x10
    8af8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    8afc:	9b087caa 	mul	x10, x5, x8
    8b00:	9b087cc8 	mul	x8, x6, x8
    8b04:	9b0220a5 	madd	x5, x5, x2, x8
    8b08:	9b027cc6 	mul	x6, x6, x2
    8b0c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8b10:	8b0900c5 	add	x5, x6, x9
    8b14:	eb02011f 	cmp	x8, x2
    8b18:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    8b1c:	8b4280c6 	add	x6, x6, x2, lsr #32
    8b20:	eb06007f 	cmp	x3, x6
    8b24:	540000e3 	b.cc	8b40 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    8b28:	92407d4a 	and	x10, x10, #0xffffffff
    8b2c:	9ac72000 	lsl	x0, x0, x7
    8b30:	8b028142 	add	x2, x10, x2, lsl #32
    8b34:	eb02001f 	cmp	x0, x2
    8b38:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    8b3c:	54000a01 	b.ne	8c7c <__divti3+0x32c>  // b.any
    8b40:	d1000420 	sub	x0, x1, #0x1
    8b44:	d2800001 	mov	x1, #0x0                   	// #0
    8b48:	17ffffb4 	b	8a18 <__divti3+0xc8>
    8b4c:	b5000062 	cbnz	x2, 8b58 <__divti3+0x208>
    8b50:	d2800022 	mov	x2, #0x1                   	// #1
    8b54:	9ac30846 	udiv	x6, x2, x3
    8b58:	dac010c8 	clz	x8, x6
    8b5c:	b5000408 	cbnz	x8, 8bdc <__divti3+0x28c>
    8b60:	d360fcc9 	lsr	x9, x6, #32
    8b64:	92407cc5 	and	x5, x6, #0xffffffff
    8b68:	cb060023 	sub	x3, x1, x6
    8b6c:	d2800021 	mov	x1, #0x1                   	// #1
    8b70:	9ac90868 	udiv	x8, x3, x9
    8b74:	9b098d03 	msub	x3, x8, x9, x3
    8b78:	aa0803e0 	mov	x0, x8
    8b7c:	9b057d02 	mul	x2, x8, x5
    8b80:	93c78063 	extr	x3, x3, x7, #32
    8b84:	eb03005f 	cmp	x2, x3
    8b88:	540000a9 	b.ls	8b9c <__divti3+0x24c>  // b.plast
    8b8c:	ab0300c3 	adds	x3, x6, x3
    8b90:	d1000500 	sub	x0, x8, #0x1
    8b94:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8b98:	54000968 	b.hi	8cc4 <__divti3+0x374>  // b.pmore
    8b9c:	cb020063 	sub	x3, x3, x2
    8ba0:	9ac90862 	udiv	x2, x3, x9
    8ba4:	aa0203e8 	mov	x8, x2
    8ba8:	9b098c42 	msub	x2, x2, x9, x3
    8bac:	aa0703e3 	mov	x3, x7
    8bb0:	9b057d05 	mul	x5, x8, x5
    8bb4:	b3607c43 	bfi	x3, x2, #32, #32
    8bb8:	eb0300bf 	cmp	x5, x3
    8bbc:	540000c9 	b.ls	8bd4 <__divti3+0x284>  // b.plast
    8bc0:	ab0300c2 	adds	x2, x6, x3
    8bc4:	d1000503 	sub	x3, x8, #0x1
    8bc8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    8bcc:	d1000908 	sub	x8, x8, #0x2
    8bd0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8bd4:	aa008100 	orr	x0, x8, x0, lsl #32
    8bd8:	17ffff90 	b	8a18 <__divti3+0xc8>
    8bdc:	9ac820c6 	lsl	x6, x6, x8
    8be0:	d2800803 	mov	x3, #0x40                  	// #64
    8be4:	cb080063 	sub	x3, x3, x8
    8be8:	d360fcc9 	lsr	x9, x6, #32
    8bec:	9ac82027 	lsl	x7, x1, x8
    8bf0:	92407cc5 	and	x5, x6, #0xffffffff
    8bf4:	9ac32422 	lsr	x2, x1, x3
    8bf8:	9ac32403 	lsr	x3, x0, x3
    8bfc:	aa070063 	orr	x3, x3, x7
    8c00:	9ac9084a 	udiv	x10, x2, x9
    8c04:	9ac82007 	lsl	x7, x0, x8
    8c08:	9b098940 	msub	x0, x10, x9, x2
    8c0c:	aa0a03e1 	mov	x1, x10
    8c10:	9b0a7ca2 	mul	x2, x5, x10
    8c14:	93c38000 	extr	x0, x0, x3, #32
    8c18:	eb00005f 	cmp	x2, x0
    8c1c:	540000a9 	b.ls	8c30 <__divti3+0x2e0>  // b.plast
    8c20:	ab0000c0 	adds	x0, x6, x0
    8c24:	d1000541 	sub	x1, x10, #0x1
    8c28:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    8c2c:	54000468 	b.hi	8cb8 <__divti3+0x368>  // b.pmore
    8c30:	cb020000 	sub	x0, x0, x2
    8c34:	9ac9080a 	udiv	x10, x0, x9
    8c38:	9b098140 	msub	x0, x10, x9, x0
    8c3c:	aa0a03e2 	mov	x2, x10
    8c40:	9b0a7ca8 	mul	x8, x5, x10
    8c44:	b3607c03 	bfi	x3, x0, #32, #32
    8c48:	eb03011f 	cmp	x8, x3
    8c4c:	540000a9 	b.ls	8c60 <__divti3+0x310>  // b.plast
    8c50:	ab0300c3 	adds	x3, x6, x3
    8c54:	d1000542 	sub	x2, x10, #0x1
    8c58:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    8c5c:	54000288 	b.hi	8cac <__divti3+0x35c>  // b.pmore
    8c60:	cb080063 	sub	x3, x3, x8
    8c64:	aa018041 	orr	x1, x2, x1, lsl #32
    8c68:	17ffffc2 	b	8b70 <__divti3+0x220>
    8c6c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    8c70:	d2800001 	mov	x1, #0x0                   	// #0
    8c74:	9a9f87e0 	cset	x0, ls	// ls = plast
    8c78:	17ffff68 	b	8a18 <__divti3+0xc8>
    8c7c:	aa0103e0 	mov	x0, x1
    8c80:	d2800001 	mov	x1, #0x0                   	// #0
    8c84:	17ffff65 	b	8a18 <__divti3+0xc8>
    8c88:	d1000860 	sub	x0, x3, #0x2
    8c8c:	8b0600a5 	add	x5, x5, x6
    8c90:	17ffff52 	b	89d8 <__divti3+0x88>
    8c94:	d1000961 	sub	x1, x11, #0x2
    8c98:	8b0800a5 	add	x5, x5, x8
    8c9c:	17ffff85 	b	8ab0 <__divti3+0x160>
    8ca0:	d1000965 	sub	x5, x11, #0x2
    8ca4:	8b080063 	add	x3, x3, x8
    8ca8:	17ffff8e 	b	8ae0 <__divti3+0x190>
    8cac:	d1000942 	sub	x2, x10, #0x2
    8cb0:	8b060063 	add	x3, x3, x6
    8cb4:	17ffffeb 	b	8c60 <__divti3+0x310>
    8cb8:	d1000941 	sub	x1, x10, #0x2
    8cbc:	8b060000 	add	x0, x0, x6
    8cc0:	17ffffdc 	b	8c30 <__divti3+0x2e0>
    8cc4:	d1000900 	sub	x0, x8, #0x2
    8cc8:	8b060063 	add	x3, x3, x6
    8ccc:	17ffffb4 	b	8b9c <__divti3+0x24c>

0000000000008cd0 <__modti3>:
    8cd0:	d503245f 	bti	c
    8cd4:	d2800004 	mov	x4, #0x0                   	// #0
    8cd8:	b6f80081 	tbz	x1, #63, 8ce8 <__modti3+0x18>
    8cdc:	eb0003e0 	negs	x0, x0
    8ce0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8ce4:	da0103e1 	ngc	x1, x1
    8ce8:	f100007f 	cmp	x3, #0x0
    8cec:	5400128b 	b.lt	8f3c <__modti3+0x26c>  // b.tstop
    8cf0:	aa0003e7 	mov	x7, x0
    8cf4:	aa0103e6 	mov	x6, x1
    8cf8:	540004e1 	b.ne	8d94 <__modti3+0xc4>  // b.any
    8cfc:	eb02003f 	cmp	x1, x2
    8d00:	54000dc2 	b.cs	8eb8 <__modti3+0x1e8>  // b.hs, b.nlast
    8d04:	dac01043 	clz	x3, x2
    8d08:	aa0303e5 	mov	x5, x3
    8d0c:	b40000e3 	cbz	x3, 8d28 <__modti3+0x58>
    8d10:	4b0303e6 	neg	w6, w3
    8d14:	9ac32021 	lsl	x1, x1, x3
    8d18:	9ac32042 	lsl	x2, x2, x3
    8d1c:	9ac62406 	lsr	x6, x0, x6
    8d20:	aa0100c6 	orr	x6, x6, x1
    8d24:	9ac32007 	lsl	x7, x0, x3
    8d28:	d360fc40 	lsr	x0, x2, #32
    8d2c:	92407c43 	and	x3, x2, #0xffffffff
    8d30:	9ac008c1 	udiv	x1, x6, x0
    8d34:	9b009826 	msub	x6, x1, x0, x6
    8d38:	9b017c61 	mul	x1, x3, x1
    8d3c:	93c780c6 	extr	x6, x6, x7, #32
    8d40:	eb06003f 	cmp	x1, x6
    8d44:	540000a9 	b.ls	8d58 <__modti3+0x88>  // b.plast
    8d48:	ab060046 	adds	x6, x2, x6
    8d4c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    8d50:	8b0200c8 	add	x8, x6, x2
    8d54:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    8d58:	cb0100c6 	sub	x6, x6, x1
    8d5c:	9ac008c8 	udiv	x8, x6, x0
    8d60:	9b009901 	msub	x1, x8, x0, x6
    8d64:	aa0703e0 	mov	x0, x7
    8d68:	9b087c63 	mul	x3, x3, x8
    8d6c:	b3607c20 	bfi	x0, x1, #32, #32
    8d70:	eb00007f 	cmp	x3, x0
    8d74:	54001088 	b.hi	8f84 <__modti3+0x2b4>  // b.pmore
    8d78:	cb030000 	sub	x0, x0, x3
    8d7c:	9ac52400 	lsr	x0, x0, x5
    8d80:	d2800001 	mov	x1, #0x0                   	// #0
    8d84:	b4000064 	cbz	x4, 8d90 <__modti3+0xc0>
    8d88:	eb0003e0 	negs	x0, x0
    8d8c:	da0103e1 	ngc	x1, x1
    8d90:	d65f03c0 	ret
    8d94:	dac01066 	clz	x6, x3
    8d98:	eb03003f 	cmp	x1, x3
    8d9c:	54ffff43 	b.cc	8d84 <__modti3+0xb4>  // b.lo, b.ul, b.last
    8da0:	93407cc5 	sxtw	x5, w6
    8da4:	d2800808 	mov	x8, #0x40                  	// #64
    8da8:	cb050108 	sub	x8, x8, x5
    8dac:	9ac62063 	lsl	x3, x3, x6
    8db0:	9ac62025 	lsl	x5, x1, x6
    8db4:	9ac82447 	lsr	x7, x2, x8
    8db8:	aa0300e7 	orr	x7, x7, x3
    8dbc:	9ac82423 	lsr	x3, x1, x8
    8dc0:	92407cec 	and	x12, x7, #0xffffffff
    8dc4:	d360fcea 	lsr	x10, x7, #32
    8dc8:	9ac82401 	lsr	x1, x0, x8
    8dcc:	aa050021 	orr	x1, x1, x5
    8dd0:	9ac62042 	lsl	x2, x2, x6
    8dd4:	9ac62000 	lsl	x0, x0, x6
    8dd8:	9aca086b 	udiv	x11, x3, x10
    8ddc:	9b0a8d63 	msub	x3, x11, x10, x3
    8de0:	aa0b03e5 	mov	x5, x11
    8de4:	9b0b7d89 	mul	x9, x12, x11
    8de8:	93c18063 	extr	x3, x3, x1, #32
    8dec:	eb03013f 	cmp	x9, x3
    8df0:	540000a9 	b.ls	8e04 <__modti3+0x134>  // b.plast
    8df4:	ab0300e3 	adds	x3, x7, x3
    8df8:	d1000565 	sub	x5, x11, #0x1
    8dfc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    8e00:	54001168 	b.hi	902c <__modti3+0x35c>  // b.pmore
    8e04:	cb090063 	sub	x3, x3, x9
    8e08:	9aca086b 	udiv	x11, x3, x10
    8e0c:	9b0a8d6a 	msub	x10, x11, x10, x3
    8e10:	aa0b03e9 	mov	x9, x11
    8e14:	9b0b7d8c 	mul	x12, x12, x11
    8e18:	b3607d41 	bfi	x1, x10, #32, #32
    8e1c:	eb01019f 	cmp	x12, x1
    8e20:	540000a9 	b.ls	8e34 <__modti3+0x164>  // b.plast
    8e24:	ab0100e1 	adds	x1, x7, x1
    8e28:	d1000569 	sub	x9, x11, #0x1
    8e2c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    8e30:	54000f88 	b.hi	9020 <__modti3+0x350>  // b.pmore
    8e34:	aa058123 	orr	x3, x9, x5, lsl #32
    8e38:	92407c4b 	and	x11, x2, #0xffffffff
    8e3c:	2a0903e9 	mov	w9, w9
    8e40:	d360fc4a 	lsr	x10, x2, #32
    8e44:	d360fc63 	lsr	x3, x3, #32
    8e48:	cb0c0021 	sub	x1, x1, x12
    8e4c:	aa0a03ec 	mov	x12, x10
    8e50:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    8e54:	9b0b7d25 	mul	x5, x9, x11
    8e58:	9b0b7c6b 	mul	x11, x3, x11
    8e5c:	9b0a2d29 	madd	x9, x9, x10, x11
    8e60:	92407caa 	and	x10, x5, #0xffffffff
    8e64:	9b0c7c63 	mul	x3, x3, x12
    8e68:	8b458125 	add	x5, x9, x5, lsr #32
    8e6c:	8b0d0069 	add	x9, x3, x13
    8e70:	eb05017f 	cmp	x11, x5
    8e74:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    8e78:	8b058149 	add	x9, x10, x5, lsl #32
    8e7c:	8b458063 	add	x3, x3, x5, lsr #32
    8e80:	eb03003f 	cmp	x1, x3
    8e84:	54000063 	b.cc	8e90 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    8e88:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    8e8c:	54000082 	b.cs	8e9c <__modti3+0x1cc>  // b.hs, b.nlast
    8e90:	eb020129 	subs	x9, x9, x2
    8e94:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    8e98:	cb070063 	sub	x3, x3, x7
    8e9c:	eb090000 	subs	x0, x0, x9
    8ea0:	da030021 	sbc	x1, x1, x3
    8ea4:	9ac62400 	lsr	x0, x0, x6
    8ea8:	9ac82028 	lsl	x8, x1, x8
    8eac:	aa000100 	orr	x0, x8, x0
    8eb0:	9ac62421 	lsr	x1, x1, x6
    8eb4:	17ffffb4 	b	8d84 <__modti3+0xb4>
    8eb8:	b5000062 	cbnz	x2, 8ec4 <__modti3+0x1f4>
    8ebc:	d2800023 	mov	x3, #0x1                   	// #1
    8ec0:	9ac20862 	udiv	x2, x3, x2
    8ec4:	dac01048 	clz	x8, x2
    8ec8:	aa0803e5 	mov	x5, x8
    8ecc:	b5000668 	cbnz	x8, 8f98 <__modti3+0x2c8>
    8ed0:	cb020020 	sub	x0, x1, x2
    8ed4:	d360fc49 	lsr	x9, x2, #32
    8ed8:	92407c4a 	and	x10, x2, #0xffffffff
    8edc:	9ac90801 	udiv	x1, x0, x9
    8ee0:	9b098020 	msub	x0, x1, x9, x0
    8ee4:	9b0a7c21 	mul	x1, x1, x10
    8ee8:	93c78000 	extr	x0, x0, x7, #32
    8eec:	eb00003f 	cmp	x1, x0
    8ef0:	540000a9 	b.ls	8f04 <__modti3+0x234>  // b.plast
    8ef4:	ab000040 	adds	x0, x2, x0
    8ef8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8efc:	8b020003 	add	x3, x0, x2
    8f00:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8f04:	cb010001 	sub	x1, x0, x1
    8f08:	9ac90820 	udiv	x0, x1, x9
    8f0c:	9b098403 	msub	x3, x0, x9, x1
    8f10:	aa0703e1 	mov	x1, x7
    8f14:	9b0a7c00 	mul	x0, x0, x10
    8f18:	b3607c61 	bfi	x1, x3, #32, #32
    8f1c:	eb01001f 	cmp	x0, x1
    8f20:	540000a9 	b.ls	8f34 <__modti3+0x264>  // b.plast
    8f24:	ab010041 	adds	x1, x2, x1
    8f28:	8b020022 	add	x2, x1, x2
    8f2c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    8f30:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    8f34:	cb000020 	sub	x0, x1, x0
    8f38:	17ffff91 	b	8d7c <__modti3+0xac>
    8f3c:	eb0203e5 	negs	x5, x2
    8f40:	aa0003e7 	mov	x7, x0
    8f44:	da0303e8 	ngc	x8, x3
    8f48:	aa0503e2 	mov	x2, x5
    8f4c:	aa0803e3 	mov	x3, x8
    8f50:	aa0103e6 	mov	x6, x1
    8f54:	b4ffed48 	cbz	x8, 8cfc <__modti3+0x2c>
    8f58:	eb01011f 	cmp	x8, x1
    8f5c:	54fff148 	b.hi	8d84 <__modti3+0xb4>  // b.pmore
    8f60:	dac01109 	clz	x9, x8
    8f64:	2a0903e6 	mov	w6, w9
    8f68:	b5fff1c9 	cbnz	x9, 8da0 <__modti3+0xd0>
    8f6c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    8f70:	54000068 	b.hi	8f7c <__modti3+0x2ac>  // b.pmore
    8f74:	eb050007 	subs	x7, x0, x5
    8f78:	da080021 	sbc	x1, x1, x8
    8f7c:	aa0703e0 	mov	x0, x7
    8f80:	17ffff81 	b	8d84 <__modti3+0xb4>
    8f84:	ab000040 	adds	x0, x2, x0
    8f88:	8b020002 	add	x2, x0, x2
    8f8c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    8f90:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    8f94:	17ffff79 	b	8d78 <__modti3+0xa8>
    8f98:	9ac82042 	lsl	x2, x2, x8
    8f9c:	d2800803 	mov	x3, #0x40                  	// #64
    8fa0:	cb080063 	sub	x3, x3, x8
    8fa4:	d360fc49 	lsr	x9, x2, #32
    8fa8:	9ac82027 	lsl	x7, x1, x8
    8fac:	92407c4a 	and	x10, x2, #0xffffffff
    8fb0:	9ac32426 	lsr	x6, x1, x3
    8fb4:	9ac32403 	lsr	x3, x0, x3
    8fb8:	aa070063 	orr	x3, x3, x7
    8fbc:	9ac908c1 	udiv	x1, x6, x9
    8fc0:	9ac82007 	lsl	x7, x0, x8
    8fc4:	9b099820 	msub	x0, x1, x9, x6
    8fc8:	9b017d41 	mul	x1, x10, x1
    8fcc:	93c38000 	extr	x0, x0, x3, #32
    8fd0:	eb00003f 	cmp	x1, x0
    8fd4:	540000a9 	b.ls	8fe8 <__modti3+0x318>  // b.plast
    8fd8:	ab000040 	adds	x0, x2, x0
    8fdc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8fe0:	8b020006 	add	x6, x0, x2
    8fe4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    8fe8:	cb010000 	sub	x0, x0, x1
    8fec:	9ac90801 	udiv	x1, x0, x9
    8ff0:	9b098026 	msub	x6, x1, x9, x0
    8ff4:	aa0303e0 	mov	x0, x3
    8ff8:	9b017d41 	mul	x1, x10, x1
    8ffc:	b3607cc0 	bfi	x0, x6, #32, #32
    9000:	eb00003f 	cmp	x1, x0
    9004:	540000a9 	b.ls	9018 <__modti3+0x348>  // b.plast
    9008:	ab000040 	adds	x0, x2, x0
    900c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9010:	8b020003 	add	x3, x0, x2
    9014:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9018:	cb010000 	sub	x0, x0, x1
    901c:	17ffffb0 	b	8edc <__modti3+0x20c>
    9020:	d1000969 	sub	x9, x11, #0x2
    9024:	8b070021 	add	x1, x1, x7
    9028:	17ffff83 	b	8e34 <__modti3+0x164>
    902c:	d1000965 	sub	x5, x11, #0x2
    9030:	8b070063 	add	x3, x3, x7
    9034:	17ffff74 	b	8e04 <__modti3+0x134>
    9038:	d503201f 	nop
    903c:	d503201f 	nop

0000000000009040 <atexit>:
    9040:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9044:	f00000a2 	adrp	x2, 20000 <__data_start>
    9048:	d2800001 	mov	x1, #0x0                   	// #0
    904c:	910003fd 	mov	x29, sp
    9050:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9054:	f9400442 	ldr	x2, [x2, #8]
    9058:	17ffe5ca 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000905c <_fini>:
    905c:	d503201f 	nop
    9060:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9064:	910003fd 	mov	x29, sp
    9068:	a8c17bfd 	ldp	x29, x30, [sp], #16
    906c:	d65f03c0 	ret
