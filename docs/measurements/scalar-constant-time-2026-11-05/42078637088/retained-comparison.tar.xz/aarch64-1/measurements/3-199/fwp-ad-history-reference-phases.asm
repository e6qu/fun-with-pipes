
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-199/fwp-ad-history-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	b0000045 	adrp	x5, b000 <__divti3+0x190>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	912120a5 	add	x5, x5, #0x848
    2aa0:	b0000044 	adrp	x4, b000 <__divti3+0x190>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91214084 	add	x4, x4, #0x850
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9101c261 	add	x1, x19, #0x70
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10840>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9004420 	str	x0, [x1, #136]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <__divti3+0x190>
    2b34:	9130a000 	add	x0, x0, #0xc28
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	f0000022 	adrp	x2, 9000 <fwp_write+0x7a0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91214042 	add	x2, x2, #0x850
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c273 	add	x19, x19, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9437a60 	ldr	w0, [x19, #888]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	b0000040 	adrp	x0, b000 <__divti3+0x190>
    2c7c:	9130e000 	add	x0, x0, #0xc38
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	b0000040 	adrp	x0, b000 <__divti3+0x190>
    2c8c:	91336000 	add	x0, x0, #0xcd8
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	b0000040 	adrp	x0, b000 <__divti3+0x190>
    2ca4:	9132c000 	add	x0, x0, #0xcb0
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	b0000040 	adrp	x0, b000 <__divti3+0x190>
    2cb0:	91320000 	add	x0, x0, #0xc80
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	b0000040 	adrp	x0, b000 <__divti3+0x190>
    2cbc:	91316000 	add	x0, x0, #0xc58
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0xa70>
    2eb4:	910d0021 	add	x1, x1, #0x340
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3050:	91166000 	add	x0, x0, #0x598
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xa70>
    3118:	910c8021 	add	x1, x1, #0x320
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3150:	9116c000 	add	x0, x0, #0x5b0
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	90000042 	adrp	x2, b000 <__divti3+0x190>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	90000056 	adrp	x22, b000 <__divti3+0x190>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	b0000058 	adrp	x24, c000 <_IO_stdin_used+0xa70>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	9117e042 	add	x2, x2, #0x5f8
    31e0:	911942d6 	add	x22, x22, #0x650
    31e4:	9102a318 	add	x24, x24, #0xa8
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	90000059 	adrp	x25, b000 <__divti3+0x190>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	91192323 	add	x3, x25, #0x648
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	91198000 	add	x0, x0, #0x660
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    32c4:	9117c2a1 	add	x1, x21, #0x5f0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa10>
    32d8:	912780a5 	add	x5, x5, #0x9e0
    32dc:	9117c2a1 	add	x1, x21, #0x5f0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	9117c2b7 	add	x23, x21, #0x5f0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	9117c2b5 	add	x21, x21, #0x5f0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	9117c2b5 	add	x21, x21, #0x5f0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa10>
    3468:	912760a5 	add	x5, x5, #0x9d8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3570:	91166000 	add	x0, x0, #0x598
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	90000041 	adrp	x1, b000 <__divti3+0x190>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9119a021 	add	x1, x1, #0x668
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	90000041 	adrp	x1, b000 <__divti3+0x190>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	9119c021 	add	x1, x1, #0x670
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	90000041 	adrp	x1, b000 <__divti3+0x190>
    37e0:	9119e021 	add	x1, x1, #0x678
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffdf1 	bl	2ff0 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	90000042 	adrp	x2, b000 <__divti3+0x190>
    3838:	aa1303e3 	mov	x3, x19
    383c:	911a0042 	add	x2, x2, #0x680
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc2b 	bl	28f0 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc58 	bl	29b0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc66 	bl	29f0 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbb4 	bl	2730 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbd4 	bl	2820 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbb7 	bl	27d0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc0f 	bl	2940 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3950:	91166000 	add	x0, x0, #0x598
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc0a 	bl	2980 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc14 	bl	29b0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc22 	bl	29f0 <_Exit@plt>
    396c:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3970:	911a4000 	add	x0, x0, #0x690
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb82 	bl	27b0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3a08:	911ac000 	add	x0, x0, #0x6b0
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffb9c 	bl	2880 <__stack_chk_fail@plt>
    3a14:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3a18:	911b4000 	add	x0, x0, #0x6d0
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xa70>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc0d420 	ldr	q0, [x1, #848]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	9101c2b5 	add	x21, x21, #0x70
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f94046a2 	ldr	x2, [x21, #136]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb97 	bl	2940 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3b18:	911be000 	add	x0, x0, #0x6f8
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb57 	bl	2880 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	9350fc01 	asr	x1, x0, #16
    3b3c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b40:	d1000440 	sub	x0, x2, #0x1
    3b44:	9101c062 	add	x2, x3, #0x70
    3b48:	f9404842 	ldr	x2, [x2, #144]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9403863 	ldr	x3, [x3, #112]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3b88:	911ca000 	add	x0, x0, #0x728
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	90000044 	adrp	x4, b000 <__divti3+0x190>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	911de084 	add	x4, x4, #0x778
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffafe 	bl	27f0 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb57 	bl	2960 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb42 	bl	2920 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa8b 	bl	26d0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffac3 	bl	27d0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffab4 	bl	27d0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa6c 	bl	26d0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa78 	bl	2710 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb08 	bl	2960 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	90000044 	adrp	x4, b000 <__divti3+0x190>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	911e4084 	add	x4, x4, #0x790
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa88 	bl	27f0 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa77 	bl	27d0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffad7 	bl	2960 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	90000044 	adrp	x4, b000 <__divti3+0x190>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	911e0084 	add	x4, x4, #0x780
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa60 	bl	27f0 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa4a 	bl	27d0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa1e 	bl	27d0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa3a 	bl	2880 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    3fa8:	9117c042 	add	x2, x2, #0x5f0
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	90000041 	adrp	x1, b000 <__divti3+0x190>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	90000040 	adrp	x0, b000 <__divti3+0x190>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	911e6021 	add	x1, x1, #0x798
    4004:	911e8000 	add	x0, x0, #0x7a0
    4008:	97fffa02 	bl	2810 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa83 	bl	2a40 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa2d 	bl	2920 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa70 	bl	2a40 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9dd 	bl	2800 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	f0000022 	adrp	x2, b000 <__divti3+0x190>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	911f0042 	add	x2, x2, #0x7c0
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa00 	b	28f0 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e0 	bl	2880 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa10>
    410c:	9113c061 	add	x1, x3, #0x4f0
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    411c:	9117c262 	add	x2, x19, #0x5f0
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	90000042 	adrp	x2, c000 <_IO_stdin_used+0xa70>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa10>
    414c:	9114c021 	add	x1, x1, #0x530
    4150:	3dc0d843 	ldr	q3, [x2, #864]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa10>
    417c:	9113c063 	add	x3, x3, #0x4f0
    4180:	91164084 	add	x4, x4, #0x590
    4184:	9117c266 	add	x6, x19, #0x5f0
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9c5 	bl	2910 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	9117c275 	add	x21, x19, #0x5f0
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9af 	bl	2910 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	f0000020 	adrp	x0, b000 <__divti3+0x190>
    4268:	9121c000 	add	x0, x0, #0x870
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9e8 	bl	2a10 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	9117c273 	add	x19, x19, #0x5f0
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffb5c 	bl	3030 <fwp_heap_oom>

00000000000042c4 <caf61>:
    42c4:	900000e2 	adrp	x2, 20000 <__data_start>
    42c8:	9101c041 	add	x1, x2, #0x70
    42cc:	b9409820 	ldr	w0, [x1, #152]
    42d0:	34000060 	cbz	w0, 42dc <caf61+0x18>
    42d4:	f9405020 	ldr	x0, [x1, #160]
    42d8:	d65f03c0 	ret
    42dc:	b940a820 	ldr	w0, [x1, #168]
    42e0:	340000e0 	cbz	w0, 42fc <caf61+0x38>
    42e4:	f9405820 	ldr	x0, [x1, #176]
    42e8:	9101c042 	add	x2, x2, #0x70
    42ec:	52800021 	mov	w1, #0x1                   	// #1
    42f0:	b9009841 	str	w1, [x2, #152]
    42f4:	f9005040 	str	x0, [x2, #160]
    42f8:	d65f03c0 	ret
    42fc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4300:	52800024 	mov	w4, #0x1                   	// #1
    4304:	aa0303e0 	mov	x0, x3
    4308:	b900a824 	str	w4, [x1, #168]
    430c:	f9005823 	str	x3, [x1, #176]
    4310:	17fffff6 	b	42e8 <caf61+0x24>

0000000000004314 <fwp_wake_io>:
    4314:	900000e9 	adrp	x9, 20000 <__data_start>
    4318:	9101c122 	add	x2, x9, #0x70
    431c:	f9400001 	ldr	x1, [x0]
    4320:	5280000a 	mov	w10, #0x0                   	// #0
    4324:	f9403c46 	ldr	x6, [x2, #120]
    4328:	52800008 	mov	w8, #0x0                   	// #0
    432c:	4f000400 	movi	v0.4s, #0x0
    4330:	52800027 	mov	w7, #0x1                   	// #1
    4334:	aa0103e2 	mov	x2, x1
    4338:	b4000321 	cbz	x1, 439c <fwp_wake_io+0x88>
    433c:	f9408c25 	ldr	x5, [x1, #280]
    4340:	39015c27 	strb	w7, [x1, #87]
    4344:	b4000165 	cbz	x5, 4370 <fwp_wake_io+0x5c>
    4348:	a9520c24 	ldp	x4, x3, [x1, #288]
    434c:	b4000364 	cbz	x4, 43b8 <fwp_wake_io+0xa4>
    4350:	f9009483 	str	x3, [x4, #296]
    4354:	f9409423 	ldr	x3, [x1, #296]
    4358:	b4000043 	cbz	x3, 4360 <fwp_wake_io+0x4c>
    435c:	f9009064 	str	x4, [x3, #288]
    4360:	91080023 	add	x3, x1, #0x200
    4364:	f900943f 	str	xzr, [x1, #296]
    4368:	3c918060 	stur	q0, [x3, #-232]
    436c:	f9400001 	ldr	x1, [x0]
    4370:	f9402843 	ldr	x3, [x2, #80]
    4374:	f2001c7f 	tst	x3, #0xff000000ff
    4378:	54fffde1 	b.ne	4334 <fwp_wake_io+0x20>  // b.any
    437c:	39015047 	strb	w7, [x2, #84]
    4380:	f900805f 	str	xzr, [x2, #256]
    4384:	b40001e6 	cbz	x6, 43c0 <fwp_wake_io+0xac>
    4388:	f90080c2 	str	x2, [x6, #256]
    438c:	aa0203e6 	mov	x6, x2
    4390:	52800028 	mov	w8, #0x1                   	// #1
    4394:	aa0103e2 	mov	x2, x1
    4398:	b5fffd21 	cbnz	x1, 433c <fwp_wake_io+0x28>
    439c:	3400006a 	cbz	w10, 43a8 <fwp_wake_io+0x94>
    43a0:	9101c120 	add	x0, x9, #0x70
    43a4:	f900400b 	str	x11, [x0, #128]
    43a8:	34000068 	cbz	w8, 43b4 <fwp_wake_io+0xa0>
    43ac:	9101c129 	add	x9, x9, #0x70
    43b0:	f9003d26 	str	x6, [x9, #120]
    43b4:	d65f03c0 	ret
    43b8:	f90000a3 	str	x3, [x5]
    43bc:	17ffffe7 	b	4358 <fwp_wake_io+0x44>
    43c0:	aa0203eb 	mov	x11, x2
    43c4:	5280002a 	mov	w10, #0x1                   	// #1
    43c8:	17fffff1 	b	438c <fwp_wake_io+0x78>
    43cc:	d503201f 	nop

00000000000043d0 <fwp_tape_buffers_release>:
    43d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d4:	910003fd 	mov	x29, sp
    43d8:	a90153f3 	stp	x19, x20, [sp, #16]
    43dc:	aa0003f3 	mov	x19, x0
    43e0:	f9401400 	ldr	x0, [x0, #40]
    43e4:	b7f80760 	tbnz	x0, #63, 44d0 <fwp_tape_buffers_release+0x100>
    43e8:	f9401a61 	ldr	x1, [x19, #48]
    43ec:	b7f80301 	tbnz	x1, #63, 444c <fwp_tape_buffers_release+0x7c>
    43f0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    43f4:	eb02001f 	cmp	x0, x2
    43f8:	540002a8 	b.hi	444c <fwp_tape_buffers_release+0x7c>  // b.pmore
    43fc:	8b000400 	add	x0, x0, x0, lsl #1
    4400:	d2a00102 	mov	x2, #0x80000               	// #524288
    4404:	d37df000 	lsl	x0, x0, #3
    4408:	cb000042 	sub	x2, x2, x0
    440c:	eb420c3f 	cmp	x1, x2, lsr #3
    4410:	540001e8 	b.hi	444c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4414:	8b010c14 	add	x20, x0, x1, lsl #3
    4418:	f0000020 	adrp	x0, b000 <__divti3+0x190>
    441c:	91220000 	add	x0, x0, #0x880
    4420:	97fff97c 	bl	2a10 <getenv@plt>
    4424:	b4000240 	cbz	x0, 446c <fwp_tape_buffers_release+0x9c>
    4428:	39400001 	ldrb	w1, [x0]
    442c:	7100c03f 	cmp	w1, #0x30
    4430:	540001e1 	b.ne	446c <fwp_tape_buffers_release+0x9c>  // b.any
    4434:	39400400 	ldrb	w0, [x0, #1]
    4438:	350001a0 	cbnz	w0, 446c <fwp_tape_buffers_release+0x9c>
    443c:	aa1303e0 	mov	x0, x19
    4440:	a94153f3 	ldp	x19, x20, [sp, #16]
    4444:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4448:	17fffc0e 	b	3480 <fwp_tape_buffers_dispose>
    444c:	f0000020 	adrp	x0, b000 <__divti3+0x190>
    4450:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4454:	91220000 	add	x0, x0, #0x880
    4458:	97fff96e 	bl	2a10 <getenv@plt>
    445c:	b4ffff00 	cbz	x0, 443c <fwp_tape_buffers_release+0x6c>
    4460:	39400001 	ldrb	w1, [x0]
    4464:	7100c03f 	cmp	w1, #0x30
    4468:	54fffe60 	b.eq	4434 <fwp_tape_buffers_release+0x64>  // b.none
    446c:	d1000681 	sub	x1, x20, #0x1
    4470:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4474:	eb00003f 	cmp	x1, x0
    4478:	54fffe28 	b.hi	443c <fwp_tape_buffers_release+0x6c>  // b.pmore
    447c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4480:	900000f6 	adrp	x22, 20000 <__data_start>
    4484:	9101c2d6 	add	x22, x22, #0x70
    4488:	9102e2d5 	add	x21, x22, #0xb8
    448c:	aa1503e0 	mov	x0, x21
    4490:	97fffbfc 	bl	3480 <fwp_tape_buffers_dispose>
    4494:	ad400a61 	ldp	q1, q2, [x19]
    4498:	f9007ad4 	str	x20, [x22, #240]
    449c:	4f000400 	movi	v0.4s, #0x0
    44a0:	ad000aa1 	stp	q1, q2, [x21]
    44a4:	3dc00a61 	ldr	q1, [x19, #32]
    44a8:	3d800aa1 	str	q1, [x21, #32]
    44ac:	f9401a60 	ldr	x0, [x19, #48]
    44b0:	f9001aa0 	str	x0, [x21, #48]
    44b4:	f9001a7f 	str	xzr, [x19, #48]
    44b8:	ad000260 	stp	q0, q0, [x19]
    44bc:	3d800a60 	str	q0, [x19, #32]
    44c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44cc:	d65f03c0 	ret
    44d0:	f0000020 	adrp	x0, b000 <__divti3+0x190>
    44d4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    44d8:	91220000 	add	x0, x0, #0x880
    44dc:	97fff94d 	bl	2a10 <getenv@plt>
    44e0:	b5fffa40 	cbnz	x0, 4428 <fwp_tape_buffers_release+0x58>
    44e4:	17ffffd6 	b	443c <fwp_tape_buffers_release+0x6c>
    44e8:	d503201f 	nop
    44ec:	d503201f 	nop

00000000000044f0 <fwp_poll_events>:
    44f0:	d10103ff 	sub	sp, sp, #0x40
    44f4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    44f8:	f947f400 	ldr	x0, [x0, #4072]
    44fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4500:	910083fd 	add	x29, sp, #0x20
    4504:	a90353f3 	stp	x19, x20, [sp, #48]
    4508:	900000f4 	adrp	x20, 20000 <__data_start>
    450c:	f9400001 	ldr	x1, [x0]
    4510:	f9000fe1 	str	x1, [sp, #24]
    4514:	d2800001 	mov	x1, #0x0                   	// #0
    4518:	97fffd1a 	bl	3980 <fwp_now_ns>
    451c:	9101c281 	add	x1, x20, #0x70
    4520:	f9407c33 	ldr	x19, [x1, #248]
    4524:	b4000e93 	cbz	x19, 46f4 <fwp_poll_events+0x204>
    4528:	aa1303e1 	mov	x1, x19
    452c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4530:	14000005 	b	4544 <fwp_poll_events+0x54>
    4534:	f9408821 	ldr	x1, [x1, #272]
    4538:	eb03005f 	cmp	x2, x3
    453c:	9a83d042 	csel	x2, x2, x3, le
    4540:	b40000c1 	cbz	x1, 4558 <fwp_poll_events+0x68>
    4544:	f9403423 	ldr	x3, [x1, #104]
    4548:	b6ffff62 	tbz	x2, #63, 4534 <fwp_poll_events+0x44>
    454c:	f9408821 	ldr	x1, [x1, #272]
    4550:	aa0303e2 	mov	x2, x3
    4554:	b5ffff81 	cbnz	x1, 4544 <fwp_poll_events+0x54>
    4558:	b7f80ce2 	tbnz	x2, #63, 46f4 <fwp_poll_events+0x204>
    455c:	cb000042 	sub	x2, x2, x0
    4560:	f100005f 	cmp	x2, #0x0
    4564:	540005cd 	b.le	461c <fwp_poll_events+0x12c>
    4568:	d2869b60 	mov	x0, #0x34db                	// #13531
    456c:	d2884801 	mov	x1, #0x4240                	// #16960
    4570:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4574:	f2a001e1 	movk	x1, #0xf, lsl #16
    4578:	f2dbd040 	movk	x0, #0xde82, lsl #32
    457c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4580:	f2e86360 	movk	x0, #0x431b, lsl #48
    4584:	9b407c40 	smulh	x0, x2, x0
    4588:	9352fc00 	asr	x0, x0, #18
    458c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4590:	9b018802 	msub	x2, x0, x1, x2
    4594:	f100005f 	cmp	x2, #0x0
    4598:	9a800400 	cinc	x0, x0, ne	// ne = any
    459c:	eb03001f 	cmp	x0, x3
    45a0:	54000a0c 	b.gt	46e0 <fwp_poll_events+0x1f0>
    45a4:	340003c0 	cbz	w0, 461c <fwp_poll_events+0x12c>
    45a8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    45ac:	52807d04 	mov	w4, #0x3e8                 	// #1000
    45b0:	72a20c42 	movk	w2, #0x1062, lsl #16
    45b4:	9ba27c02 	umull	x2, w0, w2
    45b8:	d366fc43 	lsr	x3, x2, #38
    45bc:	aa0303e2 	mov	x2, x3
    45c0:	1b048063 	msub	w3, w3, w4, w0
    45c4:	9b217c63 	smull	x3, w3, w1
    45c8:	d2800001 	mov	x1, #0x0                   	// #0
    45cc:	910023e0 	add	x0, sp, #0x8
    45d0:	a9008fe2 	stp	x2, x3, [sp, #8]
    45d4:	97fff8df 	bl	2950 <nanosleep@plt>
    45d8:	9101c280 	add	x0, x20, #0x70
    45dc:	f9407c13 	ldr	x19, [x0, #248]
    45e0:	97fffce8 	bl	3980 <fwp_now_ns>
    45e4:	aa0003e6 	mov	x6, x0
    45e8:	b50001f3 	cbnz	x19, 4624 <fwp_poll_events+0x134>
    45ec:	d503201f 	nop
    45f0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45f4:	f947f400 	ldr	x0, [x0, #4072]
    45f8:	f9400fe2 	ldr	x2, [sp, #24]
    45fc:	f9400001 	ldr	x1, [x0]
    4600:	eb010042 	subs	x2, x2, x1
    4604:	d2800001 	mov	x1, #0x0                   	// #0
    4608:	540008c1 	b.ne	4720 <fwp_poll_events+0x230>  // b.any
    460c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4610:	a94353f3 	ldp	x19, x20, [sp, #48]
    4614:	910103ff 	add	sp, sp, #0x40
    4618:	d65f03c0 	ret
    461c:	97fffcd9 	bl	3980 <fwp_now_ns>
    4620:	aa0003e6 	mov	x6, x0
    4624:	4f000400 	movi	v0.4s, #0x0
    4628:	9101c288 	add	x8, x20, #0x70
    462c:	52800027 	mov	w7, #0x1                   	// #1
    4630:	f9403661 	ldr	x1, [x19, #104]
    4634:	aa1303e5 	mov	x5, x19
    4638:	f9408a73 	ldr	x19, [x19, #272]
    463c:	eb06003f 	cmp	x1, x6
    4640:	5400032c 	b.gt	46a4 <fwp_poll_events+0x1b4>
    4644:	394154a0 	ldrb	w0, [x5, #85]
    4648:	36000120 	tbz	w0, #0, 466c <fwp_poll_events+0x17c>
    464c:	f94084a0 	ldr	x0, [x5, #264]
    4650:	b40003c0 	cbz	x0, 46c8 <fwp_poll_events+0x1d8>
    4654:	f9008813 	str	x19, [x0, #272]
    4658:	b4000053 	cbz	x19, 4660 <fwp_poll_events+0x170>
    465c:	f9008660 	str	x0, [x19, #264]
    4660:	910800a0 	add	x0, x5, #0x200
    4664:	390154bf 	strb	wzr, [x5, #85]
    4668:	3c908000 	stur	q0, [x0, #-248]
    466c:	f94030a0 	ldr	x0, [x5, #96]
    4670:	390158a7 	strb	w7, [x5, #86]
    4674:	f100001f 	cmp	x0, #0x0
    4678:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    467c:	5400018d 	b.le	46ac <fwp_poll_events+0x1bc>
    4680:	f94028a0 	ldr	x0, [x5, #80]
    4684:	f2001c1f 	tst	x0, #0xff000000ff
    4688:	540000e1 	b.ne	46a4 <fwp_poll_events+0x1b4>  // b.any
    468c:	f9403d00 	ldr	x0, [x8, #120]
    4690:	390150a7 	strb	w7, [x5, #84]
    4694:	f90080bf 	str	xzr, [x5, #256]
    4698:	b40001e0 	cbz	x0, 46d4 <fwp_poll_events+0x1e4>
    469c:	f9003d05 	str	x5, [x8, #120]
    46a0:	f9008005 	str	x5, [x0, #256]
    46a4:	b5fffc73 	cbnz	x19, 4630 <fwp_poll_events+0x140>
    46a8:	17ffffd2 	b	45f0 <fwp_poll_events+0x100>
    46ac:	394144a0 	ldrb	w0, [x5, #81]
    46b0:	3707fe80 	tbnz	w0, #0, 4680 <fwp_poll_events+0x190>
    46b4:	394140a0 	ldrb	w0, [x5, #80]
    46b8:	3707fe40 	tbnz	w0, #0, 4680 <fwp_poll_events+0x190>
    46bc:	aa0503e0 	mov	x0, x5
    46c0:	97fffc0c 	bl	36f0 <fwp_cancel_tree.part.0>
    46c4:	17ffffef 	b	4680 <fwp_poll_events+0x190>
    46c8:	9101c281 	add	x1, x20, #0x70
    46cc:	f9007c33 	str	x19, [x1, #248]
    46d0:	17ffffe2 	b	4658 <fwp_poll_events+0x168>
    46d4:	f9003d05 	str	x5, [x8, #120]
    46d8:	f9004105 	str	x5, [x8, #128]
    46dc:	17fffff2 	b	46a4 <fwp_poll_events+0x1b4>
    46e0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    46e4:	d2989362 	mov	x2, #0xc49b                	// #50331
    46e8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    46ec:	f2a00402 	movk	x2, #0x20, lsl #16
    46f0:	17ffffb6 	b	45c8 <fwp_poll_events+0xd8>
    46f4:	97fffa3f 	bl	2ff0 <fwp_flush>
    46f8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    46fc:	f947e863 	ldr	x3, [x3, #4048]
    4700:	d2800562 	mov	x2, #0x2b                  	// #43
    4704:	d2800021 	mov	x1, #0x1                   	// #1
    4708:	f0000020 	adrp	x0, b000 <__divti3+0x190>
    470c:	91226000 	add	x0, x0, #0x898
    4710:	f9400063 	ldr	x3, [x3]
    4714:	97fff89b 	bl	2980 <fwrite@plt>
    4718:	52800ca0 	mov	w0, #0x65                  	// #101
    471c:	97fff805 	bl	2730 <exit@plt>
    4720:	97fff858 	bl	2880 <__stack_chk_fail@plt>

0000000000004724 <fwp_rc_wide_dup>:
    4724:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4728:	910003fd 	mov	x29, sp
    472c:	a90153f3 	stp	x19, x20, [sp, #16]
    4730:	aa0003f3 	mov	x19, x0
    4734:	ca404400 	eor	x0, x0, x0, lsr #17
    4738:	f90013f5 	str	x21, [sp, #32]
    473c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4740:	ca402400 	eor	x0, x0, x0, lsr #9
    4744:	9117c2a2 	add	x2, x21, #0x5f0
    4748:	92401c00 	and	x0, x0, #0xff
    474c:	910a2403 	add	x3, x0, #0x289
    4750:	8b000c40 	add	x0, x2, x0, lsl #3
    4754:	8b030c54 	add	x20, x2, x3, lsl #3
    4758:	f94a2401 	ldr	x1, [x0, #5192]
    475c:	b50000a1 	cbnz	x1, 4770 <fwp_rc_wide_dup+0x4c>
    4760:	1400002d 	b	4814 <fwp_rc_wide_dup+0xf0>
    4764:	91004034 	add	x20, x1, #0x10
    4768:	f9400821 	ldr	x1, [x1, #16]
    476c:	b4000241 	cbz	x1, 47b4 <fwp_rc_wide_dup+0x90>
    4770:	f9400022 	ldr	x2, [x1]
    4774:	eb02027f 	cmp	x19, x2
    4778:	54ffff61 	b.ne	4764 <fwp_rc_wide_dup+0x40>  // b.any
    477c:	f9400281 	ldr	x1, [x20]
    4780:	39400260 	ldrb	w0, [x19]
    4784:	7103f81f 	cmp	w0, #0xfe
    4788:	54000220 	b.eq	47cc <fwp_rc_wide_dup+0xa8>  // b.none
    478c:	b40001a1 	cbz	x1, 47c0 <fwp_rc_wide_dup+0x9c>
    4790:	f9400420 	ldr	x0, [x1, #8]
    4794:	b100041f 	cmn	x0, #0x1
    4798:	540004a0 	b.eq	482c <fwp_rc_wide_dup+0x108>  // b.none
    479c:	91000400 	add	x0, x0, #0x1
    47a0:	f9000420 	str	x0, [x1, #8]
    47a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47a8:	f94013f5 	ldr	x21, [sp, #32]
    47ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47b0:	d65f03c0 	ret
    47b4:	39400260 	ldrb	w0, [x19]
    47b8:	7103f81f 	cmp	w0, #0xfe
    47bc:	540000a0 	b.eq	47d0 <fwp_rc_wide_dup+0xac>  // b.none
    47c0:	f0000020 	adrp	x0, b000 <__divti3+0x190>
    47c4:	9123c000 	add	x0, x0, #0x8f0
    47c8:	97fffc0e 	bl	3800 <fwp_trap>
    47cc:	b5000281 	cbnz	x1, 481c <fwp_rc_wide_dup+0xf8>
    47d0:	d2800300 	mov	x0, #0x18                  	// #24
    47d4:	97fff813 	bl	2820 <malloc@plt>
    47d8:	b4000280 	cbz	x0, 4828 <fwp_rc_wide_dup+0x104>
    47dc:	d2801fe1 	mov	x1, #0xff                  	// #255
    47e0:	a9000413 	stp	x19, x1, [x0]
    47e4:	9117c2b5 	add	x21, x21, #0x5f0
    47e8:	f900081f 	str	xzr, [x0, #16]
    47ec:	12800001 	mov	w1, #0xffffffff            	// #-1
    47f0:	f9000280 	str	x0, [x20]
    47f4:	39000261 	strb	w1, [x19]
    47f8:	f94e26a0 	ldr	x0, [x21, #7240]
    47fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4800:	91000400 	add	x0, x0, #0x1
    4804:	f90e26a0 	str	x0, [x21, #7240]
    4808:	f94013f5 	ldr	x21, [sp, #32]
    480c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4810:	d65f03c0 	ret
    4814:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4818:	17ffffda 	b	4780 <fwp_rc_wide_dup+0x5c>
    481c:	f0000020 	adrp	x0, b000 <__divti3+0x190>
    4820:	91232000 	add	x0, x0, #0x8c8
    4824:	97fffbf7 	bl	3800 <fwp_trap>
    4828:	97fffa02 	bl	3030 <fwp_heap_oom>
    482c:	f0000020 	adrp	x0, b000 <__divti3+0x190>
    4830:	91246000 	add	x0, x0, #0x918
    4834:	97fffbf3 	bl	3800 <fwp_trap>
    4838:	d503201f 	nop
    483c:	d503201f 	nop

0000000000004840 <fwp_rc_forget_slot>:
    4840:	aa0003e1 	mov	x1, x0
    4844:	39400000 	ldrb	w0, [x0]
    4848:	7103fc1f 	cmp	w0, #0xff
    484c:	54000040 	b.eq	4854 <fwp_rc_forget_slot+0x14>  // b.none
    4850:	d65f03c0 	ret
    4854:	ca414420 	eor	x0, x1, x1, lsr #17
    4858:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    485c:	ca402400 	eor	x0, x0, x0, lsr #9
    4860:	910003fd 	mov	x29, sp
    4864:	92401c00 	and	x0, x0, #0xff
    4868:	f9000bf3 	str	x19, [sp, #16]
    486c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    4870:	9117c262 	add	x2, x19, #0x5f0
    4874:	910a2403 	add	x3, x0, #0x289
    4878:	8b000c40 	add	x0, x2, x0, lsl #3
    487c:	8b030c43 	add	x3, x2, x3, lsl #3
    4880:	f94a2400 	ldr	x0, [x0, #5192]
    4884:	b50000a0 	cbnz	x0, 4898 <fwp_rc_forget_slot+0x58>
    4888:	14000011 	b	48cc <fwp_rc_forget_slot+0x8c>
    488c:	91004003 	add	x3, x0, #0x10
    4890:	f9400800 	ldr	x0, [x0, #16]
    4894:	b40001c0 	cbz	x0, 48cc <fwp_rc_forget_slot+0x8c>
    4898:	f9400002 	ldr	x2, [x0]
    489c:	eb02003f 	cmp	x1, x2
    48a0:	54ffff61 	b.ne	488c <fwp_rc_forget_slot+0x4c>  // b.any
    48a4:	f9400801 	ldr	x1, [x0, #16]
    48a8:	9117c273 	add	x19, x19, #0x5f0
    48ac:	f9000061 	str	x1, [x3]
    48b0:	97fff824 	bl	2940 <free@plt>
    48b4:	f94e2660 	ldr	x0, [x19, #7240]
    48b8:	d1000400 	sub	x0, x0, #0x1
    48bc:	f90e2660 	str	x0, [x19, #7240]
    48c0:	f9400bf3 	ldr	x19, [sp, #16]
    48c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48c8:	d65f03c0 	ret
    48cc:	f0000020 	adrp	x0, b000 <__divti3+0x190>
    48d0:	9123c000 	add	x0, x0, #0x8f0
    48d4:	97fffbcb 	bl	3800 <fwp_trap>
    48d8:	d503201f 	nop
    48dc:	d503201f 	nop

00000000000048e0 <fwp_rc_prepare_chunk>:
    48e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48e4:	910003fd 	mov	x29, sp
    48e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    48ec:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xbf0>
    48f0:	9117c2c2 	add	x2, x22, #0x5f0
    48f4:	b9401c03 	ldr	w3, [x0, #28]
    48f8:	aa0103f5 	mov	x21, x1
    48fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4900:	aa0003f4 	mov	x20, x0
    4904:	f94e2440 	ldr	x0, [x2, #7240]
    4908:	b4000440 	cbz	x0, 4990 <fwp_rc_prepare_chunk+0xb0>
    490c:	d2800013 	mov	x19, #0x0                   	// #0
    4910:	35000203 	cbnz	w3, 4950 <fwp_rc_prepare_chunk+0x70>
    4914:	b4000361 	cbz	x1, 4980 <fwp_rc_prepare_chunk+0xa0>
    4918:	f9401280 	ldr	x0, [x20, #32]
    491c:	97fff809 	bl	2940 <free@plt>
    4920:	aa1503e0 	mov	x0, x21
    4924:	d2800021 	mov	x1, #0x1                   	// #1
    4928:	97fff7ce 	bl	2860 <calloc@plt>
    492c:	f9001280 	str	x0, [x20, #32]
    4930:	b5000460 	cbnz	x0, 49bc <fwp_rc_prepare_chunk+0xdc>
    4934:	97fff9bf 	bl	3030 <fwp_heap_oom>
    4938:	97ffffc2 	bl	4840 <fwp_rc_forget_slot>
    493c:	91000673 	add	x19, x19, #0x1
    4940:	b9401e83 	ldr	w3, [x20, #28]
    4944:	eb13007f 	cmp	x3, x19
    4948:	54000169 	b.ls	4974 <fwp_rc_prepare_chunk+0x94>  // b.plast
    494c:	d503201f 	nop
    4950:	f9401283 	ldr	x3, [x20, #32]
    4954:	8b130060 	add	x0, x3, x19
    4958:	38736863 	ldrb	w3, [x3, x19]
    495c:	7103fc7f 	cmp	w3, #0xff
    4960:	54fffec0 	b.eq	4938 <fwp_rc_prepare_chunk+0x58>  // b.none
    4964:	b9401e83 	ldr	w3, [x20, #28]
    4968:	91000673 	add	x19, x19, #0x1
    496c:	eb13007f 	cmp	x3, x19
    4970:	54ffff08 	b.hi	4950 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4974:	eb0302bf 	cmp	x21, x3
    4978:	54000121 	b.ne	499c <fwp_rc_prepare_chunk+0xbc>  // b.any
    497c:	b5000335 	cbnz	x21, 49e0 <fwp_rc_prepare_chunk+0x100>
    4980:	a94153f3 	ldp	x19, x20, [sp, #16]
    4984:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4988:	a8c37bfd 	ldp	x29, x30, [sp], #48
    498c:	d65f03c0 	ret
    4990:	2a0303e3 	mov	w3, w3
    4994:	eb0302bf 	cmp	x21, x3
    4998:	54ffff20 	b.eq	497c <fwp_rc_prepare_chunk+0x9c>  // b.none
    499c:	9117c2c2 	add	x2, x22, #0x5f0
    49a0:	f9401280 	ldr	x0, [x20, #32]
    49a4:	f94e2841 	ldr	x1, [x2, #7248]
    49a8:	cb030021 	sub	x1, x1, x3
    49ac:	f90e2841 	str	x1, [x2, #7248]
    49b0:	97fff7e4 	bl	2940 <free@plt>
    49b4:	b5fffb75 	cbnz	x21, 4920 <fwp_rc_prepare_chunk+0x40>
    49b8:	f900129f 	str	xzr, [x20, #32]
    49bc:	9117c2d6 	add	x22, x22, #0x5f0
    49c0:	f94e2ac0 	ldr	x0, [x22, #7248]
    49c4:	b9001e95 	str	w21, [x20, #28]
    49c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49cc:	8b150000 	add	x0, x0, x21
    49d0:	f90e2ac0 	str	x0, [x22, #7248]
    49d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49dc:	d65f03c0 	ret
    49e0:	f9401280 	ldr	x0, [x20, #32]
    49e4:	aa1503e2 	mov	x2, x21
    49e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49ec:	52800001 	mov	w1, #0x0                   	// #0
    49f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49f8:	17fff796 	b	2850 <memset@plt>
    49fc:	d503201f 	nop

0000000000004a00 <fwp_heap_refill>:
    4a00:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a04:	910003fd 	mov	x29, sp
    4a08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a0c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4a10:	9117c2b5 	add	x21, x21, #0x5f0
    4a14:	aa0003f6 	mov	x22, x0
    4a18:	d2800020 	mov	x0, #0x1                   	// #1
    4a1c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a20:	a90363f7 	stp	x23, x24, [sp, #48]
    4a24:	2a0103f7 	mov	w23, w1
    4a28:	2a0203f8 	mov	w24, w2
    4a2c:	97fffa21 	bl	32b0 <fwp_heap_chunks>
    4a30:	aa0003f3 	mov	x19, x0
    4a34:	f949fea2 	ldr	x2, [x21, #5112]
    4a38:	8b000800 	add	x0, x0, x0, lsl #2
    4a3c:	2a1703e1 	mov	w1, w23
    4a40:	52800025 	mov	w5, #0x1                   	// #1
    4a44:	d37df000 	lsl	x0, x0, #3
    4a48:	910f0021 	add	x1, x1, #0x3c0
    4a4c:	8b000054 	add	x20, x2, x0
    4a50:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a54:	52a00024 	mov	w4, #0x10000               	// #65536
    4a58:	38206845 	strb	w5, [x2, x0]
    4a5c:	aa1403e0 	mov	x0, x20
    4a60:	39000698 	strb	w24, [x20, #1]
    4a64:	39000a97 	strb	w23, [x20, #2]
    4a68:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a6c:	b9000681 	str	w1, [x20, #4]
    4a70:	2a0103e5 	mov	w5, w1
    4a74:	8b0300a2 	add	x2, x5, x3
    4a78:	1ac10881 	udiv	w1, w4, w1
    4a7c:	9ac50842 	udiv	x2, x2, x5
    4a80:	b9000a81 	str	w1, [x20, #8]
    4a84:	92404021 	and	x1, x1, #0x1ffff
    4a88:	b9001a82 	str	w2, [x20, #24]
    4a8c:	97ffff95 	bl	48e0 <fwp_rc_prepare_chunk>
    4a90:	f949daa0 	ldr	x0, [x21, #5040]
    4a94:	29408a81 	ldp	w1, w2, [x20, #4]
    4a98:	8b134000 	add	x0, x0, x19, lsl #16
    4a9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4aa0:	8b214003 	add	x3, x0, w1, uxtw
    4aa4:	9ba20021 	umaddl	x1, w1, w2, x0
    4aa8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4aac:	a90086c3 	stp	x3, x1, [x22, #8]
    4ab0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ab4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ab8:	d65f03c0 	ret
    4abc:	d503201f 	nop

0000000000004ac0 <fwp_mem_free>:
    4ac0:	b40003c0 	cbz	x0, 4b38 <fwp_mem_free+0x78>
    4ac4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4ac8:	910003fd 	mov	x29, sp
    4acc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ad0:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4ad4:	9117c2a1 	add	x1, x21, #0x5f0
    4ad8:	a90153f3 	stp	x19, x20, [sp, #16]
    4adc:	aa0003f3 	mov	x19, x0
    4ae0:	f949d823 	ldr	x3, [x1, #5040]
    4ae4:	f949ec22 	ldr	x2, [x1, #5080]
    4ae8:	cb030000 	sub	x0, x0, x3
    4aec:	eb02401f 	cmp	x0, x2, lsl #16
    4af0:	540001c2 	b.cs	4b28 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4af4:	d350fc16 	lsr	x22, x0, #16
    4af8:	a90363f7 	stp	x23, x24, [sp, #48]
    4afc:	f949fc22 	ldr	x2, [x1, #5112]
    4b00:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b04:	d37df294 	lsl	x20, x20, #3
    4b08:	ab140057 	adds	x23, x2, x20
    4b0c:	540000c0 	b.eq	4b24 <fwp_mem_free+0x64>  // b.none
    4b10:	38746842 	ldrb	w2, [x2, x20]
    4b14:	7100045f 	cmp	w2, #0x1
    4b18:	54000120 	b.eq	4b3c <fwp_mem_free+0x7c>  // b.none
    4b1c:	7100085f 	cmp	w2, #0x2
    4b20:	540005e0 	b.eq	4bdc <fwp_mem_free+0x11c>  // b.none
    4b24:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b30:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b34:	d65f03c0 	ret
    4b38:	d65f03c0 	ret
    4b3c:	f94012f8 	ldr	x24, [x23, #32]
    4b40:	b94006e1 	ldr	w1, [x23, #4]
    4b44:	f90023f9 	str	x25, [sp, #64]
    4b48:	2a0103e2 	mov	w2, w1
    4b4c:	394006f9 	ldrb	w25, [x23, #1]
    4b50:	39400af4 	ldrb	w20, [x23, #2]
    4b54:	b4000158 	cbz	x24, 4b7c <fwp_mem_free+0xbc>
    4b58:	92403e76 	and	x22, x19, #0xffff
    4b5c:	9ac20ad6 	udiv	x22, x22, x2
    4b60:	38766b01 	ldrb	w1, [x24, x22]
    4b64:	8b160300 	add	x0, x24, x22
    4b68:	7103fc3f 	cmp	w1, #0xff
    4b6c:	54000980 	b.eq	4c9c <fwp_mem_free+0x1dc>  // b.none
    4b70:	38366b1f 	strb	wzr, [x24, x22]
    4b74:	b94006e1 	ldr	w1, [x23, #4]
    4b78:	2a0103e2 	mov	w2, w1
    4b7c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4b80:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4b84:	cb390000 	sub	x0, x0, w25, uxtb
    4b88:	8b340074 	add	x20, x3, w20, uxtb
    4b8c:	9117c2b5 	add	x21, x21, #0x5f0
    4b90:	1e630021 	ucvtf	d1, w1
    4b94:	d37ae400 	lsl	x0, x0, #6
    4b98:	8b140c14 	add	x20, x0, x20, lsl #3
    4b9c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ba0:	f8746aa0 	ldr	x0, [x21, x20]
    4ba4:	f94023f9 	ldr	x25, [sp, #64]
    4ba8:	aa2003e0 	mvn	x0, x0
    4bac:	fd4a22a0 	ldr	d0, [x21, #5184]
    4bb0:	f9000260 	str	x0, [x19]
    4bb4:	f8346ab3 	str	x19, [x21, x20]
    4bb8:	f94a12a0 	ldr	x0, [x21, #5152]
    4bbc:	1e612800 	fadd	d0, d0, d1
    4bc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bc4:	cb020000 	sub	x0, x0, x2
    4bc8:	f90a12a0 	str	x0, [x21, #5152]
    4bcc:	fd0a22a0 	str	d0, [x21, #5184]
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4bd8:	d65f03c0 	ret
    4bdc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4be0:	8b000063 	add	x3, x3, x0
    4be4:	eb03027f 	cmp	x19, x3
    4be8:	54fff9e1 	b.ne	4b24 <fwp_mem_free+0x64>  // b.any
    4bec:	fd400ae1 	ldr	d1, [x23, #16]
    4bf0:	fd4a2020 	ldr	d0, [x1, #5184]
    4bf4:	f9400ae0 	ldr	x0, [x23, #16]
    4bf8:	7e61d821 	ucvtf	d1, d1
    4bfc:	f94a1022 	ldr	x2, [x1, #5152]
    4c00:	f94012f3 	ldr	x19, [x23, #32]
    4c04:	1e612800 	fadd	d0, d0, d1
    4c08:	cb000042 	sub	x2, x2, x0
    4c0c:	f90a1022 	str	x2, [x1, #5152]
    4c10:	fd0a2020 	str	d0, [x1, #5184]
    4c14:	b40000b3 	cbz	x19, 4c28 <fwp_mem_free+0x168>
    4c18:	39400260 	ldrb	w0, [x19]
    4c1c:	7103fc1f 	cmp	w0, #0xff
    4c20:	54000380 	b.eq	4c90 <fwp_mem_free+0x1d0>  // b.none
    4c24:	3900027f 	strb	wzr, [x19]
    4c28:	b9400ee2 	ldr	w2, [x23, #12]
    4c2c:	b4000142 	cbz	x2, 4c54 <fwp_mem_free+0x194>
    4c30:	9117c2a1 	add	x1, x21, #0x5f0
    4c34:	8b160040 	add	x0, x2, x22
    4c38:	8b000800 	add	x0, x0, x0, lsl #2
    4c3c:	f949fc21 	ldr	x1, [x1, #5112]
    4c40:	8b140034 	add	x20, x1, x20
    4c44:	8b000c20 	add	x0, x1, x0, lsl #3
    4c48:	3802869f 	strb	wzr, [x20], #40
    4c4c:	eb00029f 	cmp	x20, x0
    4c50:	54ffffc1 	b.ne	4c48 <fwp_mem_free+0x188>  // b.any
    4c54:	9117c2a0 	add	x0, x21, #0x5f0
    4c58:	f94a1801 	ldr	x1, [x0, #5168]
    4c5c:	f949f803 	ldr	x3, [x0, #5104]
    4c60:	8b020021 	add	x1, x1, x2
    4c64:	f90a1801 	str	x1, [x0, #5168]
    4c68:	eb16007f 	cmp	x3, x22
    4c6c:	54000049 	b.ls	4c74 <fwp_mem_free+0x1b4>  // b.plast
    4c70:	f909f816 	str	x22, [x0, #5104]
    4c74:	9117c2b5 	add	x21, x21, #0x5f0
    4c78:	f949f6a0 	ldr	x0, [x21, #5096]
    4c7c:	eb16001f 	cmp	x0, x22
    4c80:	54fff529 	b.ls	4b24 <fwp_mem_free+0x64>  // b.plast
    4c84:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c88:	f909f6b6 	str	x22, [x21, #5096]
    4c8c:	17ffffa7 	b	4b28 <fwp_mem_free+0x68>
    4c90:	aa1303e0 	mov	x0, x19
    4c94:	97fffeeb 	bl	4840 <fwp_rc_forget_slot>
    4c98:	17ffffe3 	b	4c24 <fwp_mem_free+0x164>
    4c9c:	97fffee9 	bl	4840 <fwp_rc_forget_slot>
    4ca0:	17ffffb4 	b	4b70 <fwp_mem_free+0xb0>

0000000000004ca4 <fwp_heap_alloc_big>:
    4ca4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4ca8:	910003fd 	mov	x29, sp
    4cac:	a90153f3 	stp	x19, x20, [sp, #16]
    4cb0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4cb4:	a90363f7 	stp	x23, x24, [sp, #48]
    4cb8:	aa0003f7 	mov	x23, x0
    4cbc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cc0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cc4:	eb0002ff 	cmp	x23, x0
    4cc8:	54000888 	b.hi	4dd8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4ccc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4cd0:	8b0002f4 	add	x20, x23, x0
    4cd4:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xbf0>
    4cd8:	9117c359 	add	x25, x26, #0x5f0
    4cdc:	d350fe94 	lsr	x20, x20, #16
    4ce0:	2a0103f5 	mov	w21, w1
    4ce4:	aa1403e0 	mov	x0, x20
    4ce8:	97fff972 	bl	32b0 <fwp_heap_chunks>
    4cec:	f949ff22 	ldr	x2, [x25, #5112]
    4cf0:	8b000813 	add	x19, x0, x0, lsl #2
    4cf4:	aa0003f8 	mov	x24, x0
    4cf8:	52800043 	mov	w3, #0x2                   	// #2
    4cfc:	d37df273 	lsl	x19, x19, #3
    4d00:	d2800021 	mov	x1, #0x1                   	// #1
    4d04:	8b130040 	add	x0, x2, x19
    4d08:	38336843 	strb	w3, [x2, x19]
    4d0c:	39000415 	strb	w21, [x0, #1]
    4d10:	b9000c14 	str	w20, [x0, #12]
    4d14:	f9000817 	str	x23, [x0, #16]
    4d18:	97fffef2 	bl	48e0 <fwp_rc_prepare_chunk>
    4d1c:	f100069f 	cmp	x20, #0x1
    4d20:	54000269 	b.ls	4d6c <fwp_heap_alloc_big+0xc8>  // b.plast
    4d24:	8b180294 	add	x20, x20, x24
    4d28:	9100a273 	add	x19, x19, #0x28
    4d2c:	a90573fb 	stp	x27, x28, [sp, #80]
    4d30:	5280007b 	mov	w27, #0x3                   	// #3
    4d34:	8b140a94 	add	x20, x20, x20, lsl #2
    4d38:	2a1803fc 	mov	w28, w24
    4d3c:	9adb2296 	lsl	x22, x20, x27
    4d40:	f949ff35 	ldr	x21, [x25, #5112]
    4d44:	d2800001 	mov	x1, #0x0                   	// #0
    4d48:	8b1302b4 	add	x20, x21, x19
    4d4c:	aa1403e0 	mov	x0, x20
    4d50:	97fffee4 	bl	48e0 <fwp_rc_prepare_chunk>
    4d54:	38336abb 	strb	w27, [x21, x19]
    4d58:	9100a273 	add	x19, x19, #0x28
    4d5c:	b9000e9c 	str	w28, [x20, #12]
    4d60:	eb1302df 	cmp	x22, x19
    4d64:	54fffee1 	b.ne	4d40 <fwp_heap_alloc_big+0x9c>  // b.any
    4d68:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d6c:	9117c353 	add	x19, x26, #0x5f0
    4d70:	aa1703e2 	mov	x2, x23
    4d74:	52800001 	mov	w1, #0x0                   	// #0
    4d78:	f949da60 	ldr	x0, [x19, #5040]
    4d7c:	8b184018 	add	x24, x0, x24, lsl #16
    4d80:	aa1803e0 	mov	x0, x24
    4d84:	97fff6b3 	bl	2850 <memset@plt>
    4d88:	f94a1260 	ldr	x0, [x19, #5152]
    4d8c:	ab170000 	adds	x0, x0, x23
    4d90:	54000242 	b.cs	4dd8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4d94:	f94a1661 	ldr	x1, [x19, #5160]
    4d98:	f90a1260 	str	x0, [x19, #5152]
    4d9c:	eb01001f 	cmp	x0, x1
    4da0:	54000049 	b.ls	4da8 <fwp_heap_alloc_big+0x104>  // b.plast
    4da4:	f90a1660 	str	x0, [x19, #5160]
    4da8:	9117c35a 	add	x26, x26, #0x5f0
    4dac:	9e6202e0 	scvtf	d0, x23
    4db0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4db4:	aa1803e0 	mov	x0, x24
    4db8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dbc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4dc0:	1e602820 	fadd	d0, d1, d0
    4dc4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dc8:	fd0a1f40 	str	d0, [x26, #5176]
    4dcc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4dd0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4dd4:	d65f03c0 	ret
    4dd8:	a90573fb 	stp	x27, x28, [sp, #80]
    4ddc:	97fff895 	bl	3030 <fwp_heap_oom>

0000000000004de0 <fwp_heap_alloc_slow>:
    4de0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4de4:	910003fd 	mov	x29, sp
    4de8:	a90153f3 	stp	x19, x20, [sp, #16]
    4dec:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    4df0:	9117c262 	add	x2, x19, #0x5f0
    4df4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4df8:	aa0003f5 	mov	x21, x0
    4dfc:	2a0103f4 	mov	w20, w1
    4e00:	b953a440 	ldr	w0, [x2, #5028]
    4e04:	34000600 	cbz	w0, 4ec4 <fwp_heap_alloc_slow+0xe4>
    4e08:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e0c:	54000628 	b.hi	4ed0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e10:	91003ea0 	add	x0, x21, #0xf
    4e14:	9117c262 	add	x2, x19, #0x5f0
    4e18:	f9001bf7 	str	x23, [sp, #48]
    4e1c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e20:	8b401040 	add	x0, x2, x0, lsr #4
    4e24:	cb34c084 	sub	x4, x4, w20, sxtw
    4e28:	d37ae484 	lsl	x4, x4, #6
    4e2c:	397e8003 	ldrb	w3, [x0, #4000]
    4e30:	910f0060 	add	x0, x3, #0x3c0
    4e34:	aa0303e1 	mov	x1, x3
    4e38:	8b030463 	add	x3, x3, x3, lsl #1
    4e3c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e40:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e44:	2a1703f6 	mov	w22, w23
    4e48:	f8636844 	ldr	x4, [x2, x3]
    4e4c:	b40004e4 	cbz	x4, 4ee8 <fwp_heap_alloc_slow+0x108>
    4e50:	f9400080 	ldr	x0, [x4]
    4e54:	aa2003e0 	mvn	x0, x0
    4e58:	f8236840 	str	x0, [x2, x3]
    4e5c:	7100069f 	cmp	w20, #0x1
    4e60:	aa0403e0 	mov	x0, x4
    4e64:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e68:	52800001 	mov	w1, #0x0                   	// #0
    4e6c:	97fff679 	bl	2850 <memset@plt>
    4e70:	aa0003e4 	mov	x4, x0
    4e74:	9117c260 	add	x0, x19, #0x5f0
    4e78:	f94a1001 	ldr	x1, [x0, #5152]
    4e7c:	ab160021 	adds	x1, x1, x22
    4e80:	540005c2 	b.cs	4f38 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e84:	f94a1402 	ldr	x2, [x0, #5160]
    4e88:	f90a1001 	str	x1, [x0, #5152]
    4e8c:	eb02003f 	cmp	x1, x2
    4e90:	54000049 	b.ls	4e98 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e94:	f90a1401 	str	x1, [x0, #5160]
    4e98:	9117c273 	add	x19, x19, #0x5f0
    4e9c:	1e6302e1 	ucvtf	d1, w23
    4ea0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ea4:	aa0403e0 	mov	x0, x4
    4ea8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4eac:	f9401bf7 	ldr	x23, [sp, #48]
    4eb0:	1e612800 	fadd	d0, d0, d1
    4eb4:	fd0a1e60 	str	d0, [x19, #5176]
    4eb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ebc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ec0:	d65f03c0 	ret
    4ec4:	97fffc90 	bl	4104 <fwp_heap_init>
    4ec8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4ecc:	54fffa29 	b.ls	4e10 <fwp_heap_alloc_slow+0x30>  // b.plast
    4ed0:	2a1403e1 	mov	w1, w20
    4ed4:	aa1503e0 	mov	x0, x21
    4ed8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4edc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ee0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ee4:	17ffff70 	b	4ca4 <fwp_heap_alloc_big>
    4ee8:	8b030042 	add	x2, x2, x3
    4eec:	f9400444 	ldr	x4, [x2, #8]
    4ef0:	b4000104 	cbz	x4, 4f10 <fwp_heap_alloc_slow+0x130>
    4ef4:	f9400840 	ldr	x0, [x2, #16]
    4ef8:	cb040000 	sub	x0, x0, x4
    4efc:	eb16001f 	cmp	x0, x22
    4f00:	54000083 	b.cc	4f10 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f04:	8b160080 	add	x0, x4, x22
    4f08:	f9000440 	str	x0, [x2, #8]
    4f0c:	17ffffd4 	b	4e5c <fwp_heap_alloc_slow+0x7c>
    4f10:	52800302 	mov	w2, #0x18                  	// #24
    4f14:	52807804 	mov	w4, #0x3c0                 	// #960
    4f18:	9117c260 	add	x0, x19, #0x5f0
    4f1c:	9ba27c23 	umull	x3, w1, w2
    4f20:	2a1403e2 	mov	w2, w20
    4f24:	9b240e84 	smaddl	x4, w20, w4, x3
    4f28:	8b040000 	add	x0, x0, x4
    4f2c:	97fffeb5 	bl	4a00 <fwp_heap_refill>
    4f30:	aa0003e4 	mov	x4, x0
    4f34:	17ffffca 	b	4e5c <fwp_heap_alloc_slow+0x7c>
    4f38:	97fff83e 	bl	3030 <fwp_heap_oom>
    4f3c:	d503201f 	nop

0000000000004f40 <fwp_heap_alloc>:
    4f40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f44:	f140101f 	cmp	x0, #0x4, lsl #12
    4f48:	910003fd 	mov	x29, sp
    4f4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f50:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    4f54:	9117c293 	add	x19, x20, #0x5f0
    4f58:	b953a662 	ldr	w2, [x19, #5028]
    4f5c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f60:	54000640 	b.eq	5028 <fwp_heap_alloc+0xe8>  // b.none
    4f64:	91003c03 	add	x3, x0, #0xf
    4f68:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f6c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f70:	8b431263 	add	x3, x19, x3, lsr #4
    4f74:	cb21c042 	sub	x2, x2, w1, sxtw
    4f78:	d37ae442 	lsl	x2, x2, #6
    4f7c:	397e8063 	ldrb	w3, [x3, #4000]
    4f80:	910f0064 	add	x4, x3, #0x3c0
    4f84:	8b030463 	add	x3, x3, x3, lsl #1
    4f88:	8b030c43 	add	x3, x2, x3, lsl #3
    4f8c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f90:	2a1603f5 	mov	w21, w22
    4f94:	f8636a64 	ldr	x4, [x19, x3]
    4f98:	b4000384 	cbz	x4, 5008 <fwp_heap_alloc+0xc8>
    4f9c:	f9400085 	ldr	x5, [x4]
    4fa0:	7100043f 	cmp	w1, #0x1
    4fa4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fa8:	aa0403e0 	mov	x0, x4
    4fac:	aa2503e5 	mvn	x5, x5
    4fb0:	52800001 	mov	w1, #0x0                   	// #0
    4fb4:	f8236a65 	str	x5, [x19, x3]
    4fb8:	97fff626 	bl	2850 <memset@plt>
    4fbc:	aa0003e4 	mov	x4, x0
    4fc0:	f94a1260 	ldr	x0, [x19, #5152]
    4fc4:	ab150000 	adds	x0, x0, x21
    4fc8:	54000442 	b.cs	5050 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4fcc:	f94a1661 	ldr	x1, [x19, #5160]
    4fd0:	f90a1260 	str	x0, [x19, #5152]
    4fd4:	eb01001f 	cmp	x0, x1
    4fd8:	54000049 	b.ls	4fe0 <fwp_heap_alloc+0xa0>  // b.plast
    4fdc:	f90a1660 	str	x0, [x19, #5160]
    4fe0:	9117c294 	add	x20, x20, #0x5f0
    4fe4:	1e6302c1 	ucvtf	d1, w22
    4fe8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fec:	aa0403e0 	mov	x0, x4
    4ff0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ff4:	1e612800 	fadd	d0, d0, d1
    4ff8:	fd0a1e80 	str	d0, [x20, #5176]
    4ffc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5000:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5004:	d65f03c0 	ret
    5008:	8b030263 	add	x3, x19, x3
    500c:	f9400464 	ldr	x4, [x3, #8]
    5010:	b40000a4 	cbz	x4, 5024 <fwp_heap_alloc+0xe4>
    5014:	f9400862 	ldr	x2, [x3, #16]
    5018:	cb040042 	sub	x2, x2, x4
    501c:	eb15005f 	cmp	x2, x21
    5020:	540000a2 	b.cs	5034 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5024:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5030:	17ffff6c 	b	4de0 <fwp_heap_alloc_slow>
    5034:	7100043f 	cmp	w1, #0x1
    5038:	8b150085 	add	x5, x4, x21
    503c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5040:	52800001 	mov	w1, #0x0                   	// #0
    5044:	aa0403e0 	mov	x0, x4
    5048:	f9000465 	str	x5, [x3, #8]
    504c:	17ffffdb 	b	4fb8 <fwp_heap_alloc+0x78>
    5050:	97fff7f8 	bl	3030 <fwp_heap_oom>

0000000000005054 <fwp_apply>:
    5054:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5058:	aa0003e6 	mov	x6, x0
    505c:	910003fd 	mov	x29, sp
    5060:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5064:	f947f463 	ldr	x3, [x3, #4072]
    5068:	a90153f3 	stp	x19, x20, [sp, #16]
    506c:	aa0203f4 	mov	x20, x2
    5070:	a9025bf5 	stp	x21, x22, [sp, #32]
    5074:	2a0103f5 	mov	w21, w1
    5078:	52800033 	mov	w19, #0x1                   	// #1
    507c:	a90363f7 	stp	x23, x24, [sp, #48]
    5080:	f00000d7 	adrp	x23, 20000 <__data_start>
    5084:	9101c2f7 	add	x23, x23, #0x70
    5088:	a9046bf9 	stp	x25, x26, [sp, #64]
    508c:	d100c3ff 	sub	sp, sp, #0x30
    5090:	f9400060 	ldr	x0, [x3]
    5094:	f81f83a0 	stur	x0, [x29, #-8]
    5098:	d2800000 	mov	x0, #0x0                   	// #0
    509c:	294058c3 	ldp	w3, w22, [x6]
    50a0:	910003f8 	mov	x24, sp
    50a4:	f94046e0 	ldr	x0, [x23, #136]
    50a8:	710002df 	cmp	w22, #0x0
    50ac:	d37be863 	lsl	x3, x3, #5
    50b0:	8b030007 	add	x7, x0, x3
    50b4:	b8636819 	ldr	w25, [x0, x3]
    50b8:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    50bc:	54000163 	b.cc	50e8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    50c0:	f94004e3 	ldr	x3, [x7, #8]
    50c4:	34000bd9 	cbz	w25, 523c <fwp_apply+0x1e8>
    50c8:	aa1403e0 	mov	x0, x20
    50cc:	d63f0060 	blr	x3
    50d0:	aa0003e6 	mov	x6, x0
    50d4:	6b1902bf 	cmp	w21, w25
    50d8:	54000940 	b.eq	5200 <fwp_apply+0x1ac>  // b.none
    50dc:	8b394e94 	add	x20, x20, w25, uxtw #3
    50e0:	4b1902b5 	sub	w21, w21, w25
    50e4:	17ffffee 	b	509c <fwp_apply+0x48>
    50e8:	0b1602ba 	add	w26, w21, w22
    50ec:	6b19035f 	cmp	w26, w25
    50f0:	54000543 	b.cc	5198 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50f4:	7100033f 	cmp	w25, #0x0
    50f8:	4b16033a 	sub	w26, w25, w22
    50fc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    5100:	d37df000 	lsl	x0, x0, #3
    5104:	91003c00 	add	x0, x0, #0xf
    5108:	92704c01 	and	x1, x0, #0xfffff0000
    510c:	927c7c00 	and	x0, x0, #0xffffffff0
    5110:	cb2163e1 	sub	x1, sp, x1
    5114:	eb2163ff 	cmp	sp, x1
    5118:	540000a0 	b.eq	512c <fwp_apply+0xd8>  // b.none
    511c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    5120:	f90203ff 	str	xzr, [sp, #1024]
    5124:	eb2163ff 	cmp	sp, x1
    5128:	54ffffa1 	b.ne	511c <fwp_apply+0xc8>  // b.any
    512c:	92403c00 	and	x0, x0, #0xffff
    5130:	cb2063ff 	sub	sp, sp, x0
    5134:	f90003ff 	str	xzr, [sp]
    5138:	f110001f 	cmp	x0, #0x400
    513c:	54000962 	b.cs	5268 <fwp_apply+0x214>  // b.hs, b.nlast
    5140:	910020c6 	add	x6, x6, #0x8
    5144:	910043e0 	add	x0, sp, #0x10
    5148:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    514c:	d2800003 	mov	x3, #0x0                   	// #0
    5150:	340000f6 	cbz	w22, 516c <fwp_apply+0x118>
    5154:	d503201f 	nop
    5158:	f86368c4 	ldr	x4, [x6, x3]
    515c:	f8236804 	str	x4, [x0, x3]
    5160:	91002063 	add	x3, x3, #0x8
    5164:	eb0300bf 	cmp	x5, x3
    5168:	54ffff81 	b.ne	5158 <fwp_apply+0x104>  // b.any
    516c:	3400013a 	cbz	w26, 5190 <fwp_apply+0x13c>
    5170:	2a1a03e6 	mov	w6, w26
    5174:	d2800003 	mov	x3, #0x0                   	// #0
    5178:	0b0302c4 	add	w4, w22, w3
    517c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5180:	91000463 	add	x3, x3, #0x1
    5184:	f8247805 	str	x5, [x0, x4, lsl #3]
    5188:	eb0300df 	cmp	x6, x3
    518c:	54ffff61 	b.ne	5178 <fwp_apply+0x124>  // b.any
    5190:	f94004e3 	ldr	x3, [x7, #8]
    5194:	1400002c 	b	5244 <fwp_apply+0x1f0>
    5198:	11000740 	add	w0, w26, #0x1
    519c:	52800041 	mov	w1, #0x2                   	// #2
    51a0:	f81e83a6 	stur	x6, [x29, #-24]
    51a4:	d37df000 	lsl	x0, x0, #3
    51a8:	97ffff66 	bl	4f40 <fwp_heap_alloc>
    51ac:	f85e83a6 	ldur	x6, [x29, #-24]
    51b0:	aa0003f3 	mov	x19, x0
    51b4:	b94000c1 	ldr	w1, [x6]
    51b8:	29006801 	stp	w1, w26, [x0]
    51bc:	340000b6 	cbz	w22, 51d0 <fwp_apply+0x17c>
    51c0:	910020c1 	add	x1, x6, #0x8
    51c4:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    51c8:	91002000 	add	x0, x0, #0x8
    51cc:	97fff549 	bl	26f0 <memmove@plt>
    51d0:	2a1503e3 	mov	w3, w21
    51d4:	d2800000 	mov	x0, #0x0                   	// #0
    51d8:	34000135 	cbz	w21, 51fc <fwp_apply+0x1a8>
    51dc:	d503201f 	nop
    51e0:	0b0002c1 	add	w1, w22, w0
    51e4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    51e8:	8b010e61 	add	x1, x19, x1, lsl #3
    51ec:	91000400 	add	x0, x0, #0x1
    51f0:	f9000422 	str	x2, [x1, #8]
    51f4:	eb00007f 	cmp	x3, x0
    51f8:	54ffff41 	b.ne	51e0 <fwp_apply+0x18c>  // b.any
    51fc:	aa1303e6 	mov	x6, x19
    5200:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5204:	f947f400 	ldr	x0, [x0, #4072]
    5208:	f85f83a2 	ldur	x2, [x29, #-8]
    520c:	f9400001 	ldr	x1, [x0]
    5210:	eb010042 	subs	x2, x2, x1
    5214:	d2800001 	mov	x1, #0x0                   	// #0
    5218:	540002c1 	b.ne	5270 <fwp_apply+0x21c>  // b.any
    521c:	910003bf 	mov	sp, x29
    5220:	aa0603e0 	mov	x0, x6
    5224:	a94153f3 	ldp	x19, x20, [sp, #16]
    5228:	a9425bf5 	ldp	x21, x22, [sp, #32]
    522c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5230:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5234:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5238:	d65f03c0 	ret
    523c:	d10043a0 	sub	x0, x29, #0x10
    5240:	5280001a 	mov	w26, #0x0                   	// #0
    5244:	d63f0060 	blr	x3
    5248:	aa0003e6 	mov	x6, x0
    524c:	6b1a02bf 	cmp	w21, w26
    5250:	54fffd80 	b.eq	5200 <fwp_apply+0x1ac>  // b.none
    5254:	0b1602b6 	add	w22, w21, w22
    5258:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    525c:	4b1902d5 	sub	w21, w22, w25
    5260:	9100031f 	mov	sp, x24
    5264:	17ffff8e 	b	509c <fwp_apply+0x48>
    5268:	f90203ff 	str	xzr, [sp, #1024]
    526c:	17ffffb5 	b	5140 <fwp_apply+0xec>
    5270:	97fff584 	bl	2880 <__stack_chk_fail@plt>

0000000000005274 <fwp_p_ad_push>:
    5274:	f100001f 	cmp	x0, #0x0
    5278:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    527c:	54000e8b 	b.lt	544c <fwp_p_ad_push+0x1d8>  // b.tstop
    5280:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5284:	aa0003e4 	mov	x4, x0
    5288:	910003fd 	mov	x29, sp
    528c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5290:	aa0003f5 	mov	x21, x0
    5294:	aa020000 	orr	x0, x0, x2
    5298:	a90363f7 	stp	x23, x24, [sp, #48]
    529c:	aa0203f7 	mov	x23, x2
    52a0:	6d0627e8 	stp	d8, d9, [sp, #96]
    52a4:	9e670029 	fmov	d9, x1
    52a8:	9e670068 	fmov	d8, x3
    52ac:	b6f80900 	tbz	x0, #63, 53cc <fwp_p_ad_push+0x158>
    52b0:	a90153f3 	stp	x19, x20, [sp, #16]
    52b4:	9360fc80 	asr	x0, x4, #32
    52b8:	b6f800c4 	tbz	x4, #63, 52d0 <fwp_p_ad_push+0x5c>
    52bc:	1e604109 	fmov	d9, d8
    52c0:	2f00e408 	movi	d8, #0x0
    52c4:	9360fc40 	asr	x0, x2, #32
    52c8:	aa0203f5 	mov	x21, x2
    52cc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    52d0:	97fffa18 	bl	3b30 <fwp_tape_of>
    52d4:	aa0003f3 	mov	x19, x0
    52d8:	f9403000 	ldr	x0, [x0, #96]
    52dc:	b5001280 	cbnz	x0, 552c <fwp_p_ad_push+0x2b8>
    52e0:	f9400a76 	ldr	x22, [x19, #16]
    52e4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    52e8:	eb0002df 	cmp	x22, x0
    52ec:	54000e2c 	b.gt	54b0 <fwp_p_ad_push+0x23c>
    52f0:	eb3542df 	cmp	x22, w21, uxtw
    52f4:	54000d4d 	b.le	549c <fwp_p_ad_push+0x228>
    52f8:	b7f80077 	tbnz	x23, #63, 5304 <fwp_p_ad_push+0x90>
    52fc:	eb3742df 	cmp	x22, w23, uxtw
    5300:	54000ced 	b.le	549c <fwp_p_ad_push+0x228>
    5304:	f9400678 	ldr	x24, [x19, #8]
    5308:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    530c:	cb1802d8 	sub	x24, x22, x24
    5310:	91000701 	add	x1, x24, #0x1
    5314:	eb00003f 	cmp	x1, x0
    5318:	54000cc8 	b.hi	54b0 <fwp_p_ad_push+0x23c>  // b.pmore
    531c:	a9418274 	ldp	x20, x0, [x19, #24]
    5320:	a90573fb 	stp	x27, x28, [sp, #80]
    5324:	eb14003f 	cmp	x1, x20
    5328:	5400068d 	b.le	53f8 <fwp_p_ad_push+0x184>
    532c:	f100029f 	cmp	x20, #0x0
    5330:	d2800803 	mov	x3, #0x40                  	// #64
    5334:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5338:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    533c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5340:	eb14003f 	cmp	x1, x20
    5344:	5400008d 	b.le	5354 <fwp_p_ad_push+0xe0>
    5348:	eb02029f 	cmp	x20, x2
    534c:	5400052d 	b.le	53f0 <fwp_p_ad_push+0x17c>
    5350:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5354:	d37df299 	lsl	x25, x20, #3
    5358:	aa1903e1 	mov	x1, x25
    535c:	97fff545 	bl	2870 <realloc@plt>
    5360:	aa0003e1 	mov	x1, x0
    5364:	b4000b00 	cbz	x0, 54c4 <fwp_p_ad_push+0x250>
    5368:	f9400e62 	ldr	x2, [x19, #24]
    536c:	f9001261 	str	x1, [x19, #32]
    5370:	f9401a60 	ldr	x0, [x19, #48]
    5374:	d37cee9a 	lsl	x26, x20, #4
    5378:	8b020821 	add	x1, x1, x2, lsl #2
    537c:	f9001661 	str	x1, [x19, #40]
    5380:	aa1a03e1 	mov	x1, x26
    5384:	97fff53b 	bl	2870 <realloc@plt>
    5388:	aa0003e2 	mov	x2, x0
    538c:	b40009c0 	cbz	x0, 54c4 <fwp_p_ad_push+0x250>
    5390:	f9400e61 	ldr	x1, [x19, #24]
    5394:	d37df31b 	lsl	x27, x24, #3
    5398:	d37ef685 	lsl	x5, x20, #2
    539c:	d37ef71c 	lsl	x28, x24, #2
    53a0:	8b190004 	add	x4, x0, x25
    53a4:	8b010c01 	add	x1, x0, x1, lsl #3
    53a8:	a9030660 	stp	x0, x1, [x19, #48]
    53ac:	b5000558 	cbnz	x24, 5454 <fwp_p_ad_push+0x1e0>
    53b0:	f9001e64 	str	x4, [x19, #56]
    53b4:	f9401260 	ldr	x0, [x19, #32]
    53b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53bc:	8b050001 	add	x1, x0, x5
    53c0:	f9000e74 	str	x20, [x19, #24]
    53c4:	f9001661 	str	x1, [x19, #40]
    53c8:	14000010 	b	5408 <fwp_p_ad_push+0x194>
    53cc:	9360fc40 	asr	x0, x2, #32
    53d0:	a90153f3 	stp	x19, x20, [sp, #16]
    53d4:	eb84801f 	cmp	x0, x4, asr #32
    53d8:	54fff7c0 	b.eq	52d0 <fwp_p_ad_push+0x5c>  // b.none
    53dc:	d0000020 	adrp	x0, b000 <__divti3+0x190>
    53e0:	9124e000 	add	x0, x0, #0x938
    53e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    53e8:	a90573fb 	stp	x27, x28, [sp, #80]
    53ec:	97fff905 	bl	3800 <fwp_trap>
    53f0:	d37ffa94 	lsl	x20, x20, #1
    53f4:	17ffffd3 	b	5340 <fwp_p_ad_push+0xcc>
    53f8:	a9428a61 	ldp	x1, x2, [x19, #40]
    53fc:	d37ef71c 	lsl	x28, x24, #2
    5400:	f9401e64 	ldr	x4, [x19, #56]
    5404:	d37df31b 	lsl	x27, x24, #3
    5408:	b83c6815 	str	w21, [x0, x28]
    540c:	f10002ff 	cmp	x23, #0x0
    5410:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5414:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5418:	fc3b6849 	str	d9, [x2, x27]
    541c:	aa1602a0 	orr	x0, x21, x22
    5420:	b83c6837 	str	w23, [x1, x28]
    5424:	910006d6 	add	x22, x22, #0x1
    5428:	a94363f7 	ldp	x23, x24, [sp, #48]
    542c:	fc3b6888 	str	d8, [x4, x27]
    5430:	a94573fb 	ldp	x27, x28, [sp, #80]
    5434:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5438:	f9000a76 	str	x22, [x19, #16]
    543c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5440:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5444:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5448:	d65f03c0 	ret
    544c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5450:	d65f03c0 	ret
    5454:	eb1a033f 	cmp	x25, x26
    5458:	aa0403e0 	mov	x0, x4
    545c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5460:	aa1b03e2 	mov	x2, x27
    5464:	cb190063 	sub	x3, x3, x25
    5468:	f9003fe5 	str	x5, [sp, #120]
    546c:	97fff56d 	bl	2a20 <__memmove_chk@plt>
    5470:	a9420660 	ldp	x0, x1, [x19, #32]
    5474:	aa1c03e2 	mov	x2, x28
    5478:	f9401a63 	ldr	x3, [x19, #48]
    547c:	f9403fe5 	ldr	x5, [sp, #120]
    5480:	8b190063 	add	x3, x3, x25
    5484:	f9001e63 	str	x3, [x19, #56]
    5488:	8b050000 	add	x0, x0, x5
    548c:	97fff499 	bl	26f0 <memmove@plt>
    5490:	a9431262 	ldp	x2, x4, [x19, #48]
    5494:	f9403fe5 	ldr	x5, [sp, #120]
    5498:	17ffffc7 	b	53b4 <fwp_p_ad_push+0x140>
    549c:	d0000020 	adrp	x0, b000 <__divti3+0x190>
    54a0:	91274000 	add	x0, x0, #0x9d0
    54a4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54a8:	a90573fb 	stp	x27, x28, [sp, #80]
    54ac:	97fff8d5 	bl	3800 <fwp_trap>
    54b0:	d0000020 	adrp	x0, b000 <__divti3+0x190>
    54b4:	9126c000 	add	x0, x0, #0x9b0
    54b8:	a9046bf9 	stp	x25, x26, [sp, #64]
    54bc:	a90573fb 	stp	x27, x28, [sp, #80]
    54c0:	97fff8d0 	bl	3800 <fwp_trap>
    54c4:	aa1303e0 	mov	x0, x19
    54c8:	97fff6b2 	bl	2f90 <fwp_tape_unlink_scope>
    54cc:	f9401260 	ldr	x0, [x19, #32]
    54d0:	97fff51c 	bl	2940 <free@plt>
    54d4:	f9401a60 	ldr	x0, [x19, #48]
    54d8:	97fff51a 	bl	2940 <free@plt>
    54dc:	f9402260 	ldr	x0, [x19, #64]
    54e0:	97fff518 	bl	2940 <free@plt>
    54e4:	f9000e7f 	str	xzr, [x19, #24]
    54e8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    54ec:	f947e821 	ldr	x1, [x1, #4048]
    54f0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    54f4:	d2800262 	mov	x2, #0x13                  	// #19
    54f8:	4f000400 	movi	v0.4s, #0x0
    54fc:	d0000020 	adrp	x0, b000 <__divti3+0x190>
    5500:	f9400023 	ldr	x3, [x1]
    5504:	b900067f 	str	wzr, [x19, #4]
    5508:	d2800021 	mov	x1, #0x1                   	// #1
    550c:	91166000 	add	x0, x0, #0x598
    5510:	3c808260 	stur	q0, [x19, #8]
    5514:	ad010260 	stp	q0, q0, [x19, #32]
    5518:	97fff51a 	bl	2980 <fwrite@plt>
    551c:	d2800000 	mov	x0, #0x0                   	// #0
    5520:	97fff524 	bl	29b0 <fflush@plt>
    5524:	52800cc0 	mov	w0, #0x66                  	// #102
    5528:	97fff532 	bl	29f0 <_Exit@plt>
    552c:	d0000020 	adrp	x0, b000 <__divti3+0x190>
    5530:	91260000 	add	x0, x0, #0x980
    5534:	a9046bf9 	stp	x25, x26, [sp, #64]
    5538:	a90573fb 	stp	x27, x28, [sp, #80]
    553c:	97fff8b1 	bl	3800 <fwp_trap>

0000000000005540 <w107>:
    5540:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5544:	9e660003 	fmov	x3, d0
    5548:	aa0003e2 	mov	x2, x0
    554c:	910003fd 	mov	x29, sp
    5550:	fd001fea 	str	d10, [sp, #56]
    5554:	1e60400a 	fmov	d10, d0
    5558:	6d0427e8 	stp	d8, d9, [sp, #64]
    555c:	1e604028 	fmov	d8, d1
    5560:	1e600809 	fmul	d9, d0, d0
    5564:	a90153f3 	stp	x19, x20, [sp, #16]
    5568:	aa0103f4 	mov	x20, x1
    556c:	aa0303e1 	mov	x1, x3
    5570:	aa0003f3 	mov	x19, x0
    5574:	a9025bf5 	stp	x21, x22, [sp, #32]
    5578:	f9001bf7 	str	x23, [sp, #48]
    557c:	97ffff3e 	bl	5274 <fwp_p_ad_push>
    5580:	aa0003e5 	mov	x5, x0
    5584:	97fffb50 	bl	42c4 <caf61>
    5588:	9e670000 	fmov	d0, x0
    558c:	97fffb4e 	bl	42c4 <caf61>
    5590:	1e693908 	fsub	d8, d8, d9
    5594:	aa1403e2 	mov	x2, x20
    5598:	1e614000 	fneg	d0, d0
    559c:	aa0003e3 	mov	x3, x0
    55a0:	aa0503e0 	mov	x0, x5
    55a4:	9e660117 	fmov	x23, d8
    55a8:	9e660001 	fmov	x1, d0
    55ac:	97ffff32 	bl	5274 <fwp_p_ad_push>
    55b0:	aa0003f5 	mov	x21, x0
    55b4:	97fffb44 	bl	42c4 <caf61>
    55b8:	9e670000 	fmov	d0, x0
    55bc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    55c0:	97fffb41 	bl	42c4 <caf61>
    55c4:	1e614000 	fneg	d0, d0
    55c8:	aa0003e3 	mov	x3, x0
    55cc:	1e6a3929 	fsub	d9, d9, d10
    55d0:	aa1303e0 	mov	x0, x19
    55d4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    55d8:	9e660001 	fmov	x1, d0
    55dc:	9e660136 	fmov	x22, d9
    55e0:	97ffff25 	bl	5274 <fwp_p_ad_push>
    55e4:	1e680908 	fmul	d8, d8, d8
    55e8:	aa0003f4 	mov	x20, x0
    55ec:	aa1703e3 	mov	x3, x23
    55f0:	aa1703e1 	mov	x1, x23
    55f4:	aa1503e2 	mov	x2, x21
    55f8:	aa1503e0 	mov	x0, x21
    55fc:	97ffff1e 	bl	5274 <fwp_p_ad_push>
    5600:	aa0003e2 	mov	x2, x0
    5604:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5608:	9e670020 	fmov	d0, x1
    560c:	9e660101 	fmov	x1, d8
    5610:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5614:	1e600908 	fmul	d8, d8, d0
    5618:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    561c:	97ffff16 	bl	5274 <fwp_p_ad_push>
    5620:	1e690929 	fmul	d9, d9, d9
    5624:	aa1603e3 	mov	x3, x22
    5628:	aa1603e1 	mov	x1, x22
    562c:	aa1403e2 	mov	x2, x20
    5630:	aa0003f3 	mov	x19, x0
    5634:	aa1403e0 	mov	x0, x20
    5638:	97ffff0f 	bl	5274 <fwp_p_ad_push>
    563c:	aa0003e5 	mov	x5, x0
    5640:	97fffb21 	bl	42c4 <caf61>
    5644:	aa0003e6 	mov	x6, x0
    5648:	97fffb1f 	bl	42c4 <caf61>
    564c:	1e692908 	fadd	d8, d8, d9
    5650:	aa1303e2 	mov	x2, x19
    5654:	aa0603e1 	mov	x1, x6
    5658:	aa0003e3 	mov	x3, x0
    565c:	aa0503e0 	mov	x0, x5
    5660:	97ffff05 	bl	5274 <fwp_p_ad_push>
    5664:	aa0003e1 	mov	x1, x0
    5668:	a94153f3 	ldp	x19, x20, [sp, #16]
    566c:	9e660100 	fmov	x0, d8
    5670:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5674:	f9401bf7 	ldr	x23, [sp, #48]
    5678:	fd401fea 	ldr	d10, [sp, #56]
    567c:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5680:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5684:	d65f03c0 	ret
    5688:	d503201f 	nop
    568c:	d503201f 	nop

0000000000005690 <w164.constprop.0>:
    5690:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5694:	910003fd 	mov	x29, sp
    5698:	a9025bf5 	stp	x21, x22, [sp, #32]
    569c:	fd001be8 	str	d8, [sp, #48]
    56a0:	f9400015 	ldr	x21, [x0]
    56a4:	b40003b5 	cbz	x21, 5718 <w164.constprop.0+0x88>
    56a8:	2f00e408 	movi	d8, #0x0
    56ac:	91002016 	add	x22, x0, #0x8
    56b0:	a90153f3 	stp	x19, x20, [sp, #16]
    56b4:	91004014 	add	x20, x0, #0x10
    56b8:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    56bc:	d2800013 	mov	x19, #0x0                   	// #0
    56c0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    56c4:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    56c8:	97fffaff 	bl	42c4 <caf61>
    56cc:	aa0003e6 	mov	x6, x0
    56d0:	97fffafd 	bl	42c4 <caf61>
    56d4:	1e602908 	fadd	d8, d8, d0
    56d8:	aa0003e3 	mov	x3, x0
    56dc:	aa0703e2 	mov	x2, x7
    56e0:	aa0503e0 	mov	x0, x5
    56e4:	aa0603e1 	mov	x1, x6
    56e8:	91000a73 	add	x19, x19, #0x2
    56ec:	97fffee2 	bl	5274 <fwp_p_ad_push>
    56f0:	aa0003e5 	mov	x5, x0
    56f4:	eb1302bf 	cmp	x21, x19
    56f8:	54fffe48 	b.hi	56c0 <w164.constprop.0+0x30>  // b.pmore
    56fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5700:	9e660100 	fmov	x0, d8
    5704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5708:	aa0503e1 	mov	x1, x5
    570c:	fd401be8 	ldr	d8, [sp, #48]
    5710:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5714:	d65f03c0 	ret
    5718:	2f00e408 	movi	d8, #0x0
    571c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    5720:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5724:	aa0503e1 	mov	x1, x5
    5728:	9e660100 	fmov	x0, d8
    572c:	fd401be8 	ldr	d8, [sp, #48]
    5730:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5734:	d65f03c0 	ret
    5738:	d503201f 	nop
    573c:	d503201f 	nop

0000000000005740 <fwp_data.part.0.constprop.0>:
    5740:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5744:	910003fd 	mov	x29, sp
    5748:	a90153f3 	stp	x19, x20, [sp, #16]
    574c:	90000174 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    5750:	9117c283 	add	x3, x20, #0x5f0
    5754:	a9025bf5 	stp	x21, x22, [sp, #32]
    5758:	aa0103f5 	mov	x21, x1
    575c:	b953a461 	ldr	w1, [x3, #5028]
    5760:	a90363f7 	stp	x23, x24, [sp, #48]
    5764:	2a0003f8 	mov	w24, w0
    5768:	34000701 	cbz	w1, 5848 <fwp_data.part.0.constprop.0+0x108>
    576c:	397e8862 	ldrb	w2, [x3, #4002]
    5770:	910f0040 	add	x0, x2, #0x3c0
    5774:	8b020442 	add	x2, x2, x2, lsl #1
    5778:	d37df042 	lsl	x2, x2, #3
    577c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5780:	2a1703f6 	mov	w22, w23
    5784:	f8626873 	ldr	x19, [x3, x2]
    5788:	b40004d3 	cbz	x19, 5820 <fwp_data.part.0.constprop.0+0xe0>
    578c:	f9400260 	ldr	x0, [x19]
    5790:	aa2003e0 	mvn	x0, x0
    5794:	f8226860 	str	x0, [x3, x2]
    5798:	f10062df 	cmp	x22, #0x18
    579c:	540000e9 	b.ls	57b8 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    57a0:	d10066c2 	sub	x2, x22, #0x19
    57a4:	91006260 	add	x0, x19, #0x18
    57a8:	927df042 	and	x2, x2, #0xfffffffffffffff8
    57ac:	52800001 	mov	w1, #0x0                   	// #0
    57b0:	91002042 	add	x2, x2, #0x8
    57b4:	97fff427 	bl	2850 <memset@plt>
    57b8:	9117c282 	add	x2, x20, #0x5f0
    57bc:	f94a1041 	ldr	x1, [x2, #5152]
    57c0:	ab160021 	adds	x1, x1, x22
    57c4:	540004c2 	b.cs	585c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    57c8:	f94a1440 	ldr	x0, [x2, #5160]
    57cc:	f90a1041 	str	x1, [x2, #5152]
    57d0:	eb00003f 	cmp	x1, x0
    57d4:	54000049 	b.ls	57dc <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    57d8:	f90a1441 	str	x1, [x2, #5160]
    57dc:	9117c294 	add	x20, x20, #0x5f0
    57e0:	1e6302e1 	ucvtf	d1, w23
    57e4:	fd4a1e80 	ldr	d0, [x20, #5176]
    57e8:	1e612800 	fadd	d0, d0, d1
    57ec:	fd0a1e80 	str	d0, [x20, #5176]
    57f0:	52800041 	mov	w1, #0x2                   	// #2
    57f4:	29000678 	stp	w24, w1, [x19]
    57f8:	aa1303e0 	mov	x0, x19
    57fc:	f94002a1 	ldr	x1, [x21]
    5800:	f9000661 	str	x1, [x19, #8]
    5804:	f94006a1 	ldr	x1, [x21, #8]
    5808:	f9000a61 	str	x1, [x19, #16]
    580c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5810:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5814:	a94363f7 	ldp	x23, x24, [sp, #48]
    5818:	a8c47bfd 	ldp	x29, x30, [sp], #64
    581c:	d65f03c0 	ret
    5820:	8b020063 	add	x3, x3, x2
    5824:	f9400473 	ldr	x19, [x3, #8]
    5828:	b4000113 	cbz	x19, 5848 <fwp_data.part.0.constprop.0+0x108>
    582c:	f9400860 	ldr	x0, [x3, #16]
    5830:	cb130000 	sub	x0, x0, x19
    5834:	eb0002df 	cmp	x22, x0
    5838:	54000088 	b.hi	5848 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    583c:	8b160260 	add	x0, x19, x22
    5840:	f9000460 	str	x0, [x3, #8]
    5844:	17ffffd5 	b	5798 <fwp_data.part.0.constprop.0+0x58>
    5848:	52800001 	mov	w1, #0x0                   	// #0
    584c:	d2800300 	mov	x0, #0x18                  	// #24
    5850:	97fffdbc 	bl	4f40 <fwp_heap_alloc>
    5854:	aa0003f3 	mov	x19, x0
    5858:	17ffffe6 	b	57f0 <fwp_data.part.0.constprop.0+0xb0>
    585c:	97fff5f5 	bl	3030 <fwp_heap_oom>

0000000000005860 <fwp_rc_share>:
    5860:	90000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    5864:	9117c042 	add	x2, x2, #0x5f0
    5868:	f949d843 	ldr	x3, [x2, #5040]
    586c:	f949ec41 	ldr	x1, [x2, #5080]
    5870:	cb030000 	sub	x0, x0, x3
    5874:	eb01401f 	cmp	x0, x1, lsl #16
    5878:	540002c2 	b.cs	58d0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    587c:	d350fc01 	lsr	x1, x0, #16
    5880:	f949fc44 	ldr	x4, [x2, #5112]
    5884:	8b010821 	add	x1, x1, x1, lsl #2
    5888:	d37df021 	lsl	x1, x1, #3
    588c:	8b010083 	add	x3, x4, x1
    5890:	f9401062 	ldr	x2, [x3, #32]
    5894:	b40001e2 	cbz	x2, 58d0 <fwp_rc_share+0x70>
    5898:	38616881 	ldrb	w1, [x4, x1]
    589c:	7100083f 	cmp	w1, #0x2
    58a0:	540001a0 	b.eq	58d4 <fwp_rc_share+0x74>  // b.none
    58a4:	7100043f 	cmp	w1, #0x1
    58a8:	54000141 	b.ne	58d0 <fwp_rc_share+0x70>  // b.any
    58ac:	29430464 	ldp	w4, w1, [x3, #24]
    58b0:	92403c00 	and	x0, x0, #0xffff
    58b4:	9b047c00 	mul	x0, x0, x4
    58b8:	d360fc00 	lsr	x0, x0, #32
    58bc:	eb01001f 	cmp	x0, x1
    58c0:	54000082 	b.cs	58d0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    58c4:	8b000042 	add	x2, x2, x0
    58c8:	39400040 	ldrb	w0, [x2]
    58cc:	350000a0 	cbnz	w0, 58e0 <fwp_rc_share+0x80>
    58d0:	d65f03c0 	ret
    58d4:	72003c1f 	tst	w0, #0xffff
    58d8:	54ffff80 	b.eq	58c8 <fwp_rc_share+0x68>  // b.none
    58dc:	d65f03c0 	ret
    58e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    58e4:	d0000020 	adrp	x0, b000 <__divti3+0x190>
    58e8:	9127c000 	add	x0, x0, #0x9f0
    58ec:	910003fd 	mov	x29, sp
    58f0:	97fff7c4 	bl	3800 <fwp_trap>

00000000000058f4 <fwp_rc_free_arr>:
    58f4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    58f8:	9117c063 	add	x3, x3, #0x5f0
    58fc:	f949d861 	ldr	x1, [x3, #5040]
    5900:	f949ec62 	ldr	x2, [x3, #5080]
    5904:	cb010001 	sub	x1, x0, x1
    5908:	eb02403f 	cmp	x1, x2, lsl #16
    590c:	54000342 	b.cs	5974 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5910:	d350fc22 	lsr	x2, x1, #16
    5914:	f949fc65 	ldr	x5, [x3, #5112]
    5918:	8b020842 	add	x2, x2, x2, lsl #2
    591c:	d37df042 	lsl	x2, x2, #3
    5920:	8b0200a4 	add	x4, x5, x2
    5924:	f9401083 	ldr	x3, [x4, #32]
    5928:	b4000263 	cbz	x3, 5974 <fwp_rc_free_arr+0x80>
    592c:	386268a2 	ldrb	w2, [x5, x2]
    5930:	7100085f 	cmp	w2, #0x2
    5934:	540001c0 	b.eq	596c <fwp_rc_free_arr+0x78>  // b.none
    5938:	7100045f 	cmp	w2, #0x1
    593c:	540001c1 	b.ne	5974 <fwp_rc_free_arr+0x80>  // b.any
    5940:	29430885 	ldp	w5, w2, [x4, #24]
    5944:	92403c21 	and	x1, x1, #0xffff
    5948:	9b057c21 	mul	x1, x1, x5
    594c:	d360fc21 	lsr	x1, x1, #32
    5950:	eb02003f 	cmp	x1, x2
    5954:	54000102 	b.cs	5974 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5958:	8b010063 	add	x3, x3, x1
    595c:	39400061 	ldrb	w1, [x3]
    5960:	7100043f 	cmp	w1, #0x1
    5964:	54000081 	b.ne	5974 <fwp_rc_free_arr+0x80>  // b.any
    5968:	17fffc56 	b	4ac0 <fwp_mem_free>
    596c:	72003c3f 	tst	w1, #0xffff
    5970:	54ffff60 	b.eq	595c <fwp_rc_free_arr+0x68>  // b.none
    5974:	d65f03c0 	ret
    5978:	d503201f 	nop
    597c:	d503201f 	nop

0000000000005980 <fwp_rc_dup>:
    5980:	90000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    5984:	9117c042 	add	x2, x2, #0x5f0
    5988:	f949d841 	ldr	x1, [x2, #5040]
    598c:	f949ec43 	ldr	x3, [x2, #5080]
    5990:	cb010001 	sub	x1, x0, x1
    5994:	eb03403f 	cmp	x1, x3, lsl #16
    5998:	54000342 	b.cs	5a00 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    599c:	d350fc20 	lsr	x0, x1, #16
    59a0:	f949fc44 	ldr	x4, [x2, #5112]
    59a4:	8b000800 	add	x0, x0, x0, lsl #2
    59a8:	d37df002 	lsl	x2, x0, #3
    59ac:	8b020083 	add	x3, x4, x2
    59b0:	f9401060 	ldr	x0, [x3, #32]
    59b4:	b4000260 	cbz	x0, 5a00 <fwp_rc_dup+0x80>
    59b8:	38626882 	ldrb	w2, [x4, x2]
    59bc:	7100085f 	cmp	w2, #0x2
    59c0:	54000220 	b.eq	5a04 <fwp_rc_dup+0x84>  // b.none
    59c4:	7100045f 	cmp	w2, #0x1
    59c8:	540001c1 	b.ne	5a00 <fwp_rc_dup+0x80>  // b.any
    59cc:	29430864 	ldp	w4, w2, [x3, #24]
    59d0:	92403c21 	and	x1, x1, #0xffff
    59d4:	9b047c21 	mul	x1, x1, x4
    59d8:	d360fc21 	lsr	x1, x1, #32
    59dc:	eb02003f 	cmp	x1, x2
    59e0:	54000102 	b.cs	5a00 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    59e4:	8b010000 	add	x0, x0, x1
    59e8:	39400001 	ldrb	w1, [x0]
    59ec:	340000a1 	cbz	w1, 5a00 <fwp_rc_dup+0x80>
    59f0:	7103f43f 	cmp	w1, #0xfd
    59f4:	540000e8 	b.hi	5a10 <fwp_rc_dup+0x90>  // b.pmore
    59f8:	11000421 	add	w1, w1, #0x1
    59fc:	39000001 	strb	w1, [x0]
    5a00:	d65f03c0 	ret
    5a04:	72003c3f 	tst	w1, #0xffff
    5a08:	54ffff00 	b.eq	59e8 <fwp_rc_dup+0x68>  // b.none
    5a0c:	d65f03c0 	ret
    5a10:	17fffb45 	b	4724 <fwp_rc_wide_dup>

0000000000005a14 <fwp_drop0>:
    5a14:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a18:	910003fd 	mov	x29, sp
    5a1c:	a90153f3 	stp	x19, x20, [sp, #16]
    5a20:	f90013f5 	str	x21, [sp, #32]
    5a24:	90000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    5a28:	9117c2b4 	add	x20, x21, #0x5f0
    5a2c:	f949da81 	ldr	x1, [x20, #5040]
    5a30:	f949ee82 	ldr	x2, [x20, #5080]
    5a34:	cb010001 	sub	x1, x0, x1
    5a38:	eb02403f 	cmp	x1, x2, lsl #16
    5a3c:	54000382 	b.cs	5aac <fwp_drop0+0x98>  // b.hs, b.nlast
    5a40:	d350fc22 	lsr	x2, x1, #16
    5a44:	f949fe84 	ldr	x4, [x20, #5112]
    5a48:	8b020842 	add	x2, x2, x2, lsl #2
    5a4c:	d37df042 	lsl	x2, x2, #3
    5a50:	8b020083 	add	x3, x4, x2
    5a54:	f9401073 	ldr	x19, [x3, #32]
    5a58:	b40002b3 	cbz	x19, 5aac <fwp_drop0+0x98>
    5a5c:	38626882 	ldrb	w2, [x4, x2]
    5a60:	7100085f 	cmp	w2, #0x2
    5a64:	540002c0 	b.eq	5abc <fwp_drop0+0xa8>  // b.none
    5a68:	7100045f 	cmp	w2, #0x1
    5a6c:	54000201 	b.ne	5aac <fwp_drop0+0x98>  // b.any
    5a70:	29430864 	ldp	w4, w2, [x3, #24]
    5a74:	92403c21 	and	x1, x1, #0xffff
    5a78:	9b047c21 	mul	x1, x1, x4
    5a7c:	d360fc21 	lsr	x1, x1, #32
    5a80:	eb02003f 	cmp	x1, x2
    5a84:	54000142 	b.cs	5aac <fwp_drop0+0x98>  // b.hs, b.nlast
    5a88:	8b010273 	add	x19, x19, x1
    5a8c:	39400261 	ldrb	w1, [x19]
    5a90:	340000e1 	cbz	w1, 5aac <fwp_drop0+0x98>
    5a94:	7100043f 	cmp	w1, #0x1
    5a98:	540001e0 	b.eq	5ad4 <fwp_drop0+0xc0>  // b.none
    5a9c:	7103fc3f 	cmp	w1, #0xff
    5aa0:	540002e0 	b.eq	5afc <fwp_drop0+0xe8>  // b.none
    5aa4:	51000421 	sub	w1, w1, #0x1
    5aa8:	39000261 	strb	w1, [x19]
    5aac:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ab0:	f94013f5 	ldr	x21, [sp, #32]
    5ab4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ab8:	d65f03c0 	ret
    5abc:	72003c3f 	tst	w1, #0xffff
    5ac0:	54fffe60 	b.eq	5a8c <fwp_drop0+0x78>  // b.none
    5ac4:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ac8:	f94013f5 	ldr	x21, [sp, #32]
    5acc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ad0:	d65f03c0 	ret
    5ad4:	f9400813 	ldr	x19, [x0, #16]
    5ad8:	97ffff87 	bl	58f4 <fwp_rc_free_arr>
    5adc:	9117c2a0 	add	x0, x21, #0x5f0
    5ae0:	f949d801 	ldr	x1, [x0, #5040]
    5ae4:	f949ec00 	ldr	x0, [x0, #5080]
    5ae8:	cb010261 	sub	x1, x19, x1
    5aec:	eb00403f 	cmp	x1, x0, lsl #16
    5af0:	54fffde2 	b.cs	5aac <fwp_drop0+0x98>  // b.hs, b.nlast
    5af4:	aa1303e0 	mov	x0, x19
    5af8:	17ffffd2 	b	5a40 <fwp_drop0+0x2c>
    5afc:	ca534660 	eor	x0, x19, x19, lsr #17
    5b00:	9117c2b5 	add	x21, x21, #0x5f0
    5b04:	ca402400 	eor	x0, x0, x0, lsr #9
    5b08:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5b0c:	f94a2400 	ldr	x0, [x0, #5192]
    5b10:	b5000080 	cbnz	x0, 5b20 <fwp_drop0+0x10c>
    5b14:	14000010 	b	5b54 <fwp_drop0+0x140>
    5b18:	f9400800 	ldr	x0, [x0, #16]
    5b1c:	b40001c0 	cbz	x0, 5b54 <fwp_drop0+0x140>
    5b20:	f9400001 	ldr	x1, [x0]
    5b24:	eb13003f 	cmp	x1, x19
    5b28:	54ffff81 	b.ne	5b18 <fwp_drop0+0x104>  // b.any
    5b2c:	f9400401 	ldr	x1, [x0, #8]
    5b30:	d1000421 	sub	x1, x1, #0x1
    5b34:	f9000401 	str	x1, [x0, #8]
    5b38:	f103f83f 	cmp	x1, #0xfe
    5b3c:	54fffb81 	b.ne	5aac <fwp_drop0+0x98>  // b.any
    5b40:	aa1303e0 	mov	x0, x19
    5b44:	97fffb3f 	bl	4840 <fwp_rc_forget_slot>
    5b48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b4c:	39000260 	strb	w0, [x19]
    5b50:	17ffffd7 	b	5aac <fwp_drop0+0x98>
    5b54:	d0000020 	adrp	x0, b000 <__divti3+0x190>
    5b58:	9123c000 	add	x0, x0, #0x8f0
    5b5c:	97fff729 	bl	3800 <fwp_trap>

0000000000005b60 <fwp_arg_drop12>:
    5b60:	7100003f 	cmp	w1, #0x0
    5b64:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5b68:	54000041 	b.ne	5b70 <fwp_arg_drop12+0x10>  // b.any
    5b6c:	d65f03c0 	ret
    5b70:	f9400000 	ldr	x0, [x0]
    5b74:	17ffffa8 	b	5a14 <fwp_drop0>
    5b78:	d503201f 	nop
    5b7c:	d503201f 	nop

0000000000005b80 <fwp_drop1>:
    5b80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b84:	910003fd 	mov	x29, sp
    5b88:	a90153f3 	stp	x19, x20, [sp, #16]
    5b8c:	f90013f5 	str	x21, [sp, #32]
    5b90:	90000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    5b94:	9117c2b4 	add	x20, x21, #0x5f0
    5b98:	f949da81 	ldr	x1, [x20, #5040]
    5b9c:	f949ee82 	ldr	x2, [x20, #5080]
    5ba0:	cb010001 	sub	x1, x0, x1
    5ba4:	eb02403f 	cmp	x1, x2, lsl #16
    5ba8:	54000382 	b.cs	5c18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5bac:	d350fc22 	lsr	x2, x1, #16
    5bb0:	f949fe84 	ldr	x4, [x20, #5112]
    5bb4:	8b020842 	add	x2, x2, x2, lsl #2
    5bb8:	d37df042 	lsl	x2, x2, #3
    5bbc:	8b020083 	add	x3, x4, x2
    5bc0:	f9401073 	ldr	x19, [x3, #32]
    5bc4:	b40002b3 	cbz	x19, 5c18 <fwp_drop1+0x98>
    5bc8:	38626882 	ldrb	w2, [x4, x2]
    5bcc:	7100085f 	cmp	w2, #0x2
    5bd0:	540002c0 	b.eq	5c28 <fwp_drop1+0xa8>  // b.none
    5bd4:	7100045f 	cmp	w2, #0x1
    5bd8:	54000201 	b.ne	5c18 <fwp_drop1+0x98>  // b.any
    5bdc:	29430864 	ldp	w4, w2, [x3, #24]
    5be0:	92403c21 	and	x1, x1, #0xffff
    5be4:	9b047c21 	mul	x1, x1, x4
    5be8:	d360fc21 	lsr	x1, x1, #32
    5bec:	eb02003f 	cmp	x1, x2
    5bf0:	54000142 	b.cs	5c18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5bf4:	8b010273 	add	x19, x19, x1
    5bf8:	39400261 	ldrb	w1, [x19]
    5bfc:	340000e1 	cbz	w1, 5c18 <fwp_drop1+0x98>
    5c00:	7100043f 	cmp	w1, #0x1
    5c04:	540001e0 	b.eq	5c40 <fwp_drop1+0xc0>  // b.none
    5c08:	7103fc3f 	cmp	w1, #0xff
    5c0c:	540002e0 	b.eq	5c68 <fwp_drop1+0xe8>  // b.none
    5c10:	51000421 	sub	w1, w1, #0x1
    5c14:	39000261 	strb	w1, [x19]
    5c18:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c1c:	f94013f5 	ldr	x21, [sp, #32]
    5c20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c24:	d65f03c0 	ret
    5c28:	72003c3f 	tst	w1, #0xffff
    5c2c:	54fffe60 	b.eq	5bf8 <fwp_drop1+0x78>  // b.none
    5c30:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c34:	f94013f5 	ldr	x21, [sp, #32]
    5c38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c3c:	d65f03c0 	ret
    5c40:	f9400813 	ldr	x19, [x0, #16]
    5c44:	97ffff2c 	bl	58f4 <fwp_rc_free_arr>
    5c48:	9117c2a0 	add	x0, x21, #0x5f0
    5c4c:	f949d801 	ldr	x1, [x0, #5040]
    5c50:	f949ec00 	ldr	x0, [x0, #5080]
    5c54:	cb010261 	sub	x1, x19, x1
    5c58:	eb00403f 	cmp	x1, x0, lsl #16
    5c5c:	54fffde2 	b.cs	5c18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c60:	aa1303e0 	mov	x0, x19
    5c64:	17ffffd2 	b	5bac <fwp_drop1+0x2c>
    5c68:	ca534660 	eor	x0, x19, x19, lsr #17
    5c6c:	9117c2b5 	add	x21, x21, #0x5f0
    5c70:	ca402400 	eor	x0, x0, x0, lsr #9
    5c74:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5c78:	f94a2400 	ldr	x0, [x0, #5192]
    5c7c:	b5000080 	cbnz	x0, 5c8c <fwp_drop1+0x10c>
    5c80:	14000010 	b	5cc0 <fwp_drop1+0x140>
    5c84:	f9400800 	ldr	x0, [x0, #16]
    5c88:	b40001c0 	cbz	x0, 5cc0 <fwp_drop1+0x140>
    5c8c:	f9400001 	ldr	x1, [x0]
    5c90:	eb13003f 	cmp	x1, x19
    5c94:	54ffff81 	b.ne	5c84 <fwp_drop1+0x104>  // b.any
    5c98:	f9400401 	ldr	x1, [x0, #8]
    5c9c:	d1000421 	sub	x1, x1, #0x1
    5ca0:	f9000401 	str	x1, [x0, #8]
    5ca4:	f103f83f 	cmp	x1, #0xfe
    5ca8:	54fffb81 	b.ne	5c18 <fwp_drop1+0x98>  // b.any
    5cac:	aa1303e0 	mov	x0, x19
    5cb0:	97fffae4 	bl	4840 <fwp_rc_forget_slot>
    5cb4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5cb8:	39000260 	strb	w0, [x19]
    5cbc:	17ffffd7 	b	5c18 <fwp_drop1+0x98>
    5cc0:	d0000020 	adrp	x0, b000 <__divti3+0x190>
    5cc4:	9123c000 	add	x0, x0, #0x8f0
    5cc8:	97fff6ce 	bl	3800 <fwp_trap>
    5ccc:	d503201f 	nop

0000000000005cd0 <fwp_closure_drop>:
    5cd0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xbf0>
    5cd4:	9117c0a4 	add	x4, x5, #0x5f0
    5cd8:	aa0003e1 	mov	x1, x0
    5cdc:	f949d882 	ldr	x2, [x4, #5040]
    5ce0:	f949ec80 	ldr	x0, [x4, #5080]
    5ce4:	cb020022 	sub	x2, x1, x2
    5ce8:	eb00405f 	cmp	x2, x0, lsl #16
    5cec:	54000662 	b.cs	5db8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5cf0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5cf4:	d350fc43 	lsr	x3, x2, #16
    5cf8:	910003fd 	mov	x29, sp
    5cfc:	8b030863 	add	x3, x3, x3, lsl #2
    5d00:	f949fc84 	ldr	x4, [x4, #5112]
    5d04:	d37df063 	lsl	x3, x3, #3
    5d08:	f9000bf3 	str	x19, [sp, #16]
    5d0c:	8b030080 	add	x0, x4, x3
    5d10:	f9401013 	ldr	x19, [x0, #32]
    5d14:	b40002b3 	cbz	x19, 5d68 <fwp_closure_drop+0x98>
    5d18:	38636883 	ldrb	w3, [x4, x3]
    5d1c:	7100087f 	cmp	w3, #0x2
    5d20:	54000420 	b.eq	5da4 <fwp_closure_drop+0xd4>  // b.none
    5d24:	7100047f 	cmp	w3, #0x1
    5d28:	54000201 	b.ne	5d68 <fwp_closure_drop+0x98>  // b.any
    5d2c:	29430003 	ldp	w3, w0, [x0, #24]
    5d30:	92403c42 	and	x2, x2, #0xffff
    5d34:	9b037c42 	mul	x2, x2, x3
    5d38:	d360fc42 	lsr	x2, x2, #32
    5d3c:	eb00005f 	cmp	x2, x0
    5d40:	54000142 	b.cs	5d68 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5d44:	8b020273 	add	x19, x19, x2
    5d48:	39400260 	ldrb	w0, [x19]
    5d4c:	340000e0 	cbz	w0, 5d68 <fwp_closure_drop+0x98>
    5d50:	7100041f 	cmp	w0, #0x1
    5d54:	54000100 	b.eq	5d74 <fwp_closure_drop+0xa4>  // b.none
    5d58:	7103fc1f 	cmp	w0, #0xff
    5d5c:	54000300 	b.eq	5dbc <fwp_closure_drop+0xec>  // b.none
    5d60:	51000400 	sub	w0, w0, #0x1
    5d64:	39000260 	strb	w0, [x19]
    5d68:	f9400bf3 	ldr	x19, [sp, #16]
    5d6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d70:	d65f03c0 	ret
    5d74:	d53bd040 	mrs	x0, tpidr_el0
    5d78:	91400000 	add	x0, x0, #0x0, lsl #12
    5d7c:	91004000 	add	x0, x0, #0x10
    5d80:	f9400000 	ldr	x0, [x0]
    5d84:	b4000080 	cbz	x0, 5d94 <fwp_closure_drop+0xc4>
    5d88:	f9400bf3 	ldr	x19, [sp, #16]
    5d8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d90:	17fff6b5 	b	3864 <fwp_closure_drop_push>
    5d94:	f9400bf3 	ldr	x19, [sp, #16]
    5d98:	aa0103e0 	mov	x0, x1
    5d9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5da0:	17fff720 	b	3a20 <fwp_closure_drop.part.0>
    5da4:	72003c5f 	tst	w2, #0xffff
    5da8:	54fffd00 	b.eq	5d48 <fwp_closure_drop+0x78>  // b.none
    5dac:	f9400bf3 	ldr	x19, [sp, #16]
    5db0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5db4:	d65f03c0 	ret
    5db8:	d65f03c0 	ret
    5dbc:	ca534660 	eor	x0, x19, x19, lsr #17
    5dc0:	9117c0a5 	add	x5, x5, #0x5f0
    5dc4:	ca402400 	eor	x0, x0, x0, lsr #9
    5dc8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5dcc:	f94a2400 	ldr	x0, [x0, #5192]
    5dd0:	b5000080 	cbnz	x0, 5de0 <fwp_closure_drop+0x110>
    5dd4:	14000010 	b	5e14 <fwp_closure_drop+0x144>
    5dd8:	f9400800 	ldr	x0, [x0, #16]
    5ddc:	b40001c0 	cbz	x0, 5e14 <fwp_closure_drop+0x144>
    5de0:	f9400001 	ldr	x1, [x0]
    5de4:	eb13003f 	cmp	x1, x19
    5de8:	54ffff81 	b.ne	5dd8 <fwp_closure_drop+0x108>  // b.any
    5dec:	f9400401 	ldr	x1, [x0, #8]
    5df0:	d1000421 	sub	x1, x1, #0x1
    5df4:	f9000401 	str	x1, [x0, #8]
    5df8:	f103f83f 	cmp	x1, #0xfe
    5dfc:	54fffb61 	b.ne	5d68 <fwp_closure_drop+0x98>  // b.any
    5e00:	aa1303e0 	mov	x0, x19
    5e04:	97fffa8f 	bl	4840 <fwp_rc_forget_slot>
    5e08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e0c:	39000260 	strb	w0, [x19]
    5e10:	17ffffd6 	b	5d68 <fwp_closure_drop+0x98>
    5e14:	d0000020 	adrp	x0, b000 <__divti3+0x190>
    5e18:	9123c000 	add	x0, x0, #0x8f0
    5e1c:	97fff679 	bl	3800 <fwp_trap>

0000000000005e20 <fwp_owned_tape_release>:
    5e20:	b4000940 	cbz	x0, 5f48 <fwp_owned_tape_release+0x128>
    5e24:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e28:	910003fd 	mov	x29, sp
    5e2c:	a90153f3 	stp	x19, x20, [sp, #16]
    5e30:	aa0003f3 	mov	x19, x0
    5e34:	f9400000 	ldr	x0, [x0]
    5e38:	b4000060 	cbz	x0, 5e44 <fwp_owned_tape_release+0x24>
    5e3c:	f9400661 	ldr	x1, [x19, #8]
    5e40:	f9000401 	str	x1, [x0, #8]
    5e44:	f9400661 	ldr	x1, [x19, #8]
    5e48:	b4000041 	cbz	x1, 5e50 <fwp_owned_tape_release+0x30>
    5e4c:	f9000020 	str	x0, [x1]
    5e50:	f9400a60 	ldr	x0, [x19, #16]
    5e54:	f9403401 	ldr	x1, [x0, #104]
    5e58:	b40005c1 	cbz	x1, 5f10 <fwp_owned_tape_release+0xf0>
    5e5c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5e60:	eb00005f 	cmp	x2, x0
    5e64:	540002ed 	b.le	5ec0 <fwp_owned_tape_release+0xa0>
    5e68:	d2800014 	mov	x20, #0x0                   	// #0
    5e6c:	f90013f5 	str	x21, [sp, #32]
    5e70:	d2800015 	mov	x21, #0x0                   	// #0
    5e74:	d503201f 	nop
    5e78:	f9402260 	ldr	x0, [x19, #64]
    5e7c:	910006b5 	add	x21, x21, #0x1
    5e80:	f8746800 	ldr	x0, [x0, x20]
    5e84:	d63f0020 	blr	x1
    5e88:	f9402260 	ldr	x0, [x19, #64]
    5e8c:	f9400a61 	ldr	x1, [x19, #16]
    5e90:	8b140000 	add	x0, x0, x20
    5e94:	91004294 	add	x20, x20, #0x10
    5e98:	f9400400 	ldr	x0, [x0, #8]
    5e9c:	f9403421 	ldr	x1, [x1, #104]
    5ea0:	d63f0020 	blr	x1
    5ea4:	a9450261 	ldp	x1, x0, [x19, #80]
    5ea8:	cb010000 	sub	x0, x0, x1
    5eac:	eb15001f 	cmp	x0, x21
    5eb0:	f9400a60 	ldr	x0, [x19, #16]
    5eb4:	f9403401 	ldr	x1, [x0, #104]
    5eb8:	54fffe0c 	b.gt	5e78 <fwp_owned_tape_release+0x58>
    5ebc:	f94013f5 	ldr	x21, [sp, #32]
    5ec0:	f9403663 	ldr	x3, [x19, #104]
    5ec4:	f9401262 	ldr	x2, [x19, #32]
    5ec8:	f100007f 	cmp	x3, #0x0
    5ecc:	540001ed 	b.le	5f08 <fwp_owned_tape_release+0xe8>
    5ed0:	d2800014 	mov	x20, #0x0                   	// #0
    5ed4:	d503201f 	nop
    5ed8:	f9402660 	ldr	x0, [x19, #72]
    5edc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5ee0:	eb02001f 	cmp	x0, x2
    5ee4:	540000c0 	b.eq	5efc <fwp_owned_tape_release+0xdc>  // b.none
    5ee8:	d63f0020 	blr	x1
    5eec:	f9400a60 	ldr	x0, [x19, #16]
    5ef0:	f9401262 	ldr	x2, [x19, #32]
    5ef4:	f9403663 	ldr	x3, [x19, #104]
    5ef8:	f9403401 	ldr	x1, [x0, #104]
    5efc:	91000694 	add	x20, x20, #0x1
    5f00:	eb14007f 	cmp	x3, x20
    5f04:	54fffeac 	b.gt	5ed8 <fwp_owned_tape_release+0xb8>
    5f08:	aa0203e0 	mov	x0, x2
    5f0c:	d63f0020 	blr	x1
    5f10:	f9401660 	ldr	x0, [x19, #40]
    5f14:	97ffff6f 	bl	5cd0 <fwp_closure_drop>
    5f18:	f9401a60 	ldr	x0, [x19, #48]
    5f1c:	97ffff6d 	bl	5cd0 <fwp_closure_drop>
    5f20:	f9401e60 	ldr	x0, [x19, #56]
    5f24:	97ffff6b 	bl	5cd0 <fwp_closure_drop>
    5f28:	f9402260 	ldr	x0, [x19, #64]
    5f2c:	97fffae5 	bl	4ac0 <fwp_mem_free>
    5f30:	f9402660 	ldr	x0, [x19, #72]
    5f34:	97fffae3 	bl	4ac0 <fwp_mem_free>
    5f38:	aa1303e0 	mov	x0, x19
    5f3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f44:	17fffadf 	b	4ac0 <fwp_mem_free>
    5f48:	d65f03c0 	ret
    5f4c:	d503201f 	nop

0000000000005f50 <fwp_tape_finish>:
    5f50:	d10203ff 	sub	sp, sp, #0x80
    5f54:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5f58:	f947f421 	ldr	x1, [x1, #4072]
    5f5c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f60:	910103fd 	add	x29, sp, #0x40
    5f64:	a90553f3 	stp	x19, x20, [sp, #80]
    5f68:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f6c:	a90763f7 	stp	x23, x24, [sp, #112]
    5f70:	f00000d8 	adrp	x24, 20000 <__data_start>
    5f74:	9101c316 	add	x22, x24, #0x70
    5f78:	f9400022 	ldr	x2, [x1]
    5f7c:	f9001fe2 	str	x2, [sp, #56]
    5f80:	d2800002 	mov	x2, #0x0                   	// #0
    5f84:	9102e2c0 	add	x0, x22, #0xb8
    5f88:	97fff53e 	bl	3480 <fwp_tape_buffers_dispose>
    5f8c:	f9007adf 	str	xzr, [x22, #240]
    5f90:	f9404ac0 	ldr	x0, [x22, #144]
    5f94:	f100001f 	cmp	x0, #0x0
    5f98:	5400030d 	b.le	5ff8 <fwp_tape_finish+0xa8>
    5f9c:	910003f7 	mov	x23, sp
    5fa0:	d2800015 	mov	x21, #0x0                   	// #0
    5fa4:	d2800014 	mov	x20, #0x0                   	// #0
    5fa8:	f94002d3 	ldr	x19, [x22]
    5fac:	91000694 	add	x20, x20, #0x1
    5fb0:	8b150273 	add	x19, x19, x21
    5fb4:	9101a2b5 	add	x21, x21, #0x68
    5fb8:	aa1303e0 	mov	x0, x19
    5fbc:	97fff3f5 	bl	2f90 <fwp_tape_unlink_scope>
    5fc0:	aa1703e0 	mov	x0, x23
    5fc4:	f9401261 	ldr	x1, [x19, #32]
    5fc8:	f90003e1 	str	x1, [sp]
    5fcc:	f9401a62 	ldr	x2, [x19, #48]
    5fd0:	f9000be2 	str	x2, [sp, #16]
    5fd4:	f9402261 	ldr	x1, [x19, #64]
    5fd8:	f90013e1 	str	x1, [sp, #32]
    5fdc:	97fff529 	bl	3480 <fwp_tape_buffers_dispose>
    5fe0:	f9403260 	ldr	x0, [x19, #96]
    5fe4:	97ffff8f 	bl	5e20 <fwp_owned_tape_release>
    5fe8:	f900327f 	str	xzr, [x19, #96]
    5fec:	f9404ac0 	ldr	x0, [x22, #144]
    5ff0:	eb14001f 	cmp	x0, x20
    5ff4:	54fffdac 	b.gt	5fa8 <fwp_tape_finish+0x58>
    5ff8:	f9403b00 	ldr	x0, [x24, #112]
    5ffc:	9101c313 	add	x19, x24, #0x70
    6000:	97fff250 	bl	2940 <free@plt>
    6004:	f9003b1f 	str	xzr, [x24, #112]
    6008:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    600c:	f947f400 	ldr	x0, [x0, #4072]
    6010:	f9004a7f 	str	xzr, [x19, #144]
    6014:	a9107e7f 	stp	xzr, xzr, [x19, #256]
    6018:	f9401fe2 	ldr	x2, [sp, #56]
    601c:	f9400001 	ldr	x1, [x0]
    6020:	eb010042 	subs	x2, x2, x1
    6024:	d2800001 	mov	x1, #0x0                   	// #0
    6028:	540000e1 	b.ne	6044 <fwp_tape_finish+0xf4>  // b.any
    602c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6030:	a94553f3 	ldp	x19, x20, [sp, #80]
    6034:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6038:	a94763f7 	ldp	x23, x24, [sp, #112]
    603c:	910203ff 	add	sp, sp, #0x80
    6040:	d65f03c0 	ret
    6044:	97fff20f 	bl	2880 <__stack_chk_fail@plt>
    6048:	d503201f 	nop
    604c:	d503201f 	nop

0000000000006050 <fwp_tape_scope_release>:
    6050:	d10243ff 	sub	sp, sp, #0x90
    6054:	a9047bfd 	stp	x29, x30, [sp, #64]
    6058:	910103fd 	add	x29, sp, #0x40
    605c:	a90553f3 	stp	x19, x20, [sp, #80]
    6060:	aa0003f4 	mov	x20, x0
    6064:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6068:	f947f400 	ldr	x0, [x0, #4072]
    606c:	b9400285 	ldr	w5, [x20]
    6070:	f9400001 	ldr	x1, [x0]
    6074:	f9001fe1 	str	x1, [sp, #56]
    6078:	d2800001 	mov	x1, #0x0                   	// #0
    607c:	37f806c5 	tbnz	w5, #31, 6154 <fwp_tape_scope_release+0x104>
    6080:	a90763f7 	stp	x23, x24, [sp, #112]
    6084:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6088:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    608c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6090:	d00000d3 	adrp	x19, 20000 <__data_start>
    6094:	910003f7 	mov	x23, sp
    6098:	9101c273 	add	x19, x19, #0x70
    609c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    60a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    60a4:	52800d16 	mov	w22, #0x68                  	// #104
    60a8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    60ac:	f90043f9 	str	x25, [sp, #128]
    60b0:	14000006 	b	60c8 <fwp_tape_scope_release+0x78>
    60b4:	97fff4f3 	bl	3480 <fwp_tape_buffers_dispose>
    60b8:	aa1903e0 	mov	x0, x25
    60bc:	97ffff59 	bl	5e20 <fwp_owned_tape_release>
    60c0:	b9400285 	ldr	w5, [x20]
    60c4:	37f80425 	tbnz	w5, #31, 6148 <fwp_tape_scope_release+0xf8>
    60c8:	f9400266 	ldr	x6, [x19]
    60cc:	9b367ca5 	smull	x5, w5, w22
    60d0:	8b0500c0 	add	x0, x6, x5
    60d4:	97fff3af 	bl	2f90 <fwp_tape_unlink_scope>
    60d8:	ad410001 	ldp	q1, q0, [x0, #32]
    60dc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    60e0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    60e4:	f9400c03 	ldr	x3, [x0, #24]
    60e8:	ad0003e1 	stp	q1, q0, [sp]
    60ec:	b86568c1 	ldr	w1, [x6, x5]
    60f0:	a9440804 	ldp	x4, x2, [x0, #64]
    60f4:	b900041f 	str	wzr, [x0, #4]
    60f8:	f9403019 	ldr	x25, [x0, #96]
    60fc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6100:	f9000c1f 	str	xzr, [x0, #24]
    6104:	a9020fe4 	stp	x4, x3, [sp, #32]
    6108:	f9001be2 	str	x2, [sp, #48]
    610c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6110:	f900301f 	str	xzr, [x0, #96]
    6114:	6b15003f 	cmp	w1, w21
    6118:	540000e8 	b.hi	6134 <fwp_tape_scope_release+0xe4>  // b.pmore
    611c:	9343fca5 	asr	x5, x5, #3
    6120:	f9408660 	ldr	x0, [x19, #264]
    6124:	9b187ca5 	mul	x5, x5, x24
    6128:	eb0000bf 	cmp	x5, x0
    612c:	5400004a 	b.ge	6134 <fwp_tape_scope_release+0xe4>  // b.tcont
    6130:	f9008665 	str	x5, [x19, #264]
    6134:	aa1703e0 	mov	x0, x23
    6138:	b5fffbf9 	cbnz	x25, 60b4 <fwp_tape_scope_release+0x64>
    613c:	97fff8a5 	bl	43d0 <fwp_tape_buffers_release>
    6140:	b9400285 	ldr	w5, [x20]
    6144:	36fffc25 	tbz	w5, #31, 60c8 <fwp_tape_scope_release+0x78>
    6148:	a9465bf5 	ldp	x21, x22, [sp, #96]
    614c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6150:	f94043f9 	ldr	x25, [sp, #128]
    6154:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6158:	f947f400 	ldr	x0, [x0, #4072]
    615c:	f9401fe2 	ldr	x2, [sp, #56]
    6160:	f9400001 	ldr	x1, [x0]
    6164:	eb010042 	subs	x2, x2, x1
    6168:	d2800001 	mov	x1, #0x0                   	// #0
    616c:	540000a1 	b.ne	6180 <fwp_tape_scope_release+0x130>  // b.any
    6170:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6174:	a94553f3 	ldp	x19, x20, [sp, #80]
    6178:	910243ff 	add	sp, sp, #0x90
    617c:	d65f03c0 	ret
    6180:	a9065bf5 	stp	x21, x22, [sp, #96]
    6184:	a90763f7 	stp	x23, x24, [sp, #112]
    6188:	f90043f9 	str	x25, [sp, #128]
    618c:	97fff1bd 	bl	2880 <__stack_chk_fail@plt>

0000000000006190 <fwp_task_dispose>:
    6190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6194:	910003fd 	mov	x29, sp
    6198:	f9000bf3 	str	x19, [sp, #16]
    619c:	aa0003f3 	mov	x19, x0
    61a0:	39414000 	ldrb	w0, [x0, #80]
    61a4:	36000720 	tbz	w0, #0, 6288 <fwp_task_dispose+0xf8>
    61a8:	f9400a60 	ldr	x0, [x19, #16]
    61ac:	b50006e0 	cbnz	x0, 6288 <fwp_task_dispose+0xf8>
    61b0:	a9478660 	ldp	x0, x1, [x19, #120]
    61b4:	39014e7f 	strb	wzr, [x19, #83]
    61b8:	f9003e7f 	str	xzr, [x19, #120]
    61bc:	f100003f 	cmp	x1, #0x0
    61c0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    61c4:	54000040 	b.eq	61cc <fwp_task_dispose+0x3c>  // b.none
    61c8:	d63f0020 	blr	x1
    61cc:	f9405660 	ldr	x0, [x19, #168]
    61d0:	97fffa3c 	bl	4ac0 <fwp_mem_free>
    61d4:	f900567f 	str	xzr, [x19, #168]
    61d8:	b9405e60 	ldr	w0, [x19, #92]
    61dc:	7100041f 	cmp	w0, #0x1
    61e0:	54000420 	b.eq	6264 <fwp_task_dispose+0xd4>  // b.none
    61e4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    61e8:	9117c042 	add	x2, x2, #0x5f0
    61ec:	f949d840 	ldr	x0, [x2, #5040]
    61f0:	f949ec41 	ldr	x1, [x2, #5080]
    61f4:	cb000260 	sub	x0, x19, x0
    61f8:	eb01401f 	cmp	x0, x1, lsl #16
    61fc:	540002e2 	b.cs	6258 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6200:	d350fc01 	lsr	x1, x0, #16
    6204:	f949fc44 	ldr	x4, [x2, #5112]
    6208:	8b010821 	add	x1, x1, x1, lsl #2
    620c:	d37df021 	lsl	x1, x1, #3
    6210:	8b010083 	add	x3, x4, x1
    6214:	f9401062 	ldr	x2, [x3, #32]
    6218:	b4000202 	cbz	x2, 6258 <fwp_task_dispose+0xc8>
    621c:	38616881 	ldrb	w1, [x4, x1]
    6220:	7100083f 	cmp	w1, #0x2
    6224:	54000280 	b.eq	6274 <fwp_task_dispose+0xe4>  // b.none
    6228:	7100043f 	cmp	w1, #0x1
    622c:	54000161 	b.ne	6258 <fwp_task_dispose+0xc8>  // b.any
    6230:	29430464 	ldp	w4, w1, [x3, #24]
    6234:	92403c00 	and	x0, x0, #0xffff
    6238:	9b047c00 	mul	x0, x0, x4
    623c:	d360fc00 	lsr	x0, x0, #32
    6240:	eb01001f 	cmp	x0, x1
    6244:	540000a2 	b.cs	6258 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6248:	8b000042 	add	x2, x2, x0
    624c:	39400040 	ldrb	w0, [x2]
    6250:	7100041f 	cmp	w0, #0x1
    6254:	54000080 	b.eq	6264 <fwp_task_dispose+0xd4>  // b.none
    6258:	f9400bf3 	ldr	x19, [sp, #16]
    625c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6260:	d65f03c0 	ret
    6264:	aa1303e0 	mov	x0, x19
    6268:	f9400bf3 	ldr	x19, [sp, #16]
    626c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6270:	17fffa14 	b	4ac0 <fwp_mem_free>
    6274:	72003c1f 	tst	w0, #0xffff
    6278:	54fffea0 	b.eq	624c <fwp_task_dispose+0xbc>  // b.none
    627c:	f9400bf3 	ldr	x19, [sp, #16]
    6280:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6284:	d65f03c0 	ret
    6288:	97fff192 	bl	28d0 <abort@plt>
    628c:	d503201f 	nop

0000000000006290 <fwp_free_zombie>:
    6290:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6294:	910003fd 	mov	x29, sp
    6298:	a90153f3 	stp	x19, x20, [sp, #16]
    629c:	d00000d4 	adrp	x20, 20000 <__data_start>
    62a0:	9101c281 	add	x1, x20, #0x70
    62a4:	f9408833 	ldr	x19, [x1, #272]
    62a8:	b4000333 	cbz	x19, 630c <fwp_free_zombie+0x7c>
    62ac:	f9400820 	ldr	x0, [x1, #16]
    62b0:	eb00027f 	cmp	x19, x0
    62b4:	540002c0 	b.eq	630c <fwp_free_zombie+0x7c>  // b.none
    62b8:	b9411822 	ldr	w2, [x1, #280]
    62bc:	f9400a60 	ldr	x0, [x19, #16]
    62c0:	7100fc5f 	cmp	w2, #0x3f
    62c4:	5400078c 	b.gt	63b4 <fwp_free_zombie+0x124>
    62c8:	91048023 	add	x3, x1, #0x120
    62cc:	11000444 	add	w4, w2, #0x1
    62d0:	b9011824 	str	w4, [x1, #280]
    62d4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    62d8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    62dc:	a9530261 	ldp	x1, x0, [x19, #304]
    62e0:	b4000741 	cbz	x1, 63c8 <fwp_free_zombie+0x138>
    62e4:	f9009c20 	str	x0, [x1, #312]
    62e8:	b4000040 	cbz	x0, 62f0 <fwp_free_zombie+0x60>
    62ec:	f9009801 	str	x1, [x0, #304]
    62f0:	9101c294 	add	x20, x20, #0x70
    62f4:	b9405e60 	ldr	w0, [x19, #92]
    62f8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    62fc:	f9008a9f 	str	xzr, [x20, #272]
    6300:	34000140 	cbz	w0, 6328 <fwp_free_zombie+0x98>
    6304:	7100041f 	cmp	w0, #0x1
    6308:	54000080 	b.eq	6318 <fwp_free_zombie+0x88>  // b.none
    630c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6310:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6314:	d65f03c0 	ret
    6318:	aa1303e0 	mov	x0, x19
    631c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6320:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6324:	17ffff9b 	b	6190 <fwp_task_dispose>
    6328:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xbf0>
    632c:	9117c082 	add	x2, x4, #0x5f0
    6330:	f949d841 	ldr	x1, [x2, #5040]
    6334:	f949ec40 	ldr	x0, [x2, #5080]
    6338:	cb010261 	sub	x1, x19, x1
    633c:	eb00403f 	cmp	x1, x0, lsl #16
    6340:	54fffe62 	b.cs	630c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6344:	d350fc20 	lsr	x0, x1, #16
    6348:	f949fc43 	ldr	x3, [x2, #5112]
    634c:	8b000800 	add	x0, x0, x0, lsl #2
    6350:	d37df000 	lsl	x0, x0, #3
    6354:	8b000062 	add	x2, x3, x0
    6358:	f9401054 	ldr	x20, [x2, #32]
    635c:	b4fffd94 	cbz	x20, 630c <fwp_free_zombie+0x7c>
    6360:	38606860 	ldrb	w0, [x3, x0]
    6364:	7100081f 	cmp	w0, #0x2
    6368:	54000360 	b.eq	63d4 <fwp_free_zombie+0x144>  // b.none
    636c:	7100041f 	cmp	w0, #0x1
    6370:	54fffce1 	b.ne	630c <fwp_free_zombie+0x7c>  // b.any
    6374:	29430043 	ldp	w3, w0, [x2, #24]
    6378:	92403c21 	and	x1, x1, #0xffff
    637c:	9b037c21 	mul	x1, x1, x3
    6380:	d360fc21 	lsr	x1, x1, #32
    6384:	eb00003f 	cmp	x1, x0
    6388:	54fffc22 	b.cs	630c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    638c:	8b010294 	add	x20, x20, x1
    6390:	39400280 	ldrb	w0, [x20]
    6394:	34fffbc0 	cbz	w0, 630c <fwp_free_zombie+0x7c>
    6398:	7100041f 	cmp	w0, #0x1
    639c:	54fffbe0 	b.eq	6318 <fwp_free_zombie+0x88>  // b.none
    63a0:	7103fc1f 	cmp	w0, #0xff
    63a4:	540001e0 	b.eq	63e0 <fwp_free_zombie+0x150>  // b.none
    63a8:	51000400 	sub	w0, w0, #0x1
    63ac:	39000280 	strb	w0, [x20]
    63b0:	17ffffd7 	b	630c <fwp_free_zombie+0x7c>
    63b4:	f9400e61 	ldr	x1, [x19, #24]
    63b8:	97fff17a 	bl	29a0 <munmap@plt>
    63bc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    63c0:	a9530261 	ldp	x1, x0, [x19, #304]
    63c4:	b5fff901 	cbnz	x1, 62e4 <fwp_free_zombie+0x54>
    63c8:	9101c282 	add	x2, x20, #0x70
    63cc:	f9019040 	str	x0, [x2, #800]
    63d0:	17ffffc6 	b	62e8 <fwp_free_zombie+0x58>
    63d4:	72003c3f 	tst	w1, #0xffff
    63d8:	54fff9a1 	b.ne	630c <fwp_free_zombie+0x7c>  // b.any
    63dc:	17ffffed 	b	6390 <fwp_free_zombie+0x100>
    63e0:	ca544680 	eor	x0, x20, x20, lsr #17
    63e4:	9117c084 	add	x4, x4, #0x5f0
    63e8:	ca402400 	eor	x0, x0, x0, lsr #9
    63ec:	8b200c80 	add	x0, x4, w0, uxtb #3
    63f0:	f94a2400 	ldr	x0, [x0, #5192]
    63f4:	b5000080 	cbnz	x0, 6404 <fwp_free_zombie+0x174>
    63f8:	14000010 	b	6438 <fwp_free_zombie+0x1a8>
    63fc:	f9400800 	ldr	x0, [x0, #16]
    6400:	b40001c0 	cbz	x0, 6438 <fwp_free_zombie+0x1a8>
    6404:	f9400001 	ldr	x1, [x0]
    6408:	eb14003f 	cmp	x1, x20
    640c:	54ffff81 	b.ne	63fc <fwp_free_zombie+0x16c>  // b.any
    6410:	f9400401 	ldr	x1, [x0, #8]
    6414:	d1000421 	sub	x1, x1, #0x1
    6418:	f9000401 	str	x1, [x0, #8]
    641c:	f103f83f 	cmp	x1, #0xfe
    6420:	54fff761 	b.ne	630c <fwp_free_zombie+0x7c>  // b.any
    6424:	aa1403e0 	mov	x0, x20
    6428:	97fff906 	bl	4840 <fwp_rc_forget_slot>
    642c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6430:	39000280 	strb	w0, [x20]
    6434:	17ffffb6 	b	630c <fwp_free_zombie+0x7c>
    6438:	b0000020 	adrp	x0, b000 <__divti3+0x190>
    643c:	9123c000 	add	x0, x0, #0x8f0
    6440:	97fff4f0 	bl	3800 <fwp_trap>

0000000000006444 <fwp_block>:
    6444:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6448:	910003fd 	mov	x29, sp
    644c:	a90153f3 	stp	x19, x20, [sp, #16]
    6450:	d00000d3 	adrp	x19, 20000 <__data_start>
    6454:	9101c274 	add	x20, x19, #0x70
    6458:	f9404282 	ldr	x2, [x20, #128]
    645c:	b4000622 	cbz	x2, 6520 <fwp_block+0xdc>
    6460:	9101c261 	add	x1, x19, #0x70
    6464:	f9408040 	ldr	x0, [x2, #256]
    6468:	f9004020 	str	x0, [x1, #128]
    646c:	b4000680 	cbz	x0, 653c <fwp_block+0xf8>
    6470:	9101c263 	add	x3, x19, #0x70
    6474:	3901505f 	strb	wzr, [x2, #84]
    6478:	f9400864 	ldr	x4, [x3, #16]
    647c:	eb02009f 	cmp	x4, x2
    6480:	54000440 	b.eq	6508 <fwp_block+0xc4>  // b.none
    6484:	f9419465 	ldr	x5, [x3, #808]
    6488:	f9000862 	str	x2, [x3, #16]
    648c:	f9400441 	ldr	x1, [x2, #8]
    6490:	f9004885 	str	x5, [x4, #144]
    6494:	f9419865 	ldr	x5, [x3, #816]
    6498:	f9004c85 	str	x5, [x4, #152]
    649c:	f9419c65 	ldr	x5, [x3, #824]
    64a0:	f9005085 	str	x5, [x4, #160]
    64a4:	f941a065 	ldr	x5, [x3, #832]
    64a8:	f9005485 	str	x5, [x4, #168]
    64ac:	f941a465 	ldr	x5, [x3, #840]
    64b0:	f9005885 	str	x5, [x4, #176]
    64b4:	f941a865 	ldr	x5, [x3, #848]
    64b8:	f9005c85 	str	x5, [x4, #184]
    64bc:	f941ac65 	ldr	x5, [x3, #856]
    64c0:	f9006085 	str	x5, [x4, #192]
    64c4:	f9400480 	ldr	x0, [x4, #8]
    64c8:	f9404844 	ldr	x4, [x2, #144]
    64cc:	f9019464 	str	x4, [x3, #808]
    64d0:	f9404c44 	ldr	x4, [x2, #152]
    64d4:	f9019864 	str	x4, [x3, #816]
    64d8:	f9405044 	ldr	x4, [x2, #160]
    64dc:	f9019c64 	str	x4, [x3, #824]
    64e0:	f9405444 	ldr	x4, [x2, #168]
    64e4:	f901a064 	str	x4, [x3, #832]
    64e8:	f9405844 	ldr	x4, [x2, #176]
    64ec:	f901a464 	str	x4, [x3, #840]
    64f0:	a94b8844 	ldp	x4, x2, [x2, #184]
    64f4:	f901a864 	str	x4, [x3, #848]
    64f8:	f901ac62 	str	x2, [x3, #856]
    64fc:	97fff0f9 	bl	28e0 <swapcontext@plt>
    6500:	97ffff64 	bl	6290 <fwp_free_zombie>
    6504:	d503201f 	nop
    6508:	9101c260 	add	x0, x19, #0x70
    650c:	b9436000 	ldr	w0, [x0, #864]
    6510:	340001a0 	cbz	w0, 6544 <fwp_block+0x100>
    6514:	a94153f3 	ldp	x19, x20, [sp, #16]
    6518:	a8c27bfd 	ldp	x29, x30, [sp], #32
    651c:	d65f03c0 	ret
    6520:	97fff7f4 	bl	44f0 <fwp_poll_events>
    6524:	f9404282 	ldr	x2, [x20, #128]
    6528:	b4ffffc2 	cbz	x2, 6520 <fwp_block+0xdc>
    652c:	9101c261 	add	x1, x19, #0x70
    6530:	f9408040 	ldr	x0, [x2, #256]
    6534:	f9004020 	str	x0, [x1, #128]
    6538:	b5fff9c0 	cbnz	x0, 6470 <fwp_block+0x2c>
    653c:	f9003c3f 	str	xzr, [x1, #120]
    6540:	17ffffcc 	b	6470 <fwp_block+0x2c>
    6544:	b0000020 	adrp	x0, b000 <__divti3+0x190>
    6548:	91288000 	add	x0, x0, #0xa20
    654c:	97fff131 	bl	2a10 <getenv@plt>
    6550:	5284e202 	mov	w2, #0x2710                	// #10000
    6554:	b4000060 	cbz	x0, 6560 <fwp_block+0x11c>
    6558:	39400001 	ldrb	w1, [x0]
    655c:	350000c1 	cbnz	w1, 6574 <fwp_block+0x130>
    6560:	9101c273 	add	x19, x19, #0x70
    6564:	b9036262 	str	w2, [x19, #864]
    6568:	a94153f3 	ldp	x19, x20, [sp, #16]
    656c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6570:	d65f03c0 	ret
    6574:	52800142 	mov	w2, #0xa                   	// #10
    6578:	d2800001 	mov	x1, #0x0                   	// #0
    657c:	97fff075 	bl	2750 <strtoll@plt>
    6580:	d1000403 	sub	x3, x0, #0x1
    6584:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6588:	eb02007f 	cmp	x3, x2
    658c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6590:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6594:	17fffff3 	b	6560 <fwp_block+0x11c>
    6598:	d503201f 	nop
    659c:	d503201f 	nop

00000000000065a0 <fwp_owned_entry161>:
    65a0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    65a4:	910003fd 	mov	x29, sp
    65a8:	a90363f7 	stp	x23, x24, [sp, #48]
    65ac:	a9406002 	ldp	x2, x24, [x0]
    65b0:	a90153f3 	stp	x19, x20, [sp, #16]
    65b4:	f9400801 	ldr	x1, [x0, #16]
    65b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    65bc:	ab010055 	adds	x21, x2, x1
    65c0:	54000d06 	b.vs	6760 <fwp_owned_entry161+0x1c0>
    65c4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    65c8:	9117c281 	add	x1, x20, #0x5f0
    65cc:	b953a420 	ldr	w0, [x1, #5028]
    65d0:	34000a80 	cbz	w0, 6720 <fwp_owned_entry161+0x180>
    65d4:	397e8820 	ldrb	w0, [x1, #4002]
    65d8:	910f0002 	add	x2, x0, #0x3c0
    65dc:	8b000400 	add	x0, x0, x0, lsl #1
    65e0:	d37df000 	lsl	x0, x0, #3
    65e4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    65e8:	2a1703f6 	mov	w22, w23
    65ec:	f8606833 	ldr	x19, [x1, x0]
    65f0:	b4000853 	cbz	x19, 66f8 <fwp_owned_entry161+0x158>
    65f4:	f9400262 	ldr	x2, [x19]
    65f8:	aa2203e2 	mvn	x2, x2
    65fc:	f8206822 	str	x2, [x1, x0]
    6600:	f10062df 	cmp	x22, #0x18
    6604:	540000e9 	b.ls	6620 <fwp_owned_entry161+0x80>  // b.plast
    6608:	d10066c2 	sub	x2, x22, #0x19
    660c:	91006260 	add	x0, x19, #0x18
    6610:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6614:	52800001 	mov	w1, #0x0                   	// #0
    6618:	91002042 	add	x2, x2, #0x8
    661c:	97fff08d 	bl	2850 <memset@plt>
    6620:	9117c281 	add	x1, x20, #0x5f0
    6624:	f94a1020 	ldr	x0, [x1, #5152]
    6628:	ab160000 	adds	x0, x0, x22
    662c:	540009c2 	b.cs	6764 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    6630:	f94a1422 	ldr	x2, [x1, #5160]
    6634:	f90a1020 	str	x0, [x1, #5152]
    6638:	eb02001f 	cmp	x0, x2
    663c:	54000049 	b.ls	6644 <fwp_owned_entry161+0xa4>  // b.plast
    6640:	f90a1420 	str	x0, [x1, #5160]
    6644:	9117c280 	add	x0, x20, #0x5f0
    6648:	1e6302e1 	ucvtf	d1, w23
    664c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6650:	1e612800 	fadd	d0, d0, d1
    6654:	fd0a1c00 	str	d0, [x0, #5176]
    6658:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0xa70>
    665c:	9117c294 	add	x20, x20, #0x5f0
    6660:	a900d678 	stp	x24, x21, [x19, #8]
    6664:	fd41c000 	ldr	d0, [x0, #896]
    6668:	fd000260 	str	d0, [x19]
    666c:	f949da81 	ldr	x1, [x20, #5040]
    6670:	f949ee80 	ldr	x0, [x20, #5080]
    6674:	cb010261 	sub	x1, x19, x1
    6678:	eb00403f 	cmp	x1, x0, lsl #16
    667c:	54000322 	b.cs	66e0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6680:	d350fc20 	lsr	x0, x1, #16
    6684:	f949fe83 	ldr	x3, [x20, #5112]
    6688:	8b000800 	add	x0, x0, x0, lsl #2
    668c:	d37df002 	lsl	x2, x0, #3
    6690:	8b020060 	add	x0, x3, x2
    6694:	f9401014 	ldr	x20, [x0, #32]
    6698:	b4000254 	cbz	x20, 66e0 <fwp_owned_entry161+0x140>
    669c:	38626862 	ldrb	w2, [x3, x2]
    66a0:	7100085f 	cmp	w2, #0x2
    66a4:	54000480 	b.eq	6734 <fwp_owned_entry161+0x194>  // b.none
    66a8:	7100045f 	cmp	w2, #0x1
    66ac:	540001a1 	b.ne	66e0 <fwp_owned_entry161+0x140>  // b.any
    66b0:	29430002 	ldp	w2, w0, [x0, #24]
    66b4:	92403c21 	and	x1, x1, #0xffff
    66b8:	9b027c21 	mul	x1, x1, x2
    66bc:	d360fc21 	lsr	x1, x1, #32
    66c0:	eb00003f 	cmp	x1, x0
    66c4:	540000e2 	b.cs	66e0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    66c8:	8b010294 	add	x20, x20, x1
    66cc:	39400280 	ldrb	w0, [x20]
    66d0:	7103fc1f 	cmp	w0, #0xff
    66d4:	54000400 	b.eq	6754 <fwp_owned_entry161+0x1b4>  // b.none
    66d8:	52800020 	mov	w0, #0x1                   	// #1
    66dc:	39000280 	strb	w0, [x20]
    66e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    66e4:	aa1303e0 	mov	x0, x19
    66e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    66ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    66f0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    66f4:	d65f03c0 	ret
    66f8:	8b000021 	add	x1, x1, x0
    66fc:	f9400433 	ldr	x19, [x1, #8]
    6700:	b4000113 	cbz	x19, 6720 <fwp_owned_entry161+0x180>
    6704:	f9400820 	ldr	x0, [x1, #16]
    6708:	cb130000 	sub	x0, x0, x19
    670c:	eb0002df 	cmp	x22, x0
    6710:	54000088 	b.hi	6720 <fwp_owned_entry161+0x180>  // b.pmore
    6714:	8b160260 	add	x0, x19, x22
    6718:	f9000420 	str	x0, [x1, #8]
    671c:	17ffffb9 	b	6600 <fwp_owned_entry161+0x60>
    6720:	52800001 	mov	w1, #0x0                   	// #0
    6724:	d2800300 	mov	x0, #0x18                  	// #24
    6728:	97fffa06 	bl	4f40 <fwp_heap_alloc>
    672c:	aa0003f3 	mov	x19, x0
    6730:	17ffffca 	b	6658 <fwp_owned_entry161+0xb8>
    6734:	72003c3f 	tst	w1, #0xffff
    6738:	54fffca0 	b.eq	66cc <fwp_owned_entry161+0x12c>  // b.none
    673c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6740:	aa1303e0 	mov	x0, x19
    6744:	a94153f3 	ldp	x19, x20, [sp, #16]
    6748:	a94363f7 	ldp	x23, x24, [sp, #48]
    674c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6750:	d65f03c0 	ret
    6754:	aa1403e0 	mov	x0, x20
    6758:	97fff83a 	bl	4840 <fwp_rc_forget_slot>
    675c:	17ffffdf 	b	66d8 <fwp_owned_entry161+0x138>
    6760:	97fff0c8 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6764:	97fff233 	bl	3030 <fwp_heap_oom>
    6768:	d503201f 	nop
    676c:	d503201f 	nop

0000000000006770 <e161>:
    6770:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6774:	910003fd 	mov	x29, sp
    6778:	a90363f7 	stp	x23, x24, [sp, #48]
    677c:	a9406002 	ldp	x2, x24, [x0]
    6780:	a90153f3 	stp	x19, x20, [sp, #16]
    6784:	f9400801 	ldr	x1, [x0, #16]
    6788:	a9025bf5 	stp	x21, x22, [sp, #32]
    678c:	ab010055 	adds	x21, x2, x1
    6790:	54000d86 	b.vs	6940 <e161+0x1d0>
    6794:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    6798:	9117c281 	add	x1, x20, #0x5f0
    679c:	b953a420 	ldr	w0, [x1, #5028]
    67a0:	34000ac0 	cbz	w0, 68f8 <e161+0x188>
    67a4:	397e8820 	ldrb	w0, [x1, #4002]
    67a8:	910f0002 	add	x2, x0, #0x3c0
    67ac:	8b000400 	add	x0, x0, x0, lsl #1
    67b0:	d37df000 	lsl	x0, x0, #3
    67b4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    67b8:	2a1703f6 	mov	w22, w23
    67bc:	f8606833 	ldr	x19, [x1, x0]
    67c0:	b4000893 	cbz	x19, 68d0 <e161+0x160>
    67c4:	f9400262 	ldr	x2, [x19]
    67c8:	aa2203e2 	mvn	x2, x2
    67cc:	f8206822 	str	x2, [x1, x0]
    67d0:	f10062df 	cmp	x22, #0x18
    67d4:	540000e9 	b.ls	67f0 <e161+0x80>  // b.plast
    67d8:	d10066c2 	sub	x2, x22, #0x19
    67dc:	91006260 	add	x0, x19, #0x18
    67e0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    67e4:	52800001 	mov	w1, #0x0                   	// #0
    67e8:	91002042 	add	x2, x2, #0x8
    67ec:	97fff019 	bl	2850 <memset@plt>
    67f0:	9117c281 	add	x1, x20, #0x5f0
    67f4:	f94a1020 	ldr	x0, [x1, #5152]
    67f8:	ab160000 	adds	x0, x0, x22
    67fc:	54000a42 	b.cs	6944 <e161+0x1d4>  // b.hs, b.nlast
    6800:	f94a1422 	ldr	x2, [x1, #5160]
    6804:	f90a1020 	str	x0, [x1, #5152]
    6808:	eb02001f 	cmp	x0, x2
    680c:	54000049 	b.ls	6814 <e161+0xa4>  // b.plast
    6810:	f90a1420 	str	x0, [x1, #5160]
    6814:	9117c280 	add	x0, x20, #0x5f0
    6818:	1e6302e1 	ucvtf	d1, w23
    681c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6820:	1e612800 	fadd	d0, d0, d1
    6824:	fd0a1c00 	str	d0, [x0, #5176]
    6828:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0xa70>
    682c:	9117c294 	add	x20, x20, #0x5f0
    6830:	a900d678 	stp	x24, x21, [x19, #8]
    6834:	fd41c000 	ldr	d0, [x0, #896]
    6838:	fd000260 	str	d0, [x19]
    683c:	f949da81 	ldr	x1, [x20, #5040]
    6840:	f949ee80 	ldr	x0, [x20, #5080]
    6844:	cb010261 	sub	x1, x19, x1
    6848:	eb00403f 	cmp	x1, x0, lsl #16
    684c:	54000322 	b.cs	68b0 <e161+0x140>  // b.hs, b.nlast
    6850:	d350fc20 	lsr	x0, x1, #16
    6854:	f949fe83 	ldr	x3, [x20, #5112]
    6858:	8b000800 	add	x0, x0, x0, lsl #2
    685c:	d37df002 	lsl	x2, x0, #3
    6860:	8b020060 	add	x0, x3, x2
    6864:	f9401014 	ldr	x20, [x0, #32]
    6868:	b4000254 	cbz	x20, 68b0 <e161+0x140>
    686c:	38626862 	ldrb	w2, [x3, x2]
    6870:	7100085f 	cmp	w2, #0x2
    6874:	540004c0 	b.eq	690c <e161+0x19c>  // b.none
    6878:	7100045f 	cmp	w2, #0x1
    687c:	540001a1 	b.ne	68b0 <e161+0x140>  // b.any
    6880:	29430002 	ldp	w2, w0, [x0, #24]
    6884:	92403c21 	and	x1, x1, #0xffff
    6888:	9b027c21 	mul	x1, x1, x2
    688c:	d360fc21 	lsr	x1, x1, #32
    6890:	eb00003f 	cmp	x1, x0
    6894:	540000e2 	b.cs	68b0 <e161+0x140>  // b.hs, b.nlast
    6898:	8b010294 	add	x20, x20, x1
    689c:	39400280 	ldrb	w0, [x20]
    68a0:	7103fc1f 	cmp	w0, #0xff
    68a4:	54000480 	b.eq	6934 <e161+0x1c4>  // b.none
    68a8:	52800020 	mov	w0, #0x1                   	// #1
    68ac:	39000280 	strb	w0, [x20]
    68b0:	aa1303e0 	mov	x0, x19
    68b4:	97fffbeb 	bl	5860 <fwp_rc_share>
    68b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    68bc:	aa1303e0 	mov	x0, x19
    68c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    68c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    68c8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    68cc:	d65f03c0 	ret
    68d0:	8b000021 	add	x1, x1, x0
    68d4:	f9400433 	ldr	x19, [x1, #8]
    68d8:	b4000113 	cbz	x19, 68f8 <e161+0x188>
    68dc:	f9400820 	ldr	x0, [x1, #16]
    68e0:	cb130000 	sub	x0, x0, x19
    68e4:	eb0002df 	cmp	x22, x0
    68e8:	54000088 	b.hi	68f8 <e161+0x188>  // b.pmore
    68ec:	8b160260 	add	x0, x19, x22
    68f0:	f9000420 	str	x0, [x1, #8]
    68f4:	17ffffb7 	b	67d0 <e161+0x60>
    68f8:	52800001 	mov	w1, #0x0                   	// #0
    68fc:	d2800300 	mov	x0, #0x18                  	// #24
    6900:	97fff990 	bl	4f40 <fwp_heap_alloc>
    6904:	aa0003f3 	mov	x19, x0
    6908:	17ffffc8 	b	6828 <e161+0xb8>
    690c:	72003c3f 	tst	w1, #0xffff
    6910:	54fffc60 	b.eq	689c <e161+0x12c>  // b.none
    6914:	aa1303e0 	mov	x0, x19
    6918:	97fffbd2 	bl	5860 <fwp_rc_share>
    691c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6920:	aa1303e0 	mov	x0, x19
    6924:	a94153f3 	ldp	x19, x20, [sp, #16]
    6928:	a94363f7 	ldp	x23, x24, [sp, #48]
    692c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6930:	d65f03c0 	ret
    6934:	aa1403e0 	mov	x0, x20
    6938:	97fff7c2 	bl	4840 <fwp_rc_forget_slot>
    693c:	17ffffdb 	b	68a8 <e161+0x138>
    6940:	97fff050 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6944:	97fff1bb 	bl	3030 <fwp_heap_oom>
    6948:	d503201f 	nop
    694c:	d503201f 	nop

0000000000006950 <fwp_drop4>:
    6950:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6954:	910003fd 	mov	x29, sp
    6958:	a90153f3 	stp	x19, x20, [sp, #16]
    695c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    6960:	f90013f5 	str	x21, [sp, #32]
    6964:	9117c275 	add	x21, x19, #0x5f0
    6968:	f949daa1 	ldr	x1, [x21, #5040]
    696c:	f949eea2 	ldr	x2, [x21, #5080]
    6970:	cb010001 	sub	x1, x0, x1
    6974:	eb02403f 	cmp	x1, x2, lsl #16
    6978:	54000382 	b.cs	69e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    697c:	d350fc22 	lsr	x2, x1, #16
    6980:	f949fea3 	ldr	x3, [x21, #5112]
    6984:	8b020842 	add	x2, x2, x2, lsl #2
    6988:	d37df042 	lsl	x2, x2, #3
    698c:	8b020064 	add	x4, x3, x2
    6990:	f9401094 	ldr	x20, [x4, #32]
    6994:	b40002b4 	cbz	x20, 69e8 <fwp_drop4+0x98>
    6998:	38626862 	ldrb	w2, [x3, x2]
    699c:	7100085f 	cmp	w2, #0x2
    69a0:	540007a0 	b.eq	6a94 <fwp_drop4+0x144>  // b.none
    69a4:	7100045f 	cmp	w2, #0x1
    69a8:	54000201 	b.ne	69e8 <fwp_drop4+0x98>  // b.any
    69ac:	29430885 	ldp	w5, w2, [x4, #24]
    69b0:	92403c21 	and	x1, x1, #0xffff
    69b4:	9b057c21 	mul	x1, x1, x5
    69b8:	d360fc21 	lsr	x1, x1, #32
    69bc:	eb02003f 	cmp	x1, x2
    69c0:	54000142 	b.cs	69e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    69c4:	8b010294 	add	x20, x20, x1
    69c8:	39400281 	ldrb	w1, [x20]
    69cc:	340000e1 	cbz	w1, 69e8 <fwp_drop4+0x98>
    69d0:	7100043f 	cmp	w1, #0x1
    69d4:	54000120 	b.eq	69f8 <fwp_drop4+0xa8>  // b.none
    69d8:	7103fc3f 	cmp	w1, #0xff
    69dc:	540007c0 	b.eq	6ad4 <fwp_drop4+0x184>  // b.none
    69e0:	51000421 	sub	w1, w1, #0x1
    69e4:	39000281 	strb	w1, [x20]
    69e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    69ec:	f94013f5 	ldr	x21, [sp, #32]
    69f0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69f4:	d65f03c0 	ret
    69f8:	f9400001 	ldr	x1, [x0]
    69fc:	b7f80581 	tbnz	x1, #63, 6aac <fwp_drop4+0x15c>
    6a00:	9117c273 	add	x19, x19, #0x5f0
    6a04:	f949da61 	ldr	x1, [x19, #5040]
    6a08:	f949ee62 	ldr	x2, [x19, #5080]
    6a0c:	cb010001 	sub	x1, x0, x1
    6a10:	eb02403f 	cmp	x1, x2, lsl #16
    6a14:	54fffea2 	b.cs	69e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a18:	d350fc22 	lsr	x2, x1, #16
    6a1c:	8b020842 	add	x2, x2, x2, lsl #2
    6a20:	d37df042 	lsl	x2, x2, #3
    6a24:	8b020065 	add	x5, x3, x2
    6a28:	f94010a4 	ldr	x4, [x5, #32]
    6a2c:	b4fffde4 	cbz	x4, 69e8 <fwp_drop4+0x98>
    6a30:	38626862 	ldrb	w2, [x3, x2]
    6a34:	7100085f 	cmp	w2, #0x2
    6a38:	54000220 	b.eq	6a7c <fwp_drop4+0x12c>  // b.none
    6a3c:	7100045f 	cmp	w2, #0x1
    6a40:	54fffd41 	b.ne	69e8 <fwp_drop4+0x98>  // b.any
    6a44:	294308a3 	ldp	w3, w2, [x5, #24]
    6a48:	92403c21 	and	x1, x1, #0xffff
    6a4c:	9b037c21 	mul	x1, x1, x3
    6a50:	d360fc21 	lsr	x1, x1, #32
    6a54:	eb02003f 	cmp	x1, x2
    6a58:	54fffc82 	b.cs	69e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a5c:	8b010084 	add	x4, x4, x1
    6a60:	39400081 	ldrb	w1, [x4]
    6a64:	7100043f 	cmp	w1, #0x1
    6a68:	54fffc01 	b.ne	69e8 <fwp_drop4+0x98>  // b.any
    6a6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a70:	f94013f5 	ldr	x21, [sp, #32]
    6a74:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a78:	17fff812 	b	4ac0 <fwp_mem_free>
    6a7c:	72003c3f 	tst	w1, #0xffff
    6a80:	54ffff00 	b.eq	6a60 <fwp_drop4+0x110>  // b.none
    6a84:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a88:	f94013f5 	ldr	x21, [sp, #32]
    6a8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a90:	d65f03c0 	ret
    6a94:	72003c3f 	tst	w1, #0xffff
    6a98:	54fff980 	b.eq	69c8 <fwp_drop4+0x78>  // b.none
    6a9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6aa0:	f94013f5 	ldr	x21, [sp, #32]
    6aa4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6aa8:	d65f03c0 	ret
    6aac:	f9400414 	ldr	x20, [x0, #8]
    6ab0:	97fffb91 	bl	58f4 <fwp_rc_free_arr>
    6ab4:	9117c260 	add	x0, x19, #0x5f0
    6ab8:	f949d801 	ldr	x1, [x0, #5040]
    6abc:	f949ec00 	ldr	x0, [x0, #5080]
    6ac0:	cb010281 	sub	x1, x20, x1
    6ac4:	eb00403f 	cmp	x1, x0, lsl #16
    6ac8:	54fff902 	b.cs	69e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6acc:	aa1403e0 	mov	x0, x20
    6ad0:	17ffffab 	b	697c <fwp_drop4+0x2c>
    6ad4:	ca544680 	eor	x0, x20, x20, lsr #17
    6ad8:	9117c273 	add	x19, x19, #0x5f0
    6adc:	ca402400 	eor	x0, x0, x0, lsr #9
    6ae0:	8b200e60 	add	x0, x19, w0, uxtb #3
    6ae4:	f94a2400 	ldr	x0, [x0, #5192]
    6ae8:	b5000080 	cbnz	x0, 6af8 <fwp_drop4+0x1a8>
    6aec:	14000010 	b	6b2c <fwp_drop4+0x1dc>
    6af0:	f9400800 	ldr	x0, [x0, #16]
    6af4:	b40001c0 	cbz	x0, 6b2c <fwp_drop4+0x1dc>
    6af8:	f9400001 	ldr	x1, [x0]
    6afc:	eb14003f 	cmp	x1, x20
    6b00:	54ffff81 	b.ne	6af0 <fwp_drop4+0x1a0>  // b.any
    6b04:	f9400401 	ldr	x1, [x0, #8]
    6b08:	d1000421 	sub	x1, x1, #0x1
    6b0c:	f9000401 	str	x1, [x0, #8]
    6b10:	f103f83f 	cmp	x1, #0xfe
    6b14:	54fff6a1 	b.ne	69e8 <fwp_drop4+0x98>  // b.any
    6b18:	aa1403e0 	mov	x0, x20
    6b1c:	97fff749 	bl	4840 <fwp_rc_forget_slot>
    6b20:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b24:	39000280 	strb	w0, [x20]
    6b28:	17ffffb0 	b	69e8 <fwp_drop4+0x98>
    6b2c:	b0000020 	adrp	x0, b000 <__divti3+0x190>
    6b30:	9123c000 	add	x0, x0, #0x8f0
    6b34:	97fff333 	bl	3800 <fwp_trap>
    6b38:	d503201f 	nop
    6b3c:	d503201f 	nop

0000000000006b40 <fwp_caps161>:
    6b40:	34000041 	cbz	w1, 6b48 <fwp_caps161+0x8>
    6b44:	d65f03c0 	ret
    6b48:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    6b4c:	9117c063 	add	x3, x3, #0x5f0
    6b50:	f949d861 	ldr	x1, [x3, #5040]
    6b54:	f949ec62 	ldr	x2, [x3, #5080]
    6b58:	cb010001 	sub	x1, x0, x1
    6b5c:	eb02403f 	cmp	x1, x2, lsl #16
    6b60:	54ffff22 	b.cs	6b44 <fwp_caps161+0x4>  // b.hs, b.nlast
    6b64:	d350fc22 	lsr	x2, x1, #16
    6b68:	f949fc65 	ldr	x5, [x3, #5112]
    6b6c:	8b020842 	add	x2, x2, x2, lsl #2
    6b70:	d37df042 	lsl	x2, x2, #3
    6b74:	8b0200a4 	add	x4, x5, x2
    6b78:	f9401083 	ldr	x3, [x4, #32]
    6b7c:	b4fffe43 	cbz	x3, 6b44 <fwp_caps161+0x4>
    6b80:	386268a2 	ldrb	w2, [x5, x2]
    6b84:	7100085f 	cmp	w2, #0x2
    6b88:	540001c0 	b.eq	6bc0 <fwp_caps161+0x80>  // b.none
    6b8c:	7100045f 	cmp	w2, #0x1
    6b90:	54fffda1 	b.ne	6b44 <fwp_caps161+0x4>  // b.any
    6b94:	29430885 	ldp	w5, w2, [x4, #24]
    6b98:	92403c21 	and	x1, x1, #0xffff
    6b9c:	9b057c21 	mul	x1, x1, x5
    6ba0:	d360fc21 	lsr	x1, x1, #32
    6ba4:	eb02003f 	cmp	x1, x2
    6ba8:	54fffce2 	b.cs	6b44 <fwp_caps161+0x4>  // b.hs, b.nlast
    6bac:	8b010063 	add	x3, x3, x1
    6bb0:	39400061 	ldrb	w1, [x3]
    6bb4:	7100043f 	cmp	w1, #0x1
    6bb8:	54fffc61 	b.ne	6b44 <fwp_caps161+0x4>  // b.any
    6bbc:	17fff7c1 	b	4ac0 <fwp_mem_free>
    6bc0:	72003c3f 	tst	w1, #0xffff
    6bc4:	54ffff60 	b.eq	6bb0 <fwp_caps161+0x70>  // b.none
    6bc8:	d65f03c0 	ret
    6bcc:	d503201f 	nop

0000000000006bd0 <f12>:
    6bd0:	d10483ff 	sub	sp, sp, #0x120
    6bd4:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6bd8:	f947f442 	ldr	x2, [x2, #4072]
    6bdc:	910103e8 	add	x8, sp, #0x40
    6be0:	a90b7bfd 	stp	x29, x30, [sp, #176]
    6be4:	9102c3fd 	add	x29, sp, #0xb0
    6be8:	9100e3e9 	add	x9, sp, #0x38
    6bec:	a90c53f3 	stp	x19, x20, [sp, #192]
    6bf0:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    6bf4:	9117c263 	add	x3, x19, #0x5f0
    6bf8:	d00000d4 	adrp	x20, 20000 <__data_start>
    6bfc:	9101c284 	add	x4, x20, #0x70
    6c00:	a90d5bf5 	stp	x21, x22, [sp, #208]
    6c04:	90000016 	adrp	x22, 6000 <fwp_tape_finish+0xb0>
    6c08:	aa0003f5 	mov	x21, x0
    6c0c:	f949d861 	ldr	x1, [x3, #5040]
    6c10:	a90e63f7 	stp	x23, x24, [sp, #224]
    6c14:	d00000d7 	adrp	x23, 20000 <__data_start>
    6c18:	f949ec65 	ldr	x5, [x3, #5080]
    6c1c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    6c20:	910042f7 	add	x23, x23, #0x10
    6c24:	a91073fb 	stp	x27, x28, [sp, #256]
    6c28:	9100e2f7 	add	x23, x23, #0x38
    6c2c:	cb0102e1 	sub	x1, x23, x1
    6c30:	f9419886 	ldr	x6, [x4, #816]
    6c34:	fd008be8 	str	d8, [sp, #272]
    6c38:	f9400047 	ldr	x7, [x2]
    6c3c:	f90057e7 	str	x7, [sp, #168]
    6c40:	d2800007 	mov	x7, #0x0                   	// #0
    6c44:	910142c2 	add	x2, x22, #0x50
    6c48:	12800007 	mov	w7, #0xffffffff            	// #-1
    6c4c:	a90123e9 	stp	x9, x8, [sp, #16]
    6c50:	b9003be7 	str	w7, [sp, #56]
    6c54:	a9040be6 	stp	x6, x2, [sp, #64]
    6c58:	f9002be9 	str	x9, [sp, #80]
    6c5c:	f9019888 	str	x8, [x4, #816]
    6c60:	eb05403f 	cmp	x1, x5, lsl #16
    6c64:	54000342 	b.cs	6ccc <f12+0xfc>  // b.hs, b.nlast
    6c68:	d350fc20 	lsr	x0, x1, #16
    6c6c:	f949fc64 	ldr	x4, [x3, #5112]
    6c70:	8b000800 	add	x0, x0, x0, lsl #2
    6c74:	d37df002 	lsl	x2, x0, #3
    6c78:	8b020083 	add	x3, x4, x2
    6c7c:	f9401060 	ldr	x0, [x3, #32]
    6c80:	b4000260 	cbz	x0, 6ccc <f12+0xfc>
    6c84:	38626882 	ldrb	w2, [x4, x2]
    6c88:	7100085f 	cmp	w2, #0x2
    6c8c:	54007840 	b.eq	7b94 <f12+0xfc4>  // b.none
    6c90:	7100045f 	cmp	w2, #0x1
    6c94:	540001c1 	b.ne	6ccc <f12+0xfc>  // b.any
    6c98:	29430864 	ldp	w4, w2, [x3, #24]
    6c9c:	92403c21 	and	x1, x1, #0xffff
    6ca0:	9b047c21 	mul	x1, x1, x4
    6ca4:	d360fc21 	lsr	x1, x1, #32
    6ca8:	eb02003f 	cmp	x1, x2
    6cac:	54000102 	b.cs	6ccc <f12+0xfc>  // b.hs, b.nlast
    6cb0:	8b010000 	add	x0, x0, x1
    6cb4:	39400001 	ldrb	w1, [x0]
    6cb8:	340000a1 	cbz	w1, 6ccc <f12+0xfc>
    6cbc:	7103f43f 	cmp	w1, #0xfd
    6cc0:	54007fe8 	b.hi	7cbc <f12+0x10ec>  // b.pmore
    6cc4:	11000421 	add	w1, w1, #0x1
    6cc8:	39000001 	strb	w1, [x0]
    6ccc:	aa1703e0 	mov	x0, x23
    6cd0:	97fffc00 	bl	5cd0 <fwp_closure_drop>
    6cd4:	b40076b5 	cbz	x21, 7ba8 <f12+0xfd8>
    6cd8:	aa1503e0 	mov	x0, x21
    6cdc:	d2800017 	mov	x23, #0x0                   	// #0
    6ce0:	f9400800 	ldr	x0, [x0, #16]
    6ce4:	910006f7 	add	x23, x23, #0x1
    6ce8:	b5ffffc0 	cbnz	x0, 6ce0 <f12+0x110>
    6cec:	52800000 	mov	w0, #0x0                   	// #0
    6cf0:	97fff240 	bl	35f0 <descent_phase_step>
    6cf4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6cf8:	eb0002ff 	cmp	x23, x0
    6cfc:	54008208 	b.hi	7d3c <f12+0x116c>  // b.pmore
    6d00:	9101c298 	add	x24, x20, #0x70
    6d04:	b9436700 	ldr	w0, [x24, #868]
    6d08:	34007320 	cbz	w0, 7b6c <f12+0xf9c>
    6d0c:	9101c280 	add	x0, x20, #0x70
    6d10:	f9404818 	ldr	x24, [x0, #144]
    6d14:	f9408419 	ldr	x25, [x0, #264]
    6d18:	eb18033f 	cmp	x25, x24
    6d1c:	540071aa 	b.ge	7b50 <f12+0xf80>  // b.tcont
    6d20:	f9403a81 	ldr	x1, [x20, #112]
    6d24:	8b190720 	add	x0, x25, x25, lsl #1
    6d28:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6d2c:	8b000b20 	add	x0, x25, x0, lsl #2
    6d30:	8b000c20 	add	x0, x1, x0, lsl #3
    6d34:	d503201f 	nop
    6d38:	b9400401 	ldr	w1, [x0, #4]
    6d3c:	35000081 	cbnz	w1, 6d4c <f12+0x17c>
    6d40:	b9400001 	ldr	w1, [x0]
    6d44:	6b02003f 	cmp	w1, w2
    6d48:	54007049 	b.ls	7b50 <f12+0xf80>  // b.plast
    6d4c:	91000739 	add	x25, x25, #0x1
    6d50:	9101a000 	add	x0, x0, #0x68
    6d54:	eb18033f 	cmp	x25, x24
    6d58:	54ffff01 	b.ne	6d38 <f12+0x168>  // b.any
    6d5c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6d60:	eb00031f 	cmp	x24, x0
    6d64:	54007f2c 	b.gt	7d48 <f12+0x1178>
    6d68:	9101c280 	add	x0, x20, #0x70
    6d6c:	f9403a9c 	ldr	x28, [x20, #112]
    6d70:	f9408000 	ldr	x0, [x0, #256]
    6d74:	eb18001f 	cmp	x0, x24
    6d78:	54000161 	b.ne	6da4 <f12+0x1d4>  // b.any
    6d7c:	b5007478 	cbnz	x24, 7c08 <f12+0x1038>
    6d80:	d2800d01 	mov	x1, #0x68                  	// #104
    6d84:	d280003a 	mov	x26, #0x1                   	// #1
    6d88:	aa1c03e0 	mov	x0, x28
    6d8c:	97ffeeb9 	bl	2870 <realloc@plt>
    6d90:	aa0003fc 	mov	x28, x0
    6d94:	b4006c60 	cbz	x0, 7b20 <f12+0xf50>
    6d98:	9101c280 	add	x0, x20, #0x70
    6d9c:	f9003a9c 	str	x28, [x20, #112]
    6da0:	f900801a 	str	x26, [x0, #256]
    6da4:	8b180700 	add	x0, x24, x24, lsl #1
    6da8:	9101c281 	add	x1, x20, #0x70
    6dac:	4f000400 	movi	v0.4s, #0x0
    6db0:	91000702 	add	x2, x24, #0x1
    6db4:	8b000b00 	add	x0, x24, x0, lsl #2
    6db8:	f9004822 	str	x2, [x1, #144]
    6dbc:	8b000f80 	add	x0, x28, x0, lsl #3
    6dc0:	f900301f 	str	xzr, [x0, #96]
    6dc4:	ad000000 	stp	q0, q0, [x0]
    6dc8:	ad010000 	stp	q0, q0, [x0, #32]
    6dcc:	ad020000 	stp	q0, q0, [x0, #64]
    6dd0:	8b190721 	add	x1, x25, x25, lsl #1
    6dd4:	b0000020 	adrp	x0, b000 <__divti3+0x190>
    6dd8:	91220000 	add	x0, x0, #0x880
    6ddc:	8b010b38 	add	x24, x25, x1, lsl #2
    6de0:	8b180f98 	add	x24, x28, x24, lsl #3
    6de4:	f900331f 	str	xzr, [x24, #96]
    6de8:	97ffef0a 	bl	2a10 <getenv@plt>
    6dec:	b4000080 	cbz	x0, 6dfc <f12+0x22c>
    6df0:	39400001 	ldrb	w1, [x0]
    6df4:	7100c03f 	cmp	w1, #0x30
    6df8:	540030a0 	b.eq	740c <f12+0x83c>  // b.none
    6dfc:	9101c280 	add	x0, x20, #0x70
    6e00:	f9407801 	ldr	x1, [x0, #240]
    6e04:	b5006e41 	cbnz	x1, 7bcc <f12+0xffc>
    6e08:	9101c281 	add	x1, x20, #0x70
    6e0c:	2f000400 	mvni	v0.2s, #0x0
    6e10:	b9400302 	ldr	w2, [x24]
    6e14:	52800024 	mov	w4, #0x1                   	// #1
    6e18:	91000723 	add	x3, x25, #0x1
    6e1c:	a900df17 	stp	x23, x23, [x24, #8]
    6e20:	0b040042 	add	w2, w2, w4
    6e24:	f9419820 	ldr	x0, [x1, #816]
    6e28:	29001302 	stp	w2, w4, [x24]
    6e2c:	f9002b1f 	str	xzr, [x24, #80]
    6e30:	f9008423 	str	x3, [x1, #264]
    6e34:	fd002f00 	str	d0, [x24, #88]
    6e38:	b40078e0 	cbz	x0, 7d54 <f12+0x1184>
    6e3c:	910142d6 	add	x22, x22, #0x50
    6e40:	14000003 	b	6e4c <f12+0x27c>
    6e44:	f9400000 	ldr	x0, [x0]
    6e48:	b4007860 	cbz	x0, 7d54 <f12+0x1184>
    6e4c:	f9400401 	ldr	x1, [x0, #8]
    6e50:	eb16003f 	cmp	x1, x22
    6e54:	54ffff81 	b.ne	6e44 <f12+0x274>  // b.any
    6e58:	f9400800 	ldr	x0, [x0, #16]
    6e5c:	2a1903e4 	mov	w4, w25
    6e60:	b9400001 	ldr	w1, [x0]
    6e64:	f9002b00 	str	x0, [x24, #80]
    6e68:	b9005f01 	str	w1, [x24, #92]
    6e6c:	37f80081 	tbnz	w1, #31, 6e7c <f12+0x2ac>
    6e70:	52800d05 	mov	w5, #0x68                  	// #104
    6e74:	9b257021 	smaddl	x1, w1, w5, x28
    6e78:	b9005839 	str	w25, [x1, #88]
    6e7c:	d3707c42 	ubfiz	x2, x2, #16, #32
    6e80:	b9000004 	str	w4, [x0]
    6e84:	aa030057 	orr	x23, x2, x3
    6e88:	52800020 	mov	w0, #0x1                   	// #1
    6e8c:	97fff1d9 	bl	35f0 <descent_phase_step>
    6e90:	aa1503e0 	mov	x0, x21
    6e94:	d2800002 	mov	x2, #0x0                   	// #0
    6e98:	b4006155 	cbz	x21, 7ac0 <f12+0xef0>
    6e9c:	d503201f 	nop
    6ea0:	f9400800 	ldr	x0, [x0, #16]
    6ea4:	91000442 	add	x2, x2, #0x1
    6ea8:	b5ffffc0 	cbnz	x0, 6ea0 <f12+0x2d0>
    6eac:	aa1503e1 	mov	x1, x21
    6eb0:	f9400821 	ldr	x1, [x1, #16]
    6eb4:	91000400 	add	x0, x0, #0x1
    6eb8:	b5ffffc1 	cbnz	x1, 6eb0 <f12+0x2e0>
    6ebc:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6ec0:	eb01001f 	cmp	x0, x1
    6ec4:	540074e8 	b.hi	7d60 <f12+0x1190>  // b.pmore
    6ec8:	f100005f 	cmp	x2, #0x0
    6ecc:	54005fad 	b.le	7ac0 <f12+0xef0>
    6ed0:	eb00005f 	cmp	x2, x0
    6ed4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6ed8:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    6edc:	eb0102df 	cmp	x22, x1
    6ee0:	54007408 	b.hi	7d60 <f12+0x1190>  // b.pmore
    6ee4:	d37ffad9 	lsl	x25, x22, #1
    6ee8:	52800041 	mov	w1, #0x2                   	// #2
    6eec:	91000720 	add	x0, x25, #0x1
    6ef0:	d37df000 	lsl	x0, x0, #3
    6ef4:	97fff813 	bl	4f40 <fwp_heap_alloc>
    6ef8:	aa0003f8 	mov	x24, x0
    6efc:	9117c261 	add	x1, x19, #0x5f0
    6f00:	aa0103e0 	mov	x0, x1
    6f04:	f9000319 	str	x25, [x24]
    6f08:	f949d821 	ldr	x1, [x1, #5040]
    6f0c:	f949ec00 	ldr	x0, [x0, #5080]
    6f10:	cb010301 	sub	x1, x24, x1
    6f14:	eb00403f 	cmp	x1, x0, lsl #16
    6f18:	54006242 	b.cs	7b60 <f12+0xf90>  // b.hs, b.nlast
    6f1c:	9117c262 	add	x2, x19, #0x5f0
    6f20:	d350fc20 	lsr	x0, x1, #16
    6f24:	8b000800 	add	x0, x0, x0, lsl #2
    6f28:	f949fc43 	ldr	x3, [x2, #5112]
    6f2c:	d37df002 	lsl	x2, x0, #3
    6f30:	8b020060 	add	x0, x3, x2
    6f34:	f9401019 	ldr	x25, [x0, #32]
    6f38:	b4000259 	cbz	x25, 6f80 <f12+0x3b0>
    6f3c:	38626862 	ldrb	w2, [x3, x2]
    6f40:	7100085f 	cmp	w2, #0x2
    6f44:	54006220 	b.eq	7b88 <f12+0xfb8>  // b.none
    6f48:	7100045f 	cmp	w2, #0x1
    6f4c:	540001a1 	b.ne	6f80 <f12+0x3b0>  // b.any
    6f50:	29430002 	ldp	w2, w0, [x0, #24]
    6f54:	92403c21 	and	x1, x1, #0xffff
    6f58:	9b027c21 	mul	x1, x1, x2
    6f5c:	d360fc21 	lsr	x1, x1, #32
    6f60:	eb00003f 	cmp	x1, x0
    6f64:	540000e2 	b.cs	6f80 <f12+0x3b0>  // b.hs, b.nlast
    6f68:	8b010339 	add	x25, x25, x1
    6f6c:	39400320 	ldrb	w0, [x25]
    6f70:	7103fc1f 	cmp	w0, #0xff
    6f74:	54006920 	b.eq	7c98 <f12+0x10c8>  // b.none
    6f78:	52800020 	mov	w0, #0x1                   	// #1
    6f7c:	39000320 	strb	w0, [x25]
    6f80:	b4000236 	cbz	x22, 6fc4 <f12+0x3f4>
    6f84:	d3607ee4 	lsl	x4, x23, #32
    6f88:	aa1503e2 	mov	x2, x21
    6f8c:	f94006a5 	ldr	x5, [x21, #8]
    6f90:	aa0403e3 	mov	x3, x4
    6f94:	91002300 	add	x0, x24, #0x8
    6f98:	d2800001 	mov	x1, #0x0                   	// #0
    6f9c:	14000005 	b	6fb0 <f12+0x3e0>
    6fa0:	f9400445 	ldr	x5, [x2, #8]
    6fa4:	ab040023 	adds	x3, x1, x4
    6fa8:	91004000 	add	x0, x0, #0x10
    6fac:	54006f06 	b.vs	7d8c <f12+0x11bc>
    6fb0:	a9000c05 	stp	x5, x3, [x0]
    6fb4:	91000421 	add	x1, x1, #0x1
    6fb8:	f9400842 	ldr	x2, [x2, #16]
    6fbc:	eb0102df 	cmp	x22, x1
    6fc0:	54ffff08 	b.hi	6fa0 <f12+0x3d0>  // b.pmore
    6fc4:	f9400300 	ldr	x0, [x24]
    6fc8:	f100041f 	cmp	x0, #0x1
    6fcc:	54005cc9 	b.ls	7b64 <f12+0xf94>  // b.plast
    6fd0:	d341fc00 	lsr	x0, x0, #1
    6fd4:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    6fd8:	d1000401 	sub	x1, x0, #0x1
    6fdc:	eb02003f 	cmp	x1, x2
    6fe0:	54006c08 	b.hi	7d60 <f12+0x1190>  // b.pmore
    6fe4:	d37ff83c 	lsl	x28, x1, #1
    6fe8:	b4005be1 	cbz	x1, 7b64 <f12+0xf94>
    6fec:	d1002301 	sub	x1, x24, #0x8
    6ff0:	91002316 	add	x22, x24, #0x8
    6ff4:	8b001039 	add	x25, x1, x0, lsl #4
    6ff8:	f94006c0 	ldr	x0, [x22, #8]
    6ffc:	f9400ec1 	ldr	x1, [x22, #24]
    7000:	fd4002c0 	ldr	d0, [x22]
    7004:	fd400ac1 	ldr	d1, [x22, #16]
    7008:	97fff94e 	bl	5540 <w107>
    700c:	a90006c0 	stp	x0, x1, [x22]
    7010:	910042d6 	add	x22, x22, #0x10
    7014:	eb1902df 	cmp	x22, x25
    7018:	54ffff01 	b.ne	6ff8 <f12+0x428>  // b.any
    701c:	f900031c 	str	x28, [x24]
    7020:	aa1803e0 	mov	x0, x24
    7024:	93407efb 	sxtw	x27, w23
    7028:	97fff99a 	bl	5690 <w164.constprop.0>
    702c:	aa1803e0 	mov	x0, x24
    7030:	aa0103f8 	mov	x24, x1
    7034:	97fffe47 	bl	6950 <fwp_drop4>
    7038:	97fff4a3 	bl	42c4 <caf61>
    703c:	9e670008 	fmov	d8, x0
    7040:	52800040 	mov	w0, #0x2                   	// #2
    7044:	97fff16b 	bl	35f0 <descent_phase_step>
    7048:	aa1b03e0 	mov	x0, x27
    704c:	97fff2b9 	bl	3b30 <fwp_tape_of>
    7050:	f9403002 	ldr	x2, [x0, #96]
    7054:	aa0003e8 	mov	x8, x0
    7058:	b50066c2 	cbnz	x2, 7d30 <f12+0x1160>
    705c:	97ffefcd 	bl	2f90 <fwp_tape_unlink_scope>
    7060:	b900051f 	str	wzr, [x8, #4]
    7064:	a9428517 	ldp	x23, x1, [x8, #40]
    7068:	f90007e1 	str	x1, [sp, #8]
    706c:	b9400103 	ldr	w3, [x8]
    7070:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    7074:	a9409d1c 	ldp	x28, x7, [x8, #8]
    7078:	a941d90a 	ldp	x10, x22, [x8, #24]
    707c:	a943e919 	ldp	x25, x26, [x8, #56]
    7080:	f9402502 	ldr	x2, [x8, #72]
    7084:	6b00007f 	cmp	w3, w0
    7088:	54000108 	b.hi	70a8 <f12+0x4d8>  // b.pmore
    708c:	9101c283 	add	x3, x20, #0x70
    7090:	92403f60 	and	x0, x27, #0xffff
    7094:	d1000400 	sub	x0, x0, #0x1
    7098:	f9408469 	ldr	x9, [x3, #264]
    709c:	eb09001f 	cmp	x0, x9
    70a0:	5400004a 	b.ge	70a8 <f12+0x4d8>  // b.tcont
    70a4:	f9008460 	str	x0, [x3, #264]
    70a8:	4f000400 	movi	v0.4s, #0x0
    70ac:	9101c289 	add	x9, x20, #0x70
    70b0:	9101c3e1 	add	x1, sp, #0x70
    70b4:	f9000d1f 	str	xzr, [x8, #24]
    70b8:	f90013e1 	str	x1, [sp, #32]
    70bc:	910163e0 	add	x0, sp, #0x58
    70c0:	f941992b 	ldr	x11, [x9, #816]
    70c4:	3c808100 	stur	q0, [x8, #8]
    70c8:	b0ffffe3 	adrp	x3, 4000 <fwp_heap_report+0x60>
    70cc:	ad010100 	stp	q0, q0, [x8, #32]
    70d0:	910f4063 	add	x3, x3, #0x3d0
    70d4:	a906dbe1 	stp	x1, x22, [sp, #104]
    70d8:	f94007e1 	ldr	x1, [sp, #8]
    70dc:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    70e0:	a9058feb 	stp	x11, x3, [sp, #88]
    70e4:	f9003ff7 	str	x23, [sp, #120]
    70e8:	f90043e1 	str	x1, [sp, #128]
    70ec:	a908ebf9 	stp	x25, x26, [sp, #136]
    70f0:	a9098bea 	stp	x10, x2, [sp, #152]
    70f4:	f9019920 	str	x0, [x9, #816]
    70f8:	b7f85618 	tbnz	x24, #63, 7bb8 <f12+0xfe8>
    70fc:	eb98837f 	cmp	x27, x24, asr #32
    7100:	540060a1 	b.ne	7d14 <f12+0x1144>  // b.any
    7104:	92407f03 	and	x3, x24, #0xffffffff
    7108:	eb3840ff 	cmp	x7, w24, uxtw
    710c:	540060ad 	b.le	7d20 <f12+0x1150>
    7110:	eb1c007f 	cmp	x3, x28
    7114:	9a83b79b 	csinc	x27, x28, x3, lt	// lt = tstop
    7118:	eb1b005f 	cmp	x2, x27
    711c:	54004f2a 	b.ge	7b00 <f12+0xf30>  // b.tcont
    7120:	f100005f 	cmp	x2, #0x0
    7124:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7128:	9a9b1042 	csel	x2, x2, x27, ne	// ne = any
    712c:	14000004 	b	713c <f12+0x56c>
    7130:	eb01005f 	cmp	x2, x1
    7134:	d37ff842 	lsl	x2, x2, #1
    7138:	9a9bd042 	csel	x2, x2, x27, le
    713c:	eb1b005f 	cmp	x2, x27
    7140:	54ffff8b 	b.lt	7130 <f12+0x560>  // b.tstop
    7144:	b400587a 	cbz	x26, 7c50 <f12+0x1080>
    7148:	aa1a03e0 	mov	x0, x26
    714c:	d37df041 	lsl	x1, x2, #3
    7150:	f90017e2 	str	x2, [sp, #40]
    7154:	97ffedc7 	bl	2870 <realloc@plt>
    7158:	f94017e2 	ldr	x2, [sp, #40]
    715c:	aa0003fa 	mov	x26, x0
    7160:	b4004d1a 	cbz	x26, 7b00 <f12+0xf30>
    7164:	f9004bfa 	str	x26, [sp, #144]
    7168:	f90053e2 	str	x2, [sp, #160]
    716c:	b500157b 	cbnz	x27, 7418 <f12+0x848>
    7170:	b7f800b8 	tbnz	x24, #63, 7184 <f12+0x5b4>
    7174:	92407f04 	and	x4, x24, #0xffffffff
    7178:	fc647b40 	ldr	d0, [x26, x4, lsl #3]
    717c:	1e682800 	fadd	d0, d0, d8
    7180:	fc247b40 	str	d0, [x26, x4, lsl #3]
    7184:	9101c281 	add	x1, x20, #0x70
    7188:	cb1c0364 	sub	x4, x27, x28
    718c:	52800060 	mov	w0, #0x3                   	// #3
    7190:	a9428827 	ldp	x7, x2, [x1, #40]
    7194:	8b070084 	add	x4, x4, x7
    7198:	8b1c0042 	add	x2, x2, x28
    719c:	a9028824 	stp	x4, x2, [x1, #40]
    71a0:	97fff114 	bl	35f0 <descent_phase_step>
    71a4:	d1000763 	sub	x3, x27, #0x1
    71a8:	d1000784 	sub	x4, x28, #0x1
    71ac:	eb03039f 	cmp	x28, x3
    71b0:	540003cc 	b.gt	7228 <f12+0x658>
    71b4:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    71b8:	1e602008 	fcmp	d0, #0.0
    71bc:	54000300 	b.eq	721c <f12+0x64c>  // b.none
    71c0:	cb1c0be0 	neg	x0, x28, lsl #2
    71c4:	cb1c03e2 	neg	x2, x28
    71c8:	8b0002c1 	add	x1, x22, x0
    71cc:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    71d0:	37f80121 	tbnz	w1, #31, 71f4 <f12+0x624>
    71d4:	f94007e5 	ldr	x5, [sp, #8]
    71d8:	93407c21 	sxtw	x1, w1
    71dc:	8b020ca7 	add	x7, x5, x2, lsl #3
    71e0:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    71e4:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    71e8:	1e620802 	fmul	d2, d0, d2
    71ec:	1e622821 	fadd	d1, d1, d2
    71f0:	fc217b41 	str	d1, [x26, x1, lsl #3]
    71f4:	8b0002e0 	add	x0, x23, x0
    71f8:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    71fc:	37f80100 	tbnz	w0, #31, 721c <f12+0x64c>
    7200:	8b020f22 	add	x2, x25, x2, lsl #3
    7204:	93407c00 	sxtw	x0, w0
    7208:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    720c:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    7210:	1e620800 	fmul	d0, d0, d2
    7214:	1e602820 	fadd	d0, d1, d0
    7218:	fc207b40 	str	d0, [x26, x0, lsl #3]
    721c:	d1000463 	sub	x3, x3, #0x1
    7220:	eb04007f 	cmp	x3, x4
    7224:	54fffc81 	b.ne	71b4 <f12+0x5e4>  // b.any
    7228:	52800080 	mov	w0, #0x4                   	// #4
    722c:	97fff0f1 	bl	35f0 <descent_phase_step>
    7230:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7234:	eb00039f 	cmp	x28, x0
    7238:	540059c8 	b.hi	7d70 <f12+0x11a0>  // b.pmore
    723c:	91000780 	add	x0, x28, #0x1
    7240:	52800041 	mov	w1, #0x2                   	// #2
    7244:	d37df000 	lsl	x0, x0, #3
    7248:	97fff73e 	bl	4f40 <fwp_heap_alloc>
    724c:	aa0003e2 	mov	x2, x0
    7250:	aa0003f6 	mov	x22, x0
    7254:	d2800001 	mov	x1, #0x0                   	// #0
    7258:	f800845c 	str	x28, [x2], #8
    725c:	b40000dc 	cbz	x28, 7274 <f12+0x6a4>
    7260:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    7264:	f8217840 	str	x0, [x2, x1, lsl #3]
    7268:	91000421 	add	x1, x1, #0x1
    726c:	eb01039f 	cmp	x28, x1
    7270:	54ffff81 	b.ne	7260 <f12+0x690>  // b.any
    7274:	528000a0 	mov	w0, #0x5                   	// #5
    7278:	97fff0de 	bl	35f0 <descent_phase_step>
    727c:	f94013e0 	ldr	x0, [sp, #32]
    7280:	9101c281 	add	x1, x20, #0x70
    7284:	f9402ff8 	ldr	x24, [sp, #88]
    7288:	f9019838 	str	x24, [x1, #816]
    728c:	97fff451 	bl	43d0 <fwp_tape_buffers_release>
    7290:	528000c0 	mov	w0, #0x6                   	// #6
    7294:	97fff0d7 	bl	35f0 <descent_phase_step>
    7298:	9117c262 	add	x2, x19, #0x5f0
    729c:	f949d841 	ldr	x1, [x2, #5040]
    72a0:	f949ec40 	ldr	x0, [x2, #5080]
    72a4:	cb0102c1 	sub	x1, x22, x1
    72a8:	eb00403f 	cmp	x1, x0, lsl #16
    72ac:	54000322 	b.cs	7310 <f12+0x740>  // b.hs, b.nlast
    72b0:	d350fc20 	lsr	x0, x1, #16
    72b4:	f949fc43 	ldr	x3, [x2, #5112]
    72b8:	8b000800 	add	x0, x0, x0, lsl #2
    72bc:	d37df002 	lsl	x2, x0, #3
    72c0:	8b020060 	add	x0, x3, x2
    72c4:	f9401017 	ldr	x23, [x0, #32]
    72c8:	b4000257 	cbz	x23, 7310 <f12+0x740>
    72cc:	38626862 	ldrb	w2, [x3, x2]
    72d0:	7100085f 	cmp	w2, #0x2
    72d4:	54004760 	b.eq	7bc0 <f12+0xff0>  // b.none
    72d8:	7100045f 	cmp	w2, #0x1
    72dc:	540001a1 	b.ne	7310 <f12+0x740>  // b.any
    72e0:	29430002 	ldp	w2, w0, [x0, #24]
    72e4:	92403c21 	and	x1, x1, #0xffff
    72e8:	9b027c21 	mul	x1, x1, x2
    72ec:	d360fc21 	lsr	x1, x1, #32
    72f0:	eb00003f 	cmp	x1, x0
    72f4:	540000e2 	b.cs	7310 <f12+0x740>  // b.hs, b.nlast
    72f8:	8b0102f7 	add	x23, x23, x1
    72fc:	394002e0 	ldrb	w0, [x23]
    7300:	7103fc1f 	cmp	w0, #0xff
    7304:	54004d00 	b.eq	7ca4 <f12+0x10d4>  // b.none
    7308:	52800020 	mov	w0, #0x1                   	// #1
    730c:	390002e0 	strb	w0, [x23]
    7310:	f9400fe0 	ldr	x0, [sp, #24]
    7314:	eb00031f 	cmp	x24, x0
    7318:	54005381 	b.ne	7d88 <f12+0x11b8>  // b.any
    731c:	f9400be0 	ldr	x0, [sp, #16]
    7320:	9101c294 	add	x20, x20, #0x70
    7324:	f94023e1 	ldr	x1, [sp, #64]
    7328:	f9019a81 	str	x1, [x20, #816]
    732c:	97fffb49 	bl	6050 <fwp_tape_scope_release>
    7330:	f94002c0 	ldr	x0, [x22]
    7334:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    7338:	b7f83700 	tbnz	x0, #63, 7a18 <f12+0xe48>
    733c:	9117c262 	add	x2, x19, #0x5f0
    7340:	f949d840 	ldr	x0, [x2, #5040]
    7344:	f949ec41 	ldr	x1, [x2, #5080]
    7348:	cb0002c0 	sub	x0, x22, x0
    734c:	eb01401f 	cmp	x0, x1, lsl #16
    7350:	54003642 	b.cs	7a18 <f12+0xe48>  // b.hs, b.nlast
    7354:	d350fc01 	lsr	x1, x0, #16
    7358:	f949fc44 	ldr	x4, [x2, #5112]
    735c:	8b010821 	add	x1, x1, x1, lsl #2
    7360:	d37df021 	lsl	x1, x1, #3
    7364:	8b010083 	add	x3, x4, x1
    7368:	f9401062 	ldr	x2, [x3, #32]
    736c:	b4003562 	cbz	x2, 7a18 <f12+0xe48>
    7370:	38616881 	ldrb	w1, [x4, x1]
    7374:	7100083f 	cmp	w1, #0x2
    7378:	540034a0 	b.eq	7a0c <f12+0xe3c>  // b.none
    737c:	7100043f 	cmp	w1, #0x1
    7380:	540034c1 	b.ne	7a18 <f12+0xe48>  // b.any
    7384:	29430464 	ldp	w4, w1, [x3, #24]
    7388:	92403c00 	and	x0, x0, #0xffff
    738c:	9b047c00 	mul	x0, x0, x4
    7390:	d360fc00 	lsr	x0, x0, #32
    7394:	eb01001f 	cmp	x0, x1
    7398:	54003402 	b.cs	7a18 <f12+0xe48>  // b.hs, b.nlast
    739c:	8b000042 	add	x2, x2, x0
    73a0:	39400040 	ldrb	w0, [x2]
    73a4:	7100041f 	cmp	w0, #0x1
    73a8:	54003381 	b.ne	7a18 <f12+0xe48>  // b.any
    73ac:	aa1603fa 	mov	x26, x22
    73b0:	d2800000 	mov	x0, #0x0                   	// #0
    73b4:	f9000ff6 	str	x22, [sp, #24]
    73b8:	f9400fe1 	ldr	x1, [sp, #24]
    73bc:	91002023 	add	x3, x1, #0x8
    73c0:	d2800001 	mov	x1, #0x0                   	// #0
    73c4:	b4000357 	cbz	x23, 742c <f12+0x85c>
    73c8:	b0000022 	adrp	x2, c000 <_IO_stdin_used+0xa70>
    73cc:	910022c5 	add	x5, x22, #0x8
    73d0:	fd41c441 	ldr	d1, [x2, #904]
    73d4:	14000009 	b	73f8 <f12+0x828>
    73d8:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    73dc:	f9400342 	ldr	x2, [x26]
    73e0:	1e600820 	fmul	d0, d1, d0
    73e4:	b7f84cc2 	tbnz	x2, #63, 7d7c <f12+0x11ac>
    73e8:	91000421 	add	x1, x1, #0x1
    73ec:	fc008460 	str	d0, [x3], #8
    73f0:	eb0102ff 	cmp	x23, x1
    73f4:	540001c0 	b.eq	742c <f12+0x85c>  // b.none
    73f8:	f94002c4 	ldr	x4, [x22]
    73fc:	aa0503e2 	mov	x2, x5
    7400:	b6fffec4 	tbz	x4, #63, 73d8 <f12+0x808>
    7404:	f9400ac2 	ldr	x2, [x22, #16]
    7408:	17fffff4 	b	73d8 <f12+0x808>
    740c:	39400400 	ldrb	w0, [x0, #1]
    7410:	34ffcfc0 	cbz	w0, 6e08 <f12+0x238>
    7414:	17fffe7a 	b	6dfc <f12+0x22c>
    7418:	d37df362 	lsl	x2, x27, #3
    741c:	aa1a03e0 	mov	x0, x26
    7420:	52800001 	mov	w1, #0x0                   	// #0
    7424:	97ffed0b 	bl	2850 <memset@plt>
    7428:	17ffff52 	b	7170 <f12+0x5a0>
    742c:	97fffd49 	bl	6950 <fwp_drop4>
    7430:	aa1503e1 	mov	x1, x21
    7434:	d2800002 	mov	x2, #0x0                   	// #0
    7438:	b40041b5 	cbz	x21, 7c6c <f12+0x109c>
    743c:	d503201f 	nop
    7440:	f9400821 	ldr	x1, [x1, #16]
    7444:	91000442 	add	x2, x2, #0x1
    7448:	b5ffffc1 	cbnz	x1, 7440 <f12+0x870>
    744c:	f9400343 	ldr	x3, [x26]
    7450:	9240f877 	and	x23, x3, #0x7fffffffffffffff
    7454:	b7f82a63 	tbnz	x3, #63, 79a0 <f12+0xdd0>
    7458:	9117c261 	add	x1, x19, #0x5f0
    745c:	f9400fe4 	ldr	x4, [sp, #24]
    7460:	f949d820 	ldr	x0, [x1, #5040]
    7464:	f949ec21 	ldr	x1, [x1, #5080]
    7468:	cb000080 	sub	x0, x4, x0
    746c:	eb01401f 	cmp	x0, x1, lsl #16
    7470:	54002982 	b.cs	79a0 <f12+0xdd0>  // b.hs, b.nlast
    7474:	9117c264 	add	x4, x19, #0x5f0
    7478:	d350fc01 	lsr	x1, x0, #16
    747c:	8b010821 	add	x1, x1, x1, lsl #2
    7480:	f949fc86 	ldr	x6, [x4, #5112]
    7484:	d37df021 	lsl	x1, x1, #3
    7488:	8b0100c5 	add	x5, x6, x1
    748c:	f94010a4 	ldr	x4, [x5, #32]
    7490:	b4002864 	cbz	x4, 799c <f12+0xdcc>
    7494:	386168c1 	ldrb	w1, [x6, x1]
    7498:	7100083f 	cmp	w1, #0x2
    749c:	540027c0 	b.eq	7994 <f12+0xdc4>  // b.none
    74a0:	7100043f 	cmp	w1, #0x1
    74a4:	540027c1 	b.ne	799c <f12+0xdcc>  // b.any
    74a8:	294304a6 	ldp	w6, w1, [x5, #24]
    74ac:	92403c00 	and	x0, x0, #0xffff
    74b0:	9b067c00 	mul	x0, x0, x6
    74b4:	d360fc00 	lsr	x0, x0, #32
    74b8:	eb01001f 	cmp	x0, x1
    74bc:	54002702 	b.cs	799c <f12+0xdcc>  // b.hs, b.nlast
    74c0:	8b000084 	add	x4, x4, x0
    74c4:	39400096 	ldrb	w22, [x4]
    74c8:	710006df 	cmp	w22, #0x1
    74cc:	54002681 	b.ne	799c <f12+0xdcc>  // b.any
    74d0:	b90023f6 	str	w22, [sp, #32]
    74d4:	eb17005f 	cmp	x2, x23
    74d8:	9a979057 	csel	x23, x2, x23, ls	// ls = plast
    74dc:	91002359 	add	x25, x26, #0x8
    74e0:	b4003f77 	cbz	x23, 7ccc <f12+0x10fc>
    74e4:	f9400fe0 	ldr	x0, [sp, #24]
    74e8:	d37df2e5 	lsl	x5, x23, #3
    74ec:	aa1503e2 	mov	x2, x21
    74f0:	d2800001 	mov	x1, #0x0                   	// #0
    74f4:	91002000 	add	x0, x0, #0x8
    74f8:	1400000a 	b	7520 <f12+0x950>
    74fc:	fc616881 	ldr	d1, [x4, x1]
    7500:	fd400440 	ldr	d0, [x2, #8]
    7504:	1e613800 	fsub	d0, d0, d1
    7508:	fc216b20 	str	d0, [x25, x1]
    750c:	91002021 	add	x1, x1, #0x8
    7510:	f9400842 	ldr	x2, [x2, #16]
    7514:	eb05003f 	cmp	x1, x5
    7518:	540001c0 	b.eq	7550 <f12+0x980>  // b.none
    751c:	f9400343 	ldr	x3, [x26]
    7520:	aa0003e4 	mov	x4, x0
    7524:	b6fffec3 	tbz	x3, #63, 74fc <f12+0x92c>
    7528:	f9400fe3 	ldr	x3, [sp, #24]
    752c:	fd400440 	ldr	d0, [x2, #8]
    7530:	f9400864 	ldr	x4, [x3, #16]
    7534:	fc616881 	ldr	d1, [x4, x1]
    7538:	1e613800 	fsub	d0, d0, d1
    753c:	fc216b20 	str	d0, [x25, x1]
    7540:	91002021 	add	x1, x1, #0x8
    7544:	f9400842 	ldr	x2, [x2, #16]
    7548:	eb05003f 	cmp	x1, x5
    754c:	54fffe81 	b.ne	751c <f12+0x94c>  // b.any
    7550:	b4003bb5 	cbz	x21, 7cc4 <f12+0x10f4>
    7554:	9117c260 	add	x0, x19, #0x5f0
    7558:	aa1503e2 	mov	x2, x21
    755c:	d280001b 	mov	x27, #0x0                   	// #0
    7560:	f949ec06 	ldr	x6, [x0, #5080]
    7564:	f949d807 	ldr	x7, [x0, #5040]
    7568:	f949fc05 	ldr	x5, [x0, #5112]
    756c:	d370bcc6 	lsl	x6, x6, #16
    7570:	14000006 	b	7588 <f12+0x9b8>
    7574:	f9400842 	ldr	x2, [x2, #16]
    7578:	9100077b 	add	x27, x27, #0x1
    757c:	f100005f 	cmp	x2, #0x0
    7580:	fa571362 	ccmp	x27, x23, #0x2, ne	// ne = any
    7584:	54000322 	b.cs	75e8 <f12+0xa18>  // b.hs, b.nlast
    7588:	cb070040 	sub	x0, x2, x7
    758c:	eb06001f 	cmp	x0, x6
    7590:	540002c2 	b.cs	75e8 <f12+0xa18>  // b.hs, b.nlast
    7594:	d350fc01 	lsr	x1, x0, #16
    7598:	8b010821 	add	x1, x1, x1, lsl #2
    759c:	d37df021 	lsl	x1, x1, #3
    75a0:	8b0100a4 	add	x4, x5, x1
    75a4:	f9401083 	ldr	x3, [x4, #32]
    75a8:	b4000203 	cbz	x3, 75e8 <f12+0xa18>
    75ac:	386168a1 	ldrb	w1, [x5, x1]
    75b0:	7100083f 	cmp	w1, #0x2
    75b4:	54000e00 	b.eq	7774 <f12+0xba4>  // b.none
    75b8:	7100043f 	cmp	w1, #0x1
    75bc:	54000161 	b.ne	75e8 <f12+0xa18>  // b.any
    75c0:	29430488 	ldp	w8, w1, [x4, #24]
    75c4:	92403c00 	and	x0, x0, #0xffff
    75c8:	9b087c00 	mul	x0, x0, x8
    75cc:	d360fc00 	lsr	x0, x0, #32
    75d0:	eb01001f 	cmp	x0, x1
    75d4:	540000a2 	b.cs	75e8 <f12+0xa18>  // b.hs, b.nlast
    75d8:	8b000063 	add	x3, x3, x0
    75dc:	39400060 	ldrb	w0, [x3]
    75e0:	7100041f 	cmp	w0, #0x1
    75e4:	54fffc80 	b.eq	7574 <f12+0x9a4>  // b.none
    75e8:	d2800018 	mov	x24, #0x0                   	// #0
    75ec:	eb17037f 	cmp	x27, x23
    75f0:	54000cc2 	b.cs	7788 <f12+0xbb8>  // b.hs, b.nlast
    75f4:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0xa70>
    75f8:	d1002336 	sub	x22, x25, #0x8
    75fc:	9117c27a 	add	x26, x19, #0x5f0
    7600:	d2800018 	mov	x24, #0x0                   	// #0
    7604:	fd41b008 	ldr	d8, [x0, #864]
    7608:	14000042 	b	7710 <f12+0xb40>
    760c:	f9400381 	ldr	x1, [x28]
    7610:	aa2103e1 	mvn	x1, x1
    7614:	f8207b41 	str	x1, [x26, x0, lsl #3]
    7618:	f100609f 	cmp	x4, #0x18
    761c:	54000169 	b.ls	7648 <f12+0xa78>  // b.plast
    7620:	d1006482 	sub	x2, x4, #0x19
    7624:	91006380 	add	x0, x28, #0x18
    7628:	927df042 	and	x2, x2, #0xfffffffffffffff8
    762c:	52800001 	mov	w1, #0x0                   	// #0
    7630:	91002042 	add	x2, x2, #0x8
    7634:	f90007e4 	str	x4, [sp, #8]
    7638:	b90013e5 	str	w5, [sp, #16]
    763c:	97ffec85 	bl	2850 <memset@plt>
    7640:	f94007e4 	ldr	x4, [sp, #8]
    7644:	b94013e5 	ldr	w5, [sp, #16]
    7648:	9117c262 	add	x2, x19, #0x5f0
    764c:	f94a1041 	ldr	x1, [x2, #5152]
    7650:	ab040021 	adds	x1, x1, x4
    7654:	540036c2 	b.cs	7d2c <f12+0x115c>  // b.hs, b.nlast
    7658:	f94a1440 	ldr	x0, [x2, #5160]
    765c:	f90a1041 	str	x1, [x2, #5152]
    7660:	eb00003f 	cmp	x1, x0
    7664:	54000049 	b.ls	766c <f12+0xa9c>  // b.plast
    7668:	f90a1441 	str	x1, [x2, #5160]
    766c:	9117c260 	add	x0, x19, #0x5f0
    7670:	1e6300a1 	ucvtf	d1, w5
    7674:	fd4a1c00 	ldr	d0, [x0, #5176]
    7678:	1e612800 	fadd	d0, d0, d1
    767c:	fd0a1c00 	str	d0, [x0, #5176]
    7680:	a900e394 	stp	x20, x24, [x28, #8]
    7684:	aa1c03f8 	mov	x24, x28
    7688:	fd000388 	str	d8, [x28]
    768c:	f949db41 	ldr	x1, [x26, #5040]
    7690:	f949ef40 	ldr	x0, [x26, #5080]
    7694:	cb010381 	sub	x1, x28, x1
    7698:	eb00403f 	cmp	x1, x0, lsl #16
    769c:	54000322 	b.cs	7700 <f12+0xb30>  // b.hs, b.nlast
    76a0:	d350fc22 	lsr	x2, x1, #16
    76a4:	f949ff44 	ldr	x4, [x26, #5112]
    76a8:	8b020842 	add	x2, x2, x2, lsl #2
    76ac:	d37df042 	lsl	x2, x2, #3
    76b0:	8b020080 	add	x0, x4, x2
    76b4:	f940101c 	ldr	x28, [x0, #32]
    76b8:	b400025c 	cbz	x28, 7700 <f12+0xb30>
    76bc:	38626882 	ldrb	w2, [x4, x2]
    76c0:	7100085f 	cmp	w2, #0x2
    76c4:	54000b00 	b.eq	7824 <f12+0xc54>  // b.none
    76c8:	7100045f 	cmp	w2, #0x1
    76cc:	540001a1 	b.ne	7700 <f12+0xb30>  // b.any
    76d0:	29430002 	ldp	w2, w0, [x0, #24]
    76d4:	92403c21 	and	x1, x1, #0xffff
    76d8:	9b027c21 	mul	x1, x1, x2
    76dc:	d360fc21 	lsr	x1, x1, #32
    76e0:	eb00003f 	cmp	x1, x0
    76e4:	540000e2 	b.cs	7700 <f12+0xb30>  // b.hs, b.nlast
    76e8:	8b01039c 	add	x28, x28, x1
    76ec:	39400380 	ldrb	w0, [x28]
    76f0:	7103fc1f 	cmp	w0, #0xff
    76f4:	54002000 	b.eq	7af4 <f12+0xf24>  // b.none
    76f8:	52800020 	mov	w0, #0x1                   	// #1
    76fc:	39000380 	strb	w0, [x28]
    7700:	d10006e0 	sub	x0, x23, #0x1
    7704:	eb00037f 	cmp	x27, x0
    7708:	54000982 	b.cs	7838 <f12+0xc68>  // b.hs, b.nlast
    770c:	aa0003f7 	mov	x23, x0
    7710:	b953a740 	ldr	w0, [x26, #5028]
    7714:	f8777ad4 	ldr	x20, [x22, x23, lsl #3]
    7718:	34000240 	cbz	w0, 7760 <f12+0xb90>
    771c:	397e8b40 	ldrb	w0, [x26, #4002]
    7720:	910f0001 	add	x1, x0, #0x3c0
    7724:	8b000400 	add	x0, x0, x0, lsl #1
    7728:	b8617b45 	ldr	w5, [x26, x1, lsl #2]
    772c:	8b000f41 	add	x1, x26, x0, lsl #3
    7730:	f8607b5c 	ldr	x28, [x26, x0, lsl #3]
    7734:	2a0503e4 	mov	w4, w5
    7738:	b5fff6bc 	cbnz	x28, 760c <f12+0xa3c>
    773c:	f940043c 	ldr	x28, [x1, #8]
    7740:	b400011c 	cbz	x28, 7760 <f12+0xb90>
    7744:	f9400820 	ldr	x0, [x1, #16]
    7748:	cb1c0000 	sub	x0, x0, x28
    774c:	eb00009f 	cmp	x4, x0
    7750:	54000088 	b.hi	7760 <f12+0xb90>  // b.pmore
    7754:	8b040380 	add	x0, x28, x4
    7758:	f9000420 	str	x0, [x1, #8]
    775c:	17ffffaf 	b	7618 <f12+0xa48>
    7760:	52800001 	mov	w1, #0x0                   	// #0
    7764:	d2800300 	mov	x0, #0x18                  	// #24
    7768:	97fff5f6 	bl	4f40 <fwp_heap_alloc>
    776c:	aa0003fc 	mov	x28, x0
    7770:	17ffffc4 	b	7680 <f12+0xab0>
    7774:	72003c1f 	tst	w0, #0xffff
    7778:	54fff320 	b.eq	75dc <f12+0xa0c>  // b.none
    777c:	d2800018 	mov	x24, #0x0                   	// #0
    7780:	eb17037f 	cmp	x27, x23
    7784:	54fff383 	b.cc	75f4 <f12+0xa24>  // b.lo, b.ul, b.last
    7788:	8b1b0f3b 	add	x27, x25, x27, lsl #3
    778c:	aa1903e1 	mov	x1, x25
    7790:	aa1503e0 	mov	x0, x21
    7794:	d503201f 	nop
    7798:	f8408422 	ldr	x2, [x1], #8
    779c:	f9000402 	str	x2, [x0, #8]
    77a0:	aa0003e2 	mov	x2, x0
    77a4:	f9400800 	ldr	x0, [x0, #16]
    77a8:	eb1b003f 	cmp	x1, x27
    77ac:	54ffff61 	b.ne	7798 <f12+0xbc8>  // b.any
    77b0:	b94023e1 	ldr	w1, [sp, #32]
    77b4:	f9000858 	str	x24, [x2, #16]
    77b8:	aa1503f8 	mov	x24, x21
    77bc:	aa0003f5 	mov	x21, x0
    77c0:	34000041 	cbz	w1, 77c8 <f12+0xbf8>
    77c4:	d2800019 	mov	x25, #0x0                   	// #0
    77c8:	aa1903e0 	mov	x0, x25
    77cc:	97fff4bd 	bl	4ac0 <fwp_mem_free>
    77d0:	f9400fe0 	ldr	x0, [sp, #24]
    77d4:	97fffc5f 	bl	6950 <fwp_drop4>
    77d8:	aa1503e0 	mov	x0, x21
    77dc:	97fff88e 	bl	5a14 <fwp_drop0>
    77e0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    77e4:	f947f400 	ldr	x0, [x0, #4072]
    77e8:	f94057e2 	ldr	x2, [sp, #168]
    77ec:	f9400001 	ldr	x1, [x0]
    77f0:	eb010042 	subs	x2, x2, x1
    77f4:	d2800001 	mov	x1, #0x0                   	// #0
    77f8:	54002ba1 	b.ne	7d6c <f12+0x119c>  // b.any
    77fc:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7800:	aa1803e0 	mov	x0, x24
    7804:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7808:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    780c:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7810:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7814:	a95073fb 	ldp	x27, x28, [sp, #256]
    7818:	fd408be8 	ldr	d8, [sp, #272]
    781c:	910483ff 	add	sp, sp, #0x120
    7820:	d65f03c0 	ret
    7824:	72003c3f 	tst	w1, #0xffff
    7828:	54fff620 	b.eq	76ec <f12+0xb1c>  // b.none
    782c:	d10006e0 	sub	x0, x23, #0x1
    7830:	eb00037f 	cmp	x27, x0
    7834:	54fff6c3 	b.cc	770c <f12+0xb3c>  // b.lo, b.ul, b.last
    7838:	b5fffa9b 	cbnz	x27, 7788 <f12+0xbb8>
    783c:	b94023e1 	ldr	w1, [sp, #32]
    7840:	7100003f 	cmp	w1, #0x0
    7844:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7848:	b4fffc00 	cbz	x0, 77c8 <f12+0xbf8>
    784c:	9117c273 	add	x19, x19, #0x5f0
    7850:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0xa70>
    7854:	d1000afa 	sub	x26, x23, #0x2
    7858:	52800034 	mov	w20, #0x1                   	// #1
    785c:	fd41b008 	ldr	d8, [x0, #864]
    7860:	b953a660 	ldr	w0, [x19, #5028]
    7864:	f87a7b37 	ldr	x23, [x25, x26, lsl #3]
    7868:	340008c0 	cbz	w0, 7980 <f12+0xdb0>
    786c:	d503201f 	nop
    7870:	397e8a60 	ldrb	w0, [x19, #4002]
    7874:	910f0001 	add	x1, x0, #0x3c0
    7878:	8b000400 	add	x0, x0, x0, lsl #1
    787c:	b8617a7c 	ldr	w28, [x19, x1, lsl #2]
    7880:	8b000e61 	add	x1, x19, x0, lsl #3
    7884:	f8607a76 	ldr	x22, [x19, x0, lsl #3]
    7888:	2a1c03fb 	mov	w27, w28
    788c:	b40022d6 	cbz	x22, 7ce4 <f12+0x1114>
    7890:	f94002c1 	ldr	x1, [x22]
    7894:	aa2103e1 	mvn	x1, x1
    7898:	f8207a61 	str	x1, [x19, x0, lsl #3]
    789c:	f100637f 	cmp	x27, #0x18
    78a0:	540000e9 	b.ls	78bc <f12+0xcec>  // b.plast
    78a4:	d1006762 	sub	x2, x27, #0x19
    78a8:	910062c0 	add	x0, x22, #0x18
    78ac:	927df042 	and	x2, x2, #0xfffffffffffffff8
    78b0:	52800001 	mov	w1, #0x0                   	// #0
    78b4:	91002042 	add	x2, x2, #0x8
    78b8:	97ffebe6 	bl	2850 <memset@plt>
    78bc:	f94a1260 	ldr	x0, [x19, #5152]
    78c0:	ab1b0000 	adds	x0, x0, x27
    78c4:	54002342 	b.cs	7d2c <f12+0x115c>  // b.hs, b.nlast
    78c8:	f94a1661 	ldr	x1, [x19, #5160]
    78cc:	f90a1260 	str	x0, [x19, #5152]
    78d0:	eb01001f 	cmp	x0, x1
    78d4:	54000049 	b.ls	78dc <f12+0xd0c>  // b.plast
    78d8:	f90a1660 	str	x0, [x19, #5160]
    78dc:	1e630381 	ucvtf	d1, w28
    78e0:	fd4a1e60 	ldr	d0, [x19, #5176]
    78e4:	1e612800 	fadd	d0, d0, d1
    78e8:	fd0a1e60 	str	d0, [x19, #5176]
    78ec:	a900e2d7 	stp	x23, x24, [x22, #8]
    78f0:	aa1603f8 	mov	x24, x22
    78f4:	fd0002c8 	str	d8, [x22]
    78f8:	f949da61 	ldr	x1, [x19, #5040]
    78fc:	f949ee60 	ldr	x0, [x19, #5080]
    7900:	cb0102c1 	sub	x1, x22, x1
    7904:	eb00403f 	cmp	x1, x0, lsl #16
    7908:	54000302 	b.cs	7968 <f12+0xd98>  // b.hs, b.nlast
    790c:	d350fc22 	lsr	x2, x1, #16
    7910:	f949fe63 	ldr	x3, [x19, #5112]
    7914:	8b020842 	add	x2, x2, x2, lsl #2
    7918:	d37df042 	lsl	x2, x2, #3
    791c:	8b020060 	add	x0, x3, x2
    7920:	f9401016 	ldr	x22, [x0, #32]
    7924:	b4000236 	cbz	x22, 7968 <f12+0xd98>
    7928:	38626862 	ldrb	w2, [x3, x2]
    792c:	7100085f 	cmp	w2, #0x2
    7930:	54001ec0 	b.eq	7d08 <f12+0x1138>  // b.none
    7934:	7100045f 	cmp	w2, #0x1
    7938:	54000181 	b.ne	7968 <f12+0xd98>  // b.any
    793c:	29430002 	ldp	w2, w0, [x0, #24]
    7940:	92403c21 	and	x1, x1, #0xffff
    7944:	9b027c21 	mul	x1, x1, x2
    7948:	d360fc21 	lsr	x1, x1, #32
    794c:	eb00003f 	cmp	x1, x0
    7950:	540000c2 	b.cs	7968 <f12+0xd98>  // b.hs, b.nlast
    7954:	8b0102d6 	add	x22, x22, x1
    7958:	394002c0 	ldrb	w0, [x22]
    795c:	7103fc1f 	cmp	w0, #0xff
    7960:	54001bc0 	b.eq	7cd8 <f12+0x1108>  // b.none
    7964:	390002d4 	strb	w20, [x22]
    7968:	d100075a 	sub	x26, x26, #0x1
    796c:	b100075f 	cmn	x26, #0x1
    7970:	54fff2c0 	b.eq	77c8 <f12+0xbf8>  // b.none
    7974:	b953a660 	ldr	w0, [x19, #5028]
    7978:	f87a7b37 	ldr	x23, [x25, x26, lsl #3]
    797c:	35fff7a0 	cbnz	w0, 7870 <f12+0xca0>
    7980:	52800001 	mov	w1, #0x0                   	// #0
    7984:	d2800300 	mov	x0, #0x18                  	// #24
    7988:	97fff56e 	bl	4f40 <fwp_heap_alloc>
    798c:	aa0003f6 	mov	x22, x0
    7990:	17ffffd7 	b	78ec <f12+0xd1c>
    7994:	72003c1f 	tst	w0, #0xffff
    7998:	54ffd960 	b.eq	74c4 <f12+0x8f4>  // b.none
    799c:	b4001475 	cbz	x21, 7c28 <f12+0x1058>
    79a0:	aa1503f6 	mov	x22, x21
    79a4:	d2800018 	mov	x24, #0x0                   	// #0
    79a8:	f9400ad6 	ldr	x22, [x22, #16]
    79ac:	aa1803e0 	mov	x0, x24
    79b0:	91000718 	add	x24, x24, #0x1
    79b4:	b5ffffb6 	cbnz	x22, 79a8 <f12+0xdd8>
    79b8:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    79bc:	eb01031f 	cmp	x24, x1
    79c0:	54001d08 	b.hi	7d60 <f12+0x1190>  // b.pmore
    79c4:	91000800 	add	x0, x0, #0x2
    79c8:	52800041 	mov	w1, #0x2                   	// #2
    79cc:	d37df000 	lsl	x0, x0, #3
    79d0:	97fff55c 	bl	4f40 <fwp_heap_alloc>
    79d4:	eb17031f 	cmp	x24, x23
    79d8:	aa0003f9 	mov	x25, x0
    79dc:	9a979317 	csel	x23, x24, x23, ls	// ls = plast
    79e0:	aa1503e1 	mov	x1, x21
    79e4:	d503201f 	nop
    79e8:	f9400420 	ldr	x0, [x1, #8]
    79ec:	f8367b20 	str	x0, [x25, x22, lsl #3]
    79f0:	910006d6 	add	x22, x22, #0x1
    79f4:	f9400821 	ldr	x1, [x1, #16]
    79f8:	b5ffff81 	cbnz	x1, 79e8 <f12+0xe18>
    79fc:	b40011f7 	cbz	x23, 7c38 <f12+0x1068>
    7a00:	f9400343 	ldr	x3, [x26]
    7a04:	b90023ff 	str	wzr, [sp, #32]
    7a08:	17fffeb7 	b	74e4 <f12+0x914>
    7a0c:	72003c1f 	tst	w0, #0xffff
    7a10:	54ffcc80 	b.eq	73a0 <f12+0x7d0>  // b.none
    7a14:	d503201f 	nop
    7a18:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7a1c:	eb0002ff 	cmp	x23, x0
    7a20:	54001a88 	b.hi	7d70 <f12+0x11a0>  // b.pmore
    7a24:	910006e0 	add	x0, x23, #0x1
    7a28:	52800021 	mov	w1, #0x1                   	// #1
    7a2c:	d37df000 	lsl	x0, x0, #3
    7a30:	97fff544 	bl	4f40 <fwp_heap_alloc>
    7a34:	9117c262 	add	x2, x19, #0x5f0
    7a38:	f9000017 	str	x23, [x0]
    7a3c:	aa0003fa 	mov	x26, x0
    7a40:	f9000ffa 	str	x26, [sp, #24]
    7a44:	f949d841 	ldr	x1, [x2, #5040]
    7a48:	f949ec40 	ldr	x0, [x2, #5080]
    7a4c:	cb010341 	sub	x1, x26, x1
    7a50:	eb00403f 	cmp	x1, x0, lsl #16
    7a54:	54000322 	b.cs	7ab8 <f12+0xee8>  // b.hs, b.nlast
    7a58:	d350fc20 	lsr	x0, x1, #16
    7a5c:	f949fc43 	ldr	x3, [x2, #5112]
    7a60:	8b000800 	add	x0, x0, x0, lsl #2
    7a64:	d37df002 	lsl	x2, x0, #3
    7a68:	8b020060 	add	x0, x3, x2
    7a6c:	f9401018 	ldr	x24, [x0, #32]
    7a70:	b4000258 	cbz	x24, 7ab8 <f12+0xee8>
    7a74:	38626862 	ldrb	w2, [x3, x2]
    7a78:	7100085f 	cmp	w2, #0x2
    7a7c:	54000e20 	b.eq	7c40 <f12+0x1070>  // b.none
    7a80:	7100045f 	cmp	w2, #0x1
    7a84:	540001a1 	b.ne	7ab8 <f12+0xee8>  // b.any
    7a88:	29430002 	ldp	w2, w0, [x0, #24]
    7a8c:	92403c21 	and	x1, x1, #0xffff
    7a90:	9b027c21 	mul	x1, x1, x2
    7a94:	d360fc21 	lsr	x1, x1, #32
    7a98:	eb00003f 	cmp	x1, x0
    7a9c:	540000e2 	b.cs	7ab8 <f12+0xee8>  // b.hs, b.nlast
    7aa0:	8b010318 	add	x24, x24, x1
    7aa4:	39400300 	ldrb	w0, [x24]
    7aa8:	7103fc1f 	cmp	w0, #0xff
    7aac:	54001020 	b.eq	7cb0 <f12+0x10e0>  // b.none
    7ab0:	52800020 	mov	w0, #0x1                   	// #1
    7ab4:	39000300 	strb	w0, [x24]
    7ab8:	aa1603e0 	mov	x0, x22
    7abc:	17fffe3f 	b	73b8 <f12+0x7e8>
    7ac0:	52800041 	mov	w1, #0x2                   	// #2
    7ac4:	d2800100 	mov	x0, #0x8                   	// #8
    7ac8:	97fff51e 	bl	4f40 <fwp_heap_alloc>
    7acc:	aa0003f8 	mov	x24, x0
    7ad0:	9117c260 	add	x0, x19, #0x5f0
    7ad4:	f900031f 	str	xzr, [x24]
    7ad8:	f949d801 	ldr	x1, [x0, #5040]
    7adc:	f949ec00 	ldr	x0, [x0, #5080]
    7ae0:	cb010301 	sub	x1, x24, x1
    7ae4:	eb00403f 	cmp	x1, x0, lsl #16
    7ae8:	540003e2 	b.cs	7b64 <f12+0xf94>  // b.hs, b.nlast
    7aec:	d2800016 	mov	x22, #0x0                   	// #0
    7af0:	17fffd0b 	b	6f1c <f12+0x34c>
    7af4:	aa1c03e0 	mov	x0, x28
    7af8:	97fff352 	bl	4840 <fwp_rc_forget_slot>
    7afc:	17fffeff 	b	76f8 <f12+0xb28>
    7b00:	f100037f 	cmp	x27, #0x0
    7b04:	fa401b40 	ccmp	x26, #0x0, #0x0, ne	// ne = any
    7b08:	54ffb321 	b.ne	716c <f12+0x59c>  // b.any
    7b0c:	f94013e0 	ldr	x0, [sp, #32]
    7b10:	9101c294 	add	x20, x20, #0x70
    7b14:	f9402fe1 	ldr	x1, [sp, #88]
    7b18:	f9019a81 	str	x1, [x20, #816]
    7b1c:	97fff22d 	bl	43d0 <fwp_tape_buffers_release>
    7b20:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7b24:	f947e863 	ldr	x3, [x3, #4048]
    7b28:	d2800262 	mov	x2, #0x13                  	// #19
    7b2c:	d2800021 	mov	x1, #0x1                   	// #1
    7b30:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7b34:	91166000 	add	x0, x0, #0x598
    7b38:	f9400063 	ldr	x3, [x3]
    7b3c:	97ffeb91 	bl	2980 <fwrite@plt>
    7b40:	d2800000 	mov	x0, #0x0                   	// #0
    7b44:	97ffeb9b 	bl	29b0 <fflush@plt>
    7b48:	52800cc0 	mov	w0, #0x66                  	// #102
    7b4c:	97ffeba9 	bl	29f0 <_Exit@plt>
    7b50:	eb18033f 	cmp	x25, x24
    7b54:	54ff9040 	b.eq	6d5c <f12+0x18c>  // b.none
    7b58:	f9403a9c 	ldr	x28, [x20, #112]
    7b5c:	17fffc9d 	b	6dd0 <f12+0x200>
    7b60:	b5ffa136 	cbnz	x22, 6f84 <f12+0x3b4>
    7b64:	d280001c 	mov	x28, #0x0                   	// #0
    7b68:	17fffd2d 	b	701c <f12+0x44c>
    7b6c:	d0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0xc0>
    7b70:	913d4000 	add	x0, x0, #0xf50
    7b74:	94000e7b 	bl	b560 <atexit>
    7b78:	35fffd40 	cbnz	w0, 7b20 <f12+0xf50>
    7b7c:	52800020 	mov	w0, #0x1                   	// #1
    7b80:	b9036700 	str	w0, [x24, #868]
    7b84:	17fffc62 	b	6d0c <f12+0x13c>
    7b88:	72003c3f 	tst	w1, #0xffff
    7b8c:	54ff9fa1 	b.ne	6f80 <f12+0x3b0>  // b.any
    7b90:	17fffcf7 	b	6f6c <f12+0x39c>
    7b94:	72003c3f 	tst	w1, #0xffff
    7b98:	54ff88e0 	b.eq	6cb4 <f12+0xe4>  // b.none
    7b9c:	aa1703e0 	mov	x0, x23
    7ba0:	97fff84c 	bl	5cd0 <fwp_closure_drop>
    7ba4:	b5ff89b5 	cbnz	x21, 6cd8 <f12+0x108>
    7ba8:	52800000 	mov	w0, #0x0                   	// #0
    7bac:	d2800017 	mov	x23, #0x0                   	// #0
    7bb0:	97ffee90 	bl	35f0 <descent_phase_step>
    7bb4:	17fffc53 	b	6d00 <f12+0x130>
    7bb8:	aa1c03fb 	mov	x27, x28
    7bbc:	17fffd57 	b	7118 <f12+0x548>
    7bc0:	72003c3f 	tst	w1, #0xffff
    7bc4:	54ffba61 	b.ne	7310 <f12+0x740>  // b.any
    7bc8:	17fffdcd 	b	72fc <f12+0x72c>
    7bcc:	3ccb8002 	ldur	q2, [x0, #184]
    7bd0:	9102e001 	add	x1, x0, #0xb8
    7bd4:	3ccc8001 	ldur	q1, [x0, #200]
    7bd8:	f900781f 	str	xzr, [x0, #240]
    7bdc:	4f000400 	movi	v0.4s, #0x0
    7be0:	ad010702 	stp	q2, q1, [x24, #32]
    7be4:	a94d8002 	ldp	x2, x0, [x0, #216]
    7be8:	f9000f00 	str	x0, [x24, #24]
    7bec:	f9401820 	ldr	x0, [x1, #48]
    7bf0:	f9002302 	str	x2, [x24, #64]
    7bf4:	f9002700 	str	x0, [x24, #72]
    7bf8:	ad000020 	stp	q0, q0, [x1]
    7bfc:	3d800820 	str	q0, [x1, #32]
    7c00:	f900183f 	str	xzr, [x1, #48]
    7c04:	17fffc81 	b	6e08 <f12+0x238>
    7c08:	d37ffb1a 	lsl	x26, x24, #1
    7c0c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7c10:	eb00035f 	cmp	x26, x0
    7c14:	9a80d35a 	csel	x26, x26, x0, le
    7c18:	8b1a0741 	add	x1, x26, x26, lsl #1
    7c1c:	8b010b41 	add	x1, x26, x1, lsl #2
    7c20:	d37df021 	lsl	x1, x1, #3
    7c24:	17fffc59 	b	6d88 <f12+0x1b8>
    7c28:	52800041 	mov	w1, #0x2                   	// #2
    7c2c:	d2800100 	mov	x0, #0x8                   	// #8
    7c30:	97fff4c4 	bl	4f40 <fwp_heap_alloc>
    7c34:	aa0003f9 	mov	x25, x0
    7c38:	d2800018 	mov	x24, #0x0                   	// #0
    7c3c:	17fffee3 	b	77c8 <f12+0xbf8>
    7c40:	72003c3f 	tst	w1, #0xffff
    7c44:	54fff300 	b.eq	7aa4 <f12+0xed4>  // b.none
    7c48:	aa1603e0 	mov	x0, x22
    7c4c:	17fffddb 	b	73b8 <f12+0x7e8>
    7c50:	aa0203e0 	mov	x0, x2
    7c54:	d2800101 	mov	x1, #0x8                   	// #8
    7c58:	f90017e2 	str	x2, [sp, #40]
    7c5c:	97ffeb01 	bl	2860 <calloc@plt>
    7c60:	f94017e2 	ldr	x2, [sp, #40]
    7c64:	aa0003fa 	mov	x26, x0
    7c68:	17fffd3e 	b	7160 <f12+0x590>
    7c6c:	f9400343 	ldr	x3, [x26]
    7c70:	b7fffdc3 	tbnz	x3, #63, 7c28 <f12+0x1058>
    7c74:	9117c261 	add	x1, x19, #0x5f0
    7c78:	f9400fe4 	ldr	x4, [sp, #24]
    7c7c:	f949d820 	ldr	x0, [x1, #5040]
    7c80:	f949ec21 	ldr	x1, [x1, #5080]
    7c84:	cb000080 	sub	x0, x4, x0
    7c88:	eb01401f 	cmp	x0, x1, lsl #16
    7c8c:	54fffce2 	b.cs	7c28 <f12+0x1058>  // b.hs, b.nlast
    7c90:	9240f877 	and	x23, x3, #0x7fffffffffffffff
    7c94:	17fffdf8 	b	7474 <f12+0x8a4>
    7c98:	aa1903e0 	mov	x0, x25
    7c9c:	97fff2e9 	bl	4840 <fwp_rc_forget_slot>
    7ca0:	17fffcb6 	b	6f78 <f12+0x3a8>
    7ca4:	aa1703e0 	mov	x0, x23
    7ca8:	97fff2e6 	bl	4840 <fwp_rc_forget_slot>
    7cac:	17fffd97 	b	7308 <f12+0x738>
    7cb0:	aa1803e0 	mov	x0, x24
    7cb4:	97fff2e3 	bl	4840 <fwp_rc_forget_slot>
    7cb8:	17ffff7e 	b	7ab0 <f12+0xee0>
    7cbc:	97fff29a 	bl	4724 <fwp_rc_wide_dup>
    7cc0:	17fffc03 	b	6ccc <f12+0xfc>
    7cc4:	d280001b 	mov	x27, #0x0                   	// #0
    7cc8:	17fffe4b 	b	75f4 <f12+0xa24>
    7ccc:	d2800019 	mov	x25, #0x0                   	// #0
    7cd0:	d2800018 	mov	x24, #0x0                   	// #0
    7cd4:	17fffebd 	b	77c8 <f12+0xbf8>
    7cd8:	aa1603e0 	mov	x0, x22
    7cdc:	97fff2d9 	bl	4840 <fwp_rc_forget_slot>
    7ce0:	17ffff21 	b	7964 <f12+0xd94>
    7ce4:	f9400436 	ldr	x22, [x1, #8]
    7ce8:	b4ffe4d6 	cbz	x22, 7980 <f12+0xdb0>
    7cec:	f9400820 	ldr	x0, [x1, #16]
    7cf0:	cb160000 	sub	x0, x0, x22
    7cf4:	eb00037f 	cmp	x27, x0
    7cf8:	54ffe448 	b.hi	7980 <f12+0xdb0>  // b.pmore
    7cfc:	8b1b02c0 	add	x0, x22, x27
    7d00:	f9000420 	str	x0, [x1, #8]
    7d04:	17fffee6 	b	789c <f12+0xccc>
    7d08:	72003c3f 	tst	w1, #0xffff
    7d0c:	54ffe2e1 	b.ne	7968 <f12+0xd98>  // b.any
    7d10:	17ffff12 	b	7958 <f12+0xd88>
    7d14:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7d18:	9124e000 	add	x0, x0, #0x938
    7d1c:	97ffeeb9 	bl	3800 <fwp_trap>
    7d20:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7d24:	91274000 	add	x0, x0, #0x9d0
    7d28:	97ffeeb6 	bl	3800 <fwp_trap>
    7d2c:	97ffecc1 	bl	3030 <fwp_heap_oom>
    7d30:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7d34:	91260000 	add	x0, x0, #0x980
    7d38:	97ffeeb2 	bl	3800 <fwp_trap>
    7d3c:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7d40:	9128c000 	add	x0, x0, #0xa30
    7d44:	97ffeeaf 	bl	3800 <fwp_trap>
    7d48:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7d4c:	91294000 	add	x0, x0, #0xa50
    7d50:	97ffeeac 	bl	3800 <fwp_trap>
    7d54:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7d58:	912a0000 	add	x0, x0, #0xa80
    7d5c:	97ffeea9 	bl	3800 <fwp_trap>
    7d60:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7d64:	912ac000 	add	x0, x0, #0xab0
    7d68:	97ffeea6 	bl	3800 <fwp_trap>
    7d6c:	97ffeac5 	bl	2880 <__stack_chk_fail@plt>
    7d70:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7d74:	912b0000 	add	x0, x0, #0xac0
    7d78:	97ffeea2 	bl	3800 <fwp_trap>
    7d7c:	90000020 	adrp	x0, b000 <__divti3+0x190>
    7d80:	912b4000 	add	x0, x0, #0xad0
    7d84:	97ffee9f 	bl	3800 <fwp_trap>
    7d88:	97ffead2 	bl	28d0 <abort@plt>
    7d8c:	97ffeb3d 	bl	2a80 <fwp_trap_overflow.constprop.0>

0000000000007d90 <fwp_owned_entry12>:
    7d90:	f9400000 	ldr	x0, [x0]
    7d94:	17fffb8f 	b	6bd0 <f12>
    7d98:	d503201f 	nop
    7d9c:	d503201f 	nop

0000000000007da0 <e12>:
    7da0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7da4:	910003fd 	mov	x29, sp
    7da8:	f9000bf3 	str	x19, [sp, #16]
    7dac:	f9400013 	ldr	x19, [x0]
    7db0:	aa1303e0 	mov	x0, x19
    7db4:	97fff6ab 	bl	5860 <fwp_rc_share>
    7db8:	aa1303e0 	mov	x0, x19
    7dbc:	97fffb85 	bl	6bd0 <f12>
    7dc0:	aa0003f3 	mov	x19, x0
    7dc4:	97fff6a7 	bl	5860 <fwp_rc_share>
    7dc8:	aa1303e0 	mov	x0, x19
    7dcc:	f9400bf3 	ldr	x19, [sp, #16]
    7dd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7dd4:	d65f03c0 	ret
    7dd8:	d503201f 	nop
    7ddc:	d503201f 	nop

0000000000007de0 <fwp_args23>:
    7de0:	7100003f 	cmp	w1, #0x0
    7de4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7de8:	54000041 	b.ne	7df0 <fwp_args23+0x10>  // b.any
    7dec:	d65f03c0 	ret
    7df0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    7df4:	9117c042 	add	x2, x2, #0x5f0
    7df8:	f9400001 	ldr	x1, [x0]
    7dfc:	f949d843 	ldr	x3, [x2, #5040]
    7e00:	f949ec40 	ldr	x0, [x2, #5080]
    7e04:	cb030021 	sub	x1, x1, x3
    7e08:	eb00403f 	cmp	x1, x0, lsl #16
    7e0c:	54ffff02 	b.cs	7dec <fwp_args23+0xc>  // b.hs, b.nlast
    7e10:	d350fc20 	lsr	x0, x1, #16
    7e14:	f949fc44 	ldr	x4, [x2, #5112]
    7e18:	8b000800 	add	x0, x0, x0, lsl #2
    7e1c:	d37df002 	lsl	x2, x0, #3
    7e20:	8b020083 	add	x3, x4, x2
    7e24:	f9401060 	ldr	x0, [x3, #32]
    7e28:	b4fffe20 	cbz	x0, 7dec <fwp_args23+0xc>
    7e2c:	38626882 	ldrb	w2, [x4, x2]
    7e30:	7100085f 	cmp	w2, #0x2
    7e34:	54000220 	b.eq	7e78 <fwp_args23+0x98>  // b.none
    7e38:	7100045f 	cmp	w2, #0x1
    7e3c:	54fffd81 	b.ne	7dec <fwp_args23+0xc>  // b.any
    7e40:	29430864 	ldp	w4, w2, [x3, #24]
    7e44:	92403c21 	and	x1, x1, #0xffff
    7e48:	9b047c21 	mul	x1, x1, x4
    7e4c:	d360fc21 	lsr	x1, x1, #32
    7e50:	eb02003f 	cmp	x1, x2
    7e54:	54fffcc2 	b.cs	7dec <fwp_args23+0xc>  // b.hs, b.nlast
    7e58:	8b010000 	add	x0, x0, x1
    7e5c:	39400001 	ldrb	w1, [x0]
    7e60:	34fffc61 	cbz	w1, 7dec <fwp_args23+0xc>
    7e64:	7103f43f 	cmp	w1, #0xfd
    7e68:	540000e8 	b.hi	7e84 <fwp_args23+0xa4>  // b.pmore
    7e6c:	11000421 	add	w1, w1, #0x1
    7e70:	39000001 	strb	w1, [x0]
    7e74:	d65f03c0 	ret
    7e78:	72003c3f 	tst	w1, #0xffff
    7e7c:	54ffff00 	b.eq	7e5c <fwp_args23+0x7c>  // b.none
    7e80:	d65f03c0 	ret
    7e84:	17fff228 	b	4724 <fwp_rc_wide_dup>
    7e88:	d503201f 	nop
    7e8c:	d503201f 	nop

0000000000007e90 <fwp_args12>:
    7e90:	7100003f 	cmp	w1, #0x0
    7e94:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7e98:	54000041 	b.ne	7ea0 <fwp_args12+0x10>  // b.any
    7e9c:	d65f03c0 	ret
    7ea0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    7ea4:	9117c042 	add	x2, x2, #0x5f0
    7ea8:	f9400001 	ldr	x1, [x0]
    7eac:	f949d843 	ldr	x3, [x2, #5040]
    7eb0:	f949ec40 	ldr	x0, [x2, #5080]
    7eb4:	cb030021 	sub	x1, x1, x3
    7eb8:	eb00403f 	cmp	x1, x0, lsl #16
    7ebc:	54ffff02 	b.cs	7e9c <fwp_args12+0xc>  // b.hs, b.nlast
    7ec0:	d350fc20 	lsr	x0, x1, #16
    7ec4:	f949fc44 	ldr	x4, [x2, #5112]
    7ec8:	8b000800 	add	x0, x0, x0, lsl #2
    7ecc:	d37df002 	lsl	x2, x0, #3
    7ed0:	8b020083 	add	x3, x4, x2
    7ed4:	f9401060 	ldr	x0, [x3, #32]
    7ed8:	b4fffe20 	cbz	x0, 7e9c <fwp_args12+0xc>
    7edc:	38626882 	ldrb	w2, [x4, x2]
    7ee0:	7100085f 	cmp	w2, #0x2
    7ee4:	54000220 	b.eq	7f28 <fwp_args12+0x98>  // b.none
    7ee8:	7100045f 	cmp	w2, #0x1
    7eec:	54fffd81 	b.ne	7e9c <fwp_args12+0xc>  // b.any
    7ef0:	29430864 	ldp	w4, w2, [x3, #24]
    7ef4:	92403c21 	and	x1, x1, #0xffff
    7ef8:	9b047c21 	mul	x1, x1, x4
    7efc:	d360fc21 	lsr	x1, x1, #32
    7f00:	eb02003f 	cmp	x1, x2
    7f04:	54fffcc2 	b.cs	7e9c <fwp_args12+0xc>  // b.hs, b.nlast
    7f08:	8b010000 	add	x0, x0, x1
    7f0c:	39400001 	ldrb	w1, [x0]
    7f10:	34fffc61 	cbz	w1, 7e9c <fwp_args12+0xc>
    7f14:	7103f43f 	cmp	w1, #0xfd
    7f18:	540000e8 	b.hi	7f34 <fwp_args12+0xa4>  // b.pmore
    7f1c:	11000421 	add	w1, w1, #0x1
    7f20:	39000001 	strb	w1, [x0]
    7f24:	d65f03c0 	ret
    7f28:	72003c3f 	tst	w1, #0xffff
    7f2c:	54ffff00 	b.eq	7f0c <fwp_args12+0x7c>  // b.none
    7f30:	d65f03c0 	ret
    7f34:	17fff1fc 	b	4724 <fwp_rc_wide_dup>
    7f38:	d503201f 	nop
    7f3c:	d503201f 	nop

0000000000007f40 <fwp_caps12>:
    7f40:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7f44:	910003fd 	mov	x29, sp
    7f48:	f9000bf3 	str	x19, [sp, #16]
    7f4c:	aa0003f3 	mov	x19, x0
    7f50:	b9400400 	ldr	w0, [x0, #4]
    7f54:	340004a0 	cbz	w0, 7fe8 <fwp_caps12+0xa8>
    7f58:	f9400660 	ldr	x0, [x19, #8]
    7f5c:	350004e1 	cbnz	w1, 7ff8 <fwp_caps12+0xb8>
    7f60:	97fff6ad 	bl	5a14 <fwp_drop0>
    7f64:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    7f68:	9117c042 	add	x2, x2, #0x5f0
    7f6c:	f949d840 	ldr	x0, [x2, #5040]
    7f70:	f949ec41 	ldr	x1, [x2, #5080]
    7f74:	cb000260 	sub	x0, x19, x0
    7f78:	eb01401f 	cmp	x0, x1, lsl #16
    7f7c:	54000382 	b.cs	7fec <fwp_caps12+0xac>  // b.hs, b.nlast
    7f80:	d350fc01 	lsr	x1, x0, #16
    7f84:	f949fc44 	ldr	x4, [x2, #5112]
    7f88:	8b010821 	add	x1, x1, x1, lsl #2
    7f8c:	d37df021 	lsl	x1, x1, #3
    7f90:	8b010083 	add	x3, x4, x1
    7f94:	f9401062 	ldr	x2, [x3, #32]
    7f98:	b40002a2 	cbz	x2, 7fec <fwp_caps12+0xac>
    7f9c:	38616881 	ldrb	w1, [x4, x1]
    7fa0:	7100083f 	cmp	w1, #0x2
    7fa4:	540006c0 	b.eq	807c <fwp_caps12+0x13c>  // b.none
    7fa8:	7100043f 	cmp	w1, #0x1
    7fac:	54000201 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    7fb0:	29430464 	ldp	w4, w1, [x3, #24]
    7fb4:	92403c00 	and	x0, x0, #0xffff
    7fb8:	9b047c00 	mul	x0, x0, x4
    7fbc:	d360fc00 	lsr	x0, x0, #32
    7fc0:	eb01001f 	cmp	x0, x1
    7fc4:	54000142 	b.cs	7fec <fwp_caps12+0xac>  // b.hs, b.nlast
    7fc8:	8b000042 	add	x2, x2, x0
    7fcc:	39400040 	ldrb	w0, [x2]
    7fd0:	7100041f 	cmp	w0, #0x1
    7fd4:	540000c1 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    7fd8:	aa1303e0 	mov	x0, x19
    7fdc:	f9400bf3 	ldr	x19, [sp, #16]
    7fe0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7fe4:	17fff2b7 	b	4ac0 <fwp_mem_free>
    7fe8:	34fffbe1 	cbz	w1, 7f64 <fwp_caps12+0x24>
    7fec:	f9400bf3 	ldr	x19, [sp, #16]
    7ff0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7ff4:	d65f03c0 	ret
    7ff8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    7ffc:	9117c042 	add	x2, x2, #0x5f0
    8000:	f949d843 	ldr	x3, [x2, #5040]
    8004:	f949ec41 	ldr	x1, [x2, #5080]
    8008:	cb030000 	sub	x0, x0, x3
    800c:	eb01401f 	cmp	x0, x1, lsl #16
    8010:	54fffee2 	b.cs	7fec <fwp_caps12+0xac>  // b.hs, b.nlast
    8014:	d350fc01 	lsr	x1, x0, #16
    8018:	f949fc44 	ldr	x4, [x2, #5112]
    801c:	8b010821 	add	x1, x1, x1, lsl #2
    8020:	d37df021 	lsl	x1, x1, #3
    8024:	8b010083 	add	x3, x4, x1
    8028:	f9401062 	ldr	x2, [x3, #32]
    802c:	b4fffe02 	cbz	x2, 7fec <fwp_caps12+0xac>
    8030:	38616881 	ldrb	w1, [x4, x1]
    8034:	7100083f 	cmp	w1, #0x2
    8038:	54000280 	b.eq	8088 <fwp_caps12+0x148>  // b.none
    803c:	7100043f 	cmp	w1, #0x1
    8040:	54fffd61 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    8044:	92403c01 	and	x1, x0, #0xffff
    8048:	29430064 	ldp	w4, w0, [x3, #24]
    804c:	9b047c21 	mul	x1, x1, x4
    8050:	d360fc21 	lsr	x1, x1, #32
    8054:	eb00003f 	cmp	x1, x0
    8058:	54fffca2 	b.cs	7fec <fwp_caps12+0xac>  // b.hs, b.nlast
    805c:	8b010042 	add	x2, x2, x1
    8060:	39400040 	ldrb	w0, [x2]
    8064:	34fffc40 	cbz	w0, 7fec <fwp_caps12+0xac>
    8068:	7103f41f 	cmp	w0, #0xfd
    806c:	54000148 	b.hi	8094 <fwp_caps12+0x154>  // b.pmore
    8070:	11000400 	add	w0, w0, #0x1
    8074:	39000040 	strb	w0, [x2]
    8078:	17ffffdd 	b	7fec <fwp_caps12+0xac>
    807c:	72003c1f 	tst	w0, #0xffff
    8080:	54fffb61 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    8084:	17ffffd2 	b	7fcc <fwp_caps12+0x8c>
    8088:	72003c1f 	tst	w0, #0xffff
    808c:	54fffb01 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    8090:	17fffff4 	b	8060 <fwp_caps12+0x120>
    8094:	f9400bf3 	ldr	x19, [sp, #16]
    8098:	aa0203e0 	mov	x0, x2
    809c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    80a0:	17fff1a1 	b	4724 <fwp_rc_wide_dup>

00000000000080a4 <fwp_drop2>:
    80a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    80a8:	910003fd 	mov	x29, sp
    80ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    80b0:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xbf0>
    80b4:	9117c2d5 	add	x21, x22, #0x5f0
    80b8:	a90153f3 	stp	x19, x20, [sp, #16]
    80bc:	aa0003f3 	mov	x19, x0
    80c0:	f949daa1 	ldr	x1, [x21, #5040]
    80c4:	f949eea0 	ldr	x0, [x21, #5080]
    80c8:	cb010261 	sub	x1, x19, x1
    80cc:	eb00403f 	cmp	x1, x0, lsl #16
    80d0:	54000382 	b.cs	8140 <fwp_drop2+0x9c>  // b.hs, b.nlast
    80d4:	d350fc22 	lsr	x2, x1, #16
    80d8:	f949fea3 	ldr	x3, [x21, #5112]
    80dc:	8b020842 	add	x2, x2, x2, lsl #2
    80e0:	d37df042 	lsl	x2, x2, #3
    80e4:	8b020060 	add	x0, x3, x2
    80e8:	f9401014 	ldr	x20, [x0, #32]
    80ec:	b40002b4 	cbz	x20, 8140 <fwp_drop2+0x9c>
    80f0:	38626862 	ldrb	w2, [x3, x2]
    80f4:	7100085f 	cmp	w2, #0x2
    80f8:	540002c0 	b.eq	8150 <fwp_drop2+0xac>  // b.none
    80fc:	7100045f 	cmp	w2, #0x1
    8100:	54000201 	b.ne	8140 <fwp_drop2+0x9c>  // b.any
    8104:	29430002 	ldp	w2, w0, [x0, #24]
    8108:	92403c21 	and	x1, x1, #0xffff
    810c:	9b027c21 	mul	x1, x1, x2
    8110:	d360fc21 	lsr	x1, x1, #32
    8114:	eb00003f 	cmp	x1, x0
    8118:	54000142 	b.cs	8140 <fwp_drop2+0x9c>  // b.hs, b.nlast
    811c:	8b010294 	add	x20, x20, x1
    8120:	39400280 	ldrb	w0, [x20]
    8124:	340000e0 	cbz	w0, 8140 <fwp_drop2+0x9c>
    8128:	7100041f 	cmp	w0, #0x1
    812c:	540001e0 	b.eq	8168 <fwp_drop2+0xc4>  // b.none
    8130:	7103fc1f 	cmp	w0, #0xff
    8134:	540007e0 	b.eq	8230 <fwp_drop2+0x18c>  // b.none
    8138:	51000400 	sub	w0, w0, #0x1
    813c:	39000280 	strb	w0, [x20]
    8140:	a94153f3 	ldp	x19, x20, [sp, #16]
    8144:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8148:	a8c37bfd 	ldp	x29, x30, [sp], #48
    814c:	d65f03c0 	ret
    8150:	72003c3f 	tst	w1, #0xffff
    8154:	54fffe60 	b.eq	8120 <fwp_drop2+0x7c>  // b.none
    8158:	a94153f3 	ldp	x19, x20, [sp, #16]
    815c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    8164:	d65f03c0 	ret
    8168:	9117c2c2 	add	x2, x22, #0x5f0
    816c:	f9400660 	ldr	x0, [x19, #8]
    8170:	f949d841 	ldr	x1, [x2, #5040]
    8174:	f949ec42 	ldr	x2, [x2, #5080]
    8178:	cb010001 	sub	x1, x0, x1
    817c:	eb02403f 	cmp	x1, x2, lsl #16
    8180:	54000382 	b.cs	81f0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    8184:	d350fc22 	lsr	x2, x1, #16
    8188:	8b020842 	add	x2, x2, x2, lsl #2
    818c:	d37df042 	lsl	x2, x2, #3
    8190:	8b020064 	add	x4, x3, x2
    8194:	f9401094 	ldr	x20, [x4, #32]
    8198:	b40002d4 	cbz	x20, 81f0 <fwp_drop2+0x14c>
    819c:	38626862 	ldrb	w2, [x3, x2]
    81a0:	7100085f 	cmp	w2, #0x2
    81a4:	54000400 	b.eq	8224 <fwp_drop2+0x180>  // b.none
    81a8:	7100045f 	cmp	w2, #0x1
    81ac:	54000221 	b.ne	81f0 <fwp_drop2+0x14c>  // b.any
    81b0:	29430883 	ldp	w3, w2, [x4, #24]
    81b4:	92403c21 	and	x1, x1, #0xffff
    81b8:	9b037c21 	mul	x1, x1, x3
    81bc:	d360fc21 	lsr	x1, x1, #32
    81c0:	eb02003f 	cmp	x1, x2
    81c4:	54000162 	b.cs	81f0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    81c8:	8b010294 	add	x20, x20, x1
    81cc:	39400281 	ldrb	w1, [x20]
    81d0:	34000101 	cbz	w1, 81f0 <fwp_drop2+0x14c>
    81d4:	7100043f 	cmp	w1, #0x1
    81d8:	54000220 	b.eq	821c <fwp_drop2+0x178>  // b.none
    81dc:	7103fc3f 	cmp	w1, #0xff
    81e0:	540005a0 	b.eq	8294 <fwp_drop2+0x1f0>  // b.none
    81e4:	51000421 	sub	w1, w1, #0x1
    81e8:	39000281 	strb	w1, [x20]
    81ec:	d503201f 	nop
    81f0:	f9400a74 	ldr	x20, [x19, #16]
    81f4:	aa1303e0 	mov	x0, x19
    81f8:	97fff5bf 	bl	58f4 <fwp_rc_free_arr>
    81fc:	9117c2c0 	add	x0, x22, #0x5f0
    8200:	f949d801 	ldr	x1, [x0, #5040]
    8204:	f949ec00 	ldr	x0, [x0, #5080]
    8208:	cb010281 	sub	x1, x20, x1
    820c:	eb00403f 	cmp	x1, x0, lsl #16
    8210:	54fff982 	b.cs	8140 <fwp_drop2+0x9c>  // b.hs, b.nlast
    8214:	aa1403f3 	mov	x19, x20
    8218:	17ffffaf 	b	80d4 <fwp_drop2+0x30>
    821c:	97fff5b6 	bl	58f4 <fwp_rc_free_arr>
    8220:	17fffff4 	b	81f0 <fwp_drop2+0x14c>
    8224:	72003c3f 	tst	w1, #0xffff
    8228:	54fffe41 	b.ne	81f0 <fwp_drop2+0x14c>  // b.any
    822c:	17ffffe8 	b	81cc <fwp_drop2+0x128>
    8230:	ca544681 	eor	x1, x20, x20, lsr #17
    8234:	9117c2c0 	add	x0, x22, #0x5f0
    8238:	ca412421 	eor	x1, x1, x1, lsr #9
    823c:	8b210c01 	add	x1, x0, w1, uxtb #3
    8240:	f94a2420 	ldr	x0, [x1, #5192]
    8244:	b5000080 	cbnz	x0, 8254 <fwp_drop2+0x1b0>
    8248:	14000010 	b	8288 <fwp_drop2+0x1e4>
    824c:	f9400800 	ldr	x0, [x0, #16]
    8250:	b40001c0 	cbz	x0, 8288 <fwp_drop2+0x1e4>
    8254:	f9400001 	ldr	x1, [x0]
    8258:	eb14003f 	cmp	x1, x20
    825c:	54ffff81 	b.ne	824c <fwp_drop2+0x1a8>  // b.any
    8260:	f9400401 	ldr	x1, [x0, #8]
    8264:	d1000421 	sub	x1, x1, #0x1
    8268:	f9000401 	str	x1, [x0, #8]
    826c:	f103f83f 	cmp	x1, #0xfe
    8270:	54fff681 	b.ne	8140 <fwp_drop2+0x9c>  // b.any
    8274:	aa1403e0 	mov	x0, x20
    8278:	97fff172 	bl	4840 <fwp_rc_forget_slot>
    827c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8280:	39000280 	strb	w0, [x20]
    8284:	17ffffaf 	b	8140 <fwp_drop2+0x9c>
    8288:	f0000000 	adrp	x0, b000 <__divti3+0x190>
    828c:	9123c000 	add	x0, x0, #0x8f0
    8290:	97ffed5c 	bl	3800 <fwp_trap>
    8294:	ca544680 	eor	x0, x20, x20, lsr #17
    8298:	9117c2c1 	add	x1, x22, #0x5f0
    829c:	ca402400 	eor	x0, x0, x0, lsr #9
    82a0:	8b200c20 	add	x0, x1, w0, uxtb #3
    82a4:	f94a2400 	ldr	x0, [x0, #5192]
    82a8:	b5000080 	cbnz	x0, 82b8 <fwp_drop2+0x214>
    82ac:	17fffff7 	b	8288 <fwp_drop2+0x1e4>
    82b0:	f9400800 	ldr	x0, [x0, #16]
    82b4:	b4fffea0 	cbz	x0, 8288 <fwp_drop2+0x1e4>
    82b8:	f9400001 	ldr	x1, [x0]
    82bc:	eb14003f 	cmp	x1, x20
    82c0:	54ffff81 	b.ne	82b0 <fwp_drop2+0x20c>  // b.any
    82c4:	f9400401 	ldr	x1, [x0, #8]
    82c8:	d1000421 	sub	x1, x1, #0x1
    82cc:	f9000401 	str	x1, [x0, #8]
    82d0:	f103f83f 	cmp	x1, #0xfe
    82d4:	54fff8e1 	b.ne	81f0 <fwp_drop2+0x14c>  // b.any
    82d8:	aa1403e0 	mov	x0, x20
    82dc:	97fff159 	bl	4840 <fwp_rc_forget_slot>
    82e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    82e4:	39000280 	strb	w0, [x20]
    82e8:	17ffffc2 	b	81f0 <fwp_drop2+0x14c>
    82ec:	d503201f 	nop

00000000000082f0 <fwp_arg_drop23>:
    82f0:	7100003f 	cmp	w1, #0x0
    82f4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    82f8:	54000041 	b.ne	8300 <fwp_arg_drop23+0x10>  // b.any
    82fc:	d65f03c0 	ret
    8300:	f9400000 	ldr	x0, [x0]
    8304:	17ffff68 	b	80a4 <fwp_drop2>
    8308:	d503201f 	nop
    830c:	d503201f 	nop

0000000000008310 <fwp_caps23>:
    8310:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8314:	910003fd 	mov	x29, sp
    8318:	f9000bf3 	str	x19, [sp, #16]
    831c:	aa0003f3 	mov	x19, x0
    8320:	b9400400 	ldr	w0, [x0, #4]
    8324:	340004a0 	cbz	w0, 83b8 <fwp_caps23+0xa8>
    8328:	f9400660 	ldr	x0, [x19, #8]
    832c:	350004e1 	cbnz	w1, 83c8 <fwp_caps23+0xb8>
    8330:	97ffff5d 	bl	80a4 <fwp_drop2>
    8334:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    8338:	9117c042 	add	x2, x2, #0x5f0
    833c:	f949d840 	ldr	x0, [x2, #5040]
    8340:	f949ec41 	ldr	x1, [x2, #5080]
    8344:	cb000260 	sub	x0, x19, x0
    8348:	eb01401f 	cmp	x0, x1, lsl #16
    834c:	54000382 	b.cs	83bc <fwp_caps23+0xac>  // b.hs, b.nlast
    8350:	d350fc01 	lsr	x1, x0, #16
    8354:	f949fc44 	ldr	x4, [x2, #5112]
    8358:	8b010821 	add	x1, x1, x1, lsl #2
    835c:	d37df021 	lsl	x1, x1, #3
    8360:	8b010083 	add	x3, x4, x1
    8364:	f9401062 	ldr	x2, [x3, #32]
    8368:	b40002a2 	cbz	x2, 83bc <fwp_caps23+0xac>
    836c:	38616881 	ldrb	w1, [x4, x1]
    8370:	7100083f 	cmp	w1, #0x2
    8374:	540006c0 	b.eq	844c <fwp_caps23+0x13c>  // b.none
    8378:	7100043f 	cmp	w1, #0x1
    837c:	54000201 	b.ne	83bc <fwp_caps23+0xac>  // b.any
    8380:	29430464 	ldp	w4, w1, [x3, #24]
    8384:	92403c00 	and	x0, x0, #0xffff
    8388:	9b047c00 	mul	x0, x0, x4
    838c:	d360fc00 	lsr	x0, x0, #32
    8390:	eb01001f 	cmp	x0, x1
    8394:	54000142 	b.cs	83bc <fwp_caps23+0xac>  // b.hs, b.nlast
    8398:	8b000042 	add	x2, x2, x0
    839c:	39400040 	ldrb	w0, [x2]
    83a0:	7100041f 	cmp	w0, #0x1
    83a4:	540000c1 	b.ne	83bc <fwp_caps23+0xac>  // b.any
    83a8:	aa1303e0 	mov	x0, x19
    83ac:	f9400bf3 	ldr	x19, [sp, #16]
    83b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    83b4:	17fff1c3 	b	4ac0 <fwp_mem_free>
    83b8:	34fffbe1 	cbz	w1, 8334 <fwp_caps23+0x24>
    83bc:	f9400bf3 	ldr	x19, [sp, #16]
    83c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    83c4:	d65f03c0 	ret
    83c8:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    83cc:	9117c042 	add	x2, x2, #0x5f0
    83d0:	f949d843 	ldr	x3, [x2, #5040]
    83d4:	f949ec41 	ldr	x1, [x2, #5080]
    83d8:	cb030000 	sub	x0, x0, x3
    83dc:	eb01401f 	cmp	x0, x1, lsl #16
    83e0:	54fffee2 	b.cs	83bc <fwp_caps23+0xac>  // b.hs, b.nlast
    83e4:	d350fc01 	lsr	x1, x0, #16
    83e8:	f949fc44 	ldr	x4, [x2, #5112]
    83ec:	8b010821 	add	x1, x1, x1, lsl #2
    83f0:	d37df021 	lsl	x1, x1, #3
    83f4:	8b010083 	add	x3, x4, x1
    83f8:	f9401062 	ldr	x2, [x3, #32]
    83fc:	b4fffe02 	cbz	x2, 83bc <fwp_caps23+0xac>
    8400:	38616881 	ldrb	w1, [x4, x1]
    8404:	7100083f 	cmp	w1, #0x2
    8408:	54000280 	b.eq	8458 <fwp_caps23+0x148>  // b.none
    840c:	7100043f 	cmp	w1, #0x1
    8410:	54fffd61 	b.ne	83bc <fwp_caps23+0xac>  // b.any
    8414:	92403c01 	and	x1, x0, #0xffff
    8418:	29430064 	ldp	w4, w0, [x3, #24]
    841c:	9b047c21 	mul	x1, x1, x4
    8420:	d360fc21 	lsr	x1, x1, #32
    8424:	eb00003f 	cmp	x1, x0
    8428:	54fffca2 	b.cs	83bc <fwp_caps23+0xac>  // b.hs, b.nlast
    842c:	8b010042 	add	x2, x2, x1
    8430:	39400040 	ldrb	w0, [x2]
    8434:	34fffc40 	cbz	w0, 83bc <fwp_caps23+0xac>
    8438:	7103f41f 	cmp	w0, #0xfd
    843c:	54000148 	b.hi	8464 <fwp_caps23+0x154>  // b.pmore
    8440:	11000400 	add	w0, w0, #0x1
    8444:	39000040 	strb	w0, [x2]
    8448:	17ffffdd 	b	83bc <fwp_caps23+0xac>
    844c:	72003c1f 	tst	w0, #0xffff
    8450:	54fffb61 	b.ne	83bc <fwp_caps23+0xac>  // b.any
    8454:	17ffffd2 	b	839c <fwp_caps23+0x8c>
    8458:	72003c1f 	tst	w0, #0xffff
    845c:	54fffb01 	b.ne	83bc <fwp_caps23+0xac>  // b.any
    8460:	17fffff4 	b	8430 <fwp_caps23+0x120>
    8464:	f9400bf3 	ldr	x19, [sp, #16]
    8468:	aa0203e0 	mov	x0, x2
    846c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8470:	17fff0ad 	b	4724 <fwp_rc_wide_dup>

0000000000008474 <f23>:
    8474:	d101c3ff 	sub	sp, sp, #0x70
    8478:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    847c:	f947f421 	ldr	x1, [x1, #4072]
    8480:	a9027bfd 	stp	x29, x30, [sp, #32]
    8484:	910083fd 	add	x29, sp, #0x20
    8488:	a90563f7 	stp	x23, x24, [sp, #80]
    848c:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xbf0>
    8490:	9117c2e3 	add	x3, x23, #0x5f0
    8494:	a90353f3 	stp	x19, x20, [sp, #48]
    8498:	a9045bf5 	stp	x21, x22, [sp, #64]
    849c:	aa0003f6 	mov	x22, x0
    84a0:	a9066bf9 	stp	x25, x26, [sp, #96]
    84a4:	f949ec62 	ldr	x2, [x3, #5080]
    84a8:	f9400024 	ldr	x4, [x1]
    84ac:	f9000fe4 	str	x4, [sp, #24]
    84b0:	d2800004 	mov	x4, #0x0                   	// #0
    84b4:	f949d861 	ldr	x1, [x3, #5040]
    84b8:	d370bc42 	lsl	x2, x2, #16
    84bc:	b40015a0 	cbz	x0, 8770 <f23+0x2fc>
    84c0:	f9400818 	ldr	x24, [x0, #16]
    84c4:	cb010301 	sub	x1, x24, x1
    84c8:	eb02003f 	cmp	x1, x2
    84cc:	54000362 	b.cs	8538 <f23+0xc4>  // b.hs, b.nlast
    84d0:	f949fc60 	ldr	x0, [x3, #5112]
    84d4:	d350fc22 	lsr	x2, x1, #16
    84d8:	8b020842 	add	x2, x2, x2, lsl #2
    84dc:	8b020c02 	add	x2, x0, x2, lsl #3
    84e0:	f9401040 	ldr	x0, [x2, #32]
    84e4:	b40002a0 	cbz	x0, 8538 <f23+0xc4>
    84e8:	39400043 	ldrb	w3, [x2]
    84ec:	7100087f 	cmp	w3, #0x2
    84f0:	540013a0 	b.eq	8764 <f23+0x2f0>  // b.none
    84f4:	7100047f 	cmp	w3, #0x1
    84f8:	540001c1 	b.ne	8530 <f23+0xbc>  // b.any
    84fc:	29430843 	ldp	w3, w2, [x2, #24]
    8500:	92403c21 	and	x1, x1, #0xffff
    8504:	9b037c21 	mul	x1, x1, x3
    8508:	d360fc21 	lsr	x1, x1, #32
    850c:	eb02003f 	cmp	x1, x2
    8510:	54000102 	b.cs	8530 <f23+0xbc>  // b.hs, b.nlast
    8514:	8b010000 	add	x0, x0, x1
    8518:	39400001 	ldrb	w1, [x0]
    851c:	340000a1 	cbz	w1, 8530 <f23+0xbc>
    8520:	7103f43f 	cmp	w1, #0xfd
    8524:	54001688 	b.hi	87f4 <f23+0x380>  // b.pmore
    8528:	11000421 	add	w1, w1, #0x1
    852c:	39000001 	strb	w1, [x0]
    8530:	d2800000 	mov	x0, #0x0                   	// #0
    8534:	b40000d6 	cbz	x22, 854c <f23+0xd8>
    8538:	aa1603e1 	mov	x1, x22
    853c:	d2800000 	mov	x0, #0x0                   	// #0
    8540:	f9400821 	ldr	x1, [x1, #16]
    8544:	91000400 	add	x0, x0, #0x1
    8548:	b5ffffc1 	cbnz	x1, 8540 <f23+0xcc>
    854c:	b40011b8 	cbz	x24, 8780 <f23+0x30c>
    8550:	aa1803e1 	mov	x1, x24
    8554:	d2800002 	mov	x2, #0x0                   	// #0
    8558:	f9400821 	ldr	x1, [x1, #16]
    855c:	91000442 	add	x2, x2, #0x1
    8560:	b5ffffc1 	cbnz	x1, 8558 <f23+0xe4>
    8564:	eb00005f 	cmp	x2, x0
    8568:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    856c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    8570:	eb01033f 	cmp	x25, x1
    8574:	54001468 	b.hi	8800 <f23+0x38c>  // b.pmore
    8578:	d37ffb33 	lsl	x19, x25, #1
    857c:	52800041 	mov	w1, #0x2                   	// #2
    8580:	91000660 	add	x0, x19, #0x1
    8584:	d37df000 	lsl	x0, x0, #3
    8588:	97fff26e 	bl	4f40 <fwp_heap_alloc>
    858c:	9117c2e1 	add	x1, x23, #0x5f0
    8590:	aa0003fa 	mov	x26, x0
    8594:	f9000013 	str	x19, [x0]
    8598:	aa0103e0 	mov	x0, x1
    859c:	f949d821 	ldr	x1, [x1, #5040]
    85a0:	f949ec00 	ldr	x0, [x0, #5080]
    85a4:	cb010341 	sub	x1, x26, x1
    85a8:	eb00403f 	cmp	x1, x0, lsl #16
    85ac:	54000342 	b.cs	8614 <f23+0x1a0>  // b.hs, b.nlast
    85b0:	9117c2e2 	add	x2, x23, #0x5f0
    85b4:	d350fc20 	lsr	x0, x1, #16
    85b8:	8b000800 	add	x0, x0, x0, lsl #2
    85bc:	f949fc43 	ldr	x3, [x2, #5112]
    85c0:	d37df002 	lsl	x2, x0, #3
    85c4:	8b020060 	add	x0, x3, x2
    85c8:	f9401013 	ldr	x19, [x0, #32]
    85cc:	b4000253 	cbz	x19, 8614 <f23+0x1a0>
    85d0:	38626862 	ldrb	w2, [x3, x2]
    85d4:	7100085f 	cmp	w2, #0x2
    85d8:	54000c00 	b.eq	8758 <f23+0x2e4>  // b.none
    85dc:	7100045f 	cmp	w2, #0x1
    85e0:	540001a1 	b.ne	8614 <f23+0x1a0>  // b.any
    85e4:	29430002 	ldp	w2, w0, [x0, #24]
    85e8:	92403c21 	and	x1, x1, #0xffff
    85ec:	9b027c21 	mul	x1, x1, x2
    85f0:	d360fc21 	lsr	x1, x1, #32
    85f4:	eb00003f 	cmp	x1, x0
    85f8:	540000e2 	b.cs	8614 <f23+0x1a0>  // b.hs, b.nlast
    85fc:	8b010273 	add	x19, x19, x1
    8600:	39400260 	ldrb	w0, [x19]
    8604:	7103fc1f 	cmp	w0, #0xff
    8608:	54000da0 	b.eq	87bc <f23+0x348>  // b.none
    860c:	52800020 	mov	w0, #0x1                   	// #1
    8610:	39000260 	strb	w0, [x19]
    8614:	b4000259 	cbz	x25, 865c <f23+0x1e8>
    8618:	8b191359 	add	x25, x26, x25, lsl #4
    861c:	aa1a03f3 	mov	x19, x26
    8620:	aa1603f5 	mov	x21, x22
    8624:	aa1803f4 	mov	x20, x24
    8628:	f9400683 	ldr	x3, [x20, #8]
    862c:	f94006a2 	ldr	x2, [x21, #8]
    8630:	f9400861 	ldr	x1, [x3, #16]
    8634:	f9400840 	ldr	x0, [x2, #16]
    8638:	fd400461 	ldr	d1, [x3, #8]
    863c:	fd400440 	ldr	d0, [x2, #8]
    8640:	97fff3c0 	bl	5540 <w107>
    8644:	f9000660 	str	x0, [x19, #8]
    8648:	f8010e61 	str	x1, [x19, #16]!
    864c:	f9400a94 	ldr	x20, [x20, #16]
    8650:	f9400ab5 	ldr	x21, [x21, #16]
    8654:	eb13033f 	cmp	x25, x19
    8658:	54fffe81 	b.ne	8628 <f23+0x1b4>  // b.any
    865c:	aa1803e0 	mov	x0, x24
    8660:	97fffe91 	bl	80a4 <fwp_drop2>
    8664:	aa1603e0 	mov	x0, x22
    8668:	97fffe8f 	bl	80a4 <fwp_drop2>
    866c:	9117c2f7 	add	x23, x23, #0x5f0
    8670:	aa1a03e0 	mov	x0, x26
    8674:	97fff407 	bl	5690 <w164.constprop.0>
    8678:	aa0103f3 	mov	x19, x1
    867c:	aa0003f4 	mov	x20, x0
    8680:	aa1a03e0 	mov	x0, x26
    8684:	97fff8b3 	bl	6950 <fwp_drop4>
    8688:	a900cff4 	stp	x20, x19, [sp, #8]
    868c:	910023e1 	add	x1, sp, #0x8
    8690:	52800000 	mov	w0, #0x0                   	// #0
    8694:	97fff42b 	bl	5740 <fwp_data.part.0.constprop.0>
    8698:	f949dae1 	ldr	x1, [x23, #5040]
    869c:	aa0003f3 	mov	x19, x0
    86a0:	f949eee0 	ldr	x0, [x23, #5080]
    86a4:	cb010261 	sub	x1, x19, x1
    86a8:	eb00403f 	cmp	x1, x0, lsl #16
    86ac:	54000322 	b.cs	8710 <f23+0x29c>  // b.hs, b.nlast
    86b0:	d350fc22 	lsr	x2, x1, #16
    86b4:	f949fee3 	ldr	x3, [x23, #5112]
    86b8:	8b020842 	add	x2, x2, x2, lsl #2
    86bc:	d37df042 	lsl	x2, x2, #3
    86c0:	8b020060 	add	x0, x3, x2
    86c4:	f9401014 	ldr	x20, [x0, #32]
    86c8:	b4000254 	cbz	x20, 8710 <f23+0x29c>
    86cc:	38626862 	ldrb	w2, [x3, x2]
    86d0:	7100085f 	cmp	w2, #0x2
    86d4:	540003c0 	b.eq	874c <f23+0x2d8>  // b.none
    86d8:	7100045f 	cmp	w2, #0x1
    86dc:	540001a1 	b.ne	8710 <f23+0x29c>  // b.any
    86e0:	29430002 	ldp	w2, w0, [x0, #24]
    86e4:	92403c21 	and	x1, x1, #0xffff
    86e8:	9b027c21 	mul	x1, x1, x2
    86ec:	d360fc21 	lsr	x1, x1, #32
    86f0:	eb00003f 	cmp	x1, x0
    86f4:	540000e2 	b.cs	8710 <f23+0x29c>  // b.hs, b.nlast
    86f8:	8b010294 	add	x20, x20, x1
    86fc:	39400280 	ldrb	w0, [x20]
    8700:	7103fc1f 	cmp	w0, #0xff
    8704:	54000620 	b.eq	87c8 <f23+0x354>  // b.none
    8708:	52800020 	mov	w0, #0x1                   	// #1
    870c:	39000280 	strb	w0, [x20]
    8710:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8714:	f947f400 	ldr	x0, [x0, #4072]
    8718:	f9400fe2 	ldr	x2, [sp, #24]
    871c:	f9400001 	ldr	x1, [x0]
    8720:	eb010042 	subs	x2, x2, x1
    8724:	d2800001 	mov	x1, #0x0                   	// #0
    8728:	540006a1 	b.ne	87fc <f23+0x388>  // b.any
    872c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8730:	aa1303e0 	mov	x0, x19
    8734:	a94353f3 	ldp	x19, x20, [sp, #48]
    8738:	a9445bf5 	ldp	x21, x22, [sp, #64]
    873c:	a94563f7 	ldp	x23, x24, [sp, #80]
    8740:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8744:	9101c3ff 	add	sp, sp, #0x70
    8748:	d65f03c0 	ret
    874c:	72003c3f 	tst	w1, #0xffff
    8750:	54fffe01 	b.ne	8710 <f23+0x29c>  // b.any
    8754:	17ffffea 	b	86fc <f23+0x288>
    8758:	72003c3f 	tst	w1, #0xffff
    875c:	54fff5c1 	b.ne	8614 <f23+0x1a0>  // b.any
    8760:	17ffffa8 	b	8600 <f23+0x18c>
    8764:	72003c3f 	tst	w1, #0xffff
    8768:	54ffee41 	b.ne	8530 <f23+0xbc>  // b.any
    876c:	17ffff6b 	b	8518 <f23+0xa4>
    8770:	cb0103e1 	neg	x1, x1
    8774:	eb02003f 	cmp	x1, x2
    8778:	540002e3 	b.cc	87d4 <f23+0x360>  // b.lo, b.ul, b.last
    877c:	d503201f 	nop
    8780:	52800041 	mov	w1, #0x2                   	// #2
    8784:	d2800100 	mov	x0, #0x8                   	// #8
    8788:	97fff1ee 	bl	4f40 <fwp_heap_alloc>
    878c:	aa0003e1 	mov	x1, x0
    8790:	9117c2e0 	add	x0, x23, #0x5f0
    8794:	aa0103fa 	mov	x26, x1
    8798:	d2800018 	mov	x24, #0x0                   	// #0
    879c:	f900003f 	str	xzr, [x1]
    87a0:	f949d801 	ldr	x1, [x0, #5040]
    87a4:	f949ec00 	ldr	x0, [x0, #5080]
    87a8:	cb010341 	sub	x1, x26, x1
    87ac:	eb00403f 	cmp	x1, x0, lsl #16
    87b0:	54fff562 	b.cs	865c <f23+0x1e8>  // b.hs, b.nlast
    87b4:	d2800019 	mov	x25, #0x0                   	// #0
    87b8:	17ffff7e 	b	85b0 <f23+0x13c>
    87bc:	aa1303e0 	mov	x0, x19
    87c0:	97fff020 	bl	4840 <fwp_rc_forget_slot>
    87c4:	17ffff92 	b	860c <f23+0x198>
    87c8:	aa1403e0 	mov	x0, x20
    87cc:	97fff01d 	bl	4840 <fwp_rc_forget_slot>
    87d0:	17ffffce 	b	8708 <f23+0x294>
    87d4:	f949fc62 	ldr	x2, [x3, #5112]
    87d8:	d350fc20 	lsr	x0, x1, #16
    87dc:	8b000800 	add	x0, x0, x0, lsl #2
    87e0:	8b000c42 	add	x2, x2, x0, lsl #3
    87e4:	f9401040 	ldr	x0, [x2, #32]
    87e8:	b4fffcc0 	cbz	x0, 8780 <f23+0x30c>
    87ec:	d2800018 	mov	x24, #0x0                   	// #0
    87f0:	17ffff3e 	b	84e8 <f23+0x74>
    87f4:	97ffefcc 	bl	4724 <fwp_rc_wide_dup>
    87f8:	17ffff4e 	b	8530 <f23+0xbc>
    87fc:	97ffe821 	bl	2880 <__stack_chk_fail@plt>
    8800:	f0000000 	adrp	x0, b000 <__divti3+0x190>
    8804:	912ac000 	add	x0, x0, #0xab0
    8808:	97ffebfe 	bl	3800 <fwp_trap>
    880c:	d503201f 	nop

0000000000008810 <fwp_owned_entry23>:
    8810:	f9400000 	ldr	x0, [x0]
    8814:	17ffff18 	b	8474 <f23>
    8818:	d503201f 	nop
    881c:	d503201f 	nop

0000000000008820 <e23>:
    8820:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8824:	910003fd 	mov	x29, sp
    8828:	f9000bf3 	str	x19, [sp, #16]
    882c:	f9400013 	ldr	x19, [x0]
    8830:	aa1303e0 	mov	x0, x19
    8834:	97fff40b 	bl	5860 <fwp_rc_share>
    8838:	aa1303e0 	mov	x0, x19
    883c:	97ffff0e 	bl	8474 <f23>
    8840:	aa0003f3 	mov	x19, x0
    8844:	97fff407 	bl	5860 <fwp_rc_share>
    8848:	aa1303e0 	mov	x0, x19
    884c:	f9400bf3 	ldr	x19, [sp, #16]
    8850:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8854:	d65f03c0 	ret
    8858:	d503201f 	nop
    885c:	d503201f 	nop

0000000000008860 <fwp_write>:
    8860:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8864:	910003fd 	mov	x29, sp
    8868:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    886c:	f947f484 	ldr	x4, [x4, #4072]
    8870:	a90153f3 	stp	x19, x20, [sp, #16]
    8874:	d10943ff 	sub	sp, sp, #0x250
    8878:	b9400045 	ldr	w5, [x2]
    887c:	aa0003f4 	mov	x20, x0
    8880:	f9400080 	ldr	x0, [x4]
    8884:	f90127e0 	str	x0, [sp, #584]
    8888:	d2800000 	mov	x0, #0x0                   	// #0
    888c:	710064bf 	cmp	w5, #0x19
    8890:	54000408 	b.hi	8910 <fwp_write+0xb0>  // b.pmore
    8894:	90000020 	adrp	x0, c000 <_IO_stdin_used+0xa70>
    8898:	aa0103f3 	mov	x19, x1
    889c:	910b8000 	add	x0, x0, #0x2e0
    88a0:	f9013bf5 	str	x21, [sp, #624]
    88a4:	f9013ff6 	str	x22, [sp, #632]
    88a8:	f90153fb 	str	x27, [sp, #672]
    88ac:	f90157fc 	str	x28, [sp, #680]
    88b0:	aa0203fc 	mov	x28, x2
    88b4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    88b8:	10000061 	adr	x1, 88c4 <fwp_write+0x64>
    88bc:	8b20a820 	add	x0, x1, w0, sxth #2
    88c0:	d61f0000 	br	x0
    88c4:	910123e0 	add	x0, sp, #0x48
    88c8:	aa1303e5 	mov	x5, x19
    88cc:	f0000004 	adrp	x4, b000 <__divti3+0x190>
    88d0:	aa0003f3 	mov	x19, x0
    88d4:	912cc084 	add	x4, x4, #0xb30
    88d8:	d2804003 	mov	x3, #0x200                 	// #512
    88dc:	aa0303e1 	mov	x1, x3
    88e0:	52800042 	mov	w2, #0x2                   	// #2
    88e4:	97ffe7c3 	bl	27f0 <__snprintf_chk@plt>
    88e8:	aa1303e0 	mov	x0, x19
    88ec:	97ffe789 	bl	2710 <strlen@plt>
    88f0:	aa1303e1 	mov	x1, x19
    88f4:	aa0003e2 	mov	x2, x0
    88f8:	aa1403e0 	mov	x0, x20
    88fc:	97ffeb25 	bl	3590 <buf_put>
    8900:	f9413bf5 	ldr	x21, [sp, #624]
    8904:	f9413ff6 	ldr	x22, [sp, #632]
    8908:	f94153fb 	ldr	x27, [sp, #672]
    890c:	f94157fc 	ldr	x28, [sp, #680]
    8910:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8914:	f947f400 	ldr	x0, [x0, #4072]
    8918:	f94127e2 	ldr	x2, [sp, #584]
    891c:	f9400001 	ldr	x1, [x0]
    8920:	eb010042 	subs	x2, x2, x1
    8924:	d2800001 	mov	x1, #0x0                   	// #0
    8928:	540077c1 	b.ne	9820 <fwp_write+0xfc0>  // b.any
    892c:	910943ff 	add	sp, sp, #0x250
    8930:	a94153f3 	ldp	x19, x20, [sp, #16]
    8934:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8938:	d65f03c0 	ret
    893c:	910123e0 	add	x0, sp, #0x48
    8940:	aa1303e5 	mov	x5, x19
    8944:	f0000004 	adrp	x4, b000 <__divti3+0x190>
    8948:	aa0003f3 	mov	x19, x0
    894c:	912ca084 	add	x4, x4, #0xb28
    8950:	d2804003 	mov	x3, #0x200                 	// #512
    8954:	17ffffe2 	b	88dc <fwp_write+0x7c>
    8958:	71004cbf 	cmp	w5, #0x13
    895c:	f0000000 	adrp	x0, b000 <__divti3+0x190>
    8960:	f0000001 	adrp	x1, b000 <__divti3+0x190>
    8964:	912c6000 	add	x0, x0, #0xb18
    8968:	912c8021 	add	x1, x1, #0xb20
    896c:	d2800082 	mov	x2, #0x4                   	// #4
    8970:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8974:	aa1403e0 	mov	x0, x20
    8978:	f90143f7 	str	x23, [sp, #640]
    897c:	d2800016 	mov	x22, #0x0                   	// #0
    8980:	f90147f8 	str	x24, [sp, #648]
    8984:	97ffeb03 	bl	3590 <buf_put>
    8988:	f9400260 	ldr	x0, [x19]
    898c:	f0000017 	adrp	x23, b000 <__divti3+0x190>
    8990:	d2800015 	mov	x21, #0x0                   	// #0
    8994:	912e82f7 	add	x23, x23, #0xba0
    8998:	b40047a0 	cbz	x0, 928c <fwp_write+0xa2c>
    899c:	b9400380 	ldr	w0, [x28]
    89a0:	52800003 	mov	w3, #0x0                   	// #0
    89a4:	f9401f82 	ldr	x2, [x28, #56]
    89a8:	71004c1f 	cmp	w0, #0x13
    89ac:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    89b0:	aa1403e0 	mov	x0, x20
    89b4:	8b010e61 	add	x1, x19, x1, lsl #3
    89b8:	f9400421 	ldr	x1, [x1, #8]
    89bc:	97ffffa9 	bl	8860 <fwp_write>
    89c0:	b9400380 	ldr	w0, [x28]
    89c4:	7100481f 	cmp	w0, #0x12
    89c8:	54004b40 	b.eq	9330 <fwp_write+0xad0>  // b.none
    89cc:	f9400260 	ldr	x0, [x19]
    89d0:	910006b5 	add	x21, x21, #0x1
    89d4:	91000ad6 	add	x22, x22, #0x2
    89d8:	eb15001f 	cmp	x0, x21
    89dc:	54004589 	b.ls	928c <fwp_write+0xa2c>  // b.plast
    89e0:	aa1703e1 	mov	x1, x23
    89e4:	aa1403e0 	mov	x0, x20
    89e8:	d2800042 	mov	x2, #0x2                   	// #2
    89ec:	97ffeae9 	bl	3590 <buf_put>
    89f0:	17ffffeb 	b	899c <fwp_write+0x13c>
    89f4:	f0000001 	adrp	x1, b000 <__divti3+0x190>
    89f8:	912d6021 	add	x1, x1, #0xb58
    89fc:	d28000c2 	mov	x2, #0x6                   	// #6
    8a00:	aa1403e0 	mov	x0, x20
    8a04:	91004273 	add	x19, x19, #0x10
    8a08:	97ffeae2 	bl	3590 <buf_put>
    8a0c:	aa1303e0 	mov	x0, x19
    8a10:	97ffe740 	bl	2710 <strlen@plt>
    8a14:	aa1303e1 	mov	x1, x19
    8a18:	aa0003e2 	mov	x2, x0
    8a1c:	aa1403e0 	mov	x0, x20
    8a20:	97ffeadc 	bl	3590 <buf_put>
    8a24:	528007c3 	mov	w3, #0x3e                  	// #62
    8a28:	aa1403e0 	mov	x0, x20
    8a2c:	91001fe1 	add	x1, sp, #0x7
    8a30:	d2800022 	mov	x2, #0x1                   	// #1
    8a34:	39001fe3 	strb	w3, [sp, #7]
    8a38:	17ffffb1 	b	88fc <fwp_write+0x9c>
    8a3c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8a40:	f947f400 	ldr	x0, [x0, #4072]
    8a44:	f94127e2 	ldr	x2, [sp, #584]
    8a48:	f9400001 	ldr	x1, [x0]
    8a4c:	eb010042 	subs	x2, x2, x1
    8a50:	d2800001 	mov	x1, #0x0                   	// #0
    8a54:	540034e1 	b.ne	90f0 <fwp_write+0x890>  // b.any
    8a58:	f9413bf5 	ldr	x21, [sp, #624]
    8a5c:	f0000001 	adrp	x1, b000 <__divti3+0x190>
    8a60:	f9413ff6 	ldr	x22, [sp, #632]
    8a64:	aa1403e0 	mov	x0, x20
    8a68:	912ce021 	add	x1, x1, #0xb38
    8a6c:	d2800142 	mov	x2, #0xa                   	// #10
    8a70:	f94153fb 	ldr	x27, [sp, #672]
    8a74:	f94157fc 	ldr	x28, [sp, #680]
    8a78:	910943ff 	add	sp, sp, #0x250
    8a7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8a80:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8a84:	17ffeac3 	b	3590 <buf_put>
    8a88:	f9400456 	ldr	x22, [x2, #8]
    8a8c:	f90143f7 	str	x23, [sp, #640]
    8a90:	f90147f8 	str	x24, [sp, #648]
    8a94:	b4005b16 	cbz	x22, 95f4 <fwp_write+0xd94>
    8a98:	aa1603e0 	mov	x0, x22
    8a9c:	f0000001 	adrp	x1, b000 <__divti3+0x190>
    8aa0:	912ee021 	add	x1, x1, #0xbb8
    8aa4:	97ffe797 	bl	2900 <strcmp@plt>
    8aa8:	2a0003f5 	mov	w21, w0
    8aac:	34005fe0 	cbz	w0, 96a8 <fwp_write+0xe48>
    8ab0:	aa1603e0 	mov	x0, x22
    8ab4:	97ffe717 	bl	2710 <strlen@plt>
    8ab8:	aa1603e1 	mov	x1, x22
    8abc:	aa0003e2 	mov	x2, x0
    8ac0:	aa1403e0 	mov	x0, x20
    8ac4:	97ffeab3 	bl	3590 <buf_put>
    8ac8:	52800403 	mov	w3, #0x20                  	// #32
    8acc:	91001ff5 	add	x21, sp, #0x7
    8ad0:	aa1503e1 	mov	x1, x21
    8ad4:	aa1403e0 	mov	x0, x20
    8ad8:	d2800022 	mov	x2, #0x1                   	// #1
    8adc:	39001fe3 	strb	w3, [sp, #7]
    8ae0:	97ffeaac 	bl	3590 <buf_put>
    8ae4:	52800f63 	mov	w3, #0x7b                  	// #123
    8ae8:	aa1403e0 	mov	x0, x20
    8aec:	aa1503e1 	mov	x1, x21
    8af0:	d2800022 	mov	x2, #0x1                   	// #1
    8af4:	39001fe3 	strb	w3, [sp, #7]
    8af8:	97ffeaa6 	bl	3590 <buf_put>
    8afc:	b9401380 	ldr	w0, [x28, #16]
    8b00:	52800018 	mov	w24, #0x0                   	// #0
    8b04:	7100001f 	cmp	w0, #0x0
    8b08:	54003aad 	b.le	925c <fwp_write+0x9fc>
    8b0c:	f9014bf9 	str	x25, [sp, #656]
    8b10:	f0000019 	adrp	x25, b000 <__divti3+0x190>
    8b14:	912f8339 	add	x25, x25, #0xbe0
    8b18:	f9014ffa 	str	x26, [sp, #664]
    8b1c:	f000001a 	adrp	x26, b000 <__divti3+0x190>
    8b20:	912e835a 	add	x26, x26, #0xba0
    8b24:	91002276 	add	x22, x19, #0x8
    8b28:	d2800013 	mov	x19, #0x0                   	// #0
    8b2c:	b5003e93 	cbnz	x19, 92fc <fwp_write+0xa9c>
    8b30:	d37df277 	lsl	x23, x19, #3
    8b34:	34003cb8 	cbz	w24, 92c8 <fwp_write+0xa68>
    8b38:	f9401382 	ldr	x2, [x28, #32]
    8b3c:	aa1403e0 	mov	x0, x20
    8b40:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8b44:	52800003 	mov	w3, #0x0                   	// #0
    8b48:	f8776842 	ldr	x2, [x2, x23]
    8b4c:	91000673 	add	x19, x19, #0x1
    8b50:	97ffff44 	bl	8860 <fwp_write>
    8b54:	b9401380 	ldr	w0, [x28, #16]
    8b58:	6b13001f 	cmp	w0, w19
    8b5c:	54fffe8c 	b.gt	8b2c <fwp_write+0x2cc>
    8b60:	f9414bf9 	ldr	x25, [sp, #656]
    8b64:	f9414ffa 	ldr	x26, [sp, #664]
    8b68:	340037b8 	cbz	w24, 925c <fwp_write+0x9fc>
    8b6c:	52800523 	mov	w3, #0x29                  	// #41
    8b70:	aa1503e1 	mov	x1, x21
    8b74:	aa1403e0 	mov	x0, x20
    8b78:	d2800022 	mov	x2, #0x1                   	// #1
    8b7c:	39001fe3 	strb	w3, [sp, #7]
    8b80:	97ffea84 	bl	3590 <buf_put>
    8b84:	f9413bf5 	ldr	x21, [sp, #624]
    8b88:	f9413ff6 	ldr	x22, [sp, #632]
    8b8c:	f94143f7 	ldr	x23, [sp, #640]
    8b90:	f94147f8 	ldr	x24, [sp, #648]
    8b94:	f94153fb 	ldr	x27, [sp, #672]
    8b98:	f94157fc 	ldr	x28, [sp, #680]
    8b9c:	17ffff5d 	b	8910 <fwp_write+0xb0>
    8ba0:	b9404855 	ldr	w21, [x2, #72]
    8ba4:	aa1403e0 	mov	x0, x20
    8ba8:	93407eb6 	sxtw	x22, w21
    8bac:	91000ac1 	add	x1, x22, #0x2
    8bb0:	97ffea45 	bl	34c4 <buf_grow>
    8bb4:	a9400281 	ldp	x1, x0, [x20]
    8bb8:	528e8603 	mov	w3, #0x7430                	// #29744
    8bbc:	78206823 	strh	w3, [x1, x0]
    8bc0:	8b000022 	add	x2, x1, x0
    8bc4:	710002bf 	cmp	w21, #0x0
    8bc8:	540036cd 	b.le	92a0 <fwp_write+0xa40>
    8bcc:	110006a3 	add	w3, w21, #0x1
    8bd0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8bd4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8bd8:	91000449 	add	x9, x2, #0x1
    8bdc:	8b23c043 	add	x3, x2, w3, sxtw
    8be0:	f28aaac6 	movk	x6, #0x5556
    8be4:	f2955568 	movk	x8, #0xaaab
    8be8:	1400000d 	b	8c1c <fwp_write+0x3bc>
    8bec:	d2800021 	mov	x1, #0x1                   	// #1
    8bf0:	528005a5 	mov	w5, #0x2d                  	// #45
    8bf4:	f100001f 	cmp	x0, #0x0
    8bf8:	9b467e60 	smulh	x0, x19, x6
    8bfc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8c00:	381ff465 	strb	w5, [x3], #-1
    8c04:	cb040000 	sub	x0, x0, x4
    8c08:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8c0c:	cb020000 	sub	x0, x0, x2
    8c10:	8b010013 	add	x19, x0, x1
    8c14:	eb03013f 	cmp	x9, x3
    8c18:	54003440 	b.eq	92a0 <fwp_write+0xa40>  // b.none
    8c1c:	9b467e60 	smulh	x0, x19, x6
    8c20:	937ffe64 	asr	x4, x19, #63
    8c24:	52800605 	mov	w5, #0x30                  	// #48
    8c28:	cb040000 	sub	x0, x0, x4
    8c2c:	8b000400 	add	x0, x0, x0, lsl #1
    8c30:	cb000260 	sub	x0, x19, x0
    8c34:	91000c01 	add	x1, x0, #0x3
    8c38:	9bc87c22 	umulh	x2, x1, x8
    8c3c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8c40:	8b4204e2 	add	x2, x7, x2, lsr #1
    8c44:	eb020021 	subs	x1, x1, x2
    8c48:	54fffd60 	b.eq	8bf4 <fwp_write+0x394>  // b.none
    8c4c:	f100043f 	cmp	x1, #0x1
    8c50:	54fffce1 	b.ne	8bec <fwp_write+0x38c>  // b.any
    8c54:	d2800001 	mov	x1, #0x0                   	// #0
    8c58:	52800565 	mov	w5, #0x2b                  	// #43
    8c5c:	17ffffe6 	b	8bf4 <fwp_write+0x394>
    8c60:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8c64:	f947f400 	ldr	x0, [x0, #4072]
    8c68:	f94127e2 	ldr	x2, [sp, #584]
    8c6c:	f9400001 	ldr	x1, [x0]
    8c70:	eb010042 	subs	x2, x2, x1
    8c74:	d2800001 	mov	x1, #0x0                   	// #0
    8c78:	540023c1 	b.ne	90f0 <fwp_write+0x890>  // b.any
    8c7c:	f9413bf5 	ldr	x21, [sp, #624]
    8c80:	f0000001 	adrp	x1, b000 <__divti3+0x190>
    8c84:	f9413ff6 	ldr	x22, [sp, #632]
    8c88:	aa1403e0 	mov	x0, x20
    8c8c:	912d2021 	add	x1, x1, #0xb48
    8c90:	d2800102 	mov	x2, #0x8                   	// #8
    8c94:	17ffff77 	b	8a70 <fwp_write+0x210>
    8c98:	aa1403e0 	mov	x0, x20
    8c9c:	f0000001 	adrp	x1, b000 <__divti3+0x190>
    8ca0:	d28000c2 	mov	x2, #0x6                   	// #6
    8ca4:	912ea021 	add	x1, x1, #0xba8
    8ca8:	97ffea3a 	bl	3590 <buf_put>
    8cac:	d2800015 	mov	x21, #0x0                   	// #0
    8cb0:	f9400263 	ldr	x3, [x19]
    8cb4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8cb8:	54002c60 	b.eq	9244 <fwp_write+0x9e4>  // b.none
    8cbc:	f9401f82 	ldr	x2, [x28, #56]
    8cc0:	f90143f7 	str	x23, [sp, #640]
    8cc4:	f90147f8 	str	x24, [sp, #648]
    8cc8:	d2800857 	mov	x23, #0x42                  	// #66
    8ccc:	f9014bf9 	str	x25, [sp, #656]
    8cd0:	f0000016 	adrp	x22, b000 <__divti3+0x190>
    8cd4:	f9014ffa 	str	x26, [sp, #664]
    8cd8:	912e82d6 	add	x22, x22, #0xba0
    8cdc:	d2800038 	mov	x24, #0x1                   	// #1
    8ce0:	f2a18017 	movk	x23, #0xc00, lsl #16
    8ce4:	d2809099 	mov	x25, #0x484                 	// #1156
    8ce8:	b40004a2 	cbz	x2, 8d7c <fwp_write+0x51c>
    8cec:	b9400040 	ldr	w0, [x2]
    8cf0:	7100701f 	cmp	w0, #0x1c
    8cf4:	540042c0 	b.eq	954c <fwp_write+0xcec>  // b.none
    8cf8:	71006c1f 	cmp	w0, #0x1b
    8cfc:	54000408 	b.hi	8d7c <fwp_write+0x51c>  // b.pmore
    8d00:	9ac02301 	lsl	x1, x24, x0
    8d04:	ea17003f 	tst	x1, x23
    8d08:	540036a1 	b.ne	93dc <fwp_write+0xb7c>  // b.any
    8d0c:	ea19003f 	tst	x1, x25
    8d10:	54003521 	b.ne	93b4 <fwp_write+0xb54>  // b.any
    8d14:	d2800424 	mov	x4, #0x21                  	// #33
    8d18:	ea04003f 	tst	x1, x4
    8d1c:	54000300 	b.eq	8d7c <fwp_write+0x51c>  // b.none
    8d20:	b7f849c3 	tbnz	x3, #63, 9658 <fwp_write+0xdf8>
    8d24:	91002261 	add	x1, x19, #0x8
    8d28:	8b150021 	add	x1, x1, x21
    8d2c:	39400021 	ldrb	w1, [x1]
    8d30:	7100001f 	cmp	w0, #0x0
    8d34:	93401c23 	sxtb	x3, w1
    8d38:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8d3c:	d503201f 	nop
    8d40:	aa1403e0 	mov	x0, x20
    8d44:	52800003 	mov	w3, #0x0                   	// #0
    8d48:	97fffec6 	bl	8860 <fwp_write>
    8d4c:	910006b5 	add	x21, x21, #0x1
    8d50:	f9400260 	ldr	x0, [x19]
    8d54:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8d58:	eb0002bf 	cmp	x21, x0
    8d5c:	540026c2 	b.cs	9234 <fwp_write+0x9d4>  // b.hs, b.nlast
    8d60:	d2800042 	mov	x2, #0x2                   	// #2
    8d64:	aa1603e1 	mov	x1, x22
    8d68:	aa1403e0 	mov	x0, x20
    8d6c:	97ffea09 	bl	3590 <buf_put>
    8d70:	f9401f82 	ldr	x2, [x28, #56]
    8d74:	f9400263 	ldr	x3, [x19]
    8d78:	b5fffba2 	cbnz	x2, 8cec <fwp_write+0x48c>
    8d7c:	d37df2a0 	lsl	x0, x21, #3
    8d80:	b7f83f03 	tbnz	x3, #63, 9560 <fwp_write+0xd00>
    8d84:	91002261 	add	x1, x19, #0x8
    8d88:	8b000020 	add	x0, x1, x0
    8d8c:	f9400001 	ldr	x1, [x0]
    8d90:	17ffffec 	b	8d40 <fwp_write+0x4e0>
    8d94:	a9400e62 	ldp	x2, x3, [x19]
    8d98:	b7f83ca3 	tbnz	x3, #63, 952c <fwp_write+0xccc>
    8d9c:	910123f5 	add	x21, sp, #0x48
    8da0:	aa1503e0 	mov	x0, x21
    8da4:	97ffe81f 	bl	2e20 <fwp_fmt_u128>
    8da8:	aa1503e0 	mov	x0, x21
    8dac:	97ffe659 	bl	2710 <strlen@plt>
    8db0:	aa1503e1 	mov	x1, x21
    8db4:	aa0003e2 	mov	x2, x0
    8db8:	17fffed0 	b	88f8 <fwp_write+0x98>
    8dbc:	fd015be8 	str	d8, [sp, #688]
    8dc0:	1e270268 	fmov	s8, w19
    8dc4:	fd015fe9 	str	d9, [sp, #696]
    8dc8:	1e282100 	fcmp	s8, s8
    8dcc:	54004d26 	b.vs	9770 <fwp_write+0xf10>
    8dd0:	1e20c101 	fabs	s1, s8
    8dd4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8dd8:	1e270000 	fmov	s0, w0
    8ddc:	1e202020 	fcmp	s1, s0
    8de0:	54002c0d 	b.le	9360 <fwp_write+0xb00>
    8de4:	1e202118 	fcmpe	s8, #0.0
    8de8:	f0000002 	adrp	x2, b000 <__divti3+0x190>
    8dec:	9119a042 	add	x2, x2, #0x668
    8df0:	910123f5 	add	x21, sp, #0x48
    8df4:	f0000001 	adrp	x1, b000 <__divti3+0x190>
    8df8:	912be021 	add	x1, x1, #0xaf8
    8dfc:	aa1503e0 	mov	x0, x21
    8e00:	9a81c041 	csel	x1, x2, x1, gt
    8e04:	97ffe6ef 	bl	29c0 <strcpy@plt>
    8e08:	aa1503e0 	mov	x0, x21
    8e0c:	97ffe641 	bl	2710 <strlen@plt>
    8e10:	aa1503e1 	mov	x1, x21
    8e14:	aa0003e2 	mov	x2, x0
    8e18:	aa1403e0 	mov	x0, x20
    8e1c:	97ffe9dd 	bl	3590 <buf_put>
    8e20:	f9413bf5 	ldr	x21, [sp, #624]
    8e24:	f9413ff6 	ldr	x22, [sp, #632]
    8e28:	f94153fb 	ldr	x27, [sp, #672]
    8e2c:	f94157fc 	ldr	x28, [sp, #680]
    8e30:	fd415be8 	ldr	d8, [sp, #688]
    8e34:	fd415fe9 	ldr	d9, [sp, #696]
    8e38:	17fffeb6 	b	8910 <fwp_write+0xb0>
    8e3c:	f9400276 	ldr	x22, [x19]
    8e40:	34002e03 	cbz	w3, 9400 <fwp_write+0xba0>
    8e44:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8e48:	f947f400 	ldr	x0, [x0, #4072]
    8e4c:	f94127e2 	ldr	x2, [sp, #584]
    8e50:	f9400001 	ldr	x1, [x0]
    8e54:	eb010042 	subs	x2, x2, x1
    8e58:	d2800001 	mov	x1, #0x0                   	// #0
    8e5c:	540014a1 	b.ne	90f0 <fwp_write+0x890>  // b.any
    8e60:	aa1603e2 	mov	x2, x22
    8e64:	91002261 	add	x1, x19, #0x8
    8e68:	f9413bf5 	ldr	x21, [sp, #624]
    8e6c:	aa1403e0 	mov	x0, x20
    8e70:	f9413ff6 	ldr	x22, [sp, #632]
    8e74:	17fffeff 	b	8a70 <fwp_write+0x210>
    8e78:	fd015be8 	str	d8, [sp, #688]
    8e7c:	9e670268 	fmov	d8, x19
    8e80:	fd015fe9 	str	d9, [sp, #696]
    8e84:	1e682100 	fcmp	d8, d8
    8e88:	54004746 	b.vs	9770 <fwp_write+0xf10>
    8e8c:	1e60c101 	fabs	d1, d8
    8e90:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8e94:	9e670000 	fmov	d0, x0
    8e98:	910123f5 	add	x21, sp, #0x48
    8e9c:	52800033 	mov	w19, #0x1                   	// #1
    8ea0:	1e602020 	fcmp	d1, d0
    8ea4:	540001ad 	b.le	8ed8 <fwp_write+0x678>
    8ea8:	1e602118 	fcmpe	d8, #0.0
    8eac:	f0000002 	adrp	x2, b000 <__divti3+0x190>
    8eb0:	9119a042 	add	x2, x2, #0x668
    8eb4:	f0000001 	adrp	x1, b000 <__divti3+0x190>
    8eb8:	912be021 	add	x1, x1, #0xaf8
    8ebc:	aa1503e0 	mov	x0, x21
    8ec0:	9a81c041 	csel	x1, x2, x1, gt
    8ec4:	97ffe6bf 	bl	29c0 <strcpy@plt>
    8ec8:	17ffffd0 	b	8e08 <fwp_write+0x5a8>
    8ecc:	11000673 	add	w19, w19, #0x1
    8ed0:	71004a7f 	cmp	w19, #0x12
    8ed4:	54003860 	b.eq	95e0 <fwp_write+0xd80>  // b.none
    8ed8:	1e604100 	fmov	d0, d8
    8edc:	2a1303e1 	mov	w1, w19
    8ee0:	aa1503e0 	mov	x0, x21
    8ee4:	97ffeb2c 	bl	3b94 <fwp_format_g.constprop.0>
    8ee8:	aa1503e0 	mov	x0, x21
    8eec:	d2800001 	mov	x1, #0x0                   	// #0
    8ef0:	97ffe61c 	bl	2760 <strtod@plt>
    8ef4:	1e602100 	fcmp	d8, d0
    8ef8:	54fffea1 	b.ne	8ecc <fwp_write+0x66c>  // b.any
    8efc:	aa1503e0 	mov	x0, x21
    8f00:	97ffea1d 	bl	3774 <fwp_finish_float>
    8f04:	17ffffc1 	b	8e08 <fwp_write+0x5a8>
    8f08:	a9400e62 	ldp	x2, x3, [x19]
    8f0c:	910123f3 	add	x19, sp, #0x48
    8f10:	aa1303e0 	mov	x0, x19
    8f14:	97ffe7c3 	bl	2e20 <fwp_fmt_u128>
    8f18:	17fffe74 	b	88e8 <fwp_write+0x88>
    8f1c:	f90143f7 	str	x23, [sp, #640]
    8f20:	f90147f8 	str	x24, [sp, #648]
    8f24:	2a1303f8 	mov	w24, w19
    8f28:	f9014bf9 	str	x25, [sp, #656]
    8f2c:	f9014ffa 	str	x26, [sp, #664]
    8f30:	f13ffe7f 	cmp	x19, #0xfff
    8f34:	54000049 	b.ls	8f3c <fwp_write+0x6dc>  // b.plast
    8f38:	b9400278 	ldr	w24, [x19]
    8f3c:	f9400f80 	ldr	x0, [x28, #24]
    8f40:	2a1803f5 	mov	w21, w24
    8f44:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8f48:	d37ef6b9 	lsl	x25, x21, #2
    8f4c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8f50:	aa1603e0 	mov	x0, x22
    8f54:	97ffe5ef 	bl	2710 <strlen@plt>
    8f58:	aa1603e1 	mov	x1, x22
    8f5c:	aa0003e2 	mov	x2, x0
    8f60:	aa1403e0 	mov	x0, x20
    8f64:	97ffe98b 	bl	3590 <buf_put>
    8f68:	f9401780 	ldr	x0, [x28, #40]
    8f6c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8f70:	7100001f 	cmp	w0, #0x0
    8f74:	5400068d 	b.le	9044 <fwp_write+0x7e4>
    8f78:	91002276 	add	x22, x19, #0x8
    8f7c:	91001ff5 	add	x21, sp, #0x7
    8f80:	d280001b 	mov	x27, #0x0                   	// #0
    8f84:	5280041a 	mov	w26, #0x20                  	// #32
    8f88:	f9401b80 	ldr	x0, [x28, #48]
    8f8c:	aa1503e1 	mov	x1, x21
    8f90:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8f94:	d2800022 	mov	x2, #0x1                   	// #1
    8f98:	f8786803 	ldr	x3, [x0, x24]
    8f9c:	aa1403e0 	mov	x0, x20
    8fa0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8fa4:	39001ffa 	strb	w26, [sp, #7]
    8fa8:	97ffe97a 	bl	3590 <buf_put>
    8fac:	f13ffeff 	cmp	x23, #0xfff
    8fb0:	b9400261 	ldr	w1, [x19]
    8fb4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8fb8:	7100383f 	cmp	w1, #0xe
    8fbc:	54000160 	b.eq	8fe8 <fwp_write+0x788>  // b.none
    8fc0:	7100403f 	cmp	w1, #0x10
    8fc4:	54001a60 	b.eq	9310 <fwp_write+0xab0>  // b.none
    8fc8:	7100283f 	cmp	w1, #0xa
    8fcc:	54002aa0 	b.eq	9520 <fwp_write+0xcc0>  // b.none
    8fd0:	540014ac 	b.gt	9264 <fwp_write+0xa04>
    8fd4:	71000c3f 	cmp	w1, #0x3
    8fd8:	540029ac 	b.gt	950c <fwp_write+0xcac>
    8fdc:	d37ffee0 	lsr	x0, x23, #63
    8fe0:	37f814a1 	tbnz	w1, #31, 9274 <fwp_write+0xa14>
    8fe4:	d503201f 	nop
    8fe8:	34001460 	cbz	w0, 9274 <fwp_write+0xa14>
    8fec:	52800503 	mov	w3, #0x28                  	// #40
    8ff0:	aa1503e1 	mov	x1, x21
    8ff4:	aa1403e0 	mov	x0, x20
    8ff8:	d2800022 	mov	x2, #0x1                   	// #1
    8ffc:	39001fe3 	strb	w3, [sp, #7]
    9000:	97ffe964 	bl	3590 <buf_put>
    9004:	aa1303e2 	mov	x2, x19
    9008:	aa1703e1 	mov	x1, x23
    900c:	aa1403e0 	mov	x0, x20
    9010:	52800003 	mov	w3, #0x0                   	// #0
    9014:	97fffe13 	bl	8860 <fwp_write>
    9018:	52800523 	mov	w3, #0x29                  	// #41
    901c:	aa1503e1 	mov	x1, x21
    9020:	aa1403e0 	mov	x0, x20
    9024:	d2800022 	mov	x2, #0x1                   	// #1
    9028:	39001fe3 	strb	w3, [sp, #7]
    902c:	97ffe959 	bl	3590 <buf_put>
    9030:	f9401780 	ldr	x0, [x28, #40]
    9034:	9100077b 	add	x27, x27, #0x1
    9038:	b8796800 	ldr	w0, [x0, x25]
    903c:	6b1b001f 	cmp	w0, w27
    9040:	54fffa4c 	b.gt	8f88 <fwp_write+0x728>
    9044:	f9413bf5 	ldr	x21, [sp, #624]
    9048:	f9413ff6 	ldr	x22, [sp, #632]
    904c:	f94143f7 	ldr	x23, [sp, #640]
    9050:	f94147f8 	ldr	x24, [sp, #648]
    9054:	f9414bf9 	ldr	x25, [sp, #656]
    9058:	f9414ffa 	ldr	x26, [sp, #664]
    905c:	f94153fb 	ldr	x27, [sp, #672]
    9060:	f94157fc 	ldr	x28, [sp, #680]
    9064:	17fffe2b 	b	8910 <fwp_write+0xb0>
    9068:	52800783 	mov	w3, #0x3c                  	// #60
    906c:	91001ff3 	add	x19, sp, #0x7
    9070:	aa1303e1 	mov	x1, x19
    9074:	d2800022 	mov	x2, #0x1                   	// #1
    9078:	aa1403e0 	mov	x0, x20
    907c:	39001fe3 	strb	w3, [sp, #7]
    9080:	97ffe944 	bl	3590 <buf_put>
    9084:	f9400795 	ldr	x21, [x28, #8]
    9088:	aa1503e0 	mov	x0, x21
    908c:	97ffe5a1 	bl	2710 <strlen@plt>
    9090:	aa1503e1 	mov	x1, x21
    9094:	aa0003e2 	mov	x2, x0
    9098:	aa1403e0 	mov	x0, x20
    909c:	97ffe93d 	bl	3590 <buf_put>
    90a0:	528007c3 	mov	w3, #0x3e                  	// #62
    90a4:	aa1303e1 	mov	x1, x19
    90a8:	aa1403e0 	mov	x0, x20
    90ac:	d2800022 	mov	x2, #0x1                   	// #1
    90b0:	39001fe3 	strb	w3, [sp, #7]
    90b4:	17fffe12 	b	88fc <fwp_write+0x9c>
    90b8:	f100067f 	cmp	x19, #0x1
    90bc:	540025a0 	b.eq	9570 <fwp_write+0xd10>  // b.none
    90c0:	b100067f 	cmn	x19, #0x1
    90c4:	54002bc0 	b.eq	963c <fwp_write+0xddc>  // b.none
    90c8:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    90cc:	912c0021 	add	x1, x1, #0xb00
    90d0:	d2800022 	mov	x2, #0x1                   	// #1
    90d4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    90d8:	f947f400 	ldr	x0, [x0, #4072]
    90dc:	f94127e4 	ldr	x4, [sp, #584]
    90e0:	f9400003 	ldr	x3, [x0]
    90e4:	eb030084 	subs	x4, x4, x3
    90e8:	d2800003 	mov	x3, #0x0                   	// #0
    90ec:	54ffebe0 	b.eq	8e68 <fwp_write+0x608>  // b.none
    90f0:	f90143f7 	str	x23, [sp, #640]
    90f4:	f90147f8 	str	x24, [sp, #648]
    90f8:	f9014bf9 	str	x25, [sp, #656]
    90fc:	f9014ffa 	str	x26, [sp, #664]
    9100:	fd015be8 	str	d8, [sp, #688]
    9104:	fd015fe9 	str	d9, [sp, #696]
    9108:	97ffe5de 	bl	2880 <__stack_chk_fail@plt>
    910c:	52800b63 	mov	w3, #0x5b                  	// #91
    9110:	91001ff5 	add	x21, sp, #0x7
    9114:	aa1503e1 	mov	x1, x21
    9118:	aa1403e0 	mov	x0, x20
    911c:	d2800022 	mov	x2, #0x1                   	// #1
    9120:	d0000016 	adrp	x22, b000 <__divti3+0x190>
    9124:	912e82d6 	add	x22, x22, #0xba0
    9128:	39001fe3 	strb	w3, [sp, #7]
    912c:	97ffe919 	bl	3590 <buf_put>
    9130:	b4000273 	cbz	x19, 917c <fwp_write+0x91c>
    9134:	f9400661 	ldr	x1, [x19, #8]
    9138:	aa1403e0 	mov	x0, x20
    913c:	f9401f82 	ldr	x2, [x28, #56]
    9140:	52800003 	mov	w3, #0x0                   	// #0
    9144:	97fffdc7 	bl	8860 <fwp_write>
    9148:	f9400a73 	ldr	x19, [x19, #16]
    914c:	b4000193 	cbz	x19, 917c <fwp_write+0x91c>
    9150:	aa1603e1 	mov	x1, x22
    9154:	aa1403e0 	mov	x0, x20
    9158:	d2800042 	mov	x2, #0x2                   	// #2
    915c:	97ffe90d 	bl	3590 <buf_put>
    9160:	f9400661 	ldr	x1, [x19, #8]
    9164:	aa1403e0 	mov	x0, x20
    9168:	f9401f82 	ldr	x2, [x28, #56]
    916c:	52800003 	mov	w3, #0x0                   	// #0
    9170:	97fffdbc 	bl	8860 <fwp_write>
    9174:	f9400a73 	ldr	x19, [x19, #16]
    9178:	b5fffed3 	cbnz	x19, 9150 <fwp_write+0x8f0>
    917c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9180:	aa1503e1 	mov	x1, x21
    9184:	aa1403e0 	mov	x0, x20
    9188:	d2800022 	mov	x2, #0x1                   	// #1
    918c:	39001fe3 	strb	w3, [sp, #7]
    9190:	17fffddb 	b	88fc <fwp_write+0x9c>
    9194:	aa1403e0 	mov	x0, x20
    9198:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    919c:	d28000c2 	mov	x2, #0x6                   	// #6
    91a0:	912e4021 	add	x1, x1, #0xb90
    91a4:	97ffe8fb 	bl	3590 <buf_put>
    91a8:	f9400260 	ldr	x0, [x19]
    91ac:	b40004c0 	cbz	x0, 9244 <fwp_write+0x9e4>
    91b0:	910123f5 	add	x21, sp, #0x48
    91b4:	91002276 	add	x22, x19, #0x8
    91b8:	f90143f7 	str	x23, [sp, #640]
    91bc:	d2800017 	mov	x23, #0x0                   	// #0
    91c0:	f90147f8 	str	x24, [sp, #648]
    91c4:	d0000018 	adrp	x24, b000 <__divti3+0x190>
    91c8:	912e6318 	add	x24, x24, #0xb98
    91cc:	f9014bf9 	str	x25, [sp, #656]
    91d0:	d0000019 	adrp	x25, b000 <__divti3+0x190>
    91d4:	912e8339 	add	x25, x25, #0xba0
    91d8:	f9014ffa 	str	x26, [sp, #664]
    91dc:	14000005 	b	91f0 <fwp_write+0x990>
    91e0:	aa1903e1 	mov	x1, x25
    91e4:	aa1403e0 	mov	x0, x20
    91e8:	d2800042 	mov	x2, #0x2                   	// #2
    91ec:	97ffe8e9 	bl	3590 <buf_put>
    91f0:	38776ac5 	ldrb	w5, [x22, x23]
    91f4:	d2804003 	mov	x3, #0x200                 	// #512
    91f8:	aa1803e4 	mov	x4, x24
    91fc:	aa0303e1 	mov	x1, x3
    9200:	52800042 	mov	w2, #0x2                   	// #2
    9204:	aa1503e0 	mov	x0, x21
    9208:	910006f7 	add	x23, x23, #0x1
    920c:	97ffe579 	bl	27f0 <__snprintf_chk@plt>
    9210:	aa1503e0 	mov	x0, x21
    9214:	97ffe53f 	bl	2710 <strlen@plt>
    9218:	aa1503e1 	mov	x1, x21
    921c:	aa0003e2 	mov	x2, x0
    9220:	aa1403e0 	mov	x0, x20
    9224:	97ffe8db 	bl	3590 <buf_put>
    9228:	f9400260 	ldr	x0, [x19]
    922c:	eb17001f 	cmp	x0, x23
    9230:	54fffd88 	b.hi	91e0 <fwp_write+0x980>  // b.pmore
    9234:	f94143f7 	ldr	x23, [sp, #640]
    9238:	f94147f8 	ldr	x24, [sp, #648]
    923c:	f9414bf9 	ldr	x25, [sp, #656]
    9240:	f9414ffa 	ldr	x26, [sp, #664]
    9244:	52800ba3 	mov	w3, #0x5d                  	// #93
    9248:	aa1403e0 	mov	x0, x20
    924c:	91001fe1 	add	x1, sp, #0x7
    9250:	d2800022 	mov	x2, #0x1                   	// #1
    9254:	39001fe3 	strb	w3, [sp, #7]
    9258:	17fffda9 	b	88fc <fwp_write+0x9c>
    925c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9260:	17fffe44 	b	8b70 <fwp_write+0x310>
    9264:	f10002ff 	cmp	x23, #0x0
    9268:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    926c:	71002c3f 	cmp	w1, #0xb
    9270:	54ffebc0 	b.eq	8fe8 <fwp_write+0x788>  // b.none
    9274:	aa1303e2 	mov	x2, x19
    9278:	aa1703e1 	mov	x1, x23
    927c:	aa1403e0 	mov	x0, x20
    9280:	52800003 	mov	w3, #0x0                   	// #0
    9284:	97fffd77 	bl	8860 <fwp_write>
    9288:	17ffff6a 	b	9030 <fwp_write+0x7d0>
    928c:	aa1403e0 	mov	x0, x20
    9290:	91001fe1 	add	x1, sp, #0x7
    9294:	52800fa3 	mov	w3, #0x7d                  	// #125
    9298:	d2800022 	mov	x2, #0x1                   	// #1
    929c:	17fffe38 	b	8b7c <fwp_write+0x31c>
    92a0:	a9400281 	ldp	x1, x0, [x20]
    92a4:	91000800 	add	x0, x0, #0x2
    92a8:	8b160000 	add	x0, x0, x22
    92ac:	f9000680 	str	x0, [x20, #8]
    92b0:	3820683f 	strb	wzr, [x1, x0]
    92b4:	f9413bf5 	ldr	x21, [sp, #624]
    92b8:	f9413ff6 	ldr	x22, [sp, #632]
    92bc:	f94153fb 	ldr	x27, [sp, #672]
    92c0:	f94157fc 	ldr	x28, [sp, #680]
    92c4:	17fffd93 	b	8910 <fwp_write+0xb0>
    92c8:	f9400f80 	ldr	x0, [x28, #24]
    92cc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    92d0:	aa1b03e0 	mov	x0, x27
    92d4:	97ffe50f 	bl	2710 <strlen@plt>
    92d8:	aa1b03e1 	mov	x1, x27
    92dc:	aa0003e2 	mov	x2, x0
    92e0:	aa1403e0 	mov	x0, x20
    92e4:	97ffe8ab 	bl	3590 <buf_put>
    92e8:	aa1903e1 	mov	x1, x25
    92ec:	aa1403e0 	mov	x0, x20
    92f0:	d2800062 	mov	x2, #0x3                   	// #3
    92f4:	97ffe8a7 	bl	3590 <buf_put>
    92f8:	17fffe10 	b	8b38 <fwp_write+0x2d8>
    92fc:	aa1a03e1 	mov	x1, x26
    9300:	aa1403e0 	mov	x0, x20
    9304:	d2800042 	mov	x2, #0x2                   	// #2
    9308:	97ffe8a2 	bl	3590 <buf_put>
    930c:	17fffe09 	b	8b30 <fwp_write+0x2d0>
    9310:	f9400660 	ldr	x0, [x19, #8]
    9314:	b4fffb00 	cbz	x0, 9274 <fwp_write+0xa14>
    9318:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    931c:	912ee021 	add	x1, x1, #0xbb8
    9320:	97ffe578 	bl	2900 <strcmp@plt>
    9324:	7100001f 	cmp	w0, #0x0
    9328:	1a9f07e0 	cset	w0, ne	// ne = any
    932c:	17ffff2f 	b	8fe8 <fwp_write+0x788>
    9330:	aa1403e0 	mov	x0, x20
    9334:	d2800042 	mov	x2, #0x2                   	// #2
    9338:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    933c:	912ec021 	add	x1, x1, #0xbb0
    9340:	97ffe894 	bl	3590 <buf_put>
    9344:	91004261 	add	x1, x19, #0x10
    9348:	aa1403e0 	mov	x0, x20
    934c:	f9402382 	ldr	x2, [x28, #64]
    9350:	52800003 	mov	w3, #0x0                   	// #0
    9354:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9358:	97fffd42 	bl	8860 <fwp_write>
    935c:	17fffd9c 	b	89cc <fwp_write+0x16c>
    9360:	1e22c109 	fcvt	d9, s8
    9364:	910123f5 	add	x21, sp, #0x48
    9368:	52800033 	mov	w19, #0x1                   	// #1
    936c:	d503201f 	nop
    9370:	1e604120 	fmov	d0, d9
    9374:	2a1303e1 	mov	w1, w19
    9378:	aa1503e0 	mov	x0, x21
    937c:	97ffea06 	bl	3b94 <fwp_format_g.constprop.0>
    9380:	aa1503e0 	mov	x0, x21
    9384:	d2800001 	mov	x1, #0x0                   	// #0
    9388:	97ffe56a 	bl	2930 <strtof@plt>
    938c:	1e202100 	fcmp	s8, s0
    9390:	54ffdb60 	b.eq	8efc <fwp_write+0x69c>  // b.none
    9394:	11000673 	add	w19, w19, #0x1
    9398:	71002a7f 	cmp	w19, #0xa
    939c:	54fffea1 	b.ne	9370 <fwp_write+0xb10>  // b.any
    93a0:	1e604120 	fmov	d0, d9
    93a4:	aa1503e0 	mov	x0, x21
    93a8:	52800121 	mov	w1, #0x9                   	// #9
    93ac:	97ffe9fa 	bl	3b94 <fwp_format_g.constprop.0>
    93b0:	17fffed3 	b	8efc <fwp_write+0x69c>
    93b4:	d37ef6a1 	lsl	x1, x21, #2
    93b8:	b7f81563 	tbnz	x3, #63, 9664 <fwp_write+0xe04>
    93bc:	91002263 	add	x3, x19, #0x8
    93c0:	8b010061 	add	x1, x3, x1
    93c4:	b9400023 	ldr	w3, [x1]
    93c8:	7100081f 	cmp	w0, #0x2
    93cc:	2a0303e1 	mov	w1, w3
    93d0:	93407c63 	sxtw	x3, w3
    93d4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    93d8:	17fffe5a 	b	8d40 <fwp_write+0x4e0>
    93dc:	d37ffaa1 	lsl	x1, x21, #1
    93e0:	b7f81363 	tbnz	x3, #63, 964c <fwp_write+0xdec>
    93e4:	91002263 	add	x3, x19, #0x8
    93e8:	8b010061 	add	x1, x3, x1
    93ec:	79400021 	ldrh	w1, [x1]
    93f0:	7100041f 	cmp	w0, #0x1
    93f4:	93403c23 	sxth	x3, w1
    93f8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    93fc:	17fffe51 	b	8d40 <fwp_write+0x4e0>
    9400:	52800443 	mov	w3, #0x22                  	// #34
    9404:	91001ff5 	add	x21, sp, #0x7
    9408:	91002273 	add	x19, x19, #0x8
    940c:	aa1503e1 	mov	x1, x21
    9410:	aa1403e0 	mov	x0, x20
    9414:	d2800022 	mov	x2, #0x1                   	// #1
    9418:	39001fe3 	strb	w3, [sp, #7]
    941c:	f90143f7 	str	x23, [sp, #640]
    9420:	8b160277 	add	x23, x19, x22
    9424:	f90147f8 	str	x24, [sp, #648]
    9428:	97ffe85a 	bl	3590 <buf_put>
    942c:	b4000696 	cbz	x22, 94fc <fwp_write+0xc9c>
    9430:	d0000018 	adrp	x24, b000 <__divti3+0x190>
    9434:	912d8318 	add	x24, x24, #0xb60
    9438:	f9014bf9 	str	x25, [sp, #656]
    943c:	d0000019 	adrp	x25, b000 <__divti3+0x190>
    9440:	912e0339 	add	x25, x25, #0xb80
    9444:	f9014ffa 	str	x26, [sp, #664]
    9448:	1400000d 	b	947c <fwp_write+0xc1c>
    944c:	710024bf 	cmp	w5, #0x9
    9450:	54000460 	b.eq	94dc <fwp_write+0xc7c>  // b.none
    9454:	710028bf 	cmp	w5, #0xa
    9458:	54000a61 	b.ne	95a4 <fwp_write+0xd44>  // b.any
    945c:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    9460:	aa1403e0 	mov	x0, x20
    9464:	912dc021 	add	x1, x1, #0xb70
    9468:	d2800042 	mov	x2, #0x2                   	// #2
    946c:	97ffe849 	bl	3590 <buf_put>
    9470:	91000673 	add	x19, x19, #0x1
    9474:	eb17027f 	cmp	x19, x23
    9478:	540003e0 	b.eq	94f4 <fwp_write+0xc94>  // b.none
    947c:	39400265 	ldrb	w5, [x19]
    9480:	710034bf 	cmp	w5, #0xd
    9484:	54000180 	b.eq	94b4 <fwp_write+0xc54>  // b.none
    9488:	54fffe29 	b.ls	944c <fwp_write+0xbec>  // b.plast
    948c:	710088bf 	cmp	w5, #0x22
    9490:	540001c0 	b.eq	94c8 <fwp_write+0xc68>  // b.none
    9494:	710170bf 	cmp	w5, #0x5c
    9498:	54000741 	b.ne	9580 <fwp_write+0xd20>  // b.any
    949c:	aa1403e0 	mov	x0, x20
    94a0:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    94a4:	d2800042 	mov	x2, #0x2                   	// #2
    94a8:	912da021 	add	x1, x1, #0xb68
    94ac:	97ffe839 	bl	3590 <buf_put>
    94b0:	17fffff0 	b	9470 <fwp_write+0xc10>
    94b4:	aa1903e1 	mov	x1, x25
    94b8:	aa1403e0 	mov	x0, x20
    94bc:	d2800042 	mov	x2, #0x2                   	// #2
    94c0:	97ffe834 	bl	3590 <buf_put>
    94c4:	17ffffeb 	b	9470 <fwp_write+0xc10>
    94c8:	aa1803e1 	mov	x1, x24
    94cc:	aa1403e0 	mov	x0, x20
    94d0:	d2800042 	mov	x2, #0x2                   	// #2
    94d4:	97ffe82f 	bl	3590 <buf_put>
    94d8:	17ffffe6 	b	9470 <fwp_write+0xc10>
    94dc:	aa1403e0 	mov	x0, x20
    94e0:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    94e4:	d2800042 	mov	x2, #0x2                   	// #2
    94e8:	912de021 	add	x1, x1, #0xb78
    94ec:	97ffe829 	bl	3590 <buf_put>
    94f0:	17ffffe0 	b	9470 <fwp_write+0xc10>
    94f4:	f9414bf9 	ldr	x25, [sp, #656]
    94f8:	f9414ffa 	ldr	x26, [sp, #664]
    94fc:	aa1503e1 	mov	x1, x21
    9500:	aa1403e0 	mov	x0, x20
    9504:	52800443 	mov	w3, #0x22                  	// #34
    9508:	17fffd9c 	b	8b78 <fwp_write+0x318>
    950c:	7100103f 	cmp	w1, #0x4
    9510:	54ffeb21 	b.ne	9274 <fwp_write+0xa14>  // b.any
    9514:	f94006e0 	ldr	x0, [x23, #8]
    9518:	d37ffc00 	lsr	x0, x0, #63
    951c:	17fffeb3 	b	8fe8 <fwp_write+0x788>
    9520:	710002ff 	cmp	w23, #0x0
    9524:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9528:	17fffeb0 	b	8fe8 <fwp_write+0x788>
    952c:	528005a1 	mov	w1, #0x2d                  	// #45
    9530:	eb0203e2 	negs	x2, x2
    9534:	da0303e3 	ngc	x3, x3
    9538:	910127e0 	add	x0, sp, #0x49
    953c:	910123f5 	add	x21, sp, #0x48
    9540:	390123e1 	strb	w1, [sp, #72]
    9544:	97ffe637 	bl	2e20 <fwp_fmt_u128>
    9548:	17fffe18 	b	8da8 <fwp_write+0x548>
    954c:	d37ceea1 	lsl	x1, x21, #4
    9550:	b7f810a3 	tbnz	x3, #63, 9764 <fwp_write+0xf04>
    9554:	91002260 	add	x0, x19, #0x8
    9558:	8b010001 	add	x1, x0, x1
    955c:	17fffdf9 	b	8d40 <fwp_write+0x4e0>
    9560:	f9400a61 	ldr	x1, [x19, #16]
    9564:	8b010000 	add	x0, x0, x1
    9568:	f9400001 	ldr	x1, [x0]
    956c:	17fffdf5 	b	8d40 <fwp_write+0x4e0>
    9570:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    9574:	d2800042 	mov	x2, #0x2                   	// #2
    9578:	912c2021 	add	x1, x1, #0xb08
    957c:	17fffed6 	b	90d4 <fwp_write+0x874>
    9580:	7101fcbf 	cmp	w5, #0x7f
    9584:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9588:	540000e9 	b.ls	95a4 <fwp_write+0xd44>  // b.plast
    958c:	aa1503e1 	mov	x1, x21
    9590:	aa1403e0 	mov	x0, x20
    9594:	d2800022 	mov	x2, #0x1                   	// #1
    9598:	39001fe5 	strb	w5, [sp, #7]
    959c:	97ffe7fd 	bl	3590 <buf_put>
    95a0:	17ffffb4 	b	9470 <fwp_write+0xc10>
    95a4:	d2800203 	mov	x3, #0x10                  	// #16
    95a8:	d0000004 	adrp	x4, b000 <__divti3+0x190>
    95ac:	aa0303e1 	mov	x1, x3
    95b0:	912e2084 	add	x4, x4, #0xb88
    95b4:	910123f6 	add	x22, sp, #0x48
    95b8:	52800042 	mov	w2, #0x2                   	// #2
    95bc:	aa1603e0 	mov	x0, x22
    95c0:	97ffe48c 	bl	27f0 <__snprintf_chk@plt>
    95c4:	aa1603e0 	mov	x0, x22
    95c8:	97ffe452 	bl	2710 <strlen@plt>
    95cc:	aa1603e1 	mov	x1, x22
    95d0:	aa0003e2 	mov	x2, x0
    95d4:	aa1403e0 	mov	x0, x20
    95d8:	97ffe7ee 	bl	3590 <buf_put>
    95dc:	17ffffa5 	b	9470 <fwp_write+0xc10>
    95e0:	1e604100 	fmov	d0, d8
    95e4:	aa1503e0 	mov	x0, x21
    95e8:	52800221 	mov	w1, #0x11                  	// #17
    95ec:	97ffe96a 	bl	3b94 <fwp_format_g.constprop.0>
    95f0:	17fffe43 	b	8efc <fwp_write+0x69c>
    95f4:	b9401040 	ldr	w0, [x2, #16]
    95f8:	350003c0 	cbnz	w0, 9670 <fwp_write+0xe10>
    95fc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9600:	f947f400 	ldr	x0, [x0, #4072]
    9604:	f94127e2 	ldr	x2, [sp, #584]
    9608:	f9400001 	ldr	x1, [x0]
    960c:	eb010042 	subs	x2, x2, x1
    9610:	d2800001 	mov	x1, #0x0                   	// #0
    9614:	54ffd721 	b.ne	90f8 <fwp_write+0x898>  // b.any
    9618:	f9413bf5 	ldr	x21, [sp, #624]
    961c:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    9620:	f9413ff6 	ldr	x22, [sp, #632]
    9624:	aa1403e0 	mov	x0, x20
    9628:	f94143f7 	ldr	x23, [sp, #640]
    962c:	912f6021 	add	x1, x1, #0xbd8
    9630:	f94147f8 	ldr	x24, [sp, #648]
    9634:	d2800042 	mov	x2, #0x2                   	// #2
    9638:	17fffd0e 	b	8a70 <fwp_write+0x210>
    963c:	d0000001 	adrp	x1, b000 <__divti3+0x190>
    9640:	d2800042 	mov	x2, #0x2                   	// #2
    9644:	912c4021 	add	x1, x1, #0xb10
    9648:	17fffea3 	b	90d4 <fwp_write+0x874>
    964c:	f9400a63 	ldr	x3, [x19, #16]
    9650:	8b030021 	add	x1, x1, x3
    9654:	17ffff66 	b	93ec <fwp_write+0xb8c>
    9658:	f9400a61 	ldr	x1, [x19, #16]
    965c:	8b0102a1 	add	x1, x21, x1
    9660:	17fffdb3 	b	8d2c <fwp_write+0x4cc>
    9664:	f9400a63 	ldr	x3, [x19, #16]
    9668:	8b030021 	add	x1, x1, x3
    966c:	17ffff56 	b	93c4 <fwp_write+0xb64>
    9670:	b9404840 	ldr	w0, [x2, #72]
    9674:	91001ff5 	add	x21, sp, #0x7
    9678:	34ffa360 	cbz	w0, 8ae4 <fwp_write+0x284>
    967c:	52800503 	mov	w3, #0x28                  	// #40
    9680:	aa1403e0 	mov	x0, x20
    9684:	aa1503e1 	mov	x1, x21
    9688:	d2800022 	mov	x2, #0x1                   	// #1
    968c:	39001fe3 	strb	w3, [sp, #7]
    9690:	97ffe7c0 	bl	3590 <buf_put>
    9694:	b9401380 	ldr	w0, [x28, #16]
    9698:	52800038 	mov	w24, #0x1                   	// #1
    969c:	7100001f 	cmp	w0, #0x0
    96a0:	54ffa36c 	b.gt	8b0c <fwp_write+0x2ac>
    96a4:	17fffd32 	b	8b6c <fwp_write+0x30c>
    96a8:	f9014bf9 	str	x25, [sp, #656]
    96ac:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10840>
    96b0:	f9014ffa 	str	x26, [sp, #664]
    96b4:	f9400676 	ldr	x22, [x19, #8]
    96b8:	91102333 	add	x19, x25, #0x408
    96bc:	91002273 	add	x19, x19, #0x8
    96c0:	937ffed8 	asr	x24, x22, #63
    96c4:	aa1802c0 	orr	x0, x22, x24
    96c8:	b5000320 	cbnz	x0, 972c <fwp_write+0xecc>
    96cc:	110006b5 	add	w21, w21, #0x1
    96d0:	710016bf 	cmp	w21, #0x5
    96d4:	54ffffc1 	b.ne	96cc <fwp_write+0xe6c>  // b.any
    96d8:	b7f80578 	tbnz	x24, #63, 9784 <fwp_write+0xf24>
    96dc:	910023f3 	add	x19, sp, #0x8
    96e0:	aa1603e2 	mov	x2, x22
    96e4:	aa1303e0 	mov	x0, x19
    96e8:	d2800003 	mov	x3, #0x0                   	// #0
    96ec:	97ffe5cd 	bl	2e20 <fwp_fmt_u128>
    96f0:	910123f5 	add	x21, sp, #0x48
    96f4:	d0000003 	adrp	x3, b000 <__divti3+0x190>
    96f8:	aa1303e4 	mov	x4, x19
    96fc:	aa1503e0 	mov	x0, x21
    9700:	912f4063 	add	x3, x3, #0xbd0
    9704:	d2804002 	mov	x2, #0x200                 	// #512
    9708:	52800041 	mov	w1, #0x2                   	// #2
    970c:	97ffe405 	bl	2720 <__sprintf_chk@plt>
    9710:	aa1503e0 	mov	x0, x21
    9714:	97ffe3ff 	bl	2710 <strlen@plt>
    9718:	aa1503e1 	mov	x1, x21
    971c:	aa0003e2 	mov	x2, x0
    9720:	aa1403e0 	mov	x0, x20
    9724:	97ffe79b 	bl	3590 <buf_put>
    9728:	17fffe47 	b	9044 <fwp_write+0x7e4>
    972c:	f9400277 	ldr	x23, [x19]
    9730:	aa1603e0 	mov	x0, x22
    9734:	aa1803e1 	mov	x1, x24
    9738:	aa1703e2 	mov	x2, x23
    973c:	937ffefa 	asr	x26, x23, #63
    9740:	aa1a03e3 	mov	x3, x26
    9744:	940006ab 	bl	b1f0 <__modti3>
    9748:	aa010000 	orr	x0, x0, x1
    974c:	b40002c0 	cbz	x0, 97a4 <fwp_write+0xf44>
    9750:	110006b5 	add	w21, w21, #0x1
    9754:	91004273 	add	x19, x19, #0x10
    9758:	710016bf 	cmp	w21, #0x5
    975c:	54fffe81 	b.ne	972c <fwp_write+0xecc>  // b.any
    9760:	17ffffde 	b	96d8 <fwp_write+0xe78>
    9764:	f9400a60 	ldr	x0, [x19, #16]
    9768:	8b000021 	add	x1, x1, x0
    976c:	17fffd75 	b	8d40 <fwp_write+0x4e0>
    9770:	528c29c0 	mov	w0, #0x614e                	// #24910
    9774:	910123f5 	add	x21, sp, #0x48
    9778:	72a009c0 	movk	w0, #0x4e, lsl #16
    977c:	b9004be0 	str	w0, [sp, #72]
    9780:	17fffda2 	b	8e08 <fwp_write+0x5a8>
    9784:	528005a1 	mov	w1, #0x2d                  	// #45
    9788:	eb1603e2 	negs	x2, x22
    978c:	da1803e3 	ngc	x3, x24
    9790:	910027e0 	add	x0, sp, #0x9
    9794:	910023f3 	add	x19, sp, #0x8
    9798:	390023e1 	strb	w1, [sp, #8]
    979c:	97ffe5a1 	bl	2e20 <fwp_fmt_u128>
    97a0:	17ffffd4 	b	96f0 <fwp_write+0xe90>
    97a4:	aa1703e2 	mov	x2, x23
    97a8:	aa1a03e3 	mov	x3, x26
    97ac:	aa1603e0 	mov	x0, x22
    97b0:	aa1803e1 	mov	x1, x24
    97b4:	940005af 	bl	ae70 <__divti3>
    97b8:	aa0003e2 	mov	x2, x0
    97bc:	aa0103e3 	mov	x3, x1
    97c0:	b7f80201 	tbnz	x1, #63, 9800 <fwp_write+0xfa0>
    97c4:	910023f3 	add	x19, sp, #0x8
    97c8:	aa1303e0 	mov	x0, x19
    97cc:	97ffe595 	bl	2e20 <fwp_fmt_u128>
    97d0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    97d4:	91102339 	add	x25, x25, #0x408
    97d8:	910123f5 	add	x21, sp, #0x48
    97dc:	aa1303e4 	mov	x4, x19
    97e0:	aa1503e0 	mov	x0, x21
    97e4:	d0000003 	adrp	x3, b000 <__divti3+0x190>
    97e8:	f8616b25 	ldr	x5, [x25, x1]
    97ec:	912f2063 	add	x3, x3, #0xbc8
    97f0:	d2804002 	mov	x2, #0x200                 	// #512
    97f4:	52800041 	mov	w1, #0x2                   	// #2
    97f8:	97ffe3ca 	bl	2720 <__sprintf_chk@plt>
    97fc:	17ffffc5 	b	9710 <fwp_write+0xeb0>
    9800:	528005a4 	mov	w4, #0x2d                  	// #45
    9804:	eb0003e2 	negs	x2, x0
    9808:	da0103e3 	ngc	x3, x1
    980c:	910027e0 	add	x0, sp, #0x9
    9810:	910023f3 	add	x19, sp, #0x8
    9814:	390023e4 	strb	w4, [sp, #8]
    9818:	97ffe582 	bl	2e20 <fwp_fmt_u128>
    981c:	17ffffed 	b	97d0 <fwp_write+0xf70>
    9820:	f9013bf5 	str	x21, [sp, #624]
    9824:	f9013ff6 	str	x22, [sp, #632]
    9828:	f90143f7 	str	x23, [sp, #640]
    982c:	f90147f8 	str	x24, [sp, #648]
    9830:	f9014bf9 	str	x25, [sp, #656]
    9834:	f9014ffa 	str	x26, [sp, #664]
    9838:	f90153fb 	str	x27, [sp, #672]
    983c:	f90157fc 	str	x28, [sp, #680]
    9840:	fd015be8 	str	d8, [sp, #688]
    9844:	fd015fe9 	str	d9, [sp, #696]
    9848:	97ffe40e 	bl	2880 <__stack_chk_fail@plt>
    984c:	d503201f 	nop

0000000000009850 <fwp_main_thread>:
    9850:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    9854:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9858:	9117c001 	add	x1, x0, #0x5f0
    985c:	910003fd 	mov	x29, sp
    9860:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9864:	f947f400 	ldr	x0, [x0, #4072]
    9868:	a90153f3 	stp	x19, x20, [sp, #16]
    986c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9870:	a90363f7 	stp	x23, x24, [sp, #48]
    9874:	a9046bf9 	stp	x25, x26, [sp, #64]
    9878:	a90573fb 	stp	x27, x28, [sp, #80]
    987c:	fd0033e8 	str	d8, [sp, #96]
    9880:	d10643ff 	sub	sp, sp, #0x190
    9884:	b953a421 	ldr	w1, [x1, #5028]
    9888:	f9400002 	ldr	x2, [x0]
    988c:	f81f83a2 	stur	x2, [x29, #-8]
    9890:	d2800002 	mov	x2, #0x0                   	// #0
    9894:	34007541 	cbz	w1, a73c <fwp_main_thread+0xeec>
    9898:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    989c:	9117c000 	add	x0, x0, #0x5f0
    98a0:	b953a800 	ldr	w0, [x0, #5032]
    98a4:	35007440 	cbnz	w0, a72c <fwp_main_thread+0xedc>
    98a8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    98ac:	f00000a0 	adrp	x0, 20000 <__data_start>
    98b0:	f00000a2 	adrp	x2, 20000 <__data_start>
    98b4:	9101c013 	add	x19, x0, #0x70
    98b8:	91104042 	add	x2, x2, #0x410
    98bc:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    98c0:	d2a00024 	mov	x4, #0x10000               	// #65536
    98c4:	d10383a0 	sub	x0, x29, #0xe0
    98c8:	d103e3b5 	sub	x21, x29, #0xf8
    98cc:	f81203a2 	stur	x2, [x29, #-224]
    98d0:	b81283bf 	stur	wzr, [x29, #-216]
    98d4:	f81303a4 	stur	x4, [x29, #-208]
    98d8:	a9018e75 	stp	x21, x3, [x19, #24]
    98dc:	f91f5420 	str	x0, [x1, #16040]
    98e0:	d2800001 	mov	x1, #0x0                   	// #0
    98e4:	97ffe37f 	bl	26e0 <sigaltstack@plt>
    98e8:	3500a500 	cbnz	w0, ad88 <fwp_main_thread+0x1538>
    98ec:	4f000400 	movi	v0.4s, #0x0
    98f0:	d10263a0 	sub	x0, x29, #0x98
    98f4:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    98f8:	9101c021 	add	x1, x1, #0x70
    98fc:	f81603a1 	stur	x1, [x29, #-160]
    9900:	52800082 	mov	w2, #0x4                   	// #4
    9904:	72a10002 	movk	w2, #0x800, lsl #16
    9908:	d10283b7 	sub	x23, x29, #0xa0
    990c:	3d802000 	str	q0, [x0, #128]
    9910:	b81e83a2 	stur	w2, [x29, #-24]
    9914:	ad000000 	stp	q0, q0, [x0]
    9918:	ad010000 	stp	q0, q0, [x0, #32]
    991c:	ad020000 	stp	q0, q0, [x0, #64]
    9920:	ad030000 	stp	q0, q0, [x0, #96]
    9924:	97ffe3c7 	bl	2840 <sigemptyset@plt>
    9928:	3500a300 	cbnz	w0, ad88 <fwp_main_thread+0x1538>
    992c:	aa1703e1 	mov	x1, x23
    9930:	d2800002 	mov	x2, #0x0                   	// #0
    9934:	52800160 	mov	w0, #0xb                   	// #11
    9938:	97ffe3da 	bl	28a0 <sigaction@plt>
    993c:	3500a260 	cbnz	w0, ad88 <fwp_main_thread+0x1538>
    9940:	aa1703e1 	mov	x1, x23
    9944:	d2800002 	mov	x2, #0x0                   	// #0
    9948:	528000e0 	mov	w0, #0x7                   	// #7
    994c:	97ffe3d5 	bl	28a0 <sigaction@plt>
    9950:	3500a1c0 	cbnz	w0, ad88 <fwp_main_thread+0x1538>
    9954:	b9436a60 	ldr	w0, [x19, #872]
    9958:	34001480 	cbz	w0, 9be8 <fwp_main_thread+0x398>
    995c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9960:	9101c000 	add	x0, x0, #0x70
    9964:	b9436c01 	ldr	w1, [x0, #876]
    9968:	34001541 	cbz	w1, 9c10 <fwp_main_thread+0x3c0>
    996c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9970:	9101c015 	add	x21, x0, #0x70
    9974:	f9400ab4 	ldr	x20, [x21, #16]
    9978:	b4000c54 	cbz	x20, 9b00 <fwp_main_thread+0x2b0>
    997c:	aa1403f3 	mov	x19, x20
    9980:	91010297 	add	x23, x20, #0x40
    9984:	39414a98 	ldrb	w24, [x20, #82]
    9988:	52800036 	mov	w22, #0x1                   	// #1
    998c:	39014a96 	strb	w22, [x20, #82]
    9990:	f9401680 	ldr	x0, [x20, #40]
    9994:	b4000620 	cbz	x0, 9a58 <fwp_main_thread+0x208>
    9998:	f9403281 	ldr	x1, [x20, #96]
    999c:	39414680 	ldrb	w0, [x20, #81]
    99a0:	b4000e81 	cbz	x1, 9b70 <fwp_main_thread+0x320>
    99a4:	36000d40 	tbz	w0, #0, 9b4c <fwp_main_thread+0x2fc>
    99a8:	39414a62 	ldrb	w2, [x19, #82]
    99ac:	f9402281 	ldr	x1, [x20, #64]
    99b0:	37001082 	tbnz	w2, #0, 9bc0 <fwp_main_thread+0x370>
    99b4:	f9403260 	ldr	x0, [x19, #96]
    99b8:	a911fe77 	stp	x23, xzr, [x19, #280]
    99bc:	f9009661 	str	x1, [x19, #296]
    99c0:	b4000041 	cbz	x1, 99c8 <fwp_main_thread+0x178>
    99c4:	f9009033 	str	x19, [x1, #288]
    99c8:	f9002293 	str	x19, [x20, #64]
    99cc:	b4000100 	cbz	x0, 99ec <fwp_main_thread+0x19c>
    99d0:	f9407ea1 	ldr	x1, [x21, #248]
    99d4:	39015676 	strb	w22, [x19, #85]
    99d8:	f9003660 	str	x0, [x19, #104]
    99dc:	a910867f 	stp	xzr, x1, [x19, #264]
    99e0:	b4000041 	cbz	x1, 99e8 <fwp_main_thread+0x198>
    99e4:	f9008433 	str	x19, [x1, #264]
    99e8:	f9007eb3 	str	x19, [x21, #248]
    99ec:	39015a7f 	strb	wzr, [x19, #86]
    99f0:	97fff295 	bl	6444 <fwp_block>
    99f4:	f9408e62 	ldr	x2, [x19, #280]
    99f8:	b4000142 	cbz	x2, 9a20 <fwp_main_thread+0x1d0>
    99fc:	a9520261 	ldp	x1, x0, [x19, #288]
    9a00:	b4000ec1 	cbz	x1, 9bd8 <fwp_main_thread+0x388>
    9a04:	f9009420 	str	x0, [x1, #296]
    9a08:	f9409660 	ldr	x0, [x19, #296]
    9a0c:	b4000040 	cbz	x0, 9a14 <fwp_main_thread+0x1c4>
    9a10:	f9009001 	str	x1, [x0, #288]
    9a14:	91080260 	add	x0, x19, #0x200
    9a18:	f900967f 	str	xzr, [x19, #296]
    9a1c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9a20:	39415660 	ldrb	w0, [x19, #85]
    9a24:	f9400aa1 	ldr	x1, [x21, #16]
    9a28:	36000c80 	tbz	w0, #0, 9bb8 <fwp_main_thread+0x368>
    9a2c:	a9508262 	ldp	x2, x0, [x19, #264]
    9a30:	b4000d82 	cbz	x2, 9be0 <fwp_main_thread+0x390>
    9a34:	f9008840 	str	x0, [x2, #272]
    9a38:	b4000040 	cbz	x0, 9a40 <fwp_main_thread+0x1f0>
    9a3c:	f9008402 	str	x2, [x0, #264]
    9a40:	91080260 	add	x0, x19, #0x200
    9a44:	3901567f 	strb	wzr, [x19, #85]
    9a48:	aa0103f3 	mov	x19, x1
    9a4c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9a50:	f9401680 	ldr	x0, [x20, #40]
    9a54:	b5fffa20 	cbnz	x0, 9998 <fwp_main_thread+0x148>
    9a58:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a5c:	9101c000 	add	x0, x0, #0x70
    9a60:	39014a98 	strb	w24, [x20, #82]
    9a64:	f941a400 	ldr	x0, [x0, #840]
    9a68:	b4000520 	cbz	x0, 9b0c <fwp_main_thread+0x2bc>
    9a6c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a70:	9101c000 	add	x0, x0, #0x70
    9a74:	f941c001 	ldr	x1, [x0, #896]
    9a78:	b903781f 	str	wzr, [x0, #888]
    9a7c:	eb13003f 	cmp	x1, x19
    9a80:	54000641 	b.ne	9b48 <fwp_main_thread+0x2f8>  // b.any
    9a84:	b40059b3 	cbz	x19, a5b8 <fwp_main_thread+0xd68>
    9a88:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a8c:	9101c000 	add	x0, x0, #0x70
    9a90:	52800021 	mov	w1, #0x1                   	// #1
    9a94:	39014a61 	strb	w1, [x19, #82]
    9a98:	f9419005 	ldr	x5, [x0, #800]
    9a9c:	b40058e5 	cbz	x5, a5b8 <fwp_main_thread+0xd68>
    9aa0:	394140a0 	ldrb	w0, [x5, #80]
    9aa4:	37000060 	tbnz	w0, #0, 9ab0 <fwp_main_thread+0x260>
    9aa8:	aa0503e0 	mov	x0, x5
    9aac:	97ffe711 	bl	36f0 <fwp_cancel_tree.part.0>
    9ab0:	f9409ca5 	ldr	x5, [x5, #312]
    9ab4:	b5ffff65 	cbnz	x5, 9aa0 <fwp_main_thread+0x250>
    9ab8:	f00000a0 	adrp	x0, 20000 <__data_start>
    9abc:	9101c014 	add	x20, x0, #0x70
    9ac0:	52800035 	mov	w21, #0x1                   	// #1
    9ac4:	f9402a60 	ldr	x0, [x19, #80]
    9ac8:	f2001c1f 	tst	x0, #0xff000000ff
    9acc:	540000e1 	b.ne	9ae8 <fwp_main_thread+0x298>  // b.any
    9ad0:	f9403e80 	ldr	x0, [x20, #120]
    9ad4:	39015275 	strb	w21, [x19, #84]
    9ad8:	f900827f 	str	xzr, [x19, #256]
    9adc:	b4005640 	cbz	x0, a5a4 <fwp_main_thread+0xd54>
    9ae0:	f9008013 	str	x19, [x0, #256]
    9ae4:	f9003e93 	str	x19, [x20, #120]
    9ae8:	97fff257 	bl	6444 <fwp_block>
    9aec:	97fff1e9 	bl	6290 <fwp_free_zombie>
    9af0:	f9419280 	ldr	x0, [x20, #800]
    9af4:	b4005620 	cbz	x0, a5b8 <fwp_main_thread+0xd68>
    9af8:	f941c293 	ldr	x19, [x20, #896]
    9afc:	17fffff2 	b	9ac4 <fwp_main_thread+0x274>
    9b00:	f941a6a0 	ldr	x0, [x21, #840]
    9b04:	b5005540 	cbnz	x0, a5ac <fwp_main_thread+0xd5c>
    9b08:	d2800013 	mov	x19, #0x0                   	// #0
    9b0c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b10:	9101c014 	add	x20, x0, #0x70
    9b14:	f941ae80 	ldr	x0, [x20, #856]
    9b18:	b5fffaa0 	cbnz	x0, 9a6c <fwp_main_thread+0x21c>
    9b1c:	f941a280 	ldr	x0, [x20, #832]
    9b20:	97ffebe8 	bl	4ac0 <fwp_mem_free>
    9b24:	f901a29f 	str	xzr, [x20, #832]
    9b28:	f901aa9f 	str	xzr, [x20, #848]
    9b2c:	f941c280 	ldr	x0, [x20, #896]
    9b30:	b40098f3 	cbz	x19, ae4c <fwp_main_thread+0x15fc>
    9b34:	f900567f 	str	xzr, [x19, #168]
    9b38:	f9005e7f 	str	xzr, [x19, #184]
    9b3c:	b9037a9f 	str	wzr, [x20, #888]
    9b40:	eb00027f 	cmp	x19, x0
    9b44:	54fffa20 	b.eq	9a88 <fwp_main_thread+0x238>  // b.none
    9b48:	97ffe362 	bl	28d0 <abort@plt>
    9b4c:	97ffe78d 	bl	3980 <fwp_now_ns>
    9b50:	f9403281 	ldr	x1, [x20, #96]
    9b54:	eb01001f 	cmp	x0, x1
    9b58:	540000ab 	b.lt	9b6c <fwp_main_thread+0x31c>  // b.tstop
    9b5c:	39414280 	ldrb	w0, [x20, #80]
    9b60:	37000060 	tbnz	w0, #0, 9b6c <fwp_main_thread+0x31c>
    9b64:	aa1403e0 	mov	x0, x20
    9b68:	97ffe6e2 	bl	36f0 <fwp_cancel_tree.part.0>
    9b6c:	39414680 	ldrb	w0, [x20, #81]
    9b70:	39414a62 	ldrb	w2, [x19, #82]
    9b74:	3707f1c0 	tbnz	w0, #0, 99ac <fwp_main_thread+0x15c>
    9b78:	f9403280 	ldr	x0, [x20, #96]
    9b7c:	370001a2 	tbnz	w2, #0, 9bb0 <fwp_main_thread+0x360>
    9b80:	f9403261 	ldr	x1, [x19, #96]
    9b84:	b4000161 	cbz	x1, 9bb0 <fwp_main_thread+0x360>
    9b88:	b4008ca0 	cbz	x0, ad1c <fwp_main_thread+0x14cc>
    9b8c:	eb01001f 	cmp	x0, x1
    9b90:	9a81d000 	csel	x0, x0, x1, le
    9b94:	f9402281 	ldr	x1, [x20, #64]
    9b98:	a911fe77 	stp	x23, xzr, [x19, #280]
    9b9c:	f9009661 	str	x1, [x19, #296]
    9ba0:	b4000041 	cbz	x1, 9ba8 <fwp_main_thread+0x358>
    9ba4:	f9009033 	str	x19, [x1, #288]
    9ba8:	f9002293 	str	x19, [x20, #64]
    9bac:	17ffff89 	b	99d0 <fwp_main_thread+0x180>
    9bb0:	f9402281 	ldr	x1, [x20, #64]
    9bb4:	17ffff81 	b	99b8 <fwp_main_thread+0x168>
    9bb8:	aa0103f3 	mov	x19, x1
    9bbc:	17ffff75 	b	9990 <fwp_main_thread+0x140>
    9bc0:	a911fe77 	stp	x23, xzr, [x19, #280]
    9bc4:	f9009661 	str	x1, [x19, #296]
    9bc8:	b4000041 	cbz	x1, 9bd0 <fwp_main_thread+0x380>
    9bcc:	f9009033 	str	x19, [x1, #288]
    9bd0:	f9002293 	str	x19, [x20, #64]
    9bd4:	17ffff86 	b	99ec <fwp_main_thread+0x19c>
    9bd8:	f9000040 	str	x0, [x2]
    9bdc:	17ffff8c 	b	9a0c <fwp_main_thread+0x1bc>
    9be0:	f9007ea0 	str	x0, [x21, #248]
    9be4:	17ffff95 	b	9a38 <fwp_main_thread+0x1e8>
    9be8:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9bec:	91058000 	add	x0, x0, #0x160
    9bf0:	9400065c 	bl	b560 <atexit>
    9bf4:	35008d00 	cbnz	w0, ad94 <fwp_main_thread+0x1544>
    9bf8:	52800020 	mov	w0, #0x1                   	// #1
    9bfc:	b9036a60 	str	w0, [x19, #872]
    9c00:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c04:	9101c000 	add	x0, x0, #0x70
    9c08:	b9436c01 	ldr	w1, [x0, #876]
    9c0c:	35ffeb01 	cbnz	w1, 996c <fwp_main_thread+0x11c>
    9c10:	f9419803 	ldr	x3, [x0, #816]
    9c14:	b0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    9c18:	913d4042 	add	x2, x2, #0xf50
    9c1c:	a9308ba3 	stp	x3, x2, [x29, #-248]
    9c20:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    9c24:	90000141 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    9c28:	f9019815 	str	x21, [x0, #816]
    9c2c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c30:	9117c033 	add	x19, x1, #0x5f0
    9c34:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0xa70>
    9c38:	d2800016 	mov	x22, #0x0                   	// #0
    9c3c:	f95f5442 	ldr	x2, [x2, #16040]
    9c40:	d280041b 	mov	x27, #0x20                  	// #32
    9c44:	fd41b028 	ldr	d8, [x1, #864]
    9c48:	d2800014 	mov	x20, #0x0                   	// #0
    9c4c:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0xc0>
    9c50:	52800038 	mov	w24, #0x1                   	// #1
    9c54:	912e0021 	add	x1, x1, #0xb80
    9c58:	f81183a2 	stur	x2, [x29, #-232]
    9c5c:	f81203bf 	stur	xzr, [x29, #-224]
    9c60:	a93307bf 	stp	xzr, x1, [x29, #-208]
    9c64:	f91f7c17 	str	x23, [x0, #16120]
    9c68:	b953a660 	ldr	w0, [x19, #5028]
    9c6c:	f1000779 	subs	x25, x27, #0x1
    9c70:	f81283b9 	stur	x25, [x29, #-216]
    9c74:	da1f029c 	sbc	x28, x20, xzr
    9c78:	aa1903fb 	mov	x27, x25
    9c7c:	aa1c03f4 	mov	x20, x28
    9c80:	34005740 	cbz	w0, a768 <fwp_main_thread+0xf18>
    9c84:	397e8a60 	ldrb	w0, [x19, #4002]
    9c88:	910f0001 	add	x1, x0, #0x3c0
    9c8c:	8b000400 	add	x0, x0, x0, lsl #1
    9c90:	b8617a77 	ldr	w23, [x19, x1, lsl #2]
    9c94:	8b000e61 	add	x1, x19, x0, lsl #3
    9c98:	f8607a75 	ldr	x21, [x19, x0, lsl #3]
    9c9c:	2a1703fa 	mov	w26, w23
    9ca0:	b4005535 	cbz	x21, a744 <fwp_main_thread+0xef4>
    9ca4:	f94002a1 	ldr	x1, [x21]
    9ca8:	aa2103e1 	mvn	x1, x1
    9cac:	f8207a61 	str	x1, [x19, x0, lsl #3]
    9cb0:	f100635f 	cmp	x26, #0x18
    9cb4:	540000e9 	b.ls	9cd0 <fwp_main_thread+0x480>  // b.plast
    9cb8:	d1006742 	sub	x2, x26, #0x19
    9cbc:	910062a0 	add	x0, x21, #0x18
    9cc0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9cc4:	52800001 	mov	w1, #0x0                   	// #0
    9cc8:	91002042 	add	x2, x2, #0x8
    9ccc:	97ffe2e1 	bl	2850 <memset@plt>
    9cd0:	f94a1260 	ldr	x0, [x19, #5152]
    9cd4:	ab1a0000 	adds	x0, x0, x26
    9cd8:	54008562 	b.cs	ad84 <fwp_main_thread+0x1534>  // b.hs, b.nlast
    9cdc:	f94a1661 	ldr	x1, [x19, #5160]
    9ce0:	f90a1260 	str	x0, [x19, #5152]
    9ce4:	eb01001f 	cmp	x0, x1
    9ce8:	54000049 	b.ls	9cf0 <fwp_main_thread+0x4a0>  // b.plast
    9cec:	f90a1660 	str	x0, [x19, #5160]
    9cf0:	1e6302e1 	ucvtf	d1, w23
    9cf4:	fd4a1e60 	ldr	d0, [x19, #5176]
    9cf8:	1e612800 	fadd	d0, d0, d1
    9cfc:	fd0a1e60 	str	d0, [x19, #5176]
    9d00:	a900dab9 	stp	x25, x22, [x21, #8]
    9d04:	aa1503f6 	mov	x22, x21
    9d08:	fd0002a8 	str	d8, [x21]
    9d0c:	f949da62 	ldr	x2, [x19, #5040]
    9d10:	f949ee60 	ldr	x0, [x19, #5080]
    9d14:	cb0202a2 	sub	x2, x21, x2
    9d18:	eb00405f 	cmp	x2, x0, lsl #16
    9d1c:	54000302 	b.cs	9d7c <fwp_main_thread+0x52c>  // b.hs, b.nlast
    9d20:	d350fc40 	lsr	x0, x2, #16
    9d24:	f949fe63 	ldr	x3, [x19, #5112]
    9d28:	8b000800 	add	x0, x0, x0, lsl #2
    9d2c:	d37df001 	lsl	x1, x0, #3
    9d30:	8b010060 	add	x0, x3, x1
    9d34:	f940101a 	ldr	x26, [x0, #32]
    9d38:	b400023a 	cbz	x26, 9d7c <fwp_main_thread+0x52c>
    9d3c:	38616861 	ldrb	w1, [x3, x1]
    9d40:	7100083f 	cmp	w1, #0x2
    9d44:	540051c0 	b.eq	a77c <fwp_main_thread+0xf2c>  // b.none
    9d48:	7100043f 	cmp	w1, #0x1
    9d4c:	54000181 	b.ne	9d7c <fwp_main_thread+0x52c>  // b.any
    9d50:	29430003 	ldp	w3, w0, [x0, #24]
    9d54:	92403c41 	and	x1, x2, #0xffff
    9d58:	9b037c21 	mul	x1, x1, x3
    9d5c:	d360fc21 	lsr	x1, x1, #32
    9d60:	eb00003f 	cmp	x1, x0
    9d64:	540000c2 	b.cs	9d7c <fwp_main_thread+0x52c>  // b.hs, b.nlast
    9d68:	8b01035a 	add	x26, x26, x1
    9d6c:	39400340 	ldrb	w0, [x26]
    9d70:	7103fc1f 	cmp	w0, #0xff
    9d74:	540050e0 	b.eq	a790 <fwp_main_thread+0xf40>  // b.none
    9d78:	39000358 	strb	w24, [x26]
    9d7c:	f81203b5 	stur	x21, [x29, #-224]
    9d80:	aa1c0339 	orr	x25, x25, x28
    9d84:	b5fff739 	cbnz	x25, 9c68 <fwp_main_thread+0x418>
    9d88:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d8c:	d10303a1 	sub	x1, x29, #0xc0
    9d90:	f85083a3 	ldur	x3, [x29, #-248]
    9d94:	f95f7c17 	ldr	x23, [x0, #16120]
    9d98:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0xa70>
    9d9c:	3dc0dc00 	ldr	q0, [x0, #880]
    9da0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9da4:	9101c002 	add	x2, x0, #0x70
    9da8:	52800020 	mov	w0, #0x1                   	// #1
    9dac:	3c9403a0 	stur	q0, [x29, #-192]
    9db0:	f9019843 	str	x3, [x2, #816]
    9db4:	97ffee63 	bl	5740 <fwp_data.part.0.constprop.0>
    9db8:	90000141 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    9dbc:	9117c022 	add	x2, x1, #0x5f0
    9dc0:	aa0003f4 	mov	x20, x0
    9dc4:	f949d841 	ldr	x1, [x2, #5040]
    9dc8:	f949ec40 	ldr	x0, [x2, #5080]
    9dcc:	cb010281 	sub	x1, x20, x1
    9dd0:	eb00403f 	cmp	x1, x0, lsl #16
    9dd4:	54000322 	b.cs	9e38 <fwp_main_thread+0x5e8>  // b.hs, b.nlast
    9dd8:	d350fc20 	lsr	x0, x1, #16
    9ddc:	f949fc43 	ldr	x3, [x2, #5112]
    9de0:	8b000800 	add	x0, x0, x0, lsl #2
    9de4:	d37df002 	lsl	x2, x0, #3
    9de8:	8b020060 	add	x0, x3, x2
    9dec:	f9401013 	ldr	x19, [x0, #32]
    9df0:	b4000253 	cbz	x19, 9e38 <fwp_main_thread+0x5e8>
    9df4:	38626862 	ldrb	w2, [x3, x2]
    9df8:	7100085f 	cmp	w2, #0x2
    9dfc:	54007780 	b.eq	acec <fwp_main_thread+0x149c>  // b.none
    9e00:	7100045f 	cmp	w2, #0x1
    9e04:	540001a1 	b.ne	9e38 <fwp_main_thread+0x5e8>  // b.any
    9e08:	29430002 	ldp	w2, w0, [x0, #24]
    9e0c:	92403c21 	and	x1, x1, #0xffff
    9e10:	9b027c21 	mul	x1, x1, x2
    9e14:	d360fc21 	lsr	x1, x1, #32
    9e18:	eb00003f 	cmp	x1, x0
    9e1c:	540000e2 	b.cs	9e38 <fwp_main_thread+0x5e8>  // b.hs, b.nlast
    9e20:	8b010273 	add	x19, x19, x1
    9e24:	39400260 	ldrb	w0, [x19]
    9e28:	7103fc1f 	cmp	w0, #0xff
    9e2c:	54007940 	b.eq	ad54 <fwp_main_thread+0x1504>  // b.none
    9e30:	52800020 	mov	w0, #0x1                   	// #1
    9e34:	39000260 	strb	w0, [x19]
    9e38:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9e3c:	aa1703e1 	mov	x1, x23
    9e40:	52800020 	mov	w0, #0x1                   	// #1
    9e44:	a93653a2 	stp	x2, x20, [x29, #-160]
    9e48:	97ffee3e 	bl	5740 <fwp_data.part.0.constprop.0>
    9e4c:	90000141 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    9e50:	9117c022 	add	x2, x1, #0x5f0
    9e54:	aa0003f4 	mov	x20, x0
    9e58:	f949d841 	ldr	x1, [x2, #5040]
    9e5c:	f949ec40 	ldr	x0, [x2, #5080]
    9e60:	cb010281 	sub	x1, x20, x1
    9e64:	eb00403f 	cmp	x1, x0, lsl #16
    9e68:	54000322 	b.cs	9ecc <fwp_main_thread+0x67c>  // b.hs, b.nlast
    9e6c:	d350fc20 	lsr	x0, x1, #16
    9e70:	f949fc43 	ldr	x3, [x2, #5112]
    9e74:	8b000800 	add	x0, x0, x0, lsl #2
    9e78:	d37df002 	lsl	x2, x0, #3
    9e7c:	8b020060 	add	x0, x3, x2
    9e80:	f9401013 	ldr	x19, [x0, #32]
    9e84:	b4000253 	cbz	x19, 9ecc <fwp_main_thread+0x67c>
    9e88:	38626862 	ldrb	w2, [x3, x2]
    9e8c:	7100085f 	cmp	w2, #0x2
    9e90:	540073a0 	b.eq	ad04 <fwp_main_thread+0x14b4>  // b.none
    9e94:	7100045f 	cmp	w2, #0x1
    9e98:	540001a1 	b.ne	9ecc <fwp_main_thread+0x67c>  // b.any
    9e9c:	29430002 	ldp	w2, w0, [x0, #24]
    9ea0:	92403c21 	and	x1, x1, #0xffff
    9ea4:	9b027c21 	mul	x1, x1, x2
    9ea8:	d360fc21 	lsr	x1, x1, #32
    9eac:	eb00003f 	cmp	x1, x0
    9eb0:	540000e2 	b.cs	9ecc <fwp_main_thread+0x67c>  // b.hs, b.nlast
    9eb4:	8b010273 	add	x19, x19, x1
    9eb8:	39400260 	ldrb	w0, [x19]
    9ebc:	7103fc1f 	cmp	w0, #0xff
    9ec0:	54007540 	b.eq	ad68 <fwp_main_thread+0x1518>  // b.none
    9ec4:	52800020 	mov	w0, #0x1                   	// #1
    9ec8:	39000260 	strb	w0, [x19]
    9ecc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9ed0:	d102c3a1 	sub	x1, x29, #0xb0
    9ed4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9ed8:	52800020 	mov	w0, #0x1                   	// #1
    9edc:	a93553a2 	stp	x2, x20, [x29, #-176]
    9ee0:	97ffee18 	bl	5740 <fwp_data.part.0.constprop.0>
    9ee4:	90000141 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    9ee8:	9117c023 	add	x3, x1, #0x5f0
    9eec:	aa0003f4 	mov	x20, x0
    9ef0:	f949ec62 	ldr	x2, [x3, #5080]
    9ef4:	f949d861 	ldr	x1, [x3, #5040]
    9ef8:	d370bc42 	lsl	x2, x2, #16
    9efc:	cb010001 	sub	x1, x0, x1
    9f00:	eb02003f 	cmp	x1, x2
    9f04:	540003e2 	b.cs	9f80 <fwp_main_thread+0x730>  // b.hs, b.nlast
    9f08:	d350fc20 	lsr	x0, x1, #16
    9f0c:	f949fc64 	ldr	x4, [x3, #5112]
    9f10:	8b000800 	add	x0, x0, x0, lsl #2
    9f14:	d37df003 	lsl	x3, x0, #3
    9f18:	8b030080 	add	x0, x4, x3
    9f1c:	f9401013 	ldr	x19, [x0, #32]
    9f20:	b4000313 	cbz	x19, 9f80 <fwp_main_thread+0x730>
    9f24:	38636883 	ldrb	w3, [x4, x3]
    9f28:	7100087f 	cmp	w3, #0x2
    9f2c:	54006e60 	b.eq	acf8 <fwp_main_thread+0x14a8>  // b.none
    9f30:	7100047f 	cmp	w3, #0x1
    9f34:	54000261 	b.ne	9f80 <fwp_main_thread+0x730>  // b.any
    9f38:	29430004 	ldp	w4, w0, [x0, #24]
    9f3c:	92403c23 	and	x3, x1, #0xffff
    9f40:	9b047c63 	mul	x3, x3, x4
    9f44:	d360fc63 	lsr	x3, x3, #32
    9f48:	eb00007f 	cmp	x3, x0
    9f4c:	540001a2 	b.cs	9f80 <fwp_main_thread+0x730>  // b.hs, b.nlast
    9f50:	8b030273 	add	x19, x19, x3
    9f54:	39400260 	ldrb	w0, [x19]
    9f58:	7103fc1f 	cmp	w0, #0xff
    9f5c:	540070c0 	b.eq	ad74 <fwp_main_thread+0x1524>  // b.none
    9f60:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9f64:	9117c000 	add	x0, x0, #0x5f0
    9f68:	52800021 	mov	w1, #0x1                   	// #1
    9f6c:	39000261 	strb	w1, [x19]
    9f70:	f949ec02 	ldr	x2, [x0, #5080]
    9f74:	f949d801 	ldr	x1, [x0, #5040]
    9f78:	d370bc42 	lsl	x2, x2, #16
    9f7c:	cb010281 	sub	x1, x20, x1
    9f80:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f84:	9101c018 	add	x24, x0, #0x70
    9f88:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9f8c:	f00000bc 	adrp	x28, 20000 <__data_start>
    9f90:	9100439b 	add	x27, x28, #0x10
    9f94:	d10403b6 	sub	x22, x29, #0x100
    9f98:	91010367 	add	x7, x27, #0x40
    9f9c:	aa1503f7 	mov	x23, x21
    9fa0:	aa1503fb 	mov	x27, x21
    9fa4:	f91f5007 	str	x7, [x0, #16032]
    9fa8:	f91f581c 	str	x28, [x0, #16048]
    9fac:	eb02003f 	cmp	x1, x2
    9fb0:	54000382 	b.cs	a020 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    9fb4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9fb8:	9117c002 	add	x2, x0, #0x5f0
    9fbc:	d350fc20 	lsr	x0, x1, #16
    9fc0:	f949fc44 	ldr	x4, [x2, #5112]
    9fc4:	8b000800 	add	x0, x0, x0, lsl #2
    9fc8:	d37df002 	lsl	x2, x0, #3
    9fcc:	8b020083 	add	x3, x4, x2
    9fd0:	f9401060 	ldr	x0, [x3, #32]
    9fd4:	b4000260 	cbz	x0, a020 <fwp_main_thread+0x7d0>
    9fd8:	38626882 	ldrb	w2, [x4, x2]
    9fdc:	7100085f 	cmp	w2, #0x2
    9fe0:	54006980 	b.eq	ad10 <fwp_main_thread+0x14c0>  // b.none
    9fe4:	7100045f 	cmp	w2, #0x1
    9fe8:	540001c1 	b.ne	a020 <fwp_main_thread+0x7d0>  // b.any
    9fec:	29430864 	ldp	w4, w2, [x3, #24]
    9ff0:	92403c21 	and	x1, x1, #0xffff
    9ff4:	9b047c21 	mul	x1, x1, x4
    9ff8:	d360fc21 	lsr	x1, x1, #32
    9ffc:	eb02003f 	cmp	x1, x2
    a000:	54000102 	b.cs	a020 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    a004:	8b010000 	add	x0, x0, x1
    a008:	39400001 	ldrb	w1, [x0]
    a00c:	340000a1 	cbz	w1, a020 <fwp_main_thread+0x7d0>
    a010:	7103f43f 	cmp	w1, #0xfd
    a014:	54006a68 	b.hi	ad60 <fwp_main_thread+0x1510>  // b.pmore
    a018:	11000421 	add	w1, w1, #0x1
    a01c:	39000001 	strb	w1, [x0]
    a020:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a024:	d28018f3 	mov	x19, #0xc7                  	// #199
    a028:	f95f5004 	ldr	x4, [x0, #16032]
    a02c:	f91f4417 	str	x23, [x0, #16008]
    a030:	aa1403f7 	mov	x23, x20
    a034:	f91f481b 	str	x27, [x0, #16016]
    a038:	f91f4c14 	str	x20, [x0, #16024]
    a03c:	f91f5c13 	str	x19, [x0, #16056]
    a040:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a044:	f81003b7 	stur	x23, [x29, #-256]
    a048:	f9404705 	ldr	x5, [x24, #136]
    a04c:	f95f5800 	ldr	x0, [x0, #16048]
    a050:	91004000 	add	x0, x0, #0x10
    a054:	91010006 	add	x6, x0, #0x40
    a058:	b9404002 	ldr	w2, [x0, #64]
    a05c:	d37be842 	lsl	x2, x2, #5
    a060:	8b0200bc 	add	x28, x5, x2
    a064:	f9400f81 	ldr	x1, [x28, #24]
    a068:	b40065e1 	cbz	x1, ad24 <fwp_main_thread+0x14d4>
    a06c:	f9400c20 	ldr	x0, [x1, #24]
    a070:	b4005640 	cbz	x0, ab38 <fwp_main_thread+0x12e8>
    a074:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a078:	9117c002 	add	x2, x0, #0x5f0
    a07c:	f949d841 	ldr	x1, [x2, #5040]
    a080:	f949ec40 	ldr	x0, [x2, #5080]
    a084:	cb010081 	sub	x1, x4, x1
    a088:	eb00403f 	cmp	x1, x0, lsl #16
    a08c:	54000342 	b.cs	a0f4 <fwp_main_thread+0x8a4>  // b.hs, b.nlast
    a090:	d350fc20 	lsr	x0, x1, #16
    a094:	f949fc45 	ldr	x5, [x2, #5112]
    a098:	8b000800 	add	x0, x0, x0, lsl #2
    a09c:	d37df002 	lsl	x2, x0, #3
    a0a0:	8b0200a3 	add	x3, x5, x2
    a0a4:	f9401060 	ldr	x0, [x3, #32]
    a0a8:	b4000260 	cbz	x0, a0f4 <fwp_main_thread+0x8a4>
    a0ac:	386268a2 	ldrb	w2, [x5, x2]
    a0b0:	7100085f 	cmp	w2, #0x2
    a0b4:	54005b20 	b.eq	ac18 <fwp_main_thread+0x13c8>  // b.none
    a0b8:	7100045f 	cmp	w2, #0x1
    a0bc:	540001c1 	b.ne	a0f4 <fwp_main_thread+0x8a4>  // b.any
    a0c0:	29430865 	ldp	w5, w2, [x3, #24]
    a0c4:	92403c21 	and	x1, x1, #0xffff
    a0c8:	9b057c21 	mul	x1, x1, x5
    a0cc:	d360fc21 	lsr	x1, x1, #32
    a0d0:	eb02003f 	cmp	x1, x2
    a0d4:	54000102 	b.cs	a0f4 <fwp_main_thread+0x8a4>  // b.hs, b.nlast
    a0d8:	8b010000 	add	x0, x0, x1
    a0dc:	39400001 	ldrb	w1, [x0]
    a0e0:	340000a1 	cbz	w1, a0f4 <fwp_main_thread+0x8a4>
    a0e4:	7103f43f 	cmp	w1, #0xfd
    a0e8:	54005e28 	b.hi	acac <fwp_main_thread+0x145c>  // b.pmore
    a0ec:	11000421 	add	w1, w1, #0x1
    a0f0:	39000001 	strb	w1, [x0]
    a0f4:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    a0f8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a0fc:	9117c035 	add	x21, x1, #0x5f0
    a100:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a104:	aa0403f7 	mov	x23, x4
    a108:	52800034 	mov	w20, #0x1                   	// #1
    a10c:	f91f7816 	str	x22, [x0, #16112]
    a110:	aa0403e0 	mov	x0, x4
    a114:	f91f6424 	str	x4, [x1, #16072]
    a118:	aa1c03e4 	mov	x4, x28
    a11c:	f91f6036 	str	x22, [x1, #16064]
    a120:	b93ee834 	str	w20, [x1, #16104]
    a124:	b93eec34 	str	w20, [x1, #16108]
    a128:	b9400401 	ldr	w1, [x0, #4]
    a12c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a130:	b9400096 	ldr	w22, [x4]
    a134:	b97eec00 	ldr	w0, [x0, #16108]
    a138:	4b0102d6 	sub	w22, w22, w1
    a13c:	6b0002df 	cmp	w22, w0
    a140:	1a8092dc 	csel	w28, w22, w0, ls	// ls = plast
    a144:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a148:	b97ee800 	ldr	w0, [x0, #16104]
    a14c:	6b00039f 	cmp	w28, w0
    a150:	1a80939b 	csel	w27, w28, w0, ls	// ls = plast
    a154:	6b1b0382 	subs	w2, w28, w27
    a158:	54000100 	b.eq	a178 <fwp_main_thread+0x928>  // b.none
    a15c:	f9400c84 	ldr	x4, [x4, #24]
    a160:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a164:	0b1b0021 	add	w1, w1, w27
    a168:	f9400884 	ldr	x4, [x4, #16]
    a16c:	f95f7800 	ldr	x0, [x0, #16112]
    a170:	8b3b4c00 	add	x0, x0, w27, uxtw #3
    a174:	d63f0080 	blr	x4
    a178:	f9404700 	ldr	x0, [x24, #136]
    a17c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a180:	b94002e4 	ldr	w4, [x23]
    a184:	aa1703e7 	mov	x7, x23
    a188:	2a1c03f9 	mov	w25, w28
    a18c:	aa1703e9 	mov	x9, x23
    a190:	f95f783a 	ldr	x26, [x1, #16112]
    a194:	8b041404 	add	x4, x0, x4, lsl #5
    a198:	f9400c88 	ldr	x8, [x4, #24]
    a19c:	b4003148 	cbz	x8, a7c4 <fwp_main_thread+0xf74>
    a1a0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1a4:	aa0403f4 	mov	x20, x4
    a1a8:	b93ed41b 	str	w27, [x0, #16084]
    a1ac:	b93ed81c 	str	w28, [x0, #16088]
    a1b0:	b93ee016 	str	w22, [x0, #16096]
    a1b4:	14000012 	b	a1fc <fwp_main_thread+0x9ac>
    a1b8:	f9400101 	ldr	x1, [x8]
    a1bc:	aa1a03e0 	mov	x0, x26
    a1c0:	d63f0020 	blr	x1
    a1c4:	aa0003fc 	mov	x28, x0
    a1c8:	aa1703e0 	mov	x0, x23
    a1cc:	97ffeec1 	bl	5cd0 <fwp_closure_drop>
    a1d0:	6b1902df 	cmp	w22, w25
    a1d4:	54000d00 	b.eq	a374 <fwp_main_thread+0xb24>  // b.none
    a1d8:	f9404700 	ldr	x0, [x24, #136]
    a1dc:	8b364f5a 	add	x26, x26, w22, uxtw #3
    a1e0:	b9400384 	ldr	w4, [x28]
    a1e4:	4b130379 	sub	w25, w27, w19
    a1e8:	aa1c03e7 	mov	x7, x28
    a1ec:	8b041414 	add	x20, x0, x4, lsl #5
    a1f0:	f9400e88 	ldr	x8, [x20, #24]
    a1f4:	b4002de8 	cbz	x8, a7b0 <fwp_main_thread+0xf60>
    a1f8:	aa1c03f7 	mov	x23, x28
    a1fc:	b94004e9 	ldr	w9, [x7, #4]
    a200:	b9400293 	ldr	w19, [x20]
    a204:	0b19013b 	add	w27, w9, w25
    a208:	6b1b027f 	cmp	w19, w27
    a20c:	54003768 	b.hi	a8f8 <fwp_main_thread+0x10a8>  // b.pmore
    a210:	7100013f 	cmp	w9, #0x0
    a214:	4b090276 	sub	w22, w19, w9
    a218:	7a400a64 	ccmp	w19, #0x0, #0x4, eq	// eq = none
    a21c:	54fffce1 	b.ne	a1b8 <fwp_main_thread+0x968>  // b.any
    a220:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a224:	910003e0 	mov	x0, sp
    a228:	7100027f 	cmp	w19, #0x0
    a22c:	f91f7c20 	str	x0, [x1, #16120]
    a230:	1a9f1660 	csinc	w0, w19, wzr, ne	// ne = any
    a234:	d37df000 	lsl	x0, x0, #3
    a238:	91003c00 	add	x0, x0, #0xf
    a23c:	92704c01 	and	x1, x0, #0xfffff0000
    a240:	927c7c00 	and	x0, x0, #0xffffffff0
    a244:	cb2163e1 	sub	x1, sp, x1
    a248:	eb2163ff 	cmp	sp, x1
    a24c:	540000a0 	b.eq	a260 <fwp_main_thread+0xa10>  // b.none
    a250:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a254:	f90203ff 	str	xzr, [sp, #1024]
    a258:	eb2163ff 	cmp	sp, x1
    a25c:	54ffffa1 	b.ne	a250 <fwp_main_thread+0xa00>  // b.any
    a260:	92403c00 	and	x0, x0, #0xffff
    a264:	cb2063ff 	sub	sp, sp, x0
    a268:	f90003ff 	str	xzr, [sp]
    a26c:	f110001f 	cmp	x0, #0x400
    a270:	54000043 	b.cc	a278 <fwp_main_thread+0xa28>  // b.lo, b.ul, b.last
    a274:	f90203ff 	str	xzr, [sp, #1024]
    a278:	910043fc 	add	x28, sp, #0x10
    a27c:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a280:	910020e1 	add	x1, x7, #0x8
    a284:	d2800000 	mov	x0, #0x0                   	// #0
    a288:	340000e9 	cbz	w9, a2a4 <fwp_main_thread+0xa54>
    a28c:	d503201f 	nop
    a290:	f8606823 	ldr	x3, [x1, x0]
    a294:	f8206b83 	str	x3, [x28, x0]
    a298:	91002000 	add	x0, x0, #0x8
    a29c:	eb02001f 	cmp	x0, x2
    a2a0:	54ffff81 	b.ne	a290 <fwp_main_thread+0xa40>  // b.any
    a2a4:	2a1603e1 	mov	w1, w22
    a2a8:	d2800000 	mov	x0, #0x0                   	// #0
    a2ac:	340000f6 	cbz	w22, a2c8 <fwp_main_thread+0xa78>
    a2b0:	0b000122 	add	w2, w9, w0
    a2b4:	f8607b43 	ldr	x3, [x26, x0, lsl #3]
    a2b8:	91000400 	add	x0, x0, #0x1
    a2bc:	f8227b83 	str	x3, [x28, x2, lsl #3]
    a2c0:	eb01001f 	cmp	x0, x1
    a2c4:	54ffff61 	b.ne	a2b0 <fwp_main_thread+0xa60>  // b.any
    a2c8:	f949daa0 	ldr	x0, [x21, #5040]
    a2cc:	f949eea1 	ldr	x1, [x21, #5080]
    a2d0:	cb0002e0 	sub	x0, x23, x0
    a2d4:	eb01401f 	cmp	x0, x1, lsl #16
    a2d8:	540002e2 	b.cs	a334 <fwp_main_thread+0xae4>  // b.hs, b.nlast
    a2dc:	d350fc01 	lsr	x1, x0, #16
    a2e0:	f949fea5 	ldr	x5, [x21, #5112]
    a2e4:	8b010821 	add	x1, x1, x1, lsl #2
    a2e8:	d37df021 	lsl	x1, x1, #3
    a2ec:	8b0100a3 	add	x3, x5, x1
    a2f0:	f9401062 	ldr	x2, [x3, #32]
    a2f4:	b4000202 	cbz	x2, a334 <fwp_main_thread+0xae4>
    a2f8:	386168a1 	ldrb	w1, [x5, x1]
    a2fc:	7100083f 	cmp	w1, #0x2
    a300:	54002520 	b.eq	a7a4 <fwp_main_thread+0xf54>  // b.none
    a304:	7100043f 	cmp	w1, #0x1
    a308:	54000161 	b.ne	a334 <fwp_main_thread+0xae4>  // b.any
    a30c:	29430465 	ldp	w5, w1, [x3, #24]
    a310:	92403c00 	and	x0, x0, #0xffff
    a314:	9b057c00 	mul	x0, x0, x5
    a318:	d360fc00 	lsr	x0, x0, #32
    a31c:	eb01001f 	cmp	x0, x1
    a320:	540000a2 	b.cs	a334 <fwp_main_thread+0xae4>  // b.hs, b.nlast
    a324:	8b000042 	add	x2, x2, x0
    a328:	39400040 	ldrb	w0, [x2]
    a32c:	7100041f 	cmp	w0, #0x1
    a330:	54002360 	b.eq	a79c <fwp_main_thread+0xf4c>  // b.none
    a334:	f9400502 	ldr	x2, [x8, #8]
    a338:	aa1703e0 	mov	x0, x23
    a33c:	52800021 	mov	w1, #0x1                   	// #1
    a340:	d63f0040 	blr	x2
    a344:	f9400e81 	ldr	x1, [x20, #24]
    a348:	aa1c03e0 	mov	x0, x28
    a34c:	f9400021 	ldr	x1, [x1]
    a350:	d63f0020 	blr	x1
    a354:	aa0003fc 	mov	x28, x0
    a358:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a35c:	f95f7c00 	ldr	x0, [x0, #16120]
    a360:	9100001f 	mov	sp, x0
    a364:	aa1703e0 	mov	x0, x23
    a368:	97ffee5a 	bl	5cd0 <fwp_closure_drop>
    a36c:	6b1902df 	cmp	w22, w25
    a370:	54fff341 	b.ne	a1d8 <fwp_main_thread+0x988>  // b.any
    a374:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a378:	aa1c03f7 	mov	x23, x28
    a37c:	b97ed41b 	ldr	w27, [x0, #16084]
    a380:	b97ed81c 	ldr	w28, [x0, #16088]
    a384:	b97ee016 	ldr	w22, [x0, #16096]
    a388:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a38c:	b97eec00 	ldr	w0, [x0, #16108]
    a390:	6b0002df 	cmp	w22, w0
    a394:	540024a3 	b.cc	a828 <fwp_main_thread+0xfd8>  // b.lo, b.ul, b.last
    a398:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a39c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a3a0:	f95f6016 	ldr	x22, [x0, #16064]
    a3a4:	f95f6404 	ldr	x4, [x0, #16072]
    a3a8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3ac:	f95f5c00 	ldr	x0, [x0, #16056]
    a3b0:	f1000400 	subs	x0, x0, #0x1
    a3b4:	f91f5c20 	str	x0, [x1, #16056]
    a3b8:	54ffe441 	b.ne	a040 <fwp_main_thread+0x7f0>  // b.any
    a3bc:	aa0103e0 	mov	x0, x1
    a3c0:	aa1703fc 	mov	x28, x23
    a3c4:	aa1703e1 	mov	x1, x23
    a3c8:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10840>
    a3cc:	91102042 	add	x2, x2, #0x408
    a3d0:	52800023 	mov	w3, #0x1                   	// #1
    a3d4:	f95f4417 	ldr	x23, [x0, #16008]
    a3d8:	91014042 	add	x2, x2, #0x50
    a3dc:	f95f481b 	ldr	x27, [x0, #16016]
    a3e0:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a3e4:	f95f4c14 	ldr	x20, [x0, #16024]
    a3e8:	f81303bf 	stur	xzr, [x29, #-208]
    a3ec:	f95f5400 	ldr	x0, [x0, #16040]
    a3f0:	97fff91c 	bl	8860 <fwp_write>
    a3f4:	a97267b5 	ldp	x21, x25, [x29, #-224]
    a3f8:	d0000000 	adrp	x0, c000 <_IO_stdin_used+0xa70>
    a3fc:	9102a000 	add	x0, x0, #0xa8
    a400:	f10002bf 	cmp	x21, #0x0
    a404:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    a408:	b1002b3f 	cmn	x25, #0xa
    a40c:	54004c68 	b.hi	ad98 <fwp_main_thread+0x1548>  // b.pmore
    a410:	91002720 	add	x0, x25, #0x9
    a414:	52800021 	mov	w1, #0x1                   	// #1
    a418:	97ffeaca 	bl	4f40 <fwp_heap_alloc>
    a41c:	aa0003f3 	mov	x19, x0
    a420:	aa1503e1 	mov	x1, x21
    a424:	aa0003f5 	mov	x21, x0
    a428:	aa1903e2 	mov	x2, x25
    a42c:	f80086b9 	str	x25, [x21], #8
    a430:	8b190279 	add	x25, x19, x25
    a434:	aa1503e0 	mov	x0, x21
    a438:	97ffe0a6 	bl	26d0 <memcpy@plt>
    a43c:	3900233f 	strb	wzr, [x25, #8]
    a440:	f85203a0 	ldur	x0, [x29, #-224]
    a444:	97ffe13f 	bl	2940 <free@plt>
    a448:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a44c:	9117c002 	add	x2, x0, #0x5f0
    a450:	f949d841 	ldr	x1, [x2, #5040]
    a454:	f949ec40 	ldr	x0, [x2, #5080]
    a458:	cb010261 	sub	x1, x19, x1
    a45c:	eb00403f 	cmp	x1, x0, lsl #16
    a460:	54000322 	b.cs	a4c4 <fwp_main_thread+0xc74>  // b.hs, b.nlast
    a464:	d350fc20 	lsr	x0, x1, #16
    a468:	f949fc43 	ldr	x3, [x2, #5112]
    a46c:	8b000800 	add	x0, x0, x0, lsl #2
    a470:	d37df002 	lsl	x2, x0, #3
    a474:	8b020060 	add	x0, x3, x2
    a478:	f9401019 	ldr	x25, [x0, #32]
    a47c:	b4000259 	cbz	x25, a4c4 <fwp_main_thread+0xc74>
    a480:	38626862 	ldrb	w2, [x3, x2]
    a484:	7100085f 	cmp	w2, #0x2
    a488:	54004a80 	b.eq	add8 <fwp_main_thread+0x1588>  // b.none
    a48c:	7100045f 	cmp	w2, #0x1
    a490:	540001a1 	b.ne	a4c4 <fwp_main_thread+0xc74>  // b.any
    a494:	29430002 	ldp	w2, w0, [x0, #24]
    a498:	92403c21 	and	x1, x1, #0xffff
    a49c:	9b027c21 	mul	x1, x1, x2
    a4a0:	d360fc21 	lsr	x1, x1, #32
    a4a4:	eb00003f 	cmp	x1, x0
    a4a8:	540000e2 	b.cs	a4c4 <fwp_main_thread+0xc74>  // b.hs, b.nlast
    a4ac:	8b010339 	add	x25, x25, x1
    a4b0:	39400320 	ldrb	w0, [x25]
    a4b4:	7103fc1f 	cmp	w0, #0xff
    a4b8:	54004d00 	b.eq	ae58 <fwp_main_thread+0x1608>  // b.none
    a4bc:	52800020 	mov	w0, #0x1                   	// #1
    a4c0:	39000320 	strb	w0, [x25]
    a4c4:	aa1c03e0 	mov	x0, x28
    a4c8:	97ffed53 	bl	5a14 <fwp_drop0>
    a4cc:	d00000a0 	adrp	x0, 20000 <__data_start>
    a4d0:	9101c003 	add	x3, x0, #0x70
    a4d4:	f9400262 	ldr	x2, [x19]
    a4d8:	aa1503e0 	mov	x0, x21
    a4dc:	aa0303f5 	mov	x21, x3
    a4e0:	d2800021 	mov	x1, #0x1                   	// #1
    a4e4:	f9400463 	ldr	x3, [x3, #8]
    a4e8:	97ffe126 	bl	2980 <fwrite@plt>
    a4ec:	f94006a1 	ldr	x1, [x21, #8]
    a4f0:	52800140 	mov	w0, #0xa                   	// #10
    a4f4:	97ffe0ab 	bl	27a0 <fputc@plt>
    a4f8:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a4fc:	9117c002 	add	x2, x0, #0x5f0
    a500:	f949d841 	ldr	x1, [x2, #5040]
    a504:	f949ec40 	ldr	x0, [x2, #5080]
    a508:	cb010261 	sub	x1, x19, x1
    a50c:	eb00403f 	cmp	x1, x0, lsl #16
    a510:	54000382 	b.cs	a580 <fwp_main_thread+0xd30>  // b.hs, b.nlast
    a514:	d350fc20 	lsr	x0, x1, #16
    a518:	f949fc43 	ldr	x3, [x2, #5112]
    a51c:	8b000800 	add	x0, x0, x0, lsl #2
    a520:	d37df000 	lsl	x0, x0, #3
    a524:	8b000062 	add	x2, x3, x0
    a528:	f9401055 	ldr	x21, [x2, #32]
    a52c:	b40002b5 	cbz	x21, a580 <fwp_main_thread+0xd30>
    a530:	38606860 	ldrb	w0, [x3, x0]
    a534:	7100081f 	cmp	w0, #0x2
    a538:	540044a0 	b.eq	adcc <fwp_main_thread+0x157c>  // b.none
    a53c:	7100041f 	cmp	w0, #0x1
    a540:	54000201 	b.ne	a580 <fwp_main_thread+0xd30>  // b.any
    a544:	29430043 	ldp	w3, w0, [x2, #24]
    a548:	92403c21 	and	x1, x1, #0xffff
    a54c:	9b037c21 	mul	x1, x1, x3
    a550:	d360fc21 	lsr	x1, x1, #32
    a554:	eb00003f 	cmp	x1, x0
    a558:	54000142 	b.cs	a580 <fwp_main_thread+0xd30>  // b.hs, b.nlast
    a55c:	8b0102b5 	add	x21, x21, x1
    a560:	394002a0 	ldrb	w0, [x21]
    a564:	340000e0 	cbz	w0, a580 <fwp_main_thread+0xd30>
    a568:	7100041f 	cmp	w0, #0x1
    a56c:	540046a0 	b.eq	ae40 <fwp_main_thread+0x15f0>  // b.none
    a570:	7103fc1f 	cmp	w0, #0xff
    a574:	54004380 	b.eq	ade4 <fwp_main_thread+0x1594>  // b.none
    a578:	51000400 	sub	w0, w0, #0x1
    a57c:	390002a0 	strb	w0, [x21]
    a580:	f9400b7b 	ldr	x27, [x27, #16]
    a584:	b400411b 	cbz	x27, ada4 <fwp_main_thread+0x1554>
    a588:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a58c:	9117c000 	add	x0, x0, #0x5f0
    a590:	f949ec02 	ldr	x2, [x0, #5080]
    a594:	f949d801 	ldr	x1, [x0, #5040]
    a598:	d370bc42 	lsl	x2, x2, #16
    a59c:	cb010281 	sub	x1, x20, x1
    a5a0:	17fffe83 	b	9fac <fwp_main_thread+0x75c>
    a5a4:	f9004293 	str	x19, [x20, #128]
    a5a8:	17fffd4f 	b	9ae4 <fwp_main_thread+0x294>
    a5ac:	f941c2a0 	ldr	x0, [x21, #896]
    a5b0:	b9037abf 	str	wzr, [x21, #888]
    a5b4:	b5ffaca0 	cbnz	x0, 9b48 <fwp_main_thread+0x2f8>
    a5b8:	97ffef36 	bl	6290 <fwp_free_zombie>
    a5bc:	d00000a0 	adrp	x0, 20000 <__data_start>
    a5c0:	9101c015 	add	x21, x0, #0x70
    a5c4:	f94042a0 	ldr	x0, [x21, #128]
    a5c8:	b5ffac00 	cbnz	x0, 9b48 <fwp_main_thread+0x2f8>
    a5cc:	f9407ea0 	ldr	x0, [x21, #248]
    a5d0:	b5ffabc0 	cbnz	x0, 9b48 <fwp_main_thread+0x2f8>
    a5d4:	b9411aa0 	ldr	w0, [x21, #280]
    a5d8:	340001c0 	cbz	w0, a610 <fwp_main_thread+0xdc0>
    a5dc:	93407c14 	sxtw	x20, w0
    a5e0:	51000400 	sub	w0, w0, #0x1
    a5e4:	d1000a94 	sub	x20, x20, #0x2
    a5e8:	910482b6 	add	x22, x21, #0x120
    a5ec:	cb204294 	sub	x20, x20, w0, uxtw
    a5f0:	93407c13 	sxtw	x19, w0
    a5f4:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    a5f8:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    a5fc:	b9011ab3 	str	w19, [x21, #280]
    a600:	d1000673 	sub	x19, x19, #0x1
    a604:	97ffe0e7 	bl	29a0 <munmap@plt>
    a608:	eb14027f 	cmp	x19, x20
    a60c:	54ffff41 	b.ne	a5f4 <fwp_main_thread+0xda4>  // b.any
    a610:	d00000bc 	adrp	x28, 20000 <__data_start>
    a614:	91004380 	add	x0, x28, #0x10
    a618:	b9404800 	ldr	w0, [x0, #72]
    a61c:	37f80040 	tbnz	w0, #31, a624 <fwp_main_thread+0xdd4>
    a620:	97ffe09c 	bl	2890 <close@plt>
    a624:	d00000a0 	adrp	x0, 20000 <__data_start>
    a628:	9101c000 	add	x0, x0, #0x70
    a62c:	9100439c 	add	x28, x28, #0x10
    a630:	12800001 	mov	w1, #0xffffffff            	// #-1
    a634:	d2800013 	mov	x19, #0x0                   	// #0
    a638:	f941c415 	ldr	x21, [x0, #904]
    a63c:	b9004b81 	str	w1, [x28, #72]
    a640:	f941c814 	ldr	x20, [x0, #912]
    a644:	b4000175 	cbz	x21, a670 <fwp_main_thread+0xe20>
    a648:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    a64c:	b40000c0 	cbz	x0, a664 <fwp_main_thread+0xe14>
    a650:	f9400001 	ldr	x1, [x0]
    a654:	b5ffa7a1 	cbnz	x1, 9b48 <fwp_main_thread+0x2f8>
    a658:	f9400401 	ldr	x1, [x0, #8]
    a65c:	b5ffa761 	cbnz	x1, 9b48 <fwp_main_thread+0x2f8>
    a660:	97ffe918 	bl	4ac0 <fwp_mem_free>
    a664:	91000673 	add	x19, x19, #0x1
    a668:	eb1302bf 	cmp	x21, x19
    a66c:	54fffee1 	b.ne	a648 <fwp_main_thread+0xdf8>  // b.any
    a670:	aa1403e0 	mov	x0, x20
    a674:	97ffe913 	bl	4ac0 <fwp_mem_free>
    a678:	d00000a0 	adrp	x0, 20000 <__data_start>
    a67c:	9101c000 	add	x0, x0, #0x70
    a680:	f941c013 	ldr	x19, [x0, #896]
    a684:	f901c41f 	str	xzr, [x0, #904]
    a688:	f901c81f 	str	xzr, [x0, #912]
    a68c:	b40001f3 	cbz	x19, a6c8 <fwp_main_thread+0xe78>
    a690:	f9401661 	ldr	x1, [x19, #40]
    a694:	b5ffa5a1 	cbnz	x1, 9b48 <fwp_main_thread+0x2f8>
    a698:	f9405661 	ldr	x1, [x19, #168]
    a69c:	b5ffa561 	cbnz	x1, 9b48 <fwp_main_thread+0x2f8>
    a6a0:	f941a401 	ldr	x1, [x0, #840]
    a6a4:	b5ffa521 	cbnz	x1, 9b48 <fwp_main_thread+0x2f8>
    a6a8:	f941ac00 	ldr	x0, [x0, #856]
    a6ac:	b5ffa4e0 	cbnz	x0, 9b48 <fwp_main_thread+0x2f8>
    a6b0:	d2823a02 	mov	x2, #0x11d0                	// #4560
    a6b4:	d0000120 	adrp	x0, 30000 <alt.9+0xfbf0>
    a6b8:	91104000 	add	x0, x0, #0x410
    a6bc:	97ffe065 	bl	2850 <memset@plt>
    a6c0:	aa1303e0 	mov	x0, x19
    a6c4:	97ffe8ff 	bl	4ac0 <fwp_mem_free>
    a6c8:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a6cc:	f947ec00 	ldr	x0, [x0, #4056]
    a6d0:	d00000a1 	adrp	x1, 20000 <__data_start>
    a6d4:	9101c021 	add	x1, x1, #0x70
    a6d8:	f9400000 	ldr	x0, [x0]
    a6dc:	f900083f 	str	xzr, [x1, #16]
    a6e0:	f901c03f 	str	xzr, [x1, #896]
    a6e4:	97ffe0b3 	bl	29b0 <fflush@plt>
    a6e8:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a6ec:	f947f400 	ldr	x0, [x0, #4072]
    a6f0:	f85f83a2 	ldur	x2, [x29, #-8]
    a6f4:	f9400001 	ldr	x1, [x0]
    a6f8:	eb010042 	subs	x2, x2, x1
    a6fc:	d2800001 	mov	x1, #0x0                   	// #0
    a700:	54003401 	b.ne	ad80 <fwp_main_thread+0x1530>  // b.any
    a704:	910003bf 	mov	sp, x29
    a708:	d2800000 	mov	x0, #0x0                   	// #0
    a70c:	a94153f3 	ldp	x19, x20, [sp, #16]
    a710:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a714:	a94363f7 	ldp	x23, x24, [sp, #48]
    a718:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a71c:	a94573fb 	ldp	x27, x28, [sp, #80]
    a720:	fd4033e8 	ldr	d8, [sp, #96]
    a724:	a8c77bfd 	ldp	x29, x30, [sp], #112
    a728:	d65f03c0 	ret
    a72c:	b0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    a730:	913e8000 	add	x0, x0, #0xfa0
    a734:	9400038b 	bl	b560 <atexit>
    a738:	17fffc5c 	b	98a8 <fwp_main_thread+0x58>
    a73c:	97ffe672 	bl	4104 <fwp_heap_init>
    a740:	17fffc56 	b	9898 <fwp_main_thread+0x48>
    a744:	f9400435 	ldr	x21, [x1, #8]
    a748:	b4000115 	cbz	x21, a768 <fwp_main_thread+0xf18>
    a74c:	f9400820 	ldr	x0, [x1, #16]
    a750:	cb150000 	sub	x0, x0, x21
    a754:	eb00035f 	cmp	x26, x0
    a758:	54000088 	b.hi	a768 <fwp_main_thread+0xf18>  // b.pmore
    a75c:	8b1a02a0 	add	x0, x21, x26
    a760:	f9000420 	str	x0, [x1, #8]
    a764:	17fffd53 	b	9cb0 <fwp_main_thread+0x460>
    a768:	52800001 	mov	w1, #0x0                   	// #0
    a76c:	d2800300 	mov	x0, #0x18                  	// #24
    a770:	97ffe9f4 	bl	4f40 <fwp_heap_alloc>
    a774:	aa0003f5 	mov	x21, x0
    a778:	17fffd62 	b	9d00 <fwp_main_thread+0x4b0>
    a77c:	72003c5f 	tst	w2, #0xffff
    a780:	54ffafe1 	b.ne	9d7c <fwp_main_thread+0x52c>  // b.any
    a784:	39400340 	ldrb	w0, [x26]
    a788:	7103fc1f 	cmp	w0, #0xff
    a78c:	54ffaf61 	b.ne	9d78 <fwp_main_thread+0x528>  // b.any
    a790:	aa1a03e0 	mov	x0, x26
    a794:	97ffe82b 	bl	4840 <fwp_rc_forget_slot>
    a798:	17fffd78 	b	9d78 <fwp_main_thread+0x528>
    a79c:	b90004ff 	str	wzr, [x7, #4]
    a7a0:	17fffee9 	b	a344 <fwp_main_thread+0xaf4>
    a7a4:	72003c1f 	tst	w0, #0xffff
    a7a8:	54ffdc61 	b.ne	a334 <fwp_main_thread+0xae4>  // b.any
    a7ac:	17fffedf 	b	a328 <fwp_main_thread+0xad8>
    a7b0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7b4:	aa1c03e9 	mov	x9, x28
    a7b8:	b97ed41b 	ldr	w27, [x0, #16084]
    a7bc:	b97ed81c 	ldr	w28, [x0, #16088]
    a7c0:	b97ee016 	ldr	w22, [x0, #16096]
    a7c4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a7c8:	aa0903e0 	mov	x0, x9
    a7cc:	f91f7c29 	str	x9, [x1, #16120]
    a7d0:	97ffec24 	bl	5860 <fwp_rc_share>
    a7d4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7d8:	f95f7c09 	ldr	x9, [x0, #16120]
    a7dc:	34000159 	cbz	w25, a804 <fwp_main_thread+0xfb4>
    a7e0:	8b394f53 	add	x19, x26, w25, uxtw #3
    a7e4:	aa1a03f4 	mov	x20, x26
    a7e8:	aa0903f7 	mov	x23, x9
    a7ec:	d503201f 	nop
    a7f0:	f8408680 	ldr	x0, [x20], #8
    a7f4:	97ffec1b 	bl	5860 <fwp_rc_share>
    a7f8:	eb13029f 	cmp	x20, x19
    a7fc:	54ffffa1 	b.ne	a7f0 <fwp_main_thread+0xfa0>  // b.any
    a800:	aa1703e9 	mov	x9, x23
    a804:	aa1a03e2 	mov	x2, x26
    a808:	2a1903e1 	mov	w1, w25
    a80c:	aa0903e0 	mov	x0, x9
    a810:	97ffea11 	bl	5054 <fwp_apply>
    a814:	aa0003f7 	mov	x23, x0
    a818:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a81c:	b97eec00 	ldr	w0, [x0, #16108]
    a820:	6b0002df 	cmp	w22, w0
    a824:	54ffdba2 	b.cs	a398 <fwp_main_thread+0xb48>  // b.hs, b.nlast
    a828:	f9404701 	ldr	x1, [x24, #136]
    a82c:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a830:	b94002e4 	ldr	w4, [x23]
    a834:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a838:	4b1c0000 	sub	w0, w0, w28
    a83c:	f95f7842 	ldr	x2, [x2, #16112]
    a840:	8b041424 	add	x4, x1, x4, lsl #5
    a844:	b93eec60 	str	w0, [x3, #16108]
    a848:	b97ee860 	ldr	w0, [x3, #16104]
    a84c:	f9400c81 	ldr	x1, [x4, #24]
    a850:	4b1b0000 	sub	w0, w0, w27
    a854:	8b3c4c42 	add	x2, x2, w28, uxtw #3
    a858:	b93ee860 	str	w0, [x3, #16104]
    a85c:	f91f7862 	str	x2, [x3, #16112]
    a860:	aa1703e0 	mov	x0, x23
    a864:	b5ffc621 	cbnz	x1, a128 <fwp_main_thread+0x8d8>
    a868:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a86c:	f95f6404 	ldr	x4, [x0, #16072]
    a870:	f91f7c04 	str	x4, [x0, #16120]
    a874:	f95f6016 	ldr	x22, [x0, #16064]
    a878:	b97eec14 	ldr	w20, [x0, #16108]
    a87c:	aa1703e0 	mov	x0, x23
    a880:	97ffebf8 	bl	5860 <fwp_rc_share>
    a884:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a888:	f95f7c04 	ldr	x4, [x0, #16120]
    a88c:	34000174 	cbz	w20, a8b8 <fwp_main_thread+0x1068>
    a890:	f95f781a 	ldr	x26, [x0, #16112]
    a894:	aa0403fb 	mov	x27, x4
    a898:	d2800015 	mov	x21, #0x0                   	// #0
    a89c:	d503201f 	nop
    a8a0:	f8757b40 	ldr	x0, [x26, x21, lsl #3]
    a8a4:	910006b5 	add	x21, x21, #0x1
    a8a8:	97ffebee 	bl	5860 <fwp_rc_share>
    a8ac:	6b15029f 	cmp	w20, w21
    a8b0:	54ffff88 	b.hi	a8a0 <fwp_main_thread+0x1050>  // b.pmore
    a8b4:	aa1b03e4 	mov	x4, x27
    a8b8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8bc:	2a1403e1 	mov	w1, w20
    a8c0:	f95f7802 	ldr	x2, [x0, #16112]
    a8c4:	f91f7c04 	str	x4, [x0, #16120]
    a8c8:	aa1703e0 	mov	x0, x23
    a8cc:	97ffe9e2 	bl	5054 <fwp_apply>
    a8d0:	aa0003f7 	mov	x23, x0
    a8d4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8d8:	f95f7c04 	ldr	x4, [x0, #16120]
    a8dc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8e0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a8e4:	f95f5c00 	ldr	x0, [x0, #16056]
    a8e8:	f1000400 	subs	x0, x0, #0x1
    a8ec:	f91f5c20 	str	x0, [x1, #16056]
    a8f0:	54ffba81 	b.ne	a040 <fwp_main_thread+0x7f0>  // b.any
    a8f4:	17fffeb2 	b	a3bc <fwp_main_thread+0xb6c>
    a8f8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8fc:	2a1b03e2 	mov	w2, w27
    a900:	aa1403e4 	mov	x4, x20
    a904:	b97ed41b 	ldr	w27, [x0, #16084]
    a908:	b97ed81c 	ldr	w28, [x0, #16088]
    a90c:	b97ee016 	ldr	w22, [x0, #16096]
    a910:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a914:	9117c00a 	add	x10, x0, #0x5f0
    a918:	11000440 	add	w0, w2, #0x1
    a91c:	f120001f 	cmp	x0, #0x800
    a920:	d37df000 	lsl	x0, x0, #3
    a924:	b953a541 	ldr	w1, [x10, #5028]
    a928:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a92c:	540018e0 	b.eq	ac48 <fwp_main_thread+0x13f8>  // b.none
    a930:	91003c01 	add	x1, x0, #0xf
    a934:	8b411141 	add	x1, x10, x1, lsr #4
    a938:	397e8021 	ldrb	w1, [x1, #4000]
    a93c:	910f002b 	add	x11, x1, #0x3c0
    a940:	8b010428 	add	x8, x1, x1, lsl #1
    a944:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    a948:	8b080d4c 	add	x12, x10, x8, lsl #3
    a94c:	f8687953 	ldr	x19, [x10, x8, lsl #3]
    a950:	2a0b03e1 	mov	w1, w11
    a954:	b4001693 	cbz	x19, ac24 <fwp_main_thread+0x13d4>
    a958:	f940026c 	ldr	x12, [x19]
    a95c:	aa2c03ec 	mvn	x12, x12
    a960:	f828794c 	str	x12, [x10, x8, lsl #3]
    a964:	eb01001f 	cmp	x0, x1
    a968:	540000c2 	b.cs	a980 <fwp_main_thread+0x1130>  // b.hs, b.nlast
    a96c:	d503201f 	nop
    a970:	f8206a7f 	str	xzr, [x19, x0]
    a974:	91002000 	add	x0, x0, #0x8
    a978:	eb00003f 	cmp	x1, x0
    a97c:	54ffffa8 	b.hi	a970 <fwp_main_thread+0x1120>  // b.pmore
    a980:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a984:	9117c008 	add	x8, x0, #0x5f0
    a988:	f94a1100 	ldr	x0, [x8, #5152]
    a98c:	ab010000 	adds	x0, x0, x1
    a990:	54001fa2 	b.cs	ad84 <fwp_main_thread+0x1534>  // b.hs, b.nlast
    a994:	f94a1501 	ldr	x1, [x8, #5160]
    a998:	f90a1100 	str	x0, [x8, #5152]
    a99c:	eb01001f 	cmp	x0, x1
    a9a0:	54000049 	b.ls	a9a8 <fwp_main_thread+0x1158>  // b.plast
    a9a4:	f90a1500 	str	x0, [x8, #5160]
    a9a8:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a9ac:	9117c000 	add	x0, x0, #0x5f0
    a9b0:	1e630161 	ucvtf	d1, w11
    a9b4:	fd4a1c00 	ldr	d0, [x0, #5176]
    a9b8:	1e612800 	fadd	d0, d0, d1
    a9bc:	fd0a1c00 	str	d0, [x0, #5176]
    a9c0:	b94000e0 	ldr	w0, [x7]
    a9c4:	29000a60 	stp	w0, w2, [x19]
    a9c8:	340001a9 	cbz	w9, a9fc <fwp_main_thread+0x11ac>
    a9cc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9d0:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a9d4:	910020e1 	add	x1, x7, #0x8
    a9d8:	f91f6c04 	str	x4, [x0, #16088]
    a9dc:	b93ee009 	str	w9, [x0, #16096]
    a9e0:	f91f7c07 	str	x7, [x0, #16120]
    a9e4:	91002260 	add	x0, x19, #0x8
    a9e8:	97ffdf42 	bl	26f0 <memmove@plt>
    a9ec:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9f0:	f95f6c04 	ldr	x4, [x0, #16088]
    a9f4:	f95f7c07 	ldr	x7, [x0, #16120]
    a9f8:	b97ee009 	ldr	w9, [x0, #16096]
    a9fc:	2a1903e8 	mov	w8, w25
    aa00:	d2800001 	mov	x1, #0x0                   	// #0
    aa04:	34000119 	cbz	w25, aa24 <fwp_main_thread+0x11d4>
    aa08:	0b010120 	add	w0, w9, w1
    aa0c:	f8617b42 	ldr	x2, [x26, x1, lsl #3]
    aa10:	8b000e60 	add	x0, x19, x0, lsl #3
    aa14:	91000421 	add	x1, x1, #0x1
    aa18:	f9000402 	str	x2, [x0, #8]
    aa1c:	eb08003f 	cmp	x1, x8
    aa20:	54ffff41 	b.ne	aa08 <fwp_main_thread+0x11b8>  // b.any
    aa24:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    aa28:	9117c002 	add	x2, x0, #0x5f0
    aa2c:	f949d840 	ldr	x0, [x2, #5040]
    aa30:	f949ec41 	ldr	x1, [x2, #5080]
    aa34:	cb0002e0 	sub	x0, x23, x0
    aa38:	eb01401f 	cmp	x0, x1, lsl #16
    aa3c:	540002e2 	b.cs	aa98 <fwp_main_thread+0x1248>  // b.hs, b.nlast
    aa40:	d350fc01 	lsr	x1, x0, #16
    aa44:	f949fc48 	ldr	x8, [x2, #5112]
    aa48:	8b010821 	add	x1, x1, x1, lsl #2
    aa4c:	d37df021 	lsl	x1, x1, #3
    aa50:	8b010105 	add	x5, x8, x1
    aa54:	f94010a2 	ldr	x2, [x5, #32]
    aa58:	b4000202 	cbz	x2, aa98 <fwp_main_thread+0x1248>
    aa5c:	38616901 	ldrb	w1, [x8, x1]
    aa60:	7100083f 	cmp	w1, #0x2
    aa64:	540010e0 	b.eq	ac80 <fwp_main_thread+0x1430>  // b.none
    aa68:	7100043f 	cmp	w1, #0x1
    aa6c:	54000161 	b.ne	aa98 <fwp_main_thread+0x1248>  // b.any
    aa70:	294304a8 	ldp	w8, w1, [x5, #24]
    aa74:	92403c00 	and	x0, x0, #0xffff
    aa78:	9b087c00 	mul	x0, x0, x8
    aa7c:	d360fc00 	lsr	x0, x0, #32
    aa80:	eb01001f 	cmp	x0, x1
    aa84:	540000a2 	b.cs	aa98 <fwp_main_thread+0x1248>  // b.hs, b.nlast
    aa88:	8b000042 	add	x2, x2, x0
    aa8c:	39400040 	ldrb	w0, [x2]
    aa90:	7100041f 	cmp	w0, #0x1
    aa94:	54000be0 	b.eq	ac10 <fwp_main_thread+0x13c0>  // b.none
    aa98:	f9400c82 	ldr	x2, [x4, #24]
    aa9c:	aa1703e0 	mov	x0, x23
    aaa0:	52800021 	mov	w1, #0x1                   	// #1
    aaa4:	f9400442 	ldr	x2, [x2, #8]
    aaa8:	d63f0040 	blr	x2
    aaac:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    aab0:	9117c002 	add	x2, x0, #0x5f0
    aab4:	f949d841 	ldr	x1, [x2, #5040]
    aab8:	f949ec40 	ldr	x0, [x2, #5080]
    aabc:	cb010261 	sub	x1, x19, x1
    aac0:	eb00403f 	cmp	x1, x0, lsl #16
    aac4:	54000322 	b.cs	ab28 <fwp_main_thread+0x12d8>  // b.hs, b.nlast
    aac8:	d350fc20 	lsr	x0, x1, #16
    aacc:	f949fc44 	ldr	x4, [x2, #5112]
    aad0:	8b000800 	add	x0, x0, x0, lsl #2
    aad4:	d37df002 	lsl	x2, x0, #3
    aad8:	8b020080 	add	x0, x4, x2
    aadc:	f9401019 	ldr	x25, [x0, #32]
    aae0:	b4000259 	cbz	x25, ab28 <fwp_main_thread+0x12d8>
    aae4:	38626882 	ldrb	w2, [x4, x2]
    aae8:	7100085f 	cmp	w2, #0x2
    aaec:	54000d00 	b.eq	ac8c <fwp_main_thread+0x143c>  // b.none
    aaf0:	7100045f 	cmp	w2, #0x1
    aaf4:	540001a1 	b.ne	ab28 <fwp_main_thread+0x12d8>  // b.any
    aaf8:	29430002 	ldp	w2, w0, [x0, #24]
    aafc:	92403c21 	and	x1, x1, #0xffff
    ab00:	9b027c21 	mul	x1, x1, x2
    ab04:	d360fc21 	lsr	x1, x1, #32
    ab08:	eb00003f 	cmp	x1, x0
    ab0c:	540000e2 	b.cs	ab28 <fwp_main_thread+0x12d8>  // b.hs, b.nlast
    ab10:	8b010339 	add	x25, x25, x1
    ab14:	39400320 	ldrb	w0, [x25]
    ab18:	7103fc1f 	cmp	w0, #0xff
    ab1c:	54000c20 	b.eq	aca0 <fwp_main_thread+0x1450>  // b.none
    ab20:	52800020 	mov	w0, #0x1                   	// #1
    ab24:	39000320 	strb	w0, [x25]
    ab28:	aa1703e0 	mov	x0, x23
    ab2c:	aa1303f7 	mov	x23, x19
    ab30:	97ffec68 	bl	5cd0 <fwp_closure_drop>
    ab34:	17ffff39 	b	a818 <fwp_main_thread+0xfc8>
    ab38:	b86268a0 	ldr	w0, [x5, x2]
    ab3c:	b94004c2 	ldr	w2, [x6, #4]
    ab40:	4b020003 	sub	w3, w0, w2
    ab44:	7100047f 	cmp	w3, #0x1
    ab48:	54ffa961 	b.ne	a074 <fwp_main_thread+0x824>  // b.any
    ab4c:	910003f4 	mov	x20, sp
    ab50:	34000ba2 	cbz	w2, acc4 <fwp_main_thread+0x1474>
    ab54:	7100001f 	cmp	w0, #0x0
    ab58:	d37d7c00 	ubfiz	x0, x0, #3, #32
    ab5c:	d2800101 	mov	x1, #0x8                   	// #8
    ab60:	9a81101a 	csel	x26, x0, x1, ne	// ne = any
    ab64:	91003f40 	add	x0, x26, #0xf
    ab68:	92704c01 	and	x1, x0, #0xfffff0000
    ab6c:	927c7c00 	and	x0, x0, #0xffffffff0
    ab70:	cb2163e1 	sub	x1, sp, x1
    ab74:	eb2163ff 	cmp	sp, x1
    ab78:	540000a0 	b.eq	ab8c <fwp_main_thread+0x133c>  // b.none
    ab7c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    ab80:	f90203ff 	str	xzr, [sp, #1024]
    ab84:	eb2163ff 	cmp	sp, x1
    ab88:	54ffffa1 	b.ne	ab7c <fwp_main_thread+0x132c>  // b.any
    ab8c:	92403c00 	and	x0, x0, #0xffff
    ab90:	cb2063ff 	sub	sp, sp, x0
    ab94:	f90003ff 	str	xzr, [sp]
    ab98:	f110001f 	cmp	x0, #0x400
    ab9c:	54000043 	b.cc	aba4 <fwp_main_thread+0x1354>  // b.lo, b.ul, b.last
    aba0:	f90203ff 	str	xzr, [sp, #1024]
    aba4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aba8:	d37d7c5b 	ubfiz	x27, x2, #3, #32
    abac:	910043f5 	add	x21, sp, #0x10
    abb0:	aa1b03e2 	mov	x2, x27
    abb4:	aa1a03e3 	mov	x3, x26
    abb8:	f91f7c04 	str	x4, [x0, #16120]
    abbc:	f95f5800 	ldr	x0, [x0, #16048]
    abc0:	91004001 	add	x1, x0, #0x10
    abc4:	aa1503e0 	mov	x0, x21
    abc8:	91012021 	add	x1, x1, #0x48
    abcc:	97ffdf01 	bl	27d0 <__memcpy_chk@plt>
    abd0:	eb1b035f 	cmp	x26, x27
    abd4:	aa1603e1 	mov	x1, x22
    abd8:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    abdc:	d2800102 	mov	x2, #0x8                   	// #8
    abe0:	cb1b0063 	sub	x3, x3, x27
    abe4:	8b1b02a0 	add	x0, x21, x27
    abe8:	97ffdefa 	bl	27d0 <__memcpy_chk@plt>
    abec:	f9400f81 	ldr	x1, [x28, #24]
    abf0:	aa1503e0 	mov	x0, x21
    abf4:	f9400021 	ldr	x1, [x1]
    abf8:	d63f0020 	blr	x1
    abfc:	aa0003f7 	mov	x23, x0
    ac00:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac04:	f95f7c04 	ldr	x4, [x0, #16120]
    ac08:	9100029f 	mov	sp, x20
    ac0c:	17ffff34 	b	a8dc <fwp_main_thread+0x108c>
    ac10:	b90004ff 	str	wzr, [x7, #4]
    ac14:	17ffffa6 	b	aaac <fwp_main_thread+0x125c>
    ac18:	72003c3f 	tst	w1, #0xffff
    ac1c:	54ffa6c1 	b.ne	a0f4 <fwp_main_thread+0x8a4>  // b.any
    ac20:	17fffd2f 	b	a0dc <fwp_main_thread+0x88c>
    ac24:	f9400593 	ldr	x19, [x12, #8]
    ac28:	b4000113 	cbz	x19, ac48 <fwp_main_thread+0x13f8>
    ac2c:	f9400988 	ldr	x8, [x12, #16]
    ac30:	cb130108 	sub	x8, x8, x19
    ac34:	eb08003f 	cmp	x1, x8
    ac38:	54000088 	b.hi	ac48 <fwp_main_thread+0x13f8>  // b.pmore
    ac3c:	8b010268 	add	x8, x19, x1
    ac40:	f9000588 	str	x8, [x12, #8]
    ac44:	17ffff48 	b	a964 <fwp_main_thread+0x1114>
    ac48:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ac4c:	b93ed422 	str	w2, [x1, #16084]
    ac50:	b93ed829 	str	w9, [x1, #16088]
    ac54:	f91f7024 	str	x4, [x1, #16096]
    ac58:	f91f7c27 	str	x7, [x1, #16120]
    ac5c:	52800001 	mov	w1, #0x0                   	// #0
    ac60:	97ffe8b8 	bl	4f40 <fwp_heap_alloc>
    ac64:	aa0003f3 	mov	x19, x0
    ac68:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac6c:	f95f7004 	ldr	x4, [x0, #16096]
    ac70:	f95f7c07 	ldr	x7, [x0, #16120]
    ac74:	b97ed402 	ldr	w2, [x0, #16084]
    ac78:	b97ed809 	ldr	w9, [x0, #16088]
    ac7c:	17ffff51 	b	a9c0 <fwp_main_thread+0x1170>
    ac80:	72003c1f 	tst	w0, #0xffff
    ac84:	54fff0a1 	b.ne	aa98 <fwp_main_thread+0x1248>  // b.any
    ac88:	17ffff81 	b	aa8c <fwp_main_thread+0x123c>
    ac8c:	72003c3f 	tst	w1, #0xffff
    ac90:	54fff4c1 	b.ne	ab28 <fwp_main_thread+0x12d8>  // b.any
    ac94:	39400320 	ldrb	w0, [x25]
    ac98:	7103fc1f 	cmp	w0, #0xff
    ac9c:	54fff421 	b.ne	ab20 <fwp_main_thread+0x12d0>  // b.any
    aca0:	aa1903e0 	mov	x0, x25
    aca4:	97ffe6e7 	bl	4840 <fwp_rc_forget_slot>
    aca8:	17ffff9e 	b	ab20 <fwp_main_thread+0x12d0>
    acac:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    acb0:	f91f7c24 	str	x4, [x1, #16120]
    acb4:	97ffe69c 	bl	4724 <fwp_rc_wide_dup>
    acb8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acbc:	f95f7c04 	ldr	x4, [x0, #16120]
    acc0:	17fffd0d 	b	a0f4 <fwp_main_thread+0x8a4>
    acc4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acc8:	f9400021 	ldr	x1, [x1]
    accc:	f91f7c04 	str	x4, [x0, #16120]
    acd0:	aa1603e0 	mov	x0, x22
    acd4:	d63f0020 	blr	x1
    acd8:	aa0003f7 	mov	x23, x0
    acdc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ace0:	f95f7c04 	ldr	x4, [x0, #16120]
    ace4:	9100029f 	mov	sp, x20
    ace8:	17fffefd 	b	a8dc <fwp_main_thread+0x108c>
    acec:	72003c3f 	tst	w1, #0xffff
    acf0:	54ff8a41 	b.ne	9e38 <fwp_main_thread+0x5e8>  // b.any
    acf4:	17fffc4c 	b	9e24 <fwp_main_thread+0x5d4>
    acf8:	72003c3f 	tst	w1, #0xffff
    acfc:	54ff9421 	b.ne	9f80 <fwp_main_thread+0x730>  // b.any
    ad00:	17fffc95 	b	9f54 <fwp_main_thread+0x704>
    ad04:	72003c3f 	tst	w1, #0xffff
    ad08:	54ff8e21 	b.ne	9ecc <fwp_main_thread+0x67c>  // b.any
    ad0c:	17fffc6b 	b	9eb8 <fwp_main_thread+0x668>
    ad10:	72003c3f 	tst	w1, #0xffff
    ad14:	54ff9861 	b.ne	a020 <fwp_main_thread+0x7d0>  // b.any
    ad18:	17fffcbc 	b	a008 <fwp_main_thread+0x7b8>
    ad1c:	aa0103e0 	mov	x0, x1
    ad20:	17fffb9d 	b	9b94 <fwp_main_thread+0x344>
    ad24:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad28:	aa0403e0 	mov	x0, x4
    ad2c:	52800034 	mov	w20, #0x1                   	// #1
    ad30:	f91f7c24 	str	x4, [x1, #16120]
    ad34:	97ffeacb 	bl	5860 <fwp_rc_share>
    ad38:	aa1703e0 	mov	x0, x23
    ad3c:	97ffeac9 	bl	5860 <fwp_rc_share>
    ad40:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad44:	f95f7c04 	ldr	x4, [x0, #16120]
    ad48:	f91f7816 	str	x22, [x0, #16112]
    ad4c:	aa0403f7 	mov	x23, x4
    ad50:	17fffeda 	b	a8b8 <fwp_main_thread+0x1068>
    ad54:	aa1303e0 	mov	x0, x19
    ad58:	97ffe6ba 	bl	4840 <fwp_rc_forget_slot>
    ad5c:	17fffc35 	b	9e30 <fwp_main_thread+0x5e0>
    ad60:	97ffe671 	bl	4724 <fwp_rc_wide_dup>
    ad64:	17fffcaf 	b	a020 <fwp_main_thread+0x7d0>
    ad68:	aa1303e0 	mov	x0, x19
    ad6c:	97ffe6b5 	bl	4840 <fwp_rc_forget_slot>
    ad70:	17fffc55 	b	9ec4 <fwp_main_thread+0x674>
    ad74:	aa1303e0 	mov	x0, x19
    ad78:	97ffe6b2 	bl	4840 <fwp_rc_forget_slot>
    ad7c:	17fffc79 	b	9f60 <fwp_main_thread+0x710>
    ad80:	97ffdec0 	bl	2880 <__stack_chk_fail@plt>
    ad84:	97ffe0ab 	bl	3030 <fwp_heap_oom>
    ad88:	b0000000 	adrp	x0, b000 <__divti3+0x190>
    ad8c:	912fa000 	add	x0, x0, #0xbe8
    ad90:	97ffe29c 	bl	3800 <fwp_trap>
    ad94:	97ffe0e7 	bl	3130 <descent_phase_fail>
    ad98:	b0000000 	adrp	x0, b000 <__divti3+0x190>
    ad9c:	91304000 	add	x0, x0, #0xc10
    ada0:	97ffe298 	bl	3800 <fwp_trap>
    ada4:	aa1403e0 	mov	x0, x20
    ada8:	97ffeb1b 	bl	5a14 <fwp_drop0>
    adac:	aa1703e0 	mov	x0, x23
    adb0:	97ffeb19 	bl	5a14 <fwp_drop0>
    adb4:	d00000a0 	adrp	x0, 20000 <__data_start>
    adb8:	9101c000 	add	x0, x0, #0x70
    adbc:	52800021 	mov	w1, #0x1                   	// #1
    adc0:	b9036c01 	str	w1, [x0, #876]
    adc4:	f901b81f 	str	xzr, [x0, #880]
    adc8:	17fffae9 	b	996c <fwp_main_thread+0x11c>
    adcc:	72003c3f 	tst	w1, #0xffff
    add0:	54ffbd81 	b.ne	a580 <fwp_main_thread+0xd30>  // b.any
    add4:	17fffde3 	b	a560 <fwp_main_thread+0xd10>
    add8:	72003c3f 	tst	w1, #0xffff
    addc:	54ffb741 	b.ne	a4c4 <fwp_main_thread+0xc74>  // b.any
    ade0:	17fffdb4 	b	a4b0 <fwp_main_thread+0xc60>
    ade4:	ca5546a0 	eor	x0, x21, x21, lsr #17
    ade8:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    adec:	9117c021 	add	x1, x1, #0x5f0
    adf0:	ca402400 	eor	x0, x0, x0, lsr #9
    adf4:	8b200c20 	add	x0, x1, w0, uxtb #3
    adf8:	f94a2400 	ldr	x0, [x0, #5192]
    adfc:	b5000080 	cbnz	x0, ae0c <fwp_main_thread+0x15bc>
    ae00:	14000019 	b	ae64 <fwp_main_thread+0x1614>
    ae04:	f9400800 	ldr	x0, [x0, #16]
    ae08:	b40002e0 	cbz	x0, ae64 <fwp_main_thread+0x1614>
    ae0c:	f9400001 	ldr	x1, [x0]
    ae10:	eb0102bf 	cmp	x21, x1
    ae14:	54ffff81 	b.ne	ae04 <fwp_main_thread+0x15b4>  // b.any
    ae18:	f9400401 	ldr	x1, [x0, #8]
    ae1c:	d1000421 	sub	x1, x1, #0x1
    ae20:	f9000401 	str	x1, [x0, #8]
    ae24:	f103f83f 	cmp	x1, #0xfe
    ae28:	54ffbac1 	b.ne	a580 <fwp_main_thread+0xd30>  // b.any
    ae2c:	aa1503e0 	mov	x0, x21
    ae30:	97ffe684 	bl	4840 <fwp_rc_forget_slot>
    ae34:	12800020 	mov	w0, #0xfffffffe            	// #-2
    ae38:	390002a0 	strb	w0, [x21]
    ae3c:	17fffdd1 	b	a580 <fwp_main_thread+0xd30>
    ae40:	aa1303e0 	mov	x0, x19
    ae44:	97ffeaac 	bl	58f4 <fwp_rc_free_arr>
    ae48:	17fffdce 	b	a580 <fwp_main_thread+0xd30>
    ae4c:	b9037a9f 	str	wzr, [x20, #888]
    ae50:	b4ffbb40 	cbz	x0, a5b8 <fwp_main_thread+0xd68>
    ae54:	97ffde9f 	bl	28d0 <abort@plt>
    ae58:	aa1903e0 	mov	x0, x25
    ae5c:	97ffe679 	bl	4840 <fwp_rc_forget_slot>
    ae60:	17fffd97 	b	a4bc <fwp_main_thread+0xc6c>
    ae64:	b0000000 	adrp	x0, b000 <__divti3+0x190>
    ae68:	9123c000 	add	x0, x0, #0x8f0
    ae6c:	97ffe265 	bl	3800 <fwp_trap>

000000000000ae70 <__divti3>:
    ae70:	d503245f 	bti	c
    ae74:	d2800004 	mov	x4, #0x0                   	// #0
    ae78:	b7f80721 	tbnz	x1, #63, af5c <__divti3+0xec>
    ae7c:	b6f80083 	tbz	x3, #63, ae8c <__divti3+0x1c>
    ae80:	eb0203e2 	negs	x2, x2
    ae84:	aa2403e4 	mvn	x4, x4
    ae88:	da0303e3 	ngc	x3, x3
    ae8c:	aa0203e6 	mov	x6, x2
    ae90:	aa0003e7 	mov	x7, x0
    ae94:	aa0103e5 	mov	x5, x1
    ae98:	b5000583 	cbnz	x3, af48 <__divti3+0xd8>
    ae9c:	eb01005f 	cmp	x2, x1
    aea0:	54000e69 	b.ls	b06c <__divti3+0x1fc>  // b.plast
    aea4:	dac01040 	clz	x0, x2
    aea8:	b40000e0 	cbz	x0, aec4 <__divti3+0x54>
    aeac:	4b0003e1 	neg	w1, w0
    aeb0:	9ac020a5 	lsl	x5, x5, x0
    aeb4:	9ac02046 	lsl	x6, x2, x0
    aeb8:	9ac124e1 	lsr	x1, x7, x1
    aebc:	aa050025 	orr	x5, x1, x5
    aec0:	9ac020e7 	lsl	x7, x7, x0
    aec4:	d360fcc8 	lsr	x8, x6, #32
    aec8:	92407cc2 	and	x2, x6, #0xffffffff
    aecc:	9ac808a3 	udiv	x3, x5, x8
    aed0:	9b089465 	msub	x5, x3, x8, x5
    aed4:	aa0303e0 	mov	x0, x3
    aed8:	9b037c41 	mul	x1, x2, x3
    aedc:	93c780a5 	extr	x5, x5, x7, #32
    aee0:	eb05003f 	cmp	x1, x5
    aee4:	540000a9 	b.ls	aef8 <__divti3+0x88>  // b.plast
    aee8:	ab0500c5 	adds	x5, x6, x5
    aeec:	d1000460 	sub	x0, x3, #0x1
    aef0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    aef4:	540015a8 	b.hi	b1a8 <__divti3+0x338>  // b.pmore
    aef8:	cb0100a5 	sub	x5, x5, x1
    aefc:	9ac808a3 	udiv	x3, x5, x8
    af00:	9b089465 	msub	x5, x3, x8, x5
    af04:	aa0303e1 	mov	x1, x3
    af08:	9b037c42 	mul	x2, x2, x3
    af0c:	aa0703e3 	mov	x3, x7
    af10:	b3607ca3 	bfi	x3, x5, #32, #32
    af14:	eb03005f 	cmp	x2, x3
    af18:	540000c9 	b.ls	af30 <__divti3+0xc0>  // b.plast
    af1c:	ab0300c3 	adds	x3, x6, x3
    af20:	d1000425 	sub	x5, x1, #0x1
    af24:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    af28:	d1000821 	sub	x1, x1, #0x2
    af2c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    af30:	aa008020 	orr	x0, x1, x0, lsl #32
    af34:	d2800001 	mov	x1, #0x0                   	// #0
    af38:	b4000064 	cbz	x4, af44 <__divti3+0xd4>
    af3c:	eb0003e0 	negs	x0, x0
    af40:	da0103e1 	ngc	x1, x1
    af44:	d65f03c0 	ret
    af48:	eb01007f 	cmp	x3, x1
    af4c:	54000109 	b.ls	af6c <__divti3+0xfc>  // b.plast
    af50:	d2800001 	mov	x1, #0x0                   	// #0
    af54:	d2800000 	mov	x0, #0x0                   	// #0
    af58:	17fffff8 	b	af38 <__divti3+0xc8>
    af5c:	eb0003e0 	negs	x0, x0
    af60:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    af64:	da0103e1 	ngc	x1, x1
    af68:	17ffffc5 	b	ae7c <__divti3+0xc>
    af6c:	dac01067 	clz	x7, x3
    af70:	b40010e7 	cbz	x7, b18c <__divti3+0x31c>
    af74:	d2800805 	mov	x5, #0x40                  	// #64
    af78:	cb0700a5 	sub	x5, x5, x7
    af7c:	9ac72063 	lsl	x3, x3, x7
    af80:	9ac52448 	lsr	x8, x2, x5
    af84:	aa030108 	orr	x8, x8, x3
    af88:	9ac52426 	lsr	x6, x1, x5
    af8c:	92407d0a 	and	x10, x8, #0xffffffff
    af90:	d360fd09 	lsr	x9, x8, #32
    af94:	9ac52403 	lsr	x3, x0, x5
    af98:	9ac72021 	lsl	x1, x1, x7
    af9c:	aa010063 	orr	x3, x3, x1
    afa0:	9ac72042 	lsl	x2, x2, x7
    afa4:	9ac908cb 	udiv	x11, x6, x9
    afa8:	9b099965 	msub	x5, x11, x9, x6
    afac:	aa0b03e1 	mov	x1, x11
    afb0:	9b0b7d46 	mul	x6, x10, x11
    afb4:	93c380a5 	extr	x5, x5, x3, #32
    afb8:	eb0500df 	cmp	x6, x5
    afbc:	540000a9 	b.ls	afd0 <__divti3+0x160>  // b.plast
    afc0:	ab050105 	adds	x5, x8, x5
    afc4:	d1000561 	sub	x1, x11, #0x1
    afc8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    afcc:	54000f48 	b.hi	b1b4 <__divti3+0x344>  // b.pmore
    afd0:	cb0600a6 	sub	x6, x5, x6
    afd4:	9ac908cb 	udiv	x11, x6, x9
    afd8:	9b099969 	msub	x9, x11, x9, x6
    afdc:	aa0b03e5 	mov	x5, x11
    afe0:	9b0b7d4a 	mul	x10, x10, x11
    afe4:	b3607d23 	bfi	x3, x9, #32, #32
    afe8:	eb03015f 	cmp	x10, x3
    afec:	540000a9 	b.ls	b000 <__divti3+0x190>  // b.plast
    aff0:	ab030103 	adds	x3, x8, x3
    aff4:	d1000565 	sub	x5, x11, #0x1
    aff8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    affc:	54000e28 	b.hi	b1c0 <__divti3+0x350>  // b.pmore
    b000:	aa0180a1 	orr	x1, x5, x1, lsl #32
    b004:	92407c48 	and	x8, x2, #0xffffffff
    b008:	2a0503e5 	mov	w5, w5
    b00c:	d360fc42 	lsr	x2, x2, #32
    b010:	d360fc26 	lsr	x6, x1, #32
    b014:	cb0a0063 	sub	x3, x3, x10
    b018:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    b01c:	9b087caa 	mul	x10, x5, x8
    b020:	9b087cc8 	mul	x8, x6, x8
    b024:	9b0220a5 	madd	x5, x5, x2, x8
    b028:	9b027cc6 	mul	x6, x6, x2
    b02c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    b030:	8b0900c5 	add	x5, x6, x9
    b034:	eb02011f 	cmp	x8, x2
    b038:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    b03c:	8b4280c6 	add	x6, x6, x2, lsr #32
    b040:	eb06007f 	cmp	x3, x6
    b044:	540000e3 	b.cc	b060 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    b048:	92407d4a 	and	x10, x10, #0xffffffff
    b04c:	9ac72000 	lsl	x0, x0, x7
    b050:	8b028142 	add	x2, x10, x2, lsl #32
    b054:	eb02001f 	cmp	x0, x2
    b058:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    b05c:	54000a01 	b.ne	b19c <__divti3+0x32c>  // b.any
    b060:	d1000420 	sub	x0, x1, #0x1
    b064:	d2800001 	mov	x1, #0x0                   	// #0
    b068:	17ffffb4 	b	af38 <__divti3+0xc8>
    b06c:	b5000062 	cbnz	x2, b078 <__divti3+0x208>
    b070:	d2800022 	mov	x2, #0x1                   	// #1
    b074:	9ac30846 	udiv	x6, x2, x3
    b078:	dac010c8 	clz	x8, x6
    b07c:	b5000408 	cbnz	x8, b0fc <__divti3+0x28c>
    b080:	d360fcc9 	lsr	x9, x6, #32
    b084:	92407cc5 	and	x5, x6, #0xffffffff
    b088:	cb060023 	sub	x3, x1, x6
    b08c:	d2800021 	mov	x1, #0x1                   	// #1
    b090:	9ac90868 	udiv	x8, x3, x9
    b094:	9b098d03 	msub	x3, x8, x9, x3
    b098:	aa0803e0 	mov	x0, x8
    b09c:	9b057d02 	mul	x2, x8, x5
    b0a0:	93c78063 	extr	x3, x3, x7, #32
    b0a4:	eb03005f 	cmp	x2, x3
    b0a8:	540000a9 	b.ls	b0bc <__divti3+0x24c>  // b.plast
    b0ac:	ab0300c3 	adds	x3, x6, x3
    b0b0:	d1000500 	sub	x0, x8, #0x1
    b0b4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b0b8:	54000968 	b.hi	b1e4 <__divti3+0x374>  // b.pmore
    b0bc:	cb020063 	sub	x3, x3, x2
    b0c0:	9ac90862 	udiv	x2, x3, x9
    b0c4:	aa0203e8 	mov	x8, x2
    b0c8:	9b098c42 	msub	x2, x2, x9, x3
    b0cc:	aa0703e3 	mov	x3, x7
    b0d0:	9b057d05 	mul	x5, x8, x5
    b0d4:	b3607c43 	bfi	x3, x2, #32, #32
    b0d8:	eb0300bf 	cmp	x5, x3
    b0dc:	540000c9 	b.ls	b0f4 <__divti3+0x284>  // b.plast
    b0e0:	ab0300c2 	adds	x2, x6, x3
    b0e4:	d1000503 	sub	x3, x8, #0x1
    b0e8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    b0ec:	d1000908 	sub	x8, x8, #0x2
    b0f0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    b0f4:	aa008100 	orr	x0, x8, x0, lsl #32
    b0f8:	17ffff90 	b	af38 <__divti3+0xc8>
    b0fc:	9ac820c6 	lsl	x6, x6, x8
    b100:	d2800803 	mov	x3, #0x40                  	// #64
    b104:	cb080063 	sub	x3, x3, x8
    b108:	d360fcc9 	lsr	x9, x6, #32
    b10c:	9ac82027 	lsl	x7, x1, x8
    b110:	92407cc5 	and	x5, x6, #0xffffffff
    b114:	9ac32422 	lsr	x2, x1, x3
    b118:	9ac32403 	lsr	x3, x0, x3
    b11c:	aa070063 	orr	x3, x3, x7
    b120:	9ac9084a 	udiv	x10, x2, x9
    b124:	9ac82007 	lsl	x7, x0, x8
    b128:	9b098940 	msub	x0, x10, x9, x2
    b12c:	aa0a03e1 	mov	x1, x10
    b130:	9b0a7ca2 	mul	x2, x5, x10
    b134:	93c38000 	extr	x0, x0, x3, #32
    b138:	eb00005f 	cmp	x2, x0
    b13c:	540000a9 	b.ls	b150 <__divti3+0x2e0>  // b.plast
    b140:	ab0000c0 	adds	x0, x6, x0
    b144:	d1000541 	sub	x1, x10, #0x1
    b148:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    b14c:	54000468 	b.hi	b1d8 <__divti3+0x368>  // b.pmore
    b150:	cb020000 	sub	x0, x0, x2
    b154:	9ac9080a 	udiv	x10, x0, x9
    b158:	9b098140 	msub	x0, x10, x9, x0
    b15c:	aa0a03e2 	mov	x2, x10
    b160:	9b0a7ca8 	mul	x8, x5, x10
    b164:	b3607c03 	bfi	x3, x0, #32, #32
    b168:	eb03011f 	cmp	x8, x3
    b16c:	540000a9 	b.ls	b180 <__divti3+0x310>  // b.plast
    b170:	ab0300c3 	adds	x3, x6, x3
    b174:	d1000542 	sub	x2, x10, #0x1
    b178:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    b17c:	54000288 	b.hi	b1cc <__divti3+0x35c>  // b.pmore
    b180:	cb080063 	sub	x3, x3, x8
    b184:	aa018041 	orr	x1, x2, x1, lsl #32
    b188:	17ffffc2 	b	b090 <__divti3+0x220>
    b18c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    b190:	d2800001 	mov	x1, #0x0                   	// #0
    b194:	9a9f87e0 	cset	x0, ls	// ls = plast
    b198:	17ffff68 	b	af38 <__divti3+0xc8>
    b19c:	aa0103e0 	mov	x0, x1
    b1a0:	d2800001 	mov	x1, #0x0                   	// #0
    b1a4:	17ffff65 	b	af38 <__divti3+0xc8>
    b1a8:	d1000860 	sub	x0, x3, #0x2
    b1ac:	8b0600a5 	add	x5, x5, x6
    b1b0:	17ffff52 	b	aef8 <__divti3+0x88>
    b1b4:	d1000961 	sub	x1, x11, #0x2
    b1b8:	8b0800a5 	add	x5, x5, x8
    b1bc:	17ffff85 	b	afd0 <__divti3+0x160>
    b1c0:	d1000965 	sub	x5, x11, #0x2
    b1c4:	8b080063 	add	x3, x3, x8
    b1c8:	17ffff8e 	b	b000 <__divti3+0x190>
    b1cc:	d1000942 	sub	x2, x10, #0x2
    b1d0:	8b060063 	add	x3, x3, x6
    b1d4:	17ffffeb 	b	b180 <__divti3+0x310>
    b1d8:	d1000941 	sub	x1, x10, #0x2
    b1dc:	8b060000 	add	x0, x0, x6
    b1e0:	17ffffdc 	b	b150 <__divti3+0x2e0>
    b1e4:	d1000900 	sub	x0, x8, #0x2
    b1e8:	8b060063 	add	x3, x3, x6
    b1ec:	17ffffb4 	b	b0bc <__divti3+0x24c>

000000000000b1f0 <__modti3>:
    b1f0:	d503245f 	bti	c
    b1f4:	d2800004 	mov	x4, #0x0                   	// #0
    b1f8:	b6f80081 	tbz	x1, #63, b208 <__modti3+0x18>
    b1fc:	eb0003e0 	negs	x0, x0
    b200:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b204:	da0103e1 	ngc	x1, x1
    b208:	f100007f 	cmp	x3, #0x0
    b20c:	5400128b 	b.lt	b45c <__modti3+0x26c>  // b.tstop
    b210:	aa0003e7 	mov	x7, x0
    b214:	aa0103e6 	mov	x6, x1
    b218:	540004e1 	b.ne	b2b4 <__modti3+0xc4>  // b.any
    b21c:	eb02003f 	cmp	x1, x2
    b220:	54000dc2 	b.cs	b3d8 <__modti3+0x1e8>  // b.hs, b.nlast
    b224:	dac01043 	clz	x3, x2
    b228:	aa0303e5 	mov	x5, x3
    b22c:	b40000e3 	cbz	x3, b248 <__modti3+0x58>
    b230:	4b0303e6 	neg	w6, w3
    b234:	9ac32021 	lsl	x1, x1, x3
    b238:	9ac32042 	lsl	x2, x2, x3
    b23c:	9ac62406 	lsr	x6, x0, x6
    b240:	aa0100c6 	orr	x6, x6, x1
    b244:	9ac32007 	lsl	x7, x0, x3
    b248:	d360fc40 	lsr	x0, x2, #32
    b24c:	92407c43 	and	x3, x2, #0xffffffff
    b250:	9ac008c1 	udiv	x1, x6, x0
    b254:	9b009826 	msub	x6, x1, x0, x6
    b258:	9b017c61 	mul	x1, x3, x1
    b25c:	93c780c6 	extr	x6, x6, x7, #32
    b260:	eb06003f 	cmp	x1, x6
    b264:	540000a9 	b.ls	b278 <__modti3+0x88>  // b.plast
    b268:	ab060046 	adds	x6, x2, x6
    b26c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b270:	8b0200c8 	add	x8, x6, x2
    b274:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b278:	cb0100c6 	sub	x6, x6, x1
    b27c:	9ac008c8 	udiv	x8, x6, x0
    b280:	9b009901 	msub	x1, x8, x0, x6
    b284:	aa0703e0 	mov	x0, x7
    b288:	9b087c63 	mul	x3, x3, x8
    b28c:	b3607c20 	bfi	x0, x1, #32, #32
    b290:	eb00007f 	cmp	x3, x0
    b294:	54001088 	b.hi	b4a4 <__modti3+0x2b4>  // b.pmore
    b298:	cb030000 	sub	x0, x0, x3
    b29c:	9ac52400 	lsr	x0, x0, x5
    b2a0:	d2800001 	mov	x1, #0x0                   	// #0
    b2a4:	b4000064 	cbz	x4, b2b0 <__modti3+0xc0>
    b2a8:	eb0003e0 	negs	x0, x0
    b2ac:	da0103e1 	ngc	x1, x1
    b2b0:	d65f03c0 	ret
    b2b4:	dac01066 	clz	x6, x3
    b2b8:	eb03003f 	cmp	x1, x3
    b2bc:	54ffff43 	b.cc	b2a4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b2c0:	93407cc5 	sxtw	x5, w6
    b2c4:	d2800808 	mov	x8, #0x40                  	// #64
    b2c8:	cb050108 	sub	x8, x8, x5
    b2cc:	9ac62063 	lsl	x3, x3, x6
    b2d0:	9ac62025 	lsl	x5, x1, x6
    b2d4:	9ac82447 	lsr	x7, x2, x8
    b2d8:	aa0300e7 	orr	x7, x7, x3
    b2dc:	9ac82423 	lsr	x3, x1, x8
    b2e0:	92407cec 	and	x12, x7, #0xffffffff
    b2e4:	d360fcea 	lsr	x10, x7, #32
    b2e8:	9ac82401 	lsr	x1, x0, x8
    b2ec:	aa050021 	orr	x1, x1, x5
    b2f0:	9ac62042 	lsl	x2, x2, x6
    b2f4:	9ac62000 	lsl	x0, x0, x6
    b2f8:	9aca086b 	udiv	x11, x3, x10
    b2fc:	9b0a8d63 	msub	x3, x11, x10, x3
    b300:	aa0b03e5 	mov	x5, x11
    b304:	9b0b7d89 	mul	x9, x12, x11
    b308:	93c18063 	extr	x3, x3, x1, #32
    b30c:	eb03013f 	cmp	x9, x3
    b310:	540000a9 	b.ls	b324 <__modti3+0x134>  // b.plast
    b314:	ab0300e3 	adds	x3, x7, x3
    b318:	d1000565 	sub	x5, x11, #0x1
    b31c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b320:	54001168 	b.hi	b54c <__modti3+0x35c>  // b.pmore
    b324:	cb090063 	sub	x3, x3, x9
    b328:	9aca086b 	udiv	x11, x3, x10
    b32c:	9b0a8d6a 	msub	x10, x11, x10, x3
    b330:	aa0b03e9 	mov	x9, x11
    b334:	9b0b7d8c 	mul	x12, x12, x11
    b338:	b3607d41 	bfi	x1, x10, #32, #32
    b33c:	eb01019f 	cmp	x12, x1
    b340:	540000a9 	b.ls	b354 <__modti3+0x164>  // b.plast
    b344:	ab0100e1 	adds	x1, x7, x1
    b348:	d1000569 	sub	x9, x11, #0x1
    b34c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b350:	54000f88 	b.hi	b540 <__modti3+0x350>  // b.pmore
    b354:	aa058123 	orr	x3, x9, x5, lsl #32
    b358:	92407c4b 	and	x11, x2, #0xffffffff
    b35c:	2a0903e9 	mov	w9, w9
    b360:	d360fc4a 	lsr	x10, x2, #32
    b364:	d360fc63 	lsr	x3, x3, #32
    b368:	cb0c0021 	sub	x1, x1, x12
    b36c:	aa0a03ec 	mov	x12, x10
    b370:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b374:	9b0b7d25 	mul	x5, x9, x11
    b378:	9b0b7c6b 	mul	x11, x3, x11
    b37c:	9b0a2d29 	madd	x9, x9, x10, x11
    b380:	92407caa 	and	x10, x5, #0xffffffff
    b384:	9b0c7c63 	mul	x3, x3, x12
    b388:	8b458125 	add	x5, x9, x5, lsr #32
    b38c:	8b0d0069 	add	x9, x3, x13
    b390:	eb05017f 	cmp	x11, x5
    b394:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b398:	8b058149 	add	x9, x10, x5, lsl #32
    b39c:	8b458063 	add	x3, x3, x5, lsr #32
    b3a0:	eb03003f 	cmp	x1, x3
    b3a4:	54000063 	b.cc	b3b0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b3a8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b3ac:	54000082 	b.cs	b3bc <__modti3+0x1cc>  // b.hs, b.nlast
    b3b0:	eb020129 	subs	x9, x9, x2
    b3b4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b3b8:	cb070063 	sub	x3, x3, x7
    b3bc:	eb090000 	subs	x0, x0, x9
    b3c0:	da030021 	sbc	x1, x1, x3
    b3c4:	9ac62400 	lsr	x0, x0, x6
    b3c8:	9ac82028 	lsl	x8, x1, x8
    b3cc:	aa000100 	orr	x0, x8, x0
    b3d0:	9ac62421 	lsr	x1, x1, x6
    b3d4:	17ffffb4 	b	b2a4 <__modti3+0xb4>
    b3d8:	b5000062 	cbnz	x2, b3e4 <__modti3+0x1f4>
    b3dc:	d2800023 	mov	x3, #0x1                   	// #1
    b3e0:	9ac20862 	udiv	x2, x3, x2
    b3e4:	dac01048 	clz	x8, x2
    b3e8:	aa0803e5 	mov	x5, x8
    b3ec:	b5000668 	cbnz	x8, b4b8 <__modti3+0x2c8>
    b3f0:	cb020020 	sub	x0, x1, x2
    b3f4:	d360fc49 	lsr	x9, x2, #32
    b3f8:	92407c4a 	and	x10, x2, #0xffffffff
    b3fc:	9ac90801 	udiv	x1, x0, x9
    b400:	9b098020 	msub	x0, x1, x9, x0
    b404:	9b0a7c21 	mul	x1, x1, x10
    b408:	93c78000 	extr	x0, x0, x7, #32
    b40c:	eb00003f 	cmp	x1, x0
    b410:	540000a9 	b.ls	b424 <__modti3+0x234>  // b.plast
    b414:	ab000040 	adds	x0, x2, x0
    b418:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b41c:	8b020003 	add	x3, x0, x2
    b420:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b424:	cb010001 	sub	x1, x0, x1
    b428:	9ac90820 	udiv	x0, x1, x9
    b42c:	9b098403 	msub	x3, x0, x9, x1
    b430:	aa0703e1 	mov	x1, x7
    b434:	9b0a7c00 	mul	x0, x0, x10
    b438:	b3607c61 	bfi	x1, x3, #32, #32
    b43c:	eb01001f 	cmp	x0, x1
    b440:	540000a9 	b.ls	b454 <__modti3+0x264>  // b.plast
    b444:	ab010041 	adds	x1, x2, x1
    b448:	8b020022 	add	x2, x1, x2
    b44c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b450:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b454:	cb000020 	sub	x0, x1, x0
    b458:	17ffff91 	b	b29c <__modti3+0xac>
    b45c:	eb0203e5 	negs	x5, x2
    b460:	aa0003e7 	mov	x7, x0
    b464:	da0303e8 	ngc	x8, x3
    b468:	aa0503e2 	mov	x2, x5
    b46c:	aa0803e3 	mov	x3, x8
    b470:	aa0103e6 	mov	x6, x1
    b474:	b4ffed48 	cbz	x8, b21c <__modti3+0x2c>
    b478:	eb01011f 	cmp	x8, x1
    b47c:	54fff148 	b.hi	b2a4 <__modti3+0xb4>  // b.pmore
    b480:	dac01109 	clz	x9, x8
    b484:	2a0903e6 	mov	w6, w9
    b488:	b5fff1c9 	cbnz	x9, b2c0 <__modti3+0xd0>
    b48c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b490:	54000068 	b.hi	b49c <__modti3+0x2ac>  // b.pmore
    b494:	eb050007 	subs	x7, x0, x5
    b498:	da080021 	sbc	x1, x1, x8
    b49c:	aa0703e0 	mov	x0, x7
    b4a0:	17ffff81 	b	b2a4 <__modti3+0xb4>
    b4a4:	ab000040 	adds	x0, x2, x0
    b4a8:	8b020002 	add	x2, x0, x2
    b4ac:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b4b0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b4b4:	17ffff79 	b	b298 <__modti3+0xa8>
    b4b8:	9ac82042 	lsl	x2, x2, x8
    b4bc:	d2800803 	mov	x3, #0x40                  	// #64
    b4c0:	cb080063 	sub	x3, x3, x8
    b4c4:	d360fc49 	lsr	x9, x2, #32
    b4c8:	9ac82027 	lsl	x7, x1, x8
    b4cc:	92407c4a 	and	x10, x2, #0xffffffff
    b4d0:	9ac32426 	lsr	x6, x1, x3
    b4d4:	9ac32403 	lsr	x3, x0, x3
    b4d8:	aa070063 	orr	x3, x3, x7
    b4dc:	9ac908c1 	udiv	x1, x6, x9
    b4e0:	9ac82007 	lsl	x7, x0, x8
    b4e4:	9b099820 	msub	x0, x1, x9, x6
    b4e8:	9b017d41 	mul	x1, x10, x1
    b4ec:	93c38000 	extr	x0, x0, x3, #32
    b4f0:	eb00003f 	cmp	x1, x0
    b4f4:	540000a9 	b.ls	b508 <__modti3+0x318>  // b.plast
    b4f8:	ab000040 	adds	x0, x2, x0
    b4fc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b500:	8b020006 	add	x6, x0, x2
    b504:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b508:	cb010000 	sub	x0, x0, x1
    b50c:	9ac90801 	udiv	x1, x0, x9
    b510:	9b098026 	msub	x6, x1, x9, x0
    b514:	aa0303e0 	mov	x0, x3
    b518:	9b017d41 	mul	x1, x10, x1
    b51c:	b3607cc0 	bfi	x0, x6, #32, #32
    b520:	eb00003f 	cmp	x1, x0
    b524:	540000a9 	b.ls	b538 <__modti3+0x348>  // b.plast
    b528:	ab000040 	adds	x0, x2, x0
    b52c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b530:	8b020003 	add	x3, x0, x2
    b534:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b538:	cb010000 	sub	x0, x0, x1
    b53c:	17ffffb0 	b	b3fc <__modti3+0x20c>
    b540:	d1000969 	sub	x9, x11, #0x2
    b544:	8b070021 	add	x1, x1, x7
    b548:	17ffff83 	b	b354 <__modti3+0x164>
    b54c:	d1000965 	sub	x5, x11, #0x2
    b550:	8b070063 	add	x3, x3, x7
    b554:	17ffff74 	b	b324 <__modti3+0x134>
    b558:	d503201f 	nop
    b55c:	d503201f 	nop

000000000000b560 <atexit>:
    b560:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b564:	b00000a2 	adrp	x2, 20000 <__data_start>
    b568:	d2800001 	mov	x1, #0x0                   	// #0
    b56c:	910003fd 	mov	x29, sp
    b570:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b574:	f9400442 	ldr	x2, [x2, #8]
    b578:	17ffdc82 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b57c <_fini>:
    b57c:	d503201f 	nop
    b580:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b584:	910003fd 	mov	x29, sp
    b588:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b58c:	d65f03c0 	ret
