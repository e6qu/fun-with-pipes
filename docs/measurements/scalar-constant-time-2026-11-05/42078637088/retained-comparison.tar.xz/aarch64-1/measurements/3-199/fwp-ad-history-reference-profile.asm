
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-199/fwp-ad-history-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <__divti3+0x70>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	912820a5 	add	x5, x5, #0xa08
    2a20:	b0000044 	adrp	x4, b000 <__divti3+0x70>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	91284084 	add	x4, x4, #0xa10
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	9400034c 	bl	3780 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91018261 	add	x1, x19, #0x60
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10540>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9006820 	str	x0, [x1, #208]
    2aac:	94000395 	bl	3900 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <__divti3+0x70>
    2ab4:	913d6000 	add	x0, x0, #0xf58
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0x6d0>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91248042 	add	x2, x2, #0x920
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91018273 	add	x19, x19, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943fa60 	ldr	w0, [x19, #1016]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff4c 	bl	2900 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	b0000040 	adrp	x0, b000 <__divti3+0x70>
    2bfc:	913da000 	add	x0, x0, #0xf68
    2c00:	940002e0 	bl	3780 <fwp_trap>
    2c04:	97ffff03 	bl	2810 <__stack_chk_fail@plt>
    2c08:	d0000040 	adrp	x0, c000 <_IO_stdin_used+0x950>
    2c0c:	91002000 	add	x0, x0, #0x8
    2c10:	940002dc 	bl	3780 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffeea 	bl	27c0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	b0000040 	adrp	x0, b000 <__divti3+0x70>
    2c24:	913f8000 	add	x0, x0, #0xfe0
    2c28:	940002d6 	bl	3780 <fwp_trap>
    2c2c:	b0000040 	adrp	x0, b000 <__divti3+0x70>
    2c30:	913ec000 	add	x0, x0, #0xfb0
    2c34:	940002d3 	bl	3780 <fwp_trap>
    2c38:	b0000040 	adrp	x0, b000 <__divti3+0x70>
    2c3c:	913e2000 	add	x0, x0, #0xf88
    2c40:	940002d0 	bl	3780 <fwp_trap>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0x950>
    2e34:	91190021 	add	x1, x1, #0x640
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0x950>
    30d8:	91188021 	add	x1, x1, #0x620
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	90000040 	adrp	x0, b000 <__divti3+0x70>
    3110:	911ae000 	add	x0, x0, #0x6b8
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    3144:	911982a1 	add	x1, x21, #0x660
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9a0>
    3158:	912940a5 	add	x5, x5, #0xa50
    315c:	911982a1 	add	x1, x21, #0x660
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911982b7 	add	x23, x21, #0x660
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911982b5 	add	x21, x21, #0x660
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911982b5 	add	x21, x21, #0x660
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9a0>
    32e8:	912920a5 	add	x5, x5, #0xa48
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	90000042 	adrp	x2, b000 <__divti3+0x70>
    331c:	911b4042 	add	x2, x2, #0x6d0
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	90000042 	adrp	x2, b000 <__divti3+0x70>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	911ca042 	add	x2, x2, #0x728
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	90000059 	adrp	x25, b000 <__divti3+0x70>
    33a8:	9000005a 	adrp	x26, b000 <__divti3+0x70>
    33ac:	911e2339 	add	x25, x25, #0x788
    33b0:	911bc35a 	add	x26, x26, #0x6f0
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	9000005b 	adrp	x27, b000 <__divti3+0x70>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	911be377 	add	x23, x27, #0x6f8
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	90000040 	adrp	x0, b000 <__divti3+0x70>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	911f2000 	add	x0, x0, #0x7c8
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.9+0xfb80>
    3474:	b0000165 	adrp	x5, 30000 <alt.9+0xfb80>
    3478:	b0000162 	adrp	x2, 30000 <alt.9+0xfb80>
    347c:	90000043 	adrp	x3, b000 <__divti3+0x70>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	90000055 	adrp	x21, b000 <__divti3+0x70>
    3488:	f9424024 	ldr	x4, [x1, #1152]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94244a5 	ldr	x5, [x5, #1160]
    3494:	91120033 	add	x19, x1, #0x480
    3498:	f9424846 	ldr	x6, [x2, #1168]
    349c:	911bc063 	add	x3, x3, #0x6f0
    34a0:	911f82b5 	add	x21, x21, #0x7e0
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	90000040 	adrp	x0, b000 <__divti3+0x70>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	91208000 	add	x0, x0, #0x820
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	90000040 	adrp	x0, b000 <__divti3+0x70>
    352c:	911c0000 	add	x0, x0, #0x700
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	90000040 	adrp	x0, b000 <__divti3+0x70>
    35ec:	911ae000 	add	x0, x0, #0x6b8
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	90000041 	adrp	x1, b000 <__divti3+0x70>
    3730:	aa1303e0 	mov	x0, x19
    3734:	9120a021 	add	x1, x1, #0x828
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	90000041 	adrp	x1, b000 <__divti3+0x70>
    3744:	aa1303e0 	mov	x0, x19
    3748:	9120c021 	add	x1, x1, #0x830
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	90000041 	adrp	x1, b000 <__divti3+0x70>
    3760:	9120e021 	add	x1, x1, #0x838
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_trap>:
    3780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3784:	d53bd041 	mrs	x1, tpidr_el0
    3788:	91400021 	add	x1, x1, #0x0, lsl #12
    378c:	91004021 	add	x1, x1, #0x10
    3790:	910003fd 	mov	x29, sp
    3794:	a90153f3 	stp	x19, x20, [sp, #16]
    3798:	aa0003f3 	mov	x19, x0
    379c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    37a0:	f947ea94 	ldr	x20, [x20, #4048]
    37a4:	f90013f5 	str	x21, [sp, #32]
    37a8:	f9400035 	ldr	x21, [x1]
    37ac:	97fffe12 	bl	2ff4 <fwp_flush>
    37b0:	f9400280 	ldr	x0, [x20]
    37b4:	90000042 	adrp	x2, b000 <__divti3+0x70>
    37b8:	aa1303e3 	mov	x3, x19
    37bc:	91210042 	add	x2, x2, #0x840
    37c0:	52800041 	mov	w1, #0x2                   	// #2
    37c4:	97fffc2f 	bl	2880 <__fprintf_chk@plt>
    37c8:	b40000b5 	cbz	x21, 37dc <fwp_trap+0x5c>
    37cc:	f9400280 	ldr	x0, [x20]
    37d0:	97fffc5c 	bl	2940 <fflush@plt>
    37d4:	52800ca0 	mov	w0, #0x65                  	// #101
    37d8:	97fffc6a 	bl	2980 <_Exit@plt>
    37dc:	52800ca0 	mov	w0, #0x65                  	// #101
    37e0:	97fffbb8 	bl	26c0 <exit@plt>

00000000000037e4 <fwp_closure_drop_push>:
    37e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    37e8:	910003fd 	mov	x29, sp
    37ec:	a90153f3 	stp	x19, x20, [sp, #16]
    37f0:	aa0003f3 	mov	x19, x0
    37f4:	a9408014 	ldp	x20, x0, [x0, #8]
    37f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    37fc:	aa0103f5 	mov	x21, x1
    3800:	a90363f7 	stp	x23, x24, [sp, #48]
    3804:	eb00029f 	cmp	x20, x0
    3808:	54000160 	b.eq	3834 <fwp_closure_drop_push+0x50>  // b.none
    380c:	f9400276 	ldr	x22, [x19]
    3810:	d37df297 	lsl	x23, x20, #3
    3814:	91000694 	add	x20, x20, #0x1
    3818:	f9000674 	str	x20, [x19, #8]
    381c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3820:	f8376ad5 	str	x21, [x22, x23]
    3824:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3828:	a94363f7 	ldp	x23, x24, [sp, #48]
    382c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3830:	d65f03c0 	ret
    3834:	a9046bf9 	stp	x25, x26, [sp, #64]
    3838:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    383c:	eb00029f 	cmp	x20, x0
    3840:	54000568 	b.hi	38ec <fwp_closure_drop_push+0x108>  // b.pmore
    3844:	d37cee99 	lsl	x25, x20, #4
    3848:	d37ffa9a 	lsl	x26, x20, #1
    384c:	aa1903e0 	mov	x0, x25
    3850:	97fffbd8 	bl	27b0 <malloc@plt>
    3854:	aa0003f6 	mov	x22, x0
    3858:	b4000320 	cbz	x0, 38bc <fwp_closure_drop_push+0xd8>
    385c:	aa1303f8 	mov	x24, x19
    3860:	aa1903e3 	mov	x3, x25
    3864:	d37df297 	lsl	x23, x20, #3
    3868:	aa1703e2 	mov	x2, x23
    386c:	f8418719 	ldr	x25, [x24], #24
    3870:	aa1903e1 	mov	x1, x25
    3874:	97fffbbb 	bl	2760 <__memcpy_chk@plt>
    3878:	eb18033f 	cmp	x25, x24
    387c:	540000a0 	b.eq	3890 <fwp_closure_drop_push+0xac>  // b.none
    3880:	aa1903e0 	mov	x0, x25
    3884:	97fffc13 	bl	28d0 <free@plt>
    3888:	f9400674 	ldr	x20, [x19, #8]
    388c:	d37df297 	lsl	x23, x20, #3
    3890:	91000694 	add	x20, x20, #0x1
    3894:	f9000276 	str	x22, [x19]
    3898:	f9000a7a 	str	x26, [x19, #16]
    389c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    38a0:	f9000674 	str	x20, [x19, #8]
    38a4:	f8376ad5 	str	x21, [x22, x23]
    38a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    38b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b8:	d65f03c0 	ret
    38bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    38c0:	f947e863 	ldr	x3, [x3, #4048]
    38c4:	d2800262 	mov	x2, #0x13                  	// #19
    38c8:	d2800021 	mov	x1, #0x1                   	// #1
    38cc:	90000040 	adrp	x0, b000 <__divti3+0x70>
    38d0:	911ae000 	add	x0, x0, #0x6b8
    38d4:	f9400063 	ldr	x3, [x3]
    38d8:	97fffc0e 	bl	2910 <fwrite@plt>
    38dc:	d2800000 	mov	x0, #0x0                   	// #0
    38e0:	97fffc18 	bl	2940 <fflush@plt>
    38e4:	52800cc0 	mov	w0, #0x66                  	// #102
    38e8:	97fffc26 	bl	2980 <_Exit@plt>
    38ec:	90000040 	adrp	x0, b000 <__divti3+0x70>
    38f0:	91214000 	add	x0, x0, #0x850
    38f4:	97ffffa3 	bl	3780 <fwp_trap>
    38f8:	d503201f 	nop
    38fc:	d503201f 	nop

0000000000003900 <fwp_now_ns>:
    3900:	d100c3ff 	sub	sp, sp, #0x30
    3904:	52800020 	mov	w0, #0x1                   	// #1
    3908:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    390c:	f947f442 	ldr	x2, [x2, #4072]
    3910:	910023e1 	add	x1, sp, #0x8
    3914:	a9027bfd 	stp	x29, x30, [sp, #32]
    3918:	910083fd 	add	x29, sp, #0x20
    391c:	f9400043 	ldr	x3, [x2]
    3920:	f9000fe3 	str	x3, [sp, #24]
    3924:	d2800003 	mov	x3, #0x0                   	// #0
    3928:	97fffb86 	bl	2740 <clock_gettime@plt>
    392c:	350002c0 	cbnz	w0, 3984 <fwp_now_ns+0x84>
    3930:	a9408be1 	ldp	x1, x2, [sp, #8]
    3934:	d2994003 	mov	x3, #0xca00                	// #51712
    3938:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    393c:	9b037c20 	mul	x0, x1, x3
    3940:	9b437c21 	smulh	x1, x1, x3
    3944:	ab020000 	adds	x0, x0, x2
    3948:	937ffc42 	asr	x2, x2, #63
    394c:	9a020021 	adc	x1, x1, x2
    3950:	f100001f 	cmp	x0, #0x0
    3954:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3958:	b50001e1 	cbnz	x1, 3994 <fwp_now_ns+0x94>
    395c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3960:	f947f421 	ldr	x1, [x1, #4072]
    3964:	f9400fe3 	ldr	x3, [sp, #24]
    3968:	f9400022 	ldr	x2, [x1]
    396c:	eb020063 	subs	x3, x3, x2
    3970:	d2800002 	mov	x2, #0x0                   	// #0
    3974:	540000e1 	b.ne	3990 <fwp_now_ns+0x90>  // b.any
    3978:	a9427bfd 	ldp	x29, x30, [sp, #32]
    397c:	9100c3ff 	add	sp, sp, #0x30
    3980:	d65f03c0 	ret
    3984:	90000040 	adrp	x0, b000 <__divti3+0x70>
    3988:	9121c000 	add	x0, x0, #0x870
    398c:	97ffff7d 	bl	3780 <fwp_trap>
    3990:	97fffba0 	bl	2810 <__stack_chk_fail@plt>
    3994:	90000040 	adrp	x0, b000 <__divti3+0x70>
    3998:	91224000 	add	x0, x0, #0x890
    399c:	97ffff79 	bl	3780 <fwp_trap>

00000000000039a0 <fwp_closure_drop.part.0>:
    39a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39a4:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0x950>
    39a8:	910003fd 	mov	x29, sp
    39ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    39b0:	f947f463 	ldr	x3, [x3, #4072]
    39b4:	a90153f3 	stp	x19, x20, [sp, #16]
    39b8:	d10883ff 	sub	sp, sp, #0x220
    39bc:	910003e2 	mov	x2, sp
    39c0:	d53bd053 	mrs	x19, tpidr_el0
    39c4:	910063f4 	add	x20, sp, #0x18
    39c8:	3dc19420 	ldr	q0, [x1, #1616]
    39cc:	91400264 	add	x4, x19, #0x0, lsl #12
    39d0:	91004084 	add	x4, x4, #0x10
    39d4:	aa0003e1 	mov	x1, x0
    39d8:	aa0203e0 	mov	x0, x2
    39dc:	f9400062 	ldr	x2, [x3]
    39e0:	f9010fe2 	str	x2, [sp, #536]
    39e4:	d2800002 	mov	x2, #0x0                   	// #0
    39e8:	f90003f4 	str	x20, [sp]
    39ec:	f9000080 	str	x0, [x4]
    39f0:	3c8083e0 	stur	q0, [sp, #8]
    39f4:	97ffff7c 	bl	37e4 <fwp_closure_drop_push>
    39f8:	f94007e0 	ldr	x0, [sp, #8]
    39fc:	b4000280 	cbz	x0, 3a4c <fwp_closure_drop.part.0+0xac>
    3a00:	f90123f5 	str	x21, [sp, #576]
    3a04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a08:	910182b5 	add	x21, x21, #0x60
    3a0c:	d503201f 	nop
    3a10:	f94003e1 	ldr	x1, [sp]
    3a14:	d1000400 	sub	x0, x0, #0x1
    3a18:	f90007e0 	str	x0, [sp, #8]
    3a1c:	f9406aa2 	ldr	x2, [x21, #208]
    3a20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3a24:	b9400001 	ldr	w1, [x0]
    3a28:	8b011441 	add	x1, x2, x1, lsl #5
    3a2c:	f9400c21 	ldr	x1, [x1, #24]
    3a30:	b4000321 	cbz	x1, 3a94 <fwp_closure_drop.part.0+0xf4>
    3a34:	f9400422 	ldr	x2, [x1, #8]
    3a38:	52800001 	mov	w1, #0x0                   	// #0
    3a3c:	d63f0040 	blr	x2
    3a40:	f94007e0 	ldr	x0, [sp, #8]
    3a44:	b5fffe60 	cbnz	x0, 3a10 <fwp_closure_drop.part.0+0x70>
    3a48:	f94123f5 	ldr	x21, [sp, #576]
    3a4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3a50:	91004273 	add	x19, x19, #0x10
    3a54:	f94003e0 	ldr	x0, [sp]
    3a58:	f900027f 	str	xzr, [x19]
    3a5c:	eb14001f 	cmp	x0, x20
    3a60:	54000040 	b.eq	3a68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3a64:	97fffb9b 	bl	28d0 <free@plt>
    3a68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3a6c:	f947f400 	ldr	x0, [x0, #4072]
    3a70:	f9410fe2 	ldr	x2, [sp, #536]
    3a74:	f9400001 	ldr	x1, [x0]
    3a78:	eb010042 	subs	x2, x2, x1
    3a7c:	d2800001 	mov	x1, #0x0                   	// #0
    3a80:	54000101 	b.ne	3aa0 <fwp_closure_drop.part.0+0x100>  // b.any
    3a84:	910883ff 	add	sp, sp, #0x220
    3a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a90:	d65f03c0 	ret
    3a94:	90000040 	adrp	x0, b000 <__divti3+0x70>
    3a98:	9122e000 	add	x0, x0, #0x8b8
    3a9c:	97ffff39 	bl	3780 <fwp_trap>
    3aa0:	f90123f5 	str	x21, [sp, #576]
    3aa4:	97fffb5b 	bl	2810 <__stack_chk_fail@plt>
    3aa8:	d503201f 	nop
    3aac:	d503201f 	nop

0000000000003ab0 <fwp_tape_of>:
    3ab0:	92403c02 	and	x2, x0, #0xffff
    3ab4:	b4000262 	cbz	x2, 3b00 <fwp_tape_of+0x50>
    3ab8:	b00000e3 	adrp	x3, 20000 <__data_start>
    3abc:	91018063 	add	x3, x3, #0x60
    3ac0:	9350fc01 	asr	x1, x0, #16
    3ac4:	d1000440 	sub	x0, x2, #0x1
    3ac8:	f9406c62 	ldr	x2, [x3, #216]
    3acc:	eb00005f 	cmp	x2, x0
    3ad0:	5400018d 	b.le	3b00 <fwp_tape_of+0x50>
    3ad4:	8b000402 	add	x2, x0, x0, lsl #1
    3ad8:	f9404463 	ldr	x3, [x3, #136]
    3adc:	8b020802 	add	x2, x0, x2, lsl #2
    3ae0:	d37df042 	lsl	x2, x2, #3
    3ae4:	8b020060 	add	x0, x3, x2
    3ae8:	b9400404 	ldr	w4, [x0, #4]
    3aec:	340000a4 	cbz	w4, 3b00 <fwp_tape_of+0x50>
    3af0:	b8626862 	ldr	w2, [x3, x2]
    3af4:	6b01005f 	cmp	w2, w1
    3af8:	54000041 	b.ne	3b00 <fwp_tape_of+0x50>  // b.any
    3afc:	d65f03c0 	ret
    3b00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b04:	90000040 	adrp	x0, b000 <__divti3+0x70>
    3b08:	9123a000 	add	x0, x0, #0x8e8
    3b0c:	910003fd 	mov	x29, sp
    3b10:	97ffff1c 	bl	3780 <fwp_trap>

0000000000003b14 <fwp_format_g.constprop.0>:
    3b14:	d10483ff 	sub	sp, sp, #0x120
    3b18:	90000044 	adrp	x4, b000 <__divti3+0x70>
    3b1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    3b20:	f947f442 	ldr	x2, [x2, #4072]
    3b24:	9124e084 	add	x4, x4, #0x938
    3b28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3b2c:	9102c3fd 	add	x29, sp, #0xb0
    3b30:	d2800803 	mov	x3, #0x40                  	// #64
    3b34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3b38:	93407c38 	sxtw	x24, w1
    3b3c:	aa0303e1 	mov	x1, x3
    3b40:	fd008be8 	str	d8, [sp, #272]
    3b44:	1e604008 	fmov	d8, d0
    3b48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3b4c:	910083f4 	add	x20, sp, #0x20
    3b50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3b54:	aa0003f5 	mov	x21, x0
    3b58:	a91073fb 	stp	x27, x28, [sp, #256]
    3b5c:	5100071c 	sub	w28, w24, #0x1
    3b60:	2a1c03e5 	mov	w5, w28
    3b64:	f9400040 	ldr	x0, [x2]
    3b68:	f90057e0 	str	x0, [sp, #168]
    3b6c:	d2800000 	mov	x0, #0x0                   	// #0
    3b70:	52800042 	mov	w2, #0x2                   	// #2
    3b74:	aa1403e0 	mov	x0, x20
    3b78:	97fffb02 	bl	2780 <__snprintf_chk@plt>
    3b7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3b80:	aa1403e0 	mov	x0, x20
    3b84:	97fffb5b 	bl	28f0 <strchr@plt>
    3b88:	aa0003f3 	mov	x19, x0
    3b8c:	52800142 	mov	w2, #0xa                   	// #10
    3b90:	91000400 	add	x0, x0, #0x1
    3b94:	d2800001 	mov	x1, #0x0                   	// #0
    3b98:	97fffb46 	bl	28b0 <strtol@plt>
    3b9c:	aa0003f7 	mov	x23, x0
    3ba0:	11001400 	add	w0, w0, #0x5
    3ba4:	7100541f 	cmp	w0, #0x15
    3ba8:	54000d88 	b.hi	3d58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3bac:	4b170385 	sub	w5, w28, w23
    3bb0:	710000bf 	cmp	w5, #0x0
    3bb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3bb8:	54000ba0 	b.eq	3d2c <fwp_format_g.constprop.0+0x218>  // b.none
    3bbc:	394083e0 	ldrb	w0, [sp, #32]
    3bc0:	cb180273 	sub	x19, x19, x24
    3bc4:	91000673 	add	x19, x19, #0x1
    3bc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bcc:	7100b41f 	cmp	w0, #0x2d
    3bd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3bd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3bd8:	cb010266 	sub	x6, x19, x1
    3bdc:	d10004da 	sub	x26, x6, #0x1
    3be0:	540018c0 	b.eq	3ef8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d280091b 	mov	x27, #0x48                  	// #72
    3bec:	aa1903e7 	mov	x7, x25
    3bf0:	91000423 	add	x3, x1, #0x1
    3bf4:	91011cc6 	add	x6, x6, #0x47
    3bf8:	910004f6 	add	x22, x7, #0x1
    3bfc:	37f81017 	tbnz	w23, #31, 3dfc <fwp_format_g.constprop.0+0x2e8>
    3c00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c04:	93407ef7 	sxtw	x23, w23
    3c08:	390000e4 	strb	w4, [x7]
    3c0c:	aa1303e1 	mov	x1, x19
    3c10:	aa1703e2 	mov	x2, x23
    3c14:	aa1603e0 	mov	x0, x22
    3c18:	b9000be5 	str	w5, [sp, #8]
    3c1c:	cb170374 	sub	x20, x27, x23
    3c20:	a9011be3 	stp	x3, x6, [sp, #16]
    3c24:	97fffa8f 	bl	2660 <memcpy@plt>
    3c28:	d1000694 	sub	x20, x20, #0x1
    3c2c:	f9400be3 	ldr	x3, [sp, #16]
    3c30:	8b1702d6 	add	x22, x22, x23
    3c34:	aa1603e0 	mov	x0, x22
    3c38:	aa1a03e2 	mov	x2, x26
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	aa1403e3 	mov	x3, x20
    3c44:	97fffac7 	bl	2760 <__memcpy_chk@plt>
    3c48:	8b1a02d6 	add	x22, x22, x26
    3c4c:	f9400fe6 	ldr	x6, [sp, #24]
    3c50:	d2800900 	mov	x0, #0x48                  	// #72
    3c54:	b9400be5 	ldr	w5, [sp, #8]
    3c58:	8b170261 	add	x1, x19, x23
    3c5c:	cb1400c3 	sub	x3, x6, x20
    3c60:	cb060294 	sub	x20, x20, x6
    3c64:	f101207f 	cmp	x3, #0x48
    3c68:	93407cb8 	sxtw	x24, w5
    3c6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c70:	aa1803e2 	mov	x2, x24
    3c74:	8b1802d3 	add	x19, x22, x24
    3c78:	8b140063 	add	x3, x3, x20
    3c7c:	aa1603e0 	mov	x0, x22
    3c80:	97fffab8 	bl	2760 <__memcpy_chk@plt>
    3c84:	cb190273 	sub	x19, x19, x25
    3c88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3c8c:	eb00027f 	cmp	x19, x0
    3c90:	aa1903e1 	mov	x1, x25
    3c94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3c98:	aa1503e0 	mov	x0, x21
    3c9c:	aa1303e2 	mov	x2, x19
    3ca0:	97fffa70 	bl	2660 <memcpy@plt>
    3ca4:	38336abf 	strb	wzr, [x21, x19]
    3ca8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3cac:	aa1503e0 	mov	x0, x21
    3cb0:	97fffa7c 	bl	26a0 <strlen@plt>
    3cb4:	aa0003f3 	mov	x19, x0
    3cb8:	528005c1 	mov	w1, #0x2e                  	// #46
    3cbc:	aa1503e0 	mov	x0, x21
    3cc0:	97fffb0c 	bl	28f0 <strchr@plt>
    3cc4:	b4000160 	cbz	x0, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3cc8:	b4000153 	cbz	x19, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ccc:	d503201f 	nop
    3cd0:	aa1303e1 	mov	x1, x19
    3cd4:	d1000673 	sub	x19, x19, #0x1
    3cd8:	38736aa0 	ldrb	w0, [x21, x19]
    3cdc:	7100c01f 	cmp	w0, #0x30
    3ce0:	54001001 	b.ne	3ee0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ce4:	38336abf 	strb	wzr, [x21, x19]
    3ce8:	b5ffff53 	cbnz	x19, 3cd0 <fwp_format_g.constprop.0+0x1bc>
    3cec:	d503201f 	nop
    3cf0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3cf4:	f947f400 	ldr	x0, [x0, #4072]
    3cf8:	f94057e2 	ldr	x2, [sp, #168]
    3cfc:	f9400001 	ldr	x1, [x0]
    3d00:	eb010042 	subs	x2, x2, x1
    3d04:	d2800001 	mov	x1, #0x0                   	// #0
    3d08:	54001061 	b.ne	3f14 <fwp_format_g.constprop.0+0x400>  // b.any
    3d0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3d20:	fd408be8 	ldr	d8, [sp, #272]
    3d24:	910483ff 	add	sp, sp, #0x120
    3d28:	d65f03c0 	ret
    3d2c:	1e604100 	fmov	d0, d8
    3d30:	710000bf 	cmp	w5, #0x0
    3d34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3d38:	aa1503e0 	mov	x0, x21
    3d3c:	90000044 	adrp	x4, b000 <__divti3+0x70>
    3d40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3d44:	91254084 	add	x4, x4, #0x950
    3d48:	52800042 	mov	w2, #0x2                   	// #2
    3d4c:	d2803201 	mov	x1, #0x190                 	// #400
    3d50:	97fffa8c 	bl	2780 <__snprintf_chk@plt>
    3d54:	17ffffd6 	b	3cac <fwp_format_g.constprop.0+0x198>
    3d58:	cb140273 	sub	x19, x19, x20
    3d5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d60:	910183f9 	add	x25, sp, #0x60
    3d64:	aa1303e2 	mov	x2, x19
    3d68:	aa1403e1 	mov	x1, x20
    3d6c:	aa1903e0 	mov	x0, x25
    3d70:	d2800803 	mov	x3, #0x40                  	// #64
    3d74:	97fffa7b 	bl	2760 <__memcpy_chk@plt>
    3d78:	38336b3f 	strb	wzr, [x25, x19]
    3d7c:	aa1903e0 	mov	x0, x25
    3d80:	528005c1 	mov	w1, #0x2e                  	// #46
    3d84:	97fffadb 	bl	28f0 <strchr@plt>
    3d88:	b40001c0 	cbz	x0, 3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d8c:	b50000b3 	cbnz	x19, 3da0 <fwp_format_g.constprop.0+0x28c>
    3d90:	1400000c 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d94:	381ff01f 	sturb	wzr, [x0, #-1]
    3d98:	f1000673 	subs	x19, x19, #0x1
    3d9c:	54000120 	b.eq	3dc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3da0:	8b130320 	add	x0, x25, x19
    3da4:	385ff001 	ldurb	w1, [x0, #-1]
    3da8:	7100c03f 	cmp	w1, #0x30
    3dac:	54ffff40 	b.eq	3d94 <fwp_format_g.constprop.0+0x280>  // b.none
    3db0:	d1000673 	sub	x19, x19, #0x1
    3db4:	38736b20 	ldrb	w0, [x25, x19]
    3db8:	7100b81f 	cmp	w0, #0x2e
    3dbc:	54000a80 	b.eq	3f0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3dc0:	710002ff 	cmp	w23, #0x0
    3dc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3dc8:	aa1903e5 	mov	x5, x25
    3dcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3dd0:	aa1503e0 	mov	x0, x21
    3dd4:	52800566 	mov	w6, #0x2b                  	// #43
    3dd8:	90000044 	adrp	x4, b000 <__divti3+0x70>
    3ddc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3de0:	91250084 	add	x4, x4, #0x940
    3de4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3de8:	52800042 	mov	w2, #0x2                   	// #2
    3dec:	d2803201 	mov	x1, #0x190                 	// #400
    3df0:	97fffa64 	bl	2780 <__snprintf_chk@plt>
    3df4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3df8:	17ffffbe 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3dfc:	52800605 	mov	w5, #0x30                  	// #48
    3e00:	390000e5 	strb	w5, [x7]
    3e04:	d100077b 	sub	x27, x27, #0x1
    3e08:	aa0303e1 	mov	x1, x3
    3e0c:	aa1603e0 	mov	x0, x22
    3e10:	aa1b03e3 	mov	x3, x27
    3e14:	aa1a03e2 	mov	x2, x26
    3e18:	f90007e6 	str	x6, [sp, #8]
    3e1c:	b90013e4 	str	w4, [sp, #16]
    3e20:	8b1a02d6 	add	x22, x22, x26
    3e24:	b9001be5 	str	w5, [sp, #24]
    3e28:	97fffa4e 	bl	2760 <__memcpy_chk@plt>
    3e2c:	f94007e6 	ldr	x6, [sp, #8]
    3e30:	2a3703e7 	mvn	w7, w23
    3e34:	b94013e4 	ldr	w4, [sp, #16]
    3e38:	cb1b00c1 	sub	x1, x6, x27
    3e3c:	cb06037b 	sub	x27, x27, x6
    3e40:	f101203f 	cmp	x1, #0x48
    3e44:	d2800906 	mov	x6, #0x48                  	// #72
    3e48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3e4c:	8b1b0023 	add	x3, x1, x27
    3e50:	310006ff 	cmn	w23, #0x1
    3e54:	54000220 	b.eq	3e98 <fwp_format_g.constprop.0+0x384>  // b.none
    3e58:	b9401be5 	ldr	w5, [sp, #24]
    3e5c:	d2800001 	mov	x1, #0x0                   	// #0
    3e60:	f101207f 	cmp	x3, #0x48
    3e64:	d1000462 	sub	x2, x3, #0x1
    3e68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3e6c:	38216ac5 	strb	w5, [x22, x1]
    3e70:	cb030003 	sub	x3, x0, x3
    3e74:	91000421 	add	x1, x1, #0x1
    3e78:	91000463 	add	x3, x3, #0x1
    3e7c:	eb00007f 	cmp	x3, x0
    3e80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3e84:	cb000063 	sub	x3, x3, x0
    3e88:	8b020063 	add	x3, x3, x2
    3e8c:	6b0100ff 	cmp	w7, w1
    3e90:	54fffe8c 	b.gt	3e60 <fwp_format_g.constprop.0+0x34c>
    3e94:	8b2742d6 	add	x22, x22, w7, uxtw
    3e98:	f101207f 	cmp	x3, #0x48
    3e9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ea0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ea4:	aa1603e0 	mov	x0, x22
    3ea8:	cb0300a1 	sub	x1, x5, x3
    3eac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3eb0:	91000421 	add	x1, x1, #0x1
    3eb4:	d1000463 	sub	x3, x3, #0x1
    3eb8:	eb05003f 	cmp	x1, x5
    3ebc:	38001402 	strb	w2, [x0], #1
    3ec0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3ec4:	93407f82 	sxtw	x2, w28
    3ec8:	cb050025 	sub	x5, x1, x5
    3ecc:	aa1303e1 	mov	x1, x19
    3ed0:	8b0300a3 	add	x3, x5, x3
    3ed4:	8b1802d3 	add	x19, x22, x24
    3ed8:	97fffa22 	bl	2760 <__memcpy_chk@plt>
    3edc:	17ffff6a 	b	3c84 <fwp_format_g.constprop.0+0x170>
    3ee0:	d1000421 	sub	x1, x1, #0x1
    3ee4:	38616aa0 	ldrb	w0, [x21, x1]
    3ee8:	7100b81f 	cmp	w0, #0x2e
    3eec:	54fff021 	b.ne	3cf0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ef0:	38216abf 	strb	wzr, [x21, x1]
    3ef4:	17ffff7f 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ef8:	910187e7 	add	x7, sp, #0x61
    3efc:	910183f9 	add	x25, sp, #0x60
    3f00:	d28008fb 	mov	x27, #0x47                  	// #71
    3f04:	390183e0 	strb	w0, [sp, #96]
    3f08:	17ffff3a 	b	3bf0 <fwp_format_g.constprop.0+0xdc>
    3f0c:	38336b3f 	strb	wzr, [x25, x19]
    3f10:	17ffffac 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3f14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f18:	97fffa3e 	bl	2810 <__stack_chk_fail@plt>
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_heap_report>:
    3f20:	d105c3ff 	sub	sp, sp, #0x170
    3f24:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xb80>
    3f28:	91198042 	add	x2, x2, #0x660
    3f2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3f30:	f947e821 	ldr	x1, [x1, #4048]
    3f34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3f38:	910443fd 	add	x29, sp, #0x110
    3f3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3f40:	f947f400 	ldr	x0, [x0, #4072]
    3f44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3f48:	a91463f7 	stp	x23, x24, [sp, #320]
    3f4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3f50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3f54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3f58:	fd4a2049 	ldr	d9, [x2, #5184]
    3f5c:	f9400036 	ldr	x22, [x1]
    3f60:	f9400001 	ldr	x1, [x0]
    3f64:	f90087e1 	str	x1, [sp, #264]
    3f68:	d2800001 	mov	x1, #0x0                   	// #0
    3f6c:	f949e459 	ldr	x25, [x2, #5064]
    3f70:	90000041 	adrp	x1, b000 <__divti3+0x70>
    3f74:	f94a1057 	ldr	x23, [x2, #5152]
    3f78:	90000040 	adrp	x0, b000 <__divti3+0x70>
    3f7c:	f94a1458 	ldr	x24, [x2, #5160]
    3f80:	91256021 	add	x1, x1, #0x958
    3f84:	91258000 	add	x0, x0, #0x960
    3f88:	97fffa06 	bl	27a0 <fopen@plt>
    3f8c:	b4000740 	cbz	x0, 4074 <fwp_heap_report+0x154>
    3f90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3f94:	a91253f3 	stp	x19, x20, [sp, #288]
    3f98:	aa0003f4 	mov	x20, x0
    3f9c:	910023f3 	add	x19, sp, #0x8
    3fa0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3fa4:	72aae915 	movk	w21, #0x5748, lsl #16
    3fa8:	aa1403e2 	mov	x2, x20
    3fac:	aa1303e0 	mov	x0, x19
    3fb0:	52802001 	mov	w1, #0x100                 	// #256
    3fb4:	97fffa83 	bl	29c0 <fgets@plt>
    3fb8:	b4000280 	cbz	x0, 4008 <fwp_heap_report+0xe8>
    3fbc:	b9400261 	ldr	w1, [x19]
    3fc0:	6b15003f 	cmp	w1, w21
    3fc4:	54ffff21 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fc8:	39401260 	ldrb	w0, [x19, #4]
    3fcc:	7101341f 	cmp	w0, #0x4d
    3fd0:	54fffec1 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fd4:	394037e0 	ldrb	w0, [sp, #13]
    3fd8:	7100e81f 	cmp	w0, #0x3a
    3fdc:	54fffe61 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fe0:	52800142 	mov	w2, #0xa                   	// #10
    3fe4:	d2800001 	mov	x1, #0x0                   	// #0
    3fe8:	91003be0 	add	x0, sp, #0xe
    3fec:	97fffa31 	bl	28b0 <strtol@plt>
    3ff0:	aa1403e2 	mov	x2, x20
    3ff4:	aa0003fa 	mov	x26, x0
    3ff8:	52802001 	mov	w1, #0x100                 	// #256
    3ffc:	aa1303e0 	mov	x0, x19
    4000:	97fffa70 	bl	29c0 <fgets@plt>
    4004:	b5fffdc0 	cbnz	x0, 3fbc <fwp_heap_report+0x9c>
    4008:	aa1403e0 	mov	x0, x20
    400c:	97fff9e1 	bl	2790 <fclose@plt>
    4010:	a95253f3 	ldp	x19, x20, [sp, #288]
    4014:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4018:	f947f400 	ldr	x0, [x0, #4072]
    401c:	f94087e2 	ldr	x2, [sp, #264]
    4020:	f9400001 	ldr	x1, [x0]
    4024:	eb010042 	subs	x2, x2, x1
    4028:	d2800001 	mov	x1, #0x0                   	// #0
    402c:	54000281 	b.ne	407c <fwp_heap_report+0x15c>  // b.any
    4030:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4034:	aa1a03e6 	mov	x6, x26
    4038:	aa1903e5 	mov	x5, x25
    403c:	aa1803e4 	mov	x4, x24
    4040:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4044:	aa1703e3 	mov	x3, x23
    4048:	a95463f7 	ldp	x23, x24, [sp, #320]
    404c:	aa1603e0 	mov	x0, x22
    4050:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4054:	1e604121 	fmov	d1, d9
    4058:	1e604100 	fmov	d0, d8
    405c:	f0000022 	adrp	x2, b000 <__divti3+0x70>
    4060:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4064:	91260042 	add	x2, x2, #0x980
    4068:	9105c3ff 	add	sp, sp, #0x170
    406c:	52800041 	mov	w1, #0x2                   	// #2
    4070:	17fffa04 	b	2880 <__fprintf_chk@plt>
    4074:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4078:	17ffffe7 	b	4014 <fwp_heap_report+0xf4>
    407c:	a91253f3 	stp	x19, x20, [sp, #288]
    4080:	97fff9e4 	bl	2810 <__stack_chk_fail@plt>

0000000000004084 <fwp_heap_init>:
    4084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4088:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9a0>
    408c:	91158061 	add	x1, x3, #0x560
    4090:	910003fd 	mov	x29, sp
    4094:	a90153f3 	stp	x19, x20, [sp, #16]
    4098:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xb80>
    409c:	91198262 	add	x2, x19, #0x660
    40a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a4:	52800024 	mov	w4, #0x1                   	// #1
    40a8:	52800200 	mov	w0, #0x10                  	// #16
    40ac:	b913a444 	str	w4, [x2, #5028]
    40b0:	b8004420 	str	w0, [x1], #4
    40b4:	11004000 	add	w0, w0, #0x10
    40b8:	7104401f 	cmp	w0, #0x110
    40bc:	54ffffa1 	b.ne	40b0 <fwp_heap_init+0x2c>  // b.any
    40c0:	90000042 	adrp	x2, c000 <_IO_stdin_used+0x950>
    40c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    40c8:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9a0>
    40cc:	91168021 	add	x1, x1, #0x5a0
    40d0:	3dc19843 	ldr	q3, [x2, #1632]
    40d4:	d2800000 	mov	x0, #0x0                   	// #0
    40d8:	4e040401 	dup	v1.4s, v0.s[0]
    40dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    40e0:	0f215400 	shl	v0.2s, v0.2s, #1
    40e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    40e8:	3ca06821 	str	q1, [x1, x0]
    40ec:	91004000 	add	x0, x0, #0x10
    40f0:	f101801f 	cmp	x0, #0x60
    40f4:	54ffff21 	b.ne	40d8 <fwp_heap_init+0x54>  // b.any
    40f8:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9a0>
    40fc:	91158063 	add	x3, x3, #0x560
    4100:	91180084 	add	x4, x4, #0x600
    4104:	91198266 	add	x6, x19, #0x660
    4108:	d2800002 	mov	x2, #0x0                   	// #0
    410c:	d2800000 	mov	x0, #0x0                   	// #0
    4110:	d2880205 	mov	x5, #0x4010                	// #16400
    4114:	d503201f 	nop
    4118:	910f0001 	add	x1, x0, #0x3c0
    411c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4120:	eb02003f 	cmp	x1, x2
    4124:	540000a2 	b.cs	4138 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4128:	91000400 	add	x0, x0, #0x1
    412c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4130:	eb02003f 	cmp	x1, x2
    4134:	54ffffa3 	b.cc	4128 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4138:	91004042 	add	x2, x2, #0x10
    413c:	38001480 	strb	w0, [x4], #1
    4140:	eb05005f 	cmp	x2, x5
    4144:	54fffea1 	b.ne	4118 <fwp_heap_init+0x94>  // b.any
    4148:	528000b5 	mov	w21, #0x5                   	// #5
    414c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4150:	14000004 	b	4160 <fwp_heap_init+0xdc>
    4154:	d342fe94 	lsr	x20, x20, #2
    4158:	710006b5 	subs	w21, w21, #0x1
    415c:	54000720 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    4160:	91404296 	add	x22, x20, #0x10, lsl #12
    4164:	d2800005 	mov	x5, #0x0                   	// #0
    4168:	aa1603e1 	mov	x1, x22
    416c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4170:	52880443 	mov	w3, #0x4022                	// #16418
    4174:	52800002 	mov	w2, #0x0                   	// #0
    4178:	d2800000 	mov	x0, #0x0                   	// #0
    417c:	97fff9c9 	bl	28a0 <mmap@plt>
    4180:	aa0003e6 	mov	x6, x0
    4184:	b100041f 	cmn	x0, #0x1
    4188:	54fffe60 	b.eq	4154 <fwp_heap_init+0xd0>  // b.none
    418c:	b40005a0 	cbz	x0, 4240 <fwp_heap_init+0x1bc>
    4190:	d350fe94 	lsr	x20, x20, #16
    4194:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4198:	8b0000c7 	add	x7, x6, x0
    419c:	91198275 	add	x21, x19, #0x660
    41a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    41a4:	8b140a81 	add	x1, x20, x20, lsl #2
    41a8:	d2800005 	mov	x5, #0x0                   	// #0
    41ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    41b0:	d37df021 	lsl	x1, x1, #3
    41b4:	52880443 	mov	w3, #0x4022                	// #16418
    41b8:	52800002 	mov	w2, #0x0                   	// #0
    41bc:	d2800000 	mov	x0, #0x0                   	// #0
    41c0:	f909daa7 	str	x7, [x21, #5040]
    41c4:	f909dea6 	str	x6, [x21, #5048]
    41c8:	f909e2b6 	str	x22, [x21, #5056]
    41cc:	f909eab4 	str	x20, [x21, #5072]
    41d0:	f90a02a1 	str	x1, [x21, #5120]
    41d4:	97fff9b3 	bl	28a0 <mmap@plt>
    41d8:	aa0003e1 	mov	x1, x0
    41dc:	b100041f 	cmn	x0, #0x1
    41e0:	54000300 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    41e4:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    41e8:	9128c000 	add	x0, x0, #0xa30
    41ec:	f909fea1 	str	x1, [x21, #5112]
    41f0:	97fff9ec 	bl	29a0 <getenv@plt>
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	aa0003e1 	mov	x1, x0
    41fc:	b40000e0 	cbz	x0, 4218 <fwp_heap_init+0x194>
    4200:	39400000 	ldrb	w0, [x0]
    4204:	340000a0 	cbz	w0, 4218 <fwp_heap_init+0x194>
    4208:	7100c000 	subs	w0, w0, #0x30
    420c:	54000120 	b.eq	4230 <fwp_heap_init+0x1ac>  // b.none
    4210:	7100001f 	cmp	w0, #0x0
    4214:	1a9f07e2 	cset	w2, ne	// ne = any
    4218:	91198273 	add	x19, x19, #0x660
    421c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4220:	b913aa62 	str	w2, [x19, #5032]
    4224:	a94153f3 	ldp	x19, x20, [sp, #16]
    4228:	a8c37bfd 	ldp	x29, x30, [sp], #48
    422c:	d65f03c0 	ret
    4230:	39400420 	ldrb	w0, [x1, #1]
    4234:	7100001f 	cmp	w0, #0x0
    4238:	1a9f07e2 	cset	w2, ne	// ne = any
    423c:	17fffff7 	b	4218 <fwp_heap_init+0x194>
    4240:	97fffbac 	bl	30f0 <fwp_heap_oom>

0000000000004244 <caf61>:
    4244:	900000e2 	adrp	x2, 20000 <__data_start>
    4248:	91018041 	add	x1, x2, #0x60
    424c:	b940e020 	ldr	w0, [x1, #224]
    4250:	34000060 	cbz	w0, 425c <caf61+0x18>
    4254:	f9407420 	ldr	x0, [x1, #232]
    4258:	d65f03c0 	ret
    425c:	b940f020 	ldr	w0, [x1, #240]
    4260:	340000e0 	cbz	w0, 427c <caf61+0x38>
    4264:	f9407c20 	ldr	x0, [x1, #248]
    4268:	91018042 	add	x2, x2, #0x60
    426c:	52800021 	mov	w1, #0x1                   	// #1
    4270:	b900e041 	str	w1, [x2, #224]
    4274:	f9007440 	str	x0, [x2, #232]
    4278:	d65f03c0 	ret
    427c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4280:	52800024 	mov	w4, #0x1                   	// #1
    4284:	aa0303e0 	mov	x0, x3
    4288:	b900f024 	str	w4, [x1, #240]
    428c:	f9007c23 	str	x3, [x1, #248]
    4290:	17fffff6 	b	4268 <caf61+0x24>

0000000000004294 <fwp_wake_io>:
    4294:	900000e9 	adrp	x9, 20000 <__data_start>
    4298:	91018122 	add	x2, x9, #0x60
    429c:	f9400001 	ldr	x1, [x0]
    42a0:	5280000a 	mov	w10, #0x0                   	// #0
    42a4:	f9406046 	ldr	x6, [x2, #192]
    42a8:	52800008 	mov	w8, #0x0                   	// #0
    42ac:	4f000400 	movi	v0.4s, #0x0
    42b0:	52800027 	mov	w7, #0x1                   	// #1
    42b4:	aa0103e2 	mov	x2, x1
    42b8:	b4000321 	cbz	x1, 431c <fwp_wake_io+0x88>
    42bc:	f9408c25 	ldr	x5, [x1, #280]
    42c0:	39015c27 	strb	w7, [x1, #87]
    42c4:	b4000165 	cbz	x5, 42f0 <fwp_wake_io+0x5c>
    42c8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42cc:	b4000364 	cbz	x4, 4338 <fwp_wake_io+0xa4>
    42d0:	f9009483 	str	x3, [x4, #296]
    42d4:	f9409423 	ldr	x3, [x1, #296]
    42d8:	b4000043 	cbz	x3, 42e0 <fwp_wake_io+0x4c>
    42dc:	f9009064 	str	x4, [x3, #288]
    42e0:	91080023 	add	x3, x1, #0x200
    42e4:	f900943f 	str	xzr, [x1, #296]
    42e8:	3c918060 	stur	q0, [x3, #-232]
    42ec:	f9400001 	ldr	x1, [x0]
    42f0:	f9402843 	ldr	x3, [x2, #80]
    42f4:	f2001c7f 	tst	x3, #0xff000000ff
    42f8:	54fffde1 	b.ne	42b4 <fwp_wake_io+0x20>  // b.any
    42fc:	39015047 	strb	w7, [x2, #84]
    4300:	f900805f 	str	xzr, [x2, #256]
    4304:	b40001e6 	cbz	x6, 4340 <fwp_wake_io+0xac>
    4308:	f90080c2 	str	x2, [x6, #256]
    430c:	aa0203e6 	mov	x6, x2
    4310:	52800028 	mov	w8, #0x1                   	// #1
    4314:	aa0103e2 	mov	x2, x1
    4318:	b5fffd21 	cbnz	x1, 42bc <fwp_wake_io+0x28>
    431c:	3400006a 	cbz	w10, 4328 <fwp_wake_io+0x94>
    4320:	91018120 	add	x0, x9, #0x60
    4324:	f900640b 	str	x11, [x0, #200]
    4328:	34000068 	cbz	w8, 4334 <fwp_wake_io+0xa0>
    432c:	91018129 	add	x9, x9, #0x60
    4330:	f9006126 	str	x6, [x9, #192]
    4334:	d65f03c0 	ret
    4338:	f90000a3 	str	x3, [x5]
    433c:	17ffffe7 	b	42d8 <fwp_wake_io+0x44>
    4340:	aa0203eb 	mov	x11, x2
    4344:	5280002a 	mov	w10, #0x1                   	// #1
    4348:	17fffff1 	b	430c <fwp_wake_io+0x78>
    434c:	d503201f 	nop

0000000000004350 <ad_raw_free.part.0>:
    4350:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fb80>
    4354:	d2800001 	mov	x1, #0x0                   	// #0
    4358:	91120082 	add	x2, x4, #0x480
    435c:	14000005 	b	4370 <ad_raw_free.part.0+0x20>
    4360:	91000421 	add	x1, x1, #0x1
    4364:	91006042 	add	x2, x2, #0x18
    4368:	f140043f 	cmp	x1, #0x1, lsl #12
    436c:	54000220 	b.eq	43b0 <ad_raw_free.part.0+0x60>  // b.none
    4370:	f9400043 	ldr	x3, [x2]
    4374:	eb03001f 	cmp	x0, x3
    4378:	54ffff41 	b.ne	4360 <ad_raw_free.part.0+0x10>  // b.any
    437c:	8b010421 	add	x1, x1, x1, lsl #1
    4380:	91120084 	add	x4, x4, #0x480
    4384:	900000e2 	adrp	x2, 20000 <__data_start>
    4388:	91018042 	add	x2, x2, #0x60
    438c:	8b010c81 	add	x1, x4, x1, lsl #3
    4390:	b9401024 	ldr	w4, [x1, #16]
    4394:	f9400425 	ldr	x5, [x1, #8]
    4398:	a9007c3f 	stp	xzr, xzr, [x1]
    439c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    43a0:	f900083f 	str	xzr, [x1, #16]
    43a4:	cb050061 	sub	x1, x3, x5
    43a8:	f8247841 	str	x1, [x2, x4, lsl #3]
    43ac:	17fff949 	b	28d0 <free@plt>
    43b0:	f100001f 	cmp	x0, #0x0
    43b4:	f0000021 	adrp	x1, b000 <__divti3+0x70>
    43b8:	91296021 	add	x1, x1, #0xa58
    43bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    43c0:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    43c4:	91290000 	add	x0, x0, #0xa40
    43c8:	910003fd 	mov	x29, sp
    43cc:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    43d0:	97fffbcc 	bl	3300 <ad_raw_fail>

00000000000043d4 <fwp_tape_buffers_dispose>:
    43d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	f9000bf3 	str	x19, [sp, #16]
    43e0:	aa0003f3 	mov	x19, x0
    43e4:	f9400000 	ldr	x0, [x0]
    43e8:	b4000040 	cbz	x0, 43f0 <fwp_tape_buffers_dispose+0x1c>
    43ec:	97ffffd9 	bl	4350 <ad_raw_free.part.0>
    43f0:	f9400a60 	ldr	x0, [x19, #16]
    43f4:	b4000040 	cbz	x0, 43fc <fwp_tape_buffers_dispose+0x28>
    43f8:	97ffffd6 	bl	4350 <ad_raw_free.part.0>
    43fc:	f9401260 	ldr	x0, [x19, #32]
    4400:	b4000040 	cbz	x0, 4408 <fwp_tape_buffers_dispose+0x34>
    4404:	97ffffd3 	bl	4350 <ad_raw_free.part.0>
    4408:	4f000400 	movi	v0.4s, #0x0
    440c:	f9001a7f 	str	xzr, [x19, #48]
    4410:	ad000260 	stp	q0, q0, [x19]
    4414:	3d800a60 	str	q0, [x19, #32]
    4418:	f9400bf3 	ldr	x19, [sp, #16]
    441c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4420:	d65f03c0 	ret

0000000000004424 <ad_raw_realloc>:
    4424:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4428:	910003fd 	mov	x29, sp
    442c:	a90153f3 	stp	x19, x20, [sp, #16]
    4430:	f90013f5 	str	x21, [sp, #32]
    4434:	b40005a1 	cbz	x1, 44e8 <ad_raw_realloc+0xc4>
    4438:	aa0103f4 	mov	x20, x1
    443c:	2a0203f5 	mov	w21, w2
    4440:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fb80>
    4444:	d2800004 	mov	x4, #0x0                   	// #0
    4448:	91120025 	add	x5, x1, #0x480
    444c:	14000005 	b	4460 <ad_raw_realloc+0x3c>
    4450:	91000484 	add	x4, x4, #0x1
    4454:	910060a5 	add	x5, x5, #0x18
    4458:	f140049f 	cmp	x4, #0x1, lsl #12
    445c:	54000320 	b.eq	44c0 <ad_raw_realloc+0x9c>  // b.none
    4460:	f94000a6 	ldr	x6, [x5]
    4464:	eb06001f 	cmp	x0, x6
    4468:	54ffff41 	b.ne	4450 <ad_raw_realloc+0x2c>  // b.any
    446c:	8b040484 	add	x4, x4, x4, lsl #1
    4470:	91120021 	add	x1, x1, #0x480
    4474:	8b040c33 	add	x19, x1, x4, lsl #3
    4478:	b4000080 	cbz	x0, 4488 <ad_raw_realloc+0x64>
    447c:	b9401261 	ldr	w1, [x19, #16]
    4480:	6b15003f 	cmp	w1, w21
    4484:	540002c1 	b.ne	44dc <ad_raw_realloc+0xb8>  // b.any
    4488:	aa1403e1 	mov	x1, x20
    448c:	97fff8dd 	bl	2800 <realloc@plt>
    4490:	aa0003ed 	mov	x13, x0
    4494:	b40000c0 	cbz	x0, 44ac <ad_raw_realloc+0x88>
    4498:	2a1503e3 	mov	w3, w21
    449c:	aa1403e2 	mov	x2, x20
    44a0:	aa1303e0 	mov	x0, x19
    44a4:	aa0d03e1 	mov	x1, x13
    44a8:	97fffa9a 	bl	2f10 <ad_raw_record>
    44ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b0:	aa0d03e0 	mov	x0, x13
    44b4:	f94013f5 	ldr	x21, [sp, #32]
    44b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44bc:	d65f03c0 	ret
    44c0:	f100001f 	cmp	x0, #0x0
    44c4:	f0000021 	adrp	x1, b000 <__divti3+0x70>
    44c8:	91296021 	add	x1, x1, #0xa58
    44cc:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    44d0:	91290000 	add	x0, x0, #0xa40
    44d4:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    44d8:	97fffb8a 	bl	3300 <ad_raw_fail>
    44dc:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    44e0:	912a6000 	add	x0, x0, #0xa98
    44e4:	97fffb87 	bl	3300 <ad_raw_fail>
    44e8:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    44ec:	9129e000 	add	x0, x0, #0xa78
    44f0:	97fffb84 	bl	3300 <ad_raw_fail>

00000000000044f4 <fwp_tape_buffers_release>:
    44f4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44f8:	910003fd 	mov	x29, sp
    44fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4500:	aa0003f4 	mov	x20, x0
    4504:	f9401400 	ldr	x0, [x0, #40]
    4508:	a9025bf5 	stp	x21, x22, [sp, #32]
    450c:	b7f80560 	tbnz	x0, #63, 45b8 <fwp_tape_buffers_release+0xc4>
    4510:	f9401a93 	ldr	x19, [x20, #48]
    4514:	b7f80533 	tbnz	x19, #63, 45b8 <fwp_tape_buffers_release+0xc4>
    4518:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    451c:	eb01001f 	cmp	x0, x1
    4520:	540004c8 	b.hi	45b8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4524:	8b000400 	add	x0, x0, x0, lsl #1
    4528:	d2a00101 	mov	x1, #0x80000               	// #524288
    452c:	d37df000 	lsl	x0, x0, #3
    4530:	cb000021 	sub	x1, x1, x0
    4534:	eb410e7f 	cmp	x19, x1, lsr #3
    4538:	54000408 	b.hi	45b8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    453c:	8b130c13 	add	x19, x0, x19, lsl #3
    4540:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    4544:	912ac000 	add	x0, x0, #0xab0
    4548:	97fff916 	bl	29a0 <getenv@plt>
    454c:	b4000080 	cbz	x0, 455c <fwp_tape_buffers_release+0x68>
    4550:	39400001 	ldrb	w1, [x0]
    4554:	7100c03f 	cmp	w1, #0x30
    4558:	54000880 	b.eq	4668 <fwp_tape_buffers_release+0x174>  // b.none
    455c:	d1000661 	sub	x1, x19, #0x1
    4560:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4564:	eb00003f 	cmp	x1, x0
    4568:	54000328 	b.hi	45cc <fwp_tape_buffers_release+0xd8>  // b.pmore
    456c:	900000f5 	adrp	x21, 20000 <__data_start>
    4570:	f9001bf7 	str	x23, [sp, #48]
    4574:	910182b7 	add	x23, x21, #0x60
    4578:	910402f6 	add	x22, x23, #0x100
    457c:	aa1603e0 	mov	x0, x22
    4580:	97ffff95 	bl	43d4 <fwp_tape_buffers_dispose>
    4584:	ad400a81 	ldp	q1, q2, [x20]
    4588:	f9009ef3 	str	x19, [x23, #312]
    458c:	4f000400 	movi	v0.4s, #0x0
    4590:	ad000ac1 	stp	q1, q2, [x22]
    4594:	3dc00a81 	ldr	q1, [x20, #32]
    4598:	3d800ac1 	str	q1, [x22, #32]
    459c:	f9401a80 	ldr	x0, [x20, #48]
    45a0:	f9001ac0 	str	x0, [x22, #48]
    45a4:	f9001a9f 	str	xzr, [x20, #48]
    45a8:	ad000280 	stp	q0, q0, [x20]
    45ac:	3d800a80 	str	q0, [x20, #32]
    45b0:	f9401bf7 	ldr	x23, [sp, #48]
    45b4:	1400000b 	b	45e0 <fwp_tape_buffers_release+0xec>
    45b8:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    45bc:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    45c0:	912ac000 	add	x0, x0, #0xab0
    45c4:	97fff8f7 	bl	29a0 <getenv@plt>
    45c8:	b5fffc40 	cbnz	x0, 4550 <fwp_tape_buffers_release+0x5c>
    45cc:	aa1403e0 	mov	x0, x20
    45d0:	97ffff81 	bl	43d4 <fwp_tape_buffers_dispose>
    45d4:	900000f5 	adrp	x21, 20000 <__data_start>
    45d8:	910182a0 	add	x0, x21, #0x60
    45dc:	f9409c13 	ldr	x19, [x0, #312]
    45e0:	910182a2 	add	x2, x21, #0x60
    45e4:	f940a044 	ldr	x4, [x2, #320]
    45e8:	a9400c45 	ldp	x5, x3, [x2]
    45ec:	8b040481 	add	x1, x4, x4, lsl #1
    45f0:	f9400840 	ldr	x0, [x2, #16]
    45f4:	8b010881 	add	x1, x4, x1, lsl #2
    45f8:	f9400c44 	ldr	x4, [x2, #24]
    45fc:	8b0300a3 	add	x3, x5, x3
    4600:	d37df021 	lsl	x1, x1, #3
    4604:	8b040000 	add	x0, x0, x4
    4608:	8b030000 	add	x0, x0, x3
    460c:	eb05003f 	cmp	x1, x5
    4610:	54000321 	b.ne	4674 <fwp_tape_buffers_release+0x180>  // b.any
    4614:	8b130023 	add	x3, x1, x19
    4618:	eb00007f 	cmp	x3, x0
    461c:	540002c8 	b.hi	4674 <fwp_tape_buffers_release+0x180>  // b.pmore
    4620:	f9405c43 	ldr	x3, [x2, #184]
    4624:	f140087f 	cmp	x3, #0x2, lsl #12
    4628:	540002e0 	b.eq	4684 <fwp_tape_buffers_release+0x190>  // b.none
    462c:	8b030464 	add	x4, x3, x3, lsl #1
    4630:	90000165 	adrp	x5, 30000 <alt.9+0xfb80>
    4634:	911200a5 	add	x5, x5, #0x480
    4638:	cb010000 	sub	x0, x0, x1
    463c:	d37df084 	lsl	x4, x4, #3
    4640:	cb130000 	sub	x0, x0, x19
    4644:	8b0400a6 	add	x6, x5, x4
    4648:	91000463 	add	x3, x3, #0x1
    464c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4650:	f82468a1 	str	x1, [x5, x4]
    4654:	a90080d3 	stp	x19, x0, [x6, #8]
    4658:	f9005c43 	str	x3, [x2, #184]
    465c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4660:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4664:	d65f03c0 	ret
    4668:	39400400 	ldrb	w0, [x0, #1]
    466c:	34fffb00 	cbz	w0, 45cc <fwp_tape_buffers_release+0xd8>
    4670:	17ffffbb 	b	455c <fwp_tape_buffers_release+0x68>
    4674:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    4678:	912b2000 	add	x0, x0, #0xac8
    467c:	f9001bf7 	str	x23, [sp, #48]
    4680:	97fffb20 	bl	3300 <ad_raw_fail>
    4684:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    4688:	912be000 	add	x0, x0, #0xaf8
    468c:	f9001bf7 	str	x23, [sp, #48]
    4690:	97fffb1c 	bl	3300 <ad_raw_fail>

0000000000004694 <fwp_poll_events>:
    4694:	d10103ff 	sub	sp, sp, #0x40
    4698:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    469c:	f947f400 	ldr	x0, [x0, #4072]
    46a0:	a9027bfd 	stp	x29, x30, [sp, #32]
    46a4:	910083fd 	add	x29, sp, #0x20
    46a8:	a90353f3 	stp	x19, x20, [sp, #48]
    46ac:	900000f4 	adrp	x20, 20000 <__data_start>
    46b0:	f9400001 	ldr	x1, [x0]
    46b4:	f9000fe1 	str	x1, [sp, #24]
    46b8:	d2800001 	mov	x1, #0x0                   	// #0
    46bc:	97fffc91 	bl	3900 <fwp_now_ns>
    46c0:	91018281 	add	x1, x20, #0x60
    46c4:	f940a433 	ldr	x19, [x1, #328]
    46c8:	b4000e73 	cbz	x19, 4894 <fwp_poll_events+0x200>
    46cc:	aa1303e1 	mov	x1, x19
    46d0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    46d4:	14000005 	b	46e8 <fwp_poll_events+0x54>
    46d8:	f9408821 	ldr	x1, [x1, #272]
    46dc:	eb03005f 	cmp	x2, x3
    46e0:	9a83d042 	csel	x2, x2, x3, le
    46e4:	b40000c1 	cbz	x1, 46fc <fwp_poll_events+0x68>
    46e8:	f9403423 	ldr	x3, [x1, #104]
    46ec:	b6ffff62 	tbz	x2, #63, 46d8 <fwp_poll_events+0x44>
    46f0:	f9408821 	ldr	x1, [x1, #272]
    46f4:	aa0303e2 	mov	x2, x3
    46f8:	b5ffff81 	cbnz	x1, 46e8 <fwp_poll_events+0x54>
    46fc:	b7f80cc2 	tbnz	x2, #63, 4894 <fwp_poll_events+0x200>
    4700:	cb000042 	sub	x2, x2, x0
    4704:	f100005f 	cmp	x2, #0x0
    4708:	540005ad 	b.le	47bc <fwp_poll_events+0x128>
    470c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4710:	d2884801 	mov	x1, #0x4240                	// #16960
    4714:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4718:	f2a001e1 	movk	x1, #0xf, lsl #16
    471c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4720:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4724:	f2e86360 	movk	x0, #0x431b, lsl #48
    4728:	9b407c40 	smulh	x0, x2, x0
    472c:	9352fc00 	asr	x0, x0, #18
    4730:	cb82fc00 	sub	x0, x0, x2, asr #63
    4734:	9b018802 	msub	x2, x0, x1, x2
    4738:	f100005f 	cmp	x2, #0x0
    473c:	9a800400 	cinc	x0, x0, ne	// ne = any
    4740:	eb03001f 	cmp	x0, x3
    4744:	540009ec 	b.gt	4880 <fwp_poll_events+0x1ec>
    4748:	340003a0 	cbz	w0, 47bc <fwp_poll_events+0x128>
    474c:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4750:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4754:	72a20c42 	movk	w2, #0x1062, lsl #16
    4758:	9ba27c02 	umull	x2, w0, w2
    475c:	d366fc43 	lsr	x3, x2, #38
    4760:	aa0303e2 	mov	x2, x3
    4764:	1b048063 	msub	w3, w3, w4, w0
    4768:	9b217c63 	smull	x3, w3, w1
    476c:	d2800001 	mov	x1, #0x0                   	// #0
    4770:	910023e0 	add	x0, sp, #0x8
    4774:	a9008fe2 	stp	x2, x3, [sp, #8]
    4778:	97fff85a 	bl	28e0 <nanosleep@plt>
    477c:	91018280 	add	x0, x20, #0x60
    4780:	f940a413 	ldr	x19, [x0, #328]
    4784:	97fffc5f 	bl	3900 <fwp_now_ns>
    4788:	aa0003e6 	mov	x6, x0
    478c:	b50001d3 	cbnz	x19, 47c4 <fwp_poll_events+0x130>
    4790:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4794:	f947f400 	ldr	x0, [x0, #4072]
    4798:	f9400fe2 	ldr	x2, [sp, #24]
    479c:	f9400001 	ldr	x1, [x0]
    47a0:	eb010042 	subs	x2, x2, x1
    47a4:	d2800001 	mov	x1, #0x0                   	// #0
    47a8:	540008c1 	b.ne	48c0 <fwp_poll_events+0x22c>  // b.any
    47ac:	a9427bfd 	ldp	x29, x30, [sp, #32]
    47b0:	a94353f3 	ldp	x19, x20, [sp, #48]
    47b4:	910103ff 	add	sp, sp, #0x40
    47b8:	d65f03c0 	ret
    47bc:	97fffc51 	bl	3900 <fwp_now_ns>
    47c0:	aa0003e6 	mov	x6, x0
    47c4:	4f000400 	movi	v0.4s, #0x0
    47c8:	91018288 	add	x8, x20, #0x60
    47cc:	52800027 	mov	w7, #0x1                   	// #1
    47d0:	f9403661 	ldr	x1, [x19, #104]
    47d4:	aa1303e5 	mov	x5, x19
    47d8:	f9408a73 	ldr	x19, [x19, #272]
    47dc:	eb06003f 	cmp	x1, x6
    47e0:	5400032c 	b.gt	4844 <fwp_poll_events+0x1b0>
    47e4:	394154a0 	ldrb	w0, [x5, #85]
    47e8:	36000120 	tbz	w0, #0, 480c <fwp_poll_events+0x178>
    47ec:	f94084a0 	ldr	x0, [x5, #264]
    47f0:	b40003c0 	cbz	x0, 4868 <fwp_poll_events+0x1d4>
    47f4:	f9008813 	str	x19, [x0, #272]
    47f8:	b4000053 	cbz	x19, 4800 <fwp_poll_events+0x16c>
    47fc:	f9008660 	str	x0, [x19, #264]
    4800:	910800a0 	add	x0, x5, #0x200
    4804:	390154bf 	strb	wzr, [x5, #85]
    4808:	3c908000 	stur	q0, [x0, #-248]
    480c:	f94030a0 	ldr	x0, [x5, #96]
    4810:	390158a7 	strb	w7, [x5, #86]
    4814:	f100001f 	cmp	x0, #0x0
    4818:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    481c:	5400018d 	b.le	484c <fwp_poll_events+0x1b8>
    4820:	f94028a0 	ldr	x0, [x5, #80]
    4824:	f2001c1f 	tst	x0, #0xff000000ff
    4828:	540000e1 	b.ne	4844 <fwp_poll_events+0x1b0>  // b.any
    482c:	f9406100 	ldr	x0, [x8, #192]
    4830:	390150a7 	strb	w7, [x5, #84]
    4834:	f90080bf 	str	xzr, [x5, #256]
    4838:	b40001e0 	cbz	x0, 4874 <fwp_poll_events+0x1e0>
    483c:	f9006105 	str	x5, [x8, #192]
    4840:	f9008005 	str	x5, [x0, #256]
    4844:	b5fffc73 	cbnz	x19, 47d0 <fwp_poll_events+0x13c>
    4848:	17ffffd2 	b	4790 <fwp_poll_events+0xfc>
    484c:	394144a0 	ldrb	w0, [x5, #81]
    4850:	3707fe80 	tbnz	w0, #0, 4820 <fwp_poll_events+0x18c>
    4854:	394140a0 	ldrb	w0, [x5, #80]
    4858:	3707fe40 	tbnz	w0, #0, 4820 <fwp_poll_events+0x18c>
    485c:	aa0503e0 	mov	x0, x5
    4860:	97fffb84 	bl	3670 <fwp_cancel_tree.part.0>
    4864:	17ffffef 	b	4820 <fwp_poll_events+0x18c>
    4868:	91018281 	add	x1, x20, #0x60
    486c:	f900a433 	str	x19, [x1, #328]
    4870:	17ffffe2 	b	47f8 <fwp_poll_events+0x164>
    4874:	f9006105 	str	x5, [x8, #192]
    4878:	f9006505 	str	x5, [x8, #200]
    487c:	17fffff2 	b	4844 <fwp_poll_events+0x1b0>
    4880:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4884:	d2989362 	mov	x2, #0xc49b                	// #50331
    4888:	f2a4d203 	movk	x3, #0x2690, lsl #16
    488c:	f2a00402 	movk	x2, #0x20, lsl #16
    4890:	17ffffb7 	b	476c <fwp_poll_events+0xd8>
    4894:	97fff9d8 	bl	2ff4 <fwp_flush>
    4898:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    489c:	f947e863 	ldr	x3, [x3, #4048]
    48a0:	d2800562 	mov	x2, #0x2b                  	// #43
    48a4:	d2800021 	mov	x1, #0x1                   	// #1
    48a8:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    48ac:	912c6000 	add	x0, x0, #0xb18
    48b0:	f9400063 	ldr	x3, [x3]
    48b4:	97fff817 	bl	2910 <fwrite@plt>
    48b8:	52800ca0 	mov	w0, #0x65                  	// #101
    48bc:	97fff781 	bl	26c0 <exit@plt>
    48c0:	97fff7d4 	bl	2810 <__stack_chk_fail@plt>

00000000000048c4 <fwp_rc_wide_dup>:
    48c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48c8:	910003fd 	mov	x29, sp
    48cc:	a90153f3 	stp	x19, x20, [sp, #16]
    48d0:	aa0003f3 	mov	x19, x0
    48d4:	ca404400 	eor	x0, x0, x0, lsr #17
    48d8:	f90013f5 	str	x21, [sp, #32]
    48dc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    48e0:	ca402400 	eor	x0, x0, x0, lsr #9
    48e4:	911982a2 	add	x2, x21, #0x660
    48e8:	92401c00 	and	x0, x0, #0xff
    48ec:	910a2403 	add	x3, x0, #0x289
    48f0:	8b000c40 	add	x0, x2, x0, lsl #3
    48f4:	8b030c54 	add	x20, x2, x3, lsl #3
    48f8:	f94a2401 	ldr	x1, [x0, #5192]
    48fc:	b50000a1 	cbnz	x1, 4910 <fwp_rc_wide_dup+0x4c>
    4900:	1400002d 	b	49b4 <fwp_rc_wide_dup+0xf0>
    4904:	91004034 	add	x20, x1, #0x10
    4908:	f9400821 	ldr	x1, [x1, #16]
    490c:	b4000241 	cbz	x1, 4954 <fwp_rc_wide_dup+0x90>
    4910:	f9400022 	ldr	x2, [x1]
    4914:	eb02027f 	cmp	x19, x2
    4918:	54ffff61 	b.ne	4904 <fwp_rc_wide_dup+0x40>  // b.any
    491c:	f9400281 	ldr	x1, [x20]
    4920:	39400260 	ldrb	w0, [x19]
    4924:	7103f81f 	cmp	w0, #0xfe
    4928:	54000220 	b.eq	496c <fwp_rc_wide_dup+0xa8>  // b.none
    492c:	b40001a1 	cbz	x1, 4960 <fwp_rc_wide_dup+0x9c>
    4930:	f9400420 	ldr	x0, [x1, #8]
    4934:	b100041f 	cmn	x0, #0x1
    4938:	540004a0 	b.eq	49cc <fwp_rc_wide_dup+0x108>  // b.none
    493c:	91000400 	add	x0, x0, #0x1
    4940:	f9000420 	str	x0, [x1, #8]
    4944:	a94153f3 	ldp	x19, x20, [sp, #16]
    4948:	f94013f5 	ldr	x21, [sp, #32]
    494c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4950:	d65f03c0 	ret
    4954:	39400260 	ldrb	w0, [x19]
    4958:	7103f81f 	cmp	w0, #0xfe
    495c:	540000a0 	b.eq	4970 <fwp_rc_wide_dup+0xac>  // b.none
    4960:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    4964:	912dc000 	add	x0, x0, #0xb70
    4968:	97fffb86 	bl	3780 <fwp_trap>
    496c:	b5000281 	cbnz	x1, 49bc <fwp_rc_wide_dup+0xf8>
    4970:	d2800300 	mov	x0, #0x18                  	// #24
    4974:	97fff78f 	bl	27b0 <malloc@plt>
    4978:	b4000280 	cbz	x0, 49c8 <fwp_rc_wide_dup+0x104>
    497c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4980:	a9000413 	stp	x19, x1, [x0]
    4984:	911982b5 	add	x21, x21, #0x660
    4988:	f900081f 	str	xzr, [x0, #16]
    498c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4990:	f9000280 	str	x0, [x20]
    4994:	39000261 	strb	w1, [x19]
    4998:	f94e26a0 	ldr	x0, [x21, #7240]
    499c:	a94153f3 	ldp	x19, x20, [sp, #16]
    49a0:	91000400 	add	x0, x0, #0x1
    49a4:	f90e26a0 	str	x0, [x21, #7240]
    49a8:	f94013f5 	ldr	x21, [sp, #32]
    49ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49b0:	d65f03c0 	ret
    49b4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    49b8:	17ffffda 	b	4920 <fwp_rc_wide_dup+0x5c>
    49bc:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    49c0:	912d2000 	add	x0, x0, #0xb48
    49c4:	97fffb6f 	bl	3780 <fwp_trap>
    49c8:	97fff9ca 	bl	30f0 <fwp_heap_oom>
    49cc:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    49d0:	912e6000 	add	x0, x0, #0xb98
    49d4:	97fffb6b 	bl	3780 <fwp_trap>
    49d8:	d503201f 	nop
    49dc:	d503201f 	nop

00000000000049e0 <fwp_rc_forget_slot>:
    49e0:	aa0003e1 	mov	x1, x0
    49e4:	39400000 	ldrb	w0, [x0]
    49e8:	7103fc1f 	cmp	w0, #0xff
    49ec:	54000040 	b.eq	49f4 <fwp_rc_forget_slot+0x14>  // b.none
    49f0:	d65f03c0 	ret
    49f4:	ca414420 	eor	x0, x1, x1, lsr #17
    49f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    49fc:	ca402400 	eor	x0, x0, x0, lsr #9
    4a00:	910003fd 	mov	x29, sp
    4a04:	92401c00 	and	x0, x0, #0xff
    4a08:	f9000bf3 	str	x19, [sp, #16]
    4a0c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xb80>
    4a10:	91198262 	add	x2, x19, #0x660
    4a14:	910a2403 	add	x3, x0, #0x289
    4a18:	8b000c40 	add	x0, x2, x0, lsl #3
    4a1c:	8b030c43 	add	x3, x2, x3, lsl #3
    4a20:	f94a2400 	ldr	x0, [x0, #5192]
    4a24:	b50000a0 	cbnz	x0, 4a38 <fwp_rc_forget_slot+0x58>
    4a28:	14000011 	b	4a6c <fwp_rc_forget_slot+0x8c>
    4a2c:	91004003 	add	x3, x0, #0x10
    4a30:	f9400800 	ldr	x0, [x0, #16]
    4a34:	b40001c0 	cbz	x0, 4a6c <fwp_rc_forget_slot+0x8c>
    4a38:	f9400002 	ldr	x2, [x0]
    4a3c:	eb02003f 	cmp	x1, x2
    4a40:	54ffff61 	b.ne	4a2c <fwp_rc_forget_slot+0x4c>  // b.any
    4a44:	f9400801 	ldr	x1, [x0, #16]
    4a48:	91198273 	add	x19, x19, #0x660
    4a4c:	f9000061 	str	x1, [x3]
    4a50:	97fff7a0 	bl	28d0 <free@plt>
    4a54:	f94e2660 	ldr	x0, [x19, #7240]
    4a58:	d1000400 	sub	x0, x0, #0x1
    4a5c:	f90e2660 	str	x0, [x19, #7240]
    4a60:	f9400bf3 	ldr	x19, [sp, #16]
    4a64:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a68:	d65f03c0 	ret
    4a6c:	f0000020 	adrp	x0, b000 <__divti3+0x70>
    4a70:	912dc000 	add	x0, x0, #0xb70
    4a74:	97fffb43 	bl	3780 <fwp_trap>
    4a78:	d503201f 	nop
    4a7c:	d503201f 	nop

0000000000004a80 <fwp_rc_prepare_chunk>:
    4a80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a84:	910003fd 	mov	x29, sp
    4a88:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a8c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xb80>
    4a90:	911982c2 	add	x2, x22, #0x660
    4a94:	b9401c03 	ldr	w3, [x0, #28]
    4a98:	aa0103f5 	mov	x21, x1
    4a9c:	a90153f3 	stp	x19, x20, [sp, #16]
    4aa0:	aa0003f4 	mov	x20, x0
    4aa4:	f94e2440 	ldr	x0, [x2, #7240]
    4aa8:	b4000440 	cbz	x0, 4b30 <fwp_rc_prepare_chunk+0xb0>
    4aac:	d2800013 	mov	x19, #0x0                   	// #0
    4ab0:	35000203 	cbnz	w3, 4af0 <fwp_rc_prepare_chunk+0x70>
    4ab4:	b4000361 	cbz	x1, 4b20 <fwp_rc_prepare_chunk+0xa0>
    4ab8:	f9401280 	ldr	x0, [x20, #32]
    4abc:	97fff785 	bl	28d0 <free@plt>
    4ac0:	aa1503e0 	mov	x0, x21
    4ac4:	d2800021 	mov	x1, #0x1                   	// #1
    4ac8:	97fff74a 	bl	27f0 <calloc@plt>
    4acc:	f9001280 	str	x0, [x20, #32]
    4ad0:	b5000460 	cbnz	x0, 4b5c <fwp_rc_prepare_chunk+0xdc>
    4ad4:	97fff987 	bl	30f0 <fwp_heap_oom>
    4ad8:	97ffffc2 	bl	49e0 <fwp_rc_forget_slot>
    4adc:	91000673 	add	x19, x19, #0x1
    4ae0:	b9401e83 	ldr	w3, [x20, #28]
    4ae4:	eb13007f 	cmp	x3, x19
    4ae8:	54000169 	b.ls	4b14 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4aec:	d503201f 	nop
    4af0:	f9401283 	ldr	x3, [x20, #32]
    4af4:	8b130060 	add	x0, x3, x19
    4af8:	38736863 	ldrb	w3, [x3, x19]
    4afc:	7103fc7f 	cmp	w3, #0xff
    4b00:	54fffec0 	b.eq	4ad8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b04:	b9401e83 	ldr	w3, [x20, #28]
    4b08:	91000673 	add	x19, x19, #0x1
    4b0c:	eb13007f 	cmp	x3, x19
    4b10:	54ffff08 	b.hi	4af0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b14:	eb0302bf 	cmp	x21, x3
    4b18:	54000121 	b.ne	4b3c <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b1c:	b5000335 	cbnz	x21, 4b80 <fwp_rc_prepare_chunk+0x100>
    4b20:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b2c:	d65f03c0 	ret
    4b30:	2a0303e3 	mov	w3, w3
    4b34:	eb0302bf 	cmp	x21, x3
    4b38:	54ffff20 	b.eq	4b1c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4b3c:	911982c2 	add	x2, x22, #0x660
    4b40:	f9401280 	ldr	x0, [x20, #32]
    4b44:	f94e2841 	ldr	x1, [x2, #7248]
    4b48:	cb030021 	sub	x1, x1, x3
    4b4c:	f90e2841 	str	x1, [x2, #7248]
    4b50:	97fff760 	bl	28d0 <free@plt>
    4b54:	b5fffb75 	cbnz	x21, 4ac0 <fwp_rc_prepare_chunk+0x40>
    4b58:	f900129f 	str	xzr, [x20, #32]
    4b5c:	911982d6 	add	x22, x22, #0x660
    4b60:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b64:	b9001e95 	str	w21, [x20, #28]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	8b150000 	add	x0, x0, x21
    4b70:	f90e2ac0 	str	x0, [x22, #7248]
    4b74:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b7c:	d65f03c0 	ret
    4b80:	f9401280 	ldr	x0, [x20, #32]
    4b84:	aa1503e2 	mov	x2, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	52800001 	mov	w1, #0x0                   	// #0
    4b90:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b94:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b98:	17fff712 	b	27e0 <memset@plt>
    4b9c:	d503201f 	nop

0000000000004ba0 <fwp_heap_refill>:
    4ba0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4ba4:	910003fd 	mov	x29, sp
    4ba8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4bac:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    4bb0:	911982b5 	add	x21, x21, #0x660
    4bb4:	aa0003f6 	mov	x22, x0
    4bb8:	d2800020 	mov	x0, #0x1                   	// #1
    4bbc:	a90153f3 	stp	x19, x20, [sp, #16]
    4bc0:	a90363f7 	stp	x23, x24, [sp, #48]
    4bc4:	2a0103f7 	mov	w23, w1
    4bc8:	2a0203f8 	mov	w24, w2
    4bcc:	97fff959 	bl	3130 <fwp_heap_chunks>
    4bd0:	aa0003f3 	mov	x19, x0
    4bd4:	f949fea2 	ldr	x2, [x21, #5112]
    4bd8:	8b000800 	add	x0, x0, x0, lsl #2
    4bdc:	2a1703e1 	mov	w1, w23
    4be0:	52800025 	mov	w5, #0x1                   	// #1
    4be4:	d37df000 	lsl	x0, x0, #3
    4be8:	910f0021 	add	x1, x1, #0x3c0
    4bec:	8b000054 	add	x20, x2, x0
    4bf0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4bf4:	52a00024 	mov	w4, #0x10000               	// #65536
    4bf8:	38206845 	strb	w5, [x2, x0]
    4bfc:	aa1403e0 	mov	x0, x20
    4c00:	39000698 	strb	w24, [x20, #1]
    4c04:	39000a97 	strb	w23, [x20, #2]
    4c08:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c0c:	b9000681 	str	w1, [x20, #4]
    4c10:	2a0103e5 	mov	w5, w1
    4c14:	8b0300a2 	add	x2, x5, x3
    4c18:	1ac10881 	udiv	w1, w4, w1
    4c1c:	9ac50842 	udiv	x2, x2, x5
    4c20:	b9000a81 	str	w1, [x20, #8]
    4c24:	92404021 	and	x1, x1, #0x1ffff
    4c28:	b9001a82 	str	w2, [x20, #24]
    4c2c:	97ffff95 	bl	4a80 <fwp_rc_prepare_chunk>
    4c30:	f949daa0 	ldr	x0, [x21, #5040]
    4c34:	29408a81 	ldp	w1, w2, [x20, #4]
    4c38:	8b134000 	add	x0, x0, x19, lsl #16
    4c3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c40:	8b214003 	add	x3, x0, w1, uxtw
    4c44:	9ba20021 	umaddl	x1, w1, w2, x0
    4c48:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c4c:	a90086c3 	stp	x3, x1, [x22, #8]
    4c50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c54:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c58:	d65f03c0 	ret
    4c5c:	d503201f 	nop

0000000000004c60 <fwp_mem_free>:
    4c60:	b40003c0 	cbz	x0, 4cd8 <fwp_mem_free+0x78>
    4c64:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c68:	910003fd 	mov	x29, sp
    4c6c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c70:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    4c74:	911982a1 	add	x1, x21, #0x660
    4c78:	a90153f3 	stp	x19, x20, [sp, #16]
    4c7c:	aa0003f3 	mov	x19, x0
    4c80:	f949d823 	ldr	x3, [x1, #5040]
    4c84:	f949ec22 	ldr	x2, [x1, #5080]
    4c88:	cb030000 	sub	x0, x0, x3
    4c8c:	eb02401f 	cmp	x0, x2, lsl #16
    4c90:	540001c2 	b.cs	4cc8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4c94:	d350fc16 	lsr	x22, x0, #16
    4c98:	a90363f7 	stp	x23, x24, [sp, #48]
    4c9c:	f949fc22 	ldr	x2, [x1, #5112]
    4ca0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4ca4:	d37df294 	lsl	x20, x20, #3
    4ca8:	ab140057 	adds	x23, x2, x20
    4cac:	540000c0 	b.eq	4cc4 <fwp_mem_free+0x64>  // b.none
    4cb0:	38746842 	ldrb	w2, [x2, x20]
    4cb4:	7100045f 	cmp	w2, #0x1
    4cb8:	54000120 	b.eq	4cdc <fwp_mem_free+0x7c>  // b.none
    4cbc:	7100085f 	cmp	w2, #0x2
    4cc0:	540005e0 	b.eq	4d7c <fwp_mem_free+0x11c>  // b.none
    4cc4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ccc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4cd4:	d65f03c0 	ret
    4cd8:	d65f03c0 	ret
    4cdc:	f94012f8 	ldr	x24, [x23, #32]
    4ce0:	b94006e1 	ldr	w1, [x23, #4]
    4ce4:	f90023f9 	str	x25, [sp, #64]
    4ce8:	2a0103e2 	mov	w2, w1
    4cec:	394006f9 	ldrb	w25, [x23, #1]
    4cf0:	39400af4 	ldrb	w20, [x23, #2]
    4cf4:	b4000158 	cbz	x24, 4d1c <fwp_mem_free+0xbc>
    4cf8:	92403e76 	and	x22, x19, #0xffff
    4cfc:	9ac20ad6 	udiv	x22, x22, x2
    4d00:	38766b01 	ldrb	w1, [x24, x22]
    4d04:	8b160300 	add	x0, x24, x22
    4d08:	7103fc3f 	cmp	w1, #0xff
    4d0c:	54000980 	b.eq	4e3c <fwp_mem_free+0x1dc>  // b.none
    4d10:	38366b1f 	strb	wzr, [x24, x22]
    4d14:	b94006e1 	ldr	w1, [x23, #4]
    4d18:	2a0103e2 	mov	w2, w1
    4d1c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4d20:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4d24:	cb390000 	sub	x0, x0, w25, uxtb
    4d28:	8b340074 	add	x20, x3, w20, uxtb
    4d2c:	911982b5 	add	x21, x21, #0x660
    4d30:	1e630021 	ucvtf	d1, w1
    4d34:	d37ae400 	lsl	x0, x0, #6
    4d38:	8b140c14 	add	x20, x0, x20, lsl #3
    4d3c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d40:	f8746aa0 	ldr	x0, [x21, x20]
    4d44:	f94023f9 	ldr	x25, [sp, #64]
    4d48:	aa2003e0 	mvn	x0, x0
    4d4c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d50:	f9000260 	str	x0, [x19]
    4d54:	f8346ab3 	str	x19, [x21, x20]
    4d58:	f94a12a0 	ldr	x0, [x21, #5152]
    4d5c:	1e612800 	fadd	d0, d0, d1
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	cb020000 	sub	x0, x0, x2
    4d68:	f90a12a0 	str	x0, [x21, #5152]
    4d6c:	fd0a22a0 	str	d0, [x21, #5184]
    4d70:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d74:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d78:	d65f03c0 	ret
    4d7c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4d80:	8b000063 	add	x3, x3, x0
    4d84:	eb03027f 	cmp	x19, x3
    4d88:	54fff9e1 	b.ne	4cc4 <fwp_mem_free+0x64>  // b.any
    4d8c:	fd400ae1 	ldr	d1, [x23, #16]
    4d90:	fd4a2020 	ldr	d0, [x1, #5184]
    4d94:	f9400ae0 	ldr	x0, [x23, #16]
    4d98:	7e61d821 	ucvtf	d1, d1
    4d9c:	f94a1022 	ldr	x2, [x1, #5152]
    4da0:	f94012f3 	ldr	x19, [x23, #32]
    4da4:	1e612800 	fadd	d0, d0, d1
    4da8:	cb000042 	sub	x2, x2, x0
    4dac:	f90a1022 	str	x2, [x1, #5152]
    4db0:	fd0a2020 	str	d0, [x1, #5184]
    4db4:	b40000b3 	cbz	x19, 4dc8 <fwp_mem_free+0x168>
    4db8:	39400260 	ldrb	w0, [x19]
    4dbc:	7103fc1f 	cmp	w0, #0xff
    4dc0:	54000380 	b.eq	4e30 <fwp_mem_free+0x1d0>  // b.none
    4dc4:	3900027f 	strb	wzr, [x19]
    4dc8:	b9400ee2 	ldr	w2, [x23, #12]
    4dcc:	b4000142 	cbz	x2, 4df4 <fwp_mem_free+0x194>
    4dd0:	911982a1 	add	x1, x21, #0x660
    4dd4:	8b160040 	add	x0, x2, x22
    4dd8:	8b000800 	add	x0, x0, x0, lsl #2
    4ddc:	f949fc21 	ldr	x1, [x1, #5112]
    4de0:	8b140034 	add	x20, x1, x20
    4de4:	8b000c20 	add	x0, x1, x0, lsl #3
    4de8:	3802869f 	strb	wzr, [x20], #40
    4dec:	eb00029f 	cmp	x20, x0
    4df0:	54ffffc1 	b.ne	4de8 <fwp_mem_free+0x188>  // b.any
    4df4:	911982a0 	add	x0, x21, #0x660
    4df8:	f94a1801 	ldr	x1, [x0, #5168]
    4dfc:	f949f803 	ldr	x3, [x0, #5104]
    4e00:	8b020021 	add	x1, x1, x2
    4e04:	f90a1801 	str	x1, [x0, #5168]
    4e08:	eb16007f 	cmp	x3, x22
    4e0c:	54000049 	b.ls	4e14 <fwp_mem_free+0x1b4>  // b.plast
    4e10:	f909f816 	str	x22, [x0, #5104]
    4e14:	911982b5 	add	x21, x21, #0x660
    4e18:	f949f6a0 	ldr	x0, [x21, #5096]
    4e1c:	eb16001f 	cmp	x0, x22
    4e20:	54fff529 	b.ls	4cc4 <fwp_mem_free+0x64>  // b.plast
    4e24:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e28:	f909f6b6 	str	x22, [x21, #5096]
    4e2c:	17ffffa7 	b	4cc8 <fwp_mem_free+0x68>
    4e30:	aa1303e0 	mov	x0, x19
    4e34:	97fffeeb 	bl	49e0 <fwp_rc_forget_slot>
    4e38:	17ffffe3 	b	4dc4 <fwp_mem_free+0x164>
    4e3c:	97fffee9 	bl	49e0 <fwp_rc_forget_slot>
    4e40:	17ffffb4 	b	4d10 <fwp_mem_free+0xb0>

0000000000004e44 <fwp_heap_alloc_big>:
    4e44:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e48:	910003fd 	mov	x29, sp
    4e4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4e50:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e54:	a90363f7 	stp	x23, x24, [sp, #48]
    4e58:	aa0003f7 	mov	x23, x0
    4e5c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e60:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e64:	eb0002ff 	cmp	x23, x0
    4e68:	54000888 	b.hi	4f78 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e6c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e70:	8b0002f4 	add	x20, x23, x0
    4e74:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xb80>
    4e78:	91198359 	add	x25, x26, #0x660
    4e7c:	d350fe94 	lsr	x20, x20, #16
    4e80:	2a0103f5 	mov	w21, w1
    4e84:	aa1403e0 	mov	x0, x20
    4e88:	97fff8aa 	bl	3130 <fwp_heap_chunks>
    4e8c:	f949ff22 	ldr	x2, [x25, #5112]
    4e90:	8b000813 	add	x19, x0, x0, lsl #2
    4e94:	aa0003f8 	mov	x24, x0
    4e98:	52800043 	mov	w3, #0x2                   	// #2
    4e9c:	d37df273 	lsl	x19, x19, #3
    4ea0:	d2800021 	mov	x1, #0x1                   	// #1
    4ea4:	8b130040 	add	x0, x2, x19
    4ea8:	38336843 	strb	w3, [x2, x19]
    4eac:	39000415 	strb	w21, [x0, #1]
    4eb0:	b9000c14 	str	w20, [x0, #12]
    4eb4:	f9000817 	str	x23, [x0, #16]
    4eb8:	97fffef2 	bl	4a80 <fwp_rc_prepare_chunk>
    4ebc:	f100069f 	cmp	x20, #0x1
    4ec0:	54000269 	b.ls	4f0c <fwp_heap_alloc_big+0xc8>  // b.plast
    4ec4:	8b180294 	add	x20, x20, x24
    4ec8:	9100a273 	add	x19, x19, #0x28
    4ecc:	a90573fb 	stp	x27, x28, [sp, #80]
    4ed0:	5280007b 	mov	w27, #0x3                   	// #3
    4ed4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ed8:	2a1803fc 	mov	w28, w24
    4edc:	9adb2296 	lsl	x22, x20, x27
    4ee0:	f949ff35 	ldr	x21, [x25, #5112]
    4ee4:	d2800001 	mov	x1, #0x0                   	// #0
    4ee8:	8b1302b4 	add	x20, x21, x19
    4eec:	aa1403e0 	mov	x0, x20
    4ef0:	97fffee4 	bl	4a80 <fwp_rc_prepare_chunk>
    4ef4:	38336abb 	strb	w27, [x21, x19]
    4ef8:	9100a273 	add	x19, x19, #0x28
    4efc:	b9000e9c 	str	w28, [x20, #12]
    4f00:	eb1302df 	cmp	x22, x19
    4f04:	54fffee1 	b.ne	4ee0 <fwp_heap_alloc_big+0x9c>  // b.any
    4f08:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f0c:	91198353 	add	x19, x26, #0x660
    4f10:	aa1703e2 	mov	x2, x23
    4f14:	52800001 	mov	w1, #0x0                   	// #0
    4f18:	f949da60 	ldr	x0, [x19, #5040]
    4f1c:	8b184018 	add	x24, x0, x24, lsl #16
    4f20:	aa1803e0 	mov	x0, x24
    4f24:	97fff62f 	bl	27e0 <memset@plt>
    4f28:	f94a1260 	ldr	x0, [x19, #5152]
    4f2c:	ab170000 	adds	x0, x0, x23
    4f30:	54000242 	b.cs	4f78 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4f34:	f94a1661 	ldr	x1, [x19, #5160]
    4f38:	f90a1260 	str	x0, [x19, #5152]
    4f3c:	eb01001f 	cmp	x0, x1
    4f40:	54000049 	b.ls	4f48 <fwp_heap_alloc_big+0x104>  // b.plast
    4f44:	f90a1660 	str	x0, [x19, #5160]
    4f48:	9119835a 	add	x26, x26, #0x660
    4f4c:	9e6202e0 	scvtf	d0, x23
    4f50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f54:	aa1803e0 	mov	x0, x24
    4f58:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f60:	1e602820 	fadd	d0, d1, d0
    4f64:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f68:	fd0a1f40 	str	d0, [x26, #5176]
    4f6c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f70:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f74:	d65f03c0 	ret
    4f78:	a90573fb 	stp	x27, x28, [sp, #80]
    4f7c:	97fff85d 	bl	30f0 <fwp_heap_oom>

0000000000004f80 <fwp_heap_alloc_slow>:
    4f80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f84:	910003fd 	mov	x29, sp
    4f88:	a90153f3 	stp	x19, x20, [sp, #16]
    4f8c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xb80>
    4f90:	91198262 	add	x2, x19, #0x660
    4f94:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f98:	aa0003f5 	mov	x21, x0
    4f9c:	2a0103f4 	mov	w20, w1
    4fa0:	b953a440 	ldr	w0, [x2, #5028]
    4fa4:	34000600 	cbz	w0, 5064 <fwp_heap_alloc_slow+0xe4>
    4fa8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fac:	54000628 	b.hi	5070 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fb0:	91003ea0 	add	x0, x21, #0xf
    4fb4:	91198262 	add	x2, x19, #0x660
    4fb8:	f9001bf7 	str	x23, [sp, #48]
    4fbc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4fc0:	8b401040 	add	x0, x2, x0, lsr #4
    4fc4:	cb34c084 	sub	x4, x4, w20, sxtw
    4fc8:	d37ae484 	lsl	x4, x4, #6
    4fcc:	397e8003 	ldrb	w3, [x0, #4000]
    4fd0:	910f0060 	add	x0, x3, #0x3c0
    4fd4:	aa0303e1 	mov	x1, x3
    4fd8:	8b030463 	add	x3, x3, x3, lsl #1
    4fdc:	8b030c83 	add	x3, x4, x3, lsl #3
    4fe0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4fe4:	2a1703f6 	mov	w22, w23
    4fe8:	f8636844 	ldr	x4, [x2, x3]
    4fec:	b40004e4 	cbz	x4, 5088 <fwp_heap_alloc_slow+0x108>
    4ff0:	f9400080 	ldr	x0, [x4]
    4ff4:	aa2003e0 	mvn	x0, x0
    4ff8:	f8236840 	str	x0, [x2, x3]
    4ffc:	7100069f 	cmp	w20, #0x1
    5000:	aa0403e0 	mov	x0, x4
    5004:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5008:	52800001 	mov	w1, #0x0                   	// #0
    500c:	97fff5f5 	bl	27e0 <memset@plt>
    5010:	aa0003e4 	mov	x4, x0
    5014:	91198260 	add	x0, x19, #0x660
    5018:	f94a1001 	ldr	x1, [x0, #5152]
    501c:	ab160021 	adds	x1, x1, x22
    5020:	540005c2 	b.cs	50d8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5024:	f94a1402 	ldr	x2, [x0, #5160]
    5028:	f90a1001 	str	x1, [x0, #5152]
    502c:	eb02003f 	cmp	x1, x2
    5030:	54000049 	b.ls	5038 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5034:	f90a1401 	str	x1, [x0, #5160]
    5038:	91198273 	add	x19, x19, #0x660
    503c:	1e6302e1 	ucvtf	d1, w23
    5040:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5044:	aa0403e0 	mov	x0, x4
    5048:	fd4a1e60 	ldr	d0, [x19, #5176]
    504c:	f9401bf7 	ldr	x23, [sp, #48]
    5050:	1e612800 	fadd	d0, d0, d1
    5054:	fd0a1e60 	str	d0, [x19, #5176]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5060:	d65f03c0 	ret
    5064:	97fffc08 	bl	4084 <fwp_heap_init>
    5068:	f14012bf 	cmp	x21, #0x4, lsl #12
    506c:	54fffa29 	b.ls	4fb0 <fwp_heap_alloc_slow+0x30>  // b.plast
    5070:	2a1403e1 	mov	w1, w20
    5074:	aa1503e0 	mov	x0, x21
    5078:	a94153f3 	ldp	x19, x20, [sp, #16]
    507c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5080:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5084:	17ffff70 	b	4e44 <fwp_heap_alloc_big>
    5088:	8b030042 	add	x2, x2, x3
    508c:	f9400444 	ldr	x4, [x2, #8]
    5090:	b4000104 	cbz	x4, 50b0 <fwp_heap_alloc_slow+0x130>
    5094:	f9400840 	ldr	x0, [x2, #16]
    5098:	cb040000 	sub	x0, x0, x4
    509c:	eb16001f 	cmp	x0, x22
    50a0:	54000083 	b.cc	50b0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50a4:	8b160080 	add	x0, x4, x22
    50a8:	f9000440 	str	x0, [x2, #8]
    50ac:	17ffffd4 	b	4ffc <fwp_heap_alloc_slow+0x7c>
    50b0:	52800302 	mov	w2, #0x18                  	// #24
    50b4:	52807804 	mov	w4, #0x3c0                 	// #960
    50b8:	91198260 	add	x0, x19, #0x660
    50bc:	9ba27c23 	umull	x3, w1, w2
    50c0:	2a1403e2 	mov	w2, w20
    50c4:	9b240e84 	smaddl	x4, w20, w4, x3
    50c8:	8b040000 	add	x0, x0, x4
    50cc:	97fffeb5 	bl	4ba0 <fwp_heap_refill>
    50d0:	aa0003e4 	mov	x4, x0
    50d4:	17ffffca 	b	4ffc <fwp_heap_alloc_slow+0x7c>
    50d8:	97fff806 	bl	30f0 <fwp_heap_oom>
    50dc:	d503201f 	nop

00000000000050e0 <fwp_heap_alloc>:
    50e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    50e4:	910003fd 	mov	x29, sp
    50e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    50ec:	f00000d6 	adrp	x22, 20000 <__data_start>
    50f0:	910182c2 	add	x2, x22, #0x60
    50f4:	a90363f7 	stp	x23, x24, [sp, #48]
    50f8:	b9415058 	ldr	w24, [x2, #336]
    50fc:	a90153f3 	stp	x19, x20, [sp, #16]
    5100:	7100031f 	cmp	w24, #0x0
    5104:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5108:	54000861 	b.ne	5214 <fwp_heap_alloc+0x134>  // b.any
    510c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xb80>
    5110:	911982f3 	add	x19, x23, #0x660
    5114:	f140101f 	cmp	x0, #0x4, lsl #12
    5118:	b953a662 	ldr	w2, [x19, #5028]
    511c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5120:	54000740 	b.eq	5208 <fwp_heap_alloc+0x128>  // b.none
    5124:	91003c03 	add	x3, x0, #0xf
    5128:	937c7c22 	sbfiz	x2, x1, #4, #32
    512c:	cb21c042 	sub	x2, x2, w1, sxtw
    5130:	8b431263 	add	x3, x19, x3, lsr #4
    5134:	d37ae442 	lsl	x2, x2, #6
    5138:	397e8063 	ldrb	w3, [x3, #4000]
    513c:	910f0064 	add	x4, x3, #0x3c0
    5140:	8b030463 	add	x3, x3, x3, lsl #1
    5144:	8b030c43 	add	x3, x2, x3, lsl #3
    5148:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    514c:	2a1503f4 	mov	w20, w21
    5150:	f8636a64 	ldr	x4, [x19, x3]
    5154:	b40004c4 	cbz	x4, 51ec <fwp_heap_alloc+0x10c>
    5158:	f9400085 	ldr	x5, [x4]
    515c:	7100043f 	cmp	w1, #0x1
    5160:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5164:	aa0403e0 	mov	x0, x4
    5168:	aa2503e5 	mvn	x5, x5
    516c:	52800001 	mov	w1, #0x0                   	// #0
    5170:	f8236a65 	str	x5, [x19, x3]
    5174:	97fff59b 	bl	27e0 <memset@plt>
    5178:	aa0003e4 	mov	x4, x0
    517c:	f94a1260 	ldr	x0, [x19, #5152]
    5180:	ab140000 	adds	x0, x0, x20
    5184:	540006e2 	b.cs	5260 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5188:	f94a1661 	ldr	x1, [x19, #5160]
    518c:	f90a1260 	str	x0, [x19, #5152]
    5190:	eb01001f 	cmp	x0, x1
    5194:	54000049 	b.ls	519c <fwp_heap_alloc+0xbc>  // b.plast
    5198:	f90a1660 	str	x0, [x19, #5160]
    519c:	911982e0 	add	x0, x23, #0x660
    51a0:	1e6302a1 	ucvtf	d1, w21
    51a4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51a8:	1e612800 	fadd	d0, d0, d1
    51ac:	fd0a1c00 	str	d0, [x0, #5176]
    51b0:	34000138 	cbz	w24, 51d4 <fwp_heap_alloc+0xf4>
    51b4:	911982e1 	add	x1, x23, #0x660
    51b8:	910182c0 	add	x0, x22, #0x60
    51bc:	fd4a1020 	ldr	d0, [x1, #5152]
    51c0:	6d568402 	ldp	d2, d1, [x0, #360]
    51c4:	7e61d800 	ucvtf	d0, d0
    51c8:	1e623800 	fsub	d0, d0, d2
    51cc:	1e612010 	fcmpe	d0, d1
    51d0:	540002cc 	b.gt	5228 <fwp_heap_alloc+0x148>
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	aa0403e0 	mov	x0, x4
    51dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51e0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51e8:	d65f03c0 	ret
    51ec:	8b030263 	add	x3, x19, x3
    51f0:	f9400464 	ldr	x4, [x3, #8]
    51f4:	b40000a4 	cbz	x4, 5208 <fwp_heap_alloc+0x128>
    51f8:	f9400862 	ldr	x2, [x3, #16]
    51fc:	cb040042 	sub	x2, x2, x4
    5200:	eb02029f 	cmp	x20, x2
    5204:	54000209 	b.ls	5244 <fwp_heap_alloc+0x164>  // b.plast
    5208:	97ffff5e 	bl	4f80 <fwp_heap_alloc_slow>
    520c:	aa0003e4 	mov	x4, x0
    5210:	17ffffe8 	b	51b0 <fwp_heap_alloc+0xd0>
    5214:	a9558c44 	ldp	x4, x3, [x2, #344]
    5218:	91000484 	add	x4, x4, #0x1
    521c:	8b000063 	add	x3, x3, x0
    5220:	a9158c44 	stp	x4, x3, [x2, #344]
    5224:	17ffffba 	b	510c <fwp_heap_alloc+0x2c>
    5228:	a94153f3 	ldp	x19, x20, [sp, #16]
    522c:	fd00b800 	str	d0, [x0, #368]
    5230:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5234:	aa0403e0 	mov	x0, x4
    5238:	a94363f7 	ldp	x23, x24, [sp, #48]
    523c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5240:	d65f03c0 	ret
    5244:	7100043f 	cmp	w1, #0x1
    5248:	8b140085 	add	x5, x4, x20
    524c:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5250:	52800001 	mov	w1, #0x0                   	// #0
    5254:	aa0403e0 	mov	x0, x4
    5258:	f9000465 	str	x5, [x3, #8]
    525c:	17ffffc6 	b	5174 <fwp_heap_alloc+0x94>
    5260:	97fff7a4 	bl	30f0 <fwp_heap_oom>

0000000000005264 <fwp_apply>:
    5264:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5268:	aa0003e6 	mov	x6, x0
    526c:	910003fd 	mov	x29, sp
    5270:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5274:	f947f463 	ldr	x3, [x3, #4072]
    5278:	a90153f3 	stp	x19, x20, [sp, #16]
    527c:	aa0203f4 	mov	x20, x2
    5280:	a9025bf5 	stp	x21, x22, [sp, #32]
    5284:	2a0103f5 	mov	w21, w1
    5288:	52800033 	mov	w19, #0x1                   	// #1
    528c:	a90363f7 	stp	x23, x24, [sp, #48]
    5290:	f00000d7 	adrp	x23, 20000 <__data_start>
    5294:	910182f7 	add	x23, x23, #0x60
    5298:	a9046bf9 	stp	x25, x26, [sp, #64]
    529c:	d100c3ff 	sub	sp, sp, #0x30
    52a0:	f9400060 	ldr	x0, [x3]
    52a4:	f81f83a0 	stur	x0, [x29, #-8]
    52a8:	d2800000 	mov	x0, #0x0                   	// #0
    52ac:	294058c3 	ldp	w3, w22, [x6]
    52b0:	910003f8 	mov	x24, sp
    52b4:	f9406ae0 	ldr	x0, [x23, #208]
    52b8:	710002df 	cmp	w22, #0x0
    52bc:	d37be863 	lsl	x3, x3, #5
    52c0:	8b030007 	add	x7, x0, x3
    52c4:	b8636819 	ldr	w25, [x0, x3]
    52c8:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    52cc:	54000163 	b.cc	52f8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    52d0:	f94004e3 	ldr	x3, [x7, #8]
    52d4:	34000bd9 	cbz	w25, 544c <fwp_apply+0x1e8>
    52d8:	aa1403e0 	mov	x0, x20
    52dc:	d63f0060 	blr	x3
    52e0:	aa0003e6 	mov	x6, x0
    52e4:	6b1902bf 	cmp	w21, w25
    52e8:	54000940 	b.eq	5410 <fwp_apply+0x1ac>  // b.none
    52ec:	8b394e94 	add	x20, x20, w25, uxtw #3
    52f0:	4b1902b5 	sub	w21, w21, w25
    52f4:	17ffffee 	b	52ac <fwp_apply+0x48>
    52f8:	0b1602ba 	add	w26, w21, w22
    52fc:	6b19035f 	cmp	w26, w25
    5300:	54000543 	b.cc	53a8 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    5304:	7100033f 	cmp	w25, #0x0
    5308:	4b16033a 	sub	w26, w25, w22
    530c:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    5310:	d37df000 	lsl	x0, x0, #3
    5314:	91003c00 	add	x0, x0, #0xf
    5318:	92704c01 	and	x1, x0, #0xfffff0000
    531c:	927c7c00 	and	x0, x0, #0xffffffff0
    5320:	cb2163e1 	sub	x1, sp, x1
    5324:	eb2163ff 	cmp	sp, x1
    5328:	540000a0 	b.eq	533c <fwp_apply+0xd8>  // b.none
    532c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    5330:	f90203ff 	str	xzr, [sp, #1024]
    5334:	eb2163ff 	cmp	sp, x1
    5338:	54ffffa1 	b.ne	532c <fwp_apply+0xc8>  // b.any
    533c:	92403c00 	and	x0, x0, #0xffff
    5340:	cb2063ff 	sub	sp, sp, x0
    5344:	f90003ff 	str	xzr, [sp]
    5348:	f110001f 	cmp	x0, #0x400
    534c:	54000962 	b.cs	5478 <fwp_apply+0x214>  // b.hs, b.nlast
    5350:	910020c6 	add	x6, x6, #0x8
    5354:	910043e0 	add	x0, sp, #0x10
    5358:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    535c:	d2800003 	mov	x3, #0x0                   	// #0
    5360:	340000f6 	cbz	w22, 537c <fwp_apply+0x118>
    5364:	d503201f 	nop
    5368:	f86368c4 	ldr	x4, [x6, x3]
    536c:	f8236804 	str	x4, [x0, x3]
    5370:	91002063 	add	x3, x3, #0x8
    5374:	eb0300bf 	cmp	x5, x3
    5378:	54ffff81 	b.ne	5368 <fwp_apply+0x104>  // b.any
    537c:	3400013a 	cbz	w26, 53a0 <fwp_apply+0x13c>
    5380:	2a1a03e6 	mov	w6, w26
    5384:	d2800003 	mov	x3, #0x0                   	// #0
    5388:	0b0302c4 	add	w4, w22, w3
    538c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5390:	91000463 	add	x3, x3, #0x1
    5394:	f8247805 	str	x5, [x0, x4, lsl #3]
    5398:	eb0300df 	cmp	x6, x3
    539c:	54ffff61 	b.ne	5388 <fwp_apply+0x124>  // b.any
    53a0:	f94004e3 	ldr	x3, [x7, #8]
    53a4:	1400002c 	b	5454 <fwp_apply+0x1f0>
    53a8:	11000740 	add	w0, w26, #0x1
    53ac:	52800041 	mov	w1, #0x2                   	// #2
    53b0:	f81e83a6 	stur	x6, [x29, #-24]
    53b4:	d37df000 	lsl	x0, x0, #3
    53b8:	97ffff4a 	bl	50e0 <fwp_heap_alloc>
    53bc:	f85e83a6 	ldur	x6, [x29, #-24]
    53c0:	aa0003f3 	mov	x19, x0
    53c4:	b94000c1 	ldr	w1, [x6]
    53c8:	29006801 	stp	w1, w26, [x0]
    53cc:	340000b6 	cbz	w22, 53e0 <fwp_apply+0x17c>
    53d0:	910020c1 	add	x1, x6, #0x8
    53d4:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    53d8:	91002000 	add	x0, x0, #0x8
    53dc:	97fff4a9 	bl	2680 <memmove@plt>
    53e0:	2a1503e3 	mov	w3, w21
    53e4:	d2800000 	mov	x0, #0x0                   	// #0
    53e8:	34000135 	cbz	w21, 540c <fwp_apply+0x1a8>
    53ec:	d503201f 	nop
    53f0:	0b0002c1 	add	w1, w22, w0
    53f4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53f8:	8b010e61 	add	x1, x19, x1, lsl #3
    53fc:	91000400 	add	x0, x0, #0x1
    5400:	f9000422 	str	x2, [x1, #8]
    5404:	eb00007f 	cmp	x3, x0
    5408:	54ffff41 	b.ne	53f0 <fwp_apply+0x18c>  // b.any
    540c:	aa1303e6 	mov	x6, x19
    5410:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5414:	f947f400 	ldr	x0, [x0, #4072]
    5418:	f85f83a2 	ldur	x2, [x29, #-8]
    541c:	f9400001 	ldr	x1, [x0]
    5420:	eb010042 	subs	x2, x2, x1
    5424:	d2800001 	mov	x1, #0x0                   	// #0
    5428:	540002c1 	b.ne	5480 <fwp_apply+0x21c>  // b.any
    542c:	910003bf 	mov	sp, x29
    5430:	aa0603e0 	mov	x0, x6
    5434:	a94153f3 	ldp	x19, x20, [sp, #16]
    5438:	a9425bf5 	ldp	x21, x22, [sp, #32]
    543c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5440:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5444:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5448:	d65f03c0 	ret
    544c:	d10043a0 	sub	x0, x29, #0x10
    5450:	5280001a 	mov	w26, #0x0                   	// #0
    5454:	d63f0060 	blr	x3
    5458:	aa0003e6 	mov	x6, x0
    545c:	6b1a02bf 	cmp	w21, w26
    5460:	54fffd80 	b.eq	5410 <fwp_apply+0x1ac>  // b.none
    5464:	0b1602b6 	add	w22, w21, w22
    5468:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    546c:	4b1902d5 	sub	w21, w22, w25
    5470:	9100031f 	mov	sp, x24
    5474:	17ffff8e 	b	52ac <fwp_apply+0x48>
    5478:	f90203ff 	str	xzr, [sp, #1024]
    547c:	17ffffb5 	b	5350 <fwp_apply+0xec>
    5480:	97fff4e4 	bl	2810 <__stack_chk_fail@plt>

0000000000005484 <fwp_p_ad_push>:
    5484:	f100001f 	cmp	x0, #0x0
    5488:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    548c:	54000eab 	b.lt	5660 <fwp_p_ad_push+0x1dc>  // b.tstop
    5490:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5494:	aa0003e4 	mov	x4, x0
    5498:	910003fd 	mov	x29, sp
    549c:	a9025bf5 	stp	x21, x22, [sp, #32]
    54a0:	aa0003f5 	mov	x21, x0
    54a4:	aa020000 	orr	x0, x0, x2
    54a8:	a90363f7 	stp	x23, x24, [sp, #48]
    54ac:	aa0203f7 	mov	x23, x2
    54b0:	6d0627e8 	stp	d8, d9, [sp, #96]
    54b4:	9e670029 	fmov	d9, x1
    54b8:	9e670068 	fmov	d8, x3
    54bc:	b6f80920 	tbz	x0, #63, 55e0 <fwp_p_ad_push+0x15c>
    54c0:	a90153f3 	stp	x19, x20, [sp, #16]
    54c4:	9360fc80 	asr	x0, x4, #32
    54c8:	b6f800c4 	tbz	x4, #63, 54e0 <fwp_p_ad_push+0x5c>
    54cc:	1e604109 	fmov	d9, d8
    54d0:	2f00e408 	movi	d8, #0x0
    54d4:	9360fc40 	asr	x0, x2, #32
    54d8:	aa0203f5 	mov	x21, x2
    54dc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    54e0:	97fff974 	bl	3ab0 <fwp_tape_of>
    54e4:	aa0003f3 	mov	x19, x0
    54e8:	f9403000 	ldr	x0, [x0, #96]
    54ec:	b5001240 	cbnz	x0, 5734 <fwp_p_ad_push+0x2b0>
    54f0:	f9400a76 	ldr	x22, [x19, #16]
    54f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54f8:	eb0002df 	cmp	x22, x0
    54fc:	54000d8c 	b.gt	56ac <fwp_p_ad_push+0x228>
    5500:	eb3542df 	cmp	x22, w21, uxtw
    5504:	54000cad 	b.le	5698 <fwp_p_ad_push+0x214>
    5508:	b7f80077 	tbnz	x23, #63, 5514 <fwp_p_ad_push+0x90>
    550c:	eb3742df 	cmp	x22, w23, uxtw
    5510:	54000c4d 	b.le	5698 <fwp_p_ad_push+0x214>
    5514:	f9400678 	ldr	x24, [x19, #8]
    5518:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    551c:	cb1802d8 	sub	x24, x22, x24
    5520:	91000701 	add	x1, x24, #0x1
    5524:	eb00003f 	cmp	x1, x0
    5528:	54000c28 	b.hi	56ac <fwp_p_ad_push+0x228>  // b.pmore
    552c:	a9418274 	ldp	x20, x0, [x19, #24]
    5530:	a90573fb 	stp	x27, x28, [sp, #80]
    5534:	eb14003f 	cmp	x1, x20
    5538:	540006ad 	b.le	560c <fwp_p_ad_push+0x188>
    553c:	f100029f 	cmp	x20, #0x0
    5540:	d2800803 	mov	x3, #0x40                  	// #64
    5544:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5548:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    554c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5550:	eb14003f 	cmp	x1, x20
    5554:	5400008d 	b.le	5564 <fwp_p_ad_push+0xe0>
    5558:	eb02029f 	cmp	x20, x2
    555c:	5400054d 	b.le	5604 <fwp_p_ad_push+0x180>
    5560:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5564:	d37df299 	lsl	x25, x20, #3
    5568:	52800022 	mov	w2, #0x1                   	// #1
    556c:	aa1903e1 	mov	x1, x25
    5570:	97fffbad 	bl	4424 <ad_raw_realloc>
    5574:	aa0003e1 	mov	x1, x0
    5578:	b4000a40 	cbz	x0, 56c0 <fwp_p_ad_push+0x23c>
    557c:	f9400e63 	ldr	x3, [x19, #24]
    5580:	f9001261 	str	x1, [x19, #32]
    5584:	f9401a60 	ldr	x0, [x19, #48]
    5588:	52800042 	mov	w2, #0x2                   	// #2
    558c:	8b030821 	add	x1, x1, x3, lsl #2
    5590:	f9001661 	str	x1, [x19, #40]
    5594:	d37cee81 	lsl	x1, x20, #4
    5598:	97fffba3 	bl	4424 <ad_raw_realloc>
    559c:	aa0003e2 	mov	x2, x0
    55a0:	b4000900 	cbz	x0, 56c0 <fwp_p_ad_push+0x23c>
    55a4:	f9400e61 	ldr	x1, [x19, #24]
    55a8:	d37df31b 	lsl	x27, x24, #3
    55ac:	d37ef69a 	lsl	x26, x20, #2
    55b0:	d37ef71c 	lsl	x28, x24, #2
    55b4:	8b190003 	add	x3, x0, x25
    55b8:	8b010c01 	add	x1, x0, x1, lsl #3
    55bc:	a9030660 	stp	x0, x1, [x19, #48]
    55c0:	b5000558 	cbnz	x24, 5668 <fwp_p_ad_push+0x1e4>
    55c4:	f9001e63 	str	x3, [x19, #56]
    55c8:	f9401260 	ldr	x0, [x19, #32]
    55cc:	8b1a0001 	add	x1, x0, x26
    55d0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    55d4:	f9000e74 	str	x20, [x19, #24]
    55d8:	f9001661 	str	x1, [x19, #40]
    55dc:	14000010 	b	561c <fwp_p_ad_push+0x198>
    55e0:	9360fc40 	asr	x0, x2, #32
    55e4:	a90153f3 	stp	x19, x20, [sp, #16]
    55e8:	eb84801f 	cmp	x0, x4, asr #32
    55ec:	54fff7a0 	b.eq	54e0 <fwp_p_ad_push+0x5c>  // b.none
    55f0:	d0000020 	adrp	x0, b000 <__divti3+0x70>
    55f4:	912ee000 	add	x0, x0, #0xbb8
    55f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    55fc:	a90573fb 	stp	x27, x28, [sp, #80]
    5600:	97fff860 	bl	3780 <fwp_trap>
    5604:	d37ffa94 	lsl	x20, x20, #1
    5608:	17ffffd2 	b	5550 <fwp_p_ad_push+0xcc>
    560c:	a9428a61 	ldp	x1, x2, [x19, #40]
    5610:	d37ef71c 	lsl	x28, x24, #2
    5614:	f9401e63 	ldr	x3, [x19, #56]
    5618:	d37df31b 	lsl	x27, x24, #3
    561c:	b83c6815 	str	w21, [x0, x28]
    5620:	f10002ff 	cmp	x23, #0x0
    5624:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5628:	92607eb5 	and	x21, x21, #0xffffffff00000000
    562c:	fc3b6849 	str	d9, [x2, x27]
    5630:	aa1602a0 	orr	x0, x21, x22
    5634:	b83c6837 	str	w23, [x1, x28]
    5638:	910006d6 	add	x22, x22, #0x1
    563c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5640:	fc3b6868 	str	d8, [x3, x27]
    5644:	a94573fb 	ldp	x27, x28, [sp, #80]
    5648:	6d4627e8 	ldp	d8, d9, [sp, #96]
    564c:	f9000a76 	str	x22, [x19, #16]
    5650:	a94153f3 	ldp	x19, x20, [sp, #16]
    5654:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5658:	a8c77bfd 	ldp	x29, x30, [sp], #112
    565c:	d65f03c0 	ret
    5660:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5664:	d65f03c0 	ret
    5668:	aa0303e0 	mov	x0, x3
    566c:	aa1b03e2 	mov	x2, x27
    5670:	97fff404 	bl	2680 <memmove@plt>
    5674:	a9420660 	ldp	x0, x1, [x19, #32]
    5678:	aa1c03e2 	mov	x2, x28
    567c:	f9401a63 	ldr	x3, [x19, #48]
    5680:	8b190063 	add	x3, x3, x25
    5684:	f9001e63 	str	x3, [x19, #56]
    5688:	8b1a0000 	add	x0, x0, x26
    568c:	97fff3fd 	bl	2680 <memmove@plt>
    5690:	a9430e62 	ldp	x2, x3, [x19, #48]
    5694:	17ffffcd 	b	55c8 <fwp_p_ad_push+0x144>
    5698:	d0000020 	adrp	x0, b000 <__divti3+0x70>
    569c:	91314000 	add	x0, x0, #0xc50
    56a0:	a9046bf9 	stp	x25, x26, [sp, #64]
    56a4:	a90573fb 	stp	x27, x28, [sp, #80]
    56a8:	97fff836 	bl	3780 <fwp_trap>
    56ac:	d0000020 	adrp	x0, b000 <__divti3+0x70>
    56b0:	9130c000 	add	x0, x0, #0xc30
    56b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    56b8:	a90573fb 	stp	x27, x28, [sp, #80]
    56bc:	97fff831 	bl	3780 <fwp_trap>
    56c0:	aa1303e0 	mov	x0, x19
    56c4:	97fff634 	bl	2f94 <fwp_tape_unlink_scope>
    56c8:	f9401260 	ldr	x0, [x19, #32]
    56cc:	b4000040 	cbz	x0, 56d4 <fwp_p_ad_push+0x250>
    56d0:	97fffb20 	bl	4350 <ad_raw_free.part.0>
    56d4:	f9401a60 	ldr	x0, [x19, #48]
    56d8:	b4000040 	cbz	x0, 56e0 <fwp_p_ad_push+0x25c>
    56dc:	97fffb1d 	bl	4350 <ad_raw_free.part.0>
    56e0:	f9402260 	ldr	x0, [x19, #64]
    56e4:	b4000040 	cbz	x0, 56ec <fwp_p_ad_push+0x268>
    56e8:	97fffb1a 	bl	4350 <ad_raw_free.part.0>
    56ec:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    56f0:	f947e821 	ldr	x1, [x1, #4048]
    56f4:	f9000e7f 	str	xzr, [x19, #24]
    56f8:	4f000400 	movi	v0.4s, #0x0
    56fc:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5700:	d2800262 	mov	x2, #0x13                  	// #19
    5704:	f9400023 	ldr	x3, [x1]
    5708:	b900067f 	str	wzr, [x19, #4]
    570c:	d2800021 	mov	x1, #0x1                   	// #1
    5710:	d0000020 	adrp	x0, b000 <__divti3+0x70>
    5714:	911ae000 	add	x0, x0, #0x6b8
    5718:	3c808260 	stur	q0, [x19, #8]
    571c:	ad010260 	stp	q0, q0, [x19, #32]
    5720:	97fff47c 	bl	2910 <fwrite@plt>
    5724:	d2800000 	mov	x0, #0x0                   	// #0
    5728:	97fff486 	bl	2940 <fflush@plt>
    572c:	52800cc0 	mov	w0, #0x66                  	// #102
    5730:	97fff494 	bl	2980 <_Exit@plt>
    5734:	d0000020 	adrp	x0, b000 <__divti3+0x70>
    5738:	91300000 	add	x0, x0, #0xc00
    573c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5740:	a90573fb 	stp	x27, x28, [sp, #80]
    5744:	97fff80f 	bl	3780 <fwp_trap>
    5748:	d503201f 	nop
    574c:	d503201f 	nop

0000000000005750 <w107>:
    5750:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5754:	9e660003 	fmov	x3, d0
    5758:	aa0003e2 	mov	x2, x0
    575c:	910003fd 	mov	x29, sp
    5760:	fd001fea 	str	d10, [sp, #56]
    5764:	1e60400a 	fmov	d10, d0
    5768:	6d0427e8 	stp	d8, d9, [sp, #64]
    576c:	1e604028 	fmov	d8, d1
    5770:	1e600809 	fmul	d9, d0, d0
    5774:	a90153f3 	stp	x19, x20, [sp, #16]
    5778:	aa0103f4 	mov	x20, x1
    577c:	aa0303e1 	mov	x1, x3
    5780:	aa0003f3 	mov	x19, x0
    5784:	a9025bf5 	stp	x21, x22, [sp, #32]
    5788:	f9001bf7 	str	x23, [sp, #48]
    578c:	97ffff3e 	bl	5484 <fwp_p_ad_push>
    5790:	aa0003e5 	mov	x5, x0
    5794:	97fffaac 	bl	4244 <caf61>
    5798:	9e670000 	fmov	d0, x0
    579c:	97fffaaa 	bl	4244 <caf61>
    57a0:	1e693908 	fsub	d8, d8, d9
    57a4:	aa1403e2 	mov	x2, x20
    57a8:	1e614000 	fneg	d0, d0
    57ac:	aa0003e3 	mov	x3, x0
    57b0:	aa0503e0 	mov	x0, x5
    57b4:	9e660117 	fmov	x23, d8
    57b8:	9e660001 	fmov	x1, d0
    57bc:	97ffff32 	bl	5484 <fwp_p_ad_push>
    57c0:	aa0003f5 	mov	x21, x0
    57c4:	97fffaa0 	bl	4244 <caf61>
    57c8:	9e670000 	fmov	d0, x0
    57cc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    57d0:	97fffa9d 	bl	4244 <caf61>
    57d4:	1e614000 	fneg	d0, d0
    57d8:	aa0003e3 	mov	x3, x0
    57dc:	1e6a3929 	fsub	d9, d9, d10
    57e0:	aa1303e0 	mov	x0, x19
    57e4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    57e8:	9e660001 	fmov	x1, d0
    57ec:	9e660136 	fmov	x22, d9
    57f0:	97ffff25 	bl	5484 <fwp_p_ad_push>
    57f4:	1e680908 	fmul	d8, d8, d8
    57f8:	aa0003f4 	mov	x20, x0
    57fc:	aa1703e3 	mov	x3, x23
    5800:	aa1703e1 	mov	x1, x23
    5804:	aa1503e2 	mov	x2, x21
    5808:	aa1503e0 	mov	x0, x21
    580c:	97ffff1e 	bl	5484 <fwp_p_ad_push>
    5810:	aa0003e2 	mov	x2, x0
    5814:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5818:	9e670020 	fmov	d0, x1
    581c:	9e660101 	fmov	x1, d8
    5820:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5824:	1e600908 	fmul	d8, d8, d0
    5828:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    582c:	97ffff16 	bl	5484 <fwp_p_ad_push>
    5830:	1e690929 	fmul	d9, d9, d9
    5834:	aa1603e3 	mov	x3, x22
    5838:	aa1603e1 	mov	x1, x22
    583c:	aa1403e2 	mov	x2, x20
    5840:	aa0003f3 	mov	x19, x0
    5844:	aa1403e0 	mov	x0, x20
    5848:	97ffff0f 	bl	5484 <fwp_p_ad_push>
    584c:	aa0003e5 	mov	x5, x0
    5850:	97fffa7d 	bl	4244 <caf61>
    5854:	aa0003e6 	mov	x6, x0
    5858:	97fffa7b 	bl	4244 <caf61>
    585c:	1e692908 	fadd	d8, d8, d9
    5860:	aa1303e2 	mov	x2, x19
    5864:	aa0603e1 	mov	x1, x6
    5868:	aa0003e3 	mov	x3, x0
    586c:	aa0503e0 	mov	x0, x5
    5870:	97ffff05 	bl	5484 <fwp_p_ad_push>
    5874:	aa0003e1 	mov	x1, x0
    5878:	a94153f3 	ldp	x19, x20, [sp, #16]
    587c:	9e660100 	fmov	x0, d8
    5880:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5884:	f9401bf7 	ldr	x23, [sp, #48]
    5888:	fd401fea 	ldr	d10, [sp, #56]
    588c:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5890:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5894:	d65f03c0 	ret
    5898:	d503201f 	nop
    589c:	d503201f 	nop

00000000000058a0 <w164.constprop.0>:
    58a0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    58a4:	910003fd 	mov	x29, sp
    58a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    58ac:	fd001be8 	str	d8, [sp, #48]
    58b0:	f9400015 	ldr	x21, [x0]
    58b4:	b40003b5 	cbz	x21, 5928 <w164.constprop.0+0x88>
    58b8:	2f00e408 	movi	d8, #0x0
    58bc:	91002016 	add	x22, x0, #0x8
    58c0:	a90153f3 	stp	x19, x20, [sp, #16]
    58c4:	91004014 	add	x20, x0, #0x10
    58c8:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    58cc:	d2800013 	mov	x19, #0x0                   	// #0
    58d0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    58d4:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    58d8:	97fffa5b 	bl	4244 <caf61>
    58dc:	aa0003e6 	mov	x6, x0
    58e0:	97fffa59 	bl	4244 <caf61>
    58e4:	1e602908 	fadd	d8, d8, d0
    58e8:	aa0003e3 	mov	x3, x0
    58ec:	aa0703e2 	mov	x2, x7
    58f0:	aa0503e0 	mov	x0, x5
    58f4:	aa0603e1 	mov	x1, x6
    58f8:	91000a73 	add	x19, x19, #0x2
    58fc:	97fffee2 	bl	5484 <fwp_p_ad_push>
    5900:	aa0003e5 	mov	x5, x0
    5904:	eb1302bf 	cmp	x21, x19
    5908:	54fffe48 	b.hi	58d0 <w164.constprop.0+0x30>  // b.pmore
    590c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5910:	9e660100 	fmov	x0, d8
    5914:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5918:	aa0503e1 	mov	x1, x5
    591c:	fd401be8 	ldr	d8, [sp, #48]
    5920:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5924:	d65f03c0 	ret
    5928:	2f00e408 	movi	d8, #0x0
    592c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    5930:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5934:	aa0503e1 	mov	x1, x5
    5938:	9e660100 	fmov	x0, d8
    593c:	fd401be8 	ldr	d8, [sp, #48]
    5940:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5944:	d65f03c0 	ret
    5948:	d503201f 	nop
    594c:	d503201f 	nop

0000000000005950 <fwp_data.part.0.constprop.0>:
    5950:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5954:	910003fd 	mov	x29, sp
    5958:	a9025bf5 	stp	x21, x22, [sp, #32]
    595c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5960:	910182c2 	add	x2, x22, #0x60
    5964:	a9046bf9 	stp	x25, x26, [sp, #64]
    5968:	b9415059 	ldr	w25, [x2, #336]
    596c:	a90153f3 	stp	x19, x20, [sp, #16]
    5970:	aa0103f4 	mov	x20, x1
    5974:	a90363f7 	stp	x23, x24, [sp, #48]
    5978:	2a0003f7 	mov	w23, w0
    597c:	340000b9 	cbz	w25, 5990 <fwp_data.part.0.constprop.0+0x40>
    5980:	a9558041 	ldp	x1, x0, [x2, #344]
    5984:	91000421 	add	x1, x1, #0x1
    5988:	91006000 	add	x0, x0, #0x18
    598c:	a9158041 	stp	x1, x0, [x2, #344]
    5990:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    5994:	911982a3 	add	x3, x21, #0x660
    5998:	b953a460 	ldr	w0, [x3, #5028]
    599c:	34000840 	cbz	w0, 5aa4 <fwp_data.part.0.constprop.0+0x154>
    59a0:	397e8862 	ldrb	w2, [x3, #4002]
    59a4:	910f0040 	add	x0, x2, #0x3c0
    59a8:	8b020442 	add	x2, x2, x2, lsl #1
    59ac:	d37df042 	lsl	x2, x2, #3
    59b0:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    59b4:	2a1a03f8 	mov	w24, w26
    59b8:	f8626873 	ldr	x19, [x3, x2]
    59bc:	b4000613 	cbz	x19, 5a7c <fwp_data.part.0.constprop.0+0x12c>
    59c0:	f9400260 	ldr	x0, [x19]
    59c4:	aa2003e0 	mvn	x0, x0
    59c8:	f8226860 	str	x0, [x3, x2]
    59cc:	f100631f 	cmp	x24, #0x18
    59d0:	540000e9 	b.ls	59ec <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    59d4:	d1006702 	sub	x2, x24, #0x19
    59d8:	91006260 	add	x0, x19, #0x18
    59dc:	927df042 	and	x2, x2, #0xfffffffffffffff8
    59e0:	52800001 	mov	w1, #0x0                   	// #0
    59e4:	91002042 	add	x2, x2, #0x8
    59e8:	97fff37e 	bl	27e0 <memset@plt>
    59ec:	911982a0 	add	x0, x21, #0x660
    59f0:	f94a1001 	ldr	x1, [x0, #5152]
    59f4:	ab180021 	adds	x1, x1, x24
    59f8:	54000642 	b.cs	5ac0 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    59fc:	f94a1402 	ldr	x2, [x0, #5160]
    5a00:	f90a1001 	str	x1, [x0, #5152]
    5a04:	eb02003f 	cmp	x1, x2
    5a08:	54000049 	b.ls	5a10 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5a0c:	f90a1401 	str	x1, [x0, #5160]
    5a10:	911982a0 	add	x0, x21, #0x660
    5a14:	1e630341 	ucvtf	d1, w26
    5a18:	fd4a1c00 	ldr	d0, [x0, #5176]
    5a1c:	1e612800 	fadd	d0, d0, d1
    5a20:	fd0a1c00 	str	d0, [x0, #5176]
    5a24:	34000139 	cbz	w25, 5a48 <fwp_data.part.0.constprop.0+0xf8>
    5a28:	911982b5 	add	x21, x21, #0x660
    5a2c:	910182d6 	add	x22, x22, #0x60
    5a30:	fd4a12a0 	ldr	d0, [x21, #5152]
    5a34:	6d5686c2 	ldp	d2, d1, [x22, #360]
    5a38:	7e61d800 	ucvtf	d0, d0
    5a3c:	1e623800 	fsub	d0, d0, d2
    5a40:	1e612010 	fcmpe	d0, d1
    5a44:	540003ac 	b.gt	5ab8 <fwp_data.part.0.constprop.0+0x168>
    5a48:	52800040 	mov	w0, #0x2                   	// #2
    5a4c:	29000277 	stp	w23, w0, [x19]
    5a50:	aa1303e0 	mov	x0, x19
    5a54:	f9400281 	ldr	x1, [x20]
    5a58:	f9000661 	str	x1, [x19, #8]
    5a5c:	f9400681 	ldr	x1, [x20, #8]
    5a60:	f9000a61 	str	x1, [x19, #16]
    5a64:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a68:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5a6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5a70:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5a74:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5a78:	d65f03c0 	ret
    5a7c:	8b020063 	add	x3, x3, x2
    5a80:	f9400473 	ldr	x19, [x3, #8]
    5a84:	b4000113 	cbz	x19, 5aa4 <fwp_data.part.0.constprop.0+0x154>
    5a88:	f9400860 	ldr	x0, [x3, #16]
    5a8c:	cb130000 	sub	x0, x0, x19
    5a90:	eb00031f 	cmp	x24, x0
    5a94:	54000088 	b.hi	5aa4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5a98:	8b180260 	add	x0, x19, x24
    5a9c:	f9000460 	str	x0, [x3, #8]
    5aa0:	17ffffcb 	b	59cc <fwp_data.part.0.constprop.0+0x7c>
    5aa4:	52800001 	mov	w1, #0x0                   	// #0
    5aa8:	d2800300 	mov	x0, #0x18                  	// #24
    5aac:	97fffd8d 	bl	50e0 <fwp_heap_alloc>
    5ab0:	aa0003f3 	mov	x19, x0
    5ab4:	17ffffdc 	b	5a24 <fwp_data.part.0.constprop.0+0xd4>
    5ab8:	fd00bac0 	str	d0, [x22, #368]
    5abc:	17ffffe3 	b	5a48 <fwp_data.part.0.constprop.0+0xf8>
    5ac0:	97fff58c 	bl	30f0 <fwp_heap_oom>

0000000000005ac4 <fwp_rc_share>:
    5ac4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xb80>
    5ac8:	91198042 	add	x2, x2, #0x660
    5acc:	f949d843 	ldr	x3, [x2, #5040]
    5ad0:	f949ec41 	ldr	x1, [x2, #5080]
    5ad4:	cb030000 	sub	x0, x0, x3
    5ad8:	eb01401f 	cmp	x0, x1, lsl #16
    5adc:	540002c2 	b.cs	5b34 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5ae0:	d350fc01 	lsr	x1, x0, #16
    5ae4:	f949fc44 	ldr	x4, [x2, #5112]
    5ae8:	8b010821 	add	x1, x1, x1, lsl #2
    5aec:	d37df021 	lsl	x1, x1, #3
    5af0:	8b010083 	add	x3, x4, x1
    5af4:	f9401062 	ldr	x2, [x3, #32]
    5af8:	b40001e2 	cbz	x2, 5b34 <fwp_rc_share+0x70>
    5afc:	38616881 	ldrb	w1, [x4, x1]
    5b00:	7100083f 	cmp	w1, #0x2
    5b04:	540001a0 	b.eq	5b38 <fwp_rc_share+0x74>  // b.none
    5b08:	7100043f 	cmp	w1, #0x1
    5b0c:	54000141 	b.ne	5b34 <fwp_rc_share+0x70>  // b.any
    5b10:	29430464 	ldp	w4, w1, [x3, #24]
    5b14:	92403c00 	and	x0, x0, #0xffff
    5b18:	9b047c00 	mul	x0, x0, x4
    5b1c:	d360fc00 	lsr	x0, x0, #32
    5b20:	eb01001f 	cmp	x0, x1
    5b24:	54000082 	b.cs	5b34 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5b28:	8b000042 	add	x2, x2, x0
    5b2c:	39400040 	ldrb	w0, [x2]
    5b30:	350000a0 	cbnz	w0, 5b44 <fwp_rc_share+0x80>
    5b34:	d65f03c0 	ret
    5b38:	72003c1f 	tst	w0, #0xffff
    5b3c:	54ffff80 	b.eq	5b2c <fwp_rc_share+0x68>  // b.none
    5b40:	d65f03c0 	ret
    5b44:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5b48:	d0000020 	adrp	x0, b000 <__divti3+0x70>
    5b4c:	9131c000 	add	x0, x0, #0xc70
    5b50:	910003fd 	mov	x29, sp
    5b54:	97fff70b 	bl	3780 <fwp_trap>
    5b58:	d503201f 	nop
    5b5c:	d503201f 	nop

0000000000005b60 <fwp_rc_free_arr>:
    5b60:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb80>
    5b64:	91198063 	add	x3, x3, #0x660
    5b68:	f949d861 	ldr	x1, [x3, #5040]
    5b6c:	f949ec62 	ldr	x2, [x3, #5080]
    5b70:	cb010001 	sub	x1, x0, x1
    5b74:	eb02403f 	cmp	x1, x2, lsl #16
    5b78:	54000342 	b.cs	5be0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b7c:	d350fc22 	lsr	x2, x1, #16
    5b80:	f949fc65 	ldr	x5, [x3, #5112]
    5b84:	8b020842 	add	x2, x2, x2, lsl #2
    5b88:	d37df042 	lsl	x2, x2, #3
    5b8c:	8b0200a4 	add	x4, x5, x2
    5b90:	f9401083 	ldr	x3, [x4, #32]
    5b94:	b4000263 	cbz	x3, 5be0 <fwp_rc_free_arr+0x80>
    5b98:	386268a2 	ldrb	w2, [x5, x2]
    5b9c:	7100085f 	cmp	w2, #0x2
    5ba0:	540001c0 	b.eq	5bd8 <fwp_rc_free_arr+0x78>  // b.none
    5ba4:	7100045f 	cmp	w2, #0x1
    5ba8:	540001c1 	b.ne	5be0 <fwp_rc_free_arr+0x80>  // b.any
    5bac:	29430885 	ldp	w5, w2, [x4, #24]
    5bb0:	92403c21 	and	x1, x1, #0xffff
    5bb4:	9b057c21 	mul	x1, x1, x5
    5bb8:	d360fc21 	lsr	x1, x1, #32
    5bbc:	eb02003f 	cmp	x1, x2
    5bc0:	54000102 	b.cs	5be0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5bc4:	8b010063 	add	x3, x3, x1
    5bc8:	39400061 	ldrb	w1, [x3]
    5bcc:	7100043f 	cmp	w1, #0x1
    5bd0:	54000081 	b.ne	5be0 <fwp_rc_free_arr+0x80>  // b.any
    5bd4:	17fffc23 	b	4c60 <fwp_mem_free>
    5bd8:	72003c3f 	tst	w1, #0xffff
    5bdc:	54ffff60 	b.eq	5bc8 <fwp_rc_free_arr+0x68>  // b.none
    5be0:	d65f03c0 	ret

0000000000005be4 <fwp_rc_dup>:
    5be4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xb80>
    5be8:	91198042 	add	x2, x2, #0x660
    5bec:	f949d841 	ldr	x1, [x2, #5040]
    5bf0:	f949ec43 	ldr	x3, [x2, #5080]
    5bf4:	cb010001 	sub	x1, x0, x1
    5bf8:	eb03403f 	cmp	x1, x3, lsl #16
    5bfc:	540003c2 	b.cs	5c74 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5c00:	d350fc20 	lsr	x0, x1, #16
    5c04:	f949fc44 	ldr	x4, [x2, #5112]
    5c08:	8b000800 	add	x0, x0, x0, lsl #2
    5c0c:	d37df002 	lsl	x2, x0, #3
    5c10:	8b020083 	add	x3, x4, x2
    5c14:	f9401060 	ldr	x0, [x3, #32]
    5c18:	b40002e0 	cbz	x0, 5c74 <fwp_rc_dup+0x90>
    5c1c:	38626882 	ldrb	w2, [x4, x2]
    5c20:	7100085f 	cmp	w2, #0x2
    5c24:	540002a0 	b.eq	5c78 <fwp_rc_dup+0x94>  // b.none
    5c28:	7100045f 	cmp	w2, #0x1
    5c2c:	54000241 	b.ne	5c74 <fwp_rc_dup+0x90>  // b.any
    5c30:	29430864 	ldp	w4, w2, [x3, #24]
    5c34:	92403c21 	and	x1, x1, #0xffff
    5c38:	9b047c21 	mul	x1, x1, x4
    5c3c:	d360fc21 	lsr	x1, x1, #32
    5c40:	eb02003f 	cmp	x1, x2
    5c44:	54000182 	b.cs	5c74 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5c48:	8b010000 	add	x0, x0, x1
    5c4c:	39400001 	ldrb	w1, [x0]
    5c50:	34000121 	cbz	w1, 5c74 <fwp_rc_dup+0x90>
    5c54:	f00000c2 	adrp	x2, 20000 <__data_start>
    5c58:	91018042 	add	x2, x2, #0x60
    5c5c:	b9415043 	ldr	w3, [x2, #336]
    5c60:	35000123 	cbnz	w3, 5c84 <fwp_rc_dup+0xa0>
    5c64:	7103f43f 	cmp	w1, #0xfd
    5c68:	54000168 	b.hi	5c94 <fwp_rc_dup+0xb0>  // b.pmore
    5c6c:	11000421 	add	w1, w1, #0x1
    5c70:	39000001 	strb	w1, [x0]
    5c74:	d65f03c0 	ret
    5c78:	72003c3f 	tst	w1, #0xffff
    5c7c:	54fffe80 	b.eq	5c4c <fwp_rc_dup+0x68>  // b.none
    5c80:	d65f03c0 	ret
    5c84:	f940bc43 	ldr	x3, [x2, #376]
    5c88:	91000463 	add	x3, x3, #0x1
    5c8c:	f900bc43 	str	x3, [x2, #376]
    5c90:	17fffff5 	b	5c64 <fwp_rc_dup+0x80>
    5c94:	17fffb0c 	b	48c4 <fwp_rc_wide_dup>
    5c98:	d503201f 	nop
    5c9c:	d503201f 	nop

0000000000005ca0 <fwp_owned_entry161>:
    5ca0:	d10103ff 	sub	sp, sp, #0x40
    5ca4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5ca8:	f947f442 	ldr	x2, [x2, #4072]
    5cac:	a9027bfd 	stp	x29, x30, [sp, #32]
    5cb0:	910083fd 	add	x29, sp, #0x20
    5cb4:	a90353f3 	stp	x19, x20, [sp, #48]
    5cb8:	f9400043 	ldr	x3, [x2]
    5cbc:	f9000fe3 	str	x3, [sp, #24]
    5cc0:	d2800003 	mov	x3, #0x0                   	// #0
    5cc4:	a9400c01 	ldp	x1, x3, [x0]
    5cc8:	f9400802 	ldr	x2, [x0, #16]
    5ccc:	ab020022 	adds	x2, x1, x2
    5cd0:	540006e6 	b.vs	5dac <fwp_owned_entry161+0x10c>
    5cd4:	910023e1 	add	x1, sp, #0x8
    5cd8:	52800000 	mov	w0, #0x0                   	// #0
    5cdc:	a9008be3 	stp	x3, x2, [sp, #8]
    5ce0:	97ffff1c 	bl	5950 <fwp_data.part.0.constprop.0>
    5ce4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb80>
    5ce8:	91198063 	add	x3, x3, #0x660
    5cec:	aa0003f3 	mov	x19, x0
    5cf0:	f949d861 	ldr	x1, [x3, #5040]
    5cf4:	f949ec60 	ldr	x0, [x3, #5080]
    5cf8:	cb010261 	sub	x1, x19, x1
    5cfc:	eb00403f 	cmp	x1, x0, lsl #16
    5d00:	54000322 	b.cs	5d64 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5d04:	d350fc22 	lsr	x2, x1, #16
    5d08:	f949fc63 	ldr	x3, [x3, #5112]
    5d0c:	8b020842 	add	x2, x2, x2, lsl #2
    5d10:	d37df042 	lsl	x2, x2, #3
    5d14:	8b020060 	add	x0, x3, x2
    5d18:	f9401014 	ldr	x20, [x0, #32]
    5d1c:	b4000254 	cbz	x20, 5d64 <fwp_owned_entry161+0xc4>
    5d20:	38626862 	ldrb	w2, [x3, x2]
    5d24:	7100085f 	cmp	w2, #0x2
    5d28:	54000360 	b.eq	5d94 <fwp_owned_entry161+0xf4>  // b.none
    5d2c:	7100045f 	cmp	w2, #0x1
    5d30:	540001a1 	b.ne	5d64 <fwp_owned_entry161+0xc4>  // b.any
    5d34:	29430002 	ldp	w2, w0, [x0, #24]
    5d38:	92403c21 	and	x1, x1, #0xffff
    5d3c:	9b027c21 	mul	x1, x1, x2
    5d40:	d360fc21 	lsr	x1, x1, #32
    5d44:	eb00003f 	cmp	x1, x0
    5d48:	540000e2 	b.cs	5d64 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5d4c:	8b010294 	add	x20, x20, x1
    5d50:	39400280 	ldrb	w0, [x20]
    5d54:	7103fc1f 	cmp	w0, #0xff
    5d58:	54000240 	b.eq	5da0 <fwp_owned_entry161+0x100>  // b.none
    5d5c:	52800020 	mov	w0, #0x1                   	// #1
    5d60:	39000280 	strb	w0, [x20]
    5d64:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5d68:	f947f400 	ldr	x0, [x0, #4072]
    5d6c:	f9400fe2 	ldr	x2, [sp, #24]
    5d70:	f9400001 	ldr	x1, [x0]
    5d74:	eb010042 	subs	x2, x2, x1
    5d78:	d2800001 	mov	x1, #0x0                   	// #0
    5d7c:	540001a1 	b.ne	5db0 <fwp_owned_entry161+0x110>  // b.any
    5d80:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d84:	aa1303e0 	mov	x0, x19
    5d88:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d8c:	910103ff 	add	sp, sp, #0x40
    5d90:	d65f03c0 	ret
    5d94:	72003c3f 	tst	w1, #0xffff
    5d98:	54fffe61 	b.ne	5d64 <fwp_owned_entry161+0xc4>  // b.any
    5d9c:	17ffffed 	b	5d50 <fwp_owned_entry161+0xb0>
    5da0:	aa1403e0 	mov	x0, x20
    5da4:	97fffb0f 	bl	49e0 <fwp_rc_forget_slot>
    5da8:	17ffffed 	b	5d5c <fwp_owned_entry161+0xbc>
    5dac:	97fff315 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5db0:	97fff298 	bl	2810 <__stack_chk_fail@plt>

0000000000005db4 <e161>:
    5db4:	d10103ff 	sub	sp, sp, #0x40
    5db8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5dbc:	f947f442 	ldr	x2, [x2, #4072]
    5dc0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5dc4:	910083fd 	add	x29, sp, #0x20
    5dc8:	a90353f3 	stp	x19, x20, [sp, #48]
    5dcc:	f9400043 	ldr	x3, [x2]
    5dd0:	f9000fe3 	str	x3, [sp, #24]
    5dd4:	d2800003 	mov	x3, #0x0                   	// #0
    5dd8:	a9400c01 	ldp	x1, x3, [x0]
    5ddc:	f9400802 	ldr	x2, [x0, #16]
    5de0:	ab020022 	adds	x2, x1, x2
    5de4:	54000726 	b.vs	5ec8 <e161+0x114>
    5de8:	910023e1 	add	x1, sp, #0x8
    5dec:	52800000 	mov	w0, #0x0                   	// #0
    5df0:	a9008be3 	stp	x3, x2, [sp, #8]
    5df4:	97fffed7 	bl	5950 <fwp_data.part.0.constprop.0>
    5df8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb80>
    5dfc:	91198063 	add	x3, x3, #0x660
    5e00:	aa0003f3 	mov	x19, x0
    5e04:	f949d861 	ldr	x1, [x3, #5040]
    5e08:	f949ec60 	ldr	x0, [x3, #5080]
    5e0c:	cb010261 	sub	x1, x19, x1
    5e10:	eb00403f 	cmp	x1, x0, lsl #16
    5e14:	54000322 	b.cs	5e78 <e161+0xc4>  // b.hs, b.nlast
    5e18:	d350fc22 	lsr	x2, x1, #16
    5e1c:	f949fc63 	ldr	x3, [x3, #5112]
    5e20:	8b020842 	add	x2, x2, x2, lsl #2
    5e24:	d37df042 	lsl	x2, x2, #3
    5e28:	8b020060 	add	x0, x3, x2
    5e2c:	f9401014 	ldr	x20, [x0, #32]
    5e30:	b4000254 	cbz	x20, 5e78 <e161+0xc4>
    5e34:	38626862 	ldrb	w2, [x3, x2]
    5e38:	7100085f 	cmp	w2, #0x2
    5e3c:	540003a0 	b.eq	5eb0 <e161+0xfc>  // b.none
    5e40:	7100045f 	cmp	w2, #0x1
    5e44:	540001a1 	b.ne	5e78 <e161+0xc4>  // b.any
    5e48:	29430002 	ldp	w2, w0, [x0, #24]
    5e4c:	92403c21 	and	x1, x1, #0xffff
    5e50:	9b027c21 	mul	x1, x1, x2
    5e54:	d360fc21 	lsr	x1, x1, #32
    5e58:	eb00003f 	cmp	x1, x0
    5e5c:	540000e2 	b.cs	5e78 <e161+0xc4>  // b.hs, b.nlast
    5e60:	8b010294 	add	x20, x20, x1
    5e64:	39400280 	ldrb	w0, [x20]
    5e68:	7103fc1f 	cmp	w0, #0xff
    5e6c:	54000280 	b.eq	5ebc <e161+0x108>  // b.none
    5e70:	52800020 	mov	w0, #0x1                   	// #1
    5e74:	39000280 	strb	w0, [x20]
    5e78:	aa1303e0 	mov	x0, x19
    5e7c:	97ffff12 	bl	5ac4 <fwp_rc_share>
    5e80:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5e84:	f947f400 	ldr	x0, [x0, #4072]
    5e88:	f9400fe2 	ldr	x2, [sp, #24]
    5e8c:	f9400001 	ldr	x1, [x0]
    5e90:	eb010042 	subs	x2, x2, x1
    5e94:	d2800001 	mov	x1, #0x0                   	// #0
    5e98:	540001a1 	b.ne	5ecc <e161+0x118>  // b.any
    5e9c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ea0:	aa1303e0 	mov	x0, x19
    5ea4:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ea8:	910103ff 	add	sp, sp, #0x40
    5eac:	d65f03c0 	ret
    5eb0:	72003c3f 	tst	w1, #0xffff
    5eb4:	54fffe21 	b.ne	5e78 <e161+0xc4>  // b.any
    5eb8:	17ffffeb 	b	5e64 <e161+0xb0>
    5ebc:	aa1403e0 	mov	x0, x20
    5ec0:	97fffac8 	bl	49e0 <fwp_rc_forget_slot>
    5ec4:	17ffffeb 	b	5e70 <e161+0xbc>
    5ec8:	97fff2ce 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5ecc:	97fff251 	bl	2810 <__stack_chk_fail@plt>

0000000000005ed0 <fwp_drop0>:
    5ed0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ed4:	910003fd 	mov	x29, sp
    5ed8:	a90153f3 	stp	x19, x20, [sp, #16]
    5edc:	f90013f5 	str	x21, [sp, #32]
    5ee0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    5ee4:	911982b4 	add	x20, x21, #0x660
    5ee8:	f949da81 	ldr	x1, [x20, #5040]
    5eec:	f949ee82 	ldr	x2, [x20, #5080]
    5ef0:	cb010001 	sub	x1, x0, x1
    5ef4:	eb02403f 	cmp	x1, x2, lsl #16
    5ef8:	54000382 	b.cs	5f68 <fwp_drop0+0x98>  // b.hs, b.nlast
    5efc:	d350fc22 	lsr	x2, x1, #16
    5f00:	f949fe84 	ldr	x4, [x20, #5112]
    5f04:	8b020842 	add	x2, x2, x2, lsl #2
    5f08:	d37df042 	lsl	x2, x2, #3
    5f0c:	8b020083 	add	x3, x4, x2
    5f10:	f9401073 	ldr	x19, [x3, #32]
    5f14:	b40002b3 	cbz	x19, 5f68 <fwp_drop0+0x98>
    5f18:	38626882 	ldrb	w2, [x4, x2]
    5f1c:	7100085f 	cmp	w2, #0x2
    5f20:	540002c0 	b.eq	5f78 <fwp_drop0+0xa8>  // b.none
    5f24:	7100045f 	cmp	w2, #0x1
    5f28:	54000201 	b.ne	5f68 <fwp_drop0+0x98>  // b.any
    5f2c:	29430864 	ldp	w4, w2, [x3, #24]
    5f30:	92403c21 	and	x1, x1, #0xffff
    5f34:	9b047c21 	mul	x1, x1, x4
    5f38:	d360fc21 	lsr	x1, x1, #32
    5f3c:	eb02003f 	cmp	x1, x2
    5f40:	54000142 	b.cs	5f68 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f44:	8b010273 	add	x19, x19, x1
    5f48:	39400261 	ldrb	w1, [x19]
    5f4c:	340000e1 	cbz	w1, 5f68 <fwp_drop0+0x98>
    5f50:	7100043f 	cmp	w1, #0x1
    5f54:	540001e0 	b.eq	5f90 <fwp_drop0+0xc0>  // b.none
    5f58:	7103fc3f 	cmp	w1, #0xff
    5f5c:	540002e0 	b.eq	5fb8 <fwp_drop0+0xe8>  // b.none
    5f60:	51000421 	sub	w1, w1, #0x1
    5f64:	39000261 	strb	w1, [x19]
    5f68:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f6c:	f94013f5 	ldr	x21, [sp, #32]
    5f70:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f74:	d65f03c0 	ret
    5f78:	72003c3f 	tst	w1, #0xffff
    5f7c:	54fffe60 	b.eq	5f48 <fwp_drop0+0x78>  // b.none
    5f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f84:	f94013f5 	ldr	x21, [sp, #32]
    5f88:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f8c:	d65f03c0 	ret
    5f90:	f9400813 	ldr	x19, [x0, #16]
    5f94:	97fffef3 	bl	5b60 <fwp_rc_free_arr>
    5f98:	911982a0 	add	x0, x21, #0x660
    5f9c:	f949d801 	ldr	x1, [x0, #5040]
    5fa0:	f949ec00 	ldr	x0, [x0, #5080]
    5fa4:	cb010261 	sub	x1, x19, x1
    5fa8:	eb00403f 	cmp	x1, x0, lsl #16
    5fac:	54fffde2 	b.cs	5f68 <fwp_drop0+0x98>  // b.hs, b.nlast
    5fb0:	aa1303e0 	mov	x0, x19
    5fb4:	17ffffd2 	b	5efc <fwp_drop0+0x2c>
    5fb8:	ca534660 	eor	x0, x19, x19, lsr #17
    5fbc:	911982b5 	add	x21, x21, #0x660
    5fc0:	ca402400 	eor	x0, x0, x0, lsr #9
    5fc4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5fc8:	f94a2400 	ldr	x0, [x0, #5192]
    5fcc:	b5000080 	cbnz	x0, 5fdc <fwp_drop0+0x10c>
    5fd0:	14000010 	b	6010 <fwp_drop0+0x140>
    5fd4:	f9400800 	ldr	x0, [x0, #16]
    5fd8:	b40001c0 	cbz	x0, 6010 <fwp_drop0+0x140>
    5fdc:	f9400001 	ldr	x1, [x0]
    5fe0:	eb13003f 	cmp	x1, x19
    5fe4:	54ffff81 	b.ne	5fd4 <fwp_drop0+0x104>  // b.any
    5fe8:	f9400401 	ldr	x1, [x0, #8]
    5fec:	d1000421 	sub	x1, x1, #0x1
    5ff0:	f9000401 	str	x1, [x0, #8]
    5ff4:	f103f83f 	cmp	x1, #0xfe
    5ff8:	54fffb81 	b.ne	5f68 <fwp_drop0+0x98>  // b.any
    5ffc:	aa1303e0 	mov	x0, x19
    6000:	97fffa78 	bl	49e0 <fwp_rc_forget_slot>
    6004:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6008:	39000260 	strb	w0, [x19]
    600c:	17ffffd7 	b	5f68 <fwp_drop0+0x98>
    6010:	b0000020 	adrp	x0, b000 <__divti3+0x70>
    6014:	912dc000 	add	x0, x0, #0xb70
    6018:	97fff5da 	bl	3780 <fwp_trap>
    601c:	d503201f 	nop

0000000000006020 <fwp_arg_drop12>:
    6020:	7100003f 	cmp	w1, #0x0
    6024:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6028:	54000041 	b.ne	6030 <fwp_arg_drop12+0x10>  // b.any
    602c:	d65f03c0 	ret
    6030:	f9400000 	ldr	x0, [x0]
    6034:	17ffffa7 	b	5ed0 <fwp_drop0>
    6038:	d503201f 	nop
    603c:	d503201f 	nop

0000000000006040 <fwp_drop1>:
    6040:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6044:	910003fd 	mov	x29, sp
    6048:	a90153f3 	stp	x19, x20, [sp, #16]
    604c:	f90013f5 	str	x21, [sp, #32]
    6050:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xb80>
    6054:	911982b4 	add	x20, x21, #0x660
    6058:	f949da81 	ldr	x1, [x20, #5040]
    605c:	f949ee82 	ldr	x2, [x20, #5080]
    6060:	cb010001 	sub	x1, x0, x1
    6064:	eb02403f 	cmp	x1, x2, lsl #16
    6068:	54000382 	b.cs	60d8 <fwp_drop1+0x98>  // b.hs, b.nlast
    606c:	d350fc22 	lsr	x2, x1, #16
    6070:	f949fe84 	ldr	x4, [x20, #5112]
    6074:	8b020842 	add	x2, x2, x2, lsl #2
    6078:	d37df042 	lsl	x2, x2, #3
    607c:	8b020083 	add	x3, x4, x2
    6080:	f9401073 	ldr	x19, [x3, #32]
    6084:	b40002b3 	cbz	x19, 60d8 <fwp_drop1+0x98>
    6088:	38626882 	ldrb	w2, [x4, x2]
    608c:	7100085f 	cmp	w2, #0x2
    6090:	540002c0 	b.eq	60e8 <fwp_drop1+0xa8>  // b.none
    6094:	7100045f 	cmp	w2, #0x1
    6098:	54000201 	b.ne	60d8 <fwp_drop1+0x98>  // b.any
    609c:	29430864 	ldp	w4, w2, [x3, #24]
    60a0:	92403c21 	and	x1, x1, #0xffff
    60a4:	9b047c21 	mul	x1, x1, x4
    60a8:	d360fc21 	lsr	x1, x1, #32
    60ac:	eb02003f 	cmp	x1, x2
    60b0:	54000142 	b.cs	60d8 <fwp_drop1+0x98>  // b.hs, b.nlast
    60b4:	8b010273 	add	x19, x19, x1
    60b8:	39400261 	ldrb	w1, [x19]
    60bc:	340000e1 	cbz	w1, 60d8 <fwp_drop1+0x98>
    60c0:	7100043f 	cmp	w1, #0x1
    60c4:	540001e0 	b.eq	6100 <fwp_drop1+0xc0>  // b.none
    60c8:	7103fc3f 	cmp	w1, #0xff
    60cc:	540002e0 	b.eq	6128 <fwp_drop1+0xe8>  // b.none
    60d0:	51000421 	sub	w1, w1, #0x1
    60d4:	39000261 	strb	w1, [x19]
    60d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    60dc:	f94013f5 	ldr	x21, [sp, #32]
    60e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60e4:	d65f03c0 	ret
    60e8:	72003c3f 	tst	w1, #0xffff
    60ec:	54fffe60 	b.eq	60b8 <fwp_drop1+0x78>  // b.none
    60f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    60f4:	f94013f5 	ldr	x21, [sp, #32]
    60f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60fc:	d65f03c0 	ret
    6100:	f9400813 	ldr	x19, [x0, #16]
    6104:	97fffe97 	bl	5b60 <fwp_rc_free_arr>
    6108:	911982a0 	add	x0, x21, #0x660
    610c:	f949d801 	ldr	x1, [x0, #5040]
    6110:	f949ec00 	ldr	x0, [x0, #5080]
    6114:	cb010261 	sub	x1, x19, x1
    6118:	eb00403f 	cmp	x1, x0, lsl #16
    611c:	54fffde2 	b.cs	60d8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6120:	aa1303e0 	mov	x0, x19
    6124:	17ffffd2 	b	606c <fwp_drop1+0x2c>
    6128:	ca534660 	eor	x0, x19, x19, lsr #17
    612c:	911982b5 	add	x21, x21, #0x660
    6130:	ca402400 	eor	x0, x0, x0, lsr #9
    6134:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6138:	f94a2400 	ldr	x0, [x0, #5192]
    613c:	b5000080 	cbnz	x0, 614c <fwp_drop1+0x10c>
    6140:	14000010 	b	6180 <fwp_drop1+0x140>
    6144:	f9400800 	ldr	x0, [x0, #16]
    6148:	b40001c0 	cbz	x0, 6180 <fwp_drop1+0x140>
    614c:	f9400001 	ldr	x1, [x0]
    6150:	eb13003f 	cmp	x1, x19
    6154:	54ffff81 	b.ne	6144 <fwp_drop1+0x104>  // b.any
    6158:	f9400401 	ldr	x1, [x0, #8]
    615c:	d1000421 	sub	x1, x1, #0x1
    6160:	f9000401 	str	x1, [x0, #8]
    6164:	f103f83f 	cmp	x1, #0xfe
    6168:	54fffb81 	b.ne	60d8 <fwp_drop1+0x98>  // b.any
    616c:	aa1303e0 	mov	x0, x19
    6170:	97fffa1c 	bl	49e0 <fwp_rc_forget_slot>
    6174:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6178:	39000260 	strb	w0, [x19]
    617c:	17ffffd7 	b	60d8 <fwp_drop1+0x98>
    6180:	b0000020 	adrp	x0, b000 <__divti3+0x70>
    6184:	912dc000 	add	x0, x0, #0xb70
    6188:	97fff57e 	bl	3780 <fwp_trap>
    618c:	d503201f 	nop

0000000000006190 <fwp_closure_drop>:
    6190:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xb80>
    6194:	911980a4 	add	x4, x5, #0x660
    6198:	aa0003e1 	mov	x1, x0
    619c:	f949d882 	ldr	x2, [x4, #5040]
    61a0:	f949ec80 	ldr	x0, [x4, #5080]
    61a4:	cb020022 	sub	x2, x1, x2
    61a8:	eb00405f 	cmp	x2, x0, lsl #16
    61ac:	54000662 	b.cs	6278 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    61b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61b4:	d350fc43 	lsr	x3, x2, #16
    61b8:	910003fd 	mov	x29, sp
    61bc:	8b030863 	add	x3, x3, x3, lsl #2
    61c0:	f949fc84 	ldr	x4, [x4, #5112]
    61c4:	d37df063 	lsl	x3, x3, #3
    61c8:	f9000bf3 	str	x19, [sp, #16]
    61cc:	8b030080 	add	x0, x4, x3
    61d0:	f9401013 	ldr	x19, [x0, #32]
    61d4:	b40002b3 	cbz	x19, 6228 <fwp_closure_drop+0x98>
    61d8:	38636883 	ldrb	w3, [x4, x3]
    61dc:	7100087f 	cmp	w3, #0x2
    61e0:	54000420 	b.eq	6264 <fwp_closure_drop+0xd4>  // b.none
    61e4:	7100047f 	cmp	w3, #0x1
    61e8:	54000201 	b.ne	6228 <fwp_closure_drop+0x98>  // b.any
    61ec:	29430003 	ldp	w3, w0, [x0, #24]
    61f0:	92403c42 	and	x2, x2, #0xffff
    61f4:	9b037c42 	mul	x2, x2, x3
    61f8:	d360fc42 	lsr	x2, x2, #32
    61fc:	eb00005f 	cmp	x2, x0
    6200:	54000142 	b.cs	6228 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6204:	8b020273 	add	x19, x19, x2
    6208:	39400260 	ldrb	w0, [x19]
    620c:	340000e0 	cbz	w0, 6228 <fwp_closure_drop+0x98>
    6210:	7100041f 	cmp	w0, #0x1
    6214:	54000100 	b.eq	6234 <fwp_closure_drop+0xa4>  // b.none
    6218:	7103fc1f 	cmp	w0, #0xff
    621c:	54000300 	b.eq	627c <fwp_closure_drop+0xec>  // b.none
    6220:	51000400 	sub	w0, w0, #0x1
    6224:	39000260 	strb	w0, [x19]
    6228:	f9400bf3 	ldr	x19, [sp, #16]
    622c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6230:	d65f03c0 	ret
    6234:	d53bd040 	mrs	x0, tpidr_el0
    6238:	91400000 	add	x0, x0, #0x0, lsl #12
    623c:	91004000 	add	x0, x0, #0x10
    6240:	f9400000 	ldr	x0, [x0]
    6244:	b4000080 	cbz	x0, 6254 <fwp_closure_drop+0xc4>
    6248:	f9400bf3 	ldr	x19, [sp, #16]
    624c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6250:	17fff565 	b	37e4 <fwp_closure_drop_push>
    6254:	f9400bf3 	ldr	x19, [sp, #16]
    6258:	aa0103e0 	mov	x0, x1
    625c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6260:	17fff5d0 	b	39a0 <fwp_closure_drop.part.0>
    6264:	72003c5f 	tst	w2, #0xffff
    6268:	54fffd00 	b.eq	6208 <fwp_closure_drop+0x78>  // b.none
    626c:	f9400bf3 	ldr	x19, [sp, #16]
    6270:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6274:	d65f03c0 	ret
    6278:	d65f03c0 	ret
    627c:	ca534660 	eor	x0, x19, x19, lsr #17
    6280:	911980a5 	add	x5, x5, #0x660
    6284:	ca402400 	eor	x0, x0, x0, lsr #9
    6288:	8b200ca0 	add	x0, x5, w0, uxtb #3
    628c:	f94a2400 	ldr	x0, [x0, #5192]
    6290:	b5000080 	cbnz	x0, 62a0 <fwp_closure_drop+0x110>
    6294:	14000010 	b	62d4 <fwp_closure_drop+0x144>
    6298:	f9400800 	ldr	x0, [x0, #16]
    629c:	b40001c0 	cbz	x0, 62d4 <fwp_closure_drop+0x144>
    62a0:	f9400001 	ldr	x1, [x0]
    62a4:	eb13003f 	cmp	x1, x19
    62a8:	54ffff81 	b.ne	6298 <fwp_closure_drop+0x108>  // b.any
    62ac:	f9400401 	ldr	x1, [x0, #8]
    62b0:	d1000421 	sub	x1, x1, #0x1
    62b4:	f9000401 	str	x1, [x0, #8]
    62b8:	f103f83f 	cmp	x1, #0xfe
    62bc:	54fffb61 	b.ne	6228 <fwp_closure_drop+0x98>  // b.any
    62c0:	aa1303e0 	mov	x0, x19
    62c4:	97fff9c7 	bl	49e0 <fwp_rc_forget_slot>
    62c8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62cc:	39000260 	strb	w0, [x19]
    62d0:	17ffffd6 	b	6228 <fwp_closure_drop+0x98>
    62d4:	b0000020 	adrp	x0, b000 <__divti3+0x70>
    62d8:	912dc000 	add	x0, x0, #0xb70
    62dc:	97fff529 	bl	3780 <fwp_trap>

00000000000062e0 <fwp_owned_tape_release>:
    62e0:	b4000940 	cbz	x0, 6408 <fwp_owned_tape_release+0x128>
    62e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    62e8:	910003fd 	mov	x29, sp
    62ec:	a90153f3 	stp	x19, x20, [sp, #16]
    62f0:	aa0003f3 	mov	x19, x0
    62f4:	f9400000 	ldr	x0, [x0]
    62f8:	b4000060 	cbz	x0, 6304 <fwp_owned_tape_release+0x24>
    62fc:	f9400661 	ldr	x1, [x19, #8]
    6300:	f9000401 	str	x1, [x0, #8]
    6304:	f9400661 	ldr	x1, [x19, #8]
    6308:	b4000041 	cbz	x1, 6310 <fwp_owned_tape_release+0x30>
    630c:	f9000020 	str	x0, [x1]
    6310:	f9400a60 	ldr	x0, [x19, #16]
    6314:	f9403401 	ldr	x1, [x0, #104]
    6318:	b40005c1 	cbz	x1, 63d0 <fwp_owned_tape_release+0xf0>
    631c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6320:	eb00005f 	cmp	x2, x0
    6324:	540002ed 	b.le	6380 <fwp_owned_tape_release+0xa0>
    6328:	d2800014 	mov	x20, #0x0                   	// #0
    632c:	f90013f5 	str	x21, [sp, #32]
    6330:	d2800015 	mov	x21, #0x0                   	// #0
    6334:	d503201f 	nop
    6338:	f9402260 	ldr	x0, [x19, #64]
    633c:	910006b5 	add	x21, x21, #0x1
    6340:	f8746800 	ldr	x0, [x0, x20]
    6344:	d63f0020 	blr	x1
    6348:	f9402260 	ldr	x0, [x19, #64]
    634c:	f9400a61 	ldr	x1, [x19, #16]
    6350:	8b140000 	add	x0, x0, x20
    6354:	91004294 	add	x20, x20, #0x10
    6358:	f9400400 	ldr	x0, [x0, #8]
    635c:	f9403421 	ldr	x1, [x1, #104]
    6360:	d63f0020 	blr	x1
    6364:	a9450261 	ldp	x1, x0, [x19, #80]
    6368:	cb010000 	sub	x0, x0, x1
    636c:	eb15001f 	cmp	x0, x21
    6370:	f9400a60 	ldr	x0, [x19, #16]
    6374:	f9403401 	ldr	x1, [x0, #104]
    6378:	54fffe0c 	b.gt	6338 <fwp_owned_tape_release+0x58>
    637c:	f94013f5 	ldr	x21, [sp, #32]
    6380:	f9403663 	ldr	x3, [x19, #104]
    6384:	f9401262 	ldr	x2, [x19, #32]
    6388:	f100007f 	cmp	x3, #0x0
    638c:	540001ed 	b.le	63c8 <fwp_owned_tape_release+0xe8>
    6390:	d2800014 	mov	x20, #0x0                   	// #0
    6394:	d503201f 	nop
    6398:	f9402660 	ldr	x0, [x19, #72]
    639c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    63a0:	eb02001f 	cmp	x0, x2
    63a4:	540000c0 	b.eq	63bc <fwp_owned_tape_release+0xdc>  // b.none
    63a8:	d63f0020 	blr	x1
    63ac:	f9400a60 	ldr	x0, [x19, #16]
    63b0:	f9401262 	ldr	x2, [x19, #32]
    63b4:	f9403663 	ldr	x3, [x19, #104]
    63b8:	f9403401 	ldr	x1, [x0, #104]
    63bc:	91000694 	add	x20, x20, #0x1
    63c0:	eb14007f 	cmp	x3, x20
    63c4:	54fffeac 	b.gt	6398 <fwp_owned_tape_release+0xb8>
    63c8:	aa0203e0 	mov	x0, x2
    63cc:	d63f0020 	blr	x1
    63d0:	f9401660 	ldr	x0, [x19, #40]
    63d4:	97ffff6f 	bl	6190 <fwp_closure_drop>
    63d8:	f9401a60 	ldr	x0, [x19, #48]
    63dc:	97ffff6d 	bl	6190 <fwp_closure_drop>
    63e0:	f9401e60 	ldr	x0, [x19, #56]
    63e4:	97ffff6b 	bl	6190 <fwp_closure_drop>
    63e8:	f9402260 	ldr	x0, [x19, #64]
    63ec:	97fffa1d 	bl	4c60 <fwp_mem_free>
    63f0:	f9402660 	ldr	x0, [x19, #72]
    63f4:	97fffa1b 	bl	4c60 <fwp_mem_free>
    63f8:	aa1303e0 	mov	x0, x19
    63fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6400:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6404:	17fffa17 	b	4c60 <fwp_mem_free>
    6408:	d65f03c0 	ret
    640c:	d503201f 	nop

0000000000006410 <fwp_tape_finish>:
    6410:	d10203ff 	sub	sp, sp, #0x80
    6414:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    6418:	f947f421 	ldr	x1, [x1, #4072]
    641c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6420:	910103fd 	add	x29, sp, #0x40
    6424:	a9065bf5 	stp	x21, x22, [sp, #96]
    6428:	a90763f7 	stp	x23, x24, [sp, #112]
    642c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6430:	910182f6 	add	x22, x23, #0x60
    6434:	f9400022 	ldr	x2, [x1]
    6438:	f9001fe2 	str	x2, [sp, #56]
    643c:	d2800002 	mov	x2, #0x0                   	// #0
    6440:	910402c0 	add	x0, x22, #0x100
    6444:	97fff7e4 	bl	43d4 <fwp_tape_buffers_dispose>
    6448:	f9009edf 	str	xzr, [x22, #312]
    644c:	f9406ec0 	ldr	x0, [x22, #216]
    6450:	f100001f 	cmp	x0, #0x0
    6454:	5400034d 	b.le	64bc <fwp_tape_finish+0xac>
    6458:	910003f8 	mov	x24, sp
    645c:	d2800015 	mov	x21, #0x0                   	// #0
    6460:	a90553f3 	stp	x19, x20, [sp, #80]
    6464:	d2800014 	mov	x20, #0x0                   	// #0
    6468:	91000694 	add	x20, x20, #0x1
    646c:	f94046d3 	ldr	x19, [x22, #136]
    6470:	8b150273 	add	x19, x19, x21
    6474:	9101a2b5 	add	x21, x21, #0x68
    6478:	aa1303e0 	mov	x0, x19
    647c:	97fff2c6 	bl	2f94 <fwp_tape_unlink_scope>
    6480:	aa1803e0 	mov	x0, x24
    6484:	a9440663 	ldp	x3, x1, [x19, #64]
    6488:	f9001be1 	str	x1, [sp, #48]
    648c:	f9400e62 	ldr	x2, [x19, #24]
    6490:	a9020be3 	stp	x3, x2, [sp, #32]
    6494:	ad410261 	ldp	q1, q0, [x19, #32]
    6498:	ad0003e1 	stp	q1, q0, [sp]
    649c:	97fff7ce 	bl	43d4 <fwp_tape_buffers_dispose>
    64a0:	f9403260 	ldr	x0, [x19, #96]
    64a4:	97ffff8f 	bl	62e0 <fwp_owned_tape_release>
    64a8:	f900327f 	str	xzr, [x19, #96]
    64ac:	f9406ec0 	ldr	x0, [x22, #216]
    64b0:	eb14001f 	cmp	x0, x20
    64b4:	54fffdac 	b.gt	6468 <fwp_tape_finish+0x58>
    64b8:	a94553f3 	ldp	x19, x20, [sp, #80]
    64bc:	910182e0 	add	x0, x23, #0x60
    64c0:	f9404400 	ldr	x0, [x0, #136]
    64c4:	b4000040 	cbz	x0, 64cc <fwp_tape_finish+0xbc>
    64c8:	97fff7a2 	bl	4350 <ad_raw_free.part.0>
    64cc:	910182f7 	add	x23, x23, #0x60
    64d0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    64d4:	f947f400 	ldr	x0, [x0, #4072]
    64d8:	f90046ff 	str	xzr, [x23, #136]
    64dc:	f9006eff 	str	xzr, [x23, #216]
    64e0:	f900a2ff 	str	xzr, [x23, #320]
    64e4:	f900c2ff 	str	xzr, [x23, #384]
    64e8:	f9401fe2 	ldr	x2, [sp, #56]
    64ec:	f9400001 	ldr	x1, [x0]
    64f0:	eb010042 	subs	x2, x2, x1
    64f4:	d2800001 	mov	x1, #0x0                   	// #0
    64f8:	540000c1 	b.ne	6510 <fwp_tape_finish+0x100>  // b.any
    64fc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6500:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6504:	a94763f7 	ldp	x23, x24, [sp, #112]
    6508:	910203ff 	add	sp, sp, #0x80
    650c:	d65f03c0 	ret
    6510:	a90553f3 	stp	x19, x20, [sp, #80]
    6514:	97fff0bf 	bl	2810 <__stack_chk_fail@plt>
    6518:	d503201f 	nop
    651c:	d503201f 	nop

0000000000006520 <fwp_tape_scope_release>:
    6520:	d10243ff 	sub	sp, sp, #0x90
    6524:	a9047bfd 	stp	x29, x30, [sp, #64]
    6528:	910103fd 	add	x29, sp, #0x40
    652c:	a90553f3 	stp	x19, x20, [sp, #80]
    6530:	aa0003f4 	mov	x20, x0
    6534:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6538:	f947f400 	ldr	x0, [x0, #4072]
    653c:	b9400285 	ldr	w5, [x20]
    6540:	f9400001 	ldr	x1, [x0]
    6544:	f9001fe1 	str	x1, [sp, #56]
    6548:	d2800001 	mov	x1, #0x0                   	// #0
    654c:	37f806c5 	tbnz	w5, #31, 6624 <fwp_tape_scope_release+0x104>
    6550:	a90763f7 	stp	x23, x24, [sp, #112]
    6554:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6558:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    655c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6560:	d00000d3 	adrp	x19, 20000 <__data_start>
    6564:	910003f7 	mov	x23, sp
    6568:	91018273 	add	x19, x19, #0x60
    656c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6570:	a9065bf5 	stp	x21, x22, [sp, #96]
    6574:	52800d16 	mov	w22, #0x68                  	// #104
    6578:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    657c:	f90043f9 	str	x25, [sp, #128]
    6580:	14000006 	b	6598 <fwp_tape_scope_release+0x78>
    6584:	97fff794 	bl	43d4 <fwp_tape_buffers_dispose>
    6588:	aa1903e0 	mov	x0, x25
    658c:	97ffff55 	bl	62e0 <fwp_owned_tape_release>
    6590:	b9400285 	ldr	w5, [x20]
    6594:	37f80425 	tbnz	w5, #31, 6618 <fwp_tape_scope_release+0xf8>
    6598:	f9404666 	ldr	x6, [x19, #136]
    659c:	9b367ca5 	smull	x5, w5, w22
    65a0:	8b0500c0 	add	x0, x6, x5
    65a4:	97fff27c 	bl	2f94 <fwp_tape_unlink_scope>
    65a8:	ad410001 	ldp	q1, q0, [x0, #32]
    65ac:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    65b0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    65b4:	f9400c03 	ldr	x3, [x0, #24]
    65b8:	ad0003e1 	stp	q1, q0, [sp]
    65bc:	b86568c1 	ldr	w1, [x6, x5]
    65c0:	a9440804 	ldp	x4, x2, [x0, #64]
    65c4:	b900041f 	str	wzr, [x0, #4]
    65c8:	f9403019 	ldr	x25, [x0, #96]
    65cc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    65d0:	f9000c1f 	str	xzr, [x0, #24]
    65d4:	a9020fe4 	stp	x4, x3, [sp, #32]
    65d8:	f9001be2 	str	x2, [sp, #48]
    65dc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    65e0:	f900301f 	str	xzr, [x0, #96]
    65e4:	6b15003f 	cmp	w1, w21
    65e8:	540000e8 	b.hi	6604 <fwp_tape_scope_release+0xe4>  // b.pmore
    65ec:	9343fca5 	asr	x5, x5, #3
    65f0:	f940c260 	ldr	x0, [x19, #384]
    65f4:	9b187ca5 	mul	x5, x5, x24
    65f8:	eb0000bf 	cmp	x5, x0
    65fc:	5400004a 	b.ge	6604 <fwp_tape_scope_release+0xe4>  // b.tcont
    6600:	f900c265 	str	x5, [x19, #384]
    6604:	aa1703e0 	mov	x0, x23
    6608:	b5fffbf9 	cbnz	x25, 6584 <fwp_tape_scope_release+0x64>
    660c:	97fff7ba 	bl	44f4 <fwp_tape_buffers_release>
    6610:	b9400285 	ldr	w5, [x20]
    6614:	36fffc25 	tbz	w5, #31, 6598 <fwp_tape_scope_release+0x78>
    6618:	a9465bf5 	ldp	x21, x22, [sp, #96]
    661c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6620:	f94043f9 	ldr	x25, [sp, #128]
    6624:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6628:	f947f400 	ldr	x0, [x0, #4072]
    662c:	f9401fe2 	ldr	x2, [sp, #56]
    6630:	f9400001 	ldr	x1, [x0]
    6634:	eb010042 	subs	x2, x2, x1
    6638:	d2800001 	mov	x1, #0x0                   	// #0
    663c:	540000a1 	b.ne	6650 <fwp_tape_scope_release+0x130>  // b.any
    6640:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6644:	a94553f3 	ldp	x19, x20, [sp, #80]
    6648:	910243ff 	add	sp, sp, #0x90
    664c:	d65f03c0 	ret
    6650:	a9065bf5 	stp	x21, x22, [sp, #96]
    6654:	a90763f7 	stp	x23, x24, [sp, #112]
    6658:	f90043f9 	str	x25, [sp, #128]
    665c:	97fff06d 	bl	2810 <__stack_chk_fail@plt>

0000000000006660 <fwp_task_dispose>:
    6660:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6664:	910003fd 	mov	x29, sp
    6668:	f9000bf3 	str	x19, [sp, #16]
    666c:	aa0003f3 	mov	x19, x0
    6670:	39414000 	ldrb	w0, [x0, #80]
    6674:	36000720 	tbz	w0, #0, 6758 <fwp_task_dispose+0xf8>
    6678:	f9400a60 	ldr	x0, [x19, #16]
    667c:	b50006e0 	cbnz	x0, 6758 <fwp_task_dispose+0xf8>
    6680:	a9478660 	ldp	x0, x1, [x19, #120]
    6684:	39014e7f 	strb	wzr, [x19, #83]
    6688:	f9003e7f 	str	xzr, [x19, #120]
    668c:	f100003f 	cmp	x1, #0x0
    6690:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6694:	54000040 	b.eq	669c <fwp_task_dispose+0x3c>  // b.none
    6698:	d63f0020 	blr	x1
    669c:	f9405660 	ldr	x0, [x19, #168]
    66a0:	97fff970 	bl	4c60 <fwp_mem_free>
    66a4:	f900567f 	str	xzr, [x19, #168]
    66a8:	b9405e60 	ldr	w0, [x19, #92]
    66ac:	7100041f 	cmp	w0, #0x1
    66b0:	54000420 	b.eq	6734 <fwp_task_dispose+0xd4>  // b.none
    66b4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    66b8:	91198042 	add	x2, x2, #0x660
    66bc:	f949d840 	ldr	x0, [x2, #5040]
    66c0:	f949ec41 	ldr	x1, [x2, #5080]
    66c4:	cb000260 	sub	x0, x19, x0
    66c8:	eb01401f 	cmp	x0, x1, lsl #16
    66cc:	540002e2 	b.cs	6728 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    66d0:	d350fc01 	lsr	x1, x0, #16
    66d4:	f949fc44 	ldr	x4, [x2, #5112]
    66d8:	8b010821 	add	x1, x1, x1, lsl #2
    66dc:	d37df021 	lsl	x1, x1, #3
    66e0:	8b010083 	add	x3, x4, x1
    66e4:	f9401062 	ldr	x2, [x3, #32]
    66e8:	b4000202 	cbz	x2, 6728 <fwp_task_dispose+0xc8>
    66ec:	38616881 	ldrb	w1, [x4, x1]
    66f0:	7100083f 	cmp	w1, #0x2
    66f4:	54000280 	b.eq	6744 <fwp_task_dispose+0xe4>  // b.none
    66f8:	7100043f 	cmp	w1, #0x1
    66fc:	54000161 	b.ne	6728 <fwp_task_dispose+0xc8>  // b.any
    6700:	29430464 	ldp	w4, w1, [x3, #24]
    6704:	92403c00 	and	x0, x0, #0xffff
    6708:	9b047c00 	mul	x0, x0, x4
    670c:	d360fc00 	lsr	x0, x0, #32
    6710:	eb01001f 	cmp	x0, x1
    6714:	540000a2 	b.cs	6728 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6718:	8b000042 	add	x2, x2, x0
    671c:	39400040 	ldrb	w0, [x2]
    6720:	7100041f 	cmp	w0, #0x1
    6724:	54000080 	b.eq	6734 <fwp_task_dispose+0xd4>  // b.none
    6728:	f9400bf3 	ldr	x19, [sp, #16]
    672c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6730:	d65f03c0 	ret
    6734:	aa1303e0 	mov	x0, x19
    6738:	f9400bf3 	ldr	x19, [sp, #16]
    673c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6740:	17fff948 	b	4c60 <fwp_mem_free>
    6744:	72003c1f 	tst	w0, #0xffff
    6748:	54fffea0 	b.eq	671c <fwp_task_dispose+0xbc>  // b.none
    674c:	f9400bf3 	ldr	x19, [sp, #16]
    6750:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6754:	d65f03c0 	ret
    6758:	97fff042 	bl	2860 <abort@plt>
    675c:	d503201f 	nop

0000000000006760 <fwp_free_zombie>:
    6760:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6764:	910003fd 	mov	x29, sp
    6768:	a90153f3 	stp	x19, x20, [sp, #16]
    676c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6770:	91018281 	add	x1, x20, #0x60
    6774:	f940c433 	ldr	x19, [x1, #392]
    6778:	b4000333 	cbz	x19, 67dc <fwp_free_zombie+0x7c>
    677c:	f9404c20 	ldr	x0, [x1, #152]
    6780:	eb00027f 	cmp	x19, x0
    6784:	540002c0 	b.eq	67dc <fwp_free_zombie+0x7c>  // b.none
    6788:	b9419022 	ldr	w2, [x1, #400]
    678c:	f9400a60 	ldr	x0, [x19, #16]
    6790:	7100fc5f 	cmp	w2, #0x3f
    6794:	5400078c 	b.gt	6884 <fwp_free_zombie+0x124>
    6798:	91068023 	add	x3, x1, #0x1a0
    679c:	11000444 	add	w4, w2, #0x1
    67a0:	b9019024 	str	w4, [x1, #400]
    67a4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67a8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    67ac:	a9530261 	ldp	x1, x0, [x19, #304]
    67b0:	b4000741 	cbz	x1, 6898 <fwp_free_zombie+0x138>
    67b4:	f9009c20 	str	x0, [x1, #312]
    67b8:	b4000040 	cbz	x0, 67c0 <fwp_free_zombie+0x60>
    67bc:	f9009801 	str	x1, [x0, #304]
    67c0:	91018294 	add	x20, x20, #0x60
    67c4:	b9405e60 	ldr	w0, [x19, #92]
    67c8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    67cc:	f900c69f 	str	xzr, [x20, #392]
    67d0:	34000140 	cbz	w0, 67f8 <fwp_free_zombie+0x98>
    67d4:	7100041f 	cmp	w0, #0x1
    67d8:	54000080 	b.eq	67e8 <fwp_free_zombie+0x88>  // b.none
    67dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    67e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67e4:	d65f03c0 	ret
    67e8:	aa1303e0 	mov	x0, x19
    67ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    67f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67f4:	17ffff9b 	b	6660 <fwp_task_dispose>
    67f8:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xb80>
    67fc:	91198082 	add	x2, x4, #0x660
    6800:	f949d841 	ldr	x1, [x2, #5040]
    6804:	f949ec40 	ldr	x0, [x2, #5080]
    6808:	cb010261 	sub	x1, x19, x1
    680c:	eb00403f 	cmp	x1, x0, lsl #16
    6810:	54fffe62 	b.cs	67dc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6814:	d350fc20 	lsr	x0, x1, #16
    6818:	f949fc43 	ldr	x3, [x2, #5112]
    681c:	8b000800 	add	x0, x0, x0, lsl #2
    6820:	d37df000 	lsl	x0, x0, #3
    6824:	8b000062 	add	x2, x3, x0
    6828:	f9401054 	ldr	x20, [x2, #32]
    682c:	b4fffd94 	cbz	x20, 67dc <fwp_free_zombie+0x7c>
    6830:	38606860 	ldrb	w0, [x3, x0]
    6834:	7100081f 	cmp	w0, #0x2
    6838:	54000360 	b.eq	68a4 <fwp_free_zombie+0x144>  // b.none
    683c:	7100041f 	cmp	w0, #0x1
    6840:	54fffce1 	b.ne	67dc <fwp_free_zombie+0x7c>  // b.any
    6844:	29430043 	ldp	w3, w0, [x2, #24]
    6848:	92403c21 	and	x1, x1, #0xffff
    684c:	9b037c21 	mul	x1, x1, x3
    6850:	d360fc21 	lsr	x1, x1, #32
    6854:	eb00003f 	cmp	x1, x0
    6858:	54fffc22 	b.cs	67dc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    685c:	8b010294 	add	x20, x20, x1
    6860:	39400280 	ldrb	w0, [x20]
    6864:	34fffbc0 	cbz	w0, 67dc <fwp_free_zombie+0x7c>
    6868:	7100041f 	cmp	w0, #0x1
    686c:	54fffbe0 	b.eq	67e8 <fwp_free_zombie+0x88>  // b.none
    6870:	7103fc1f 	cmp	w0, #0xff
    6874:	540001e0 	b.eq	68b0 <fwp_free_zombie+0x150>  // b.none
    6878:	51000400 	sub	w0, w0, #0x1
    687c:	39000280 	strb	w0, [x20]
    6880:	17ffffd7 	b	67dc <fwp_free_zombie+0x7c>
    6884:	f9400e61 	ldr	x1, [x19, #24]
    6888:	97fff02a 	bl	2930 <munmap@plt>
    688c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6890:	a9530261 	ldp	x1, x0, [x19, #304]
    6894:	b5fff901 	cbnz	x1, 67b4 <fwp_free_zombie+0x54>
    6898:	91018282 	add	x2, x20, #0x60
    689c:	f901d040 	str	x0, [x2, #928]
    68a0:	17ffffc6 	b	67b8 <fwp_free_zombie+0x58>
    68a4:	72003c3f 	tst	w1, #0xffff
    68a8:	54fff9a1 	b.ne	67dc <fwp_free_zombie+0x7c>  // b.any
    68ac:	17ffffed 	b	6860 <fwp_free_zombie+0x100>
    68b0:	ca544680 	eor	x0, x20, x20, lsr #17
    68b4:	91198084 	add	x4, x4, #0x660
    68b8:	ca402400 	eor	x0, x0, x0, lsr #9
    68bc:	8b200c80 	add	x0, x4, w0, uxtb #3
    68c0:	f94a2400 	ldr	x0, [x0, #5192]
    68c4:	b5000080 	cbnz	x0, 68d4 <fwp_free_zombie+0x174>
    68c8:	14000010 	b	6908 <fwp_free_zombie+0x1a8>
    68cc:	f9400800 	ldr	x0, [x0, #16]
    68d0:	b40001c0 	cbz	x0, 6908 <fwp_free_zombie+0x1a8>
    68d4:	f9400001 	ldr	x1, [x0]
    68d8:	eb14003f 	cmp	x1, x20
    68dc:	54ffff81 	b.ne	68cc <fwp_free_zombie+0x16c>  // b.any
    68e0:	f9400401 	ldr	x1, [x0, #8]
    68e4:	d1000421 	sub	x1, x1, #0x1
    68e8:	f9000401 	str	x1, [x0, #8]
    68ec:	f103f83f 	cmp	x1, #0xfe
    68f0:	54fff761 	b.ne	67dc <fwp_free_zombie+0x7c>  // b.any
    68f4:	aa1403e0 	mov	x0, x20
    68f8:	97fff83a 	bl	49e0 <fwp_rc_forget_slot>
    68fc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6900:	39000280 	strb	w0, [x20]
    6904:	17ffffb6 	b	67dc <fwp_free_zombie+0x7c>
    6908:	b0000020 	adrp	x0, b000 <__divti3+0x70>
    690c:	912dc000 	add	x0, x0, #0xb70
    6910:	97fff39c 	bl	3780 <fwp_trap>

0000000000006914 <fwp_block>:
    6914:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6918:	910003fd 	mov	x29, sp
    691c:	a90153f3 	stp	x19, x20, [sp, #16]
    6920:	d00000d3 	adrp	x19, 20000 <__data_start>
    6924:	91018274 	add	x20, x19, #0x60
    6928:	f9406682 	ldr	x2, [x20, #200]
    692c:	b4000622 	cbz	x2, 69f0 <fwp_block+0xdc>
    6930:	91018261 	add	x1, x19, #0x60
    6934:	f9408040 	ldr	x0, [x2, #256]
    6938:	f9006420 	str	x0, [x1, #200]
    693c:	b4000680 	cbz	x0, 6a0c <fwp_block+0xf8>
    6940:	91018263 	add	x3, x19, #0x60
    6944:	3901505f 	strb	wzr, [x2, #84]
    6948:	f9404c64 	ldr	x4, [x3, #152]
    694c:	eb02009f 	cmp	x4, x2
    6950:	54000440 	b.eq	69d8 <fwp_block+0xc4>  // b.none
    6954:	f941d465 	ldr	x5, [x3, #936]
    6958:	f9004c62 	str	x2, [x3, #152]
    695c:	f9400441 	ldr	x1, [x2, #8]
    6960:	f9004885 	str	x5, [x4, #144]
    6964:	f941d865 	ldr	x5, [x3, #944]
    6968:	f9004c85 	str	x5, [x4, #152]
    696c:	f941dc65 	ldr	x5, [x3, #952]
    6970:	f9005085 	str	x5, [x4, #160]
    6974:	f941e065 	ldr	x5, [x3, #960]
    6978:	f9005485 	str	x5, [x4, #168]
    697c:	f941e465 	ldr	x5, [x3, #968]
    6980:	f9005885 	str	x5, [x4, #176]
    6984:	f941e865 	ldr	x5, [x3, #976]
    6988:	f9005c85 	str	x5, [x4, #184]
    698c:	f941ec65 	ldr	x5, [x3, #984]
    6990:	f9006085 	str	x5, [x4, #192]
    6994:	f9400480 	ldr	x0, [x4, #8]
    6998:	f9404844 	ldr	x4, [x2, #144]
    699c:	f901d464 	str	x4, [x3, #936]
    69a0:	f9404c44 	ldr	x4, [x2, #152]
    69a4:	f901d864 	str	x4, [x3, #944]
    69a8:	f9405044 	ldr	x4, [x2, #160]
    69ac:	f901dc64 	str	x4, [x3, #952]
    69b0:	f9405444 	ldr	x4, [x2, #168]
    69b4:	f901e064 	str	x4, [x3, #960]
    69b8:	f9405844 	ldr	x4, [x2, #176]
    69bc:	f901e464 	str	x4, [x3, #968]
    69c0:	a94b8844 	ldp	x4, x2, [x2, #184]
    69c4:	f901e864 	str	x4, [x3, #976]
    69c8:	f901ec62 	str	x2, [x3, #984]
    69cc:	97ffefa9 	bl	2870 <swapcontext@plt>
    69d0:	97ffff64 	bl	6760 <fwp_free_zombie>
    69d4:	d503201f 	nop
    69d8:	91018260 	add	x0, x19, #0x60
    69dc:	b943e000 	ldr	w0, [x0, #992]
    69e0:	340001a0 	cbz	w0, 6a14 <fwp_block+0x100>
    69e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    69e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69ec:	d65f03c0 	ret
    69f0:	97fff729 	bl	4694 <fwp_poll_events>
    69f4:	f9406682 	ldr	x2, [x20, #200]
    69f8:	b4ffffc2 	cbz	x2, 69f0 <fwp_block+0xdc>
    69fc:	91018261 	add	x1, x19, #0x60
    6a00:	f9408040 	ldr	x0, [x2, #256]
    6a04:	f9006420 	str	x0, [x1, #200]
    6a08:	b5fff9c0 	cbnz	x0, 6940 <fwp_block+0x2c>
    6a0c:	f900603f 	str	xzr, [x1, #192]
    6a10:	17ffffcc 	b	6940 <fwp_block+0x2c>
    6a14:	b0000020 	adrp	x0, b000 <__divti3+0x70>
    6a18:	91328000 	add	x0, x0, #0xca0
    6a1c:	97ffefe1 	bl	29a0 <getenv@plt>
    6a20:	5284e202 	mov	w2, #0x2710                	// #10000
    6a24:	b4000060 	cbz	x0, 6a30 <fwp_block+0x11c>
    6a28:	39400001 	ldrb	w1, [x0]
    6a2c:	350000c1 	cbnz	w1, 6a44 <fwp_block+0x130>
    6a30:	91018273 	add	x19, x19, #0x60
    6a34:	b903e262 	str	w2, [x19, #992]
    6a38:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a40:	d65f03c0 	ret
    6a44:	52800142 	mov	w2, #0xa                   	// #10
    6a48:	d2800001 	mov	x1, #0x0                   	// #0
    6a4c:	97ffef25 	bl	26e0 <strtoll@plt>
    6a50:	d1000403 	sub	x3, x0, #0x1
    6a54:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6a58:	eb02007f 	cmp	x3, x2
    6a5c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6a60:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6a64:	17fffff3 	b	6a30 <fwp_block+0x11c>
    6a68:	d503201f 	nop
    6a6c:	d503201f 	nop

0000000000006a70 <fwp_drop4>:
    6a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6a74:	910003fd 	mov	x29, sp
    6a78:	a90153f3 	stp	x19, x20, [sp, #16]
    6a7c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xb80>
    6a80:	f90013f5 	str	x21, [sp, #32]
    6a84:	91198275 	add	x21, x19, #0x660
    6a88:	f949daa1 	ldr	x1, [x21, #5040]
    6a8c:	f949eea2 	ldr	x2, [x21, #5080]
    6a90:	cb010001 	sub	x1, x0, x1
    6a94:	eb02403f 	cmp	x1, x2, lsl #16
    6a98:	54000382 	b.cs	6b08 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a9c:	d350fc22 	lsr	x2, x1, #16
    6aa0:	f949fea3 	ldr	x3, [x21, #5112]
    6aa4:	8b020842 	add	x2, x2, x2, lsl #2
    6aa8:	d37df042 	lsl	x2, x2, #3
    6aac:	8b020064 	add	x4, x3, x2
    6ab0:	f9401094 	ldr	x20, [x4, #32]
    6ab4:	b40002b4 	cbz	x20, 6b08 <fwp_drop4+0x98>
    6ab8:	38626862 	ldrb	w2, [x3, x2]
    6abc:	7100085f 	cmp	w2, #0x2
    6ac0:	540007a0 	b.eq	6bb4 <fwp_drop4+0x144>  // b.none
    6ac4:	7100045f 	cmp	w2, #0x1
    6ac8:	54000201 	b.ne	6b08 <fwp_drop4+0x98>  // b.any
    6acc:	29430885 	ldp	w5, w2, [x4, #24]
    6ad0:	92403c21 	and	x1, x1, #0xffff
    6ad4:	9b057c21 	mul	x1, x1, x5
    6ad8:	d360fc21 	lsr	x1, x1, #32
    6adc:	eb02003f 	cmp	x1, x2
    6ae0:	54000142 	b.cs	6b08 <fwp_drop4+0x98>  // b.hs, b.nlast
    6ae4:	8b010294 	add	x20, x20, x1
    6ae8:	39400281 	ldrb	w1, [x20]
    6aec:	340000e1 	cbz	w1, 6b08 <fwp_drop4+0x98>
    6af0:	7100043f 	cmp	w1, #0x1
    6af4:	54000120 	b.eq	6b18 <fwp_drop4+0xa8>  // b.none
    6af8:	7103fc3f 	cmp	w1, #0xff
    6afc:	540007c0 	b.eq	6bf4 <fwp_drop4+0x184>  // b.none
    6b00:	51000421 	sub	w1, w1, #0x1
    6b04:	39000281 	strb	w1, [x20]
    6b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b0c:	f94013f5 	ldr	x21, [sp, #32]
    6b10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b14:	d65f03c0 	ret
    6b18:	f9400001 	ldr	x1, [x0]
    6b1c:	b7f80581 	tbnz	x1, #63, 6bcc <fwp_drop4+0x15c>
    6b20:	91198273 	add	x19, x19, #0x660
    6b24:	f949da61 	ldr	x1, [x19, #5040]
    6b28:	f949ee62 	ldr	x2, [x19, #5080]
    6b2c:	cb010001 	sub	x1, x0, x1
    6b30:	eb02403f 	cmp	x1, x2, lsl #16
    6b34:	54fffea2 	b.cs	6b08 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b38:	d350fc22 	lsr	x2, x1, #16
    6b3c:	8b020842 	add	x2, x2, x2, lsl #2
    6b40:	d37df042 	lsl	x2, x2, #3
    6b44:	8b020065 	add	x5, x3, x2
    6b48:	f94010a4 	ldr	x4, [x5, #32]
    6b4c:	b4fffde4 	cbz	x4, 6b08 <fwp_drop4+0x98>
    6b50:	38626862 	ldrb	w2, [x3, x2]
    6b54:	7100085f 	cmp	w2, #0x2
    6b58:	54000220 	b.eq	6b9c <fwp_drop4+0x12c>  // b.none
    6b5c:	7100045f 	cmp	w2, #0x1
    6b60:	54fffd41 	b.ne	6b08 <fwp_drop4+0x98>  // b.any
    6b64:	294308a3 	ldp	w3, w2, [x5, #24]
    6b68:	92403c21 	and	x1, x1, #0xffff
    6b6c:	9b037c21 	mul	x1, x1, x3
    6b70:	d360fc21 	lsr	x1, x1, #32
    6b74:	eb02003f 	cmp	x1, x2
    6b78:	54fffc82 	b.cs	6b08 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b7c:	8b010084 	add	x4, x4, x1
    6b80:	39400081 	ldrb	w1, [x4]
    6b84:	7100043f 	cmp	w1, #0x1
    6b88:	54fffc01 	b.ne	6b08 <fwp_drop4+0x98>  // b.any
    6b8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b90:	f94013f5 	ldr	x21, [sp, #32]
    6b94:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b98:	17fff832 	b	4c60 <fwp_mem_free>
    6b9c:	72003c3f 	tst	w1, #0xffff
    6ba0:	54ffff00 	b.eq	6b80 <fwp_drop4+0x110>  // b.none
    6ba4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ba8:	f94013f5 	ldr	x21, [sp, #32]
    6bac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bb0:	d65f03c0 	ret
    6bb4:	72003c3f 	tst	w1, #0xffff
    6bb8:	54fff980 	b.eq	6ae8 <fwp_drop4+0x78>  // b.none
    6bbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bc0:	f94013f5 	ldr	x21, [sp, #32]
    6bc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bc8:	d65f03c0 	ret
    6bcc:	f9400414 	ldr	x20, [x0, #8]
    6bd0:	97fffbe4 	bl	5b60 <fwp_rc_free_arr>
    6bd4:	91198260 	add	x0, x19, #0x660
    6bd8:	f949d801 	ldr	x1, [x0, #5040]
    6bdc:	f949ec00 	ldr	x0, [x0, #5080]
    6be0:	cb010281 	sub	x1, x20, x1
    6be4:	eb00403f 	cmp	x1, x0, lsl #16
    6be8:	54fff902 	b.cs	6b08 <fwp_drop4+0x98>  // b.hs, b.nlast
    6bec:	aa1403e0 	mov	x0, x20
    6bf0:	17ffffab 	b	6a9c <fwp_drop4+0x2c>
    6bf4:	ca544680 	eor	x0, x20, x20, lsr #17
    6bf8:	91198273 	add	x19, x19, #0x660
    6bfc:	ca402400 	eor	x0, x0, x0, lsr #9
    6c00:	8b200e60 	add	x0, x19, w0, uxtb #3
    6c04:	f94a2400 	ldr	x0, [x0, #5192]
    6c08:	b5000080 	cbnz	x0, 6c18 <fwp_drop4+0x1a8>
    6c0c:	14000010 	b	6c4c <fwp_drop4+0x1dc>
    6c10:	f9400800 	ldr	x0, [x0, #16]
    6c14:	b40001c0 	cbz	x0, 6c4c <fwp_drop4+0x1dc>
    6c18:	f9400001 	ldr	x1, [x0]
    6c1c:	eb14003f 	cmp	x1, x20
    6c20:	54ffff81 	b.ne	6c10 <fwp_drop4+0x1a0>  // b.any
    6c24:	f9400401 	ldr	x1, [x0, #8]
    6c28:	d1000421 	sub	x1, x1, #0x1
    6c2c:	f9000401 	str	x1, [x0, #8]
    6c30:	f103f83f 	cmp	x1, #0xfe
    6c34:	54fff6a1 	b.ne	6b08 <fwp_drop4+0x98>  // b.any
    6c38:	aa1403e0 	mov	x0, x20
    6c3c:	97fff769 	bl	49e0 <fwp_rc_forget_slot>
    6c40:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c44:	39000280 	strb	w0, [x20]
    6c48:	17ffffb0 	b	6b08 <fwp_drop4+0x98>
    6c4c:	b0000020 	adrp	x0, b000 <__divti3+0x70>
    6c50:	912dc000 	add	x0, x0, #0xb70
    6c54:	97fff2cb 	bl	3780 <fwp_trap>
    6c58:	d503201f 	nop
    6c5c:	d503201f 	nop

0000000000006c60 <fwp_caps161>:
    6c60:	34000041 	cbz	w1, 6c68 <fwp_caps161+0x8>
    6c64:	d65f03c0 	ret
    6c68:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xb80>
    6c6c:	91198063 	add	x3, x3, #0x660
    6c70:	f949d861 	ldr	x1, [x3, #5040]
    6c74:	f949ec62 	ldr	x2, [x3, #5080]
    6c78:	cb010001 	sub	x1, x0, x1
    6c7c:	eb02403f 	cmp	x1, x2, lsl #16
    6c80:	54ffff22 	b.cs	6c64 <fwp_caps161+0x4>  // b.hs, b.nlast
    6c84:	d350fc22 	lsr	x2, x1, #16
    6c88:	f949fc65 	ldr	x5, [x3, #5112]
    6c8c:	8b020842 	add	x2, x2, x2, lsl #2
    6c90:	d37df042 	lsl	x2, x2, #3
    6c94:	8b0200a4 	add	x4, x5, x2
    6c98:	f9401083 	ldr	x3, [x4, #32]
    6c9c:	b4fffe43 	cbz	x3, 6c64 <fwp_caps161+0x4>
    6ca0:	386268a2 	ldrb	w2, [x5, x2]
    6ca4:	7100085f 	cmp	w2, #0x2
    6ca8:	540001c0 	b.eq	6ce0 <fwp_caps161+0x80>  // b.none
    6cac:	7100045f 	cmp	w2, #0x1
    6cb0:	54fffda1 	b.ne	6c64 <fwp_caps161+0x4>  // b.any
    6cb4:	29430885 	ldp	w5, w2, [x4, #24]
    6cb8:	92403c21 	and	x1, x1, #0xffff
    6cbc:	9b057c21 	mul	x1, x1, x5
    6cc0:	d360fc21 	lsr	x1, x1, #32
    6cc4:	eb02003f 	cmp	x1, x2
    6cc8:	54fffce2 	b.cs	6c64 <fwp_caps161+0x4>  // b.hs, b.nlast
    6ccc:	8b010063 	add	x3, x3, x1
    6cd0:	39400061 	ldrb	w1, [x3]
    6cd4:	7100043f 	cmp	w1, #0x1
    6cd8:	54fffc61 	b.ne	6c64 <fwp_caps161+0x4>  // b.any
    6cdc:	17fff7e1 	b	4c60 <fwp_mem_free>
    6ce0:	72003c3f 	tst	w1, #0xffff
    6ce4:	54ffff60 	b.eq	6cd0 <fwp_caps161+0x70>  // b.none
    6ce8:	d65f03c0 	ret
    6cec:	d503201f 	nop

0000000000006cf0 <f12>:
    6cf0:	d104c3ff 	sub	sp, sp, #0x130
    6cf4:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    6cf8:	f947f442 	ldr	x2, [x2, #4072]
    6cfc:	a90c7bfd 	stp	x29, x30, [sp, #192]
    6d00:	910303fd 	add	x29, sp, #0xc0
    6d04:	a90f63f7 	stp	x23, x24, [sp, #240]
    6d08:	f0000397 	adrp	x23, 79000 <fwp_root_context+0xb80>
    6d0c:	911982e3 	add	x3, x23, #0x660
    6d10:	a90e5bf5 	stp	x21, x22, [sp, #224]
    6d14:	d00000d5 	adrp	x21, 20000 <__data_start>
    6d18:	910182a4 	add	x4, x21, #0x60
    6d1c:	f949d861 	ldr	x1, [x3, #5040]
    6d20:	a90d53f3 	stp	x19, x20, [sp, #208]
    6d24:	910103f8 	add	x24, sp, #0x40
    6d28:	f949ec65 	ldr	x5, [x3, #5080]
    6d2c:	a9106bf9 	stp	x25, x26, [sp, #256]
    6d30:	d00000d9 	adrp	x25, 20000 <__data_start>
    6d34:	a91173fb 	stp	x27, x28, [sp, #272]
    6d38:	91004339 	add	x25, x25, #0x10
    6d3c:	91008339 	add	x25, x25, #0x20
    6d40:	f941d886 	ldr	x6, [x4, #944]
    6d44:	fd0093e8 	str	d8, [sp, #288]
    6d48:	f9400047 	ldr	x7, [x2]
    6d4c:	f9005fe7 	str	x7, [sp, #184]
    6d50:	d2800007 	mov	x7, #0x0                   	// #0
    6d54:	9100e3f6 	add	x22, sp, #0x38
    6d58:	90000013 	adrp	x19, 6000 <fwp_drop0+0x130>
    6d5c:	12800007 	mov	w7, #0xffffffff            	// #-1
    6d60:	91148262 	add	x2, x19, #0x520
    6d64:	cb010321 	sub	x1, x25, x1
    6d68:	b9003be7 	str	w7, [sp, #56]
    6d6c:	aa0003f4 	mov	x20, x0
    6d70:	a9040be6 	stp	x6, x2, [sp, #64]
    6d74:	f9002bf6 	str	x22, [sp, #80]
    6d78:	f901d898 	str	x24, [x4, #944]
    6d7c:	eb05403f 	cmp	x1, x5, lsl #16
    6d80:	540003a2 	b.cs	6df4 <f12+0x104>  // b.hs, b.nlast
    6d84:	d350fc20 	lsr	x0, x1, #16
    6d88:	f949fc64 	ldr	x4, [x3, #5112]
    6d8c:	8b000800 	add	x0, x0, x0, lsl #2
    6d90:	d37df002 	lsl	x2, x0, #3
    6d94:	8b020083 	add	x3, x4, x2
    6d98:	f9401060 	ldr	x0, [x3, #32]
    6d9c:	b40002c0 	cbz	x0, 6df4 <f12+0x104>
    6da0:	38626882 	ldrb	w2, [x4, x2]
    6da4:	7100085f 	cmp	w2, #0x2
    6da8:	54006dc0 	b.eq	7b60 <f12+0xe70>  // b.none
    6dac:	7100045f 	cmp	w2, #0x1
    6db0:	54000221 	b.ne	6df4 <f12+0x104>  // b.any
    6db4:	29430864 	ldp	w4, w2, [x3, #24]
    6db8:	92403c21 	and	x1, x1, #0xffff
    6dbc:	9b047c21 	mul	x1, x1, x4
    6dc0:	d360fc21 	lsr	x1, x1, #32
    6dc4:	eb02003f 	cmp	x1, x2
    6dc8:	54000162 	b.cs	6df4 <f12+0x104>  // b.hs, b.nlast
    6dcc:	8b010000 	add	x0, x0, x1
    6dd0:	39400001 	ldrb	w1, [x0]
    6dd4:	34000101 	cbz	w1, 6df4 <f12+0x104>
    6dd8:	910182a2 	add	x2, x21, #0x60
    6ddc:	b9415043 	ldr	w3, [x2, #336]
    6de0:	35006f43 	cbnz	w3, 7bc8 <f12+0xed8>
    6de4:	7103f43f 	cmp	w1, #0xfd
    6de8:	54007928 	b.hi	7d0c <f12+0x101c>  // b.pmore
    6dec:	11000421 	add	w1, w1, #0x1
    6df0:	39000001 	strb	w1, [x0]
    6df4:	aa1903e0 	mov	x0, x25
    6df8:	97fffce6 	bl	6190 <fwp_closure_drop>
    6dfc:	b4006bd4 	cbz	x20, 7b74 <f12+0xe84>
    6e00:	aa1403e0 	mov	x0, x20
    6e04:	d2800001 	mov	x1, #0x0                   	// #0
    6e08:	f9400800 	ldr	x0, [x0, #16]
    6e0c:	91000421 	add	x1, x1, #0x1
    6e10:	b5ffffc0 	cbnz	x0, 6e08 <f12+0x118>
    6e14:	aa0103fa 	mov	x26, x1
    6e18:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6e1c:	eb00003f 	cmp	x1, x0
    6e20:	54007b48 	b.hi	7d88 <f12+0x1098>  // b.pmore
    6e24:	910182b9 	add	x25, x21, #0x60
    6e28:	b943e720 	ldr	w0, [x25, #996]
    6e2c:	34006860 	cbz	w0, 7b38 <f12+0xe48>
    6e30:	910182a0 	add	x0, x21, #0x60
    6e34:	f9406c1b 	ldr	x27, [x0, #216]
    6e38:	f940c019 	ldr	x25, [x0, #384]
    6e3c:	eb1b033f 	cmp	x25, x27
    6e40:	5400358a 	b.ge	74f0 <f12+0x800>  // b.tcont
    6e44:	f9404401 	ldr	x1, [x0, #136]
    6e48:	8b190720 	add	x0, x25, x25, lsl #1
    6e4c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6e50:	8b000b20 	add	x0, x25, x0, lsl #2
    6e54:	8b000c20 	add	x0, x1, x0, lsl #3
    6e58:	b9400401 	ldr	w1, [x0, #4]
    6e5c:	35000081 	cbnz	w1, 6e6c <f12+0x17c>
    6e60:	b9400001 	ldr	w1, [x0]
    6e64:	6b02003f 	cmp	w1, w2
    6e68:	54003449 	b.ls	74f0 <f12+0x800>  // b.plast
    6e6c:	91000739 	add	x25, x25, #0x1
    6e70:	9101a000 	add	x0, x0, #0x68
    6e74:	eb1b033f 	cmp	x25, x27
    6e78:	54ffff01 	b.ne	6e58 <f12+0x168>  // b.any
    6e7c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6e80:	eb00037f 	cmp	x27, x0
    6e84:	540078ec 	b.gt	7da0 <f12+0x10b0>
    6e88:	910182a0 	add	x0, x21, #0x60
    6e8c:	f940a001 	ldr	x1, [x0, #320]
    6e90:	f940441c 	ldr	x28, [x0, #136]
    6e94:	eb1b003f 	cmp	x1, x27
    6e98:	54000221 	b.ne	6edc <f12+0x1ec>  // b.any
    6e9c:	b400721b 	cbz	x27, 7cdc <f12+0xfec>
    6ea0:	d37ffb79 	lsl	x25, x27, #1
    6ea4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    6ea8:	eb00033f 	cmp	x25, x0
    6eac:	9a80d339 	csel	x25, x25, x0, le
    6eb0:	8b190721 	add	x1, x25, x25, lsl #1
    6eb4:	8b010b21 	add	x1, x25, x1, lsl #2
    6eb8:	d37df021 	lsl	x1, x1, #3
    6ebc:	aa1c03e0 	mov	x0, x28
    6ec0:	52800002 	mov	w2, #0x0                   	// #0
    6ec4:	97fff558 	bl	4424 <ad_raw_realloc>
    6ec8:	aa0003fc 	mov	x28, x0
    6ecc:	b40035e0 	cbz	x0, 7588 <f12+0x898>
    6ed0:	910182a0 	add	x0, x21, #0x60
    6ed4:	f900441c 	str	x28, [x0, #136]
    6ed8:	f900a019 	str	x25, [x0, #320]
    6edc:	8b1b0761 	add	x1, x27, x27, lsl #1
    6ee0:	910182a0 	add	x0, x21, #0x60
    6ee4:	4f000400 	movi	v0.4s, #0x0
    6ee8:	aa1b03f9 	mov	x25, x27
    6eec:	8b010b61 	add	x1, x27, x1, lsl #2
    6ef0:	9100077b 	add	x27, x27, #0x1
    6ef4:	f9006c1b 	str	x27, [x0, #216]
    6ef8:	8b19073b 	add	x27, x25, x25, lsl #1
    6efc:	8b010f81 	add	x1, x28, x1, lsl #3
    6f00:	b0000020 	adrp	x0, b000 <__divti3+0x70>
    6f04:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    6f08:	912ac000 	add	x0, x0, #0xab0
    6f0c:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6f10:	ad000020 	stp	q0, q0, [x1]
    6f14:	ad010020 	stp	q0, q0, [x1, #32]
    6f18:	ad020020 	stp	q0, q0, [x1, #64]
    6f1c:	f900303f 	str	xzr, [x1, #96]
    6f20:	f900337f 	str	xzr, [x27, #96]
    6f24:	97ffee9f 	bl	29a0 <getenv@plt>
    6f28:	b5002fc0 	cbnz	x0, 7520 <f12+0x830>
    6f2c:	d503201f 	nop
    6f30:	910182a0 	add	x0, x21, #0x60
    6f34:	f9409c01 	ldr	x1, [x0, #312]
    6f38:	b50062c1 	cbnz	x1, 7b90 <f12+0xea0>
    6f3c:	910182a2 	add	x2, x21, #0x60
    6f40:	2f000400 	mvni	v0.2s, #0x0
    6f44:	b9400363 	ldr	w3, [x27]
    6f48:	52800024 	mov	w4, #0x1                   	// #1
    6f4c:	91000720 	add	x0, x25, #0x1
    6f50:	a900eb7a 	stp	x26, x26, [x27, #8]
    6f54:	0b040063 	add	w3, w3, w4
    6f58:	f941d841 	ldr	x1, [x2, #944]
    6f5c:	29001363 	stp	w3, w4, [x27]
    6f60:	f9002b7f 	str	xzr, [x27, #80]
    6f64:	f900c040 	str	x0, [x2, #384]
    6f68:	fd002f60 	str	d0, [x27, #88]
    6f6c:	b4007081 	cbz	x1, 7d7c <f12+0x108c>
    6f70:	91148273 	add	x19, x19, #0x520
    6f74:	14000003 	b	6f80 <f12+0x290>
    6f78:	f9400021 	ldr	x1, [x1]
    6f7c:	b4007001 	cbz	x1, 7d7c <f12+0x108c>
    6f80:	f9400422 	ldr	x2, [x1, #8]
    6f84:	eb13005f 	cmp	x2, x19
    6f88:	54ffff81 	b.ne	6f78 <f12+0x288>  // b.any
    6f8c:	f9400821 	ldr	x1, [x1, #16]
    6f90:	2a1903e4 	mov	w4, w25
    6f94:	b9400022 	ldr	w2, [x1]
    6f98:	f9002b61 	str	x1, [x27, #80]
    6f9c:	b9005f62 	str	w2, [x27, #92]
    6fa0:	37f80082 	tbnz	w2, #31, 6fb0 <f12+0x2c0>
    6fa4:	52800d05 	mov	w5, #0x68                  	// #104
    6fa8:	9b257042 	smaddl	x2, w2, w5, x28
    6fac:	b9005859 	str	w25, [x2, #88]
    6fb0:	b9000024 	str	w4, [x1]
    6fb4:	d3707c79 	ubfiz	x25, x3, #16, #32
    6fb8:	aa000339 	orr	x25, x25, x0
    6fbc:	d2800002 	mov	x2, #0x0                   	// #0
    6fc0:	aa1403e0 	mov	x0, x20
    6fc4:	b4005934 	cbz	x20, 7ae8 <f12+0xdf8>
    6fc8:	f9400800 	ldr	x0, [x0, #16]
    6fcc:	91000442 	add	x2, x2, #0x1
    6fd0:	b5ffffc0 	cbnz	x0, 6fc8 <f12+0x2d8>
    6fd4:	aa1403e1 	mov	x1, x20
    6fd8:	f9400821 	ldr	x1, [x1, #16]
    6fdc:	91000400 	add	x0, x0, #0x1
    6fe0:	b5ffffc1 	cbnz	x1, 6fd8 <f12+0x2e8>
    6fe4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6fe8:	eb01001f 	cmp	x0, x1
    6fec:	54006b68 	b.hi	7d58 <f12+0x1068>  // b.pmore
    6ff0:	f100005f 	cmp	x2, #0x0
    6ff4:	540057ad 	b.le	7ae8 <f12+0xdf8>
    6ff8:	eb00005f 	cmp	x2, x0
    6ffc:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7000:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7004:	eb01027f 	cmp	x19, x1
    7008:	54006a88 	b.hi	7d58 <f12+0x1068>  // b.pmore
    700c:	d37ffa7a 	lsl	x26, x19, #1
    7010:	52800041 	mov	w1, #0x2                   	// #2
    7014:	91000740 	add	x0, x26, #0x1
    7018:	d37df000 	lsl	x0, x0, #3
    701c:	97fff831 	bl	50e0 <fwp_heap_alloc>
    7020:	aa0003fb 	mov	x27, x0
    7024:	911982e1 	add	x1, x23, #0x660
    7028:	aa0103e0 	mov	x0, x1
    702c:	f900037a 	str	x26, [x27]
    7030:	f949d821 	ldr	x1, [x1, #5040]
    7034:	f949ec00 	ldr	x0, [x0, #5080]
    7038:	cb010361 	sub	x1, x27, x1
    703c:	eb00403f 	cmp	x1, x0, lsl #16
    7040:	54005742 	b.cs	7b28 <f12+0xe38>  // b.hs, b.nlast
    7044:	911982e2 	add	x2, x23, #0x660
    7048:	d350fc20 	lsr	x0, x1, #16
    704c:	8b000800 	add	x0, x0, x0, lsl #2
    7050:	f949fc43 	ldr	x3, [x2, #5112]
    7054:	d37df002 	lsl	x2, x0, #3
    7058:	8b020060 	add	x0, x3, x2
    705c:	f940101a 	ldr	x26, [x0, #32]
    7060:	b400025a 	cbz	x26, 70a8 <f12+0x3b8>
    7064:	38626862 	ldrb	w2, [x3, x2]
    7068:	7100085f 	cmp	w2, #0x2
    706c:	54005740 	b.eq	7b54 <f12+0xe64>  // b.none
    7070:	7100045f 	cmp	w2, #0x1
    7074:	540001a1 	b.ne	70a8 <f12+0x3b8>  // b.any
    7078:	29430002 	ldp	w2, w0, [x0, #24]
    707c:	92403c21 	and	x1, x1, #0xffff
    7080:	9b027c21 	mul	x1, x1, x2
    7084:	d360fc21 	lsr	x1, x1, #32
    7088:	eb00003f 	cmp	x1, x0
    708c:	540000e2 	b.cs	70a8 <f12+0x3b8>  // b.hs, b.nlast
    7090:	8b01035a 	add	x26, x26, x1
    7094:	39400340 	ldrb	w0, [x26]
    7098:	7103fc1f 	cmp	w0, #0xff
    709c:	54006260 	b.eq	7ce8 <f12+0xff8>  // b.none
    70a0:	52800020 	mov	w0, #0x1                   	// #1
    70a4:	39000340 	strb	w0, [x26]
    70a8:	b4000233 	cbz	x19, 70ec <f12+0x3fc>
    70ac:	d3607f24 	lsl	x4, x25, #32
    70b0:	aa1403e2 	mov	x2, x20
    70b4:	f9400685 	ldr	x5, [x20, #8]
    70b8:	aa0403e3 	mov	x3, x4
    70bc:	91002360 	add	x0, x27, #0x8
    70c0:	d2800001 	mov	x1, #0x0                   	// #0
    70c4:	14000005 	b	70d8 <f12+0x3e8>
    70c8:	f9400445 	ldr	x5, [x2, #8]
    70cc:	ab040023 	adds	x3, x1, x4
    70d0:	91004000 	add	x0, x0, #0x10
    70d4:	54006706 	b.vs	7db4 <f12+0x10c4>
    70d8:	a9000c05 	stp	x5, x3, [x0]
    70dc:	91000421 	add	x1, x1, #0x1
    70e0:	f9400842 	ldr	x2, [x2, #16]
    70e4:	eb01027f 	cmp	x19, x1
    70e8:	54ffff08 	b.hi	70c8 <f12+0x3d8>  // b.pmore
    70ec:	f9400360 	ldr	x0, [x27]
    70f0:	f100041f 	cmp	x0, #0x1
    70f4:	540051e9 	b.ls	7b30 <f12+0xe40>  // b.plast
    70f8:	d341fc00 	lsr	x0, x0, #1
    70fc:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7100:	d1000401 	sub	x1, x0, #0x1
    7104:	eb02003f 	cmp	x1, x2
    7108:	54006288 	b.hi	7d58 <f12+0x1068>  // b.pmore
    710c:	d37ff83c 	lsl	x28, x1, #1
    7110:	b4005101 	cbz	x1, 7b30 <f12+0xe40>
    7114:	d1002361 	sub	x1, x27, #0x8
    7118:	91002373 	add	x19, x27, #0x8
    711c:	8b00103a 	add	x26, x1, x0, lsl #4
    7120:	f9400660 	ldr	x0, [x19, #8]
    7124:	f9400e61 	ldr	x1, [x19, #24]
    7128:	fd400260 	ldr	d0, [x19]
    712c:	fd400a61 	ldr	d1, [x19, #16]
    7130:	97fff988 	bl	5750 <w107>
    7134:	a9000660 	stp	x0, x1, [x19]
    7138:	91004273 	add	x19, x19, #0x10
    713c:	eb1a027f 	cmp	x19, x26
    7140:	54ffff01 	b.ne	7120 <f12+0x430>  // b.any
    7144:	f900037c 	str	x28, [x27]
    7148:	aa1b03e0 	mov	x0, x27
    714c:	93407f33 	sxtw	x19, w25
    7150:	97fff9d4 	bl	58a0 <w164.constprop.0>
    7154:	aa0103fa 	mov	x26, x1
    7158:	aa1b03e0 	mov	x0, x27
    715c:	97fffe45 	bl	6a70 <fwp_drop4>
    7160:	97fff439 	bl	4244 <caf61>
    7164:	9e670008 	fmov	d8, x0
    7168:	aa1303e0 	mov	x0, x19
    716c:	97fff251 	bl	3ab0 <fwp_tape_of>
    7170:	aa0003ea 	mov	x10, x0
    7174:	f9403001 	ldr	x1, [x0, #96]
    7178:	b50060e1 	cbnz	x1, 7d94 <f12+0x10a4>
    717c:	97ffef86 	bl	2f94 <fwp_tape_unlink_scope>
    7180:	b9400002 	ldr	w2, [x0]
    7184:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    7188:	a940801c 	ldp	x28, x0, [x0, #8]
    718c:	b900055f 	str	wzr, [x10, #4]
    7190:	a941994b 	ldp	x11, x6, [x10, #24]
    7194:	a942a147 	ldp	x7, x8, [x10, #40]
    7198:	a9439549 	ldp	x9, x5, [x10, #56]
    719c:	f940255b 	ldr	x27, [x10, #72]
    71a0:	6b01005f 	cmp	w2, w1
    71a4:	54000108 	b.hi	71c4 <f12+0x4d4>  // b.pmore
    71a8:	910182a2 	add	x2, x21, #0x60
    71ac:	92403e61 	and	x1, x19, #0xffff
    71b0:	d1000421 	sub	x1, x1, #0x1
    71b4:	f940c043 	ldr	x3, [x2, #384]
    71b8:	eb03003f 	cmp	x1, x3
    71bc:	5400004a 	b.ge	71c4 <f12+0x4d4>  // b.tcont
    71c0:	f900c041 	str	x1, [x2, #384]
    71c4:	4f000400 	movi	v0.4s, #0x0
    71c8:	910182a3 	add	x3, x21, #0x60
    71cc:	f9000d5f 	str	xzr, [x10, #24]
    71d0:	910163e1 	add	x1, sp, #0x58
    71d4:	9101c3f9 	add	x25, sp, #0x70
    71d8:	b0ffffe2 	adrp	x2, 4000 <fwp_heap_report+0xe0>
    71dc:	f941d86c 	ldr	x12, [x3, #944]
    71e0:	3c808140 	stur	q0, [x10, #8]
    71e4:	9113d042 	add	x2, x2, #0x4f4
    71e8:	ad010140 	stp	q0, q0, [x10, #32]
    71ec:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    71f0:	a9058bec 	stp	x12, x2, [sp, #88]
    71f4:	a9069bf9 	stp	x25, x6, [sp, #104]
    71f8:	a907a3e7 	stp	x7, x8, [sp, #120]
    71fc:	a90897e9 	stp	x9, x5, [sp, #136]
    7200:	a909efeb 	stp	x11, x27, [sp, #152]
    7204:	f901d861 	str	x1, [x3, #944]
    7208:	b7f84bba 	tbnz	x26, #63, 7b7c <f12+0xe8c>
    720c:	eb9a827f 	cmp	x19, x26, asr #32
    7210:	54005921 	b.ne	7d34 <f12+0x1044>  // b.any
    7214:	92407f53 	and	x19, x26, #0xffffffff
    7218:	eb3a401f 	cmp	x0, w26, uxtw
    721c:	5400592d 	b.le	7d40 <f12+0x1050>
    7220:	eb13039f 	cmp	x28, x19
    7224:	9a93c793 	csinc	x19, x28, x19, gt
    7228:	eb13037f 	cmp	x27, x19
    722c:	540019aa 	b.ge	7560 <f12+0x870>  // b.tcont
    7230:	f100037f 	cmp	x27, #0x0
    7234:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7238:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    723c:	14000004 	b	724c <f12+0x55c>
    7240:	eb01037f 	cmp	x27, x1
    7244:	d37ffb7b 	lsl	x27, x27, #1
    7248:	9a93d37b 	csel	x27, x27, x19, le
    724c:	eb13037f 	cmp	x27, x19
    7250:	54ffff8b 	b.lt	7240 <f12+0x550>  // b.tstop
    7254:	b4004dc5 	cbz	x5, 7c0c <f12+0xf1c>
    7258:	aa0503e0 	mov	x0, x5
    725c:	d37df361 	lsl	x1, x27, #3
    7260:	52800062 	mov	w2, #0x3                   	// #3
    7264:	a9009fe6 	stp	x6, x7, [sp, #8]
    7268:	a901a7e8 	stp	x8, x9, [sp, #24]
    726c:	97fff46e 	bl	4424 <ad_raw_realloc>
    7270:	aa0003e5 	mov	x5, x0
    7274:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7278:	a941a7e8 	ldp	x8, x9, [sp, #24]
    727c:	b4004ae0 	cbz	x0, 7bd8 <f12+0xee8>
    7280:	f9004be5 	str	x5, [sp, #144]
    7284:	f90053fb 	str	x27, [sp, #160]
    7288:	b5001593 	cbnz	x19, 7538 <f12+0x848>
    728c:	b7f800ba 	tbnz	x26, #63, 72a0 <f12+0x5b0>
    7290:	92407f41 	and	x1, x26, #0xffffffff
    7294:	fc6178a0 	ldr	d0, [x5, x1, lsl #3]
    7298:	1e682800 	fadd	d0, d0, d8
    729c:	fc2178a0 	str	d0, [x5, x1, lsl #3]
    72a0:	d1000673 	sub	x19, x19, #0x1
    72a4:	d1000783 	sub	x3, x28, #0x1
    72a8:	eb13039f 	cmp	x28, x19
    72ac:	540003ac 	b.gt	7320 <f12+0x630>
    72b0:	fc7378a0 	ldr	d0, [x5, x19, lsl #3]
    72b4:	1e602008 	fcmp	d0, #0.0
    72b8:	540002e0 	b.eq	7314 <f12+0x624>  // b.none
    72bc:	cb1c0be0 	neg	x0, x28, lsl #2
    72c0:	cb1c03e2 	neg	x2, x28
    72c4:	8b0000c1 	add	x1, x6, x0
    72c8:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    72cc:	37f80101 	tbnz	w1, #31, 72ec <f12+0x5fc>
    72d0:	8b020d0a 	add	x10, x8, x2, lsl #3
    72d4:	93407c21 	sxtw	x1, w1
    72d8:	fc737942 	ldr	d2, [x10, x19, lsl #3]
    72dc:	fc6178a1 	ldr	d1, [x5, x1, lsl #3]
    72e0:	1e620802 	fmul	d2, d0, d2
    72e4:	1e622821 	fadd	d1, d1, d2
    72e8:	fc2178a1 	str	d1, [x5, x1, lsl #3]
    72ec:	8b0000e0 	add	x0, x7, x0
    72f0:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    72f4:	37f80100 	tbnz	w0, #31, 7314 <f12+0x624>
    72f8:	8b020d22 	add	x2, x9, x2, lsl #3
    72fc:	93407c00 	sxtw	x0, w0
    7300:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    7304:	fc6078a1 	ldr	d1, [x5, x0, lsl #3]
    7308:	1e620800 	fmul	d0, d0, d2
    730c:	1e602820 	fadd	d0, d1, d0
    7310:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    7314:	d1000673 	sub	x19, x19, #0x1
    7318:	eb13007f 	cmp	x3, x19
    731c:	54fffca1 	b.ne	72b0 <f12+0x5c0>  // b.any
    7320:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7324:	eb00039f 	cmp	x28, x0
    7328:	540051e8 	b.hi	7d64 <f12+0x1074>  // b.pmore
    732c:	91000780 	add	x0, x28, #0x1
    7330:	52800041 	mov	w1, #0x2                   	// #2
    7334:	f90007e5 	str	x5, [sp, #8]
    7338:	d37df000 	lsl	x0, x0, #3
    733c:	97fff769 	bl	50e0 <fwp_heap_alloc>
    7340:	aa0003e2 	mov	x2, x0
    7344:	aa0003f3 	mov	x19, x0
    7348:	f94007e5 	ldr	x5, [sp, #8]
    734c:	d2800001 	mov	x1, #0x0                   	// #0
    7350:	f800845c 	str	x28, [x2], #8
    7354:	b40000dc 	cbz	x28, 736c <f12+0x67c>
    7358:	f86178a0 	ldr	x0, [x5, x1, lsl #3]
    735c:	f8217840 	str	x0, [x2, x1, lsl #3]
    7360:	91000421 	add	x1, x1, #0x1
    7364:	eb01039f 	cmp	x28, x1
    7368:	54ffff81 	b.ne	7358 <f12+0x668>  // b.any
    736c:	910182a1 	add	x1, x21, #0x60
    7370:	aa1903e0 	mov	x0, x25
    7374:	f9402ffa 	ldr	x26, [sp, #88]
    7378:	f901d83a 	str	x26, [x1, #944]
    737c:	97fff45e 	bl	44f4 <fwp_tape_buffers_release>
    7380:	911982e2 	add	x2, x23, #0x660
    7384:	f949d841 	ldr	x1, [x2, #5040]
    7388:	f949ec40 	ldr	x0, [x2, #5080]
    738c:	cb010261 	sub	x1, x19, x1
    7390:	eb00403f 	cmp	x1, x0, lsl #16
    7394:	54000322 	b.cs	73f8 <f12+0x708>  // b.hs, b.nlast
    7398:	d350fc20 	lsr	x0, x1, #16
    739c:	f949fc43 	ldr	x3, [x2, #5112]
    73a0:	8b000800 	add	x0, x0, x0, lsl #2
    73a4:	d37df002 	lsl	x2, x0, #3
    73a8:	8b020060 	add	x0, x3, x2
    73ac:	f9401019 	ldr	x25, [x0, #32]
    73b0:	b4000259 	cbz	x25, 73f8 <f12+0x708>
    73b4:	38626862 	ldrb	w2, [x3, x2]
    73b8:	7100085f 	cmp	w2, #0x2
    73bc:	54003e40 	b.eq	7b84 <f12+0xe94>  // b.none
    73c0:	7100045f 	cmp	w2, #0x1
    73c4:	540001a1 	b.ne	73f8 <f12+0x708>  // b.any
    73c8:	29430002 	ldp	w2, w0, [x0, #24]
    73cc:	92403c21 	and	x1, x1, #0xffff
    73d0:	9b027c21 	mul	x1, x1, x2
    73d4:	d360fc21 	lsr	x1, x1, #32
    73d8:	eb00003f 	cmp	x1, x0
    73dc:	540000e2 	b.cs	73f8 <f12+0x708>  // b.hs, b.nlast
    73e0:	8b010339 	add	x25, x25, x1
    73e4:	39400320 	ldrb	w0, [x25]
    73e8:	7103fc1f 	cmp	w0, #0xff
    73ec:	54004840 	b.eq	7cf4 <f12+0x1004>  // b.none
    73f0:	52800020 	mov	w0, #0x1                   	// #1
    73f4:	39000320 	strb	w0, [x25]
    73f8:	eb18035f 	cmp	x26, x24
    73fc:	54004da1 	b.ne	7db0 <f12+0x10c0>  // b.any
    7400:	f94023e1 	ldr	x1, [sp, #64]
    7404:	910182b5 	add	x21, x21, #0x60
    7408:	aa1603e0 	mov	x0, x22
    740c:	f901daa1 	str	x1, [x21, #944]
    7410:	97fffc44 	bl	6520 <fwp_tape_scope_release>
    7414:	f9400260 	ldr	x0, [x19]
    7418:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    741c:	b7f83120 	tbnz	x0, #63, 7a40 <f12+0xd50>
    7420:	911982e2 	add	x2, x23, #0x660
    7424:	f949d840 	ldr	x0, [x2, #5040]
    7428:	f949ec41 	ldr	x1, [x2, #5080]
    742c:	cb000260 	sub	x0, x19, x0
    7430:	eb01401f 	cmp	x0, x1, lsl #16
    7434:	54003062 	b.cs	7a40 <f12+0xd50>  // b.hs, b.nlast
    7438:	d350fc01 	lsr	x1, x0, #16
    743c:	f949fc44 	ldr	x4, [x2, #5112]
    7440:	8b010821 	add	x1, x1, x1, lsl #2
    7444:	d37df021 	lsl	x1, x1, #3
    7448:	8b010083 	add	x3, x4, x1
    744c:	f9401062 	ldr	x2, [x3, #32]
    7450:	b4002f82 	cbz	x2, 7a40 <f12+0xd50>
    7454:	38616881 	ldrb	w1, [x4, x1]
    7458:	7100083f 	cmp	w1, #0x2
    745c:	54002ec0 	b.eq	7a34 <f12+0xd44>  // b.none
    7460:	7100043f 	cmp	w1, #0x1
    7464:	54002ee1 	b.ne	7a40 <f12+0xd50>  // b.any
    7468:	29430464 	ldp	w4, w1, [x3, #24]
    746c:	92403c00 	and	x0, x0, #0xffff
    7470:	9b047c00 	mul	x0, x0, x4
    7474:	d360fc00 	lsr	x0, x0, #32
    7478:	eb01001f 	cmp	x0, x1
    747c:	54002e22 	b.cs	7a40 <f12+0xd50>  // b.hs, b.nlast
    7480:	8b000042 	add	x2, x2, x0
    7484:	39400040 	ldrb	w0, [x2]
    7488:	7100041f 	cmp	w0, #0x1
    748c:	54002da1 	b.ne	7a40 <f12+0xd50>  // b.any
    7490:	aa1303f5 	mov	x21, x19
    7494:	d2800000 	mov	x0, #0x0                   	// #0
    7498:	f90007f3 	str	x19, [sp, #8]
    749c:	f94007e1 	ldr	x1, [sp, #8]
    74a0:	91002023 	add	x3, x1, #0x8
    74a4:	d2800001 	mov	x1, #0x0                   	// #0
    74a8:	b4000898 	cbz	x24, 75b8 <f12+0x8c8>
    74ac:	b0000022 	adrp	x2, c000 <_IO_stdin_used+0x950>
    74b0:	91002265 	add	x5, x19, #0x8
    74b4:	fd434041 	ldr	d1, [x2, #1664]
    74b8:	14000009 	b	74dc <f12+0x7ec>
    74bc:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    74c0:	f94002a2 	ldr	x2, [x21]
    74c4:	1e600820 	fmul	d0, d1, d0
    74c8:	b7f84422 	tbnz	x2, #63, 7d4c <f12+0x105c>
    74cc:	91000421 	add	x1, x1, #0x1
    74d0:	fc008460 	str	d0, [x3], #8
    74d4:	eb01031f 	cmp	x24, x1
    74d8:	54000700 	b.eq	75b8 <f12+0x8c8>  // b.none
    74dc:	f9400264 	ldr	x4, [x19]
    74e0:	aa0503e2 	mov	x2, x5
    74e4:	b6fffec4 	tbz	x4, #63, 74bc <f12+0x7cc>
    74e8:	f9400a62 	ldr	x2, [x19, #16]
    74ec:	17fffff4 	b	74bc <f12+0x7cc>
    74f0:	eb19037f 	cmp	x27, x25
    74f4:	54ffcc40 	b.eq	6e7c <f12+0x18c>  // b.none
    74f8:	910182a0 	add	x0, x21, #0x60
    74fc:	8b19073b 	add	x27, x25, x25, lsl #1
    7500:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    7504:	f940441c 	ldr	x28, [x0, #136]
    7508:	90000020 	adrp	x0, b000 <__divti3+0x70>
    750c:	912ac000 	add	x0, x0, #0xab0
    7510:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7514:	f900337f 	str	xzr, [x27, #96]
    7518:	97ffed22 	bl	29a0 <getenv@plt>
    751c:	b4ffd0a0 	cbz	x0, 6f30 <f12+0x240>
    7520:	39400001 	ldrb	w1, [x0]
    7524:	7100c03f 	cmp	w1, #0x30
    7528:	54ffd041 	b.ne	6f30 <f12+0x240>  // b.any
    752c:	39400400 	ldrb	w0, [x0, #1]
    7530:	34ffd060 	cbz	w0, 6f3c <f12+0x24c>
    7534:	17fffe7f 	b	6f30 <f12+0x240>
    7538:	aa0503e0 	mov	x0, x5
    753c:	d37df262 	lsl	x2, x19, #3
    7540:	52800001 	mov	w1, #0x0                   	// #0
    7544:	a9009fe6 	stp	x6, x7, [sp, #8]
    7548:	a901a7e8 	stp	x8, x9, [sp, #24]
    754c:	97ffeca5 	bl	27e0 <memset@plt>
    7550:	aa0003e5 	mov	x5, x0
    7554:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7558:	a941a7e8 	ldp	x8, x9, [sp, #24]
    755c:	17ffff4c 	b	728c <f12+0x59c>
    7560:	f10000bf 	cmp	x5, #0x0
    7564:	1a9f17e0 	cset	w0, eq	// eq = none
    7568:	f100027f 	cmp	x19, #0x0
    756c:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    7570:	54ffe8c0 	b.eq	7288 <f12+0x598>  // b.none
    7574:	f9402fe1 	ldr	x1, [sp, #88]
    7578:	910182b5 	add	x21, x21, #0x60
    757c:	aa1903e0 	mov	x0, x25
    7580:	f901daa1 	str	x1, [x21, #944]
    7584:	97fff3dc 	bl	44f4 <fwp_tape_buffers_release>
    7588:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    758c:	f947e863 	ldr	x3, [x3, #4048]
    7590:	d2800262 	mov	x2, #0x13                  	// #19
    7594:	d2800021 	mov	x1, #0x1                   	// #1
    7598:	90000020 	adrp	x0, b000 <__divti3+0x70>
    759c:	911ae000 	add	x0, x0, #0x6b8
    75a0:	f9400063 	ldr	x3, [x3]
    75a4:	97ffecdb 	bl	2910 <fwrite@plt>
    75a8:	d2800000 	mov	x0, #0x0                   	// #0
    75ac:	97ffece5 	bl	2940 <fflush@plt>
    75b0:	52800cc0 	mov	w0, #0x66                  	// #102
    75b4:	97ffecf3 	bl	2980 <_Exit@plt>
    75b8:	97fffd2e 	bl	6a70 <fwp_drop4>
    75bc:	aa1403e1 	mov	x1, x20
    75c0:	d2800002 	mov	x2, #0x0                   	// #0
    75c4:	b4003774 	cbz	x20, 7cb0 <f12+0xfc0>
    75c8:	f9400821 	ldr	x1, [x1, #16]
    75cc:	91000442 	add	x2, x2, #0x1
    75d0:	b5ffffc1 	cbnz	x1, 75c8 <f12+0x8d8>
    75d4:	f94002a3 	ldr	x3, [x21]
    75d8:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    75dc:	b7f81f63 	tbnz	x3, #63, 79c8 <f12+0xcd8>
    75e0:	911982e1 	add	x1, x23, #0x660
    75e4:	f94007e4 	ldr	x4, [sp, #8]
    75e8:	f949d820 	ldr	x0, [x1, #5040]
    75ec:	f949ec21 	ldr	x1, [x1, #5080]
    75f0:	cb000080 	sub	x0, x4, x0
    75f4:	eb01401f 	cmp	x0, x1, lsl #16
    75f8:	54001e82 	b.cs	79c8 <f12+0xcd8>  // b.hs, b.nlast
    75fc:	911982e4 	add	x4, x23, #0x660
    7600:	d350fc01 	lsr	x1, x0, #16
    7604:	8b010821 	add	x1, x1, x1, lsl #2
    7608:	f949fc86 	ldr	x6, [x4, #5112]
    760c:	d37df021 	lsl	x1, x1, #3
    7610:	8b0100c5 	add	x5, x6, x1
    7614:	f94010a4 	ldr	x4, [x5, #32]
    7618:	b4001d64 	cbz	x4, 79c4 <f12+0xcd4>
    761c:	386168c1 	ldrb	w1, [x6, x1]
    7620:	7100083f 	cmp	w1, #0x2
    7624:	54001cc0 	b.eq	79bc <f12+0xccc>  // b.none
    7628:	7100043f 	cmp	w1, #0x1
    762c:	54001cc1 	b.ne	79c4 <f12+0xcd4>  // b.any
    7630:	294304a6 	ldp	w6, w1, [x5, #24]
    7634:	92403c00 	and	x0, x0, #0xffff
    7638:	9b067c00 	mul	x0, x0, x6
    763c:	d360fc00 	lsr	x0, x0, #32
    7640:	eb01001f 	cmp	x0, x1
    7644:	54001c02 	b.cs	79c4 <f12+0xcd4>  // b.hs, b.nlast
    7648:	8b000084 	add	x4, x4, x0
    764c:	39400098 	ldrb	w24, [x4]
    7650:	7100071f 	cmp	w24, #0x1
    7654:	54001b81 	b.ne	79c4 <f12+0xcd4>  // b.any
    7658:	b90013f8 	str	w24, [sp, #16]
    765c:	eb1c005f 	cmp	x2, x28
    7660:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    7664:	910022b9 	add	x25, x21, #0x8
    7668:	b400361c 	cbz	x28, 7d28 <f12+0x1038>
    766c:	f94007e0 	ldr	x0, [sp, #8]
    7670:	d37df385 	lsl	x5, x28, #3
    7674:	aa1403e2 	mov	x2, x20
    7678:	d2800001 	mov	x1, #0x0                   	// #0
    767c:	91002000 	add	x0, x0, #0x8
    7680:	1400000a 	b	76a8 <f12+0x9b8>
    7684:	fc616881 	ldr	d1, [x4, x1]
    7688:	fd400440 	ldr	d0, [x2, #8]
    768c:	1e613800 	fsub	d0, d0, d1
    7690:	fc216b20 	str	d0, [x25, x1]
    7694:	91002021 	add	x1, x1, #0x8
    7698:	f9400842 	ldr	x2, [x2, #16]
    769c:	eb05003f 	cmp	x1, x5
    76a0:	540001c0 	b.eq	76d8 <f12+0x9e8>  // b.none
    76a4:	f94002a3 	ldr	x3, [x21]
    76a8:	aa0003e4 	mov	x4, x0
    76ac:	b6fffec3 	tbz	x3, #63, 7684 <f12+0x994>
    76b0:	f94007e3 	ldr	x3, [sp, #8]
    76b4:	fd400440 	ldr	d0, [x2, #8]
    76b8:	f9400864 	ldr	x4, [x3, #16]
    76bc:	fc616881 	ldr	d1, [x4, x1]
    76c0:	1e613800 	fsub	d0, d0, d1
    76c4:	fc216b20 	str	d0, [x25, x1]
    76c8:	91002021 	add	x1, x1, #0x8
    76cc:	f9400842 	ldr	x2, [x2, #16]
    76d0:	eb05003f 	cmp	x1, x5
    76d4:	54fffe81 	b.ne	76a4 <f12+0x9b4>  // b.any
    76d8:	b4003254 	cbz	x20, 7d20 <f12+0x1030>
    76dc:	911982e0 	add	x0, x23, #0x660
    76e0:	aa1403e2 	mov	x2, x20
    76e4:	d280001a 	mov	x26, #0x0                   	// #0
    76e8:	f949ec06 	ldr	x6, [x0, #5080]
    76ec:	f949d807 	ldr	x7, [x0, #5040]
    76f0:	f949fc05 	ldr	x5, [x0, #5112]
    76f4:	d370bcc6 	lsl	x6, x6, #16
    76f8:	14000006 	b	7710 <f12+0xa20>
    76fc:	f9400842 	ldr	x2, [x2, #16]
    7700:	9100075a 	add	x26, x26, #0x1
    7704:	f100005f 	cmp	x2, #0x0
    7708:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    770c:	54000329 	b.ls	7770 <f12+0xa80>  // b.plast
    7710:	cb070040 	sub	x0, x2, x7
    7714:	eb06001f 	cmp	x0, x6
    7718:	540002c2 	b.cs	7770 <f12+0xa80>  // b.hs, b.nlast
    771c:	d350fc01 	lsr	x1, x0, #16
    7720:	8b010821 	add	x1, x1, x1, lsl #2
    7724:	d37df021 	lsl	x1, x1, #3
    7728:	8b0100a4 	add	x4, x5, x1
    772c:	f9401083 	ldr	x3, [x4, #32]
    7730:	b4000203 	cbz	x3, 7770 <f12+0xa80>
    7734:	386168a1 	ldrb	w1, [x5, x1]
    7738:	7100083f 	cmp	w1, #0x2
    773c:	54000de0 	b.eq	78f8 <f12+0xc08>  // b.none
    7740:	7100043f 	cmp	w1, #0x1
    7744:	54000161 	b.ne	7770 <f12+0xa80>  // b.any
    7748:	29430488 	ldp	w8, w1, [x4, #24]
    774c:	92403c00 	and	x0, x0, #0xffff
    7750:	9b087c00 	mul	x0, x0, x8
    7754:	d360fc00 	lsr	x0, x0, #32
    7758:	eb01001f 	cmp	x0, x1
    775c:	540000a2 	b.cs	7770 <f12+0xa80>  // b.hs, b.nlast
    7760:	8b000063 	add	x3, x3, x0
    7764:	39400060 	ldrb	w0, [x3]
    7768:	7100041f 	cmp	w0, #0x1
    776c:	54fffc80 	b.eq	76fc <f12+0xa0c>  // b.none
    7770:	eb1a039f 	cmp	x28, x26
    7774:	54000ca9 	b.ls	7908 <f12+0xc18>  // b.plast
    7778:	d1002336 	sub	x22, x25, #0x8
    777c:	9102a3f5 	add	x21, sp, #0xa8
    7780:	911982f8 	add	x24, x23, #0x660
    7784:	d2800013 	mov	x19, #0x0                   	// #0
    7788:	14000012 	b	77d0 <f12+0xae0>
    778c:	7100045f 	cmp	w2, #0x1
    7790:	540001a1 	b.ne	77c4 <f12+0xad4>  // b.any
    7794:	29430002 	ldp	w2, w0, [x0, #24]
    7798:	92403c21 	and	x1, x1, #0xffff
    779c:	9b027c21 	mul	x1, x1, x2
    77a0:	d360fc21 	lsr	x1, x1, #32
    77a4:	eb00003f 	cmp	x1, x0
    77a8:	540000e2 	b.cs	77c4 <f12+0xad4>  // b.hs, b.nlast
    77ac:	8b01037b 	add	x27, x27, x1
    77b0:	39400360 	ldrb	w0, [x27]
    77b4:	7103fc1f 	cmp	w0, #0xff
    77b8:	54001b20 	b.eq	7b1c <f12+0xe2c>  // b.none
    77bc:	52800020 	mov	w0, #0x1                   	// #1
    77c0:	39000360 	strb	w0, [x27]
    77c4:	d100079c 	sub	x28, x28, #0x1
    77c8:	eb1c035f 	cmp	x26, x28
    77cc:	54000362 	b.cs	7838 <f12+0xb48>  // b.hs, b.nlast
    77d0:	f87c7ac2 	ldr	x2, [x22, x28, lsl #3]
    77d4:	aa1503e1 	mov	x1, x21
    77d8:	52800020 	mov	w0, #0x1                   	// #1
    77dc:	a90acfe2 	stp	x2, x19, [sp, #168]
    77e0:	97fff85c 	bl	5950 <fwp_data.part.0.constprop.0>
    77e4:	aa0003f3 	mov	x19, x0
    77e8:	f949db01 	ldr	x1, [x24, #5040]
    77ec:	f949ef00 	ldr	x0, [x24, #5080]
    77f0:	cb010261 	sub	x1, x19, x1
    77f4:	eb00403f 	cmp	x1, x0, lsl #16
    77f8:	54fffe62 	b.cs	77c4 <f12+0xad4>  // b.hs, b.nlast
    77fc:	d350fc22 	lsr	x2, x1, #16
    7800:	f949ff03 	ldr	x3, [x24, #5112]
    7804:	8b020842 	add	x2, x2, x2, lsl #2
    7808:	d37df042 	lsl	x2, x2, #3
    780c:	8b020060 	add	x0, x3, x2
    7810:	f940101b 	ldr	x27, [x0, #32]
    7814:	b4fffd9b 	cbz	x27, 77c4 <f12+0xad4>
    7818:	38626862 	ldrb	w2, [x3, x2]
    781c:	7100085f 	cmp	w2, #0x2
    7820:	54fffb61 	b.ne	778c <f12+0xa9c>  // b.any
    7824:	72003c3f 	tst	w1, #0xffff
    7828:	54fffc40 	b.eq	77b0 <f12+0xac0>  // b.none
    782c:	d100079c 	sub	x28, x28, #0x1
    7830:	eb1c035f 	cmp	x26, x28
    7834:	54fffce3 	b.cc	77d0 <f12+0xae0>  // b.lo, b.ul, b.last
    7838:	b50006ba 	cbnz	x26, 790c <f12+0xc1c>
    783c:	b94013e0 	ldr	w0, [sp, #16]
    7840:	d2800038 	mov	x24, #0x1                   	// #1
    7844:	d280001b 	mov	x27, #0x0                   	// #0
    7848:	7100001f 	cmp	w0, #0x0
    784c:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7850:	b40007db 	cbz	x27, 7948 <f12+0xc58>
    7854:	d100077b 	sub	x27, x27, #0x1
    7858:	911982f7 	add	x23, x23, #0x660
    785c:	d503201f 	nop
    7860:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    7864:	aa1503e1 	mov	x1, x21
    7868:	52800020 	mov	w0, #0x1                   	// #1
    786c:	a90acfe2 	stp	x2, x19, [sp, #168]
    7870:	97fff838 	bl	5950 <fwp_data.part.0.constprop.0>
    7874:	aa0003f3 	mov	x19, x0
    7878:	f949dae1 	ldr	x1, [x23, #5040]
    787c:	f949eee0 	ldr	x0, [x23, #5080]
    7880:	cb010261 	sub	x1, x19, x1
    7884:	eb00403f 	cmp	x1, x0, lsl #16
    7888:	54000302 	b.cs	78e8 <f12+0xbf8>  // b.hs, b.nlast
    788c:	d350fc22 	lsr	x2, x1, #16
    7890:	f949fee3 	ldr	x3, [x23, #5112]
    7894:	8b020842 	add	x2, x2, x2, lsl #2
    7898:	d37df042 	lsl	x2, x2, #3
    789c:	8b020060 	add	x0, x3, x2
    78a0:	f940101a 	ldr	x26, [x0, #32]
    78a4:	b400023a 	cbz	x26, 78e8 <f12+0xbf8>
    78a8:	38626862 	ldrb	w2, [x3, x2]
    78ac:	7100085f 	cmp	w2, #0x2
    78b0:	54000800 	b.eq	79b0 <f12+0xcc0>  // b.none
    78b4:	7100045f 	cmp	w2, #0x1
    78b8:	54000181 	b.ne	78e8 <f12+0xbf8>  // b.any
    78bc:	29430002 	ldp	w2, w0, [x0, #24]
    78c0:	92403c21 	and	x1, x1, #0xffff
    78c4:	9b027c21 	mul	x1, x1, x2
    78c8:	d360fc21 	lsr	x1, x1, #32
    78cc:	eb00003f 	cmp	x1, x0
    78d0:	540000c2 	b.cs	78e8 <f12+0xbf8>  // b.hs, b.nlast
    78d4:	8b01035a 	add	x26, x26, x1
    78d8:	39400340 	ldrb	w0, [x26]
    78dc:	7103fc1f 	cmp	w0, #0xff
    78e0:	54000620 	b.eq	79a4 <f12+0xcb4>  // b.none
    78e4:	39000358 	strb	w24, [x26]
    78e8:	d100077b 	sub	x27, x27, #0x1
    78ec:	b100077f 	cmn	x27, #0x1
    78f0:	54fffb81 	b.ne	7860 <f12+0xb70>  // b.any
    78f4:	14000015 	b	7948 <f12+0xc58>
    78f8:	72003c1f 	tst	w0, #0xffff
    78fc:	54fff340 	b.eq	7764 <f12+0xa74>  // b.none
    7900:	eb1a039f 	cmp	x28, x26
    7904:	54fff3a8 	b.hi	7778 <f12+0xa88>  // b.pmore
    7908:	d2800013 	mov	x19, #0x0                   	// #0
    790c:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    7910:	aa1903e1 	mov	x1, x25
    7914:	aa1403e0 	mov	x0, x20
    7918:	f8408422 	ldr	x2, [x1], #8
    791c:	f9000402 	str	x2, [x0, #8]
    7920:	aa0003e2 	mov	x2, x0
    7924:	f9400800 	ldr	x0, [x0, #16]
    7928:	eb01035f 	cmp	x26, x1
    792c:	54ffff61 	b.ne	7918 <f12+0xc28>  // b.any
    7930:	b94013e1 	ldr	w1, [sp, #16]
    7934:	f9000853 	str	x19, [x2, #16]
    7938:	aa1403f3 	mov	x19, x20
    793c:	aa0003f4 	mov	x20, x0
    7940:	34000041 	cbz	w1, 7948 <f12+0xc58>
    7944:	d2800019 	mov	x25, #0x0                   	// #0
    7948:	aa1903e0 	mov	x0, x25
    794c:	97fff4c5 	bl	4c60 <fwp_mem_free>
    7950:	f94007e0 	ldr	x0, [sp, #8]
    7954:	97fffc47 	bl	6a70 <fwp_drop4>
    7958:	aa1403e0 	mov	x0, x20
    795c:	97fff95d 	bl	5ed0 <fwp_drop0>
    7960:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    7964:	f947f400 	ldr	x0, [x0, #4072]
    7968:	f9405fe2 	ldr	x2, [sp, #184]
    796c:	f9400001 	ldr	x1, [x0]
    7970:	eb010042 	subs	x2, x2, x1
    7974:	d2800001 	mov	x1, #0x0                   	// #0
    7978:	540021a1 	b.ne	7dac <f12+0x10bc>  // b.any
    797c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    7980:	aa1303e0 	mov	x0, x19
    7984:	a94d53f3 	ldp	x19, x20, [sp, #208]
    7988:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    798c:	a94f63f7 	ldp	x23, x24, [sp, #240]
    7990:	a9506bf9 	ldp	x25, x26, [sp, #256]
    7994:	a95173fb 	ldp	x27, x28, [sp, #272]
    7998:	fd4093e8 	ldr	d8, [sp, #288]
    799c:	9104c3ff 	add	sp, sp, #0x130
    79a0:	d65f03c0 	ret
    79a4:	aa1a03e0 	mov	x0, x26
    79a8:	97fff40e 	bl	49e0 <fwp_rc_forget_slot>
    79ac:	17ffffce 	b	78e4 <f12+0xbf4>
    79b0:	72003c3f 	tst	w1, #0xffff
    79b4:	54fff9a1 	b.ne	78e8 <f12+0xbf8>  // b.any
    79b8:	17ffffc8 	b	78d8 <f12+0xbe8>
    79bc:	72003c1f 	tst	w0, #0xffff
    79c0:	54ffe460 	b.eq	764c <f12+0x95c>  // b.none
    79c4:	b4001114 	cbz	x20, 7be4 <f12+0xef4>
    79c8:	aa1403f3 	mov	x19, x20
    79cc:	d2800018 	mov	x24, #0x0                   	// #0
    79d0:	f9400a73 	ldr	x19, [x19, #16]
    79d4:	aa1803e0 	mov	x0, x24
    79d8:	91000718 	add	x24, x24, #0x1
    79dc:	b5ffffb3 	cbnz	x19, 79d0 <f12+0xce0>
    79e0:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    79e4:	eb01031f 	cmp	x24, x1
    79e8:	54001b88 	b.hi	7d58 <f12+0x1068>  // b.pmore
    79ec:	91000800 	add	x0, x0, #0x2
    79f0:	52800041 	mov	w1, #0x2                   	// #2
    79f4:	d37df000 	lsl	x0, x0, #3
    79f8:	97fff5ba 	bl	50e0 <fwp_heap_alloc>
    79fc:	eb1c031f 	cmp	x24, x28
    7a00:	aa0003f9 	mov	x25, x0
    7a04:	9a9c931c 	csel	x28, x24, x28, ls	// ls = plast
    7a08:	aa1403e1 	mov	x1, x20
    7a0c:	d503201f 	nop
    7a10:	f9400420 	ldr	x0, [x1, #8]
    7a14:	f8337b20 	str	x0, [x25, x19, lsl #3]
    7a18:	91000673 	add	x19, x19, #0x1
    7a1c:	f9400821 	ldr	x1, [x1, #16]
    7a20:	b5ffff81 	cbnz	x1, 7a10 <f12+0xd20>
    7a24:	b4000e9c 	cbz	x28, 7bf4 <f12+0xf04>
    7a28:	f94002a3 	ldr	x3, [x21]
    7a2c:	b90013ff 	str	wzr, [sp, #16]
    7a30:	17ffff0f 	b	766c <f12+0x97c>
    7a34:	72003c1f 	tst	w0, #0xffff
    7a38:	54ffd260 	b.eq	7484 <f12+0x794>  // b.none
    7a3c:	d503201f 	nop
    7a40:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7a44:	eb00031f 	cmp	x24, x0
    7a48:	540018e8 	b.hi	7d64 <f12+0x1074>  // b.pmore
    7a4c:	91000700 	add	x0, x24, #0x1
    7a50:	52800021 	mov	w1, #0x1                   	// #1
    7a54:	d37df000 	lsl	x0, x0, #3
    7a58:	97fff5a2 	bl	50e0 <fwp_heap_alloc>
    7a5c:	911982e2 	add	x2, x23, #0x660
    7a60:	f9000018 	str	x24, [x0]
    7a64:	aa0003f5 	mov	x21, x0
    7a68:	f90007f5 	str	x21, [sp, #8]
    7a6c:	f949d841 	ldr	x1, [x2, #5040]
    7a70:	f949ec40 	ldr	x0, [x2, #5080]
    7a74:	cb0102a1 	sub	x1, x21, x1
    7a78:	eb00403f 	cmp	x1, x0, lsl #16
    7a7c:	54000322 	b.cs	7ae0 <f12+0xdf0>  // b.hs, b.nlast
    7a80:	d350fc20 	lsr	x0, x1, #16
    7a84:	f949fc43 	ldr	x3, [x2, #5112]
    7a88:	8b000800 	add	x0, x0, x0, lsl #2
    7a8c:	d37df002 	lsl	x2, x0, #3
    7a90:	8b020060 	add	x0, x3, x2
    7a94:	f9401019 	ldr	x25, [x0, #32]
    7a98:	b4000259 	cbz	x25, 7ae0 <f12+0xdf0>
    7a9c:	38626862 	ldrb	w2, [x3, x2]
    7aa0:	7100085f 	cmp	w2, #0x2
    7aa4:	54000ac0 	b.eq	7bfc <f12+0xf0c>  // b.none
    7aa8:	7100045f 	cmp	w2, #0x1
    7aac:	540001a1 	b.ne	7ae0 <f12+0xdf0>  // b.any
    7ab0:	29430002 	ldp	w2, w0, [x0, #24]
    7ab4:	92403c21 	and	x1, x1, #0xffff
    7ab8:	9b027c21 	mul	x1, x1, x2
    7abc:	d360fc21 	lsr	x1, x1, #32
    7ac0:	eb00003f 	cmp	x1, x0
    7ac4:	540000e2 	b.cs	7ae0 <f12+0xdf0>  // b.hs, b.nlast
    7ac8:	8b010339 	add	x25, x25, x1
    7acc:	39400320 	ldrb	w0, [x25]
    7ad0:	7103fc1f 	cmp	w0, #0xff
    7ad4:	54001160 	b.eq	7d00 <f12+0x1010>  // b.none
    7ad8:	52800020 	mov	w0, #0x1                   	// #1
    7adc:	39000320 	strb	w0, [x25]
    7ae0:	aa1303e0 	mov	x0, x19
    7ae4:	17fffe6e 	b	749c <f12+0x7ac>
    7ae8:	52800041 	mov	w1, #0x2                   	// #2
    7aec:	d2800100 	mov	x0, #0x8                   	// #8
    7af0:	97fff57c 	bl	50e0 <fwp_heap_alloc>
    7af4:	aa0003fb 	mov	x27, x0
    7af8:	911982e0 	add	x0, x23, #0x660
    7afc:	f900037f 	str	xzr, [x27]
    7b00:	f949d801 	ldr	x1, [x0, #5040]
    7b04:	f949ec00 	ldr	x0, [x0, #5080]
    7b08:	cb010361 	sub	x1, x27, x1
    7b0c:	eb00403f 	cmp	x1, x0, lsl #16
    7b10:	54000102 	b.cs	7b30 <f12+0xe40>  // b.hs, b.nlast
    7b14:	d2800013 	mov	x19, #0x0                   	// #0
    7b18:	17fffd4b 	b	7044 <f12+0x354>
    7b1c:	aa1b03e0 	mov	x0, x27
    7b20:	97fff3b0 	bl	49e0 <fwp_rc_forget_slot>
    7b24:	17ffff26 	b	77bc <f12+0xacc>
    7b28:	b5ffac33 	cbnz	x19, 70ac <f12+0x3bc>
    7b2c:	d503201f 	nop
    7b30:	d280001c 	mov	x28, #0x0                   	// #0
    7b34:	17fffd84 	b	7144 <f12+0x454>
    7b38:	f0ffffe0 	adrp	x0, 6000 <fwp_drop0+0x130>
    7b3c:	91104000 	add	x0, x0, #0x410
    7b40:	94000ed0 	bl	b680 <atexit>
    7b44:	35ffd220 	cbnz	w0, 7588 <f12+0x898>
    7b48:	52800020 	mov	w0, #0x1                   	// #1
    7b4c:	b903e720 	str	w0, [x25, #996]
    7b50:	17fffcb8 	b	6e30 <f12+0x140>
    7b54:	72003c3f 	tst	w1, #0xffff
    7b58:	54ffaa81 	b.ne	70a8 <f12+0x3b8>  // b.any
    7b5c:	17fffd4e 	b	7094 <f12+0x3a4>
    7b60:	72003c3f 	tst	w1, #0xffff
    7b64:	54ff9360 	b.eq	6dd0 <f12+0xe0>  // b.none
    7b68:	aa1903e0 	mov	x0, x25
    7b6c:	97fff989 	bl	6190 <fwp_closure_drop>
    7b70:	b5ff9494 	cbnz	x20, 6e00 <f12+0x110>
    7b74:	d280001a 	mov	x26, #0x0                   	// #0
    7b78:	17fffcab 	b	6e24 <f12+0x134>
    7b7c:	aa1c03f3 	mov	x19, x28
    7b80:	17fffdaa 	b	7228 <f12+0x538>
    7b84:	72003c3f 	tst	w1, #0xffff
    7b88:	54ffc381 	b.ne	73f8 <f12+0x708>  // b.any
    7b8c:	17fffe16 	b	73e4 <f12+0x6f4>
    7b90:	ad480402 	ldp	q2, q1, [x0, #256]
    7b94:	91040001 	add	x1, x0, #0x100
    7b98:	4f000400 	movi	v0.4s, #0x0
    7b9c:	f9009c1f 	str	xzr, [x0, #312]
    7ba0:	ad010762 	stp	q2, q1, [x27, #32]
    7ba4:	a9520002 	ldp	x2, x0, [x0, #288]
    7ba8:	f9000f60 	str	x0, [x27, #24]
    7bac:	f9401820 	ldr	x0, [x1, #48]
    7bb0:	f9002362 	str	x2, [x27, #64]
    7bb4:	f9002760 	str	x0, [x27, #72]
    7bb8:	ad000020 	stp	q0, q0, [x1]
    7bbc:	3d800820 	str	q0, [x1, #32]
    7bc0:	f900183f 	str	xzr, [x1, #48]
    7bc4:	17fffcde 	b	6f3c <f12+0x24c>
    7bc8:	f940bc43 	ldr	x3, [x2, #376]
    7bcc:	91000463 	add	x3, x3, #0x1
    7bd0:	f900bc43 	str	x3, [x2, #376]
    7bd4:	17fffc84 	b	6de4 <f12+0xf4>
    7bd8:	d2800005 	mov	x5, #0x0                   	// #0
    7bdc:	52800020 	mov	w0, #0x1                   	// #1
    7be0:	17fffe62 	b	7568 <f12+0x878>
    7be4:	52800041 	mov	w1, #0x2                   	// #2
    7be8:	d2800100 	mov	x0, #0x8                   	// #8
    7bec:	97fff53d 	bl	50e0 <fwp_heap_alloc>
    7bf0:	aa0003f9 	mov	x25, x0
    7bf4:	d2800013 	mov	x19, #0x0                   	// #0
    7bf8:	17ffff54 	b	7948 <f12+0xc58>
    7bfc:	72003c3f 	tst	w1, #0xffff
    7c00:	54fff660 	b.eq	7acc <f12+0xddc>  // b.none
    7c04:	aa1303e0 	mov	x0, x19
    7c08:	17fffe25 	b	749c <f12+0x7ac>
    7c0c:	d1000761 	sub	x1, x27, #0x1
    7c10:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7c14:	eb00003f 	cmp	x1, x0
    7c18:	54000ac8 	b.hi	7d70 <f12+0x1080>  // b.pmore
    7c1c:	b00002c3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fb80>
    7c20:	d2800000 	mov	x0, #0x0                   	// #0
    7c24:	91120061 	add	x1, x3, #0x480
    7c28:	14000005 	b	7c3c <f12+0xf4c>
    7c2c:	91000400 	add	x0, x0, #0x1
    7c30:	91006021 	add	x1, x1, #0x18
    7c34:	f140041f 	cmp	x0, #0x1, lsl #12
    7c38:	540006e0 	b.eq	7d14 <f12+0x1024>  // b.none
    7c3c:	f9400022 	ldr	x2, [x1]
    7c40:	b5ffff62 	cbnz	x2, 7c2c <f12+0xf3c>
    7c44:	8b000402 	add	x2, x0, x0, lsl #1
    7c48:	91120063 	add	x3, x3, #0x480
    7c4c:	aa1b03e0 	mov	x0, x27
    7c50:	d2800101 	mov	x1, #0x8                   	// #8
    7c54:	8b020c62 	add	x2, x3, x2, lsl #3
    7c58:	a9009be2 	stp	x2, x6, [sp, #8]
    7c5c:	a901a3e7 	stp	x7, x8, [sp, #24]
    7c60:	f90017e9 	str	x9, [sp, #40]
    7c64:	97ffeae3 	bl	27f0 <calloc@plt>
    7c68:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7c6c:	aa0003e5 	mov	x5, x0
    7c70:	a94227e8 	ldp	x8, x9, [sp, #32]
    7c74:	b4fffb20 	cbz	x0, 7bd8 <f12+0xee8>
    7c78:	aa0003e1 	mov	x1, x0
    7c7c:	d37df362 	lsl	x2, x27, #3
    7c80:	f94007e0 	ldr	x0, [sp, #8]
    7c84:	52800063 	mov	w3, #0x3                   	// #3
    7c88:	a9009be5 	stp	x5, x6, [sp, #8]
    7c8c:	a901a3e7 	stp	x7, x8, [sp, #24]
    7c90:	f90017e9 	str	x9, [sp, #40]
    7c94:	97ffec9f 	bl	2f10 <ad_raw_record>
    7c98:	a9409be5 	ldp	x5, x6, [sp, #8]
    7c9c:	f9004be5 	str	x5, [sp, #144]
    7ca0:	a941a3e7 	ldp	x7, x8, [sp, #24]
    7ca4:	f90053fb 	str	x27, [sp, #160]
    7ca8:	f94017e9 	ldr	x9, [sp, #40]
    7cac:	17fffd77 	b	7288 <f12+0x598>
    7cb0:	f94002a3 	ldr	x3, [x21]
    7cb4:	b7fff983 	tbnz	x3, #63, 7be4 <f12+0xef4>
    7cb8:	911982e1 	add	x1, x23, #0x660
    7cbc:	f94007e4 	ldr	x4, [sp, #8]
    7cc0:	f949d820 	ldr	x0, [x1, #5040]
    7cc4:	f949ec21 	ldr	x1, [x1, #5080]
    7cc8:	cb000080 	sub	x0, x4, x0
    7ccc:	eb01401f 	cmp	x0, x1, lsl #16
    7cd0:	54fff8a2 	b.cs	7be4 <f12+0xef4>  // b.hs, b.nlast
    7cd4:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7cd8:	17fffe49 	b	75fc <f12+0x90c>
    7cdc:	d2800d01 	mov	x1, #0x68                  	// #104
    7ce0:	d2800039 	mov	x25, #0x1                   	// #1
    7ce4:	17fffc76 	b	6ebc <f12+0x1cc>
    7ce8:	aa1a03e0 	mov	x0, x26
    7cec:	97fff33d 	bl	49e0 <fwp_rc_forget_slot>
    7cf0:	17fffcec 	b	70a0 <f12+0x3b0>
    7cf4:	aa1903e0 	mov	x0, x25
    7cf8:	97fff33a 	bl	49e0 <fwp_rc_forget_slot>
    7cfc:	17fffdbd 	b	73f0 <f12+0x700>
    7d00:	aa1903e0 	mov	x0, x25
    7d04:	97fff337 	bl	49e0 <fwp_rc_forget_slot>
    7d08:	17ffff74 	b	7ad8 <f12+0xde8>
    7d0c:	97fff2ee 	bl	48c4 <fwp_rc_wide_dup>
    7d10:	17fffc39 	b	6df4 <f12+0x104>
    7d14:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d18:	91296000 	add	x0, x0, #0xa58
    7d1c:	97ffed79 	bl	3300 <ad_raw_fail>
    7d20:	d280001a 	mov	x26, #0x0                   	// #0
    7d24:	17fffe95 	b	7778 <f12+0xa88>
    7d28:	d2800019 	mov	x25, #0x0                   	// #0
    7d2c:	d2800013 	mov	x19, #0x0                   	// #0
    7d30:	17ffff06 	b	7948 <f12+0xc58>
    7d34:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d38:	912ee000 	add	x0, x0, #0xbb8
    7d3c:	97ffee91 	bl	3780 <fwp_trap>
    7d40:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d44:	91314000 	add	x0, x0, #0xc50
    7d48:	97ffee8e 	bl	3780 <fwp_trap>
    7d4c:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d50:	9135c000 	add	x0, x0, #0xd70
    7d54:	97ffee8b 	bl	3780 <fwp_trap>
    7d58:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d5c:	9134c000 	add	x0, x0, #0xd30
    7d60:	97ffee88 	bl	3780 <fwp_trap>
    7d64:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d68:	91358000 	add	x0, x0, #0xd60
    7d6c:	97ffee85 	bl	3780 <fwp_trap>
    7d70:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d74:	91350000 	add	x0, x0, #0xd40
    7d78:	97ffed62 	bl	3300 <ad_raw_fail>
    7d7c:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d80:	91340000 	add	x0, x0, #0xd00
    7d84:	97ffee7f 	bl	3780 <fwp_trap>
    7d88:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d8c:	9132c000 	add	x0, x0, #0xcb0
    7d90:	97ffee7c 	bl	3780 <fwp_trap>
    7d94:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7d98:	91300000 	add	x0, x0, #0xc00
    7d9c:	97ffee79 	bl	3780 <fwp_trap>
    7da0:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7da4:	91334000 	add	x0, x0, #0xcd0
    7da8:	97ffee76 	bl	3780 <fwp_trap>
    7dac:	97ffea99 	bl	2810 <__stack_chk_fail@plt>
    7db0:	97ffeaac 	bl	2860 <abort@plt>
    7db4:	97ffeb13 	bl	2a00 <fwp_trap_overflow.constprop.0>
    7db8:	d503201f 	nop
    7dbc:	d503201f 	nop

0000000000007dc0 <fwp_owned_entry12>:
    7dc0:	f9400000 	ldr	x0, [x0]
    7dc4:	17fffbcb 	b	6cf0 <f12>
    7dc8:	d503201f 	nop
    7dcc:	d503201f 	nop

0000000000007dd0 <e12>:
    7dd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7dd4:	910003fd 	mov	x29, sp
    7dd8:	f9000bf3 	str	x19, [sp, #16]
    7ddc:	f9400013 	ldr	x19, [x0]
    7de0:	aa1303e0 	mov	x0, x19
    7de4:	97fff738 	bl	5ac4 <fwp_rc_share>
    7de8:	aa1303e0 	mov	x0, x19
    7dec:	97fffbc1 	bl	6cf0 <f12>
    7df0:	aa0003f3 	mov	x19, x0
    7df4:	97fff734 	bl	5ac4 <fwp_rc_share>
    7df8:	aa1303e0 	mov	x0, x19
    7dfc:	f9400bf3 	ldr	x19, [sp, #16]
    7e00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7e04:	d65f03c0 	ret
    7e08:	d503201f 	nop
    7e0c:	d503201f 	nop

0000000000007e10 <fwp_drop2>:
    7e10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7e14:	910003fd 	mov	x29, sp
    7e18:	a9025bf5 	stp	x21, x22, [sp, #32]
    7e1c:	d0000396 	adrp	x22, 79000 <fwp_root_context+0xb80>
    7e20:	911982d5 	add	x21, x22, #0x660
    7e24:	a90153f3 	stp	x19, x20, [sp, #16]
    7e28:	aa0003f3 	mov	x19, x0
    7e2c:	f949daa1 	ldr	x1, [x21, #5040]
    7e30:	f949eea0 	ldr	x0, [x21, #5080]
    7e34:	cb010261 	sub	x1, x19, x1
    7e38:	eb00403f 	cmp	x1, x0, lsl #16
    7e3c:	54000382 	b.cs	7eac <fwp_drop2+0x9c>  // b.hs, b.nlast
    7e40:	d350fc22 	lsr	x2, x1, #16
    7e44:	f949fea3 	ldr	x3, [x21, #5112]
    7e48:	8b020842 	add	x2, x2, x2, lsl #2
    7e4c:	d37df042 	lsl	x2, x2, #3
    7e50:	8b020060 	add	x0, x3, x2
    7e54:	f9401014 	ldr	x20, [x0, #32]
    7e58:	b40002b4 	cbz	x20, 7eac <fwp_drop2+0x9c>
    7e5c:	38626862 	ldrb	w2, [x3, x2]
    7e60:	7100085f 	cmp	w2, #0x2
    7e64:	540002c0 	b.eq	7ebc <fwp_drop2+0xac>  // b.none
    7e68:	7100045f 	cmp	w2, #0x1
    7e6c:	54000201 	b.ne	7eac <fwp_drop2+0x9c>  // b.any
    7e70:	29430002 	ldp	w2, w0, [x0, #24]
    7e74:	92403c21 	and	x1, x1, #0xffff
    7e78:	9b027c21 	mul	x1, x1, x2
    7e7c:	d360fc21 	lsr	x1, x1, #32
    7e80:	eb00003f 	cmp	x1, x0
    7e84:	54000142 	b.cs	7eac <fwp_drop2+0x9c>  // b.hs, b.nlast
    7e88:	8b010294 	add	x20, x20, x1
    7e8c:	39400280 	ldrb	w0, [x20]
    7e90:	340000e0 	cbz	w0, 7eac <fwp_drop2+0x9c>
    7e94:	7100041f 	cmp	w0, #0x1
    7e98:	540001e0 	b.eq	7ed4 <fwp_drop2+0xc4>  // b.none
    7e9c:	7103fc1f 	cmp	w0, #0xff
    7ea0:	540007c0 	b.eq	7f98 <fwp_drop2+0x188>  // b.none
    7ea4:	51000400 	sub	w0, w0, #0x1
    7ea8:	39000280 	strb	w0, [x20]
    7eac:	a94153f3 	ldp	x19, x20, [sp, #16]
    7eb0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7eb4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7eb8:	d65f03c0 	ret
    7ebc:	72003c3f 	tst	w1, #0xffff
    7ec0:	54fffe60 	b.eq	7e8c <fwp_drop2+0x7c>  // b.none
    7ec4:	a94153f3 	ldp	x19, x20, [sp, #16]
    7ec8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7ecc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7ed0:	d65f03c0 	ret
    7ed4:	911982c2 	add	x2, x22, #0x660
    7ed8:	f9400660 	ldr	x0, [x19, #8]
    7edc:	f949d841 	ldr	x1, [x2, #5040]
    7ee0:	f949ec42 	ldr	x2, [x2, #5080]
    7ee4:	cb010001 	sub	x1, x0, x1
    7ee8:	eb02403f 	cmp	x1, x2, lsl #16
    7eec:	54000362 	b.cs	7f58 <fwp_drop2+0x148>  // b.hs, b.nlast
    7ef0:	d350fc22 	lsr	x2, x1, #16
    7ef4:	8b020842 	add	x2, x2, x2, lsl #2
    7ef8:	d37df042 	lsl	x2, x2, #3
    7efc:	8b020064 	add	x4, x3, x2
    7f00:	f9401094 	ldr	x20, [x4, #32]
    7f04:	b40002b4 	cbz	x20, 7f58 <fwp_drop2+0x148>
    7f08:	38626862 	ldrb	w2, [x3, x2]
    7f0c:	7100085f 	cmp	w2, #0x2
    7f10:	540003e0 	b.eq	7f8c <fwp_drop2+0x17c>  // b.none
    7f14:	7100045f 	cmp	w2, #0x1
    7f18:	54000201 	b.ne	7f58 <fwp_drop2+0x148>  // b.any
    7f1c:	29430883 	ldp	w3, w2, [x4, #24]
    7f20:	92403c21 	and	x1, x1, #0xffff
    7f24:	9b037c21 	mul	x1, x1, x3
    7f28:	d360fc21 	lsr	x1, x1, #32
    7f2c:	eb02003f 	cmp	x1, x2
    7f30:	54000142 	b.cs	7f58 <fwp_drop2+0x148>  // b.hs, b.nlast
    7f34:	8b010294 	add	x20, x20, x1
    7f38:	39400281 	ldrb	w1, [x20]
    7f3c:	340000e1 	cbz	w1, 7f58 <fwp_drop2+0x148>
    7f40:	7100043f 	cmp	w1, #0x1
    7f44:	54000200 	b.eq	7f84 <fwp_drop2+0x174>  // b.none
    7f48:	7103fc3f 	cmp	w1, #0xff
    7f4c:	54000580 	b.eq	7ffc <fwp_drop2+0x1ec>  // b.none
    7f50:	51000421 	sub	w1, w1, #0x1
    7f54:	39000281 	strb	w1, [x20]
    7f58:	f9400a74 	ldr	x20, [x19, #16]
    7f5c:	aa1303e0 	mov	x0, x19
    7f60:	97fff700 	bl	5b60 <fwp_rc_free_arr>
    7f64:	911982c0 	add	x0, x22, #0x660
    7f68:	f949d801 	ldr	x1, [x0, #5040]
    7f6c:	f949ec00 	ldr	x0, [x0, #5080]
    7f70:	cb010281 	sub	x1, x20, x1
    7f74:	eb00403f 	cmp	x1, x0, lsl #16
    7f78:	54fff9a2 	b.cs	7eac <fwp_drop2+0x9c>  // b.hs, b.nlast
    7f7c:	aa1403f3 	mov	x19, x20
    7f80:	17ffffb0 	b	7e40 <fwp_drop2+0x30>
    7f84:	97fff6f7 	bl	5b60 <fwp_rc_free_arr>
    7f88:	17fffff4 	b	7f58 <fwp_drop2+0x148>
    7f8c:	72003c3f 	tst	w1, #0xffff
    7f90:	54fffe41 	b.ne	7f58 <fwp_drop2+0x148>  // b.any
    7f94:	17ffffe9 	b	7f38 <fwp_drop2+0x128>
    7f98:	ca544681 	eor	x1, x20, x20, lsr #17
    7f9c:	911982c0 	add	x0, x22, #0x660
    7fa0:	ca412421 	eor	x1, x1, x1, lsr #9
    7fa4:	8b210c01 	add	x1, x0, w1, uxtb #3
    7fa8:	f94a2420 	ldr	x0, [x1, #5192]
    7fac:	b5000080 	cbnz	x0, 7fbc <fwp_drop2+0x1ac>
    7fb0:	14000010 	b	7ff0 <fwp_drop2+0x1e0>
    7fb4:	f9400800 	ldr	x0, [x0, #16]
    7fb8:	b40001c0 	cbz	x0, 7ff0 <fwp_drop2+0x1e0>
    7fbc:	f9400001 	ldr	x1, [x0]
    7fc0:	eb14003f 	cmp	x1, x20
    7fc4:	54ffff81 	b.ne	7fb4 <fwp_drop2+0x1a4>  // b.any
    7fc8:	f9400401 	ldr	x1, [x0, #8]
    7fcc:	d1000421 	sub	x1, x1, #0x1
    7fd0:	f9000401 	str	x1, [x0, #8]
    7fd4:	f103f83f 	cmp	x1, #0xfe
    7fd8:	54fff6a1 	b.ne	7eac <fwp_drop2+0x9c>  // b.any
    7fdc:	aa1403e0 	mov	x0, x20
    7fe0:	97fff280 	bl	49e0 <fwp_rc_forget_slot>
    7fe4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7fe8:	39000280 	strb	w0, [x20]
    7fec:	17ffffb0 	b	7eac <fwp_drop2+0x9c>
    7ff0:	90000020 	adrp	x0, b000 <__divti3+0x70>
    7ff4:	912dc000 	add	x0, x0, #0xb70
    7ff8:	97ffede2 	bl	3780 <fwp_trap>
    7ffc:	ca544680 	eor	x0, x20, x20, lsr #17
    8000:	911982c1 	add	x1, x22, #0x660
    8004:	ca402400 	eor	x0, x0, x0, lsr #9
    8008:	8b200c20 	add	x0, x1, w0, uxtb #3
    800c:	f94a2400 	ldr	x0, [x0, #5192]
    8010:	b5000080 	cbnz	x0, 8020 <fwp_drop2+0x210>
    8014:	17fffff7 	b	7ff0 <fwp_drop2+0x1e0>
    8018:	f9400800 	ldr	x0, [x0, #16]
    801c:	b4fffea0 	cbz	x0, 7ff0 <fwp_drop2+0x1e0>
    8020:	f9400001 	ldr	x1, [x0]
    8024:	eb14003f 	cmp	x1, x20
    8028:	54ffff81 	b.ne	8018 <fwp_drop2+0x208>  // b.any
    802c:	f9400401 	ldr	x1, [x0, #8]
    8030:	d1000421 	sub	x1, x1, #0x1
    8034:	f9000401 	str	x1, [x0, #8]
    8038:	f103f83f 	cmp	x1, #0xfe
    803c:	54fff8e1 	b.ne	7f58 <fwp_drop2+0x148>  // b.any
    8040:	aa1403e0 	mov	x0, x20
    8044:	97fff267 	bl	49e0 <fwp_rc_forget_slot>
    8048:	12800020 	mov	w0, #0xfffffffe            	// #-2
    804c:	39000280 	strb	w0, [x20]
    8050:	17ffffc2 	b	7f58 <fwp_drop2+0x148>

0000000000008054 <fwp_arg_drop23>:
    8054:	7100003f 	cmp	w1, #0x0
    8058:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    805c:	54000041 	b.ne	8064 <fwp_arg_drop23+0x10>  // b.any
    8060:	d65f03c0 	ret
    8064:	f9400000 	ldr	x0, [x0]
    8068:	17ffff6a 	b	7e10 <fwp_drop2>
    806c:	d503201f 	nop

0000000000008070 <f23>:
    8070:	d101c3ff 	sub	sp, sp, #0x70
    8074:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    8078:	f947f421 	ldr	x1, [x1, #4072]
    807c:	a9027bfd 	stp	x29, x30, [sp, #32]
    8080:	910083fd 	add	x29, sp, #0x20
    8084:	a90563f7 	stp	x23, x24, [sp, #80]
    8088:	b0000397 	adrp	x23, 79000 <fwp_root_context+0xb80>
    808c:	911982e3 	add	x3, x23, #0x660
    8090:	a90353f3 	stp	x19, x20, [sp, #48]
    8094:	a9045bf5 	stp	x21, x22, [sp, #64]
    8098:	aa0003f6 	mov	x22, x0
    809c:	a9066bf9 	stp	x25, x26, [sp, #96]
    80a0:	f949ec62 	ldr	x2, [x3, #5080]
    80a4:	f9400024 	ldr	x4, [x1]
    80a8:	f9000fe4 	str	x4, [sp, #24]
    80ac:	d2800004 	mov	x4, #0x0                   	// #0
    80b0:	f949d861 	ldr	x1, [x3, #5040]
    80b4:	d370bc42 	lsl	x2, x2, #16
    80b8:	b40016c0 	cbz	x0, 8390 <f23+0x320>
    80bc:	f9400818 	ldr	x24, [x0, #16]
    80c0:	cb010301 	sub	x1, x24, x1
    80c4:	eb02003f 	cmp	x1, x2
    80c8:	540003e2 	b.cs	8144 <f23+0xd4>  // b.hs, b.nlast
    80cc:	f949fc60 	ldr	x0, [x3, #5112]
    80d0:	d350fc22 	lsr	x2, x1, #16
    80d4:	8b020842 	add	x2, x2, x2, lsl #2
    80d8:	8b020c02 	add	x2, x0, x2, lsl #3
    80dc:	f9401040 	ldr	x0, [x2, #32]
    80e0:	b4000320 	cbz	x0, 8144 <f23+0xd4>
    80e4:	39400043 	ldrb	w3, [x2]
    80e8:	7100087f 	cmp	w3, #0x2
    80ec:	54001440 	b.eq	8374 <f23+0x304>  // b.none
    80f0:	7100047f 	cmp	w3, #0x1
    80f4:	54000241 	b.ne	813c <f23+0xcc>  // b.any
    80f8:	29430843 	ldp	w3, w2, [x2, #24]
    80fc:	92403c21 	and	x1, x1, #0xffff
    8100:	9b037c21 	mul	x1, x1, x3
    8104:	d360fc21 	lsr	x1, x1, #32
    8108:	eb02003f 	cmp	x1, x2
    810c:	54000182 	b.cs	813c <f23+0xcc>  // b.hs, b.nlast
    8110:	8b010000 	add	x0, x0, x1
    8114:	39400001 	ldrb	w1, [x0]
    8118:	34000121 	cbz	w1, 813c <f23+0xcc>
    811c:	900000c2 	adrp	x2, 20000 <__data_start>
    8120:	91018042 	add	x2, x2, #0x60
    8124:	b9415043 	ldr	w3, [x2, #336]
    8128:	350012c3 	cbnz	w3, 8380 <f23+0x310>
    812c:	7103f43f 	cmp	w1, #0xfd
    8130:	54001728 	b.hi	8414 <f23+0x3a4>  // b.pmore
    8134:	11000421 	add	w1, w1, #0x1
    8138:	39000001 	strb	w1, [x0]
    813c:	d2800000 	mov	x0, #0x0                   	// #0
    8140:	b40000f6 	cbz	x22, 815c <f23+0xec>
    8144:	aa1603e1 	mov	x1, x22
    8148:	d2800000 	mov	x0, #0x0                   	// #0
    814c:	d503201f 	nop
    8150:	f9400821 	ldr	x1, [x1, #16]
    8154:	91000400 	add	x0, x0, #0x1
    8158:	b5ffffc1 	cbnz	x1, 8150 <f23+0xe0>
    815c:	b4001238 	cbz	x24, 83a0 <f23+0x330>
    8160:	aa1803e1 	mov	x1, x24
    8164:	d2800002 	mov	x2, #0x0                   	// #0
    8168:	f9400821 	ldr	x1, [x1, #16]
    816c:	91000442 	add	x2, x2, #0x1
    8170:	b5ffffc1 	cbnz	x1, 8168 <f23+0xf8>
    8174:	eb00005f 	cmp	x2, x0
    8178:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    817c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    8180:	eb01033f 	cmp	x25, x1
    8184:	540014e8 	b.hi	8420 <f23+0x3b0>  // b.pmore
    8188:	d37ffb33 	lsl	x19, x25, #1
    818c:	52800041 	mov	w1, #0x2                   	// #2
    8190:	91000660 	add	x0, x19, #0x1
    8194:	d37df000 	lsl	x0, x0, #3
    8198:	97fff3d2 	bl	50e0 <fwp_heap_alloc>
    819c:	911982e1 	add	x1, x23, #0x660
    81a0:	aa0003fa 	mov	x26, x0
    81a4:	f9000013 	str	x19, [x0]
    81a8:	aa0103e0 	mov	x0, x1
    81ac:	f949d821 	ldr	x1, [x1, #5040]
    81b0:	f949ec00 	ldr	x0, [x0, #5080]
    81b4:	cb010341 	sub	x1, x26, x1
    81b8:	eb00403f 	cmp	x1, x0, lsl #16
    81bc:	54000342 	b.cs	8224 <f23+0x1b4>  // b.hs, b.nlast
    81c0:	911982e2 	add	x2, x23, #0x660
    81c4:	d350fc20 	lsr	x0, x1, #16
    81c8:	8b000800 	add	x0, x0, x0, lsl #2
    81cc:	f949fc43 	ldr	x3, [x2, #5112]
    81d0:	d37df002 	lsl	x2, x0, #3
    81d4:	8b020060 	add	x0, x3, x2
    81d8:	f9401013 	ldr	x19, [x0, #32]
    81dc:	b4000253 	cbz	x19, 8224 <f23+0x1b4>
    81e0:	38626862 	ldrb	w2, [x3, x2]
    81e4:	7100085f 	cmp	w2, #0x2
    81e8:	54000c00 	b.eq	8368 <f23+0x2f8>  // b.none
    81ec:	7100045f 	cmp	w2, #0x1
    81f0:	540001a1 	b.ne	8224 <f23+0x1b4>  // b.any
    81f4:	29430002 	ldp	w2, w0, [x0, #24]
    81f8:	92403c21 	and	x1, x1, #0xffff
    81fc:	9b027c21 	mul	x1, x1, x2
    8200:	d360fc21 	lsr	x1, x1, #32
    8204:	eb00003f 	cmp	x1, x0
    8208:	540000e2 	b.cs	8224 <f23+0x1b4>  // b.hs, b.nlast
    820c:	8b010273 	add	x19, x19, x1
    8210:	39400260 	ldrb	w0, [x19]
    8214:	7103fc1f 	cmp	w0, #0xff
    8218:	54000e80 	b.eq	83e8 <f23+0x378>  // b.none
    821c:	52800020 	mov	w0, #0x1                   	// #1
    8220:	39000260 	strb	w0, [x19]
    8224:	b4000259 	cbz	x25, 826c <f23+0x1fc>
    8228:	8b191359 	add	x25, x26, x25, lsl #4
    822c:	aa1a03f3 	mov	x19, x26
    8230:	aa1603f5 	mov	x21, x22
    8234:	aa1803f4 	mov	x20, x24
    8238:	f9400683 	ldr	x3, [x20, #8]
    823c:	f94006a2 	ldr	x2, [x21, #8]
    8240:	f9400861 	ldr	x1, [x3, #16]
    8244:	f9400840 	ldr	x0, [x2, #16]
    8248:	fd400461 	ldr	d1, [x3, #8]
    824c:	fd400440 	ldr	d0, [x2, #8]
    8250:	97fff540 	bl	5750 <w107>
    8254:	f9000660 	str	x0, [x19, #8]
    8258:	f8010e61 	str	x1, [x19, #16]!
    825c:	f9400a94 	ldr	x20, [x20, #16]
    8260:	f9400ab5 	ldr	x21, [x21, #16]
    8264:	eb13033f 	cmp	x25, x19
    8268:	54fffe81 	b.ne	8238 <f23+0x1c8>  // b.any
    826c:	aa1803e0 	mov	x0, x24
    8270:	97fffee8 	bl	7e10 <fwp_drop2>
    8274:	aa1603e0 	mov	x0, x22
    8278:	97fffee6 	bl	7e10 <fwp_drop2>
    827c:	911982f7 	add	x23, x23, #0x660
    8280:	aa1a03e0 	mov	x0, x26
    8284:	97fff587 	bl	58a0 <w164.constprop.0>
    8288:	aa0103f3 	mov	x19, x1
    828c:	aa0003f4 	mov	x20, x0
    8290:	aa1a03e0 	mov	x0, x26
    8294:	97fff9f7 	bl	6a70 <fwp_drop4>
    8298:	a900cff4 	stp	x20, x19, [sp, #8]
    829c:	910023e1 	add	x1, sp, #0x8
    82a0:	52800000 	mov	w0, #0x0                   	// #0
    82a4:	97fff5ab 	bl	5950 <fwp_data.part.0.constprop.0>
    82a8:	f949dae1 	ldr	x1, [x23, #5040]
    82ac:	aa0003f3 	mov	x19, x0
    82b0:	f949eee0 	ldr	x0, [x23, #5080]
    82b4:	cb010261 	sub	x1, x19, x1
    82b8:	eb00403f 	cmp	x1, x0, lsl #16
    82bc:	54000322 	b.cs	8320 <f23+0x2b0>  // b.hs, b.nlast
    82c0:	d350fc22 	lsr	x2, x1, #16
    82c4:	f949fee3 	ldr	x3, [x23, #5112]
    82c8:	8b020842 	add	x2, x2, x2, lsl #2
    82cc:	d37df042 	lsl	x2, x2, #3
    82d0:	8b020060 	add	x0, x3, x2
    82d4:	f9401014 	ldr	x20, [x0, #32]
    82d8:	b4000254 	cbz	x20, 8320 <f23+0x2b0>
    82dc:	38626862 	ldrb	w2, [x3, x2]
    82e0:	7100085f 	cmp	w2, #0x2
    82e4:	540003c0 	b.eq	835c <f23+0x2ec>  // b.none
    82e8:	7100045f 	cmp	w2, #0x1
    82ec:	540001a1 	b.ne	8320 <f23+0x2b0>  // b.any
    82f0:	29430002 	ldp	w2, w0, [x0, #24]
    82f4:	92403c21 	and	x1, x1, #0xffff
    82f8:	9b027c21 	mul	x1, x1, x2
    82fc:	d360fc21 	lsr	x1, x1, #32
    8300:	eb00003f 	cmp	x1, x0
    8304:	540000e2 	b.cs	8320 <f23+0x2b0>  // b.hs, b.nlast
    8308:	8b010294 	add	x20, x20, x1
    830c:	39400280 	ldrb	w0, [x20]
    8310:	7103fc1f 	cmp	w0, #0xff
    8314:	54000640 	b.eq	83dc <f23+0x36c>  // b.none
    8318:	52800020 	mov	w0, #0x1                   	// #1
    831c:	39000280 	strb	w0, [x20]
    8320:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8324:	f947f400 	ldr	x0, [x0, #4072]
    8328:	f9400fe2 	ldr	x2, [sp, #24]
    832c:	f9400001 	ldr	x1, [x0]
    8330:	eb010042 	subs	x2, x2, x1
    8334:	d2800001 	mov	x1, #0x0                   	// #0
    8338:	54000721 	b.ne	841c <f23+0x3ac>  // b.any
    833c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8340:	aa1303e0 	mov	x0, x19
    8344:	a94353f3 	ldp	x19, x20, [sp, #48]
    8348:	a9445bf5 	ldp	x21, x22, [sp, #64]
    834c:	a94563f7 	ldp	x23, x24, [sp, #80]
    8350:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8354:	9101c3ff 	add	sp, sp, #0x70
    8358:	d65f03c0 	ret
    835c:	72003c3f 	tst	w1, #0xffff
    8360:	54fffe01 	b.ne	8320 <f23+0x2b0>  // b.any
    8364:	17ffffea 	b	830c <f23+0x29c>
    8368:	72003c3f 	tst	w1, #0xffff
    836c:	54fff5c1 	b.ne	8224 <f23+0x1b4>  // b.any
    8370:	17ffffa8 	b	8210 <f23+0x1a0>
    8374:	72003c3f 	tst	w1, #0xffff
    8378:	54ffee21 	b.ne	813c <f23+0xcc>  // b.any
    837c:	17ffff66 	b	8114 <f23+0xa4>
    8380:	f940bc43 	ldr	x3, [x2, #376]
    8384:	91000463 	add	x3, x3, #0x1
    8388:	f900bc43 	str	x3, [x2, #376]
    838c:	17ffff68 	b	812c <f23+0xbc>
    8390:	cb0103e1 	neg	x1, x1
    8394:	eb02003f 	cmp	x1, x2
    8398:	540002e3 	b.cc	83f4 <f23+0x384>  // b.lo, b.ul, b.last
    839c:	d503201f 	nop
    83a0:	52800041 	mov	w1, #0x2                   	// #2
    83a4:	d2800100 	mov	x0, #0x8                   	// #8
    83a8:	97fff34e 	bl	50e0 <fwp_heap_alloc>
    83ac:	aa0003e1 	mov	x1, x0
    83b0:	911982e0 	add	x0, x23, #0x660
    83b4:	aa0103fa 	mov	x26, x1
    83b8:	d2800018 	mov	x24, #0x0                   	// #0
    83bc:	f900003f 	str	xzr, [x1]
    83c0:	f949d801 	ldr	x1, [x0, #5040]
    83c4:	f949ec00 	ldr	x0, [x0, #5080]
    83c8:	cb010341 	sub	x1, x26, x1
    83cc:	eb00403f 	cmp	x1, x0, lsl #16
    83d0:	54fff4e2 	b.cs	826c <f23+0x1fc>  // b.hs, b.nlast
    83d4:	d2800019 	mov	x25, #0x0                   	// #0
    83d8:	17ffff7a 	b	81c0 <f23+0x150>
    83dc:	aa1403e0 	mov	x0, x20
    83e0:	97fff180 	bl	49e0 <fwp_rc_forget_slot>
    83e4:	17ffffcd 	b	8318 <f23+0x2a8>
    83e8:	aa1303e0 	mov	x0, x19
    83ec:	97fff17d 	bl	49e0 <fwp_rc_forget_slot>
    83f0:	17ffff8b 	b	821c <f23+0x1ac>
    83f4:	f949fc62 	ldr	x2, [x3, #5112]
    83f8:	d350fc20 	lsr	x0, x1, #16
    83fc:	8b000800 	add	x0, x0, x0, lsl #2
    8400:	8b000c42 	add	x2, x2, x0, lsl #3
    8404:	f9401040 	ldr	x0, [x2, #32]
    8408:	b4fffcc0 	cbz	x0, 83a0 <f23+0x330>
    840c:	d2800018 	mov	x24, #0x0                   	// #0
    8410:	17ffff35 	b	80e4 <f23+0x74>
    8414:	97fff12c 	bl	48c4 <fwp_rc_wide_dup>
    8418:	17ffff49 	b	813c <f23+0xcc>
    841c:	97ffe8fd 	bl	2810 <__stack_chk_fail@plt>
    8420:	f0000000 	adrp	x0, b000 <__divti3+0x70>
    8424:	9134c000 	add	x0, x0, #0xd30
    8428:	97ffecd6 	bl	3780 <fwp_trap>
    842c:	d503201f 	nop

0000000000008430 <fwp_owned_entry23>:
    8430:	f9400000 	ldr	x0, [x0]
    8434:	17ffff0f 	b	8070 <f23>
    8438:	d503201f 	nop
    843c:	d503201f 	nop

0000000000008440 <e23>:
    8440:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8444:	910003fd 	mov	x29, sp
    8448:	f9000bf3 	str	x19, [sp, #16]
    844c:	f9400013 	ldr	x19, [x0]
    8450:	aa1303e0 	mov	x0, x19
    8454:	97fff59c 	bl	5ac4 <fwp_rc_share>
    8458:	aa1303e0 	mov	x0, x19
    845c:	97ffff05 	bl	8070 <f23>
    8460:	aa0003f3 	mov	x19, x0
    8464:	97fff598 	bl	5ac4 <fwp_rc_share>
    8468:	aa1303e0 	mov	x0, x19
    846c:	f9400bf3 	ldr	x19, [sp, #16]
    8470:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8474:	d65f03c0 	ret
    8478:	d503201f 	nop
    847c:	d503201f 	nop

0000000000008480 <fwp_args12>:
    8480:	7100003f 	cmp	w1, #0x0
    8484:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8488:	54000041 	b.ne	8490 <fwp_args12+0x10>  // b.any
    848c:	d65f03c0 	ret
    8490:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    8494:	91198042 	add	x2, x2, #0x660
    8498:	f9400001 	ldr	x1, [x0]
    849c:	f949d843 	ldr	x3, [x2, #5040]
    84a0:	f949ec40 	ldr	x0, [x2, #5080]
    84a4:	cb030021 	sub	x1, x1, x3
    84a8:	eb00403f 	cmp	x1, x0, lsl #16
    84ac:	54ffff02 	b.cs	848c <fwp_args12+0xc>  // b.hs, b.nlast
    84b0:	d350fc20 	lsr	x0, x1, #16
    84b4:	f949fc44 	ldr	x4, [x2, #5112]
    84b8:	8b000800 	add	x0, x0, x0, lsl #2
    84bc:	d37df002 	lsl	x2, x0, #3
    84c0:	8b020083 	add	x3, x4, x2
    84c4:	f9401060 	ldr	x0, [x3, #32]
    84c8:	b4fffe20 	cbz	x0, 848c <fwp_args12+0xc>
    84cc:	38626882 	ldrb	w2, [x4, x2]
    84d0:	7100085f 	cmp	w2, #0x2
    84d4:	54000320 	b.eq	8538 <fwp_args12+0xb8>  // b.none
    84d8:	7100045f 	cmp	w2, #0x1
    84dc:	54fffd81 	b.ne	848c <fwp_args12+0xc>  // b.any
    84e0:	29430864 	ldp	w4, w2, [x3, #24]
    84e4:	92403c21 	and	x1, x1, #0xffff
    84e8:	9b047c21 	mul	x1, x1, x4
    84ec:	d360fc21 	lsr	x1, x1, #32
    84f0:	eb02003f 	cmp	x1, x2
    84f4:	54fffcc2 	b.cs	848c <fwp_args12+0xc>  // b.hs, b.nlast
    84f8:	8b010000 	add	x0, x0, x1
    84fc:	39400001 	ldrb	w1, [x0]
    8500:	34fffc61 	cbz	w1, 848c <fwp_args12+0xc>
    8504:	900000c2 	adrp	x2, 20000 <__data_start>
    8508:	91018042 	add	x2, x2, #0x60
    850c:	b9415043 	ldr	w3, [x2, #336]
    8510:	350000c3 	cbnz	w3, 8528 <fwp_args12+0xa8>
    8514:	7103f43f 	cmp	w1, #0xfd
    8518:	54000168 	b.hi	8544 <fwp_args12+0xc4>  // b.pmore
    851c:	11000421 	add	w1, w1, #0x1
    8520:	39000001 	strb	w1, [x0]
    8524:	d65f03c0 	ret
    8528:	f940bc43 	ldr	x3, [x2, #376]
    852c:	91000463 	add	x3, x3, #0x1
    8530:	f900bc43 	str	x3, [x2, #376]
    8534:	17fffff8 	b	8514 <fwp_args12+0x94>
    8538:	72003c3f 	tst	w1, #0xffff
    853c:	54fffe00 	b.eq	84fc <fwp_args12+0x7c>  // b.none
    8540:	d65f03c0 	ret
    8544:	17fff0e0 	b	48c4 <fwp_rc_wide_dup>
    8548:	d503201f 	nop
    854c:	d503201f 	nop

0000000000008550 <fwp_args23>:
    8550:	7100003f 	cmp	w1, #0x0
    8554:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8558:	54000041 	b.ne	8560 <fwp_args23+0x10>  // b.any
    855c:	d65f03c0 	ret
    8560:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    8564:	91198042 	add	x2, x2, #0x660
    8568:	f9400001 	ldr	x1, [x0]
    856c:	f949d843 	ldr	x3, [x2, #5040]
    8570:	f949ec40 	ldr	x0, [x2, #5080]
    8574:	cb030021 	sub	x1, x1, x3
    8578:	eb00403f 	cmp	x1, x0, lsl #16
    857c:	54ffff02 	b.cs	855c <fwp_args23+0xc>  // b.hs, b.nlast
    8580:	d350fc20 	lsr	x0, x1, #16
    8584:	f949fc44 	ldr	x4, [x2, #5112]
    8588:	8b000800 	add	x0, x0, x0, lsl #2
    858c:	d37df002 	lsl	x2, x0, #3
    8590:	8b020083 	add	x3, x4, x2
    8594:	f9401060 	ldr	x0, [x3, #32]
    8598:	b4fffe20 	cbz	x0, 855c <fwp_args23+0xc>
    859c:	38626882 	ldrb	w2, [x4, x2]
    85a0:	7100085f 	cmp	w2, #0x2
    85a4:	54000320 	b.eq	8608 <fwp_args23+0xb8>  // b.none
    85a8:	7100045f 	cmp	w2, #0x1
    85ac:	54fffd81 	b.ne	855c <fwp_args23+0xc>  // b.any
    85b0:	29430864 	ldp	w4, w2, [x3, #24]
    85b4:	92403c21 	and	x1, x1, #0xffff
    85b8:	9b047c21 	mul	x1, x1, x4
    85bc:	d360fc21 	lsr	x1, x1, #32
    85c0:	eb02003f 	cmp	x1, x2
    85c4:	54fffcc2 	b.cs	855c <fwp_args23+0xc>  // b.hs, b.nlast
    85c8:	8b010000 	add	x0, x0, x1
    85cc:	39400001 	ldrb	w1, [x0]
    85d0:	34fffc61 	cbz	w1, 855c <fwp_args23+0xc>
    85d4:	900000c2 	adrp	x2, 20000 <__data_start>
    85d8:	91018042 	add	x2, x2, #0x60
    85dc:	b9415043 	ldr	w3, [x2, #336]
    85e0:	350000c3 	cbnz	w3, 85f8 <fwp_args23+0xa8>
    85e4:	7103f43f 	cmp	w1, #0xfd
    85e8:	54000168 	b.hi	8614 <fwp_args23+0xc4>  // b.pmore
    85ec:	11000421 	add	w1, w1, #0x1
    85f0:	39000001 	strb	w1, [x0]
    85f4:	d65f03c0 	ret
    85f8:	f940bc43 	ldr	x3, [x2, #376]
    85fc:	91000463 	add	x3, x3, #0x1
    8600:	f900bc43 	str	x3, [x2, #376]
    8604:	17fffff8 	b	85e4 <fwp_args23+0x94>
    8608:	72003c3f 	tst	w1, #0xffff
    860c:	54fffe00 	b.eq	85cc <fwp_args23+0x7c>  // b.none
    8610:	d65f03c0 	ret
    8614:	17fff0ac 	b	48c4 <fwp_rc_wide_dup>
    8618:	d503201f 	nop
    861c:	d503201f 	nop

0000000000008620 <fwp_caps12>:
    8620:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8624:	910003fd 	mov	x29, sp
    8628:	f9000bf3 	str	x19, [sp, #16]
    862c:	aa0003f3 	mov	x19, x0
    8630:	b9400400 	ldr	w0, [x0, #4]
    8634:	340004a0 	cbz	w0, 86c8 <fwp_caps12+0xa8>
    8638:	f9400660 	ldr	x0, [x19, #8]
    863c:	350004e1 	cbnz	w1, 86d8 <fwp_caps12+0xb8>
    8640:	97fff624 	bl	5ed0 <fwp_drop0>
    8644:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    8648:	91198042 	add	x2, x2, #0x660
    864c:	f949d840 	ldr	x0, [x2, #5040]
    8650:	f949ec41 	ldr	x1, [x2, #5080]
    8654:	cb000260 	sub	x0, x19, x0
    8658:	eb01401f 	cmp	x0, x1, lsl #16
    865c:	54000382 	b.cs	86cc <fwp_caps12+0xac>  // b.hs, b.nlast
    8660:	d350fc01 	lsr	x1, x0, #16
    8664:	f949fc44 	ldr	x4, [x2, #5112]
    8668:	8b010821 	add	x1, x1, x1, lsl #2
    866c:	d37df021 	lsl	x1, x1, #3
    8670:	8b010083 	add	x3, x4, x1
    8674:	f9401062 	ldr	x2, [x3, #32]
    8678:	b40002a2 	cbz	x2, 86cc <fwp_caps12+0xac>
    867c:	38616881 	ldrb	w1, [x4, x1]
    8680:	7100083f 	cmp	w1, #0x2
    8684:	54000740 	b.eq	876c <fwp_caps12+0x14c>  // b.none
    8688:	7100043f 	cmp	w1, #0x1
    868c:	54000201 	b.ne	86cc <fwp_caps12+0xac>  // b.any
    8690:	29430464 	ldp	w4, w1, [x3, #24]
    8694:	92403c00 	and	x0, x0, #0xffff
    8698:	9b047c00 	mul	x0, x0, x4
    869c:	d360fc00 	lsr	x0, x0, #32
    86a0:	eb01001f 	cmp	x0, x1
    86a4:	54000142 	b.cs	86cc <fwp_caps12+0xac>  // b.hs, b.nlast
    86a8:	8b000042 	add	x2, x2, x0
    86ac:	39400040 	ldrb	w0, [x2]
    86b0:	7100041f 	cmp	w0, #0x1
    86b4:	540000c1 	b.ne	86cc <fwp_caps12+0xac>  // b.any
    86b8:	aa1303e0 	mov	x0, x19
    86bc:	f9400bf3 	ldr	x19, [sp, #16]
    86c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    86c4:	17fff167 	b	4c60 <fwp_mem_free>
    86c8:	34fffbe1 	cbz	w1, 8644 <fwp_caps12+0x24>
    86cc:	f9400bf3 	ldr	x19, [sp, #16]
    86d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    86d4:	d65f03c0 	ret
    86d8:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    86dc:	91198042 	add	x2, x2, #0x660
    86e0:	f949d843 	ldr	x3, [x2, #5040]
    86e4:	f949ec41 	ldr	x1, [x2, #5080]
    86e8:	cb030000 	sub	x0, x0, x3
    86ec:	eb01401f 	cmp	x0, x1, lsl #16
    86f0:	54fffee2 	b.cs	86cc <fwp_caps12+0xac>  // b.hs, b.nlast
    86f4:	d350fc01 	lsr	x1, x0, #16
    86f8:	f949fc44 	ldr	x4, [x2, #5112]
    86fc:	8b010821 	add	x1, x1, x1, lsl #2
    8700:	d37df021 	lsl	x1, x1, #3
    8704:	8b010083 	add	x3, x4, x1
    8708:	f9401062 	ldr	x2, [x3, #32]
    870c:	b4fffe02 	cbz	x2, 86cc <fwp_caps12+0xac>
    8710:	38616881 	ldrb	w1, [x4, x1]
    8714:	7100083f 	cmp	w1, #0x2
    8718:	54000300 	b.eq	8778 <fwp_caps12+0x158>  // b.none
    871c:	7100043f 	cmp	w1, #0x1
    8720:	54fffd61 	b.ne	86cc <fwp_caps12+0xac>  // b.any
    8724:	92403c01 	and	x1, x0, #0xffff
    8728:	29430064 	ldp	w4, w0, [x3, #24]
    872c:	9b047c21 	mul	x1, x1, x4
    8730:	d360fc21 	lsr	x1, x1, #32
    8734:	eb00003f 	cmp	x1, x0
    8738:	54fffca2 	b.cs	86cc <fwp_caps12+0xac>  // b.hs, b.nlast
    873c:	8b010042 	add	x2, x2, x1
    8740:	39400040 	ldrb	w0, [x2]
    8744:	34fffc40 	cbz	w0, 86cc <fwp_caps12+0xac>
    8748:	900000c1 	adrp	x1, 20000 <__data_start>
    874c:	91018021 	add	x1, x1, #0x60
    8750:	b9415023 	ldr	w3, [x1, #336]
    8754:	35000183 	cbnz	w3, 8784 <fwp_caps12+0x164>
    8758:	7103f41f 	cmp	w0, #0xfd
    875c:	540001c8 	b.hi	8794 <fwp_caps12+0x174>  // b.pmore
    8760:	11000400 	add	w0, w0, #0x1
    8764:	39000040 	strb	w0, [x2]
    8768:	17ffffd9 	b	86cc <fwp_caps12+0xac>
    876c:	72003c1f 	tst	w0, #0xffff
    8770:	54fffae1 	b.ne	86cc <fwp_caps12+0xac>  // b.any
    8774:	17ffffce 	b	86ac <fwp_caps12+0x8c>
    8778:	72003c1f 	tst	w0, #0xffff
    877c:	54fffa81 	b.ne	86cc <fwp_caps12+0xac>  // b.any
    8780:	17fffff0 	b	8740 <fwp_caps12+0x120>
    8784:	f940bc23 	ldr	x3, [x1, #376]
    8788:	91000463 	add	x3, x3, #0x1
    878c:	f900bc23 	str	x3, [x1, #376]
    8790:	17fffff2 	b	8758 <fwp_caps12+0x138>
    8794:	f9400bf3 	ldr	x19, [sp, #16]
    8798:	aa0203e0 	mov	x0, x2
    879c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    87a0:	17fff049 	b	48c4 <fwp_rc_wide_dup>

00000000000087a4 <fwp_caps23>:
    87a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    87a8:	910003fd 	mov	x29, sp
    87ac:	f9000bf3 	str	x19, [sp, #16]
    87b0:	aa0003f3 	mov	x19, x0
    87b4:	b9400400 	ldr	w0, [x0, #4]
    87b8:	340004a0 	cbz	w0, 884c <fwp_caps23+0xa8>
    87bc:	f9400660 	ldr	x0, [x19, #8]
    87c0:	350004e1 	cbnz	w1, 885c <fwp_caps23+0xb8>
    87c4:	97fffd93 	bl	7e10 <fwp_drop2>
    87c8:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    87cc:	91198042 	add	x2, x2, #0x660
    87d0:	f949d840 	ldr	x0, [x2, #5040]
    87d4:	f949ec41 	ldr	x1, [x2, #5080]
    87d8:	cb000260 	sub	x0, x19, x0
    87dc:	eb01401f 	cmp	x0, x1, lsl #16
    87e0:	54000382 	b.cs	8850 <fwp_caps23+0xac>  // b.hs, b.nlast
    87e4:	d350fc01 	lsr	x1, x0, #16
    87e8:	f949fc44 	ldr	x4, [x2, #5112]
    87ec:	8b010821 	add	x1, x1, x1, lsl #2
    87f0:	d37df021 	lsl	x1, x1, #3
    87f4:	8b010083 	add	x3, x4, x1
    87f8:	f9401062 	ldr	x2, [x3, #32]
    87fc:	b40002a2 	cbz	x2, 8850 <fwp_caps23+0xac>
    8800:	38616881 	ldrb	w1, [x4, x1]
    8804:	7100083f 	cmp	w1, #0x2
    8808:	54000740 	b.eq	88f0 <fwp_caps23+0x14c>  // b.none
    880c:	7100043f 	cmp	w1, #0x1
    8810:	54000201 	b.ne	8850 <fwp_caps23+0xac>  // b.any
    8814:	29430464 	ldp	w4, w1, [x3, #24]
    8818:	92403c00 	and	x0, x0, #0xffff
    881c:	9b047c00 	mul	x0, x0, x4
    8820:	d360fc00 	lsr	x0, x0, #32
    8824:	eb01001f 	cmp	x0, x1
    8828:	54000142 	b.cs	8850 <fwp_caps23+0xac>  // b.hs, b.nlast
    882c:	8b000042 	add	x2, x2, x0
    8830:	39400040 	ldrb	w0, [x2]
    8834:	7100041f 	cmp	w0, #0x1
    8838:	540000c1 	b.ne	8850 <fwp_caps23+0xac>  // b.any
    883c:	aa1303e0 	mov	x0, x19
    8840:	f9400bf3 	ldr	x19, [sp, #16]
    8844:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8848:	17fff106 	b	4c60 <fwp_mem_free>
    884c:	34fffbe1 	cbz	w1, 87c8 <fwp_caps23+0x24>
    8850:	f9400bf3 	ldr	x19, [sp, #16]
    8854:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8858:	d65f03c0 	ret
    885c:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    8860:	91198042 	add	x2, x2, #0x660
    8864:	f949d843 	ldr	x3, [x2, #5040]
    8868:	f949ec41 	ldr	x1, [x2, #5080]
    886c:	cb030000 	sub	x0, x0, x3
    8870:	eb01401f 	cmp	x0, x1, lsl #16
    8874:	54fffee2 	b.cs	8850 <fwp_caps23+0xac>  // b.hs, b.nlast
    8878:	d350fc01 	lsr	x1, x0, #16
    887c:	f949fc44 	ldr	x4, [x2, #5112]
    8880:	8b010821 	add	x1, x1, x1, lsl #2
    8884:	d37df021 	lsl	x1, x1, #3
    8888:	8b010083 	add	x3, x4, x1
    888c:	f9401062 	ldr	x2, [x3, #32]
    8890:	b4fffe02 	cbz	x2, 8850 <fwp_caps23+0xac>
    8894:	38616881 	ldrb	w1, [x4, x1]
    8898:	7100083f 	cmp	w1, #0x2
    889c:	54000300 	b.eq	88fc <fwp_caps23+0x158>  // b.none
    88a0:	7100043f 	cmp	w1, #0x1
    88a4:	54fffd61 	b.ne	8850 <fwp_caps23+0xac>  // b.any
    88a8:	92403c01 	and	x1, x0, #0xffff
    88ac:	29430064 	ldp	w4, w0, [x3, #24]
    88b0:	9b047c21 	mul	x1, x1, x4
    88b4:	d360fc21 	lsr	x1, x1, #32
    88b8:	eb00003f 	cmp	x1, x0
    88bc:	54fffca2 	b.cs	8850 <fwp_caps23+0xac>  // b.hs, b.nlast
    88c0:	8b010042 	add	x2, x2, x1
    88c4:	39400040 	ldrb	w0, [x2]
    88c8:	34fffc40 	cbz	w0, 8850 <fwp_caps23+0xac>
    88cc:	900000c1 	adrp	x1, 20000 <__data_start>
    88d0:	91018021 	add	x1, x1, #0x60
    88d4:	b9415023 	ldr	w3, [x1, #336]
    88d8:	35000183 	cbnz	w3, 8908 <fwp_caps23+0x164>
    88dc:	7103f41f 	cmp	w0, #0xfd
    88e0:	540001c8 	b.hi	8918 <fwp_caps23+0x174>  // b.pmore
    88e4:	11000400 	add	w0, w0, #0x1
    88e8:	39000040 	strb	w0, [x2]
    88ec:	17ffffd9 	b	8850 <fwp_caps23+0xac>
    88f0:	72003c1f 	tst	w0, #0xffff
    88f4:	54fffae1 	b.ne	8850 <fwp_caps23+0xac>  // b.any
    88f8:	17ffffce 	b	8830 <fwp_caps23+0x8c>
    88fc:	72003c1f 	tst	w0, #0xffff
    8900:	54fffa81 	b.ne	8850 <fwp_caps23+0xac>  // b.any
    8904:	17fffff0 	b	88c4 <fwp_caps23+0x120>
    8908:	f940bc23 	ldr	x3, [x1, #376]
    890c:	91000463 	add	x3, x3, #0x1
    8910:	f900bc23 	str	x3, [x1, #376]
    8914:	17fffff2 	b	88dc <fwp_caps23+0x138>
    8918:	f9400bf3 	ldr	x19, [sp, #16]
    891c:	aa0203e0 	mov	x0, x2
    8920:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8924:	17ffefe8 	b	48c4 <fwp_rc_wide_dup>
    8928:	d503201f 	nop
    892c:	d503201f 	nop

0000000000008930 <fwp_write>:
    8930:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8934:	910003fd 	mov	x29, sp
    8938:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    893c:	f947f484 	ldr	x4, [x4, #4072]
    8940:	a90153f3 	stp	x19, x20, [sp, #16]
    8944:	d10943ff 	sub	sp, sp, #0x250
    8948:	b9400045 	ldr	w5, [x2]
    894c:	aa0003f4 	mov	x20, x0
    8950:	f9400080 	ldr	x0, [x4]
    8954:	f90127e0 	str	x0, [sp, #584]
    8958:	d2800000 	mov	x0, #0x0                   	// #0
    895c:	710064bf 	cmp	w5, #0x19
    8960:	54000408 	b.hi	89e0 <fwp_write+0xb0>  // b.pmore
    8964:	90000020 	adrp	x0, c000 <_IO_stdin_used+0x950>
    8968:	aa0103f3 	mov	x19, x1
    896c:	91178000 	add	x0, x0, #0x5e0
    8970:	f9013bf5 	str	x21, [sp, #624]
    8974:	f9013ff6 	str	x22, [sp, #632]
    8978:	f90153fb 	str	x27, [sp, #672]
    897c:	f90157fc 	str	x28, [sp, #680]
    8980:	aa0203fc 	mov	x28, x2
    8984:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8988:	10000061 	adr	x1, 8994 <fwp_write+0x64>
    898c:	8b20a820 	add	x0, x1, w0, sxth #2
    8990:	d61f0000 	br	x0
    8994:	910123e0 	add	x0, sp, #0x48
    8998:	aa1303e5 	mov	x5, x19
    899c:	f0000004 	adrp	x4, b000 <__divti3+0x70>
    89a0:	aa0003f3 	mov	x19, x0
    89a4:	91374084 	add	x4, x4, #0xdd0
    89a8:	d2804003 	mov	x3, #0x200                 	// #512
    89ac:	aa0303e1 	mov	x1, x3
    89b0:	52800042 	mov	w2, #0x2                   	// #2
    89b4:	97ffe773 	bl	2780 <__snprintf_chk@plt>
    89b8:	aa1303e0 	mov	x0, x19
    89bc:	97ffe739 	bl	26a0 <strlen@plt>
    89c0:	aa1303e1 	mov	x1, x19
    89c4:	aa0003e2 	mov	x2, x0
    89c8:	aa1403e0 	mov	x0, x20
    89cc:	97ffeb11 	bl	3610 <buf_put>
    89d0:	f9413bf5 	ldr	x21, [sp, #624]
    89d4:	f9413ff6 	ldr	x22, [sp, #632]
    89d8:	f94153fb 	ldr	x27, [sp, #672]
    89dc:	f94157fc 	ldr	x28, [sp, #680]
    89e0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    89e4:	f947f400 	ldr	x0, [x0, #4072]
    89e8:	f94127e2 	ldr	x2, [sp, #584]
    89ec:	f9400001 	ldr	x1, [x0]
    89f0:	eb010042 	subs	x2, x2, x1
    89f4:	d2800001 	mov	x1, #0x0                   	// #0
    89f8:	540077c1 	b.ne	98f0 <fwp_write+0xfc0>  // b.any
    89fc:	910943ff 	add	sp, sp, #0x250
    8a00:	a94153f3 	ldp	x19, x20, [sp, #16]
    8a04:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8a08:	d65f03c0 	ret
    8a0c:	910123e0 	add	x0, sp, #0x48
    8a10:	aa1303e5 	mov	x5, x19
    8a14:	f0000004 	adrp	x4, b000 <__divti3+0x70>
    8a18:	aa0003f3 	mov	x19, x0
    8a1c:	91372084 	add	x4, x4, #0xdc8
    8a20:	d2804003 	mov	x3, #0x200                 	// #512
    8a24:	17ffffe2 	b	89ac <fwp_write+0x7c>
    8a28:	71004cbf 	cmp	w5, #0x13
    8a2c:	f0000000 	adrp	x0, b000 <__divti3+0x70>
    8a30:	f0000001 	adrp	x1, b000 <__divti3+0x70>
    8a34:	9136e000 	add	x0, x0, #0xdb8
    8a38:	91370021 	add	x1, x1, #0xdc0
    8a3c:	d2800082 	mov	x2, #0x4                   	// #4
    8a40:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8a44:	aa1403e0 	mov	x0, x20
    8a48:	f90143f7 	str	x23, [sp, #640]
    8a4c:	d2800016 	mov	x22, #0x0                   	// #0
    8a50:	f90147f8 	str	x24, [sp, #648]
    8a54:	97ffeaef 	bl	3610 <buf_put>
    8a58:	f9400260 	ldr	x0, [x19]
    8a5c:	f0000017 	adrp	x23, b000 <__divti3+0x70>
    8a60:	d2800015 	mov	x21, #0x0                   	// #0
    8a64:	913902f7 	add	x23, x23, #0xe40
    8a68:	b40047a0 	cbz	x0, 935c <fwp_write+0xa2c>
    8a6c:	b9400380 	ldr	w0, [x28]
    8a70:	52800003 	mov	w3, #0x0                   	// #0
    8a74:	f9401f82 	ldr	x2, [x28, #56]
    8a78:	71004c1f 	cmp	w0, #0x13
    8a7c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8a80:	aa1403e0 	mov	x0, x20
    8a84:	8b010e61 	add	x1, x19, x1, lsl #3
    8a88:	f9400421 	ldr	x1, [x1, #8]
    8a8c:	97ffffa9 	bl	8930 <fwp_write>
    8a90:	b9400380 	ldr	w0, [x28]
    8a94:	7100481f 	cmp	w0, #0x12
    8a98:	54004b40 	b.eq	9400 <fwp_write+0xad0>  // b.none
    8a9c:	f9400260 	ldr	x0, [x19]
    8aa0:	910006b5 	add	x21, x21, #0x1
    8aa4:	91000ad6 	add	x22, x22, #0x2
    8aa8:	eb15001f 	cmp	x0, x21
    8aac:	54004589 	b.ls	935c <fwp_write+0xa2c>  // b.plast
    8ab0:	aa1703e1 	mov	x1, x23
    8ab4:	aa1403e0 	mov	x0, x20
    8ab8:	d2800042 	mov	x2, #0x2                   	// #2
    8abc:	97ffead5 	bl	3610 <buf_put>
    8ac0:	17ffffeb 	b	8a6c <fwp_write+0x13c>
    8ac4:	f0000001 	adrp	x1, b000 <__divti3+0x70>
    8ac8:	9137e021 	add	x1, x1, #0xdf8
    8acc:	d28000c2 	mov	x2, #0x6                   	// #6
    8ad0:	aa1403e0 	mov	x0, x20
    8ad4:	91004273 	add	x19, x19, #0x10
    8ad8:	97ffeace 	bl	3610 <buf_put>
    8adc:	aa1303e0 	mov	x0, x19
    8ae0:	97ffe6f0 	bl	26a0 <strlen@plt>
    8ae4:	aa1303e1 	mov	x1, x19
    8ae8:	aa0003e2 	mov	x2, x0
    8aec:	aa1403e0 	mov	x0, x20
    8af0:	97ffeac8 	bl	3610 <buf_put>
    8af4:	528007c3 	mov	w3, #0x3e                  	// #62
    8af8:	aa1403e0 	mov	x0, x20
    8afc:	91001fe1 	add	x1, sp, #0x7
    8b00:	d2800022 	mov	x2, #0x1                   	// #1
    8b04:	39001fe3 	strb	w3, [sp, #7]
    8b08:	17ffffb1 	b	89cc <fwp_write+0x9c>
    8b0c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8b10:	f947f400 	ldr	x0, [x0, #4072]
    8b14:	f94127e2 	ldr	x2, [sp, #584]
    8b18:	f9400001 	ldr	x1, [x0]
    8b1c:	eb010042 	subs	x2, x2, x1
    8b20:	d2800001 	mov	x1, #0x0                   	// #0
    8b24:	540034e1 	b.ne	91c0 <fwp_write+0x890>  // b.any
    8b28:	f9413bf5 	ldr	x21, [sp, #624]
    8b2c:	f0000001 	adrp	x1, b000 <__divti3+0x70>
    8b30:	f9413ff6 	ldr	x22, [sp, #632]
    8b34:	aa1403e0 	mov	x0, x20
    8b38:	91376021 	add	x1, x1, #0xdd8
    8b3c:	d2800142 	mov	x2, #0xa                   	// #10
    8b40:	f94153fb 	ldr	x27, [sp, #672]
    8b44:	f94157fc 	ldr	x28, [sp, #680]
    8b48:	910943ff 	add	sp, sp, #0x250
    8b4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8b50:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8b54:	17ffeaaf 	b	3610 <buf_put>
    8b58:	f9400456 	ldr	x22, [x2, #8]
    8b5c:	f90143f7 	str	x23, [sp, #640]
    8b60:	f90147f8 	str	x24, [sp, #648]
    8b64:	b4005b16 	cbz	x22, 96c4 <fwp_write+0xd94>
    8b68:	aa1603e0 	mov	x0, x22
    8b6c:	f0000001 	adrp	x1, b000 <__divti3+0x70>
    8b70:	91396021 	add	x1, x1, #0xe58
    8b74:	97ffe747 	bl	2890 <strcmp@plt>
    8b78:	2a0003f5 	mov	w21, w0
    8b7c:	34005fe0 	cbz	w0, 9778 <fwp_write+0xe48>
    8b80:	aa1603e0 	mov	x0, x22
    8b84:	97ffe6c7 	bl	26a0 <strlen@plt>
    8b88:	aa1603e1 	mov	x1, x22
    8b8c:	aa0003e2 	mov	x2, x0
    8b90:	aa1403e0 	mov	x0, x20
    8b94:	97ffea9f 	bl	3610 <buf_put>
    8b98:	52800403 	mov	w3, #0x20                  	// #32
    8b9c:	91001ff5 	add	x21, sp, #0x7
    8ba0:	aa1503e1 	mov	x1, x21
    8ba4:	aa1403e0 	mov	x0, x20
    8ba8:	d2800022 	mov	x2, #0x1                   	// #1
    8bac:	39001fe3 	strb	w3, [sp, #7]
    8bb0:	97ffea98 	bl	3610 <buf_put>
    8bb4:	52800f63 	mov	w3, #0x7b                  	// #123
    8bb8:	aa1403e0 	mov	x0, x20
    8bbc:	aa1503e1 	mov	x1, x21
    8bc0:	d2800022 	mov	x2, #0x1                   	// #1
    8bc4:	39001fe3 	strb	w3, [sp, #7]
    8bc8:	97ffea92 	bl	3610 <buf_put>
    8bcc:	b9401380 	ldr	w0, [x28, #16]
    8bd0:	52800018 	mov	w24, #0x0                   	// #0
    8bd4:	7100001f 	cmp	w0, #0x0
    8bd8:	54003aad 	b.le	932c <fwp_write+0x9fc>
    8bdc:	f9014bf9 	str	x25, [sp, #656]
    8be0:	f0000019 	adrp	x25, b000 <__divti3+0x70>
    8be4:	913a0339 	add	x25, x25, #0xe80
    8be8:	f9014ffa 	str	x26, [sp, #664]
    8bec:	f000001a 	adrp	x26, b000 <__divti3+0x70>
    8bf0:	9139035a 	add	x26, x26, #0xe40
    8bf4:	91002276 	add	x22, x19, #0x8
    8bf8:	d2800013 	mov	x19, #0x0                   	// #0
    8bfc:	b5003e93 	cbnz	x19, 93cc <fwp_write+0xa9c>
    8c00:	d37df277 	lsl	x23, x19, #3
    8c04:	34003cb8 	cbz	w24, 9398 <fwp_write+0xa68>
    8c08:	f9401382 	ldr	x2, [x28, #32]
    8c0c:	aa1403e0 	mov	x0, x20
    8c10:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8c14:	52800003 	mov	w3, #0x0                   	// #0
    8c18:	f8776842 	ldr	x2, [x2, x23]
    8c1c:	91000673 	add	x19, x19, #0x1
    8c20:	97ffff44 	bl	8930 <fwp_write>
    8c24:	b9401380 	ldr	w0, [x28, #16]
    8c28:	6b13001f 	cmp	w0, w19
    8c2c:	54fffe8c 	b.gt	8bfc <fwp_write+0x2cc>
    8c30:	f9414bf9 	ldr	x25, [sp, #656]
    8c34:	f9414ffa 	ldr	x26, [sp, #664]
    8c38:	340037b8 	cbz	w24, 932c <fwp_write+0x9fc>
    8c3c:	52800523 	mov	w3, #0x29                  	// #41
    8c40:	aa1503e1 	mov	x1, x21
    8c44:	aa1403e0 	mov	x0, x20
    8c48:	d2800022 	mov	x2, #0x1                   	// #1
    8c4c:	39001fe3 	strb	w3, [sp, #7]
    8c50:	97ffea70 	bl	3610 <buf_put>
    8c54:	f9413bf5 	ldr	x21, [sp, #624]
    8c58:	f9413ff6 	ldr	x22, [sp, #632]
    8c5c:	f94143f7 	ldr	x23, [sp, #640]
    8c60:	f94147f8 	ldr	x24, [sp, #648]
    8c64:	f94153fb 	ldr	x27, [sp, #672]
    8c68:	f94157fc 	ldr	x28, [sp, #680]
    8c6c:	17ffff5d 	b	89e0 <fwp_write+0xb0>
    8c70:	b9404855 	ldr	w21, [x2, #72]
    8c74:	aa1403e0 	mov	x0, x20
    8c78:	93407eb6 	sxtw	x22, w21
    8c7c:	91000ac1 	add	x1, x22, #0x2
    8c80:	97ffea30 	bl	3540 <buf_grow>
    8c84:	a9400281 	ldp	x1, x0, [x20]
    8c88:	528e8603 	mov	w3, #0x7430                	// #29744
    8c8c:	78206823 	strh	w3, [x1, x0]
    8c90:	8b000022 	add	x2, x1, x0
    8c94:	710002bf 	cmp	w21, #0x0
    8c98:	540036cd 	b.le	9370 <fwp_write+0xa40>
    8c9c:	110006a3 	add	w3, w21, #0x1
    8ca0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8ca4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8ca8:	91000449 	add	x9, x2, #0x1
    8cac:	8b23c043 	add	x3, x2, w3, sxtw
    8cb0:	f28aaac6 	movk	x6, #0x5556
    8cb4:	f2955568 	movk	x8, #0xaaab
    8cb8:	1400000d 	b	8cec <fwp_write+0x3bc>
    8cbc:	d2800021 	mov	x1, #0x1                   	// #1
    8cc0:	528005a5 	mov	w5, #0x2d                  	// #45
    8cc4:	f100001f 	cmp	x0, #0x0
    8cc8:	9b467e60 	smulh	x0, x19, x6
    8ccc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8cd0:	381ff465 	strb	w5, [x3], #-1
    8cd4:	cb040000 	sub	x0, x0, x4
    8cd8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8cdc:	cb020000 	sub	x0, x0, x2
    8ce0:	8b010013 	add	x19, x0, x1
    8ce4:	eb03013f 	cmp	x9, x3
    8ce8:	54003440 	b.eq	9370 <fwp_write+0xa40>  // b.none
    8cec:	9b467e60 	smulh	x0, x19, x6
    8cf0:	937ffe64 	asr	x4, x19, #63
    8cf4:	52800605 	mov	w5, #0x30                  	// #48
    8cf8:	cb040000 	sub	x0, x0, x4
    8cfc:	8b000400 	add	x0, x0, x0, lsl #1
    8d00:	cb000260 	sub	x0, x19, x0
    8d04:	91000c01 	add	x1, x0, #0x3
    8d08:	9bc87c22 	umulh	x2, x1, x8
    8d0c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8d10:	8b4204e2 	add	x2, x7, x2, lsr #1
    8d14:	eb020021 	subs	x1, x1, x2
    8d18:	54fffd60 	b.eq	8cc4 <fwp_write+0x394>  // b.none
    8d1c:	f100043f 	cmp	x1, #0x1
    8d20:	54fffce1 	b.ne	8cbc <fwp_write+0x38c>  // b.any
    8d24:	d2800001 	mov	x1, #0x0                   	// #0
    8d28:	52800565 	mov	w5, #0x2b                  	// #43
    8d2c:	17ffffe6 	b	8cc4 <fwp_write+0x394>
    8d30:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8d34:	f947f400 	ldr	x0, [x0, #4072]
    8d38:	f94127e2 	ldr	x2, [sp, #584]
    8d3c:	f9400001 	ldr	x1, [x0]
    8d40:	eb010042 	subs	x2, x2, x1
    8d44:	d2800001 	mov	x1, #0x0                   	// #0
    8d48:	540023c1 	b.ne	91c0 <fwp_write+0x890>  // b.any
    8d4c:	f9413bf5 	ldr	x21, [sp, #624]
    8d50:	f0000001 	adrp	x1, b000 <__divti3+0x70>
    8d54:	f9413ff6 	ldr	x22, [sp, #632]
    8d58:	aa1403e0 	mov	x0, x20
    8d5c:	9137a021 	add	x1, x1, #0xde8
    8d60:	d2800102 	mov	x2, #0x8                   	// #8
    8d64:	17ffff77 	b	8b40 <fwp_write+0x210>
    8d68:	aa1403e0 	mov	x0, x20
    8d6c:	f0000001 	adrp	x1, b000 <__divti3+0x70>
    8d70:	d28000c2 	mov	x2, #0x6                   	// #6
    8d74:	91392021 	add	x1, x1, #0xe48
    8d78:	97ffea26 	bl	3610 <buf_put>
    8d7c:	d2800015 	mov	x21, #0x0                   	// #0
    8d80:	f9400263 	ldr	x3, [x19]
    8d84:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8d88:	54002c60 	b.eq	9314 <fwp_write+0x9e4>  // b.none
    8d8c:	f9401f82 	ldr	x2, [x28, #56]
    8d90:	f90143f7 	str	x23, [sp, #640]
    8d94:	f90147f8 	str	x24, [sp, #648]
    8d98:	d2800857 	mov	x23, #0x42                  	// #66
    8d9c:	f9014bf9 	str	x25, [sp, #656]
    8da0:	f0000016 	adrp	x22, b000 <__divti3+0x70>
    8da4:	f9014ffa 	str	x26, [sp, #664]
    8da8:	913902d6 	add	x22, x22, #0xe40
    8dac:	d2800038 	mov	x24, #0x1                   	// #1
    8db0:	f2a18017 	movk	x23, #0xc00, lsl #16
    8db4:	d2809099 	mov	x25, #0x484                 	// #1156
    8db8:	b40004a2 	cbz	x2, 8e4c <fwp_write+0x51c>
    8dbc:	b9400040 	ldr	w0, [x2]
    8dc0:	7100701f 	cmp	w0, #0x1c
    8dc4:	540042c0 	b.eq	961c <fwp_write+0xcec>  // b.none
    8dc8:	71006c1f 	cmp	w0, #0x1b
    8dcc:	54000408 	b.hi	8e4c <fwp_write+0x51c>  // b.pmore
    8dd0:	9ac02301 	lsl	x1, x24, x0
    8dd4:	ea17003f 	tst	x1, x23
    8dd8:	540036a1 	b.ne	94ac <fwp_write+0xb7c>  // b.any
    8ddc:	ea19003f 	tst	x1, x25
    8de0:	54003521 	b.ne	9484 <fwp_write+0xb54>  // b.any
    8de4:	d2800424 	mov	x4, #0x21                  	// #33
    8de8:	ea04003f 	tst	x1, x4
    8dec:	54000300 	b.eq	8e4c <fwp_write+0x51c>  // b.none
    8df0:	b7f849c3 	tbnz	x3, #63, 9728 <fwp_write+0xdf8>
    8df4:	91002261 	add	x1, x19, #0x8
    8df8:	8b150021 	add	x1, x1, x21
    8dfc:	39400021 	ldrb	w1, [x1]
    8e00:	7100001f 	cmp	w0, #0x0
    8e04:	93401c23 	sxtb	x3, w1
    8e08:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8e0c:	d503201f 	nop
    8e10:	aa1403e0 	mov	x0, x20
    8e14:	52800003 	mov	w3, #0x0                   	// #0
    8e18:	97fffec6 	bl	8930 <fwp_write>
    8e1c:	910006b5 	add	x21, x21, #0x1
    8e20:	f9400260 	ldr	x0, [x19]
    8e24:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8e28:	eb0002bf 	cmp	x21, x0
    8e2c:	540026c2 	b.cs	9304 <fwp_write+0x9d4>  // b.hs, b.nlast
    8e30:	d2800042 	mov	x2, #0x2                   	// #2
    8e34:	aa1603e1 	mov	x1, x22
    8e38:	aa1403e0 	mov	x0, x20
    8e3c:	97ffe9f5 	bl	3610 <buf_put>
    8e40:	f9401f82 	ldr	x2, [x28, #56]
    8e44:	f9400263 	ldr	x3, [x19]
    8e48:	b5fffba2 	cbnz	x2, 8dbc <fwp_write+0x48c>
    8e4c:	d37df2a0 	lsl	x0, x21, #3
    8e50:	b7f83f03 	tbnz	x3, #63, 9630 <fwp_write+0xd00>
    8e54:	91002261 	add	x1, x19, #0x8
    8e58:	8b000020 	add	x0, x1, x0
    8e5c:	f9400001 	ldr	x1, [x0]
    8e60:	17ffffec 	b	8e10 <fwp_write+0x4e0>
    8e64:	a9400e62 	ldp	x2, x3, [x19]
    8e68:	b7f83ca3 	tbnz	x3, #63, 95fc <fwp_write+0xccc>
    8e6c:	910123f5 	add	x21, sp, #0x48
    8e70:	aa1503e0 	mov	x0, x21
    8e74:	97ffe7cb 	bl	2da0 <fwp_fmt_u128>
    8e78:	aa1503e0 	mov	x0, x21
    8e7c:	97ffe609 	bl	26a0 <strlen@plt>
    8e80:	aa1503e1 	mov	x1, x21
    8e84:	aa0003e2 	mov	x2, x0
    8e88:	17fffed0 	b	89c8 <fwp_write+0x98>
    8e8c:	fd015be8 	str	d8, [sp, #688]
    8e90:	1e270268 	fmov	s8, w19
    8e94:	fd015fe9 	str	d9, [sp, #696]
    8e98:	1e282100 	fcmp	s8, s8
    8e9c:	54004d26 	b.vs	9840 <fwp_write+0xf10>
    8ea0:	1e20c101 	fabs	s1, s8
    8ea4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8ea8:	1e270000 	fmov	s0, w0
    8eac:	1e202020 	fcmp	s1, s0
    8eb0:	54002c0d 	b.le	9430 <fwp_write+0xb00>
    8eb4:	1e202118 	fcmpe	s8, #0.0
    8eb8:	f0000002 	adrp	x2, b000 <__divti3+0x70>
    8ebc:	9120a042 	add	x2, x2, #0x828
    8ec0:	910123f5 	add	x21, sp, #0x48
    8ec4:	f0000001 	adrp	x1, b000 <__divti3+0x70>
    8ec8:	91366021 	add	x1, x1, #0xd98
    8ecc:	aa1503e0 	mov	x0, x21
    8ed0:	9a81c041 	csel	x1, x2, x1, gt
    8ed4:	97ffe69f 	bl	2950 <strcpy@plt>
    8ed8:	aa1503e0 	mov	x0, x21
    8edc:	97ffe5f1 	bl	26a0 <strlen@plt>
    8ee0:	aa1503e1 	mov	x1, x21
    8ee4:	aa0003e2 	mov	x2, x0
    8ee8:	aa1403e0 	mov	x0, x20
    8eec:	97ffe9c9 	bl	3610 <buf_put>
    8ef0:	f9413bf5 	ldr	x21, [sp, #624]
    8ef4:	f9413ff6 	ldr	x22, [sp, #632]
    8ef8:	f94153fb 	ldr	x27, [sp, #672]
    8efc:	f94157fc 	ldr	x28, [sp, #680]
    8f00:	fd415be8 	ldr	d8, [sp, #688]
    8f04:	fd415fe9 	ldr	d9, [sp, #696]
    8f08:	17fffeb6 	b	89e0 <fwp_write+0xb0>
    8f0c:	f9400276 	ldr	x22, [x19]
    8f10:	34002e03 	cbz	w3, 94d0 <fwp_write+0xba0>
    8f14:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8f18:	f947f400 	ldr	x0, [x0, #4072]
    8f1c:	f94127e2 	ldr	x2, [sp, #584]
    8f20:	f9400001 	ldr	x1, [x0]
    8f24:	eb010042 	subs	x2, x2, x1
    8f28:	d2800001 	mov	x1, #0x0                   	// #0
    8f2c:	540014a1 	b.ne	91c0 <fwp_write+0x890>  // b.any
    8f30:	aa1603e2 	mov	x2, x22
    8f34:	91002261 	add	x1, x19, #0x8
    8f38:	f9413bf5 	ldr	x21, [sp, #624]
    8f3c:	aa1403e0 	mov	x0, x20
    8f40:	f9413ff6 	ldr	x22, [sp, #632]
    8f44:	17fffeff 	b	8b40 <fwp_write+0x210>
    8f48:	fd015be8 	str	d8, [sp, #688]
    8f4c:	9e670268 	fmov	d8, x19
    8f50:	fd015fe9 	str	d9, [sp, #696]
    8f54:	1e682100 	fcmp	d8, d8
    8f58:	54004746 	b.vs	9840 <fwp_write+0xf10>
    8f5c:	1e60c101 	fabs	d1, d8
    8f60:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8f64:	9e670000 	fmov	d0, x0
    8f68:	910123f5 	add	x21, sp, #0x48
    8f6c:	52800033 	mov	w19, #0x1                   	// #1
    8f70:	1e602020 	fcmp	d1, d0
    8f74:	540001ad 	b.le	8fa8 <fwp_write+0x678>
    8f78:	1e602118 	fcmpe	d8, #0.0
    8f7c:	f0000002 	adrp	x2, b000 <__divti3+0x70>
    8f80:	9120a042 	add	x2, x2, #0x828
    8f84:	f0000001 	adrp	x1, b000 <__divti3+0x70>
    8f88:	91366021 	add	x1, x1, #0xd98
    8f8c:	aa1503e0 	mov	x0, x21
    8f90:	9a81c041 	csel	x1, x2, x1, gt
    8f94:	97ffe66f 	bl	2950 <strcpy@plt>
    8f98:	17ffffd0 	b	8ed8 <fwp_write+0x5a8>
    8f9c:	11000673 	add	w19, w19, #0x1
    8fa0:	71004a7f 	cmp	w19, #0x12
    8fa4:	54003860 	b.eq	96b0 <fwp_write+0xd80>  // b.none
    8fa8:	1e604100 	fmov	d0, d8
    8fac:	2a1303e1 	mov	w1, w19
    8fb0:	aa1503e0 	mov	x0, x21
    8fb4:	97ffead8 	bl	3b14 <fwp_format_g.constprop.0>
    8fb8:	aa1503e0 	mov	x0, x21
    8fbc:	d2800001 	mov	x1, #0x0                   	// #0
    8fc0:	97ffe5cc 	bl	26f0 <strtod@plt>
    8fc4:	1e602100 	fcmp	d8, d0
    8fc8:	54fffea1 	b.ne	8f9c <fwp_write+0x66c>  // b.any
    8fcc:	aa1503e0 	mov	x0, x21
    8fd0:	97ffe9c9 	bl	36f4 <fwp_finish_float>
    8fd4:	17ffffc1 	b	8ed8 <fwp_write+0x5a8>
    8fd8:	a9400e62 	ldp	x2, x3, [x19]
    8fdc:	910123f3 	add	x19, sp, #0x48
    8fe0:	aa1303e0 	mov	x0, x19
    8fe4:	97ffe76f 	bl	2da0 <fwp_fmt_u128>
    8fe8:	17fffe74 	b	89b8 <fwp_write+0x88>
    8fec:	f90143f7 	str	x23, [sp, #640]
    8ff0:	f90147f8 	str	x24, [sp, #648]
    8ff4:	2a1303f8 	mov	w24, w19
    8ff8:	f9014bf9 	str	x25, [sp, #656]
    8ffc:	f9014ffa 	str	x26, [sp, #664]
    9000:	f13ffe7f 	cmp	x19, #0xfff
    9004:	54000049 	b.ls	900c <fwp_write+0x6dc>  // b.plast
    9008:	b9400278 	ldr	w24, [x19]
    900c:	f9400f80 	ldr	x0, [x28, #24]
    9010:	2a1803f5 	mov	w21, w24
    9014:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9018:	d37ef6b9 	lsl	x25, x21, #2
    901c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    9020:	aa1603e0 	mov	x0, x22
    9024:	97ffe59f 	bl	26a0 <strlen@plt>
    9028:	aa1603e1 	mov	x1, x22
    902c:	aa0003e2 	mov	x2, x0
    9030:	aa1403e0 	mov	x0, x20
    9034:	97ffe977 	bl	3610 <buf_put>
    9038:	f9401780 	ldr	x0, [x28, #40]
    903c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9040:	7100001f 	cmp	w0, #0x0
    9044:	5400068d 	b.le	9114 <fwp_write+0x7e4>
    9048:	91002276 	add	x22, x19, #0x8
    904c:	91001ff5 	add	x21, sp, #0x7
    9050:	d280001b 	mov	x27, #0x0                   	// #0
    9054:	5280041a 	mov	w26, #0x20                  	// #32
    9058:	f9401b80 	ldr	x0, [x28, #48]
    905c:	aa1503e1 	mov	x1, x21
    9060:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    9064:	d2800022 	mov	x2, #0x1                   	// #1
    9068:	f8786803 	ldr	x3, [x0, x24]
    906c:	aa1403e0 	mov	x0, x20
    9070:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9074:	39001ffa 	strb	w26, [sp, #7]
    9078:	97ffe966 	bl	3610 <buf_put>
    907c:	f13ffeff 	cmp	x23, #0xfff
    9080:	b9400261 	ldr	w1, [x19]
    9084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9088:	7100383f 	cmp	w1, #0xe
    908c:	54000160 	b.eq	90b8 <fwp_write+0x788>  // b.none
    9090:	7100403f 	cmp	w1, #0x10
    9094:	54001a60 	b.eq	93e0 <fwp_write+0xab0>  // b.none
    9098:	7100283f 	cmp	w1, #0xa
    909c:	54002aa0 	b.eq	95f0 <fwp_write+0xcc0>  // b.none
    90a0:	540014ac 	b.gt	9334 <fwp_write+0xa04>
    90a4:	71000c3f 	cmp	w1, #0x3
    90a8:	540029ac 	b.gt	95dc <fwp_write+0xcac>
    90ac:	d37ffee0 	lsr	x0, x23, #63
    90b0:	37f814a1 	tbnz	w1, #31, 9344 <fwp_write+0xa14>
    90b4:	d503201f 	nop
    90b8:	34001460 	cbz	w0, 9344 <fwp_write+0xa14>
    90bc:	52800503 	mov	w3, #0x28                  	// #40
    90c0:	aa1503e1 	mov	x1, x21
    90c4:	aa1403e0 	mov	x0, x20
    90c8:	d2800022 	mov	x2, #0x1                   	// #1
    90cc:	39001fe3 	strb	w3, [sp, #7]
    90d0:	97ffe950 	bl	3610 <buf_put>
    90d4:	aa1303e2 	mov	x2, x19
    90d8:	aa1703e1 	mov	x1, x23
    90dc:	aa1403e0 	mov	x0, x20
    90e0:	52800003 	mov	w3, #0x0                   	// #0
    90e4:	97fffe13 	bl	8930 <fwp_write>
    90e8:	52800523 	mov	w3, #0x29                  	// #41
    90ec:	aa1503e1 	mov	x1, x21
    90f0:	aa1403e0 	mov	x0, x20
    90f4:	d2800022 	mov	x2, #0x1                   	// #1
    90f8:	39001fe3 	strb	w3, [sp, #7]
    90fc:	97ffe945 	bl	3610 <buf_put>
    9100:	f9401780 	ldr	x0, [x28, #40]
    9104:	9100077b 	add	x27, x27, #0x1
    9108:	b8796800 	ldr	w0, [x0, x25]
    910c:	6b1b001f 	cmp	w0, w27
    9110:	54fffa4c 	b.gt	9058 <fwp_write+0x728>
    9114:	f9413bf5 	ldr	x21, [sp, #624]
    9118:	f9413ff6 	ldr	x22, [sp, #632]
    911c:	f94143f7 	ldr	x23, [sp, #640]
    9120:	f94147f8 	ldr	x24, [sp, #648]
    9124:	f9414bf9 	ldr	x25, [sp, #656]
    9128:	f9414ffa 	ldr	x26, [sp, #664]
    912c:	f94153fb 	ldr	x27, [sp, #672]
    9130:	f94157fc 	ldr	x28, [sp, #680]
    9134:	17fffe2b 	b	89e0 <fwp_write+0xb0>
    9138:	52800783 	mov	w3, #0x3c                  	// #60
    913c:	91001ff3 	add	x19, sp, #0x7
    9140:	aa1303e1 	mov	x1, x19
    9144:	d2800022 	mov	x2, #0x1                   	// #1
    9148:	aa1403e0 	mov	x0, x20
    914c:	39001fe3 	strb	w3, [sp, #7]
    9150:	97ffe930 	bl	3610 <buf_put>
    9154:	f9400795 	ldr	x21, [x28, #8]
    9158:	aa1503e0 	mov	x0, x21
    915c:	97ffe551 	bl	26a0 <strlen@plt>
    9160:	aa1503e1 	mov	x1, x21
    9164:	aa0003e2 	mov	x2, x0
    9168:	aa1403e0 	mov	x0, x20
    916c:	97ffe929 	bl	3610 <buf_put>
    9170:	528007c3 	mov	w3, #0x3e                  	// #62
    9174:	aa1303e1 	mov	x1, x19
    9178:	aa1403e0 	mov	x0, x20
    917c:	d2800022 	mov	x2, #0x1                   	// #1
    9180:	39001fe3 	strb	w3, [sp, #7]
    9184:	17fffe12 	b	89cc <fwp_write+0x9c>
    9188:	f100067f 	cmp	x19, #0x1
    918c:	540025a0 	b.eq	9640 <fwp_write+0xd10>  // b.none
    9190:	b100067f 	cmn	x19, #0x1
    9194:	54002bc0 	b.eq	970c <fwp_write+0xddc>  // b.none
    9198:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    919c:	91368021 	add	x1, x1, #0xda0
    91a0:	d2800022 	mov	x2, #0x1                   	// #1
    91a4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    91a8:	f947f400 	ldr	x0, [x0, #4072]
    91ac:	f94127e4 	ldr	x4, [sp, #584]
    91b0:	f9400003 	ldr	x3, [x0]
    91b4:	eb030084 	subs	x4, x4, x3
    91b8:	d2800003 	mov	x3, #0x0                   	// #0
    91bc:	54ffebe0 	b.eq	8f38 <fwp_write+0x608>  // b.none
    91c0:	f90143f7 	str	x23, [sp, #640]
    91c4:	f90147f8 	str	x24, [sp, #648]
    91c8:	f9014bf9 	str	x25, [sp, #656]
    91cc:	f9014ffa 	str	x26, [sp, #664]
    91d0:	fd015be8 	str	d8, [sp, #688]
    91d4:	fd015fe9 	str	d9, [sp, #696]
    91d8:	97ffe58e 	bl	2810 <__stack_chk_fail@plt>
    91dc:	52800b63 	mov	w3, #0x5b                  	// #91
    91e0:	91001ff5 	add	x21, sp, #0x7
    91e4:	aa1503e1 	mov	x1, x21
    91e8:	aa1403e0 	mov	x0, x20
    91ec:	d2800022 	mov	x2, #0x1                   	// #1
    91f0:	d0000016 	adrp	x22, b000 <__divti3+0x70>
    91f4:	913902d6 	add	x22, x22, #0xe40
    91f8:	39001fe3 	strb	w3, [sp, #7]
    91fc:	97ffe905 	bl	3610 <buf_put>
    9200:	b4000273 	cbz	x19, 924c <fwp_write+0x91c>
    9204:	f9400661 	ldr	x1, [x19, #8]
    9208:	aa1403e0 	mov	x0, x20
    920c:	f9401f82 	ldr	x2, [x28, #56]
    9210:	52800003 	mov	w3, #0x0                   	// #0
    9214:	97fffdc7 	bl	8930 <fwp_write>
    9218:	f9400a73 	ldr	x19, [x19, #16]
    921c:	b4000193 	cbz	x19, 924c <fwp_write+0x91c>
    9220:	aa1603e1 	mov	x1, x22
    9224:	aa1403e0 	mov	x0, x20
    9228:	d2800042 	mov	x2, #0x2                   	// #2
    922c:	97ffe8f9 	bl	3610 <buf_put>
    9230:	f9400661 	ldr	x1, [x19, #8]
    9234:	aa1403e0 	mov	x0, x20
    9238:	f9401f82 	ldr	x2, [x28, #56]
    923c:	52800003 	mov	w3, #0x0                   	// #0
    9240:	97fffdbc 	bl	8930 <fwp_write>
    9244:	f9400a73 	ldr	x19, [x19, #16]
    9248:	b5fffed3 	cbnz	x19, 9220 <fwp_write+0x8f0>
    924c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9250:	aa1503e1 	mov	x1, x21
    9254:	aa1403e0 	mov	x0, x20
    9258:	d2800022 	mov	x2, #0x1                   	// #1
    925c:	39001fe3 	strb	w3, [sp, #7]
    9260:	17fffddb 	b	89cc <fwp_write+0x9c>
    9264:	aa1403e0 	mov	x0, x20
    9268:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    926c:	d28000c2 	mov	x2, #0x6                   	// #6
    9270:	9138c021 	add	x1, x1, #0xe30
    9274:	97ffe8e7 	bl	3610 <buf_put>
    9278:	f9400260 	ldr	x0, [x19]
    927c:	b40004c0 	cbz	x0, 9314 <fwp_write+0x9e4>
    9280:	910123f5 	add	x21, sp, #0x48
    9284:	91002276 	add	x22, x19, #0x8
    9288:	f90143f7 	str	x23, [sp, #640]
    928c:	d2800017 	mov	x23, #0x0                   	// #0
    9290:	f90147f8 	str	x24, [sp, #648]
    9294:	d0000018 	adrp	x24, b000 <__divti3+0x70>
    9298:	9138e318 	add	x24, x24, #0xe38
    929c:	f9014bf9 	str	x25, [sp, #656]
    92a0:	d0000019 	adrp	x25, b000 <__divti3+0x70>
    92a4:	91390339 	add	x25, x25, #0xe40
    92a8:	f9014ffa 	str	x26, [sp, #664]
    92ac:	14000005 	b	92c0 <fwp_write+0x990>
    92b0:	aa1903e1 	mov	x1, x25
    92b4:	aa1403e0 	mov	x0, x20
    92b8:	d2800042 	mov	x2, #0x2                   	// #2
    92bc:	97ffe8d5 	bl	3610 <buf_put>
    92c0:	38776ac5 	ldrb	w5, [x22, x23]
    92c4:	d2804003 	mov	x3, #0x200                 	// #512
    92c8:	aa1803e4 	mov	x4, x24
    92cc:	aa0303e1 	mov	x1, x3
    92d0:	52800042 	mov	w2, #0x2                   	// #2
    92d4:	aa1503e0 	mov	x0, x21
    92d8:	910006f7 	add	x23, x23, #0x1
    92dc:	97ffe529 	bl	2780 <__snprintf_chk@plt>
    92e0:	aa1503e0 	mov	x0, x21
    92e4:	97ffe4ef 	bl	26a0 <strlen@plt>
    92e8:	aa1503e1 	mov	x1, x21
    92ec:	aa0003e2 	mov	x2, x0
    92f0:	aa1403e0 	mov	x0, x20
    92f4:	97ffe8c7 	bl	3610 <buf_put>
    92f8:	f9400260 	ldr	x0, [x19]
    92fc:	eb17001f 	cmp	x0, x23
    9300:	54fffd88 	b.hi	92b0 <fwp_write+0x980>  // b.pmore
    9304:	f94143f7 	ldr	x23, [sp, #640]
    9308:	f94147f8 	ldr	x24, [sp, #648]
    930c:	f9414bf9 	ldr	x25, [sp, #656]
    9310:	f9414ffa 	ldr	x26, [sp, #664]
    9314:	52800ba3 	mov	w3, #0x5d                  	// #93
    9318:	aa1403e0 	mov	x0, x20
    931c:	91001fe1 	add	x1, sp, #0x7
    9320:	d2800022 	mov	x2, #0x1                   	// #1
    9324:	39001fe3 	strb	w3, [sp, #7]
    9328:	17fffda9 	b	89cc <fwp_write+0x9c>
    932c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9330:	17fffe44 	b	8c40 <fwp_write+0x310>
    9334:	f10002ff 	cmp	x23, #0x0
    9338:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    933c:	71002c3f 	cmp	w1, #0xb
    9340:	54ffebc0 	b.eq	90b8 <fwp_write+0x788>  // b.none
    9344:	aa1303e2 	mov	x2, x19
    9348:	aa1703e1 	mov	x1, x23
    934c:	aa1403e0 	mov	x0, x20
    9350:	52800003 	mov	w3, #0x0                   	// #0
    9354:	97fffd77 	bl	8930 <fwp_write>
    9358:	17ffff6a 	b	9100 <fwp_write+0x7d0>
    935c:	aa1403e0 	mov	x0, x20
    9360:	91001fe1 	add	x1, sp, #0x7
    9364:	52800fa3 	mov	w3, #0x7d                  	// #125
    9368:	d2800022 	mov	x2, #0x1                   	// #1
    936c:	17fffe38 	b	8c4c <fwp_write+0x31c>
    9370:	a9400281 	ldp	x1, x0, [x20]
    9374:	91000800 	add	x0, x0, #0x2
    9378:	8b160000 	add	x0, x0, x22
    937c:	f9000680 	str	x0, [x20, #8]
    9380:	3820683f 	strb	wzr, [x1, x0]
    9384:	f9413bf5 	ldr	x21, [sp, #624]
    9388:	f9413ff6 	ldr	x22, [sp, #632]
    938c:	f94153fb 	ldr	x27, [sp, #672]
    9390:	f94157fc 	ldr	x28, [sp, #680]
    9394:	17fffd93 	b	89e0 <fwp_write+0xb0>
    9398:	f9400f80 	ldr	x0, [x28, #24]
    939c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    93a0:	aa1b03e0 	mov	x0, x27
    93a4:	97ffe4bf 	bl	26a0 <strlen@plt>
    93a8:	aa1b03e1 	mov	x1, x27
    93ac:	aa0003e2 	mov	x2, x0
    93b0:	aa1403e0 	mov	x0, x20
    93b4:	97ffe897 	bl	3610 <buf_put>
    93b8:	aa1903e1 	mov	x1, x25
    93bc:	aa1403e0 	mov	x0, x20
    93c0:	d2800062 	mov	x2, #0x3                   	// #3
    93c4:	97ffe893 	bl	3610 <buf_put>
    93c8:	17fffe10 	b	8c08 <fwp_write+0x2d8>
    93cc:	aa1a03e1 	mov	x1, x26
    93d0:	aa1403e0 	mov	x0, x20
    93d4:	d2800042 	mov	x2, #0x2                   	// #2
    93d8:	97ffe88e 	bl	3610 <buf_put>
    93dc:	17fffe09 	b	8c00 <fwp_write+0x2d0>
    93e0:	f9400660 	ldr	x0, [x19, #8]
    93e4:	b4fffb00 	cbz	x0, 9344 <fwp_write+0xa14>
    93e8:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    93ec:	91396021 	add	x1, x1, #0xe58
    93f0:	97ffe528 	bl	2890 <strcmp@plt>
    93f4:	7100001f 	cmp	w0, #0x0
    93f8:	1a9f07e0 	cset	w0, ne	// ne = any
    93fc:	17ffff2f 	b	90b8 <fwp_write+0x788>
    9400:	aa1403e0 	mov	x0, x20
    9404:	d2800042 	mov	x2, #0x2                   	// #2
    9408:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    940c:	91394021 	add	x1, x1, #0xe50
    9410:	97ffe880 	bl	3610 <buf_put>
    9414:	91004261 	add	x1, x19, #0x10
    9418:	aa1403e0 	mov	x0, x20
    941c:	f9402382 	ldr	x2, [x28, #64]
    9420:	52800003 	mov	w3, #0x0                   	// #0
    9424:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9428:	97fffd42 	bl	8930 <fwp_write>
    942c:	17fffd9c 	b	8a9c <fwp_write+0x16c>
    9430:	1e22c109 	fcvt	d9, s8
    9434:	910123f5 	add	x21, sp, #0x48
    9438:	52800033 	mov	w19, #0x1                   	// #1
    943c:	d503201f 	nop
    9440:	1e604120 	fmov	d0, d9
    9444:	2a1303e1 	mov	w1, w19
    9448:	aa1503e0 	mov	x0, x21
    944c:	97ffe9b2 	bl	3b14 <fwp_format_g.constprop.0>
    9450:	aa1503e0 	mov	x0, x21
    9454:	d2800001 	mov	x1, #0x0                   	// #0
    9458:	97ffe51a 	bl	28c0 <strtof@plt>
    945c:	1e202100 	fcmp	s8, s0
    9460:	54ffdb60 	b.eq	8fcc <fwp_write+0x69c>  // b.none
    9464:	11000673 	add	w19, w19, #0x1
    9468:	71002a7f 	cmp	w19, #0xa
    946c:	54fffea1 	b.ne	9440 <fwp_write+0xb10>  // b.any
    9470:	1e604120 	fmov	d0, d9
    9474:	aa1503e0 	mov	x0, x21
    9478:	52800121 	mov	w1, #0x9                   	// #9
    947c:	97ffe9a6 	bl	3b14 <fwp_format_g.constprop.0>
    9480:	17fffed3 	b	8fcc <fwp_write+0x69c>
    9484:	d37ef6a1 	lsl	x1, x21, #2
    9488:	b7f81563 	tbnz	x3, #63, 9734 <fwp_write+0xe04>
    948c:	91002263 	add	x3, x19, #0x8
    9490:	8b010061 	add	x1, x3, x1
    9494:	b9400023 	ldr	w3, [x1]
    9498:	7100081f 	cmp	w0, #0x2
    949c:	2a0303e1 	mov	w1, w3
    94a0:	93407c63 	sxtw	x3, w3
    94a4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    94a8:	17fffe5a 	b	8e10 <fwp_write+0x4e0>
    94ac:	d37ffaa1 	lsl	x1, x21, #1
    94b0:	b7f81363 	tbnz	x3, #63, 971c <fwp_write+0xdec>
    94b4:	91002263 	add	x3, x19, #0x8
    94b8:	8b010061 	add	x1, x3, x1
    94bc:	79400021 	ldrh	w1, [x1]
    94c0:	7100041f 	cmp	w0, #0x1
    94c4:	93403c23 	sxth	x3, w1
    94c8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    94cc:	17fffe51 	b	8e10 <fwp_write+0x4e0>
    94d0:	52800443 	mov	w3, #0x22                  	// #34
    94d4:	91001ff5 	add	x21, sp, #0x7
    94d8:	91002273 	add	x19, x19, #0x8
    94dc:	aa1503e1 	mov	x1, x21
    94e0:	aa1403e0 	mov	x0, x20
    94e4:	d2800022 	mov	x2, #0x1                   	// #1
    94e8:	39001fe3 	strb	w3, [sp, #7]
    94ec:	f90143f7 	str	x23, [sp, #640]
    94f0:	8b160277 	add	x23, x19, x22
    94f4:	f90147f8 	str	x24, [sp, #648]
    94f8:	97ffe846 	bl	3610 <buf_put>
    94fc:	b4000696 	cbz	x22, 95cc <fwp_write+0xc9c>
    9500:	d0000018 	adrp	x24, b000 <__divti3+0x70>
    9504:	91380318 	add	x24, x24, #0xe00
    9508:	f9014bf9 	str	x25, [sp, #656]
    950c:	d0000019 	adrp	x25, b000 <__divti3+0x70>
    9510:	91388339 	add	x25, x25, #0xe20
    9514:	f9014ffa 	str	x26, [sp, #664]
    9518:	1400000d 	b	954c <fwp_write+0xc1c>
    951c:	710024bf 	cmp	w5, #0x9
    9520:	54000460 	b.eq	95ac <fwp_write+0xc7c>  // b.none
    9524:	710028bf 	cmp	w5, #0xa
    9528:	54000a61 	b.ne	9674 <fwp_write+0xd44>  // b.any
    952c:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    9530:	aa1403e0 	mov	x0, x20
    9534:	91384021 	add	x1, x1, #0xe10
    9538:	d2800042 	mov	x2, #0x2                   	// #2
    953c:	97ffe835 	bl	3610 <buf_put>
    9540:	91000673 	add	x19, x19, #0x1
    9544:	eb17027f 	cmp	x19, x23
    9548:	540003e0 	b.eq	95c4 <fwp_write+0xc94>  // b.none
    954c:	39400265 	ldrb	w5, [x19]
    9550:	710034bf 	cmp	w5, #0xd
    9554:	54000180 	b.eq	9584 <fwp_write+0xc54>  // b.none
    9558:	54fffe29 	b.ls	951c <fwp_write+0xbec>  // b.plast
    955c:	710088bf 	cmp	w5, #0x22
    9560:	540001c0 	b.eq	9598 <fwp_write+0xc68>  // b.none
    9564:	710170bf 	cmp	w5, #0x5c
    9568:	54000741 	b.ne	9650 <fwp_write+0xd20>  // b.any
    956c:	aa1403e0 	mov	x0, x20
    9570:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    9574:	d2800042 	mov	x2, #0x2                   	// #2
    9578:	91382021 	add	x1, x1, #0xe08
    957c:	97ffe825 	bl	3610 <buf_put>
    9580:	17fffff0 	b	9540 <fwp_write+0xc10>
    9584:	aa1903e1 	mov	x1, x25
    9588:	aa1403e0 	mov	x0, x20
    958c:	d2800042 	mov	x2, #0x2                   	// #2
    9590:	97ffe820 	bl	3610 <buf_put>
    9594:	17ffffeb 	b	9540 <fwp_write+0xc10>
    9598:	aa1803e1 	mov	x1, x24
    959c:	aa1403e0 	mov	x0, x20
    95a0:	d2800042 	mov	x2, #0x2                   	// #2
    95a4:	97ffe81b 	bl	3610 <buf_put>
    95a8:	17ffffe6 	b	9540 <fwp_write+0xc10>
    95ac:	aa1403e0 	mov	x0, x20
    95b0:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    95b4:	d2800042 	mov	x2, #0x2                   	// #2
    95b8:	91386021 	add	x1, x1, #0xe18
    95bc:	97ffe815 	bl	3610 <buf_put>
    95c0:	17ffffe0 	b	9540 <fwp_write+0xc10>
    95c4:	f9414bf9 	ldr	x25, [sp, #656]
    95c8:	f9414ffa 	ldr	x26, [sp, #664]
    95cc:	aa1503e1 	mov	x1, x21
    95d0:	aa1403e0 	mov	x0, x20
    95d4:	52800443 	mov	w3, #0x22                  	// #34
    95d8:	17fffd9c 	b	8c48 <fwp_write+0x318>
    95dc:	7100103f 	cmp	w1, #0x4
    95e0:	54ffeb21 	b.ne	9344 <fwp_write+0xa14>  // b.any
    95e4:	f94006e0 	ldr	x0, [x23, #8]
    95e8:	d37ffc00 	lsr	x0, x0, #63
    95ec:	17fffeb3 	b	90b8 <fwp_write+0x788>
    95f0:	710002ff 	cmp	w23, #0x0
    95f4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    95f8:	17fffeb0 	b	90b8 <fwp_write+0x788>
    95fc:	528005a1 	mov	w1, #0x2d                  	// #45
    9600:	eb0203e2 	negs	x2, x2
    9604:	da0303e3 	ngc	x3, x3
    9608:	910127e0 	add	x0, sp, #0x49
    960c:	910123f5 	add	x21, sp, #0x48
    9610:	390123e1 	strb	w1, [sp, #72]
    9614:	97ffe5e3 	bl	2da0 <fwp_fmt_u128>
    9618:	17fffe18 	b	8e78 <fwp_write+0x548>
    961c:	d37ceea1 	lsl	x1, x21, #4
    9620:	b7f810a3 	tbnz	x3, #63, 9834 <fwp_write+0xf04>
    9624:	91002260 	add	x0, x19, #0x8
    9628:	8b010001 	add	x1, x0, x1
    962c:	17fffdf9 	b	8e10 <fwp_write+0x4e0>
    9630:	f9400a61 	ldr	x1, [x19, #16]
    9634:	8b010000 	add	x0, x0, x1
    9638:	f9400001 	ldr	x1, [x0]
    963c:	17fffdf5 	b	8e10 <fwp_write+0x4e0>
    9640:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    9644:	d2800042 	mov	x2, #0x2                   	// #2
    9648:	9136a021 	add	x1, x1, #0xda8
    964c:	17fffed6 	b	91a4 <fwp_write+0x874>
    9650:	7101fcbf 	cmp	w5, #0x7f
    9654:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9658:	540000e9 	b.ls	9674 <fwp_write+0xd44>  // b.plast
    965c:	aa1503e1 	mov	x1, x21
    9660:	aa1403e0 	mov	x0, x20
    9664:	d2800022 	mov	x2, #0x1                   	// #1
    9668:	39001fe5 	strb	w5, [sp, #7]
    966c:	97ffe7e9 	bl	3610 <buf_put>
    9670:	17ffffb4 	b	9540 <fwp_write+0xc10>
    9674:	d2800203 	mov	x3, #0x10                  	// #16
    9678:	d0000004 	adrp	x4, b000 <__divti3+0x70>
    967c:	aa0303e1 	mov	x1, x3
    9680:	9138a084 	add	x4, x4, #0xe28
    9684:	910123f6 	add	x22, sp, #0x48
    9688:	52800042 	mov	w2, #0x2                   	// #2
    968c:	aa1603e0 	mov	x0, x22
    9690:	97ffe43c 	bl	2780 <__snprintf_chk@plt>
    9694:	aa1603e0 	mov	x0, x22
    9698:	97ffe402 	bl	26a0 <strlen@plt>
    969c:	aa1603e1 	mov	x1, x22
    96a0:	aa0003e2 	mov	x2, x0
    96a4:	aa1403e0 	mov	x0, x20
    96a8:	97ffe7da 	bl	3610 <buf_put>
    96ac:	17ffffa5 	b	9540 <fwp_write+0xc10>
    96b0:	1e604100 	fmov	d0, d8
    96b4:	aa1503e0 	mov	x0, x21
    96b8:	52800221 	mov	w1, #0x11                  	// #17
    96bc:	97ffe916 	bl	3b14 <fwp_format_g.constprop.0>
    96c0:	17fffe43 	b	8fcc <fwp_write+0x69c>
    96c4:	b9401040 	ldr	w0, [x2, #16]
    96c8:	350003c0 	cbnz	w0, 9740 <fwp_write+0xe10>
    96cc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    96d0:	f947f400 	ldr	x0, [x0, #4072]
    96d4:	f94127e2 	ldr	x2, [sp, #584]
    96d8:	f9400001 	ldr	x1, [x0]
    96dc:	eb010042 	subs	x2, x2, x1
    96e0:	d2800001 	mov	x1, #0x0                   	// #0
    96e4:	54ffd721 	b.ne	91c8 <fwp_write+0x898>  // b.any
    96e8:	f9413bf5 	ldr	x21, [sp, #624]
    96ec:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    96f0:	f9413ff6 	ldr	x22, [sp, #632]
    96f4:	aa1403e0 	mov	x0, x20
    96f8:	f94143f7 	ldr	x23, [sp, #640]
    96fc:	9139e021 	add	x1, x1, #0xe78
    9700:	f94147f8 	ldr	x24, [sp, #648]
    9704:	d2800042 	mov	x2, #0x2                   	// #2
    9708:	17fffd0e 	b	8b40 <fwp_write+0x210>
    970c:	d0000001 	adrp	x1, b000 <__divti3+0x70>
    9710:	d2800042 	mov	x2, #0x2                   	// #2
    9714:	9136c021 	add	x1, x1, #0xdb0
    9718:	17fffea3 	b	91a4 <fwp_write+0x874>
    971c:	f9400a63 	ldr	x3, [x19, #16]
    9720:	8b030021 	add	x1, x1, x3
    9724:	17ffff66 	b	94bc <fwp_write+0xb8c>
    9728:	f9400a61 	ldr	x1, [x19, #16]
    972c:	8b0102a1 	add	x1, x21, x1
    9730:	17fffdb3 	b	8dfc <fwp_write+0x4cc>
    9734:	f9400a63 	ldr	x3, [x19, #16]
    9738:	8b030021 	add	x1, x1, x3
    973c:	17ffff56 	b	9494 <fwp_write+0xb64>
    9740:	b9404840 	ldr	w0, [x2, #72]
    9744:	91001ff5 	add	x21, sp, #0x7
    9748:	34ffa360 	cbz	w0, 8bb4 <fwp_write+0x284>
    974c:	52800503 	mov	w3, #0x28                  	// #40
    9750:	aa1403e0 	mov	x0, x20
    9754:	aa1503e1 	mov	x1, x21
    9758:	d2800022 	mov	x2, #0x1                   	// #1
    975c:	39001fe3 	strb	w3, [sp, #7]
    9760:	97ffe7ac 	bl	3610 <buf_put>
    9764:	b9401380 	ldr	w0, [x28, #16]
    9768:	52800038 	mov	w24, #0x1                   	// #1
    976c:	7100001f 	cmp	w0, #0x0
    9770:	54ffa36c 	b.gt	8bdc <fwp_write+0x2ac>
    9774:	17fffd32 	b	8c3c <fwp_write+0x30c>
    9778:	f9014bf9 	str	x25, [sp, #656]
    977c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10540>
    9780:	f9014ffa 	str	x26, [sp, #664]
    9784:	f9400676 	ldr	x22, [x19, #8]
    9788:	91104333 	add	x19, x25, #0x410
    978c:	91002273 	add	x19, x19, #0x8
    9790:	937ffed8 	asr	x24, x22, #63
    9794:	aa1802c0 	orr	x0, x22, x24
    9798:	b5000320 	cbnz	x0, 97fc <fwp_write+0xecc>
    979c:	110006b5 	add	w21, w21, #0x1
    97a0:	710016bf 	cmp	w21, #0x5
    97a4:	54ffffc1 	b.ne	979c <fwp_write+0xe6c>  // b.any
    97a8:	b7f80578 	tbnz	x24, #63, 9854 <fwp_write+0xf24>
    97ac:	910023f3 	add	x19, sp, #0x8
    97b0:	aa1603e2 	mov	x2, x22
    97b4:	aa1303e0 	mov	x0, x19
    97b8:	d2800003 	mov	x3, #0x0                   	// #0
    97bc:	97ffe579 	bl	2da0 <fwp_fmt_u128>
    97c0:	910123f5 	add	x21, sp, #0x48
    97c4:	d0000003 	adrp	x3, b000 <__divti3+0x70>
    97c8:	aa1303e4 	mov	x4, x19
    97cc:	aa1503e0 	mov	x0, x21
    97d0:	9139c063 	add	x3, x3, #0xe70
    97d4:	d2804002 	mov	x2, #0x200                 	// #512
    97d8:	52800041 	mov	w1, #0x2                   	// #2
    97dc:	97ffe3b5 	bl	26b0 <__sprintf_chk@plt>
    97e0:	aa1503e0 	mov	x0, x21
    97e4:	97ffe3af 	bl	26a0 <strlen@plt>
    97e8:	aa1503e1 	mov	x1, x21
    97ec:	aa0003e2 	mov	x2, x0
    97f0:	aa1403e0 	mov	x0, x20
    97f4:	97ffe787 	bl	3610 <buf_put>
    97f8:	17fffe47 	b	9114 <fwp_write+0x7e4>
    97fc:	f9400277 	ldr	x23, [x19]
    9800:	aa1603e0 	mov	x0, x22
    9804:	aa1803e1 	mov	x1, x24
    9808:	aa1703e2 	mov	x2, x23
    980c:	937ffefa 	asr	x26, x23, #63
    9810:	aa1a03e3 	mov	x3, x26
    9814:	940006bf 	bl	b310 <__modti3>
    9818:	aa010000 	orr	x0, x0, x1
    981c:	b40002c0 	cbz	x0, 9874 <fwp_write+0xf44>
    9820:	110006b5 	add	w21, w21, #0x1
    9824:	91004273 	add	x19, x19, #0x10
    9828:	710016bf 	cmp	w21, #0x5
    982c:	54fffe81 	b.ne	97fc <fwp_write+0xecc>  // b.any
    9830:	17ffffde 	b	97a8 <fwp_write+0xe78>
    9834:	f9400a60 	ldr	x0, [x19, #16]
    9838:	8b000021 	add	x1, x1, x0
    983c:	17fffd75 	b	8e10 <fwp_write+0x4e0>
    9840:	528c29c0 	mov	w0, #0x614e                	// #24910
    9844:	910123f5 	add	x21, sp, #0x48
    9848:	72a009c0 	movk	w0, #0x4e, lsl #16
    984c:	b9004be0 	str	w0, [sp, #72]
    9850:	17fffda2 	b	8ed8 <fwp_write+0x5a8>
    9854:	528005a1 	mov	w1, #0x2d                  	// #45
    9858:	eb1603e2 	negs	x2, x22
    985c:	da1803e3 	ngc	x3, x24
    9860:	910027e0 	add	x0, sp, #0x9
    9864:	910023f3 	add	x19, sp, #0x8
    9868:	390023e1 	strb	w1, [sp, #8]
    986c:	97ffe54d 	bl	2da0 <fwp_fmt_u128>
    9870:	17ffffd4 	b	97c0 <fwp_write+0xe90>
    9874:	aa1703e2 	mov	x2, x23
    9878:	aa1a03e3 	mov	x3, x26
    987c:	aa1603e0 	mov	x0, x22
    9880:	aa1803e1 	mov	x1, x24
    9884:	940005c3 	bl	af90 <__divti3>
    9888:	aa0003e2 	mov	x2, x0
    988c:	aa0103e3 	mov	x3, x1
    9890:	b7f80201 	tbnz	x1, #63, 98d0 <fwp_write+0xfa0>
    9894:	910023f3 	add	x19, sp, #0x8
    9898:	aa1303e0 	mov	x0, x19
    989c:	97ffe541 	bl	2da0 <fwp_fmt_u128>
    98a0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    98a4:	91104339 	add	x25, x25, #0x410
    98a8:	910123f5 	add	x21, sp, #0x48
    98ac:	aa1303e4 	mov	x4, x19
    98b0:	aa1503e0 	mov	x0, x21
    98b4:	d0000003 	adrp	x3, b000 <__divti3+0x70>
    98b8:	f8616b25 	ldr	x5, [x25, x1]
    98bc:	9139a063 	add	x3, x3, #0xe68
    98c0:	d2804002 	mov	x2, #0x200                 	// #512
    98c4:	52800041 	mov	w1, #0x2                   	// #2
    98c8:	97ffe37a 	bl	26b0 <__sprintf_chk@plt>
    98cc:	17ffffc5 	b	97e0 <fwp_write+0xeb0>
    98d0:	528005a4 	mov	w4, #0x2d                  	// #45
    98d4:	eb0003e2 	negs	x2, x0
    98d8:	da0103e3 	ngc	x3, x1
    98dc:	910027e0 	add	x0, sp, #0x9
    98e0:	910023f3 	add	x19, sp, #0x8
    98e4:	390023e4 	strb	w4, [sp, #8]
    98e8:	97ffe52e 	bl	2da0 <fwp_fmt_u128>
    98ec:	17ffffed 	b	98a0 <fwp_write+0xf70>
    98f0:	f9013bf5 	str	x21, [sp, #624]
    98f4:	f9013ff6 	str	x22, [sp, #632]
    98f8:	f90143f7 	str	x23, [sp, #640]
    98fc:	f90147f8 	str	x24, [sp, #648]
    9900:	f9014bf9 	str	x25, [sp, #656]
    9904:	f9014ffa 	str	x26, [sp, #664]
    9908:	f90153fb 	str	x27, [sp, #672]
    990c:	f90157fc 	str	x28, [sp, #680]
    9910:	fd015be8 	str	d8, [sp, #688]
    9914:	fd015fe9 	str	d9, [sp, #696]
    9918:	97ffe3be 	bl	2810 <__stack_chk_fail@plt>
    991c:	d503201f 	nop

0000000000009920 <fwp_main_thread>:
    9920:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9924:	90000380 	adrp	x0, 79000 <fwp_root_context+0xb80>
    9928:	91198001 	add	x1, x0, #0x660
    992c:	910003fd 	mov	x29, sp
    9930:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9934:	f947f400 	ldr	x0, [x0, #4072]
    9938:	a90153f3 	stp	x19, x20, [sp, #16]
    993c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9940:	a90363f7 	stp	x23, x24, [sp, #48]
    9944:	a9046bf9 	stp	x25, x26, [sp, #64]
    9948:	a90573fb 	stp	x27, x28, [sp, #80]
    994c:	d10603ff 	sub	sp, sp, #0x180
    9950:	b953a421 	ldr	w1, [x1, #5028]
    9954:	f9400002 	ldr	x2, [x0]
    9958:	f81f83a2 	stur	x2, [x29, #-8]
    995c:	d2800002 	mov	x2, #0x0                   	// #0
    9960:	340076a1 	cbz	w1, a834 <fwp_main_thread+0xf14>
    9964:	90000380 	adrp	x0, 79000 <fwp_root_context+0xb80>
    9968:	91198000 	add	x0, x0, #0x660
    996c:	b953a800 	ldr	w0, [x0, #5032]
    9970:	350075a0 	cbnz	w0, a824 <fwp_main_thread+0xf04>
    9974:	f00000a0 	adrp	x0, 20000 <__data_start>
    9978:	f00000a2 	adrp	x2, 20000 <__data_start>
    997c:	9101801a 	add	x26, x0, #0x60
    9980:	91120042 	add	x2, x2, #0x480
    9984:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    9988:	d2a00024 	mov	x4, #0x10000               	// #65536
    998c:	d10383b4 	sub	x20, x29, #0xe0
    9990:	d103e3b9 	sub	x25, x29, #0xf8
    9994:	aa1403e0 	mov	x0, x20
    9998:	d2800001 	mov	x1, #0x0                   	// #0
    999c:	f81203a2 	stur	x2, [x29, #-224]
    99a0:	b81283bf 	stur	wzr, [x29, #-216]
    99a4:	f81303a4 	stur	x4, [x29, #-208]
    99a8:	a90a0f59 	stp	x25, x3, [x26, #160]
    99ac:	97ffe331 	bl	2670 <sigaltstack@plt>
    99b0:	3500a8a0 	cbnz	w0, aec4 <fwp_main_thread+0x15a4>
    99b4:	4f000400 	movi	v0.4s, #0x0
    99b8:	d10263a0 	sub	x0, x29, #0x98
    99bc:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0xc>
    99c0:	9100c021 	add	x1, x1, #0x30
    99c4:	f81603a1 	stur	x1, [x29, #-160]
    99c8:	52800082 	mov	w2, #0x4                   	// #4
    99cc:	72a10002 	movk	w2, #0x800, lsl #16
    99d0:	d10283b3 	sub	x19, x29, #0xa0
    99d4:	3d802000 	str	q0, [x0, #128]
    99d8:	b81e83a2 	stur	w2, [x29, #-24]
    99dc:	ad000000 	stp	q0, q0, [x0]
    99e0:	ad010000 	stp	q0, q0, [x0, #32]
    99e4:	ad020000 	stp	q0, q0, [x0, #64]
    99e8:	ad030000 	stp	q0, q0, [x0, #96]
    99ec:	97ffe379 	bl	27d0 <sigemptyset@plt>
    99f0:	3500a6a0 	cbnz	w0, aec4 <fwp_main_thread+0x15a4>
    99f4:	aa1303e1 	mov	x1, x19
    99f8:	d2800002 	mov	x2, #0x0                   	// #0
    99fc:	52800160 	mov	w0, #0xb                   	// #11
    9a00:	97ffe38c 	bl	2830 <sigaction@plt>
    9a04:	3500a600 	cbnz	w0, aec4 <fwp_main_thread+0x15a4>
    9a08:	aa1303e1 	mov	x1, x19
    9a0c:	d2800002 	mov	x2, #0x0                   	// #0
    9a10:	528000e0 	mov	w0, #0x7                   	// #7
    9a14:	97ffe387 	bl	2830 <sigaction@plt>
    9a18:	3500a560 	cbnz	w0, aec4 <fwp_main_thread+0x15a4>
    9a1c:	90000380 	adrp	x0, 79000 <fwp_root_context+0xb80>
    9a20:	9119801b 	add	x27, x0, #0x660
    9a24:	52800037 	mov	w23, #0x1                   	// #1
    9a28:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    9a2c:	910cc000 	add	x0, x0, #0x330
    9a30:	b9015357 	str	w23, [x26, #336]
    9a34:	fd4a1360 	ldr	d0, [x27, #5152]
    9a38:	7e61d800 	ucvtf	d0, d0
    9a3c:	fd00b740 	str	d0, [x26, #360]
    9a40:	94000710 	bl	b680 <atexit>
    9a44:	3500a3a0 	cbnz	w0, aeb8 <fwp_main_thread+0x1598>
    9a48:	b943eb40 	ldr	w0, [x26, #1000]
    9a4c:	34002360 	cbz	w0, 9eb8 <fwp_main_thread+0x598>
    9a50:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a54:	91018015 	add	x21, x0, #0x60
    9a58:	f9404eb4 	ldr	x20, [x21, #152]
    9a5c:	b4000c54 	cbz	x20, 9be4 <fwp_main_thread+0x2c4>
    9a60:	aa1403f3 	mov	x19, x20
    9a64:	91010297 	add	x23, x20, #0x40
    9a68:	39414a98 	ldrb	w24, [x20, #82]
    9a6c:	52800036 	mov	w22, #0x1                   	// #1
    9a70:	39014a96 	strb	w22, [x20, #82]
    9a74:	f9401680 	ldr	x0, [x20, #40]
    9a78:	b4000620 	cbz	x0, 9b3c <fwp_main_thread+0x21c>
    9a7c:	f9403281 	ldr	x1, [x20, #96]
    9a80:	39414680 	ldrb	w0, [x20, #81]
    9a84:	b4000e81 	cbz	x1, 9c54 <fwp_main_thread+0x334>
    9a88:	36000d40 	tbz	w0, #0, 9c30 <fwp_main_thread+0x310>
    9a8c:	39414a62 	ldrb	w2, [x19, #82]
    9a90:	f9402281 	ldr	x1, [x20, #64]
    9a94:	370010c2 	tbnz	w2, #0, 9cac <fwp_main_thread+0x38c>
    9a98:	f9403260 	ldr	x0, [x19, #96]
    9a9c:	a911fe77 	stp	x23, xzr, [x19, #280]
    9aa0:	f9009661 	str	x1, [x19, #296]
    9aa4:	b4000041 	cbz	x1, 9aac <fwp_main_thread+0x18c>
    9aa8:	f9009033 	str	x19, [x1, #288]
    9aac:	f9002293 	str	x19, [x20, #64]
    9ab0:	b4000100 	cbz	x0, 9ad0 <fwp_main_thread+0x1b0>
    9ab4:	f940a6a1 	ldr	x1, [x21, #328]
    9ab8:	39015676 	strb	w22, [x19, #85]
    9abc:	f9003660 	str	x0, [x19, #104]
    9ac0:	a910867f 	stp	xzr, x1, [x19, #264]
    9ac4:	b4000041 	cbz	x1, 9acc <fwp_main_thread+0x1ac>
    9ac8:	f9008433 	str	x19, [x1, #264]
    9acc:	f900a6b3 	str	x19, [x21, #328]
    9ad0:	39015a7f 	strb	wzr, [x19, #86]
    9ad4:	97fff390 	bl	6914 <fwp_block>
    9ad8:	f9408e62 	ldr	x2, [x19, #280]
    9adc:	b4000142 	cbz	x2, 9b04 <fwp_main_thread+0x1e4>
    9ae0:	a9520261 	ldp	x1, x0, [x19, #288]
    9ae4:	b4000e01 	cbz	x1, 9ca4 <fwp_main_thread+0x384>
    9ae8:	f9009420 	str	x0, [x1, #296]
    9aec:	f9409660 	ldr	x0, [x19, #296]
    9af0:	b4000040 	cbz	x0, 9af8 <fwp_main_thread+0x1d8>
    9af4:	f9009001 	str	x1, [x0, #288]
    9af8:	91080260 	add	x0, x19, #0x200
    9afc:	f900967f 	str	xzr, [x19, #296]
    9b00:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9b04:	39415660 	ldrb	w0, [x19, #85]
    9b08:	f9404ea1 	ldr	x1, [x21, #152]
    9b0c:	36000c80 	tbz	w0, #0, 9c9c <fwp_main_thread+0x37c>
    9b10:	a9508262 	ldp	x2, x0, [x19, #264]
    9b14:	b4000d82 	cbz	x2, 9cc4 <fwp_main_thread+0x3a4>
    9b18:	f9008840 	str	x0, [x2, #272]
    9b1c:	b4000040 	cbz	x0, 9b24 <fwp_main_thread+0x204>
    9b20:	f9008402 	str	x2, [x0, #264]
    9b24:	91080260 	add	x0, x19, #0x200
    9b28:	3901567f 	strb	wzr, [x19, #85]
    9b2c:	aa0103f3 	mov	x19, x1
    9b30:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9b34:	f9401680 	ldr	x0, [x20, #40]
    9b38:	b5fffa20 	cbnz	x0, 9a7c <fwp_main_thread+0x15c>
    9b3c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b40:	91018000 	add	x0, x0, #0x60
    9b44:	39014a98 	strb	w24, [x20, #82]
    9b48:	f941e400 	ldr	x0, [x0, #968]
    9b4c:	b4000520 	cbz	x0, 9bf0 <fwp_main_thread+0x2d0>
    9b50:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b54:	91018000 	add	x0, x0, #0x60
    9b58:	f9420001 	ldr	x1, [x0, #1024]
    9b5c:	b903f81f 	str	wzr, [x0, #1016]
    9b60:	eb13003f 	cmp	x1, x19
    9b64:	54000641 	b.ne	9c2c <fwp_main_thread+0x30c>  // b.any
    9b68:	b4000bd3 	cbz	x19, 9ce0 <fwp_main_thread+0x3c0>
    9b6c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b70:	91018000 	add	x0, x0, #0x60
    9b74:	52800021 	mov	w1, #0x1                   	// #1
    9b78:	39014a61 	strb	w1, [x19, #82]
    9b7c:	f941d005 	ldr	x5, [x0, #928]
    9b80:	b4000b05 	cbz	x5, 9ce0 <fwp_main_thread+0x3c0>
    9b84:	394140a0 	ldrb	w0, [x5, #80]
    9b88:	37000060 	tbnz	w0, #0, 9b94 <fwp_main_thread+0x274>
    9b8c:	aa0503e0 	mov	x0, x5
    9b90:	97ffe6b8 	bl	3670 <fwp_cancel_tree.part.0>
    9b94:	f9409ca5 	ldr	x5, [x5, #312]
    9b98:	b5ffff65 	cbnz	x5, 9b84 <fwp_main_thread+0x264>
    9b9c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ba0:	91018014 	add	x20, x0, #0x60
    9ba4:	52800035 	mov	w21, #0x1                   	// #1
    9ba8:	f9402a60 	ldr	x0, [x19, #80]
    9bac:	f2001c1f 	tst	x0, #0xff000000ff
    9bb0:	540000e1 	b.ne	9bcc <fwp_main_thread+0x2ac>  // b.any
    9bb4:	f9406280 	ldr	x0, [x20, #192]
    9bb8:	39015275 	strb	w21, [x19, #84]
    9bbc:	f900827f 	str	xzr, [x19, #256]
    9bc0:	b4000860 	cbz	x0, 9ccc <fwp_main_thread+0x3ac>
    9bc4:	f9008013 	str	x19, [x0, #256]
    9bc8:	f9006293 	str	x19, [x20, #192]
    9bcc:	97fff352 	bl	6914 <fwp_block>
    9bd0:	97fff2e4 	bl	6760 <fwp_free_zombie>
    9bd4:	f941d280 	ldr	x0, [x20, #928]
    9bd8:	b4000840 	cbz	x0, 9ce0 <fwp_main_thread+0x3c0>
    9bdc:	f9420293 	ldr	x19, [x20, #1024]
    9be0:	17fffff2 	b	9ba8 <fwp_main_thread+0x288>
    9be4:	f941e6a0 	ldr	x0, [x21, #968]
    9be8:	b5000760 	cbnz	x0, 9cd4 <fwp_main_thread+0x3b4>
    9bec:	d2800013 	mov	x19, #0x0                   	// #0
    9bf0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9bf4:	91018014 	add	x20, x0, #0x60
    9bf8:	f941ee80 	ldr	x0, [x20, #984]
    9bfc:	b5fffaa0 	cbnz	x0, 9b50 <fwp_main_thread+0x230>
    9c00:	f941e280 	ldr	x0, [x20, #960]
    9c04:	97ffec17 	bl	4c60 <fwp_mem_free>
    9c08:	f901e29f 	str	xzr, [x20, #960]
    9c0c:	f901ea9f 	str	xzr, [x20, #976]
    9c10:	f9420280 	ldr	x0, [x20, #1024]
    9c14:	b4009a93 	cbz	x19, af64 <fwp_main_thread+0x1644>
    9c18:	f900567f 	str	xzr, [x19, #168]
    9c1c:	f9005e7f 	str	xzr, [x19, #184]
    9c20:	b903fa9f 	str	wzr, [x20, #1016]
    9c24:	eb00027f 	cmp	x19, x0
    9c28:	54fffa20 	b.eq	9b6c <fwp_main_thread+0x24c>  // b.none
    9c2c:	97ffe30d 	bl	2860 <abort@plt>
    9c30:	97ffe734 	bl	3900 <fwp_now_ns>
    9c34:	f9403281 	ldr	x1, [x20, #96]
    9c38:	eb01001f 	cmp	x0, x1
    9c3c:	540000ab 	b.lt	9c50 <fwp_main_thread+0x330>  // b.tstop
    9c40:	39414280 	ldrb	w0, [x20, #80]
    9c44:	37000060 	tbnz	w0, #0, 9c50 <fwp_main_thread+0x330>
    9c48:	aa1403e0 	mov	x0, x20
    9c4c:	97ffe689 	bl	3670 <fwp_cancel_tree.part.0>
    9c50:	39414680 	ldrb	w0, [x20, #81]
    9c54:	39414a62 	ldrb	w2, [x19, #82]
    9c58:	3707f1c0 	tbnz	w0, #0, 9a90 <fwp_main_thread+0x170>
    9c5c:	f9403280 	ldr	x0, [x20, #96]
    9c60:	370001a2 	tbnz	w2, #0, 9c94 <fwp_main_thread+0x374>
    9c64:	f9403261 	ldr	x1, [x19, #96]
    9c68:	b4000161 	cbz	x1, 9c94 <fwp_main_thread+0x374>
    9c6c:	b4008f40 	cbz	x0, ae54 <fwp_main_thread+0x1534>
    9c70:	eb01001f 	cmp	x0, x1
    9c74:	9a81d000 	csel	x0, x0, x1, le
    9c78:	f9402281 	ldr	x1, [x20, #64]
    9c7c:	a911fe77 	stp	x23, xzr, [x19, #280]
    9c80:	f9009661 	str	x1, [x19, #296]
    9c84:	b4000041 	cbz	x1, 9c8c <fwp_main_thread+0x36c>
    9c88:	f9009033 	str	x19, [x1, #288]
    9c8c:	f9002293 	str	x19, [x20, #64]
    9c90:	17ffff89 	b	9ab4 <fwp_main_thread+0x194>
    9c94:	f9402281 	ldr	x1, [x20, #64]
    9c98:	17ffff81 	b	9a9c <fwp_main_thread+0x17c>
    9c9c:	aa0103f3 	mov	x19, x1
    9ca0:	17ffff75 	b	9a74 <fwp_main_thread+0x154>
    9ca4:	f9000040 	str	x0, [x2]
    9ca8:	17ffff92 	b	9af0 <fwp_main_thread+0x1d0>
    9cac:	a911fe77 	stp	x23, xzr, [x19, #280]
    9cb0:	f9009661 	str	x1, [x19, #296]
    9cb4:	b4000041 	cbz	x1, 9cbc <fwp_main_thread+0x39c>
    9cb8:	f9009033 	str	x19, [x1, #288]
    9cbc:	f9002293 	str	x19, [x20, #64]
    9cc0:	17ffff84 	b	9ad0 <fwp_main_thread+0x1b0>
    9cc4:	f900a6a0 	str	x0, [x21, #328]
    9cc8:	17ffff95 	b	9b1c <fwp_main_thread+0x1fc>
    9ccc:	f9006693 	str	x19, [x20, #200]
    9cd0:	17ffffbe 	b	9bc8 <fwp_main_thread+0x2a8>
    9cd4:	f94202a0 	ldr	x0, [x21, #1024]
    9cd8:	b903fabf 	str	wzr, [x21, #1016]
    9cdc:	b5fffa80 	cbnz	x0, 9c2c <fwp_main_thread+0x30c>
    9ce0:	97fff2a0 	bl	6760 <fwp_free_zombie>
    9ce4:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ce8:	91018015 	add	x21, x0, #0x60
    9cec:	f94066a0 	ldr	x0, [x21, #200]
    9cf0:	b5fff9e0 	cbnz	x0, 9c2c <fwp_main_thread+0x30c>
    9cf4:	f940a6a0 	ldr	x0, [x21, #328]
    9cf8:	b5fff9a0 	cbnz	x0, 9c2c <fwp_main_thread+0x30c>
    9cfc:	b94192a0 	ldr	w0, [x21, #400]
    9d00:	340001c0 	cbz	w0, 9d38 <fwp_main_thread+0x418>
    9d04:	93407c14 	sxtw	x20, w0
    9d08:	51000400 	sub	w0, w0, #0x1
    9d0c:	d1000a94 	sub	x20, x20, #0x2
    9d10:	910682b6 	add	x22, x21, #0x1a0
    9d14:	cb204294 	sub	x20, x20, w0, uxtw
    9d18:	93407c13 	sxtw	x19, w0
    9d1c:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    9d20:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9d24:	b90192b3 	str	w19, [x21, #400]
    9d28:	d1000673 	sub	x19, x19, #0x1
    9d2c:	97ffe301 	bl	2930 <munmap@plt>
    9d30:	eb14027f 	cmp	x19, x20
    9d34:	54ffff41 	b.ne	9d1c <fwp_main_thread+0x3fc>  // b.any
    9d38:	f00000a4 	adrp	x4, 20000 <__data_start>
    9d3c:	91004080 	add	x0, x4, #0x10
    9d40:	b9403000 	ldr	w0, [x0, #48]
    9d44:	37f800c0 	tbnz	w0, #31, 9d5c <fwp_main_thread+0x43c>
    9d48:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9d4c:	f91f7c24 	str	x4, [x1, #16120]
    9d50:	97ffe2b4 	bl	2820 <close@plt>
    9d54:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d58:	f95f7c04 	ldr	x4, [x0, #16120]
    9d5c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d60:	91018000 	add	x0, x0, #0x60
    9d64:	91004084 	add	x4, x4, #0x10
    9d68:	12800001 	mov	w1, #0xffffffff            	// #-1
    9d6c:	d2800013 	mov	x19, #0x0                   	// #0
    9d70:	f9420415 	ldr	x21, [x0, #1032]
    9d74:	b9003081 	str	w1, [x4, #48]
    9d78:	f9420814 	ldr	x20, [x0, #1040]
    9d7c:	b4000175 	cbz	x21, 9da8 <fwp_main_thread+0x488>
    9d80:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    9d84:	b40000c0 	cbz	x0, 9d9c <fwp_main_thread+0x47c>
    9d88:	f9400001 	ldr	x1, [x0]
    9d8c:	b5fff501 	cbnz	x1, 9c2c <fwp_main_thread+0x30c>
    9d90:	f9400401 	ldr	x1, [x0, #8]
    9d94:	b5fff4c1 	cbnz	x1, 9c2c <fwp_main_thread+0x30c>
    9d98:	97ffebb2 	bl	4c60 <fwp_mem_free>
    9d9c:	91000673 	add	x19, x19, #0x1
    9da0:	eb1302bf 	cmp	x21, x19
    9da4:	54fffee1 	b.ne	9d80 <fwp_main_thread+0x460>  // b.any
    9da8:	aa1403e0 	mov	x0, x20
    9dac:	97ffebad 	bl	4c60 <fwp_mem_free>
    9db0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9db4:	91018000 	add	x0, x0, #0x60
    9db8:	f9420013 	ldr	x19, [x0, #1024]
    9dbc:	f902041f 	str	xzr, [x0, #1032]
    9dc0:	f902081f 	str	xzr, [x0, #1040]
    9dc4:	b40001f3 	cbz	x19, 9e00 <fwp_main_thread+0x4e0>
    9dc8:	f9401661 	ldr	x1, [x19, #40]
    9dcc:	b5fff301 	cbnz	x1, 9c2c <fwp_main_thread+0x30c>
    9dd0:	f9405661 	ldr	x1, [x19, #168]
    9dd4:	b5fff2c1 	cbnz	x1, 9c2c <fwp_main_thread+0x30c>
    9dd8:	f941e401 	ldr	x1, [x0, #968]
    9ddc:	b5fff281 	cbnz	x1, 9c2c <fwp_main_thread+0x30c>
    9de0:	f941ec00 	ldr	x0, [x0, #984]
    9de4:	b5fff240 	cbnz	x0, 9c2c <fwp_main_thread+0x30c>
    9de8:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9dec:	f0000360 	adrp	x0, 78000 <ad_raw_blocks+0x17b80>
    9df0:	91120000 	add	x0, x0, #0x480
    9df4:	97ffe27b 	bl	27e0 <memset@plt>
    9df8:	aa1303e0 	mov	x0, x19
    9dfc:	97ffeb99 	bl	4c60 <fwp_mem_free>
    9e00:	f00000a1 	adrp	x1, 20000 <__data_start>
    9e04:	90000380 	adrp	x0, 79000 <fwp_root_context+0xb80>
    9e08:	91018026 	add	x6, x1, #0x60
    9e0c:	91198000 	add	x0, x0, #0x660
    9e10:	3dc01821 	ldr	q1, [x1, #96]
    9e14:	d0000002 	adrp	x2, b000 <__divti3+0x70>
    9e18:	3dc004c2 	ldr	q2, [x6, #16]
    9e1c:	913ba042 	add	x2, x2, #0xee8
    9e20:	fd4a1000 	ldr	d0, [x0, #5152]
    9e24:	52800041 	mov	w1, #0x2                   	// #2
    9e28:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    9e2c:	fd40b4c1 	ldr	d1, [x6, #360]
    9e30:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9e34:	f947e800 	ldr	x0, [x0, #4048]
    9e38:	7e61d800 	ucvtf	d0, d0
    9e3c:	a95590c3 	ldp	x3, x4, [x6, #344]
    9e40:	f9004cdf 	str	xzr, [x6, #152]
    9e44:	f9400000 	ldr	x0, [x0]
    9e48:	1e613801 	fsub	d1, d0, d1
    9e4c:	f940bcc5 	ldr	x5, [x6, #376]
    9e50:	b90150df 	str	wzr, [x6, #336]
    9e54:	5ef1b842 	addp	d2, v2.2d
    9e58:	fd40b8c0 	ldr	d0, [x6, #368]
    9e5c:	f90200df 	str	xzr, [x6, #1024]
    9e60:	fd0058c2 	str	d2, [x6, #176]
    9e64:	97ffe287 	bl	2880 <__fprintf_chk@plt>
    9e68:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9e6c:	f947ec00 	ldr	x0, [x0, #4056]
    9e70:	f9400000 	ldr	x0, [x0]
    9e74:	97ffe2b3 	bl	2940 <fflush@plt>
    9e78:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9e7c:	f947f400 	ldr	x0, [x0, #4072]
    9e80:	f85f83a2 	ldur	x2, [x29, #-8]
    9e84:	f9400001 	ldr	x1, [x0]
    9e88:	eb010042 	subs	x2, x2, x1
    9e8c:	d2800001 	mov	x1, #0x0                   	// #0
    9e90:	54008281 	b.ne	aee0 <fwp_main_thread+0x15c0>  // b.any
    9e94:	910003bf 	mov	sp, x29
    9e98:	d2800000 	mov	x0, #0x0                   	// #0
    9e9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    9ea0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9ea4:	a94363f7 	ldp	x23, x24, [sp, #48]
    9ea8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9eac:	a94573fb 	ldp	x27, x28, [sp, #80]
    9eb0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9eb4:	d65f03c0 	ret
    9eb8:	f941db42 	ldr	x2, [x26, #944]
    9ebc:	b0ffffe0 	adrp	x0, 6000 <fwp_drop0+0x130>
    9ec0:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9ec4:	91010000 	add	x0, x0, #0x40
    9ec8:	913b4021 	add	x1, x1, #0xed0
    9ecc:	d2800015 	mov	x21, #0x0                   	// #0
    9ed0:	d2800418 	mov	x24, #0x20                  	// #32
    9ed4:	d2800016 	mov	x22, #0x0                   	// #0
    9ed8:	a93087a2 	stp	x2, x1, [x29, #-248]
    9edc:	a931ffb4 	stp	x20, xzr, [x29, #-232]
    9ee0:	a93303bf 	stp	xzr, x0, [x29, #-208]
    9ee4:	f901db59 	str	x25, [x26, #944]
    9ee8:	f100071a 	subs	x26, x24, #0x1
    9eec:	aa1303e1 	mov	x1, x19
    9ef0:	da1f02dc 	sbc	x28, x22, xzr
    9ef4:	52800020 	mov	w0, #0x1                   	// #1
    9ef8:	f81283ba 	stur	x26, [x29, #-216]
    9efc:	aa1a03f8 	mov	x24, x26
    9f00:	a93657ba 	stp	x26, x21, [x29, #-160]
    9f04:	97ffee93 	bl	5950 <fwp_data.part.0.constprop.0>
    9f08:	aa0003f5 	mov	x21, x0
    9f0c:	f949db62 	ldr	x2, [x27, #5040]
    9f10:	aa1c03f6 	mov	x22, x28
    9f14:	f949ef60 	ldr	x0, [x27, #5080]
    9f18:	cb0202a2 	sub	x2, x21, x2
    9f1c:	eb00405f 	cmp	x2, x0, lsl #16
    9f20:	54000302 	b.cs	9f80 <fwp_main_thread+0x660>  // b.hs, b.nlast
    9f24:	d350fc40 	lsr	x0, x2, #16
    9f28:	f949ff63 	ldr	x3, [x27, #5112]
    9f2c:	8b000800 	add	x0, x0, x0, lsl #2
    9f30:	d37df001 	lsl	x1, x0, #3
    9f34:	8b010060 	add	x0, x3, x1
    9f38:	f9401019 	ldr	x25, [x0, #32]
    9f3c:	b4000239 	cbz	x25, 9f80 <fwp_main_thread+0x660>
    9f40:	38616861 	ldrb	w1, [x3, x1]
    9f44:	7100083f 	cmp	w1, #0x2
    9f48:	540045e0 	b.eq	a804 <fwp_main_thread+0xee4>  // b.none
    9f4c:	7100043f 	cmp	w1, #0x1
    9f50:	54000181 	b.ne	9f80 <fwp_main_thread+0x660>  // b.any
    9f54:	29430003 	ldp	w3, w0, [x0, #24]
    9f58:	92403c41 	and	x1, x2, #0xffff
    9f5c:	9b037c21 	mul	x1, x1, x3
    9f60:	d360fc21 	lsr	x1, x1, #32
    9f64:	eb00003f 	cmp	x1, x0
    9f68:	540000c2 	b.cs	9f80 <fwp_main_thread+0x660>  // b.hs, b.nlast
    9f6c:	8b010339 	add	x25, x25, x1
    9f70:	39400320 	ldrb	w0, [x25]
    9f74:	7103fc1f 	cmp	w0, #0xff
    9f78:	54004500 	b.eq	a818 <fwp_main_thread+0xef8>  // b.none
    9f7c:	39000337 	strb	w23, [x25]
    9f80:	f81203b5 	stur	x21, [x29, #-224]
    9f84:	aa1c0340 	orr	x0, x26, x28
    9f88:	b5fffb00 	cbnz	x0, 9ee8 <fwp_main_thread+0x5c8>
    9f8c:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0x950>
    9f90:	d10303a1 	sub	x1, x29, #0xc0
    9f94:	f85083a3 	ldur	x3, [x29, #-248]
    9f98:	3dc19c00 	ldr	q0, [x0, #1648]
    9f9c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9fa0:	91018002 	add	x2, x0, #0x60
    9fa4:	52800020 	mov	w0, #0x1                   	// #1
    9fa8:	3c9403a0 	stur	q0, [x29, #-192]
    9fac:	f901d843 	str	x3, [x2, #944]
    9fb0:	97ffee68 	bl	5950 <fwp_data.part.0.constprop.0>
    9fb4:	90000381 	adrp	x1, 79000 <fwp_root_context+0xb80>
    9fb8:	91198022 	add	x2, x1, #0x660
    9fbc:	aa0003f7 	mov	x23, x0
    9fc0:	f949d841 	ldr	x1, [x2, #5040]
    9fc4:	f949ec40 	ldr	x0, [x2, #5080]
    9fc8:	cb0102e1 	sub	x1, x23, x1
    9fcc:	eb00403f 	cmp	x1, x0, lsl #16
    9fd0:	54000322 	b.cs	a034 <fwp_main_thread+0x714>  // b.hs, b.nlast
    9fd4:	d350fc20 	lsr	x0, x1, #16
    9fd8:	f949fc43 	ldr	x3, [x2, #5112]
    9fdc:	8b000800 	add	x0, x0, x0, lsl #2
    9fe0:	d37df002 	lsl	x2, x0, #3
    9fe4:	8b020060 	add	x0, x3, x2
    9fe8:	f9401016 	ldr	x22, [x0, #32]
    9fec:	b4000256 	cbz	x22, a034 <fwp_main_thread+0x714>
    9ff0:	38626862 	ldrb	w2, [x3, x2]
    9ff4:	7100085f 	cmp	w2, #0x2
    9ff8:	540071c0 	b.eq	ae30 <fwp_main_thread+0x1510>  // b.none
    9ffc:	7100045f 	cmp	w2, #0x1
    a000:	540001a1 	b.ne	a034 <fwp_main_thread+0x714>  // b.any
    a004:	29430002 	ldp	w2, w0, [x0, #24]
    a008:	92403c21 	and	x1, x1, #0xffff
    a00c:	9b027c21 	mul	x1, x1, x2
    a010:	d360fc21 	lsr	x1, x1, #32
    a014:	eb00003f 	cmp	x1, x0
    a018:	540000e2 	b.cs	a034 <fwp_main_thread+0x714>  // b.hs, b.nlast
    a01c:	8b0102d6 	add	x22, x22, x1
    a020:	394002c0 	ldrb	w0, [x22]
    a024:	7103fc1f 	cmp	w0, #0xff
    a028:	54007320 	b.eq	ae8c <fwp_main_thread+0x156c>  // b.none
    a02c:	52800020 	mov	w0, #0x1                   	// #1
    a030:	390002c0 	strb	w0, [x22]
    a034:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a038:	aa1303e1 	mov	x1, x19
    a03c:	52800020 	mov	w0, #0x1                   	// #1
    a040:	a9365fa2 	stp	x2, x23, [x29, #-160]
    a044:	97ffee43 	bl	5950 <fwp_data.part.0.constprop.0>
    a048:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xb80>
    a04c:	91198022 	add	x2, x1, #0x660
    a050:	aa0003f6 	mov	x22, x0
    a054:	f949d841 	ldr	x1, [x2, #5040]
    a058:	f949ec40 	ldr	x0, [x2, #5080]
    a05c:	cb0102c1 	sub	x1, x22, x1
    a060:	eb00403f 	cmp	x1, x0, lsl #16
    a064:	54000322 	b.cs	a0c8 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    a068:	d350fc20 	lsr	x0, x1, #16
    a06c:	f949fc43 	ldr	x3, [x2, #5112]
    a070:	8b000800 	add	x0, x0, x0, lsl #2
    a074:	d37df002 	lsl	x2, x0, #3
    a078:	8b020060 	add	x0, x3, x2
    a07c:	f9401013 	ldr	x19, [x0, #32]
    a080:	b4000253 	cbz	x19, a0c8 <fwp_main_thread+0x7a8>
    a084:	38626862 	ldrb	w2, [x3, x2]
    a088:	7100085f 	cmp	w2, #0x2
    a08c:	54006cc0 	b.eq	ae24 <fwp_main_thread+0x1504>  // b.none
    a090:	7100045f 	cmp	w2, #0x1
    a094:	540001a1 	b.ne	a0c8 <fwp_main_thread+0x7a8>  // b.any
    a098:	29430002 	ldp	w2, w0, [x0, #24]
    a09c:	92403c21 	and	x1, x1, #0xffff
    a0a0:	9b027c21 	mul	x1, x1, x2
    a0a4:	d360fc21 	lsr	x1, x1, #32
    a0a8:	eb00003f 	cmp	x1, x0
    a0ac:	540000e2 	b.cs	a0c8 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    a0b0:	8b010273 	add	x19, x19, x1
    a0b4:	39400260 	ldrb	w0, [x19]
    a0b8:	7103fc1f 	cmp	w0, #0xff
    a0bc:	54006f20 	b.eq	aea0 <fwp_main_thread+0x1580>  // b.none
    a0c0:	52800020 	mov	w0, #0x1                   	// #1
    a0c4:	39000260 	strb	w0, [x19]
    a0c8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a0cc:	d102c3a1 	sub	x1, x29, #0xb0
    a0d0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a0d4:	52800020 	mov	w0, #0x1                   	// #1
    a0d8:	a9355ba2 	stp	x2, x22, [x29, #-176]
    a0dc:	97ffee1d 	bl	5950 <fwp_data.part.0.constprop.0>
    a0e0:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xb80>
    a0e4:	91198022 	add	x2, x1, #0x660
    a0e8:	aa0003f8 	mov	x24, x0
    a0ec:	f949d841 	ldr	x1, [x2, #5040]
    a0f0:	f949ec40 	ldr	x0, [x2, #5080]
    a0f4:	cb010301 	sub	x1, x24, x1
    a0f8:	eb00403f 	cmp	x1, x0, lsl #16
    a0fc:	54000322 	b.cs	a160 <fwp_main_thread+0x840>  // b.hs, b.nlast
    a100:	d350fc20 	lsr	x0, x1, #16
    a104:	f949fc43 	ldr	x3, [x2, #5112]
    a108:	8b000800 	add	x0, x0, x0, lsl #2
    a10c:	d37df002 	lsl	x2, x0, #3
    a110:	8b020060 	add	x0, x3, x2
    a114:	f9401013 	ldr	x19, [x0, #32]
    a118:	b4000253 	cbz	x19, a160 <fwp_main_thread+0x840>
    a11c:	38626862 	ldrb	w2, [x3, x2]
    a120:	7100085f 	cmp	w2, #0x2
    a124:	540068c0 	b.eq	ae3c <fwp_main_thread+0x151c>  // b.none
    a128:	7100045f 	cmp	w2, #0x1
    a12c:	540001a1 	b.ne	a160 <fwp_main_thread+0x840>  // b.any
    a130:	29430002 	ldp	w2, w0, [x0, #24]
    a134:	92403c21 	and	x1, x1, #0xffff
    a138:	9b027c21 	mul	x1, x1, x2
    a13c:	d360fc21 	lsr	x1, x1, #32
    a140:	eb00003f 	cmp	x1, x0
    a144:	540000e2 	b.cs	a160 <fwp_main_thread+0x840>  // b.hs, b.nlast
    a148:	8b010273 	add	x19, x19, x1
    a14c:	39400260 	ldrb	w0, [x19]
    a150:	7103fc1f 	cmp	w0, #0xff
    a154:	54006ac0 	b.eq	aeac <fwp_main_thread+0x158c>  // b.none
    a158:	52800020 	mov	w0, #0x1                   	// #1
    a15c:	39000260 	strb	w0, [x19]
    a160:	b40033f5 	cbz	x21, a7dc <fwp_main_thread+0xebc>
    a164:	d00000a0 	adrp	x0, 20000 <__data_start>
    a168:	d00000a4 	adrp	x4, 20000 <__data_start>
    a16c:	9101801c 	add	x28, x0, #0x60
    a170:	9100409b 	add	x27, x4, #0x10
    a174:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a178:	9100a37b 	add	x27, x27, #0x28
    a17c:	aa1b03f6 	mov	x22, x27
    a180:	aa1503f7 	mov	x23, x21
    a184:	aa1c03fb 	mov	x27, x28
    a188:	aa0403f3 	mov	x19, x4
    a18c:	f91f5415 	str	x21, [x0, #16040]
    a190:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    a194:	91198002 	add	x2, x0, #0x660
    a198:	f949d841 	ldr	x1, [x2, #5040]
    a19c:	f949ec40 	ldr	x0, [x2, #5080]
    a1a0:	cb010301 	sub	x1, x24, x1
    a1a4:	eb00403f 	cmp	x1, x0, lsl #16
    a1a8:	54000422 	b.cs	a22c <fwp_main_thread+0x90c>  // b.hs, b.nlast
    a1ac:	d350fc20 	lsr	x0, x1, #16
    a1b0:	f949fc44 	ldr	x4, [x2, #5112]
    a1b4:	8b000800 	add	x0, x0, x0, lsl #2
    a1b8:	d37df002 	lsl	x2, x0, #3
    a1bc:	8b020083 	add	x3, x4, x2
    a1c0:	f9401060 	ldr	x0, [x3, #32]
    a1c4:	b4000340 	cbz	x0, a22c <fwp_main_thread+0x90c>
    a1c8:	38626882 	ldrb	w2, [x4, x2]
    a1cc:	7100085f 	cmp	w2, #0x2
    a1d0:	540063c0 	b.eq	ae48 <fwp_main_thread+0x1528>  // b.none
    a1d4:	7100045f 	cmp	w2, #0x1
    a1d8:	540002a1 	b.ne	a22c <fwp_main_thread+0x90c>  // b.any
    a1dc:	29430864 	ldp	w4, w2, [x3, #24]
    a1e0:	92403c21 	and	x1, x1, #0xffff
    a1e4:	9b047c21 	mul	x1, x1, x4
    a1e8:	d360fc21 	lsr	x1, x1, #32
    a1ec:	eb02003f 	cmp	x1, x2
    a1f0:	540001e2 	b.cs	a22c <fwp_main_thread+0x90c>  // b.hs, b.nlast
    a1f4:	8b010000 	add	x0, x0, x1
    a1f8:	39400001 	ldrb	w1, [x0]
    a1fc:	34000181 	cbz	w1, a22c <fwp_main_thread+0x90c>
    a200:	d00000a2 	adrp	x2, 20000 <__data_start>
    a204:	91018042 	add	x2, x2, #0x60
    a208:	b9415043 	ldr	w3, [x2, #336]
    a20c:	34000083 	cbz	w3, a21c <fwp_main_thread+0x8fc>
    a210:	f940bc43 	ldr	x3, [x2, #376]
    a214:	91000463 	add	x3, x3, #0x1
    a218:	f900bc43 	str	x3, [x2, #376]
    a21c:	7103f43f 	cmp	w1, #0xfd
    a220:	540063c8 	b.hi	ae98 <fwp_main_thread+0x1578>  // b.pmore
    a224:	11000421 	add	w1, w1, #0x1
    a228:	39000001 	strb	w1, [x0]
    a22c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a230:	aa1603e6 	mov	x6, x22
    a234:	aa1303f9 	mov	x25, x19
    a238:	d28018fc 	mov	x28, #0xc7                  	// #199
    a23c:	f91f4c17 	str	x23, [x0, #16024]
    a240:	aa1803f7 	mov	x23, x24
    a244:	f91f5018 	str	x24, [x0, #16032]
    a248:	f91f581c 	str	x28, [x0, #16048]
    a24c:	91004320 	add	x0, x25, #0x10
    a250:	f9406b63 	ldr	x3, [x27, #208]
    a254:	9100a005 	add	x5, x0, #0x28
    a258:	b9402802 	ldr	w2, [x0, #40]
    a25c:	d37be842 	lsl	x2, x2, #5
    a260:	8b020064 	add	x4, x3, x2
    a264:	f9400c81 	ldr	x1, [x4, #24]
    a268:	f81203b7 	stur	x23, [x29, #-224]
    a26c:	b4005f81 	cbz	x1, ae5c <fwp_main_thread+0x153c>
    a270:	f9400c20 	ldr	x0, [x1, #24]
    a274:	b4004ea0 	cbz	x0, ac48 <fwp_main_thread+0x1328>
    a278:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    a27c:	91198002 	add	x2, x0, #0x660
    a280:	f949d841 	ldr	x1, [x2, #5040]
    a284:	f949ec40 	ldr	x0, [x2, #5080]
    a288:	cb0100c1 	sub	x1, x6, x1
    a28c:	eb00403f 	cmp	x1, x0, lsl #16
    a290:	540003e2 	b.cs	a30c <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    a294:	d350fc20 	lsr	x0, x1, #16
    a298:	f949fc45 	ldr	x5, [x2, #5112]
    a29c:	8b000800 	add	x0, x0, x0, lsl #2
    a2a0:	d37df002 	lsl	x2, x0, #3
    a2a4:	8b0200a3 	add	x3, x5, x2
    a2a8:	f9401060 	ldr	x0, [x3, #32]
    a2ac:	b4000300 	cbz	x0, a30c <fwp_main_thread+0x9ec>
    a2b0:	386268a2 	ldrb	w2, [x5, x2]
    a2b4:	7100085f 	cmp	w2, #0x2
    a2b8:	540053c0 	b.eq	ad30 <fwp_main_thread+0x1410>  // b.none
    a2bc:	7100045f 	cmp	w2, #0x1
    a2c0:	54000261 	b.ne	a30c <fwp_main_thread+0x9ec>  // b.any
    a2c4:	29430865 	ldp	w5, w2, [x3, #24]
    a2c8:	92403c21 	and	x1, x1, #0xffff
    a2cc:	9b057c21 	mul	x1, x1, x5
    a2d0:	d360fc21 	lsr	x1, x1, #32
    a2d4:	eb02003f 	cmp	x1, x2
    a2d8:	540001a2 	b.cs	a30c <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    a2dc:	8b010000 	add	x0, x0, x1
    a2e0:	39400001 	ldrb	w1, [x0]
    a2e4:	34000141 	cbz	w1, a30c <fwp_main_thread+0x9ec>
    a2e8:	b9415362 	ldr	w2, [x27, #336]
    a2ec:	34000082 	cbz	w2, a2fc <fwp_main_thread+0x9dc>
    a2f0:	f940bf62 	ldr	x2, [x27, #376]
    a2f4:	91000442 	add	x2, x2, #0x1
    a2f8:	f900bf62 	str	x2, [x27, #376]
    a2fc:	7103f43f 	cmp	w1, #0xfd
    a300:	540056e8 	b.hi	addc <fwp_main_thread+0x14bc>  // b.pmore
    a304:	11000421 	add	w1, w1, #0x1
    a308:	39000001 	strb	w1, [x0]
    a30c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a310:	52800020 	mov	w0, #0x1                   	// #1
    a314:	2a0003f8 	mov	w24, w0
    a318:	aa0603f7 	mov	x23, x6
    a31c:	aa1903fc 	mov	x28, x25
    a320:	b93ee820 	str	w0, [x1, #16104]
    a324:	aa0103e0 	mov	x0, x1
    a328:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xb80>
    a32c:	91198035 	add	x21, x1, #0x660
    a330:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a334:	f91f7814 	str	x20, [x0, #16112]
    a338:	aa0603e0 	mov	x0, x6
    a33c:	f91f5c34 	str	x20, [x1, #16056]
    a340:	f91f6026 	str	x6, [x1, #16064]
    a344:	b93eec38 	str	w24, [x1, #16108]
    a348:	b9400401 	ldr	w1, [x0, #4]
    a34c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a350:	b9400096 	ldr	w22, [x4]
    a354:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a358:	b97eec00 	ldr	w0, [x0, #16108]
    a35c:	4b0102d6 	sub	w22, w22, w1
    a360:	6b0002df 	cmp	w22, w0
    a364:	1a8092c7 	csel	w7, w22, w0, ls	// ls = plast
    a368:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a36c:	b97ee800 	ldr	w0, [x0, #16104]
    a370:	6b0000ff 	cmp	w7, w0
    a374:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    a378:	b93ee440 	str	w0, [x2, #16100]
    a37c:	6b0000e2 	subs	w2, w7, w0
    a380:	54000180 	b.eq	a3b0 <fwp_main_thread+0xa90>  // b.none
    a384:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a388:	0b000021 	add	w1, w1, w0
    a38c:	b93ef867 	str	w7, [x3, #16120]
    a390:	f9400c83 	ldr	x3, [x4, #24]
    a394:	d14013a4 	sub	x4, x29, #0x4, lsl #12
    a398:	f9400863 	ldr	x3, [x3, #16]
    a39c:	f95f7884 	ldr	x4, [x4, #16112]
    a3a0:	8b204c80 	add	x0, x4, w0, uxtw #3
    a3a4:	d63f0060 	blr	x3
    a3a8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3ac:	b97ef807 	ldr	w7, [x0, #16120]
    a3b0:	f9406b60 	ldr	x0, [x27, #208]
    a3b4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a3b8:	b94002e3 	ldr	w3, [x23]
    a3bc:	aa1703e5 	mov	x5, x23
    a3c0:	2a0703f4 	mov	w20, w7
    a3c4:	aa1703f9 	mov	x25, x23
    a3c8:	f95f7838 	ldr	x24, [x1, #16112]
    a3cc:	8b031403 	add	x3, x0, x3, lsl #5
    a3d0:	f9400c60 	ldr	x0, [x3, #24]
    a3d4:	b4002460 	cbz	x0, a860 <fwp_main_thread+0xf40>
    a3d8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a3dc:	f91f643c 	str	x28, [x1, #16072]
    a3e0:	b93ed027 	str	w7, [x1, #16080]
    a3e4:	b93ed836 	str	w22, [x1, #16088]
    a3e8:	aa0303f6 	mov	x22, x3
    a3ec:	14000012 	b	a434 <fwp_main_thread+0xb14>
    a3f0:	f9400001 	ldr	x1, [x0]
    a3f4:	aa1803e0 	mov	x0, x24
    a3f8:	d63f0020 	blr	x1
    a3fc:	aa0003f9 	mov	x25, x0
    a400:	aa1703e0 	mov	x0, x23
    a404:	97ffef63 	bl	6190 <fwp_closure_drop>
    a408:	6b13029f 	cmp	w20, w19
    a40c:	54000d00 	b.eq	a5ac <fwp_main_thread+0xc8c>  // b.none
    a410:	f9406b60 	ldr	x0, [x27, #208]
    a414:	8b334f18 	add	x24, x24, w19, uxtw #3
    a418:	b9400323 	ldr	w3, [x25]
    a41c:	4b1c0354 	sub	w20, w26, w28
    a420:	aa1903e5 	mov	x5, x25
    a424:	8b031416 	add	x22, x0, x3, lsl #5
    a428:	f9400ec0 	ldr	x0, [x22, #24]
    a42c:	b4002120 	cbz	x0, a850 <fwp_main_thread+0xf30>
    a430:	aa1903f7 	mov	x23, x25
    a434:	b94004a1 	ldr	w1, [x5, #4]
    a438:	b94002dc 	ldr	w28, [x22]
    a43c:	0b01029a 	add	w26, w20, w1
    a440:	6b1a039f 	cmp	w28, w26
    a444:	54002b28 	b.hi	a9a8 <fwp_main_thread+0x1088>  // b.pmore
    a448:	7100003f 	cmp	w1, #0x0
    a44c:	4b010393 	sub	w19, w28, w1
    a450:	7a400b84 	ccmp	w28, #0x0, #0x4, eq	// eq = none
    a454:	54fffce1 	b.ne	a3f0 <fwp_main_thread+0xad0>  // b.any
    a458:	7100039f 	cmp	w28, #0x0
    a45c:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a460:	1a9f1784 	csinc	w4, w28, wzr, ne	// ne = any
    a464:	910003e2 	mov	x2, sp
    a468:	d37df084 	lsl	x4, x4, #3
    a46c:	f91f7c62 	str	x2, [x3, #16120]
    a470:	91003c84 	add	x4, x4, #0xf
    a474:	92704c86 	and	x6, x4, #0xfffff0000
    a478:	927c7c84 	and	x4, x4, #0xffffffff0
    a47c:	cb2663e6 	sub	x6, sp, x6
    a480:	eb2663ff 	cmp	sp, x6
    a484:	540000a0 	b.eq	a498 <fwp_main_thread+0xb78>  // b.none
    a488:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a48c:	f90203ff 	str	xzr, [sp, #1024]
    a490:	eb2663ff 	cmp	sp, x6
    a494:	54ffffa1 	b.ne	a488 <fwp_main_thread+0xb68>  // b.any
    a498:	92403c84 	and	x4, x4, #0xffff
    a49c:	cb2463ff 	sub	sp, sp, x4
    a4a0:	f90003ff 	str	xzr, [sp]
    a4a4:	f110009f 	cmp	x4, #0x400
    a4a8:	54000043 	b.cc	a4b0 <fwp_main_thread+0xb90>  // b.lo, b.ul, b.last
    a4ac:	f90203ff 	str	xzr, [sp, #1024]
    a4b0:	910043f9 	add	x25, sp, #0x10
    a4b4:	d37d7c27 	ubfiz	x7, x1, #3, #32
    a4b8:	910020a6 	add	x6, x5, #0x8
    a4bc:	d2800004 	mov	x4, #0x0                   	// #0
    a4c0:	340000e1 	cbz	w1, a4dc <fwp_main_thread+0xbbc>
    a4c4:	d503201f 	nop
    a4c8:	f86468c2 	ldr	x2, [x6, x4]
    a4cc:	f8246b22 	str	x2, [x25, x4]
    a4d0:	91002084 	add	x4, x4, #0x8
    a4d4:	eb07009f 	cmp	x4, x7
    a4d8:	54ffff81 	b.ne	a4c8 <fwp_main_thread+0xba8>  // b.any
    a4dc:	2a1303e6 	mov	w6, w19
    a4e0:	d2800004 	mov	x4, #0x0                   	// #0
    a4e4:	340000f3 	cbz	w19, a500 <fwp_main_thread+0xbe0>
    a4e8:	0b040022 	add	w2, w1, w4
    a4ec:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    a4f0:	91000484 	add	x4, x4, #0x1
    a4f4:	f8227b23 	str	x3, [x25, x2, lsl #3]
    a4f8:	eb06009f 	cmp	x4, x6
    a4fc:	54ffff61 	b.ne	a4e8 <fwp_main_thread+0xbc8>  // b.any
    a500:	f949daa1 	ldr	x1, [x21, #5040]
    a504:	f949eea4 	ldr	x4, [x21, #5080]
    a508:	cb0102e1 	sub	x1, x23, x1
    a50c:	eb04403f 	cmp	x1, x4, lsl #16
    a510:	540002e2 	b.cs	a56c <fwp_main_thread+0xc4c>  // b.hs, b.nlast
    a514:	d350fc24 	lsr	x4, x1, #16
    a518:	f949fea8 	ldr	x8, [x21, #5112]
    a51c:	8b040884 	add	x4, x4, x4, lsl #2
    a520:	d37df084 	lsl	x4, x4, #3
    a524:	8b040107 	add	x7, x8, x4
    a528:	f94010e6 	ldr	x6, [x7, #32]
    a52c:	b4000206 	cbz	x6, a56c <fwp_main_thread+0xc4c>
    a530:	38646904 	ldrb	w4, [x8, x4]
    a534:	7100089f 	cmp	w4, #0x2
    a538:	54001860 	b.eq	a844 <fwp_main_thread+0xf24>  // b.none
    a53c:	7100049f 	cmp	w4, #0x1
    a540:	54000161 	b.ne	a56c <fwp_main_thread+0xc4c>  // b.any
    a544:	294310e8 	ldp	w8, w4, [x7, #24]
    a548:	92403c21 	and	x1, x1, #0xffff
    a54c:	9b087c21 	mul	x1, x1, x8
    a550:	d360fc21 	lsr	x1, x1, #32
    a554:	eb04003f 	cmp	x1, x4
    a558:	540000a2 	b.cs	a56c <fwp_main_thread+0xc4c>  // b.hs, b.nlast
    a55c:	8b0100c6 	add	x6, x6, x1
    a560:	394000c1 	ldrb	w1, [x6]
    a564:	7100043f 	cmp	w1, #0x1
    a568:	540016a0 	b.eq	a83c <fwp_main_thread+0xf1c>  // b.none
    a56c:	f9400404 	ldr	x4, [x0, #8]
    a570:	52800021 	mov	w1, #0x1                   	// #1
    a574:	aa1703e0 	mov	x0, x23
    a578:	d63f0080 	blr	x4
    a57c:	f9400ec1 	ldr	x1, [x22, #24]
    a580:	aa1903e0 	mov	x0, x25
    a584:	f9400021 	ldr	x1, [x1]
    a588:	d63f0020 	blr	x1
    a58c:	aa0003f9 	mov	x25, x0
    a590:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a594:	f95f7c00 	ldr	x0, [x0, #16120]
    a598:	9100001f 	mov	sp, x0
    a59c:	aa1703e0 	mov	x0, x23
    a5a0:	97ffeefc 	bl	6190 <fwp_closure_drop>
    a5a4:	6b13029f 	cmp	w20, w19
    a5a8:	54fff341 	b.ne	a410 <fwp_main_thread+0xaf0>  // b.any
    a5ac:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5b0:	aa1903f7 	mov	x23, x25
    a5b4:	f95f641c 	ldr	x28, [x0, #16072]
    a5b8:	b97ed007 	ldr	w7, [x0, #16080]
    a5bc:	b97ed816 	ldr	w22, [x0, #16088]
    a5c0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5c4:	b97eec00 	ldr	w0, [x0, #16108]
    a5c8:	6b0002df 	cmp	w22, w0
    a5cc:	54001823 	b.cc	a8d0 <fwp_main_thread+0xfb0>  // b.lo, b.ul, b.last
    a5d0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5d4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a5d8:	aa1c03f9 	mov	x25, x28
    a5dc:	f95f5c14 	ldr	x20, [x0, #16056]
    a5e0:	f95f6006 	ldr	x6, [x0, #16064]
    a5e4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5e8:	f95f5800 	ldr	x0, [x0, #16048]
    a5ec:	f1000400 	subs	x0, x0, #0x1
    a5f0:	f91f5820 	str	x0, [x1, #16048]
    a5f4:	54ffe2c1 	b.ne	a24c <fwp_main_thread+0x92c>  // b.any
    a5f8:	aa0103e0 	mov	x0, x1
    a5fc:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10540>
    a600:	91104042 	add	x2, x2, #0x410
    a604:	aa1703e1 	mov	x1, x23
    a608:	aa0603f6 	mov	x22, x6
    a60c:	aa1903f3 	mov	x19, x25
    a610:	f95f5018 	ldr	x24, [x0, #16032]
    a614:	aa1703f9 	mov	x25, x23
    a618:	f95f4c17 	ldr	x23, [x0, #16024]
    a61c:	91014042 	add	x2, x2, #0x50
    a620:	aa1403e0 	mov	x0, x20
    a624:	52800023 	mov	w3, #0x1                   	// #1
    a628:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a62c:	f81303bf 	stur	xzr, [x29, #-208]
    a630:	97fff8c0 	bl	8930 <fwp_write>
    a634:	a97273ba 	ldp	x26, x28, [x29, #-224]
    a638:	b0000000 	adrp	x0, b000 <__divti3+0x70>
    a63c:	911bc000 	add	x0, x0, #0x6f0
    a640:	f100035f 	cmp	x26, #0x0
    a644:	9a9a001a 	csel	x26, x0, x26, eq	// eq = none
    a648:	b1002b9f 	cmn	x28, #0xa
    a64c:	54004448 	b.hi	aed4 <fwp_main_thread+0x15b4>  // b.pmore
    a650:	91002780 	add	x0, x28, #0x9
    a654:	52800021 	mov	w1, #0x1                   	// #1
    a658:	97ffeaa2 	bl	50e0 <fwp_heap_alloc>
    a65c:	aa0003f5 	mov	x21, x0
    a660:	aa1a03e1 	mov	x1, x26
    a664:	aa0003fa 	mov	x26, x0
    a668:	aa1c03e2 	mov	x2, x28
    a66c:	f800875c 	str	x28, [x26], #8
    a670:	8b1c02bc 	add	x28, x21, x28
    a674:	aa1a03e0 	mov	x0, x26
    a678:	97ffdffa 	bl	2660 <memcpy@plt>
    a67c:	3900239f 	strb	wzr, [x28, #8]
    a680:	f85203a0 	ldur	x0, [x29, #-224]
    a684:	97ffe093 	bl	28d0 <free@plt>
    a688:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    a68c:	91198002 	add	x2, x0, #0x660
    a690:	f949d841 	ldr	x1, [x2, #5040]
    a694:	f949ec40 	ldr	x0, [x2, #5080]
    a698:	cb0102a1 	sub	x1, x21, x1
    a69c:	eb00403f 	cmp	x1, x0, lsl #16
    a6a0:	54000322 	b.cs	a704 <fwp_main_thread+0xde4>  // b.hs, b.nlast
    a6a4:	d350fc20 	lsr	x0, x1, #16
    a6a8:	f949fc43 	ldr	x3, [x2, #5112]
    a6ac:	8b000800 	add	x0, x0, x0, lsl #2
    a6b0:	d37df002 	lsl	x2, x0, #3
    a6b4:	8b020060 	add	x0, x3, x2
    a6b8:	f940101c 	ldr	x28, [x0, #32]
    a6bc:	b400025c 	cbz	x28, a704 <fwp_main_thread+0xde4>
    a6c0:	38626862 	ldrb	w2, [x3, x2]
    a6c4:	7100085f 	cmp	w2, #0x2
    a6c8:	54004140 	b.eq	aef0 <fwp_main_thread+0x15d0>  // b.none
    a6cc:	7100045f 	cmp	w2, #0x1
    a6d0:	540001a1 	b.ne	a704 <fwp_main_thread+0xde4>  // b.any
    a6d4:	29430002 	ldp	w2, w0, [x0, #24]
    a6d8:	92403c21 	and	x1, x1, #0xffff
    a6dc:	9b027c21 	mul	x1, x1, x2
    a6e0:	d360fc21 	lsr	x1, x1, #32
    a6e4:	eb00003f 	cmp	x1, x0
    a6e8:	540000e2 	b.cs	a704 <fwp_main_thread+0xde4>  // b.hs, b.nlast
    a6ec:	8b01039c 	add	x28, x28, x1
    a6f0:	39400380 	ldrb	w0, [x28]
    a6f4:	7103fc1f 	cmp	w0, #0xff
    a6f8:	540043c0 	b.eq	af70 <fwp_main_thread+0x1650>  // b.none
    a6fc:	52800020 	mov	w0, #0x1                   	// #1
    a700:	39000380 	strb	w0, [x28]
    a704:	aa1903e0 	mov	x0, x25
    a708:	97ffedf2 	bl	5ed0 <fwp_drop0>
    a70c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a710:	91018003 	add	x3, x0, #0x60
    a714:	f94002a2 	ldr	x2, [x21]
    a718:	aa1a03e0 	mov	x0, x26
    a71c:	aa0303fa 	mov	x26, x3
    a720:	d2800021 	mov	x1, #0x1                   	// #1
    a724:	f9404863 	ldr	x3, [x3, #144]
    a728:	97ffe07a 	bl	2910 <fwrite@plt>
    a72c:	f9404b41 	ldr	x1, [x26, #144]
    a730:	52800140 	mov	w0, #0xa                   	// #10
    a734:	97ffdfff 	bl	2730 <fputc@plt>
    a738:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    a73c:	91198002 	add	x2, x0, #0x660
    a740:	f949d841 	ldr	x1, [x2, #5040]
    a744:	f949ec40 	ldr	x0, [x2, #5080]
    a748:	cb0102a1 	sub	x1, x21, x1
    a74c:	eb00403f 	cmp	x1, x0, lsl #16
    a750:	54000382 	b.cs	a7c0 <fwp_main_thread+0xea0>  // b.hs, b.nlast
    a754:	d350fc20 	lsr	x0, x1, #16
    a758:	f949fc43 	ldr	x3, [x2, #5112]
    a75c:	8b000800 	add	x0, x0, x0, lsl #2
    a760:	d37df000 	lsl	x0, x0, #3
    a764:	8b000062 	add	x2, x3, x0
    a768:	f940105a 	ldr	x26, [x2, #32]
    a76c:	b40002ba 	cbz	x26, a7c0 <fwp_main_thread+0xea0>
    a770:	38606860 	ldrb	w0, [x3, x0]
    a774:	7100081f 	cmp	w0, #0x2
    a778:	54003b60 	b.eq	aee4 <fwp_main_thread+0x15c4>  // b.none
    a77c:	7100041f 	cmp	w0, #0x1
    a780:	54000201 	b.ne	a7c0 <fwp_main_thread+0xea0>  // b.any
    a784:	29430043 	ldp	w3, w0, [x2, #24]
    a788:	92403c21 	and	x1, x1, #0xffff
    a78c:	9b037c21 	mul	x1, x1, x3
    a790:	d360fc21 	lsr	x1, x1, #32
    a794:	eb00003f 	cmp	x1, x0
    a798:	54000142 	b.cs	a7c0 <fwp_main_thread+0xea0>  // b.hs, b.nlast
    a79c:	8b01035a 	add	x26, x26, x1
    a7a0:	39400340 	ldrb	w0, [x26]
    a7a4:	340000e0 	cbz	w0, a7c0 <fwp_main_thread+0xea0>
    a7a8:	7100041f 	cmp	w0, #0x1
    a7ac:	54003d60 	b.eq	af58 <fwp_main_thread+0x1638>  // b.none
    a7b0:	7103fc1f 	cmp	w0, #0xff
    a7b4:	54003a40 	b.eq	aefc <fwp_main_thread+0x15dc>  // b.none
    a7b8:	51000400 	sub	w0, w0, #0x1
    a7bc:	39000340 	strb	w0, [x26]
    a7c0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7c4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a7c8:	f95f5400 	ldr	x0, [x0, #16040]
    a7cc:	f9400800 	ldr	x0, [x0, #16]
    a7d0:	f91f5420 	str	x0, [x1, #16040]
    a7d4:	b5ffcde0 	cbnz	x0, a190 <fwp_main_thread+0x870>
    a7d8:	aa1703f5 	mov	x21, x23
    a7dc:	aa1803e0 	mov	x0, x24
    a7e0:	97ffedbc 	bl	5ed0 <fwp_drop0>
    a7e4:	aa1503e0 	mov	x0, x21
    a7e8:	97ffedba 	bl	5ed0 <fwp_drop0>
    a7ec:	d00000a0 	adrp	x0, 20000 <__data_start>
    a7f0:	91018000 	add	x0, x0, #0x60
    a7f4:	52800021 	mov	w1, #0x1                   	// #1
    a7f8:	b903e801 	str	w1, [x0, #1000]
    a7fc:	f901f81f 	str	xzr, [x0, #1008]
    a800:	17fffc94 	b	9a50 <fwp_main_thread+0x130>
    a804:	72003c5f 	tst	w2, #0xffff
    a808:	54ffbbc1 	b.ne	9f80 <fwp_main_thread+0x660>  // b.any
    a80c:	39400320 	ldrb	w0, [x25]
    a810:	7103fc1f 	cmp	w0, #0xff
    a814:	54ffbb41 	b.ne	9f7c <fwp_main_thread+0x65c>  // b.any
    a818:	aa1903e0 	mov	x0, x25
    a81c:	97ffe871 	bl	49e0 <fwp_rc_forget_slot>
    a820:	17fffdd7 	b	9f7c <fwp_main_thread+0x65c>
    a824:	b0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    a828:	913c8000 	add	x0, x0, #0xf20
    a82c:	94000395 	bl	b680 <atexit>
    a830:	17fffc51 	b	9974 <fwp_main_thread+0x54>
    a834:	97ffe614 	bl	4084 <fwp_heap_init>
    a838:	17fffc4b 	b	9964 <fwp_main_thread+0x44>
    a83c:	b90004bf 	str	wzr, [x5, #4]
    a840:	17ffff4f 	b	a57c <fwp_main_thread+0xc5c>
    a844:	72003c3f 	tst	w1, #0xffff
    a848:	54ffe921 	b.ne	a56c <fwp_main_thread+0xc4c>  // b.any
    a84c:	17ffff45 	b	a560 <fwp_main_thread+0xc40>
    a850:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a854:	f95f641c 	ldr	x28, [x0, #16072]
    a858:	b97ed007 	ldr	w7, [x0, #16080]
    a85c:	b97ed816 	ldr	w22, [x0, #16088]
    a860:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a864:	b93ef807 	str	w7, [x0, #16120]
    a868:	aa1903e0 	mov	x0, x25
    a86c:	97ffec96 	bl	5ac4 <fwp_rc_share>
    a870:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a874:	b97ef807 	ldr	w7, [x0, #16120]
    a878:	34000134 	cbz	w20, a89c <fwp_main_thread+0xf7c>
    a87c:	aa1803f7 	mov	x23, x24
    a880:	8b344f13 	add	x19, x24, w20, uxtw #3
    a884:	2a0703fa 	mov	w26, w7
    a888:	f84086e0 	ldr	x0, [x23], #8
    a88c:	97ffec8e 	bl	5ac4 <fwp_rc_share>
    a890:	eb1302ff 	cmp	x23, x19
    a894:	54ffffa1 	b.ne	a888 <fwp_main_thread+0xf68>  // b.any
    a898:	2a1a03e7 	mov	w7, w26
    a89c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8a0:	aa1803e2 	mov	x2, x24
    a8a4:	2a1403e1 	mov	w1, w20
    a8a8:	b93ef807 	str	w7, [x0, #16120]
    a8ac:	aa1903e0 	mov	x0, x25
    a8b0:	97ffea6d 	bl	5264 <fwp_apply>
    a8b4:	aa0003f7 	mov	x23, x0
    a8b8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8bc:	b97ef807 	ldr	w7, [x0, #16120]
    a8c0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8c4:	b97eec00 	ldr	w0, [x0, #16108]
    a8c8:	6b0002df 	cmp	w22, w0
    a8cc:	54ffe822 	b.cs	a5d0 <fwp_main_thread+0xcb0>  // b.hs, b.nlast
    a8d0:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a8d4:	b94002e4 	ldr	w4, [x23]
    a8d8:	f9406b61 	ldr	x1, [x27, #208]
    a8dc:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a8e0:	f95f7842 	ldr	x2, [x2, #16112]
    a8e4:	4b070000 	sub	w0, w0, w7
    a8e8:	8b041424 	add	x4, x1, x4, lsl #5
    a8ec:	b93eec60 	str	w0, [x3, #16108]
    a8f0:	b97ee860 	ldr	w0, [x3, #16104]
    a8f4:	8b274c42 	add	x2, x2, w7, uxtw #3
    a8f8:	f91f7862 	str	x2, [x3, #16112]
    a8fc:	f9400c81 	ldr	x1, [x4, #24]
    a900:	b97ee462 	ldr	w2, [x3, #16100]
    a904:	4b020000 	sub	w0, w0, w2
    a908:	b93ee860 	str	w0, [x3, #16104]
    a90c:	aa1703e0 	mov	x0, x23
    a910:	b5ffd1c1 	cbnz	x1, a348 <fwp_main_thread+0xa28>
    a914:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a918:	aa1c03f9 	mov	x25, x28
    a91c:	f95f6006 	ldr	x6, [x0, #16064]
    a920:	f91f7c06 	str	x6, [x0, #16120]
    a924:	f95f5c14 	ldr	x20, [x0, #16056]
    a928:	b97eec18 	ldr	w24, [x0, #16108]
    a92c:	aa1703e0 	mov	x0, x23
    a930:	97ffec65 	bl	5ac4 <fwp_rc_share>
    a934:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a938:	f95f7c06 	ldr	x6, [x0, #16120]
    a93c:	34000178 	cbz	w24, a968 <fwp_main_thread+0x1048>
    a940:	f95f7816 	ldr	x22, [x0, #16112]
    a944:	aa0603fa 	mov	x26, x6
    a948:	d2800015 	mov	x21, #0x0                   	// #0
    a94c:	d503201f 	nop
    a950:	f8757ac0 	ldr	x0, [x22, x21, lsl #3]
    a954:	910006b5 	add	x21, x21, #0x1
    a958:	97ffec5b 	bl	5ac4 <fwp_rc_share>
    a95c:	6b15031f 	cmp	w24, w21
    a960:	54ffff88 	b.hi	a950 <fwp_main_thread+0x1030>  // b.pmore
    a964:	aa1a03e6 	mov	x6, x26
    a968:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a96c:	2a1803e1 	mov	w1, w24
    a970:	f95f7802 	ldr	x2, [x0, #16112]
    a974:	f91f7c06 	str	x6, [x0, #16120]
    a978:	aa1703e0 	mov	x0, x23
    a97c:	97ffea3a 	bl	5264 <fwp_apply>
    a980:	aa0003f7 	mov	x23, x0
    a984:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a988:	f95f7c06 	ldr	x6, [x0, #16120]
    a98c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a990:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a994:	f95f5800 	ldr	x0, [x0, #16048]
    a998:	f1000400 	subs	x0, x0, #0x1
    a99c:	f91f5820 	str	x0, [x1, #16048]
    a9a0:	54ffc561 	b.ne	a24c <fwp_main_thread+0x92c>  // b.any
    a9a4:	17ffff15 	b	a5f8 <fwp_main_thread+0xcd8>
    a9a8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9ac:	b941536b 	ldr	w11, [x27, #336]
    a9b0:	aa1603e3 	mov	x3, x22
    a9b4:	2a0103f9 	mov	w25, w1
    a9b8:	f95f641c 	ldr	x28, [x0, #16072]
    a9bc:	b97ed007 	ldr	w7, [x0, #16080]
    a9c0:	b97ed816 	ldr	w22, [x0, #16088]
    a9c4:	11000740 	add	w0, w26, #0x1
    a9c8:	d37df000 	lsl	x0, x0, #3
    a9cc:	340000ab 	cbz	w11, a9e0 <fwp_main_thread+0x10c0>
    a9d0:	a9558769 	ldp	x9, x1, [x27, #344]
    a9d4:	91000529 	add	x9, x9, #0x1
    a9d8:	8b000021 	add	x1, x1, x0
    a9dc:	a9158769 	stp	x9, x1, [x27, #344]
    a9e0:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xb80>
    a9e4:	9119802a 	add	x10, x1, #0x660
    a9e8:	f140101f 	cmp	x0, #0x4, lsl #12
    a9ec:	b953a541 	ldr	w1, [x10, #5028]
    a9f0:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a9f4:	54001b60 	b.eq	ad60 <fwp_main_thread+0x1440>  // b.none
    a9f8:	91003c01 	add	x1, x0, #0xf
    a9fc:	8b411141 	add	x1, x10, x1, lsr #4
    aa00:	397e8021 	ldrb	w1, [x1, #4000]
    aa04:	910f002c 	add	x12, x1, #0x3c0
    aa08:	8b010429 	add	x9, x1, x1, lsl #1
    aa0c:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    aa10:	8b090d4d 	add	x13, x10, x9, lsl #3
    aa14:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    aa18:	2a0c03e1 	mov	w1, w12
    aa1c:	b4001913 	cbz	x19, ad3c <fwp_main_thread+0x141c>
    aa20:	f940026d 	ldr	x13, [x19]
    aa24:	aa2d03ed 	mvn	x13, x13
    aa28:	f829794d 	str	x13, [x10, x9, lsl #3]
    aa2c:	eb01001f 	cmp	x0, x1
    aa30:	540000c2 	b.cs	aa48 <fwp_main_thread+0x1128>  // b.hs, b.nlast
    aa34:	d503201f 	nop
    aa38:	f8206a7f 	str	xzr, [x19, x0]
    aa3c:	91002000 	add	x0, x0, #0x8
    aa40:	eb00003f 	cmp	x1, x0
    aa44:	54ffffa8 	b.hi	aa38 <fwp_main_thread+0x1118>  // b.pmore
    aa48:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    aa4c:	91198009 	add	x9, x0, #0x660
    aa50:	f94a1120 	ldr	x0, [x9, #5152]
    aa54:	ab010000 	adds	x0, x0, x1
    aa58:	540023c2 	b.cs	aed0 <fwp_main_thread+0x15b0>  // b.hs, b.nlast
    aa5c:	f94a1521 	ldr	x1, [x9, #5160]
    aa60:	f90a1120 	str	x0, [x9, #5152]
    aa64:	eb01001f 	cmp	x0, x1
    aa68:	54000049 	b.ls	aa70 <fwp_main_thread+0x1150>  // b.plast
    aa6c:	f90a1520 	str	x0, [x9, #5160]
    aa70:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    aa74:	91198000 	add	x0, x0, #0x660
    aa78:	1e630181 	ucvtf	d1, w12
    aa7c:	fd4a1c00 	ldr	d0, [x0, #5176]
    aa80:	1e612800 	fadd	d0, d0, d1
    aa84:	fd0a1c00 	str	d0, [x0, #5176]
    aa88:	3400012b 	cbz	w11, aaac <fwp_main_thread+0x118c>
    aa8c:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    aa90:	91198000 	add	x0, x0, #0x660
    aa94:	6d568762 	ldp	d2, d1, [x27, #360]
    aa98:	fd4a1000 	ldr	d0, [x0, #5152]
    aa9c:	7e61d800 	ucvtf	d0, d0
    aaa0:	1e623800 	fsub	d0, d0, d2
    aaa4:	1e612010 	fcmpe	d0, d1
    aaa8:	5400196c 	b.gt	add4 <fwp_main_thread+0x14b4>
    aaac:	b94000a0 	ldr	w0, [x5]
    aab0:	29006a60 	stp	w0, w26, [x19]
    aab4:	340001b9 	cbz	w25, aae8 <fwp_main_thread+0x11c8>
    aab8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aabc:	910020a1 	add	x1, x5, #0x8
    aac0:	d37d7f22 	ubfiz	x2, x25, #3, #32
    aac4:	b93ed007 	str	w7, [x0, #16080]
    aac8:	f91f6c03 	str	x3, [x0, #16088]
    aacc:	f91f7c05 	str	x5, [x0, #16120]
    aad0:	91002260 	add	x0, x19, #0x8
    aad4:	97ffdeeb 	bl	2680 <memmove@plt>
    aad8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aadc:	f95f6c03 	ldr	x3, [x0, #16088]
    aae0:	f95f7c05 	ldr	x5, [x0, #16120]
    aae4:	b97ed007 	ldr	w7, [x0, #16080]
    aae8:	2a1403e9 	mov	w9, w20
    aaec:	d2800001 	mov	x1, #0x0                   	// #0
    aaf0:	34000134 	cbz	w20, ab14 <fwp_main_thread+0x11f4>
    aaf4:	d503201f 	nop
    aaf8:	0b010320 	add	w0, w25, w1
    aafc:	f8617b02 	ldr	x2, [x24, x1, lsl #3]
    ab00:	8b000e60 	add	x0, x19, x0, lsl #3
    ab04:	91000421 	add	x1, x1, #0x1
    ab08:	f9000402 	str	x2, [x0, #8]
    ab0c:	eb09003f 	cmp	x1, x9
    ab10:	54ffff41 	b.ne	aaf8 <fwp_main_thread+0x11d8>  // b.any
    ab14:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    ab18:	91198002 	add	x2, x0, #0x660
    ab1c:	f949d840 	ldr	x0, [x2, #5040]
    ab20:	f949ec41 	ldr	x1, [x2, #5080]
    ab24:	cb0002e0 	sub	x0, x23, x0
    ab28:	eb01401f 	cmp	x0, x1, lsl #16
    ab2c:	540002e2 	b.cs	ab88 <fwp_main_thread+0x1268>  // b.hs, b.nlast
    ab30:	d350fc01 	lsr	x1, x0, #16
    ab34:	f949fc46 	ldr	x6, [x2, #5112]
    ab38:	8b010821 	add	x1, x1, x1, lsl #2
    ab3c:	d37df021 	lsl	x1, x1, #3
    ab40:	8b0100c4 	add	x4, x6, x1
    ab44:	f9401082 	ldr	x2, [x4, #32]
    ab48:	b4000202 	cbz	x2, ab88 <fwp_main_thread+0x1268>
    ab4c:	386168c1 	ldrb	w1, [x6, x1]
    ab50:	7100083f 	cmp	w1, #0x2
    ab54:	54001220 	b.eq	ad98 <fwp_main_thread+0x1478>  // b.none
    ab58:	7100043f 	cmp	w1, #0x1
    ab5c:	54000161 	b.ne	ab88 <fwp_main_thread+0x1268>  // b.any
    ab60:	29430486 	ldp	w6, w1, [x4, #24]
    ab64:	92403c00 	and	x0, x0, #0xffff
    ab68:	9b067c00 	mul	x0, x0, x6
    ab6c:	d360fc00 	lsr	x0, x0, #32
    ab70:	eb01001f 	cmp	x0, x1
    ab74:	540000a2 	b.cs	ab88 <fwp_main_thread+0x1268>  // b.hs, b.nlast
    ab78:	8b000042 	add	x2, x2, x0
    ab7c:	39400040 	ldrb	w0, [x2]
    ab80:	7100041f 	cmp	w0, #0x1
    ab84:	54000d20 	b.eq	ad28 <fwp_main_thread+0x1408>  // b.none
    ab88:	f9400c62 	ldr	x2, [x3, #24]
    ab8c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab90:	52800021 	mov	w1, #0x1                   	// #1
    ab94:	f9400442 	ldr	x2, [x2, #8]
    ab98:	b93ef807 	str	w7, [x0, #16120]
    ab9c:	aa1703e0 	mov	x0, x23
    aba0:	d63f0040 	blr	x2
    aba4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aba8:	b97ef807 	ldr	w7, [x0, #16120]
    abac:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    abb0:	91198002 	add	x2, x0, #0x660
    abb4:	f949d841 	ldr	x1, [x2, #5040]
    abb8:	f949ec40 	ldr	x0, [x2, #5080]
    abbc:	cb010261 	sub	x1, x19, x1
    abc0:	eb00403f 	cmp	x1, x0, lsl #16
    abc4:	54000322 	b.cs	ac28 <fwp_main_thread+0x1308>  // b.hs, b.nlast
    abc8:	d350fc20 	lsr	x0, x1, #16
    abcc:	f949fc43 	ldr	x3, [x2, #5112]
    abd0:	8b000800 	add	x0, x0, x0, lsl #2
    abd4:	d37df002 	lsl	x2, x0, #3
    abd8:	8b020060 	add	x0, x3, x2
    abdc:	f9401014 	ldr	x20, [x0, #32]
    abe0:	b4000254 	cbz	x20, ac28 <fwp_main_thread+0x1308>
    abe4:	38626862 	ldrb	w2, [x3, x2]
    abe8:	7100085f 	cmp	w2, #0x2
    abec:	54000dc0 	b.eq	ada4 <fwp_main_thread+0x1484>  // b.none
    abf0:	7100045f 	cmp	w2, #0x1
    abf4:	540001a1 	b.ne	ac28 <fwp_main_thread+0x1308>  // b.any
    abf8:	29430002 	ldp	w2, w0, [x0, #24]
    abfc:	92403c21 	and	x1, x1, #0xffff
    ac00:	9b027c21 	mul	x1, x1, x2
    ac04:	d360fc21 	lsr	x1, x1, #32
    ac08:	eb00003f 	cmp	x1, x0
    ac0c:	540000e2 	b.cs	ac28 <fwp_main_thread+0x1308>  // b.hs, b.nlast
    ac10:	8b010294 	add	x20, x20, x1
    ac14:	39400280 	ldrb	w0, [x20]
    ac18:	7103fc1f 	cmp	w0, #0xff
    ac1c:	54000ce0 	b.eq	adb8 <fwp_main_thread+0x1498>  // b.none
    ac20:	52800020 	mov	w0, #0x1                   	// #1
    ac24:	39000280 	strb	w0, [x20]
    ac28:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac2c:	b93ef807 	str	w7, [x0, #16120]
    ac30:	aa1703e0 	mov	x0, x23
    ac34:	97ffed57 	bl	6190 <fwp_closure_drop>
    ac38:	aa1303f7 	mov	x23, x19
    ac3c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac40:	b97ef807 	ldr	w7, [x0, #16120]
    ac44:	17ffff1f 	b	a8c0 <fwp_main_thread+0xfa0>
    ac48:	b8626860 	ldr	w0, [x3, x2]
    ac4c:	b94004a2 	ldr	w2, [x5, #4]
    ac50:	4b020003 	sub	w3, w0, w2
    ac54:	7100047f 	cmp	w3, #0x1
    ac58:	54ffb101 	b.ne	a278 <fwp_main_thread+0x958>  // b.any
    ac5c:	910003f5 	mov	x21, sp
    ac60:	34000ce2 	cbz	w2, adfc <fwp_main_thread+0x14dc>
    ac64:	7100001f 	cmp	w0, #0x0
    ac68:	d37d7c00 	ubfiz	x0, x0, #3, #32
    ac6c:	d2800101 	mov	x1, #0x8                   	// #8
    ac70:	9a811018 	csel	x24, x0, x1, ne	// ne = any
    ac74:	91003f00 	add	x0, x24, #0xf
    ac78:	92704c01 	and	x1, x0, #0xfffff0000
    ac7c:	927c7c00 	and	x0, x0, #0xffffffff0
    ac80:	cb2163e1 	sub	x1, sp, x1
    ac84:	eb2163ff 	cmp	sp, x1
    ac88:	540000a0 	b.eq	ac9c <fwp_main_thread+0x137c>  // b.none
    ac8c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    ac90:	f90203ff 	str	xzr, [sp, #1024]
    ac94:	eb2163ff 	cmp	sp, x1
    ac98:	54ffffa1 	b.ne	ac8c <fwp_main_thread+0x136c>  // b.any
    ac9c:	92403c00 	and	x0, x0, #0xffff
    aca0:	cb2063ff 	sub	sp, sp, x0
    aca4:	f90003ff 	str	xzr, [sp]
    aca8:	f110001f 	cmp	x0, #0x400
    acac:	54000043 	b.cc	acb4 <fwp_main_thread+0x1394>  // b.lo, b.ul, b.last
    acb0:	f90203ff 	str	xzr, [sp, #1024]
    acb4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acb8:	d37d7c5a 	ubfiz	x26, x2, #3, #32
    acbc:	910043f6 	add	x22, sp, #0x10
    acc0:	91004321 	add	x1, x25, #0x10
    acc4:	aa1a03e2 	mov	x2, x26
    acc8:	9100c021 	add	x1, x1, #0x30
    accc:	aa1803e3 	mov	x3, x24
    acd0:	f91f7806 	str	x6, [x0, #16112]
    acd4:	f91f7c04 	str	x4, [x0, #16120]
    acd8:	aa1603e0 	mov	x0, x22
    acdc:	97ffdea1 	bl	2760 <__memcpy_chk@plt>
    ace0:	eb1a031f 	cmp	x24, x26
    ace4:	aa1403e1 	mov	x1, x20
    ace8:	9a9a2303 	csel	x3, x24, x26, cs	// cs = hs, nlast
    acec:	d2800102 	mov	x2, #0x8                   	// #8
    acf0:	cb1a0063 	sub	x3, x3, x26
    acf4:	8b1a02c0 	add	x0, x22, x26
    acf8:	97ffde9a 	bl	2760 <__memcpy_chk@plt>
    acfc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad00:	aa1603e0 	mov	x0, x22
    ad04:	f95f7c24 	ldr	x4, [x1, #16120]
    ad08:	f9400c81 	ldr	x1, [x4, #24]
    ad0c:	f9400021 	ldr	x1, [x1]
    ad10:	d63f0020 	blr	x1
    ad14:	aa0003f7 	mov	x23, x0
    ad18:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad1c:	f95f7806 	ldr	x6, [x0, #16112]
    ad20:	910002bf 	mov	sp, x21
    ad24:	17ffff1a 	b	a98c <fwp_main_thread+0x106c>
    ad28:	b90004bf 	str	wzr, [x5, #4]
    ad2c:	17ffffa0 	b	abac <fwp_main_thread+0x128c>
    ad30:	72003c3f 	tst	w1, #0xffff
    ad34:	54ffaec1 	b.ne	a30c <fwp_main_thread+0x9ec>  // b.any
    ad38:	17fffd6a 	b	a2e0 <fwp_main_thread+0x9c0>
    ad3c:	f94005b3 	ldr	x19, [x13, #8]
    ad40:	b4000113 	cbz	x19, ad60 <fwp_main_thread+0x1440>
    ad44:	f94009a9 	ldr	x9, [x13, #16]
    ad48:	cb130129 	sub	x9, x9, x19
    ad4c:	eb09003f 	cmp	x1, x9
    ad50:	54000088 	b.hi	ad60 <fwp_main_thread+0x1440>  // b.pmore
    ad54:	8b010269 	add	x9, x19, x1
    ad58:	f90005a9 	str	x9, [x13, #8]
    ad5c:	17ffff34 	b	aa2c <fwp_main_thread+0x110c>
    ad60:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad64:	b93ec82b 	str	w11, [x1, #16072]
    ad68:	f91f6825 	str	x5, [x1, #16080]
    ad6c:	b93ed827 	str	w7, [x1, #16088]
    ad70:	f91f7c23 	str	x3, [x1, #16120]
    ad74:	52800001 	mov	w1, #0x0                   	// #0
    ad78:	97ffe8da 	bl	50e0 <fwp_heap_alloc>
    ad7c:	aa0003f3 	mov	x19, x0
    ad80:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad84:	f95f6805 	ldr	x5, [x0, #16080]
    ad88:	f95f7c03 	ldr	x3, [x0, #16120]
    ad8c:	b97ec80b 	ldr	w11, [x0, #16072]
    ad90:	b97ed807 	ldr	w7, [x0, #16088]
    ad94:	17ffff3d 	b	aa88 <fwp_main_thread+0x1168>
    ad98:	72003c1f 	tst	w0, #0xffff
    ad9c:	54ffef61 	b.ne	ab88 <fwp_main_thread+0x1268>  // b.any
    ada0:	17ffff77 	b	ab7c <fwp_main_thread+0x125c>
    ada4:	72003c3f 	tst	w1, #0xffff
    ada8:	54fff401 	b.ne	ac28 <fwp_main_thread+0x1308>  // b.any
    adac:	39400280 	ldrb	w0, [x20]
    adb0:	7103fc1f 	cmp	w0, #0xff
    adb4:	54fff361 	b.ne	ac20 <fwp_main_thread+0x1300>  // b.any
    adb8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    adbc:	b93ef807 	str	w7, [x0, #16120]
    adc0:	aa1403e0 	mov	x0, x20
    adc4:	97ffe707 	bl	49e0 <fwp_rc_forget_slot>
    adc8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    adcc:	b97ef807 	ldr	w7, [x0, #16120]
    add0:	17ffff94 	b	ac20 <fwp_main_thread+0x1300>
    add4:	fd00bb60 	str	d0, [x27, #368]
    add8:	17ffff35 	b	aaac <fwp_main_thread+0x118c>
    addc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ade0:	f91f7826 	str	x6, [x1, #16112]
    ade4:	f91f7c24 	str	x4, [x1, #16120]
    ade8:	97ffe6b7 	bl	48c4 <fwp_rc_wide_dup>
    adec:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    adf0:	f95f7806 	ldr	x6, [x0, #16112]
    adf4:	f95f7c04 	ldr	x4, [x0, #16120]
    adf8:	17fffd45 	b	a30c <fwp_main_thread+0x9ec>
    adfc:	f9400021 	ldr	x1, [x1]
    ae00:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae04:	f91f7c06 	str	x6, [x0, #16120]
    ae08:	aa1403e0 	mov	x0, x20
    ae0c:	d63f0020 	blr	x1
    ae10:	aa0003f7 	mov	x23, x0
    ae14:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae18:	f95f7c06 	ldr	x6, [x0, #16120]
    ae1c:	910002bf 	mov	sp, x21
    ae20:	17fffedb 	b	a98c <fwp_main_thread+0x106c>
    ae24:	72003c3f 	tst	w1, #0xffff
    ae28:	54ff9501 	b.ne	a0c8 <fwp_main_thread+0x7a8>  // b.any
    ae2c:	17fffca2 	b	a0b4 <fwp_main_thread+0x794>
    ae30:	72003c3f 	tst	w1, #0xffff
    ae34:	54ff9001 	b.ne	a034 <fwp_main_thread+0x714>  // b.any
    ae38:	17fffc7a 	b	a020 <fwp_main_thread+0x700>
    ae3c:	72003c3f 	tst	w1, #0xffff
    ae40:	54ff9901 	b.ne	a160 <fwp_main_thread+0x840>  // b.any
    ae44:	17fffcc2 	b	a14c <fwp_main_thread+0x82c>
    ae48:	72003c3f 	tst	w1, #0xffff
    ae4c:	54ff9f01 	b.ne	a22c <fwp_main_thread+0x90c>  // b.any
    ae50:	17fffcea 	b	a1f8 <fwp_main_thread+0x8d8>
    ae54:	aa0103e0 	mov	x0, x1
    ae58:	17fffb88 	b	9c78 <fwp_main_thread+0x358>
    ae5c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ae60:	aa0603e0 	mov	x0, x6
    ae64:	52800038 	mov	w24, #0x1                   	// #1
    ae68:	f91f7c26 	str	x6, [x1, #16120]
    ae6c:	97ffeb16 	bl	5ac4 <fwp_rc_share>
    ae70:	aa1703e0 	mov	x0, x23
    ae74:	97ffeb14 	bl	5ac4 <fwp_rc_share>
    ae78:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae7c:	f95f7c06 	ldr	x6, [x0, #16120]
    ae80:	f91f7814 	str	x20, [x0, #16112]
    ae84:	aa0603f7 	mov	x23, x6
    ae88:	17fffeb8 	b	a968 <fwp_main_thread+0x1048>
    ae8c:	aa1603e0 	mov	x0, x22
    ae90:	97ffe6d4 	bl	49e0 <fwp_rc_forget_slot>
    ae94:	17fffc66 	b	a02c <fwp_main_thread+0x70c>
    ae98:	97ffe68b 	bl	48c4 <fwp_rc_wide_dup>
    ae9c:	17fffce4 	b	a22c <fwp_main_thread+0x90c>
    aea0:	aa1303e0 	mov	x0, x19
    aea4:	97ffe6cf 	bl	49e0 <fwp_rc_forget_slot>
    aea8:	17fffc86 	b	a0c0 <fwp_main_thread+0x7a0>
    aeac:	aa1303e0 	mov	x0, x19
    aeb0:	97ffe6cc 	bl	49e0 <fwp_rc_forget_slot>
    aeb4:	17fffca9 	b	a158 <fwp_main_thread+0x838>
    aeb8:	b0000000 	adrp	x0, b000 <__divti3+0x70>
    aebc:	913ac000 	add	x0, x0, #0xeb0
    aec0:	97ffe110 	bl	3300 <ad_raw_fail>
    aec4:	b0000000 	adrp	x0, b000 <__divti3+0x70>
    aec8:	913a2000 	add	x0, x0, #0xe88
    aecc:	97ffe22d 	bl	3780 <fwp_trap>
    aed0:	97ffe088 	bl	30f0 <fwp_heap_oom>
    aed4:	b0000000 	adrp	x0, b000 <__divti3+0x70>
    aed8:	913b4000 	add	x0, x0, #0xed0
    aedc:	97ffe229 	bl	3780 <fwp_trap>
    aee0:	97ffde4c 	bl	2810 <__stack_chk_fail@plt>
    aee4:	72003c3f 	tst	w1, #0xffff
    aee8:	54ffc6c1 	b.ne	a7c0 <fwp_main_thread+0xea0>  // b.any
    aeec:	17fffe2d 	b	a7a0 <fwp_main_thread+0xe80>
    aef0:	72003c3f 	tst	w1, #0xffff
    aef4:	54ffc081 	b.ne	a704 <fwp_main_thread+0xde4>  // b.any
    aef8:	17fffdfe 	b	a6f0 <fwp_main_thread+0xdd0>
    aefc:	ca5a4740 	eor	x0, x26, x26, lsr #17
    af00:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xb80>
    af04:	91198021 	add	x1, x1, #0x660
    af08:	ca402400 	eor	x0, x0, x0, lsr #9
    af0c:	8b200c20 	add	x0, x1, w0, uxtb #3
    af10:	f94a2400 	ldr	x0, [x0, #5192]
    af14:	b5000080 	cbnz	x0, af24 <fwp_main_thread+0x1604>
    af18:	14000019 	b	af7c <fwp_main_thread+0x165c>
    af1c:	f9400800 	ldr	x0, [x0, #16]
    af20:	b40002e0 	cbz	x0, af7c <fwp_main_thread+0x165c>
    af24:	f9400001 	ldr	x1, [x0]
    af28:	eb01035f 	cmp	x26, x1
    af2c:	54ffff81 	b.ne	af1c <fwp_main_thread+0x15fc>  // b.any
    af30:	f9400401 	ldr	x1, [x0, #8]
    af34:	d1000421 	sub	x1, x1, #0x1
    af38:	f9000401 	str	x1, [x0, #8]
    af3c:	f103f83f 	cmp	x1, #0xfe
    af40:	54ffc401 	b.ne	a7c0 <fwp_main_thread+0xea0>  // b.any
    af44:	aa1a03e0 	mov	x0, x26
    af48:	97ffe6a6 	bl	49e0 <fwp_rc_forget_slot>
    af4c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    af50:	39000340 	strb	w0, [x26]
    af54:	17fffe1b 	b	a7c0 <fwp_main_thread+0xea0>
    af58:	aa1503e0 	mov	x0, x21
    af5c:	97ffeb01 	bl	5b60 <fwp_rc_free_arr>
    af60:	17fffe18 	b	a7c0 <fwp_main_thread+0xea0>
    af64:	b903fa9f 	str	wzr, [x20, #1016]
    af68:	b4ff6bc0 	cbz	x0, 9ce0 <fwp_main_thread+0x3c0>
    af6c:	97ffde3d 	bl	2860 <abort@plt>
    af70:	aa1c03e0 	mov	x0, x28
    af74:	97ffe69b 	bl	49e0 <fwp_rc_forget_slot>
    af78:	17fffde1 	b	a6fc <fwp_main_thread+0xddc>
    af7c:	b0000000 	adrp	x0, b000 <__divti3+0x70>
    af80:	912dc000 	add	x0, x0, #0xb70
    af84:	97ffe1ff 	bl	3780 <fwp_trap>
    af88:	d503201f 	nop
    af8c:	d503201f 	nop

000000000000af90 <__divti3>:
    af90:	d503245f 	bti	c
    af94:	d2800004 	mov	x4, #0x0                   	// #0
    af98:	b7f80721 	tbnz	x1, #63, b07c <__divti3+0xec>
    af9c:	b6f80083 	tbz	x3, #63, afac <__divti3+0x1c>
    afa0:	eb0203e2 	negs	x2, x2
    afa4:	aa2403e4 	mvn	x4, x4
    afa8:	da0303e3 	ngc	x3, x3
    afac:	aa0203e6 	mov	x6, x2
    afb0:	aa0003e7 	mov	x7, x0
    afb4:	aa0103e5 	mov	x5, x1
    afb8:	b5000583 	cbnz	x3, b068 <__divti3+0xd8>
    afbc:	eb01005f 	cmp	x2, x1
    afc0:	54000e69 	b.ls	b18c <__divti3+0x1fc>  // b.plast
    afc4:	dac01040 	clz	x0, x2
    afc8:	b40000e0 	cbz	x0, afe4 <__divti3+0x54>
    afcc:	4b0003e1 	neg	w1, w0
    afd0:	9ac020a5 	lsl	x5, x5, x0
    afd4:	9ac02046 	lsl	x6, x2, x0
    afd8:	9ac124e1 	lsr	x1, x7, x1
    afdc:	aa050025 	orr	x5, x1, x5
    afe0:	9ac020e7 	lsl	x7, x7, x0
    afe4:	d360fcc8 	lsr	x8, x6, #32
    afe8:	92407cc2 	and	x2, x6, #0xffffffff
    afec:	9ac808a3 	udiv	x3, x5, x8
    aff0:	9b089465 	msub	x5, x3, x8, x5
    aff4:	aa0303e0 	mov	x0, x3
    aff8:	9b037c41 	mul	x1, x2, x3
    affc:	93c780a5 	extr	x5, x5, x7, #32
    b000:	eb05003f 	cmp	x1, x5
    b004:	540000a9 	b.ls	b018 <__divti3+0x88>  // b.plast
    b008:	ab0500c5 	adds	x5, x6, x5
    b00c:	d1000460 	sub	x0, x3, #0x1
    b010:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    b014:	540015a8 	b.hi	b2c8 <__divti3+0x338>  // b.pmore
    b018:	cb0100a5 	sub	x5, x5, x1
    b01c:	9ac808a3 	udiv	x3, x5, x8
    b020:	9b089465 	msub	x5, x3, x8, x5
    b024:	aa0303e1 	mov	x1, x3
    b028:	9b037c42 	mul	x2, x2, x3
    b02c:	aa0703e3 	mov	x3, x7
    b030:	b3607ca3 	bfi	x3, x5, #32, #32
    b034:	eb03005f 	cmp	x2, x3
    b038:	540000c9 	b.ls	b050 <__divti3+0xc0>  // b.plast
    b03c:	ab0300c3 	adds	x3, x6, x3
    b040:	d1000425 	sub	x5, x1, #0x1
    b044:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b048:	d1000821 	sub	x1, x1, #0x2
    b04c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    b050:	aa008020 	orr	x0, x1, x0, lsl #32
    b054:	d2800001 	mov	x1, #0x0                   	// #0
    b058:	b4000064 	cbz	x4, b064 <__divti3+0xd4>
    b05c:	eb0003e0 	negs	x0, x0
    b060:	da0103e1 	ngc	x1, x1
    b064:	d65f03c0 	ret
    b068:	eb01007f 	cmp	x3, x1
    b06c:	54000109 	b.ls	b08c <__divti3+0xfc>  // b.plast
    b070:	d2800001 	mov	x1, #0x0                   	// #0
    b074:	d2800000 	mov	x0, #0x0                   	// #0
    b078:	17fffff8 	b	b058 <__divti3+0xc8>
    b07c:	eb0003e0 	negs	x0, x0
    b080:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b084:	da0103e1 	ngc	x1, x1
    b088:	17ffffc5 	b	af9c <__divti3+0xc>
    b08c:	dac01067 	clz	x7, x3
    b090:	b40010e7 	cbz	x7, b2ac <__divti3+0x31c>
    b094:	d2800805 	mov	x5, #0x40                  	// #64
    b098:	cb0700a5 	sub	x5, x5, x7
    b09c:	9ac72063 	lsl	x3, x3, x7
    b0a0:	9ac52448 	lsr	x8, x2, x5
    b0a4:	aa030108 	orr	x8, x8, x3
    b0a8:	9ac52426 	lsr	x6, x1, x5
    b0ac:	92407d0a 	and	x10, x8, #0xffffffff
    b0b0:	d360fd09 	lsr	x9, x8, #32
    b0b4:	9ac52403 	lsr	x3, x0, x5
    b0b8:	9ac72021 	lsl	x1, x1, x7
    b0bc:	aa010063 	orr	x3, x3, x1
    b0c0:	9ac72042 	lsl	x2, x2, x7
    b0c4:	9ac908cb 	udiv	x11, x6, x9
    b0c8:	9b099965 	msub	x5, x11, x9, x6
    b0cc:	aa0b03e1 	mov	x1, x11
    b0d0:	9b0b7d46 	mul	x6, x10, x11
    b0d4:	93c380a5 	extr	x5, x5, x3, #32
    b0d8:	eb0500df 	cmp	x6, x5
    b0dc:	540000a9 	b.ls	b0f0 <__divti3+0x160>  // b.plast
    b0e0:	ab050105 	adds	x5, x8, x5
    b0e4:	d1000561 	sub	x1, x11, #0x1
    b0e8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    b0ec:	54000f48 	b.hi	b2d4 <__divti3+0x344>  // b.pmore
    b0f0:	cb0600a6 	sub	x6, x5, x6
    b0f4:	9ac908cb 	udiv	x11, x6, x9
    b0f8:	9b099969 	msub	x9, x11, x9, x6
    b0fc:	aa0b03e5 	mov	x5, x11
    b100:	9b0b7d4a 	mul	x10, x10, x11
    b104:	b3607d23 	bfi	x3, x9, #32, #32
    b108:	eb03015f 	cmp	x10, x3
    b10c:	540000a9 	b.ls	b120 <__divti3+0x190>  // b.plast
    b110:	ab030103 	adds	x3, x8, x3
    b114:	d1000565 	sub	x5, x11, #0x1
    b118:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    b11c:	54000e28 	b.hi	b2e0 <__divti3+0x350>  // b.pmore
    b120:	aa0180a1 	orr	x1, x5, x1, lsl #32
    b124:	92407c48 	and	x8, x2, #0xffffffff
    b128:	2a0503e5 	mov	w5, w5
    b12c:	d360fc42 	lsr	x2, x2, #32
    b130:	d360fc26 	lsr	x6, x1, #32
    b134:	cb0a0063 	sub	x3, x3, x10
    b138:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    b13c:	9b087caa 	mul	x10, x5, x8
    b140:	9b087cc8 	mul	x8, x6, x8
    b144:	9b0220a5 	madd	x5, x5, x2, x8
    b148:	9b027cc6 	mul	x6, x6, x2
    b14c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    b150:	8b0900c5 	add	x5, x6, x9
    b154:	eb02011f 	cmp	x8, x2
    b158:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    b15c:	8b4280c6 	add	x6, x6, x2, lsr #32
    b160:	eb06007f 	cmp	x3, x6
    b164:	540000e3 	b.cc	b180 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    b168:	92407d4a 	and	x10, x10, #0xffffffff
    b16c:	9ac72000 	lsl	x0, x0, x7
    b170:	8b028142 	add	x2, x10, x2, lsl #32
    b174:	eb02001f 	cmp	x0, x2
    b178:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    b17c:	54000a01 	b.ne	b2bc <__divti3+0x32c>  // b.any
    b180:	d1000420 	sub	x0, x1, #0x1
    b184:	d2800001 	mov	x1, #0x0                   	// #0
    b188:	17ffffb4 	b	b058 <__divti3+0xc8>
    b18c:	b5000062 	cbnz	x2, b198 <__divti3+0x208>
    b190:	d2800022 	mov	x2, #0x1                   	// #1
    b194:	9ac30846 	udiv	x6, x2, x3
    b198:	dac010c8 	clz	x8, x6
    b19c:	b5000408 	cbnz	x8, b21c <__divti3+0x28c>
    b1a0:	d360fcc9 	lsr	x9, x6, #32
    b1a4:	92407cc5 	and	x5, x6, #0xffffffff
    b1a8:	cb060023 	sub	x3, x1, x6
    b1ac:	d2800021 	mov	x1, #0x1                   	// #1
    b1b0:	9ac90868 	udiv	x8, x3, x9
    b1b4:	9b098d03 	msub	x3, x8, x9, x3
    b1b8:	aa0803e0 	mov	x0, x8
    b1bc:	9b057d02 	mul	x2, x8, x5
    b1c0:	93c78063 	extr	x3, x3, x7, #32
    b1c4:	eb03005f 	cmp	x2, x3
    b1c8:	540000a9 	b.ls	b1dc <__divti3+0x24c>  // b.plast
    b1cc:	ab0300c3 	adds	x3, x6, x3
    b1d0:	d1000500 	sub	x0, x8, #0x1
    b1d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b1d8:	54000968 	b.hi	b304 <__divti3+0x374>  // b.pmore
    b1dc:	cb020063 	sub	x3, x3, x2
    b1e0:	9ac90862 	udiv	x2, x3, x9
    b1e4:	aa0203e8 	mov	x8, x2
    b1e8:	9b098c42 	msub	x2, x2, x9, x3
    b1ec:	aa0703e3 	mov	x3, x7
    b1f0:	9b057d05 	mul	x5, x8, x5
    b1f4:	b3607c43 	bfi	x3, x2, #32, #32
    b1f8:	eb0300bf 	cmp	x5, x3
    b1fc:	540000c9 	b.ls	b214 <__divti3+0x284>  // b.plast
    b200:	ab0300c2 	adds	x2, x6, x3
    b204:	d1000503 	sub	x3, x8, #0x1
    b208:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    b20c:	d1000908 	sub	x8, x8, #0x2
    b210:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    b214:	aa008100 	orr	x0, x8, x0, lsl #32
    b218:	17ffff90 	b	b058 <__divti3+0xc8>
    b21c:	9ac820c6 	lsl	x6, x6, x8
    b220:	d2800803 	mov	x3, #0x40                  	// #64
    b224:	cb080063 	sub	x3, x3, x8
    b228:	d360fcc9 	lsr	x9, x6, #32
    b22c:	9ac82027 	lsl	x7, x1, x8
    b230:	92407cc5 	and	x5, x6, #0xffffffff
    b234:	9ac32422 	lsr	x2, x1, x3
    b238:	9ac32403 	lsr	x3, x0, x3
    b23c:	aa070063 	orr	x3, x3, x7
    b240:	9ac9084a 	udiv	x10, x2, x9
    b244:	9ac82007 	lsl	x7, x0, x8
    b248:	9b098940 	msub	x0, x10, x9, x2
    b24c:	aa0a03e1 	mov	x1, x10
    b250:	9b0a7ca2 	mul	x2, x5, x10
    b254:	93c38000 	extr	x0, x0, x3, #32
    b258:	eb00005f 	cmp	x2, x0
    b25c:	540000a9 	b.ls	b270 <__divti3+0x2e0>  // b.plast
    b260:	ab0000c0 	adds	x0, x6, x0
    b264:	d1000541 	sub	x1, x10, #0x1
    b268:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    b26c:	54000468 	b.hi	b2f8 <__divti3+0x368>  // b.pmore
    b270:	cb020000 	sub	x0, x0, x2
    b274:	9ac9080a 	udiv	x10, x0, x9
    b278:	9b098140 	msub	x0, x10, x9, x0
    b27c:	aa0a03e2 	mov	x2, x10
    b280:	9b0a7ca8 	mul	x8, x5, x10
    b284:	b3607c03 	bfi	x3, x0, #32, #32
    b288:	eb03011f 	cmp	x8, x3
    b28c:	540000a9 	b.ls	b2a0 <__divti3+0x310>  // b.plast
    b290:	ab0300c3 	adds	x3, x6, x3
    b294:	d1000542 	sub	x2, x10, #0x1
    b298:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    b29c:	54000288 	b.hi	b2ec <__divti3+0x35c>  // b.pmore
    b2a0:	cb080063 	sub	x3, x3, x8
    b2a4:	aa018041 	orr	x1, x2, x1, lsl #32
    b2a8:	17ffffc2 	b	b1b0 <__divti3+0x220>
    b2ac:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    b2b0:	d2800001 	mov	x1, #0x0                   	// #0
    b2b4:	9a9f87e0 	cset	x0, ls	// ls = plast
    b2b8:	17ffff68 	b	b058 <__divti3+0xc8>
    b2bc:	aa0103e0 	mov	x0, x1
    b2c0:	d2800001 	mov	x1, #0x0                   	// #0
    b2c4:	17ffff65 	b	b058 <__divti3+0xc8>
    b2c8:	d1000860 	sub	x0, x3, #0x2
    b2cc:	8b0600a5 	add	x5, x5, x6
    b2d0:	17ffff52 	b	b018 <__divti3+0x88>
    b2d4:	d1000961 	sub	x1, x11, #0x2
    b2d8:	8b0800a5 	add	x5, x5, x8
    b2dc:	17ffff85 	b	b0f0 <__divti3+0x160>
    b2e0:	d1000965 	sub	x5, x11, #0x2
    b2e4:	8b080063 	add	x3, x3, x8
    b2e8:	17ffff8e 	b	b120 <__divti3+0x190>
    b2ec:	d1000942 	sub	x2, x10, #0x2
    b2f0:	8b060063 	add	x3, x3, x6
    b2f4:	17ffffeb 	b	b2a0 <__divti3+0x310>
    b2f8:	d1000941 	sub	x1, x10, #0x2
    b2fc:	8b060000 	add	x0, x0, x6
    b300:	17ffffdc 	b	b270 <__divti3+0x2e0>
    b304:	d1000900 	sub	x0, x8, #0x2
    b308:	8b060063 	add	x3, x3, x6
    b30c:	17ffffb4 	b	b1dc <__divti3+0x24c>

000000000000b310 <__modti3>:
    b310:	d503245f 	bti	c
    b314:	d2800004 	mov	x4, #0x0                   	// #0
    b318:	b6f80081 	tbz	x1, #63, b328 <__modti3+0x18>
    b31c:	eb0003e0 	negs	x0, x0
    b320:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b324:	da0103e1 	ngc	x1, x1
    b328:	f100007f 	cmp	x3, #0x0
    b32c:	5400128b 	b.lt	b57c <__modti3+0x26c>  // b.tstop
    b330:	aa0003e7 	mov	x7, x0
    b334:	aa0103e6 	mov	x6, x1
    b338:	540004e1 	b.ne	b3d4 <__modti3+0xc4>  // b.any
    b33c:	eb02003f 	cmp	x1, x2
    b340:	54000dc2 	b.cs	b4f8 <__modti3+0x1e8>  // b.hs, b.nlast
    b344:	dac01043 	clz	x3, x2
    b348:	aa0303e5 	mov	x5, x3
    b34c:	b40000e3 	cbz	x3, b368 <__modti3+0x58>
    b350:	4b0303e6 	neg	w6, w3
    b354:	9ac32021 	lsl	x1, x1, x3
    b358:	9ac32042 	lsl	x2, x2, x3
    b35c:	9ac62406 	lsr	x6, x0, x6
    b360:	aa0100c6 	orr	x6, x6, x1
    b364:	9ac32007 	lsl	x7, x0, x3
    b368:	d360fc40 	lsr	x0, x2, #32
    b36c:	92407c43 	and	x3, x2, #0xffffffff
    b370:	9ac008c1 	udiv	x1, x6, x0
    b374:	9b009826 	msub	x6, x1, x0, x6
    b378:	9b017c61 	mul	x1, x3, x1
    b37c:	93c780c6 	extr	x6, x6, x7, #32
    b380:	eb06003f 	cmp	x1, x6
    b384:	540000a9 	b.ls	b398 <__modti3+0x88>  // b.plast
    b388:	ab060046 	adds	x6, x2, x6
    b38c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b390:	8b0200c8 	add	x8, x6, x2
    b394:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b398:	cb0100c6 	sub	x6, x6, x1
    b39c:	9ac008c8 	udiv	x8, x6, x0
    b3a0:	9b009901 	msub	x1, x8, x0, x6
    b3a4:	aa0703e0 	mov	x0, x7
    b3a8:	9b087c63 	mul	x3, x3, x8
    b3ac:	b3607c20 	bfi	x0, x1, #32, #32
    b3b0:	eb00007f 	cmp	x3, x0
    b3b4:	54001088 	b.hi	b5c4 <__modti3+0x2b4>  // b.pmore
    b3b8:	cb030000 	sub	x0, x0, x3
    b3bc:	9ac52400 	lsr	x0, x0, x5
    b3c0:	d2800001 	mov	x1, #0x0                   	// #0
    b3c4:	b4000064 	cbz	x4, b3d0 <__modti3+0xc0>
    b3c8:	eb0003e0 	negs	x0, x0
    b3cc:	da0103e1 	ngc	x1, x1
    b3d0:	d65f03c0 	ret
    b3d4:	dac01066 	clz	x6, x3
    b3d8:	eb03003f 	cmp	x1, x3
    b3dc:	54ffff43 	b.cc	b3c4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b3e0:	93407cc5 	sxtw	x5, w6
    b3e4:	d2800808 	mov	x8, #0x40                  	// #64
    b3e8:	cb050108 	sub	x8, x8, x5
    b3ec:	9ac62063 	lsl	x3, x3, x6
    b3f0:	9ac62025 	lsl	x5, x1, x6
    b3f4:	9ac82447 	lsr	x7, x2, x8
    b3f8:	aa0300e7 	orr	x7, x7, x3
    b3fc:	9ac82423 	lsr	x3, x1, x8
    b400:	92407cec 	and	x12, x7, #0xffffffff
    b404:	d360fcea 	lsr	x10, x7, #32
    b408:	9ac82401 	lsr	x1, x0, x8
    b40c:	aa050021 	orr	x1, x1, x5
    b410:	9ac62042 	lsl	x2, x2, x6
    b414:	9ac62000 	lsl	x0, x0, x6
    b418:	9aca086b 	udiv	x11, x3, x10
    b41c:	9b0a8d63 	msub	x3, x11, x10, x3
    b420:	aa0b03e5 	mov	x5, x11
    b424:	9b0b7d89 	mul	x9, x12, x11
    b428:	93c18063 	extr	x3, x3, x1, #32
    b42c:	eb03013f 	cmp	x9, x3
    b430:	540000a9 	b.ls	b444 <__modti3+0x134>  // b.plast
    b434:	ab0300e3 	adds	x3, x7, x3
    b438:	d1000565 	sub	x5, x11, #0x1
    b43c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b440:	54001168 	b.hi	b66c <__modti3+0x35c>  // b.pmore
    b444:	cb090063 	sub	x3, x3, x9
    b448:	9aca086b 	udiv	x11, x3, x10
    b44c:	9b0a8d6a 	msub	x10, x11, x10, x3
    b450:	aa0b03e9 	mov	x9, x11
    b454:	9b0b7d8c 	mul	x12, x12, x11
    b458:	b3607d41 	bfi	x1, x10, #32, #32
    b45c:	eb01019f 	cmp	x12, x1
    b460:	540000a9 	b.ls	b474 <__modti3+0x164>  // b.plast
    b464:	ab0100e1 	adds	x1, x7, x1
    b468:	d1000569 	sub	x9, x11, #0x1
    b46c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b470:	54000f88 	b.hi	b660 <__modti3+0x350>  // b.pmore
    b474:	aa058123 	orr	x3, x9, x5, lsl #32
    b478:	92407c4b 	and	x11, x2, #0xffffffff
    b47c:	2a0903e9 	mov	w9, w9
    b480:	d360fc4a 	lsr	x10, x2, #32
    b484:	d360fc63 	lsr	x3, x3, #32
    b488:	cb0c0021 	sub	x1, x1, x12
    b48c:	aa0a03ec 	mov	x12, x10
    b490:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b494:	9b0b7d25 	mul	x5, x9, x11
    b498:	9b0b7c6b 	mul	x11, x3, x11
    b49c:	9b0a2d29 	madd	x9, x9, x10, x11
    b4a0:	92407caa 	and	x10, x5, #0xffffffff
    b4a4:	9b0c7c63 	mul	x3, x3, x12
    b4a8:	8b458125 	add	x5, x9, x5, lsr #32
    b4ac:	8b0d0069 	add	x9, x3, x13
    b4b0:	eb05017f 	cmp	x11, x5
    b4b4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b4b8:	8b058149 	add	x9, x10, x5, lsl #32
    b4bc:	8b458063 	add	x3, x3, x5, lsr #32
    b4c0:	eb03003f 	cmp	x1, x3
    b4c4:	54000063 	b.cc	b4d0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b4c8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b4cc:	54000082 	b.cs	b4dc <__modti3+0x1cc>  // b.hs, b.nlast
    b4d0:	eb020129 	subs	x9, x9, x2
    b4d4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b4d8:	cb070063 	sub	x3, x3, x7
    b4dc:	eb090000 	subs	x0, x0, x9
    b4e0:	da030021 	sbc	x1, x1, x3
    b4e4:	9ac62400 	lsr	x0, x0, x6
    b4e8:	9ac82028 	lsl	x8, x1, x8
    b4ec:	aa000100 	orr	x0, x8, x0
    b4f0:	9ac62421 	lsr	x1, x1, x6
    b4f4:	17ffffb4 	b	b3c4 <__modti3+0xb4>
    b4f8:	b5000062 	cbnz	x2, b504 <__modti3+0x1f4>
    b4fc:	d2800023 	mov	x3, #0x1                   	// #1
    b500:	9ac20862 	udiv	x2, x3, x2
    b504:	dac01048 	clz	x8, x2
    b508:	aa0803e5 	mov	x5, x8
    b50c:	b5000668 	cbnz	x8, b5d8 <__modti3+0x2c8>
    b510:	cb020020 	sub	x0, x1, x2
    b514:	d360fc49 	lsr	x9, x2, #32
    b518:	92407c4a 	and	x10, x2, #0xffffffff
    b51c:	9ac90801 	udiv	x1, x0, x9
    b520:	9b098020 	msub	x0, x1, x9, x0
    b524:	9b0a7c21 	mul	x1, x1, x10
    b528:	93c78000 	extr	x0, x0, x7, #32
    b52c:	eb00003f 	cmp	x1, x0
    b530:	540000a9 	b.ls	b544 <__modti3+0x234>  // b.plast
    b534:	ab000040 	adds	x0, x2, x0
    b538:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b53c:	8b020003 	add	x3, x0, x2
    b540:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b544:	cb010001 	sub	x1, x0, x1
    b548:	9ac90820 	udiv	x0, x1, x9
    b54c:	9b098403 	msub	x3, x0, x9, x1
    b550:	aa0703e1 	mov	x1, x7
    b554:	9b0a7c00 	mul	x0, x0, x10
    b558:	b3607c61 	bfi	x1, x3, #32, #32
    b55c:	eb01001f 	cmp	x0, x1
    b560:	540000a9 	b.ls	b574 <__modti3+0x264>  // b.plast
    b564:	ab010041 	adds	x1, x2, x1
    b568:	8b020022 	add	x2, x1, x2
    b56c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b570:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b574:	cb000020 	sub	x0, x1, x0
    b578:	17ffff91 	b	b3bc <__modti3+0xac>
    b57c:	eb0203e5 	negs	x5, x2
    b580:	aa0003e7 	mov	x7, x0
    b584:	da0303e8 	ngc	x8, x3
    b588:	aa0503e2 	mov	x2, x5
    b58c:	aa0803e3 	mov	x3, x8
    b590:	aa0103e6 	mov	x6, x1
    b594:	b4ffed48 	cbz	x8, b33c <__modti3+0x2c>
    b598:	eb01011f 	cmp	x8, x1
    b59c:	54fff148 	b.hi	b3c4 <__modti3+0xb4>  // b.pmore
    b5a0:	dac01109 	clz	x9, x8
    b5a4:	2a0903e6 	mov	w6, w9
    b5a8:	b5fff1c9 	cbnz	x9, b3e0 <__modti3+0xd0>
    b5ac:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b5b0:	54000068 	b.hi	b5bc <__modti3+0x2ac>  // b.pmore
    b5b4:	eb050007 	subs	x7, x0, x5
    b5b8:	da080021 	sbc	x1, x1, x8
    b5bc:	aa0703e0 	mov	x0, x7
    b5c0:	17ffff81 	b	b3c4 <__modti3+0xb4>
    b5c4:	ab000040 	adds	x0, x2, x0
    b5c8:	8b020002 	add	x2, x0, x2
    b5cc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b5d0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b5d4:	17ffff79 	b	b3b8 <__modti3+0xa8>
    b5d8:	9ac82042 	lsl	x2, x2, x8
    b5dc:	d2800803 	mov	x3, #0x40                  	// #64
    b5e0:	cb080063 	sub	x3, x3, x8
    b5e4:	d360fc49 	lsr	x9, x2, #32
    b5e8:	9ac82027 	lsl	x7, x1, x8
    b5ec:	92407c4a 	and	x10, x2, #0xffffffff
    b5f0:	9ac32426 	lsr	x6, x1, x3
    b5f4:	9ac32403 	lsr	x3, x0, x3
    b5f8:	aa070063 	orr	x3, x3, x7
    b5fc:	9ac908c1 	udiv	x1, x6, x9
    b600:	9ac82007 	lsl	x7, x0, x8
    b604:	9b099820 	msub	x0, x1, x9, x6
    b608:	9b017d41 	mul	x1, x10, x1
    b60c:	93c38000 	extr	x0, x0, x3, #32
    b610:	eb00003f 	cmp	x1, x0
    b614:	540000a9 	b.ls	b628 <__modti3+0x318>  // b.plast
    b618:	ab000040 	adds	x0, x2, x0
    b61c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b620:	8b020006 	add	x6, x0, x2
    b624:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b628:	cb010000 	sub	x0, x0, x1
    b62c:	9ac90801 	udiv	x1, x0, x9
    b630:	9b098026 	msub	x6, x1, x9, x0
    b634:	aa0303e0 	mov	x0, x3
    b638:	9b017d41 	mul	x1, x10, x1
    b63c:	b3607cc0 	bfi	x0, x6, #32, #32
    b640:	eb00003f 	cmp	x1, x0
    b644:	540000a9 	b.ls	b658 <__modti3+0x348>  // b.plast
    b648:	ab000040 	adds	x0, x2, x0
    b64c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b650:	8b020003 	add	x3, x0, x2
    b654:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b658:	cb010000 	sub	x0, x0, x1
    b65c:	17ffffb0 	b	b51c <__modti3+0x20c>
    b660:	d1000969 	sub	x9, x11, #0x2
    b664:	8b070021 	add	x1, x1, x7
    b668:	17ffff83 	b	b474 <__modti3+0x164>
    b66c:	d1000965 	sub	x5, x11, #0x2
    b670:	8b070063 	add	x3, x3, x7
    b674:	17ffff74 	b	b444 <__modti3+0x134>
    b678:	d503201f 	nop
    b67c:	d503201f 	nop

000000000000b680 <atexit>:
    b680:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b684:	b00000a2 	adrp	x2, 20000 <__data_start>
    b688:	d2800001 	mov	x1, #0x0                   	// #0
    b68c:	910003fd 	mov	x29, sp
    b690:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b694:	f9400442 	ldr	x2, [x2, #8]
    b698:	17ffdc1e 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b69c <_fini>:
    b69c:	d503201f 	nop
    b6a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b6a4:	910003fd 	mov	x29, sp
    b6a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b6ac:	d65f03c0 	ret
