
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-identical:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	d0000045 	adrp	x5, c000 <fwp_main_thread+0x120>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	913500a5 	add	x5, x5, #0xd40
    2aa0:	d0000044 	adrp	x4, c000 <fwp_main_thread+0x120>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91352084 	add	x4, x4, #0xd48
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940002ac 	bl	3580 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9100c261 	add	x1, x19, #0x30
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xf4c0>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9001c20 	str	x0, [x1, #56]
    2b2c:	940002f5 	bl	3700 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    2b34:	91048000 	add	x0, x0, #0x120
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	b0000042 	adrp	x2, b000 <f0+0x177c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	913b8042 	add	x2, x2, #0xee0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c273 	add	x19, x19, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9430a60 	ldr	w0, [x19, #776]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    2c7c:	9104c000 	add	x0, x0, #0x130
    2c80:	94000240 	bl	3580 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    2c8c:	91074000 	add	x0, x0, #0x1d0
    2c90:	9400023c 	bl	3580 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    2ca4:	9106a000 	add	x0, x0, #0x1a8
    2ca8:	94000236 	bl	3580 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    2cb0:	9105e000 	add	x0, x0, #0x178
    2cb4:	94000233 	bl	3580 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    2cbc:	91054000 	add	x0, x0, #0x150
    2cc0:	94000230 	bl	3580 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91008000 	add	x0, x0, #0x20
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91008021 	add	x1, x1, #0x20
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91008000 	add	x0, x0, #0x20
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91008021 	add	x1, x1, #0x20
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	f0000041 	adrp	x1, d000 <_IO_stdin_used+0x4c0>
    2eb4:	911fc021 	add	x1, x1, #0x7f0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    3050:	912d2000 	add	x0, x0, #0xb48
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x4c0>
    3118:	911f4021 	add	x1, x1, #0x7d0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    3144:	911502a1 	add	x1, x21, #0x540
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3158:	9124c0a5 	add	x5, x5, #0x930
    315c:	911502a1 	add	x1, x21, #0x540
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911502b7 	add	x23, x21, #0x540
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911502b5 	add	x21, x21, #0x540
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911502b5 	add	x21, x21, #0x540
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    32e8:	9124a0a5 	add	x5, x5, #0x928
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    33f0:	912d2000 	add	x0, x0, #0xb48
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	b0000041 	adrp	x1, c000 <fwp_main_thread+0x120>
    3530:	aa1303e0 	mov	x0, x19
    3534:	912d8021 	add	x1, x1, #0xb60
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	b0000041 	adrp	x1, c000 <fwp_main_thread+0x120>
    3544:	aa1303e0 	mov	x0, x19
    3548:	912da021 	add	x1, x1, #0xb68
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	b0000041 	adrp	x1, c000 <fwp_main_thread+0x120>
    3560:	912dc021 	add	x1, x1, #0xb70
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_trap>:
    3580:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3584:	d53bd041 	mrs	x1, tpidr_el0
    3588:	91400021 	add	x1, x1, #0x0, lsl #12
    358c:	91004021 	add	x1, x1, #0x10
    3590:	910003fd 	mov	x29, sp
    3594:	a90153f3 	stp	x19, x20, [sp, #16]
    3598:	aa0003f3 	mov	x19, x0
    359c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    35a0:	f947ea94 	ldr	x20, [x20, #4048]
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	f9400035 	ldr	x21, [x1]
    35ac:	97fffe91 	bl	2ff0 <fwp_flush>
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	b0000042 	adrp	x2, c000 <fwp_main_thread+0x120>
    35b8:	aa1303e3 	mov	x3, x19
    35bc:	912de042 	add	x2, x2, #0xb78
    35c0:	52800041 	mov	w1, #0x2                   	// #2
    35c4:	97fffccb 	bl	28f0 <__fprintf_chk@plt>
    35c8:	b40000b5 	cbz	x21, 35dc <fwp_trap+0x5c>
    35cc:	f9400280 	ldr	x0, [x20]
    35d0:	97fffcf8 	bl	29b0 <fflush@plt>
    35d4:	52800ca0 	mov	w0, #0x65                  	// #101
    35d8:	97fffd06 	bl	29f0 <_Exit@plt>
    35dc:	52800ca0 	mov	w0, #0x65                  	// #101
    35e0:	97fffc54 	bl	2730 <exit@plt>

00000000000035e4 <fwp_closure_drop_push>:
    35e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    35e8:	910003fd 	mov	x29, sp
    35ec:	a90153f3 	stp	x19, x20, [sp, #16]
    35f0:	aa0003f3 	mov	x19, x0
    35f4:	a9408014 	ldp	x20, x0, [x0, #8]
    35f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    35fc:	aa0103f5 	mov	x21, x1
    3600:	a90363f7 	stp	x23, x24, [sp, #48]
    3604:	eb00029f 	cmp	x20, x0
    3608:	54000160 	b.eq	3634 <fwp_closure_drop_push+0x50>  // b.none
    360c:	f9400276 	ldr	x22, [x19]
    3610:	d37df297 	lsl	x23, x20, #3
    3614:	91000694 	add	x20, x20, #0x1
    3618:	f9000674 	str	x20, [x19, #8]
    361c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3620:	f8376ad5 	str	x21, [x22, x23]
    3624:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3628:	a94363f7 	ldp	x23, x24, [sp, #48]
    362c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3630:	d65f03c0 	ret
    3634:	a9046bf9 	stp	x25, x26, [sp, #64]
    3638:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    363c:	eb00029f 	cmp	x20, x0
    3640:	54000568 	b.hi	36ec <fwp_closure_drop_push+0x108>  // b.pmore
    3644:	d37cee99 	lsl	x25, x20, #4
    3648:	d37ffa9a 	lsl	x26, x20, #1
    364c:	aa1903e0 	mov	x0, x25
    3650:	97fffc74 	bl	2820 <malloc@plt>
    3654:	aa0003f6 	mov	x22, x0
    3658:	b4000320 	cbz	x0, 36bc <fwp_closure_drop_push+0xd8>
    365c:	aa1303f8 	mov	x24, x19
    3660:	aa1903e3 	mov	x3, x25
    3664:	d37df297 	lsl	x23, x20, #3
    3668:	aa1703e2 	mov	x2, x23
    366c:	f8418719 	ldr	x25, [x24], #24
    3670:	aa1903e1 	mov	x1, x25
    3674:	97fffc57 	bl	27d0 <__memcpy_chk@plt>
    3678:	eb18033f 	cmp	x25, x24
    367c:	540000a0 	b.eq	3690 <fwp_closure_drop_push+0xac>  // b.none
    3680:	aa1903e0 	mov	x0, x25
    3684:	97fffcaf 	bl	2940 <free@plt>
    3688:	f9400674 	ldr	x20, [x19, #8]
    368c:	d37df297 	lsl	x23, x20, #3
    3690:	91000694 	add	x20, x20, #0x1
    3694:	f9000276 	str	x22, [x19]
    3698:	f9000a7a 	str	x26, [x19, #16]
    369c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    36a0:	f9000674 	str	x20, [x19, #8]
    36a4:	f8376ad5 	str	x21, [x22, x23]
    36a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    36b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    36b8:	d65f03c0 	ret
    36bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    36c0:	f947e863 	ldr	x3, [x3, #4048]
    36c4:	d2800262 	mov	x2, #0x13                  	// #19
    36c8:	d2800021 	mov	x1, #0x1                   	// #1
    36cc:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    36d0:	912d2000 	add	x0, x0, #0xb48
    36d4:	f9400063 	ldr	x3, [x3]
    36d8:	97fffcaa 	bl	2980 <fwrite@plt>
    36dc:	d2800000 	mov	x0, #0x0                   	// #0
    36e0:	97fffcb4 	bl	29b0 <fflush@plt>
    36e4:	52800cc0 	mov	w0, #0x66                  	// #102
    36e8:	97fffcc2 	bl	29f0 <_Exit@plt>
    36ec:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    36f0:	912e2000 	add	x0, x0, #0xb88
    36f4:	97ffffa3 	bl	3580 <fwp_trap>
    36f8:	d503201f 	nop
    36fc:	d503201f 	nop

0000000000003700 <fwp_now_ns>:
    3700:	d100c3ff 	sub	sp, sp, #0x30
    3704:	52800020 	mov	w0, #0x1                   	// #1
    3708:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    370c:	f947f442 	ldr	x2, [x2, #4072]
    3710:	910023e1 	add	x1, sp, #0x8
    3714:	a9027bfd 	stp	x29, x30, [sp, #32]
    3718:	910083fd 	add	x29, sp, #0x20
    371c:	f9400043 	ldr	x3, [x2]
    3720:	f9000fe3 	str	x3, [sp, #24]
    3724:	d2800003 	mov	x3, #0x0                   	// #0
    3728:	97fffc22 	bl	27b0 <clock_gettime@plt>
    372c:	350002c0 	cbnz	w0, 3784 <fwp_now_ns+0x84>
    3730:	a9408be1 	ldp	x1, x2, [sp, #8]
    3734:	d2994003 	mov	x3, #0xca00                	// #51712
    3738:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    373c:	9b037c20 	mul	x0, x1, x3
    3740:	9b437c21 	smulh	x1, x1, x3
    3744:	ab020000 	adds	x0, x0, x2
    3748:	937ffc42 	asr	x2, x2, #63
    374c:	9a020021 	adc	x1, x1, x2
    3750:	f100001f 	cmp	x0, #0x0
    3754:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3758:	b50001e1 	cbnz	x1, 3794 <fwp_now_ns+0x94>
    375c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3760:	f947f421 	ldr	x1, [x1, #4072]
    3764:	f9400fe3 	ldr	x3, [sp, #24]
    3768:	f9400022 	ldr	x2, [x1]
    376c:	eb020063 	subs	x3, x3, x2
    3770:	d2800002 	mov	x2, #0x0                   	// #0
    3774:	540000e1 	b.ne	3790 <fwp_now_ns+0x90>  // b.any
    3778:	a9427bfd 	ldp	x29, x30, [sp, #32]
    377c:	9100c3ff 	add	sp, sp, #0x30
    3780:	d65f03c0 	ret
    3784:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    3788:	912ea000 	add	x0, x0, #0xba8
    378c:	97ffff7d 	bl	3580 <fwp_trap>
    3790:	97fffc3c 	bl	2880 <__stack_chk_fail@plt>
    3794:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    3798:	912f2000 	add	x0, x0, #0xbc8
    379c:	97ffff79 	bl	3580 <fwp_trap>

00000000000037a0 <fwp_closure_drop.part.0>:
    37a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37a4:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x4c0>
    37a8:	910003fd 	mov	x29, sp
    37ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    37b0:	f947f463 	ldr	x3, [x3, #4072]
    37b4:	a90153f3 	stp	x19, x20, [sp, #16]
    37b8:	d10883ff 	sub	sp, sp, #0x220
    37bc:	910003e2 	mov	x2, sp
    37c0:	d53bd053 	mrs	x19, tpidr_el0
    37c4:	910063f4 	add	x20, sp, #0x18
    37c8:	3dc20020 	ldr	q0, [x1, #2048]
    37cc:	91400264 	add	x4, x19, #0x0, lsl #12
    37d0:	91004084 	add	x4, x4, #0x10
    37d4:	aa0003e1 	mov	x1, x0
    37d8:	aa0203e0 	mov	x0, x2
    37dc:	f9400062 	ldr	x2, [x3]
    37e0:	f9010fe2 	str	x2, [sp, #536]
    37e4:	d2800002 	mov	x2, #0x0                   	// #0
    37e8:	f90003f4 	str	x20, [sp]
    37ec:	f9000080 	str	x0, [x4]
    37f0:	3c8083e0 	stur	q0, [sp, #8]
    37f4:	97ffff7c 	bl	35e4 <fwp_closure_drop_push>
    37f8:	f94007e0 	ldr	x0, [sp, #8]
    37fc:	b4000280 	cbz	x0, 384c <fwp_closure_drop.part.0+0xac>
    3800:	f90123f5 	str	x21, [sp, #576]
    3804:	b00000f5 	adrp	x21, 20000 <__data_start>
    3808:	9100c2b5 	add	x21, x21, #0x30
    380c:	d503201f 	nop
    3810:	f94003e1 	ldr	x1, [sp]
    3814:	d1000400 	sub	x0, x0, #0x1
    3818:	f90007e0 	str	x0, [sp, #8]
    381c:	f9401ea2 	ldr	x2, [x21, #56]
    3820:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3824:	b9400001 	ldr	w1, [x0]
    3828:	8b011441 	add	x1, x2, x1, lsl #5
    382c:	f9400c21 	ldr	x1, [x1, #24]
    3830:	b4000321 	cbz	x1, 3894 <fwp_closure_drop.part.0+0xf4>
    3834:	f9400422 	ldr	x2, [x1, #8]
    3838:	52800001 	mov	w1, #0x0                   	// #0
    383c:	d63f0040 	blr	x2
    3840:	f94007e0 	ldr	x0, [sp, #8]
    3844:	b5fffe60 	cbnz	x0, 3810 <fwp_closure_drop.part.0+0x70>
    3848:	f94123f5 	ldr	x21, [sp, #576]
    384c:	91400273 	add	x19, x19, #0x0, lsl #12
    3850:	91004273 	add	x19, x19, #0x10
    3854:	f94003e0 	ldr	x0, [sp]
    3858:	f900027f 	str	xzr, [x19]
    385c:	eb14001f 	cmp	x0, x20
    3860:	54000040 	b.eq	3868 <fwp_closure_drop.part.0+0xc8>  // b.none
    3864:	97fffc37 	bl	2940 <free@plt>
    3868:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    386c:	f947f400 	ldr	x0, [x0, #4072]
    3870:	f9410fe2 	ldr	x2, [sp, #536]
    3874:	f9400001 	ldr	x1, [x0]
    3878:	eb010042 	subs	x2, x2, x1
    387c:	d2800001 	mov	x1, #0x0                   	// #0
    3880:	54000101 	b.ne	38a0 <fwp_closure_drop.part.0+0x100>  // b.any
    3884:	910883ff 	add	sp, sp, #0x220
    3888:	a94153f3 	ldp	x19, x20, [sp, #16]
    388c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3890:	d65f03c0 	ret
    3894:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    3898:	912fc000 	add	x0, x0, #0xbf0
    389c:	97ffff39 	bl	3580 <fwp_trap>
    38a0:	f90123f5 	str	x21, [sp, #576]
    38a4:	97fffbf7 	bl	2880 <__stack_chk_fail@plt>
    38a8:	d503201f 	nop
    38ac:	d503201f 	nop

00000000000038b0 <fwp_tape_of>:
    38b0:	92403c02 	and	x2, x0, #0xffff
    38b4:	b4000262 	cbz	x2, 3900 <fwp_tape_of+0x50>
    38b8:	9350fc01 	asr	x1, x0, #16
    38bc:	b00000e3 	adrp	x3, 20000 <__data_start>
    38c0:	d1000440 	sub	x0, x2, #0x1
    38c4:	9100c062 	add	x2, x3, #0x30
    38c8:	f9402042 	ldr	x2, [x2, #64]
    38cc:	eb00005f 	cmp	x2, x0
    38d0:	5400018d 	b.le	3900 <fwp_tape_of+0x50>
    38d4:	8b000402 	add	x2, x0, x0, lsl #1
    38d8:	f9401863 	ldr	x3, [x3, #48]
    38dc:	8b020802 	add	x2, x0, x2, lsl #2
    38e0:	d37df042 	lsl	x2, x2, #3
    38e4:	8b020060 	add	x0, x3, x2
    38e8:	b9400404 	ldr	w4, [x0, #4]
    38ec:	340000a4 	cbz	w4, 3900 <fwp_tape_of+0x50>
    38f0:	b8626862 	ldr	w2, [x3, x2]
    38f4:	6b01005f 	cmp	w2, w1
    38f8:	54000041 	b.ne	3900 <fwp_tape_of+0x50>  // b.any
    38fc:	d65f03c0 	ret
    3900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3904:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    3908:	91308000 	add	x0, x0, #0xc20
    390c:	910003fd 	mov	x29, sp
    3910:	97ffff1c 	bl	3580 <fwp_trap>

0000000000003914 <fwp_format_g.constprop.0>:
    3914:	d10483ff 	sub	sp, sp, #0x120
    3918:	b0000044 	adrp	x4, c000 <fwp_main_thread+0x120>
    391c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3920:	f947f442 	ldr	x2, [x2, #4072]
    3924:	9131c084 	add	x4, x4, #0xc70
    3928:	a90b7bfd 	stp	x29, x30, [sp, #176]
    392c:	9102c3fd 	add	x29, sp, #0xb0
    3930:	d2800803 	mov	x3, #0x40                  	// #64
    3934:	a90e63f7 	stp	x23, x24, [sp, #224]
    3938:	93407c38 	sxtw	x24, w1
    393c:	aa0303e1 	mov	x1, x3
    3940:	fd008be8 	str	d8, [sp, #272]
    3944:	1e604008 	fmov	d8, d0
    3948:	a90c53f3 	stp	x19, x20, [sp, #192]
    394c:	910083f4 	add	x20, sp, #0x20
    3950:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3954:	aa0003f5 	mov	x21, x0
    3958:	a91073fb 	stp	x27, x28, [sp, #256]
    395c:	5100071c 	sub	w28, w24, #0x1
    3960:	2a1c03e5 	mov	w5, w28
    3964:	f9400040 	ldr	x0, [x2]
    3968:	f90057e0 	str	x0, [sp, #168]
    396c:	d2800000 	mov	x0, #0x0                   	// #0
    3970:	52800042 	mov	w2, #0x2                   	// #2
    3974:	aa1403e0 	mov	x0, x20
    3978:	97fffb9e 	bl	27f0 <__snprintf_chk@plt>
    397c:	52800ca1 	mov	w1, #0x65                  	// #101
    3980:	aa1403e0 	mov	x0, x20
    3984:	97fffbf7 	bl	2960 <strchr@plt>
    3988:	aa0003f3 	mov	x19, x0
    398c:	52800142 	mov	w2, #0xa                   	// #10
    3990:	91000400 	add	x0, x0, #0x1
    3994:	d2800001 	mov	x1, #0x0                   	// #0
    3998:	97fffbe2 	bl	2920 <strtol@plt>
    399c:	aa0003f7 	mov	x23, x0
    39a0:	11001400 	add	w0, w0, #0x5
    39a4:	7100541f 	cmp	w0, #0x15
    39a8:	54000d88 	b.hi	3b58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    39ac:	4b170385 	sub	w5, w28, w23
    39b0:	710000bf 	cmp	w5, #0x0
    39b4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    39b8:	54000ba0 	b.eq	3b2c <fwp_format_g.constprop.0+0x218>  // b.none
    39bc:	394083e0 	ldrb	w0, [sp, #32]
    39c0:	cb180273 	sub	x19, x19, x24
    39c4:	91000673 	add	x19, x19, #0x1
    39c8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39cc:	7100b41f 	cmp	w0, #0x2d
    39d0:	9a941681 	cinc	x1, x20, eq	// eq = none
    39d4:	1a9f17e4 	cset	w4, eq	// eq = none
    39d8:	cb010266 	sub	x6, x19, x1
    39dc:	d10004da 	sub	x26, x6, #0x1
    39e0:	540018c0 	b.eq	3cf8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    39e4:	910183f9 	add	x25, sp, #0x60
    39e8:	d280091b 	mov	x27, #0x48                  	// #72
    39ec:	aa1903e7 	mov	x7, x25
    39f0:	91000423 	add	x3, x1, #0x1
    39f4:	91011cc6 	add	x6, x6, #0x47
    39f8:	910004f6 	add	x22, x7, #0x1
    39fc:	37f81017 	tbnz	w23, #31, 3bfc <fwp_format_g.constprop.0+0x2e8>
    3a00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3a04:	93407ef7 	sxtw	x23, w23
    3a08:	390000e4 	strb	w4, [x7]
    3a0c:	aa1303e1 	mov	x1, x19
    3a10:	aa1703e2 	mov	x2, x23
    3a14:	aa1603e0 	mov	x0, x22
    3a18:	b9000be5 	str	w5, [sp, #8]
    3a1c:	cb170374 	sub	x20, x27, x23
    3a20:	a9011be3 	stp	x3, x6, [sp, #16]
    3a24:	97fffb2b 	bl	26d0 <memcpy@plt>
    3a28:	d1000694 	sub	x20, x20, #0x1
    3a2c:	f9400be3 	ldr	x3, [sp, #16]
    3a30:	8b1702d6 	add	x22, x22, x23
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	aa1a03e2 	mov	x2, x26
    3a3c:	aa0303e1 	mov	x1, x3
    3a40:	aa1403e3 	mov	x3, x20
    3a44:	97fffb63 	bl	27d0 <__memcpy_chk@plt>
    3a48:	8b1a02d6 	add	x22, x22, x26
    3a4c:	f9400fe6 	ldr	x6, [sp, #24]
    3a50:	d2800900 	mov	x0, #0x48                  	// #72
    3a54:	b9400be5 	ldr	w5, [sp, #8]
    3a58:	8b170261 	add	x1, x19, x23
    3a5c:	cb1400c3 	sub	x3, x6, x20
    3a60:	cb060294 	sub	x20, x20, x6
    3a64:	f101207f 	cmp	x3, #0x48
    3a68:	93407cb8 	sxtw	x24, w5
    3a6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3a70:	aa1803e2 	mov	x2, x24
    3a74:	8b1802d3 	add	x19, x22, x24
    3a78:	8b140063 	add	x3, x3, x20
    3a7c:	aa1603e0 	mov	x0, x22
    3a80:	97fffb54 	bl	27d0 <__memcpy_chk@plt>
    3a84:	cb190273 	sub	x19, x19, x25
    3a88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a8c:	eb00027f 	cmp	x19, x0
    3a90:	aa1903e1 	mov	x1, x25
    3a94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a98:	aa1503e0 	mov	x0, x21
    3a9c:	aa1303e2 	mov	x2, x19
    3aa0:	97fffb0c 	bl	26d0 <memcpy@plt>
    3aa4:	38336abf 	strb	wzr, [x21, x19]
    3aa8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aac:	aa1503e0 	mov	x0, x21
    3ab0:	97fffb18 	bl	2710 <strlen@plt>
    3ab4:	aa0003f3 	mov	x19, x0
    3ab8:	528005c1 	mov	w1, #0x2e                  	// #46
    3abc:	aa1503e0 	mov	x0, x21
    3ac0:	97fffba8 	bl	2960 <strchr@plt>
    3ac4:	b4000160 	cbz	x0, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3ac8:	b4000153 	cbz	x19, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3acc:	d503201f 	nop
    3ad0:	aa1303e1 	mov	x1, x19
    3ad4:	d1000673 	sub	x19, x19, #0x1
    3ad8:	38736aa0 	ldrb	w0, [x21, x19]
    3adc:	7100c01f 	cmp	w0, #0x30
    3ae0:	54001001 	b.ne	3ce0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ae4:	38336abf 	strb	wzr, [x21, x19]
    3ae8:	b5ffff53 	cbnz	x19, 3ad0 <fwp_format_g.constprop.0+0x1bc>
    3aec:	d503201f 	nop
    3af0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3af4:	f947f400 	ldr	x0, [x0, #4072]
    3af8:	f94057e2 	ldr	x2, [sp, #168]
    3afc:	f9400001 	ldr	x1, [x0]
    3b00:	eb010042 	subs	x2, x2, x1
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	54001061 	b.ne	3d14 <fwp_format_g.constprop.0+0x400>  // b.any
    3b0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3b10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3b14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3b18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3b1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3b20:	fd408be8 	ldr	d8, [sp, #272]
    3b24:	910483ff 	add	sp, sp, #0x120
    3b28:	d65f03c0 	ret
    3b2c:	1e604100 	fmov	d0, d8
    3b30:	710000bf 	cmp	w5, #0x0
    3b34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	b0000044 	adrp	x4, c000 <fwp_main_thread+0x120>
    3b40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b44:	91322084 	add	x4, x4, #0xc88
    3b48:	52800042 	mov	w2, #0x2                   	// #2
    3b4c:	d2803201 	mov	x1, #0x190                 	// #400
    3b50:	97fffb28 	bl	27f0 <__snprintf_chk@plt>
    3b54:	17ffffd6 	b	3aac <fwp_format_g.constprop.0+0x198>
    3b58:	cb140273 	sub	x19, x19, x20
    3b5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b60:	910183f9 	add	x25, sp, #0x60
    3b64:	aa1303e2 	mov	x2, x19
    3b68:	aa1403e1 	mov	x1, x20
    3b6c:	aa1903e0 	mov	x0, x25
    3b70:	d2800803 	mov	x3, #0x40                  	// #64
    3b74:	97fffb17 	bl	27d0 <__memcpy_chk@plt>
    3b78:	38336b3f 	strb	wzr, [x25, x19]
    3b7c:	aa1903e0 	mov	x0, x25
    3b80:	528005c1 	mov	w1, #0x2e                  	// #46
    3b84:	97fffb77 	bl	2960 <strchr@plt>
    3b88:	b40001c0 	cbz	x0, 3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b8c:	b50000b3 	cbnz	x19, 3ba0 <fwp_format_g.constprop.0+0x28c>
    3b90:	1400000c 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b94:	381ff01f 	sturb	wzr, [x0, #-1]
    3b98:	f1000673 	subs	x19, x19, #0x1
    3b9c:	54000120 	b.eq	3bc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ba0:	8b130320 	add	x0, x25, x19
    3ba4:	385ff001 	ldurb	w1, [x0, #-1]
    3ba8:	7100c03f 	cmp	w1, #0x30
    3bac:	54ffff40 	b.eq	3b94 <fwp_format_g.constprop.0+0x280>  // b.none
    3bb0:	d1000673 	sub	x19, x19, #0x1
    3bb4:	38736b20 	ldrb	w0, [x25, x19]
    3bb8:	7100b81f 	cmp	w0, #0x2e
    3bbc:	54000a80 	b.eq	3d0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3bc0:	710002ff 	cmp	w23, #0x0
    3bc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3bc8:	aa1903e5 	mov	x5, x25
    3bcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3bd0:	aa1503e0 	mov	x0, x21
    3bd4:	52800566 	mov	w6, #0x2b                  	// #43
    3bd8:	b0000044 	adrp	x4, c000 <fwp_main_thread+0x120>
    3bdc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3be0:	9131e084 	add	x4, x4, #0xc78
    3be4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3be8:	52800042 	mov	w2, #0x2                   	// #2
    3bec:	d2803201 	mov	x1, #0x190                 	// #400
    3bf0:	97fffb00 	bl	27f0 <__snprintf_chk@plt>
    3bf4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3bf8:	17ffffbe 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3bfc:	52800605 	mov	w5, #0x30                  	// #48
    3c00:	390000e5 	strb	w5, [x7]
    3c04:	d100077b 	sub	x27, x27, #0x1
    3c08:	aa0303e1 	mov	x1, x3
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	aa1b03e3 	mov	x3, x27
    3c14:	aa1a03e2 	mov	x2, x26
    3c18:	f90007e6 	str	x6, [sp, #8]
    3c1c:	b90013e4 	str	w4, [sp, #16]
    3c20:	8b1a02d6 	add	x22, x22, x26
    3c24:	b9001be5 	str	w5, [sp, #24]
    3c28:	97fffaea 	bl	27d0 <__memcpy_chk@plt>
    3c2c:	f94007e6 	ldr	x6, [sp, #8]
    3c30:	2a3703e7 	mvn	w7, w23
    3c34:	b94013e4 	ldr	w4, [sp, #16]
    3c38:	cb1b00c1 	sub	x1, x6, x27
    3c3c:	cb06037b 	sub	x27, x27, x6
    3c40:	f101203f 	cmp	x1, #0x48
    3c44:	d2800906 	mov	x6, #0x48                  	// #72
    3c48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3c4c:	8b1b0023 	add	x3, x1, x27
    3c50:	310006ff 	cmn	w23, #0x1
    3c54:	54000220 	b.eq	3c98 <fwp_format_g.constprop.0+0x384>  // b.none
    3c58:	b9401be5 	ldr	w5, [sp, #24]
    3c5c:	d2800001 	mov	x1, #0x0                   	// #0
    3c60:	f101207f 	cmp	x3, #0x48
    3c64:	d1000462 	sub	x2, x3, #0x1
    3c68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3c6c:	38216ac5 	strb	w5, [x22, x1]
    3c70:	cb030003 	sub	x3, x0, x3
    3c74:	91000421 	add	x1, x1, #0x1
    3c78:	91000463 	add	x3, x3, #0x1
    3c7c:	eb00007f 	cmp	x3, x0
    3c80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c84:	cb000063 	sub	x3, x3, x0
    3c88:	8b020063 	add	x3, x3, x2
    3c8c:	6b0100ff 	cmp	w7, w1
    3c90:	54fffe8c 	b.gt	3c60 <fwp_format_g.constprop.0+0x34c>
    3c94:	8b2742d6 	add	x22, x22, w7, uxtw
    3c98:	f101207f 	cmp	x3, #0x48
    3c9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ca0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ca4:	aa1603e0 	mov	x0, x22
    3ca8:	cb0300a1 	sub	x1, x5, x3
    3cac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3cb0:	91000421 	add	x1, x1, #0x1
    3cb4:	d1000463 	sub	x3, x3, #0x1
    3cb8:	eb05003f 	cmp	x1, x5
    3cbc:	38001402 	strb	w2, [x0], #1
    3cc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3cc4:	93407f82 	sxtw	x2, w28
    3cc8:	cb050025 	sub	x5, x1, x5
    3ccc:	aa1303e1 	mov	x1, x19
    3cd0:	8b0300a3 	add	x3, x5, x3
    3cd4:	8b1802d3 	add	x19, x22, x24
    3cd8:	97fffabe 	bl	27d0 <__memcpy_chk@plt>
    3cdc:	17ffff6a 	b	3a84 <fwp_format_g.constprop.0+0x170>
    3ce0:	d1000421 	sub	x1, x1, #0x1
    3ce4:	38616aa0 	ldrb	w0, [x21, x1]
    3ce8:	7100b81f 	cmp	w0, #0x2e
    3cec:	54fff021 	b.ne	3af0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3cf0:	38216abf 	strb	wzr, [x21, x1]
    3cf4:	17ffff7f 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3cf8:	910187e7 	add	x7, sp, #0x61
    3cfc:	910183f9 	add	x25, sp, #0x60
    3d00:	d28008fb 	mov	x27, #0x47                  	// #71
    3d04:	390183e0 	strb	w0, [sp, #96]
    3d08:	17ffff3a 	b	39f0 <fwp_format_g.constprop.0+0xdc>
    3d0c:	38336b3f 	strb	wzr, [x25, x19]
    3d10:	17ffffac 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3d14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d18:	97fffada 	bl	2880 <__stack_chk_fail@plt>
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_heap_report>:
    3d20:	d105c3ff 	sub	sp, sp, #0x170
    3d24:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    3d28:	91150042 	add	x2, x2, #0x540
    3d2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3d30:	f947e821 	ldr	x1, [x1, #4048]
    3d34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3d38:	910443fd 	add	x29, sp, #0x110
    3d3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d40:	f947f400 	ldr	x0, [x0, #4072]
    3d44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3d48:	a91463f7 	stp	x23, x24, [sp, #320]
    3d4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3d50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3d54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3d58:	fd4a2049 	ldr	d9, [x2, #5184]
    3d5c:	f9400036 	ldr	x22, [x1]
    3d60:	f9400001 	ldr	x1, [x0]
    3d64:	f90087e1 	str	x1, [sp, #264]
    3d68:	d2800001 	mov	x1, #0x0                   	// #0
    3d6c:	f949e459 	ldr	x25, [x2, #5064]
    3d70:	b0000041 	adrp	x1, c000 <fwp_main_thread+0x120>
    3d74:	f94a1057 	ldr	x23, [x2, #5152]
    3d78:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    3d7c:	f94a1458 	ldr	x24, [x2, #5160]
    3d80:	91324021 	add	x1, x1, #0xc90
    3d84:	91326000 	add	x0, x0, #0xc98
    3d88:	97fffaa2 	bl	2810 <fopen@plt>
    3d8c:	b4000740 	cbz	x0, 3e74 <fwp_heap_report+0x154>
    3d90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d94:	a91253f3 	stp	x19, x20, [sp, #288]
    3d98:	aa0003f4 	mov	x20, x0
    3d9c:	910023f3 	add	x19, sp, #0x8
    3da0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3da4:	72aae915 	movk	w21, #0x5748, lsl #16
    3da8:	aa1403e2 	mov	x2, x20
    3dac:	aa1303e0 	mov	x0, x19
    3db0:	52802001 	mov	w1, #0x100                 	// #256
    3db4:	97fffb23 	bl	2a40 <fgets@plt>
    3db8:	b4000280 	cbz	x0, 3e08 <fwp_heap_report+0xe8>
    3dbc:	b9400261 	ldr	w1, [x19]
    3dc0:	6b15003f 	cmp	w1, w21
    3dc4:	54ffff21 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dc8:	39401260 	ldrb	w0, [x19, #4]
    3dcc:	7101341f 	cmp	w0, #0x4d
    3dd0:	54fffec1 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dd4:	394037e0 	ldrb	w0, [sp, #13]
    3dd8:	7100e81f 	cmp	w0, #0x3a
    3ddc:	54fffe61 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3de0:	52800142 	mov	w2, #0xa                   	// #10
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	91003be0 	add	x0, sp, #0xe
    3dec:	97fffacd 	bl	2920 <strtol@plt>
    3df0:	aa1403e2 	mov	x2, x20
    3df4:	aa0003fa 	mov	x26, x0
    3df8:	52802001 	mov	w1, #0x100                 	// #256
    3dfc:	aa1303e0 	mov	x0, x19
    3e00:	97fffb10 	bl	2a40 <fgets@plt>
    3e04:	b5fffdc0 	cbnz	x0, 3dbc <fwp_heap_report+0x9c>
    3e08:	aa1403e0 	mov	x0, x20
    3e0c:	97fffa7d 	bl	2800 <fclose@plt>
    3e10:	a95253f3 	ldp	x19, x20, [sp, #288]
    3e14:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3e18:	f947f400 	ldr	x0, [x0, #4072]
    3e1c:	f94087e2 	ldr	x2, [sp, #264]
    3e20:	f9400001 	ldr	x1, [x0]
    3e24:	eb010042 	subs	x2, x2, x1
    3e28:	d2800001 	mov	x1, #0x0                   	// #0
    3e2c:	54000281 	b.ne	3e7c <fwp_heap_report+0x15c>  // b.any
    3e30:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3e34:	aa1a03e6 	mov	x6, x26
    3e38:	aa1903e5 	mov	x5, x25
    3e3c:	aa1803e4 	mov	x4, x24
    3e40:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3e44:	aa1703e3 	mov	x3, x23
    3e48:	a95463f7 	ldp	x23, x24, [sp, #320]
    3e4c:	aa1603e0 	mov	x0, x22
    3e50:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3e54:	1e604121 	fmov	d1, d9
    3e58:	1e604100 	fmov	d0, d8
    3e5c:	b0000042 	adrp	x2, c000 <fwp_main_thread+0x120>
    3e60:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3e64:	9132e042 	add	x2, x2, #0xcb8
    3e68:	9105c3ff 	add	sp, sp, #0x170
    3e6c:	52800041 	mov	w1, #0x2                   	// #2
    3e70:	17fffaa0 	b	28f0 <__fprintf_chk@plt>
    3e74:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3e78:	17ffffe7 	b	3e14 <fwp_heap_report+0xf4>
    3e7c:	a91253f3 	stp	x19, x20, [sp, #288]
    3e80:	97fffa80 	bl	2880 <__stack_chk_fail@plt>

0000000000003e84 <fwp_heap_init>:
    3e84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e88:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3e8c:	91110061 	add	x1, x3, #0x440
    3e90:	910003fd 	mov	x29, sp
    3e94:	a90153f3 	stp	x19, x20, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3e9c:	91150262 	add	x2, x19, #0x540
    3ea0:	a9025bf5 	stp	x21, x22, [sp, #32]
    3ea4:	52800024 	mov	w4, #0x1                   	// #1
    3ea8:	52800200 	mov	w0, #0x10                  	// #16
    3eac:	b913a444 	str	w4, [x2, #5028]
    3eb0:	b8004420 	str	w0, [x1], #4
    3eb4:	11004000 	add	w0, w0, #0x10
    3eb8:	7104401f 	cmp	w0, #0x110
    3ebc:	54ffffa1 	b.ne	3eb0 <fwp_heap_init+0x2c>  // b.any
    3ec0:	d0000042 	adrp	x2, d000 <_IO_stdin_used+0x4c0>
    3ec4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ec8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3ecc:	91120021 	add	x1, x1, #0x480
    3ed0:	3dc20443 	ldr	q3, [x2, #2064]
    3ed4:	d2800000 	mov	x0, #0x0                   	// #0
    3ed8:	4e040401 	dup	v1.4s, v0.s[0]
    3edc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ee0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ee4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ee8:	3ca06821 	str	q1, [x1, x0]
    3eec:	91004000 	add	x0, x0, #0x10
    3ef0:	f101801f 	cmp	x0, #0x60
    3ef4:	54ffff21 	b.ne	3ed8 <fwp_heap_init+0x54>  // b.any
    3ef8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3efc:	91110063 	add	x3, x3, #0x440
    3f00:	91138084 	add	x4, x4, #0x4e0
    3f04:	91150266 	add	x6, x19, #0x540
    3f08:	d2800002 	mov	x2, #0x0                   	// #0
    3f0c:	d2800000 	mov	x0, #0x0                   	// #0
    3f10:	d2880205 	mov	x5, #0x4010                	// #16400
    3f14:	d503201f 	nop
    3f18:	910f0001 	add	x1, x0, #0x3c0
    3f1c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3f20:	eb02003f 	cmp	x1, x2
    3f24:	540000a2 	b.cs	3f38 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3f28:	91000400 	add	x0, x0, #0x1
    3f2c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3f30:	eb02003f 	cmp	x1, x2
    3f34:	54ffffa3 	b.cc	3f28 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3f38:	91004042 	add	x2, x2, #0x10
    3f3c:	38001480 	strb	w0, [x4], #1
    3f40:	eb05005f 	cmp	x2, x5
    3f44:	54fffea1 	b.ne	3f18 <fwp_heap_init+0x94>  // b.any
    3f48:	528000b5 	mov	w21, #0x5                   	// #5
    3f4c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3f50:	14000004 	b	3f60 <fwp_heap_init+0xdc>
    3f54:	d342fe94 	lsr	x20, x20, #2
    3f58:	710006b5 	subs	w21, w21, #0x1
    3f5c:	54000720 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3f60:	91404296 	add	x22, x20, #0x10, lsl #12
    3f64:	d2800005 	mov	x5, #0x0                   	// #0
    3f68:	aa1603e1 	mov	x1, x22
    3f6c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f70:	52880443 	mov	w3, #0x4022                	// #16418
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	d2800000 	mov	x0, #0x0                   	// #0
    3f7c:	97fffa65 	bl	2910 <mmap@plt>
    3f80:	aa0003e6 	mov	x6, x0
    3f84:	b100041f 	cmn	x0, #0x1
    3f88:	54fffe60 	b.eq	3f54 <fwp_heap_init+0xd0>  // b.none
    3f8c:	b40005a0 	cbz	x0, 4040 <fwp_heap_init+0x1bc>
    3f90:	d350fe94 	lsr	x20, x20, #16
    3f94:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f98:	8b0000c7 	add	x7, x6, x0
    3f9c:	91150275 	add	x21, x19, #0x540
    3fa0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3fa4:	8b140a81 	add	x1, x20, x20, lsl #2
    3fa8:	d2800005 	mov	x5, #0x0                   	// #0
    3fac:	12800004 	mov	w4, #0xffffffff            	// #-1
    3fb0:	d37df021 	lsl	x1, x1, #3
    3fb4:	52880443 	mov	w3, #0x4022                	// #16418
    3fb8:	52800002 	mov	w2, #0x0                   	// #0
    3fbc:	d2800000 	mov	x0, #0x0                   	// #0
    3fc0:	f909daa7 	str	x7, [x21, #5040]
    3fc4:	f909dea6 	str	x6, [x21, #5048]
    3fc8:	f909e2b6 	str	x22, [x21, #5056]
    3fcc:	f909eab4 	str	x20, [x21, #5072]
    3fd0:	f90a02a1 	str	x1, [x21, #5120]
    3fd4:	97fffa4f 	bl	2910 <mmap@plt>
    3fd8:	aa0003e1 	mov	x1, x0
    3fdc:	b100041f 	cmn	x0, #0x1
    3fe0:	54000300 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3fe4:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    3fe8:	9135a000 	add	x0, x0, #0xd68
    3fec:	f909fea1 	str	x1, [x21, #5112]
    3ff0:	97fffa88 	bl	2a10 <getenv@plt>
    3ff4:	52800002 	mov	w2, #0x0                   	// #0
    3ff8:	aa0003e1 	mov	x1, x0
    3ffc:	b40000e0 	cbz	x0, 4018 <fwp_heap_init+0x194>
    4000:	39400000 	ldrb	w0, [x0]
    4004:	340000a0 	cbz	w0, 4018 <fwp_heap_init+0x194>
    4008:	7100c000 	subs	w0, w0, #0x30
    400c:	54000120 	b.eq	4030 <fwp_heap_init+0x1ac>  // b.none
    4010:	7100001f 	cmp	w0, #0x0
    4014:	1a9f07e2 	cset	w2, ne	// ne = any
    4018:	91150273 	add	x19, x19, #0x540
    401c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4020:	b913aa62 	str	w2, [x19, #5032]
    4024:	a94153f3 	ldp	x19, x20, [sp, #16]
    4028:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402c:	d65f03c0 	ret
    4030:	39400420 	ldrb	w0, [x1, #1]
    4034:	7100001f 	cmp	w0, #0x0
    4038:	1a9f07e2 	cset	w2, ne	// ne = any
    403c:	17fffff7 	b	4018 <fwp_heap_init+0x194>
    4040:	97fffbfc 	bl	3030 <fwp_heap_oom>

0000000000004044 <fwp_wake_io>:
    4044:	900000e9 	adrp	x9, 20000 <__data_start>
    4048:	9100c122 	add	x2, x9, #0x30
    404c:	f9400001 	ldr	x1, [x0]
    4050:	5280000a 	mov	w10, #0x0                   	// #0
    4054:	f9401446 	ldr	x6, [x2, #40]
    4058:	52800008 	mov	w8, #0x0                   	// #0
    405c:	4f000400 	movi	v0.4s, #0x0
    4060:	52800027 	mov	w7, #0x1                   	// #1
    4064:	aa0103e2 	mov	x2, x1
    4068:	b4000321 	cbz	x1, 40cc <fwp_wake_io+0x88>
    406c:	f9408c25 	ldr	x5, [x1, #280]
    4070:	39015c27 	strb	w7, [x1, #87]
    4074:	b4000165 	cbz	x5, 40a0 <fwp_wake_io+0x5c>
    4078:	a9520c24 	ldp	x4, x3, [x1, #288]
    407c:	b4000364 	cbz	x4, 40e8 <fwp_wake_io+0xa4>
    4080:	f9009483 	str	x3, [x4, #296]
    4084:	f9409423 	ldr	x3, [x1, #296]
    4088:	b4000043 	cbz	x3, 4090 <fwp_wake_io+0x4c>
    408c:	f9009064 	str	x4, [x3, #288]
    4090:	91080023 	add	x3, x1, #0x200
    4094:	f900943f 	str	xzr, [x1, #296]
    4098:	3c918060 	stur	q0, [x3, #-232]
    409c:	f9400001 	ldr	x1, [x0]
    40a0:	f9402843 	ldr	x3, [x2, #80]
    40a4:	f2001c7f 	tst	x3, #0xff000000ff
    40a8:	54fffde1 	b.ne	4064 <fwp_wake_io+0x20>  // b.any
    40ac:	39015047 	strb	w7, [x2, #84]
    40b0:	f900805f 	str	xzr, [x2, #256]
    40b4:	b40001e6 	cbz	x6, 40f0 <fwp_wake_io+0xac>
    40b8:	f90080c2 	str	x2, [x6, #256]
    40bc:	aa0203e6 	mov	x6, x2
    40c0:	52800028 	mov	w8, #0x1                   	// #1
    40c4:	aa0103e2 	mov	x2, x1
    40c8:	b5fffd21 	cbnz	x1, 406c <fwp_wake_io+0x28>
    40cc:	3400006a 	cbz	w10, 40d8 <fwp_wake_io+0x94>
    40d0:	9100c120 	add	x0, x9, #0x30
    40d4:	f900180b 	str	x11, [x0, #48]
    40d8:	34000068 	cbz	w8, 40e4 <fwp_wake_io+0xa0>
    40dc:	9100c129 	add	x9, x9, #0x30
    40e0:	f9001526 	str	x6, [x9, #40]
    40e4:	d65f03c0 	ret
    40e8:	f90000a3 	str	x3, [x5]
    40ec:	17ffffe7 	b	4088 <fwp_wake_io+0x44>
    40f0:	aa0203eb 	mov	x11, x2
    40f4:	5280002a 	mov	w10, #0x1                   	// #1
    40f8:	17fffff1 	b	40bc <fwp_wake_io+0x78>
    40fc:	d503201f 	nop

0000000000004100 <fwp_tape_buffers_release>:
    4100:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4104:	910003fd 	mov	x29, sp
    4108:	a90153f3 	stp	x19, x20, [sp, #16]
    410c:	aa0003f3 	mov	x19, x0
    4110:	f9401400 	ldr	x0, [x0, #40]
    4114:	b7f80760 	tbnz	x0, #63, 4200 <fwp_tape_buffers_release+0x100>
    4118:	f9401a61 	ldr	x1, [x19, #48]
    411c:	b7f80301 	tbnz	x1, #63, 417c <fwp_tape_buffers_release+0x7c>
    4120:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4124:	eb02001f 	cmp	x0, x2
    4128:	540002a8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    412c:	8b000400 	add	x0, x0, x0, lsl #1
    4130:	d2a00102 	mov	x2, #0x80000               	// #524288
    4134:	d37df000 	lsl	x0, x0, #3
    4138:	cb000042 	sub	x2, x2, x0
    413c:	eb420c3f 	cmp	x1, x2, lsr #3
    4140:	540001e8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4144:	8b010c14 	add	x20, x0, x1, lsl #3
    4148:	90000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    414c:	9135e000 	add	x0, x0, #0xd78
    4150:	97fffa30 	bl	2a10 <getenv@plt>
    4154:	b4000240 	cbz	x0, 419c <fwp_tape_buffers_release+0x9c>
    4158:	39400001 	ldrb	w1, [x0]
    415c:	7100c03f 	cmp	w1, #0x30
    4160:	540001e1 	b.ne	419c <fwp_tape_buffers_release+0x9c>  // b.any
    4164:	39400400 	ldrb	w0, [x0, #1]
    4168:	350001a0 	cbnz	w0, 419c <fwp_tape_buffers_release+0x9c>
    416c:	aa1303e0 	mov	x0, x19
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4178:	17fffc62 	b	3300 <fwp_tape_buffers_dispose>
    417c:	90000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    4180:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4184:	9135e000 	add	x0, x0, #0xd78
    4188:	97fffa22 	bl	2a10 <getenv@plt>
    418c:	b4ffff00 	cbz	x0, 416c <fwp_tape_buffers_release+0x6c>
    4190:	39400001 	ldrb	w1, [x0]
    4194:	7100c03f 	cmp	w1, #0x30
    4198:	54fffe60 	b.eq	4164 <fwp_tape_buffers_release+0x64>  // b.none
    419c:	d1000681 	sub	x1, x20, #0x1
    41a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41a4:	eb00003f 	cmp	x1, x0
    41a8:	54fffe28 	b.hi	416c <fwp_tape_buffers_release+0x6c>  // b.pmore
    41ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    41b0:	900000f6 	adrp	x22, 20000 <__data_start>
    41b4:	9100c2d6 	add	x22, x22, #0x30
    41b8:	910122d5 	add	x21, x22, #0x48
    41bc:	aa1503e0 	mov	x0, x21
    41c0:	97fffc50 	bl	3300 <fwp_tape_buffers_dispose>
    41c4:	ad400a61 	ldp	q1, q2, [x19]
    41c8:	f90042d4 	str	x20, [x22, #128]
    41cc:	4f000400 	movi	v0.4s, #0x0
    41d0:	ad000aa1 	stp	q1, q2, [x21]
    41d4:	3dc00a61 	ldr	q1, [x19, #32]
    41d8:	3d800aa1 	str	q1, [x21, #32]
    41dc:	f9401a60 	ldr	x0, [x19, #48]
    41e0:	f9001aa0 	str	x0, [x21, #48]
    41e4:	f9001a7f 	str	xzr, [x19, #48]
    41e8:	ad000260 	stp	q0, q0, [x19]
    41ec:	3d800a60 	str	q0, [x19, #32]
    41f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41fc:	d65f03c0 	ret
    4200:	90000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    4204:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4208:	9135e000 	add	x0, x0, #0xd78
    420c:	97fffa01 	bl	2a10 <getenv@plt>
    4210:	b5fffa40 	cbnz	x0, 4158 <fwp_tape_buffers_release+0x58>
    4214:	17ffffd6 	b	416c <fwp_tape_buffers_release+0x6c>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_poll_events>:
    4220:	d10103ff 	sub	sp, sp, #0x40
    4224:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4228:	f947f400 	ldr	x0, [x0, #4072]
    422c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4230:	910083fd 	add	x29, sp, #0x20
    4234:	a90353f3 	stp	x19, x20, [sp, #48]
    4238:	900000f4 	adrp	x20, 20000 <__data_start>
    423c:	f9400001 	ldr	x1, [x0]
    4240:	f9000fe1 	str	x1, [sp, #24]
    4244:	d2800001 	mov	x1, #0x0                   	// #0
    4248:	97fffd2e 	bl	3700 <fwp_now_ns>
    424c:	9100c281 	add	x1, x20, #0x30
    4250:	f9404433 	ldr	x19, [x1, #136]
    4254:	b4000e93 	cbz	x19, 4424 <fwp_poll_events+0x204>
    4258:	aa1303e1 	mov	x1, x19
    425c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4260:	14000005 	b	4274 <fwp_poll_events+0x54>
    4264:	f9408821 	ldr	x1, [x1, #272]
    4268:	eb03005f 	cmp	x2, x3
    426c:	9a83d042 	csel	x2, x2, x3, le
    4270:	b40000c1 	cbz	x1, 4288 <fwp_poll_events+0x68>
    4274:	f9403423 	ldr	x3, [x1, #104]
    4278:	b6ffff62 	tbz	x2, #63, 4264 <fwp_poll_events+0x44>
    427c:	f9408821 	ldr	x1, [x1, #272]
    4280:	aa0303e2 	mov	x2, x3
    4284:	b5ffff81 	cbnz	x1, 4274 <fwp_poll_events+0x54>
    4288:	b7f80ce2 	tbnz	x2, #63, 4424 <fwp_poll_events+0x204>
    428c:	cb000042 	sub	x2, x2, x0
    4290:	f100005f 	cmp	x2, #0x0
    4294:	540005cd 	b.le	434c <fwp_poll_events+0x12c>
    4298:	d2869b60 	mov	x0, #0x34db                	// #13531
    429c:	d2884801 	mov	x1, #0x4240                	// #16960
    42a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    42a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    42a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    42ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    42b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    42b4:	9b407c40 	smulh	x0, x2, x0
    42b8:	9352fc00 	asr	x0, x0, #18
    42bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    42c0:	9b018802 	msub	x2, x0, x1, x2
    42c4:	f100005f 	cmp	x2, #0x0
    42c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    42cc:	eb03001f 	cmp	x0, x3
    42d0:	54000a0c 	b.gt	4410 <fwp_poll_events+0x1f0>
    42d4:	340003c0 	cbz	w0, 434c <fwp_poll_events+0x12c>
    42d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    42dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    42e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    42e4:	9ba27c02 	umull	x2, w0, w2
    42e8:	d366fc43 	lsr	x3, x2, #38
    42ec:	aa0303e2 	mov	x2, x3
    42f0:	1b048063 	msub	w3, w3, w4, w0
    42f4:	9b217c63 	smull	x3, w3, w1
    42f8:	d2800001 	mov	x1, #0x0                   	// #0
    42fc:	910023e0 	add	x0, sp, #0x8
    4300:	a9008fe2 	stp	x2, x3, [sp, #8]
    4304:	97fff993 	bl	2950 <nanosleep@plt>
    4308:	9100c280 	add	x0, x20, #0x30
    430c:	f9404413 	ldr	x19, [x0, #136]
    4310:	97fffcfc 	bl	3700 <fwp_now_ns>
    4314:	aa0003e6 	mov	x6, x0
    4318:	b50001f3 	cbnz	x19, 4354 <fwp_poll_events+0x134>
    431c:	d503201f 	nop
    4320:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4324:	f947f400 	ldr	x0, [x0, #4072]
    4328:	f9400fe2 	ldr	x2, [sp, #24]
    432c:	f9400001 	ldr	x1, [x0]
    4330:	eb010042 	subs	x2, x2, x1
    4334:	d2800001 	mov	x1, #0x0                   	// #0
    4338:	540008c1 	b.ne	4450 <fwp_poll_events+0x230>  // b.any
    433c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4340:	a94353f3 	ldp	x19, x20, [sp, #48]
    4344:	910103ff 	add	sp, sp, #0x40
    4348:	d65f03c0 	ret
    434c:	97fffced 	bl	3700 <fwp_now_ns>
    4350:	aa0003e6 	mov	x6, x0
    4354:	4f000400 	movi	v0.4s, #0x0
    4358:	9100c288 	add	x8, x20, #0x30
    435c:	52800027 	mov	w7, #0x1                   	// #1
    4360:	f9403661 	ldr	x1, [x19, #104]
    4364:	aa1303e5 	mov	x5, x19
    4368:	f9408a73 	ldr	x19, [x19, #272]
    436c:	eb06003f 	cmp	x1, x6
    4370:	5400032c 	b.gt	43d4 <fwp_poll_events+0x1b4>
    4374:	394154a0 	ldrb	w0, [x5, #85]
    4378:	36000120 	tbz	w0, #0, 439c <fwp_poll_events+0x17c>
    437c:	f94084a0 	ldr	x0, [x5, #264]
    4380:	b40003c0 	cbz	x0, 43f8 <fwp_poll_events+0x1d8>
    4384:	f9008813 	str	x19, [x0, #272]
    4388:	b4000053 	cbz	x19, 4390 <fwp_poll_events+0x170>
    438c:	f9008660 	str	x0, [x19, #264]
    4390:	910800a0 	add	x0, x5, #0x200
    4394:	390154bf 	strb	wzr, [x5, #85]
    4398:	3c908000 	stur	q0, [x0, #-248]
    439c:	f94030a0 	ldr	x0, [x5, #96]
    43a0:	390158a7 	strb	w7, [x5, #86]
    43a4:	f100001f 	cmp	x0, #0x0
    43a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    43ac:	5400018d 	b.le	43dc <fwp_poll_events+0x1bc>
    43b0:	f94028a0 	ldr	x0, [x5, #80]
    43b4:	f2001c1f 	tst	x0, #0xff000000ff
    43b8:	540000e1 	b.ne	43d4 <fwp_poll_events+0x1b4>  // b.any
    43bc:	f9401500 	ldr	x0, [x8, #40]
    43c0:	390150a7 	strb	w7, [x5, #84]
    43c4:	f90080bf 	str	xzr, [x5, #256]
    43c8:	b40001e0 	cbz	x0, 4404 <fwp_poll_events+0x1e4>
    43cc:	f9001505 	str	x5, [x8, #40]
    43d0:	f9008005 	str	x5, [x0, #256]
    43d4:	b5fffc73 	cbnz	x19, 4360 <fwp_poll_events+0x140>
    43d8:	17ffffd2 	b	4320 <fwp_poll_events+0x100>
    43dc:	394144a0 	ldrb	w0, [x5, #81]
    43e0:	3707fe80 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43e4:	394140a0 	ldrb	w0, [x5, #80]
    43e8:	3707fe40 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43ec:	aa0503e0 	mov	x0, x5
    43f0:	97fffc20 	bl	3470 <fwp_cancel_tree.part.0>
    43f4:	17ffffef 	b	43b0 <fwp_poll_events+0x190>
    43f8:	9100c281 	add	x1, x20, #0x30
    43fc:	f9004433 	str	x19, [x1, #136]
    4400:	17ffffe2 	b	4388 <fwp_poll_events+0x168>
    4404:	f9001505 	str	x5, [x8, #40]
    4408:	f9001905 	str	x5, [x8, #48]
    440c:	17fffff2 	b	43d4 <fwp_poll_events+0x1b4>
    4410:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4414:	d2989362 	mov	x2, #0xc49b                	// #50331
    4418:	f2a4d203 	movk	x3, #0x2690, lsl #16
    441c:	f2a00402 	movk	x2, #0x20, lsl #16
    4420:	17ffffb6 	b	42f8 <fwp_poll_events+0xd8>
    4424:	97fffaf3 	bl	2ff0 <fwp_flush>
    4428:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    442c:	f947e863 	ldr	x3, [x3, #4048]
    4430:	d2800562 	mov	x2, #0x2b                  	// #43
    4434:	d2800021 	mov	x1, #0x1                   	// #1
    4438:	90000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    443c:	91364000 	add	x0, x0, #0xd90
    4440:	f9400063 	ldr	x3, [x3]
    4444:	97fff94f 	bl	2980 <fwrite@plt>
    4448:	52800ca0 	mov	w0, #0x65                  	// #101
    444c:	97fff8b9 	bl	2730 <exit@plt>
    4450:	97fff90c 	bl	2880 <__stack_chk_fail@plt>

0000000000004454 <fwp_rc_wide_dup>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f3 	mov	x19, x0
    4464:	ca404400 	eor	x0, x0, x0, lsr #17
    4468:	f90013f5 	str	x21, [sp, #32]
    446c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4470:	ca402400 	eor	x0, x0, x0, lsr #9
    4474:	911502a2 	add	x2, x21, #0x540
    4478:	92401c00 	and	x0, x0, #0xff
    447c:	910a2403 	add	x3, x0, #0x289
    4480:	8b000c40 	add	x0, x2, x0, lsl #3
    4484:	8b030c54 	add	x20, x2, x3, lsl #3
    4488:	f94a2401 	ldr	x1, [x0, #5192]
    448c:	b50000a1 	cbnz	x1, 44a0 <fwp_rc_wide_dup+0x4c>
    4490:	1400002d 	b	4544 <fwp_rc_wide_dup+0xf0>
    4494:	91004034 	add	x20, x1, #0x10
    4498:	f9400821 	ldr	x1, [x1, #16]
    449c:	b4000241 	cbz	x1, 44e4 <fwp_rc_wide_dup+0x90>
    44a0:	f9400022 	ldr	x2, [x1]
    44a4:	eb02027f 	cmp	x19, x2
    44a8:	54ffff61 	b.ne	4494 <fwp_rc_wide_dup+0x40>  // b.any
    44ac:	f9400281 	ldr	x1, [x20]
    44b0:	39400260 	ldrb	w0, [x19]
    44b4:	7103f81f 	cmp	w0, #0xfe
    44b8:	54000220 	b.eq	44fc <fwp_rc_wide_dup+0xa8>  // b.none
    44bc:	b40001a1 	cbz	x1, 44f0 <fwp_rc_wide_dup+0x9c>
    44c0:	f9400420 	ldr	x0, [x1, #8]
    44c4:	b100041f 	cmn	x0, #0x1
    44c8:	540004a0 	b.eq	455c <fwp_rc_wide_dup+0x108>  // b.none
    44cc:	91000400 	add	x0, x0, #0x1
    44d0:	f9000420 	str	x0, [x1, #8]
    44d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44d8:	f94013f5 	ldr	x21, [sp, #32]
    44dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44e0:	d65f03c0 	ret
    44e4:	39400260 	ldrb	w0, [x19]
    44e8:	7103f81f 	cmp	w0, #0xfe
    44ec:	540000a0 	b.eq	4500 <fwp_rc_wide_dup+0xac>  // b.none
    44f0:	90000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    44f4:	9137a000 	add	x0, x0, #0xde8
    44f8:	97fffc22 	bl	3580 <fwp_trap>
    44fc:	b5000281 	cbnz	x1, 454c <fwp_rc_wide_dup+0xf8>
    4500:	d2800300 	mov	x0, #0x18                  	// #24
    4504:	97fff8c7 	bl	2820 <malloc@plt>
    4508:	b4000280 	cbz	x0, 4558 <fwp_rc_wide_dup+0x104>
    450c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4510:	a9000413 	stp	x19, x1, [x0]
    4514:	911502b5 	add	x21, x21, #0x540
    4518:	f900081f 	str	xzr, [x0, #16]
    451c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4520:	f9000280 	str	x0, [x20]
    4524:	39000261 	strb	w1, [x19]
    4528:	f94e26a0 	ldr	x0, [x21, #7240]
    452c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4530:	91000400 	add	x0, x0, #0x1
    4534:	f90e26a0 	str	x0, [x21, #7240]
    4538:	f94013f5 	ldr	x21, [sp, #32]
    453c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4540:	d65f03c0 	ret
    4544:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4548:	17ffffda 	b	44b0 <fwp_rc_wide_dup+0x5c>
    454c:	90000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    4550:	91370000 	add	x0, x0, #0xdc0
    4554:	97fffc0b 	bl	3580 <fwp_trap>
    4558:	97fffab6 	bl	3030 <fwp_heap_oom>
    455c:	90000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    4560:	91384000 	add	x0, x0, #0xe10
    4564:	97fffc07 	bl	3580 <fwp_trap>
    4568:	d503201f 	nop
    456c:	d503201f 	nop

0000000000004570 <fwp_rc_forget_slot>:
    4570:	aa0003e1 	mov	x1, x0
    4574:	39400000 	ldrb	w0, [x0]
    4578:	7103fc1f 	cmp	w0, #0xff
    457c:	54000040 	b.eq	4584 <fwp_rc_forget_slot+0x14>  // b.none
    4580:	d65f03c0 	ret
    4584:	ca414420 	eor	x0, x1, x1, lsr #17
    4588:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    458c:	ca402400 	eor	x0, x0, x0, lsr #9
    4590:	910003fd 	mov	x29, sp
    4594:	92401c00 	and	x0, x0, #0xff
    4598:	f9000bf3 	str	x19, [sp, #16]
    459c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    45a0:	91150262 	add	x2, x19, #0x540
    45a4:	910a2403 	add	x3, x0, #0x289
    45a8:	8b000c40 	add	x0, x2, x0, lsl #3
    45ac:	8b030c43 	add	x3, x2, x3, lsl #3
    45b0:	f94a2400 	ldr	x0, [x0, #5192]
    45b4:	b50000a0 	cbnz	x0, 45c8 <fwp_rc_forget_slot+0x58>
    45b8:	14000011 	b	45fc <fwp_rc_forget_slot+0x8c>
    45bc:	91004003 	add	x3, x0, #0x10
    45c0:	f9400800 	ldr	x0, [x0, #16]
    45c4:	b40001c0 	cbz	x0, 45fc <fwp_rc_forget_slot+0x8c>
    45c8:	f9400002 	ldr	x2, [x0]
    45cc:	eb02003f 	cmp	x1, x2
    45d0:	54ffff61 	b.ne	45bc <fwp_rc_forget_slot+0x4c>  // b.any
    45d4:	f9400801 	ldr	x1, [x0, #16]
    45d8:	91150273 	add	x19, x19, #0x540
    45dc:	f9000061 	str	x1, [x3]
    45e0:	97fff8d8 	bl	2940 <free@plt>
    45e4:	f94e2660 	ldr	x0, [x19, #7240]
    45e8:	d1000400 	sub	x0, x0, #0x1
    45ec:	f90e2660 	str	x0, [x19, #7240]
    45f0:	f9400bf3 	ldr	x19, [sp, #16]
    45f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45f8:	d65f03c0 	ret
    45fc:	90000040 	adrp	x0, c000 <fwp_main_thread+0x120>
    4600:	9137a000 	add	x0, x0, #0xde8
    4604:	97fffbdf 	bl	3580 <fwp_trap>
    4608:	d503201f 	nop
    460c:	d503201f 	nop

0000000000004610 <fwp_rc_prepare_chunk>:
    4610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4614:	910003fd 	mov	x29, sp
    4618:	a9025bf5 	stp	x21, x22, [sp, #32]
    461c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    4620:	911502c2 	add	x2, x22, #0x540
    4624:	b9401c03 	ldr	w3, [x0, #28]
    4628:	aa0103f5 	mov	x21, x1
    462c:	a90153f3 	stp	x19, x20, [sp, #16]
    4630:	aa0003f4 	mov	x20, x0
    4634:	f94e2440 	ldr	x0, [x2, #7240]
    4638:	b4000440 	cbz	x0, 46c0 <fwp_rc_prepare_chunk+0xb0>
    463c:	d2800013 	mov	x19, #0x0                   	// #0
    4640:	35000203 	cbnz	w3, 4680 <fwp_rc_prepare_chunk+0x70>
    4644:	b4000361 	cbz	x1, 46b0 <fwp_rc_prepare_chunk+0xa0>
    4648:	f9401280 	ldr	x0, [x20, #32]
    464c:	97fff8bd 	bl	2940 <free@plt>
    4650:	aa1503e0 	mov	x0, x21
    4654:	d2800021 	mov	x1, #0x1                   	// #1
    4658:	97fff882 	bl	2860 <calloc@plt>
    465c:	f9001280 	str	x0, [x20, #32]
    4660:	b5000460 	cbnz	x0, 46ec <fwp_rc_prepare_chunk+0xdc>
    4664:	97fffa73 	bl	3030 <fwp_heap_oom>
    4668:	97ffffc2 	bl	4570 <fwp_rc_forget_slot>
    466c:	91000673 	add	x19, x19, #0x1
    4670:	b9401e83 	ldr	w3, [x20, #28]
    4674:	eb13007f 	cmp	x3, x19
    4678:	54000169 	b.ls	46a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    467c:	d503201f 	nop
    4680:	f9401283 	ldr	x3, [x20, #32]
    4684:	8b130060 	add	x0, x3, x19
    4688:	38736863 	ldrb	w3, [x3, x19]
    468c:	7103fc7f 	cmp	w3, #0xff
    4690:	54fffec0 	b.eq	4668 <fwp_rc_prepare_chunk+0x58>  // b.none
    4694:	b9401e83 	ldr	w3, [x20, #28]
    4698:	91000673 	add	x19, x19, #0x1
    469c:	eb13007f 	cmp	x3, x19
    46a0:	54ffff08 	b.hi	4680 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    46a4:	eb0302bf 	cmp	x21, x3
    46a8:	54000121 	b.ne	46cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    46ac:	b5000335 	cbnz	x21, 4710 <fwp_rc_prepare_chunk+0x100>
    46b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46bc:	d65f03c0 	ret
    46c0:	2a0303e3 	mov	w3, w3
    46c4:	eb0302bf 	cmp	x21, x3
    46c8:	54ffff20 	b.eq	46ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    46cc:	911502c2 	add	x2, x22, #0x540
    46d0:	f9401280 	ldr	x0, [x20, #32]
    46d4:	f94e2841 	ldr	x1, [x2, #7248]
    46d8:	cb030021 	sub	x1, x1, x3
    46dc:	f90e2841 	str	x1, [x2, #7248]
    46e0:	97fff898 	bl	2940 <free@plt>
    46e4:	b5fffb75 	cbnz	x21, 4650 <fwp_rc_prepare_chunk+0x40>
    46e8:	f900129f 	str	xzr, [x20, #32]
    46ec:	911502d6 	add	x22, x22, #0x540
    46f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    46f4:	b9001e95 	str	w21, [x20, #28]
    46f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46fc:	8b150000 	add	x0, x0, x21
    4700:	f90e2ac0 	str	x0, [x22, #7248]
    4704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4708:	a8c37bfd 	ldp	x29, x30, [sp], #48
    470c:	d65f03c0 	ret
    4710:	f9401280 	ldr	x0, [x20, #32]
    4714:	aa1503e2 	mov	x2, x21
    4718:	a94153f3 	ldp	x19, x20, [sp, #16]
    471c:	52800001 	mov	w1, #0x0                   	// #0
    4720:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4724:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4728:	17fff84a 	b	2850 <memset@plt>
    472c:	d503201f 	nop

0000000000004730 <fwp_heap_refill>:
    4730:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4734:	910003fd 	mov	x29, sp
    4738:	a9025bf5 	stp	x21, x22, [sp, #32]
    473c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4740:	911502b5 	add	x21, x21, #0x540
    4744:	aa0003f6 	mov	x22, x0
    4748:	d2800020 	mov	x0, #0x1                   	// #1
    474c:	a90153f3 	stp	x19, x20, [sp, #16]
    4750:	a90363f7 	stp	x23, x24, [sp, #48]
    4754:	2a0103f7 	mov	w23, w1
    4758:	2a0203f8 	mov	w24, w2
    475c:	97fffa75 	bl	3130 <fwp_heap_chunks>
    4760:	aa0003f3 	mov	x19, x0
    4764:	f949fea2 	ldr	x2, [x21, #5112]
    4768:	8b000800 	add	x0, x0, x0, lsl #2
    476c:	2a1703e1 	mov	w1, w23
    4770:	52800025 	mov	w5, #0x1                   	// #1
    4774:	d37df000 	lsl	x0, x0, #3
    4778:	910f0021 	add	x1, x1, #0x3c0
    477c:	8b000054 	add	x20, x2, x0
    4780:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4784:	52a00024 	mov	w4, #0x10000               	// #65536
    4788:	38206845 	strb	w5, [x2, x0]
    478c:	aa1403e0 	mov	x0, x20
    4790:	39000698 	strb	w24, [x20, #1]
    4794:	39000a97 	strb	w23, [x20, #2]
    4798:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    479c:	b9000681 	str	w1, [x20, #4]
    47a0:	2a0103e5 	mov	w5, w1
    47a4:	8b0300a2 	add	x2, x5, x3
    47a8:	1ac10881 	udiv	w1, w4, w1
    47ac:	9ac50842 	udiv	x2, x2, x5
    47b0:	b9000a81 	str	w1, [x20, #8]
    47b4:	92404021 	and	x1, x1, #0x1ffff
    47b8:	b9001a82 	str	w2, [x20, #24]
    47bc:	97ffff95 	bl	4610 <fwp_rc_prepare_chunk>
    47c0:	f949daa0 	ldr	x0, [x21, #5040]
    47c4:	29408a81 	ldp	w1, w2, [x20, #4]
    47c8:	8b134000 	add	x0, x0, x19, lsl #16
    47cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d0:	8b214003 	add	x3, x0, w1, uxtw
    47d4:	9ba20021 	umaddl	x1, w1, w2, x0
    47d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    47dc:	a90086c3 	stp	x3, x1, [x22, #8]
    47e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    47e8:	d65f03c0 	ret
    47ec:	d503201f 	nop

00000000000047f0 <fwp_mem_free>:
    47f0:	b40003c0 	cbz	x0, 4868 <fwp_mem_free+0x78>
    47f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    47f8:	910003fd 	mov	x29, sp
    47fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4800:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4804:	911502a1 	add	x1, x21, #0x540
    4808:	a90153f3 	stp	x19, x20, [sp, #16]
    480c:	aa0003f3 	mov	x19, x0
    4810:	f949d823 	ldr	x3, [x1, #5040]
    4814:	f949ec22 	ldr	x2, [x1, #5080]
    4818:	cb030000 	sub	x0, x0, x3
    481c:	eb02401f 	cmp	x0, x2, lsl #16
    4820:	540001c2 	b.cs	4858 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4824:	d350fc16 	lsr	x22, x0, #16
    4828:	a90363f7 	stp	x23, x24, [sp, #48]
    482c:	f949fc22 	ldr	x2, [x1, #5112]
    4830:	8b160ad4 	add	x20, x22, x22, lsl #2
    4834:	d37df294 	lsl	x20, x20, #3
    4838:	ab140057 	adds	x23, x2, x20
    483c:	540000c0 	b.eq	4854 <fwp_mem_free+0x64>  // b.none
    4840:	38746842 	ldrb	w2, [x2, x20]
    4844:	7100045f 	cmp	w2, #0x1
    4848:	54000120 	b.eq	486c <fwp_mem_free+0x7c>  // b.none
    484c:	7100085f 	cmp	w2, #0x2
    4850:	540005e0 	b.eq	490c <fwp_mem_free+0x11c>  // b.none
    4854:	a94363f7 	ldp	x23, x24, [sp, #48]
    4858:	a94153f3 	ldp	x19, x20, [sp, #16]
    485c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4860:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4864:	d65f03c0 	ret
    4868:	d65f03c0 	ret
    486c:	f94012f8 	ldr	x24, [x23, #32]
    4870:	b94006e1 	ldr	w1, [x23, #4]
    4874:	f90023f9 	str	x25, [sp, #64]
    4878:	2a0103e2 	mov	w2, w1
    487c:	394006f9 	ldrb	w25, [x23, #1]
    4880:	39400af4 	ldrb	w20, [x23, #2]
    4884:	b4000158 	cbz	x24, 48ac <fwp_mem_free+0xbc>
    4888:	92403e76 	and	x22, x19, #0xffff
    488c:	9ac20ad6 	udiv	x22, x22, x2
    4890:	38766b01 	ldrb	w1, [x24, x22]
    4894:	8b160300 	add	x0, x24, x22
    4898:	7103fc3f 	cmp	w1, #0xff
    489c:	54000980 	b.eq	49cc <fwp_mem_free+0x1dc>  // b.none
    48a0:	38366b1f 	strb	wzr, [x24, x22]
    48a4:	b94006e1 	ldr	w1, [x23, #4]
    48a8:	2a0103e2 	mov	w2, w1
    48ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    48b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    48b4:	cb390000 	sub	x0, x0, w25, uxtb
    48b8:	8b340074 	add	x20, x3, w20, uxtb
    48bc:	911502b5 	add	x21, x21, #0x540
    48c0:	1e630021 	ucvtf	d1, w1
    48c4:	d37ae400 	lsl	x0, x0, #6
    48c8:	8b140c14 	add	x20, x0, x20, lsl #3
    48cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    48d0:	f8746aa0 	ldr	x0, [x21, x20]
    48d4:	f94023f9 	ldr	x25, [sp, #64]
    48d8:	aa2003e0 	mvn	x0, x0
    48dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    48e0:	f9000260 	str	x0, [x19]
    48e4:	f8346ab3 	str	x19, [x21, x20]
    48e8:	f94a12a0 	ldr	x0, [x21, #5152]
    48ec:	1e612800 	fadd	d0, d0, d1
    48f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f4:	cb020000 	sub	x0, x0, x2
    48f8:	f90a12a0 	str	x0, [x21, #5152]
    48fc:	fd0a22a0 	str	d0, [x21, #5184]
    4900:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4904:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4908:	d65f03c0 	ret
    490c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4910:	8b000063 	add	x3, x3, x0
    4914:	eb03027f 	cmp	x19, x3
    4918:	54fff9e1 	b.ne	4854 <fwp_mem_free+0x64>  // b.any
    491c:	fd400ae1 	ldr	d1, [x23, #16]
    4920:	fd4a2020 	ldr	d0, [x1, #5184]
    4924:	f9400ae0 	ldr	x0, [x23, #16]
    4928:	7e61d821 	ucvtf	d1, d1
    492c:	f94a1022 	ldr	x2, [x1, #5152]
    4930:	f94012f3 	ldr	x19, [x23, #32]
    4934:	1e612800 	fadd	d0, d0, d1
    4938:	cb000042 	sub	x2, x2, x0
    493c:	f90a1022 	str	x2, [x1, #5152]
    4940:	fd0a2020 	str	d0, [x1, #5184]
    4944:	b40000b3 	cbz	x19, 4958 <fwp_mem_free+0x168>
    4948:	39400260 	ldrb	w0, [x19]
    494c:	7103fc1f 	cmp	w0, #0xff
    4950:	54000380 	b.eq	49c0 <fwp_mem_free+0x1d0>  // b.none
    4954:	3900027f 	strb	wzr, [x19]
    4958:	b9400ee2 	ldr	w2, [x23, #12]
    495c:	b4000142 	cbz	x2, 4984 <fwp_mem_free+0x194>
    4960:	911502a1 	add	x1, x21, #0x540
    4964:	8b160040 	add	x0, x2, x22
    4968:	8b000800 	add	x0, x0, x0, lsl #2
    496c:	f949fc21 	ldr	x1, [x1, #5112]
    4970:	8b140034 	add	x20, x1, x20
    4974:	8b000c20 	add	x0, x1, x0, lsl #3
    4978:	3802869f 	strb	wzr, [x20], #40
    497c:	eb00029f 	cmp	x20, x0
    4980:	54ffffc1 	b.ne	4978 <fwp_mem_free+0x188>  // b.any
    4984:	911502a0 	add	x0, x21, #0x540
    4988:	f94a1801 	ldr	x1, [x0, #5168]
    498c:	f949f803 	ldr	x3, [x0, #5104]
    4990:	8b020021 	add	x1, x1, x2
    4994:	f90a1801 	str	x1, [x0, #5168]
    4998:	eb16007f 	cmp	x3, x22
    499c:	54000049 	b.ls	49a4 <fwp_mem_free+0x1b4>  // b.plast
    49a0:	f909f816 	str	x22, [x0, #5104]
    49a4:	911502b5 	add	x21, x21, #0x540
    49a8:	f949f6a0 	ldr	x0, [x21, #5096]
    49ac:	eb16001f 	cmp	x0, x22
    49b0:	54fff529 	b.ls	4854 <fwp_mem_free+0x64>  // b.plast
    49b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    49b8:	f909f6b6 	str	x22, [x21, #5096]
    49bc:	17ffffa7 	b	4858 <fwp_mem_free+0x68>
    49c0:	aa1303e0 	mov	x0, x19
    49c4:	97fffeeb 	bl	4570 <fwp_rc_forget_slot>
    49c8:	17ffffe3 	b	4954 <fwp_mem_free+0x164>
    49cc:	97fffee9 	bl	4570 <fwp_rc_forget_slot>
    49d0:	17ffffb4 	b	48a0 <fwp_mem_free+0xb0>

00000000000049d4 <fwp_heap_alloc_big>:
    49d4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d8:	910003fd 	mov	x29, sp
    49dc:	a90153f3 	stp	x19, x20, [sp, #16]
    49e0:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e4:	a90363f7 	stp	x23, x24, [sp, #48]
    49e8:	aa0003f7 	mov	x23, x0
    49ec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f4:	eb0002ff 	cmp	x23, x0
    49f8:	54000888 	b.hi	4b08 <fwp_heap_alloc_big+0x134>  // b.pmore
    49fc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4a00:	8b0002f4 	add	x20, x23, x0
    4a04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4a08:	91150359 	add	x25, x26, #0x540
    4a0c:	d350fe94 	lsr	x20, x20, #16
    4a10:	2a0103f5 	mov	w21, w1
    4a14:	aa1403e0 	mov	x0, x20
    4a18:	97fff9c6 	bl	3130 <fwp_heap_chunks>
    4a1c:	f949ff22 	ldr	x2, [x25, #5112]
    4a20:	8b000813 	add	x19, x0, x0, lsl #2
    4a24:	aa0003f8 	mov	x24, x0
    4a28:	52800043 	mov	w3, #0x2                   	// #2
    4a2c:	d37df273 	lsl	x19, x19, #3
    4a30:	d2800021 	mov	x1, #0x1                   	// #1
    4a34:	8b130040 	add	x0, x2, x19
    4a38:	38336843 	strb	w3, [x2, x19]
    4a3c:	39000415 	strb	w21, [x0, #1]
    4a40:	b9000c14 	str	w20, [x0, #12]
    4a44:	f9000817 	str	x23, [x0, #16]
    4a48:	97fffef2 	bl	4610 <fwp_rc_prepare_chunk>
    4a4c:	f100069f 	cmp	x20, #0x1
    4a50:	54000269 	b.ls	4a9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4a54:	8b180294 	add	x20, x20, x24
    4a58:	9100a273 	add	x19, x19, #0x28
    4a5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4a60:	5280007b 	mov	w27, #0x3                   	// #3
    4a64:	8b140a94 	add	x20, x20, x20, lsl #2
    4a68:	2a1803fc 	mov	w28, w24
    4a6c:	9adb2296 	lsl	x22, x20, x27
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffee4 	bl	4610 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0x9c>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	91150353 	add	x19, x26, #0x540
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9115035a 	add	x26, x26, #0x540
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4b20:	91150262 	add	x2, x19, #0x540
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	91150262 	add	x2, x19, #0x540
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	91150260 	add	x0, x19, #0x540
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	91150273 	add	x19, x19, #0x540
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffca4 	bl	3e84 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff70 	b	49d4 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	91150260 	add	x0, x19, #0x540
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffeb5 	bl	4730 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c84:	91150293 	add	x19, x20, #0x540
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	91150294 	add	x20, x20, #0x540
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4d94:	91150283 	add	x3, x20, #0x540
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	91150282 	add	x2, x20, #0x540
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	91150294 	add	x20, x20, #0x540
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_p_ad_push>:
    4ea4:	f100001f 	cmp	x0, #0x0
    4ea8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4eac:	54000e8b 	b.lt	507c <fwp_p_ad_push+0x1d8>  // b.tstop
    4eb0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4eb4:	aa0003e4 	mov	x4, x0
    4eb8:	910003fd 	mov	x29, sp
    4ebc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ec0:	aa0003f5 	mov	x21, x0
    4ec4:	aa020000 	orr	x0, x0, x2
    4ec8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ecc:	aa0203f7 	mov	x23, x2
    4ed0:	6d0627e8 	stp	d8, d9, [sp, #96]
    4ed4:	9e670029 	fmov	d9, x1
    4ed8:	9e670068 	fmov	d8, x3
    4edc:	b6f80900 	tbz	x0, #63, 4ffc <fwp_p_ad_push+0x158>
    4ee0:	a90153f3 	stp	x19, x20, [sp, #16]
    4ee4:	9360fc80 	asr	x0, x4, #32
    4ee8:	b6f800c4 	tbz	x4, #63, 4f00 <fwp_p_ad_push+0x5c>
    4eec:	1e604109 	fmov	d9, d8
    4ef0:	2f00e408 	movi	d8, #0x0
    4ef4:	9360fc40 	asr	x0, x2, #32
    4ef8:	aa0203f5 	mov	x21, x2
    4efc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f00:	97fffa6c 	bl	38b0 <fwp_tape_of>
    4f04:	aa0003f3 	mov	x19, x0
    4f08:	f9403000 	ldr	x0, [x0, #96]
    4f0c:	b5001280 	cbnz	x0, 515c <fwp_p_ad_push+0x2b8>
    4f10:	f9400a76 	ldr	x22, [x19, #16]
    4f14:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f18:	eb0002df 	cmp	x22, x0
    4f1c:	54000e2c 	b.gt	50e0 <fwp_p_ad_push+0x23c>
    4f20:	eb3542df 	cmp	x22, w21, uxtw
    4f24:	54000d4d 	b.le	50cc <fwp_p_ad_push+0x228>
    4f28:	b7f80077 	tbnz	x23, #63, 4f34 <fwp_p_ad_push+0x90>
    4f2c:	eb3742df 	cmp	x22, w23, uxtw
    4f30:	54000ced 	b.le	50cc <fwp_p_ad_push+0x228>
    4f34:	f9400678 	ldr	x24, [x19, #8]
    4f38:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f3c:	cb1802d8 	sub	x24, x22, x24
    4f40:	91000701 	add	x1, x24, #0x1
    4f44:	eb00003f 	cmp	x1, x0
    4f48:	54000cc8 	b.hi	50e0 <fwp_p_ad_push+0x23c>  // b.pmore
    4f4c:	a9418274 	ldp	x20, x0, [x19, #24]
    4f50:	a90573fb 	stp	x27, x28, [sp, #80]
    4f54:	eb14003f 	cmp	x1, x20
    4f58:	5400068d 	b.le	5028 <fwp_p_ad_push+0x184>
    4f5c:	f100029f 	cmp	x20, #0x0
    4f60:	d2800803 	mov	x3, #0x40                  	// #64
    4f64:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4f68:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4f6c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f70:	eb14003f 	cmp	x1, x20
    4f74:	5400008d 	b.le	4f84 <fwp_p_ad_push+0xe0>
    4f78:	eb02029f 	cmp	x20, x2
    4f7c:	5400052d 	b.le	5020 <fwp_p_ad_push+0x17c>
    4f80:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4f84:	d37df299 	lsl	x25, x20, #3
    4f88:	aa1903e1 	mov	x1, x25
    4f8c:	97fff639 	bl	2870 <realloc@plt>
    4f90:	aa0003e1 	mov	x1, x0
    4f94:	b4000b00 	cbz	x0, 50f4 <fwp_p_ad_push+0x250>
    4f98:	f9400e62 	ldr	x2, [x19, #24]
    4f9c:	f9001261 	str	x1, [x19, #32]
    4fa0:	f9401a60 	ldr	x0, [x19, #48]
    4fa4:	d37cee9a 	lsl	x26, x20, #4
    4fa8:	8b020821 	add	x1, x1, x2, lsl #2
    4fac:	f9001661 	str	x1, [x19, #40]
    4fb0:	aa1a03e1 	mov	x1, x26
    4fb4:	97fff62f 	bl	2870 <realloc@plt>
    4fb8:	aa0003e2 	mov	x2, x0
    4fbc:	b40009c0 	cbz	x0, 50f4 <fwp_p_ad_push+0x250>
    4fc0:	f9400e61 	ldr	x1, [x19, #24]
    4fc4:	d37df31b 	lsl	x27, x24, #3
    4fc8:	d37ef685 	lsl	x5, x20, #2
    4fcc:	d37ef71c 	lsl	x28, x24, #2
    4fd0:	8b190004 	add	x4, x0, x25
    4fd4:	8b010c01 	add	x1, x0, x1, lsl #3
    4fd8:	a9030660 	stp	x0, x1, [x19, #48]
    4fdc:	b5000558 	cbnz	x24, 5084 <fwp_p_ad_push+0x1e0>
    4fe0:	f9001e64 	str	x4, [x19, #56]
    4fe4:	f9401260 	ldr	x0, [x19, #32]
    4fe8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fec:	8b050001 	add	x1, x0, x5
    4ff0:	f9000e74 	str	x20, [x19, #24]
    4ff4:	f9001661 	str	x1, [x19, #40]
    4ff8:	14000010 	b	5038 <fwp_p_ad_push+0x194>
    4ffc:	9360fc40 	asr	x0, x2, #32
    5000:	a90153f3 	stp	x19, x20, [sp, #16]
    5004:	eb84801f 	cmp	x0, x4, asr #32
    5008:	54fff7c0 	b.eq	4f00 <fwp_p_ad_push+0x5c>  // b.none
    500c:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    5010:	9138c000 	add	x0, x0, #0xe30
    5014:	a9046bf9 	stp	x25, x26, [sp, #64]
    5018:	a90573fb 	stp	x27, x28, [sp, #80]
    501c:	97fff959 	bl	3580 <fwp_trap>
    5020:	d37ffa94 	lsl	x20, x20, #1
    5024:	17ffffd3 	b	4f70 <fwp_p_ad_push+0xcc>
    5028:	a9428a61 	ldp	x1, x2, [x19, #40]
    502c:	d37ef71c 	lsl	x28, x24, #2
    5030:	f9401e64 	ldr	x4, [x19, #56]
    5034:	d37df31b 	lsl	x27, x24, #3
    5038:	b83c6815 	str	w21, [x0, x28]
    503c:	f10002ff 	cmp	x23, #0x0
    5040:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5044:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5048:	fc3b6849 	str	d9, [x2, x27]
    504c:	aa1602a0 	orr	x0, x21, x22
    5050:	b83c6837 	str	w23, [x1, x28]
    5054:	910006d6 	add	x22, x22, #0x1
    5058:	a94363f7 	ldp	x23, x24, [sp, #48]
    505c:	fc3b6888 	str	d8, [x4, x27]
    5060:	a94573fb 	ldp	x27, x28, [sp, #80]
    5064:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5068:	f9000a76 	str	x22, [x19, #16]
    506c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5078:	d65f03c0 	ret
    507c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5080:	d65f03c0 	ret
    5084:	eb1a033f 	cmp	x25, x26
    5088:	aa0403e0 	mov	x0, x4
    508c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5090:	aa1b03e2 	mov	x2, x27
    5094:	cb190063 	sub	x3, x3, x25
    5098:	f9003fe5 	str	x5, [sp, #120]
    509c:	97fff661 	bl	2a20 <__memmove_chk@plt>
    50a0:	a9420660 	ldp	x0, x1, [x19, #32]
    50a4:	aa1c03e2 	mov	x2, x28
    50a8:	f9401a63 	ldr	x3, [x19, #48]
    50ac:	f9403fe5 	ldr	x5, [sp, #120]
    50b0:	8b190063 	add	x3, x3, x25
    50b4:	f9001e63 	str	x3, [x19, #56]
    50b8:	8b050000 	add	x0, x0, x5
    50bc:	97fff58d 	bl	26f0 <memmove@plt>
    50c0:	a9431262 	ldp	x2, x4, [x19, #48]
    50c4:	f9403fe5 	ldr	x5, [sp, #120]
    50c8:	17ffffc7 	b	4fe4 <fwp_p_ad_push+0x140>
    50cc:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    50d0:	913b2000 	add	x0, x0, #0xec8
    50d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    50d8:	a90573fb 	stp	x27, x28, [sp, #80]
    50dc:	97fff929 	bl	3580 <fwp_trap>
    50e0:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    50e4:	913aa000 	add	x0, x0, #0xea8
    50e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    50ec:	a90573fb 	stp	x27, x28, [sp, #80]
    50f0:	97fff924 	bl	3580 <fwp_trap>
    50f4:	aa1303e0 	mov	x0, x19
    50f8:	97fff7a6 	bl	2f90 <fwp_tape_unlink_scope>
    50fc:	f9401260 	ldr	x0, [x19, #32]
    5100:	97fff610 	bl	2940 <free@plt>
    5104:	f9401a60 	ldr	x0, [x19, #48]
    5108:	97fff60e 	bl	2940 <free@plt>
    510c:	f9402260 	ldr	x0, [x19, #64]
    5110:	97fff60c 	bl	2940 <free@plt>
    5114:	f9000e7f 	str	xzr, [x19, #24]
    5118:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    511c:	f947e821 	ldr	x1, [x1, #4048]
    5120:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5124:	d2800262 	mov	x2, #0x13                  	// #19
    5128:	4f000400 	movi	v0.4s, #0x0
    512c:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    5130:	f9400023 	ldr	x3, [x1]
    5134:	b900067f 	str	wzr, [x19, #4]
    5138:	d2800021 	mov	x1, #0x1                   	// #1
    513c:	912d2000 	add	x0, x0, #0xb48
    5140:	3c808260 	stur	q0, [x19, #8]
    5144:	ad010260 	stp	q0, q0, [x19, #32]
    5148:	97fff60e 	bl	2980 <fwrite@plt>
    514c:	d2800000 	mov	x0, #0x0                   	// #0
    5150:	97fff618 	bl	29b0 <fflush@plt>
    5154:	52800cc0 	mov	w0, #0x66                  	// #102
    5158:	97fff626 	bl	29f0 <_Exit@plt>
    515c:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    5160:	9139e000 	add	x0, x0, #0xe78
    5164:	a9046bf9 	stp	x25, x26, [sp, #64]
    5168:	a90573fb 	stp	x27, x28, [sp, #80]
    516c:	97fff905 	bl	3580 <fwp_trap>

0000000000005170 <w120>:
    5170:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5174:	9e660003 	fmov	x3, d0
    5178:	aa0003e2 	mov	x2, x0
    517c:	910003fd 	mov	x29, sp
    5180:	6d0327e8 	stp	d8, d9, [sp, #48]
    5184:	1e604028 	fmov	d8, d1
    5188:	1e600809 	fmul	d9, d0, d0
    518c:	fd0023ea 	str	d10, [sp, #64]
    5190:	1e60400a 	fmov	d10, d0
    5194:	a90153f3 	stp	x19, x20, [sp, #16]
    5198:	aa0003f3 	mov	x19, x0
    519c:	aa0103f4 	mov	x20, x1
    51a0:	aa0303e1 	mov	x1, x3
    51a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    51a8:	97ffff3f 	bl	4ea4 <fwp_p_ad_push>
    51ac:	1e693908 	fsub	d8, d8, d9
    51b0:	aa1403e2 	mov	x2, x20
    51b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    51b8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    51bc:	9e660116 	fmov	x22, d8
    51c0:	97ffff39 	bl	4ea4 <fwp_p_ad_push>
    51c4:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    51c8:	aa0003e1 	mov	x1, x0
    51cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    51d0:	aa1303e0 	mov	x0, x19
    51d4:	1e6a3929 	fsub	d9, d9, d10
    51d8:	aa0103f3 	mov	x19, x1
    51dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    51e0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    51e4:	9e660135 	fmov	x21, d9
    51e8:	97ffff2f 	bl	4ea4 <fwp_p_ad_push>
    51ec:	1e680908 	fmul	d8, d8, d8
    51f0:	aa0003f4 	mov	x20, x0
    51f4:	aa1603e3 	mov	x3, x22
    51f8:	aa1603e1 	mov	x1, x22
    51fc:	aa1303e2 	mov	x2, x19
    5200:	aa1303e0 	mov	x0, x19
    5204:	97ffff28 	bl	4ea4 <fwp_p_ad_push>
    5208:	aa0003e2 	mov	x2, x0
    520c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5210:	9e670020 	fmov	d0, x1
    5214:	9e660101 	fmov	x1, d8
    5218:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    521c:	1e600908 	fmul	d8, d8, d0
    5220:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5224:	97ffff20 	bl	4ea4 <fwp_p_ad_push>
    5228:	1e690929 	fmul	d9, d9, d9
    522c:	aa0003f3 	mov	x19, x0
    5230:	aa1503e3 	mov	x3, x21
    5234:	aa1503e1 	mov	x1, x21
    5238:	aa1403e2 	mov	x2, x20
    523c:	aa1403e0 	mov	x0, x20
    5240:	97ffff19 	bl	4ea4 <fwp_p_ad_push>
    5244:	1e692908 	fadd	d8, d8, d9
    5248:	aa1303e2 	mov	x2, x19
    524c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5250:	aa0303e1 	mov	x1, x3
    5254:	97ffff14 	bl	4ea4 <fwp_p_ad_push>
    5258:	aa0003e1 	mov	x1, x0
    525c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5260:	9e660100 	fmov	x0, d8
    5264:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5268:	6d4327e8 	ldp	d8, d9, [sp, #48]
    526c:	fd4023ea 	ldr	d10, [sp, #64]
    5270:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5274:	d65f03c0 	ret
    5278:	d503201f 	nop
    527c:	d503201f 	nop

0000000000005280 <fwp_rc_share>:
    5280:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5284:	91150042 	add	x2, x2, #0x540
    5288:	f949d843 	ldr	x3, [x2, #5040]
    528c:	f949ec41 	ldr	x1, [x2, #5080]
    5290:	cb030000 	sub	x0, x0, x3
    5294:	eb01401f 	cmp	x0, x1, lsl #16
    5298:	540002c2 	b.cs	52f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    529c:	d350fc01 	lsr	x1, x0, #16
    52a0:	f949fc44 	ldr	x4, [x2, #5112]
    52a4:	8b010821 	add	x1, x1, x1, lsl #2
    52a8:	d37df021 	lsl	x1, x1, #3
    52ac:	8b010083 	add	x3, x4, x1
    52b0:	f9401062 	ldr	x2, [x3, #32]
    52b4:	b40001e2 	cbz	x2, 52f0 <fwp_rc_share+0x70>
    52b8:	38616881 	ldrb	w1, [x4, x1]
    52bc:	7100083f 	cmp	w1, #0x2
    52c0:	540001a0 	b.eq	52f4 <fwp_rc_share+0x74>  // b.none
    52c4:	7100043f 	cmp	w1, #0x1
    52c8:	54000141 	b.ne	52f0 <fwp_rc_share+0x70>  // b.any
    52cc:	29430464 	ldp	w4, w1, [x3, #24]
    52d0:	92403c00 	and	x0, x0, #0xffff
    52d4:	9b047c00 	mul	x0, x0, x4
    52d8:	d360fc00 	lsr	x0, x0, #32
    52dc:	eb01001f 	cmp	x0, x1
    52e0:	54000082 	b.cs	52f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    52e4:	8b000042 	add	x2, x2, x0
    52e8:	39400040 	ldrb	w0, [x2]
    52ec:	350000a0 	cbnz	w0, 5300 <fwp_rc_share+0x80>
    52f0:	d65f03c0 	ret
    52f4:	72003c1f 	tst	w0, #0xffff
    52f8:	54ffff80 	b.eq	52e8 <fwp_rc_share+0x68>  // b.none
    52fc:	d65f03c0 	ret
    5300:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5304:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    5308:	913ba000 	add	x0, x0, #0xee8
    530c:	910003fd 	mov	x29, sp
    5310:	97fff89c 	bl	3580 <fwp_trap>

0000000000005314 <fwp_rc_fresh>:
    5314:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5318:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    531c:	91150063 	add	x3, x3, #0x540
    5320:	910003fd 	mov	x29, sp
    5324:	a90153f3 	stp	x19, x20, [sp, #16]
    5328:	aa0003f3 	mov	x19, x0
    532c:	f949d861 	ldr	x1, [x3, #5040]
    5330:	f949ec60 	ldr	x0, [x3, #5080]
    5334:	cb010261 	sub	x1, x19, x1
    5338:	eb00403f 	cmp	x1, x0, lsl #16
    533c:	54000322 	b.cs	53a0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5340:	d350fc22 	lsr	x2, x1, #16
    5344:	f949fc63 	ldr	x3, [x3, #5112]
    5348:	8b020842 	add	x2, x2, x2, lsl #2
    534c:	d37df042 	lsl	x2, x2, #3
    5350:	8b020060 	add	x0, x3, x2
    5354:	f9401014 	ldr	x20, [x0, #32]
    5358:	b4000254 	cbz	x20, 53a0 <fwp_rc_fresh+0x8c>
    535c:	38626862 	ldrb	w2, [x3, x2]
    5360:	7100085f 	cmp	w2, #0x2
    5364:	54000260 	b.eq	53b0 <fwp_rc_fresh+0x9c>  // b.none
    5368:	7100045f 	cmp	w2, #0x1
    536c:	540001a1 	b.ne	53a0 <fwp_rc_fresh+0x8c>  // b.any
    5370:	29430002 	ldp	w2, w0, [x0, #24]
    5374:	92403c21 	and	x1, x1, #0xffff
    5378:	9b027c21 	mul	x1, x1, x2
    537c:	d360fc21 	lsr	x1, x1, #32
    5380:	eb00003f 	cmp	x1, x0
    5384:	540000e2 	b.cs	53a0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5388:	8b010294 	add	x20, x20, x1
    538c:	39400280 	ldrb	w0, [x20]
    5390:	7103fc1f 	cmp	w0, #0xff
    5394:	540001a0 	b.eq	53c8 <fwp_rc_fresh+0xb4>  // b.none
    5398:	52800020 	mov	w0, #0x1                   	// #1
    539c:	39000280 	strb	w0, [x20]
    53a0:	aa1303e0 	mov	x0, x19
    53a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    53ac:	d65f03c0 	ret
    53b0:	72003c3f 	tst	w1, #0xffff
    53b4:	54fffec0 	b.eq	538c <fwp_rc_fresh+0x78>  // b.none
    53b8:	aa1303e0 	mov	x0, x19
    53bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    53c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    53c4:	d65f03c0 	ret
    53c8:	aa1403e0 	mov	x0, x20
    53cc:	97fffc69 	bl	4570 <fwp_rc_forget_slot>
    53d0:	17fffff2 	b	5398 <fwp_rc_fresh+0x84>

00000000000053d4 <fwp_rc_free_arr>:
    53d4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    53d8:	91150063 	add	x3, x3, #0x540
    53dc:	f949d861 	ldr	x1, [x3, #5040]
    53e0:	f949ec62 	ldr	x2, [x3, #5080]
    53e4:	cb010001 	sub	x1, x0, x1
    53e8:	eb02403f 	cmp	x1, x2, lsl #16
    53ec:	54000342 	b.cs	5454 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    53f0:	d350fc22 	lsr	x2, x1, #16
    53f4:	f949fc65 	ldr	x5, [x3, #5112]
    53f8:	8b020842 	add	x2, x2, x2, lsl #2
    53fc:	d37df042 	lsl	x2, x2, #3
    5400:	8b0200a4 	add	x4, x5, x2
    5404:	f9401083 	ldr	x3, [x4, #32]
    5408:	b4000263 	cbz	x3, 5454 <fwp_rc_free_arr+0x80>
    540c:	386268a2 	ldrb	w2, [x5, x2]
    5410:	7100085f 	cmp	w2, #0x2
    5414:	540001c0 	b.eq	544c <fwp_rc_free_arr+0x78>  // b.none
    5418:	7100045f 	cmp	w2, #0x1
    541c:	540001c1 	b.ne	5454 <fwp_rc_free_arr+0x80>  // b.any
    5420:	29430885 	ldp	w5, w2, [x4, #24]
    5424:	92403c21 	and	x1, x1, #0xffff
    5428:	9b057c21 	mul	x1, x1, x5
    542c:	d360fc21 	lsr	x1, x1, #32
    5430:	eb02003f 	cmp	x1, x2
    5434:	54000102 	b.cs	5454 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5438:	8b010063 	add	x3, x3, x1
    543c:	39400061 	ldrb	w1, [x3]
    5440:	7100043f 	cmp	w1, #0x1
    5444:	54000081 	b.ne	5454 <fwp_rc_free_arr+0x80>  // b.any
    5448:	17fffcea 	b	47f0 <fwp_mem_free>
    544c:	72003c3f 	tst	w1, #0xffff
    5450:	54ffff60 	b.eq	543c <fwp_rc_free_arr+0x68>  // b.none
    5454:	d65f03c0 	ret
    5458:	d503201f 	nop
    545c:	d503201f 	nop

0000000000005460 <fwp_rc_dup>:
    5460:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5464:	91150042 	add	x2, x2, #0x540
    5468:	f949d841 	ldr	x1, [x2, #5040]
    546c:	f949ec43 	ldr	x3, [x2, #5080]
    5470:	cb010001 	sub	x1, x0, x1
    5474:	eb03403f 	cmp	x1, x3, lsl #16
    5478:	54000342 	b.cs	54e0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    547c:	d350fc20 	lsr	x0, x1, #16
    5480:	f949fc44 	ldr	x4, [x2, #5112]
    5484:	8b000800 	add	x0, x0, x0, lsl #2
    5488:	d37df002 	lsl	x2, x0, #3
    548c:	8b020083 	add	x3, x4, x2
    5490:	f9401060 	ldr	x0, [x3, #32]
    5494:	b4000260 	cbz	x0, 54e0 <fwp_rc_dup+0x80>
    5498:	38626882 	ldrb	w2, [x4, x2]
    549c:	7100085f 	cmp	w2, #0x2
    54a0:	54000220 	b.eq	54e4 <fwp_rc_dup+0x84>  // b.none
    54a4:	7100045f 	cmp	w2, #0x1
    54a8:	540001c1 	b.ne	54e0 <fwp_rc_dup+0x80>  // b.any
    54ac:	29430864 	ldp	w4, w2, [x3, #24]
    54b0:	92403c21 	and	x1, x1, #0xffff
    54b4:	9b047c21 	mul	x1, x1, x4
    54b8:	d360fc21 	lsr	x1, x1, #32
    54bc:	eb02003f 	cmp	x1, x2
    54c0:	54000102 	b.cs	54e0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    54c4:	8b010000 	add	x0, x0, x1
    54c8:	39400001 	ldrb	w1, [x0]
    54cc:	340000a1 	cbz	w1, 54e0 <fwp_rc_dup+0x80>
    54d0:	7103f43f 	cmp	w1, #0xfd
    54d4:	540000e8 	b.hi	54f0 <fwp_rc_dup+0x90>  // b.pmore
    54d8:	11000421 	add	w1, w1, #0x1
    54dc:	39000001 	strb	w1, [x0]
    54e0:	d65f03c0 	ret
    54e4:	72003c3f 	tst	w1, #0xffff
    54e8:	54ffff00 	b.eq	54c8 <fwp_rc_dup+0x68>  // b.none
    54ec:	d65f03c0 	ret
    54f0:	17fffbd9 	b	4454 <fwp_rc_wide_dup>

00000000000054f4 <fwp_owned_entry173>:
    54f4:	d10103ff 	sub	sp, sp, #0x40
    54f8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    54fc:	f947f442 	ldr	x2, [x2, #4072]
    5500:	a9027bfd 	stp	x29, x30, [sp, #32]
    5504:	910083fd 	add	x29, sp, #0x20
    5508:	a90353f3 	stp	x19, x20, [sp, #48]
    550c:	f9400043 	ldr	x3, [x2]
    5510:	f9000fe3 	str	x3, [sp, #24]
    5514:	d2800003 	mov	x3, #0x0                   	// #0
    5518:	a9400c01 	ldp	x1, x3, [x0]
    551c:	f9400802 	ldr	x2, [x0, #16]
    5520:	ab020022 	adds	x2, x1, x2
    5524:	540006e6 	b.vs	5600 <fwp_owned_entry173+0x10c>
    5528:	910023e1 	add	x1, sp, #0x8
    552c:	52800000 	mov	w0, #0x0                   	// #0
    5530:	a9008be3 	stp	x3, x2, [sp, #8]
    5534:	97fffe14 	bl	4d84 <fwp_data.part.0.constprop.0>
    5538:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    553c:	91150063 	add	x3, x3, #0x540
    5540:	aa0003f3 	mov	x19, x0
    5544:	f949d861 	ldr	x1, [x3, #5040]
    5548:	f949ec60 	ldr	x0, [x3, #5080]
    554c:	cb010261 	sub	x1, x19, x1
    5550:	eb00403f 	cmp	x1, x0, lsl #16
    5554:	54000322 	b.cs	55b8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5558:	d350fc22 	lsr	x2, x1, #16
    555c:	f949fc63 	ldr	x3, [x3, #5112]
    5560:	8b020842 	add	x2, x2, x2, lsl #2
    5564:	d37df042 	lsl	x2, x2, #3
    5568:	8b020060 	add	x0, x3, x2
    556c:	f9401014 	ldr	x20, [x0, #32]
    5570:	b4000254 	cbz	x20, 55b8 <fwp_owned_entry173+0xc4>
    5574:	38626862 	ldrb	w2, [x3, x2]
    5578:	7100085f 	cmp	w2, #0x2
    557c:	54000360 	b.eq	55e8 <fwp_owned_entry173+0xf4>  // b.none
    5580:	7100045f 	cmp	w2, #0x1
    5584:	540001a1 	b.ne	55b8 <fwp_owned_entry173+0xc4>  // b.any
    5588:	29430002 	ldp	w2, w0, [x0, #24]
    558c:	92403c21 	and	x1, x1, #0xffff
    5590:	9b027c21 	mul	x1, x1, x2
    5594:	d360fc21 	lsr	x1, x1, #32
    5598:	eb00003f 	cmp	x1, x0
    559c:	540000e2 	b.cs	55b8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    55a0:	8b010294 	add	x20, x20, x1
    55a4:	39400280 	ldrb	w0, [x20]
    55a8:	7103fc1f 	cmp	w0, #0xff
    55ac:	54000240 	b.eq	55f4 <fwp_owned_entry173+0x100>  // b.none
    55b0:	52800020 	mov	w0, #0x1                   	// #1
    55b4:	39000280 	strb	w0, [x20]
    55b8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    55bc:	f947f400 	ldr	x0, [x0, #4072]
    55c0:	f9400fe2 	ldr	x2, [sp, #24]
    55c4:	f9400001 	ldr	x1, [x0]
    55c8:	eb010042 	subs	x2, x2, x1
    55cc:	d2800001 	mov	x1, #0x0                   	// #0
    55d0:	540001a1 	b.ne	5604 <fwp_owned_entry173+0x110>  // b.any
    55d4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    55d8:	aa1303e0 	mov	x0, x19
    55dc:	a94353f3 	ldp	x19, x20, [sp, #48]
    55e0:	910103ff 	add	sp, sp, #0x40
    55e4:	d65f03c0 	ret
    55e8:	72003c3f 	tst	w1, #0xffff
    55ec:	54fffe61 	b.ne	55b8 <fwp_owned_entry173+0xc4>  // b.any
    55f0:	17ffffed 	b	55a4 <fwp_owned_entry173+0xb0>
    55f4:	aa1403e0 	mov	x0, x20
    55f8:	97fffbde 	bl	4570 <fwp_rc_forget_slot>
    55fc:	17ffffed 	b	55b0 <fwp_owned_entry173+0xbc>
    5600:	97fff520 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5604:	97fff49f 	bl	2880 <__stack_chk_fail@plt>
    5608:	d503201f 	nop
    560c:	d503201f 	nop

0000000000005610 <e173>:
    5610:	d10103ff 	sub	sp, sp, #0x40
    5614:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5618:	f947f442 	ldr	x2, [x2, #4072]
    561c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5620:	910083fd 	add	x29, sp, #0x20
    5624:	a90353f3 	stp	x19, x20, [sp, #48]
    5628:	f9400043 	ldr	x3, [x2]
    562c:	f9000fe3 	str	x3, [sp, #24]
    5630:	d2800003 	mov	x3, #0x0                   	// #0
    5634:	a9400c01 	ldp	x1, x3, [x0]
    5638:	f9400802 	ldr	x2, [x0, #16]
    563c:	ab020022 	adds	x2, x1, x2
    5640:	54000726 	b.vs	5724 <e173+0x114>
    5644:	910023e1 	add	x1, sp, #0x8
    5648:	52800000 	mov	w0, #0x0                   	// #0
    564c:	a9008be3 	stp	x3, x2, [sp, #8]
    5650:	97fffdcd 	bl	4d84 <fwp_data.part.0.constprop.0>
    5654:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5658:	91150063 	add	x3, x3, #0x540
    565c:	aa0003f3 	mov	x19, x0
    5660:	f949d861 	ldr	x1, [x3, #5040]
    5664:	f949ec60 	ldr	x0, [x3, #5080]
    5668:	cb010261 	sub	x1, x19, x1
    566c:	eb00403f 	cmp	x1, x0, lsl #16
    5670:	54000322 	b.cs	56d4 <e173+0xc4>  // b.hs, b.nlast
    5674:	d350fc22 	lsr	x2, x1, #16
    5678:	f949fc63 	ldr	x3, [x3, #5112]
    567c:	8b020842 	add	x2, x2, x2, lsl #2
    5680:	d37df042 	lsl	x2, x2, #3
    5684:	8b020060 	add	x0, x3, x2
    5688:	f9401014 	ldr	x20, [x0, #32]
    568c:	b4000254 	cbz	x20, 56d4 <e173+0xc4>
    5690:	38626862 	ldrb	w2, [x3, x2]
    5694:	7100085f 	cmp	w2, #0x2
    5698:	540003a0 	b.eq	570c <e173+0xfc>  // b.none
    569c:	7100045f 	cmp	w2, #0x1
    56a0:	540001a1 	b.ne	56d4 <e173+0xc4>  // b.any
    56a4:	29430002 	ldp	w2, w0, [x0, #24]
    56a8:	92403c21 	and	x1, x1, #0xffff
    56ac:	9b027c21 	mul	x1, x1, x2
    56b0:	d360fc21 	lsr	x1, x1, #32
    56b4:	eb00003f 	cmp	x1, x0
    56b8:	540000e2 	b.cs	56d4 <e173+0xc4>  // b.hs, b.nlast
    56bc:	8b010294 	add	x20, x20, x1
    56c0:	39400280 	ldrb	w0, [x20]
    56c4:	7103fc1f 	cmp	w0, #0xff
    56c8:	54000280 	b.eq	5718 <e173+0x108>  // b.none
    56cc:	52800020 	mov	w0, #0x1                   	// #1
    56d0:	39000280 	strb	w0, [x20]
    56d4:	aa1303e0 	mov	x0, x19
    56d8:	97fffeea 	bl	5280 <fwp_rc_share>
    56dc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    56e0:	f947f400 	ldr	x0, [x0, #4072]
    56e4:	f9400fe2 	ldr	x2, [sp, #24]
    56e8:	f9400001 	ldr	x1, [x0]
    56ec:	eb010042 	subs	x2, x2, x1
    56f0:	d2800001 	mov	x1, #0x0                   	// #0
    56f4:	540001a1 	b.ne	5728 <e173+0x118>  // b.any
    56f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    56fc:	aa1303e0 	mov	x0, x19
    5700:	a94353f3 	ldp	x19, x20, [sp, #48]
    5704:	910103ff 	add	sp, sp, #0x40
    5708:	d65f03c0 	ret
    570c:	72003c3f 	tst	w1, #0xffff
    5710:	54fffe21 	b.ne	56d4 <e173+0xc4>  // b.any
    5714:	17ffffeb 	b	56c0 <e173+0xb0>
    5718:	aa1403e0 	mov	x0, x20
    571c:	97fffb95 	bl	4570 <fwp_rc_forget_slot>
    5720:	17ffffeb 	b	56cc <e173+0xbc>
    5724:	97fff4d7 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5728:	97fff456 	bl	2880 <__stack_chk_fail@plt>
    572c:	d503201f 	nop

0000000000005730 <fwp_drop1>:
    5730:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5734:	910003fd 	mov	x29, sp
    5738:	a90153f3 	stp	x19, x20, [sp, #16]
    573c:	f90013f5 	str	x21, [sp, #32]
    5740:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5744:	911502b4 	add	x20, x21, #0x540
    5748:	f949da81 	ldr	x1, [x20, #5040]
    574c:	f949ee82 	ldr	x2, [x20, #5080]
    5750:	cb010001 	sub	x1, x0, x1
    5754:	eb02403f 	cmp	x1, x2, lsl #16
    5758:	54000382 	b.cs	57c8 <fwp_drop1+0x98>  // b.hs, b.nlast
    575c:	d350fc22 	lsr	x2, x1, #16
    5760:	f949fe84 	ldr	x4, [x20, #5112]
    5764:	8b020842 	add	x2, x2, x2, lsl #2
    5768:	d37df042 	lsl	x2, x2, #3
    576c:	8b020083 	add	x3, x4, x2
    5770:	f9401073 	ldr	x19, [x3, #32]
    5774:	b40002b3 	cbz	x19, 57c8 <fwp_drop1+0x98>
    5778:	38626882 	ldrb	w2, [x4, x2]
    577c:	7100085f 	cmp	w2, #0x2
    5780:	540002c0 	b.eq	57d8 <fwp_drop1+0xa8>  // b.none
    5784:	7100045f 	cmp	w2, #0x1
    5788:	54000201 	b.ne	57c8 <fwp_drop1+0x98>  // b.any
    578c:	29430864 	ldp	w4, w2, [x3, #24]
    5790:	92403c21 	and	x1, x1, #0xffff
    5794:	9b047c21 	mul	x1, x1, x4
    5798:	d360fc21 	lsr	x1, x1, #32
    579c:	eb02003f 	cmp	x1, x2
    57a0:	54000142 	b.cs	57c8 <fwp_drop1+0x98>  // b.hs, b.nlast
    57a4:	8b010273 	add	x19, x19, x1
    57a8:	39400261 	ldrb	w1, [x19]
    57ac:	340000e1 	cbz	w1, 57c8 <fwp_drop1+0x98>
    57b0:	7100043f 	cmp	w1, #0x1
    57b4:	540001e0 	b.eq	57f0 <fwp_drop1+0xc0>  // b.none
    57b8:	7103fc3f 	cmp	w1, #0xff
    57bc:	540002e0 	b.eq	5818 <fwp_drop1+0xe8>  // b.none
    57c0:	51000421 	sub	w1, w1, #0x1
    57c4:	39000261 	strb	w1, [x19]
    57c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    57cc:	f94013f5 	ldr	x21, [sp, #32]
    57d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    57d4:	d65f03c0 	ret
    57d8:	72003c3f 	tst	w1, #0xffff
    57dc:	54fffe60 	b.eq	57a8 <fwp_drop1+0x78>  // b.none
    57e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    57e4:	f94013f5 	ldr	x21, [sp, #32]
    57e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    57ec:	d65f03c0 	ret
    57f0:	f9400813 	ldr	x19, [x0, #16]
    57f4:	97fffef8 	bl	53d4 <fwp_rc_free_arr>
    57f8:	911502a0 	add	x0, x21, #0x540
    57fc:	f949d801 	ldr	x1, [x0, #5040]
    5800:	f949ec00 	ldr	x0, [x0, #5080]
    5804:	cb010261 	sub	x1, x19, x1
    5808:	eb00403f 	cmp	x1, x0, lsl #16
    580c:	54fffde2 	b.cs	57c8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5810:	aa1303e0 	mov	x0, x19
    5814:	17ffffd2 	b	575c <fwp_drop1+0x2c>
    5818:	ca534660 	eor	x0, x19, x19, lsr #17
    581c:	911502b5 	add	x21, x21, #0x540
    5820:	ca402400 	eor	x0, x0, x0, lsr #9
    5824:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5828:	f94a2400 	ldr	x0, [x0, #5192]
    582c:	b5000080 	cbnz	x0, 583c <fwp_drop1+0x10c>
    5830:	14000010 	b	5870 <fwp_drop1+0x140>
    5834:	f9400800 	ldr	x0, [x0, #16]
    5838:	b40001c0 	cbz	x0, 5870 <fwp_drop1+0x140>
    583c:	f9400001 	ldr	x1, [x0]
    5840:	eb13003f 	cmp	x1, x19
    5844:	54ffff81 	b.ne	5834 <fwp_drop1+0x104>  // b.any
    5848:	f9400401 	ldr	x1, [x0, #8]
    584c:	d1000421 	sub	x1, x1, #0x1
    5850:	f9000401 	str	x1, [x0, #8]
    5854:	f103f83f 	cmp	x1, #0xfe
    5858:	54fffb81 	b.ne	57c8 <fwp_drop1+0x98>  // b.any
    585c:	aa1303e0 	mov	x0, x19
    5860:	97fffb44 	bl	4570 <fwp_rc_forget_slot>
    5864:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5868:	39000260 	strb	w0, [x19]
    586c:	17ffffd7 	b	57c8 <fwp_drop1+0x98>
    5870:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    5874:	9137a000 	add	x0, x0, #0xde8
    5878:	97fff742 	bl	3580 <fwp_trap>
    587c:	d503201f 	nop

0000000000005880 <fwp_drop0>:
    5880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5884:	910003fd 	mov	x29, sp
    5888:	a90153f3 	stp	x19, x20, [sp, #16]
    588c:	f90013f5 	str	x21, [sp, #32]
    5890:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5894:	911502b4 	add	x20, x21, #0x540
    5898:	f949da81 	ldr	x1, [x20, #5040]
    589c:	f949ee82 	ldr	x2, [x20, #5080]
    58a0:	cb010001 	sub	x1, x0, x1
    58a4:	eb02403f 	cmp	x1, x2, lsl #16
    58a8:	54000382 	b.cs	5918 <fwp_drop0+0x98>  // b.hs, b.nlast
    58ac:	d350fc22 	lsr	x2, x1, #16
    58b0:	f949fe84 	ldr	x4, [x20, #5112]
    58b4:	8b020842 	add	x2, x2, x2, lsl #2
    58b8:	d37df042 	lsl	x2, x2, #3
    58bc:	8b020083 	add	x3, x4, x2
    58c0:	f9401073 	ldr	x19, [x3, #32]
    58c4:	b40002b3 	cbz	x19, 5918 <fwp_drop0+0x98>
    58c8:	38626882 	ldrb	w2, [x4, x2]
    58cc:	7100085f 	cmp	w2, #0x2
    58d0:	540002c0 	b.eq	5928 <fwp_drop0+0xa8>  // b.none
    58d4:	7100045f 	cmp	w2, #0x1
    58d8:	54000201 	b.ne	5918 <fwp_drop0+0x98>  // b.any
    58dc:	29430864 	ldp	w4, w2, [x3, #24]
    58e0:	92403c21 	and	x1, x1, #0xffff
    58e4:	9b047c21 	mul	x1, x1, x4
    58e8:	d360fc21 	lsr	x1, x1, #32
    58ec:	eb02003f 	cmp	x1, x2
    58f0:	54000142 	b.cs	5918 <fwp_drop0+0x98>  // b.hs, b.nlast
    58f4:	8b010273 	add	x19, x19, x1
    58f8:	39400261 	ldrb	w1, [x19]
    58fc:	340000e1 	cbz	w1, 5918 <fwp_drop0+0x98>
    5900:	7100043f 	cmp	w1, #0x1
    5904:	540001e0 	b.eq	5940 <fwp_drop0+0xc0>  // b.none
    5908:	7103fc3f 	cmp	w1, #0xff
    590c:	540002e0 	b.eq	5968 <fwp_drop0+0xe8>  // b.none
    5910:	51000421 	sub	w1, w1, #0x1
    5914:	39000261 	strb	w1, [x19]
    5918:	a94153f3 	ldp	x19, x20, [sp, #16]
    591c:	f94013f5 	ldr	x21, [sp, #32]
    5920:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5924:	d65f03c0 	ret
    5928:	72003c3f 	tst	w1, #0xffff
    592c:	54fffe60 	b.eq	58f8 <fwp_drop0+0x78>  // b.none
    5930:	a94153f3 	ldp	x19, x20, [sp, #16]
    5934:	f94013f5 	ldr	x21, [sp, #32]
    5938:	a8c37bfd 	ldp	x29, x30, [sp], #48
    593c:	d65f03c0 	ret
    5940:	f9400813 	ldr	x19, [x0, #16]
    5944:	97fffea4 	bl	53d4 <fwp_rc_free_arr>
    5948:	911502a0 	add	x0, x21, #0x540
    594c:	f949d801 	ldr	x1, [x0, #5040]
    5950:	f949ec00 	ldr	x0, [x0, #5080]
    5954:	cb010261 	sub	x1, x19, x1
    5958:	eb00403f 	cmp	x1, x0, lsl #16
    595c:	54fffde2 	b.cs	5918 <fwp_drop0+0x98>  // b.hs, b.nlast
    5960:	aa1303e0 	mov	x0, x19
    5964:	17ffffd2 	b	58ac <fwp_drop0+0x2c>
    5968:	ca534660 	eor	x0, x19, x19, lsr #17
    596c:	911502b5 	add	x21, x21, #0x540
    5970:	ca402400 	eor	x0, x0, x0, lsr #9
    5974:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5978:	f94a2400 	ldr	x0, [x0, #5192]
    597c:	b5000080 	cbnz	x0, 598c <fwp_drop0+0x10c>
    5980:	14000010 	b	59c0 <fwp_drop0+0x140>
    5984:	f9400800 	ldr	x0, [x0, #16]
    5988:	b40001c0 	cbz	x0, 59c0 <fwp_drop0+0x140>
    598c:	f9400001 	ldr	x1, [x0]
    5990:	eb13003f 	cmp	x1, x19
    5994:	54ffff81 	b.ne	5984 <fwp_drop0+0x104>  // b.any
    5998:	f9400401 	ldr	x1, [x0, #8]
    599c:	d1000421 	sub	x1, x1, #0x1
    59a0:	f9000401 	str	x1, [x0, #8]
    59a4:	f103f83f 	cmp	x1, #0xfe
    59a8:	54fffb81 	b.ne	5918 <fwp_drop0+0x98>  // b.any
    59ac:	aa1303e0 	mov	x0, x19
    59b0:	97fffaf0 	bl	4570 <fwp_rc_forget_slot>
    59b4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    59b8:	39000260 	strb	w0, [x19]
    59bc:	17ffffd7 	b	5918 <fwp_drop0+0x98>
    59c0:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    59c4:	9137a000 	add	x0, x0, #0xde8
    59c8:	97fff6ee 	bl	3580 <fwp_trap>
    59cc:	d503201f 	nop

00000000000059d0 <fwp_closure_drop>:
    59d0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    59d4:	911500a4 	add	x4, x5, #0x540
    59d8:	aa0003e1 	mov	x1, x0
    59dc:	f949d882 	ldr	x2, [x4, #5040]
    59e0:	f949ec80 	ldr	x0, [x4, #5080]
    59e4:	cb020022 	sub	x2, x1, x2
    59e8:	eb00405f 	cmp	x2, x0, lsl #16
    59ec:	54000662 	b.cs	5ab8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    59f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    59f4:	d350fc43 	lsr	x3, x2, #16
    59f8:	910003fd 	mov	x29, sp
    59fc:	8b030863 	add	x3, x3, x3, lsl #2
    5a00:	f949fc84 	ldr	x4, [x4, #5112]
    5a04:	d37df063 	lsl	x3, x3, #3
    5a08:	f9000bf3 	str	x19, [sp, #16]
    5a0c:	8b030080 	add	x0, x4, x3
    5a10:	f9401013 	ldr	x19, [x0, #32]
    5a14:	b40002b3 	cbz	x19, 5a68 <fwp_closure_drop+0x98>
    5a18:	38636883 	ldrb	w3, [x4, x3]
    5a1c:	7100087f 	cmp	w3, #0x2
    5a20:	54000420 	b.eq	5aa4 <fwp_closure_drop+0xd4>  // b.none
    5a24:	7100047f 	cmp	w3, #0x1
    5a28:	54000201 	b.ne	5a68 <fwp_closure_drop+0x98>  // b.any
    5a2c:	29430003 	ldp	w3, w0, [x0, #24]
    5a30:	92403c42 	and	x2, x2, #0xffff
    5a34:	9b037c42 	mul	x2, x2, x3
    5a38:	d360fc42 	lsr	x2, x2, #32
    5a3c:	eb00005f 	cmp	x2, x0
    5a40:	54000142 	b.cs	5a68 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5a44:	8b020273 	add	x19, x19, x2
    5a48:	39400260 	ldrb	w0, [x19]
    5a4c:	340000e0 	cbz	w0, 5a68 <fwp_closure_drop+0x98>
    5a50:	7100041f 	cmp	w0, #0x1
    5a54:	54000100 	b.eq	5a74 <fwp_closure_drop+0xa4>  // b.none
    5a58:	7103fc1f 	cmp	w0, #0xff
    5a5c:	54000300 	b.eq	5abc <fwp_closure_drop+0xec>  // b.none
    5a60:	51000400 	sub	w0, w0, #0x1
    5a64:	39000260 	strb	w0, [x19]
    5a68:	f9400bf3 	ldr	x19, [sp, #16]
    5a6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a70:	d65f03c0 	ret
    5a74:	d53bd040 	mrs	x0, tpidr_el0
    5a78:	91400000 	add	x0, x0, #0x0, lsl #12
    5a7c:	91004000 	add	x0, x0, #0x10
    5a80:	f9400000 	ldr	x0, [x0]
    5a84:	b4000080 	cbz	x0, 5a94 <fwp_closure_drop+0xc4>
    5a88:	f9400bf3 	ldr	x19, [sp, #16]
    5a8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a90:	17fff6d5 	b	35e4 <fwp_closure_drop_push>
    5a94:	f9400bf3 	ldr	x19, [sp, #16]
    5a98:	aa0103e0 	mov	x0, x1
    5a9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5aa0:	17fff740 	b	37a0 <fwp_closure_drop.part.0>
    5aa4:	72003c5f 	tst	w2, #0xffff
    5aa8:	54fffd00 	b.eq	5a48 <fwp_closure_drop+0x78>  // b.none
    5aac:	f9400bf3 	ldr	x19, [sp, #16]
    5ab0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ab4:	d65f03c0 	ret
    5ab8:	d65f03c0 	ret
    5abc:	ca534660 	eor	x0, x19, x19, lsr #17
    5ac0:	911500a5 	add	x5, x5, #0x540
    5ac4:	ca402400 	eor	x0, x0, x0, lsr #9
    5ac8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5acc:	f94a2400 	ldr	x0, [x0, #5192]
    5ad0:	b5000080 	cbnz	x0, 5ae0 <fwp_closure_drop+0x110>
    5ad4:	14000010 	b	5b14 <fwp_closure_drop+0x144>
    5ad8:	f9400800 	ldr	x0, [x0, #16]
    5adc:	b40001c0 	cbz	x0, 5b14 <fwp_closure_drop+0x144>
    5ae0:	f9400001 	ldr	x1, [x0]
    5ae4:	eb13003f 	cmp	x1, x19
    5ae8:	54ffff81 	b.ne	5ad8 <fwp_closure_drop+0x108>  // b.any
    5aec:	f9400401 	ldr	x1, [x0, #8]
    5af0:	d1000421 	sub	x1, x1, #0x1
    5af4:	f9000401 	str	x1, [x0, #8]
    5af8:	f103f83f 	cmp	x1, #0xfe
    5afc:	54fffb61 	b.ne	5a68 <fwp_closure_drop+0x98>  // b.any
    5b00:	aa1303e0 	mov	x0, x19
    5b04:	97fffa9b 	bl	4570 <fwp_rc_forget_slot>
    5b08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b0c:	39000260 	strb	w0, [x19]
    5b10:	17ffffd6 	b	5a68 <fwp_closure_drop+0x98>
    5b14:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    5b18:	9137a000 	add	x0, x0, #0xde8
    5b1c:	97fff699 	bl	3580 <fwp_trap>

0000000000005b20 <fwp_owned_tape_release>:
    5b20:	b4000940 	cbz	x0, 5c48 <fwp_owned_tape_release+0x128>
    5b24:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b28:	910003fd 	mov	x29, sp
    5b2c:	a90153f3 	stp	x19, x20, [sp, #16]
    5b30:	aa0003f3 	mov	x19, x0
    5b34:	f9400000 	ldr	x0, [x0]
    5b38:	b4000060 	cbz	x0, 5b44 <fwp_owned_tape_release+0x24>
    5b3c:	f9400661 	ldr	x1, [x19, #8]
    5b40:	f9000401 	str	x1, [x0, #8]
    5b44:	f9400661 	ldr	x1, [x19, #8]
    5b48:	b4000041 	cbz	x1, 5b50 <fwp_owned_tape_release+0x30>
    5b4c:	f9000020 	str	x0, [x1]
    5b50:	f9400a60 	ldr	x0, [x19, #16]
    5b54:	f9403401 	ldr	x1, [x0, #104]
    5b58:	b40005c1 	cbz	x1, 5c10 <fwp_owned_tape_release+0xf0>
    5b5c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5b60:	eb00005f 	cmp	x2, x0
    5b64:	540002ed 	b.le	5bc0 <fwp_owned_tape_release+0xa0>
    5b68:	d2800014 	mov	x20, #0x0                   	// #0
    5b6c:	f90013f5 	str	x21, [sp, #32]
    5b70:	d2800015 	mov	x21, #0x0                   	// #0
    5b74:	d503201f 	nop
    5b78:	f9402260 	ldr	x0, [x19, #64]
    5b7c:	910006b5 	add	x21, x21, #0x1
    5b80:	f8746800 	ldr	x0, [x0, x20]
    5b84:	d63f0020 	blr	x1
    5b88:	f9402260 	ldr	x0, [x19, #64]
    5b8c:	f9400a61 	ldr	x1, [x19, #16]
    5b90:	8b140000 	add	x0, x0, x20
    5b94:	91004294 	add	x20, x20, #0x10
    5b98:	f9400400 	ldr	x0, [x0, #8]
    5b9c:	f9403421 	ldr	x1, [x1, #104]
    5ba0:	d63f0020 	blr	x1
    5ba4:	a9450261 	ldp	x1, x0, [x19, #80]
    5ba8:	cb010000 	sub	x0, x0, x1
    5bac:	eb15001f 	cmp	x0, x21
    5bb0:	f9400a60 	ldr	x0, [x19, #16]
    5bb4:	f9403401 	ldr	x1, [x0, #104]
    5bb8:	54fffe0c 	b.gt	5b78 <fwp_owned_tape_release+0x58>
    5bbc:	f94013f5 	ldr	x21, [sp, #32]
    5bc0:	f9403663 	ldr	x3, [x19, #104]
    5bc4:	f9401262 	ldr	x2, [x19, #32]
    5bc8:	f100007f 	cmp	x3, #0x0
    5bcc:	540001ed 	b.le	5c08 <fwp_owned_tape_release+0xe8>
    5bd0:	d2800014 	mov	x20, #0x0                   	// #0
    5bd4:	d503201f 	nop
    5bd8:	f9402660 	ldr	x0, [x19, #72]
    5bdc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5be0:	eb02001f 	cmp	x0, x2
    5be4:	540000c0 	b.eq	5bfc <fwp_owned_tape_release+0xdc>  // b.none
    5be8:	d63f0020 	blr	x1
    5bec:	f9400a60 	ldr	x0, [x19, #16]
    5bf0:	f9401262 	ldr	x2, [x19, #32]
    5bf4:	f9403663 	ldr	x3, [x19, #104]
    5bf8:	f9403401 	ldr	x1, [x0, #104]
    5bfc:	91000694 	add	x20, x20, #0x1
    5c00:	eb14007f 	cmp	x3, x20
    5c04:	54fffeac 	b.gt	5bd8 <fwp_owned_tape_release+0xb8>
    5c08:	aa0203e0 	mov	x0, x2
    5c0c:	d63f0020 	blr	x1
    5c10:	f9401660 	ldr	x0, [x19, #40]
    5c14:	97ffff6f 	bl	59d0 <fwp_closure_drop>
    5c18:	f9401a60 	ldr	x0, [x19, #48]
    5c1c:	97ffff6d 	bl	59d0 <fwp_closure_drop>
    5c20:	f9401e60 	ldr	x0, [x19, #56]
    5c24:	97ffff6b 	bl	59d0 <fwp_closure_drop>
    5c28:	f9402260 	ldr	x0, [x19, #64]
    5c2c:	97fffaf1 	bl	47f0 <fwp_mem_free>
    5c30:	f9402660 	ldr	x0, [x19, #72]
    5c34:	97fffaef 	bl	47f0 <fwp_mem_free>
    5c38:	aa1303e0 	mov	x0, x19
    5c3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c44:	17fffaeb 	b	47f0 <fwp_mem_free>
    5c48:	d65f03c0 	ret
    5c4c:	d503201f 	nop

0000000000005c50 <fwp_tape_finish>:
    5c50:	d10203ff 	sub	sp, sp, #0x80
    5c54:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5c58:	f947f421 	ldr	x1, [x1, #4072]
    5c5c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5c60:	910103fd 	add	x29, sp, #0x40
    5c64:	a90553f3 	stp	x19, x20, [sp, #80]
    5c68:	a9065bf5 	stp	x21, x22, [sp, #96]
    5c6c:	a90763f7 	stp	x23, x24, [sp, #112]
    5c70:	f00000d8 	adrp	x24, 20000 <__data_start>
    5c74:	9100c316 	add	x22, x24, #0x30
    5c78:	f9400022 	ldr	x2, [x1]
    5c7c:	f9001fe2 	str	x2, [sp, #56]
    5c80:	d2800002 	mov	x2, #0x0                   	// #0
    5c84:	910122c0 	add	x0, x22, #0x48
    5c88:	97fff59e 	bl	3300 <fwp_tape_buffers_dispose>
    5c8c:	f90042df 	str	xzr, [x22, #128]
    5c90:	f94022c0 	ldr	x0, [x22, #64]
    5c94:	f100001f 	cmp	x0, #0x0
    5c98:	5400030d 	b.le	5cf8 <fwp_tape_finish+0xa8>
    5c9c:	910003f7 	mov	x23, sp
    5ca0:	d2800015 	mov	x21, #0x0                   	// #0
    5ca4:	d2800014 	mov	x20, #0x0                   	// #0
    5ca8:	f94002d3 	ldr	x19, [x22]
    5cac:	91000694 	add	x20, x20, #0x1
    5cb0:	8b150273 	add	x19, x19, x21
    5cb4:	9101a2b5 	add	x21, x21, #0x68
    5cb8:	aa1303e0 	mov	x0, x19
    5cbc:	97fff4b5 	bl	2f90 <fwp_tape_unlink_scope>
    5cc0:	aa1703e0 	mov	x0, x23
    5cc4:	f9401261 	ldr	x1, [x19, #32]
    5cc8:	f90003e1 	str	x1, [sp]
    5ccc:	f9401a62 	ldr	x2, [x19, #48]
    5cd0:	f9000be2 	str	x2, [sp, #16]
    5cd4:	f9402261 	ldr	x1, [x19, #64]
    5cd8:	f90013e1 	str	x1, [sp, #32]
    5cdc:	97fff589 	bl	3300 <fwp_tape_buffers_dispose>
    5ce0:	f9403260 	ldr	x0, [x19, #96]
    5ce4:	97ffff8f 	bl	5b20 <fwp_owned_tape_release>
    5ce8:	f900327f 	str	xzr, [x19, #96]
    5cec:	f94022c0 	ldr	x0, [x22, #64]
    5cf0:	eb14001f 	cmp	x0, x20
    5cf4:	54fffdac 	b.gt	5ca8 <fwp_tape_finish+0x58>
    5cf8:	f9401b00 	ldr	x0, [x24, #48]
    5cfc:	9100c313 	add	x19, x24, #0x30
    5d00:	97fff310 	bl	2940 <free@plt>
    5d04:	f9001b1f 	str	xzr, [x24, #48]
    5d08:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5d0c:	f947f400 	ldr	x0, [x0, #4072]
    5d10:	f900227f 	str	xzr, [x19, #64]
    5d14:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5d18:	f9401fe2 	ldr	x2, [sp, #56]
    5d1c:	f9400001 	ldr	x1, [x0]
    5d20:	eb010042 	subs	x2, x2, x1
    5d24:	d2800001 	mov	x1, #0x0                   	// #0
    5d28:	540000e1 	b.ne	5d44 <fwp_tape_finish+0xf4>  // b.any
    5d2c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5d30:	a94553f3 	ldp	x19, x20, [sp, #80]
    5d34:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5d38:	a94763f7 	ldp	x23, x24, [sp, #112]
    5d3c:	910203ff 	add	sp, sp, #0x80
    5d40:	d65f03c0 	ret
    5d44:	97fff2cf 	bl	2880 <__stack_chk_fail@plt>
    5d48:	d503201f 	nop
    5d4c:	d503201f 	nop

0000000000005d50 <fwp_tape_scope_release>:
    5d50:	d10243ff 	sub	sp, sp, #0x90
    5d54:	a9047bfd 	stp	x29, x30, [sp, #64]
    5d58:	910103fd 	add	x29, sp, #0x40
    5d5c:	a90553f3 	stp	x19, x20, [sp, #80]
    5d60:	aa0003f4 	mov	x20, x0
    5d64:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5d68:	f947f400 	ldr	x0, [x0, #4072]
    5d6c:	b9400285 	ldr	w5, [x20]
    5d70:	f9400001 	ldr	x1, [x0]
    5d74:	f9001fe1 	str	x1, [sp, #56]
    5d78:	d2800001 	mov	x1, #0x0                   	// #0
    5d7c:	37f806c5 	tbnz	w5, #31, 5e54 <fwp_tape_scope_release+0x104>
    5d80:	a90763f7 	stp	x23, x24, [sp, #112]
    5d84:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5d88:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5d8c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5d90:	f00000d3 	adrp	x19, 20000 <__data_start>
    5d94:	910003f7 	mov	x23, sp
    5d98:	9100c273 	add	x19, x19, #0x30
    5d9c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5da0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5da4:	52800d16 	mov	w22, #0x68                  	// #104
    5da8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5dac:	f90043f9 	str	x25, [sp, #128]
    5db0:	14000006 	b	5dc8 <fwp_tape_scope_release+0x78>
    5db4:	97fff553 	bl	3300 <fwp_tape_buffers_dispose>
    5db8:	aa1903e0 	mov	x0, x25
    5dbc:	97ffff59 	bl	5b20 <fwp_owned_tape_release>
    5dc0:	b9400285 	ldr	w5, [x20]
    5dc4:	37f80425 	tbnz	w5, #31, 5e48 <fwp_tape_scope_release+0xf8>
    5dc8:	f9400266 	ldr	x6, [x19]
    5dcc:	9b367ca5 	smull	x5, w5, w22
    5dd0:	8b0500c0 	add	x0, x6, x5
    5dd4:	97fff46f 	bl	2f90 <fwp_tape_unlink_scope>
    5dd8:	ad410001 	ldp	q1, q0, [x0, #32]
    5ddc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5de0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5de4:	f9400c03 	ldr	x3, [x0, #24]
    5de8:	ad0003e1 	stp	q1, q0, [sp]
    5dec:	b86568c1 	ldr	w1, [x6, x5]
    5df0:	a9440804 	ldp	x4, x2, [x0, #64]
    5df4:	b900041f 	str	wzr, [x0, #4]
    5df8:	f9403019 	ldr	x25, [x0, #96]
    5dfc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5e00:	f9000c1f 	str	xzr, [x0, #24]
    5e04:	a9020fe4 	stp	x4, x3, [sp, #32]
    5e08:	f9001be2 	str	x2, [sp, #48]
    5e0c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5e10:	f900301f 	str	xzr, [x0, #96]
    5e14:	6b15003f 	cmp	w1, w21
    5e18:	540000e8 	b.hi	5e34 <fwp_tape_scope_release+0xe4>  // b.pmore
    5e1c:	9343fca5 	asr	x5, x5, #3
    5e20:	f9404e60 	ldr	x0, [x19, #152]
    5e24:	9b187ca5 	mul	x5, x5, x24
    5e28:	eb0000bf 	cmp	x5, x0
    5e2c:	5400004a 	b.ge	5e34 <fwp_tape_scope_release+0xe4>  // b.tcont
    5e30:	f9004e65 	str	x5, [x19, #152]
    5e34:	aa1703e0 	mov	x0, x23
    5e38:	b5fffbf9 	cbnz	x25, 5db4 <fwp_tape_scope_release+0x64>
    5e3c:	97fff8b1 	bl	4100 <fwp_tape_buffers_release>
    5e40:	b9400285 	ldr	w5, [x20]
    5e44:	36fffc25 	tbz	w5, #31, 5dc8 <fwp_tape_scope_release+0x78>
    5e48:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5e4c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5e50:	f94043f9 	ldr	x25, [sp, #128]
    5e54:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5e58:	f947f400 	ldr	x0, [x0, #4072]
    5e5c:	f9401fe2 	ldr	x2, [sp, #56]
    5e60:	f9400001 	ldr	x1, [x0]
    5e64:	eb010042 	subs	x2, x2, x1
    5e68:	d2800001 	mov	x1, #0x0                   	// #0
    5e6c:	540000a1 	b.ne	5e80 <fwp_tape_scope_release+0x130>  // b.any
    5e70:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5e74:	a94553f3 	ldp	x19, x20, [sp, #80]
    5e78:	910243ff 	add	sp, sp, #0x90
    5e7c:	d65f03c0 	ret
    5e80:	a9065bf5 	stp	x21, x22, [sp, #96]
    5e84:	a90763f7 	stp	x23, x24, [sp, #112]
    5e88:	f90043f9 	str	x25, [sp, #128]
    5e8c:	97fff27d 	bl	2880 <__stack_chk_fail@plt>

0000000000005e90 <fwp_drop4>:
    5e90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e94:	910003fd 	mov	x29, sp
    5e98:	a9025bf5 	stp	x21, x22, [sp, #32]
    5e9c:	90000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    5ea0:	911502d5 	add	x21, x22, #0x540
    5ea4:	a90153f3 	stp	x19, x20, [sp, #16]
    5ea8:	aa0003f3 	mov	x19, x0
    5eac:	f949daa1 	ldr	x1, [x21, #5040]
    5eb0:	f949eea0 	ldr	x0, [x21, #5080]
    5eb4:	cb010261 	sub	x1, x19, x1
    5eb8:	eb00403f 	cmp	x1, x0, lsl #16
    5ebc:	54000382 	b.cs	5f2c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5ec0:	d350fc22 	lsr	x2, x1, #16
    5ec4:	f949fea3 	ldr	x3, [x21, #5112]
    5ec8:	8b020842 	add	x2, x2, x2, lsl #2
    5ecc:	d37df042 	lsl	x2, x2, #3
    5ed0:	8b020060 	add	x0, x3, x2
    5ed4:	f9401014 	ldr	x20, [x0, #32]
    5ed8:	b40002b4 	cbz	x20, 5f2c <fwp_drop4+0x9c>
    5edc:	38626862 	ldrb	w2, [x3, x2]
    5ee0:	7100085f 	cmp	w2, #0x2
    5ee4:	540002c0 	b.eq	5f3c <fwp_drop4+0xac>  // b.none
    5ee8:	7100045f 	cmp	w2, #0x1
    5eec:	54000201 	b.ne	5f2c <fwp_drop4+0x9c>  // b.any
    5ef0:	29430002 	ldp	w2, w0, [x0, #24]
    5ef4:	92403c21 	and	x1, x1, #0xffff
    5ef8:	9b027c21 	mul	x1, x1, x2
    5efc:	d360fc21 	lsr	x1, x1, #32
    5f00:	eb00003f 	cmp	x1, x0
    5f04:	54000142 	b.cs	5f2c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5f08:	8b010294 	add	x20, x20, x1
    5f0c:	39400280 	ldrb	w0, [x20]
    5f10:	340000e0 	cbz	w0, 5f2c <fwp_drop4+0x9c>
    5f14:	7100041f 	cmp	w0, #0x1
    5f18:	540001e0 	b.eq	5f54 <fwp_drop4+0xc4>  // b.none
    5f1c:	7103fc1f 	cmp	w0, #0xff
    5f20:	540007c0 	b.eq	6018 <fwp_drop4+0x188>  // b.none
    5f24:	51000400 	sub	w0, w0, #0x1
    5f28:	39000280 	strb	w0, [x20]
    5f2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5f34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f38:	d65f03c0 	ret
    5f3c:	72003c3f 	tst	w1, #0xffff
    5f40:	54fffe60 	b.eq	5f0c <fwp_drop4+0x7c>  // b.none
    5f44:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f48:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5f4c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f50:	d65f03c0 	ret
    5f54:	911502c2 	add	x2, x22, #0x540
    5f58:	f9400660 	ldr	x0, [x19, #8]
    5f5c:	f949d841 	ldr	x1, [x2, #5040]
    5f60:	f949ec42 	ldr	x2, [x2, #5080]
    5f64:	cb010001 	sub	x1, x0, x1
    5f68:	eb02403f 	cmp	x1, x2, lsl #16
    5f6c:	54000362 	b.cs	5fd8 <fwp_drop4+0x148>  // b.hs, b.nlast
    5f70:	d350fc22 	lsr	x2, x1, #16
    5f74:	8b020842 	add	x2, x2, x2, lsl #2
    5f78:	d37df042 	lsl	x2, x2, #3
    5f7c:	8b020064 	add	x4, x3, x2
    5f80:	f9401094 	ldr	x20, [x4, #32]
    5f84:	b40002b4 	cbz	x20, 5fd8 <fwp_drop4+0x148>
    5f88:	38626862 	ldrb	w2, [x3, x2]
    5f8c:	7100085f 	cmp	w2, #0x2
    5f90:	540003e0 	b.eq	600c <fwp_drop4+0x17c>  // b.none
    5f94:	7100045f 	cmp	w2, #0x1
    5f98:	54000201 	b.ne	5fd8 <fwp_drop4+0x148>  // b.any
    5f9c:	29430883 	ldp	w3, w2, [x4, #24]
    5fa0:	92403c21 	and	x1, x1, #0xffff
    5fa4:	9b037c21 	mul	x1, x1, x3
    5fa8:	d360fc21 	lsr	x1, x1, #32
    5fac:	eb02003f 	cmp	x1, x2
    5fb0:	54000142 	b.cs	5fd8 <fwp_drop4+0x148>  // b.hs, b.nlast
    5fb4:	8b010294 	add	x20, x20, x1
    5fb8:	39400281 	ldrb	w1, [x20]
    5fbc:	340000e1 	cbz	w1, 5fd8 <fwp_drop4+0x148>
    5fc0:	7100043f 	cmp	w1, #0x1
    5fc4:	54000200 	b.eq	6004 <fwp_drop4+0x174>  // b.none
    5fc8:	7103fc3f 	cmp	w1, #0xff
    5fcc:	54000580 	b.eq	607c <fwp_drop4+0x1ec>  // b.none
    5fd0:	51000421 	sub	w1, w1, #0x1
    5fd4:	39000281 	strb	w1, [x20]
    5fd8:	f9400a74 	ldr	x20, [x19, #16]
    5fdc:	aa1303e0 	mov	x0, x19
    5fe0:	97fffcfd 	bl	53d4 <fwp_rc_free_arr>
    5fe4:	911502c0 	add	x0, x22, #0x540
    5fe8:	f949d801 	ldr	x1, [x0, #5040]
    5fec:	f949ec00 	ldr	x0, [x0, #5080]
    5ff0:	cb010281 	sub	x1, x20, x1
    5ff4:	eb00403f 	cmp	x1, x0, lsl #16
    5ff8:	54fff9a2 	b.cs	5f2c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5ffc:	aa1403f3 	mov	x19, x20
    6000:	17ffffb0 	b	5ec0 <fwp_drop4+0x30>
    6004:	97fffcf4 	bl	53d4 <fwp_rc_free_arr>
    6008:	17fffff4 	b	5fd8 <fwp_drop4+0x148>
    600c:	72003c3f 	tst	w1, #0xffff
    6010:	54fffe41 	b.ne	5fd8 <fwp_drop4+0x148>  // b.any
    6014:	17ffffe9 	b	5fb8 <fwp_drop4+0x128>
    6018:	ca544681 	eor	x1, x20, x20, lsr #17
    601c:	911502c0 	add	x0, x22, #0x540
    6020:	ca412421 	eor	x1, x1, x1, lsr #9
    6024:	8b210c01 	add	x1, x0, w1, uxtb #3
    6028:	f94a2420 	ldr	x0, [x1, #5192]
    602c:	b5000080 	cbnz	x0, 603c <fwp_drop4+0x1ac>
    6030:	14000010 	b	6070 <fwp_drop4+0x1e0>
    6034:	f9400800 	ldr	x0, [x0, #16]
    6038:	b40001c0 	cbz	x0, 6070 <fwp_drop4+0x1e0>
    603c:	f9400001 	ldr	x1, [x0]
    6040:	eb14003f 	cmp	x1, x20
    6044:	54ffff81 	b.ne	6034 <fwp_drop4+0x1a4>  // b.any
    6048:	f9400401 	ldr	x1, [x0, #8]
    604c:	d1000421 	sub	x1, x1, #0x1
    6050:	f9000401 	str	x1, [x0, #8]
    6054:	f103f83f 	cmp	x1, #0xfe
    6058:	54fff6a1 	b.ne	5f2c <fwp_drop4+0x9c>  // b.any
    605c:	aa1403e0 	mov	x0, x20
    6060:	97fff944 	bl	4570 <fwp_rc_forget_slot>
    6064:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6068:	39000280 	strb	w0, [x20]
    606c:	17ffffb0 	b	5f2c <fwp_drop4+0x9c>
    6070:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    6074:	9137a000 	add	x0, x0, #0xde8
    6078:	97fff542 	bl	3580 <fwp_trap>
    607c:	ca544680 	eor	x0, x20, x20, lsr #17
    6080:	911502c1 	add	x1, x22, #0x540
    6084:	ca402400 	eor	x0, x0, x0, lsr #9
    6088:	8b200c20 	add	x0, x1, w0, uxtb #3
    608c:	f94a2400 	ldr	x0, [x0, #5192]
    6090:	b5000080 	cbnz	x0, 60a0 <fwp_drop4+0x210>
    6094:	17fffff7 	b	6070 <fwp_drop4+0x1e0>
    6098:	f9400800 	ldr	x0, [x0, #16]
    609c:	b4fffea0 	cbz	x0, 6070 <fwp_drop4+0x1e0>
    60a0:	f9400001 	ldr	x1, [x0]
    60a4:	eb14003f 	cmp	x1, x20
    60a8:	54ffff81 	b.ne	6098 <fwp_drop4+0x208>  // b.any
    60ac:	f9400401 	ldr	x1, [x0, #8]
    60b0:	d1000421 	sub	x1, x1, #0x1
    60b4:	f9000401 	str	x1, [x0, #8]
    60b8:	f103f83f 	cmp	x1, #0xfe
    60bc:	54fff8e1 	b.ne	5fd8 <fwp_drop4+0x148>  // b.any
    60c0:	aa1403e0 	mov	x0, x20
    60c4:	97fff92b 	bl	4570 <fwp_rc_forget_slot>
    60c8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    60cc:	39000280 	strb	w0, [x20]
    60d0:	17ffffc2 	b	5fd8 <fwp_drop4+0x148>

00000000000060d4 <fwp_arg_drop37>:
    60d4:	7100003f 	cmp	w1, #0x0
    60d8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    60dc:	54000041 	b.ne	60e4 <fwp_arg_drop37+0x10>  // b.any
    60e0:	d65f03c0 	ret
    60e4:	f9400000 	ldr	x0, [x0]
    60e8:	17ffff6a 	b	5e90 <fwp_drop4>
    60ec:	d503201f 	nop

00000000000060f0 <fwp_task_dispose>:
    60f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    60f4:	910003fd 	mov	x29, sp
    60f8:	f9000bf3 	str	x19, [sp, #16]
    60fc:	aa0003f3 	mov	x19, x0
    6100:	39414000 	ldrb	w0, [x0, #80]
    6104:	36000720 	tbz	w0, #0, 61e8 <fwp_task_dispose+0xf8>
    6108:	f9400a60 	ldr	x0, [x19, #16]
    610c:	b50006e0 	cbnz	x0, 61e8 <fwp_task_dispose+0xf8>
    6110:	a9478660 	ldp	x0, x1, [x19, #120]
    6114:	39014e7f 	strb	wzr, [x19, #83]
    6118:	f9003e7f 	str	xzr, [x19, #120]
    611c:	f100003f 	cmp	x1, #0x0
    6120:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6124:	54000040 	b.eq	612c <fwp_task_dispose+0x3c>  // b.none
    6128:	d63f0020 	blr	x1
    612c:	f9405660 	ldr	x0, [x19, #168]
    6130:	97fff9b0 	bl	47f0 <fwp_mem_free>
    6134:	f900567f 	str	xzr, [x19, #168]
    6138:	b9405e60 	ldr	w0, [x19, #92]
    613c:	7100041f 	cmp	w0, #0x1
    6140:	54000420 	b.eq	61c4 <fwp_task_dispose+0xd4>  // b.none
    6144:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6148:	91150042 	add	x2, x2, #0x540
    614c:	f949d840 	ldr	x0, [x2, #5040]
    6150:	f949ec41 	ldr	x1, [x2, #5080]
    6154:	cb000260 	sub	x0, x19, x0
    6158:	eb01401f 	cmp	x0, x1, lsl #16
    615c:	540002e2 	b.cs	61b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6160:	d350fc01 	lsr	x1, x0, #16
    6164:	f949fc44 	ldr	x4, [x2, #5112]
    6168:	8b010821 	add	x1, x1, x1, lsl #2
    616c:	d37df021 	lsl	x1, x1, #3
    6170:	8b010083 	add	x3, x4, x1
    6174:	f9401062 	ldr	x2, [x3, #32]
    6178:	b4000202 	cbz	x2, 61b8 <fwp_task_dispose+0xc8>
    617c:	38616881 	ldrb	w1, [x4, x1]
    6180:	7100083f 	cmp	w1, #0x2
    6184:	54000280 	b.eq	61d4 <fwp_task_dispose+0xe4>  // b.none
    6188:	7100043f 	cmp	w1, #0x1
    618c:	54000161 	b.ne	61b8 <fwp_task_dispose+0xc8>  // b.any
    6190:	29430464 	ldp	w4, w1, [x3, #24]
    6194:	92403c00 	and	x0, x0, #0xffff
    6198:	9b047c00 	mul	x0, x0, x4
    619c:	d360fc00 	lsr	x0, x0, #32
    61a0:	eb01001f 	cmp	x0, x1
    61a4:	540000a2 	b.cs	61b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    61a8:	8b000042 	add	x2, x2, x0
    61ac:	39400040 	ldrb	w0, [x2]
    61b0:	7100041f 	cmp	w0, #0x1
    61b4:	54000080 	b.eq	61c4 <fwp_task_dispose+0xd4>  // b.none
    61b8:	f9400bf3 	ldr	x19, [sp, #16]
    61bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61c0:	d65f03c0 	ret
    61c4:	aa1303e0 	mov	x0, x19
    61c8:	f9400bf3 	ldr	x19, [sp, #16]
    61cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d0:	17fff988 	b	47f0 <fwp_mem_free>
    61d4:	72003c1f 	tst	w0, #0xffff
    61d8:	54fffea0 	b.eq	61ac <fwp_task_dispose+0xbc>  // b.none
    61dc:	f9400bf3 	ldr	x19, [sp, #16]
    61e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61e4:	d65f03c0 	ret
    61e8:	97fff1ba 	bl	28d0 <abort@plt>
    61ec:	d503201f 	nop

00000000000061f0 <fwp_free_zombie>:
    61f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61f4:	910003fd 	mov	x29, sp
    61f8:	a90153f3 	stp	x19, x20, [sp, #16]
    61fc:	d00000d4 	adrp	x20, 20000 <__data_start>
    6200:	9100c281 	add	x1, x20, #0x30
    6204:	f9405033 	ldr	x19, [x1, #160]
    6208:	b4000333 	cbz	x19, 626c <fwp_free_zombie+0x7c>
    620c:	f9400820 	ldr	x0, [x1, #16]
    6210:	eb00027f 	cmp	x19, x0
    6214:	540002c0 	b.eq	626c <fwp_free_zombie+0x7c>  // b.none
    6218:	b940a822 	ldr	w2, [x1, #168]
    621c:	f9400a60 	ldr	x0, [x19, #16]
    6220:	7100fc5f 	cmp	w2, #0x3f
    6224:	5400078c 	b.gt	6314 <fwp_free_zombie+0x124>
    6228:	9102c023 	add	x3, x1, #0xb0
    622c:	11000444 	add	w4, w2, #0x1
    6230:	b900a824 	str	w4, [x1, #168]
    6234:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6238:	f822d860 	str	x0, [x3, w2, sxtw #3]
    623c:	a9530261 	ldp	x1, x0, [x19, #304]
    6240:	b4000741 	cbz	x1, 6328 <fwp_free_zombie+0x138>
    6244:	f9009c20 	str	x0, [x1, #312]
    6248:	b4000040 	cbz	x0, 6250 <fwp_free_zombie+0x60>
    624c:	f9009801 	str	x1, [x0, #304]
    6250:	9100c294 	add	x20, x20, #0x30
    6254:	b9405e60 	ldr	w0, [x19, #92]
    6258:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    625c:	f900529f 	str	xzr, [x20, #160]
    6260:	34000140 	cbz	w0, 6288 <fwp_free_zombie+0x98>
    6264:	7100041f 	cmp	w0, #0x1
    6268:	54000080 	b.eq	6278 <fwp_free_zombie+0x88>  // b.none
    626c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6270:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6274:	d65f03c0 	ret
    6278:	aa1303e0 	mov	x0, x19
    627c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6280:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6284:	17ffff9b 	b	60f0 <fwp_task_dispose>
    6288:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xca0>
    628c:	91150082 	add	x2, x4, #0x540
    6290:	f949d841 	ldr	x1, [x2, #5040]
    6294:	f949ec40 	ldr	x0, [x2, #5080]
    6298:	cb010261 	sub	x1, x19, x1
    629c:	eb00403f 	cmp	x1, x0, lsl #16
    62a0:	54fffe62 	b.cs	626c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    62a4:	d350fc20 	lsr	x0, x1, #16
    62a8:	f949fc43 	ldr	x3, [x2, #5112]
    62ac:	8b000800 	add	x0, x0, x0, lsl #2
    62b0:	d37df000 	lsl	x0, x0, #3
    62b4:	8b000062 	add	x2, x3, x0
    62b8:	f9401054 	ldr	x20, [x2, #32]
    62bc:	b4fffd94 	cbz	x20, 626c <fwp_free_zombie+0x7c>
    62c0:	38606860 	ldrb	w0, [x3, x0]
    62c4:	7100081f 	cmp	w0, #0x2
    62c8:	54000360 	b.eq	6334 <fwp_free_zombie+0x144>  // b.none
    62cc:	7100041f 	cmp	w0, #0x1
    62d0:	54fffce1 	b.ne	626c <fwp_free_zombie+0x7c>  // b.any
    62d4:	29430043 	ldp	w3, w0, [x2, #24]
    62d8:	92403c21 	and	x1, x1, #0xffff
    62dc:	9b037c21 	mul	x1, x1, x3
    62e0:	d360fc21 	lsr	x1, x1, #32
    62e4:	eb00003f 	cmp	x1, x0
    62e8:	54fffc22 	b.cs	626c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    62ec:	8b010294 	add	x20, x20, x1
    62f0:	39400280 	ldrb	w0, [x20]
    62f4:	34fffbc0 	cbz	w0, 626c <fwp_free_zombie+0x7c>
    62f8:	7100041f 	cmp	w0, #0x1
    62fc:	54fffbe0 	b.eq	6278 <fwp_free_zombie+0x88>  // b.none
    6300:	7103fc1f 	cmp	w0, #0xff
    6304:	540001e0 	b.eq	6340 <fwp_free_zombie+0x150>  // b.none
    6308:	51000400 	sub	w0, w0, #0x1
    630c:	39000280 	strb	w0, [x20]
    6310:	17ffffd7 	b	626c <fwp_free_zombie+0x7c>
    6314:	f9400e61 	ldr	x1, [x19, #24]
    6318:	97fff1a2 	bl	29a0 <munmap@plt>
    631c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6320:	a9530261 	ldp	x1, x0, [x19, #304]
    6324:	b5fff901 	cbnz	x1, 6244 <fwp_free_zombie+0x54>
    6328:	9100c282 	add	x2, x20, #0x30
    632c:	f9015840 	str	x0, [x2, #688]
    6330:	17ffffc6 	b	6248 <fwp_free_zombie+0x58>
    6334:	72003c3f 	tst	w1, #0xffff
    6338:	54fff9a1 	b.ne	626c <fwp_free_zombie+0x7c>  // b.any
    633c:	17ffffed 	b	62f0 <fwp_free_zombie+0x100>
    6340:	ca544680 	eor	x0, x20, x20, lsr #17
    6344:	91150084 	add	x4, x4, #0x540
    6348:	ca402400 	eor	x0, x0, x0, lsr #9
    634c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6350:	f94a2400 	ldr	x0, [x0, #5192]
    6354:	b5000080 	cbnz	x0, 6364 <fwp_free_zombie+0x174>
    6358:	14000010 	b	6398 <fwp_free_zombie+0x1a8>
    635c:	f9400800 	ldr	x0, [x0, #16]
    6360:	b40001c0 	cbz	x0, 6398 <fwp_free_zombie+0x1a8>
    6364:	f9400001 	ldr	x1, [x0]
    6368:	eb14003f 	cmp	x1, x20
    636c:	54ffff81 	b.ne	635c <fwp_free_zombie+0x16c>  // b.any
    6370:	f9400401 	ldr	x1, [x0, #8]
    6374:	d1000421 	sub	x1, x1, #0x1
    6378:	f9000401 	str	x1, [x0, #8]
    637c:	f103f83f 	cmp	x1, #0xfe
    6380:	54fff761 	b.ne	626c <fwp_free_zombie+0x7c>  // b.any
    6384:	aa1403e0 	mov	x0, x20
    6388:	97fff87a 	bl	4570 <fwp_rc_forget_slot>
    638c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6390:	39000280 	strb	w0, [x20]
    6394:	17ffffb6 	b	626c <fwp_free_zombie+0x7c>
    6398:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    639c:	9137a000 	add	x0, x0, #0xde8
    63a0:	97fff478 	bl	3580 <fwp_trap>

00000000000063a4 <fwp_block>:
    63a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63a8:	910003fd 	mov	x29, sp
    63ac:	a90153f3 	stp	x19, x20, [sp, #16]
    63b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    63b4:	9100c274 	add	x20, x19, #0x30
    63b8:	f9401a82 	ldr	x2, [x20, #48]
    63bc:	b4000622 	cbz	x2, 6480 <fwp_block+0xdc>
    63c0:	9100c261 	add	x1, x19, #0x30
    63c4:	f9408040 	ldr	x0, [x2, #256]
    63c8:	f9001820 	str	x0, [x1, #48]
    63cc:	b4000680 	cbz	x0, 649c <fwp_block+0xf8>
    63d0:	9100c263 	add	x3, x19, #0x30
    63d4:	3901505f 	strb	wzr, [x2, #84]
    63d8:	f9400864 	ldr	x4, [x3, #16]
    63dc:	eb02009f 	cmp	x4, x2
    63e0:	54000440 	b.eq	6468 <fwp_block+0xc4>  // b.none
    63e4:	f9415c65 	ldr	x5, [x3, #696]
    63e8:	f9000862 	str	x2, [x3, #16]
    63ec:	f9400441 	ldr	x1, [x2, #8]
    63f0:	f9004885 	str	x5, [x4, #144]
    63f4:	f9416065 	ldr	x5, [x3, #704]
    63f8:	f9004c85 	str	x5, [x4, #152]
    63fc:	f9416465 	ldr	x5, [x3, #712]
    6400:	f9005085 	str	x5, [x4, #160]
    6404:	f9416865 	ldr	x5, [x3, #720]
    6408:	f9005485 	str	x5, [x4, #168]
    640c:	f9416c65 	ldr	x5, [x3, #728]
    6410:	f9005885 	str	x5, [x4, #176]
    6414:	f9417065 	ldr	x5, [x3, #736]
    6418:	f9005c85 	str	x5, [x4, #184]
    641c:	f9417465 	ldr	x5, [x3, #744]
    6420:	f9006085 	str	x5, [x4, #192]
    6424:	f9400480 	ldr	x0, [x4, #8]
    6428:	f9404844 	ldr	x4, [x2, #144]
    642c:	f9015c64 	str	x4, [x3, #696]
    6430:	f9404c44 	ldr	x4, [x2, #152]
    6434:	f9016064 	str	x4, [x3, #704]
    6438:	f9405044 	ldr	x4, [x2, #160]
    643c:	f9016464 	str	x4, [x3, #712]
    6440:	f9405444 	ldr	x4, [x2, #168]
    6444:	f9016864 	str	x4, [x3, #720]
    6448:	f9405844 	ldr	x4, [x2, #176]
    644c:	f9016c64 	str	x4, [x3, #728]
    6450:	a94b8844 	ldp	x4, x2, [x2, #184]
    6454:	f9017064 	str	x4, [x3, #736]
    6458:	f9017462 	str	x2, [x3, #744]
    645c:	97fff121 	bl	28e0 <swapcontext@plt>
    6460:	97ffff64 	bl	61f0 <fwp_free_zombie>
    6464:	d503201f 	nop
    6468:	9100c260 	add	x0, x19, #0x30
    646c:	b942f000 	ldr	w0, [x0, #752]
    6470:	340001a0 	cbz	w0, 64a4 <fwp_block+0x100>
    6474:	a94153f3 	ldp	x19, x20, [sp, #16]
    6478:	a8c27bfd 	ldp	x29, x30, [sp], #32
    647c:	d65f03c0 	ret
    6480:	97fff768 	bl	4220 <fwp_poll_events>
    6484:	f9401a82 	ldr	x2, [x20, #48]
    6488:	b4ffffc2 	cbz	x2, 6480 <fwp_block+0xdc>
    648c:	9100c261 	add	x1, x19, #0x30
    6490:	f9408040 	ldr	x0, [x2, #256]
    6494:	f9001820 	str	x0, [x1, #48]
    6498:	b5fff9c0 	cbnz	x0, 63d0 <fwp_block+0x2c>
    649c:	f900143f 	str	xzr, [x1, #40]
    64a0:	17ffffcc 	b	63d0 <fwp_block+0x2c>
    64a4:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    64a8:	913c6000 	add	x0, x0, #0xf18
    64ac:	97fff159 	bl	2a10 <getenv@plt>
    64b0:	5284e202 	mov	w2, #0x2710                	// #10000
    64b4:	b4000060 	cbz	x0, 64c0 <fwp_block+0x11c>
    64b8:	39400001 	ldrb	w1, [x0]
    64bc:	350000c1 	cbnz	w1, 64d4 <fwp_block+0x130>
    64c0:	9100c273 	add	x19, x19, #0x30
    64c4:	b902f262 	str	w2, [x19, #752]
    64c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    64cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64d0:	d65f03c0 	ret
    64d4:	52800142 	mov	w2, #0xa                   	// #10
    64d8:	d2800001 	mov	x1, #0x0                   	// #0
    64dc:	97fff09d 	bl	2750 <strtoll@plt>
    64e0:	d1000403 	sub	x3, x0, #0x1
    64e4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    64e8:	eb02007f 	cmp	x3, x2
    64ec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    64f0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    64f4:	17fffff3 	b	64c0 <fwp_block+0x11c>
    64f8:	d503201f 	nop
    64fc:	d503201f 	nop

0000000000006500 <fwp_drop10>:
    6500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6504:	910003fd 	mov	x29, sp
    6508:	a90153f3 	stp	x19, x20, [sp, #16]
    650c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    6510:	f90013f5 	str	x21, [sp, #32]
    6514:	91150275 	add	x21, x19, #0x540
    6518:	f949daa1 	ldr	x1, [x21, #5040]
    651c:	f949eea2 	ldr	x2, [x21, #5080]
    6520:	cb010001 	sub	x1, x0, x1
    6524:	eb02403f 	cmp	x1, x2, lsl #16
    6528:	54000382 	b.cs	6598 <fwp_drop10+0x98>  // b.hs, b.nlast
    652c:	d350fc22 	lsr	x2, x1, #16
    6530:	f949fea3 	ldr	x3, [x21, #5112]
    6534:	8b020842 	add	x2, x2, x2, lsl #2
    6538:	d37df042 	lsl	x2, x2, #3
    653c:	8b020064 	add	x4, x3, x2
    6540:	f9401094 	ldr	x20, [x4, #32]
    6544:	b40002b4 	cbz	x20, 6598 <fwp_drop10+0x98>
    6548:	38626862 	ldrb	w2, [x3, x2]
    654c:	7100085f 	cmp	w2, #0x2
    6550:	540007a0 	b.eq	6644 <fwp_drop10+0x144>  // b.none
    6554:	7100045f 	cmp	w2, #0x1
    6558:	54000201 	b.ne	6598 <fwp_drop10+0x98>  // b.any
    655c:	29430885 	ldp	w5, w2, [x4, #24]
    6560:	92403c21 	and	x1, x1, #0xffff
    6564:	9b057c21 	mul	x1, x1, x5
    6568:	d360fc21 	lsr	x1, x1, #32
    656c:	eb02003f 	cmp	x1, x2
    6570:	54000142 	b.cs	6598 <fwp_drop10+0x98>  // b.hs, b.nlast
    6574:	8b010294 	add	x20, x20, x1
    6578:	39400281 	ldrb	w1, [x20]
    657c:	340000e1 	cbz	w1, 6598 <fwp_drop10+0x98>
    6580:	7100043f 	cmp	w1, #0x1
    6584:	54000120 	b.eq	65a8 <fwp_drop10+0xa8>  // b.none
    6588:	7103fc3f 	cmp	w1, #0xff
    658c:	540007c0 	b.eq	6684 <fwp_drop10+0x184>  // b.none
    6590:	51000421 	sub	w1, w1, #0x1
    6594:	39000281 	strb	w1, [x20]
    6598:	a94153f3 	ldp	x19, x20, [sp, #16]
    659c:	f94013f5 	ldr	x21, [sp, #32]
    65a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65a4:	d65f03c0 	ret
    65a8:	f9400001 	ldr	x1, [x0]
    65ac:	b7f80581 	tbnz	x1, #63, 665c <fwp_drop10+0x15c>
    65b0:	91150273 	add	x19, x19, #0x540
    65b4:	f949da61 	ldr	x1, [x19, #5040]
    65b8:	f949ee62 	ldr	x2, [x19, #5080]
    65bc:	cb010001 	sub	x1, x0, x1
    65c0:	eb02403f 	cmp	x1, x2, lsl #16
    65c4:	54fffea2 	b.cs	6598 <fwp_drop10+0x98>  // b.hs, b.nlast
    65c8:	d350fc22 	lsr	x2, x1, #16
    65cc:	8b020842 	add	x2, x2, x2, lsl #2
    65d0:	d37df042 	lsl	x2, x2, #3
    65d4:	8b020065 	add	x5, x3, x2
    65d8:	f94010a4 	ldr	x4, [x5, #32]
    65dc:	b4fffde4 	cbz	x4, 6598 <fwp_drop10+0x98>
    65e0:	38626862 	ldrb	w2, [x3, x2]
    65e4:	7100085f 	cmp	w2, #0x2
    65e8:	54000220 	b.eq	662c <fwp_drop10+0x12c>  // b.none
    65ec:	7100045f 	cmp	w2, #0x1
    65f0:	54fffd41 	b.ne	6598 <fwp_drop10+0x98>  // b.any
    65f4:	294308a3 	ldp	w3, w2, [x5, #24]
    65f8:	92403c21 	and	x1, x1, #0xffff
    65fc:	9b037c21 	mul	x1, x1, x3
    6600:	d360fc21 	lsr	x1, x1, #32
    6604:	eb02003f 	cmp	x1, x2
    6608:	54fffc82 	b.cs	6598 <fwp_drop10+0x98>  // b.hs, b.nlast
    660c:	8b010084 	add	x4, x4, x1
    6610:	39400081 	ldrb	w1, [x4]
    6614:	7100043f 	cmp	w1, #0x1
    6618:	54fffc01 	b.ne	6598 <fwp_drop10+0x98>  // b.any
    661c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6620:	f94013f5 	ldr	x21, [sp, #32]
    6624:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6628:	17fff872 	b	47f0 <fwp_mem_free>
    662c:	72003c3f 	tst	w1, #0xffff
    6630:	54ffff00 	b.eq	6610 <fwp_drop10+0x110>  // b.none
    6634:	a94153f3 	ldp	x19, x20, [sp, #16]
    6638:	f94013f5 	ldr	x21, [sp, #32]
    663c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6640:	d65f03c0 	ret
    6644:	72003c3f 	tst	w1, #0xffff
    6648:	54fff980 	b.eq	6578 <fwp_drop10+0x78>  // b.none
    664c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6650:	f94013f5 	ldr	x21, [sp, #32]
    6654:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6658:	d65f03c0 	ret
    665c:	f9400414 	ldr	x20, [x0, #8]
    6660:	97fffb5d 	bl	53d4 <fwp_rc_free_arr>
    6664:	91150260 	add	x0, x19, #0x540
    6668:	f949d801 	ldr	x1, [x0, #5040]
    666c:	f949ec00 	ldr	x0, [x0, #5080]
    6670:	cb010281 	sub	x1, x20, x1
    6674:	eb00403f 	cmp	x1, x0, lsl #16
    6678:	54fff902 	b.cs	6598 <fwp_drop10+0x98>  // b.hs, b.nlast
    667c:	aa1403e0 	mov	x0, x20
    6680:	17ffffab 	b	652c <fwp_drop10+0x2c>
    6684:	ca544680 	eor	x0, x20, x20, lsr #17
    6688:	91150273 	add	x19, x19, #0x540
    668c:	ca402400 	eor	x0, x0, x0, lsr #9
    6690:	8b200e60 	add	x0, x19, w0, uxtb #3
    6694:	f94a2400 	ldr	x0, [x0, #5192]
    6698:	b5000080 	cbnz	x0, 66a8 <fwp_drop10+0x1a8>
    669c:	14000010 	b	66dc <fwp_drop10+0x1dc>
    66a0:	f9400800 	ldr	x0, [x0, #16]
    66a4:	b40001c0 	cbz	x0, 66dc <fwp_drop10+0x1dc>
    66a8:	f9400001 	ldr	x1, [x0]
    66ac:	eb14003f 	cmp	x1, x20
    66b0:	54ffff81 	b.ne	66a0 <fwp_drop10+0x1a0>  // b.any
    66b4:	f9400401 	ldr	x1, [x0, #8]
    66b8:	d1000421 	sub	x1, x1, #0x1
    66bc:	f9000401 	str	x1, [x0, #8]
    66c0:	f103f83f 	cmp	x1, #0xfe
    66c4:	54fff6a1 	b.ne	6598 <fwp_drop10+0x98>  // b.any
    66c8:	aa1403e0 	mov	x0, x20
    66cc:	97fff7a9 	bl	4570 <fwp_rc_forget_slot>
    66d0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    66d4:	39000280 	strb	w0, [x20]
    66d8:	17ffffb0 	b	6598 <fwp_drop10+0x98>
    66dc:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    66e0:	9137a000 	add	x0, x0, #0xde8
    66e4:	97fff3a7 	bl	3580 <fwp_trap>
    66e8:	d503201f 	nop
    66ec:	d503201f 	nop

00000000000066f0 <fwp_caps173>:
    66f0:	34000041 	cbz	w1, 66f8 <fwp_caps173+0x8>
    66f4:	d65f03c0 	ret
    66f8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    66fc:	91150063 	add	x3, x3, #0x540
    6700:	f949d861 	ldr	x1, [x3, #5040]
    6704:	f949ec62 	ldr	x2, [x3, #5080]
    6708:	cb010001 	sub	x1, x0, x1
    670c:	eb02403f 	cmp	x1, x2, lsl #16
    6710:	54ffff22 	b.cs	66f4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6714:	d350fc22 	lsr	x2, x1, #16
    6718:	f949fc65 	ldr	x5, [x3, #5112]
    671c:	8b020842 	add	x2, x2, x2, lsl #2
    6720:	d37df042 	lsl	x2, x2, #3
    6724:	8b0200a4 	add	x4, x5, x2
    6728:	f9401083 	ldr	x3, [x4, #32]
    672c:	b4fffe43 	cbz	x3, 66f4 <fwp_caps173+0x4>
    6730:	386268a2 	ldrb	w2, [x5, x2]
    6734:	7100085f 	cmp	w2, #0x2
    6738:	540001c0 	b.eq	6770 <fwp_caps173+0x80>  // b.none
    673c:	7100045f 	cmp	w2, #0x1
    6740:	54fffda1 	b.ne	66f4 <fwp_caps173+0x4>  // b.any
    6744:	29430885 	ldp	w5, w2, [x4, #24]
    6748:	92403c21 	and	x1, x1, #0xffff
    674c:	9b057c21 	mul	x1, x1, x5
    6750:	d360fc21 	lsr	x1, x1, #32
    6754:	eb02003f 	cmp	x1, x2
    6758:	54fffce2 	b.cs	66f4 <fwp_caps173+0x4>  // b.hs, b.nlast
    675c:	8b010063 	add	x3, x3, x1
    6760:	39400061 	ldrb	w1, [x3]
    6764:	7100043f 	cmp	w1, #0x1
    6768:	54fffc61 	b.ne	66f4 <fwp_caps173+0x4>  // b.any
    676c:	17fff821 	b	47f0 <fwp_mem_free>
    6770:	72003c3f 	tst	w1, #0xffff
    6774:	54ffff60 	b.eq	6760 <fwp_caps173+0x70>  // b.none
    6778:	d65f03c0 	ret
    677c:	d503201f 	nop

0000000000006780 <fwp_args37>:
    6780:	7100003f 	cmp	w1, #0x0
    6784:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6788:	54000041 	b.ne	6790 <fwp_args37+0x10>  // b.any
    678c:	d65f03c0 	ret
    6790:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6794:	91150042 	add	x2, x2, #0x540
    6798:	f9400001 	ldr	x1, [x0]
    679c:	f949d843 	ldr	x3, [x2, #5040]
    67a0:	f949ec40 	ldr	x0, [x2, #5080]
    67a4:	cb030021 	sub	x1, x1, x3
    67a8:	eb00403f 	cmp	x1, x0, lsl #16
    67ac:	54ffff02 	b.cs	678c <fwp_args37+0xc>  // b.hs, b.nlast
    67b0:	d350fc20 	lsr	x0, x1, #16
    67b4:	f949fc44 	ldr	x4, [x2, #5112]
    67b8:	8b000800 	add	x0, x0, x0, lsl #2
    67bc:	d37df002 	lsl	x2, x0, #3
    67c0:	8b020083 	add	x3, x4, x2
    67c4:	f9401060 	ldr	x0, [x3, #32]
    67c8:	b4fffe20 	cbz	x0, 678c <fwp_args37+0xc>
    67cc:	38626882 	ldrb	w2, [x4, x2]
    67d0:	7100085f 	cmp	w2, #0x2
    67d4:	54000220 	b.eq	6818 <fwp_args37+0x98>  // b.none
    67d8:	7100045f 	cmp	w2, #0x1
    67dc:	54fffd81 	b.ne	678c <fwp_args37+0xc>  // b.any
    67e0:	29430864 	ldp	w4, w2, [x3, #24]
    67e4:	92403c21 	and	x1, x1, #0xffff
    67e8:	9b047c21 	mul	x1, x1, x4
    67ec:	d360fc21 	lsr	x1, x1, #32
    67f0:	eb02003f 	cmp	x1, x2
    67f4:	54fffcc2 	b.cs	678c <fwp_args37+0xc>  // b.hs, b.nlast
    67f8:	8b010000 	add	x0, x0, x1
    67fc:	39400001 	ldrb	w1, [x0]
    6800:	34fffc61 	cbz	w1, 678c <fwp_args37+0xc>
    6804:	7103f43f 	cmp	w1, #0xfd
    6808:	540000e8 	b.hi	6824 <fwp_args37+0xa4>  // b.pmore
    680c:	11000421 	add	w1, w1, #0x1
    6810:	39000001 	strb	w1, [x0]
    6814:	d65f03c0 	ret
    6818:	72003c3f 	tst	w1, #0xffff
    681c:	54ffff00 	b.eq	67fc <fwp_args37+0x7c>  // b.none
    6820:	d65f03c0 	ret
    6824:	17fff70c 	b	4454 <fwp_rc_wide_dup>
    6828:	d503201f 	nop
    682c:	d503201f 	nop

0000000000006830 <fwp_caps37>:
    6830:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6834:	910003fd 	mov	x29, sp
    6838:	f9000bf3 	str	x19, [sp, #16]
    683c:	aa0003f3 	mov	x19, x0
    6840:	b9400400 	ldr	w0, [x0, #4]
    6844:	340004a0 	cbz	w0, 68d8 <fwp_caps37+0xa8>
    6848:	f9400660 	ldr	x0, [x19, #8]
    684c:	350004e1 	cbnz	w1, 68e8 <fwp_caps37+0xb8>
    6850:	97fffd90 	bl	5e90 <fwp_drop4>
    6854:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6858:	91150042 	add	x2, x2, #0x540
    685c:	f949d840 	ldr	x0, [x2, #5040]
    6860:	f949ec41 	ldr	x1, [x2, #5080]
    6864:	cb000260 	sub	x0, x19, x0
    6868:	eb01401f 	cmp	x0, x1, lsl #16
    686c:	54000382 	b.cs	68dc <fwp_caps37+0xac>  // b.hs, b.nlast
    6870:	d350fc01 	lsr	x1, x0, #16
    6874:	f949fc44 	ldr	x4, [x2, #5112]
    6878:	8b010821 	add	x1, x1, x1, lsl #2
    687c:	d37df021 	lsl	x1, x1, #3
    6880:	8b010083 	add	x3, x4, x1
    6884:	f9401062 	ldr	x2, [x3, #32]
    6888:	b40002a2 	cbz	x2, 68dc <fwp_caps37+0xac>
    688c:	38616881 	ldrb	w1, [x4, x1]
    6890:	7100083f 	cmp	w1, #0x2
    6894:	540006c0 	b.eq	696c <fwp_caps37+0x13c>  // b.none
    6898:	7100043f 	cmp	w1, #0x1
    689c:	54000201 	b.ne	68dc <fwp_caps37+0xac>  // b.any
    68a0:	29430464 	ldp	w4, w1, [x3, #24]
    68a4:	92403c00 	and	x0, x0, #0xffff
    68a8:	9b047c00 	mul	x0, x0, x4
    68ac:	d360fc00 	lsr	x0, x0, #32
    68b0:	eb01001f 	cmp	x0, x1
    68b4:	54000142 	b.cs	68dc <fwp_caps37+0xac>  // b.hs, b.nlast
    68b8:	8b000042 	add	x2, x2, x0
    68bc:	39400040 	ldrb	w0, [x2]
    68c0:	7100041f 	cmp	w0, #0x1
    68c4:	540000c1 	b.ne	68dc <fwp_caps37+0xac>  // b.any
    68c8:	aa1303e0 	mov	x0, x19
    68cc:	f9400bf3 	ldr	x19, [sp, #16]
    68d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68d4:	17fff7c7 	b	47f0 <fwp_mem_free>
    68d8:	34fffbe1 	cbz	w1, 6854 <fwp_caps37+0x24>
    68dc:	f9400bf3 	ldr	x19, [sp, #16]
    68e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68e4:	d65f03c0 	ret
    68e8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    68ec:	91150042 	add	x2, x2, #0x540
    68f0:	f949d843 	ldr	x3, [x2, #5040]
    68f4:	f949ec41 	ldr	x1, [x2, #5080]
    68f8:	cb030000 	sub	x0, x0, x3
    68fc:	eb01401f 	cmp	x0, x1, lsl #16
    6900:	54fffee2 	b.cs	68dc <fwp_caps37+0xac>  // b.hs, b.nlast
    6904:	d350fc01 	lsr	x1, x0, #16
    6908:	f949fc44 	ldr	x4, [x2, #5112]
    690c:	8b010821 	add	x1, x1, x1, lsl #2
    6910:	d37df021 	lsl	x1, x1, #3
    6914:	8b010083 	add	x3, x4, x1
    6918:	f9401062 	ldr	x2, [x3, #32]
    691c:	b4fffe02 	cbz	x2, 68dc <fwp_caps37+0xac>
    6920:	38616881 	ldrb	w1, [x4, x1]
    6924:	7100083f 	cmp	w1, #0x2
    6928:	54000280 	b.eq	6978 <fwp_caps37+0x148>  // b.none
    692c:	7100043f 	cmp	w1, #0x1
    6930:	54fffd61 	b.ne	68dc <fwp_caps37+0xac>  // b.any
    6934:	92403c01 	and	x1, x0, #0xffff
    6938:	29430064 	ldp	w4, w0, [x3, #24]
    693c:	9b047c21 	mul	x1, x1, x4
    6940:	d360fc21 	lsr	x1, x1, #32
    6944:	eb00003f 	cmp	x1, x0
    6948:	54fffca2 	b.cs	68dc <fwp_caps37+0xac>  // b.hs, b.nlast
    694c:	8b010042 	add	x2, x2, x1
    6950:	39400040 	ldrb	w0, [x2]
    6954:	34fffc40 	cbz	w0, 68dc <fwp_caps37+0xac>
    6958:	7103f41f 	cmp	w0, #0xfd
    695c:	54000148 	b.hi	6984 <fwp_caps37+0x154>  // b.pmore
    6960:	11000400 	add	w0, w0, #0x1
    6964:	39000040 	strb	w0, [x2]
    6968:	17ffffdd 	b	68dc <fwp_caps37+0xac>
    696c:	72003c1f 	tst	w0, #0xffff
    6970:	54fffb61 	b.ne	68dc <fwp_caps37+0xac>  // b.any
    6974:	17ffffd2 	b	68bc <fwp_caps37+0x8c>
    6978:	72003c1f 	tst	w0, #0xffff
    697c:	54fffb01 	b.ne	68dc <fwp_caps37+0xac>  // b.any
    6980:	17fffff4 	b	6950 <fwp_caps37+0x120>
    6984:	f9400bf3 	ldr	x19, [sp, #16]
    6988:	aa0203e0 	mov	x0, x2
    698c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6990:	17fff6b1 	b	4454 <fwp_rc_wide_dup>

0000000000006994 <f37>:
    6994:	d10203ff 	sub	sp, sp, #0x80
    6998:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    699c:	f947f421 	ldr	x1, [x1, #4072]
    69a0:	a9027bfd 	stp	x29, x30, [sp, #32]
    69a4:	910083fd 	add	x29, sp, #0x20
    69a8:	a9045bf5 	stp	x21, x22, [sp, #64]
    69ac:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    69b0:	911502c3 	add	x3, x22, #0x540
    69b4:	a90353f3 	stp	x19, x20, [sp, #48]
    69b8:	a90563f7 	stp	x23, x24, [sp, #80]
    69bc:	aa0003f8 	mov	x24, x0
    69c0:	a9066bf9 	stp	x25, x26, [sp, #96]
    69c4:	f949ec62 	ldr	x2, [x3, #5080]
    69c8:	f9400024 	ldr	x4, [x1]
    69cc:	f9000fe4 	str	x4, [sp, #24]
    69d0:	d2800004 	mov	x4, #0x0                   	// #0
    69d4:	f949d861 	ldr	x1, [x3, #5040]
    69d8:	d370bc42 	lsl	x2, x2, #16
    69dc:	b40017c0 	cbz	x0, 6cd4 <f37+0x340>
    69e0:	f9400819 	ldr	x25, [x0, #16]
    69e4:	cb010321 	sub	x1, x25, x1
    69e8:	eb02003f 	cmp	x1, x2
    69ec:	54000362 	b.cs	6a58 <f37+0xc4>  // b.hs, b.nlast
    69f0:	f949fc60 	ldr	x0, [x3, #5112]
    69f4:	d350fc22 	lsr	x2, x1, #16
    69f8:	8b020842 	add	x2, x2, x2, lsl #2
    69fc:	8b020c02 	add	x2, x0, x2, lsl #3
    6a00:	f9401040 	ldr	x0, [x2, #32]
    6a04:	b40002a0 	cbz	x0, 6a58 <f37+0xc4>
    6a08:	39400043 	ldrb	w3, [x2]
    6a0c:	7100087f 	cmp	w3, #0x2
    6a10:	540015c0 	b.eq	6cc8 <f37+0x334>  // b.none
    6a14:	7100047f 	cmp	w3, #0x1
    6a18:	540001c1 	b.ne	6a50 <f37+0xbc>  // b.any
    6a1c:	29430843 	ldp	w3, w2, [x2, #24]
    6a20:	92403c21 	and	x1, x1, #0xffff
    6a24:	9b037c21 	mul	x1, x1, x3
    6a28:	d360fc21 	lsr	x1, x1, #32
    6a2c:	eb02003f 	cmp	x1, x2
    6a30:	54000102 	b.cs	6a50 <f37+0xbc>  // b.hs, b.nlast
    6a34:	8b010000 	add	x0, x0, x1
    6a38:	39400001 	ldrb	w1, [x0]
    6a3c:	340000a1 	cbz	w1, 6a50 <f37+0xbc>
    6a40:	7103f43f 	cmp	w1, #0xfd
    6a44:	54001868 	b.hi	6d50 <f37+0x3bc>  // b.pmore
    6a48:	11000421 	add	w1, w1, #0x1
    6a4c:	39000001 	strb	w1, [x0]
    6a50:	d2800000 	mov	x0, #0x0                   	// #0
    6a54:	b40000d8 	cbz	x24, 6a6c <f37+0xd8>
    6a58:	aa1803e1 	mov	x1, x24
    6a5c:	d2800000 	mov	x0, #0x0                   	// #0
    6a60:	f9400821 	ldr	x1, [x1, #16]
    6a64:	91000400 	add	x0, x0, #0x1
    6a68:	b5ffffc1 	cbnz	x1, 6a60 <f37+0xcc>
    6a6c:	b40013b9 	cbz	x25, 6ce0 <f37+0x34c>
    6a70:	aa1903e1 	mov	x1, x25
    6a74:	d2800002 	mov	x2, #0x0                   	// #0
    6a78:	f9400821 	ldr	x1, [x1, #16]
    6a7c:	91000442 	add	x2, x2, #0x1
    6a80:	b5ffffc1 	cbnz	x1, 6a78 <f37+0xe4>
    6a84:	eb00005f 	cmp	x2, x0
    6a88:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6a8c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    6a90:	eb01035f 	cmp	x26, x1
    6a94:	54001668 	b.hi	6d60 <f37+0x3cc>  // b.pmore
    6a98:	d37ffb53 	lsl	x19, x26, #1
    6a9c:	52800041 	mov	w1, #0x2                   	// #2
    6aa0:	91000660 	add	x0, x19, #0x1
    6aa4:	d37df000 	lsl	x0, x0, #3
    6aa8:	97fff872 	bl	4c70 <fwp_heap_alloc>
    6aac:	aa0003f7 	mov	x23, x0
    6ab0:	911502c1 	add	x1, x22, #0x540
    6ab4:	aa0103e0 	mov	x0, x1
    6ab8:	f90002f3 	str	x19, [x23]
    6abc:	f949d821 	ldr	x1, [x1, #5040]
    6ac0:	f949ec00 	ldr	x0, [x0, #5080]
    6ac4:	cb0102e1 	sub	x1, x23, x1
    6ac8:	eb00403f 	cmp	x1, x0, lsl #16
    6acc:	54000342 	b.cs	6b34 <f37+0x1a0>  // b.hs, b.nlast
    6ad0:	911502c2 	add	x2, x22, #0x540
    6ad4:	d350fc20 	lsr	x0, x1, #16
    6ad8:	8b000800 	add	x0, x0, x0, lsl #2
    6adc:	f949fc43 	ldr	x3, [x2, #5112]
    6ae0:	d37df002 	lsl	x2, x0, #3
    6ae4:	8b020060 	add	x0, x3, x2
    6ae8:	f9401013 	ldr	x19, [x0, #32]
    6aec:	b4000253 	cbz	x19, 6b34 <f37+0x1a0>
    6af0:	38626862 	ldrb	w2, [x3, x2]
    6af4:	7100085f 	cmp	w2, #0x2
    6af8:	54000e20 	b.eq	6cbc <f37+0x328>  // b.none
    6afc:	7100045f 	cmp	w2, #0x1
    6b00:	540001a1 	b.ne	6b34 <f37+0x1a0>  // b.any
    6b04:	29430002 	ldp	w2, w0, [x0, #24]
    6b08:	92403c21 	and	x1, x1, #0xffff
    6b0c:	9b027c21 	mul	x1, x1, x2
    6b10:	d360fc21 	lsr	x1, x1, #32
    6b14:	eb00003f 	cmp	x1, x0
    6b18:	540000e2 	b.cs	6b34 <f37+0x1a0>  // b.hs, b.nlast
    6b1c:	8b010273 	add	x19, x19, x1
    6b20:	39400260 	ldrb	w0, [x19]
    6b24:	7103fc1f 	cmp	w0, #0xff
    6b28:	54000f80 	b.eq	6d18 <f37+0x384>  // b.none
    6b2c:	52800020 	mov	w0, #0x1                   	// #1
    6b30:	39000260 	strb	w0, [x19]
    6b34:	b400025a 	cbz	x26, 6b7c <f37+0x1e8>
    6b38:	8b1a12fa 	add	x26, x23, x26, lsl #4
    6b3c:	aa1703f3 	mov	x19, x23
    6b40:	aa1803f5 	mov	x21, x24
    6b44:	aa1903f4 	mov	x20, x25
    6b48:	f9400683 	ldr	x3, [x20, #8]
    6b4c:	f94006a2 	ldr	x2, [x21, #8]
    6b50:	f9400861 	ldr	x1, [x3, #16]
    6b54:	f9400840 	ldr	x0, [x2, #16]
    6b58:	fd400461 	ldr	d1, [x3, #8]
    6b5c:	fd400440 	ldr	d0, [x2, #8]
    6b60:	97fff984 	bl	5170 <w120>
    6b64:	f9000660 	str	x0, [x19, #8]
    6b68:	f8010e61 	str	x1, [x19, #16]!
    6b6c:	f9400a94 	ldr	x20, [x20, #16]
    6b70:	f9400ab5 	ldr	x21, [x21, #16]
    6b74:	eb13035f 	cmp	x26, x19
    6b78:	54fffe81 	b.ne	6b48 <f37+0x1b4>  // b.any
    6b7c:	aa1903e0 	mov	x0, x25
    6b80:	97fffcc4 	bl	5e90 <fwp_drop4>
    6b84:	aa1803e0 	mov	x0, x24
    6b88:	97fffcc2 	bl	5e90 <fwp_drop4>
    6b8c:	f94002f5 	ldr	x21, [x23]
    6b90:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6b94:	b4000275 	cbz	x21, 6be0 <f37+0x24c>
    6b98:	fd003be8 	str	d8, [sp, #112]
    6b9c:	2f00e408 	movi	d8, #0x0
    6ba0:	910022f9 	add	x25, x23, #0x8
    6ba4:	910042f8 	add	x24, x23, #0x10
    6ba8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    6bac:	d2800013 	mov	x19, #0x0                   	// #0
    6bb0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    6bb4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6bb8:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    6bbc:	aa0303e1 	mov	x1, x3
    6bc0:	1e602908 	fadd	d8, d8, d0
    6bc4:	91000a73 	add	x19, x19, #0x2
    6bc8:	97fff8b7 	bl	4ea4 <fwp_p_ad_push>
    6bcc:	aa0003f4 	mov	x20, x0
    6bd0:	eb1302bf 	cmp	x21, x19
    6bd4:	54fffee8 	b.hi	6bb0 <f37+0x21c>  // b.pmore
    6bd8:	9e660115 	fmov	x21, d8
    6bdc:	fd403be8 	ldr	d8, [sp, #112]
    6be0:	911502d6 	add	x22, x22, #0x540
    6be4:	aa1703e0 	mov	x0, x23
    6be8:	97fffe46 	bl	6500 <fwp_drop10>
    6bec:	a900d3f5 	stp	x21, x20, [sp, #8]
    6bf0:	910023e1 	add	x1, sp, #0x8
    6bf4:	52800000 	mov	w0, #0x0                   	// #0
    6bf8:	97fff863 	bl	4d84 <fwp_data.part.0.constprop.0>
    6bfc:	f949dac1 	ldr	x1, [x22, #5040]
    6c00:	aa0003f3 	mov	x19, x0
    6c04:	f949eec0 	ldr	x0, [x22, #5080]
    6c08:	cb010261 	sub	x1, x19, x1
    6c0c:	eb00403f 	cmp	x1, x0, lsl #16
    6c10:	54000322 	b.cs	6c74 <f37+0x2e0>  // b.hs, b.nlast
    6c14:	d350fc22 	lsr	x2, x1, #16
    6c18:	f949fec3 	ldr	x3, [x22, #5112]
    6c1c:	8b020842 	add	x2, x2, x2, lsl #2
    6c20:	d37df042 	lsl	x2, x2, #3
    6c24:	8b020060 	add	x0, x3, x2
    6c28:	f9401014 	ldr	x20, [x0, #32]
    6c2c:	b4000254 	cbz	x20, 6c74 <f37+0x2e0>
    6c30:	38626862 	ldrb	w2, [x3, x2]
    6c34:	7100085f 	cmp	w2, #0x2
    6c38:	540003c0 	b.eq	6cb0 <f37+0x31c>  // b.none
    6c3c:	7100045f 	cmp	w2, #0x1
    6c40:	540001a1 	b.ne	6c74 <f37+0x2e0>  // b.any
    6c44:	29430002 	ldp	w2, w0, [x0, #24]
    6c48:	92403c21 	and	x1, x1, #0xffff
    6c4c:	9b027c21 	mul	x1, x1, x2
    6c50:	d360fc21 	lsr	x1, x1, #32
    6c54:	eb00003f 	cmp	x1, x0
    6c58:	540000e2 	b.cs	6c74 <f37+0x2e0>  // b.hs, b.nlast
    6c5c:	8b010294 	add	x20, x20, x1
    6c60:	39400280 	ldrb	w0, [x20]
    6c64:	7103fc1f 	cmp	w0, #0xff
    6c68:	540005e0 	b.eq	6d24 <f37+0x390>  // b.none
    6c6c:	52800020 	mov	w0, #0x1                   	// #1
    6c70:	39000280 	strb	w0, [x20]
    6c74:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6c78:	f947f400 	ldr	x0, [x0, #4072]
    6c7c:	f9400fe2 	ldr	x2, [sp, #24]
    6c80:	f9400001 	ldr	x1, [x0]
    6c84:	eb010042 	subs	x2, x2, x1
    6c88:	d2800001 	mov	x1, #0x0                   	// #0
    6c8c:	54000721 	b.ne	6d70 <f37+0x3dc>  // b.any
    6c90:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6c94:	aa1303e0 	mov	x0, x19
    6c98:	a94353f3 	ldp	x19, x20, [sp, #48]
    6c9c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6ca0:	a94563f7 	ldp	x23, x24, [sp, #80]
    6ca4:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6ca8:	910203ff 	add	sp, sp, #0x80
    6cac:	d65f03c0 	ret
    6cb0:	72003c3f 	tst	w1, #0xffff
    6cb4:	54fffe01 	b.ne	6c74 <f37+0x2e0>  // b.any
    6cb8:	17ffffea 	b	6c60 <f37+0x2cc>
    6cbc:	72003c3f 	tst	w1, #0xffff
    6cc0:	54fff3a1 	b.ne	6b34 <f37+0x1a0>  // b.any
    6cc4:	17ffff97 	b	6b20 <f37+0x18c>
    6cc8:	72003c3f 	tst	w1, #0xffff
    6ccc:	54ffec21 	b.ne	6a50 <f37+0xbc>  // b.any
    6cd0:	17ffff5a 	b	6a38 <f37+0xa4>
    6cd4:	cb0103e1 	neg	x1, x1
    6cd8:	eb02003f 	cmp	x1, x2
    6cdc:	540002a3 	b.cc	6d30 <f37+0x39c>  // b.lo, b.ul, b.last
    6ce0:	52800041 	mov	w1, #0x2                   	// #2
    6ce4:	d2800100 	mov	x0, #0x8                   	// #8
    6ce8:	97fff7e2 	bl	4c70 <fwp_heap_alloc>
    6cec:	aa0003f7 	mov	x23, x0
    6cf0:	911502c0 	add	x0, x22, #0x540
    6cf4:	f90002ff 	str	xzr, [x23]
    6cf8:	f949d801 	ldr	x1, [x0, #5040]
    6cfc:	f949ec00 	ldr	x0, [x0, #5080]
    6d00:	cb0102e1 	sub	x1, x23, x1
    6d04:	eb00403f 	cmp	x1, x0, lsl #16
    6d08:	54000282 	b.cs	6d58 <f37+0x3c4>  // b.hs, b.nlast
    6d0c:	d280001a 	mov	x26, #0x0                   	// #0
    6d10:	d2800019 	mov	x25, #0x0                   	// #0
    6d14:	17ffff6f 	b	6ad0 <f37+0x13c>
    6d18:	aa1303e0 	mov	x0, x19
    6d1c:	97fff615 	bl	4570 <fwp_rc_forget_slot>
    6d20:	17ffff83 	b	6b2c <f37+0x198>
    6d24:	aa1403e0 	mov	x0, x20
    6d28:	97fff612 	bl	4570 <fwp_rc_forget_slot>
    6d2c:	17ffffd0 	b	6c6c <f37+0x2d8>
    6d30:	f949fc62 	ldr	x2, [x3, #5112]
    6d34:	d350fc20 	lsr	x0, x1, #16
    6d38:	8b000800 	add	x0, x0, x0, lsl #2
    6d3c:	8b000c42 	add	x2, x2, x0, lsl #3
    6d40:	f9401040 	ldr	x0, [x2, #32]
    6d44:	b4fffce0 	cbz	x0, 6ce0 <f37+0x34c>
    6d48:	d2800019 	mov	x25, #0x0                   	// #0
    6d4c:	17ffff2f 	b	6a08 <f37+0x74>
    6d50:	97fff5c1 	bl	4454 <fwp_rc_wide_dup>
    6d54:	17ffff3f 	b	6a50 <f37+0xbc>
    6d58:	d2800019 	mov	x25, #0x0                   	// #0
    6d5c:	17ffff88 	b	6b7c <f37+0x1e8>
    6d60:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    6d64:	913ca000 	add	x0, x0, #0xf28
    6d68:	fd003be8 	str	d8, [sp, #112]
    6d6c:	97fff205 	bl	3580 <fwp_trap>
    6d70:	fd003be8 	str	d8, [sp, #112]
    6d74:	97ffeec3 	bl	2880 <__stack_chk_fail@plt>
    6d78:	d503201f 	nop
    6d7c:	d503201f 	nop

0000000000006d80 <fwp_owned_entry37>:
    6d80:	f9400000 	ldr	x0, [x0]
    6d84:	17ffff04 	b	6994 <f37>
    6d88:	d503201f 	nop
    6d8c:	d503201f 	nop

0000000000006d90 <e37>:
    6d90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d94:	910003fd 	mov	x29, sp
    6d98:	f9000bf3 	str	x19, [sp, #16]
    6d9c:	f9400013 	ldr	x19, [x0]
    6da0:	aa1303e0 	mov	x0, x19
    6da4:	97fff937 	bl	5280 <fwp_rc_share>
    6da8:	aa1303e0 	mov	x0, x19
    6dac:	97fffefa 	bl	6994 <f37>
    6db0:	aa0003f3 	mov	x19, x0
    6db4:	97fff933 	bl	5280 <fwp_rc_share>
    6db8:	aa1303e0 	mov	x0, x19
    6dbc:	f9400bf3 	ldr	x19, [sp, #16]
    6dc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6dc4:	d65f03c0 	ret
    6dc8:	d503201f 	nop
    6dcc:	d503201f 	nop

0000000000006dd0 <fwp_write>:
    6dd0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    6dd4:	910003fd 	mov	x29, sp
    6dd8:	b00000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    6ddc:	f947f484 	ldr	x4, [x4, #4072]
    6de0:	a90153f3 	stp	x19, x20, [sp, #16]
    6de4:	d10943ff 	sub	sp, sp, #0x250
    6de8:	b9400045 	ldr	w5, [x2]
    6dec:	aa0003f4 	mov	x20, x0
    6df0:	f9400080 	ldr	x0, [x4]
    6df4:	f90127e0 	str	x0, [sp, #584]
    6df8:	d2800000 	mov	x0, #0x0                   	// #0
    6dfc:	710064bf 	cmp	w5, #0x19
    6e00:	54000408 	b.hi	6e80 <fwp_write+0xb0>  // b.pmore
    6e04:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    6e08:	aa0103f3 	mov	x19, x1
    6e0c:	911e4000 	add	x0, x0, #0x790
    6e10:	f9013bf5 	str	x21, [sp, #624]
    6e14:	f9013ff6 	str	x22, [sp, #632]
    6e18:	f90153fb 	str	x27, [sp, #672]
    6e1c:	f90157fc 	str	x28, [sp, #680]
    6e20:	aa0203fc 	mov	x28, x2
    6e24:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    6e28:	10000061 	adr	x1, 6e34 <fwp_write+0x64>
    6e2c:	8b20a820 	add	x0, x1, w0, sxth #2
    6e30:	d61f0000 	br	x0
    6e34:	910123e0 	add	x0, sp, #0x48
    6e38:	aa1303e5 	mov	x5, x19
    6e3c:	d0000024 	adrp	x4, c000 <fwp_main_thread+0x120>
    6e40:	aa0003f3 	mov	x19, x0
    6e44:	913dc084 	add	x4, x4, #0xf70
    6e48:	d2804003 	mov	x3, #0x200                 	// #512
    6e4c:	aa0303e1 	mov	x1, x3
    6e50:	52800042 	mov	w2, #0x2                   	// #2
    6e54:	97ffee67 	bl	27f0 <__snprintf_chk@plt>
    6e58:	aa1303e0 	mov	x0, x19
    6e5c:	97ffee2d 	bl	2710 <strlen@plt>
    6e60:	aa1303e1 	mov	x1, x19
    6e64:	aa0003e2 	mov	x2, x0
    6e68:	aa1403e0 	mov	x0, x20
    6e6c:	97fff169 	bl	3410 <buf_put>
    6e70:	f9413bf5 	ldr	x21, [sp, #624]
    6e74:	f9413ff6 	ldr	x22, [sp, #632]
    6e78:	f94153fb 	ldr	x27, [sp, #672]
    6e7c:	f94157fc 	ldr	x28, [sp, #680]
    6e80:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6e84:	f947f400 	ldr	x0, [x0, #4072]
    6e88:	f94127e2 	ldr	x2, [sp, #584]
    6e8c:	f9400001 	ldr	x1, [x0]
    6e90:	eb010042 	subs	x2, x2, x1
    6e94:	d2800001 	mov	x1, #0x0                   	// #0
    6e98:	540077c1 	b.ne	7d90 <fwp_write+0xfc0>  // b.any
    6e9c:	910943ff 	add	sp, sp, #0x250
    6ea0:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ea4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6ea8:	d65f03c0 	ret
    6eac:	910123e0 	add	x0, sp, #0x48
    6eb0:	aa1303e5 	mov	x5, x19
    6eb4:	d0000024 	adrp	x4, c000 <fwp_main_thread+0x120>
    6eb8:	aa0003f3 	mov	x19, x0
    6ebc:	913da084 	add	x4, x4, #0xf68
    6ec0:	d2804003 	mov	x3, #0x200                 	// #512
    6ec4:	17ffffe2 	b	6e4c <fwp_write+0x7c>
    6ec8:	71004cbf 	cmp	w5, #0x13
    6ecc:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    6ed0:	d0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    6ed4:	913d6000 	add	x0, x0, #0xf58
    6ed8:	913d8021 	add	x1, x1, #0xf60
    6edc:	d2800082 	mov	x2, #0x4                   	// #4
    6ee0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    6ee4:	aa1403e0 	mov	x0, x20
    6ee8:	f90143f7 	str	x23, [sp, #640]
    6eec:	d2800016 	mov	x22, #0x0                   	// #0
    6ef0:	f90147f8 	str	x24, [sp, #648]
    6ef4:	97fff147 	bl	3410 <buf_put>
    6ef8:	f9400260 	ldr	x0, [x19]
    6efc:	d0000037 	adrp	x23, c000 <fwp_main_thread+0x120>
    6f00:	d2800015 	mov	x21, #0x0                   	// #0
    6f04:	913f82f7 	add	x23, x23, #0xfe0
    6f08:	b40047a0 	cbz	x0, 77fc <fwp_write+0xa2c>
    6f0c:	b9400380 	ldr	w0, [x28]
    6f10:	52800003 	mov	w3, #0x0                   	// #0
    6f14:	f9401f82 	ldr	x2, [x28, #56]
    6f18:	71004c1f 	cmp	w0, #0x13
    6f1c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    6f20:	aa1403e0 	mov	x0, x20
    6f24:	8b010e61 	add	x1, x19, x1, lsl #3
    6f28:	f9400421 	ldr	x1, [x1, #8]
    6f2c:	97ffffa9 	bl	6dd0 <fwp_write>
    6f30:	b9400380 	ldr	w0, [x28]
    6f34:	7100481f 	cmp	w0, #0x12
    6f38:	54004b40 	b.eq	78a0 <fwp_write+0xad0>  // b.none
    6f3c:	f9400260 	ldr	x0, [x19]
    6f40:	910006b5 	add	x21, x21, #0x1
    6f44:	91000ad6 	add	x22, x22, #0x2
    6f48:	eb15001f 	cmp	x0, x21
    6f4c:	54004589 	b.ls	77fc <fwp_write+0xa2c>  // b.plast
    6f50:	aa1703e1 	mov	x1, x23
    6f54:	aa1403e0 	mov	x0, x20
    6f58:	d2800042 	mov	x2, #0x2                   	// #2
    6f5c:	97fff12d 	bl	3410 <buf_put>
    6f60:	17ffffeb 	b	6f0c <fwp_write+0x13c>
    6f64:	d0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    6f68:	913e6021 	add	x1, x1, #0xf98
    6f6c:	d28000c2 	mov	x2, #0x6                   	// #6
    6f70:	aa1403e0 	mov	x0, x20
    6f74:	91004273 	add	x19, x19, #0x10
    6f78:	97fff126 	bl	3410 <buf_put>
    6f7c:	aa1303e0 	mov	x0, x19
    6f80:	97ffede4 	bl	2710 <strlen@plt>
    6f84:	aa1303e1 	mov	x1, x19
    6f88:	aa0003e2 	mov	x2, x0
    6f8c:	aa1403e0 	mov	x0, x20
    6f90:	97fff120 	bl	3410 <buf_put>
    6f94:	528007c3 	mov	w3, #0x3e                  	// #62
    6f98:	aa1403e0 	mov	x0, x20
    6f9c:	91001fe1 	add	x1, sp, #0x7
    6fa0:	d2800022 	mov	x2, #0x1                   	// #1
    6fa4:	39001fe3 	strb	w3, [sp, #7]
    6fa8:	17ffffb1 	b	6e6c <fwp_write+0x9c>
    6fac:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6fb0:	f947f400 	ldr	x0, [x0, #4072]
    6fb4:	f94127e2 	ldr	x2, [sp, #584]
    6fb8:	f9400001 	ldr	x1, [x0]
    6fbc:	eb010042 	subs	x2, x2, x1
    6fc0:	d2800001 	mov	x1, #0x0                   	// #0
    6fc4:	540034e1 	b.ne	7660 <fwp_write+0x890>  // b.any
    6fc8:	f9413bf5 	ldr	x21, [sp, #624]
    6fcc:	d0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    6fd0:	f9413ff6 	ldr	x22, [sp, #632]
    6fd4:	aa1403e0 	mov	x0, x20
    6fd8:	913de021 	add	x1, x1, #0xf78
    6fdc:	d2800142 	mov	x2, #0xa                   	// #10
    6fe0:	f94153fb 	ldr	x27, [sp, #672]
    6fe4:	f94157fc 	ldr	x28, [sp, #680]
    6fe8:	910943ff 	add	sp, sp, #0x250
    6fec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ff0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6ff4:	17fff107 	b	3410 <buf_put>
    6ff8:	f9400456 	ldr	x22, [x2, #8]
    6ffc:	f90143f7 	str	x23, [sp, #640]
    7000:	f90147f8 	str	x24, [sp, #648]
    7004:	b4005b16 	cbz	x22, 7b64 <fwp_write+0xd94>
    7008:	aa1603e0 	mov	x0, x22
    700c:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    7010:	913fe021 	add	x1, x1, #0xff8
    7014:	97ffee3b 	bl	2900 <strcmp@plt>
    7018:	2a0003f5 	mov	w21, w0
    701c:	34005fe0 	cbz	w0, 7c18 <fwp_write+0xe48>
    7020:	aa1603e0 	mov	x0, x22
    7024:	97ffedbb 	bl	2710 <strlen@plt>
    7028:	aa1603e1 	mov	x1, x22
    702c:	aa0003e2 	mov	x2, x0
    7030:	aa1403e0 	mov	x0, x20
    7034:	97fff0f7 	bl	3410 <buf_put>
    7038:	52800403 	mov	w3, #0x20                  	// #32
    703c:	91001ff5 	add	x21, sp, #0x7
    7040:	aa1503e1 	mov	x1, x21
    7044:	aa1403e0 	mov	x0, x20
    7048:	d2800022 	mov	x2, #0x1                   	// #1
    704c:	39001fe3 	strb	w3, [sp, #7]
    7050:	97fff0f0 	bl	3410 <buf_put>
    7054:	52800f63 	mov	w3, #0x7b                  	// #123
    7058:	aa1403e0 	mov	x0, x20
    705c:	aa1503e1 	mov	x1, x21
    7060:	d2800022 	mov	x2, #0x1                   	// #1
    7064:	39001fe3 	strb	w3, [sp, #7]
    7068:	97fff0ea 	bl	3410 <buf_put>
    706c:	b9401380 	ldr	w0, [x28, #16]
    7070:	52800018 	mov	w24, #0x0                   	// #0
    7074:	7100001f 	cmp	w0, #0x0
    7078:	54003aad 	b.le	77cc <fwp_write+0x9fc>
    707c:	f9014bf9 	str	x25, [sp, #656]
    7080:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x4c0>
    7084:	91008339 	add	x25, x25, #0x20
    7088:	f9014ffa 	str	x26, [sp, #664]
    708c:	b000003a 	adrp	x26, c000 <fwp_main_thread+0x120>
    7090:	913f835a 	add	x26, x26, #0xfe0
    7094:	91002276 	add	x22, x19, #0x8
    7098:	d2800013 	mov	x19, #0x0                   	// #0
    709c:	b5003e93 	cbnz	x19, 786c <fwp_write+0xa9c>
    70a0:	d37df277 	lsl	x23, x19, #3
    70a4:	34003cb8 	cbz	w24, 7838 <fwp_write+0xa68>
    70a8:	f9401382 	ldr	x2, [x28, #32]
    70ac:	aa1403e0 	mov	x0, x20
    70b0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    70b4:	52800003 	mov	w3, #0x0                   	// #0
    70b8:	f8776842 	ldr	x2, [x2, x23]
    70bc:	91000673 	add	x19, x19, #0x1
    70c0:	97ffff44 	bl	6dd0 <fwp_write>
    70c4:	b9401380 	ldr	w0, [x28, #16]
    70c8:	6b13001f 	cmp	w0, w19
    70cc:	54fffe8c 	b.gt	709c <fwp_write+0x2cc>
    70d0:	f9414bf9 	ldr	x25, [sp, #656]
    70d4:	f9414ffa 	ldr	x26, [sp, #664]
    70d8:	340037b8 	cbz	w24, 77cc <fwp_write+0x9fc>
    70dc:	52800523 	mov	w3, #0x29                  	// #41
    70e0:	aa1503e1 	mov	x1, x21
    70e4:	aa1403e0 	mov	x0, x20
    70e8:	d2800022 	mov	x2, #0x1                   	// #1
    70ec:	39001fe3 	strb	w3, [sp, #7]
    70f0:	97fff0c8 	bl	3410 <buf_put>
    70f4:	f9413bf5 	ldr	x21, [sp, #624]
    70f8:	f9413ff6 	ldr	x22, [sp, #632]
    70fc:	f94143f7 	ldr	x23, [sp, #640]
    7100:	f94147f8 	ldr	x24, [sp, #648]
    7104:	f94153fb 	ldr	x27, [sp, #672]
    7108:	f94157fc 	ldr	x28, [sp, #680]
    710c:	17ffff5d 	b	6e80 <fwp_write+0xb0>
    7110:	b9404855 	ldr	w21, [x2, #72]
    7114:	aa1403e0 	mov	x0, x20
    7118:	93407eb6 	sxtw	x22, w21
    711c:	91000ac1 	add	x1, x22, #0x2
    7120:	97fff089 	bl	3344 <buf_grow>
    7124:	a9400281 	ldp	x1, x0, [x20]
    7128:	528e8603 	mov	w3, #0x7430                	// #29744
    712c:	78206823 	strh	w3, [x1, x0]
    7130:	8b000022 	add	x2, x1, x0
    7134:	710002bf 	cmp	w21, #0x0
    7138:	540036cd 	b.le	7810 <fwp_write+0xa40>
    713c:	110006a3 	add	w3, w21, #0x1
    7140:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7144:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7148:	91000449 	add	x9, x2, #0x1
    714c:	8b23c043 	add	x3, x2, w3, sxtw
    7150:	f28aaac6 	movk	x6, #0x5556
    7154:	f2955568 	movk	x8, #0xaaab
    7158:	1400000d 	b	718c <fwp_write+0x3bc>
    715c:	d2800021 	mov	x1, #0x1                   	// #1
    7160:	528005a5 	mov	w5, #0x2d                  	// #45
    7164:	f100001f 	cmp	x0, #0x0
    7168:	9b467e60 	smulh	x0, x19, x6
    716c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7170:	381ff465 	strb	w5, [x3], #-1
    7174:	cb040000 	sub	x0, x0, x4
    7178:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    717c:	cb020000 	sub	x0, x0, x2
    7180:	8b010013 	add	x19, x0, x1
    7184:	eb03013f 	cmp	x9, x3
    7188:	54003440 	b.eq	7810 <fwp_write+0xa40>  // b.none
    718c:	9b467e60 	smulh	x0, x19, x6
    7190:	937ffe64 	asr	x4, x19, #63
    7194:	52800605 	mov	w5, #0x30                  	// #48
    7198:	cb040000 	sub	x0, x0, x4
    719c:	8b000400 	add	x0, x0, x0, lsl #1
    71a0:	cb000260 	sub	x0, x19, x0
    71a4:	91000c01 	add	x1, x0, #0x3
    71a8:	9bc87c22 	umulh	x2, x1, x8
    71ac:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    71b0:	8b4204e2 	add	x2, x7, x2, lsr #1
    71b4:	eb020021 	subs	x1, x1, x2
    71b8:	54fffd60 	b.eq	7164 <fwp_write+0x394>  // b.none
    71bc:	f100043f 	cmp	x1, #0x1
    71c0:	54fffce1 	b.ne	715c <fwp_write+0x38c>  // b.any
    71c4:	d2800001 	mov	x1, #0x0                   	// #0
    71c8:	52800565 	mov	w5, #0x2b                  	// #43
    71cc:	17ffffe6 	b	7164 <fwp_write+0x394>
    71d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    71d4:	f947f400 	ldr	x0, [x0, #4072]
    71d8:	f94127e2 	ldr	x2, [sp, #584]
    71dc:	f9400001 	ldr	x1, [x0]
    71e0:	eb010042 	subs	x2, x2, x1
    71e4:	d2800001 	mov	x1, #0x0                   	// #0
    71e8:	540023c1 	b.ne	7660 <fwp_write+0x890>  // b.any
    71ec:	f9413bf5 	ldr	x21, [sp, #624]
    71f0:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    71f4:	f9413ff6 	ldr	x22, [sp, #632]
    71f8:	aa1403e0 	mov	x0, x20
    71fc:	913e2021 	add	x1, x1, #0xf88
    7200:	d2800102 	mov	x2, #0x8                   	// #8
    7204:	17ffff77 	b	6fe0 <fwp_write+0x210>
    7208:	aa1403e0 	mov	x0, x20
    720c:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    7210:	d28000c2 	mov	x2, #0x6                   	// #6
    7214:	913fa021 	add	x1, x1, #0xfe8
    7218:	97fff07e 	bl	3410 <buf_put>
    721c:	d2800015 	mov	x21, #0x0                   	// #0
    7220:	f9400263 	ldr	x3, [x19]
    7224:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7228:	54002c60 	b.eq	77b4 <fwp_write+0x9e4>  // b.none
    722c:	f9401f82 	ldr	x2, [x28, #56]
    7230:	f90143f7 	str	x23, [sp, #640]
    7234:	f90147f8 	str	x24, [sp, #648]
    7238:	d2800857 	mov	x23, #0x42                  	// #66
    723c:	f9014bf9 	str	x25, [sp, #656]
    7240:	b0000036 	adrp	x22, c000 <fwp_main_thread+0x120>
    7244:	f9014ffa 	str	x26, [sp, #664]
    7248:	913f82d6 	add	x22, x22, #0xfe0
    724c:	d2800038 	mov	x24, #0x1                   	// #1
    7250:	f2a18017 	movk	x23, #0xc00, lsl #16
    7254:	d2809099 	mov	x25, #0x484                 	// #1156
    7258:	b40004a2 	cbz	x2, 72ec <fwp_write+0x51c>
    725c:	b9400040 	ldr	w0, [x2]
    7260:	7100701f 	cmp	w0, #0x1c
    7264:	540042c0 	b.eq	7abc <fwp_write+0xcec>  // b.none
    7268:	71006c1f 	cmp	w0, #0x1b
    726c:	54000408 	b.hi	72ec <fwp_write+0x51c>  // b.pmore
    7270:	9ac02301 	lsl	x1, x24, x0
    7274:	ea17003f 	tst	x1, x23
    7278:	540036a1 	b.ne	794c <fwp_write+0xb7c>  // b.any
    727c:	ea19003f 	tst	x1, x25
    7280:	54003521 	b.ne	7924 <fwp_write+0xb54>  // b.any
    7284:	d2800424 	mov	x4, #0x21                  	// #33
    7288:	ea04003f 	tst	x1, x4
    728c:	54000300 	b.eq	72ec <fwp_write+0x51c>  // b.none
    7290:	b7f849c3 	tbnz	x3, #63, 7bc8 <fwp_write+0xdf8>
    7294:	91002261 	add	x1, x19, #0x8
    7298:	8b150021 	add	x1, x1, x21
    729c:	39400021 	ldrb	w1, [x1]
    72a0:	7100001f 	cmp	w0, #0x0
    72a4:	93401c23 	sxtb	x3, w1
    72a8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    72ac:	d503201f 	nop
    72b0:	aa1403e0 	mov	x0, x20
    72b4:	52800003 	mov	w3, #0x0                   	// #0
    72b8:	97fffec6 	bl	6dd0 <fwp_write>
    72bc:	910006b5 	add	x21, x21, #0x1
    72c0:	f9400260 	ldr	x0, [x19]
    72c4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    72c8:	eb0002bf 	cmp	x21, x0
    72cc:	540026c2 	b.cs	77a4 <fwp_write+0x9d4>  // b.hs, b.nlast
    72d0:	d2800042 	mov	x2, #0x2                   	// #2
    72d4:	aa1603e1 	mov	x1, x22
    72d8:	aa1403e0 	mov	x0, x20
    72dc:	97fff04d 	bl	3410 <buf_put>
    72e0:	f9401f82 	ldr	x2, [x28, #56]
    72e4:	f9400263 	ldr	x3, [x19]
    72e8:	b5fffba2 	cbnz	x2, 725c <fwp_write+0x48c>
    72ec:	d37df2a0 	lsl	x0, x21, #3
    72f0:	b7f83f03 	tbnz	x3, #63, 7ad0 <fwp_write+0xd00>
    72f4:	91002261 	add	x1, x19, #0x8
    72f8:	8b000020 	add	x0, x1, x0
    72fc:	f9400001 	ldr	x1, [x0]
    7300:	17ffffec 	b	72b0 <fwp_write+0x4e0>
    7304:	a9400e62 	ldp	x2, x3, [x19]
    7308:	b7f83ca3 	tbnz	x3, #63, 7a9c <fwp_write+0xccc>
    730c:	910123f5 	add	x21, sp, #0x48
    7310:	aa1503e0 	mov	x0, x21
    7314:	97ffeec3 	bl	2e20 <fwp_fmt_u128>
    7318:	aa1503e0 	mov	x0, x21
    731c:	97ffecfd 	bl	2710 <strlen@plt>
    7320:	aa1503e1 	mov	x1, x21
    7324:	aa0003e2 	mov	x2, x0
    7328:	17fffed0 	b	6e68 <fwp_write+0x98>
    732c:	fd015be8 	str	d8, [sp, #688]
    7330:	1e270268 	fmov	s8, w19
    7334:	fd015fe9 	str	d9, [sp, #696]
    7338:	1e282100 	fcmp	s8, s8
    733c:	54004d26 	b.vs	7ce0 <fwp_write+0xf10>
    7340:	1e20c101 	fabs	s1, s8
    7344:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7348:	1e270000 	fmov	s0, w0
    734c:	1e202020 	fcmp	s1, s0
    7350:	54002c0d 	b.le	78d0 <fwp_write+0xb00>
    7354:	1e202118 	fcmpe	s8, #0.0
    7358:	b0000022 	adrp	x2, c000 <fwp_main_thread+0x120>
    735c:	912d8042 	add	x2, x2, #0xb60
    7360:	910123f5 	add	x21, sp, #0x48
    7364:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    7368:	913ce021 	add	x1, x1, #0xf38
    736c:	aa1503e0 	mov	x0, x21
    7370:	9a81c041 	csel	x1, x2, x1, gt
    7374:	97ffed93 	bl	29c0 <strcpy@plt>
    7378:	aa1503e0 	mov	x0, x21
    737c:	97ffece5 	bl	2710 <strlen@plt>
    7380:	aa1503e1 	mov	x1, x21
    7384:	aa0003e2 	mov	x2, x0
    7388:	aa1403e0 	mov	x0, x20
    738c:	97fff021 	bl	3410 <buf_put>
    7390:	f9413bf5 	ldr	x21, [sp, #624]
    7394:	f9413ff6 	ldr	x22, [sp, #632]
    7398:	f94153fb 	ldr	x27, [sp, #672]
    739c:	f94157fc 	ldr	x28, [sp, #680]
    73a0:	fd415be8 	ldr	d8, [sp, #688]
    73a4:	fd415fe9 	ldr	d9, [sp, #696]
    73a8:	17fffeb6 	b	6e80 <fwp_write+0xb0>
    73ac:	f9400276 	ldr	x22, [x19]
    73b0:	34002e03 	cbz	w3, 7970 <fwp_write+0xba0>
    73b4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    73b8:	f947f400 	ldr	x0, [x0, #4072]
    73bc:	f94127e2 	ldr	x2, [sp, #584]
    73c0:	f9400001 	ldr	x1, [x0]
    73c4:	eb010042 	subs	x2, x2, x1
    73c8:	d2800001 	mov	x1, #0x0                   	// #0
    73cc:	540014a1 	b.ne	7660 <fwp_write+0x890>  // b.any
    73d0:	aa1603e2 	mov	x2, x22
    73d4:	91002261 	add	x1, x19, #0x8
    73d8:	f9413bf5 	ldr	x21, [sp, #624]
    73dc:	aa1403e0 	mov	x0, x20
    73e0:	f9413ff6 	ldr	x22, [sp, #632]
    73e4:	17fffeff 	b	6fe0 <fwp_write+0x210>
    73e8:	fd015be8 	str	d8, [sp, #688]
    73ec:	9e670268 	fmov	d8, x19
    73f0:	fd015fe9 	str	d9, [sp, #696]
    73f4:	1e682100 	fcmp	d8, d8
    73f8:	54004746 	b.vs	7ce0 <fwp_write+0xf10>
    73fc:	1e60c101 	fabs	d1, d8
    7400:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7404:	9e670000 	fmov	d0, x0
    7408:	910123f5 	add	x21, sp, #0x48
    740c:	52800033 	mov	w19, #0x1                   	// #1
    7410:	1e602020 	fcmp	d1, d0
    7414:	540001ad 	b.le	7448 <fwp_write+0x678>
    7418:	1e602118 	fcmpe	d8, #0.0
    741c:	b0000022 	adrp	x2, c000 <fwp_main_thread+0x120>
    7420:	912d8042 	add	x2, x2, #0xb60
    7424:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    7428:	913ce021 	add	x1, x1, #0xf38
    742c:	aa1503e0 	mov	x0, x21
    7430:	9a81c041 	csel	x1, x2, x1, gt
    7434:	97ffed63 	bl	29c0 <strcpy@plt>
    7438:	17ffffd0 	b	7378 <fwp_write+0x5a8>
    743c:	11000673 	add	w19, w19, #0x1
    7440:	71004a7f 	cmp	w19, #0x12
    7444:	54003860 	b.eq	7b50 <fwp_write+0xd80>  // b.none
    7448:	1e604100 	fmov	d0, d8
    744c:	2a1303e1 	mov	w1, w19
    7450:	aa1503e0 	mov	x0, x21
    7454:	97fff130 	bl	3914 <fwp_format_g.constprop.0>
    7458:	aa1503e0 	mov	x0, x21
    745c:	d2800001 	mov	x1, #0x0                   	// #0
    7460:	97ffecc0 	bl	2760 <strtod@plt>
    7464:	1e602100 	fcmp	d8, d0
    7468:	54fffea1 	b.ne	743c <fwp_write+0x66c>  // b.any
    746c:	aa1503e0 	mov	x0, x21
    7470:	97fff021 	bl	34f4 <fwp_finish_float>
    7474:	17ffffc1 	b	7378 <fwp_write+0x5a8>
    7478:	a9400e62 	ldp	x2, x3, [x19]
    747c:	910123f3 	add	x19, sp, #0x48
    7480:	aa1303e0 	mov	x0, x19
    7484:	97ffee67 	bl	2e20 <fwp_fmt_u128>
    7488:	17fffe74 	b	6e58 <fwp_write+0x88>
    748c:	f90143f7 	str	x23, [sp, #640]
    7490:	f90147f8 	str	x24, [sp, #648]
    7494:	2a1303f8 	mov	w24, w19
    7498:	f9014bf9 	str	x25, [sp, #656]
    749c:	f9014ffa 	str	x26, [sp, #664]
    74a0:	f13ffe7f 	cmp	x19, #0xfff
    74a4:	54000049 	b.ls	74ac <fwp_write+0x6dc>  // b.plast
    74a8:	b9400278 	ldr	w24, [x19]
    74ac:	f9400f80 	ldr	x0, [x28, #24]
    74b0:	2a1803f5 	mov	w21, w24
    74b4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    74b8:	d37ef6b9 	lsl	x25, x21, #2
    74bc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    74c0:	aa1603e0 	mov	x0, x22
    74c4:	97ffec93 	bl	2710 <strlen@plt>
    74c8:	aa1603e1 	mov	x1, x22
    74cc:	aa0003e2 	mov	x2, x0
    74d0:	aa1403e0 	mov	x0, x20
    74d4:	97ffefcf 	bl	3410 <buf_put>
    74d8:	f9401780 	ldr	x0, [x28, #40]
    74dc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    74e0:	7100001f 	cmp	w0, #0x0
    74e4:	5400068d 	b.le	75b4 <fwp_write+0x7e4>
    74e8:	91002276 	add	x22, x19, #0x8
    74ec:	91001ff5 	add	x21, sp, #0x7
    74f0:	d280001b 	mov	x27, #0x0                   	// #0
    74f4:	5280041a 	mov	w26, #0x20                  	// #32
    74f8:	f9401b80 	ldr	x0, [x28, #48]
    74fc:	aa1503e1 	mov	x1, x21
    7500:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7504:	d2800022 	mov	x2, #0x1                   	// #1
    7508:	f8786803 	ldr	x3, [x0, x24]
    750c:	aa1403e0 	mov	x0, x20
    7510:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7514:	39001ffa 	strb	w26, [sp, #7]
    7518:	97ffefbe 	bl	3410 <buf_put>
    751c:	f13ffeff 	cmp	x23, #0xfff
    7520:	b9400261 	ldr	w1, [x19]
    7524:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7528:	7100383f 	cmp	w1, #0xe
    752c:	54000160 	b.eq	7558 <fwp_write+0x788>  // b.none
    7530:	7100403f 	cmp	w1, #0x10
    7534:	54001a60 	b.eq	7880 <fwp_write+0xab0>  // b.none
    7538:	7100283f 	cmp	w1, #0xa
    753c:	54002aa0 	b.eq	7a90 <fwp_write+0xcc0>  // b.none
    7540:	540014ac 	b.gt	77d4 <fwp_write+0xa04>
    7544:	71000c3f 	cmp	w1, #0x3
    7548:	540029ac 	b.gt	7a7c <fwp_write+0xcac>
    754c:	d37ffee0 	lsr	x0, x23, #63
    7550:	37f814a1 	tbnz	w1, #31, 77e4 <fwp_write+0xa14>
    7554:	d503201f 	nop
    7558:	34001460 	cbz	w0, 77e4 <fwp_write+0xa14>
    755c:	52800503 	mov	w3, #0x28                  	// #40
    7560:	aa1503e1 	mov	x1, x21
    7564:	aa1403e0 	mov	x0, x20
    7568:	d2800022 	mov	x2, #0x1                   	// #1
    756c:	39001fe3 	strb	w3, [sp, #7]
    7570:	97ffefa8 	bl	3410 <buf_put>
    7574:	aa1303e2 	mov	x2, x19
    7578:	aa1703e1 	mov	x1, x23
    757c:	aa1403e0 	mov	x0, x20
    7580:	52800003 	mov	w3, #0x0                   	// #0
    7584:	97fffe13 	bl	6dd0 <fwp_write>
    7588:	52800523 	mov	w3, #0x29                  	// #41
    758c:	aa1503e1 	mov	x1, x21
    7590:	aa1403e0 	mov	x0, x20
    7594:	d2800022 	mov	x2, #0x1                   	// #1
    7598:	39001fe3 	strb	w3, [sp, #7]
    759c:	97ffef9d 	bl	3410 <buf_put>
    75a0:	f9401780 	ldr	x0, [x28, #40]
    75a4:	9100077b 	add	x27, x27, #0x1
    75a8:	b8796800 	ldr	w0, [x0, x25]
    75ac:	6b1b001f 	cmp	w0, w27
    75b0:	54fffa4c 	b.gt	74f8 <fwp_write+0x728>
    75b4:	f9413bf5 	ldr	x21, [sp, #624]
    75b8:	f9413ff6 	ldr	x22, [sp, #632]
    75bc:	f94143f7 	ldr	x23, [sp, #640]
    75c0:	f94147f8 	ldr	x24, [sp, #648]
    75c4:	f9414bf9 	ldr	x25, [sp, #656]
    75c8:	f9414ffa 	ldr	x26, [sp, #664]
    75cc:	f94153fb 	ldr	x27, [sp, #672]
    75d0:	f94157fc 	ldr	x28, [sp, #680]
    75d4:	17fffe2b 	b	6e80 <fwp_write+0xb0>
    75d8:	52800783 	mov	w3, #0x3c                  	// #60
    75dc:	91001ff3 	add	x19, sp, #0x7
    75e0:	aa1303e1 	mov	x1, x19
    75e4:	d2800022 	mov	x2, #0x1                   	// #1
    75e8:	aa1403e0 	mov	x0, x20
    75ec:	39001fe3 	strb	w3, [sp, #7]
    75f0:	97ffef88 	bl	3410 <buf_put>
    75f4:	f9400795 	ldr	x21, [x28, #8]
    75f8:	aa1503e0 	mov	x0, x21
    75fc:	97ffec45 	bl	2710 <strlen@plt>
    7600:	aa1503e1 	mov	x1, x21
    7604:	aa0003e2 	mov	x2, x0
    7608:	aa1403e0 	mov	x0, x20
    760c:	97ffef81 	bl	3410 <buf_put>
    7610:	528007c3 	mov	w3, #0x3e                  	// #62
    7614:	aa1303e1 	mov	x1, x19
    7618:	aa1403e0 	mov	x0, x20
    761c:	d2800022 	mov	x2, #0x1                   	// #1
    7620:	39001fe3 	strb	w3, [sp, #7]
    7624:	17fffe12 	b	6e6c <fwp_write+0x9c>
    7628:	f100067f 	cmp	x19, #0x1
    762c:	540025a0 	b.eq	7ae0 <fwp_write+0xd10>  // b.none
    7630:	b100067f 	cmn	x19, #0x1
    7634:	54002bc0 	b.eq	7bac <fwp_write+0xddc>  // b.none
    7638:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    763c:	913d0021 	add	x1, x1, #0xf40
    7640:	d2800022 	mov	x2, #0x1                   	// #1
    7644:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7648:	f947f400 	ldr	x0, [x0, #4072]
    764c:	f94127e4 	ldr	x4, [sp, #584]
    7650:	f9400003 	ldr	x3, [x0]
    7654:	eb030084 	subs	x4, x4, x3
    7658:	d2800003 	mov	x3, #0x0                   	// #0
    765c:	54ffebe0 	b.eq	73d8 <fwp_write+0x608>  // b.none
    7660:	f90143f7 	str	x23, [sp, #640]
    7664:	f90147f8 	str	x24, [sp, #648]
    7668:	f9014bf9 	str	x25, [sp, #656]
    766c:	f9014ffa 	str	x26, [sp, #664]
    7670:	fd015be8 	str	d8, [sp, #688]
    7674:	fd015fe9 	str	d9, [sp, #696]
    7678:	97ffec82 	bl	2880 <__stack_chk_fail@plt>
    767c:	52800b63 	mov	w3, #0x5b                  	// #91
    7680:	91001ff5 	add	x21, sp, #0x7
    7684:	aa1503e1 	mov	x1, x21
    7688:	aa1403e0 	mov	x0, x20
    768c:	d2800022 	mov	x2, #0x1                   	// #1
    7690:	b0000036 	adrp	x22, c000 <fwp_main_thread+0x120>
    7694:	913f82d6 	add	x22, x22, #0xfe0
    7698:	39001fe3 	strb	w3, [sp, #7]
    769c:	97ffef5d 	bl	3410 <buf_put>
    76a0:	b4000273 	cbz	x19, 76ec <fwp_write+0x91c>
    76a4:	f9400661 	ldr	x1, [x19, #8]
    76a8:	aa1403e0 	mov	x0, x20
    76ac:	f9401f82 	ldr	x2, [x28, #56]
    76b0:	52800003 	mov	w3, #0x0                   	// #0
    76b4:	97fffdc7 	bl	6dd0 <fwp_write>
    76b8:	f9400a73 	ldr	x19, [x19, #16]
    76bc:	b4000193 	cbz	x19, 76ec <fwp_write+0x91c>
    76c0:	aa1603e1 	mov	x1, x22
    76c4:	aa1403e0 	mov	x0, x20
    76c8:	d2800042 	mov	x2, #0x2                   	// #2
    76cc:	97ffef51 	bl	3410 <buf_put>
    76d0:	f9400661 	ldr	x1, [x19, #8]
    76d4:	aa1403e0 	mov	x0, x20
    76d8:	f9401f82 	ldr	x2, [x28, #56]
    76dc:	52800003 	mov	w3, #0x0                   	// #0
    76e0:	97fffdbc 	bl	6dd0 <fwp_write>
    76e4:	f9400a73 	ldr	x19, [x19, #16]
    76e8:	b5fffed3 	cbnz	x19, 76c0 <fwp_write+0x8f0>
    76ec:	52800ba3 	mov	w3, #0x5d                  	// #93
    76f0:	aa1503e1 	mov	x1, x21
    76f4:	aa1403e0 	mov	x0, x20
    76f8:	d2800022 	mov	x2, #0x1                   	// #1
    76fc:	39001fe3 	strb	w3, [sp, #7]
    7700:	17fffddb 	b	6e6c <fwp_write+0x9c>
    7704:	aa1403e0 	mov	x0, x20
    7708:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    770c:	d28000c2 	mov	x2, #0x6                   	// #6
    7710:	913f4021 	add	x1, x1, #0xfd0
    7714:	97ffef3f 	bl	3410 <buf_put>
    7718:	f9400260 	ldr	x0, [x19]
    771c:	b40004c0 	cbz	x0, 77b4 <fwp_write+0x9e4>
    7720:	910123f5 	add	x21, sp, #0x48
    7724:	91002276 	add	x22, x19, #0x8
    7728:	f90143f7 	str	x23, [sp, #640]
    772c:	d2800017 	mov	x23, #0x0                   	// #0
    7730:	f90147f8 	str	x24, [sp, #648]
    7734:	b0000038 	adrp	x24, c000 <fwp_main_thread+0x120>
    7738:	913f6318 	add	x24, x24, #0xfd8
    773c:	f9014bf9 	str	x25, [sp, #656]
    7740:	b0000039 	adrp	x25, c000 <fwp_main_thread+0x120>
    7744:	913f8339 	add	x25, x25, #0xfe0
    7748:	f9014ffa 	str	x26, [sp, #664]
    774c:	14000005 	b	7760 <fwp_write+0x990>
    7750:	aa1903e1 	mov	x1, x25
    7754:	aa1403e0 	mov	x0, x20
    7758:	d2800042 	mov	x2, #0x2                   	// #2
    775c:	97ffef2d 	bl	3410 <buf_put>
    7760:	38776ac5 	ldrb	w5, [x22, x23]
    7764:	d2804003 	mov	x3, #0x200                 	// #512
    7768:	aa1803e4 	mov	x4, x24
    776c:	aa0303e1 	mov	x1, x3
    7770:	52800042 	mov	w2, #0x2                   	// #2
    7774:	aa1503e0 	mov	x0, x21
    7778:	910006f7 	add	x23, x23, #0x1
    777c:	97ffec1d 	bl	27f0 <__snprintf_chk@plt>
    7780:	aa1503e0 	mov	x0, x21
    7784:	97ffebe3 	bl	2710 <strlen@plt>
    7788:	aa1503e1 	mov	x1, x21
    778c:	aa0003e2 	mov	x2, x0
    7790:	aa1403e0 	mov	x0, x20
    7794:	97ffef1f 	bl	3410 <buf_put>
    7798:	f9400260 	ldr	x0, [x19]
    779c:	eb17001f 	cmp	x0, x23
    77a0:	54fffd88 	b.hi	7750 <fwp_write+0x980>  // b.pmore
    77a4:	f94143f7 	ldr	x23, [sp, #640]
    77a8:	f94147f8 	ldr	x24, [sp, #648]
    77ac:	f9414bf9 	ldr	x25, [sp, #656]
    77b0:	f9414ffa 	ldr	x26, [sp, #664]
    77b4:	52800ba3 	mov	w3, #0x5d                  	// #93
    77b8:	aa1403e0 	mov	x0, x20
    77bc:	91001fe1 	add	x1, sp, #0x7
    77c0:	d2800022 	mov	x2, #0x1                   	// #1
    77c4:	39001fe3 	strb	w3, [sp, #7]
    77c8:	17fffda9 	b	6e6c <fwp_write+0x9c>
    77cc:	52800fa3 	mov	w3, #0x7d                  	// #125
    77d0:	17fffe44 	b	70e0 <fwp_write+0x310>
    77d4:	f10002ff 	cmp	x23, #0x0
    77d8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    77dc:	71002c3f 	cmp	w1, #0xb
    77e0:	54ffebc0 	b.eq	7558 <fwp_write+0x788>  // b.none
    77e4:	aa1303e2 	mov	x2, x19
    77e8:	aa1703e1 	mov	x1, x23
    77ec:	aa1403e0 	mov	x0, x20
    77f0:	52800003 	mov	w3, #0x0                   	// #0
    77f4:	97fffd77 	bl	6dd0 <fwp_write>
    77f8:	17ffff6a 	b	75a0 <fwp_write+0x7d0>
    77fc:	aa1403e0 	mov	x0, x20
    7800:	91001fe1 	add	x1, sp, #0x7
    7804:	52800fa3 	mov	w3, #0x7d                  	// #125
    7808:	d2800022 	mov	x2, #0x1                   	// #1
    780c:	17fffe38 	b	70ec <fwp_write+0x31c>
    7810:	a9400281 	ldp	x1, x0, [x20]
    7814:	91000800 	add	x0, x0, #0x2
    7818:	8b160000 	add	x0, x0, x22
    781c:	f9000680 	str	x0, [x20, #8]
    7820:	3820683f 	strb	wzr, [x1, x0]
    7824:	f9413bf5 	ldr	x21, [sp, #624]
    7828:	f9413ff6 	ldr	x22, [sp, #632]
    782c:	f94153fb 	ldr	x27, [sp, #672]
    7830:	f94157fc 	ldr	x28, [sp, #680]
    7834:	17fffd93 	b	6e80 <fwp_write+0xb0>
    7838:	f9400f80 	ldr	x0, [x28, #24]
    783c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7840:	aa1b03e0 	mov	x0, x27
    7844:	97ffebb3 	bl	2710 <strlen@plt>
    7848:	aa1b03e1 	mov	x1, x27
    784c:	aa0003e2 	mov	x2, x0
    7850:	aa1403e0 	mov	x0, x20
    7854:	97ffeeef 	bl	3410 <buf_put>
    7858:	aa1903e1 	mov	x1, x25
    785c:	aa1403e0 	mov	x0, x20
    7860:	d2800062 	mov	x2, #0x3                   	// #3
    7864:	97ffeeeb 	bl	3410 <buf_put>
    7868:	17fffe10 	b	70a8 <fwp_write+0x2d8>
    786c:	aa1a03e1 	mov	x1, x26
    7870:	aa1403e0 	mov	x0, x20
    7874:	d2800042 	mov	x2, #0x2                   	// #2
    7878:	97ffeee6 	bl	3410 <buf_put>
    787c:	17fffe09 	b	70a0 <fwp_write+0x2d0>
    7880:	f9400660 	ldr	x0, [x19, #8]
    7884:	b4fffb00 	cbz	x0, 77e4 <fwp_write+0xa14>
    7888:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    788c:	913fe021 	add	x1, x1, #0xff8
    7890:	97ffec1c 	bl	2900 <strcmp@plt>
    7894:	7100001f 	cmp	w0, #0x0
    7898:	1a9f07e0 	cset	w0, ne	// ne = any
    789c:	17ffff2f 	b	7558 <fwp_write+0x788>
    78a0:	aa1403e0 	mov	x0, x20
    78a4:	d2800042 	mov	x2, #0x2                   	// #2
    78a8:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    78ac:	913fc021 	add	x1, x1, #0xff0
    78b0:	97ffeed8 	bl	3410 <buf_put>
    78b4:	91004261 	add	x1, x19, #0x10
    78b8:	aa1403e0 	mov	x0, x20
    78bc:	f9402382 	ldr	x2, [x28, #64]
    78c0:	52800003 	mov	w3, #0x0                   	// #0
    78c4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    78c8:	97fffd42 	bl	6dd0 <fwp_write>
    78cc:	17fffd9c 	b	6f3c <fwp_write+0x16c>
    78d0:	1e22c109 	fcvt	d9, s8
    78d4:	910123f5 	add	x21, sp, #0x48
    78d8:	52800033 	mov	w19, #0x1                   	// #1
    78dc:	d503201f 	nop
    78e0:	1e604120 	fmov	d0, d9
    78e4:	2a1303e1 	mov	w1, w19
    78e8:	aa1503e0 	mov	x0, x21
    78ec:	97fff00a 	bl	3914 <fwp_format_g.constprop.0>
    78f0:	aa1503e0 	mov	x0, x21
    78f4:	d2800001 	mov	x1, #0x0                   	// #0
    78f8:	97ffec0e 	bl	2930 <strtof@plt>
    78fc:	1e202100 	fcmp	s8, s0
    7900:	54ffdb60 	b.eq	746c <fwp_write+0x69c>  // b.none
    7904:	11000673 	add	w19, w19, #0x1
    7908:	71002a7f 	cmp	w19, #0xa
    790c:	54fffea1 	b.ne	78e0 <fwp_write+0xb10>  // b.any
    7910:	1e604120 	fmov	d0, d9
    7914:	aa1503e0 	mov	x0, x21
    7918:	52800121 	mov	w1, #0x9                   	// #9
    791c:	97ffeffe 	bl	3914 <fwp_format_g.constprop.0>
    7920:	17fffed3 	b	746c <fwp_write+0x69c>
    7924:	d37ef6a1 	lsl	x1, x21, #2
    7928:	b7f81563 	tbnz	x3, #63, 7bd4 <fwp_write+0xe04>
    792c:	91002263 	add	x3, x19, #0x8
    7930:	8b010061 	add	x1, x3, x1
    7934:	b9400023 	ldr	w3, [x1]
    7938:	7100081f 	cmp	w0, #0x2
    793c:	2a0303e1 	mov	w1, w3
    7940:	93407c63 	sxtw	x3, w3
    7944:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7948:	17fffe5a 	b	72b0 <fwp_write+0x4e0>
    794c:	d37ffaa1 	lsl	x1, x21, #1
    7950:	b7f81363 	tbnz	x3, #63, 7bbc <fwp_write+0xdec>
    7954:	91002263 	add	x3, x19, #0x8
    7958:	8b010061 	add	x1, x3, x1
    795c:	79400021 	ldrh	w1, [x1]
    7960:	7100041f 	cmp	w0, #0x1
    7964:	93403c23 	sxth	x3, w1
    7968:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    796c:	17fffe51 	b	72b0 <fwp_write+0x4e0>
    7970:	52800443 	mov	w3, #0x22                  	// #34
    7974:	91001ff5 	add	x21, sp, #0x7
    7978:	91002273 	add	x19, x19, #0x8
    797c:	aa1503e1 	mov	x1, x21
    7980:	aa1403e0 	mov	x0, x20
    7984:	d2800022 	mov	x2, #0x1                   	// #1
    7988:	39001fe3 	strb	w3, [sp, #7]
    798c:	f90143f7 	str	x23, [sp, #640]
    7990:	8b160277 	add	x23, x19, x22
    7994:	f90147f8 	str	x24, [sp, #648]
    7998:	97ffee9e 	bl	3410 <buf_put>
    799c:	b4000696 	cbz	x22, 7a6c <fwp_write+0xc9c>
    79a0:	b0000038 	adrp	x24, c000 <fwp_main_thread+0x120>
    79a4:	913e8318 	add	x24, x24, #0xfa0
    79a8:	f9014bf9 	str	x25, [sp, #656]
    79ac:	b0000039 	adrp	x25, c000 <fwp_main_thread+0x120>
    79b0:	913f0339 	add	x25, x25, #0xfc0
    79b4:	f9014ffa 	str	x26, [sp, #664]
    79b8:	1400000d 	b	79ec <fwp_write+0xc1c>
    79bc:	710024bf 	cmp	w5, #0x9
    79c0:	54000460 	b.eq	7a4c <fwp_write+0xc7c>  // b.none
    79c4:	710028bf 	cmp	w5, #0xa
    79c8:	54000a61 	b.ne	7b14 <fwp_write+0xd44>  // b.any
    79cc:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    79d0:	aa1403e0 	mov	x0, x20
    79d4:	913ec021 	add	x1, x1, #0xfb0
    79d8:	d2800042 	mov	x2, #0x2                   	// #2
    79dc:	97ffee8d 	bl	3410 <buf_put>
    79e0:	91000673 	add	x19, x19, #0x1
    79e4:	eb17027f 	cmp	x19, x23
    79e8:	540003e0 	b.eq	7a64 <fwp_write+0xc94>  // b.none
    79ec:	39400265 	ldrb	w5, [x19]
    79f0:	710034bf 	cmp	w5, #0xd
    79f4:	54000180 	b.eq	7a24 <fwp_write+0xc54>  // b.none
    79f8:	54fffe29 	b.ls	79bc <fwp_write+0xbec>  // b.plast
    79fc:	710088bf 	cmp	w5, #0x22
    7a00:	540001c0 	b.eq	7a38 <fwp_write+0xc68>  // b.none
    7a04:	710170bf 	cmp	w5, #0x5c
    7a08:	54000741 	b.ne	7af0 <fwp_write+0xd20>  // b.any
    7a0c:	aa1403e0 	mov	x0, x20
    7a10:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    7a14:	d2800042 	mov	x2, #0x2                   	// #2
    7a18:	913ea021 	add	x1, x1, #0xfa8
    7a1c:	97ffee7d 	bl	3410 <buf_put>
    7a20:	17fffff0 	b	79e0 <fwp_write+0xc10>
    7a24:	aa1903e1 	mov	x1, x25
    7a28:	aa1403e0 	mov	x0, x20
    7a2c:	d2800042 	mov	x2, #0x2                   	// #2
    7a30:	97ffee78 	bl	3410 <buf_put>
    7a34:	17ffffeb 	b	79e0 <fwp_write+0xc10>
    7a38:	aa1803e1 	mov	x1, x24
    7a3c:	aa1403e0 	mov	x0, x20
    7a40:	d2800042 	mov	x2, #0x2                   	// #2
    7a44:	97ffee73 	bl	3410 <buf_put>
    7a48:	17ffffe6 	b	79e0 <fwp_write+0xc10>
    7a4c:	aa1403e0 	mov	x0, x20
    7a50:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    7a54:	d2800042 	mov	x2, #0x2                   	// #2
    7a58:	913ee021 	add	x1, x1, #0xfb8
    7a5c:	97ffee6d 	bl	3410 <buf_put>
    7a60:	17ffffe0 	b	79e0 <fwp_write+0xc10>
    7a64:	f9414bf9 	ldr	x25, [sp, #656]
    7a68:	f9414ffa 	ldr	x26, [sp, #664]
    7a6c:	aa1503e1 	mov	x1, x21
    7a70:	aa1403e0 	mov	x0, x20
    7a74:	52800443 	mov	w3, #0x22                  	// #34
    7a78:	17fffd9c 	b	70e8 <fwp_write+0x318>
    7a7c:	7100103f 	cmp	w1, #0x4
    7a80:	54ffeb21 	b.ne	77e4 <fwp_write+0xa14>  // b.any
    7a84:	f94006e0 	ldr	x0, [x23, #8]
    7a88:	d37ffc00 	lsr	x0, x0, #63
    7a8c:	17fffeb3 	b	7558 <fwp_write+0x788>
    7a90:	710002ff 	cmp	w23, #0x0
    7a94:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7a98:	17fffeb0 	b	7558 <fwp_write+0x788>
    7a9c:	528005a1 	mov	w1, #0x2d                  	// #45
    7aa0:	eb0203e2 	negs	x2, x2
    7aa4:	da0303e3 	ngc	x3, x3
    7aa8:	910127e0 	add	x0, sp, #0x49
    7aac:	910123f5 	add	x21, sp, #0x48
    7ab0:	390123e1 	strb	w1, [sp, #72]
    7ab4:	97ffecdb 	bl	2e20 <fwp_fmt_u128>
    7ab8:	17fffe18 	b	7318 <fwp_write+0x548>
    7abc:	d37ceea1 	lsl	x1, x21, #4
    7ac0:	b7f810a3 	tbnz	x3, #63, 7cd4 <fwp_write+0xf04>
    7ac4:	91002260 	add	x0, x19, #0x8
    7ac8:	8b010001 	add	x1, x0, x1
    7acc:	17fffdf9 	b	72b0 <fwp_write+0x4e0>
    7ad0:	f9400a61 	ldr	x1, [x19, #16]
    7ad4:	8b010000 	add	x0, x0, x1
    7ad8:	f9400001 	ldr	x1, [x0]
    7adc:	17fffdf5 	b	72b0 <fwp_write+0x4e0>
    7ae0:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    7ae4:	d2800042 	mov	x2, #0x2                   	// #2
    7ae8:	913d2021 	add	x1, x1, #0xf48
    7aec:	17fffed6 	b	7644 <fwp_write+0x874>
    7af0:	7101fcbf 	cmp	w5, #0x7f
    7af4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7af8:	540000e9 	b.ls	7b14 <fwp_write+0xd44>  // b.plast
    7afc:	aa1503e1 	mov	x1, x21
    7b00:	aa1403e0 	mov	x0, x20
    7b04:	d2800022 	mov	x2, #0x1                   	// #1
    7b08:	39001fe5 	strb	w5, [sp, #7]
    7b0c:	97ffee41 	bl	3410 <buf_put>
    7b10:	17ffffb4 	b	79e0 <fwp_write+0xc10>
    7b14:	d2800203 	mov	x3, #0x10                  	// #16
    7b18:	b0000024 	adrp	x4, c000 <fwp_main_thread+0x120>
    7b1c:	aa0303e1 	mov	x1, x3
    7b20:	913f2084 	add	x4, x4, #0xfc8
    7b24:	910123f6 	add	x22, sp, #0x48
    7b28:	52800042 	mov	w2, #0x2                   	// #2
    7b2c:	aa1603e0 	mov	x0, x22
    7b30:	97ffeb30 	bl	27f0 <__snprintf_chk@plt>
    7b34:	aa1603e0 	mov	x0, x22
    7b38:	97ffeaf6 	bl	2710 <strlen@plt>
    7b3c:	aa1603e1 	mov	x1, x22
    7b40:	aa0003e2 	mov	x2, x0
    7b44:	aa1403e0 	mov	x0, x20
    7b48:	97ffee32 	bl	3410 <buf_put>
    7b4c:	17ffffa5 	b	79e0 <fwp_write+0xc10>
    7b50:	1e604100 	fmov	d0, d8
    7b54:	aa1503e0 	mov	x0, x21
    7b58:	52800221 	mov	w1, #0x11                  	// #17
    7b5c:	97ffef6e 	bl	3914 <fwp_format_g.constprop.0>
    7b60:	17fffe43 	b	746c <fwp_write+0x69c>
    7b64:	b9401040 	ldr	w0, [x2, #16]
    7b68:	350003c0 	cbnz	w0, 7be0 <fwp_write+0xe10>
    7b6c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7b70:	f947f400 	ldr	x0, [x0, #4072]
    7b74:	f94127e2 	ldr	x2, [sp, #584]
    7b78:	f9400001 	ldr	x1, [x0]
    7b7c:	eb010042 	subs	x2, x2, x1
    7b80:	d2800001 	mov	x1, #0x0                   	// #0
    7b84:	54ffd721 	b.ne	7668 <fwp_write+0x898>  // b.any
    7b88:	f9413bf5 	ldr	x21, [sp, #624]
    7b8c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x4c0>
    7b90:	f9413ff6 	ldr	x22, [sp, #632]
    7b94:	aa1403e0 	mov	x0, x20
    7b98:	f94143f7 	ldr	x23, [sp, #640]
    7b9c:	91006021 	add	x1, x1, #0x18
    7ba0:	f94147f8 	ldr	x24, [sp, #648]
    7ba4:	d2800042 	mov	x2, #0x2                   	// #2
    7ba8:	17fffd0e 	b	6fe0 <fwp_write+0x210>
    7bac:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x120>
    7bb0:	d2800042 	mov	x2, #0x2                   	// #2
    7bb4:	913d4021 	add	x1, x1, #0xf50
    7bb8:	17fffea3 	b	7644 <fwp_write+0x874>
    7bbc:	f9400a63 	ldr	x3, [x19, #16]
    7bc0:	8b030021 	add	x1, x1, x3
    7bc4:	17ffff66 	b	795c <fwp_write+0xb8c>
    7bc8:	f9400a61 	ldr	x1, [x19, #16]
    7bcc:	8b0102a1 	add	x1, x21, x1
    7bd0:	17fffdb3 	b	729c <fwp_write+0x4cc>
    7bd4:	f9400a63 	ldr	x3, [x19, #16]
    7bd8:	8b030021 	add	x1, x1, x3
    7bdc:	17ffff56 	b	7934 <fwp_write+0xb64>
    7be0:	b9404840 	ldr	w0, [x2, #72]
    7be4:	91001ff5 	add	x21, sp, #0x7
    7be8:	34ffa360 	cbz	w0, 7054 <fwp_write+0x284>
    7bec:	52800503 	mov	w3, #0x28                  	// #40
    7bf0:	aa1403e0 	mov	x0, x20
    7bf4:	aa1503e1 	mov	x1, x21
    7bf8:	d2800022 	mov	x2, #0x1                   	// #1
    7bfc:	39001fe3 	strb	w3, [sp, #7]
    7c00:	97ffee04 	bl	3410 <buf_put>
    7c04:	b9401380 	ldr	w0, [x28, #16]
    7c08:	52800038 	mov	w24, #0x1                   	// #1
    7c0c:	7100001f 	cmp	w0, #0x0
    7c10:	54ffa36c 	b.gt	707c <fwp_write+0x2ac>
    7c14:	17fffd32 	b	70dc <fwp_write+0x30c>
    7c18:	f9014bf9 	str	x25, [sp, #656]
    7c1c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xf4c0>
    7c20:	f9014ffa 	str	x26, [sp, #664]
    7c24:	f9400676 	ldr	x22, [x19, #8]
    7c28:	910aa333 	add	x19, x25, #0x2a8
    7c2c:	91002273 	add	x19, x19, #0x8
    7c30:	937ffed8 	asr	x24, x22, #63
    7c34:	aa1802c0 	orr	x0, x22, x24
    7c38:	b5000320 	cbnz	x0, 7c9c <fwp_write+0xecc>
    7c3c:	110006b5 	add	w21, w21, #0x1
    7c40:	710016bf 	cmp	w21, #0x5
    7c44:	54ffffc1 	b.ne	7c3c <fwp_write+0xe6c>  // b.any
    7c48:	b7f80578 	tbnz	x24, #63, 7cf4 <fwp_write+0xf24>
    7c4c:	910023f3 	add	x19, sp, #0x8
    7c50:	aa1603e2 	mov	x2, x22
    7c54:	aa1303e0 	mov	x0, x19
    7c58:	d2800003 	mov	x3, #0x0                   	// #0
    7c5c:	97ffec71 	bl	2e20 <fwp_fmt_u128>
    7c60:	910123f5 	add	x21, sp, #0x48
    7c64:	d0000023 	adrp	x3, d000 <_IO_stdin_used+0x4c0>
    7c68:	aa1303e4 	mov	x4, x19
    7c6c:	aa1503e0 	mov	x0, x21
    7c70:	91004063 	add	x3, x3, #0x10
    7c74:	d2804002 	mov	x2, #0x200                 	// #512
    7c78:	52800041 	mov	w1, #0x2                   	// #2
    7c7c:	97ffeaa9 	bl	2720 <__sprintf_chk@plt>
    7c80:	aa1503e0 	mov	x0, x21
    7c84:	97ffeaa3 	bl	2710 <strlen@plt>
    7c88:	aa1503e1 	mov	x1, x21
    7c8c:	aa0003e2 	mov	x2, x0
    7c90:	aa1403e0 	mov	x0, x20
    7c94:	97ffeddf 	bl	3410 <buf_put>
    7c98:	17fffe47 	b	75b4 <fwp_write+0x7e4>
    7c9c:	f9400277 	ldr	x23, [x19]
    7ca0:	aa1603e0 	mov	x0, x22
    7ca4:	aa1803e1 	mov	x1, x24
    7ca8:	aa1703e2 	mov	x2, x23
    7cac:	937ffefa 	asr	x26, x23, #63
    7cb0:	aa1a03e3 	mov	x3, x26
    7cb4:	940012bb 	bl	c7a0 <__modti3>
    7cb8:	aa010000 	orr	x0, x0, x1
    7cbc:	b40002c0 	cbz	x0, 7d14 <fwp_write+0xf44>
    7cc0:	110006b5 	add	w21, w21, #0x1
    7cc4:	91004273 	add	x19, x19, #0x10
    7cc8:	710016bf 	cmp	w21, #0x5
    7ccc:	54fffe81 	b.ne	7c9c <fwp_write+0xecc>  // b.any
    7cd0:	17ffffde 	b	7c48 <fwp_write+0xe78>
    7cd4:	f9400a60 	ldr	x0, [x19, #16]
    7cd8:	8b000021 	add	x1, x1, x0
    7cdc:	17fffd75 	b	72b0 <fwp_write+0x4e0>
    7ce0:	528c29c0 	mov	w0, #0x614e                	// #24910
    7ce4:	910123f5 	add	x21, sp, #0x48
    7ce8:	72a009c0 	movk	w0, #0x4e, lsl #16
    7cec:	b9004be0 	str	w0, [sp, #72]
    7cf0:	17fffda2 	b	7378 <fwp_write+0x5a8>
    7cf4:	528005a1 	mov	w1, #0x2d                  	// #45
    7cf8:	eb1603e2 	negs	x2, x22
    7cfc:	da1803e3 	ngc	x3, x24
    7d00:	910027e0 	add	x0, sp, #0x9
    7d04:	910023f3 	add	x19, sp, #0x8
    7d08:	390023e1 	strb	w1, [sp, #8]
    7d0c:	97ffec45 	bl	2e20 <fwp_fmt_u128>
    7d10:	17ffffd4 	b	7c60 <fwp_write+0xe90>
    7d14:	aa1703e2 	mov	x2, x23
    7d18:	aa1a03e3 	mov	x3, x26
    7d1c:	aa1603e0 	mov	x0, x22
    7d20:	aa1803e1 	mov	x1, x24
    7d24:	940011bf 	bl	c420 <__divti3>
    7d28:	aa0003e2 	mov	x2, x0
    7d2c:	aa0103e3 	mov	x3, x1
    7d30:	b7f80201 	tbnz	x1, #63, 7d70 <fwp_write+0xfa0>
    7d34:	910023f3 	add	x19, sp, #0x8
    7d38:	aa1303e0 	mov	x0, x19
    7d3c:	97ffec39 	bl	2e20 <fwp_fmt_u128>
    7d40:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7d44:	910aa339 	add	x25, x25, #0x2a8
    7d48:	910123f5 	add	x21, sp, #0x48
    7d4c:	aa1303e4 	mov	x4, x19
    7d50:	aa1503e0 	mov	x0, x21
    7d54:	d0000023 	adrp	x3, d000 <_IO_stdin_used+0x4c0>
    7d58:	f8616b25 	ldr	x5, [x25, x1]
    7d5c:	91002063 	add	x3, x3, #0x8
    7d60:	d2804002 	mov	x2, #0x200                 	// #512
    7d64:	52800041 	mov	w1, #0x2                   	// #2
    7d68:	97ffea6e 	bl	2720 <__sprintf_chk@plt>
    7d6c:	17ffffc5 	b	7c80 <fwp_write+0xeb0>
    7d70:	528005a4 	mov	w4, #0x2d                  	// #45
    7d74:	eb0003e2 	negs	x2, x0
    7d78:	da0103e3 	ngc	x3, x1
    7d7c:	910027e0 	add	x0, sp, #0x9
    7d80:	910023f3 	add	x19, sp, #0x8
    7d84:	390023e4 	strb	w4, [sp, #8]
    7d88:	97ffec26 	bl	2e20 <fwp_fmt_u128>
    7d8c:	17ffffed 	b	7d40 <fwp_write+0xf70>
    7d90:	f9013bf5 	str	x21, [sp, #624]
    7d94:	f9013ff6 	str	x22, [sp, #632]
    7d98:	f90143f7 	str	x23, [sp, #640]
    7d9c:	f90147f8 	str	x24, [sp, #648]
    7da0:	f9014bf9 	str	x25, [sp, #656]
    7da4:	f9014ffa 	str	x26, [sp, #664]
    7da8:	f90153fb 	str	x27, [sp, #672]
    7dac:	f90157fc 	str	x28, [sp, #680]
    7db0:	fd015be8 	str	d8, [sp, #688]
    7db4:	fd015fe9 	str	d9, [sp, #696]
    7db8:	97ffeab2 	bl	2880 <__stack_chk_fail@plt>
    7dbc:	d503201f 	nop

0000000000007dc0 <fwp_hof0.constprop.0>:
    7dc0:	d10543ff 	sub	sp, sp, #0x150
    7dc4:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    7dc8:	f947f442 	ldr	x2, [x2, #4072]
    7dcc:	a90e7bfd 	stp	x29, x30, [sp, #224]
    7dd0:	910383fd 	add	x29, sp, #0xe0
    7dd4:	f90023e0 	str	x0, [sp, #64]
    7dd8:	f9400040 	ldr	x0, [x2]
    7ddc:	f9006fe0 	str	x0, [sp, #216]
    7de0:	d2800000 	mov	x0, #0x0                   	// #0
    7de4:	f90027e1 	str	x1, [sp, #72]
    7de8:	b400a481 	cbz	x1, 9278 <fwp_hof0.constprop.0+0x14b8>
    7dec:	b00000c0 	adrp	x0, 20000 <__data_start>
    7df0:	91004000 	add	x0, x0, #0x10
    7df4:	f90017e0 	str	x0, [sp, #40]
    7df8:	910183e0 	add	x0, sp, #0x60
    7dfc:	f90013e0 	str	x0, [sp, #32]
    7e00:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    7e04:	fd00a3e8 	str	d8, [sp, #320]
    7e08:	910163e1 	add	x1, sp, #0x58
    7e0c:	fd441808 	ldr	d8, [x0, #2096]
    7e10:	f9000fe1 	str	x1, [sp, #24]
    7e14:	a90f53f3 	stp	x19, x20, [sp, #240]
    7e18:	d0000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    7e1c:	a9105bf5 	stp	x21, x22, [sp, #256]
    7e20:	a91163f7 	stp	x23, x24, [sp, #272]
    7e24:	a9126bf9 	stp	x25, x26, [sp, #288]
    7e28:	a91373fb 	stp	x27, x28, [sp, #304]
    7e2c:	91150282 	add	x2, x20, #0x540
    7e30:	f94023e0 	ldr	x0, [sp, #64]
    7e34:	f949ec43 	ldr	x3, [x2, #5080]
    7e38:	f949d841 	ldr	x1, [x2, #5040]
    7e3c:	d370bc63 	lsl	x3, x3, #16
    7e40:	cb010004 	sub	x4, x0, x1
    7e44:	eb03009f 	cmp	x4, x3
    7e48:	540003e2 	b.cs	7ec4 <fwp_hof0.constprop.0+0x104>  // b.hs, b.nlast
    7e4c:	d350fc80 	lsr	x0, x4, #16
    7e50:	f949fc46 	ldr	x6, [x2, #5112]
    7e54:	8b000800 	add	x0, x0, x0, lsl #2
    7e58:	d37df002 	lsl	x2, x0, #3
    7e5c:	8b0200c5 	add	x5, x6, x2
    7e60:	f94010a0 	ldr	x0, [x5, #32]
    7e64:	b4000300 	cbz	x0, 7ec4 <fwp_hof0.constprop.0+0x104>
    7e68:	386268c2 	ldrb	w2, [x6, x2]
    7e6c:	7100085f 	cmp	w2, #0x2
    7e70:	5400b980 	b.eq	95a0 <fwp_hof0.constprop.0+0x17e0>  // b.none
    7e74:	7100045f 	cmp	w2, #0x1
    7e78:	54000261 	b.ne	7ec4 <fwp_hof0.constprop.0+0x104>  // b.any
    7e7c:	92403c82 	and	x2, x4, #0xffff
    7e80:	294310a6 	ldp	w6, w4, [x5, #24]
    7e84:	9b067c42 	mul	x2, x2, x6
    7e88:	d360fc42 	lsr	x2, x2, #32
    7e8c:	eb04005f 	cmp	x2, x4
    7e90:	540001a2 	b.cs	7ec4 <fwp_hof0.constprop.0+0x104>  // b.hs, b.nlast
    7e94:	8b020000 	add	x0, x0, x2
    7e98:	39400002 	ldrb	w2, [x0]
    7e9c:	34000142 	cbz	w2, 7ec4 <fwp_hof0.constprop.0+0x104>
    7ea0:	7103f45f 	cmp	w2, #0xfd
    7ea4:	5400c728 	b.hi	9788 <fwp_hof0.constprop.0+0x19c8>  // b.pmore
    7ea8:	91150281 	add	x1, x20, #0x540
    7eac:	11000442 	add	w2, w2, #0x1
    7eb0:	39000002 	strb	w2, [x0]
    7eb4:	aa0103e0 	mov	x0, x1
    7eb8:	f949d821 	ldr	x1, [x1, #5040]
    7ebc:	f949ec03 	ldr	x3, [x0, #5080]
    7ec0:	d370bc63 	lsl	x3, x3, #16
    7ec4:	f94023f5 	ldr	x21, [sp, #64]
    7ec8:	d28018c0 	mov	x0, #0xc6                  	// #198
    7ecc:	f90007e0 	str	x0, [sp, #8]
    7ed0:	b00000c0 	adrp	x0, 20000 <__data_start>
    7ed4:	9100c002 	add	x2, x0, #0x30
    7ed8:	f94017e0 	ldr	x0, [sp, #40]
    7edc:	12800004 	mov	w4, #0xffffffff            	// #-1
    7ee0:	b9005be4 	str	w4, [sp, #88]
    7ee4:	cb010001 	sub	x1, x0, x1
    7ee8:	d0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    7eec:	91354000 	add	x0, x0, #0xd50
    7ef0:	f90037e0 	str	x0, [sp, #104]
    7ef4:	f9416040 	ldr	x0, [x2, #704]
    7ef8:	f90033e0 	str	x0, [sp, #96]
    7efc:	f9400fe0 	ldr	x0, [sp, #24]
    7f00:	f9003be0 	str	x0, [sp, #112]
    7f04:	f94013e0 	ldr	x0, [sp, #32]
    7f08:	f9016040 	str	x0, [x2, #704]
    7f0c:	eb03003f 	cmp	x1, x3
    7f10:	54000782 	b.cs	8000 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    7f14:	91150282 	add	x2, x20, #0x540
    7f18:	d350fc20 	lsr	x0, x1, #16
    7f1c:	8b000800 	add	x0, x0, x0, lsl #2
    7f20:	f949fc44 	ldr	x4, [x2, #5112]
    7f24:	d37df003 	lsl	x3, x0, #3
    7f28:	8b030082 	add	x2, x4, x3
    7f2c:	f9401053 	ldr	x19, [x2, #32]
    7f30:	b4000693 	cbz	x19, 8000 <fwp_hof0.constprop.0+0x240>
    7f34:	38636880 	ldrb	w0, [x4, x3]
    7f38:	7100081f 	cmp	w0, #0x2
    7f3c:	5400a680 	b.eq	940c <fwp_hof0.constprop.0+0x164c>  // b.none
    7f40:	7100041f 	cmp	w0, #0x1
    7f44:	540005e1 	b.ne	8000 <fwp_hof0.constprop.0+0x240>  // b.any
    7f48:	29430c44 	ldp	w4, w3, [x2, #24]
    7f4c:	92403c20 	and	x0, x1, #0xffff
    7f50:	9b047c00 	mul	x0, x0, x4
    7f54:	d360fc00 	lsr	x0, x0, #32
    7f58:	eb03001f 	cmp	x0, x3
    7f5c:	540002a2 	b.cs	7fb0 <fwp_hof0.constprop.0+0x1f0>  // b.hs, b.nlast
    7f60:	8b000260 	add	x0, x19, x0
    7f64:	39400003 	ldrb	w3, [x0]
    7f68:	34000243 	cbz	w3, 7fb0 <fwp_hof0.constprop.0+0x1f0>
    7f6c:	7103f47f 	cmp	w3, #0xfd
    7f70:	5400bcc8 	b.hi	9708 <fwp_hof0.constprop.0+0x1948>  // b.pmore
    7f74:	11000463 	add	w3, w3, #0x1
    7f78:	39000003 	strb	w3, [x0]
    7f7c:	91150280 	add	x0, x20, #0x540
    7f80:	f94017e3 	ldr	x3, [sp, #40]
    7f84:	f949d801 	ldr	x1, [x0, #5040]
    7f88:	f949ec02 	ldr	x2, [x0, #5080]
    7f8c:	cb010061 	sub	x1, x3, x1
    7f90:	eb02403f 	cmp	x1, x2, lsl #16
    7f94:	54000362 	b.cs	8000 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    7f98:	f949fc00 	ldr	x0, [x0, #5112]
    7f9c:	d350fc22 	lsr	x2, x1, #16
    7fa0:	8b020842 	add	x2, x2, x2, lsl #2
    7fa4:	8b020c02 	add	x2, x0, x2, lsl #3
    7fa8:	f9401053 	ldr	x19, [x2, #32]
    7fac:	b40002b3 	cbz	x19, 8000 <fwp_hof0.constprop.0+0x240>
    7fb0:	39400040 	ldrb	w0, [x2]
    7fb4:	7100081f 	cmp	w0, #0x2
    7fb8:	5400a320 	b.eq	941c <fwp_hof0.constprop.0+0x165c>  // b.none
    7fbc:	7100041f 	cmp	w0, #0x1
    7fc0:	54000201 	b.ne	8000 <fwp_hof0.constprop.0+0x240>  // b.any
    7fc4:	29430043 	ldp	w3, w0, [x2, #24]
    7fc8:	92403c21 	and	x1, x1, #0xffff
    7fcc:	9b037c21 	mul	x1, x1, x3
    7fd0:	d360fc21 	lsr	x1, x1, #32
    7fd4:	eb00003f 	cmp	x1, x0
    7fd8:	54000142 	b.cs	8000 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    7fdc:	8b010273 	add	x19, x19, x1
    7fe0:	39400261 	ldrb	w1, [x19]
    7fe4:	340000e1 	cbz	w1, 8000 <fwp_hof0.constprop.0+0x240>
    7fe8:	7100043f 	cmp	w1, #0x1
    7fec:	54007a60 	b.eq	8f38 <fwp_hof0.constprop.0+0x1178>  // b.none
    7ff0:	7103fc3f 	cmp	w1, #0xff
    7ff4:	5400b8e0 	b.eq	9710 <fwp_hof0.constprop.0+0x1950>  // b.none
    7ff8:	51000421 	sub	w1, w1, #0x1
    7ffc:	39000261 	strb	w1, [x19]
    8000:	b4007ad5 	cbz	x21, 8f58 <fwp_hof0.constprop.0+0x1198>
    8004:	aa1503e0 	mov	x0, x21
    8008:	d2800001 	mov	x1, #0x0                   	// #0
    800c:	d503201f 	nop
    8010:	f9400800 	ldr	x0, [x0, #16]
    8014:	91000421 	add	x1, x1, #0x1
    8018:	b5ffffc0 	cbnz	x0, 8010 <fwp_hof0.constprop.0+0x250>
    801c:	aa0103f7 	mov	x23, x1
    8020:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8024:	eb00003f 	cmp	x1, x0
    8028:	5400c008 	b.hi	9828 <fwp_hof0.constprop.0+0x1a68>  // b.pmore
    802c:	900000c0 	adrp	x0, 20000 <__data_start>
    8030:	9100c013 	add	x19, x0, #0x30
    8034:	b942f660 	ldr	w0, [x19, #756]
    8038:	340079c0 	cbz	w0, 8f70 <fwp_hof0.constprop.0+0x11b0>
    803c:	900000c0 	adrp	x0, 20000 <__data_start>
    8040:	9100c000 	add	x0, x0, #0x30
    8044:	f9402013 	ldr	x19, [x0, #64]
    8048:	f9404c16 	ldr	x22, [x0, #152]
    804c:	eb1302df 	cmp	x22, x19
    8050:	5400736a 	b.ge	8ebc <fwp_hof0.constprop.0+0x10fc>  // b.tcont
    8054:	900000c1 	adrp	x1, 20000 <__data_start>
    8058:	8b1606c0 	add	x0, x22, x22, lsl #1
    805c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8060:	f9401821 	ldr	x1, [x1, #48]
    8064:	8b000ac0 	add	x0, x22, x0, lsl #2
    8068:	8b000c20 	add	x0, x1, x0, lsl #3
    806c:	d503201f 	nop
    8070:	b9400401 	ldr	w1, [x0, #4]
    8074:	35000081 	cbnz	w1, 8084 <fwp_hof0.constprop.0+0x2c4>
    8078:	b9400001 	ldr	w1, [x0]
    807c:	6b02003f 	cmp	w1, w2
    8080:	540071e9 	b.ls	8ebc <fwp_hof0.constprop.0+0x10fc>  // b.plast
    8084:	910006d6 	add	x22, x22, #0x1
    8088:	9101a000 	add	x0, x0, #0x68
    808c:	eb1302df 	cmp	x22, x19
    8090:	54ffff01 	b.ne	8070 <fwp_hof0.constprop.0+0x2b0>  // b.any
    8094:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8098:	eb00027f 	cmp	x19, x0
    809c:	5400bc0c 	b.gt	981c <fwp_hof0.constprop.0+0x1a5c>
    80a0:	900000c0 	adrp	x0, 20000 <__data_start>
    80a4:	9100c000 	add	x0, x0, #0x30
    80a8:	900000c1 	adrp	x1, 20000 <__data_start>
    80ac:	f9404800 	ldr	x0, [x0, #144]
    80b0:	f940183c 	ldr	x28, [x1, #48]
    80b4:	eb13001f 	cmp	x0, x19
    80b8:	54000241 	b.ne	8100 <fwp_hof0.constprop.0+0x340>  // b.any
    80bc:	b400a553 	cbz	x19, 9564 <fwp_hof0.constprop.0+0x17a4>
    80c0:	d37ffa78 	lsl	x24, x19, #1
    80c4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    80c8:	eb00031f 	cmp	x24, x0
    80cc:	9a80d318 	csel	x24, x24, x0, le
    80d0:	8b180701 	add	x1, x24, x24, lsl #1
    80d4:	8b010b01 	add	x1, x24, x1, lsl #2
    80d8:	d37df021 	lsl	x1, x1, #3
    80dc:	aa1c03e0 	mov	x0, x28
    80e0:	97ffe9e4 	bl	2870 <realloc@plt>
    80e4:	aa0003fc 	mov	x28, x0
    80e8:	b40038c0 	cbz	x0, 8800 <fwp_hof0.constprop.0+0xa40>
    80ec:	900000c0 	adrp	x0, 20000 <__data_start>
    80f0:	9100c000 	add	x0, x0, #0x30
    80f4:	900000c1 	adrp	x1, 20000 <__data_start>
    80f8:	f900183c 	str	x28, [x1, #48]
    80fc:	f9004818 	str	x24, [x0, #144]
    8100:	8b130660 	add	x0, x19, x19, lsl #1
    8104:	8b1606d8 	add	x24, x22, x22, lsl #1
    8108:	4f000400 	movi	v0.4s, #0x0
    810c:	91000662 	add	x2, x19, #0x1
    8110:	8b000a60 	add	x0, x19, x0, lsl #2
    8114:	8b180ad8 	add	x24, x22, x24, lsl #2
    8118:	900000c1 	adrp	x1, 20000 <__data_start>
    811c:	9100c021 	add	x1, x1, #0x30
    8120:	8b000f80 	add	x0, x28, x0, lsl #3
    8124:	8b180f98 	add	x24, x28, x24, lsl #3
    8128:	f9002022 	str	x2, [x1, #64]
    812c:	ad000000 	stp	q0, q0, [x0]
    8130:	ad010000 	stp	q0, q0, [x0, #32]
    8134:	ad020000 	stp	q0, q0, [x0, #64]
    8138:	f900301f 	str	xzr, [x0, #96]
    813c:	90000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    8140:	f900331f 	str	xzr, [x24, #96]
    8144:	9135e000 	add	x0, x0, #0xd78
    8148:	97ffea32 	bl	2a10 <getenv@plt>
    814c:	b4006d00 	cbz	x0, 8eec <fwp_hof0.constprop.0+0x112c>
    8150:	39400001 	ldrb	w1, [x0]
    8154:	7100c03f 	cmp	w1, #0x30
    8158:	54006ca1 	b.ne	8eec <fwp_hof0.constprop.0+0x112c>  // b.any
    815c:	39400400 	ldrb	w0, [x0, #1]
    8160:	35006c60 	cbnz	w0, 8eec <fwp_hof0.constprop.0+0x112c>
    8164:	900000c0 	adrp	x0, 20000 <__data_start>
    8168:	9100c000 	add	x0, x0, #0x30
    816c:	2f000400 	mvni	v0.2s, #0x0
    8170:	b9400313 	ldr	w19, [x24]
    8174:	52800022 	mov	w2, #0x1                   	// #1
    8178:	910006c4 	add	x4, x22, #0x1
    817c:	f9416001 	ldr	x1, [x0, #704]
    8180:	0b020273 	add	w19, w19, w2
    8184:	29000b13 	stp	w19, w2, [x24]
    8188:	a900df17 	stp	x23, x23, [x24, #8]
    818c:	f9002b1f 	str	xzr, [x24, #80]
    8190:	f9004c04 	str	x4, [x0, #152]
    8194:	fd002f00 	str	d0, [x24, #88]
    8198:	b400b3c1 	cbz	x1, 9810 <fwp_hof0.constprop.0+0x1a50>
    819c:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    81a0:	91354003 	add	x3, x0, #0xd50
    81a4:	14000003 	b	81b0 <fwp_hof0.constprop.0+0x3f0>
    81a8:	f9400021 	ldr	x1, [x1]
    81ac:	b400b321 	cbz	x1, 9810 <fwp_hof0.constprop.0+0x1a50>
    81b0:	f9400422 	ldr	x2, [x1, #8]
    81b4:	eb03005f 	cmp	x2, x3
    81b8:	54ffff81 	b.ne	81a8 <fwp_hof0.constprop.0+0x3e8>  // b.any
    81bc:	f9400820 	ldr	x0, [x1, #16]
    81c0:	2a1603e2 	mov	w2, w22
    81c4:	b9400001 	ldr	w1, [x0]
    81c8:	f9002b00 	str	x0, [x24, #80]
    81cc:	b9005f01 	str	w1, [x24, #92]
    81d0:	37f80081 	tbnz	w1, #31, 81e0 <fwp_hof0.constprop.0+0x420>
    81d4:	52800d03 	mov	w3, #0x68                  	// #104
    81d8:	9b237021 	smaddl	x1, w1, w3, x28
    81dc:	b9005836 	str	w22, [x1, #88]
    81e0:	b9000002 	str	w2, [x0]
    81e4:	d3707e73 	ubfiz	x19, x19, #16, #32
    81e8:	aa040273 	orr	x19, x19, x4
    81ec:	aa1503e0 	mov	x0, x21
    81f0:	d2800002 	mov	x2, #0x0                   	// #0
    81f4:	b4007395 	cbz	x21, 9064 <fwp_hof0.constprop.0+0x12a4>
    81f8:	f9400800 	ldr	x0, [x0, #16]
    81fc:	91000442 	add	x2, x2, #0x1
    8200:	b5ffffc0 	cbnz	x0, 81f8 <fwp_hof0.constprop.0+0x438>
    8204:	aa1503e1 	mov	x1, x21
    8208:	f9400821 	ldr	x1, [x1, #16]
    820c:	91000400 	add	x0, x0, #0x1
    8210:	b5ffffc1 	cbnz	x1, 8208 <fwp_hof0.constprop.0+0x448>
    8214:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8218:	eb01001f 	cmp	x0, x1
    821c:	5400af48 	b.hi	9804 <fwp_hof0.constprop.0+0x1a44>  // b.pmore
    8220:	f100005f 	cmp	x2, #0x0
    8224:	5400720d 	b.le	9064 <fwp_hof0.constprop.0+0x12a4>
    8228:	eb00005f 	cmp	x2, x0
    822c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8230:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    8234:	eb0102df 	cmp	x22, x1
    8238:	5400ae68 	b.hi	9804 <fwp_hof0.constprop.0+0x1a44>  // b.pmore
    823c:	d37ffad7 	lsl	x23, x22, #1
    8240:	52800041 	mov	w1, #0x2                   	// #2
    8244:	910006e0 	add	x0, x23, #0x1
    8248:	d37df000 	lsl	x0, x0, #3
    824c:	97fff289 	bl	4c70 <fwp_heap_alloc>
    8250:	aa0003f8 	mov	x24, x0
    8254:	91150281 	add	x1, x20, #0x540
    8258:	aa0003fc 	mov	x28, x0
    825c:	aa0103e0 	mov	x0, x1
    8260:	f9000317 	str	x23, [x24]
    8264:	f949d821 	ldr	x1, [x1, #5040]
    8268:	f949ec00 	ldr	x0, [x0, #5080]
    826c:	cb010301 	sub	x1, x24, x1
    8270:	eb00403f 	cmp	x1, x0, lsl #16
    8274:	54008182 	b.cs	92a4 <fwp_hof0.constprop.0+0x14e4>  // b.hs, b.nlast
    8278:	91150282 	add	x2, x20, #0x540
    827c:	d350fc20 	lsr	x0, x1, #16
    8280:	8b000800 	add	x0, x0, x0, lsl #2
    8284:	f949fc43 	ldr	x3, [x2, #5112]
    8288:	d37df002 	lsl	x2, x0, #3
    828c:	8b020060 	add	x0, x3, x2
    8290:	f9401017 	ldr	x23, [x0, #32]
    8294:	b4000257 	cbz	x23, 82dc <fwp_hof0.constprop.0+0x51c>
    8298:	38626862 	ldrb	w2, [x3, x2]
    829c:	7100085f 	cmp	w2, #0x2
    82a0:	54008a60 	b.eq	93ec <fwp_hof0.constprop.0+0x162c>  // b.none
    82a4:	7100045f 	cmp	w2, #0x1
    82a8:	540001a1 	b.ne	82dc <fwp_hof0.constprop.0+0x51c>  // b.any
    82ac:	29430002 	ldp	w2, w0, [x0, #24]
    82b0:	92403c21 	and	x1, x1, #0xffff
    82b4:	9b027c21 	mul	x1, x1, x2
    82b8:	d360fc21 	lsr	x1, x1, #32
    82bc:	eb00003f 	cmp	x1, x0
    82c0:	540000e2 	b.cs	82dc <fwp_hof0.constprop.0+0x51c>  // b.hs, b.nlast
    82c4:	8b0102f7 	add	x23, x23, x1
    82c8:	394002e0 	ldrb	w0, [x23]
    82cc:	7103fc1f 	cmp	w0, #0xff
    82d0:	54008980 	b.eq	9400 <fwp_hof0.constprop.0+0x1640>  // b.none
    82d4:	52800020 	mov	w0, #0x1                   	// #1
    82d8:	390002e0 	strb	w0, [x23]
    82dc:	b4000236 	cbz	x22, 8320 <fwp_hof0.constprop.0+0x560>
    82e0:	d3607e64 	lsl	x4, x19, #32
    82e4:	aa1503e1 	mov	x1, x21
    82e8:	f94006a5 	ldr	x5, [x21, #8]
    82ec:	aa0403e3 	mov	x3, x4
    82f0:	91002302 	add	x2, x24, #0x8
    82f4:	d2800000 	mov	x0, #0x0                   	// #0
    82f8:	14000005 	b	830c <fwp_hof0.constprop.0+0x54c>
    82fc:	f9400425 	ldr	x5, [x1, #8]
    8300:	ab040003 	adds	x3, x0, x4
    8304:	91004042 	add	x2, x2, #0x10
    8308:	5400aba6 	b.vs	987c <fwp_hof0.constprop.0+0x1abc>
    830c:	a9000c45 	stp	x5, x3, [x2]
    8310:	91000400 	add	x0, x0, #0x1
    8314:	f9400821 	ldr	x1, [x1, #16]
    8318:	eb16001f 	cmp	x0, x22
    831c:	54ffff03 	b.cc	82fc <fwp_hof0.constprop.0+0x53c>  // b.lo, b.ul, b.last
    8320:	f9400300 	ldr	x0, [x24]
    8324:	f100041f 	cmp	x0, #0x1
    8328:	54007c09 	b.ls	92a8 <fwp_hof0.constprop.0+0x14e8>  // b.plast
    832c:	d341fc00 	lsr	x0, x0, #1
    8330:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8334:	d1000417 	sub	x23, x0, #0x1
    8338:	eb0102ff 	cmp	x23, x1
    833c:	5400a648 	b.hi	9804 <fwp_hof0.constprop.0+0x1a44>  // b.pmore
    8340:	b4007b57 	cbz	x23, 92a8 <fwp_hof0.constprop.0+0x14e8>
    8344:	d1002301 	sub	x1, x24, #0x8
    8348:	91002319 	add	x25, x24, #0x8
    834c:	8b001036 	add	x22, x1, x0, lsl #4
    8350:	f9400720 	ldr	x0, [x25, #8]
    8354:	f9400f21 	ldr	x1, [x25, #24]
    8358:	fd400320 	ldr	d0, [x25]
    835c:	fd400b21 	ldr	d1, [x25, #16]
    8360:	97fff384 	bl	5170 <w120>
    8364:	a9000720 	stp	x0, x1, [x25]
    8368:	91004339 	add	x25, x25, #0x10
    836c:	eb16033f 	cmp	x25, x22
    8370:	54ffff01 	b.ne	8350 <fwp_hof0.constprop.0+0x590>  // b.any
    8374:	aa1803f6 	mov	x22, x24
    8378:	d37ffaf7 	lsl	x23, x23, #1
    837c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    8380:	d2800019 	mov	x25, #0x0                   	// #0
    8384:	f80106d7 	str	x23, [x22], #16
    8388:	f8797ac2 	ldr	x2, [x22, x25, lsl #3]
    838c:	aa1a03e0 	mov	x0, x26
    8390:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    8394:	91000b39 	add	x25, x25, #0x2
    8398:	aa0303e1 	mov	x1, x3
    839c:	97fff2c2 	bl	4ea4 <fwp_p_ad_push>
    83a0:	aa0003fa 	mov	x26, x0
    83a4:	eb17033f 	cmp	x25, x23
    83a8:	54ffff03 	b.cc	8388 <fwp_hof0.constprop.0+0x5c8>  // b.lo, b.ul, b.last
    83ac:	91150296 	add	x22, x20, #0x540
    83b0:	f949dac1 	ldr	x1, [x22, #5040]
    83b4:	f949eec0 	ldr	x0, [x22, #5080]
    83b8:	cb010301 	sub	x1, x24, x1
    83bc:	eb00403f 	cmp	x1, x0, lsl #16
    83c0:	54000382 	b.cs	8430 <fwp_hof0.constprop.0+0x670>  // b.hs, b.nlast
    83c4:	d350fc20 	lsr	x0, x1, #16
    83c8:	f949fec5 	ldr	x5, [x22, #5112]
    83cc:	8b000800 	add	x0, x0, x0, lsl #2
    83d0:	d37df000 	lsl	x0, x0, #3
    83d4:	8b0000a2 	add	x2, x5, x0
    83d8:	f9401057 	ldr	x23, [x2, #32]
    83dc:	b40002b7 	cbz	x23, 8430 <fwp_hof0.constprop.0+0x670>
    83e0:	386068a0 	ldrb	w0, [x5, x0]
    83e4:	7100081f 	cmp	w0, #0x2
    83e8:	54007660 	b.eq	92b4 <fwp_hof0.constprop.0+0x14f4>  // b.none
    83ec:	7100041f 	cmp	w0, #0x1
    83f0:	54000201 	b.ne	8430 <fwp_hof0.constprop.0+0x670>  // b.any
    83f4:	29430044 	ldp	w4, w0, [x2, #24]
    83f8:	92403c21 	and	x1, x1, #0xffff
    83fc:	9b047c21 	mul	x1, x1, x4
    8400:	d360fc21 	lsr	x1, x1, #32
    8404:	eb00003f 	cmp	x1, x0
    8408:	54000142 	b.cs	8430 <fwp_hof0.constprop.0+0x670>  // b.hs, b.nlast
    840c:	8b0102f7 	add	x23, x23, x1
    8410:	394002e0 	ldrb	w0, [x23]
    8414:	340000e0 	cbz	w0, 8430 <fwp_hof0.constprop.0+0x670>
    8418:	7100041f 	cmp	w0, #0x1
    841c:	540020a0 	b.eq	8830 <fwp_hof0.constprop.0+0xa70>  // b.none
    8420:	7103fc1f 	cmp	w0, #0xff
    8424:	54008c40 	b.eq	95ac <fwp_hof0.constprop.0+0x17ec>  // b.none
    8428:	51000400 	sub	w0, w0, #0x1
    842c:	390002e0 	strb	w0, [x23]
    8430:	93407e73 	sxtw	x19, w19
    8434:	aa1303e0 	mov	x0, x19
    8438:	97ffed1e 	bl	38b0 <fwp_tape_of>
    843c:	f9403001 	ldr	x1, [x0, #96]
    8440:	aa0003e8 	mov	x8, x0
    8444:	b5009f81 	cbnz	x1, 9834 <fwp_hof0.constprop.0+0x1a74>
    8448:	97ffead2 	bl	2f90 <fwp_tape_unlink_scope>
    844c:	b9400002 	ldr	w2, [x0]
    8450:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    8454:	a9408017 	ldp	x23, x0, [x0, #8]
    8458:	b900051f 	str	wzr, [x8, #4]
    845c:	a941e10a 	ldp	x10, x24, [x8, #24]
    8460:	a9429119 	ldp	x25, x4, [x8, #40]
    8464:	a943f11b 	ldp	x27, x28, [x8, #56]
    8468:	f9402516 	ldr	x22, [x8, #72]
    846c:	6b01005f 	cmp	w2, w1
    8470:	54000128 	b.hi	8494 <fwp_hof0.constprop.0+0x6d4>  // b.pmore
    8474:	900000c1 	adrp	x1, 20000 <__data_start>
    8478:	9100c022 	add	x2, x1, #0x30
    847c:	92403e61 	and	x1, x19, #0xffff
    8480:	d1000421 	sub	x1, x1, #0x1
    8484:	f9404c49 	ldr	x9, [x2, #152]
    8488:	eb09003f 	cmp	x1, x9
    848c:	5400004a 	b.ge	8494 <fwp_hof0.constprop.0+0x6d4>  // b.tcont
    8490:	f9004c41 	str	x1, [x2, #152]
    8494:	4f000400 	movi	v0.4s, #0x0
    8498:	900000c1 	adrp	x1, 20000 <__data_start>
    849c:	9100c029 	add	x9, x1, #0x30
    84a0:	f9000d1f 	str	xzr, [x8, #24]
    84a4:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    84a8:	910243e3 	add	x3, sp, #0x90
    84ac:	9101e3e1 	add	x1, sp, #0x78
    84b0:	f941612b 	ldr	x11, [x9, #704]
    84b4:	3c808100 	stur	q0, [x8, #8]
    84b8:	90ffffe2 	adrp	x2, 4000 <fwp_heap_init+0x17c>
    84bc:	ad010100 	stp	q0, q0, [x8, #32]
    84c0:	91040042 	add	x2, x2, #0x100
    84c4:	f9000be3 	str	x3, [sp, #16]
    84c8:	a9078beb 	stp	x11, x2, [sp, #120]
    84cc:	a908e3e3 	stp	x3, x24, [sp, #136]
    84d0:	a90993f9 	stp	x25, x4, [sp, #152]
    84d4:	a90af3fb 	stp	x27, x28, [sp, #168]
    84d8:	a90bdbea 	stp	x10, x22, [sp, #184]
    84dc:	f9016121 	str	x1, [x9, #704]
    84e0:	b7f87a5a 	tbnz	x26, #63, 9428 <fwp_hof0.constprop.0+0x1668>
    84e4:	eb9a827f 	cmp	x19, x26, asr #32
    84e8:	54009441 	b.ne	9770 <fwp_hof0.constprop.0+0x19b0>  // b.any
    84ec:	92407f53 	and	x19, x26, #0xffffffff
    84f0:	eb3a401f 	cmp	x0, w26, uxtw
    84f4:	5400944d 	b.le	977c <fwp_hof0.constprop.0+0x19bc>
    84f8:	eb1302ff 	cmp	x23, x19
    84fc:	9a93c6f3 	csinc	x19, x23, x19, gt
    8500:	eb1302df 	cmp	x22, x19
    8504:	5400168a 	b.ge	87d4 <fwp_hof0.constprop.0+0xa14>  // b.tcont
    8508:	f10002df 	cmp	x22, #0x0
    850c:	9a9312d6 	csel	x22, x22, x19, ne	// ne = any
    8510:	14000005 	b	8524 <fwp_hof0.constprop.0+0x764>
    8514:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8518:	eb0002df 	cmp	x22, x0
    851c:	d37ffad6 	lsl	x22, x22, #1
    8520:	9a93d2d6 	csel	x22, x22, x19, le
    8524:	eb1302df 	cmp	x22, x19
    8528:	54ffff6b 	b.lt	8514 <fwp_hof0.constprop.0+0x754>  // b.tstop
    852c:	f9001be4 	str	x4, [sp, #48]
    8530:	b4007fbc 	cbz	x28, 9524 <fwp_hof0.constprop.0+0x1764>
    8534:	aa1c03e0 	mov	x0, x28
    8538:	d37df2c1 	lsl	x1, x22, #3
    853c:	97ffe8cd 	bl	2870 <realloc@plt>
    8540:	aa0003fc 	mov	x28, x0
    8544:	f9401be4 	ldr	x4, [sp, #48]
    8548:	b400989c 	cbz	x28, 9858 <fwp_hof0.constprop.0+0x1a98>
    854c:	f9005bfc 	str	x28, [sp, #176]
    8550:	f90063f6 	str	x22, [sp, #192]
    8554:	b5001333 	cbnz	x19, 87b8 <fwp_hof0.constprop.0+0x9f8>
    8558:	b7f800da 	tbnz	x26, #63, 8570 <fwp_hof0.constprop.0+0x7b0>
    855c:	92407f40 	and	x0, x26, #0xffffffff
    8560:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8564:	fc607b80 	ldr	d0, [x28, x0, lsl #3]
    8568:	1e612800 	fadd	d0, d0, d1
    856c:	fc207b80 	str	d0, [x28, x0, lsl #3]
    8570:	d1000673 	sub	x19, x19, #0x1
    8574:	d10006e3 	sub	x3, x23, #0x1
    8578:	eb1302ff 	cmp	x23, x19
    857c:	540003ac 	b.gt	85f0 <fwp_hof0.constprop.0+0x830>
    8580:	fc737b80 	ldr	d0, [x28, x19, lsl #3]
    8584:	1e602008 	fcmp	d0, #0.0
    8588:	540002e0 	b.eq	85e4 <fwp_hof0.constprop.0+0x824>  // b.none
    858c:	cb170be0 	neg	x0, x23, lsl #2
    8590:	cb1703e2 	neg	x2, x23
    8594:	8b000301 	add	x1, x24, x0
    8598:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    859c:	37f80101 	tbnz	w1, #31, 85bc <fwp_hof0.constprop.0+0x7fc>
    85a0:	8b020c88 	add	x8, x4, x2, lsl #3
    85a4:	93407c21 	sxtw	x1, w1
    85a8:	fc737902 	ldr	d2, [x8, x19, lsl #3]
    85ac:	fc617b81 	ldr	d1, [x28, x1, lsl #3]
    85b0:	1e620802 	fmul	d2, d0, d2
    85b4:	1e622821 	fadd	d1, d1, d2
    85b8:	fc217b81 	str	d1, [x28, x1, lsl #3]
    85bc:	8b000320 	add	x0, x25, x0
    85c0:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    85c4:	37f80100 	tbnz	w0, #31, 85e4 <fwp_hof0.constprop.0+0x824>
    85c8:	8b020f62 	add	x2, x27, x2, lsl #3
    85cc:	93407c00 	sxtw	x0, w0
    85d0:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    85d4:	fc607b81 	ldr	d1, [x28, x0, lsl #3]
    85d8:	1e620800 	fmul	d0, d0, d2
    85dc:	1e602820 	fadd	d0, d1, d0
    85e0:	fc207b80 	str	d0, [x28, x0, lsl #3]
    85e4:	d1000673 	sub	x19, x19, #0x1
    85e8:	eb13007f 	cmp	x3, x19
    85ec:	54fffca1 	b.ne	8580 <fwp_hof0.constprop.0+0x7c0>  // b.any
    85f0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    85f4:	eb0002ff 	cmp	x23, x0
    85f8:	540092a8 	b.hi	984c <fwp_hof0.constprop.0+0x1a8c>  // b.pmore
    85fc:	910006e0 	add	x0, x23, #0x1
    8600:	52800041 	mov	w1, #0x2                   	// #2
    8604:	d37df000 	lsl	x0, x0, #3
    8608:	97fff19a 	bl	4c70 <fwp_heap_alloc>
    860c:	aa0003e2 	mov	x2, x0
    8610:	aa0003f3 	mov	x19, x0
    8614:	d2800001 	mov	x1, #0x0                   	// #0
    8618:	f8008457 	str	x23, [x2], #8
    861c:	b40000d7 	cbz	x23, 8634 <fwp_hof0.constprop.0+0x874>
    8620:	f8617b80 	ldr	x0, [x28, x1, lsl #3]
    8624:	f8217840 	str	x0, [x2, x1, lsl #3]
    8628:	91000421 	add	x1, x1, #0x1
    862c:	eb0102ff 	cmp	x23, x1
    8630:	54ffff81 	b.ne	8620 <fwp_hof0.constprop.0+0x860>  // b.any
    8634:	900000c0 	adrp	x0, 20000 <__data_start>
    8638:	9100c001 	add	x1, x0, #0x30
    863c:	f9400be0 	ldr	x0, [sp, #16]
    8640:	f9403ff7 	ldr	x23, [sp, #120]
    8644:	f9016037 	str	x23, [x1, #704]
    8648:	97ffeeae 	bl	4100 <fwp_tape_buffers_release>
    864c:	91150282 	add	x2, x20, #0x540
    8650:	f949d841 	ldr	x1, [x2, #5040]
    8654:	f949ec40 	ldr	x0, [x2, #5080]
    8658:	cb010261 	sub	x1, x19, x1
    865c:	eb00403f 	cmp	x1, x0, lsl #16
    8660:	54000322 	b.cs	86c4 <fwp_hof0.constprop.0+0x904>  // b.hs, b.nlast
    8664:	d350fc20 	lsr	x0, x1, #16
    8668:	f949fc43 	ldr	x3, [x2, #5112]
    866c:	8b000800 	add	x0, x0, x0, lsl #2
    8670:	d37df002 	lsl	x2, x0, #3
    8674:	8b020060 	add	x0, x3, x2
    8678:	f9401016 	ldr	x22, [x0, #32]
    867c:	b4000256 	cbz	x22, 86c4 <fwp_hof0.constprop.0+0x904>
    8680:	38626862 	ldrb	w2, [x3, x2]
    8684:	7100085f 	cmp	w2, #0x2
    8688:	54006d40 	b.eq	9430 <fwp_hof0.constprop.0+0x1670>  // b.none
    868c:	7100045f 	cmp	w2, #0x1
    8690:	540001a1 	b.ne	86c4 <fwp_hof0.constprop.0+0x904>  // b.any
    8694:	29430002 	ldp	w2, w0, [x0, #24]
    8698:	92403c21 	and	x1, x1, #0xffff
    869c:	9b027c21 	mul	x1, x1, x2
    86a0:	d360fc21 	lsr	x1, x1, #32
    86a4:	eb00003f 	cmp	x1, x0
    86a8:	540000e2 	b.cs	86c4 <fwp_hof0.constprop.0+0x904>  // b.hs, b.nlast
    86ac:	8b0102d6 	add	x22, x22, x1
    86b0:	394002c0 	ldrb	w0, [x22]
    86b4:	7103fc1f 	cmp	w0, #0xff
    86b8:	54006c60 	b.eq	9444 <fwp_hof0.constprop.0+0x1684>  // b.none
    86bc:	52800020 	mov	w0, #0x1                   	// #1
    86c0:	390002c0 	strb	w0, [x22]
    86c4:	f94013e0 	ldr	x0, [sp, #32]
    86c8:	eb0002ff 	cmp	x23, x0
    86cc:	54008da1 	b.ne	9880 <fwp_hof0.constprop.0+0x1ac0>  // b.any
    86d0:	900000c0 	adrp	x0, 20000 <__data_start>
    86d4:	9100c001 	add	x1, x0, #0x30
    86d8:	f9400fe0 	ldr	x0, [sp, #24]
    86dc:	f94033e2 	ldr	x2, [sp, #96]
    86e0:	f9016022 	str	x2, [x1, #704]
    86e4:	97fff59b 	bl	5d50 <fwp_tape_scope_release>
    86e8:	f9400260 	ldr	x0, [x19]
    86ec:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    86f0:	b7f84540 	tbnz	x0, #63, 8f98 <fwp_hof0.constprop.0+0x11d8>
    86f4:	91150282 	add	x2, x20, #0x540
    86f8:	f949d840 	ldr	x0, [x2, #5040]
    86fc:	f949ec41 	ldr	x1, [x2, #5080]
    8700:	cb000260 	sub	x0, x19, x0
    8704:	eb01401f 	cmp	x0, x1, lsl #16
    8708:	54004482 	b.cs	8f98 <fwp_hof0.constprop.0+0x11d8>  // b.hs, b.nlast
    870c:	d350fc01 	lsr	x1, x0, #16
    8710:	f949fc44 	ldr	x4, [x2, #5112]
    8714:	8b010821 	add	x1, x1, x1, lsl #2
    8718:	d37df021 	lsl	x1, x1, #3
    871c:	8b010083 	add	x3, x4, x1
    8720:	f9401062 	ldr	x2, [x3, #32]
    8724:	b40043a2 	cbz	x2, 8f98 <fwp_hof0.constprop.0+0x11d8>
    8728:	38616881 	ldrb	w1, [x4, x1]
    872c:	7100083f 	cmp	w1, #0x2
    8730:	540042e0 	b.eq	8f8c <fwp_hof0.constprop.0+0x11cc>  // b.none
    8734:	7100043f 	cmp	w1, #0x1
    8738:	54004301 	b.ne	8f98 <fwp_hof0.constprop.0+0x11d8>  // b.any
    873c:	29430464 	ldp	w4, w1, [x3, #24]
    8740:	92403c00 	and	x0, x0, #0xffff
    8744:	9b047c00 	mul	x0, x0, x4
    8748:	d360fc00 	lsr	x0, x0, #32
    874c:	eb01001f 	cmp	x0, x1
    8750:	54004242 	b.cs	8f98 <fwp_hof0.constprop.0+0x11d8>  // b.hs, b.nlast
    8754:	8b000042 	add	x2, x2, x0
    8758:	39400040 	ldrb	w0, [x2]
    875c:	7100041f 	cmp	w0, #0x1
    8760:	540041c1 	b.ne	8f98 <fwp_hof0.constprop.0+0x11d8>  // b.any
    8764:	aa1303fc 	mov	x28, x19
    8768:	aa1303f6 	mov	x22, x19
    876c:	d2800000 	mov	x0, #0x0                   	// #0
    8770:	910022c3 	add	x3, x22, #0x8
    8774:	91002265 	add	x5, x19, #0x8
    8778:	d2800001 	mov	x1, #0x0                   	// #0
    877c:	b5000157 	cbnz	x23, 87a4 <fwp_hof0.constprop.0+0x9e4>
    8780:	1400004d 	b	88b4 <fwp_hof0.constprop.0+0xaf4>
    8784:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8788:	f9400382 	ldr	x2, [x28]
    878c:	1e600900 	fmul	d0, d8, d0
    8790:	b7f88342 	tbnz	x2, #63, 97f8 <fwp_hof0.constprop.0+0x1a38>
    8794:	91000421 	add	x1, x1, #0x1
    8798:	fc008460 	str	d0, [x3], #8
    879c:	eb0102ff 	cmp	x23, x1
    87a0:	540008a0 	b.eq	88b4 <fwp_hof0.constprop.0+0xaf4>  // b.none
    87a4:	f9400264 	ldr	x4, [x19]
    87a8:	aa0503e2 	mov	x2, x5
    87ac:	b6fffec4 	tbz	x4, #63, 8784 <fwp_hof0.constprop.0+0x9c4>
    87b0:	f9400a62 	ldr	x2, [x19, #16]
    87b4:	17fffff4 	b	8784 <fwp_hof0.constprop.0+0x9c4>
    87b8:	d37df262 	lsl	x2, x19, #3
    87bc:	aa1c03e0 	mov	x0, x28
    87c0:	52800001 	mov	w1, #0x0                   	// #0
    87c4:	f9001be4 	str	x4, [sp, #48]
    87c8:	97ffe822 	bl	2850 <memset@plt>
    87cc:	f9401be4 	ldr	x4, [sp, #48]
    87d0:	17ffff62 	b	8558 <fwp_hof0.constprop.0+0x798>
    87d4:	f100039f 	cmp	x28, #0x0
    87d8:	1a9f17e0 	cset	w0, eq	// eq = none
    87dc:	f100027f 	cmp	x19, #0x0
    87e0:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    87e4:	54ffeb80 	b.eq	8554 <fwp_hof0.constprop.0+0x794>  // b.none
    87e8:	900000c0 	adrp	x0, 20000 <__data_start>
    87ec:	9100c019 	add	x25, x0, #0x30
    87f0:	f9400be0 	ldr	x0, [sp, #16]
    87f4:	f9403fe1 	ldr	x1, [sp, #120]
    87f8:	f9016321 	str	x1, [x25, #704]
    87fc:	97ffee41 	bl	4100 <fwp_tape_buffers_release>
    8800:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    8804:	f947e863 	ldr	x3, [x3, #4048]
    8808:	d2800262 	mov	x2, #0x13                  	// #19
    880c:	d2800021 	mov	x1, #0x1                   	// #1
    8810:	90000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    8814:	912d2000 	add	x0, x0, #0xb48
    8818:	f9400063 	ldr	x3, [x3]
    881c:	97ffe859 	bl	2980 <fwrite@plt>
    8820:	d2800000 	mov	x0, #0x0                   	// #0
    8824:	97ffe863 	bl	29b0 <fflush@plt>
    8828:	52800cc0 	mov	w0, #0x66                  	// #102
    882c:	97ffe871 	bl	29f0 <_Exit@plt>
    8830:	f9400386 	ldr	x6, [x28]
    8834:	aa1c03e0 	mov	x0, x28
    8838:	f949eec4 	ldr	x4, [x22, #5080]
    883c:	f949dac1 	ldr	x1, [x22, #5040]
    8840:	d370bc84 	lsl	x4, x4, #16
    8844:	cb010382 	sub	x2, x28, x1
    8848:	b7f85426 	tbnz	x6, #63, 92cc <fwp_hof0.constprop.0+0x150c>
    884c:	eb02009f 	cmp	x4, x2
    8850:	54ffdf09 	b.ls	8430 <fwp_hof0.constprop.0+0x670>  // b.plast
    8854:	d350fc40 	lsr	x0, x2, #16
    8858:	8b000800 	add	x0, x0, x0, lsl #2
    885c:	d37df000 	lsl	x0, x0, #3
    8860:	8b0000a4 	add	x4, x5, x0
    8864:	f9401081 	ldr	x1, [x4, #32]
    8868:	b4ffde41 	cbz	x1, 8430 <fwp_hof0.constprop.0+0x670>
    886c:	386068a0 	ldrb	w0, [x5, x0]
    8870:	7100081f 	cmp	w0, #0x2
    8874:	54005ee0 	b.eq	9450 <fwp_hof0.constprop.0+0x1690>  // b.none
    8878:	7100041f 	cmp	w0, #0x1
    887c:	54ffdda1 	b.ne	8430 <fwp_hof0.constprop.0+0x670>  // b.any
    8880:	92403c40 	and	x0, x2, #0xffff
    8884:	29430885 	ldp	w5, w2, [x4, #24]
    8888:	9b057c00 	mul	x0, x0, x5
    888c:	d360fc00 	lsr	x0, x0, #32
    8890:	eb02001f 	cmp	x0, x2
    8894:	54ffdce2 	b.cs	8430 <fwp_hof0.constprop.0+0x670>  // b.hs, b.nlast
    8898:	8b000021 	add	x1, x1, x0
    889c:	39400020 	ldrb	w0, [x1]
    88a0:	7100041f 	cmp	w0, #0x1
    88a4:	54ffdc61 	b.ne	8430 <fwp_hof0.constprop.0+0x670>  // b.any
    88a8:	aa1c03e0 	mov	x0, x28
    88ac:	97ffefd1 	bl	47f0 <fwp_mem_free>
    88b0:	17fffee0 	b	8430 <fwp_hof0.constprop.0+0x670>
    88b4:	97fff713 	bl	6500 <fwp_drop10>
    88b8:	aa1503e1 	mov	x1, x21
    88bc:	d2800002 	mov	x2, #0x0                   	// #0
    88c0:	b40063f5 	cbz	x21, 953c <fwp_hof0.constprop.0+0x177c>
    88c4:	d503201f 	nop
    88c8:	f9400821 	ldr	x1, [x1, #16]
    88cc:	91000442 	add	x2, x2, #0x1
    88d0:	b5ffffc1 	cbnz	x1, 88c8 <fwp_hof0.constprop.0+0xb08>
    88d4:	f9400384 	ldr	x4, [x28]
    88d8:	9240f885 	and	x5, x4, #0x7fffffffffffffff
    88dc:	b7f82b64 	tbnz	x4, #63, 8e48 <fwp_hof0.constprop.0+0x1088>
    88e0:	91150281 	add	x1, x20, #0x540
    88e4:	f949d820 	ldr	x0, [x1, #5040]
    88e8:	f949ec21 	ldr	x1, [x1, #5080]
    88ec:	cb0002c0 	sub	x0, x22, x0
    88f0:	eb01401f 	cmp	x0, x1, lsl #16
    88f4:	54002aa2 	b.cs	8e48 <fwp_hof0.constprop.0+0x1088>  // b.hs, b.nlast
    88f8:	91150283 	add	x3, x20, #0x540
    88fc:	d350fc01 	lsr	x1, x0, #16
    8900:	8b010821 	add	x1, x1, x1, lsl #2
    8904:	f949fc67 	ldr	x7, [x3, #5112]
    8908:	d37df021 	lsl	x1, x1, #3
    890c:	8b0100e6 	add	x6, x7, x1
    8910:	f94010c3 	ldr	x3, [x6, #32]
    8914:	b4002983 	cbz	x3, 8e44 <fwp_hof0.constprop.0+0x1084>
    8918:	386168e1 	ldrb	w1, [x7, x1]
    891c:	7100083f 	cmp	w1, #0x2
    8920:	540028e0 	b.eq	8e3c <fwp_hof0.constprop.0+0x107c>  // b.none
    8924:	7100043f 	cmp	w1, #0x1
    8928:	540028e1 	b.ne	8e44 <fwp_hof0.constprop.0+0x1084>  // b.any
    892c:	294304c7 	ldp	w7, w1, [x6, #24]
    8930:	92403c00 	and	x0, x0, #0xffff
    8934:	9b077c00 	mul	x0, x0, x7
    8938:	d360fc00 	lsr	x0, x0, #32
    893c:	eb01001f 	cmp	x0, x1
    8940:	54002822 	b.cs	8e44 <fwp_hof0.constprop.0+0x1084>  // b.hs, b.nlast
    8944:	8b000063 	add	x3, x3, x0
    8948:	39400060 	ldrb	w0, [x3]
    894c:	7100041f 	cmp	w0, #0x1
    8950:	540027a1 	b.ne	8e44 <fwp_hof0.constprop.0+0x1084>  // b.any
    8954:	b90033e0 	str	w0, [sp, #48]
    8958:	eb05005f 	cmp	x2, x5
    895c:	9a859045 	csel	x5, x2, x5, ls	// ls = plast
    8960:	91002398 	add	x24, x28, #0x8
    8964:	b4006cc5 	cbz	x5, 96fc <fwp_hof0.constprop.0+0x193c>
    8968:	d37df0a7 	lsl	x7, x5, #3
    896c:	aa1503e2 	mov	x2, x21
    8970:	910022c0 	add	x0, x22, #0x8
    8974:	d2800001 	mov	x1, #0x0                   	// #0
    8978:	1400000a 	b	89a0 <fwp_hof0.constprop.0+0xbe0>
    897c:	fc6168c1 	ldr	d1, [x6, x1]
    8980:	fd400440 	ldr	d0, [x2, #8]
    8984:	1e613800 	fsub	d0, d0, d1
    8988:	fc216b00 	str	d0, [x24, x1]
    898c:	91002021 	add	x1, x1, #0x8
    8990:	f9400842 	ldr	x2, [x2, #16]
    8994:	eb07003f 	cmp	x1, x7
    8998:	540001a0 	b.eq	89cc <fwp_hof0.constprop.0+0xc0c>  // b.none
    899c:	f9400384 	ldr	x4, [x28]
    89a0:	aa0003e6 	mov	x6, x0
    89a4:	b6fffec4 	tbz	x4, #63, 897c <fwp_hof0.constprop.0+0xbbc>
    89a8:	f9400ac6 	ldr	x6, [x22, #16]
    89ac:	fd400440 	ldr	d0, [x2, #8]
    89b0:	fc6168c1 	ldr	d1, [x6, x1]
    89b4:	1e613800 	fsub	d0, d0, d1
    89b8:	fc216b00 	str	d0, [x24, x1]
    89bc:	91002021 	add	x1, x1, #0x8
    89c0:	f9400842 	ldr	x2, [x2, #16]
    89c4:	eb07003f 	cmp	x1, x7
    89c8:	54fffea1 	b.ne	899c <fwp_hof0.constprop.0+0xbdc>  // b.any
    89cc:	b4006cf5 	cbz	x21, 9768 <fwp_hof0.constprop.0+0x19a8>
    89d0:	91150280 	add	x0, x20, #0x540
    89d4:	aa1503e7 	mov	x7, x21
    89d8:	d2800017 	mov	x23, #0x0                   	// #0
    89dc:	f949ec09 	ldr	x9, [x0, #5080]
    89e0:	f949d80a 	ldr	x10, [x0, #5040]
    89e4:	f949fc08 	ldr	x8, [x0, #5112]
    89e8:	d370bd29 	lsl	x9, x9, #16
    89ec:	14000006 	b	8a04 <fwp_hof0.constprop.0+0xc44>
    89f0:	f94008e7 	ldr	x7, [x7, #16]
    89f4:	910006f7 	add	x23, x23, #0x1
    89f8:	f10000ff 	cmp	x7, #0x0
    89fc:	fa5710a0 	ccmp	x5, x23, #0x0, ne	// ne = any
    8a00:	54003209 	b.ls	9040 <fwp_hof0.constprop.0+0x1280>  // b.plast
    8a04:	cb0a00e0 	sub	x0, x7, x10
    8a08:	eb09001f 	cmp	x0, x9
    8a0c:	540002c2 	b.cs	8a64 <fwp_hof0.constprop.0+0xca4>  // b.hs, b.nlast
    8a10:	d350fc01 	lsr	x1, x0, #16
    8a14:	8b010821 	add	x1, x1, x1, lsl #2
    8a18:	d37df021 	lsl	x1, x1, #3
    8a1c:	8b010106 	add	x6, x8, x1
    8a20:	f94010c2 	ldr	x2, [x6, #32]
    8a24:	b4000202 	cbz	x2, 8a64 <fwp_hof0.constprop.0+0xca4>
    8a28:	38616901 	ldrb	w1, [x8, x1]
    8a2c:	7100083f 	cmp	w1, #0x2
    8a30:	54000e00 	b.eq	8bf0 <fwp_hof0.constprop.0+0xe30>  // b.none
    8a34:	7100043f 	cmp	w1, #0x1
    8a38:	54000161 	b.ne	8a64 <fwp_hof0.constprop.0+0xca4>  // b.any
    8a3c:	294304cb 	ldp	w11, w1, [x6, #24]
    8a40:	92403c00 	and	x0, x0, #0xffff
    8a44:	9b0b7c00 	mul	x0, x0, x11
    8a48:	d360fc00 	lsr	x0, x0, #32
    8a4c:	eb01001f 	cmp	x0, x1
    8a50:	540000a2 	b.cs	8a64 <fwp_hof0.constprop.0+0xca4>  // b.hs, b.nlast
    8a54:	8b000042 	add	x2, x2, x0
    8a58:	39400040 	ldrb	w0, [x2]
    8a5c:	7100041f 	cmp	w0, #0x1
    8a60:	54fffc80 	b.eq	89f0 <fwp_hof0.constprop.0+0xc30>  // b.none
    8a64:	eb0502ff 	cmp	x23, x5
    8a68:	54000cc2 	b.cs	8c00 <fwp_hof0.constprop.0+0xe40>  // b.hs, b.nlast
    8a6c:	aa0503f9 	mov	x25, x5
    8a70:	d100231a 	sub	x26, x24, #0x8
    8a74:	910323f3 	add	x19, sp, #0xc8
    8a78:	9115029b 	add	x27, x20, #0x540
    8a7c:	d280001c 	mov	x28, #0x0                   	// #0
    8a80:	14000012 	b	8ac8 <fwp_hof0.constprop.0+0xd08>
    8a84:	7100045f 	cmp	w2, #0x1
    8a88:	540001a1 	b.ne	8abc <fwp_hof0.constprop.0+0xcfc>  // b.any
    8a8c:	29430909 	ldp	w9, w2, [x8, #24]
    8a90:	92403c21 	and	x1, x1, #0xffff
    8a94:	9b097c21 	mul	x1, x1, x9
    8a98:	d360fc21 	lsr	x1, x1, #32
    8a9c:	eb02003f 	cmp	x1, x2
    8aa0:	540000e2 	b.cs	8abc <fwp_hof0.constprop.0+0xcfc>  // b.hs, b.nlast
    8aa4:	8b010000 	add	x0, x0, x1
    8aa8:	39400001 	ldrb	w1, [x0]
    8aac:	7103fc3f 	cmp	w1, #0xff
    8ab0:	54002f60 	b.eq	909c <fwp_hof0.constprop.0+0x12dc>  // b.none
    8ab4:	52800021 	mov	w1, #0x1                   	// #1
    8ab8:	39000001 	strb	w1, [x0]
    8abc:	d1000739 	sub	x25, x25, #0x1
    8ac0:	eb1902ff 	cmp	x23, x25
    8ac4:	54000362 	b.cs	8b30 <fwp_hof0.constprop.0+0xd70>  // b.hs, b.nlast
    8ac8:	f8797b42 	ldr	x2, [x26, x25, lsl #3]
    8acc:	aa1303e1 	mov	x1, x19
    8ad0:	52800020 	mov	w0, #0x1                   	// #1
    8ad4:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8ad8:	97fff0ab 	bl	4d84 <fwp_data.part.0.constprop.0>
    8adc:	aa0003fc 	mov	x28, x0
    8ae0:	f949db61 	ldr	x1, [x27, #5040]
    8ae4:	f949ef60 	ldr	x0, [x27, #5080]
    8ae8:	cb010381 	sub	x1, x28, x1
    8aec:	eb00403f 	cmp	x1, x0, lsl #16
    8af0:	54fffe62 	b.cs	8abc <fwp_hof0.constprop.0+0xcfc>  // b.hs, b.nlast
    8af4:	d350fc20 	lsr	x0, x1, #16
    8af8:	f949ff69 	ldr	x9, [x27, #5112]
    8afc:	8b000800 	add	x0, x0, x0, lsl #2
    8b00:	d37df002 	lsl	x2, x0, #3
    8b04:	8b020128 	add	x8, x9, x2
    8b08:	f9401100 	ldr	x0, [x8, #32]
    8b0c:	b4fffd80 	cbz	x0, 8abc <fwp_hof0.constprop.0+0xcfc>
    8b10:	38626922 	ldrb	w2, [x9, x2]
    8b14:	7100085f 	cmp	w2, #0x2
    8b18:	54fffb61 	b.ne	8a84 <fwp_hof0.constprop.0+0xcc4>  // b.any
    8b1c:	72003c3f 	tst	w1, #0xffff
    8b20:	54fffc40 	b.eq	8aa8 <fwp_hof0.constprop.0+0xce8>  // b.none
    8b24:	d1000739 	sub	x25, x25, #0x1
    8b28:	eb1902ff 	cmp	x23, x25
    8b2c:	54fffce3 	b.cc	8ac8 <fwp_hof0.constprop.0+0xd08>  // b.lo, b.ul, b.last
    8b30:	b50006b7 	cbnz	x23, 8c04 <fwp_hof0.constprop.0+0xe44>
    8b34:	b94033e0 	ldr	w0, [sp, #48]
    8b38:	d2800004 	mov	x4, #0x0                   	// #0
    8b3c:	7100001f 	cmp	w0, #0x0
    8b40:	d2800020 	mov	x0, #0x1                   	// #1
    8b44:	9a9f0318 	csel	x24, x24, xzr, eq	// eq = none
    8b48:	b40007c4 	cbz	x4, 8c40 <fwp_hof0.constprop.0+0xe80>
    8b4c:	d1000497 	sub	x23, x4, #0x1
    8b50:	2a0003fa 	mov	w26, w0
    8b54:	9115029b 	add	x27, x20, #0x540
    8b58:	f8777b02 	ldr	x2, [x24, x23, lsl #3]
    8b5c:	aa1303e1 	mov	x1, x19
    8b60:	52800020 	mov	w0, #0x1                   	// #1
    8b64:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8b68:	97fff087 	bl	4d84 <fwp_data.part.0.constprop.0>
    8b6c:	aa0003fc 	mov	x28, x0
    8b70:	f949db61 	ldr	x1, [x27, #5040]
    8b74:	f949ef60 	ldr	x0, [x27, #5080]
    8b78:	cb010381 	sub	x1, x28, x1
    8b7c:	eb00403f 	cmp	x1, x0, lsl #16
    8b80:	54000302 	b.cs	8be0 <fwp_hof0.constprop.0+0xe20>  // b.hs, b.nlast
    8b84:	d350fc22 	lsr	x2, x1, #16
    8b88:	f949ff67 	ldr	x7, [x27, #5112]
    8b8c:	8b020842 	add	x2, x2, x2, lsl #2
    8b90:	d37df042 	lsl	x2, x2, #3
    8b94:	8b0200e6 	add	x6, x7, x2
    8b98:	f94010d9 	ldr	x25, [x6, #32]
    8b9c:	b4000239 	cbz	x25, 8be0 <fwp_hof0.constprop.0+0xe20>
    8ba0:	386268e2 	ldrb	w2, [x7, x2]
    8ba4:	7100085f 	cmp	w2, #0x2
    8ba8:	54001440 	b.eq	8e30 <fwp_hof0.constprop.0+0x1070>  // b.none
    8bac:	7100045f 	cmp	w2, #0x1
    8bb0:	54000181 	b.ne	8be0 <fwp_hof0.constprop.0+0xe20>  // b.any
    8bb4:	294308c7 	ldp	w7, w2, [x6, #24]
    8bb8:	92403c21 	and	x1, x1, #0xffff
    8bbc:	9b077c21 	mul	x1, x1, x7
    8bc0:	d360fc21 	lsr	x1, x1, #32
    8bc4:	eb02003f 	cmp	x1, x2
    8bc8:	540000c2 	b.cs	8be0 <fwp_hof0.constprop.0+0xe20>  // b.hs, b.nlast
    8bcc:	8b010339 	add	x25, x25, x1
    8bd0:	39400321 	ldrb	w1, [x25]
    8bd4:	7103fc3f 	cmp	w1, #0xff
    8bd8:	54001260 	b.eq	8e24 <fwp_hof0.constprop.0+0x1064>  // b.none
    8bdc:	3900033a 	strb	w26, [x25]
    8be0:	d10006f7 	sub	x23, x23, #0x1
    8be4:	b10006ff 	cmn	x23, #0x1
    8be8:	54fffb81 	b.ne	8b58 <fwp_hof0.constprop.0+0xd98>  // b.any
    8bec:	14000015 	b	8c40 <fwp_hof0.constprop.0+0xe80>
    8bf0:	72003c1f 	tst	w0, #0xffff
    8bf4:	54fff320 	b.eq	8a58 <fwp_hof0.constprop.0+0xc98>  // b.none
    8bf8:	eb0502ff 	cmp	x23, x5
    8bfc:	54fff383 	b.cc	8a6c <fwp_hof0.constprop.0+0xcac>  // b.lo, b.ul, b.last
    8c00:	d280001c 	mov	x28, #0x0                   	// #0
    8c04:	8b170f04 	add	x4, x24, x23, lsl #3
    8c08:	aa1803e1 	mov	x1, x24
    8c0c:	aa1503e0 	mov	x0, x21
    8c10:	f8408422 	ldr	x2, [x1], #8
    8c14:	f9000402 	str	x2, [x0, #8]
    8c18:	aa0003e2 	mov	x2, x0
    8c1c:	f9400800 	ldr	x0, [x0, #16]
    8c20:	eb04003f 	cmp	x1, x4
    8c24:	54ffff61 	b.ne	8c10 <fwp_hof0.constprop.0+0xe50>  // b.any
    8c28:	b94033e1 	ldr	w1, [sp, #48]
    8c2c:	f900085c 	str	x28, [x2, #16]
    8c30:	aa1503fc 	mov	x28, x21
    8c34:	aa0003f5 	mov	x21, x0
    8c38:	34000041 	cbz	w1, 8c40 <fwp_hof0.constprop.0+0xe80>
    8c3c:	d2800018 	mov	x24, #0x0                   	// #0
    8c40:	91150293 	add	x19, x20, #0x540
    8c44:	aa1803e0 	mov	x0, x24
    8c48:	97ffeeea 	bl	47f0 <fwp_mem_free>
    8c4c:	f949ee62 	ldr	x2, [x19, #5080]
    8c50:	f949da61 	ldr	x1, [x19, #5040]
    8c54:	d370bc42 	lsl	x2, x2, #16
    8c58:	cb0102c3 	sub	x3, x22, x1
    8c5c:	eb03005f 	cmp	x2, x3
    8c60:	54000409 	b.ls	8ce0 <fwp_hof0.constprop.0+0xf20>  // b.plast
    8c64:	d350fc60 	lsr	x0, x3, #16
    8c68:	f949fe65 	ldr	x5, [x19, #5112]
    8c6c:	8b000800 	add	x0, x0, x0, lsl #2
    8c70:	d37df000 	lsl	x0, x0, #3
    8c74:	8b0000a2 	add	x2, x5, x0
    8c78:	f9401057 	ldr	x23, [x2, #32]
    8c7c:	b4000cb7 	cbz	x23, 8e10 <fwp_hof0.constprop.0+0x1050>
    8c80:	386068a1 	ldrb	w1, [x5, x0]
    8c84:	7100083f 	cmp	w1, #0x2
    8c88:	540031c0 	b.eq	92c0 <fwp_hof0.constprop.0+0x1500>  // b.none
    8c8c:	7100043f 	cmp	w1, #0x1
    8c90:	54000c01 	b.ne	8e10 <fwp_hof0.constprop.0+0x1050>  // b.any
    8c94:	29430844 	ldp	w4, w2, [x2, #24]
    8c98:	92403c61 	and	x1, x3, #0xffff
    8c9c:	9b047c21 	mul	x1, x1, x4
    8ca0:	d360fc21 	lsr	x1, x1, #32
    8ca4:	eb02003f 	cmp	x1, x2
    8ca8:	54000b42 	b.cs	8e10 <fwp_hof0.constprop.0+0x1050>  // b.hs, b.nlast
    8cac:	8b0102f7 	add	x23, x23, x1
    8cb0:	394002e1 	ldrb	w1, [x23]
    8cb4:	34000ae1 	cbz	w1, 8e10 <fwp_hof0.constprop.0+0x1050>
    8cb8:	7100043f 	cmp	w1, #0x1
    8cbc:	540006a0 	b.eq	8d90 <fwp_hof0.constprop.0+0xfd0>  // b.none
    8cc0:	7103fc3f 	cmp	w1, #0xff
    8cc4:	54004a60 	b.eq	9610 <fwp_hof0.constprop.0+0x1850>  // b.none
    8cc8:	91150280 	add	x0, x20, #0x540
    8ccc:	51000421 	sub	w1, w1, #0x1
    8cd0:	390002e1 	strb	w1, [x23]
    8cd4:	f949ec02 	ldr	x2, [x0, #5080]
    8cd8:	f949d801 	ldr	x1, [x0, #5040]
    8cdc:	d370bc42 	lsl	x2, x2, #16
    8ce0:	cb0102a1 	sub	x1, x21, x1
    8ce4:	eb01005f 	cmp	x2, x1
    8ce8:	540003c9 	b.ls	8d60 <fwp_hof0.constprop.0+0xfa0>  // b.plast
    8cec:	91150296 	add	x22, x20, #0x540
    8cf0:	d350fc20 	lsr	x0, x1, #16
    8cf4:	f949fec3 	ldr	x3, [x22, #5112]
    8cf8:	8b000800 	add	x0, x0, x0, lsl #2
    8cfc:	d37df000 	lsl	x0, x0, #3
    8d00:	8b000062 	add	x2, x3, x0
    8d04:	f9401053 	ldr	x19, [x2, #32]
    8d08:	b40002d3 	cbz	x19, 8d60 <fwp_hof0.constprop.0+0xfa0>
    8d0c:	38606860 	ldrb	w0, [x3, x0]
    8d10:	7100081f 	cmp	w0, #0x2
    8d14:	540031e0 	b.eq	9350 <fwp_hof0.constprop.0+0x1590>  // b.none
    8d18:	7100041f 	cmp	w0, #0x1
    8d1c:	54000221 	b.ne	8d60 <fwp_hof0.constprop.0+0xfa0>  // b.any
    8d20:	29430044 	ldp	w4, w0, [x2, #24]
    8d24:	92403c21 	and	x1, x1, #0xffff
    8d28:	9b047c21 	mul	x1, x1, x4
    8d2c:	d360fc21 	lsr	x1, x1, #32
    8d30:	eb00003f 	cmp	x1, x0
    8d34:	54000162 	b.cs	8d60 <fwp_hof0.constprop.0+0xfa0>  // b.hs, b.nlast
    8d38:	8b010273 	add	x19, x19, x1
    8d3c:	39400260 	ldrb	w0, [x19]
    8d40:	34000100 	cbz	w0, 8d60 <fwp_hof0.constprop.0+0xfa0>
    8d44:	7100041f 	cmp	w0, #0x1
    8d48:	540038a0 	b.eq	945c <fwp_hof0.constprop.0+0x169c>  // b.none
    8d4c:	7103fc1f 	cmp	w0, #0xff
    8d50:	54004940 	b.eq	9678 <fwp_hof0.constprop.0+0x18b8>  // b.none
    8d54:	51000400 	sub	w0, w0, #0x1
    8d58:	39000260 	strb	w0, [x19]
    8d5c:	d503201f 	nop
    8d60:	f94007e0 	ldr	x0, [sp, #8]
    8d64:	b4001a40 	cbz	x0, 90ac <fwp_hof0.constprop.0+0x12ec>
    8d68:	f94007e0 	ldr	x0, [sp, #8]
    8d6c:	f100041b 	subs	x27, x0, #0x1
    8d70:	f90007fb 	str	x27, [sp, #8]
    8d74:	54005846 	b.vs	987c <fwp_hof0.constprop.0+0x1abc>
    8d78:	91150280 	add	x0, x20, #0x540
    8d7c:	aa1c03f5 	mov	x21, x28
    8d80:	f949ec03 	ldr	x3, [x0, #5080]
    8d84:	f949d801 	ldr	x1, [x0, #5040]
    8d88:	d370bc63 	lsl	x3, x3, #16
    8d8c:	17fffc51 	b	7ed0 <fwp_hof0.constprop.0+0x110>
    8d90:	f94002c3 	ldr	x3, [x22]
    8d94:	aa1603e0 	mov	x0, x22
    8d98:	f949ee62 	ldr	x2, [x19, #5080]
    8d9c:	f949da61 	ldr	x1, [x19, #5040]
    8da0:	d370bc42 	lsl	x2, x2, #16
    8da4:	cb0102c7 	sub	x7, x22, x1
    8da8:	b7f82da3 	tbnz	x3, #63, 935c <fwp_hof0.constprop.0+0x159c>
    8dac:	eb07005f 	cmp	x2, x7
    8db0:	54fff989 	b.ls	8ce0 <fwp_hof0.constprop.0+0xf20>  // b.plast
    8db4:	d350fce3 	lsr	x3, x7, #16
    8db8:	8b030863 	add	x3, x3, x3, lsl #2
    8dbc:	d37df063 	lsl	x3, x3, #3
    8dc0:	8b0300a6 	add	x6, x5, x3
    8dc4:	f94010c4 	ldr	x4, [x6, #32]
    8dc8:	b4fff8c4 	cbz	x4, 8ce0 <fwp_hof0.constprop.0+0xf20>
    8dcc:	386368a3 	ldrb	w3, [x5, x3]
    8dd0:	7100087f 	cmp	w3, #0x2
    8dd4:	54003940 	b.eq	94fc <fwp_hof0.constprop.0+0x173c>  // b.none
    8dd8:	7100047f 	cmp	w3, #0x1
    8ddc:	54fff821 	b.ne	8ce0 <fwp_hof0.constprop.0+0xf20>  // b.any
    8de0:	29430cc5 	ldp	w5, w3, [x6, #24]
    8de4:	92403ce0 	and	x0, x7, #0xffff
    8de8:	9b057c00 	mul	x0, x0, x5
    8dec:	d360fc00 	lsr	x0, x0, #32
    8df0:	eb03001f 	cmp	x0, x3
    8df4:	54fff762 	b.cs	8ce0 <fwp_hof0.constprop.0+0xf20>  // b.hs, b.nlast
    8df8:	8b000084 	add	x4, x4, x0
    8dfc:	39400080 	ldrb	w0, [x4]
    8e00:	7100041f 	cmp	w0, #0x1
    8e04:	54fff6e1 	b.ne	8ce0 <fwp_hof0.constprop.0+0xf20>  // b.any
    8e08:	aa1603e0 	mov	x0, x22
    8e0c:	97ffee79 	bl	47f0 <fwp_mem_free>
    8e10:	91150280 	add	x0, x20, #0x540
    8e14:	f949ec02 	ldr	x2, [x0, #5080]
    8e18:	f949d801 	ldr	x1, [x0, #5040]
    8e1c:	d370bc42 	lsl	x2, x2, #16
    8e20:	17ffffb0 	b	8ce0 <fwp_hof0.constprop.0+0xf20>
    8e24:	aa1903e0 	mov	x0, x25
    8e28:	97ffedd2 	bl	4570 <fwp_rc_forget_slot>
    8e2c:	17ffff6c 	b	8bdc <fwp_hof0.constprop.0+0xe1c>
    8e30:	72003c3f 	tst	w1, #0xffff
    8e34:	54ffed61 	b.ne	8be0 <fwp_hof0.constprop.0+0xe20>  // b.any
    8e38:	17ffff66 	b	8bd0 <fwp_hof0.constprop.0+0xe10>
    8e3c:	72003c1f 	tst	w0, #0xffff
    8e40:	54ffd840 	b.eq	8948 <fwp_hof0.constprop.0+0xb88>  // b.none
    8e44:	b4001055 	cbz	x21, 904c <fwp_hof0.constprop.0+0x128c>
    8e48:	aa1503f3 	mov	x19, x21
    8e4c:	d2800017 	mov	x23, #0x0                   	// #0
    8e50:	f9400a73 	ldr	x19, [x19, #16]
    8e54:	aa1703e0 	mov	x0, x23
    8e58:	910006f7 	add	x23, x23, #0x1
    8e5c:	b5ffffb3 	cbnz	x19, 8e50 <fwp_hof0.constprop.0+0x1090>
    8e60:	f9001be5 	str	x5, [sp, #48]
    8e64:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8e68:	eb0102ff 	cmp	x23, x1
    8e6c:	54004cc8 	b.hi	9804 <fwp_hof0.constprop.0+0x1a44>  // b.pmore
    8e70:	91000800 	add	x0, x0, #0x2
    8e74:	52800041 	mov	w1, #0x2                   	// #2
    8e78:	d37df000 	lsl	x0, x0, #3
    8e7c:	97ffef7d 	bl	4c70 <fwp_heap_alloc>
    8e80:	f9401be5 	ldr	x5, [sp, #48]
    8e84:	aa0003f8 	mov	x24, x0
    8e88:	aa1503e1 	mov	x1, x21
    8e8c:	eb0502ff 	cmp	x23, x5
    8e90:	9a8592e5 	csel	x5, x23, x5, ls	// ls = plast
    8e94:	d503201f 	nop
    8e98:	f9400420 	ldr	x0, [x1, #8]
    8e9c:	f8337b00 	str	x0, [x24, x19, lsl #3]
    8ea0:	91000673 	add	x19, x19, #0x1
    8ea4:	f9400821 	ldr	x1, [x1, #16]
    8ea8:	b5ffff81 	cbnz	x1, 8e98 <fwp_hof0.constprop.0+0x10d8>
    8eac:	b4000d85 	cbz	x5, 905c <fwp_hof0.constprop.0+0x129c>
    8eb0:	f9400384 	ldr	x4, [x28]
    8eb4:	b90033ff 	str	wzr, [sp, #48]
    8eb8:	17fffeac 	b	8968 <fwp_hof0.constprop.0+0xba8>
    8ebc:	eb1302df 	cmp	x22, x19
    8ec0:	54ff8ea0 	b.eq	8094 <fwp_hof0.constprop.0+0x2d4>  // b.none
    8ec4:	900000c0 	adrp	x0, 20000 <__data_start>
    8ec8:	8b1606d8 	add	x24, x22, x22, lsl #1
    8ecc:	f940181c 	ldr	x28, [x0, #48]
    8ed0:	8b180ad8 	add	x24, x22, x24, lsl #2
    8ed4:	90000020 	adrp	x0, c000 <fwp_main_thread+0x120>
    8ed8:	9135e000 	add	x0, x0, #0xd78
    8edc:	8b180f98 	add	x24, x28, x24, lsl #3
    8ee0:	f900331f 	str	xzr, [x24, #96]
    8ee4:	97ffe6cb 	bl	2a10 <getenv@plt>
    8ee8:	b5ff9340 	cbnz	x0, 8150 <fwp_hof0.constprop.0+0x390>
    8eec:	900000c0 	adrp	x0, 20000 <__data_start>
    8ef0:	9100c000 	add	x0, x0, #0x30
    8ef4:	f9404001 	ldr	x1, [x0, #128]
    8ef8:	b4ff9361 	cbz	x1, 8164 <fwp_hof0.constprop.0+0x3a4>
    8efc:	3cc48002 	ldur	q2, [x0, #72]
    8f00:	91012001 	add	x1, x0, #0x48
    8f04:	3cc58001 	ldur	q1, [x0, #88]
    8f08:	f900401f 	str	xzr, [x0, #128]
    8f0c:	4f000400 	movi	v0.4s, #0x0
    8f10:	ad010702 	stp	q2, q1, [x24, #32]
    8f14:	a9468002 	ldp	x2, x0, [x0, #104]
    8f18:	f9000f00 	str	x0, [x24, #24]
    8f1c:	f9401820 	ldr	x0, [x1, #48]
    8f20:	f9002302 	str	x2, [x24, #64]
    8f24:	f9002700 	str	x0, [x24, #72]
    8f28:	ad000020 	stp	q0, q0, [x1]
    8f2c:	3d800820 	str	q0, [x1, #32]
    8f30:	f900183f 	str	xzr, [x1, #48]
    8f34:	17fffc8c 	b	8164 <fwp_hof0.constprop.0+0x3a4>
    8f38:	d53bd040 	mrs	x0, tpidr_el0
    8f3c:	91400000 	add	x0, x0, #0x0, lsl #12
    8f40:	91004000 	add	x0, x0, #0x10
    8f44:	f9400000 	ldr	x0, [x0]
    8f48:	b40024c0 	cbz	x0, 93e0 <fwp_hof0.constprop.0+0x1620>
    8f4c:	f94017e1 	ldr	x1, [sp, #40]
    8f50:	97ffe9a5 	bl	35e4 <fwp_closure_drop_push>
    8f54:	b5ff8595 	cbnz	x21, 8004 <fwp_hof0.constprop.0+0x244>
    8f58:	900000c0 	adrp	x0, 20000 <__data_start>
    8f5c:	9100c013 	add	x19, x0, #0x30
    8f60:	d2800017 	mov	x23, #0x0                   	// #0
    8f64:	b942f660 	ldr	w0, [x19, #756]
    8f68:	35ff86a0 	cbnz	w0, 803c <fwp_hof0.constprop.0+0x27c>
    8f6c:	d503201f 	nop
    8f70:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    8f74:	91314000 	add	x0, x0, #0xc50
    8f78:	94000ee6 	bl	cb10 <atexit>
    8f7c:	35ffc420 	cbnz	w0, 8800 <fwp_hof0.constprop.0+0xa40>
    8f80:	52800020 	mov	w0, #0x1                   	// #1
    8f84:	b902f660 	str	w0, [x19, #756]
    8f88:	17fffc2d 	b	803c <fwp_hof0.constprop.0+0x27c>
    8f8c:	72003c1f 	tst	w0, #0xffff
    8f90:	54ffbe40 	b.eq	8758 <fwp_hof0.constprop.0+0x998>  // b.none
    8f94:	d503201f 	nop
    8f98:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8f9c:	eb0002ff 	cmp	x23, x0
    8fa0:	54004568 	b.hi	984c <fwp_hof0.constprop.0+0x1a8c>  // b.pmore
    8fa4:	910006e0 	add	x0, x23, #0x1
    8fa8:	52800021 	mov	w1, #0x1                   	// #1
    8fac:	d37df000 	lsl	x0, x0, #3
    8fb0:	97ffef30 	bl	4c70 <fwp_heap_alloc>
    8fb4:	91150282 	add	x2, x20, #0x540
    8fb8:	f9000017 	str	x23, [x0]
    8fbc:	aa0003fc 	mov	x28, x0
    8fc0:	aa0003f6 	mov	x22, x0
    8fc4:	f949d841 	ldr	x1, [x2, #5040]
    8fc8:	f949ec40 	ldr	x0, [x2, #5080]
    8fcc:	cb010381 	sub	x1, x28, x1
    8fd0:	eb00403f 	cmp	x1, x0, lsl #16
    8fd4:	54000322 	b.cs	9038 <fwp_hof0.constprop.0+0x1278>  // b.hs, b.nlast
    8fd8:	d350fc20 	lsr	x0, x1, #16
    8fdc:	f949fc44 	ldr	x4, [x2, #5112]
    8fe0:	8b000800 	add	x0, x0, x0, lsl #2
    8fe4:	d37df002 	lsl	x2, x0, #3
    8fe8:	8b020083 	add	x3, x4, x2
    8fec:	f9401078 	ldr	x24, [x3, #32]
    8ff0:	b4000258 	cbz	x24, 9038 <fwp_hof0.constprop.0+0x1278>
    8ff4:	38626882 	ldrb	w2, [x4, x2]
    8ff8:	7100085f 	cmp	w2, #0x2
    8ffc:	54002860 	b.eq	9508 <fwp_hof0.constprop.0+0x1748>  // b.none
    9000:	7100045f 	cmp	w2, #0x1
    9004:	540001a1 	b.ne	9038 <fwp_hof0.constprop.0+0x1278>  // b.any
    9008:	29430864 	ldp	w4, w2, [x3, #24]
    900c:	92403c21 	and	x1, x1, #0xffff
    9010:	9b047c21 	mul	x1, x1, x4
    9014:	d360fc21 	lsr	x1, x1, #32
    9018:	eb02003f 	cmp	x1, x2
    901c:	540000e2 	b.cs	9038 <fwp_hof0.constprop.0+0x1278>  // b.hs, b.nlast
    9020:	8b010318 	add	x24, x24, x1
    9024:	39400301 	ldrb	w1, [x24]
    9028:	7103fc3f 	cmp	w1, #0xff
    902c:	54002760 	b.eq	9518 <fwp_hof0.constprop.0+0x1758>  // b.none
    9030:	52800021 	mov	w1, #0x1                   	// #1
    9034:	39000301 	strb	w1, [x24]
    9038:	aa1303e0 	mov	x0, x19
    903c:	17fffdcd 	b	8770 <fwp_hof0.constprop.0+0x9b0>
    9040:	eb1700bf 	cmp	x5, x23
    9044:	54ffd148 	b.hi	8a6c <fwp_hof0.constprop.0+0xcac>  // b.pmore
    9048:	17fffeee 	b	8c00 <fwp_hof0.constprop.0+0xe40>
    904c:	52800041 	mov	w1, #0x2                   	// #2
    9050:	d2800100 	mov	x0, #0x8                   	// #8
    9054:	97ffef07 	bl	4c70 <fwp_heap_alloc>
    9058:	aa0003f8 	mov	x24, x0
    905c:	d280001c 	mov	x28, #0x0                   	// #0
    9060:	17fffef8 	b	8c40 <fwp_hof0.constprop.0+0xe80>
    9064:	52800041 	mov	w1, #0x2                   	// #2
    9068:	d2800100 	mov	x0, #0x8                   	// #8
    906c:	97ffef01 	bl	4c70 <fwp_heap_alloc>
    9070:	aa0003f8 	mov	x24, x0
    9074:	91150280 	add	x0, x20, #0x540
    9078:	aa1803fc 	mov	x28, x24
    907c:	f900031f 	str	xzr, [x24]
    9080:	f949d801 	ldr	x1, [x0, #5040]
    9084:	f949ec00 	ldr	x0, [x0, #5080]
    9088:	cb010301 	sub	x1, x24, x1
    908c:	eb00403f 	cmp	x1, x0, lsl #16
    9090:	540010c2 	b.cs	92a8 <fwp_hof0.constprop.0+0x14e8>  // b.hs, b.nlast
    9094:	d2800016 	mov	x22, #0x0                   	// #0
    9098:	17fffc78 	b	8278 <fwp_hof0.constprop.0+0x4b8>
    909c:	f9001fe0 	str	x0, [sp, #56]
    90a0:	97ffed34 	bl	4570 <fwp_rc_forget_slot>
    90a4:	f9401fe0 	ldr	x0, [sp, #56]
    90a8:	17fffe83 	b	8ab4 <fwp_hof0.constprop.0+0xcf4>
    90ac:	f9400be0 	ldr	x0, [sp, #16]
    90b0:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xf4c0>
    90b4:	910aa042 	add	x2, x2, #0x2a8
    90b8:	aa1c03e1 	mov	x1, x28
    90bc:	91014042 	add	x2, x2, #0x50
    90c0:	52800023 	mov	w3, #0x1                   	// #1
    90c4:	a9097fff 	stp	xzr, xzr, [sp, #144]
    90c8:	f90053ff 	str	xzr, [sp, #160]
    90cc:	97fff741 	bl	6dd0 <fwp_write>
    90d0:	a9495bf5 	ldp	x21, x22, [sp, #144]
    90d4:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    90d8:	9115c000 	add	x0, x0, #0x570
    90dc:	f10002bf 	cmp	x21, #0x0
    90e0:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    90e4:	b1002adf 	cmn	x22, #0xa
    90e8:	54003ac8 	b.hi	9840 <fwp_hof0.constprop.0+0x1a80>  // b.pmore
    90ec:	910026c0 	add	x0, x22, #0x9
    90f0:	52800021 	mov	w1, #0x1                   	// #1
    90f4:	97ffeedf 	bl	4c70 <fwp_heap_alloc>
    90f8:	aa0003f7 	mov	x23, x0
    90fc:	aa0003f3 	mov	x19, x0
    9100:	aa1603e2 	mov	x2, x22
    9104:	aa1503e1 	mov	x1, x21
    9108:	f80086f6 	str	x22, [x23], #8
    910c:	8b160276 	add	x22, x19, x22
    9110:	aa1703e0 	mov	x0, x23
    9114:	97ffe56f 	bl	26d0 <memcpy@plt>
    9118:	390022df 	strb	wzr, [x22, #8]
    911c:	f9404be0 	ldr	x0, [sp, #144]
    9120:	97ffe608 	bl	2940 <free@plt>
    9124:	91150281 	add	x1, x20, #0x540
    9128:	f949d822 	ldr	x2, [x1, #5040]
    912c:	f949ec20 	ldr	x0, [x1, #5080]
    9130:	cb020262 	sub	x2, x19, x2
    9134:	eb00405f 	cmp	x2, x0, lsl #16
    9138:	54000322 	b.cs	919c <fwp_hof0.constprop.0+0x13dc>  // b.hs, b.nlast
    913c:	d350fc40 	lsr	x0, x2, #16
    9140:	f949fc23 	ldr	x3, [x1, #5112]
    9144:	8b000800 	add	x0, x0, x0, lsl #2
    9148:	d37df001 	lsl	x1, x0, #3
    914c:	8b010060 	add	x0, x3, x1
    9150:	f9401015 	ldr	x21, [x0, #32]
    9154:	b4000255 	cbz	x21, 919c <fwp_hof0.constprop.0+0x13dc>
    9158:	38616861 	ldrb	w1, [x3, x1]
    915c:	7100083f 	cmp	w1, #0x2
    9160:	54002b80 	b.eq	96d0 <fwp_hof0.constprop.0+0x1910>  // b.none
    9164:	7100043f 	cmp	w1, #0x1
    9168:	540001a1 	b.ne	919c <fwp_hof0.constprop.0+0x13dc>  // b.any
    916c:	29430003 	ldp	w3, w0, [x0, #24]
    9170:	92403c41 	and	x1, x2, #0xffff
    9174:	9b037c21 	mul	x1, x1, x3
    9178:	d360fc21 	lsr	x1, x1, #32
    917c:	eb00003f 	cmp	x1, x0
    9180:	540000e2 	b.cs	919c <fwp_hof0.constprop.0+0x13dc>  // b.hs, b.nlast
    9184:	8b0102b5 	add	x21, x21, x1
    9188:	394002a0 	ldrb	w0, [x21]
    918c:	7103fc1f 	cmp	w0, #0xff
    9190:	54002aa0 	b.eq	96e4 <fwp_hof0.constprop.0+0x1924>  // b.none
    9194:	52800020 	mov	w0, #0x1                   	// #1
    9198:	390002a0 	strb	w0, [x21]
    919c:	aa1c03e0 	mov	x0, x28
    91a0:	97fff1b8 	bl	5880 <fwp_drop0>
    91a4:	f00000a0 	adrp	x0, 20000 <__data_start>
    91a8:	9100c015 	add	x21, x0, #0x30
    91ac:	f9400262 	ldr	x2, [x19]
    91b0:	d2800021 	mov	x1, #0x1                   	// #1
    91b4:	f94006a3 	ldr	x3, [x21, #8]
    91b8:	aa1703e0 	mov	x0, x23
    91bc:	97ffe5f1 	bl	2980 <fwrite@plt>
    91c0:	f94006a1 	ldr	x1, [x21, #8]
    91c4:	52800140 	mov	w0, #0xa                   	// #10
    91c8:	97ffe576 	bl	27a0 <fputc@plt>
    91cc:	91150281 	add	x1, x20, #0x540
    91d0:	f949d822 	ldr	x2, [x1, #5040]
    91d4:	f949ec20 	ldr	x0, [x1, #5080]
    91d8:	cb020262 	sub	x2, x19, x2
    91dc:	eb00405f 	cmp	x2, x0, lsl #16
    91e0:	54000382 	b.cs	9250 <fwp_hof0.constprop.0+0x1490>  // b.hs, b.nlast
    91e4:	d350fc40 	lsr	x0, x2, #16
    91e8:	f949fc23 	ldr	x3, [x1, #5112]
    91ec:	8b000800 	add	x0, x0, x0, lsl #2
    91f0:	d37df001 	lsl	x1, x0, #3
    91f4:	8b010060 	add	x0, x3, x1
    91f8:	f9401015 	ldr	x21, [x0, #32]
    91fc:	b40002b5 	cbz	x21, 9250 <fwp_hof0.constprop.0+0x1490>
    9200:	38616861 	ldrb	w1, [x3, x1]
    9204:	7100083f 	cmp	w1, #0x2
    9208:	54002740 	b.eq	96f0 <fwp_hof0.constprop.0+0x1930>  // b.none
    920c:	7100043f 	cmp	w1, #0x1
    9210:	54000201 	b.ne	9250 <fwp_hof0.constprop.0+0x1490>  // b.any
    9214:	29430003 	ldp	w3, w0, [x0, #24]
    9218:	92403c41 	and	x1, x2, #0xffff
    921c:	9b037c21 	mul	x1, x1, x3
    9220:	d360fc21 	lsr	x1, x1, #32
    9224:	eb00003f 	cmp	x1, x0
    9228:	54000142 	b.cs	9250 <fwp_hof0.constprop.0+0x1490>  // b.hs, b.nlast
    922c:	8b0102b5 	add	x21, x21, x1
    9230:	394002a0 	ldrb	w0, [x21]
    9234:	340000e0 	cbz	w0, 9250 <fwp_hof0.constprop.0+0x1490>
    9238:	7100041f 	cmp	w0, #0x1
    923c:	54001a00 	b.eq	957c <fwp_hof0.constprop.0+0x17bc>  // b.none
    9240:	7103fc1f 	cmp	w0, #0xff
    9244:	54002ae0 	b.eq	97a0 <fwp_hof0.constprop.0+0x19e0>  // b.none
    9248:	51000400 	sub	w0, w0, #0x1
    924c:	390002a0 	strb	w0, [x21]
    9250:	f94027e0 	ldr	x0, [sp, #72]
    9254:	f9400800 	ldr	x0, [x0, #16]
    9258:	f90027e0 	str	x0, [sp, #72]
    925c:	b5ff5e80 	cbnz	x0, 7e2c <fwp_hof0.constprop.0+0x6c>
    9260:	a94f53f3 	ldp	x19, x20, [sp, #240]
    9264:	a9505bf5 	ldp	x21, x22, [sp, #256]
    9268:	a95163f7 	ldp	x23, x24, [sp, #272]
    926c:	a9526bf9 	ldp	x25, x26, [sp, #288]
    9270:	a95373fb 	ldp	x27, x28, [sp, #304]
    9274:	fd40a3e8 	ldr	d8, [sp, #320]
    9278:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    927c:	f947f400 	ldr	x0, [x0, #4072]
    9280:	f9406fe2 	ldr	x2, [sp, #216]
    9284:	f9400001 	ldr	x1, [x0]
    9288:	eb010042 	subs	x2, x2, x1
    928c:	d2800001 	mov	x1, #0x0                   	// #0
    9290:	54002e81 	b.ne	9860 <fwp_hof0.constprop.0+0x1aa0>  // b.any
    9294:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    9298:	d2800000 	mov	x0, #0x0                   	// #0
    929c:	910543ff 	add	sp, sp, #0x150
    92a0:	d65f03c0 	ret
    92a4:	b5ff81f6 	cbnz	x22, 82e0 <fwp_hof0.constprop.0+0x520>
    92a8:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    92ac:	f900031f 	str	xzr, [x24]
    92b0:	17fffc3f 	b	83ac <fwp_hof0.constprop.0+0x5ec>
    92b4:	72003c3f 	tst	w1, #0xffff
    92b8:	54ff8bc1 	b.ne	8430 <fwp_hof0.constprop.0+0x670>  // b.any
    92bc:	17fffc55 	b	8410 <fwp_hof0.constprop.0+0x650>
    92c0:	72003c7f 	tst	w3, #0xffff
    92c4:	54ffda61 	b.ne	8e10 <fwp_hof0.constprop.0+0x1050>  // b.any
    92c8:	17fffe7a 	b	8cb0 <fwp_hof0.constprop.0+0xef0>
    92cc:	f940079c 	ldr	x28, [x28, #8]
    92d0:	eb02009f 	cmp	x4, x2
    92d4:	54000369 	b.ls	9340 <fwp_hof0.constprop.0+0x1580>  // b.plast
    92d8:	d350fc46 	lsr	x6, x2, #16
    92dc:	8b0608c6 	add	x6, x6, x6, lsl #2
    92e0:	d37df0c6 	lsl	x6, x6, #3
    92e4:	8b0600a8 	add	x8, x5, x6
    92e8:	f9401107 	ldr	x7, [x8, #32]
    92ec:	b40002a7 	cbz	x7, 9340 <fwp_hof0.constprop.0+0x1580>
    92f0:	386668a5 	ldrb	w5, [x5, x6]
    92f4:	710008bf 	cmp	w5, #0x2
    92f8:	540013c0 	b.eq	9570 <fwp_hof0.constprop.0+0x17b0>  // b.none
    92fc:	710004bf 	cmp	w5, #0x1
    9300:	54000201 	b.ne	9340 <fwp_hof0.constprop.0+0x1580>  // b.any
    9304:	29431506 	ldp	w6, w5, [x8, #24]
    9308:	92403c42 	and	x2, x2, #0xffff
    930c:	9b067c42 	mul	x2, x2, x6
    9310:	d360fc42 	lsr	x2, x2, #32
    9314:	eb05005f 	cmp	x2, x5
    9318:	54000142 	b.cs	9340 <fwp_hof0.constprop.0+0x1580>  // b.hs, b.nlast
    931c:	8b0200e7 	add	x7, x7, x2
    9320:	394000e2 	ldrb	w2, [x7]
    9324:	7100045f 	cmp	w2, #0x1
    9328:	540000c1 	b.ne	9340 <fwp_hof0.constprop.0+0x1580>  // b.any
    932c:	97ffed31 	bl	47f0 <fwp_mem_free>
    9330:	91150280 	add	x0, x20, #0x540
    9334:	f949ec04 	ldr	x4, [x0, #5080]
    9338:	f949d801 	ldr	x1, [x0, #5040]
    933c:	d370bc84 	lsl	x4, x4, #16
    9340:	cb010381 	sub	x1, x28, x1
    9344:	eb04003f 	cmp	x1, x4
    9348:	54ff83e3 	b.cc	83c4 <fwp_hof0.constprop.0+0x604>  // b.lo, b.ul, b.last
    934c:	17fffc39 	b	8430 <fwp_hof0.constprop.0+0x670>
    9350:	72003c3f 	tst	w1, #0xffff
    9354:	54ffd061 	b.ne	8d60 <fwp_hof0.constprop.0+0xfa0>  // b.any
    9358:	17fffe79 	b	8d3c <fwp_hof0.constprop.0+0xf7c>
    935c:	f94006d6 	ldr	x22, [x22, #8]
    9360:	eb07005f 	cmp	x2, x7
    9364:	54000369 	b.ls	93d0 <fwp_hof0.constprop.0+0x1610>  // b.plast
    9368:	d350fce3 	lsr	x3, x7, #16
    936c:	8b030863 	add	x3, x3, x3, lsl #2
    9370:	d37df063 	lsl	x3, x3, #3
    9374:	8b0300a6 	add	x6, x5, x3
    9378:	f94010c4 	ldr	x4, [x6, #32]
    937c:	b40002a4 	cbz	x4, 93d0 <fwp_hof0.constprop.0+0x1610>
    9380:	386368a3 	ldrb	w3, [x5, x3]
    9384:	7100087f 	cmp	w3, #0x2
    9388:	54001000 	b.eq	9588 <fwp_hof0.constprop.0+0x17c8>  // b.none
    938c:	7100047f 	cmp	w3, #0x1
    9390:	54000201 	b.ne	93d0 <fwp_hof0.constprop.0+0x1610>  // b.any
    9394:	294314c8 	ldp	w8, w5, [x6, #24]
    9398:	92403ce3 	and	x3, x7, #0xffff
    939c:	9b087c63 	mul	x3, x3, x8
    93a0:	d360fc63 	lsr	x3, x3, #32
    93a4:	eb05007f 	cmp	x3, x5
    93a8:	54000142 	b.cs	93d0 <fwp_hof0.constprop.0+0x1610>  // b.hs, b.nlast
    93ac:	8b030084 	add	x4, x4, x3
    93b0:	39400083 	ldrb	w3, [x4]
    93b4:	7100047f 	cmp	w3, #0x1
    93b8:	540000c1 	b.ne	93d0 <fwp_hof0.constprop.0+0x1610>  // b.any
    93bc:	97ffed0d 	bl	47f0 <fwp_mem_free>
    93c0:	91150280 	add	x0, x20, #0x540
    93c4:	f949ec02 	ldr	x2, [x0, #5080]
    93c8:	f949d801 	ldr	x1, [x0, #5040]
    93cc:	d370bc42 	lsl	x2, x2, #16
    93d0:	cb0102c3 	sub	x3, x22, x1
    93d4:	eb03005f 	cmp	x2, x3
    93d8:	54ffc468 	b.hi	8c64 <fwp_hof0.constprop.0+0xea4>  // b.pmore
    93dc:	17fffe41 	b	8ce0 <fwp_hof0.constprop.0+0xf20>
    93e0:	f94017e0 	ldr	x0, [sp, #40]
    93e4:	97ffe8ef 	bl	37a0 <fwp_closure_drop.part.0>
    93e8:	17fffb06 	b	8000 <fwp_hof0.constprop.0+0x240>
    93ec:	72003c3f 	tst	w1, #0xffff
    93f0:	54ff7761 	b.ne	82dc <fwp_hof0.constprop.0+0x51c>  // b.any
    93f4:	394002e0 	ldrb	w0, [x23]
    93f8:	7103fc1f 	cmp	w0, #0xff
    93fc:	54ff76c1 	b.ne	82d4 <fwp_hof0.constprop.0+0x514>  // b.any
    9400:	aa1703e0 	mov	x0, x23
    9404:	97ffec5b 	bl	4570 <fwp_rc_forget_slot>
    9408:	17fffbb3 	b	82d4 <fwp_hof0.constprop.0+0x514>
    940c:	72003c3f 	tst	w1, #0xffff
    9410:	54ff5d01 	b.ne	7fb0 <fwp_hof0.constprop.0+0x1f0>  // b.any
    9414:	aa1303e0 	mov	x0, x19
    9418:	17fffad3 	b	7f64 <fwp_hof0.constprop.0+0x1a4>
    941c:	72003c3f 	tst	w1, #0xffff
    9420:	54ff5f01 	b.ne	8000 <fwp_hof0.constprop.0+0x240>  // b.any
    9424:	17fffaef 	b	7fe0 <fwp_hof0.constprop.0+0x220>
    9428:	aa1703f3 	mov	x19, x23
    942c:	17fffc35 	b	8500 <fwp_hof0.constprop.0+0x740>
    9430:	72003c3f 	tst	w1, #0xffff
    9434:	54ff9481 	b.ne	86c4 <fwp_hof0.constprop.0+0x904>  // b.any
    9438:	394002c0 	ldrb	w0, [x22]
    943c:	7103fc1f 	cmp	w0, #0xff
    9440:	54ff93e1 	b.ne	86bc <fwp_hof0.constprop.0+0x8fc>  // b.any
    9444:	aa1603e0 	mov	x0, x22
    9448:	97ffec4a 	bl	4570 <fwp_rc_forget_slot>
    944c:	17fffc9c 	b	86bc <fwp_hof0.constprop.0+0x8fc>
    9450:	72003c5f 	tst	w2, #0xffff
    9454:	54ff7ee1 	b.ne	8430 <fwp_hof0.constprop.0+0x670>  // b.any
    9458:	17fffd11 	b	889c <fwp_hof0.constprop.0+0xadc>
    945c:	91150280 	add	x0, x20, #0x540
    9460:	f9400ab3 	ldr	x19, [x21, #16]
    9464:	f949ec04 	ldr	x4, [x0, #5080]
    9468:	f949d801 	ldr	x1, [x0, #5040]
    946c:	d370bc84 	lsl	x4, x4, #16
    9470:	cb0102a0 	sub	x0, x21, x1
    9474:	eb04001f 	cmp	x0, x4
    9478:	54000382 	b.cs	94e8 <fwp_hof0.constprop.0+0x1728>  // b.hs, b.nlast
    947c:	d350fc02 	lsr	x2, x0, #16
    9480:	8b020842 	add	x2, x2, x2, lsl #2
    9484:	d37df042 	lsl	x2, x2, #3
    9488:	8b020066 	add	x6, x3, x2
    948c:	f94010c5 	ldr	x5, [x6, #32]
    9490:	b40002c5 	cbz	x5, 94e8 <fwp_hof0.constprop.0+0x1728>
    9494:	38626862 	ldrb	w2, [x3, x2]
    9498:	7100085f 	cmp	w2, #0x2
    949c:	540007c0 	b.eq	9594 <fwp_hof0.constprop.0+0x17d4>  // b.none
    94a0:	7100045f 	cmp	w2, #0x1
    94a4:	54000221 	b.ne	94e8 <fwp_hof0.constprop.0+0x1728>  // b.any
    94a8:	294308c3 	ldp	w3, w2, [x6, #24]
    94ac:	92403c00 	and	x0, x0, #0xffff
    94b0:	9b037c00 	mul	x0, x0, x3
    94b4:	d360fc00 	lsr	x0, x0, #32
    94b8:	eb02001f 	cmp	x0, x2
    94bc:	54000162 	b.cs	94e8 <fwp_hof0.constprop.0+0x1728>  // b.hs, b.nlast
    94c0:	8b0000a5 	add	x5, x5, x0
    94c4:	394000a0 	ldrb	w0, [x5]
    94c8:	7100041f 	cmp	w0, #0x1
    94cc:	540000e1 	b.ne	94e8 <fwp_hof0.constprop.0+0x1728>  // b.any
    94d0:	aa1503e0 	mov	x0, x21
    94d4:	97ffecc7 	bl	47f0 <fwp_mem_free>
    94d8:	91150280 	add	x0, x20, #0x540
    94dc:	f949ec04 	ldr	x4, [x0, #5080]
    94e0:	f949d801 	ldr	x1, [x0, #5040]
    94e4:	d370bc84 	lsl	x4, x4, #16
    94e8:	cb010261 	sub	x1, x19, x1
    94ec:	eb01009f 	cmp	x4, x1
    94f0:	54ffc389 	b.ls	8d60 <fwp_hof0.constprop.0+0xfa0>  // b.plast
    94f4:	aa1303f5 	mov	x21, x19
    94f8:	17fffdfe 	b	8cf0 <fwp_hof0.constprop.0+0xf30>
    94fc:	72003cff 	tst	w7, #0xffff
    9500:	54ffbf01 	b.ne	8ce0 <fwp_hof0.constprop.0+0xf20>  // b.any
    9504:	17fffe3e 	b	8dfc <fwp_hof0.constprop.0+0x103c>
    9508:	72003c3f 	tst	w1, #0xffff
    950c:	54ffd8c0 	b.eq	9024 <fwp_hof0.constprop.0+0x1264>  // b.none
    9510:	aa1303e0 	mov	x0, x19
    9514:	17fffc97 	b	8770 <fwp_hof0.constprop.0+0x9b0>
    9518:	aa1803e0 	mov	x0, x24
    951c:	97ffec15 	bl	4570 <fwp_rc_forget_slot>
    9520:	17fffec4 	b	9030 <fwp_hof0.constprop.0+0x1270>
    9524:	aa1603e0 	mov	x0, x22
    9528:	d2800101 	mov	x1, #0x8                   	// #8
    952c:	97ffe4cd 	bl	2860 <calloc@plt>
    9530:	aa0003fc 	mov	x28, x0
    9534:	f9401be4 	ldr	x4, [sp, #48]
    9538:	17fffc04 	b	8548 <fwp_hof0.constprop.0+0x788>
    953c:	f9400384 	ldr	x4, [x28]
    9540:	b7ffd864 	tbnz	x4, #63, 904c <fwp_hof0.constprop.0+0x128c>
    9544:	91150281 	add	x1, x20, #0x540
    9548:	f949d820 	ldr	x0, [x1, #5040]
    954c:	f949ec21 	ldr	x1, [x1, #5080]
    9550:	cb0002c0 	sub	x0, x22, x0
    9554:	eb01401f 	cmp	x0, x1, lsl #16
    9558:	54ffd7a2 	b.cs	904c <fwp_hof0.constprop.0+0x128c>  // b.hs, b.nlast
    955c:	9240f885 	and	x5, x4, #0x7fffffffffffffff
    9560:	17fffce6 	b	88f8 <fwp_hof0.constprop.0+0xb38>
    9564:	d2800d01 	mov	x1, #0x68                  	// #104
    9568:	d2800038 	mov	x24, #0x1                   	// #1
    956c:	17fffadc 	b	80dc <fwp_hof0.constprop.0+0x31c>
    9570:	72003c5f 	tst	w2, #0xffff
    9574:	54ffee61 	b.ne	9340 <fwp_hof0.constprop.0+0x1580>  // b.any
    9578:	17ffff6a 	b	9320 <fwp_hof0.constprop.0+0x1560>
    957c:	aa1303e0 	mov	x0, x19
    9580:	97ffef95 	bl	53d4 <fwp_rc_free_arr>
    9584:	17ffff33 	b	9250 <fwp_hof0.constprop.0+0x1490>
    9588:	72003cff 	tst	w7, #0xffff
    958c:	54fff221 	b.ne	93d0 <fwp_hof0.constprop.0+0x1610>  // b.any
    9590:	17ffff88 	b	93b0 <fwp_hof0.constprop.0+0x15f0>
    9594:	72003c1f 	tst	w0, #0xffff
    9598:	54fffa81 	b.ne	94e8 <fwp_hof0.constprop.0+0x1728>  // b.any
    959c:	17ffffca 	b	94c4 <fwp_hof0.constprop.0+0x1704>
    95a0:	72003c9f 	tst	w4, #0xffff
    95a4:	54ff4901 	b.ne	7ec4 <fwp_hof0.constprop.0+0x104>  // b.any
    95a8:	17fffa3c 	b	7e98 <fwp_hof0.constprop.0+0xd8>
    95ac:	ca5746e0 	eor	x0, x23, x23, lsr #17
    95b0:	91150281 	add	x1, x20, #0x540
    95b4:	ca402400 	eor	x0, x0, x0, lsr #9
    95b8:	8b200c20 	add	x0, x1, w0, uxtb #3
    95bc:	f94a2400 	ldr	x0, [x0, #5192]
    95c0:	b5000080 	cbnz	x0, 95d0 <fwp_hof0.constprop.0+0x1810>
    95c4:	14000010 	b	9604 <fwp_hof0.constprop.0+0x1844>
    95c8:	f9400800 	ldr	x0, [x0, #16]
    95cc:	b40001c0 	cbz	x0, 9604 <fwp_hof0.constprop.0+0x1844>
    95d0:	f9400001 	ldr	x1, [x0]
    95d4:	eb17003f 	cmp	x1, x23
    95d8:	54ffff81 	b.ne	95c8 <fwp_hof0.constprop.0+0x1808>  // b.any
    95dc:	f9400401 	ldr	x1, [x0, #8]
    95e0:	d1000421 	sub	x1, x1, #0x1
    95e4:	f9000401 	str	x1, [x0, #8]
    95e8:	f103f83f 	cmp	x1, #0xfe
    95ec:	54ff7221 	b.ne	8430 <fwp_hof0.constprop.0+0x670>  // b.any
    95f0:	aa1703e0 	mov	x0, x23
    95f4:	97ffebdf 	bl	4570 <fwp_rc_forget_slot>
    95f8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    95fc:	390002e0 	strb	w0, [x23]
    9600:	17fffb8c 	b	8430 <fwp_hof0.constprop.0+0x670>
    9604:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x120>
    9608:	9137a000 	add	x0, x0, #0xde8
    960c:	97ffe7dd 	bl	3580 <fwp_trap>
    9610:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9614:	91150281 	add	x1, x20, #0x540
    9618:	ca402400 	eor	x0, x0, x0, lsr #9
    961c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9620:	f94a2401 	ldr	x1, [x0, #5192]
    9624:	b5000081 	cbnz	x1, 9634 <fwp_hof0.constprop.0+0x1874>
    9628:	17fffff7 	b	9604 <fwp_hof0.constprop.0+0x1844>
    962c:	f9400821 	ldr	x1, [x1, #16]
    9630:	b4fffea1 	cbz	x1, 9604 <fwp_hof0.constprop.0+0x1844>
    9634:	f9400020 	ldr	x0, [x1]
    9638:	eb17001f 	cmp	x0, x23
    963c:	54ffff81 	b.ne	962c <fwp_hof0.constprop.0+0x186c>  // b.any
    9640:	f9400420 	ldr	x0, [x1, #8]
    9644:	d1000400 	sub	x0, x0, #0x1
    9648:	f9000420 	str	x0, [x1, #8]
    964c:	f103f81f 	cmp	x0, #0xfe
    9650:	54ffbe01 	b.ne	8e10 <fwp_hof0.constprop.0+0x1050>  // b.any
    9654:	aa1703e0 	mov	x0, x23
    9658:	97ffebc6 	bl	4570 <fwp_rc_forget_slot>
    965c:	91150280 	add	x0, x20, #0x540
    9660:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9664:	390002e1 	strb	w1, [x23]
    9668:	f949ec02 	ldr	x2, [x0, #5080]
    966c:	f949d801 	ldr	x1, [x0, #5040]
    9670:	d370bc42 	lsl	x2, x2, #16
    9674:	17fffd9b 	b	8ce0 <fwp_hof0.constprop.0+0xf20>
    9678:	ca534660 	eor	x0, x19, x19, lsr #17
    967c:	91150281 	add	x1, x20, #0x540
    9680:	ca402400 	eor	x0, x0, x0, lsr #9
    9684:	8b200c20 	add	x0, x1, w0, uxtb #3
    9688:	f94a2400 	ldr	x0, [x0, #5192]
    968c:	b5000080 	cbnz	x0, 969c <fwp_hof0.constprop.0+0x18dc>
    9690:	17ffffdd 	b	9604 <fwp_hof0.constprop.0+0x1844>
    9694:	f9400800 	ldr	x0, [x0, #16]
    9698:	b4fffb60 	cbz	x0, 9604 <fwp_hof0.constprop.0+0x1844>
    969c:	f9400001 	ldr	x1, [x0]
    96a0:	eb01027f 	cmp	x19, x1
    96a4:	54ffff81 	b.ne	9694 <fwp_hof0.constprop.0+0x18d4>  // b.any
    96a8:	f9400401 	ldr	x1, [x0, #8]
    96ac:	d1000421 	sub	x1, x1, #0x1
    96b0:	f9000401 	str	x1, [x0, #8]
    96b4:	f103f83f 	cmp	x1, #0xfe
    96b8:	54ffb541 	b.ne	8d60 <fwp_hof0.constprop.0+0xfa0>  // b.any
    96bc:	aa1303e0 	mov	x0, x19
    96c0:	97ffebac 	bl	4570 <fwp_rc_forget_slot>
    96c4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    96c8:	39000260 	strb	w0, [x19]
    96cc:	17fffda5 	b	8d60 <fwp_hof0.constprop.0+0xfa0>
    96d0:	72003c5f 	tst	w2, #0xffff
    96d4:	54ffd641 	b.ne	919c <fwp_hof0.constprop.0+0x13dc>  // b.any
    96d8:	394002a0 	ldrb	w0, [x21]
    96dc:	7103fc1f 	cmp	w0, #0xff
    96e0:	54ffd5a1 	b.ne	9194 <fwp_hof0.constprop.0+0x13d4>  // b.any
    96e4:	aa1503e0 	mov	x0, x21
    96e8:	97ffeba2 	bl	4570 <fwp_rc_forget_slot>
    96ec:	17fffeaa 	b	9194 <fwp_hof0.constprop.0+0x13d4>
    96f0:	72003c5f 	tst	w2, #0xffff
    96f4:	54ffdae1 	b.ne	9250 <fwp_hof0.constprop.0+0x1490>  // b.any
    96f8:	17fffece 	b	9230 <fwp_hof0.constprop.0+0x1470>
    96fc:	d2800018 	mov	x24, #0x0                   	// #0
    9700:	d280001c 	mov	x28, #0x0                   	// #0
    9704:	17fffd4f 	b	8c40 <fwp_hof0.constprop.0+0xe80>
    9708:	97ffeb53 	bl	4454 <fwp_rc_wide_dup>
    970c:	17fffa1c 	b	7f7c <fwp_hof0.constprop.0+0x1bc>
    9710:	ca534660 	eor	x0, x19, x19, lsr #17
    9714:	91150281 	add	x1, x20, #0x540
    9718:	ca402400 	eor	x0, x0, x0, lsr #9
    971c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9720:	f94a2400 	ldr	x0, [x0, #5192]
    9724:	b5000080 	cbnz	x0, 9734 <fwp_hof0.constprop.0+0x1974>
    9728:	17ffffb7 	b	9604 <fwp_hof0.constprop.0+0x1844>
    972c:	f9400800 	ldr	x0, [x0, #16]
    9730:	b4fff6a0 	cbz	x0, 9604 <fwp_hof0.constprop.0+0x1844>
    9734:	f9400001 	ldr	x1, [x0]
    9738:	eb01027f 	cmp	x19, x1
    973c:	54ffff81 	b.ne	972c <fwp_hof0.constprop.0+0x196c>  // b.any
    9740:	f9400401 	ldr	x1, [x0, #8]
    9744:	d1000421 	sub	x1, x1, #0x1
    9748:	f9000401 	str	x1, [x0, #8]
    974c:	f103f83f 	cmp	x1, #0xfe
    9750:	54ff4581 	b.ne	8000 <fwp_hof0.constprop.0+0x240>  // b.any
    9754:	aa1303e0 	mov	x0, x19
    9758:	97ffeb86 	bl	4570 <fwp_rc_forget_slot>
    975c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9760:	39000260 	strb	w0, [x19]
    9764:	17fffa27 	b	8000 <fwp_hof0.constprop.0+0x240>
    9768:	d2800017 	mov	x23, #0x0                   	// #0
    976c:	17fffcc0 	b	8a6c <fwp_hof0.constprop.0+0xcac>
    9770:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x120>
    9774:	9138c000 	add	x0, x0, #0xe30
    9778:	97ffe782 	bl	3580 <fwp_trap>
    977c:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x120>
    9780:	913b2000 	add	x0, x0, #0xec8
    9784:	97ffe77f 	bl	3580 <fwp_trap>
    9788:	97ffeb33 	bl	4454 <fwp_rc_wide_dup>
    978c:	91150280 	add	x0, x20, #0x540
    9790:	f949ec03 	ldr	x3, [x0, #5080]
    9794:	f949d801 	ldr	x1, [x0, #5040]
    9798:	d370bc63 	lsl	x3, x3, #16
    979c:	17fff9ca 	b	7ec4 <fwp_hof0.constprop.0+0x104>
    97a0:	ca5546a0 	eor	x0, x21, x21, lsr #17
    97a4:	91150281 	add	x1, x20, #0x540
    97a8:	ca402400 	eor	x0, x0, x0, lsr #9
    97ac:	8b200c20 	add	x0, x1, w0, uxtb #3
    97b0:	f94a2400 	ldr	x0, [x0, #5192]
    97b4:	b5000080 	cbnz	x0, 97c4 <fwp_hof0.constprop.0+0x1a04>
    97b8:	17ffff93 	b	9604 <fwp_hof0.constprop.0+0x1844>
    97bc:	f9400800 	ldr	x0, [x0, #16]
    97c0:	b4fff220 	cbz	x0, 9604 <fwp_hof0.constprop.0+0x1844>
    97c4:	f9400001 	ldr	x1, [x0]
    97c8:	eb0102bf 	cmp	x21, x1
    97cc:	54ffff81 	b.ne	97bc <fwp_hof0.constprop.0+0x19fc>  // b.any
    97d0:	f9400401 	ldr	x1, [x0, #8]
    97d4:	d1000421 	sub	x1, x1, #0x1
    97d8:	f9000401 	str	x1, [x0, #8]
    97dc:	f103f83f 	cmp	x1, #0xfe
    97e0:	54ffd381 	b.ne	9250 <fwp_hof0.constprop.0+0x1490>  // b.any
    97e4:	aa1503e0 	mov	x0, x21
    97e8:	97ffeb62 	bl	4570 <fwp_rc_forget_slot>
    97ec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    97f0:	390002a0 	strb	w0, [x21]
    97f4:	17fffe97 	b	9250 <fwp_hof0.constprop.0+0x1490>
    97f8:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    97fc:	91022000 	add	x0, x0, #0x88
    9800:	97ffe760 	bl	3580 <fwp_trap>
    9804:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x120>
    9808:	913ca000 	add	x0, x0, #0xf28
    980c:	97ffe75d 	bl	3580 <fwp_trap>
    9810:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    9814:	91032000 	add	x0, x0, #0xc8
    9818:	97ffe75a 	bl	3580 <fwp_trap>
    981c:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    9820:	91012000 	add	x0, x0, #0x48
    9824:	97ffe757 	bl	3580 <fwp_trap>
    9828:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    982c:	9100a000 	add	x0, x0, #0x28
    9830:	97ffe754 	bl	3580 <fwp_trap>
    9834:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x120>
    9838:	9139e000 	add	x0, x0, #0xe78
    983c:	97ffe751 	bl	3580 <fwp_trap>
    9840:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    9844:	9102c000 	add	x0, x0, #0xb0
    9848:	97ffe74e 	bl	3580 <fwp_trap>
    984c:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    9850:	9101e000 	add	x0, x0, #0x78
    9854:	97ffe74b 	bl	3580 <fwp_trap>
    9858:	52800020 	mov	w0, #0x1                   	// #1
    985c:	17fffbe0 	b	87dc <fwp_hof0.constprop.0+0xa1c>
    9860:	a90f53f3 	stp	x19, x20, [sp, #240]
    9864:	a9105bf5 	stp	x21, x22, [sp, #256]
    9868:	a91163f7 	stp	x23, x24, [sp, #272]
    986c:	a9126bf9 	stp	x25, x26, [sp, #288]
    9870:	a91373fb 	stp	x27, x28, [sp, #304]
    9874:	fd00a3e8 	str	d8, [sp, #320]
    9878:	97ffe402 	bl	2880 <__stack_chk_fail@plt>
    987c:	97ffe481 	bl	2a80 <fwp_trap_overflow.constprop.0>
    9880:	97ffe414 	bl	28d0 <abort@plt>

0000000000009884 <f0>:
    9884:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9888:	910003fd 	mov	x29, sp
    988c:	a90153f3 	stp	x19, x20, [sp, #16]
    9890:	a9025bf5 	stp	x21, x22, [sp, #32]
    9894:	a90363f7 	stp	x23, x24, [sp, #48]
    9898:	a9046bf9 	stp	x25, x26, [sp, #64]
    989c:	a90573fb 	stp	x27, x28, [sp, #80]
    98a0:	d12183ff 	sub	sp, sp, #0x860
    98a4:	f90203ff 	str	xzr, [sp, #1024]
    98a8:	f00000a0 	adrp	x0, 20000 <__data_start>
    98ac:	9100c005 	add	x5, x0, #0x30
    98b0:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    98b4:	f947f400 	ldr	x0, [x0, #4072]
    98b8:	90000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    98bc:	f94160a6 	ldr	x6, [x5, #704]
    98c0:	f9400001 	ldr	x1, [x0]
    98c4:	f9042fe1 	str	x1, [sp, #2136]
    98c8:	d2800001 	mov	x1, #0x0                   	// #0
    98cc:	91150298 	add	x24, x20, #0x540
    98d0:	912123f6 	add	x22, sp, #0x848
    98d4:	910023e0 	add	x0, sp, #0x8
    98d8:	910083e2 	add	x2, sp, #0x20
    98dc:	90ffffe1 	adrp	x1, 5000 <fwp_p_ad_push+0x15c>
    98e0:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    98e4:	911cc021 	add	x1, x1, #0x730
    98e8:	913d4084 	add	x4, x4, #0xf50
    98ec:	d2800013 	mov	x19, #0x0                   	// #0
    98f0:	d2800119 	mov	x25, #0x8                   	// #8
    98f4:	d2800015 	mov	x21, #0x0                   	// #0
    98f8:	52800037 	mov	w23, #0x1                   	// #1
    98fc:	a90093e6 	stp	x6, x4, [sp, #8]
    9900:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9904:	a90307ff 	stp	xzr, x1, [sp, #48]
    9908:	f90160a0 	str	x0, [x5, #704]
    990c:	d503201f 	nop
    9910:	f100073a 	subs	x26, x25, #0x1
    9914:	aa1603e1 	mov	x1, x22
    9918:	da1f02bc 	sbc	x28, x21, xzr
    991c:	52800020 	mov	w0, #0x1                   	// #1
    9920:	f90017fa 	str	x26, [sp, #40]
    9924:	aa1a03f9 	mov	x25, x26
    9928:	f90427fa 	str	x26, [sp, #2120]
    992c:	aa1c03f5 	mov	x21, x28
    9930:	f9042bf3 	str	x19, [sp, #2128]
    9934:	97ffed14 	bl	4d84 <fwp_data.part.0.constprop.0>
    9938:	f949db02 	ldr	x2, [x24, #5040]
    993c:	aa0003f3 	mov	x19, x0
    9940:	f949ef00 	ldr	x0, [x24, #5080]
    9944:	cb020262 	sub	x2, x19, x2
    9948:	eb00405f 	cmp	x2, x0, lsl #16
    994c:	54000302 	b.cs	99ac <f0+0x128>  // b.hs, b.nlast
    9950:	d350fc40 	lsr	x0, x2, #16
    9954:	f949ff04 	ldr	x4, [x24, #5112]
    9958:	8b000800 	add	x0, x0, x0, lsl #2
    995c:	d37df001 	lsl	x1, x0, #3
    9960:	8b010080 	add	x0, x4, x1
    9964:	f940101b 	ldr	x27, [x0, #32]
    9968:	b400023b 	cbz	x27, 99ac <f0+0x128>
    996c:	38616881 	ldrb	w1, [x4, x1]
    9970:	7100083f 	cmp	w1, #0x2
    9974:	54010da0 	b.eq	bb28 <f0+0x22a4>  // b.none
    9978:	7100043f 	cmp	w1, #0x1
    997c:	54000181 	b.ne	99ac <f0+0x128>  // b.any
    9980:	29430001 	ldp	w1, w0, [x0, #24]
    9984:	92403c42 	and	x2, x2, #0xffff
    9988:	9b017c42 	mul	x2, x2, x1
    998c:	d360fc42 	lsr	x2, x2, #32
    9990:	eb00005f 	cmp	x2, x0
    9994:	540000c2 	b.cs	99ac <f0+0x128>  // b.hs, b.nlast
    9998:	8b02037b 	add	x27, x27, x2
    999c:	39400360 	ldrb	w0, [x27]
    99a0:	7103fc1f 	cmp	w0, #0xff
    99a4:	54010bc0 	b.eq	bb1c <f0+0x2298>  // b.none
    99a8:	39000377 	strb	w23, [x27]
    99ac:	f90013f3 	str	x19, [sp, #32]
    99b0:	aa1c035a 	orr	x26, x26, x28
    99b4:	b5fffafa 	cbnz	x26, 9910 <f0+0x8c>
    99b8:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    99bc:	910103e1 	add	x1, sp, #0x40
    99c0:	f94007e2 	ldr	x2, [sp, #8]
    99c4:	3dc20800 	ldr	q0, [x0, #2080]
    99c8:	f00000a0 	adrp	x0, 20000 <__data_start>
    99cc:	9100c018 	add	x24, x0, #0x30
    99d0:	52800020 	mov	w0, #0x1                   	// #1
    99d4:	3d8013e0 	str	q0, [sp, #64]
    99d8:	f9016302 	str	x2, [x24, #704]
    99dc:	97ffecea 	bl	4d84 <fwp_data.part.0.constprop.0>
    99e0:	91150283 	add	x3, x20, #0x540
    99e4:	aa0003f5 	mov	x21, x0
    99e8:	f949d861 	ldr	x1, [x3, #5040]
    99ec:	f949ec60 	ldr	x0, [x3, #5080]
    99f0:	cb0102a1 	sub	x1, x21, x1
    99f4:	eb00403f 	cmp	x1, x0, lsl #16
    99f8:	54000322 	b.cs	9a5c <f0+0x1d8>  // b.hs, b.nlast
    99fc:	d350fc22 	lsr	x2, x1, #16
    9a00:	f949fc63 	ldr	x3, [x3, #5112]
    9a04:	8b020842 	add	x2, x2, x2, lsl #2
    9a08:	d37df042 	lsl	x2, x2, #3
    9a0c:	8b020060 	add	x0, x3, x2
    9a10:	f9401017 	ldr	x23, [x0, #32]
    9a14:	b4000257 	cbz	x23, 9a5c <f0+0x1d8>
    9a18:	38626862 	ldrb	w2, [x3, x2]
    9a1c:	7100085f 	cmp	w2, #0x2
    9a20:	54010c60 	b.eq	bbac <f0+0x2328>  // b.none
    9a24:	7100045f 	cmp	w2, #0x1
    9a28:	540001a1 	b.ne	9a5c <f0+0x1d8>  // b.any
    9a2c:	29430002 	ldp	w2, w0, [x0, #24]
    9a30:	92403c21 	and	x1, x1, #0xffff
    9a34:	9b027c21 	mul	x1, x1, x2
    9a38:	d360fc21 	lsr	x1, x1, #32
    9a3c:	eb00003f 	cmp	x1, x0
    9a40:	540000e2 	b.cs	9a5c <f0+0x1d8>  // b.hs, b.nlast
    9a44:	8b0102f7 	add	x23, x23, x1
    9a48:	394002e0 	ldrb	w0, [x23]
    9a4c:	7103fc1f 	cmp	w0, #0xff
    9a50:	54011620 	b.eq	bd14 <f0+0x2490>  // b.none
    9a54:	52800020 	mov	w0, #0x1                   	// #1
    9a58:	390002e0 	strb	w0, [x23]
    9a5c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9a60:	910163e1 	add	x1, sp, #0x58
    9a64:	52800020 	mov	w0, #0x1                   	// #1
    9a68:	a905d7e2 	stp	x2, x21, [sp, #88]
    9a6c:	97ffecc6 	bl	4d84 <fwp_data.part.0.constprop.0>
    9a70:	91150283 	add	x3, x20, #0x540
    9a74:	aa0003f5 	mov	x21, x0
    9a78:	f949d861 	ldr	x1, [x3, #5040]
    9a7c:	f949ec60 	ldr	x0, [x3, #5080]
    9a80:	cb0102a1 	sub	x1, x21, x1
    9a84:	eb00403f 	cmp	x1, x0, lsl #16
    9a88:	54000322 	b.cs	9aec <f0+0x268>  // b.hs, b.nlast
    9a8c:	d350fc22 	lsr	x2, x1, #16
    9a90:	f949fc63 	ldr	x3, [x3, #5112]
    9a94:	8b020842 	add	x2, x2, x2, lsl #2
    9a98:	d37df042 	lsl	x2, x2, #3
    9a9c:	8b020060 	add	x0, x3, x2
    9aa0:	f9401017 	ldr	x23, [x0, #32]
    9aa4:	b4000257 	cbz	x23, 9aec <f0+0x268>
    9aa8:	38626862 	ldrb	w2, [x3, x2]
    9aac:	7100085f 	cmp	w2, #0x2
    9ab0:	54010780 	b.eq	bba0 <f0+0x231c>  // b.none
    9ab4:	7100045f 	cmp	w2, #0x1
    9ab8:	540001a1 	b.ne	9aec <f0+0x268>  // b.any
    9abc:	29430002 	ldp	w2, w0, [x0, #24]
    9ac0:	92403c21 	and	x1, x1, #0xffff
    9ac4:	9b027c21 	mul	x1, x1, x2
    9ac8:	d360fc21 	lsr	x1, x1, #32
    9acc:	eb00003f 	cmp	x1, x0
    9ad0:	540000e2 	b.cs	9aec <f0+0x268>  // b.hs, b.nlast
    9ad4:	8b0102f7 	add	x23, x23, x1
    9ad8:	394002e0 	ldrb	w0, [x23]
    9adc:	7103fc1f 	cmp	w0, #0xff
    9ae0:	54011200 	b.eq	bd20 <f0+0x249c>  // b.none
    9ae4:	52800020 	mov	w0, #0x1                   	// #1
    9ae8:	390002e0 	strb	w0, [x23]
    9aec:	9101a3e1 	add	x1, sp, #0x68
    9af0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9af4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9af8:	52800020 	mov	w0, #0x1                   	// #1
    9afc:	a906d7f7 	stp	x23, x21, [sp, #104]
    9b00:	97ffeca1 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b04:	97ffee04 	bl	5314 <fwp_rc_fresh>
    9b08:	aa0003e2 	mov	x2, x0
    9b0c:	9101e3e1 	add	x1, sp, #0x78
    9b10:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9b14:	52800020 	mov	w0, #0x1                   	// #1
    9b18:	a9078bf5 	stp	x21, x2, [sp, #120]
    9b1c:	97ffec9a 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b20:	97ffedfd 	bl	5314 <fwp_rc_fresh>
    9b24:	aa0003e2 	mov	x2, x0
    9b28:	910223e1 	add	x1, sp, #0x88
    9b2c:	52800020 	mov	w0, #0x1                   	// #1
    9b30:	a9088bf7 	stp	x23, x2, [sp, #136]
    9b34:	97ffec94 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b38:	97ffedf7 	bl	5314 <fwp_rc_fresh>
    9b3c:	aa0003e2 	mov	x2, x0
    9b40:	910263e1 	add	x1, sp, #0x98
    9b44:	52800020 	mov	w0, #0x1                   	// #1
    9b48:	a9098bf5 	stp	x21, x2, [sp, #152]
    9b4c:	97ffec8e 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b50:	97ffedf1 	bl	5314 <fwp_rc_fresh>
    9b54:	aa0003e2 	mov	x2, x0
    9b58:	9102a3e1 	add	x1, sp, #0xa8
    9b5c:	52800020 	mov	w0, #0x1                   	// #1
    9b60:	a90a8bf7 	stp	x23, x2, [sp, #168]
    9b64:	97ffec88 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b68:	97ffedeb 	bl	5314 <fwp_rc_fresh>
    9b6c:	aa0003e2 	mov	x2, x0
    9b70:	9102e3e1 	add	x1, sp, #0xb8
    9b74:	52800020 	mov	w0, #0x1                   	// #1
    9b78:	a90b8bf5 	stp	x21, x2, [sp, #184]
    9b7c:	97ffec82 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b80:	97ffede5 	bl	5314 <fwp_rc_fresh>
    9b84:	aa0003e2 	mov	x2, x0
    9b88:	910323e1 	add	x1, sp, #0xc8
    9b8c:	52800020 	mov	w0, #0x1                   	// #1
    9b90:	a90c8bf7 	stp	x23, x2, [sp, #200]
    9b94:	97ffec7c 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b98:	97ffeddf 	bl	5314 <fwp_rc_fresh>
    9b9c:	aa0003e2 	mov	x2, x0
    9ba0:	910363e1 	add	x1, sp, #0xd8
    9ba4:	52800020 	mov	w0, #0x1                   	// #1
    9ba8:	a90d8bf5 	stp	x21, x2, [sp, #216]
    9bac:	97ffec76 	bl	4d84 <fwp_data.part.0.constprop.0>
    9bb0:	97ffedd9 	bl	5314 <fwp_rc_fresh>
    9bb4:	aa0003e2 	mov	x2, x0
    9bb8:	9103a3e1 	add	x1, sp, #0xe8
    9bbc:	52800020 	mov	w0, #0x1                   	// #1
    9bc0:	a90e8bf7 	stp	x23, x2, [sp, #232]
    9bc4:	97ffec70 	bl	4d84 <fwp_data.part.0.constprop.0>
    9bc8:	97ffedd3 	bl	5314 <fwp_rc_fresh>
    9bcc:	aa0003e2 	mov	x2, x0
    9bd0:	9103e3e1 	add	x1, sp, #0xf8
    9bd4:	52800020 	mov	w0, #0x1                   	// #1
    9bd8:	a90f8bf5 	stp	x21, x2, [sp, #248]
    9bdc:	97ffec6a 	bl	4d84 <fwp_data.part.0.constprop.0>
    9be0:	91150283 	add	x3, x20, #0x540
    9be4:	aa0003f5 	mov	x21, x0
    9be8:	f949d861 	ldr	x1, [x3, #5040]
    9bec:	f949ec60 	ldr	x0, [x3, #5080]
    9bf0:	cb0102a1 	sub	x1, x21, x1
    9bf4:	eb00403f 	cmp	x1, x0, lsl #16
    9bf8:	54000322 	b.cs	9c5c <f0+0x3d8>  // b.hs, b.nlast
    9bfc:	d350fc22 	lsr	x2, x1, #16
    9c00:	f949fc63 	ldr	x3, [x3, #5112]
    9c04:	8b020842 	add	x2, x2, x2, lsl #2
    9c08:	d37df042 	lsl	x2, x2, #3
    9c0c:	8b020060 	add	x0, x3, x2
    9c10:	f9401017 	ldr	x23, [x0, #32]
    9c14:	b4000257 	cbz	x23, 9c5c <f0+0x3d8>
    9c18:	38626862 	ldrb	w2, [x3, x2]
    9c1c:	7100085f 	cmp	w2, #0x2
    9c20:	5400fba0 	b.eq	bb94 <f0+0x2310>  // b.none
    9c24:	7100045f 	cmp	w2, #0x1
    9c28:	540001a1 	b.ne	9c5c <f0+0x3d8>  // b.any
    9c2c:	29430002 	ldp	w2, w0, [x0, #24]
    9c30:	92403c21 	and	x1, x1, #0xffff
    9c34:	9b027c21 	mul	x1, x1, x2
    9c38:	d360fc21 	lsr	x1, x1, #32
    9c3c:	eb00003f 	cmp	x1, x0
    9c40:	540000e2 	b.cs	9c5c <f0+0x3d8>  // b.hs, b.nlast
    9c44:	8b0102f7 	add	x23, x23, x1
    9c48:	394002e0 	ldrb	w0, [x23]
    9c4c:	7103fc1f 	cmp	w0, #0xff
    9c50:	540106e0 	b.eq	bd2c <f0+0x24a8>  // b.none
    9c54:	52800020 	mov	w0, #0x1                   	// #1
    9c58:	390002e0 	strb	w0, [x23]
    9c5c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9c60:	910423e1 	add	x1, sp, #0x108
    9c64:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9c68:	52800020 	mov	w0, #0x1                   	// #1
    9c6c:	a910d7e2 	stp	x2, x21, [sp, #264]
    9c70:	97ffec45 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c74:	97ffeda8 	bl	5314 <fwp_rc_fresh>
    9c78:	aa0003e2 	mov	x2, x0
    9c7c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9c80:	910463e1 	add	x1, sp, #0x118
    9c84:	52800020 	mov	w0, #0x1                   	// #1
    9c88:	a9118be3 	stp	x3, x2, [sp, #280]
    9c8c:	97ffec3e 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c90:	91150283 	add	x3, x20, #0x540
    9c94:	aa0003f5 	mov	x21, x0
    9c98:	f949d861 	ldr	x1, [x3, #5040]
    9c9c:	f949ec60 	ldr	x0, [x3, #5080]
    9ca0:	cb0102a1 	sub	x1, x21, x1
    9ca4:	eb00403f 	cmp	x1, x0, lsl #16
    9ca8:	54000322 	b.cs	9d0c <f0+0x488>  // b.hs, b.nlast
    9cac:	d350fc22 	lsr	x2, x1, #16
    9cb0:	f949fc63 	ldr	x3, [x3, #5112]
    9cb4:	8b020842 	add	x2, x2, x2, lsl #2
    9cb8:	d37df042 	lsl	x2, x2, #3
    9cbc:	8b020060 	add	x0, x3, x2
    9cc0:	f9401017 	ldr	x23, [x0, #32]
    9cc4:	b4000257 	cbz	x23, 9d0c <f0+0x488>
    9cc8:	38626862 	ldrb	w2, [x3, x2]
    9ccc:	7100085f 	cmp	w2, #0x2
    9cd0:	5400f860 	b.eq	bbdc <f0+0x2358>  // b.none
    9cd4:	7100045f 	cmp	w2, #0x1
    9cd8:	540001a1 	b.ne	9d0c <f0+0x488>  // b.any
    9cdc:	29430002 	ldp	w2, w0, [x0, #24]
    9ce0:	92403c21 	and	x1, x1, #0xffff
    9ce4:	9b027c21 	mul	x1, x1, x2
    9ce8:	d360fc21 	lsr	x1, x1, #32
    9cec:	eb00003f 	cmp	x1, x0
    9cf0:	540000e2 	b.cs	9d0c <f0+0x488>  // b.hs, b.nlast
    9cf4:	8b0102f7 	add	x23, x23, x1
    9cf8:	394002e0 	ldrb	w0, [x23]
    9cfc:	7103fc1f 	cmp	w0, #0xff
    9d00:	540101c0 	b.eq	bd38 <f0+0x24b4>  // b.none
    9d04:	52800020 	mov	w0, #0x1                   	// #1
    9d08:	390002e0 	strb	w0, [x23]
    9d0c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9d10:	9104a3e1 	add	x1, sp, #0x128
    9d14:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9d18:	52800020 	mov	w0, #0x1                   	// #1
    9d1c:	a912d7e2 	stp	x2, x21, [sp, #296]
    9d20:	97ffec19 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d24:	91150283 	add	x3, x20, #0x540
    9d28:	aa0003f5 	mov	x21, x0
    9d2c:	f949d861 	ldr	x1, [x3, #5040]
    9d30:	f949ec60 	ldr	x0, [x3, #5080]
    9d34:	cb0102a1 	sub	x1, x21, x1
    9d38:	eb00403f 	cmp	x1, x0, lsl #16
    9d3c:	54000322 	b.cs	9da0 <f0+0x51c>  // b.hs, b.nlast
    9d40:	d350fc22 	lsr	x2, x1, #16
    9d44:	f949fc63 	ldr	x3, [x3, #5112]
    9d48:	8b020842 	add	x2, x2, x2, lsl #2
    9d4c:	d37df042 	lsl	x2, x2, #3
    9d50:	8b020060 	add	x0, x3, x2
    9d54:	f9401017 	ldr	x23, [x0, #32]
    9d58:	b4000257 	cbz	x23, 9da0 <f0+0x51c>
    9d5c:	38626862 	ldrb	w2, [x3, x2]
    9d60:	7100085f 	cmp	w2, #0x2
    9d64:	5400f360 	b.eq	bbd0 <f0+0x234c>  // b.none
    9d68:	7100045f 	cmp	w2, #0x1
    9d6c:	540001a1 	b.ne	9da0 <f0+0x51c>  // b.any
    9d70:	29430002 	ldp	w2, w0, [x0, #24]
    9d74:	92403c21 	and	x1, x1, #0xffff
    9d78:	9b027c21 	mul	x1, x1, x2
    9d7c:	d360fc21 	lsr	x1, x1, #32
    9d80:	eb00003f 	cmp	x1, x0
    9d84:	540000e2 	b.cs	9da0 <f0+0x51c>  // b.hs, b.nlast
    9d88:	8b0102f7 	add	x23, x23, x1
    9d8c:	394002e0 	ldrb	w0, [x23]
    9d90:	7103fc1f 	cmp	w0, #0xff
    9d94:	5400fd80 	b.eq	bd44 <f0+0x24c0>  // b.none
    9d98:	52800020 	mov	w0, #0x1                   	// #1
    9d9c:	390002e0 	strb	w0, [x23]
    9da0:	9104e3e1 	add	x1, sp, #0x138
    9da4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    9da8:	52800020 	mov	w0, #0x1                   	// #1
    9dac:	a913d7f7 	stp	x23, x21, [sp, #312]
    9db0:	97ffebf5 	bl	4d84 <fwp_data.part.0.constprop.0>
    9db4:	97ffed58 	bl	5314 <fwp_rc_fresh>
    9db8:	aa0003e2 	mov	x2, x0
    9dbc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9dc0:	910523e1 	add	x1, sp, #0x148
    9dc4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9dc8:	52800020 	mov	w0, #0x1                   	// #1
    9dcc:	a9148be3 	stp	x3, x2, [sp, #328]
    9dd0:	97ffebed 	bl	4d84 <fwp_data.part.0.constprop.0>
    9dd4:	97ffed50 	bl	5314 <fwp_rc_fresh>
    9dd8:	aa0003e2 	mov	x2, x0
    9ddc:	910563e1 	add	x1, sp, #0x158
    9de0:	52800020 	mov	w0, #0x1                   	// #1
    9de4:	a9158bf7 	stp	x23, x2, [sp, #344]
    9de8:	97ffebe7 	bl	4d84 <fwp_data.part.0.constprop.0>
    9dec:	91150283 	add	x3, x20, #0x540
    9df0:	aa0003f5 	mov	x21, x0
    9df4:	f949d861 	ldr	x1, [x3, #5040]
    9df8:	f949ec60 	ldr	x0, [x3, #5080]
    9dfc:	cb0102a1 	sub	x1, x21, x1
    9e00:	eb00403f 	cmp	x1, x0, lsl #16
    9e04:	54000322 	b.cs	9e68 <f0+0x5e4>  // b.hs, b.nlast
    9e08:	d350fc22 	lsr	x2, x1, #16
    9e0c:	f949fc63 	ldr	x3, [x3, #5112]
    9e10:	8b020842 	add	x2, x2, x2, lsl #2
    9e14:	d37df042 	lsl	x2, x2, #3
    9e18:	8b020060 	add	x0, x3, x2
    9e1c:	f9401017 	ldr	x23, [x0, #32]
    9e20:	b4000257 	cbz	x23, 9e68 <f0+0x5e4>
    9e24:	38626862 	ldrb	w2, [x3, x2]
    9e28:	7100085f 	cmp	w2, #0x2
    9e2c:	5400ecc0 	b.eq	bbc4 <f0+0x2340>  // b.none
    9e30:	7100045f 	cmp	w2, #0x1
    9e34:	540001a1 	b.ne	9e68 <f0+0x5e4>  // b.any
    9e38:	29430002 	ldp	w2, w0, [x0, #24]
    9e3c:	92403c21 	and	x1, x1, #0xffff
    9e40:	9b027c21 	mul	x1, x1, x2
    9e44:	d360fc21 	lsr	x1, x1, #32
    9e48:	eb00003f 	cmp	x1, x0
    9e4c:	540000e2 	b.cs	9e68 <f0+0x5e4>  // b.hs, b.nlast
    9e50:	8b0102f7 	add	x23, x23, x1
    9e54:	394002e0 	ldrb	w0, [x23]
    9e58:	7103fc1f 	cmp	w0, #0xff
    9e5c:	5400f7a0 	b.eq	bd50 <f0+0x24cc>  // b.none
    9e60:	52800020 	mov	w0, #0x1                   	// #1
    9e64:	390002e0 	strb	w0, [x23]
    9e68:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9e6c:	9105a3e1 	add	x1, sp, #0x168
    9e70:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9e74:	52800020 	mov	w0, #0x1                   	// #1
    9e78:	a916d7e2 	stp	x2, x21, [sp, #360]
    9e7c:	97ffebc2 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e80:	97ffed25 	bl	5314 <fwp_rc_fresh>
    9e84:	aa0003e2 	mov	x2, x0
    9e88:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9e8c:	9105e3e1 	add	x1, sp, #0x178
    9e90:	52800020 	mov	w0, #0x1                   	// #1
    9e94:	a9178be3 	stp	x3, x2, [sp, #376]
    9e98:	97ffebbb 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e9c:	91150283 	add	x3, x20, #0x540
    9ea0:	aa0003f5 	mov	x21, x0
    9ea4:	f949d861 	ldr	x1, [x3, #5040]
    9ea8:	f949ec60 	ldr	x0, [x3, #5080]
    9eac:	cb0102a1 	sub	x1, x21, x1
    9eb0:	eb00403f 	cmp	x1, x0, lsl #16
    9eb4:	54000322 	b.cs	9f18 <f0+0x694>  // b.hs, b.nlast
    9eb8:	d350fc22 	lsr	x2, x1, #16
    9ebc:	f949fc63 	ldr	x3, [x3, #5112]
    9ec0:	8b020842 	add	x2, x2, x2, lsl #2
    9ec4:	d37df042 	lsl	x2, x2, #3
    9ec8:	8b020060 	add	x0, x3, x2
    9ecc:	f9401017 	ldr	x23, [x0, #32]
    9ed0:	b4000257 	cbz	x23, 9f18 <f0+0x694>
    9ed4:	38626862 	ldrb	w2, [x3, x2]
    9ed8:	7100085f 	cmp	w2, #0x2
    9edc:	5400e6e0 	b.eq	bbb8 <f0+0x2334>  // b.none
    9ee0:	7100045f 	cmp	w2, #0x1
    9ee4:	540001a1 	b.ne	9f18 <f0+0x694>  // b.any
    9ee8:	29430002 	ldp	w2, w0, [x0, #24]
    9eec:	92403c21 	and	x1, x1, #0xffff
    9ef0:	9b027c21 	mul	x1, x1, x2
    9ef4:	d360fc21 	lsr	x1, x1, #32
    9ef8:	eb00003f 	cmp	x1, x0
    9efc:	540000e2 	b.cs	9f18 <f0+0x694>  // b.hs, b.nlast
    9f00:	8b0102f7 	add	x23, x23, x1
    9f04:	394002e0 	ldrb	w0, [x23]
    9f08:	7103fc1f 	cmp	w0, #0xff
    9f0c:	5400f280 	b.eq	bd5c <f0+0x24d8>  // b.none
    9f10:	52800020 	mov	w0, #0x1                   	// #1
    9f14:	390002e0 	strb	w0, [x23]
    9f18:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9f1c:	910623e1 	add	x1, sp, #0x188
    9f20:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9f24:	52800020 	mov	w0, #0x1                   	// #1
    9f28:	a918d7e2 	stp	x2, x21, [sp, #392]
    9f2c:	97ffeb96 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f30:	97ffecf9 	bl	5314 <fwp_rc_fresh>
    9f34:	aa0003e2 	mov	x2, x0
    9f38:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9f3c:	910663e1 	add	x1, sp, #0x198
    9f40:	52800020 	mov	w0, #0x1                   	// #1
    9f44:	a9198be3 	stp	x3, x2, [sp, #408]
    9f48:	97ffeb8f 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f4c:	91150283 	add	x3, x20, #0x540
    9f50:	aa0003f5 	mov	x21, x0
    9f54:	f949d861 	ldr	x1, [x3, #5040]
    9f58:	f949ec60 	ldr	x0, [x3, #5080]
    9f5c:	cb0102a1 	sub	x1, x21, x1
    9f60:	eb00403f 	cmp	x1, x0, lsl #16
    9f64:	54000322 	b.cs	9fc8 <f0+0x744>  // b.hs, b.nlast
    9f68:	d350fc22 	lsr	x2, x1, #16
    9f6c:	f949fc63 	ldr	x3, [x3, #5112]
    9f70:	8b020842 	add	x2, x2, x2, lsl #2
    9f74:	d37df042 	lsl	x2, x2, #3
    9f78:	8b020060 	add	x0, x3, x2
    9f7c:	f9401017 	ldr	x23, [x0, #32]
    9f80:	b4000257 	cbz	x23, 9fc8 <f0+0x744>
    9f84:	38626862 	ldrb	w2, [x3, x2]
    9f88:	7100085f 	cmp	w2, #0x2
    9f8c:	5400e580 	b.eq	bc3c <f0+0x23b8>  // b.none
    9f90:	7100045f 	cmp	w2, #0x1
    9f94:	540001a1 	b.ne	9fc8 <f0+0x744>  // b.any
    9f98:	29430002 	ldp	w2, w0, [x0, #24]
    9f9c:	92403c21 	and	x1, x1, #0xffff
    9fa0:	9b027c21 	mul	x1, x1, x2
    9fa4:	d360fc21 	lsr	x1, x1, #32
    9fa8:	eb00003f 	cmp	x1, x0
    9fac:	540000e2 	b.cs	9fc8 <f0+0x744>  // b.hs, b.nlast
    9fb0:	8b0102f7 	add	x23, x23, x1
    9fb4:	394002e0 	ldrb	w0, [x23]
    9fb8:	7103fc1f 	cmp	w0, #0xff
    9fbc:	5400ed60 	b.eq	bd68 <f0+0x24e4>  // b.none
    9fc0:	52800020 	mov	w0, #0x1                   	// #1
    9fc4:	390002e0 	strb	w0, [x23]
    9fc8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9fcc:	9106a3e1 	add	x1, sp, #0x1a8
    9fd0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9fd4:	52800020 	mov	w0, #0x1                   	// #1
    9fd8:	a91ad7e2 	stp	x2, x21, [sp, #424]
    9fdc:	97ffeb6a 	bl	4d84 <fwp_data.part.0.constprop.0>
    9fe0:	91150283 	add	x3, x20, #0x540
    9fe4:	aa0003f5 	mov	x21, x0
    9fe8:	f949d861 	ldr	x1, [x3, #5040]
    9fec:	f949ec60 	ldr	x0, [x3, #5080]
    9ff0:	cb0102a1 	sub	x1, x21, x1
    9ff4:	eb00403f 	cmp	x1, x0, lsl #16
    9ff8:	54000322 	b.cs	a05c <f0+0x7d8>  // b.hs, b.nlast
    9ffc:	d350fc22 	lsr	x2, x1, #16
    a000:	f949fc63 	ldr	x3, [x3, #5112]
    a004:	8b020842 	add	x2, x2, x2, lsl #2
    a008:	d37df042 	lsl	x2, x2, #3
    a00c:	8b020060 	add	x0, x3, x2
    a010:	f9401017 	ldr	x23, [x0, #32]
    a014:	b4000257 	cbz	x23, a05c <f0+0x7d8>
    a018:	38626862 	ldrb	w2, [x3, x2]
    a01c:	7100085f 	cmp	w2, #0x2
    a020:	5400e080 	b.eq	bc30 <f0+0x23ac>  // b.none
    a024:	7100045f 	cmp	w2, #0x1
    a028:	540001a1 	b.ne	a05c <f0+0x7d8>  // b.any
    a02c:	29430002 	ldp	w2, w0, [x0, #24]
    a030:	92403c21 	and	x1, x1, #0xffff
    a034:	9b027c21 	mul	x1, x1, x2
    a038:	d360fc21 	lsr	x1, x1, #32
    a03c:	eb00003f 	cmp	x1, x0
    a040:	540000e2 	b.cs	a05c <f0+0x7d8>  // b.hs, b.nlast
    a044:	8b0102f7 	add	x23, x23, x1
    a048:	394002e0 	ldrb	w0, [x23]
    a04c:	7103fc1f 	cmp	w0, #0xff
    a050:	5400e920 	b.eq	bd74 <f0+0x24f0>  // b.none
    a054:	52800020 	mov	w0, #0x1                   	// #1
    a058:	390002e0 	strb	w0, [x23]
    a05c:	9106e3e1 	add	x1, sp, #0x1b8
    a060:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a064:	52800020 	mov	w0, #0x1                   	// #1
    a068:	a91bd7f7 	stp	x23, x21, [sp, #440]
    a06c:	97ffeb46 	bl	4d84 <fwp_data.part.0.constprop.0>
    a070:	97ffeca9 	bl	5314 <fwp_rc_fresh>
    a074:	aa0003e2 	mov	x2, x0
    a078:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a07c:	910723e1 	add	x1, sp, #0x1c8
    a080:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a084:	52800020 	mov	w0, #0x1                   	// #1
    a088:	a91c8be3 	stp	x3, x2, [sp, #456]
    a08c:	97ffeb3e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a090:	97ffeca1 	bl	5314 <fwp_rc_fresh>
    a094:	aa0003e2 	mov	x2, x0
    a098:	910763e1 	add	x1, sp, #0x1d8
    a09c:	52800020 	mov	w0, #0x1                   	// #1
    a0a0:	a91d8bf7 	stp	x23, x2, [sp, #472]
    a0a4:	97ffeb38 	bl	4d84 <fwp_data.part.0.constprop.0>
    a0a8:	91150283 	add	x3, x20, #0x540
    a0ac:	aa0003f5 	mov	x21, x0
    a0b0:	f949d861 	ldr	x1, [x3, #5040]
    a0b4:	f949ec60 	ldr	x0, [x3, #5080]
    a0b8:	cb0102a1 	sub	x1, x21, x1
    a0bc:	eb00403f 	cmp	x1, x0, lsl #16
    a0c0:	54000322 	b.cs	a124 <f0+0x8a0>  // b.hs, b.nlast
    a0c4:	d350fc22 	lsr	x2, x1, #16
    a0c8:	f949fc63 	ldr	x3, [x3, #5112]
    a0cc:	8b020842 	add	x2, x2, x2, lsl #2
    a0d0:	d37df042 	lsl	x2, x2, #3
    a0d4:	8b020060 	add	x0, x3, x2
    a0d8:	f9401017 	ldr	x23, [x0, #32]
    a0dc:	b4000257 	cbz	x23, a124 <f0+0x8a0>
    a0e0:	38626862 	ldrb	w2, [x3, x2]
    a0e4:	7100085f 	cmp	w2, #0x2
    a0e8:	5400d9e0 	b.eq	bc24 <f0+0x23a0>  // b.none
    a0ec:	7100045f 	cmp	w2, #0x1
    a0f0:	540001a1 	b.ne	a124 <f0+0x8a0>  // b.any
    a0f4:	29430002 	ldp	w2, w0, [x0, #24]
    a0f8:	92403c21 	and	x1, x1, #0xffff
    a0fc:	9b027c21 	mul	x1, x1, x2
    a100:	d360fc21 	lsr	x1, x1, #32
    a104:	eb00003f 	cmp	x1, x0
    a108:	540000e2 	b.cs	a124 <f0+0x8a0>  // b.hs, b.nlast
    a10c:	8b0102f7 	add	x23, x23, x1
    a110:	394002e0 	ldrb	w0, [x23]
    a114:	7103fc1f 	cmp	w0, #0xff
    a118:	5400e340 	b.eq	bd80 <f0+0x24fc>  // b.none
    a11c:	52800020 	mov	w0, #0x1                   	// #1
    a120:	390002e0 	strb	w0, [x23]
    a124:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a128:	9107a3e1 	add	x1, sp, #0x1e8
    a12c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a130:	52800020 	mov	w0, #0x1                   	// #1
    a134:	a91ed7e2 	stp	x2, x21, [sp, #488]
    a138:	97ffeb13 	bl	4d84 <fwp_data.part.0.constprop.0>
    a13c:	97ffec76 	bl	5314 <fwp_rc_fresh>
    a140:	aa0003e2 	mov	x2, x0
    a144:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a148:	9107e3e1 	add	x1, sp, #0x1f8
    a14c:	52800020 	mov	w0, #0x1                   	// #1
    a150:	a91f8be3 	stp	x3, x2, [sp, #504]
    a154:	97ffeb0c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a158:	91150283 	add	x3, x20, #0x540
    a15c:	aa0003f5 	mov	x21, x0
    a160:	f949d861 	ldr	x1, [x3, #5040]
    a164:	f949ec60 	ldr	x0, [x3, #5080]
    a168:	cb0102a1 	sub	x1, x21, x1
    a16c:	eb00403f 	cmp	x1, x0, lsl #16
    a170:	54000322 	b.cs	a1d4 <f0+0x950>  // b.hs, b.nlast
    a174:	d350fc22 	lsr	x2, x1, #16
    a178:	f949fc63 	ldr	x3, [x3, #5112]
    a17c:	8b020842 	add	x2, x2, x2, lsl #2
    a180:	d37df042 	lsl	x2, x2, #3
    a184:	8b020060 	add	x0, x3, x2
    a188:	f9401017 	ldr	x23, [x0, #32]
    a18c:	b4000257 	cbz	x23, a1d4 <f0+0x950>
    a190:	38626862 	ldrb	w2, [x3, x2]
    a194:	7100085f 	cmp	w2, #0x2
    a198:	5400d400 	b.eq	bc18 <f0+0x2394>  // b.none
    a19c:	7100045f 	cmp	w2, #0x1
    a1a0:	540001a1 	b.ne	a1d4 <f0+0x950>  // b.any
    a1a4:	29430002 	ldp	w2, w0, [x0, #24]
    a1a8:	92403c21 	and	x1, x1, #0xffff
    a1ac:	9b027c21 	mul	x1, x1, x2
    a1b0:	d360fc21 	lsr	x1, x1, #32
    a1b4:	eb00003f 	cmp	x1, x0
    a1b8:	540000e2 	b.cs	a1d4 <f0+0x950>  // b.hs, b.nlast
    a1bc:	8b0102f7 	add	x23, x23, x1
    a1c0:	394002e0 	ldrb	w0, [x23]
    a1c4:	7103fc1f 	cmp	w0, #0xff
    a1c8:	5400de20 	b.eq	bd8c <f0+0x2508>  // b.none
    a1cc:	52800020 	mov	w0, #0x1                   	// #1
    a1d0:	390002e0 	strb	w0, [x23]
    a1d4:	910823e1 	add	x1, sp, #0x208
    a1d8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a1dc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a1e0:	52800020 	mov	w0, #0x1                   	// #1
    a1e4:	f90107f7 	str	x23, [sp, #520]
    a1e8:	f9010bf5 	str	x21, [sp, #528]
    a1ec:	97ffeae6 	bl	4d84 <fwp_data.part.0.constprop.0>
    a1f0:	97ffec49 	bl	5314 <fwp_rc_fresh>
    a1f4:	aa0003e2 	mov	x2, x0
    a1f8:	910863e1 	add	x1, sp, #0x218
    a1fc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a200:	52800020 	mov	w0, #0x1                   	// #1
    a204:	f9010ff5 	str	x21, [sp, #536]
    a208:	f90113e2 	str	x2, [sp, #544]
    a20c:	97ffeade 	bl	4d84 <fwp_data.part.0.constprop.0>
    a210:	97ffec41 	bl	5314 <fwp_rc_fresh>
    a214:	aa0003e2 	mov	x2, x0
    a218:	9108a3e1 	add	x1, sp, #0x228
    a21c:	52800020 	mov	w0, #0x1                   	// #1
    a220:	f90117f7 	str	x23, [sp, #552]
    a224:	f9011be2 	str	x2, [sp, #560]
    a228:	97ffead7 	bl	4d84 <fwp_data.part.0.constprop.0>
    a22c:	97ffec3a 	bl	5314 <fwp_rc_fresh>
    a230:	aa0003e2 	mov	x2, x0
    a234:	9108e3e1 	add	x1, sp, #0x238
    a238:	52800020 	mov	w0, #0x1                   	// #1
    a23c:	f9011ff5 	str	x21, [sp, #568]
    a240:	f90123e2 	str	x2, [sp, #576]
    a244:	97ffead0 	bl	4d84 <fwp_data.part.0.constprop.0>
    a248:	91150283 	add	x3, x20, #0x540
    a24c:	aa0003f5 	mov	x21, x0
    a250:	f949d861 	ldr	x1, [x3, #5040]
    a254:	f949ec60 	ldr	x0, [x3, #5080]
    a258:	cb0102a1 	sub	x1, x21, x1
    a25c:	eb00403f 	cmp	x1, x0, lsl #16
    a260:	54000322 	b.cs	a2c4 <f0+0xa40>  // b.hs, b.nlast
    a264:	d350fc22 	lsr	x2, x1, #16
    a268:	f949fc63 	ldr	x3, [x3, #5112]
    a26c:	8b020842 	add	x2, x2, x2, lsl #2
    a270:	d37df042 	lsl	x2, x2, #3
    a274:	8b020060 	add	x0, x3, x2
    a278:	f9401017 	ldr	x23, [x0, #32]
    a27c:	b4000257 	cbz	x23, a2c4 <f0+0xa40>
    a280:	38626862 	ldrb	w2, [x3, x2]
    a284:	7100085f 	cmp	w2, #0x2
    a288:	5400cc20 	b.eq	bc0c <f0+0x2388>  // b.none
    a28c:	7100045f 	cmp	w2, #0x1
    a290:	540001a1 	b.ne	a2c4 <f0+0xa40>  // b.any
    a294:	29430002 	ldp	w2, w0, [x0, #24]
    a298:	92403c21 	and	x1, x1, #0xffff
    a29c:	9b027c21 	mul	x1, x1, x2
    a2a0:	d360fc21 	lsr	x1, x1, #32
    a2a4:	eb00003f 	cmp	x1, x0
    a2a8:	540000e2 	b.cs	a2c4 <f0+0xa40>  // b.hs, b.nlast
    a2ac:	8b0102f7 	add	x23, x23, x1
    a2b0:	394002e0 	ldrb	w0, [x23]
    a2b4:	7103fc1f 	cmp	w0, #0xff
    a2b8:	5400d700 	b.eq	bd98 <f0+0x2514>  // b.none
    a2bc:	52800020 	mov	w0, #0x1                   	// #1
    a2c0:	390002e0 	strb	w0, [x23]
    a2c4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a2c8:	910923e1 	add	x1, sp, #0x248
    a2cc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a2d0:	52800020 	mov	w0, #0x1                   	// #1
    a2d4:	f90127e2 	str	x2, [sp, #584]
    a2d8:	f9012bf5 	str	x21, [sp, #592]
    a2dc:	97ffeaaa 	bl	4d84 <fwp_data.part.0.constprop.0>
    a2e0:	97ffec0d 	bl	5314 <fwp_rc_fresh>
    a2e4:	aa0003e2 	mov	x2, x0
    a2e8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a2ec:	910963e1 	add	x1, sp, #0x258
    a2f0:	52800020 	mov	w0, #0x1                   	// #1
    a2f4:	f9012fe3 	str	x3, [sp, #600]
    a2f8:	f90133e2 	str	x2, [sp, #608]
    a2fc:	97ffeaa2 	bl	4d84 <fwp_data.part.0.constprop.0>
    a300:	91150283 	add	x3, x20, #0x540
    a304:	aa0003f5 	mov	x21, x0
    a308:	f949d861 	ldr	x1, [x3, #5040]
    a30c:	f949ec60 	ldr	x0, [x3, #5080]
    a310:	cb0102a1 	sub	x1, x21, x1
    a314:	eb00403f 	cmp	x1, x0, lsl #16
    a318:	54000322 	b.cs	a37c <f0+0xaf8>  // b.hs, b.nlast
    a31c:	d350fc22 	lsr	x2, x1, #16
    a320:	f949fc63 	ldr	x3, [x3, #5112]
    a324:	8b020842 	add	x2, x2, x2, lsl #2
    a328:	d37df042 	lsl	x2, x2, #3
    a32c:	8b020060 	add	x0, x3, x2
    a330:	f9401017 	ldr	x23, [x0, #32]
    a334:	b4000257 	cbz	x23, a37c <f0+0xaf8>
    a338:	38626862 	ldrb	w2, [x3, x2]
    a33c:	7100085f 	cmp	w2, #0x2
    a340:	5400c600 	b.eq	bc00 <f0+0x237c>  // b.none
    a344:	7100045f 	cmp	w2, #0x1
    a348:	540001a1 	b.ne	a37c <f0+0xaf8>  // b.any
    a34c:	29430002 	ldp	w2, w0, [x0, #24]
    a350:	92403c21 	and	x1, x1, #0xffff
    a354:	9b027c21 	mul	x1, x1, x2
    a358:	d360fc21 	lsr	x1, x1, #32
    a35c:	eb00003f 	cmp	x1, x0
    a360:	540000e2 	b.cs	a37c <f0+0xaf8>  // b.hs, b.nlast
    a364:	8b0102f7 	add	x23, x23, x1
    a368:	394002e0 	ldrb	w0, [x23]
    a36c:	7103fc1f 	cmp	w0, #0xff
    a370:	5400d1a0 	b.eq	bda4 <f0+0x2520>  // b.none
    a374:	52800020 	mov	w0, #0x1                   	// #1
    a378:	390002e0 	strb	w0, [x23]
    a37c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a380:	9109a3e1 	add	x1, sp, #0x268
    a384:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a388:	52800020 	mov	w0, #0x1                   	// #1
    a38c:	f90137e2 	str	x2, [sp, #616]
    a390:	f9013bf5 	str	x21, [sp, #624]
    a394:	97ffea7c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a398:	97ffebdf 	bl	5314 <fwp_rc_fresh>
    a39c:	aa0003e2 	mov	x2, x0
    a3a0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a3a4:	9109e3e1 	add	x1, sp, #0x278
    a3a8:	52800020 	mov	w0, #0x1                   	// #1
    a3ac:	f9013fe3 	str	x3, [sp, #632]
    a3b0:	f90143e2 	str	x2, [sp, #640]
    a3b4:	97ffea74 	bl	4d84 <fwp_data.part.0.constprop.0>
    a3b8:	91150283 	add	x3, x20, #0x540
    a3bc:	aa0003f5 	mov	x21, x0
    a3c0:	f949d861 	ldr	x1, [x3, #5040]
    a3c4:	f949ec60 	ldr	x0, [x3, #5080]
    a3c8:	cb0102a1 	sub	x1, x21, x1
    a3cc:	eb00403f 	cmp	x1, x0, lsl #16
    a3d0:	54000322 	b.cs	a434 <f0+0xbb0>  // b.hs, b.nlast
    a3d4:	d350fc22 	lsr	x2, x1, #16
    a3d8:	f949fc63 	ldr	x3, [x3, #5112]
    a3dc:	8b020842 	add	x2, x2, x2, lsl #2
    a3e0:	d37df042 	lsl	x2, x2, #3
    a3e4:	8b020060 	add	x0, x3, x2
    a3e8:	f9401017 	ldr	x23, [x0, #32]
    a3ec:	b4000257 	cbz	x23, a434 <f0+0xbb0>
    a3f0:	38626862 	ldrb	w2, [x3, x2]
    a3f4:	7100085f 	cmp	w2, #0x2
    a3f8:	5400bfe0 	b.eq	bbf4 <f0+0x2370>  // b.none
    a3fc:	7100045f 	cmp	w2, #0x1
    a400:	540001a1 	b.ne	a434 <f0+0xbb0>  // b.any
    a404:	29430002 	ldp	w2, w0, [x0, #24]
    a408:	92403c21 	and	x1, x1, #0xffff
    a40c:	9b027c21 	mul	x1, x1, x2
    a410:	d360fc21 	lsr	x1, x1, #32
    a414:	eb00003f 	cmp	x1, x0
    a418:	540000e2 	b.cs	a434 <f0+0xbb0>  // b.hs, b.nlast
    a41c:	8b0102f7 	add	x23, x23, x1
    a420:	394002e0 	ldrb	w0, [x23]
    a424:	7103fc1f 	cmp	w0, #0xff
    a428:	5400cc40 	b.eq	bdb0 <f0+0x252c>  // b.none
    a42c:	52800020 	mov	w0, #0x1                   	// #1
    a430:	390002e0 	strb	w0, [x23]
    a434:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a438:	910a23e1 	add	x1, sp, #0x288
    a43c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a440:	52800020 	mov	w0, #0x1                   	// #1
    a444:	f90147e2 	str	x2, [sp, #648]
    a448:	f9014bf5 	str	x21, [sp, #656]
    a44c:	97ffea4e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a450:	91150283 	add	x3, x20, #0x540
    a454:	aa0003f5 	mov	x21, x0
    a458:	f949d861 	ldr	x1, [x3, #5040]
    a45c:	f949ec60 	ldr	x0, [x3, #5080]
    a460:	cb0102a1 	sub	x1, x21, x1
    a464:	eb00403f 	cmp	x1, x0, lsl #16
    a468:	54000322 	b.cs	a4cc <f0+0xc48>  // b.hs, b.nlast
    a46c:	d350fc22 	lsr	x2, x1, #16
    a470:	f949fc63 	ldr	x3, [x3, #5112]
    a474:	8b020842 	add	x2, x2, x2, lsl #2
    a478:	d37df042 	lsl	x2, x2, #3
    a47c:	8b020060 	add	x0, x3, x2
    a480:	f9401017 	ldr	x23, [x0, #32]
    a484:	b4000257 	cbz	x23, a4cc <f0+0xc48>
    a488:	38626862 	ldrb	w2, [x3, x2]
    a48c:	7100085f 	cmp	w2, #0x2
    a490:	5400bac0 	b.eq	bbe8 <f0+0x2364>  // b.none
    a494:	7100045f 	cmp	w2, #0x1
    a498:	540001a1 	b.ne	a4cc <f0+0xc48>  // b.any
    a49c:	29430002 	ldp	w2, w0, [x0, #24]
    a4a0:	92403c21 	and	x1, x1, #0xffff
    a4a4:	9b027c21 	mul	x1, x1, x2
    a4a8:	d360fc21 	lsr	x1, x1, #32
    a4ac:	eb00003f 	cmp	x1, x0
    a4b0:	540000e2 	b.cs	a4cc <f0+0xc48>  // b.hs, b.nlast
    a4b4:	8b0102f7 	add	x23, x23, x1
    a4b8:	394002e0 	ldrb	w0, [x23]
    a4bc:	7103fc1f 	cmp	w0, #0xff
    a4c0:	5400c7e0 	b.eq	bdbc <f0+0x2538>  // b.none
    a4c4:	52800020 	mov	w0, #0x1                   	// #1
    a4c8:	390002e0 	strb	w0, [x23]
    a4cc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a4d0:	910a63e1 	add	x1, sp, #0x298
    a4d4:	52800020 	mov	w0, #0x1                   	// #1
    a4d8:	f9014fe2 	str	x2, [sp, #664]
    a4dc:	f90153f5 	str	x21, [sp, #672]
    a4e0:	97ffea29 	bl	4d84 <fwp_data.part.0.constprop.0>
    a4e4:	91150283 	add	x3, x20, #0x540
    a4e8:	aa0003f5 	mov	x21, x0
    a4ec:	f949d861 	ldr	x1, [x3, #5040]
    a4f0:	f949ec60 	ldr	x0, [x3, #5080]
    a4f4:	cb0102a1 	sub	x1, x21, x1
    a4f8:	eb00403f 	cmp	x1, x0, lsl #16
    a4fc:	54000322 	b.cs	a560 <f0+0xcdc>  // b.hs, b.nlast
    a500:	d350fc22 	lsr	x2, x1, #16
    a504:	f949fc63 	ldr	x3, [x3, #5112]
    a508:	8b020842 	add	x2, x2, x2, lsl #2
    a50c:	d37df042 	lsl	x2, x2, #3
    a510:	8b020060 	add	x0, x3, x2
    a514:	f9401017 	ldr	x23, [x0, #32]
    a518:	b4000257 	cbz	x23, a560 <f0+0xcdc>
    a51c:	38626862 	ldrb	w2, [x3, x2]
    a520:	7100085f 	cmp	w2, #0x2
    a524:	5400b320 	b.eq	bb88 <f0+0x2304>  // b.none
    a528:	7100045f 	cmp	w2, #0x1
    a52c:	540001a1 	b.ne	a560 <f0+0xcdc>  // b.any
    a530:	29430002 	ldp	w2, w0, [x0, #24]
    a534:	92403c21 	and	x1, x1, #0xffff
    a538:	9b027c21 	mul	x1, x1, x2
    a53c:	d360fc21 	lsr	x1, x1, #32
    a540:	eb00003f 	cmp	x1, x0
    a544:	540000e2 	b.cs	a560 <f0+0xcdc>  // b.hs, b.nlast
    a548:	8b0102f7 	add	x23, x23, x1
    a54c:	394002e0 	ldrb	w0, [x23]
    a550:	7103fc1f 	cmp	w0, #0xff
    a554:	5400c3a0 	b.eq	bdc8 <f0+0x2544>  // b.none
    a558:	52800020 	mov	w0, #0x1                   	// #1
    a55c:	390002e0 	strb	w0, [x23]
    a560:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a564:	910aa3e1 	add	x1, sp, #0x2a8
    a568:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a56c:	52800020 	mov	w0, #0x1                   	// #1
    a570:	f90157e2 	str	x2, [sp, #680]
    a574:	f9015bf5 	str	x21, [sp, #688]
    a578:	97ffea03 	bl	4d84 <fwp_data.part.0.constprop.0>
    a57c:	97ffeb66 	bl	5314 <fwp_rc_fresh>
    a580:	aa0003e2 	mov	x2, x0
    a584:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a588:	910ae3e1 	add	x1, sp, #0x2b8
    a58c:	52800020 	mov	w0, #0x1                   	// #1
    a590:	f9015fe3 	str	x3, [sp, #696]
    a594:	f90163e2 	str	x2, [sp, #704]
    a598:	97ffe9fb 	bl	4d84 <fwp_data.part.0.constprop.0>
    a59c:	91150283 	add	x3, x20, #0x540
    a5a0:	aa0003f5 	mov	x21, x0
    a5a4:	f949d861 	ldr	x1, [x3, #5040]
    a5a8:	f949ec60 	ldr	x0, [x3, #5080]
    a5ac:	cb0102a1 	sub	x1, x21, x1
    a5b0:	eb00403f 	cmp	x1, x0, lsl #16
    a5b4:	54000322 	b.cs	a618 <f0+0xd94>  // b.hs, b.nlast
    a5b8:	d350fc22 	lsr	x2, x1, #16
    a5bc:	f949fc63 	ldr	x3, [x3, #5112]
    a5c0:	8b020842 	add	x2, x2, x2, lsl #2
    a5c4:	d37df042 	lsl	x2, x2, #3
    a5c8:	8b020060 	add	x0, x3, x2
    a5cc:	f9401017 	ldr	x23, [x0, #32]
    a5d0:	b4000257 	cbz	x23, a618 <f0+0xd94>
    a5d4:	38626862 	ldrb	w2, [x3, x2]
    a5d8:	7100085f 	cmp	w2, #0x2
    a5dc:	5400ad00 	b.eq	bb7c <f0+0x22f8>  // b.none
    a5e0:	7100045f 	cmp	w2, #0x1
    a5e4:	540001a1 	b.ne	a618 <f0+0xd94>  // b.any
    a5e8:	29430002 	ldp	w2, w0, [x0, #24]
    a5ec:	92403c21 	and	x1, x1, #0xffff
    a5f0:	9b027c21 	mul	x1, x1, x2
    a5f4:	d360fc21 	lsr	x1, x1, #32
    a5f8:	eb00003f 	cmp	x1, x0
    a5fc:	540000e2 	b.cs	a618 <f0+0xd94>  // b.hs, b.nlast
    a600:	8b0102f7 	add	x23, x23, x1
    a604:	394002e0 	ldrb	w0, [x23]
    a608:	7103fc1f 	cmp	w0, #0xff
    a60c:	5400be40 	b.eq	bdd4 <f0+0x2550>  // b.none
    a610:	52800020 	mov	w0, #0x1                   	// #1
    a614:	390002e0 	strb	w0, [x23]
    a618:	910b23e1 	add	x1, sp, #0x2c8
    a61c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a620:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a624:	52800020 	mov	w0, #0x1                   	// #1
    a628:	f90167f7 	str	x23, [sp, #712]
    a62c:	f9016bf5 	str	x21, [sp, #720]
    a630:	97ffe9d5 	bl	4d84 <fwp_data.part.0.constprop.0>
    a634:	97ffeb38 	bl	5314 <fwp_rc_fresh>
    a638:	aa0003e2 	mov	x2, x0
    a63c:	910b63e1 	add	x1, sp, #0x2d8
    a640:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a644:	52800020 	mov	w0, #0x1                   	// #1
    a648:	f9016ff5 	str	x21, [sp, #728]
    a64c:	f90173e2 	str	x2, [sp, #736]
    a650:	97ffe9cd 	bl	4d84 <fwp_data.part.0.constprop.0>
    a654:	97ffeb30 	bl	5314 <fwp_rc_fresh>
    a658:	aa0003e2 	mov	x2, x0
    a65c:	910ba3e1 	add	x1, sp, #0x2e8
    a660:	52800020 	mov	w0, #0x1                   	// #1
    a664:	f90177f7 	str	x23, [sp, #744]
    a668:	f9017be2 	str	x2, [sp, #752]
    a66c:	97ffe9c6 	bl	4d84 <fwp_data.part.0.constprop.0>
    a670:	97ffeb29 	bl	5314 <fwp_rc_fresh>
    a674:	aa0003e2 	mov	x2, x0
    a678:	910be3e1 	add	x1, sp, #0x2f8
    a67c:	52800020 	mov	w0, #0x1                   	// #1
    a680:	f9017ff5 	str	x21, [sp, #760]
    a684:	f90183e2 	str	x2, [sp, #768]
    a688:	97ffe9bf 	bl	4d84 <fwp_data.part.0.constprop.0>
    a68c:	97ffeb22 	bl	5314 <fwp_rc_fresh>
    a690:	aa0003e2 	mov	x2, x0
    a694:	910c23e1 	add	x1, sp, #0x308
    a698:	52800020 	mov	w0, #0x1                   	// #1
    a69c:	f90187f7 	str	x23, [sp, #776]
    a6a0:	f9018be2 	str	x2, [sp, #784]
    a6a4:	97ffe9b8 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6a8:	97ffeb1b 	bl	5314 <fwp_rc_fresh>
    a6ac:	aa0003e2 	mov	x2, x0
    a6b0:	910c63e1 	add	x1, sp, #0x318
    a6b4:	52800020 	mov	w0, #0x1                   	// #1
    a6b8:	f9018ff5 	str	x21, [sp, #792]
    a6bc:	f90193e2 	str	x2, [sp, #800]
    a6c0:	97ffe9b1 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6c4:	97ffeb14 	bl	5314 <fwp_rc_fresh>
    a6c8:	aa0003e2 	mov	x2, x0
    a6cc:	910ca3e1 	add	x1, sp, #0x328
    a6d0:	52800020 	mov	w0, #0x1                   	// #1
    a6d4:	f90197f7 	str	x23, [sp, #808]
    a6d8:	f9019be2 	str	x2, [sp, #816]
    a6dc:	97ffe9aa 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6e0:	97ffeb0d 	bl	5314 <fwp_rc_fresh>
    a6e4:	aa0003e2 	mov	x2, x0
    a6e8:	910ce3e1 	add	x1, sp, #0x338
    a6ec:	52800020 	mov	w0, #0x1                   	// #1
    a6f0:	f9019ff5 	str	x21, [sp, #824]
    a6f4:	f901a3e2 	str	x2, [sp, #832]
    a6f8:	97ffe9a3 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6fc:	91150283 	add	x3, x20, #0x540
    a700:	aa0003f5 	mov	x21, x0
    a704:	f949d861 	ldr	x1, [x3, #5040]
    a708:	f949ec60 	ldr	x0, [x3, #5080]
    a70c:	cb0102a1 	sub	x1, x21, x1
    a710:	eb00403f 	cmp	x1, x0, lsl #16
    a714:	54000322 	b.cs	a778 <f0+0xef4>  // b.hs, b.nlast
    a718:	d350fc22 	lsr	x2, x1, #16
    a71c:	f949fc63 	ldr	x3, [x3, #5112]
    a720:	8b020842 	add	x2, x2, x2, lsl #2
    a724:	d37df042 	lsl	x2, x2, #3
    a728:	8b020060 	add	x0, x3, x2
    a72c:	f9401017 	ldr	x23, [x0, #32]
    a730:	b4000257 	cbz	x23, a778 <f0+0xef4>
    a734:	38626862 	ldrb	w2, [x3, x2]
    a738:	7100085f 	cmp	w2, #0x2
    a73c:	5400a1a0 	b.eq	bb70 <f0+0x22ec>  // b.none
    a740:	7100045f 	cmp	w2, #0x1
    a744:	540001a1 	b.ne	a778 <f0+0xef4>  // b.any
    a748:	29430002 	ldp	w2, w0, [x0, #24]
    a74c:	92403c21 	and	x1, x1, #0xffff
    a750:	9b027c21 	mul	x1, x1, x2
    a754:	d360fc21 	lsr	x1, x1, #32
    a758:	eb00003f 	cmp	x1, x0
    a75c:	540000e2 	b.cs	a778 <f0+0xef4>  // b.hs, b.nlast
    a760:	8b0102f7 	add	x23, x23, x1
    a764:	394002e0 	ldrb	w0, [x23]
    a768:	7103fc1f 	cmp	w0, #0xff
    a76c:	5400b3a0 	b.eq	bde0 <f0+0x255c>  // b.none
    a770:	52800020 	mov	w0, #0x1                   	// #1
    a774:	390002e0 	strb	w0, [x23]
    a778:	910d23e1 	add	x1, sp, #0x348
    a77c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a780:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a784:	52800020 	mov	w0, #0x1                   	// #1
    a788:	f901a7f7 	str	x23, [sp, #840]
    a78c:	f901abf5 	str	x21, [sp, #848]
    a790:	97ffe97d 	bl	4d84 <fwp_data.part.0.constprop.0>
    a794:	97ffeae0 	bl	5314 <fwp_rc_fresh>
    a798:	aa0003e2 	mov	x2, x0
    a79c:	910d63e1 	add	x1, sp, #0x358
    a7a0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a7a4:	52800020 	mov	w0, #0x1                   	// #1
    a7a8:	f901aff5 	str	x21, [sp, #856]
    a7ac:	f901b3e2 	str	x2, [sp, #864]
    a7b0:	97ffe975 	bl	4d84 <fwp_data.part.0.constprop.0>
    a7b4:	97ffead8 	bl	5314 <fwp_rc_fresh>
    a7b8:	aa0003e2 	mov	x2, x0
    a7bc:	910da3e1 	add	x1, sp, #0x368
    a7c0:	52800020 	mov	w0, #0x1                   	// #1
    a7c4:	f901b7f7 	str	x23, [sp, #872]
    a7c8:	f901bbe2 	str	x2, [sp, #880]
    a7cc:	97ffe96e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a7d0:	97ffead1 	bl	5314 <fwp_rc_fresh>
    a7d4:	aa0003e2 	mov	x2, x0
    a7d8:	910de3e1 	add	x1, sp, #0x378
    a7dc:	52800020 	mov	w0, #0x1                   	// #1
    a7e0:	f901bff5 	str	x21, [sp, #888]
    a7e4:	f901c3e2 	str	x2, [sp, #896]
    a7e8:	97ffe967 	bl	4d84 <fwp_data.part.0.constprop.0>
    a7ec:	91150283 	add	x3, x20, #0x540
    a7f0:	aa0003f5 	mov	x21, x0
    a7f4:	f949d861 	ldr	x1, [x3, #5040]
    a7f8:	f949ec60 	ldr	x0, [x3, #5080]
    a7fc:	cb0102a1 	sub	x1, x21, x1
    a800:	eb00403f 	cmp	x1, x0, lsl #16
    a804:	54000322 	b.cs	a868 <f0+0xfe4>  // b.hs, b.nlast
    a808:	d350fc22 	lsr	x2, x1, #16
    a80c:	f949fc63 	ldr	x3, [x3, #5112]
    a810:	8b020842 	add	x2, x2, x2, lsl #2
    a814:	d37df042 	lsl	x2, x2, #3
    a818:	8b020060 	add	x0, x3, x2
    a81c:	f9401017 	ldr	x23, [x0, #32]
    a820:	b4000257 	cbz	x23, a868 <f0+0xfe4>
    a824:	38626862 	ldrb	w2, [x3, x2]
    a828:	7100085f 	cmp	w2, #0x2
    a82c:	540099c0 	b.eq	bb64 <f0+0x22e0>  // b.none
    a830:	7100045f 	cmp	w2, #0x1
    a834:	540001a1 	b.ne	a868 <f0+0xfe4>  // b.any
    a838:	29430002 	ldp	w2, w0, [x0, #24]
    a83c:	92403c21 	and	x1, x1, #0xffff
    a840:	9b027c21 	mul	x1, x1, x2
    a844:	d360fc21 	lsr	x1, x1, #32
    a848:	eb00003f 	cmp	x1, x0
    a84c:	540000e2 	b.cs	a868 <f0+0xfe4>  // b.hs, b.nlast
    a850:	8b0102f7 	add	x23, x23, x1
    a854:	394002e0 	ldrb	w0, [x23]
    a858:	7103fc1f 	cmp	w0, #0xff
    a85c:	5400ac80 	b.eq	bdec <f0+0x2568>  // b.none
    a860:	52800020 	mov	w0, #0x1                   	// #1
    a864:	390002e0 	strb	w0, [x23]
    a868:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a86c:	910e23e1 	add	x1, sp, #0x388
    a870:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a874:	52800020 	mov	w0, #0x1                   	// #1
    a878:	f901c7e2 	str	x2, [sp, #904]
    a87c:	f901cbf5 	str	x21, [sp, #912]
    a880:	97ffe941 	bl	4d84 <fwp_data.part.0.constprop.0>
    a884:	97ffeaa4 	bl	5314 <fwp_rc_fresh>
    a888:	aa0003e2 	mov	x2, x0
    a88c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a890:	910e63e1 	add	x1, sp, #0x398
    a894:	52800020 	mov	w0, #0x1                   	// #1
    a898:	f901cfe3 	str	x3, [sp, #920]
    a89c:	f901d3e2 	str	x2, [sp, #928]
    a8a0:	97ffe939 	bl	4d84 <fwp_data.part.0.constprop.0>
    a8a4:	91150283 	add	x3, x20, #0x540
    a8a8:	aa0003f5 	mov	x21, x0
    a8ac:	f949d861 	ldr	x1, [x3, #5040]
    a8b0:	f949ec60 	ldr	x0, [x3, #5080]
    a8b4:	cb0102a1 	sub	x1, x21, x1
    a8b8:	eb00403f 	cmp	x1, x0, lsl #16
    a8bc:	54000322 	b.cs	a920 <f0+0x109c>  // b.hs, b.nlast
    a8c0:	d350fc22 	lsr	x2, x1, #16
    a8c4:	f949fc63 	ldr	x3, [x3, #5112]
    a8c8:	8b020842 	add	x2, x2, x2, lsl #2
    a8cc:	d37df042 	lsl	x2, x2, #3
    a8d0:	8b020060 	add	x0, x3, x2
    a8d4:	f9401017 	ldr	x23, [x0, #32]
    a8d8:	b4000257 	cbz	x23, a920 <f0+0x109c>
    a8dc:	38626862 	ldrb	w2, [x3, x2]
    a8e0:	7100085f 	cmp	w2, #0x2
    a8e4:	540093a0 	b.eq	bb58 <f0+0x22d4>  // b.none
    a8e8:	7100045f 	cmp	w2, #0x1
    a8ec:	540001a1 	b.ne	a920 <f0+0x109c>  // b.any
    a8f0:	29430002 	ldp	w2, w0, [x0, #24]
    a8f4:	92403c21 	and	x1, x1, #0xffff
    a8f8:	9b027c21 	mul	x1, x1, x2
    a8fc:	d360fc21 	lsr	x1, x1, #32
    a900:	eb00003f 	cmp	x1, x0
    a904:	540000e2 	b.cs	a920 <f0+0x109c>  // b.hs, b.nlast
    a908:	8b0102f7 	add	x23, x23, x1
    a90c:	394002e0 	ldrb	w0, [x23]
    a910:	7103fc1f 	cmp	w0, #0xff
    a914:	5400a720 	b.eq	bdf8 <f0+0x2574>  // b.none
    a918:	52800020 	mov	w0, #0x1                   	// #1
    a91c:	390002e0 	strb	w0, [x23]
    a920:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a924:	910ea3e1 	add	x1, sp, #0x3a8
    a928:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a92c:	52800020 	mov	w0, #0x1                   	// #1
    a930:	f901d7e2 	str	x2, [sp, #936]
    a934:	f901dbf5 	str	x21, [sp, #944]
    a938:	97ffe913 	bl	4d84 <fwp_data.part.0.constprop.0>
    a93c:	97ffea76 	bl	5314 <fwp_rc_fresh>
    a940:	aa0003e2 	mov	x2, x0
    a944:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a948:	910ee3e1 	add	x1, sp, #0x3b8
    a94c:	52800020 	mov	w0, #0x1                   	// #1
    a950:	f901dfe3 	str	x3, [sp, #952]
    a954:	f901e3e2 	str	x2, [sp, #960]
    a958:	97ffe90b 	bl	4d84 <fwp_data.part.0.constprop.0>
    a95c:	91150283 	add	x3, x20, #0x540
    a960:	aa0003f7 	mov	x23, x0
    a964:	f949d861 	ldr	x1, [x3, #5040]
    a968:	f949ec60 	ldr	x0, [x3, #5080]
    a96c:	cb0102e1 	sub	x1, x23, x1
    a970:	eb00403f 	cmp	x1, x0, lsl #16
    a974:	54000322 	b.cs	a9d8 <f0+0x1154>  // b.hs, b.nlast
    a978:	d350fc22 	lsr	x2, x1, #16
    a97c:	f949fc63 	ldr	x3, [x3, #5112]
    a980:	8b020842 	add	x2, x2, x2, lsl #2
    a984:	d37df042 	lsl	x2, x2, #3
    a988:	8b020060 	add	x0, x3, x2
    a98c:	f9401015 	ldr	x21, [x0, #32]
    a990:	b4000255 	cbz	x21, a9d8 <f0+0x1154>
    a994:	38626862 	ldrb	w2, [x3, x2]
    a998:	7100085f 	cmp	w2, #0x2
    a99c:	54008d80 	b.eq	bb4c <f0+0x22c8>  // b.none
    a9a0:	7100045f 	cmp	w2, #0x1
    a9a4:	540001a1 	b.ne	a9d8 <f0+0x1154>  // b.any
    a9a8:	29430002 	ldp	w2, w0, [x0, #24]
    a9ac:	92403c21 	and	x1, x1, #0xffff
    a9b0:	9b027c21 	mul	x1, x1, x2
    a9b4:	d360fc21 	lsr	x1, x1, #32
    a9b8:	eb00003f 	cmp	x1, x0
    a9bc:	540000e2 	b.cs	a9d8 <f0+0x1154>  // b.hs, b.nlast
    a9c0:	8b0102b5 	add	x21, x21, x1
    a9c4:	394002a0 	ldrb	w0, [x21]
    a9c8:	7103fc1f 	cmp	w0, #0xff
    a9cc:	5400a1c0 	b.eq	be04 <f0+0x2580>  // b.none
    a9d0:	52800020 	mov	w0, #0x1                   	// #1
    a9d4:	390002a0 	strb	w0, [x21]
    a9d8:	910f23e1 	add	x1, sp, #0x3c8
    a9dc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a9e0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a9e4:	52800020 	mov	w0, #0x1                   	// #1
    a9e8:	f901e7f5 	str	x21, [sp, #968]
    a9ec:	f901ebf7 	str	x23, [sp, #976]
    a9f0:	97ffe8e5 	bl	4d84 <fwp_data.part.0.constprop.0>
    a9f4:	97ffea48 	bl	5314 <fwp_rc_fresh>
    a9f8:	aa0003e2 	mov	x2, x0
    a9fc:	910f63e1 	add	x1, sp, #0x3d8
    aa00:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    aa04:	52800020 	mov	w0, #0x1                   	// #1
    aa08:	f901eff7 	str	x23, [sp, #984]
    aa0c:	f901f3e2 	str	x2, [sp, #992]
    aa10:	97ffe8dd 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa14:	97ffea40 	bl	5314 <fwp_rc_fresh>
    aa18:	aa0003e2 	mov	x2, x0
    aa1c:	910fa3e1 	add	x1, sp, #0x3e8
    aa20:	52800020 	mov	w0, #0x1                   	// #1
    aa24:	f901f7f5 	str	x21, [sp, #1000]
    aa28:	f901fbe2 	str	x2, [sp, #1008]
    aa2c:	97ffe8d6 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa30:	97ffea39 	bl	5314 <fwp_rc_fresh>
    aa34:	aa0003e2 	mov	x2, x0
    aa38:	910fe3e1 	add	x1, sp, #0x3f8
    aa3c:	52800020 	mov	w0, #0x1                   	// #1
    aa40:	f901fff7 	str	x23, [sp, #1016]
    aa44:	f90203e2 	str	x2, [sp, #1024]
    aa48:	97ffe8cf 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa4c:	97ffea32 	bl	5314 <fwp_rc_fresh>
    aa50:	aa0003e2 	mov	x2, x0
    aa54:	911023e1 	add	x1, sp, #0x408
    aa58:	52800020 	mov	w0, #0x1                   	// #1
    aa5c:	f90207f5 	str	x21, [sp, #1032]
    aa60:	f9020be2 	str	x2, [sp, #1040]
    aa64:	97ffe8c8 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa68:	97ffea2b 	bl	5314 <fwp_rc_fresh>
    aa6c:	aa0003e2 	mov	x2, x0
    aa70:	911063e1 	add	x1, sp, #0x418
    aa74:	52800020 	mov	w0, #0x1                   	// #1
    aa78:	f9020ff7 	str	x23, [sp, #1048]
    aa7c:	f90213e2 	str	x2, [sp, #1056]
    aa80:	97ffe8c1 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa84:	97ffea24 	bl	5314 <fwp_rc_fresh>
    aa88:	aa0003e2 	mov	x2, x0
    aa8c:	9110a3e1 	add	x1, sp, #0x428
    aa90:	52800020 	mov	w0, #0x1                   	// #1
    aa94:	f90217f5 	str	x21, [sp, #1064]
    aa98:	f9021be2 	str	x2, [sp, #1072]
    aa9c:	97ffe8ba 	bl	4d84 <fwp_data.part.0.constprop.0>
    aaa0:	91150283 	add	x3, x20, #0x540
    aaa4:	aa0003f5 	mov	x21, x0
    aaa8:	f949d861 	ldr	x1, [x3, #5040]
    aaac:	f949ec60 	ldr	x0, [x3, #5080]
    aab0:	cb0102a1 	sub	x1, x21, x1
    aab4:	eb00403f 	cmp	x1, x0, lsl #16
    aab8:	54000322 	b.cs	ab1c <f0+0x1298>  // b.hs, b.nlast
    aabc:	d350fc22 	lsr	x2, x1, #16
    aac0:	f949fc63 	ldr	x3, [x3, #5112]
    aac4:	8b020842 	add	x2, x2, x2, lsl #2
    aac8:	d37df042 	lsl	x2, x2, #3
    aacc:	8b020060 	add	x0, x3, x2
    aad0:	f9401017 	ldr	x23, [x0, #32]
    aad4:	b4000257 	cbz	x23, ab1c <f0+0x1298>
    aad8:	38626862 	ldrb	w2, [x3, x2]
    aadc:	7100085f 	cmp	w2, #0x2
    aae0:	54008300 	b.eq	bb40 <f0+0x22bc>  // b.none
    aae4:	7100045f 	cmp	w2, #0x1
    aae8:	540001a1 	b.ne	ab1c <f0+0x1298>  // b.any
    aaec:	29430002 	ldp	w2, w0, [x0, #24]
    aaf0:	92403c21 	and	x1, x1, #0xffff
    aaf4:	9b027c21 	mul	x1, x1, x2
    aaf8:	d360fc21 	lsr	x1, x1, #32
    aafc:	eb00003f 	cmp	x1, x0
    ab00:	540000e2 	b.cs	ab1c <f0+0x1298>  // b.hs, b.nlast
    ab04:	8b0102f7 	add	x23, x23, x1
    ab08:	394002e0 	ldrb	w0, [x23]
    ab0c:	7103fc1f 	cmp	w0, #0xff
    ab10:	54009800 	b.eq	be10 <f0+0x258c>  // b.none
    ab14:	52800020 	mov	w0, #0x1                   	// #1
    ab18:	390002e0 	strb	w0, [x23]
    ab1c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab20:	9110e3e1 	add	x1, sp, #0x438
    ab24:	52800020 	mov	w0, #0x1                   	// #1
    ab28:	f9021fe2 	str	x2, [sp, #1080]
    ab2c:	f90223f5 	str	x21, [sp, #1088]
    ab30:	97ffe895 	bl	4d84 <fwp_data.part.0.constprop.0>
    ab34:	91150283 	add	x3, x20, #0x540
    ab38:	aa0003f5 	mov	x21, x0
    ab3c:	f949d861 	ldr	x1, [x3, #5040]
    ab40:	f949ec60 	ldr	x0, [x3, #5080]
    ab44:	cb0102a1 	sub	x1, x21, x1
    ab48:	eb00403f 	cmp	x1, x0, lsl #16
    ab4c:	54000322 	b.cs	abb0 <f0+0x132c>  // b.hs, b.nlast
    ab50:	d350fc22 	lsr	x2, x1, #16
    ab54:	f949fc63 	ldr	x3, [x3, #5112]
    ab58:	8b020842 	add	x2, x2, x2, lsl #2
    ab5c:	d37df042 	lsl	x2, x2, #3
    ab60:	8b020060 	add	x0, x3, x2
    ab64:	f9401017 	ldr	x23, [x0, #32]
    ab68:	b4000257 	cbz	x23, abb0 <f0+0x132c>
    ab6c:	38626862 	ldrb	w2, [x3, x2]
    ab70:	7100085f 	cmp	w2, #0x2
    ab74:	54007e00 	b.eq	bb34 <f0+0x22b0>  // b.none
    ab78:	7100045f 	cmp	w2, #0x1
    ab7c:	540001a1 	b.ne	abb0 <f0+0x132c>  // b.any
    ab80:	29430002 	ldp	w2, w0, [x0, #24]
    ab84:	92403c21 	and	x1, x1, #0xffff
    ab88:	9b027c21 	mul	x1, x1, x2
    ab8c:	d360fc21 	lsr	x1, x1, #32
    ab90:	eb00003f 	cmp	x1, x0
    ab94:	540000e2 	b.cs	abb0 <f0+0x132c>  // b.hs, b.nlast
    ab98:	8b0102f7 	add	x23, x23, x1
    ab9c:	394002e0 	ldrb	w0, [x23]
    aba0:	7103fc1f 	cmp	w0, #0xff
    aba4:	540093c0 	b.eq	be1c <f0+0x2598>  // b.none
    aba8:	52800020 	mov	w0, #0x1                   	// #1
    abac:	390002e0 	strb	w0, [x23]
    abb0:	911123e1 	add	x1, sp, #0x448
    abb4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    abb8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    abbc:	52800020 	mov	w0, #0x1                   	// #1
    abc0:	f90227f7 	str	x23, [sp, #1096]
    abc4:	f9022bf5 	str	x21, [sp, #1104]
    abc8:	97ffe86f 	bl	4d84 <fwp_data.part.0.constprop.0>
    abcc:	97ffe9d2 	bl	5314 <fwp_rc_fresh>
    abd0:	aa0003e2 	mov	x2, x0
    abd4:	911163e1 	add	x1, sp, #0x458
    abd8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    abdc:	52800020 	mov	w0, #0x1                   	// #1
    abe0:	f9022ff5 	str	x21, [sp, #1112]
    abe4:	f90233e2 	str	x2, [sp, #1120]
    abe8:	97ffe867 	bl	4d84 <fwp_data.part.0.constprop.0>
    abec:	97ffe9ca 	bl	5314 <fwp_rc_fresh>
    abf0:	aa0003e2 	mov	x2, x0
    abf4:	9111a3e1 	add	x1, sp, #0x468
    abf8:	52800020 	mov	w0, #0x1                   	// #1
    abfc:	f90237f7 	str	x23, [sp, #1128]
    ac00:	f9023be2 	str	x2, [sp, #1136]
    ac04:	97ffe860 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac08:	97ffe9c3 	bl	5314 <fwp_rc_fresh>
    ac0c:	aa0003e2 	mov	x2, x0
    ac10:	9111e3e1 	add	x1, sp, #0x478
    ac14:	52800020 	mov	w0, #0x1                   	// #1
    ac18:	f9023ff5 	str	x21, [sp, #1144]
    ac1c:	f90243e2 	str	x2, [sp, #1152]
    ac20:	97ffe859 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac24:	91150283 	add	x3, x20, #0x540
    ac28:	aa0003f5 	mov	x21, x0
    ac2c:	f949d861 	ldr	x1, [x3, #5040]
    ac30:	f949ec60 	ldr	x0, [x3, #5080]
    ac34:	cb0102a1 	sub	x1, x21, x1
    ac38:	eb00403f 	cmp	x1, x0, lsl #16
    ac3c:	54000322 	b.cs	aca0 <f0+0x141c>  // b.hs, b.nlast
    ac40:	d350fc22 	lsr	x2, x1, #16
    ac44:	f949fc63 	ldr	x3, [x3, #5112]
    ac48:	8b020842 	add	x2, x2, x2, lsl #2
    ac4c:	d37df042 	lsl	x2, x2, #3
    ac50:	8b020060 	add	x0, x3, x2
    ac54:	f9401017 	ldr	x23, [x0, #32]
    ac58:	b4000257 	cbz	x23, aca0 <f0+0x141c>
    ac5c:	38626862 	ldrb	w2, [x3, x2]
    ac60:	7100085f 	cmp	w2, #0x2
    ac64:	540084c0 	b.eq	bcfc <f0+0x2478>  // b.none
    ac68:	7100045f 	cmp	w2, #0x1
    ac6c:	540001a1 	b.ne	aca0 <f0+0x141c>  // b.any
    ac70:	29430002 	ldp	w2, w0, [x0, #24]
    ac74:	92403c21 	and	x1, x1, #0xffff
    ac78:	9b027c21 	mul	x1, x1, x2
    ac7c:	d360fc21 	lsr	x1, x1, #32
    ac80:	eb00003f 	cmp	x1, x0
    ac84:	540000e2 	b.cs	aca0 <f0+0x141c>  // b.hs, b.nlast
    ac88:	8b0102f7 	add	x23, x23, x1
    ac8c:	394002e0 	ldrb	w0, [x23]
    ac90:	7103fc1f 	cmp	w0, #0xff
    ac94:	54008ca0 	b.eq	be28 <f0+0x25a4>  // b.none
    ac98:	52800020 	mov	w0, #0x1                   	// #1
    ac9c:	390002e0 	strb	w0, [x23]
    aca0:	911223e1 	add	x1, sp, #0x488
    aca4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aca8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    acac:	52800020 	mov	w0, #0x1                   	// #1
    acb0:	f90247f7 	str	x23, [sp, #1160]
    acb4:	f9024bf5 	str	x21, [sp, #1168]
    acb8:	97ffe833 	bl	4d84 <fwp_data.part.0.constprop.0>
    acbc:	97ffe996 	bl	5314 <fwp_rc_fresh>
    acc0:	aa0003e2 	mov	x2, x0
    acc4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    acc8:	911263e1 	add	x1, sp, #0x498
    accc:	52800020 	mov	w0, #0x1                   	// #1
    acd0:	f9024fe3 	str	x3, [sp, #1176]
    acd4:	f90253e2 	str	x2, [sp, #1184]
    acd8:	97ffe82b 	bl	4d84 <fwp_data.part.0.constprop.0>
    acdc:	97ffe98e 	bl	5314 <fwp_rc_fresh>
    ace0:	aa0003e2 	mov	x2, x0
    ace4:	9112a3e1 	add	x1, sp, #0x4a8
    ace8:	52800020 	mov	w0, #0x1                   	// #1
    acec:	f90257f7 	str	x23, [sp, #1192]
    acf0:	f9025be2 	str	x2, [sp, #1200]
    acf4:	97ffe824 	bl	4d84 <fwp_data.part.0.constprop.0>
    acf8:	91150283 	add	x3, x20, #0x540
    acfc:	aa0003f5 	mov	x21, x0
    ad00:	f949d861 	ldr	x1, [x3, #5040]
    ad04:	f949ec60 	ldr	x0, [x3, #5080]
    ad08:	cb0102a1 	sub	x1, x21, x1
    ad0c:	eb00403f 	cmp	x1, x0, lsl #16
    ad10:	54000322 	b.cs	ad74 <f0+0x14f0>  // b.hs, b.nlast
    ad14:	d350fc22 	lsr	x2, x1, #16
    ad18:	f949fc63 	ldr	x3, [x3, #5112]
    ad1c:	8b020842 	add	x2, x2, x2, lsl #2
    ad20:	d37df042 	lsl	x2, x2, #3
    ad24:	8b020060 	add	x0, x3, x2
    ad28:	f9401017 	ldr	x23, [x0, #32]
    ad2c:	b4000257 	cbz	x23, ad74 <f0+0x14f0>
    ad30:	38626862 	ldrb	w2, [x3, x2]
    ad34:	7100085f 	cmp	w2, #0x2
    ad38:	54007dc0 	b.eq	bcf0 <f0+0x246c>  // b.none
    ad3c:	7100045f 	cmp	w2, #0x1
    ad40:	540001a1 	b.ne	ad74 <f0+0x14f0>  // b.any
    ad44:	29430002 	ldp	w2, w0, [x0, #24]
    ad48:	92403c21 	and	x1, x1, #0xffff
    ad4c:	9b027c21 	mul	x1, x1, x2
    ad50:	d360fc21 	lsr	x1, x1, #32
    ad54:	eb00003f 	cmp	x1, x0
    ad58:	540000e2 	b.cs	ad74 <f0+0x14f0>  // b.hs, b.nlast
    ad5c:	8b0102f7 	add	x23, x23, x1
    ad60:	394002e0 	ldrb	w0, [x23]
    ad64:	7103fc1f 	cmp	w0, #0xff
    ad68:	54008660 	b.eq	be34 <f0+0x25b0>  // b.none
    ad6c:	52800020 	mov	w0, #0x1                   	// #1
    ad70:	390002e0 	strb	w0, [x23]
    ad74:	9112e3e1 	add	x1, sp, #0x4b8
    ad78:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ad7c:	52800020 	mov	w0, #0x1                   	// #1
    ad80:	f9025ff7 	str	x23, [sp, #1208]
    ad84:	f90263f5 	str	x21, [sp, #1216]
    ad88:	97ffe7ff 	bl	4d84 <fwp_data.part.0.constprop.0>
    ad8c:	97ffe962 	bl	5314 <fwp_rc_fresh>
    ad90:	aa0003e2 	mov	x2, x0
    ad94:	911323e1 	add	x1, sp, #0x4c8
    ad98:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ad9c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ada0:	52800020 	mov	w0, #0x1                   	// #1
    ada4:	f90267f5 	str	x21, [sp, #1224]
    ada8:	f9026be2 	str	x2, [sp, #1232]
    adac:	97ffe7f6 	bl	4d84 <fwp_data.part.0.constprop.0>
    adb0:	97ffe959 	bl	5314 <fwp_rc_fresh>
    adb4:	aa0003e2 	mov	x2, x0
    adb8:	911363e1 	add	x1, sp, #0x4d8
    adbc:	52800020 	mov	w0, #0x1                   	// #1
    adc0:	f9026ff7 	str	x23, [sp, #1240]
    adc4:	f90273e2 	str	x2, [sp, #1248]
    adc8:	97ffe7ef 	bl	4d84 <fwp_data.part.0.constprop.0>
    adcc:	97ffe952 	bl	5314 <fwp_rc_fresh>
    add0:	aa0003e2 	mov	x2, x0
    add4:	9113a3e1 	add	x1, sp, #0x4e8
    add8:	52800020 	mov	w0, #0x1                   	// #1
    addc:	f90277f5 	str	x21, [sp, #1256]
    ade0:	f9027be2 	str	x2, [sp, #1264]
    ade4:	97ffe7e8 	bl	4d84 <fwp_data.part.0.constprop.0>
    ade8:	97ffe94b 	bl	5314 <fwp_rc_fresh>
    adec:	aa0003e2 	mov	x2, x0
    adf0:	9113e3e1 	add	x1, sp, #0x4f8
    adf4:	52800020 	mov	w0, #0x1                   	// #1
    adf8:	f9027ff7 	str	x23, [sp, #1272]
    adfc:	f90283e2 	str	x2, [sp, #1280]
    ae00:	97ffe7e1 	bl	4d84 <fwp_data.part.0.constprop.0>
    ae04:	91150283 	add	x3, x20, #0x540
    ae08:	aa0003f5 	mov	x21, x0
    ae0c:	f949d861 	ldr	x1, [x3, #5040]
    ae10:	f949ec60 	ldr	x0, [x3, #5080]
    ae14:	cb0102a1 	sub	x1, x21, x1
    ae18:	eb00403f 	cmp	x1, x0, lsl #16
    ae1c:	54000322 	b.cs	ae80 <f0+0x15fc>  // b.hs, b.nlast
    ae20:	d350fc22 	lsr	x2, x1, #16
    ae24:	f949fc63 	ldr	x3, [x3, #5112]
    ae28:	8b020842 	add	x2, x2, x2, lsl #2
    ae2c:	d37df042 	lsl	x2, x2, #3
    ae30:	8b020060 	add	x0, x3, x2
    ae34:	f9401017 	ldr	x23, [x0, #32]
    ae38:	b4000257 	cbz	x23, ae80 <f0+0x15fc>
    ae3c:	38626862 	ldrb	w2, [x3, x2]
    ae40:	7100085f 	cmp	w2, #0x2
    ae44:	54007500 	b.eq	bce4 <f0+0x2460>  // b.none
    ae48:	7100045f 	cmp	w2, #0x1
    ae4c:	540001a1 	b.ne	ae80 <f0+0x15fc>  // b.any
    ae50:	29430002 	ldp	w2, w0, [x0, #24]
    ae54:	92403c21 	and	x1, x1, #0xffff
    ae58:	9b027c21 	mul	x1, x1, x2
    ae5c:	d360fc21 	lsr	x1, x1, #32
    ae60:	eb00003f 	cmp	x1, x0
    ae64:	540000e2 	b.cs	ae80 <f0+0x15fc>  // b.hs, b.nlast
    ae68:	8b0102f7 	add	x23, x23, x1
    ae6c:	394002e0 	ldrb	w0, [x23]
    ae70:	7103fc1f 	cmp	w0, #0xff
    ae74:	54007e60 	b.eq	be40 <f0+0x25bc>  // b.none
    ae78:	52800020 	mov	w0, #0x1                   	// #1
    ae7c:	390002e0 	strb	w0, [x23]
    ae80:	911423e1 	add	x1, sp, #0x508
    ae84:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ae88:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ae8c:	52800020 	mov	w0, #0x1                   	// #1
    ae90:	f90287f7 	str	x23, [sp, #1288]
    ae94:	f9028bf5 	str	x21, [sp, #1296]
    ae98:	97ffe7bb 	bl	4d84 <fwp_data.part.0.constprop.0>
    ae9c:	97ffe91e 	bl	5314 <fwp_rc_fresh>
    aea0:	aa0003e2 	mov	x2, x0
    aea4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aea8:	911463e1 	add	x1, sp, #0x518
    aeac:	52800020 	mov	w0, #0x1                   	// #1
    aeb0:	f9028fe3 	str	x3, [sp, #1304]
    aeb4:	f90293e2 	str	x2, [sp, #1312]
    aeb8:	97ffe7b3 	bl	4d84 <fwp_data.part.0.constprop.0>
    aebc:	97ffe916 	bl	5314 <fwp_rc_fresh>
    aec0:	aa0003e2 	mov	x2, x0
    aec4:	9114a3e1 	add	x1, sp, #0x528
    aec8:	52800020 	mov	w0, #0x1                   	// #1
    aecc:	f90297f7 	str	x23, [sp, #1320]
    aed0:	f9029be2 	str	x2, [sp, #1328]
    aed4:	97ffe7ac 	bl	4d84 <fwp_data.part.0.constprop.0>
    aed8:	91150283 	add	x3, x20, #0x540
    aedc:	aa0003f5 	mov	x21, x0
    aee0:	f949d861 	ldr	x1, [x3, #5040]
    aee4:	f949ec60 	ldr	x0, [x3, #5080]
    aee8:	cb0102a1 	sub	x1, x21, x1
    aeec:	eb00403f 	cmp	x1, x0, lsl #16
    aef0:	54000322 	b.cs	af54 <f0+0x16d0>  // b.hs, b.nlast
    aef4:	d350fc22 	lsr	x2, x1, #16
    aef8:	f949fc63 	ldr	x3, [x3, #5112]
    aefc:	8b020842 	add	x2, x2, x2, lsl #2
    af00:	d37df042 	lsl	x2, x2, #3
    af04:	8b020060 	add	x0, x3, x2
    af08:	f9401017 	ldr	x23, [x0, #32]
    af0c:	b4000257 	cbz	x23, af54 <f0+0x16d0>
    af10:	38626862 	ldrb	w2, [x3, x2]
    af14:	7100085f 	cmp	w2, #0x2
    af18:	54006e00 	b.eq	bcd8 <f0+0x2454>  // b.none
    af1c:	7100045f 	cmp	w2, #0x1
    af20:	540001a1 	b.ne	af54 <f0+0x16d0>  // b.any
    af24:	29430002 	ldp	w2, w0, [x0, #24]
    af28:	92403c21 	and	x1, x1, #0xffff
    af2c:	9b027c21 	mul	x1, x1, x2
    af30:	d360fc21 	lsr	x1, x1, #32
    af34:	eb00003f 	cmp	x1, x0
    af38:	540000e2 	b.cs	af54 <f0+0x16d0>  // b.hs, b.nlast
    af3c:	8b0102f7 	add	x23, x23, x1
    af40:	394002e0 	ldrb	w0, [x23]
    af44:	7103fc1f 	cmp	w0, #0xff
    af48:	54007820 	b.eq	be4c <f0+0x25c8>  // b.none
    af4c:	52800020 	mov	w0, #0x1                   	// #1
    af50:	390002e0 	strb	w0, [x23]
    af54:	9114e3e1 	add	x1, sp, #0x538
    af58:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af5c:	52800020 	mov	w0, #0x1                   	// #1
    af60:	f9029ff7 	str	x23, [sp, #1336]
    af64:	f902a3f5 	str	x21, [sp, #1344]
    af68:	97ffe787 	bl	4d84 <fwp_data.part.0.constprop.0>
    af6c:	97ffe8ea 	bl	5314 <fwp_rc_fresh>
    af70:	aa0003e2 	mov	x2, x0
    af74:	911523e1 	add	x1, sp, #0x548
    af78:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    af7c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    af80:	52800020 	mov	w0, #0x1                   	// #1
    af84:	f902a7f5 	str	x21, [sp, #1352]
    af88:	f902abe2 	str	x2, [sp, #1360]
    af8c:	97ffe77e 	bl	4d84 <fwp_data.part.0.constprop.0>
    af90:	97ffe8e1 	bl	5314 <fwp_rc_fresh>
    af94:	aa0003e2 	mov	x2, x0
    af98:	911563e1 	add	x1, sp, #0x558
    af9c:	52800020 	mov	w0, #0x1                   	// #1
    afa0:	f902aff7 	str	x23, [sp, #1368]
    afa4:	f902b3e2 	str	x2, [sp, #1376]
    afa8:	97ffe777 	bl	4d84 <fwp_data.part.0.constprop.0>
    afac:	97ffe8da 	bl	5314 <fwp_rc_fresh>
    afb0:	aa0003e2 	mov	x2, x0
    afb4:	9115a3e1 	add	x1, sp, #0x568
    afb8:	52800020 	mov	w0, #0x1                   	// #1
    afbc:	f902b7f5 	str	x21, [sp, #1384]
    afc0:	f902bbe2 	str	x2, [sp, #1392]
    afc4:	97ffe770 	bl	4d84 <fwp_data.part.0.constprop.0>
    afc8:	97ffe8d3 	bl	5314 <fwp_rc_fresh>
    afcc:	aa0003e2 	mov	x2, x0
    afd0:	9115e3e1 	add	x1, sp, #0x578
    afd4:	52800020 	mov	w0, #0x1                   	// #1
    afd8:	f902bff7 	str	x23, [sp, #1400]
    afdc:	f902c3e2 	str	x2, [sp, #1408]
    afe0:	97ffe769 	bl	4d84 <fwp_data.part.0.constprop.0>
    afe4:	91150283 	add	x3, x20, #0x540
    afe8:	aa0003f5 	mov	x21, x0
    afec:	f949d861 	ldr	x1, [x3, #5040]
    aff0:	f949ec60 	ldr	x0, [x3, #5080]
    aff4:	cb0102a1 	sub	x1, x21, x1
    aff8:	eb00403f 	cmp	x1, x0, lsl #16
    affc:	54000322 	b.cs	b060 <f0+0x17dc>  // b.hs, b.nlast
    b000:	d350fc22 	lsr	x2, x1, #16
    b004:	f949fc63 	ldr	x3, [x3, #5112]
    b008:	8b020842 	add	x2, x2, x2, lsl #2
    b00c:	d37df042 	lsl	x2, x2, #3
    b010:	8b020060 	add	x0, x3, x2
    b014:	f9401017 	ldr	x23, [x0, #32]
    b018:	b4000257 	cbz	x23, b060 <f0+0x17dc>
    b01c:	38626862 	ldrb	w2, [x3, x2]
    b020:	7100085f 	cmp	w2, #0x2
    b024:	54006540 	b.eq	bccc <f0+0x2448>  // b.none
    b028:	7100045f 	cmp	w2, #0x1
    b02c:	540001a1 	b.ne	b060 <f0+0x17dc>  // b.any
    b030:	29430002 	ldp	w2, w0, [x0, #24]
    b034:	92403c21 	and	x1, x1, #0xffff
    b038:	9b027c21 	mul	x1, x1, x2
    b03c:	d360fc21 	lsr	x1, x1, #32
    b040:	eb00003f 	cmp	x1, x0
    b044:	540000e2 	b.cs	b060 <f0+0x17dc>  // b.hs, b.nlast
    b048:	8b0102f7 	add	x23, x23, x1
    b04c:	394002e0 	ldrb	w0, [x23]
    b050:	7103fc1f 	cmp	w0, #0xff
    b054:	54007020 	b.eq	be58 <f0+0x25d4>  // b.none
    b058:	52800020 	mov	w0, #0x1                   	// #1
    b05c:	390002e0 	strb	w0, [x23]
    b060:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b064:	911623e1 	add	x1, sp, #0x588
    b068:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b06c:	52800020 	mov	w0, #0x1                   	// #1
    b070:	f902c7e2 	str	x2, [sp, #1416]
    b074:	f902cbf5 	str	x21, [sp, #1424]
    b078:	97ffe743 	bl	4d84 <fwp_data.part.0.constprop.0>
    b07c:	97ffe8a6 	bl	5314 <fwp_rc_fresh>
    b080:	aa0003e2 	mov	x2, x0
    b084:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b088:	911663e1 	add	x1, sp, #0x598
    b08c:	52800020 	mov	w0, #0x1                   	// #1
    b090:	f902cfe3 	str	x3, [sp, #1432]
    b094:	f902d3e2 	str	x2, [sp, #1440]
    b098:	97ffe73b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b09c:	91150283 	add	x3, x20, #0x540
    b0a0:	aa0003f5 	mov	x21, x0
    b0a4:	f949d861 	ldr	x1, [x3, #5040]
    b0a8:	f949ec60 	ldr	x0, [x3, #5080]
    b0ac:	cb0102a1 	sub	x1, x21, x1
    b0b0:	eb00403f 	cmp	x1, x0, lsl #16
    b0b4:	54000322 	b.cs	b118 <f0+0x1894>  // b.hs, b.nlast
    b0b8:	d350fc22 	lsr	x2, x1, #16
    b0bc:	f949fc63 	ldr	x3, [x3, #5112]
    b0c0:	8b020842 	add	x2, x2, x2, lsl #2
    b0c4:	d37df042 	lsl	x2, x2, #3
    b0c8:	8b020060 	add	x0, x3, x2
    b0cc:	f9401017 	ldr	x23, [x0, #32]
    b0d0:	b4000257 	cbz	x23, b118 <f0+0x1894>
    b0d4:	38626862 	ldrb	w2, [x3, x2]
    b0d8:	7100085f 	cmp	w2, #0x2
    b0dc:	54005f20 	b.eq	bcc0 <f0+0x243c>  // b.none
    b0e0:	7100045f 	cmp	w2, #0x1
    b0e4:	540001a1 	b.ne	b118 <f0+0x1894>  // b.any
    b0e8:	29430002 	ldp	w2, w0, [x0, #24]
    b0ec:	92403c21 	and	x1, x1, #0xffff
    b0f0:	9b027c21 	mul	x1, x1, x2
    b0f4:	d360fc21 	lsr	x1, x1, #32
    b0f8:	eb00003f 	cmp	x1, x0
    b0fc:	540000e2 	b.cs	b118 <f0+0x1894>  // b.hs, b.nlast
    b100:	8b0102f7 	add	x23, x23, x1
    b104:	394002e0 	ldrb	w0, [x23]
    b108:	7103fc1f 	cmp	w0, #0xff
    b10c:	54006ac0 	b.eq	be64 <f0+0x25e0>  // b.none
    b110:	52800020 	mov	w0, #0x1                   	// #1
    b114:	390002e0 	strb	w0, [x23]
    b118:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b11c:	9116a3e1 	add	x1, sp, #0x5a8
    b120:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b124:	52800020 	mov	w0, #0x1                   	// #1
    b128:	f902d7e2 	str	x2, [sp, #1448]
    b12c:	f902dbf5 	str	x21, [sp, #1456]
    b130:	97ffe715 	bl	4d84 <fwp_data.part.0.constprop.0>
    b134:	91150283 	add	x3, x20, #0x540
    b138:	aa0003f5 	mov	x21, x0
    b13c:	f949d861 	ldr	x1, [x3, #5040]
    b140:	f949ec60 	ldr	x0, [x3, #5080]
    b144:	cb0102a1 	sub	x1, x21, x1
    b148:	eb00403f 	cmp	x1, x0, lsl #16
    b14c:	54000322 	b.cs	b1b0 <f0+0x192c>  // b.hs, b.nlast
    b150:	d350fc22 	lsr	x2, x1, #16
    b154:	f949fc63 	ldr	x3, [x3, #5112]
    b158:	8b020842 	add	x2, x2, x2, lsl #2
    b15c:	d37df042 	lsl	x2, x2, #3
    b160:	8b020060 	add	x0, x3, x2
    b164:	f9401017 	ldr	x23, [x0, #32]
    b168:	b4000257 	cbz	x23, b1b0 <f0+0x192c>
    b16c:	38626862 	ldrb	w2, [x3, x2]
    b170:	7100085f 	cmp	w2, #0x2
    b174:	54005a00 	b.eq	bcb4 <f0+0x2430>  // b.none
    b178:	7100045f 	cmp	w2, #0x1
    b17c:	540001a1 	b.ne	b1b0 <f0+0x192c>  // b.any
    b180:	29430002 	ldp	w2, w0, [x0, #24]
    b184:	92403c21 	and	x1, x1, #0xffff
    b188:	9b027c21 	mul	x1, x1, x2
    b18c:	d360fc21 	lsr	x1, x1, #32
    b190:	eb00003f 	cmp	x1, x0
    b194:	540000e2 	b.cs	b1b0 <f0+0x192c>  // b.hs, b.nlast
    b198:	8b0102f7 	add	x23, x23, x1
    b19c:	394002e0 	ldrb	w0, [x23]
    b1a0:	7103fc1f 	cmp	w0, #0xff
    b1a4:	54006660 	b.eq	be70 <f0+0x25ec>  // b.none
    b1a8:	52800020 	mov	w0, #0x1                   	// #1
    b1ac:	390002e0 	strb	w0, [x23]
    b1b0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b1b4:	9116e3e1 	add	x1, sp, #0x5b8
    b1b8:	52800020 	mov	w0, #0x1                   	// #1
    b1bc:	f902dfe2 	str	x2, [sp, #1464]
    b1c0:	f902e3f5 	str	x21, [sp, #1472]
    b1c4:	97ffe6f0 	bl	4d84 <fwp_data.part.0.constprop.0>
    b1c8:	91150283 	add	x3, x20, #0x540
    b1cc:	aa0003f7 	mov	x23, x0
    b1d0:	f949d861 	ldr	x1, [x3, #5040]
    b1d4:	f949ec60 	ldr	x0, [x3, #5080]
    b1d8:	cb0102e1 	sub	x1, x23, x1
    b1dc:	eb00403f 	cmp	x1, x0, lsl #16
    b1e0:	54000322 	b.cs	b244 <f0+0x19c0>  // b.hs, b.nlast
    b1e4:	d350fc22 	lsr	x2, x1, #16
    b1e8:	f949fc63 	ldr	x3, [x3, #5112]
    b1ec:	8b020842 	add	x2, x2, x2, lsl #2
    b1f0:	d37df042 	lsl	x2, x2, #3
    b1f4:	8b020060 	add	x0, x3, x2
    b1f8:	f9401015 	ldr	x21, [x0, #32]
    b1fc:	b4000255 	cbz	x21, b244 <f0+0x19c0>
    b200:	38626862 	ldrb	w2, [x3, x2]
    b204:	7100085f 	cmp	w2, #0x2
    b208:	54005500 	b.eq	bca8 <f0+0x2424>  // b.none
    b20c:	7100045f 	cmp	w2, #0x1
    b210:	540001a1 	b.ne	b244 <f0+0x19c0>  // b.any
    b214:	29430002 	ldp	w2, w0, [x0, #24]
    b218:	92403c21 	and	x1, x1, #0xffff
    b21c:	9b027c21 	mul	x1, x1, x2
    b220:	d360fc21 	lsr	x1, x1, #32
    b224:	eb00003f 	cmp	x1, x0
    b228:	540000e2 	b.cs	b244 <f0+0x19c0>  // b.hs, b.nlast
    b22c:	8b0102b5 	add	x21, x21, x1
    b230:	394002a0 	ldrb	w0, [x21]
    b234:	7103fc1f 	cmp	w0, #0xff
    b238:	54006220 	b.eq	be7c <f0+0x25f8>  // b.none
    b23c:	52800020 	mov	w0, #0x1                   	// #1
    b240:	390002a0 	strb	w0, [x21]
    b244:	911723e1 	add	x1, sp, #0x5c8
    b248:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b24c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b250:	52800020 	mov	w0, #0x1                   	// #1
    b254:	f902e7f5 	str	x21, [sp, #1480]
    b258:	f902ebf7 	str	x23, [sp, #1488]
    b25c:	97ffe6ca 	bl	4d84 <fwp_data.part.0.constprop.0>
    b260:	97ffe82d 	bl	5314 <fwp_rc_fresh>
    b264:	aa0003e2 	mov	x2, x0
    b268:	911763e1 	add	x1, sp, #0x5d8
    b26c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b270:	52800020 	mov	w0, #0x1                   	// #1
    b274:	f902eff7 	str	x23, [sp, #1496]
    b278:	f902f3e2 	str	x2, [sp, #1504]
    b27c:	97ffe6c2 	bl	4d84 <fwp_data.part.0.constprop.0>
    b280:	97ffe825 	bl	5314 <fwp_rc_fresh>
    b284:	aa0003e2 	mov	x2, x0
    b288:	9117a3e1 	add	x1, sp, #0x5e8
    b28c:	52800020 	mov	w0, #0x1                   	// #1
    b290:	f902f7f5 	str	x21, [sp, #1512]
    b294:	f902fbe2 	str	x2, [sp, #1520]
    b298:	97ffe6bb 	bl	4d84 <fwp_data.part.0.constprop.0>
    b29c:	97ffe81e 	bl	5314 <fwp_rc_fresh>
    b2a0:	aa0003e2 	mov	x2, x0
    b2a4:	9117e3e1 	add	x1, sp, #0x5f8
    b2a8:	52800020 	mov	w0, #0x1                   	// #1
    b2ac:	f902fff7 	str	x23, [sp, #1528]
    b2b0:	f90303e2 	str	x2, [sp, #1536]
    b2b4:	97ffe6b4 	bl	4d84 <fwp_data.part.0.constprop.0>
    b2b8:	97ffe817 	bl	5314 <fwp_rc_fresh>
    b2bc:	aa0003e2 	mov	x2, x0
    b2c0:	911823e1 	add	x1, sp, #0x608
    b2c4:	52800020 	mov	w0, #0x1                   	// #1
    b2c8:	f90307f5 	str	x21, [sp, #1544]
    b2cc:	f9030be2 	str	x2, [sp, #1552]
    b2d0:	97ffe6ad 	bl	4d84 <fwp_data.part.0.constprop.0>
    b2d4:	97ffe810 	bl	5314 <fwp_rc_fresh>
    b2d8:	aa0003e2 	mov	x2, x0
    b2dc:	911863e1 	add	x1, sp, #0x618
    b2e0:	52800020 	mov	w0, #0x1                   	// #1
    b2e4:	f9030ff7 	str	x23, [sp, #1560]
    b2e8:	f90313e2 	str	x2, [sp, #1568]
    b2ec:	97ffe6a6 	bl	4d84 <fwp_data.part.0.constprop.0>
    b2f0:	97ffe809 	bl	5314 <fwp_rc_fresh>
    b2f4:	aa0003e2 	mov	x2, x0
    b2f8:	9118a3e1 	add	x1, sp, #0x628
    b2fc:	52800020 	mov	w0, #0x1                   	// #1
    b300:	f90317f5 	str	x21, [sp, #1576]
    b304:	f9031be2 	str	x2, [sp, #1584]
    b308:	97ffe69f 	bl	4d84 <fwp_data.part.0.constprop.0>
    b30c:	91150283 	add	x3, x20, #0x540
    b310:	aa0003f5 	mov	x21, x0
    b314:	f949d861 	ldr	x1, [x3, #5040]
    b318:	f949ec60 	ldr	x0, [x3, #5080]
    b31c:	cb0102a1 	sub	x1, x21, x1
    b320:	eb00403f 	cmp	x1, x0, lsl #16
    b324:	54000322 	b.cs	b388 <f0+0x1b04>  // b.hs, b.nlast
    b328:	d350fc22 	lsr	x2, x1, #16
    b32c:	f949fc63 	ldr	x3, [x3, #5112]
    b330:	8b020842 	add	x2, x2, x2, lsl #2
    b334:	d37df042 	lsl	x2, x2, #3
    b338:	8b020060 	add	x0, x3, x2
    b33c:	f9401017 	ldr	x23, [x0, #32]
    b340:	b4000257 	cbz	x23, b388 <f0+0x1b04>
    b344:	38626862 	ldrb	w2, [x3, x2]
    b348:	7100085f 	cmp	w2, #0x2
    b34c:	54004a80 	b.eq	bc9c <f0+0x2418>  // b.none
    b350:	7100045f 	cmp	w2, #0x1
    b354:	540001a1 	b.ne	b388 <f0+0x1b04>  // b.any
    b358:	29430002 	ldp	w2, w0, [x0, #24]
    b35c:	92403c21 	and	x1, x1, #0xffff
    b360:	9b027c21 	mul	x1, x1, x2
    b364:	d360fc21 	lsr	x1, x1, #32
    b368:	eb00003f 	cmp	x1, x0
    b36c:	540000e2 	b.cs	b388 <f0+0x1b04>  // b.hs, b.nlast
    b370:	8b0102f7 	add	x23, x23, x1
    b374:	394002e0 	ldrb	w0, [x23]
    b378:	7103fc1f 	cmp	w0, #0xff
    b37c:	54005860 	b.eq	be88 <f0+0x2604>  // b.none
    b380:	52800020 	mov	w0, #0x1                   	// #1
    b384:	390002e0 	strb	w0, [x23]
    b388:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b38c:	9118e3e1 	add	x1, sp, #0x638
    b390:	52800020 	mov	w0, #0x1                   	// #1
    b394:	f9031fe2 	str	x2, [sp, #1592]
    b398:	f90323f5 	str	x21, [sp, #1600]
    b39c:	97ffe67a 	bl	4d84 <fwp_data.part.0.constprop.0>
    b3a0:	91150283 	add	x3, x20, #0x540
    b3a4:	aa0003f5 	mov	x21, x0
    b3a8:	f949d861 	ldr	x1, [x3, #5040]
    b3ac:	f949ec60 	ldr	x0, [x3, #5080]
    b3b0:	cb0102a1 	sub	x1, x21, x1
    b3b4:	eb00403f 	cmp	x1, x0, lsl #16
    b3b8:	54000322 	b.cs	b41c <f0+0x1b98>  // b.hs, b.nlast
    b3bc:	d350fc22 	lsr	x2, x1, #16
    b3c0:	f949fc63 	ldr	x3, [x3, #5112]
    b3c4:	8b020842 	add	x2, x2, x2, lsl #2
    b3c8:	d37df042 	lsl	x2, x2, #3
    b3cc:	8b020060 	add	x0, x3, x2
    b3d0:	f9401017 	ldr	x23, [x0, #32]
    b3d4:	b4000257 	cbz	x23, b41c <f0+0x1b98>
    b3d8:	38626862 	ldrb	w2, [x3, x2]
    b3dc:	7100085f 	cmp	w2, #0x2
    b3e0:	54004580 	b.eq	bc90 <f0+0x240c>  // b.none
    b3e4:	7100045f 	cmp	w2, #0x1
    b3e8:	540001a1 	b.ne	b41c <f0+0x1b98>  // b.any
    b3ec:	29430002 	ldp	w2, w0, [x0, #24]
    b3f0:	92403c21 	and	x1, x1, #0xffff
    b3f4:	9b027c21 	mul	x1, x1, x2
    b3f8:	d360fc21 	lsr	x1, x1, #32
    b3fc:	eb00003f 	cmp	x1, x0
    b400:	540000e2 	b.cs	b41c <f0+0x1b98>  // b.hs, b.nlast
    b404:	8b0102f7 	add	x23, x23, x1
    b408:	394002e0 	ldrb	w0, [x23]
    b40c:	7103fc1f 	cmp	w0, #0xff
    b410:	54005420 	b.eq	be94 <f0+0x2610>  // b.none
    b414:	52800020 	mov	w0, #0x1                   	// #1
    b418:	390002e0 	strb	w0, [x23]
    b41c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b420:	911923e1 	add	x1, sp, #0x648
    b424:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b428:	52800020 	mov	w0, #0x1                   	// #1
    b42c:	f90327e2 	str	x2, [sp, #1608]
    b430:	f9032bf5 	str	x21, [sp, #1616]
    b434:	97ffe654 	bl	4d84 <fwp_data.part.0.constprop.0>
    b438:	97ffe7b7 	bl	5314 <fwp_rc_fresh>
    b43c:	aa0003e2 	mov	x2, x0
    b440:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b444:	911963e1 	add	x1, sp, #0x658
    b448:	52800020 	mov	w0, #0x1                   	// #1
    b44c:	f9032fe3 	str	x3, [sp, #1624]
    b450:	f90333e2 	str	x2, [sp, #1632]
    b454:	97ffe64c 	bl	4d84 <fwp_data.part.0.constprop.0>
    b458:	91150283 	add	x3, x20, #0x540
    b45c:	aa0003f5 	mov	x21, x0
    b460:	f949d861 	ldr	x1, [x3, #5040]
    b464:	f949ec60 	ldr	x0, [x3, #5080]
    b468:	cb0102a1 	sub	x1, x21, x1
    b46c:	eb00403f 	cmp	x1, x0, lsl #16
    b470:	54000322 	b.cs	b4d4 <f0+0x1c50>  // b.hs, b.nlast
    b474:	d350fc22 	lsr	x2, x1, #16
    b478:	f949fc63 	ldr	x3, [x3, #5112]
    b47c:	8b020842 	add	x2, x2, x2, lsl #2
    b480:	d37df042 	lsl	x2, x2, #3
    b484:	8b020060 	add	x0, x3, x2
    b488:	f9401017 	ldr	x23, [x0, #32]
    b48c:	b4000257 	cbz	x23, b4d4 <f0+0x1c50>
    b490:	38626862 	ldrb	w2, [x3, x2]
    b494:	7100085f 	cmp	w2, #0x2
    b498:	54003f60 	b.eq	bc84 <f0+0x2400>  // b.none
    b49c:	7100045f 	cmp	w2, #0x1
    b4a0:	540001a1 	b.ne	b4d4 <f0+0x1c50>  // b.any
    b4a4:	29430002 	ldp	w2, w0, [x0, #24]
    b4a8:	92403c21 	and	x1, x1, #0xffff
    b4ac:	9b027c21 	mul	x1, x1, x2
    b4b0:	d360fc21 	lsr	x1, x1, #32
    b4b4:	eb00003f 	cmp	x1, x0
    b4b8:	540000e2 	b.cs	b4d4 <f0+0x1c50>  // b.hs, b.nlast
    b4bc:	8b0102f7 	add	x23, x23, x1
    b4c0:	394002e0 	ldrb	w0, [x23]
    b4c4:	7103fc1f 	cmp	w0, #0xff
    b4c8:	54004ec0 	b.eq	bea0 <f0+0x261c>  // b.none
    b4cc:	52800020 	mov	w0, #0x1                   	// #1
    b4d0:	390002e0 	strb	w0, [x23]
    b4d4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b4d8:	9119a3e1 	add	x1, sp, #0x668
    b4dc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b4e0:	52800020 	mov	w0, #0x1                   	// #1
    b4e4:	f90337e2 	str	x2, [sp, #1640]
    b4e8:	f9033bf5 	str	x21, [sp, #1648]
    b4ec:	97ffe626 	bl	4d84 <fwp_data.part.0.constprop.0>
    b4f0:	97ffe789 	bl	5314 <fwp_rc_fresh>
    b4f4:	aa0003e2 	mov	x2, x0
    b4f8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b4fc:	9119e3e1 	add	x1, sp, #0x678
    b500:	52800020 	mov	w0, #0x1                   	// #1
    b504:	f9033fe3 	str	x3, [sp, #1656]
    b508:	f90343e2 	str	x2, [sp, #1664]
    b50c:	97ffe61e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b510:	91150283 	add	x3, x20, #0x540
    b514:	aa0003f5 	mov	x21, x0
    b518:	f949d861 	ldr	x1, [x3, #5040]
    b51c:	f949ec60 	ldr	x0, [x3, #5080]
    b520:	cb0102a1 	sub	x1, x21, x1
    b524:	eb00403f 	cmp	x1, x0, lsl #16
    b528:	54000322 	b.cs	b58c <f0+0x1d08>  // b.hs, b.nlast
    b52c:	d350fc22 	lsr	x2, x1, #16
    b530:	f949fc63 	ldr	x3, [x3, #5112]
    b534:	8b020842 	add	x2, x2, x2, lsl #2
    b538:	d37df042 	lsl	x2, x2, #3
    b53c:	8b020060 	add	x0, x3, x2
    b540:	f9401017 	ldr	x23, [x0, #32]
    b544:	b4000257 	cbz	x23, b58c <f0+0x1d08>
    b548:	38626862 	ldrb	w2, [x3, x2]
    b54c:	7100085f 	cmp	w2, #0x2
    b550:	54003940 	b.eq	bc78 <f0+0x23f4>  // b.none
    b554:	7100045f 	cmp	w2, #0x1
    b558:	540001a1 	b.ne	b58c <f0+0x1d08>  // b.any
    b55c:	29430002 	ldp	w2, w0, [x0, #24]
    b560:	92403c21 	and	x1, x1, #0xffff
    b564:	9b027c21 	mul	x1, x1, x2
    b568:	d360fc21 	lsr	x1, x1, #32
    b56c:	eb00003f 	cmp	x1, x0
    b570:	540000e2 	b.cs	b58c <f0+0x1d08>  // b.hs, b.nlast
    b574:	8b0102f7 	add	x23, x23, x1
    b578:	394002e0 	ldrb	w0, [x23]
    b57c:	7103fc1f 	cmp	w0, #0xff
    b580:	54004960 	b.eq	beac <f0+0x2628>  // b.none
    b584:	52800020 	mov	w0, #0x1                   	// #1
    b588:	390002e0 	strb	w0, [x23]
    b58c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b590:	911a23e1 	add	x1, sp, #0x688
    b594:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b598:	52800020 	mov	w0, #0x1                   	// #1
    b59c:	f90347e2 	str	x2, [sp, #1672]
    b5a0:	f9034bf5 	str	x21, [sp, #1680]
    b5a4:	97ffe5f8 	bl	4d84 <fwp_data.part.0.constprop.0>
    b5a8:	97ffe75b 	bl	5314 <fwp_rc_fresh>
    b5ac:	aa0003e2 	mov	x2, x0
    b5b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b5b4:	911a63e1 	add	x1, sp, #0x698
    b5b8:	52800020 	mov	w0, #0x1                   	// #1
    b5bc:	f9034fe3 	str	x3, [sp, #1688]
    b5c0:	f90353e2 	str	x2, [sp, #1696]
    b5c4:	97ffe5f0 	bl	4d84 <fwp_data.part.0.constprop.0>
    b5c8:	91150283 	add	x3, x20, #0x540
    b5cc:	aa0003f5 	mov	x21, x0
    b5d0:	f949d861 	ldr	x1, [x3, #5040]
    b5d4:	f949ec60 	ldr	x0, [x3, #5080]
    b5d8:	cb0102a1 	sub	x1, x21, x1
    b5dc:	eb00403f 	cmp	x1, x0, lsl #16
    b5e0:	54000322 	b.cs	b644 <f0+0x1dc0>  // b.hs, b.nlast
    b5e4:	d350fc22 	lsr	x2, x1, #16
    b5e8:	f949fc63 	ldr	x3, [x3, #5112]
    b5ec:	8b020842 	add	x2, x2, x2, lsl #2
    b5f0:	d37df042 	lsl	x2, x2, #3
    b5f4:	8b020060 	add	x0, x3, x2
    b5f8:	f9401017 	ldr	x23, [x0, #32]
    b5fc:	b4000257 	cbz	x23, b644 <f0+0x1dc0>
    b600:	38626862 	ldrb	w2, [x3, x2]
    b604:	7100085f 	cmp	w2, #0x2
    b608:	54003320 	b.eq	bc6c <f0+0x23e8>  // b.none
    b60c:	7100045f 	cmp	w2, #0x1
    b610:	540001a1 	b.ne	b644 <f0+0x1dc0>  // b.any
    b614:	29430002 	ldp	w2, w0, [x0, #24]
    b618:	92403c21 	and	x1, x1, #0xffff
    b61c:	9b027c21 	mul	x1, x1, x2
    b620:	d360fc21 	lsr	x1, x1, #32
    b624:	eb00003f 	cmp	x1, x0
    b628:	540000e2 	b.cs	b644 <f0+0x1dc0>  // b.hs, b.nlast
    b62c:	8b0102f7 	add	x23, x23, x1
    b630:	394002e0 	ldrb	w0, [x23]
    b634:	7103fc1f 	cmp	w0, #0xff
    b638:	54004400 	b.eq	beb8 <f0+0x2634>  // b.none
    b63c:	52800020 	mov	w0, #0x1                   	// #1
    b640:	390002e0 	strb	w0, [x23]
    b644:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b648:	911aa3e1 	add	x1, sp, #0x6a8
    b64c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b650:	52800020 	mov	w0, #0x1                   	// #1
    b654:	f90357e2 	str	x2, [sp, #1704]
    b658:	f9035bf5 	str	x21, [sp, #1712]
    b65c:	97ffe5ca 	bl	4d84 <fwp_data.part.0.constprop.0>
    b660:	91150283 	add	x3, x20, #0x540
    b664:	aa0003f5 	mov	x21, x0
    b668:	f949d861 	ldr	x1, [x3, #5040]
    b66c:	f949ec60 	ldr	x0, [x3, #5080]
    b670:	cb0102a1 	sub	x1, x21, x1
    b674:	eb00403f 	cmp	x1, x0, lsl #16
    b678:	54000322 	b.cs	b6dc <f0+0x1e58>  // b.hs, b.nlast
    b67c:	d350fc22 	lsr	x2, x1, #16
    b680:	f949fc63 	ldr	x3, [x3, #5112]
    b684:	8b020842 	add	x2, x2, x2, lsl #2
    b688:	d37df042 	lsl	x2, x2, #3
    b68c:	8b020060 	add	x0, x3, x2
    b690:	f9401017 	ldr	x23, [x0, #32]
    b694:	b4000257 	cbz	x23, b6dc <f0+0x1e58>
    b698:	38626862 	ldrb	w2, [x3, x2]
    b69c:	7100085f 	cmp	w2, #0x2
    b6a0:	54002e00 	b.eq	bc60 <f0+0x23dc>  // b.none
    b6a4:	7100045f 	cmp	w2, #0x1
    b6a8:	540001a1 	b.ne	b6dc <f0+0x1e58>  // b.any
    b6ac:	29430002 	ldp	w2, w0, [x0, #24]
    b6b0:	92403c21 	and	x1, x1, #0xffff
    b6b4:	9b027c21 	mul	x1, x1, x2
    b6b8:	d360fc21 	lsr	x1, x1, #32
    b6bc:	eb00003f 	cmp	x1, x0
    b6c0:	540000e2 	b.cs	b6dc <f0+0x1e58>  // b.hs, b.nlast
    b6c4:	8b0102f7 	add	x23, x23, x1
    b6c8:	394002e0 	ldrb	w0, [x23]
    b6cc:	7103fc1f 	cmp	w0, #0xff
    b6d0:	54003fa0 	b.eq	bec4 <f0+0x2640>  // b.none
    b6d4:	52800020 	mov	w0, #0x1                   	// #1
    b6d8:	390002e0 	strb	w0, [x23]
    b6dc:	911ae3e1 	add	x1, sp, #0x6b8
    b6e0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b6e4:	52800020 	mov	w0, #0x1                   	// #1
    b6e8:	f9035fe2 	str	x2, [sp, #1720]
    b6ec:	f90363f5 	str	x21, [sp, #1728]
    b6f0:	97ffe5a5 	bl	4d84 <fwp_data.part.0.constprop.0>
    b6f4:	97ffe708 	bl	5314 <fwp_rc_fresh>
    b6f8:	aa0003e2 	mov	x2, x0
    b6fc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b700:	911b23e1 	add	x1, sp, #0x6c8
    b704:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b708:	52800020 	mov	w0, #0x1                   	// #1
    b70c:	f90367e3 	str	x3, [sp, #1736]
    b710:	f9036be2 	str	x2, [sp, #1744]
    b714:	97ffe59c 	bl	4d84 <fwp_data.part.0.constprop.0>
    b718:	91150283 	add	x3, x20, #0x540
    b71c:	aa0003f5 	mov	x21, x0
    b720:	f949d861 	ldr	x1, [x3, #5040]
    b724:	f949ec60 	ldr	x0, [x3, #5080]
    b728:	cb0102a1 	sub	x1, x21, x1
    b72c:	eb00403f 	cmp	x1, x0, lsl #16
    b730:	54000322 	b.cs	b794 <f0+0x1f10>  // b.hs, b.nlast
    b734:	d350fc22 	lsr	x2, x1, #16
    b738:	f949fc63 	ldr	x3, [x3, #5112]
    b73c:	8b020842 	add	x2, x2, x2, lsl #2
    b740:	d37df042 	lsl	x2, x2, #3
    b744:	8b020060 	add	x0, x3, x2
    b748:	f9401017 	ldr	x23, [x0, #32]
    b74c:	b4000257 	cbz	x23, b794 <f0+0x1f10>
    b750:	38626862 	ldrb	w2, [x3, x2]
    b754:	7100085f 	cmp	w2, #0x2
    b758:	540027e0 	b.eq	bc54 <f0+0x23d0>  // b.none
    b75c:	7100045f 	cmp	w2, #0x1
    b760:	540001a1 	b.ne	b794 <f0+0x1f10>  // b.any
    b764:	29430002 	ldp	w2, w0, [x0, #24]
    b768:	92403c21 	and	x1, x1, #0xffff
    b76c:	9b027c21 	mul	x1, x1, x2
    b770:	d360fc21 	lsr	x1, x1, #32
    b774:	eb00003f 	cmp	x1, x0
    b778:	540000e2 	b.cs	b794 <f0+0x1f10>  // b.hs, b.nlast
    b77c:	8b0102f7 	add	x23, x23, x1
    b780:	394002e0 	ldrb	w0, [x23]
    b784:	7103fc1f 	cmp	w0, #0xff
    b788:	54003a40 	b.eq	bed0 <f0+0x264c>  // b.none
    b78c:	52800020 	mov	w0, #0x1                   	// #1
    b790:	390002e0 	strb	w0, [x23]
    b794:	911b63e1 	add	x1, sp, #0x6d8
    b798:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b79c:	52800020 	mov	w0, #0x1                   	// #1
    b7a0:	f9036ff7 	str	x23, [sp, #1752]
    b7a4:	f90373f5 	str	x21, [sp, #1760]
    b7a8:	97ffe577 	bl	4d84 <fwp_data.part.0.constprop.0>
    b7ac:	97ffe6da 	bl	5314 <fwp_rc_fresh>
    b7b0:	aa0003e2 	mov	x2, x0
    b7b4:	911ba3e1 	add	x1, sp, #0x6e8
    b7b8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b7bc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b7c0:	52800020 	mov	w0, #0x1                   	// #1
    b7c4:	f90377f5 	str	x21, [sp, #1768]
    b7c8:	91150294 	add	x20, x20, #0x540
    b7cc:	f9037be2 	str	x2, [sp, #1776]
    b7d0:	97ffe56d 	bl	4d84 <fwp_data.part.0.constprop.0>
    b7d4:	97ffe6d0 	bl	5314 <fwp_rc_fresh>
    b7d8:	aa0003e2 	mov	x2, x0
    b7dc:	911be3e1 	add	x1, sp, #0x6f8
    b7e0:	52800020 	mov	w0, #0x1                   	// #1
    b7e4:	f9037ff7 	str	x23, [sp, #1784]
    b7e8:	f90383e2 	str	x2, [sp, #1792]
    b7ec:	97ffe566 	bl	4d84 <fwp_data.part.0.constprop.0>
    b7f0:	97ffe6c9 	bl	5314 <fwp_rc_fresh>
    b7f4:	aa0003e2 	mov	x2, x0
    b7f8:	911c23e1 	add	x1, sp, #0x708
    b7fc:	52800020 	mov	w0, #0x1                   	// #1
    b800:	f90387f5 	str	x21, [sp, #1800]
    b804:	f9038be2 	str	x2, [sp, #1808]
    b808:	97ffe55f 	bl	4d84 <fwp_data.part.0.constprop.0>
    b80c:	f949da81 	ldr	x1, [x20, #5040]
    b810:	aa0003f7 	mov	x23, x0
    b814:	f949ee80 	ldr	x0, [x20, #5080]
    b818:	cb0102e1 	sub	x1, x23, x1
    b81c:	eb00403f 	cmp	x1, x0, lsl #16
    b820:	54000322 	b.cs	b884 <f0+0x2000>  // b.hs, b.nlast
    b824:	d350fc22 	lsr	x2, x1, #16
    b828:	f949fe83 	ldr	x3, [x20, #5112]
    b82c:	8b020842 	add	x2, x2, x2, lsl #2
    b830:	d37df042 	lsl	x2, x2, #3
    b834:	8b020060 	add	x0, x3, x2
    b838:	f9401014 	ldr	x20, [x0, #32]
    b83c:	b4000254 	cbz	x20, b884 <f0+0x2000>
    b840:	38626862 	ldrb	w2, [x3, x2]
    b844:	7100085f 	cmp	w2, #0x2
    b848:	54002000 	b.eq	bc48 <f0+0x23c4>  // b.none
    b84c:	7100045f 	cmp	w2, #0x1
    b850:	540001a1 	b.ne	b884 <f0+0x2000>  // b.any
    b854:	29430002 	ldp	w2, w0, [x0, #24]
    b858:	92403c21 	and	x1, x1, #0xffff
    b85c:	9b027c21 	mul	x1, x1, x2
    b860:	d360fc21 	lsr	x1, x1, #32
    b864:	eb00003f 	cmp	x1, x0
    b868:	540000e2 	b.cs	b884 <f0+0x2000>  // b.hs, b.nlast
    b86c:	8b010294 	add	x20, x20, x1
    b870:	39400280 	ldrb	w0, [x20]
    b874:	7103fc1f 	cmp	w0, #0xff
    b878:	54002480 	b.eq	bd08 <f0+0x2484>  // b.none
    b87c:	52800020 	mov	w0, #0x1                   	// #1
    b880:	39000280 	strb	w0, [x20]
    b884:	911c63e1 	add	x1, sp, #0x718
    b888:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b88c:	52800020 	mov	w0, #0x1                   	// #1
    b890:	f9038ff5 	str	x21, [sp, #1816]
    b894:	f90393f7 	str	x23, [sp, #1824]
    b898:	97ffe53b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b89c:	97ffe69e 	bl	5314 <fwp_rc_fresh>
    b8a0:	aa0003e2 	mov	x2, x0
    b8a4:	911ca3e1 	add	x1, sp, #0x728
    b8a8:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    b8ac:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    b8b0:	52800020 	mov	w0, #0x1                   	// #1
    b8b4:	f90397f4 	str	x20, [sp, #1832]
    b8b8:	f9039be2 	str	x2, [sp, #1840]
    b8bc:	97ffe532 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8c0:	97ffe695 	bl	5314 <fwp_rc_fresh>
    b8c4:	aa0003e2 	mov	x2, x0
    b8c8:	911ce3e1 	add	x1, sp, #0x738
    b8cc:	52800020 	mov	w0, #0x1                   	// #1
    b8d0:	f9039ff5 	str	x21, [sp, #1848]
    b8d4:	f903a3e2 	str	x2, [sp, #1856]
    b8d8:	97ffe52b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8dc:	97ffe68e 	bl	5314 <fwp_rc_fresh>
    b8e0:	aa0003e2 	mov	x2, x0
    b8e4:	911d23e1 	add	x1, sp, #0x748
    b8e8:	52800020 	mov	w0, #0x1                   	// #1
    b8ec:	f903a7f4 	str	x20, [sp, #1864]
    b8f0:	f903abe2 	str	x2, [sp, #1872]
    b8f4:	97ffe524 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8f8:	97ffe687 	bl	5314 <fwp_rc_fresh>
    b8fc:	aa0003e2 	mov	x2, x0
    b900:	911d63e1 	add	x1, sp, #0x758
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	f903aff5 	str	x21, [sp, #1880]
    b90c:	f903b3e2 	str	x2, [sp, #1888]
    b910:	97ffe51d 	bl	4d84 <fwp_data.part.0.constprop.0>
    b914:	97ffe680 	bl	5314 <fwp_rc_fresh>
    b918:	aa0003e2 	mov	x2, x0
    b91c:	911da3e1 	add	x1, sp, #0x768
    b920:	52800020 	mov	w0, #0x1                   	// #1
    b924:	f903b7f4 	str	x20, [sp, #1896]
    b928:	f903bbe2 	str	x2, [sp, #1904]
    b92c:	97ffe516 	bl	4d84 <fwp_data.part.0.constprop.0>
    b930:	97ffe679 	bl	5314 <fwp_rc_fresh>
    b934:	aa0003e2 	mov	x2, x0
    b938:	911de3e1 	add	x1, sp, #0x778
    b93c:	52800020 	mov	w0, #0x1                   	// #1
    b940:	f903bff5 	str	x21, [sp, #1912]
    b944:	f903c3e2 	str	x2, [sp, #1920]
    b948:	97ffe50f 	bl	4d84 <fwp_data.part.0.constprop.0>
    b94c:	97ffe672 	bl	5314 <fwp_rc_fresh>
    b950:	aa0003e2 	mov	x2, x0
    b954:	911e23e1 	add	x1, sp, #0x788
    b958:	52800020 	mov	w0, #0x1                   	// #1
    b95c:	f903c7f4 	str	x20, [sp, #1928]
    b960:	f903cbe2 	str	x2, [sp, #1936]
    b964:	97ffe508 	bl	4d84 <fwp_data.part.0.constprop.0>
    b968:	97ffe66b 	bl	5314 <fwp_rc_fresh>
    b96c:	aa0003e2 	mov	x2, x0
    b970:	911e63e1 	add	x1, sp, #0x798
    b974:	52800020 	mov	w0, #0x1                   	// #1
    b978:	f903cff5 	str	x21, [sp, #1944]
    b97c:	f903d3e2 	str	x2, [sp, #1952]
    b980:	97ffe501 	bl	4d84 <fwp_data.part.0.constprop.0>
    b984:	97ffe664 	bl	5314 <fwp_rc_fresh>
    b988:	aa0003e2 	mov	x2, x0
    b98c:	911ea3e1 	add	x1, sp, #0x7a8
    b990:	52800020 	mov	w0, #0x1                   	// #1
    b994:	f903d7f4 	str	x20, [sp, #1960]
    b998:	f903dbe2 	str	x2, [sp, #1968]
    b99c:	97ffe4fa 	bl	4d84 <fwp_data.part.0.constprop.0>
    b9a0:	97ffe65d 	bl	5314 <fwp_rc_fresh>
    b9a4:	aa0003e2 	mov	x2, x0
    b9a8:	911ee3e1 	add	x1, sp, #0x7b8
    b9ac:	52800020 	mov	w0, #0x1                   	// #1
    b9b0:	f903dff5 	str	x21, [sp, #1976]
    b9b4:	f903e3e2 	str	x2, [sp, #1984]
    b9b8:	97ffe4f3 	bl	4d84 <fwp_data.part.0.constprop.0>
    b9bc:	97ffe656 	bl	5314 <fwp_rc_fresh>
    b9c0:	aa0003e2 	mov	x2, x0
    b9c4:	911f23e1 	add	x1, sp, #0x7c8
    b9c8:	52800020 	mov	w0, #0x1                   	// #1
    b9cc:	f903e7f4 	str	x20, [sp, #1992]
    b9d0:	f903ebe2 	str	x2, [sp, #2000]
    b9d4:	97ffe4ec 	bl	4d84 <fwp_data.part.0.constprop.0>
    b9d8:	97ffe64f 	bl	5314 <fwp_rc_fresh>
    b9dc:	aa0003e2 	mov	x2, x0
    b9e0:	911f63e1 	add	x1, sp, #0x7d8
    b9e4:	52800020 	mov	w0, #0x1                   	// #1
    b9e8:	f903eff5 	str	x21, [sp, #2008]
    b9ec:	f903f3e2 	str	x2, [sp, #2016]
    b9f0:	97ffe4e5 	bl	4d84 <fwp_data.part.0.constprop.0>
    b9f4:	97ffe648 	bl	5314 <fwp_rc_fresh>
    b9f8:	aa0003e2 	mov	x2, x0
    b9fc:	911fa3e1 	add	x1, sp, #0x7e8
    ba00:	52800020 	mov	w0, #0x1                   	// #1
    ba04:	f903f7f4 	str	x20, [sp, #2024]
    ba08:	f903fbe2 	str	x2, [sp, #2032]
    ba0c:	97ffe4de 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba10:	97ffe641 	bl	5314 <fwp_rc_fresh>
    ba14:	aa0003e2 	mov	x2, x0
    ba18:	911fe3e1 	add	x1, sp, #0x7f8
    ba1c:	52800020 	mov	w0, #0x1                   	// #1
    ba20:	f903fff5 	str	x21, [sp, #2040]
    ba24:	f90403e2 	str	x2, [sp, #2048]
    ba28:	97ffe4d7 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba2c:	97ffe63a 	bl	5314 <fwp_rc_fresh>
    ba30:	aa0003e2 	mov	x2, x0
    ba34:	912023e1 	add	x1, sp, #0x808
    ba38:	52800020 	mov	w0, #0x1                   	// #1
    ba3c:	f90407f4 	str	x20, [sp, #2056]
    ba40:	f9040be2 	str	x2, [sp, #2064]
    ba44:	97ffe4d0 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba48:	97ffe633 	bl	5314 <fwp_rc_fresh>
    ba4c:	aa0003e2 	mov	x2, x0
    ba50:	912063e1 	add	x1, sp, #0x818
    ba54:	52800020 	mov	w0, #0x1                   	// #1
    ba58:	f9040ff5 	str	x21, [sp, #2072]
    ba5c:	f90413e2 	str	x2, [sp, #2080]
    ba60:	97ffe4c9 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba64:	97ffe62c 	bl	5314 <fwp_rc_fresh>
    ba68:	aa0003e2 	mov	x2, x0
    ba6c:	9120a3e1 	add	x1, sp, #0x828
    ba70:	52800020 	mov	w0, #0x1                   	// #1
    ba74:	f90417f4 	str	x20, [sp, #2088]
    ba78:	f9041be2 	str	x2, [sp, #2096]
    ba7c:	97ffe4c2 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba80:	97ffe625 	bl	5314 <fwp_rc_fresh>
    ba84:	aa0003e2 	mov	x2, x0
    ba88:	9120e3e1 	add	x1, sp, #0x838
    ba8c:	52800020 	mov	w0, #0x1                   	// #1
    ba90:	f9041ff5 	str	x21, [sp, #2104]
    ba94:	f90423e2 	str	x2, [sp, #2112]
    ba98:	97ffe4bb 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba9c:	97ffe61e 	bl	5314 <fwp_rc_fresh>
    baa0:	aa0003e2 	mov	x2, x0
    baa4:	aa1603e1 	mov	x1, x22
    baa8:	52800020 	mov	w0, #0x1                   	// #1
    baac:	f90427f4 	str	x20, [sp, #2120]
    bab0:	f9042be2 	str	x2, [sp, #2128]
    bab4:	97ffe4b4 	bl	4d84 <fwp_data.part.0.constprop.0>
    bab8:	97ffe617 	bl	5314 <fwp_rc_fresh>
    babc:	aa0003f5 	mov	x21, x0
    bac0:	aa1303e1 	mov	x1, x19
    bac4:	97fff0bf 	bl	7dc0 <fwp_hof0.constprop.0>
    bac8:	aa0003f4 	mov	x20, x0
    bacc:	aa1503e0 	mov	x0, x21
    bad0:	97ffe76c 	bl	5880 <fwp_drop0>
    bad4:	aa1303e0 	mov	x0, x19
    bad8:	97ffe76a 	bl	5880 <fwp_drop0>
    badc:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bae0:	f947f400 	ldr	x0, [x0, #4072]
    bae4:	f9442fe2 	ldr	x2, [sp, #2136]
    bae8:	f9400001 	ldr	x1, [x0]
    baec:	eb010042 	subs	x2, x2, x1
    baf0:	d2800001 	mov	x1, #0x0                   	// #0
    baf4:	54001f41 	b.ne	bedc <f0+0x2658>  // b.any
    baf8:	912183ff 	add	sp, sp, #0x860
    bafc:	aa1403e0 	mov	x0, x20
    bb00:	a94153f3 	ldp	x19, x20, [sp, #16]
    bb04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    bb08:	a94363f7 	ldp	x23, x24, [sp, #48]
    bb0c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    bb10:	a94573fb 	ldp	x27, x28, [sp, #80]
    bb14:	a8c67bfd 	ldp	x29, x30, [sp], #96
    bb18:	d65f03c0 	ret
    bb1c:	aa1b03e0 	mov	x0, x27
    bb20:	97ffe294 	bl	4570 <fwp_rc_forget_slot>
    bb24:	17fff7a1 	b	99a8 <f0+0x124>
    bb28:	72003c5f 	tst	w2, #0xffff
    bb2c:	54fef401 	b.ne	99ac <f0+0x128>  // b.any
    bb30:	17fff79b 	b	999c <f0+0x118>
    bb34:	72003c3f 	tst	w1, #0xffff
    bb38:	54ff83c1 	b.ne	abb0 <f0+0x132c>  // b.any
    bb3c:	17fffc18 	b	ab9c <f0+0x1318>
    bb40:	72003c3f 	tst	w1, #0xffff
    bb44:	54ff7ec1 	b.ne	ab1c <f0+0x1298>  // b.any
    bb48:	17fffbf0 	b	ab08 <f0+0x1284>
    bb4c:	72003c3f 	tst	w1, #0xffff
    bb50:	54ff7441 	b.ne	a9d8 <f0+0x1154>  // b.any
    bb54:	17fffb9c 	b	a9c4 <f0+0x1140>
    bb58:	72003c3f 	tst	w1, #0xffff
    bb5c:	54ff6e21 	b.ne	a920 <f0+0x109c>  // b.any
    bb60:	17fffb6b 	b	a90c <f0+0x1088>
    bb64:	72003c3f 	tst	w1, #0xffff
    bb68:	54ff6801 	b.ne	a868 <f0+0xfe4>  // b.any
    bb6c:	17fffb3a 	b	a854 <f0+0xfd0>
    bb70:	72003c3f 	tst	w1, #0xffff
    bb74:	54ff6021 	b.ne	a778 <f0+0xef4>  // b.any
    bb78:	17fffafb 	b	a764 <f0+0xee0>
    bb7c:	72003c3f 	tst	w1, #0xffff
    bb80:	54ff54c1 	b.ne	a618 <f0+0xd94>  // b.any
    bb84:	17fffaa0 	b	a604 <f0+0xd80>
    bb88:	72003c3f 	tst	w1, #0xffff
    bb8c:	54ff4ea1 	b.ne	a560 <f0+0xcdc>  // b.any
    bb90:	17fffa6f 	b	a54c <f0+0xcc8>
    bb94:	72003c3f 	tst	w1, #0xffff
    bb98:	54ff0621 	b.ne	9c5c <f0+0x3d8>  // b.any
    bb9c:	17fff82b 	b	9c48 <f0+0x3c4>
    bba0:	72003c3f 	tst	w1, #0xffff
    bba4:	54fefa41 	b.ne	9aec <f0+0x268>  // b.any
    bba8:	17fff7cc 	b	9ad8 <f0+0x254>
    bbac:	72003c3f 	tst	w1, #0xffff
    bbb0:	54fef561 	b.ne	9a5c <f0+0x1d8>  // b.any
    bbb4:	17fff7a5 	b	9a48 <f0+0x1c4>
    bbb8:	72003c3f 	tst	w1, #0xffff
    bbbc:	54ff1ae1 	b.ne	9f18 <f0+0x694>  // b.any
    bbc0:	17fff8d1 	b	9f04 <f0+0x680>
    bbc4:	72003c3f 	tst	w1, #0xffff
    bbc8:	54ff1501 	b.ne	9e68 <f0+0x5e4>  // b.any
    bbcc:	17fff8a2 	b	9e54 <f0+0x5d0>
    bbd0:	72003c3f 	tst	w1, #0xffff
    bbd4:	54ff0e61 	b.ne	9da0 <f0+0x51c>  // b.any
    bbd8:	17fff86d 	b	9d8c <f0+0x508>
    bbdc:	72003c3f 	tst	w1, #0xffff
    bbe0:	54ff0961 	b.ne	9d0c <f0+0x488>  // b.any
    bbe4:	17fff845 	b	9cf8 <f0+0x474>
    bbe8:	72003c3f 	tst	w1, #0xffff
    bbec:	54ff4701 	b.ne	a4cc <f0+0xc48>  // b.any
    bbf0:	17fffa32 	b	a4b8 <f0+0xc34>
    bbf4:	72003c3f 	tst	w1, #0xffff
    bbf8:	54ff41e1 	b.ne	a434 <f0+0xbb0>  // b.any
    bbfc:	17fffa09 	b	a420 <f0+0xb9c>
    bc00:	72003c3f 	tst	w1, #0xffff
    bc04:	54ff3bc1 	b.ne	a37c <f0+0xaf8>  // b.any
    bc08:	17fff9d8 	b	a368 <f0+0xae4>
    bc0c:	72003c3f 	tst	w1, #0xffff
    bc10:	54ff35a1 	b.ne	a2c4 <f0+0xa40>  // b.any
    bc14:	17fff9a7 	b	a2b0 <f0+0xa2c>
    bc18:	72003c3f 	tst	w1, #0xffff
    bc1c:	54ff2dc1 	b.ne	a1d4 <f0+0x950>  // b.any
    bc20:	17fff968 	b	a1c0 <f0+0x93c>
    bc24:	72003c3f 	tst	w1, #0xffff
    bc28:	54ff27e1 	b.ne	a124 <f0+0x8a0>  // b.any
    bc2c:	17fff939 	b	a110 <f0+0x88c>
    bc30:	72003c3f 	tst	w1, #0xffff
    bc34:	54ff2141 	b.ne	a05c <f0+0x7d8>  // b.any
    bc38:	17fff904 	b	a048 <f0+0x7c4>
    bc3c:	72003c3f 	tst	w1, #0xffff
    bc40:	54ff1c41 	b.ne	9fc8 <f0+0x744>  // b.any
    bc44:	17fff8dc 	b	9fb4 <f0+0x730>
    bc48:	72003c3f 	tst	w1, #0xffff
    bc4c:	54ffe1c1 	b.ne	b884 <f0+0x2000>  // b.any
    bc50:	17ffff08 	b	b870 <f0+0x1fec>
    bc54:	72003c3f 	tst	w1, #0xffff
    bc58:	54ffd9e1 	b.ne	b794 <f0+0x1f10>  // b.any
    bc5c:	17fffec9 	b	b780 <f0+0x1efc>
    bc60:	72003c3f 	tst	w1, #0xffff
    bc64:	54ffd3c1 	b.ne	b6dc <f0+0x1e58>  // b.any
    bc68:	17fffe98 	b	b6c8 <f0+0x1e44>
    bc6c:	72003c3f 	tst	w1, #0xffff
    bc70:	54ffcea1 	b.ne	b644 <f0+0x1dc0>  // b.any
    bc74:	17fffe6f 	b	b630 <f0+0x1dac>
    bc78:	72003c3f 	tst	w1, #0xffff
    bc7c:	54ffc881 	b.ne	b58c <f0+0x1d08>  // b.any
    bc80:	17fffe3e 	b	b578 <f0+0x1cf4>
    bc84:	72003c3f 	tst	w1, #0xffff
    bc88:	54ffc261 	b.ne	b4d4 <f0+0x1c50>  // b.any
    bc8c:	17fffe0d 	b	b4c0 <f0+0x1c3c>
    bc90:	72003c3f 	tst	w1, #0xffff
    bc94:	54ffbc41 	b.ne	b41c <f0+0x1b98>  // b.any
    bc98:	17fffddc 	b	b408 <f0+0x1b84>
    bc9c:	72003c3f 	tst	w1, #0xffff
    bca0:	54ffb741 	b.ne	b388 <f0+0x1b04>  // b.any
    bca4:	17fffdb4 	b	b374 <f0+0x1af0>
    bca8:	72003c3f 	tst	w1, #0xffff
    bcac:	54ffacc1 	b.ne	b244 <f0+0x19c0>  // b.any
    bcb0:	17fffd60 	b	b230 <f0+0x19ac>
    bcb4:	72003c3f 	tst	w1, #0xffff
    bcb8:	54ffa7c1 	b.ne	b1b0 <f0+0x192c>  // b.any
    bcbc:	17fffd38 	b	b19c <f0+0x1918>
    bcc0:	72003c3f 	tst	w1, #0xffff
    bcc4:	54ffa2a1 	b.ne	b118 <f0+0x1894>  // b.any
    bcc8:	17fffd0f 	b	b104 <f0+0x1880>
    bccc:	72003c3f 	tst	w1, #0xffff
    bcd0:	54ff9c81 	b.ne	b060 <f0+0x17dc>  // b.any
    bcd4:	17fffcde 	b	b04c <f0+0x17c8>
    bcd8:	72003c3f 	tst	w1, #0xffff
    bcdc:	54ff93c1 	b.ne	af54 <f0+0x16d0>  // b.any
    bce0:	17fffc98 	b	af40 <f0+0x16bc>
    bce4:	72003c3f 	tst	w1, #0xffff
    bce8:	54ff8cc1 	b.ne	ae80 <f0+0x15fc>  // b.any
    bcec:	17fffc60 	b	ae6c <f0+0x15e8>
    bcf0:	72003c3f 	tst	w1, #0xffff
    bcf4:	54ff8401 	b.ne	ad74 <f0+0x14f0>  // b.any
    bcf8:	17fffc1a 	b	ad60 <f0+0x14dc>
    bcfc:	72003c3f 	tst	w1, #0xffff
    bd00:	54ff7d01 	b.ne	aca0 <f0+0x141c>  // b.any
    bd04:	17fffbe2 	b	ac8c <f0+0x1408>
    bd08:	aa1403e0 	mov	x0, x20
    bd0c:	97ffe219 	bl	4570 <fwp_rc_forget_slot>
    bd10:	17fffedb 	b	b87c <f0+0x1ff8>
    bd14:	aa1703e0 	mov	x0, x23
    bd18:	97ffe216 	bl	4570 <fwp_rc_forget_slot>
    bd1c:	17fff74e 	b	9a54 <f0+0x1d0>
    bd20:	aa1703e0 	mov	x0, x23
    bd24:	97ffe213 	bl	4570 <fwp_rc_forget_slot>
    bd28:	17fff76f 	b	9ae4 <f0+0x260>
    bd2c:	aa1703e0 	mov	x0, x23
    bd30:	97ffe210 	bl	4570 <fwp_rc_forget_slot>
    bd34:	17fff7c8 	b	9c54 <f0+0x3d0>
    bd38:	aa1703e0 	mov	x0, x23
    bd3c:	97ffe20d 	bl	4570 <fwp_rc_forget_slot>
    bd40:	17fff7f1 	b	9d04 <f0+0x480>
    bd44:	aa1703e0 	mov	x0, x23
    bd48:	97ffe20a 	bl	4570 <fwp_rc_forget_slot>
    bd4c:	17fff813 	b	9d98 <f0+0x514>
    bd50:	aa1703e0 	mov	x0, x23
    bd54:	97ffe207 	bl	4570 <fwp_rc_forget_slot>
    bd58:	17fff842 	b	9e60 <f0+0x5dc>
    bd5c:	aa1703e0 	mov	x0, x23
    bd60:	97ffe204 	bl	4570 <fwp_rc_forget_slot>
    bd64:	17fff86b 	b	9f10 <f0+0x68c>
    bd68:	aa1703e0 	mov	x0, x23
    bd6c:	97ffe201 	bl	4570 <fwp_rc_forget_slot>
    bd70:	17fff894 	b	9fc0 <f0+0x73c>
    bd74:	aa1703e0 	mov	x0, x23
    bd78:	97ffe1fe 	bl	4570 <fwp_rc_forget_slot>
    bd7c:	17fff8b6 	b	a054 <f0+0x7d0>
    bd80:	aa1703e0 	mov	x0, x23
    bd84:	97ffe1fb 	bl	4570 <fwp_rc_forget_slot>
    bd88:	17fff8e5 	b	a11c <f0+0x898>
    bd8c:	aa1703e0 	mov	x0, x23
    bd90:	97ffe1f8 	bl	4570 <fwp_rc_forget_slot>
    bd94:	17fff90e 	b	a1cc <f0+0x948>
    bd98:	aa1703e0 	mov	x0, x23
    bd9c:	97ffe1f5 	bl	4570 <fwp_rc_forget_slot>
    bda0:	17fff947 	b	a2bc <f0+0xa38>
    bda4:	aa1703e0 	mov	x0, x23
    bda8:	97ffe1f2 	bl	4570 <fwp_rc_forget_slot>
    bdac:	17fff972 	b	a374 <f0+0xaf0>
    bdb0:	aa1703e0 	mov	x0, x23
    bdb4:	97ffe1ef 	bl	4570 <fwp_rc_forget_slot>
    bdb8:	17fff99d 	b	a42c <f0+0xba8>
    bdbc:	aa1703e0 	mov	x0, x23
    bdc0:	97ffe1ec 	bl	4570 <fwp_rc_forget_slot>
    bdc4:	17fff9c0 	b	a4c4 <f0+0xc40>
    bdc8:	aa1703e0 	mov	x0, x23
    bdcc:	97ffe1e9 	bl	4570 <fwp_rc_forget_slot>
    bdd0:	17fff9e2 	b	a558 <f0+0xcd4>
    bdd4:	aa1703e0 	mov	x0, x23
    bdd8:	97ffe1e6 	bl	4570 <fwp_rc_forget_slot>
    bddc:	17fffa0d 	b	a610 <f0+0xd8c>
    bde0:	aa1703e0 	mov	x0, x23
    bde4:	97ffe1e3 	bl	4570 <fwp_rc_forget_slot>
    bde8:	17fffa62 	b	a770 <f0+0xeec>
    bdec:	aa1703e0 	mov	x0, x23
    bdf0:	97ffe1e0 	bl	4570 <fwp_rc_forget_slot>
    bdf4:	17fffa9b 	b	a860 <f0+0xfdc>
    bdf8:	aa1703e0 	mov	x0, x23
    bdfc:	97ffe1dd 	bl	4570 <fwp_rc_forget_slot>
    be00:	17fffac6 	b	a918 <f0+0x1094>
    be04:	aa1503e0 	mov	x0, x21
    be08:	97ffe1da 	bl	4570 <fwp_rc_forget_slot>
    be0c:	17fffaf1 	b	a9d0 <f0+0x114c>
    be10:	aa1703e0 	mov	x0, x23
    be14:	97ffe1d7 	bl	4570 <fwp_rc_forget_slot>
    be18:	17fffb3f 	b	ab14 <f0+0x1290>
    be1c:	aa1703e0 	mov	x0, x23
    be20:	97ffe1d4 	bl	4570 <fwp_rc_forget_slot>
    be24:	17fffb61 	b	aba8 <f0+0x1324>
    be28:	aa1703e0 	mov	x0, x23
    be2c:	97ffe1d1 	bl	4570 <fwp_rc_forget_slot>
    be30:	17fffb9a 	b	ac98 <f0+0x1414>
    be34:	aa1703e0 	mov	x0, x23
    be38:	97ffe1ce 	bl	4570 <fwp_rc_forget_slot>
    be3c:	17fffbcc 	b	ad6c <f0+0x14e8>
    be40:	aa1703e0 	mov	x0, x23
    be44:	97ffe1cb 	bl	4570 <fwp_rc_forget_slot>
    be48:	17fffc0c 	b	ae78 <f0+0x15f4>
    be4c:	aa1703e0 	mov	x0, x23
    be50:	97ffe1c8 	bl	4570 <fwp_rc_forget_slot>
    be54:	17fffc3e 	b	af4c <f0+0x16c8>
    be58:	aa1703e0 	mov	x0, x23
    be5c:	97ffe1c5 	bl	4570 <fwp_rc_forget_slot>
    be60:	17fffc7e 	b	b058 <f0+0x17d4>
    be64:	aa1703e0 	mov	x0, x23
    be68:	97ffe1c2 	bl	4570 <fwp_rc_forget_slot>
    be6c:	17fffca9 	b	b110 <f0+0x188c>
    be70:	aa1703e0 	mov	x0, x23
    be74:	97ffe1bf 	bl	4570 <fwp_rc_forget_slot>
    be78:	17fffccc 	b	b1a8 <f0+0x1924>
    be7c:	aa1503e0 	mov	x0, x21
    be80:	97ffe1bc 	bl	4570 <fwp_rc_forget_slot>
    be84:	17fffcee 	b	b23c <f0+0x19b8>
    be88:	aa1703e0 	mov	x0, x23
    be8c:	97ffe1b9 	bl	4570 <fwp_rc_forget_slot>
    be90:	17fffd3c 	b	b380 <f0+0x1afc>
    be94:	aa1703e0 	mov	x0, x23
    be98:	97ffe1b6 	bl	4570 <fwp_rc_forget_slot>
    be9c:	17fffd5e 	b	b414 <f0+0x1b90>
    bea0:	aa1703e0 	mov	x0, x23
    bea4:	97ffe1b3 	bl	4570 <fwp_rc_forget_slot>
    bea8:	17fffd89 	b	b4cc <f0+0x1c48>
    beac:	aa1703e0 	mov	x0, x23
    beb0:	97ffe1b0 	bl	4570 <fwp_rc_forget_slot>
    beb4:	17fffdb4 	b	b584 <f0+0x1d00>
    beb8:	aa1703e0 	mov	x0, x23
    bebc:	97ffe1ad 	bl	4570 <fwp_rc_forget_slot>
    bec0:	17fffddf 	b	b63c <f0+0x1db8>
    bec4:	aa1703e0 	mov	x0, x23
    bec8:	97ffe1aa 	bl	4570 <fwp_rc_forget_slot>
    becc:	17fffe02 	b	b6d4 <f0+0x1e50>
    bed0:	aa1703e0 	mov	x0, x23
    bed4:	97ffe1a7 	bl	4570 <fwp_rc_forget_slot>
    bed8:	17fffe2d 	b	b78c <f0+0x1f08>
    bedc:	97ffda69 	bl	2880 <__stack_chk_fail@plt>

000000000000bee0 <fwp_main_thread>:
    bee0:	d10443ff 	sub	sp, sp, #0x110
    bee4:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bee8:	f947f400 	ldr	x0, [x0, #4072]
    beec:	a90c7bfd 	stp	x29, x30, [sp, #192]
    bef0:	910303fd 	add	x29, sp, #0xc0
    bef4:	a90d53f3 	stp	x19, x20, [sp, #208]
    bef8:	d0000133 	adrp	x19, 31000 <fwp_root_context+0xca0>
    befc:	91150261 	add	x1, x19, #0x540
    bf00:	a90e5bf5 	stp	x21, x22, [sp, #224]
    bf04:	b953a421 	ldr	w1, [x1, #5028]
    bf08:	f9400002 	ldr	x2, [x0]
    bf0c:	f9005fe2 	str	x2, [sp, #184]
    bf10:	d2800002 	mov	x2, #0x0                   	// #0
    bf14:	340025c1 	cbz	w1, c3cc <fwp_main_thread+0x4ec>
    bf18:	91150273 	add	x19, x19, #0x540
    bf1c:	b953aa60 	ldr	w0, [x19, #5032]
    bf20:	350024e0 	cbnz	w0, c3bc <fwp_main_thread+0x4dc>
    bf24:	91001fe2 	add	x2, sp, #0x7
    bf28:	b00000b5 	adrp	x21, 20000 <__data_start>
    bf2c:	b00000a3 	adrp	x3, 20000 <__data_start>
    bf30:	9100c2b3 	add	x19, x21, #0x30
    bf34:	910d8063 	add	x3, x3, #0x360
    bf38:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    bf3c:	d2a00025 	mov	x5, #0x10000               	// #65536
    bf40:	910023e0 	add	x0, sp, #0x8
    bf44:	d2800001 	mov	x1, #0x0                   	// #0
    bf48:	f90007e3 	str	x3, [sp, #8]
    bf4c:	b90013ff 	str	wzr, [sp, #16]
    bf50:	a9019262 	stp	x2, x4, [x19, #24]
    bf54:	f9000fe5 	str	x5, [sp, #24]
    bf58:	97ffd9e2 	bl	26e0 <sigaltstack@plt>
    bf5c:	35002520 	cbnz	w0, c400 <fwp_main_thread+0x520>
    bf60:	4f000400 	movi	v0.4s, #0x0
    bf64:	9100a3e0 	add	x0, sp, #0x28
    bf68:	90ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    bf6c:	52800082 	mov	w2, #0x4                   	// #4
    bf70:	9101c021 	add	x1, x1, #0x70
    bf74:	72a10002 	movk	w2, #0x800, lsl #16
    bf78:	910083f4 	add	x20, sp, #0x20
    bf7c:	f90013e1 	str	x1, [sp, #32]
    bf80:	3d802000 	str	q0, [x0, #128]
    bf84:	b900abe2 	str	w2, [sp, #168]
    bf88:	ad000000 	stp	q0, q0, [x0]
    bf8c:	ad010000 	stp	q0, q0, [x0, #32]
    bf90:	ad020000 	stp	q0, q0, [x0, #64]
    bf94:	ad030000 	stp	q0, q0, [x0, #96]
    bf98:	97ffda2a 	bl	2840 <sigemptyset@plt>
    bf9c:	35002320 	cbnz	w0, c400 <fwp_main_thread+0x520>
    bfa0:	aa1403e1 	mov	x1, x20
    bfa4:	d2800002 	mov	x2, #0x0                   	// #0
    bfa8:	52800160 	mov	w0, #0xb                   	// #11
    bfac:	97ffda3d 	bl	28a0 <sigaction@plt>
    bfb0:	35002280 	cbnz	w0, c400 <fwp_main_thread+0x520>
    bfb4:	aa1403e1 	mov	x1, x20
    bfb8:	d2800002 	mov	x2, #0x0                   	// #0
    bfbc:	528000e0 	mov	w0, #0x7                   	// #7
    bfc0:	97ffda38 	bl	28a0 <sigaction@plt>
    bfc4:	350021e0 	cbnz	w0, c400 <fwp_main_thread+0x520>
    bfc8:	b942fa60 	ldr	w0, [x19, #760]
    bfcc:	a90f63f7 	stp	x23, x24, [sp, #240]
    bfd0:	34002020 	cbz	w0, c3d4 <fwp_main_thread+0x4f4>
    bfd4:	9100c2b6 	add	x22, x21, #0x30
    bfd8:	f9400ad4 	ldr	x20, [x22, #16]
    bfdc:	b40010d4 	cbz	x20, c1f4 <fwp_main_thread+0x314>
    bfe0:	aa1403f3 	mov	x19, x20
    bfe4:	91010297 	add	x23, x20, #0x40
    bfe8:	f90083f9 	str	x25, [sp, #256]
    bfec:	52800038 	mov	w24, #0x1                   	// #1
    bff0:	39414a99 	ldrb	w25, [x20, #82]
    bff4:	39014a98 	strb	w24, [x20, #82]
    bff8:	f9401680 	ldr	x0, [x20, #40]
    bffc:	b4000620 	cbz	x0, c0c0 <fwp_main_thread+0x1e0>
    c000:	f9403281 	ldr	x1, [x20, #96]
    c004:	39414680 	ldrb	w0, [x20, #81]
    c008:	b4000b41 	cbz	x1, c170 <fwp_main_thread+0x290>
    c00c:	36000a80 	tbz	w0, #0, c15c <fwp_main_thread+0x27c>
    c010:	39414a62 	ldrb	w2, [x19, #82]
    c014:	f9402280 	ldr	x0, [x20, #64]
    c018:	37000d62 	tbnz	w2, #0, c1c4 <fwp_main_thread+0x2e4>
    c01c:	f9403261 	ldr	x1, [x19, #96]
    c020:	a911fe77 	stp	x23, xzr, [x19, #280]
    c024:	f9009660 	str	x0, [x19, #296]
    c028:	b4000040 	cbz	x0, c030 <fwp_main_thread+0x150>
    c02c:	f9009013 	str	x19, [x0, #288]
    c030:	f9002293 	str	x19, [x20, #64]
    c034:	b4000101 	cbz	x1, c054 <fwp_main_thread+0x174>
    c038:	f94046c0 	ldr	x0, [x22, #136]
    c03c:	39015678 	strb	w24, [x19, #85]
    c040:	f9003661 	str	x1, [x19, #104]
    c044:	a910827f 	stp	xzr, x0, [x19, #264]
    c048:	b4000040 	cbz	x0, c050 <fwp_main_thread+0x170>
    c04c:	f9008413 	str	x19, [x0, #264]
    c050:	f90046d3 	str	x19, [x22, #136]
    c054:	39015a7f 	strb	wzr, [x19, #86]
    c058:	97ffe8d3 	bl	63a4 <fwp_block>
    c05c:	f9408e62 	ldr	x2, [x19, #280]
    c060:	b4000142 	cbz	x2, c088 <fwp_main_thread+0x1a8>
    c064:	a9520261 	ldp	x1, x0, [x19, #288]
    c068:	b4000ba1 	cbz	x1, c1dc <fwp_main_thread+0x2fc>
    c06c:	f9009420 	str	x0, [x1, #296]
    c070:	f9409660 	ldr	x0, [x19, #296]
    c074:	b4000040 	cbz	x0, c07c <fwp_main_thread+0x19c>
    c078:	f9009001 	str	x1, [x0, #288]
    c07c:	91080260 	add	x0, x19, #0x200
    c080:	f900967f 	str	xzr, [x19, #296]
    c084:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c088:	39415660 	ldrb	w0, [x19, #85]
    c08c:	f9400ac2 	ldr	x2, [x22, #16]
    c090:	36000960 	tbz	w0, #0, c1bc <fwp_main_thread+0x2dc>
    c094:	a9508261 	ldp	x1, x0, [x19, #264]
    c098:	b4000a61 	cbz	x1, c1e4 <fwp_main_thread+0x304>
    c09c:	f9008820 	str	x0, [x1, #272]
    c0a0:	b4000040 	cbz	x0, c0a8 <fwp_main_thread+0x1c8>
    c0a4:	f9008401 	str	x1, [x0, #264]
    c0a8:	91080260 	add	x0, x19, #0x200
    c0ac:	3901567f 	strb	wzr, [x19, #85]
    c0b0:	aa0203f3 	mov	x19, x2
    c0b4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c0b8:	f9401680 	ldr	x0, [x20, #40]
    c0bc:	b5fffa20 	cbnz	x0, c000 <fwp_main_thread+0x120>
    c0c0:	9100c2a0 	add	x0, x21, #0x30
    c0c4:	39014a99 	strb	w25, [x20, #82]
    c0c8:	f94083f9 	ldr	x25, [sp, #256]
    c0cc:	f9416c00 	ldr	x0, [x0, #728]
    c0d0:	b4001560 	cbz	x0, c37c <fwp_main_thread+0x49c>
    c0d4:	9100c2a0 	add	x0, x21, #0x30
    c0d8:	f9418801 	ldr	x1, [x0, #784]
    c0dc:	b903081f 	str	wzr, [x0, #776]
    c0e0:	eb13003f 	cmp	x1, x19
    c0e4:	54001681 	b.ne	c3b4 <fwp_main_thread+0x4d4>  // b.any
    c0e8:	b4000913 	cbz	x19, c208 <fwp_main_thread+0x328>
    c0ec:	9100c2a0 	add	x0, x21, #0x30
    c0f0:	52800021 	mov	w1, #0x1                   	// #1
    c0f4:	39014a61 	strb	w1, [x19, #82]
    c0f8:	f9415805 	ldr	x5, [x0, #688]
    c0fc:	b4000865 	cbz	x5, c208 <fwp_main_thread+0x328>
    c100:	394140a0 	ldrb	w0, [x5, #80]
    c104:	37000060 	tbnz	w0, #0, c110 <fwp_main_thread+0x230>
    c108:	aa0503e0 	mov	x0, x5
    c10c:	97ffdcd9 	bl	3470 <fwp_cancel_tree.part.0>
    c110:	f9409ca5 	ldr	x5, [x5, #312]
    c114:	b5ffff65 	cbnz	x5, c100 <fwp_main_thread+0x220>
    c118:	9100c2b4 	add	x20, x21, #0x30
    c11c:	52800036 	mov	w22, #0x1                   	// #1
    c120:	f9402a60 	ldr	x0, [x19, #80]
    c124:	f2001c1f 	tst	x0, #0xff000000ff
    c128:	540000e1 	b.ne	c144 <fwp_main_thread+0x264>  // b.any
    c12c:	f9401680 	ldr	x0, [x20, #40]
    c130:	39015276 	strb	w22, [x19, #84]
    c134:	f900827f 	str	xzr, [x19, #256]
    c138:	b40005a0 	cbz	x0, c1ec <fwp_main_thread+0x30c>
    c13c:	f9008013 	str	x19, [x0, #256]
    c140:	f9001693 	str	x19, [x20, #40]
    c144:	97ffe898 	bl	63a4 <fwp_block>
    c148:	97ffe82a 	bl	61f0 <fwp_free_zombie>
    c14c:	f9415a80 	ldr	x0, [x20, #688]
    c150:	b40005c0 	cbz	x0, c208 <fwp_main_thread+0x328>
    c154:	f9418a93 	ldr	x19, [x20, #784]
    c158:	17fffff2 	b	c120 <fwp_main_thread+0x240>
    c15c:	97ffdd69 	bl	3700 <fwp_now_ns>
    c160:	f9403281 	ldr	x1, [x20, #96]
    c164:	eb01001f 	cmp	x0, x1
    c168:	54000fca 	b.ge	c360 <fwp_main_thread+0x480>  // b.tcont
    c16c:	39414680 	ldrb	w0, [x20, #81]
    c170:	39414a62 	ldrb	w2, [x19, #82]
    c174:	3707f500 	tbnz	w0, #0, c014 <fwp_main_thread+0x134>
    c178:	f9403281 	ldr	x1, [x20, #96]
    c17c:	370001c2 	tbnz	w2, #0, c1b4 <fwp_main_thread+0x2d4>
    c180:	f9403260 	ldr	x0, [x19, #96]
    c184:	b4000180 	cbz	x0, c1b4 <fwp_main_thread+0x2d4>
    c188:	b4000061 	cbz	x1, c194 <fwp_main_thread+0x2b4>
    c18c:	eb01001f 	cmp	x0, x1
    c190:	9a81d000 	csel	x0, x0, x1, le
    c194:	f9402281 	ldr	x1, [x20, #64]
    c198:	a911fe77 	stp	x23, xzr, [x19, #280]
    c19c:	f9009661 	str	x1, [x19, #296]
    c1a0:	b4001241 	cbz	x1, c3e8 <fwp_main_thread+0x508>
    c1a4:	f9009033 	str	x19, [x1, #288]
    c1a8:	aa0003e1 	mov	x1, x0
    c1ac:	f9002293 	str	x19, [x20, #64]
    c1b0:	17ffffa2 	b	c038 <fwp_main_thread+0x158>
    c1b4:	f9402280 	ldr	x0, [x20, #64]
    c1b8:	17ffff9a 	b	c020 <fwp_main_thread+0x140>
    c1bc:	aa0203f3 	mov	x19, x2
    c1c0:	17ffff8e 	b	bff8 <fwp_main_thread+0x118>
    c1c4:	a911fe77 	stp	x23, xzr, [x19, #280]
    c1c8:	f9009660 	str	x0, [x19, #296]
    c1cc:	b4000040 	cbz	x0, c1d4 <fwp_main_thread+0x2f4>
    c1d0:	f9009013 	str	x19, [x0, #288]
    c1d4:	f9002293 	str	x19, [x20, #64]
    c1d8:	17ffff9f 	b	c054 <fwp_main_thread+0x174>
    c1dc:	f9000040 	str	x0, [x2]
    c1e0:	17ffffa5 	b	c074 <fwp_main_thread+0x194>
    c1e4:	f90046c0 	str	x0, [x22, #136]
    c1e8:	17ffffae 	b	c0a0 <fwp_main_thread+0x1c0>
    c1ec:	f9001a93 	str	x19, [x20, #48]
    c1f0:	17ffffd4 	b	c140 <fwp_main_thread+0x260>
    c1f4:	f9416ec0 	ldr	x0, [x22, #728]
    c1f8:	b4000c00 	cbz	x0, c378 <fwp_main_thread+0x498>
    c1fc:	f9418ac0 	ldr	x0, [x22, #784]
    c200:	b9030adf 	str	wzr, [x22, #776]
    c204:	b5000d80 	cbnz	x0, c3b4 <fwp_main_thread+0x4d4>
    c208:	9100c2b4 	add	x20, x21, #0x30
    c20c:	97ffe7f9 	bl	61f0 <fwp_free_zombie>
    c210:	f9401a80 	ldr	x0, [x20, #48]
    c214:	b5000d00 	cbnz	x0, c3b4 <fwp_main_thread+0x4d4>
    c218:	f9404680 	ldr	x0, [x20, #136]
    c21c:	b5000cc0 	cbnz	x0, c3b4 <fwp_main_thread+0x4d4>
    c220:	b940aa93 	ldr	w19, [x20, #168]
    c224:	340001d3 	cbz	w19, c25c <fwp_main_thread+0x37c>
    c228:	93407e76 	sxtw	x22, w19
    c22c:	51000673 	sub	w19, w19, #0x1
    c230:	d1000ad6 	sub	x22, x22, #0x2
    c234:	9102c297 	add	x23, x20, #0xb0
    c238:	cb3342d6 	sub	x22, x22, w19, uxtw
    c23c:	93407e73 	sxtw	x19, w19
    c240:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c244:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c248:	b900aa93 	str	w19, [x20, #168]
    c24c:	d1000673 	sub	x19, x19, #0x1
    c250:	97ffd9d4 	bl	29a0 <munmap@plt>
    c254:	eb16027f 	cmp	x19, x22
    c258:	54ffff41 	b.ne	c240 <fwp_main_thread+0x360>  // b.any
    c25c:	900000b3 	adrp	x19, 20000 <__data_start>
    c260:	91004260 	add	x0, x19, #0x10
    c264:	b9400800 	ldr	w0, [x0, #8]
    c268:	37f80040 	tbnz	w0, #31, c270 <fwp_main_thread+0x390>
    c26c:	97ffd989 	bl	2890 <close@plt>
    c270:	9100c2a0 	add	x0, x21, #0x30
    c274:	91004261 	add	x1, x19, #0x10
    c278:	12800002 	mov	w2, #0xffffffff            	// #-1
    c27c:	d2800013 	mov	x19, #0x0                   	// #0
    c280:	f9418c16 	ldr	x22, [x0, #792]
    c284:	b9000822 	str	w2, [x1, #8]
    c288:	f9419014 	ldr	x20, [x0, #800]
    c28c:	b4000176 	cbz	x22, c2b8 <fwp_main_thread+0x3d8>
    c290:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c294:	b40000c0 	cbz	x0, c2ac <fwp_main_thread+0x3cc>
    c298:	f9400001 	ldr	x1, [x0]
    c29c:	b50008c1 	cbnz	x1, c3b4 <fwp_main_thread+0x4d4>
    c2a0:	f9400401 	ldr	x1, [x0, #8]
    c2a4:	b5000881 	cbnz	x1, c3b4 <fwp_main_thread+0x4d4>
    c2a8:	97ffe152 	bl	47f0 <fwp_mem_free>
    c2ac:	91000673 	add	x19, x19, #0x1
    c2b0:	eb16027f 	cmp	x19, x22
    c2b4:	54fffee1 	b.ne	c290 <fwp_main_thread+0x3b0>  // b.any
    c2b8:	aa1403e0 	mov	x0, x20
    c2bc:	97ffe14d 	bl	47f0 <fwp_mem_free>
    c2c0:	9100c2a0 	add	x0, x21, #0x30
    c2c4:	f9418813 	ldr	x19, [x0, #784]
    c2c8:	f9018c1f 	str	xzr, [x0, #792]
    c2cc:	f901901f 	str	xzr, [x0, #800]
    c2d0:	b40001f3 	cbz	x19, c30c <fwp_main_thread+0x42c>
    c2d4:	f9401661 	ldr	x1, [x19, #40]
    c2d8:	b50006e1 	cbnz	x1, c3b4 <fwp_main_thread+0x4d4>
    c2dc:	f9405661 	ldr	x1, [x19, #168]
    c2e0:	b50006a1 	cbnz	x1, c3b4 <fwp_main_thread+0x4d4>
    c2e4:	f9416c01 	ldr	x1, [x0, #728]
    c2e8:	b5000661 	cbnz	x1, c3b4 <fwp_main_thread+0x4d4>
    c2ec:	f9417400 	ldr	x0, [x0, #744]
    c2f0:	b5000620 	cbnz	x0, c3b4 <fwp_main_thread+0x4d4>
    c2f4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c2f8:	90000120 	adrp	x0, 30000 <alt.5+0xfca0>
    c2fc:	910d8000 	add	x0, x0, #0x360
    c300:	97ffd954 	bl	2850 <memset@plt>
    c304:	aa1303e0 	mov	x0, x19
    c308:	97ffe13a 	bl	47f0 <fwp_mem_free>
    c30c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c310:	f947ec00 	ldr	x0, [x0, #4056]
    c314:	9100c2b5 	add	x21, x21, #0x30
    c318:	f9400000 	ldr	x0, [x0]
    c31c:	f9000abf 	str	xzr, [x21, #16]
    c320:	f9018abf 	str	xzr, [x21, #784]
    c324:	97ffd9a3 	bl	29b0 <fflush@plt>
    c328:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c32c:	f947f400 	ldr	x0, [x0, #4072]
    c330:	f9405fe2 	ldr	x2, [sp, #184]
    c334:	f9400001 	ldr	x1, [x0]
    c338:	eb010042 	subs	x2, x2, x1
    c33c:	d2800001 	mov	x1, #0x0                   	// #0
    c340:	540006a1 	b.ne	c414 <fwp_main_thread+0x534>  // b.any
    c344:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c348:	d2800000 	mov	x0, #0x0                   	// #0
    c34c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c350:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c354:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c358:	910443ff 	add	sp, sp, #0x110
    c35c:	d65f03c0 	ret
    c360:	39414280 	ldrb	w0, [x20, #80]
    c364:	3707f040 	tbnz	w0, #0, c16c <fwp_main_thread+0x28c>
    c368:	aa1403e0 	mov	x0, x20
    c36c:	97ffdc41 	bl	3470 <fwp_cancel_tree.part.0>
    c370:	39414680 	ldrb	w0, [x20, #81]
    c374:	17ffff7f 	b	c170 <fwp_main_thread+0x290>
    c378:	d2800013 	mov	x19, #0x0                   	// #0
    c37c:	9100c2b4 	add	x20, x21, #0x30
    c380:	f9417680 	ldr	x0, [x20, #744]
    c384:	b5ffea80 	cbnz	x0, c0d4 <fwp_main_thread+0x1f4>
    c388:	f9416a80 	ldr	x0, [x20, #720]
    c38c:	97ffe119 	bl	47f0 <fwp_mem_free>
    c390:	f9016a9f 	str	xzr, [x20, #720]
    c394:	f901729f 	str	xzr, [x20, #736]
    c398:	f9418a80 	ldr	x0, [x20, #784]
    c39c:	b40002d3 	cbz	x19, c3f4 <fwp_main_thread+0x514>
    c3a0:	f900567f 	str	xzr, [x19, #168]
    c3a4:	f9005e7f 	str	xzr, [x19, #184]
    c3a8:	b9030a9f 	str	wzr, [x20, #776]
    c3ac:	eb00027f 	cmp	x19, x0
    c3b0:	54ffe9e0 	b.eq	c0ec <fwp_main_thread+0x20c>  // b.none
    c3b4:	f90083f9 	str	x25, [sp, #256]
    c3b8:	97ffd946 	bl	28d0 <abort@plt>
    c3bc:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    c3c0:	91348000 	add	x0, x0, #0xd20
    c3c4:	940001d3 	bl	cb10 <atexit>
    c3c8:	17fffed7 	b	bf24 <fwp_main_thread+0x44>
    c3cc:	97ffdeae 	bl	3e84 <fwp_heap_init>
    c3d0:	17fffed2 	b	bf18 <fwp_main_thread+0x38>
    c3d4:	97fff52c 	bl	9884 <f0>
    c3d8:	f9018260 	str	x0, [x19, #768]
    c3dc:	52800021 	mov	w1, #0x1                   	// #1
    c3e0:	b902fa61 	str	w1, [x19, #760]
    c3e4:	17fffefc 	b	bfd4 <fwp_main_thread+0xf4>
    c3e8:	aa0003e1 	mov	x1, x0
    c3ec:	f9002293 	str	x19, [x20, #64]
    c3f0:	17ffff12 	b	c038 <fwp_main_thread+0x158>
    c3f4:	b9030a9f 	str	wzr, [x20, #776]
    c3f8:	b4fff080 	cbz	x0, c208 <fwp_main_thread+0x328>
    c3fc:	17ffffee 	b	c3b4 <fwp_main_thread+0x4d4>
    c400:	b0000000 	adrp	x0, d000 <_IO_stdin_used+0x4c0>
    c404:	9103e000 	add	x0, x0, #0xf8
    c408:	a90f63f7 	stp	x23, x24, [sp, #240]
    c40c:	f90083f9 	str	x25, [sp, #256]
    c410:	97ffdc5c 	bl	3580 <fwp_trap>
    c414:	f90083f9 	str	x25, [sp, #256]
    c418:	97ffd91a 	bl	2880 <__stack_chk_fail@plt>
    c41c:	d503201f 	nop

000000000000c420 <__divti3>:
    c420:	d503245f 	bti	c
    c424:	d2800004 	mov	x4, #0x0                   	// #0
    c428:	b7f80721 	tbnz	x1, #63, c50c <__divti3+0xec>
    c42c:	b6f80083 	tbz	x3, #63, c43c <__divti3+0x1c>
    c430:	eb0203e2 	negs	x2, x2
    c434:	aa2403e4 	mvn	x4, x4
    c438:	da0303e3 	ngc	x3, x3
    c43c:	aa0203e6 	mov	x6, x2
    c440:	aa0003e7 	mov	x7, x0
    c444:	aa0103e5 	mov	x5, x1
    c448:	b5000583 	cbnz	x3, c4f8 <__divti3+0xd8>
    c44c:	eb01005f 	cmp	x2, x1
    c450:	54000e69 	b.ls	c61c <__divti3+0x1fc>  // b.plast
    c454:	dac01040 	clz	x0, x2
    c458:	b40000e0 	cbz	x0, c474 <__divti3+0x54>
    c45c:	4b0003e1 	neg	w1, w0
    c460:	9ac020a5 	lsl	x5, x5, x0
    c464:	9ac02046 	lsl	x6, x2, x0
    c468:	9ac124e1 	lsr	x1, x7, x1
    c46c:	aa050025 	orr	x5, x1, x5
    c470:	9ac020e7 	lsl	x7, x7, x0
    c474:	d360fcc8 	lsr	x8, x6, #32
    c478:	92407cc2 	and	x2, x6, #0xffffffff
    c47c:	9ac808a3 	udiv	x3, x5, x8
    c480:	9b089465 	msub	x5, x3, x8, x5
    c484:	aa0303e0 	mov	x0, x3
    c488:	9b037c41 	mul	x1, x2, x3
    c48c:	93c780a5 	extr	x5, x5, x7, #32
    c490:	eb05003f 	cmp	x1, x5
    c494:	540000a9 	b.ls	c4a8 <__divti3+0x88>  // b.plast
    c498:	ab0500c5 	adds	x5, x6, x5
    c49c:	d1000460 	sub	x0, x3, #0x1
    c4a0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c4a4:	540015a8 	b.hi	c758 <__divti3+0x338>  // b.pmore
    c4a8:	cb0100a5 	sub	x5, x5, x1
    c4ac:	9ac808a3 	udiv	x3, x5, x8
    c4b0:	9b089465 	msub	x5, x3, x8, x5
    c4b4:	aa0303e1 	mov	x1, x3
    c4b8:	9b037c42 	mul	x2, x2, x3
    c4bc:	aa0703e3 	mov	x3, x7
    c4c0:	b3607ca3 	bfi	x3, x5, #32, #32
    c4c4:	eb03005f 	cmp	x2, x3
    c4c8:	540000c9 	b.ls	c4e0 <__divti3+0xc0>  // b.plast
    c4cc:	ab0300c3 	adds	x3, x6, x3
    c4d0:	d1000425 	sub	x5, x1, #0x1
    c4d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c4d8:	d1000821 	sub	x1, x1, #0x2
    c4dc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    c4e0:	aa008020 	orr	x0, x1, x0, lsl #32
    c4e4:	d2800001 	mov	x1, #0x0                   	// #0
    c4e8:	b4000064 	cbz	x4, c4f4 <__divti3+0xd4>
    c4ec:	eb0003e0 	negs	x0, x0
    c4f0:	da0103e1 	ngc	x1, x1
    c4f4:	d65f03c0 	ret
    c4f8:	eb01007f 	cmp	x3, x1
    c4fc:	54000109 	b.ls	c51c <__divti3+0xfc>  // b.plast
    c500:	d2800001 	mov	x1, #0x0                   	// #0
    c504:	d2800000 	mov	x0, #0x0                   	// #0
    c508:	17fffff8 	b	c4e8 <__divti3+0xc8>
    c50c:	eb0003e0 	negs	x0, x0
    c510:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c514:	da0103e1 	ngc	x1, x1
    c518:	17ffffc5 	b	c42c <__divti3+0xc>
    c51c:	dac01067 	clz	x7, x3
    c520:	b40010e7 	cbz	x7, c73c <__divti3+0x31c>
    c524:	d2800805 	mov	x5, #0x40                  	// #64
    c528:	cb0700a5 	sub	x5, x5, x7
    c52c:	9ac72063 	lsl	x3, x3, x7
    c530:	9ac52448 	lsr	x8, x2, x5
    c534:	aa030108 	orr	x8, x8, x3
    c538:	9ac52426 	lsr	x6, x1, x5
    c53c:	92407d0a 	and	x10, x8, #0xffffffff
    c540:	d360fd09 	lsr	x9, x8, #32
    c544:	9ac52403 	lsr	x3, x0, x5
    c548:	9ac72021 	lsl	x1, x1, x7
    c54c:	aa010063 	orr	x3, x3, x1
    c550:	9ac72042 	lsl	x2, x2, x7
    c554:	9ac908cb 	udiv	x11, x6, x9
    c558:	9b099965 	msub	x5, x11, x9, x6
    c55c:	aa0b03e1 	mov	x1, x11
    c560:	9b0b7d46 	mul	x6, x10, x11
    c564:	93c380a5 	extr	x5, x5, x3, #32
    c568:	eb0500df 	cmp	x6, x5
    c56c:	540000a9 	b.ls	c580 <__divti3+0x160>  // b.plast
    c570:	ab050105 	adds	x5, x8, x5
    c574:	d1000561 	sub	x1, x11, #0x1
    c578:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    c57c:	54000f48 	b.hi	c764 <__divti3+0x344>  // b.pmore
    c580:	cb0600a6 	sub	x6, x5, x6
    c584:	9ac908cb 	udiv	x11, x6, x9
    c588:	9b099969 	msub	x9, x11, x9, x6
    c58c:	aa0b03e5 	mov	x5, x11
    c590:	9b0b7d4a 	mul	x10, x10, x11
    c594:	b3607d23 	bfi	x3, x9, #32, #32
    c598:	eb03015f 	cmp	x10, x3
    c59c:	540000a9 	b.ls	c5b0 <__divti3+0x190>  // b.plast
    c5a0:	ab030103 	adds	x3, x8, x3
    c5a4:	d1000565 	sub	x5, x11, #0x1
    c5a8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    c5ac:	54000e28 	b.hi	c770 <__divti3+0x350>  // b.pmore
    c5b0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    c5b4:	92407c48 	and	x8, x2, #0xffffffff
    c5b8:	2a0503e5 	mov	w5, w5
    c5bc:	d360fc42 	lsr	x2, x2, #32
    c5c0:	d360fc26 	lsr	x6, x1, #32
    c5c4:	cb0a0063 	sub	x3, x3, x10
    c5c8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    c5cc:	9b087caa 	mul	x10, x5, x8
    c5d0:	9b087cc8 	mul	x8, x6, x8
    c5d4:	9b0220a5 	madd	x5, x5, x2, x8
    c5d8:	9b027cc6 	mul	x6, x6, x2
    c5dc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    c5e0:	8b0900c5 	add	x5, x6, x9
    c5e4:	eb02011f 	cmp	x8, x2
    c5e8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    c5ec:	8b4280c6 	add	x6, x6, x2, lsr #32
    c5f0:	eb06007f 	cmp	x3, x6
    c5f4:	540000e3 	b.cc	c610 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    c5f8:	92407d4a 	and	x10, x10, #0xffffffff
    c5fc:	9ac72000 	lsl	x0, x0, x7
    c600:	8b028142 	add	x2, x10, x2, lsl #32
    c604:	eb02001f 	cmp	x0, x2
    c608:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    c60c:	54000a01 	b.ne	c74c <__divti3+0x32c>  // b.any
    c610:	d1000420 	sub	x0, x1, #0x1
    c614:	d2800001 	mov	x1, #0x0                   	// #0
    c618:	17ffffb4 	b	c4e8 <__divti3+0xc8>
    c61c:	b5000062 	cbnz	x2, c628 <__divti3+0x208>
    c620:	d2800022 	mov	x2, #0x1                   	// #1
    c624:	9ac30846 	udiv	x6, x2, x3
    c628:	dac010c8 	clz	x8, x6
    c62c:	b5000408 	cbnz	x8, c6ac <__divti3+0x28c>
    c630:	d360fcc9 	lsr	x9, x6, #32
    c634:	92407cc5 	and	x5, x6, #0xffffffff
    c638:	cb060023 	sub	x3, x1, x6
    c63c:	d2800021 	mov	x1, #0x1                   	// #1
    c640:	9ac90868 	udiv	x8, x3, x9
    c644:	9b098d03 	msub	x3, x8, x9, x3
    c648:	aa0803e0 	mov	x0, x8
    c64c:	9b057d02 	mul	x2, x8, x5
    c650:	93c78063 	extr	x3, x3, x7, #32
    c654:	eb03005f 	cmp	x2, x3
    c658:	540000a9 	b.ls	c66c <__divti3+0x24c>  // b.plast
    c65c:	ab0300c3 	adds	x3, x6, x3
    c660:	d1000500 	sub	x0, x8, #0x1
    c664:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c668:	54000968 	b.hi	c794 <__divti3+0x374>  // b.pmore
    c66c:	cb020063 	sub	x3, x3, x2
    c670:	9ac90862 	udiv	x2, x3, x9
    c674:	aa0203e8 	mov	x8, x2
    c678:	9b098c42 	msub	x2, x2, x9, x3
    c67c:	aa0703e3 	mov	x3, x7
    c680:	9b057d05 	mul	x5, x8, x5
    c684:	b3607c43 	bfi	x3, x2, #32, #32
    c688:	eb0300bf 	cmp	x5, x3
    c68c:	540000c9 	b.ls	c6a4 <__divti3+0x284>  // b.plast
    c690:	ab0300c2 	adds	x2, x6, x3
    c694:	d1000503 	sub	x3, x8, #0x1
    c698:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    c69c:	d1000908 	sub	x8, x8, #0x2
    c6a0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    c6a4:	aa008100 	orr	x0, x8, x0, lsl #32
    c6a8:	17ffff90 	b	c4e8 <__divti3+0xc8>
    c6ac:	9ac820c6 	lsl	x6, x6, x8
    c6b0:	d2800803 	mov	x3, #0x40                  	// #64
    c6b4:	cb080063 	sub	x3, x3, x8
    c6b8:	d360fcc9 	lsr	x9, x6, #32
    c6bc:	9ac82027 	lsl	x7, x1, x8
    c6c0:	92407cc5 	and	x5, x6, #0xffffffff
    c6c4:	9ac32422 	lsr	x2, x1, x3
    c6c8:	9ac32403 	lsr	x3, x0, x3
    c6cc:	aa070063 	orr	x3, x3, x7
    c6d0:	9ac9084a 	udiv	x10, x2, x9
    c6d4:	9ac82007 	lsl	x7, x0, x8
    c6d8:	9b098940 	msub	x0, x10, x9, x2
    c6dc:	aa0a03e1 	mov	x1, x10
    c6e0:	9b0a7ca2 	mul	x2, x5, x10
    c6e4:	93c38000 	extr	x0, x0, x3, #32
    c6e8:	eb00005f 	cmp	x2, x0
    c6ec:	540000a9 	b.ls	c700 <__divti3+0x2e0>  // b.plast
    c6f0:	ab0000c0 	adds	x0, x6, x0
    c6f4:	d1000541 	sub	x1, x10, #0x1
    c6f8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    c6fc:	54000468 	b.hi	c788 <__divti3+0x368>  // b.pmore
    c700:	cb020000 	sub	x0, x0, x2
    c704:	9ac9080a 	udiv	x10, x0, x9
    c708:	9b098140 	msub	x0, x10, x9, x0
    c70c:	aa0a03e2 	mov	x2, x10
    c710:	9b0a7ca8 	mul	x8, x5, x10
    c714:	b3607c03 	bfi	x3, x0, #32, #32
    c718:	eb03011f 	cmp	x8, x3
    c71c:	540000a9 	b.ls	c730 <__divti3+0x310>  // b.plast
    c720:	ab0300c3 	adds	x3, x6, x3
    c724:	d1000542 	sub	x2, x10, #0x1
    c728:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    c72c:	54000288 	b.hi	c77c <__divti3+0x35c>  // b.pmore
    c730:	cb080063 	sub	x3, x3, x8
    c734:	aa018041 	orr	x1, x2, x1, lsl #32
    c738:	17ffffc2 	b	c640 <__divti3+0x220>
    c73c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    c740:	d2800001 	mov	x1, #0x0                   	// #0
    c744:	9a9f87e0 	cset	x0, ls	// ls = plast
    c748:	17ffff68 	b	c4e8 <__divti3+0xc8>
    c74c:	aa0103e0 	mov	x0, x1
    c750:	d2800001 	mov	x1, #0x0                   	// #0
    c754:	17ffff65 	b	c4e8 <__divti3+0xc8>
    c758:	d1000860 	sub	x0, x3, #0x2
    c75c:	8b0600a5 	add	x5, x5, x6
    c760:	17ffff52 	b	c4a8 <__divti3+0x88>
    c764:	d1000961 	sub	x1, x11, #0x2
    c768:	8b0800a5 	add	x5, x5, x8
    c76c:	17ffff85 	b	c580 <__divti3+0x160>
    c770:	d1000965 	sub	x5, x11, #0x2
    c774:	8b080063 	add	x3, x3, x8
    c778:	17ffff8e 	b	c5b0 <__divti3+0x190>
    c77c:	d1000942 	sub	x2, x10, #0x2
    c780:	8b060063 	add	x3, x3, x6
    c784:	17ffffeb 	b	c730 <__divti3+0x310>
    c788:	d1000941 	sub	x1, x10, #0x2
    c78c:	8b060000 	add	x0, x0, x6
    c790:	17ffffdc 	b	c700 <__divti3+0x2e0>
    c794:	d1000900 	sub	x0, x8, #0x2
    c798:	8b060063 	add	x3, x3, x6
    c79c:	17ffffb4 	b	c66c <__divti3+0x24c>

000000000000c7a0 <__modti3>:
    c7a0:	d503245f 	bti	c
    c7a4:	d2800004 	mov	x4, #0x0                   	// #0
    c7a8:	b6f80081 	tbz	x1, #63, c7b8 <__modti3+0x18>
    c7ac:	eb0003e0 	negs	x0, x0
    c7b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c7b4:	da0103e1 	ngc	x1, x1
    c7b8:	f100007f 	cmp	x3, #0x0
    c7bc:	5400128b 	b.lt	ca0c <__modti3+0x26c>  // b.tstop
    c7c0:	aa0003e7 	mov	x7, x0
    c7c4:	aa0103e6 	mov	x6, x1
    c7c8:	540004e1 	b.ne	c864 <__modti3+0xc4>  // b.any
    c7cc:	eb02003f 	cmp	x1, x2
    c7d0:	54000dc2 	b.cs	c988 <__modti3+0x1e8>  // b.hs, b.nlast
    c7d4:	dac01043 	clz	x3, x2
    c7d8:	aa0303e5 	mov	x5, x3
    c7dc:	b40000e3 	cbz	x3, c7f8 <__modti3+0x58>
    c7e0:	4b0303e6 	neg	w6, w3
    c7e4:	9ac32021 	lsl	x1, x1, x3
    c7e8:	9ac32042 	lsl	x2, x2, x3
    c7ec:	9ac62406 	lsr	x6, x0, x6
    c7f0:	aa0100c6 	orr	x6, x6, x1
    c7f4:	9ac32007 	lsl	x7, x0, x3
    c7f8:	d360fc40 	lsr	x0, x2, #32
    c7fc:	92407c43 	and	x3, x2, #0xffffffff
    c800:	9ac008c1 	udiv	x1, x6, x0
    c804:	9b009826 	msub	x6, x1, x0, x6
    c808:	9b017c61 	mul	x1, x3, x1
    c80c:	93c780c6 	extr	x6, x6, x7, #32
    c810:	eb06003f 	cmp	x1, x6
    c814:	540000a9 	b.ls	c828 <__modti3+0x88>  // b.plast
    c818:	ab060046 	adds	x6, x2, x6
    c81c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    c820:	8b0200c8 	add	x8, x6, x2
    c824:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    c828:	cb0100c6 	sub	x6, x6, x1
    c82c:	9ac008c8 	udiv	x8, x6, x0
    c830:	9b009901 	msub	x1, x8, x0, x6
    c834:	aa0703e0 	mov	x0, x7
    c838:	9b087c63 	mul	x3, x3, x8
    c83c:	b3607c20 	bfi	x0, x1, #32, #32
    c840:	eb00007f 	cmp	x3, x0
    c844:	54001088 	b.hi	ca54 <__modti3+0x2b4>  // b.pmore
    c848:	cb030000 	sub	x0, x0, x3
    c84c:	9ac52400 	lsr	x0, x0, x5
    c850:	d2800001 	mov	x1, #0x0                   	// #0
    c854:	b4000064 	cbz	x4, c860 <__modti3+0xc0>
    c858:	eb0003e0 	negs	x0, x0
    c85c:	da0103e1 	ngc	x1, x1
    c860:	d65f03c0 	ret
    c864:	dac01066 	clz	x6, x3
    c868:	eb03003f 	cmp	x1, x3
    c86c:	54ffff43 	b.cc	c854 <__modti3+0xb4>  // b.lo, b.ul, b.last
    c870:	93407cc5 	sxtw	x5, w6
    c874:	d2800808 	mov	x8, #0x40                  	// #64
    c878:	cb050108 	sub	x8, x8, x5
    c87c:	9ac62063 	lsl	x3, x3, x6
    c880:	9ac62025 	lsl	x5, x1, x6
    c884:	9ac82447 	lsr	x7, x2, x8
    c888:	aa0300e7 	orr	x7, x7, x3
    c88c:	9ac82423 	lsr	x3, x1, x8
    c890:	92407cec 	and	x12, x7, #0xffffffff
    c894:	d360fcea 	lsr	x10, x7, #32
    c898:	9ac82401 	lsr	x1, x0, x8
    c89c:	aa050021 	orr	x1, x1, x5
    c8a0:	9ac62042 	lsl	x2, x2, x6
    c8a4:	9ac62000 	lsl	x0, x0, x6
    c8a8:	9aca086b 	udiv	x11, x3, x10
    c8ac:	9b0a8d63 	msub	x3, x11, x10, x3
    c8b0:	aa0b03e5 	mov	x5, x11
    c8b4:	9b0b7d89 	mul	x9, x12, x11
    c8b8:	93c18063 	extr	x3, x3, x1, #32
    c8bc:	eb03013f 	cmp	x9, x3
    c8c0:	540000a9 	b.ls	c8d4 <__modti3+0x134>  // b.plast
    c8c4:	ab0300e3 	adds	x3, x7, x3
    c8c8:	d1000565 	sub	x5, x11, #0x1
    c8cc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    c8d0:	54001168 	b.hi	cafc <__modti3+0x35c>  // b.pmore
    c8d4:	cb090063 	sub	x3, x3, x9
    c8d8:	9aca086b 	udiv	x11, x3, x10
    c8dc:	9b0a8d6a 	msub	x10, x11, x10, x3
    c8e0:	aa0b03e9 	mov	x9, x11
    c8e4:	9b0b7d8c 	mul	x12, x12, x11
    c8e8:	b3607d41 	bfi	x1, x10, #32, #32
    c8ec:	eb01019f 	cmp	x12, x1
    c8f0:	540000a9 	b.ls	c904 <__modti3+0x164>  // b.plast
    c8f4:	ab0100e1 	adds	x1, x7, x1
    c8f8:	d1000569 	sub	x9, x11, #0x1
    c8fc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    c900:	54000f88 	b.hi	caf0 <__modti3+0x350>  // b.pmore
    c904:	aa058123 	orr	x3, x9, x5, lsl #32
    c908:	92407c4b 	and	x11, x2, #0xffffffff
    c90c:	2a0903e9 	mov	w9, w9
    c910:	d360fc4a 	lsr	x10, x2, #32
    c914:	d360fc63 	lsr	x3, x3, #32
    c918:	cb0c0021 	sub	x1, x1, x12
    c91c:	aa0a03ec 	mov	x12, x10
    c920:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    c924:	9b0b7d25 	mul	x5, x9, x11
    c928:	9b0b7c6b 	mul	x11, x3, x11
    c92c:	9b0a2d29 	madd	x9, x9, x10, x11
    c930:	92407caa 	and	x10, x5, #0xffffffff
    c934:	9b0c7c63 	mul	x3, x3, x12
    c938:	8b458125 	add	x5, x9, x5, lsr #32
    c93c:	8b0d0069 	add	x9, x3, x13
    c940:	eb05017f 	cmp	x11, x5
    c944:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    c948:	8b058149 	add	x9, x10, x5, lsl #32
    c94c:	8b458063 	add	x3, x3, x5, lsr #32
    c950:	eb03003f 	cmp	x1, x3
    c954:	54000063 	b.cc	c960 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    c958:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    c95c:	54000082 	b.cs	c96c <__modti3+0x1cc>  // b.hs, b.nlast
    c960:	eb020129 	subs	x9, x9, x2
    c964:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    c968:	cb070063 	sub	x3, x3, x7
    c96c:	eb090000 	subs	x0, x0, x9
    c970:	da030021 	sbc	x1, x1, x3
    c974:	9ac62400 	lsr	x0, x0, x6
    c978:	9ac82028 	lsl	x8, x1, x8
    c97c:	aa000100 	orr	x0, x8, x0
    c980:	9ac62421 	lsr	x1, x1, x6
    c984:	17ffffb4 	b	c854 <__modti3+0xb4>
    c988:	b5000062 	cbnz	x2, c994 <__modti3+0x1f4>
    c98c:	d2800023 	mov	x3, #0x1                   	// #1
    c990:	9ac20862 	udiv	x2, x3, x2
    c994:	dac01048 	clz	x8, x2
    c998:	aa0803e5 	mov	x5, x8
    c99c:	b5000668 	cbnz	x8, ca68 <__modti3+0x2c8>
    c9a0:	cb020020 	sub	x0, x1, x2
    c9a4:	d360fc49 	lsr	x9, x2, #32
    c9a8:	92407c4a 	and	x10, x2, #0xffffffff
    c9ac:	9ac90801 	udiv	x1, x0, x9
    c9b0:	9b098020 	msub	x0, x1, x9, x0
    c9b4:	9b0a7c21 	mul	x1, x1, x10
    c9b8:	93c78000 	extr	x0, x0, x7, #32
    c9bc:	eb00003f 	cmp	x1, x0
    c9c0:	540000a9 	b.ls	c9d4 <__modti3+0x234>  // b.plast
    c9c4:	ab000040 	adds	x0, x2, x0
    c9c8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    c9cc:	8b020003 	add	x3, x0, x2
    c9d0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    c9d4:	cb010001 	sub	x1, x0, x1
    c9d8:	9ac90820 	udiv	x0, x1, x9
    c9dc:	9b098403 	msub	x3, x0, x9, x1
    c9e0:	aa0703e1 	mov	x1, x7
    c9e4:	9b0a7c00 	mul	x0, x0, x10
    c9e8:	b3607c61 	bfi	x1, x3, #32, #32
    c9ec:	eb01001f 	cmp	x0, x1
    c9f0:	540000a9 	b.ls	ca04 <__modti3+0x264>  // b.plast
    c9f4:	ab010041 	adds	x1, x2, x1
    c9f8:	8b020022 	add	x2, x1, x2
    c9fc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    ca00:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    ca04:	cb000020 	sub	x0, x1, x0
    ca08:	17ffff91 	b	c84c <__modti3+0xac>
    ca0c:	eb0203e5 	negs	x5, x2
    ca10:	aa0003e7 	mov	x7, x0
    ca14:	da0303e8 	ngc	x8, x3
    ca18:	aa0503e2 	mov	x2, x5
    ca1c:	aa0803e3 	mov	x3, x8
    ca20:	aa0103e6 	mov	x6, x1
    ca24:	b4ffed48 	cbz	x8, c7cc <__modti3+0x2c>
    ca28:	eb01011f 	cmp	x8, x1
    ca2c:	54fff148 	b.hi	c854 <__modti3+0xb4>  // b.pmore
    ca30:	dac01109 	clz	x9, x8
    ca34:	2a0903e6 	mov	w6, w9
    ca38:	b5fff1c9 	cbnz	x9, c870 <__modti3+0xd0>
    ca3c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    ca40:	54000068 	b.hi	ca4c <__modti3+0x2ac>  // b.pmore
    ca44:	eb050007 	subs	x7, x0, x5
    ca48:	da080021 	sbc	x1, x1, x8
    ca4c:	aa0703e0 	mov	x0, x7
    ca50:	17ffff81 	b	c854 <__modti3+0xb4>
    ca54:	ab000040 	adds	x0, x2, x0
    ca58:	8b020002 	add	x2, x0, x2
    ca5c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    ca60:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    ca64:	17ffff79 	b	c848 <__modti3+0xa8>
    ca68:	9ac82042 	lsl	x2, x2, x8
    ca6c:	d2800803 	mov	x3, #0x40                  	// #64
    ca70:	cb080063 	sub	x3, x3, x8
    ca74:	d360fc49 	lsr	x9, x2, #32
    ca78:	9ac82027 	lsl	x7, x1, x8
    ca7c:	92407c4a 	and	x10, x2, #0xffffffff
    ca80:	9ac32426 	lsr	x6, x1, x3
    ca84:	9ac32403 	lsr	x3, x0, x3
    ca88:	aa070063 	orr	x3, x3, x7
    ca8c:	9ac908c1 	udiv	x1, x6, x9
    ca90:	9ac82007 	lsl	x7, x0, x8
    ca94:	9b099820 	msub	x0, x1, x9, x6
    ca98:	9b017d41 	mul	x1, x10, x1
    ca9c:	93c38000 	extr	x0, x0, x3, #32
    caa0:	eb00003f 	cmp	x1, x0
    caa4:	540000a9 	b.ls	cab8 <__modti3+0x318>  // b.plast
    caa8:	ab000040 	adds	x0, x2, x0
    caac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cab0:	8b020006 	add	x6, x0, x2
    cab4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    cab8:	cb010000 	sub	x0, x0, x1
    cabc:	9ac90801 	udiv	x1, x0, x9
    cac0:	9b098026 	msub	x6, x1, x9, x0
    cac4:	aa0303e0 	mov	x0, x3
    cac8:	9b017d41 	mul	x1, x10, x1
    cacc:	b3607cc0 	bfi	x0, x6, #32, #32
    cad0:	eb00003f 	cmp	x1, x0
    cad4:	540000a9 	b.ls	cae8 <__modti3+0x348>  // b.plast
    cad8:	ab000040 	adds	x0, x2, x0
    cadc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cae0:	8b020003 	add	x3, x0, x2
    cae4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cae8:	cb010000 	sub	x0, x0, x1
    caec:	17ffffb0 	b	c9ac <__modti3+0x20c>
    caf0:	d1000969 	sub	x9, x11, #0x2
    caf4:	8b070021 	add	x1, x1, x7
    caf8:	17ffff83 	b	c904 <__modti3+0x164>
    cafc:	d1000965 	sub	x5, x11, #0x2
    cb00:	8b070063 	add	x3, x3, x7
    cb04:	17ffff74 	b	c8d4 <__modti3+0x134>
    cb08:	d503201f 	nop
    cb0c:	d503201f 	nop

000000000000cb10 <atexit>:
    cb10:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cb14:	900000a2 	adrp	x2, 20000 <__data_start>
    cb18:	d2800001 	mov	x1, #0x0                   	// #0
    cb1c:	910003fd 	mov	x29, sp
    cb20:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cb24:	f9400442 	ldr	x2, [x2, #8]
    cb28:	17ffd716 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000cb2c <_fini>:
    cb2c:	d503201f 	nop
    cb30:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cb34:	910003fd 	mov	x29, sp
    cb38:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cb3c:	d65f03c0 	ret
