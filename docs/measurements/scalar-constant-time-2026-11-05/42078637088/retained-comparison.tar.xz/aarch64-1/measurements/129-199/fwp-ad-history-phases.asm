
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__divti3+0x2f0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911ba0a5 	add	x5, x5, #0x6e8
    2aa0:	f0000044 	adrp	x4, d000 <__divti3+0x2f0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	911bc084 	add	x4, x4, #0x6f0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9101c261 	add	x1, x19, #0x70
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe930>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9004420 	str	x0, [x1, #136]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__divti3+0x2f0>
    2b34:	912b2000 	add	x0, x0, #0xac8
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1ee0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	911e5042 	add	x2, x2, #0x794
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c273 	add	x19, x19, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435a60 	ldr	w0, [x19, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <__divti3+0x2f0>
    2c7c:	912b6000 	add	x0, x0, #0xad8
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <__divti3+0x2f0>
    2c8c:	912de000 	add	x0, x0, #0xb78
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <__divti3+0x2f0>
    2ca4:	912d4000 	add	x0, x0, #0xb50
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <__divti3+0x2f0>
    2cb0:	912c8000 	add	x0, x0, #0xb20
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <__divti3+0x2f0>
    2cbc:	912be000 	add	x0, x0, #0xaf8
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xbd0>
    2eb4:	91078021 	add	x1, x1, #0x1e0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3050:	9110e000 	add	x0, x0, #0x438
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xbd0>
    3118:	91070021 	add	x1, x1, #0x1c0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3150:	91114000 	add	x0, x0, #0x450
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	d0000042 	adrp	x2, d000 <__divti3+0x2f0>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	d0000056 	adrp	x22, d000 <__divti3+0x2f0>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	d0000058 	adrp	x24, d000 <__divti3+0x2f0>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	91126042 	add	x2, x2, #0x498
    31e0:	9113c2d6 	add	x22, x22, #0x4f0
    31e4:	913d2318 	add	x24, x24, #0xf48
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	d0000059 	adrp	x25, d000 <__divti3+0x2f0>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	9113a323 	add	x3, x25, #0x4e8
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	91140000 	add	x0, x0, #0x500
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3570:	9110e000 	add	x0, x0, #0x438
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <__divti3+0x2f0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91142021 	add	x1, x1, #0x508
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <__divti3+0x2f0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91144021 	add	x1, x1, #0x510
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <__divti3+0x2f0>
    37e0:	91146021 	add	x1, x1, #0x518
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffdf1 	bl	2ff0 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000042 	adrp	x2, d000 <__divti3+0x2f0>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91148042 	add	x2, x2, #0x520
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc2b 	bl	28f0 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc58 	bl	29b0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc66 	bl	29f0 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbb4 	bl	2730 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbd4 	bl	2820 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbb7 	bl	27d0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc0f 	bl	2940 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3950:	9110e000 	add	x0, x0, #0x438
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc0a 	bl	2980 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc14 	bl	29b0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc22 	bl	29f0 <_Exit@plt>
    396c:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3970:	9114c000 	add	x0, x0, #0x530
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb82 	bl	27b0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3a08:	91154000 	add	x0, x0, #0x550
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffb9c 	bl	2880 <__stack_chk_fail@plt>
    3a14:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3a18:	9115c000 	add	x0, x0, #0x570
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xbd0>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc07c20 	ldr	q0, [x1, #496]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	9101c2b5 	add	x21, x21, #0x70
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f94046a2 	ldr	x2, [x21, #136]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb97 	bl	2940 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3b18:	91166000 	add	x0, x0, #0x598
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb57 	bl	2880 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	9350fc01 	asr	x1, x0, #16
    3b3c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b40:	d1000440 	sub	x0, x2, #0x1
    3b44:	9101c062 	add	x2, x3, #0x70
    3b48:	f9404842 	ldr	x2, [x2, #144]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9403863 	ldr	x3, [x3, #112]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3b88:	91172000 	add	x0, x0, #0x5c8
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000044 	adrp	x4, d000 <__divti3+0x2f0>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	91186084 	add	x4, x4, #0x618
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffafe 	bl	27f0 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb57 	bl	2960 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb42 	bl	2920 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa8b 	bl	26d0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffac3 	bl	27d0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffab4 	bl	27d0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa6c 	bl	26d0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa78 	bl	2710 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb08 	bl	2960 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000044 	adrp	x4, d000 <__divti3+0x2f0>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	9118c084 	add	x4, x4, #0x630
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa88 	bl	27f0 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa77 	bl	27d0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffad7 	bl	2960 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000044 	adrp	x4, d000 <__divti3+0x2f0>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	91188084 	add	x4, x4, #0x620
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa60 	bl	27f0 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa4a 	bl	27d0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa1e 	bl	27d0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa3a 	bl	2880 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3fa8:	91174042 	add	x2, x2, #0x5d0
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000041 	adrp	x1, d000 <__divti3+0x2f0>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000040 	adrp	x0, d000 <__divti3+0x2f0>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	9118e021 	add	x1, x1, #0x638
    4004:	91190000 	add	x0, x0, #0x640
    4008:	97fffa02 	bl	2810 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa83 	bl	2a40 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa2d 	bl	2920 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa70 	bl	2a40 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9dd 	bl	2800 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000042 	adrp	x2, d000 <__divti3+0x2f0>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	91198042 	add	x2, x2, #0x660
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa00 	b	28f0 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e0 	bl	2880 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    410c:	91134061 	add	x1, x3, #0x4d0
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    411c:	91174262 	add	x2, x19, #0x5d0
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0xbd0>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    414c:	91144021 	add	x1, x1, #0x510
    4150:	3dc08043 	ldr	q3, [x2, #512]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    417c:	91134063 	add	x3, x3, #0x4d0
    4180:	9115c084 	add	x4, x4, #0x570
    4184:	91174266 	add	x6, x19, #0x5d0
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9c5 	bl	2910 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91174275 	add	x21, x19, #0x5d0
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9af 	bl	2910 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000040 	adrp	x0, d000 <__divti3+0x2f0>
    4268:	911c4000 	add	x0, x0, #0x710
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9e8 	bl	2a10 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91174273 	add	x19, x19, #0x5d0
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffb5c 	bl	3030 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	9101c122 	add	x2, x9, #0x70
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9403c46 	ldr	x6, [x2, #120]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	9101c120 	add	x0, x9, #0x70
    4354:	f900400b 	str	x11, [x0, #128]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	9101c129 	add	x9, x9, #0x70
    4360:	f9003d26 	str	x6, [x9, #120]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <fwp_tape_buffers_release>:
    4380:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4384:	910003fd 	mov	x29, sp
    4388:	a90153f3 	stp	x19, x20, [sp, #16]
    438c:	aa0003f3 	mov	x19, x0
    4390:	f9401400 	ldr	x0, [x0, #40]
    4394:	b7f80760 	tbnz	x0, #63, 4480 <fwp_tape_buffers_release+0x100>
    4398:	f9401a61 	ldr	x1, [x19, #48]
    439c:	b7f80301 	tbnz	x1, #63, 43fc <fwp_tape_buffers_release+0x7c>
    43a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    43a4:	eb02001f 	cmp	x0, x2
    43a8:	540002a8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43ac:	8b000400 	add	x0, x0, x0, lsl #1
    43b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    43b4:	d37df000 	lsl	x0, x0, #3
    43b8:	cb000042 	sub	x2, x2, x0
    43bc:	eb420c3f 	cmp	x1, x2, lsr #3
    43c0:	540001e8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43c4:	8b010c14 	add	x20, x0, x1, lsl #3
    43c8:	b0000040 	adrp	x0, d000 <__divti3+0x2f0>
    43cc:	911c8000 	add	x0, x0, #0x720
    43d0:	97fff990 	bl	2a10 <getenv@plt>
    43d4:	b4000240 	cbz	x0, 441c <fwp_tape_buffers_release+0x9c>
    43d8:	39400001 	ldrb	w1, [x0]
    43dc:	7100c03f 	cmp	w1, #0x30
    43e0:	540001e1 	b.ne	441c <fwp_tape_buffers_release+0x9c>  // b.any
    43e4:	39400400 	ldrb	w0, [x0, #1]
    43e8:	350001a0 	cbnz	w0, 441c <fwp_tape_buffers_release+0x9c>
    43ec:	aa1303e0 	mov	x0, x19
    43f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    43f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f8:	17fffc22 	b	3480 <fwp_tape_buffers_dispose>
    43fc:	b0000040 	adrp	x0, d000 <__divti3+0x2f0>
    4400:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4404:	911c8000 	add	x0, x0, #0x720
    4408:	97fff982 	bl	2a10 <getenv@plt>
    440c:	b4ffff00 	cbz	x0, 43ec <fwp_tape_buffers_release+0x6c>
    4410:	39400001 	ldrb	w1, [x0]
    4414:	7100c03f 	cmp	w1, #0x30
    4418:	54fffe60 	b.eq	43e4 <fwp_tape_buffers_release+0x64>  // b.none
    441c:	d1000681 	sub	x1, x20, #0x1
    4420:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4424:	eb00003f 	cmp	x1, x0
    4428:	54fffe28 	b.hi	43ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    442c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4430:	900000f6 	adrp	x22, 20000 <__data_start>
    4434:	9101c2d6 	add	x22, x22, #0x70
    4438:	910262d5 	add	x21, x22, #0x98
    443c:	aa1503e0 	mov	x0, x21
    4440:	97fffc10 	bl	3480 <fwp_tape_buffers_dispose>
    4444:	ad400a61 	ldp	q1, q2, [x19]
    4448:	f9006ad4 	str	x20, [x22, #208]
    444c:	4f000400 	movi	v0.4s, #0x0
    4450:	ad000aa1 	stp	q1, q2, [x21]
    4454:	3dc00a61 	ldr	q1, [x19, #32]
    4458:	3d800aa1 	str	q1, [x21, #32]
    445c:	f9401a60 	ldr	x0, [x19, #48]
    4460:	f9001aa0 	str	x0, [x21, #48]
    4464:	f9001a7f 	str	xzr, [x19, #48]
    4468:	ad000260 	stp	q0, q0, [x19]
    446c:	3d800a60 	str	q0, [x19, #32]
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4478:	a8c37bfd 	ldp	x29, x30, [sp], #48
    447c:	d65f03c0 	ret
    4480:	b0000040 	adrp	x0, d000 <__divti3+0x2f0>
    4484:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4488:	911c8000 	add	x0, x0, #0x720
    448c:	97fff961 	bl	2a10 <getenv@plt>
    4490:	b5fffa40 	cbnz	x0, 43d8 <fwp_tape_buffers_release+0x58>
    4494:	17ffffd6 	b	43ec <fwp_tape_buffers_release+0x6c>
    4498:	d503201f 	nop
    449c:	d503201f 	nop

00000000000044a0 <fwp_poll_events>:
    44a0:	d10103ff 	sub	sp, sp, #0x40
    44a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    44a8:	f947f400 	ldr	x0, [x0, #4072]
    44ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    44b0:	910083fd 	add	x29, sp, #0x20
    44b4:	a90353f3 	stp	x19, x20, [sp, #48]
    44b8:	900000f4 	adrp	x20, 20000 <__data_start>
    44bc:	f9400001 	ldr	x1, [x0]
    44c0:	f9000fe1 	str	x1, [sp, #24]
    44c4:	d2800001 	mov	x1, #0x0                   	// #0
    44c8:	97fffd2e 	bl	3980 <fwp_now_ns>
    44cc:	9101c281 	add	x1, x20, #0x70
    44d0:	f9406c33 	ldr	x19, [x1, #216]
    44d4:	b4000e93 	cbz	x19, 46a4 <fwp_poll_events+0x204>
    44d8:	aa1303e1 	mov	x1, x19
    44dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    44e0:	14000005 	b	44f4 <fwp_poll_events+0x54>
    44e4:	f9408821 	ldr	x1, [x1, #272]
    44e8:	eb03005f 	cmp	x2, x3
    44ec:	9a83d042 	csel	x2, x2, x3, le
    44f0:	b40000c1 	cbz	x1, 4508 <fwp_poll_events+0x68>
    44f4:	f9403423 	ldr	x3, [x1, #104]
    44f8:	b6ffff62 	tbz	x2, #63, 44e4 <fwp_poll_events+0x44>
    44fc:	f9408821 	ldr	x1, [x1, #272]
    4500:	aa0303e2 	mov	x2, x3
    4504:	b5ffff81 	cbnz	x1, 44f4 <fwp_poll_events+0x54>
    4508:	b7f80ce2 	tbnz	x2, #63, 46a4 <fwp_poll_events+0x204>
    450c:	cb000042 	sub	x2, x2, x0
    4510:	f100005f 	cmp	x2, #0x0
    4514:	540005cd 	b.le	45cc <fwp_poll_events+0x12c>
    4518:	d2869b60 	mov	x0, #0x34db                	// #13531
    451c:	d2884801 	mov	x1, #0x4240                	// #16960
    4520:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4524:	f2a001e1 	movk	x1, #0xf, lsl #16
    4528:	f2dbd040 	movk	x0, #0xde82, lsl #32
    452c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4530:	f2e86360 	movk	x0, #0x431b, lsl #48
    4534:	9b407c40 	smulh	x0, x2, x0
    4538:	9352fc00 	asr	x0, x0, #18
    453c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4540:	9b018802 	msub	x2, x0, x1, x2
    4544:	f100005f 	cmp	x2, #0x0
    4548:	9a800400 	cinc	x0, x0, ne	// ne = any
    454c:	eb03001f 	cmp	x0, x3
    4550:	54000a0c 	b.gt	4690 <fwp_poll_events+0x1f0>
    4554:	340003c0 	cbz	w0, 45cc <fwp_poll_events+0x12c>
    4558:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    455c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4560:	72a20c42 	movk	w2, #0x1062, lsl #16
    4564:	9ba27c02 	umull	x2, w0, w2
    4568:	d366fc43 	lsr	x3, x2, #38
    456c:	aa0303e2 	mov	x2, x3
    4570:	1b048063 	msub	w3, w3, w4, w0
    4574:	9b217c63 	smull	x3, w3, w1
    4578:	d2800001 	mov	x1, #0x0                   	// #0
    457c:	910023e0 	add	x0, sp, #0x8
    4580:	a9008fe2 	stp	x2, x3, [sp, #8]
    4584:	97fff8f3 	bl	2950 <nanosleep@plt>
    4588:	9101c280 	add	x0, x20, #0x70
    458c:	f9406c13 	ldr	x19, [x0, #216]
    4590:	97fffcfc 	bl	3980 <fwp_now_ns>
    4594:	aa0003e6 	mov	x6, x0
    4598:	b50001f3 	cbnz	x19, 45d4 <fwp_poll_events+0x134>
    459c:	d503201f 	nop
    45a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45a4:	f947f400 	ldr	x0, [x0, #4072]
    45a8:	f9400fe2 	ldr	x2, [sp, #24]
    45ac:	f9400001 	ldr	x1, [x0]
    45b0:	eb010042 	subs	x2, x2, x1
    45b4:	d2800001 	mov	x1, #0x0                   	// #0
    45b8:	540008c1 	b.ne	46d0 <fwp_poll_events+0x230>  // b.any
    45bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    45c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    45c4:	910103ff 	add	sp, sp, #0x40
    45c8:	d65f03c0 	ret
    45cc:	97fffced 	bl	3980 <fwp_now_ns>
    45d0:	aa0003e6 	mov	x6, x0
    45d4:	4f000400 	movi	v0.4s, #0x0
    45d8:	9101c288 	add	x8, x20, #0x70
    45dc:	52800027 	mov	w7, #0x1                   	// #1
    45e0:	f9403661 	ldr	x1, [x19, #104]
    45e4:	aa1303e5 	mov	x5, x19
    45e8:	f9408a73 	ldr	x19, [x19, #272]
    45ec:	eb06003f 	cmp	x1, x6
    45f0:	5400032c 	b.gt	4654 <fwp_poll_events+0x1b4>
    45f4:	394154a0 	ldrb	w0, [x5, #85]
    45f8:	36000120 	tbz	w0, #0, 461c <fwp_poll_events+0x17c>
    45fc:	f94084a0 	ldr	x0, [x5, #264]
    4600:	b40003c0 	cbz	x0, 4678 <fwp_poll_events+0x1d8>
    4604:	f9008813 	str	x19, [x0, #272]
    4608:	b4000053 	cbz	x19, 4610 <fwp_poll_events+0x170>
    460c:	f9008660 	str	x0, [x19, #264]
    4610:	910800a0 	add	x0, x5, #0x200
    4614:	390154bf 	strb	wzr, [x5, #85]
    4618:	3c908000 	stur	q0, [x0, #-248]
    461c:	f94030a0 	ldr	x0, [x5, #96]
    4620:	390158a7 	strb	w7, [x5, #86]
    4624:	f100001f 	cmp	x0, #0x0
    4628:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    462c:	5400018d 	b.le	465c <fwp_poll_events+0x1bc>
    4630:	f94028a0 	ldr	x0, [x5, #80]
    4634:	f2001c1f 	tst	x0, #0xff000000ff
    4638:	540000e1 	b.ne	4654 <fwp_poll_events+0x1b4>  // b.any
    463c:	f9403d00 	ldr	x0, [x8, #120]
    4640:	390150a7 	strb	w7, [x5, #84]
    4644:	f90080bf 	str	xzr, [x5, #256]
    4648:	b40001e0 	cbz	x0, 4684 <fwp_poll_events+0x1e4>
    464c:	f9003d05 	str	x5, [x8, #120]
    4650:	f9008005 	str	x5, [x0, #256]
    4654:	b5fffc73 	cbnz	x19, 45e0 <fwp_poll_events+0x140>
    4658:	17ffffd2 	b	45a0 <fwp_poll_events+0x100>
    465c:	394144a0 	ldrb	w0, [x5, #81]
    4660:	3707fe80 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    4664:	394140a0 	ldrb	w0, [x5, #80]
    4668:	3707fe40 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    466c:	aa0503e0 	mov	x0, x5
    4670:	97fffc20 	bl	36f0 <fwp_cancel_tree.part.0>
    4674:	17ffffef 	b	4630 <fwp_poll_events+0x190>
    4678:	9101c281 	add	x1, x20, #0x70
    467c:	f9006c33 	str	x19, [x1, #216]
    4680:	17ffffe2 	b	4608 <fwp_poll_events+0x168>
    4684:	f9003d05 	str	x5, [x8, #120]
    4688:	f9004105 	str	x5, [x8, #128]
    468c:	17fffff2 	b	4654 <fwp_poll_events+0x1b4>
    4690:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4694:	d2989362 	mov	x2, #0xc49b                	// #50331
    4698:	f2a4d203 	movk	x3, #0x2690, lsl #16
    469c:	f2a00402 	movk	x2, #0x20, lsl #16
    46a0:	17ffffb6 	b	4578 <fwp_poll_events+0xd8>
    46a4:	97fffa53 	bl	2ff0 <fwp_flush>
    46a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    46ac:	f947e863 	ldr	x3, [x3, #4048]
    46b0:	d2800562 	mov	x2, #0x2b                  	// #43
    46b4:	d2800021 	mov	x1, #0x1                   	// #1
    46b8:	b0000040 	adrp	x0, d000 <__divti3+0x2f0>
    46bc:	911ce000 	add	x0, x0, #0x738
    46c0:	f9400063 	ldr	x3, [x3]
    46c4:	97fff8af 	bl	2980 <fwrite@plt>
    46c8:	52800ca0 	mov	w0, #0x65                  	// #101
    46cc:	97fff819 	bl	2730 <exit@plt>
    46d0:	97fff86c 	bl	2880 <__stack_chk_fail@plt>

00000000000046d4 <fwp_rc_wide_dup>:
    46d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    46d8:	910003fd 	mov	x29, sp
    46dc:	a90153f3 	stp	x19, x20, [sp, #16]
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	ca404400 	eor	x0, x0, x0, lsr #17
    46e8:	f90013f5 	str	x21, [sp, #32]
    46ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    46f0:	ca402400 	eor	x0, x0, x0, lsr #9
    46f4:	911742a2 	add	x2, x21, #0x5d0
    46f8:	92401c00 	and	x0, x0, #0xff
    46fc:	910a2403 	add	x3, x0, #0x289
    4700:	8b000c40 	add	x0, x2, x0, lsl #3
    4704:	8b030c54 	add	x20, x2, x3, lsl #3
    4708:	f94a2401 	ldr	x1, [x0, #5192]
    470c:	b50000a1 	cbnz	x1, 4720 <fwp_rc_wide_dup+0x4c>
    4710:	1400002d 	b	47c4 <fwp_rc_wide_dup+0xf0>
    4714:	91004034 	add	x20, x1, #0x10
    4718:	f9400821 	ldr	x1, [x1, #16]
    471c:	b4000241 	cbz	x1, 4764 <fwp_rc_wide_dup+0x90>
    4720:	f9400022 	ldr	x2, [x1]
    4724:	eb02027f 	cmp	x19, x2
    4728:	54ffff61 	b.ne	4714 <fwp_rc_wide_dup+0x40>  // b.any
    472c:	f9400281 	ldr	x1, [x20]
    4730:	39400260 	ldrb	w0, [x19]
    4734:	7103f81f 	cmp	w0, #0xfe
    4738:	54000220 	b.eq	477c <fwp_rc_wide_dup+0xa8>  // b.none
    473c:	b40001a1 	cbz	x1, 4770 <fwp_rc_wide_dup+0x9c>
    4740:	f9400420 	ldr	x0, [x1, #8]
    4744:	b100041f 	cmn	x0, #0x1
    4748:	540004a0 	b.eq	47dc <fwp_rc_wide_dup+0x108>  // b.none
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f9000420 	str	x0, [x1, #8]
    4754:	a94153f3 	ldp	x19, x20, [sp, #16]
    4758:	f94013f5 	ldr	x21, [sp, #32]
    475c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4760:	d65f03c0 	ret
    4764:	39400260 	ldrb	w0, [x19]
    4768:	7103f81f 	cmp	w0, #0xfe
    476c:	540000a0 	b.eq	4780 <fwp_rc_wide_dup+0xac>  // b.none
    4770:	b0000040 	adrp	x0, d000 <__divti3+0x2f0>
    4774:	911e4000 	add	x0, x0, #0x790
    4778:	97fffc22 	bl	3800 <fwp_trap>
    477c:	b5000281 	cbnz	x1, 47cc <fwp_rc_wide_dup+0xf8>
    4780:	d2800300 	mov	x0, #0x18                  	// #24
    4784:	97fff827 	bl	2820 <malloc@plt>
    4788:	b4000280 	cbz	x0, 47d8 <fwp_rc_wide_dup+0x104>
    478c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4790:	a9000413 	stp	x19, x1, [x0]
    4794:	911742b5 	add	x21, x21, #0x5d0
    4798:	f900081f 	str	xzr, [x0, #16]
    479c:	12800001 	mov	w1, #0xffffffff            	// #-1
    47a0:	f9000280 	str	x0, [x20]
    47a4:	39000261 	strb	w1, [x19]
    47a8:	f94e26a0 	ldr	x0, [x21, #7240]
    47ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    47b0:	91000400 	add	x0, x0, #0x1
    47b4:	f90e26a0 	str	x0, [x21, #7240]
    47b8:	f94013f5 	ldr	x21, [sp, #32]
    47bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47c0:	d65f03c0 	ret
    47c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    47c8:	17ffffda 	b	4730 <fwp_rc_wide_dup+0x5c>
    47cc:	b0000040 	adrp	x0, d000 <__divti3+0x2f0>
    47d0:	911da000 	add	x0, x0, #0x768
    47d4:	97fffc0b 	bl	3800 <fwp_trap>
    47d8:	97fffa16 	bl	3030 <fwp_heap_oom>
    47dc:	b0000040 	adrp	x0, d000 <__divti3+0x2f0>
    47e0:	911ee000 	add	x0, x0, #0x7b8
    47e4:	97fffc07 	bl	3800 <fwp_trap>
    47e8:	d503201f 	nop
    47ec:	d503201f 	nop

00000000000047f0 <fwp_rc_forget_slot>:
    47f0:	aa0003e1 	mov	x1, x0
    47f4:	39400000 	ldrb	w0, [x0]
    47f8:	7103fc1f 	cmp	w0, #0xff
    47fc:	54000040 	b.eq	4804 <fwp_rc_forget_slot+0x14>  // b.none
    4800:	d65f03c0 	ret
    4804:	ca414420 	eor	x0, x1, x1, lsr #17
    4808:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    480c:	ca402400 	eor	x0, x0, x0, lsr #9
    4810:	910003fd 	mov	x29, sp
    4814:	92401c00 	and	x0, x0, #0xff
    4818:	f9000bf3 	str	x19, [sp, #16]
    481c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4820:	91174262 	add	x2, x19, #0x5d0
    4824:	910a2403 	add	x3, x0, #0x289
    4828:	8b000c40 	add	x0, x2, x0, lsl #3
    482c:	8b030c43 	add	x3, x2, x3, lsl #3
    4830:	f94a2400 	ldr	x0, [x0, #5192]
    4834:	b50000a0 	cbnz	x0, 4848 <fwp_rc_forget_slot+0x58>
    4838:	14000011 	b	487c <fwp_rc_forget_slot+0x8c>
    483c:	91004003 	add	x3, x0, #0x10
    4840:	f9400800 	ldr	x0, [x0, #16]
    4844:	b40001c0 	cbz	x0, 487c <fwp_rc_forget_slot+0x8c>
    4848:	f9400002 	ldr	x2, [x0]
    484c:	eb02003f 	cmp	x1, x2
    4850:	54ffff61 	b.ne	483c <fwp_rc_forget_slot+0x4c>  // b.any
    4854:	f9400801 	ldr	x1, [x0, #16]
    4858:	91174273 	add	x19, x19, #0x5d0
    485c:	f9000061 	str	x1, [x3]
    4860:	97fff838 	bl	2940 <free@plt>
    4864:	f94e2660 	ldr	x0, [x19, #7240]
    4868:	d1000400 	sub	x0, x0, #0x1
    486c:	f90e2660 	str	x0, [x19, #7240]
    4870:	f9400bf3 	ldr	x19, [sp, #16]
    4874:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4878:	d65f03c0 	ret
    487c:	b0000040 	adrp	x0, d000 <__divti3+0x2f0>
    4880:	911e4000 	add	x0, x0, #0x790
    4884:	97fffbdf 	bl	3800 <fwp_trap>
    4888:	d503201f 	nop
    488c:	d503201f 	nop

0000000000004890 <fwp_rc_prepare_chunk>:
    4890:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4894:	910003fd 	mov	x29, sp
    4898:	a9025bf5 	stp	x21, x22, [sp, #32]
    489c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    48a0:	911742c2 	add	x2, x22, #0x5d0
    48a4:	b9401c03 	ldr	w3, [x0, #28]
    48a8:	aa0103f5 	mov	x21, x1
    48ac:	a90153f3 	stp	x19, x20, [sp, #16]
    48b0:	aa0003f4 	mov	x20, x0
    48b4:	f94e2440 	ldr	x0, [x2, #7240]
    48b8:	b4000440 	cbz	x0, 4940 <fwp_rc_prepare_chunk+0xb0>
    48bc:	d2800013 	mov	x19, #0x0                   	// #0
    48c0:	35000203 	cbnz	w3, 4900 <fwp_rc_prepare_chunk+0x70>
    48c4:	b4000361 	cbz	x1, 4930 <fwp_rc_prepare_chunk+0xa0>
    48c8:	f9401280 	ldr	x0, [x20, #32]
    48cc:	97fff81d 	bl	2940 <free@plt>
    48d0:	aa1503e0 	mov	x0, x21
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	97fff7e2 	bl	2860 <calloc@plt>
    48dc:	f9001280 	str	x0, [x20, #32]
    48e0:	b5000460 	cbnz	x0, 496c <fwp_rc_prepare_chunk+0xdc>
    48e4:	97fff9d3 	bl	3030 <fwp_heap_oom>
    48e8:	97ffffc2 	bl	47f0 <fwp_rc_forget_slot>
    48ec:	91000673 	add	x19, x19, #0x1
    48f0:	b9401e83 	ldr	w3, [x20, #28]
    48f4:	eb13007f 	cmp	x3, x19
    48f8:	54000169 	b.ls	4924 <fwp_rc_prepare_chunk+0x94>  // b.plast
    48fc:	d503201f 	nop
    4900:	f9401283 	ldr	x3, [x20, #32]
    4904:	8b130060 	add	x0, x3, x19
    4908:	38736863 	ldrb	w3, [x3, x19]
    490c:	7103fc7f 	cmp	w3, #0xff
    4910:	54fffec0 	b.eq	48e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4914:	b9401e83 	ldr	w3, [x20, #28]
    4918:	91000673 	add	x19, x19, #0x1
    491c:	eb13007f 	cmp	x3, x19
    4920:	54ffff08 	b.hi	4900 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4924:	eb0302bf 	cmp	x21, x3
    4928:	54000121 	b.ne	494c <fwp_rc_prepare_chunk+0xbc>  // b.any
    492c:	b5000335 	cbnz	x21, 4990 <fwp_rc_prepare_chunk+0x100>
    4930:	a94153f3 	ldp	x19, x20, [sp, #16]
    4934:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4938:	a8c37bfd 	ldp	x29, x30, [sp], #48
    493c:	d65f03c0 	ret
    4940:	2a0303e3 	mov	w3, w3
    4944:	eb0302bf 	cmp	x21, x3
    4948:	54ffff20 	b.eq	492c <fwp_rc_prepare_chunk+0x9c>  // b.none
    494c:	911742c2 	add	x2, x22, #0x5d0
    4950:	f9401280 	ldr	x0, [x20, #32]
    4954:	f94e2841 	ldr	x1, [x2, #7248]
    4958:	cb030021 	sub	x1, x1, x3
    495c:	f90e2841 	str	x1, [x2, #7248]
    4960:	97fff7f8 	bl	2940 <free@plt>
    4964:	b5fffb75 	cbnz	x21, 48d0 <fwp_rc_prepare_chunk+0x40>
    4968:	f900129f 	str	xzr, [x20, #32]
    496c:	911742d6 	add	x22, x22, #0x5d0
    4970:	f94e2ac0 	ldr	x0, [x22, #7248]
    4974:	b9001e95 	str	w21, [x20, #28]
    4978:	a94153f3 	ldp	x19, x20, [sp, #16]
    497c:	8b150000 	add	x0, x0, x21
    4980:	f90e2ac0 	str	x0, [x22, #7248]
    4984:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4988:	a8c37bfd 	ldp	x29, x30, [sp], #48
    498c:	d65f03c0 	ret
    4990:	f9401280 	ldr	x0, [x20, #32]
    4994:	aa1503e2 	mov	x2, x21
    4998:	a94153f3 	ldp	x19, x20, [sp, #16]
    499c:	52800001 	mov	w1, #0x0                   	// #0
    49a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49a8:	17fff7aa 	b	2850 <memset@plt>
    49ac:	d503201f 	nop

00000000000049b0 <fwp_heap_refill>:
    49b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    49b4:	910003fd 	mov	x29, sp
    49b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    49bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    49c0:	911742b5 	add	x21, x21, #0x5d0
    49c4:	aa0003f6 	mov	x22, x0
    49c8:	d2800020 	mov	x0, #0x1                   	// #1
    49cc:	a90153f3 	stp	x19, x20, [sp, #16]
    49d0:	a90363f7 	stp	x23, x24, [sp, #48]
    49d4:	2a0103f7 	mov	w23, w1
    49d8:	2a0203f8 	mov	w24, w2
    49dc:	97fffa35 	bl	32b0 <fwp_heap_chunks>
    49e0:	aa0003f3 	mov	x19, x0
    49e4:	f949fea2 	ldr	x2, [x21, #5112]
    49e8:	8b000800 	add	x0, x0, x0, lsl #2
    49ec:	2a1703e1 	mov	w1, w23
    49f0:	52800025 	mov	w5, #0x1                   	// #1
    49f4:	d37df000 	lsl	x0, x0, #3
    49f8:	910f0021 	add	x1, x1, #0x3c0
    49fc:	8b000054 	add	x20, x2, x0
    4a00:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a04:	52a00024 	mov	w4, #0x10000               	// #65536
    4a08:	38206845 	strb	w5, [x2, x0]
    4a0c:	aa1403e0 	mov	x0, x20
    4a10:	39000698 	strb	w24, [x20, #1]
    4a14:	39000a97 	strb	w23, [x20, #2]
    4a18:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a1c:	b9000681 	str	w1, [x20, #4]
    4a20:	2a0103e5 	mov	w5, w1
    4a24:	8b0300a2 	add	x2, x5, x3
    4a28:	1ac10881 	udiv	w1, w4, w1
    4a2c:	9ac50842 	udiv	x2, x2, x5
    4a30:	b9000a81 	str	w1, [x20, #8]
    4a34:	92404021 	and	x1, x1, #0x1ffff
    4a38:	b9001a82 	str	w2, [x20, #24]
    4a3c:	97ffff95 	bl	4890 <fwp_rc_prepare_chunk>
    4a40:	f949daa0 	ldr	x0, [x21, #5040]
    4a44:	29408a81 	ldp	w1, w2, [x20, #4]
    4a48:	8b134000 	add	x0, x0, x19, lsl #16
    4a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a50:	8b214003 	add	x3, x0, w1, uxtw
    4a54:	9ba20021 	umaddl	x1, w1, w2, x0
    4a58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a5c:	a90086c3 	stp	x3, x1, [x22, #8]
    4a60:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a64:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4a68:	d65f03c0 	ret
    4a6c:	d503201f 	nop

0000000000004a70 <fwp_mem_free>:
    4a70:	b40003c0 	cbz	x0, 4ae8 <fwp_mem_free+0x78>
    4a74:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4a78:	910003fd 	mov	x29, sp
    4a7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a80:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a84:	911742a1 	add	x1, x21, #0x5d0
    4a88:	a90153f3 	stp	x19, x20, [sp, #16]
    4a8c:	aa0003f3 	mov	x19, x0
    4a90:	f949d823 	ldr	x3, [x1, #5040]
    4a94:	f949ec22 	ldr	x2, [x1, #5080]
    4a98:	cb030000 	sub	x0, x0, x3
    4a9c:	eb02401f 	cmp	x0, x2, lsl #16
    4aa0:	540001c2 	b.cs	4ad8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4aa4:	d350fc16 	lsr	x22, x0, #16
    4aa8:	a90363f7 	stp	x23, x24, [sp, #48]
    4aac:	f949fc22 	ldr	x2, [x1, #5112]
    4ab0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4ab4:	d37df294 	lsl	x20, x20, #3
    4ab8:	ab140057 	adds	x23, x2, x20
    4abc:	540000c0 	b.eq	4ad4 <fwp_mem_free+0x64>  // b.none
    4ac0:	38746842 	ldrb	w2, [x2, x20]
    4ac4:	7100045f 	cmp	w2, #0x1
    4ac8:	54000120 	b.eq	4aec <fwp_mem_free+0x7c>  // b.none
    4acc:	7100085f 	cmp	w2, #0x2
    4ad0:	540005e0 	b.eq	4b8c <fwp_mem_free+0x11c>  // b.none
    4ad4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4adc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ae4:	d65f03c0 	ret
    4ae8:	d65f03c0 	ret
    4aec:	f94012f8 	ldr	x24, [x23, #32]
    4af0:	b94006e1 	ldr	w1, [x23, #4]
    4af4:	f90023f9 	str	x25, [sp, #64]
    4af8:	2a0103e2 	mov	w2, w1
    4afc:	394006f9 	ldrb	w25, [x23, #1]
    4b00:	39400af4 	ldrb	w20, [x23, #2]
    4b04:	b4000158 	cbz	x24, 4b2c <fwp_mem_free+0xbc>
    4b08:	92403e76 	and	x22, x19, #0xffff
    4b0c:	9ac20ad6 	udiv	x22, x22, x2
    4b10:	38766b01 	ldrb	w1, [x24, x22]
    4b14:	8b160300 	add	x0, x24, x22
    4b18:	7103fc3f 	cmp	w1, #0xff
    4b1c:	54000980 	b.eq	4c4c <fwp_mem_free+0x1dc>  // b.none
    4b20:	38366b1f 	strb	wzr, [x24, x22]
    4b24:	b94006e1 	ldr	w1, [x23, #4]
    4b28:	2a0103e2 	mov	w2, w1
    4b2c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4b30:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4b34:	cb390000 	sub	x0, x0, w25, uxtb
    4b38:	8b340074 	add	x20, x3, w20, uxtb
    4b3c:	911742b5 	add	x21, x21, #0x5d0
    4b40:	1e630021 	ucvtf	d1, w1
    4b44:	d37ae400 	lsl	x0, x0, #6
    4b48:	8b140c14 	add	x20, x0, x20, lsl #3
    4b4c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b50:	f8746aa0 	ldr	x0, [x21, x20]
    4b54:	f94023f9 	ldr	x25, [sp, #64]
    4b58:	aa2003e0 	mvn	x0, x0
    4b5c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4b60:	f9000260 	str	x0, [x19]
    4b64:	f8346ab3 	str	x19, [x21, x20]
    4b68:	f94a12a0 	ldr	x0, [x21, #5152]
    4b6c:	1e612800 	fadd	d0, d0, d1
    4b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b74:	cb020000 	sub	x0, x0, x2
    4b78:	f90a12a0 	str	x0, [x21, #5152]
    4b7c:	fd0a22a0 	str	d0, [x21, #5184]
    4b80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b84:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b88:	d65f03c0 	ret
    4b8c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4b90:	8b000063 	add	x3, x3, x0
    4b94:	eb03027f 	cmp	x19, x3
    4b98:	54fff9e1 	b.ne	4ad4 <fwp_mem_free+0x64>  // b.any
    4b9c:	fd400ae1 	ldr	d1, [x23, #16]
    4ba0:	fd4a2020 	ldr	d0, [x1, #5184]
    4ba4:	f9400ae0 	ldr	x0, [x23, #16]
    4ba8:	7e61d821 	ucvtf	d1, d1
    4bac:	f94a1022 	ldr	x2, [x1, #5152]
    4bb0:	f94012f3 	ldr	x19, [x23, #32]
    4bb4:	1e612800 	fadd	d0, d0, d1
    4bb8:	cb000042 	sub	x2, x2, x0
    4bbc:	f90a1022 	str	x2, [x1, #5152]
    4bc0:	fd0a2020 	str	d0, [x1, #5184]
    4bc4:	b40000b3 	cbz	x19, 4bd8 <fwp_mem_free+0x168>
    4bc8:	39400260 	ldrb	w0, [x19]
    4bcc:	7103fc1f 	cmp	w0, #0xff
    4bd0:	54000380 	b.eq	4c40 <fwp_mem_free+0x1d0>  // b.none
    4bd4:	3900027f 	strb	wzr, [x19]
    4bd8:	b9400ee2 	ldr	w2, [x23, #12]
    4bdc:	b4000142 	cbz	x2, 4c04 <fwp_mem_free+0x194>
    4be0:	911742a1 	add	x1, x21, #0x5d0
    4be4:	8b160040 	add	x0, x2, x22
    4be8:	8b000800 	add	x0, x0, x0, lsl #2
    4bec:	f949fc21 	ldr	x1, [x1, #5112]
    4bf0:	8b140034 	add	x20, x1, x20
    4bf4:	8b000c20 	add	x0, x1, x0, lsl #3
    4bf8:	3802869f 	strb	wzr, [x20], #40
    4bfc:	eb00029f 	cmp	x20, x0
    4c00:	54ffffc1 	b.ne	4bf8 <fwp_mem_free+0x188>  // b.any
    4c04:	911742a0 	add	x0, x21, #0x5d0
    4c08:	f94a1801 	ldr	x1, [x0, #5168]
    4c0c:	f949f803 	ldr	x3, [x0, #5104]
    4c10:	8b020021 	add	x1, x1, x2
    4c14:	f90a1801 	str	x1, [x0, #5168]
    4c18:	eb16007f 	cmp	x3, x22
    4c1c:	54000049 	b.ls	4c24 <fwp_mem_free+0x1b4>  // b.plast
    4c20:	f909f816 	str	x22, [x0, #5104]
    4c24:	911742b5 	add	x21, x21, #0x5d0
    4c28:	f949f6a0 	ldr	x0, [x21, #5096]
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54fff529 	b.ls	4ad4 <fwp_mem_free+0x64>  // b.plast
    4c34:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c38:	f909f6b6 	str	x22, [x21, #5096]
    4c3c:	17ffffa7 	b	4ad8 <fwp_mem_free+0x68>
    4c40:	aa1303e0 	mov	x0, x19
    4c44:	97fffeeb 	bl	47f0 <fwp_rc_forget_slot>
    4c48:	17ffffe3 	b	4bd4 <fwp_mem_free+0x164>
    4c4c:	97fffee9 	bl	47f0 <fwp_rc_forget_slot>
    4c50:	17ffffb4 	b	4b20 <fwp_mem_free+0xb0>

0000000000004c54 <fwp_heap_alloc_big>:
    4c54:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c58:	910003fd 	mov	x29, sp
    4c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c60:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c64:	a90363f7 	stp	x23, x24, [sp, #48]
    4c68:	aa0003f7 	mov	x23, x0
    4c6c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c70:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c74:	eb0002ff 	cmp	x23, x0
    4c78:	54000888 	b.hi	4d88 <fwp_heap_alloc_big+0x134>  // b.pmore
    4c7c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c80:	8b0002f4 	add	x20, x23, x0
    4c84:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c88:	91174359 	add	x25, x26, #0x5d0
    4c8c:	d350fe94 	lsr	x20, x20, #16
    4c90:	2a0103f5 	mov	w21, w1
    4c94:	aa1403e0 	mov	x0, x20
    4c98:	97fff986 	bl	32b0 <fwp_heap_chunks>
    4c9c:	f949ff22 	ldr	x2, [x25, #5112]
    4ca0:	8b000813 	add	x19, x0, x0, lsl #2
    4ca4:	aa0003f8 	mov	x24, x0
    4ca8:	52800043 	mov	w3, #0x2                   	// #2
    4cac:	d37df273 	lsl	x19, x19, #3
    4cb0:	d2800021 	mov	x1, #0x1                   	// #1
    4cb4:	8b130040 	add	x0, x2, x19
    4cb8:	38336843 	strb	w3, [x2, x19]
    4cbc:	39000415 	strb	w21, [x0, #1]
    4cc0:	b9000c14 	str	w20, [x0, #12]
    4cc4:	f9000817 	str	x23, [x0, #16]
    4cc8:	97fffef2 	bl	4890 <fwp_rc_prepare_chunk>
    4ccc:	f100069f 	cmp	x20, #0x1
    4cd0:	54000269 	b.ls	4d1c <fwp_heap_alloc_big+0xc8>  // b.plast
    4cd4:	8b180294 	add	x20, x20, x24
    4cd8:	9100a273 	add	x19, x19, #0x28
    4cdc:	a90573fb 	stp	x27, x28, [sp, #80]
    4ce0:	5280007b 	mov	w27, #0x3                   	// #3
    4ce4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce8:	2a1803fc 	mov	w28, w24
    4cec:	9adb2296 	lsl	x22, x20, x27
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffee4 	bl	4890 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0x9c>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x104>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffca4 	bl	4104 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff70 	b	4c54 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffeb5 	bl	49b0 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94046e0 	ldr	x0, [x23, #136]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_p_ad_push>:
    5224:	f100001f 	cmp	x0, #0x0
    5228:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    522c:	54000e8b 	b.lt	53fc <fwp_p_ad_push+0x1d8>  // b.tstop
    5230:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5234:	aa0003e4 	mov	x4, x0
    5238:	910003fd 	mov	x29, sp
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	aa0003f5 	mov	x21, x0
    5244:	aa020000 	orr	x0, x0, x2
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	aa0203f7 	mov	x23, x2
    5250:	6d0627e8 	stp	d8, d9, [sp, #96]
    5254:	9e670029 	fmov	d9, x1
    5258:	9e670068 	fmov	d8, x3
    525c:	b6f80900 	tbz	x0, #63, 537c <fwp_p_ad_push+0x158>
    5260:	a90153f3 	stp	x19, x20, [sp, #16]
    5264:	9360fc80 	asr	x0, x4, #32
    5268:	b6f800c4 	tbz	x4, #63, 5280 <fwp_p_ad_push+0x5c>
    526c:	1e604109 	fmov	d9, d8
    5270:	2f00e408 	movi	d8, #0x0
    5274:	9360fc40 	asr	x0, x2, #32
    5278:	aa0203f5 	mov	x21, x2
    527c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5280:	97fffa2c 	bl	3b30 <fwp_tape_of>
    5284:	aa0003f3 	mov	x19, x0
    5288:	f9403000 	ldr	x0, [x0, #96]
    528c:	b5001280 	cbnz	x0, 54dc <fwp_p_ad_push+0x2b8>
    5290:	f9400a76 	ldr	x22, [x19, #16]
    5294:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5298:	eb0002df 	cmp	x22, x0
    529c:	54000e2c 	b.gt	5460 <fwp_p_ad_push+0x23c>
    52a0:	eb3542df 	cmp	x22, w21, uxtw
    52a4:	54000d4d 	b.le	544c <fwp_p_ad_push+0x228>
    52a8:	b7f80077 	tbnz	x23, #63, 52b4 <fwp_p_ad_push+0x90>
    52ac:	eb3742df 	cmp	x22, w23, uxtw
    52b0:	54000ced 	b.le	544c <fwp_p_ad_push+0x228>
    52b4:	f9400678 	ldr	x24, [x19, #8]
    52b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    52bc:	cb1802d8 	sub	x24, x22, x24
    52c0:	91000701 	add	x1, x24, #0x1
    52c4:	eb00003f 	cmp	x1, x0
    52c8:	54000cc8 	b.hi	5460 <fwp_p_ad_push+0x23c>  // b.pmore
    52cc:	a9418274 	ldp	x20, x0, [x19, #24]
    52d0:	a90573fb 	stp	x27, x28, [sp, #80]
    52d4:	eb14003f 	cmp	x1, x20
    52d8:	5400068d 	b.le	53a8 <fwp_p_ad_push+0x184>
    52dc:	f100029f 	cmp	x20, #0x0
    52e0:	d2800803 	mov	x3, #0x40                  	// #64
    52e4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    52e8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    52ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    52f0:	eb14003f 	cmp	x1, x20
    52f4:	5400008d 	b.le	5304 <fwp_p_ad_push+0xe0>
    52f8:	eb02029f 	cmp	x20, x2
    52fc:	5400052d 	b.le	53a0 <fwp_p_ad_push+0x17c>
    5300:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5304:	d37df299 	lsl	x25, x20, #3
    5308:	aa1903e1 	mov	x1, x25
    530c:	97fff559 	bl	2870 <realloc@plt>
    5310:	aa0003e1 	mov	x1, x0
    5314:	b4000b00 	cbz	x0, 5474 <fwp_p_ad_push+0x250>
    5318:	f9400e62 	ldr	x2, [x19, #24]
    531c:	f9001261 	str	x1, [x19, #32]
    5320:	f9401a60 	ldr	x0, [x19, #48]
    5324:	d37cee9a 	lsl	x26, x20, #4
    5328:	8b020821 	add	x1, x1, x2, lsl #2
    532c:	f9001661 	str	x1, [x19, #40]
    5330:	aa1a03e1 	mov	x1, x26
    5334:	97fff54f 	bl	2870 <realloc@plt>
    5338:	aa0003e2 	mov	x2, x0
    533c:	b40009c0 	cbz	x0, 5474 <fwp_p_ad_push+0x250>
    5340:	f9400e61 	ldr	x1, [x19, #24]
    5344:	d37df31b 	lsl	x27, x24, #3
    5348:	d37ef685 	lsl	x5, x20, #2
    534c:	d37ef71c 	lsl	x28, x24, #2
    5350:	8b190004 	add	x4, x0, x25
    5354:	8b010c01 	add	x1, x0, x1, lsl #3
    5358:	a9030660 	stp	x0, x1, [x19, #48]
    535c:	b5000558 	cbnz	x24, 5404 <fwp_p_ad_push+0x1e0>
    5360:	f9001e64 	str	x4, [x19, #56]
    5364:	f9401260 	ldr	x0, [x19, #32]
    5368:	a9446bf9 	ldp	x25, x26, [sp, #64]
    536c:	8b050001 	add	x1, x0, x5
    5370:	f9000e74 	str	x20, [x19, #24]
    5374:	f9001661 	str	x1, [x19, #40]
    5378:	14000010 	b	53b8 <fwp_p_ad_push+0x194>
    537c:	9360fc40 	asr	x0, x2, #32
    5380:	a90153f3 	stp	x19, x20, [sp, #16]
    5384:	eb84801f 	cmp	x0, x4, asr #32
    5388:	54fff7c0 	b.eq	5280 <fwp_p_ad_push+0x5c>  // b.none
    538c:	90000040 	adrp	x0, d000 <__divti3+0x2f0>
    5390:	911f6000 	add	x0, x0, #0x7d8
    5394:	a9046bf9 	stp	x25, x26, [sp, #64]
    5398:	a90573fb 	stp	x27, x28, [sp, #80]
    539c:	97fff919 	bl	3800 <fwp_trap>
    53a0:	d37ffa94 	lsl	x20, x20, #1
    53a4:	17ffffd3 	b	52f0 <fwp_p_ad_push+0xcc>
    53a8:	a9428a61 	ldp	x1, x2, [x19, #40]
    53ac:	d37ef71c 	lsl	x28, x24, #2
    53b0:	f9401e64 	ldr	x4, [x19, #56]
    53b4:	d37df31b 	lsl	x27, x24, #3
    53b8:	b83c6815 	str	w21, [x0, x28]
    53bc:	f10002ff 	cmp	x23, #0x0
    53c0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    53c4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    53c8:	fc3b6849 	str	d9, [x2, x27]
    53cc:	aa1602a0 	orr	x0, x21, x22
    53d0:	b83c6837 	str	w23, [x1, x28]
    53d4:	910006d6 	add	x22, x22, #0x1
    53d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    53dc:	fc3b6888 	str	d8, [x4, x27]
    53e0:	a94573fb 	ldp	x27, x28, [sp, #80]
    53e4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    53e8:	f9000a76 	str	x22, [x19, #16]
    53ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    53f8:	d65f03c0 	ret
    53fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5400:	d65f03c0 	ret
    5404:	eb1a033f 	cmp	x25, x26
    5408:	aa0403e0 	mov	x0, x4
    540c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5410:	aa1b03e2 	mov	x2, x27
    5414:	cb190063 	sub	x3, x3, x25
    5418:	f9003fe5 	str	x5, [sp, #120]
    541c:	97fff581 	bl	2a20 <__memmove_chk@plt>
    5420:	a9420660 	ldp	x0, x1, [x19, #32]
    5424:	aa1c03e2 	mov	x2, x28
    5428:	f9401a63 	ldr	x3, [x19, #48]
    542c:	f9403fe5 	ldr	x5, [sp, #120]
    5430:	8b190063 	add	x3, x3, x25
    5434:	f9001e63 	str	x3, [x19, #56]
    5438:	8b050000 	add	x0, x0, x5
    543c:	97fff4ad 	bl	26f0 <memmove@plt>
    5440:	a9431262 	ldp	x2, x4, [x19, #48]
    5444:	f9403fe5 	ldr	x5, [sp, #120]
    5448:	17ffffc7 	b	5364 <fwp_p_ad_push+0x140>
    544c:	90000040 	adrp	x0, d000 <__divti3+0x2f0>
    5450:	9121c000 	add	x0, x0, #0x870
    5454:	a9046bf9 	stp	x25, x26, [sp, #64]
    5458:	a90573fb 	stp	x27, x28, [sp, #80]
    545c:	97fff8e9 	bl	3800 <fwp_trap>
    5460:	90000040 	adrp	x0, d000 <__divti3+0x2f0>
    5464:	91214000 	add	x0, x0, #0x850
    5468:	a9046bf9 	stp	x25, x26, [sp, #64]
    546c:	a90573fb 	stp	x27, x28, [sp, #80]
    5470:	97fff8e4 	bl	3800 <fwp_trap>
    5474:	aa1303e0 	mov	x0, x19
    5478:	97fff6c6 	bl	2f90 <fwp_tape_unlink_scope>
    547c:	f9401260 	ldr	x0, [x19, #32]
    5480:	97fff530 	bl	2940 <free@plt>
    5484:	f9401a60 	ldr	x0, [x19, #48]
    5488:	97fff52e 	bl	2940 <free@plt>
    548c:	f9402260 	ldr	x0, [x19, #64]
    5490:	97fff52c 	bl	2940 <free@plt>
    5494:	f9000e7f 	str	xzr, [x19, #24]
    5498:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    549c:	f947e821 	ldr	x1, [x1, #4048]
    54a0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    54a4:	d2800262 	mov	x2, #0x13                  	// #19
    54a8:	4f000400 	movi	v0.4s, #0x0
    54ac:	90000040 	adrp	x0, d000 <__divti3+0x2f0>
    54b0:	f9400023 	ldr	x3, [x1]
    54b4:	b900067f 	str	wzr, [x19, #4]
    54b8:	d2800021 	mov	x1, #0x1                   	// #1
    54bc:	9110e000 	add	x0, x0, #0x438
    54c0:	3c808260 	stur	q0, [x19, #8]
    54c4:	ad010260 	stp	q0, q0, [x19, #32]
    54c8:	97fff52e 	bl	2980 <fwrite@plt>
    54cc:	d2800000 	mov	x0, #0x0                   	// #0
    54d0:	97fff538 	bl	29b0 <fflush@plt>
    54d4:	52800cc0 	mov	w0, #0x66                  	// #102
    54d8:	97fff546 	bl	29f0 <_Exit@plt>
    54dc:	90000040 	adrp	x0, d000 <__divti3+0x2f0>
    54e0:	91208000 	add	x0, x0, #0x820
    54e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54e8:	a90573fb 	stp	x27, x28, [sp, #80]
    54ec:	97fff8c5 	bl	3800 <fwp_trap>

00000000000054f0 <w107>:
    54f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    54f4:	9e660003 	fmov	x3, d0
    54f8:	aa0003e2 	mov	x2, x0
    54fc:	910003fd 	mov	x29, sp
    5500:	6d0327e8 	stp	d8, d9, [sp, #48]
    5504:	1e604028 	fmov	d8, d1
    5508:	1e600809 	fmul	d9, d0, d0
    550c:	fd0023ea 	str	d10, [sp, #64]
    5510:	1e60400a 	fmov	d10, d0
    5514:	a90153f3 	stp	x19, x20, [sp, #16]
    5518:	aa0003f3 	mov	x19, x0
    551c:	aa0103f4 	mov	x20, x1
    5520:	aa0303e1 	mov	x1, x3
    5524:	a9025bf5 	stp	x21, x22, [sp, #32]
    5528:	97ffff3f 	bl	5224 <fwp_p_ad_push>
    552c:	1e693908 	fsub	d8, d8, d9
    5530:	aa1403e2 	mov	x2, x20
    5534:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5538:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    553c:	9e660116 	fmov	x22, d8
    5540:	97ffff39 	bl	5224 <fwp_p_ad_push>
    5544:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5548:	aa0003e1 	mov	x1, x0
    554c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5550:	aa1303e0 	mov	x0, x19
    5554:	1e6a3929 	fsub	d9, d9, d10
    5558:	aa0103f3 	mov	x19, x1
    555c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5560:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5564:	9e660135 	fmov	x21, d9
    5568:	97ffff2f 	bl	5224 <fwp_p_ad_push>
    556c:	1e680908 	fmul	d8, d8, d8
    5570:	aa0003f4 	mov	x20, x0
    5574:	aa1603e3 	mov	x3, x22
    5578:	aa1603e1 	mov	x1, x22
    557c:	aa1303e2 	mov	x2, x19
    5580:	aa1303e0 	mov	x0, x19
    5584:	97ffff28 	bl	5224 <fwp_p_ad_push>
    5588:	aa0003e2 	mov	x2, x0
    558c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5590:	9e670020 	fmov	d0, x1
    5594:	9e660101 	fmov	x1, d8
    5598:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    559c:	1e600908 	fmul	d8, d8, d0
    55a0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55a4:	97ffff20 	bl	5224 <fwp_p_ad_push>
    55a8:	1e690929 	fmul	d9, d9, d9
    55ac:	aa0003f3 	mov	x19, x0
    55b0:	aa1503e3 	mov	x3, x21
    55b4:	aa1503e1 	mov	x1, x21
    55b8:	aa1403e2 	mov	x2, x20
    55bc:	aa1403e0 	mov	x0, x20
    55c0:	97ffff19 	bl	5224 <fwp_p_ad_push>
    55c4:	1e692908 	fadd	d8, d8, d9
    55c8:	aa1303e2 	mov	x2, x19
    55cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55d0:	aa0303e1 	mov	x1, x3
    55d4:	97ffff14 	bl	5224 <fwp_p_ad_push>
    55d8:	aa0003e1 	mov	x1, x0
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	9e660100 	fmov	x0, d8
    55e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    55ec:	fd4023ea 	ldr	d10, [sp, #64]
    55f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    55f4:	d65f03c0 	ret
    55f8:	d503201f 	nop
    55fc:	d503201f 	nop

0000000000005600 <fwp_data.part.0.constprop.0>:
    5600:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5604:	910003fd 	mov	x29, sp
    5608:	a90153f3 	stp	x19, x20, [sp, #16]
    560c:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5610:	91174283 	add	x3, x20, #0x5d0
    5614:	a9025bf5 	stp	x21, x22, [sp, #32]
    5618:	aa0103f5 	mov	x21, x1
    561c:	b953a461 	ldr	w1, [x3, #5028]
    5620:	a90363f7 	stp	x23, x24, [sp, #48]
    5624:	2a0003f8 	mov	w24, w0
    5628:	34000701 	cbz	w1, 5708 <fwp_data.part.0.constprop.0+0x108>
    562c:	397e8862 	ldrb	w2, [x3, #4002]
    5630:	910f0040 	add	x0, x2, #0x3c0
    5634:	8b020442 	add	x2, x2, x2, lsl #1
    5638:	d37df042 	lsl	x2, x2, #3
    563c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5640:	2a1703f6 	mov	w22, w23
    5644:	f8626873 	ldr	x19, [x3, x2]
    5648:	b40004d3 	cbz	x19, 56e0 <fwp_data.part.0.constprop.0+0xe0>
    564c:	f9400260 	ldr	x0, [x19]
    5650:	aa2003e0 	mvn	x0, x0
    5654:	f8226860 	str	x0, [x3, x2]
    5658:	f10062df 	cmp	x22, #0x18
    565c:	540000e9 	b.ls	5678 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5660:	d10066c2 	sub	x2, x22, #0x19
    5664:	91006260 	add	x0, x19, #0x18
    5668:	927df042 	and	x2, x2, #0xfffffffffffffff8
    566c:	52800001 	mov	w1, #0x0                   	// #0
    5670:	91002042 	add	x2, x2, #0x8
    5674:	97fff477 	bl	2850 <memset@plt>
    5678:	91174282 	add	x2, x20, #0x5d0
    567c:	f94a1041 	ldr	x1, [x2, #5152]
    5680:	ab160021 	adds	x1, x1, x22
    5684:	540004c2 	b.cs	571c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5688:	f94a1440 	ldr	x0, [x2, #5160]
    568c:	f90a1041 	str	x1, [x2, #5152]
    5690:	eb00003f 	cmp	x1, x0
    5694:	54000049 	b.ls	569c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5698:	f90a1441 	str	x1, [x2, #5160]
    569c:	91174294 	add	x20, x20, #0x5d0
    56a0:	1e6302e1 	ucvtf	d1, w23
    56a4:	fd4a1e80 	ldr	d0, [x20, #5176]
    56a8:	1e612800 	fadd	d0, d0, d1
    56ac:	fd0a1e80 	str	d0, [x20, #5176]
    56b0:	52800041 	mov	w1, #0x2                   	// #2
    56b4:	29000678 	stp	w24, w1, [x19]
    56b8:	aa1303e0 	mov	x0, x19
    56bc:	f94002a1 	ldr	x1, [x21]
    56c0:	f9000661 	str	x1, [x19, #8]
    56c4:	f94006a1 	ldr	x1, [x21, #8]
    56c8:	f9000a61 	str	x1, [x19, #16]
    56cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    56d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    56d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    56dc:	d65f03c0 	ret
    56e0:	8b020063 	add	x3, x3, x2
    56e4:	f9400473 	ldr	x19, [x3, #8]
    56e8:	b4000113 	cbz	x19, 5708 <fwp_data.part.0.constprop.0+0x108>
    56ec:	f9400860 	ldr	x0, [x3, #16]
    56f0:	cb130000 	sub	x0, x0, x19
    56f4:	eb0002df 	cmp	x22, x0
    56f8:	54000088 	b.hi	5708 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    56fc:	8b160260 	add	x0, x19, x22
    5700:	f9000460 	str	x0, [x3, #8]
    5704:	17ffffd5 	b	5658 <fwp_data.part.0.constprop.0+0x58>
    5708:	52800001 	mov	w1, #0x0                   	// #0
    570c:	d2800300 	mov	x0, #0x18                  	// #24
    5710:	97fffdf8 	bl	4ef0 <fwp_heap_alloc>
    5714:	aa0003f3 	mov	x19, x0
    5718:	17ffffe6 	b	56b0 <fwp_data.part.0.constprop.0+0xb0>
    571c:	97fff645 	bl	3030 <fwp_heap_oom>

0000000000005720 <fwp_rc_share>:
    5720:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5724:	91174042 	add	x2, x2, #0x5d0
    5728:	f949d843 	ldr	x3, [x2, #5040]
    572c:	f949ec41 	ldr	x1, [x2, #5080]
    5730:	cb030000 	sub	x0, x0, x3
    5734:	eb01401f 	cmp	x0, x1, lsl #16
    5738:	540002c2 	b.cs	5790 <fwp_rc_share+0x70>  // b.hs, b.nlast
    573c:	d350fc01 	lsr	x1, x0, #16
    5740:	f949fc44 	ldr	x4, [x2, #5112]
    5744:	8b010821 	add	x1, x1, x1, lsl #2
    5748:	d37df021 	lsl	x1, x1, #3
    574c:	8b010083 	add	x3, x4, x1
    5750:	f9401062 	ldr	x2, [x3, #32]
    5754:	b40001e2 	cbz	x2, 5790 <fwp_rc_share+0x70>
    5758:	38616881 	ldrb	w1, [x4, x1]
    575c:	7100083f 	cmp	w1, #0x2
    5760:	540001a0 	b.eq	5794 <fwp_rc_share+0x74>  // b.none
    5764:	7100043f 	cmp	w1, #0x1
    5768:	54000141 	b.ne	5790 <fwp_rc_share+0x70>  // b.any
    576c:	29430464 	ldp	w4, w1, [x3, #24]
    5770:	92403c00 	and	x0, x0, #0xffff
    5774:	9b047c00 	mul	x0, x0, x4
    5778:	d360fc00 	lsr	x0, x0, #32
    577c:	eb01001f 	cmp	x0, x1
    5780:	54000082 	b.cs	5790 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5784:	8b000042 	add	x2, x2, x0
    5788:	39400040 	ldrb	w0, [x2]
    578c:	350000a0 	cbnz	w0, 57a0 <fwp_rc_share+0x80>
    5790:	d65f03c0 	ret
    5794:	72003c1f 	tst	w0, #0xffff
    5798:	54ffff80 	b.eq	5788 <fwp_rc_share+0x68>  // b.none
    579c:	d65f03c0 	ret
    57a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    57a4:	90000040 	adrp	x0, d000 <__divti3+0x2f0>
    57a8:	91224000 	add	x0, x0, #0x890
    57ac:	910003fd 	mov	x29, sp
    57b0:	97fff814 	bl	3800 <fwp_trap>

00000000000057b4 <fwp_rc_fresh>:
    57b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    57b8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    57bc:	91174063 	add	x3, x3, #0x5d0
    57c0:	910003fd 	mov	x29, sp
    57c4:	a90153f3 	stp	x19, x20, [sp, #16]
    57c8:	aa0003f3 	mov	x19, x0
    57cc:	f949d861 	ldr	x1, [x3, #5040]
    57d0:	f949ec60 	ldr	x0, [x3, #5080]
    57d4:	cb010261 	sub	x1, x19, x1
    57d8:	eb00403f 	cmp	x1, x0, lsl #16
    57dc:	54000322 	b.cs	5840 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    57e0:	d350fc22 	lsr	x2, x1, #16
    57e4:	f949fc63 	ldr	x3, [x3, #5112]
    57e8:	8b020842 	add	x2, x2, x2, lsl #2
    57ec:	d37df042 	lsl	x2, x2, #3
    57f0:	8b020060 	add	x0, x3, x2
    57f4:	f9401014 	ldr	x20, [x0, #32]
    57f8:	b4000254 	cbz	x20, 5840 <fwp_rc_fresh+0x8c>
    57fc:	38626862 	ldrb	w2, [x3, x2]
    5800:	7100085f 	cmp	w2, #0x2
    5804:	54000260 	b.eq	5850 <fwp_rc_fresh+0x9c>  // b.none
    5808:	7100045f 	cmp	w2, #0x1
    580c:	540001a1 	b.ne	5840 <fwp_rc_fresh+0x8c>  // b.any
    5810:	29430002 	ldp	w2, w0, [x0, #24]
    5814:	92403c21 	and	x1, x1, #0xffff
    5818:	9b027c21 	mul	x1, x1, x2
    581c:	d360fc21 	lsr	x1, x1, #32
    5820:	eb00003f 	cmp	x1, x0
    5824:	540000e2 	b.cs	5840 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5828:	8b010294 	add	x20, x20, x1
    582c:	39400280 	ldrb	w0, [x20]
    5830:	7103fc1f 	cmp	w0, #0xff
    5834:	540001a0 	b.eq	5868 <fwp_rc_fresh+0xb4>  // b.none
    5838:	52800020 	mov	w0, #0x1                   	// #1
    583c:	39000280 	strb	w0, [x20]
    5840:	aa1303e0 	mov	x0, x19
    5844:	a94153f3 	ldp	x19, x20, [sp, #16]
    5848:	a8c27bfd 	ldp	x29, x30, [sp], #32
    584c:	d65f03c0 	ret
    5850:	72003c3f 	tst	w1, #0xffff
    5854:	54fffec0 	b.eq	582c <fwp_rc_fresh+0x78>  // b.none
    5858:	aa1303e0 	mov	x0, x19
    585c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5860:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5864:	d65f03c0 	ret
    5868:	aa1403e0 	mov	x0, x20
    586c:	97fffbe1 	bl	47f0 <fwp_rc_forget_slot>
    5870:	17fffff2 	b	5838 <fwp_rc_fresh+0x84>

0000000000005874 <fwp_rc_free_arr>:
    5874:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5878:	91174063 	add	x3, x3, #0x5d0
    587c:	f949d861 	ldr	x1, [x3, #5040]
    5880:	f949ec62 	ldr	x2, [x3, #5080]
    5884:	cb010001 	sub	x1, x0, x1
    5888:	eb02403f 	cmp	x1, x2, lsl #16
    588c:	54000342 	b.cs	58f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5890:	d350fc22 	lsr	x2, x1, #16
    5894:	f949fc65 	ldr	x5, [x3, #5112]
    5898:	8b020842 	add	x2, x2, x2, lsl #2
    589c:	d37df042 	lsl	x2, x2, #3
    58a0:	8b0200a4 	add	x4, x5, x2
    58a4:	f9401083 	ldr	x3, [x4, #32]
    58a8:	b4000263 	cbz	x3, 58f4 <fwp_rc_free_arr+0x80>
    58ac:	386268a2 	ldrb	w2, [x5, x2]
    58b0:	7100085f 	cmp	w2, #0x2
    58b4:	540001c0 	b.eq	58ec <fwp_rc_free_arr+0x78>  // b.none
    58b8:	7100045f 	cmp	w2, #0x1
    58bc:	540001c1 	b.ne	58f4 <fwp_rc_free_arr+0x80>  // b.any
    58c0:	29430885 	ldp	w5, w2, [x4, #24]
    58c4:	92403c21 	and	x1, x1, #0xffff
    58c8:	9b057c21 	mul	x1, x1, x5
    58cc:	d360fc21 	lsr	x1, x1, #32
    58d0:	eb02003f 	cmp	x1, x2
    58d4:	54000102 	b.cs	58f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    58d8:	8b010063 	add	x3, x3, x1
    58dc:	39400061 	ldrb	w1, [x3]
    58e0:	7100043f 	cmp	w1, #0x1
    58e4:	54000081 	b.ne	58f4 <fwp_rc_free_arr+0x80>  // b.any
    58e8:	17fffc62 	b	4a70 <fwp_mem_free>
    58ec:	72003c3f 	tst	w1, #0xffff
    58f0:	54ffff60 	b.eq	58dc <fwp_rc_free_arr+0x68>  // b.none
    58f4:	d65f03c0 	ret
    58f8:	d503201f 	nop
    58fc:	d503201f 	nop

0000000000005900 <fwp_rc_dup>:
    5900:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5904:	91174042 	add	x2, x2, #0x5d0
    5908:	f949d841 	ldr	x1, [x2, #5040]
    590c:	f949ec43 	ldr	x3, [x2, #5080]
    5910:	cb010001 	sub	x1, x0, x1
    5914:	eb03403f 	cmp	x1, x3, lsl #16
    5918:	54000342 	b.cs	5980 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    591c:	d350fc20 	lsr	x0, x1, #16
    5920:	f949fc44 	ldr	x4, [x2, #5112]
    5924:	8b000800 	add	x0, x0, x0, lsl #2
    5928:	d37df002 	lsl	x2, x0, #3
    592c:	8b020083 	add	x3, x4, x2
    5930:	f9401060 	ldr	x0, [x3, #32]
    5934:	b4000260 	cbz	x0, 5980 <fwp_rc_dup+0x80>
    5938:	38626882 	ldrb	w2, [x4, x2]
    593c:	7100085f 	cmp	w2, #0x2
    5940:	54000220 	b.eq	5984 <fwp_rc_dup+0x84>  // b.none
    5944:	7100045f 	cmp	w2, #0x1
    5948:	540001c1 	b.ne	5980 <fwp_rc_dup+0x80>  // b.any
    594c:	29430864 	ldp	w4, w2, [x3, #24]
    5950:	92403c21 	and	x1, x1, #0xffff
    5954:	9b047c21 	mul	x1, x1, x4
    5958:	d360fc21 	lsr	x1, x1, #32
    595c:	eb02003f 	cmp	x1, x2
    5960:	54000102 	b.cs	5980 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5964:	8b010000 	add	x0, x0, x1
    5968:	39400001 	ldrb	w1, [x0]
    596c:	340000a1 	cbz	w1, 5980 <fwp_rc_dup+0x80>
    5970:	7103f43f 	cmp	w1, #0xfd
    5974:	540000e8 	b.hi	5990 <fwp_rc_dup+0x90>  // b.pmore
    5978:	11000421 	add	w1, w1, #0x1
    597c:	39000001 	strb	w1, [x0]
    5980:	d65f03c0 	ret
    5984:	72003c3f 	tst	w1, #0xffff
    5988:	54ffff00 	b.eq	5968 <fwp_rc_dup+0x68>  // b.none
    598c:	d65f03c0 	ret
    5990:	17fffb51 	b	46d4 <fwp_rc_wide_dup>

0000000000005994 <fwp_owned_entry161>:
    5994:	d10103ff 	sub	sp, sp, #0x40
    5998:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    599c:	f947f442 	ldr	x2, [x2, #4072]
    59a0:	a9027bfd 	stp	x29, x30, [sp, #32]
    59a4:	910083fd 	add	x29, sp, #0x20
    59a8:	a90353f3 	stp	x19, x20, [sp, #48]
    59ac:	f9400043 	ldr	x3, [x2]
    59b0:	f9000fe3 	str	x3, [sp, #24]
    59b4:	d2800003 	mov	x3, #0x0                   	// #0
    59b8:	a9400c01 	ldp	x1, x3, [x0]
    59bc:	f9400802 	ldr	x2, [x0, #16]
    59c0:	ab020022 	adds	x2, x1, x2
    59c4:	540006e6 	b.vs	5aa0 <fwp_owned_entry161+0x10c>
    59c8:	910023e1 	add	x1, sp, #0x8
    59cc:	52800000 	mov	w0, #0x0                   	// #0
    59d0:	a9008be3 	stp	x3, x2, [sp, #8]
    59d4:	97ffff0b 	bl	5600 <fwp_data.part.0.constprop.0>
    59d8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    59dc:	91174063 	add	x3, x3, #0x5d0
    59e0:	aa0003f3 	mov	x19, x0
    59e4:	f949d861 	ldr	x1, [x3, #5040]
    59e8:	f949ec60 	ldr	x0, [x3, #5080]
    59ec:	cb010261 	sub	x1, x19, x1
    59f0:	eb00403f 	cmp	x1, x0, lsl #16
    59f4:	54000322 	b.cs	5a58 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    59f8:	d350fc22 	lsr	x2, x1, #16
    59fc:	f949fc63 	ldr	x3, [x3, #5112]
    5a00:	8b020842 	add	x2, x2, x2, lsl #2
    5a04:	d37df042 	lsl	x2, x2, #3
    5a08:	8b020060 	add	x0, x3, x2
    5a0c:	f9401014 	ldr	x20, [x0, #32]
    5a10:	b4000254 	cbz	x20, 5a58 <fwp_owned_entry161+0xc4>
    5a14:	38626862 	ldrb	w2, [x3, x2]
    5a18:	7100085f 	cmp	w2, #0x2
    5a1c:	54000360 	b.eq	5a88 <fwp_owned_entry161+0xf4>  // b.none
    5a20:	7100045f 	cmp	w2, #0x1
    5a24:	540001a1 	b.ne	5a58 <fwp_owned_entry161+0xc4>  // b.any
    5a28:	29430002 	ldp	w2, w0, [x0, #24]
    5a2c:	92403c21 	and	x1, x1, #0xffff
    5a30:	9b027c21 	mul	x1, x1, x2
    5a34:	d360fc21 	lsr	x1, x1, #32
    5a38:	eb00003f 	cmp	x1, x0
    5a3c:	540000e2 	b.cs	5a58 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5a40:	8b010294 	add	x20, x20, x1
    5a44:	39400280 	ldrb	w0, [x20]
    5a48:	7103fc1f 	cmp	w0, #0xff
    5a4c:	54000240 	b.eq	5a94 <fwp_owned_entry161+0x100>  // b.none
    5a50:	52800020 	mov	w0, #0x1                   	// #1
    5a54:	39000280 	strb	w0, [x20]
    5a58:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5a5c:	f947f400 	ldr	x0, [x0, #4072]
    5a60:	f9400fe2 	ldr	x2, [sp, #24]
    5a64:	f9400001 	ldr	x1, [x0]
    5a68:	eb010042 	subs	x2, x2, x1
    5a6c:	d2800001 	mov	x1, #0x0                   	// #0
    5a70:	540001a1 	b.ne	5aa4 <fwp_owned_entry161+0x110>  // b.any
    5a74:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a78:	aa1303e0 	mov	x0, x19
    5a7c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a80:	910103ff 	add	sp, sp, #0x40
    5a84:	d65f03c0 	ret
    5a88:	72003c3f 	tst	w1, #0xffff
    5a8c:	54fffe61 	b.ne	5a58 <fwp_owned_entry161+0xc4>  // b.any
    5a90:	17ffffed 	b	5a44 <fwp_owned_entry161+0xb0>
    5a94:	aa1403e0 	mov	x0, x20
    5a98:	97fffb56 	bl	47f0 <fwp_rc_forget_slot>
    5a9c:	17ffffed 	b	5a50 <fwp_owned_entry161+0xbc>
    5aa0:	97fff3f8 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5aa4:	97fff377 	bl	2880 <__stack_chk_fail@plt>
    5aa8:	d503201f 	nop
    5aac:	d503201f 	nop

0000000000005ab0 <e161>:
    5ab0:	d10103ff 	sub	sp, sp, #0x40
    5ab4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5ab8:	f947f442 	ldr	x2, [x2, #4072]
    5abc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ac0:	910083fd 	add	x29, sp, #0x20
    5ac4:	a90353f3 	stp	x19, x20, [sp, #48]
    5ac8:	f9400043 	ldr	x3, [x2]
    5acc:	f9000fe3 	str	x3, [sp, #24]
    5ad0:	d2800003 	mov	x3, #0x0                   	// #0
    5ad4:	a9400c01 	ldp	x1, x3, [x0]
    5ad8:	f9400802 	ldr	x2, [x0, #16]
    5adc:	ab020022 	adds	x2, x1, x2
    5ae0:	54000726 	b.vs	5bc4 <e161+0x114>
    5ae4:	910023e1 	add	x1, sp, #0x8
    5ae8:	52800000 	mov	w0, #0x0                   	// #0
    5aec:	a9008be3 	stp	x3, x2, [sp, #8]
    5af0:	97fffec4 	bl	5600 <fwp_data.part.0.constprop.0>
    5af4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5af8:	91174063 	add	x3, x3, #0x5d0
    5afc:	aa0003f3 	mov	x19, x0
    5b00:	f949d861 	ldr	x1, [x3, #5040]
    5b04:	f949ec60 	ldr	x0, [x3, #5080]
    5b08:	cb010261 	sub	x1, x19, x1
    5b0c:	eb00403f 	cmp	x1, x0, lsl #16
    5b10:	54000322 	b.cs	5b74 <e161+0xc4>  // b.hs, b.nlast
    5b14:	d350fc22 	lsr	x2, x1, #16
    5b18:	f949fc63 	ldr	x3, [x3, #5112]
    5b1c:	8b020842 	add	x2, x2, x2, lsl #2
    5b20:	d37df042 	lsl	x2, x2, #3
    5b24:	8b020060 	add	x0, x3, x2
    5b28:	f9401014 	ldr	x20, [x0, #32]
    5b2c:	b4000254 	cbz	x20, 5b74 <e161+0xc4>
    5b30:	38626862 	ldrb	w2, [x3, x2]
    5b34:	7100085f 	cmp	w2, #0x2
    5b38:	540003a0 	b.eq	5bac <e161+0xfc>  // b.none
    5b3c:	7100045f 	cmp	w2, #0x1
    5b40:	540001a1 	b.ne	5b74 <e161+0xc4>  // b.any
    5b44:	29430002 	ldp	w2, w0, [x0, #24]
    5b48:	92403c21 	and	x1, x1, #0xffff
    5b4c:	9b027c21 	mul	x1, x1, x2
    5b50:	d360fc21 	lsr	x1, x1, #32
    5b54:	eb00003f 	cmp	x1, x0
    5b58:	540000e2 	b.cs	5b74 <e161+0xc4>  // b.hs, b.nlast
    5b5c:	8b010294 	add	x20, x20, x1
    5b60:	39400280 	ldrb	w0, [x20]
    5b64:	7103fc1f 	cmp	w0, #0xff
    5b68:	54000280 	b.eq	5bb8 <e161+0x108>  // b.none
    5b6c:	52800020 	mov	w0, #0x1                   	// #1
    5b70:	39000280 	strb	w0, [x20]
    5b74:	aa1303e0 	mov	x0, x19
    5b78:	97fffeea 	bl	5720 <fwp_rc_share>
    5b7c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5b80:	f947f400 	ldr	x0, [x0, #4072]
    5b84:	f9400fe2 	ldr	x2, [sp, #24]
    5b88:	f9400001 	ldr	x1, [x0]
    5b8c:	eb010042 	subs	x2, x2, x1
    5b90:	d2800001 	mov	x1, #0x0                   	// #0
    5b94:	540001a1 	b.ne	5bc8 <e161+0x118>  // b.any
    5b98:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5b9c:	aa1303e0 	mov	x0, x19
    5ba0:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ba4:	910103ff 	add	sp, sp, #0x40
    5ba8:	d65f03c0 	ret
    5bac:	72003c3f 	tst	w1, #0xffff
    5bb0:	54fffe21 	b.ne	5b74 <e161+0xc4>  // b.any
    5bb4:	17ffffeb 	b	5b60 <e161+0xb0>
    5bb8:	aa1403e0 	mov	x0, x20
    5bbc:	97fffb0d 	bl	47f0 <fwp_rc_forget_slot>
    5bc0:	17ffffeb 	b	5b6c <e161+0xbc>
    5bc4:	97fff3af 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5bc8:	97fff32e 	bl	2880 <__stack_chk_fail@plt>
    5bcc:	d503201f 	nop

0000000000005bd0 <fwp_drop0>:
    5bd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5bd4:	910003fd 	mov	x29, sp
    5bd8:	a90153f3 	stp	x19, x20, [sp, #16]
    5bdc:	f90013f5 	str	x21, [sp, #32]
    5be0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5be4:	911742b4 	add	x20, x21, #0x5d0
    5be8:	f949da81 	ldr	x1, [x20, #5040]
    5bec:	f949ee82 	ldr	x2, [x20, #5080]
    5bf0:	cb010001 	sub	x1, x0, x1
    5bf4:	eb02403f 	cmp	x1, x2, lsl #16
    5bf8:	54000382 	b.cs	5c68 <fwp_drop0+0x98>  // b.hs, b.nlast
    5bfc:	d350fc22 	lsr	x2, x1, #16
    5c00:	f949fe84 	ldr	x4, [x20, #5112]
    5c04:	8b020842 	add	x2, x2, x2, lsl #2
    5c08:	d37df042 	lsl	x2, x2, #3
    5c0c:	8b020083 	add	x3, x4, x2
    5c10:	f9401073 	ldr	x19, [x3, #32]
    5c14:	b40002b3 	cbz	x19, 5c68 <fwp_drop0+0x98>
    5c18:	38626882 	ldrb	w2, [x4, x2]
    5c1c:	7100085f 	cmp	w2, #0x2
    5c20:	540002c0 	b.eq	5c78 <fwp_drop0+0xa8>  // b.none
    5c24:	7100045f 	cmp	w2, #0x1
    5c28:	54000201 	b.ne	5c68 <fwp_drop0+0x98>  // b.any
    5c2c:	29430864 	ldp	w4, w2, [x3, #24]
    5c30:	92403c21 	and	x1, x1, #0xffff
    5c34:	9b047c21 	mul	x1, x1, x4
    5c38:	d360fc21 	lsr	x1, x1, #32
    5c3c:	eb02003f 	cmp	x1, x2
    5c40:	54000142 	b.cs	5c68 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c44:	8b010273 	add	x19, x19, x1
    5c48:	39400261 	ldrb	w1, [x19]
    5c4c:	340000e1 	cbz	w1, 5c68 <fwp_drop0+0x98>
    5c50:	7100043f 	cmp	w1, #0x1
    5c54:	540001e0 	b.eq	5c90 <fwp_drop0+0xc0>  // b.none
    5c58:	7103fc3f 	cmp	w1, #0xff
    5c5c:	540002e0 	b.eq	5cb8 <fwp_drop0+0xe8>  // b.none
    5c60:	51000421 	sub	w1, w1, #0x1
    5c64:	39000261 	strb	w1, [x19]
    5c68:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c6c:	f94013f5 	ldr	x21, [sp, #32]
    5c70:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c74:	d65f03c0 	ret
    5c78:	72003c3f 	tst	w1, #0xffff
    5c7c:	54fffe60 	b.eq	5c48 <fwp_drop0+0x78>  // b.none
    5c80:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c84:	f94013f5 	ldr	x21, [sp, #32]
    5c88:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c8c:	d65f03c0 	ret
    5c90:	f9400813 	ldr	x19, [x0, #16]
    5c94:	97fffef8 	bl	5874 <fwp_rc_free_arr>
    5c98:	911742a0 	add	x0, x21, #0x5d0
    5c9c:	f949d801 	ldr	x1, [x0, #5040]
    5ca0:	f949ec00 	ldr	x0, [x0, #5080]
    5ca4:	cb010261 	sub	x1, x19, x1
    5ca8:	eb00403f 	cmp	x1, x0, lsl #16
    5cac:	54fffde2 	b.cs	5c68 <fwp_drop0+0x98>  // b.hs, b.nlast
    5cb0:	aa1303e0 	mov	x0, x19
    5cb4:	17ffffd2 	b	5bfc <fwp_drop0+0x2c>
    5cb8:	ca534660 	eor	x0, x19, x19, lsr #17
    5cbc:	911742b5 	add	x21, x21, #0x5d0
    5cc0:	ca402400 	eor	x0, x0, x0, lsr #9
    5cc4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5cc8:	f94a2400 	ldr	x0, [x0, #5192]
    5ccc:	b5000080 	cbnz	x0, 5cdc <fwp_drop0+0x10c>
    5cd0:	14000010 	b	5d10 <fwp_drop0+0x140>
    5cd4:	f9400800 	ldr	x0, [x0, #16]
    5cd8:	b40001c0 	cbz	x0, 5d10 <fwp_drop0+0x140>
    5cdc:	f9400001 	ldr	x1, [x0]
    5ce0:	eb13003f 	cmp	x1, x19
    5ce4:	54ffff81 	b.ne	5cd4 <fwp_drop0+0x104>  // b.any
    5ce8:	f9400401 	ldr	x1, [x0, #8]
    5cec:	d1000421 	sub	x1, x1, #0x1
    5cf0:	f9000401 	str	x1, [x0, #8]
    5cf4:	f103f83f 	cmp	x1, #0xfe
    5cf8:	54fffb81 	b.ne	5c68 <fwp_drop0+0x98>  // b.any
    5cfc:	aa1303e0 	mov	x0, x19
    5d00:	97fffabc 	bl	47f0 <fwp_rc_forget_slot>
    5d04:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d08:	39000260 	strb	w0, [x19]
    5d0c:	17ffffd7 	b	5c68 <fwp_drop0+0x98>
    5d10:	90000040 	adrp	x0, d000 <__divti3+0x2f0>
    5d14:	911e4000 	add	x0, x0, #0x790
    5d18:	97fff6ba 	bl	3800 <fwp_trap>
    5d1c:	d503201f 	nop

0000000000005d20 <fwp_arg_drop12>:
    5d20:	7100003f 	cmp	w1, #0x0
    5d24:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5d28:	54000041 	b.ne	5d30 <fwp_arg_drop12+0x10>  // b.any
    5d2c:	d65f03c0 	ret
    5d30:	f9400000 	ldr	x0, [x0]
    5d34:	17ffffa7 	b	5bd0 <fwp_drop0>
    5d38:	d503201f 	nop
    5d3c:	d503201f 	nop

0000000000005d40 <fwp_drop1>:
    5d40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d44:	910003fd 	mov	x29, sp
    5d48:	a90153f3 	stp	x19, x20, [sp, #16]
    5d4c:	f90013f5 	str	x21, [sp, #32]
    5d50:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5d54:	911742b4 	add	x20, x21, #0x5d0
    5d58:	f949da81 	ldr	x1, [x20, #5040]
    5d5c:	f949ee82 	ldr	x2, [x20, #5080]
    5d60:	cb010001 	sub	x1, x0, x1
    5d64:	eb02403f 	cmp	x1, x2, lsl #16
    5d68:	54000382 	b.cs	5dd8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d6c:	d350fc22 	lsr	x2, x1, #16
    5d70:	f949fe84 	ldr	x4, [x20, #5112]
    5d74:	8b020842 	add	x2, x2, x2, lsl #2
    5d78:	d37df042 	lsl	x2, x2, #3
    5d7c:	8b020083 	add	x3, x4, x2
    5d80:	f9401073 	ldr	x19, [x3, #32]
    5d84:	b40002b3 	cbz	x19, 5dd8 <fwp_drop1+0x98>
    5d88:	38626882 	ldrb	w2, [x4, x2]
    5d8c:	7100085f 	cmp	w2, #0x2
    5d90:	540002c0 	b.eq	5de8 <fwp_drop1+0xa8>  // b.none
    5d94:	7100045f 	cmp	w2, #0x1
    5d98:	54000201 	b.ne	5dd8 <fwp_drop1+0x98>  // b.any
    5d9c:	29430864 	ldp	w4, w2, [x3, #24]
    5da0:	92403c21 	and	x1, x1, #0xffff
    5da4:	9b047c21 	mul	x1, x1, x4
    5da8:	d360fc21 	lsr	x1, x1, #32
    5dac:	eb02003f 	cmp	x1, x2
    5db0:	54000142 	b.cs	5dd8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5db4:	8b010273 	add	x19, x19, x1
    5db8:	39400261 	ldrb	w1, [x19]
    5dbc:	340000e1 	cbz	w1, 5dd8 <fwp_drop1+0x98>
    5dc0:	7100043f 	cmp	w1, #0x1
    5dc4:	540001e0 	b.eq	5e00 <fwp_drop1+0xc0>  // b.none
    5dc8:	7103fc3f 	cmp	w1, #0xff
    5dcc:	540002e0 	b.eq	5e28 <fwp_drop1+0xe8>  // b.none
    5dd0:	51000421 	sub	w1, w1, #0x1
    5dd4:	39000261 	strb	w1, [x19]
    5dd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ddc:	f94013f5 	ldr	x21, [sp, #32]
    5de0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5de4:	d65f03c0 	ret
    5de8:	72003c3f 	tst	w1, #0xffff
    5dec:	54fffe60 	b.eq	5db8 <fwp_drop1+0x78>  // b.none
    5df0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5df4:	f94013f5 	ldr	x21, [sp, #32]
    5df8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5dfc:	d65f03c0 	ret
    5e00:	f9400813 	ldr	x19, [x0, #16]
    5e04:	97fffe9c 	bl	5874 <fwp_rc_free_arr>
    5e08:	911742a0 	add	x0, x21, #0x5d0
    5e0c:	f949d801 	ldr	x1, [x0, #5040]
    5e10:	f949ec00 	ldr	x0, [x0, #5080]
    5e14:	cb010261 	sub	x1, x19, x1
    5e18:	eb00403f 	cmp	x1, x0, lsl #16
    5e1c:	54fffde2 	b.cs	5dd8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e20:	aa1303e0 	mov	x0, x19
    5e24:	17ffffd2 	b	5d6c <fwp_drop1+0x2c>
    5e28:	ca534660 	eor	x0, x19, x19, lsr #17
    5e2c:	911742b5 	add	x21, x21, #0x5d0
    5e30:	ca402400 	eor	x0, x0, x0, lsr #9
    5e34:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5e38:	f94a2400 	ldr	x0, [x0, #5192]
    5e3c:	b5000080 	cbnz	x0, 5e4c <fwp_drop1+0x10c>
    5e40:	14000010 	b	5e80 <fwp_drop1+0x140>
    5e44:	f9400800 	ldr	x0, [x0, #16]
    5e48:	b40001c0 	cbz	x0, 5e80 <fwp_drop1+0x140>
    5e4c:	f9400001 	ldr	x1, [x0]
    5e50:	eb13003f 	cmp	x1, x19
    5e54:	54ffff81 	b.ne	5e44 <fwp_drop1+0x104>  // b.any
    5e58:	f9400401 	ldr	x1, [x0, #8]
    5e5c:	d1000421 	sub	x1, x1, #0x1
    5e60:	f9000401 	str	x1, [x0, #8]
    5e64:	f103f83f 	cmp	x1, #0xfe
    5e68:	54fffb81 	b.ne	5dd8 <fwp_drop1+0x98>  // b.any
    5e6c:	aa1303e0 	mov	x0, x19
    5e70:	97fffa60 	bl	47f0 <fwp_rc_forget_slot>
    5e74:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e78:	39000260 	strb	w0, [x19]
    5e7c:	17ffffd7 	b	5dd8 <fwp_drop1+0x98>
    5e80:	90000040 	adrp	x0, d000 <__divti3+0x2f0>
    5e84:	911e4000 	add	x0, x0, #0x790
    5e88:	97fff65e 	bl	3800 <fwp_trap>
    5e8c:	d503201f 	nop

0000000000005e90 <fwp_closure_drop>:
    5e90:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5e94:	911740a4 	add	x4, x5, #0x5d0
    5e98:	aa0003e1 	mov	x1, x0
    5e9c:	f949d882 	ldr	x2, [x4, #5040]
    5ea0:	f949ec80 	ldr	x0, [x4, #5080]
    5ea4:	cb020022 	sub	x2, x1, x2
    5ea8:	eb00405f 	cmp	x2, x0, lsl #16
    5eac:	54000662 	b.cs	5f78 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5eb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5eb4:	d350fc43 	lsr	x3, x2, #16
    5eb8:	910003fd 	mov	x29, sp
    5ebc:	8b030863 	add	x3, x3, x3, lsl #2
    5ec0:	f949fc84 	ldr	x4, [x4, #5112]
    5ec4:	d37df063 	lsl	x3, x3, #3
    5ec8:	f9000bf3 	str	x19, [sp, #16]
    5ecc:	8b030080 	add	x0, x4, x3
    5ed0:	f9401013 	ldr	x19, [x0, #32]
    5ed4:	b40002b3 	cbz	x19, 5f28 <fwp_closure_drop+0x98>
    5ed8:	38636883 	ldrb	w3, [x4, x3]
    5edc:	7100087f 	cmp	w3, #0x2
    5ee0:	54000420 	b.eq	5f64 <fwp_closure_drop+0xd4>  // b.none
    5ee4:	7100047f 	cmp	w3, #0x1
    5ee8:	54000201 	b.ne	5f28 <fwp_closure_drop+0x98>  // b.any
    5eec:	29430003 	ldp	w3, w0, [x0, #24]
    5ef0:	92403c42 	and	x2, x2, #0xffff
    5ef4:	9b037c42 	mul	x2, x2, x3
    5ef8:	d360fc42 	lsr	x2, x2, #32
    5efc:	eb00005f 	cmp	x2, x0
    5f00:	54000142 	b.cs	5f28 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5f04:	8b020273 	add	x19, x19, x2
    5f08:	39400260 	ldrb	w0, [x19]
    5f0c:	340000e0 	cbz	w0, 5f28 <fwp_closure_drop+0x98>
    5f10:	7100041f 	cmp	w0, #0x1
    5f14:	54000100 	b.eq	5f34 <fwp_closure_drop+0xa4>  // b.none
    5f18:	7103fc1f 	cmp	w0, #0xff
    5f1c:	54000300 	b.eq	5f7c <fwp_closure_drop+0xec>  // b.none
    5f20:	51000400 	sub	w0, w0, #0x1
    5f24:	39000260 	strb	w0, [x19]
    5f28:	f9400bf3 	ldr	x19, [sp, #16]
    5f2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f30:	d65f03c0 	ret
    5f34:	d53bd040 	mrs	x0, tpidr_el0
    5f38:	91400000 	add	x0, x0, #0x0, lsl #12
    5f3c:	91004000 	add	x0, x0, #0x10
    5f40:	f9400000 	ldr	x0, [x0]
    5f44:	b4000080 	cbz	x0, 5f54 <fwp_closure_drop+0xc4>
    5f48:	f9400bf3 	ldr	x19, [sp, #16]
    5f4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f50:	17fff645 	b	3864 <fwp_closure_drop_push>
    5f54:	f9400bf3 	ldr	x19, [sp, #16]
    5f58:	aa0103e0 	mov	x0, x1
    5f5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f60:	17fff6b0 	b	3a20 <fwp_closure_drop.part.0>
    5f64:	72003c5f 	tst	w2, #0xffff
    5f68:	54fffd00 	b.eq	5f08 <fwp_closure_drop+0x78>  // b.none
    5f6c:	f9400bf3 	ldr	x19, [sp, #16]
    5f70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f74:	d65f03c0 	ret
    5f78:	d65f03c0 	ret
    5f7c:	ca534660 	eor	x0, x19, x19, lsr #17
    5f80:	911740a5 	add	x5, x5, #0x5d0
    5f84:	ca402400 	eor	x0, x0, x0, lsr #9
    5f88:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5f8c:	f94a2400 	ldr	x0, [x0, #5192]
    5f90:	b5000080 	cbnz	x0, 5fa0 <fwp_closure_drop+0x110>
    5f94:	14000010 	b	5fd4 <fwp_closure_drop+0x144>
    5f98:	f9400800 	ldr	x0, [x0, #16]
    5f9c:	b40001c0 	cbz	x0, 5fd4 <fwp_closure_drop+0x144>
    5fa0:	f9400001 	ldr	x1, [x0]
    5fa4:	eb13003f 	cmp	x1, x19
    5fa8:	54ffff81 	b.ne	5f98 <fwp_closure_drop+0x108>  // b.any
    5fac:	f9400401 	ldr	x1, [x0, #8]
    5fb0:	d1000421 	sub	x1, x1, #0x1
    5fb4:	f9000401 	str	x1, [x0, #8]
    5fb8:	f103f83f 	cmp	x1, #0xfe
    5fbc:	54fffb61 	b.ne	5f28 <fwp_closure_drop+0x98>  // b.any
    5fc0:	aa1303e0 	mov	x0, x19
    5fc4:	97fffa0b 	bl	47f0 <fwp_rc_forget_slot>
    5fc8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5fcc:	39000260 	strb	w0, [x19]
    5fd0:	17ffffd6 	b	5f28 <fwp_closure_drop+0x98>
    5fd4:	90000040 	adrp	x0, d000 <__divti3+0x2f0>
    5fd8:	911e4000 	add	x0, x0, #0x790
    5fdc:	97fff609 	bl	3800 <fwp_trap>

0000000000005fe0 <fwp_owned_tape_release>:
    5fe0:	b4000940 	cbz	x0, 6108 <fwp_owned_tape_release+0x128>
    5fe4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fe8:	910003fd 	mov	x29, sp
    5fec:	a90153f3 	stp	x19, x20, [sp, #16]
    5ff0:	aa0003f3 	mov	x19, x0
    5ff4:	f9400000 	ldr	x0, [x0]
    5ff8:	b4000060 	cbz	x0, 6004 <fwp_owned_tape_release+0x24>
    5ffc:	f9400661 	ldr	x1, [x19, #8]
    6000:	f9000401 	str	x1, [x0, #8]
    6004:	f9400661 	ldr	x1, [x19, #8]
    6008:	b4000041 	cbz	x1, 6010 <fwp_owned_tape_release+0x30>
    600c:	f9000020 	str	x0, [x1]
    6010:	f9400a60 	ldr	x0, [x19, #16]
    6014:	f9403401 	ldr	x1, [x0, #104]
    6018:	b40005c1 	cbz	x1, 60d0 <fwp_owned_tape_release+0xf0>
    601c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6020:	eb00005f 	cmp	x2, x0
    6024:	540002ed 	b.le	6080 <fwp_owned_tape_release+0xa0>
    6028:	d2800014 	mov	x20, #0x0                   	// #0
    602c:	f90013f5 	str	x21, [sp, #32]
    6030:	d2800015 	mov	x21, #0x0                   	// #0
    6034:	d503201f 	nop
    6038:	f9402260 	ldr	x0, [x19, #64]
    603c:	910006b5 	add	x21, x21, #0x1
    6040:	f8746800 	ldr	x0, [x0, x20]
    6044:	d63f0020 	blr	x1
    6048:	f9402260 	ldr	x0, [x19, #64]
    604c:	f9400a61 	ldr	x1, [x19, #16]
    6050:	8b140000 	add	x0, x0, x20
    6054:	91004294 	add	x20, x20, #0x10
    6058:	f9400400 	ldr	x0, [x0, #8]
    605c:	f9403421 	ldr	x1, [x1, #104]
    6060:	d63f0020 	blr	x1
    6064:	a9450261 	ldp	x1, x0, [x19, #80]
    6068:	cb010000 	sub	x0, x0, x1
    606c:	eb15001f 	cmp	x0, x21
    6070:	f9400a60 	ldr	x0, [x19, #16]
    6074:	f9403401 	ldr	x1, [x0, #104]
    6078:	54fffe0c 	b.gt	6038 <fwp_owned_tape_release+0x58>
    607c:	f94013f5 	ldr	x21, [sp, #32]
    6080:	f9403663 	ldr	x3, [x19, #104]
    6084:	f9401262 	ldr	x2, [x19, #32]
    6088:	f100007f 	cmp	x3, #0x0
    608c:	540001ed 	b.le	60c8 <fwp_owned_tape_release+0xe8>
    6090:	d2800014 	mov	x20, #0x0                   	// #0
    6094:	d503201f 	nop
    6098:	f9402660 	ldr	x0, [x19, #72]
    609c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    60a0:	eb02001f 	cmp	x0, x2
    60a4:	540000c0 	b.eq	60bc <fwp_owned_tape_release+0xdc>  // b.none
    60a8:	d63f0020 	blr	x1
    60ac:	f9400a60 	ldr	x0, [x19, #16]
    60b0:	f9401262 	ldr	x2, [x19, #32]
    60b4:	f9403663 	ldr	x3, [x19, #104]
    60b8:	f9403401 	ldr	x1, [x0, #104]
    60bc:	91000694 	add	x20, x20, #0x1
    60c0:	eb14007f 	cmp	x3, x20
    60c4:	54fffeac 	b.gt	6098 <fwp_owned_tape_release+0xb8>
    60c8:	aa0203e0 	mov	x0, x2
    60cc:	d63f0020 	blr	x1
    60d0:	f9401660 	ldr	x0, [x19, #40]
    60d4:	97ffff6f 	bl	5e90 <fwp_closure_drop>
    60d8:	f9401a60 	ldr	x0, [x19, #48]
    60dc:	97ffff6d 	bl	5e90 <fwp_closure_drop>
    60e0:	f9401e60 	ldr	x0, [x19, #56]
    60e4:	97ffff6b 	bl	5e90 <fwp_closure_drop>
    60e8:	f9402260 	ldr	x0, [x19, #64]
    60ec:	97fffa61 	bl	4a70 <fwp_mem_free>
    60f0:	f9402660 	ldr	x0, [x19, #72]
    60f4:	97fffa5f 	bl	4a70 <fwp_mem_free>
    60f8:	aa1303e0 	mov	x0, x19
    60fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6100:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6104:	17fffa5b 	b	4a70 <fwp_mem_free>
    6108:	d65f03c0 	ret
    610c:	d503201f 	nop

0000000000006110 <fwp_tape_finish>:
    6110:	d10203ff 	sub	sp, sp, #0x80
    6114:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6118:	f947f421 	ldr	x1, [x1, #4072]
    611c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6120:	910103fd 	add	x29, sp, #0x40
    6124:	a90553f3 	stp	x19, x20, [sp, #80]
    6128:	a9065bf5 	stp	x21, x22, [sp, #96]
    612c:	a90763f7 	stp	x23, x24, [sp, #112]
    6130:	d00000d8 	adrp	x24, 20000 <__data_start>
    6134:	9101c316 	add	x22, x24, #0x70
    6138:	f9400022 	ldr	x2, [x1]
    613c:	f9001fe2 	str	x2, [sp, #56]
    6140:	d2800002 	mov	x2, #0x0                   	// #0
    6144:	910262c0 	add	x0, x22, #0x98
    6148:	97fff4ce 	bl	3480 <fwp_tape_buffers_dispose>
    614c:	f9006adf 	str	xzr, [x22, #208]
    6150:	f9404ac0 	ldr	x0, [x22, #144]
    6154:	f100001f 	cmp	x0, #0x0
    6158:	5400030d 	b.le	61b8 <fwp_tape_finish+0xa8>
    615c:	910003f7 	mov	x23, sp
    6160:	d2800015 	mov	x21, #0x0                   	// #0
    6164:	d2800014 	mov	x20, #0x0                   	// #0
    6168:	f94002d3 	ldr	x19, [x22]
    616c:	91000694 	add	x20, x20, #0x1
    6170:	8b150273 	add	x19, x19, x21
    6174:	9101a2b5 	add	x21, x21, #0x68
    6178:	aa1303e0 	mov	x0, x19
    617c:	97fff385 	bl	2f90 <fwp_tape_unlink_scope>
    6180:	aa1703e0 	mov	x0, x23
    6184:	f9401261 	ldr	x1, [x19, #32]
    6188:	f90003e1 	str	x1, [sp]
    618c:	f9401a62 	ldr	x2, [x19, #48]
    6190:	f9000be2 	str	x2, [sp, #16]
    6194:	f9402261 	ldr	x1, [x19, #64]
    6198:	f90013e1 	str	x1, [sp, #32]
    619c:	97fff4b9 	bl	3480 <fwp_tape_buffers_dispose>
    61a0:	f9403260 	ldr	x0, [x19, #96]
    61a4:	97ffff8f 	bl	5fe0 <fwp_owned_tape_release>
    61a8:	f900327f 	str	xzr, [x19, #96]
    61ac:	f9404ac0 	ldr	x0, [x22, #144]
    61b0:	eb14001f 	cmp	x0, x20
    61b4:	54fffdac 	b.gt	6168 <fwp_tape_finish+0x58>
    61b8:	f9403b00 	ldr	x0, [x24, #112]
    61bc:	9101c313 	add	x19, x24, #0x70
    61c0:	97fff1e0 	bl	2940 <free@plt>
    61c4:	f9003b1f 	str	xzr, [x24, #112]
    61c8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    61cc:	f947f400 	ldr	x0, [x0, #4072]
    61d0:	f9004a7f 	str	xzr, [x19, #144]
    61d4:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    61d8:	f9401fe2 	ldr	x2, [sp, #56]
    61dc:	f9400001 	ldr	x1, [x0]
    61e0:	eb010042 	subs	x2, x2, x1
    61e4:	d2800001 	mov	x1, #0x0                   	// #0
    61e8:	540000e1 	b.ne	6204 <fwp_tape_finish+0xf4>  // b.any
    61ec:	a9447bfd 	ldp	x29, x30, [sp, #64]
    61f0:	a94553f3 	ldp	x19, x20, [sp, #80]
    61f4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    61f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    61fc:	910203ff 	add	sp, sp, #0x80
    6200:	d65f03c0 	ret
    6204:	97fff19f 	bl	2880 <__stack_chk_fail@plt>
    6208:	d503201f 	nop
    620c:	d503201f 	nop

0000000000006210 <fwp_tape_scope_release>:
    6210:	d10243ff 	sub	sp, sp, #0x90
    6214:	a9047bfd 	stp	x29, x30, [sp, #64]
    6218:	910103fd 	add	x29, sp, #0x40
    621c:	a90553f3 	stp	x19, x20, [sp, #80]
    6220:	aa0003f4 	mov	x20, x0
    6224:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6228:	f947f400 	ldr	x0, [x0, #4072]
    622c:	b9400285 	ldr	w5, [x20]
    6230:	f9400001 	ldr	x1, [x0]
    6234:	f9001fe1 	str	x1, [sp, #56]
    6238:	d2800001 	mov	x1, #0x0                   	// #0
    623c:	37f806c5 	tbnz	w5, #31, 6314 <fwp_tape_scope_release+0x104>
    6240:	a90763f7 	stp	x23, x24, [sp, #112]
    6244:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6248:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    624c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6250:	d00000d3 	adrp	x19, 20000 <__data_start>
    6254:	910003f7 	mov	x23, sp
    6258:	9101c273 	add	x19, x19, #0x70
    625c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6260:	a9065bf5 	stp	x21, x22, [sp, #96]
    6264:	52800d16 	mov	w22, #0x68                  	// #104
    6268:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    626c:	f90043f9 	str	x25, [sp, #128]
    6270:	14000006 	b	6288 <fwp_tape_scope_release+0x78>
    6274:	97fff483 	bl	3480 <fwp_tape_buffers_dispose>
    6278:	aa1903e0 	mov	x0, x25
    627c:	97ffff59 	bl	5fe0 <fwp_owned_tape_release>
    6280:	b9400285 	ldr	w5, [x20]
    6284:	37f80425 	tbnz	w5, #31, 6308 <fwp_tape_scope_release+0xf8>
    6288:	f9400266 	ldr	x6, [x19]
    628c:	9b367ca5 	smull	x5, w5, w22
    6290:	8b0500c0 	add	x0, x6, x5
    6294:	97fff33f 	bl	2f90 <fwp_tape_unlink_scope>
    6298:	ad410001 	ldp	q1, q0, [x0, #32]
    629c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    62a0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    62a4:	f9400c03 	ldr	x3, [x0, #24]
    62a8:	ad0003e1 	stp	q1, q0, [sp]
    62ac:	b86568c1 	ldr	w1, [x6, x5]
    62b0:	a9440804 	ldp	x4, x2, [x0, #64]
    62b4:	b900041f 	str	wzr, [x0, #4]
    62b8:	f9403019 	ldr	x25, [x0, #96]
    62bc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    62c0:	f9000c1f 	str	xzr, [x0, #24]
    62c4:	a9020fe4 	stp	x4, x3, [sp, #32]
    62c8:	f9001be2 	str	x2, [sp, #48]
    62cc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    62d0:	f900301f 	str	xzr, [x0, #96]
    62d4:	6b15003f 	cmp	w1, w21
    62d8:	540000e8 	b.hi	62f4 <fwp_tape_scope_release+0xe4>  // b.pmore
    62dc:	9343fca5 	asr	x5, x5, #3
    62e0:	f9407660 	ldr	x0, [x19, #232]
    62e4:	9b187ca5 	mul	x5, x5, x24
    62e8:	eb0000bf 	cmp	x5, x0
    62ec:	5400004a 	b.ge	62f4 <fwp_tape_scope_release+0xe4>  // b.tcont
    62f0:	f9007665 	str	x5, [x19, #232]
    62f4:	aa1703e0 	mov	x0, x23
    62f8:	b5fffbf9 	cbnz	x25, 6274 <fwp_tape_scope_release+0x64>
    62fc:	97fff821 	bl	4380 <fwp_tape_buffers_release>
    6300:	b9400285 	ldr	w5, [x20]
    6304:	36fffc25 	tbz	w5, #31, 6288 <fwp_tape_scope_release+0x78>
    6308:	a9465bf5 	ldp	x21, x22, [sp, #96]
    630c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6310:	f94043f9 	ldr	x25, [sp, #128]
    6314:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6318:	f947f400 	ldr	x0, [x0, #4072]
    631c:	f9401fe2 	ldr	x2, [sp, #56]
    6320:	f9400001 	ldr	x1, [x0]
    6324:	eb010042 	subs	x2, x2, x1
    6328:	d2800001 	mov	x1, #0x0                   	// #0
    632c:	540000a1 	b.ne	6340 <fwp_tape_scope_release+0x130>  // b.any
    6330:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6334:	a94553f3 	ldp	x19, x20, [sp, #80]
    6338:	910243ff 	add	sp, sp, #0x90
    633c:	d65f03c0 	ret
    6340:	a9065bf5 	stp	x21, x22, [sp, #96]
    6344:	a90763f7 	stp	x23, x24, [sp, #112]
    6348:	f90043f9 	str	x25, [sp, #128]
    634c:	97fff14d 	bl	2880 <__stack_chk_fail@plt>

0000000000006350 <fwp_task_dispose>:
    6350:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6354:	910003fd 	mov	x29, sp
    6358:	f9000bf3 	str	x19, [sp, #16]
    635c:	aa0003f3 	mov	x19, x0
    6360:	39414000 	ldrb	w0, [x0, #80]
    6364:	36000720 	tbz	w0, #0, 6448 <fwp_task_dispose+0xf8>
    6368:	f9400a60 	ldr	x0, [x19, #16]
    636c:	b50006e0 	cbnz	x0, 6448 <fwp_task_dispose+0xf8>
    6370:	a9478660 	ldp	x0, x1, [x19, #120]
    6374:	39014e7f 	strb	wzr, [x19, #83]
    6378:	f9003e7f 	str	xzr, [x19, #120]
    637c:	f100003f 	cmp	x1, #0x0
    6380:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6384:	54000040 	b.eq	638c <fwp_task_dispose+0x3c>  // b.none
    6388:	d63f0020 	blr	x1
    638c:	f9405660 	ldr	x0, [x19, #168]
    6390:	97fff9b8 	bl	4a70 <fwp_mem_free>
    6394:	f900567f 	str	xzr, [x19, #168]
    6398:	b9405e60 	ldr	w0, [x19, #92]
    639c:	7100041f 	cmp	w0, #0x1
    63a0:	54000420 	b.eq	6424 <fwp_task_dispose+0xd4>  // b.none
    63a4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    63a8:	91174042 	add	x2, x2, #0x5d0
    63ac:	f949d840 	ldr	x0, [x2, #5040]
    63b0:	f949ec41 	ldr	x1, [x2, #5080]
    63b4:	cb000260 	sub	x0, x19, x0
    63b8:	eb01401f 	cmp	x0, x1, lsl #16
    63bc:	540002e2 	b.cs	6418 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    63c0:	d350fc01 	lsr	x1, x0, #16
    63c4:	f949fc44 	ldr	x4, [x2, #5112]
    63c8:	8b010821 	add	x1, x1, x1, lsl #2
    63cc:	d37df021 	lsl	x1, x1, #3
    63d0:	8b010083 	add	x3, x4, x1
    63d4:	f9401062 	ldr	x2, [x3, #32]
    63d8:	b4000202 	cbz	x2, 6418 <fwp_task_dispose+0xc8>
    63dc:	38616881 	ldrb	w1, [x4, x1]
    63e0:	7100083f 	cmp	w1, #0x2
    63e4:	54000280 	b.eq	6434 <fwp_task_dispose+0xe4>  // b.none
    63e8:	7100043f 	cmp	w1, #0x1
    63ec:	54000161 	b.ne	6418 <fwp_task_dispose+0xc8>  // b.any
    63f0:	29430464 	ldp	w4, w1, [x3, #24]
    63f4:	92403c00 	and	x0, x0, #0xffff
    63f8:	9b047c00 	mul	x0, x0, x4
    63fc:	d360fc00 	lsr	x0, x0, #32
    6400:	eb01001f 	cmp	x0, x1
    6404:	540000a2 	b.cs	6418 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6408:	8b000042 	add	x2, x2, x0
    640c:	39400040 	ldrb	w0, [x2]
    6410:	7100041f 	cmp	w0, #0x1
    6414:	54000080 	b.eq	6424 <fwp_task_dispose+0xd4>  // b.none
    6418:	f9400bf3 	ldr	x19, [sp, #16]
    641c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6420:	d65f03c0 	ret
    6424:	aa1303e0 	mov	x0, x19
    6428:	f9400bf3 	ldr	x19, [sp, #16]
    642c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6430:	17fff990 	b	4a70 <fwp_mem_free>
    6434:	72003c1f 	tst	w0, #0xffff
    6438:	54fffea0 	b.eq	640c <fwp_task_dispose+0xbc>  // b.none
    643c:	f9400bf3 	ldr	x19, [sp, #16]
    6440:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6444:	d65f03c0 	ret
    6448:	97fff122 	bl	28d0 <abort@plt>
    644c:	d503201f 	nop

0000000000006450 <fwp_free_zombie>:
    6450:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6454:	910003fd 	mov	x29, sp
    6458:	a90153f3 	stp	x19, x20, [sp, #16]
    645c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6460:	9101c281 	add	x1, x20, #0x70
    6464:	f9407833 	ldr	x19, [x1, #240]
    6468:	b4000333 	cbz	x19, 64cc <fwp_free_zombie+0x7c>
    646c:	f9400820 	ldr	x0, [x1, #16]
    6470:	eb00027f 	cmp	x19, x0
    6474:	540002c0 	b.eq	64cc <fwp_free_zombie+0x7c>  // b.none
    6478:	b940f822 	ldr	w2, [x1, #248]
    647c:	f9400a60 	ldr	x0, [x19, #16]
    6480:	7100fc5f 	cmp	w2, #0x3f
    6484:	5400078c 	b.gt	6574 <fwp_free_zombie+0x124>
    6488:	91040023 	add	x3, x1, #0x100
    648c:	11000444 	add	w4, w2, #0x1
    6490:	b900f824 	str	w4, [x1, #248]
    6494:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6498:	f822d860 	str	x0, [x3, w2, sxtw #3]
    649c:	a9530261 	ldp	x1, x0, [x19, #304]
    64a0:	b4000741 	cbz	x1, 6588 <fwp_free_zombie+0x138>
    64a4:	f9009c20 	str	x0, [x1, #312]
    64a8:	b4000040 	cbz	x0, 64b0 <fwp_free_zombie+0x60>
    64ac:	f9009801 	str	x1, [x0, #304]
    64b0:	9101c294 	add	x20, x20, #0x70
    64b4:	b9405e60 	ldr	w0, [x19, #92]
    64b8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    64bc:	f9007a9f 	str	xzr, [x20, #240]
    64c0:	34000140 	cbz	w0, 64e8 <fwp_free_zombie+0x98>
    64c4:	7100041f 	cmp	w0, #0x1
    64c8:	54000080 	b.eq	64d8 <fwp_free_zombie+0x88>  // b.none
    64cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    64d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64d4:	d65f03c0 	ret
    64d8:	aa1303e0 	mov	x0, x19
    64dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    64e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64e4:	17ffff9b 	b	6350 <fwp_task_dispose>
    64e8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    64ec:	91174082 	add	x2, x4, #0x5d0
    64f0:	f949d841 	ldr	x1, [x2, #5040]
    64f4:	f949ec40 	ldr	x0, [x2, #5080]
    64f8:	cb010261 	sub	x1, x19, x1
    64fc:	eb00403f 	cmp	x1, x0, lsl #16
    6500:	54fffe62 	b.cs	64cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6504:	d350fc20 	lsr	x0, x1, #16
    6508:	f949fc43 	ldr	x3, [x2, #5112]
    650c:	8b000800 	add	x0, x0, x0, lsl #2
    6510:	d37df000 	lsl	x0, x0, #3
    6514:	8b000062 	add	x2, x3, x0
    6518:	f9401054 	ldr	x20, [x2, #32]
    651c:	b4fffd94 	cbz	x20, 64cc <fwp_free_zombie+0x7c>
    6520:	38606860 	ldrb	w0, [x3, x0]
    6524:	7100081f 	cmp	w0, #0x2
    6528:	54000360 	b.eq	6594 <fwp_free_zombie+0x144>  // b.none
    652c:	7100041f 	cmp	w0, #0x1
    6530:	54fffce1 	b.ne	64cc <fwp_free_zombie+0x7c>  // b.any
    6534:	29430043 	ldp	w3, w0, [x2, #24]
    6538:	92403c21 	and	x1, x1, #0xffff
    653c:	9b037c21 	mul	x1, x1, x3
    6540:	d360fc21 	lsr	x1, x1, #32
    6544:	eb00003f 	cmp	x1, x0
    6548:	54fffc22 	b.cs	64cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    654c:	8b010294 	add	x20, x20, x1
    6550:	39400280 	ldrb	w0, [x20]
    6554:	34fffbc0 	cbz	w0, 64cc <fwp_free_zombie+0x7c>
    6558:	7100041f 	cmp	w0, #0x1
    655c:	54fffbe0 	b.eq	64d8 <fwp_free_zombie+0x88>  // b.none
    6560:	7103fc1f 	cmp	w0, #0xff
    6564:	540001e0 	b.eq	65a0 <fwp_free_zombie+0x150>  // b.none
    6568:	51000400 	sub	w0, w0, #0x1
    656c:	39000280 	strb	w0, [x20]
    6570:	17ffffd7 	b	64cc <fwp_free_zombie+0x7c>
    6574:	f9400e61 	ldr	x1, [x19, #24]
    6578:	97fff10a 	bl	29a0 <munmap@plt>
    657c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6580:	a9530261 	ldp	x1, x0, [x19, #304]
    6584:	b5fff901 	cbnz	x1, 64a4 <fwp_free_zombie+0x54>
    6588:	9101c282 	add	x2, x20, #0x70
    658c:	f9018040 	str	x0, [x2, #768]
    6590:	17ffffc6 	b	64a8 <fwp_free_zombie+0x58>
    6594:	72003c3f 	tst	w1, #0xffff
    6598:	54fff9a1 	b.ne	64cc <fwp_free_zombie+0x7c>  // b.any
    659c:	17ffffed 	b	6550 <fwp_free_zombie+0x100>
    65a0:	ca544680 	eor	x0, x20, x20, lsr #17
    65a4:	91174084 	add	x4, x4, #0x5d0
    65a8:	ca402400 	eor	x0, x0, x0, lsr #9
    65ac:	8b200c80 	add	x0, x4, w0, uxtb #3
    65b0:	f94a2400 	ldr	x0, [x0, #5192]
    65b4:	b5000080 	cbnz	x0, 65c4 <fwp_free_zombie+0x174>
    65b8:	14000010 	b	65f8 <fwp_free_zombie+0x1a8>
    65bc:	f9400800 	ldr	x0, [x0, #16]
    65c0:	b40001c0 	cbz	x0, 65f8 <fwp_free_zombie+0x1a8>
    65c4:	f9400001 	ldr	x1, [x0]
    65c8:	eb14003f 	cmp	x1, x20
    65cc:	54ffff81 	b.ne	65bc <fwp_free_zombie+0x16c>  // b.any
    65d0:	f9400401 	ldr	x1, [x0, #8]
    65d4:	d1000421 	sub	x1, x1, #0x1
    65d8:	f9000401 	str	x1, [x0, #8]
    65dc:	f103f83f 	cmp	x1, #0xfe
    65e0:	54fff761 	b.ne	64cc <fwp_free_zombie+0x7c>  // b.any
    65e4:	aa1403e0 	mov	x0, x20
    65e8:	97fff882 	bl	47f0 <fwp_rc_forget_slot>
    65ec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65f0:	39000280 	strb	w0, [x20]
    65f4:	17ffffb6 	b	64cc <fwp_free_zombie+0x7c>
    65f8:	f0000020 	adrp	x0, d000 <__divti3+0x2f0>
    65fc:	911e4000 	add	x0, x0, #0x790
    6600:	97fff480 	bl	3800 <fwp_trap>

0000000000006604 <fwp_block>:
    6604:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6608:	910003fd 	mov	x29, sp
    660c:	a90153f3 	stp	x19, x20, [sp, #16]
    6610:	d00000d3 	adrp	x19, 20000 <__data_start>
    6614:	9101c274 	add	x20, x19, #0x70
    6618:	f9404282 	ldr	x2, [x20, #128]
    661c:	b4000622 	cbz	x2, 66e0 <fwp_block+0xdc>
    6620:	9101c261 	add	x1, x19, #0x70
    6624:	f9408040 	ldr	x0, [x2, #256]
    6628:	f9004020 	str	x0, [x1, #128]
    662c:	b4000680 	cbz	x0, 66fc <fwp_block+0xf8>
    6630:	9101c263 	add	x3, x19, #0x70
    6634:	3901505f 	strb	wzr, [x2, #84]
    6638:	f9400864 	ldr	x4, [x3, #16]
    663c:	eb02009f 	cmp	x4, x2
    6640:	54000440 	b.eq	66c8 <fwp_block+0xc4>  // b.none
    6644:	f9418465 	ldr	x5, [x3, #776]
    6648:	f9000862 	str	x2, [x3, #16]
    664c:	f9400441 	ldr	x1, [x2, #8]
    6650:	f9004885 	str	x5, [x4, #144]
    6654:	f9418865 	ldr	x5, [x3, #784]
    6658:	f9004c85 	str	x5, [x4, #152]
    665c:	f9418c65 	ldr	x5, [x3, #792]
    6660:	f9005085 	str	x5, [x4, #160]
    6664:	f9419065 	ldr	x5, [x3, #800]
    6668:	f9005485 	str	x5, [x4, #168]
    666c:	f9419465 	ldr	x5, [x3, #808]
    6670:	f9005885 	str	x5, [x4, #176]
    6674:	f9419865 	ldr	x5, [x3, #816]
    6678:	f9005c85 	str	x5, [x4, #184]
    667c:	f9419c65 	ldr	x5, [x3, #824]
    6680:	f9006085 	str	x5, [x4, #192]
    6684:	f9400480 	ldr	x0, [x4, #8]
    6688:	f9404844 	ldr	x4, [x2, #144]
    668c:	f9018464 	str	x4, [x3, #776]
    6690:	f9404c44 	ldr	x4, [x2, #152]
    6694:	f9018864 	str	x4, [x3, #784]
    6698:	f9405044 	ldr	x4, [x2, #160]
    669c:	f9018c64 	str	x4, [x3, #792]
    66a0:	f9405444 	ldr	x4, [x2, #168]
    66a4:	f9019064 	str	x4, [x3, #800]
    66a8:	f9405844 	ldr	x4, [x2, #176]
    66ac:	f9019464 	str	x4, [x3, #808]
    66b0:	a94b8844 	ldp	x4, x2, [x2, #184]
    66b4:	f9019864 	str	x4, [x3, #816]
    66b8:	f9019c62 	str	x2, [x3, #824]
    66bc:	97fff089 	bl	28e0 <swapcontext@plt>
    66c0:	97ffff64 	bl	6450 <fwp_free_zombie>
    66c4:	d503201f 	nop
    66c8:	9101c260 	add	x0, x19, #0x70
    66cc:	b9434000 	ldr	w0, [x0, #832]
    66d0:	340001a0 	cbz	w0, 6704 <fwp_block+0x100>
    66d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66dc:	d65f03c0 	ret
    66e0:	97fff770 	bl	44a0 <fwp_poll_events>
    66e4:	f9404282 	ldr	x2, [x20, #128]
    66e8:	b4ffffc2 	cbz	x2, 66e0 <fwp_block+0xdc>
    66ec:	9101c261 	add	x1, x19, #0x70
    66f0:	f9408040 	ldr	x0, [x2, #256]
    66f4:	f9004020 	str	x0, [x1, #128]
    66f8:	b5fff9c0 	cbnz	x0, 6630 <fwp_block+0x2c>
    66fc:	f9003c3f 	str	xzr, [x1, #120]
    6700:	17ffffcc 	b	6630 <fwp_block+0x2c>
    6704:	f0000020 	adrp	x0, d000 <__divti3+0x2f0>
    6708:	91230000 	add	x0, x0, #0x8c0
    670c:	97fff0c1 	bl	2a10 <getenv@plt>
    6710:	5284e202 	mov	w2, #0x2710                	// #10000
    6714:	b4000060 	cbz	x0, 6720 <fwp_block+0x11c>
    6718:	39400001 	ldrb	w1, [x0]
    671c:	350000c1 	cbnz	w1, 6734 <fwp_block+0x130>
    6720:	9101c273 	add	x19, x19, #0x70
    6724:	b9034262 	str	w2, [x19, #832]
    6728:	a94153f3 	ldp	x19, x20, [sp, #16]
    672c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6730:	d65f03c0 	ret
    6734:	52800142 	mov	w2, #0xa                   	// #10
    6738:	d2800001 	mov	x1, #0x0                   	// #0
    673c:	97fff005 	bl	2750 <strtoll@plt>
    6740:	d1000403 	sub	x3, x0, #0x1
    6744:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6748:	eb02007f 	cmp	x3, x2
    674c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6750:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6754:	17fffff3 	b	6720 <fwp_block+0x11c>
    6758:	d503201f 	nop
    675c:	d503201f 	nop

0000000000006760 <fwp_drop4>:
    6760:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6764:	910003fd 	mov	x29, sp
    6768:	a90153f3 	stp	x19, x20, [sp, #16]
    676c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6770:	f90013f5 	str	x21, [sp, #32]
    6774:	91174275 	add	x21, x19, #0x5d0
    6778:	f949daa1 	ldr	x1, [x21, #5040]
    677c:	f949eea2 	ldr	x2, [x21, #5080]
    6780:	cb010001 	sub	x1, x0, x1
    6784:	eb02403f 	cmp	x1, x2, lsl #16
    6788:	54000382 	b.cs	67f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    678c:	d350fc22 	lsr	x2, x1, #16
    6790:	f949fea3 	ldr	x3, [x21, #5112]
    6794:	8b020842 	add	x2, x2, x2, lsl #2
    6798:	d37df042 	lsl	x2, x2, #3
    679c:	8b020064 	add	x4, x3, x2
    67a0:	f9401094 	ldr	x20, [x4, #32]
    67a4:	b40002b4 	cbz	x20, 67f8 <fwp_drop4+0x98>
    67a8:	38626862 	ldrb	w2, [x3, x2]
    67ac:	7100085f 	cmp	w2, #0x2
    67b0:	540007a0 	b.eq	68a4 <fwp_drop4+0x144>  // b.none
    67b4:	7100045f 	cmp	w2, #0x1
    67b8:	54000201 	b.ne	67f8 <fwp_drop4+0x98>  // b.any
    67bc:	29430885 	ldp	w5, w2, [x4, #24]
    67c0:	92403c21 	and	x1, x1, #0xffff
    67c4:	9b057c21 	mul	x1, x1, x5
    67c8:	d360fc21 	lsr	x1, x1, #32
    67cc:	eb02003f 	cmp	x1, x2
    67d0:	54000142 	b.cs	67f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    67d4:	8b010294 	add	x20, x20, x1
    67d8:	39400281 	ldrb	w1, [x20]
    67dc:	340000e1 	cbz	w1, 67f8 <fwp_drop4+0x98>
    67e0:	7100043f 	cmp	w1, #0x1
    67e4:	54000120 	b.eq	6808 <fwp_drop4+0xa8>  // b.none
    67e8:	7103fc3f 	cmp	w1, #0xff
    67ec:	540007c0 	b.eq	68e4 <fwp_drop4+0x184>  // b.none
    67f0:	51000421 	sub	w1, w1, #0x1
    67f4:	39000281 	strb	w1, [x20]
    67f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    67fc:	f94013f5 	ldr	x21, [sp, #32]
    6800:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6804:	d65f03c0 	ret
    6808:	f9400001 	ldr	x1, [x0]
    680c:	b7f80581 	tbnz	x1, #63, 68bc <fwp_drop4+0x15c>
    6810:	91174273 	add	x19, x19, #0x5d0
    6814:	f949da61 	ldr	x1, [x19, #5040]
    6818:	f949ee62 	ldr	x2, [x19, #5080]
    681c:	cb010001 	sub	x1, x0, x1
    6820:	eb02403f 	cmp	x1, x2, lsl #16
    6824:	54fffea2 	b.cs	67f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6828:	d350fc22 	lsr	x2, x1, #16
    682c:	8b020842 	add	x2, x2, x2, lsl #2
    6830:	d37df042 	lsl	x2, x2, #3
    6834:	8b020065 	add	x5, x3, x2
    6838:	f94010a4 	ldr	x4, [x5, #32]
    683c:	b4fffde4 	cbz	x4, 67f8 <fwp_drop4+0x98>
    6840:	38626862 	ldrb	w2, [x3, x2]
    6844:	7100085f 	cmp	w2, #0x2
    6848:	54000220 	b.eq	688c <fwp_drop4+0x12c>  // b.none
    684c:	7100045f 	cmp	w2, #0x1
    6850:	54fffd41 	b.ne	67f8 <fwp_drop4+0x98>  // b.any
    6854:	294308a3 	ldp	w3, w2, [x5, #24]
    6858:	92403c21 	and	x1, x1, #0xffff
    685c:	9b037c21 	mul	x1, x1, x3
    6860:	d360fc21 	lsr	x1, x1, #32
    6864:	eb02003f 	cmp	x1, x2
    6868:	54fffc82 	b.cs	67f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    686c:	8b010084 	add	x4, x4, x1
    6870:	39400081 	ldrb	w1, [x4]
    6874:	7100043f 	cmp	w1, #0x1
    6878:	54fffc01 	b.ne	67f8 <fwp_drop4+0x98>  // b.any
    687c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6880:	f94013f5 	ldr	x21, [sp, #32]
    6884:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6888:	17fff87a 	b	4a70 <fwp_mem_free>
    688c:	72003c3f 	tst	w1, #0xffff
    6890:	54ffff00 	b.eq	6870 <fwp_drop4+0x110>  // b.none
    6894:	a94153f3 	ldp	x19, x20, [sp, #16]
    6898:	f94013f5 	ldr	x21, [sp, #32]
    689c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    68a0:	d65f03c0 	ret
    68a4:	72003c3f 	tst	w1, #0xffff
    68a8:	54fff980 	b.eq	67d8 <fwp_drop4+0x78>  // b.none
    68ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    68b0:	f94013f5 	ldr	x21, [sp, #32]
    68b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    68b8:	d65f03c0 	ret
    68bc:	f9400414 	ldr	x20, [x0, #8]
    68c0:	97fffbed 	bl	5874 <fwp_rc_free_arr>
    68c4:	91174260 	add	x0, x19, #0x5d0
    68c8:	f949d801 	ldr	x1, [x0, #5040]
    68cc:	f949ec00 	ldr	x0, [x0, #5080]
    68d0:	cb010281 	sub	x1, x20, x1
    68d4:	eb00403f 	cmp	x1, x0, lsl #16
    68d8:	54fff902 	b.cs	67f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    68dc:	aa1403e0 	mov	x0, x20
    68e0:	17ffffab 	b	678c <fwp_drop4+0x2c>
    68e4:	ca544680 	eor	x0, x20, x20, lsr #17
    68e8:	91174273 	add	x19, x19, #0x5d0
    68ec:	ca402400 	eor	x0, x0, x0, lsr #9
    68f0:	8b200e60 	add	x0, x19, w0, uxtb #3
    68f4:	f94a2400 	ldr	x0, [x0, #5192]
    68f8:	b5000080 	cbnz	x0, 6908 <fwp_drop4+0x1a8>
    68fc:	14000010 	b	693c <fwp_drop4+0x1dc>
    6900:	f9400800 	ldr	x0, [x0, #16]
    6904:	b40001c0 	cbz	x0, 693c <fwp_drop4+0x1dc>
    6908:	f9400001 	ldr	x1, [x0]
    690c:	eb14003f 	cmp	x1, x20
    6910:	54ffff81 	b.ne	6900 <fwp_drop4+0x1a0>  // b.any
    6914:	f9400401 	ldr	x1, [x0, #8]
    6918:	d1000421 	sub	x1, x1, #0x1
    691c:	f9000401 	str	x1, [x0, #8]
    6920:	f103f83f 	cmp	x1, #0xfe
    6924:	54fff6a1 	b.ne	67f8 <fwp_drop4+0x98>  // b.any
    6928:	aa1403e0 	mov	x0, x20
    692c:	97fff7b1 	bl	47f0 <fwp_rc_forget_slot>
    6930:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6934:	39000280 	strb	w0, [x20]
    6938:	17ffffb0 	b	67f8 <fwp_drop4+0x98>
    693c:	f0000020 	adrp	x0, d000 <__divti3+0x2f0>
    6940:	911e4000 	add	x0, x0, #0x790
    6944:	97fff3af 	bl	3800 <fwp_trap>
    6948:	d503201f 	nop
    694c:	d503201f 	nop

0000000000006950 <fwp_caps161>:
    6950:	34000041 	cbz	w1, 6958 <fwp_caps161+0x8>
    6954:	d65f03c0 	ret
    6958:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    695c:	91174063 	add	x3, x3, #0x5d0
    6960:	f949d861 	ldr	x1, [x3, #5040]
    6964:	f949ec62 	ldr	x2, [x3, #5080]
    6968:	cb010001 	sub	x1, x0, x1
    696c:	eb02403f 	cmp	x1, x2, lsl #16
    6970:	54ffff22 	b.cs	6954 <fwp_caps161+0x4>  // b.hs, b.nlast
    6974:	d350fc22 	lsr	x2, x1, #16
    6978:	f949fc65 	ldr	x5, [x3, #5112]
    697c:	8b020842 	add	x2, x2, x2, lsl #2
    6980:	d37df042 	lsl	x2, x2, #3
    6984:	8b0200a4 	add	x4, x5, x2
    6988:	f9401083 	ldr	x3, [x4, #32]
    698c:	b4fffe43 	cbz	x3, 6954 <fwp_caps161+0x4>
    6990:	386268a2 	ldrb	w2, [x5, x2]
    6994:	7100085f 	cmp	w2, #0x2
    6998:	540001c0 	b.eq	69d0 <fwp_caps161+0x80>  // b.none
    699c:	7100045f 	cmp	w2, #0x1
    69a0:	54fffda1 	b.ne	6954 <fwp_caps161+0x4>  // b.any
    69a4:	29430885 	ldp	w5, w2, [x4, #24]
    69a8:	92403c21 	and	x1, x1, #0xffff
    69ac:	9b057c21 	mul	x1, x1, x5
    69b0:	d360fc21 	lsr	x1, x1, #32
    69b4:	eb02003f 	cmp	x1, x2
    69b8:	54fffce2 	b.cs	6954 <fwp_caps161+0x4>  // b.hs, b.nlast
    69bc:	8b010063 	add	x3, x3, x1
    69c0:	39400061 	ldrb	w1, [x3]
    69c4:	7100043f 	cmp	w1, #0x1
    69c8:	54fffc61 	b.ne	6954 <fwp_caps161+0x4>  // b.any
    69cc:	17fff829 	b	4a70 <fwp_mem_free>
    69d0:	72003c3f 	tst	w1, #0xffff
    69d4:	54ffff60 	b.eq	69c0 <fwp_caps161+0x70>  // b.none
    69d8:	d65f03c0 	ret
    69dc:	d503201f 	nop

00000000000069e0 <fwp_args23>:
    69e0:	7100003f 	cmp	w1, #0x0
    69e4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    69e8:	54000041 	b.ne	69f0 <fwp_args23+0x10>  // b.any
    69ec:	d65f03c0 	ret
    69f0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    69f4:	91174042 	add	x2, x2, #0x5d0
    69f8:	f9400001 	ldr	x1, [x0]
    69fc:	f949d843 	ldr	x3, [x2, #5040]
    6a00:	f949ec40 	ldr	x0, [x2, #5080]
    6a04:	cb030021 	sub	x1, x1, x3
    6a08:	eb00403f 	cmp	x1, x0, lsl #16
    6a0c:	54ffff02 	b.cs	69ec <fwp_args23+0xc>  // b.hs, b.nlast
    6a10:	d350fc20 	lsr	x0, x1, #16
    6a14:	f949fc44 	ldr	x4, [x2, #5112]
    6a18:	8b000800 	add	x0, x0, x0, lsl #2
    6a1c:	d37df002 	lsl	x2, x0, #3
    6a20:	8b020083 	add	x3, x4, x2
    6a24:	f9401060 	ldr	x0, [x3, #32]
    6a28:	b4fffe20 	cbz	x0, 69ec <fwp_args23+0xc>
    6a2c:	38626882 	ldrb	w2, [x4, x2]
    6a30:	7100085f 	cmp	w2, #0x2
    6a34:	54000220 	b.eq	6a78 <fwp_args23+0x98>  // b.none
    6a38:	7100045f 	cmp	w2, #0x1
    6a3c:	54fffd81 	b.ne	69ec <fwp_args23+0xc>  // b.any
    6a40:	29430864 	ldp	w4, w2, [x3, #24]
    6a44:	92403c21 	and	x1, x1, #0xffff
    6a48:	9b047c21 	mul	x1, x1, x4
    6a4c:	d360fc21 	lsr	x1, x1, #32
    6a50:	eb02003f 	cmp	x1, x2
    6a54:	54fffcc2 	b.cs	69ec <fwp_args23+0xc>  // b.hs, b.nlast
    6a58:	8b010000 	add	x0, x0, x1
    6a5c:	39400001 	ldrb	w1, [x0]
    6a60:	34fffc61 	cbz	w1, 69ec <fwp_args23+0xc>
    6a64:	7103f43f 	cmp	w1, #0xfd
    6a68:	540000e8 	b.hi	6a84 <fwp_args23+0xa4>  // b.pmore
    6a6c:	11000421 	add	w1, w1, #0x1
    6a70:	39000001 	strb	w1, [x0]
    6a74:	d65f03c0 	ret
    6a78:	72003c3f 	tst	w1, #0xffff
    6a7c:	54ffff00 	b.eq	6a5c <fwp_args23+0x7c>  // b.none
    6a80:	d65f03c0 	ret
    6a84:	17fff714 	b	46d4 <fwp_rc_wide_dup>
    6a88:	d503201f 	nop
    6a8c:	d503201f 	nop

0000000000006a90 <fwp_args12>:
    6a90:	7100003f 	cmp	w1, #0x0
    6a94:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6a98:	54000041 	b.ne	6aa0 <fwp_args12+0x10>  // b.any
    6a9c:	d65f03c0 	ret
    6aa0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6aa4:	91174042 	add	x2, x2, #0x5d0
    6aa8:	f9400001 	ldr	x1, [x0]
    6aac:	f949d843 	ldr	x3, [x2, #5040]
    6ab0:	f949ec40 	ldr	x0, [x2, #5080]
    6ab4:	cb030021 	sub	x1, x1, x3
    6ab8:	eb00403f 	cmp	x1, x0, lsl #16
    6abc:	54ffff02 	b.cs	6a9c <fwp_args12+0xc>  // b.hs, b.nlast
    6ac0:	d350fc20 	lsr	x0, x1, #16
    6ac4:	f949fc44 	ldr	x4, [x2, #5112]
    6ac8:	8b000800 	add	x0, x0, x0, lsl #2
    6acc:	d37df002 	lsl	x2, x0, #3
    6ad0:	8b020083 	add	x3, x4, x2
    6ad4:	f9401060 	ldr	x0, [x3, #32]
    6ad8:	b4fffe20 	cbz	x0, 6a9c <fwp_args12+0xc>
    6adc:	38626882 	ldrb	w2, [x4, x2]
    6ae0:	7100085f 	cmp	w2, #0x2
    6ae4:	54000220 	b.eq	6b28 <fwp_args12+0x98>  // b.none
    6ae8:	7100045f 	cmp	w2, #0x1
    6aec:	54fffd81 	b.ne	6a9c <fwp_args12+0xc>  // b.any
    6af0:	29430864 	ldp	w4, w2, [x3, #24]
    6af4:	92403c21 	and	x1, x1, #0xffff
    6af8:	9b047c21 	mul	x1, x1, x4
    6afc:	d360fc21 	lsr	x1, x1, #32
    6b00:	eb02003f 	cmp	x1, x2
    6b04:	54fffcc2 	b.cs	6a9c <fwp_args12+0xc>  // b.hs, b.nlast
    6b08:	8b010000 	add	x0, x0, x1
    6b0c:	39400001 	ldrb	w1, [x0]
    6b10:	34fffc61 	cbz	w1, 6a9c <fwp_args12+0xc>
    6b14:	7103f43f 	cmp	w1, #0xfd
    6b18:	540000e8 	b.hi	6b34 <fwp_args12+0xa4>  // b.pmore
    6b1c:	11000421 	add	w1, w1, #0x1
    6b20:	39000001 	strb	w1, [x0]
    6b24:	d65f03c0 	ret
    6b28:	72003c3f 	tst	w1, #0xffff
    6b2c:	54ffff00 	b.eq	6b0c <fwp_args12+0x7c>  // b.none
    6b30:	d65f03c0 	ret
    6b34:	17fff6e8 	b	46d4 <fwp_rc_wide_dup>
    6b38:	d503201f 	nop
    6b3c:	d503201f 	nop

0000000000006b40 <fwp_caps12>:
    6b40:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b44:	910003fd 	mov	x29, sp
    6b48:	f9000bf3 	str	x19, [sp, #16]
    6b4c:	aa0003f3 	mov	x19, x0
    6b50:	b9400400 	ldr	w0, [x0, #4]
    6b54:	340004a0 	cbz	w0, 6be8 <fwp_caps12+0xa8>
    6b58:	f9400660 	ldr	x0, [x19, #8]
    6b5c:	350004e1 	cbnz	w1, 6bf8 <fwp_caps12+0xb8>
    6b60:	97fffc1c 	bl	5bd0 <fwp_drop0>
    6b64:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6b68:	91174042 	add	x2, x2, #0x5d0
    6b6c:	f949d840 	ldr	x0, [x2, #5040]
    6b70:	f949ec41 	ldr	x1, [x2, #5080]
    6b74:	cb000260 	sub	x0, x19, x0
    6b78:	eb01401f 	cmp	x0, x1, lsl #16
    6b7c:	54000382 	b.cs	6bec <fwp_caps12+0xac>  // b.hs, b.nlast
    6b80:	d350fc01 	lsr	x1, x0, #16
    6b84:	f949fc44 	ldr	x4, [x2, #5112]
    6b88:	8b010821 	add	x1, x1, x1, lsl #2
    6b8c:	d37df021 	lsl	x1, x1, #3
    6b90:	8b010083 	add	x3, x4, x1
    6b94:	f9401062 	ldr	x2, [x3, #32]
    6b98:	b40002a2 	cbz	x2, 6bec <fwp_caps12+0xac>
    6b9c:	38616881 	ldrb	w1, [x4, x1]
    6ba0:	7100083f 	cmp	w1, #0x2
    6ba4:	540006c0 	b.eq	6c7c <fwp_caps12+0x13c>  // b.none
    6ba8:	7100043f 	cmp	w1, #0x1
    6bac:	54000201 	b.ne	6bec <fwp_caps12+0xac>  // b.any
    6bb0:	29430464 	ldp	w4, w1, [x3, #24]
    6bb4:	92403c00 	and	x0, x0, #0xffff
    6bb8:	9b047c00 	mul	x0, x0, x4
    6bbc:	d360fc00 	lsr	x0, x0, #32
    6bc0:	eb01001f 	cmp	x0, x1
    6bc4:	54000142 	b.cs	6bec <fwp_caps12+0xac>  // b.hs, b.nlast
    6bc8:	8b000042 	add	x2, x2, x0
    6bcc:	39400040 	ldrb	w0, [x2]
    6bd0:	7100041f 	cmp	w0, #0x1
    6bd4:	540000c1 	b.ne	6bec <fwp_caps12+0xac>  // b.any
    6bd8:	aa1303e0 	mov	x0, x19
    6bdc:	f9400bf3 	ldr	x19, [sp, #16]
    6be0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6be4:	17fff7a3 	b	4a70 <fwp_mem_free>
    6be8:	34fffbe1 	cbz	w1, 6b64 <fwp_caps12+0x24>
    6bec:	f9400bf3 	ldr	x19, [sp, #16]
    6bf0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bf4:	d65f03c0 	ret
    6bf8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6bfc:	91174042 	add	x2, x2, #0x5d0
    6c00:	f949d843 	ldr	x3, [x2, #5040]
    6c04:	f949ec41 	ldr	x1, [x2, #5080]
    6c08:	cb030000 	sub	x0, x0, x3
    6c0c:	eb01401f 	cmp	x0, x1, lsl #16
    6c10:	54fffee2 	b.cs	6bec <fwp_caps12+0xac>  // b.hs, b.nlast
    6c14:	d350fc01 	lsr	x1, x0, #16
    6c18:	f949fc44 	ldr	x4, [x2, #5112]
    6c1c:	8b010821 	add	x1, x1, x1, lsl #2
    6c20:	d37df021 	lsl	x1, x1, #3
    6c24:	8b010083 	add	x3, x4, x1
    6c28:	f9401062 	ldr	x2, [x3, #32]
    6c2c:	b4fffe02 	cbz	x2, 6bec <fwp_caps12+0xac>
    6c30:	38616881 	ldrb	w1, [x4, x1]
    6c34:	7100083f 	cmp	w1, #0x2
    6c38:	54000280 	b.eq	6c88 <fwp_caps12+0x148>  // b.none
    6c3c:	7100043f 	cmp	w1, #0x1
    6c40:	54fffd61 	b.ne	6bec <fwp_caps12+0xac>  // b.any
    6c44:	92403c01 	and	x1, x0, #0xffff
    6c48:	29430064 	ldp	w4, w0, [x3, #24]
    6c4c:	9b047c21 	mul	x1, x1, x4
    6c50:	d360fc21 	lsr	x1, x1, #32
    6c54:	eb00003f 	cmp	x1, x0
    6c58:	54fffca2 	b.cs	6bec <fwp_caps12+0xac>  // b.hs, b.nlast
    6c5c:	8b010042 	add	x2, x2, x1
    6c60:	39400040 	ldrb	w0, [x2]
    6c64:	34fffc40 	cbz	w0, 6bec <fwp_caps12+0xac>
    6c68:	7103f41f 	cmp	w0, #0xfd
    6c6c:	54000148 	b.hi	6c94 <fwp_caps12+0x154>  // b.pmore
    6c70:	11000400 	add	w0, w0, #0x1
    6c74:	39000040 	strb	w0, [x2]
    6c78:	17ffffdd 	b	6bec <fwp_caps12+0xac>
    6c7c:	72003c1f 	tst	w0, #0xffff
    6c80:	54fffb61 	b.ne	6bec <fwp_caps12+0xac>  // b.any
    6c84:	17ffffd2 	b	6bcc <fwp_caps12+0x8c>
    6c88:	72003c1f 	tst	w0, #0xffff
    6c8c:	54fffb01 	b.ne	6bec <fwp_caps12+0xac>  // b.any
    6c90:	17fffff4 	b	6c60 <fwp_caps12+0x120>
    6c94:	f9400bf3 	ldr	x19, [sp, #16]
    6c98:	aa0203e0 	mov	x0, x2
    6c9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ca0:	17fff68d 	b	46d4 <fwp_rc_wide_dup>

0000000000006ca4 <fwp_drop2>:
    6ca4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6ca8:	910003fd 	mov	x29, sp
    6cac:	a9025bf5 	stp	x21, x22, [sp, #32]
    6cb0:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    6cb4:	911742d5 	add	x21, x22, #0x5d0
    6cb8:	a90153f3 	stp	x19, x20, [sp, #16]
    6cbc:	aa0003f3 	mov	x19, x0
    6cc0:	f949daa1 	ldr	x1, [x21, #5040]
    6cc4:	f949eea0 	ldr	x0, [x21, #5080]
    6cc8:	cb010261 	sub	x1, x19, x1
    6ccc:	eb00403f 	cmp	x1, x0, lsl #16
    6cd0:	54000382 	b.cs	6d40 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6cd4:	d350fc22 	lsr	x2, x1, #16
    6cd8:	f949fea3 	ldr	x3, [x21, #5112]
    6cdc:	8b020842 	add	x2, x2, x2, lsl #2
    6ce0:	d37df042 	lsl	x2, x2, #3
    6ce4:	8b020060 	add	x0, x3, x2
    6ce8:	f9401014 	ldr	x20, [x0, #32]
    6cec:	b40002b4 	cbz	x20, 6d40 <fwp_drop2+0x9c>
    6cf0:	38626862 	ldrb	w2, [x3, x2]
    6cf4:	7100085f 	cmp	w2, #0x2
    6cf8:	540002c0 	b.eq	6d50 <fwp_drop2+0xac>  // b.none
    6cfc:	7100045f 	cmp	w2, #0x1
    6d00:	54000201 	b.ne	6d40 <fwp_drop2+0x9c>  // b.any
    6d04:	29430002 	ldp	w2, w0, [x0, #24]
    6d08:	92403c21 	and	x1, x1, #0xffff
    6d0c:	9b027c21 	mul	x1, x1, x2
    6d10:	d360fc21 	lsr	x1, x1, #32
    6d14:	eb00003f 	cmp	x1, x0
    6d18:	54000142 	b.cs	6d40 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6d1c:	8b010294 	add	x20, x20, x1
    6d20:	39400280 	ldrb	w0, [x20]
    6d24:	340000e0 	cbz	w0, 6d40 <fwp_drop2+0x9c>
    6d28:	7100041f 	cmp	w0, #0x1
    6d2c:	540001e0 	b.eq	6d68 <fwp_drop2+0xc4>  // b.none
    6d30:	7103fc1f 	cmp	w0, #0xff
    6d34:	540007e0 	b.eq	6e30 <fwp_drop2+0x18c>  // b.none
    6d38:	51000400 	sub	w0, w0, #0x1
    6d3c:	39000280 	strb	w0, [x20]
    6d40:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d44:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6d48:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d4c:	d65f03c0 	ret
    6d50:	72003c3f 	tst	w1, #0xffff
    6d54:	54fffe60 	b.eq	6d20 <fwp_drop2+0x7c>  // b.none
    6d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6d60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d64:	d65f03c0 	ret
    6d68:	911742c2 	add	x2, x22, #0x5d0
    6d6c:	f9400660 	ldr	x0, [x19, #8]
    6d70:	f949d841 	ldr	x1, [x2, #5040]
    6d74:	f949ec42 	ldr	x2, [x2, #5080]
    6d78:	cb010001 	sub	x1, x0, x1
    6d7c:	eb02403f 	cmp	x1, x2, lsl #16
    6d80:	54000382 	b.cs	6df0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6d84:	d350fc22 	lsr	x2, x1, #16
    6d88:	8b020842 	add	x2, x2, x2, lsl #2
    6d8c:	d37df042 	lsl	x2, x2, #3
    6d90:	8b020064 	add	x4, x3, x2
    6d94:	f9401094 	ldr	x20, [x4, #32]
    6d98:	b40002d4 	cbz	x20, 6df0 <fwp_drop2+0x14c>
    6d9c:	38626862 	ldrb	w2, [x3, x2]
    6da0:	7100085f 	cmp	w2, #0x2
    6da4:	54000400 	b.eq	6e24 <fwp_drop2+0x180>  // b.none
    6da8:	7100045f 	cmp	w2, #0x1
    6dac:	54000221 	b.ne	6df0 <fwp_drop2+0x14c>  // b.any
    6db0:	29430883 	ldp	w3, w2, [x4, #24]
    6db4:	92403c21 	and	x1, x1, #0xffff
    6db8:	9b037c21 	mul	x1, x1, x3
    6dbc:	d360fc21 	lsr	x1, x1, #32
    6dc0:	eb02003f 	cmp	x1, x2
    6dc4:	54000162 	b.cs	6df0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6dc8:	8b010294 	add	x20, x20, x1
    6dcc:	39400281 	ldrb	w1, [x20]
    6dd0:	34000101 	cbz	w1, 6df0 <fwp_drop2+0x14c>
    6dd4:	7100043f 	cmp	w1, #0x1
    6dd8:	54000220 	b.eq	6e1c <fwp_drop2+0x178>  // b.none
    6ddc:	7103fc3f 	cmp	w1, #0xff
    6de0:	540005a0 	b.eq	6e94 <fwp_drop2+0x1f0>  // b.none
    6de4:	51000421 	sub	w1, w1, #0x1
    6de8:	39000281 	strb	w1, [x20]
    6dec:	d503201f 	nop
    6df0:	f9400a74 	ldr	x20, [x19, #16]
    6df4:	aa1303e0 	mov	x0, x19
    6df8:	97fffa9f 	bl	5874 <fwp_rc_free_arr>
    6dfc:	911742c0 	add	x0, x22, #0x5d0
    6e00:	f949d801 	ldr	x1, [x0, #5040]
    6e04:	f949ec00 	ldr	x0, [x0, #5080]
    6e08:	cb010281 	sub	x1, x20, x1
    6e0c:	eb00403f 	cmp	x1, x0, lsl #16
    6e10:	54fff982 	b.cs	6d40 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6e14:	aa1403f3 	mov	x19, x20
    6e18:	17ffffaf 	b	6cd4 <fwp_drop2+0x30>
    6e1c:	97fffa96 	bl	5874 <fwp_rc_free_arr>
    6e20:	17fffff4 	b	6df0 <fwp_drop2+0x14c>
    6e24:	72003c3f 	tst	w1, #0xffff
    6e28:	54fffe41 	b.ne	6df0 <fwp_drop2+0x14c>  // b.any
    6e2c:	17ffffe8 	b	6dcc <fwp_drop2+0x128>
    6e30:	ca544681 	eor	x1, x20, x20, lsr #17
    6e34:	911742c0 	add	x0, x22, #0x5d0
    6e38:	ca412421 	eor	x1, x1, x1, lsr #9
    6e3c:	8b210c01 	add	x1, x0, w1, uxtb #3
    6e40:	f94a2420 	ldr	x0, [x1, #5192]
    6e44:	b5000080 	cbnz	x0, 6e54 <fwp_drop2+0x1b0>
    6e48:	14000010 	b	6e88 <fwp_drop2+0x1e4>
    6e4c:	f9400800 	ldr	x0, [x0, #16]
    6e50:	b40001c0 	cbz	x0, 6e88 <fwp_drop2+0x1e4>
    6e54:	f9400001 	ldr	x1, [x0]
    6e58:	eb14003f 	cmp	x1, x20
    6e5c:	54ffff81 	b.ne	6e4c <fwp_drop2+0x1a8>  // b.any
    6e60:	f9400401 	ldr	x1, [x0, #8]
    6e64:	d1000421 	sub	x1, x1, #0x1
    6e68:	f9000401 	str	x1, [x0, #8]
    6e6c:	f103f83f 	cmp	x1, #0xfe
    6e70:	54fff681 	b.ne	6d40 <fwp_drop2+0x9c>  // b.any
    6e74:	aa1403e0 	mov	x0, x20
    6e78:	97fff65e 	bl	47f0 <fwp_rc_forget_slot>
    6e7c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6e80:	39000280 	strb	w0, [x20]
    6e84:	17ffffaf 	b	6d40 <fwp_drop2+0x9c>
    6e88:	f0000020 	adrp	x0, d000 <__divti3+0x2f0>
    6e8c:	911e4000 	add	x0, x0, #0x790
    6e90:	97fff25c 	bl	3800 <fwp_trap>
    6e94:	ca544680 	eor	x0, x20, x20, lsr #17
    6e98:	911742c1 	add	x1, x22, #0x5d0
    6e9c:	ca402400 	eor	x0, x0, x0, lsr #9
    6ea0:	8b200c20 	add	x0, x1, w0, uxtb #3
    6ea4:	f94a2400 	ldr	x0, [x0, #5192]
    6ea8:	b5000080 	cbnz	x0, 6eb8 <fwp_drop2+0x214>
    6eac:	17fffff7 	b	6e88 <fwp_drop2+0x1e4>
    6eb0:	f9400800 	ldr	x0, [x0, #16]
    6eb4:	b4fffea0 	cbz	x0, 6e88 <fwp_drop2+0x1e4>
    6eb8:	f9400001 	ldr	x1, [x0]
    6ebc:	eb14003f 	cmp	x1, x20
    6ec0:	54ffff81 	b.ne	6eb0 <fwp_drop2+0x20c>  // b.any
    6ec4:	f9400401 	ldr	x1, [x0, #8]
    6ec8:	d1000421 	sub	x1, x1, #0x1
    6ecc:	f9000401 	str	x1, [x0, #8]
    6ed0:	f103f83f 	cmp	x1, #0xfe
    6ed4:	54fff8e1 	b.ne	6df0 <fwp_drop2+0x14c>  // b.any
    6ed8:	aa1403e0 	mov	x0, x20
    6edc:	97fff645 	bl	47f0 <fwp_rc_forget_slot>
    6ee0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6ee4:	39000280 	strb	w0, [x20]
    6ee8:	17ffffc2 	b	6df0 <fwp_drop2+0x14c>
    6eec:	d503201f 	nop

0000000000006ef0 <fwp_arg_drop23>:
    6ef0:	7100003f 	cmp	w1, #0x0
    6ef4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6ef8:	54000041 	b.ne	6f00 <fwp_arg_drop23+0x10>  // b.any
    6efc:	d65f03c0 	ret
    6f00:	f9400000 	ldr	x0, [x0]
    6f04:	17ffff68 	b	6ca4 <fwp_drop2>
    6f08:	d503201f 	nop
    6f0c:	d503201f 	nop

0000000000006f10 <fwp_caps23>:
    6f10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6f14:	910003fd 	mov	x29, sp
    6f18:	f9000bf3 	str	x19, [sp, #16]
    6f1c:	aa0003f3 	mov	x19, x0
    6f20:	b9400400 	ldr	w0, [x0, #4]
    6f24:	340004a0 	cbz	w0, 6fb8 <fwp_caps23+0xa8>
    6f28:	f9400660 	ldr	x0, [x19, #8]
    6f2c:	350004e1 	cbnz	w1, 6fc8 <fwp_caps23+0xb8>
    6f30:	97ffff5d 	bl	6ca4 <fwp_drop2>
    6f34:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6f38:	91174042 	add	x2, x2, #0x5d0
    6f3c:	f949d840 	ldr	x0, [x2, #5040]
    6f40:	f949ec41 	ldr	x1, [x2, #5080]
    6f44:	cb000260 	sub	x0, x19, x0
    6f48:	eb01401f 	cmp	x0, x1, lsl #16
    6f4c:	54000382 	b.cs	6fbc <fwp_caps23+0xac>  // b.hs, b.nlast
    6f50:	d350fc01 	lsr	x1, x0, #16
    6f54:	f949fc44 	ldr	x4, [x2, #5112]
    6f58:	8b010821 	add	x1, x1, x1, lsl #2
    6f5c:	d37df021 	lsl	x1, x1, #3
    6f60:	8b010083 	add	x3, x4, x1
    6f64:	f9401062 	ldr	x2, [x3, #32]
    6f68:	b40002a2 	cbz	x2, 6fbc <fwp_caps23+0xac>
    6f6c:	38616881 	ldrb	w1, [x4, x1]
    6f70:	7100083f 	cmp	w1, #0x2
    6f74:	540006c0 	b.eq	704c <fwp_caps23+0x13c>  // b.none
    6f78:	7100043f 	cmp	w1, #0x1
    6f7c:	54000201 	b.ne	6fbc <fwp_caps23+0xac>  // b.any
    6f80:	29430464 	ldp	w4, w1, [x3, #24]
    6f84:	92403c00 	and	x0, x0, #0xffff
    6f88:	9b047c00 	mul	x0, x0, x4
    6f8c:	d360fc00 	lsr	x0, x0, #32
    6f90:	eb01001f 	cmp	x0, x1
    6f94:	54000142 	b.cs	6fbc <fwp_caps23+0xac>  // b.hs, b.nlast
    6f98:	8b000042 	add	x2, x2, x0
    6f9c:	39400040 	ldrb	w0, [x2]
    6fa0:	7100041f 	cmp	w0, #0x1
    6fa4:	540000c1 	b.ne	6fbc <fwp_caps23+0xac>  // b.any
    6fa8:	aa1303e0 	mov	x0, x19
    6fac:	f9400bf3 	ldr	x19, [sp, #16]
    6fb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6fb4:	17fff6af 	b	4a70 <fwp_mem_free>
    6fb8:	34fffbe1 	cbz	w1, 6f34 <fwp_caps23+0x24>
    6fbc:	f9400bf3 	ldr	x19, [sp, #16]
    6fc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6fc4:	d65f03c0 	ret
    6fc8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6fcc:	91174042 	add	x2, x2, #0x5d0
    6fd0:	f949d843 	ldr	x3, [x2, #5040]
    6fd4:	f949ec41 	ldr	x1, [x2, #5080]
    6fd8:	cb030000 	sub	x0, x0, x3
    6fdc:	eb01401f 	cmp	x0, x1, lsl #16
    6fe0:	54fffee2 	b.cs	6fbc <fwp_caps23+0xac>  // b.hs, b.nlast
    6fe4:	d350fc01 	lsr	x1, x0, #16
    6fe8:	f949fc44 	ldr	x4, [x2, #5112]
    6fec:	8b010821 	add	x1, x1, x1, lsl #2
    6ff0:	d37df021 	lsl	x1, x1, #3
    6ff4:	8b010083 	add	x3, x4, x1
    6ff8:	f9401062 	ldr	x2, [x3, #32]
    6ffc:	b4fffe02 	cbz	x2, 6fbc <fwp_caps23+0xac>
    7000:	38616881 	ldrb	w1, [x4, x1]
    7004:	7100083f 	cmp	w1, #0x2
    7008:	54000280 	b.eq	7058 <fwp_caps23+0x148>  // b.none
    700c:	7100043f 	cmp	w1, #0x1
    7010:	54fffd61 	b.ne	6fbc <fwp_caps23+0xac>  // b.any
    7014:	92403c01 	and	x1, x0, #0xffff
    7018:	29430064 	ldp	w4, w0, [x3, #24]
    701c:	9b047c21 	mul	x1, x1, x4
    7020:	d360fc21 	lsr	x1, x1, #32
    7024:	eb00003f 	cmp	x1, x0
    7028:	54fffca2 	b.cs	6fbc <fwp_caps23+0xac>  // b.hs, b.nlast
    702c:	8b010042 	add	x2, x2, x1
    7030:	39400040 	ldrb	w0, [x2]
    7034:	34fffc40 	cbz	w0, 6fbc <fwp_caps23+0xac>
    7038:	7103f41f 	cmp	w0, #0xfd
    703c:	54000148 	b.hi	7064 <fwp_caps23+0x154>  // b.pmore
    7040:	11000400 	add	w0, w0, #0x1
    7044:	39000040 	strb	w0, [x2]
    7048:	17ffffdd 	b	6fbc <fwp_caps23+0xac>
    704c:	72003c1f 	tst	w0, #0xffff
    7050:	54fffb61 	b.ne	6fbc <fwp_caps23+0xac>  // b.any
    7054:	17ffffd2 	b	6f9c <fwp_caps23+0x8c>
    7058:	72003c1f 	tst	w0, #0xffff
    705c:	54fffb01 	b.ne	6fbc <fwp_caps23+0xac>  // b.any
    7060:	17fffff4 	b	7030 <fwp_caps23+0x120>
    7064:	f9400bf3 	ldr	x19, [sp, #16]
    7068:	aa0203e0 	mov	x0, x2
    706c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7070:	17fff599 	b	46d4 <fwp_rc_wide_dup>

0000000000007074 <f23>:
    7074:	d10203ff 	sub	sp, sp, #0x80
    7078:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    707c:	f947f421 	ldr	x1, [x1, #4072]
    7080:	a9027bfd 	stp	x29, x30, [sp, #32]
    7084:	910083fd 	add	x29, sp, #0x20
    7088:	a9045bf5 	stp	x21, x22, [sp, #64]
    708c:	d0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    7090:	911742c3 	add	x3, x22, #0x5d0
    7094:	a90353f3 	stp	x19, x20, [sp, #48]
    7098:	a90563f7 	stp	x23, x24, [sp, #80]
    709c:	aa0003f8 	mov	x24, x0
    70a0:	a9066bf9 	stp	x25, x26, [sp, #96]
    70a4:	f949ec62 	ldr	x2, [x3, #5080]
    70a8:	f9400024 	ldr	x4, [x1]
    70ac:	f9000fe4 	str	x4, [sp, #24]
    70b0:	d2800004 	mov	x4, #0x0                   	// #0
    70b4:	f949d861 	ldr	x1, [x3, #5040]
    70b8:	d370bc42 	lsl	x2, x2, #16
    70bc:	b40017c0 	cbz	x0, 73b4 <f23+0x340>
    70c0:	f9400819 	ldr	x25, [x0, #16]
    70c4:	cb010321 	sub	x1, x25, x1
    70c8:	eb02003f 	cmp	x1, x2
    70cc:	54000362 	b.cs	7138 <f23+0xc4>  // b.hs, b.nlast
    70d0:	f949fc60 	ldr	x0, [x3, #5112]
    70d4:	d350fc22 	lsr	x2, x1, #16
    70d8:	8b020842 	add	x2, x2, x2, lsl #2
    70dc:	8b020c02 	add	x2, x0, x2, lsl #3
    70e0:	f9401040 	ldr	x0, [x2, #32]
    70e4:	b40002a0 	cbz	x0, 7138 <f23+0xc4>
    70e8:	39400043 	ldrb	w3, [x2]
    70ec:	7100087f 	cmp	w3, #0x2
    70f0:	540015c0 	b.eq	73a8 <f23+0x334>  // b.none
    70f4:	7100047f 	cmp	w3, #0x1
    70f8:	540001c1 	b.ne	7130 <f23+0xbc>  // b.any
    70fc:	29430843 	ldp	w3, w2, [x2, #24]
    7100:	92403c21 	and	x1, x1, #0xffff
    7104:	9b037c21 	mul	x1, x1, x3
    7108:	d360fc21 	lsr	x1, x1, #32
    710c:	eb02003f 	cmp	x1, x2
    7110:	54000102 	b.cs	7130 <f23+0xbc>  // b.hs, b.nlast
    7114:	8b010000 	add	x0, x0, x1
    7118:	39400001 	ldrb	w1, [x0]
    711c:	340000a1 	cbz	w1, 7130 <f23+0xbc>
    7120:	7103f43f 	cmp	w1, #0xfd
    7124:	54001868 	b.hi	7430 <f23+0x3bc>  // b.pmore
    7128:	11000421 	add	w1, w1, #0x1
    712c:	39000001 	strb	w1, [x0]
    7130:	d2800000 	mov	x0, #0x0                   	// #0
    7134:	b40000d8 	cbz	x24, 714c <f23+0xd8>
    7138:	aa1803e1 	mov	x1, x24
    713c:	d2800000 	mov	x0, #0x0                   	// #0
    7140:	f9400821 	ldr	x1, [x1, #16]
    7144:	91000400 	add	x0, x0, #0x1
    7148:	b5ffffc1 	cbnz	x1, 7140 <f23+0xcc>
    714c:	b40013b9 	cbz	x25, 73c0 <f23+0x34c>
    7150:	aa1903e1 	mov	x1, x25
    7154:	d2800002 	mov	x2, #0x0                   	// #0
    7158:	f9400821 	ldr	x1, [x1, #16]
    715c:	91000442 	add	x2, x2, #0x1
    7160:	b5ffffc1 	cbnz	x1, 7158 <f23+0xe4>
    7164:	eb00005f 	cmp	x2, x0
    7168:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    716c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    7170:	eb01035f 	cmp	x26, x1
    7174:	54001668 	b.hi	7440 <f23+0x3cc>  // b.pmore
    7178:	d37ffb53 	lsl	x19, x26, #1
    717c:	52800041 	mov	w1, #0x2                   	// #2
    7180:	91000660 	add	x0, x19, #0x1
    7184:	d37df000 	lsl	x0, x0, #3
    7188:	97fff75a 	bl	4ef0 <fwp_heap_alloc>
    718c:	aa0003f7 	mov	x23, x0
    7190:	911742c1 	add	x1, x22, #0x5d0
    7194:	aa0103e0 	mov	x0, x1
    7198:	f90002f3 	str	x19, [x23]
    719c:	f949d821 	ldr	x1, [x1, #5040]
    71a0:	f949ec00 	ldr	x0, [x0, #5080]
    71a4:	cb0102e1 	sub	x1, x23, x1
    71a8:	eb00403f 	cmp	x1, x0, lsl #16
    71ac:	54000342 	b.cs	7214 <f23+0x1a0>  // b.hs, b.nlast
    71b0:	911742c2 	add	x2, x22, #0x5d0
    71b4:	d350fc20 	lsr	x0, x1, #16
    71b8:	8b000800 	add	x0, x0, x0, lsl #2
    71bc:	f949fc43 	ldr	x3, [x2, #5112]
    71c0:	d37df002 	lsl	x2, x0, #3
    71c4:	8b020060 	add	x0, x3, x2
    71c8:	f9401013 	ldr	x19, [x0, #32]
    71cc:	b4000253 	cbz	x19, 7214 <f23+0x1a0>
    71d0:	38626862 	ldrb	w2, [x3, x2]
    71d4:	7100085f 	cmp	w2, #0x2
    71d8:	54000e20 	b.eq	739c <f23+0x328>  // b.none
    71dc:	7100045f 	cmp	w2, #0x1
    71e0:	540001a1 	b.ne	7214 <f23+0x1a0>  // b.any
    71e4:	29430002 	ldp	w2, w0, [x0, #24]
    71e8:	92403c21 	and	x1, x1, #0xffff
    71ec:	9b027c21 	mul	x1, x1, x2
    71f0:	d360fc21 	lsr	x1, x1, #32
    71f4:	eb00003f 	cmp	x1, x0
    71f8:	540000e2 	b.cs	7214 <f23+0x1a0>  // b.hs, b.nlast
    71fc:	8b010273 	add	x19, x19, x1
    7200:	39400260 	ldrb	w0, [x19]
    7204:	7103fc1f 	cmp	w0, #0xff
    7208:	54000f80 	b.eq	73f8 <f23+0x384>  // b.none
    720c:	52800020 	mov	w0, #0x1                   	// #1
    7210:	39000260 	strb	w0, [x19]
    7214:	b400025a 	cbz	x26, 725c <f23+0x1e8>
    7218:	8b1a12fa 	add	x26, x23, x26, lsl #4
    721c:	aa1703f3 	mov	x19, x23
    7220:	aa1803f5 	mov	x21, x24
    7224:	aa1903f4 	mov	x20, x25
    7228:	f9400683 	ldr	x3, [x20, #8]
    722c:	f94006a2 	ldr	x2, [x21, #8]
    7230:	f9400861 	ldr	x1, [x3, #16]
    7234:	f9400840 	ldr	x0, [x2, #16]
    7238:	fd400461 	ldr	d1, [x3, #8]
    723c:	fd400440 	ldr	d0, [x2, #8]
    7240:	97fff8ac 	bl	54f0 <w107>
    7244:	f9000660 	str	x0, [x19, #8]
    7248:	f8010e61 	str	x1, [x19, #16]!
    724c:	f9400a94 	ldr	x20, [x20, #16]
    7250:	f9400ab5 	ldr	x21, [x21, #16]
    7254:	eb13035f 	cmp	x26, x19
    7258:	54fffe81 	b.ne	7228 <f23+0x1b4>  // b.any
    725c:	aa1903e0 	mov	x0, x25
    7260:	97fffe91 	bl	6ca4 <fwp_drop2>
    7264:	aa1803e0 	mov	x0, x24
    7268:	97fffe8f 	bl	6ca4 <fwp_drop2>
    726c:	f94002f5 	ldr	x21, [x23]
    7270:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7274:	b4000275 	cbz	x21, 72c0 <f23+0x24c>
    7278:	fd003be8 	str	d8, [sp, #112]
    727c:	2f00e408 	movi	d8, #0x0
    7280:	910022f9 	add	x25, x23, #0x8
    7284:	910042f8 	add	x24, x23, #0x10
    7288:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    728c:	d2800013 	mov	x19, #0x0                   	// #0
    7290:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7294:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    7298:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    729c:	aa0303e1 	mov	x1, x3
    72a0:	1e602908 	fadd	d8, d8, d0
    72a4:	91000a73 	add	x19, x19, #0x2
    72a8:	97fff7df 	bl	5224 <fwp_p_ad_push>
    72ac:	aa0003f4 	mov	x20, x0
    72b0:	eb1302bf 	cmp	x21, x19
    72b4:	54fffee8 	b.hi	7290 <f23+0x21c>  // b.pmore
    72b8:	9e660115 	fmov	x21, d8
    72bc:	fd403be8 	ldr	d8, [sp, #112]
    72c0:	911742d6 	add	x22, x22, #0x5d0
    72c4:	aa1703e0 	mov	x0, x23
    72c8:	97fffd26 	bl	6760 <fwp_drop4>
    72cc:	a900d3f5 	stp	x21, x20, [sp, #8]
    72d0:	910023e1 	add	x1, sp, #0x8
    72d4:	52800000 	mov	w0, #0x0                   	// #0
    72d8:	97fff8ca 	bl	5600 <fwp_data.part.0.constprop.0>
    72dc:	f949dac1 	ldr	x1, [x22, #5040]
    72e0:	aa0003f3 	mov	x19, x0
    72e4:	f949eec0 	ldr	x0, [x22, #5080]
    72e8:	cb010261 	sub	x1, x19, x1
    72ec:	eb00403f 	cmp	x1, x0, lsl #16
    72f0:	54000322 	b.cs	7354 <f23+0x2e0>  // b.hs, b.nlast
    72f4:	d350fc22 	lsr	x2, x1, #16
    72f8:	f949fec3 	ldr	x3, [x22, #5112]
    72fc:	8b020842 	add	x2, x2, x2, lsl #2
    7300:	d37df042 	lsl	x2, x2, #3
    7304:	8b020060 	add	x0, x3, x2
    7308:	f9401014 	ldr	x20, [x0, #32]
    730c:	b4000254 	cbz	x20, 7354 <f23+0x2e0>
    7310:	38626862 	ldrb	w2, [x3, x2]
    7314:	7100085f 	cmp	w2, #0x2
    7318:	540003c0 	b.eq	7390 <f23+0x31c>  // b.none
    731c:	7100045f 	cmp	w2, #0x1
    7320:	540001a1 	b.ne	7354 <f23+0x2e0>  // b.any
    7324:	29430002 	ldp	w2, w0, [x0, #24]
    7328:	92403c21 	and	x1, x1, #0xffff
    732c:	9b027c21 	mul	x1, x1, x2
    7330:	d360fc21 	lsr	x1, x1, #32
    7334:	eb00003f 	cmp	x1, x0
    7338:	540000e2 	b.cs	7354 <f23+0x2e0>  // b.hs, b.nlast
    733c:	8b010294 	add	x20, x20, x1
    7340:	39400280 	ldrb	w0, [x20]
    7344:	7103fc1f 	cmp	w0, #0xff
    7348:	540005e0 	b.eq	7404 <f23+0x390>  // b.none
    734c:	52800020 	mov	w0, #0x1                   	// #1
    7350:	39000280 	strb	w0, [x20]
    7354:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7358:	f947f400 	ldr	x0, [x0, #4072]
    735c:	f9400fe2 	ldr	x2, [sp, #24]
    7360:	f9400001 	ldr	x1, [x0]
    7364:	eb010042 	subs	x2, x2, x1
    7368:	d2800001 	mov	x1, #0x0                   	// #0
    736c:	54000721 	b.ne	7450 <f23+0x3dc>  // b.any
    7370:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7374:	aa1303e0 	mov	x0, x19
    7378:	a94353f3 	ldp	x19, x20, [sp, #48]
    737c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7380:	a94563f7 	ldp	x23, x24, [sp, #80]
    7384:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7388:	910203ff 	add	sp, sp, #0x80
    738c:	d65f03c0 	ret
    7390:	72003c3f 	tst	w1, #0xffff
    7394:	54fffe01 	b.ne	7354 <f23+0x2e0>  // b.any
    7398:	17ffffea 	b	7340 <f23+0x2cc>
    739c:	72003c3f 	tst	w1, #0xffff
    73a0:	54fff3a1 	b.ne	7214 <f23+0x1a0>  // b.any
    73a4:	17ffff97 	b	7200 <f23+0x18c>
    73a8:	72003c3f 	tst	w1, #0xffff
    73ac:	54ffec21 	b.ne	7130 <f23+0xbc>  // b.any
    73b0:	17ffff5a 	b	7118 <f23+0xa4>
    73b4:	cb0103e1 	neg	x1, x1
    73b8:	eb02003f 	cmp	x1, x2
    73bc:	540002a3 	b.cc	7410 <f23+0x39c>  // b.lo, b.ul, b.last
    73c0:	52800041 	mov	w1, #0x2                   	// #2
    73c4:	d2800100 	mov	x0, #0x8                   	// #8
    73c8:	97fff6ca 	bl	4ef0 <fwp_heap_alloc>
    73cc:	aa0003f7 	mov	x23, x0
    73d0:	911742c0 	add	x0, x22, #0x5d0
    73d4:	f90002ff 	str	xzr, [x23]
    73d8:	f949d801 	ldr	x1, [x0, #5040]
    73dc:	f949ec00 	ldr	x0, [x0, #5080]
    73e0:	cb0102e1 	sub	x1, x23, x1
    73e4:	eb00403f 	cmp	x1, x0, lsl #16
    73e8:	54000282 	b.cs	7438 <f23+0x3c4>  // b.hs, b.nlast
    73ec:	d280001a 	mov	x26, #0x0                   	// #0
    73f0:	d2800019 	mov	x25, #0x0                   	// #0
    73f4:	17ffff6f 	b	71b0 <f23+0x13c>
    73f8:	aa1303e0 	mov	x0, x19
    73fc:	97fff4fd 	bl	47f0 <fwp_rc_forget_slot>
    7400:	17ffff83 	b	720c <f23+0x198>
    7404:	aa1403e0 	mov	x0, x20
    7408:	97fff4fa 	bl	47f0 <fwp_rc_forget_slot>
    740c:	17ffffd0 	b	734c <f23+0x2d8>
    7410:	f949fc62 	ldr	x2, [x3, #5112]
    7414:	d350fc20 	lsr	x0, x1, #16
    7418:	8b000800 	add	x0, x0, x0, lsl #2
    741c:	8b000c42 	add	x2, x2, x0, lsl #3
    7420:	f9401040 	ldr	x0, [x2, #32]
    7424:	b4fffce0 	cbz	x0, 73c0 <f23+0x34c>
    7428:	d2800019 	mov	x25, #0x0                   	// #0
    742c:	17ffff2f 	b	70e8 <f23+0x74>
    7430:	97fff4a9 	bl	46d4 <fwp_rc_wide_dup>
    7434:	17ffff3f 	b	7130 <f23+0xbc>
    7438:	d2800019 	mov	x25, #0x0                   	// #0
    743c:	17ffff88 	b	725c <f23+0x1e8>
    7440:	d0000020 	adrp	x0, d000 <__divti3+0x2f0>
    7444:	91234000 	add	x0, x0, #0x8d0
    7448:	fd003be8 	str	d8, [sp, #112]
    744c:	97fff0ed 	bl	3800 <fwp_trap>
    7450:	fd003be8 	str	d8, [sp, #112]
    7454:	97ffed0b 	bl	2880 <__stack_chk_fail@plt>
    7458:	d503201f 	nop
    745c:	d503201f 	nop

0000000000007460 <fwp_owned_entry23>:
    7460:	f9400000 	ldr	x0, [x0]
    7464:	17ffff04 	b	7074 <f23>
    7468:	d503201f 	nop
    746c:	d503201f 	nop

0000000000007470 <e23>:
    7470:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7474:	910003fd 	mov	x29, sp
    7478:	f9000bf3 	str	x19, [sp, #16]
    747c:	f9400013 	ldr	x19, [x0]
    7480:	aa1303e0 	mov	x0, x19
    7484:	97fff8a7 	bl	5720 <fwp_rc_share>
    7488:	aa1303e0 	mov	x0, x19
    748c:	97fffefa 	bl	7074 <f23>
    7490:	aa0003f3 	mov	x19, x0
    7494:	97fff8a3 	bl	5720 <fwp_rc_share>
    7498:	aa1303e0 	mov	x0, x19
    749c:	f9400bf3 	ldr	x19, [sp, #16]
    74a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    74a4:	d65f03c0 	ret
    74a8:	d503201f 	nop
    74ac:	d503201f 	nop

00000000000074b0 <f12>:
    74b0:	d10483ff 	sub	sp, sp, #0x120
    74b4:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    74b8:	f947f442 	ldr	x2, [x2, #4072]
    74bc:	910103e8 	add	x8, sp, #0x40
    74c0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    74c4:	910303fd 	add	x29, sp, #0xc0
    74c8:	9100e3e9 	add	x9, sp, #0x38
    74cc:	a90d53f3 	stp	x19, x20, [sp, #208]
    74d0:	d0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    74d4:	91174263 	add	x3, x19, #0x5d0
    74d8:	b00000d4 	adrp	x20, 20000 <__data_start>
    74dc:	9101c284 	add	x4, x20, #0x70
    74e0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    74e4:	f0fffff6 	adrp	x22, 6000 <fwp_owned_tape_release+0x20>
    74e8:	aa0003f5 	mov	x21, x0
    74ec:	f949d861 	ldr	x1, [x3, #5040]
    74f0:	a90f63f7 	stp	x23, x24, [sp, #240]
    74f4:	b00000d7 	adrp	x23, 20000 <__data_start>
    74f8:	f949ec65 	ldr	x5, [x3, #5080]
    74fc:	a9106bf9 	stp	x25, x26, [sp, #256]
    7500:	910042f7 	add	x23, x23, #0x10
    7504:	a91173fb 	stp	x27, x28, [sp, #272]
    7508:	9100e2f7 	add	x23, x23, #0x38
    750c:	cb0102e1 	sub	x1, x23, x1
    7510:	f9418886 	ldr	x6, [x4, #784]
    7514:	f9400047 	ldr	x7, [x2]
    7518:	f9005fe7 	str	x7, [sp, #184]
    751c:	d2800007 	mov	x7, #0x0                   	// #0
    7520:	12800007 	mov	w7, #0xffffffff            	// #-1
    7524:	910842c2 	add	x2, x22, #0x210
    7528:	a90123e9 	stp	x9, x8, [sp, #16]
    752c:	b9003be7 	str	w7, [sp, #56]
    7530:	a9040be6 	stp	x6, x2, [sp, #64]
    7534:	f9002be9 	str	x9, [sp, #80]
    7538:	f9018888 	str	x8, [x4, #784]
    753c:	eb05403f 	cmp	x1, x5, lsl #16
    7540:	54000342 	b.cs	75a8 <f12+0xf8>  // b.hs, b.nlast
    7544:	d350fc20 	lsr	x0, x1, #16
    7548:	f949fc64 	ldr	x4, [x3, #5112]
    754c:	8b000800 	add	x0, x0, x0, lsl #2
    7550:	d37df002 	lsl	x2, x0, #3
    7554:	8b020083 	add	x3, x4, x2
    7558:	f9401060 	ldr	x0, [x3, #32]
    755c:	b4000260 	cbz	x0, 75a8 <f12+0xf8>
    7560:	38626882 	ldrb	w2, [x4, x2]
    7564:	7100085f 	cmp	w2, #0x2
    7568:	54006f60 	b.eq	8354 <f12+0xea4>  // b.none
    756c:	7100045f 	cmp	w2, #0x1
    7570:	540001c1 	b.ne	75a8 <f12+0xf8>  // b.any
    7574:	29430864 	ldp	w4, w2, [x3, #24]
    7578:	92403c21 	and	x1, x1, #0xffff
    757c:	9b047c21 	mul	x1, x1, x4
    7580:	d360fc21 	lsr	x1, x1, #32
    7584:	eb02003f 	cmp	x1, x2
    7588:	54000102 	b.cs	75a8 <f12+0xf8>  // b.hs, b.nlast
    758c:	8b010000 	add	x0, x0, x1
    7590:	39400001 	ldrb	w1, [x0]
    7594:	340000a1 	cbz	w1, 75a8 <f12+0xf8>
    7598:	7103f43f 	cmp	w1, #0xfd
    759c:	54007708 	b.hi	847c <f12+0xfcc>  // b.pmore
    75a0:	11000421 	add	w1, w1, #0x1
    75a4:	39000001 	strb	w1, [x0]
    75a8:	aa1703e0 	mov	x0, x23
    75ac:	97fffa39 	bl	5e90 <fwp_closure_drop>
    75b0:	b4006dd5 	cbz	x21, 8368 <f12+0xeb8>
    75b4:	aa1503e0 	mov	x0, x21
    75b8:	d2800017 	mov	x23, #0x0                   	// #0
    75bc:	d503201f 	nop
    75c0:	f9400800 	ldr	x0, [x0, #16]
    75c4:	910006f7 	add	x23, x23, #0x1
    75c8:	b5ffffc0 	cbnz	x0, 75c0 <f12+0x110>
    75cc:	52800000 	mov	w0, #0x0                   	// #0
    75d0:	97fff008 	bl	35f0 <descent_phase_step>
    75d4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    75d8:	eb0002ff 	cmp	x23, x0
    75dc:	54007848 	b.hi	84e4 <f12+0x1034>  // b.pmore
    75e0:	9101c298 	add	x24, x20, #0x70
    75e4:	b9434700 	ldr	w0, [x24, #836]
    75e8:	34006a20 	cbz	w0, 832c <f12+0xe7c>
    75ec:	9101c280 	add	x0, x20, #0x70
    75f0:	f9404819 	ldr	x25, [x0, #144]
    75f4:	f9407401 	ldr	x1, [x0, #232]
    75f8:	eb19003f 	cmp	x1, x25
    75fc:	5400682a 	b.ge	8300 <f12+0xe50>  // b.tcont
    7600:	f9403a82 	ldr	x2, [x20, #112]
    7604:	8b010420 	add	x0, x1, x1, lsl #1
    7608:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    760c:	8b000820 	add	x0, x1, x0, lsl #2
    7610:	8b000c40 	add	x0, x2, x0, lsl #3
    7614:	d503201f 	nop
    7618:	b9400402 	ldr	w2, [x0, #4]
    761c:	35000082 	cbnz	w2, 762c <f12+0x17c>
    7620:	b9400002 	ldr	w2, [x0]
    7624:	6b03005f 	cmp	w2, w3
    7628:	540066c9 	b.ls	8300 <f12+0xe50>  // b.plast
    762c:	91000421 	add	x1, x1, #0x1
    7630:	9101a000 	add	x0, x0, #0x68
    7634:	eb19003f 	cmp	x1, x25
    7638:	54ffff01 	b.ne	7618 <f12+0x168>  // b.any
    763c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7640:	eb00033f 	cmp	x25, x0
    7644:	5400756c 	b.gt	84f0 <f12+0x1040>
    7648:	9101c280 	add	x0, x20, #0x70
    764c:	f9403a9a 	ldr	x26, [x20, #112]
    7650:	f9407000 	ldr	x0, [x0, #224]
    7654:	eb00033f 	cmp	x25, x0
    7658:	54000161 	b.ne	7684 <f12+0x1d4>  // b.any
    765c:	b5006b79 	cbnz	x25, 83c8 <f12+0xf18>
    7660:	d2800d01 	mov	x1, #0x68                  	// #104
    7664:	d2800038 	mov	x24, #0x1                   	// #1
    7668:	aa1a03e0 	mov	x0, x26
    766c:	97ffec81 	bl	2870 <realloc@plt>
    7670:	aa0003fa 	mov	x26, x0
    7674:	b40062e0 	cbz	x0, 82d0 <f12+0xe20>
    7678:	9101c280 	add	x0, x20, #0x70
    767c:	f9003a9a 	str	x26, [x20, #112]
    7680:	f9007018 	str	x24, [x0, #224]
    7684:	d37ffb21 	lsl	x1, x25, #1
    7688:	9101c280 	add	x0, x20, #0x70
    768c:	8b190022 	add	x2, x1, x25
    7690:	9100073b 	add	x27, x25, #0x1
    7694:	4f000400 	movi	v0.4s, #0x0
    7698:	8b020b22 	add	x2, x25, x2, lsl #2
    769c:	f900481b 	str	x27, [x0, #144]
    76a0:	8b020f42 	add	x2, x26, x2, lsl #3
    76a4:	f900305f 	str	xzr, [x2, #96]
    76a8:	ad000040 	stp	q0, q0, [x2]
    76ac:	ad010040 	stp	q0, q0, [x2, #32]
    76b0:	ad020040 	stp	q0, q0, [x2, #64]
    76b4:	8b190021 	add	x1, x1, x25
    76b8:	d0000020 	adrp	x0, d000 <__divti3+0x2f0>
    76bc:	911c8000 	add	x0, x0, #0x720
    76c0:	8b010b21 	add	x1, x25, x1, lsl #2
    76c4:	8b010f58 	add	x24, x26, x1, lsl #3
    76c8:	f900331f 	str	xzr, [x24, #96]
    76cc:	97ffecd1 	bl	2a10 <getenv@plt>
    76d0:	b4000080 	cbz	x0, 76e0 <f12+0x230>
    76d4:	39400001 	ldrb	w1, [x0]
    76d8:	7100c03f 	cmp	w1, #0x30
    76dc:	540031c0 	b.eq	7d14 <f12+0x864>  // b.none
    76e0:	9101c280 	add	x0, x20, #0x70
    76e4:	f9406801 	ldr	x1, [x0, #208]
    76e8:	b5006521 	cbnz	x1, 838c <f12+0xedc>
    76ec:	9101c282 	add	x2, x20, #0x70
    76f0:	2f000400 	mvni	v0.2s, #0x0
    76f4:	b9400303 	ldr	w3, [x24]
    76f8:	52800020 	mov	w0, #0x1                   	// #1
    76fc:	a900df17 	stp	x23, x23, [x24, #8]
    7700:	0b000063 	add	w3, w3, w0
    7704:	f9418841 	ldr	x1, [x2, #784]
    7708:	29000303 	stp	w3, w0, [x24]
    770c:	f9002b1f 	str	xzr, [x24, #80]
    7710:	f900745b 	str	x27, [x2, #232]
    7714:	fd002f00 	str	d0, [x24, #88]
    7718:	b4006d81 	cbz	x1, 84c8 <f12+0x1018>
    771c:	910842d6 	add	x22, x22, #0x210
    7720:	14000003 	b	772c <f12+0x27c>
    7724:	f9400021 	ldr	x1, [x1]
    7728:	b4006d01 	cbz	x1, 84c8 <f12+0x1018>
    772c:	f9400422 	ldr	x2, [x1, #8]
    7730:	eb16005f 	cmp	x2, x22
    7734:	54ffff81 	b.ne	7724 <f12+0x274>  // b.any
    7738:	f9400820 	ldr	x0, [x1, #16]
    773c:	2a1903e2 	mov	w2, w25
    7740:	b9400001 	ldr	w1, [x0]
    7744:	f9002b00 	str	x0, [x24, #80]
    7748:	b9005f01 	str	w1, [x24, #92]
    774c:	37f80081 	tbnz	w1, #31, 775c <f12+0x2ac>
    7750:	52800d05 	mov	w5, #0x68                  	// #104
    7754:	9b256821 	smaddl	x1, w1, w5, x26
    7758:	b9005839 	str	w25, [x1, #88]
    775c:	b9000002 	str	w2, [x0]
    7760:	d3707c77 	ubfiz	x23, x3, #16, #32
    7764:	52800020 	mov	w0, #0x1                   	// #1
    7768:	aa1b02f7 	orr	x23, x23, x27
    776c:	97ffefa1 	bl	35f0 <descent_phase_step>
    7770:	aa1503e0 	mov	x0, x21
    7774:	d2800002 	mov	x2, #0x0                   	// #0
    7778:	b40057d5 	cbz	x21, 8270 <f12+0xdc0>
    777c:	d503201f 	nop
    7780:	f9400800 	ldr	x0, [x0, #16]
    7784:	91000442 	add	x2, x2, #0x1
    7788:	b5ffffc0 	cbnz	x0, 7780 <f12+0x2d0>
    778c:	aa1503e1 	mov	x1, x21
    7790:	f9400821 	ldr	x1, [x1, #16]
    7794:	91000400 	add	x0, x0, #0x1
    7798:	b5ffffc1 	cbnz	x1, 7790 <f12+0x2e0>
    779c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    77a0:	eb01001f 	cmp	x0, x1
    77a4:	54006868 	b.hi	84b0 <f12+0x1000>  // b.pmore
    77a8:	f100005f 	cmp	x2, #0x0
    77ac:	5400562d 	b.le	8270 <f12+0xdc0>
    77b0:	eb00005f 	cmp	x2, x0
    77b4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    77b8:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    77bc:	eb0102df 	cmp	x22, x1
    77c0:	54006788 	b.hi	84b0 <f12+0x1000>  // b.pmore
    77c4:	d37ffad9 	lsl	x25, x22, #1
    77c8:	52800041 	mov	w1, #0x2                   	// #2
    77cc:	91000720 	add	x0, x25, #0x1
    77d0:	d37df000 	lsl	x0, x0, #3
    77d4:	97fff5c7 	bl	4ef0 <fwp_heap_alloc>
    77d8:	aa0003f8 	mov	x24, x0
    77dc:	91174261 	add	x1, x19, #0x5d0
    77e0:	aa0103e0 	mov	x0, x1
    77e4:	f9000319 	str	x25, [x24]
    77e8:	f949d821 	ldr	x1, [x1, #5040]
    77ec:	f949ec00 	ldr	x0, [x0, #5080]
    77f0:	cb010301 	sub	x1, x24, x1
    77f4:	eb00403f 	cmp	x1, x0, lsl #16
    77f8:	54005922 	b.cs	831c <f12+0xe6c>  // b.hs, b.nlast
    77fc:	91174262 	add	x2, x19, #0x5d0
    7800:	d350fc20 	lsr	x0, x1, #16
    7804:	8b000800 	add	x0, x0, x0, lsl #2
    7808:	f949fc43 	ldr	x3, [x2, #5112]
    780c:	d37df002 	lsl	x2, x0, #3
    7810:	8b020060 	add	x0, x3, x2
    7814:	f9401019 	ldr	x25, [x0, #32]
    7818:	b4000259 	cbz	x25, 7860 <f12+0x3b0>
    781c:	38626862 	ldrb	w2, [x3, x2]
    7820:	7100085f 	cmp	w2, #0x2
    7824:	54005920 	b.eq	8348 <f12+0xe98>  // b.none
    7828:	7100045f 	cmp	w2, #0x1
    782c:	540001a1 	b.ne	7860 <f12+0x3b0>  // b.any
    7830:	29430002 	ldp	w2, w0, [x0, #24]
    7834:	92403c21 	and	x1, x1, #0xffff
    7838:	9b027c21 	mul	x1, x1, x2
    783c:	d360fc21 	lsr	x1, x1, #32
    7840:	eb00003f 	cmp	x1, x0
    7844:	540000e2 	b.cs	7860 <f12+0x3b0>  // b.hs, b.nlast
    7848:	8b010339 	add	x25, x25, x1
    784c:	39400320 	ldrb	w0, [x25]
    7850:	7103fc1f 	cmp	w0, #0xff
    7854:	54006020 	b.eq	8458 <f12+0xfa8>  // b.none
    7858:	52800020 	mov	w0, #0x1                   	// #1
    785c:	39000320 	strb	w0, [x25]
    7860:	b4000236 	cbz	x22, 78a4 <f12+0x3f4>
    7864:	d3607ee4 	lsl	x4, x23, #32
    7868:	aa1503e0 	mov	x0, x21
    786c:	f94006a5 	ldr	x5, [x21, #8]
    7870:	aa0403e3 	mov	x3, x4
    7874:	91002302 	add	x2, x24, #0x8
    7878:	d2800001 	mov	x1, #0x0                   	// #0
    787c:	14000005 	b	7890 <f12+0x3e0>
    7880:	f9400405 	ldr	x5, [x0, #8]
    7884:	ab010083 	adds	x3, x4, x1
    7888:	91004042 	add	x2, x2, #0x10
    788c:	54006406 	b.vs	850c <f12+0x105c>
    7890:	a9000c45 	stp	x5, x3, [x2]
    7894:	91000421 	add	x1, x1, #0x1
    7898:	f9400800 	ldr	x0, [x0, #16]
    789c:	eb0102df 	cmp	x22, x1
    78a0:	54ffff08 	b.hi	7880 <f12+0x3d0>  // b.pmore
    78a4:	f9400300 	ldr	x0, [x24]
    78a8:	f100041f 	cmp	x0, #0x1
    78ac:	540053a9 	b.ls	8320 <f12+0xe70>  // b.plast
    78b0:	d341fc00 	lsr	x0, x0, #1
    78b4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    78b8:	d100041a 	sub	x26, x0, #0x1
    78bc:	eb01035f 	cmp	x26, x1
    78c0:	54005f88 	b.hi	84b0 <f12+0x1000>  // b.pmore
    78c4:	b40052fa 	cbz	x26, 8320 <f12+0xe70>
    78c8:	d1002301 	sub	x1, x24, #0x8
    78cc:	91002316 	add	x22, x24, #0x8
    78d0:	8b001039 	add	x25, x1, x0, lsl #4
    78d4:	d503201f 	nop
    78d8:	f94006c0 	ldr	x0, [x22, #8]
    78dc:	f9400ec1 	ldr	x1, [x22, #24]
    78e0:	fd4002c0 	ldr	d0, [x22]
    78e4:	fd400ac1 	ldr	d1, [x22, #16]
    78e8:	97fff702 	bl	54f0 <w107>
    78ec:	a90006c0 	stp	x0, x1, [x22]
    78f0:	910042d6 	add	x22, x22, #0x10
    78f4:	eb1902df 	cmp	x22, x25
    78f8:	54ffff01 	b.ne	78d8 <f12+0x428>  // b.any
    78fc:	aa1803f9 	mov	x25, x24
    7900:	d37ffb56 	lsl	x22, x26, #1
    7904:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7908:	d280001a 	mov	x26, #0x0                   	// #0
    790c:	f8010736 	str	x22, [x25], #16
    7910:	f87a7b22 	ldr	x2, [x25, x26, lsl #3]
    7914:	aa0403e0 	mov	x0, x4
    7918:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    791c:	91000b5a 	add	x26, x26, #0x2
    7920:	aa0303e1 	mov	x1, x3
    7924:	97fff640 	bl	5224 <fwp_p_ad_push>
    7928:	aa0003e4 	mov	x4, x0
    792c:	eb16035f 	cmp	x26, x22
    7930:	54ffff03 	b.cc	7910 <f12+0x460>  // b.lo, b.ul, b.last
    7934:	aa1803e0 	mov	x0, x24
    7938:	f90007e4 	str	x4, [sp, #8]
    793c:	97fffb89 	bl	6760 <fwp_drop4>
    7940:	93407efc 	sxtw	x28, w23
    7944:	52800040 	mov	w0, #0x2                   	// #2
    7948:	97ffef2a 	bl	35f0 <descent_phase_step>
    794c:	aa1c03e0 	mov	x0, x28
    7950:	97fff078 	bl	3b30 <fwp_tape_of>
    7954:	f9403002 	ldr	x2, [x0, #96]
    7958:	aa0003e7 	mov	x7, x0
    795c:	f94007e4 	ldr	x4, [sp, #8]
    7960:	b5005bc2 	cbnz	x2, 84d8 <f12+0x1028>
    7964:	f90007e4 	str	x4, [sp, #8]
    7968:	97ffed8a 	bl	2f90 <fwp_tape_unlink_scope>
    796c:	b9400008 	ldr	w8, [x0]
    7970:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    7974:	a940801b 	ldp	x27, x0, [x0, #8]
    7978:	b90004ff 	str	wzr, [x7, #4]
    797c:	f94007e4 	ldr	x4, [sp, #8]
    7980:	6b03011f 	cmp	w8, w3
    7984:	a941d8ea 	ldp	x10, x22, [x7, #24]
    7988:	a942e0f7 	ldp	x23, x24, [x7, #40]
    798c:	a943e8f9 	ldp	x25, x26, [x7, #56]
    7990:	f94024e2 	ldr	x2, [x7, #72]
    7994:	54000108 	b.hi	79b4 <f12+0x504>  // b.pmore
    7998:	9101c288 	add	x8, x20, #0x70
    799c:	92403f83 	and	x3, x28, #0xffff
    79a0:	d1000463 	sub	x3, x3, #0x1
    79a4:	f9407509 	ldr	x9, [x8, #232]
    79a8:	eb09007f 	cmp	x3, x9
    79ac:	5400004a 	b.ge	79b4 <f12+0x504>  // b.tcont
    79b0:	f9007503 	str	x3, [x8, #232]
    79b4:	4f000400 	movi	v0.4s, #0x0
    79b8:	9101c289 	add	x9, x20, #0x70
    79bc:	f9000cff 	str	xzr, [x7, #24]
    79c0:	9101c3e1 	add	x1, sp, #0x70
    79c4:	910163e3 	add	x3, sp, #0x58
    79c8:	b0ffffe8 	adrp	x8, 4000 <fwp_heap_report+0x60>
    79cc:	f941892b 	ldr	x11, [x9, #784]
    79d0:	3c8080e0 	stur	q0, [x7, #8]
    79d4:	910e0108 	add	x8, x8, #0x380
    79d8:	ad0100e0 	stp	q0, q0, [x7, #32]
    79dc:	f90007e1 	str	x1, [sp, #8]
    79e0:	a9047cff 	stp	xzr, xzr, [x7, #64]
    79e4:	a905a3eb 	stp	x11, x8, [sp, #88]
    79e8:	a906dbe1 	stp	x1, x22, [sp, #104]
    79ec:	a907e3f7 	stp	x23, x24, [sp, #120]
    79f0:	a908ebf9 	stp	x25, x26, [sp, #136]
    79f4:	a9098bea 	stp	x10, x2, [sp, #152]
    79f8:	f9018923 	str	x3, [x9, #784]
    79fc:	b7f84be4 	tbnz	x4, #63, 8378 <f12+0xec8>
    7a00:	eb84839f 	cmp	x28, x4, asr #32
    7a04:	54005501 	b.ne	84a4 <f12+0xff4>  // b.any
    7a08:	92407c83 	and	x3, x4, #0xffffffff
    7a0c:	eb24401f 	cmp	x0, w4, uxtw
    7a10:	5400544d 	b.le	8498 <f12+0xfe8>
    7a14:	eb03037f 	cmp	x27, x3
    7a18:	9a83c77c 	csinc	x28, x27, x3, gt
    7a1c:	eb1c005f 	cmp	x2, x28
    7a20:	5400448a 	b.ge	82b0 <f12+0xe00>  // b.tcont
    7a24:	f100005f 	cmp	x2, #0x0
    7a28:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7a2c:	9a9c1042 	csel	x2, x2, x28, ne	// ne = any
    7a30:	14000004 	b	7a40 <f12+0x590>
    7a34:	eb01005f 	cmp	x2, x1
    7a38:	d37ff842 	lsl	x2, x2, #1
    7a3c:	9a9cd042 	csel	x2, x2, x28, le
    7a40:	eb1c005f 	cmp	x2, x28
    7a44:	54ffff8b 	b.lt	7a34 <f12+0x584>  // b.tstop
    7a48:	f90017e4 	str	x4, [sp, #40]
    7a4c:	b4004e3a 	cbz	x26, 8410 <f12+0xf60>
    7a50:	aa1a03e0 	mov	x0, x26
    7a54:	d37df041 	lsl	x1, x2, #3
    7a58:	f90013e2 	str	x2, [sp, #32]
    7a5c:	97ffeb85 	bl	2870 <realloc@plt>
    7a60:	a94213e2 	ldp	x2, x4, [sp, #32]
    7a64:	aa0003fa 	mov	x26, x0
    7a68:	b400425a 	cbz	x26, 82b0 <f12+0xe00>
    7a6c:	f9004bfa 	str	x26, [sp, #144]
    7a70:	f90053e2 	str	x2, [sp, #160]
    7a74:	b500157c 	cbnz	x28, 7d20 <f12+0x870>
    7a78:	b7f800c4 	tbnz	x4, #63, 7a90 <f12+0x5e0>
    7a7c:	92407c84 	and	x4, x4, #0xffffffff
    7a80:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7a84:	fc647b40 	ldr	d0, [x26, x4, lsl #3]
    7a88:	1e612800 	fadd	d0, d0, d1
    7a8c:	fc247b40 	str	d0, [x26, x4, lsl #3]
    7a90:	9101c281 	add	x1, x20, #0x70
    7a94:	cb1b0384 	sub	x4, x28, x27
    7a98:	52800060 	mov	w0, #0x3                   	// #3
    7a9c:	a9428827 	ldp	x7, x2, [x1, #40]
    7aa0:	8b070084 	add	x4, x4, x7
    7aa4:	8b1b0042 	add	x2, x2, x27
    7aa8:	a9028824 	stp	x4, x2, [x1, #40]
    7aac:	97ffeed1 	bl	35f0 <descent_phase_step>
    7ab0:	d1000783 	sub	x3, x28, #0x1
    7ab4:	d1000764 	sub	x4, x27, #0x1
    7ab8:	eb03037f 	cmp	x27, x3
    7abc:	540003ac 	b.gt	7b30 <f12+0x680>
    7ac0:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    7ac4:	1e602008 	fcmp	d0, #0.0
    7ac8:	540002e0 	b.eq	7b24 <f12+0x674>  // b.none
    7acc:	cb1b0be0 	neg	x0, x27, lsl #2
    7ad0:	cb1b03e2 	neg	x2, x27
    7ad4:	8b0002c1 	add	x1, x22, x0
    7ad8:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    7adc:	37f80101 	tbnz	w1, #31, 7afc <f12+0x64c>
    7ae0:	8b020f07 	add	x7, x24, x2, lsl #3
    7ae4:	93407c21 	sxtw	x1, w1
    7ae8:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    7aec:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    7af0:	1e620802 	fmul	d2, d0, d2
    7af4:	1e622821 	fadd	d1, d1, d2
    7af8:	fc217b41 	str	d1, [x26, x1, lsl #3]
    7afc:	8b0002e0 	add	x0, x23, x0
    7b00:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    7b04:	37f80100 	tbnz	w0, #31, 7b24 <f12+0x674>
    7b08:	8b020f22 	add	x2, x25, x2, lsl #3
    7b0c:	93407c00 	sxtw	x0, w0
    7b10:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    7b14:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    7b18:	1e620800 	fmul	d0, d0, d2
    7b1c:	1e602820 	fadd	d0, d1, d0
    7b20:	fc207b40 	str	d0, [x26, x0, lsl #3]
    7b24:	d1000463 	sub	x3, x3, #0x1
    7b28:	eb03009f 	cmp	x4, x3
    7b2c:	54fffca1 	b.ne	7ac0 <f12+0x610>  // b.any
    7b30:	52800080 	mov	w0, #0x4                   	// #4
    7b34:	97ffeeaf 	bl	35f0 <descent_phase_step>
    7b38:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7b3c:	eb00037f 	cmp	x27, x0
    7b40:	54004de8 	b.hi	84fc <f12+0x104c>  // b.pmore
    7b44:	91000760 	add	x0, x27, #0x1
    7b48:	52800041 	mov	w1, #0x2                   	// #2
    7b4c:	d37df000 	lsl	x0, x0, #3
    7b50:	97fff4e8 	bl	4ef0 <fwp_heap_alloc>
    7b54:	aa0003e2 	mov	x2, x0
    7b58:	aa0003f6 	mov	x22, x0
    7b5c:	d2800001 	mov	x1, #0x0                   	// #0
    7b60:	f800845b 	str	x27, [x2], #8
    7b64:	b40000db 	cbz	x27, 7b7c <f12+0x6cc>
    7b68:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    7b6c:	f8217840 	str	x0, [x2, x1, lsl #3]
    7b70:	91000421 	add	x1, x1, #0x1
    7b74:	eb01037f 	cmp	x27, x1
    7b78:	54ffff81 	b.ne	7b68 <f12+0x6b8>  // b.any
    7b7c:	528000a0 	mov	w0, #0x5                   	// #5
    7b80:	97ffee9c 	bl	35f0 <descent_phase_step>
    7b84:	f94007e0 	ldr	x0, [sp, #8]
    7b88:	9101c281 	add	x1, x20, #0x70
    7b8c:	f9402ff8 	ldr	x24, [sp, #88]
    7b90:	f9018838 	str	x24, [x1, #784]
    7b94:	97fff1fb 	bl	4380 <fwp_tape_buffers_release>
    7b98:	528000c0 	mov	w0, #0x6                   	// #6
    7b9c:	97ffee95 	bl	35f0 <descent_phase_step>
    7ba0:	91174262 	add	x2, x19, #0x5d0
    7ba4:	f949d841 	ldr	x1, [x2, #5040]
    7ba8:	f949ec40 	ldr	x0, [x2, #5080]
    7bac:	cb0102c1 	sub	x1, x22, x1
    7bb0:	eb00403f 	cmp	x1, x0, lsl #16
    7bb4:	54000322 	b.cs	7c18 <f12+0x768>  // b.hs, b.nlast
    7bb8:	d350fc20 	lsr	x0, x1, #16
    7bbc:	f949fc43 	ldr	x3, [x2, #5112]
    7bc0:	8b000800 	add	x0, x0, x0, lsl #2
    7bc4:	d37df002 	lsl	x2, x0, #3
    7bc8:	8b020060 	add	x0, x3, x2
    7bcc:	f9401017 	ldr	x23, [x0, #32]
    7bd0:	b4000257 	cbz	x23, 7c18 <f12+0x768>
    7bd4:	38626862 	ldrb	w2, [x3, x2]
    7bd8:	7100085f 	cmp	w2, #0x2
    7bdc:	54003d20 	b.eq	8380 <f12+0xed0>  // b.none
    7be0:	7100045f 	cmp	w2, #0x1
    7be4:	540001a1 	b.ne	7c18 <f12+0x768>  // b.any
    7be8:	29430002 	ldp	w2, w0, [x0, #24]
    7bec:	92403c21 	and	x1, x1, #0xffff
    7bf0:	9b027c21 	mul	x1, x1, x2
    7bf4:	d360fc21 	lsr	x1, x1, #32
    7bf8:	eb00003f 	cmp	x1, x0
    7bfc:	540000e2 	b.cs	7c18 <f12+0x768>  // b.hs, b.nlast
    7c00:	8b0102f7 	add	x23, x23, x1
    7c04:	394002e0 	ldrb	w0, [x23]
    7c08:	7103fc1f 	cmp	w0, #0xff
    7c0c:	540042c0 	b.eq	8464 <f12+0xfb4>  // b.none
    7c10:	52800020 	mov	w0, #0x1                   	// #1
    7c14:	390002e0 	strb	w0, [x23]
    7c18:	f9400fe0 	ldr	x0, [sp, #24]
    7c1c:	eb00031f 	cmp	x24, x0
    7c20:	54004741 	b.ne	8508 <f12+0x1058>  // b.any
    7c24:	f9400be0 	ldr	x0, [sp, #16]
    7c28:	9101c294 	add	x20, x20, #0x70
    7c2c:	f94023e1 	ldr	x1, [sp, #64]
    7c30:	f9018a81 	str	x1, [x20, #784]
    7c34:	97fff977 	bl	6210 <fwp_tape_scope_release>
    7c38:	f94002c0 	ldr	x0, [x22]
    7c3c:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    7c40:	b7f82c40 	tbnz	x0, #63, 81c8 <f12+0xd18>
    7c44:	91174262 	add	x2, x19, #0x5d0
    7c48:	f949d840 	ldr	x0, [x2, #5040]
    7c4c:	f949ec41 	ldr	x1, [x2, #5080]
    7c50:	cb0002c0 	sub	x0, x22, x0
    7c54:	eb01401f 	cmp	x0, x1, lsl #16
    7c58:	54002b82 	b.cs	81c8 <f12+0xd18>  // b.hs, b.nlast
    7c5c:	d350fc01 	lsr	x1, x0, #16
    7c60:	f949fc44 	ldr	x4, [x2, #5112]
    7c64:	8b010821 	add	x1, x1, x1, lsl #2
    7c68:	d37df021 	lsl	x1, x1, #3
    7c6c:	8b010083 	add	x3, x4, x1
    7c70:	f9401062 	ldr	x2, [x3, #32]
    7c74:	b4002aa2 	cbz	x2, 81c8 <f12+0xd18>
    7c78:	38616881 	ldrb	w1, [x4, x1]
    7c7c:	7100083f 	cmp	w1, #0x2
    7c80:	540029e0 	b.eq	81bc <f12+0xd0c>  // b.none
    7c84:	7100043f 	cmp	w1, #0x1
    7c88:	54002a01 	b.ne	81c8 <f12+0xd18>  // b.any
    7c8c:	29430464 	ldp	w4, w1, [x3, #24]
    7c90:	92403c00 	and	x0, x0, #0xffff
    7c94:	9b047c00 	mul	x0, x0, x4
    7c98:	d360fc00 	lsr	x0, x0, #32
    7c9c:	eb01001f 	cmp	x0, x1
    7ca0:	54002942 	b.cs	81c8 <f12+0xd18>  // b.hs, b.nlast
    7ca4:	8b000042 	add	x2, x2, x0
    7ca8:	39400040 	ldrb	w0, [x2]
    7cac:	7100041f 	cmp	w0, #0x1
    7cb0:	540028c1 	b.ne	81c8 <f12+0xd18>  // b.any
    7cb4:	aa1603fa 	mov	x26, x22
    7cb8:	d2800000 	mov	x0, #0x0                   	// #0
    7cbc:	f90007f6 	str	x22, [sp, #8]
    7cc0:	f94007e1 	ldr	x1, [sp, #8]
    7cc4:	91002023 	add	x3, x1, #0x8
    7cc8:	d2800001 	mov	x1, #0x0                   	// #0
    7ccc:	b4000394 	cbz	x20, 7d3c <f12+0x88c>
    7cd0:	f0000022 	adrp	x2, e000 <_IO_stdin_used+0xbd0>
    7cd4:	910022c5 	add	x5, x22, #0x8
    7cd8:	fd411041 	ldr	d1, [x2, #544]
    7cdc:	14000009 	b	7d00 <f12+0x850>
    7ce0:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7ce4:	f9400342 	ldr	x2, [x26]
    7ce8:	1e600820 	fmul	d0, d1, d0
    7cec:	b7f83e82 	tbnz	x2, #63, 84bc <f12+0x100c>
    7cf0:	91000421 	add	x1, x1, #0x1
    7cf4:	fc008460 	str	d0, [x3], #8
    7cf8:	eb01029f 	cmp	x20, x1
    7cfc:	54000200 	b.eq	7d3c <f12+0x88c>  // b.none
    7d00:	f94002c4 	ldr	x4, [x22]
    7d04:	aa0503e2 	mov	x2, x5
    7d08:	b6fffec4 	tbz	x4, #63, 7ce0 <f12+0x830>
    7d0c:	f9400ac2 	ldr	x2, [x22, #16]
    7d10:	17fffff4 	b	7ce0 <f12+0x830>
    7d14:	39400400 	ldrb	w0, [x0, #1]
    7d18:	34ffcea0 	cbz	w0, 76ec <f12+0x23c>
    7d1c:	17fffe71 	b	76e0 <f12+0x230>
    7d20:	d37df382 	lsl	x2, x28, #3
    7d24:	aa1a03e0 	mov	x0, x26
    7d28:	52800001 	mov	w1, #0x0                   	// #0
    7d2c:	f90013e4 	str	x4, [sp, #32]
    7d30:	97ffeac8 	bl	2850 <memset@plt>
    7d34:	f94013e4 	ldr	x4, [sp, #32]
    7d38:	17ffff50 	b	7a78 <f12+0x5c8>
    7d3c:	97fffa89 	bl	6760 <fwp_drop4>
    7d40:	aa1503e1 	mov	x1, x21
    7d44:	d2800002 	mov	x2, #0x0                   	// #0
    7d48:	b4003735 	cbz	x21, 842c <f12+0xf7c>
    7d4c:	d503201f 	nop
    7d50:	f9400821 	ldr	x1, [x1, #16]
    7d54:	91000442 	add	x2, x2, #0x1
    7d58:	b5ffffc1 	cbnz	x1, 7d50 <f12+0x8a0>
    7d5c:	f9400343 	ldr	x3, [x26]
    7d60:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7d64:	b7f81f43 	tbnz	x3, #63, 814c <f12+0xc9c>
    7d68:	91174261 	add	x1, x19, #0x5d0
    7d6c:	f94007e4 	ldr	x4, [sp, #8]
    7d70:	f949d820 	ldr	x0, [x1, #5040]
    7d74:	f949ec21 	ldr	x1, [x1, #5080]
    7d78:	cb000080 	sub	x0, x4, x0
    7d7c:	eb01401f 	cmp	x0, x1, lsl #16
    7d80:	54001e62 	b.cs	814c <f12+0xc9c>  // b.hs, b.nlast
    7d84:	91174264 	add	x4, x19, #0x5d0
    7d88:	d350fc01 	lsr	x1, x0, #16
    7d8c:	8b010821 	add	x1, x1, x1, lsl #2
    7d90:	f949fc86 	ldr	x6, [x4, #5112]
    7d94:	d37df021 	lsl	x1, x1, #3
    7d98:	8b0100c5 	add	x5, x6, x1
    7d9c:	f94010a4 	ldr	x4, [x5, #32]
    7da0:	b4001d44 	cbz	x4, 8148 <f12+0xc98>
    7da4:	386168c1 	ldrb	w1, [x6, x1]
    7da8:	7100083f 	cmp	w1, #0x2
    7dac:	54001ca0 	b.eq	8140 <f12+0xc90>  // b.none
    7db0:	7100043f 	cmp	w1, #0x1
    7db4:	54001ca1 	b.ne	8148 <f12+0xc98>  // b.any
    7db8:	294304a6 	ldp	w6, w1, [x5, #24]
    7dbc:	92403c00 	and	x0, x0, #0xffff
    7dc0:	9b067c00 	mul	x0, x0, x6
    7dc4:	d360fc00 	lsr	x0, x0, #32
    7dc8:	eb01001f 	cmp	x0, x1
    7dcc:	54001be2 	b.cs	8148 <f12+0xc98>  // b.hs, b.nlast
    7dd0:	8b000084 	add	x4, x4, x0
    7dd4:	39400098 	ldrb	w24, [x4]
    7dd8:	7100071f 	cmp	w24, #0x1
    7ddc:	54001b61 	b.ne	8148 <f12+0xc98>  // b.any
    7de0:	b90013f8 	str	w24, [sp, #16]
    7de4:	eb1c005f 	cmp	x2, x28
    7de8:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    7dec:	91002359 	add	x25, x26, #0x8
    7df0:	b40034fc 	cbz	x28, 848c <f12+0xfdc>
    7df4:	f94007e0 	ldr	x0, [sp, #8]
    7df8:	d37df385 	lsl	x5, x28, #3
    7dfc:	aa1503e2 	mov	x2, x21
    7e00:	d2800001 	mov	x1, #0x0                   	// #0
    7e04:	91002000 	add	x0, x0, #0x8
    7e08:	1400000a 	b	7e30 <f12+0x980>
    7e0c:	fc616881 	ldr	d1, [x4, x1]
    7e10:	fd400440 	ldr	d0, [x2, #8]
    7e14:	1e613800 	fsub	d0, d0, d1
    7e18:	fc216b20 	str	d0, [x25, x1]
    7e1c:	91002021 	add	x1, x1, #0x8
    7e20:	f9400842 	ldr	x2, [x2, #16]
    7e24:	eb05003f 	cmp	x1, x5
    7e28:	540001c0 	b.eq	7e60 <f12+0x9b0>  // b.none
    7e2c:	f9400343 	ldr	x3, [x26]
    7e30:	aa0003e4 	mov	x4, x0
    7e34:	b6fffec3 	tbz	x3, #63, 7e0c <f12+0x95c>
    7e38:	f94007e3 	ldr	x3, [sp, #8]
    7e3c:	fd400440 	ldr	d0, [x2, #8]
    7e40:	f9400864 	ldr	x4, [x3, #16]
    7e44:	fc616881 	ldr	d1, [x4, x1]
    7e48:	1e613800 	fsub	d0, d0, d1
    7e4c:	fc216b20 	str	d0, [x25, x1]
    7e50:	91002021 	add	x1, x1, #0x8
    7e54:	f9400842 	ldr	x2, [x2, #16]
    7e58:	eb05003f 	cmp	x1, x5
    7e5c:	54fffe81 	b.ne	7e2c <f12+0x97c>  // b.any
    7e60:	b4003135 	cbz	x21, 8484 <f12+0xfd4>
    7e64:	91174260 	add	x0, x19, #0x5d0
    7e68:	aa1503e2 	mov	x2, x21
    7e6c:	d280001a 	mov	x26, #0x0                   	// #0
    7e70:	f949ec06 	ldr	x6, [x0, #5080]
    7e74:	f949d807 	ldr	x7, [x0, #5040]
    7e78:	f949fc05 	ldr	x5, [x0, #5112]
    7e7c:	d370bcc6 	lsl	x6, x6, #16
    7e80:	14000006 	b	7e98 <f12+0x9e8>
    7e84:	f9400842 	ldr	x2, [x2, #16]
    7e88:	9100075a 	add	x26, x26, #0x1
    7e8c:	f100005f 	cmp	x2, #0x0
    7e90:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    7e94:	54000329 	b.ls	7ef8 <f12+0xa48>  // b.plast
    7e98:	cb070040 	sub	x0, x2, x7
    7e9c:	eb06001f 	cmp	x0, x6
    7ea0:	540002c2 	b.cs	7ef8 <f12+0xa48>  // b.hs, b.nlast
    7ea4:	d350fc01 	lsr	x1, x0, #16
    7ea8:	8b010821 	add	x1, x1, x1, lsl #2
    7eac:	d37df021 	lsl	x1, x1, #3
    7eb0:	8b0100a4 	add	x4, x5, x1
    7eb4:	f9401083 	ldr	x3, [x4, #32]
    7eb8:	b4000203 	cbz	x3, 7ef8 <f12+0xa48>
    7ebc:	386168a1 	ldrb	w1, [x5, x1]
    7ec0:	7100083f 	cmp	w1, #0x2
    7ec4:	54000de0 	b.eq	8080 <f12+0xbd0>  // b.none
    7ec8:	7100043f 	cmp	w1, #0x1
    7ecc:	54000161 	b.ne	7ef8 <f12+0xa48>  // b.any
    7ed0:	29430488 	ldp	w8, w1, [x4, #24]
    7ed4:	92403c00 	and	x0, x0, #0xffff
    7ed8:	9b087c00 	mul	x0, x0, x8
    7edc:	d360fc00 	lsr	x0, x0, #32
    7ee0:	eb01001f 	cmp	x0, x1
    7ee4:	540000a2 	b.cs	7ef8 <f12+0xa48>  // b.hs, b.nlast
    7ee8:	8b000063 	add	x3, x3, x0
    7eec:	39400060 	ldrb	w0, [x3]
    7ef0:	7100041f 	cmp	w0, #0x1
    7ef4:	54fffc80 	b.eq	7e84 <f12+0x9d4>  // b.none
    7ef8:	eb1a039f 	cmp	x28, x26
    7efc:	54000ca9 	b.ls	8090 <f12+0xbe0>  // b.plast
    7f00:	d1002337 	sub	x23, x25, #0x8
    7f04:	9102a3f6 	add	x22, sp, #0xa8
    7f08:	91174278 	add	x24, x19, #0x5d0
    7f0c:	d2800014 	mov	x20, #0x0                   	// #0
    7f10:	14000012 	b	7f58 <f12+0xaa8>
    7f14:	7100045f 	cmp	w2, #0x1
    7f18:	540001a1 	b.ne	7f4c <f12+0xa9c>  // b.any
    7f1c:	29430002 	ldp	w2, w0, [x0, #24]
    7f20:	92403c21 	and	x1, x1, #0xffff
    7f24:	9b027c21 	mul	x1, x1, x2
    7f28:	d360fc21 	lsr	x1, x1, #32
    7f2c:	eb00003f 	cmp	x1, x0
    7f30:	540000e2 	b.cs	7f4c <f12+0xa9c>  // b.hs, b.nlast
    7f34:	8b01037b 	add	x27, x27, x1
    7f38:	39400360 	ldrb	w0, [x27]
    7f3c:	7103fc1f 	cmp	w0, #0xff
    7f40:	54001b20 	b.eq	82a4 <f12+0xdf4>  // b.none
    7f44:	52800020 	mov	w0, #0x1                   	// #1
    7f48:	39000360 	strb	w0, [x27]
    7f4c:	d100079c 	sub	x28, x28, #0x1
    7f50:	eb1a039f 	cmp	x28, x26
    7f54:	54000369 	b.ls	7fc0 <f12+0xb10>  // b.plast
    7f58:	f87c7ae2 	ldr	x2, [x23, x28, lsl #3]
    7f5c:	aa1603e1 	mov	x1, x22
    7f60:	52800020 	mov	w0, #0x1                   	// #1
    7f64:	a90ad3e2 	stp	x2, x20, [sp, #168]
    7f68:	97fff5a6 	bl	5600 <fwp_data.part.0.constprop.0>
    7f6c:	aa0003f4 	mov	x20, x0
    7f70:	f949db01 	ldr	x1, [x24, #5040]
    7f74:	f949ef00 	ldr	x0, [x24, #5080]
    7f78:	cb010281 	sub	x1, x20, x1
    7f7c:	eb00403f 	cmp	x1, x0, lsl #16
    7f80:	54fffe62 	b.cs	7f4c <f12+0xa9c>  // b.hs, b.nlast
    7f84:	d350fc22 	lsr	x2, x1, #16
    7f88:	f949ff03 	ldr	x3, [x24, #5112]
    7f8c:	8b020842 	add	x2, x2, x2, lsl #2
    7f90:	d37df042 	lsl	x2, x2, #3
    7f94:	8b020060 	add	x0, x3, x2
    7f98:	f940101b 	ldr	x27, [x0, #32]
    7f9c:	b4fffd9b 	cbz	x27, 7f4c <f12+0xa9c>
    7fa0:	38626862 	ldrb	w2, [x3, x2]
    7fa4:	7100085f 	cmp	w2, #0x2
    7fa8:	54fffb61 	b.ne	7f14 <f12+0xa64>  // b.any
    7fac:	72003c3f 	tst	w1, #0xffff
    7fb0:	54fffc40 	b.eq	7f38 <f12+0xa88>  // b.none
    7fb4:	d100079c 	sub	x28, x28, #0x1
    7fb8:	eb1a039f 	cmp	x28, x26
    7fbc:	54fffce8 	b.hi	7f58 <f12+0xaa8>  // b.pmore
    7fc0:	b50006ba 	cbnz	x26, 8094 <f12+0xbe4>
    7fc4:	b94013e0 	ldr	w0, [sp, #16]
    7fc8:	d2800038 	mov	x24, #0x1                   	// #1
    7fcc:	d280001b 	mov	x27, #0x0                   	// #0
    7fd0:	7100001f 	cmp	w0, #0x0
    7fd4:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7fd8:	b40007db 	cbz	x27, 80d0 <f12+0xc20>
    7fdc:	d100077b 	sub	x27, x27, #0x1
    7fe0:	91174273 	add	x19, x19, #0x5d0
    7fe4:	d503201f 	nop
    7fe8:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    7fec:	aa1603e1 	mov	x1, x22
    7ff0:	52800020 	mov	w0, #0x1                   	// #1
    7ff4:	a90ad3e2 	stp	x2, x20, [sp, #168]
    7ff8:	97fff582 	bl	5600 <fwp_data.part.0.constprop.0>
    7ffc:	aa0003f4 	mov	x20, x0
    8000:	f949da61 	ldr	x1, [x19, #5040]
    8004:	f949ee60 	ldr	x0, [x19, #5080]
    8008:	cb010281 	sub	x1, x20, x1
    800c:	eb00403f 	cmp	x1, x0, lsl #16
    8010:	54000302 	b.cs	8070 <f12+0xbc0>  // b.hs, b.nlast
    8014:	d350fc22 	lsr	x2, x1, #16
    8018:	f949fe63 	ldr	x3, [x19, #5112]
    801c:	8b020842 	add	x2, x2, x2, lsl #2
    8020:	d37df042 	lsl	x2, x2, #3
    8024:	8b020060 	add	x0, x3, x2
    8028:	f940101a 	ldr	x26, [x0, #32]
    802c:	b400023a 	cbz	x26, 8070 <f12+0xbc0>
    8030:	38626862 	ldrb	w2, [x3, x2]
    8034:	7100085f 	cmp	w2, #0x2
    8038:	540007e0 	b.eq	8134 <f12+0xc84>  // b.none
    803c:	7100045f 	cmp	w2, #0x1
    8040:	54000181 	b.ne	8070 <f12+0xbc0>  // b.any
    8044:	29430002 	ldp	w2, w0, [x0, #24]
    8048:	92403c21 	and	x1, x1, #0xffff
    804c:	9b027c21 	mul	x1, x1, x2
    8050:	d360fc21 	lsr	x1, x1, #32
    8054:	eb00003f 	cmp	x1, x0
    8058:	540000c2 	b.cs	8070 <f12+0xbc0>  // b.hs, b.nlast
    805c:	8b01035a 	add	x26, x26, x1
    8060:	39400340 	ldrb	w0, [x26]
    8064:	7103fc1f 	cmp	w0, #0xff
    8068:	54000600 	b.eq	8128 <f12+0xc78>  // b.none
    806c:	39000358 	strb	w24, [x26]
    8070:	d100077b 	sub	x27, x27, #0x1
    8074:	b100077f 	cmn	x27, #0x1
    8078:	54fffb81 	b.ne	7fe8 <f12+0xb38>  // b.any
    807c:	14000015 	b	80d0 <f12+0xc20>
    8080:	72003c1f 	tst	w0, #0xffff
    8084:	54fff340 	b.eq	7eec <f12+0xa3c>  // b.none
    8088:	eb1a039f 	cmp	x28, x26
    808c:	54fff3a8 	b.hi	7f00 <f12+0xa50>  // b.pmore
    8090:	d2800014 	mov	x20, #0x0                   	// #0
    8094:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    8098:	aa1903e1 	mov	x1, x25
    809c:	aa1503e0 	mov	x0, x21
    80a0:	f8408422 	ldr	x2, [x1], #8
    80a4:	f9000402 	str	x2, [x0, #8]
    80a8:	aa0003e2 	mov	x2, x0
    80ac:	f9400800 	ldr	x0, [x0, #16]
    80b0:	eb1a003f 	cmp	x1, x26
    80b4:	54ffff61 	b.ne	80a0 <f12+0xbf0>  // b.any
    80b8:	b94013e1 	ldr	w1, [sp, #16]
    80bc:	f9000854 	str	x20, [x2, #16]
    80c0:	aa1503f4 	mov	x20, x21
    80c4:	aa0003f5 	mov	x21, x0
    80c8:	34000041 	cbz	w1, 80d0 <f12+0xc20>
    80cc:	d2800019 	mov	x25, #0x0                   	// #0
    80d0:	aa1903e0 	mov	x0, x25
    80d4:	97fff267 	bl	4a70 <fwp_mem_free>
    80d8:	f94007e0 	ldr	x0, [sp, #8]
    80dc:	97fff9a1 	bl	6760 <fwp_drop4>
    80e0:	aa1503e0 	mov	x0, x21
    80e4:	97fff6bb 	bl	5bd0 <fwp_drop0>
    80e8:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    80ec:	f947f400 	ldr	x0, [x0, #4072]
    80f0:	f9405fe2 	ldr	x2, [sp, #184]
    80f4:	f9400001 	ldr	x1, [x0]
    80f8:	eb010042 	subs	x2, x2, x1
    80fc:	d2800001 	mov	x1, #0x0                   	// #0
    8100:	54001ea1 	b.ne	84d4 <f12+0x1024>  // b.any
    8104:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    8108:	aa1403e0 	mov	x0, x20
    810c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8110:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8114:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8118:	a9506bf9 	ldp	x25, x26, [sp, #256]
    811c:	a95173fb 	ldp	x27, x28, [sp, #272]
    8120:	910483ff 	add	sp, sp, #0x120
    8124:	d65f03c0 	ret
    8128:	aa1a03e0 	mov	x0, x26
    812c:	97fff1b1 	bl	47f0 <fwp_rc_forget_slot>
    8130:	17ffffcf 	b	806c <f12+0xbbc>
    8134:	72003c3f 	tst	w1, #0xffff
    8138:	54fff9c1 	b.ne	8070 <f12+0xbc0>  // b.any
    813c:	17ffffc9 	b	8060 <f12+0xbb0>
    8140:	72003c1f 	tst	w0, #0xffff
    8144:	54ffe480 	b.eq	7dd4 <f12+0x924>  // b.none
    8148:	b4001515 	cbz	x21, 83e8 <f12+0xf38>
    814c:	aa1503f4 	mov	x20, x21
    8150:	d2800016 	mov	x22, #0x0                   	// #0
    8154:	d503201f 	nop
    8158:	f9400a94 	ldr	x20, [x20, #16]
    815c:	aa1603e0 	mov	x0, x22
    8160:	910006d6 	add	x22, x22, #0x1
    8164:	b5ffffb4 	cbnz	x20, 8158 <f12+0xca8>
    8168:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    816c:	eb0102df 	cmp	x22, x1
    8170:	54001a08 	b.hi	84b0 <f12+0x1000>  // b.pmore
    8174:	91000800 	add	x0, x0, #0x2
    8178:	52800041 	mov	w1, #0x2                   	// #2
    817c:	d37df000 	lsl	x0, x0, #3
    8180:	97fff35c 	bl	4ef0 <fwp_heap_alloc>
    8184:	eb16039f 	cmp	x28, x22
    8188:	aa0003f9 	mov	x25, x0
    818c:	9a96939c 	csel	x28, x28, x22, ls	// ls = plast
    8190:	aa1503e1 	mov	x1, x21
    8194:	d503201f 	nop
    8198:	f9400420 	ldr	x0, [x1, #8]
    819c:	f8347b20 	str	x0, [x25, x20, lsl #3]
    81a0:	91000694 	add	x20, x20, #0x1
    81a4:	f9400821 	ldr	x1, [x1, #16]
    81a8:	b5ffff81 	cbnz	x1, 8198 <f12+0xce8>
    81ac:	b400127c 	cbz	x28, 83f8 <f12+0xf48>
    81b0:	f9400343 	ldr	x3, [x26]
    81b4:	b90013ff 	str	wzr, [sp, #16]
    81b8:	17ffff0f 	b	7df4 <f12+0x944>
    81bc:	72003c1f 	tst	w0, #0xffff
    81c0:	54ffd740 	b.eq	7ca8 <f12+0x7f8>  // b.none
    81c4:	d503201f 	nop
    81c8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    81cc:	eb00029f 	cmp	x20, x0
    81d0:	54001968 	b.hi	84fc <f12+0x104c>  // b.pmore
    81d4:	91000680 	add	x0, x20, #0x1
    81d8:	52800021 	mov	w1, #0x1                   	// #1
    81dc:	d37df000 	lsl	x0, x0, #3
    81e0:	97fff344 	bl	4ef0 <fwp_heap_alloc>
    81e4:	91174262 	add	x2, x19, #0x5d0
    81e8:	f9000014 	str	x20, [x0]
    81ec:	aa0003fa 	mov	x26, x0
    81f0:	f90007fa 	str	x26, [sp, #8]
    81f4:	f949d841 	ldr	x1, [x2, #5040]
    81f8:	f949ec40 	ldr	x0, [x2, #5080]
    81fc:	cb010341 	sub	x1, x26, x1
    8200:	eb00403f 	cmp	x1, x0, lsl #16
    8204:	54000322 	b.cs	8268 <f12+0xdb8>  // b.hs, b.nlast
    8208:	d350fc20 	lsr	x0, x1, #16
    820c:	f949fc43 	ldr	x3, [x2, #5112]
    8210:	8b000800 	add	x0, x0, x0, lsl #2
    8214:	d37df002 	lsl	x2, x0, #3
    8218:	8b020060 	add	x0, x3, x2
    821c:	f9401018 	ldr	x24, [x0, #32]
    8220:	b4000258 	cbz	x24, 8268 <f12+0xdb8>
    8224:	38626862 	ldrb	w2, [x3, x2]
    8228:	7100085f 	cmp	w2, #0x2
    822c:	54000ea0 	b.eq	8400 <f12+0xf50>  // b.none
    8230:	7100045f 	cmp	w2, #0x1
    8234:	540001a1 	b.ne	8268 <f12+0xdb8>  // b.any
    8238:	29430002 	ldp	w2, w0, [x0, #24]
    823c:	92403c21 	and	x1, x1, #0xffff
    8240:	9b027c21 	mul	x1, x1, x2
    8244:	d360fc21 	lsr	x1, x1, #32
    8248:	eb00003f 	cmp	x1, x0
    824c:	540000e2 	b.cs	8268 <f12+0xdb8>  // b.hs, b.nlast
    8250:	8b010318 	add	x24, x24, x1
    8254:	39400300 	ldrb	w0, [x24]
    8258:	7103fc1f 	cmp	w0, #0xff
    825c:	540010a0 	b.eq	8470 <f12+0xfc0>  // b.none
    8260:	52800020 	mov	w0, #0x1                   	// #1
    8264:	39000300 	strb	w0, [x24]
    8268:	aa1603e0 	mov	x0, x22
    826c:	17fffe95 	b	7cc0 <f12+0x810>
    8270:	52800041 	mov	w1, #0x2                   	// #2
    8274:	d2800100 	mov	x0, #0x8                   	// #8
    8278:	97fff31e 	bl	4ef0 <fwp_heap_alloc>
    827c:	aa0003f8 	mov	x24, x0
    8280:	91174260 	add	x0, x19, #0x5d0
    8284:	f900031f 	str	xzr, [x24]
    8288:	f949d801 	ldr	x1, [x0, #5040]
    828c:	f949ec00 	ldr	x0, [x0, #5080]
    8290:	cb010301 	sub	x1, x24, x1
    8294:	eb00403f 	cmp	x1, x0, lsl #16
    8298:	54000442 	b.cs	8320 <f12+0xe70>  // b.hs, b.nlast
    829c:	d2800016 	mov	x22, #0x0                   	// #0
    82a0:	17fffd57 	b	77fc <f12+0x34c>
    82a4:	aa1b03e0 	mov	x0, x27
    82a8:	97fff152 	bl	47f0 <fwp_rc_forget_slot>
    82ac:	17ffff26 	b	7f44 <f12+0xa94>
    82b0:	f100039f 	cmp	x28, #0x0
    82b4:	fa401b40 	ccmp	x26, #0x0, #0x0, ne	// ne = any
    82b8:	54ffbde1 	b.ne	7a74 <f12+0x5c4>  // b.any
    82bc:	f94007e0 	ldr	x0, [sp, #8]
    82c0:	9101c294 	add	x20, x20, #0x70
    82c4:	f9402fe1 	ldr	x1, [sp, #88]
    82c8:	f9018a81 	str	x1, [x20, #784]
    82cc:	97fff02d 	bl	4380 <fwp_tape_buffers_release>
    82d0:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    82d4:	f947e863 	ldr	x3, [x3, #4048]
    82d8:	d2800262 	mov	x2, #0x13                  	// #19
    82dc:	d2800021 	mov	x1, #0x1                   	// #1
    82e0:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    82e4:	9110e000 	add	x0, x0, #0x438
    82e8:	f9400063 	ldr	x3, [x3]
    82ec:	97ffe9a5 	bl	2980 <fwrite@plt>
    82f0:	d2800000 	mov	x0, #0x0                   	// #0
    82f4:	97ffe9af 	bl	29b0 <fflush@plt>
    82f8:	52800cc0 	mov	w0, #0x66                  	// #102
    82fc:	97ffe9bd 	bl	29f0 <_Exit@plt>
    8300:	eb01033f 	cmp	x25, x1
    8304:	54ff99c0 	b.eq	763c <f12+0x18c>  // b.none
    8308:	aa0103f9 	mov	x25, x1
    830c:	9100043b 	add	x27, x1, #0x1
    8310:	f9403a9a 	ldr	x26, [x20, #112]
    8314:	d37ff821 	lsl	x1, x1, #1
    8318:	17fffce7 	b	76b4 <f12+0x204>
    831c:	b5ffaa56 	cbnz	x22, 7864 <f12+0x3b4>
    8320:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8324:	f900031f 	str	xzr, [x24]
    8328:	17fffd83 	b	7934 <f12+0x484>
    832c:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0x20>
    8330:	91044000 	add	x0, x0, #0x110
    8334:	94001433 	bl	d400 <atexit>
    8338:	35fffcc0 	cbnz	w0, 82d0 <f12+0xe20>
    833c:	52800020 	mov	w0, #0x1                   	// #1
    8340:	b9034700 	str	w0, [x24, #836]
    8344:	17fffcaa 	b	75ec <f12+0x13c>
    8348:	72003c3f 	tst	w1, #0xffff
    834c:	54ffa8a1 	b.ne	7860 <f12+0x3b0>  // b.any
    8350:	17fffd3f 	b	784c <f12+0x39c>
    8354:	72003c3f 	tst	w1, #0xffff
    8358:	54ff91c0 	b.eq	7590 <f12+0xe0>  // b.none
    835c:	aa1703e0 	mov	x0, x23
    8360:	97fff6cc 	bl	5e90 <fwp_closure_drop>
    8364:	b5ff9295 	cbnz	x21, 75b4 <f12+0x104>
    8368:	52800000 	mov	w0, #0x0                   	// #0
    836c:	d2800017 	mov	x23, #0x0                   	// #0
    8370:	97ffeca0 	bl	35f0 <descent_phase_step>
    8374:	17fffc9b 	b	75e0 <f12+0x130>
    8378:	aa1b03fc 	mov	x28, x27
    837c:	17fffda8 	b	7a1c <f12+0x56c>
    8380:	72003c3f 	tst	w1, #0xffff
    8384:	54ffc4a1 	b.ne	7c18 <f12+0x768>  // b.any
    8388:	17fffe1f 	b	7c04 <f12+0x754>
    838c:	3cc98002 	ldur	q2, [x0, #152]
    8390:	91026001 	add	x1, x0, #0x98
    8394:	3cca8001 	ldur	q1, [x0, #168]
    8398:	f900681f 	str	xzr, [x0, #208]
    839c:	4f000400 	movi	v0.4s, #0x0
    83a0:	ad010702 	stp	q2, q1, [x24, #32]
    83a4:	a94b8002 	ldp	x2, x0, [x0, #184]
    83a8:	f9000f00 	str	x0, [x24, #24]
    83ac:	f9401820 	ldr	x0, [x1, #48]
    83b0:	f9002302 	str	x2, [x24, #64]
    83b4:	f9002700 	str	x0, [x24, #72]
    83b8:	ad000020 	stp	q0, q0, [x1]
    83bc:	3d800820 	str	q0, [x1, #32]
    83c0:	f900183f 	str	xzr, [x1, #48]
    83c4:	17fffcca 	b	76ec <f12+0x23c>
    83c8:	d37ffb38 	lsl	x24, x25, #1
    83cc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    83d0:	eb00031f 	cmp	x24, x0
    83d4:	9a80d318 	csel	x24, x24, x0, le
    83d8:	8b180701 	add	x1, x24, x24, lsl #1
    83dc:	8b010b01 	add	x1, x24, x1, lsl #2
    83e0:	d37df021 	lsl	x1, x1, #3
    83e4:	17fffca1 	b	7668 <f12+0x1b8>
    83e8:	52800041 	mov	w1, #0x2                   	// #2
    83ec:	d2800100 	mov	x0, #0x8                   	// #8
    83f0:	97fff2c0 	bl	4ef0 <fwp_heap_alloc>
    83f4:	aa0003f9 	mov	x25, x0
    83f8:	d2800014 	mov	x20, #0x0                   	// #0
    83fc:	17ffff35 	b	80d0 <f12+0xc20>
    8400:	72003c3f 	tst	w1, #0xffff
    8404:	54fff280 	b.eq	8254 <f12+0xda4>  // b.none
    8408:	aa1603e0 	mov	x0, x22
    840c:	17fffe2d 	b	7cc0 <f12+0x810>
    8410:	aa0203e0 	mov	x0, x2
    8414:	d2800101 	mov	x1, #0x8                   	// #8
    8418:	f90013e2 	str	x2, [sp, #32]
    841c:	97ffe911 	bl	2860 <calloc@plt>
    8420:	a94213e2 	ldp	x2, x4, [sp, #32]
    8424:	aa0003fa 	mov	x26, x0
    8428:	17fffd90 	b	7a68 <f12+0x5b8>
    842c:	f9400343 	ldr	x3, [x26]
    8430:	b7fffdc3 	tbnz	x3, #63, 83e8 <f12+0xf38>
    8434:	91174261 	add	x1, x19, #0x5d0
    8438:	f94007e4 	ldr	x4, [sp, #8]
    843c:	f949d820 	ldr	x0, [x1, #5040]
    8440:	f949ec21 	ldr	x1, [x1, #5080]
    8444:	cb000080 	sub	x0, x4, x0
    8448:	eb01401f 	cmp	x0, x1, lsl #16
    844c:	54fffce2 	b.cs	83e8 <f12+0xf38>  // b.hs, b.nlast
    8450:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    8454:	17fffe4c 	b	7d84 <f12+0x8d4>
    8458:	aa1903e0 	mov	x0, x25
    845c:	97fff0e5 	bl	47f0 <fwp_rc_forget_slot>
    8460:	17fffcfe 	b	7858 <f12+0x3a8>
    8464:	aa1703e0 	mov	x0, x23
    8468:	97fff0e2 	bl	47f0 <fwp_rc_forget_slot>
    846c:	17fffde9 	b	7c10 <f12+0x760>
    8470:	aa1803e0 	mov	x0, x24
    8474:	97fff0df 	bl	47f0 <fwp_rc_forget_slot>
    8478:	17ffff7a 	b	8260 <f12+0xdb0>
    847c:	97fff096 	bl	46d4 <fwp_rc_wide_dup>
    8480:	17fffc4a 	b	75a8 <f12+0xf8>
    8484:	d280001a 	mov	x26, #0x0                   	// #0
    8488:	17fffe9e 	b	7f00 <f12+0xa50>
    848c:	d2800019 	mov	x25, #0x0                   	// #0
    8490:	d2800014 	mov	x20, #0x0                   	// #0
    8494:	17ffff0f 	b	80d0 <f12+0xc20>
    8498:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    849c:	9121c000 	add	x0, x0, #0x870
    84a0:	97ffecd8 	bl	3800 <fwp_trap>
    84a4:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    84a8:	911f6000 	add	x0, x0, #0x7d8
    84ac:	97ffecd5 	bl	3800 <fwp_trap>
    84b0:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    84b4:	91234000 	add	x0, x0, #0x8d0
    84b8:	97ffecd2 	bl	3800 <fwp_trap>
    84bc:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    84c0:	9125c000 	add	x0, x0, #0x970
    84c4:	97ffeccf 	bl	3800 <fwp_trap>
    84c8:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    84cc:	9124c000 	add	x0, x0, #0x930
    84d0:	97ffeccc 	bl	3800 <fwp_trap>
    84d4:	97ffe8eb 	bl	2880 <__stack_chk_fail@plt>
    84d8:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    84dc:	91208000 	add	x0, x0, #0x820
    84e0:	97ffecc8 	bl	3800 <fwp_trap>
    84e4:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    84e8:	91238000 	add	x0, x0, #0x8e0
    84ec:	97ffecc5 	bl	3800 <fwp_trap>
    84f0:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    84f4:	91240000 	add	x0, x0, #0x900
    84f8:	97ffecc2 	bl	3800 <fwp_trap>
    84fc:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    8500:	91258000 	add	x0, x0, #0x960
    8504:	97ffecbf 	bl	3800 <fwp_trap>
    8508:	97ffe8f2 	bl	28d0 <abort@plt>
    850c:	97ffe95d 	bl	2a80 <fwp_trap_overflow.constprop.0>

0000000000008510 <fwp_owned_entry12>:
    8510:	f9400000 	ldr	x0, [x0]
    8514:	17fffbe7 	b	74b0 <f12>
    8518:	d503201f 	nop
    851c:	d503201f 	nop

0000000000008520 <e12>:
    8520:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8524:	910003fd 	mov	x29, sp
    8528:	f9000bf3 	str	x19, [sp, #16]
    852c:	f9400013 	ldr	x19, [x0]
    8530:	aa1303e0 	mov	x0, x19
    8534:	97fff47b 	bl	5720 <fwp_rc_share>
    8538:	aa1303e0 	mov	x0, x19
    853c:	97fffbdd 	bl	74b0 <f12>
    8540:	aa0003f3 	mov	x19, x0
    8544:	97fff477 	bl	5720 <fwp_rc_share>
    8548:	aa1303e0 	mov	x0, x19
    854c:	f9400bf3 	ldr	x19, [sp, #16]
    8550:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8554:	d65f03c0 	ret
    8558:	d503201f 	nop
    855c:	d503201f 	nop

0000000000008560 <fwp_write>:
    8560:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8564:	910003fd 	mov	x29, sp
    8568:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    856c:	f947f484 	ldr	x4, [x4, #4072]
    8570:	a90153f3 	stp	x19, x20, [sp, #16]
    8574:	d10943ff 	sub	sp, sp, #0x250
    8578:	b9400045 	ldr	w5, [x2]
    857c:	aa0003f4 	mov	x20, x0
    8580:	f9400080 	ldr	x0, [x4]
    8584:	f90127e0 	str	x0, [sp, #584]
    8588:	d2800000 	mov	x0, #0x0                   	// #0
    858c:	710064bf 	cmp	w5, #0x19
    8590:	54000408 	b.hi	8610 <fwp_write+0xb0>  // b.pmore
    8594:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0xbd0>
    8598:	aa0103f3 	mov	x19, x1
    859c:	91060000 	add	x0, x0, #0x180
    85a0:	f9013bf5 	str	x21, [sp, #624]
    85a4:	f9013ff6 	str	x22, [sp, #632]
    85a8:	f90153fb 	str	x27, [sp, #672]
    85ac:	f90157fc 	str	x28, [sp, #680]
    85b0:	aa0203fc 	mov	x28, x2
    85b4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    85b8:	10000061 	adr	x1, 85c4 <fwp_write+0x64>
    85bc:	8b20a820 	add	x0, x1, w0, sxth #2
    85c0:	d61f0000 	br	x0
    85c4:	910123e0 	add	x0, sp, #0x48
    85c8:	aa1303e5 	mov	x5, x19
    85cc:	b0000024 	adrp	x4, d000 <__divti3+0x2f0>
    85d0:	aa0003f3 	mov	x19, x0
    85d4:	91274084 	add	x4, x4, #0x9d0
    85d8:	d2804003 	mov	x3, #0x200                 	// #512
    85dc:	aa0303e1 	mov	x1, x3
    85e0:	52800042 	mov	w2, #0x2                   	// #2
    85e4:	97ffe883 	bl	27f0 <__snprintf_chk@plt>
    85e8:	aa1303e0 	mov	x0, x19
    85ec:	97ffe849 	bl	2710 <strlen@plt>
    85f0:	aa1303e1 	mov	x1, x19
    85f4:	aa0003e2 	mov	x2, x0
    85f8:	aa1403e0 	mov	x0, x20
    85fc:	97ffebe5 	bl	3590 <buf_put>
    8600:	f9413bf5 	ldr	x21, [sp, #624]
    8604:	f9413ff6 	ldr	x22, [sp, #632]
    8608:	f94153fb 	ldr	x27, [sp, #672]
    860c:	f94157fc 	ldr	x28, [sp, #680]
    8610:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8614:	f947f400 	ldr	x0, [x0, #4072]
    8618:	f94127e2 	ldr	x2, [sp, #584]
    861c:	f9400001 	ldr	x1, [x0]
    8620:	eb010042 	subs	x2, x2, x1
    8624:	d2800001 	mov	x1, #0x0                   	// #0
    8628:	540077c1 	b.ne	9520 <fwp_write+0xfc0>  // b.any
    862c:	910943ff 	add	sp, sp, #0x250
    8630:	a94153f3 	ldp	x19, x20, [sp, #16]
    8634:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8638:	d65f03c0 	ret
    863c:	910123e0 	add	x0, sp, #0x48
    8640:	aa1303e5 	mov	x5, x19
    8644:	b0000024 	adrp	x4, d000 <__divti3+0x2f0>
    8648:	aa0003f3 	mov	x19, x0
    864c:	91272084 	add	x4, x4, #0x9c8
    8650:	d2804003 	mov	x3, #0x200                 	// #512
    8654:	17ffffe2 	b	85dc <fwp_write+0x7c>
    8658:	71004cbf 	cmp	w5, #0x13
    865c:	b0000020 	adrp	x0, d000 <__divti3+0x2f0>
    8660:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    8664:	9126e000 	add	x0, x0, #0x9b8
    8668:	91270021 	add	x1, x1, #0x9c0
    866c:	d2800082 	mov	x2, #0x4                   	// #4
    8670:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8674:	aa1403e0 	mov	x0, x20
    8678:	f90143f7 	str	x23, [sp, #640]
    867c:	d2800016 	mov	x22, #0x0                   	// #0
    8680:	f90147f8 	str	x24, [sp, #648]
    8684:	97ffebc3 	bl	3590 <buf_put>
    8688:	f9400260 	ldr	x0, [x19]
    868c:	b0000037 	adrp	x23, d000 <__divti3+0x2f0>
    8690:	d2800015 	mov	x21, #0x0                   	// #0
    8694:	912902f7 	add	x23, x23, #0xa40
    8698:	b40047a0 	cbz	x0, 8f8c <fwp_write+0xa2c>
    869c:	b9400380 	ldr	w0, [x28]
    86a0:	52800003 	mov	w3, #0x0                   	// #0
    86a4:	f9401f82 	ldr	x2, [x28, #56]
    86a8:	71004c1f 	cmp	w0, #0x13
    86ac:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    86b0:	aa1403e0 	mov	x0, x20
    86b4:	8b010e61 	add	x1, x19, x1, lsl #3
    86b8:	f9400421 	ldr	x1, [x1, #8]
    86bc:	97ffffa9 	bl	8560 <fwp_write>
    86c0:	b9400380 	ldr	w0, [x28]
    86c4:	7100481f 	cmp	w0, #0x12
    86c8:	54004b40 	b.eq	9030 <fwp_write+0xad0>  // b.none
    86cc:	f9400260 	ldr	x0, [x19]
    86d0:	910006b5 	add	x21, x21, #0x1
    86d4:	91000ad6 	add	x22, x22, #0x2
    86d8:	eb15001f 	cmp	x0, x21
    86dc:	54004589 	b.ls	8f8c <fwp_write+0xa2c>  // b.plast
    86e0:	aa1703e1 	mov	x1, x23
    86e4:	aa1403e0 	mov	x0, x20
    86e8:	d2800042 	mov	x2, #0x2                   	// #2
    86ec:	97ffeba9 	bl	3590 <buf_put>
    86f0:	17ffffeb 	b	869c <fwp_write+0x13c>
    86f4:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    86f8:	9127e021 	add	x1, x1, #0x9f8
    86fc:	d28000c2 	mov	x2, #0x6                   	// #6
    8700:	aa1403e0 	mov	x0, x20
    8704:	91004273 	add	x19, x19, #0x10
    8708:	97ffeba2 	bl	3590 <buf_put>
    870c:	aa1303e0 	mov	x0, x19
    8710:	97ffe800 	bl	2710 <strlen@plt>
    8714:	aa1303e1 	mov	x1, x19
    8718:	aa0003e2 	mov	x2, x0
    871c:	aa1403e0 	mov	x0, x20
    8720:	97ffeb9c 	bl	3590 <buf_put>
    8724:	528007c3 	mov	w3, #0x3e                  	// #62
    8728:	aa1403e0 	mov	x0, x20
    872c:	91001fe1 	add	x1, sp, #0x7
    8730:	d2800022 	mov	x2, #0x1                   	// #1
    8734:	39001fe3 	strb	w3, [sp, #7]
    8738:	17ffffb1 	b	85fc <fwp_write+0x9c>
    873c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8740:	f947f400 	ldr	x0, [x0, #4072]
    8744:	f94127e2 	ldr	x2, [sp, #584]
    8748:	f9400001 	ldr	x1, [x0]
    874c:	eb010042 	subs	x2, x2, x1
    8750:	d2800001 	mov	x1, #0x0                   	// #0
    8754:	540034e1 	b.ne	8df0 <fwp_write+0x890>  // b.any
    8758:	f9413bf5 	ldr	x21, [sp, #624]
    875c:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    8760:	f9413ff6 	ldr	x22, [sp, #632]
    8764:	aa1403e0 	mov	x0, x20
    8768:	91276021 	add	x1, x1, #0x9d8
    876c:	d2800142 	mov	x2, #0xa                   	// #10
    8770:	f94153fb 	ldr	x27, [sp, #672]
    8774:	f94157fc 	ldr	x28, [sp, #680]
    8778:	910943ff 	add	sp, sp, #0x250
    877c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8780:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8784:	17ffeb83 	b	3590 <buf_put>
    8788:	f9400456 	ldr	x22, [x2, #8]
    878c:	f90143f7 	str	x23, [sp, #640]
    8790:	f90147f8 	str	x24, [sp, #648]
    8794:	b4005b16 	cbz	x22, 92f4 <fwp_write+0xd94>
    8798:	aa1603e0 	mov	x0, x22
    879c:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    87a0:	91296021 	add	x1, x1, #0xa58
    87a4:	97ffe857 	bl	2900 <strcmp@plt>
    87a8:	2a0003f5 	mov	w21, w0
    87ac:	34005fe0 	cbz	w0, 93a8 <fwp_write+0xe48>
    87b0:	aa1603e0 	mov	x0, x22
    87b4:	97ffe7d7 	bl	2710 <strlen@plt>
    87b8:	aa1603e1 	mov	x1, x22
    87bc:	aa0003e2 	mov	x2, x0
    87c0:	aa1403e0 	mov	x0, x20
    87c4:	97ffeb73 	bl	3590 <buf_put>
    87c8:	52800403 	mov	w3, #0x20                  	// #32
    87cc:	91001ff5 	add	x21, sp, #0x7
    87d0:	aa1503e1 	mov	x1, x21
    87d4:	aa1403e0 	mov	x0, x20
    87d8:	d2800022 	mov	x2, #0x1                   	// #1
    87dc:	39001fe3 	strb	w3, [sp, #7]
    87e0:	97ffeb6c 	bl	3590 <buf_put>
    87e4:	52800f63 	mov	w3, #0x7b                  	// #123
    87e8:	aa1403e0 	mov	x0, x20
    87ec:	aa1503e1 	mov	x1, x21
    87f0:	d2800022 	mov	x2, #0x1                   	// #1
    87f4:	39001fe3 	strb	w3, [sp, #7]
    87f8:	97ffeb66 	bl	3590 <buf_put>
    87fc:	b9401380 	ldr	w0, [x28, #16]
    8800:	52800018 	mov	w24, #0x0                   	// #0
    8804:	7100001f 	cmp	w0, #0x0
    8808:	54003aad 	b.le	8f5c <fwp_write+0x9fc>
    880c:	f9014bf9 	str	x25, [sp, #656]
    8810:	b0000039 	adrp	x25, d000 <__divti3+0x2f0>
    8814:	912a0339 	add	x25, x25, #0xa80
    8818:	f9014ffa 	str	x26, [sp, #664]
    881c:	b000003a 	adrp	x26, d000 <__divti3+0x2f0>
    8820:	9129035a 	add	x26, x26, #0xa40
    8824:	91002276 	add	x22, x19, #0x8
    8828:	d2800013 	mov	x19, #0x0                   	// #0
    882c:	b5003e93 	cbnz	x19, 8ffc <fwp_write+0xa9c>
    8830:	d37df277 	lsl	x23, x19, #3
    8834:	34003cb8 	cbz	w24, 8fc8 <fwp_write+0xa68>
    8838:	f9401382 	ldr	x2, [x28, #32]
    883c:	aa1403e0 	mov	x0, x20
    8840:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8844:	52800003 	mov	w3, #0x0                   	// #0
    8848:	f8776842 	ldr	x2, [x2, x23]
    884c:	91000673 	add	x19, x19, #0x1
    8850:	97ffff44 	bl	8560 <fwp_write>
    8854:	b9401380 	ldr	w0, [x28, #16]
    8858:	6b13001f 	cmp	w0, w19
    885c:	54fffe8c 	b.gt	882c <fwp_write+0x2cc>
    8860:	f9414bf9 	ldr	x25, [sp, #656]
    8864:	f9414ffa 	ldr	x26, [sp, #664]
    8868:	340037b8 	cbz	w24, 8f5c <fwp_write+0x9fc>
    886c:	52800523 	mov	w3, #0x29                  	// #41
    8870:	aa1503e1 	mov	x1, x21
    8874:	aa1403e0 	mov	x0, x20
    8878:	d2800022 	mov	x2, #0x1                   	// #1
    887c:	39001fe3 	strb	w3, [sp, #7]
    8880:	97ffeb44 	bl	3590 <buf_put>
    8884:	f9413bf5 	ldr	x21, [sp, #624]
    8888:	f9413ff6 	ldr	x22, [sp, #632]
    888c:	f94143f7 	ldr	x23, [sp, #640]
    8890:	f94147f8 	ldr	x24, [sp, #648]
    8894:	f94153fb 	ldr	x27, [sp, #672]
    8898:	f94157fc 	ldr	x28, [sp, #680]
    889c:	17ffff5d 	b	8610 <fwp_write+0xb0>
    88a0:	b9404855 	ldr	w21, [x2, #72]
    88a4:	aa1403e0 	mov	x0, x20
    88a8:	93407eb6 	sxtw	x22, w21
    88ac:	91000ac1 	add	x1, x22, #0x2
    88b0:	97ffeb05 	bl	34c4 <buf_grow>
    88b4:	a9400281 	ldp	x1, x0, [x20]
    88b8:	528e8603 	mov	w3, #0x7430                	// #29744
    88bc:	78206823 	strh	w3, [x1, x0]
    88c0:	8b000022 	add	x2, x1, x0
    88c4:	710002bf 	cmp	w21, #0x0
    88c8:	540036cd 	b.le	8fa0 <fwp_write+0xa40>
    88cc:	110006a3 	add	w3, w21, #0x1
    88d0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    88d4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    88d8:	91000449 	add	x9, x2, #0x1
    88dc:	8b23c043 	add	x3, x2, w3, sxtw
    88e0:	f28aaac6 	movk	x6, #0x5556
    88e4:	f2955568 	movk	x8, #0xaaab
    88e8:	1400000d 	b	891c <fwp_write+0x3bc>
    88ec:	d2800021 	mov	x1, #0x1                   	// #1
    88f0:	528005a5 	mov	w5, #0x2d                  	// #45
    88f4:	f100001f 	cmp	x0, #0x0
    88f8:	9b467e60 	smulh	x0, x19, x6
    88fc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8900:	381ff465 	strb	w5, [x3], #-1
    8904:	cb040000 	sub	x0, x0, x4
    8908:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    890c:	cb020000 	sub	x0, x0, x2
    8910:	8b010013 	add	x19, x0, x1
    8914:	eb03013f 	cmp	x9, x3
    8918:	54003440 	b.eq	8fa0 <fwp_write+0xa40>  // b.none
    891c:	9b467e60 	smulh	x0, x19, x6
    8920:	937ffe64 	asr	x4, x19, #63
    8924:	52800605 	mov	w5, #0x30                  	// #48
    8928:	cb040000 	sub	x0, x0, x4
    892c:	8b000400 	add	x0, x0, x0, lsl #1
    8930:	cb000260 	sub	x0, x19, x0
    8934:	91000c01 	add	x1, x0, #0x3
    8938:	9bc87c22 	umulh	x2, x1, x8
    893c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8940:	8b4204e2 	add	x2, x7, x2, lsr #1
    8944:	eb020021 	subs	x1, x1, x2
    8948:	54fffd60 	b.eq	88f4 <fwp_write+0x394>  // b.none
    894c:	f100043f 	cmp	x1, #0x1
    8950:	54fffce1 	b.ne	88ec <fwp_write+0x38c>  // b.any
    8954:	d2800001 	mov	x1, #0x0                   	// #0
    8958:	52800565 	mov	w5, #0x2b                  	// #43
    895c:	17ffffe6 	b	88f4 <fwp_write+0x394>
    8960:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8964:	f947f400 	ldr	x0, [x0, #4072]
    8968:	f94127e2 	ldr	x2, [sp, #584]
    896c:	f9400001 	ldr	x1, [x0]
    8970:	eb010042 	subs	x2, x2, x1
    8974:	d2800001 	mov	x1, #0x0                   	// #0
    8978:	540023c1 	b.ne	8df0 <fwp_write+0x890>  // b.any
    897c:	f9413bf5 	ldr	x21, [sp, #624]
    8980:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    8984:	f9413ff6 	ldr	x22, [sp, #632]
    8988:	aa1403e0 	mov	x0, x20
    898c:	9127a021 	add	x1, x1, #0x9e8
    8990:	d2800102 	mov	x2, #0x8                   	// #8
    8994:	17ffff77 	b	8770 <fwp_write+0x210>
    8998:	aa1403e0 	mov	x0, x20
    899c:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    89a0:	d28000c2 	mov	x2, #0x6                   	// #6
    89a4:	91292021 	add	x1, x1, #0xa48
    89a8:	97ffeafa 	bl	3590 <buf_put>
    89ac:	d2800015 	mov	x21, #0x0                   	// #0
    89b0:	f9400263 	ldr	x3, [x19]
    89b4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    89b8:	54002c60 	b.eq	8f44 <fwp_write+0x9e4>  // b.none
    89bc:	f9401f82 	ldr	x2, [x28, #56]
    89c0:	f90143f7 	str	x23, [sp, #640]
    89c4:	f90147f8 	str	x24, [sp, #648]
    89c8:	d2800857 	mov	x23, #0x42                  	// #66
    89cc:	f9014bf9 	str	x25, [sp, #656]
    89d0:	b0000036 	adrp	x22, d000 <__divti3+0x2f0>
    89d4:	f9014ffa 	str	x26, [sp, #664]
    89d8:	912902d6 	add	x22, x22, #0xa40
    89dc:	d2800038 	mov	x24, #0x1                   	// #1
    89e0:	f2a18017 	movk	x23, #0xc00, lsl #16
    89e4:	d2809099 	mov	x25, #0x484                 	// #1156
    89e8:	b40004a2 	cbz	x2, 8a7c <fwp_write+0x51c>
    89ec:	b9400040 	ldr	w0, [x2]
    89f0:	7100701f 	cmp	w0, #0x1c
    89f4:	540042c0 	b.eq	924c <fwp_write+0xcec>  // b.none
    89f8:	71006c1f 	cmp	w0, #0x1b
    89fc:	54000408 	b.hi	8a7c <fwp_write+0x51c>  // b.pmore
    8a00:	9ac02301 	lsl	x1, x24, x0
    8a04:	ea17003f 	tst	x1, x23
    8a08:	540036a1 	b.ne	90dc <fwp_write+0xb7c>  // b.any
    8a0c:	ea19003f 	tst	x1, x25
    8a10:	54003521 	b.ne	90b4 <fwp_write+0xb54>  // b.any
    8a14:	d2800424 	mov	x4, #0x21                  	// #33
    8a18:	ea04003f 	tst	x1, x4
    8a1c:	54000300 	b.eq	8a7c <fwp_write+0x51c>  // b.none
    8a20:	b7f849c3 	tbnz	x3, #63, 9358 <fwp_write+0xdf8>
    8a24:	91002261 	add	x1, x19, #0x8
    8a28:	8b150021 	add	x1, x1, x21
    8a2c:	39400021 	ldrb	w1, [x1]
    8a30:	7100001f 	cmp	w0, #0x0
    8a34:	93401c23 	sxtb	x3, w1
    8a38:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8a3c:	d503201f 	nop
    8a40:	aa1403e0 	mov	x0, x20
    8a44:	52800003 	mov	w3, #0x0                   	// #0
    8a48:	97fffec6 	bl	8560 <fwp_write>
    8a4c:	910006b5 	add	x21, x21, #0x1
    8a50:	f9400260 	ldr	x0, [x19]
    8a54:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8a58:	eb0002bf 	cmp	x21, x0
    8a5c:	540026c2 	b.cs	8f34 <fwp_write+0x9d4>  // b.hs, b.nlast
    8a60:	d2800042 	mov	x2, #0x2                   	// #2
    8a64:	aa1603e1 	mov	x1, x22
    8a68:	aa1403e0 	mov	x0, x20
    8a6c:	97ffeac9 	bl	3590 <buf_put>
    8a70:	f9401f82 	ldr	x2, [x28, #56]
    8a74:	f9400263 	ldr	x3, [x19]
    8a78:	b5fffba2 	cbnz	x2, 89ec <fwp_write+0x48c>
    8a7c:	d37df2a0 	lsl	x0, x21, #3
    8a80:	b7f83f03 	tbnz	x3, #63, 9260 <fwp_write+0xd00>
    8a84:	91002261 	add	x1, x19, #0x8
    8a88:	8b000020 	add	x0, x1, x0
    8a8c:	f9400001 	ldr	x1, [x0]
    8a90:	17ffffec 	b	8a40 <fwp_write+0x4e0>
    8a94:	a9400e62 	ldp	x2, x3, [x19]
    8a98:	b7f83ca3 	tbnz	x3, #63, 922c <fwp_write+0xccc>
    8a9c:	910123f5 	add	x21, sp, #0x48
    8aa0:	aa1503e0 	mov	x0, x21
    8aa4:	97ffe8df 	bl	2e20 <fwp_fmt_u128>
    8aa8:	aa1503e0 	mov	x0, x21
    8aac:	97ffe719 	bl	2710 <strlen@plt>
    8ab0:	aa1503e1 	mov	x1, x21
    8ab4:	aa0003e2 	mov	x2, x0
    8ab8:	17fffed0 	b	85f8 <fwp_write+0x98>
    8abc:	fd015be8 	str	d8, [sp, #688]
    8ac0:	1e270268 	fmov	s8, w19
    8ac4:	fd015fe9 	str	d9, [sp, #696]
    8ac8:	1e282100 	fcmp	s8, s8
    8acc:	54004d26 	b.vs	9470 <fwp_write+0xf10>
    8ad0:	1e20c101 	fabs	s1, s8
    8ad4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8ad8:	1e270000 	fmov	s0, w0
    8adc:	1e202020 	fcmp	s1, s0
    8ae0:	54002c0d 	b.le	9060 <fwp_write+0xb00>
    8ae4:	1e202118 	fcmpe	s8, #0.0
    8ae8:	b0000022 	adrp	x2, d000 <__divti3+0x2f0>
    8aec:	91142042 	add	x2, x2, #0x508
    8af0:	910123f5 	add	x21, sp, #0x48
    8af4:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    8af8:	91266021 	add	x1, x1, #0x998
    8afc:	aa1503e0 	mov	x0, x21
    8b00:	9a81c041 	csel	x1, x2, x1, gt
    8b04:	97ffe7af 	bl	29c0 <strcpy@plt>
    8b08:	aa1503e0 	mov	x0, x21
    8b0c:	97ffe701 	bl	2710 <strlen@plt>
    8b10:	aa1503e1 	mov	x1, x21
    8b14:	aa0003e2 	mov	x2, x0
    8b18:	aa1403e0 	mov	x0, x20
    8b1c:	97ffea9d 	bl	3590 <buf_put>
    8b20:	f9413bf5 	ldr	x21, [sp, #624]
    8b24:	f9413ff6 	ldr	x22, [sp, #632]
    8b28:	f94153fb 	ldr	x27, [sp, #672]
    8b2c:	f94157fc 	ldr	x28, [sp, #680]
    8b30:	fd415be8 	ldr	d8, [sp, #688]
    8b34:	fd415fe9 	ldr	d9, [sp, #696]
    8b38:	17fffeb6 	b	8610 <fwp_write+0xb0>
    8b3c:	f9400276 	ldr	x22, [x19]
    8b40:	34002e03 	cbz	w3, 9100 <fwp_write+0xba0>
    8b44:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8b48:	f947f400 	ldr	x0, [x0, #4072]
    8b4c:	f94127e2 	ldr	x2, [sp, #584]
    8b50:	f9400001 	ldr	x1, [x0]
    8b54:	eb010042 	subs	x2, x2, x1
    8b58:	d2800001 	mov	x1, #0x0                   	// #0
    8b5c:	540014a1 	b.ne	8df0 <fwp_write+0x890>  // b.any
    8b60:	aa1603e2 	mov	x2, x22
    8b64:	91002261 	add	x1, x19, #0x8
    8b68:	f9413bf5 	ldr	x21, [sp, #624]
    8b6c:	aa1403e0 	mov	x0, x20
    8b70:	f9413ff6 	ldr	x22, [sp, #632]
    8b74:	17fffeff 	b	8770 <fwp_write+0x210>
    8b78:	fd015be8 	str	d8, [sp, #688]
    8b7c:	9e670268 	fmov	d8, x19
    8b80:	fd015fe9 	str	d9, [sp, #696]
    8b84:	1e682100 	fcmp	d8, d8
    8b88:	54004746 	b.vs	9470 <fwp_write+0xf10>
    8b8c:	1e60c101 	fabs	d1, d8
    8b90:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8b94:	9e670000 	fmov	d0, x0
    8b98:	910123f5 	add	x21, sp, #0x48
    8b9c:	52800033 	mov	w19, #0x1                   	// #1
    8ba0:	1e602020 	fcmp	d1, d0
    8ba4:	540001ad 	b.le	8bd8 <fwp_write+0x678>
    8ba8:	1e602118 	fcmpe	d8, #0.0
    8bac:	b0000022 	adrp	x2, d000 <__divti3+0x2f0>
    8bb0:	91142042 	add	x2, x2, #0x508
    8bb4:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    8bb8:	91266021 	add	x1, x1, #0x998
    8bbc:	aa1503e0 	mov	x0, x21
    8bc0:	9a81c041 	csel	x1, x2, x1, gt
    8bc4:	97ffe77f 	bl	29c0 <strcpy@plt>
    8bc8:	17ffffd0 	b	8b08 <fwp_write+0x5a8>
    8bcc:	11000673 	add	w19, w19, #0x1
    8bd0:	71004a7f 	cmp	w19, #0x12
    8bd4:	54003860 	b.eq	92e0 <fwp_write+0xd80>  // b.none
    8bd8:	1e604100 	fmov	d0, d8
    8bdc:	2a1303e1 	mov	w1, w19
    8be0:	aa1503e0 	mov	x0, x21
    8be4:	97ffebec 	bl	3b94 <fwp_format_g.constprop.0>
    8be8:	aa1503e0 	mov	x0, x21
    8bec:	d2800001 	mov	x1, #0x0                   	// #0
    8bf0:	97ffe6dc 	bl	2760 <strtod@plt>
    8bf4:	1e602100 	fcmp	d8, d0
    8bf8:	54fffea1 	b.ne	8bcc <fwp_write+0x66c>  // b.any
    8bfc:	aa1503e0 	mov	x0, x21
    8c00:	97ffeadd 	bl	3774 <fwp_finish_float>
    8c04:	17ffffc1 	b	8b08 <fwp_write+0x5a8>
    8c08:	a9400e62 	ldp	x2, x3, [x19]
    8c0c:	910123f3 	add	x19, sp, #0x48
    8c10:	aa1303e0 	mov	x0, x19
    8c14:	97ffe883 	bl	2e20 <fwp_fmt_u128>
    8c18:	17fffe74 	b	85e8 <fwp_write+0x88>
    8c1c:	f90143f7 	str	x23, [sp, #640]
    8c20:	f90147f8 	str	x24, [sp, #648]
    8c24:	2a1303f8 	mov	w24, w19
    8c28:	f9014bf9 	str	x25, [sp, #656]
    8c2c:	f9014ffa 	str	x26, [sp, #664]
    8c30:	f13ffe7f 	cmp	x19, #0xfff
    8c34:	54000049 	b.ls	8c3c <fwp_write+0x6dc>  // b.plast
    8c38:	b9400278 	ldr	w24, [x19]
    8c3c:	f9400f80 	ldr	x0, [x28, #24]
    8c40:	2a1803f5 	mov	w21, w24
    8c44:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8c48:	d37ef6b9 	lsl	x25, x21, #2
    8c4c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8c50:	aa1603e0 	mov	x0, x22
    8c54:	97ffe6af 	bl	2710 <strlen@plt>
    8c58:	aa1603e1 	mov	x1, x22
    8c5c:	aa0003e2 	mov	x2, x0
    8c60:	aa1403e0 	mov	x0, x20
    8c64:	97ffea4b 	bl	3590 <buf_put>
    8c68:	f9401780 	ldr	x0, [x28, #40]
    8c6c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8c70:	7100001f 	cmp	w0, #0x0
    8c74:	5400068d 	b.le	8d44 <fwp_write+0x7e4>
    8c78:	91002276 	add	x22, x19, #0x8
    8c7c:	91001ff5 	add	x21, sp, #0x7
    8c80:	d280001b 	mov	x27, #0x0                   	// #0
    8c84:	5280041a 	mov	w26, #0x20                  	// #32
    8c88:	f9401b80 	ldr	x0, [x28, #48]
    8c8c:	aa1503e1 	mov	x1, x21
    8c90:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8c94:	d2800022 	mov	x2, #0x1                   	// #1
    8c98:	f8786803 	ldr	x3, [x0, x24]
    8c9c:	aa1403e0 	mov	x0, x20
    8ca0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8ca4:	39001ffa 	strb	w26, [sp, #7]
    8ca8:	97ffea3a 	bl	3590 <buf_put>
    8cac:	f13ffeff 	cmp	x23, #0xfff
    8cb0:	b9400261 	ldr	w1, [x19]
    8cb4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8cb8:	7100383f 	cmp	w1, #0xe
    8cbc:	54000160 	b.eq	8ce8 <fwp_write+0x788>  // b.none
    8cc0:	7100403f 	cmp	w1, #0x10
    8cc4:	54001a60 	b.eq	9010 <fwp_write+0xab0>  // b.none
    8cc8:	7100283f 	cmp	w1, #0xa
    8ccc:	54002aa0 	b.eq	9220 <fwp_write+0xcc0>  // b.none
    8cd0:	540014ac 	b.gt	8f64 <fwp_write+0xa04>
    8cd4:	71000c3f 	cmp	w1, #0x3
    8cd8:	540029ac 	b.gt	920c <fwp_write+0xcac>
    8cdc:	d37ffee0 	lsr	x0, x23, #63
    8ce0:	37f814a1 	tbnz	w1, #31, 8f74 <fwp_write+0xa14>
    8ce4:	d503201f 	nop
    8ce8:	34001460 	cbz	w0, 8f74 <fwp_write+0xa14>
    8cec:	52800503 	mov	w3, #0x28                  	// #40
    8cf0:	aa1503e1 	mov	x1, x21
    8cf4:	aa1403e0 	mov	x0, x20
    8cf8:	d2800022 	mov	x2, #0x1                   	// #1
    8cfc:	39001fe3 	strb	w3, [sp, #7]
    8d00:	97ffea24 	bl	3590 <buf_put>
    8d04:	aa1303e2 	mov	x2, x19
    8d08:	aa1703e1 	mov	x1, x23
    8d0c:	aa1403e0 	mov	x0, x20
    8d10:	52800003 	mov	w3, #0x0                   	// #0
    8d14:	97fffe13 	bl	8560 <fwp_write>
    8d18:	52800523 	mov	w3, #0x29                  	// #41
    8d1c:	aa1503e1 	mov	x1, x21
    8d20:	aa1403e0 	mov	x0, x20
    8d24:	d2800022 	mov	x2, #0x1                   	// #1
    8d28:	39001fe3 	strb	w3, [sp, #7]
    8d2c:	97ffea19 	bl	3590 <buf_put>
    8d30:	f9401780 	ldr	x0, [x28, #40]
    8d34:	9100077b 	add	x27, x27, #0x1
    8d38:	b8796800 	ldr	w0, [x0, x25]
    8d3c:	6b1b001f 	cmp	w0, w27
    8d40:	54fffa4c 	b.gt	8c88 <fwp_write+0x728>
    8d44:	f9413bf5 	ldr	x21, [sp, #624]
    8d48:	f9413ff6 	ldr	x22, [sp, #632]
    8d4c:	f94143f7 	ldr	x23, [sp, #640]
    8d50:	f94147f8 	ldr	x24, [sp, #648]
    8d54:	f9414bf9 	ldr	x25, [sp, #656]
    8d58:	f9414ffa 	ldr	x26, [sp, #664]
    8d5c:	f94153fb 	ldr	x27, [sp, #672]
    8d60:	f94157fc 	ldr	x28, [sp, #680]
    8d64:	17fffe2b 	b	8610 <fwp_write+0xb0>
    8d68:	52800783 	mov	w3, #0x3c                  	// #60
    8d6c:	91001ff3 	add	x19, sp, #0x7
    8d70:	aa1303e1 	mov	x1, x19
    8d74:	d2800022 	mov	x2, #0x1                   	// #1
    8d78:	aa1403e0 	mov	x0, x20
    8d7c:	39001fe3 	strb	w3, [sp, #7]
    8d80:	97ffea04 	bl	3590 <buf_put>
    8d84:	f9400795 	ldr	x21, [x28, #8]
    8d88:	aa1503e0 	mov	x0, x21
    8d8c:	97ffe661 	bl	2710 <strlen@plt>
    8d90:	aa1503e1 	mov	x1, x21
    8d94:	aa0003e2 	mov	x2, x0
    8d98:	aa1403e0 	mov	x0, x20
    8d9c:	97ffe9fd 	bl	3590 <buf_put>
    8da0:	528007c3 	mov	w3, #0x3e                  	// #62
    8da4:	aa1303e1 	mov	x1, x19
    8da8:	aa1403e0 	mov	x0, x20
    8dac:	d2800022 	mov	x2, #0x1                   	// #1
    8db0:	39001fe3 	strb	w3, [sp, #7]
    8db4:	17fffe12 	b	85fc <fwp_write+0x9c>
    8db8:	f100067f 	cmp	x19, #0x1
    8dbc:	540025a0 	b.eq	9270 <fwp_write+0xd10>  // b.none
    8dc0:	b100067f 	cmn	x19, #0x1
    8dc4:	54002bc0 	b.eq	933c <fwp_write+0xddc>  // b.none
    8dc8:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    8dcc:	91268021 	add	x1, x1, #0x9a0
    8dd0:	d2800022 	mov	x2, #0x1                   	// #1
    8dd4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8dd8:	f947f400 	ldr	x0, [x0, #4072]
    8ddc:	f94127e4 	ldr	x4, [sp, #584]
    8de0:	f9400003 	ldr	x3, [x0]
    8de4:	eb030084 	subs	x4, x4, x3
    8de8:	d2800003 	mov	x3, #0x0                   	// #0
    8dec:	54ffebe0 	b.eq	8b68 <fwp_write+0x608>  // b.none
    8df0:	f90143f7 	str	x23, [sp, #640]
    8df4:	f90147f8 	str	x24, [sp, #648]
    8df8:	f9014bf9 	str	x25, [sp, #656]
    8dfc:	f9014ffa 	str	x26, [sp, #664]
    8e00:	fd015be8 	str	d8, [sp, #688]
    8e04:	fd015fe9 	str	d9, [sp, #696]
    8e08:	97ffe69e 	bl	2880 <__stack_chk_fail@plt>
    8e0c:	52800b63 	mov	w3, #0x5b                  	// #91
    8e10:	91001ff5 	add	x21, sp, #0x7
    8e14:	aa1503e1 	mov	x1, x21
    8e18:	aa1403e0 	mov	x0, x20
    8e1c:	d2800022 	mov	x2, #0x1                   	// #1
    8e20:	b0000036 	adrp	x22, d000 <__divti3+0x2f0>
    8e24:	912902d6 	add	x22, x22, #0xa40
    8e28:	39001fe3 	strb	w3, [sp, #7]
    8e2c:	97ffe9d9 	bl	3590 <buf_put>
    8e30:	b4000273 	cbz	x19, 8e7c <fwp_write+0x91c>
    8e34:	f9400661 	ldr	x1, [x19, #8]
    8e38:	aa1403e0 	mov	x0, x20
    8e3c:	f9401f82 	ldr	x2, [x28, #56]
    8e40:	52800003 	mov	w3, #0x0                   	// #0
    8e44:	97fffdc7 	bl	8560 <fwp_write>
    8e48:	f9400a73 	ldr	x19, [x19, #16]
    8e4c:	b4000193 	cbz	x19, 8e7c <fwp_write+0x91c>
    8e50:	aa1603e1 	mov	x1, x22
    8e54:	aa1403e0 	mov	x0, x20
    8e58:	d2800042 	mov	x2, #0x2                   	// #2
    8e5c:	97ffe9cd 	bl	3590 <buf_put>
    8e60:	f9400661 	ldr	x1, [x19, #8]
    8e64:	aa1403e0 	mov	x0, x20
    8e68:	f9401f82 	ldr	x2, [x28, #56]
    8e6c:	52800003 	mov	w3, #0x0                   	// #0
    8e70:	97fffdbc 	bl	8560 <fwp_write>
    8e74:	f9400a73 	ldr	x19, [x19, #16]
    8e78:	b5fffed3 	cbnz	x19, 8e50 <fwp_write+0x8f0>
    8e7c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8e80:	aa1503e1 	mov	x1, x21
    8e84:	aa1403e0 	mov	x0, x20
    8e88:	d2800022 	mov	x2, #0x1                   	// #1
    8e8c:	39001fe3 	strb	w3, [sp, #7]
    8e90:	17fffddb 	b	85fc <fwp_write+0x9c>
    8e94:	aa1403e0 	mov	x0, x20
    8e98:	b0000021 	adrp	x1, d000 <__divti3+0x2f0>
    8e9c:	d28000c2 	mov	x2, #0x6                   	// #6
    8ea0:	9128c021 	add	x1, x1, #0xa30
    8ea4:	97ffe9bb 	bl	3590 <buf_put>
    8ea8:	f9400260 	ldr	x0, [x19]
    8eac:	b40004c0 	cbz	x0, 8f44 <fwp_write+0x9e4>
    8eb0:	910123f5 	add	x21, sp, #0x48
    8eb4:	91002276 	add	x22, x19, #0x8
    8eb8:	f90143f7 	str	x23, [sp, #640]
    8ebc:	d2800017 	mov	x23, #0x0                   	// #0
    8ec0:	f90147f8 	str	x24, [sp, #648]
    8ec4:	b0000038 	adrp	x24, d000 <__divti3+0x2f0>
    8ec8:	9128e318 	add	x24, x24, #0xa38
    8ecc:	f9014bf9 	str	x25, [sp, #656]
    8ed0:	b0000039 	adrp	x25, d000 <__divti3+0x2f0>
    8ed4:	91290339 	add	x25, x25, #0xa40
    8ed8:	f9014ffa 	str	x26, [sp, #664]
    8edc:	14000005 	b	8ef0 <fwp_write+0x990>
    8ee0:	aa1903e1 	mov	x1, x25
    8ee4:	aa1403e0 	mov	x0, x20
    8ee8:	d2800042 	mov	x2, #0x2                   	// #2
    8eec:	97ffe9a9 	bl	3590 <buf_put>
    8ef0:	38776ac5 	ldrb	w5, [x22, x23]
    8ef4:	d2804003 	mov	x3, #0x200                 	// #512
    8ef8:	aa1803e4 	mov	x4, x24
    8efc:	aa0303e1 	mov	x1, x3
    8f00:	52800042 	mov	w2, #0x2                   	// #2
    8f04:	aa1503e0 	mov	x0, x21
    8f08:	910006f7 	add	x23, x23, #0x1
    8f0c:	97ffe639 	bl	27f0 <__snprintf_chk@plt>
    8f10:	aa1503e0 	mov	x0, x21
    8f14:	97ffe5ff 	bl	2710 <strlen@plt>
    8f18:	aa1503e1 	mov	x1, x21
    8f1c:	aa0003e2 	mov	x2, x0
    8f20:	aa1403e0 	mov	x0, x20
    8f24:	97ffe99b 	bl	3590 <buf_put>
    8f28:	f9400260 	ldr	x0, [x19]
    8f2c:	eb17001f 	cmp	x0, x23
    8f30:	54fffd88 	b.hi	8ee0 <fwp_write+0x980>  // b.pmore
    8f34:	f94143f7 	ldr	x23, [sp, #640]
    8f38:	f94147f8 	ldr	x24, [sp, #648]
    8f3c:	f9414bf9 	ldr	x25, [sp, #656]
    8f40:	f9414ffa 	ldr	x26, [sp, #664]
    8f44:	52800ba3 	mov	w3, #0x5d                  	// #93
    8f48:	aa1403e0 	mov	x0, x20
    8f4c:	91001fe1 	add	x1, sp, #0x7
    8f50:	d2800022 	mov	x2, #0x1                   	// #1
    8f54:	39001fe3 	strb	w3, [sp, #7]
    8f58:	17fffda9 	b	85fc <fwp_write+0x9c>
    8f5c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8f60:	17fffe44 	b	8870 <fwp_write+0x310>
    8f64:	f10002ff 	cmp	x23, #0x0
    8f68:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8f6c:	71002c3f 	cmp	w1, #0xb
    8f70:	54ffebc0 	b.eq	8ce8 <fwp_write+0x788>  // b.none
    8f74:	aa1303e2 	mov	x2, x19
    8f78:	aa1703e1 	mov	x1, x23
    8f7c:	aa1403e0 	mov	x0, x20
    8f80:	52800003 	mov	w3, #0x0                   	// #0
    8f84:	97fffd77 	bl	8560 <fwp_write>
    8f88:	17ffff6a 	b	8d30 <fwp_write+0x7d0>
    8f8c:	aa1403e0 	mov	x0, x20
    8f90:	91001fe1 	add	x1, sp, #0x7
    8f94:	52800fa3 	mov	w3, #0x7d                  	// #125
    8f98:	d2800022 	mov	x2, #0x1                   	// #1
    8f9c:	17fffe38 	b	887c <fwp_write+0x31c>
    8fa0:	a9400281 	ldp	x1, x0, [x20]
    8fa4:	91000800 	add	x0, x0, #0x2
    8fa8:	8b160000 	add	x0, x0, x22
    8fac:	f9000680 	str	x0, [x20, #8]
    8fb0:	3820683f 	strb	wzr, [x1, x0]
    8fb4:	f9413bf5 	ldr	x21, [sp, #624]
    8fb8:	f9413ff6 	ldr	x22, [sp, #632]
    8fbc:	f94153fb 	ldr	x27, [sp, #672]
    8fc0:	f94157fc 	ldr	x28, [sp, #680]
    8fc4:	17fffd93 	b	8610 <fwp_write+0xb0>
    8fc8:	f9400f80 	ldr	x0, [x28, #24]
    8fcc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8fd0:	aa1b03e0 	mov	x0, x27
    8fd4:	97ffe5cf 	bl	2710 <strlen@plt>
    8fd8:	aa1b03e1 	mov	x1, x27
    8fdc:	aa0003e2 	mov	x2, x0
    8fe0:	aa1403e0 	mov	x0, x20
    8fe4:	97ffe96b 	bl	3590 <buf_put>
    8fe8:	aa1903e1 	mov	x1, x25
    8fec:	aa1403e0 	mov	x0, x20
    8ff0:	d2800062 	mov	x2, #0x3                   	// #3
    8ff4:	97ffe967 	bl	3590 <buf_put>
    8ff8:	17fffe10 	b	8838 <fwp_write+0x2d8>
    8ffc:	aa1a03e1 	mov	x1, x26
    9000:	aa1403e0 	mov	x0, x20
    9004:	d2800042 	mov	x2, #0x2                   	// #2
    9008:	97ffe962 	bl	3590 <buf_put>
    900c:	17fffe09 	b	8830 <fwp_write+0x2d0>
    9010:	f9400660 	ldr	x0, [x19, #8]
    9014:	b4fffb00 	cbz	x0, 8f74 <fwp_write+0xa14>
    9018:	90000021 	adrp	x1, d000 <__divti3+0x2f0>
    901c:	91296021 	add	x1, x1, #0xa58
    9020:	97ffe638 	bl	2900 <strcmp@plt>
    9024:	7100001f 	cmp	w0, #0x0
    9028:	1a9f07e0 	cset	w0, ne	// ne = any
    902c:	17ffff2f 	b	8ce8 <fwp_write+0x788>
    9030:	aa1403e0 	mov	x0, x20
    9034:	d2800042 	mov	x2, #0x2                   	// #2
    9038:	90000021 	adrp	x1, d000 <__divti3+0x2f0>
    903c:	91294021 	add	x1, x1, #0xa50
    9040:	97ffe954 	bl	3590 <buf_put>
    9044:	91004261 	add	x1, x19, #0x10
    9048:	aa1403e0 	mov	x0, x20
    904c:	f9402382 	ldr	x2, [x28, #64]
    9050:	52800003 	mov	w3, #0x0                   	// #0
    9054:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9058:	97fffd42 	bl	8560 <fwp_write>
    905c:	17fffd9c 	b	86cc <fwp_write+0x16c>
    9060:	1e22c109 	fcvt	d9, s8
    9064:	910123f5 	add	x21, sp, #0x48
    9068:	52800033 	mov	w19, #0x1                   	// #1
    906c:	d503201f 	nop
    9070:	1e604120 	fmov	d0, d9
    9074:	2a1303e1 	mov	w1, w19
    9078:	aa1503e0 	mov	x0, x21
    907c:	97ffeac6 	bl	3b94 <fwp_format_g.constprop.0>
    9080:	aa1503e0 	mov	x0, x21
    9084:	d2800001 	mov	x1, #0x0                   	// #0
    9088:	97ffe62a 	bl	2930 <strtof@plt>
    908c:	1e202100 	fcmp	s8, s0
    9090:	54ffdb60 	b.eq	8bfc <fwp_write+0x69c>  // b.none
    9094:	11000673 	add	w19, w19, #0x1
    9098:	71002a7f 	cmp	w19, #0xa
    909c:	54fffea1 	b.ne	9070 <fwp_write+0xb10>  // b.any
    90a0:	1e604120 	fmov	d0, d9
    90a4:	aa1503e0 	mov	x0, x21
    90a8:	52800121 	mov	w1, #0x9                   	// #9
    90ac:	97ffeaba 	bl	3b94 <fwp_format_g.constprop.0>
    90b0:	17fffed3 	b	8bfc <fwp_write+0x69c>
    90b4:	d37ef6a1 	lsl	x1, x21, #2
    90b8:	b7f81563 	tbnz	x3, #63, 9364 <fwp_write+0xe04>
    90bc:	91002263 	add	x3, x19, #0x8
    90c0:	8b010061 	add	x1, x3, x1
    90c4:	b9400023 	ldr	w3, [x1]
    90c8:	7100081f 	cmp	w0, #0x2
    90cc:	2a0303e1 	mov	w1, w3
    90d0:	93407c63 	sxtw	x3, w3
    90d4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    90d8:	17fffe5a 	b	8a40 <fwp_write+0x4e0>
    90dc:	d37ffaa1 	lsl	x1, x21, #1
    90e0:	b7f81363 	tbnz	x3, #63, 934c <fwp_write+0xdec>
    90e4:	91002263 	add	x3, x19, #0x8
    90e8:	8b010061 	add	x1, x3, x1
    90ec:	79400021 	ldrh	w1, [x1]
    90f0:	7100041f 	cmp	w0, #0x1
    90f4:	93403c23 	sxth	x3, w1
    90f8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    90fc:	17fffe51 	b	8a40 <fwp_write+0x4e0>
    9100:	52800443 	mov	w3, #0x22                  	// #34
    9104:	91001ff5 	add	x21, sp, #0x7
    9108:	91002273 	add	x19, x19, #0x8
    910c:	aa1503e1 	mov	x1, x21
    9110:	aa1403e0 	mov	x0, x20
    9114:	d2800022 	mov	x2, #0x1                   	// #1
    9118:	39001fe3 	strb	w3, [sp, #7]
    911c:	f90143f7 	str	x23, [sp, #640]
    9120:	8b160277 	add	x23, x19, x22
    9124:	f90147f8 	str	x24, [sp, #648]
    9128:	97ffe91a 	bl	3590 <buf_put>
    912c:	b4000696 	cbz	x22, 91fc <fwp_write+0xc9c>
    9130:	90000038 	adrp	x24, d000 <__divti3+0x2f0>
    9134:	91280318 	add	x24, x24, #0xa00
    9138:	f9014bf9 	str	x25, [sp, #656]
    913c:	90000039 	adrp	x25, d000 <__divti3+0x2f0>
    9140:	91288339 	add	x25, x25, #0xa20
    9144:	f9014ffa 	str	x26, [sp, #664]
    9148:	1400000d 	b	917c <fwp_write+0xc1c>
    914c:	710024bf 	cmp	w5, #0x9
    9150:	54000460 	b.eq	91dc <fwp_write+0xc7c>  // b.none
    9154:	710028bf 	cmp	w5, #0xa
    9158:	54000a61 	b.ne	92a4 <fwp_write+0xd44>  // b.any
    915c:	90000021 	adrp	x1, d000 <__divti3+0x2f0>
    9160:	aa1403e0 	mov	x0, x20
    9164:	91284021 	add	x1, x1, #0xa10
    9168:	d2800042 	mov	x2, #0x2                   	// #2
    916c:	97ffe909 	bl	3590 <buf_put>
    9170:	91000673 	add	x19, x19, #0x1
    9174:	eb17027f 	cmp	x19, x23
    9178:	540003e0 	b.eq	91f4 <fwp_write+0xc94>  // b.none
    917c:	39400265 	ldrb	w5, [x19]
    9180:	710034bf 	cmp	w5, #0xd
    9184:	54000180 	b.eq	91b4 <fwp_write+0xc54>  // b.none
    9188:	54fffe29 	b.ls	914c <fwp_write+0xbec>  // b.plast
    918c:	710088bf 	cmp	w5, #0x22
    9190:	540001c0 	b.eq	91c8 <fwp_write+0xc68>  // b.none
    9194:	710170bf 	cmp	w5, #0x5c
    9198:	54000741 	b.ne	9280 <fwp_write+0xd20>  // b.any
    919c:	aa1403e0 	mov	x0, x20
    91a0:	90000021 	adrp	x1, d000 <__divti3+0x2f0>
    91a4:	d2800042 	mov	x2, #0x2                   	// #2
    91a8:	91282021 	add	x1, x1, #0xa08
    91ac:	97ffe8f9 	bl	3590 <buf_put>
    91b0:	17fffff0 	b	9170 <fwp_write+0xc10>
    91b4:	aa1903e1 	mov	x1, x25
    91b8:	aa1403e0 	mov	x0, x20
    91bc:	d2800042 	mov	x2, #0x2                   	// #2
    91c0:	97ffe8f4 	bl	3590 <buf_put>
    91c4:	17ffffeb 	b	9170 <fwp_write+0xc10>
    91c8:	aa1803e1 	mov	x1, x24
    91cc:	aa1403e0 	mov	x0, x20
    91d0:	d2800042 	mov	x2, #0x2                   	// #2
    91d4:	97ffe8ef 	bl	3590 <buf_put>
    91d8:	17ffffe6 	b	9170 <fwp_write+0xc10>
    91dc:	aa1403e0 	mov	x0, x20
    91e0:	90000021 	adrp	x1, d000 <__divti3+0x2f0>
    91e4:	d2800042 	mov	x2, #0x2                   	// #2
    91e8:	91286021 	add	x1, x1, #0xa18
    91ec:	97ffe8e9 	bl	3590 <buf_put>
    91f0:	17ffffe0 	b	9170 <fwp_write+0xc10>
    91f4:	f9414bf9 	ldr	x25, [sp, #656]
    91f8:	f9414ffa 	ldr	x26, [sp, #664]
    91fc:	aa1503e1 	mov	x1, x21
    9200:	aa1403e0 	mov	x0, x20
    9204:	52800443 	mov	w3, #0x22                  	// #34
    9208:	17fffd9c 	b	8878 <fwp_write+0x318>
    920c:	7100103f 	cmp	w1, #0x4
    9210:	54ffeb21 	b.ne	8f74 <fwp_write+0xa14>  // b.any
    9214:	f94006e0 	ldr	x0, [x23, #8]
    9218:	d37ffc00 	lsr	x0, x0, #63
    921c:	17fffeb3 	b	8ce8 <fwp_write+0x788>
    9220:	710002ff 	cmp	w23, #0x0
    9224:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9228:	17fffeb0 	b	8ce8 <fwp_write+0x788>
    922c:	528005a1 	mov	w1, #0x2d                  	// #45
    9230:	eb0203e2 	negs	x2, x2
    9234:	da0303e3 	ngc	x3, x3
    9238:	910127e0 	add	x0, sp, #0x49
    923c:	910123f5 	add	x21, sp, #0x48
    9240:	390123e1 	strb	w1, [sp, #72]
    9244:	97ffe6f7 	bl	2e20 <fwp_fmt_u128>
    9248:	17fffe18 	b	8aa8 <fwp_write+0x548>
    924c:	d37ceea1 	lsl	x1, x21, #4
    9250:	b7f810a3 	tbnz	x3, #63, 9464 <fwp_write+0xf04>
    9254:	91002260 	add	x0, x19, #0x8
    9258:	8b010001 	add	x1, x0, x1
    925c:	17fffdf9 	b	8a40 <fwp_write+0x4e0>
    9260:	f9400a61 	ldr	x1, [x19, #16]
    9264:	8b010000 	add	x0, x0, x1
    9268:	f9400001 	ldr	x1, [x0]
    926c:	17fffdf5 	b	8a40 <fwp_write+0x4e0>
    9270:	90000021 	adrp	x1, d000 <__divti3+0x2f0>
    9274:	d2800042 	mov	x2, #0x2                   	// #2
    9278:	9126a021 	add	x1, x1, #0x9a8
    927c:	17fffed6 	b	8dd4 <fwp_write+0x874>
    9280:	7101fcbf 	cmp	w5, #0x7f
    9284:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9288:	540000e9 	b.ls	92a4 <fwp_write+0xd44>  // b.plast
    928c:	aa1503e1 	mov	x1, x21
    9290:	aa1403e0 	mov	x0, x20
    9294:	d2800022 	mov	x2, #0x1                   	// #1
    9298:	39001fe5 	strb	w5, [sp, #7]
    929c:	97ffe8bd 	bl	3590 <buf_put>
    92a0:	17ffffb4 	b	9170 <fwp_write+0xc10>
    92a4:	d2800203 	mov	x3, #0x10                  	// #16
    92a8:	90000024 	adrp	x4, d000 <__divti3+0x2f0>
    92ac:	aa0303e1 	mov	x1, x3
    92b0:	9128a084 	add	x4, x4, #0xa28
    92b4:	910123f6 	add	x22, sp, #0x48
    92b8:	52800042 	mov	w2, #0x2                   	// #2
    92bc:	aa1603e0 	mov	x0, x22
    92c0:	97ffe54c 	bl	27f0 <__snprintf_chk@plt>
    92c4:	aa1603e0 	mov	x0, x22
    92c8:	97ffe512 	bl	2710 <strlen@plt>
    92cc:	aa1603e1 	mov	x1, x22
    92d0:	aa0003e2 	mov	x2, x0
    92d4:	aa1403e0 	mov	x0, x20
    92d8:	97ffe8ae 	bl	3590 <buf_put>
    92dc:	17ffffa5 	b	9170 <fwp_write+0xc10>
    92e0:	1e604100 	fmov	d0, d8
    92e4:	aa1503e0 	mov	x0, x21
    92e8:	52800221 	mov	w1, #0x11                  	// #17
    92ec:	97ffea2a 	bl	3b94 <fwp_format_g.constprop.0>
    92f0:	17fffe43 	b	8bfc <fwp_write+0x69c>
    92f4:	b9401040 	ldr	w0, [x2, #16]
    92f8:	350003c0 	cbnz	w0, 9370 <fwp_write+0xe10>
    92fc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9300:	f947f400 	ldr	x0, [x0, #4072]
    9304:	f94127e2 	ldr	x2, [sp, #584]
    9308:	f9400001 	ldr	x1, [x0]
    930c:	eb010042 	subs	x2, x2, x1
    9310:	d2800001 	mov	x1, #0x0                   	// #0
    9314:	54ffd721 	b.ne	8df8 <fwp_write+0x898>  // b.any
    9318:	f9413bf5 	ldr	x21, [sp, #624]
    931c:	90000021 	adrp	x1, d000 <__divti3+0x2f0>
    9320:	f9413ff6 	ldr	x22, [sp, #632]
    9324:	aa1403e0 	mov	x0, x20
    9328:	f94143f7 	ldr	x23, [sp, #640]
    932c:	9129e021 	add	x1, x1, #0xa78
    9330:	f94147f8 	ldr	x24, [sp, #648]
    9334:	d2800042 	mov	x2, #0x2                   	// #2
    9338:	17fffd0e 	b	8770 <fwp_write+0x210>
    933c:	90000021 	adrp	x1, d000 <__divti3+0x2f0>
    9340:	d2800042 	mov	x2, #0x2                   	// #2
    9344:	9126c021 	add	x1, x1, #0x9b0
    9348:	17fffea3 	b	8dd4 <fwp_write+0x874>
    934c:	f9400a63 	ldr	x3, [x19, #16]
    9350:	8b030021 	add	x1, x1, x3
    9354:	17ffff66 	b	90ec <fwp_write+0xb8c>
    9358:	f9400a61 	ldr	x1, [x19, #16]
    935c:	8b0102a1 	add	x1, x21, x1
    9360:	17fffdb3 	b	8a2c <fwp_write+0x4cc>
    9364:	f9400a63 	ldr	x3, [x19, #16]
    9368:	8b030021 	add	x1, x1, x3
    936c:	17ffff56 	b	90c4 <fwp_write+0xb64>
    9370:	b9404840 	ldr	w0, [x2, #72]
    9374:	91001ff5 	add	x21, sp, #0x7
    9378:	34ffa360 	cbz	w0, 87e4 <fwp_write+0x284>
    937c:	52800503 	mov	w3, #0x28                  	// #40
    9380:	aa1403e0 	mov	x0, x20
    9384:	aa1503e1 	mov	x1, x21
    9388:	d2800022 	mov	x2, #0x1                   	// #1
    938c:	39001fe3 	strb	w3, [sp, #7]
    9390:	97ffe880 	bl	3590 <buf_put>
    9394:	b9401380 	ldr	w0, [x28, #16]
    9398:	52800038 	mov	w24, #0x1                   	// #1
    939c:	7100001f 	cmp	w0, #0x0
    93a0:	54ffa36c 	b.gt	880c <fwp_write+0x2ac>
    93a4:	17fffd32 	b	886c <fwp_write+0x30c>
    93a8:	f9014bf9 	str	x25, [sp, #656]
    93ac:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe930>
    93b0:	f9014ffa 	str	x26, [sp, #664]
    93b4:	f9400676 	ldr	x22, [x19, #8]
    93b8:	91102333 	add	x19, x25, #0x408
    93bc:	91002273 	add	x19, x19, #0x8
    93c0:	937ffed8 	asr	x24, x22, #63
    93c4:	aa1802c0 	orr	x0, x22, x24
    93c8:	b5000320 	cbnz	x0, 942c <fwp_write+0xecc>
    93cc:	110006b5 	add	w21, w21, #0x1
    93d0:	710016bf 	cmp	w21, #0x5
    93d4:	54ffffc1 	b.ne	93cc <fwp_write+0xe6c>  // b.any
    93d8:	b7f80578 	tbnz	x24, #63, 9484 <fwp_write+0xf24>
    93dc:	910023f3 	add	x19, sp, #0x8
    93e0:	aa1603e2 	mov	x2, x22
    93e4:	aa1303e0 	mov	x0, x19
    93e8:	d2800003 	mov	x3, #0x0                   	// #0
    93ec:	97ffe68d 	bl	2e20 <fwp_fmt_u128>
    93f0:	910123f5 	add	x21, sp, #0x48
    93f4:	90000023 	adrp	x3, d000 <__divti3+0x2f0>
    93f8:	aa1303e4 	mov	x4, x19
    93fc:	aa1503e0 	mov	x0, x21
    9400:	9129c063 	add	x3, x3, #0xa70
    9404:	d2804002 	mov	x2, #0x200                 	// #512
    9408:	52800041 	mov	w1, #0x2                   	// #2
    940c:	97ffe4c5 	bl	2720 <__sprintf_chk@plt>
    9410:	aa1503e0 	mov	x0, x21
    9414:	97ffe4bf 	bl	2710 <strlen@plt>
    9418:	aa1503e1 	mov	x1, x21
    941c:	aa0003e2 	mov	x2, x0
    9420:	aa1403e0 	mov	x0, x20
    9424:	97ffe85b 	bl	3590 <buf_put>
    9428:	17fffe47 	b	8d44 <fwp_write+0x7e4>
    942c:	f9400277 	ldr	x23, [x19]
    9430:	aa1603e0 	mov	x0, x22
    9434:	aa1803e1 	mov	x1, x24
    9438:	aa1703e2 	mov	x2, x23
    943c:	937ffefa 	asr	x26, x23, #63
    9440:	aa1a03e3 	mov	x3, x26
    9444:	94000f13 	bl	d090 <__modti3>
    9448:	aa010000 	orr	x0, x0, x1
    944c:	b40002c0 	cbz	x0, 94a4 <fwp_write+0xf44>
    9450:	110006b5 	add	w21, w21, #0x1
    9454:	91004273 	add	x19, x19, #0x10
    9458:	710016bf 	cmp	w21, #0x5
    945c:	54fffe81 	b.ne	942c <fwp_write+0xecc>  // b.any
    9460:	17ffffde 	b	93d8 <fwp_write+0xe78>
    9464:	f9400a60 	ldr	x0, [x19, #16]
    9468:	8b000021 	add	x1, x1, x0
    946c:	17fffd75 	b	8a40 <fwp_write+0x4e0>
    9470:	528c29c0 	mov	w0, #0x614e                	// #24910
    9474:	910123f5 	add	x21, sp, #0x48
    9478:	72a009c0 	movk	w0, #0x4e, lsl #16
    947c:	b9004be0 	str	w0, [sp, #72]
    9480:	17fffda2 	b	8b08 <fwp_write+0x5a8>
    9484:	528005a1 	mov	w1, #0x2d                  	// #45
    9488:	eb1603e2 	negs	x2, x22
    948c:	da1803e3 	ngc	x3, x24
    9490:	910027e0 	add	x0, sp, #0x9
    9494:	910023f3 	add	x19, sp, #0x8
    9498:	390023e1 	strb	w1, [sp, #8]
    949c:	97ffe661 	bl	2e20 <fwp_fmt_u128>
    94a0:	17ffffd4 	b	93f0 <fwp_write+0xe90>
    94a4:	aa1703e2 	mov	x2, x23
    94a8:	aa1a03e3 	mov	x3, x26
    94ac:	aa1603e0 	mov	x0, x22
    94b0:	aa1803e1 	mov	x1, x24
    94b4:	94000e17 	bl	cd10 <__divti3>
    94b8:	aa0003e2 	mov	x2, x0
    94bc:	aa0103e3 	mov	x3, x1
    94c0:	b7f80201 	tbnz	x1, #63, 9500 <fwp_write+0xfa0>
    94c4:	910023f3 	add	x19, sp, #0x8
    94c8:	aa1303e0 	mov	x0, x19
    94cc:	97ffe655 	bl	2e20 <fwp_fmt_u128>
    94d0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    94d4:	91102339 	add	x25, x25, #0x408
    94d8:	910123f5 	add	x21, sp, #0x48
    94dc:	aa1303e4 	mov	x4, x19
    94e0:	aa1503e0 	mov	x0, x21
    94e4:	90000023 	adrp	x3, d000 <__divti3+0x2f0>
    94e8:	f8616b25 	ldr	x5, [x25, x1]
    94ec:	9129a063 	add	x3, x3, #0xa68
    94f0:	d2804002 	mov	x2, #0x200                 	// #512
    94f4:	52800041 	mov	w1, #0x2                   	// #2
    94f8:	97ffe48a 	bl	2720 <__sprintf_chk@plt>
    94fc:	17ffffc5 	b	9410 <fwp_write+0xeb0>
    9500:	528005a4 	mov	w4, #0x2d                  	// #45
    9504:	eb0003e2 	negs	x2, x0
    9508:	da0103e3 	ngc	x3, x1
    950c:	910027e0 	add	x0, sp, #0x9
    9510:	910023f3 	add	x19, sp, #0x8
    9514:	390023e4 	strb	w4, [sp, #8]
    9518:	97ffe642 	bl	2e20 <fwp_fmt_u128>
    951c:	17ffffed 	b	94d0 <fwp_write+0xf70>
    9520:	f9013bf5 	str	x21, [sp, #624]
    9524:	f9013ff6 	str	x22, [sp, #632]
    9528:	f90143f7 	str	x23, [sp, #640]
    952c:	f90147f8 	str	x24, [sp, #648]
    9530:	f9014bf9 	str	x25, [sp, #656]
    9534:	f9014ffa 	str	x26, [sp, #664]
    9538:	f90153fb 	str	x27, [sp, #672]
    953c:	f90157fc 	str	x28, [sp, #680]
    9540:	fd015be8 	str	d8, [sp, #688]
    9544:	fd015fe9 	str	d9, [sp, #696]
    9548:	97ffe4ce 	bl	2880 <__stack_chk_fail@plt>
    954c:	d503201f 	nop

0000000000009550 <fwp_hof0.constprop.0>:
    9550:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9554:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9558:	f947f442 	ldr	x2, [x2, #4072]
    955c:	910003fd 	mov	x29, sp
    9560:	a90153f3 	stp	x19, x20, [sp, #16]
    9564:	a9025bf5 	stp	x21, x22, [sp, #32]
    9568:	a90363f7 	stp	x23, x24, [sp, #48]
    956c:	aa0003f7 	mov	x23, x0
    9570:	a9046bf9 	stp	x25, x26, [sp, #64]
    9574:	a90573fb 	stp	x27, x28, [sp, #80]
    9578:	d10243ff 	sub	sp, sp, #0x90
    957c:	f9400040 	ldr	x0, [x2]
    9580:	f81f83a0 	stur	x0, [x29, #-8]
    9584:	d2800000 	mov	x0, #0x0                   	// #0
    9588:	b4002da1 	cbz	x1, 9b3c <fwp_hof0.constprop.0+0x5ec>
    958c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9590:	9100401c 	add	x28, x0, #0x10
    9594:	9101039c 	add	x28, x28, #0x40
    9598:	f00000a0 	adrp	x0, 20000 <__data_start>
    959c:	aa0103fa 	mov	x26, x1
    95a0:	d10083b4 	sub	x20, x29, #0x20
    95a4:	9101c015 	add	x21, x0, #0x70
    95a8:	aa1c03f8 	mov	x24, x28
    95ac:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    95b0:	91174002 	add	x2, x0, #0x5d0
    95b4:	f949d841 	ldr	x1, [x2, #5040]
    95b8:	f949ec40 	ldr	x0, [x2, #5080]
    95bc:	cb0102e1 	sub	x1, x23, x1
    95c0:	eb00403f 	cmp	x1, x0, lsl #16
    95c4:	54000342 	b.cs	962c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    95c8:	d350fc20 	lsr	x0, x1, #16
    95cc:	f949fc44 	ldr	x4, [x2, #5112]
    95d0:	8b000800 	add	x0, x0, x0, lsl #2
    95d4:	d37df002 	lsl	x2, x0, #3
    95d8:	8b020083 	add	x3, x4, x2
    95dc:	f9401060 	ldr	x0, [x3, #32]
    95e0:	b4000260 	cbz	x0, 962c <fwp_hof0.constprop.0+0xdc>
    95e4:	38626882 	ldrb	w2, [x4, x2]
    95e8:	7100085f 	cmp	w2, #0x2
    95ec:	54005240 	b.eq	a034 <fwp_hof0.constprop.0+0xae4>  // b.none
    95f0:	7100045f 	cmp	w2, #0x1
    95f4:	540001c1 	b.ne	962c <fwp_hof0.constprop.0+0xdc>  // b.any
    95f8:	29430864 	ldp	w4, w2, [x3, #24]
    95fc:	92403c21 	and	x1, x1, #0xffff
    9600:	9b047c21 	mul	x1, x1, x4
    9604:	d360fc21 	lsr	x1, x1, #32
    9608:	eb02003f 	cmp	x1, x2
    960c:	54000102 	b.cs	962c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9610:	8b010000 	add	x0, x0, x1
    9614:	39400001 	ldrb	w1, [x0]
    9618:	340000a1 	cbz	w1, 962c <fwp_hof0.constprop.0+0xdc>
    961c:	7103f43f 	cmp	w1, #0xfd
    9620:	54005728 	b.hi	a104 <fwp_hof0.constprop.0+0xbb4>  // b.pmore
    9624:	11000421 	add	w1, w1, #0x1
    9628:	39000001 	strb	w1, [x0]
    962c:	aa1703f9 	mov	x25, x23
    9630:	a938dfba 	stp	x26, x23, [x29, #-120]
    9634:	aa1803fa 	mov	x26, x24
    9638:	d28018f3 	mov	x19, #0xc7                  	// #199
    963c:	f81983b3 	stur	x19, [x29, #-104]
    9640:	f00000a0 	adrp	x0, 20000 <__data_start>
    9644:	91004000 	add	x0, x0, #0x10
    9648:	f94046a3 	ldr	x3, [x21, #136]
    964c:	91010005 	add	x5, x0, #0x40
    9650:	b9404002 	ldr	w2, [x0, #64]
    9654:	d37be842 	lsl	x2, x2, #5
    9658:	8b02007b 	add	x27, x3, x2
    965c:	f9400f61 	ldr	x1, [x27, #24]
    9660:	f81e03b9 	stur	x25, [x29, #-32]
    9664:	b4004ee1 	cbz	x1, a040 <fwp_hof0.constprop.0+0xaf0>
    9668:	f9400c20 	ldr	x0, [x1, #24]
    966c:	b40042a0 	cbz	x0, 9ec0 <fwp_hof0.constprop.0+0x970>
    9670:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9674:	91174002 	add	x2, x0, #0x5d0
    9678:	f949d841 	ldr	x1, [x2, #5040]
    967c:	f949ec40 	ldr	x0, [x2, #5080]
    9680:	cb010341 	sub	x1, x26, x1
    9684:	eb00403f 	cmp	x1, x0, lsl #16
    9688:	54000342 	b.cs	96f0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    968c:	d350fc20 	lsr	x0, x1, #16
    9690:	f949fc45 	ldr	x5, [x2, #5112]
    9694:	8b000800 	add	x0, x0, x0, lsl #2
    9698:	d37df002 	lsl	x2, x0, #3
    969c:	8b0200a3 	add	x3, x5, x2
    96a0:	f9401060 	ldr	x0, [x3, #32]
    96a4:	b4000260 	cbz	x0, 96f0 <fwp_hof0.constprop.0+0x1a0>
    96a8:	386268a2 	ldrb	w2, [x5, x2]
    96ac:	7100085f 	cmp	w2, #0x2
    96b0:	54004700 	b.eq	9f90 <fwp_hof0.constprop.0+0xa40>  // b.none
    96b4:	7100045f 	cmp	w2, #0x1
    96b8:	540001c1 	b.ne	96f0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    96bc:	29430865 	ldp	w5, w2, [x3, #24]
    96c0:	92403c21 	and	x1, x1, #0xffff
    96c4:	9b057c21 	mul	x1, x1, x5
    96c8:	d360fc21 	lsr	x1, x1, #32
    96cc:	eb02003f 	cmp	x1, x2
    96d0:	54000102 	b.cs	96f0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    96d4:	8b010000 	add	x0, x0, x1
    96d8:	39400001 	ldrb	w1, [x0]
    96dc:	340000a1 	cbz	w1, 96f0 <fwp_hof0.constprop.0+0x1a0>
    96e0:	7103f43f 	cmp	w1, #0xfd
    96e4:	54004988 	b.hi	a014 <fwp_hof0.constprop.0+0xac4>  // b.pmore
    96e8:	11000421 	add	w1, w1, #0x1
    96ec:	39000001 	strb	w1, [x0]
    96f0:	aa1a03f9 	mov	x25, x26
    96f4:	aa1a03e0 	mov	x0, x26
    96f8:	aa1b03e3 	mov	x3, x27
    96fc:	52800037 	mov	w23, #0x1                   	// #1
    9700:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9704:	91174036 	add	x22, x1, #0x5d0
    9708:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    970c:	f81b03b6 	stur	x22, [x29, #-80]
    9710:	b81cc3b7 	stur	w23, [x29, #-52]
    9714:	f81d03b4 	stur	x20, [x29, #-48]
    9718:	b9400401 	ldr	w1, [x0, #4]
    971c:	b9400078 	ldr	w24, [x3]
    9720:	b85cc3a0 	ldur	w0, [x29, #-52]
    9724:	4b010318 	sub	w24, w24, w1
    9728:	6b17031f 	cmp	w24, w23
    972c:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    9730:	6b0000ff 	cmp	w7, w0
    9734:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    9738:	b81c83a0 	stur	w0, [x29, #-56]
    973c:	6b0000e2 	subs	w2, w7, w0
    9740:	54000120 	b.eq	9764 <fwp_hof0.constprop.0+0x214>  // b.none
    9744:	f9400c63 	ldr	x3, [x3, #24]
    9748:	0b000021 	add	w1, w1, w0
    974c:	f85d03a4 	ldur	x4, [x29, #-48]
    9750:	b81d83a7 	stur	w7, [x29, #-40]
    9754:	f9400863 	ldr	x3, [x3, #16]
    9758:	8b204c80 	add	x0, x4, w0, uxtw #3
    975c:	d63f0060 	blr	x3
    9760:	b85d83a7 	ldur	w7, [x29, #-40]
    9764:	f94046a0 	ldr	x0, [x21, #136]
    9768:	aa1903e6 	mov	x6, x25
    976c:	b9400323 	ldr	w3, [x25]
    9770:	2a0703f4 	mov	w20, w7
    9774:	f85d03bb 	ldur	x27, [x29, #-48]
    9778:	aa1903fc 	mov	x28, x25
    977c:	8b03141a 	add	x26, x0, x3, lsl #5
    9780:	f9400f40 	ldr	x0, [x26, #24]
    9784:	b40020e0 	cbz	x0, 9ba0 <fwp_hof0.constprop.0+0x650>
    9788:	f85b03bc 	ldur	x28, [x29, #-80]
    978c:	29371fb7 	stp	w23, w7, [x29, #-72]
    9790:	aa1a03f7 	mov	x23, x26
    9794:	b81c03b8 	stur	w24, [x29, #-64]
    9798:	aa1b03f8 	mov	x24, x27
    979c:	14000012 	b	97e4 <fwp_hof0.constprop.0+0x294>
    97a0:	f9400001 	ldr	x1, [x0]
    97a4:	aa1803e0 	mov	x0, x24
    97a8:	d63f0020 	blr	x1
    97ac:	aa0003fb 	mov	x27, x0
    97b0:	aa1903e0 	mov	x0, x25
    97b4:	97fff1b7 	bl	5e90 <fwp_closure_drop>
    97b8:	6b13029f 	cmp	w20, w19
    97bc:	54000ca0 	b.eq	9950 <fwp_hof0.constprop.0+0x400>  // b.none
    97c0:	f94046a0 	ldr	x0, [x21, #136]
    97c4:	8b334f18 	add	x24, x24, w19, uxtw #3
    97c8:	b9400363 	ldr	w3, [x27]
    97cc:	4b1a02d4 	sub	w20, w22, w26
    97d0:	aa1b03e6 	mov	x6, x27
    97d4:	8b031417 	add	x23, x0, x3, lsl #5
    97d8:	f9400ee0 	ldr	x0, [x23, #24]
    97dc:	b4001da0 	cbz	x0, 9b90 <fwp_hof0.constprop.0+0x640>
    97e0:	aa1b03f9 	mov	x25, x27
    97e4:	b94004c1 	ldr	w1, [x6, #4]
    97e8:	b94002fa 	ldr	w26, [x23]
    97ec:	0b010296 	add	w22, w20, w1
    97f0:	6b16035f 	cmp	w26, w22
    97f4:	54002488 	b.hi	9c84 <fwp_hof0.constprop.0+0x734>  // b.pmore
    97f8:	7100003f 	cmp	w1, #0x0
    97fc:	4b010353 	sub	w19, w26, w1
    9800:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9804:	54fffce1 	b.ne	97a0 <fwp_hof0.constprop.0+0x250>  // b.any
    9808:	7100035f 	cmp	w26, #0x0
    980c:	910003e2 	mov	x2, sp
    9810:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    9814:	f81d83a2 	stur	x2, [x29, #-40]
    9818:	d37df084 	lsl	x4, x4, #3
    981c:	91003c84 	add	x4, x4, #0xf
    9820:	92704c87 	and	x7, x4, #0xfffff0000
    9824:	927c7c84 	and	x4, x4, #0xffffffff0
    9828:	cb2763e7 	sub	x7, sp, x7
    982c:	eb2763ff 	cmp	sp, x7
    9830:	540000a0 	b.eq	9844 <fwp_hof0.constprop.0+0x2f4>  // b.none
    9834:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9838:	f90203ff 	str	xzr, [sp, #1024]
    983c:	eb2763ff 	cmp	sp, x7
    9840:	54ffffa1 	b.ne	9834 <fwp_hof0.constprop.0+0x2e4>  // b.any
    9844:	92403c84 	and	x4, x4, #0xffff
    9848:	cb2463ff 	sub	sp, sp, x4
    984c:	f90003ff 	str	xzr, [sp]
    9850:	f110009f 	cmp	x4, #0x400
    9854:	54000043 	b.cc	985c <fwp_hof0.constprop.0+0x30c>  // b.lo, b.ul, b.last
    9858:	f90203ff 	str	xzr, [sp, #1024]
    985c:	910043fb 	add	x27, sp, #0x10
    9860:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9864:	910020c9 	add	x9, x6, #0x8
    9868:	d2800004 	mov	x4, #0x0                   	// #0
    986c:	340000c1 	cbz	w1, 9884 <fwp_hof0.constprop.0+0x334>
    9870:	f8646922 	ldr	x2, [x9, x4]
    9874:	f8246b62 	str	x2, [x27, x4]
    9878:	91002084 	add	x4, x4, #0x8
    987c:	eb04015f 	cmp	x10, x4
    9880:	54ffff81 	b.ne	9870 <fwp_hof0.constprop.0+0x320>  // b.any
    9884:	2a1303ea 	mov	w10, w19
    9888:	d2800004 	mov	x4, #0x0                   	// #0
    988c:	340000f3 	cbz	w19, 98a8 <fwp_hof0.constprop.0+0x358>
    9890:	0b040022 	add	w2, w1, w4
    9894:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9898:	91000484 	add	x4, x4, #0x1
    989c:	f8227b63 	str	x3, [x27, x2, lsl #3]
    98a0:	eb04015f 	cmp	x10, x4
    98a4:	54ffff61 	b.ne	9890 <fwp_hof0.constprop.0+0x340>  // b.any
    98a8:	f949db81 	ldr	x1, [x28, #5040]
    98ac:	f949ef84 	ldr	x4, [x28, #5080]
    98b0:	cb010321 	sub	x1, x25, x1
    98b4:	eb04403f 	cmp	x1, x4, lsl #16
    98b8:	540002e2 	b.cs	9914 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    98bc:	d350fc24 	lsr	x4, x1, #16
    98c0:	f949ff8a 	ldr	x10, [x28, #5112]
    98c4:	8b040884 	add	x4, x4, x4, lsl #2
    98c8:	d37df084 	lsl	x4, x4, #3
    98cc:	8b040149 	add	x9, x10, x4
    98d0:	f9401128 	ldr	x8, [x9, #32]
    98d4:	b4000208 	cbz	x8, 9914 <fwp_hof0.constprop.0+0x3c4>
    98d8:	38646944 	ldrb	w4, [x10, x4]
    98dc:	7100089f 	cmp	w4, #0x2
    98e0:	54001520 	b.eq	9b84 <fwp_hof0.constprop.0+0x634>  // b.none
    98e4:	7100049f 	cmp	w4, #0x1
    98e8:	54000161 	b.ne	9914 <fwp_hof0.constprop.0+0x3c4>  // b.any
    98ec:	2943112a 	ldp	w10, w4, [x9, #24]
    98f0:	92403c21 	and	x1, x1, #0xffff
    98f4:	9b0a7c21 	mul	x1, x1, x10
    98f8:	d360fc21 	lsr	x1, x1, #32
    98fc:	eb04003f 	cmp	x1, x4
    9900:	540000a2 	b.cs	9914 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    9904:	8b010108 	add	x8, x8, x1
    9908:	39400101 	ldrb	w1, [x8]
    990c:	7100043f 	cmp	w1, #0x1
    9910:	54001360 	b.eq	9b7c <fwp_hof0.constprop.0+0x62c>  // b.none
    9914:	f9400404 	ldr	x4, [x0, #8]
    9918:	52800021 	mov	w1, #0x1                   	// #1
    991c:	aa1903e0 	mov	x0, x25
    9920:	d63f0080 	blr	x4
    9924:	f9400ee1 	ldr	x1, [x23, #24]
    9928:	aa1b03e0 	mov	x0, x27
    992c:	f9400021 	ldr	x1, [x1]
    9930:	d63f0020 	blr	x1
    9934:	aa0003fb 	mov	x27, x0
    9938:	f85d83a0 	ldur	x0, [x29, #-40]
    993c:	9100001f 	mov	sp, x0
    9940:	aa1903e0 	mov	x0, x25
    9944:	97fff153 	bl	5e90 <fwp_closure_drop>
    9948:	6b13029f 	cmp	w20, w19
    994c:	54fff3a1 	b.ne	97c0 <fwp_hof0.constprop.0+0x270>  // b.any
    9950:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9954:	aa1b03f9 	mov	x25, x27
    9958:	b85c03b8 	ldur	w24, [x29, #-64]
    995c:	6b17031f 	cmp	w24, w23
    9960:	540014c3 	b.cc	9bf8 <fwp_hof0.constprop.0+0x6a8>  // b.lo, b.ul, b.last
    9964:	f85983a0 	ldur	x0, [x29, #-104]
    9968:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    996c:	f1000400 	subs	x0, x0, #0x1
    9970:	f81983a0 	stur	x0, [x29, #-104]
    9974:	54ffe661 	b.ne	9640 <fwp_hof0.constprop.0+0xf0>  // b.any
    9978:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe930>
    997c:	91102042 	add	x2, x2, #0x408
    9980:	aa1903e1 	mov	x1, x25
    9984:	aa1403e0 	mov	x0, x20
    9988:	aa1a03f8 	mov	x24, x26
    998c:	aa1903fb 	mov	x27, x25
    9990:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9994:	91014042 	add	x2, x2, #0x50
    9998:	52800023 	mov	w3, #0x1                   	// #1
    999c:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    99a0:	f81f03bf 	stur	xzr, [x29, #-16]
    99a4:	97fffaef 	bl	8560 <fwp_write>
    99a8:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    99ac:	90000020 	adrp	x0, d000 <__divti3+0x2f0>
    99b0:	913d2000 	add	x0, x0, #0xf48
    99b4:	f10002df 	cmp	x22, #0x0
    99b8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    99bc:	b1002b3f 	cmn	x25, #0xa
    99c0:	540039c8 	b.hi	a0f8 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    99c4:	91002720 	add	x0, x25, #0x9
    99c8:	52800021 	mov	w1, #0x1                   	// #1
    99cc:	97ffed49 	bl	4ef0 <fwp_heap_alloc>
    99d0:	aa0003f3 	mov	x19, x0
    99d4:	aa1603e1 	mov	x1, x22
    99d8:	aa0003f6 	mov	x22, x0
    99dc:	aa1903e2 	mov	x2, x25
    99e0:	f80086d9 	str	x25, [x22], #8
    99e4:	8b190279 	add	x25, x19, x25
    99e8:	aa1603e0 	mov	x0, x22
    99ec:	97ffe339 	bl	26d0 <memcpy@plt>
    99f0:	3900233f 	strb	wzr, [x25, #8]
    99f4:	f85e03a0 	ldur	x0, [x29, #-32]
    99f8:	97ffe3d2 	bl	2940 <free@plt>
    99fc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9a00:	91174002 	add	x2, x0, #0x5d0
    9a04:	f949d841 	ldr	x1, [x2, #5040]
    9a08:	f949ec40 	ldr	x0, [x2, #5080]
    9a0c:	cb010261 	sub	x1, x19, x1
    9a10:	eb00403f 	cmp	x1, x0, lsl #16
    9a14:	54000322 	b.cs	9a78 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9a18:	d350fc20 	lsr	x0, x1, #16
    9a1c:	f949fc43 	ldr	x3, [x2, #5112]
    9a20:	8b000800 	add	x0, x0, x0, lsl #2
    9a24:	d37df002 	lsl	x2, x0, #3
    9a28:	8b020060 	add	x0, x3, x2
    9a2c:	f9401019 	ldr	x25, [x0, #32]
    9a30:	b4000259 	cbz	x25, 9a78 <fwp_hof0.constprop.0+0x528>
    9a34:	38626862 	ldrb	w2, [x3, x2]
    9a38:	7100085f 	cmp	w2, #0x2
    9a3c:	54003220 	b.eq	a080 <fwp_hof0.constprop.0+0xb30>  // b.none
    9a40:	7100045f 	cmp	w2, #0x1
    9a44:	540001a1 	b.ne	9a78 <fwp_hof0.constprop.0+0x528>  // b.any
    9a48:	29430002 	ldp	w2, w0, [x0, #24]
    9a4c:	92403c21 	and	x1, x1, #0xffff
    9a50:	9b027c21 	mul	x1, x1, x2
    9a54:	d360fc21 	lsr	x1, x1, #32
    9a58:	eb00003f 	cmp	x1, x0
    9a5c:	540000e2 	b.cs	9a78 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9a60:	8b010339 	add	x25, x25, x1
    9a64:	39400320 	ldrb	w0, [x25]
    9a68:	7103fc1f 	cmp	w0, #0xff
    9a6c:	54003520 	b.eq	a110 <fwp_hof0.constprop.0+0xbc0>  // b.none
    9a70:	52800020 	mov	w0, #0x1                   	// #1
    9a74:	39000320 	strb	w0, [x25]
    9a78:	aa1b03e0 	mov	x0, x27
    9a7c:	97fff055 	bl	5bd0 <fwp_drop0>
    9a80:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a84:	9101c003 	add	x3, x0, #0x70
    9a88:	f9400262 	ldr	x2, [x19]
    9a8c:	aa1603e0 	mov	x0, x22
    9a90:	aa0303f6 	mov	x22, x3
    9a94:	d2800021 	mov	x1, #0x1                   	// #1
    9a98:	f9400463 	ldr	x3, [x3, #8]
    9a9c:	97ffe3b9 	bl	2980 <fwrite@plt>
    9aa0:	f94006c1 	ldr	x1, [x22, #8]
    9aa4:	52800140 	mov	w0, #0xa                   	// #10
    9aa8:	97ffe33e 	bl	27a0 <fputc@plt>
    9aac:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ab0:	91174002 	add	x2, x0, #0x5d0
    9ab4:	f949d841 	ldr	x1, [x2, #5040]
    9ab8:	f949ec40 	ldr	x0, [x2, #5080]
    9abc:	cb010261 	sub	x1, x19, x1
    9ac0:	eb00403f 	cmp	x1, x0, lsl #16
    9ac4:	54000382 	b.cs	9b34 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9ac8:	d350fc20 	lsr	x0, x1, #16
    9acc:	f949fc43 	ldr	x3, [x2, #5112]
    9ad0:	8b000800 	add	x0, x0, x0, lsl #2
    9ad4:	d37df000 	lsl	x0, x0, #3
    9ad8:	8b000062 	add	x2, x3, x0
    9adc:	f9401056 	ldr	x22, [x2, #32]
    9ae0:	b40002b6 	cbz	x22, 9b34 <fwp_hof0.constprop.0+0x5e4>
    9ae4:	38606860 	ldrb	w0, [x3, x0]
    9ae8:	7100081f 	cmp	w0, #0x2
    9aec:	54002c40 	b.eq	a074 <fwp_hof0.constprop.0+0xb24>  // b.none
    9af0:	7100041f 	cmp	w0, #0x1
    9af4:	54000201 	b.ne	9b34 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9af8:	29430043 	ldp	w3, w0, [x2, #24]
    9afc:	92403c21 	and	x1, x1, #0xffff
    9b00:	9b037c21 	mul	x1, x1, x3
    9b04:	d360fc21 	lsr	x1, x1, #32
    9b08:	eb00003f 	cmp	x1, x0
    9b0c:	54000142 	b.cs	9b34 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9b10:	8b0102d6 	add	x22, x22, x1
    9b14:	394002c0 	ldrb	w0, [x22]
    9b18:	340000e0 	cbz	w0, 9b34 <fwp_hof0.constprop.0+0x5e4>
    9b1c:	7100041f 	cmp	w0, #0x1
    9b20:	54002a00 	b.eq	a060 <fwp_hof0.constprop.0+0xb10>  // b.none
    9b24:	7103fc1f 	cmp	w0, #0xff
    9b28:	54002b20 	b.eq	a08c <fwp_hof0.constprop.0+0xb3c>  // b.none
    9b2c:	51000400 	sub	w0, w0, #0x1
    9b30:	390002c0 	strb	w0, [x22]
    9b34:	f9400b5a 	ldr	x26, [x26, #16]
    9b38:	b5ffd3ba 	cbnz	x26, 95ac <fwp_hof0.constprop.0+0x5c>
    9b3c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9b40:	f947f400 	ldr	x0, [x0, #4072]
    9b44:	f85f83a2 	ldur	x2, [x29, #-8]
    9b48:	f9400001 	ldr	x1, [x0]
    9b4c:	eb010042 	subs	x2, x2, x1
    9b50:	d2800001 	mov	x1, #0x0                   	// #0
    9b54:	54002dc1 	b.ne	a10c <fwp_hof0.constprop.0+0xbbc>  // b.any
    9b58:	910003bf 	mov	sp, x29
    9b5c:	d2800000 	mov	x0, #0x0                   	// #0
    9b60:	a94153f3 	ldp	x19, x20, [sp, #16]
    9b64:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9b68:	a94363f7 	ldp	x23, x24, [sp, #48]
    9b6c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9b70:	a94573fb 	ldp	x27, x28, [sp, #80]
    9b74:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9b78:	d65f03c0 	ret
    9b7c:	b90004df 	str	wzr, [x6, #4]
    9b80:	17ffff69 	b	9924 <fwp_hof0.constprop.0+0x3d4>
    9b84:	72003c3f 	tst	w1, #0xffff
    9b88:	54ffec61 	b.ne	9914 <fwp_hof0.constprop.0+0x3c4>  // b.any
    9b8c:	17ffff5f 	b	9908 <fwp_hof0.constprop.0+0x3b8>
    9b90:	aa1b03fc 	mov	x28, x27
    9b94:	aa1803fb 	mov	x27, x24
    9b98:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9b9c:	b85c03b8 	ldur	w24, [x29, #-64]
    9ba0:	aa1c03e0 	mov	x0, x28
    9ba4:	b81d83a7 	stur	w7, [x29, #-40]
    9ba8:	97ffeede 	bl	5720 <fwp_rc_share>
    9bac:	b85d83a7 	ldur	w7, [x29, #-40]
    9bb0:	34000134 	cbz	w20, 9bd4 <fwp_hof0.constprop.0+0x684>
    9bb4:	aa1b03f6 	mov	x22, x27
    9bb8:	8b344f73 	add	x19, x27, w20, uxtw #3
    9bbc:	2a0703f9 	mov	w25, w7
    9bc0:	f84086c0 	ldr	x0, [x22], #8
    9bc4:	97ffeed7 	bl	5720 <fwp_rc_share>
    9bc8:	eb16027f 	cmp	x19, x22
    9bcc:	54ffffa1 	b.ne	9bc0 <fwp_hof0.constprop.0+0x670>  // b.any
    9bd0:	2a1903e7 	mov	w7, w25
    9bd4:	aa1b03e2 	mov	x2, x27
    9bd8:	2a1403e1 	mov	w1, w20
    9bdc:	aa1c03e0 	mov	x0, x28
    9be0:	b81d83a7 	stur	w7, [x29, #-40]
    9be4:	97ffed08 	bl	5004 <fwp_apply>
    9be8:	aa0003f9 	mov	x25, x0
    9bec:	b85d83a7 	ldur	w7, [x29, #-40]
    9bf0:	6b17031f 	cmp	w24, w23
    9bf4:	54ffeb82 	b.cs	9964 <fwp_hof0.constprop.0+0x414>  // b.hs, b.nlast
    9bf8:	f94046a1 	ldr	x1, [x21, #136]
    9bfc:	4b0702f7 	sub	w23, w23, w7
    9c00:	b9400323 	ldr	w3, [x25]
    9c04:	f85d03a0 	ldur	x0, [x29, #-48]
    9c08:	8b031423 	add	x3, x1, x3, lsl #5
    9c0c:	b85c83a2 	ldur	w2, [x29, #-56]
    9c10:	8b274c00 	add	x0, x0, w7, uxtw #3
    9c14:	f81d03a0 	stur	x0, [x29, #-48]
    9c18:	f9400c61 	ldr	x1, [x3, #24]
    9c1c:	b85cc3a0 	ldur	w0, [x29, #-52]
    9c20:	4b020000 	sub	w0, w0, w2
    9c24:	b81cc3a0 	stur	w0, [x29, #-52]
    9c28:	aa1903e0 	mov	x0, x25
    9c2c:	b5ffd761 	cbnz	x1, 9718 <fwp_hof0.constprop.0+0x1c8>
    9c30:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9c34:	aa1903e0 	mov	x0, x25
    9c38:	97ffeeba 	bl	5720 <fwp_rc_share>
    9c3c:	34000117 	cbz	w23, 9c5c <fwp_hof0.constprop.0+0x70c>
    9c40:	f85d03b8 	ldur	x24, [x29, #-48]
    9c44:	d2800016 	mov	x22, #0x0                   	// #0
    9c48:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    9c4c:	910006d6 	add	x22, x22, #0x1
    9c50:	97ffeeb4 	bl	5720 <fwp_rc_share>
    9c54:	6b1602ff 	cmp	w23, w22
    9c58:	54ffff88 	b.hi	9c48 <fwp_hof0.constprop.0+0x6f8>  // b.pmore
    9c5c:	f85d03a2 	ldur	x2, [x29, #-48]
    9c60:	aa1903e0 	mov	x0, x25
    9c64:	2a1703e1 	mov	w1, w23
    9c68:	97ffece7 	bl	5004 <fwp_apply>
    9c6c:	aa0003f9 	mov	x25, x0
    9c70:	f85983a0 	ldur	x0, [x29, #-104]
    9c74:	f1000400 	subs	x0, x0, #0x1
    9c78:	f81983a0 	stur	x0, [x29, #-104]
    9c7c:	54ffce21 	b.ne	9640 <fwp_hof0.constprop.0+0xf0>  // b.any
    9c80:	17ffff3e 	b	9978 <fwp_hof0.constprop.0+0x428>
    9c84:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9c88:	9117400a 	add	x10, x0, #0x5d0
    9c8c:	2a0103fc 	mov	w28, w1
    9c90:	110006c0 	add	w0, w22, #0x1
    9c94:	f120001f 	cmp	x0, #0x800
    9c98:	aa1703fa 	mov	x26, x23
    9c9c:	b953a541 	ldr	w1, [x10, #5028]
    9ca0:	aa1803fb 	mov	x27, x24
    9ca4:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9ca8:	d37df000 	lsl	x0, x0, #3
    9cac:	b85c03b8 	ldur	w24, [x29, #-64]
    9cb0:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9cb4:	54001860 	b.eq	9fc0 <fwp_hof0.constprop.0+0xa70>  // b.none
    9cb8:	91003c01 	add	x1, x0, #0xf
    9cbc:	8b411141 	add	x1, x10, x1, lsr #4
    9cc0:	397e8021 	ldrb	w1, [x1, #4000]
    9cc4:	910f002b 	add	x11, x1, #0x3c0
    9cc8:	8b010429 	add	x9, x1, x1, lsl #1
    9ccc:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    9cd0:	8b090d4c 	add	x12, x10, x9, lsl #3
    9cd4:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    9cd8:	2a0b03e1 	mov	w1, w11
    9cdc:	b4001613 	cbz	x19, 9f9c <fwp_hof0.constprop.0+0xa4c>
    9ce0:	f940026c 	ldr	x12, [x19]
    9ce4:	aa2c03ec 	mvn	x12, x12
    9ce8:	f829794c 	str	x12, [x10, x9, lsl #3]
    9cec:	eb01001f 	cmp	x0, x1
    9cf0:	540000c2 	b.cs	9d08 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    9cf4:	d503201f 	nop
    9cf8:	f8206a7f 	str	xzr, [x19, x0]
    9cfc:	91002000 	add	x0, x0, #0x8
    9d00:	eb00003f 	cmp	x1, x0
    9d04:	54ffffa8 	b.hi	9cf8 <fwp_hof0.constprop.0+0x7a8>  // b.pmore
    9d08:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9d0c:	91174009 	add	x9, x0, #0x5d0
    9d10:	f94a1120 	ldr	x0, [x9, #5152]
    9d14:	ab010000 	adds	x0, x0, x1
    9d18:	54001e82 	b.cs	a0e8 <fwp_hof0.constprop.0+0xb98>  // b.hs, b.nlast
    9d1c:	f94a1521 	ldr	x1, [x9, #5160]
    9d20:	f90a1120 	str	x0, [x9, #5152]
    9d24:	eb01001f 	cmp	x0, x1
    9d28:	54000049 	b.ls	9d30 <fwp_hof0.constprop.0+0x7e0>  // b.plast
    9d2c:	f90a1520 	str	x0, [x9, #5160]
    9d30:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9d34:	91174000 	add	x0, x0, #0x5d0
    9d38:	1e630161 	ucvtf	d1, w11
    9d3c:	fd4a1c00 	ldr	d0, [x0, #5176]
    9d40:	1e612800 	fadd	d0, d0, d1
    9d44:	fd0a1c00 	str	d0, [x0, #5176]
    9d48:	b94000c0 	ldr	w0, [x6]
    9d4c:	29005a60 	stp	w0, w22, [x19]
    9d50:	3400013c 	cbz	w28, 9d74 <fwp_hof0.constprop.0+0x824>
    9d54:	910020c1 	add	x1, x6, #0x8
    9d58:	d37d7f82 	ubfiz	x2, x28, #3, #32
    9d5c:	91002260 	add	x0, x19, #0x8
    9d60:	b81c03a7 	stur	w7, [x29, #-64]
    9d64:	f81d83a6 	stur	x6, [x29, #-40]
    9d68:	97ffe262 	bl	26f0 <memmove@plt>
    9d6c:	f85d83a6 	ldur	x6, [x29, #-40]
    9d70:	b85c03a7 	ldur	w7, [x29, #-64]
    9d74:	2a1403e9 	mov	w9, w20
    9d78:	d2800001 	mov	x1, #0x0                   	// #0
    9d7c:	34000114 	cbz	w20, 9d9c <fwp_hof0.constprop.0+0x84c>
    9d80:	0b010380 	add	w0, w28, w1
    9d84:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9d88:	8b000e60 	add	x0, x19, x0, lsl #3
    9d8c:	91000421 	add	x1, x1, #0x1
    9d90:	f9000402 	str	x2, [x0, #8]
    9d94:	eb01013f 	cmp	x9, x1
    9d98:	54ffff41 	b.ne	9d80 <fwp_hof0.constprop.0+0x830>  // b.any
    9d9c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9da0:	91174002 	add	x2, x0, #0x5d0
    9da4:	f949d840 	ldr	x0, [x2, #5040]
    9da8:	f949ec41 	ldr	x1, [x2, #5080]
    9dac:	cb000320 	sub	x0, x25, x0
    9db0:	eb01401f 	cmp	x0, x1, lsl #16
    9db4:	540002e2 	b.cs	9e10 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9db8:	d350fc01 	lsr	x1, x0, #16
    9dbc:	f949fc45 	ldr	x5, [x2, #5112]
    9dc0:	8b010821 	add	x1, x1, x1, lsl #2
    9dc4:	d37df021 	lsl	x1, x1, #3
    9dc8:	8b0100a4 	add	x4, x5, x1
    9dcc:	f9401082 	ldr	x2, [x4, #32]
    9dd0:	b4000202 	cbz	x2, 9e10 <fwp_hof0.constprop.0+0x8c0>
    9dd4:	386168a1 	ldrb	w1, [x5, x1]
    9dd8:	7100083f 	cmp	w1, #0x2
    9ddc:	54001020 	b.eq	9fe0 <fwp_hof0.constprop.0+0xa90>  // b.none
    9de0:	7100043f 	cmp	w1, #0x1
    9de4:	54000161 	b.ne	9e10 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9de8:	29430485 	ldp	w5, w1, [x4, #24]
    9dec:	92403c00 	and	x0, x0, #0xffff
    9df0:	9b057c00 	mul	x0, x0, x5
    9df4:	d360fc00 	lsr	x0, x0, #32
    9df8:	eb01001f 	cmp	x0, x1
    9dfc:	540000a2 	b.cs	9e10 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9e00:	8b000042 	add	x2, x2, x0
    9e04:	39400040 	ldrb	w0, [x2]
    9e08:	7100041f 	cmp	w0, #0x1
    9e0c:	54000be0 	b.eq	9f88 <fwp_hof0.constprop.0+0xa38>  // b.none
    9e10:	f9400f42 	ldr	x2, [x26, #24]
    9e14:	aa1903e0 	mov	x0, x25
    9e18:	52800021 	mov	w1, #0x1                   	// #1
    9e1c:	b81d83a7 	stur	w7, [x29, #-40]
    9e20:	f9400442 	ldr	x2, [x2, #8]
    9e24:	d63f0040 	blr	x2
    9e28:	b85d83a7 	ldur	w7, [x29, #-40]
    9e2c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9e30:	91174002 	add	x2, x0, #0x5d0
    9e34:	f949d841 	ldr	x1, [x2, #5040]
    9e38:	f949ec40 	ldr	x0, [x2, #5080]
    9e3c:	cb010261 	sub	x1, x19, x1
    9e40:	eb00403f 	cmp	x1, x0, lsl #16
    9e44:	54000322 	b.cs	9ea8 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9e48:	d350fc20 	lsr	x0, x1, #16
    9e4c:	f949fc43 	ldr	x3, [x2, #5112]
    9e50:	8b000800 	add	x0, x0, x0, lsl #2
    9e54:	d37df002 	lsl	x2, x0, #3
    9e58:	8b020060 	add	x0, x3, x2
    9e5c:	f9401014 	ldr	x20, [x0, #32]
    9e60:	b4000254 	cbz	x20, 9ea8 <fwp_hof0.constprop.0+0x958>
    9e64:	38626862 	ldrb	w2, [x3, x2]
    9e68:	7100085f 	cmp	w2, #0x2
    9e6c:	54000c00 	b.eq	9fec <fwp_hof0.constprop.0+0xa9c>  // b.none
    9e70:	7100045f 	cmp	w2, #0x1
    9e74:	540001a1 	b.ne	9ea8 <fwp_hof0.constprop.0+0x958>  // b.any
    9e78:	29430002 	ldp	w2, w0, [x0, #24]
    9e7c:	92403c21 	and	x1, x1, #0xffff
    9e80:	9b027c21 	mul	x1, x1, x2
    9e84:	d360fc21 	lsr	x1, x1, #32
    9e88:	eb00003f 	cmp	x1, x0
    9e8c:	540000e2 	b.cs	9ea8 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9e90:	8b010294 	add	x20, x20, x1
    9e94:	39400280 	ldrb	w0, [x20]
    9e98:	7103fc1f 	cmp	w0, #0xff
    9e9c:	54000b20 	b.eq	a000 <fwp_hof0.constprop.0+0xab0>  // b.none
    9ea0:	52800020 	mov	w0, #0x1                   	// #1
    9ea4:	39000280 	strb	w0, [x20]
    9ea8:	aa1903e0 	mov	x0, x25
    9eac:	b81d83a7 	stur	w7, [x29, #-40]
    9eb0:	97ffeff8 	bl	5e90 <fwp_closure_drop>
    9eb4:	aa1303f9 	mov	x25, x19
    9eb8:	b85d83a7 	ldur	w7, [x29, #-40]
    9ebc:	17ffff4d 	b	9bf0 <fwp_hof0.constprop.0+0x6a0>
    9ec0:	b8626860 	ldr	w0, [x3, x2]
    9ec4:	b94004a2 	ldr	w2, [x5, #4]
    9ec8:	4b020003 	sub	w3, w0, w2
    9ecc:	7100047f 	cmp	w3, #0x1
    9ed0:	54ffbd01 	b.ne	9670 <fwp_hof0.constprop.0+0x120>  // b.any
    9ed4:	910003f6 	mov	x22, sp
    9ed8:	34000a22 	cbz	w2, a01c <fwp_hof0.constprop.0+0xacc>
    9edc:	7100001f 	cmp	w0, #0x0
    9ee0:	d37d7c00 	ubfiz	x0, x0, #3, #32
    9ee4:	d2800101 	mov	x1, #0x8                   	// #8
    9ee8:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    9eec:	91003ee0 	add	x0, x23, #0xf
    9ef0:	92704c01 	and	x1, x0, #0xfffff0000
    9ef4:	927c7c00 	and	x0, x0, #0xffffffff0
    9ef8:	cb2163e1 	sub	x1, sp, x1
    9efc:	eb2163ff 	cmp	sp, x1
    9f00:	540000a0 	b.eq	9f14 <fwp_hof0.constprop.0+0x9c4>  // b.none
    9f04:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9f08:	f90203ff 	str	xzr, [sp, #1024]
    9f0c:	eb2163ff 	cmp	sp, x1
    9f10:	54ffffa1 	b.ne	9f04 <fwp_hof0.constprop.0+0x9b4>  // b.any
    9f14:	92403c00 	and	x0, x0, #0xffff
    9f18:	cb2063ff 	sub	sp, sp, x0
    9f1c:	f90003ff 	str	xzr, [sp]
    9f20:	f110001f 	cmp	x0, #0x400
    9f24:	54000043 	b.cc	9f2c <fwp_hof0.constprop.0+0x9dc>  // b.lo, b.ul, b.last
    9f28:	f90203ff 	str	xzr, [sp, #1024]
    9f2c:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    9f30:	910043f8 	add	x24, sp, #0x10
    9f34:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f38:	91004001 	add	x1, x0, #0x10
    9f3c:	aa1c03e2 	mov	x2, x28
    9f40:	91012021 	add	x1, x1, #0x48
    9f44:	aa1703e3 	mov	x3, x23
    9f48:	aa1803e0 	mov	x0, x24
    9f4c:	97ffe221 	bl	27d0 <__memcpy_chk@plt>
    9f50:	eb1c02ff 	cmp	x23, x28
    9f54:	aa1403e1 	mov	x1, x20
    9f58:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    9f5c:	d2800102 	mov	x2, #0x8                   	// #8
    9f60:	cb1c0063 	sub	x3, x3, x28
    9f64:	8b1c0300 	add	x0, x24, x28
    9f68:	97ffe21a 	bl	27d0 <__memcpy_chk@plt>
    9f6c:	f9400f61 	ldr	x1, [x27, #24]
    9f70:	aa1803e0 	mov	x0, x24
    9f74:	f9400021 	ldr	x1, [x1]
    9f78:	d63f0020 	blr	x1
    9f7c:	aa0003f9 	mov	x25, x0
    9f80:	910002df 	mov	sp, x22
    9f84:	17ffff3b 	b	9c70 <fwp_hof0.constprop.0+0x720>
    9f88:	b90004df 	str	wzr, [x6, #4]
    9f8c:	17ffffa8 	b	9e2c <fwp_hof0.constprop.0+0x8dc>
    9f90:	72003c3f 	tst	w1, #0xffff
    9f94:	54ffbae1 	b.ne	96f0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    9f98:	17fffdd0 	b	96d8 <fwp_hof0.constprop.0+0x188>
    9f9c:	f9400593 	ldr	x19, [x12, #8]
    9fa0:	b4000113 	cbz	x19, 9fc0 <fwp_hof0.constprop.0+0xa70>
    9fa4:	f9400989 	ldr	x9, [x12, #16]
    9fa8:	cb130129 	sub	x9, x9, x19
    9fac:	eb09003f 	cmp	x1, x9
    9fb0:	54000088 	b.hi	9fc0 <fwp_hof0.constprop.0+0xa70>  // b.pmore
    9fb4:	8b010269 	add	x9, x19, x1
    9fb8:	f9000589 	str	x9, [x12, #8]
    9fbc:	17ffff4c 	b	9cec <fwp_hof0.constprop.0+0x79c>
    9fc0:	52800001 	mov	w1, #0x0                   	// #0
    9fc4:	f81c03a6 	stur	x6, [x29, #-64]
    9fc8:	b81d83a7 	stur	w7, [x29, #-40]
    9fcc:	97ffebc9 	bl	4ef0 <fwp_heap_alloc>
    9fd0:	f85c03a6 	ldur	x6, [x29, #-64]
    9fd4:	aa0003f3 	mov	x19, x0
    9fd8:	b85d83a7 	ldur	w7, [x29, #-40]
    9fdc:	17ffff5b 	b	9d48 <fwp_hof0.constprop.0+0x7f8>
    9fe0:	72003c1f 	tst	w0, #0xffff
    9fe4:	54fff161 	b.ne	9e10 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9fe8:	17ffff87 	b	9e04 <fwp_hof0.constprop.0+0x8b4>
    9fec:	72003c3f 	tst	w1, #0xffff
    9ff0:	54fff5c1 	b.ne	9ea8 <fwp_hof0.constprop.0+0x958>  // b.any
    9ff4:	39400280 	ldrb	w0, [x20]
    9ff8:	7103fc1f 	cmp	w0, #0xff
    9ffc:	54fff521 	b.ne	9ea0 <fwp_hof0.constprop.0+0x950>  // b.any
    a000:	aa1403e0 	mov	x0, x20
    a004:	b81d83a7 	stur	w7, [x29, #-40]
    a008:	97ffe9fa 	bl	47f0 <fwp_rc_forget_slot>
    a00c:	b85d83a7 	ldur	w7, [x29, #-40]
    a010:	17ffffa4 	b	9ea0 <fwp_hof0.constprop.0+0x950>
    a014:	97ffe9b0 	bl	46d4 <fwp_rc_wide_dup>
    a018:	17fffdb6 	b	96f0 <fwp_hof0.constprop.0+0x1a0>
    a01c:	f9400021 	ldr	x1, [x1]
    a020:	aa1403e0 	mov	x0, x20
    a024:	d63f0020 	blr	x1
    a028:	aa0003f9 	mov	x25, x0
    a02c:	910002df 	mov	sp, x22
    a030:	17ffff10 	b	9c70 <fwp_hof0.constprop.0+0x720>
    a034:	72003c3f 	tst	w1, #0xffff
    a038:	54ffafa1 	b.ne	962c <fwp_hof0.constprop.0+0xdc>  // b.any
    a03c:	17fffd76 	b	9614 <fwp_hof0.constprop.0+0xc4>
    a040:	aa1a03e0 	mov	x0, x26
    a044:	97ffedb7 	bl	5720 <fwp_rc_share>
    a048:	aa1903e0 	mov	x0, x25
    a04c:	52800037 	mov	w23, #0x1                   	// #1
    a050:	97ffedb4 	bl	5720 <fwp_rc_share>
    a054:	aa1a03f9 	mov	x25, x26
    a058:	f81d03b4 	stur	x20, [x29, #-48]
    a05c:	17ffff00 	b	9c5c <fwp_hof0.constprop.0+0x70c>
    a060:	aa1303e0 	mov	x0, x19
    a064:	97ffee04 	bl	5874 <fwp_rc_free_arr>
    a068:	f9400b5a 	ldr	x26, [x26, #16]
    a06c:	b5ffaa1a 	cbnz	x26, 95ac <fwp_hof0.constprop.0+0x5c>
    a070:	17fffeb3 	b	9b3c <fwp_hof0.constprop.0+0x5ec>
    a074:	72003c3f 	tst	w1, #0xffff
    a078:	54ffd5e1 	b.ne	9b34 <fwp_hof0.constprop.0+0x5e4>  // b.any
    a07c:	17fffea6 	b	9b14 <fwp_hof0.constprop.0+0x5c4>
    a080:	72003c3f 	tst	w1, #0xffff
    a084:	54ffcfa1 	b.ne	9a78 <fwp_hof0.constprop.0+0x528>  // b.any
    a088:	17fffe77 	b	9a64 <fwp_hof0.constprop.0+0x514>
    a08c:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a090:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a094:	91174021 	add	x1, x1, #0x5d0
    a098:	ca402400 	eor	x0, x0, x0, lsr #9
    a09c:	8b200c20 	add	x0, x1, w0, uxtb #3
    a0a0:	f94a2400 	ldr	x0, [x0, #5192]
    a0a4:	b5000080 	cbnz	x0, a0b4 <fwp_hof0.constprop.0+0xb64>
    a0a8:	14000011 	b	a0ec <fwp_hof0.constprop.0+0xb9c>
    a0ac:	f9400800 	ldr	x0, [x0, #16]
    a0b0:	b40001e0 	cbz	x0, a0ec <fwp_hof0.constprop.0+0xb9c>
    a0b4:	f9400001 	ldr	x1, [x0]
    a0b8:	eb0102df 	cmp	x22, x1
    a0bc:	54ffff81 	b.ne	a0ac <fwp_hof0.constprop.0+0xb5c>  // b.any
    a0c0:	f9400401 	ldr	x1, [x0, #8]
    a0c4:	d1000421 	sub	x1, x1, #0x1
    a0c8:	f9000401 	str	x1, [x0, #8]
    a0cc:	f103f83f 	cmp	x1, #0xfe
    a0d0:	54ffd321 	b.ne	9b34 <fwp_hof0.constprop.0+0x5e4>  // b.any
    a0d4:	aa1603e0 	mov	x0, x22
    a0d8:	97ffe9c6 	bl	47f0 <fwp_rc_forget_slot>
    a0dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a0e0:	390002c0 	strb	w0, [x22]
    a0e4:	17fffe94 	b	9b34 <fwp_hof0.constprop.0+0x5e4>
    a0e8:	97ffe3d2 	bl	3030 <fwp_heap_oom>
    a0ec:	f0000000 	adrp	x0, d000 <__divti3+0x2f0>
    a0f0:	911e4000 	add	x0, x0, #0x790
    a0f4:	97ffe5c3 	bl	3800 <fwp_trap>
    a0f8:	f0000000 	adrp	x0, d000 <__divti3+0x2f0>
    a0fc:	912a2000 	add	x0, x0, #0xa88
    a100:	97ffe5c0 	bl	3800 <fwp_trap>
    a104:	97ffe974 	bl	46d4 <fwp_rc_wide_dup>
    a108:	17fffd49 	b	962c <fwp_hof0.constprop.0+0xdc>
    a10c:	97ffe1dd 	bl	2880 <__stack_chk_fail@plt>
    a110:	aa1903e0 	mov	x0, x25
    a114:	97ffe9b7 	bl	47f0 <fwp_rc_forget_slot>
    a118:	17fffe56 	b	9a70 <fwp_hof0.constprop.0+0x520>
    a11c:	d503201f 	nop

000000000000a120 <f0>:
    a120:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a124:	910003fd 	mov	x29, sp
    a128:	a90153f3 	stp	x19, x20, [sp, #16]
    a12c:	a9025bf5 	stp	x21, x22, [sp, #32]
    a130:	a90363f7 	stp	x23, x24, [sp, #48]
    a134:	a9046bf9 	stp	x25, x26, [sp, #64]
    a138:	a90573fb 	stp	x27, x28, [sp, #80]
    a13c:	d12183ff 	sub	sp, sp, #0x860
    a140:	f90203ff 	str	xzr, [sp, #1024]
    a144:	d00000a0 	adrp	x0, 20000 <__data_start>
    a148:	9101c005 	add	x5, x0, #0x70
    a14c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a150:	f947f400 	ldr	x0, [x0, #4072]
    a154:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc10>
    a158:	f94188a6 	ldr	x6, [x5, #784]
    a15c:	f9400001 	ldr	x1, [x0]
    a160:	f9042fe1 	str	x1, [sp, #2136]
    a164:	d2800001 	mov	x1, #0x0                   	// #0
    a168:	91174298 	add	x24, x20, #0x5d0
    a16c:	912123f6 	add	x22, sp, #0x848
    a170:	910023e0 	add	x0, sp, #0x8
    a174:	910083e2 	add	x2, sp, #0x20
    a178:	f0ffffc1 	adrp	x1, 5000 <fwp_heap_alloc+0x110>
    a17c:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a180:	91350021 	add	x1, x1, #0xd40
    a184:	913d4084 	add	x4, x4, #0xf50
    a188:	d2800013 	mov	x19, #0x0                   	// #0
    a18c:	d2800119 	mov	x25, #0x8                   	// #8
    a190:	d2800015 	mov	x21, #0x0                   	// #0
    a194:	52800037 	mov	w23, #0x1                   	// #1
    a198:	a90093e6 	stp	x6, x4, [sp, #8]
    a19c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a1a0:	a90307ff 	stp	xzr, x1, [sp, #48]
    a1a4:	f90188a0 	str	x0, [x5, #784]
    a1a8:	f100073a 	subs	x26, x25, #0x1
    a1ac:	aa1603e1 	mov	x1, x22
    a1b0:	da1f02bc 	sbc	x28, x21, xzr
    a1b4:	52800020 	mov	w0, #0x1                   	// #1
    a1b8:	f90017fa 	str	x26, [sp, #40]
    a1bc:	aa1a03f9 	mov	x25, x26
    a1c0:	f90427fa 	str	x26, [sp, #2120]
    a1c4:	aa1c03f5 	mov	x21, x28
    a1c8:	f9042bf3 	str	x19, [sp, #2128]
    a1cc:	97ffed0d 	bl	5600 <fwp_data.part.0.constprop.0>
    a1d0:	f949db02 	ldr	x2, [x24, #5040]
    a1d4:	aa0003f3 	mov	x19, x0
    a1d8:	f949ef00 	ldr	x0, [x24, #5080]
    a1dc:	cb020262 	sub	x2, x19, x2
    a1e0:	eb00405f 	cmp	x2, x0, lsl #16
    a1e4:	54000302 	b.cs	a244 <f0+0x124>  // b.hs, b.nlast
    a1e8:	d350fc40 	lsr	x0, x2, #16
    a1ec:	f949ff04 	ldr	x4, [x24, #5112]
    a1f0:	8b000800 	add	x0, x0, x0, lsl #2
    a1f4:	d37df001 	lsl	x1, x0, #3
    a1f8:	8b010080 	add	x0, x4, x1
    a1fc:	f940101b 	ldr	x27, [x0, #32]
    a200:	b400023b 	cbz	x27, a244 <f0+0x124>
    a204:	38616881 	ldrb	w1, [x4, x1]
    a208:	7100083f 	cmp	w1, #0x2
    a20c:	54010e80 	b.eq	c3dc <f0+0x22bc>  // b.none
    a210:	7100043f 	cmp	w1, #0x1
    a214:	54000181 	b.ne	a244 <f0+0x124>  // b.any
    a218:	29430001 	ldp	w1, w0, [x0, #24]
    a21c:	92403c42 	and	x2, x2, #0xffff
    a220:	9b017c42 	mul	x2, x2, x1
    a224:	d360fc42 	lsr	x2, x2, #32
    a228:	eb00005f 	cmp	x2, x0
    a22c:	540000c2 	b.cs	a244 <f0+0x124>  // b.hs, b.nlast
    a230:	8b02037b 	add	x27, x27, x2
    a234:	39400360 	ldrb	w0, [x27]
    a238:	7103fc1f 	cmp	w0, #0xff
    a23c:	54010ca0 	b.eq	c3d0 <f0+0x22b0>  // b.none
    a240:	39000377 	strb	w23, [x27]
    a244:	f90013f3 	str	x19, [sp, #32]
    a248:	aa1c035a 	orr	x26, x26, x28
    a24c:	b5fffafa 	cbnz	x26, a1a8 <f0+0x88>
    a250:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xbd0>
    a254:	910103e1 	add	x1, sp, #0x40
    a258:	f94007e2 	ldr	x2, [sp, #8]
    a25c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a260:	3dc08460 	ldr	q0, [x3, #528]
    a264:	9101c018 	add	x24, x0, #0x70
    a268:	52800020 	mov	w0, #0x1                   	// #1
    a26c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a270:	3d8013e0 	str	q0, [sp, #64]
    a274:	f9018b02 	str	x2, [x24, #784]
    a278:	97ffece2 	bl	5600 <fwp_data.part.0.constprop.0>
    a27c:	97ffed4e 	bl	57b4 <fwp_rc_fresh>
    a280:	aa0003e2 	mov	x2, x0
    a284:	910163e1 	add	x1, sp, #0x58
    a288:	52800020 	mov	w0, #0x1                   	// #1
    a28c:	a9058bf5 	stp	x21, x2, [sp, #88]
    a290:	97ffecdc 	bl	5600 <fwp_data.part.0.constprop.0>
    a294:	97ffed48 	bl	57b4 <fwp_rc_fresh>
    a298:	aa0003e2 	mov	x2, x0
    a29c:	9101a3e1 	add	x1, sp, #0x68
    a2a0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a2a4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a2a8:	52800020 	mov	w0, #0x1                   	// #1
    a2ac:	a9068be3 	stp	x3, x2, [sp, #104]
    a2b0:	97ffecd4 	bl	5600 <fwp_data.part.0.constprop.0>
    a2b4:	97ffed40 	bl	57b4 <fwp_rc_fresh>
    a2b8:	aa0003e2 	mov	x2, x0
    a2bc:	9101e3e1 	add	x1, sp, #0x78
    a2c0:	52800020 	mov	w0, #0x1                   	// #1
    a2c4:	a9078bf5 	stp	x21, x2, [sp, #120]
    a2c8:	97ffecce 	bl	5600 <fwp_data.part.0.constprop.0>
    a2cc:	97ffed3a 	bl	57b4 <fwp_rc_fresh>
    a2d0:	aa0003e2 	mov	x2, x0
    a2d4:	910223e1 	add	x1, sp, #0x88
    a2d8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a2dc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a2e0:	52800020 	mov	w0, #0x1                   	// #1
    a2e4:	a9088be3 	stp	x3, x2, [sp, #136]
    a2e8:	97ffecc6 	bl	5600 <fwp_data.part.0.constprop.0>
    a2ec:	97ffed32 	bl	57b4 <fwp_rc_fresh>
    a2f0:	aa0003e2 	mov	x2, x0
    a2f4:	910263e1 	add	x1, sp, #0x98
    a2f8:	52800020 	mov	w0, #0x1                   	// #1
    a2fc:	a9098bf5 	stp	x21, x2, [sp, #152]
    a300:	97ffecc0 	bl	5600 <fwp_data.part.0.constprop.0>
    a304:	97ffed2c 	bl	57b4 <fwp_rc_fresh>
    a308:	aa0003e2 	mov	x2, x0
    a30c:	9102a3e1 	add	x1, sp, #0xa8
    a310:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a314:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a318:	52800020 	mov	w0, #0x1                   	// #1
    a31c:	a90a8be3 	stp	x3, x2, [sp, #168]
    a320:	97ffecb8 	bl	5600 <fwp_data.part.0.constprop.0>
    a324:	97ffed24 	bl	57b4 <fwp_rc_fresh>
    a328:	aa0003e2 	mov	x2, x0
    a32c:	9102e3e1 	add	x1, sp, #0xb8
    a330:	52800020 	mov	w0, #0x1                   	// #1
    a334:	a90b8bf5 	stp	x21, x2, [sp, #184]
    a338:	97ffecb2 	bl	5600 <fwp_data.part.0.constprop.0>
    a33c:	97ffed1e 	bl	57b4 <fwp_rc_fresh>
    a340:	aa0003e2 	mov	x2, x0
    a344:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a348:	910323e1 	add	x1, sp, #0xc8
    a34c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a350:	52800020 	mov	w0, #0x1                   	// #1
    a354:	a90c8be3 	stp	x3, x2, [sp, #200]
    a358:	97ffecaa 	bl	5600 <fwp_data.part.0.constprop.0>
    a35c:	97ffed16 	bl	57b4 <fwp_rc_fresh>
    a360:	aa0003e2 	mov	x2, x0
    a364:	910363e1 	add	x1, sp, #0xd8
    a368:	52800020 	mov	w0, #0x1                   	// #1
    a36c:	a90d8bf5 	stp	x21, x2, [sp, #216]
    a370:	97ffeca4 	bl	5600 <fwp_data.part.0.constprop.0>
    a374:	91174283 	add	x3, x20, #0x5d0
    a378:	aa0003f5 	mov	x21, x0
    a37c:	f949d861 	ldr	x1, [x3, #5040]
    a380:	f949ec60 	ldr	x0, [x3, #5080]
    a384:	cb0102a1 	sub	x1, x21, x1
    a388:	eb00403f 	cmp	x1, x0, lsl #16
    a38c:	54000322 	b.cs	a3f0 <f0+0x2d0>  // b.hs, b.nlast
    a390:	d350fc22 	lsr	x2, x1, #16
    a394:	f949fc63 	ldr	x3, [x3, #5112]
    a398:	8b020842 	add	x2, x2, x2, lsl #2
    a39c:	d37df042 	lsl	x2, x2, #3
    a3a0:	8b020060 	add	x0, x3, x2
    a3a4:	f9401017 	ldr	x23, [x0, #32]
    a3a8:	b4000257 	cbz	x23, a3f0 <f0+0x2d0>
    a3ac:	38626862 	ldrb	w2, [x3, x2]
    a3b0:	7100085f 	cmp	w2, #0x2
    a3b4:	54010560 	b.eq	c460 <f0+0x2340>  // b.none
    a3b8:	7100045f 	cmp	w2, #0x1
    a3bc:	540001a1 	b.ne	a3f0 <f0+0x2d0>  // b.any
    a3c0:	29430002 	ldp	w2, w0, [x0, #24]
    a3c4:	92403c21 	and	x1, x1, #0xffff
    a3c8:	9b027c21 	mul	x1, x1, x2
    a3cc:	d360fc21 	lsr	x1, x1, #32
    a3d0:	eb00003f 	cmp	x1, x0
    a3d4:	540000e2 	b.cs	a3f0 <f0+0x2d0>  // b.hs, b.nlast
    a3d8:	8b0102f7 	add	x23, x23, x1
    a3dc:	394002e0 	ldrb	w0, [x23]
    a3e0:	7103fc1f 	cmp	w0, #0xff
    a3e4:	54010f20 	b.eq	c5c8 <f0+0x24a8>  // b.none
    a3e8:	52800020 	mov	w0, #0x1                   	// #1
    a3ec:	390002e0 	strb	w0, [x23]
    a3f0:	9103a3e1 	add	x1, sp, #0xe8
    a3f4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a3f8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a3fc:	52800020 	mov	w0, #0x1                   	// #1
    a400:	a90ed7f7 	stp	x23, x21, [sp, #232]
    a404:	97ffec7f 	bl	5600 <fwp_data.part.0.constprop.0>
    a408:	97ffeceb 	bl	57b4 <fwp_rc_fresh>
    a40c:	aa0003e2 	mov	x2, x0
    a410:	9103e3e1 	add	x1, sp, #0xf8
    a414:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a418:	52800020 	mov	w0, #0x1                   	// #1
    a41c:	a90f8bf5 	stp	x21, x2, [sp, #248]
    a420:	97ffec78 	bl	5600 <fwp_data.part.0.constprop.0>
    a424:	97ffece4 	bl	57b4 <fwp_rc_fresh>
    a428:	aa0003e2 	mov	x2, x0
    a42c:	910423e1 	add	x1, sp, #0x108
    a430:	52800020 	mov	w0, #0x1                   	// #1
    a434:	a9108bf7 	stp	x23, x2, [sp, #264]
    a438:	97ffec72 	bl	5600 <fwp_data.part.0.constprop.0>
    a43c:	97ffecde 	bl	57b4 <fwp_rc_fresh>
    a440:	aa0003e2 	mov	x2, x0
    a444:	910463e1 	add	x1, sp, #0x118
    a448:	52800020 	mov	w0, #0x1                   	// #1
    a44c:	a9118bf5 	stp	x21, x2, [sp, #280]
    a450:	97ffec6c 	bl	5600 <fwp_data.part.0.constprop.0>
    a454:	97ffecd8 	bl	57b4 <fwp_rc_fresh>
    a458:	aa0003e2 	mov	x2, x0
    a45c:	9104a3e1 	add	x1, sp, #0x128
    a460:	52800020 	mov	w0, #0x1                   	// #1
    a464:	a9128bf7 	stp	x23, x2, [sp, #296]
    a468:	97ffec66 	bl	5600 <fwp_data.part.0.constprop.0>
    a46c:	97ffecd2 	bl	57b4 <fwp_rc_fresh>
    a470:	aa0003e2 	mov	x2, x0
    a474:	9104e3e1 	add	x1, sp, #0x138
    a478:	52800020 	mov	w0, #0x1                   	// #1
    a47c:	a9138bf5 	stp	x21, x2, [sp, #312]
    a480:	97ffec60 	bl	5600 <fwp_data.part.0.constprop.0>
    a484:	91174283 	add	x3, x20, #0x5d0
    a488:	aa0003f5 	mov	x21, x0
    a48c:	f949d861 	ldr	x1, [x3, #5040]
    a490:	f949ec60 	ldr	x0, [x3, #5080]
    a494:	cb0102a1 	sub	x1, x21, x1
    a498:	eb00403f 	cmp	x1, x0, lsl #16
    a49c:	54000322 	b.cs	a500 <f0+0x3e0>  // b.hs, b.nlast
    a4a0:	d350fc22 	lsr	x2, x1, #16
    a4a4:	f949fc63 	ldr	x3, [x3, #5112]
    a4a8:	8b020842 	add	x2, x2, x2, lsl #2
    a4ac:	d37df042 	lsl	x2, x2, #3
    a4b0:	8b020060 	add	x0, x3, x2
    a4b4:	f9401017 	ldr	x23, [x0, #32]
    a4b8:	b4000257 	cbz	x23, a500 <f0+0x3e0>
    a4bc:	38626862 	ldrb	w2, [x3, x2]
    a4c0:	7100085f 	cmp	w2, #0x2
    a4c4:	5400fc80 	b.eq	c454 <f0+0x2334>  // b.none
    a4c8:	7100045f 	cmp	w2, #0x1
    a4cc:	540001a1 	b.ne	a500 <f0+0x3e0>  // b.any
    a4d0:	29430002 	ldp	w2, w0, [x0, #24]
    a4d4:	92403c21 	and	x1, x1, #0xffff
    a4d8:	9b027c21 	mul	x1, x1, x2
    a4dc:	d360fc21 	lsr	x1, x1, #32
    a4e0:	eb00003f 	cmp	x1, x0
    a4e4:	540000e2 	b.cs	a500 <f0+0x3e0>  // b.hs, b.nlast
    a4e8:	8b0102f7 	add	x23, x23, x1
    a4ec:	394002e0 	ldrb	w0, [x23]
    a4f0:	7103fc1f 	cmp	w0, #0xff
    a4f4:	54010700 	b.eq	c5d4 <f0+0x24b4>  // b.none
    a4f8:	52800020 	mov	w0, #0x1                   	// #1
    a4fc:	390002e0 	strb	w0, [x23]
    a500:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a504:	910523e1 	add	x1, sp, #0x148
    a508:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a50c:	52800020 	mov	w0, #0x1                   	// #1
    a510:	a914d7e2 	stp	x2, x21, [sp, #328]
    a514:	97ffec3b 	bl	5600 <fwp_data.part.0.constprop.0>
    a518:	97ffeca7 	bl	57b4 <fwp_rc_fresh>
    a51c:	aa0003e2 	mov	x2, x0
    a520:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a524:	910563e1 	add	x1, sp, #0x158
    a528:	52800020 	mov	w0, #0x1                   	// #1
    a52c:	a9158be3 	stp	x3, x2, [sp, #344]
    a530:	97ffec34 	bl	5600 <fwp_data.part.0.constprop.0>
    a534:	91174283 	add	x3, x20, #0x5d0
    a538:	aa0003f5 	mov	x21, x0
    a53c:	f949d861 	ldr	x1, [x3, #5040]
    a540:	f949ec60 	ldr	x0, [x3, #5080]
    a544:	cb0102a1 	sub	x1, x21, x1
    a548:	eb00403f 	cmp	x1, x0, lsl #16
    a54c:	54000322 	b.cs	a5b0 <f0+0x490>  // b.hs, b.nlast
    a550:	d350fc22 	lsr	x2, x1, #16
    a554:	f949fc63 	ldr	x3, [x3, #5112]
    a558:	8b020842 	add	x2, x2, x2, lsl #2
    a55c:	d37df042 	lsl	x2, x2, #3
    a560:	8b020060 	add	x0, x3, x2
    a564:	f9401017 	ldr	x23, [x0, #32]
    a568:	b4000257 	cbz	x23, a5b0 <f0+0x490>
    a56c:	38626862 	ldrb	w2, [x3, x2]
    a570:	7100085f 	cmp	w2, #0x2
    a574:	5400f6a0 	b.eq	c448 <f0+0x2328>  // b.none
    a578:	7100045f 	cmp	w2, #0x1
    a57c:	540001a1 	b.ne	a5b0 <f0+0x490>  // b.any
    a580:	29430002 	ldp	w2, w0, [x0, #24]
    a584:	92403c21 	and	x1, x1, #0xffff
    a588:	9b027c21 	mul	x1, x1, x2
    a58c:	d360fc21 	lsr	x1, x1, #32
    a590:	eb00003f 	cmp	x1, x0
    a594:	540000e2 	b.cs	a5b0 <f0+0x490>  // b.hs, b.nlast
    a598:	8b0102f7 	add	x23, x23, x1
    a59c:	394002e0 	ldrb	w0, [x23]
    a5a0:	7103fc1f 	cmp	w0, #0xff
    a5a4:	540101e0 	b.eq	c5e0 <f0+0x24c0>  // b.none
    a5a8:	52800020 	mov	w0, #0x1                   	// #1
    a5ac:	390002e0 	strb	w0, [x23]
    a5b0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a5b4:	9105a3e1 	add	x1, sp, #0x168
    a5b8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a5bc:	52800020 	mov	w0, #0x1                   	// #1
    a5c0:	a916d7e2 	stp	x2, x21, [sp, #360]
    a5c4:	97ffec0f 	bl	5600 <fwp_data.part.0.constprop.0>
    a5c8:	97ffec7b 	bl	57b4 <fwp_rc_fresh>
    a5cc:	aa0003e2 	mov	x2, x0
    a5d0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a5d4:	9105e3e1 	add	x1, sp, #0x178
    a5d8:	52800020 	mov	w0, #0x1                   	// #1
    a5dc:	a9178be3 	stp	x3, x2, [sp, #376]
    a5e0:	97ffec08 	bl	5600 <fwp_data.part.0.constprop.0>
    a5e4:	91174283 	add	x3, x20, #0x5d0
    a5e8:	aa0003f5 	mov	x21, x0
    a5ec:	f949d861 	ldr	x1, [x3, #5040]
    a5f0:	f949ec60 	ldr	x0, [x3, #5080]
    a5f4:	cb0102a1 	sub	x1, x21, x1
    a5f8:	eb00403f 	cmp	x1, x0, lsl #16
    a5fc:	54000322 	b.cs	a660 <f0+0x540>  // b.hs, b.nlast
    a600:	d350fc22 	lsr	x2, x1, #16
    a604:	f949fc63 	ldr	x3, [x3, #5112]
    a608:	8b020842 	add	x2, x2, x2, lsl #2
    a60c:	d37df042 	lsl	x2, x2, #3
    a610:	8b020060 	add	x0, x3, x2
    a614:	f9401017 	ldr	x23, [x0, #32]
    a618:	b4000257 	cbz	x23, a660 <f0+0x540>
    a61c:	38626862 	ldrb	w2, [x3, x2]
    a620:	7100085f 	cmp	w2, #0x2
    a624:	5400f360 	b.eq	c490 <f0+0x2370>  // b.none
    a628:	7100045f 	cmp	w2, #0x1
    a62c:	540001a1 	b.ne	a660 <f0+0x540>  // b.any
    a630:	29430002 	ldp	w2, w0, [x0, #24]
    a634:	92403c21 	and	x1, x1, #0xffff
    a638:	9b027c21 	mul	x1, x1, x2
    a63c:	d360fc21 	lsr	x1, x1, #32
    a640:	eb00003f 	cmp	x1, x0
    a644:	540000e2 	b.cs	a660 <f0+0x540>  // b.hs, b.nlast
    a648:	8b0102f7 	add	x23, x23, x1
    a64c:	394002e0 	ldrb	w0, [x23]
    a650:	7103fc1f 	cmp	w0, #0xff
    a654:	5400fcc0 	b.eq	c5ec <f0+0x24cc>  // b.none
    a658:	52800020 	mov	w0, #0x1                   	// #1
    a65c:	390002e0 	strb	w0, [x23]
    a660:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a664:	910623e1 	add	x1, sp, #0x188
    a668:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a66c:	52800020 	mov	w0, #0x1                   	// #1
    a670:	a918d7e2 	stp	x2, x21, [sp, #392]
    a674:	97ffebe3 	bl	5600 <fwp_data.part.0.constprop.0>
    a678:	97ffec4f 	bl	57b4 <fwp_rc_fresh>
    a67c:	aa0003e2 	mov	x2, x0
    a680:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a684:	910663e1 	add	x1, sp, #0x198
    a688:	52800020 	mov	w0, #0x1                   	// #1
    a68c:	a9198be3 	stp	x3, x2, [sp, #408]
    a690:	97ffebdc 	bl	5600 <fwp_data.part.0.constprop.0>
    a694:	91174283 	add	x3, x20, #0x5d0
    a698:	aa0003f5 	mov	x21, x0
    a69c:	f949d861 	ldr	x1, [x3, #5040]
    a6a0:	f949ec60 	ldr	x0, [x3, #5080]
    a6a4:	cb0102a1 	sub	x1, x21, x1
    a6a8:	eb00403f 	cmp	x1, x0, lsl #16
    a6ac:	54000322 	b.cs	a710 <f0+0x5f0>  // b.hs, b.nlast
    a6b0:	d350fc22 	lsr	x2, x1, #16
    a6b4:	f949fc63 	ldr	x3, [x3, #5112]
    a6b8:	8b020842 	add	x2, x2, x2, lsl #2
    a6bc:	d37df042 	lsl	x2, x2, #3
    a6c0:	8b020060 	add	x0, x3, x2
    a6c4:	f9401017 	ldr	x23, [x0, #32]
    a6c8:	b4000257 	cbz	x23, a710 <f0+0x5f0>
    a6cc:	38626862 	ldrb	w2, [x3, x2]
    a6d0:	7100085f 	cmp	w2, #0x2
    a6d4:	5400ed80 	b.eq	c484 <f0+0x2364>  // b.none
    a6d8:	7100045f 	cmp	w2, #0x1
    a6dc:	540001a1 	b.ne	a710 <f0+0x5f0>  // b.any
    a6e0:	29430002 	ldp	w2, w0, [x0, #24]
    a6e4:	92403c21 	and	x1, x1, #0xffff
    a6e8:	9b027c21 	mul	x1, x1, x2
    a6ec:	d360fc21 	lsr	x1, x1, #32
    a6f0:	eb00003f 	cmp	x1, x0
    a6f4:	540000e2 	b.cs	a710 <f0+0x5f0>  // b.hs, b.nlast
    a6f8:	8b0102f7 	add	x23, x23, x1
    a6fc:	394002e0 	ldrb	w0, [x23]
    a700:	7103fc1f 	cmp	w0, #0xff
    a704:	5400f7a0 	b.eq	c5f8 <f0+0x24d8>  // b.none
    a708:	52800020 	mov	w0, #0x1                   	// #1
    a70c:	390002e0 	strb	w0, [x23]
    a710:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a714:	9106a3e1 	add	x1, sp, #0x1a8
    a718:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a71c:	52800020 	mov	w0, #0x1                   	// #1
    a720:	a91ad7e2 	stp	x2, x21, [sp, #424]
    a724:	97ffebb7 	bl	5600 <fwp_data.part.0.constprop.0>
    a728:	97ffec23 	bl	57b4 <fwp_rc_fresh>
    a72c:	aa0003e2 	mov	x2, x0
    a730:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a734:	9106e3e1 	add	x1, sp, #0x1b8
    a738:	52800020 	mov	w0, #0x1                   	// #1
    a73c:	a91b8be3 	stp	x3, x2, [sp, #440]
    a740:	97ffebb0 	bl	5600 <fwp_data.part.0.constprop.0>
    a744:	91174283 	add	x3, x20, #0x5d0
    a748:	aa0003f5 	mov	x21, x0
    a74c:	f949d861 	ldr	x1, [x3, #5040]
    a750:	f949ec60 	ldr	x0, [x3, #5080]
    a754:	cb0102a1 	sub	x1, x21, x1
    a758:	eb00403f 	cmp	x1, x0, lsl #16
    a75c:	54000322 	b.cs	a7c0 <f0+0x6a0>  // b.hs, b.nlast
    a760:	d350fc22 	lsr	x2, x1, #16
    a764:	f949fc63 	ldr	x3, [x3, #5112]
    a768:	8b020842 	add	x2, x2, x2, lsl #2
    a76c:	d37df042 	lsl	x2, x2, #3
    a770:	8b020060 	add	x0, x3, x2
    a774:	f9401017 	ldr	x23, [x0, #32]
    a778:	b4000257 	cbz	x23, a7c0 <f0+0x6a0>
    a77c:	38626862 	ldrb	w2, [x3, x2]
    a780:	7100085f 	cmp	w2, #0x2
    a784:	5400e7a0 	b.eq	c478 <f0+0x2358>  // b.none
    a788:	7100045f 	cmp	w2, #0x1
    a78c:	540001a1 	b.ne	a7c0 <f0+0x6a0>  // b.any
    a790:	29430002 	ldp	w2, w0, [x0, #24]
    a794:	92403c21 	and	x1, x1, #0xffff
    a798:	9b027c21 	mul	x1, x1, x2
    a79c:	d360fc21 	lsr	x1, x1, #32
    a7a0:	eb00003f 	cmp	x1, x0
    a7a4:	540000e2 	b.cs	a7c0 <f0+0x6a0>  // b.hs, b.nlast
    a7a8:	8b0102f7 	add	x23, x23, x1
    a7ac:	394002e0 	ldrb	w0, [x23]
    a7b0:	7103fc1f 	cmp	w0, #0xff
    a7b4:	5400f280 	b.eq	c604 <f0+0x24e4>  // b.none
    a7b8:	52800020 	mov	w0, #0x1                   	// #1
    a7bc:	390002e0 	strb	w0, [x23]
    a7c0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a7c4:	910723e1 	add	x1, sp, #0x1c8
    a7c8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a7cc:	52800020 	mov	w0, #0x1                   	// #1
    a7d0:	a91cd7e2 	stp	x2, x21, [sp, #456]
    a7d4:	97ffeb8b 	bl	5600 <fwp_data.part.0.constprop.0>
    a7d8:	91174283 	add	x3, x20, #0x5d0
    a7dc:	aa0003f5 	mov	x21, x0
    a7e0:	f949d861 	ldr	x1, [x3, #5040]
    a7e4:	f949ec60 	ldr	x0, [x3, #5080]
    a7e8:	cb0102a1 	sub	x1, x21, x1
    a7ec:	eb00403f 	cmp	x1, x0, lsl #16
    a7f0:	54000322 	b.cs	a854 <f0+0x734>  // b.hs, b.nlast
    a7f4:	d350fc22 	lsr	x2, x1, #16
    a7f8:	f949fc63 	ldr	x3, [x3, #5112]
    a7fc:	8b020842 	add	x2, x2, x2, lsl #2
    a800:	d37df042 	lsl	x2, x2, #3
    a804:	8b020060 	add	x0, x3, x2
    a808:	f9401017 	ldr	x23, [x0, #32]
    a80c:	b4000257 	cbz	x23, a854 <f0+0x734>
    a810:	38626862 	ldrb	w2, [x3, x2]
    a814:	7100085f 	cmp	w2, #0x2
    a818:	5400e2a0 	b.eq	c46c <f0+0x234c>  // b.none
    a81c:	7100045f 	cmp	w2, #0x1
    a820:	540001a1 	b.ne	a854 <f0+0x734>  // b.any
    a824:	29430002 	ldp	w2, w0, [x0, #24]
    a828:	92403c21 	and	x1, x1, #0xffff
    a82c:	9b027c21 	mul	x1, x1, x2
    a830:	d360fc21 	lsr	x1, x1, #32
    a834:	eb00003f 	cmp	x1, x0
    a838:	540000e2 	b.cs	a854 <f0+0x734>  // b.hs, b.nlast
    a83c:	8b0102f7 	add	x23, x23, x1
    a840:	394002e0 	ldrb	w0, [x23]
    a844:	7103fc1f 	cmp	w0, #0xff
    a848:	5400ee40 	b.eq	c610 <f0+0x24f0>  // b.none
    a84c:	52800020 	mov	w0, #0x1                   	// #1
    a850:	390002e0 	strb	w0, [x23]
    a854:	910763e1 	add	x1, sp, #0x1d8
    a858:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a85c:	52800020 	mov	w0, #0x1                   	// #1
    a860:	a91dd7f7 	stp	x23, x21, [sp, #472]
    a864:	97ffeb67 	bl	5600 <fwp_data.part.0.constprop.0>
    a868:	97ffebd3 	bl	57b4 <fwp_rc_fresh>
    a86c:	aa0003e2 	mov	x2, x0
    a870:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a874:	9107a3e1 	add	x1, sp, #0x1e8
    a878:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a87c:	52800020 	mov	w0, #0x1                   	// #1
    a880:	a91e8be3 	stp	x3, x2, [sp, #488]
    a884:	97ffeb5f 	bl	5600 <fwp_data.part.0.constprop.0>
    a888:	97ffebcb 	bl	57b4 <fwp_rc_fresh>
    a88c:	aa0003e2 	mov	x2, x0
    a890:	9107e3e1 	add	x1, sp, #0x1f8
    a894:	52800020 	mov	w0, #0x1                   	// #1
    a898:	a91f8bf7 	stp	x23, x2, [sp, #504]
    a89c:	97ffeb59 	bl	5600 <fwp_data.part.0.constprop.0>
    a8a0:	91174283 	add	x3, x20, #0x5d0
    a8a4:	aa0003f5 	mov	x21, x0
    a8a8:	f949d861 	ldr	x1, [x3, #5040]
    a8ac:	f949ec60 	ldr	x0, [x3, #5080]
    a8b0:	cb0102a1 	sub	x1, x21, x1
    a8b4:	eb00403f 	cmp	x1, x0, lsl #16
    a8b8:	54000322 	b.cs	a91c <f0+0x7fc>  // b.hs, b.nlast
    a8bc:	d350fc22 	lsr	x2, x1, #16
    a8c0:	f949fc63 	ldr	x3, [x3, #5112]
    a8c4:	8b020842 	add	x2, x2, x2, lsl #2
    a8c8:	d37df042 	lsl	x2, x2, #3
    a8cc:	8b020060 	add	x0, x3, x2
    a8d0:	f9401017 	ldr	x23, [x0, #32]
    a8d4:	b4000257 	cbz	x23, a91c <f0+0x7fc>
    a8d8:	38626862 	ldrb	w2, [x3, x2]
    a8dc:	7100085f 	cmp	w2, #0x2
    a8e0:	5400e080 	b.eq	c4f0 <f0+0x23d0>  // b.none
    a8e4:	7100045f 	cmp	w2, #0x1
    a8e8:	540001a1 	b.ne	a91c <f0+0x7fc>  // b.any
    a8ec:	29430002 	ldp	w2, w0, [x0, #24]
    a8f0:	92403c21 	and	x1, x1, #0xffff
    a8f4:	9b027c21 	mul	x1, x1, x2
    a8f8:	d360fc21 	lsr	x1, x1, #32
    a8fc:	eb00003f 	cmp	x1, x0
    a900:	540000e2 	b.cs	a91c <f0+0x7fc>  // b.hs, b.nlast
    a904:	8b0102f7 	add	x23, x23, x1
    a908:	394002e0 	ldrb	w0, [x23]
    a90c:	7103fc1f 	cmp	w0, #0xff
    a910:	5400e860 	b.eq	c61c <f0+0x24fc>  // b.none
    a914:	52800020 	mov	w0, #0x1                   	// #1
    a918:	390002e0 	strb	w0, [x23]
    a91c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a920:	910823e1 	add	x1, sp, #0x208
    a924:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a928:	52800020 	mov	w0, #0x1                   	// #1
    a92c:	f90107e2 	str	x2, [sp, #520]
    a930:	f9010bf5 	str	x21, [sp, #528]
    a934:	97ffeb33 	bl	5600 <fwp_data.part.0.constprop.0>
    a938:	97ffeb9f 	bl	57b4 <fwp_rc_fresh>
    a93c:	aa0003e2 	mov	x2, x0
    a940:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a944:	910863e1 	add	x1, sp, #0x218
    a948:	52800020 	mov	w0, #0x1                   	// #1
    a94c:	f9010fe3 	str	x3, [sp, #536]
    a950:	f90113e2 	str	x2, [sp, #544]
    a954:	97ffeb2b 	bl	5600 <fwp_data.part.0.constprop.0>
    a958:	91174283 	add	x3, x20, #0x5d0
    a95c:	aa0003f5 	mov	x21, x0
    a960:	f949d861 	ldr	x1, [x3, #5040]
    a964:	f949ec60 	ldr	x0, [x3, #5080]
    a968:	cb0102a1 	sub	x1, x21, x1
    a96c:	eb00403f 	cmp	x1, x0, lsl #16
    a970:	54000322 	b.cs	a9d4 <f0+0x8b4>  // b.hs, b.nlast
    a974:	d350fc22 	lsr	x2, x1, #16
    a978:	f949fc63 	ldr	x3, [x3, #5112]
    a97c:	8b020842 	add	x2, x2, x2, lsl #2
    a980:	d37df042 	lsl	x2, x2, #3
    a984:	8b020060 	add	x0, x3, x2
    a988:	f9401017 	ldr	x23, [x0, #32]
    a98c:	b4000257 	cbz	x23, a9d4 <f0+0x8b4>
    a990:	38626862 	ldrb	w2, [x3, x2]
    a994:	7100085f 	cmp	w2, #0x2
    a998:	5400da60 	b.eq	c4e4 <f0+0x23c4>  // b.none
    a99c:	7100045f 	cmp	w2, #0x1
    a9a0:	540001a1 	b.ne	a9d4 <f0+0x8b4>  // b.any
    a9a4:	29430002 	ldp	w2, w0, [x0, #24]
    a9a8:	92403c21 	and	x1, x1, #0xffff
    a9ac:	9b027c21 	mul	x1, x1, x2
    a9b0:	d360fc21 	lsr	x1, x1, #32
    a9b4:	eb00003f 	cmp	x1, x0
    a9b8:	540000e2 	b.cs	a9d4 <f0+0x8b4>  // b.hs, b.nlast
    a9bc:	8b0102f7 	add	x23, x23, x1
    a9c0:	394002e0 	ldrb	w0, [x23]
    a9c4:	7103fc1f 	cmp	w0, #0xff
    a9c8:	5400e300 	b.eq	c628 <f0+0x2508>  // b.none
    a9cc:	52800020 	mov	w0, #0x1                   	// #1
    a9d0:	390002e0 	strb	w0, [x23]
    a9d4:	9108a3e1 	add	x1, sp, #0x228
    a9d8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a9dc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a9e0:	52800020 	mov	w0, #0x1                   	// #1
    a9e4:	f90117f7 	str	x23, [sp, #552]
    a9e8:	f9011bf5 	str	x21, [sp, #560]
    a9ec:	97ffeb05 	bl	5600 <fwp_data.part.0.constprop.0>
    a9f0:	97ffeb71 	bl	57b4 <fwp_rc_fresh>
    a9f4:	aa0003e2 	mov	x2, x0
    a9f8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a9fc:	9108e3e1 	add	x1, sp, #0x238
    aa00:	52800020 	mov	w0, #0x1                   	// #1
    aa04:	f9011fe3 	str	x3, [sp, #568]
    aa08:	f90123e2 	str	x2, [sp, #576]
    aa0c:	97ffeafd 	bl	5600 <fwp_data.part.0.constprop.0>
    aa10:	97ffeb69 	bl	57b4 <fwp_rc_fresh>
    aa14:	aa0003e2 	mov	x2, x0
    aa18:	910923e1 	add	x1, sp, #0x248
    aa1c:	52800020 	mov	w0, #0x1                   	// #1
    aa20:	f90127f7 	str	x23, [sp, #584]
    aa24:	f9012be2 	str	x2, [sp, #592]
    aa28:	97ffeaf6 	bl	5600 <fwp_data.part.0.constprop.0>
    aa2c:	91174283 	add	x3, x20, #0x5d0
    aa30:	aa0003f5 	mov	x21, x0
    aa34:	f949d861 	ldr	x1, [x3, #5040]
    aa38:	f949ec60 	ldr	x0, [x3, #5080]
    aa3c:	cb0102a1 	sub	x1, x21, x1
    aa40:	eb00403f 	cmp	x1, x0, lsl #16
    aa44:	54000322 	b.cs	aaa8 <f0+0x988>  // b.hs, b.nlast
    aa48:	d350fc22 	lsr	x2, x1, #16
    aa4c:	f949fc63 	ldr	x3, [x3, #5112]
    aa50:	8b020842 	add	x2, x2, x2, lsl #2
    aa54:	d37df042 	lsl	x2, x2, #3
    aa58:	8b020060 	add	x0, x3, x2
    aa5c:	f9401017 	ldr	x23, [x0, #32]
    aa60:	b4000257 	cbz	x23, aaa8 <f0+0x988>
    aa64:	38626862 	ldrb	w2, [x3, x2]
    aa68:	7100085f 	cmp	w2, #0x2
    aa6c:	5400d360 	b.eq	c4d8 <f0+0x23b8>  // b.none
    aa70:	7100045f 	cmp	w2, #0x1
    aa74:	540001a1 	b.ne	aaa8 <f0+0x988>  // b.any
    aa78:	29430002 	ldp	w2, w0, [x0, #24]
    aa7c:	92403c21 	and	x1, x1, #0xffff
    aa80:	9b027c21 	mul	x1, x1, x2
    aa84:	d360fc21 	lsr	x1, x1, #32
    aa88:	eb00003f 	cmp	x1, x0
    aa8c:	540000e2 	b.cs	aaa8 <f0+0x988>  // b.hs, b.nlast
    aa90:	8b0102f7 	add	x23, x23, x1
    aa94:	394002e0 	ldrb	w0, [x23]
    aa98:	7103fc1f 	cmp	w0, #0xff
    aa9c:	5400dcc0 	b.eq	c634 <f0+0x2514>  // b.none
    aaa0:	52800020 	mov	w0, #0x1                   	// #1
    aaa4:	390002e0 	strb	w0, [x23]
    aaa8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aaac:	910963e1 	add	x1, sp, #0x258
    aab0:	52800020 	mov	w0, #0x1                   	// #1
    aab4:	f9012fe2 	str	x2, [sp, #600]
    aab8:	f90133f5 	str	x21, [sp, #608]
    aabc:	97ffead1 	bl	5600 <fwp_data.part.0.constprop.0>
    aac0:	91174283 	add	x3, x20, #0x5d0
    aac4:	aa0003f5 	mov	x21, x0
    aac8:	f949d861 	ldr	x1, [x3, #5040]
    aacc:	f949ec60 	ldr	x0, [x3, #5080]
    aad0:	cb0102a1 	sub	x1, x21, x1
    aad4:	eb00403f 	cmp	x1, x0, lsl #16
    aad8:	54000322 	b.cs	ab3c <f0+0xa1c>  // b.hs, b.nlast
    aadc:	d350fc22 	lsr	x2, x1, #16
    aae0:	f949fc63 	ldr	x3, [x3, #5112]
    aae4:	8b020842 	add	x2, x2, x2, lsl #2
    aae8:	d37df042 	lsl	x2, x2, #3
    aaec:	8b020060 	add	x0, x3, x2
    aaf0:	f9401017 	ldr	x23, [x0, #32]
    aaf4:	b4000257 	cbz	x23, ab3c <f0+0xa1c>
    aaf8:	38626862 	ldrb	w2, [x3, x2]
    aafc:	7100085f 	cmp	w2, #0x2
    ab00:	5400ce60 	b.eq	c4cc <f0+0x23ac>  // b.none
    ab04:	7100045f 	cmp	w2, #0x1
    ab08:	540001a1 	b.ne	ab3c <f0+0xa1c>  // b.any
    ab0c:	29430002 	ldp	w2, w0, [x0, #24]
    ab10:	92403c21 	and	x1, x1, #0xffff
    ab14:	9b027c21 	mul	x1, x1, x2
    ab18:	d360fc21 	lsr	x1, x1, #32
    ab1c:	eb00003f 	cmp	x1, x0
    ab20:	540000e2 	b.cs	ab3c <f0+0xa1c>  // b.hs, b.nlast
    ab24:	8b0102f7 	add	x23, x23, x1
    ab28:	394002e0 	ldrb	w0, [x23]
    ab2c:	7103fc1f 	cmp	w0, #0xff
    ab30:	5400d880 	b.eq	c640 <f0+0x2520>  // b.none
    ab34:	52800020 	mov	w0, #0x1                   	// #1
    ab38:	390002e0 	strb	w0, [x23]
    ab3c:	9109a3e1 	add	x1, sp, #0x268
    ab40:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ab44:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ab48:	52800020 	mov	w0, #0x1                   	// #1
    ab4c:	f90137f7 	str	x23, [sp, #616]
    ab50:	f9013bf5 	str	x21, [sp, #624]
    ab54:	97ffeaab 	bl	5600 <fwp_data.part.0.constprop.0>
    ab58:	97ffeb17 	bl	57b4 <fwp_rc_fresh>
    ab5c:	aa0003e2 	mov	x2, x0
    ab60:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ab64:	9109e3e1 	add	x1, sp, #0x278
    ab68:	52800020 	mov	w0, #0x1                   	// #1
    ab6c:	f9013fe3 	str	x3, [sp, #632]
    ab70:	f90143e2 	str	x2, [sp, #640]
    ab74:	97ffeaa3 	bl	5600 <fwp_data.part.0.constprop.0>
    ab78:	97ffeb0f 	bl	57b4 <fwp_rc_fresh>
    ab7c:	aa0003e2 	mov	x2, x0
    ab80:	910a23e1 	add	x1, sp, #0x288
    ab84:	52800020 	mov	w0, #0x1                   	// #1
    ab88:	f90147f7 	str	x23, [sp, #648]
    ab8c:	f9014be2 	str	x2, [sp, #656]
    ab90:	97ffea9c 	bl	5600 <fwp_data.part.0.constprop.0>
    ab94:	91174283 	add	x3, x20, #0x5d0
    ab98:	aa0003f5 	mov	x21, x0
    ab9c:	f949d861 	ldr	x1, [x3, #5040]
    aba0:	f949ec60 	ldr	x0, [x3, #5080]
    aba4:	cb0102a1 	sub	x1, x21, x1
    aba8:	eb00403f 	cmp	x1, x0, lsl #16
    abac:	54000322 	b.cs	ac10 <f0+0xaf0>  // b.hs, b.nlast
    abb0:	d350fc22 	lsr	x2, x1, #16
    abb4:	f949fc63 	ldr	x3, [x3, #5112]
    abb8:	8b020842 	add	x2, x2, x2, lsl #2
    abbc:	d37df042 	lsl	x2, x2, #3
    abc0:	8b020060 	add	x0, x3, x2
    abc4:	f9401017 	ldr	x23, [x0, #32]
    abc8:	b4000257 	cbz	x23, ac10 <f0+0xaf0>
    abcc:	38626862 	ldrb	w2, [x3, x2]
    abd0:	7100085f 	cmp	w2, #0x2
    abd4:	5400c760 	b.eq	c4c0 <f0+0x23a0>  // b.none
    abd8:	7100045f 	cmp	w2, #0x1
    abdc:	540001a1 	b.ne	ac10 <f0+0xaf0>  // b.any
    abe0:	29430002 	ldp	w2, w0, [x0, #24]
    abe4:	92403c21 	and	x1, x1, #0xffff
    abe8:	9b027c21 	mul	x1, x1, x2
    abec:	d360fc21 	lsr	x1, x1, #32
    abf0:	eb00003f 	cmp	x1, x0
    abf4:	540000e2 	b.cs	ac10 <f0+0xaf0>  // b.hs, b.nlast
    abf8:	8b0102f7 	add	x23, x23, x1
    abfc:	394002e0 	ldrb	w0, [x23]
    ac00:	7103fc1f 	cmp	w0, #0xff
    ac04:	5400d240 	b.eq	c64c <f0+0x252c>  // b.none
    ac08:	52800020 	mov	w0, #0x1                   	// #1
    ac0c:	390002e0 	strb	w0, [x23]
    ac10:	910a63e1 	add	x1, sp, #0x298
    ac14:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ac18:	52800020 	mov	w0, #0x1                   	// #1
    ac1c:	f9014ff7 	str	x23, [sp, #664]
    ac20:	f90153f5 	str	x21, [sp, #672]
    ac24:	97ffea77 	bl	5600 <fwp_data.part.0.constprop.0>
    ac28:	97ffeae3 	bl	57b4 <fwp_rc_fresh>
    ac2c:	aa0003e2 	mov	x2, x0
    ac30:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac34:	910aa3e1 	add	x1, sp, #0x2a8
    ac38:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac3c:	52800020 	mov	w0, #0x1                   	// #1
    ac40:	f90157e3 	str	x3, [sp, #680]
    ac44:	f9015be2 	str	x2, [sp, #688]
    ac48:	97ffea6e 	bl	5600 <fwp_data.part.0.constprop.0>
    ac4c:	97ffeada 	bl	57b4 <fwp_rc_fresh>
    ac50:	aa0003e2 	mov	x2, x0
    ac54:	910ae3e1 	add	x1, sp, #0x2b8
    ac58:	52800020 	mov	w0, #0x1                   	// #1
    ac5c:	f9015ff7 	str	x23, [sp, #696]
    ac60:	f90163e2 	str	x2, [sp, #704]
    ac64:	97ffea67 	bl	5600 <fwp_data.part.0.constprop.0>
    ac68:	91174283 	add	x3, x20, #0x5d0
    ac6c:	aa0003f5 	mov	x21, x0
    ac70:	f949d861 	ldr	x1, [x3, #5040]
    ac74:	f949ec60 	ldr	x0, [x3, #5080]
    ac78:	cb0102a1 	sub	x1, x21, x1
    ac7c:	eb00403f 	cmp	x1, x0, lsl #16
    ac80:	54000322 	b.cs	ace4 <f0+0xbc4>  // b.hs, b.nlast
    ac84:	d350fc22 	lsr	x2, x1, #16
    ac88:	f949fc63 	ldr	x3, [x3, #5112]
    ac8c:	8b020842 	add	x2, x2, x2, lsl #2
    ac90:	d37df042 	lsl	x2, x2, #3
    ac94:	8b020060 	add	x0, x3, x2
    ac98:	f9401017 	ldr	x23, [x0, #32]
    ac9c:	b4000257 	cbz	x23, ace4 <f0+0xbc4>
    aca0:	38626862 	ldrb	w2, [x3, x2]
    aca4:	7100085f 	cmp	w2, #0x2
    aca8:	5400c060 	b.eq	c4b4 <f0+0x2394>  // b.none
    acac:	7100045f 	cmp	w2, #0x1
    acb0:	540001a1 	b.ne	ace4 <f0+0xbc4>  // b.any
    acb4:	29430002 	ldp	w2, w0, [x0, #24]
    acb8:	92403c21 	and	x1, x1, #0xffff
    acbc:	9b027c21 	mul	x1, x1, x2
    acc0:	d360fc21 	lsr	x1, x1, #32
    acc4:	eb00003f 	cmp	x1, x0
    acc8:	540000e2 	b.cs	ace4 <f0+0xbc4>  // b.hs, b.nlast
    accc:	8b0102f7 	add	x23, x23, x1
    acd0:	394002e0 	ldrb	w0, [x23]
    acd4:	7103fc1f 	cmp	w0, #0xff
    acd8:	5400cc00 	b.eq	c658 <f0+0x2538>  // b.none
    acdc:	52800020 	mov	w0, #0x1                   	// #1
    ace0:	390002e0 	strb	w0, [x23]
    ace4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ace8:	910b23e1 	add	x1, sp, #0x2c8
    acec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    acf0:	52800020 	mov	w0, #0x1                   	// #1
    acf4:	f90167e2 	str	x2, [sp, #712]
    acf8:	f9016bf5 	str	x21, [sp, #720]
    acfc:	97ffea41 	bl	5600 <fwp_data.part.0.constprop.0>
    ad00:	97ffeaad 	bl	57b4 <fwp_rc_fresh>
    ad04:	aa0003e2 	mov	x2, x0
    ad08:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ad0c:	910b63e1 	add	x1, sp, #0x2d8
    ad10:	52800020 	mov	w0, #0x1                   	// #1
    ad14:	f9016fe3 	str	x3, [sp, #728]
    ad18:	f90173e2 	str	x2, [sp, #736]
    ad1c:	97ffea39 	bl	5600 <fwp_data.part.0.constprop.0>
    ad20:	91174283 	add	x3, x20, #0x5d0
    ad24:	aa0003f5 	mov	x21, x0
    ad28:	f949d861 	ldr	x1, [x3, #5040]
    ad2c:	f949ec60 	ldr	x0, [x3, #5080]
    ad30:	cb0102a1 	sub	x1, x21, x1
    ad34:	eb00403f 	cmp	x1, x0, lsl #16
    ad38:	54000322 	b.cs	ad9c <f0+0xc7c>  // b.hs, b.nlast
    ad3c:	d350fc22 	lsr	x2, x1, #16
    ad40:	f949fc63 	ldr	x3, [x3, #5112]
    ad44:	8b020842 	add	x2, x2, x2, lsl #2
    ad48:	d37df042 	lsl	x2, x2, #3
    ad4c:	8b020060 	add	x0, x3, x2
    ad50:	f9401017 	ldr	x23, [x0, #32]
    ad54:	b4000257 	cbz	x23, ad9c <f0+0xc7c>
    ad58:	38626862 	ldrb	w2, [x3, x2]
    ad5c:	7100085f 	cmp	w2, #0x2
    ad60:	5400ba40 	b.eq	c4a8 <f0+0x2388>  // b.none
    ad64:	7100045f 	cmp	w2, #0x1
    ad68:	540001a1 	b.ne	ad9c <f0+0xc7c>  // b.any
    ad6c:	29430002 	ldp	w2, w0, [x0, #24]
    ad70:	92403c21 	and	x1, x1, #0xffff
    ad74:	9b027c21 	mul	x1, x1, x2
    ad78:	d360fc21 	lsr	x1, x1, #32
    ad7c:	eb00003f 	cmp	x1, x0
    ad80:	540000e2 	b.cs	ad9c <f0+0xc7c>  // b.hs, b.nlast
    ad84:	8b0102f7 	add	x23, x23, x1
    ad88:	394002e0 	ldrb	w0, [x23]
    ad8c:	7103fc1f 	cmp	w0, #0xff
    ad90:	5400c6a0 	b.eq	c664 <f0+0x2544>  // b.none
    ad94:	52800020 	mov	w0, #0x1                   	// #1
    ad98:	390002e0 	strb	w0, [x23]
    ad9c:	910ba3e1 	add	x1, sp, #0x2e8
    ada0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ada4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ada8:	52800020 	mov	w0, #0x1                   	// #1
    adac:	f90177f7 	str	x23, [sp, #744]
    adb0:	f9017bf5 	str	x21, [sp, #752]
    adb4:	97ffea13 	bl	5600 <fwp_data.part.0.constprop.0>
    adb8:	97ffea7f 	bl	57b4 <fwp_rc_fresh>
    adbc:	aa0003e2 	mov	x2, x0
    adc0:	910be3e1 	add	x1, sp, #0x2f8
    adc4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    adc8:	52800020 	mov	w0, #0x1                   	// #1
    adcc:	f9017ff5 	str	x21, [sp, #760]
    add0:	f90183e2 	str	x2, [sp, #768]
    add4:	97ffea0b 	bl	5600 <fwp_data.part.0.constprop.0>
    add8:	97ffea77 	bl	57b4 <fwp_rc_fresh>
    addc:	aa0003e2 	mov	x2, x0
    ade0:	910c23e1 	add	x1, sp, #0x308
    ade4:	52800020 	mov	w0, #0x1                   	// #1
    ade8:	f90187f7 	str	x23, [sp, #776]
    adec:	f9018be2 	str	x2, [sp, #784]
    adf0:	97ffea04 	bl	5600 <fwp_data.part.0.constprop.0>
    adf4:	97ffea70 	bl	57b4 <fwp_rc_fresh>
    adf8:	aa0003e2 	mov	x2, x0
    adfc:	910c63e1 	add	x1, sp, #0x318
    ae00:	52800020 	mov	w0, #0x1                   	// #1
    ae04:	f9018ff5 	str	x21, [sp, #792]
    ae08:	f90193e2 	str	x2, [sp, #800]
    ae0c:	97ffe9fd 	bl	5600 <fwp_data.part.0.constprop.0>
    ae10:	91174283 	add	x3, x20, #0x5d0
    ae14:	aa0003f5 	mov	x21, x0
    ae18:	f949d861 	ldr	x1, [x3, #5040]
    ae1c:	f949ec60 	ldr	x0, [x3, #5080]
    ae20:	cb0102a1 	sub	x1, x21, x1
    ae24:	eb00403f 	cmp	x1, x0, lsl #16
    ae28:	54000322 	b.cs	ae8c <f0+0xd6c>  // b.hs, b.nlast
    ae2c:	d350fc22 	lsr	x2, x1, #16
    ae30:	f949fc63 	ldr	x3, [x3, #5112]
    ae34:	8b020842 	add	x2, x2, x2, lsl #2
    ae38:	d37df042 	lsl	x2, x2, #3
    ae3c:	8b020060 	add	x0, x3, x2
    ae40:	f9401017 	ldr	x23, [x0, #32]
    ae44:	b4000257 	cbz	x23, ae8c <f0+0xd6c>
    ae48:	38626862 	ldrb	w2, [x3, x2]
    ae4c:	7100085f 	cmp	w2, #0x2
    ae50:	5400b260 	b.eq	c49c <f0+0x237c>  // b.none
    ae54:	7100045f 	cmp	w2, #0x1
    ae58:	540001a1 	b.ne	ae8c <f0+0xd6c>  // b.any
    ae5c:	29430002 	ldp	w2, w0, [x0, #24]
    ae60:	92403c21 	and	x1, x1, #0xffff
    ae64:	9b027c21 	mul	x1, x1, x2
    ae68:	d360fc21 	lsr	x1, x1, #32
    ae6c:	eb00003f 	cmp	x1, x0
    ae70:	540000e2 	b.cs	ae8c <f0+0xd6c>  // b.hs, b.nlast
    ae74:	8b0102f7 	add	x23, x23, x1
    ae78:	394002e0 	ldrb	w0, [x23]
    ae7c:	7103fc1f 	cmp	w0, #0xff
    ae80:	5400bf80 	b.eq	c670 <f0+0x2550>  // b.none
    ae84:	52800020 	mov	w0, #0x1                   	// #1
    ae88:	390002e0 	strb	w0, [x23]
    ae8c:	910ca3e1 	add	x1, sp, #0x328
    ae90:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ae94:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ae98:	52800020 	mov	w0, #0x1                   	// #1
    ae9c:	f90197f7 	str	x23, [sp, #808]
    aea0:	f9019bf5 	str	x21, [sp, #816]
    aea4:	97ffe9d7 	bl	5600 <fwp_data.part.0.constprop.0>
    aea8:	97ffea43 	bl	57b4 <fwp_rc_fresh>
    aeac:	aa0003e2 	mov	x2, x0
    aeb0:	910ce3e1 	add	x1, sp, #0x338
    aeb4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    aeb8:	52800020 	mov	w0, #0x1                   	// #1
    aebc:	f9019ff5 	str	x21, [sp, #824]
    aec0:	f901a3e2 	str	x2, [sp, #832]
    aec4:	97ffe9cf 	bl	5600 <fwp_data.part.0.constprop.0>
    aec8:	97ffea3b 	bl	57b4 <fwp_rc_fresh>
    aecc:	aa0003e2 	mov	x2, x0
    aed0:	910d23e1 	add	x1, sp, #0x348
    aed4:	52800020 	mov	w0, #0x1                   	// #1
    aed8:	f901a7f7 	str	x23, [sp, #840]
    aedc:	f901abe2 	str	x2, [sp, #848]
    aee0:	97ffe9c8 	bl	5600 <fwp_data.part.0.constprop.0>
    aee4:	97ffea34 	bl	57b4 <fwp_rc_fresh>
    aee8:	aa0003e2 	mov	x2, x0
    aeec:	910d63e1 	add	x1, sp, #0x358
    aef0:	52800020 	mov	w0, #0x1                   	// #1
    aef4:	f901aff5 	str	x21, [sp, #856]
    aef8:	f901b3e2 	str	x2, [sp, #864]
    aefc:	97ffe9c1 	bl	5600 <fwp_data.part.0.constprop.0>
    af00:	97ffea2d 	bl	57b4 <fwp_rc_fresh>
    af04:	aa0003e2 	mov	x2, x0
    af08:	910da3e1 	add	x1, sp, #0x368
    af0c:	52800020 	mov	w0, #0x1                   	// #1
    af10:	f901b7f7 	str	x23, [sp, #872]
    af14:	f901bbe2 	str	x2, [sp, #880]
    af18:	97ffe9ba 	bl	5600 <fwp_data.part.0.constprop.0>
    af1c:	97ffea26 	bl	57b4 <fwp_rc_fresh>
    af20:	aa0003e2 	mov	x2, x0
    af24:	910de3e1 	add	x1, sp, #0x378
    af28:	52800020 	mov	w0, #0x1                   	// #1
    af2c:	f901bff5 	str	x21, [sp, #888]
    af30:	f901c3e2 	str	x2, [sp, #896]
    af34:	97ffe9b3 	bl	5600 <fwp_data.part.0.constprop.0>
    af38:	97ffea1f 	bl	57b4 <fwp_rc_fresh>
    af3c:	aa0003e2 	mov	x2, x0
    af40:	910e23e1 	add	x1, sp, #0x388
    af44:	52800020 	mov	w0, #0x1                   	// #1
    af48:	f901c7f7 	str	x23, [sp, #904]
    af4c:	f901cbe2 	str	x2, [sp, #912]
    af50:	97ffe9ac 	bl	5600 <fwp_data.part.0.constprop.0>
    af54:	97ffea18 	bl	57b4 <fwp_rc_fresh>
    af58:	aa0003e2 	mov	x2, x0
    af5c:	910e63e1 	add	x1, sp, #0x398
    af60:	52800020 	mov	w0, #0x1                   	// #1
    af64:	f901cff5 	str	x21, [sp, #920]
    af68:	f901d3e2 	str	x2, [sp, #928]
    af6c:	97ffe9a5 	bl	5600 <fwp_data.part.0.constprop.0>
    af70:	97ffea11 	bl	57b4 <fwp_rc_fresh>
    af74:	aa0003e2 	mov	x2, x0
    af78:	910ea3e1 	add	x1, sp, #0x3a8
    af7c:	52800020 	mov	w0, #0x1                   	// #1
    af80:	f901d7f7 	str	x23, [sp, #936]
    af84:	f901dbe2 	str	x2, [sp, #944]
    af88:	97ffe99e 	bl	5600 <fwp_data.part.0.constprop.0>
    af8c:	97ffea0a 	bl	57b4 <fwp_rc_fresh>
    af90:	aa0003e2 	mov	x2, x0
    af94:	910ee3e1 	add	x1, sp, #0x3b8
    af98:	52800020 	mov	w0, #0x1                   	// #1
    af9c:	f901dff5 	str	x21, [sp, #952]
    afa0:	f901e3e2 	str	x2, [sp, #960]
    afa4:	97ffe997 	bl	5600 <fwp_data.part.0.constprop.0>
    afa8:	97ffea03 	bl	57b4 <fwp_rc_fresh>
    afac:	aa0003e2 	mov	x2, x0
    afb0:	910f23e1 	add	x1, sp, #0x3c8
    afb4:	52800020 	mov	w0, #0x1                   	// #1
    afb8:	f901e7f7 	str	x23, [sp, #968]
    afbc:	f901ebe2 	str	x2, [sp, #976]
    afc0:	97ffe990 	bl	5600 <fwp_data.part.0.constprop.0>
    afc4:	97ffe9fc 	bl	57b4 <fwp_rc_fresh>
    afc8:	aa0003e2 	mov	x2, x0
    afcc:	910f63e1 	add	x1, sp, #0x3d8
    afd0:	52800020 	mov	w0, #0x1                   	// #1
    afd4:	f901eff5 	str	x21, [sp, #984]
    afd8:	f901f3e2 	str	x2, [sp, #992]
    afdc:	97ffe989 	bl	5600 <fwp_data.part.0.constprop.0>
    afe0:	91174283 	add	x3, x20, #0x5d0
    afe4:	aa0003f5 	mov	x21, x0
    afe8:	f949d861 	ldr	x1, [x3, #5040]
    afec:	f949ec60 	ldr	x0, [x3, #5080]
    aff0:	cb0102a1 	sub	x1, x21, x1
    aff4:	eb00403f 	cmp	x1, x0, lsl #16
    aff8:	54000322 	b.cs	b05c <f0+0xf3c>  // b.hs, b.nlast
    affc:	d350fc22 	lsr	x2, x1, #16
    b000:	f949fc63 	ldr	x3, [x3, #5112]
    b004:	8b020842 	add	x2, x2, x2, lsl #2
    b008:	d37df042 	lsl	x2, x2, #3
    b00c:	8b020060 	add	x0, x3, x2
    b010:	f9401017 	ldr	x23, [x0, #32]
    b014:	b4000257 	cbz	x23, b05c <f0+0xf3c>
    b018:	38626862 	ldrb	w2, [x3, x2]
    b01c:	7100085f 	cmp	w2, #0x2
    b020:	5400a0e0 	b.eq	c43c <f0+0x231c>  // b.none
    b024:	7100045f 	cmp	w2, #0x1
    b028:	540001a1 	b.ne	b05c <f0+0xf3c>  // b.any
    b02c:	29430002 	ldp	w2, w0, [x0, #24]
    b030:	92403c21 	and	x1, x1, #0xffff
    b034:	9b027c21 	mul	x1, x1, x2
    b038:	d360fc21 	lsr	x1, x1, #32
    b03c:	eb00003f 	cmp	x1, x0
    b040:	540000e2 	b.cs	b05c <f0+0xf3c>  // b.hs, b.nlast
    b044:	8b0102f7 	add	x23, x23, x1
    b048:	394002e0 	ldrb	w0, [x23]
    b04c:	7103fc1f 	cmp	w0, #0xff
    b050:	5400b160 	b.eq	c67c <f0+0x255c>  // b.none
    b054:	52800020 	mov	w0, #0x1                   	// #1
    b058:	390002e0 	strb	w0, [x23]
    b05c:	910fa3e1 	add	x1, sp, #0x3e8
    b060:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b064:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b068:	52800020 	mov	w0, #0x1                   	// #1
    b06c:	f901f7f7 	str	x23, [sp, #1000]
    b070:	f901fbf5 	str	x21, [sp, #1008]
    b074:	97ffe963 	bl	5600 <fwp_data.part.0.constprop.0>
    b078:	97ffe9cf 	bl	57b4 <fwp_rc_fresh>
    b07c:	aa0003e2 	mov	x2, x0
    b080:	910fe3e1 	add	x1, sp, #0x3f8
    b084:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b088:	52800020 	mov	w0, #0x1                   	// #1
    b08c:	f901fff5 	str	x21, [sp, #1016]
    b090:	f90203e2 	str	x2, [sp, #1024]
    b094:	97ffe95b 	bl	5600 <fwp_data.part.0.constprop.0>
    b098:	97ffe9c7 	bl	57b4 <fwp_rc_fresh>
    b09c:	aa0003e2 	mov	x2, x0
    b0a0:	911023e1 	add	x1, sp, #0x408
    b0a4:	52800020 	mov	w0, #0x1                   	// #1
    b0a8:	f90207f7 	str	x23, [sp, #1032]
    b0ac:	f9020be2 	str	x2, [sp, #1040]
    b0b0:	97ffe954 	bl	5600 <fwp_data.part.0.constprop.0>
    b0b4:	97ffe9c0 	bl	57b4 <fwp_rc_fresh>
    b0b8:	aa0003e2 	mov	x2, x0
    b0bc:	911063e1 	add	x1, sp, #0x418
    b0c0:	52800020 	mov	w0, #0x1                   	// #1
    b0c4:	f9020ff5 	str	x21, [sp, #1048]
    b0c8:	f90213e2 	str	x2, [sp, #1056]
    b0cc:	97ffe94d 	bl	5600 <fwp_data.part.0.constprop.0>
    b0d0:	91174283 	add	x3, x20, #0x5d0
    b0d4:	aa0003f5 	mov	x21, x0
    b0d8:	f949d861 	ldr	x1, [x3, #5040]
    b0dc:	f949ec60 	ldr	x0, [x3, #5080]
    b0e0:	cb0102a1 	sub	x1, x21, x1
    b0e4:	eb00403f 	cmp	x1, x0, lsl #16
    b0e8:	54000322 	b.cs	b14c <f0+0x102c>  // b.hs, b.nlast
    b0ec:	d350fc22 	lsr	x2, x1, #16
    b0f0:	f949fc63 	ldr	x3, [x3, #5112]
    b0f4:	8b020842 	add	x2, x2, x2, lsl #2
    b0f8:	d37df042 	lsl	x2, x2, #3
    b0fc:	8b020060 	add	x0, x3, x2
    b100:	f9401017 	ldr	x23, [x0, #32]
    b104:	b4000257 	cbz	x23, b14c <f0+0x102c>
    b108:	38626862 	ldrb	w2, [x3, x2]
    b10c:	7100085f 	cmp	w2, #0x2
    b110:	54009900 	b.eq	c430 <f0+0x2310>  // b.none
    b114:	7100045f 	cmp	w2, #0x1
    b118:	540001a1 	b.ne	b14c <f0+0x102c>  // b.any
    b11c:	29430002 	ldp	w2, w0, [x0, #24]
    b120:	92403c21 	and	x1, x1, #0xffff
    b124:	9b027c21 	mul	x1, x1, x2
    b128:	d360fc21 	lsr	x1, x1, #32
    b12c:	eb00003f 	cmp	x1, x0
    b130:	540000e2 	b.cs	b14c <f0+0x102c>  // b.hs, b.nlast
    b134:	8b0102f7 	add	x23, x23, x1
    b138:	394002e0 	ldrb	w0, [x23]
    b13c:	7103fc1f 	cmp	w0, #0xff
    b140:	5400aa40 	b.eq	c688 <f0+0x2568>  // b.none
    b144:	52800020 	mov	w0, #0x1                   	// #1
    b148:	390002e0 	strb	w0, [x23]
    b14c:	9110a3e1 	add	x1, sp, #0x428
    b150:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b154:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b158:	52800020 	mov	w0, #0x1                   	// #1
    b15c:	f90217f7 	str	x23, [sp, #1064]
    b160:	f9021bf5 	str	x21, [sp, #1072]
    b164:	97ffe927 	bl	5600 <fwp_data.part.0.constprop.0>
    b168:	97ffe993 	bl	57b4 <fwp_rc_fresh>
    b16c:	aa0003e2 	mov	x2, x0
    b170:	9110e3e1 	add	x1, sp, #0x438
    b174:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b178:	52800020 	mov	w0, #0x1                   	// #1
    b17c:	f9021ff5 	str	x21, [sp, #1080]
    b180:	f90223e2 	str	x2, [sp, #1088]
    b184:	97ffe91f 	bl	5600 <fwp_data.part.0.constprop.0>
    b188:	97ffe98b 	bl	57b4 <fwp_rc_fresh>
    b18c:	aa0003e2 	mov	x2, x0
    b190:	911123e1 	add	x1, sp, #0x448
    b194:	52800020 	mov	w0, #0x1                   	// #1
    b198:	f90227f7 	str	x23, [sp, #1096]
    b19c:	f9022be2 	str	x2, [sp, #1104]
    b1a0:	97ffe918 	bl	5600 <fwp_data.part.0.constprop.0>
    b1a4:	97ffe984 	bl	57b4 <fwp_rc_fresh>
    b1a8:	aa0003e2 	mov	x2, x0
    b1ac:	911163e1 	add	x1, sp, #0x458
    b1b0:	52800020 	mov	w0, #0x1                   	// #1
    b1b4:	f9022ff5 	str	x21, [sp, #1112]
    b1b8:	f90233e2 	str	x2, [sp, #1120]
    b1bc:	97ffe911 	bl	5600 <fwp_data.part.0.constprop.0>
    b1c0:	91174283 	add	x3, x20, #0x5d0
    b1c4:	aa0003f5 	mov	x21, x0
    b1c8:	f949d861 	ldr	x1, [x3, #5040]
    b1cc:	f949ec60 	ldr	x0, [x3, #5080]
    b1d0:	cb0102a1 	sub	x1, x21, x1
    b1d4:	eb00403f 	cmp	x1, x0, lsl #16
    b1d8:	54000322 	b.cs	b23c <f0+0x111c>  // b.hs, b.nlast
    b1dc:	d350fc22 	lsr	x2, x1, #16
    b1e0:	f949fc63 	ldr	x3, [x3, #5112]
    b1e4:	8b020842 	add	x2, x2, x2, lsl #2
    b1e8:	d37df042 	lsl	x2, x2, #3
    b1ec:	8b020060 	add	x0, x3, x2
    b1f0:	f9401017 	ldr	x23, [x0, #32]
    b1f4:	b4000257 	cbz	x23, b23c <f0+0x111c>
    b1f8:	38626862 	ldrb	w2, [x3, x2]
    b1fc:	7100085f 	cmp	w2, #0x2
    b200:	54009120 	b.eq	c424 <f0+0x2304>  // b.none
    b204:	7100045f 	cmp	w2, #0x1
    b208:	540001a1 	b.ne	b23c <f0+0x111c>  // b.any
    b20c:	29430002 	ldp	w2, w0, [x0, #24]
    b210:	92403c21 	and	x1, x1, #0xffff
    b214:	9b027c21 	mul	x1, x1, x2
    b218:	d360fc21 	lsr	x1, x1, #32
    b21c:	eb00003f 	cmp	x1, x0
    b220:	540000e2 	b.cs	b23c <f0+0x111c>  // b.hs, b.nlast
    b224:	8b0102f7 	add	x23, x23, x1
    b228:	394002e0 	ldrb	w0, [x23]
    b22c:	7103fc1f 	cmp	w0, #0xff
    b230:	5400a320 	b.eq	c694 <f0+0x2574>  // b.none
    b234:	52800020 	mov	w0, #0x1                   	// #1
    b238:	390002e0 	strb	w0, [x23]
    b23c:	9111a3e1 	add	x1, sp, #0x468
    b240:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b244:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b248:	52800020 	mov	w0, #0x1                   	// #1
    b24c:	f90237f7 	str	x23, [sp, #1128]
    b250:	f9023bf5 	str	x21, [sp, #1136]
    b254:	97ffe8eb 	bl	5600 <fwp_data.part.0.constprop.0>
    b258:	97ffe957 	bl	57b4 <fwp_rc_fresh>
    b25c:	aa0003e2 	mov	x2, x0
    b260:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b264:	9111e3e1 	add	x1, sp, #0x478
    b268:	52800020 	mov	w0, #0x1                   	// #1
    b26c:	f9023fe3 	str	x3, [sp, #1144]
    b270:	f90243e2 	str	x2, [sp, #1152]
    b274:	97ffe8e3 	bl	5600 <fwp_data.part.0.constprop.0>
    b278:	97ffe94f 	bl	57b4 <fwp_rc_fresh>
    b27c:	aa0003e2 	mov	x2, x0
    b280:	911223e1 	add	x1, sp, #0x488
    b284:	52800020 	mov	w0, #0x1                   	// #1
    b288:	f90247f7 	str	x23, [sp, #1160]
    b28c:	f9024be2 	str	x2, [sp, #1168]
    b290:	97ffe8dc 	bl	5600 <fwp_data.part.0.constprop.0>
    b294:	91174283 	add	x3, x20, #0x5d0
    b298:	aa0003f5 	mov	x21, x0
    b29c:	f949d861 	ldr	x1, [x3, #5040]
    b2a0:	f949ec60 	ldr	x0, [x3, #5080]
    b2a4:	cb0102a1 	sub	x1, x21, x1
    b2a8:	eb00403f 	cmp	x1, x0, lsl #16
    b2ac:	54000322 	b.cs	b310 <f0+0x11f0>  // b.hs, b.nlast
    b2b0:	d350fc22 	lsr	x2, x1, #16
    b2b4:	f949fc63 	ldr	x3, [x3, #5112]
    b2b8:	8b020842 	add	x2, x2, x2, lsl #2
    b2bc:	d37df042 	lsl	x2, x2, #3
    b2c0:	8b020060 	add	x0, x3, x2
    b2c4:	f9401017 	ldr	x23, [x0, #32]
    b2c8:	b4000257 	cbz	x23, b310 <f0+0x11f0>
    b2cc:	38626862 	ldrb	w2, [x3, x2]
    b2d0:	7100085f 	cmp	w2, #0x2
    b2d4:	54008a20 	b.eq	c418 <f0+0x22f8>  // b.none
    b2d8:	7100045f 	cmp	w2, #0x1
    b2dc:	540001a1 	b.ne	b310 <f0+0x11f0>  // b.any
    b2e0:	29430002 	ldp	w2, w0, [x0, #24]
    b2e4:	92403c21 	and	x1, x1, #0xffff
    b2e8:	9b027c21 	mul	x1, x1, x2
    b2ec:	d360fc21 	lsr	x1, x1, #32
    b2f0:	eb00003f 	cmp	x1, x0
    b2f4:	540000e2 	b.cs	b310 <f0+0x11f0>  // b.hs, b.nlast
    b2f8:	8b0102f7 	add	x23, x23, x1
    b2fc:	394002e0 	ldrb	w0, [x23]
    b300:	7103fc1f 	cmp	w0, #0xff
    b304:	54009ce0 	b.eq	c6a0 <f0+0x2580>  // b.none
    b308:	52800020 	mov	w0, #0x1                   	// #1
    b30c:	390002e0 	strb	w0, [x23]
    b310:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b314:	911263e1 	add	x1, sp, #0x498
    b318:	52800020 	mov	w0, #0x1                   	// #1
    b31c:	f9024fe2 	str	x2, [sp, #1176]
    b320:	f90253f5 	str	x21, [sp, #1184]
    b324:	97ffe8b7 	bl	5600 <fwp_data.part.0.constprop.0>
    b328:	91174283 	add	x3, x20, #0x5d0
    b32c:	aa0003f5 	mov	x21, x0
    b330:	f949d861 	ldr	x1, [x3, #5040]
    b334:	f949ec60 	ldr	x0, [x3, #5080]
    b338:	cb0102a1 	sub	x1, x21, x1
    b33c:	eb00403f 	cmp	x1, x0, lsl #16
    b340:	54000322 	b.cs	b3a4 <f0+0x1284>  // b.hs, b.nlast
    b344:	d350fc22 	lsr	x2, x1, #16
    b348:	f949fc63 	ldr	x3, [x3, #5112]
    b34c:	8b020842 	add	x2, x2, x2, lsl #2
    b350:	d37df042 	lsl	x2, x2, #3
    b354:	8b020060 	add	x0, x3, x2
    b358:	f9401017 	ldr	x23, [x0, #32]
    b35c:	b4000257 	cbz	x23, b3a4 <f0+0x1284>
    b360:	38626862 	ldrb	w2, [x3, x2]
    b364:	7100085f 	cmp	w2, #0x2
    b368:	54008520 	b.eq	c40c <f0+0x22ec>  // b.none
    b36c:	7100045f 	cmp	w2, #0x1
    b370:	540001a1 	b.ne	b3a4 <f0+0x1284>  // b.any
    b374:	29430002 	ldp	w2, w0, [x0, #24]
    b378:	92403c21 	and	x1, x1, #0xffff
    b37c:	9b027c21 	mul	x1, x1, x2
    b380:	d360fc21 	lsr	x1, x1, #32
    b384:	eb00003f 	cmp	x1, x0
    b388:	540000e2 	b.cs	b3a4 <f0+0x1284>  // b.hs, b.nlast
    b38c:	8b0102f7 	add	x23, x23, x1
    b390:	394002e0 	ldrb	w0, [x23]
    b394:	7103fc1f 	cmp	w0, #0xff
    b398:	540098a0 	b.eq	c6ac <f0+0x258c>  // b.none
    b39c:	52800020 	mov	w0, #0x1                   	// #1
    b3a0:	390002e0 	strb	w0, [x23]
    b3a4:	9112a3e1 	add	x1, sp, #0x4a8
    b3a8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b3ac:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b3b0:	52800020 	mov	w0, #0x1                   	// #1
    b3b4:	f90257f7 	str	x23, [sp, #1192]
    b3b8:	f9025bf5 	str	x21, [sp, #1200]
    b3bc:	97ffe891 	bl	5600 <fwp_data.part.0.constprop.0>
    b3c0:	97ffe8fd 	bl	57b4 <fwp_rc_fresh>
    b3c4:	aa0003e2 	mov	x2, x0
    b3c8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b3cc:	9112e3e1 	add	x1, sp, #0x4b8
    b3d0:	52800020 	mov	w0, #0x1                   	// #1
    b3d4:	f9025fe3 	str	x3, [sp, #1208]
    b3d8:	f90263e2 	str	x2, [sp, #1216]
    b3dc:	97ffe889 	bl	5600 <fwp_data.part.0.constprop.0>
    b3e0:	97ffe8f5 	bl	57b4 <fwp_rc_fresh>
    b3e4:	aa0003e2 	mov	x2, x0
    b3e8:	911323e1 	add	x1, sp, #0x4c8
    b3ec:	52800020 	mov	w0, #0x1                   	// #1
    b3f0:	f90267f7 	str	x23, [sp, #1224]
    b3f4:	f9026be2 	str	x2, [sp, #1232]
    b3f8:	97ffe882 	bl	5600 <fwp_data.part.0.constprop.0>
    b3fc:	91174283 	add	x3, x20, #0x5d0
    b400:	aa0003f5 	mov	x21, x0
    b404:	f949d861 	ldr	x1, [x3, #5040]
    b408:	f949ec60 	ldr	x0, [x3, #5080]
    b40c:	cb0102a1 	sub	x1, x21, x1
    b410:	eb00403f 	cmp	x1, x0, lsl #16
    b414:	54000322 	b.cs	b478 <f0+0x1358>  // b.hs, b.nlast
    b418:	d350fc22 	lsr	x2, x1, #16
    b41c:	f949fc63 	ldr	x3, [x3, #5112]
    b420:	8b020842 	add	x2, x2, x2, lsl #2
    b424:	d37df042 	lsl	x2, x2, #3
    b428:	8b020060 	add	x0, x3, x2
    b42c:	f9401017 	ldr	x23, [x0, #32]
    b430:	b4000257 	cbz	x23, b478 <f0+0x1358>
    b434:	38626862 	ldrb	w2, [x3, x2]
    b438:	7100085f 	cmp	w2, #0x2
    b43c:	54007e20 	b.eq	c400 <f0+0x22e0>  // b.none
    b440:	7100045f 	cmp	w2, #0x1
    b444:	540001a1 	b.ne	b478 <f0+0x1358>  // b.any
    b448:	29430002 	ldp	w2, w0, [x0, #24]
    b44c:	92403c21 	and	x1, x1, #0xffff
    b450:	9b027c21 	mul	x1, x1, x2
    b454:	d360fc21 	lsr	x1, x1, #32
    b458:	eb00003f 	cmp	x1, x0
    b45c:	540000e2 	b.cs	b478 <f0+0x1358>  // b.hs, b.nlast
    b460:	8b0102f7 	add	x23, x23, x1
    b464:	394002e0 	ldrb	w0, [x23]
    b468:	7103fc1f 	cmp	w0, #0xff
    b46c:	54009260 	b.eq	c6b8 <f0+0x2598>  // b.none
    b470:	52800020 	mov	w0, #0x1                   	// #1
    b474:	390002e0 	strb	w0, [x23]
    b478:	911363e1 	add	x1, sp, #0x4d8
    b47c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b480:	52800020 	mov	w0, #0x1                   	// #1
    b484:	f9026ff7 	str	x23, [sp, #1240]
    b488:	f90273f5 	str	x21, [sp, #1248]
    b48c:	97ffe85d 	bl	5600 <fwp_data.part.0.constprop.0>
    b490:	97ffe8c9 	bl	57b4 <fwp_rc_fresh>
    b494:	aa0003e2 	mov	x2, x0
    b498:	9113a3e1 	add	x1, sp, #0x4e8
    b49c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b4a0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b4a4:	52800020 	mov	w0, #0x1                   	// #1
    b4a8:	f90277f5 	str	x21, [sp, #1256]
    b4ac:	f9027be2 	str	x2, [sp, #1264]
    b4b0:	97ffe854 	bl	5600 <fwp_data.part.0.constprop.0>
    b4b4:	97ffe8c0 	bl	57b4 <fwp_rc_fresh>
    b4b8:	aa0003e2 	mov	x2, x0
    b4bc:	9113e3e1 	add	x1, sp, #0x4f8
    b4c0:	52800020 	mov	w0, #0x1                   	// #1
    b4c4:	f9027ff7 	str	x23, [sp, #1272]
    b4c8:	f90283e2 	str	x2, [sp, #1280]
    b4cc:	97ffe84d 	bl	5600 <fwp_data.part.0.constprop.0>
    b4d0:	97ffe8b9 	bl	57b4 <fwp_rc_fresh>
    b4d4:	aa0003e2 	mov	x2, x0
    b4d8:	911423e1 	add	x1, sp, #0x508
    b4dc:	52800020 	mov	w0, #0x1                   	// #1
    b4e0:	f90287f5 	str	x21, [sp, #1288]
    b4e4:	f9028be2 	str	x2, [sp, #1296]
    b4e8:	97ffe846 	bl	5600 <fwp_data.part.0.constprop.0>
    b4ec:	97ffe8b2 	bl	57b4 <fwp_rc_fresh>
    b4f0:	aa0003e2 	mov	x2, x0
    b4f4:	911463e1 	add	x1, sp, #0x518
    b4f8:	52800020 	mov	w0, #0x1                   	// #1
    b4fc:	f9028ff7 	str	x23, [sp, #1304]
    b500:	f90293e2 	str	x2, [sp, #1312]
    b504:	97ffe83f 	bl	5600 <fwp_data.part.0.constprop.0>
    b508:	91174283 	add	x3, x20, #0x5d0
    b50c:	aa0003f7 	mov	x23, x0
    b510:	f949d861 	ldr	x1, [x3, #5040]
    b514:	f949ec60 	ldr	x0, [x3, #5080]
    b518:	cb0102e1 	sub	x1, x23, x1
    b51c:	eb00403f 	cmp	x1, x0, lsl #16
    b520:	54000322 	b.cs	b584 <f0+0x1464>  // b.hs, b.nlast
    b524:	d350fc22 	lsr	x2, x1, #16
    b528:	f949fc63 	ldr	x3, [x3, #5112]
    b52c:	8b020842 	add	x2, x2, x2, lsl #2
    b530:	d37df042 	lsl	x2, x2, #3
    b534:	8b020060 	add	x0, x3, x2
    b538:	f9401015 	ldr	x21, [x0, #32]
    b53c:	b4000255 	cbz	x21, b584 <f0+0x1464>
    b540:	38626862 	ldrb	w2, [x3, x2]
    b544:	7100085f 	cmp	w2, #0x2
    b548:	54007560 	b.eq	c3f4 <f0+0x22d4>  // b.none
    b54c:	7100045f 	cmp	w2, #0x1
    b550:	540001a1 	b.ne	b584 <f0+0x1464>  // b.any
    b554:	29430002 	ldp	w2, w0, [x0, #24]
    b558:	92403c21 	and	x1, x1, #0xffff
    b55c:	9b027c21 	mul	x1, x1, x2
    b560:	d360fc21 	lsr	x1, x1, #32
    b564:	eb00003f 	cmp	x1, x0
    b568:	540000e2 	b.cs	b584 <f0+0x1464>  // b.hs, b.nlast
    b56c:	8b0102b5 	add	x21, x21, x1
    b570:	394002a0 	ldrb	w0, [x21]
    b574:	7103fc1f 	cmp	w0, #0xff
    b578:	54008a60 	b.eq	c6c4 <f0+0x25a4>  // b.none
    b57c:	52800020 	mov	w0, #0x1                   	// #1
    b580:	390002a0 	strb	w0, [x21]
    b584:	9114a3e1 	add	x1, sp, #0x528
    b588:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b58c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b590:	52800020 	mov	w0, #0x1                   	// #1
    b594:	f90297f5 	str	x21, [sp, #1320]
    b598:	f9029bf7 	str	x23, [sp, #1328]
    b59c:	97ffe819 	bl	5600 <fwp_data.part.0.constprop.0>
    b5a0:	97ffe885 	bl	57b4 <fwp_rc_fresh>
    b5a4:	aa0003e2 	mov	x2, x0
    b5a8:	9114e3e1 	add	x1, sp, #0x538
    b5ac:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b5b0:	52800020 	mov	w0, #0x1                   	// #1
    b5b4:	f9029ff7 	str	x23, [sp, #1336]
    b5b8:	f902a3e2 	str	x2, [sp, #1344]
    b5bc:	97ffe811 	bl	5600 <fwp_data.part.0.constprop.0>
    b5c0:	97ffe87d 	bl	57b4 <fwp_rc_fresh>
    b5c4:	aa0003e2 	mov	x2, x0
    b5c8:	911523e1 	add	x1, sp, #0x548
    b5cc:	52800020 	mov	w0, #0x1                   	// #1
    b5d0:	f902a7f5 	str	x21, [sp, #1352]
    b5d4:	f902abe2 	str	x2, [sp, #1360]
    b5d8:	97ffe80a 	bl	5600 <fwp_data.part.0.constprop.0>
    b5dc:	97ffe876 	bl	57b4 <fwp_rc_fresh>
    b5e0:	aa0003e2 	mov	x2, x0
    b5e4:	911563e1 	add	x1, sp, #0x558
    b5e8:	52800020 	mov	w0, #0x1                   	// #1
    b5ec:	f902aff7 	str	x23, [sp, #1368]
    b5f0:	f902b3e2 	str	x2, [sp, #1376]
    b5f4:	97ffe803 	bl	5600 <fwp_data.part.0.constprop.0>
    b5f8:	97ffe86f 	bl	57b4 <fwp_rc_fresh>
    b5fc:	aa0003e2 	mov	x2, x0
    b600:	9115a3e1 	add	x1, sp, #0x568
    b604:	52800020 	mov	w0, #0x1                   	// #1
    b608:	f902b7f5 	str	x21, [sp, #1384]
    b60c:	f902bbe2 	str	x2, [sp, #1392]
    b610:	97ffe7fc 	bl	5600 <fwp_data.part.0.constprop.0>
    b614:	97ffe868 	bl	57b4 <fwp_rc_fresh>
    b618:	aa0003e2 	mov	x2, x0
    b61c:	9115e3e1 	add	x1, sp, #0x578
    b620:	52800020 	mov	w0, #0x1                   	// #1
    b624:	f902bff7 	str	x23, [sp, #1400]
    b628:	f902c3e2 	str	x2, [sp, #1408]
    b62c:	97ffe7f5 	bl	5600 <fwp_data.part.0.constprop.0>
    b630:	97ffe861 	bl	57b4 <fwp_rc_fresh>
    b634:	aa0003e2 	mov	x2, x0
    b638:	911623e1 	add	x1, sp, #0x588
    b63c:	52800020 	mov	w0, #0x1                   	// #1
    b640:	f902c7f5 	str	x21, [sp, #1416]
    b644:	f902cbe2 	str	x2, [sp, #1424]
    b648:	97ffe7ee 	bl	5600 <fwp_data.part.0.constprop.0>
    b64c:	97ffe85a 	bl	57b4 <fwp_rc_fresh>
    b650:	aa0003e2 	mov	x2, x0
    b654:	911663e1 	add	x1, sp, #0x598
    b658:	52800020 	mov	w0, #0x1                   	// #1
    b65c:	f902cff7 	str	x23, [sp, #1432]
    b660:	f902d3e2 	str	x2, [sp, #1440]
    b664:	97ffe7e7 	bl	5600 <fwp_data.part.0.constprop.0>
    b668:	97ffe853 	bl	57b4 <fwp_rc_fresh>
    b66c:	aa0003e2 	mov	x2, x0
    b670:	9116a3e1 	add	x1, sp, #0x5a8
    b674:	52800020 	mov	w0, #0x1                   	// #1
    b678:	f902d7f5 	str	x21, [sp, #1448]
    b67c:	f902dbe2 	str	x2, [sp, #1456]
    b680:	97ffe7e0 	bl	5600 <fwp_data.part.0.constprop.0>
    b684:	97ffe84c 	bl	57b4 <fwp_rc_fresh>
    b688:	aa0003e2 	mov	x2, x0
    b68c:	9116e3e1 	add	x1, sp, #0x5b8
    b690:	52800020 	mov	w0, #0x1                   	// #1
    b694:	f902dff7 	str	x23, [sp, #1464]
    b698:	f902e3e2 	str	x2, [sp, #1472]
    b69c:	97ffe7d9 	bl	5600 <fwp_data.part.0.constprop.0>
    b6a0:	97ffe845 	bl	57b4 <fwp_rc_fresh>
    b6a4:	aa0003e2 	mov	x2, x0
    b6a8:	911723e1 	add	x1, sp, #0x5c8
    b6ac:	52800020 	mov	w0, #0x1                   	// #1
    b6b0:	f902e7f5 	str	x21, [sp, #1480]
    b6b4:	f902ebe2 	str	x2, [sp, #1488]
    b6b8:	97ffe7d2 	bl	5600 <fwp_data.part.0.constprop.0>
    b6bc:	91174283 	add	x3, x20, #0x5d0
    b6c0:	aa0003f5 	mov	x21, x0
    b6c4:	f949d861 	ldr	x1, [x3, #5040]
    b6c8:	f949ec60 	ldr	x0, [x3, #5080]
    b6cc:	cb0102a1 	sub	x1, x21, x1
    b6d0:	eb00403f 	cmp	x1, x0, lsl #16
    b6d4:	54000322 	b.cs	b738 <f0+0x1618>  // b.hs, b.nlast
    b6d8:	d350fc22 	lsr	x2, x1, #16
    b6dc:	f949fc63 	ldr	x3, [x3, #5112]
    b6e0:	8b020842 	add	x2, x2, x2, lsl #2
    b6e4:	d37df042 	lsl	x2, x2, #3
    b6e8:	8b020060 	add	x0, x3, x2
    b6ec:	f9401017 	ldr	x23, [x0, #32]
    b6f0:	b4000257 	cbz	x23, b738 <f0+0x1618>
    b6f4:	38626862 	ldrb	w2, [x3, x2]
    b6f8:	7100085f 	cmp	w2, #0x2
    b6fc:	54006760 	b.eq	c3e8 <f0+0x22c8>  // b.none
    b700:	7100045f 	cmp	w2, #0x1
    b704:	540001a1 	b.ne	b738 <f0+0x1618>  // b.any
    b708:	29430002 	ldp	w2, w0, [x0, #24]
    b70c:	92403c21 	and	x1, x1, #0xffff
    b710:	9b027c21 	mul	x1, x1, x2
    b714:	d360fc21 	lsr	x1, x1, #32
    b718:	eb00003f 	cmp	x1, x0
    b71c:	540000e2 	b.cs	b738 <f0+0x1618>  // b.hs, b.nlast
    b720:	8b0102f7 	add	x23, x23, x1
    b724:	394002e0 	ldrb	w0, [x23]
    b728:	7103fc1f 	cmp	w0, #0xff
    b72c:	54007d20 	b.eq	c6d0 <f0+0x25b0>  // b.none
    b730:	52800020 	mov	w0, #0x1                   	// #1
    b734:	390002e0 	strb	w0, [x23]
    b738:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b73c:	911763e1 	add	x1, sp, #0x5d8
    b740:	52800020 	mov	w0, #0x1                   	// #1
    b744:	f902efe2 	str	x2, [sp, #1496]
    b748:	f902f3f5 	str	x21, [sp, #1504]
    b74c:	97ffe7ad 	bl	5600 <fwp_data.part.0.constprop.0>
    b750:	91174283 	add	x3, x20, #0x5d0
    b754:	aa0003f5 	mov	x21, x0
    b758:	f949d861 	ldr	x1, [x3, #5040]
    b75c:	f949ec60 	ldr	x0, [x3, #5080]
    b760:	cb0102a1 	sub	x1, x21, x1
    b764:	eb00403f 	cmp	x1, x0, lsl #16
    b768:	54000322 	b.cs	b7cc <f0+0x16ac>  // b.hs, b.nlast
    b76c:	d350fc22 	lsr	x2, x1, #16
    b770:	f949fc63 	ldr	x3, [x3, #5112]
    b774:	8b020842 	add	x2, x2, x2, lsl #2
    b778:	d37df042 	lsl	x2, x2, #3
    b77c:	8b020060 	add	x0, x3, x2
    b780:	f9401017 	ldr	x23, [x0, #32]
    b784:	b4000257 	cbz	x23, b7cc <f0+0x16ac>
    b788:	38626862 	ldrb	w2, [x3, x2]
    b78c:	7100085f 	cmp	w2, #0x2
    b790:	54007100 	b.eq	c5b0 <f0+0x2490>  // b.none
    b794:	7100045f 	cmp	w2, #0x1
    b798:	540001a1 	b.ne	b7cc <f0+0x16ac>  // b.any
    b79c:	29430002 	ldp	w2, w0, [x0, #24]
    b7a0:	92403c21 	and	x1, x1, #0xffff
    b7a4:	9b027c21 	mul	x1, x1, x2
    b7a8:	d360fc21 	lsr	x1, x1, #32
    b7ac:	eb00003f 	cmp	x1, x0
    b7b0:	540000e2 	b.cs	b7cc <f0+0x16ac>  // b.hs, b.nlast
    b7b4:	8b0102f7 	add	x23, x23, x1
    b7b8:	394002e0 	ldrb	w0, [x23]
    b7bc:	7103fc1f 	cmp	w0, #0xff
    b7c0:	540078e0 	b.eq	c6dc <f0+0x25bc>  // b.none
    b7c4:	52800020 	mov	w0, #0x1                   	// #1
    b7c8:	390002e0 	strb	w0, [x23]
    b7cc:	9117a3e1 	add	x1, sp, #0x5e8
    b7d0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b7d4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b7d8:	52800020 	mov	w0, #0x1                   	// #1
    b7dc:	f902f7f7 	str	x23, [sp, #1512]
    b7e0:	f902fbf5 	str	x21, [sp, #1520]
    b7e4:	97ffe787 	bl	5600 <fwp_data.part.0.constprop.0>
    b7e8:	97ffe7f3 	bl	57b4 <fwp_rc_fresh>
    b7ec:	aa0003e2 	mov	x2, x0
    b7f0:	9117e3e1 	add	x1, sp, #0x5f8
    b7f4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b7f8:	52800020 	mov	w0, #0x1                   	// #1
    b7fc:	f902fff5 	str	x21, [sp, #1528]
    b800:	f90303e2 	str	x2, [sp, #1536]
    b804:	97ffe77f 	bl	5600 <fwp_data.part.0.constprop.0>
    b808:	97ffe7eb 	bl	57b4 <fwp_rc_fresh>
    b80c:	aa0003e2 	mov	x2, x0
    b810:	911823e1 	add	x1, sp, #0x608
    b814:	52800020 	mov	w0, #0x1                   	// #1
    b818:	f90307f7 	str	x23, [sp, #1544]
    b81c:	f9030be2 	str	x2, [sp, #1552]
    b820:	97ffe778 	bl	5600 <fwp_data.part.0.constprop.0>
    b824:	97ffe7e4 	bl	57b4 <fwp_rc_fresh>
    b828:	aa0003e2 	mov	x2, x0
    b82c:	911863e1 	add	x1, sp, #0x618
    b830:	52800020 	mov	w0, #0x1                   	// #1
    b834:	f9030ff5 	str	x21, [sp, #1560]
    b838:	f90313e2 	str	x2, [sp, #1568]
    b83c:	97ffe771 	bl	5600 <fwp_data.part.0.constprop.0>
    b840:	91174283 	add	x3, x20, #0x5d0
    b844:	aa0003f5 	mov	x21, x0
    b848:	f949d861 	ldr	x1, [x3, #5040]
    b84c:	f949ec60 	ldr	x0, [x3, #5080]
    b850:	cb0102a1 	sub	x1, x21, x1
    b854:	eb00403f 	cmp	x1, x0, lsl #16
    b858:	54000322 	b.cs	b8bc <f0+0x179c>  // b.hs, b.nlast
    b85c:	d350fc22 	lsr	x2, x1, #16
    b860:	f949fc63 	ldr	x3, [x3, #5112]
    b864:	8b020842 	add	x2, x2, x2, lsl #2
    b868:	d37df042 	lsl	x2, x2, #3
    b86c:	8b020060 	add	x0, x3, x2
    b870:	f9401017 	ldr	x23, [x0, #32]
    b874:	b4000257 	cbz	x23, b8bc <f0+0x179c>
    b878:	38626862 	ldrb	w2, [x3, x2]
    b87c:	7100085f 	cmp	w2, #0x2
    b880:	54006920 	b.eq	c5a4 <f0+0x2484>  // b.none
    b884:	7100045f 	cmp	w2, #0x1
    b888:	540001a1 	b.ne	b8bc <f0+0x179c>  // b.any
    b88c:	29430002 	ldp	w2, w0, [x0, #24]
    b890:	92403c21 	and	x1, x1, #0xffff
    b894:	9b027c21 	mul	x1, x1, x2
    b898:	d360fc21 	lsr	x1, x1, #32
    b89c:	eb00003f 	cmp	x1, x0
    b8a0:	540000e2 	b.cs	b8bc <f0+0x179c>  // b.hs, b.nlast
    b8a4:	8b0102f7 	add	x23, x23, x1
    b8a8:	394002e0 	ldrb	w0, [x23]
    b8ac:	7103fc1f 	cmp	w0, #0xff
    b8b0:	540071c0 	b.eq	c6e8 <f0+0x25c8>  // b.none
    b8b4:	52800020 	mov	w0, #0x1                   	// #1
    b8b8:	390002e0 	strb	w0, [x23]
    b8bc:	9118a3e1 	add	x1, sp, #0x628
    b8c0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b8c4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b8c8:	52800020 	mov	w0, #0x1                   	// #1
    b8cc:	f90317f7 	str	x23, [sp, #1576]
    b8d0:	f9031bf5 	str	x21, [sp, #1584]
    b8d4:	97ffe74b 	bl	5600 <fwp_data.part.0.constprop.0>
    b8d8:	97ffe7b7 	bl	57b4 <fwp_rc_fresh>
    b8dc:	aa0003e2 	mov	x2, x0
    b8e0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b8e4:	9118e3e1 	add	x1, sp, #0x638
    b8e8:	52800020 	mov	w0, #0x1                   	// #1
    b8ec:	f9031fe3 	str	x3, [sp, #1592]
    b8f0:	f90323e2 	str	x2, [sp, #1600]
    b8f4:	97ffe743 	bl	5600 <fwp_data.part.0.constprop.0>
    b8f8:	97ffe7af 	bl	57b4 <fwp_rc_fresh>
    b8fc:	aa0003e2 	mov	x2, x0
    b900:	911923e1 	add	x1, sp, #0x648
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	f90327f7 	str	x23, [sp, #1608]
    b90c:	f9032be2 	str	x2, [sp, #1616]
    b910:	97ffe73c 	bl	5600 <fwp_data.part.0.constprop.0>
    b914:	91174283 	add	x3, x20, #0x5d0
    b918:	aa0003f5 	mov	x21, x0
    b91c:	f949d861 	ldr	x1, [x3, #5040]
    b920:	f949ec60 	ldr	x0, [x3, #5080]
    b924:	cb0102a1 	sub	x1, x21, x1
    b928:	eb00403f 	cmp	x1, x0, lsl #16
    b92c:	54000322 	b.cs	b990 <f0+0x1870>  // b.hs, b.nlast
    b930:	d350fc22 	lsr	x2, x1, #16
    b934:	f949fc63 	ldr	x3, [x3, #5112]
    b938:	8b020842 	add	x2, x2, x2, lsl #2
    b93c:	d37df042 	lsl	x2, x2, #3
    b940:	8b020060 	add	x0, x3, x2
    b944:	f9401017 	ldr	x23, [x0, #32]
    b948:	b4000257 	cbz	x23, b990 <f0+0x1870>
    b94c:	38626862 	ldrb	w2, [x3, x2]
    b950:	7100085f 	cmp	w2, #0x2
    b954:	54006220 	b.eq	c598 <f0+0x2478>  // b.none
    b958:	7100045f 	cmp	w2, #0x1
    b95c:	540001a1 	b.ne	b990 <f0+0x1870>  // b.any
    b960:	29430002 	ldp	w2, w0, [x0, #24]
    b964:	92403c21 	and	x1, x1, #0xffff
    b968:	9b027c21 	mul	x1, x1, x2
    b96c:	d360fc21 	lsr	x1, x1, #32
    b970:	eb00003f 	cmp	x1, x0
    b974:	540000e2 	b.cs	b990 <f0+0x1870>  // b.hs, b.nlast
    b978:	8b0102f7 	add	x23, x23, x1
    b97c:	394002e0 	ldrb	w0, [x23]
    b980:	7103fc1f 	cmp	w0, #0xff
    b984:	54006b80 	b.eq	c6f4 <f0+0x25d4>  // b.none
    b988:	52800020 	mov	w0, #0x1                   	// #1
    b98c:	390002e0 	strb	w0, [x23]
    b990:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b994:	911963e1 	add	x1, sp, #0x658
    b998:	52800020 	mov	w0, #0x1                   	// #1
    b99c:	f9032fe2 	str	x2, [sp, #1624]
    b9a0:	f90333f5 	str	x21, [sp, #1632]
    b9a4:	97ffe717 	bl	5600 <fwp_data.part.0.constprop.0>
    b9a8:	91174283 	add	x3, x20, #0x5d0
    b9ac:	aa0003f5 	mov	x21, x0
    b9b0:	f949d861 	ldr	x1, [x3, #5040]
    b9b4:	f949ec60 	ldr	x0, [x3, #5080]
    b9b8:	cb0102a1 	sub	x1, x21, x1
    b9bc:	eb00403f 	cmp	x1, x0, lsl #16
    b9c0:	54000322 	b.cs	ba24 <f0+0x1904>  // b.hs, b.nlast
    b9c4:	d350fc22 	lsr	x2, x1, #16
    b9c8:	f949fc63 	ldr	x3, [x3, #5112]
    b9cc:	8b020842 	add	x2, x2, x2, lsl #2
    b9d0:	d37df042 	lsl	x2, x2, #3
    b9d4:	8b020060 	add	x0, x3, x2
    b9d8:	f9401017 	ldr	x23, [x0, #32]
    b9dc:	b4000257 	cbz	x23, ba24 <f0+0x1904>
    b9e0:	38626862 	ldrb	w2, [x3, x2]
    b9e4:	7100085f 	cmp	w2, #0x2
    b9e8:	54005d20 	b.eq	c58c <f0+0x246c>  // b.none
    b9ec:	7100045f 	cmp	w2, #0x1
    b9f0:	540001a1 	b.ne	ba24 <f0+0x1904>  // b.any
    b9f4:	29430002 	ldp	w2, w0, [x0, #24]
    b9f8:	92403c21 	and	x1, x1, #0xffff
    b9fc:	9b027c21 	mul	x1, x1, x2
    ba00:	d360fc21 	lsr	x1, x1, #32
    ba04:	eb00003f 	cmp	x1, x0
    ba08:	540000e2 	b.cs	ba24 <f0+0x1904>  // b.hs, b.nlast
    ba0c:	8b0102f7 	add	x23, x23, x1
    ba10:	394002e0 	ldrb	w0, [x23]
    ba14:	7103fc1f 	cmp	w0, #0xff
    ba18:	54006740 	b.eq	c700 <f0+0x25e0>  // b.none
    ba1c:	52800020 	mov	w0, #0x1                   	// #1
    ba20:	390002e0 	strb	w0, [x23]
    ba24:	9119a3e1 	add	x1, sp, #0x668
    ba28:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ba2c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ba30:	52800020 	mov	w0, #0x1                   	// #1
    ba34:	f90337f7 	str	x23, [sp, #1640]
    ba38:	f9033bf5 	str	x21, [sp, #1648]
    ba3c:	97ffe6f1 	bl	5600 <fwp_data.part.0.constprop.0>
    ba40:	97ffe75d 	bl	57b4 <fwp_rc_fresh>
    ba44:	aa0003e2 	mov	x2, x0
    ba48:	9119e3e1 	add	x1, sp, #0x678
    ba4c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ba50:	52800020 	mov	w0, #0x1                   	// #1
    ba54:	f9033ff5 	str	x21, [sp, #1656]
    ba58:	f90343e2 	str	x2, [sp, #1664]
    ba5c:	97ffe6e9 	bl	5600 <fwp_data.part.0.constprop.0>
    ba60:	97ffe755 	bl	57b4 <fwp_rc_fresh>
    ba64:	aa0003e2 	mov	x2, x0
    ba68:	911a23e1 	add	x1, sp, #0x688
    ba6c:	52800020 	mov	w0, #0x1                   	// #1
    ba70:	f90347f7 	str	x23, [sp, #1672]
    ba74:	f9034be2 	str	x2, [sp, #1680]
    ba78:	97ffe6e2 	bl	5600 <fwp_data.part.0.constprop.0>
    ba7c:	97ffe74e 	bl	57b4 <fwp_rc_fresh>
    ba80:	aa0003e2 	mov	x2, x0
    ba84:	911a63e1 	add	x1, sp, #0x698
    ba88:	52800020 	mov	w0, #0x1                   	// #1
    ba8c:	f9034ff5 	str	x21, [sp, #1688]
    ba90:	f90353e2 	str	x2, [sp, #1696]
    ba94:	97ffe6db 	bl	5600 <fwp_data.part.0.constprop.0>
    ba98:	91174283 	add	x3, x20, #0x5d0
    ba9c:	aa0003f5 	mov	x21, x0
    baa0:	f949d861 	ldr	x1, [x3, #5040]
    baa4:	f949ec60 	ldr	x0, [x3, #5080]
    baa8:	cb0102a1 	sub	x1, x21, x1
    baac:	eb00403f 	cmp	x1, x0, lsl #16
    bab0:	54000322 	b.cs	bb14 <f0+0x19f4>  // b.hs, b.nlast
    bab4:	d350fc22 	lsr	x2, x1, #16
    bab8:	f949fc63 	ldr	x3, [x3, #5112]
    babc:	8b020842 	add	x2, x2, x2, lsl #2
    bac0:	d37df042 	lsl	x2, x2, #3
    bac4:	8b020060 	add	x0, x3, x2
    bac8:	f9401017 	ldr	x23, [x0, #32]
    bacc:	b4000257 	cbz	x23, bb14 <f0+0x19f4>
    bad0:	38626862 	ldrb	w2, [x3, x2]
    bad4:	7100085f 	cmp	w2, #0x2
    bad8:	54005540 	b.eq	c580 <f0+0x2460>  // b.none
    badc:	7100045f 	cmp	w2, #0x1
    bae0:	540001a1 	b.ne	bb14 <f0+0x19f4>  // b.any
    bae4:	29430002 	ldp	w2, w0, [x0, #24]
    bae8:	92403c21 	and	x1, x1, #0xffff
    baec:	9b027c21 	mul	x1, x1, x2
    baf0:	d360fc21 	lsr	x1, x1, #32
    baf4:	eb00003f 	cmp	x1, x0
    baf8:	540000e2 	b.cs	bb14 <f0+0x19f4>  // b.hs, b.nlast
    bafc:	8b0102f7 	add	x23, x23, x1
    bb00:	394002e0 	ldrb	w0, [x23]
    bb04:	7103fc1f 	cmp	w0, #0xff
    bb08:	54006020 	b.eq	c70c <f0+0x25ec>  // b.none
    bb0c:	52800020 	mov	w0, #0x1                   	// #1
    bb10:	390002e0 	strb	w0, [x23]
    bb14:	911aa3e1 	add	x1, sp, #0x6a8
    bb18:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bb1c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bb20:	52800020 	mov	w0, #0x1                   	// #1
    bb24:	f90357f7 	str	x23, [sp, #1704]
    bb28:	f9035bf5 	str	x21, [sp, #1712]
    bb2c:	97ffe6b5 	bl	5600 <fwp_data.part.0.constprop.0>
    bb30:	97ffe721 	bl	57b4 <fwp_rc_fresh>
    bb34:	aa0003e2 	mov	x2, x0
    bb38:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bb3c:	911ae3e1 	add	x1, sp, #0x6b8
    bb40:	52800020 	mov	w0, #0x1                   	// #1
    bb44:	f9035fe3 	str	x3, [sp, #1720]
    bb48:	f90363e2 	str	x2, [sp, #1728]
    bb4c:	97ffe6ad 	bl	5600 <fwp_data.part.0.constprop.0>
    bb50:	97ffe719 	bl	57b4 <fwp_rc_fresh>
    bb54:	aa0003e2 	mov	x2, x0
    bb58:	911b23e1 	add	x1, sp, #0x6c8
    bb5c:	52800020 	mov	w0, #0x1                   	// #1
    bb60:	f90367f7 	str	x23, [sp, #1736]
    bb64:	f9036be2 	str	x2, [sp, #1744]
    bb68:	97ffe6a6 	bl	5600 <fwp_data.part.0.constprop.0>
    bb6c:	91174283 	add	x3, x20, #0x5d0
    bb70:	aa0003f5 	mov	x21, x0
    bb74:	f949d861 	ldr	x1, [x3, #5040]
    bb78:	f949ec60 	ldr	x0, [x3, #5080]
    bb7c:	cb0102a1 	sub	x1, x21, x1
    bb80:	eb00403f 	cmp	x1, x0, lsl #16
    bb84:	54000322 	b.cs	bbe8 <f0+0x1ac8>  // b.hs, b.nlast
    bb88:	d350fc22 	lsr	x2, x1, #16
    bb8c:	f949fc63 	ldr	x3, [x3, #5112]
    bb90:	8b020842 	add	x2, x2, x2, lsl #2
    bb94:	d37df042 	lsl	x2, x2, #3
    bb98:	8b020060 	add	x0, x3, x2
    bb9c:	f9401017 	ldr	x23, [x0, #32]
    bba0:	b4000257 	cbz	x23, bbe8 <f0+0x1ac8>
    bba4:	38626862 	ldrb	w2, [x3, x2]
    bba8:	7100085f 	cmp	w2, #0x2
    bbac:	54004e40 	b.eq	c574 <f0+0x2454>  // b.none
    bbb0:	7100045f 	cmp	w2, #0x1
    bbb4:	540001a1 	b.ne	bbe8 <f0+0x1ac8>  // b.any
    bbb8:	29430002 	ldp	w2, w0, [x0, #24]
    bbbc:	92403c21 	and	x1, x1, #0xffff
    bbc0:	9b027c21 	mul	x1, x1, x2
    bbc4:	d360fc21 	lsr	x1, x1, #32
    bbc8:	eb00003f 	cmp	x1, x0
    bbcc:	540000e2 	b.cs	bbe8 <f0+0x1ac8>  // b.hs, b.nlast
    bbd0:	8b0102f7 	add	x23, x23, x1
    bbd4:	394002e0 	ldrb	w0, [x23]
    bbd8:	7103fc1f 	cmp	w0, #0xff
    bbdc:	540059e0 	b.eq	c718 <f0+0x25f8>  // b.none
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	390002e0 	strb	w0, [x23]
    bbe8:	911b63e1 	add	x1, sp, #0x6d8
    bbec:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bbf0:	52800020 	mov	w0, #0x1                   	// #1
    bbf4:	f9036ff7 	str	x23, [sp, #1752]
    bbf8:	f90373f5 	str	x21, [sp, #1760]
    bbfc:	97ffe681 	bl	5600 <fwp_data.part.0.constprop.0>
    bc00:	97ffe6ed 	bl	57b4 <fwp_rc_fresh>
    bc04:	aa0003e2 	mov	x2, x0
    bc08:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bc0c:	911ba3e1 	add	x1, sp, #0x6e8
    bc10:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bc14:	52800020 	mov	w0, #0x1                   	// #1
    bc18:	f90377e3 	str	x3, [sp, #1768]
    bc1c:	f9037be2 	str	x2, [sp, #1776]
    bc20:	97ffe678 	bl	5600 <fwp_data.part.0.constprop.0>
    bc24:	97ffe6e4 	bl	57b4 <fwp_rc_fresh>
    bc28:	aa0003e2 	mov	x2, x0
    bc2c:	911be3e1 	add	x1, sp, #0x6f8
    bc30:	52800020 	mov	w0, #0x1                   	// #1
    bc34:	f9037ff7 	str	x23, [sp, #1784]
    bc38:	f90383e2 	str	x2, [sp, #1792]
    bc3c:	97ffe671 	bl	5600 <fwp_data.part.0.constprop.0>
    bc40:	91174283 	add	x3, x20, #0x5d0
    bc44:	aa0003f5 	mov	x21, x0
    bc48:	f949d861 	ldr	x1, [x3, #5040]
    bc4c:	f949ec60 	ldr	x0, [x3, #5080]
    bc50:	cb0102a1 	sub	x1, x21, x1
    bc54:	eb00403f 	cmp	x1, x0, lsl #16
    bc58:	54000322 	b.cs	bcbc <f0+0x1b9c>  // b.hs, b.nlast
    bc5c:	d350fc22 	lsr	x2, x1, #16
    bc60:	f949fc63 	ldr	x3, [x3, #5112]
    bc64:	8b020842 	add	x2, x2, x2, lsl #2
    bc68:	d37df042 	lsl	x2, x2, #3
    bc6c:	8b020060 	add	x0, x3, x2
    bc70:	f9401017 	ldr	x23, [x0, #32]
    bc74:	b4000257 	cbz	x23, bcbc <f0+0x1b9c>
    bc78:	38626862 	ldrb	w2, [x3, x2]
    bc7c:	7100085f 	cmp	w2, #0x2
    bc80:	54004740 	b.eq	c568 <f0+0x2448>  // b.none
    bc84:	7100045f 	cmp	w2, #0x1
    bc88:	540001a1 	b.ne	bcbc <f0+0x1b9c>  // b.any
    bc8c:	29430002 	ldp	w2, w0, [x0, #24]
    bc90:	92403c21 	and	x1, x1, #0xffff
    bc94:	9b027c21 	mul	x1, x1, x2
    bc98:	d360fc21 	lsr	x1, x1, #32
    bc9c:	eb00003f 	cmp	x1, x0
    bca0:	540000e2 	b.cs	bcbc <f0+0x1b9c>  // b.hs, b.nlast
    bca4:	8b0102f7 	add	x23, x23, x1
    bca8:	394002e0 	ldrb	w0, [x23]
    bcac:	7103fc1f 	cmp	w0, #0xff
    bcb0:	540053a0 	b.eq	c724 <f0+0x2604>  // b.none
    bcb4:	52800020 	mov	w0, #0x1                   	// #1
    bcb8:	390002e0 	strb	w0, [x23]
    bcbc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bcc0:	911c23e1 	add	x1, sp, #0x708
    bcc4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bcc8:	52800020 	mov	w0, #0x1                   	// #1
    bccc:	f90387e2 	str	x2, [sp, #1800]
    bcd0:	f9038bf5 	str	x21, [sp, #1808]
    bcd4:	97ffe64b 	bl	5600 <fwp_data.part.0.constprop.0>
    bcd8:	97ffe6b7 	bl	57b4 <fwp_rc_fresh>
    bcdc:	aa0003e2 	mov	x2, x0
    bce0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bce4:	911c63e1 	add	x1, sp, #0x718
    bce8:	52800020 	mov	w0, #0x1                   	// #1
    bcec:	f9038fe3 	str	x3, [sp, #1816]
    bcf0:	f90393e2 	str	x2, [sp, #1824]
    bcf4:	97ffe643 	bl	5600 <fwp_data.part.0.constprop.0>
    bcf8:	91174283 	add	x3, x20, #0x5d0
    bcfc:	aa0003f5 	mov	x21, x0
    bd00:	f949d861 	ldr	x1, [x3, #5040]
    bd04:	f949ec60 	ldr	x0, [x3, #5080]
    bd08:	cb0102a1 	sub	x1, x21, x1
    bd0c:	eb00403f 	cmp	x1, x0, lsl #16
    bd10:	54000322 	b.cs	bd74 <f0+0x1c54>  // b.hs, b.nlast
    bd14:	d350fc22 	lsr	x2, x1, #16
    bd18:	f949fc63 	ldr	x3, [x3, #5112]
    bd1c:	8b020842 	add	x2, x2, x2, lsl #2
    bd20:	d37df042 	lsl	x2, x2, #3
    bd24:	8b020060 	add	x0, x3, x2
    bd28:	f9401017 	ldr	x23, [x0, #32]
    bd2c:	b4000257 	cbz	x23, bd74 <f0+0x1c54>
    bd30:	38626862 	ldrb	w2, [x3, x2]
    bd34:	7100085f 	cmp	w2, #0x2
    bd38:	54004120 	b.eq	c55c <f0+0x243c>  // b.none
    bd3c:	7100045f 	cmp	w2, #0x1
    bd40:	540001a1 	b.ne	bd74 <f0+0x1c54>  // b.any
    bd44:	29430002 	ldp	w2, w0, [x0, #24]
    bd48:	92403c21 	and	x1, x1, #0xffff
    bd4c:	9b027c21 	mul	x1, x1, x2
    bd50:	d360fc21 	lsr	x1, x1, #32
    bd54:	eb00003f 	cmp	x1, x0
    bd58:	540000e2 	b.cs	bd74 <f0+0x1c54>  // b.hs, b.nlast
    bd5c:	8b0102f7 	add	x23, x23, x1
    bd60:	394002e0 	ldrb	w0, [x23]
    bd64:	7103fc1f 	cmp	w0, #0xff
    bd68:	54004e40 	b.eq	c730 <f0+0x2610>  // b.none
    bd6c:	52800020 	mov	w0, #0x1                   	// #1
    bd70:	390002e0 	strb	w0, [x23]
    bd74:	911ca3e1 	add	x1, sp, #0x728
    bd78:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd7c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd80:	52800020 	mov	w0, #0x1                   	// #1
    bd84:	f90397f7 	str	x23, [sp, #1832]
    bd88:	f9039bf5 	str	x21, [sp, #1840]
    bd8c:	97ffe61d 	bl	5600 <fwp_data.part.0.constprop.0>
    bd90:	97ffe689 	bl	57b4 <fwp_rc_fresh>
    bd94:	aa0003e2 	mov	x2, x0
    bd98:	911ce3e1 	add	x1, sp, #0x738
    bd9c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bda0:	52800020 	mov	w0, #0x1                   	// #1
    bda4:	f9039ff5 	str	x21, [sp, #1848]
    bda8:	f903a3e2 	str	x2, [sp, #1856]
    bdac:	97ffe615 	bl	5600 <fwp_data.part.0.constprop.0>
    bdb0:	97ffe681 	bl	57b4 <fwp_rc_fresh>
    bdb4:	aa0003e2 	mov	x2, x0
    bdb8:	911d23e1 	add	x1, sp, #0x748
    bdbc:	52800020 	mov	w0, #0x1                   	// #1
    bdc0:	f903a7f7 	str	x23, [sp, #1864]
    bdc4:	f903abe2 	str	x2, [sp, #1872]
    bdc8:	97ffe60e 	bl	5600 <fwp_data.part.0.constprop.0>
    bdcc:	97ffe67a 	bl	57b4 <fwp_rc_fresh>
    bdd0:	aa0003e2 	mov	x2, x0
    bdd4:	911d63e1 	add	x1, sp, #0x758
    bdd8:	52800020 	mov	w0, #0x1                   	// #1
    bddc:	f903aff5 	str	x21, [sp, #1880]
    bde0:	f903b3e2 	str	x2, [sp, #1888]
    bde4:	97ffe607 	bl	5600 <fwp_data.part.0.constprop.0>
    bde8:	91174283 	add	x3, x20, #0x5d0
    bdec:	aa0003f5 	mov	x21, x0
    bdf0:	f949d861 	ldr	x1, [x3, #5040]
    bdf4:	f949ec60 	ldr	x0, [x3, #5080]
    bdf8:	cb0102a1 	sub	x1, x21, x1
    bdfc:	eb00403f 	cmp	x1, x0, lsl #16
    be00:	54000322 	b.cs	be64 <f0+0x1d44>  // b.hs, b.nlast
    be04:	d350fc22 	lsr	x2, x1, #16
    be08:	f949fc63 	ldr	x3, [x3, #5112]
    be0c:	8b020842 	add	x2, x2, x2, lsl #2
    be10:	d37df042 	lsl	x2, x2, #3
    be14:	8b020060 	add	x0, x3, x2
    be18:	f9401017 	ldr	x23, [x0, #32]
    be1c:	b4000257 	cbz	x23, be64 <f0+0x1d44>
    be20:	38626862 	ldrb	w2, [x3, x2]
    be24:	7100085f 	cmp	w2, #0x2
    be28:	54003940 	b.eq	c550 <f0+0x2430>  // b.none
    be2c:	7100045f 	cmp	w2, #0x1
    be30:	540001a1 	b.ne	be64 <f0+0x1d44>  // b.any
    be34:	29430002 	ldp	w2, w0, [x0, #24]
    be38:	92403c21 	and	x1, x1, #0xffff
    be3c:	9b027c21 	mul	x1, x1, x2
    be40:	d360fc21 	lsr	x1, x1, #32
    be44:	eb00003f 	cmp	x1, x0
    be48:	540000e2 	b.cs	be64 <f0+0x1d44>  // b.hs, b.nlast
    be4c:	8b0102f7 	add	x23, x23, x1
    be50:	394002e0 	ldrb	w0, [x23]
    be54:	7103fc1f 	cmp	w0, #0xff
    be58:	54004720 	b.eq	c73c <f0+0x261c>  // b.none
    be5c:	52800020 	mov	w0, #0x1                   	// #1
    be60:	390002e0 	strb	w0, [x23]
    be64:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be68:	911da3e1 	add	x1, sp, #0x768
    be6c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be70:	52800020 	mov	w0, #0x1                   	// #1
    be74:	f903b7e2 	str	x2, [sp, #1896]
    be78:	f903bbf5 	str	x21, [sp, #1904]
    be7c:	97ffe5e1 	bl	5600 <fwp_data.part.0.constprop.0>
    be80:	97ffe64d 	bl	57b4 <fwp_rc_fresh>
    be84:	aa0003e2 	mov	x2, x0
    be88:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    be8c:	911de3e1 	add	x1, sp, #0x778
    be90:	52800020 	mov	w0, #0x1                   	// #1
    be94:	f903bfe3 	str	x3, [sp, #1912]
    be98:	f903c3e2 	str	x2, [sp, #1920]
    be9c:	97ffe5d9 	bl	5600 <fwp_data.part.0.constprop.0>
    bea0:	91174283 	add	x3, x20, #0x5d0
    bea4:	aa0003f5 	mov	x21, x0
    bea8:	f949d861 	ldr	x1, [x3, #5040]
    beac:	f949ec60 	ldr	x0, [x3, #5080]
    beb0:	cb0102a1 	sub	x1, x21, x1
    beb4:	eb00403f 	cmp	x1, x0, lsl #16
    beb8:	54000322 	b.cs	bf1c <f0+0x1dfc>  // b.hs, b.nlast
    bebc:	d350fc22 	lsr	x2, x1, #16
    bec0:	f949fc63 	ldr	x3, [x3, #5112]
    bec4:	8b020842 	add	x2, x2, x2, lsl #2
    bec8:	d37df042 	lsl	x2, x2, #3
    becc:	8b020060 	add	x0, x3, x2
    bed0:	f9401017 	ldr	x23, [x0, #32]
    bed4:	b4000257 	cbz	x23, bf1c <f0+0x1dfc>
    bed8:	38626862 	ldrb	w2, [x3, x2]
    bedc:	7100085f 	cmp	w2, #0x2
    bee0:	54003320 	b.eq	c544 <f0+0x2424>  // b.none
    bee4:	7100045f 	cmp	w2, #0x1
    bee8:	540001a1 	b.ne	bf1c <f0+0x1dfc>  // b.any
    beec:	29430002 	ldp	w2, w0, [x0, #24]
    bef0:	92403c21 	and	x1, x1, #0xffff
    bef4:	9b027c21 	mul	x1, x1, x2
    bef8:	d360fc21 	lsr	x1, x1, #32
    befc:	eb00003f 	cmp	x1, x0
    bf00:	540000e2 	b.cs	bf1c <f0+0x1dfc>  // b.hs, b.nlast
    bf04:	8b0102f7 	add	x23, x23, x1
    bf08:	394002e0 	ldrb	w0, [x23]
    bf0c:	7103fc1f 	cmp	w0, #0xff
    bf10:	540041c0 	b.eq	c748 <f0+0x2628>  // b.none
    bf14:	52800020 	mov	w0, #0x1                   	// #1
    bf18:	390002e0 	strb	w0, [x23]
    bf1c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bf20:	911e23e1 	add	x1, sp, #0x788
    bf24:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bf28:	52800020 	mov	w0, #0x1                   	// #1
    bf2c:	f903c7e2 	str	x2, [sp, #1928]
    bf30:	f903cbf5 	str	x21, [sp, #1936]
    bf34:	97ffe5b3 	bl	5600 <fwp_data.part.0.constprop.0>
    bf38:	97ffe61f 	bl	57b4 <fwp_rc_fresh>
    bf3c:	aa0003e2 	mov	x2, x0
    bf40:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bf44:	911e63e1 	add	x1, sp, #0x798
    bf48:	52800020 	mov	w0, #0x1                   	// #1
    bf4c:	f903cfe3 	str	x3, [sp, #1944]
    bf50:	f903d3e2 	str	x2, [sp, #1952]
    bf54:	97ffe5ab 	bl	5600 <fwp_data.part.0.constprop.0>
    bf58:	91174283 	add	x3, x20, #0x5d0
    bf5c:	aa0003f5 	mov	x21, x0
    bf60:	f949d861 	ldr	x1, [x3, #5040]
    bf64:	f949ec60 	ldr	x0, [x3, #5080]
    bf68:	cb0102a1 	sub	x1, x21, x1
    bf6c:	eb00403f 	cmp	x1, x0, lsl #16
    bf70:	54000322 	b.cs	bfd4 <f0+0x1eb4>  // b.hs, b.nlast
    bf74:	d350fc22 	lsr	x2, x1, #16
    bf78:	f949fc63 	ldr	x3, [x3, #5112]
    bf7c:	8b020842 	add	x2, x2, x2, lsl #2
    bf80:	d37df042 	lsl	x2, x2, #3
    bf84:	8b020060 	add	x0, x3, x2
    bf88:	f9401017 	ldr	x23, [x0, #32]
    bf8c:	b4000257 	cbz	x23, bfd4 <f0+0x1eb4>
    bf90:	38626862 	ldrb	w2, [x3, x2]
    bf94:	7100085f 	cmp	w2, #0x2
    bf98:	54002d00 	b.eq	c538 <f0+0x2418>  // b.none
    bf9c:	7100045f 	cmp	w2, #0x1
    bfa0:	540001a1 	b.ne	bfd4 <f0+0x1eb4>  // b.any
    bfa4:	29430002 	ldp	w2, w0, [x0, #24]
    bfa8:	92403c21 	and	x1, x1, #0xffff
    bfac:	9b027c21 	mul	x1, x1, x2
    bfb0:	d360fc21 	lsr	x1, x1, #32
    bfb4:	eb00003f 	cmp	x1, x0
    bfb8:	540000e2 	b.cs	bfd4 <f0+0x1eb4>  // b.hs, b.nlast
    bfbc:	8b0102f7 	add	x23, x23, x1
    bfc0:	394002e0 	ldrb	w0, [x23]
    bfc4:	7103fc1f 	cmp	w0, #0xff
    bfc8:	54003c60 	b.eq	c754 <f0+0x2634>  // b.none
    bfcc:	52800020 	mov	w0, #0x1                   	// #1
    bfd0:	390002e0 	strb	w0, [x23]
    bfd4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bfd8:	911ea3e1 	add	x1, sp, #0x7a8
    bfdc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bfe0:	52800020 	mov	w0, #0x1                   	// #1
    bfe4:	f903d7e2 	str	x2, [sp, #1960]
    bfe8:	f903dbf5 	str	x21, [sp, #1968]
    bfec:	97ffe585 	bl	5600 <fwp_data.part.0.constprop.0>
    bff0:	91174283 	add	x3, x20, #0x5d0
    bff4:	aa0003f5 	mov	x21, x0
    bff8:	f949d861 	ldr	x1, [x3, #5040]
    bffc:	f949ec60 	ldr	x0, [x3, #5080]
    c000:	cb0102a1 	sub	x1, x21, x1
    c004:	eb00403f 	cmp	x1, x0, lsl #16
    c008:	54000322 	b.cs	c06c <f0+0x1f4c>  // b.hs, b.nlast
    c00c:	d350fc22 	lsr	x2, x1, #16
    c010:	f949fc63 	ldr	x3, [x3, #5112]
    c014:	8b020842 	add	x2, x2, x2, lsl #2
    c018:	d37df042 	lsl	x2, x2, #3
    c01c:	8b020060 	add	x0, x3, x2
    c020:	f9401017 	ldr	x23, [x0, #32]
    c024:	b4000257 	cbz	x23, c06c <f0+0x1f4c>
    c028:	38626862 	ldrb	w2, [x3, x2]
    c02c:	7100085f 	cmp	w2, #0x2
    c030:	540027e0 	b.eq	c52c <f0+0x240c>  // b.none
    c034:	7100045f 	cmp	w2, #0x1
    c038:	540001a1 	b.ne	c06c <f0+0x1f4c>  // b.any
    c03c:	29430002 	ldp	w2, w0, [x0, #24]
    c040:	92403c21 	and	x1, x1, #0xffff
    c044:	9b027c21 	mul	x1, x1, x2
    c048:	d360fc21 	lsr	x1, x1, #32
    c04c:	eb00003f 	cmp	x1, x0
    c050:	540000e2 	b.cs	c06c <f0+0x1f4c>  // b.hs, b.nlast
    c054:	8b0102f7 	add	x23, x23, x1
    c058:	394002e0 	ldrb	w0, [x23]
    c05c:	7103fc1f 	cmp	w0, #0xff
    c060:	54003800 	b.eq	c760 <f0+0x2640>  // b.none
    c064:	52800020 	mov	w0, #0x1                   	// #1
    c068:	390002e0 	strb	w0, [x23]
    c06c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c070:	911ee3e1 	add	x1, sp, #0x7b8
    c074:	52800020 	mov	w0, #0x1                   	// #1
    c078:	f903dfe2 	str	x2, [sp, #1976]
    c07c:	f903e3f5 	str	x21, [sp, #1984]
    c080:	97ffe560 	bl	5600 <fwp_data.part.0.constprop.0>
    c084:	91174283 	add	x3, x20, #0x5d0
    c088:	aa0003f7 	mov	x23, x0
    c08c:	f949d861 	ldr	x1, [x3, #5040]
    c090:	f949ec60 	ldr	x0, [x3, #5080]
    c094:	cb0102e1 	sub	x1, x23, x1
    c098:	eb00403f 	cmp	x1, x0, lsl #16
    c09c:	54000322 	b.cs	c100 <f0+0x1fe0>  // b.hs, b.nlast
    c0a0:	d350fc22 	lsr	x2, x1, #16
    c0a4:	f949fc63 	ldr	x3, [x3, #5112]
    c0a8:	8b020842 	add	x2, x2, x2, lsl #2
    c0ac:	d37df042 	lsl	x2, x2, #3
    c0b0:	8b020060 	add	x0, x3, x2
    c0b4:	f9401015 	ldr	x21, [x0, #32]
    c0b8:	b4000255 	cbz	x21, c100 <f0+0x1fe0>
    c0bc:	38626862 	ldrb	w2, [x3, x2]
    c0c0:	7100085f 	cmp	w2, #0x2
    c0c4:	540022e0 	b.eq	c520 <f0+0x2400>  // b.none
    c0c8:	7100045f 	cmp	w2, #0x1
    c0cc:	540001a1 	b.ne	c100 <f0+0x1fe0>  // b.any
    c0d0:	29430002 	ldp	w2, w0, [x0, #24]
    c0d4:	92403c21 	and	x1, x1, #0xffff
    c0d8:	9b027c21 	mul	x1, x1, x2
    c0dc:	d360fc21 	lsr	x1, x1, #32
    c0e0:	eb00003f 	cmp	x1, x0
    c0e4:	540000e2 	b.cs	c100 <f0+0x1fe0>  // b.hs, b.nlast
    c0e8:	8b0102b5 	add	x21, x21, x1
    c0ec:	394002a0 	ldrb	w0, [x21]
    c0f0:	7103fc1f 	cmp	w0, #0xff
    c0f4:	540033c0 	b.eq	c76c <f0+0x264c>  // b.none
    c0f8:	52800020 	mov	w0, #0x1                   	// #1
    c0fc:	390002a0 	strb	w0, [x21]
    c100:	911f23e1 	add	x1, sp, #0x7c8
    c104:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c108:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c10c:	52800020 	mov	w0, #0x1                   	// #1
    c110:	f903e7f5 	str	x21, [sp, #1992]
    c114:	f903ebf7 	str	x23, [sp, #2000]
    c118:	97ffe53a 	bl	5600 <fwp_data.part.0.constprop.0>
    c11c:	97ffe5a6 	bl	57b4 <fwp_rc_fresh>
    c120:	aa0003e2 	mov	x2, x0
    c124:	911f63e1 	add	x1, sp, #0x7d8
    c128:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c12c:	52800020 	mov	w0, #0x1                   	// #1
    c130:	f903eff7 	str	x23, [sp, #2008]
    c134:	f903f3e2 	str	x2, [sp, #2016]
    c138:	97ffe532 	bl	5600 <fwp_data.part.0.constprop.0>
    c13c:	97ffe59e 	bl	57b4 <fwp_rc_fresh>
    c140:	aa0003e2 	mov	x2, x0
    c144:	911fa3e1 	add	x1, sp, #0x7e8
    c148:	52800020 	mov	w0, #0x1                   	// #1
    c14c:	f903f7f5 	str	x21, [sp, #2024]
    c150:	f903fbe2 	str	x2, [sp, #2032]
    c154:	97ffe52b 	bl	5600 <fwp_data.part.0.constprop.0>
    c158:	97ffe597 	bl	57b4 <fwp_rc_fresh>
    c15c:	aa0003e2 	mov	x2, x0
    c160:	911fe3e1 	add	x1, sp, #0x7f8
    c164:	52800020 	mov	w0, #0x1                   	// #1
    c168:	f903fff7 	str	x23, [sp, #2040]
    c16c:	f90403e2 	str	x2, [sp, #2048]
    c170:	97ffe524 	bl	5600 <fwp_data.part.0.constprop.0>
    c174:	97ffe590 	bl	57b4 <fwp_rc_fresh>
    c178:	aa0003e2 	mov	x2, x0
    c17c:	912023e1 	add	x1, sp, #0x808
    c180:	52800020 	mov	w0, #0x1                   	// #1
    c184:	f90407f5 	str	x21, [sp, #2056]
    c188:	f9040be2 	str	x2, [sp, #2064]
    c18c:	97ffe51d 	bl	5600 <fwp_data.part.0.constprop.0>
    c190:	97ffe589 	bl	57b4 <fwp_rc_fresh>
    c194:	aa0003e2 	mov	x2, x0
    c198:	912063e1 	add	x1, sp, #0x818
    c19c:	52800020 	mov	w0, #0x1                   	// #1
    c1a0:	f9040ff7 	str	x23, [sp, #2072]
    c1a4:	f90413e2 	str	x2, [sp, #2080]
    c1a8:	97ffe516 	bl	5600 <fwp_data.part.0.constprop.0>
    c1ac:	97ffe582 	bl	57b4 <fwp_rc_fresh>
    c1b0:	aa0003e2 	mov	x2, x0
    c1b4:	9120a3e1 	add	x1, sp, #0x828
    c1b8:	52800020 	mov	w0, #0x1                   	// #1
    c1bc:	f90417f5 	str	x21, [sp, #2088]
    c1c0:	f9041be2 	str	x2, [sp, #2096]
    c1c4:	97ffe50f 	bl	5600 <fwp_data.part.0.constprop.0>
    c1c8:	91174283 	add	x3, x20, #0x5d0
    c1cc:	aa0003f5 	mov	x21, x0
    c1d0:	f949d861 	ldr	x1, [x3, #5040]
    c1d4:	f949ec60 	ldr	x0, [x3, #5080]
    c1d8:	cb0102a1 	sub	x1, x21, x1
    c1dc:	eb00403f 	cmp	x1, x0, lsl #16
    c1e0:	54000322 	b.cs	c244 <f0+0x2124>  // b.hs, b.nlast
    c1e4:	d350fc22 	lsr	x2, x1, #16
    c1e8:	f949fc63 	ldr	x3, [x3, #5112]
    c1ec:	8b020842 	add	x2, x2, x2, lsl #2
    c1f0:	d37df042 	lsl	x2, x2, #3
    c1f4:	8b020060 	add	x0, x3, x2
    c1f8:	f9401017 	ldr	x23, [x0, #32]
    c1fc:	b4000257 	cbz	x23, c244 <f0+0x2124>
    c200:	38626862 	ldrb	w2, [x3, x2]
    c204:	7100085f 	cmp	w2, #0x2
    c208:	54001860 	b.eq	c514 <f0+0x23f4>  // b.none
    c20c:	7100045f 	cmp	w2, #0x1
    c210:	540001a1 	b.ne	c244 <f0+0x2124>  // b.any
    c214:	29430002 	ldp	w2, w0, [x0, #24]
    c218:	92403c21 	and	x1, x1, #0xffff
    c21c:	9b027c21 	mul	x1, x1, x2
    c220:	d360fc21 	lsr	x1, x1, #32
    c224:	eb00003f 	cmp	x1, x0
    c228:	540000e2 	b.cs	c244 <f0+0x2124>  // b.hs, b.nlast
    c22c:	8b0102f7 	add	x23, x23, x1
    c230:	394002e0 	ldrb	w0, [x23]
    c234:	7103fc1f 	cmp	w0, #0xff
    c238:	54002a00 	b.eq	c778 <f0+0x2658>  // b.none
    c23c:	52800020 	mov	w0, #0x1                   	// #1
    c240:	390002e0 	strb	w0, [x23]
    c244:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c248:	9120e3e1 	add	x1, sp, #0x838
    c24c:	52800020 	mov	w0, #0x1                   	// #1
    c250:	f9041fe2 	str	x2, [sp, #2104]
    c254:	f90423f5 	str	x21, [sp, #2112]
    c258:	97ffe4ea 	bl	5600 <fwp_data.part.0.constprop.0>
    c25c:	91174283 	add	x3, x20, #0x5d0
    c260:	aa0003f5 	mov	x21, x0
    c264:	f949d861 	ldr	x1, [x3, #5040]
    c268:	f949ec60 	ldr	x0, [x3, #5080]
    c26c:	cb0102a1 	sub	x1, x21, x1
    c270:	eb00403f 	cmp	x1, x0, lsl #16
    c274:	54000322 	b.cs	c2d8 <f0+0x21b8>  // b.hs, b.nlast
    c278:	d350fc22 	lsr	x2, x1, #16
    c27c:	f949fc63 	ldr	x3, [x3, #5112]
    c280:	8b020842 	add	x2, x2, x2, lsl #2
    c284:	d37df042 	lsl	x2, x2, #3
    c288:	8b020060 	add	x0, x3, x2
    c28c:	f9401017 	ldr	x23, [x0, #32]
    c290:	b4000257 	cbz	x23, c2d8 <f0+0x21b8>
    c294:	38626862 	ldrb	w2, [x3, x2]
    c298:	7100085f 	cmp	w2, #0x2
    c29c:	54001360 	b.eq	c508 <f0+0x23e8>  // b.none
    c2a0:	7100045f 	cmp	w2, #0x1
    c2a4:	540001a1 	b.ne	c2d8 <f0+0x21b8>  // b.any
    c2a8:	29430002 	ldp	w2, w0, [x0, #24]
    c2ac:	92403c21 	and	x1, x1, #0xffff
    c2b0:	9b027c21 	mul	x1, x1, x2
    c2b4:	d360fc21 	lsr	x1, x1, #32
    c2b8:	eb00003f 	cmp	x1, x0
    c2bc:	540000e2 	b.cs	c2d8 <f0+0x21b8>  // b.hs, b.nlast
    c2c0:	8b0102f7 	add	x23, x23, x1
    c2c4:	394002e0 	ldrb	w0, [x23]
    c2c8:	7103fc1f 	cmp	w0, #0xff
    c2cc:	540025c0 	b.eq	c784 <f0+0x2664>  // b.none
    c2d0:	52800020 	mov	w0, #0x1                   	// #1
    c2d4:	390002e0 	strb	w0, [x23]
    c2d8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c2dc:	91174294 	add	x20, x20, #0x5d0
    c2e0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c2e4:	aa1603e1 	mov	x1, x22
    c2e8:	52800020 	mov	w0, #0x1                   	// #1
    c2ec:	f90427e2 	str	x2, [sp, #2120]
    c2f0:	f9042bf5 	str	x21, [sp, #2128]
    c2f4:	97ffe4c3 	bl	5600 <fwp_data.part.0.constprop.0>
    c2f8:	f949da81 	ldr	x1, [x20, #5040]
    c2fc:	aa0003f5 	mov	x21, x0
    c300:	f949ee80 	ldr	x0, [x20, #5080]
    c304:	cb0102a1 	sub	x1, x21, x1
    c308:	eb00403f 	cmp	x1, x0, lsl #16
    c30c:	54000322 	b.cs	c370 <f0+0x2250>  // b.hs, b.nlast
    c310:	d350fc22 	lsr	x2, x1, #16
    c314:	f949fe83 	ldr	x3, [x20, #5112]
    c318:	8b020842 	add	x2, x2, x2, lsl #2
    c31c:	d37df042 	lsl	x2, x2, #3
    c320:	8b020060 	add	x0, x3, x2
    c324:	f9401014 	ldr	x20, [x0, #32]
    c328:	b4000254 	cbz	x20, c370 <f0+0x2250>
    c32c:	38626862 	ldrb	w2, [x3, x2]
    c330:	7100085f 	cmp	w2, #0x2
    c334:	54000e40 	b.eq	c4fc <f0+0x23dc>  // b.none
    c338:	7100045f 	cmp	w2, #0x1
    c33c:	540001a1 	b.ne	c370 <f0+0x2250>  // b.any
    c340:	29430002 	ldp	w2, w0, [x0, #24]
    c344:	92403c21 	and	x1, x1, #0xffff
    c348:	9b027c21 	mul	x1, x1, x2
    c34c:	d360fc21 	lsr	x1, x1, #32
    c350:	eb00003f 	cmp	x1, x0
    c354:	540000e2 	b.cs	c370 <f0+0x2250>  // b.hs, b.nlast
    c358:	8b010294 	add	x20, x20, x1
    c35c:	39400280 	ldrb	w0, [x20]
    c360:	7103fc1f 	cmp	w0, #0xff
    c364:	540012c0 	b.eq	c5bc <f0+0x249c>  // b.none
    c368:	52800020 	mov	w0, #0x1                   	// #1
    c36c:	39000280 	strb	w0, [x20]
    c370:	aa1303e1 	mov	x1, x19
    c374:	aa1503e0 	mov	x0, x21
    c378:	97fff476 	bl	9550 <fwp_hof0.constprop.0>
    c37c:	aa0003f4 	mov	x20, x0
    c380:	aa1503e0 	mov	x0, x21
    c384:	97ffe613 	bl	5bd0 <fwp_drop0>
    c388:	aa1303e0 	mov	x0, x19
    c38c:	97ffe611 	bl	5bd0 <fwp_drop0>
    c390:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c394:	f947f400 	ldr	x0, [x0, #4072]
    c398:	f9442fe2 	ldr	x2, [sp, #2136]
    c39c:	f9400001 	ldr	x1, [x0]
    c3a0:	eb010042 	subs	x2, x2, x1
    c3a4:	d2800001 	mov	x1, #0x0                   	// #0
    c3a8:	54001f41 	b.ne	c790 <f0+0x2670>  // b.any
    c3ac:	912183ff 	add	sp, sp, #0x860
    c3b0:	aa1403e0 	mov	x0, x20
    c3b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    c3b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c3bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    c3c0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c3c4:	a94573fb 	ldp	x27, x28, [sp, #80]
    c3c8:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c3cc:	d65f03c0 	ret
    c3d0:	aa1b03e0 	mov	x0, x27
    c3d4:	97ffe107 	bl	47f0 <fwp_rc_forget_slot>
    c3d8:	17fff79a 	b	a240 <f0+0x120>
    c3dc:	72003c5f 	tst	w2, #0xffff
    c3e0:	54fef321 	b.ne	a244 <f0+0x124>  // b.any
    c3e4:	17fff794 	b	a234 <f0+0x114>
    c3e8:	72003c3f 	tst	w1, #0xffff
    c3ec:	54ff9a61 	b.ne	b738 <f0+0x1618>  // b.any
    c3f0:	17fffccd 	b	b724 <f0+0x1604>
    c3f4:	72003c3f 	tst	w1, #0xffff
    c3f8:	54ff8c61 	b.ne	b584 <f0+0x1464>  // b.any
    c3fc:	17fffc5d 	b	b570 <f0+0x1450>
    c400:	72003c3f 	tst	w1, #0xffff
    c404:	54ff83a1 	b.ne	b478 <f0+0x1358>  // b.any
    c408:	17fffc17 	b	b464 <f0+0x1344>
    c40c:	72003c3f 	tst	w1, #0xffff
    c410:	54ff7ca1 	b.ne	b3a4 <f0+0x1284>  // b.any
    c414:	17fffbdf 	b	b390 <f0+0x1270>
    c418:	72003c3f 	tst	w1, #0xffff
    c41c:	54ff77a1 	b.ne	b310 <f0+0x11f0>  // b.any
    c420:	17fffbb7 	b	b2fc <f0+0x11dc>
    c424:	72003c3f 	tst	w1, #0xffff
    c428:	54ff70a1 	b.ne	b23c <f0+0x111c>  // b.any
    c42c:	17fffb7f 	b	b228 <f0+0x1108>
    c430:	72003c3f 	tst	w1, #0xffff
    c434:	54ff68c1 	b.ne	b14c <f0+0x102c>  // b.any
    c438:	17fffb40 	b	b138 <f0+0x1018>
    c43c:	72003c3f 	tst	w1, #0xffff
    c440:	54ff60e1 	b.ne	b05c <f0+0xf3c>  // b.any
    c444:	17fffb01 	b	b048 <f0+0xf28>
    c448:	72003c3f 	tst	w1, #0xffff
    c44c:	54ff0b21 	b.ne	a5b0 <f0+0x490>  // b.any
    c450:	17fff853 	b	a59c <f0+0x47c>
    c454:	72003c3f 	tst	w1, #0xffff
    c458:	54ff0541 	b.ne	a500 <f0+0x3e0>  // b.any
    c45c:	17fff824 	b	a4ec <f0+0x3cc>
    c460:	72003c3f 	tst	w1, #0xffff
    c464:	54fefc61 	b.ne	a3f0 <f0+0x2d0>  // b.any
    c468:	17fff7dd 	b	a3dc <f0+0x2bc>
    c46c:	72003c3f 	tst	w1, #0xffff
    c470:	54ff1f21 	b.ne	a854 <f0+0x734>  // b.any
    c474:	17fff8f3 	b	a840 <f0+0x720>
    c478:	72003c3f 	tst	w1, #0xffff
    c47c:	54ff1a21 	b.ne	a7c0 <f0+0x6a0>  // b.any
    c480:	17fff8cb 	b	a7ac <f0+0x68c>
    c484:	72003c3f 	tst	w1, #0xffff
    c488:	54ff1441 	b.ne	a710 <f0+0x5f0>  // b.any
    c48c:	17fff89c 	b	a6fc <f0+0x5dc>
    c490:	72003c3f 	tst	w1, #0xffff
    c494:	54ff0e61 	b.ne	a660 <f0+0x540>  // b.any
    c498:	17fff86d 	b	a64c <f0+0x52c>
    c49c:	72003c3f 	tst	w1, #0xffff
    c4a0:	54ff4f61 	b.ne	ae8c <f0+0xd6c>  // b.any
    c4a4:	17fffa75 	b	ae78 <f0+0xd58>
    c4a8:	72003c3f 	tst	w1, #0xffff
    c4ac:	54ff4781 	b.ne	ad9c <f0+0xc7c>  // b.any
    c4b0:	17fffa36 	b	ad88 <f0+0xc68>
    c4b4:	72003c3f 	tst	w1, #0xffff
    c4b8:	54ff4161 	b.ne	ace4 <f0+0xbc4>  // b.any
    c4bc:	17fffa05 	b	acd0 <f0+0xbb0>
    c4c0:	72003c3f 	tst	w1, #0xffff
    c4c4:	54ff3a61 	b.ne	ac10 <f0+0xaf0>  // b.any
    c4c8:	17fff9cd 	b	abfc <f0+0xadc>
    c4cc:	72003c3f 	tst	w1, #0xffff
    c4d0:	54ff3361 	b.ne	ab3c <f0+0xa1c>  // b.any
    c4d4:	17fff995 	b	ab28 <f0+0xa08>
    c4d8:	72003c3f 	tst	w1, #0xffff
    c4dc:	54ff2e61 	b.ne	aaa8 <f0+0x988>  // b.any
    c4e0:	17fff96d 	b	aa94 <f0+0x974>
    c4e4:	72003c3f 	tst	w1, #0xffff
    c4e8:	54ff2761 	b.ne	a9d4 <f0+0x8b4>  // b.any
    c4ec:	17fff935 	b	a9c0 <f0+0x8a0>
    c4f0:	72003c3f 	tst	w1, #0xffff
    c4f4:	54ff2141 	b.ne	a91c <f0+0x7fc>  // b.any
    c4f8:	17fff904 	b	a908 <f0+0x7e8>
    c4fc:	72003c3f 	tst	w1, #0xffff
    c500:	54fff381 	b.ne	c370 <f0+0x2250>  // b.any
    c504:	17ffff96 	b	c35c <f0+0x223c>
    c508:	72003c3f 	tst	w1, #0xffff
    c50c:	54ffee61 	b.ne	c2d8 <f0+0x21b8>  // b.any
    c510:	17ffff6d 	b	c2c4 <f0+0x21a4>
    c514:	72003c3f 	tst	w1, #0xffff
    c518:	54ffe961 	b.ne	c244 <f0+0x2124>  // b.any
    c51c:	17ffff45 	b	c230 <f0+0x2110>
    c520:	72003c3f 	tst	w1, #0xffff
    c524:	54ffdee1 	b.ne	c100 <f0+0x1fe0>  // b.any
    c528:	17fffef1 	b	c0ec <f0+0x1fcc>
    c52c:	72003c3f 	tst	w1, #0xffff
    c530:	54ffd9e1 	b.ne	c06c <f0+0x1f4c>  // b.any
    c534:	17fffec9 	b	c058 <f0+0x1f38>
    c538:	72003c3f 	tst	w1, #0xffff
    c53c:	54ffd4c1 	b.ne	bfd4 <f0+0x1eb4>  // b.any
    c540:	17fffea0 	b	bfc0 <f0+0x1ea0>
    c544:	72003c3f 	tst	w1, #0xffff
    c548:	54ffcea1 	b.ne	bf1c <f0+0x1dfc>  // b.any
    c54c:	17fffe6f 	b	bf08 <f0+0x1de8>
    c550:	72003c3f 	tst	w1, #0xffff
    c554:	54ffc881 	b.ne	be64 <f0+0x1d44>  // b.any
    c558:	17fffe3e 	b	be50 <f0+0x1d30>
    c55c:	72003c3f 	tst	w1, #0xffff
    c560:	54ffc0a1 	b.ne	bd74 <f0+0x1c54>  // b.any
    c564:	17fffdff 	b	bd60 <f0+0x1c40>
    c568:	72003c3f 	tst	w1, #0xffff
    c56c:	54ffba81 	b.ne	bcbc <f0+0x1b9c>  // b.any
    c570:	17fffdce 	b	bca8 <f0+0x1b88>
    c574:	72003c3f 	tst	w1, #0xffff
    c578:	54ffb381 	b.ne	bbe8 <f0+0x1ac8>  // b.any
    c57c:	17fffd96 	b	bbd4 <f0+0x1ab4>
    c580:	72003c3f 	tst	w1, #0xffff
    c584:	54ffac81 	b.ne	bb14 <f0+0x19f4>  // b.any
    c588:	17fffd5e 	b	bb00 <f0+0x19e0>
    c58c:	72003c3f 	tst	w1, #0xffff
    c590:	54ffa4a1 	b.ne	ba24 <f0+0x1904>  // b.any
    c594:	17fffd1f 	b	ba10 <f0+0x18f0>
    c598:	72003c3f 	tst	w1, #0xffff
    c59c:	54ff9fa1 	b.ne	b990 <f0+0x1870>  // b.any
    c5a0:	17fffcf7 	b	b97c <f0+0x185c>
    c5a4:	72003c3f 	tst	w1, #0xffff
    c5a8:	54ff98a1 	b.ne	b8bc <f0+0x179c>  // b.any
    c5ac:	17fffcbf 	b	b8a8 <f0+0x1788>
    c5b0:	72003c3f 	tst	w1, #0xffff
    c5b4:	54ff90c1 	b.ne	b7cc <f0+0x16ac>  // b.any
    c5b8:	17fffc80 	b	b7b8 <f0+0x1698>
    c5bc:	aa1403e0 	mov	x0, x20
    c5c0:	97ffe08c 	bl	47f0 <fwp_rc_forget_slot>
    c5c4:	17ffff69 	b	c368 <f0+0x2248>
    c5c8:	aa1703e0 	mov	x0, x23
    c5cc:	97ffe089 	bl	47f0 <fwp_rc_forget_slot>
    c5d0:	17fff786 	b	a3e8 <f0+0x2c8>
    c5d4:	aa1703e0 	mov	x0, x23
    c5d8:	97ffe086 	bl	47f0 <fwp_rc_forget_slot>
    c5dc:	17fff7c7 	b	a4f8 <f0+0x3d8>
    c5e0:	aa1703e0 	mov	x0, x23
    c5e4:	97ffe083 	bl	47f0 <fwp_rc_forget_slot>
    c5e8:	17fff7f0 	b	a5a8 <f0+0x488>
    c5ec:	aa1703e0 	mov	x0, x23
    c5f0:	97ffe080 	bl	47f0 <fwp_rc_forget_slot>
    c5f4:	17fff819 	b	a658 <f0+0x538>
    c5f8:	aa1703e0 	mov	x0, x23
    c5fc:	97ffe07d 	bl	47f0 <fwp_rc_forget_slot>
    c600:	17fff842 	b	a708 <f0+0x5e8>
    c604:	aa1703e0 	mov	x0, x23
    c608:	97ffe07a 	bl	47f0 <fwp_rc_forget_slot>
    c60c:	17fff86b 	b	a7b8 <f0+0x698>
    c610:	aa1703e0 	mov	x0, x23
    c614:	97ffe077 	bl	47f0 <fwp_rc_forget_slot>
    c618:	17fff88d 	b	a84c <f0+0x72c>
    c61c:	aa1703e0 	mov	x0, x23
    c620:	97ffe074 	bl	47f0 <fwp_rc_forget_slot>
    c624:	17fff8bc 	b	a914 <f0+0x7f4>
    c628:	aa1703e0 	mov	x0, x23
    c62c:	97ffe071 	bl	47f0 <fwp_rc_forget_slot>
    c630:	17fff8e7 	b	a9cc <f0+0x8ac>
    c634:	aa1703e0 	mov	x0, x23
    c638:	97ffe06e 	bl	47f0 <fwp_rc_forget_slot>
    c63c:	17fff919 	b	aaa0 <f0+0x980>
    c640:	aa1703e0 	mov	x0, x23
    c644:	97ffe06b 	bl	47f0 <fwp_rc_forget_slot>
    c648:	17fff93b 	b	ab34 <f0+0xa14>
    c64c:	aa1703e0 	mov	x0, x23
    c650:	97ffe068 	bl	47f0 <fwp_rc_forget_slot>
    c654:	17fff96d 	b	ac08 <f0+0xae8>
    c658:	aa1703e0 	mov	x0, x23
    c65c:	97ffe065 	bl	47f0 <fwp_rc_forget_slot>
    c660:	17fff99f 	b	acdc <f0+0xbbc>
    c664:	aa1703e0 	mov	x0, x23
    c668:	97ffe062 	bl	47f0 <fwp_rc_forget_slot>
    c66c:	17fff9ca 	b	ad94 <f0+0xc74>
    c670:	aa1703e0 	mov	x0, x23
    c674:	97ffe05f 	bl	47f0 <fwp_rc_forget_slot>
    c678:	17fffa03 	b	ae84 <f0+0xd64>
    c67c:	aa1703e0 	mov	x0, x23
    c680:	97ffe05c 	bl	47f0 <fwp_rc_forget_slot>
    c684:	17fffa74 	b	b054 <f0+0xf34>
    c688:	aa1703e0 	mov	x0, x23
    c68c:	97ffe059 	bl	47f0 <fwp_rc_forget_slot>
    c690:	17fffaad 	b	b144 <f0+0x1024>
    c694:	aa1703e0 	mov	x0, x23
    c698:	97ffe056 	bl	47f0 <fwp_rc_forget_slot>
    c69c:	17fffae6 	b	b234 <f0+0x1114>
    c6a0:	aa1703e0 	mov	x0, x23
    c6a4:	97ffe053 	bl	47f0 <fwp_rc_forget_slot>
    c6a8:	17fffb18 	b	b308 <f0+0x11e8>
    c6ac:	aa1703e0 	mov	x0, x23
    c6b0:	97ffe050 	bl	47f0 <fwp_rc_forget_slot>
    c6b4:	17fffb3a 	b	b39c <f0+0x127c>
    c6b8:	aa1703e0 	mov	x0, x23
    c6bc:	97ffe04d 	bl	47f0 <fwp_rc_forget_slot>
    c6c0:	17fffb6c 	b	b470 <f0+0x1350>
    c6c4:	aa1503e0 	mov	x0, x21
    c6c8:	97ffe04a 	bl	47f0 <fwp_rc_forget_slot>
    c6cc:	17fffbac 	b	b57c <f0+0x145c>
    c6d0:	aa1703e0 	mov	x0, x23
    c6d4:	97ffe047 	bl	47f0 <fwp_rc_forget_slot>
    c6d8:	17fffc16 	b	b730 <f0+0x1610>
    c6dc:	aa1703e0 	mov	x0, x23
    c6e0:	97ffe044 	bl	47f0 <fwp_rc_forget_slot>
    c6e4:	17fffc38 	b	b7c4 <f0+0x16a4>
    c6e8:	aa1703e0 	mov	x0, x23
    c6ec:	97ffe041 	bl	47f0 <fwp_rc_forget_slot>
    c6f0:	17fffc71 	b	b8b4 <f0+0x1794>
    c6f4:	aa1703e0 	mov	x0, x23
    c6f8:	97ffe03e 	bl	47f0 <fwp_rc_forget_slot>
    c6fc:	17fffca3 	b	b988 <f0+0x1868>
    c700:	aa1703e0 	mov	x0, x23
    c704:	97ffe03b 	bl	47f0 <fwp_rc_forget_slot>
    c708:	17fffcc5 	b	ba1c <f0+0x18fc>
    c70c:	aa1703e0 	mov	x0, x23
    c710:	97ffe038 	bl	47f0 <fwp_rc_forget_slot>
    c714:	17fffcfe 	b	bb0c <f0+0x19ec>
    c718:	aa1703e0 	mov	x0, x23
    c71c:	97ffe035 	bl	47f0 <fwp_rc_forget_slot>
    c720:	17fffd30 	b	bbe0 <f0+0x1ac0>
    c724:	aa1703e0 	mov	x0, x23
    c728:	97ffe032 	bl	47f0 <fwp_rc_forget_slot>
    c72c:	17fffd62 	b	bcb4 <f0+0x1b94>
    c730:	aa1703e0 	mov	x0, x23
    c734:	97ffe02f 	bl	47f0 <fwp_rc_forget_slot>
    c738:	17fffd8d 	b	bd6c <f0+0x1c4c>
    c73c:	aa1703e0 	mov	x0, x23
    c740:	97ffe02c 	bl	47f0 <fwp_rc_forget_slot>
    c744:	17fffdc6 	b	be5c <f0+0x1d3c>
    c748:	aa1703e0 	mov	x0, x23
    c74c:	97ffe029 	bl	47f0 <fwp_rc_forget_slot>
    c750:	17fffdf1 	b	bf14 <f0+0x1df4>
    c754:	aa1703e0 	mov	x0, x23
    c758:	97ffe026 	bl	47f0 <fwp_rc_forget_slot>
    c75c:	17fffe1c 	b	bfcc <f0+0x1eac>
    c760:	aa1703e0 	mov	x0, x23
    c764:	97ffe023 	bl	47f0 <fwp_rc_forget_slot>
    c768:	17fffe3f 	b	c064 <f0+0x1f44>
    c76c:	aa1503e0 	mov	x0, x21
    c770:	97ffe020 	bl	47f0 <fwp_rc_forget_slot>
    c774:	17fffe61 	b	c0f8 <f0+0x1fd8>
    c778:	aa1703e0 	mov	x0, x23
    c77c:	97ffe01d 	bl	47f0 <fwp_rc_forget_slot>
    c780:	17fffeaf 	b	c23c <f0+0x211c>
    c784:	aa1703e0 	mov	x0, x23
    c788:	97ffe01a 	bl	47f0 <fwp_rc_forget_slot>
    c78c:	17fffed1 	b	c2d0 <f0+0x21b0>
    c790:	97ffd83c 	bl	2880 <__stack_chk_fail@plt>

000000000000c794 <fwp_main_thread>:
    c794:	d10443ff 	sub	sp, sp, #0x110
    c798:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c79c:	f947f400 	ldr	x0, [x0, #4072]
    c7a0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c7a4:	910303fd 	add	x29, sp, #0xc0
    c7a8:	a90d53f3 	stp	x19, x20, [sp, #208]
    c7ac:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    c7b0:	91174261 	add	x1, x19, #0x5d0
    c7b4:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c7b8:	b953a421 	ldr	w1, [x1, #5028]
    c7bc:	f9400002 	ldr	x2, [x0]
    c7c0:	f9005fe2 	str	x2, [sp, #184]
    c7c4:	d2800002 	mov	x2, #0x0                   	// #0
    c7c8:	34002801 	cbz	w1, ccc8 <fwp_main_thread+0x534>
    c7cc:	91174273 	add	x19, x19, #0x5d0
    c7d0:	b953aa60 	ldr	w0, [x19, #5032]
    c7d4:	35002720 	cbnz	w0, ccb8 <fwp_main_thread+0x524>
    c7d8:	91001fe2 	add	x2, sp, #0x7
    c7dc:	900000b5 	adrp	x21, 20000 <__data_start>
    c7e0:	900000a3 	adrp	x3, 20000 <__data_start>
    c7e4:	9101c2b3 	add	x19, x21, #0x70
    c7e8:	910fc063 	add	x3, x3, #0x3f0
    c7ec:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c7f0:	d2a00025 	mov	x5, #0x10000               	// #65536
    c7f4:	910023e0 	add	x0, sp, #0x8
    c7f8:	d2800001 	mov	x1, #0x0                   	// #0
    c7fc:	f90007e3 	str	x3, [sp, #8]
    c800:	b90013ff 	str	wzr, [sp, #16]
    c804:	a9019262 	stp	x2, x4, [x19, #24]
    c808:	f9000fe5 	str	x5, [sp, #24]
    c80c:	97ffd7b5 	bl	26e0 <sigaltstack@plt>
    c810:	350026c0 	cbnz	w0, cce8 <fwp_main_thread+0x554>
    c814:	4f000400 	movi	v0.4s, #0x0
    c818:	9100a3e0 	add	x0, sp, #0x28
    c81c:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    c820:	52800082 	mov	w2, #0x4                   	// #4
    c824:	9101c021 	add	x1, x1, #0x70
    c828:	72a10002 	movk	w2, #0x800, lsl #16
    c82c:	910083f4 	add	x20, sp, #0x20
    c830:	f90013e1 	str	x1, [sp, #32]
    c834:	3d802000 	str	q0, [x0, #128]
    c838:	b900abe2 	str	w2, [sp, #168]
    c83c:	ad000000 	stp	q0, q0, [x0]
    c840:	ad010000 	stp	q0, q0, [x0, #32]
    c844:	ad020000 	stp	q0, q0, [x0, #64]
    c848:	ad030000 	stp	q0, q0, [x0, #96]
    c84c:	97ffd7fd 	bl	2840 <sigemptyset@plt>
    c850:	350024c0 	cbnz	w0, cce8 <fwp_main_thread+0x554>
    c854:	aa1403e1 	mov	x1, x20
    c858:	d2800002 	mov	x2, #0x0                   	// #0
    c85c:	52800160 	mov	w0, #0xb                   	// #11
    c860:	97ffd810 	bl	28a0 <sigaction@plt>
    c864:	35002420 	cbnz	w0, cce8 <fwp_main_thread+0x554>
    c868:	aa1403e1 	mov	x1, x20
    c86c:	d2800002 	mov	x2, #0x0                   	// #0
    c870:	528000e0 	mov	w0, #0x7                   	// #7
    c874:	97ffd80b 	bl	28a0 <sigaction@plt>
    c878:	35002380 	cbnz	w0, cce8 <fwp_main_thread+0x554>
    c87c:	b9434a60 	ldr	w0, [x19, #840]
    c880:	34001fe0 	cbz	w0, cc7c <fwp_main_thread+0x4e8>
    c884:	9101c2b3 	add	x19, x21, #0x70
    c888:	a90f63f7 	stp	x23, x24, [sp, #240]
    c88c:	b9434e60 	ldr	w0, [x19, #844]
    c890:	340020a0 	cbz	w0, cca4 <fwp_main_thread+0x510>
    c894:	9101c2b6 	add	x22, x21, #0x70
    c898:	f9400ad4 	ldr	x20, [x22, #16]
    c89c:	b40010d4 	cbz	x20, cab4 <fwp_main_thread+0x320>
    c8a0:	aa1403f3 	mov	x19, x20
    c8a4:	91010297 	add	x23, x20, #0x40
    c8a8:	f90083f9 	str	x25, [sp, #256]
    c8ac:	52800038 	mov	w24, #0x1                   	// #1
    c8b0:	39414a99 	ldrb	w25, [x20, #82]
    c8b4:	39014a98 	strb	w24, [x20, #82]
    c8b8:	f9401680 	ldr	x0, [x20, #40]
    c8bc:	b4000620 	cbz	x0, c980 <fwp_main_thread+0x1ec>
    c8c0:	f9403281 	ldr	x1, [x20, #96]
    c8c4:	39414680 	ldrb	w0, [x20, #81]
    c8c8:	b4000b41 	cbz	x1, ca30 <fwp_main_thread+0x29c>
    c8cc:	36000a80 	tbz	w0, #0, ca1c <fwp_main_thread+0x288>
    c8d0:	39414a62 	ldrb	w2, [x19, #82]
    c8d4:	f9402280 	ldr	x0, [x20, #64]
    c8d8:	37000d62 	tbnz	w2, #0, ca84 <fwp_main_thread+0x2f0>
    c8dc:	f9403261 	ldr	x1, [x19, #96]
    c8e0:	a911fe77 	stp	x23, xzr, [x19, #280]
    c8e4:	f9009660 	str	x0, [x19, #296]
    c8e8:	b4000040 	cbz	x0, c8f0 <fwp_main_thread+0x15c>
    c8ec:	f9009013 	str	x19, [x0, #288]
    c8f0:	f9002293 	str	x19, [x20, #64]
    c8f4:	b4000101 	cbz	x1, c914 <fwp_main_thread+0x180>
    c8f8:	f9406ec0 	ldr	x0, [x22, #216]
    c8fc:	39015678 	strb	w24, [x19, #85]
    c900:	f9003661 	str	x1, [x19, #104]
    c904:	a910827f 	stp	xzr, x0, [x19, #264]
    c908:	b4000040 	cbz	x0, c910 <fwp_main_thread+0x17c>
    c90c:	f9008413 	str	x19, [x0, #264]
    c910:	f9006ed3 	str	x19, [x22, #216]
    c914:	39015a7f 	strb	wzr, [x19, #86]
    c918:	97ffe73b 	bl	6604 <fwp_block>
    c91c:	f9408e62 	ldr	x2, [x19, #280]
    c920:	b4000142 	cbz	x2, c948 <fwp_main_thread+0x1b4>
    c924:	a9520261 	ldp	x1, x0, [x19, #288]
    c928:	b4000ba1 	cbz	x1, ca9c <fwp_main_thread+0x308>
    c92c:	f9009420 	str	x0, [x1, #296]
    c930:	f9409660 	ldr	x0, [x19, #296]
    c934:	b4000040 	cbz	x0, c93c <fwp_main_thread+0x1a8>
    c938:	f9009001 	str	x1, [x0, #288]
    c93c:	91080260 	add	x0, x19, #0x200
    c940:	f900967f 	str	xzr, [x19, #296]
    c944:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c948:	39415660 	ldrb	w0, [x19, #85]
    c94c:	f9400ac2 	ldr	x2, [x22, #16]
    c950:	36000960 	tbz	w0, #0, ca7c <fwp_main_thread+0x2e8>
    c954:	a9508261 	ldp	x1, x0, [x19, #264]
    c958:	b4000a61 	cbz	x1, caa4 <fwp_main_thread+0x310>
    c95c:	f9008820 	str	x0, [x1, #272]
    c960:	b4000040 	cbz	x0, c968 <fwp_main_thread+0x1d4>
    c964:	f9008401 	str	x1, [x0, #264]
    c968:	91080260 	add	x0, x19, #0x200
    c96c:	3901567f 	strb	wzr, [x19, #85]
    c970:	aa0203f3 	mov	x19, x2
    c974:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c978:	f9401680 	ldr	x0, [x20, #40]
    c97c:	b5fffa20 	cbnz	x0, c8c0 <fwp_main_thread+0x12c>
    c980:	9101c2a0 	add	x0, x21, #0x70
    c984:	39014a99 	strb	w25, [x20, #82]
    c988:	f94083f9 	ldr	x25, [sp, #256]
    c98c:	f9419400 	ldr	x0, [x0, #808]
    c990:	b4001560 	cbz	x0, cc3c <fwp_main_thread+0x4a8>
    c994:	9101c2a0 	add	x0, x21, #0x70
    c998:	f941b001 	ldr	x1, [x0, #864]
    c99c:	b903581f 	str	wzr, [x0, #856]
    c9a0:	eb13003f 	cmp	x1, x19
    c9a4:	54001681 	b.ne	cc74 <fwp_main_thread+0x4e0>  // b.any
    c9a8:	b4000913 	cbz	x19, cac8 <fwp_main_thread+0x334>
    c9ac:	9101c2a0 	add	x0, x21, #0x70
    c9b0:	52800021 	mov	w1, #0x1                   	// #1
    c9b4:	39014a61 	strb	w1, [x19, #82]
    c9b8:	f9418005 	ldr	x5, [x0, #768]
    c9bc:	b4000865 	cbz	x5, cac8 <fwp_main_thread+0x334>
    c9c0:	394140a0 	ldrb	w0, [x5, #80]
    c9c4:	37000060 	tbnz	w0, #0, c9d0 <fwp_main_thread+0x23c>
    c9c8:	aa0503e0 	mov	x0, x5
    c9cc:	97ffdb49 	bl	36f0 <fwp_cancel_tree.part.0>
    c9d0:	f9409ca5 	ldr	x5, [x5, #312]
    c9d4:	b5ffff65 	cbnz	x5, c9c0 <fwp_main_thread+0x22c>
    c9d8:	9101c2b4 	add	x20, x21, #0x70
    c9dc:	52800036 	mov	w22, #0x1                   	// #1
    c9e0:	f9402a60 	ldr	x0, [x19, #80]
    c9e4:	f2001c1f 	tst	x0, #0xff000000ff
    c9e8:	540000e1 	b.ne	ca04 <fwp_main_thread+0x270>  // b.any
    c9ec:	f9403e80 	ldr	x0, [x20, #120]
    c9f0:	39015276 	strb	w22, [x19, #84]
    c9f4:	f900827f 	str	xzr, [x19, #256]
    c9f8:	b40005a0 	cbz	x0, caac <fwp_main_thread+0x318>
    c9fc:	f9008013 	str	x19, [x0, #256]
    ca00:	f9003e93 	str	x19, [x20, #120]
    ca04:	97ffe700 	bl	6604 <fwp_block>
    ca08:	97ffe692 	bl	6450 <fwp_free_zombie>
    ca0c:	f9418280 	ldr	x0, [x20, #768]
    ca10:	b40005c0 	cbz	x0, cac8 <fwp_main_thread+0x334>
    ca14:	f941b293 	ldr	x19, [x20, #864]
    ca18:	17fffff2 	b	c9e0 <fwp_main_thread+0x24c>
    ca1c:	97ffdbd9 	bl	3980 <fwp_now_ns>
    ca20:	f9403281 	ldr	x1, [x20, #96]
    ca24:	eb01001f 	cmp	x0, x1
    ca28:	54000fca 	b.ge	cc20 <fwp_main_thread+0x48c>  // b.tcont
    ca2c:	39414680 	ldrb	w0, [x20, #81]
    ca30:	39414a62 	ldrb	w2, [x19, #82]
    ca34:	3707f500 	tbnz	w0, #0, c8d4 <fwp_main_thread+0x140>
    ca38:	f9403281 	ldr	x1, [x20, #96]
    ca3c:	370001c2 	tbnz	w2, #0, ca74 <fwp_main_thread+0x2e0>
    ca40:	f9403260 	ldr	x0, [x19, #96]
    ca44:	b4000180 	cbz	x0, ca74 <fwp_main_thread+0x2e0>
    ca48:	b4000061 	cbz	x1, ca54 <fwp_main_thread+0x2c0>
    ca4c:	eb01001f 	cmp	x0, x1
    ca50:	9a81d000 	csel	x0, x0, x1, le
    ca54:	f9402281 	ldr	x1, [x20, #64]
    ca58:	a911fe77 	stp	x23, xzr, [x19, #280]
    ca5c:	f9009661 	str	x1, [x19, #296]
    ca60:	b4001381 	cbz	x1, ccd0 <fwp_main_thread+0x53c>
    ca64:	f9009033 	str	x19, [x1, #288]
    ca68:	aa0003e1 	mov	x1, x0
    ca6c:	f9002293 	str	x19, [x20, #64]
    ca70:	17ffffa2 	b	c8f8 <fwp_main_thread+0x164>
    ca74:	f9402280 	ldr	x0, [x20, #64]
    ca78:	17ffff9a 	b	c8e0 <fwp_main_thread+0x14c>
    ca7c:	aa0203f3 	mov	x19, x2
    ca80:	17ffff8e 	b	c8b8 <fwp_main_thread+0x124>
    ca84:	a911fe77 	stp	x23, xzr, [x19, #280]
    ca88:	f9009660 	str	x0, [x19, #296]
    ca8c:	b4000040 	cbz	x0, ca94 <fwp_main_thread+0x300>
    ca90:	f9009013 	str	x19, [x0, #288]
    ca94:	f9002293 	str	x19, [x20, #64]
    ca98:	17ffff9f 	b	c914 <fwp_main_thread+0x180>
    ca9c:	f9000040 	str	x0, [x2]
    caa0:	17ffffa5 	b	c934 <fwp_main_thread+0x1a0>
    caa4:	f9006ec0 	str	x0, [x22, #216]
    caa8:	17ffffae 	b	c960 <fwp_main_thread+0x1cc>
    caac:	f9004293 	str	x19, [x20, #128]
    cab0:	17ffffd4 	b	ca00 <fwp_main_thread+0x26c>
    cab4:	f94196c0 	ldr	x0, [x22, #808]
    cab8:	b4000c00 	cbz	x0, cc38 <fwp_main_thread+0x4a4>
    cabc:	f941b2c0 	ldr	x0, [x22, #864]
    cac0:	b9035adf 	str	wzr, [x22, #856]
    cac4:	b5000d80 	cbnz	x0, cc74 <fwp_main_thread+0x4e0>
    cac8:	9101c2b4 	add	x20, x21, #0x70
    cacc:	97ffe661 	bl	6450 <fwp_free_zombie>
    cad0:	f9404280 	ldr	x0, [x20, #128]
    cad4:	b5000d00 	cbnz	x0, cc74 <fwp_main_thread+0x4e0>
    cad8:	f9406e80 	ldr	x0, [x20, #216]
    cadc:	b5000cc0 	cbnz	x0, cc74 <fwp_main_thread+0x4e0>
    cae0:	b940fa93 	ldr	w19, [x20, #248]
    cae4:	340001d3 	cbz	w19, cb1c <fwp_main_thread+0x388>
    cae8:	93407e76 	sxtw	x22, w19
    caec:	51000673 	sub	w19, w19, #0x1
    caf0:	d1000ad6 	sub	x22, x22, #0x2
    caf4:	91040297 	add	x23, x20, #0x100
    caf8:	cb3342d6 	sub	x22, x22, w19, uxtw
    cafc:	93407e73 	sxtw	x19, w19
    cb00:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    cb04:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cb08:	b900fa93 	str	w19, [x20, #248]
    cb0c:	d1000673 	sub	x19, x19, #0x1
    cb10:	97ffd7a4 	bl	29a0 <munmap@plt>
    cb14:	eb16027f 	cmp	x19, x22
    cb18:	54ffff41 	b.ne	cb00 <fwp_main_thread+0x36c>  // b.any
    cb1c:	900000b3 	adrp	x19, 20000 <__data_start>
    cb20:	91004260 	add	x0, x19, #0x10
    cb24:	b9404800 	ldr	w0, [x0, #72]
    cb28:	37f80040 	tbnz	w0, #31, cb30 <fwp_main_thread+0x39c>
    cb2c:	97ffd759 	bl	2890 <close@plt>
    cb30:	9101c2a0 	add	x0, x21, #0x70
    cb34:	91004261 	add	x1, x19, #0x10
    cb38:	12800002 	mov	w2, #0xffffffff            	// #-1
    cb3c:	d2800013 	mov	x19, #0x0                   	// #0
    cb40:	f941b416 	ldr	x22, [x0, #872]
    cb44:	b9004822 	str	w2, [x1, #72]
    cb48:	f941b814 	ldr	x20, [x0, #880]
    cb4c:	b4000176 	cbz	x22, cb78 <fwp_main_thread+0x3e4>
    cb50:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    cb54:	b40000c0 	cbz	x0, cb6c <fwp_main_thread+0x3d8>
    cb58:	f9400001 	ldr	x1, [x0]
    cb5c:	b50008c1 	cbnz	x1, cc74 <fwp_main_thread+0x4e0>
    cb60:	f9400401 	ldr	x1, [x0, #8]
    cb64:	b5000881 	cbnz	x1, cc74 <fwp_main_thread+0x4e0>
    cb68:	97ffdfc2 	bl	4a70 <fwp_mem_free>
    cb6c:	91000673 	add	x19, x19, #0x1
    cb70:	eb16027f 	cmp	x19, x22
    cb74:	54fffee1 	b.ne	cb50 <fwp_main_thread+0x3bc>  // b.any
    cb78:	aa1403e0 	mov	x0, x20
    cb7c:	97ffdfbd 	bl	4a70 <fwp_mem_free>
    cb80:	9101c2a0 	add	x0, x21, #0x70
    cb84:	f941b013 	ldr	x19, [x0, #864]
    cb88:	f901b41f 	str	xzr, [x0, #872]
    cb8c:	f901b81f 	str	xzr, [x0, #880]
    cb90:	b40001f3 	cbz	x19, cbcc <fwp_main_thread+0x438>
    cb94:	f9401661 	ldr	x1, [x19, #40]
    cb98:	b50006e1 	cbnz	x1, cc74 <fwp_main_thread+0x4e0>
    cb9c:	f9405661 	ldr	x1, [x19, #168]
    cba0:	b50006a1 	cbnz	x1, cc74 <fwp_main_thread+0x4e0>
    cba4:	f9419401 	ldr	x1, [x0, #808]
    cba8:	b5000661 	cbnz	x1, cc74 <fwp_main_thread+0x4e0>
    cbac:	f9419c00 	ldr	x0, [x0, #824]
    cbb0:	b5000620 	cbnz	x0, cc74 <fwp_main_thread+0x4e0>
    cbb4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cbb8:	90000120 	adrp	x0, 30000 <alt.5+0xfc10>
    cbbc:	910fc000 	add	x0, x0, #0x3f0
    cbc0:	97ffd724 	bl	2850 <memset@plt>
    cbc4:	aa1303e0 	mov	x0, x19
    cbc8:	97ffdfaa 	bl	4a70 <fwp_mem_free>
    cbcc:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cbd0:	f947ec00 	ldr	x0, [x0, #4056]
    cbd4:	9101c2b5 	add	x21, x21, #0x70
    cbd8:	f9400000 	ldr	x0, [x0]
    cbdc:	f9000abf 	str	xzr, [x21, #16]
    cbe0:	f901b2bf 	str	xzr, [x21, #864]
    cbe4:	97ffd773 	bl	29b0 <fflush@plt>
    cbe8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cbec:	f947f400 	ldr	x0, [x0, #4072]
    cbf0:	f9405fe2 	ldr	x2, [sp, #184]
    cbf4:	f9400001 	ldr	x1, [x0]
    cbf8:	eb010042 	subs	x2, x2, x1
    cbfc:	d2800001 	mov	x1, #0x0                   	// #0
    cc00:	54000821 	b.ne	cd04 <fwp_main_thread+0x570>  // b.any
    cc04:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cc08:	d2800000 	mov	x0, #0x0                   	// #0
    cc0c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cc10:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cc14:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cc18:	910443ff 	add	sp, sp, #0x110
    cc1c:	d65f03c0 	ret
    cc20:	39414280 	ldrb	w0, [x20, #80]
    cc24:	3707f040 	tbnz	w0, #0, ca2c <fwp_main_thread+0x298>
    cc28:	aa1403e0 	mov	x0, x20
    cc2c:	97ffdab1 	bl	36f0 <fwp_cancel_tree.part.0>
    cc30:	39414680 	ldrb	w0, [x20, #81]
    cc34:	17ffff7f 	b	ca30 <fwp_main_thread+0x29c>
    cc38:	d2800013 	mov	x19, #0x0                   	// #0
    cc3c:	9101c2b4 	add	x20, x21, #0x70
    cc40:	f9419e80 	ldr	x0, [x20, #824]
    cc44:	b5ffea80 	cbnz	x0, c994 <fwp_main_thread+0x200>
    cc48:	f9419280 	ldr	x0, [x20, #800]
    cc4c:	97ffdf89 	bl	4a70 <fwp_mem_free>
    cc50:	f901929f 	str	xzr, [x20, #800]
    cc54:	f9019a9f 	str	xzr, [x20, #816]
    cc58:	f941b280 	ldr	x0, [x20, #864]
    cc5c:	b4000413 	cbz	x19, ccdc <fwp_main_thread+0x548>
    cc60:	f900567f 	str	xzr, [x19, #168]
    cc64:	f9005e7f 	str	xzr, [x19, #184]
    cc68:	b9035a9f 	str	wzr, [x20, #856]
    cc6c:	eb00027f 	cmp	x19, x0
    cc70:	54ffe9e0 	b.eq	c9ac <fwp_main_thread+0x218>  // b.none
    cc74:	f90083f9 	str	x25, [sp, #256]
    cc78:	97ffd716 	bl	28d0 <abort@plt>
    cc7c:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    cc80:	91058000 	add	x0, x0, #0x160
    cc84:	940001df 	bl	d400 <atexit>
    cc88:	a90f63f7 	stp	x23, x24, [sp, #240]
    cc8c:	35000380 	cbnz	w0, ccfc <fwp_main_thread+0x568>
    cc90:	52800020 	mov	w0, #0x1                   	// #1
    cc94:	b9034a60 	str	w0, [x19, #840]
    cc98:	9101c2b3 	add	x19, x21, #0x70
    cc9c:	b9434e60 	ldr	w0, [x19, #844]
    cca0:	35ffdfa0 	cbnz	w0, c894 <fwp_main_thread+0x100>
    cca4:	97fff51f 	bl	a120 <f0>
    cca8:	f901aa60 	str	x0, [x19, #848]
    ccac:	52800021 	mov	w1, #0x1                   	// #1
    ccb0:	b9034e61 	str	w1, [x19, #844]
    ccb4:	17fffef8 	b	c894 <fwp_main_thread+0x100>
    ccb8:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    ccbc:	913e8000 	add	x0, x0, #0xfa0
    ccc0:	940001d0 	bl	d400 <atexit>
    ccc4:	17fffec5 	b	c7d8 <fwp_main_thread+0x44>
    ccc8:	97ffdd0f 	bl	4104 <fwp_heap_init>
    cccc:	17fffec0 	b	c7cc <fwp_main_thread+0x38>
    ccd0:	aa0003e1 	mov	x1, x0
    ccd4:	f9002293 	str	x19, [x20, #64]
    ccd8:	17ffff08 	b	c8f8 <fwp_main_thread+0x164>
    ccdc:	b9035a9f 	str	wzr, [x20, #856]
    cce0:	b4ffef40 	cbz	x0, cac8 <fwp_main_thread+0x334>
    cce4:	17ffffe4 	b	cc74 <fwp_main_thread+0x4e0>
    cce8:	b0000000 	adrp	x0, d000 <__divti3+0x2f0>
    ccec:	912a8000 	add	x0, x0, #0xaa0
    ccf0:	a90f63f7 	stp	x23, x24, [sp, #240]
    ccf4:	f90083f9 	str	x25, [sp, #256]
    ccf8:	97ffdac2 	bl	3800 <fwp_trap>
    ccfc:	f90083f9 	str	x25, [sp, #256]
    cd00:	97ffd90c 	bl	3130 <descent_phase_fail>
    cd04:	f90083f9 	str	x25, [sp, #256]
    cd08:	97ffd6de 	bl	2880 <__stack_chk_fail@plt>
    cd0c:	d503201f 	nop

000000000000cd10 <__divti3>:
    cd10:	d503245f 	bti	c
    cd14:	d2800004 	mov	x4, #0x0                   	// #0
    cd18:	b7f80721 	tbnz	x1, #63, cdfc <__divti3+0xec>
    cd1c:	b6f80083 	tbz	x3, #63, cd2c <__divti3+0x1c>
    cd20:	eb0203e2 	negs	x2, x2
    cd24:	aa2403e4 	mvn	x4, x4
    cd28:	da0303e3 	ngc	x3, x3
    cd2c:	aa0203e6 	mov	x6, x2
    cd30:	aa0003e7 	mov	x7, x0
    cd34:	aa0103e5 	mov	x5, x1
    cd38:	b5000583 	cbnz	x3, cde8 <__divti3+0xd8>
    cd3c:	eb01005f 	cmp	x2, x1
    cd40:	54000e69 	b.ls	cf0c <__divti3+0x1fc>  // b.plast
    cd44:	dac01040 	clz	x0, x2
    cd48:	b40000e0 	cbz	x0, cd64 <__divti3+0x54>
    cd4c:	4b0003e1 	neg	w1, w0
    cd50:	9ac020a5 	lsl	x5, x5, x0
    cd54:	9ac02046 	lsl	x6, x2, x0
    cd58:	9ac124e1 	lsr	x1, x7, x1
    cd5c:	aa050025 	orr	x5, x1, x5
    cd60:	9ac020e7 	lsl	x7, x7, x0
    cd64:	d360fcc8 	lsr	x8, x6, #32
    cd68:	92407cc2 	and	x2, x6, #0xffffffff
    cd6c:	9ac808a3 	udiv	x3, x5, x8
    cd70:	9b089465 	msub	x5, x3, x8, x5
    cd74:	aa0303e0 	mov	x0, x3
    cd78:	9b037c41 	mul	x1, x2, x3
    cd7c:	93c780a5 	extr	x5, x5, x7, #32
    cd80:	eb05003f 	cmp	x1, x5
    cd84:	540000a9 	b.ls	cd98 <__divti3+0x88>  // b.plast
    cd88:	ab0500c5 	adds	x5, x6, x5
    cd8c:	d1000460 	sub	x0, x3, #0x1
    cd90:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    cd94:	540015a8 	b.hi	d048 <__divti3+0x338>  // b.pmore
    cd98:	cb0100a5 	sub	x5, x5, x1
    cd9c:	9ac808a3 	udiv	x3, x5, x8
    cda0:	9b089465 	msub	x5, x3, x8, x5
    cda4:	aa0303e1 	mov	x1, x3
    cda8:	9b037c42 	mul	x2, x2, x3
    cdac:	aa0703e3 	mov	x3, x7
    cdb0:	b3607ca3 	bfi	x3, x5, #32, #32
    cdb4:	eb03005f 	cmp	x2, x3
    cdb8:	540000c9 	b.ls	cdd0 <__divti3+0xc0>  // b.plast
    cdbc:	ab0300c3 	adds	x3, x6, x3
    cdc0:	d1000425 	sub	x5, x1, #0x1
    cdc4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cdc8:	d1000821 	sub	x1, x1, #0x2
    cdcc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    cdd0:	aa008020 	orr	x0, x1, x0, lsl #32
    cdd4:	d2800001 	mov	x1, #0x0                   	// #0
    cdd8:	b4000064 	cbz	x4, cde4 <__divti3+0xd4>
    cddc:	eb0003e0 	negs	x0, x0
    cde0:	da0103e1 	ngc	x1, x1
    cde4:	d65f03c0 	ret
    cde8:	eb01007f 	cmp	x3, x1
    cdec:	54000109 	b.ls	ce0c <__divti3+0xfc>  // b.plast
    cdf0:	d2800001 	mov	x1, #0x0                   	// #0
    cdf4:	d2800000 	mov	x0, #0x0                   	// #0
    cdf8:	17fffff8 	b	cdd8 <__divti3+0xc8>
    cdfc:	eb0003e0 	negs	x0, x0
    ce00:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ce04:	da0103e1 	ngc	x1, x1
    ce08:	17ffffc5 	b	cd1c <__divti3+0xc>
    ce0c:	dac01067 	clz	x7, x3
    ce10:	b40010e7 	cbz	x7, d02c <__divti3+0x31c>
    ce14:	d2800805 	mov	x5, #0x40                  	// #64
    ce18:	cb0700a5 	sub	x5, x5, x7
    ce1c:	9ac72063 	lsl	x3, x3, x7
    ce20:	9ac52448 	lsr	x8, x2, x5
    ce24:	aa030108 	orr	x8, x8, x3
    ce28:	9ac52426 	lsr	x6, x1, x5
    ce2c:	92407d0a 	and	x10, x8, #0xffffffff
    ce30:	d360fd09 	lsr	x9, x8, #32
    ce34:	9ac52403 	lsr	x3, x0, x5
    ce38:	9ac72021 	lsl	x1, x1, x7
    ce3c:	aa010063 	orr	x3, x3, x1
    ce40:	9ac72042 	lsl	x2, x2, x7
    ce44:	9ac908cb 	udiv	x11, x6, x9
    ce48:	9b099965 	msub	x5, x11, x9, x6
    ce4c:	aa0b03e1 	mov	x1, x11
    ce50:	9b0b7d46 	mul	x6, x10, x11
    ce54:	93c380a5 	extr	x5, x5, x3, #32
    ce58:	eb0500df 	cmp	x6, x5
    ce5c:	540000a9 	b.ls	ce70 <__divti3+0x160>  // b.plast
    ce60:	ab050105 	adds	x5, x8, x5
    ce64:	d1000561 	sub	x1, x11, #0x1
    ce68:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ce6c:	54000f48 	b.hi	d054 <__divti3+0x344>  // b.pmore
    ce70:	cb0600a6 	sub	x6, x5, x6
    ce74:	9ac908cb 	udiv	x11, x6, x9
    ce78:	9b099969 	msub	x9, x11, x9, x6
    ce7c:	aa0b03e5 	mov	x5, x11
    ce80:	9b0b7d4a 	mul	x10, x10, x11
    ce84:	b3607d23 	bfi	x3, x9, #32, #32
    ce88:	eb03015f 	cmp	x10, x3
    ce8c:	540000a9 	b.ls	cea0 <__divti3+0x190>  // b.plast
    ce90:	ab030103 	adds	x3, x8, x3
    ce94:	d1000565 	sub	x5, x11, #0x1
    ce98:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ce9c:	54000e28 	b.hi	d060 <__divti3+0x350>  // b.pmore
    cea0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cea4:	92407c48 	and	x8, x2, #0xffffffff
    cea8:	2a0503e5 	mov	w5, w5
    ceac:	d360fc42 	lsr	x2, x2, #32
    ceb0:	d360fc26 	lsr	x6, x1, #32
    ceb4:	cb0a0063 	sub	x3, x3, x10
    ceb8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cebc:	9b087caa 	mul	x10, x5, x8
    cec0:	9b087cc8 	mul	x8, x6, x8
    cec4:	9b0220a5 	madd	x5, x5, x2, x8
    cec8:	9b027cc6 	mul	x6, x6, x2
    cecc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    ced0:	8b0900c5 	add	x5, x6, x9
    ced4:	eb02011f 	cmp	x8, x2
    ced8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cedc:	8b4280c6 	add	x6, x6, x2, lsr #32
    cee0:	eb06007f 	cmp	x3, x6
    cee4:	540000e3 	b.cc	cf00 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cee8:	92407d4a 	and	x10, x10, #0xffffffff
    ceec:	9ac72000 	lsl	x0, x0, x7
    cef0:	8b028142 	add	x2, x10, x2, lsl #32
    cef4:	eb02001f 	cmp	x0, x2
    cef8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cefc:	54000a01 	b.ne	d03c <__divti3+0x32c>  // b.any
    cf00:	d1000420 	sub	x0, x1, #0x1
    cf04:	d2800001 	mov	x1, #0x0                   	// #0
    cf08:	17ffffb4 	b	cdd8 <__divti3+0xc8>
    cf0c:	b5000062 	cbnz	x2, cf18 <__divti3+0x208>
    cf10:	d2800022 	mov	x2, #0x1                   	// #1
    cf14:	9ac30846 	udiv	x6, x2, x3
    cf18:	dac010c8 	clz	x8, x6
    cf1c:	b5000408 	cbnz	x8, cf9c <__divti3+0x28c>
    cf20:	d360fcc9 	lsr	x9, x6, #32
    cf24:	92407cc5 	and	x5, x6, #0xffffffff
    cf28:	cb060023 	sub	x3, x1, x6
    cf2c:	d2800021 	mov	x1, #0x1                   	// #1
    cf30:	9ac90868 	udiv	x8, x3, x9
    cf34:	9b098d03 	msub	x3, x8, x9, x3
    cf38:	aa0803e0 	mov	x0, x8
    cf3c:	9b057d02 	mul	x2, x8, x5
    cf40:	93c78063 	extr	x3, x3, x7, #32
    cf44:	eb03005f 	cmp	x2, x3
    cf48:	540000a9 	b.ls	cf5c <__divti3+0x24c>  // b.plast
    cf4c:	ab0300c3 	adds	x3, x6, x3
    cf50:	d1000500 	sub	x0, x8, #0x1
    cf54:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cf58:	54000968 	b.hi	d084 <__divti3+0x374>  // b.pmore
    cf5c:	cb020063 	sub	x3, x3, x2
    cf60:	9ac90862 	udiv	x2, x3, x9
    cf64:	aa0203e8 	mov	x8, x2
    cf68:	9b098c42 	msub	x2, x2, x9, x3
    cf6c:	aa0703e3 	mov	x3, x7
    cf70:	9b057d05 	mul	x5, x8, x5
    cf74:	b3607c43 	bfi	x3, x2, #32, #32
    cf78:	eb0300bf 	cmp	x5, x3
    cf7c:	540000c9 	b.ls	cf94 <__divti3+0x284>  // b.plast
    cf80:	ab0300c2 	adds	x2, x6, x3
    cf84:	d1000503 	sub	x3, x8, #0x1
    cf88:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cf8c:	d1000908 	sub	x8, x8, #0x2
    cf90:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cf94:	aa008100 	orr	x0, x8, x0, lsl #32
    cf98:	17ffff90 	b	cdd8 <__divti3+0xc8>
    cf9c:	9ac820c6 	lsl	x6, x6, x8
    cfa0:	d2800803 	mov	x3, #0x40                  	// #64
    cfa4:	cb080063 	sub	x3, x3, x8
    cfa8:	d360fcc9 	lsr	x9, x6, #32
    cfac:	9ac82027 	lsl	x7, x1, x8
    cfb0:	92407cc5 	and	x5, x6, #0xffffffff
    cfb4:	9ac32422 	lsr	x2, x1, x3
    cfb8:	9ac32403 	lsr	x3, x0, x3
    cfbc:	aa070063 	orr	x3, x3, x7
    cfc0:	9ac9084a 	udiv	x10, x2, x9
    cfc4:	9ac82007 	lsl	x7, x0, x8
    cfc8:	9b098940 	msub	x0, x10, x9, x2
    cfcc:	aa0a03e1 	mov	x1, x10
    cfd0:	9b0a7ca2 	mul	x2, x5, x10
    cfd4:	93c38000 	extr	x0, x0, x3, #32
    cfd8:	eb00005f 	cmp	x2, x0
    cfdc:	540000a9 	b.ls	cff0 <__divti3+0x2e0>  // b.plast
    cfe0:	ab0000c0 	adds	x0, x6, x0
    cfe4:	d1000541 	sub	x1, x10, #0x1
    cfe8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cfec:	54000468 	b.hi	d078 <__divti3+0x368>  // b.pmore
    cff0:	cb020000 	sub	x0, x0, x2
    cff4:	9ac9080a 	udiv	x10, x0, x9
    cff8:	9b098140 	msub	x0, x10, x9, x0
    cffc:	aa0a03e2 	mov	x2, x10
    d000:	9b0a7ca8 	mul	x8, x5, x10
    d004:	b3607c03 	bfi	x3, x0, #32, #32
    d008:	eb03011f 	cmp	x8, x3
    d00c:	540000a9 	b.ls	d020 <__divti3+0x310>  // b.plast
    d010:	ab0300c3 	adds	x3, x6, x3
    d014:	d1000542 	sub	x2, x10, #0x1
    d018:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d01c:	54000288 	b.hi	d06c <__divti3+0x35c>  // b.pmore
    d020:	cb080063 	sub	x3, x3, x8
    d024:	aa018041 	orr	x1, x2, x1, lsl #32
    d028:	17ffffc2 	b	cf30 <__divti3+0x220>
    d02c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d030:	d2800001 	mov	x1, #0x0                   	// #0
    d034:	9a9f87e0 	cset	x0, ls	// ls = plast
    d038:	17ffff68 	b	cdd8 <__divti3+0xc8>
    d03c:	aa0103e0 	mov	x0, x1
    d040:	d2800001 	mov	x1, #0x0                   	// #0
    d044:	17ffff65 	b	cdd8 <__divti3+0xc8>
    d048:	d1000860 	sub	x0, x3, #0x2
    d04c:	8b0600a5 	add	x5, x5, x6
    d050:	17ffff52 	b	cd98 <__divti3+0x88>
    d054:	d1000961 	sub	x1, x11, #0x2
    d058:	8b0800a5 	add	x5, x5, x8
    d05c:	17ffff85 	b	ce70 <__divti3+0x160>
    d060:	d1000965 	sub	x5, x11, #0x2
    d064:	8b080063 	add	x3, x3, x8
    d068:	17ffff8e 	b	cea0 <__divti3+0x190>
    d06c:	d1000942 	sub	x2, x10, #0x2
    d070:	8b060063 	add	x3, x3, x6
    d074:	17ffffeb 	b	d020 <__divti3+0x310>
    d078:	d1000941 	sub	x1, x10, #0x2
    d07c:	8b060000 	add	x0, x0, x6
    d080:	17ffffdc 	b	cff0 <__divti3+0x2e0>
    d084:	d1000900 	sub	x0, x8, #0x2
    d088:	8b060063 	add	x3, x3, x6
    d08c:	17ffffb4 	b	cf5c <__divti3+0x24c>

000000000000d090 <__modti3>:
    d090:	d503245f 	bti	c
    d094:	d2800004 	mov	x4, #0x0                   	// #0
    d098:	b6f80081 	tbz	x1, #63, d0a8 <__modti3+0x18>
    d09c:	eb0003e0 	negs	x0, x0
    d0a0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d0a4:	da0103e1 	ngc	x1, x1
    d0a8:	f100007f 	cmp	x3, #0x0
    d0ac:	5400128b 	b.lt	d2fc <__modti3+0x26c>  // b.tstop
    d0b0:	aa0003e7 	mov	x7, x0
    d0b4:	aa0103e6 	mov	x6, x1
    d0b8:	540004e1 	b.ne	d154 <__modti3+0xc4>  // b.any
    d0bc:	eb02003f 	cmp	x1, x2
    d0c0:	54000dc2 	b.cs	d278 <__modti3+0x1e8>  // b.hs, b.nlast
    d0c4:	dac01043 	clz	x3, x2
    d0c8:	aa0303e5 	mov	x5, x3
    d0cc:	b40000e3 	cbz	x3, d0e8 <__modti3+0x58>
    d0d0:	4b0303e6 	neg	w6, w3
    d0d4:	9ac32021 	lsl	x1, x1, x3
    d0d8:	9ac32042 	lsl	x2, x2, x3
    d0dc:	9ac62406 	lsr	x6, x0, x6
    d0e0:	aa0100c6 	orr	x6, x6, x1
    d0e4:	9ac32007 	lsl	x7, x0, x3
    d0e8:	d360fc40 	lsr	x0, x2, #32
    d0ec:	92407c43 	and	x3, x2, #0xffffffff
    d0f0:	9ac008c1 	udiv	x1, x6, x0
    d0f4:	9b009826 	msub	x6, x1, x0, x6
    d0f8:	9b017c61 	mul	x1, x3, x1
    d0fc:	93c780c6 	extr	x6, x6, x7, #32
    d100:	eb06003f 	cmp	x1, x6
    d104:	540000a9 	b.ls	d118 <__modti3+0x88>  // b.plast
    d108:	ab060046 	adds	x6, x2, x6
    d10c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d110:	8b0200c8 	add	x8, x6, x2
    d114:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d118:	cb0100c6 	sub	x6, x6, x1
    d11c:	9ac008c8 	udiv	x8, x6, x0
    d120:	9b009901 	msub	x1, x8, x0, x6
    d124:	aa0703e0 	mov	x0, x7
    d128:	9b087c63 	mul	x3, x3, x8
    d12c:	b3607c20 	bfi	x0, x1, #32, #32
    d130:	eb00007f 	cmp	x3, x0
    d134:	54001088 	b.hi	d344 <__modti3+0x2b4>  // b.pmore
    d138:	cb030000 	sub	x0, x0, x3
    d13c:	9ac52400 	lsr	x0, x0, x5
    d140:	d2800001 	mov	x1, #0x0                   	// #0
    d144:	b4000064 	cbz	x4, d150 <__modti3+0xc0>
    d148:	eb0003e0 	negs	x0, x0
    d14c:	da0103e1 	ngc	x1, x1
    d150:	d65f03c0 	ret
    d154:	dac01066 	clz	x6, x3
    d158:	eb03003f 	cmp	x1, x3
    d15c:	54ffff43 	b.cc	d144 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d160:	93407cc5 	sxtw	x5, w6
    d164:	d2800808 	mov	x8, #0x40                  	// #64
    d168:	cb050108 	sub	x8, x8, x5
    d16c:	9ac62063 	lsl	x3, x3, x6
    d170:	9ac62025 	lsl	x5, x1, x6
    d174:	9ac82447 	lsr	x7, x2, x8
    d178:	aa0300e7 	orr	x7, x7, x3
    d17c:	9ac82423 	lsr	x3, x1, x8
    d180:	92407cec 	and	x12, x7, #0xffffffff
    d184:	d360fcea 	lsr	x10, x7, #32
    d188:	9ac82401 	lsr	x1, x0, x8
    d18c:	aa050021 	orr	x1, x1, x5
    d190:	9ac62042 	lsl	x2, x2, x6
    d194:	9ac62000 	lsl	x0, x0, x6
    d198:	9aca086b 	udiv	x11, x3, x10
    d19c:	9b0a8d63 	msub	x3, x11, x10, x3
    d1a0:	aa0b03e5 	mov	x5, x11
    d1a4:	9b0b7d89 	mul	x9, x12, x11
    d1a8:	93c18063 	extr	x3, x3, x1, #32
    d1ac:	eb03013f 	cmp	x9, x3
    d1b0:	540000a9 	b.ls	d1c4 <__modti3+0x134>  // b.plast
    d1b4:	ab0300e3 	adds	x3, x7, x3
    d1b8:	d1000565 	sub	x5, x11, #0x1
    d1bc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d1c0:	54001168 	b.hi	d3ec <__modti3+0x35c>  // b.pmore
    d1c4:	cb090063 	sub	x3, x3, x9
    d1c8:	9aca086b 	udiv	x11, x3, x10
    d1cc:	9b0a8d6a 	msub	x10, x11, x10, x3
    d1d0:	aa0b03e9 	mov	x9, x11
    d1d4:	9b0b7d8c 	mul	x12, x12, x11
    d1d8:	b3607d41 	bfi	x1, x10, #32, #32
    d1dc:	eb01019f 	cmp	x12, x1
    d1e0:	540000a9 	b.ls	d1f4 <__modti3+0x164>  // b.plast
    d1e4:	ab0100e1 	adds	x1, x7, x1
    d1e8:	d1000569 	sub	x9, x11, #0x1
    d1ec:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d1f0:	54000f88 	b.hi	d3e0 <__modti3+0x350>  // b.pmore
    d1f4:	aa058123 	orr	x3, x9, x5, lsl #32
    d1f8:	92407c4b 	and	x11, x2, #0xffffffff
    d1fc:	2a0903e9 	mov	w9, w9
    d200:	d360fc4a 	lsr	x10, x2, #32
    d204:	d360fc63 	lsr	x3, x3, #32
    d208:	cb0c0021 	sub	x1, x1, x12
    d20c:	aa0a03ec 	mov	x12, x10
    d210:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d214:	9b0b7d25 	mul	x5, x9, x11
    d218:	9b0b7c6b 	mul	x11, x3, x11
    d21c:	9b0a2d29 	madd	x9, x9, x10, x11
    d220:	92407caa 	and	x10, x5, #0xffffffff
    d224:	9b0c7c63 	mul	x3, x3, x12
    d228:	8b458125 	add	x5, x9, x5, lsr #32
    d22c:	8b0d0069 	add	x9, x3, x13
    d230:	eb05017f 	cmp	x11, x5
    d234:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d238:	8b058149 	add	x9, x10, x5, lsl #32
    d23c:	8b458063 	add	x3, x3, x5, lsr #32
    d240:	eb03003f 	cmp	x1, x3
    d244:	54000063 	b.cc	d250 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d248:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d24c:	54000082 	b.cs	d25c <__modti3+0x1cc>  // b.hs, b.nlast
    d250:	eb020129 	subs	x9, x9, x2
    d254:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d258:	cb070063 	sub	x3, x3, x7
    d25c:	eb090000 	subs	x0, x0, x9
    d260:	da030021 	sbc	x1, x1, x3
    d264:	9ac62400 	lsr	x0, x0, x6
    d268:	9ac82028 	lsl	x8, x1, x8
    d26c:	aa000100 	orr	x0, x8, x0
    d270:	9ac62421 	lsr	x1, x1, x6
    d274:	17ffffb4 	b	d144 <__modti3+0xb4>
    d278:	b5000062 	cbnz	x2, d284 <__modti3+0x1f4>
    d27c:	d2800023 	mov	x3, #0x1                   	// #1
    d280:	9ac20862 	udiv	x2, x3, x2
    d284:	dac01048 	clz	x8, x2
    d288:	aa0803e5 	mov	x5, x8
    d28c:	b5000668 	cbnz	x8, d358 <__modti3+0x2c8>
    d290:	cb020020 	sub	x0, x1, x2
    d294:	d360fc49 	lsr	x9, x2, #32
    d298:	92407c4a 	and	x10, x2, #0xffffffff
    d29c:	9ac90801 	udiv	x1, x0, x9
    d2a0:	9b098020 	msub	x0, x1, x9, x0
    d2a4:	9b0a7c21 	mul	x1, x1, x10
    d2a8:	93c78000 	extr	x0, x0, x7, #32
    d2ac:	eb00003f 	cmp	x1, x0
    d2b0:	540000a9 	b.ls	d2c4 <__modti3+0x234>  // b.plast
    d2b4:	ab000040 	adds	x0, x2, x0
    d2b8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d2bc:	8b020003 	add	x3, x0, x2
    d2c0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d2c4:	cb010001 	sub	x1, x0, x1
    d2c8:	9ac90820 	udiv	x0, x1, x9
    d2cc:	9b098403 	msub	x3, x0, x9, x1
    d2d0:	aa0703e1 	mov	x1, x7
    d2d4:	9b0a7c00 	mul	x0, x0, x10
    d2d8:	b3607c61 	bfi	x1, x3, #32, #32
    d2dc:	eb01001f 	cmp	x0, x1
    d2e0:	540000a9 	b.ls	d2f4 <__modti3+0x264>  // b.plast
    d2e4:	ab010041 	adds	x1, x2, x1
    d2e8:	8b020022 	add	x2, x1, x2
    d2ec:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d2f0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d2f4:	cb000020 	sub	x0, x1, x0
    d2f8:	17ffff91 	b	d13c <__modti3+0xac>
    d2fc:	eb0203e5 	negs	x5, x2
    d300:	aa0003e7 	mov	x7, x0
    d304:	da0303e8 	ngc	x8, x3
    d308:	aa0503e2 	mov	x2, x5
    d30c:	aa0803e3 	mov	x3, x8
    d310:	aa0103e6 	mov	x6, x1
    d314:	b4ffed48 	cbz	x8, d0bc <__modti3+0x2c>
    d318:	eb01011f 	cmp	x8, x1
    d31c:	54fff148 	b.hi	d144 <__modti3+0xb4>  // b.pmore
    d320:	dac01109 	clz	x9, x8
    d324:	2a0903e6 	mov	w6, w9
    d328:	b5fff1c9 	cbnz	x9, d160 <__modti3+0xd0>
    d32c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d330:	54000068 	b.hi	d33c <__modti3+0x2ac>  // b.pmore
    d334:	eb050007 	subs	x7, x0, x5
    d338:	da080021 	sbc	x1, x1, x8
    d33c:	aa0703e0 	mov	x0, x7
    d340:	17ffff81 	b	d144 <__modti3+0xb4>
    d344:	ab000040 	adds	x0, x2, x0
    d348:	8b020002 	add	x2, x0, x2
    d34c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d350:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d354:	17ffff79 	b	d138 <__modti3+0xa8>
    d358:	9ac82042 	lsl	x2, x2, x8
    d35c:	d2800803 	mov	x3, #0x40                  	// #64
    d360:	cb080063 	sub	x3, x3, x8
    d364:	d360fc49 	lsr	x9, x2, #32
    d368:	9ac82027 	lsl	x7, x1, x8
    d36c:	92407c4a 	and	x10, x2, #0xffffffff
    d370:	9ac32426 	lsr	x6, x1, x3
    d374:	9ac32403 	lsr	x3, x0, x3
    d378:	aa070063 	orr	x3, x3, x7
    d37c:	9ac908c1 	udiv	x1, x6, x9
    d380:	9ac82007 	lsl	x7, x0, x8
    d384:	9b099820 	msub	x0, x1, x9, x6
    d388:	9b017d41 	mul	x1, x10, x1
    d38c:	93c38000 	extr	x0, x0, x3, #32
    d390:	eb00003f 	cmp	x1, x0
    d394:	540000a9 	b.ls	d3a8 <__modti3+0x318>  // b.plast
    d398:	ab000040 	adds	x0, x2, x0
    d39c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d3a0:	8b020006 	add	x6, x0, x2
    d3a4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d3a8:	cb010000 	sub	x0, x0, x1
    d3ac:	9ac90801 	udiv	x1, x0, x9
    d3b0:	9b098026 	msub	x6, x1, x9, x0
    d3b4:	aa0303e0 	mov	x0, x3
    d3b8:	9b017d41 	mul	x1, x10, x1
    d3bc:	b3607cc0 	bfi	x0, x6, #32, #32
    d3c0:	eb00003f 	cmp	x1, x0
    d3c4:	540000a9 	b.ls	d3d8 <__modti3+0x348>  // b.plast
    d3c8:	ab000040 	adds	x0, x2, x0
    d3cc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d3d0:	8b020003 	add	x3, x0, x2
    d3d4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d3d8:	cb010000 	sub	x0, x0, x1
    d3dc:	17ffffb0 	b	d29c <__modti3+0x20c>
    d3e0:	d1000969 	sub	x9, x11, #0x2
    d3e4:	8b070021 	add	x1, x1, x7
    d3e8:	17ffff83 	b	d1f4 <__modti3+0x164>
    d3ec:	d1000965 	sub	x5, x11, #0x2
    d3f0:	8b070063 	add	x3, x3, x7
    d3f4:	17ffff74 	b	d1c4 <__modti3+0x134>
    d3f8:	d503201f 	nop
    d3fc:	d503201f 	nop

000000000000d400 <atexit>:
    d400:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d404:	f0000082 	adrp	x2, 20000 <__data_start>
    d408:	d2800001 	mov	x1, #0x0                   	// #0
    d40c:	910003fd 	mov	x29, sp
    d410:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d414:	f9400442 	ldr	x2, [x2, #8]
    d418:	17ffd4da 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d41c <_fini>:
    d41c:	d503201f 	nop
    d420:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d424:	910003fd 	mov	x29, sp
    d428:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d42c:	d65f03c0 	ret
