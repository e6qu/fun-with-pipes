
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <__modti3+0x320>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	910a00a5 	add	x5, x5, #0x280
    2a20:	f0000044 	adrp	x4, d000 <__modti3+0x320>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	910a2084 	add	x4, x4, #0x288
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940002ac 	bl	3500 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91010261 	add	x1, x19, #0x40
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xeea0>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9001c20 	str	x0, [x1, #56]
    2aac:	940002f5 	bl	3680 <fwp_now_ns>
    2ab0:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2ab4:	91198000 	add	x0, x0, #0x660
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x2230>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91108042 	add	x2, x2, #0x420
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91010273 	add	x19, x19, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430a60 	ldr	w0, [x19, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff44 	bl	28e0 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2bfc:	9119c000 	add	x0, x0, #0x670
    2c00:	94000240 	bl	3500 <fwp_trap>
    2c04:	97fffefb 	bl	27f0 <__stack_chk_fail@plt>
    2c08:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2c0c:	911c4000 	add	x0, x0, #0x710
    2c10:	9400023c 	bl	3500 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffee2 	bl	27a0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2c24:	911ba000 	add	x0, x0, #0x6e8
    2c28:	94000236 	bl	3500 <fwp_trap>
    2c2c:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2c30:	911ae000 	add	x0, x0, #0x6b8
    2c34:	94000233 	bl	3500 <fwp_trap>
    2c38:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2c3c:	911a4000 	add	x0, x0, #0x690
    2c40:	94000230 	bl	3500 <fwp_trap>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	f0000041 	adrp	x1, d000 <__modti3+0x320>
    2e34:	91344021 	add	x1, x1, #0xd10
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2fd0:	91022000 	add	x0, x0, #0x88
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    3098:	9133c021 	add	x1, x1, #0xcf0
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    30c4:	911542a1 	add	x1, x21, #0x550
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    30d8:	912500a5 	add	x5, x5, #0x940
    30dc:	911542a1 	add	x1, x21, #0x550
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911542b7 	add	x23, x21, #0x550
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911542b5 	add	x21, x21, #0x550
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911542b5 	add	x21, x21, #0x550
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    3268:	9124e0a5 	add	x5, x5, #0x938
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3370:	91022000 	add	x0, x0, #0x88
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	91028021 	add	x1, x1, #0xa0
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	9102a021 	add	x1, x1, #0xa8
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    34e0:	9102c021 	add	x1, x1, #0xb0
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_trap>:
    3500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3504:	d53bd041 	mrs	x1, tpidr_el0
    3508:	91400021 	add	x1, x1, #0x0, lsl #12
    350c:	91004021 	add	x1, x1, #0x10
    3510:	910003fd 	mov	x29, sp
    3514:	a90153f3 	stp	x19, x20, [sp, #16]
    3518:	aa0003f3 	mov	x19, x0
    351c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3520:	f947ea94 	ldr	x20, [x20, #4048]
    3524:	f90013f5 	str	x21, [sp, #32]
    3528:	f9400035 	ldr	x21, [x1]
    352c:	97fffe91 	bl	2f70 <fwp_flush>
    3530:	f9400280 	ldr	x0, [x20]
    3534:	d0000042 	adrp	x2, d000 <__modti3+0x320>
    3538:	aa1303e3 	mov	x3, x19
    353c:	9102e042 	add	x2, x2, #0xb8
    3540:	52800041 	mov	w1, #0x2                   	// #2
    3544:	97fffcc7 	bl	2860 <__fprintf_chk@plt>
    3548:	b40000b5 	cbz	x21, 355c <fwp_trap+0x5c>
    354c:	f9400280 	ldr	x0, [x20]
    3550:	97fffcf4 	bl	2920 <fflush@plt>
    3554:	52800ca0 	mov	w0, #0x65                  	// #101
    3558:	97fffd02 	bl	2960 <_Exit@plt>
    355c:	52800ca0 	mov	w0, #0x65                  	// #101
    3560:	97fffc50 	bl	26a0 <exit@plt>

0000000000003564 <fwp_closure_drop_push>:
    3564:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3568:	910003fd 	mov	x29, sp
    356c:	a90153f3 	stp	x19, x20, [sp, #16]
    3570:	aa0003f3 	mov	x19, x0
    3574:	a9408014 	ldp	x20, x0, [x0, #8]
    3578:	a9025bf5 	stp	x21, x22, [sp, #32]
    357c:	aa0103f5 	mov	x21, x1
    3580:	a90363f7 	stp	x23, x24, [sp, #48]
    3584:	eb00029f 	cmp	x20, x0
    3588:	54000160 	b.eq	35b4 <fwp_closure_drop_push+0x50>  // b.none
    358c:	f9400276 	ldr	x22, [x19]
    3590:	d37df297 	lsl	x23, x20, #3
    3594:	91000694 	add	x20, x20, #0x1
    3598:	f9000674 	str	x20, [x19, #8]
    359c:	a94153f3 	ldp	x19, x20, [sp, #16]
    35a0:	f8376ad5 	str	x21, [x22, x23]
    35a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    35ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    35b0:	d65f03c0 	ret
    35b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    35b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    35bc:	eb00029f 	cmp	x20, x0
    35c0:	54000568 	b.hi	366c <fwp_closure_drop_push+0x108>  // b.pmore
    35c4:	d37cee99 	lsl	x25, x20, #4
    35c8:	d37ffa9a 	lsl	x26, x20, #1
    35cc:	aa1903e0 	mov	x0, x25
    35d0:	97fffc70 	bl	2790 <malloc@plt>
    35d4:	aa0003f6 	mov	x22, x0
    35d8:	b4000320 	cbz	x0, 363c <fwp_closure_drop_push+0xd8>
    35dc:	aa1303f8 	mov	x24, x19
    35e0:	aa1903e3 	mov	x3, x25
    35e4:	d37df297 	lsl	x23, x20, #3
    35e8:	aa1703e2 	mov	x2, x23
    35ec:	f8418719 	ldr	x25, [x24], #24
    35f0:	aa1903e1 	mov	x1, x25
    35f4:	97fffc53 	bl	2740 <__memcpy_chk@plt>
    35f8:	eb18033f 	cmp	x25, x24
    35fc:	540000a0 	b.eq	3610 <fwp_closure_drop_push+0xac>  // b.none
    3600:	aa1903e0 	mov	x0, x25
    3604:	97fffcab 	bl	28b0 <free@plt>
    3608:	f9400674 	ldr	x20, [x19, #8]
    360c:	d37df297 	lsl	x23, x20, #3
    3610:	91000694 	add	x20, x20, #0x1
    3614:	f9000276 	str	x22, [x19]
    3618:	f9000a7a 	str	x26, [x19, #16]
    361c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3620:	f9000674 	str	x20, [x19, #8]
    3624:	f8376ad5 	str	x21, [x22, x23]
    3628:	a94153f3 	ldp	x19, x20, [sp, #16]
    362c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3630:	a94363f7 	ldp	x23, x24, [sp, #48]
    3634:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3638:	d65f03c0 	ret
    363c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3640:	f947e863 	ldr	x3, [x3, #4048]
    3644:	d2800262 	mov	x2, #0x13                  	// #19
    3648:	d2800021 	mov	x1, #0x1                   	// #1
    364c:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3650:	91022000 	add	x0, x0, #0x88
    3654:	f9400063 	ldr	x3, [x3]
    3658:	97fffca6 	bl	28f0 <fwrite@plt>
    365c:	d2800000 	mov	x0, #0x0                   	// #0
    3660:	97fffcb0 	bl	2920 <fflush@plt>
    3664:	52800cc0 	mov	w0, #0x66                  	// #102
    3668:	97fffcbe 	bl	2960 <_Exit@plt>
    366c:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3670:	91032000 	add	x0, x0, #0xc8
    3674:	97ffffa3 	bl	3500 <fwp_trap>
    3678:	d503201f 	nop
    367c:	d503201f 	nop

0000000000003680 <fwp_now_ns>:
    3680:	d100c3ff 	sub	sp, sp, #0x30
    3684:	52800020 	mov	w0, #0x1                   	// #1
    3688:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    368c:	f947f442 	ldr	x2, [x2, #4072]
    3690:	910023e1 	add	x1, sp, #0x8
    3694:	a9027bfd 	stp	x29, x30, [sp, #32]
    3698:	910083fd 	add	x29, sp, #0x20
    369c:	f9400043 	ldr	x3, [x2]
    36a0:	f9000fe3 	str	x3, [sp, #24]
    36a4:	d2800003 	mov	x3, #0x0                   	// #0
    36a8:	97fffc1e 	bl	2720 <clock_gettime@plt>
    36ac:	350002c0 	cbnz	w0, 3704 <fwp_now_ns+0x84>
    36b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    36b4:	d2994003 	mov	x3, #0xca00                	// #51712
    36b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    36bc:	9b037c20 	mul	x0, x1, x3
    36c0:	9b437c21 	smulh	x1, x1, x3
    36c4:	ab020000 	adds	x0, x0, x2
    36c8:	937ffc42 	asr	x2, x2, #63
    36cc:	9a020021 	adc	x1, x1, x2
    36d0:	f100001f 	cmp	x0, #0x0
    36d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    36d8:	b50001e1 	cbnz	x1, 3714 <fwp_now_ns+0x94>
    36dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    36e0:	f947f421 	ldr	x1, [x1, #4072]
    36e4:	f9400fe3 	ldr	x3, [sp, #24]
    36e8:	f9400022 	ldr	x2, [x1]
    36ec:	eb020063 	subs	x3, x3, x2
    36f0:	d2800002 	mov	x2, #0x0                   	// #0
    36f4:	540000e1 	b.ne	3710 <fwp_now_ns+0x90>  // b.any
    36f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36fc:	9100c3ff 	add	sp, sp, #0x30
    3700:	d65f03c0 	ret
    3704:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3708:	9103a000 	add	x0, x0, #0xe8
    370c:	97ffff7d 	bl	3500 <fwp_trap>
    3710:	97fffc38 	bl	27f0 <__stack_chk_fail@plt>
    3714:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3718:	91042000 	add	x0, x0, #0x108
    371c:	97ffff79 	bl	3500 <fwp_trap>

0000000000003720 <fwp_closure_drop.part.0>:
    3720:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3724:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    3728:	910003fd 	mov	x29, sp
    372c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3730:	f947f463 	ldr	x3, [x3, #4072]
    3734:	a90153f3 	stp	x19, x20, [sp, #16]
    3738:	d10883ff 	sub	sp, sp, #0x220
    373c:	910003e2 	mov	x2, sp
    3740:	d53bd053 	mrs	x19, tpidr_el0
    3744:	910063f4 	add	x20, sp, #0x18
    3748:	3dc34820 	ldr	q0, [x1, #3360]
    374c:	91400264 	add	x4, x19, #0x0, lsl #12
    3750:	91004084 	add	x4, x4, #0x10
    3754:	aa0003e1 	mov	x1, x0
    3758:	aa0203e0 	mov	x0, x2
    375c:	f9400062 	ldr	x2, [x3]
    3760:	f9010fe2 	str	x2, [sp, #536]
    3764:	d2800002 	mov	x2, #0x0                   	// #0
    3768:	f90003f4 	str	x20, [sp]
    376c:	f9000080 	str	x0, [x4]
    3770:	3c8083e0 	stur	q0, [sp, #8]
    3774:	97ffff7c 	bl	3564 <fwp_closure_drop_push>
    3778:	f94007e0 	ldr	x0, [sp, #8]
    377c:	b4000280 	cbz	x0, 37cc <fwp_closure_drop.part.0+0xac>
    3780:	f90123f5 	str	x21, [sp, #576]
    3784:	b00000f5 	adrp	x21, 20000 <__data_start>
    3788:	910102b5 	add	x21, x21, #0x40
    378c:	d503201f 	nop
    3790:	f94003e1 	ldr	x1, [sp]
    3794:	d1000400 	sub	x0, x0, #0x1
    3798:	f90007e0 	str	x0, [sp, #8]
    379c:	f9401ea2 	ldr	x2, [x21, #56]
    37a0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    37a4:	b9400001 	ldr	w1, [x0]
    37a8:	8b011441 	add	x1, x2, x1, lsl #5
    37ac:	f9400c21 	ldr	x1, [x1, #24]
    37b0:	b4000321 	cbz	x1, 3814 <fwp_closure_drop.part.0+0xf4>
    37b4:	f9400422 	ldr	x2, [x1, #8]
    37b8:	52800001 	mov	w1, #0x0                   	// #0
    37bc:	d63f0040 	blr	x2
    37c0:	f94007e0 	ldr	x0, [sp, #8]
    37c4:	b5fffe60 	cbnz	x0, 3790 <fwp_closure_drop.part.0+0x70>
    37c8:	f94123f5 	ldr	x21, [sp, #576]
    37cc:	91400273 	add	x19, x19, #0x0, lsl #12
    37d0:	91004273 	add	x19, x19, #0x10
    37d4:	f94003e0 	ldr	x0, [sp]
    37d8:	f900027f 	str	xzr, [x19]
    37dc:	eb14001f 	cmp	x0, x20
    37e0:	54000040 	b.eq	37e8 <fwp_closure_drop.part.0+0xc8>  // b.none
    37e4:	97fffc33 	bl	28b0 <free@plt>
    37e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    37ec:	f947f400 	ldr	x0, [x0, #4072]
    37f0:	f9410fe2 	ldr	x2, [sp, #536]
    37f4:	f9400001 	ldr	x1, [x0]
    37f8:	eb010042 	subs	x2, x2, x1
    37fc:	d2800001 	mov	x1, #0x0                   	// #0
    3800:	54000101 	b.ne	3820 <fwp_closure_drop.part.0+0x100>  // b.any
    3804:	910883ff 	add	sp, sp, #0x220
    3808:	a94153f3 	ldp	x19, x20, [sp, #16]
    380c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3810:	d65f03c0 	ret
    3814:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3818:	9104c000 	add	x0, x0, #0x130
    381c:	97ffff39 	bl	3500 <fwp_trap>
    3820:	f90123f5 	str	x21, [sp, #576]
    3824:	97fffbf3 	bl	27f0 <__stack_chk_fail@plt>
    3828:	d503201f 	nop
    382c:	d503201f 	nop

0000000000003830 <fwp_tape_of>:
    3830:	92403c02 	and	x2, x0, #0xffff
    3834:	b4000262 	cbz	x2, 3880 <fwp_tape_of+0x50>
    3838:	9350fc01 	asr	x1, x0, #16
    383c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3840:	d1000440 	sub	x0, x2, #0x1
    3844:	91010062 	add	x2, x3, #0x40
    3848:	f9402042 	ldr	x2, [x2, #64]
    384c:	eb00005f 	cmp	x2, x0
    3850:	5400018d 	b.le	3880 <fwp_tape_of+0x50>
    3854:	8b000402 	add	x2, x0, x0, lsl #1
    3858:	f9402063 	ldr	x3, [x3, #64]
    385c:	8b020802 	add	x2, x0, x2, lsl #2
    3860:	d37df042 	lsl	x2, x2, #3
    3864:	8b020060 	add	x0, x3, x2
    3868:	b9400404 	ldr	w4, [x0, #4]
    386c:	340000a4 	cbz	w4, 3880 <fwp_tape_of+0x50>
    3870:	b8626862 	ldr	w2, [x3, x2]
    3874:	6b01005f 	cmp	w2, w1
    3878:	54000041 	b.ne	3880 <fwp_tape_of+0x50>  // b.any
    387c:	d65f03c0 	ret
    3880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3884:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3888:	91058000 	add	x0, x0, #0x160
    388c:	910003fd 	mov	x29, sp
    3890:	97ffff1c 	bl	3500 <fwp_trap>

0000000000003894 <fwp_format_g.constprop.0>:
    3894:	d10483ff 	sub	sp, sp, #0x120
    3898:	d0000044 	adrp	x4, d000 <__modti3+0x320>
    389c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    38a0:	f947f442 	ldr	x2, [x2, #4072]
    38a4:	9106c084 	add	x4, x4, #0x1b0
    38a8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    38ac:	9102c3fd 	add	x29, sp, #0xb0
    38b0:	d2800803 	mov	x3, #0x40                  	// #64
    38b4:	a90e63f7 	stp	x23, x24, [sp, #224]
    38b8:	93407c38 	sxtw	x24, w1
    38bc:	aa0303e1 	mov	x1, x3
    38c0:	fd008be8 	str	d8, [sp, #272]
    38c4:	1e604008 	fmov	d8, d0
    38c8:	a90c53f3 	stp	x19, x20, [sp, #192]
    38cc:	910083f4 	add	x20, sp, #0x20
    38d0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38d4:	aa0003f5 	mov	x21, x0
    38d8:	a91073fb 	stp	x27, x28, [sp, #256]
    38dc:	5100071c 	sub	w28, w24, #0x1
    38e0:	2a1c03e5 	mov	w5, w28
    38e4:	f9400040 	ldr	x0, [x2]
    38e8:	f90057e0 	str	x0, [sp, #168]
    38ec:	d2800000 	mov	x0, #0x0                   	// #0
    38f0:	52800042 	mov	w2, #0x2                   	// #2
    38f4:	aa1403e0 	mov	x0, x20
    38f8:	97fffb9a 	bl	2760 <__snprintf_chk@plt>
    38fc:	52800ca1 	mov	w1, #0x65                  	// #101
    3900:	aa1403e0 	mov	x0, x20
    3904:	97fffbf3 	bl	28d0 <strchr@plt>
    3908:	aa0003f3 	mov	x19, x0
    390c:	52800142 	mov	w2, #0xa                   	// #10
    3910:	91000400 	add	x0, x0, #0x1
    3914:	d2800001 	mov	x1, #0x0                   	// #0
    3918:	97fffbde 	bl	2890 <strtol@plt>
    391c:	aa0003f7 	mov	x23, x0
    3920:	11001400 	add	w0, w0, #0x5
    3924:	7100541f 	cmp	w0, #0x15
    3928:	54000d88 	b.hi	3ad8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    392c:	4b170385 	sub	w5, w28, w23
    3930:	710000bf 	cmp	w5, #0x0
    3934:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3938:	54000ba0 	b.eq	3aac <fwp_format_g.constprop.0+0x218>  // b.none
    393c:	394083e0 	ldrb	w0, [sp, #32]
    3940:	cb180273 	sub	x19, x19, x24
    3944:	91000673 	add	x19, x19, #0x1
    3948:	a90f6bf9 	stp	x25, x26, [sp, #240]
    394c:	7100b41f 	cmp	w0, #0x2d
    3950:	9a941681 	cinc	x1, x20, eq	// eq = none
    3954:	1a9f17e4 	cset	w4, eq	// eq = none
    3958:	cb010266 	sub	x6, x19, x1
    395c:	d10004da 	sub	x26, x6, #0x1
    3960:	540018c0 	b.eq	3c78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d280091b 	mov	x27, #0x48                  	// #72
    396c:	aa1903e7 	mov	x7, x25
    3970:	91000423 	add	x3, x1, #0x1
    3974:	91011cc6 	add	x6, x6, #0x47
    3978:	910004f6 	add	x22, x7, #0x1
    397c:	37f81017 	tbnz	w23, #31, 3b7c <fwp_format_g.constprop.0+0x2e8>
    3980:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3984:	93407ef7 	sxtw	x23, w23
    3988:	390000e4 	strb	w4, [x7]
    398c:	aa1303e1 	mov	x1, x19
    3990:	aa1703e2 	mov	x2, x23
    3994:	aa1603e0 	mov	x0, x22
    3998:	b9000be5 	str	w5, [sp, #8]
    399c:	cb170374 	sub	x20, x27, x23
    39a0:	a9011be3 	stp	x3, x6, [sp, #16]
    39a4:	97fffb27 	bl	2640 <memcpy@plt>
    39a8:	d1000694 	sub	x20, x20, #0x1
    39ac:	f9400be3 	ldr	x3, [sp, #16]
    39b0:	8b1702d6 	add	x22, x22, x23
    39b4:	aa1603e0 	mov	x0, x22
    39b8:	aa1a03e2 	mov	x2, x26
    39bc:	aa0303e1 	mov	x1, x3
    39c0:	aa1403e3 	mov	x3, x20
    39c4:	97fffb5f 	bl	2740 <__memcpy_chk@plt>
    39c8:	8b1a02d6 	add	x22, x22, x26
    39cc:	f9400fe6 	ldr	x6, [sp, #24]
    39d0:	d2800900 	mov	x0, #0x48                  	// #72
    39d4:	b9400be5 	ldr	w5, [sp, #8]
    39d8:	8b170261 	add	x1, x19, x23
    39dc:	cb1400c3 	sub	x3, x6, x20
    39e0:	cb060294 	sub	x20, x20, x6
    39e4:	f101207f 	cmp	x3, #0x48
    39e8:	93407cb8 	sxtw	x24, w5
    39ec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39f0:	aa1803e2 	mov	x2, x24
    39f4:	8b1802d3 	add	x19, x22, x24
    39f8:	8b140063 	add	x3, x3, x20
    39fc:	aa1603e0 	mov	x0, x22
    3a00:	97fffb50 	bl	2740 <__memcpy_chk@plt>
    3a04:	cb190273 	sub	x19, x19, x25
    3a08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a0c:	eb00027f 	cmp	x19, x0
    3a10:	aa1903e1 	mov	x1, x25
    3a14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	aa1303e2 	mov	x2, x19
    3a20:	97fffb08 	bl	2640 <memcpy@plt>
    3a24:	38336abf 	strb	wzr, [x21, x19]
    3a28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a2c:	aa1503e0 	mov	x0, x21
    3a30:	97fffb14 	bl	2680 <strlen@plt>
    3a34:	aa0003f3 	mov	x19, x0
    3a38:	528005c1 	mov	w1, #0x2e                  	// #46
    3a3c:	aa1503e0 	mov	x0, x21
    3a40:	97fffba4 	bl	28d0 <strchr@plt>
    3a44:	b4000160 	cbz	x0, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a48:	b4000153 	cbz	x19, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a4c:	d503201f 	nop
    3a50:	aa1303e1 	mov	x1, x19
    3a54:	d1000673 	sub	x19, x19, #0x1
    3a58:	38736aa0 	ldrb	w0, [x21, x19]
    3a5c:	7100c01f 	cmp	w0, #0x30
    3a60:	54001001 	b.ne	3c60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3a64:	38336abf 	strb	wzr, [x21, x19]
    3a68:	b5ffff53 	cbnz	x19, 3a50 <fwp_format_g.constprop.0+0x1bc>
    3a6c:	d503201f 	nop
    3a70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a74:	f947f400 	ldr	x0, [x0, #4072]
    3a78:	f94057e2 	ldr	x2, [sp, #168]
    3a7c:	f9400001 	ldr	x1, [x0]
    3a80:	eb010042 	subs	x2, x2, x1
    3a84:	d2800001 	mov	x1, #0x0                   	// #0
    3a88:	54001061 	b.ne	3c94 <fwp_format_g.constprop.0+0x400>  // b.any
    3a8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3aa0:	fd408be8 	ldr	d8, [sp, #272]
    3aa4:	910483ff 	add	sp, sp, #0x120
    3aa8:	d65f03c0 	ret
    3aac:	1e604100 	fmov	d0, d8
    3ab0:	710000bf 	cmp	w5, #0x0
    3ab4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	d0000044 	adrp	x4, d000 <__modti3+0x320>
    3ac0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ac4:	91072084 	add	x4, x4, #0x1c8
    3ac8:	52800042 	mov	w2, #0x2                   	// #2
    3acc:	d2803201 	mov	x1, #0x190                 	// #400
    3ad0:	97fffb24 	bl	2760 <__snprintf_chk@plt>
    3ad4:	17ffffd6 	b	3a2c <fwp_format_g.constprop.0+0x198>
    3ad8:	cb140273 	sub	x19, x19, x20
    3adc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ae0:	910183f9 	add	x25, sp, #0x60
    3ae4:	aa1303e2 	mov	x2, x19
    3ae8:	aa1403e1 	mov	x1, x20
    3aec:	aa1903e0 	mov	x0, x25
    3af0:	d2800803 	mov	x3, #0x40                  	// #64
    3af4:	97fffb13 	bl	2740 <__memcpy_chk@plt>
    3af8:	38336b3f 	strb	wzr, [x25, x19]
    3afc:	aa1903e0 	mov	x0, x25
    3b00:	528005c1 	mov	w1, #0x2e                  	// #46
    3b04:	97fffb73 	bl	28d0 <strchr@plt>
    3b08:	b40001c0 	cbz	x0, 3b40 <fwp_format_g.constprop.0+0x2ac>
    3b0c:	b50000b3 	cbnz	x19, 3b20 <fwp_format_g.constprop.0+0x28c>
    3b10:	1400000c 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3b14:	381ff01f 	sturb	wzr, [x0, #-1]
    3b18:	f1000673 	subs	x19, x19, #0x1
    3b1c:	54000120 	b.eq	3b40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3b20:	8b130320 	add	x0, x25, x19
    3b24:	385ff001 	ldurb	w1, [x0, #-1]
    3b28:	7100c03f 	cmp	w1, #0x30
    3b2c:	54ffff40 	b.eq	3b14 <fwp_format_g.constprop.0+0x280>  // b.none
    3b30:	d1000673 	sub	x19, x19, #0x1
    3b34:	38736b20 	ldrb	w0, [x25, x19]
    3b38:	7100b81f 	cmp	w0, #0x2e
    3b3c:	54000a80 	b.eq	3c8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3b40:	710002ff 	cmp	w23, #0x0
    3b44:	528005a1 	mov	w1, #0x2d                  	// #45
    3b48:	aa1903e5 	mov	x5, x25
    3b4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b50:	aa1503e0 	mov	x0, x21
    3b54:	52800566 	mov	w6, #0x2b                  	// #43
    3b58:	d0000044 	adrp	x4, d000 <__modti3+0x320>
    3b5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b60:	9106e084 	add	x4, x4, #0x1b8
    3b64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b68:	52800042 	mov	w2, #0x2                   	// #2
    3b6c:	d2803201 	mov	x1, #0x190                 	// #400
    3b70:	97fffafc 	bl	2760 <__snprintf_chk@plt>
    3b74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b78:	17ffffbe 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3b7c:	52800605 	mov	w5, #0x30                  	// #48
    3b80:	390000e5 	strb	w5, [x7]
    3b84:	d100077b 	sub	x27, x27, #0x1
    3b88:	aa0303e1 	mov	x1, x3
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	aa1b03e3 	mov	x3, x27
    3b94:	aa1a03e2 	mov	x2, x26
    3b98:	f90007e6 	str	x6, [sp, #8]
    3b9c:	b90013e4 	str	w4, [sp, #16]
    3ba0:	8b1a02d6 	add	x22, x22, x26
    3ba4:	b9001be5 	str	w5, [sp, #24]
    3ba8:	97fffae6 	bl	2740 <__memcpy_chk@plt>
    3bac:	f94007e6 	ldr	x6, [sp, #8]
    3bb0:	2a3703e7 	mvn	w7, w23
    3bb4:	b94013e4 	ldr	w4, [sp, #16]
    3bb8:	cb1b00c1 	sub	x1, x6, x27
    3bbc:	cb06037b 	sub	x27, x27, x6
    3bc0:	f101203f 	cmp	x1, #0x48
    3bc4:	d2800906 	mov	x6, #0x48                  	// #72
    3bc8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bcc:	8b1b0023 	add	x3, x1, x27
    3bd0:	310006ff 	cmn	w23, #0x1
    3bd4:	54000220 	b.eq	3c18 <fwp_format_g.constprop.0+0x384>  // b.none
    3bd8:	b9401be5 	ldr	w5, [sp, #24]
    3bdc:	d2800001 	mov	x1, #0x0                   	// #0
    3be0:	f101207f 	cmp	x3, #0x48
    3be4:	d1000462 	sub	x2, x3, #0x1
    3be8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bec:	38216ac5 	strb	w5, [x22, x1]
    3bf0:	cb030003 	sub	x3, x0, x3
    3bf4:	91000421 	add	x1, x1, #0x1
    3bf8:	91000463 	add	x3, x3, #0x1
    3bfc:	eb00007f 	cmp	x3, x0
    3c00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c04:	cb000063 	sub	x3, x3, x0
    3c08:	8b020063 	add	x3, x3, x2
    3c0c:	6b0100ff 	cmp	w7, w1
    3c10:	54fffe8c 	b.gt	3be0 <fwp_format_g.constprop.0+0x34c>
    3c14:	8b2742d6 	add	x22, x22, w7, uxtw
    3c18:	f101207f 	cmp	x3, #0x48
    3c1c:	d2800905 	mov	x5, #0x48                  	// #72
    3c20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c24:	aa1603e0 	mov	x0, x22
    3c28:	cb0300a1 	sub	x1, x5, x3
    3c2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c30:	91000421 	add	x1, x1, #0x1
    3c34:	d1000463 	sub	x3, x3, #0x1
    3c38:	eb05003f 	cmp	x1, x5
    3c3c:	38001402 	strb	w2, [x0], #1
    3c40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c44:	93407f82 	sxtw	x2, w28
    3c48:	cb050025 	sub	x5, x1, x5
    3c4c:	aa1303e1 	mov	x1, x19
    3c50:	8b0300a3 	add	x3, x5, x3
    3c54:	8b1802d3 	add	x19, x22, x24
    3c58:	97fffaba 	bl	2740 <__memcpy_chk@plt>
    3c5c:	17ffff6a 	b	3a04 <fwp_format_g.constprop.0+0x170>
    3c60:	d1000421 	sub	x1, x1, #0x1
    3c64:	38616aa0 	ldrb	w0, [x21, x1]
    3c68:	7100b81f 	cmp	w0, #0x2e
    3c6c:	54fff021 	b.ne	3a70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3c70:	38216abf 	strb	wzr, [x21, x1]
    3c74:	17ffff7f 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3c78:	910187e7 	add	x7, sp, #0x61
    3c7c:	910183f9 	add	x25, sp, #0x60
    3c80:	d28008fb 	mov	x27, #0x47                  	// #71
    3c84:	390183e0 	strb	w0, [sp, #96]
    3c88:	17ffff3a 	b	3970 <fwp_format_g.constprop.0+0xdc>
    3c8c:	38336b3f 	strb	wzr, [x25, x19]
    3c90:	17ffffac 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3c94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c98:	97fffad6 	bl	27f0 <__stack_chk_fail@plt>
    3c9c:	d503201f 	nop

0000000000003ca0 <fwp_heap_report>:
    3ca0:	d105c3ff 	sub	sp, sp, #0x170
    3ca4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    3ca8:	91154042 	add	x2, x2, #0x550
    3cac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3cb0:	f947e821 	ldr	x1, [x1, #4048]
    3cb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3cb8:	910443fd 	add	x29, sp, #0x110
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3ccc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3cdc:	f9400036 	ldr	x22, [x1]
    3ce0:	f9400001 	ldr	x1, [x0]
    3ce4:	f90087e1 	str	x1, [sp, #264]
    3ce8:	d2800001 	mov	x1, #0x0                   	// #0
    3cec:	f949e459 	ldr	x25, [x2, #5064]
    3cf0:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    3cf4:	f94a1057 	ldr	x23, [x2, #5152]
    3cf8:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3cfc:	f94a1458 	ldr	x24, [x2, #5160]
    3d00:	91074021 	add	x1, x1, #0x1d0
    3d04:	91076000 	add	x0, x0, #0x1d8
    3d08:	97fffa9e 	bl	2780 <fopen@plt>
    3d0c:	b4000740 	cbz	x0, 3df4 <fwp_heap_report+0x154>
    3d10:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d14:	a91253f3 	stp	x19, x20, [sp, #288]
    3d18:	aa0003f4 	mov	x20, x0
    3d1c:	910023f3 	add	x19, sp, #0x8
    3d20:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d24:	72aae915 	movk	w21, #0x5748, lsl #16
    3d28:	aa1403e2 	mov	x2, x20
    3d2c:	aa1303e0 	mov	x0, x19
    3d30:	52802001 	mov	w1, #0x100                 	// #256
    3d34:	97fffb1f 	bl	29b0 <fgets@plt>
    3d38:	b4000280 	cbz	x0, 3d88 <fwp_heap_report+0xe8>
    3d3c:	b9400261 	ldr	w1, [x19]
    3d40:	6b15003f 	cmp	w1, w21
    3d44:	54ffff21 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d48:	39401260 	ldrb	w0, [x19, #4]
    3d4c:	7101341f 	cmp	w0, #0x4d
    3d50:	54fffec1 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d54:	394037e0 	ldrb	w0, [sp, #13]
    3d58:	7100e81f 	cmp	w0, #0x3a
    3d5c:	54fffe61 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d60:	52800142 	mov	w2, #0xa                   	// #10
    3d64:	d2800001 	mov	x1, #0x0                   	// #0
    3d68:	91003be0 	add	x0, sp, #0xe
    3d6c:	97fffac9 	bl	2890 <strtol@plt>
    3d70:	aa1403e2 	mov	x2, x20
    3d74:	aa0003fa 	mov	x26, x0
    3d78:	52802001 	mov	w1, #0x100                 	// #256
    3d7c:	aa1303e0 	mov	x0, x19
    3d80:	97fffb0c 	bl	29b0 <fgets@plt>
    3d84:	b5fffdc0 	cbnz	x0, 3d3c <fwp_heap_report+0x9c>
    3d88:	aa1403e0 	mov	x0, x20
    3d8c:	97fffa79 	bl	2770 <fclose@plt>
    3d90:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d94:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d98:	f947f400 	ldr	x0, [x0, #4072]
    3d9c:	f94087e2 	ldr	x2, [sp, #264]
    3da0:	f9400001 	ldr	x1, [x0]
    3da4:	eb010042 	subs	x2, x2, x1
    3da8:	d2800001 	mov	x1, #0x0                   	// #0
    3dac:	54000281 	b.ne	3dfc <fwp_heap_report+0x15c>  // b.any
    3db0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3db4:	aa1a03e6 	mov	x6, x26
    3db8:	aa1903e5 	mov	x5, x25
    3dbc:	aa1803e4 	mov	x4, x24
    3dc0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dc4:	aa1703e3 	mov	x3, x23
    3dc8:	a95463f7 	ldp	x23, x24, [sp, #320]
    3dcc:	aa1603e0 	mov	x0, x22
    3dd0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dd4:	1e604121 	fmov	d1, d9
    3dd8:	1e604100 	fmov	d0, d8
    3ddc:	d0000042 	adrp	x2, d000 <__modti3+0x320>
    3de0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3de4:	9107e042 	add	x2, x2, #0x1f8
    3de8:	9105c3ff 	add	sp, sp, #0x170
    3dec:	52800041 	mov	w1, #0x2                   	// #2
    3df0:	17fffa9c 	b	2860 <__fprintf_chk@plt>
    3df4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3df8:	17ffffe7 	b	3d94 <fwp_heap_report+0xf4>
    3dfc:	a91253f3 	stp	x19, x20, [sp, #288]
    3e00:	97fffa7c 	bl	27f0 <__stack_chk_fail@plt>

0000000000003e04 <fwp_heap_init>:
    3e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e08:	f0000163 	adrp	x3, 32000 <fwp_heap+0xab0>
    3e0c:	91114061 	add	x1, x3, #0x450
    3e10:	910003fd 	mov	x29, sp
    3e14:	a90153f3 	stp	x19, x20, [sp, #16]
    3e18:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3e1c:	91154262 	add	x2, x19, #0x550
    3e20:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e24:	52800024 	mov	w4, #0x1                   	// #1
    3e28:	52800200 	mov	w0, #0x10                  	// #16
    3e2c:	b913a444 	str	w4, [x2, #5028]
    3e30:	b8004420 	str	w0, [x1], #4
    3e34:	11004000 	add	w0, w0, #0x10
    3e38:	7104401f 	cmp	w0, #0x110
    3e3c:	54ffffa1 	b.ne	3e30 <fwp_heap_init+0x2c>  // b.any
    3e40:	d0000042 	adrp	x2, d000 <__modti3+0x320>
    3e44:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e48:	f0000161 	adrp	x1, 32000 <fwp_heap+0xab0>
    3e4c:	91124021 	add	x1, x1, #0x490
    3e50:	3dc34c43 	ldr	q3, [x2, #3376]
    3e54:	d2800000 	mov	x0, #0x0                   	// #0
    3e58:	4e040401 	dup	v1.4s, v0.s[0]
    3e5c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e60:	0f215400 	shl	v0.2s, v0.2s, #1
    3e64:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e68:	3ca06821 	str	q1, [x1, x0]
    3e6c:	91004000 	add	x0, x0, #0x10
    3e70:	f101801f 	cmp	x0, #0x60
    3e74:	54ffff21 	b.ne	3e58 <fwp_heap_init+0x54>  // b.any
    3e78:	f0000164 	adrp	x4, 32000 <fwp_heap+0xab0>
    3e7c:	91114063 	add	x3, x3, #0x450
    3e80:	9113c084 	add	x4, x4, #0x4f0
    3e84:	91154266 	add	x6, x19, #0x550
    3e88:	d2800002 	mov	x2, #0x0                   	// #0
    3e8c:	d2800000 	mov	x0, #0x0                   	// #0
    3e90:	d2880205 	mov	x5, #0x4010                	// #16400
    3e94:	d503201f 	nop
    3e98:	910f0001 	add	x1, x0, #0x3c0
    3e9c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	540000a2 	b.cs	3eb8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3ea8:	91000400 	add	x0, x0, #0x1
    3eac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3eb0:	eb02003f 	cmp	x1, x2
    3eb4:	54ffffa3 	b.cc	3ea8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3eb8:	91004042 	add	x2, x2, #0x10
    3ebc:	38001480 	strb	w0, [x4], #1
    3ec0:	eb05005f 	cmp	x2, x5
    3ec4:	54fffea1 	b.ne	3e98 <fwp_heap_init+0x94>  // b.any
    3ec8:	528000b5 	mov	w21, #0x5                   	// #5
    3ecc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ed0:	14000004 	b	3ee0 <fwp_heap_init+0xdc>
    3ed4:	d342fe94 	lsr	x20, x20, #2
    3ed8:	710006b5 	subs	w21, w21, #0x1
    3edc:	54000720 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3ee0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ee4:	d2800005 	mov	x5, #0x0                   	// #0
    3ee8:	aa1603e1 	mov	x1, x22
    3eec:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ef0:	52880443 	mov	w3, #0x4022                	// #16418
    3ef4:	52800002 	mov	w2, #0x0                   	// #0
    3ef8:	d2800000 	mov	x0, #0x0                   	// #0
    3efc:	97fffa61 	bl	2880 <mmap@plt>
    3f00:	aa0003e6 	mov	x6, x0
    3f04:	b100041f 	cmn	x0, #0x1
    3f08:	54fffe60 	b.eq	3ed4 <fwp_heap_init+0xd0>  // b.none
    3f0c:	b40005a0 	cbz	x0, 3fc0 <fwp_heap_init+0x1bc>
    3f10:	d350fe94 	lsr	x20, x20, #16
    3f14:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f18:	8b0000c7 	add	x7, x6, x0
    3f1c:	91154275 	add	x21, x19, #0x550
    3f20:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f24:	8b140a81 	add	x1, x20, x20, lsl #2
    3f28:	d2800005 	mov	x5, #0x0                   	// #0
    3f2c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f30:	d37df021 	lsl	x1, x1, #3
    3f34:	52880443 	mov	w3, #0x4022                	// #16418
    3f38:	52800002 	mov	w2, #0x0                   	// #0
    3f3c:	d2800000 	mov	x0, #0x0                   	// #0
    3f40:	f909daa7 	str	x7, [x21, #5040]
    3f44:	f909dea6 	str	x6, [x21, #5048]
    3f48:	f909e2b6 	str	x22, [x21, #5056]
    3f4c:	f909eab4 	str	x20, [x21, #5072]
    3f50:	f90a02a1 	str	x1, [x21, #5120]
    3f54:	97fffa4b 	bl	2880 <mmap@plt>
    3f58:	aa0003e1 	mov	x1, x0
    3f5c:	b100041f 	cmn	x0, #0x1
    3f60:	54000300 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3f64:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3f68:	910aa000 	add	x0, x0, #0x2a8
    3f6c:	f909fea1 	str	x1, [x21, #5112]
    3f70:	97fffa84 	bl	2980 <getenv@plt>
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	aa0003e1 	mov	x1, x0
    3f7c:	b40000e0 	cbz	x0, 3f98 <fwp_heap_init+0x194>
    3f80:	39400000 	ldrb	w0, [x0]
    3f84:	340000a0 	cbz	w0, 3f98 <fwp_heap_init+0x194>
    3f88:	7100c000 	subs	w0, w0, #0x30
    3f8c:	54000120 	b.eq	3fb0 <fwp_heap_init+0x1ac>  // b.none
    3f90:	7100001f 	cmp	w0, #0x0
    3f94:	1a9f07e2 	cset	w2, ne	// ne = any
    3f98:	91154273 	add	x19, x19, #0x550
    3f9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fa0:	b913aa62 	str	w2, [x19, #5032]
    3fa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fac:	d65f03c0 	ret
    3fb0:	39400420 	ldrb	w0, [x1, #1]
    3fb4:	7100001f 	cmp	w0, #0x0
    3fb8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fbc:	17fffff7 	b	3f98 <fwp_heap_init+0x194>
    3fc0:	97fffbfc 	bl	2fb0 <fwp_heap_oom>

0000000000003fc4 <fwp_wake_io>:
    3fc4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fc8:	91010122 	add	x2, x9, #0x40
    3fcc:	f9400001 	ldr	x1, [x0]
    3fd0:	5280000a 	mov	w10, #0x0                   	// #0
    3fd4:	f9401446 	ldr	x6, [x2, #40]
    3fd8:	52800008 	mov	w8, #0x0                   	// #0
    3fdc:	4f000400 	movi	v0.4s, #0x0
    3fe0:	52800027 	mov	w7, #0x1                   	// #1
    3fe4:	aa0103e2 	mov	x2, x1
    3fe8:	b4000321 	cbz	x1, 404c <fwp_wake_io+0x88>
    3fec:	f9408c25 	ldr	x5, [x1, #280]
    3ff0:	39015c27 	strb	w7, [x1, #87]
    3ff4:	b4000165 	cbz	x5, 4020 <fwp_wake_io+0x5c>
    3ff8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3ffc:	b4000364 	cbz	x4, 4068 <fwp_wake_io+0xa4>
    4000:	f9009483 	str	x3, [x4, #296]
    4004:	f9409423 	ldr	x3, [x1, #296]
    4008:	b4000043 	cbz	x3, 4010 <fwp_wake_io+0x4c>
    400c:	f9009064 	str	x4, [x3, #288]
    4010:	91080023 	add	x3, x1, #0x200
    4014:	f900943f 	str	xzr, [x1, #296]
    4018:	3c918060 	stur	q0, [x3, #-232]
    401c:	f9400001 	ldr	x1, [x0]
    4020:	f9402843 	ldr	x3, [x2, #80]
    4024:	f2001c7f 	tst	x3, #0xff000000ff
    4028:	54fffde1 	b.ne	3fe4 <fwp_wake_io+0x20>  // b.any
    402c:	39015047 	strb	w7, [x2, #84]
    4030:	f900805f 	str	xzr, [x2, #256]
    4034:	b40001e6 	cbz	x6, 4070 <fwp_wake_io+0xac>
    4038:	f90080c2 	str	x2, [x6, #256]
    403c:	aa0203e6 	mov	x6, x2
    4040:	52800028 	mov	w8, #0x1                   	// #1
    4044:	aa0103e2 	mov	x2, x1
    4048:	b5fffd21 	cbnz	x1, 3fec <fwp_wake_io+0x28>
    404c:	3400006a 	cbz	w10, 4058 <fwp_wake_io+0x94>
    4050:	91010120 	add	x0, x9, #0x40
    4054:	f900180b 	str	x11, [x0, #48]
    4058:	34000068 	cbz	w8, 4064 <fwp_wake_io+0xa0>
    405c:	91010129 	add	x9, x9, #0x40
    4060:	f9001526 	str	x6, [x9, #40]
    4064:	d65f03c0 	ret
    4068:	f90000a3 	str	x3, [x5]
    406c:	17ffffe7 	b	4008 <fwp_wake_io+0x44>
    4070:	aa0203eb 	mov	x11, x2
    4074:	5280002a 	mov	w10, #0x1                   	// #1
    4078:	17fffff1 	b	403c <fwp_wake_io+0x78>
    407c:	d503201f 	nop

0000000000004080 <fwp_tape_buffers_release>:
    4080:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4084:	910003fd 	mov	x29, sp
    4088:	a90153f3 	stp	x19, x20, [sp, #16]
    408c:	aa0003f3 	mov	x19, x0
    4090:	f9401400 	ldr	x0, [x0, #40]
    4094:	b7f80760 	tbnz	x0, #63, 4180 <fwp_tape_buffers_release+0x100>
    4098:	f9401a61 	ldr	x1, [x19, #48]
    409c:	b7f80301 	tbnz	x1, #63, 40fc <fwp_tape_buffers_release+0x7c>
    40a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    40a4:	eb02001f 	cmp	x0, x2
    40a8:	540002a8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40ac:	8b000400 	add	x0, x0, x0, lsl #1
    40b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40b4:	d37df000 	lsl	x0, x0, #3
    40b8:	cb000042 	sub	x2, x2, x0
    40bc:	eb420c3f 	cmp	x1, x2, lsr #3
    40c0:	540001e8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40c4:	8b010c14 	add	x20, x0, x1, lsl #3
    40c8:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    40cc:	910ae000 	add	x0, x0, #0x2b8
    40d0:	97fffa2c 	bl	2980 <getenv@plt>
    40d4:	b4000240 	cbz	x0, 411c <fwp_tape_buffers_release+0x9c>
    40d8:	39400001 	ldrb	w1, [x0]
    40dc:	7100c03f 	cmp	w1, #0x30
    40e0:	540001e1 	b.ne	411c <fwp_tape_buffers_release+0x9c>  // b.any
    40e4:	39400400 	ldrb	w0, [x0, #1]
    40e8:	350001a0 	cbnz	w0, 411c <fwp_tape_buffers_release+0x9c>
    40ec:	aa1303e0 	mov	x0, x19
    40f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40f8:	17fffc62 	b	3280 <fwp_tape_buffers_dispose>
    40fc:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    4100:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4104:	910ae000 	add	x0, x0, #0x2b8
    4108:	97fffa1e 	bl	2980 <getenv@plt>
    410c:	b4ffff00 	cbz	x0, 40ec <fwp_tape_buffers_release+0x6c>
    4110:	39400001 	ldrb	w1, [x0]
    4114:	7100c03f 	cmp	w1, #0x30
    4118:	54fffe60 	b.eq	40e4 <fwp_tape_buffers_release+0x64>  // b.none
    411c:	d1000681 	sub	x1, x20, #0x1
    4120:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4124:	eb00003f 	cmp	x1, x0
    4128:	54fffe28 	b.hi	40ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    412c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4130:	900000f6 	adrp	x22, 20000 <__data_start>
    4134:	910102d6 	add	x22, x22, #0x40
    4138:	910122d5 	add	x21, x22, #0x48
    413c:	aa1503e0 	mov	x0, x21
    4140:	97fffc50 	bl	3280 <fwp_tape_buffers_dispose>
    4144:	ad400a61 	ldp	q1, q2, [x19]
    4148:	f90042d4 	str	x20, [x22, #128]
    414c:	4f000400 	movi	v0.4s, #0x0
    4150:	ad000aa1 	stp	q1, q2, [x21]
    4154:	3dc00a61 	ldr	q1, [x19, #32]
    4158:	3d800aa1 	str	q1, [x21, #32]
    415c:	f9401a60 	ldr	x0, [x19, #48]
    4160:	f9001aa0 	str	x0, [x21, #48]
    4164:	f9001a7f 	str	xzr, [x19, #48]
    4168:	ad000260 	stp	q0, q0, [x19]
    416c:	3d800a60 	str	q0, [x19, #32]
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4178:	a8c37bfd 	ldp	x29, x30, [sp], #48
    417c:	d65f03c0 	ret
    4180:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    4184:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4188:	910ae000 	add	x0, x0, #0x2b8
    418c:	97fff9fd 	bl	2980 <getenv@plt>
    4190:	b5fffa40 	cbnz	x0, 40d8 <fwp_tape_buffers_release+0x58>
    4194:	17ffffd6 	b	40ec <fwp_tape_buffers_release+0x6c>
    4198:	d503201f 	nop
    419c:	d503201f 	nop

00000000000041a0 <fwp_poll_events>:
    41a0:	d10103ff 	sub	sp, sp, #0x40
    41a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    41a8:	f947f400 	ldr	x0, [x0, #4072]
    41ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    41b0:	910083fd 	add	x29, sp, #0x20
    41b4:	a90353f3 	stp	x19, x20, [sp, #48]
    41b8:	900000f4 	adrp	x20, 20000 <__data_start>
    41bc:	f9400001 	ldr	x1, [x0]
    41c0:	f9000fe1 	str	x1, [sp, #24]
    41c4:	d2800001 	mov	x1, #0x0                   	// #0
    41c8:	97fffd2e 	bl	3680 <fwp_now_ns>
    41cc:	91010281 	add	x1, x20, #0x40
    41d0:	f9404433 	ldr	x19, [x1, #136]
    41d4:	b4000e93 	cbz	x19, 43a4 <fwp_poll_events+0x204>
    41d8:	aa1303e1 	mov	x1, x19
    41dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    41e0:	14000005 	b	41f4 <fwp_poll_events+0x54>
    41e4:	f9408821 	ldr	x1, [x1, #272]
    41e8:	eb03005f 	cmp	x2, x3
    41ec:	9a83d042 	csel	x2, x2, x3, le
    41f0:	b40000c1 	cbz	x1, 4208 <fwp_poll_events+0x68>
    41f4:	f9403423 	ldr	x3, [x1, #104]
    41f8:	b6ffff62 	tbz	x2, #63, 41e4 <fwp_poll_events+0x44>
    41fc:	f9408821 	ldr	x1, [x1, #272]
    4200:	aa0303e2 	mov	x2, x3
    4204:	b5ffff81 	cbnz	x1, 41f4 <fwp_poll_events+0x54>
    4208:	b7f80ce2 	tbnz	x2, #63, 43a4 <fwp_poll_events+0x204>
    420c:	cb000042 	sub	x2, x2, x0
    4210:	f100005f 	cmp	x2, #0x0
    4214:	540005cd 	b.le	42cc <fwp_poll_events+0x12c>
    4218:	d2869b60 	mov	x0, #0x34db                	// #13531
    421c:	d2884801 	mov	x1, #0x4240                	// #16960
    4220:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4224:	f2a001e1 	movk	x1, #0xf, lsl #16
    4228:	f2dbd040 	movk	x0, #0xde82, lsl #32
    422c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4230:	f2e86360 	movk	x0, #0x431b, lsl #48
    4234:	9b407c40 	smulh	x0, x2, x0
    4238:	9352fc00 	asr	x0, x0, #18
    423c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4240:	9b018802 	msub	x2, x0, x1, x2
    4244:	f100005f 	cmp	x2, #0x0
    4248:	9a800400 	cinc	x0, x0, ne	// ne = any
    424c:	eb03001f 	cmp	x0, x3
    4250:	54000a0c 	b.gt	4390 <fwp_poll_events+0x1f0>
    4254:	340003c0 	cbz	w0, 42cc <fwp_poll_events+0x12c>
    4258:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    425c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4260:	72a20c42 	movk	w2, #0x1062, lsl #16
    4264:	9ba27c02 	umull	x2, w0, w2
    4268:	d366fc43 	lsr	x3, x2, #38
    426c:	aa0303e2 	mov	x2, x3
    4270:	1b048063 	msub	w3, w3, w4, w0
    4274:	9b217c63 	smull	x3, w3, w1
    4278:	d2800001 	mov	x1, #0x0                   	// #0
    427c:	910023e0 	add	x0, sp, #0x8
    4280:	a9008fe2 	stp	x2, x3, [sp, #8]
    4284:	97fff98f 	bl	28c0 <nanosleep@plt>
    4288:	91010280 	add	x0, x20, #0x40
    428c:	f9404413 	ldr	x19, [x0, #136]
    4290:	97fffcfc 	bl	3680 <fwp_now_ns>
    4294:	aa0003e6 	mov	x6, x0
    4298:	b50001f3 	cbnz	x19, 42d4 <fwp_poll_events+0x134>
    429c:	d503201f 	nop
    42a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    42a4:	f947f400 	ldr	x0, [x0, #4072]
    42a8:	f9400fe2 	ldr	x2, [sp, #24]
    42ac:	f9400001 	ldr	x1, [x0]
    42b0:	eb010042 	subs	x2, x2, x1
    42b4:	d2800001 	mov	x1, #0x0                   	// #0
    42b8:	540008c1 	b.ne	43d0 <fwp_poll_events+0x230>  // b.any
    42bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    42c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    42c4:	910103ff 	add	sp, sp, #0x40
    42c8:	d65f03c0 	ret
    42cc:	97fffced 	bl	3680 <fwp_now_ns>
    42d0:	aa0003e6 	mov	x6, x0
    42d4:	4f000400 	movi	v0.4s, #0x0
    42d8:	91010288 	add	x8, x20, #0x40
    42dc:	52800027 	mov	w7, #0x1                   	// #1
    42e0:	f9403661 	ldr	x1, [x19, #104]
    42e4:	aa1303e5 	mov	x5, x19
    42e8:	f9408a73 	ldr	x19, [x19, #272]
    42ec:	eb06003f 	cmp	x1, x6
    42f0:	5400032c 	b.gt	4354 <fwp_poll_events+0x1b4>
    42f4:	394154a0 	ldrb	w0, [x5, #85]
    42f8:	36000120 	tbz	w0, #0, 431c <fwp_poll_events+0x17c>
    42fc:	f94084a0 	ldr	x0, [x5, #264]
    4300:	b40003c0 	cbz	x0, 4378 <fwp_poll_events+0x1d8>
    4304:	f9008813 	str	x19, [x0, #272]
    4308:	b4000053 	cbz	x19, 4310 <fwp_poll_events+0x170>
    430c:	f9008660 	str	x0, [x19, #264]
    4310:	910800a0 	add	x0, x5, #0x200
    4314:	390154bf 	strb	wzr, [x5, #85]
    4318:	3c908000 	stur	q0, [x0, #-248]
    431c:	f94030a0 	ldr	x0, [x5, #96]
    4320:	390158a7 	strb	w7, [x5, #86]
    4324:	f100001f 	cmp	x0, #0x0
    4328:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    432c:	5400018d 	b.le	435c <fwp_poll_events+0x1bc>
    4330:	f94028a0 	ldr	x0, [x5, #80]
    4334:	f2001c1f 	tst	x0, #0xff000000ff
    4338:	540000e1 	b.ne	4354 <fwp_poll_events+0x1b4>  // b.any
    433c:	f9401500 	ldr	x0, [x8, #40]
    4340:	390150a7 	strb	w7, [x5, #84]
    4344:	f90080bf 	str	xzr, [x5, #256]
    4348:	b40001e0 	cbz	x0, 4384 <fwp_poll_events+0x1e4>
    434c:	f9001505 	str	x5, [x8, #40]
    4350:	f9008005 	str	x5, [x0, #256]
    4354:	b5fffc73 	cbnz	x19, 42e0 <fwp_poll_events+0x140>
    4358:	17ffffd2 	b	42a0 <fwp_poll_events+0x100>
    435c:	394144a0 	ldrb	w0, [x5, #81]
    4360:	3707fe80 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    4364:	394140a0 	ldrb	w0, [x5, #80]
    4368:	3707fe40 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    436c:	aa0503e0 	mov	x0, x5
    4370:	97fffc20 	bl	33f0 <fwp_cancel_tree.part.0>
    4374:	17ffffef 	b	4330 <fwp_poll_events+0x190>
    4378:	91010281 	add	x1, x20, #0x40
    437c:	f9004433 	str	x19, [x1, #136]
    4380:	17ffffe2 	b	4308 <fwp_poll_events+0x168>
    4384:	f9001505 	str	x5, [x8, #40]
    4388:	f9001905 	str	x5, [x8, #48]
    438c:	17fffff2 	b	4354 <fwp_poll_events+0x1b4>
    4390:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4394:	d2989362 	mov	x2, #0xc49b                	// #50331
    4398:	f2a4d203 	movk	x3, #0x2690, lsl #16
    439c:	f2a00402 	movk	x2, #0x20, lsl #16
    43a0:	17ffffb6 	b	4278 <fwp_poll_events+0xd8>
    43a4:	97fffaf3 	bl	2f70 <fwp_flush>
    43a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    43ac:	f947e863 	ldr	x3, [x3, #4048]
    43b0:	d2800562 	mov	x2, #0x2b                  	// #43
    43b4:	d2800021 	mov	x1, #0x1                   	// #1
    43b8:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    43bc:	910b4000 	add	x0, x0, #0x2d0
    43c0:	f9400063 	ldr	x3, [x3]
    43c4:	97fff94b 	bl	28f0 <fwrite@plt>
    43c8:	52800ca0 	mov	w0, #0x65                  	// #101
    43cc:	97fff8b5 	bl	26a0 <exit@plt>
    43d0:	97fff908 	bl	27f0 <__stack_chk_fail@plt>

00000000000043d4 <fwp_rc_wide_dup>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f3 	mov	x19, x0
    43e4:	ca404400 	eor	x0, x0, x0, lsr #17
    43e8:	f90013f5 	str	x21, [sp, #32]
    43ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    43f0:	ca402400 	eor	x0, x0, x0, lsr #9
    43f4:	911542a2 	add	x2, x21, #0x550
    43f8:	92401c00 	and	x0, x0, #0xff
    43fc:	910a2403 	add	x3, x0, #0x289
    4400:	8b000c40 	add	x0, x2, x0, lsl #3
    4404:	8b030c54 	add	x20, x2, x3, lsl #3
    4408:	f94a2401 	ldr	x1, [x0, #5192]
    440c:	b50000a1 	cbnz	x1, 4420 <fwp_rc_wide_dup+0x4c>
    4410:	1400002d 	b	44c4 <fwp_rc_wide_dup+0xf0>
    4414:	91004034 	add	x20, x1, #0x10
    4418:	f9400821 	ldr	x1, [x1, #16]
    441c:	b4000241 	cbz	x1, 4464 <fwp_rc_wide_dup+0x90>
    4420:	f9400022 	ldr	x2, [x1]
    4424:	eb02027f 	cmp	x19, x2
    4428:	54ffff61 	b.ne	4414 <fwp_rc_wide_dup+0x40>  // b.any
    442c:	f9400281 	ldr	x1, [x20]
    4430:	39400260 	ldrb	w0, [x19]
    4434:	7103f81f 	cmp	w0, #0xfe
    4438:	54000220 	b.eq	447c <fwp_rc_wide_dup+0xa8>  // b.none
    443c:	b40001a1 	cbz	x1, 4470 <fwp_rc_wide_dup+0x9c>
    4440:	f9400420 	ldr	x0, [x1, #8]
    4444:	b100041f 	cmn	x0, #0x1
    4448:	540004a0 	b.eq	44dc <fwp_rc_wide_dup+0x108>  // b.none
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f9000420 	str	x0, [x1, #8]
    4454:	a94153f3 	ldp	x19, x20, [sp, #16]
    4458:	f94013f5 	ldr	x21, [sp, #32]
    445c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4460:	d65f03c0 	ret
    4464:	39400260 	ldrb	w0, [x19]
    4468:	7103f81f 	cmp	w0, #0xfe
    446c:	540000a0 	b.eq	4480 <fwp_rc_wide_dup+0xac>  // b.none
    4470:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    4474:	910ca000 	add	x0, x0, #0x328
    4478:	97fffc22 	bl	3500 <fwp_trap>
    447c:	b5000281 	cbnz	x1, 44cc <fwp_rc_wide_dup+0xf8>
    4480:	d2800300 	mov	x0, #0x18                  	// #24
    4484:	97fff8c3 	bl	2790 <malloc@plt>
    4488:	b4000280 	cbz	x0, 44d8 <fwp_rc_wide_dup+0x104>
    448c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4490:	a9000413 	stp	x19, x1, [x0]
    4494:	911542b5 	add	x21, x21, #0x550
    4498:	f900081f 	str	xzr, [x0, #16]
    449c:	12800001 	mov	w1, #0xffffffff            	// #-1
    44a0:	f9000280 	str	x0, [x20]
    44a4:	39000261 	strb	w1, [x19]
    44a8:	f94e26a0 	ldr	x0, [x21, #7240]
    44ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b0:	91000400 	add	x0, x0, #0x1
    44b4:	f90e26a0 	str	x0, [x21, #7240]
    44b8:	f94013f5 	ldr	x21, [sp, #32]
    44bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44c0:	d65f03c0 	ret
    44c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    44c8:	17ffffda 	b	4430 <fwp_rc_wide_dup+0x5c>
    44cc:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    44d0:	910c0000 	add	x0, x0, #0x300
    44d4:	97fffc0b 	bl	3500 <fwp_trap>
    44d8:	97fffab6 	bl	2fb0 <fwp_heap_oom>
    44dc:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    44e0:	910d4000 	add	x0, x0, #0x350
    44e4:	97fffc07 	bl	3500 <fwp_trap>
    44e8:	d503201f 	nop
    44ec:	d503201f 	nop

00000000000044f0 <fwp_rc_forget_slot>:
    44f0:	aa0003e1 	mov	x1, x0
    44f4:	39400000 	ldrb	w0, [x0]
    44f8:	7103fc1f 	cmp	w0, #0xff
    44fc:	54000040 	b.eq	4504 <fwp_rc_forget_slot+0x14>  // b.none
    4500:	d65f03c0 	ret
    4504:	ca414420 	eor	x0, x1, x1, lsr #17
    4508:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    450c:	ca402400 	eor	x0, x0, x0, lsr #9
    4510:	910003fd 	mov	x29, sp
    4514:	92401c00 	and	x0, x0, #0xff
    4518:	f9000bf3 	str	x19, [sp, #16]
    451c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4520:	91154262 	add	x2, x19, #0x550
    4524:	910a2403 	add	x3, x0, #0x289
    4528:	8b000c40 	add	x0, x2, x0, lsl #3
    452c:	8b030c43 	add	x3, x2, x3, lsl #3
    4530:	f94a2400 	ldr	x0, [x0, #5192]
    4534:	b50000a0 	cbnz	x0, 4548 <fwp_rc_forget_slot+0x58>
    4538:	14000011 	b	457c <fwp_rc_forget_slot+0x8c>
    453c:	91004003 	add	x3, x0, #0x10
    4540:	f9400800 	ldr	x0, [x0, #16]
    4544:	b40001c0 	cbz	x0, 457c <fwp_rc_forget_slot+0x8c>
    4548:	f9400002 	ldr	x2, [x0]
    454c:	eb02003f 	cmp	x1, x2
    4550:	54ffff61 	b.ne	453c <fwp_rc_forget_slot+0x4c>  // b.any
    4554:	f9400801 	ldr	x1, [x0, #16]
    4558:	91154273 	add	x19, x19, #0x550
    455c:	f9000061 	str	x1, [x3]
    4560:	97fff8d4 	bl	28b0 <free@plt>
    4564:	f94e2660 	ldr	x0, [x19, #7240]
    4568:	d1000400 	sub	x0, x0, #0x1
    456c:	f90e2660 	str	x0, [x19, #7240]
    4570:	f9400bf3 	ldr	x19, [sp, #16]
    4574:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4578:	d65f03c0 	ret
    457c:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    4580:	910ca000 	add	x0, x0, #0x328
    4584:	97fffbdf 	bl	3500 <fwp_trap>
    4588:	d503201f 	nop
    458c:	d503201f 	nop

0000000000004590 <fwp_rc_prepare_chunk>:
    4590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4594:	910003fd 	mov	x29, sp
    4598:	a9025bf5 	stp	x21, x22, [sp, #32]
    459c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    45a0:	911542c2 	add	x2, x22, #0x550
    45a4:	b9401c03 	ldr	w3, [x0, #28]
    45a8:	aa0103f5 	mov	x21, x1
    45ac:	a90153f3 	stp	x19, x20, [sp, #16]
    45b0:	aa0003f4 	mov	x20, x0
    45b4:	f94e2440 	ldr	x0, [x2, #7240]
    45b8:	b4000440 	cbz	x0, 4640 <fwp_rc_prepare_chunk+0xb0>
    45bc:	d2800013 	mov	x19, #0x0                   	// #0
    45c0:	35000203 	cbnz	w3, 4600 <fwp_rc_prepare_chunk+0x70>
    45c4:	b4000361 	cbz	x1, 4630 <fwp_rc_prepare_chunk+0xa0>
    45c8:	f9401280 	ldr	x0, [x20, #32]
    45cc:	97fff8b9 	bl	28b0 <free@plt>
    45d0:	aa1503e0 	mov	x0, x21
    45d4:	d2800021 	mov	x1, #0x1                   	// #1
    45d8:	97fff87e 	bl	27d0 <calloc@plt>
    45dc:	f9001280 	str	x0, [x20, #32]
    45e0:	b5000460 	cbnz	x0, 466c <fwp_rc_prepare_chunk+0xdc>
    45e4:	97fffa73 	bl	2fb0 <fwp_heap_oom>
    45e8:	97ffffc2 	bl	44f0 <fwp_rc_forget_slot>
    45ec:	91000673 	add	x19, x19, #0x1
    45f0:	b9401e83 	ldr	w3, [x20, #28]
    45f4:	eb13007f 	cmp	x3, x19
    45f8:	54000169 	b.ls	4624 <fwp_rc_prepare_chunk+0x94>  // b.plast
    45fc:	d503201f 	nop
    4600:	f9401283 	ldr	x3, [x20, #32]
    4604:	8b130060 	add	x0, x3, x19
    4608:	38736863 	ldrb	w3, [x3, x19]
    460c:	7103fc7f 	cmp	w3, #0xff
    4610:	54fffec0 	b.eq	45e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4614:	b9401e83 	ldr	w3, [x20, #28]
    4618:	91000673 	add	x19, x19, #0x1
    461c:	eb13007f 	cmp	x3, x19
    4620:	54ffff08 	b.hi	4600 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4624:	eb0302bf 	cmp	x21, x3
    4628:	54000121 	b.ne	464c <fwp_rc_prepare_chunk+0xbc>  // b.any
    462c:	b5000335 	cbnz	x21, 4690 <fwp_rc_prepare_chunk+0x100>
    4630:	a94153f3 	ldp	x19, x20, [sp, #16]
    4634:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4638:	a8c37bfd 	ldp	x29, x30, [sp], #48
    463c:	d65f03c0 	ret
    4640:	2a0303e3 	mov	w3, w3
    4644:	eb0302bf 	cmp	x21, x3
    4648:	54ffff20 	b.eq	462c <fwp_rc_prepare_chunk+0x9c>  // b.none
    464c:	911542c2 	add	x2, x22, #0x550
    4650:	f9401280 	ldr	x0, [x20, #32]
    4654:	f94e2841 	ldr	x1, [x2, #7248]
    4658:	cb030021 	sub	x1, x1, x3
    465c:	f90e2841 	str	x1, [x2, #7248]
    4660:	97fff894 	bl	28b0 <free@plt>
    4664:	b5fffb75 	cbnz	x21, 45d0 <fwp_rc_prepare_chunk+0x40>
    4668:	f900129f 	str	xzr, [x20, #32]
    466c:	911542d6 	add	x22, x22, #0x550
    4670:	f94e2ac0 	ldr	x0, [x22, #7248]
    4674:	b9001e95 	str	w21, [x20, #28]
    4678:	a94153f3 	ldp	x19, x20, [sp, #16]
    467c:	8b150000 	add	x0, x0, x21
    4680:	f90e2ac0 	str	x0, [x22, #7248]
    4684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4688:	a8c37bfd 	ldp	x29, x30, [sp], #48
    468c:	d65f03c0 	ret
    4690:	f9401280 	ldr	x0, [x20, #32]
    4694:	aa1503e2 	mov	x2, x21
    4698:	a94153f3 	ldp	x19, x20, [sp, #16]
    469c:	52800001 	mov	w1, #0x0                   	// #0
    46a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46a8:	17fff846 	b	27c0 <memset@plt>
    46ac:	d503201f 	nop

00000000000046b0 <fwp_heap_refill>:
    46b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    46b4:	910003fd 	mov	x29, sp
    46b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    46bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    46c0:	911542b5 	add	x21, x21, #0x550
    46c4:	aa0003f6 	mov	x22, x0
    46c8:	d2800020 	mov	x0, #0x1                   	// #1
    46cc:	a90153f3 	stp	x19, x20, [sp, #16]
    46d0:	a90363f7 	stp	x23, x24, [sp, #48]
    46d4:	2a0103f7 	mov	w23, w1
    46d8:	2a0203f8 	mov	w24, w2
    46dc:	97fffa75 	bl	30b0 <fwp_heap_chunks>
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	f949fea2 	ldr	x2, [x21, #5112]
    46e8:	8b000800 	add	x0, x0, x0, lsl #2
    46ec:	2a1703e1 	mov	w1, w23
    46f0:	52800025 	mov	w5, #0x1                   	// #1
    46f4:	d37df000 	lsl	x0, x0, #3
    46f8:	910f0021 	add	x1, x1, #0x3c0
    46fc:	8b000054 	add	x20, x2, x0
    4700:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4704:	52a00024 	mov	w4, #0x10000               	// #65536
    4708:	38206845 	strb	w5, [x2, x0]
    470c:	aa1403e0 	mov	x0, x20
    4710:	39000698 	strb	w24, [x20, #1]
    4714:	39000a97 	strb	w23, [x20, #2]
    4718:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    471c:	b9000681 	str	w1, [x20, #4]
    4720:	2a0103e5 	mov	w5, w1
    4724:	8b0300a2 	add	x2, x5, x3
    4728:	1ac10881 	udiv	w1, w4, w1
    472c:	9ac50842 	udiv	x2, x2, x5
    4730:	b9000a81 	str	w1, [x20, #8]
    4734:	92404021 	and	x1, x1, #0x1ffff
    4738:	b9001a82 	str	w2, [x20, #24]
    473c:	97ffff95 	bl	4590 <fwp_rc_prepare_chunk>
    4740:	f949daa0 	ldr	x0, [x21, #5040]
    4744:	29408a81 	ldp	w1, w2, [x20, #4]
    4748:	8b134000 	add	x0, x0, x19, lsl #16
    474c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4750:	8b214003 	add	x3, x0, w1, uxtw
    4754:	9ba20021 	umaddl	x1, w1, w2, x0
    4758:	a94363f7 	ldp	x23, x24, [sp, #48]
    475c:	a90086c3 	stp	x3, x1, [x22, #8]
    4760:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4764:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4768:	d65f03c0 	ret
    476c:	d503201f 	nop

0000000000004770 <fwp_mem_free>:
    4770:	b40003c0 	cbz	x0, 47e8 <fwp_mem_free+0x78>
    4774:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4778:	910003fd 	mov	x29, sp
    477c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4780:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4784:	911542a1 	add	x1, x21, #0x550
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	f949d823 	ldr	x3, [x1, #5040]
    4794:	f949ec22 	ldr	x2, [x1, #5080]
    4798:	cb030000 	sub	x0, x0, x3
    479c:	eb02401f 	cmp	x0, x2, lsl #16
    47a0:	540001c2 	b.cs	47d8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    47a4:	d350fc16 	lsr	x22, x0, #16
    47a8:	a90363f7 	stp	x23, x24, [sp, #48]
    47ac:	f949fc22 	ldr	x2, [x1, #5112]
    47b0:	8b160ad4 	add	x20, x22, x22, lsl #2
    47b4:	d37df294 	lsl	x20, x20, #3
    47b8:	ab140057 	adds	x23, x2, x20
    47bc:	540000c0 	b.eq	47d4 <fwp_mem_free+0x64>  // b.none
    47c0:	38746842 	ldrb	w2, [x2, x20]
    47c4:	7100045f 	cmp	w2, #0x1
    47c8:	54000120 	b.eq	47ec <fwp_mem_free+0x7c>  // b.none
    47cc:	7100085f 	cmp	w2, #0x2
    47d0:	540005e0 	b.eq	488c <fwp_mem_free+0x11c>  // b.none
    47d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47e4:	d65f03c0 	ret
    47e8:	d65f03c0 	ret
    47ec:	f94012f8 	ldr	x24, [x23, #32]
    47f0:	b94006e1 	ldr	w1, [x23, #4]
    47f4:	f90023f9 	str	x25, [sp, #64]
    47f8:	2a0103e2 	mov	w2, w1
    47fc:	394006f9 	ldrb	w25, [x23, #1]
    4800:	39400af4 	ldrb	w20, [x23, #2]
    4804:	b4000158 	cbz	x24, 482c <fwp_mem_free+0xbc>
    4808:	92403e76 	and	x22, x19, #0xffff
    480c:	9ac20ad6 	udiv	x22, x22, x2
    4810:	38766b01 	ldrb	w1, [x24, x22]
    4814:	8b160300 	add	x0, x24, x22
    4818:	7103fc3f 	cmp	w1, #0xff
    481c:	54000980 	b.eq	494c <fwp_mem_free+0x1dc>  // b.none
    4820:	38366b1f 	strb	wzr, [x24, x22]
    4824:	b94006e1 	ldr	w1, [x23, #4]
    4828:	2a0103e2 	mov	w2, w1
    482c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4830:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4834:	cb390000 	sub	x0, x0, w25, uxtb
    4838:	8b340074 	add	x20, x3, w20, uxtb
    483c:	911542b5 	add	x21, x21, #0x550
    4840:	1e630021 	ucvtf	d1, w1
    4844:	d37ae400 	lsl	x0, x0, #6
    4848:	8b140c14 	add	x20, x0, x20, lsl #3
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	f8746aa0 	ldr	x0, [x21, x20]
    4854:	f94023f9 	ldr	x25, [sp, #64]
    4858:	aa2003e0 	mvn	x0, x0
    485c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4860:	f9000260 	str	x0, [x19]
    4864:	f8346ab3 	str	x19, [x21, x20]
    4868:	f94a12a0 	ldr	x0, [x21, #5152]
    486c:	1e612800 	fadd	d0, d0, d1
    4870:	a94153f3 	ldp	x19, x20, [sp, #16]
    4874:	cb020000 	sub	x0, x0, x2
    4878:	f90a12a0 	str	x0, [x21, #5152]
    487c:	fd0a22a0 	str	d0, [x21, #5184]
    4880:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4884:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4888:	d65f03c0 	ret
    488c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4890:	8b000063 	add	x3, x3, x0
    4894:	eb03027f 	cmp	x19, x3
    4898:	54fff9e1 	b.ne	47d4 <fwp_mem_free+0x64>  // b.any
    489c:	fd400ae1 	ldr	d1, [x23, #16]
    48a0:	fd4a2020 	ldr	d0, [x1, #5184]
    48a4:	f9400ae0 	ldr	x0, [x23, #16]
    48a8:	7e61d821 	ucvtf	d1, d1
    48ac:	f94a1022 	ldr	x2, [x1, #5152]
    48b0:	f94012f3 	ldr	x19, [x23, #32]
    48b4:	1e612800 	fadd	d0, d0, d1
    48b8:	cb000042 	sub	x2, x2, x0
    48bc:	f90a1022 	str	x2, [x1, #5152]
    48c0:	fd0a2020 	str	d0, [x1, #5184]
    48c4:	b40000b3 	cbz	x19, 48d8 <fwp_mem_free+0x168>
    48c8:	39400260 	ldrb	w0, [x19]
    48cc:	7103fc1f 	cmp	w0, #0xff
    48d0:	54000380 	b.eq	4940 <fwp_mem_free+0x1d0>  // b.none
    48d4:	3900027f 	strb	wzr, [x19]
    48d8:	b9400ee2 	ldr	w2, [x23, #12]
    48dc:	b4000142 	cbz	x2, 4904 <fwp_mem_free+0x194>
    48e0:	911542a1 	add	x1, x21, #0x550
    48e4:	8b160040 	add	x0, x2, x22
    48e8:	8b000800 	add	x0, x0, x0, lsl #2
    48ec:	f949fc21 	ldr	x1, [x1, #5112]
    48f0:	8b140034 	add	x20, x1, x20
    48f4:	8b000c20 	add	x0, x1, x0, lsl #3
    48f8:	3802869f 	strb	wzr, [x20], #40
    48fc:	eb00029f 	cmp	x20, x0
    4900:	54ffffc1 	b.ne	48f8 <fwp_mem_free+0x188>  // b.any
    4904:	911542a0 	add	x0, x21, #0x550
    4908:	f94a1801 	ldr	x1, [x0, #5168]
    490c:	f949f803 	ldr	x3, [x0, #5104]
    4910:	8b020021 	add	x1, x1, x2
    4914:	f90a1801 	str	x1, [x0, #5168]
    4918:	eb16007f 	cmp	x3, x22
    491c:	54000049 	b.ls	4924 <fwp_mem_free+0x1b4>  // b.plast
    4920:	f909f816 	str	x22, [x0, #5104]
    4924:	911542b5 	add	x21, x21, #0x550
    4928:	f949f6a0 	ldr	x0, [x21, #5096]
    492c:	eb16001f 	cmp	x0, x22
    4930:	54fff529 	b.ls	47d4 <fwp_mem_free+0x64>  // b.plast
    4934:	a94363f7 	ldp	x23, x24, [sp, #48]
    4938:	f909f6b6 	str	x22, [x21, #5096]
    493c:	17ffffa7 	b	47d8 <fwp_mem_free+0x68>
    4940:	aa1303e0 	mov	x0, x19
    4944:	97fffeeb 	bl	44f0 <fwp_rc_forget_slot>
    4948:	17ffffe3 	b	48d4 <fwp_mem_free+0x164>
    494c:	97fffee9 	bl	44f0 <fwp_rc_forget_slot>
    4950:	17ffffb4 	b	4820 <fwp_mem_free+0xb0>

0000000000004954 <fwp_heap_alloc_big>:
    4954:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4958:	910003fd 	mov	x29, sp
    495c:	a90153f3 	stp	x19, x20, [sp, #16]
    4960:	a9025bf5 	stp	x21, x22, [sp, #32]
    4964:	a90363f7 	stp	x23, x24, [sp, #48]
    4968:	aa0003f7 	mov	x23, x0
    496c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	eb0002ff 	cmp	x23, x0
    4978:	54000888 	b.hi	4a88 <fwp_heap_alloc_big+0x134>  // b.pmore
    497c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4980:	8b0002f4 	add	x20, x23, x0
    4984:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc90>
    4988:	91154359 	add	x25, x26, #0x550
    498c:	d350fe94 	lsr	x20, x20, #16
    4990:	2a0103f5 	mov	w21, w1
    4994:	aa1403e0 	mov	x0, x20
    4998:	97fff9c6 	bl	30b0 <fwp_heap_chunks>
    499c:	f949ff22 	ldr	x2, [x25, #5112]
    49a0:	8b000813 	add	x19, x0, x0, lsl #2
    49a4:	aa0003f8 	mov	x24, x0
    49a8:	52800043 	mov	w3, #0x2                   	// #2
    49ac:	d37df273 	lsl	x19, x19, #3
    49b0:	d2800021 	mov	x1, #0x1                   	// #1
    49b4:	8b130040 	add	x0, x2, x19
    49b8:	38336843 	strb	w3, [x2, x19]
    49bc:	39000415 	strb	w21, [x0, #1]
    49c0:	b9000c14 	str	w20, [x0, #12]
    49c4:	f9000817 	str	x23, [x0, #16]
    49c8:	97fffef2 	bl	4590 <fwp_rc_prepare_chunk>
    49cc:	f100069f 	cmp	x20, #0x1
    49d0:	54000269 	b.ls	4a1c <fwp_heap_alloc_big+0xc8>  // b.plast
    49d4:	8b180294 	add	x20, x20, x24
    49d8:	9100a273 	add	x19, x19, #0x28
    49dc:	a90573fb 	stp	x27, x28, [sp, #80]
    49e0:	5280007b 	mov	w27, #0x3                   	// #3
    49e4:	8b140a94 	add	x20, x20, x20, lsl #2
    49e8:	2a1803fc 	mov	w28, w24
    49ec:	9adb2296 	lsl	x22, x20, x27
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffee4 	bl	4590 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0x9c>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91154353 	add	x19, x26, #0x550
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x104>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115435a 	add	x26, x26, #0x550
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4aa0:	91154262 	add	x2, x19, #0x550
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91154262 	add	x2, x19, #0x550
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91154260 	add	x0, x19, #0x550
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91154273 	add	x19, x19, #0x550
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffca4 	bl	3e04 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff70 	b	4954 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91154260 	add	x0, x19, #0x550
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffeb5 	bl	46b0 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4c04:	91154293 	add	x19, x20, #0x550
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91154294 	add	x20, x20, #0x550
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	910102f7 	add	x23, x23, #0x40
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9401ee0 	ldr	x0, [x23, #56]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_p_ad_push>:
    4f24:	f100001f 	cmp	x0, #0x0
    4f28:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4f2c:	54000e8b 	b.lt	50fc <fwp_p_ad_push+0x1d8>  // b.tstop
    4f30:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f34:	aa0003e4 	mov	x4, x0
    4f38:	910003fd 	mov	x29, sp
    4f3c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f40:	aa0003f5 	mov	x21, x0
    4f44:	aa020000 	orr	x0, x0, x2
    4f48:	a90363f7 	stp	x23, x24, [sp, #48]
    4f4c:	aa0203f7 	mov	x23, x2
    4f50:	6d0627e8 	stp	d8, d9, [sp, #96]
    4f54:	9e670029 	fmov	d9, x1
    4f58:	9e670068 	fmov	d8, x3
    4f5c:	b6f80900 	tbz	x0, #63, 507c <fwp_p_ad_push+0x158>
    4f60:	a90153f3 	stp	x19, x20, [sp, #16]
    4f64:	9360fc80 	asr	x0, x4, #32
    4f68:	b6f800c4 	tbz	x4, #63, 4f80 <fwp_p_ad_push+0x5c>
    4f6c:	1e604109 	fmov	d9, d8
    4f70:	2f00e408 	movi	d8, #0x0
    4f74:	9360fc40 	asr	x0, x2, #32
    4f78:	aa0203f5 	mov	x21, x2
    4f7c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f80:	97fffa2c 	bl	3830 <fwp_tape_of>
    4f84:	aa0003f3 	mov	x19, x0
    4f88:	f9403000 	ldr	x0, [x0, #96]
    4f8c:	b5001280 	cbnz	x0, 51dc <fwp_p_ad_push+0x2b8>
    4f90:	f9400a76 	ldr	x22, [x19, #16]
    4f94:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f98:	eb0002df 	cmp	x22, x0
    4f9c:	54000e2c 	b.gt	5160 <fwp_p_ad_push+0x23c>
    4fa0:	eb3542df 	cmp	x22, w21, uxtw
    4fa4:	54000d4d 	b.le	514c <fwp_p_ad_push+0x228>
    4fa8:	b7f80077 	tbnz	x23, #63, 4fb4 <fwp_p_ad_push+0x90>
    4fac:	eb3742df 	cmp	x22, w23, uxtw
    4fb0:	54000ced 	b.le	514c <fwp_p_ad_push+0x228>
    4fb4:	f9400678 	ldr	x24, [x19, #8]
    4fb8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4fbc:	cb1802d8 	sub	x24, x22, x24
    4fc0:	91000701 	add	x1, x24, #0x1
    4fc4:	eb00003f 	cmp	x1, x0
    4fc8:	54000cc8 	b.hi	5160 <fwp_p_ad_push+0x23c>  // b.pmore
    4fcc:	a9418274 	ldp	x20, x0, [x19, #24]
    4fd0:	a90573fb 	stp	x27, x28, [sp, #80]
    4fd4:	eb14003f 	cmp	x1, x20
    4fd8:	5400068d 	b.le	50a8 <fwp_p_ad_push+0x184>
    4fdc:	f100029f 	cmp	x20, #0x0
    4fe0:	d2800803 	mov	x3, #0x40                  	// #64
    4fe4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4fe8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4fec:	a9046bf9 	stp	x25, x26, [sp, #64]
    4ff0:	eb14003f 	cmp	x1, x20
    4ff4:	5400008d 	b.le	5004 <fwp_p_ad_push+0xe0>
    4ff8:	eb02029f 	cmp	x20, x2
    4ffc:	5400052d 	b.le	50a0 <fwp_p_ad_push+0x17c>
    5000:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5004:	d37df299 	lsl	x25, x20, #3
    5008:	aa1903e1 	mov	x1, x25
    500c:	97fff5f5 	bl	27e0 <realloc@plt>
    5010:	aa0003e1 	mov	x1, x0
    5014:	b4000b00 	cbz	x0, 5174 <fwp_p_ad_push+0x250>
    5018:	f9400e62 	ldr	x2, [x19, #24]
    501c:	f9001261 	str	x1, [x19, #32]
    5020:	f9401a60 	ldr	x0, [x19, #48]
    5024:	d37cee9a 	lsl	x26, x20, #4
    5028:	8b020821 	add	x1, x1, x2, lsl #2
    502c:	f9001661 	str	x1, [x19, #40]
    5030:	aa1a03e1 	mov	x1, x26
    5034:	97fff5eb 	bl	27e0 <realloc@plt>
    5038:	aa0003e2 	mov	x2, x0
    503c:	b40009c0 	cbz	x0, 5174 <fwp_p_ad_push+0x250>
    5040:	f9400e61 	ldr	x1, [x19, #24]
    5044:	d37df31b 	lsl	x27, x24, #3
    5048:	d37ef685 	lsl	x5, x20, #2
    504c:	d37ef71c 	lsl	x28, x24, #2
    5050:	8b190004 	add	x4, x0, x25
    5054:	8b010c01 	add	x1, x0, x1, lsl #3
    5058:	a9030660 	stp	x0, x1, [x19, #48]
    505c:	b5000558 	cbnz	x24, 5104 <fwp_p_ad_push+0x1e0>
    5060:	f9001e64 	str	x4, [x19, #56]
    5064:	f9401260 	ldr	x0, [x19, #32]
    5068:	a9446bf9 	ldp	x25, x26, [sp, #64]
    506c:	8b050001 	add	x1, x0, x5
    5070:	f9000e74 	str	x20, [x19, #24]
    5074:	f9001661 	str	x1, [x19, #40]
    5078:	14000010 	b	50b8 <fwp_p_ad_push+0x194>
    507c:	9360fc40 	asr	x0, x2, #32
    5080:	a90153f3 	stp	x19, x20, [sp, #16]
    5084:	eb84801f 	cmp	x0, x4, asr #32
    5088:	54fff7c0 	b.eq	4f80 <fwp_p_ad_push+0x5c>  // b.none
    508c:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5090:	910dc000 	add	x0, x0, #0x370
    5094:	a9046bf9 	stp	x25, x26, [sp, #64]
    5098:	a90573fb 	stp	x27, x28, [sp, #80]
    509c:	97fff919 	bl	3500 <fwp_trap>
    50a0:	d37ffa94 	lsl	x20, x20, #1
    50a4:	17ffffd3 	b	4ff0 <fwp_p_ad_push+0xcc>
    50a8:	a9428a61 	ldp	x1, x2, [x19, #40]
    50ac:	d37ef71c 	lsl	x28, x24, #2
    50b0:	f9401e64 	ldr	x4, [x19, #56]
    50b4:	d37df31b 	lsl	x27, x24, #3
    50b8:	b83c6815 	str	w21, [x0, x28]
    50bc:	f10002ff 	cmp	x23, #0x0
    50c0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    50c4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    50c8:	fc3b6849 	str	d9, [x2, x27]
    50cc:	aa1602a0 	orr	x0, x21, x22
    50d0:	b83c6837 	str	w23, [x1, x28]
    50d4:	910006d6 	add	x22, x22, #0x1
    50d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50dc:	fc3b6888 	str	d8, [x4, x27]
    50e0:	a94573fb 	ldp	x27, x28, [sp, #80]
    50e4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    50e8:	f9000a76 	str	x22, [x19, #16]
    50ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    50f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50f4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    50f8:	d65f03c0 	ret
    50fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5100:	d65f03c0 	ret
    5104:	eb1a033f 	cmp	x25, x26
    5108:	aa0403e0 	mov	x0, x4
    510c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5110:	aa1b03e2 	mov	x2, x27
    5114:	cb190063 	sub	x3, x3, x25
    5118:	f9003fe5 	str	x5, [sp, #120]
    511c:	97fff61d 	bl	2990 <__memmove_chk@plt>
    5120:	a9420660 	ldp	x0, x1, [x19, #32]
    5124:	aa1c03e2 	mov	x2, x28
    5128:	f9401a63 	ldr	x3, [x19, #48]
    512c:	f9403fe5 	ldr	x5, [sp, #120]
    5130:	8b190063 	add	x3, x3, x25
    5134:	f9001e63 	str	x3, [x19, #56]
    5138:	8b050000 	add	x0, x0, x5
    513c:	97fff549 	bl	2660 <memmove@plt>
    5140:	a9431262 	ldp	x2, x4, [x19, #48]
    5144:	f9403fe5 	ldr	x5, [sp, #120]
    5148:	17ffffc7 	b	5064 <fwp_p_ad_push+0x140>
    514c:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5150:	91102000 	add	x0, x0, #0x408
    5154:	a9046bf9 	stp	x25, x26, [sp, #64]
    5158:	a90573fb 	stp	x27, x28, [sp, #80]
    515c:	97fff8e9 	bl	3500 <fwp_trap>
    5160:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5164:	910fa000 	add	x0, x0, #0x3e8
    5168:	a9046bf9 	stp	x25, x26, [sp, #64]
    516c:	a90573fb 	stp	x27, x28, [sp, #80]
    5170:	97fff8e4 	bl	3500 <fwp_trap>
    5174:	aa1303e0 	mov	x0, x19
    5178:	97fff766 	bl	2f10 <fwp_tape_unlink_scope>
    517c:	f9401260 	ldr	x0, [x19, #32]
    5180:	97fff5cc 	bl	28b0 <free@plt>
    5184:	f9401a60 	ldr	x0, [x19, #48]
    5188:	97fff5ca 	bl	28b0 <free@plt>
    518c:	f9402260 	ldr	x0, [x19, #64]
    5190:	97fff5c8 	bl	28b0 <free@plt>
    5194:	f9000e7f 	str	xzr, [x19, #24]
    5198:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    519c:	f947e821 	ldr	x1, [x1, #4048]
    51a0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    51a4:	d2800262 	mov	x2, #0x13                  	// #19
    51a8:	4f000400 	movi	v0.4s, #0x0
    51ac:	90000040 	adrp	x0, d000 <__modti3+0x320>
    51b0:	f9400023 	ldr	x3, [x1]
    51b4:	b900067f 	str	wzr, [x19, #4]
    51b8:	d2800021 	mov	x1, #0x1                   	// #1
    51bc:	91022000 	add	x0, x0, #0x88
    51c0:	3c808260 	stur	q0, [x19, #8]
    51c4:	ad010260 	stp	q0, q0, [x19, #32]
    51c8:	97fff5ca 	bl	28f0 <fwrite@plt>
    51cc:	d2800000 	mov	x0, #0x0                   	// #0
    51d0:	97fff5d4 	bl	2920 <fflush@plt>
    51d4:	52800cc0 	mov	w0, #0x66                  	// #102
    51d8:	97fff5e2 	bl	2960 <_Exit@plt>
    51dc:	90000040 	adrp	x0, d000 <__modti3+0x320>
    51e0:	910ee000 	add	x0, x0, #0x3b8
    51e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    51e8:	a90573fb 	stp	x27, x28, [sp, #80]
    51ec:	97fff8c5 	bl	3500 <fwp_trap>

00000000000051f0 <w107>:
    51f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51f4:	9e660003 	fmov	x3, d0
    51f8:	aa0003e2 	mov	x2, x0
    51fc:	910003fd 	mov	x29, sp
    5200:	6d0327e8 	stp	d8, d9, [sp, #48]
    5204:	1e604028 	fmov	d8, d1
    5208:	1e600809 	fmul	d9, d0, d0
    520c:	fd0023ea 	str	d10, [sp, #64]
    5210:	1e60400a 	fmov	d10, d0
    5214:	a90153f3 	stp	x19, x20, [sp, #16]
    5218:	aa0003f3 	mov	x19, x0
    521c:	aa0103f4 	mov	x20, x1
    5220:	aa0303e1 	mov	x1, x3
    5224:	a9025bf5 	stp	x21, x22, [sp, #32]
    5228:	97ffff3f 	bl	4f24 <fwp_p_ad_push>
    522c:	1e693908 	fsub	d8, d8, d9
    5230:	aa1403e2 	mov	x2, x20
    5234:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5238:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    523c:	9e660116 	fmov	x22, d8
    5240:	97ffff39 	bl	4f24 <fwp_p_ad_push>
    5244:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5248:	aa0003e1 	mov	x1, x0
    524c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5250:	aa1303e0 	mov	x0, x19
    5254:	1e6a3929 	fsub	d9, d9, d10
    5258:	aa0103f3 	mov	x19, x1
    525c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5260:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5264:	9e660135 	fmov	x21, d9
    5268:	97ffff2f 	bl	4f24 <fwp_p_ad_push>
    526c:	1e680908 	fmul	d8, d8, d8
    5270:	aa0003f4 	mov	x20, x0
    5274:	aa1603e3 	mov	x3, x22
    5278:	aa1603e1 	mov	x1, x22
    527c:	aa1303e2 	mov	x2, x19
    5280:	aa1303e0 	mov	x0, x19
    5284:	97ffff28 	bl	4f24 <fwp_p_ad_push>
    5288:	aa0003e2 	mov	x2, x0
    528c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5290:	9e670020 	fmov	d0, x1
    5294:	9e660101 	fmov	x1, d8
    5298:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    529c:	1e600908 	fmul	d8, d8, d0
    52a0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52a4:	97ffff20 	bl	4f24 <fwp_p_ad_push>
    52a8:	1e690929 	fmul	d9, d9, d9
    52ac:	aa0003f3 	mov	x19, x0
    52b0:	aa1503e3 	mov	x3, x21
    52b4:	aa1503e1 	mov	x1, x21
    52b8:	aa1403e2 	mov	x2, x20
    52bc:	aa1403e0 	mov	x0, x20
    52c0:	97ffff19 	bl	4f24 <fwp_p_ad_push>
    52c4:	1e692908 	fadd	d8, d8, d9
    52c8:	aa1303e2 	mov	x2, x19
    52cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52d0:	aa0303e1 	mov	x1, x3
    52d4:	97ffff14 	bl	4f24 <fwp_p_ad_push>
    52d8:	aa0003e1 	mov	x1, x0
    52dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    52e0:	9e660100 	fmov	x0, d8
    52e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52e8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    52ec:	fd4023ea 	ldr	d10, [sp, #64]
    52f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    52f4:	d65f03c0 	ret
    52f8:	d503201f 	nop
    52fc:	d503201f 	nop

0000000000005300 <fwp_data.part.0.constprop.0>:
    5300:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5304:	910003fd 	mov	x29, sp
    5308:	a90153f3 	stp	x19, x20, [sp, #16]
    530c:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    5310:	91154283 	add	x3, x20, #0x550
    5314:	a9025bf5 	stp	x21, x22, [sp, #32]
    5318:	aa0103f5 	mov	x21, x1
    531c:	b953a461 	ldr	w1, [x3, #5028]
    5320:	a90363f7 	stp	x23, x24, [sp, #48]
    5324:	2a0003f8 	mov	w24, w0
    5328:	34000701 	cbz	w1, 5408 <fwp_data.part.0.constprop.0+0x108>
    532c:	397e8862 	ldrb	w2, [x3, #4002]
    5330:	910f0040 	add	x0, x2, #0x3c0
    5334:	8b020442 	add	x2, x2, x2, lsl #1
    5338:	d37df042 	lsl	x2, x2, #3
    533c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5340:	2a1703f6 	mov	w22, w23
    5344:	f8626873 	ldr	x19, [x3, x2]
    5348:	b40004d3 	cbz	x19, 53e0 <fwp_data.part.0.constprop.0+0xe0>
    534c:	f9400260 	ldr	x0, [x19]
    5350:	aa2003e0 	mvn	x0, x0
    5354:	f8226860 	str	x0, [x3, x2]
    5358:	f10062df 	cmp	x22, #0x18
    535c:	540000e9 	b.ls	5378 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5360:	d10066c2 	sub	x2, x22, #0x19
    5364:	91006260 	add	x0, x19, #0x18
    5368:	927df042 	and	x2, x2, #0xfffffffffffffff8
    536c:	52800001 	mov	w1, #0x0                   	// #0
    5370:	91002042 	add	x2, x2, #0x8
    5374:	97fff513 	bl	27c0 <memset@plt>
    5378:	91154282 	add	x2, x20, #0x550
    537c:	f94a1041 	ldr	x1, [x2, #5152]
    5380:	ab160021 	adds	x1, x1, x22
    5384:	540004c2 	b.cs	541c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5388:	f94a1440 	ldr	x0, [x2, #5160]
    538c:	f90a1041 	str	x1, [x2, #5152]
    5390:	eb00003f 	cmp	x1, x0
    5394:	54000049 	b.ls	539c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5398:	f90a1441 	str	x1, [x2, #5160]
    539c:	91154294 	add	x20, x20, #0x550
    53a0:	1e6302e1 	ucvtf	d1, w23
    53a4:	fd4a1e80 	ldr	d0, [x20, #5176]
    53a8:	1e612800 	fadd	d0, d0, d1
    53ac:	fd0a1e80 	str	d0, [x20, #5176]
    53b0:	52800041 	mov	w1, #0x2                   	// #2
    53b4:	29000678 	stp	w24, w1, [x19]
    53b8:	aa1303e0 	mov	x0, x19
    53bc:	f94002a1 	ldr	x1, [x21]
    53c0:	f9000661 	str	x1, [x19, #8]
    53c4:	f94006a1 	ldr	x1, [x21, #8]
    53c8:	f9000a61 	str	x1, [x19, #16]
    53cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    53d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    53d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    53dc:	d65f03c0 	ret
    53e0:	8b020063 	add	x3, x3, x2
    53e4:	f9400473 	ldr	x19, [x3, #8]
    53e8:	b4000113 	cbz	x19, 5408 <fwp_data.part.0.constprop.0+0x108>
    53ec:	f9400860 	ldr	x0, [x3, #16]
    53f0:	cb130000 	sub	x0, x0, x19
    53f4:	eb0002df 	cmp	x22, x0
    53f8:	54000088 	b.hi	5408 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    53fc:	8b160260 	add	x0, x19, x22
    5400:	f9000460 	str	x0, [x3, #8]
    5404:	17ffffd5 	b	5358 <fwp_data.part.0.constprop.0+0x58>
    5408:	52800001 	mov	w1, #0x0                   	// #0
    540c:	d2800300 	mov	x0, #0x18                  	// #24
    5410:	97fffdf8 	bl	4bf0 <fwp_heap_alloc>
    5414:	aa0003f3 	mov	x19, x0
    5418:	17ffffe6 	b	53b0 <fwp_data.part.0.constprop.0+0xb0>
    541c:	97fff6e5 	bl	2fb0 <fwp_heap_oom>

0000000000005420 <fwp_rc_share>:
    5420:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5424:	91154042 	add	x2, x2, #0x550
    5428:	f949d843 	ldr	x3, [x2, #5040]
    542c:	f949ec41 	ldr	x1, [x2, #5080]
    5430:	cb030000 	sub	x0, x0, x3
    5434:	eb01401f 	cmp	x0, x1, lsl #16
    5438:	540002c2 	b.cs	5490 <fwp_rc_share+0x70>  // b.hs, b.nlast
    543c:	d350fc01 	lsr	x1, x0, #16
    5440:	f949fc44 	ldr	x4, [x2, #5112]
    5444:	8b010821 	add	x1, x1, x1, lsl #2
    5448:	d37df021 	lsl	x1, x1, #3
    544c:	8b010083 	add	x3, x4, x1
    5450:	f9401062 	ldr	x2, [x3, #32]
    5454:	b40001e2 	cbz	x2, 5490 <fwp_rc_share+0x70>
    5458:	38616881 	ldrb	w1, [x4, x1]
    545c:	7100083f 	cmp	w1, #0x2
    5460:	540001a0 	b.eq	5494 <fwp_rc_share+0x74>  // b.none
    5464:	7100043f 	cmp	w1, #0x1
    5468:	54000141 	b.ne	5490 <fwp_rc_share+0x70>  // b.any
    546c:	29430464 	ldp	w4, w1, [x3, #24]
    5470:	92403c00 	and	x0, x0, #0xffff
    5474:	9b047c00 	mul	x0, x0, x4
    5478:	d360fc00 	lsr	x0, x0, #32
    547c:	eb01001f 	cmp	x0, x1
    5480:	54000082 	b.cs	5490 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5484:	8b000042 	add	x2, x2, x0
    5488:	39400040 	ldrb	w0, [x2]
    548c:	350000a0 	cbnz	w0, 54a0 <fwp_rc_share+0x80>
    5490:	d65f03c0 	ret
    5494:	72003c1f 	tst	w0, #0xffff
    5498:	54ffff80 	b.eq	5488 <fwp_rc_share+0x68>  // b.none
    549c:	d65f03c0 	ret
    54a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    54a4:	90000040 	adrp	x0, d000 <__modti3+0x320>
    54a8:	9110a000 	add	x0, x0, #0x428
    54ac:	910003fd 	mov	x29, sp
    54b0:	97fff814 	bl	3500 <fwp_trap>

00000000000054b4 <fwp_rc_fresh>:
    54b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    54b8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    54bc:	91154063 	add	x3, x3, #0x550
    54c0:	910003fd 	mov	x29, sp
    54c4:	a90153f3 	stp	x19, x20, [sp, #16]
    54c8:	aa0003f3 	mov	x19, x0
    54cc:	f949d861 	ldr	x1, [x3, #5040]
    54d0:	f949ec60 	ldr	x0, [x3, #5080]
    54d4:	cb010261 	sub	x1, x19, x1
    54d8:	eb00403f 	cmp	x1, x0, lsl #16
    54dc:	54000322 	b.cs	5540 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    54e0:	d350fc22 	lsr	x2, x1, #16
    54e4:	f949fc63 	ldr	x3, [x3, #5112]
    54e8:	8b020842 	add	x2, x2, x2, lsl #2
    54ec:	d37df042 	lsl	x2, x2, #3
    54f0:	8b020060 	add	x0, x3, x2
    54f4:	f9401014 	ldr	x20, [x0, #32]
    54f8:	b4000254 	cbz	x20, 5540 <fwp_rc_fresh+0x8c>
    54fc:	38626862 	ldrb	w2, [x3, x2]
    5500:	7100085f 	cmp	w2, #0x2
    5504:	54000260 	b.eq	5550 <fwp_rc_fresh+0x9c>  // b.none
    5508:	7100045f 	cmp	w2, #0x1
    550c:	540001a1 	b.ne	5540 <fwp_rc_fresh+0x8c>  // b.any
    5510:	29430002 	ldp	w2, w0, [x0, #24]
    5514:	92403c21 	and	x1, x1, #0xffff
    5518:	9b027c21 	mul	x1, x1, x2
    551c:	d360fc21 	lsr	x1, x1, #32
    5520:	eb00003f 	cmp	x1, x0
    5524:	540000e2 	b.cs	5540 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5528:	8b010294 	add	x20, x20, x1
    552c:	39400280 	ldrb	w0, [x20]
    5530:	7103fc1f 	cmp	w0, #0xff
    5534:	540001a0 	b.eq	5568 <fwp_rc_fresh+0xb4>  // b.none
    5538:	52800020 	mov	w0, #0x1                   	// #1
    553c:	39000280 	strb	w0, [x20]
    5540:	aa1303e0 	mov	x0, x19
    5544:	a94153f3 	ldp	x19, x20, [sp, #16]
    5548:	a8c27bfd 	ldp	x29, x30, [sp], #32
    554c:	d65f03c0 	ret
    5550:	72003c3f 	tst	w1, #0xffff
    5554:	54fffec0 	b.eq	552c <fwp_rc_fresh+0x78>  // b.none
    5558:	aa1303e0 	mov	x0, x19
    555c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5560:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5564:	d65f03c0 	ret
    5568:	aa1403e0 	mov	x0, x20
    556c:	97fffbe1 	bl	44f0 <fwp_rc_forget_slot>
    5570:	17fffff2 	b	5538 <fwp_rc_fresh+0x84>

0000000000005574 <fwp_rc_free_arr>:
    5574:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5578:	91154063 	add	x3, x3, #0x550
    557c:	f949d861 	ldr	x1, [x3, #5040]
    5580:	f949ec62 	ldr	x2, [x3, #5080]
    5584:	cb010001 	sub	x1, x0, x1
    5588:	eb02403f 	cmp	x1, x2, lsl #16
    558c:	54000342 	b.cs	55f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5590:	d350fc22 	lsr	x2, x1, #16
    5594:	f949fc65 	ldr	x5, [x3, #5112]
    5598:	8b020842 	add	x2, x2, x2, lsl #2
    559c:	d37df042 	lsl	x2, x2, #3
    55a0:	8b0200a4 	add	x4, x5, x2
    55a4:	f9401083 	ldr	x3, [x4, #32]
    55a8:	b4000263 	cbz	x3, 55f4 <fwp_rc_free_arr+0x80>
    55ac:	386268a2 	ldrb	w2, [x5, x2]
    55b0:	7100085f 	cmp	w2, #0x2
    55b4:	540001c0 	b.eq	55ec <fwp_rc_free_arr+0x78>  // b.none
    55b8:	7100045f 	cmp	w2, #0x1
    55bc:	540001c1 	b.ne	55f4 <fwp_rc_free_arr+0x80>  // b.any
    55c0:	29430885 	ldp	w5, w2, [x4, #24]
    55c4:	92403c21 	and	x1, x1, #0xffff
    55c8:	9b057c21 	mul	x1, x1, x5
    55cc:	d360fc21 	lsr	x1, x1, #32
    55d0:	eb02003f 	cmp	x1, x2
    55d4:	54000102 	b.cs	55f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    55d8:	8b010063 	add	x3, x3, x1
    55dc:	39400061 	ldrb	w1, [x3]
    55e0:	7100043f 	cmp	w1, #0x1
    55e4:	54000081 	b.ne	55f4 <fwp_rc_free_arr+0x80>  // b.any
    55e8:	17fffc62 	b	4770 <fwp_mem_free>
    55ec:	72003c3f 	tst	w1, #0xffff
    55f0:	54ffff60 	b.eq	55dc <fwp_rc_free_arr+0x68>  // b.none
    55f4:	d65f03c0 	ret
    55f8:	d503201f 	nop
    55fc:	d503201f 	nop

0000000000005600 <fwp_rc_dup>:
    5600:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5604:	91154042 	add	x2, x2, #0x550
    5608:	f949d841 	ldr	x1, [x2, #5040]
    560c:	f949ec43 	ldr	x3, [x2, #5080]
    5610:	cb010001 	sub	x1, x0, x1
    5614:	eb03403f 	cmp	x1, x3, lsl #16
    5618:	54000342 	b.cs	5680 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    561c:	d350fc20 	lsr	x0, x1, #16
    5620:	f949fc44 	ldr	x4, [x2, #5112]
    5624:	8b000800 	add	x0, x0, x0, lsl #2
    5628:	d37df002 	lsl	x2, x0, #3
    562c:	8b020083 	add	x3, x4, x2
    5630:	f9401060 	ldr	x0, [x3, #32]
    5634:	b4000260 	cbz	x0, 5680 <fwp_rc_dup+0x80>
    5638:	38626882 	ldrb	w2, [x4, x2]
    563c:	7100085f 	cmp	w2, #0x2
    5640:	54000220 	b.eq	5684 <fwp_rc_dup+0x84>  // b.none
    5644:	7100045f 	cmp	w2, #0x1
    5648:	540001c1 	b.ne	5680 <fwp_rc_dup+0x80>  // b.any
    564c:	29430864 	ldp	w4, w2, [x3, #24]
    5650:	92403c21 	and	x1, x1, #0xffff
    5654:	9b047c21 	mul	x1, x1, x4
    5658:	d360fc21 	lsr	x1, x1, #32
    565c:	eb02003f 	cmp	x1, x2
    5660:	54000102 	b.cs	5680 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5664:	8b010000 	add	x0, x0, x1
    5668:	39400001 	ldrb	w1, [x0]
    566c:	340000a1 	cbz	w1, 5680 <fwp_rc_dup+0x80>
    5670:	7103f43f 	cmp	w1, #0xfd
    5674:	540000e8 	b.hi	5690 <fwp_rc_dup+0x90>  // b.pmore
    5678:	11000421 	add	w1, w1, #0x1
    567c:	39000001 	strb	w1, [x0]
    5680:	d65f03c0 	ret
    5684:	72003c3f 	tst	w1, #0xffff
    5688:	54ffff00 	b.eq	5668 <fwp_rc_dup+0x68>  // b.none
    568c:	d65f03c0 	ret
    5690:	17fffb51 	b	43d4 <fwp_rc_wide_dup>

0000000000005694 <fwp_owned_entry161>:
    5694:	d10103ff 	sub	sp, sp, #0x40
    5698:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    569c:	f947f442 	ldr	x2, [x2, #4072]
    56a0:	a9027bfd 	stp	x29, x30, [sp, #32]
    56a4:	910083fd 	add	x29, sp, #0x20
    56a8:	a90353f3 	stp	x19, x20, [sp, #48]
    56ac:	f9400043 	ldr	x3, [x2]
    56b0:	f9000fe3 	str	x3, [sp, #24]
    56b4:	d2800003 	mov	x3, #0x0                   	// #0
    56b8:	a9400c01 	ldp	x1, x3, [x0]
    56bc:	f9400802 	ldr	x2, [x0, #16]
    56c0:	ab020022 	adds	x2, x1, x2
    56c4:	540006e6 	b.vs	57a0 <fwp_owned_entry161+0x10c>
    56c8:	910023e1 	add	x1, sp, #0x8
    56cc:	52800000 	mov	w0, #0x0                   	// #0
    56d0:	a9008be3 	stp	x3, x2, [sp, #8]
    56d4:	97ffff0b 	bl	5300 <fwp_data.part.0.constprop.0>
    56d8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    56dc:	91154063 	add	x3, x3, #0x550
    56e0:	aa0003f3 	mov	x19, x0
    56e4:	f949d861 	ldr	x1, [x3, #5040]
    56e8:	f949ec60 	ldr	x0, [x3, #5080]
    56ec:	cb010261 	sub	x1, x19, x1
    56f0:	eb00403f 	cmp	x1, x0, lsl #16
    56f4:	54000322 	b.cs	5758 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    56f8:	d350fc22 	lsr	x2, x1, #16
    56fc:	f949fc63 	ldr	x3, [x3, #5112]
    5700:	8b020842 	add	x2, x2, x2, lsl #2
    5704:	d37df042 	lsl	x2, x2, #3
    5708:	8b020060 	add	x0, x3, x2
    570c:	f9401014 	ldr	x20, [x0, #32]
    5710:	b4000254 	cbz	x20, 5758 <fwp_owned_entry161+0xc4>
    5714:	38626862 	ldrb	w2, [x3, x2]
    5718:	7100085f 	cmp	w2, #0x2
    571c:	54000360 	b.eq	5788 <fwp_owned_entry161+0xf4>  // b.none
    5720:	7100045f 	cmp	w2, #0x1
    5724:	540001a1 	b.ne	5758 <fwp_owned_entry161+0xc4>  // b.any
    5728:	29430002 	ldp	w2, w0, [x0, #24]
    572c:	92403c21 	and	x1, x1, #0xffff
    5730:	9b027c21 	mul	x1, x1, x2
    5734:	d360fc21 	lsr	x1, x1, #32
    5738:	eb00003f 	cmp	x1, x0
    573c:	540000e2 	b.cs	5758 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5740:	8b010294 	add	x20, x20, x1
    5744:	39400280 	ldrb	w0, [x20]
    5748:	7103fc1f 	cmp	w0, #0xff
    574c:	54000240 	b.eq	5794 <fwp_owned_entry161+0x100>  // b.none
    5750:	52800020 	mov	w0, #0x1                   	// #1
    5754:	39000280 	strb	w0, [x20]
    5758:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    575c:	f947f400 	ldr	x0, [x0, #4072]
    5760:	f9400fe2 	ldr	x2, [sp, #24]
    5764:	f9400001 	ldr	x1, [x0]
    5768:	eb010042 	subs	x2, x2, x1
    576c:	d2800001 	mov	x1, #0x0                   	// #0
    5770:	540001a1 	b.ne	57a4 <fwp_owned_entry161+0x110>  // b.any
    5774:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5778:	aa1303e0 	mov	x0, x19
    577c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5780:	910103ff 	add	sp, sp, #0x40
    5784:	d65f03c0 	ret
    5788:	72003c3f 	tst	w1, #0xffff
    578c:	54fffe61 	b.ne	5758 <fwp_owned_entry161+0xc4>  // b.any
    5790:	17ffffed 	b	5744 <fwp_owned_entry161+0xb0>
    5794:	aa1403e0 	mov	x0, x20
    5798:	97fffb56 	bl	44f0 <fwp_rc_forget_slot>
    579c:	17ffffed 	b	5750 <fwp_owned_entry161+0xbc>
    57a0:	97fff498 	bl	2a00 <fwp_trap_overflow.constprop.0>
    57a4:	97fff413 	bl	27f0 <__stack_chk_fail@plt>
    57a8:	d503201f 	nop
    57ac:	d503201f 	nop

00000000000057b0 <e161>:
    57b0:	d10103ff 	sub	sp, sp, #0x40
    57b4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    57b8:	f947f442 	ldr	x2, [x2, #4072]
    57bc:	a9027bfd 	stp	x29, x30, [sp, #32]
    57c0:	910083fd 	add	x29, sp, #0x20
    57c4:	a90353f3 	stp	x19, x20, [sp, #48]
    57c8:	f9400043 	ldr	x3, [x2]
    57cc:	f9000fe3 	str	x3, [sp, #24]
    57d0:	d2800003 	mov	x3, #0x0                   	// #0
    57d4:	a9400c01 	ldp	x1, x3, [x0]
    57d8:	f9400802 	ldr	x2, [x0, #16]
    57dc:	ab020022 	adds	x2, x1, x2
    57e0:	54000726 	b.vs	58c4 <e161+0x114>
    57e4:	910023e1 	add	x1, sp, #0x8
    57e8:	52800000 	mov	w0, #0x0                   	// #0
    57ec:	a9008be3 	stp	x3, x2, [sp, #8]
    57f0:	97fffec4 	bl	5300 <fwp_data.part.0.constprop.0>
    57f4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    57f8:	91154063 	add	x3, x3, #0x550
    57fc:	aa0003f3 	mov	x19, x0
    5800:	f949d861 	ldr	x1, [x3, #5040]
    5804:	f949ec60 	ldr	x0, [x3, #5080]
    5808:	cb010261 	sub	x1, x19, x1
    580c:	eb00403f 	cmp	x1, x0, lsl #16
    5810:	54000322 	b.cs	5874 <e161+0xc4>  // b.hs, b.nlast
    5814:	d350fc22 	lsr	x2, x1, #16
    5818:	f949fc63 	ldr	x3, [x3, #5112]
    581c:	8b020842 	add	x2, x2, x2, lsl #2
    5820:	d37df042 	lsl	x2, x2, #3
    5824:	8b020060 	add	x0, x3, x2
    5828:	f9401014 	ldr	x20, [x0, #32]
    582c:	b4000254 	cbz	x20, 5874 <e161+0xc4>
    5830:	38626862 	ldrb	w2, [x3, x2]
    5834:	7100085f 	cmp	w2, #0x2
    5838:	540003a0 	b.eq	58ac <e161+0xfc>  // b.none
    583c:	7100045f 	cmp	w2, #0x1
    5840:	540001a1 	b.ne	5874 <e161+0xc4>  // b.any
    5844:	29430002 	ldp	w2, w0, [x0, #24]
    5848:	92403c21 	and	x1, x1, #0xffff
    584c:	9b027c21 	mul	x1, x1, x2
    5850:	d360fc21 	lsr	x1, x1, #32
    5854:	eb00003f 	cmp	x1, x0
    5858:	540000e2 	b.cs	5874 <e161+0xc4>  // b.hs, b.nlast
    585c:	8b010294 	add	x20, x20, x1
    5860:	39400280 	ldrb	w0, [x20]
    5864:	7103fc1f 	cmp	w0, #0xff
    5868:	54000280 	b.eq	58b8 <e161+0x108>  // b.none
    586c:	52800020 	mov	w0, #0x1                   	// #1
    5870:	39000280 	strb	w0, [x20]
    5874:	aa1303e0 	mov	x0, x19
    5878:	97fffeea 	bl	5420 <fwp_rc_share>
    587c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5880:	f947f400 	ldr	x0, [x0, #4072]
    5884:	f9400fe2 	ldr	x2, [sp, #24]
    5888:	f9400001 	ldr	x1, [x0]
    588c:	eb010042 	subs	x2, x2, x1
    5890:	d2800001 	mov	x1, #0x0                   	// #0
    5894:	540001a1 	b.ne	58c8 <e161+0x118>  // b.any
    5898:	a9427bfd 	ldp	x29, x30, [sp, #32]
    589c:	aa1303e0 	mov	x0, x19
    58a0:	a94353f3 	ldp	x19, x20, [sp, #48]
    58a4:	910103ff 	add	sp, sp, #0x40
    58a8:	d65f03c0 	ret
    58ac:	72003c3f 	tst	w1, #0xffff
    58b0:	54fffe21 	b.ne	5874 <e161+0xc4>  // b.any
    58b4:	17ffffeb 	b	5860 <e161+0xb0>
    58b8:	aa1403e0 	mov	x0, x20
    58bc:	97fffb0d 	bl	44f0 <fwp_rc_forget_slot>
    58c0:	17ffffeb 	b	586c <e161+0xbc>
    58c4:	97fff44f 	bl	2a00 <fwp_trap_overflow.constprop.0>
    58c8:	97fff3ca 	bl	27f0 <__stack_chk_fail@plt>
    58cc:	d503201f 	nop

00000000000058d0 <fwp_drop1>:
    58d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    58d4:	910003fd 	mov	x29, sp
    58d8:	a90153f3 	stp	x19, x20, [sp, #16]
    58dc:	f90013f5 	str	x21, [sp, #32]
    58e0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    58e4:	911542b4 	add	x20, x21, #0x550
    58e8:	f949da81 	ldr	x1, [x20, #5040]
    58ec:	f949ee82 	ldr	x2, [x20, #5080]
    58f0:	cb010001 	sub	x1, x0, x1
    58f4:	eb02403f 	cmp	x1, x2, lsl #16
    58f8:	54000382 	b.cs	5968 <fwp_drop1+0x98>  // b.hs, b.nlast
    58fc:	d350fc22 	lsr	x2, x1, #16
    5900:	f949fe84 	ldr	x4, [x20, #5112]
    5904:	8b020842 	add	x2, x2, x2, lsl #2
    5908:	d37df042 	lsl	x2, x2, #3
    590c:	8b020083 	add	x3, x4, x2
    5910:	f9401073 	ldr	x19, [x3, #32]
    5914:	b40002b3 	cbz	x19, 5968 <fwp_drop1+0x98>
    5918:	38626882 	ldrb	w2, [x4, x2]
    591c:	7100085f 	cmp	w2, #0x2
    5920:	540002c0 	b.eq	5978 <fwp_drop1+0xa8>  // b.none
    5924:	7100045f 	cmp	w2, #0x1
    5928:	54000201 	b.ne	5968 <fwp_drop1+0x98>  // b.any
    592c:	29430864 	ldp	w4, w2, [x3, #24]
    5930:	92403c21 	and	x1, x1, #0xffff
    5934:	9b047c21 	mul	x1, x1, x4
    5938:	d360fc21 	lsr	x1, x1, #32
    593c:	eb02003f 	cmp	x1, x2
    5940:	54000142 	b.cs	5968 <fwp_drop1+0x98>  // b.hs, b.nlast
    5944:	8b010273 	add	x19, x19, x1
    5948:	39400261 	ldrb	w1, [x19]
    594c:	340000e1 	cbz	w1, 5968 <fwp_drop1+0x98>
    5950:	7100043f 	cmp	w1, #0x1
    5954:	540001e0 	b.eq	5990 <fwp_drop1+0xc0>  // b.none
    5958:	7103fc3f 	cmp	w1, #0xff
    595c:	540002e0 	b.eq	59b8 <fwp_drop1+0xe8>  // b.none
    5960:	51000421 	sub	w1, w1, #0x1
    5964:	39000261 	strb	w1, [x19]
    5968:	a94153f3 	ldp	x19, x20, [sp, #16]
    596c:	f94013f5 	ldr	x21, [sp, #32]
    5970:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5974:	d65f03c0 	ret
    5978:	72003c3f 	tst	w1, #0xffff
    597c:	54fffe60 	b.eq	5948 <fwp_drop1+0x78>  // b.none
    5980:	a94153f3 	ldp	x19, x20, [sp, #16]
    5984:	f94013f5 	ldr	x21, [sp, #32]
    5988:	a8c37bfd 	ldp	x29, x30, [sp], #48
    598c:	d65f03c0 	ret
    5990:	f9400813 	ldr	x19, [x0, #16]
    5994:	97fffef8 	bl	5574 <fwp_rc_free_arr>
    5998:	911542a0 	add	x0, x21, #0x550
    599c:	f949d801 	ldr	x1, [x0, #5040]
    59a0:	f949ec00 	ldr	x0, [x0, #5080]
    59a4:	cb010261 	sub	x1, x19, x1
    59a8:	eb00403f 	cmp	x1, x0, lsl #16
    59ac:	54fffde2 	b.cs	5968 <fwp_drop1+0x98>  // b.hs, b.nlast
    59b0:	aa1303e0 	mov	x0, x19
    59b4:	17ffffd2 	b	58fc <fwp_drop1+0x2c>
    59b8:	ca534660 	eor	x0, x19, x19, lsr #17
    59bc:	911542b5 	add	x21, x21, #0x550
    59c0:	ca402400 	eor	x0, x0, x0, lsr #9
    59c4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    59c8:	f94a2400 	ldr	x0, [x0, #5192]
    59cc:	b5000080 	cbnz	x0, 59dc <fwp_drop1+0x10c>
    59d0:	14000010 	b	5a10 <fwp_drop1+0x140>
    59d4:	f9400800 	ldr	x0, [x0, #16]
    59d8:	b40001c0 	cbz	x0, 5a10 <fwp_drop1+0x140>
    59dc:	f9400001 	ldr	x1, [x0]
    59e0:	eb13003f 	cmp	x1, x19
    59e4:	54ffff81 	b.ne	59d4 <fwp_drop1+0x104>  // b.any
    59e8:	f9400401 	ldr	x1, [x0, #8]
    59ec:	d1000421 	sub	x1, x1, #0x1
    59f0:	f9000401 	str	x1, [x0, #8]
    59f4:	f103f83f 	cmp	x1, #0xfe
    59f8:	54fffb81 	b.ne	5968 <fwp_drop1+0x98>  // b.any
    59fc:	aa1303e0 	mov	x0, x19
    5a00:	97fffabc 	bl	44f0 <fwp_rc_forget_slot>
    5a04:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5a08:	39000260 	strb	w0, [x19]
    5a0c:	17ffffd7 	b	5968 <fwp_drop1+0x98>
    5a10:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5a14:	910ca000 	add	x0, x0, #0x328
    5a18:	97fff6ba 	bl	3500 <fwp_trap>
    5a1c:	d503201f 	nop

0000000000005a20 <fwp_drop0>:
    5a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a24:	910003fd 	mov	x29, sp
    5a28:	a90153f3 	stp	x19, x20, [sp, #16]
    5a2c:	f90013f5 	str	x21, [sp, #32]
    5a30:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5a34:	911542b4 	add	x20, x21, #0x550
    5a38:	f949da81 	ldr	x1, [x20, #5040]
    5a3c:	f949ee82 	ldr	x2, [x20, #5080]
    5a40:	cb010001 	sub	x1, x0, x1
    5a44:	eb02403f 	cmp	x1, x2, lsl #16
    5a48:	54000382 	b.cs	5ab8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5a4c:	d350fc22 	lsr	x2, x1, #16
    5a50:	f949fe84 	ldr	x4, [x20, #5112]
    5a54:	8b020842 	add	x2, x2, x2, lsl #2
    5a58:	d37df042 	lsl	x2, x2, #3
    5a5c:	8b020083 	add	x3, x4, x2
    5a60:	f9401073 	ldr	x19, [x3, #32]
    5a64:	b40002b3 	cbz	x19, 5ab8 <fwp_drop0+0x98>
    5a68:	38626882 	ldrb	w2, [x4, x2]
    5a6c:	7100085f 	cmp	w2, #0x2
    5a70:	540002c0 	b.eq	5ac8 <fwp_drop0+0xa8>  // b.none
    5a74:	7100045f 	cmp	w2, #0x1
    5a78:	54000201 	b.ne	5ab8 <fwp_drop0+0x98>  // b.any
    5a7c:	29430864 	ldp	w4, w2, [x3, #24]
    5a80:	92403c21 	and	x1, x1, #0xffff
    5a84:	9b047c21 	mul	x1, x1, x4
    5a88:	d360fc21 	lsr	x1, x1, #32
    5a8c:	eb02003f 	cmp	x1, x2
    5a90:	54000142 	b.cs	5ab8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5a94:	8b010273 	add	x19, x19, x1
    5a98:	39400261 	ldrb	w1, [x19]
    5a9c:	340000e1 	cbz	w1, 5ab8 <fwp_drop0+0x98>
    5aa0:	7100043f 	cmp	w1, #0x1
    5aa4:	540001e0 	b.eq	5ae0 <fwp_drop0+0xc0>  // b.none
    5aa8:	7103fc3f 	cmp	w1, #0xff
    5aac:	540002e0 	b.eq	5b08 <fwp_drop0+0xe8>  // b.none
    5ab0:	51000421 	sub	w1, w1, #0x1
    5ab4:	39000261 	strb	w1, [x19]
    5ab8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5abc:	f94013f5 	ldr	x21, [sp, #32]
    5ac0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ac4:	d65f03c0 	ret
    5ac8:	72003c3f 	tst	w1, #0xffff
    5acc:	54fffe60 	b.eq	5a98 <fwp_drop0+0x78>  // b.none
    5ad0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ad4:	f94013f5 	ldr	x21, [sp, #32]
    5ad8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5adc:	d65f03c0 	ret
    5ae0:	f9400813 	ldr	x19, [x0, #16]
    5ae4:	97fffea4 	bl	5574 <fwp_rc_free_arr>
    5ae8:	911542a0 	add	x0, x21, #0x550
    5aec:	f949d801 	ldr	x1, [x0, #5040]
    5af0:	f949ec00 	ldr	x0, [x0, #5080]
    5af4:	cb010261 	sub	x1, x19, x1
    5af8:	eb00403f 	cmp	x1, x0, lsl #16
    5afc:	54fffde2 	b.cs	5ab8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b00:	aa1303e0 	mov	x0, x19
    5b04:	17ffffd2 	b	5a4c <fwp_drop0+0x2c>
    5b08:	ca534660 	eor	x0, x19, x19, lsr #17
    5b0c:	911542b5 	add	x21, x21, #0x550
    5b10:	ca402400 	eor	x0, x0, x0, lsr #9
    5b14:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5b18:	f94a2400 	ldr	x0, [x0, #5192]
    5b1c:	b5000080 	cbnz	x0, 5b2c <fwp_drop0+0x10c>
    5b20:	14000010 	b	5b60 <fwp_drop0+0x140>
    5b24:	f9400800 	ldr	x0, [x0, #16]
    5b28:	b40001c0 	cbz	x0, 5b60 <fwp_drop0+0x140>
    5b2c:	f9400001 	ldr	x1, [x0]
    5b30:	eb13003f 	cmp	x1, x19
    5b34:	54ffff81 	b.ne	5b24 <fwp_drop0+0x104>  // b.any
    5b38:	f9400401 	ldr	x1, [x0, #8]
    5b3c:	d1000421 	sub	x1, x1, #0x1
    5b40:	f9000401 	str	x1, [x0, #8]
    5b44:	f103f83f 	cmp	x1, #0xfe
    5b48:	54fffb81 	b.ne	5ab8 <fwp_drop0+0x98>  // b.any
    5b4c:	aa1303e0 	mov	x0, x19
    5b50:	97fffa68 	bl	44f0 <fwp_rc_forget_slot>
    5b54:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b58:	39000260 	strb	w0, [x19]
    5b5c:	17ffffd7 	b	5ab8 <fwp_drop0+0x98>
    5b60:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5b64:	910ca000 	add	x0, x0, #0x328
    5b68:	97fff666 	bl	3500 <fwp_trap>
    5b6c:	d503201f 	nop

0000000000005b70 <fwp_arg_drop12>:
    5b70:	7100003f 	cmp	w1, #0x0
    5b74:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5b78:	54000041 	b.ne	5b80 <fwp_arg_drop12+0x10>  // b.any
    5b7c:	d65f03c0 	ret
    5b80:	f9400000 	ldr	x0, [x0]
    5b84:	17ffffa7 	b	5a20 <fwp_drop0>
    5b88:	d503201f 	nop
    5b8c:	d503201f 	nop

0000000000005b90 <fwp_closure_drop>:
    5b90:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc90>
    5b94:	911540a4 	add	x4, x5, #0x550
    5b98:	aa0003e1 	mov	x1, x0
    5b9c:	f949d882 	ldr	x2, [x4, #5040]
    5ba0:	f949ec80 	ldr	x0, [x4, #5080]
    5ba4:	cb020022 	sub	x2, x1, x2
    5ba8:	eb00405f 	cmp	x2, x0, lsl #16
    5bac:	54000662 	b.cs	5c78 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5bb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5bb4:	d350fc43 	lsr	x3, x2, #16
    5bb8:	910003fd 	mov	x29, sp
    5bbc:	8b030863 	add	x3, x3, x3, lsl #2
    5bc0:	f949fc84 	ldr	x4, [x4, #5112]
    5bc4:	d37df063 	lsl	x3, x3, #3
    5bc8:	f9000bf3 	str	x19, [sp, #16]
    5bcc:	8b030080 	add	x0, x4, x3
    5bd0:	f9401013 	ldr	x19, [x0, #32]
    5bd4:	b40002b3 	cbz	x19, 5c28 <fwp_closure_drop+0x98>
    5bd8:	38636883 	ldrb	w3, [x4, x3]
    5bdc:	7100087f 	cmp	w3, #0x2
    5be0:	54000420 	b.eq	5c64 <fwp_closure_drop+0xd4>  // b.none
    5be4:	7100047f 	cmp	w3, #0x1
    5be8:	54000201 	b.ne	5c28 <fwp_closure_drop+0x98>  // b.any
    5bec:	29430003 	ldp	w3, w0, [x0, #24]
    5bf0:	92403c42 	and	x2, x2, #0xffff
    5bf4:	9b037c42 	mul	x2, x2, x3
    5bf8:	d360fc42 	lsr	x2, x2, #32
    5bfc:	eb00005f 	cmp	x2, x0
    5c00:	54000142 	b.cs	5c28 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5c04:	8b020273 	add	x19, x19, x2
    5c08:	39400260 	ldrb	w0, [x19]
    5c0c:	340000e0 	cbz	w0, 5c28 <fwp_closure_drop+0x98>
    5c10:	7100041f 	cmp	w0, #0x1
    5c14:	54000100 	b.eq	5c34 <fwp_closure_drop+0xa4>  // b.none
    5c18:	7103fc1f 	cmp	w0, #0xff
    5c1c:	54000300 	b.eq	5c7c <fwp_closure_drop+0xec>  // b.none
    5c20:	51000400 	sub	w0, w0, #0x1
    5c24:	39000260 	strb	w0, [x19]
    5c28:	f9400bf3 	ldr	x19, [sp, #16]
    5c2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c30:	d65f03c0 	ret
    5c34:	d53bd040 	mrs	x0, tpidr_el0
    5c38:	91400000 	add	x0, x0, #0x0, lsl #12
    5c3c:	91004000 	add	x0, x0, #0x10
    5c40:	f9400000 	ldr	x0, [x0]
    5c44:	b4000080 	cbz	x0, 5c54 <fwp_closure_drop+0xc4>
    5c48:	f9400bf3 	ldr	x19, [sp, #16]
    5c4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c50:	17fff645 	b	3564 <fwp_closure_drop_push>
    5c54:	f9400bf3 	ldr	x19, [sp, #16]
    5c58:	aa0103e0 	mov	x0, x1
    5c5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c60:	17fff6b0 	b	3720 <fwp_closure_drop.part.0>
    5c64:	72003c5f 	tst	w2, #0xffff
    5c68:	54fffd00 	b.eq	5c08 <fwp_closure_drop+0x78>  // b.none
    5c6c:	f9400bf3 	ldr	x19, [sp, #16]
    5c70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c74:	d65f03c0 	ret
    5c78:	d65f03c0 	ret
    5c7c:	ca534660 	eor	x0, x19, x19, lsr #17
    5c80:	911540a5 	add	x5, x5, #0x550
    5c84:	ca402400 	eor	x0, x0, x0, lsr #9
    5c88:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5c8c:	f94a2400 	ldr	x0, [x0, #5192]
    5c90:	b5000080 	cbnz	x0, 5ca0 <fwp_closure_drop+0x110>
    5c94:	14000010 	b	5cd4 <fwp_closure_drop+0x144>
    5c98:	f9400800 	ldr	x0, [x0, #16]
    5c9c:	b40001c0 	cbz	x0, 5cd4 <fwp_closure_drop+0x144>
    5ca0:	f9400001 	ldr	x1, [x0]
    5ca4:	eb13003f 	cmp	x1, x19
    5ca8:	54ffff81 	b.ne	5c98 <fwp_closure_drop+0x108>  // b.any
    5cac:	f9400401 	ldr	x1, [x0, #8]
    5cb0:	d1000421 	sub	x1, x1, #0x1
    5cb4:	f9000401 	str	x1, [x0, #8]
    5cb8:	f103f83f 	cmp	x1, #0xfe
    5cbc:	54fffb61 	b.ne	5c28 <fwp_closure_drop+0x98>  // b.any
    5cc0:	aa1303e0 	mov	x0, x19
    5cc4:	97fffa0b 	bl	44f0 <fwp_rc_forget_slot>
    5cc8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ccc:	39000260 	strb	w0, [x19]
    5cd0:	17ffffd6 	b	5c28 <fwp_closure_drop+0x98>
    5cd4:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5cd8:	910ca000 	add	x0, x0, #0x328
    5cdc:	97fff609 	bl	3500 <fwp_trap>

0000000000005ce0 <fwp_owned_tape_release>:
    5ce0:	b4000940 	cbz	x0, 5e08 <fwp_owned_tape_release+0x128>
    5ce4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ce8:	910003fd 	mov	x29, sp
    5cec:	a90153f3 	stp	x19, x20, [sp, #16]
    5cf0:	aa0003f3 	mov	x19, x0
    5cf4:	f9400000 	ldr	x0, [x0]
    5cf8:	b4000060 	cbz	x0, 5d04 <fwp_owned_tape_release+0x24>
    5cfc:	f9400661 	ldr	x1, [x19, #8]
    5d00:	f9000401 	str	x1, [x0, #8]
    5d04:	f9400661 	ldr	x1, [x19, #8]
    5d08:	b4000041 	cbz	x1, 5d10 <fwp_owned_tape_release+0x30>
    5d0c:	f9000020 	str	x0, [x1]
    5d10:	f9400a60 	ldr	x0, [x19, #16]
    5d14:	f9403401 	ldr	x1, [x0, #104]
    5d18:	b40005c1 	cbz	x1, 5dd0 <fwp_owned_tape_release+0xf0>
    5d1c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5d20:	eb00005f 	cmp	x2, x0
    5d24:	540002ed 	b.le	5d80 <fwp_owned_tape_release+0xa0>
    5d28:	d2800014 	mov	x20, #0x0                   	// #0
    5d2c:	f90013f5 	str	x21, [sp, #32]
    5d30:	d2800015 	mov	x21, #0x0                   	// #0
    5d34:	d503201f 	nop
    5d38:	f9402260 	ldr	x0, [x19, #64]
    5d3c:	910006b5 	add	x21, x21, #0x1
    5d40:	f8746800 	ldr	x0, [x0, x20]
    5d44:	d63f0020 	blr	x1
    5d48:	f9402260 	ldr	x0, [x19, #64]
    5d4c:	f9400a61 	ldr	x1, [x19, #16]
    5d50:	8b140000 	add	x0, x0, x20
    5d54:	91004294 	add	x20, x20, #0x10
    5d58:	f9400400 	ldr	x0, [x0, #8]
    5d5c:	f9403421 	ldr	x1, [x1, #104]
    5d60:	d63f0020 	blr	x1
    5d64:	a9450261 	ldp	x1, x0, [x19, #80]
    5d68:	cb010000 	sub	x0, x0, x1
    5d6c:	eb15001f 	cmp	x0, x21
    5d70:	f9400a60 	ldr	x0, [x19, #16]
    5d74:	f9403401 	ldr	x1, [x0, #104]
    5d78:	54fffe0c 	b.gt	5d38 <fwp_owned_tape_release+0x58>
    5d7c:	f94013f5 	ldr	x21, [sp, #32]
    5d80:	f9403663 	ldr	x3, [x19, #104]
    5d84:	f9401262 	ldr	x2, [x19, #32]
    5d88:	f100007f 	cmp	x3, #0x0
    5d8c:	540001ed 	b.le	5dc8 <fwp_owned_tape_release+0xe8>
    5d90:	d2800014 	mov	x20, #0x0                   	// #0
    5d94:	d503201f 	nop
    5d98:	f9402660 	ldr	x0, [x19, #72]
    5d9c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5da0:	eb02001f 	cmp	x0, x2
    5da4:	540000c0 	b.eq	5dbc <fwp_owned_tape_release+0xdc>  // b.none
    5da8:	d63f0020 	blr	x1
    5dac:	f9400a60 	ldr	x0, [x19, #16]
    5db0:	f9401262 	ldr	x2, [x19, #32]
    5db4:	f9403663 	ldr	x3, [x19, #104]
    5db8:	f9403401 	ldr	x1, [x0, #104]
    5dbc:	91000694 	add	x20, x20, #0x1
    5dc0:	eb14007f 	cmp	x3, x20
    5dc4:	54fffeac 	b.gt	5d98 <fwp_owned_tape_release+0xb8>
    5dc8:	aa0203e0 	mov	x0, x2
    5dcc:	d63f0020 	blr	x1
    5dd0:	f9401660 	ldr	x0, [x19, #40]
    5dd4:	97ffff6f 	bl	5b90 <fwp_closure_drop>
    5dd8:	f9401a60 	ldr	x0, [x19, #48]
    5ddc:	97ffff6d 	bl	5b90 <fwp_closure_drop>
    5de0:	f9401e60 	ldr	x0, [x19, #56]
    5de4:	97ffff6b 	bl	5b90 <fwp_closure_drop>
    5de8:	f9402260 	ldr	x0, [x19, #64]
    5dec:	97fffa61 	bl	4770 <fwp_mem_free>
    5df0:	f9402660 	ldr	x0, [x19, #72]
    5df4:	97fffa5f 	bl	4770 <fwp_mem_free>
    5df8:	aa1303e0 	mov	x0, x19
    5dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e04:	17fffa5b 	b	4770 <fwp_mem_free>
    5e08:	d65f03c0 	ret
    5e0c:	d503201f 	nop

0000000000005e10 <fwp_tape_finish>:
    5e10:	d10203ff 	sub	sp, sp, #0x80
    5e14:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5e18:	f947f421 	ldr	x1, [x1, #4072]
    5e1c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5e20:	910103fd 	add	x29, sp, #0x40
    5e24:	a90553f3 	stp	x19, x20, [sp, #80]
    5e28:	a9065bf5 	stp	x21, x22, [sp, #96]
    5e2c:	a90763f7 	stp	x23, x24, [sp, #112]
    5e30:	f00000d8 	adrp	x24, 20000 <__data_start>
    5e34:	91010316 	add	x22, x24, #0x40
    5e38:	f9400022 	ldr	x2, [x1]
    5e3c:	f9001fe2 	str	x2, [sp, #56]
    5e40:	d2800002 	mov	x2, #0x0                   	// #0
    5e44:	910122c0 	add	x0, x22, #0x48
    5e48:	97fff50e 	bl	3280 <fwp_tape_buffers_dispose>
    5e4c:	f90042df 	str	xzr, [x22, #128]
    5e50:	f94022c0 	ldr	x0, [x22, #64]
    5e54:	f100001f 	cmp	x0, #0x0
    5e58:	5400030d 	b.le	5eb8 <fwp_tape_finish+0xa8>
    5e5c:	910003f7 	mov	x23, sp
    5e60:	d2800015 	mov	x21, #0x0                   	// #0
    5e64:	d2800014 	mov	x20, #0x0                   	// #0
    5e68:	f94002d3 	ldr	x19, [x22]
    5e6c:	91000694 	add	x20, x20, #0x1
    5e70:	8b150273 	add	x19, x19, x21
    5e74:	9101a2b5 	add	x21, x21, #0x68
    5e78:	aa1303e0 	mov	x0, x19
    5e7c:	97fff425 	bl	2f10 <fwp_tape_unlink_scope>
    5e80:	aa1703e0 	mov	x0, x23
    5e84:	f9401261 	ldr	x1, [x19, #32]
    5e88:	f90003e1 	str	x1, [sp]
    5e8c:	f9401a62 	ldr	x2, [x19, #48]
    5e90:	f9000be2 	str	x2, [sp, #16]
    5e94:	f9402261 	ldr	x1, [x19, #64]
    5e98:	f90013e1 	str	x1, [sp, #32]
    5e9c:	97fff4f9 	bl	3280 <fwp_tape_buffers_dispose>
    5ea0:	f9403260 	ldr	x0, [x19, #96]
    5ea4:	97ffff8f 	bl	5ce0 <fwp_owned_tape_release>
    5ea8:	f900327f 	str	xzr, [x19, #96]
    5eac:	f94022c0 	ldr	x0, [x22, #64]
    5eb0:	eb14001f 	cmp	x0, x20
    5eb4:	54fffdac 	b.gt	5e68 <fwp_tape_finish+0x58>
    5eb8:	f9402300 	ldr	x0, [x24, #64]
    5ebc:	91010313 	add	x19, x24, #0x40
    5ec0:	97fff27c 	bl	28b0 <free@plt>
    5ec4:	f900231f 	str	xzr, [x24, #64]
    5ec8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5ecc:	f947f400 	ldr	x0, [x0, #4072]
    5ed0:	f900227f 	str	xzr, [x19, #64]
    5ed4:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5ed8:	f9401fe2 	ldr	x2, [sp, #56]
    5edc:	f9400001 	ldr	x1, [x0]
    5ee0:	eb010042 	subs	x2, x2, x1
    5ee4:	d2800001 	mov	x1, #0x0                   	// #0
    5ee8:	540000e1 	b.ne	5f04 <fwp_tape_finish+0xf4>  // b.any
    5eec:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5ef0:	a94553f3 	ldp	x19, x20, [sp, #80]
    5ef4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5ef8:	a94763f7 	ldp	x23, x24, [sp, #112]
    5efc:	910203ff 	add	sp, sp, #0x80
    5f00:	d65f03c0 	ret
    5f04:	97fff23b 	bl	27f0 <__stack_chk_fail@plt>
    5f08:	d503201f 	nop
    5f0c:	d503201f 	nop

0000000000005f10 <fwp_tape_scope_release>:
    5f10:	d10243ff 	sub	sp, sp, #0x90
    5f14:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f18:	910103fd 	add	x29, sp, #0x40
    5f1c:	a90553f3 	stp	x19, x20, [sp, #80]
    5f20:	aa0003f4 	mov	x20, x0
    5f24:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5f28:	f947f400 	ldr	x0, [x0, #4072]
    5f2c:	b9400285 	ldr	w5, [x20]
    5f30:	f9400001 	ldr	x1, [x0]
    5f34:	f9001fe1 	str	x1, [sp, #56]
    5f38:	d2800001 	mov	x1, #0x0                   	// #0
    5f3c:	37f806c5 	tbnz	w5, #31, 6014 <fwp_tape_scope_release+0x104>
    5f40:	a90763f7 	stp	x23, x24, [sp, #112]
    5f44:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5f48:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5f4c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5f50:	f00000d3 	adrp	x19, 20000 <__data_start>
    5f54:	910003f7 	mov	x23, sp
    5f58:	91010273 	add	x19, x19, #0x40
    5f5c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5f60:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f64:	52800d16 	mov	w22, #0x68                  	// #104
    5f68:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5f6c:	f90043f9 	str	x25, [sp, #128]
    5f70:	14000006 	b	5f88 <fwp_tape_scope_release+0x78>
    5f74:	97fff4c3 	bl	3280 <fwp_tape_buffers_dispose>
    5f78:	aa1903e0 	mov	x0, x25
    5f7c:	97ffff59 	bl	5ce0 <fwp_owned_tape_release>
    5f80:	b9400285 	ldr	w5, [x20]
    5f84:	37f80425 	tbnz	w5, #31, 6008 <fwp_tape_scope_release+0xf8>
    5f88:	f9400266 	ldr	x6, [x19]
    5f8c:	9b367ca5 	smull	x5, w5, w22
    5f90:	8b0500c0 	add	x0, x6, x5
    5f94:	97fff3df 	bl	2f10 <fwp_tape_unlink_scope>
    5f98:	ad410001 	ldp	q1, q0, [x0, #32]
    5f9c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5fa0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5fa4:	f9400c03 	ldr	x3, [x0, #24]
    5fa8:	ad0003e1 	stp	q1, q0, [sp]
    5fac:	b86568c1 	ldr	w1, [x6, x5]
    5fb0:	a9440804 	ldp	x4, x2, [x0, #64]
    5fb4:	b900041f 	str	wzr, [x0, #4]
    5fb8:	f9403019 	ldr	x25, [x0, #96]
    5fbc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5fc0:	f9000c1f 	str	xzr, [x0, #24]
    5fc4:	a9020fe4 	stp	x4, x3, [sp, #32]
    5fc8:	f9001be2 	str	x2, [sp, #48]
    5fcc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5fd0:	f900301f 	str	xzr, [x0, #96]
    5fd4:	6b15003f 	cmp	w1, w21
    5fd8:	540000e8 	b.hi	5ff4 <fwp_tape_scope_release+0xe4>  // b.pmore
    5fdc:	9343fca5 	asr	x5, x5, #3
    5fe0:	f9404e60 	ldr	x0, [x19, #152]
    5fe4:	9b187ca5 	mul	x5, x5, x24
    5fe8:	eb0000bf 	cmp	x5, x0
    5fec:	5400004a 	b.ge	5ff4 <fwp_tape_scope_release+0xe4>  // b.tcont
    5ff0:	f9004e65 	str	x5, [x19, #152]
    5ff4:	aa1703e0 	mov	x0, x23
    5ff8:	b5fffbf9 	cbnz	x25, 5f74 <fwp_tape_scope_release+0x64>
    5ffc:	97fff821 	bl	4080 <fwp_tape_buffers_release>
    6000:	b9400285 	ldr	w5, [x20]
    6004:	36fffc25 	tbz	w5, #31, 5f88 <fwp_tape_scope_release+0x78>
    6008:	a9465bf5 	ldp	x21, x22, [sp, #96]
    600c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6010:	f94043f9 	ldr	x25, [sp, #128]
    6014:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6018:	f947f400 	ldr	x0, [x0, #4072]
    601c:	f9401fe2 	ldr	x2, [sp, #56]
    6020:	f9400001 	ldr	x1, [x0]
    6024:	eb010042 	subs	x2, x2, x1
    6028:	d2800001 	mov	x1, #0x0                   	// #0
    602c:	540000a1 	b.ne	6040 <fwp_tape_scope_release+0x130>  // b.any
    6030:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6034:	a94553f3 	ldp	x19, x20, [sp, #80]
    6038:	910243ff 	add	sp, sp, #0x90
    603c:	d65f03c0 	ret
    6040:	a9065bf5 	stp	x21, x22, [sp, #96]
    6044:	a90763f7 	stp	x23, x24, [sp, #112]
    6048:	f90043f9 	str	x25, [sp, #128]
    604c:	97fff1e9 	bl	27f0 <__stack_chk_fail@plt>

0000000000006050 <fwp_task_dispose>:
    6050:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6054:	910003fd 	mov	x29, sp
    6058:	f9000bf3 	str	x19, [sp, #16]
    605c:	aa0003f3 	mov	x19, x0
    6060:	39414000 	ldrb	w0, [x0, #80]
    6064:	36000720 	tbz	w0, #0, 6148 <fwp_task_dispose+0xf8>
    6068:	f9400a60 	ldr	x0, [x19, #16]
    606c:	b50006e0 	cbnz	x0, 6148 <fwp_task_dispose+0xf8>
    6070:	a9478660 	ldp	x0, x1, [x19, #120]
    6074:	39014e7f 	strb	wzr, [x19, #83]
    6078:	f9003e7f 	str	xzr, [x19, #120]
    607c:	f100003f 	cmp	x1, #0x0
    6080:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6084:	54000040 	b.eq	608c <fwp_task_dispose+0x3c>  // b.none
    6088:	d63f0020 	blr	x1
    608c:	f9405660 	ldr	x0, [x19, #168]
    6090:	97fff9b8 	bl	4770 <fwp_mem_free>
    6094:	f900567f 	str	xzr, [x19, #168]
    6098:	b9405e60 	ldr	w0, [x19, #92]
    609c:	7100041f 	cmp	w0, #0x1
    60a0:	54000420 	b.eq	6124 <fwp_task_dispose+0xd4>  // b.none
    60a4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    60a8:	91154042 	add	x2, x2, #0x550
    60ac:	f949d840 	ldr	x0, [x2, #5040]
    60b0:	f949ec41 	ldr	x1, [x2, #5080]
    60b4:	cb000260 	sub	x0, x19, x0
    60b8:	eb01401f 	cmp	x0, x1, lsl #16
    60bc:	540002e2 	b.cs	6118 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    60c0:	d350fc01 	lsr	x1, x0, #16
    60c4:	f949fc44 	ldr	x4, [x2, #5112]
    60c8:	8b010821 	add	x1, x1, x1, lsl #2
    60cc:	d37df021 	lsl	x1, x1, #3
    60d0:	8b010083 	add	x3, x4, x1
    60d4:	f9401062 	ldr	x2, [x3, #32]
    60d8:	b4000202 	cbz	x2, 6118 <fwp_task_dispose+0xc8>
    60dc:	38616881 	ldrb	w1, [x4, x1]
    60e0:	7100083f 	cmp	w1, #0x2
    60e4:	54000280 	b.eq	6134 <fwp_task_dispose+0xe4>  // b.none
    60e8:	7100043f 	cmp	w1, #0x1
    60ec:	54000161 	b.ne	6118 <fwp_task_dispose+0xc8>  // b.any
    60f0:	29430464 	ldp	w4, w1, [x3, #24]
    60f4:	92403c00 	and	x0, x0, #0xffff
    60f8:	9b047c00 	mul	x0, x0, x4
    60fc:	d360fc00 	lsr	x0, x0, #32
    6100:	eb01001f 	cmp	x0, x1
    6104:	540000a2 	b.cs	6118 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6108:	8b000042 	add	x2, x2, x0
    610c:	39400040 	ldrb	w0, [x2]
    6110:	7100041f 	cmp	w0, #0x1
    6114:	54000080 	b.eq	6124 <fwp_task_dispose+0xd4>  // b.none
    6118:	f9400bf3 	ldr	x19, [sp, #16]
    611c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6120:	d65f03c0 	ret
    6124:	aa1303e0 	mov	x0, x19
    6128:	f9400bf3 	ldr	x19, [sp, #16]
    612c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6130:	17fff990 	b	4770 <fwp_mem_free>
    6134:	72003c1f 	tst	w0, #0xffff
    6138:	54fffea0 	b.eq	610c <fwp_task_dispose+0xbc>  // b.none
    613c:	f9400bf3 	ldr	x19, [sp, #16]
    6140:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6144:	d65f03c0 	ret
    6148:	97fff1be 	bl	2840 <abort@plt>
    614c:	d503201f 	nop

0000000000006150 <fwp_free_zombie>:
    6150:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6154:	910003fd 	mov	x29, sp
    6158:	a90153f3 	stp	x19, x20, [sp, #16]
    615c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6160:	91010281 	add	x1, x20, #0x40
    6164:	f9405033 	ldr	x19, [x1, #160]
    6168:	b4000333 	cbz	x19, 61cc <fwp_free_zombie+0x7c>
    616c:	f9400820 	ldr	x0, [x1, #16]
    6170:	eb00027f 	cmp	x19, x0
    6174:	540002c0 	b.eq	61cc <fwp_free_zombie+0x7c>  // b.none
    6178:	b940a822 	ldr	w2, [x1, #168]
    617c:	f9400a60 	ldr	x0, [x19, #16]
    6180:	7100fc5f 	cmp	w2, #0x3f
    6184:	5400078c 	b.gt	6274 <fwp_free_zombie+0x124>
    6188:	9102c023 	add	x3, x1, #0xb0
    618c:	11000444 	add	w4, w2, #0x1
    6190:	b900a824 	str	w4, [x1, #168]
    6194:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6198:	f822d860 	str	x0, [x3, w2, sxtw #3]
    619c:	a9530261 	ldp	x1, x0, [x19, #304]
    61a0:	b4000741 	cbz	x1, 6288 <fwp_free_zombie+0x138>
    61a4:	f9009c20 	str	x0, [x1, #312]
    61a8:	b4000040 	cbz	x0, 61b0 <fwp_free_zombie+0x60>
    61ac:	f9009801 	str	x1, [x0, #304]
    61b0:	91010294 	add	x20, x20, #0x40
    61b4:	b9405e60 	ldr	w0, [x19, #92]
    61b8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    61bc:	f900529f 	str	xzr, [x20, #160]
    61c0:	34000140 	cbz	w0, 61e8 <fwp_free_zombie+0x98>
    61c4:	7100041f 	cmp	w0, #0x1
    61c8:	54000080 	b.eq	61d8 <fwp_free_zombie+0x88>  // b.none
    61cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    61d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d4:	d65f03c0 	ret
    61d8:	aa1303e0 	mov	x0, x19
    61dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    61e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61e4:	17ffff9b 	b	6050 <fwp_task_dispose>
    61e8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc90>
    61ec:	91154082 	add	x2, x4, #0x550
    61f0:	f949d841 	ldr	x1, [x2, #5040]
    61f4:	f949ec40 	ldr	x0, [x2, #5080]
    61f8:	cb010261 	sub	x1, x19, x1
    61fc:	eb00403f 	cmp	x1, x0, lsl #16
    6200:	54fffe62 	b.cs	61cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6204:	d350fc20 	lsr	x0, x1, #16
    6208:	f949fc43 	ldr	x3, [x2, #5112]
    620c:	8b000800 	add	x0, x0, x0, lsl #2
    6210:	d37df000 	lsl	x0, x0, #3
    6214:	8b000062 	add	x2, x3, x0
    6218:	f9401054 	ldr	x20, [x2, #32]
    621c:	b4fffd94 	cbz	x20, 61cc <fwp_free_zombie+0x7c>
    6220:	38606860 	ldrb	w0, [x3, x0]
    6224:	7100081f 	cmp	w0, #0x2
    6228:	54000360 	b.eq	6294 <fwp_free_zombie+0x144>  // b.none
    622c:	7100041f 	cmp	w0, #0x1
    6230:	54fffce1 	b.ne	61cc <fwp_free_zombie+0x7c>  // b.any
    6234:	29430043 	ldp	w3, w0, [x2, #24]
    6238:	92403c21 	and	x1, x1, #0xffff
    623c:	9b037c21 	mul	x1, x1, x3
    6240:	d360fc21 	lsr	x1, x1, #32
    6244:	eb00003f 	cmp	x1, x0
    6248:	54fffc22 	b.cs	61cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    624c:	8b010294 	add	x20, x20, x1
    6250:	39400280 	ldrb	w0, [x20]
    6254:	34fffbc0 	cbz	w0, 61cc <fwp_free_zombie+0x7c>
    6258:	7100041f 	cmp	w0, #0x1
    625c:	54fffbe0 	b.eq	61d8 <fwp_free_zombie+0x88>  // b.none
    6260:	7103fc1f 	cmp	w0, #0xff
    6264:	540001e0 	b.eq	62a0 <fwp_free_zombie+0x150>  // b.none
    6268:	51000400 	sub	w0, w0, #0x1
    626c:	39000280 	strb	w0, [x20]
    6270:	17ffffd7 	b	61cc <fwp_free_zombie+0x7c>
    6274:	f9400e61 	ldr	x1, [x19, #24]
    6278:	97fff1a6 	bl	2910 <munmap@plt>
    627c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6280:	a9530261 	ldp	x1, x0, [x19, #304]
    6284:	b5fff901 	cbnz	x1, 61a4 <fwp_free_zombie+0x54>
    6288:	91010282 	add	x2, x20, #0x40
    628c:	f9015840 	str	x0, [x2, #688]
    6290:	17ffffc6 	b	61a8 <fwp_free_zombie+0x58>
    6294:	72003c3f 	tst	w1, #0xffff
    6298:	54fff9a1 	b.ne	61cc <fwp_free_zombie+0x7c>  // b.any
    629c:	17ffffed 	b	6250 <fwp_free_zombie+0x100>
    62a0:	ca544680 	eor	x0, x20, x20, lsr #17
    62a4:	91154084 	add	x4, x4, #0x550
    62a8:	ca402400 	eor	x0, x0, x0, lsr #9
    62ac:	8b200c80 	add	x0, x4, w0, uxtb #3
    62b0:	f94a2400 	ldr	x0, [x0, #5192]
    62b4:	b5000080 	cbnz	x0, 62c4 <fwp_free_zombie+0x174>
    62b8:	14000010 	b	62f8 <fwp_free_zombie+0x1a8>
    62bc:	f9400800 	ldr	x0, [x0, #16]
    62c0:	b40001c0 	cbz	x0, 62f8 <fwp_free_zombie+0x1a8>
    62c4:	f9400001 	ldr	x1, [x0]
    62c8:	eb14003f 	cmp	x1, x20
    62cc:	54ffff81 	b.ne	62bc <fwp_free_zombie+0x16c>  // b.any
    62d0:	f9400401 	ldr	x1, [x0, #8]
    62d4:	d1000421 	sub	x1, x1, #0x1
    62d8:	f9000401 	str	x1, [x0, #8]
    62dc:	f103f83f 	cmp	x1, #0xfe
    62e0:	54fff761 	b.ne	61cc <fwp_free_zombie+0x7c>  // b.any
    62e4:	aa1403e0 	mov	x0, x20
    62e8:	97fff882 	bl	44f0 <fwp_rc_forget_slot>
    62ec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62f0:	39000280 	strb	w0, [x20]
    62f4:	17ffffb6 	b	61cc <fwp_free_zombie+0x7c>
    62f8:	f0000020 	adrp	x0, d000 <__modti3+0x320>
    62fc:	910ca000 	add	x0, x0, #0x328
    6300:	97fff480 	bl	3500 <fwp_trap>

0000000000006304 <fwp_block>:
    6304:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6308:	910003fd 	mov	x29, sp
    630c:	a90153f3 	stp	x19, x20, [sp, #16]
    6310:	d00000d3 	adrp	x19, 20000 <__data_start>
    6314:	91010274 	add	x20, x19, #0x40
    6318:	f9401a82 	ldr	x2, [x20, #48]
    631c:	b4000622 	cbz	x2, 63e0 <fwp_block+0xdc>
    6320:	91010261 	add	x1, x19, #0x40
    6324:	f9408040 	ldr	x0, [x2, #256]
    6328:	f9001820 	str	x0, [x1, #48]
    632c:	b4000680 	cbz	x0, 63fc <fwp_block+0xf8>
    6330:	91010263 	add	x3, x19, #0x40
    6334:	3901505f 	strb	wzr, [x2, #84]
    6338:	f9400864 	ldr	x4, [x3, #16]
    633c:	eb02009f 	cmp	x4, x2
    6340:	54000440 	b.eq	63c8 <fwp_block+0xc4>  // b.none
    6344:	f9415c65 	ldr	x5, [x3, #696]
    6348:	f9000862 	str	x2, [x3, #16]
    634c:	f9400441 	ldr	x1, [x2, #8]
    6350:	f9004885 	str	x5, [x4, #144]
    6354:	f9416065 	ldr	x5, [x3, #704]
    6358:	f9004c85 	str	x5, [x4, #152]
    635c:	f9416465 	ldr	x5, [x3, #712]
    6360:	f9005085 	str	x5, [x4, #160]
    6364:	f9416865 	ldr	x5, [x3, #720]
    6368:	f9005485 	str	x5, [x4, #168]
    636c:	f9416c65 	ldr	x5, [x3, #728]
    6370:	f9005885 	str	x5, [x4, #176]
    6374:	f9417065 	ldr	x5, [x3, #736]
    6378:	f9005c85 	str	x5, [x4, #184]
    637c:	f9417465 	ldr	x5, [x3, #744]
    6380:	f9006085 	str	x5, [x4, #192]
    6384:	f9400480 	ldr	x0, [x4, #8]
    6388:	f9404844 	ldr	x4, [x2, #144]
    638c:	f9015c64 	str	x4, [x3, #696]
    6390:	f9404c44 	ldr	x4, [x2, #152]
    6394:	f9016064 	str	x4, [x3, #704]
    6398:	f9405044 	ldr	x4, [x2, #160]
    639c:	f9016464 	str	x4, [x3, #712]
    63a0:	f9405444 	ldr	x4, [x2, #168]
    63a4:	f9016864 	str	x4, [x3, #720]
    63a8:	f9405844 	ldr	x4, [x2, #176]
    63ac:	f9016c64 	str	x4, [x3, #728]
    63b0:	a94b8844 	ldp	x4, x2, [x2, #184]
    63b4:	f9017064 	str	x4, [x3, #736]
    63b8:	f9017462 	str	x2, [x3, #744]
    63bc:	97fff125 	bl	2850 <swapcontext@plt>
    63c0:	97ffff64 	bl	6150 <fwp_free_zombie>
    63c4:	d503201f 	nop
    63c8:	91010260 	add	x0, x19, #0x40
    63cc:	b942f000 	ldr	w0, [x0, #752]
    63d0:	340001a0 	cbz	w0, 6404 <fwp_block+0x100>
    63d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    63d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63dc:	d65f03c0 	ret
    63e0:	97fff770 	bl	41a0 <fwp_poll_events>
    63e4:	f9401a82 	ldr	x2, [x20, #48]
    63e8:	b4ffffc2 	cbz	x2, 63e0 <fwp_block+0xdc>
    63ec:	91010261 	add	x1, x19, #0x40
    63f0:	f9408040 	ldr	x0, [x2, #256]
    63f4:	f9001820 	str	x0, [x1, #48]
    63f8:	b5fff9c0 	cbnz	x0, 6330 <fwp_block+0x2c>
    63fc:	f900143f 	str	xzr, [x1, #40]
    6400:	17ffffcc 	b	6330 <fwp_block+0x2c>
    6404:	f0000020 	adrp	x0, d000 <__modti3+0x320>
    6408:	91116000 	add	x0, x0, #0x458
    640c:	97fff15d 	bl	2980 <getenv@plt>
    6410:	5284e202 	mov	w2, #0x2710                	// #10000
    6414:	b4000060 	cbz	x0, 6420 <fwp_block+0x11c>
    6418:	39400001 	ldrb	w1, [x0]
    641c:	350000c1 	cbnz	w1, 6434 <fwp_block+0x130>
    6420:	91010273 	add	x19, x19, #0x40
    6424:	b902f262 	str	w2, [x19, #752]
    6428:	a94153f3 	ldp	x19, x20, [sp, #16]
    642c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6430:	d65f03c0 	ret
    6434:	52800142 	mov	w2, #0xa                   	// #10
    6438:	d2800001 	mov	x1, #0x0                   	// #0
    643c:	97fff0a1 	bl	26c0 <strtoll@plt>
    6440:	d1000403 	sub	x3, x0, #0x1
    6444:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6448:	eb02007f 	cmp	x3, x2
    644c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6450:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6454:	17fffff3 	b	6420 <fwp_block+0x11c>
    6458:	d503201f 	nop
    645c:	d503201f 	nop

0000000000006460 <fwp_drop4>:
    6460:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6464:	910003fd 	mov	x29, sp
    6468:	a90153f3 	stp	x19, x20, [sp, #16]
    646c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc90>
    6470:	f90013f5 	str	x21, [sp, #32]
    6474:	91154275 	add	x21, x19, #0x550
    6478:	f949daa1 	ldr	x1, [x21, #5040]
    647c:	f949eea2 	ldr	x2, [x21, #5080]
    6480:	cb010001 	sub	x1, x0, x1
    6484:	eb02403f 	cmp	x1, x2, lsl #16
    6488:	54000382 	b.cs	64f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    648c:	d350fc22 	lsr	x2, x1, #16
    6490:	f949fea3 	ldr	x3, [x21, #5112]
    6494:	8b020842 	add	x2, x2, x2, lsl #2
    6498:	d37df042 	lsl	x2, x2, #3
    649c:	8b020064 	add	x4, x3, x2
    64a0:	f9401094 	ldr	x20, [x4, #32]
    64a4:	b40002b4 	cbz	x20, 64f8 <fwp_drop4+0x98>
    64a8:	38626862 	ldrb	w2, [x3, x2]
    64ac:	7100085f 	cmp	w2, #0x2
    64b0:	540007a0 	b.eq	65a4 <fwp_drop4+0x144>  // b.none
    64b4:	7100045f 	cmp	w2, #0x1
    64b8:	54000201 	b.ne	64f8 <fwp_drop4+0x98>  // b.any
    64bc:	29430885 	ldp	w5, w2, [x4, #24]
    64c0:	92403c21 	and	x1, x1, #0xffff
    64c4:	9b057c21 	mul	x1, x1, x5
    64c8:	d360fc21 	lsr	x1, x1, #32
    64cc:	eb02003f 	cmp	x1, x2
    64d0:	54000142 	b.cs	64f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    64d4:	8b010294 	add	x20, x20, x1
    64d8:	39400281 	ldrb	w1, [x20]
    64dc:	340000e1 	cbz	w1, 64f8 <fwp_drop4+0x98>
    64e0:	7100043f 	cmp	w1, #0x1
    64e4:	54000120 	b.eq	6508 <fwp_drop4+0xa8>  // b.none
    64e8:	7103fc3f 	cmp	w1, #0xff
    64ec:	540007c0 	b.eq	65e4 <fwp_drop4+0x184>  // b.none
    64f0:	51000421 	sub	w1, w1, #0x1
    64f4:	39000281 	strb	w1, [x20]
    64f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    64fc:	f94013f5 	ldr	x21, [sp, #32]
    6500:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6504:	d65f03c0 	ret
    6508:	f9400001 	ldr	x1, [x0]
    650c:	b7f80581 	tbnz	x1, #63, 65bc <fwp_drop4+0x15c>
    6510:	91154273 	add	x19, x19, #0x550
    6514:	f949da61 	ldr	x1, [x19, #5040]
    6518:	f949ee62 	ldr	x2, [x19, #5080]
    651c:	cb010001 	sub	x1, x0, x1
    6520:	eb02403f 	cmp	x1, x2, lsl #16
    6524:	54fffea2 	b.cs	64f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6528:	d350fc22 	lsr	x2, x1, #16
    652c:	8b020842 	add	x2, x2, x2, lsl #2
    6530:	d37df042 	lsl	x2, x2, #3
    6534:	8b020065 	add	x5, x3, x2
    6538:	f94010a4 	ldr	x4, [x5, #32]
    653c:	b4fffde4 	cbz	x4, 64f8 <fwp_drop4+0x98>
    6540:	38626862 	ldrb	w2, [x3, x2]
    6544:	7100085f 	cmp	w2, #0x2
    6548:	54000220 	b.eq	658c <fwp_drop4+0x12c>  // b.none
    654c:	7100045f 	cmp	w2, #0x1
    6550:	54fffd41 	b.ne	64f8 <fwp_drop4+0x98>  // b.any
    6554:	294308a3 	ldp	w3, w2, [x5, #24]
    6558:	92403c21 	and	x1, x1, #0xffff
    655c:	9b037c21 	mul	x1, x1, x3
    6560:	d360fc21 	lsr	x1, x1, #32
    6564:	eb02003f 	cmp	x1, x2
    6568:	54fffc82 	b.cs	64f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    656c:	8b010084 	add	x4, x4, x1
    6570:	39400081 	ldrb	w1, [x4]
    6574:	7100043f 	cmp	w1, #0x1
    6578:	54fffc01 	b.ne	64f8 <fwp_drop4+0x98>  // b.any
    657c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6580:	f94013f5 	ldr	x21, [sp, #32]
    6584:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6588:	17fff87a 	b	4770 <fwp_mem_free>
    658c:	72003c3f 	tst	w1, #0xffff
    6590:	54ffff00 	b.eq	6570 <fwp_drop4+0x110>  // b.none
    6594:	a94153f3 	ldp	x19, x20, [sp, #16]
    6598:	f94013f5 	ldr	x21, [sp, #32]
    659c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65a0:	d65f03c0 	ret
    65a4:	72003c3f 	tst	w1, #0xffff
    65a8:	54fff980 	b.eq	64d8 <fwp_drop4+0x78>  // b.none
    65ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    65b0:	f94013f5 	ldr	x21, [sp, #32]
    65b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65b8:	d65f03c0 	ret
    65bc:	f9400414 	ldr	x20, [x0, #8]
    65c0:	97fffbed 	bl	5574 <fwp_rc_free_arr>
    65c4:	91154260 	add	x0, x19, #0x550
    65c8:	f949d801 	ldr	x1, [x0, #5040]
    65cc:	f949ec00 	ldr	x0, [x0, #5080]
    65d0:	cb010281 	sub	x1, x20, x1
    65d4:	eb00403f 	cmp	x1, x0, lsl #16
    65d8:	54fff902 	b.cs	64f8 <fwp_drop4+0x98>  // b.hs, b.nlast
    65dc:	aa1403e0 	mov	x0, x20
    65e0:	17ffffab 	b	648c <fwp_drop4+0x2c>
    65e4:	ca544680 	eor	x0, x20, x20, lsr #17
    65e8:	91154273 	add	x19, x19, #0x550
    65ec:	ca402400 	eor	x0, x0, x0, lsr #9
    65f0:	8b200e60 	add	x0, x19, w0, uxtb #3
    65f4:	f94a2400 	ldr	x0, [x0, #5192]
    65f8:	b5000080 	cbnz	x0, 6608 <fwp_drop4+0x1a8>
    65fc:	14000010 	b	663c <fwp_drop4+0x1dc>
    6600:	f9400800 	ldr	x0, [x0, #16]
    6604:	b40001c0 	cbz	x0, 663c <fwp_drop4+0x1dc>
    6608:	f9400001 	ldr	x1, [x0]
    660c:	eb14003f 	cmp	x1, x20
    6610:	54ffff81 	b.ne	6600 <fwp_drop4+0x1a0>  // b.any
    6614:	f9400401 	ldr	x1, [x0, #8]
    6618:	d1000421 	sub	x1, x1, #0x1
    661c:	f9000401 	str	x1, [x0, #8]
    6620:	f103f83f 	cmp	x1, #0xfe
    6624:	54fff6a1 	b.ne	64f8 <fwp_drop4+0x98>  // b.any
    6628:	aa1403e0 	mov	x0, x20
    662c:	97fff7b1 	bl	44f0 <fwp_rc_forget_slot>
    6630:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6634:	39000280 	strb	w0, [x20]
    6638:	17ffffb0 	b	64f8 <fwp_drop4+0x98>
    663c:	f0000020 	adrp	x0, d000 <__modti3+0x320>
    6640:	910ca000 	add	x0, x0, #0x328
    6644:	97fff3af 	bl	3500 <fwp_trap>
    6648:	d503201f 	nop
    664c:	d503201f 	nop

0000000000006650 <fwp_caps161>:
    6650:	34000041 	cbz	w1, 6658 <fwp_caps161+0x8>
    6654:	d65f03c0 	ret
    6658:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc90>
    665c:	91154063 	add	x3, x3, #0x550
    6660:	f949d861 	ldr	x1, [x3, #5040]
    6664:	f949ec62 	ldr	x2, [x3, #5080]
    6668:	cb010001 	sub	x1, x0, x1
    666c:	eb02403f 	cmp	x1, x2, lsl #16
    6670:	54ffff22 	b.cs	6654 <fwp_caps161+0x4>  // b.hs, b.nlast
    6674:	d350fc22 	lsr	x2, x1, #16
    6678:	f949fc65 	ldr	x5, [x3, #5112]
    667c:	8b020842 	add	x2, x2, x2, lsl #2
    6680:	d37df042 	lsl	x2, x2, #3
    6684:	8b0200a4 	add	x4, x5, x2
    6688:	f9401083 	ldr	x3, [x4, #32]
    668c:	b4fffe43 	cbz	x3, 6654 <fwp_caps161+0x4>
    6690:	386268a2 	ldrb	w2, [x5, x2]
    6694:	7100085f 	cmp	w2, #0x2
    6698:	540001c0 	b.eq	66d0 <fwp_caps161+0x80>  // b.none
    669c:	7100045f 	cmp	w2, #0x1
    66a0:	54fffda1 	b.ne	6654 <fwp_caps161+0x4>  // b.any
    66a4:	29430885 	ldp	w5, w2, [x4, #24]
    66a8:	92403c21 	and	x1, x1, #0xffff
    66ac:	9b057c21 	mul	x1, x1, x5
    66b0:	d360fc21 	lsr	x1, x1, #32
    66b4:	eb02003f 	cmp	x1, x2
    66b8:	54fffce2 	b.cs	6654 <fwp_caps161+0x4>  // b.hs, b.nlast
    66bc:	8b010063 	add	x3, x3, x1
    66c0:	39400061 	ldrb	w1, [x3]
    66c4:	7100043f 	cmp	w1, #0x1
    66c8:	54fffc61 	b.ne	6654 <fwp_caps161+0x4>  // b.any
    66cc:	17fff829 	b	4770 <fwp_mem_free>
    66d0:	72003c3f 	tst	w1, #0xffff
    66d4:	54ffff60 	b.eq	66c0 <fwp_caps161+0x70>  // b.none
    66d8:	d65f03c0 	ret
    66dc:	d503201f 	nop

00000000000066e0 <fwp_args23>:
    66e0:	7100003f 	cmp	w1, #0x0
    66e4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    66e8:	54000041 	b.ne	66f0 <fwp_args23+0x10>  // b.any
    66ec:	d65f03c0 	ret
    66f0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    66f4:	91154042 	add	x2, x2, #0x550
    66f8:	f9400001 	ldr	x1, [x0]
    66fc:	f949d843 	ldr	x3, [x2, #5040]
    6700:	f949ec40 	ldr	x0, [x2, #5080]
    6704:	cb030021 	sub	x1, x1, x3
    6708:	eb00403f 	cmp	x1, x0, lsl #16
    670c:	54ffff02 	b.cs	66ec <fwp_args23+0xc>  // b.hs, b.nlast
    6710:	d350fc20 	lsr	x0, x1, #16
    6714:	f949fc44 	ldr	x4, [x2, #5112]
    6718:	8b000800 	add	x0, x0, x0, lsl #2
    671c:	d37df002 	lsl	x2, x0, #3
    6720:	8b020083 	add	x3, x4, x2
    6724:	f9401060 	ldr	x0, [x3, #32]
    6728:	b4fffe20 	cbz	x0, 66ec <fwp_args23+0xc>
    672c:	38626882 	ldrb	w2, [x4, x2]
    6730:	7100085f 	cmp	w2, #0x2
    6734:	54000220 	b.eq	6778 <fwp_args23+0x98>  // b.none
    6738:	7100045f 	cmp	w2, #0x1
    673c:	54fffd81 	b.ne	66ec <fwp_args23+0xc>  // b.any
    6740:	29430864 	ldp	w4, w2, [x3, #24]
    6744:	92403c21 	and	x1, x1, #0xffff
    6748:	9b047c21 	mul	x1, x1, x4
    674c:	d360fc21 	lsr	x1, x1, #32
    6750:	eb02003f 	cmp	x1, x2
    6754:	54fffcc2 	b.cs	66ec <fwp_args23+0xc>  // b.hs, b.nlast
    6758:	8b010000 	add	x0, x0, x1
    675c:	39400001 	ldrb	w1, [x0]
    6760:	34fffc61 	cbz	w1, 66ec <fwp_args23+0xc>
    6764:	7103f43f 	cmp	w1, #0xfd
    6768:	540000e8 	b.hi	6784 <fwp_args23+0xa4>  // b.pmore
    676c:	11000421 	add	w1, w1, #0x1
    6770:	39000001 	strb	w1, [x0]
    6774:	d65f03c0 	ret
    6778:	72003c3f 	tst	w1, #0xffff
    677c:	54ffff00 	b.eq	675c <fwp_args23+0x7c>  // b.none
    6780:	d65f03c0 	ret
    6784:	17fff714 	b	43d4 <fwp_rc_wide_dup>
    6788:	d503201f 	nop
    678c:	d503201f 	nop

0000000000006790 <fwp_args12>:
    6790:	7100003f 	cmp	w1, #0x0
    6794:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6798:	54000041 	b.ne	67a0 <fwp_args12+0x10>  // b.any
    679c:	d65f03c0 	ret
    67a0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    67a4:	91154042 	add	x2, x2, #0x550
    67a8:	f9400001 	ldr	x1, [x0]
    67ac:	f949d843 	ldr	x3, [x2, #5040]
    67b0:	f949ec40 	ldr	x0, [x2, #5080]
    67b4:	cb030021 	sub	x1, x1, x3
    67b8:	eb00403f 	cmp	x1, x0, lsl #16
    67bc:	54ffff02 	b.cs	679c <fwp_args12+0xc>  // b.hs, b.nlast
    67c0:	d350fc20 	lsr	x0, x1, #16
    67c4:	f949fc44 	ldr	x4, [x2, #5112]
    67c8:	8b000800 	add	x0, x0, x0, lsl #2
    67cc:	d37df002 	lsl	x2, x0, #3
    67d0:	8b020083 	add	x3, x4, x2
    67d4:	f9401060 	ldr	x0, [x3, #32]
    67d8:	b4fffe20 	cbz	x0, 679c <fwp_args12+0xc>
    67dc:	38626882 	ldrb	w2, [x4, x2]
    67e0:	7100085f 	cmp	w2, #0x2
    67e4:	54000220 	b.eq	6828 <fwp_args12+0x98>  // b.none
    67e8:	7100045f 	cmp	w2, #0x1
    67ec:	54fffd81 	b.ne	679c <fwp_args12+0xc>  // b.any
    67f0:	29430864 	ldp	w4, w2, [x3, #24]
    67f4:	92403c21 	and	x1, x1, #0xffff
    67f8:	9b047c21 	mul	x1, x1, x4
    67fc:	d360fc21 	lsr	x1, x1, #32
    6800:	eb02003f 	cmp	x1, x2
    6804:	54fffcc2 	b.cs	679c <fwp_args12+0xc>  // b.hs, b.nlast
    6808:	8b010000 	add	x0, x0, x1
    680c:	39400001 	ldrb	w1, [x0]
    6810:	34fffc61 	cbz	w1, 679c <fwp_args12+0xc>
    6814:	7103f43f 	cmp	w1, #0xfd
    6818:	540000e8 	b.hi	6834 <fwp_args12+0xa4>  // b.pmore
    681c:	11000421 	add	w1, w1, #0x1
    6820:	39000001 	strb	w1, [x0]
    6824:	d65f03c0 	ret
    6828:	72003c3f 	tst	w1, #0xffff
    682c:	54ffff00 	b.eq	680c <fwp_args12+0x7c>  // b.none
    6830:	d65f03c0 	ret
    6834:	17fff6e8 	b	43d4 <fwp_rc_wide_dup>
    6838:	d503201f 	nop
    683c:	d503201f 	nop

0000000000006840 <fwp_caps12>:
    6840:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6844:	910003fd 	mov	x29, sp
    6848:	f9000bf3 	str	x19, [sp, #16]
    684c:	aa0003f3 	mov	x19, x0
    6850:	b9400400 	ldr	w0, [x0, #4]
    6854:	340004a0 	cbz	w0, 68e8 <fwp_caps12+0xa8>
    6858:	f9400660 	ldr	x0, [x19, #8]
    685c:	350004e1 	cbnz	w1, 68f8 <fwp_caps12+0xb8>
    6860:	97fffc70 	bl	5a20 <fwp_drop0>
    6864:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6868:	91154042 	add	x2, x2, #0x550
    686c:	f949d840 	ldr	x0, [x2, #5040]
    6870:	f949ec41 	ldr	x1, [x2, #5080]
    6874:	cb000260 	sub	x0, x19, x0
    6878:	eb01401f 	cmp	x0, x1, lsl #16
    687c:	54000382 	b.cs	68ec <fwp_caps12+0xac>  // b.hs, b.nlast
    6880:	d350fc01 	lsr	x1, x0, #16
    6884:	f949fc44 	ldr	x4, [x2, #5112]
    6888:	8b010821 	add	x1, x1, x1, lsl #2
    688c:	d37df021 	lsl	x1, x1, #3
    6890:	8b010083 	add	x3, x4, x1
    6894:	f9401062 	ldr	x2, [x3, #32]
    6898:	b40002a2 	cbz	x2, 68ec <fwp_caps12+0xac>
    689c:	38616881 	ldrb	w1, [x4, x1]
    68a0:	7100083f 	cmp	w1, #0x2
    68a4:	540006c0 	b.eq	697c <fwp_caps12+0x13c>  // b.none
    68a8:	7100043f 	cmp	w1, #0x1
    68ac:	54000201 	b.ne	68ec <fwp_caps12+0xac>  // b.any
    68b0:	29430464 	ldp	w4, w1, [x3, #24]
    68b4:	92403c00 	and	x0, x0, #0xffff
    68b8:	9b047c00 	mul	x0, x0, x4
    68bc:	d360fc00 	lsr	x0, x0, #32
    68c0:	eb01001f 	cmp	x0, x1
    68c4:	54000142 	b.cs	68ec <fwp_caps12+0xac>  // b.hs, b.nlast
    68c8:	8b000042 	add	x2, x2, x0
    68cc:	39400040 	ldrb	w0, [x2]
    68d0:	7100041f 	cmp	w0, #0x1
    68d4:	540000c1 	b.ne	68ec <fwp_caps12+0xac>  // b.any
    68d8:	aa1303e0 	mov	x0, x19
    68dc:	f9400bf3 	ldr	x19, [sp, #16]
    68e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68e4:	17fff7a3 	b	4770 <fwp_mem_free>
    68e8:	34fffbe1 	cbz	w1, 6864 <fwp_caps12+0x24>
    68ec:	f9400bf3 	ldr	x19, [sp, #16]
    68f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68f4:	d65f03c0 	ret
    68f8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    68fc:	91154042 	add	x2, x2, #0x550
    6900:	f949d843 	ldr	x3, [x2, #5040]
    6904:	f949ec41 	ldr	x1, [x2, #5080]
    6908:	cb030000 	sub	x0, x0, x3
    690c:	eb01401f 	cmp	x0, x1, lsl #16
    6910:	54fffee2 	b.cs	68ec <fwp_caps12+0xac>  // b.hs, b.nlast
    6914:	d350fc01 	lsr	x1, x0, #16
    6918:	f949fc44 	ldr	x4, [x2, #5112]
    691c:	8b010821 	add	x1, x1, x1, lsl #2
    6920:	d37df021 	lsl	x1, x1, #3
    6924:	8b010083 	add	x3, x4, x1
    6928:	f9401062 	ldr	x2, [x3, #32]
    692c:	b4fffe02 	cbz	x2, 68ec <fwp_caps12+0xac>
    6930:	38616881 	ldrb	w1, [x4, x1]
    6934:	7100083f 	cmp	w1, #0x2
    6938:	54000280 	b.eq	6988 <fwp_caps12+0x148>  // b.none
    693c:	7100043f 	cmp	w1, #0x1
    6940:	54fffd61 	b.ne	68ec <fwp_caps12+0xac>  // b.any
    6944:	92403c01 	and	x1, x0, #0xffff
    6948:	29430064 	ldp	w4, w0, [x3, #24]
    694c:	9b047c21 	mul	x1, x1, x4
    6950:	d360fc21 	lsr	x1, x1, #32
    6954:	eb00003f 	cmp	x1, x0
    6958:	54fffca2 	b.cs	68ec <fwp_caps12+0xac>  // b.hs, b.nlast
    695c:	8b010042 	add	x2, x2, x1
    6960:	39400040 	ldrb	w0, [x2]
    6964:	34fffc40 	cbz	w0, 68ec <fwp_caps12+0xac>
    6968:	7103f41f 	cmp	w0, #0xfd
    696c:	54000148 	b.hi	6994 <fwp_caps12+0x154>  // b.pmore
    6970:	11000400 	add	w0, w0, #0x1
    6974:	39000040 	strb	w0, [x2]
    6978:	17ffffdd 	b	68ec <fwp_caps12+0xac>
    697c:	72003c1f 	tst	w0, #0xffff
    6980:	54fffb61 	b.ne	68ec <fwp_caps12+0xac>  // b.any
    6984:	17ffffd2 	b	68cc <fwp_caps12+0x8c>
    6988:	72003c1f 	tst	w0, #0xffff
    698c:	54fffb01 	b.ne	68ec <fwp_caps12+0xac>  // b.any
    6990:	17fffff4 	b	6960 <fwp_caps12+0x120>
    6994:	f9400bf3 	ldr	x19, [sp, #16]
    6998:	aa0203e0 	mov	x0, x2
    699c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69a0:	17fff68d 	b	43d4 <fwp_rc_wide_dup>

00000000000069a4 <fwp_drop2>:
    69a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69a8:	910003fd 	mov	x29, sp
    69ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    69b0:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    69b4:	911542d5 	add	x21, x22, #0x550
    69b8:	a90153f3 	stp	x19, x20, [sp, #16]
    69bc:	aa0003f3 	mov	x19, x0
    69c0:	f949daa1 	ldr	x1, [x21, #5040]
    69c4:	f949eea0 	ldr	x0, [x21, #5080]
    69c8:	cb010261 	sub	x1, x19, x1
    69cc:	eb00403f 	cmp	x1, x0, lsl #16
    69d0:	54000382 	b.cs	6a40 <fwp_drop2+0x9c>  // b.hs, b.nlast
    69d4:	d350fc22 	lsr	x2, x1, #16
    69d8:	f949fea3 	ldr	x3, [x21, #5112]
    69dc:	8b020842 	add	x2, x2, x2, lsl #2
    69e0:	d37df042 	lsl	x2, x2, #3
    69e4:	8b020060 	add	x0, x3, x2
    69e8:	f9401014 	ldr	x20, [x0, #32]
    69ec:	b40002b4 	cbz	x20, 6a40 <fwp_drop2+0x9c>
    69f0:	38626862 	ldrb	w2, [x3, x2]
    69f4:	7100085f 	cmp	w2, #0x2
    69f8:	540002c0 	b.eq	6a50 <fwp_drop2+0xac>  // b.none
    69fc:	7100045f 	cmp	w2, #0x1
    6a00:	54000201 	b.ne	6a40 <fwp_drop2+0x9c>  // b.any
    6a04:	29430002 	ldp	w2, w0, [x0, #24]
    6a08:	92403c21 	and	x1, x1, #0xffff
    6a0c:	9b027c21 	mul	x1, x1, x2
    6a10:	d360fc21 	lsr	x1, x1, #32
    6a14:	eb00003f 	cmp	x1, x0
    6a18:	54000142 	b.cs	6a40 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6a1c:	8b010294 	add	x20, x20, x1
    6a20:	39400280 	ldrb	w0, [x20]
    6a24:	340000e0 	cbz	w0, 6a40 <fwp_drop2+0x9c>
    6a28:	7100041f 	cmp	w0, #0x1
    6a2c:	540001e0 	b.eq	6a68 <fwp_drop2+0xc4>  // b.none
    6a30:	7103fc1f 	cmp	w0, #0xff
    6a34:	540007e0 	b.eq	6b30 <fwp_drop2+0x18c>  // b.none
    6a38:	51000400 	sub	w0, w0, #0x1
    6a3c:	39000280 	strb	w0, [x20]
    6a40:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a44:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6a48:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a4c:	d65f03c0 	ret
    6a50:	72003c3f 	tst	w1, #0xffff
    6a54:	54fffe60 	b.eq	6a20 <fwp_drop2+0x7c>  // b.none
    6a58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6a60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a64:	d65f03c0 	ret
    6a68:	911542c2 	add	x2, x22, #0x550
    6a6c:	f9400660 	ldr	x0, [x19, #8]
    6a70:	f949d841 	ldr	x1, [x2, #5040]
    6a74:	f949ec42 	ldr	x2, [x2, #5080]
    6a78:	cb010001 	sub	x1, x0, x1
    6a7c:	eb02403f 	cmp	x1, x2, lsl #16
    6a80:	54000382 	b.cs	6af0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6a84:	d350fc22 	lsr	x2, x1, #16
    6a88:	8b020842 	add	x2, x2, x2, lsl #2
    6a8c:	d37df042 	lsl	x2, x2, #3
    6a90:	8b020064 	add	x4, x3, x2
    6a94:	f9401094 	ldr	x20, [x4, #32]
    6a98:	b40002d4 	cbz	x20, 6af0 <fwp_drop2+0x14c>
    6a9c:	38626862 	ldrb	w2, [x3, x2]
    6aa0:	7100085f 	cmp	w2, #0x2
    6aa4:	54000400 	b.eq	6b24 <fwp_drop2+0x180>  // b.none
    6aa8:	7100045f 	cmp	w2, #0x1
    6aac:	54000221 	b.ne	6af0 <fwp_drop2+0x14c>  // b.any
    6ab0:	29430883 	ldp	w3, w2, [x4, #24]
    6ab4:	92403c21 	and	x1, x1, #0xffff
    6ab8:	9b037c21 	mul	x1, x1, x3
    6abc:	d360fc21 	lsr	x1, x1, #32
    6ac0:	eb02003f 	cmp	x1, x2
    6ac4:	54000162 	b.cs	6af0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6ac8:	8b010294 	add	x20, x20, x1
    6acc:	39400281 	ldrb	w1, [x20]
    6ad0:	34000101 	cbz	w1, 6af0 <fwp_drop2+0x14c>
    6ad4:	7100043f 	cmp	w1, #0x1
    6ad8:	54000220 	b.eq	6b1c <fwp_drop2+0x178>  // b.none
    6adc:	7103fc3f 	cmp	w1, #0xff
    6ae0:	540005a0 	b.eq	6b94 <fwp_drop2+0x1f0>  // b.none
    6ae4:	51000421 	sub	w1, w1, #0x1
    6ae8:	39000281 	strb	w1, [x20]
    6aec:	d503201f 	nop
    6af0:	f9400a74 	ldr	x20, [x19, #16]
    6af4:	aa1303e0 	mov	x0, x19
    6af8:	97fffa9f 	bl	5574 <fwp_rc_free_arr>
    6afc:	911542c0 	add	x0, x22, #0x550
    6b00:	f949d801 	ldr	x1, [x0, #5040]
    6b04:	f949ec00 	ldr	x0, [x0, #5080]
    6b08:	cb010281 	sub	x1, x20, x1
    6b0c:	eb00403f 	cmp	x1, x0, lsl #16
    6b10:	54fff982 	b.cs	6a40 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6b14:	aa1403f3 	mov	x19, x20
    6b18:	17ffffaf 	b	69d4 <fwp_drop2+0x30>
    6b1c:	97fffa96 	bl	5574 <fwp_rc_free_arr>
    6b20:	17fffff4 	b	6af0 <fwp_drop2+0x14c>
    6b24:	72003c3f 	tst	w1, #0xffff
    6b28:	54fffe41 	b.ne	6af0 <fwp_drop2+0x14c>  // b.any
    6b2c:	17ffffe8 	b	6acc <fwp_drop2+0x128>
    6b30:	ca544681 	eor	x1, x20, x20, lsr #17
    6b34:	911542c0 	add	x0, x22, #0x550
    6b38:	ca412421 	eor	x1, x1, x1, lsr #9
    6b3c:	8b210c01 	add	x1, x0, w1, uxtb #3
    6b40:	f94a2420 	ldr	x0, [x1, #5192]
    6b44:	b5000080 	cbnz	x0, 6b54 <fwp_drop2+0x1b0>
    6b48:	14000010 	b	6b88 <fwp_drop2+0x1e4>
    6b4c:	f9400800 	ldr	x0, [x0, #16]
    6b50:	b40001c0 	cbz	x0, 6b88 <fwp_drop2+0x1e4>
    6b54:	f9400001 	ldr	x1, [x0]
    6b58:	eb14003f 	cmp	x1, x20
    6b5c:	54ffff81 	b.ne	6b4c <fwp_drop2+0x1a8>  // b.any
    6b60:	f9400401 	ldr	x1, [x0, #8]
    6b64:	d1000421 	sub	x1, x1, #0x1
    6b68:	f9000401 	str	x1, [x0, #8]
    6b6c:	f103f83f 	cmp	x1, #0xfe
    6b70:	54fff681 	b.ne	6a40 <fwp_drop2+0x9c>  // b.any
    6b74:	aa1403e0 	mov	x0, x20
    6b78:	97fff65e 	bl	44f0 <fwp_rc_forget_slot>
    6b7c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b80:	39000280 	strb	w0, [x20]
    6b84:	17ffffaf 	b	6a40 <fwp_drop2+0x9c>
    6b88:	f0000020 	adrp	x0, d000 <__modti3+0x320>
    6b8c:	910ca000 	add	x0, x0, #0x328
    6b90:	97fff25c 	bl	3500 <fwp_trap>
    6b94:	ca544680 	eor	x0, x20, x20, lsr #17
    6b98:	911542c1 	add	x1, x22, #0x550
    6b9c:	ca402400 	eor	x0, x0, x0, lsr #9
    6ba0:	8b200c20 	add	x0, x1, w0, uxtb #3
    6ba4:	f94a2400 	ldr	x0, [x0, #5192]
    6ba8:	b5000080 	cbnz	x0, 6bb8 <fwp_drop2+0x214>
    6bac:	17fffff7 	b	6b88 <fwp_drop2+0x1e4>
    6bb0:	f9400800 	ldr	x0, [x0, #16]
    6bb4:	b4fffea0 	cbz	x0, 6b88 <fwp_drop2+0x1e4>
    6bb8:	f9400001 	ldr	x1, [x0]
    6bbc:	eb14003f 	cmp	x1, x20
    6bc0:	54ffff81 	b.ne	6bb0 <fwp_drop2+0x20c>  // b.any
    6bc4:	f9400401 	ldr	x1, [x0, #8]
    6bc8:	d1000421 	sub	x1, x1, #0x1
    6bcc:	f9000401 	str	x1, [x0, #8]
    6bd0:	f103f83f 	cmp	x1, #0xfe
    6bd4:	54fff8e1 	b.ne	6af0 <fwp_drop2+0x14c>  // b.any
    6bd8:	aa1403e0 	mov	x0, x20
    6bdc:	97fff645 	bl	44f0 <fwp_rc_forget_slot>
    6be0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6be4:	39000280 	strb	w0, [x20]
    6be8:	17ffffc2 	b	6af0 <fwp_drop2+0x14c>
    6bec:	d503201f 	nop

0000000000006bf0 <fwp_arg_drop23>:
    6bf0:	7100003f 	cmp	w1, #0x0
    6bf4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6bf8:	54000041 	b.ne	6c00 <fwp_arg_drop23+0x10>  // b.any
    6bfc:	d65f03c0 	ret
    6c00:	f9400000 	ldr	x0, [x0]
    6c04:	17ffff68 	b	69a4 <fwp_drop2>
    6c08:	d503201f 	nop
    6c0c:	d503201f 	nop

0000000000006c10 <fwp_caps23>:
    6c10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c14:	910003fd 	mov	x29, sp
    6c18:	f9000bf3 	str	x19, [sp, #16]
    6c1c:	aa0003f3 	mov	x19, x0
    6c20:	b9400400 	ldr	w0, [x0, #4]
    6c24:	340004a0 	cbz	w0, 6cb8 <fwp_caps23+0xa8>
    6c28:	f9400660 	ldr	x0, [x19, #8]
    6c2c:	350004e1 	cbnz	w1, 6cc8 <fwp_caps23+0xb8>
    6c30:	97ffff5d 	bl	69a4 <fwp_drop2>
    6c34:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6c38:	91154042 	add	x2, x2, #0x550
    6c3c:	f949d840 	ldr	x0, [x2, #5040]
    6c40:	f949ec41 	ldr	x1, [x2, #5080]
    6c44:	cb000260 	sub	x0, x19, x0
    6c48:	eb01401f 	cmp	x0, x1, lsl #16
    6c4c:	54000382 	b.cs	6cbc <fwp_caps23+0xac>  // b.hs, b.nlast
    6c50:	d350fc01 	lsr	x1, x0, #16
    6c54:	f949fc44 	ldr	x4, [x2, #5112]
    6c58:	8b010821 	add	x1, x1, x1, lsl #2
    6c5c:	d37df021 	lsl	x1, x1, #3
    6c60:	8b010083 	add	x3, x4, x1
    6c64:	f9401062 	ldr	x2, [x3, #32]
    6c68:	b40002a2 	cbz	x2, 6cbc <fwp_caps23+0xac>
    6c6c:	38616881 	ldrb	w1, [x4, x1]
    6c70:	7100083f 	cmp	w1, #0x2
    6c74:	540006c0 	b.eq	6d4c <fwp_caps23+0x13c>  // b.none
    6c78:	7100043f 	cmp	w1, #0x1
    6c7c:	54000201 	b.ne	6cbc <fwp_caps23+0xac>  // b.any
    6c80:	29430464 	ldp	w4, w1, [x3, #24]
    6c84:	92403c00 	and	x0, x0, #0xffff
    6c88:	9b047c00 	mul	x0, x0, x4
    6c8c:	d360fc00 	lsr	x0, x0, #32
    6c90:	eb01001f 	cmp	x0, x1
    6c94:	54000142 	b.cs	6cbc <fwp_caps23+0xac>  // b.hs, b.nlast
    6c98:	8b000042 	add	x2, x2, x0
    6c9c:	39400040 	ldrb	w0, [x2]
    6ca0:	7100041f 	cmp	w0, #0x1
    6ca4:	540000c1 	b.ne	6cbc <fwp_caps23+0xac>  // b.any
    6ca8:	aa1303e0 	mov	x0, x19
    6cac:	f9400bf3 	ldr	x19, [sp, #16]
    6cb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cb4:	17fff6af 	b	4770 <fwp_mem_free>
    6cb8:	34fffbe1 	cbz	w1, 6c34 <fwp_caps23+0x24>
    6cbc:	f9400bf3 	ldr	x19, [sp, #16]
    6cc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cc4:	d65f03c0 	ret
    6cc8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6ccc:	91154042 	add	x2, x2, #0x550
    6cd0:	f949d843 	ldr	x3, [x2, #5040]
    6cd4:	f949ec41 	ldr	x1, [x2, #5080]
    6cd8:	cb030000 	sub	x0, x0, x3
    6cdc:	eb01401f 	cmp	x0, x1, lsl #16
    6ce0:	54fffee2 	b.cs	6cbc <fwp_caps23+0xac>  // b.hs, b.nlast
    6ce4:	d350fc01 	lsr	x1, x0, #16
    6ce8:	f949fc44 	ldr	x4, [x2, #5112]
    6cec:	8b010821 	add	x1, x1, x1, lsl #2
    6cf0:	d37df021 	lsl	x1, x1, #3
    6cf4:	8b010083 	add	x3, x4, x1
    6cf8:	f9401062 	ldr	x2, [x3, #32]
    6cfc:	b4fffe02 	cbz	x2, 6cbc <fwp_caps23+0xac>
    6d00:	38616881 	ldrb	w1, [x4, x1]
    6d04:	7100083f 	cmp	w1, #0x2
    6d08:	54000280 	b.eq	6d58 <fwp_caps23+0x148>  // b.none
    6d0c:	7100043f 	cmp	w1, #0x1
    6d10:	54fffd61 	b.ne	6cbc <fwp_caps23+0xac>  // b.any
    6d14:	92403c01 	and	x1, x0, #0xffff
    6d18:	29430064 	ldp	w4, w0, [x3, #24]
    6d1c:	9b047c21 	mul	x1, x1, x4
    6d20:	d360fc21 	lsr	x1, x1, #32
    6d24:	eb00003f 	cmp	x1, x0
    6d28:	54fffca2 	b.cs	6cbc <fwp_caps23+0xac>  // b.hs, b.nlast
    6d2c:	8b010042 	add	x2, x2, x1
    6d30:	39400040 	ldrb	w0, [x2]
    6d34:	34fffc40 	cbz	w0, 6cbc <fwp_caps23+0xac>
    6d38:	7103f41f 	cmp	w0, #0xfd
    6d3c:	54000148 	b.hi	6d64 <fwp_caps23+0x154>  // b.pmore
    6d40:	11000400 	add	w0, w0, #0x1
    6d44:	39000040 	strb	w0, [x2]
    6d48:	17ffffdd 	b	6cbc <fwp_caps23+0xac>
    6d4c:	72003c1f 	tst	w0, #0xffff
    6d50:	54fffb61 	b.ne	6cbc <fwp_caps23+0xac>  // b.any
    6d54:	17ffffd2 	b	6c9c <fwp_caps23+0x8c>
    6d58:	72003c1f 	tst	w0, #0xffff
    6d5c:	54fffb01 	b.ne	6cbc <fwp_caps23+0xac>  // b.any
    6d60:	17fffff4 	b	6d30 <fwp_caps23+0x120>
    6d64:	f9400bf3 	ldr	x19, [sp, #16]
    6d68:	aa0203e0 	mov	x0, x2
    6d6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d70:	17fff599 	b	43d4 <fwp_rc_wide_dup>

0000000000006d74 <f23>:
    6d74:	d10203ff 	sub	sp, sp, #0x80
    6d78:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6d7c:	f947f421 	ldr	x1, [x1, #4072]
    6d80:	a9027bfd 	stp	x29, x30, [sp, #32]
    6d84:	910083fd 	add	x29, sp, #0x20
    6d88:	a9045bf5 	stp	x21, x22, [sp, #64]
    6d8c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    6d90:	911542c3 	add	x3, x22, #0x550
    6d94:	a90353f3 	stp	x19, x20, [sp, #48]
    6d98:	a90563f7 	stp	x23, x24, [sp, #80]
    6d9c:	aa0003f8 	mov	x24, x0
    6da0:	a9066bf9 	stp	x25, x26, [sp, #96]
    6da4:	f949ec62 	ldr	x2, [x3, #5080]
    6da8:	f9400024 	ldr	x4, [x1]
    6dac:	f9000fe4 	str	x4, [sp, #24]
    6db0:	d2800004 	mov	x4, #0x0                   	// #0
    6db4:	f949d861 	ldr	x1, [x3, #5040]
    6db8:	d370bc42 	lsl	x2, x2, #16
    6dbc:	b40017c0 	cbz	x0, 70b4 <f23+0x340>
    6dc0:	f9400819 	ldr	x25, [x0, #16]
    6dc4:	cb010321 	sub	x1, x25, x1
    6dc8:	eb02003f 	cmp	x1, x2
    6dcc:	54000362 	b.cs	6e38 <f23+0xc4>  // b.hs, b.nlast
    6dd0:	f949fc60 	ldr	x0, [x3, #5112]
    6dd4:	d350fc22 	lsr	x2, x1, #16
    6dd8:	8b020842 	add	x2, x2, x2, lsl #2
    6ddc:	8b020c02 	add	x2, x0, x2, lsl #3
    6de0:	f9401040 	ldr	x0, [x2, #32]
    6de4:	b40002a0 	cbz	x0, 6e38 <f23+0xc4>
    6de8:	39400043 	ldrb	w3, [x2]
    6dec:	7100087f 	cmp	w3, #0x2
    6df0:	540015c0 	b.eq	70a8 <f23+0x334>  // b.none
    6df4:	7100047f 	cmp	w3, #0x1
    6df8:	540001c1 	b.ne	6e30 <f23+0xbc>  // b.any
    6dfc:	29430843 	ldp	w3, w2, [x2, #24]
    6e00:	92403c21 	and	x1, x1, #0xffff
    6e04:	9b037c21 	mul	x1, x1, x3
    6e08:	d360fc21 	lsr	x1, x1, #32
    6e0c:	eb02003f 	cmp	x1, x2
    6e10:	54000102 	b.cs	6e30 <f23+0xbc>  // b.hs, b.nlast
    6e14:	8b010000 	add	x0, x0, x1
    6e18:	39400001 	ldrb	w1, [x0]
    6e1c:	340000a1 	cbz	w1, 6e30 <f23+0xbc>
    6e20:	7103f43f 	cmp	w1, #0xfd
    6e24:	54001868 	b.hi	7130 <f23+0x3bc>  // b.pmore
    6e28:	11000421 	add	w1, w1, #0x1
    6e2c:	39000001 	strb	w1, [x0]
    6e30:	d2800000 	mov	x0, #0x0                   	// #0
    6e34:	b40000d8 	cbz	x24, 6e4c <f23+0xd8>
    6e38:	aa1803e1 	mov	x1, x24
    6e3c:	d2800000 	mov	x0, #0x0                   	// #0
    6e40:	f9400821 	ldr	x1, [x1, #16]
    6e44:	91000400 	add	x0, x0, #0x1
    6e48:	b5ffffc1 	cbnz	x1, 6e40 <f23+0xcc>
    6e4c:	b40013b9 	cbz	x25, 70c0 <f23+0x34c>
    6e50:	aa1903e1 	mov	x1, x25
    6e54:	d2800002 	mov	x2, #0x0                   	// #0
    6e58:	f9400821 	ldr	x1, [x1, #16]
    6e5c:	91000442 	add	x2, x2, #0x1
    6e60:	b5ffffc1 	cbnz	x1, 6e58 <f23+0xe4>
    6e64:	eb00005f 	cmp	x2, x0
    6e68:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6e6c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    6e70:	eb01035f 	cmp	x26, x1
    6e74:	54001668 	b.hi	7140 <f23+0x3cc>  // b.pmore
    6e78:	d37ffb53 	lsl	x19, x26, #1
    6e7c:	52800041 	mov	w1, #0x2                   	// #2
    6e80:	91000660 	add	x0, x19, #0x1
    6e84:	d37df000 	lsl	x0, x0, #3
    6e88:	97fff75a 	bl	4bf0 <fwp_heap_alloc>
    6e8c:	aa0003f7 	mov	x23, x0
    6e90:	911542c1 	add	x1, x22, #0x550
    6e94:	aa0103e0 	mov	x0, x1
    6e98:	f90002f3 	str	x19, [x23]
    6e9c:	f949d821 	ldr	x1, [x1, #5040]
    6ea0:	f949ec00 	ldr	x0, [x0, #5080]
    6ea4:	cb0102e1 	sub	x1, x23, x1
    6ea8:	eb00403f 	cmp	x1, x0, lsl #16
    6eac:	54000342 	b.cs	6f14 <f23+0x1a0>  // b.hs, b.nlast
    6eb0:	911542c2 	add	x2, x22, #0x550
    6eb4:	d350fc20 	lsr	x0, x1, #16
    6eb8:	8b000800 	add	x0, x0, x0, lsl #2
    6ebc:	f949fc43 	ldr	x3, [x2, #5112]
    6ec0:	d37df002 	lsl	x2, x0, #3
    6ec4:	8b020060 	add	x0, x3, x2
    6ec8:	f9401013 	ldr	x19, [x0, #32]
    6ecc:	b4000253 	cbz	x19, 6f14 <f23+0x1a0>
    6ed0:	38626862 	ldrb	w2, [x3, x2]
    6ed4:	7100085f 	cmp	w2, #0x2
    6ed8:	54000e20 	b.eq	709c <f23+0x328>  // b.none
    6edc:	7100045f 	cmp	w2, #0x1
    6ee0:	540001a1 	b.ne	6f14 <f23+0x1a0>  // b.any
    6ee4:	29430002 	ldp	w2, w0, [x0, #24]
    6ee8:	92403c21 	and	x1, x1, #0xffff
    6eec:	9b027c21 	mul	x1, x1, x2
    6ef0:	d360fc21 	lsr	x1, x1, #32
    6ef4:	eb00003f 	cmp	x1, x0
    6ef8:	540000e2 	b.cs	6f14 <f23+0x1a0>  // b.hs, b.nlast
    6efc:	8b010273 	add	x19, x19, x1
    6f00:	39400260 	ldrb	w0, [x19]
    6f04:	7103fc1f 	cmp	w0, #0xff
    6f08:	54000f80 	b.eq	70f8 <f23+0x384>  // b.none
    6f0c:	52800020 	mov	w0, #0x1                   	// #1
    6f10:	39000260 	strb	w0, [x19]
    6f14:	b400025a 	cbz	x26, 6f5c <f23+0x1e8>
    6f18:	8b1a12fa 	add	x26, x23, x26, lsl #4
    6f1c:	aa1703f3 	mov	x19, x23
    6f20:	aa1803f5 	mov	x21, x24
    6f24:	aa1903f4 	mov	x20, x25
    6f28:	f9400683 	ldr	x3, [x20, #8]
    6f2c:	f94006a2 	ldr	x2, [x21, #8]
    6f30:	f9400861 	ldr	x1, [x3, #16]
    6f34:	f9400840 	ldr	x0, [x2, #16]
    6f38:	fd400461 	ldr	d1, [x3, #8]
    6f3c:	fd400440 	ldr	d0, [x2, #8]
    6f40:	97fff8ac 	bl	51f0 <w107>
    6f44:	f9000660 	str	x0, [x19, #8]
    6f48:	f8010e61 	str	x1, [x19, #16]!
    6f4c:	f9400a94 	ldr	x20, [x20, #16]
    6f50:	f9400ab5 	ldr	x21, [x21, #16]
    6f54:	eb13035f 	cmp	x26, x19
    6f58:	54fffe81 	b.ne	6f28 <f23+0x1b4>  // b.any
    6f5c:	aa1903e0 	mov	x0, x25
    6f60:	97fffe91 	bl	69a4 <fwp_drop2>
    6f64:	aa1803e0 	mov	x0, x24
    6f68:	97fffe8f 	bl	69a4 <fwp_drop2>
    6f6c:	f94002f5 	ldr	x21, [x23]
    6f70:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6f74:	b4000275 	cbz	x21, 6fc0 <f23+0x24c>
    6f78:	fd003be8 	str	d8, [sp, #112]
    6f7c:	2f00e408 	movi	d8, #0x0
    6f80:	910022f9 	add	x25, x23, #0x8
    6f84:	910042f8 	add	x24, x23, #0x10
    6f88:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    6f8c:	d2800013 	mov	x19, #0x0                   	// #0
    6f90:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    6f94:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6f98:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    6f9c:	aa0303e1 	mov	x1, x3
    6fa0:	1e602908 	fadd	d8, d8, d0
    6fa4:	91000a73 	add	x19, x19, #0x2
    6fa8:	97fff7df 	bl	4f24 <fwp_p_ad_push>
    6fac:	aa0003f4 	mov	x20, x0
    6fb0:	eb1302bf 	cmp	x21, x19
    6fb4:	54fffee8 	b.hi	6f90 <f23+0x21c>  // b.pmore
    6fb8:	9e660115 	fmov	x21, d8
    6fbc:	fd403be8 	ldr	d8, [sp, #112]
    6fc0:	911542d6 	add	x22, x22, #0x550
    6fc4:	aa1703e0 	mov	x0, x23
    6fc8:	97fffd26 	bl	6460 <fwp_drop4>
    6fcc:	a900d3f5 	stp	x21, x20, [sp, #8]
    6fd0:	910023e1 	add	x1, sp, #0x8
    6fd4:	52800000 	mov	w0, #0x0                   	// #0
    6fd8:	97fff8ca 	bl	5300 <fwp_data.part.0.constprop.0>
    6fdc:	f949dac1 	ldr	x1, [x22, #5040]
    6fe0:	aa0003f3 	mov	x19, x0
    6fe4:	f949eec0 	ldr	x0, [x22, #5080]
    6fe8:	cb010261 	sub	x1, x19, x1
    6fec:	eb00403f 	cmp	x1, x0, lsl #16
    6ff0:	54000322 	b.cs	7054 <f23+0x2e0>  // b.hs, b.nlast
    6ff4:	d350fc22 	lsr	x2, x1, #16
    6ff8:	f949fec3 	ldr	x3, [x22, #5112]
    6ffc:	8b020842 	add	x2, x2, x2, lsl #2
    7000:	d37df042 	lsl	x2, x2, #3
    7004:	8b020060 	add	x0, x3, x2
    7008:	f9401014 	ldr	x20, [x0, #32]
    700c:	b4000254 	cbz	x20, 7054 <f23+0x2e0>
    7010:	38626862 	ldrb	w2, [x3, x2]
    7014:	7100085f 	cmp	w2, #0x2
    7018:	540003c0 	b.eq	7090 <f23+0x31c>  // b.none
    701c:	7100045f 	cmp	w2, #0x1
    7020:	540001a1 	b.ne	7054 <f23+0x2e0>  // b.any
    7024:	29430002 	ldp	w2, w0, [x0, #24]
    7028:	92403c21 	and	x1, x1, #0xffff
    702c:	9b027c21 	mul	x1, x1, x2
    7030:	d360fc21 	lsr	x1, x1, #32
    7034:	eb00003f 	cmp	x1, x0
    7038:	540000e2 	b.cs	7054 <f23+0x2e0>  // b.hs, b.nlast
    703c:	8b010294 	add	x20, x20, x1
    7040:	39400280 	ldrb	w0, [x20]
    7044:	7103fc1f 	cmp	w0, #0xff
    7048:	540005e0 	b.eq	7104 <f23+0x390>  // b.none
    704c:	52800020 	mov	w0, #0x1                   	// #1
    7050:	39000280 	strb	w0, [x20]
    7054:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7058:	f947f400 	ldr	x0, [x0, #4072]
    705c:	f9400fe2 	ldr	x2, [sp, #24]
    7060:	f9400001 	ldr	x1, [x0]
    7064:	eb010042 	subs	x2, x2, x1
    7068:	d2800001 	mov	x1, #0x0                   	// #0
    706c:	54000721 	b.ne	7150 <f23+0x3dc>  // b.any
    7070:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7074:	aa1303e0 	mov	x0, x19
    7078:	a94353f3 	ldp	x19, x20, [sp, #48]
    707c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7080:	a94563f7 	ldp	x23, x24, [sp, #80]
    7084:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7088:	910203ff 	add	sp, sp, #0x80
    708c:	d65f03c0 	ret
    7090:	72003c3f 	tst	w1, #0xffff
    7094:	54fffe01 	b.ne	7054 <f23+0x2e0>  // b.any
    7098:	17ffffea 	b	7040 <f23+0x2cc>
    709c:	72003c3f 	tst	w1, #0xffff
    70a0:	54fff3a1 	b.ne	6f14 <f23+0x1a0>  // b.any
    70a4:	17ffff97 	b	6f00 <f23+0x18c>
    70a8:	72003c3f 	tst	w1, #0xffff
    70ac:	54ffec21 	b.ne	6e30 <f23+0xbc>  // b.any
    70b0:	17ffff5a 	b	6e18 <f23+0xa4>
    70b4:	cb0103e1 	neg	x1, x1
    70b8:	eb02003f 	cmp	x1, x2
    70bc:	540002a3 	b.cc	7110 <f23+0x39c>  // b.lo, b.ul, b.last
    70c0:	52800041 	mov	w1, #0x2                   	// #2
    70c4:	d2800100 	mov	x0, #0x8                   	// #8
    70c8:	97fff6ca 	bl	4bf0 <fwp_heap_alloc>
    70cc:	aa0003f7 	mov	x23, x0
    70d0:	911542c0 	add	x0, x22, #0x550
    70d4:	f90002ff 	str	xzr, [x23]
    70d8:	f949d801 	ldr	x1, [x0, #5040]
    70dc:	f949ec00 	ldr	x0, [x0, #5080]
    70e0:	cb0102e1 	sub	x1, x23, x1
    70e4:	eb00403f 	cmp	x1, x0, lsl #16
    70e8:	54000282 	b.cs	7138 <f23+0x3c4>  // b.hs, b.nlast
    70ec:	d280001a 	mov	x26, #0x0                   	// #0
    70f0:	d2800019 	mov	x25, #0x0                   	// #0
    70f4:	17ffff6f 	b	6eb0 <f23+0x13c>
    70f8:	aa1303e0 	mov	x0, x19
    70fc:	97fff4fd 	bl	44f0 <fwp_rc_forget_slot>
    7100:	17ffff83 	b	6f0c <f23+0x198>
    7104:	aa1403e0 	mov	x0, x20
    7108:	97fff4fa 	bl	44f0 <fwp_rc_forget_slot>
    710c:	17ffffd0 	b	704c <f23+0x2d8>
    7110:	f949fc62 	ldr	x2, [x3, #5112]
    7114:	d350fc20 	lsr	x0, x1, #16
    7118:	8b000800 	add	x0, x0, x0, lsl #2
    711c:	8b000c42 	add	x2, x2, x0, lsl #3
    7120:	f9401040 	ldr	x0, [x2, #32]
    7124:	b4fffce0 	cbz	x0, 70c0 <f23+0x34c>
    7128:	d2800019 	mov	x25, #0x0                   	// #0
    712c:	17ffff2f 	b	6de8 <f23+0x74>
    7130:	97fff4a9 	bl	43d4 <fwp_rc_wide_dup>
    7134:	17ffff3f 	b	6e30 <f23+0xbc>
    7138:	d2800019 	mov	x25, #0x0                   	// #0
    713c:	17ffff88 	b	6f5c <f23+0x1e8>
    7140:	d0000020 	adrp	x0, d000 <__modti3+0x320>
    7144:	9111a000 	add	x0, x0, #0x468
    7148:	fd003be8 	str	d8, [sp, #112]
    714c:	97fff0ed 	bl	3500 <fwp_trap>
    7150:	fd003be8 	str	d8, [sp, #112]
    7154:	97ffeda7 	bl	27f0 <__stack_chk_fail@plt>
    7158:	d503201f 	nop
    715c:	d503201f 	nop

0000000000007160 <fwp_owned_entry23>:
    7160:	f9400000 	ldr	x0, [x0]
    7164:	17ffff04 	b	6d74 <f23>
    7168:	d503201f 	nop
    716c:	d503201f 	nop

0000000000007170 <e23>:
    7170:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7174:	910003fd 	mov	x29, sp
    7178:	f9000bf3 	str	x19, [sp, #16]
    717c:	f9400013 	ldr	x19, [x0]
    7180:	aa1303e0 	mov	x0, x19
    7184:	97fff8a7 	bl	5420 <fwp_rc_share>
    7188:	aa1303e0 	mov	x0, x19
    718c:	97fffefa 	bl	6d74 <f23>
    7190:	aa0003f3 	mov	x19, x0
    7194:	97fff8a3 	bl	5420 <fwp_rc_share>
    7198:	aa1303e0 	mov	x0, x19
    719c:	f9400bf3 	ldr	x19, [sp, #16]
    71a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71a4:	d65f03c0 	ret
    71a8:	d503201f 	nop
    71ac:	d503201f 	nop

00000000000071b0 <f12>:
    71b0:	d10483ff 	sub	sp, sp, #0x120
    71b4:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    71b8:	f947f442 	ldr	x2, [x2, #4072]
    71bc:	9100e3e8 	add	x8, sp, #0x38
    71c0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    71c4:	910303fd 	add	x29, sp, #0xc0
    71c8:	a90e5bf5 	stp	x21, x22, [sp, #224]
    71cc:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc90>
    71d0:	911542a3 	add	x3, x21, #0x550
    71d4:	a90f63f7 	stp	x23, x24, [sp, #240]
    71d8:	b00000d7 	adrp	x23, 20000 <__data_start>
    71dc:	910102e4 	add	x4, x23, #0x40
    71e0:	f949d861 	ldr	x1, [x3, #5040]
    71e4:	a90d53f3 	stp	x19, x20, [sp, #208]
    71e8:	b00000d4 	adrp	x20, 20000 <__data_start>
    71ec:	f949ec65 	ldr	x5, [x3, #5080]
    71f0:	a9106bf9 	stp	x25, x26, [sp, #256]
    71f4:	91004294 	add	x20, x20, #0x10
    71f8:	a91173fb 	stp	x27, x28, [sp, #272]
    71fc:	910103fa 	add	x26, sp, #0x40
    7200:	d0fffff3 	adrp	x19, 5000 <fwp_p_ad_push+0xdc>
    7204:	f9416086 	ldr	x6, [x4, #704]
    7208:	f9400047 	ldr	x7, [x2]
    720c:	f9005fe7 	str	x7, [sp, #184]
    7210:	d2800007 	mov	x7, #0x0                   	// #0
    7214:	12800007 	mov	w7, #0xffffffff            	// #-1
    7218:	913c4262 	add	x2, x19, #0xf10
    721c:	cb010281 	sub	x1, x20, x1
    7220:	f90007e8 	str	x8, [sp, #8]
    7224:	b9003be7 	str	w7, [sp, #56]
    7228:	aa0003f6 	mov	x22, x0
    722c:	a9040be6 	stp	x6, x2, [sp, #64]
    7230:	f9002be8 	str	x8, [sp, #80]
    7234:	f901609a 	str	x26, [x4, #704]
    7238:	eb05403f 	cmp	x1, x5, lsl #16
    723c:	54000342 	b.cs	72a4 <f12+0xf4>  // b.hs, b.nlast
    7240:	d350fc20 	lsr	x0, x1, #16
    7244:	f949fc64 	ldr	x4, [x3, #5112]
    7248:	8b000800 	add	x0, x0, x0, lsl #2
    724c:	d37df002 	lsl	x2, x0, #3
    7250:	8b020083 	add	x3, x4, x2
    7254:	f9401060 	ldr	x0, [x3, #32]
    7258:	b4000260 	cbz	x0, 72a4 <f12+0xf4>
    725c:	38626882 	ldrb	w2, [x4, x2]
    7260:	7100085f 	cmp	w2, #0x2
    7264:	54006e00 	b.eq	8024 <f12+0xe74>  // b.none
    7268:	7100045f 	cmp	w2, #0x1
    726c:	540001c1 	b.ne	72a4 <f12+0xf4>  // b.any
    7270:	29430864 	ldp	w4, w2, [x3, #24]
    7274:	92403c21 	and	x1, x1, #0xffff
    7278:	9b047c21 	mul	x1, x1, x4
    727c:	d360fc21 	lsr	x1, x1, #32
    7280:	eb02003f 	cmp	x1, x2
    7284:	54000102 	b.cs	72a4 <f12+0xf4>  // b.hs, b.nlast
    7288:	8b010000 	add	x0, x0, x1
    728c:	39400001 	ldrb	w1, [x0]
    7290:	340000a1 	cbz	w1, 72a4 <f12+0xf4>
    7294:	7103f43f 	cmp	w1, #0xfd
    7298:	540074c8 	b.hi	8130 <f12+0xf80>  // b.pmore
    729c:	11000421 	add	w1, w1, #0x1
    72a0:	39000001 	strb	w1, [x0]
    72a4:	aa1403e0 	mov	x0, x20
    72a8:	97fffa3a 	bl	5b90 <fwp_closure_drop>
    72ac:	b4006c76 	cbz	x22, 8038 <f12+0xe88>
    72b0:	aa1603e0 	mov	x0, x22
    72b4:	d2800001 	mov	x1, #0x0                   	// #0
    72b8:	f9400800 	ldr	x0, [x0, #16]
    72bc:	91000421 	add	x1, x1, #0x1
    72c0:	b5ffffc0 	cbnz	x0, 72b8 <f12+0x108>
    72c4:	aa0103fc 	mov	x28, x1
    72c8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    72cc:	eb00003f 	cmp	x1, x0
    72d0:	54007628 	b.hi	8194 <f12+0xfe4>  // b.pmore
    72d4:	910102f4 	add	x20, x23, #0x40
    72d8:	b942f680 	ldr	w0, [x20, #756]
    72dc:	34006900 	cbz	w0, 7ffc <f12+0xe4c>
    72e0:	910102e0 	add	x0, x23, #0x40
    72e4:	f9402014 	ldr	x20, [x0, #64]
    72e8:	f9404c1b 	ldr	x27, [x0, #152]
    72ec:	eb14037f 	cmp	x27, x20
    72f0:	5400364a 	b.ge	79b8 <f12+0x808>  // b.tcont
    72f4:	f94022e1 	ldr	x1, [x23, #64]
    72f8:	8b1b0760 	add	x0, x27, x27, lsl #1
    72fc:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7300:	8b000b60 	add	x0, x27, x0, lsl #2
    7304:	8b000c20 	add	x0, x1, x0, lsl #3
    7308:	b9400401 	ldr	w1, [x0, #4]
    730c:	35000081 	cbnz	w1, 731c <f12+0x16c>
    7310:	b9400001 	ldr	w1, [x0]
    7314:	6b02003f 	cmp	w1, w2
    7318:	54003509 	b.ls	79b8 <f12+0x808>  // b.plast
    731c:	9100077b 	add	x27, x27, #0x1
    7320:	9101a000 	add	x0, x0, #0x68
    7324:	eb14037f 	cmp	x27, x20
    7328:	54ffff01 	b.ne	7308 <f12+0x158>  // b.any
    732c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7330:	eb00029f 	cmp	x20, x0
    7334:	5400738c 	b.gt	81a4 <f12+0xff4>
    7338:	910102e0 	add	x0, x23, #0x40
    733c:	f94022f9 	ldr	x25, [x23, #64]
    7340:	f9404800 	ldr	x0, [x0, #144]
    7344:	eb00029f 	cmp	x20, x0
    7348:	54000201 	b.ne	7388 <f12+0x1d8>  // b.any
    734c:	b4006db4 	cbz	x20, 8100 <f12+0xf50>
    7350:	d37ffa98 	lsl	x24, x20, #1
    7354:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7358:	eb00031f 	cmp	x24, x0
    735c:	9a80d318 	csel	x24, x24, x0, le
    7360:	8b180701 	add	x1, x24, x24, lsl #1
    7364:	8b010b01 	add	x1, x24, x1, lsl #2
    7368:	d37df021 	lsl	x1, x1, #3
    736c:	aa1903e0 	mov	x0, x25
    7370:	97ffed1c 	bl	27e0 <realloc@plt>
    7374:	aa0003f9 	mov	x25, x0
    7378:	b4006200 	cbz	x0, 7fb8 <f12+0xe08>
    737c:	910102e0 	add	x0, x23, #0x40
    7380:	f90022f9 	str	x25, [x23, #64]
    7384:	f9004818 	str	x24, [x0, #144]
    7388:	8b140681 	add	x1, x20, x20, lsl #1
    738c:	910102e0 	add	x0, x23, #0x40
    7390:	4f000400 	movi	v0.4s, #0x0
    7394:	aa1403fb 	mov	x27, x20
    7398:	8b010a81 	add	x1, x20, x1, lsl #2
    739c:	91000694 	add	x20, x20, #0x1
    73a0:	f9002014 	str	x20, [x0, #64]
    73a4:	8b1b0774 	add	x20, x27, x27, lsl #1
    73a8:	8b010f21 	add	x1, x25, x1, lsl #3
    73ac:	d0000020 	adrp	x0, d000 <__modti3+0x320>
    73b0:	8b140b74 	add	x20, x27, x20, lsl #2
    73b4:	910ae000 	add	x0, x0, #0x2b8
    73b8:	8b140f34 	add	x20, x25, x20, lsl #3
    73bc:	ad000020 	stp	q0, q0, [x1]
    73c0:	ad010020 	stp	q0, q0, [x1, #32]
    73c4:	ad020020 	stp	q0, q0, [x1, #64]
    73c8:	f900303f 	str	xzr, [x1, #96]
    73cc:	f900329f 	str	xzr, [x20, #96]
    73d0:	97ffed6c 	bl	2980 <getenv@plt>
    73d4:	b5003080 	cbnz	x0, 79e4 <f12+0x834>
    73d8:	910102e0 	add	x0, x23, #0x40
    73dc:	f9404001 	ldr	x1, [x0, #128]
    73e0:	b50063a1 	cbnz	x1, 8054 <f12+0xea4>
    73e4:	910102e2 	add	x2, x23, #0x40
    73e8:	2f000400 	mvni	v0.2s, #0x0
    73ec:	b9400298 	ldr	w24, [x20]
    73f0:	52800024 	mov	w4, #0x1                   	// #1
    73f4:	91000760 	add	x0, x27, #0x1
    73f8:	a900f29c 	stp	x28, x28, [x20, #8]
    73fc:	0b040318 	add	w24, w24, w4
    7400:	f9416041 	ldr	x1, [x2, #704]
    7404:	29001298 	stp	w24, w4, [x20]
    7408:	f9002a9f 	str	xzr, [x20, #80]
    740c:	f9004c40 	str	x0, [x2, #152]
    7410:	fd002e80 	str	d0, [x20, #88]
    7414:	b4006ba1 	cbz	x1, 8188 <f12+0xfd8>
    7418:	913c4273 	add	x19, x19, #0xf10
    741c:	14000003 	b	7428 <f12+0x278>
    7420:	f9400021 	ldr	x1, [x1]
    7424:	b4006b21 	cbz	x1, 8188 <f12+0xfd8>
    7428:	f9400422 	ldr	x2, [x1, #8]
    742c:	eb13005f 	cmp	x2, x19
    7430:	54ffff81 	b.ne	7420 <f12+0x270>  // b.any
    7434:	f9400821 	ldr	x1, [x1, #16]
    7438:	2a1b03e4 	mov	w4, w27
    743c:	b9400022 	ldr	w2, [x1]
    7440:	f9002a81 	str	x1, [x20, #80]
    7444:	b9005e82 	str	w2, [x20, #92]
    7448:	37f80082 	tbnz	w2, #31, 7458 <f12+0x2a8>
    744c:	52800d05 	mov	w5, #0x68                  	// #104
    7450:	9b256442 	smaddl	x2, w2, w5, x25
    7454:	b900585b 	str	w27, [x2, #88]
    7458:	b9000024 	str	w4, [x1]
    745c:	d3707f18 	ubfiz	x24, x24, #16, #32
    7460:	aa000318 	orr	x24, x24, x0
    7464:	d2800002 	mov	x2, #0x0                   	// #0
    7468:	aa1603e0 	mov	x0, x22
    746c:	b4005776 	cbz	x22, 7f58 <f12+0xda8>
    7470:	f9400800 	ldr	x0, [x0, #16]
    7474:	91000442 	add	x2, x2, #0x1
    7478:	b5ffffc0 	cbnz	x0, 7470 <f12+0x2c0>
    747c:	aa1603e1 	mov	x1, x22
    7480:	f9400821 	ldr	x1, [x1, #16]
    7484:	91000400 	add	x0, x0, #0x1
    7488:	b5ffffc1 	cbnz	x1, 7480 <f12+0x2d0>
    748c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7490:	eb01001f 	cmp	x0, x1
    7494:	540066e8 	b.hi	8170 <f12+0xfc0>  // b.pmore
    7498:	f100005f 	cmp	x2, #0x0
    749c:	540055ed 	b.le	7f58 <f12+0xda8>
    74a0:	eb00005f 	cmp	x2, x0
    74a4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    74a8:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    74ac:	eb01027f 	cmp	x19, x1
    74b0:	54006608 	b.hi	8170 <f12+0xfc0>  // b.pmore
    74b4:	d37ffa74 	lsl	x20, x19, #1
    74b8:	52800041 	mov	w1, #0x2                   	// #2
    74bc:	91000680 	add	x0, x20, #0x1
    74c0:	d37df000 	lsl	x0, x0, #3
    74c4:	97fff5cb 	bl	4bf0 <fwp_heap_alloc>
    74c8:	aa0003fb 	mov	x27, x0
    74cc:	911542a1 	add	x1, x21, #0x550
    74d0:	aa0103e0 	mov	x0, x1
    74d4:	f9000374 	str	x20, [x27]
    74d8:	f949d821 	ldr	x1, [x1, #5040]
    74dc:	f949ec00 	ldr	x0, [x0, #5080]
    74e0:	cb010361 	sub	x1, x27, x1
    74e4:	eb00403f 	cmp	x1, x0, lsl #16
    74e8:	54005802 	b.cs	7fe8 <f12+0xe38>  // b.hs, b.nlast
    74ec:	911542a2 	add	x2, x21, #0x550
    74f0:	d350fc20 	lsr	x0, x1, #16
    74f4:	8b000800 	add	x0, x0, x0, lsl #2
    74f8:	f949fc43 	ldr	x3, [x2, #5112]
    74fc:	d37df002 	lsl	x2, x0, #3
    7500:	8b020060 	add	x0, x3, x2
    7504:	f9401014 	ldr	x20, [x0, #32]
    7508:	b4000254 	cbz	x20, 7550 <f12+0x3a0>
    750c:	38626862 	ldrb	w2, [x3, x2]
    7510:	7100085f 	cmp	w2, #0x2
    7514:	54005820 	b.eq	8018 <f12+0xe68>  // b.none
    7518:	7100045f 	cmp	w2, #0x1
    751c:	540001a1 	b.ne	7550 <f12+0x3a0>  // b.any
    7520:	29430002 	ldp	w2, w0, [x0, #24]
    7524:	92403c21 	and	x1, x1, #0xffff
    7528:	9b027c21 	mul	x1, x1, x2
    752c:	d360fc21 	lsr	x1, x1, #32
    7530:	eb00003f 	cmp	x1, x0
    7534:	540000e2 	b.cs	7550 <f12+0x3a0>  // b.hs, b.nlast
    7538:	8b010294 	add	x20, x20, x1
    753c:	39400280 	ldrb	w0, [x20]
    7540:	7103fc1f 	cmp	w0, #0xff
    7544:	54005ea0 	b.eq	8118 <f12+0xf68>  // b.none
    7548:	52800020 	mov	w0, #0x1                   	// #1
    754c:	39000280 	strb	w0, [x20]
    7550:	b4000233 	cbz	x19, 7594 <f12+0x3e4>
    7554:	d3607f04 	lsl	x4, x24, #32
    7558:	aa1603e0 	mov	x0, x22
    755c:	f94006c5 	ldr	x5, [x22, #8]
    7560:	aa0403e3 	mov	x3, x4
    7564:	91002362 	add	x2, x27, #0x8
    7568:	d2800001 	mov	x1, #0x0                   	// #0
    756c:	14000005 	b	7580 <f12+0x3d0>
    7570:	f9400405 	ldr	x5, [x0, #8]
    7574:	ab010083 	adds	x3, x4, x1
    7578:	91004042 	add	x2, x2, #0x10
    757c:	54006206 	b.vs	81bc <f12+0x100c>
    7580:	a9000c45 	stp	x5, x3, [x2]
    7584:	91000421 	add	x1, x1, #0x1
    7588:	f9400800 	ldr	x0, [x0, #16]
    758c:	eb01027f 	cmp	x19, x1
    7590:	54ffff08 	b.hi	7570 <f12+0x3c0>  // b.pmore
    7594:	f9400360 	ldr	x0, [x27]
    7598:	f100041f 	cmp	x0, #0x1
    759c:	540052a9 	b.ls	7ff0 <f12+0xe40>  // b.plast
    75a0:	d341fc00 	lsr	x0, x0, #1
    75a4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    75a8:	d1000414 	sub	x20, x0, #0x1
    75ac:	eb01029f 	cmp	x20, x1
    75b0:	54005e08 	b.hi	8170 <f12+0xfc0>  // b.pmore
    75b4:	b40051f4 	cbz	x20, 7ff0 <f12+0xe40>
    75b8:	d1002361 	sub	x1, x27, #0x8
    75bc:	91002373 	add	x19, x27, #0x8
    75c0:	8b00103c 	add	x28, x1, x0, lsl #4
    75c4:	d503201f 	nop
    75c8:	f9400660 	ldr	x0, [x19, #8]
    75cc:	f9400e61 	ldr	x1, [x19, #24]
    75d0:	fd400260 	ldr	d0, [x19]
    75d4:	fd400a61 	ldr	d1, [x19, #16]
    75d8:	97fff706 	bl	51f0 <w107>
    75dc:	a9000660 	stp	x0, x1, [x19]
    75e0:	91004273 	add	x19, x19, #0x10
    75e4:	eb1c027f 	cmp	x19, x28
    75e8:	54ffff01 	b.ne	75c8 <f12+0x418>  // b.any
    75ec:	aa1b03fc 	mov	x28, x27
    75f0:	d37ffa93 	lsl	x19, x20, #1
    75f4:	d2800019 	mov	x25, #0x0                   	// #0
    75f8:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    75fc:	f8010793 	str	x19, [x28], #16
    7600:	f8797b82 	ldr	x2, [x28, x25, lsl #3]
    7604:	aa1403e0 	mov	x0, x20
    7608:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    760c:	91000b39 	add	x25, x25, #0x2
    7610:	aa0303e1 	mov	x1, x3
    7614:	97fff644 	bl	4f24 <fwp_p_ad_push>
    7618:	aa0003f4 	mov	x20, x0
    761c:	eb13033f 	cmp	x25, x19
    7620:	54ffff03 	b.cc	7600 <f12+0x450>  // b.lo, b.ul, b.last
    7624:	aa1b03e0 	mov	x0, x27
    7628:	93407f13 	sxtw	x19, w24
    762c:	97fffb8d 	bl	6460 <fwp_drop4>
    7630:	aa1303e0 	mov	x0, x19
    7634:	97fff07f 	bl	3830 <fwp_tape_of>
    7638:	f9403001 	ldr	x1, [x0, #96]
    763c:	aa0003e8 	mov	x8, x0
    7640:	b50059e1 	cbnz	x1, 817c <f12+0xfcc>
    7644:	97ffee33 	bl	2f10 <fwp_tape_unlink_scope>
    7648:	b9400002 	ldr	w2, [x0]
    764c:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    7650:	a940801c 	ldp	x28, x0, [x0, #8]
    7654:	b900051f 	str	wzr, [x8, #4]
    7658:	a941910a 	ldp	x10, x4, [x8, #24]
    765c:	a9429905 	ldp	x5, x6, [x8, #40]
    7660:	a9438d07 	ldp	x7, x3, [x8, #56]
    7664:	f940251b 	ldr	x27, [x8, #72]
    7668:	6b01005f 	cmp	w2, w1
    766c:	54000108 	b.hi	768c <f12+0x4dc>  // b.pmore
    7670:	910102e2 	add	x2, x23, #0x40
    7674:	92403e61 	and	x1, x19, #0xffff
    7678:	d1000421 	sub	x1, x1, #0x1
    767c:	f9404c49 	ldr	x9, [x2, #152]
    7680:	eb09003f 	cmp	x1, x9
    7684:	5400004a 	b.ge	768c <f12+0x4dc>  // b.tcont
    7688:	f9004c41 	str	x1, [x2, #152]
    768c:	4f000400 	movi	v0.4s, #0x0
    7690:	910102e9 	add	x9, x23, #0x40
    7694:	f9000d1f 	str	xzr, [x8, #24]
    7698:	910163e1 	add	x1, sp, #0x58
    769c:	9101c3f8 	add	x24, sp, #0x70
    76a0:	b0ffffe2 	adrp	x2, 4000 <fwp_wake_io+0x3c>
    76a4:	f941612b 	ldr	x11, [x9, #704]
    76a8:	3c808100 	stur	q0, [x8, #8]
    76ac:	91020042 	add	x2, x2, #0x80
    76b0:	ad010100 	stp	q0, q0, [x8, #32]
    76b4:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    76b8:	a9058beb 	stp	x11, x2, [sp, #88]
    76bc:	a90693f8 	stp	x24, x4, [sp, #104]
    76c0:	a9079be5 	stp	x5, x6, [sp, #120]
    76c4:	a9088fe7 	stp	x7, x3, [sp, #136]
    76c8:	a909efea 	stp	x10, x27, [sp, #152]
    76cc:	f9016121 	str	x1, [x9, #704]
    76d0:	b7f84b94 	tbnz	x20, #63, 8040 <f12+0xe90>
    76d4:	eb94827f 	cmp	x19, x20, asr #32
    76d8:	54005401 	b.ne	8158 <f12+0xfa8>  // b.any
    76dc:	92407e93 	and	x19, x20, #0xffffffff
    76e0:	eb34401f 	cmp	x0, w20, uxtw
    76e4:	5400534d 	b.le	814c <f12+0xf9c>
    76e8:	eb13039f 	cmp	x28, x19
    76ec:	9a93c793 	csinc	x19, x28, x19, gt
    76f0:	eb13037f 	cmp	x27, x19
    76f4:	5400452a 	b.ge	7f98 <f12+0xde8>  // b.tcont
    76f8:	f100037f 	cmp	x27, #0x0
    76fc:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7700:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    7704:	14000004 	b	7714 <f12+0x564>
    7708:	eb01037f 	cmp	x27, x1
    770c:	d37ffb7b 	lsl	x27, x27, #1
    7710:	9a93d37b 	csel	x27, x27, x19, le
    7714:	eb13037f 	cmp	x27, x19
    7718:	54ffff8b 	b.lt	7708 <f12+0x558>  // b.tstop
    771c:	a90117e4 	stp	x4, x5, [sp, #16]
    7720:	a9021fe6 	stp	x6, x7, [sp, #32]
    7724:	b4004ca3 	cbz	x3, 80b8 <f12+0xf08>
    7728:	aa0303e0 	mov	x0, x3
    772c:	d37df361 	lsl	x1, x27, #3
    7730:	97ffec2c 	bl	27e0 <realloc@plt>
    7734:	aa0003e3 	mov	x3, x0
    7738:	a94117e4 	ldp	x4, x5, [sp, #16]
    773c:	a9421fe6 	ldp	x6, x7, [sp, #32]
    7740:	b40042c3 	cbz	x3, 7f98 <f12+0xde8>
    7744:	f9004be3 	str	x3, [sp, #144]
    7748:	f90053fb 	str	x27, [sp, #160]
    774c:	b5001593 	cbnz	x19, 79fc <f12+0x84c>
    7750:	b7f800d4 	tbnz	x20, #63, 7768 <f12+0x5b8>
    7754:	92407e94 	and	x20, x20, #0xffffffff
    7758:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    775c:	fc747860 	ldr	d0, [x3, x20, lsl #3]
    7760:	1e612800 	fadd	d0, d0, d1
    7764:	fc347860 	str	d0, [x3, x20, lsl #3]
    7768:	d1000673 	sub	x19, x19, #0x1
    776c:	d1000788 	sub	x8, x28, #0x1
    7770:	eb13039f 	cmp	x28, x19
    7774:	540003ac 	b.gt	77e8 <f12+0x638>
    7778:	fc737860 	ldr	d0, [x3, x19, lsl #3]
    777c:	1e602008 	fcmp	d0, #0.0
    7780:	540002e0 	b.eq	77dc <f12+0x62c>  // b.none
    7784:	cb1c0be0 	neg	x0, x28, lsl #2
    7788:	cb1c03e2 	neg	x2, x28
    778c:	8b000081 	add	x1, x4, x0
    7790:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    7794:	37f80101 	tbnz	w1, #31, 77b4 <f12+0x604>
    7798:	8b020cc9 	add	x9, x6, x2, lsl #3
    779c:	93407c21 	sxtw	x1, w1
    77a0:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    77a4:	fc617861 	ldr	d1, [x3, x1, lsl #3]
    77a8:	1e620802 	fmul	d2, d0, d2
    77ac:	1e622821 	fadd	d1, d1, d2
    77b0:	fc217861 	str	d1, [x3, x1, lsl #3]
    77b4:	8b0000a0 	add	x0, x5, x0
    77b8:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    77bc:	37f80100 	tbnz	w0, #31, 77dc <f12+0x62c>
    77c0:	8b020ce2 	add	x2, x7, x2, lsl #3
    77c4:	93407c00 	sxtw	x0, w0
    77c8:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    77cc:	fc607861 	ldr	d1, [x3, x0, lsl #3]
    77d0:	1e620800 	fmul	d0, d0, d2
    77d4:	1e602820 	fadd	d0, d1, d0
    77d8:	fc207860 	str	d0, [x3, x0, lsl #3]
    77dc:	d1000673 	sub	x19, x19, #0x1
    77e0:	eb13011f 	cmp	x8, x19
    77e4:	54fffca1 	b.ne	7778 <f12+0x5c8>  // b.any
    77e8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    77ec:	eb00039f 	cmp	x28, x0
    77f0:	54004e08 	b.hi	81b0 <f12+0x1000>  // b.pmore
    77f4:	91000780 	add	x0, x28, #0x1
    77f8:	52800041 	mov	w1, #0x2                   	// #2
    77fc:	f9000be3 	str	x3, [sp, #16]
    7800:	d37df000 	lsl	x0, x0, #3
    7804:	97fff4fb 	bl	4bf0 <fwp_heap_alloc>
    7808:	aa0003e2 	mov	x2, x0
    780c:	aa0003f3 	mov	x19, x0
    7810:	f9400be3 	ldr	x3, [sp, #16]
    7814:	d2800001 	mov	x1, #0x0                   	// #0
    7818:	f800845c 	str	x28, [x2], #8
    781c:	b40000dc 	cbz	x28, 7834 <f12+0x684>
    7820:	f8617860 	ldr	x0, [x3, x1, lsl #3]
    7824:	f8217840 	str	x0, [x2, x1, lsl #3]
    7828:	91000421 	add	x1, x1, #0x1
    782c:	eb01039f 	cmp	x28, x1
    7830:	54ffff81 	b.ne	7820 <f12+0x670>  // b.any
    7834:	910102e1 	add	x1, x23, #0x40
    7838:	aa1803e0 	mov	x0, x24
    783c:	f9402ff8 	ldr	x24, [sp, #88]
    7840:	f9016038 	str	x24, [x1, #704]
    7844:	97fff20f 	bl	4080 <fwp_tape_buffers_release>
    7848:	911542a2 	add	x2, x21, #0x550
    784c:	f949d841 	ldr	x1, [x2, #5040]
    7850:	f949ec40 	ldr	x0, [x2, #5080]
    7854:	cb010261 	sub	x1, x19, x1
    7858:	eb00403f 	cmp	x1, x0, lsl #16
    785c:	54000322 	b.cs	78c0 <f12+0x710>  // b.hs, b.nlast
    7860:	d350fc20 	lsr	x0, x1, #16
    7864:	f949fc43 	ldr	x3, [x2, #5112]
    7868:	8b000800 	add	x0, x0, x0, lsl #2
    786c:	d37df002 	lsl	x2, x0, #3
    7870:	8b020060 	add	x0, x3, x2
    7874:	f9401014 	ldr	x20, [x0, #32]
    7878:	b4000254 	cbz	x20, 78c0 <f12+0x710>
    787c:	38626862 	ldrb	w2, [x3, x2]
    7880:	7100085f 	cmp	w2, #0x2
    7884:	54003e20 	b.eq	8048 <f12+0xe98>  // b.none
    7888:	7100045f 	cmp	w2, #0x1
    788c:	540001a1 	b.ne	78c0 <f12+0x710>  // b.any
    7890:	29430002 	ldp	w2, w0, [x0, #24]
    7894:	92403c21 	and	x1, x1, #0xffff
    7898:	9b027c21 	mul	x1, x1, x2
    789c:	d360fc21 	lsr	x1, x1, #32
    78a0:	eb00003f 	cmp	x1, x0
    78a4:	540000e2 	b.cs	78c0 <f12+0x710>  // b.hs, b.nlast
    78a8:	8b010294 	add	x20, x20, x1
    78ac:	39400280 	ldrb	w0, [x20]
    78b0:	7103fc1f 	cmp	w0, #0xff
    78b4:	540042c0 	b.eq	810c <f12+0xf5c>  // b.none
    78b8:	52800020 	mov	w0, #0x1                   	// #1
    78bc:	39000280 	strb	w0, [x20]
    78c0:	eb1a031f 	cmp	x24, x26
    78c4:	540047e1 	b.ne	81c0 <f12+0x1010>  // b.any
    78c8:	f94007e0 	ldr	x0, [sp, #8]
    78cc:	910102f7 	add	x23, x23, #0x40
    78d0:	f94023e1 	ldr	x1, [sp, #64]
    78d4:	f90162e1 	str	x1, [x23, #704]
    78d8:	97fff98e 	bl	5f10 <fwp_tape_scope_release>
    78dc:	f9400260 	ldr	x0, [x19]
    78e0:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    78e4:	b7f82e60 	tbnz	x0, #63, 7eb0 <f12+0xd00>
    78e8:	911542a2 	add	x2, x21, #0x550
    78ec:	f949d840 	ldr	x0, [x2, #5040]
    78f0:	f949ec41 	ldr	x1, [x2, #5080]
    78f4:	cb000260 	sub	x0, x19, x0
    78f8:	eb01401f 	cmp	x0, x1, lsl #16
    78fc:	54002da2 	b.cs	7eb0 <f12+0xd00>  // b.hs, b.nlast
    7900:	d350fc01 	lsr	x1, x0, #16
    7904:	f949fc44 	ldr	x4, [x2, #5112]
    7908:	8b010821 	add	x1, x1, x1, lsl #2
    790c:	d37df021 	lsl	x1, x1, #3
    7910:	8b010083 	add	x3, x4, x1
    7914:	f9401062 	ldr	x2, [x3, #32]
    7918:	b4002cc2 	cbz	x2, 7eb0 <f12+0xd00>
    791c:	38616881 	ldrb	w1, [x4, x1]
    7920:	7100083f 	cmp	w1, #0x2
    7924:	54002c00 	b.eq	7ea4 <f12+0xcf4>  // b.none
    7928:	7100043f 	cmp	w1, #0x1
    792c:	54002c21 	b.ne	7eb0 <f12+0xd00>  // b.any
    7930:	29430464 	ldp	w4, w1, [x3, #24]
    7934:	92403c00 	and	x0, x0, #0xffff
    7938:	9b047c00 	mul	x0, x0, x4
    793c:	d360fc00 	lsr	x0, x0, #32
    7940:	eb01001f 	cmp	x0, x1
    7944:	54002b62 	b.cs	7eb0 <f12+0xd00>  // b.hs, b.nlast
    7948:	8b000042 	add	x2, x2, x0
    794c:	39400040 	ldrb	w0, [x2]
    7950:	7100041f 	cmp	w0, #0x1
    7954:	54002ae1 	b.ne	7eb0 <f12+0xd00>  // b.any
    7958:	aa1303fa 	mov	x26, x19
    795c:	d2800000 	mov	x0, #0x0                   	// #0
    7960:	f90007f3 	str	x19, [sp, #8]
    7964:	f94007e1 	ldr	x1, [sp, #8]
    7968:	91002023 	add	x3, x1, #0x8
    796c:	d2800001 	mov	x1, #0x0                   	// #0
    7970:	b40005b4 	cbz	x20, 7a24 <f12+0x874>
    7974:	d0000022 	adrp	x2, d000 <__modti3+0x320>
    7978:	91002265 	add	x5, x19, #0x8
    797c:	fd46a841 	ldr	d1, [x2, #3408]
    7980:	14000009 	b	79a4 <f12+0x7f4>
    7984:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7988:	f9400342 	ldr	x2, [x26]
    798c:	1e600820 	fmul	d0, d1, d0
    7990:	b7f83ea2 	tbnz	x2, #63, 8164 <f12+0xfb4>
    7994:	91000421 	add	x1, x1, #0x1
    7998:	fc008460 	str	d0, [x3], #8
    799c:	eb01029f 	cmp	x20, x1
    79a0:	54000420 	b.eq	7a24 <f12+0x874>  // b.none
    79a4:	f9400264 	ldr	x4, [x19]
    79a8:	aa0503e2 	mov	x2, x5
    79ac:	b6fffec4 	tbz	x4, #63, 7984 <f12+0x7d4>
    79b0:	f9400a62 	ldr	x2, [x19, #16]
    79b4:	17fffff4 	b	7984 <f12+0x7d4>
    79b8:	eb1b029f 	cmp	x20, x27
    79bc:	54ffcb80 	b.eq	732c <f12+0x17c>  // b.none
    79c0:	f94022f9 	ldr	x25, [x23, #64]
    79c4:	8b1b0774 	add	x20, x27, x27, lsl #1
    79c8:	d0000020 	adrp	x0, d000 <__modti3+0x320>
    79cc:	910ae000 	add	x0, x0, #0x2b8
    79d0:	8b140b74 	add	x20, x27, x20, lsl #2
    79d4:	8b140f34 	add	x20, x25, x20, lsl #3
    79d8:	f900329f 	str	xzr, [x20, #96]
    79dc:	97ffebe9 	bl	2980 <getenv@plt>
    79e0:	b4ffcfc0 	cbz	x0, 73d8 <f12+0x228>
    79e4:	39400001 	ldrb	w1, [x0]
    79e8:	7100c03f 	cmp	w1, #0x30
    79ec:	54ffcf61 	b.ne	73d8 <f12+0x228>  // b.any
    79f0:	39400400 	ldrb	w0, [x0, #1]
    79f4:	34ffcf80 	cbz	w0, 73e4 <f12+0x234>
    79f8:	17fffe78 	b	73d8 <f12+0x228>
    79fc:	aa0303e0 	mov	x0, x3
    7a00:	d37df262 	lsl	x2, x19, #3
    7a04:	52800001 	mov	w1, #0x0                   	// #0
    7a08:	a90117e4 	stp	x4, x5, [sp, #16]
    7a0c:	a9021fe6 	stp	x6, x7, [sp, #32]
    7a10:	97ffeb6c 	bl	27c0 <memset@plt>
    7a14:	aa0003e3 	mov	x3, x0
    7a18:	a94117e4 	ldp	x4, x5, [sp, #16]
    7a1c:	a9421fe6 	ldp	x6, x7, [sp, #32]
    7a20:	17ffff4c 	b	7750 <f12+0x5a0>
    7a24:	97fffa8f 	bl	6460 <fwp_drop4>
    7a28:	aa1603e1 	mov	x1, x22
    7a2c:	d2800002 	mov	x2, #0x0                   	// #0
    7a30:	b4003536 	cbz	x22, 80d4 <f12+0xf24>
    7a34:	d503201f 	nop
    7a38:	f9400821 	ldr	x1, [x1, #16]
    7a3c:	91000442 	add	x2, x2, #0x1
    7a40:	b5ffffc1 	cbnz	x1, 7a38 <f12+0x888>
    7a44:	f9400343 	ldr	x3, [x26]
    7a48:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7a4c:	b7f81f43 	tbnz	x3, #63, 7e34 <f12+0xc84>
    7a50:	911542a1 	add	x1, x21, #0x550
    7a54:	f94007e4 	ldr	x4, [sp, #8]
    7a58:	f949d820 	ldr	x0, [x1, #5040]
    7a5c:	f949ec21 	ldr	x1, [x1, #5080]
    7a60:	cb000080 	sub	x0, x4, x0
    7a64:	eb01401f 	cmp	x0, x1, lsl #16
    7a68:	54001e62 	b.cs	7e34 <f12+0xc84>  // b.hs, b.nlast
    7a6c:	911542a4 	add	x4, x21, #0x550
    7a70:	d350fc01 	lsr	x1, x0, #16
    7a74:	8b010821 	add	x1, x1, x1, lsl #2
    7a78:	f949fc86 	ldr	x6, [x4, #5112]
    7a7c:	d37df021 	lsl	x1, x1, #3
    7a80:	8b0100c5 	add	x5, x6, x1
    7a84:	f94010a4 	ldr	x4, [x5, #32]
    7a88:	b4001d44 	cbz	x4, 7e30 <f12+0xc80>
    7a8c:	386168c1 	ldrb	w1, [x6, x1]
    7a90:	7100083f 	cmp	w1, #0x2
    7a94:	54001ca0 	b.eq	7e28 <f12+0xc78>  // b.none
    7a98:	7100043f 	cmp	w1, #0x1
    7a9c:	54001ca1 	b.ne	7e30 <f12+0xc80>  // b.any
    7aa0:	294304a6 	ldp	w6, w1, [x5, #24]
    7aa4:	92403c00 	and	x0, x0, #0xffff
    7aa8:	9b067c00 	mul	x0, x0, x6
    7aac:	d360fc00 	lsr	x0, x0, #32
    7ab0:	eb01001f 	cmp	x0, x1
    7ab4:	54001be2 	b.cs	7e30 <f12+0xc80>  // b.hs, b.nlast
    7ab8:	8b000084 	add	x4, x4, x0
    7abc:	39400098 	ldrb	w24, [x4]
    7ac0:	7100071f 	cmp	w24, #0x1
    7ac4:	54001b61 	b.ne	7e30 <f12+0xc80>  // b.any
    7ac8:	b90013f8 	str	w24, [sp, #16]
    7acc:	eb02039f 	cmp	x28, x2
    7ad0:	9a82939c 	csel	x28, x28, x2, ls	// ls = plast
    7ad4:	91002359 	add	x25, x26, #0x8
    7ad8:	b400335c 	cbz	x28, 8140 <f12+0xf90>
    7adc:	f94007e0 	ldr	x0, [sp, #8]
    7ae0:	d37df385 	lsl	x5, x28, #3
    7ae4:	aa1603e2 	mov	x2, x22
    7ae8:	d2800001 	mov	x1, #0x0                   	// #0
    7aec:	91002000 	add	x0, x0, #0x8
    7af0:	1400000a 	b	7b18 <f12+0x968>
    7af4:	fc616881 	ldr	d1, [x4, x1]
    7af8:	fd400440 	ldr	d0, [x2, #8]
    7afc:	1e613800 	fsub	d0, d0, d1
    7b00:	fc216b20 	str	d0, [x25, x1]
    7b04:	91002021 	add	x1, x1, #0x8
    7b08:	f9400842 	ldr	x2, [x2, #16]
    7b0c:	eb05003f 	cmp	x1, x5
    7b10:	540001c0 	b.eq	7b48 <f12+0x998>  // b.none
    7b14:	f9400343 	ldr	x3, [x26]
    7b18:	aa0003e4 	mov	x4, x0
    7b1c:	b6fffec3 	tbz	x3, #63, 7af4 <f12+0x944>
    7b20:	f94007e3 	ldr	x3, [sp, #8]
    7b24:	fd400440 	ldr	d0, [x2, #8]
    7b28:	f9400864 	ldr	x4, [x3, #16]
    7b2c:	fc616881 	ldr	d1, [x4, x1]
    7b30:	1e613800 	fsub	d0, d0, d1
    7b34:	fc216b20 	str	d0, [x25, x1]
    7b38:	91002021 	add	x1, x1, #0x8
    7b3c:	f9400842 	ldr	x2, [x2, #16]
    7b40:	eb05003f 	cmp	x1, x5
    7b44:	54fffe81 	b.ne	7b14 <f12+0x964>  // b.any
    7b48:	b4002f96 	cbz	x22, 8138 <f12+0xf88>
    7b4c:	911542a0 	add	x0, x21, #0x550
    7b50:	aa1603e2 	mov	x2, x22
    7b54:	d280001a 	mov	x26, #0x0                   	// #0
    7b58:	f949ec06 	ldr	x6, [x0, #5080]
    7b5c:	f949d807 	ldr	x7, [x0, #5040]
    7b60:	f949fc05 	ldr	x5, [x0, #5112]
    7b64:	d370bcc6 	lsl	x6, x6, #16
    7b68:	14000006 	b	7b80 <f12+0x9d0>
    7b6c:	f9400842 	ldr	x2, [x2, #16]
    7b70:	9100075a 	add	x26, x26, #0x1
    7b74:	f100005f 	cmp	x2, #0x0
    7b78:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    7b7c:	54000329 	b.ls	7be0 <f12+0xa30>  // b.plast
    7b80:	cb070040 	sub	x0, x2, x7
    7b84:	eb06001f 	cmp	x0, x6
    7b88:	540002c2 	b.cs	7be0 <f12+0xa30>  // b.hs, b.nlast
    7b8c:	d350fc01 	lsr	x1, x0, #16
    7b90:	8b010821 	add	x1, x1, x1, lsl #2
    7b94:	d37df021 	lsl	x1, x1, #3
    7b98:	8b0100a4 	add	x4, x5, x1
    7b9c:	f9401083 	ldr	x3, [x4, #32]
    7ba0:	b4000203 	cbz	x3, 7be0 <f12+0xa30>
    7ba4:	386168a1 	ldrb	w1, [x5, x1]
    7ba8:	7100083f 	cmp	w1, #0x2
    7bac:	54000de0 	b.eq	7d68 <f12+0xbb8>  // b.none
    7bb0:	7100043f 	cmp	w1, #0x1
    7bb4:	54000161 	b.ne	7be0 <f12+0xa30>  // b.any
    7bb8:	29430488 	ldp	w8, w1, [x4, #24]
    7bbc:	92403c00 	and	x0, x0, #0xffff
    7bc0:	9b087c00 	mul	x0, x0, x8
    7bc4:	d360fc00 	lsr	x0, x0, #32
    7bc8:	eb01001f 	cmp	x0, x1
    7bcc:	540000a2 	b.cs	7be0 <f12+0xa30>  // b.hs, b.nlast
    7bd0:	8b000063 	add	x3, x3, x0
    7bd4:	39400060 	ldrb	w0, [x3]
    7bd8:	7100041f 	cmp	w0, #0x1
    7bdc:	54fffc80 	b.eq	7b6c <f12+0x9bc>  // b.none
    7be0:	eb1a039f 	cmp	x28, x26
    7be4:	54000ca9 	b.ls	7d78 <f12+0xbc8>  // b.plast
    7be8:	d1002337 	sub	x23, x25, #0x8
    7bec:	9102a3f4 	add	x20, sp, #0xa8
    7bf0:	911542b8 	add	x24, x21, #0x550
    7bf4:	d2800013 	mov	x19, #0x0                   	// #0
    7bf8:	14000012 	b	7c40 <f12+0xa90>
    7bfc:	7100045f 	cmp	w2, #0x1
    7c00:	540001a1 	b.ne	7c34 <f12+0xa84>  // b.any
    7c04:	29430002 	ldp	w2, w0, [x0, #24]
    7c08:	92403c21 	and	x1, x1, #0xffff
    7c0c:	9b027c21 	mul	x1, x1, x2
    7c10:	d360fc21 	lsr	x1, x1, #32
    7c14:	eb00003f 	cmp	x1, x0
    7c18:	540000e2 	b.cs	7c34 <f12+0xa84>  // b.hs, b.nlast
    7c1c:	8b01037b 	add	x27, x27, x1
    7c20:	39400360 	ldrb	w0, [x27]
    7c24:	7103fc1f 	cmp	w0, #0xff
    7c28:	54001b20 	b.eq	7f8c <f12+0xddc>  // b.none
    7c2c:	52800020 	mov	w0, #0x1                   	// #1
    7c30:	39000360 	strb	w0, [x27]
    7c34:	d100079c 	sub	x28, x28, #0x1
    7c38:	eb1a039f 	cmp	x28, x26
    7c3c:	54000369 	b.ls	7ca8 <f12+0xaf8>  // b.plast
    7c40:	f87c7ae2 	ldr	x2, [x23, x28, lsl #3]
    7c44:	aa1403e1 	mov	x1, x20
    7c48:	52800020 	mov	w0, #0x1                   	// #1
    7c4c:	a90acfe2 	stp	x2, x19, [sp, #168]
    7c50:	97fff5ac 	bl	5300 <fwp_data.part.0.constprop.0>
    7c54:	aa0003f3 	mov	x19, x0
    7c58:	f949db01 	ldr	x1, [x24, #5040]
    7c5c:	f949ef00 	ldr	x0, [x24, #5080]
    7c60:	cb010261 	sub	x1, x19, x1
    7c64:	eb00403f 	cmp	x1, x0, lsl #16
    7c68:	54fffe62 	b.cs	7c34 <f12+0xa84>  // b.hs, b.nlast
    7c6c:	d350fc22 	lsr	x2, x1, #16
    7c70:	f949ff03 	ldr	x3, [x24, #5112]
    7c74:	8b020842 	add	x2, x2, x2, lsl #2
    7c78:	d37df042 	lsl	x2, x2, #3
    7c7c:	8b020060 	add	x0, x3, x2
    7c80:	f940101b 	ldr	x27, [x0, #32]
    7c84:	b4fffd9b 	cbz	x27, 7c34 <f12+0xa84>
    7c88:	38626862 	ldrb	w2, [x3, x2]
    7c8c:	7100085f 	cmp	w2, #0x2
    7c90:	54fffb61 	b.ne	7bfc <f12+0xa4c>  // b.any
    7c94:	72003c3f 	tst	w1, #0xffff
    7c98:	54fffc40 	b.eq	7c20 <f12+0xa70>  // b.none
    7c9c:	d100079c 	sub	x28, x28, #0x1
    7ca0:	eb1a039f 	cmp	x28, x26
    7ca4:	54fffce8 	b.hi	7c40 <f12+0xa90>  // b.pmore
    7ca8:	b50006ba 	cbnz	x26, 7d7c <f12+0xbcc>
    7cac:	b94013e0 	ldr	w0, [sp, #16]
    7cb0:	d2800038 	mov	x24, #0x1                   	// #1
    7cb4:	d280001b 	mov	x27, #0x0                   	// #0
    7cb8:	7100001f 	cmp	w0, #0x0
    7cbc:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7cc0:	b40007db 	cbz	x27, 7db8 <f12+0xc08>
    7cc4:	d100077b 	sub	x27, x27, #0x1
    7cc8:	911542b5 	add	x21, x21, #0x550
    7ccc:	d503201f 	nop
    7cd0:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    7cd4:	aa1403e1 	mov	x1, x20
    7cd8:	52800020 	mov	w0, #0x1                   	// #1
    7cdc:	a90acfe2 	stp	x2, x19, [sp, #168]
    7ce0:	97fff588 	bl	5300 <fwp_data.part.0.constprop.0>
    7ce4:	aa0003f3 	mov	x19, x0
    7ce8:	f949daa1 	ldr	x1, [x21, #5040]
    7cec:	f949eea0 	ldr	x0, [x21, #5080]
    7cf0:	cb010261 	sub	x1, x19, x1
    7cf4:	eb00403f 	cmp	x1, x0, lsl #16
    7cf8:	54000302 	b.cs	7d58 <f12+0xba8>  // b.hs, b.nlast
    7cfc:	d350fc22 	lsr	x2, x1, #16
    7d00:	f949fea3 	ldr	x3, [x21, #5112]
    7d04:	8b020842 	add	x2, x2, x2, lsl #2
    7d08:	d37df042 	lsl	x2, x2, #3
    7d0c:	8b020060 	add	x0, x3, x2
    7d10:	f940101a 	ldr	x26, [x0, #32]
    7d14:	b400023a 	cbz	x26, 7d58 <f12+0xba8>
    7d18:	38626862 	ldrb	w2, [x3, x2]
    7d1c:	7100085f 	cmp	w2, #0x2
    7d20:	540007e0 	b.eq	7e1c <f12+0xc6c>  // b.none
    7d24:	7100045f 	cmp	w2, #0x1
    7d28:	54000181 	b.ne	7d58 <f12+0xba8>  // b.any
    7d2c:	29430002 	ldp	w2, w0, [x0, #24]
    7d30:	92403c21 	and	x1, x1, #0xffff
    7d34:	9b027c21 	mul	x1, x1, x2
    7d38:	d360fc21 	lsr	x1, x1, #32
    7d3c:	eb00003f 	cmp	x1, x0
    7d40:	540000c2 	b.cs	7d58 <f12+0xba8>  // b.hs, b.nlast
    7d44:	8b01035a 	add	x26, x26, x1
    7d48:	39400340 	ldrb	w0, [x26]
    7d4c:	7103fc1f 	cmp	w0, #0xff
    7d50:	54000600 	b.eq	7e10 <f12+0xc60>  // b.none
    7d54:	39000358 	strb	w24, [x26]
    7d58:	d100077b 	sub	x27, x27, #0x1
    7d5c:	b100077f 	cmn	x27, #0x1
    7d60:	54fffb81 	b.ne	7cd0 <f12+0xb20>  // b.any
    7d64:	14000015 	b	7db8 <f12+0xc08>
    7d68:	72003c1f 	tst	w0, #0xffff
    7d6c:	54fff340 	b.eq	7bd4 <f12+0xa24>  // b.none
    7d70:	eb1a039f 	cmp	x28, x26
    7d74:	54fff3a8 	b.hi	7be8 <f12+0xa38>  // b.pmore
    7d78:	d2800013 	mov	x19, #0x0                   	// #0
    7d7c:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    7d80:	aa1903e1 	mov	x1, x25
    7d84:	aa1603e0 	mov	x0, x22
    7d88:	f8408422 	ldr	x2, [x1], #8
    7d8c:	f9000402 	str	x2, [x0, #8]
    7d90:	aa0003e2 	mov	x2, x0
    7d94:	f9400800 	ldr	x0, [x0, #16]
    7d98:	eb1a003f 	cmp	x1, x26
    7d9c:	54ffff61 	b.ne	7d88 <f12+0xbd8>  // b.any
    7da0:	b94013e1 	ldr	w1, [sp, #16]
    7da4:	f9000853 	str	x19, [x2, #16]
    7da8:	aa1603f3 	mov	x19, x22
    7dac:	aa0003f6 	mov	x22, x0
    7db0:	34000041 	cbz	w1, 7db8 <f12+0xc08>
    7db4:	d2800019 	mov	x25, #0x0                   	// #0
    7db8:	aa1903e0 	mov	x0, x25
    7dbc:	97fff26d 	bl	4770 <fwp_mem_free>
    7dc0:	f94007e0 	ldr	x0, [sp, #8]
    7dc4:	97fff9a7 	bl	6460 <fwp_drop4>
    7dc8:	aa1603e0 	mov	x0, x22
    7dcc:	97fff715 	bl	5a20 <fwp_drop0>
    7dd0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7dd4:	f947f400 	ldr	x0, [x0, #4072]
    7dd8:	f9405fe2 	ldr	x2, [sp, #184]
    7ddc:	f9400001 	ldr	x1, [x0]
    7de0:	eb010042 	subs	x2, x2, x1
    7de4:	d2800001 	mov	x1, #0x0                   	// #0
    7de8:	54001dc1 	b.ne	81a0 <f12+0xff0>  // b.any
    7dec:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    7df0:	aa1303e0 	mov	x0, x19
    7df4:	a94d53f3 	ldp	x19, x20, [sp, #208]
    7df8:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    7dfc:	a94f63f7 	ldp	x23, x24, [sp, #240]
    7e00:	a9506bf9 	ldp	x25, x26, [sp, #256]
    7e04:	a95173fb 	ldp	x27, x28, [sp, #272]
    7e08:	910483ff 	add	sp, sp, #0x120
    7e0c:	d65f03c0 	ret
    7e10:	aa1a03e0 	mov	x0, x26
    7e14:	97fff1b7 	bl	44f0 <fwp_rc_forget_slot>
    7e18:	17ffffcf 	b	7d54 <f12+0xba4>
    7e1c:	72003c3f 	tst	w1, #0xffff
    7e20:	54fff9c1 	b.ne	7d58 <f12+0xba8>  // b.any
    7e24:	17ffffc9 	b	7d48 <f12+0xb98>
    7e28:	72003c1f 	tst	w0, #0xffff
    7e2c:	54ffe480 	b.eq	7abc <f12+0x90c>  // b.none
    7e30:	b4001316 	cbz	x22, 8090 <f12+0xee0>
    7e34:	aa1603f3 	mov	x19, x22
    7e38:	d2800014 	mov	x20, #0x0                   	// #0
    7e3c:	d503201f 	nop
    7e40:	f9400a73 	ldr	x19, [x19, #16]
    7e44:	aa1403e0 	mov	x0, x20
    7e48:	91000694 	add	x20, x20, #0x1
    7e4c:	b5ffffb3 	cbnz	x19, 7e40 <f12+0xc90>
    7e50:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7e54:	eb01029f 	cmp	x20, x1
    7e58:	540018c8 	b.hi	8170 <f12+0xfc0>  // b.pmore
    7e5c:	91000800 	add	x0, x0, #0x2
    7e60:	52800041 	mov	w1, #0x2                   	// #2
    7e64:	d37df000 	lsl	x0, x0, #3
    7e68:	97fff362 	bl	4bf0 <fwp_heap_alloc>
    7e6c:	eb14039f 	cmp	x28, x20
    7e70:	aa0003f9 	mov	x25, x0
    7e74:	9a94939c 	csel	x28, x28, x20, ls	// ls = plast
    7e78:	aa1603e1 	mov	x1, x22
    7e7c:	d503201f 	nop
    7e80:	f9400420 	ldr	x0, [x1, #8]
    7e84:	f8337b20 	str	x0, [x25, x19, lsl #3]
    7e88:	91000673 	add	x19, x19, #0x1
    7e8c:	f9400821 	ldr	x1, [x1, #16]
    7e90:	b5ffff81 	cbnz	x1, 7e80 <f12+0xcd0>
    7e94:	b400107c 	cbz	x28, 80a0 <f12+0xef0>
    7e98:	f9400343 	ldr	x3, [x26]
    7e9c:	b90013ff 	str	wzr, [sp, #16]
    7ea0:	17ffff0f 	b	7adc <f12+0x92c>
    7ea4:	72003c1f 	tst	w0, #0xffff
    7ea8:	54ffd520 	b.eq	794c <f12+0x79c>  // b.none
    7eac:	d503201f 	nop
    7eb0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7eb4:	eb00029f 	cmp	x20, x0
    7eb8:	540017c8 	b.hi	81b0 <f12+0x1000>  // b.pmore
    7ebc:	91000680 	add	x0, x20, #0x1
    7ec0:	52800021 	mov	w1, #0x1                   	// #1
    7ec4:	d37df000 	lsl	x0, x0, #3
    7ec8:	97fff34a 	bl	4bf0 <fwp_heap_alloc>
    7ecc:	911542a2 	add	x2, x21, #0x550
    7ed0:	f9000014 	str	x20, [x0]
    7ed4:	aa0003fa 	mov	x26, x0
    7ed8:	f90007fa 	str	x26, [sp, #8]
    7edc:	f949d841 	ldr	x1, [x2, #5040]
    7ee0:	f949ec40 	ldr	x0, [x2, #5080]
    7ee4:	cb010341 	sub	x1, x26, x1
    7ee8:	eb00403f 	cmp	x1, x0, lsl #16
    7eec:	54000322 	b.cs	7f50 <f12+0xda0>  // b.hs, b.nlast
    7ef0:	d350fc20 	lsr	x0, x1, #16
    7ef4:	f949fc43 	ldr	x3, [x2, #5112]
    7ef8:	8b000800 	add	x0, x0, x0, lsl #2
    7efc:	d37df002 	lsl	x2, x0, #3
    7f00:	8b020060 	add	x0, x3, x2
    7f04:	f9401018 	ldr	x24, [x0, #32]
    7f08:	b4000258 	cbz	x24, 7f50 <f12+0xda0>
    7f0c:	38626862 	ldrb	w2, [x3, x2]
    7f10:	7100085f 	cmp	w2, #0x2
    7f14:	54000ca0 	b.eq	80a8 <f12+0xef8>  // b.none
    7f18:	7100045f 	cmp	w2, #0x1
    7f1c:	540001a1 	b.ne	7f50 <f12+0xda0>  // b.any
    7f20:	29430002 	ldp	w2, w0, [x0, #24]
    7f24:	92403c21 	and	x1, x1, #0xffff
    7f28:	9b027c21 	mul	x1, x1, x2
    7f2c:	d360fc21 	lsr	x1, x1, #32
    7f30:	eb00003f 	cmp	x1, x0
    7f34:	540000e2 	b.cs	7f50 <f12+0xda0>  // b.hs, b.nlast
    7f38:	8b010318 	add	x24, x24, x1
    7f3c:	39400300 	ldrb	w0, [x24]
    7f40:	7103fc1f 	cmp	w0, #0xff
    7f44:	54000f00 	b.eq	8124 <f12+0xf74>  // b.none
    7f48:	52800020 	mov	w0, #0x1                   	// #1
    7f4c:	39000300 	strb	w0, [x24]
    7f50:	aa1303e0 	mov	x0, x19
    7f54:	17fffe84 	b	7964 <f12+0x7b4>
    7f58:	52800041 	mov	w1, #0x2                   	// #2
    7f5c:	d2800100 	mov	x0, #0x8                   	// #8
    7f60:	97fff324 	bl	4bf0 <fwp_heap_alloc>
    7f64:	aa0003fb 	mov	x27, x0
    7f68:	911542a0 	add	x0, x21, #0x550
    7f6c:	f900037f 	str	xzr, [x27]
    7f70:	f949d801 	ldr	x1, [x0, #5040]
    7f74:	f949ec00 	ldr	x0, [x0, #5080]
    7f78:	cb010361 	sub	x1, x27, x1
    7f7c:	eb00403f 	cmp	x1, x0, lsl #16
    7f80:	54000382 	b.cs	7ff0 <f12+0xe40>  // b.hs, b.nlast
    7f84:	d2800013 	mov	x19, #0x0                   	// #0
    7f88:	17fffd59 	b	74ec <f12+0x33c>
    7f8c:	aa1b03e0 	mov	x0, x27
    7f90:	97fff158 	bl	44f0 <fwp_rc_forget_slot>
    7f94:	17ffff26 	b	7c2c <f12+0xa7c>
    7f98:	f100027f 	cmp	x19, #0x0
    7f9c:	fa401860 	ccmp	x3, #0x0, #0x0, ne	// ne = any
    7fa0:	54ffbd61 	b.ne	774c <f12+0x59c>  // b.any
    7fa4:	f9402fe1 	ldr	x1, [sp, #88]
    7fa8:	910102f7 	add	x23, x23, #0x40
    7fac:	aa1803e0 	mov	x0, x24
    7fb0:	f90162e1 	str	x1, [x23, #704]
    7fb4:	97fff033 	bl	4080 <fwp_tape_buffers_release>
    7fb8:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7fbc:	f947e863 	ldr	x3, [x3, #4048]
    7fc0:	d2800262 	mov	x2, #0x13                  	// #19
    7fc4:	d2800021 	mov	x1, #0x1                   	// #1
    7fc8:	d0000020 	adrp	x0, d000 <__modti3+0x320>
    7fcc:	91022000 	add	x0, x0, #0x88
    7fd0:	f9400063 	ldr	x3, [x3]
    7fd4:	97ffea47 	bl	28f0 <fwrite@plt>
    7fd8:	d2800000 	mov	x0, #0x0                   	// #0
    7fdc:	97ffea51 	bl	2920 <fflush@plt>
    7fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    7fe4:	97ffea5f 	bl	2960 <_Exit@plt>
    7fe8:	b5ffab73 	cbnz	x19, 7554 <f12+0x3a4>
    7fec:	d503201f 	nop
    7ff0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7ff4:	f900037f 	str	xzr, [x27]
    7ff8:	17fffd8b 	b	7624 <f12+0x474>
    7ffc:	d0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0xdc>
    8000:	91384000 	add	x0, x0, #0xe10
    8004:	94001413 	bl	d050 <atexit>
    8008:	35fffd80 	cbnz	w0, 7fb8 <f12+0xe08>
    800c:	52800020 	mov	w0, #0x1                   	// #1
    8010:	b902f680 	str	w0, [x20, #756]
    8014:	17fffcb3 	b	72e0 <f12+0x130>
    8018:	72003c3f 	tst	w1, #0xffff
    801c:	54ffa9a1 	b.ne	7550 <f12+0x3a0>  // b.any
    8020:	17fffd47 	b	753c <f12+0x38c>
    8024:	72003c3f 	tst	w1, #0xffff
    8028:	54ff9320 	b.eq	728c <f12+0xdc>  // b.none
    802c:	aa1403e0 	mov	x0, x20
    8030:	97fff6d8 	bl	5b90 <fwp_closure_drop>
    8034:	b5ff93f6 	cbnz	x22, 72b0 <f12+0x100>
    8038:	d280001c 	mov	x28, #0x0                   	// #0
    803c:	17fffca6 	b	72d4 <f12+0x124>
    8040:	aa1c03f3 	mov	x19, x28
    8044:	17fffdab 	b	76f0 <f12+0x540>
    8048:	72003c3f 	tst	w1, #0xffff
    804c:	54ffc3a1 	b.ne	78c0 <f12+0x710>  // b.any
    8050:	17fffe17 	b	78ac <f12+0x6fc>
    8054:	3cc48002 	ldur	q2, [x0, #72]
    8058:	91012001 	add	x1, x0, #0x48
    805c:	3cc58001 	ldur	q1, [x0, #88]
    8060:	f900401f 	str	xzr, [x0, #128]
    8064:	4f000400 	movi	v0.4s, #0x0
    8068:	ad010682 	stp	q2, q1, [x20, #32]
    806c:	a9468002 	ldp	x2, x0, [x0, #104]
    8070:	f9000e80 	str	x0, [x20, #24]
    8074:	f9401820 	ldr	x0, [x1, #48]
    8078:	f9002282 	str	x2, [x20, #64]
    807c:	f9002680 	str	x0, [x20, #72]
    8080:	ad000020 	stp	q0, q0, [x1]
    8084:	3d800820 	str	q0, [x1, #32]
    8088:	f900183f 	str	xzr, [x1, #48]
    808c:	17fffcd6 	b	73e4 <f12+0x234>
    8090:	52800041 	mov	w1, #0x2                   	// #2
    8094:	d2800100 	mov	x0, #0x8                   	// #8
    8098:	97fff2d6 	bl	4bf0 <fwp_heap_alloc>
    809c:	aa0003f9 	mov	x25, x0
    80a0:	d2800013 	mov	x19, #0x0                   	// #0
    80a4:	17ffff45 	b	7db8 <f12+0xc08>
    80a8:	72003c3f 	tst	w1, #0xffff
    80ac:	54fff480 	b.eq	7f3c <f12+0xd8c>  // b.none
    80b0:	aa1303e0 	mov	x0, x19
    80b4:	17fffe2c 	b	7964 <f12+0x7b4>
    80b8:	aa1b03e0 	mov	x0, x27
    80bc:	d2800101 	mov	x1, #0x8                   	// #8
    80c0:	97ffe9c4 	bl	27d0 <calloc@plt>
    80c4:	aa0003e3 	mov	x3, x0
    80c8:	a94117e4 	ldp	x4, x5, [sp, #16]
    80cc:	a9421fe6 	ldp	x6, x7, [sp, #32]
    80d0:	17fffd9c 	b	7740 <f12+0x590>
    80d4:	f9400343 	ldr	x3, [x26]
    80d8:	b7fffdc3 	tbnz	x3, #63, 8090 <f12+0xee0>
    80dc:	911542a1 	add	x1, x21, #0x550
    80e0:	f94007e4 	ldr	x4, [sp, #8]
    80e4:	f949d820 	ldr	x0, [x1, #5040]
    80e8:	f949ec21 	ldr	x1, [x1, #5080]
    80ec:	cb000080 	sub	x0, x4, x0
    80f0:	eb01401f 	cmp	x0, x1, lsl #16
    80f4:	54fffce2 	b.cs	8090 <f12+0xee0>  // b.hs, b.nlast
    80f8:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    80fc:	17fffe5c 	b	7a6c <f12+0x8bc>
    8100:	d2800d01 	mov	x1, #0x68                  	// #104
    8104:	d2800038 	mov	x24, #0x1                   	// #1
    8108:	17fffc99 	b	736c <f12+0x1bc>
    810c:	aa1403e0 	mov	x0, x20
    8110:	97fff0f8 	bl	44f0 <fwp_rc_forget_slot>
    8114:	17fffde9 	b	78b8 <f12+0x708>
    8118:	aa1403e0 	mov	x0, x20
    811c:	97fff0f5 	bl	44f0 <fwp_rc_forget_slot>
    8120:	17fffd0a 	b	7548 <f12+0x398>
    8124:	aa1803e0 	mov	x0, x24
    8128:	97fff0f2 	bl	44f0 <fwp_rc_forget_slot>
    812c:	17ffff87 	b	7f48 <f12+0xd98>
    8130:	97fff0a9 	bl	43d4 <fwp_rc_wide_dup>
    8134:	17fffc5c 	b	72a4 <f12+0xf4>
    8138:	d280001a 	mov	x26, #0x0                   	// #0
    813c:	17fffeab 	b	7be8 <f12+0xa38>
    8140:	d2800019 	mov	x25, #0x0                   	// #0
    8144:	d2800013 	mov	x19, #0x0                   	// #0
    8148:	17ffff1c 	b	7db8 <f12+0xc08>
    814c:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8150:	91102000 	add	x0, x0, #0x408
    8154:	97ffeceb 	bl	3500 <fwp_trap>
    8158:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    815c:	910dc000 	add	x0, x0, #0x370
    8160:	97ffece8 	bl	3500 <fwp_trap>
    8164:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8168:	91142000 	add	x0, x0, #0x508
    816c:	97ffece5 	bl	3500 <fwp_trap>
    8170:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8174:	9111a000 	add	x0, x0, #0x468
    8178:	97ffece2 	bl	3500 <fwp_trap>
    817c:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8180:	910ee000 	add	x0, x0, #0x3b8
    8184:	97ffecdf 	bl	3500 <fwp_trap>
    8188:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    818c:	91132000 	add	x0, x0, #0x4c8
    8190:	97ffecdc 	bl	3500 <fwp_trap>
    8194:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8198:	9111e000 	add	x0, x0, #0x478
    819c:	97ffecd9 	bl	3500 <fwp_trap>
    81a0:	97ffe994 	bl	27f0 <__stack_chk_fail@plt>
    81a4:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    81a8:	91126000 	add	x0, x0, #0x498
    81ac:	97ffecd5 	bl	3500 <fwp_trap>
    81b0:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    81b4:	9113e000 	add	x0, x0, #0x4f8
    81b8:	97ffecd2 	bl	3500 <fwp_trap>
    81bc:	97ffea11 	bl	2a00 <fwp_trap_overflow.constprop.0>
    81c0:	97ffe9a0 	bl	2840 <abort@plt>

00000000000081c4 <fwp_owned_entry12>:
    81c4:	f9400000 	ldr	x0, [x0]
    81c8:	17fffbfa 	b	71b0 <f12>
    81cc:	d503201f 	nop

00000000000081d0 <e12>:
    81d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    81d4:	910003fd 	mov	x29, sp
    81d8:	f9000bf3 	str	x19, [sp, #16]
    81dc:	f9400013 	ldr	x19, [x0]
    81e0:	aa1303e0 	mov	x0, x19
    81e4:	97fff48f 	bl	5420 <fwp_rc_share>
    81e8:	aa1303e0 	mov	x0, x19
    81ec:	97fffbf1 	bl	71b0 <f12>
    81f0:	aa0003f3 	mov	x19, x0
    81f4:	97fff48b 	bl	5420 <fwp_rc_share>
    81f8:	aa1303e0 	mov	x0, x19
    81fc:	f9400bf3 	ldr	x19, [sp, #16]
    8200:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8204:	d65f03c0 	ret
    8208:	d503201f 	nop
    820c:	d503201f 	nop

0000000000008210 <fwp_write>:
    8210:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8214:	910003fd 	mov	x29, sp
    8218:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    821c:	f947f484 	ldr	x4, [x4, #4072]
    8220:	a90153f3 	stp	x19, x20, [sp, #16]
    8224:	d10943ff 	sub	sp, sp, #0x250
    8228:	b9400045 	ldr	w5, [x2]
    822c:	aa0003f4 	mov	x20, x0
    8230:	f9400080 	ldr	x0, [x4]
    8234:	f90127e0 	str	x0, [sp, #584]
    8238:	d2800000 	mov	x0, #0x0                   	// #0
    823c:	710064bf 	cmp	w5, #0x19
    8240:	54000408 	b.hi	82c0 <fwp_write+0xb0>  // b.pmore
    8244:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8248:	aa0103f3 	mov	x19, x1
    824c:	9132c000 	add	x0, x0, #0xcb0
    8250:	f9013bf5 	str	x21, [sp, #624]
    8254:	f9013ff6 	str	x22, [sp, #632]
    8258:	f90153fb 	str	x27, [sp, #672]
    825c:	f90157fc 	str	x28, [sp, #680]
    8260:	aa0203fc 	mov	x28, x2
    8264:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8268:	10000061 	adr	x1, 8274 <fwp_write+0x64>
    826c:	8b20a820 	add	x0, x1, w0, sxth #2
    8270:	d61f0000 	br	x0
    8274:	910123e0 	add	x0, sp, #0x48
    8278:	aa1303e5 	mov	x5, x19
    827c:	b0000024 	adrp	x4, d000 <__modti3+0x320>
    8280:	aa0003f3 	mov	x19, x0
    8284:	9115a084 	add	x4, x4, #0x568
    8288:	d2804003 	mov	x3, #0x200                 	// #512
    828c:	aa0303e1 	mov	x1, x3
    8290:	52800042 	mov	w2, #0x2                   	// #2
    8294:	97ffe933 	bl	2760 <__snprintf_chk@plt>
    8298:	aa1303e0 	mov	x0, x19
    829c:	97ffe8f9 	bl	2680 <strlen@plt>
    82a0:	aa1303e1 	mov	x1, x19
    82a4:	aa0003e2 	mov	x2, x0
    82a8:	aa1403e0 	mov	x0, x20
    82ac:	97ffec39 	bl	3390 <buf_put>
    82b0:	f9413bf5 	ldr	x21, [sp, #624]
    82b4:	f9413ff6 	ldr	x22, [sp, #632]
    82b8:	f94153fb 	ldr	x27, [sp, #672]
    82bc:	f94157fc 	ldr	x28, [sp, #680]
    82c0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    82c4:	f947f400 	ldr	x0, [x0, #4072]
    82c8:	f94127e2 	ldr	x2, [sp, #584]
    82cc:	f9400001 	ldr	x1, [x0]
    82d0:	eb010042 	subs	x2, x2, x1
    82d4:	d2800001 	mov	x1, #0x0                   	// #0
    82d8:	540077c1 	b.ne	91d0 <fwp_write+0xfc0>  // b.any
    82dc:	910943ff 	add	sp, sp, #0x250
    82e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    82e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    82e8:	d65f03c0 	ret
    82ec:	910123e0 	add	x0, sp, #0x48
    82f0:	aa1303e5 	mov	x5, x19
    82f4:	b0000024 	adrp	x4, d000 <__modti3+0x320>
    82f8:	aa0003f3 	mov	x19, x0
    82fc:	91158084 	add	x4, x4, #0x560
    8300:	d2804003 	mov	x3, #0x200                 	// #512
    8304:	17ffffe2 	b	828c <fwp_write+0x7c>
    8308:	71004cbf 	cmp	w5, #0x13
    830c:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8310:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8314:	91154000 	add	x0, x0, #0x550
    8318:	91156021 	add	x1, x1, #0x558
    831c:	d2800082 	mov	x2, #0x4                   	// #4
    8320:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8324:	aa1403e0 	mov	x0, x20
    8328:	f90143f7 	str	x23, [sp, #640]
    832c:	d2800016 	mov	x22, #0x0                   	// #0
    8330:	f90147f8 	str	x24, [sp, #648]
    8334:	97ffec17 	bl	3390 <buf_put>
    8338:	f9400260 	ldr	x0, [x19]
    833c:	b0000037 	adrp	x23, d000 <__modti3+0x320>
    8340:	d2800015 	mov	x21, #0x0                   	// #0
    8344:	911762f7 	add	x23, x23, #0x5d8
    8348:	b40047a0 	cbz	x0, 8c3c <fwp_write+0xa2c>
    834c:	b9400380 	ldr	w0, [x28]
    8350:	52800003 	mov	w3, #0x0                   	// #0
    8354:	f9401f82 	ldr	x2, [x28, #56]
    8358:	71004c1f 	cmp	w0, #0x13
    835c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8360:	aa1403e0 	mov	x0, x20
    8364:	8b010e61 	add	x1, x19, x1, lsl #3
    8368:	f9400421 	ldr	x1, [x1, #8]
    836c:	97ffffa9 	bl	8210 <fwp_write>
    8370:	b9400380 	ldr	w0, [x28]
    8374:	7100481f 	cmp	w0, #0x12
    8378:	54004b40 	b.eq	8ce0 <fwp_write+0xad0>  // b.none
    837c:	f9400260 	ldr	x0, [x19]
    8380:	910006b5 	add	x21, x21, #0x1
    8384:	91000ad6 	add	x22, x22, #0x2
    8388:	eb15001f 	cmp	x0, x21
    838c:	54004589 	b.ls	8c3c <fwp_write+0xa2c>  // b.plast
    8390:	aa1703e1 	mov	x1, x23
    8394:	aa1403e0 	mov	x0, x20
    8398:	d2800042 	mov	x2, #0x2                   	// #2
    839c:	97ffebfd 	bl	3390 <buf_put>
    83a0:	17ffffeb 	b	834c <fwp_write+0x13c>
    83a4:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    83a8:	91164021 	add	x1, x1, #0x590
    83ac:	d28000c2 	mov	x2, #0x6                   	// #6
    83b0:	aa1403e0 	mov	x0, x20
    83b4:	91004273 	add	x19, x19, #0x10
    83b8:	97ffebf6 	bl	3390 <buf_put>
    83bc:	aa1303e0 	mov	x0, x19
    83c0:	97ffe8b0 	bl	2680 <strlen@plt>
    83c4:	aa1303e1 	mov	x1, x19
    83c8:	aa0003e2 	mov	x2, x0
    83cc:	aa1403e0 	mov	x0, x20
    83d0:	97ffebf0 	bl	3390 <buf_put>
    83d4:	528007c3 	mov	w3, #0x3e                  	// #62
    83d8:	aa1403e0 	mov	x0, x20
    83dc:	91001fe1 	add	x1, sp, #0x7
    83e0:	d2800022 	mov	x2, #0x1                   	// #1
    83e4:	39001fe3 	strb	w3, [sp, #7]
    83e8:	17ffffb1 	b	82ac <fwp_write+0x9c>
    83ec:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    83f0:	f947f400 	ldr	x0, [x0, #4072]
    83f4:	f94127e2 	ldr	x2, [sp, #584]
    83f8:	f9400001 	ldr	x1, [x0]
    83fc:	eb010042 	subs	x2, x2, x1
    8400:	d2800001 	mov	x1, #0x0                   	// #0
    8404:	540034e1 	b.ne	8aa0 <fwp_write+0x890>  // b.any
    8408:	f9413bf5 	ldr	x21, [sp, #624]
    840c:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8410:	f9413ff6 	ldr	x22, [sp, #632]
    8414:	aa1403e0 	mov	x0, x20
    8418:	9115c021 	add	x1, x1, #0x570
    841c:	d2800142 	mov	x2, #0xa                   	// #10
    8420:	f94153fb 	ldr	x27, [sp, #672]
    8424:	f94157fc 	ldr	x28, [sp, #680]
    8428:	910943ff 	add	sp, sp, #0x250
    842c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8430:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8434:	17ffebd7 	b	3390 <buf_put>
    8438:	f9400456 	ldr	x22, [x2, #8]
    843c:	f90143f7 	str	x23, [sp, #640]
    8440:	f90147f8 	str	x24, [sp, #648]
    8444:	b4005b16 	cbz	x22, 8fa4 <fwp_write+0xd94>
    8448:	aa1603e0 	mov	x0, x22
    844c:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8450:	9117c021 	add	x1, x1, #0x5f0
    8454:	97ffe907 	bl	2870 <strcmp@plt>
    8458:	2a0003f5 	mov	w21, w0
    845c:	34005fe0 	cbz	w0, 9058 <fwp_write+0xe48>
    8460:	aa1603e0 	mov	x0, x22
    8464:	97ffe887 	bl	2680 <strlen@plt>
    8468:	aa1603e1 	mov	x1, x22
    846c:	aa0003e2 	mov	x2, x0
    8470:	aa1403e0 	mov	x0, x20
    8474:	97ffebc7 	bl	3390 <buf_put>
    8478:	52800403 	mov	w3, #0x20                  	// #32
    847c:	91001ff5 	add	x21, sp, #0x7
    8480:	aa1503e1 	mov	x1, x21
    8484:	aa1403e0 	mov	x0, x20
    8488:	d2800022 	mov	x2, #0x1                   	// #1
    848c:	39001fe3 	strb	w3, [sp, #7]
    8490:	97ffebc0 	bl	3390 <buf_put>
    8494:	52800f63 	mov	w3, #0x7b                  	// #123
    8498:	aa1403e0 	mov	x0, x20
    849c:	aa1503e1 	mov	x1, x21
    84a0:	d2800022 	mov	x2, #0x1                   	// #1
    84a4:	39001fe3 	strb	w3, [sp, #7]
    84a8:	97ffebba 	bl	3390 <buf_put>
    84ac:	b9401380 	ldr	w0, [x28, #16]
    84b0:	52800018 	mov	w24, #0x0                   	// #0
    84b4:	7100001f 	cmp	w0, #0x0
    84b8:	54003aad 	b.le	8c0c <fwp_write+0x9fc>
    84bc:	f9014bf9 	str	x25, [sp, #656]
    84c0:	b0000039 	adrp	x25, d000 <__modti3+0x320>
    84c4:	91186339 	add	x25, x25, #0x618
    84c8:	f9014ffa 	str	x26, [sp, #664]
    84cc:	b000003a 	adrp	x26, d000 <__modti3+0x320>
    84d0:	9117635a 	add	x26, x26, #0x5d8
    84d4:	91002276 	add	x22, x19, #0x8
    84d8:	d2800013 	mov	x19, #0x0                   	// #0
    84dc:	b5003e93 	cbnz	x19, 8cac <fwp_write+0xa9c>
    84e0:	d37df277 	lsl	x23, x19, #3
    84e4:	34003cb8 	cbz	w24, 8c78 <fwp_write+0xa68>
    84e8:	f9401382 	ldr	x2, [x28, #32]
    84ec:	aa1403e0 	mov	x0, x20
    84f0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    84f4:	52800003 	mov	w3, #0x0                   	// #0
    84f8:	f8776842 	ldr	x2, [x2, x23]
    84fc:	91000673 	add	x19, x19, #0x1
    8500:	97ffff44 	bl	8210 <fwp_write>
    8504:	b9401380 	ldr	w0, [x28, #16]
    8508:	6b13001f 	cmp	w0, w19
    850c:	54fffe8c 	b.gt	84dc <fwp_write+0x2cc>
    8510:	f9414bf9 	ldr	x25, [sp, #656]
    8514:	f9414ffa 	ldr	x26, [sp, #664]
    8518:	340037b8 	cbz	w24, 8c0c <fwp_write+0x9fc>
    851c:	52800523 	mov	w3, #0x29                  	// #41
    8520:	aa1503e1 	mov	x1, x21
    8524:	aa1403e0 	mov	x0, x20
    8528:	d2800022 	mov	x2, #0x1                   	// #1
    852c:	39001fe3 	strb	w3, [sp, #7]
    8530:	97ffeb98 	bl	3390 <buf_put>
    8534:	f9413bf5 	ldr	x21, [sp, #624]
    8538:	f9413ff6 	ldr	x22, [sp, #632]
    853c:	f94143f7 	ldr	x23, [sp, #640]
    8540:	f94147f8 	ldr	x24, [sp, #648]
    8544:	f94153fb 	ldr	x27, [sp, #672]
    8548:	f94157fc 	ldr	x28, [sp, #680]
    854c:	17ffff5d 	b	82c0 <fwp_write+0xb0>
    8550:	b9404855 	ldr	w21, [x2, #72]
    8554:	aa1403e0 	mov	x0, x20
    8558:	93407eb6 	sxtw	x22, w21
    855c:	91000ac1 	add	x1, x22, #0x2
    8560:	97ffeb59 	bl	32c4 <buf_grow>
    8564:	a9400281 	ldp	x1, x0, [x20]
    8568:	528e8603 	mov	w3, #0x7430                	// #29744
    856c:	78206823 	strh	w3, [x1, x0]
    8570:	8b000022 	add	x2, x1, x0
    8574:	710002bf 	cmp	w21, #0x0
    8578:	540036cd 	b.le	8c50 <fwp_write+0xa40>
    857c:	110006a3 	add	w3, w21, #0x1
    8580:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8584:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8588:	91000449 	add	x9, x2, #0x1
    858c:	8b23c043 	add	x3, x2, w3, sxtw
    8590:	f28aaac6 	movk	x6, #0x5556
    8594:	f2955568 	movk	x8, #0xaaab
    8598:	1400000d 	b	85cc <fwp_write+0x3bc>
    859c:	d2800021 	mov	x1, #0x1                   	// #1
    85a0:	528005a5 	mov	w5, #0x2d                  	// #45
    85a4:	f100001f 	cmp	x0, #0x0
    85a8:	9b467e60 	smulh	x0, x19, x6
    85ac:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    85b0:	381ff465 	strb	w5, [x3], #-1
    85b4:	cb040000 	sub	x0, x0, x4
    85b8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    85bc:	cb020000 	sub	x0, x0, x2
    85c0:	8b010013 	add	x19, x0, x1
    85c4:	eb03013f 	cmp	x9, x3
    85c8:	54003440 	b.eq	8c50 <fwp_write+0xa40>  // b.none
    85cc:	9b467e60 	smulh	x0, x19, x6
    85d0:	937ffe64 	asr	x4, x19, #63
    85d4:	52800605 	mov	w5, #0x30                  	// #48
    85d8:	cb040000 	sub	x0, x0, x4
    85dc:	8b000400 	add	x0, x0, x0, lsl #1
    85e0:	cb000260 	sub	x0, x19, x0
    85e4:	91000c01 	add	x1, x0, #0x3
    85e8:	9bc87c22 	umulh	x2, x1, x8
    85ec:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    85f0:	8b4204e2 	add	x2, x7, x2, lsr #1
    85f4:	eb020021 	subs	x1, x1, x2
    85f8:	54fffd60 	b.eq	85a4 <fwp_write+0x394>  // b.none
    85fc:	f100043f 	cmp	x1, #0x1
    8600:	54fffce1 	b.ne	859c <fwp_write+0x38c>  // b.any
    8604:	d2800001 	mov	x1, #0x0                   	// #0
    8608:	52800565 	mov	w5, #0x2b                  	// #43
    860c:	17ffffe6 	b	85a4 <fwp_write+0x394>
    8610:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8614:	f947f400 	ldr	x0, [x0, #4072]
    8618:	f94127e2 	ldr	x2, [sp, #584]
    861c:	f9400001 	ldr	x1, [x0]
    8620:	eb010042 	subs	x2, x2, x1
    8624:	d2800001 	mov	x1, #0x0                   	// #0
    8628:	540023c1 	b.ne	8aa0 <fwp_write+0x890>  // b.any
    862c:	f9413bf5 	ldr	x21, [sp, #624]
    8630:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8634:	f9413ff6 	ldr	x22, [sp, #632]
    8638:	aa1403e0 	mov	x0, x20
    863c:	91160021 	add	x1, x1, #0x580
    8640:	d2800102 	mov	x2, #0x8                   	// #8
    8644:	17ffff77 	b	8420 <fwp_write+0x210>
    8648:	aa1403e0 	mov	x0, x20
    864c:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8650:	d28000c2 	mov	x2, #0x6                   	// #6
    8654:	91178021 	add	x1, x1, #0x5e0
    8658:	97ffeb4e 	bl	3390 <buf_put>
    865c:	d2800015 	mov	x21, #0x0                   	// #0
    8660:	f9400263 	ldr	x3, [x19]
    8664:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8668:	54002c60 	b.eq	8bf4 <fwp_write+0x9e4>  // b.none
    866c:	f9401f82 	ldr	x2, [x28, #56]
    8670:	f90143f7 	str	x23, [sp, #640]
    8674:	f90147f8 	str	x24, [sp, #648]
    8678:	d2800857 	mov	x23, #0x42                  	// #66
    867c:	f9014bf9 	str	x25, [sp, #656]
    8680:	b0000036 	adrp	x22, d000 <__modti3+0x320>
    8684:	f9014ffa 	str	x26, [sp, #664]
    8688:	911762d6 	add	x22, x22, #0x5d8
    868c:	d2800038 	mov	x24, #0x1                   	// #1
    8690:	f2a18017 	movk	x23, #0xc00, lsl #16
    8694:	d2809099 	mov	x25, #0x484                 	// #1156
    8698:	b40004a2 	cbz	x2, 872c <fwp_write+0x51c>
    869c:	b9400040 	ldr	w0, [x2]
    86a0:	7100701f 	cmp	w0, #0x1c
    86a4:	540042c0 	b.eq	8efc <fwp_write+0xcec>  // b.none
    86a8:	71006c1f 	cmp	w0, #0x1b
    86ac:	54000408 	b.hi	872c <fwp_write+0x51c>  // b.pmore
    86b0:	9ac02301 	lsl	x1, x24, x0
    86b4:	ea17003f 	tst	x1, x23
    86b8:	540036a1 	b.ne	8d8c <fwp_write+0xb7c>  // b.any
    86bc:	ea19003f 	tst	x1, x25
    86c0:	54003521 	b.ne	8d64 <fwp_write+0xb54>  // b.any
    86c4:	d2800424 	mov	x4, #0x21                  	// #33
    86c8:	ea04003f 	tst	x1, x4
    86cc:	54000300 	b.eq	872c <fwp_write+0x51c>  // b.none
    86d0:	b7f849c3 	tbnz	x3, #63, 9008 <fwp_write+0xdf8>
    86d4:	91002261 	add	x1, x19, #0x8
    86d8:	8b150021 	add	x1, x1, x21
    86dc:	39400021 	ldrb	w1, [x1]
    86e0:	7100001f 	cmp	w0, #0x0
    86e4:	93401c23 	sxtb	x3, w1
    86e8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    86ec:	d503201f 	nop
    86f0:	aa1403e0 	mov	x0, x20
    86f4:	52800003 	mov	w3, #0x0                   	// #0
    86f8:	97fffec6 	bl	8210 <fwp_write>
    86fc:	910006b5 	add	x21, x21, #0x1
    8700:	f9400260 	ldr	x0, [x19]
    8704:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8708:	eb0002bf 	cmp	x21, x0
    870c:	540026c2 	b.cs	8be4 <fwp_write+0x9d4>  // b.hs, b.nlast
    8710:	d2800042 	mov	x2, #0x2                   	// #2
    8714:	aa1603e1 	mov	x1, x22
    8718:	aa1403e0 	mov	x0, x20
    871c:	97ffeb1d 	bl	3390 <buf_put>
    8720:	f9401f82 	ldr	x2, [x28, #56]
    8724:	f9400263 	ldr	x3, [x19]
    8728:	b5fffba2 	cbnz	x2, 869c <fwp_write+0x48c>
    872c:	d37df2a0 	lsl	x0, x21, #3
    8730:	b7f83f03 	tbnz	x3, #63, 8f10 <fwp_write+0xd00>
    8734:	91002261 	add	x1, x19, #0x8
    8738:	8b000020 	add	x0, x1, x0
    873c:	f9400001 	ldr	x1, [x0]
    8740:	17ffffec 	b	86f0 <fwp_write+0x4e0>
    8744:	a9400e62 	ldp	x2, x3, [x19]
    8748:	b7f83ca3 	tbnz	x3, #63, 8edc <fwp_write+0xccc>
    874c:	910123f5 	add	x21, sp, #0x48
    8750:	aa1503e0 	mov	x0, x21
    8754:	97ffe993 	bl	2da0 <fwp_fmt_u128>
    8758:	aa1503e0 	mov	x0, x21
    875c:	97ffe7c9 	bl	2680 <strlen@plt>
    8760:	aa1503e1 	mov	x1, x21
    8764:	aa0003e2 	mov	x2, x0
    8768:	17fffed0 	b	82a8 <fwp_write+0x98>
    876c:	fd015be8 	str	d8, [sp, #688]
    8770:	1e270268 	fmov	s8, w19
    8774:	fd015fe9 	str	d9, [sp, #696]
    8778:	1e282100 	fcmp	s8, s8
    877c:	54004d26 	b.vs	9120 <fwp_write+0xf10>
    8780:	1e20c101 	fabs	s1, s8
    8784:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8788:	1e270000 	fmov	s0, w0
    878c:	1e202020 	fcmp	s1, s0
    8790:	54002c0d 	b.le	8d10 <fwp_write+0xb00>
    8794:	1e202118 	fcmpe	s8, #0.0
    8798:	b0000022 	adrp	x2, d000 <__modti3+0x320>
    879c:	91028042 	add	x2, x2, #0xa0
    87a0:	910123f5 	add	x21, sp, #0x48
    87a4:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    87a8:	9114c021 	add	x1, x1, #0x530
    87ac:	aa1503e0 	mov	x0, x21
    87b0:	9a81c041 	csel	x1, x2, x1, gt
    87b4:	97ffe85f 	bl	2930 <strcpy@plt>
    87b8:	aa1503e0 	mov	x0, x21
    87bc:	97ffe7b1 	bl	2680 <strlen@plt>
    87c0:	aa1503e1 	mov	x1, x21
    87c4:	aa0003e2 	mov	x2, x0
    87c8:	aa1403e0 	mov	x0, x20
    87cc:	97ffeaf1 	bl	3390 <buf_put>
    87d0:	f9413bf5 	ldr	x21, [sp, #624]
    87d4:	f9413ff6 	ldr	x22, [sp, #632]
    87d8:	f94153fb 	ldr	x27, [sp, #672]
    87dc:	f94157fc 	ldr	x28, [sp, #680]
    87e0:	fd415be8 	ldr	d8, [sp, #688]
    87e4:	fd415fe9 	ldr	d9, [sp, #696]
    87e8:	17fffeb6 	b	82c0 <fwp_write+0xb0>
    87ec:	f9400276 	ldr	x22, [x19]
    87f0:	34002e03 	cbz	w3, 8db0 <fwp_write+0xba0>
    87f4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    87f8:	f947f400 	ldr	x0, [x0, #4072]
    87fc:	f94127e2 	ldr	x2, [sp, #584]
    8800:	f9400001 	ldr	x1, [x0]
    8804:	eb010042 	subs	x2, x2, x1
    8808:	d2800001 	mov	x1, #0x0                   	// #0
    880c:	540014a1 	b.ne	8aa0 <fwp_write+0x890>  // b.any
    8810:	aa1603e2 	mov	x2, x22
    8814:	91002261 	add	x1, x19, #0x8
    8818:	f9413bf5 	ldr	x21, [sp, #624]
    881c:	aa1403e0 	mov	x0, x20
    8820:	f9413ff6 	ldr	x22, [sp, #632]
    8824:	17fffeff 	b	8420 <fwp_write+0x210>
    8828:	fd015be8 	str	d8, [sp, #688]
    882c:	9e670268 	fmov	d8, x19
    8830:	fd015fe9 	str	d9, [sp, #696]
    8834:	1e682100 	fcmp	d8, d8
    8838:	54004746 	b.vs	9120 <fwp_write+0xf10>
    883c:	1e60c101 	fabs	d1, d8
    8840:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8844:	9e670000 	fmov	d0, x0
    8848:	910123f5 	add	x21, sp, #0x48
    884c:	52800033 	mov	w19, #0x1                   	// #1
    8850:	1e602020 	fcmp	d1, d0
    8854:	540001ad 	b.le	8888 <fwp_write+0x678>
    8858:	1e602118 	fcmpe	d8, #0.0
    885c:	b0000022 	adrp	x2, d000 <__modti3+0x320>
    8860:	91028042 	add	x2, x2, #0xa0
    8864:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8868:	9114c021 	add	x1, x1, #0x530
    886c:	aa1503e0 	mov	x0, x21
    8870:	9a81c041 	csel	x1, x2, x1, gt
    8874:	97ffe82f 	bl	2930 <strcpy@plt>
    8878:	17ffffd0 	b	87b8 <fwp_write+0x5a8>
    887c:	11000673 	add	w19, w19, #0x1
    8880:	71004a7f 	cmp	w19, #0x12
    8884:	54003860 	b.eq	8f90 <fwp_write+0xd80>  // b.none
    8888:	1e604100 	fmov	d0, d8
    888c:	2a1303e1 	mov	w1, w19
    8890:	aa1503e0 	mov	x0, x21
    8894:	97ffec00 	bl	3894 <fwp_format_g.constprop.0>
    8898:	aa1503e0 	mov	x0, x21
    889c:	d2800001 	mov	x1, #0x0                   	// #0
    88a0:	97ffe78c 	bl	26d0 <strtod@plt>
    88a4:	1e602100 	fcmp	d8, d0
    88a8:	54fffea1 	b.ne	887c <fwp_write+0x66c>  // b.any
    88ac:	aa1503e0 	mov	x0, x21
    88b0:	97ffeaf1 	bl	3474 <fwp_finish_float>
    88b4:	17ffffc1 	b	87b8 <fwp_write+0x5a8>
    88b8:	a9400e62 	ldp	x2, x3, [x19]
    88bc:	910123f3 	add	x19, sp, #0x48
    88c0:	aa1303e0 	mov	x0, x19
    88c4:	97ffe937 	bl	2da0 <fwp_fmt_u128>
    88c8:	17fffe74 	b	8298 <fwp_write+0x88>
    88cc:	f90143f7 	str	x23, [sp, #640]
    88d0:	f90147f8 	str	x24, [sp, #648]
    88d4:	2a1303f8 	mov	w24, w19
    88d8:	f9014bf9 	str	x25, [sp, #656]
    88dc:	f9014ffa 	str	x26, [sp, #664]
    88e0:	f13ffe7f 	cmp	x19, #0xfff
    88e4:	54000049 	b.ls	88ec <fwp_write+0x6dc>  // b.plast
    88e8:	b9400278 	ldr	w24, [x19]
    88ec:	f9400f80 	ldr	x0, [x28, #24]
    88f0:	2a1803f5 	mov	w21, w24
    88f4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    88f8:	d37ef6b9 	lsl	x25, x21, #2
    88fc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8900:	aa1603e0 	mov	x0, x22
    8904:	97ffe75f 	bl	2680 <strlen@plt>
    8908:	aa1603e1 	mov	x1, x22
    890c:	aa0003e2 	mov	x2, x0
    8910:	aa1403e0 	mov	x0, x20
    8914:	97ffea9f 	bl	3390 <buf_put>
    8918:	f9401780 	ldr	x0, [x28, #40]
    891c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8920:	7100001f 	cmp	w0, #0x0
    8924:	5400068d 	b.le	89f4 <fwp_write+0x7e4>
    8928:	91002276 	add	x22, x19, #0x8
    892c:	91001ff5 	add	x21, sp, #0x7
    8930:	d280001b 	mov	x27, #0x0                   	// #0
    8934:	5280041a 	mov	w26, #0x20                  	// #32
    8938:	f9401b80 	ldr	x0, [x28, #48]
    893c:	aa1503e1 	mov	x1, x21
    8940:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8944:	d2800022 	mov	x2, #0x1                   	// #1
    8948:	f8786803 	ldr	x3, [x0, x24]
    894c:	aa1403e0 	mov	x0, x20
    8950:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8954:	39001ffa 	strb	w26, [sp, #7]
    8958:	97ffea8e 	bl	3390 <buf_put>
    895c:	f13ffeff 	cmp	x23, #0xfff
    8960:	b9400261 	ldr	w1, [x19]
    8964:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8968:	7100383f 	cmp	w1, #0xe
    896c:	54000160 	b.eq	8998 <fwp_write+0x788>  // b.none
    8970:	7100403f 	cmp	w1, #0x10
    8974:	54001a60 	b.eq	8cc0 <fwp_write+0xab0>  // b.none
    8978:	7100283f 	cmp	w1, #0xa
    897c:	54002aa0 	b.eq	8ed0 <fwp_write+0xcc0>  // b.none
    8980:	540014ac 	b.gt	8c14 <fwp_write+0xa04>
    8984:	71000c3f 	cmp	w1, #0x3
    8988:	540029ac 	b.gt	8ebc <fwp_write+0xcac>
    898c:	d37ffee0 	lsr	x0, x23, #63
    8990:	37f814a1 	tbnz	w1, #31, 8c24 <fwp_write+0xa14>
    8994:	d503201f 	nop
    8998:	34001460 	cbz	w0, 8c24 <fwp_write+0xa14>
    899c:	52800503 	mov	w3, #0x28                  	// #40
    89a0:	aa1503e1 	mov	x1, x21
    89a4:	aa1403e0 	mov	x0, x20
    89a8:	d2800022 	mov	x2, #0x1                   	// #1
    89ac:	39001fe3 	strb	w3, [sp, #7]
    89b0:	97ffea78 	bl	3390 <buf_put>
    89b4:	aa1303e2 	mov	x2, x19
    89b8:	aa1703e1 	mov	x1, x23
    89bc:	aa1403e0 	mov	x0, x20
    89c0:	52800003 	mov	w3, #0x0                   	// #0
    89c4:	97fffe13 	bl	8210 <fwp_write>
    89c8:	52800523 	mov	w3, #0x29                  	// #41
    89cc:	aa1503e1 	mov	x1, x21
    89d0:	aa1403e0 	mov	x0, x20
    89d4:	d2800022 	mov	x2, #0x1                   	// #1
    89d8:	39001fe3 	strb	w3, [sp, #7]
    89dc:	97ffea6d 	bl	3390 <buf_put>
    89e0:	f9401780 	ldr	x0, [x28, #40]
    89e4:	9100077b 	add	x27, x27, #0x1
    89e8:	b8796800 	ldr	w0, [x0, x25]
    89ec:	6b1b001f 	cmp	w0, w27
    89f0:	54fffa4c 	b.gt	8938 <fwp_write+0x728>
    89f4:	f9413bf5 	ldr	x21, [sp, #624]
    89f8:	f9413ff6 	ldr	x22, [sp, #632]
    89fc:	f94143f7 	ldr	x23, [sp, #640]
    8a00:	f94147f8 	ldr	x24, [sp, #648]
    8a04:	f9414bf9 	ldr	x25, [sp, #656]
    8a08:	f9414ffa 	ldr	x26, [sp, #664]
    8a0c:	f94153fb 	ldr	x27, [sp, #672]
    8a10:	f94157fc 	ldr	x28, [sp, #680]
    8a14:	17fffe2b 	b	82c0 <fwp_write+0xb0>
    8a18:	52800783 	mov	w3, #0x3c                  	// #60
    8a1c:	91001ff3 	add	x19, sp, #0x7
    8a20:	aa1303e1 	mov	x1, x19
    8a24:	d2800022 	mov	x2, #0x1                   	// #1
    8a28:	aa1403e0 	mov	x0, x20
    8a2c:	39001fe3 	strb	w3, [sp, #7]
    8a30:	97ffea58 	bl	3390 <buf_put>
    8a34:	f9400795 	ldr	x21, [x28, #8]
    8a38:	aa1503e0 	mov	x0, x21
    8a3c:	97ffe711 	bl	2680 <strlen@plt>
    8a40:	aa1503e1 	mov	x1, x21
    8a44:	aa0003e2 	mov	x2, x0
    8a48:	aa1403e0 	mov	x0, x20
    8a4c:	97ffea51 	bl	3390 <buf_put>
    8a50:	528007c3 	mov	w3, #0x3e                  	// #62
    8a54:	aa1303e1 	mov	x1, x19
    8a58:	aa1403e0 	mov	x0, x20
    8a5c:	d2800022 	mov	x2, #0x1                   	// #1
    8a60:	39001fe3 	strb	w3, [sp, #7]
    8a64:	17fffe12 	b	82ac <fwp_write+0x9c>
    8a68:	f100067f 	cmp	x19, #0x1
    8a6c:	540025a0 	b.eq	8f20 <fwp_write+0xd10>  // b.none
    8a70:	b100067f 	cmn	x19, #0x1
    8a74:	54002bc0 	b.eq	8fec <fwp_write+0xddc>  // b.none
    8a78:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8a7c:	9114e021 	add	x1, x1, #0x538
    8a80:	d2800022 	mov	x2, #0x1                   	// #1
    8a84:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8a88:	f947f400 	ldr	x0, [x0, #4072]
    8a8c:	f94127e4 	ldr	x4, [sp, #584]
    8a90:	f9400003 	ldr	x3, [x0]
    8a94:	eb030084 	subs	x4, x4, x3
    8a98:	d2800003 	mov	x3, #0x0                   	// #0
    8a9c:	54ffebe0 	b.eq	8818 <fwp_write+0x608>  // b.none
    8aa0:	f90143f7 	str	x23, [sp, #640]
    8aa4:	f90147f8 	str	x24, [sp, #648]
    8aa8:	f9014bf9 	str	x25, [sp, #656]
    8aac:	f9014ffa 	str	x26, [sp, #664]
    8ab0:	fd015be8 	str	d8, [sp, #688]
    8ab4:	fd015fe9 	str	d9, [sp, #696]
    8ab8:	97ffe74e 	bl	27f0 <__stack_chk_fail@plt>
    8abc:	52800b63 	mov	w3, #0x5b                  	// #91
    8ac0:	91001ff5 	add	x21, sp, #0x7
    8ac4:	aa1503e1 	mov	x1, x21
    8ac8:	aa1403e0 	mov	x0, x20
    8acc:	d2800022 	mov	x2, #0x1                   	// #1
    8ad0:	b0000036 	adrp	x22, d000 <__modti3+0x320>
    8ad4:	911762d6 	add	x22, x22, #0x5d8
    8ad8:	39001fe3 	strb	w3, [sp, #7]
    8adc:	97ffea2d 	bl	3390 <buf_put>
    8ae0:	b4000273 	cbz	x19, 8b2c <fwp_write+0x91c>
    8ae4:	f9400661 	ldr	x1, [x19, #8]
    8ae8:	aa1403e0 	mov	x0, x20
    8aec:	f9401f82 	ldr	x2, [x28, #56]
    8af0:	52800003 	mov	w3, #0x0                   	// #0
    8af4:	97fffdc7 	bl	8210 <fwp_write>
    8af8:	f9400a73 	ldr	x19, [x19, #16]
    8afc:	b4000193 	cbz	x19, 8b2c <fwp_write+0x91c>
    8b00:	aa1603e1 	mov	x1, x22
    8b04:	aa1403e0 	mov	x0, x20
    8b08:	d2800042 	mov	x2, #0x2                   	// #2
    8b0c:	97ffea21 	bl	3390 <buf_put>
    8b10:	f9400661 	ldr	x1, [x19, #8]
    8b14:	aa1403e0 	mov	x0, x20
    8b18:	f9401f82 	ldr	x2, [x28, #56]
    8b1c:	52800003 	mov	w3, #0x0                   	// #0
    8b20:	97fffdbc 	bl	8210 <fwp_write>
    8b24:	f9400a73 	ldr	x19, [x19, #16]
    8b28:	b5fffed3 	cbnz	x19, 8b00 <fwp_write+0x8f0>
    8b2c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8b30:	aa1503e1 	mov	x1, x21
    8b34:	aa1403e0 	mov	x0, x20
    8b38:	d2800022 	mov	x2, #0x1                   	// #1
    8b3c:	39001fe3 	strb	w3, [sp, #7]
    8b40:	17fffddb 	b	82ac <fwp_write+0x9c>
    8b44:	aa1403e0 	mov	x0, x20
    8b48:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8b4c:	d28000c2 	mov	x2, #0x6                   	// #6
    8b50:	91172021 	add	x1, x1, #0x5c8
    8b54:	97ffea0f 	bl	3390 <buf_put>
    8b58:	f9400260 	ldr	x0, [x19]
    8b5c:	b40004c0 	cbz	x0, 8bf4 <fwp_write+0x9e4>
    8b60:	910123f5 	add	x21, sp, #0x48
    8b64:	91002276 	add	x22, x19, #0x8
    8b68:	f90143f7 	str	x23, [sp, #640]
    8b6c:	d2800017 	mov	x23, #0x0                   	// #0
    8b70:	f90147f8 	str	x24, [sp, #648]
    8b74:	b0000038 	adrp	x24, d000 <__modti3+0x320>
    8b78:	91174318 	add	x24, x24, #0x5d0
    8b7c:	f9014bf9 	str	x25, [sp, #656]
    8b80:	b0000039 	adrp	x25, d000 <__modti3+0x320>
    8b84:	91176339 	add	x25, x25, #0x5d8
    8b88:	f9014ffa 	str	x26, [sp, #664]
    8b8c:	14000005 	b	8ba0 <fwp_write+0x990>
    8b90:	aa1903e1 	mov	x1, x25
    8b94:	aa1403e0 	mov	x0, x20
    8b98:	d2800042 	mov	x2, #0x2                   	// #2
    8b9c:	97ffe9fd 	bl	3390 <buf_put>
    8ba0:	38776ac5 	ldrb	w5, [x22, x23]
    8ba4:	d2804003 	mov	x3, #0x200                 	// #512
    8ba8:	aa1803e4 	mov	x4, x24
    8bac:	aa0303e1 	mov	x1, x3
    8bb0:	52800042 	mov	w2, #0x2                   	// #2
    8bb4:	aa1503e0 	mov	x0, x21
    8bb8:	910006f7 	add	x23, x23, #0x1
    8bbc:	97ffe6e9 	bl	2760 <__snprintf_chk@plt>
    8bc0:	aa1503e0 	mov	x0, x21
    8bc4:	97ffe6af 	bl	2680 <strlen@plt>
    8bc8:	aa1503e1 	mov	x1, x21
    8bcc:	aa0003e2 	mov	x2, x0
    8bd0:	aa1403e0 	mov	x0, x20
    8bd4:	97ffe9ef 	bl	3390 <buf_put>
    8bd8:	f9400260 	ldr	x0, [x19]
    8bdc:	eb17001f 	cmp	x0, x23
    8be0:	54fffd88 	b.hi	8b90 <fwp_write+0x980>  // b.pmore
    8be4:	f94143f7 	ldr	x23, [sp, #640]
    8be8:	f94147f8 	ldr	x24, [sp, #648]
    8bec:	f9414bf9 	ldr	x25, [sp, #656]
    8bf0:	f9414ffa 	ldr	x26, [sp, #664]
    8bf4:	52800ba3 	mov	w3, #0x5d                  	// #93
    8bf8:	aa1403e0 	mov	x0, x20
    8bfc:	91001fe1 	add	x1, sp, #0x7
    8c00:	d2800022 	mov	x2, #0x1                   	// #1
    8c04:	39001fe3 	strb	w3, [sp, #7]
    8c08:	17fffda9 	b	82ac <fwp_write+0x9c>
    8c0c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8c10:	17fffe44 	b	8520 <fwp_write+0x310>
    8c14:	f10002ff 	cmp	x23, #0x0
    8c18:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8c1c:	71002c3f 	cmp	w1, #0xb
    8c20:	54ffebc0 	b.eq	8998 <fwp_write+0x788>  // b.none
    8c24:	aa1303e2 	mov	x2, x19
    8c28:	aa1703e1 	mov	x1, x23
    8c2c:	aa1403e0 	mov	x0, x20
    8c30:	52800003 	mov	w3, #0x0                   	// #0
    8c34:	97fffd77 	bl	8210 <fwp_write>
    8c38:	17ffff6a 	b	89e0 <fwp_write+0x7d0>
    8c3c:	aa1403e0 	mov	x0, x20
    8c40:	91001fe1 	add	x1, sp, #0x7
    8c44:	52800fa3 	mov	w3, #0x7d                  	// #125
    8c48:	d2800022 	mov	x2, #0x1                   	// #1
    8c4c:	17fffe38 	b	852c <fwp_write+0x31c>
    8c50:	a9400281 	ldp	x1, x0, [x20]
    8c54:	91000800 	add	x0, x0, #0x2
    8c58:	8b160000 	add	x0, x0, x22
    8c5c:	f9000680 	str	x0, [x20, #8]
    8c60:	3820683f 	strb	wzr, [x1, x0]
    8c64:	f9413bf5 	ldr	x21, [sp, #624]
    8c68:	f9413ff6 	ldr	x22, [sp, #632]
    8c6c:	f94153fb 	ldr	x27, [sp, #672]
    8c70:	f94157fc 	ldr	x28, [sp, #680]
    8c74:	17fffd93 	b	82c0 <fwp_write+0xb0>
    8c78:	f9400f80 	ldr	x0, [x28, #24]
    8c7c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8c80:	aa1b03e0 	mov	x0, x27
    8c84:	97ffe67f 	bl	2680 <strlen@plt>
    8c88:	aa1b03e1 	mov	x1, x27
    8c8c:	aa0003e2 	mov	x2, x0
    8c90:	aa1403e0 	mov	x0, x20
    8c94:	97ffe9bf 	bl	3390 <buf_put>
    8c98:	aa1903e1 	mov	x1, x25
    8c9c:	aa1403e0 	mov	x0, x20
    8ca0:	d2800062 	mov	x2, #0x3                   	// #3
    8ca4:	97ffe9bb 	bl	3390 <buf_put>
    8ca8:	17fffe10 	b	84e8 <fwp_write+0x2d8>
    8cac:	aa1a03e1 	mov	x1, x26
    8cb0:	aa1403e0 	mov	x0, x20
    8cb4:	d2800042 	mov	x2, #0x2                   	// #2
    8cb8:	97ffe9b6 	bl	3390 <buf_put>
    8cbc:	17fffe09 	b	84e0 <fwp_write+0x2d0>
    8cc0:	f9400660 	ldr	x0, [x19, #8]
    8cc4:	b4fffb00 	cbz	x0, 8c24 <fwp_write+0xa14>
    8cc8:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8ccc:	9117c021 	add	x1, x1, #0x5f0
    8cd0:	97ffe6e8 	bl	2870 <strcmp@plt>
    8cd4:	7100001f 	cmp	w0, #0x0
    8cd8:	1a9f07e0 	cset	w0, ne	// ne = any
    8cdc:	17ffff2f 	b	8998 <fwp_write+0x788>
    8ce0:	aa1403e0 	mov	x0, x20
    8ce4:	d2800042 	mov	x2, #0x2                   	// #2
    8ce8:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8cec:	9117a021 	add	x1, x1, #0x5e8
    8cf0:	97ffe9a8 	bl	3390 <buf_put>
    8cf4:	91004261 	add	x1, x19, #0x10
    8cf8:	aa1403e0 	mov	x0, x20
    8cfc:	f9402382 	ldr	x2, [x28, #64]
    8d00:	52800003 	mov	w3, #0x0                   	// #0
    8d04:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8d08:	97fffd42 	bl	8210 <fwp_write>
    8d0c:	17fffd9c 	b	837c <fwp_write+0x16c>
    8d10:	1e22c109 	fcvt	d9, s8
    8d14:	910123f5 	add	x21, sp, #0x48
    8d18:	52800033 	mov	w19, #0x1                   	// #1
    8d1c:	d503201f 	nop
    8d20:	1e604120 	fmov	d0, d9
    8d24:	2a1303e1 	mov	w1, w19
    8d28:	aa1503e0 	mov	x0, x21
    8d2c:	97ffeada 	bl	3894 <fwp_format_g.constprop.0>
    8d30:	aa1503e0 	mov	x0, x21
    8d34:	d2800001 	mov	x1, #0x0                   	// #0
    8d38:	97ffe6da 	bl	28a0 <strtof@plt>
    8d3c:	1e202100 	fcmp	s8, s0
    8d40:	54ffdb60 	b.eq	88ac <fwp_write+0x69c>  // b.none
    8d44:	11000673 	add	w19, w19, #0x1
    8d48:	71002a7f 	cmp	w19, #0xa
    8d4c:	54fffea1 	b.ne	8d20 <fwp_write+0xb10>  // b.any
    8d50:	1e604120 	fmov	d0, d9
    8d54:	aa1503e0 	mov	x0, x21
    8d58:	52800121 	mov	w1, #0x9                   	// #9
    8d5c:	97ffeace 	bl	3894 <fwp_format_g.constprop.0>
    8d60:	17fffed3 	b	88ac <fwp_write+0x69c>
    8d64:	d37ef6a1 	lsl	x1, x21, #2
    8d68:	b7f81563 	tbnz	x3, #63, 9014 <fwp_write+0xe04>
    8d6c:	91002263 	add	x3, x19, #0x8
    8d70:	8b010061 	add	x1, x3, x1
    8d74:	b9400023 	ldr	w3, [x1]
    8d78:	7100081f 	cmp	w0, #0x2
    8d7c:	2a0303e1 	mov	w1, w3
    8d80:	93407c63 	sxtw	x3, w3
    8d84:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8d88:	17fffe5a 	b	86f0 <fwp_write+0x4e0>
    8d8c:	d37ffaa1 	lsl	x1, x21, #1
    8d90:	b7f81363 	tbnz	x3, #63, 8ffc <fwp_write+0xdec>
    8d94:	91002263 	add	x3, x19, #0x8
    8d98:	8b010061 	add	x1, x3, x1
    8d9c:	79400021 	ldrh	w1, [x1]
    8da0:	7100041f 	cmp	w0, #0x1
    8da4:	93403c23 	sxth	x3, w1
    8da8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8dac:	17fffe51 	b	86f0 <fwp_write+0x4e0>
    8db0:	52800443 	mov	w3, #0x22                  	// #34
    8db4:	91001ff5 	add	x21, sp, #0x7
    8db8:	91002273 	add	x19, x19, #0x8
    8dbc:	aa1503e1 	mov	x1, x21
    8dc0:	aa1403e0 	mov	x0, x20
    8dc4:	d2800022 	mov	x2, #0x1                   	// #1
    8dc8:	39001fe3 	strb	w3, [sp, #7]
    8dcc:	f90143f7 	str	x23, [sp, #640]
    8dd0:	8b160277 	add	x23, x19, x22
    8dd4:	f90147f8 	str	x24, [sp, #648]
    8dd8:	97ffe96e 	bl	3390 <buf_put>
    8ddc:	b4000696 	cbz	x22, 8eac <fwp_write+0xc9c>
    8de0:	b0000038 	adrp	x24, d000 <__modti3+0x320>
    8de4:	91166318 	add	x24, x24, #0x598
    8de8:	f9014bf9 	str	x25, [sp, #656]
    8dec:	b0000039 	adrp	x25, d000 <__modti3+0x320>
    8df0:	9116e339 	add	x25, x25, #0x5b8
    8df4:	f9014ffa 	str	x26, [sp, #664]
    8df8:	1400000d 	b	8e2c <fwp_write+0xc1c>
    8dfc:	710024bf 	cmp	w5, #0x9
    8e00:	54000460 	b.eq	8e8c <fwp_write+0xc7c>  // b.none
    8e04:	710028bf 	cmp	w5, #0xa
    8e08:	54000a61 	b.ne	8f54 <fwp_write+0xd44>  // b.any
    8e0c:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8e10:	aa1403e0 	mov	x0, x20
    8e14:	9116a021 	add	x1, x1, #0x5a8
    8e18:	d2800042 	mov	x2, #0x2                   	// #2
    8e1c:	97ffe95d 	bl	3390 <buf_put>
    8e20:	91000673 	add	x19, x19, #0x1
    8e24:	eb17027f 	cmp	x19, x23
    8e28:	540003e0 	b.eq	8ea4 <fwp_write+0xc94>  // b.none
    8e2c:	39400265 	ldrb	w5, [x19]
    8e30:	710034bf 	cmp	w5, #0xd
    8e34:	54000180 	b.eq	8e64 <fwp_write+0xc54>  // b.none
    8e38:	54fffe29 	b.ls	8dfc <fwp_write+0xbec>  // b.plast
    8e3c:	710088bf 	cmp	w5, #0x22
    8e40:	540001c0 	b.eq	8e78 <fwp_write+0xc68>  // b.none
    8e44:	710170bf 	cmp	w5, #0x5c
    8e48:	54000741 	b.ne	8f30 <fwp_write+0xd20>  // b.any
    8e4c:	aa1403e0 	mov	x0, x20
    8e50:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8e54:	d2800042 	mov	x2, #0x2                   	// #2
    8e58:	91168021 	add	x1, x1, #0x5a0
    8e5c:	97ffe94d 	bl	3390 <buf_put>
    8e60:	17fffff0 	b	8e20 <fwp_write+0xc10>
    8e64:	aa1903e1 	mov	x1, x25
    8e68:	aa1403e0 	mov	x0, x20
    8e6c:	d2800042 	mov	x2, #0x2                   	// #2
    8e70:	97ffe948 	bl	3390 <buf_put>
    8e74:	17ffffeb 	b	8e20 <fwp_write+0xc10>
    8e78:	aa1803e1 	mov	x1, x24
    8e7c:	aa1403e0 	mov	x0, x20
    8e80:	d2800042 	mov	x2, #0x2                   	// #2
    8e84:	97ffe943 	bl	3390 <buf_put>
    8e88:	17ffffe6 	b	8e20 <fwp_write+0xc10>
    8e8c:	aa1403e0 	mov	x0, x20
    8e90:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8e94:	d2800042 	mov	x2, #0x2                   	// #2
    8e98:	9116c021 	add	x1, x1, #0x5b0
    8e9c:	97ffe93d 	bl	3390 <buf_put>
    8ea0:	17ffffe0 	b	8e20 <fwp_write+0xc10>
    8ea4:	f9414bf9 	ldr	x25, [sp, #656]
    8ea8:	f9414ffa 	ldr	x26, [sp, #664]
    8eac:	aa1503e1 	mov	x1, x21
    8eb0:	aa1403e0 	mov	x0, x20
    8eb4:	52800443 	mov	w3, #0x22                  	// #34
    8eb8:	17fffd9c 	b	8528 <fwp_write+0x318>
    8ebc:	7100103f 	cmp	w1, #0x4
    8ec0:	54ffeb21 	b.ne	8c24 <fwp_write+0xa14>  // b.any
    8ec4:	f94006e0 	ldr	x0, [x23, #8]
    8ec8:	d37ffc00 	lsr	x0, x0, #63
    8ecc:	17fffeb3 	b	8998 <fwp_write+0x788>
    8ed0:	710002ff 	cmp	w23, #0x0
    8ed4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8ed8:	17fffeb0 	b	8998 <fwp_write+0x788>
    8edc:	528005a1 	mov	w1, #0x2d                  	// #45
    8ee0:	eb0203e2 	negs	x2, x2
    8ee4:	da0303e3 	ngc	x3, x3
    8ee8:	910127e0 	add	x0, sp, #0x49
    8eec:	910123f5 	add	x21, sp, #0x48
    8ef0:	390123e1 	strb	w1, [sp, #72]
    8ef4:	97ffe7ab 	bl	2da0 <fwp_fmt_u128>
    8ef8:	17fffe18 	b	8758 <fwp_write+0x548>
    8efc:	d37ceea1 	lsl	x1, x21, #4
    8f00:	b7f810a3 	tbnz	x3, #63, 9114 <fwp_write+0xf04>
    8f04:	91002260 	add	x0, x19, #0x8
    8f08:	8b010001 	add	x1, x0, x1
    8f0c:	17fffdf9 	b	86f0 <fwp_write+0x4e0>
    8f10:	f9400a61 	ldr	x1, [x19, #16]
    8f14:	8b010000 	add	x0, x0, x1
    8f18:	f9400001 	ldr	x1, [x0]
    8f1c:	17fffdf5 	b	86f0 <fwp_write+0x4e0>
    8f20:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8f24:	d2800042 	mov	x2, #0x2                   	// #2
    8f28:	91150021 	add	x1, x1, #0x540
    8f2c:	17fffed6 	b	8a84 <fwp_write+0x874>
    8f30:	7101fcbf 	cmp	w5, #0x7f
    8f34:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8f38:	540000e9 	b.ls	8f54 <fwp_write+0xd44>  // b.plast
    8f3c:	aa1503e1 	mov	x1, x21
    8f40:	aa1403e0 	mov	x0, x20
    8f44:	d2800022 	mov	x2, #0x1                   	// #1
    8f48:	39001fe5 	strb	w5, [sp, #7]
    8f4c:	97ffe911 	bl	3390 <buf_put>
    8f50:	17ffffb4 	b	8e20 <fwp_write+0xc10>
    8f54:	d2800203 	mov	x3, #0x10                  	// #16
    8f58:	b0000024 	adrp	x4, d000 <__modti3+0x320>
    8f5c:	aa0303e1 	mov	x1, x3
    8f60:	91170084 	add	x4, x4, #0x5c0
    8f64:	910123f6 	add	x22, sp, #0x48
    8f68:	52800042 	mov	w2, #0x2                   	// #2
    8f6c:	aa1603e0 	mov	x0, x22
    8f70:	97ffe5fc 	bl	2760 <__snprintf_chk@plt>
    8f74:	aa1603e0 	mov	x0, x22
    8f78:	97ffe5c2 	bl	2680 <strlen@plt>
    8f7c:	aa1603e1 	mov	x1, x22
    8f80:	aa0003e2 	mov	x2, x0
    8f84:	aa1403e0 	mov	x0, x20
    8f88:	97ffe902 	bl	3390 <buf_put>
    8f8c:	17ffffa5 	b	8e20 <fwp_write+0xc10>
    8f90:	1e604100 	fmov	d0, d8
    8f94:	aa1503e0 	mov	x0, x21
    8f98:	52800221 	mov	w1, #0x11                  	// #17
    8f9c:	97ffea3e 	bl	3894 <fwp_format_g.constprop.0>
    8fa0:	17fffe43 	b	88ac <fwp_write+0x69c>
    8fa4:	b9401040 	ldr	w0, [x2, #16]
    8fa8:	350003c0 	cbnz	w0, 9020 <fwp_write+0xe10>
    8fac:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8fb0:	f947f400 	ldr	x0, [x0, #4072]
    8fb4:	f94127e2 	ldr	x2, [sp, #584]
    8fb8:	f9400001 	ldr	x1, [x0]
    8fbc:	eb010042 	subs	x2, x2, x1
    8fc0:	d2800001 	mov	x1, #0x0                   	// #0
    8fc4:	54ffd721 	b.ne	8aa8 <fwp_write+0x898>  // b.any
    8fc8:	f9413bf5 	ldr	x21, [sp, #624]
    8fcc:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8fd0:	f9413ff6 	ldr	x22, [sp, #632]
    8fd4:	aa1403e0 	mov	x0, x20
    8fd8:	f94143f7 	ldr	x23, [sp, #640]
    8fdc:	91184021 	add	x1, x1, #0x610
    8fe0:	f94147f8 	ldr	x24, [sp, #648]
    8fe4:	d2800042 	mov	x2, #0x2                   	// #2
    8fe8:	17fffd0e 	b	8420 <fwp_write+0x210>
    8fec:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8ff0:	d2800042 	mov	x2, #0x2                   	// #2
    8ff4:	91152021 	add	x1, x1, #0x548
    8ff8:	17fffea3 	b	8a84 <fwp_write+0x874>
    8ffc:	f9400a63 	ldr	x3, [x19, #16]
    9000:	8b030021 	add	x1, x1, x3
    9004:	17ffff66 	b	8d9c <fwp_write+0xb8c>
    9008:	f9400a61 	ldr	x1, [x19, #16]
    900c:	8b0102a1 	add	x1, x21, x1
    9010:	17fffdb3 	b	86dc <fwp_write+0x4cc>
    9014:	f9400a63 	ldr	x3, [x19, #16]
    9018:	8b030021 	add	x1, x1, x3
    901c:	17ffff56 	b	8d74 <fwp_write+0xb64>
    9020:	b9404840 	ldr	w0, [x2, #72]
    9024:	91001ff5 	add	x21, sp, #0x7
    9028:	34ffa360 	cbz	w0, 8494 <fwp_write+0x284>
    902c:	52800503 	mov	w3, #0x28                  	// #40
    9030:	aa1403e0 	mov	x0, x20
    9034:	aa1503e1 	mov	x1, x21
    9038:	d2800022 	mov	x2, #0x1                   	// #1
    903c:	39001fe3 	strb	w3, [sp, #7]
    9040:	97ffe8d4 	bl	3390 <buf_put>
    9044:	b9401380 	ldr	w0, [x28, #16]
    9048:	52800038 	mov	w24, #0x1                   	// #1
    904c:	7100001f 	cmp	w0, #0x0
    9050:	54ffa36c 	b.gt	84bc <fwp_write+0x2ac>
    9054:	17fffd32 	b	851c <fwp_write+0x30c>
    9058:	f9014bf9 	str	x25, [sp, #656]
    905c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xeea0>
    9060:	f9014ffa 	str	x26, [sp, #664]
    9064:	f9400676 	ldr	x22, [x19, #8]
    9068:	91102333 	add	x19, x25, #0x408
    906c:	91002273 	add	x19, x19, #0x8
    9070:	937ffed8 	asr	x24, x22, #63
    9074:	aa1802c0 	orr	x0, x22, x24
    9078:	b5000320 	cbnz	x0, 90dc <fwp_write+0xecc>
    907c:	110006b5 	add	w21, w21, #0x1
    9080:	710016bf 	cmp	w21, #0x5
    9084:	54ffffc1 	b.ne	907c <fwp_write+0xe6c>  // b.any
    9088:	b7f80578 	tbnz	x24, #63, 9134 <fwp_write+0xf24>
    908c:	910023f3 	add	x19, sp, #0x8
    9090:	aa1603e2 	mov	x2, x22
    9094:	aa1303e0 	mov	x0, x19
    9098:	d2800003 	mov	x3, #0x0                   	// #0
    909c:	97ffe741 	bl	2da0 <fwp_fmt_u128>
    90a0:	910123f5 	add	x21, sp, #0x48
    90a4:	90000023 	adrp	x3, d000 <__modti3+0x320>
    90a8:	aa1303e4 	mov	x4, x19
    90ac:	aa1503e0 	mov	x0, x21
    90b0:	91182063 	add	x3, x3, #0x608
    90b4:	d2804002 	mov	x2, #0x200                 	// #512
    90b8:	52800041 	mov	w1, #0x2                   	// #2
    90bc:	97ffe575 	bl	2690 <__sprintf_chk@plt>
    90c0:	aa1503e0 	mov	x0, x21
    90c4:	97ffe56f 	bl	2680 <strlen@plt>
    90c8:	aa1503e1 	mov	x1, x21
    90cc:	aa0003e2 	mov	x2, x0
    90d0:	aa1403e0 	mov	x0, x20
    90d4:	97ffe8af 	bl	3390 <buf_put>
    90d8:	17fffe47 	b	89f4 <fwp_write+0x7e4>
    90dc:	f9400277 	ldr	x23, [x19]
    90e0:	aa1603e0 	mov	x0, x22
    90e4:	aa1803e1 	mov	x1, x24
    90e8:	aa1703e2 	mov	x2, x23
    90ec:	937ffefa 	asr	x26, x23, #63
    90f0:	aa1a03e3 	mov	x3, x26
    90f4:	94000efb 	bl	cce0 <__modti3>
    90f8:	aa010000 	orr	x0, x0, x1
    90fc:	b40002c0 	cbz	x0, 9154 <fwp_write+0xf44>
    9100:	110006b5 	add	w21, w21, #0x1
    9104:	91004273 	add	x19, x19, #0x10
    9108:	710016bf 	cmp	w21, #0x5
    910c:	54fffe81 	b.ne	90dc <fwp_write+0xecc>  // b.any
    9110:	17ffffde 	b	9088 <fwp_write+0xe78>
    9114:	f9400a60 	ldr	x0, [x19, #16]
    9118:	8b000021 	add	x1, x1, x0
    911c:	17fffd75 	b	86f0 <fwp_write+0x4e0>
    9120:	528c29c0 	mov	w0, #0x614e                	// #24910
    9124:	910123f5 	add	x21, sp, #0x48
    9128:	72a009c0 	movk	w0, #0x4e, lsl #16
    912c:	b9004be0 	str	w0, [sp, #72]
    9130:	17fffda2 	b	87b8 <fwp_write+0x5a8>
    9134:	528005a1 	mov	w1, #0x2d                  	// #45
    9138:	eb1603e2 	negs	x2, x22
    913c:	da1803e3 	ngc	x3, x24
    9140:	910027e0 	add	x0, sp, #0x9
    9144:	910023f3 	add	x19, sp, #0x8
    9148:	390023e1 	strb	w1, [sp, #8]
    914c:	97ffe715 	bl	2da0 <fwp_fmt_u128>
    9150:	17ffffd4 	b	90a0 <fwp_write+0xe90>
    9154:	aa1703e2 	mov	x2, x23
    9158:	aa1a03e3 	mov	x3, x26
    915c:	aa1603e0 	mov	x0, x22
    9160:	aa1803e1 	mov	x1, x24
    9164:	94000dff 	bl	c960 <__divti3>
    9168:	aa0003e2 	mov	x2, x0
    916c:	aa0103e3 	mov	x3, x1
    9170:	b7f80201 	tbnz	x1, #63, 91b0 <fwp_write+0xfa0>
    9174:	910023f3 	add	x19, sp, #0x8
    9178:	aa1303e0 	mov	x0, x19
    917c:	97ffe709 	bl	2da0 <fwp_fmt_u128>
    9180:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9184:	91102339 	add	x25, x25, #0x408
    9188:	910123f5 	add	x21, sp, #0x48
    918c:	aa1303e4 	mov	x4, x19
    9190:	aa1503e0 	mov	x0, x21
    9194:	90000023 	adrp	x3, d000 <__modti3+0x320>
    9198:	f8616b25 	ldr	x5, [x25, x1]
    919c:	91180063 	add	x3, x3, #0x600
    91a0:	d2804002 	mov	x2, #0x200                 	// #512
    91a4:	52800041 	mov	w1, #0x2                   	// #2
    91a8:	97ffe53a 	bl	2690 <__sprintf_chk@plt>
    91ac:	17ffffc5 	b	90c0 <fwp_write+0xeb0>
    91b0:	528005a4 	mov	w4, #0x2d                  	// #45
    91b4:	eb0003e2 	negs	x2, x0
    91b8:	da0103e3 	ngc	x3, x1
    91bc:	910027e0 	add	x0, sp, #0x9
    91c0:	910023f3 	add	x19, sp, #0x8
    91c4:	390023e4 	strb	w4, [sp, #8]
    91c8:	97ffe6f6 	bl	2da0 <fwp_fmt_u128>
    91cc:	17ffffed 	b	9180 <fwp_write+0xf70>
    91d0:	f9013bf5 	str	x21, [sp, #624]
    91d4:	f9013ff6 	str	x22, [sp, #632]
    91d8:	f90143f7 	str	x23, [sp, #640]
    91dc:	f90147f8 	str	x24, [sp, #648]
    91e0:	f9014bf9 	str	x25, [sp, #656]
    91e4:	f9014ffa 	str	x26, [sp, #664]
    91e8:	f90153fb 	str	x27, [sp, #672]
    91ec:	f90157fc 	str	x28, [sp, #680]
    91f0:	fd015be8 	str	d8, [sp, #688]
    91f4:	fd015fe9 	str	d9, [sp, #696]
    91f8:	97ffe57e 	bl	27f0 <__stack_chk_fail@plt>
    91fc:	d503201f 	nop

0000000000009200 <fwp_hof0.constprop.0>:
    9200:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9204:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9208:	f947f442 	ldr	x2, [x2, #4072]
    920c:	910003fd 	mov	x29, sp
    9210:	a90153f3 	stp	x19, x20, [sp, #16]
    9214:	a9025bf5 	stp	x21, x22, [sp, #32]
    9218:	a90363f7 	stp	x23, x24, [sp, #48]
    921c:	aa0003f7 	mov	x23, x0
    9220:	a9046bf9 	stp	x25, x26, [sp, #64]
    9224:	a90573fb 	stp	x27, x28, [sp, #80]
    9228:	d10243ff 	sub	sp, sp, #0x90
    922c:	f9400040 	ldr	x0, [x2]
    9230:	f81f83a0 	stur	x0, [x29, #-8]
    9234:	d2800000 	mov	x0, #0x0                   	// #0
    9238:	b4002da1 	cbz	x1, 97ec <fwp_hof0.constprop.0+0x5ec>
    923c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9240:	9100401c 	add	x28, x0, #0x10
    9244:	9100239c 	add	x28, x28, #0x8
    9248:	f00000a0 	adrp	x0, 20000 <__data_start>
    924c:	aa0103fa 	mov	x26, x1
    9250:	d10083b4 	sub	x20, x29, #0x20
    9254:	91010015 	add	x21, x0, #0x40
    9258:	aa1c03f8 	mov	x24, x28
    925c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9260:	91154002 	add	x2, x0, #0x550
    9264:	f949d841 	ldr	x1, [x2, #5040]
    9268:	f949ec40 	ldr	x0, [x2, #5080]
    926c:	cb0102e1 	sub	x1, x23, x1
    9270:	eb00403f 	cmp	x1, x0, lsl #16
    9274:	54000342 	b.cs	92dc <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9278:	d350fc20 	lsr	x0, x1, #16
    927c:	f949fc44 	ldr	x4, [x2, #5112]
    9280:	8b000800 	add	x0, x0, x0, lsl #2
    9284:	d37df002 	lsl	x2, x0, #3
    9288:	8b020083 	add	x3, x4, x2
    928c:	f9401060 	ldr	x0, [x3, #32]
    9290:	b4000260 	cbz	x0, 92dc <fwp_hof0.constprop.0+0xdc>
    9294:	38626882 	ldrb	w2, [x4, x2]
    9298:	7100085f 	cmp	w2, #0x2
    929c:	54005240 	b.eq	9ce4 <fwp_hof0.constprop.0+0xae4>  // b.none
    92a0:	7100045f 	cmp	w2, #0x1
    92a4:	540001c1 	b.ne	92dc <fwp_hof0.constprop.0+0xdc>  // b.any
    92a8:	29430864 	ldp	w4, w2, [x3, #24]
    92ac:	92403c21 	and	x1, x1, #0xffff
    92b0:	9b047c21 	mul	x1, x1, x4
    92b4:	d360fc21 	lsr	x1, x1, #32
    92b8:	eb02003f 	cmp	x1, x2
    92bc:	54000102 	b.cs	92dc <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    92c0:	8b010000 	add	x0, x0, x1
    92c4:	39400001 	ldrb	w1, [x0]
    92c8:	340000a1 	cbz	w1, 92dc <fwp_hof0.constprop.0+0xdc>
    92cc:	7103f43f 	cmp	w1, #0xfd
    92d0:	54005728 	b.hi	9db4 <fwp_hof0.constprop.0+0xbb4>  // b.pmore
    92d4:	11000421 	add	w1, w1, #0x1
    92d8:	39000001 	strb	w1, [x0]
    92dc:	aa1703f9 	mov	x25, x23
    92e0:	a938dfba 	stp	x26, x23, [x29, #-120]
    92e4:	aa1803fa 	mov	x26, x24
    92e8:	d28018f3 	mov	x19, #0xc7                  	// #199
    92ec:	f81983b3 	stur	x19, [x29, #-104]
    92f0:	f00000a0 	adrp	x0, 20000 <__data_start>
    92f4:	91004000 	add	x0, x0, #0x10
    92f8:	f9401ea3 	ldr	x3, [x21, #56]
    92fc:	91002005 	add	x5, x0, #0x8
    9300:	b9400802 	ldr	w2, [x0, #8]
    9304:	d37be842 	lsl	x2, x2, #5
    9308:	8b02007b 	add	x27, x3, x2
    930c:	f9400f61 	ldr	x1, [x27, #24]
    9310:	f81e03b9 	stur	x25, [x29, #-32]
    9314:	b4004ee1 	cbz	x1, 9cf0 <fwp_hof0.constprop.0+0xaf0>
    9318:	f9400c20 	ldr	x0, [x1, #24]
    931c:	b40042a0 	cbz	x0, 9b70 <fwp_hof0.constprop.0+0x970>
    9320:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9324:	91154002 	add	x2, x0, #0x550
    9328:	f949d841 	ldr	x1, [x2, #5040]
    932c:	f949ec40 	ldr	x0, [x2, #5080]
    9330:	cb010341 	sub	x1, x26, x1
    9334:	eb00403f 	cmp	x1, x0, lsl #16
    9338:	54000342 	b.cs	93a0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    933c:	d350fc20 	lsr	x0, x1, #16
    9340:	f949fc45 	ldr	x5, [x2, #5112]
    9344:	8b000800 	add	x0, x0, x0, lsl #2
    9348:	d37df002 	lsl	x2, x0, #3
    934c:	8b0200a3 	add	x3, x5, x2
    9350:	f9401060 	ldr	x0, [x3, #32]
    9354:	b4000260 	cbz	x0, 93a0 <fwp_hof0.constprop.0+0x1a0>
    9358:	386268a2 	ldrb	w2, [x5, x2]
    935c:	7100085f 	cmp	w2, #0x2
    9360:	54004700 	b.eq	9c40 <fwp_hof0.constprop.0+0xa40>  // b.none
    9364:	7100045f 	cmp	w2, #0x1
    9368:	540001c1 	b.ne	93a0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    936c:	29430865 	ldp	w5, w2, [x3, #24]
    9370:	92403c21 	and	x1, x1, #0xffff
    9374:	9b057c21 	mul	x1, x1, x5
    9378:	d360fc21 	lsr	x1, x1, #32
    937c:	eb02003f 	cmp	x1, x2
    9380:	54000102 	b.cs	93a0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    9384:	8b010000 	add	x0, x0, x1
    9388:	39400001 	ldrb	w1, [x0]
    938c:	340000a1 	cbz	w1, 93a0 <fwp_hof0.constprop.0+0x1a0>
    9390:	7103f43f 	cmp	w1, #0xfd
    9394:	54004988 	b.hi	9cc4 <fwp_hof0.constprop.0+0xac4>  // b.pmore
    9398:	11000421 	add	w1, w1, #0x1
    939c:	39000001 	strb	w1, [x0]
    93a0:	aa1a03f9 	mov	x25, x26
    93a4:	aa1a03e0 	mov	x0, x26
    93a8:	aa1b03e3 	mov	x3, x27
    93ac:	52800037 	mov	w23, #0x1                   	// #1
    93b0:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    93b4:	91154036 	add	x22, x1, #0x550
    93b8:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    93bc:	f81b03b6 	stur	x22, [x29, #-80]
    93c0:	b81cc3b7 	stur	w23, [x29, #-52]
    93c4:	f81d03b4 	stur	x20, [x29, #-48]
    93c8:	b9400401 	ldr	w1, [x0, #4]
    93cc:	b9400078 	ldr	w24, [x3]
    93d0:	b85cc3a0 	ldur	w0, [x29, #-52]
    93d4:	4b010318 	sub	w24, w24, w1
    93d8:	6b17031f 	cmp	w24, w23
    93dc:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    93e0:	6b0000ff 	cmp	w7, w0
    93e4:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    93e8:	b81c83a0 	stur	w0, [x29, #-56]
    93ec:	6b0000e2 	subs	w2, w7, w0
    93f0:	54000120 	b.eq	9414 <fwp_hof0.constprop.0+0x214>  // b.none
    93f4:	f9400c63 	ldr	x3, [x3, #24]
    93f8:	0b000021 	add	w1, w1, w0
    93fc:	f85d03a4 	ldur	x4, [x29, #-48]
    9400:	b81d83a7 	stur	w7, [x29, #-40]
    9404:	f9400863 	ldr	x3, [x3, #16]
    9408:	8b204c80 	add	x0, x4, w0, uxtw #3
    940c:	d63f0060 	blr	x3
    9410:	b85d83a7 	ldur	w7, [x29, #-40]
    9414:	f9401ea0 	ldr	x0, [x21, #56]
    9418:	aa1903e6 	mov	x6, x25
    941c:	b9400323 	ldr	w3, [x25]
    9420:	2a0703f4 	mov	w20, w7
    9424:	f85d03bb 	ldur	x27, [x29, #-48]
    9428:	aa1903fc 	mov	x28, x25
    942c:	8b03141a 	add	x26, x0, x3, lsl #5
    9430:	f9400f40 	ldr	x0, [x26, #24]
    9434:	b40020e0 	cbz	x0, 9850 <fwp_hof0.constprop.0+0x650>
    9438:	f85b03bc 	ldur	x28, [x29, #-80]
    943c:	29371fb7 	stp	w23, w7, [x29, #-72]
    9440:	aa1a03f7 	mov	x23, x26
    9444:	b81c03b8 	stur	w24, [x29, #-64]
    9448:	aa1b03f8 	mov	x24, x27
    944c:	14000012 	b	9494 <fwp_hof0.constprop.0+0x294>
    9450:	f9400001 	ldr	x1, [x0]
    9454:	aa1803e0 	mov	x0, x24
    9458:	d63f0020 	blr	x1
    945c:	aa0003fb 	mov	x27, x0
    9460:	aa1903e0 	mov	x0, x25
    9464:	97fff1cb 	bl	5b90 <fwp_closure_drop>
    9468:	6b13029f 	cmp	w20, w19
    946c:	54000ca0 	b.eq	9600 <fwp_hof0.constprop.0+0x400>  // b.none
    9470:	f9401ea0 	ldr	x0, [x21, #56]
    9474:	8b334f18 	add	x24, x24, w19, uxtw #3
    9478:	b9400363 	ldr	w3, [x27]
    947c:	4b1a02d4 	sub	w20, w22, w26
    9480:	aa1b03e6 	mov	x6, x27
    9484:	8b031417 	add	x23, x0, x3, lsl #5
    9488:	f9400ee0 	ldr	x0, [x23, #24]
    948c:	b4001da0 	cbz	x0, 9840 <fwp_hof0.constprop.0+0x640>
    9490:	aa1b03f9 	mov	x25, x27
    9494:	b94004c1 	ldr	w1, [x6, #4]
    9498:	b94002fa 	ldr	w26, [x23]
    949c:	0b010296 	add	w22, w20, w1
    94a0:	6b16035f 	cmp	w26, w22
    94a4:	54002488 	b.hi	9934 <fwp_hof0.constprop.0+0x734>  // b.pmore
    94a8:	7100003f 	cmp	w1, #0x0
    94ac:	4b010353 	sub	w19, w26, w1
    94b0:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    94b4:	54fffce1 	b.ne	9450 <fwp_hof0.constprop.0+0x250>  // b.any
    94b8:	7100035f 	cmp	w26, #0x0
    94bc:	910003e2 	mov	x2, sp
    94c0:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    94c4:	f81d83a2 	stur	x2, [x29, #-40]
    94c8:	d37df084 	lsl	x4, x4, #3
    94cc:	91003c84 	add	x4, x4, #0xf
    94d0:	92704c87 	and	x7, x4, #0xfffff0000
    94d4:	927c7c84 	and	x4, x4, #0xffffffff0
    94d8:	cb2763e7 	sub	x7, sp, x7
    94dc:	eb2763ff 	cmp	sp, x7
    94e0:	540000a0 	b.eq	94f4 <fwp_hof0.constprop.0+0x2f4>  // b.none
    94e4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    94e8:	f90203ff 	str	xzr, [sp, #1024]
    94ec:	eb2763ff 	cmp	sp, x7
    94f0:	54ffffa1 	b.ne	94e4 <fwp_hof0.constprop.0+0x2e4>  // b.any
    94f4:	92403c84 	and	x4, x4, #0xffff
    94f8:	cb2463ff 	sub	sp, sp, x4
    94fc:	f90003ff 	str	xzr, [sp]
    9500:	f110009f 	cmp	x4, #0x400
    9504:	54000043 	b.cc	950c <fwp_hof0.constprop.0+0x30c>  // b.lo, b.ul, b.last
    9508:	f90203ff 	str	xzr, [sp, #1024]
    950c:	910043fb 	add	x27, sp, #0x10
    9510:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9514:	910020c9 	add	x9, x6, #0x8
    9518:	d2800004 	mov	x4, #0x0                   	// #0
    951c:	340000c1 	cbz	w1, 9534 <fwp_hof0.constprop.0+0x334>
    9520:	f8646922 	ldr	x2, [x9, x4]
    9524:	f8246b62 	str	x2, [x27, x4]
    9528:	91002084 	add	x4, x4, #0x8
    952c:	eb04015f 	cmp	x10, x4
    9530:	54ffff81 	b.ne	9520 <fwp_hof0.constprop.0+0x320>  // b.any
    9534:	2a1303ea 	mov	w10, w19
    9538:	d2800004 	mov	x4, #0x0                   	// #0
    953c:	340000f3 	cbz	w19, 9558 <fwp_hof0.constprop.0+0x358>
    9540:	0b040022 	add	w2, w1, w4
    9544:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9548:	91000484 	add	x4, x4, #0x1
    954c:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9550:	eb04015f 	cmp	x10, x4
    9554:	54ffff61 	b.ne	9540 <fwp_hof0.constprop.0+0x340>  // b.any
    9558:	f949db81 	ldr	x1, [x28, #5040]
    955c:	f949ef84 	ldr	x4, [x28, #5080]
    9560:	cb010321 	sub	x1, x25, x1
    9564:	eb04403f 	cmp	x1, x4, lsl #16
    9568:	540002e2 	b.cs	95c4 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    956c:	d350fc24 	lsr	x4, x1, #16
    9570:	f949ff8a 	ldr	x10, [x28, #5112]
    9574:	8b040884 	add	x4, x4, x4, lsl #2
    9578:	d37df084 	lsl	x4, x4, #3
    957c:	8b040149 	add	x9, x10, x4
    9580:	f9401128 	ldr	x8, [x9, #32]
    9584:	b4000208 	cbz	x8, 95c4 <fwp_hof0.constprop.0+0x3c4>
    9588:	38646944 	ldrb	w4, [x10, x4]
    958c:	7100089f 	cmp	w4, #0x2
    9590:	54001520 	b.eq	9834 <fwp_hof0.constprop.0+0x634>  // b.none
    9594:	7100049f 	cmp	w4, #0x1
    9598:	54000161 	b.ne	95c4 <fwp_hof0.constprop.0+0x3c4>  // b.any
    959c:	2943112a 	ldp	w10, w4, [x9, #24]
    95a0:	92403c21 	and	x1, x1, #0xffff
    95a4:	9b0a7c21 	mul	x1, x1, x10
    95a8:	d360fc21 	lsr	x1, x1, #32
    95ac:	eb04003f 	cmp	x1, x4
    95b0:	540000a2 	b.cs	95c4 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    95b4:	8b010108 	add	x8, x8, x1
    95b8:	39400101 	ldrb	w1, [x8]
    95bc:	7100043f 	cmp	w1, #0x1
    95c0:	54001360 	b.eq	982c <fwp_hof0.constprop.0+0x62c>  // b.none
    95c4:	f9400404 	ldr	x4, [x0, #8]
    95c8:	52800021 	mov	w1, #0x1                   	// #1
    95cc:	aa1903e0 	mov	x0, x25
    95d0:	d63f0080 	blr	x4
    95d4:	f9400ee1 	ldr	x1, [x23, #24]
    95d8:	aa1b03e0 	mov	x0, x27
    95dc:	f9400021 	ldr	x1, [x1]
    95e0:	d63f0020 	blr	x1
    95e4:	aa0003fb 	mov	x27, x0
    95e8:	f85d83a0 	ldur	x0, [x29, #-40]
    95ec:	9100001f 	mov	sp, x0
    95f0:	aa1903e0 	mov	x0, x25
    95f4:	97fff167 	bl	5b90 <fwp_closure_drop>
    95f8:	6b13029f 	cmp	w20, w19
    95fc:	54fff3a1 	b.ne	9470 <fwp_hof0.constprop.0+0x270>  // b.any
    9600:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9604:	aa1b03f9 	mov	x25, x27
    9608:	b85c03b8 	ldur	w24, [x29, #-64]
    960c:	6b17031f 	cmp	w24, w23
    9610:	540014c3 	b.cc	98a8 <fwp_hof0.constprop.0+0x6a8>  // b.lo, b.ul, b.last
    9614:	f85983a0 	ldur	x0, [x29, #-104]
    9618:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    961c:	f1000400 	subs	x0, x0, #0x1
    9620:	f81983a0 	stur	x0, [x29, #-104]
    9624:	54ffe661 	b.ne	92f0 <fwp_hof0.constprop.0+0xf0>  // b.any
    9628:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xeea0>
    962c:	91102042 	add	x2, x2, #0x408
    9630:	aa1903e1 	mov	x1, x25
    9634:	aa1403e0 	mov	x0, x20
    9638:	aa1a03f8 	mov	x24, x26
    963c:	aa1903fb 	mov	x27, x25
    9640:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9644:	91014042 	add	x2, x2, #0x50
    9648:	52800023 	mov	w3, #0x1                   	// #1
    964c:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9650:	f81f03bf 	stur	xzr, [x29, #-16]
    9654:	97fffaef 	bl	8210 <fwp_write>
    9658:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    965c:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9660:	9129e000 	add	x0, x0, #0xa78
    9664:	f10002df 	cmp	x22, #0x0
    9668:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    966c:	b1002b3f 	cmn	x25, #0xa
    9670:	540039c8 	b.hi	9da8 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    9674:	91002720 	add	x0, x25, #0x9
    9678:	52800021 	mov	w1, #0x1                   	// #1
    967c:	97ffed5d 	bl	4bf0 <fwp_heap_alloc>
    9680:	aa0003f3 	mov	x19, x0
    9684:	aa1603e1 	mov	x1, x22
    9688:	aa0003f6 	mov	x22, x0
    968c:	aa1903e2 	mov	x2, x25
    9690:	f80086d9 	str	x25, [x22], #8
    9694:	8b190279 	add	x25, x19, x25
    9698:	aa1603e0 	mov	x0, x22
    969c:	97ffe3e9 	bl	2640 <memcpy@plt>
    96a0:	3900233f 	strb	wzr, [x25, #8]
    96a4:	f85e03a0 	ldur	x0, [x29, #-32]
    96a8:	97ffe482 	bl	28b0 <free@plt>
    96ac:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    96b0:	91154002 	add	x2, x0, #0x550
    96b4:	f949d841 	ldr	x1, [x2, #5040]
    96b8:	f949ec40 	ldr	x0, [x2, #5080]
    96bc:	cb010261 	sub	x1, x19, x1
    96c0:	eb00403f 	cmp	x1, x0, lsl #16
    96c4:	54000322 	b.cs	9728 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    96c8:	d350fc20 	lsr	x0, x1, #16
    96cc:	f949fc43 	ldr	x3, [x2, #5112]
    96d0:	8b000800 	add	x0, x0, x0, lsl #2
    96d4:	d37df002 	lsl	x2, x0, #3
    96d8:	8b020060 	add	x0, x3, x2
    96dc:	f9401019 	ldr	x25, [x0, #32]
    96e0:	b4000259 	cbz	x25, 9728 <fwp_hof0.constprop.0+0x528>
    96e4:	38626862 	ldrb	w2, [x3, x2]
    96e8:	7100085f 	cmp	w2, #0x2
    96ec:	54003220 	b.eq	9d30 <fwp_hof0.constprop.0+0xb30>  // b.none
    96f0:	7100045f 	cmp	w2, #0x1
    96f4:	540001a1 	b.ne	9728 <fwp_hof0.constprop.0+0x528>  // b.any
    96f8:	29430002 	ldp	w2, w0, [x0, #24]
    96fc:	92403c21 	and	x1, x1, #0xffff
    9700:	9b027c21 	mul	x1, x1, x2
    9704:	d360fc21 	lsr	x1, x1, #32
    9708:	eb00003f 	cmp	x1, x0
    970c:	540000e2 	b.cs	9728 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9710:	8b010339 	add	x25, x25, x1
    9714:	39400320 	ldrb	w0, [x25]
    9718:	7103fc1f 	cmp	w0, #0xff
    971c:	54003520 	b.eq	9dc0 <fwp_hof0.constprop.0+0xbc0>  // b.none
    9720:	52800020 	mov	w0, #0x1                   	// #1
    9724:	39000320 	strb	w0, [x25]
    9728:	aa1b03e0 	mov	x0, x27
    972c:	97fff0bd 	bl	5a20 <fwp_drop0>
    9730:	f00000a0 	adrp	x0, 20000 <__data_start>
    9734:	91010003 	add	x3, x0, #0x40
    9738:	f9400262 	ldr	x2, [x19]
    973c:	aa1603e0 	mov	x0, x22
    9740:	aa0303f6 	mov	x22, x3
    9744:	d2800021 	mov	x1, #0x1                   	// #1
    9748:	f9400463 	ldr	x3, [x3, #8]
    974c:	97ffe469 	bl	28f0 <fwrite@plt>
    9750:	f94006c1 	ldr	x1, [x22, #8]
    9754:	52800140 	mov	w0, #0xa                   	// #10
    9758:	97ffe3ee 	bl	2710 <fputc@plt>
    975c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9760:	91154002 	add	x2, x0, #0x550
    9764:	f949d841 	ldr	x1, [x2, #5040]
    9768:	f949ec40 	ldr	x0, [x2, #5080]
    976c:	cb010261 	sub	x1, x19, x1
    9770:	eb00403f 	cmp	x1, x0, lsl #16
    9774:	54000382 	b.cs	97e4 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9778:	d350fc20 	lsr	x0, x1, #16
    977c:	f949fc43 	ldr	x3, [x2, #5112]
    9780:	8b000800 	add	x0, x0, x0, lsl #2
    9784:	d37df000 	lsl	x0, x0, #3
    9788:	8b000062 	add	x2, x3, x0
    978c:	f9401056 	ldr	x22, [x2, #32]
    9790:	b40002b6 	cbz	x22, 97e4 <fwp_hof0.constprop.0+0x5e4>
    9794:	38606860 	ldrb	w0, [x3, x0]
    9798:	7100081f 	cmp	w0, #0x2
    979c:	54002c40 	b.eq	9d24 <fwp_hof0.constprop.0+0xb24>  // b.none
    97a0:	7100041f 	cmp	w0, #0x1
    97a4:	54000201 	b.ne	97e4 <fwp_hof0.constprop.0+0x5e4>  // b.any
    97a8:	29430043 	ldp	w3, w0, [x2, #24]
    97ac:	92403c21 	and	x1, x1, #0xffff
    97b0:	9b037c21 	mul	x1, x1, x3
    97b4:	d360fc21 	lsr	x1, x1, #32
    97b8:	eb00003f 	cmp	x1, x0
    97bc:	54000142 	b.cs	97e4 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    97c0:	8b0102d6 	add	x22, x22, x1
    97c4:	394002c0 	ldrb	w0, [x22]
    97c8:	340000e0 	cbz	w0, 97e4 <fwp_hof0.constprop.0+0x5e4>
    97cc:	7100041f 	cmp	w0, #0x1
    97d0:	54002a00 	b.eq	9d10 <fwp_hof0.constprop.0+0xb10>  // b.none
    97d4:	7103fc1f 	cmp	w0, #0xff
    97d8:	54002b20 	b.eq	9d3c <fwp_hof0.constprop.0+0xb3c>  // b.none
    97dc:	51000400 	sub	w0, w0, #0x1
    97e0:	390002c0 	strb	w0, [x22]
    97e4:	f9400b5a 	ldr	x26, [x26, #16]
    97e8:	b5ffd3ba 	cbnz	x26, 925c <fwp_hof0.constprop.0+0x5c>
    97ec:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    97f0:	f947f400 	ldr	x0, [x0, #4072]
    97f4:	f85f83a2 	ldur	x2, [x29, #-8]
    97f8:	f9400001 	ldr	x1, [x0]
    97fc:	eb010042 	subs	x2, x2, x1
    9800:	d2800001 	mov	x1, #0x0                   	// #0
    9804:	54002dc1 	b.ne	9dbc <fwp_hof0.constprop.0+0xbbc>  // b.any
    9808:	910003bf 	mov	sp, x29
    980c:	d2800000 	mov	x0, #0x0                   	// #0
    9810:	a94153f3 	ldp	x19, x20, [sp, #16]
    9814:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9818:	a94363f7 	ldp	x23, x24, [sp, #48]
    981c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9820:	a94573fb 	ldp	x27, x28, [sp, #80]
    9824:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9828:	d65f03c0 	ret
    982c:	b90004df 	str	wzr, [x6, #4]
    9830:	17ffff69 	b	95d4 <fwp_hof0.constprop.0+0x3d4>
    9834:	72003c3f 	tst	w1, #0xffff
    9838:	54ffec61 	b.ne	95c4 <fwp_hof0.constprop.0+0x3c4>  // b.any
    983c:	17ffff5f 	b	95b8 <fwp_hof0.constprop.0+0x3b8>
    9840:	aa1b03fc 	mov	x28, x27
    9844:	aa1803fb 	mov	x27, x24
    9848:	29771fb7 	ldp	w23, w7, [x29, #-72]
    984c:	b85c03b8 	ldur	w24, [x29, #-64]
    9850:	aa1c03e0 	mov	x0, x28
    9854:	b81d83a7 	stur	w7, [x29, #-40]
    9858:	97ffeef2 	bl	5420 <fwp_rc_share>
    985c:	b85d83a7 	ldur	w7, [x29, #-40]
    9860:	34000134 	cbz	w20, 9884 <fwp_hof0.constprop.0+0x684>
    9864:	aa1b03f6 	mov	x22, x27
    9868:	8b344f73 	add	x19, x27, w20, uxtw #3
    986c:	2a0703f9 	mov	w25, w7
    9870:	f84086c0 	ldr	x0, [x22], #8
    9874:	97ffeeeb 	bl	5420 <fwp_rc_share>
    9878:	eb16027f 	cmp	x19, x22
    987c:	54ffffa1 	b.ne	9870 <fwp_hof0.constprop.0+0x670>  // b.any
    9880:	2a1903e7 	mov	w7, w25
    9884:	aa1b03e2 	mov	x2, x27
    9888:	2a1403e1 	mov	w1, w20
    988c:	aa1c03e0 	mov	x0, x28
    9890:	b81d83a7 	stur	w7, [x29, #-40]
    9894:	97ffed1c 	bl	4d04 <fwp_apply>
    9898:	aa0003f9 	mov	x25, x0
    989c:	b85d83a7 	ldur	w7, [x29, #-40]
    98a0:	6b17031f 	cmp	w24, w23
    98a4:	54ffeb82 	b.cs	9614 <fwp_hof0.constprop.0+0x414>  // b.hs, b.nlast
    98a8:	f9401ea1 	ldr	x1, [x21, #56]
    98ac:	4b0702f7 	sub	w23, w23, w7
    98b0:	b9400323 	ldr	w3, [x25]
    98b4:	f85d03a0 	ldur	x0, [x29, #-48]
    98b8:	8b031423 	add	x3, x1, x3, lsl #5
    98bc:	b85c83a2 	ldur	w2, [x29, #-56]
    98c0:	8b274c00 	add	x0, x0, w7, uxtw #3
    98c4:	f81d03a0 	stur	x0, [x29, #-48]
    98c8:	f9400c61 	ldr	x1, [x3, #24]
    98cc:	b85cc3a0 	ldur	w0, [x29, #-52]
    98d0:	4b020000 	sub	w0, w0, w2
    98d4:	b81cc3a0 	stur	w0, [x29, #-52]
    98d8:	aa1903e0 	mov	x0, x25
    98dc:	b5ffd761 	cbnz	x1, 93c8 <fwp_hof0.constprop.0+0x1c8>
    98e0:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    98e4:	aa1903e0 	mov	x0, x25
    98e8:	97ffeece 	bl	5420 <fwp_rc_share>
    98ec:	34000117 	cbz	w23, 990c <fwp_hof0.constprop.0+0x70c>
    98f0:	f85d03b8 	ldur	x24, [x29, #-48]
    98f4:	d2800016 	mov	x22, #0x0                   	// #0
    98f8:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    98fc:	910006d6 	add	x22, x22, #0x1
    9900:	97ffeec8 	bl	5420 <fwp_rc_share>
    9904:	6b1602ff 	cmp	w23, w22
    9908:	54ffff88 	b.hi	98f8 <fwp_hof0.constprop.0+0x6f8>  // b.pmore
    990c:	f85d03a2 	ldur	x2, [x29, #-48]
    9910:	aa1903e0 	mov	x0, x25
    9914:	2a1703e1 	mov	w1, w23
    9918:	97ffecfb 	bl	4d04 <fwp_apply>
    991c:	aa0003f9 	mov	x25, x0
    9920:	f85983a0 	ldur	x0, [x29, #-104]
    9924:	f1000400 	subs	x0, x0, #0x1
    9928:	f81983a0 	stur	x0, [x29, #-104]
    992c:	54ffce21 	b.ne	92f0 <fwp_hof0.constprop.0+0xf0>  // b.any
    9930:	17ffff3e 	b	9628 <fwp_hof0.constprop.0+0x428>
    9934:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9938:	9115400a 	add	x10, x0, #0x550
    993c:	2a0103fc 	mov	w28, w1
    9940:	110006c0 	add	w0, w22, #0x1
    9944:	f120001f 	cmp	x0, #0x800
    9948:	aa1703fa 	mov	x26, x23
    994c:	b953a541 	ldr	w1, [x10, #5028]
    9950:	aa1803fb 	mov	x27, x24
    9954:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9958:	d37df000 	lsl	x0, x0, #3
    995c:	b85c03b8 	ldur	w24, [x29, #-64]
    9960:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9964:	54001860 	b.eq	9c70 <fwp_hof0.constprop.0+0xa70>  // b.none
    9968:	91003c01 	add	x1, x0, #0xf
    996c:	8b411141 	add	x1, x10, x1, lsr #4
    9970:	397e8021 	ldrb	w1, [x1, #4000]
    9974:	910f002b 	add	x11, x1, #0x3c0
    9978:	8b010429 	add	x9, x1, x1, lsl #1
    997c:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    9980:	8b090d4c 	add	x12, x10, x9, lsl #3
    9984:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    9988:	2a0b03e1 	mov	w1, w11
    998c:	b4001613 	cbz	x19, 9c4c <fwp_hof0.constprop.0+0xa4c>
    9990:	f940026c 	ldr	x12, [x19]
    9994:	aa2c03ec 	mvn	x12, x12
    9998:	f829794c 	str	x12, [x10, x9, lsl #3]
    999c:	eb01001f 	cmp	x0, x1
    99a0:	540000c2 	b.cs	99b8 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    99a4:	d503201f 	nop
    99a8:	f8206a7f 	str	xzr, [x19, x0]
    99ac:	91002000 	add	x0, x0, #0x8
    99b0:	eb00003f 	cmp	x1, x0
    99b4:	54ffffa8 	b.hi	99a8 <fwp_hof0.constprop.0+0x7a8>  // b.pmore
    99b8:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    99bc:	91154009 	add	x9, x0, #0x550
    99c0:	f94a1120 	ldr	x0, [x9, #5152]
    99c4:	ab010000 	adds	x0, x0, x1
    99c8:	54001e82 	b.cs	9d98 <fwp_hof0.constprop.0+0xb98>  // b.hs, b.nlast
    99cc:	f94a1521 	ldr	x1, [x9, #5160]
    99d0:	f90a1120 	str	x0, [x9, #5152]
    99d4:	eb01001f 	cmp	x0, x1
    99d8:	54000049 	b.ls	99e0 <fwp_hof0.constprop.0+0x7e0>  // b.plast
    99dc:	f90a1520 	str	x0, [x9, #5160]
    99e0:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    99e4:	91154000 	add	x0, x0, #0x550
    99e8:	1e630161 	ucvtf	d1, w11
    99ec:	fd4a1c00 	ldr	d0, [x0, #5176]
    99f0:	1e612800 	fadd	d0, d0, d1
    99f4:	fd0a1c00 	str	d0, [x0, #5176]
    99f8:	b94000c0 	ldr	w0, [x6]
    99fc:	29005a60 	stp	w0, w22, [x19]
    9a00:	3400013c 	cbz	w28, 9a24 <fwp_hof0.constprop.0+0x824>
    9a04:	910020c1 	add	x1, x6, #0x8
    9a08:	d37d7f82 	ubfiz	x2, x28, #3, #32
    9a0c:	91002260 	add	x0, x19, #0x8
    9a10:	b81c03a7 	stur	w7, [x29, #-64]
    9a14:	f81d83a6 	stur	x6, [x29, #-40]
    9a18:	97ffe312 	bl	2660 <memmove@plt>
    9a1c:	f85d83a6 	ldur	x6, [x29, #-40]
    9a20:	b85c03a7 	ldur	w7, [x29, #-64]
    9a24:	2a1403e9 	mov	w9, w20
    9a28:	d2800001 	mov	x1, #0x0                   	// #0
    9a2c:	34000114 	cbz	w20, 9a4c <fwp_hof0.constprop.0+0x84c>
    9a30:	0b010380 	add	w0, w28, w1
    9a34:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9a38:	8b000e60 	add	x0, x19, x0, lsl #3
    9a3c:	91000421 	add	x1, x1, #0x1
    9a40:	f9000402 	str	x2, [x0, #8]
    9a44:	eb01013f 	cmp	x9, x1
    9a48:	54ffff41 	b.ne	9a30 <fwp_hof0.constprop.0+0x830>  // b.any
    9a4c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9a50:	91154002 	add	x2, x0, #0x550
    9a54:	f949d840 	ldr	x0, [x2, #5040]
    9a58:	f949ec41 	ldr	x1, [x2, #5080]
    9a5c:	cb000320 	sub	x0, x25, x0
    9a60:	eb01401f 	cmp	x0, x1, lsl #16
    9a64:	540002e2 	b.cs	9ac0 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9a68:	d350fc01 	lsr	x1, x0, #16
    9a6c:	f949fc45 	ldr	x5, [x2, #5112]
    9a70:	8b010821 	add	x1, x1, x1, lsl #2
    9a74:	d37df021 	lsl	x1, x1, #3
    9a78:	8b0100a4 	add	x4, x5, x1
    9a7c:	f9401082 	ldr	x2, [x4, #32]
    9a80:	b4000202 	cbz	x2, 9ac0 <fwp_hof0.constprop.0+0x8c0>
    9a84:	386168a1 	ldrb	w1, [x5, x1]
    9a88:	7100083f 	cmp	w1, #0x2
    9a8c:	54001020 	b.eq	9c90 <fwp_hof0.constprop.0+0xa90>  // b.none
    9a90:	7100043f 	cmp	w1, #0x1
    9a94:	54000161 	b.ne	9ac0 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9a98:	29430485 	ldp	w5, w1, [x4, #24]
    9a9c:	92403c00 	and	x0, x0, #0xffff
    9aa0:	9b057c00 	mul	x0, x0, x5
    9aa4:	d360fc00 	lsr	x0, x0, #32
    9aa8:	eb01001f 	cmp	x0, x1
    9aac:	540000a2 	b.cs	9ac0 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9ab0:	8b000042 	add	x2, x2, x0
    9ab4:	39400040 	ldrb	w0, [x2]
    9ab8:	7100041f 	cmp	w0, #0x1
    9abc:	54000be0 	b.eq	9c38 <fwp_hof0.constprop.0+0xa38>  // b.none
    9ac0:	f9400f42 	ldr	x2, [x26, #24]
    9ac4:	aa1903e0 	mov	x0, x25
    9ac8:	52800021 	mov	w1, #0x1                   	// #1
    9acc:	b81d83a7 	stur	w7, [x29, #-40]
    9ad0:	f9400442 	ldr	x2, [x2, #8]
    9ad4:	d63f0040 	blr	x2
    9ad8:	b85d83a7 	ldur	w7, [x29, #-40]
    9adc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9ae0:	91154002 	add	x2, x0, #0x550
    9ae4:	f949d841 	ldr	x1, [x2, #5040]
    9ae8:	f949ec40 	ldr	x0, [x2, #5080]
    9aec:	cb010261 	sub	x1, x19, x1
    9af0:	eb00403f 	cmp	x1, x0, lsl #16
    9af4:	54000322 	b.cs	9b58 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9af8:	d350fc20 	lsr	x0, x1, #16
    9afc:	f949fc43 	ldr	x3, [x2, #5112]
    9b00:	8b000800 	add	x0, x0, x0, lsl #2
    9b04:	d37df002 	lsl	x2, x0, #3
    9b08:	8b020060 	add	x0, x3, x2
    9b0c:	f9401014 	ldr	x20, [x0, #32]
    9b10:	b4000254 	cbz	x20, 9b58 <fwp_hof0.constprop.0+0x958>
    9b14:	38626862 	ldrb	w2, [x3, x2]
    9b18:	7100085f 	cmp	w2, #0x2
    9b1c:	54000c00 	b.eq	9c9c <fwp_hof0.constprop.0+0xa9c>  // b.none
    9b20:	7100045f 	cmp	w2, #0x1
    9b24:	540001a1 	b.ne	9b58 <fwp_hof0.constprop.0+0x958>  // b.any
    9b28:	29430002 	ldp	w2, w0, [x0, #24]
    9b2c:	92403c21 	and	x1, x1, #0xffff
    9b30:	9b027c21 	mul	x1, x1, x2
    9b34:	d360fc21 	lsr	x1, x1, #32
    9b38:	eb00003f 	cmp	x1, x0
    9b3c:	540000e2 	b.cs	9b58 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9b40:	8b010294 	add	x20, x20, x1
    9b44:	39400280 	ldrb	w0, [x20]
    9b48:	7103fc1f 	cmp	w0, #0xff
    9b4c:	54000b20 	b.eq	9cb0 <fwp_hof0.constprop.0+0xab0>  // b.none
    9b50:	52800020 	mov	w0, #0x1                   	// #1
    9b54:	39000280 	strb	w0, [x20]
    9b58:	aa1903e0 	mov	x0, x25
    9b5c:	b81d83a7 	stur	w7, [x29, #-40]
    9b60:	97fff00c 	bl	5b90 <fwp_closure_drop>
    9b64:	aa1303f9 	mov	x25, x19
    9b68:	b85d83a7 	ldur	w7, [x29, #-40]
    9b6c:	17ffff4d 	b	98a0 <fwp_hof0.constprop.0+0x6a0>
    9b70:	b8626860 	ldr	w0, [x3, x2]
    9b74:	b94004a2 	ldr	w2, [x5, #4]
    9b78:	4b020003 	sub	w3, w0, w2
    9b7c:	7100047f 	cmp	w3, #0x1
    9b80:	54ffbd01 	b.ne	9320 <fwp_hof0.constprop.0+0x120>  // b.any
    9b84:	910003f6 	mov	x22, sp
    9b88:	34000a22 	cbz	w2, 9ccc <fwp_hof0.constprop.0+0xacc>
    9b8c:	7100001f 	cmp	w0, #0x0
    9b90:	d37d7c00 	ubfiz	x0, x0, #3, #32
    9b94:	d2800101 	mov	x1, #0x8                   	// #8
    9b98:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    9b9c:	91003ee0 	add	x0, x23, #0xf
    9ba0:	92704c01 	and	x1, x0, #0xfffff0000
    9ba4:	927c7c00 	and	x0, x0, #0xffffffff0
    9ba8:	cb2163e1 	sub	x1, sp, x1
    9bac:	eb2163ff 	cmp	sp, x1
    9bb0:	540000a0 	b.eq	9bc4 <fwp_hof0.constprop.0+0x9c4>  // b.none
    9bb4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9bb8:	f90203ff 	str	xzr, [sp, #1024]
    9bbc:	eb2163ff 	cmp	sp, x1
    9bc0:	54ffffa1 	b.ne	9bb4 <fwp_hof0.constprop.0+0x9b4>  // b.any
    9bc4:	92403c00 	and	x0, x0, #0xffff
    9bc8:	cb2063ff 	sub	sp, sp, x0
    9bcc:	f90003ff 	str	xzr, [sp]
    9bd0:	f110001f 	cmp	x0, #0x400
    9bd4:	54000043 	b.cc	9bdc <fwp_hof0.constprop.0+0x9dc>  // b.lo, b.ul, b.last
    9bd8:	f90203ff 	str	xzr, [sp, #1024]
    9bdc:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    9be0:	910043f8 	add	x24, sp, #0x10
    9be4:	f00000a0 	adrp	x0, 20000 <__data_start>
    9be8:	91004001 	add	x1, x0, #0x10
    9bec:	aa1c03e2 	mov	x2, x28
    9bf0:	91004021 	add	x1, x1, #0x10
    9bf4:	aa1703e3 	mov	x3, x23
    9bf8:	aa1803e0 	mov	x0, x24
    9bfc:	97ffe2d1 	bl	2740 <__memcpy_chk@plt>
    9c00:	eb1c02ff 	cmp	x23, x28
    9c04:	aa1403e1 	mov	x1, x20
    9c08:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    9c0c:	d2800102 	mov	x2, #0x8                   	// #8
    9c10:	cb1c0063 	sub	x3, x3, x28
    9c14:	8b1c0300 	add	x0, x24, x28
    9c18:	97ffe2ca 	bl	2740 <__memcpy_chk@plt>
    9c1c:	f9400f61 	ldr	x1, [x27, #24]
    9c20:	aa1803e0 	mov	x0, x24
    9c24:	f9400021 	ldr	x1, [x1]
    9c28:	d63f0020 	blr	x1
    9c2c:	aa0003f9 	mov	x25, x0
    9c30:	910002df 	mov	sp, x22
    9c34:	17ffff3b 	b	9920 <fwp_hof0.constprop.0+0x720>
    9c38:	b90004df 	str	wzr, [x6, #4]
    9c3c:	17ffffa8 	b	9adc <fwp_hof0.constprop.0+0x8dc>
    9c40:	72003c3f 	tst	w1, #0xffff
    9c44:	54ffbae1 	b.ne	93a0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    9c48:	17fffdd0 	b	9388 <fwp_hof0.constprop.0+0x188>
    9c4c:	f9400593 	ldr	x19, [x12, #8]
    9c50:	b4000113 	cbz	x19, 9c70 <fwp_hof0.constprop.0+0xa70>
    9c54:	f9400989 	ldr	x9, [x12, #16]
    9c58:	cb130129 	sub	x9, x9, x19
    9c5c:	eb09003f 	cmp	x1, x9
    9c60:	54000088 	b.hi	9c70 <fwp_hof0.constprop.0+0xa70>  // b.pmore
    9c64:	8b010269 	add	x9, x19, x1
    9c68:	f9000589 	str	x9, [x12, #8]
    9c6c:	17ffff4c 	b	999c <fwp_hof0.constprop.0+0x79c>
    9c70:	52800001 	mov	w1, #0x0                   	// #0
    9c74:	f81c03a6 	stur	x6, [x29, #-64]
    9c78:	b81d83a7 	stur	w7, [x29, #-40]
    9c7c:	97ffebdd 	bl	4bf0 <fwp_heap_alloc>
    9c80:	f85c03a6 	ldur	x6, [x29, #-64]
    9c84:	aa0003f3 	mov	x19, x0
    9c88:	b85d83a7 	ldur	w7, [x29, #-40]
    9c8c:	17ffff5b 	b	99f8 <fwp_hof0.constprop.0+0x7f8>
    9c90:	72003c1f 	tst	w0, #0xffff
    9c94:	54fff161 	b.ne	9ac0 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9c98:	17ffff87 	b	9ab4 <fwp_hof0.constprop.0+0x8b4>
    9c9c:	72003c3f 	tst	w1, #0xffff
    9ca0:	54fff5c1 	b.ne	9b58 <fwp_hof0.constprop.0+0x958>  // b.any
    9ca4:	39400280 	ldrb	w0, [x20]
    9ca8:	7103fc1f 	cmp	w0, #0xff
    9cac:	54fff521 	b.ne	9b50 <fwp_hof0.constprop.0+0x950>  // b.any
    9cb0:	aa1403e0 	mov	x0, x20
    9cb4:	b81d83a7 	stur	w7, [x29, #-40]
    9cb8:	97ffea0e 	bl	44f0 <fwp_rc_forget_slot>
    9cbc:	b85d83a7 	ldur	w7, [x29, #-40]
    9cc0:	17ffffa4 	b	9b50 <fwp_hof0.constprop.0+0x950>
    9cc4:	97ffe9c4 	bl	43d4 <fwp_rc_wide_dup>
    9cc8:	17fffdb6 	b	93a0 <fwp_hof0.constprop.0+0x1a0>
    9ccc:	f9400021 	ldr	x1, [x1]
    9cd0:	aa1403e0 	mov	x0, x20
    9cd4:	d63f0020 	blr	x1
    9cd8:	aa0003f9 	mov	x25, x0
    9cdc:	910002df 	mov	sp, x22
    9ce0:	17ffff10 	b	9920 <fwp_hof0.constprop.0+0x720>
    9ce4:	72003c3f 	tst	w1, #0xffff
    9ce8:	54ffafa1 	b.ne	92dc <fwp_hof0.constprop.0+0xdc>  // b.any
    9cec:	17fffd76 	b	92c4 <fwp_hof0.constprop.0+0xc4>
    9cf0:	aa1a03e0 	mov	x0, x26
    9cf4:	97ffedcb 	bl	5420 <fwp_rc_share>
    9cf8:	aa1903e0 	mov	x0, x25
    9cfc:	52800037 	mov	w23, #0x1                   	// #1
    9d00:	97ffedc8 	bl	5420 <fwp_rc_share>
    9d04:	aa1a03f9 	mov	x25, x26
    9d08:	f81d03b4 	stur	x20, [x29, #-48]
    9d0c:	17ffff00 	b	990c <fwp_hof0.constprop.0+0x70c>
    9d10:	aa1303e0 	mov	x0, x19
    9d14:	97ffee18 	bl	5574 <fwp_rc_free_arr>
    9d18:	f9400b5a 	ldr	x26, [x26, #16]
    9d1c:	b5ffaa1a 	cbnz	x26, 925c <fwp_hof0.constprop.0+0x5c>
    9d20:	17fffeb3 	b	97ec <fwp_hof0.constprop.0+0x5ec>
    9d24:	72003c3f 	tst	w1, #0xffff
    9d28:	54ffd5e1 	b.ne	97e4 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9d2c:	17fffea6 	b	97c4 <fwp_hof0.constprop.0+0x5c4>
    9d30:	72003c3f 	tst	w1, #0xffff
    9d34:	54ffcfa1 	b.ne	9728 <fwp_hof0.constprop.0+0x528>  // b.any
    9d38:	17fffe77 	b	9714 <fwp_hof0.constprop.0+0x514>
    9d3c:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9d40:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9d44:	91154021 	add	x1, x1, #0x550
    9d48:	ca402400 	eor	x0, x0, x0, lsr #9
    9d4c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9d50:	f94a2400 	ldr	x0, [x0, #5192]
    9d54:	b5000080 	cbnz	x0, 9d64 <fwp_hof0.constprop.0+0xb64>
    9d58:	14000011 	b	9d9c <fwp_hof0.constprop.0+0xb9c>
    9d5c:	f9400800 	ldr	x0, [x0, #16]
    9d60:	b40001e0 	cbz	x0, 9d9c <fwp_hof0.constprop.0+0xb9c>
    9d64:	f9400001 	ldr	x1, [x0]
    9d68:	eb0102df 	cmp	x22, x1
    9d6c:	54ffff81 	b.ne	9d5c <fwp_hof0.constprop.0+0xb5c>  // b.any
    9d70:	f9400401 	ldr	x1, [x0, #8]
    9d74:	d1000421 	sub	x1, x1, #0x1
    9d78:	f9000401 	str	x1, [x0, #8]
    9d7c:	f103f83f 	cmp	x1, #0xfe
    9d80:	54ffd321 	b.ne	97e4 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9d84:	aa1603e0 	mov	x0, x22
    9d88:	97ffe9da 	bl	44f0 <fwp_rc_forget_slot>
    9d8c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9d90:	390002c0 	strb	w0, [x22]
    9d94:	17fffe94 	b	97e4 <fwp_hof0.constprop.0+0x5e4>
    9d98:	97ffe486 	bl	2fb0 <fwp_heap_oom>
    9d9c:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9da0:	910ca000 	add	x0, x0, #0x328
    9da4:	97ffe5d7 	bl	3500 <fwp_trap>
    9da8:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9dac:	91188000 	add	x0, x0, #0x620
    9db0:	97ffe5d4 	bl	3500 <fwp_trap>
    9db4:	97ffe988 	bl	43d4 <fwp_rc_wide_dup>
    9db8:	17fffd49 	b	92dc <fwp_hof0.constprop.0+0xdc>
    9dbc:	97ffe28d 	bl	27f0 <__stack_chk_fail@plt>
    9dc0:	aa1903e0 	mov	x0, x25
    9dc4:	97ffe9cb 	bl	44f0 <fwp_rc_forget_slot>
    9dc8:	17fffe56 	b	9720 <fwp_hof0.constprop.0+0x520>
    9dcc:	d503201f 	nop

0000000000009dd0 <f0>:
    9dd0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9dd4:	910003fd 	mov	x29, sp
    9dd8:	a90153f3 	stp	x19, x20, [sp, #16]
    9ddc:	a9025bf5 	stp	x21, x22, [sp, #32]
    9de0:	a90363f7 	stp	x23, x24, [sp, #48]
    9de4:	a9046bf9 	stp	x25, x26, [sp, #64]
    9de8:	a90573fb 	stp	x27, x28, [sp, #80]
    9dec:	d12183ff 	sub	sp, sp, #0x860
    9df0:	f90203ff 	str	xzr, [sp, #1024]
    9df4:	f00000a0 	adrp	x0, 20000 <__data_start>
    9df8:	91010005 	add	x5, x0, #0x40
    9dfc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9e00:	f947f400 	ldr	x0, [x0, #4072]
    9e04:	90000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    9e08:	f94160a6 	ldr	x6, [x5, #704]
    9e0c:	f9400001 	ldr	x1, [x0]
    9e10:	f9042fe1 	str	x1, [sp, #2136]
    9e14:	d2800001 	mov	x1, #0x0                   	// #0
    9e18:	91154298 	add	x24, x20, #0x550
    9e1c:	912123f6 	add	x22, sp, #0x848
    9e20:	910023e0 	add	x0, sp, #0x8
    9e24:	910083e2 	add	x2, sp, #0x20
    9e28:	90ffffe1 	adrp	x1, 5000 <fwp_p_ad_push+0xdc>
    9e2c:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9e30:	91234021 	add	x1, x1, #0x8d0
    9e34:	913b4084 	add	x4, x4, #0xed0
    9e38:	d2800013 	mov	x19, #0x0                   	// #0
    9e3c:	d2800119 	mov	x25, #0x8                   	// #8
    9e40:	d2800015 	mov	x21, #0x0                   	// #0
    9e44:	52800037 	mov	w23, #0x1                   	// #1
    9e48:	a90093e6 	stp	x6, x4, [sp, #8]
    9e4c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9e50:	a90307ff 	stp	xzr, x1, [sp, #48]
    9e54:	f90160a0 	str	x0, [x5, #704]
    9e58:	f100073a 	subs	x26, x25, #0x1
    9e5c:	aa1603e1 	mov	x1, x22
    9e60:	da1f02bc 	sbc	x28, x21, xzr
    9e64:	52800020 	mov	w0, #0x1                   	// #1
    9e68:	f90017fa 	str	x26, [sp, #40]
    9e6c:	aa1a03f9 	mov	x25, x26
    9e70:	f90427fa 	str	x26, [sp, #2120]
    9e74:	aa1c03f5 	mov	x21, x28
    9e78:	f9042bf3 	str	x19, [sp, #2128]
    9e7c:	97ffed21 	bl	5300 <fwp_data.part.0.constprop.0>
    9e80:	f949db02 	ldr	x2, [x24, #5040]
    9e84:	aa0003f3 	mov	x19, x0
    9e88:	f949ef00 	ldr	x0, [x24, #5080]
    9e8c:	cb020262 	sub	x2, x19, x2
    9e90:	eb00405f 	cmp	x2, x0, lsl #16
    9e94:	54000302 	b.cs	9ef4 <f0+0x124>  // b.hs, b.nlast
    9e98:	d350fc40 	lsr	x0, x2, #16
    9e9c:	f949ff04 	ldr	x4, [x24, #5112]
    9ea0:	8b000800 	add	x0, x0, x0, lsl #2
    9ea4:	d37df001 	lsl	x1, x0, #3
    9ea8:	8b010080 	add	x0, x4, x1
    9eac:	f940101b 	ldr	x27, [x0, #32]
    9eb0:	b400023b 	cbz	x27, 9ef4 <f0+0x124>
    9eb4:	38616881 	ldrb	w1, [x4, x1]
    9eb8:	7100083f 	cmp	w1, #0x2
    9ebc:	54010d40 	b.eq	c064 <f0+0x2294>  // b.none
    9ec0:	7100043f 	cmp	w1, #0x1
    9ec4:	54000181 	b.ne	9ef4 <f0+0x124>  // b.any
    9ec8:	29430001 	ldp	w1, w0, [x0, #24]
    9ecc:	92403c42 	and	x2, x2, #0xffff
    9ed0:	9b017c42 	mul	x2, x2, x1
    9ed4:	d360fc42 	lsr	x2, x2, #32
    9ed8:	eb00005f 	cmp	x2, x0
    9edc:	540000c2 	b.cs	9ef4 <f0+0x124>  // b.hs, b.nlast
    9ee0:	8b02037b 	add	x27, x27, x2
    9ee4:	39400360 	ldrb	w0, [x27]
    9ee8:	7103fc1f 	cmp	w0, #0xff
    9eec:	54010b60 	b.eq	c058 <f0+0x2288>  // b.none
    9ef0:	39000377 	strb	w23, [x27]
    9ef4:	f90013f3 	str	x19, [sp, #32]
    9ef8:	aa1c035a 	orr	x26, x26, x28
    9efc:	b5fffafa 	cbnz	x26, 9e58 <f0+0x88>
    9f00:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9f04:	910103e1 	add	x1, sp, #0x40
    9f08:	f94007e2 	ldr	x2, [sp, #8]
    9f0c:	3dc35000 	ldr	q0, [x0, #3392]
    9f10:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f14:	91010018 	add	x24, x0, #0x40
    9f18:	52800020 	mov	w0, #0x1                   	// #1
    9f1c:	3d8013e0 	str	q0, [sp, #64]
    9f20:	f9016302 	str	x2, [x24, #704]
    9f24:	97ffecf7 	bl	5300 <fwp_data.part.0.constprop.0>
    9f28:	91154283 	add	x3, x20, #0x550
    9f2c:	aa0003f5 	mov	x21, x0
    9f30:	f949d861 	ldr	x1, [x3, #5040]
    9f34:	f949ec60 	ldr	x0, [x3, #5080]
    9f38:	cb0102a1 	sub	x1, x21, x1
    9f3c:	eb00403f 	cmp	x1, x0, lsl #16
    9f40:	54000322 	b.cs	9fa4 <f0+0x1d4>  // b.hs, b.nlast
    9f44:	d350fc22 	lsr	x2, x1, #16
    9f48:	f949fc63 	ldr	x3, [x3, #5112]
    9f4c:	8b020842 	add	x2, x2, x2, lsl #2
    9f50:	d37df042 	lsl	x2, x2, #3
    9f54:	8b020060 	add	x0, x3, x2
    9f58:	f9401017 	ldr	x23, [x0, #32]
    9f5c:	b4000257 	cbz	x23, 9fa4 <f0+0x1d4>
    9f60:	38626862 	ldrb	w2, [x3, x2]
    9f64:	7100085f 	cmp	w2, #0x2
    9f68:	54010c00 	b.eq	c0e8 <f0+0x2318>  // b.none
    9f6c:	7100045f 	cmp	w2, #0x1
    9f70:	540001a1 	b.ne	9fa4 <f0+0x1d4>  // b.any
    9f74:	29430002 	ldp	w2, w0, [x0, #24]
    9f78:	92403c21 	and	x1, x1, #0xffff
    9f7c:	9b027c21 	mul	x1, x1, x2
    9f80:	d360fc21 	lsr	x1, x1, #32
    9f84:	eb00003f 	cmp	x1, x0
    9f88:	540000e2 	b.cs	9fa4 <f0+0x1d4>  // b.hs, b.nlast
    9f8c:	8b0102f7 	add	x23, x23, x1
    9f90:	394002e0 	ldrb	w0, [x23]
    9f94:	7103fc1f 	cmp	w0, #0xff
    9f98:	540115c0 	b.eq	c250 <f0+0x2480>  // b.none
    9f9c:	52800020 	mov	w0, #0x1                   	// #1
    9fa0:	390002e0 	strb	w0, [x23]
    9fa4:	910163e1 	add	x1, sp, #0x58
    9fa8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    9fac:	52800020 	mov	w0, #0x1                   	// #1
    9fb0:	a905d7f7 	stp	x23, x21, [sp, #88]
    9fb4:	97ffecd3 	bl	5300 <fwp_data.part.0.constprop.0>
    9fb8:	97ffed3f 	bl	54b4 <fwp_rc_fresh>
    9fbc:	aa0003e2 	mov	x2, x0
    9fc0:	9101a3e1 	add	x1, sp, #0x68
    9fc4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    9fc8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    9fcc:	52800020 	mov	w0, #0x1                   	// #1
    9fd0:	a9068bf5 	stp	x21, x2, [sp, #104]
    9fd4:	97ffeccb 	bl	5300 <fwp_data.part.0.constprop.0>
    9fd8:	97ffed37 	bl	54b4 <fwp_rc_fresh>
    9fdc:	aa0003e2 	mov	x2, x0
    9fe0:	9101e3e1 	add	x1, sp, #0x78
    9fe4:	52800020 	mov	w0, #0x1                   	// #1
    9fe8:	a9078bf7 	stp	x23, x2, [sp, #120]
    9fec:	97ffecc5 	bl	5300 <fwp_data.part.0.constprop.0>
    9ff0:	97ffed31 	bl	54b4 <fwp_rc_fresh>
    9ff4:	aa0003e2 	mov	x2, x0
    9ff8:	910223e1 	add	x1, sp, #0x88
    9ffc:	52800020 	mov	w0, #0x1                   	// #1
    a000:	a9088bf5 	stp	x21, x2, [sp, #136]
    a004:	97ffecbf 	bl	5300 <fwp_data.part.0.constprop.0>
    a008:	97ffed2b 	bl	54b4 <fwp_rc_fresh>
    a00c:	aa0003e2 	mov	x2, x0
    a010:	910263e1 	add	x1, sp, #0x98
    a014:	52800020 	mov	w0, #0x1                   	// #1
    a018:	a9098bf7 	stp	x23, x2, [sp, #152]
    a01c:	97ffecb9 	bl	5300 <fwp_data.part.0.constprop.0>
    a020:	97ffed25 	bl	54b4 <fwp_rc_fresh>
    a024:	aa0003e2 	mov	x2, x0
    a028:	9102a3e1 	add	x1, sp, #0xa8
    a02c:	52800020 	mov	w0, #0x1                   	// #1
    a030:	a90a8bf5 	stp	x21, x2, [sp, #168]
    a034:	97ffecb3 	bl	5300 <fwp_data.part.0.constprop.0>
    a038:	97ffed1f 	bl	54b4 <fwp_rc_fresh>
    a03c:	aa0003e2 	mov	x2, x0
    a040:	9102e3e1 	add	x1, sp, #0xb8
    a044:	52800020 	mov	w0, #0x1                   	// #1
    a048:	a90b8bf7 	stp	x23, x2, [sp, #184]
    a04c:	97ffecad 	bl	5300 <fwp_data.part.0.constprop.0>
    a050:	97ffed19 	bl	54b4 <fwp_rc_fresh>
    a054:	aa0003e2 	mov	x2, x0
    a058:	910323e1 	add	x1, sp, #0xc8
    a05c:	52800020 	mov	w0, #0x1                   	// #1
    a060:	a90c8bf5 	stp	x21, x2, [sp, #200]
    a064:	97ffeca7 	bl	5300 <fwp_data.part.0.constprop.0>
    a068:	97ffed13 	bl	54b4 <fwp_rc_fresh>
    a06c:	aa0003e2 	mov	x2, x0
    a070:	910363e1 	add	x1, sp, #0xd8
    a074:	52800020 	mov	w0, #0x1                   	// #1
    a078:	a90d8bf7 	stp	x23, x2, [sp, #216]
    a07c:	97ffeca1 	bl	5300 <fwp_data.part.0.constprop.0>
    a080:	97ffed0d 	bl	54b4 <fwp_rc_fresh>
    a084:	aa0003e2 	mov	x2, x0
    a088:	9103a3e1 	add	x1, sp, #0xe8
    a08c:	52800020 	mov	w0, #0x1                   	// #1
    a090:	a90e8bf5 	stp	x21, x2, [sp, #232]
    a094:	97ffec9b 	bl	5300 <fwp_data.part.0.constprop.0>
    a098:	97ffed07 	bl	54b4 <fwp_rc_fresh>
    a09c:	aa0003e2 	mov	x2, x0
    a0a0:	9103e3e1 	add	x1, sp, #0xf8
    a0a4:	52800020 	mov	w0, #0x1                   	// #1
    a0a8:	a90f8bf7 	stp	x23, x2, [sp, #248]
    a0ac:	97ffec95 	bl	5300 <fwp_data.part.0.constprop.0>
    a0b0:	97ffed01 	bl	54b4 <fwp_rc_fresh>
    a0b4:	aa0003e2 	mov	x2, x0
    a0b8:	910423e1 	add	x1, sp, #0x108
    a0bc:	52800020 	mov	w0, #0x1                   	// #1
    a0c0:	a9108bf5 	stp	x21, x2, [sp, #264]
    a0c4:	97ffec8f 	bl	5300 <fwp_data.part.0.constprop.0>
    a0c8:	91154283 	add	x3, x20, #0x550
    a0cc:	aa0003f5 	mov	x21, x0
    a0d0:	f949d861 	ldr	x1, [x3, #5040]
    a0d4:	f949ec60 	ldr	x0, [x3, #5080]
    a0d8:	cb0102a1 	sub	x1, x21, x1
    a0dc:	eb00403f 	cmp	x1, x0, lsl #16
    a0e0:	54000322 	b.cs	a144 <f0+0x374>  // b.hs, b.nlast
    a0e4:	d350fc22 	lsr	x2, x1, #16
    a0e8:	f949fc63 	ldr	x3, [x3, #5112]
    a0ec:	8b020842 	add	x2, x2, x2, lsl #2
    a0f0:	d37df042 	lsl	x2, x2, #3
    a0f4:	8b020060 	add	x0, x3, x2
    a0f8:	f9401017 	ldr	x23, [x0, #32]
    a0fc:	b4000257 	cbz	x23, a144 <f0+0x374>
    a100:	38626862 	ldrb	w2, [x3, x2]
    a104:	7100085f 	cmp	w2, #0x2
    a108:	5400fea0 	b.eq	c0dc <f0+0x230c>  // b.none
    a10c:	7100045f 	cmp	w2, #0x1
    a110:	540001a1 	b.ne	a144 <f0+0x374>  // b.any
    a114:	29430002 	ldp	w2, w0, [x0, #24]
    a118:	92403c21 	and	x1, x1, #0xffff
    a11c:	9b027c21 	mul	x1, x1, x2
    a120:	d360fc21 	lsr	x1, x1, #32
    a124:	eb00003f 	cmp	x1, x0
    a128:	540000e2 	b.cs	a144 <f0+0x374>  // b.hs, b.nlast
    a12c:	8b0102f7 	add	x23, x23, x1
    a130:	394002e0 	ldrb	w0, [x23]
    a134:	7103fc1f 	cmp	w0, #0xff
    a138:	54010920 	b.eq	c25c <f0+0x248c>  // b.none
    a13c:	52800020 	mov	w0, #0x1                   	// #1
    a140:	390002e0 	strb	w0, [x23]
    a144:	910463e1 	add	x1, sp, #0x118
    a148:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a14c:	52800020 	mov	w0, #0x1                   	// #1
    a150:	a911d7e2 	stp	x2, x21, [sp, #280]
    a154:	97ffec6b 	bl	5300 <fwp_data.part.0.constprop.0>
    a158:	97ffecd7 	bl	54b4 <fwp_rc_fresh>
    a15c:	aa0003e2 	mov	x2, x0
    a160:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a164:	9104a3e1 	add	x1, sp, #0x128
    a168:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a16c:	52800020 	mov	w0, #0x1                   	// #1
    a170:	a9128be3 	stp	x3, x2, [sp, #296]
    a174:	97ffec63 	bl	5300 <fwp_data.part.0.constprop.0>
    a178:	91154283 	add	x3, x20, #0x550
    a17c:	aa0003f5 	mov	x21, x0
    a180:	f949d861 	ldr	x1, [x3, #5040]
    a184:	f949ec60 	ldr	x0, [x3, #5080]
    a188:	cb0102a1 	sub	x1, x21, x1
    a18c:	eb00403f 	cmp	x1, x0, lsl #16
    a190:	54000322 	b.cs	a1f4 <f0+0x424>  // b.hs, b.nlast
    a194:	d350fc22 	lsr	x2, x1, #16
    a198:	f949fc63 	ldr	x3, [x3, #5112]
    a19c:	8b020842 	add	x2, x2, x2, lsl #2
    a1a0:	d37df042 	lsl	x2, x2, #3
    a1a4:	8b020060 	add	x0, x3, x2
    a1a8:	f9401017 	ldr	x23, [x0, #32]
    a1ac:	b4000257 	cbz	x23, a1f4 <f0+0x424>
    a1b0:	38626862 	ldrb	w2, [x3, x2]
    a1b4:	7100085f 	cmp	w2, #0x2
    a1b8:	5400f8c0 	b.eq	c0d0 <f0+0x2300>  // b.none
    a1bc:	7100045f 	cmp	w2, #0x1
    a1c0:	540001a1 	b.ne	a1f4 <f0+0x424>  // b.any
    a1c4:	29430002 	ldp	w2, w0, [x0, #24]
    a1c8:	92403c21 	and	x1, x1, #0xffff
    a1cc:	9b027c21 	mul	x1, x1, x2
    a1d0:	d360fc21 	lsr	x1, x1, #32
    a1d4:	eb00003f 	cmp	x1, x0
    a1d8:	540000e2 	b.cs	a1f4 <f0+0x424>  // b.hs, b.nlast
    a1dc:	8b0102f7 	add	x23, x23, x1
    a1e0:	394002e0 	ldrb	w0, [x23]
    a1e4:	7103fc1f 	cmp	w0, #0xff
    a1e8:	54010400 	b.eq	c268 <f0+0x2498>  // b.none
    a1ec:	52800020 	mov	w0, #0x1                   	// #1
    a1f0:	390002e0 	strb	w0, [x23]
    a1f4:	9104e3e1 	add	x1, sp, #0x138
    a1f8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a1fc:	52800020 	mov	w0, #0x1                   	// #1
    a200:	a913d7e2 	stp	x2, x21, [sp, #312]
    a204:	97ffec3f 	bl	5300 <fwp_data.part.0.constprop.0>
    a208:	97ffecab 	bl	54b4 <fwp_rc_fresh>
    a20c:	aa0003e2 	mov	x2, x0
    a210:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a214:	910523e1 	add	x1, sp, #0x148
    a218:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a21c:	52800020 	mov	w0, #0x1                   	// #1
    a220:	a9148be3 	stp	x3, x2, [sp, #328]
    a224:	97ffec37 	bl	5300 <fwp_data.part.0.constprop.0>
    a228:	91154283 	add	x3, x20, #0x550
    a22c:	aa0003f5 	mov	x21, x0
    a230:	f949d861 	ldr	x1, [x3, #5040]
    a234:	f949ec60 	ldr	x0, [x3, #5080]
    a238:	cb0102a1 	sub	x1, x21, x1
    a23c:	eb00403f 	cmp	x1, x0, lsl #16
    a240:	54000322 	b.cs	a2a4 <f0+0x4d4>  // b.hs, b.nlast
    a244:	d350fc22 	lsr	x2, x1, #16
    a248:	f949fc63 	ldr	x3, [x3, #5112]
    a24c:	8b020842 	add	x2, x2, x2, lsl #2
    a250:	d37df042 	lsl	x2, x2, #3
    a254:	8b020060 	add	x0, x3, x2
    a258:	f9401017 	ldr	x23, [x0, #32]
    a25c:	b4000257 	cbz	x23, a2a4 <f0+0x4d4>
    a260:	38626862 	ldrb	w2, [x3, x2]
    a264:	7100085f 	cmp	w2, #0x2
    a268:	5400f580 	b.eq	c118 <f0+0x2348>  // b.none
    a26c:	7100045f 	cmp	w2, #0x1
    a270:	540001a1 	b.ne	a2a4 <f0+0x4d4>  // b.any
    a274:	29430002 	ldp	w2, w0, [x0, #24]
    a278:	92403c21 	and	x1, x1, #0xffff
    a27c:	9b027c21 	mul	x1, x1, x2
    a280:	d360fc21 	lsr	x1, x1, #32
    a284:	eb00003f 	cmp	x1, x0
    a288:	540000e2 	b.cs	a2a4 <f0+0x4d4>  // b.hs, b.nlast
    a28c:	8b0102f7 	add	x23, x23, x1
    a290:	394002e0 	ldrb	w0, [x23]
    a294:	7103fc1f 	cmp	w0, #0xff
    a298:	5400fee0 	b.eq	c274 <f0+0x24a4>  // b.none
    a29c:	52800020 	mov	w0, #0x1                   	// #1
    a2a0:	390002e0 	strb	w0, [x23]
    a2a4:	910563e1 	add	x1, sp, #0x158
    a2a8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a2ac:	52800020 	mov	w0, #0x1                   	// #1
    a2b0:	a915d7e2 	stp	x2, x21, [sp, #344]
    a2b4:	97ffec13 	bl	5300 <fwp_data.part.0.constprop.0>
    a2b8:	97ffec7f 	bl	54b4 <fwp_rc_fresh>
    a2bc:	aa0003e2 	mov	x2, x0
    a2c0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a2c4:	9105a3e1 	add	x1, sp, #0x168
    a2c8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a2cc:	52800020 	mov	w0, #0x1                   	// #1
    a2d0:	a9168be3 	stp	x3, x2, [sp, #360]
    a2d4:	97ffec0b 	bl	5300 <fwp_data.part.0.constprop.0>
    a2d8:	91154283 	add	x3, x20, #0x550
    a2dc:	aa0003f5 	mov	x21, x0
    a2e0:	f949d861 	ldr	x1, [x3, #5040]
    a2e4:	f949ec60 	ldr	x0, [x3, #5080]
    a2e8:	cb0102a1 	sub	x1, x21, x1
    a2ec:	eb00403f 	cmp	x1, x0, lsl #16
    a2f0:	54000322 	b.cs	a354 <f0+0x584>  // b.hs, b.nlast
    a2f4:	d350fc22 	lsr	x2, x1, #16
    a2f8:	f949fc63 	ldr	x3, [x3, #5112]
    a2fc:	8b020842 	add	x2, x2, x2, lsl #2
    a300:	d37df042 	lsl	x2, x2, #3
    a304:	8b020060 	add	x0, x3, x2
    a308:	f9401017 	ldr	x23, [x0, #32]
    a30c:	b4000257 	cbz	x23, a354 <f0+0x584>
    a310:	38626862 	ldrb	w2, [x3, x2]
    a314:	7100085f 	cmp	w2, #0x2
    a318:	5400efa0 	b.eq	c10c <f0+0x233c>  // b.none
    a31c:	7100045f 	cmp	w2, #0x1
    a320:	540001a1 	b.ne	a354 <f0+0x584>  // b.any
    a324:	29430002 	ldp	w2, w0, [x0, #24]
    a328:	92403c21 	and	x1, x1, #0xffff
    a32c:	9b027c21 	mul	x1, x1, x2
    a330:	d360fc21 	lsr	x1, x1, #32
    a334:	eb00003f 	cmp	x1, x0
    a338:	540000e2 	b.cs	a354 <f0+0x584>  // b.hs, b.nlast
    a33c:	8b0102f7 	add	x23, x23, x1
    a340:	394002e0 	ldrb	w0, [x23]
    a344:	7103fc1f 	cmp	w0, #0xff
    a348:	5400f9c0 	b.eq	c280 <f0+0x24b0>  // b.none
    a34c:	52800020 	mov	w0, #0x1                   	// #1
    a350:	390002e0 	strb	w0, [x23]
    a354:	9105e3e1 	add	x1, sp, #0x178
    a358:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a35c:	52800020 	mov	w0, #0x1                   	// #1
    a360:	a917d7f7 	stp	x23, x21, [sp, #376]
    a364:	97ffebe7 	bl	5300 <fwp_data.part.0.constprop.0>
    a368:	97ffec53 	bl	54b4 <fwp_rc_fresh>
    a36c:	aa0003e2 	mov	x2, x0
    a370:	910623e1 	add	x1, sp, #0x188
    a374:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a378:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a37c:	52800020 	mov	w0, #0x1                   	// #1
    a380:	a9188bf5 	stp	x21, x2, [sp, #392]
    a384:	97ffebdf 	bl	5300 <fwp_data.part.0.constprop.0>
    a388:	97ffec4b 	bl	54b4 <fwp_rc_fresh>
    a38c:	aa0003e2 	mov	x2, x0
    a390:	910663e1 	add	x1, sp, #0x198
    a394:	52800020 	mov	w0, #0x1                   	// #1
    a398:	a9198bf7 	stp	x23, x2, [sp, #408]
    a39c:	97ffebd9 	bl	5300 <fwp_data.part.0.constprop.0>
    a3a0:	97ffec45 	bl	54b4 <fwp_rc_fresh>
    a3a4:	aa0003e2 	mov	x2, x0
    a3a8:	9106a3e1 	add	x1, sp, #0x1a8
    a3ac:	52800020 	mov	w0, #0x1                   	// #1
    a3b0:	a91a8bf5 	stp	x21, x2, [sp, #424]
    a3b4:	97ffebd3 	bl	5300 <fwp_data.part.0.constprop.0>
    a3b8:	91154283 	add	x3, x20, #0x550
    a3bc:	aa0003f5 	mov	x21, x0
    a3c0:	f949d861 	ldr	x1, [x3, #5040]
    a3c4:	f949ec60 	ldr	x0, [x3, #5080]
    a3c8:	cb0102a1 	sub	x1, x21, x1
    a3cc:	eb00403f 	cmp	x1, x0, lsl #16
    a3d0:	54000322 	b.cs	a434 <f0+0x664>  // b.hs, b.nlast
    a3d4:	d350fc22 	lsr	x2, x1, #16
    a3d8:	f949fc63 	ldr	x3, [x3, #5112]
    a3dc:	8b020842 	add	x2, x2, x2, lsl #2
    a3e0:	d37df042 	lsl	x2, x2, #3
    a3e4:	8b020060 	add	x0, x3, x2
    a3e8:	f9401017 	ldr	x23, [x0, #32]
    a3ec:	b4000257 	cbz	x23, a434 <f0+0x664>
    a3f0:	38626862 	ldrb	w2, [x3, x2]
    a3f4:	7100085f 	cmp	w2, #0x2
    a3f8:	5400e840 	b.eq	c100 <f0+0x2330>  // b.none
    a3fc:	7100045f 	cmp	w2, #0x1
    a400:	540001a1 	b.ne	a434 <f0+0x664>  // b.any
    a404:	29430002 	ldp	w2, w0, [x0, #24]
    a408:	92403c21 	and	x1, x1, #0xffff
    a40c:	9b027c21 	mul	x1, x1, x2
    a410:	d360fc21 	lsr	x1, x1, #32
    a414:	eb00003f 	cmp	x1, x0
    a418:	540000e2 	b.cs	a434 <f0+0x664>  // b.hs, b.nlast
    a41c:	8b0102f7 	add	x23, x23, x1
    a420:	394002e0 	ldrb	w0, [x23]
    a424:	7103fc1f 	cmp	w0, #0xff
    a428:	5400f320 	b.eq	c28c <f0+0x24bc>  // b.none
    a42c:	52800020 	mov	w0, #0x1                   	// #1
    a430:	390002e0 	strb	w0, [x23]
    a434:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a438:	9106e3e1 	add	x1, sp, #0x1b8
    a43c:	52800020 	mov	w0, #0x1                   	// #1
    a440:	a91bd7e2 	stp	x2, x21, [sp, #440]
    a444:	97ffebaf 	bl	5300 <fwp_data.part.0.constprop.0>
    a448:	91154283 	add	x3, x20, #0x550
    a44c:	aa0003f5 	mov	x21, x0
    a450:	f949d861 	ldr	x1, [x3, #5040]
    a454:	f949ec60 	ldr	x0, [x3, #5080]
    a458:	cb0102a1 	sub	x1, x21, x1
    a45c:	eb00403f 	cmp	x1, x0, lsl #16
    a460:	54000322 	b.cs	a4c4 <f0+0x6f4>  // b.hs, b.nlast
    a464:	d350fc22 	lsr	x2, x1, #16
    a468:	f949fc63 	ldr	x3, [x3, #5112]
    a46c:	8b020842 	add	x2, x2, x2, lsl #2
    a470:	d37df042 	lsl	x2, x2, #3
    a474:	8b020060 	add	x0, x3, x2
    a478:	f9401017 	ldr	x23, [x0, #32]
    a47c:	b4000257 	cbz	x23, a4c4 <f0+0x6f4>
    a480:	38626862 	ldrb	w2, [x3, x2]
    a484:	7100085f 	cmp	w2, #0x2
    a488:	5400e360 	b.eq	c0f4 <f0+0x2324>  // b.none
    a48c:	7100045f 	cmp	w2, #0x1
    a490:	540001a1 	b.ne	a4c4 <f0+0x6f4>  // b.any
    a494:	29430002 	ldp	w2, w0, [x0, #24]
    a498:	92403c21 	and	x1, x1, #0xffff
    a49c:	9b027c21 	mul	x1, x1, x2
    a4a0:	d360fc21 	lsr	x1, x1, #32
    a4a4:	eb00003f 	cmp	x1, x0
    a4a8:	540000e2 	b.cs	a4c4 <f0+0x6f4>  // b.hs, b.nlast
    a4ac:	8b0102f7 	add	x23, x23, x1
    a4b0:	394002e0 	ldrb	w0, [x23]
    a4b4:	7103fc1f 	cmp	w0, #0xff
    a4b8:	5400ef00 	b.eq	c298 <f0+0x24c8>  // b.none
    a4bc:	52800020 	mov	w0, #0x1                   	// #1
    a4c0:	390002e0 	strb	w0, [x23]
    a4c4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a4c8:	910723e1 	add	x1, sp, #0x1c8
    a4cc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a4d0:	52800020 	mov	w0, #0x1                   	// #1
    a4d4:	a91cd7e2 	stp	x2, x21, [sp, #456]
    a4d8:	97ffeb8a 	bl	5300 <fwp_data.part.0.constprop.0>
    a4dc:	91154283 	add	x3, x20, #0x550
    a4e0:	aa0003f5 	mov	x21, x0
    a4e4:	f949d861 	ldr	x1, [x3, #5040]
    a4e8:	f949ec60 	ldr	x0, [x3, #5080]
    a4ec:	cb0102a1 	sub	x1, x21, x1
    a4f0:	eb00403f 	cmp	x1, x0, lsl #16
    a4f4:	54000322 	b.cs	a558 <f0+0x788>  // b.hs, b.nlast
    a4f8:	d350fc22 	lsr	x2, x1, #16
    a4fc:	f949fc63 	ldr	x3, [x3, #5112]
    a500:	8b020842 	add	x2, x2, x2, lsl #2
    a504:	d37df042 	lsl	x2, x2, #3
    a508:	8b020060 	add	x0, x3, x2
    a50c:	f9401017 	ldr	x23, [x0, #32]
    a510:	b4000257 	cbz	x23, a558 <f0+0x788>
    a514:	38626862 	ldrb	w2, [x3, x2]
    a518:	7100085f 	cmp	w2, #0x2
    a51c:	5400e2e0 	b.eq	c178 <f0+0x23a8>  // b.none
    a520:	7100045f 	cmp	w2, #0x1
    a524:	540001a1 	b.ne	a558 <f0+0x788>  // b.any
    a528:	29430002 	ldp	w2, w0, [x0, #24]
    a52c:	92403c21 	and	x1, x1, #0xffff
    a530:	9b027c21 	mul	x1, x1, x2
    a534:	d360fc21 	lsr	x1, x1, #32
    a538:	eb00003f 	cmp	x1, x0
    a53c:	540000e2 	b.cs	a558 <f0+0x788>  // b.hs, b.nlast
    a540:	8b0102f7 	add	x23, x23, x1
    a544:	394002e0 	ldrb	w0, [x23]
    a548:	7103fc1f 	cmp	w0, #0xff
    a54c:	5400eac0 	b.eq	c2a4 <f0+0x24d4>  // b.none
    a550:	52800020 	mov	w0, #0x1                   	// #1
    a554:	390002e0 	strb	w0, [x23]
    a558:	910763e1 	add	x1, sp, #0x1d8
    a55c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a560:	52800020 	mov	w0, #0x1                   	// #1
    a564:	a91dd7e2 	stp	x2, x21, [sp, #472]
    a568:	97ffeb66 	bl	5300 <fwp_data.part.0.constprop.0>
    a56c:	97ffebd2 	bl	54b4 <fwp_rc_fresh>
    a570:	aa0003e2 	mov	x2, x0
    a574:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a578:	9107a3e1 	add	x1, sp, #0x1e8
    a57c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a580:	52800020 	mov	w0, #0x1                   	// #1
    a584:	a91e8be3 	stp	x3, x2, [sp, #488]
    a588:	97ffeb5e 	bl	5300 <fwp_data.part.0.constprop.0>
    a58c:	91154283 	add	x3, x20, #0x550
    a590:	aa0003f5 	mov	x21, x0
    a594:	f949d861 	ldr	x1, [x3, #5040]
    a598:	f949ec60 	ldr	x0, [x3, #5080]
    a59c:	cb0102a1 	sub	x1, x21, x1
    a5a0:	eb00403f 	cmp	x1, x0, lsl #16
    a5a4:	54000322 	b.cs	a608 <f0+0x838>  // b.hs, b.nlast
    a5a8:	d350fc22 	lsr	x2, x1, #16
    a5ac:	f949fc63 	ldr	x3, [x3, #5112]
    a5b0:	8b020842 	add	x2, x2, x2, lsl #2
    a5b4:	d37df042 	lsl	x2, x2, #3
    a5b8:	8b020060 	add	x0, x3, x2
    a5bc:	f9401017 	ldr	x23, [x0, #32]
    a5c0:	b4000257 	cbz	x23, a608 <f0+0x838>
    a5c4:	38626862 	ldrb	w2, [x3, x2]
    a5c8:	7100085f 	cmp	w2, #0x2
    a5cc:	5400dd00 	b.eq	c16c <f0+0x239c>  // b.none
    a5d0:	7100045f 	cmp	w2, #0x1
    a5d4:	540001a1 	b.ne	a608 <f0+0x838>  // b.any
    a5d8:	29430002 	ldp	w2, w0, [x0, #24]
    a5dc:	92403c21 	and	x1, x1, #0xffff
    a5e0:	9b027c21 	mul	x1, x1, x2
    a5e4:	d360fc21 	lsr	x1, x1, #32
    a5e8:	eb00003f 	cmp	x1, x0
    a5ec:	540000e2 	b.cs	a608 <f0+0x838>  // b.hs, b.nlast
    a5f0:	8b0102f7 	add	x23, x23, x1
    a5f4:	394002e0 	ldrb	w0, [x23]
    a5f8:	7103fc1f 	cmp	w0, #0xff
    a5fc:	5400e5a0 	b.eq	c2b0 <f0+0x24e0>  // b.none
    a600:	52800020 	mov	w0, #0x1                   	// #1
    a604:	390002e0 	strb	w0, [x23]
    a608:	9107e3e1 	add	x1, sp, #0x1f8
    a60c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a610:	52800020 	mov	w0, #0x1                   	// #1
    a614:	a91fd7f7 	stp	x23, x21, [sp, #504]
    a618:	97ffeb3a 	bl	5300 <fwp_data.part.0.constprop.0>
    a61c:	97ffeba6 	bl	54b4 <fwp_rc_fresh>
    a620:	aa0003e2 	mov	x2, x0
    a624:	910823e1 	add	x1, sp, #0x208
    a628:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a62c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a630:	52800020 	mov	w0, #0x1                   	// #1
    a634:	f90107f5 	str	x21, [sp, #520]
    a638:	f9010be2 	str	x2, [sp, #528]
    a63c:	97ffeb31 	bl	5300 <fwp_data.part.0.constprop.0>
    a640:	97ffeb9d 	bl	54b4 <fwp_rc_fresh>
    a644:	aa0003e2 	mov	x2, x0
    a648:	910863e1 	add	x1, sp, #0x218
    a64c:	52800020 	mov	w0, #0x1                   	// #1
    a650:	f9010ff7 	str	x23, [sp, #536]
    a654:	f90113e2 	str	x2, [sp, #544]
    a658:	97ffeb2a 	bl	5300 <fwp_data.part.0.constprop.0>
    a65c:	97ffeb96 	bl	54b4 <fwp_rc_fresh>
    a660:	aa0003e2 	mov	x2, x0
    a664:	9108a3e1 	add	x1, sp, #0x228
    a668:	52800020 	mov	w0, #0x1                   	// #1
    a66c:	f90117f5 	str	x21, [sp, #552]
    a670:	f9011be2 	str	x2, [sp, #560]
    a674:	97ffeb23 	bl	5300 <fwp_data.part.0.constprop.0>
    a678:	97ffeb8f 	bl	54b4 <fwp_rc_fresh>
    a67c:	aa0003e2 	mov	x2, x0
    a680:	9108e3e1 	add	x1, sp, #0x238
    a684:	52800020 	mov	w0, #0x1                   	// #1
    a688:	f9011ff7 	str	x23, [sp, #568]
    a68c:	f90123e2 	str	x2, [sp, #576]
    a690:	97ffeb1c 	bl	5300 <fwp_data.part.0.constprop.0>
    a694:	91154283 	add	x3, x20, #0x550
    a698:	aa0003f5 	mov	x21, x0
    a69c:	f949d861 	ldr	x1, [x3, #5040]
    a6a0:	f949ec60 	ldr	x0, [x3, #5080]
    a6a4:	cb0102a1 	sub	x1, x21, x1
    a6a8:	eb00403f 	cmp	x1, x0, lsl #16
    a6ac:	54000322 	b.cs	a710 <f0+0x940>  // b.hs, b.nlast
    a6b0:	d350fc22 	lsr	x2, x1, #16
    a6b4:	f949fc63 	ldr	x3, [x3, #5112]
    a6b8:	8b020842 	add	x2, x2, x2, lsl #2
    a6bc:	d37df042 	lsl	x2, x2, #3
    a6c0:	8b020060 	add	x0, x3, x2
    a6c4:	f9401017 	ldr	x23, [x0, #32]
    a6c8:	b4000257 	cbz	x23, a710 <f0+0x940>
    a6cc:	38626862 	ldrb	w2, [x3, x2]
    a6d0:	7100085f 	cmp	w2, #0x2
    a6d4:	5400d460 	b.eq	c160 <f0+0x2390>  // b.none
    a6d8:	7100045f 	cmp	w2, #0x1
    a6dc:	540001a1 	b.ne	a710 <f0+0x940>  // b.any
    a6e0:	29430002 	ldp	w2, w0, [x0, #24]
    a6e4:	92403c21 	and	x1, x1, #0xffff
    a6e8:	9b027c21 	mul	x1, x1, x2
    a6ec:	d360fc21 	lsr	x1, x1, #32
    a6f0:	eb00003f 	cmp	x1, x0
    a6f4:	540000e2 	b.cs	a710 <f0+0x940>  // b.hs, b.nlast
    a6f8:	8b0102f7 	add	x23, x23, x1
    a6fc:	394002e0 	ldrb	w0, [x23]
    a700:	7103fc1f 	cmp	w0, #0xff
    a704:	5400ddc0 	b.eq	c2bc <f0+0x24ec>  // b.none
    a708:	52800020 	mov	w0, #0x1                   	// #1
    a70c:	390002e0 	strb	w0, [x23]
    a710:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a714:	910923e1 	add	x1, sp, #0x248
    a718:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a71c:	52800020 	mov	w0, #0x1                   	// #1
    a720:	f90127e2 	str	x2, [sp, #584]
    a724:	f9012bf5 	str	x21, [sp, #592]
    a728:	97ffeaf6 	bl	5300 <fwp_data.part.0.constprop.0>
    a72c:	91154283 	add	x3, x20, #0x550
    a730:	aa0003f5 	mov	x21, x0
    a734:	f949d861 	ldr	x1, [x3, #5040]
    a738:	f949ec60 	ldr	x0, [x3, #5080]
    a73c:	cb0102a1 	sub	x1, x21, x1
    a740:	eb00403f 	cmp	x1, x0, lsl #16
    a744:	54000322 	b.cs	a7a8 <f0+0x9d8>  // b.hs, b.nlast
    a748:	d350fc22 	lsr	x2, x1, #16
    a74c:	f949fc63 	ldr	x3, [x3, #5112]
    a750:	8b020842 	add	x2, x2, x2, lsl #2
    a754:	d37df042 	lsl	x2, x2, #3
    a758:	8b020060 	add	x0, x3, x2
    a75c:	f9401017 	ldr	x23, [x0, #32]
    a760:	b4000257 	cbz	x23, a7a8 <f0+0x9d8>
    a764:	38626862 	ldrb	w2, [x3, x2]
    a768:	7100085f 	cmp	w2, #0x2
    a76c:	5400cf40 	b.eq	c154 <f0+0x2384>  // b.none
    a770:	7100045f 	cmp	w2, #0x1
    a774:	540001a1 	b.ne	a7a8 <f0+0x9d8>  // b.any
    a778:	29430002 	ldp	w2, w0, [x0, #24]
    a77c:	92403c21 	and	x1, x1, #0xffff
    a780:	9b027c21 	mul	x1, x1, x2
    a784:	d360fc21 	lsr	x1, x1, #32
    a788:	eb00003f 	cmp	x1, x0
    a78c:	540000e2 	b.cs	a7a8 <f0+0x9d8>  // b.hs, b.nlast
    a790:	8b0102f7 	add	x23, x23, x1
    a794:	394002e0 	ldrb	w0, [x23]
    a798:	7103fc1f 	cmp	w0, #0xff
    a79c:	5400d960 	b.eq	c2c8 <f0+0x24f8>  // b.none
    a7a0:	52800020 	mov	w0, #0x1                   	// #1
    a7a4:	390002e0 	strb	w0, [x23]
    a7a8:	910963e1 	add	x1, sp, #0x258
    a7ac:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a7b0:	52800020 	mov	w0, #0x1                   	// #1
    a7b4:	f9012fe2 	str	x2, [sp, #600]
    a7b8:	f90133f5 	str	x21, [sp, #608]
    a7bc:	97ffead1 	bl	5300 <fwp_data.part.0.constprop.0>
    a7c0:	97ffeb3d 	bl	54b4 <fwp_rc_fresh>
    a7c4:	aa0003e2 	mov	x2, x0
    a7c8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a7cc:	9109a3e1 	add	x1, sp, #0x268
    a7d0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a7d4:	52800020 	mov	w0, #0x1                   	// #1
    a7d8:	f90137e3 	str	x3, [sp, #616]
    a7dc:	f9013be2 	str	x2, [sp, #624]
    a7e0:	97ffeac8 	bl	5300 <fwp_data.part.0.constprop.0>
    a7e4:	91154283 	add	x3, x20, #0x550
    a7e8:	aa0003f5 	mov	x21, x0
    a7ec:	f949d861 	ldr	x1, [x3, #5040]
    a7f0:	f949ec60 	ldr	x0, [x3, #5080]
    a7f4:	cb0102a1 	sub	x1, x21, x1
    a7f8:	eb00403f 	cmp	x1, x0, lsl #16
    a7fc:	54000322 	b.cs	a860 <f0+0xa90>  // b.hs, b.nlast
    a800:	d350fc22 	lsr	x2, x1, #16
    a804:	f949fc63 	ldr	x3, [x3, #5112]
    a808:	8b020842 	add	x2, x2, x2, lsl #2
    a80c:	d37df042 	lsl	x2, x2, #3
    a810:	8b020060 	add	x0, x3, x2
    a814:	f9401017 	ldr	x23, [x0, #32]
    a818:	b4000257 	cbz	x23, a860 <f0+0xa90>
    a81c:	38626862 	ldrb	w2, [x3, x2]
    a820:	7100085f 	cmp	w2, #0x2
    a824:	5400c920 	b.eq	c148 <f0+0x2378>  // b.none
    a828:	7100045f 	cmp	w2, #0x1
    a82c:	540001a1 	b.ne	a860 <f0+0xa90>  // b.any
    a830:	29430002 	ldp	w2, w0, [x0, #24]
    a834:	92403c21 	and	x1, x1, #0xffff
    a838:	9b027c21 	mul	x1, x1, x2
    a83c:	d360fc21 	lsr	x1, x1, #32
    a840:	eb00003f 	cmp	x1, x0
    a844:	540000e2 	b.cs	a860 <f0+0xa90>  // b.hs, b.nlast
    a848:	8b0102f7 	add	x23, x23, x1
    a84c:	394002e0 	ldrb	w0, [x23]
    a850:	7103fc1f 	cmp	w0, #0xff
    a854:	5400d400 	b.eq	c2d4 <f0+0x2504>  // b.none
    a858:	52800020 	mov	w0, #0x1                   	// #1
    a85c:	390002e0 	strb	w0, [x23]
    a860:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a864:	9109e3e1 	add	x1, sp, #0x278
    a868:	52800020 	mov	w0, #0x1                   	// #1
    a86c:	f9013fe2 	str	x2, [sp, #632]
    a870:	f90143f5 	str	x21, [sp, #640]
    a874:	97ffeaa3 	bl	5300 <fwp_data.part.0.constprop.0>
    a878:	91154283 	add	x3, x20, #0x550
    a87c:	aa0003f5 	mov	x21, x0
    a880:	f949d861 	ldr	x1, [x3, #5040]
    a884:	f949ec60 	ldr	x0, [x3, #5080]
    a888:	cb0102a1 	sub	x1, x21, x1
    a88c:	eb00403f 	cmp	x1, x0, lsl #16
    a890:	54000322 	b.cs	a8f4 <f0+0xb24>  // b.hs, b.nlast
    a894:	d350fc22 	lsr	x2, x1, #16
    a898:	f949fc63 	ldr	x3, [x3, #5112]
    a89c:	8b020842 	add	x2, x2, x2, lsl #2
    a8a0:	d37df042 	lsl	x2, x2, #3
    a8a4:	8b020060 	add	x0, x3, x2
    a8a8:	f9401017 	ldr	x23, [x0, #32]
    a8ac:	b4000257 	cbz	x23, a8f4 <f0+0xb24>
    a8b0:	38626862 	ldrb	w2, [x3, x2]
    a8b4:	7100085f 	cmp	w2, #0x2
    a8b8:	5400c420 	b.eq	c13c <f0+0x236c>  // b.none
    a8bc:	7100045f 	cmp	w2, #0x1
    a8c0:	540001a1 	b.ne	a8f4 <f0+0xb24>  // b.any
    a8c4:	29430002 	ldp	w2, w0, [x0, #24]
    a8c8:	92403c21 	and	x1, x1, #0xffff
    a8cc:	9b027c21 	mul	x1, x1, x2
    a8d0:	d360fc21 	lsr	x1, x1, #32
    a8d4:	eb00003f 	cmp	x1, x0
    a8d8:	540000e2 	b.cs	a8f4 <f0+0xb24>  // b.hs, b.nlast
    a8dc:	8b0102f7 	add	x23, x23, x1
    a8e0:	394002e0 	ldrb	w0, [x23]
    a8e4:	7103fc1f 	cmp	w0, #0xff
    a8e8:	5400cfc0 	b.eq	c2e0 <f0+0x2510>  // b.none
    a8ec:	52800020 	mov	w0, #0x1                   	// #1
    a8f0:	390002e0 	strb	w0, [x23]
    a8f4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a8f8:	910a23e1 	add	x1, sp, #0x288
    a8fc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a900:	52800020 	mov	w0, #0x1                   	// #1
    a904:	f90147e2 	str	x2, [sp, #648]
    a908:	f9014bf5 	str	x21, [sp, #656]
    a90c:	97ffea7d 	bl	5300 <fwp_data.part.0.constprop.0>
    a910:	91154283 	add	x3, x20, #0x550
    a914:	aa0003f5 	mov	x21, x0
    a918:	f949d861 	ldr	x1, [x3, #5040]
    a91c:	f949ec60 	ldr	x0, [x3, #5080]
    a920:	cb0102a1 	sub	x1, x21, x1
    a924:	eb00403f 	cmp	x1, x0, lsl #16
    a928:	54000322 	b.cs	a98c <f0+0xbbc>  // b.hs, b.nlast
    a92c:	d350fc22 	lsr	x2, x1, #16
    a930:	f949fc63 	ldr	x3, [x3, #5112]
    a934:	8b020842 	add	x2, x2, x2, lsl #2
    a938:	d37df042 	lsl	x2, x2, #3
    a93c:	8b020060 	add	x0, x3, x2
    a940:	f9401017 	ldr	x23, [x0, #32]
    a944:	b4000257 	cbz	x23, a98c <f0+0xbbc>
    a948:	38626862 	ldrb	w2, [x3, x2]
    a94c:	7100085f 	cmp	w2, #0x2
    a950:	5400bf00 	b.eq	c130 <f0+0x2360>  // b.none
    a954:	7100045f 	cmp	w2, #0x1
    a958:	540001a1 	b.ne	a98c <f0+0xbbc>  // b.any
    a95c:	29430002 	ldp	w2, w0, [x0, #24]
    a960:	92403c21 	and	x1, x1, #0xffff
    a964:	9b027c21 	mul	x1, x1, x2
    a968:	d360fc21 	lsr	x1, x1, #32
    a96c:	eb00003f 	cmp	x1, x0
    a970:	540000e2 	b.cs	a98c <f0+0xbbc>  // b.hs, b.nlast
    a974:	8b0102f7 	add	x23, x23, x1
    a978:	394002e0 	ldrb	w0, [x23]
    a97c:	7103fc1f 	cmp	w0, #0xff
    a980:	5400cb60 	b.eq	c2ec <f0+0x251c>  // b.none
    a984:	52800020 	mov	w0, #0x1                   	// #1
    a988:	390002e0 	strb	w0, [x23]
    a98c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a990:	910a63e1 	add	x1, sp, #0x298
    a994:	52800020 	mov	w0, #0x1                   	// #1
    a998:	f9014fe2 	str	x2, [sp, #664]
    a99c:	f90153f5 	str	x21, [sp, #672]
    a9a0:	97ffea58 	bl	5300 <fwp_data.part.0.constprop.0>
    a9a4:	91154283 	add	x3, x20, #0x550
    a9a8:	aa0003f5 	mov	x21, x0
    a9ac:	f949d861 	ldr	x1, [x3, #5040]
    a9b0:	f949ec60 	ldr	x0, [x3, #5080]
    a9b4:	cb0102a1 	sub	x1, x21, x1
    a9b8:	eb00403f 	cmp	x1, x0, lsl #16
    a9bc:	54000322 	b.cs	aa20 <f0+0xc50>  // b.hs, b.nlast
    a9c0:	d350fc22 	lsr	x2, x1, #16
    a9c4:	f949fc63 	ldr	x3, [x3, #5112]
    a9c8:	8b020842 	add	x2, x2, x2, lsl #2
    a9cc:	d37df042 	lsl	x2, x2, #3
    a9d0:	8b020060 	add	x0, x3, x2
    a9d4:	f9401017 	ldr	x23, [x0, #32]
    a9d8:	b4000257 	cbz	x23, aa20 <f0+0xc50>
    a9dc:	38626862 	ldrb	w2, [x3, x2]
    a9e0:	7100085f 	cmp	w2, #0x2
    a9e4:	5400ba00 	b.eq	c124 <f0+0x2354>  // b.none
    a9e8:	7100045f 	cmp	w2, #0x1
    a9ec:	540001a1 	b.ne	aa20 <f0+0xc50>  // b.any
    a9f0:	29430002 	ldp	w2, w0, [x0, #24]
    a9f4:	92403c21 	and	x1, x1, #0xffff
    a9f8:	9b027c21 	mul	x1, x1, x2
    a9fc:	d360fc21 	lsr	x1, x1, #32
    aa00:	eb00003f 	cmp	x1, x0
    aa04:	540000e2 	b.cs	aa20 <f0+0xc50>  // b.hs, b.nlast
    aa08:	8b0102f7 	add	x23, x23, x1
    aa0c:	394002e0 	ldrb	w0, [x23]
    aa10:	7103fc1f 	cmp	w0, #0xff
    aa14:	5400c720 	b.eq	c2f8 <f0+0x2528>  // b.none
    aa18:	52800020 	mov	w0, #0x1                   	// #1
    aa1c:	390002e0 	strb	w0, [x23]
    aa20:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aa24:	910aa3e1 	add	x1, sp, #0x2a8
    aa28:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aa2c:	52800020 	mov	w0, #0x1                   	// #1
    aa30:	f90157e2 	str	x2, [sp, #680]
    aa34:	f9015bf5 	str	x21, [sp, #688]
    aa38:	97ffea32 	bl	5300 <fwp_data.part.0.constprop.0>
    aa3c:	97ffea9e 	bl	54b4 <fwp_rc_fresh>
    aa40:	aa0003e2 	mov	x2, x0
    aa44:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aa48:	910ae3e1 	add	x1, sp, #0x2b8
    aa4c:	52800020 	mov	w0, #0x1                   	// #1
    aa50:	f9015fe3 	str	x3, [sp, #696]
    aa54:	f90163e2 	str	x2, [sp, #704]
    aa58:	97ffea2a 	bl	5300 <fwp_data.part.0.constprop.0>
    aa5c:	91154283 	add	x3, x20, #0x550
    aa60:	aa0003f5 	mov	x21, x0
    aa64:	f949d861 	ldr	x1, [x3, #5040]
    aa68:	f949ec60 	ldr	x0, [x3, #5080]
    aa6c:	cb0102a1 	sub	x1, x21, x1
    aa70:	eb00403f 	cmp	x1, x0, lsl #16
    aa74:	54000322 	b.cs	aad8 <f0+0xd08>  // b.hs, b.nlast
    aa78:	d350fc22 	lsr	x2, x1, #16
    aa7c:	f949fc63 	ldr	x3, [x3, #5112]
    aa80:	8b020842 	add	x2, x2, x2, lsl #2
    aa84:	d37df042 	lsl	x2, x2, #3
    aa88:	8b020060 	add	x0, x3, x2
    aa8c:	f9401017 	ldr	x23, [x0, #32]
    aa90:	b4000257 	cbz	x23, aad8 <f0+0xd08>
    aa94:	38626862 	ldrb	w2, [x3, x2]
    aa98:	7100085f 	cmp	w2, #0x2
    aa9c:	5400b140 	b.eq	c0c4 <f0+0x22f4>  // b.none
    aaa0:	7100045f 	cmp	w2, #0x1
    aaa4:	540001a1 	b.ne	aad8 <f0+0xd08>  // b.any
    aaa8:	29430002 	ldp	w2, w0, [x0, #24]
    aaac:	92403c21 	and	x1, x1, #0xffff
    aab0:	9b027c21 	mul	x1, x1, x2
    aab4:	d360fc21 	lsr	x1, x1, #32
    aab8:	eb00003f 	cmp	x1, x0
    aabc:	540000e2 	b.cs	aad8 <f0+0xd08>  // b.hs, b.nlast
    aac0:	8b0102f7 	add	x23, x23, x1
    aac4:	394002e0 	ldrb	w0, [x23]
    aac8:	7103fc1f 	cmp	w0, #0xff
    aacc:	5400c1c0 	b.eq	c304 <f0+0x2534>  // b.none
    aad0:	52800020 	mov	w0, #0x1                   	// #1
    aad4:	390002e0 	strb	w0, [x23]
    aad8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aadc:	910b23e1 	add	x1, sp, #0x2c8
    aae0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aae4:	52800020 	mov	w0, #0x1                   	// #1
    aae8:	f90167e2 	str	x2, [sp, #712]
    aaec:	f9016bf5 	str	x21, [sp, #720]
    aaf0:	97ffea04 	bl	5300 <fwp_data.part.0.constprop.0>
    aaf4:	91154283 	add	x3, x20, #0x550
    aaf8:	aa0003f5 	mov	x21, x0
    aafc:	f949d861 	ldr	x1, [x3, #5040]
    ab00:	f949ec60 	ldr	x0, [x3, #5080]
    ab04:	cb0102a1 	sub	x1, x21, x1
    ab08:	eb00403f 	cmp	x1, x0, lsl #16
    ab0c:	54000322 	b.cs	ab70 <f0+0xda0>  // b.hs, b.nlast
    ab10:	d350fc22 	lsr	x2, x1, #16
    ab14:	f949fc63 	ldr	x3, [x3, #5112]
    ab18:	8b020842 	add	x2, x2, x2, lsl #2
    ab1c:	d37df042 	lsl	x2, x2, #3
    ab20:	8b020060 	add	x0, x3, x2
    ab24:	f9401017 	ldr	x23, [x0, #32]
    ab28:	b4000257 	cbz	x23, ab70 <f0+0xda0>
    ab2c:	38626862 	ldrb	w2, [x3, x2]
    ab30:	7100085f 	cmp	w2, #0x2
    ab34:	5400ac20 	b.eq	c0b8 <f0+0x22e8>  // b.none
    ab38:	7100045f 	cmp	w2, #0x1
    ab3c:	540001a1 	b.ne	ab70 <f0+0xda0>  // b.any
    ab40:	29430002 	ldp	w2, w0, [x0, #24]
    ab44:	92403c21 	and	x1, x1, #0xffff
    ab48:	9b027c21 	mul	x1, x1, x2
    ab4c:	d360fc21 	lsr	x1, x1, #32
    ab50:	eb00003f 	cmp	x1, x0
    ab54:	540000e2 	b.cs	ab70 <f0+0xda0>  // b.hs, b.nlast
    ab58:	8b0102f7 	add	x23, x23, x1
    ab5c:	394002e0 	ldrb	w0, [x23]
    ab60:	7103fc1f 	cmp	w0, #0xff
    ab64:	5400bd60 	b.eq	c310 <f0+0x2540>  // b.none
    ab68:	52800020 	mov	w0, #0x1                   	// #1
    ab6c:	390002e0 	strb	w0, [x23]
    ab70:	910b63e1 	add	x1, sp, #0x2d8
    ab74:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ab78:	52800020 	mov	w0, #0x1                   	// #1
    ab7c:	f9016ff7 	str	x23, [sp, #728]
    ab80:	f90173f5 	str	x21, [sp, #736]
    ab84:	97ffe9df 	bl	5300 <fwp_data.part.0.constprop.0>
    ab88:	97ffea4b 	bl	54b4 <fwp_rc_fresh>
    ab8c:	aa0003e2 	mov	x2, x0
    ab90:	910ba3e1 	add	x1, sp, #0x2e8
    ab94:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ab98:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ab9c:	52800020 	mov	w0, #0x1                   	// #1
    aba0:	f90177f5 	str	x21, [sp, #744]
    aba4:	f9017be2 	str	x2, [sp, #752]
    aba8:	97ffe9d6 	bl	5300 <fwp_data.part.0.constprop.0>
    abac:	97ffea42 	bl	54b4 <fwp_rc_fresh>
    abb0:	aa0003e2 	mov	x2, x0
    abb4:	910be3e1 	add	x1, sp, #0x2f8
    abb8:	52800020 	mov	w0, #0x1                   	// #1
    abbc:	f9017ff7 	str	x23, [sp, #760]
    abc0:	f90183e2 	str	x2, [sp, #768]
    abc4:	97ffe9cf 	bl	5300 <fwp_data.part.0.constprop.0>
    abc8:	97ffea3b 	bl	54b4 <fwp_rc_fresh>
    abcc:	aa0003e2 	mov	x2, x0
    abd0:	910c23e1 	add	x1, sp, #0x308
    abd4:	52800020 	mov	w0, #0x1                   	// #1
    abd8:	f90187f5 	str	x21, [sp, #776]
    abdc:	f9018be2 	str	x2, [sp, #784]
    abe0:	97ffe9c8 	bl	5300 <fwp_data.part.0.constprop.0>
    abe4:	97ffea34 	bl	54b4 <fwp_rc_fresh>
    abe8:	aa0003e2 	mov	x2, x0
    abec:	910c63e1 	add	x1, sp, #0x318
    abf0:	52800020 	mov	w0, #0x1                   	// #1
    abf4:	f9018ff7 	str	x23, [sp, #792]
    abf8:	f90193e2 	str	x2, [sp, #800]
    abfc:	97ffe9c1 	bl	5300 <fwp_data.part.0.constprop.0>
    ac00:	97ffea2d 	bl	54b4 <fwp_rc_fresh>
    ac04:	aa0003e2 	mov	x2, x0
    ac08:	910ca3e1 	add	x1, sp, #0x328
    ac0c:	52800020 	mov	w0, #0x1                   	// #1
    ac10:	f90197f5 	str	x21, [sp, #808]
    ac14:	f9019be2 	str	x2, [sp, #816]
    ac18:	97ffe9ba 	bl	5300 <fwp_data.part.0.constprop.0>
    ac1c:	97ffea26 	bl	54b4 <fwp_rc_fresh>
    ac20:	aa0003e2 	mov	x2, x0
    ac24:	910ce3e1 	add	x1, sp, #0x338
    ac28:	52800020 	mov	w0, #0x1                   	// #1
    ac2c:	f9019ff7 	str	x23, [sp, #824]
    ac30:	f901a3e2 	str	x2, [sp, #832]
    ac34:	97ffe9b3 	bl	5300 <fwp_data.part.0.constprop.0>
    ac38:	97ffea1f 	bl	54b4 <fwp_rc_fresh>
    ac3c:	aa0003e2 	mov	x2, x0
    ac40:	910d23e1 	add	x1, sp, #0x348
    ac44:	52800020 	mov	w0, #0x1                   	// #1
    ac48:	f901a7f5 	str	x21, [sp, #840]
    ac4c:	f901abe2 	str	x2, [sp, #848]
    ac50:	97ffe9ac 	bl	5300 <fwp_data.part.0.constprop.0>
    ac54:	97ffea18 	bl	54b4 <fwp_rc_fresh>
    ac58:	aa0003e2 	mov	x2, x0
    ac5c:	910d63e1 	add	x1, sp, #0x358
    ac60:	52800020 	mov	w0, #0x1                   	// #1
    ac64:	f901aff7 	str	x23, [sp, #856]
    ac68:	f901b3e2 	str	x2, [sp, #864]
    ac6c:	97ffe9a5 	bl	5300 <fwp_data.part.0.constprop.0>
    ac70:	97ffea11 	bl	54b4 <fwp_rc_fresh>
    ac74:	aa0003e2 	mov	x2, x0
    ac78:	910da3e1 	add	x1, sp, #0x368
    ac7c:	52800020 	mov	w0, #0x1                   	// #1
    ac80:	f901b7f5 	str	x21, [sp, #872]
    ac84:	f901bbe2 	str	x2, [sp, #880]
    ac88:	97ffe99e 	bl	5300 <fwp_data.part.0.constprop.0>
    ac8c:	97ffea0a 	bl	54b4 <fwp_rc_fresh>
    ac90:	aa0003e2 	mov	x2, x0
    ac94:	910de3e1 	add	x1, sp, #0x378
    ac98:	52800020 	mov	w0, #0x1                   	// #1
    ac9c:	f901bff7 	str	x23, [sp, #888]
    aca0:	f901c3e2 	str	x2, [sp, #896]
    aca4:	97ffe997 	bl	5300 <fwp_data.part.0.constprop.0>
    aca8:	97ffea03 	bl	54b4 <fwp_rc_fresh>
    acac:	aa0003e2 	mov	x2, x0
    acb0:	910e23e1 	add	x1, sp, #0x388
    acb4:	52800020 	mov	w0, #0x1                   	// #1
    acb8:	f901c7f5 	str	x21, [sp, #904]
    acbc:	f901cbe2 	str	x2, [sp, #912]
    acc0:	97ffe990 	bl	5300 <fwp_data.part.0.constprop.0>
    acc4:	91154283 	add	x3, x20, #0x550
    acc8:	aa0003f5 	mov	x21, x0
    accc:	f949d861 	ldr	x1, [x3, #5040]
    acd0:	f949ec60 	ldr	x0, [x3, #5080]
    acd4:	cb0102a1 	sub	x1, x21, x1
    acd8:	eb00403f 	cmp	x1, x0, lsl #16
    acdc:	54000322 	b.cs	ad40 <f0+0xf70>  // b.hs, b.nlast
    ace0:	d350fc22 	lsr	x2, x1, #16
    ace4:	f949fc63 	ldr	x3, [x3, #5112]
    ace8:	8b020842 	add	x2, x2, x2, lsl #2
    acec:	d37df042 	lsl	x2, x2, #3
    acf0:	8b020060 	add	x0, x3, x2
    acf4:	f9401017 	ldr	x23, [x0, #32]
    acf8:	b4000257 	cbz	x23, ad40 <f0+0xf70>
    acfc:	38626862 	ldrb	w2, [x3, x2]
    ad00:	7100085f 	cmp	w2, #0x2
    ad04:	54009d40 	b.eq	c0ac <f0+0x22dc>  // b.none
    ad08:	7100045f 	cmp	w2, #0x1
    ad0c:	540001a1 	b.ne	ad40 <f0+0xf70>  // b.any
    ad10:	29430002 	ldp	w2, w0, [x0, #24]
    ad14:	92403c21 	and	x1, x1, #0xffff
    ad18:	9b027c21 	mul	x1, x1, x2
    ad1c:	d360fc21 	lsr	x1, x1, #32
    ad20:	eb00003f 	cmp	x1, x0
    ad24:	540000e2 	b.cs	ad40 <f0+0xf70>  // b.hs, b.nlast
    ad28:	8b0102f7 	add	x23, x23, x1
    ad2c:	394002e0 	ldrb	w0, [x23]
    ad30:	7103fc1f 	cmp	w0, #0xff
    ad34:	5400af40 	b.eq	c31c <f0+0x254c>  // b.none
    ad38:	52800020 	mov	w0, #0x1                   	// #1
    ad3c:	390002e0 	strb	w0, [x23]
    ad40:	910e63e1 	add	x1, sp, #0x398
    ad44:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ad48:	52800020 	mov	w0, #0x1                   	// #1
    ad4c:	f901cff7 	str	x23, [sp, #920]
    ad50:	f901d3f5 	str	x21, [sp, #928]
    ad54:	97ffe96b 	bl	5300 <fwp_data.part.0.constprop.0>
    ad58:	97ffe9d7 	bl	54b4 <fwp_rc_fresh>
    ad5c:	aa0003e2 	mov	x2, x0
    ad60:	910ea3e1 	add	x1, sp, #0x3a8
    ad64:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ad68:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ad6c:	52800020 	mov	w0, #0x1                   	// #1
    ad70:	f901d7f5 	str	x21, [sp, #936]
    ad74:	f901dbe2 	str	x2, [sp, #944]
    ad78:	97ffe962 	bl	5300 <fwp_data.part.0.constprop.0>
    ad7c:	97ffe9ce 	bl	54b4 <fwp_rc_fresh>
    ad80:	aa0003e2 	mov	x2, x0
    ad84:	910ee3e1 	add	x1, sp, #0x3b8
    ad88:	52800020 	mov	w0, #0x1                   	// #1
    ad8c:	f901dff7 	str	x23, [sp, #952]
    ad90:	f901e3e2 	str	x2, [sp, #960]
    ad94:	97ffe95b 	bl	5300 <fwp_data.part.0.constprop.0>
    ad98:	97ffe9c7 	bl	54b4 <fwp_rc_fresh>
    ad9c:	aa0003e2 	mov	x2, x0
    ada0:	910f23e1 	add	x1, sp, #0x3c8
    ada4:	52800020 	mov	w0, #0x1                   	// #1
    ada8:	f901e7f5 	str	x21, [sp, #968]
    adac:	f901ebe2 	str	x2, [sp, #976]
    adb0:	97ffe954 	bl	5300 <fwp_data.part.0.constprop.0>
    adb4:	91154283 	add	x3, x20, #0x550
    adb8:	aa0003f5 	mov	x21, x0
    adbc:	f949d861 	ldr	x1, [x3, #5040]
    adc0:	f949ec60 	ldr	x0, [x3, #5080]
    adc4:	cb0102a1 	sub	x1, x21, x1
    adc8:	eb00403f 	cmp	x1, x0, lsl #16
    adcc:	54000322 	b.cs	ae30 <f0+0x1060>  // b.hs, b.nlast
    add0:	d350fc22 	lsr	x2, x1, #16
    add4:	f949fc63 	ldr	x3, [x3, #5112]
    add8:	8b020842 	add	x2, x2, x2, lsl #2
    addc:	d37df042 	lsl	x2, x2, #3
    ade0:	8b020060 	add	x0, x3, x2
    ade4:	f9401017 	ldr	x23, [x0, #32]
    ade8:	b4000257 	cbz	x23, ae30 <f0+0x1060>
    adec:	38626862 	ldrb	w2, [x3, x2]
    adf0:	7100085f 	cmp	w2, #0x2
    adf4:	54009560 	b.eq	c0a0 <f0+0x22d0>  // b.none
    adf8:	7100045f 	cmp	w2, #0x1
    adfc:	540001a1 	b.ne	ae30 <f0+0x1060>  // b.any
    ae00:	29430002 	ldp	w2, w0, [x0, #24]
    ae04:	92403c21 	and	x1, x1, #0xffff
    ae08:	9b027c21 	mul	x1, x1, x2
    ae0c:	d360fc21 	lsr	x1, x1, #32
    ae10:	eb00003f 	cmp	x1, x0
    ae14:	540000e2 	b.cs	ae30 <f0+0x1060>  // b.hs, b.nlast
    ae18:	8b0102f7 	add	x23, x23, x1
    ae1c:	394002e0 	ldrb	w0, [x23]
    ae20:	7103fc1f 	cmp	w0, #0xff
    ae24:	5400a820 	b.eq	c328 <f0+0x2558>  // b.none
    ae28:	52800020 	mov	w0, #0x1                   	// #1
    ae2c:	390002e0 	strb	w0, [x23]
    ae30:	910f63e1 	add	x1, sp, #0x3d8
    ae34:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ae38:	52800020 	mov	w0, #0x1                   	// #1
    ae3c:	f901eff7 	str	x23, [sp, #984]
    ae40:	f901f3f5 	str	x21, [sp, #992]
    ae44:	97ffe92f 	bl	5300 <fwp_data.part.0.constprop.0>
    ae48:	97ffe99b 	bl	54b4 <fwp_rc_fresh>
    ae4c:	aa0003e2 	mov	x2, x0
    ae50:	910fa3e1 	add	x1, sp, #0x3e8
    ae54:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ae58:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	f901f7f5 	str	x21, [sp, #1000]
    ae64:	f901fbe2 	str	x2, [sp, #1008]
    ae68:	97ffe926 	bl	5300 <fwp_data.part.0.constprop.0>
    ae6c:	97ffe992 	bl	54b4 <fwp_rc_fresh>
    ae70:	aa0003e2 	mov	x2, x0
    ae74:	910fe3e1 	add	x1, sp, #0x3f8
    ae78:	52800020 	mov	w0, #0x1                   	// #1
    ae7c:	f901fff7 	str	x23, [sp, #1016]
    ae80:	f90203e2 	str	x2, [sp, #1024]
    ae84:	97ffe91f 	bl	5300 <fwp_data.part.0.constprop.0>
    ae88:	97ffe98b 	bl	54b4 <fwp_rc_fresh>
    ae8c:	aa0003e2 	mov	x2, x0
    ae90:	911023e1 	add	x1, sp, #0x408
    ae94:	52800020 	mov	w0, #0x1                   	// #1
    ae98:	f90207f5 	str	x21, [sp, #1032]
    ae9c:	f9020be2 	str	x2, [sp, #1040]
    aea0:	97ffe918 	bl	5300 <fwp_data.part.0.constprop.0>
    aea4:	91154283 	add	x3, x20, #0x550
    aea8:	aa0003f5 	mov	x21, x0
    aeac:	f949d861 	ldr	x1, [x3, #5040]
    aeb0:	f949ec60 	ldr	x0, [x3, #5080]
    aeb4:	cb0102a1 	sub	x1, x21, x1
    aeb8:	eb00403f 	cmp	x1, x0, lsl #16
    aebc:	54000322 	b.cs	af20 <f0+0x1150>  // b.hs, b.nlast
    aec0:	d350fc22 	lsr	x2, x1, #16
    aec4:	f949fc63 	ldr	x3, [x3, #5112]
    aec8:	8b020842 	add	x2, x2, x2, lsl #2
    aecc:	d37df042 	lsl	x2, x2, #3
    aed0:	8b020060 	add	x0, x3, x2
    aed4:	f9401017 	ldr	x23, [x0, #32]
    aed8:	b4000257 	cbz	x23, af20 <f0+0x1150>
    aedc:	38626862 	ldrb	w2, [x3, x2]
    aee0:	7100085f 	cmp	w2, #0x2
    aee4:	54008d80 	b.eq	c094 <f0+0x22c4>  // b.none
    aee8:	7100045f 	cmp	w2, #0x1
    aeec:	540001a1 	b.ne	af20 <f0+0x1150>  // b.any
    aef0:	29430002 	ldp	w2, w0, [x0, #24]
    aef4:	92403c21 	and	x1, x1, #0xffff
    aef8:	9b027c21 	mul	x1, x1, x2
    aefc:	d360fc21 	lsr	x1, x1, #32
    af00:	eb00003f 	cmp	x1, x0
    af04:	540000e2 	b.cs	af20 <f0+0x1150>  // b.hs, b.nlast
    af08:	8b0102f7 	add	x23, x23, x1
    af0c:	394002e0 	ldrb	w0, [x23]
    af10:	7103fc1f 	cmp	w0, #0xff
    af14:	5400a100 	b.eq	c334 <f0+0x2564>  // b.none
    af18:	52800020 	mov	w0, #0x1                   	// #1
    af1c:	390002e0 	strb	w0, [x23]
    af20:	911063e1 	add	x1, sp, #0x418
    af24:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af28:	52800020 	mov	w0, #0x1                   	// #1
    af2c:	f9020ff7 	str	x23, [sp, #1048]
    af30:	f90213f5 	str	x21, [sp, #1056]
    af34:	97ffe8f3 	bl	5300 <fwp_data.part.0.constprop.0>
    af38:	97ffe95f 	bl	54b4 <fwp_rc_fresh>
    af3c:	aa0003e2 	mov	x2, x0
    af40:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    af44:	9110a3e1 	add	x1, sp, #0x428
    af48:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    af4c:	52800020 	mov	w0, #0x1                   	// #1
    af50:	f90217e3 	str	x3, [sp, #1064]
    af54:	f9021be2 	str	x2, [sp, #1072]
    af58:	97ffe8ea 	bl	5300 <fwp_data.part.0.constprop.0>
    af5c:	97ffe956 	bl	54b4 <fwp_rc_fresh>
    af60:	aa0003e2 	mov	x2, x0
    af64:	9110e3e1 	add	x1, sp, #0x438
    af68:	52800020 	mov	w0, #0x1                   	// #1
    af6c:	f9021ff7 	str	x23, [sp, #1080]
    af70:	f90223e2 	str	x2, [sp, #1088]
    af74:	97ffe8e3 	bl	5300 <fwp_data.part.0.constprop.0>
    af78:	91154283 	add	x3, x20, #0x550
    af7c:	aa0003f5 	mov	x21, x0
    af80:	f949d861 	ldr	x1, [x3, #5040]
    af84:	f949ec60 	ldr	x0, [x3, #5080]
    af88:	cb0102a1 	sub	x1, x21, x1
    af8c:	eb00403f 	cmp	x1, x0, lsl #16
    af90:	54000322 	b.cs	aff4 <f0+0x1224>  // b.hs, b.nlast
    af94:	d350fc22 	lsr	x2, x1, #16
    af98:	f949fc63 	ldr	x3, [x3, #5112]
    af9c:	8b020842 	add	x2, x2, x2, lsl #2
    afa0:	d37df042 	lsl	x2, x2, #3
    afa4:	8b020060 	add	x0, x3, x2
    afa8:	f9401017 	ldr	x23, [x0, #32]
    afac:	b4000257 	cbz	x23, aff4 <f0+0x1224>
    afb0:	38626862 	ldrb	w2, [x3, x2]
    afb4:	7100085f 	cmp	w2, #0x2
    afb8:	54008680 	b.eq	c088 <f0+0x22b8>  // b.none
    afbc:	7100045f 	cmp	w2, #0x1
    afc0:	540001a1 	b.ne	aff4 <f0+0x1224>  // b.any
    afc4:	29430002 	ldp	w2, w0, [x0, #24]
    afc8:	92403c21 	and	x1, x1, #0xffff
    afcc:	9b027c21 	mul	x1, x1, x2
    afd0:	d360fc21 	lsr	x1, x1, #32
    afd4:	eb00003f 	cmp	x1, x0
    afd8:	540000e2 	b.cs	aff4 <f0+0x1224>  // b.hs, b.nlast
    afdc:	8b0102f7 	add	x23, x23, x1
    afe0:	394002e0 	ldrb	w0, [x23]
    afe4:	7103fc1f 	cmp	w0, #0xff
    afe8:	54009ac0 	b.eq	c340 <f0+0x2570>  // b.none
    afec:	52800020 	mov	w0, #0x1                   	// #1
    aff0:	390002e0 	strb	w0, [x23]
    aff4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aff8:	911123e1 	add	x1, sp, #0x448
    affc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b000:	52800020 	mov	w0, #0x1                   	// #1
    b004:	f90227e2 	str	x2, [sp, #1096]
    b008:	f9022bf5 	str	x21, [sp, #1104]
    b00c:	97ffe8bd 	bl	5300 <fwp_data.part.0.constprop.0>
    b010:	91154283 	add	x3, x20, #0x550
    b014:	aa0003f5 	mov	x21, x0
    b018:	f949d861 	ldr	x1, [x3, #5040]
    b01c:	f949ec60 	ldr	x0, [x3, #5080]
    b020:	cb0102a1 	sub	x1, x21, x1
    b024:	eb00403f 	cmp	x1, x0, lsl #16
    b028:	54000322 	b.cs	b08c <f0+0x12bc>  // b.hs, b.nlast
    b02c:	d350fc22 	lsr	x2, x1, #16
    b030:	f949fc63 	ldr	x3, [x3, #5112]
    b034:	8b020842 	add	x2, x2, x2, lsl #2
    b038:	d37df042 	lsl	x2, x2, #3
    b03c:	8b020060 	add	x0, x3, x2
    b040:	f9401017 	ldr	x23, [x0, #32]
    b044:	b4000257 	cbz	x23, b08c <f0+0x12bc>
    b048:	38626862 	ldrb	w2, [x3, x2]
    b04c:	7100085f 	cmp	w2, #0x2
    b050:	54008160 	b.eq	c07c <f0+0x22ac>  // b.none
    b054:	7100045f 	cmp	w2, #0x1
    b058:	540001a1 	b.ne	b08c <f0+0x12bc>  // b.any
    b05c:	29430002 	ldp	w2, w0, [x0, #24]
    b060:	92403c21 	and	x1, x1, #0xffff
    b064:	9b027c21 	mul	x1, x1, x2
    b068:	d360fc21 	lsr	x1, x1, #32
    b06c:	eb00003f 	cmp	x1, x0
    b070:	540000e2 	b.cs	b08c <f0+0x12bc>  // b.hs, b.nlast
    b074:	8b0102f7 	add	x23, x23, x1
    b078:	394002e0 	ldrb	w0, [x23]
    b07c:	7103fc1f 	cmp	w0, #0xff
    b080:	54009660 	b.eq	c34c <f0+0x257c>  // b.none
    b084:	52800020 	mov	w0, #0x1                   	// #1
    b088:	390002e0 	strb	w0, [x23]
    b08c:	911163e1 	add	x1, sp, #0x458
    b090:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b094:	52800020 	mov	w0, #0x1                   	// #1
    b098:	f9022ff7 	str	x23, [sp, #1112]
    b09c:	f90233f5 	str	x21, [sp, #1120]
    b0a0:	97ffe898 	bl	5300 <fwp_data.part.0.constprop.0>
    b0a4:	97ffe904 	bl	54b4 <fwp_rc_fresh>
    b0a8:	aa0003e2 	mov	x2, x0
    b0ac:	9111a3e1 	add	x1, sp, #0x468
    b0b0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b0b4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b0b8:	52800020 	mov	w0, #0x1                   	// #1
    b0bc:	f90237f5 	str	x21, [sp, #1128]
    b0c0:	f9023be2 	str	x2, [sp, #1136]
    b0c4:	97ffe88f 	bl	5300 <fwp_data.part.0.constprop.0>
    b0c8:	97ffe8fb 	bl	54b4 <fwp_rc_fresh>
    b0cc:	aa0003e2 	mov	x2, x0
    b0d0:	9111e3e1 	add	x1, sp, #0x478
    b0d4:	52800020 	mov	w0, #0x1                   	// #1
    b0d8:	f9023ff7 	str	x23, [sp, #1144]
    b0dc:	f90243e2 	str	x2, [sp, #1152]
    b0e0:	97ffe888 	bl	5300 <fwp_data.part.0.constprop.0>
    b0e4:	97ffe8f4 	bl	54b4 <fwp_rc_fresh>
    b0e8:	aa0003e2 	mov	x2, x0
    b0ec:	911223e1 	add	x1, sp, #0x488
    b0f0:	52800020 	mov	w0, #0x1                   	// #1
    b0f4:	f90247f5 	str	x21, [sp, #1160]
    b0f8:	f9024be2 	str	x2, [sp, #1168]
    b0fc:	97ffe881 	bl	5300 <fwp_data.part.0.constprop.0>
    b100:	91154283 	add	x3, x20, #0x550
    b104:	aa0003f5 	mov	x21, x0
    b108:	f949d861 	ldr	x1, [x3, #5040]
    b10c:	f949ec60 	ldr	x0, [x3, #5080]
    b110:	cb0102a1 	sub	x1, x21, x1
    b114:	eb00403f 	cmp	x1, x0, lsl #16
    b118:	54000322 	b.cs	b17c <f0+0x13ac>  // b.hs, b.nlast
    b11c:	d350fc22 	lsr	x2, x1, #16
    b120:	f949fc63 	ldr	x3, [x3, #5112]
    b124:	8b020842 	add	x2, x2, x2, lsl #2
    b128:	d37df042 	lsl	x2, x2, #3
    b12c:	8b020060 	add	x0, x3, x2
    b130:	f9401017 	ldr	x23, [x0, #32]
    b134:	b4000257 	cbz	x23, b17c <f0+0x13ac>
    b138:	38626862 	ldrb	w2, [x3, x2]
    b13c:	7100085f 	cmp	w2, #0x2
    b140:	54007980 	b.eq	c070 <f0+0x22a0>  // b.none
    b144:	7100045f 	cmp	w2, #0x1
    b148:	540001a1 	b.ne	b17c <f0+0x13ac>  // b.any
    b14c:	29430002 	ldp	w2, w0, [x0, #24]
    b150:	92403c21 	and	x1, x1, #0xffff
    b154:	9b027c21 	mul	x1, x1, x2
    b158:	d360fc21 	lsr	x1, x1, #32
    b15c:	eb00003f 	cmp	x1, x0
    b160:	540000e2 	b.cs	b17c <f0+0x13ac>  // b.hs, b.nlast
    b164:	8b0102f7 	add	x23, x23, x1
    b168:	394002e0 	ldrb	w0, [x23]
    b16c:	7103fc1f 	cmp	w0, #0xff
    b170:	54008f40 	b.eq	c358 <f0+0x2588>  // b.none
    b174:	52800020 	mov	w0, #0x1                   	// #1
    b178:	390002e0 	strb	w0, [x23]
    b17c:	911263e1 	add	x1, sp, #0x498
    b180:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b184:	52800020 	mov	w0, #0x1                   	// #1
    b188:	f9024ff7 	str	x23, [sp, #1176]
    b18c:	f90253f5 	str	x21, [sp, #1184]
    b190:	97ffe85c 	bl	5300 <fwp_data.part.0.constprop.0>
    b194:	97ffe8c8 	bl	54b4 <fwp_rc_fresh>
    b198:	aa0003e2 	mov	x2, x0
    b19c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b1a0:	9112a3e1 	add	x1, sp, #0x4a8
    b1a4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b1a8:	52800020 	mov	w0, #0x1                   	// #1
    b1ac:	f90257e3 	str	x3, [sp, #1192]
    b1b0:	f9025be2 	str	x2, [sp, #1200]
    b1b4:	97ffe853 	bl	5300 <fwp_data.part.0.constprop.0>
    b1b8:	97ffe8bf 	bl	54b4 <fwp_rc_fresh>
    b1bc:	aa0003e2 	mov	x2, x0
    b1c0:	9112e3e1 	add	x1, sp, #0x4b8
    b1c4:	52800020 	mov	w0, #0x1                   	// #1
    b1c8:	f9025ff7 	str	x23, [sp, #1208]
    b1cc:	f90263e2 	str	x2, [sp, #1216]
    b1d0:	97ffe84c 	bl	5300 <fwp_data.part.0.constprop.0>
    b1d4:	91154283 	add	x3, x20, #0x550
    b1d8:	aa0003f5 	mov	x21, x0
    b1dc:	f949d861 	ldr	x1, [x3, #5040]
    b1e0:	f949ec60 	ldr	x0, [x3, #5080]
    b1e4:	cb0102a1 	sub	x1, x21, x1
    b1e8:	eb00403f 	cmp	x1, x0, lsl #16
    b1ec:	54000322 	b.cs	b250 <f0+0x1480>  // b.hs, b.nlast
    b1f0:	d350fc22 	lsr	x2, x1, #16
    b1f4:	f949fc63 	ldr	x3, [x3, #5112]
    b1f8:	8b020842 	add	x2, x2, x2, lsl #2
    b1fc:	d37df042 	lsl	x2, x2, #3
    b200:	8b020060 	add	x0, x3, x2
    b204:	f9401017 	ldr	x23, [x0, #32]
    b208:	b4000257 	cbz	x23, b250 <f0+0x1480>
    b20c:	38626862 	ldrb	w2, [x3, x2]
    b210:	7100085f 	cmp	w2, #0x2
    b214:	54008120 	b.eq	c238 <f0+0x2468>  // b.none
    b218:	7100045f 	cmp	w2, #0x1
    b21c:	540001a1 	b.ne	b250 <f0+0x1480>  // b.any
    b220:	29430002 	ldp	w2, w0, [x0, #24]
    b224:	92403c21 	and	x1, x1, #0xffff
    b228:	9b027c21 	mul	x1, x1, x2
    b22c:	d360fc21 	lsr	x1, x1, #32
    b230:	eb00003f 	cmp	x1, x0
    b234:	540000e2 	b.cs	b250 <f0+0x1480>  // b.hs, b.nlast
    b238:	8b0102f7 	add	x23, x23, x1
    b23c:	394002e0 	ldrb	w0, [x23]
    b240:	7103fc1f 	cmp	w0, #0xff
    b244:	54008900 	b.eq	c364 <f0+0x2594>  // b.none
    b248:	52800020 	mov	w0, #0x1                   	// #1
    b24c:	390002e0 	strb	w0, [x23]
    b250:	911323e1 	add	x1, sp, #0x4c8
    b254:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b258:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b25c:	52800020 	mov	w0, #0x1                   	// #1
    b260:	f90267f7 	str	x23, [sp, #1224]
    b264:	f9026bf5 	str	x21, [sp, #1232]
    b268:	97ffe826 	bl	5300 <fwp_data.part.0.constprop.0>
    b26c:	97ffe892 	bl	54b4 <fwp_rc_fresh>
    b270:	aa0003e2 	mov	x2, x0
    b274:	911363e1 	add	x1, sp, #0x4d8
    b278:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b27c:	52800020 	mov	w0, #0x1                   	// #1
    b280:	f9026ff5 	str	x21, [sp, #1240]
    b284:	f90273e2 	str	x2, [sp, #1248]
    b288:	97ffe81e 	bl	5300 <fwp_data.part.0.constprop.0>
    b28c:	97ffe88a 	bl	54b4 <fwp_rc_fresh>
    b290:	aa0003e2 	mov	x2, x0
    b294:	9113a3e1 	add	x1, sp, #0x4e8
    b298:	52800020 	mov	w0, #0x1                   	// #1
    b29c:	f90277f7 	str	x23, [sp, #1256]
    b2a0:	f9027be2 	str	x2, [sp, #1264]
    b2a4:	97ffe817 	bl	5300 <fwp_data.part.0.constprop.0>
    b2a8:	97ffe883 	bl	54b4 <fwp_rc_fresh>
    b2ac:	aa0003e2 	mov	x2, x0
    b2b0:	9113e3e1 	add	x1, sp, #0x4f8
    b2b4:	52800020 	mov	w0, #0x1                   	// #1
    b2b8:	f9027ff5 	str	x21, [sp, #1272]
    b2bc:	f90283e2 	str	x2, [sp, #1280]
    b2c0:	97ffe810 	bl	5300 <fwp_data.part.0.constprop.0>
    b2c4:	97ffe87c 	bl	54b4 <fwp_rc_fresh>
    b2c8:	aa0003e2 	mov	x2, x0
    b2cc:	911423e1 	add	x1, sp, #0x508
    b2d0:	52800020 	mov	w0, #0x1                   	// #1
    b2d4:	f90287f7 	str	x23, [sp, #1288]
    b2d8:	f9028be2 	str	x2, [sp, #1296]
    b2dc:	97ffe809 	bl	5300 <fwp_data.part.0.constprop.0>
    b2e0:	91154283 	add	x3, x20, #0x550
    b2e4:	aa0003f5 	mov	x21, x0
    b2e8:	f949d861 	ldr	x1, [x3, #5040]
    b2ec:	f949ec60 	ldr	x0, [x3, #5080]
    b2f0:	cb0102a1 	sub	x1, x21, x1
    b2f4:	eb00403f 	cmp	x1, x0, lsl #16
    b2f8:	54000322 	b.cs	b35c <f0+0x158c>  // b.hs, b.nlast
    b2fc:	d350fc22 	lsr	x2, x1, #16
    b300:	f949fc63 	ldr	x3, [x3, #5112]
    b304:	8b020842 	add	x2, x2, x2, lsl #2
    b308:	d37df042 	lsl	x2, x2, #3
    b30c:	8b020060 	add	x0, x3, x2
    b310:	f9401017 	ldr	x23, [x0, #32]
    b314:	b4000257 	cbz	x23, b35c <f0+0x158c>
    b318:	38626862 	ldrb	w2, [x3, x2]
    b31c:	7100085f 	cmp	w2, #0x2
    b320:	54007860 	b.eq	c22c <f0+0x245c>  // b.none
    b324:	7100045f 	cmp	w2, #0x1
    b328:	540001a1 	b.ne	b35c <f0+0x158c>  // b.any
    b32c:	29430002 	ldp	w2, w0, [x0, #24]
    b330:	92403c21 	and	x1, x1, #0xffff
    b334:	9b027c21 	mul	x1, x1, x2
    b338:	d360fc21 	lsr	x1, x1, #32
    b33c:	eb00003f 	cmp	x1, x0
    b340:	540000e2 	b.cs	b35c <f0+0x158c>  // b.hs, b.nlast
    b344:	8b0102f7 	add	x23, x23, x1
    b348:	394002e0 	ldrb	w0, [x23]
    b34c:	7103fc1f 	cmp	w0, #0xff
    b350:	54008100 	b.eq	c370 <f0+0x25a0>  // b.none
    b354:	52800020 	mov	w0, #0x1                   	// #1
    b358:	390002e0 	strb	w0, [x23]
    b35c:	911463e1 	add	x1, sp, #0x518
    b360:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b364:	52800020 	mov	w0, #0x1                   	// #1
    b368:	f9028ff7 	str	x23, [sp, #1304]
    b36c:	f90293f5 	str	x21, [sp, #1312]
    b370:	97ffe7e4 	bl	5300 <fwp_data.part.0.constprop.0>
    b374:	97ffe850 	bl	54b4 <fwp_rc_fresh>
    b378:	aa0003e2 	mov	x2, x0
    b37c:	9114a3e1 	add	x1, sp, #0x528
    b380:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b384:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b388:	52800020 	mov	w0, #0x1                   	// #1
    b38c:	f90297f5 	str	x21, [sp, #1320]
    b390:	f9029be2 	str	x2, [sp, #1328]
    b394:	97ffe7db 	bl	5300 <fwp_data.part.0.constprop.0>
    b398:	97ffe847 	bl	54b4 <fwp_rc_fresh>
    b39c:	aa0003e2 	mov	x2, x0
    b3a0:	9114e3e1 	add	x1, sp, #0x538
    b3a4:	52800020 	mov	w0, #0x1                   	// #1
    b3a8:	f9029ff7 	str	x23, [sp, #1336]
    b3ac:	f902a3e2 	str	x2, [sp, #1344]
    b3b0:	97ffe7d4 	bl	5300 <fwp_data.part.0.constprop.0>
    b3b4:	97ffe840 	bl	54b4 <fwp_rc_fresh>
    b3b8:	aa0003e2 	mov	x2, x0
    b3bc:	911523e1 	add	x1, sp, #0x548
    b3c0:	52800020 	mov	w0, #0x1                   	// #1
    b3c4:	f902a7f5 	str	x21, [sp, #1352]
    b3c8:	f902abe2 	str	x2, [sp, #1360]
    b3cc:	97ffe7cd 	bl	5300 <fwp_data.part.0.constprop.0>
    b3d0:	91154283 	add	x3, x20, #0x550
    b3d4:	aa0003f5 	mov	x21, x0
    b3d8:	f949d861 	ldr	x1, [x3, #5040]
    b3dc:	f949ec60 	ldr	x0, [x3, #5080]
    b3e0:	cb0102a1 	sub	x1, x21, x1
    b3e4:	eb00403f 	cmp	x1, x0, lsl #16
    b3e8:	54000322 	b.cs	b44c <f0+0x167c>  // b.hs, b.nlast
    b3ec:	d350fc22 	lsr	x2, x1, #16
    b3f0:	f949fc63 	ldr	x3, [x3, #5112]
    b3f4:	8b020842 	add	x2, x2, x2, lsl #2
    b3f8:	d37df042 	lsl	x2, x2, #3
    b3fc:	8b020060 	add	x0, x3, x2
    b400:	f9401017 	ldr	x23, [x0, #32]
    b404:	b4000257 	cbz	x23, b44c <f0+0x167c>
    b408:	38626862 	ldrb	w2, [x3, x2]
    b40c:	7100085f 	cmp	w2, #0x2
    b410:	54007080 	b.eq	c220 <f0+0x2450>  // b.none
    b414:	7100045f 	cmp	w2, #0x1
    b418:	540001a1 	b.ne	b44c <f0+0x167c>  // b.any
    b41c:	29430002 	ldp	w2, w0, [x0, #24]
    b420:	92403c21 	and	x1, x1, #0xffff
    b424:	9b027c21 	mul	x1, x1, x2
    b428:	d360fc21 	lsr	x1, x1, #32
    b42c:	eb00003f 	cmp	x1, x0
    b430:	540000e2 	b.cs	b44c <f0+0x167c>  // b.hs, b.nlast
    b434:	8b0102f7 	add	x23, x23, x1
    b438:	394002e0 	ldrb	w0, [x23]
    b43c:	7103fc1f 	cmp	w0, #0xff
    b440:	540079e0 	b.eq	c37c <f0+0x25ac>  // b.none
    b444:	52800020 	mov	w0, #0x1                   	// #1
    b448:	390002e0 	strb	w0, [x23]
    b44c:	911563e1 	add	x1, sp, #0x558
    b450:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b454:	52800020 	mov	w0, #0x1                   	// #1
    b458:	f902aff7 	str	x23, [sp, #1368]
    b45c:	f902b3f5 	str	x21, [sp, #1376]
    b460:	97ffe7a8 	bl	5300 <fwp_data.part.0.constprop.0>
    b464:	97ffe814 	bl	54b4 <fwp_rc_fresh>
    b468:	aa0003e2 	mov	x2, x0
    b46c:	9115a3e1 	add	x1, sp, #0x568
    b470:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b474:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b478:	52800020 	mov	w0, #0x1                   	// #1
    b47c:	f902b7f5 	str	x21, [sp, #1384]
    b480:	f902bbe2 	str	x2, [sp, #1392]
    b484:	97ffe79f 	bl	5300 <fwp_data.part.0.constprop.0>
    b488:	97ffe80b 	bl	54b4 <fwp_rc_fresh>
    b48c:	aa0003e2 	mov	x2, x0
    b490:	9115e3e1 	add	x1, sp, #0x578
    b494:	52800020 	mov	w0, #0x1                   	// #1
    b498:	f902bff7 	str	x23, [sp, #1400]
    b49c:	f902c3e2 	str	x2, [sp, #1408]
    b4a0:	97ffe798 	bl	5300 <fwp_data.part.0.constprop.0>
    b4a4:	97ffe804 	bl	54b4 <fwp_rc_fresh>
    b4a8:	aa0003e2 	mov	x2, x0
    b4ac:	911623e1 	add	x1, sp, #0x588
    b4b0:	52800020 	mov	w0, #0x1                   	// #1
    b4b4:	f902c7f5 	str	x21, [sp, #1416]
    b4b8:	f902cbe2 	str	x2, [sp, #1424]
    b4bc:	97ffe791 	bl	5300 <fwp_data.part.0.constprop.0>
    b4c0:	91154283 	add	x3, x20, #0x550
    b4c4:	aa0003f5 	mov	x21, x0
    b4c8:	f949d861 	ldr	x1, [x3, #5040]
    b4cc:	f949ec60 	ldr	x0, [x3, #5080]
    b4d0:	cb0102a1 	sub	x1, x21, x1
    b4d4:	eb00403f 	cmp	x1, x0, lsl #16
    b4d8:	54000322 	b.cs	b53c <f0+0x176c>  // b.hs, b.nlast
    b4dc:	d350fc22 	lsr	x2, x1, #16
    b4e0:	f949fc63 	ldr	x3, [x3, #5112]
    b4e4:	8b020842 	add	x2, x2, x2, lsl #2
    b4e8:	d37df042 	lsl	x2, x2, #3
    b4ec:	8b020060 	add	x0, x3, x2
    b4f0:	f9401017 	ldr	x23, [x0, #32]
    b4f4:	b4000257 	cbz	x23, b53c <f0+0x176c>
    b4f8:	38626862 	ldrb	w2, [x3, x2]
    b4fc:	7100085f 	cmp	w2, #0x2
    b500:	540068a0 	b.eq	c214 <f0+0x2444>  // b.none
    b504:	7100045f 	cmp	w2, #0x1
    b508:	540001a1 	b.ne	b53c <f0+0x176c>  // b.any
    b50c:	29430002 	ldp	w2, w0, [x0, #24]
    b510:	92403c21 	and	x1, x1, #0xffff
    b514:	9b027c21 	mul	x1, x1, x2
    b518:	d360fc21 	lsr	x1, x1, #32
    b51c:	eb00003f 	cmp	x1, x0
    b520:	540000e2 	b.cs	b53c <f0+0x176c>  // b.hs, b.nlast
    b524:	8b0102f7 	add	x23, x23, x1
    b528:	394002e0 	ldrb	w0, [x23]
    b52c:	7103fc1f 	cmp	w0, #0xff
    b530:	540072c0 	b.eq	c388 <f0+0x25b8>  // b.none
    b534:	52800020 	mov	w0, #0x1                   	// #1
    b538:	390002e0 	strb	w0, [x23]
    b53c:	911663e1 	add	x1, sp, #0x598
    b540:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b544:	52800020 	mov	w0, #0x1                   	// #1
    b548:	f902cff7 	str	x23, [sp, #1432]
    b54c:	f902d3f5 	str	x21, [sp, #1440]
    b550:	97ffe76c 	bl	5300 <fwp_data.part.0.constprop.0>
    b554:	97ffe7d8 	bl	54b4 <fwp_rc_fresh>
    b558:	aa0003e2 	mov	x2, x0
    b55c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b560:	9116a3e1 	add	x1, sp, #0x5a8
    b564:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b568:	52800020 	mov	w0, #0x1                   	// #1
    b56c:	f902d7e3 	str	x3, [sp, #1448]
    b570:	f902dbe2 	str	x2, [sp, #1456]
    b574:	97ffe763 	bl	5300 <fwp_data.part.0.constprop.0>
    b578:	97ffe7cf 	bl	54b4 <fwp_rc_fresh>
    b57c:	aa0003e2 	mov	x2, x0
    b580:	9116e3e1 	add	x1, sp, #0x5b8
    b584:	52800020 	mov	w0, #0x1                   	// #1
    b588:	f902dff7 	str	x23, [sp, #1464]
    b58c:	f902e3e2 	str	x2, [sp, #1472]
    b590:	97ffe75c 	bl	5300 <fwp_data.part.0.constprop.0>
    b594:	91154283 	add	x3, x20, #0x550
    b598:	aa0003f5 	mov	x21, x0
    b59c:	f949d861 	ldr	x1, [x3, #5040]
    b5a0:	f949ec60 	ldr	x0, [x3, #5080]
    b5a4:	cb0102a1 	sub	x1, x21, x1
    b5a8:	eb00403f 	cmp	x1, x0, lsl #16
    b5ac:	54000322 	b.cs	b610 <f0+0x1840>  // b.hs, b.nlast
    b5b0:	d350fc22 	lsr	x2, x1, #16
    b5b4:	f949fc63 	ldr	x3, [x3, #5112]
    b5b8:	8b020842 	add	x2, x2, x2, lsl #2
    b5bc:	d37df042 	lsl	x2, x2, #3
    b5c0:	8b020060 	add	x0, x3, x2
    b5c4:	f9401017 	ldr	x23, [x0, #32]
    b5c8:	b4000257 	cbz	x23, b610 <f0+0x1840>
    b5cc:	38626862 	ldrb	w2, [x3, x2]
    b5d0:	7100085f 	cmp	w2, #0x2
    b5d4:	540061a0 	b.eq	c208 <f0+0x2438>  // b.none
    b5d8:	7100045f 	cmp	w2, #0x1
    b5dc:	540001a1 	b.ne	b610 <f0+0x1840>  // b.any
    b5e0:	29430002 	ldp	w2, w0, [x0, #24]
    b5e4:	92403c21 	and	x1, x1, #0xffff
    b5e8:	9b027c21 	mul	x1, x1, x2
    b5ec:	d360fc21 	lsr	x1, x1, #32
    b5f0:	eb00003f 	cmp	x1, x0
    b5f4:	540000e2 	b.cs	b610 <f0+0x1840>  // b.hs, b.nlast
    b5f8:	8b0102f7 	add	x23, x23, x1
    b5fc:	394002e0 	ldrb	w0, [x23]
    b600:	7103fc1f 	cmp	w0, #0xff
    b604:	54006c80 	b.eq	c394 <f0+0x25c4>  // b.none
    b608:	52800020 	mov	w0, #0x1                   	// #1
    b60c:	390002e0 	strb	w0, [x23]
    b610:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b614:	911723e1 	add	x1, sp, #0x5c8
    b618:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b61c:	52800020 	mov	w0, #0x1                   	// #1
    b620:	f902e7e2 	str	x2, [sp, #1480]
    b624:	f902ebf5 	str	x21, [sp, #1488]
    b628:	97ffe736 	bl	5300 <fwp_data.part.0.constprop.0>
    b62c:	91154283 	add	x3, x20, #0x550
    b630:	aa0003f5 	mov	x21, x0
    b634:	f949d861 	ldr	x1, [x3, #5040]
    b638:	f949ec60 	ldr	x0, [x3, #5080]
    b63c:	cb0102a1 	sub	x1, x21, x1
    b640:	eb00403f 	cmp	x1, x0, lsl #16
    b644:	54000322 	b.cs	b6a8 <f0+0x18d8>  // b.hs, b.nlast
    b648:	d350fc22 	lsr	x2, x1, #16
    b64c:	f949fc63 	ldr	x3, [x3, #5112]
    b650:	8b020842 	add	x2, x2, x2, lsl #2
    b654:	d37df042 	lsl	x2, x2, #3
    b658:	8b020060 	add	x0, x3, x2
    b65c:	f9401017 	ldr	x23, [x0, #32]
    b660:	b4000257 	cbz	x23, b6a8 <f0+0x18d8>
    b664:	38626862 	ldrb	w2, [x3, x2]
    b668:	7100085f 	cmp	w2, #0x2
    b66c:	54005c80 	b.eq	c1fc <f0+0x242c>  // b.none
    b670:	7100045f 	cmp	w2, #0x1
    b674:	540001a1 	b.ne	b6a8 <f0+0x18d8>  // b.any
    b678:	29430002 	ldp	w2, w0, [x0, #24]
    b67c:	92403c21 	and	x1, x1, #0xffff
    b680:	9b027c21 	mul	x1, x1, x2
    b684:	d360fc21 	lsr	x1, x1, #32
    b688:	eb00003f 	cmp	x1, x0
    b68c:	540000e2 	b.cs	b6a8 <f0+0x18d8>  // b.hs, b.nlast
    b690:	8b0102f7 	add	x23, x23, x1
    b694:	394002e0 	ldrb	w0, [x23]
    b698:	7103fc1f 	cmp	w0, #0xff
    b69c:	54006820 	b.eq	c3a0 <f0+0x25d0>  // b.none
    b6a0:	52800020 	mov	w0, #0x1                   	// #1
    b6a4:	390002e0 	strb	w0, [x23]
    b6a8:	911763e1 	add	x1, sp, #0x5d8
    b6ac:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b6b0:	52800020 	mov	w0, #0x1                   	// #1
    b6b4:	f902eff7 	str	x23, [sp, #1496]
    b6b8:	f902f3f5 	str	x21, [sp, #1504]
    b6bc:	97ffe711 	bl	5300 <fwp_data.part.0.constprop.0>
    b6c0:	97ffe77d 	bl	54b4 <fwp_rc_fresh>
    b6c4:	aa0003e2 	mov	x2, x0
    b6c8:	9117a3e1 	add	x1, sp, #0x5e8
    b6cc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b6d0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b6d4:	52800020 	mov	w0, #0x1                   	// #1
    b6d8:	f902f7f5 	str	x21, [sp, #1512]
    b6dc:	f902fbe2 	str	x2, [sp, #1520]
    b6e0:	97ffe708 	bl	5300 <fwp_data.part.0.constprop.0>
    b6e4:	97ffe774 	bl	54b4 <fwp_rc_fresh>
    b6e8:	aa0003e2 	mov	x2, x0
    b6ec:	9117e3e1 	add	x1, sp, #0x5f8
    b6f0:	52800020 	mov	w0, #0x1                   	// #1
    b6f4:	f902fff7 	str	x23, [sp, #1528]
    b6f8:	f90303e2 	str	x2, [sp, #1536]
    b6fc:	97ffe701 	bl	5300 <fwp_data.part.0.constprop.0>
    b700:	97ffe76d 	bl	54b4 <fwp_rc_fresh>
    b704:	aa0003e2 	mov	x2, x0
    b708:	911823e1 	add	x1, sp, #0x608
    b70c:	52800020 	mov	w0, #0x1                   	// #1
    b710:	f90307f5 	str	x21, [sp, #1544]
    b714:	f9030be2 	str	x2, [sp, #1552]
    b718:	97ffe6fa 	bl	5300 <fwp_data.part.0.constprop.0>
    b71c:	97ffe766 	bl	54b4 <fwp_rc_fresh>
    b720:	aa0003e2 	mov	x2, x0
    b724:	911863e1 	add	x1, sp, #0x618
    b728:	52800020 	mov	w0, #0x1                   	// #1
    b72c:	f9030ff7 	str	x23, [sp, #1560]
    b730:	f90313e2 	str	x2, [sp, #1568]
    b734:	97ffe6f3 	bl	5300 <fwp_data.part.0.constprop.0>
    b738:	97ffe75f 	bl	54b4 <fwp_rc_fresh>
    b73c:	aa0003e2 	mov	x2, x0
    b740:	9118a3e1 	add	x1, sp, #0x628
    b744:	52800020 	mov	w0, #0x1                   	// #1
    b748:	f90317f5 	str	x21, [sp, #1576]
    b74c:	f9031be2 	str	x2, [sp, #1584]
    b750:	97ffe6ec 	bl	5300 <fwp_data.part.0.constprop.0>
    b754:	97ffe758 	bl	54b4 <fwp_rc_fresh>
    b758:	aa0003e2 	mov	x2, x0
    b75c:	9118e3e1 	add	x1, sp, #0x638
    b760:	52800020 	mov	w0, #0x1                   	// #1
    b764:	f9031ff7 	str	x23, [sp, #1592]
    b768:	f90323e2 	str	x2, [sp, #1600]
    b76c:	97ffe6e5 	bl	5300 <fwp_data.part.0.constprop.0>
    b770:	97ffe751 	bl	54b4 <fwp_rc_fresh>
    b774:	aa0003e2 	mov	x2, x0
    b778:	911923e1 	add	x1, sp, #0x648
    b77c:	52800020 	mov	w0, #0x1                   	// #1
    b780:	f90327f5 	str	x21, [sp, #1608]
    b784:	f9032be2 	str	x2, [sp, #1616]
    b788:	97ffe6de 	bl	5300 <fwp_data.part.0.constprop.0>
    b78c:	91154283 	add	x3, x20, #0x550
    b790:	aa0003f5 	mov	x21, x0
    b794:	f949d861 	ldr	x1, [x3, #5040]
    b798:	f949ec60 	ldr	x0, [x3, #5080]
    b79c:	cb0102a1 	sub	x1, x21, x1
    b7a0:	eb00403f 	cmp	x1, x0, lsl #16
    b7a4:	54000322 	b.cs	b808 <f0+0x1a38>  // b.hs, b.nlast
    b7a8:	d350fc22 	lsr	x2, x1, #16
    b7ac:	f949fc63 	ldr	x3, [x3, #5112]
    b7b0:	8b020842 	add	x2, x2, x2, lsl #2
    b7b4:	d37df042 	lsl	x2, x2, #3
    b7b8:	8b020060 	add	x0, x3, x2
    b7bc:	f9401017 	ldr	x23, [x0, #32]
    b7c0:	b4000257 	cbz	x23, b808 <f0+0x1a38>
    b7c4:	38626862 	ldrb	w2, [x3, x2]
    b7c8:	7100085f 	cmp	w2, #0x2
    b7cc:	54005120 	b.eq	c1f0 <f0+0x2420>  // b.none
    b7d0:	7100045f 	cmp	w2, #0x1
    b7d4:	540001a1 	b.ne	b808 <f0+0x1a38>  // b.any
    b7d8:	29430002 	ldp	w2, w0, [x0, #24]
    b7dc:	92403c21 	and	x1, x1, #0xffff
    b7e0:	9b027c21 	mul	x1, x1, x2
    b7e4:	d360fc21 	lsr	x1, x1, #32
    b7e8:	eb00003f 	cmp	x1, x0
    b7ec:	540000e2 	b.cs	b808 <f0+0x1a38>  // b.hs, b.nlast
    b7f0:	8b0102f7 	add	x23, x23, x1
    b7f4:	394002e0 	ldrb	w0, [x23]
    b7f8:	7103fc1f 	cmp	w0, #0xff
    b7fc:	54005d80 	b.eq	c3ac <f0+0x25dc>  // b.none
    b800:	52800020 	mov	w0, #0x1                   	// #1
    b804:	390002e0 	strb	w0, [x23]
    b808:	911963e1 	add	x1, sp, #0x658
    b80c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b810:	52800020 	mov	w0, #0x1                   	// #1
    b814:	f9032fe2 	str	x2, [sp, #1624]
    b818:	f90333f5 	str	x21, [sp, #1632]
    b81c:	97ffe6b9 	bl	5300 <fwp_data.part.0.constprop.0>
    b820:	97ffe725 	bl	54b4 <fwp_rc_fresh>
    b824:	aa0003e2 	mov	x2, x0
    b828:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b82c:	9119a3e1 	add	x1, sp, #0x668
    b830:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b834:	52800020 	mov	w0, #0x1                   	// #1
    b838:	f90337e3 	str	x3, [sp, #1640]
    b83c:	f9033be2 	str	x2, [sp, #1648]
    b840:	97ffe6b0 	bl	5300 <fwp_data.part.0.constprop.0>
    b844:	91154283 	add	x3, x20, #0x550
    b848:	aa0003f5 	mov	x21, x0
    b84c:	f949d861 	ldr	x1, [x3, #5040]
    b850:	f949ec60 	ldr	x0, [x3, #5080]
    b854:	cb0102a1 	sub	x1, x21, x1
    b858:	eb00403f 	cmp	x1, x0, lsl #16
    b85c:	54000322 	b.cs	b8c0 <f0+0x1af0>  // b.hs, b.nlast
    b860:	d350fc22 	lsr	x2, x1, #16
    b864:	f949fc63 	ldr	x3, [x3, #5112]
    b868:	8b020842 	add	x2, x2, x2, lsl #2
    b86c:	d37df042 	lsl	x2, x2, #3
    b870:	8b020060 	add	x0, x3, x2
    b874:	f9401017 	ldr	x23, [x0, #32]
    b878:	b4000257 	cbz	x23, b8c0 <f0+0x1af0>
    b87c:	38626862 	ldrb	w2, [x3, x2]
    b880:	7100085f 	cmp	w2, #0x2
    b884:	54004b00 	b.eq	c1e4 <f0+0x2414>  // b.none
    b888:	7100045f 	cmp	w2, #0x1
    b88c:	540001a1 	b.ne	b8c0 <f0+0x1af0>  // b.any
    b890:	29430002 	ldp	w2, w0, [x0, #24]
    b894:	92403c21 	and	x1, x1, #0xffff
    b898:	9b027c21 	mul	x1, x1, x2
    b89c:	d360fc21 	lsr	x1, x1, #32
    b8a0:	eb00003f 	cmp	x1, x0
    b8a4:	540000e2 	b.cs	b8c0 <f0+0x1af0>  // b.hs, b.nlast
    b8a8:	8b0102f7 	add	x23, x23, x1
    b8ac:	394002e0 	ldrb	w0, [x23]
    b8b0:	7103fc1f 	cmp	w0, #0xff
    b8b4:	54005820 	b.eq	c3b8 <f0+0x25e8>  // b.none
    b8b8:	52800020 	mov	w0, #0x1                   	// #1
    b8bc:	390002e0 	strb	w0, [x23]
    b8c0:	9119e3e1 	add	x1, sp, #0x678
    b8c4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b8c8:	52800020 	mov	w0, #0x1                   	// #1
    b8cc:	f9033fe2 	str	x2, [sp, #1656]
    b8d0:	f90343f5 	str	x21, [sp, #1664]
    b8d4:	97ffe68b 	bl	5300 <fwp_data.part.0.constprop.0>
    b8d8:	97ffe6f7 	bl	54b4 <fwp_rc_fresh>
    b8dc:	aa0003e2 	mov	x2, x0
    b8e0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b8e4:	911a23e1 	add	x1, sp, #0x688
    b8e8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b8ec:	52800020 	mov	w0, #0x1                   	// #1
    b8f0:	f90347e3 	str	x3, [sp, #1672]
    b8f4:	f9034be2 	str	x2, [sp, #1680]
    b8f8:	97ffe682 	bl	5300 <fwp_data.part.0.constprop.0>
    b8fc:	91154283 	add	x3, x20, #0x550
    b900:	aa0003f5 	mov	x21, x0
    b904:	f949d861 	ldr	x1, [x3, #5040]
    b908:	f949ec60 	ldr	x0, [x3, #5080]
    b90c:	cb0102a1 	sub	x1, x21, x1
    b910:	eb00403f 	cmp	x1, x0, lsl #16
    b914:	54000322 	b.cs	b978 <f0+0x1ba8>  // b.hs, b.nlast
    b918:	d350fc22 	lsr	x2, x1, #16
    b91c:	f949fc63 	ldr	x3, [x3, #5112]
    b920:	8b020842 	add	x2, x2, x2, lsl #2
    b924:	d37df042 	lsl	x2, x2, #3
    b928:	8b020060 	add	x0, x3, x2
    b92c:	f9401017 	ldr	x23, [x0, #32]
    b930:	b4000257 	cbz	x23, b978 <f0+0x1ba8>
    b934:	38626862 	ldrb	w2, [x3, x2]
    b938:	7100085f 	cmp	w2, #0x2
    b93c:	540044e0 	b.eq	c1d8 <f0+0x2408>  // b.none
    b940:	7100045f 	cmp	w2, #0x1
    b944:	540001a1 	b.ne	b978 <f0+0x1ba8>  // b.any
    b948:	29430002 	ldp	w2, w0, [x0, #24]
    b94c:	92403c21 	and	x1, x1, #0xffff
    b950:	9b027c21 	mul	x1, x1, x2
    b954:	d360fc21 	lsr	x1, x1, #32
    b958:	eb00003f 	cmp	x1, x0
    b95c:	540000e2 	b.cs	b978 <f0+0x1ba8>  // b.hs, b.nlast
    b960:	8b0102f7 	add	x23, x23, x1
    b964:	394002e0 	ldrb	w0, [x23]
    b968:	7103fc1f 	cmp	w0, #0xff
    b96c:	540052c0 	b.eq	c3c4 <f0+0x25f4>  // b.none
    b970:	52800020 	mov	w0, #0x1                   	// #1
    b974:	390002e0 	strb	w0, [x23]
    b978:	911a63e1 	add	x1, sp, #0x698
    b97c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b980:	52800020 	mov	w0, #0x1                   	// #1
    b984:	f9034fe2 	str	x2, [sp, #1688]
    b988:	f90353f5 	str	x21, [sp, #1696]
    b98c:	97ffe65d 	bl	5300 <fwp_data.part.0.constprop.0>
    b990:	97ffe6c9 	bl	54b4 <fwp_rc_fresh>
    b994:	aa0003e2 	mov	x2, x0
    b998:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b99c:	911aa3e1 	add	x1, sp, #0x6a8
    b9a0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b9a4:	52800020 	mov	w0, #0x1                   	// #1
    b9a8:	f90357e3 	str	x3, [sp, #1704]
    b9ac:	f9035be2 	str	x2, [sp, #1712]
    b9b0:	97ffe654 	bl	5300 <fwp_data.part.0.constprop.0>
    b9b4:	91154283 	add	x3, x20, #0x550
    b9b8:	aa0003f5 	mov	x21, x0
    b9bc:	f949d861 	ldr	x1, [x3, #5040]
    b9c0:	f949ec60 	ldr	x0, [x3, #5080]
    b9c4:	cb0102a1 	sub	x1, x21, x1
    b9c8:	eb00403f 	cmp	x1, x0, lsl #16
    b9cc:	54000322 	b.cs	ba30 <f0+0x1c60>  // b.hs, b.nlast
    b9d0:	d350fc22 	lsr	x2, x1, #16
    b9d4:	f949fc63 	ldr	x3, [x3, #5112]
    b9d8:	8b020842 	add	x2, x2, x2, lsl #2
    b9dc:	d37df042 	lsl	x2, x2, #3
    b9e0:	8b020060 	add	x0, x3, x2
    b9e4:	f9401017 	ldr	x23, [x0, #32]
    b9e8:	b4000257 	cbz	x23, ba30 <f0+0x1c60>
    b9ec:	38626862 	ldrb	w2, [x3, x2]
    b9f0:	7100085f 	cmp	w2, #0x2
    b9f4:	54003ec0 	b.eq	c1cc <f0+0x23fc>  // b.none
    b9f8:	7100045f 	cmp	w2, #0x1
    b9fc:	540001a1 	b.ne	ba30 <f0+0x1c60>  // b.any
    ba00:	29430002 	ldp	w2, w0, [x0, #24]
    ba04:	92403c21 	and	x1, x1, #0xffff
    ba08:	9b027c21 	mul	x1, x1, x2
    ba0c:	d360fc21 	lsr	x1, x1, #32
    ba10:	eb00003f 	cmp	x1, x0
    ba14:	540000e2 	b.cs	ba30 <f0+0x1c60>  // b.hs, b.nlast
    ba18:	8b0102f7 	add	x23, x23, x1
    ba1c:	394002e0 	ldrb	w0, [x23]
    ba20:	7103fc1f 	cmp	w0, #0xff
    ba24:	54004d60 	b.eq	c3d0 <f0+0x2600>  // b.none
    ba28:	52800020 	mov	w0, #0x1                   	// #1
    ba2c:	390002e0 	strb	w0, [x23]
    ba30:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba34:	911ae3e1 	add	x1, sp, #0x6b8
    ba38:	52800020 	mov	w0, #0x1                   	// #1
    ba3c:	f9035fe2 	str	x2, [sp, #1720]
    ba40:	f90363f5 	str	x21, [sp, #1728]
    ba44:	97ffe62f 	bl	5300 <fwp_data.part.0.constprop.0>
    ba48:	91154283 	add	x3, x20, #0x550
    ba4c:	aa0003f5 	mov	x21, x0
    ba50:	f949d861 	ldr	x1, [x3, #5040]
    ba54:	f949ec60 	ldr	x0, [x3, #5080]
    ba58:	cb0102a1 	sub	x1, x21, x1
    ba5c:	eb00403f 	cmp	x1, x0, lsl #16
    ba60:	54000322 	b.cs	bac4 <f0+0x1cf4>  // b.hs, b.nlast
    ba64:	d350fc22 	lsr	x2, x1, #16
    ba68:	f949fc63 	ldr	x3, [x3, #5112]
    ba6c:	8b020842 	add	x2, x2, x2, lsl #2
    ba70:	d37df042 	lsl	x2, x2, #3
    ba74:	8b020060 	add	x0, x3, x2
    ba78:	f9401017 	ldr	x23, [x0, #32]
    ba7c:	b4000257 	cbz	x23, bac4 <f0+0x1cf4>
    ba80:	38626862 	ldrb	w2, [x3, x2]
    ba84:	7100085f 	cmp	w2, #0x2
    ba88:	540039c0 	b.eq	c1c0 <f0+0x23f0>  // b.none
    ba8c:	7100045f 	cmp	w2, #0x1
    ba90:	540001a1 	b.ne	bac4 <f0+0x1cf4>  // b.any
    ba94:	29430002 	ldp	w2, w0, [x0, #24]
    ba98:	92403c21 	and	x1, x1, #0xffff
    ba9c:	9b027c21 	mul	x1, x1, x2
    baa0:	d360fc21 	lsr	x1, x1, #32
    baa4:	eb00003f 	cmp	x1, x0
    baa8:	540000e2 	b.cs	bac4 <f0+0x1cf4>  // b.hs, b.nlast
    baac:	8b0102f7 	add	x23, x23, x1
    bab0:	394002e0 	ldrb	w0, [x23]
    bab4:	7103fc1f 	cmp	w0, #0xff
    bab8:	54004920 	b.eq	c3dc <f0+0x260c>  // b.none
    babc:	52800020 	mov	w0, #0x1                   	// #1
    bac0:	390002e0 	strb	w0, [x23]
    bac4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bac8:	911b23e1 	add	x1, sp, #0x6c8
    bacc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bad0:	52800020 	mov	w0, #0x1                   	// #1
    bad4:	f90367e2 	str	x2, [sp, #1736]
    bad8:	f9036bf5 	str	x21, [sp, #1744]
    badc:	97ffe609 	bl	5300 <fwp_data.part.0.constprop.0>
    bae0:	91154283 	add	x3, x20, #0x550
    bae4:	aa0003f5 	mov	x21, x0
    bae8:	f949d861 	ldr	x1, [x3, #5040]
    baec:	f949ec60 	ldr	x0, [x3, #5080]
    baf0:	cb0102a1 	sub	x1, x21, x1
    baf4:	eb00403f 	cmp	x1, x0, lsl #16
    baf8:	54000322 	b.cs	bb5c <f0+0x1d8c>  // b.hs, b.nlast
    bafc:	d350fc22 	lsr	x2, x1, #16
    bb00:	f949fc63 	ldr	x3, [x3, #5112]
    bb04:	8b020842 	add	x2, x2, x2, lsl #2
    bb08:	d37df042 	lsl	x2, x2, #3
    bb0c:	8b020060 	add	x0, x3, x2
    bb10:	f9401017 	ldr	x23, [x0, #32]
    bb14:	b4000257 	cbz	x23, bb5c <f0+0x1d8c>
    bb18:	38626862 	ldrb	w2, [x3, x2]
    bb1c:	7100085f 	cmp	w2, #0x2
    bb20:	540034a0 	b.eq	c1b4 <f0+0x23e4>  // b.none
    bb24:	7100045f 	cmp	w2, #0x1
    bb28:	540001a1 	b.ne	bb5c <f0+0x1d8c>  // b.any
    bb2c:	29430002 	ldp	w2, w0, [x0, #24]
    bb30:	92403c21 	and	x1, x1, #0xffff
    bb34:	9b027c21 	mul	x1, x1, x2
    bb38:	d360fc21 	lsr	x1, x1, #32
    bb3c:	eb00003f 	cmp	x1, x0
    bb40:	540000e2 	b.cs	bb5c <f0+0x1d8c>  // b.hs, b.nlast
    bb44:	8b0102f7 	add	x23, x23, x1
    bb48:	394002e0 	ldrb	w0, [x23]
    bb4c:	7103fc1f 	cmp	w0, #0xff
    bb50:	540044c0 	b.eq	c3e8 <f0+0x2618>  // b.none
    bb54:	52800020 	mov	w0, #0x1                   	// #1
    bb58:	390002e0 	strb	w0, [x23]
    bb5c:	911b63e1 	add	x1, sp, #0x6d8
    bb60:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bb64:	52800020 	mov	w0, #0x1                   	// #1
    bb68:	f9036ff7 	str	x23, [sp, #1752]
    bb6c:	f90373f5 	str	x21, [sp, #1760]
    bb70:	97ffe5e4 	bl	5300 <fwp_data.part.0.constprop.0>
    bb74:	97ffe650 	bl	54b4 <fwp_rc_fresh>
    bb78:	aa0003e2 	mov	x2, x0
    bb7c:	911ba3e1 	add	x1, sp, #0x6e8
    bb80:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bb84:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bb88:	52800020 	mov	w0, #0x1                   	// #1
    bb8c:	f90377f5 	str	x21, [sp, #1768]
    bb90:	f9037be2 	str	x2, [sp, #1776]
    bb94:	97ffe5db 	bl	5300 <fwp_data.part.0.constprop.0>
    bb98:	97ffe647 	bl	54b4 <fwp_rc_fresh>
    bb9c:	aa0003e2 	mov	x2, x0
    bba0:	911be3e1 	add	x1, sp, #0x6f8
    bba4:	52800020 	mov	w0, #0x1                   	// #1
    bba8:	f9037ff7 	str	x23, [sp, #1784]
    bbac:	f90383e2 	str	x2, [sp, #1792]
    bbb0:	97ffe5d4 	bl	5300 <fwp_data.part.0.constprop.0>
    bbb4:	97ffe640 	bl	54b4 <fwp_rc_fresh>
    bbb8:	aa0003e2 	mov	x2, x0
    bbbc:	911c23e1 	add	x1, sp, #0x708
    bbc0:	52800020 	mov	w0, #0x1                   	// #1
    bbc4:	f90387f5 	str	x21, [sp, #1800]
    bbc8:	f9038be2 	str	x2, [sp, #1808]
    bbcc:	97ffe5cd 	bl	5300 <fwp_data.part.0.constprop.0>
    bbd0:	91154283 	add	x3, x20, #0x550
    bbd4:	aa0003f5 	mov	x21, x0
    bbd8:	f949d861 	ldr	x1, [x3, #5040]
    bbdc:	f949ec60 	ldr	x0, [x3, #5080]
    bbe0:	cb0102a1 	sub	x1, x21, x1
    bbe4:	eb00403f 	cmp	x1, x0, lsl #16
    bbe8:	54000322 	b.cs	bc4c <f0+0x1e7c>  // b.hs, b.nlast
    bbec:	d350fc22 	lsr	x2, x1, #16
    bbf0:	f949fc63 	ldr	x3, [x3, #5112]
    bbf4:	8b020842 	add	x2, x2, x2, lsl #2
    bbf8:	d37df042 	lsl	x2, x2, #3
    bbfc:	8b020060 	add	x0, x3, x2
    bc00:	f9401017 	ldr	x23, [x0, #32]
    bc04:	b4000257 	cbz	x23, bc4c <f0+0x1e7c>
    bc08:	38626862 	ldrb	w2, [x3, x2]
    bc0c:	7100085f 	cmp	w2, #0x2
    bc10:	54002cc0 	b.eq	c1a8 <f0+0x23d8>  // b.none
    bc14:	7100045f 	cmp	w2, #0x1
    bc18:	540001a1 	b.ne	bc4c <f0+0x1e7c>  // b.any
    bc1c:	29430002 	ldp	w2, w0, [x0, #24]
    bc20:	92403c21 	and	x1, x1, #0xffff
    bc24:	9b027c21 	mul	x1, x1, x2
    bc28:	d360fc21 	lsr	x1, x1, #32
    bc2c:	eb00003f 	cmp	x1, x0
    bc30:	540000e2 	b.cs	bc4c <f0+0x1e7c>  // b.hs, b.nlast
    bc34:	8b0102f7 	add	x23, x23, x1
    bc38:	394002e0 	ldrb	w0, [x23]
    bc3c:	7103fc1f 	cmp	w0, #0xff
    bc40:	54003da0 	b.eq	c3f4 <f0+0x2624>  // b.none
    bc44:	52800020 	mov	w0, #0x1                   	// #1
    bc48:	390002e0 	strb	w0, [x23]
    bc4c:	911c63e1 	add	x1, sp, #0x718
    bc50:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bc54:	52800020 	mov	w0, #0x1                   	// #1
    bc58:	f9038ff7 	str	x23, [sp, #1816]
    bc5c:	f90393f5 	str	x21, [sp, #1824]
    bc60:	97ffe5a8 	bl	5300 <fwp_data.part.0.constprop.0>
    bc64:	97ffe614 	bl	54b4 <fwp_rc_fresh>
    bc68:	aa0003e2 	mov	x2, x0
    bc6c:	911ca3e1 	add	x1, sp, #0x728
    bc70:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bc74:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bc78:	52800020 	mov	w0, #0x1                   	// #1
    bc7c:	f90397f5 	str	x21, [sp, #1832]
    bc80:	f9039be2 	str	x2, [sp, #1840]
    bc84:	97ffe59f 	bl	5300 <fwp_data.part.0.constprop.0>
    bc88:	97ffe60b 	bl	54b4 <fwp_rc_fresh>
    bc8c:	aa0003e2 	mov	x2, x0
    bc90:	911ce3e1 	add	x1, sp, #0x738
    bc94:	52800020 	mov	w0, #0x1                   	// #1
    bc98:	f9039ff7 	str	x23, [sp, #1848]
    bc9c:	f903a3e2 	str	x2, [sp, #1856]
    bca0:	97ffe598 	bl	5300 <fwp_data.part.0.constprop.0>
    bca4:	97ffe604 	bl	54b4 <fwp_rc_fresh>
    bca8:	aa0003e2 	mov	x2, x0
    bcac:	911d23e1 	add	x1, sp, #0x748
    bcb0:	52800020 	mov	w0, #0x1                   	// #1
    bcb4:	f903a7f5 	str	x21, [sp, #1864]
    bcb8:	f903abe2 	str	x2, [sp, #1872]
    bcbc:	97ffe591 	bl	5300 <fwp_data.part.0.constprop.0>
    bcc0:	97ffe5fd 	bl	54b4 <fwp_rc_fresh>
    bcc4:	aa0003e2 	mov	x2, x0
    bcc8:	911d63e1 	add	x1, sp, #0x758
    bccc:	52800020 	mov	w0, #0x1                   	// #1
    bcd0:	f903aff7 	str	x23, [sp, #1880]
    bcd4:	f903b3e2 	str	x2, [sp, #1888]
    bcd8:	97ffe58a 	bl	5300 <fwp_data.part.0.constprop.0>
    bcdc:	97ffe5f6 	bl	54b4 <fwp_rc_fresh>
    bce0:	aa0003e2 	mov	x2, x0
    bce4:	911da3e1 	add	x1, sp, #0x768
    bce8:	52800020 	mov	w0, #0x1                   	// #1
    bcec:	f903b7f5 	str	x21, [sp, #1896]
    bcf0:	f903bbe2 	str	x2, [sp, #1904]
    bcf4:	97ffe583 	bl	5300 <fwp_data.part.0.constprop.0>
    bcf8:	97ffe5ef 	bl	54b4 <fwp_rc_fresh>
    bcfc:	aa0003e2 	mov	x2, x0
    bd00:	911de3e1 	add	x1, sp, #0x778
    bd04:	52800020 	mov	w0, #0x1                   	// #1
    bd08:	f903bff7 	str	x23, [sp, #1912]
    bd0c:	f903c3e2 	str	x2, [sp, #1920]
    bd10:	97ffe57c 	bl	5300 <fwp_data.part.0.constprop.0>
    bd14:	97ffe5e8 	bl	54b4 <fwp_rc_fresh>
    bd18:	aa0003e2 	mov	x2, x0
    bd1c:	911e23e1 	add	x1, sp, #0x788
    bd20:	52800020 	mov	w0, #0x1                   	// #1
    bd24:	f903c7f5 	str	x21, [sp, #1928]
    bd28:	f903cbe2 	str	x2, [sp, #1936]
    bd2c:	97ffe575 	bl	5300 <fwp_data.part.0.constprop.0>
    bd30:	97ffe5e1 	bl	54b4 <fwp_rc_fresh>
    bd34:	aa0003e2 	mov	x2, x0
    bd38:	911e63e1 	add	x1, sp, #0x798
    bd3c:	52800020 	mov	w0, #0x1                   	// #1
    bd40:	f903cff7 	str	x23, [sp, #1944]
    bd44:	f903d3e2 	str	x2, [sp, #1952]
    bd48:	97ffe56e 	bl	5300 <fwp_data.part.0.constprop.0>
    bd4c:	97ffe5da 	bl	54b4 <fwp_rc_fresh>
    bd50:	aa0003e2 	mov	x2, x0
    bd54:	911ea3e1 	add	x1, sp, #0x7a8
    bd58:	52800020 	mov	w0, #0x1                   	// #1
    bd5c:	f903d7f5 	str	x21, [sp, #1960]
    bd60:	f903dbe2 	str	x2, [sp, #1968]
    bd64:	97ffe567 	bl	5300 <fwp_data.part.0.constprop.0>
    bd68:	91154283 	add	x3, x20, #0x550
    bd6c:	aa0003f5 	mov	x21, x0
    bd70:	f949d861 	ldr	x1, [x3, #5040]
    bd74:	f949ec60 	ldr	x0, [x3, #5080]
    bd78:	cb0102a1 	sub	x1, x21, x1
    bd7c:	eb00403f 	cmp	x1, x0, lsl #16
    bd80:	54000322 	b.cs	bde4 <f0+0x2014>  // b.hs, b.nlast
    bd84:	d350fc22 	lsr	x2, x1, #16
    bd88:	f949fc63 	ldr	x3, [x3, #5112]
    bd8c:	8b020842 	add	x2, x2, x2, lsl #2
    bd90:	d37df042 	lsl	x2, x2, #3
    bd94:	8b020060 	add	x0, x3, x2
    bd98:	f9401017 	ldr	x23, [x0, #32]
    bd9c:	b4000257 	cbz	x23, bde4 <f0+0x2014>
    bda0:	38626862 	ldrb	w2, [x3, x2]
    bda4:	7100085f 	cmp	w2, #0x2
    bda8:	54001fa0 	b.eq	c19c <f0+0x23cc>  // b.none
    bdac:	7100045f 	cmp	w2, #0x1
    bdb0:	540001a1 	b.ne	bde4 <f0+0x2014>  // b.any
    bdb4:	29430002 	ldp	w2, w0, [x0, #24]
    bdb8:	92403c21 	and	x1, x1, #0xffff
    bdbc:	9b027c21 	mul	x1, x1, x2
    bdc0:	d360fc21 	lsr	x1, x1, #32
    bdc4:	eb00003f 	cmp	x1, x0
    bdc8:	540000e2 	b.cs	bde4 <f0+0x2014>  // b.hs, b.nlast
    bdcc:	8b0102f7 	add	x23, x23, x1
    bdd0:	394002e0 	ldrb	w0, [x23]
    bdd4:	7103fc1f 	cmp	w0, #0xff
    bdd8:	54003140 	b.eq	c400 <f0+0x2630>  // b.none
    bddc:	52800020 	mov	w0, #0x1                   	// #1
    bde0:	390002e0 	strb	w0, [x23]
    bde4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bde8:	911ee3e1 	add	x1, sp, #0x7b8
    bdec:	52800020 	mov	w0, #0x1                   	// #1
    bdf0:	f903dfe2 	str	x2, [sp, #1976]
    bdf4:	f903e3f5 	str	x21, [sp, #1984]
    bdf8:	97ffe542 	bl	5300 <fwp_data.part.0.constprop.0>
    bdfc:	91154283 	add	x3, x20, #0x550
    be00:	aa0003f5 	mov	x21, x0
    be04:	f949d861 	ldr	x1, [x3, #5040]
    be08:	f949ec60 	ldr	x0, [x3, #5080]
    be0c:	cb0102a1 	sub	x1, x21, x1
    be10:	eb00403f 	cmp	x1, x0, lsl #16
    be14:	54000322 	b.cs	be78 <f0+0x20a8>  // b.hs, b.nlast
    be18:	d350fc22 	lsr	x2, x1, #16
    be1c:	f949fc63 	ldr	x3, [x3, #5112]
    be20:	8b020842 	add	x2, x2, x2, lsl #2
    be24:	d37df042 	lsl	x2, x2, #3
    be28:	8b020060 	add	x0, x3, x2
    be2c:	f9401017 	ldr	x23, [x0, #32]
    be30:	b4000257 	cbz	x23, be78 <f0+0x20a8>
    be34:	38626862 	ldrb	w2, [x3, x2]
    be38:	7100085f 	cmp	w2, #0x2
    be3c:	54001aa0 	b.eq	c190 <f0+0x23c0>  // b.none
    be40:	7100045f 	cmp	w2, #0x1
    be44:	540001a1 	b.ne	be78 <f0+0x20a8>  // b.any
    be48:	29430002 	ldp	w2, w0, [x0, #24]
    be4c:	92403c21 	and	x1, x1, #0xffff
    be50:	9b027c21 	mul	x1, x1, x2
    be54:	d360fc21 	lsr	x1, x1, #32
    be58:	eb00003f 	cmp	x1, x0
    be5c:	540000e2 	b.cs	be78 <f0+0x20a8>  // b.hs, b.nlast
    be60:	8b0102f7 	add	x23, x23, x1
    be64:	394002e0 	ldrb	w0, [x23]
    be68:	7103fc1f 	cmp	w0, #0xff
    be6c:	54002d00 	b.eq	c40c <f0+0x263c>  // b.none
    be70:	52800020 	mov	w0, #0x1                   	// #1
    be74:	390002e0 	strb	w0, [x23]
    be78:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be7c:	91154294 	add	x20, x20, #0x550
    be80:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be84:	911f23e1 	add	x1, sp, #0x7c8
    be88:	52800020 	mov	w0, #0x1                   	// #1
    be8c:	f903e7e2 	str	x2, [sp, #1992]
    be90:	f903ebf5 	str	x21, [sp, #2000]
    be94:	97ffe51b 	bl	5300 <fwp_data.part.0.constprop.0>
    be98:	f949da81 	ldr	x1, [x20, #5040]
    be9c:	aa0003f7 	mov	x23, x0
    bea0:	f949ee80 	ldr	x0, [x20, #5080]
    bea4:	cb0102e1 	sub	x1, x23, x1
    bea8:	eb00403f 	cmp	x1, x0, lsl #16
    beac:	54000322 	b.cs	bf10 <f0+0x2140>  // b.hs, b.nlast
    beb0:	d350fc22 	lsr	x2, x1, #16
    beb4:	f949fe83 	ldr	x3, [x20, #5112]
    beb8:	8b020842 	add	x2, x2, x2, lsl #2
    bebc:	d37df042 	lsl	x2, x2, #3
    bec0:	8b020060 	add	x0, x3, x2
    bec4:	f9401014 	ldr	x20, [x0, #32]
    bec8:	b4000254 	cbz	x20, bf10 <f0+0x2140>
    becc:	38626862 	ldrb	w2, [x3, x2]
    bed0:	7100085f 	cmp	w2, #0x2
    bed4:	54001580 	b.eq	c184 <f0+0x23b4>  // b.none
    bed8:	7100045f 	cmp	w2, #0x1
    bedc:	540001a1 	b.ne	bf10 <f0+0x2140>  // b.any
    bee0:	29430002 	ldp	w2, w0, [x0, #24]
    bee4:	92403c21 	and	x1, x1, #0xffff
    bee8:	9b027c21 	mul	x1, x1, x2
    beec:	d360fc21 	lsr	x1, x1, #32
    bef0:	eb00003f 	cmp	x1, x0
    bef4:	540000e2 	b.cs	bf10 <f0+0x2140>  // b.hs, b.nlast
    bef8:	8b010294 	add	x20, x20, x1
    befc:	39400280 	ldrb	w0, [x20]
    bf00:	7103fc1f 	cmp	w0, #0xff
    bf04:	54001a00 	b.eq	c244 <f0+0x2474>  // b.none
    bf08:	52800020 	mov	w0, #0x1                   	// #1
    bf0c:	39000280 	strb	w0, [x20]
    bf10:	911f63e1 	add	x1, sp, #0x7d8
    bf14:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bf18:	52800020 	mov	w0, #0x1                   	// #1
    bf1c:	f903eff5 	str	x21, [sp, #2008]
    bf20:	f903f3f7 	str	x23, [sp, #2016]
    bf24:	97ffe4f7 	bl	5300 <fwp_data.part.0.constprop.0>
    bf28:	97ffe563 	bl	54b4 <fwp_rc_fresh>
    bf2c:	aa0003e2 	mov	x2, x0
    bf30:	911fa3e1 	add	x1, sp, #0x7e8
    bf34:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    bf38:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    bf3c:	52800020 	mov	w0, #0x1                   	// #1
    bf40:	f903f7f4 	str	x20, [sp, #2024]
    bf44:	f903fbe2 	str	x2, [sp, #2032]
    bf48:	97ffe4ee 	bl	5300 <fwp_data.part.0.constprop.0>
    bf4c:	97ffe55a 	bl	54b4 <fwp_rc_fresh>
    bf50:	aa0003e2 	mov	x2, x0
    bf54:	911fe3e1 	add	x1, sp, #0x7f8
    bf58:	52800020 	mov	w0, #0x1                   	// #1
    bf5c:	f903fff5 	str	x21, [sp, #2040]
    bf60:	f90403e2 	str	x2, [sp, #2048]
    bf64:	97ffe4e7 	bl	5300 <fwp_data.part.0.constprop.0>
    bf68:	97ffe553 	bl	54b4 <fwp_rc_fresh>
    bf6c:	aa0003e2 	mov	x2, x0
    bf70:	912023e1 	add	x1, sp, #0x808
    bf74:	52800020 	mov	w0, #0x1                   	// #1
    bf78:	f90407f4 	str	x20, [sp, #2056]
    bf7c:	f9040be2 	str	x2, [sp, #2064]
    bf80:	97ffe4e0 	bl	5300 <fwp_data.part.0.constprop.0>
    bf84:	97ffe54c 	bl	54b4 <fwp_rc_fresh>
    bf88:	aa0003e2 	mov	x2, x0
    bf8c:	912063e1 	add	x1, sp, #0x818
    bf90:	52800020 	mov	w0, #0x1                   	// #1
    bf94:	f9040ff5 	str	x21, [sp, #2072]
    bf98:	f90413e2 	str	x2, [sp, #2080]
    bf9c:	97ffe4d9 	bl	5300 <fwp_data.part.0.constprop.0>
    bfa0:	97ffe545 	bl	54b4 <fwp_rc_fresh>
    bfa4:	aa0003e2 	mov	x2, x0
    bfa8:	9120a3e1 	add	x1, sp, #0x828
    bfac:	52800020 	mov	w0, #0x1                   	// #1
    bfb0:	f90417f4 	str	x20, [sp, #2088]
    bfb4:	f9041be2 	str	x2, [sp, #2096]
    bfb8:	97ffe4d2 	bl	5300 <fwp_data.part.0.constprop.0>
    bfbc:	97ffe53e 	bl	54b4 <fwp_rc_fresh>
    bfc0:	aa0003e2 	mov	x2, x0
    bfc4:	9120e3e1 	add	x1, sp, #0x838
    bfc8:	52800020 	mov	w0, #0x1                   	// #1
    bfcc:	f9041ff5 	str	x21, [sp, #2104]
    bfd0:	f90423e2 	str	x2, [sp, #2112]
    bfd4:	97ffe4cb 	bl	5300 <fwp_data.part.0.constprop.0>
    bfd8:	97ffe537 	bl	54b4 <fwp_rc_fresh>
    bfdc:	aa0003e2 	mov	x2, x0
    bfe0:	aa1603e1 	mov	x1, x22
    bfe4:	52800020 	mov	w0, #0x1                   	// #1
    bfe8:	f90427f4 	str	x20, [sp, #2120]
    bfec:	f9042be2 	str	x2, [sp, #2128]
    bff0:	97ffe4c4 	bl	5300 <fwp_data.part.0.constprop.0>
    bff4:	97ffe530 	bl	54b4 <fwp_rc_fresh>
    bff8:	aa0003f5 	mov	x21, x0
    bffc:	aa1303e1 	mov	x1, x19
    c000:	97fff480 	bl	9200 <fwp_hof0.constprop.0>
    c004:	aa0003f4 	mov	x20, x0
    c008:	aa1503e0 	mov	x0, x21
    c00c:	97ffe685 	bl	5a20 <fwp_drop0>
    c010:	aa1303e0 	mov	x0, x19
    c014:	97ffe683 	bl	5a20 <fwp_drop0>
    c018:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c01c:	f947f400 	ldr	x0, [x0, #4072]
    c020:	f9442fe2 	ldr	x2, [sp, #2136]
    c024:	f9400001 	ldr	x1, [x0]
    c028:	eb010042 	subs	x2, x2, x1
    c02c:	d2800001 	mov	x1, #0x0                   	// #0
    c030:	54001f41 	b.ne	c418 <f0+0x2648>  // b.any
    c034:	912183ff 	add	sp, sp, #0x860
    c038:	aa1403e0 	mov	x0, x20
    c03c:	a94153f3 	ldp	x19, x20, [sp, #16]
    c040:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c044:	a94363f7 	ldp	x23, x24, [sp, #48]
    c048:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c04c:	a94573fb 	ldp	x27, x28, [sp, #80]
    c050:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c054:	d65f03c0 	ret
    c058:	aa1b03e0 	mov	x0, x27
    c05c:	97ffe125 	bl	44f0 <fwp_rc_forget_slot>
    c060:	17fff7a4 	b	9ef0 <f0+0x120>
    c064:	72003c5f 	tst	w2, #0xffff
    c068:	54fef461 	b.ne	9ef4 <f0+0x124>  // b.any
    c06c:	17fff79e 	b	9ee4 <f0+0x114>
    c070:	72003c3f 	tst	w1, #0xffff
    c074:	54ff8841 	b.ne	b17c <f0+0x13ac>  // b.any
    c078:	17fffc3c 	b	b168 <f0+0x1398>
    c07c:	72003c3f 	tst	w1, #0xffff
    c080:	54ff8061 	b.ne	b08c <f0+0x12bc>  // b.any
    c084:	17fffbfd 	b	b078 <f0+0x12a8>
    c088:	72003c3f 	tst	w1, #0xffff
    c08c:	54ff7b41 	b.ne	aff4 <f0+0x1224>  // b.any
    c090:	17fffbd4 	b	afe0 <f0+0x1210>
    c094:	72003c3f 	tst	w1, #0xffff
    c098:	54ff7441 	b.ne	af20 <f0+0x1150>  // b.any
    c09c:	17fffb9c 	b	af0c <f0+0x113c>
    c0a0:	72003c3f 	tst	w1, #0xffff
    c0a4:	54ff6c61 	b.ne	ae30 <f0+0x1060>  // b.any
    c0a8:	17fffb5d 	b	ae1c <f0+0x104c>
    c0ac:	72003c3f 	tst	w1, #0xffff
    c0b0:	54ff6481 	b.ne	ad40 <f0+0xf70>  // b.any
    c0b4:	17fffb1e 	b	ad2c <f0+0xf5c>
    c0b8:	72003c3f 	tst	w1, #0xffff
    c0bc:	54ff55a1 	b.ne	ab70 <f0+0xda0>  // b.any
    c0c0:	17fffaa7 	b	ab5c <f0+0xd8c>
    c0c4:	72003c3f 	tst	w1, #0xffff
    c0c8:	54ff5081 	b.ne	aad8 <f0+0xd08>  // b.any
    c0cc:	17fffa7e 	b	aac4 <f0+0xcf4>
    c0d0:	72003c3f 	tst	w1, #0xffff
    c0d4:	54ff0901 	b.ne	a1f4 <f0+0x424>  // b.any
    c0d8:	17fff842 	b	a1e0 <f0+0x410>
    c0dc:	72003c3f 	tst	w1, #0xffff
    c0e0:	54ff0321 	b.ne	a144 <f0+0x374>  // b.any
    c0e4:	17fff813 	b	a130 <f0+0x360>
    c0e8:	72003c3f 	tst	w1, #0xffff
    c0ec:	54fef5c1 	b.ne	9fa4 <f0+0x1d4>  // b.any
    c0f0:	17fff7a8 	b	9f90 <f0+0x1c0>
    c0f4:	72003c3f 	tst	w1, #0xffff
    c0f8:	54ff1e61 	b.ne	a4c4 <f0+0x6f4>  // b.any
    c0fc:	17fff8ed 	b	a4b0 <f0+0x6e0>
    c100:	72003c3f 	tst	w1, #0xffff
    c104:	54ff1981 	b.ne	a434 <f0+0x664>  // b.any
    c108:	17fff8c6 	b	a420 <f0+0x650>
    c10c:	72003c3f 	tst	w1, #0xffff
    c110:	54ff1221 	b.ne	a354 <f0+0x584>  // b.any
    c114:	17fff88b 	b	a340 <f0+0x570>
    c118:	72003c3f 	tst	w1, #0xffff
    c11c:	54ff0c41 	b.ne	a2a4 <f0+0x4d4>  // b.any
    c120:	17fff85c 	b	a290 <f0+0x4c0>
    c124:	72003c3f 	tst	w1, #0xffff
    c128:	54ff47c1 	b.ne	aa20 <f0+0xc50>  // b.any
    c12c:	17fffa38 	b	aa0c <f0+0xc3c>
    c130:	72003c3f 	tst	w1, #0xffff
    c134:	54ff42c1 	b.ne	a98c <f0+0xbbc>  // b.any
    c138:	17fffa10 	b	a978 <f0+0xba8>
    c13c:	72003c3f 	tst	w1, #0xffff
    c140:	54ff3da1 	b.ne	a8f4 <f0+0xb24>  // b.any
    c144:	17fff9e7 	b	a8e0 <f0+0xb10>
    c148:	72003c3f 	tst	w1, #0xffff
    c14c:	54ff38a1 	b.ne	a860 <f0+0xa90>  // b.any
    c150:	17fff9bf 	b	a84c <f0+0xa7c>
    c154:	72003c3f 	tst	w1, #0xffff
    c158:	54ff3281 	b.ne	a7a8 <f0+0x9d8>  // b.any
    c15c:	17fff98e 	b	a794 <f0+0x9c4>
    c160:	72003c3f 	tst	w1, #0xffff
    c164:	54ff2d61 	b.ne	a710 <f0+0x940>  // b.any
    c168:	17fff965 	b	a6fc <f0+0x92c>
    c16c:	72003c3f 	tst	w1, #0xffff
    c170:	54ff24c1 	b.ne	a608 <f0+0x838>  // b.any
    c174:	17fff920 	b	a5f4 <f0+0x824>
    c178:	72003c3f 	tst	w1, #0xffff
    c17c:	54ff1ee1 	b.ne	a558 <f0+0x788>  // b.any
    c180:	17fff8f1 	b	a544 <f0+0x774>
    c184:	72003c3f 	tst	w1, #0xffff
    c188:	54ffec41 	b.ne	bf10 <f0+0x2140>  // b.any
    c18c:	17ffff5c 	b	befc <f0+0x212c>
    c190:	72003c3f 	tst	w1, #0xffff
    c194:	54ffe721 	b.ne	be78 <f0+0x20a8>  // b.any
    c198:	17ffff33 	b	be64 <f0+0x2094>
    c19c:	72003c3f 	tst	w1, #0xffff
    c1a0:	54ffe221 	b.ne	bde4 <f0+0x2014>  // b.any
    c1a4:	17ffff0b 	b	bdd0 <f0+0x2000>
    c1a8:	72003c3f 	tst	w1, #0xffff
    c1ac:	54ffd501 	b.ne	bc4c <f0+0x1e7c>  // b.any
    c1b0:	17fffea2 	b	bc38 <f0+0x1e68>
    c1b4:	72003c3f 	tst	w1, #0xffff
    c1b8:	54ffcd21 	b.ne	bb5c <f0+0x1d8c>  // b.any
    c1bc:	17fffe63 	b	bb48 <f0+0x1d78>
    c1c0:	72003c3f 	tst	w1, #0xffff
    c1c4:	54ffc801 	b.ne	bac4 <f0+0x1cf4>  // b.any
    c1c8:	17fffe3a 	b	bab0 <f0+0x1ce0>
    c1cc:	72003c3f 	tst	w1, #0xffff
    c1d0:	54ffc301 	b.ne	ba30 <f0+0x1c60>  // b.any
    c1d4:	17fffe12 	b	ba1c <f0+0x1c4c>
    c1d8:	72003c3f 	tst	w1, #0xffff
    c1dc:	54ffbce1 	b.ne	b978 <f0+0x1ba8>  // b.any
    c1e0:	17fffde1 	b	b964 <f0+0x1b94>
    c1e4:	72003c3f 	tst	w1, #0xffff
    c1e8:	54ffb6c1 	b.ne	b8c0 <f0+0x1af0>  // b.any
    c1ec:	17fffdb0 	b	b8ac <f0+0x1adc>
    c1f0:	72003c3f 	tst	w1, #0xffff
    c1f4:	54ffb0a1 	b.ne	b808 <f0+0x1a38>  // b.any
    c1f8:	17fffd7f 	b	b7f4 <f0+0x1a24>
    c1fc:	72003c3f 	tst	w1, #0xffff
    c200:	54ffa541 	b.ne	b6a8 <f0+0x18d8>  // b.any
    c204:	17fffd24 	b	b694 <f0+0x18c4>
    c208:	72003c3f 	tst	w1, #0xffff
    c20c:	54ffa021 	b.ne	b610 <f0+0x1840>  // b.any
    c210:	17fffcfb 	b	b5fc <f0+0x182c>
    c214:	72003c3f 	tst	w1, #0xffff
    c218:	54ff9921 	b.ne	b53c <f0+0x176c>  // b.any
    c21c:	17fffcc3 	b	b528 <f0+0x1758>
    c220:	72003c3f 	tst	w1, #0xffff
    c224:	54ff9141 	b.ne	b44c <f0+0x167c>  // b.any
    c228:	17fffc84 	b	b438 <f0+0x1668>
    c22c:	72003c3f 	tst	w1, #0xffff
    c230:	54ff8961 	b.ne	b35c <f0+0x158c>  // b.any
    c234:	17fffc45 	b	b348 <f0+0x1578>
    c238:	72003c3f 	tst	w1, #0xffff
    c23c:	54ff80a1 	b.ne	b250 <f0+0x1480>  // b.any
    c240:	17fffbff 	b	b23c <f0+0x146c>
    c244:	aa1403e0 	mov	x0, x20
    c248:	97ffe0aa 	bl	44f0 <fwp_rc_forget_slot>
    c24c:	17ffff2f 	b	bf08 <f0+0x2138>
    c250:	aa1703e0 	mov	x0, x23
    c254:	97ffe0a7 	bl	44f0 <fwp_rc_forget_slot>
    c258:	17fff751 	b	9f9c <f0+0x1cc>
    c25c:	aa1703e0 	mov	x0, x23
    c260:	97ffe0a4 	bl	44f0 <fwp_rc_forget_slot>
    c264:	17fff7b6 	b	a13c <f0+0x36c>
    c268:	aa1703e0 	mov	x0, x23
    c26c:	97ffe0a1 	bl	44f0 <fwp_rc_forget_slot>
    c270:	17fff7df 	b	a1ec <f0+0x41c>
    c274:	aa1703e0 	mov	x0, x23
    c278:	97ffe09e 	bl	44f0 <fwp_rc_forget_slot>
    c27c:	17fff808 	b	a29c <f0+0x4cc>
    c280:	aa1703e0 	mov	x0, x23
    c284:	97ffe09b 	bl	44f0 <fwp_rc_forget_slot>
    c288:	17fff831 	b	a34c <f0+0x57c>
    c28c:	aa1703e0 	mov	x0, x23
    c290:	97ffe098 	bl	44f0 <fwp_rc_forget_slot>
    c294:	17fff866 	b	a42c <f0+0x65c>
    c298:	aa1703e0 	mov	x0, x23
    c29c:	97ffe095 	bl	44f0 <fwp_rc_forget_slot>
    c2a0:	17fff887 	b	a4bc <f0+0x6ec>
    c2a4:	aa1703e0 	mov	x0, x23
    c2a8:	97ffe092 	bl	44f0 <fwp_rc_forget_slot>
    c2ac:	17fff8a9 	b	a550 <f0+0x780>
    c2b0:	aa1703e0 	mov	x0, x23
    c2b4:	97ffe08f 	bl	44f0 <fwp_rc_forget_slot>
    c2b8:	17fff8d2 	b	a600 <f0+0x830>
    c2bc:	aa1703e0 	mov	x0, x23
    c2c0:	97ffe08c 	bl	44f0 <fwp_rc_forget_slot>
    c2c4:	17fff911 	b	a708 <f0+0x938>
    c2c8:	aa1703e0 	mov	x0, x23
    c2cc:	97ffe089 	bl	44f0 <fwp_rc_forget_slot>
    c2d0:	17fff934 	b	a7a0 <f0+0x9d0>
    c2d4:	aa1703e0 	mov	x0, x23
    c2d8:	97ffe086 	bl	44f0 <fwp_rc_forget_slot>
    c2dc:	17fff95f 	b	a858 <f0+0xa88>
    c2e0:	aa1703e0 	mov	x0, x23
    c2e4:	97ffe083 	bl	44f0 <fwp_rc_forget_slot>
    c2e8:	17fff981 	b	a8ec <f0+0xb1c>
    c2ec:	aa1703e0 	mov	x0, x23
    c2f0:	97ffe080 	bl	44f0 <fwp_rc_forget_slot>
    c2f4:	17fff9a4 	b	a984 <f0+0xbb4>
    c2f8:	aa1703e0 	mov	x0, x23
    c2fc:	97ffe07d 	bl	44f0 <fwp_rc_forget_slot>
    c300:	17fff9c6 	b	aa18 <f0+0xc48>
    c304:	aa1703e0 	mov	x0, x23
    c308:	97ffe07a 	bl	44f0 <fwp_rc_forget_slot>
    c30c:	17fff9f1 	b	aad0 <f0+0xd00>
    c310:	aa1703e0 	mov	x0, x23
    c314:	97ffe077 	bl	44f0 <fwp_rc_forget_slot>
    c318:	17fffa14 	b	ab68 <f0+0xd98>
    c31c:	aa1703e0 	mov	x0, x23
    c320:	97ffe074 	bl	44f0 <fwp_rc_forget_slot>
    c324:	17fffa85 	b	ad38 <f0+0xf68>
    c328:	aa1703e0 	mov	x0, x23
    c32c:	97ffe071 	bl	44f0 <fwp_rc_forget_slot>
    c330:	17fffabe 	b	ae28 <f0+0x1058>
    c334:	aa1703e0 	mov	x0, x23
    c338:	97ffe06e 	bl	44f0 <fwp_rc_forget_slot>
    c33c:	17fffaf7 	b	af18 <f0+0x1148>
    c340:	aa1703e0 	mov	x0, x23
    c344:	97ffe06b 	bl	44f0 <fwp_rc_forget_slot>
    c348:	17fffb29 	b	afec <f0+0x121c>
    c34c:	aa1703e0 	mov	x0, x23
    c350:	97ffe068 	bl	44f0 <fwp_rc_forget_slot>
    c354:	17fffb4c 	b	b084 <f0+0x12b4>
    c358:	aa1703e0 	mov	x0, x23
    c35c:	97ffe065 	bl	44f0 <fwp_rc_forget_slot>
    c360:	17fffb85 	b	b174 <f0+0x13a4>
    c364:	aa1703e0 	mov	x0, x23
    c368:	97ffe062 	bl	44f0 <fwp_rc_forget_slot>
    c36c:	17fffbb7 	b	b248 <f0+0x1478>
    c370:	aa1703e0 	mov	x0, x23
    c374:	97ffe05f 	bl	44f0 <fwp_rc_forget_slot>
    c378:	17fffbf7 	b	b354 <f0+0x1584>
    c37c:	aa1703e0 	mov	x0, x23
    c380:	97ffe05c 	bl	44f0 <fwp_rc_forget_slot>
    c384:	17fffc30 	b	b444 <f0+0x1674>
    c388:	aa1703e0 	mov	x0, x23
    c38c:	97ffe059 	bl	44f0 <fwp_rc_forget_slot>
    c390:	17fffc69 	b	b534 <f0+0x1764>
    c394:	aa1703e0 	mov	x0, x23
    c398:	97ffe056 	bl	44f0 <fwp_rc_forget_slot>
    c39c:	17fffc9b 	b	b608 <f0+0x1838>
    c3a0:	aa1703e0 	mov	x0, x23
    c3a4:	97ffe053 	bl	44f0 <fwp_rc_forget_slot>
    c3a8:	17fffcbe 	b	b6a0 <f0+0x18d0>
    c3ac:	aa1703e0 	mov	x0, x23
    c3b0:	97ffe050 	bl	44f0 <fwp_rc_forget_slot>
    c3b4:	17fffd13 	b	b800 <f0+0x1a30>
    c3b8:	aa1703e0 	mov	x0, x23
    c3bc:	97ffe04d 	bl	44f0 <fwp_rc_forget_slot>
    c3c0:	17fffd3e 	b	b8b8 <f0+0x1ae8>
    c3c4:	aa1703e0 	mov	x0, x23
    c3c8:	97ffe04a 	bl	44f0 <fwp_rc_forget_slot>
    c3cc:	17fffd69 	b	b970 <f0+0x1ba0>
    c3d0:	aa1703e0 	mov	x0, x23
    c3d4:	97ffe047 	bl	44f0 <fwp_rc_forget_slot>
    c3d8:	17fffd94 	b	ba28 <f0+0x1c58>
    c3dc:	aa1703e0 	mov	x0, x23
    c3e0:	97ffe044 	bl	44f0 <fwp_rc_forget_slot>
    c3e4:	17fffdb6 	b	babc <f0+0x1cec>
    c3e8:	aa1703e0 	mov	x0, x23
    c3ec:	97ffe041 	bl	44f0 <fwp_rc_forget_slot>
    c3f0:	17fffdd9 	b	bb54 <f0+0x1d84>
    c3f4:	aa1703e0 	mov	x0, x23
    c3f8:	97ffe03e 	bl	44f0 <fwp_rc_forget_slot>
    c3fc:	17fffe12 	b	bc44 <f0+0x1e74>
    c400:	aa1703e0 	mov	x0, x23
    c404:	97ffe03b 	bl	44f0 <fwp_rc_forget_slot>
    c408:	17fffe75 	b	bddc <f0+0x200c>
    c40c:	aa1703e0 	mov	x0, x23
    c410:	97ffe038 	bl	44f0 <fwp_rc_forget_slot>
    c414:	17fffe97 	b	be70 <f0+0x20a0>
    c418:	97ffd8f6 	bl	27f0 <__stack_chk_fail@plt>
    c41c:	d503201f 	nop

000000000000c420 <fwp_main_thread>:
    c420:	d10443ff 	sub	sp, sp, #0x110
    c424:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c428:	f947f400 	ldr	x0, [x0, #4072]
    c42c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c430:	910303fd 	add	x29, sp, #0xc0
    c434:	a90d53f3 	stp	x19, x20, [sp, #208]
    c438:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc90>
    c43c:	91154261 	add	x1, x19, #0x550
    c440:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c444:	b953a421 	ldr	w1, [x1, #5028]
    c448:	f9400002 	ldr	x2, [x0]
    c44c:	f9005fe2 	str	x2, [sp, #184]
    c450:	d2800002 	mov	x2, #0x0                   	// #0
    c454:	340025c1 	cbz	w1, c90c <fwp_main_thread+0x4ec>
    c458:	91154273 	add	x19, x19, #0x550
    c45c:	b953aa60 	ldr	w0, [x19, #5032]
    c460:	350024e0 	cbnz	w0, c8fc <fwp_main_thread+0x4dc>
    c464:	91001fe2 	add	x2, sp, #0x7
    c468:	900000b5 	adrp	x21, 20000 <__data_start>
    c46c:	900000a3 	adrp	x3, 20000 <__data_start>
    c470:	910102b3 	add	x19, x21, #0x40
    c474:	910dc063 	add	x3, x3, #0x370
    c478:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c47c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c480:	910023e0 	add	x0, sp, #0x8
    c484:	d2800001 	mov	x1, #0x0                   	// #0
    c488:	f90007e3 	str	x3, [sp, #8]
    c48c:	b90013ff 	str	wzr, [sp, #16]
    c490:	a9019262 	stp	x2, x4, [x19, #24]
    c494:	f9000fe5 	str	x5, [sp, #24]
    c498:	97ffd86e 	bl	2650 <sigaltstack@plt>
    c49c:	35002520 	cbnz	w0, c940 <fwp_main_thread+0x520>
    c4a0:	4f000400 	movi	v0.4s, #0x0
    c4a4:	9100a3e0 	add	x0, sp, #0x28
    c4a8:	d0ffffa1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    c4ac:	52800082 	mov	w2, #0x4                   	// #4
    c4b0:	913fc021 	add	x1, x1, #0xff0
    c4b4:	72a10002 	movk	w2, #0x800, lsl #16
    c4b8:	910083f4 	add	x20, sp, #0x20
    c4bc:	f90013e1 	str	x1, [sp, #32]
    c4c0:	3d802000 	str	q0, [x0, #128]
    c4c4:	b900abe2 	str	w2, [sp, #168]
    c4c8:	ad000000 	stp	q0, q0, [x0]
    c4cc:	ad010000 	stp	q0, q0, [x0, #32]
    c4d0:	ad020000 	stp	q0, q0, [x0, #64]
    c4d4:	ad030000 	stp	q0, q0, [x0, #96]
    c4d8:	97ffd8b6 	bl	27b0 <sigemptyset@plt>
    c4dc:	35002320 	cbnz	w0, c940 <fwp_main_thread+0x520>
    c4e0:	aa1403e1 	mov	x1, x20
    c4e4:	d2800002 	mov	x2, #0x0                   	// #0
    c4e8:	52800160 	mov	w0, #0xb                   	// #11
    c4ec:	97ffd8c9 	bl	2810 <sigaction@plt>
    c4f0:	35002280 	cbnz	w0, c940 <fwp_main_thread+0x520>
    c4f4:	aa1403e1 	mov	x1, x20
    c4f8:	d2800002 	mov	x2, #0x0                   	// #0
    c4fc:	528000e0 	mov	w0, #0x7                   	// #7
    c500:	97ffd8c4 	bl	2810 <sigaction@plt>
    c504:	350021e0 	cbnz	w0, c940 <fwp_main_thread+0x520>
    c508:	b942fa60 	ldr	w0, [x19, #760]
    c50c:	a90f63f7 	stp	x23, x24, [sp, #240]
    c510:	34002020 	cbz	w0, c914 <fwp_main_thread+0x4f4>
    c514:	910102b6 	add	x22, x21, #0x40
    c518:	f9400ad4 	ldr	x20, [x22, #16]
    c51c:	b40010d4 	cbz	x20, c734 <fwp_main_thread+0x314>
    c520:	aa1403f3 	mov	x19, x20
    c524:	91010297 	add	x23, x20, #0x40
    c528:	f90083f9 	str	x25, [sp, #256]
    c52c:	52800038 	mov	w24, #0x1                   	// #1
    c530:	39414a99 	ldrb	w25, [x20, #82]
    c534:	39014a98 	strb	w24, [x20, #82]
    c538:	f9401680 	ldr	x0, [x20, #40]
    c53c:	b4000620 	cbz	x0, c600 <fwp_main_thread+0x1e0>
    c540:	f9403281 	ldr	x1, [x20, #96]
    c544:	39414680 	ldrb	w0, [x20, #81]
    c548:	b4000b41 	cbz	x1, c6b0 <fwp_main_thread+0x290>
    c54c:	36000a80 	tbz	w0, #0, c69c <fwp_main_thread+0x27c>
    c550:	39414a62 	ldrb	w2, [x19, #82]
    c554:	f9402280 	ldr	x0, [x20, #64]
    c558:	37000d62 	tbnz	w2, #0, c704 <fwp_main_thread+0x2e4>
    c55c:	f9403261 	ldr	x1, [x19, #96]
    c560:	a911fe77 	stp	x23, xzr, [x19, #280]
    c564:	f9009660 	str	x0, [x19, #296]
    c568:	b4000040 	cbz	x0, c570 <fwp_main_thread+0x150>
    c56c:	f9009013 	str	x19, [x0, #288]
    c570:	f9002293 	str	x19, [x20, #64]
    c574:	b4000101 	cbz	x1, c594 <fwp_main_thread+0x174>
    c578:	f94046c0 	ldr	x0, [x22, #136]
    c57c:	39015678 	strb	w24, [x19, #85]
    c580:	f9003661 	str	x1, [x19, #104]
    c584:	a910827f 	stp	xzr, x0, [x19, #264]
    c588:	b4000040 	cbz	x0, c590 <fwp_main_thread+0x170>
    c58c:	f9008413 	str	x19, [x0, #264]
    c590:	f90046d3 	str	x19, [x22, #136]
    c594:	39015a7f 	strb	wzr, [x19, #86]
    c598:	97ffe75b 	bl	6304 <fwp_block>
    c59c:	f9408e62 	ldr	x2, [x19, #280]
    c5a0:	b4000142 	cbz	x2, c5c8 <fwp_main_thread+0x1a8>
    c5a4:	a9520261 	ldp	x1, x0, [x19, #288]
    c5a8:	b4000ba1 	cbz	x1, c71c <fwp_main_thread+0x2fc>
    c5ac:	f9009420 	str	x0, [x1, #296]
    c5b0:	f9409660 	ldr	x0, [x19, #296]
    c5b4:	b4000040 	cbz	x0, c5bc <fwp_main_thread+0x19c>
    c5b8:	f9009001 	str	x1, [x0, #288]
    c5bc:	91080260 	add	x0, x19, #0x200
    c5c0:	f900967f 	str	xzr, [x19, #296]
    c5c4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c5c8:	39415660 	ldrb	w0, [x19, #85]
    c5cc:	f9400ac2 	ldr	x2, [x22, #16]
    c5d0:	36000960 	tbz	w0, #0, c6fc <fwp_main_thread+0x2dc>
    c5d4:	a9508261 	ldp	x1, x0, [x19, #264]
    c5d8:	b4000a61 	cbz	x1, c724 <fwp_main_thread+0x304>
    c5dc:	f9008820 	str	x0, [x1, #272]
    c5e0:	b4000040 	cbz	x0, c5e8 <fwp_main_thread+0x1c8>
    c5e4:	f9008401 	str	x1, [x0, #264]
    c5e8:	91080260 	add	x0, x19, #0x200
    c5ec:	3901567f 	strb	wzr, [x19, #85]
    c5f0:	aa0203f3 	mov	x19, x2
    c5f4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c5f8:	f9401680 	ldr	x0, [x20, #40]
    c5fc:	b5fffa20 	cbnz	x0, c540 <fwp_main_thread+0x120>
    c600:	910102a0 	add	x0, x21, #0x40
    c604:	39014a99 	strb	w25, [x20, #82]
    c608:	f94083f9 	ldr	x25, [sp, #256]
    c60c:	f9416c00 	ldr	x0, [x0, #728]
    c610:	b4001560 	cbz	x0, c8bc <fwp_main_thread+0x49c>
    c614:	910102a0 	add	x0, x21, #0x40
    c618:	f9418801 	ldr	x1, [x0, #784]
    c61c:	b903081f 	str	wzr, [x0, #776]
    c620:	eb13003f 	cmp	x1, x19
    c624:	54001681 	b.ne	c8f4 <fwp_main_thread+0x4d4>  // b.any
    c628:	b4000913 	cbz	x19, c748 <fwp_main_thread+0x328>
    c62c:	910102a0 	add	x0, x21, #0x40
    c630:	52800021 	mov	w1, #0x1                   	// #1
    c634:	39014a61 	strb	w1, [x19, #82]
    c638:	f9415805 	ldr	x5, [x0, #688]
    c63c:	b4000865 	cbz	x5, c748 <fwp_main_thread+0x328>
    c640:	394140a0 	ldrb	w0, [x5, #80]
    c644:	37000060 	tbnz	w0, #0, c650 <fwp_main_thread+0x230>
    c648:	aa0503e0 	mov	x0, x5
    c64c:	97ffdb69 	bl	33f0 <fwp_cancel_tree.part.0>
    c650:	f9409ca5 	ldr	x5, [x5, #312]
    c654:	b5ffff65 	cbnz	x5, c640 <fwp_main_thread+0x220>
    c658:	910102b4 	add	x20, x21, #0x40
    c65c:	52800036 	mov	w22, #0x1                   	// #1
    c660:	f9402a60 	ldr	x0, [x19, #80]
    c664:	f2001c1f 	tst	x0, #0xff000000ff
    c668:	540000e1 	b.ne	c684 <fwp_main_thread+0x264>  // b.any
    c66c:	f9401680 	ldr	x0, [x20, #40]
    c670:	39015276 	strb	w22, [x19, #84]
    c674:	f900827f 	str	xzr, [x19, #256]
    c678:	b40005a0 	cbz	x0, c72c <fwp_main_thread+0x30c>
    c67c:	f9008013 	str	x19, [x0, #256]
    c680:	f9001693 	str	x19, [x20, #40]
    c684:	97ffe720 	bl	6304 <fwp_block>
    c688:	97ffe6b2 	bl	6150 <fwp_free_zombie>
    c68c:	f9415a80 	ldr	x0, [x20, #688]
    c690:	b40005c0 	cbz	x0, c748 <fwp_main_thread+0x328>
    c694:	f9418a93 	ldr	x19, [x20, #784]
    c698:	17fffff2 	b	c660 <fwp_main_thread+0x240>
    c69c:	97ffdbf9 	bl	3680 <fwp_now_ns>
    c6a0:	f9403281 	ldr	x1, [x20, #96]
    c6a4:	eb01001f 	cmp	x0, x1
    c6a8:	54000fca 	b.ge	c8a0 <fwp_main_thread+0x480>  // b.tcont
    c6ac:	39414680 	ldrb	w0, [x20, #81]
    c6b0:	39414a62 	ldrb	w2, [x19, #82]
    c6b4:	3707f500 	tbnz	w0, #0, c554 <fwp_main_thread+0x134>
    c6b8:	f9403281 	ldr	x1, [x20, #96]
    c6bc:	370001c2 	tbnz	w2, #0, c6f4 <fwp_main_thread+0x2d4>
    c6c0:	f9403260 	ldr	x0, [x19, #96]
    c6c4:	b4000180 	cbz	x0, c6f4 <fwp_main_thread+0x2d4>
    c6c8:	b4000061 	cbz	x1, c6d4 <fwp_main_thread+0x2b4>
    c6cc:	eb01001f 	cmp	x0, x1
    c6d0:	9a81d000 	csel	x0, x0, x1, le
    c6d4:	f9402281 	ldr	x1, [x20, #64]
    c6d8:	a911fe77 	stp	x23, xzr, [x19, #280]
    c6dc:	f9009661 	str	x1, [x19, #296]
    c6e0:	b4001241 	cbz	x1, c928 <fwp_main_thread+0x508>
    c6e4:	f9009033 	str	x19, [x1, #288]
    c6e8:	aa0003e1 	mov	x1, x0
    c6ec:	f9002293 	str	x19, [x20, #64]
    c6f0:	17ffffa2 	b	c578 <fwp_main_thread+0x158>
    c6f4:	f9402280 	ldr	x0, [x20, #64]
    c6f8:	17ffff9a 	b	c560 <fwp_main_thread+0x140>
    c6fc:	aa0203f3 	mov	x19, x2
    c700:	17ffff8e 	b	c538 <fwp_main_thread+0x118>
    c704:	a911fe77 	stp	x23, xzr, [x19, #280]
    c708:	f9009660 	str	x0, [x19, #296]
    c70c:	b4000040 	cbz	x0, c714 <fwp_main_thread+0x2f4>
    c710:	f9009013 	str	x19, [x0, #288]
    c714:	f9002293 	str	x19, [x20, #64]
    c718:	17ffff9f 	b	c594 <fwp_main_thread+0x174>
    c71c:	f9000040 	str	x0, [x2]
    c720:	17ffffa5 	b	c5b4 <fwp_main_thread+0x194>
    c724:	f90046c0 	str	x0, [x22, #136]
    c728:	17ffffae 	b	c5e0 <fwp_main_thread+0x1c0>
    c72c:	f9001a93 	str	x19, [x20, #48]
    c730:	17ffffd4 	b	c680 <fwp_main_thread+0x260>
    c734:	f9416ec0 	ldr	x0, [x22, #728]
    c738:	b4000c00 	cbz	x0, c8b8 <fwp_main_thread+0x498>
    c73c:	f9418ac0 	ldr	x0, [x22, #784]
    c740:	b9030adf 	str	wzr, [x22, #776]
    c744:	b5000d80 	cbnz	x0, c8f4 <fwp_main_thread+0x4d4>
    c748:	910102b4 	add	x20, x21, #0x40
    c74c:	97ffe681 	bl	6150 <fwp_free_zombie>
    c750:	f9401a80 	ldr	x0, [x20, #48]
    c754:	b5000d00 	cbnz	x0, c8f4 <fwp_main_thread+0x4d4>
    c758:	f9404680 	ldr	x0, [x20, #136]
    c75c:	b5000cc0 	cbnz	x0, c8f4 <fwp_main_thread+0x4d4>
    c760:	b940aa93 	ldr	w19, [x20, #168]
    c764:	340001d3 	cbz	w19, c79c <fwp_main_thread+0x37c>
    c768:	93407e76 	sxtw	x22, w19
    c76c:	51000673 	sub	w19, w19, #0x1
    c770:	d1000ad6 	sub	x22, x22, #0x2
    c774:	9102c297 	add	x23, x20, #0xb0
    c778:	cb3342d6 	sub	x22, x22, w19, uxtw
    c77c:	93407e73 	sxtw	x19, w19
    c780:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c784:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c788:	b900aa93 	str	w19, [x20, #168]
    c78c:	d1000673 	sub	x19, x19, #0x1
    c790:	97ffd860 	bl	2910 <munmap@plt>
    c794:	eb16027f 	cmp	x19, x22
    c798:	54ffff41 	b.ne	c780 <fwp_main_thread+0x360>  // b.any
    c79c:	900000b3 	adrp	x19, 20000 <__data_start>
    c7a0:	91004260 	add	x0, x19, #0x10
    c7a4:	b9401000 	ldr	w0, [x0, #16]
    c7a8:	37f80040 	tbnz	w0, #31, c7b0 <fwp_main_thread+0x390>
    c7ac:	97ffd815 	bl	2800 <close@plt>
    c7b0:	910102a0 	add	x0, x21, #0x40
    c7b4:	91004261 	add	x1, x19, #0x10
    c7b8:	12800002 	mov	w2, #0xffffffff            	// #-1
    c7bc:	d2800013 	mov	x19, #0x0                   	// #0
    c7c0:	f9418c16 	ldr	x22, [x0, #792]
    c7c4:	b9001022 	str	w2, [x1, #16]
    c7c8:	f9419014 	ldr	x20, [x0, #800]
    c7cc:	b4000176 	cbz	x22, c7f8 <fwp_main_thread+0x3d8>
    c7d0:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c7d4:	b40000c0 	cbz	x0, c7ec <fwp_main_thread+0x3cc>
    c7d8:	f9400001 	ldr	x1, [x0]
    c7dc:	b50008c1 	cbnz	x1, c8f4 <fwp_main_thread+0x4d4>
    c7e0:	f9400401 	ldr	x1, [x0, #8]
    c7e4:	b5000881 	cbnz	x1, c8f4 <fwp_main_thread+0x4d4>
    c7e8:	97ffdfe2 	bl	4770 <fwp_mem_free>
    c7ec:	91000673 	add	x19, x19, #0x1
    c7f0:	eb16027f 	cmp	x19, x22
    c7f4:	54fffee1 	b.ne	c7d0 <fwp_main_thread+0x3b0>  // b.any
    c7f8:	aa1403e0 	mov	x0, x20
    c7fc:	97ffdfdd 	bl	4770 <fwp_mem_free>
    c800:	910102a0 	add	x0, x21, #0x40
    c804:	f9418813 	ldr	x19, [x0, #784]
    c808:	f9018c1f 	str	xzr, [x0, #792]
    c80c:	f901901f 	str	xzr, [x0, #800]
    c810:	b40001f3 	cbz	x19, c84c <fwp_main_thread+0x42c>
    c814:	f9401661 	ldr	x1, [x19, #40]
    c818:	b50006e1 	cbnz	x1, c8f4 <fwp_main_thread+0x4d4>
    c81c:	f9405661 	ldr	x1, [x19, #168]
    c820:	b50006a1 	cbnz	x1, c8f4 <fwp_main_thread+0x4d4>
    c824:	f9416c01 	ldr	x1, [x0, #728]
    c828:	b5000661 	cbnz	x1, c8f4 <fwp_main_thread+0x4d4>
    c82c:	f9417400 	ldr	x0, [x0, #744]
    c830:	b5000620 	cbnz	x0, c8f4 <fwp_main_thread+0x4d4>
    c834:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c838:	90000120 	adrp	x0, 30000 <alt.5+0xfc90>
    c83c:	910dc000 	add	x0, x0, #0x370
    c840:	97ffd7e0 	bl	27c0 <memset@plt>
    c844:	aa1303e0 	mov	x0, x19
    c848:	97ffdfca 	bl	4770 <fwp_mem_free>
    c84c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c850:	f947ec00 	ldr	x0, [x0, #4056]
    c854:	910102b5 	add	x21, x21, #0x40
    c858:	f9400000 	ldr	x0, [x0]
    c85c:	f9000abf 	str	xzr, [x21, #16]
    c860:	f9018abf 	str	xzr, [x21, #784]
    c864:	97ffd82f 	bl	2920 <fflush@plt>
    c868:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c86c:	f947f400 	ldr	x0, [x0, #4072]
    c870:	f9405fe2 	ldr	x2, [sp, #184]
    c874:	f9400001 	ldr	x1, [x0]
    c878:	eb010042 	subs	x2, x2, x1
    c87c:	d2800001 	mov	x1, #0x0                   	// #0
    c880:	540006a1 	b.ne	c954 <fwp_main_thread+0x534>  // b.any
    c884:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c888:	d2800000 	mov	x0, #0x0                   	// #0
    c88c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c890:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c894:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c898:	910443ff 	add	sp, sp, #0x110
    c89c:	d65f03c0 	ret
    c8a0:	39414280 	ldrb	w0, [x20, #80]
    c8a4:	3707f040 	tbnz	w0, #0, c6ac <fwp_main_thread+0x28c>
    c8a8:	aa1403e0 	mov	x0, x20
    c8ac:	97ffdad1 	bl	33f0 <fwp_cancel_tree.part.0>
    c8b0:	39414680 	ldrb	w0, [x20, #81]
    c8b4:	17ffff7f 	b	c6b0 <fwp_main_thread+0x290>
    c8b8:	d2800013 	mov	x19, #0x0                   	// #0
    c8bc:	910102b4 	add	x20, x21, #0x40
    c8c0:	f9417680 	ldr	x0, [x20, #744]
    c8c4:	b5ffea80 	cbnz	x0, c614 <fwp_main_thread+0x1f4>
    c8c8:	f9416a80 	ldr	x0, [x20, #720]
    c8cc:	97ffdfa9 	bl	4770 <fwp_mem_free>
    c8d0:	f9016a9f 	str	xzr, [x20, #720]
    c8d4:	f901729f 	str	xzr, [x20, #736]
    c8d8:	f9418a80 	ldr	x0, [x20, #784]
    c8dc:	b40002d3 	cbz	x19, c934 <fwp_main_thread+0x514>
    c8e0:	f900567f 	str	xzr, [x19, #168]
    c8e4:	f9005e7f 	str	xzr, [x19, #184]
    c8e8:	b9030a9f 	str	wzr, [x20, #776]
    c8ec:	eb00027f 	cmp	x19, x0
    c8f0:	54ffe9e0 	b.eq	c62c <fwp_main_thread+0x20c>  // b.none
    c8f4:	f90083f9 	str	x25, [sp, #256]
    c8f8:	97ffd7d2 	bl	2840 <abort@plt>
    c8fc:	f0ffffa0 	adrp	x0, 3000 <fwp_segv+0x10>
    c900:	91328000 	add	x0, x0, #0xca0
    c904:	940001d3 	bl	d050 <atexit>
    c908:	17fffed7 	b	c464 <fwp_main_thread+0x44>
    c90c:	97ffdd3e 	bl	3e04 <fwp_heap_init>
    c910:	17fffed2 	b	c458 <fwp_main_thread+0x38>
    c914:	97fff52f 	bl	9dd0 <f0>
    c918:	f9018260 	str	x0, [x19, #768]
    c91c:	52800021 	mov	w1, #0x1                   	// #1
    c920:	b902fa61 	str	w1, [x19, #760]
    c924:	17fffefc 	b	c514 <fwp_main_thread+0xf4>
    c928:	aa0003e1 	mov	x1, x0
    c92c:	f9002293 	str	x19, [x20, #64]
    c930:	17ffff12 	b	c578 <fwp_main_thread+0x158>
    c934:	b9030a9f 	str	wzr, [x20, #776]
    c938:	b4fff080 	cbz	x0, c748 <fwp_main_thread+0x328>
    c93c:	17ffffee 	b	c8f4 <fwp_main_thread+0x4d4>
    c940:	b0000000 	adrp	x0, d000 <__modti3+0x320>
    c944:	9118e000 	add	x0, x0, #0x638
    c948:	a90f63f7 	stp	x23, x24, [sp, #240]
    c94c:	f90083f9 	str	x25, [sp, #256]
    c950:	97ffdaec 	bl	3500 <fwp_trap>
    c954:	f90083f9 	str	x25, [sp, #256]
    c958:	97ffd7a6 	bl	27f0 <__stack_chk_fail@plt>
    c95c:	d503201f 	nop

000000000000c960 <__divti3>:
    c960:	d503245f 	bti	c
    c964:	d2800004 	mov	x4, #0x0                   	// #0
    c968:	b7f80721 	tbnz	x1, #63, ca4c <__divti3+0xec>
    c96c:	b6f80083 	tbz	x3, #63, c97c <__divti3+0x1c>
    c970:	eb0203e2 	negs	x2, x2
    c974:	aa2403e4 	mvn	x4, x4
    c978:	da0303e3 	ngc	x3, x3
    c97c:	aa0203e6 	mov	x6, x2
    c980:	aa0003e7 	mov	x7, x0
    c984:	aa0103e5 	mov	x5, x1
    c988:	b5000583 	cbnz	x3, ca38 <__divti3+0xd8>
    c98c:	eb01005f 	cmp	x2, x1
    c990:	54000e69 	b.ls	cb5c <__divti3+0x1fc>  // b.plast
    c994:	dac01040 	clz	x0, x2
    c998:	b40000e0 	cbz	x0, c9b4 <__divti3+0x54>
    c99c:	4b0003e1 	neg	w1, w0
    c9a0:	9ac020a5 	lsl	x5, x5, x0
    c9a4:	9ac02046 	lsl	x6, x2, x0
    c9a8:	9ac124e1 	lsr	x1, x7, x1
    c9ac:	aa050025 	orr	x5, x1, x5
    c9b0:	9ac020e7 	lsl	x7, x7, x0
    c9b4:	d360fcc8 	lsr	x8, x6, #32
    c9b8:	92407cc2 	and	x2, x6, #0xffffffff
    c9bc:	9ac808a3 	udiv	x3, x5, x8
    c9c0:	9b089465 	msub	x5, x3, x8, x5
    c9c4:	aa0303e0 	mov	x0, x3
    c9c8:	9b037c41 	mul	x1, x2, x3
    c9cc:	93c780a5 	extr	x5, x5, x7, #32
    c9d0:	eb05003f 	cmp	x1, x5
    c9d4:	540000a9 	b.ls	c9e8 <__divti3+0x88>  // b.plast
    c9d8:	ab0500c5 	adds	x5, x6, x5
    c9dc:	d1000460 	sub	x0, x3, #0x1
    c9e0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c9e4:	540015a8 	b.hi	cc98 <__divti3+0x338>  // b.pmore
    c9e8:	cb0100a5 	sub	x5, x5, x1
    c9ec:	9ac808a3 	udiv	x3, x5, x8
    c9f0:	9b089465 	msub	x5, x3, x8, x5
    c9f4:	aa0303e1 	mov	x1, x3
    c9f8:	9b037c42 	mul	x2, x2, x3
    c9fc:	aa0703e3 	mov	x3, x7
    ca00:	b3607ca3 	bfi	x3, x5, #32, #32
    ca04:	eb03005f 	cmp	x2, x3
    ca08:	540000c9 	b.ls	ca20 <__divti3+0xc0>  // b.plast
    ca0c:	ab0300c3 	adds	x3, x6, x3
    ca10:	d1000425 	sub	x5, x1, #0x1
    ca14:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ca18:	d1000821 	sub	x1, x1, #0x2
    ca1c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ca20:	aa008020 	orr	x0, x1, x0, lsl #32
    ca24:	d2800001 	mov	x1, #0x0                   	// #0
    ca28:	b4000064 	cbz	x4, ca34 <__divti3+0xd4>
    ca2c:	eb0003e0 	negs	x0, x0
    ca30:	da0103e1 	ngc	x1, x1
    ca34:	d65f03c0 	ret
    ca38:	eb01007f 	cmp	x3, x1
    ca3c:	54000109 	b.ls	ca5c <__divti3+0xfc>  // b.plast
    ca40:	d2800001 	mov	x1, #0x0                   	// #0
    ca44:	d2800000 	mov	x0, #0x0                   	// #0
    ca48:	17fffff8 	b	ca28 <__divti3+0xc8>
    ca4c:	eb0003e0 	negs	x0, x0
    ca50:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ca54:	da0103e1 	ngc	x1, x1
    ca58:	17ffffc5 	b	c96c <__divti3+0xc>
    ca5c:	dac01067 	clz	x7, x3
    ca60:	b40010e7 	cbz	x7, cc7c <__divti3+0x31c>
    ca64:	d2800805 	mov	x5, #0x40                  	// #64
    ca68:	cb0700a5 	sub	x5, x5, x7
    ca6c:	9ac72063 	lsl	x3, x3, x7
    ca70:	9ac52448 	lsr	x8, x2, x5
    ca74:	aa030108 	orr	x8, x8, x3
    ca78:	9ac52426 	lsr	x6, x1, x5
    ca7c:	92407d0a 	and	x10, x8, #0xffffffff
    ca80:	d360fd09 	lsr	x9, x8, #32
    ca84:	9ac52403 	lsr	x3, x0, x5
    ca88:	9ac72021 	lsl	x1, x1, x7
    ca8c:	aa010063 	orr	x3, x3, x1
    ca90:	9ac72042 	lsl	x2, x2, x7
    ca94:	9ac908cb 	udiv	x11, x6, x9
    ca98:	9b099965 	msub	x5, x11, x9, x6
    ca9c:	aa0b03e1 	mov	x1, x11
    caa0:	9b0b7d46 	mul	x6, x10, x11
    caa4:	93c380a5 	extr	x5, x5, x3, #32
    caa8:	eb0500df 	cmp	x6, x5
    caac:	540000a9 	b.ls	cac0 <__divti3+0x160>  // b.plast
    cab0:	ab050105 	adds	x5, x8, x5
    cab4:	d1000561 	sub	x1, x11, #0x1
    cab8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cabc:	54000f48 	b.hi	cca4 <__divti3+0x344>  // b.pmore
    cac0:	cb0600a6 	sub	x6, x5, x6
    cac4:	9ac908cb 	udiv	x11, x6, x9
    cac8:	9b099969 	msub	x9, x11, x9, x6
    cacc:	aa0b03e5 	mov	x5, x11
    cad0:	9b0b7d4a 	mul	x10, x10, x11
    cad4:	b3607d23 	bfi	x3, x9, #32, #32
    cad8:	eb03015f 	cmp	x10, x3
    cadc:	540000a9 	b.ls	caf0 <__divti3+0x190>  // b.plast
    cae0:	ab030103 	adds	x3, x8, x3
    cae4:	d1000565 	sub	x5, x11, #0x1
    cae8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    caec:	54000e28 	b.hi	ccb0 <__divti3+0x350>  // b.pmore
    caf0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    caf4:	92407c48 	and	x8, x2, #0xffffffff
    caf8:	2a0503e5 	mov	w5, w5
    cafc:	d360fc42 	lsr	x2, x2, #32
    cb00:	d360fc26 	lsr	x6, x1, #32
    cb04:	cb0a0063 	sub	x3, x3, x10
    cb08:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cb0c:	9b087caa 	mul	x10, x5, x8
    cb10:	9b087cc8 	mul	x8, x6, x8
    cb14:	9b0220a5 	madd	x5, x5, x2, x8
    cb18:	9b027cc6 	mul	x6, x6, x2
    cb1c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cb20:	8b0900c5 	add	x5, x6, x9
    cb24:	eb02011f 	cmp	x8, x2
    cb28:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cb2c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cb30:	eb06007f 	cmp	x3, x6
    cb34:	540000e3 	b.cc	cb50 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cb38:	92407d4a 	and	x10, x10, #0xffffffff
    cb3c:	9ac72000 	lsl	x0, x0, x7
    cb40:	8b028142 	add	x2, x10, x2, lsl #32
    cb44:	eb02001f 	cmp	x0, x2
    cb48:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cb4c:	54000a01 	b.ne	cc8c <__divti3+0x32c>  // b.any
    cb50:	d1000420 	sub	x0, x1, #0x1
    cb54:	d2800001 	mov	x1, #0x0                   	// #0
    cb58:	17ffffb4 	b	ca28 <__divti3+0xc8>
    cb5c:	b5000062 	cbnz	x2, cb68 <__divti3+0x208>
    cb60:	d2800022 	mov	x2, #0x1                   	// #1
    cb64:	9ac30846 	udiv	x6, x2, x3
    cb68:	dac010c8 	clz	x8, x6
    cb6c:	b5000408 	cbnz	x8, cbec <__divti3+0x28c>
    cb70:	d360fcc9 	lsr	x9, x6, #32
    cb74:	92407cc5 	and	x5, x6, #0xffffffff
    cb78:	cb060023 	sub	x3, x1, x6
    cb7c:	d2800021 	mov	x1, #0x1                   	// #1
    cb80:	9ac90868 	udiv	x8, x3, x9
    cb84:	9b098d03 	msub	x3, x8, x9, x3
    cb88:	aa0803e0 	mov	x0, x8
    cb8c:	9b057d02 	mul	x2, x8, x5
    cb90:	93c78063 	extr	x3, x3, x7, #32
    cb94:	eb03005f 	cmp	x2, x3
    cb98:	540000a9 	b.ls	cbac <__divti3+0x24c>  // b.plast
    cb9c:	ab0300c3 	adds	x3, x6, x3
    cba0:	d1000500 	sub	x0, x8, #0x1
    cba4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cba8:	54000968 	b.hi	ccd4 <__divti3+0x374>  // b.pmore
    cbac:	cb020063 	sub	x3, x3, x2
    cbb0:	9ac90862 	udiv	x2, x3, x9
    cbb4:	aa0203e8 	mov	x8, x2
    cbb8:	9b098c42 	msub	x2, x2, x9, x3
    cbbc:	aa0703e3 	mov	x3, x7
    cbc0:	9b057d05 	mul	x5, x8, x5
    cbc4:	b3607c43 	bfi	x3, x2, #32, #32
    cbc8:	eb0300bf 	cmp	x5, x3
    cbcc:	540000c9 	b.ls	cbe4 <__divti3+0x284>  // b.plast
    cbd0:	ab0300c2 	adds	x2, x6, x3
    cbd4:	d1000503 	sub	x3, x8, #0x1
    cbd8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cbdc:	d1000908 	sub	x8, x8, #0x2
    cbe0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cbe4:	aa008100 	orr	x0, x8, x0, lsl #32
    cbe8:	17ffff90 	b	ca28 <__divti3+0xc8>
    cbec:	9ac820c6 	lsl	x6, x6, x8
    cbf0:	d2800803 	mov	x3, #0x40                  	// #64
    cbf4:	cb080063 	sub	x3, x3, x8
    cbf8:	d360fcc9 	lsr	x9, x6, #32
    cbfc:	9ac82027 	lsl	x7, x1, x8
    cc00:	92407cc5 	and	x5, x6, #0xffffffff
    cc04:	9ac32422 	lsr	x2, x1, x3
    cc08:	9ac32403 	lsr	x3, x0, x3
    cc0c:	aa070063 	orr	x3, x3, x7
    cc10:	9ac9084a 	udiv	x10, x2, x9
    cc14:	9ac82007 	lsl	x7, x0, x8
    cc18:	9b098940 	msub	x0, x10, x9, x2
    cc1c:	aa0a03e1 	mov	x1, x10
    cc20:	9b0a7ca2 	mul	x2, x5, x10
    cc24:	93c38000 	extr	x0, x0, x3, #32
    cc28:	eb00005f 	cmp	x2, x0
    cc2c:	540000a9 	b.ls	cc40 <__divti3+0x2e0>  // b.plast
    cc30:	ab0000c0 	adds	x0, x6, x0
    cc34:	d1000541 	sub	x1, x10, #0x1
    cc38:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cc3c:	54000468 	b.hi	ccc8 <__divti3+0x368>  // b.pmore
    cc40:	cb020000 	sub	x0, x0, x2
    cc44:	9ac9080a 	udiv	x10, x0, x9
    cc48:	9b098140 	msub	x0, x10, x9, x0
    cc4c:	aa0a03e2 	mov	x2, x10
    cc50:	9b0a7ca8 	mul	x8, x5, x10
    cc54:	b3607c03 	bfi	x3, x0, #32, #32
    cc58:	eb03011f 	cmp	x8, x3
    cc5c:	540000a9 	b.ls	cc70 <__divti3+0x310>  // b.plast
    cc60:	ab0300c3 	adds	x3, x6, x3
    cc64:	d1000542 	sub	x2, x10, #0x1
    cc68:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cc6c:	54000288 	b.hi	ccbc <__divti3+0x35c>  // b.pmore
    cc70:	cb080063 	sub	x3, x3, x8
    cc74:	aa018041 	orr	x1, x2, x1, lsl #32
    cc78:	17ffffc2 	b	cb80 <__divti3+0x220>
    cc7c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cc80:	d2800001 	mov	x1, #0x0                   	// #0
    cc84:	9a9f87e0 	cset	x0, ls	// ls = plast
    cc88:	17ffff68 	b	ca28 <__divti3+0xc8>
    cc8c:	aa0103e0 	mov	x0, x1
    cc90:	d2800001 	mov	x1, #0x0                   	// #0
    cc94:	17ffff65 	b	ca28 <__divti3+0xc8>
    cc98:	d1000860 	sub	x0, x3, #0x2
    cc9c:	8b0600a5 	add	x5, x5, x6
    cca0:	17ffff52 	b	c9e8 <__divti3+0x88>
    cca4:	d1000961 	sub	x1, x11, #0x2
    cca8:	8b0800a5 	add	x5, x5, x8
    ccac:	17ffff85 	b	cac0 <__divti3+0x160>
    ccb0:	d1000965 	sub	x5, x11, #0x2
    ccb4:	8b080063 	add	x3, x3, x8
    ccb8:	17ffff8e 	b	caf0 <__divti3+0x190>
    ccbc:	d1000942 	sub	x2, x10, #0x2
    ccc0:	8b060063 	add	x3, x3, x6
    ccc4:	17ffffeb 	b	cc70 <__divti3+0x310>
    ccc8:	d1000941 	sub	x1, x10, #0x2
    cccc:	8b060000 	add	x0, x0, x6
    ccd0:	17ffffdc 	b	cc40 <__divti3+0x2e0>
    ccd4:	d1000900 	sub	x0, x8, #0x2
    ccd8:	8b060063 	add	x3, x3, x6
    ccdc:	17ffffb4 	b	cbac <__divti3+0x24c>

000000000000cce0 <__modti3>:
    cce0:	d503245f 	bti	c
    cce4:	d2800004 	mov	x4, #0x0                   	// #0
    cce8:	b6f80081 	tbz	x1, #63, ccf8 <__modti3+0x18>
    ccec:	eb0003e0 	negs	x0, x0
    ccf0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ccf4:	da0103e1 	ngc	x1, x1
    ccf8:	f100007f 	cmp	x3, #0x0
    ccfc:	5400128b 	b.lt	cf4c <__modti3+0x26c>  // b.tstop
    cd00:	aa0003e7 	mov	x7, x0
    cd04:	aa0103e6 	mov	x6, x1
    cd08:	540004e1 	b.ne	cda4 <__modti3+0xc4>  // b.any
    cd0c:	eb02003f 	cmp	x1, x2
    cd10:	54000dc2 	b.cs	cec8 <__modti3+0x1e8>  // b.hs, b.nlast
    cd14:	dac01043 	clz	x3, x2
    cd18:	aa0303e5 	mov	x5, x3
    cd1c:	b40000e3 	cbz	x3, cd38 <__modti3+0x58>
    cd20:	4b0303e6 	neg	w6, w3
    cd24:	9ac32021 	lsl	x1, x1, x3
    cd28:	9ac32042 	lsl	x2, x2, x3
    cd2c:	9ac62406 	lsr	x6, x0, x6
    cd30:	aa0100c6 	orr	x6, x6, x1
    cd34:	9ac32007 	lsl	x7, x0, x3
    cd38:	d360fc40 	lsr	x0, x2, #32
    cd3c:	92407c43 	and	x3, x2, #0xffffffff
    cd40:	9ac008c1 	udiv	x1, x6, x0
    cd44:	9b009826 	msub	x6, x1, x0, x6
    cd48:	9b017c61 	mul	x1, x3, x1
    cd4c:	93c780c6 	extr	x6, x6, x7, #32
    cd50:	eb06003f 	cmp	x1, x6
    cd54:	540000a9 	b.ls	cd68 <__modti3+0x88>  // b.plast
    cd58:	ab060046 	adds	x6, x2, x6
    cd5c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    cd60:	8b0200c8 	add	x8, x6, x2
    cd64:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    cd68:	cb0100c6 	sub	x6, x6, x1
    cd6c:	9ac008c8 	udiv	x8, x6, x0
    cd70:	9b009901 	msub	x1, x8, x0, x6
    cd74:	aa0703e0 	mov	x0, x7
    cd78:	9b087c63 	mul	x3, x3, x8
    cd7c:	b3607c20 	bfi	x0, x1, #32, #32
    cd80:	eb00007f 	cmp	x3, x0
    cd84:	54001088 	b.hi	cf94 <__modti3+0x2b4>  // b.pmore
    cd88:	cb030000 	sub	x0, x0, x3
    cd8c:	9ac52400 	lsr	x0, x0, x5
    cd90:	d2800001 	mov	x1, #0x0                   	// #0
    cd94:	b4000064 	cbz	x4, cda0 <__modti3+0xc0>
    cd98:	eb0003e0 	negs	x0, x0
    cd9c:	da0103e1 	ngc	x1, x1
    cda0:	d65f03c0 	ret
    cda4:	dac01066 	clz	x6, x3
    cda8:	eb03003f 	cmp	x1, x3
    cdac:	54ffff43 	b.cc	cd94 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cdb0:	93407cc5 	sxtw	x5, w6
    cdb4:	d2800808 	mov	x8, #0x40                  	// #64
    cdb8:	cb050108 	sub	x8, x8, x5
    cdbc:	9ac62063 	lsl	x3, x3, x6
    cdc0:	9ac62025 	lsl	x5, x1, x6
    cdc4:	9ac82447 	lsr	x7, x2, x8
    cdc8:	aa0300e7 	orr	x7, x7, x3
    cdcc:	9ac82423 	lsr	x3, x1, x8
    cdd0:	92407cec 	and	x12, x7, #0xffffffff
    cdd4:	d360fcea 	lsr	x10, x7, #32
    cdd8:	9ac82401 	lsr	x1, x0, x8
    cddc:	aa050021 	orr	x1, x1, x5
    cde0:	9ac62042 	lsl	x2, x2, x6
    cde4:	9ac62000 	lsl	x0, x0, x6
    cde8:	9aca086b 	udiv	x11, x3, x10
    cdec:	9b0a8d63 	msub	x3, x11, x10, x3
    cdf0:	aa0b03e5 	mov	x5, x11
    cdf4:	9b0b7d89 	mul	x9, x12, x11
    cdf8:	93c18063 	extr	x3, x3, x1, #32
    cdfc:	eb03013f 	cmp	x9, x3
    ce00:	540000a9 	b.ls	ce14 <__modti3+0x134>  // b.plast
    ce04:	ab0300e3 	adds	x3, x7, x3
    ce08:	d1000565 	sub	x5, x11, #0x1
    ce0c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ce10:	54001168 	b.hi	d03c <__modti3+0x35c>  // b.pmore
    ce14:	cb090063 	sub	x3, x3, x9
    ce18:	9aca086b 	udiv	x11, x3, x10
    ce1c:	9b0a8d6a 	msub	x10, x11, x10, x3
    ce20:	aa0b03e9 	mov	x9, x11
    ce24:	9b0b7d8c 	mul	x12, x12, x11
    ce28:	b3607d41 	bfi	x1, x10, #32, #32
    ce2c:	eb01019f 	cmp	x12, x1
    ce30:	540000a9 	b.ls	ce44 <__modti3+0x164>  // b.plast
    ce34:	ab0100e1 	adds	x1, x7, x1
    ce38:	d1000569 	sub	x9, x11, #0x1
    ce3c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    ce40:	54000f88 	b.hi	d030 <__modti3+0x350>  // b.pmore
    ce44:	aa058123 	orr	x3, x9, x5, lsl #32
    ce48:	92407c4b 	and	x11, x2, #0xffffffff
    ce4c:	2a0903e9 	mov	w9, w9
    ce50:	d360fc4a 	lsr	x10, x2, #32
    ce54:	d360fc63 	lsr	x3, x3, #32
    ce58:	cb0c0021 	sub	x1, x1, x12
    ce5c:	aa0a03ec 	mov	x12, x10
    ce60:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    ce64:	9b0b7d25 	mul	x5, x9, x11
    ce68:	9b0b7c6b 	mul	x11, x3, x11
    ce6c:	9b0a2d29 	madd	x9, x9, x10, x11
    ce70:	92407caa 	and	x10, x5, #0xffffffff
    ce74:	9b0c7c63 	mul	x3, x3, x12
    ce78:	8b458125 	add	x5, x9, x5, lsr #32
    ce7c:	8b0d0069 	add	x9, x3, x13
    ce80:	eb05017f 	cmp	x11, x5
    ce84:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    ce88:	8b058149 	add	x9, x10, x5, lsl #32
    ce8c:	8b458063 	add	x3, x3, x5, lsr #32
    ce90:	eb03003f 	cmp	x1, x3
    ce94:	54000063 	b.cc	cea0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    ce98:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    ce9c:	54000082 	b.cs	ceac <__modti3+0x1cc>  // b.hs, b.nlast
    cea0:	eb020129 	subs	x9, x9, x2
    cea4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    cea8:	cb070063 	sub	x3, x3, x7
    ceac:	eb090000 	subs	x0, x0, x9
    ceb0:	da030021 	sbc	x1, x1, x3
    ceb4:	9ac62400 	lsr	x0, x0, x6
    ceb8:	9ac82028 	lsl	x8, x1, x8
    cebc:	aa000100 	orr	x0, x8, x0
    cec0:	9ac62421 	lsr	x1, x1, x6
    cec4:	17ffffb4 	b	cd94 <__modti3+0xb4>
    cec8:	b5000062 	cbnz	x2, ced4 <__modti3+0x1f4>
    cecc:	d2800023 	mov	x3, #0x1                   	// #1
    ced0:	9ac20862 	udiv	x2, x3, x2
    ced4:	dac01048 	clz	x8, x2
    ced8:	aa0803e5 	mov	x5, x8
    cedc:	b5000668 	cbnz	x8, cfa8 <__modti3+0x2c8>
    cee0:	cb020020 	sub	x0, x1, x2
    cee4:	d360fc49 	lsr	x9, x2, #32
    cee8:	92407c4a 	and	x10, x2, #0xffffffff
    ceec:	9ac90801 	udiv	x1, x0, x9
    cef0:	9b098020 	msub	x0, x1, x9, x0
    cef4:	9b0a7c21 	mul	x1, x1, x10
    cef8:	93c78000 	extr	x0, x0, x7, #32
    cefc:	eb00003f 	cmp	x1, x0
    cf00:	540000a9 	b.ls	cf14 <__modti3+0x234>  // b.plast
    cf04:	ab000040 	adds	x0, x2, x0
    cf08:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cf0c:	8b020003 	add	x3, x0, x2
    cf10:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cf14:	cb010001 	sub	x1, x0, x1
    cf18:	9ac90820 	udiv	x0, x1, x9
    cf1c:	9b098403 	msub	x3, x0, x9, x1
    cf20:	aa0703e1 	mov	x1, x7
    cf24:	9b0a7c00 	mul	x0, x0, x10
    cf28:	b3607c61 	bfi	x1, x3, #32, #32
    cf2c:	eb01001f 	cmp	x0, x1
    cf30:	540000a9 	b.ls	cf44 <__modti3+0x264>  // b.plast
    cf34:	ab010041 	adds	x1, x2, x1
    cf38:	8b020022 	add	x2, x1, x2
    cf3c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cf40:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cf44:	cb000020 	sub	x0, x1, x0
    cf48:	17ffff91 	b	cd8c <__modti3+0xac>
    cf4c:	eb0203e5 	negs	x5, x2
    cf50:	aa0003e7 	mov	x7, x0
    cf54:	da0303e8 	ngc	x8, x3
    cf58:	aa0503e2 	mov	x2, x5
    cf5c:	aa0803e3 	mov	x3, x8
    cf60:	aa0103e6 	mov	x6, x1
    cf64:	b4ffed48 	cbz	x8, cd0c <__modti3+0x2c>
    cf68:	eb01011f 	cmp	x8, x1
    cf6c:	54fff148 	b.hi	cd94 <__modti3+0xb4>  // b.pmore
    cf70:	dac01109 	clz	x9, x8
    cf74:	2a0903e6 	mov	w6, w9
    cf78:	b5fff1c9 	cbnz	x9, cdb0 <__modti3+0xd0>
    cf7c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    cf80:	54000068 	b.hi	cf8c <__modti3+0x2ac>  // b.pmore
    cf84:	eb050007 	subs	x7, x0, x5
    cf88:	da080021 	sbc	x1, x1, x8
    cf8c:	aa0703e0 	mov	x0, x7
    cf90:	17ffff81 	b	cd94 <__modti3+0xb4>
    cf94:	ab000040 	adds	x0, x2, x0
    cf98:	8b020002 	add	x2, x0, x2
    cf9c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    cfa0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    cfa4:	17ffff79 	b	cd88 <__modti3+0xa8>
    cfa8:	9ac82042 	lsl	x2, x2, x8
    cfac:	d2800803 	mov	x3, #0x40                  	// #64
    cfb0:	cb080063 	sub	x3, x3, x8
    cfb4:	d360fc49 	lsr	x9, x2, #32
    cfb8:	9ac82027 	lsl	x7, x1, x8
    cfbc:	92407c4a 	and	x10, x2, #0xffffffff
    cfc0:	9ac32426 	lsr	x6, x1, x3
    cfc4:	9ac32403 	lsr	x3, x0, x3
    cfc8:	aa070063 	orr	x3, x3, x7
    cfcc:	9ac908c1 	udiv	x1, x6, x9
    cfd0:	9ac82007 	lsl	x7, x0, x8
    cfd4:	9b099820 	msub	x0, x1, x9, x6
    cfd8:	9b017d41 	mul	x1, x10, x1
    cfdc:	93c38000 	extr	x0, x0, x3, #32
    cfe0:	eb00003f 	cmp	x1, x0
    cfe4:	540000a9 	b.ls	cff8 <__modti3+0x318>  // b.plast
    cfe8:	ab000040 	adds	x0, x2, x0
    cfec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cff0:	8b020006 	add	x6, x0, x2
    cff4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    cff8:	cb010000 	sub	x0, x0, x1
    cffc:	9ac90801 	udiv	x1, x0, x9
    d000:	9b098026 	msub	x6, x1, x9, x0
    d004:	aa0303e0 	mov	x0, x3
    d008:	9b017d41 	mul	x1, x10, x1
    d00c:	b3607cc0 	bfi	x0, x6, #32, #32
    d010:	eb00003f 	cmp	x1, x0
    d014:	540000a9 	b.ls	d028 <__modti3+0x348>  // b.plast
    d018:	ab000040 	adds	x0, x2, x0
    d01c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d020:	8b020003 	add	x3, x0, x2
    d024:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d028:	cb010000 	sub	x0, x0, x1
    d02c:	17ffffb0 	b	ceec <__modti3+0x20c>
    d030:	d1000969 	sub	x9, x11, #0x2
    d034:	8b070021 	add	x1, x1, x7
    d038:	17ffff83 	b	ce44 <__modti3+0x164>
    d03c:	d1000965 	sub	x5, x11, #0x2
    d040:	8b070063 	add	x3, x3, x7
    d044:	17ffff74 	b	ce14 <__modti3+0x134>
    d048:	d503201f 	nop
    d04c:	d503201f 	nop

000000000000d050 <atexit>:
    d050:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d054:	f0000082 	adrp	x2, 20000 <__data_start>
    d058:	d2800001 	mov	x1, #0x0                   	// #0
    d05c:	910003fd 	mov	x29, sp
    d060:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d064:	f9400442 	ldr	x2, [x2, #8]
    d068:	17ffd5a2 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d06c <_fini>:
    d06c:	d503201f 	nop
    d070:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d074:	910003fd 	mov	x29, sp
    d078:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d07c:	d65f03c0 	ret
