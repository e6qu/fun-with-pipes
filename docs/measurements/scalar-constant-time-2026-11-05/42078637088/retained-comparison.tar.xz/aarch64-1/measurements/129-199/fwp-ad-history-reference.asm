
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <__modti3+0x230>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	910dc0a5 	add	x5, x5, #0x370
    2a20:	f0000044 	adrp	x4, d000 <__modti3+0x230>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	910de084 	add	x4, x4, #0x378
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940002ac 	bl	3500 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91010261 	add	x1, x19, #0x40
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xed48>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9001c20 	str	x0, [x1, #56]
    2aac:	940002f5 	bl	3680 <fwp_now_ns>
    2ab0:	f0000040 	adrp	x0, d000 <__modti3+0x230>
    2ab4:	911d4000 	add	x0, x0, #0x750
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x2160>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91144042 	add	x2, x2, #0x510
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91010273 	add	x19, x19, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9432a60 	ldr	w0, [x19, #808]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff44 	bl	28e0 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	f0000040 	adrp	x0, d000 <__modti3+0x230>
    2bfc:	911d8000 	add	x0, x0, #0x760
    2c00:	94000240 	bl	3500 <fwp_trap>
    2c04:	97fffefb 	bl	27f0 <__stack_chk_fail@plt>
    2c08:	f0000040 	adrp	x0, d000 <__modti3+0x230>
    2c0c:	91200000 	add	x0, x0, #0x800
    2c10:	9400023c 	bl	3500 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffee2 	bl	27a0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	f0000040 	adrp	x0, d000 <__modti3+0x230>
    2c24:	911f6000 	add	x0, x0, #0x7d8
    2c28:	94000236 	bl	3500 <fwp_trap>
    2c2c:	f0000040 	adrp	x0, d000 <__modti3+0x230>
    2c30:	911ea000 	add	x0, x0, #0x7a8
    2c34:	94000233 	bl	3500 <fwp_trap>
    2c38:	f0000040 	adrp	x0, d000 <__modti3+0x230>
    2c3c:	911e0000 	add	x0, x0, #0x780
    2c40:	94000230 	bl	3500 <fwp_trap>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	f0000041 	adrp	x1, d000 <__modti3+0x230>
    2e34:	91380021 	add	x1, x1, #0xe00
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	f0000040 	adrp	x0, d000 <__modti3+0x230>
    2fd0:	9105e000 	add	x0, x0, #0x178
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	d0000041 	adrp	x1, d000 <__modti3+0x230>
    3098:	91378021 	add	x1, x1, #0xde0
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    30c4:	9115c2a1 	add	x1, x21, #0x570
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa90>
    30d8:	912580a5 	add	x5, x5, #0x960
    30dc:	9115c2a1 	add	x1, x21, #0x570
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	9115c2b7 	add	x23, x21, #0x570
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	9115c2b5 	add	x21, x21, #0x570
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	9115c2b5 	add	x21, x21, #0x570
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa90>
    3268:	912560a5 	add	x5, x5, #0x958
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	d0000040 	adrp	x0, d000 <__modti3+0x230>
    3370:	9105e000 	add	x0, x0, #0x178
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	d0000041 	adrp	x1, d000 <__modti3+0x230>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	91064021 	add	x1, x1, #0x190
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	d0000041 	adrp	x1, d000 <__modti3+0x230>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	91066021 	add	x1, x1, #0x198
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	d0000041 	adrp	x1, d000 <__modti3+0x230>
    34e0:	91068021 	add	x1, x1, #0x1a0
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_trap>:
    3500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3504:	d53bd041 	mrs	x1, tpidr_el0
    3508:	91400021 	add	x1, x1, #0x0, lsl #12
    350c:	91004021 	add	x1, x1, #0x10
    3510:	910003fd 	mov	x29, sp
    3514:	a90153f3 	stp	x19, x20, [sp, #16]
    3518:	aa0003f3 	mov	x19, x0
    351c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3520:	f947ea94 	ldr	x20, [x20, #4048]
    3524:	f90013f5 	str	x21, [sp, #32]
    3528:	f9400035 	ldr	x21, [x1]
    352c:	97fffe91 	bl	2f70 <fwp_flush>
    3530:	f9400280 	ldr	x0, [x20]
    3534:	d0000042 	adrp	x2, d000 <__modti3+0x230>
    3538:	aa1303e3 	mov	x3, x19
    353c:	9106a042 	add	x2, x2, #0x1a8
    3540:	52800041 	mov	w1, #0x2                   	// #2
    3544:	97fffcc7 	bl	2860 <__fprintf_chk@plt>
    3548:	b40000b5 	cbz	x21, 355c <fwp_trap+0x5c>
    354c:	f9400280 	ldr	x0, [x20]
    3550:	97fffcf4 	bl	2920 <fflush@plt>
    3554:	52800ca0 	mov	w0, #0x65                  	// #101
    3558:	97fffd02 	bl	2960 <_Exit@plt>
    355c:	52800ca0 	mov	w0, #0x65                  	// #101
    3560:	97fffc50 	bl	26a0 <exit@plt>

0000000000003564 <fwp_closure_drop_push>:
    3564:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3568:	910003fd 	mov	x29, sp
    356c:	a90153f3 	stp	x19, x20, [sp, #16]
    3570:	aa0003f3 	mov	x19, x0
    3574:	a9408014 	ldp	x20, x0, [x0, #8]
    3578:	a9025bf5 	stp	x21, x22, [sp, #32]
    357c:	aa0103f5 	mov	x21, x1
    3580:	a90363f7 	stp	x23, x24, [sp, #48]
    3584:	eb00029f 	cmp	x20, x0
    3588:	54000160 	b.eq	35b4 <fwp_closure_drop_push+0x50>  // b.none
    358c:	f9400276 	ldr	x22, [x19]
    3590:	d37df297 	lsl	x23, x20, #3
    3594:	91000694 	add	x20, x20, #0x1
    3598:	f9000674 	str	x20, [x19, #8]
    359c:	a94153f3 	ldp	x19, x20, [sp, #16]
    35a0:	f8376ad5 	str	x21, [x22, x23]
    35a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    35ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    35b0:	d65f03c0 	ret
    35b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    35b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    35bc:	eb00029f 	cmp	x20, x0
    35c0:	54000568 	b.hi	366c <fwp_closure_drop_push+0x108>  // b.pmore
    35c4:	d37cee99 	lsl	x25, x20, #4
    35c8:	d37ffa9a 	lsl	x26, x20, #1
    35cc:	aa1903e0 	mov	x0, x25
    35d0:	97fffc70 	bl	2790 <malloc@plt>
    35d4:	aa0003f6 	mov	x22, x0
    35d8:	b4000320 	cbz	x0, 363c <fwp_closure_drop_push+0xd8>
    35dc:	aa1303f8 	mov	x24, x19
    35e0:	aa1903e3 	mov	x3, x25
    35e4:	d37df297 	lsl	x23, x20, #3
    35e8:	aa1703e2 	mov	x2, x23
    35ec:	f8418719 	ldr	x25, [x24], #24
    35f0:	aa1903e1 	mov	x1, x25
    35f4:	97fffc53 	bl	2740 <__memcpy_chk@plt>
    35f8:	eb18033f 	cmp	x25, x24
    35fc:	540000a0 	b.eq	3610 <fwp_closure_drop_push+0xac>  // b.none
    3600:	aa1903e0 	mov	x0, x25
    3604:	97fffcab 	bl	28b0 <free@plt>
    3608:	f9400674 	ldr	x20, [x19, #8]
    360c:	d37df297 	lsl	x23, x20, #3
    3610:	91000694 	add	x20, x20, #0x1
    3614:	f9000276 	str	x22, [x19]
    3618:	f9000a7a 	str	x26, [x19, #16]
    361c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3620:	f9000674 	str	x20, [x19, #8]
    3624:	f8376ad5 	str	x21, [x22, x23]
    3628:	a94153f3 	ldp	x19, x20, [sp, #16]
    362c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3630:	a94363f7 	ldp	x23, x24, [sp, #48]
    3634:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3638:	d65f03c0 	ret
    363c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3640:	f947e863 	ldr	x3, [x3, #4048]
    3644:	d2800262 	mov	x2, #0x13                  	// #19
    3648:	d2800021 	mov	x1, #0x1                   	// #1
    364c:	d0000040 	adrp	x0, d000 <__modti3+0x230>
    3650:	9105e000 	add	x0, x0, #0x178
    3654:	f9400063 	ldr	x3, [x3]
    3658:	97fffca6 	bl	28f0 <fwrite@plt>
    365c:	d2800000 	mov	x0, #0x0                   	// #0
    3660:	97fffcb0 	bl	2920 <fflush@plt>
    3664:	52800cc0 	mov	w0, #0x66                  	// #102
    3668:	97fffcbe 	bl	2960 <_Exit@plt>
    366c:	d0000040 	adrp	x0, d000 <__modti3+0x230>
    3670:	9106e000 	add	x0, x0, #0x1b8
    3674:	97ffffa3 	bl	3500 <fwp_trap>
    3678:	d503201f 	nop
    367c:	d503201f 	nop

0000000000003680 <fwp_now_ns>:
    3680:	d100c3ff 	sub	sp, sp, #0x30
    3684:	52800020 	mov	w0, #0x1                   	// #1
    3688:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    368c:	f947f442 	ldr	x2, [x2, #4072]
    3690:	910023e1 	add	x1, sp, #0x8
    3694:	a9027bfd 	stp	x29, x30, [sp, #32]
    3698:	910083fd 	add	x29, sp, #0x20
    369c:	f9400043 	ldr	x3, [x2]
    36a0:	f9000fe3 	str	x3, [sp, #24]
    36a4:	d2800003 	mov	x3, #0x0                   	// #0
    36a8:	97fffc1e 	bl	2720 <clock_gettime@plt>
    36ac:	350002c0 	cbnz	w0, 3704 <fwp_now_ns+0x84>
    36b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    36b4:	d2994003 	mov	x3, #0xca00                	// #51712
    36b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    36bc:	9b037c20 	mul	x0, x1, x3
    36c0:	9b437c21 	smulh	x1, x1, x3
    36c4:	ab020000 	adds	x0, x0, x2
    36c8:	937ffc42 	asr	x2, x2, #63
    36cc:	9a020021 	adc	x1, x1, x2
    36d0:	f100001f 	cmp	x0, #0x0
    36d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    36d8:	b50001e1 	cbnz	x1, 3714 <fwp_now_ns+0x94>
    36dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    36e0:	f947f421 	ldr	x1, [x1, #4072]
    36e4:	f9400fe3 	ldr	x3, [sp, #24]
    36e8:	f9400022 	ldr	x2, [x1]
    36ec:	eb020063 	subs	x3, x3, x2
    36f0:	d2800002 	mov	x2, #0x0                   	// #0
    36f4:	540000e1 	b.ne	3710 <fwp_now_ns+0x90>  // b.any
    36f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36fc:	9100c3ff 	add	sp, sp, #0x30
    3700:	d65f03c0 	ret
    3704:	d0000040 	adrp	x0, d000 <__modti3+0x230>
    3708:	91076000 	add	x0, x0, #0x1d8
    370c:	97ffff7d 	bl	3500 <fwp_trap>
    3710:	97fffc38 	bl	27f0 <__stack_chk_fail@plt>
    3714:	d0000040 	adrp	x0, d000 <__modti3+0x230>
    3718:	9107e000 	add	x0, x0, #0x1f8
    371c:	97ffff79 	bl	3500 <fwp_trap>

0000000000003720 <fwp_closure_drop.part.0>:
    3720:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3724:	d0000041 	adrp	x1, d000 <__modti3+0x230>
    3728:	910003fd 	mov	x29, sp
    372c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3730:	f947f463 	ldr	x3, [x3, #4072]
    3734:	a90153f3 	stp	x19, x20, [sp, #16]
    3738:	d10883ff 	sub	sp, sp, #0x220
    373c:	910003e2 	mov	x2, sp
    3740:	d53bd053 	mrs	x19, tpidr_el0
    3744:	910063f4 	add	x20, sp, #0x18
    3748:	3dc38420 	ldr	q0, [x1, #3600]
    374c:	91400264 	add	x4, x19, #0x0, lsl #12
    3750:	91004084 	add	x4, x4, #0x10
    3754:	aa0003e1 	mov	x1, x0
    3758:	aa0203e0 	mov	x0, x2
    375c:	f9400062 	ldr	x2, [x3]
    3760:	f9010fe2 	str	x2, [sp, #536]
    3764:	d2800002 	mov	x2, #0x0                   	// #0
    3768:	f90003f4 	str	x20, [sp]
    376c:	f9000080 	str	x0, [x4]
    3770:	3c8083e0 	stur	q0, [sp, #8]
    3774:	97ffff7c 	bl	3564 <fwp_closure_drop_push>
    3778:	f94007e0 	ldr	x0, [sp, #8]
    377c:	b4000280 	cbz	x0, 37cc <fwp_closure_drop.part.0+0xac>
    3780:	f90123f5 	str	x21, [sp, #576]
    3784:	b00000f5 	adrp	x21, 20000 <__data_start>
    3788:	910102b5 	add	x21, x21, #0x40
    378c:	d503201f 	nop
    3790:	f94003e1 	ldr	x1, [sp]
    3794:	d1000400 	sub	x0, x0, #0x1
    3798:	f90007e0 	str	x0, [sp, #8]
    379c:	f9401ea2 	ldr	x2, [x21, #56]
    37a0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    37a4:	b9400001 	ldr	w1, [x0]
    37a8:	8b011441 	add	x1, x2, x1, lsl #5
    37ac:	f9400c21 	ldr	x1, [x1, #24]
    37b0:	b4000321 	cbz	x1, 3814 <fwp_closure_drop.part.0+0xf4>
    37b4:	f9400422 	ldr	x2, [x1, #8]
    37b8:	52800001 	mov	w1, #0x0                   	// #0
    37bc:	d63f0040 	blr	x2
    37c0:	f94007e0 	ldr	x0, [sp, #8]
    37c4:	b5fffe60 	cbnz	x0, 3790 <fwp_closure_drop.part.0+0x70>
    37c8:	f94123f5 	ldr	x21, [sp, #576]
    37cc:	91400273 	add	x19, x19, #0x0, lsl #12
    37d0:	91004273 	add	x19, x19, #0x10
    37d4:	f94003e0 	ldr	x0, [sp]
    37d8:	f900027f 	str	xzr, [x19]
    37dc:	eb14001f 	cmp	x0, x20
    37e0:	54000040 	b.eq	37e8 <fwp_closure_drop.part.0+0xc8>  // b.none
    37e4:	97fffc33 	bl	28b0 <free@plt>
    37e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    37ec:	f947f400 	ldr	x0, [x0, #4072]
    37f0:	f9410fe2 	ldr	x2, [sp, #536]
    37f4:	f9400001 	ldr	x1, [x0]
    37f8:	eb010042 	subs	x2, x2, x1
    37fc:	d2800001 	mov	x1, #0x0                   	// #0
    3800:	54000101 	b.ne	3820 <fwp_closure_drop.part.0+0x100>  // b.any
    3804:	910883ff 	add	sp, sp, #0x220
    3808:	a94153f3 	ldp	x19, x20, [sp, #16]
    380c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3810:	d65f03c0 	ret
    3814:	d0000040 	adrp	x0, d000 <__modti3+0x230>
    3818:	91088000 	add	x0, x0, #0x220
    381c:	97ffff39 	bl	3500 <fwp_trap>
    3820:	f90123f5 	str	x21, [sp, #576]
    3824:	97fffbf3 	bl	27f0 <__stack_chk_fail@plt>
    3828:	d503201f 	nop
    382c:	d503201f 	nop

0000000000003830 <fwp_tape_of>:
    3830:	92403c02 	and	x2, x0, #0xffff
    3834:	b4000262 	cbz	x2, 3880 <fwp_tape_of+0x50>
    3838:	9350fc01 	asr	x1, x0, #16
    383c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3840:	d1000440 	sub	x0, x2, #0x1
    3844:	91010062 	add	x2, x3, #0x40
    3848:	f9402042 	ldr	x2, [x2, #64]
    384c:	eb00005f 	cmp	x2, x0
    3850:	5400018d 	b.le	3880 <fwp_tape_of+0x50>
    3854:	8b000402 	add	x2, x0, x0, lsl #1
    3858:	f9402063 	ldr	x3, [x3, #64]
    385c:	8b020802 	add	x2, x0, x2, lsl #2
    3860:	d37df042 	lsl	x2, x2, #3
    3864:	8b020060 	add	x0, x3, x2
    3868:	b9400404 	ldr	w4, [x0, #4]
    386c:	340000a4 	cbz	w4, 3880 <fwp_tape_of+0x50>
    3870:	b8626862 	ldr	w2, [x3, x2]
    3874:	6b01005f 	cmp	w2, w1
    3878:	54000041 	b.ne	3880 <fwp_tape_of+0x50>  // b.any
    387c:	d65f03c0 	ret
    3880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3884:	d0000040 	adrp	x0, d000 <__modti3+0x230>
    3888:	91094000 	add	x0, x0, #0x250
    388c:	910003fd 	mov	x29, sp
    3890:	97ffff1c 	bl	3500 <fwp_trap>

0000000000003894 <fwp_format_g.constprop.0>:
    3894:	d10483ff 	sub	sp, sp, #0x120
    3898:	d0000044 	adrp	x4, d000 <__modti3+0x230>
    389c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    38a0:	f947f442 	ldr	x2, [x2, #4072]
    38a4:	910a8084 	add	x4, x4, #0x2a0
    38a8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    38ac:	9102c3fd 	add	x29, sp, #0xb0
    38b0:	d2800803 	mov	x3, #0x40                  	// #64
    38b4:	a90e63f7 	stp	x23, x24, [sp, #224]
    38b8:	93407c38 	sxtw	x24, w1
    38bc:	aa0303e1 	mov	x1, x3
    38c0:	fd008be8 	str	d8, [sp, #272]
    38c4:	1e604008 	fmov	d8, d0
    38c8:	a90c53f3 	stp	x19, x20, [sp, #192]
    38cc:	910083f4 	add	x20, sp, #0x20
    38d0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38d4:	aa0003f5 	mov	x21, x0
    38d8:	a91073fb 	stp	x27, x28, [sp, #256]
    38dc:	5100071c 	sub	w28, w24, #0x1
    38e0:	2a1c03e5 	mov	w5, w28
    38e4:	f9400040 	ldr	x0, [x2]
    38e8:	f90057e0 	str	x0, [sp, #168]
    38ec:	d2800000 	mov	x0, #0x0                   	// #0
    38f0:	52800042 	mov	w2, #0x2                   	// #2
    38f4:	aa1403e0 	mov	x0, x20
    38f8:	97fffb9a 	bl	2760 <__snprintf_chk@plt>
    38fc:	52800ca1 	mov	w1, #0x65                  	// #101
    3900:	aa1403e0 	mov	x0, x20
    3904:	97fffbf3 	bl	28d0 <strchr@plt>
    3908:	aa0003f3 	mov	x19, x0
    390c:	52800142 	mov	w2, #0xa                   	// #10
    3910:	91000400 	add	x0, x0, #0x1
    3914:	d2800001 	mov	x1, #0x0                   	// #0
    3918:	97fffbde 	bl	2890 <strtol@plt>
    391c:	aa0003f7 	mov	x23, x0
    3920:	11001400 	add	w0, w0, #0x5
    3924:	7100541f 	cmp	w0, #0x15
    3928:	54000d88 	b.hi	3ad8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    392c:	4b170385 	sub	w5, w28, w23
    3930:	710000bf 	cmp	w5, #0x0
    3934:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3938:	54000ba0 	b.eq	3aac <fwp_format_g.constprop.0+0x218>  // b.none
    393c:	394083e0 	ldrb	w0, [sp, #32]
    3940:	cb180273 	sub	x19, x19, x24
    3944:	91000673 	add	x19, x19, #0x1
    3948:	a90f6bf9 	stp	x25, x26, [sp, #240]
    394c:	7100b41f 	cmp	w0, #0x2d
    3950:	9a941681 	cinc	x1, x20, eq	// eq = none
    3954:	1a9f17e4 	cset	w4, eq	// eq = none
    3958:	cb010266 	sub	x6, x19, x1
    395c:	d10004da 	sub	x26, x6, #0x1
    3960:	540018c0 	b.eq	3c78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d280091b 	mov	x27, #0x48                  	// #72
    396c:	aa1903e7 	mov	x7, x25
    3970:	91000423 	add	x3, x1, #0x1
    3974:	91011cc6 	add	x6, x6, #0x47
    3978:	910004f6 	add	x22, x7, #0x1
    397c:	37f81017 	tbnz	w23, #31, 3b7c <fwp_format_g.constprop.0+0x2e8>
    3980:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3984:	93407ef7 	sxtw	x23, w23
    3988:	390000e4 	strb	w4, [x7]
    398c:	aa1303e1 	mov	x1, x19
    3990:	aa1703e2 	mov	x2, x23
    3994:	aa1603e0 	mov	x0, x22
    3998:	b9000be5 	str	w5, [sp, #8]
    399c:	cb170374 	sub	x20, x27, x23
    39a0:	a9011be3 	stp	x3, x6, [sp, #16]
    39a4:	97fffb27 	bl	2640 <memcpy@plt>
    39a8:	d1000694 	sub	x20, x20, #0x1
    39ac:	f9400be3 	ldr	x3, [sp, #16]
    39b0:	8b1702d6 	add	x22, x22, x23
    39b4:	aa1603e0 	mov	x0, x22
    39b8:	aa1a03e2 	mov	x2, x26
    39bc:	aa0303e1 	mov	x1, x3
    39c0:	aa1403e3 	mov	x3, x20
    39c4:	97fffb5f 	bl	2740 <__memcpy_chk@plt>
    39c8:	8b1a02d6 	add	x22, x22, x26
    39cc:	f9400fe6 	ldr	x6, [sp, #24]
    39d0:	d2800900 	mov	x0, #0x48                  	// #72
    39d4:	b9400be5 	ldr	w5, [sp, #8]
    39d8:	8b170261 	add	x1, x19, x23
    39dc:	cb1400c3 	sub	x3, x6, x20
    39e0:	cb060294 	sub	x20, x20, x6
    39e4:	f101207f 	cmp	x3, #0x48
    39e8:	93407cb8 	sxtw	x24, w5
    39ec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39f0:	aa1803e2 	mov	x2, x24
    39f4:	8b1802d3 	add	x19, x22, x24
    39f8:	8b140063 	add	x3, x3, x20
    39fc:	aa1603e0 	mov	x0, x22
    3a00:	97fffb50 	bl	2740 <__memcpy_chk@plt>
    3a04:	cb190273 	sub	x19, x19, x25
    3a08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a0c:	eb00027f 	cmp	x19, x0
    3a10:	aa1903e1 	mov	x1, x25
    3a14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	aa1303e2 	mov	x2, x19
    3a20:	97fffb08 	bl	2640 <memcpy@plt>
    3a24:	38336abf 	strb	wzr, [x21, x19]
    3a28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a2c:	aa1503e0 	mov	x0, x21
    3a30:	97fffb14 	bl	2680 <strlen@plt>
    3a34:	aa0003f3 	mov	x19, x0
    3a38:	528005c1 	mov	w1, #0x2e                  	// #46
    3a3c:	aa1503e0 	mov	x0, x21
    3a40:	97fffba4 	bl	28d0 <strchr@plt>
    3a44:	b4000160 	cbz	x0, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a48:	b4000153 	cbz	x19, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a4c:	d503201f 	nop
    3a50:	aa1303e1 	mov	x1, x19
    3a54:	d1000673 	sub	x19, x19, #0x1
    3a58:	38736aa0 	ldrb	w0, [x21, x19]
    3a5c:	7100c01f 	cmp	w0, #0x30
    3a60:	54001001 	b.ne	3c60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3a64:	38336abf 	strb	wzr, [x21, x19]
    3a68:	b5ffff53 	cbnz	x19, 3a50 <fwp_format_g.constprop.0+0x1bc>
    3a6c:	d503201f 	nop
    3a70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a74:	f947f400 	ldr	x0, [x0, #4072]
    3a78:	f94057e2 	ldr	x2, [sp, #168]
    3a7c:	f9400001 	ldr	x1, [x0]
    3a80:	eb010042 	subs	x2, x2, x1
    3a84:	d2800001 	mov	x1, #0x0                   	// #0
    3a88:	54001061 	b.ne	3c94 <fwp_format_g.constprop.0+0x400>  // b.any
    3a8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3aa0:	fd408be8 	ldr	d8, [sp, #272]
    3aa4:	910483ff 	add	sp, sp, #0x120
    3aa8:	d65f03c0 	ret
    3aac:	1e604100 	fmov	d0, d8
    3ab0:	710000bf 	cmp	w5, #0x0
    3ab4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	d0000044 	adrp	x4, d000 <__modti3+0x230>
    3ac0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ac4:	910ae084 	add	x4, x4, #0x2b8
    3ac8:	52800042 	mov	w2, #0x2                   	// #2
    3acc:	d2803201 	mov	x1, #0x190                 	// #400
    3ad0:	97fffb24 	bl	2760 <__snprintf_chk@plt>
    3ad4:	17ffffd6 	b	3a2c <fwp_format_g.constprop.0+0x198>
    3ad8:	cb140273 	sub	x19, x19, x20
    3adc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ae0:	910183f9 	add	x25, sp, #0x60
    3ae4:	aa1303e2 	mov	x2, x19
    3ae8:	aa1403e1 	mov	x1, x20
    3aec:	aa1903e0 	mov	x0, x25
    3af0:	d2800803 	mov	x3, #0x40                  	// #64
    3af4:	97fffb13 	bl	2740 <__memcpy_chk@plt>
    3af8:	38336b3f 	strb	wzr, [x25, x19]
    3afc:	aa1903e0 	mov	x0, x25
    3b00:	528005c1 	mov	w1, #0x2e                  	// #46
    3b04:	97fffb73 	bl	28d0 <strchr@plt>
    3b08:	b40001c0 	cbz	x0, 3b40 <fwp_format_g.constprop.0+0x2ac>
    3b0c:	b50000b3 	cbnz	x19, 3b20 <fwp_format_g.constprop.0+0x28c>
    3b10:	1400000c 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3b14:	381ff01f 	sturb	wzr, [x0, #-1]
    3b18:	f1000673 	subs	x19, x19, #0x1
    3b1c:	54000120 	b.eq	3b40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3b20:	8b130320 	add	x0, x25, x19
    3b24:	385ff001 	ldurb	w1, [x0, #-1]
    3b28:	7100c03f 	cmp	w1, #0x30
    3b2c:	54ffff40 	b.eq	3b14 <fwp_format_g.constprop.0+0x280>  // b.none
    3b30:	d1000673 	sub	x19, x19, #0x1
    3b34:	38736b20 	ldrb	w0, [x25, x19]
    3b38:	7100b81f 	cmp	w0, #0x2e
    3b3c:	54000a80 	b.eq	3c8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3b40:	710002ff 	cmp	w23, #0x0
    3b44:	528005a1 	mov	w1, #0x2d                  	// #45
    3b48:	aa1903e5 	mov	x5, x25
    3b4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b50:	aa1503e0 	mov	x0, x21
    3b54:	52800566 	mov	w6, #0x2b                  	// #43
    3b58:	d0000044 	adrp	x4, d000 <__modti3+0x230>
    3b5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b60:	910aa084 	add	x4, x4, #0x2a8
    3b64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b68:	52800042 	mov	w2, #0x2                   	// #2
    3b6c:	d2803201 	mov	x1, #0x190                 	// #400
    3b70:	97fffafc 	bl	2760 <__snprintf_chk@plt>
    3b74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b78:	17ffffbe 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3b7c:	52800605 	mov	w5, #0x30                  	// #48
    3b80:	390000e5 	strb	w5, [x7]
    3b84:	d100077b 	sub	x27, x27, #0x1
    3b88:	aa0303e1 	mov	x1, x3
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	aa1b03e3 	mov	x3, x27
    3b94:	aa1a03e2 	mov	x2, x26
    3b98:	f90007e6 	str	x6, [sp, #8]
    3b9c:	b90013e4 	str	w4, [sp, #16]
    3ba0:	8b1a02d6 	add	x22, x22, x26
    3ba4:	b9001be5 	str	w5, [sp, #24]
    3ba8:	97fffae6 	bl	2740 <__memcpy_chk@plt>
    3bac:	f94007e6 	ldr	x6, [sp, #8]
    3bb0:	2a3703e7 	mvn	w7, w23
    3bb4:	b94013e4 	ldr	w4, [sp, #16]
    3bb8:	cb1b00c1 	sub	x1, x6, x27
    3bbc:	cb06037b 	sub	x27, x27, x6
    3bc0:	f101203f 	cmp	x1, #0x48
    3bc4:	d2800906 	mov	x6, #0x48                  	// #72
    3bc8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bcc:	8b1b0023 	add	x3, x1, x27
    3bd0:	310006ff 	cmn	w23, #0x1
    3bd4:	54000220 	b.eq	3c18 <fwp_format_g.constprop.0+0x384>  // b.none
    3bd8:	b9401be5 	ldr	w5, [sp, #24]
    3bdc:	d2800001 	mov	x1, #0x0                   	// #0
    3be0:	f101207f 	cmp	x3, #0x48
    3be4:	d1000462 	sub	x2, x3, #0x1
    3be8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bec:	38216ac5 	strb	w5, [x22, x1]
    3bf0:	cb030003 	sub	x3, x0, x3
    3bf4:	91000421 	add	x1, x1, #0x1
    3bf8:	91000463 	add	x3, x3, #0x1
    3bfc:	eb00007f 	cmp	x3, x0
    3c00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c04:	cb000063 	sub	x3, x3, x0
    3c08:	8b020063 	add	x3, x3, x2
    3c0c:	6b0100ff 	cmp	w7, w1
    3c10:	54fffe8c 	b.gt	3be0 <fwp_format_g.constprop.0+0x34c>
    3c14:	8b2742d6 	add	x22, x22, w7, uxtw
    3c18:	f101207f 	cmp	x3, #0x48
    3c1c:	d2800905 	mov	x5, #0x48                  	// #72
    3c20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c24:	aa1603e0 	mov	x0, x22
    3c28:	cb0300a1 	sub	x1, x5, x3
    3c2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c30:	91000421 	add	x1, x1, #0x1
    3c34:	d1000463 	sub	x3, x3, #0x1
    3c38:	eb05003f 	cmp	x1, x5
    3c3c:	38001402 	strb	w2, [x0], #1
    3c40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c44:	93407f82 	sxtw	x2, w28
    3c48:	cb050025 	sub	x5, x1, x5
    3c4c:	aa1303e1 	mov	x1, x19
    3c50:	8b0300a3 	add	x3, x5, x3
    3c54:	8b1802d3 	add	x19, x22, x24
    3c58:	97fffaba 	bl	2740 <__memcpy_chk@plt>
    3c5c:	17ffff6a 	b	3a04 <fwp_format_g.constprop.0+0x170>
    3c60:	d1000421 	sub	x1, x1, #0x1
    3c64:	38616aa0 	ldrb	w0, [x21, x1]
    3c68:	7100b81f 	cmp	w0, #0x2e
    3c6c:	54fff021 	b.ne	3a70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3c70:	38216abf 	strb	wzr, [x21, x1]
    3c74:	17ffff7f 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3c78:	910187e7 	add	x7, sp, #0x61
    3c7c:	910183f9 	add	x25, sp, #0x60
    3c80:	d28008fb 	mov	x27, #0x47                  	// #71
    3c84:	390183e0 	strb	w0, [sp, #96]
    3c88:	17ffff3a 	b	3970 <fwp_format_g.constprop.0+0xdc>
    3c8c:	38336b3f 	strb	wzr, [x25, x19]
    3c90:	17ffffac 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3c94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c98:	97fffad6 	bl	27f0 <__stack_chk_fail@plt>
    3c9c:	d503201f 	nop

0000000000003ca0 <fwp_heap_report>:
    3ca0:	d105c3ff 	sub	sp, sp, #0x170
    3ca4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    3ca8:	9115c042 	add	x2, x2, #0x570
    3cac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3cb0:	f947e821 	ldr	x1, [x1, #4048]
    3cb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3cb8:	910443fd 	add	x29, sp, #0x110
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3ccc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3cdc:	f9400036 	ldr	x22, [x1]
    3ce0:	f9400001 	ldr	x1, [x0]
    3ce4:	f90087e1 	str	x1, [sp, #264]
    3ce8:	d2800001 	mov	x1, #0x0                   	// #0
    3cec:	f949e459 	ldr	x25, [x2, #5064]
    3cf0:	d0000041 	adrp	x1, d000 <__modti3+0x230>
    3cf4:	f94a1057 	ldr	x23, [x2, #5152]
    3cf8:	d0000040 	adrp	x0, d000 <__modti3+0x230>
    3cfc:	f94a1458 	ldr	x24, [x2, #5160]
    3d00:	910b0021 	add	x1, x1, #0x2c0
    3d04:	910b2000 	add	x0, x0, #0x2c8
    3d08:	97fffa9e 	bl	2780 <fopen@plt>
    3d0c:	b4000740 	cbz	x0, 3df4 <fwp_heap_report+0x154>
    3d10:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d14:	a91253f3 	stp	x19, x20, [sp, #288]
    3d18:	aa0003f4 	mov	x20, x0
    3d1c:	910023f3 	add	x19, sp, #0x8
    3d20:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d24:	72aae915 	movk	w21, #0x5748, lsl #16
    3d28:	aa1403e2 	mov	x2, x20
    3d2c:	aa1303e0 	mov	x0, x19
    3d30:	52802001 	mov	w1, #0x100                 	// #256
    3d34:	97fffb1f 	bl	29b0 <fgets@plt>
    3d38:	b4000280 	cbz	x0, 3d88 <fwp_heap_report+0xe8>
    3d3c:	b9400261 	ldr	w1, [x19]
    3d40:	6b15003f 	cmp	w1, w21
    3d44:	54ffff21 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d48:	39401260 	ldrb	w0, [x19, #4]
    3d4c:	7101341f 	cmp	w0, #0x4d
    3d50:	54fffec1 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d54:	394037e0 	ldrb	w0, [sp, #13]
    3d58:	7100e81f 	cmp	w0, #0x3a
    3d5c:	54fffe61 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d60:	52800142 	mov	w2, #0xa                   	// #10
    3d64:	d2800001 	mov	x1, #0x0                   	// #0
    3d68:	91003be0 	add	x0, sp, #0xe
    3d6c:	97fffac9 	bl	2890 <strtol@plt>
    3d70:	aa1403e2 	mov	x2, x20
    3d74:	aa0003fa 	mov	x26, x0
    3d78:	52802001 	mov	w1, #0x100                 	// #256
    3d7c:	aa1303e0 	mov	x0, x19
    3d80:	97fffb0c 	bl	29b0 <fgets@plt>
    3d84:	b5fffdc0 	cbnz	x0, 3d3c <fwp_heap_report+0x9c>
    3d88:	aa1403e0 	mov	x0, x20
    3d8c:	97fffa79 	bl	2770 <fclose@plt>
    3d90:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d94:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d98:	f947f400 	ldr	x0, [x0, #4072]
    3d9c:	f94087e2 	ldr	x2, [sp, #264]
    3da0:	f9400001 	ldr	x1, [x0]
    3da4:	eb010042 	subs	x2, x2, x1
    3da8:	d2800001 	mov	x1, #0x0                   	// #0
    3dac:	54000281 	b.ne	3dfc <fwp_heap_report+0x15c>  // b.any
    3db0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3db4:	aa1a03e6 	mov	x6, x26
    3db8:	aa1903e5 	mov	x5, x25
    3dbc:	aa1803e4 	mov	x4, x24
    3dc0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dc4:	aa1703e3 	mov	x3, x23
    3dc8:	a95463f7 	ldp	x23, x24, [sp, #320]
    3dcc:	aa1603e0 	mov	x0, x22
    3dd0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dd4:	1e604121 	fmov	d1, d9
    3dd8:	1e604100 	fmov	d0, d8
    3ddc:	d0000042 	adrp	x2, d000 <__modti3+0x230>
    3de0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3de4:	910ba042 	add	x2, x2, #0x2e8
    3de8:	9105c3ff 	add	sp, sp, #0x170
    3dec:	52800041 	mov	w1, #0x2                   	// #2
    3df0:	17fffa9c 	b	2860 <__fprintf_chk@plt>
    3df4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3df8:	17ffffe7 	b	3d94 <fwp_heap_report+0xf4>
    3dfc:	a91253f3 	stp	x19, x20, [sp, #288]
    3e00:	97fffa7c 	bl	27f0 <__stack_chk_fail@plt>

0000000000003e04 <fwp_heap_init>:
    3e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e08:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa90>
    3e0c:	9111c061 	add	x1, x3, #0x470
    3e10:	910003fd 	mov	x29, sp
    3e14:	a90153f3 	stp	x19, x20, [sp, #16]
    3e18:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    3e1c:	9115c262 	add	x2, x19, #0x570
    3e20:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e24:	52800024 	mov	w4, #0x1                   	// #1
    3e28:	52800200 	mov	w0, #0x10                  	// #16
    3e2c:	b913a444 	str	w4, [x2, #5028]
    3e30:	b8004420 	str	w0, [x1], #4
    3e34:	11004000 	add	w0, w0, #0x10
    3e38:	7104401f 	cmp	w0, #0x110
    3e3c:	54ffffa1 	b.ne	3e30 <fwp_heap_init+0x2c>  // b.any
    3e40:	d0000042 	adrp	x2, d000 <__modti3+0x230>
    3e44:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e48:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa90>
    3e4c:	9112c021 	add	x1, x1, #0x4b0
    3e50:	3dc38843 	ldr	q3, [x2, #3616]
    3e54:	d2800000 	mov	x0, #0x0                   	// #0
    3e58:	4e040401 	dup	v1.4s, v0.s[0]
    3e5c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e60:	0f215400 	shl	v0.2s, v0.2s, #1
    3e64:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e68:	3ca06821 	str	q1, [x1, x0]
    3e6c:	91004000 	add	x0, x0, #0x10
    3e70:	f101801f 	cmp	x0, #0x60
    3e74:	54ffff21 	b.ne	3e58 <fwp_heap_init+0x54>  // b.any
    3e78:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa90>
    3e7c:	9111c063 	add	x3, x3, #0x470
    3e80:	91144084 	add	x4, x4, #0x510
    3e84:	9115c266 	add	x6, x19, #0x570
    3e88:	d2800002 	mov	x2, #0x0                   	// #0
    3e8c:	d2800000 	mov	x0, #0x0                   	// #0
    3e90:	d2880205 	mov	x5, #0x4010                	// #16400
    3e94:	d503201f 	nop
    3e98:	910f0001 	add	x1, x0, #0x3c0
    3e9c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	540000a2 	b.cs	3eb8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3ea8:	91000400 	add	x0, x0, #0x1
    3eac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3eb0:	eb02003f 	cmp	x1, x2
    3eb4:	54ffffa3 	b.cc	3ea8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3eb8:	91004042 	add	x2, x2, #0x10
    3ebc:	38001480 	strb	w0, [x4], #1
    3ec0:	eb05005f 	cmp	x2, x5
    3ec4:	54fffea1 	b.ne	3e98 <fwp_heap_init+0x94>  // b.any
    3ec8:	528000b5 	mov	w21, #0x5                   	// #5
    3ecc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ed0:	14000004 	b	3ee0 <fwp_heap_init+0xdc>
    3ed4:	d342fe94 	lsr	x20, x20, #2
    3ed8:	710006b5 	subs	w21, w21, #0x1
    3edc:	54000720 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3ee0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ee4:	d2800005 	mov	x5, #0x0                   	// #0
    3ee8:	aa1603e1 	mov	x1, x22
    3eec:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ef0:	52880443 	mov	w3, #0x4022                	// #16418
    3ef4:	52800002 	mov	w2, #0x0                   	// #0
    3ef8:	d2800000 	mov	x0, #0x0                   	// #0
    3efc:	97fffa61 	bl	2880 <mmap@plt>
    3f00:	aa0003e6 	mov	x6, x0
    3f04:	b100041f 	cmn	x0, #0x1
    3f08:	54fffe60 	b.eq	3ed4 <fwp_heap_init+0xd0>  // b.none
    3f0c:	b40005a0 	cbz	x0, 3fc0 <fwp_heap_init+0x1bc>
    3f10:	d350fe94 	lsr	x20, x20, #16
    3f14:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f18:	8b0000c7 	add	x7, x6, x0
    3f1c:	9115c275 	add	x21, x19, #0x570
    3f20:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f24:	8b140a81 	add	x1, x20, x20, lsl #2
    3f28:	d2800005 	mov	x5, #0x0                   	// #0
    3f2c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f30:	d37df021 	lsl	x1, x1, #3
    3f34:	52880443 	mov	w3, #0x4022                	// #16418
    3f38:	52800002 	mov	w2, #0x0                   	// #0
    3f3c:	d2800000 	mov	x0, #0x0                   	// #0
    3f40:	f909daa7 	str	x7, [x21, #5040]
    3f44:	f909dea6 	str	x6, [x21, #5048]
    3f48:	f909e2b6 	str	x22, [x21, #5056]
    3f4c:	f909eab4 	str	x20, [x21, #5072]
    3f50:	f90a02a1 	str	x1, [x21, #5120]
    3f54:	97fffa4b 	bl	2880 <mmap@plt>
    3f58:	aa0003e1 	mov	x1, x0
    3f5c:	b100041f 	cmn	x0, #0x1
    3f60:	54000300 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3f64:	d0000040 	adrp	x0, d000 <__modti3+0x230>
    3f68:	910e6000 	add	x0, x0, #0x398
    3f6c:	f909fea1 	str	x1, [x21, #5112]
    3f70:	97fffa84 	bl	2980 <getenv@plt>
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	aa0003e1 	mov	x1, x0
    3f7c:	b40000e0 	cbz	x0, 3f98 <fwp_heap_init+0x194>
    3f80:	39400000 	ldrb	w0, [x0]
    3f84:	340000a0 	cbz	w0, 3f98 <fwp_heap_init+0x194>
    3f88:	7100c000 	subs	w0, w0, #0x30
    3f8c:	54000120 	b.eq	3fb0 <fwp_heap_init+0x1ac>  // b.none
    3f90:	7100001f 	cmp	w0, #0x0
    3f94:	1a9f07e2 	cset	w2, ne	// ne = any
    3f98:	9115c273 	add	x19, x19, #0x570
    3f9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fa0:	b913aa62 	str	w2, [x19, #5032]
    3fa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fac:	d65f03c0 	ret
    3fb0:	39400420 	ldrb	w0, [x1, #1]
    3fb4:	7100001f 	cmp	w0, #0x0
    3fb8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fbc:	17fffff7 	b	3f98 <fwp_heap_init+0x194>
    3fc0:	97fffbfc 	bl	2fb0 <fwp_heap_oom>

0000000000003fc4 <caf61>:
    3fc4:	b00000e2 	adrp	x2, 20000 <__data_start>
    3fc8:	91010041 	add	x1, x2, #0x40
    3fcc:	b9404820 	ldr	w0, [x1, #72]
    3fd0:	34000060 	cbz	w0, 3fdc <caf61+0x18>
    3fd4:	f9402820 	ldr	x0, [x1, #80]
    3fd8:	d65f03c0 	ret
    3fdc:	b9405820 	ldr	w0, [x1, #88]
    3fe0:	340000e0 	cbz	w0, 3ffc <caf61+0x38>
    3fe4:	f9403020 	ldr	x0, [x1, #96]
    3fe8:	91010042 	add	x2, x2, #0x40
    3fec:	52800021 	mov	w1, #0x1                   	// #1
    3ff0:	b9004841 	str	w1, [x2, #72]
    3ff4:	f9002840 	str	x0, [x2, #80]
    3ff8:	d65f03c0 	ret
    3ffc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4000:	52800024 	mov	w4, #0x1                   	// #1
    4004:	aa0303e0 	mov	x0, x3
    4008:	b9005824 	str	w4, [x1, #88]
    400c:	f9003023 	str	x3, [x1, #96]
    4010:	17fffff6 	b	3fe8 <caf61+0x24>

0000000000004014 <fwp_wake_io>:
    4014:	900000e9 	adrp	x9, 20000 <__data_start>
    4018:	91010122 	add	x2, x9, #0x40
    401c:	f9400001 	ldr	x1, [x0]
    4020:	5280000a 	mov	w10, #0x0                   	// #0
    4024:	f9401446 	ldr	x6, [x2, #40]
    4028:	52800008 	mov	w8, #0x0                   	// #0
    402c:	4f000400 	movi	v0.4s, #0x0
    4030:	52800027 	mov	w7, #0x1                   	// #1
    4034:	aa0103e2 	mov	x2, x1
    4038:	b4000321 	cbz	x1, 409c <fwp_wake_io+0x88>
    403c:	f9408c25 	ldr	x5, [x1, #280]
    4040:	39015c27 	strb	w7, [x1, #87]
    4044:	b4000165 	cbz	x5, 4070 <fwp_wake_io+0x5c>
    4048:	a9520c24 	ldp	x4, x3, [x1, #288]
    404c:	b4000364 	cbz	x4, 40b8 <fwp_wake_io+0xa4>
    4050:	f9009483 	str	x3, [x4, #296]
    4054:	f9409423 	ldr	x3, [x1, #296]
    4058:	b4000043 	cbz	x3, 4060 <fwp_wake_io+0x4c>
    405c:	f9009064 	str	x4, [x3, #288]
    4060:	91080023 	add	x3, x1, #0x200
    4064:	f900943f 	str	xzr, [x1, #296]
    4068:	3c918060 	stur	q0, [x3, #-232]
    406c:	f9400001 	ldr	x1, [x0]
    4070:	f9402843 	ldr	x3, [x2, #80]
    4074:	f2001c7f 	tst	x3, #0xff000000ff
    4078:	54fffde1 	b.ne	4034 <fwp_wake_io+0x20>  // b.any
    407c:	39015047 	strb	w7, [x2, #84]
    4080:	f900805f 	str	xzr, [x2, #256]
    4084:	b40001e6 	cbz	x6, 40c0 <fwp_wake_io+0xac>
    4088:	f90080c2 	str	x2, [x6, #256]
    408c:	aa0203e6 	mov	x6, x2
    4090:	52800028 	mov	w8, #0x1                   	// #1
    4094:	aa0103e2 	mov	x2, x1
    4098:	b5fffd21 	cbnz	x1, 403c <fwp_wake_io+0x28>
    409c:	3400006a 	cbz	w10, 40a8 <fwp_wake_io+0x94>
    40a0:	91010120 	add	x0, x9, #0x40
    40a4:	f900180b 	str	x11, [x0, #48]
    40a8:	34000068 	cbz	w8, 40b4 <fwp_wake_io+0xa0>
    40ac:	91010129 	add	x9, x9, #0x40
    40b0:	f9001526 	str	x6, [x9, #40]
    40b4:	d65f03c0 	ret
    40b8:	f90000a3 	str	x3, [x5]
    40bc:	17ffffe7 	b	4058 <fwp_wake_io+0x44>
    40c0:	aa0203eb 	mov	x11, x2
    40c4:	5280002a 	mov	w10, #0x1                   	// #1
    40c8:	17fffff1 	b	408c <fwp_wake_io+0x78>
    40cc:	d503201f 	nop

00000000000040d0 <fwp_tape_buffers_release>:
    40d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40d4:	910003fd 	mov	x29, sp
    40d8:	a90153f3 	stp	x19, x20, [sp, #16]
    40dc:	aa0003f3 	mov	x19, x0
    40e0:	f9401400 	ldr	x0, [x0, #40]
    40e4:	b7f80760 	tbnz	x0, #63, 41d0 <fwp_tape_buffers_release+0x100>
    40e8:	f9401a61 	ldr	x1, [x19, #48]
    40ec:	b7f80301 	tbnz	x1, #63, 414c <fwp_tape_buffers_release+0x7c>
    40f0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    40f4:	eb02001f 	cmp	x0, x2
    40f8:	540002a8 	b.hi	414c <fwp_tape_buffers_release+0x7c>  // b.pmore
    40fc:	8b000400 	add	x0, x0, x0, lsl #1
    4100:	d2a00102 	mov	x2, #0x80000               	// #524288
    4104:	d37df000 	lsl	x0, x0, #3
    4108:	cb000042 	sub	x2, x2, x0
    410c:	eb420c3f 	cmp	x1, x2, lsr #3
    4110:	540001e8 	b.hi	414c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4114:	8b010c14 	add	x20, x0, x1, lsl #3
    4118:	b0000040 	adrp	x0, d000 <__modti3+0x230>
    411c:	910ea000 	add	x0, x0, #0x3a8
    4120:	97fffa18 	bl	2980 <getenv@plt>
    4124:	b4000240 	cbz	x0, 416c <fwp_tape_buffers_release+0x9c>
    4128:	39400001 	ldrb	w1, [x0]
    412c:	7100c03f 	cmp	w1, #0x30
    4130:	540001e1 	b.ne	416c <fwp_tape_buffers_release+0x9c>  // b.any
    4134:	39400400 	ldrb	w0, [x0, #1]
    4138:	350001a0 	cbnz	w0, 416c <fwp_tape_buffers_release+0x9c>
    413c:	aa1303e0 	mov	x0, x19
    4140:	a94153f3 	ldp	x19, x20, [sp, #16]
    4144:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4148:	17fffc4e 	b	3280 <fwp_tape_buffers_dispose>
    414c:	b0000040 	adrp	x0, d000 <__modti3+0x230>
    4150:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4154:	910ea000 	add	x0, x0, #0x3a8
    4158:	97fffa0a 	bl	2980 <getenv@plt>
    415c:	b4ffff00 	cbz	x0, 413c <fwp_tape_buffers_release+0x6c>
    4160:	39400001 	ldrb	w1, [x0]
    4164:	7100c03f 	cmp	w1, #0x30
    4168:	54fffe60 	b.eq	4134 <fwp_tape_buffers_release+0x64>  // b.none
    416c:	d1000681 	sub	x1, x20, #0x1
    4170:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4174:	eb00003f 	cmp	x1, x0
    4178:	54fffe28 	b.hi	413c <fwp_tape_buffers_release+0x6c>  // b.pmore
    417c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4180:	900000f6 	adrp	x22, 20000 <__data_start>
    4184:	910102d6 	add	x22, x22, #0x40
    4188:	9101a2d5 	add	x21, x22, #0x68
    418c:	aa1503e0 	mov	x0, x21
    4190:	97fffc3c 	bl	3280 <fwp_tape_buffers_dispose>
    4194:	ad400a61 	ldp	q1, q2, [x19]
    4198:	f90052d4 	str	x20, [x22, #160]
    419c:	4f000400 	movi	v0.4s, #0x0
    41a0:	ad000aa1 	stp	q1, q2, [x21]
    41a4:	3dc00a61 	ldr	q1, [x19, #32]
    41a8:	3d800aa1 	str	q1, [x21, #32]
    41ac:	f9401a60 	ldr	x0, [x19, #48]
    41b0:	f9001aa0 	str	x0, [x21, #48]
    41b4:	f9001a7f 	str	xzr, [x19, #48]
    41b8:	ad000260 	stp	q0, q0, [x19]
    41bc:	3d800a60 	str	q0, [x19, #32]
    41c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41cc:	d65f03c0 	ret
    41d0:	b0000040 	adrp	x0, d000 <__modti3+0x230>
    41d4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    41d8:	910ea000 	add	x0, x0, #0x3a8
    41dc:	97fff9e9 	bl	2980 <getenv@plt>
    41e0:	b5fffa40 	cbnz	x0, 4128 <fwp_tape_buffers_release+0x58>
    41e4:	17ffffd6 	b	413c <fwp_tape_buffers_release+0x6c>
    41e8:	d503201f 	nop
    41ec:	d503201f 	nop

00000000000041f0 <fwp_poll_events>:
    41f0:	d10103ff 	sub	sp, sp, #0x40
    41f4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    41f8:	f947f400 	ldr	x0, [x0, #4072]
    41fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4200:	910083fd 	add	x29, sp, #0x20
    4204:	a90353f3 	stp	x19, x20, [sp, #48]
    4208:	900000f4 	adrp	x20, 20000 <__data_start>
    420c:	f9400001 	ldr	x1, [x0]
    4210:	f9000fe1 	str	x1, [sp, #24]
    4214:	d2800001 	mov	x1, #0x0                   	// #0
    4218:	97fffd1a 	bl	3680 <fwp_now_ns>
    421c:	91010281 	add	x1, x20, #0x40
    4220:	f9405433 	ldr	x19, [x1, #168]
    4224:	b4000e93 	cbz	x19, 43f4 <fwp_poll_events+0x204>
    4228:	aa1303e1 	mov	x1, x19
    422c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4230:	14000005 	b	4244 <fwp_poll_events+0x54>
    4234:	f9408821 	ldr	x1, [x1, #272]
    4238:	eb03005f 	cmp	x2, x3
    423c:	9a83d042 	csel	x2, x2, x3, le
    4240:	b40000c1 	cbz	x1, 4258 <fwp_poll_events+0x68>
    4244:	f9403423 	ldr	x3, [x1, #104]
    4248:	b6ffff62 	tbz	x2, #63, 4234 <fwp_poll_events+0x44>
    424c:	f9408821 	ldr	x1, [x1, #272]
    4250:	aa0303e2 	mov	x2, x3
    4254:	b5ffff81 	cbnz	x1, 4244 <fwp_poll_events+0x54>
    4258:	b7f80ce2 	tbnz	x2, #63, 43f4 <fwp_poll_events+0x204>
    425c:	cb000042 	sub	x2, x2, x0
    4260:	f100005f 	cmp	x2, #0x0
    4264:	540005cd 	b.le	431c <fwp_poll_events+0x12c>
    4268:	d2869b60 	mov	x0, #0x34db                	// #13531
    426c:	d2884801 	mov	x1, #0x4240                	// #16960
    4270:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4274:	f2a001e1 	movk	x1, #0xf, lsl #16
    4278:	f2dbd040 	movk	x0, #0xde82, lsl #32
    427c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4280:	f2e86360 	movk	x0, #0x431b, lsl #48
    4284:	9b407c40 	smulh	x0, x2, x0
    4288:	9352fc00 	asr	x0, x0, #18
    428c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4290:	9b018802 	msub	x2, x0, x1, x2
    4294:	f100005f 	cmp	x2, #0x0
    4298:	9a800400 	cinc	x0, x0, ne	// ne = any
    429c:	eb03001f 	cmp	x0, x3
    42a0:	54000a0c 	b.gt	43e0 <fwp_poll_events+0x1f0>
    42a4:	340003c0 	cbz	w0, 431c <fwp_poll_events+0x12c>
    42a8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    42ac:	52807d04 	mov	w4, #0x3e8                 	// #1000
    42b0:	72a20c42 	movk	w2, #0x1062, lsl #16
    42b4:	9ba27c02 	umull	x2, w0, w2
    42b8:	d366fc43 	lsr	x3, x2, #38
    42bc:	aa0303e2 	mov	x2, x3
    42c0:	1b048063 	msub	w3, w3, w4, w0
    42c4:	9b217c63 	smull	x3, w3, w1
    42c8:	d2800001 	mov	x1, #0x0                   	// #0
    42cc:	910023e0 	add	x0, sp, #0x8
    42d0:	a9008fe2 	stp	x2, x3, [sp, #8]
    42d4:	97fff97b 	bl	28c0 <nanosleep@plt>
    42d8:	91010280 	add	x0, x20, #0x40
    42dc:	f9405413 	ldr	x19, [x0, #168]
    42e0:	97fffce8 	bl	3680 <fwp_now_ns>
    42e4:	aa0003e6 	mov	x6, x0
    42e8:	b50001f3 	cbnz	x19, 4324 <fwp_poll_events+0x134>
    42ec:	d503201f 	nop
    42f0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    42f4:	f947f400 	ldr	x0, [x0, #4072]
    42f8:	f9400fe2 	ldr	x2, [sp, #24]
    42fc:	f9400001 	ldr	x1, [x0]
    4300:	eb010042 	subs	x2, x2, x1
    4304:	d2800001 	mov	x1, #0x0                   	// #0
    4308:	540008c1 	b.ne	4420 <fwp_poll_events+0x230>  // b.any
    430c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4310:	a94353f3 	ldp	x19, x20, [sp, #48]
    4314:	910103ff 	add	sp, sp, #0x40
    4318:	d65f03c0 	ret
    431c:	97fffcd9 	bl	3680 <fwp_now_ns>
    4320:	aa0003e6 	mov	x6, x0
    4324:	4f000400 	movi	v0.4s, #0x0
    4328:	91010288 	add	x8, x20, #0x40
    432c:	52800027 	mov	w7, #0x1                   	// #1
    4330:	f9403661 	ldr	x1, [x19, #104]
    4334:	aa1303e5 	mov	x5, x19
    4338:	f9408a73 	ldr	x19, [x19, #272]
    433c:	eb06003f 	cmp	x1, x6
    4340:	5400032c 	b.gt	43a4 <fwp_poll_events+0x1b4>
    4344:	394154a0 	ldrb	w0, [x5, #85]
    4348:	36000120 	tbz	w0, #0, 436c <fwp_poll_events+0x17c>
    434c:	f94084a0 	ldr	x0, [x5, #264]
    4350:	b40003c0 	cbz	x0, 43c8 <fwp_poll_events+0x1d8>
    4354:	f9008813 	str	x19, [x0, #272]
    4358:	b4000053 	cbz	x19, 4360 <fwp_poll_events+0x170>
    435c:	f9008660 	str	x0, [x19, #264]
    4360:	910800a0 	add	x0, x5, #0x200
    4364:	390154bf 	strb	wzr, [x5, #85]
    4368:	3c908000 	stur	q0, [x0, #-248]
    436c:	f94030a0 	ldr	x0, [x5, #96]
    4370:	390158a7 	strb	w7, [x5, #86]
    4374:	f100001f 	cmp	x0, #0x0
    4378:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    437c:	5400018d 	b.le	43ac <fwp_poll_events+0x1bc>
    4380:	f94028a0 	ldr	x0, [x5, #80]
    4384:	f2001c1f 	tst	x0, #0xff000000ff
    4388:	540000e1 	b.ne	43a4 <fwp_poll_events+0x1b4>  // b.any
    438c:	f9401500 	ldr	x0, [x8, #40]
    4390:	390150a7 	strb	w7, [x5, #84]
    4394:	f90080bf 	str	xzr, [x5, #256]
    4398:	b40001e0 	cbz	x0, 43d4 <fwp_poll_events+0x1e4>
    439c:	f9001505 	str	x5, [x8, #40]
    43a0:	f9008005 	str	x5, [x0, #256]
    43a4:	b5fffc73 	cbnz	x19, 4330 <fwp_poll_events+0x140>
    43a8:	17ffffd2 	b	42f0 <fwp_poll_events+0x100>
    43ac:	394144a0 	ldrb	w0, [x5, #81]
    43b0:	3707fe80 	tbnz	w0, #0, 4380 <fwp_poll_events+0x190>
    43b4:	394140a0 	ldrb	w0, [x5, #80]
    43b8:	3707fe40 	tbnz	w0, #0, 4380 <fwp_poll_events+0x190>
    43bc:	aa0503e0 	mov	x0, x5
    43c0:	97fffc0c 	bl	33f0 <fwp_cancel_tree.part.0>
    43c4:	17ffffef 	b	4380 <fwp_poll_events+0x190>
    43c8:	91010281 	add	x1, x20, #0x40
    43cc:	f9005433 	str	x19, [x1, #168]
    43d0:	17ffffe2 	b	4358 <fwp_poll_events+0x168>
    43d4:	f9001505 	str	x5, [x8, #40]
    43d8:	f9001905 	str	x5, [x8, #48]
    43dc:	17fffff2 	b	43a4 <fwp_poll_events+0x1b4>
    43e0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    43e4:	d2989362 	mov	x2, #0xc49b                	// #50331
    43e8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    43ec:	f2a00402 	movk	x2, #0x20, lsl #16
    43f0:	17ffffb6 	b	42c8 <fwp_poll_events+0xd8>
    43f4:	97fffadf 	bl	2f70 <fwp_flush>
    43f8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    43fc:	f947e863 	ldr	x3, [x3, #4048]
    4400:	d2800562 	mov	x2, #0x2b                  	// #43
    4404:	d2800021 	mov	x1, #0x1                   	// #1
    4408:	b0000040 	adrp	x0, d000 <__modti3+0x230>
    440c:	910f0000 	add	x0, x0, #0x3c0
    4410:	f9400063 	ldr	x3, [x3]
    4414:	97fff937 	bl	28f0 <fwrite@plt>
    4418:	52800ca0 	mov	w0, #0x65                  	// #101
    441c:	97fff8a1 	bl	26a0 <exit@plt>
    4420:	97fff8f4 	bl	27f0 <__stack_chk_fail@plt>

0000000000004424 <fwp_rc_wide_dup>:
    4424:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4428:	910003fd 	mov	x29, sp
    442c:	a90153f3 	stp	x19, x20, [sp, #16]
    4430:	aa0003f3 	mov	x19, x0
    4434:	ca404400 	eor	x0, x0, x0, lsr #17
    4438:	f90013f5 	str	x21, [sp, #32]
    443c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    4440:	ca402400 	eor	x0, x0, x0, lsr #9
    4444:	9115c2a2 	add	x2, x21, #0x570
    4448:	92401c00 	and	x0, x0, #0xff
    444c:	910a2403 	add	x3, x0, #0x289
    4450:	8b000c40 	add	x0, x2, x0, lsl #3
    4454:	8b030c54 	add	x20, x2, x3, lsl #3
    4458:	f94a2401 	ldr	x1, [x0, #5192]
    445c:	b50000a1 	cbnz	x1, 4470 <fwp_rc_wide_dup+0x4c>
    4460:	1400002d 	b	4514 <fwp_rc_wide_dup+0xf0>
    4464:	91004034 	add	x20, x1, #0x10
    4468:	f9400821 	ldr	x1, [x1, #16]
    446c:	b4000241 	cbz	x1, 44b4 <fwp_rc_wide_dup+0x90>
    4470:	f9400022 	ldr	x2, [x1]
    4474:	eb02027f 	cmp	x19, x2
    4478:	54ffff61 	b.ne	4464 <fwp_rc_wide_dup+0x40>  // b.any
    447c:	f9400281 	ldr	x1, [x20]
    4480:	39400260 	ldrb	w0, [x19]
    4484:	7103f81f 	cmp	w0, #0xfe
    4488:	54000220 	b.eq	44cc <fwp_rc_wide_dup+0xa8>  // b.none
    448c:	b40001a1 	cbz	x1, 44c0 <fwp_rc_wide_dup+0x9c>
    4490:	f9400420 	ldr	x0, [x1, #8]
    4494:	b100041f 	cmn	x0, #0x1
    4498:	540004a0 	b.eq	452c <fwp_rc_wide_dup+0x108>  // b.none
    449c:	91000400 	add	x0, x0, #0x1
    44a0:	f9000420 	str	x0, [x1, #8]
    44a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44a8:	f94013f5 	ldr	x21, [sp, #32]
    44ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44b0:	d65f03c0 	ret
    44b4:	39400260 	ldrb	w0, [x19]
    44b8:	7103f81f 	cmp	w0, #0xfe
    44bc:	540000a0 	b.eq	44d0 <fwp_rc_wide_dup+0xac>  // b.none
    44c0:	b0000040 	adrp	x0, d000 <__modti3+0x230>
    44c4:	91106000 	add	x0, x0, #0x418
    44c8:	97fffc0e 	bl	3500 <fwp_trap>
    44cc:	b5000281 	cbnz	x1, 451c <fwp_rc_wide_dup+0xf8>
    44d0:	d2800300 	mov	x0, #0x18                  	// #24
    44d4:	97fff8af 	bl	2790 <malloc@plt>
    44d8:	b4000280 	cbz	x0, 4528 <fwp_rc_wide_dup+0x104>
    44dc:	d2801fe1 	mov	x1, #0xff                  	// #255
    44e0:	a9000413 	stp	x19, x1, [x0]
    44e4:	9115c2b5 	add	x21, x21, #0x570
    44e8:	f900081f 	str	xzr, [x0, #16]
    44ec:	12800001 	mov	w1, #0xffffffff            	// #-1
    44f0:	f9000280 	str	x0, [x20]
    44f4:	39000261 	strb	w1, [x19]
    44f8:	f94e26a0 	ldr	x0, [x21, #7240]
    44fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4500:	91000400 	add	x0, x0, #0x1
    4504:	f90e26a0 	str	x0, [x21, #7240]
    4508:	f94013f5 	ldr	x21, [sp, #32]
    450c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4510:	d65f03c0 	ret
    4514:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4518:	17ffffda 	b	4480 <fwp_rc_wide_dup+0x5c>
    451c:	b0000040 	adrp	x0, d000 <__modti3+0x230>
    4520:	910fc000 	add	x0, x0, #0x3f0
    4524:	97fffbf7 	bl	3500 <fwp_trap>
    4528:	97fffaa2 	bl	2fb0 <fwp_heap_oom>
    452c:	b0000040 	adrp	x0, d000 <__modti3+0x230>
    4530:	91110000 	add	x0, x0, #0x440
    4534:	97fffbf3 	bl	3500 <fwp_trap>
    4538:	d503201f 	nop
    453c:	d503201f 	nop

0000000000004540 <fwp_rc_forget_slot>:
    4540:	aa0003e1 	mov	x1, x0
    4544:	39400000 	ldrb	w0, [x0]
    4548:	7103fc1f 	cmp	w0, #0xff
    454c:	54000040 	b.eq	4554 <fwp_rc_forget_slot+0x14>  // b.none
    4550:	d65f03c0 	ret
    4554:	ca414420 	eor	x0, x1, x1, lsr #17
    4558:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    455c:	ca402400 	eor	x0, x0, x0, lsr #9
    4560:	910003fd 	mov	x29, sp
    4564:	92401c00 	and	x0, x0, #0xff
    4568:	f9000bf3 	str	x19, [sp, #16]
    456c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    4570:	9115c262 	add	x2, x19, #0x570
    4574:	910a2403 	add	x3, x0, #0x289
    4578:	8b000c40 	add	x0, x2, x0, lsl #3
    457c:	8b030c43 	add	x3, x2, x3, lsl #3
    4580:	f94a2400 	ldr	x0, [x0, #5192]
    4584:	b50000a0 	cbnz	x0, 4598 <fwp_rc_forget_slot+0x58>
    4588:	14000011 	b	45cc <fwp_rc_forget_slot+0x8c>
    458c:	91004003 	add	x3, x0, #0x10
    4590:	f9400800 	ldr	x0, [x0, #16]
    4594:	b40001c0 	cbz	x0, 45cc <fwp_rc_forget_slot+0x8c>
    4598:	f9400002 	ldr	x2, [x0]
    459c:	eb02003f 	cmp	x1, x2
    45a0:	54ffff61 	b.ne	458c <fwp_rc_forget_slot+0x4c>  // b.any
    45a4:	f9400801 	ldr	x1, [x0, #16]
    45a8:	9115c273 	add	x19, x19, #0x570
    45ac:	f9000061 	str	x1, [x3]
    45b0:	97fff8c0 	bl	28b0 <free@plt>
    45b4:	f94e2660 	ldr	x0, [x19, #7240]
    45b8:	d1000400 	sub	x0, x0, #0x1
    45bc:	f90e2660 	str	x0, [x19, #7240]
    45c0:	f9400bf3 	ldr	x19, [sp, #16]
    45c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45c8:	d65f03c0 	ret
    45cc:	b0000040 	adrp	x0, d000 <__modti3+0x230>
    45d0:	91106000 	add	x0, x0, #0x418
    45d4:	97fffbcb 	bl	3500 <fwp_trap>
    45d8:	d503201f 	nop
    45dc:	d503201f 	nop

00000000000045e0 <fwp_rc_prepare_chunk>:
    45e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    45e4:	910003fd 	mov	x29, sp
    45e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    45ec:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc70>
    45f0:	9115c2c2 	add	x2, x22, #0x570
    45f4:	b9401c03 	ldr	w3, [x0, #28]
    45f8:	aa0103f5 	mov	x21, x1
    45fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4600:	aa0003f4 	mov	x20, x0
    4604:	f94e2440 	ldr	x0, [x2, #7240]
    4608:	b4000440 	cbz	x0, 4690 <fwp_rc_prepare_chunk+0xb0>
    460c:	d2800013 	mov	x19, #0x0                   	// #0
    4610:	35000203 	cbnz	w3, 4650 <fwp_rc_prepare_chunk+0x70>
    4614:	b4000361 	cbz	x1, 4680 <fwp_rc_prepare_chunk+0xa0>
    4618:	f9401280 	ldr	x0, [x20, #32]
    461c:	97fff8a5 	bl	28b0 <free@plt>
    4620:	aa1503e0 	mov	x0, x21
    4624:	d2800021 	mov	x1, #0x1                   	// #1
    4628:	97fff86a 	bl	27d0 <calloc@plt>
    462c:	f9001280 	str	x0, [x20, #32]
    4630:	b5000460 	cbnz	x0, 46bc <fwp_rc_prepare_chunk+0xdc>
    4634:	97fffa5f 	bl	2fb0 <fwp_heap_oom>
    4638:	97ffffc2 	bl	4540 <fwp_rc_forget_slot>
    463c:	91000673 	add	x19, x19, #0x1
    4640:	b9401e83 	ldr	w3, [x20, #28]
    4644:	eb13007f 	cmp	x3, x19
    4648:	54000169 	b.ls	4674 <fwp_rc_prepare_chunk+0x94>  // b.plast
    464c:	d503201f 	nop
    4650:	f9401283 	ldr	x3, [x20, #32]
    4654:	8b130060 	add	x0, x3, x19
    4658:	38736863 	ldrb	w3, [x3, x19]
    465c:	7103fc7f 	cmp	w3, #0xff
    4660:	54fffec0 	b.eq	4638 <fwp_rc_prepare_chunk+0x58>  // b.none
    4664:	b9401e83 	ldr	w3, [x20, #28]
    4668:	91000673 	add	x19, x19, #0x1
    466c:	eb13007f 	cmp	x3, x19
    4670:	54ffff08 	b.hi	4650 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4674:	eb0302bf 	cmp	x21, x3
    4678:	54000121 	b.ne	469c <fwp_rc_prepare_chunk+0xbc>  // b.any
    467c:	b5000335 	cbnz	x21, 46e0 <fwp_rc_prepare_chunk+0x100>
    4680:	a94153f3 	ldp	x19, x20, [sp, #16]
    4684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4688:	a8c37bfd 	ldp	x29, x30, [sp], #48
    468c:	d65f03c0 	ret
    4690:	2a0303e3 	mov	w3, w3
    4694:	eb0302bf 	cmp	x21, x3
    4698:	54ffff20 	b.eq	467c <fwp_rc_prepare_chunk+0x9c>  // b.none
    469c:	9115c2c2 	add	x2, x22, #0x570
    46a0:	f9401280 	ldr	x0, [x20, #32]
    46a4:	f94e2841 	ldr	x1, [x2, #7248]
    46a8:	cb030021 	sub	x1, x1, x3
    46ac:	f90e2841 	str	x1, [x2, #7248]
    46b0:	97fff880 	bl	28b0 <free@plt>
    46b4:	b5fffb75 	cbnz	x21, 4620 <fwp_rc_prepare_chunk+0x40>
    46b8:	f900129f 	str	xzr, [x20, #32]
    46bc:	9115c2d6 	add	x22, x22, #0x570
    46c0:	f94e2ac0 	ldr	x0, [x22, #7248]
    46c4:	b9001e95 	str	w21, [x20, #28]
    46c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46cc:	8b150000 	add	x0, x0, x21
    46d0:	f90e2ac0 	str	x0, [x22, #7248]
    46d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46dc:	d65f03c0 	ret
    46e0:	f9401280 	ldr	x0, [x20, #32]
    46e4:	aa1503e2 	mov	x2, x21
    46e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46ec:	52800001 	mov	w1, #0x0                   	// #0
    46f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46f8:	17fff832 	b	27c0 <memset@plt>
    46fc:	d503201f 	nop

0000000000004700 <fwp_heap_refill>:
    4700:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4704:	910003fd 	mov	x29, sp
    4708:	a9025bf5 	stp	x21, x22, [sp, #32]
    470c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    4710:	9115c2b5 	add	x21, x21, #0x570
    4714:	aa0003f6 	mov	x22, x0
    4718:	d2800020 	mov	x0, #0x1                   	// #1
    471c:	a90153f3 	stp	x19, x20, [sp, #16]
    4720:	a90363f7 	stp	x23, x24, [sp, #48]
    4724:	2a0103f7 	mov	w23, w1
    4728:	2a0203f8 	mov	w24, w2
    472c:	97fffa61 	bl	30b0 <fwp_heap_chunks>
    4730:	aa0003f3 	mov	x19, x0
    4734:	f949fea2 	ldr	x2, [x21, #5112]
    4738:	8b000800 	add	x0, x0, x0, lsl #2
    473c:	2a1703e1 	mov	w1, w23
    4740:	52800025 	mov	w5, #0x1                   	// #1
    4744:	d37df000 	lsl	x0, x0, #3
    4748:	910f0021 	add	x1, x1, #0x3c0
    474c:	8b000054 	add	x20, x2, x0
    4750:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4754:	52a00024 	mov	w4, #0x10000               	// #65536
    4758:	38206845 	strb	w5, [x2, x0]
    475c:	aa1403e0 	mov	x0, x20
    4760:	39000698 	strb	w24, [x20, #1]
    4764:	39000a97 	strb	w23, [x20, #2]
    4768:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    476c:	b9000681 	str	w1, [x20, #4]
    4770:	2a0103e5 	mov	w5, w1
    4774:	8b0300a2 	add	x2, x5, x3
    4778:	1ac10881 	udiv	w1, w4, w1
    477c:	9ac50842 	udiv	x2, x2, x5
    4780:	b9000a81 	str	w1, [x20, #8]
    4784:	92404021 	and	x1, x1, #0x1ffff
    4788:	b9001a82 	str	w2, [x20, #24]
    478c:	97ffff95 	bl	45e0 <fwp_rc_prepare_chunk>
    4790:	f949daa0 	ldr	x0, [x21, #5040]
    4794:	29408a81 	ldp	w1, w2, [x20, #4]
    4798:	8b134000 	add	x0, x0, x19, lsl #16
    479c:	a94153f3 	ldp	x19, x20, [sp, #16]
    47a0:	8b214003 	add	x3, x0, w1, uxtw
    47a4:	9ba20021 	umaddl	x1, w1, w2, x0
    47a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    47ac:	a90086c3 	stp	x3, x1, [x22, #8]
    47b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47b4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    47b8:	d65f03c0 	ret
    47bc:	d503201f 	nop

00000000000047c0 <fwp_mem_free>:
    47c0:	b40003c0 	cbz	x0, 4838 <fwp_mem_free+0x78>
    47c4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    47c8:	910003fd 	mov	x29, sp
    47cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    47d0:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    47d4:	9115c2a1 	add	x1, x21, #0x570
    47d8:	a90153f3 	stp	x19, x20, [sp, #16]
    47dc:	aa0003f3 	mov	x19, x0
    47e0:	f949d823 	ldr	x3, [x1, #5040]
    47e4:	f949ec22 	ldr	x2, [x1, #5080]
    47e8:	cb030000 	sub	x0, x0, x3
    47ec:	eb02401f 	cmp	x0, x2, lsl #16
    47f0:	540001c2 	b.cs	4828 <fwp_mem_free+0x68>  // b.hs, b.nlast
    47f4:	d350fc16 	lsr	x22, x0, #16
    47f8:	a90363f7 	stp	x23, x24, [sp, #48]
    47fc:	f949fc22 	ldr	x2, [x1, #5112]
    4800:	8b160ad4 	add	x20, x22, x22, lsl #2
    4804:	d37df294 	lsl	x20, x20, #3
    4808:	ab140057 	adds	x23, x2, x20
    480c:	540000c0 	b.eq	4824 <fwp_mem_free+0x64>  // b.none
    4810:	38746842 	ldrb	w2, [x2, x20]
    4814:	7100045f 	cmp	w2, #0x1
    4818:	54000120 	b.eq	483c <fwp_mem_free+0x7c>  // b.none
    481c:	7100085f 	cmp	w2, #0x2
    4820:	540005e0 	b.eq	48dc <fwp_mem_free+0x11c>  // b.none
    4824:	a94363f7 	ldp	x23, x24, [sp, #48]
    4828:	a94153f3 	ldp	x19, x20, [sp, #16]
    482c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4830:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4834:	d65f03c0 	ret
    4838:	d65f03c0 	ret
    483c:	f94012f8 	ldr	x24, [x23, #32]
    4840:	b94006e1 	ldr	w1, [x23, #4]
    4844:	f90023f9 	str	x25, [sp, #64]
    4848:	2a0103e2 	mov	w2, w1
    484c:	394006f9 	ldrb	w25, [x23, #1]
    4850:	39400af4 	ldrb	w20, [x23, #2]
    4854:	b4000158 	cbz	x24, 487c <fwp_mem_free+0xbc>
    4858:	92403e76 	and	x22, x19, #0xffff
    485c:	9ac20ad6 	udiv	x22, x22, x2
    4860:	38766b01 	ldrb	w1, [x24, x22]
    4864:	8b160300 	add	x0, x24, x22
    4868:	7103fc3f 	cmp	w1, #0xff
    486c:	54000980 	b.eq	499c <fwp_mem_free+0x1dc>  // b.none
    4870:	38366b1f 	strb	wzr, [x24, x22]
    4874:	b94006e1 	ldr	w1, [x23, #4]
    4878:	2a0103e2 	mov	w2, w1
    487c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4880:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4884:	cb390000 	sub	x0, x0, w25, uxtb
    4888:	8b340074 	add	x20, x3, w20, uxtb
    488c:	9115c2b5 	add	x21, x21, #0x570
    4890:	1e630021 	ucvtf	d1, w1
    4894:	d37ae400 	lsl	x0, x0, #6
    4898:	8b140c14 	add	x20, x0, x20, lsl #3
    489c:	a94363f7 	ldp	x23, x24, [sp, #48]
    48a0:	f8746aa0 	ldr	x0, [x21, x20]
    48a4:	f94023f9 	ldr	x25, [sp, #64]
    48a8:	aa2003e0 	mvn	x0, x0
    48ac:	fd4a22a0 	ldr	d0, [x21, #5184]
    48b0:	f9000260 	str	x0, [x19]
    48b4:	f8346ab3 	str	x19, [x21, x20]
    48b8:	f94a12a0 	ldr	x0, [x21, #5152]
    48bc:	1e612800 	fadd	d0, d0, d1
    48c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    48c4:	cb020000 	sub	x0, x0, x2
    48c8:	f90a12a0 	str	x0, [x21, #5152]
    48cc:	fd0a22a0 	str	d0, [x21, #5184]
    48d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    48d4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    48d8:	d65f03c0 	ret
    48dc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    48e0:	8b000063 	add	x3, x3, x0
    48e4:	eb03027f 	cmp	x19, x3
    48e8:	54fff9e1 	b.ne	4824 <fwp_mem_free+0x64>  // b.any
    48ec:	fd400ae1 	ldr	d1, [x23, #16]
    48f0:	fd4a2020 	ldr	d0, [x1, #5184]
    48f4:	f9400ae0 	ldr	x0, [x23, #16]
    48f8:	7e61d821 	ucvtf	d1, d1
    48fc:	f94a1022 	ldr	x2, [x1, #5152]
    4900:	f94012f3 	ldr	x19, [x23, #32]
    4904:	1e612800 	fadd	d0, d0, d1
    4908:	cb000042 	sub	x2, x2, x0
    490c:	f90a1022 	str	x2, [x1, #5152]
    4910:	fd0a2020 	str	d0, [x1, #5184]
    4914:	b40000b3 	cbz	x19, 4928 <fwp_mem_free+0x168>
    4918:	39400260 	ldrb	w0, [x19]
    491c:	7103fc1f 	cmp	w0, #0xff
    4920:	54000380 	b.eq	4990 <fwp_mem_free+0x1d0>  // b.none
    4924:	3900027f 	strb	wzr, [x19]
    4928:	b9400ee2 	ldr	w2, [x23, #12]
    492c:	b4000142 	cbz	x2, 4954 <fwp_mem_free+0x194>
    4930:	9115c2a1 	add	x1, x21, #0x570
    4934:	8b160040 	add	x0, x2, x22
    4938:	8b000800 	add	x0, x0, x0, lsl #2
    493c:	f949fc21 	ldr	x1, [x1, #5112]
    4940:	8b140034 	add	x20, x1, x20
    4944:	8b000c20 	add	x0, x1, x0, lsl #3
    4948:	3802869f 	strb	wzr, [x20], #40
    494c:	eb00029f 	cmp	x20, x0
    4950:	54ffffc1 	b.ne	4948 <fwp_mem_free+0x188>  // b.any
    4954:	9115c2a0 	add	x0, x21, #0x570
    4958:	f94a1801 	ldr	x1, [x0, #5168]
    495c:	f949f803 	ldr	x3, [x0, #5104]
    4960:	8b020021 	add	x1, x1, x2
    4964:	f90a1801 	str	x1, [x0, #5168]
    4968:	eb16007f 	cmp	x3, x22
    496c:	54000049 	b.ls	4974 <fwp_mem_free+0x1b4>  // b.plast
    4970:	f909f816 	str	x22, [x0, #5104]
    4974:	9115c2b5 	add	x21, x21, #0x570
    4978:	f949f6a0 	ldr	x0, [x21, #5096]
    497c:	eb16001f 	cmp	x0, x22
    4980:	54fff529 	b.ls	4824 <fwp_mem_free+0x64>  // b.plast
    4984:	a94363f7 	ldp	x23, x24, [sp, #48]
    4988:	f909f6b6 	str	x22, [x21, #5096]
    498c:	17ffffa7 	b	4828 <fwp_mem_free+0x68>
    4990:	aa1303e0 	mov	x0, x19
    4994:	97fffeeb 	bl	4540 <fwp_rc_forget_slot>
    4998:	17ffffe3 	b	4924 <fwp_mem_free+0x164>
    499c:	97fffee9 	bl	4540 <fwp_rc_forget_slot>
    49a0:	17ffffb4 	b	4870 <fwp_mem_free+0xb0>

00000000000049a4 <fwp_heap_alloc_big>:
    49a4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49a8:	910003fd 	mov	x29, sp
    49ac:	a90153f3 	stp	x19, x20, [sp, #16]
    49b0:	a9025bf5 	stp	x21, x22, [sp, #32]
    49b4:	a90363f7 	stp	x23, x24, [sp, #48]
    49b8:	aa0003f7 	mov	x23, x0
    49bc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    49c4:	eb0002ff 	cmp	x23, x0
    49c8:	54000888 	b.hi	4ad8 <fwp_heap_alloc_big+0x134>  // b.pmore
    49cc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    49d0:	8b0002f4 	add	x20, x23, x0
    49d4:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc70>
    49d8:	9115c359 	add	x25, x26, #0x570
    49dc:	d350fe94 	lsr	x20, x20, #16
    49e0:	2a0103f5 	mov	w21, w1
    49e4:	aa1403e0 	mov	x0, x20
    49e8:	97fff9b2 	bl	30b0 <fwp_heap_chunks>
    49ec:	f949ff22 	ldr	x2, [x25, #5112]
    49f0:	8b000813 	add	x19, x0, x0, lsl #2
    49f4:	aa0003f8 	mov	x24, x0
    49f8:	52800043 	mov	w3, #0x2                   	// #2
    49fc:	d37df273 	lsl	x19, x19, #3
    4a00:	d2800021 	mov	x1, #0x1                   	// #1
    4a04:	8b130040 	add	x0, x2, x19
    4a08:	38336843 	strb	w3, [x2, x19]
    4a0c:	39000415 	strb	w21, [x0, #1]
    4a10:	b9000c14 	str	w20, [x0, #12]
    4a14:	f9000817 	str	x23, [x0, #16]
    4a18:	97fffef2 	bl	45e0 <fwp_rc_prepare_chunk>
    4a1c:	f100069f 	cmp	x20, #0x1
    4a20:	54000269 	b.ls	4a6c <fwp_heap_alloc_big+0xc8>  // b.plast
    4a24:	8b180294 	add	x20, x20, x24
    4a28:	9100a273 	add	x19, x19, #0x28
    4a2c:	a90573fb 	stp	x27, x28, [sp, #80]
    4a30:	5280007b 	mov	w27, #0x3                   	// #3
    4a34:	8b140a94 	add	x20, x20, x20, lsl #2
    4a38:	2a1803fc 	mov	w28, w24
    4a3c:	9adb2296 	lsl	x22, x20, x27
    4a40:	f949ff35 	ldr	x21, [x25, #5112]
    4a44:	d2800001 	mov	x1, #0x0                   	// #0
    4a48:	8b1302b4 	add	x20, x21, x19
    4a4c:	aa1403e0 	mov	x0, x20
    4a50:	97fffee4 	bl	45e0 <fwp_rc_prepare_chunk>
    4a54:	38336abb 	strb	w27, [x21, x19]
    4a58:	9100a273 	add	x19, x19, #0x28
    4a5c:	b9000e9c 	str	w28, [x20, #12]
    4a60:	eb1302df 	cmp	x22, x19
    4a64:	54fffee1 	b.ne	4a40 <fwp_heap_alloc_big+0x9c>  // b.any
    4a68:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a6c:	9115c353 	add	x19, x26, #0x570
    4a70:	aa1703e2 	mov	x2, x23
    4a74:	52800001 	mov	w1, #0x0                   	// #0
    4a78:	f949da60 	ldr	x0, [x19, #5040]
    4a7c:	8b184018 	add	x24, x0, x24, lsl #16
    4a80:	aa1803e0 	mov	x0, x24
    4a84:	97fff74f 	bl	27c0 <memset@plt>
    4a88:	f94a1260 	ldr	x0, [x19, #5152]
    4a8c:	ab170000 	adds	x0, x0, x23
    4a90:	54000242 	b.cs	4ad8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4a94:	f94a1661 	ldr	x1, [x19, #5160]
    4a98:	f90a1260 	str	x0, [x19, #5152]
    4a9c:	eb01001f 	cmp	x0, x1
    4aa0:	54000049 	b.ls	4aa8 <fwp_heap_alloc_big+0x104>  // b.plast
    4aa4:	f90a1660 	str	x0, [x19, #5160]
    4aa8:	9115c35a 	add	x26, x26, #0x570
    4aac:	9e6202e0 	scvtf	d0, x23
    4ab0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ab4:	aa1803e0 	mov	x0, x24
    4ab8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4abc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ac0:	1e602820 	fadd	d0, d1, d0
    4ac4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ac8:	fd0a1f40 	str	d0, [x26, #5176]
    4acc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ad0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4ad4:	d65f03c0 	ret
    4ad8:	a90573fb 	stp	x27, x28, [sp, #80]
    4adc:	97fff935 	bl	2fb0 <fwp_heap_oom>

0000000000004ae0 <fwp_heap_alloc_slow>:
    4ae0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4ae4:	910003fd 	mov	x29, sp
    4ae8:	a90153f3 	stp	x19, x20, [sp, #16]
    4aec:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    4af0:	9115c262 	add	x2, x19, #0x570
    4af4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4af8:	aa0003f5 	mov	x21, x0
    4afc:	2a0103f4 	mov	w20, w1
    4b00:	b953a440 	ldr	w0, [x2, #5028]
    4b04:	34000600 	cbz	w0, 4bc4 <fwp_heap_alloc_slow+0xe4>
    4b08:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b0c:	54000628 	b.hi	4bd0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b10:	91003ea0 	add	x0, x21, #0xf
    4b14:	9115c262 	add	x2, x19, #0x570
    4b18:	f9001bf7 	str	x23, [sp, #48]
    4b1c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b20:	8b401040 	add	x0, x2, x0, lsr #4
    4b24:	cb34c084 	sub	x4, x4, w20, sxtw
    4b28:	d37ae484 	lsl	x4, x4, #6
    4b2c:	397e8003 	ldrb	w3, [x0, #4000]
    4b30:	910f0060 	add	x0, x3, #0x3c0
    4b34:	aa0303e1 	mov	x1, x3
    4b38:	8b030463 	add	x3, x3, x3, lsl #1
    4b3c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b40:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b44:	2a1703f6 	mov	w22, w23
    4b48:	f8636844 	ldr	x4, [x2, x3]
    4b4c:	b40004e4 	cbz	x4, 4be8 <fwp_heap_alloc_slow+0x108>
    4b50:	f9400080 	ldr	x0, [x4]
    4b54:	aa2003e0 	mvn	x0, x0
    4b58:	f8236840 	str	x0, [x2, x3]
    4b5c:	7100069f 	cmp	w20, #0x1
    4b60:	aa0403e0 	mov	x0, x4
    4b64:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b68:	52800001 	mov	w1, #0x0                   	// #0
    4b6c:	97fff715 	bl	27c0 <memset@plt>
    4b70:	aa0003e4 	mov	x4, x0
    4b74:	9115c260 	add	x0, x19, #0x570
    4b78:	f94a1001 	ldr	x1, [x0, #5152]
    4b7c:	ab160021 	adds	x1, x1, x22
    4b80:	540005c2 	b.cs	4c38 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b84:	f94a1402 	ldr	x2, [x0, #5160]
    4b88:	f90a1001 	str	x1, [x0, #5152]
    4b8c:	eb02003f 	cmp	x1, x2
    4b90:	54000049 	b.ls	4b98 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b94:	f90a1401 	str	x1, [x0, #5160]
    4b98:	9115c273 	add	x19, x19, #0x570
    4b9c:	1e6302e1 	ucvtf	d1, w23
    4ba0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba4:	aa0403e0 	mov	x0, x4
    4ba8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bac:	f9401bf7 	ldr	x23, [sp, #48]
    4bb0:	1e612800 	fadd	d0, d0, d1
    4bb4:	fd0a1e60 	str	d0, [x19, #5176]
    4bb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bbc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bc0:	d65f03c0 	ret
    4bc4:	97fffc90 	bl	3e04 <fwp_heap_init>
    4bc8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bcc:	54fffa29 	b.ls	4b10 <fwp_heap_alloc_slow+0x30>  // b.plast
    4bd0:	2a1403e1 	mov	w1, w20
    4bd4:	aa1503e0 	mov	x0, x21
    4bd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bdc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4be0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4be4:	17ffff70 	b	49a4 <fwp_heap_alloc_big>
    4be8:	8b030042 	add	x2, x2, x3
    4bec:	f9400444 	ldr	x4, [x2, #8]
    4bf0:	b4000104 	cbz	x4, 4c10 <fwp_heap_alloc_slow+0x130>
    4bf4:	f9400840 	ldr	x0, [x2, #16]
    4bf8:	cb040000 	sub	x0, x0, x4
    4bfc:	eb16001f 	cmp	x0, x22
    4c00:	54000083 	b.cc	4c10 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c04:	8b160080 	add	x0, x4, x22
    4c08:	f9000440 	str	x0, [x2, #8]
    4c0c:	17ffffd4 	b	4b5c <fwp_heap_alloc_slow+0x7c>
    4c10:	52800302 	mov	w2, #0x18                  	// #24
    4c14:	52807804 	mov	w4, #0x3c0                 	// #960
    4c18:	9115c260 	add	x0, x19, #0x570
    4c1c:	9ba27c23 	umull	x3, w1, w2
    4c20:	2a1403e2 	mov	w2, w20
    4c24:	9b240e84 	smaddl	x4, w20, w4, x3
    4c28:	8b040000 	add	x0, x0, x4
    4c2c:	97fffeb5 	bl	4700 <fwp_heap_refill>
    4c30:	aa0003e4 	mov	x4, x0
    4c34:	17ffffca 	b	4b5c <fwp_heap_alloc_slow+0x7c>
    4c38:	97fff8de 	bl	2fb0 <fwp_heap_oom>
    4c3c:	d503201f 	nop

0000000000004c40 <fwp_heap_alloc>:
    4c40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c44:	f140101f 	cmp	x0, #0x4, lsl #12
    4c48:	910003fd 	mov	x29, sp
    4c4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c50:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc70>
    4c54:	9115c293 	add	x19, x20, #0x570
    4c58:	b953a662 	ldr	w2, [x19, #5028]
    4c5c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c60:	54000640 	b.eq	4d28 <fwp_heap_alloc+0xe8>  // b.none
    4c64:	91003c03 	add	x3, x0, #0xf
    4c68:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c6c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c70:	8b431263 	add	x3, x19, x3, lsr #4
    4c74:	cb21c042 	sub	x2, x2, w1, sxtw
    4c78:	d37ae442 	lsl	x2, x2, #6
    4c7c:	397e8063 	ldrb	w3, [x3, #4000]
    4c80:	910f0064 	add	x4, x3, #0x3c0
    4c84:	8b030463 	add	x3, x3, x3, lsl #1
    4c88:	8b030c43 	add	x3, x2, x3, lsl #3
    4c8c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c90:	2a1603f5 	mov	w21, w22
    4c94:	f8636a64 	ldr	x4, [x19, x3]
    4c98:	b4000384 	cbz	x4, 4d08 <fwp_heap_alloc+0xc8>
    4c9c:	f9400085 	ldr	x5, [x4]
    4ca0:	7100043f 	cmp	w1, #0x1
    4ca4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ca8:	aa0403e0 	mov	x0, x4
    4cac:	aa2503e5 	mvn	x5, x5
    4cb0:	52800001 	mov	w1, #0x0                   	// #0
    4cb4:	f8236a65 	str	x5, [x19, x3]
    4cb8:	97fff6c2 	bl	27c0 <memset@plt>
    4cbc:	aa0003e4 	mov	x4, x0
    4cc0:	f94a1260 	ldr	x0, [x19, #5152]
    4cc4:	ab150000 	adds	x0, x0, x21
    4cc8:	54000442 	b.cs	4d50 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ccc:	f94a1661 	ldr	x1, [x19, #5160]
    4cd0:	f90a1260 	str	x0, [x19, #5152]
    4cd4:	eb01001f 	cmp	x0, x1
    4cd8:	54000049 	b.ls	4ce0 <fwp_heap_alloc+0xa0>  // b.plast
    4cdc:	f90a1660 	str	x0, [x19, #5160]
    4ce0:	9115c294 	add	x20, x20, #0x570
    4ce4:	1e6302c1 	ucvtf	d1, w22
    4ce8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cec:	aa0403e0 	mov	x0, x4
    4cf0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4cf4:	1e612800 	fadd	d0, d0, d1
    4cf8:	fd0a1e80 	str	d0, [x20, #5176]
    4cfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d04:	d65f03c0 	ret
    4d08:	8b030263 	add	x3, x19, x3
    4d0c:	f9400464 	ldr	x4, [x3, #8]
    4d10:	b40000a4 	cbz	x4, 4d24 <fwp_heap_alloc+0xe4>
    4d14:	f9400862 	ldr	x2, [x3, #16]
    4d18:	cb040042 	sub	x2, x2, x4
    4d1c:	eb15005f 	cmp	x2, x21
    4d20:	540000a2 	b.cs	4d34 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d30:	17ffff6c 	b	4ae0 <fwp_heap_alloc_slow>
    4d34:	7100043f 	cmp	w1, #0x1
    4d38:	8b150085 	add	x5, x4, x21
    4d3c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d40:	52800001 	mov	w1, #0x0                   	// #0
    4d44:	aa0403e0 	mov	x0, x4
    4d48:	f9000465 	str	x5, [x3, #8]
    4d4c:	17ffffdb 	b	4cb8 <fwp_heap_alloc+0x78>
    4d50:	97fff898 	bl	2fb0 <fwp_heap_oom>

0000000000004d54 <fwp_apply>:
    4d54:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d58:	aa0003e6 	mov	x6, x0
    4d5c:	910003fd 	mov	x29, sp
    4d60:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d64:	f947f463 	ldr	x3, [x3, #4072]
    4d68:	a90153f3 	stp	x19, x20, [sp, #16]
    4d6c:	aa0203f4 	mov	x20, x2
    4d70:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d74:	2a0103f5 	mov	w21, w1
    4d78:	52800033 	mov	w19, #0x1                   	// #1
    4d7c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d80:	900000f7 	adrp	x23, 20000 <__data_start>
    4d84:	910102f7 	add	x23, x23, #0x40
    4d88:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d8c:	d100c3ff 	sub	sp, sp, #0x30
    4d90:	f9400060 	ldr	x0, [x3]
    4d94:	f81f83a0 	stur	x0, [x29, #-8]
    4d98:	d2800000 	mov	x0, #0x0                   	// #0
    4d9c:	294058c3 	ldp	w3, w22, [x6]
    4da0:	910003f8 	mov	x24, sp
    4da4:	f9401ee0 	ldr	x0, [x23, #56]
    4da8:	710002df 	cmp	w22, #0x0
    4dac:	d37be863 	lsl	x3, x3, #5
    4db0:	8b030007 	add	x7, x0, x3
    4db4:	b8636819 	ldr	w25, [x0, x3]
    4db8:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4dbc:	54000163 	b.cc	4de8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4dc0:	f94004e3 	ldr	x3, [x7, #8]
    4dc4:	34000bd9 	cbz	w25, 4f3c <fwp_apply+0x1e8>
    4dc8:	aa1403e0 	mov	x0, x20
    4dcc:	d63f0060 	blr	x3
    4dd0:	aa0003e6 	mov	x6, x0
    4dd4:	6b1902bf 	cmp	w21, w25
    4dd8:	54000940 	b.eq	4f00 <fwp_apply+0x1ac>  // b.none
    4ddc:	8b394e94 	add	x20, x20, w25, uxtw #3
    4de0:	4b1902b5 	sub	w21, w21, w25
    4de4:	17ffffee 	b	4d9c <fwp_apply+0x48>
    4de8:	0b1602ba 	add	w26, w21, w22
    4dec:	6b19035f 	cmp	w26, w25
    4df0:	54000543 	b.cc	4e98 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4df4:	7100033f 	cmp	w25, #0x0
    4df8:	4b16033a 	sub	w26, w25, w22
    4dfc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4e00:	d37df000 	lsl	x0, x0, #3
    4e04:	91003c00 	add	x0, x0, #0xf
    4e08:	92704c01 	and	x1, x0, #0xfffff0000
    4e0c:	927c7c00 	and	x0, x0, #0xffffffff0
    4e10:	cb2163e1 	sub	x1, sp, x1
    4e14:	eb2163ff 	cmp	sp, x1
    4e18:	540000a0 	b.eq	4e2c <fwp_apply+0xd8>  // b.none
    4e1c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4e20:	f90203ff 	str	xzr, [sp, #1024]
    4e24:	eb2163ff 	cmp	sp, x1
    4e28:	54ffffa1 	b.ne	4e1c <fwp_apply+0xc8>  // b.any
    4e2c:	92403c00 	and	x0, x0, #0xffff
    4e30:	cb2063ff 	sub	sp, sp, x0
    4e34:	f90003ff 	str	xzr, [sp]
    4e38:	f110001f 	cmp	x0, #0x400
    4e3c:	54000962 	b.cs	4f68 <fwp_apply+0x214>  // b.hs, b.nlast
    4e40:	910020c6 	add	x6, x6, #0x8
    4e44:	910043e0 	add	x0, sp, #0x10
    4e48:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4e4c:	d2800003 	mov	x3, #0x0                   	// #0
    4e50:	340000f6 	cbz	w22, 4e6c <fwp_apply+0x118>
    4e54:	d503201f 	nop
    4e58:	f86368c4 	ldr	x4, [x6, x3]
    4e5c:	f8236804 	str	x4, [x0, x3]
    4e60:	91002063 	add	x3, x3, #0x8
    4e64:	eb0300bf 	cmp	x5, x3
    4e68:	54ffff81 	b.ne	4e58 <fwp_apply+0x104>  // b.any
    4e6c:	3400013a 	cbz	w26, 4e90 <fwp_apply+0x13c>
    4e70:	2a1a03e6 	mov	w6, w26
    4e74:	d2800003 	mov	x3, #0x0                   	// #0
    4e78:	0b0302c4 	add	w4, w22, w3
    4e7c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e80:	91000463 	add	x3, x3, #0x1
    4e84:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e88:	eb0300df 	cmp	x6, x3
    4e8c:	54ffff61 	b.ne	4e78 <fwp_apply+0x124>  // b.any
    4e90:	f94004e3 	ldr	x3, [x7, #8]
    4e94:	1400002c 	b	4f44 <fwp_apply+0x1f0>
    4e98:	11000740 	add	w0, w26, #0x1
    4e9c:	52800041 	mov	w1, #0x2                   	// #2
    4ea0:	f81e83a6 	stur	x6, [x29, #-24]
    4ea4:	d37df000 	lsl	x0, x0, #3
    4ea8:	97ffff66 	bl	4c40 <fwp_heap_alloc>
    4eac:	f85e83a6 	ldur	x6, [x29, #-24]
    4eb0:	aa0003f3 	mov	x19, x0
    4eb4:	b94000c1 	ldr	w1, [x6]
    4eb8:	29006801 	stp	w1, w26, [x0]
    4ebc:	340000b6 	cbz	w22, 4ed0 <fwp_apply+0x17c>
    4ec0:	910020c1 	add	x1, x6, #0x8
    4ec4:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4ec8:	91002000 	add	x0, x0, #0x8
    4ecc:	97fff5e5 	bl	2660 <memmove@plt>
    4ed0:	2a1503e3 	mov	w3, w21
    4ed4:	d2800000 	mov	x0, #0x0                   	// #0
    4ed8:	34000135 	cbz	w21, 4efc <fwp_apply+0x1a8>
    4edc:	d503201f 	nop
    4ee0:	0b0002c1 	add	w1, w22, w0
    4ee4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4ee8:	8b010e61 	add	x1, x19, x1, lsl #3
    4eec:	91000400 	add	x0, x0, #0x1
    4ef0:	f9000422 	str	x2, [x1, #8]
    4ef4:	eb00007f 	cmp	x3, x0
    4ef8:	54ffff41 	b.ne	4ee0 <fwp_apply+0x18c>  // b.any
    4efc:	aa1303e6 	mov	x6, x19
    4f00:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4f04:	f947f400 	ldr	x0, [x0, #4072]
    4f08:	f85f83a2 	ldur	x2, [x29, #-8]
    4f0c:	f9400001 	ldr	x1, [x0]
    4f10:	eb010042 	subs	x2, x2, x1
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	540002c1 	b.ne	4f70 <fwp_apply+0x21c>  // b.any
    4f1c:	910003bf 	mov	sp, x29
    4f20:	aa0603e0 	mov	x0, x6
    4f24:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f2c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f30:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f34:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4f38:	d65f03c0 	ret
    4f3c:	d10043a0 	sub	x0, x29, #0x10
    4f40:	5280001a 	mov	w26, #0x0                   	// #0
    4f44:	d63f0060 	blr	x3
    4f48:	aa0003e6 	mov	x6, x0
    4f4c:	6b1a02bf 	cmp	w21, w26
    4f50:	54fffd80 	b.eq	4f00 <fwp_apply+0x1ac>  // b.none
    4f54:	0b1602b6 	add	w22, w21, w22
    4f58:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f5c:	4b1902d5 	sub	w21, w22, w25
    4f60:	9100031f 	mov	sp, x24
    4f64:	17ffff8e 	b	4d9c <fwp_apply+0x48>
    4f68:	f90203ff 	str	xzr, [sp, #1024]
    4f6c:	17ffffb5 	b	4e40 <fwp_apply+0xec>
    4f70:	97fff620 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f74 <fwp_p_ad_push>:
    4f74:	f100001f 	cmp	x0, #0x0
    4f78:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4f7c:	54000e8b 	b.lt	514c <fwp_p_ad_push+0x1d8>  // b.tstop
    4f80:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f84:	aa0003e4 	mov	x4, x0
    4f88:	910003fd 	mov	x29, sp
    4f8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f90:	aa0003f5 	mov	x21, x0
    4f94:	aa020000 	orr	x0, x0, x2
    4f98:	a90363f7 	stp	x23, x24, [sp, #48]
    4f9c:	aa0203f7 	mov	x23, x2
    4fa0:	6d0627e8 	stp	d8, d9, [sp, #96]
    4fa4:	9e670029 	fmov	d9, x1
    4fa8:	9e670068 	fmov	d8, x3
    4fac:	b6f80900 	tbz	x0, #63, 50cc <fwp_p_ad_push+0x158>
    4fb0:	a90153f3 	stp	x19, x20, [sp, #16]
    4fb4:	9360fc80 	asr	x0, x4, #32
    4fb8:	b6f800c4 	tbz	x4, #63, 4fd0 <fwp_p_ad_push+0x5c>
    4fbc:	1e604109 	fmov	d9, d8
    4fc0:	2f00e408 	movi	d8, #0x0
    4fc4:	9360fc40 	asr	x0, x2, #32
    4fc8:	aa0203f5 	mov	x21, x2
    4fcc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4fd0:	97fffa18 	bl	3830 <fwp_tape_of>
    4fd4:	aa0003f3 	mov	x19, x0
    4fd8:	f9403000 	ldr	x0, [x0, #96]
    4fdc:	b5001280 	cbnz	x0, 522c <fwp_p_ad_push+0x2b8>
    4fe0:	f9400a76 	ldr	x22, [x19, #16]
    4fe4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4fe8:	eb0002df 	cmp	x22, x0
    4fec:	54000e2c 	b.gt	51b0 <fwp_p_ad_push+0x23c>
    4ff0:	eb3542df 	cmp	x22, w21, uxtw
    4ff4:	54000d4d 	b.le	519c <fwp_p_ad_push+0x228>
    4ff8:	b7f80077 	tbnz	x23, #63, 5004 <fwp_p_ad_push+0x90>
    4ffc:	eb3742df 	cmp	x22, w23, uxtw
    5000:	54000ced 	b.le	519c <fwp_p_ad_push+0x228>
    5004:	f9400678 	ldr	x24, [x19, #8]
    5008:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    500c:	cb1802d8 	sub	x24, x22, x24
    5010:	91000701 	add	x1, x24, #0x1
    5014:	eb00003f 	cmp	x1, x0
    5018:	54000cc8 	b.hi	51b0 <fwp_p_ad_push+0x23c>  // b.pmore
    501c:	a9418274 	ldp	x20, x0, [x19, #24]
    5020:	a90573fb 	stp	x27, x28, [sp, #80]
    5024:	eb14003f 	cmp	x1, x20
    5028:	5400068d 	b.le	50f8 <fwp_p_ad_push+0x184>
    502c:	f100029f 	cmp	x20, #0x0
    5030:	d2800803 	mov	x3, #0x40                  	// #64
    5034:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5038:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    503c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5040:	eb14003f 	cmp	x1, x20
    5044:	5400008d 	b.le	5054 <fwp_p_ad_push+0xe0>
    5048:	eb02029f 	cmp	x20, x2
    504c:	5400052d 	b.le	50f0 <fwp_p_ad_push+0x17c>
    5050:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5054:	d37df299 	lsl	x25, x20, #3
    5058:	aa1903e1 	mov	x1, x25
    505c:	97fff5e1 	bl	27e0 <realloc@plt>
    5060:	aa0003e1 	mov	x1, x0
    5064:	b4000b00 	cbz	x0, 51c4 <fwp_p_ad_push+0x250>
    5068:	f9400e62 	ldr	x2, [x19, #24]
    506c:	f9001261 	str	x1, [x19, #32]
    5070:	f9401a60 	ldr	x0, [x19, #48]
    5074:	d37cee9a 	lsl	x26, x20, #4
    5078:	8b020821 	add	x1, x1, x2, lsl #2
    507c:	f9001661 	str	x1, [x19, #40]
    5080:	aa1a03e1 	mov	x1, x26
    5084:	97fff5d7 	bl	27e0 <realloc@plt>
    5088:	aa0003e2 	mov	x2, x0
    508c:	b40009c0 	cbz	x0, 51c4 <fwp_p_ad_push+0x250>
    5090:	f9400e61 	ldr	x1, [x19, #24]
    5094:	d37df31b 	lsl	x27, x24, #3
    5098:	d37ef685 	lsl	x5, x20, #2
    509c:	d37ef71c 	lsl	x28, x24, #2
    50a0:	8b190004 	add	x4, x0, x25
    50a4:	8b010c01 	add	x1, x0, x1, lsl #3
    50a8:	a9030660 	stp	x0, x1, [x19, #48]
    50ac:	b5000558 	cbnz	x24, 5154 <fwp_p_ad_push+0x1e0>
    50b0:	f9001e64 	str	x4, [x19, #56]
    50b4:	f9401260 	ldr	x0, [x19, #32]
    50b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    50bc:	8b050001 	add	x1, x0, x5
    50c0:	f9000e74 	str	x20, [x19, #24]
    50c4:	f9001661 	str	x1, [x19, #40]
    50c8:	14000010 	b	5108 <fwp_p_ad_push+0x194>
    50cc:	9360fc40 	asr	x0, x2, #32
    50d0:	a90153f3 	stp	x19, x20, [sp, #16]
    50d4:	eb84801f 	cmp	x0, x4, asr #32
    50d8:	54fff7c0 	b.eq	4fd0 <fwp_p_ad_push+0x5c>  // b.none
    50dc:	90000040 	adrp	x0, d000 <__modti3+0x230>
    50e0:	91118000 	add	x0, x0, #0x460
    50e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    50e8:	a90573fb 	stp	x27, x28, [sp, #80]
    50ec:	97fff905 	bl	3500 <fwp_trap>
    50f0:	d37ffa94 	lsl	x20, x20, #1
    50f4:	17ffffd3 	b	5040 <fwp_p_ad_push+0xcc>
    50f8:	a9428a61 	ldp	x1, x2, [x19, #40]
    50fc:	d37ef71c 	lsl	x28, x24, #2
    5100:	f9401e64 	ldr	x4, [x19, #56]
    5104:	d37df31b 	lsl	x27, x24, #3
    5108:	b83c6815 	str	w21, [x0, x28]
    510c:	f10002ff 	cmp	x23, #0x0
    5110:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5114:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5118:	fc3b6849 	str	d9, [x2, x27]
    511c:	aa1602a0 	orr	x0, x21, x22
    5120:	b83c6837 	str	w23, [x1, x28]
    5124:	910006d6 	add	x22, x22, #0x1
    5128:	a94363f7 	ldp	x23, x24, [sp, #48]
    512c:	fc3b6888 	str	d8, [x4, x27]
    5130:	a94573fb 	ldp	x27, x28, [sp, #80]
    5134:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5138:	f9000a76 	str	x22, [x19, #16]
    513c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5140:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5144:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5148:	d65f03c0 	ret
    514c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5150:	d65f03c0 	ret
    5154:	eb1a033f 	cmp	x25, x26
    5158:	aa0403e0 	mov	x0, x4
    515c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5160:	aa1b03e2 	mov	x2, x27
    5164:	cb190063 	sub	x3, x3, x25
    5168:	f9003fe5 	str	x5, [sp, #120]
    516c:	97fff609 	bl	2990 <__memmove_chk@plt>
    5170:	a9420660 	ldp	x0, x1, [x19, #32]
    5174:	aa1c03e2 	mov	x2, x28
    5178:	f9401a63 	ldr	x3, [x19, #48]
    517c:	f9403fe5 	ldr	x5, [sp, #120]
    5180:	8b190063 	add	x3, x3, x25
    5184:	f9001e63 	str	x3, [x19, #56]
    5188:	8b050000 	add	x0, x0, x5
    518c:	97fff535 	bl	2660 <memmove@plt>
    5190:	a9431262 	ldp	x2, x4, [x19, #48]
    5194:	f9403fe5 	ldr	x5, [sp, #120]
    5198:	17ffffc7 	b	50b4 <fwp_p_ad_push+0x140>
    519c:	90000040 	adrp	x0, d000 <__modti3+0x230>
    51a0:	9113e000 	add	x0, x0, #0x4f8
    51a4:	a9046bf9 	stp	x25, x26, [sp, #64]
    51a8:	a90573fb 	stp	x27, x28, [sp, #80]
    51ac:	97fff8d5 	bl	3500 <fwp_trap>
    51b0:	90000040 	adrp	x0, d000 <__modti3+0x230>
    51b4:	91136000 	add	x0, x0, #0x4d8
    51b8:	a9046bf9 	stp	x25, x26, [sp, #64]
    51bc:	a90573fb 	stp	x27, x28, [sp, #80]
    51c0:	97fff8d0 	bl	3500 <fwp_trap>
    51c4:	aa1303e0 	mov	x0, x19
    51c8:	97fff752 	bl	2f10 <fwp_tape_unlink_scope>
    51cc:	f9401260 	ldr	x0, [x19, #32]
    51d0:	97fff5b8 	bl	28b0 <free@plt>
    51d4:	f9401a60 	ldr	x0, [x19, #48]
    51d8:	97fff5b6 	bl	28b0 <free@plt>
    51dc:	f9402260 	ldr	x0, [x19, #64]
    51e0:	97fff5b4 	bl	28b0 <free@plt>
    51e4:	f9000e7f 	str	xzr, [x19, #24]
    51e8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    51ec:	f947e821 	ldr	x1, [x1, #4048]
    51f0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    51f4:	d2800262 	mov	x2, #0x13                  	// #19
    51f8:	4f000400 	movi	v0.4s, #0x0
    51fc:	90000040 	adrp	x0, d000 <__modti3+0x230>
    5200:	f9400023 	ldr	x3, [x1]
    5204:	b900067f 	str	wzr, [x19, #4]
    5208:	d2800021 	mov	x1, #0x1                   	// #1
    520c:	9105e000 	add	x0, x0, #0x178
    5210:	3c808260 	stur	q0, [x19, #8]
    5214:	ad010260 	stp	q0, q0, [x19, #32]
    5218:	97fff5b6 	bl	28f0 <fwrite@plt>
    521c:	d2800000 	mov	x0, #0x0                   	// #0
    5220:	97fff5c0 	bl	2920 <fflush@plt>
    5224:	52800cc0 	mov	w0, #0x66                  	// #102
    5228:	97fff5ce 	bl	2960 <_Exit@plt>
    522c:	90000040 	adrp	x0, d000 <__modti3+0x230>
    5230:	9112a000 	add	x0, x0, #0x4a8
    5234:	a9046bf9 	stp	x25, x26, [sp, #64]
    5238:	a90573fb 	stp	x27, x28, [sp, #80]
    523c:	97fff8b1 	bl	3500 <fwp_trap>

0000000000005240 <w107>:
    5240:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5244:	9e660003 	fmov	x3, d0
    5248:	aa0003e2 	mov	x2, x0
    524c:	910003fd 	mov	x29, sp
    5250:	fd001fea 	str	d10, [sp, #56]
    5254:	1e60400a 	fmov	d10, d0
    5258:	6d0427e8 	stp	d8, d9, [sp, #64]
    525c:	1e604028 	fmov	d8, d1
    5260:	1e600809 	fmul	d9, d0, d0
    5264:	a90153f3 	stp	x19, x20, [sp, #16]
    5268:	aa0103f4 	mov	x20, x1
    526c:	aa0303e1 	mov	x1, x3
    5270:	aa0003f3 	mov	x19, x0
    5274:	a9025bf5 	stp	x21, x22, [sp, #32]
    5278:	f9001bf7 	str	x23, [sp, #48]
    527c:	97ffff3e 	bl	4f74 <fwp_p_ad_push>
    5280:	aa0003e5 	mov	x5, x0
    5284:	97fffb50 	bl	3fc4 <caf61>
    5288:	9e670000 	fmov	d0, x0
    528c:	97fffb4e 	bl	3fc4 <caf61>
    5290:	1e693908 	fsub	d8, d8, d9
    5294:	aa1403e2 	mov	x2, x20
    5298:	1e614000 	fneg	d0, d0
    529c:	aa0003e3 	mov	x3, x0
    52a0:	aa0503e0 	mov	x0, x5
    52a4:	9e660117 	fmov	x23, d8
    52a8:	9e660001 	fmov	x1, d0
    52ac:	97ffff32 	bl	4f74 <fwp_p_ad_push>
    52b0:	aa0003f5 	mov	x21, x0
    52b4:	97fffb44 	bl	3fc4 <caf61>
    52b8:	9e670000 	fmov	d0, x0
    52bc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    52c0:	97fffb41 	bl	3fc4 <caf61>
    52c4:	1e614000 	fneg	d0, d0
    52c8:	aa0003e3 	mov	x3, x0
    52cc:	1e6a3929 	fsub	d9, d9, d10
    52d0:	aa1303e0 	mov	x0, x19
    52d4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    52d8:	9e660001 	fmov	x1, d0
    52dc:	9e660136 	fmov	x22, d9
    52e0:	97ffff25 	bl	4f74 <fwp_p_ad_push>
    52e4:	1e680908 	fmul	d8, d8, d8
    52e8:	aa0003f4 	mov	x20, x0
    52ec:	aa1703e3 	mov	x3, x23
    52f0:	aa1703e1 	mov	x1, x23
    52f4:	aa1503e2 	mov	x2, x21
    52f8:	aa1503e0 	mov	x0, x21
    52fc:	97ffff1e 	bl	4f74 <fwp_p_ad_push>
    5300:	aa0003e2 	mov	x2, x0
    5304:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5308:	9e670020 	fmov	d0, x1
    530c:	9e660101 	fmov	x1, d8
    5310:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5314:	1e600908 	fmul	d8, d8, d0
    5318:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    531c:	97ffff16 	bl	4f74 <fwp_p_ad_push>
    5320:	1e690929 	fmul	d9, d9, d9
    5324:	aa1603e3 	mov	x3, x22
    5328:	aa1603e1 	mov	x1, x22
    532c:	aa1403e2 	mov	x2, x20
    5330:	aa0003f3 	mov	x19, x0
    5334:	aa1403e0 	mov	x0, x20
    5338:	97ffff0f 	bl	4f74 <fwp_p_ad_push>
    533c:	aa0003e5 	mov	x5, x0
    5340:	97fffb21 	bl	3fc4 <caf61>
    5344:	aa0003e6 	mov	x6, x0
    5348:	97fffb1f 	bl	3fc4 <caf61>
    534c:	1e692908 	fadd	d8, d8, d9
    5350:	aa1303e2 	mov	x2, x19
    5354:	aa0603e1 	mov	x1, x6
    5358:	aa0003e3 	mov	x3, x0
    535c:	aa0503e0 	mov	x0, x5
    5360:	97ffff05 	bl	4f74 <fwp_p_ad_push>
    5364:	aa0003e1 	mov	x1, x0
    5368:	a94153f3 	ldp	x19, x20, [sp, #16]
    536c:	9e660100 	fmov	x0, d8
    5370:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5374:	f9401bf7 	ldr	x23, [sp, #48]
    5378:	fd401fea 	ldr	d10, [sp, #56]
    537c:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5380:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5384:	d65f03c0 	ret
    5388:	d503201f 	nop
    538c:	d503201f 	nop

0000000000005390 <w164.constprop.0>:
    5390:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5394:	910003fd 	mov	x29, sp
    5398:	a9025bf5 	stp	x21, x22, [sp, #32]
    539c:	fd001be8 	str	d8, [sp, #48]
    53a0:	f9400015 	ldr	x21, [x0]
    53a4:	b40003b5 	cbz	x21, 5418 <w164.constprop.0+0x88>
    53a8:	2f00e408 	movi	d8, #0x0
    53ac:	91002016 	add	x22, x0, #0x8
    53b0:	a90153f3 	stp	x19, x20, [sp, #16]
    53b4:	91004014 	add	x20, x0, #0x10
    53b8:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    53bc:	d2800013 	mov	x19, #0x0                   	// #0
    53c0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    53c4:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    53c8:	97fffaff 	bl	3fc4 <caf61>
    53cc:	aa0003e6 	mov	x6, x0
    53d0:	97fffafd 	bl	3fc4 <caf61>
    53d4:	1e602908 	fadd	d8, d8, d0
    53d8:	aa0003e3 	mov	x3, x0
    53dc:	aa0703e2 	mov	x2, x7
    53e0:	aa0503e0 	mov	x0, x5
    53e4:	aa0603e1 	mov	x1, x6
    53e8:	91000a73 	add	x19, x19, #0x2
    53ec:	97fffee2 	bl	4f74 <fwp_p_ad_push>
    53f0:	aa0003e5 	mov	x5, x0
    53f4:	eb1302bf 	cmp	x21, x19
    53f8:	54fffe48 	b.hi	53c0 <w164.constprop.0+0x30>  // b.pmore
    53fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5400:	9e660100 	fmov	x0, d8
    5404:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5408:	aa0503e1 	mov	x1, x5
    540c:	fd401be8 	ldr	d8, [sp, #48]
    5410:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5414:	d65f03c0 	ret
    5418:	2f00e408 	movi	d8, #0x0
    541c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    5420:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5424:	aa0503e1 	mov	x1, x5
    5428:	9e660100 	fmov	x0, d8
    542c:	fd401be8 	ldr	d8, [sp, #48]
    5430:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5434:	d65f03c0 	ret
    5438:	d503201f 	nop
    543c:	d503201f 	nop

0000000000005440 <fwp_data.part.0.constprop.0>:
    5440:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5444:	910003fd 	mov	x29, sp
    5448:	a90153f3 	stp	x19, x20, [sp, #16]
    544c:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc70>
    5450:	9115c283 	add	x3, x20, #0x570
    5454:	a9025bf5 	stp	x21, x22, [sp, #32]
    5458:	aa0103f5 	mov	x21, x1
    545c:	b953a461 	ldr	w1, [x3, #5028]
    5460:	a90363f7 	stp	x23, x24, [sp, #48]
    5464:	2a0003f8 	mov	w24, w0
    5468:	34000701 	cbz	w1, 5548 <fwp_data.part.0.constprop.0+0x108>
    546c:	397e8862 	ldrb	w2, [x3, #4002]
    5470:	910f0040 	add	x0, x2, #0x3c0
    5474:	8b020442 	add	x2, x2, x2, lsl #1
    5478:	d37df042 	lsl	x2, x2, #3
    547c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5480:	2a1703f6 	mov	w22, w23
    5484:	f8626873 	ldr	x19, [x3, x2]
    5488:	b40004d3 	cbz	x19, 5520 <fwp_data.part.0.constprop.0+0xe0>
    548c:	f9400260 	ldr	x0, [x19]
    5490:	aa2003e0 	mvn	x0, x0
    5494:	f8226860 	str	x0, [x3, x2]
    5498:	f10062df 	cmp	x22, #0x18
    549c:	540000e9 	b.ls	54b8 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    54a0:	d10066c2 	sub	x2, x22, #0x19
    54a4:	91006260 	add	x0, x19, #0x18
    54a8:	927df042 	and	x2, x2, #0xfffffffffffffff8
    54ac:	52800001 	mov	w1, #0x0                   	// #0
    54b0:	91002042 	add	x2, x2, #0x8
    54b4:	97fff4c3 	bl	27c0 <memset@plt>
    54b8:	9115c282 	add	x2, x20, #0x570
    54bc:	f94a1041 	ldr	x1, [x2, #5152]
    54c0:	ab160021 	adds	x1, x1, x22
    54c4:	540004c2 	b.cs	555c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    54c8:	f94a1440 	ldr	x0, [x2, #5160]
    54cc:	f90a1041 	str	x1, [x2, #5152]
    54d0:	eb00003f 	cmp	x1, x0
    54d4:	54000049 	b.ls	54dc <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    54d8:	f90a1441 	str	x1, [x2, #5160]
    54dc:	9115c294 	add	x20, x20, #0x570
    54e0:	1e6302e1 	ucvtf	d1, w23
    54e4:	fd4a1e80 	ldr	d0, [x20, #5176]
    54e8:	1e612800 	fadd	d0, d0, d1
    54ec:	fd0a1e80 	str	d0, [x20, #5176]
    54f0:	52800041 	mov	w1, #0x2                   	// #2
    54f4:	29000678 	stp	w24, w1, [x19]
    54f8:	aa1303e0 	mov	x0, x19
    54fc:	f94002a1 	ldr	x1, [x21]
    5500:	f9000661 	str	x1, [x19, #8]
    5504:	f94006a1 	ldr	x1, [x21, #8]
    5508:	f9000a61 	str	x1, [x19, #16]
    550c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5510:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5514:	a94363f7 	ldp	x23, x24, [sp, #48]
    5518:	a8c47bfd 	ldp	x29, x30, [sp], #64
    551c:	d65f03c0 	ret
    5520:	8b020063 	add	x3, x3, x2
    5524:	f9400473 	ldr	x19, [x3, #8]
    5528:	b4000113 	cbz	x19, 5548 <fwp_data.part.0.constprop.0+0x108>
    552c:	f9400860 	ldr	x0, [x3, #16]
    5530:	cb130000 	sub	x0, x0, x19
    5534:	eb0002df 	cmp	x22, x0
    5538:	54000088 	b.hi	5548 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    553c:	8b160260 	add	x0, x19, x22
    5540:	f9000460 	str	x0, [x3, #8]
    5544:	17ffffd5 	b	5498 <fwp_data.part.0.constprop.0+0x58>
    5548:	52800001 	mov	w1, #0x0                   	// #0
    554c:	d2800300 	mov	x0, #0x18                  	// #24
    5550:	97fffdbc 	bl	4c40 <fwp_heap_alloc>
    5554:	aa0003f3 	mov	x19, x0
    5558:	17ffffe6 	b	54f0 <fwp_data.part.0.constprop.0+0xb0>
    555c:	97fff695 	bl	2fb0 <fwp_heap_oom>

0000000000005560 <fwp_rc_share>:
    5560:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    5564:	9115c042 	add	x2, x2, #0x570
    5568:	f949d843 	ldr	x3, [x2, #5040]
    556c:	f949ec41 	ldr	x1, [x2, #5080]
    5570:	cb030000 	sub	x0, x0, x3
    5574:	eb01401f 	cmp	x0, x1, lsl #16
    5578:	540002c2 	b.cs	55d0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    557c:	d350fc01 	lsr	x1, x0, #16
    5580:	f949fc44 	ldr	x4, [x2, #5112]
    5584:	8b010821 	add	x1, x1, x1, lsl #2
    5588:	d37df021 	lsl	x1, x1, #3
    558c:	8b010083 	add	x3, x4, x1
    5590:	f9401062 	ldr	x2, [x3, #32]
    5594:	b40001e2 	cbz	x2, 55d0 <fwp_rc_share+0x70>
    5598:	38616881 	ldrb	w1, [x4, x1]
    559c:	7100083f 	cmp	w1, #0x2
    55a0:	540001a0 	b.eq	55d4 <fwp_rc_share+0x74>  // b.none
    55a4:	7100043f 	cmp	w1, #0x1
    55a8:	54000141 	b.ne	55d0 <fwp_rc_share+0x70>  // b.any
    55ac:	29430464 	ldp	w4, w1, [x3, #24]
    55b0:	92403c00 	and	x0, x0, #0xffff
    55b4:	9b047c00 	mul	x0, x0, x4
    55b8:	d360fc00 	lsr	x0, x0, #32
    55bc:	eb01001f 	cmp	x0, x1
    55c0:	54000082 	b.cs	55d0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    55c4:	8b000042 	add	x2, x2, x0
    55c8:	39400040 	ldrb	w0, [x2]
    55cc:	350000a0 	cbnz	w0, 55e0 <fwp_rc_share+0x80>
    55d0:	d65f03c0 	ret
    55d4:	72003c1f 	tst	w0, #0xffff
    55d8:	54ffff80 	b.eq	55c8 <fwp_rc_share+0x68>  // b.none
    55dc:	d65f03c0 	ret
    55e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    55e4:	90000040 	adrp	x0, d000 <__modti3+0x230>
    55e8:	91146000 	add	x0, x0, #0x518
    55ec:	910003fd 	mov	x29, sp
    55f0:	97fff7c4 	bl	3500 <fwp_trap>

00000000000055f4 <fwp_rc_fresh>:
    55f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    55f8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    55fc:	9115c063 	add	x3, x3, #0x570
    5600:	910003fd 	mov	x29, sp
    5604:	a90153f3 	stp	x19, x20, [sp, #16]
    5608:	aa0003f3 	mov	x19, x0
    560c:	f949d861 	ldr	x1, [x3, #5040]
    5610:	f949ec60 	ldr	x0, [x3, #5080]
    5614:	cb010261 	sub	x1, x19, x1
    5618:	eb00403f 	cmp	x1, x0, lsl #16
    561c:	54000322 	b.cs	5680 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5620:	d350fc22 	lsr	x2, x1, #16
    5624:	f949fc63 	ldr	x3, [x3, #5112]
    5628:	8b020842 	add	x2, x2, x2, lsl #2
    562c:	d37df042 	lsl	x2, x2, #3
    5630:	8b020060 	add	x0, x3, x2
    5634:	f9401014 	ldr	x20, [x0, #32]
    5638:	b4000254 	cbz	x20, 5680 <fwp_rc_fresh+0x8c>
    563c:	38626862 	ldrb	w2, [x3, x2]
    5640:	7100085f 	cmp	w2, #0x2
    5644:	54000260 	b.eq	5690 <fwp_rc_fresh+0x9c>  // b.none
    5648:	7100045f 	cmp	w2, #0x1
    564c:	540001a1 	b.ne	5680 <fwp_rc_fresh+0x8c>  // b.any
    5650:	29430002 	ldp	w2, w0, [x0, #24]
    5654:	92403c21 	and	x1, x1, #0xffff
    5658:	9b027c21 	mul	x1, x1, x2
    565c:	d360fc21 	lsr	x1, x1, #32
    5660:	eb00003f 	cmp	x1, x0
    5664:	540000e2 	b.cs	5680 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5668:	8b010294 	add	x20, x20, x1
    566c:	39400280 	ldrb	w0, [x20]
    5670:	7103fc1f 	cmp	w0, #0xff
    5674:	540001a0 	b.eq	56a8 <fwp_rc_fresh+0xb4>  // b.none
    5678:	52800020 	mov	w0, #0x1                   	// #1
    567c:	39000280 	strb	w0, [x20]
    5680:	aa1303e0 	mov	x0, x19
    5684:	a94153f3 	ldp	x19, x20, [sp, #16]
    5688:	a8c27bfd 	ldp	x29, x30, [sp], #32
    568c:	d65f03c0 	ret
    5690:	72003c3f 	tst	w1, #0xffff
    5694:	54fffec0 	b.eq	566c <fwp_rc_fresh+0x78>  // b.none
    5698:	aa1303e0 	mov	x0, x19
    569c:	a94153f3 	ldp	x19, x20, [sp, #16]
    56a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    56a4:	d65f03c0 	ret
    56a8:	aa1403e0 	mov	x0, x20
    56ac:	97fffba5 	bl	4540 <fwp_rc_forget_slot>
    56b0:	17fffff2 	b	5678 <fwp_rc_fresh+0x84>

00000000000056b4 <fwp_rc_free_arr>:
    56b4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    56b8:	9115c063 	add	x3, x3, #0x570
    56bc:	f949d861 	ldr	x1, [x3, #5040]
    56c0:	f949ec62 	ldr	x2, [x3, #5080]
    56c4:	cb010001 	sub	x1, x0, x1
    56c8:	eb02403f 	cmp	x1, x2, lsl #16
    56cc:	54000342 	b.cs	5734 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    56d0:	d350fc22 	lsr	x2, x1, #16
    56d4:	f949fc65 	ldr	x5, [x3, #5112]
    56d8:	8b020842 	add	x2, x2, x2, lsl #2
    56dc:	d37df042 	lsl	x2, x2, #3
    56e0:	8b0200a4 	add	x4, x5, x2
    56e4:	f9401083 	ldr	x3, [x4, #32]
    56e8:	b4000263 	cbz	x3, 5734 <fwp_rc_free_arr+0x80>
    56ec:	386268a2 	ldrb	w2, [x5, x2]
    56f0:	7100085f 	cmp	w2, #0x2
    56f4:	540001c0 	b.eq	572c <fwp_rc_free_arr+0x78>  // b.none
    56f8:	7100045f 	cmp	w2, #0x1
    56fc:	540001c1 	b.ne	5734 <fwp_rc_free_arr+0x80>  // b.any
    5700:	29430885 	ldp	w5, w2, [x4, #24]
    5704:	92403c21 	and	x1, x1, #0xffff
    5708:	9b057c21 	mul	x1, x1, x5
    570c:	d360fc21 	lsr	x1, x1, #32
    5710:	eb02003f 	cmp	x1, x2
    5714:	54000102 	b.cs	5734 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5718:	8b010063 	add	x3, x3, x1
    571c:	39400061 	ldrb	w1, [x3]
    5720:	7100043f 	cmp	w1, #0x1
    5724:	54000081 	b.ne	5734 <fwp_rc_free_arr+0x80>  // b.any
    5728:	17fffc26 	b	47c0 <fwp_mem_free>
    572c:	72003c3f 	tst	w1, #0xffff
    5730:	54ffff60 	b.eq	571c <fwp_rc_free_arr+0x68>  // b.none
    5734:	d65f03c0 	ret
    5738:	d503201f 	nop
    573c:	d503201f 	nop

0000000000005740 <fwp_rc_dup>:
    5740:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    5744:	9115c042 	add	x2, x2, #0x570
    5748:	f949d841 	ldr	x1, [x2, #5040]
    574c:	f949ec43 	ldr	x3, [x2, #5080]
    5750:	cb010001 	sub	x1, x0, x1
    5754:	eb03403f 	cmp	x1, x3, lsl #16
    5758:	54000342 	b.cs	57c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    575c:	d350fc20 	lsr	x0, x1, #16
    5760:	f949fc44 	ldr	x4, [x2, #5112]
    5764:	8b000800 	add	x0, x0, x0, lsl #2
    5768:	d37df002 	lsl	x2, x0, #3
    576c:	8b020083 	add	x3, x4, x2
    5770:	f9401060 	ldr	x0, [x3, #32]
    5774:	b4000260 	cbz	x0, 57c0 <fwp_rc_dup+0x80>
    5778:	38626882 	ldrb	w2, [x4, x2]
    577c:	7100085f 	cmp	w2, #0x2
    5780:	54000220 	b.eq	57c4 <fwp_rc_dup+0x84>  // b.none
    5784:	7100045f 	cmp	w2, #0x1
    5788:	540001c1 	b.ne	57c0 <fwp_rc_dup+0x80>  // b.any
    578c:	29430864 	ldp	w4, w2, [x3, #24]
    5790:	92403c21 	and	x1, x1, #0xffff
    5794:	9b047c21 	mul	x1, x1, x4
    5798:	d360fc21 	lsr	x1, x1, #32
    579c:	eb02003f 	cmp	x1, x2
    57a0:	54000102 	b.cs	57c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    57a4:	8b010000 	add	x0, x0, x1
    57a8:	39400001 	ldrb	w1, [x0]
    57ac:	340000a1 	cbz	w1, 57c0 <fwp_rc_dup+0x80>
    57b0:	7103f43f 	cmp	w1, #0xfd
    57b4:	540000e8 	b.hi	57d0 <fwp_rc_dup+0x90>  // b.pmore
    57b8:	11000421 	add	w1, w1, #0x1
    57bc:	39000001 	strb	w1, [x0]
    57c0:	d65f03c0 	ret
    57c4:	72003c3f 	tst	w1, #0xffff
    57c8:	54ffff00 	b.eq	57a8 <fwp_rc_dup+0x68>  // b.none
    57cc:	d65f03c0 	ret
    57d0:	17fffb15 	b	4424 <fwp_rc_wide_dup>

00000000000057d4 <fwp_owned_entry161>:
    57d4:	d10103ff 	sub	sp, sp, #0x40
    57d8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    57dc:	f947f442 	ldr	x2, [x2, #4072]
    57e0:	a9027bfd 	stp	x29, x30, [sp, #32]
    57e4:	910083fd 	add	x29, sp, #0x20
    57e8:	a90353f3 	stp	x19, x20, [sp, #48]
    57ec:	f9400043 	ldr	x3, [x2]
    57f0:	f9000fe3 	str	x3, [sp, #24]
    57f4:	d2800003 	mov	x3, #0x0                   	// #0
    57f8:	a9400c01 	ldp	x1, x3, [x0]
    57fc:	f9400802 	ldr	x2, [x0, #16]
    5800:	ab020022 	adds	x2, x1, x2
    5804:	540006e6 	b.vs	58e0 <fwp_owned_entry161+0x10c>
    5808:	910023e1 	add	x1, sp, #0x8
    580c:	52800000 	mov	w0, #0x0                   	// #0
    5810:	a9008be3 	stp	x3, x2, [sp, #8]
    5814:	97ffff0b 	bl	5440 <fwp_data.part.0.constprop.0>
    5818:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    581c:	9115c063 	add	x3, x3, #0x570
    5820:	aa0003f3 	mov	x19, x0
    5824:	f949d861 	ldr	x1, [x3, #5040]
    5828:	f949ec60 	ldr	x0, [x3, #5080]
    582c:	cb010261 	sub	x1, x19, x1
    5830:	eb00403f 	cmp	x1, x0, lsl #16
    5834:	54000322 	b.cs	5898 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5838:	d350fc22 	lsr	x2, x1, #16
    583c:	f949fc63 	ldr	x3, [x3, #5112]
    5840:	8b020842 	add	x2, x2, x2, lsl #2
    5844:	d37df042 	lsl	x2, x2, #3
    5848:	8b020060 	add	x0, x3, x2
    584c:	f9401014 	ldr	x20, [x0, #32]
    5850:	b4000254 	cbz	x20, 5898 <fwp_owned_entry161+0xc4>
    5854:	38626862 	ldrb	w2, [x3, x2]
    5858:	7100085f 	cmp	w2, #0x2
    585c:	54000360 	b.eq	58c8 <fwp_owned_entry161+0xf4>  // b.none
    5860:	7100045f 	cmp	w2, #0x1
    5864:	540001a1 	b.ne	5898 <fwp_owned_entry161+0xc4>  // b.any
    5868:	29430002 	ldp	w2, w0, [x0, #24]
    586c:	92403c21 	and	x1, x1, #0xffff
    5870:	9b027c21 	mul	x1, x1, x2
    5874:	d360fc21 	lsr	x1, x1, #32
    5878:	eb00003f 	cmp	x1, x0
    587c:	540000e2 	b.cs	5898 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5880:	8b010294 	add	x20, x20, x1
    5884:	39400280 	ldrb	w0, [x20]
    5888:	7103fc1f 	cmp	w0, #0xff
    588c:	54000240 	b.eq	58d4 <fwp_owned_entry161+0x100>  // b.none
    5890:	52800020 	mov	w0, #0x1                   	// #1
    5894:	39000280 	strb	w0, [x20]
    5898:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    589c:	f947f400 	ldr	x0, [x0, #4072]
    58a0:	f9400fe2 	ldr	x2, [sp, #24]
    58a4:	f9400001 	ldr	x1, [x0]
    58a8:	eb010042 	subs	x2, x2, x1
    58ac:	d2800001 	mov	x1, #0x0                   	// #0
    58b0:	540001a1 	b.ne	58e4 <fwp_owned_entry161+0x110>  // b.any
    58b4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    58b8:	aa1303e0 	mov	x0, x19
    58bc:	a94353f3 	ldp	x19, x20, [sp, #48]
    58c0:	910103ff 	add	sp, sp, #0x40
    58c4:	d65f03c0 	ret
    58c8:	72003c3f 	tst	w1, #0xffff
    58cc:	54fffe61 	b.ne	5898 <fwp_owned_entry161+0xc4>  // b.any
    58d0:	17ffffed 	b	5884 <fwp_owned_entry161+0xb0>
    58d4:	aa1403e0 	mov	x0, x20
    58d8:	97fffb1a 	bl	4540 <fwp_rc_forget_slot>
    58dc:	17ffffed 	b	5890 <fwp_owned_entry161+0xbc>
    58e0:	97fff448 	bl	2a00 <fwp_trap_overflow.constprop.0>
    58e4:	97fff3c3 	bl	27f0 <__stack_chk_fail@plt>
    58e8:	d503201f 	nop
    58ec:	d503201f 	nop

00000000000058f0 <e161>:
    58f0:	d10103ff 	sub	sp, sp, #0x40
    58f4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    58f8:	f947f442 	ldr	x2, [x2, #4072]
    58fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5900:	910083fd 	add	x29, sp, #0x20
    5904:	a90353f3 	stp	x19, x20, [sp, #48]
    5908:	f9400043 	ldr	x3, [x2]
    590c:	f9000fe3 	str	x3, [sp, #24]
    5910:	d2800003 	mov	x3, #0x0                   	// #0
    5914:	a9400c01 	ldp	x1, x3, [x0]
    5918:	f9400802 	ldr	x2, [x0, #16]
    591c:	ab020022 	adds	x2, x1, x2
    5920:	54000726 	b.vs	5a04 <e161+0x114>
    5924:	910023e1 	add	x1, sp, #0x8
    5928:	52800000 	mov	w0, #0x0                   	// #0
    592c:	a9008be3 	stp	x3, x2, [sp, #8]
    5930:	97fffec4 	bl	5440 <fwp_data.part.0.constprop.0>
    5934:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    5938:	9115c063 	add	x3, x3, #0x570
    593c:	aa0003f3 	mov	x19, x0
    5940:	f949d861 	ldr	x1, [x3, #5040]
    5944:	f949ec60 	ldr	x0, [x3, #5080]
    5948:	cb010261 	sub	x1, x19, x1
    594c:	eb00403f 	cmp	x1, x0, lsl #16
    5950:	54000322 	b.cs	59b4 <e161+0xc4>  // b.hs, b.nlast
    5954:	d350fc22 	lsr	x2, x1, #16
    5958:	f949fc63 	ldr	x3, [x3, #5112]
    595c:	8b020842 	add	x2, x2, x2, lsl #2
    5960:	d37df042 	lsl	x2, x2, #3
    5964:	8b020060 	add	x0, x3, x2
    5968:	f9401014 	ldr	x20, [x0, #32]
    596c:	b4000254 	cbz	x20, 59b4 <e161+0xc4>
    5970:	38626862 	ldrb	w2, [x3, x2]
    5974:	7100085f 	cmp	w2, #0x2
    5978:	540003a0 	b.eq	59ec <e161+0xfc>  // b.none
    597c:	7100045f 	cmp	w2, #0x1
    5980:	540001a1 	b.ne	59b4 <e161+0xc4>  // b.any
    5984:	29430002 	ldp	w2, w0, [x0, #24]
    5988:	92403c21 	and	x1, x1, #0xffff
    598c:	9b027c21 	mul	x1, x1, x2
    5990:	d360fc21 	lsr	x1, x1, #32
    5994:	eb00003f 	cmp	x1, x0
    5998:	540000e2 	b.cs	59b4 <e161+0xc4>  // b.hs, b.nlast
    599c:	8b010294 	add	x20, x20, x1
    59a0:	39400280 	ldrb	w0, [x20]
    59a4:	7103fc1f 	cmp	w0, #0xff
    59a8:	54000280 	b.eq	59f8 <e161+0x108>  // b.none
    59ac:	52800020 	mov	w0, #0x1                   	// #1
    59b0:	39000280 	strb	w0, [x20]
    59b4:	aa1303e0 	mov	x0, x19
    59b8:	97fffeea 	bl	5560 <fwp_rc_share>
    59bc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    59c0:	f947f400 	ldr	x0, [x0, #4072]
    59c4:	f9400fe2 	ldr	x2, [sp, #24]
    59c8:	f9400001 	ldr	x1, [x0]
    59cc:	eb010042 	subs	x2, x2, x1
    59d0:	d2800001 	mov	x1, #0x0                   	// #0
    59d4:	540001a1 	b.ne	5a08 <e161+0x118>  // b.any
    59d8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    59dc:	aa1303e0 	mov	x0, x19
    59e0:	a94353f3 	ldp	x19, x20, [sp, #48]
    59e4:	910103ff 	add	sp, sp, #0x40
    59e8:	d65f03c0 	ret
    59ec:	72003c3f 	tst	w1, #0xffff
    59f0:	54fffe21 	b.ne	59b4 <e161+0xc4>  // b.any
    59f4:	17ffffeb 	b	59a0 <e161+0xb0>
    59f8:	aa1403e0 	mov	x0, x20
    59fc:	97fffad1 	bl	4540 <fwp_rc_forget_slot>
    5a00:	17ffffeb 	b	59ac <e161+0xbc>
    5a04:	97fff3ff 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5a08:	97fff37a 	bl	27f0 <__stack_chk_fail@plt>
    5a0c:	d503201f 	nop

0000000000005a10 <fwp_drop1>:
    5a10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a14:	910003fd 	mov	x29, sp
    5a18:	a90153f3 	stp	x19, x20, [sp, #16]
    5a1c:	f90013f5 	str	x21, [sp, #32]
    5a20:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    5a24:	9115c2b4 	add	x20, x21, #0x570
    5a28:	f949da81 	ldr	x1, [x20, #5040]
    5a2c:	f949ee82 	ldr	x2, [x20, #5080]
    5a30:	cb010001 	sub	x1, x0, x1
    5a34:	eb02403f 	cmp	x1, x2, lsl #16
    5a38:	54000382 	b.cs	5aa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a3c:	d350fc22 	lsr	x2, x1, #16
    5a40:	f949fe84 	ldr	x4, [x20, #5112]
    5a44:	8b020842 	add	x2, x2, x2, lsl #2
    5a48:	d37df042 	lsl	x2, x2, #3
    5a4c:	8b020083 	add	x3, x4, x2
    5a50:	f9401073 	ldr	x19, [x3, #32]
    5a54:	b40002b3 	cbz	x19, 5aa8 <fwp_drop1+0x98>
    5a58:	38626882 	ldrb	w2, [x4, x2]
    5a5c:	7100085f 	cmp	w2, #0x2
    5a60:	540002c0 	b.eq	5ab8 <fwp_drop1+0xa8>  // b.none
    5a64:	7100045f 	cmp	w2, #0x1
    5a68:	54000201 	b.ne	5aa8 <fwp_drop1+0x98>  // b.any
    5a6c:	29430864 	ldp	w4, w2, [x3, #24]
    5a70:	92403c21 	and	x1, x1, #0xffff
    5a74:	9b047c21 	mul	x1, x1, x4
    5a78:	d360fc21 	lsr	x1, x1, #32
    5a7c:	eb02003f 	cmp	x1, x2
    5a80:	54000142 	b.cs	5aa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a84:	8b010273 	add	x19, x19, x1
    5a88:	39400261 	ldrb	w1, [x19]
    5a8c:	340000e1 	cbz	w1, 5aa8 <fwp_drop1+0x98>
    5a90:	7100043f 	cmp	w1, #0x1
    5a94:	540001e0 	b.eq	5ad0 <fwp_drop1+0xc0>  // b.none
    5a98:	7103fc3f 	cmp	w1, #0xff
    5a9c:	540002e0 	b.eq	5af8 <fwp_drop1+0xe8>  // b.none
    5aa0:	51000421 	sub	w1, w1, #0x1
    5aa4:	39000261 	strb	w1, [x19]
    5aa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5aac:	f94013f5 	ldr	x21, [sp, #32]
    5ab0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ab4:	d65f03c0 	ret
    5ab8:	72003c3f 	tst	w1, #0xffff
    5abc:	54fffe60 	b.eq	5a88 <fwp_drop1+0x78>  // b.none
    5ac0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ac4:	f94013f5 	ldr	x21, [sp, #32]
    5ac8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5acc:	d65f03c0 	ret
    5ad0:	f9400813 	ldr	x19, [x0, #16]
    5ad4:	97fffef8 	bl	56b4 <fwp_rc_free_arr>
    5ad8:	9115c2a0 	add	x0, x21, #0x570
    5adc:	f949d801 	ldr	x1, [x0, #5040]
    5ae0:	f949ec00 	ldr	x0, [x0, #5080]
    5ae4:	cb010261 	sub	x1, x19, x1
    5ae8:	eb00403f 	cmp	x1, x0, lsl #16
    5aec:	54fffde2 	b.cs	5aa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5af0:	aa1303e0 	mov	x0, x19
    5af4:	17ffffd2 	b	5a3c <fwp_drop1+0x2c>
    5af8:	ca534660 	eor	x0, x19, x19, lsr #17
    5afc:	9115c2b5 	add	x21, x21, #0x570
    5b00:	ca402400 	eor	x0, x0, x0, lsr #9
    5b04:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5b08:	f94a2400 	ldr	x0, [x0, #5192]
    5b0c:	b5000080 	cbnz	x0, 5b1c <fwp_drop1+0x10c>
    5b10:	14000010 	b	5b50 <fwp_drop1+0x140>
    5b14:	f9400800 	ldr	x0, [x0, #16]
    5b18:	b40001c0 	cbz	x0, 5b50 <fwp_drop1+0x140>
    5b1c:	f9400001 	ldr	x1, [x0]
    5b20:	eb13003f 	cmp	x1, x19
    5b24:	54ffff81 	b.ne	5b14 <fwp_drop1+0x104>  // b.any
    5b28:	f9400401 	ldr	x1, [x0, #8]
    5b2c:	d1000421 	sub	x1, x1, #0x1
    5b30:	f9000401 	str	x1, [x0, #8]
    5b34:	f103f83f 	cmp	x1, #0xfe
    5b38:	54fffb81 	b.ne	5aa8 <fwp_drop1+0x98>  // b.any
    5b3c:	aa1303e0 	mov	x0, x19
    5b40:	97fffa80 	bl	4540 <fwp_rc_forget_slot>
    5b44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b48:	39000260 	strb	w0, [x19]
    5b4c:	17ffffd7 	b	5aa8 <fwp_drop1+0x98>
    5b50:	90000040 	adrp	x0, d000 <__modti3+0x230>
    5b54:	91106000 	add	x0, x0, #0x418
    5b58:	97fff66a 	bl	3500 <fwp_trap>
    5b5c:	d503201f 	nop

0000000000005b60 <fwp_drop0>:
    5b60:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b64:	910003fd 	mov	x29, sp
    5b68:	a90153f3 	stp	x19, x20, [sp, #16]
    5b6c:	f90013f5 	str	x21, [sp, #32]
    5b70:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    5b74:	9115c2b4 	add	x20, x21, #0x570
    5b78:	f949da81 	ldr	x1, [x20, #5040]
    5b7c:	f949ee82 	ldr	x2, [x20, #5080]
    5b80:	cb010001 	sub	x1, x0, x1
    5b84:	eb02403f 	cmp	x1, x2, lsl #16
    5b88:	54000382 	b.cs	5bf8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b8c:	d350fc22 	lsr	x2, x1, #16
    5b90:	f949fe84 	ldr	x4, [x20, #5112]
    5b94:	8b020842 	add	x2, x2, x2, lsl #2
    5b98:	d37df042 	lsl	x2, x2, #3
    5b9c:	8b020083 	add	x3, x4, x2
    5ba0:	f9401073 	ldr	x19, [x3, #32]
    5ba4:	b40002b3 	cbz	x19, 5bf8 <fwp_drop0+0x98>
    5ba8:	38626882 	ldrb	w2, [x4, x2]
    5bac:	7100085f 	cmp	w2, #0x2
    5bb0:	540002c0 	b.eq	5c08 <fwp_drop0+0xa8>  // b.none
    5bb4:	7100045f 	cmp	w2, #0x1
    5bb8:	54000201 	b.ne	5bf8 <fwp_drop0+0x98>  // b.any
    5bbc:	29430864 	ldp	w4, w2, [x3, #24]
    5bc0:	92403c21 	and	x1, x1, #0xffff
    5bc4:	9b047c21 	mul	x1, x1, x4
    5bc8:	d360fc21 	lsr	x1, x1, #32
    5bcc:	eb02003f 	cmp	x1, x2
    5bd0:	54000142 	b.cs	5bf8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5bd4:	8b010273 	add	x19, x19, x1
    5bd8:	39400261 	ldrb	w1, [x19]
    5bdc:	340000e1 	cbz	w1, 5bf8 <fwp_drop0+0x98>
    5be0:	7100043f 	cmp	w1, #0x1
    5be4:	540001e0 	b.eq	5c20 <fwp_drop0+0xc0>  // b.none
    5be8:	7103fc3f 	cmp	w1, #0xff
    5bec:	540002e0 	b.eq	5c48 <fwp_drop0+0xe8>  // b.none
    5bf0:	51000421 	sub	w1, w1, #0x1
    5bf4:	39000261 	strb	w1, [x19]
    5bf8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bfc:	f94013f5 	ldr	x21, [sp, #32]
    5c00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c04:	d65f03c0 	ret
    5c08:	72003c3f 	tst	w1, #0xffff
    5c0c:	54fffe60 	b.eq	5bd8 <fwp_drop0+0x78>  // b.none
    5c10:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c14:	f94013f5 	ldr	x21, [sp, #32]
    5c18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c1c:	d65f03c0 	ret
    5c20:	f9400813 	ldr	x19, [x0, #16]
    5c24:	97fffea4 	bl	56b4 <fwp_rc_free_arr>
    5c28:	9115c2a0 	add	x0, x21, #0x570
    5c2c:	f949d801 	ldr	x1, [x0, #5040]
    5c30:	f949ec00 	ldr	x0, [x0, #5080]
    5c34:	cb010261 	sub	x1, x19, x1
    5c38:	eb00403f 	cmp	x1, x0, lsl #16
    5c3c:	54fffde2 	b.cs	5bf8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c40:	aa1303e0 	mov	x0, x19
    5c44:	17ffffd2 	b	5b8c <fwp_drop0+0x2c>
    5c48:	ca534660 	eor	x0, x19, x19, lsr #17
    5c4c:	9115c2b5 	add	x21, x21, #0x570
    5c50:	ca402400 	eor	x0, x0, x0, lsr #9
    5c54:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5c58:	f94a2400 	ldr	x0, [x0, #5192]
    5c5c:	b5000080 	cbnz	x0, 5c6c <fwp_drop0+0x10c>
    5c60:	14000010 	b	5ca0 <fwp_drop0+0x140>
    5c64:	f9400800 	ldr	x0, [x0, #16]
    5c68:	b40001c0 	cbz	x0, 5ca0 <fwp_drop0+0x140>
    5c6c:	f9400001 	ldr	x1, [x0]
    5c70:	eb13003f 	cmp	x1, x19
    5c74:	54ffff81 	b.ne	5c64 <fwp_drop0+0x104>  // b.any
    5c78:	f9400401 	ldr	x1, [x0, #8]
    5c7c:	d1000421 	sub	x1, x1, #0x1
    5c80:	f9000401 	str	x1, [x0, #8]
    5c84:	f103f83f 	cmp	x1, #0xfe
    5c88:	54fffb81 	b.ne	5bf8 <fwp_drop0+0x98>  // b.any
    5c8c:	aa1303e0 	mov	x0, x19
    5c90:	97fffa2c 	bl	4540 <fwp_rc_forget_slot>
    5c94:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c98:	39000260 	strb	w0, [x19]
    5c9c:	17ffffd7 	b	5bf8 <fwp_drop0+0x98>
    5ca0:	90000040 	adrp	x0, d000 <__modti3+0x230>
    5ca4:	91106000 	add	x0, x0, #0x418
    5ca8:	97fff616 	bl	3500 <fwp_trap>
    5cac:	d503201f 	nop

0000000000005cb0 <fwp_arg_drop12>:
    5cb0:	7100003f 	cmp	w1, #0x0
    5cb4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5cb8:	54000041 	b.ne	5cc0 <fwp_arg_drop12+0x10>  // b.any
    5cbc:	d65f03c0 	ret
    5cc0:	f9400000 	ldr	x0, [x0]
    5cc4:	17ffffa7 	b	5b60 <fwp_drop0>
    5cc8:	d503201f 	nop
    5ccc:	d503201f 	nop

0000000000005cd0 <fwp_closure_drop>:
    5cd0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc70>
    5cd4:	9115c0a4 	add	x4, x5, #0x570
    5cd8:	aa0003e1 	mov	x1, x0
    5cdc:	f949d882 	ldr	x2, [x4, #5040]
    5ce0:	f949ec80 	ldr	x0, [x4, #5080]
    5ce4:	cb020022 	sub	x2, x1, x2
    5ce8:	eb00405f 	cmp	x2, x0, lsl #16
    5cec:	54000662 	b.cs	5db8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5cf0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5cf4:	d350fc43 	lsr	x3, x2, #16
    5cf8:	910003fd 	mov	x29, sp
    5cfc:	8b030863 	add	x3, x3, x3, lsl #2
    5d00:	f949fc84 	ldr	x4, [x4, #5112]
    5d04:	d37df063 	lsl	x3, x3, #3
    5d08:	f9000bf3 	str	x19, [sp, #16]
    5d0c:	8b030080 	add	x0, x4, x3
    5d10:	f9401013 	ldr	x19, [x0, #32]
    5d14:	b40002b3 	cbz	x19, 5d68 <fwp_closure_drop+0x98>
    5d18:	38636883 	ldrb	w3, [x4, x3]
    5d1c:	7100087f 	cmp	w3, #0x2
    5d20:	54000420 	b.eq	5da4 <fwp_closure_drop+0xd4>  // b.none
    5d24:	7100047f 	cmp	w3, #0x1
    5d28:	54000201 	b.ne	5d68 <fwp_closure_drop+0x98>  // b.any
    5d2c:	29430003 	ldp	w3, w0, [x0, #24]
    5d30:	92403c42 	and	x2, x2, #0xffff
    5d34:	9b037c42 	mul	x2, x2, x3
    5d38:	d360fc42 	lsr	x2, x2, #32
    5d3c:	eb00005f 	cmp	x2, x0
    5d40:	54000142 	b.cs	5d68 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5d44:	8b020273 	add	x19, x19, x2
    5d48:	39400260 	ldrb	w0, [x19]
    5d4c:	340000e0 	cbz	w0, 5d68 <fwp_closure_drop+0x98>
    5d50:	7100041f 	cmp	w0, #0x1
    5d54:	54000100 	b.eq	5d74 <fwp_closure_drop+0xa4>  // b.none
    5d58:	7103fc1f 	cmp	w0, #0xff
    5d5c:	54000300 	b.eq	5dbc <fwp_closure_drop+0xec>  // b.none
    5d60:	51000400 	sub	w0, w0, #0x1
    5d64:	39000260 	strb	w0, [x19]
    5d68:	f9400bf3 	ldr	x19, [sp, #16]
    5d6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d70:	d65f03c0 	ret
    5d74:	d53bd040 	mrs	x0, tpidr_el0
    5d78:	91400000 	add	x0, x0, #0x0, lsl #12
    5d7c:	91004000 	add	x0, x0, #0x10
    5d80:	f9400000 	ldr	x0, [x0]
    5d84:	b4000080 	cbz	x0, 5d94 <fwp_closure_drop+0xc4>
    5d88:	f9400bf3 	ldr	x19, [sp, #16]
    5d8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d90:	17fff5f5 	b	3564 <fwp_closure_drop_push>
    5d94:	f9400bf3 	ldr	x19, [sp, #16]
    5d98:	aa0103e0 	mov	x0, x1
    5d9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5da0:	17fff660 	b	3720 <fwp_closure_drop.part.0>
    5da4:	72003c5f 	tst	w2, #0xffff
    5da8:	54fffd00 	b.eq	5d48 <fwp_closure_drop+0x78>  // b.none
    5dac:	f9400bf3 	ldr	x19, [sp, #16]
    5db0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5db4:	d65f03c0 	ret
    5db8:	d65f03c0 	ret
    5dbc:	ca534660 	eor	x0, x19, x19, lsr #17
    5dc0:	9115c0a5 	add	x5, x5, #0x570
    5dc4:	ca402400 	eor	x0, x0, x0, lsr #9
    5dc8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5dcc:	f94a2400 	ldr	x0, [x0, #5192]
    5dd0:	b5000080 	cbnz	x0, 5de0 <fwp_closure_drop+0x110>
    5dd4:	14000010 	b	5e14 <fwp_closure_drop+0x144>
    5dd8:	f9400800 	ldr	x0, [x0, #16]
    5ddc:	b40001c0 	cbz	x0, 5e14 <fwp_closure_drop+0x144>
    5de0:	f9400001 	ldr	x1, [x0]
    5de4:	eb13003f 	cmp	x1, x19
    5de8:	54ffff81 	b.ne	5dd8 <fwp_closure_drop+0x108>  // b.any
    5dec:	f9400401 	ldr	x1, [x0, #8]
    5df0:	d1000421 	sub	x1, x1, #0x1
    5df4:	f9000401 	str	x1, [x0, #8]
    5df8:	f103f83f 	cmp	x1, #0xfe
    5dfc:	54fffb61 	b.ne	5d68 <fwp_closure_drop+0x98>  // b.any
    5e00:	aa1303e0 	mov	x0, x19
    5e04:	97fff9cf 	bl	4540 <fwp_rc_forget_slot>
    5e08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e0c:	39000260 	strb	w0, [x19]
    5e10:	17ffffd6 	b	5d68 <fwp_closure_drop+0x98>
    5e14:	90000040 	adrp	x0, d000 <__modti3+0x230>
    5e18:	91106000 	add	x0, x0, #0x418
    5e1c:	97fff5b9 	bl	3500 <fwp_trap>

0000000000005e20 <fwp_owned_tape_release>:
    5e20:	b4000940 	cbz	x0, 5f48 <fwp_owned_tape_release+0x128>
    5e24:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e28:	910003fd 	mov	x29, sp
    5e2c:	a90153f3 	stp	x19, x20, [sp, #16]
    5e30:	aa0003f3 	mov	x19, x0
    5e34:	f9400000 	ldr	x0, [x0]
    5e38:	b4000060 	cbz	x0, 5e44 <fwp_owned_tape_release+0x24>
    5e3c:	f9400661 	ldr	x1, [x19, #8]
    5e40:	f9000401 	str	x1, [x0, #8]
    5e44:	f9400661 	ldr	x1, [x19, #8]
    5e48:	b4000041 	cbz	x1, 5e50 <fwp_owned_tape_release+0x30>
    5e4c:	f9000020 	str	x0, [x1]
    5e50:	f9400a60 	ldr	x0, [x19, #16]
    5e54:	f9403401 	ldr	x1, [x0, #104]
    5e58:	b40005c1 	cbz	x1, 5f10 <fwp_owned_tape_release+0xf0>
    5e5c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5e60:	eb00005f 	cmp	x2, x0
    5e64:	540002ed 	b.le	5ec0 <fwp_owned_tape_release+0xa0>
    5e68:	d2800014 	mov	x20, #0x0                   	// #0
    5e6c:	f90013f5 	str	x21, [sp, #32]
    5e70:	d2800015 	mov	x21, #0x0                   	// #0
    5e74:	d503201f 	nop
    5e78:	f9402260 	ldr	x0, [x19, #64]
    5e7c:	910006b5 	add	x21, x21, #0x1
    5e80:	f8746800 	ldr	x0, [x0, x20]
    5e84:	d63f0020 	blr	x1
    5e88:	f9402260 	ldr	x0, [x19, #64]
    5e8c:	f9400a61 	ldr	x1, [x19, #16]
    5e90:	8b140000 	add	x0, x0, x20
    5e94:	91004294 	add	x20, x20, #0x10
    5e98:	f9400400 	ldr	x0, [x0, #8]
    5e9c:	f9403421 	ldr	x1, [x1, #104]
    5ea0:	d63f0020 	blr	x1
    5ea4:	a9450261 	ldp	x1, x0, [x19, #80]
    5ea8:	cb010000 	sub	x0, x0, x1
    5eac:	eb15001f 	cmp	x0, x21
    5eb0:	f9400a60 	ldr	x0, [x19, #16]
    5eb4:	f9403401 	ldr	x1, [x0, #104]
    5eb8:	54fffe0c 	b.gt	5e78 <fwp_owned_tape_release+0x58>
    5ebc:	f94013f5 	ldr	x21, [sp, #32]
    5ec0:	f9403663 	ldr	x3, [x19, #104]
    5ec4:	f9401262 	ldr	x2, [x19, #32]
    5ec8:	f100007f 	cmp	x3, #0x0
    5ecc:	540001ed 	b.le	5f08 <fwp_owned_tape_release+0xe8>
    5ed0:	d2800014 	mov	x20, #0x0                   	// #0
    5ed4:	d503201f 	nop
    5ed8:	f9402660 	ldr	x0, [x19, #72]
    5edc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5ee0:	eb02001f 	cmp	x0, x2
    5ee4:	540000c0 	b.eq	5efc <fwp_owned_tape_release+0xdc>  // b.none
    5ee8:	d63f0020 	blr	x1
    5eec:	f9400a60 	ldr	x0, [x19, #16]
    5ef0:	f9401262 	ldr	x2, [x19, #32]
    5ef4:	f9403663 	ldr	x3, [x19, #104]
    5ef8:	f9403401 	ldr	x1, [x0, #104]
    5efc:	91000694 	add	x20, x20, #0x1
    5f00:	eb14007f 	cmp	x3, x20
    5f04:	54fffeac 	b.gt	5ed8 <fwp_owned_tape_release+0xb8>
    5f08:	aa0203e0 	mov	x0, x2
    5f0c:	d63f0020 	blr	x1
    5f10:	f9401660 	ldr	x0, [x19, #40]
    5f14:	97ffff6f 	bl	5cd0 <fwp_closure_drop>
    5f18:	f9401a60 	ldr	x0, [x19, #48]
    5f1c:	97ffff6d 	bl	5cd0 <fwp_closure_drop>
    5f20:	f9401e60 	ldr	x0, [x19, #56]
    5f24:	97ffff6b 	bl	5cd0 <fwp_closure_drop>
    5f28:	f9402260 	ldr	x0, [x19, #64]
    5f2c:	97fffa25 	bl	47c0 <fwp_mem_free>
    5f30:	f9402660 	ldr	x0, [x19, #72]
    5f34:	97fffa23 	bl	47c0 <fwp_mem_free>
    5f38:	aa1303e0 	mov	x0, x19
    5f3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f44:	17fffa1f 	b	47c0 <fwp_mem_free>
    5f48:	d65f03c0 	ret
    5f4c:	d503201f 	nop

0000000000005f50 <fwp_tape_finish>:
    5f50:	d10203ff 	sub	sp, sp, #0x80
    5f54:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5f58:	f947f421 	ldr	x1, [x1, #4072]
    5f5c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f60:	910103fd 	add	x29, sp, #0x40
    5f64:	a90553f3 	stp	x19, x20, [sp, #80]
    5f68:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f6c:	a90763f7 	stp	x23, x24, [sp, #112]
    5f70:	f00000d8 	adrp	x24, 20000 <__data_start>
    5f74:	91010316 	add	x22, x24, #0x40
    5f78:	f9400022 	ldr	x2, [x1]
    5f7c:	f9001fe2 	str	x2, [sp, #56]
    5f80:	d2800002 	mov	x2, #0x0                   	// #0
    5f84:	9101a2c0 	add	x0, x22, #0x68
    5f88:	97fff4be 	bl	3280 <fwp_tape_buffers_dispose>
    5f8c:	f90052df 	str	xzr, [x22, #160]
    5f90:	f94022c0 	ldr	x0, [x22, #64]
    5f94:	f100001f 	cmp	x0, #0x0
    5f98:	5400030d 	b.le	5ff8 <fwp_tape_finish+0xa8>
    5f9c:	910003f7 	mov	x23, sp
    5fa0:	d2800015 	mov	x21, #0x0                   	// #0
    5fa4:	d2800014 	mov	x20, #0x0                   	// #0
    5fa8:	f94002d3 	ldr	x19, [x22]
    5fac:	91000694 	add	x20, x20, #0x1
    5fb0:	8b150273 	add	x19, x19, x21
    5fb4:	9101a2b5 	add	x21, x21, #0x68
    5fb8:	aa1303e0 	mov	x0, x19
    5fbc:	97fff3d5 	bl	2f10 <fwp_tape_unlink_scope>
    5fc0:	aa1703e0 	mov	x0, x23
    5fc4:	f9401261 	ldr	x1, [x19, #32]
    5fc8:	f90003e1 	str	x1, [sp]
    5fcc:	f9401a62 	ldr	x2, [x19, #48]
    5fd0:	f9000be2 	str	x2, [sp, #16]
    5fd4:	f9402261 	ldr	x1, [x19, #64]
    5fd8:	f90013e1 	str	x1, [sp, #32]
    5fdc:	97fff4a9 	bl	3280 <fwp_tape_buffers_dispose>
    5fe0:	f9403260 	ldr	x0, [x19, #96]
    5fe4:	97ffff8f 	bl	5e20 <fwp_owned_tape_release>
    5fe8:	f900327f 	str	xzr, [x19, #96]
    5fec:	f94022c0 	ldr	x0, [x22, #64]
    5ff0:	eb14001f 	cmp	x0, x20
    5ff4:	54fffdac 	b.gt	5fa8 <fwp_tape_finish+0x58>
    5ff8:	f9402300 	ldr	x0, [x24, #64]
    5ffc:	91010313 	add	x19, x24, #0x40
    6000:	97fff22c 	bl	28b0 <free@plt>
    6004:	f900231f 	str	xzr, [x24, #64]
    6008:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    600c:	f947f400 	ldr	x0, [x0, #4072]
    6010:	f900227f 	str	xzr, [x19, #64]
    6014:	a90b7e7f 	stp	xzr, xzr, [x19, #176]
    6018:	f9401fe2 	ldr	x2, [sp, #56]
    601c:	f9400001 	ldr	x1, [x0]
    6020:	eb010042 	subs	x2, x2, x1
    6024:	d2800001 	mov	x1, #0x0                   	// #0
    6028:	540000e1 	b.ne	6044 <fwp_tape_finish+0xf4>  // b.any
    602c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6030:	a94553f3 	ldp	x19, x20, [sp, #80]
    6034:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6038:	a94763f7 	ldp	x23, x24, [sp, #112]
    603c:	910203ff 	add	sp, sp, #0x80
    6040:	d65f03c0 	ret
    6044:	97fff1eb 	bl	27f0 <__stack_chk_fail@plt>
    6048:	d503201f 	nop
    604c:	d503201f 	nop

0000000000006050 <fwp_tape_scope_release>:
    6050:	d10243ff 	sub	sp, sp, #0x90
    6054:	a9047bfd 	stp	x29, x30, [sp, #64]
    6058:	910103fd 	add	x29, sp, #0x40
    605c:	a90553f3 	stp	x19, x20, [sp, #80]
    6060:	aa0003f4 	mov	x20, x0
    6064:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6068:	f947f400 	ldr	x0, [x0, #4072]
    606c:	b9400285 	ldr	w5, [x20]
    6070:	f9400001 	ldr	x1, [x0]
    6074:	f9001fe1 	str	x1, [sp, #56]
    6078:	d2800001 	mov	x1, #0x0                   	// #0
    607c:	37f806c5 	tbnz	w5, #31, 6154 <fwp_tape_scope_release+0x104>
    6080:	a90763f7 	stp	x23, x24, [sp, #112]
    6084:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6088:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    608c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6090:	d00000d3 	adrp	x19, 20000 <__data_start>
    6094:	910003f7 	mov	x23, sp
    6098:	91010273 	add	x19, x19, #0x40
    609c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    60a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    60a4:	52800d16 	mov	w22, #0x68                  	// #104
    60a8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    60ac:	f90043f9 	str	x25, [sp, #128]
    60b0:	14000006 	b	60c8 <fwp_tape_scope_release+0x78>
    60b4:	97fff473 	bl	3280 <fwp_tape_buffers_dispose>
    60b8:	aa1903e0 	mov	x0, x25
    60bc:	97ffff59 	bl	5e20 <fwp_owned_tape_release>
    60c0:	b9400285 	ldr	w5, [x20]
    60c4:	37f80425 	tbnz	w5, #31, 6148 <fwp_tape_scope_release+0xf8>
    60c8:	f9400266 	ldr	x6, [x19]
    60cc:	9b367ca5 	smull	x5, w5, w22
    60d0:	8b0500c0 	add	x0, x6, x5
    60d4:	97fff38f 	bl	2f10 <fwp_tape_unlink_scope>
    60d8:	ad410001 	ldp	q1, q0, [x0, #32]
    60dc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    60e0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    60e4:	f9400c03 	ldr	x3, [x0, #24]
    60e8:	ad0003e1 	stp	q1, q0, [sp]
    60ec:	b86568c1 	ldr	w1, [x6, x5]
    60f0:	a9440804 	ldp	x4, x2, [x0, #64]
    60f4:	b900041f 	str	wzr, [x0, #4]
    60f8:	f9403019 	ldr	x25, [x0, #96]
    60fc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6100:	f9000c1f 	str	xzr, [x0, #24]
    6104:	a9020fe4 	stp	x4, x3, [sp, #32]
    6108:	f9001be2 	str	x2, [sp, #48]
    610c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6110:	f900301f 	str	xzr, [x0, #96]
    6114:	6b15003f 	cmp	w1, w21
    6118:	540000e8 	b.hi	6134 <fwp_tape_scope_release+0xe4>  // b.pmore
    611c:	9343fca5 	asr	x5, x5, #3
    6120:	f9405e60 	ldr	x0, [x19, #184]
    6124:	9b187ca5 	mul	x5, x5, x24
    6128:	eb0000bf 	cmp	x5, x0
    612c:	5400004a 	b.ge	6134 <fwp_tape_scope_release+0xe4>  // b.tcont
    6130:	f9005e65 	str	x5, [x19, #184]
    6134:	aa1703e0 	mov	x0, x23
    6138:	b5fffbf9 	cbnz	x25, 60b4 <fwp_tape_scope_release+0x64>
    613c:	97fff7e5 	bl	40d0 <fwp_tape_buffers_release>
    6140:	b9400285 	ldr	w5, [x20]
    6144:	36fffc25 	tbz	w5, #31, 60c8 <fwp_tape_scope_release+0x78>
    6148:	a9465bf5 	ldp	x21, x22, [sp, #96]
    614c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6150:	f94043f9 	ldr	x25, [sp, #128]
    6154:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6158:	f947f400 	ldr	x0, [x0, #4072]
    615c:	f9401fe2 	ldr	x2, [sp, #56]
    6160:	f9400001 	ldr	x1, [x0]
    6164:	eb010042 	subs	x2, x2, x1
    6168:	d2800001 	mov	x1, #0x0                   	// #0
    616c:	540000a1 	b.ne	6180 <fwp_tape_scope_release+0x130>  // b.any
    6170:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6174:	a94553f3 	ldp	x19, x20, [sp, #80]
    6178:	910243ff 	add	sp, sp, #0x90
    617c:	d65f03c0 	ret
    6180:	a9065bf5 	stp	x21, x22, [sp, #96]
    6184:	a90763f7 	stp	x23, x24, [sp, #112]
    6188:	f90043f9 	str	x25, [sp, #128]
    618c:	97fff199 	bl	27f0 <__stack_chk_fail@plt>

0000000000006190 <fwp_task_dispose>:
    6190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6194:	910003fd 	mov	x29, sp
    6198:	f9000bf3 	str	x19, [sp, #16]
    619c:	aa0003f3 	mov	x19, x0
    61a0:	39414000 	ldrb	w0, [x0, #80]
    61a4:	36000720 	tbz	w0, #0, 6288 <fwp_task_dispose+0xf8>
    61a8:	f9400a60 	ldr	x0, [x19, #16]
    61ac:	b50006e0 	cbnz	x0, 6288 <fwp_task_dispose+0xf8>
    61b0:	a9478660 	ldp	x0, x1, [x19, #120]
    61b4:	39014e7f 	strb	wzr, [x19, #83]
    61b8:	f9003e7f 	str	xzr, [x19, #120]
    61bc:	f100003f 	cmp	x1, #0x0
    61c0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    61c4:	54000040 	b.eq	61cc <fwp_task_dispose+0x3c>  // b.none
    61c8:	d63f0020 	blr	x1
    61cc:	f9405660 	ldr	x0, [x19, #168]
    61d0:	97fff97c 	bl	47c0 <fwp_mem_free>
    61d4:	f900567f 	str	xzr, [x19, #168]
    61d8:	b9405e60 	ldr	w0, [x19, #92]
    61dc:	7100041f 	cmp	w0, #0x1
    61e0:	54000420 	b.eq	6264 <fwp_task_dispose+0xd4>  // b.none
    61e4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    61e8:	9115c042 	add	x2, x2, #0x570
    61ec:	f949d840 	ldr	x0, [x2, #5040]
    61f0:	f949ec41 	ldr	x1, [x2, #5080]
    61f4:	cb000260 	sub	x0, x19, x0
    61f8:	eb01401f 	cmp	x0, x1, lsl #16
    61fc:	540002e2 	b.cs	6258 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6200:	d350fc01 	lsr	x1, x0, #16
    6204:	f949fc44 	ldr	x4, [x2, #5112]
    6208:	8b010821 	add	x1, x1, x1, lsl #2
    620c:	d37df021 	lsl	x1, x1, #3
    6210:	8b010083 	add	x3, x4, x1
    6214:	f9401062 	ldr	x2, [x3, #32]
    6218:	b4000202 	cbz	x2, 6258 <fwp_task_dispose+0xc8>
    621c:	38616881 	ldrb	w1, [x4, x1]
    6220:	7100083f 	cmp	w1, #0x2
    6224:	54000280 	b.eq	6274 <fwp_task_dispose+0xe4>  // b.none
    6228:	7100043f 	cmp	w1, #0x1
    622c:	54000161 	b.ne	6258 <fwp_task_dispose+0xc8>  // b.any
    6230:	29430464 	ldp	w4, w1, [x3, #24]
    6234:	92403c00 	and	x0, x0, #0xffff
    6238:	9b047c00 	mul	x0, x0, x4
    623c:	d360fc00 	lsr	x0, x0, #32
    6240:	eb01001f 	cmp	x0, x1
    6244:	540000a2 	b.cs	6258 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6248:	8b000042 	add	x2, x2, x0
    624c:	39400040 	ldrb	w0, [x2]
    6250:	7100041f 	cmp	w0, #0x1
    6254:	54000080 	b.eq	6264 <fwp_task_dispose+0xd4>  // b.none
    6258:	f9400bf3 	ldr	x19, [sp, #16]
    625c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6260:	d65f03c0 	ret
    6264:	aa1303e0 	mov	x0, x19
    6268:	f9400bf3 	ldr	x19, [sp, #16]
    626c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6270:	17fff954 	b	47c0 <fwp_mem_free>
    6274:	72003c1f 	tst	w0, #0xffff
    6278:	54fffea0 	b.eq	624c <fwp_task_dispose+0xbc>  // b.none
    627c:	f9400bf3 	ldr	x19, [sp, #16]
    6280:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6284:	d65f03c0 	ret
    6288:	97fff16e 	bl	2840 <abort@plt>
    628c:	d503201f 	nop

0000000000006290 <fwp_free_zombie>:
    6290:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6294:	910003fd 	mov	x29, sp
    6298:	a90153f3 	stp	x19, x20, [sp, #16]
    629c:	d00000d4 	adrp	x20, 20000 <__data_start>
    62a0:	91010281 	add	x1, x20, #0x40
    62a4:	f9406033 	ldr	x19, [x1, #192]
    62a8:	b4000333 	cbz	x19, 630c <fwp_free_zombie+0x7c>
    62ac:	f9400820 	ldr	x0, [x1, #16]
    62b0:	eb00027f 	cmp	x19, x0
    62b4:	540002c0 	b.eq	630c <fwp_free_zombie+0x7c>  // b.none
    62b8:	b940c822 	ldr	w2, [x1, #200]
    62bc:	f9400a60 	ldr	x0, [x19, #16]
    62c0:	7100fc5f 	cmp	w2, #0x3f
    62c4:	5400078c 	b.gt	63b4 <fwp_free_zombie+0x124>
    62c8:	91034023 	add	x3, x1, #0xd0
    62cc:	11000444 	add	w4, w2, #0x1
    62d0:	b900c824 	str	w4, [x1, #200]
    62d4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    62d8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    62dc:	a9530261 	ldp	x1, x0, [x19, #304]
    62e0:	b4000741 	cbz	x1, 63c8 <fwp_free_zombie+0x138>
    62e4:	f9009c20 	str	x0, [x1, #312]
    62e8:	b4000040 	cbz	x0, 62f0 <fwp_free_zombie+0x60>
    62ec:	f9009801 	str	x1, [x0, #304]
    62f0:	91010294 	add	x20, x20, #0x40
    62f4:	b9405e60 	ldr	w0, [x19, #92]
    62f8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    62fc:	f900629f 	str	xzr, [x20, #192]
    6300:	34000140 	cbz	w0, 6328 <fwp_free_zombie+0x98>
    6304:	7100041f 	cmp	w0, #0x1
    6308:	54000080 	b.eq	6318 <fwp_free_zombie+0x88>  // b.none
    630c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6310:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6314:	d65f03c0 	ret
    6318:	aa1303e0 	mov	x0, x19
    631c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6320:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6324:	17ffff9b 	b	6190 <fwp_task_dispose>
    6328:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc70>
    632c:	9115c082 	add	x2, x4, #0x570
    6330:	f949d841 	ldr	x1, [x2, #5040]
    6334:	f949ec40 	ldr	x0, [x2, #5080]
    6338:	cb010261 	sub	x1, x19, x1
    633c:	eb00403f 	cmp	x1, x0, lsl #16
    6340:	54fffe62 	b.cs	630c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6344:	d350fc20 	lsr	x0, x1, #16
    6348:	f949fc43 	ldr	x3, [x2, #5112]
    634c:	8b000800 	add	x0, x0, x0, lsl #2
    6350:	d37df000 	lsl	x0, x0, #3
    6354:	8b000062 	add	x2, x3, x0
    6358:	f9401054 	ldr	x20, [x2, #32]
    635c:	b4fffd94 	cbz	x20, 630c <fwp_free_zombie+0x7c>
    6360:	38606860 	ldrb	w0, [x3, x0]
    6364:	7100081f 	cmp	w0, #0x2
    6368:	54000360 	b.eq	63d4 <fwp_free_zombie+0x144>  // b.none
    636c:	7100041f 	cmp	w0, #0x1
    6370:	54fffce1 	b.ne	630c <fwp_free_zombie+0x7c>  // b.any
    6374:	29430043 	ldp	w3, w0, [x2, #24]
    6378:	92403c21 	and	x1, x1, #0xffff
    637c:	9b037c21 	mul	x1, x1, x3
    6380:	d360fc21 	lsr	x1, x1, #32
    6384:	eb00003f 	cmp	x1, x0
    6388:	54fffc22 	b.cs	630c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    638c:	8b010294 	add	x20, x20, x1
    6390:	39400280 	ldrb	w0, [x20]
    6394:	34fffbc0 	cbz	w0, 630c <fwp_free_zombie+0x7c>
    6398:	7100041f 	cmp	w0, #0x1
    639c:	54fffbe0 	b.eq	6318 <fwp_free_zombie+0x88>  // b.none
    63a0:	7103fc1f 	cmp	w0, #0xff
    63a4:	540001e0 	b.eq	63e0 <fwp_free_zombie+0x150>  // b.none
    63a8:	51000400 	sub	w0, w0, #0x1
    63ac:	39000280 	strb	w0, [x20]
    63b0:	17ffffd7 	b	630c <fwp_free_zombie+0x7c>
    63b4:	f9400e61 	ldr	x1, [x19, #24]
    63b8:	97fff156 	bl	2910 <munmap@plt>
    63bc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    63c0:	a9530261 	ldp	x1, x0, [x19, #304]
    63c4:	b5fff901 	cbnz	x1, 62e4 <fwp_free_zombie+0x54>
    63c8:	91010282 	add	x2, x20, #0x40
    63cc:	f9016840 	str	x0, [x2, #720]
    63d0:	17ffffc6 	b	62e8 <fwp_free_zombie+0x58>
    63d4:	72003c3f 	tst	w1, #0xffff
    63d8:	54fff9a1 	b.ne	630c <fwp_free_zombie+0x7c>  // b.any
    63dc:	17ffffed 	b	6390 <fwp_free_zombie+0x100>
    63e0:	ca544680 	eor	x0, x20, x20, lsr #17
    63e4:	9115c084 	add	x4, x4, #0x570
    63e8:	ca402400 	eor	x0, x0, x0, lsr #9
    63ec:	8b200c80 	add	x0, x4, w0, uxtb #3
    63f0:	f94a2400 	ldr	x0, [x0, #5192]
    63f4:	b5000080 	cbnz	x0, 6404 <fwp_free_zombie+0x174>
    63f8:	14000010 	b	6438 <fwp_free_zombie+0x1a8>
    63fc:	f9400800 	ldr	x0, [x0, #16]
    6400:	b40001c0 	cbz	x0, 6438 <fwp_free_zombie+0x1a8>
    6404:	f9400001 	ldr	x1, [x0]
    6408:	eb14003f 	cmp	x1, x20
    640c:	54ffff81 	b.ne	63fc <fwp_free_zombie+0x16c>  // b.any
    6410:	f9400401 	ldr	x1, [x0, #8]
    6414:	d1000421 	sub	x1, x1, #0x1
    6418:	f9000401 	str	x1, [x0, #8]
    641c:	f103f83f 	cmp	x1, #0xfe
    6420:	54fff761 	b.ne	630c <fwp_free_zombie+0x7c>  // b.any
    6424:	aa1403e0 	mov	x0, x20
    6428:	97fff846 	bl	4540 <fwp_rc_forget_slot>
    642c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6430:	39000280 	strb	w0, [x20]
    6434:	17ffffb6 	b	630c <fwp_free_zombie+0x7c>
    6438:	f0000020 	adrp	x0, d000 <__modti3+0x230>
    643c:	91106000 	add	x0, x0, #0x418
    6440:	97fff430 	bl	3500 <fwp_trap>

0000000000006444 <fwp_block>:
    6444:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6448:	910003fd 	mov	x29, sp
    644c:	a90153f3 	stp	x19, x20, [sp, #16]
    6450:	d00000d3 	adrp	x19, 20000 <__data_start>
    6454:	91010274 	add	x20, x19, #0x40
    6458:	f9401a82 	ldr	x2, [x20, #48]
    645c:	b4000622 	cbz	x2, 6520 <fwp_block+0xdc>
    6460:	91010261 	add	x1, x19, #0x40
    6464:	f9408040 	ldr	x0, [x2, #256]
    6468:	f9001820 	str	x0, [x1, #48]
    646c:	b4000680 	cbz	x0, 653c <fwp_block+0xf8>
    6470:	91010263 	add	x3, x19, #0x40
    6474:	3901505f 	strb	wzr, [x2, #84]
    6478:	f9400864 	ldr	x4, [x3, #16]
    647c:	eb02009f 	cmp	x4, x2
    6480:	54000440 	b.eq	6508 <fwp_block+0xc4>  // b.none
    6484:	f9416c65 	ldr	x5, [x3, #728]
    6488:	f9000862 	str	x2, [x3, #16]
    648c:	f9400441 	ldr	x1, [x2, #8]
    6490:	f9004885 	str	x5, [x4, #144]
    6494:	f9417065 	ldr	x5, [x3, #736]
    6498:	f9004c85 	str	x5, [x4, #152]
    649c:	f9417465 	ldr	x5, [x3, #744]
    64a0:	f9005085 	str	x5, [x4, #160]
    64a4:	f9417865 	ldr	x5, [x3, #752]
    64a8:	f9005485 	str	x5, [x4, #168]
    64ac:	f9417c65 	ldr	x5, [x3, #760]
    64b0:	f9005885 	str	x5, [x4, #176]
    64b4:	f9418065 	ldr	x5, [x3, #768]
    64b8:	f9005c85 	str	x5, [x4, #184]
    64bc:	f9418465 	ldr	x5, [x3, #776]
    64c0:	f9006085 	str	x5, [x4, #192]
    64c4:	f9400480 	ldr	x0, [x4, #8]
    64c8:	f9404844 	ldr	x4, [x2, #144]
    64cc:	f9016c64 	str	x4, [x3, #728]
    64d0:	f9404c44 	ldr	x4, [x2, #152]
    64d4:	f9017064 	str	x4, [x3, #736]
    64d8:	f9405044 	ldr	x4, [x2, #160]
    64dc:	f9017464 	str	x4, [x3, #744]
    64e0:	f9405444 	ldr	x4, [x2, #168]
    64e4:	f9017864 	str	x4, [x3, #752]
    64e8:	f9405844 	ldr	x4, [x2, #176]
    64ec:	f9017c64 	str	x4, [x3, #760]
    64f0:	a94b8844 	ldp	x4, x2, [x2, #184]
    64f4:	f9018064 	str	x4, [x3, #768]
    64f8:	f9018462 	str	x2, [x3, #776]
    64fc:	97fff0d5 	bl	2850 <swapcontext@plt>
    6500:	97ffff64 	bl	6290 <fwp_free_zombie>
    6504:	d503201f 	nop
    6508:	91010260 	add	x0, x19, #0x40
    650c:	b9431000 	ldr	w0, [x0, #784]
    6510:	340001a0 	cbz	w0, 6544 <fwp_block+0x100>
    6514:	a94153f3 	ldp	x19, x20, [sp, #16]
    6518:	a8c27bfd 	ldp	x29, x30, [sp], #32
    651c:	d65f03c0 	ret
    6520:	97fff734 	bl	41f0 <fwp_poll_events>
    6524:	f9401a82 	ldr	x2, [x20, #48]
    6528:	b4ffffc2 	cbz	x2, 6520 <fwp_block+0xdc>
    652c:	91010261 	add	x1, x19, #0x40
    6530:	f9408040 	ldr	x0, [x2, #256]
    6534:	f9001820 	str	x0, [x1, #48]
    6538:	b5fff9c0 	cbnz	x0, 6470 <fwp_block+0x2c>
    653c:	f900143f 	str	xzr, [x1, #40]
    6540:	17ffffcc 	b	6470 <fwp_block+0x2c>
    6544:	f0000020 	adrp	x0, d000 <__modti3+0x230>
    6548:	91152000 	add	x0, x0, #0x548
    654c:	97fff10d 	bl	2980 <getenv@plt>
    6550:	5284e202 	mov	w2, #0x2710                	// #10000
    6554:	b4000060 	cbz	x0, 6560 <fwp_block+0x11c>
    6558:	39400001 	ldrb	w1, [x0]
    655c:	350000c1 	cbnz	w1, 6574 <fwp_block+0x130>
    6560:	91010273 	add	x19, x19, #0x40
    6564:	b9031262 	str	w2, [x19, #784]
    6568:	a94153f3 	ldp	x19, x20, [sp, #16]
    656c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6570:	d65f03c0 	ret
    6574:	52800142 	mov	w2, #0xa                   	// #10
    6578:	d2800001 	mov	x1, #0x0                   	// #0
    657c:	97fff051 	bl	26c0 <strtoll@plt>
    6580:	d1000403 	sub	x3, x0, #0x1
    6584:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6588:	eb02007f 	cmp	x3, x2
    658c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6590:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6594:	17fffff3 	b	6560 <fwp_block+0x11c>
    6598:	d503201f 	nop
    659c:	d503201f 	nop

00000000000065a0 <fwp_drop4>:
    65a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    65a4:	910003fd 	mov	x29, sp
    65a8:	a90153f3 	stp	x19, x20, [sp, #16]
    65ac:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc70>
    65b0:	f90013f5 	str	x21, [sp, #32]
    65b4:	9115c275 	add	x21, x19, #0x570
    65b8:	f949daa1 	ldr	x1, [x21, #5040]
    65bc:	f949eea2 	ldr	x2, [x21, #5080]
    65c0:	cb010001 	sub	x1, x0, x1
    65c4:	eb02403f 	cmp	x1, x2, lsl #16
    65c8:	54000382 	b.cs	6638 <fwp_drop4+0x98>  // b.hs, b.nlast
    65cc:	d350fc22 	lsr	x2, x1, #16
    65d0:	f949fea3 	ldr	x3, [x21, #5112]
    65d4:	8b020842 	add	x2, x2, x2, lsl #2
    65d8:	d37df042 	lsl	x2, x2, #3
    65dc:	8b020064 	add	x4, x3, x2
    65e0:	f9401094 	ldr	x20, [x4, #32]
    65e4:	b40002b4 	cbz	x20, 6638 <fwp_drop4+0x98>
    65e8:	38626862 	ldrb	w2, [x3, x2]
    65ec:	7100085f 	cmp	w2, #0x2
    65f0:	540007a0 	b.eq	66e4 <fwp_drop4+0x144>  // b.none
    65f4:	7100045f 	cmp	w2, #0x1
    65f8:	54000201 	b.ne	6638 <fwp_drop4+0x98>  // b.any
    65fc:	29430885 	ldp	w5, w2, [x4, #24]
    6600:	92403c21 	and	x1, x1, #0xffff
    6604:	9b057c21 	mul	x1, x1, x5
    6608:	d360fc21 	lsr	x1, x1, #32
    660c:	eb02003f 	cmp	x1, x2
    6610:	54000142 	b.cs	6638 <fwp_drop4+0x98>  // b.hs, b.nlast
    6614:	8b010294 	add	x20, x20, x1
    6618:	39400281 	ldrb	w1, [x20]
    661c:	340000e1 	cbz	w1, 6638 <fwp_drop4+0x98>
    6620:	7100043f 	cmp	w1, #0x1
    6624:	54000120 	b.eq	6648 <fwp_drop4+0xa8>  // b.none
    6628:	7103fc3f 	cmp	w1, #0xff
    662c:	540007c0 	b.eq	6724 <fwp_drop4+0x184>  // b.none
    6630:	51000421 	sub	w1, w1, #0x1
    6634:	39000281 	strb	w1, [x20]
    6638:	a94153f3 	ldp	x19, x20, [sp, #16]
    663c:	f94013f5 	ldr	x21, [sp, #32]
    6640:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6644:	d65f03c0 	ret
    6648:	f9400001 	ldr	x1, [x0]
    664c:	b7f80581 	tbnz	x1, #63, 66fc <fwp_drop4+0x15c>
    6650:	9115c273 	add	x19, x19, #0x570
    6654:	f949da61 	ldr	x1, [x19, #5040]
    6658:	f949ee62 	ldr	x2, [x19, #5080]
    665c:	cb010001 	sub	x1, x0, x1
    6660:	eb02403f 	cmp	x1, x2, lsl #16
    6664:	54fffea2 	b.cs	6638 <fwp_drop4+0x98>  // b.hs, b.nlast
    6668:	d350fc22 	lsr	x2, x1, #16
    666c:	8b020842 	add	x2, x2, x2, lsl #2
    6670:	d37df042 	lsl	x2, x2, #3
    6674:	8b020065 	add	x5, x3, x2
    6678:	f94010a4 	ldr	x4, [x5, #32]
    667c:	b4fffde4 	cbz	x4, 6638 <fwp_drop4+0x98>
    6680:	38626862 	ldrb	w2, [x3, x2]
    6684:	7100085f 	cmp	w2, #0x2
    6688:	54000220 	b.eq	66cc <fwp_drop4+0x12c>  // b.none
    668c:	7100045f 	cmp	w2, #0x1
    6690:	54fffd41 	b.ne	6638 <fwp_drop4+0x98>  // b.any
    6694:	294308a3 	ldp	w3, w2, [x5, #24]
    6698:	92403c21 	and	x1, x1, #0xffff
    669c:	9b037c21 	mul	x1, x1, x3
    66a0:	d360fc21 	lsr	x1, x1, #32
    66a4:	eb02003f 	cmp	x1, x2
    66a8:	54fffc82 	b.cs	6638 <fwp_drop4+0x98>  // b.hs, b.nlast
    66ac:	8b010084 	add	x4, x4, x1
    66b0:	39400081 	ldrb	w1, [x4]
    66b4:	7100043f 	cmp	w1, #0x1
    66b8:	54fffc01 	b.ne	6638 <fwp_drop4+0x98>  // b.any
    66bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    66c0:	f94013f5 	ldr	x21, [sp, #32]
    66c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66c8:	17fff83e 	b	47c0 <fwp_mem_free>
    66cc:	72003c3f 	tst	w1, #0xffff
    66d0:	54ffff00 	b.eq	66b0 <fwp_drop4+0x110>  // b.none
    66d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66d8:	f94013f5 	ldr	x21, [sp, #32]
    66dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66e0:	d65f03c0 	ret
    66e4:	72003c3f 	tst	w1, #0xffff
    66e8:	54fff980 	b.eq	6618 <fwp_drop4+0x78>  // b.none
    66ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    66f0:	f94013f5 	ldr	x21, [sp, #32]
    66f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66f8:	d65f03c0 	ret
    66fc:	f9400414 	ldr	x20, [x0, #8]
    6700:	97fffbed 	bl	56b4 <fwp_rc_free_arr>
    6704:	9115c260 	add	x0, x19, #0x570
    6708:	f949d801 	ldr	x1, [x0, #5040]
    670c:	f949ec00 	ldr	x0, [x0, #5080]
    6710:	cb010281 	sub	x1, x20, x1
    6714:	eb00403f 	cmp	x1, x0, lsl #16
    6718:	54fff902 	b.cs	6638 <fwp_drop4+0x98>  // b.hs, b.nlast
    671c:	aa1403e0 	mov	x0, x20
    6720:	17ffffab 	b	65cc <fwp_drop4+0x2c>
    6724:	ca544680 	eor	x0, x20, x20, lsr #17
    6728:	9115c273 	add	x19, x19, #0x570
    672c:	ca402400 	eor	x0, x0, x0, lsr #9
    6730:	8b200e60 	add	x0, x19, w0, uxtb #3
    6734:	f94a2400 	ldr	x0, [x0, #5192]
    6738:	b5000080 	cbnz	x0, 6748 <fwp_drop4+0x1a8>
    673c:	14000010 	b	677c <fwp_drop4+0x1dc>
    6740:	f9400800 	ldr	x0, [x0, #16]
    6744:	b40001c0 	cbz	x0, 677c <fwp_drop4+0x1dc>
    6748:	f9400001 	ldr	x1, [x0]
    674c:	eb14003f 	cmp	x1, x20
    6750:	54ffff81 	b.ne	6740 <fwp_drop4+0x1a0>  // b.any
    6754:	f9400401 	ldr	x1, [x0, #8]
    6758:	d1000421 	sub	x1, x1, #0x1
    675c:	f9000401 	str	x1, [x0, #8]
    6760:	f103f83f 	cmp	x1, #0xfe
    6764:	54fff6a1 	b.ne	6638 <fwp_drop4+0x98>  // b.any
    6768:	aa1403e0 	mov	x0, x20
    676c:	97fff775 	bl	4540 <fwp_rc_forget_slot>
    6770:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6774:	39000280 	strb	w0, [x20]
    6778:	17ffffb0 	b	6638 <fwp_drop4+0x98>
    677c:	f0000020 	adrp	x0, d000 <__modti3+0x230>
    6780:	91106000 	add	x0, x0, #0x418
    6784:	97fff35f 	bl	3500 <fwp_trap>
    6788:	d503201f 	nop
    678c:	d503201f 	nop

0000000000006790 <fwp_caps161>:
    6790:	34000041 	cbz	w1, 6798 <fwp_caps161+0x8>
    6794:	d65f03c0 	ret
    6798:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc70>
    679c:	9115c063 	add	x3, x3, #0x570
    67a0:	f949d861 	ldr	x1, [x3, #5040]
    67a4:	f949ec62 	ldr	x2, [x3, #5080]
    67a8:	cb010001 	sub	x1, x0, x1
    67ac:	eb02403f 	cmp	x1, x2, lsl #16
    67b0:	54ffff22 	b.cs	6794 <fwp_caps161+0x4>  // b.hs, b.nlast
    67b4:	d350fc22 	lsr	x2, x1, #16
    67b8:	f949fc65 	ldr	x5, [x3, #5112]
    67bc:	8b020842 	add	x2, x2, x2, lsl #2
    67c0:	d37df042 	lsl	x2, x2, #3
    67c4:	8b0200a4 	add	x4, x5, x2
    67c8:	f9401083 	ldr	x3, [x4, #32]
    67cc:	b4fffe43 	cbz	x3, 6794 <fwp_caps161+0x4>
    67d0:	386268a2 	ldrb	w2, [x5, x2]
    67d4:	7100085f 	cmp	w2, #0x2
    67d8:	540001c0 	b.eq	6810 <fwp_caps161+0x80>  // b.none
    67dc:	7100045f 	cmp	w2, #0x1
    67e0:	54fffda1 	b.ne	6794 <fwp_caps161+0x4>  // b.any
    67e4:	29430885 	ldp	w5, w2, [x4, #24]
    67e8:	92403c21 	and	x1, x1, #0xffff
    67ec:	9b057c21 	mul	x1, x1, x5
    67f0:	d360fc21 	lsr	x1, x1, #32
    67f4:	eb02003f 	cmp	x1, x2
    67f8:	54fffce2 	b.cs	6794 <fwp_caps161+0x4>  // b.hs, b.nlast
    67fc:	8b010063 	add	x3, x3, x1
    6800:	39400061 	ldrb	w1, [x3]
    6804:	7100043f 	cmp	w1, #0x1
    6808:	54fffc61 	b.ne	6794 <fwp_caps161+0x4>  // b.any
    680c:	17fff7ed 	b	47c0 <fwp_mem_free>
    6810:	72003c3f 	tst	w1, #0xffff
    6814:	54ffff60 	b.eq	6800 <fwp_caps161+0x70>  // b.none
    6818:	d65f03c0 	ret
    681c:	d503201f 	nop

0000000000006820 <fwp_args23>:
    6820:	7100003f 	cmp	w1, #0x0
    6824:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6828:	54000041 	b.ne	6830 <fwp_args23+0x10>  // b.any
    682c:	d65f03c0 	ret
    6830:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    6834:	9115c042 	add	x2, x2, #0x570
    6838:	f9400001 	ldr	x1, [x0]
    683c:	f949d843 	ldr	x3, [x2, #5040]
    6840:	f949ec40 	ldr	x0, [x2, #5080]
    6844:	cb030021 	sub	x1, x1, x3
    6848:	eb00403f 	cmp	x1, x0, lsl #16
    684c:	54ffff02 	b.cs	682c <fwp_args23+0xc>  // b.hs, b.nlast
    6850:	d350fc20 	lsr	x0, x1, #16
    6854:	f949fc44 	ldr	x4, [x2, #5112]
    6858:	8b000800 	add	x0, x0, x0, lsl #2
    685c:	d37df002 	lsl	x2, x0, #3
    6860:	8b020083 	add	x3, x4, x2
    6864:	f9401060 	ldr	x0, [x3, #32]
    6868:	b4fffe20 	cbz	x0, 682c <fwp_args23+0xc>
    686c:	38626882 	ldrb	w2, [x4, x2]
    6870:	7100085f 	cmp	w2, #0x2
    6874:	54000220 	b.eq	68b8 <fwp_args23+0x98>  // b.none
    6878:	7100045f 	cmp	w2, #0x1
    687c:	54fffd81 	b.ne	682c <fwp_args23+0xc>  // b.any
    6880:	29430864 	ldp	w4, w2, [x3, #24]
    6884:	92403c21 	and	x1, x1, #0xffff
    6888:	9b047c21 	mul	x1, x1, x4
    688c:	d360fc21 	lsr	x1, x1, #32
    6890:	eb02003f 	cmp	x1, x2
    6894:	54fffcc2 	b.cs	682c <fwp_args23+0xc>  // b.hs, b.nlast
    6898:	8b010000 	add	x0, x0, x1
    689c:	39400001 	ldrb	w1, [x0]
    68a0:	34fffc61 	cbz	w1, 682c <fwp_args23+0xc>
    68a4:	7103f43f 	cmp	w1, #0xfd
    68a8:	540000e8 	b.hi	68c4 <fwp_args23+0xa4>  // b.pmore
    68ac:	11000421 	add	w1, w1, #0x1
    68b0:	39000001 	strb	w1, [x0]
    68b4:	d65f03c0 	ret
    68b8:	72003c3f 	tst	w1, #0xffff
    68bc:	54ffff00 	b.eq	689c <fwp_args23+0x7c>  // b.none
    68c0:	d65f03c0 	ret
    68c4:	17fff6d8 	b	4424 <fwp_rc_wide_dup>
    68c8:	d503201f 	nop
    68cc:	d503201f 	nop

00000000000068d0 <fwp_args12>:
    68d0:	7100003f 	cmp	w1, #0x0
    68d4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    68d8:	54000041 	b.ne	68e0 <fwp_args12+0x10>  // b.any
    68dc:	d65f03c0 	ret
    68e0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    68e4:	9115c042 	add	x2, x2, #0x570
    68e8:	f9400001 	ldr	x1, [x0]
    68ec:	f949d843 	ldr	x3, [x2, #5040]
    68f0:	f949ec40 	ldr	x0, [x2, #5080]
    68f4:	cb030021 	sub	x1, x1, x3
    68f8:	eb00403f 	cmp	x1, x0, lsl #16
    68fc:	54ffff02 	b.cs	68dc <fwp_args12+0xc>  // b.hs, b.nlast
    6900:	d350fc20 	lsr	x0, x1, #16
    6904:	f949fc44 	ldr	x4, [x2, #5112]
    6908:	8b000800 	add	x0, x0, x0, lsl #2
    690c:	d37df002 	lsl	x2, x0, #3
    6910:	8b020083 	add	x3, x4, x2
    6914:	f9401060 	ldr	x0, [x3, #32]
    6918:	b4fffe20 	cbz	x0, 68dc <fwp_args12+0xc>
    691c:	38626882 	ldrb	w2, [x4, x2]
    6920:	7100085f 	cmp	w2, #0x2
    6924:	54000220 	b.eq	6968 <fwp_args12+0x98>  // b.none
    6928:	7100045f 	cmp	w2, #0x1
    692c:	54fffd81 	b.ne	68dc <fwp_args12+0xc>  // b.any
    6930:	29430864 	ldp	w4, w2, [x3, #24]
    6934:	92403c21 	and	x1, x1, #0xffff
    6938:	9b047c21 	mul	x1, x1, x4
    693c:	d360fc21 	lsr	x1, x1, #32
    6940:	eb02003f 	cmp	x1, x2
    6944:	54fffcc2 	b.cs	68dc <fwp_args12+0xc>  // b.hs, b.nlast
    6948:	8b010000 	add	x0, x0, x1
    694c:	39400001 	ldrb	w1, [x0]
    6950:	34fffc61 	cbz	w1, 68dc <fwp_args12+0xc>
    6954:	7103f43f 	cmp	w1, #0xfd
    6958:	540000e8 	b.hi	6974 <fwp_args12+0xa4>  // b.pmore
    695c:	11000421 	add	w1, w1, #0x1
    6960:	39000001 	strb	w1, [x0]
    6964:	d65f03c0 	ret
    6968:	72003c3f 	tst	w1, #0xffff
    696c:	54ffff00 	b.eq	694c <fwp_args12+0x7c>  // b.none
    6970:	d65f03c0 	ret
    6974:	17fff6ac 	b	4424 <fwp_rc_wide_dup>
    6978:	d503201f 	nop
    697c:	d503201f 	nop

0000000000006980 <fwp_caps12>:
    6980:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6984:	910003fd 	mov	x29, sp
    6988:	f9000bf3 	str	x19, [sp, #16]
    698c:	aa0003f3 	mov	x19, x0
    6990:	b9400400 	ldr	w0, [x0, #4]
    6994:	340004a0 	cbz	w0, 6a28 <fwp_caps12+0xa8>
    6998:	f9400660 	ldr	x0, [x19, #8]
    699c:	350004e1 	cbnz	w1, 6a38 <fwp_caps12+0xb8>
    69a0:	97fffc70 	bl	5b60 <fwp_drop0>
    69a4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    69a8:	9115c042 	add	x2, x2, #0x570
    69ac:	f949d840 	ldr	x0, [x2, #5040]
    69b0:	f949ec41 	ldr	x1, [x2, #5080]
    69b4:	cb000260 	sub	x0, x19, x0
    69b8:	eb01401f 	cmp	x0, x1, lsl #16
    69bc:	54000382 	b.cs	6a2c <fwp_caps12+0xac>  // b.hs, b.nlast
    69c0:	d350fc01 	lsr	x1, x0, #16
    69c4:	f949fc44 	ldr	x4, [x2, #5112]
    69c8:	8b010821 	add	x1, x1, x1, lsl #2
    69cc:	d37df021 	lsl	x1, x1, #3
    69d0:	8b010083 	add	x3, x4, x1
    69d4:	f9401062 	ldr	x2, [x3, #32]
    69d8:	b40002a2 	cbz	x2, 6a2c <fwp_caps12+0xac>
    69dc:	38616881 	ldrb	w1, [x4, x1]
    69e0:	7100083f 	cmp	w1, #0x2
    69e4:	540006c0 	b.eq	6abc <fwp_caps12+0x13c>  // b.none
    69e8:	7100043f 	cmp	w1, #0x1
    69ec:	54000201 	b.ne	6a2c <fwp_caps12+0xac>  // b.any
    69f0:	29430464 	ldp	w4, w1, [x3, #24]
    69f4:	92403c00 	and	x0, x0, #0xffff
    69f8:	9b047c00 	mul	x0, x0, x4
    69fc:	d360fc00 	lsr	x0, x0, #32
    6a00:	eb01001f 	cmp	x0, x1
    6a04:	54000142 	b.cs	6a2c <fwp_caps12+0xac>  // b.hs, b.nlast
    6a08:	8b000042 	add	x2, x2, x0
    6a0c:	39400040 	ldrb	w0, [x2]
    6a10:	7100041f 	cmp	w0, #0x1
    6a14:	540000c1 	b.ne	6a2c <fwp_caps12+0xac>  // b.any
    6a18:	aa1303e0 	mov	x0, x19
    6a1c:	f9400bf3 	ldr	x19, [sp, #16]
    6a20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a24:	17fff767 	b	47c0 <fwp_mem_free>
    6a28:	34fffbe1 	cbz	w1, 69a4 <fwp_caps12+0x24>
    6a2c:	f9400bf3 	ldr	x19, [sp, #16]
    6a30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a34:	d65f03c0 	ret
    6a38:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    6a3c:	9115c042 	add	x2, x2, #0x570
    6a40:	f949d843 	ldr	x3, [x2, #5040]
    6a44:	f949ec41 	ldr	x1, [x2, #5080]
    6a48:	cb030000 	sub	x0, x0, x3
    6a4c:	eb01401f 	cmp	x0, x1, lsl #16
    6a50:	54fffee2 	b.cs	6a2c <fwp_caps12+0xac>  // b.hs, b.nlast
    6a54:	d350fc01 	lsr	x1, x0, #16
    6a58:	f949fc44 	ldr	x4, [x2, #5112]
    6a5c:	8b010821 	add	x1, x1, x1, lsl #2
    6a60:	d37df021 	lsl	x1, x1, #3
    6a64:	8b010083 	add	x3, x4, x1
    6a68:	f9401062 	ldr	x2, [x3, #32]
    6a6c:	b4fffe02 	cbz	x2, 6a2c <fwp_caps12+0xac>
    6a70:	38616881 	ldrb	w1, [x4, x1]
    6a74:	7100083f 	cmp	w1, #0x2
    6a78:	54000280 	b.eq	6ac8 <fwp_caps12+0x148>  // b.none
    6a7c:	7100043f 	cmp	w1, #0x1
    6a80:	54fffd61 	b.ne	6a2c <fwp_caps12+0xac>  // b.any
    6a84:	92403c01 	and	x1, x0, #0xffff
    6a88:	29430064 	ldp	w4, w0, [x3, #24]
    6a8c:	9b047c21 	mul	x1, x1, x4
    6a90:	d360fc21 	lsr	x1, x1, #32
    6a94:	eb00003f 	cmp	x1, x0
    6a98:	54fffca2 	b.cs	6a2c <fwp_caps12+0xac>  // b.hs, b.nlast
    6a9c:	8b010042 	add	x2, x2, x1
    6aa0:	39400040 	ldrb	w0, [x2]
    6aa4:	34fffc40 	cbz	w0, 6a2c <fwp_caps12+0xac>
    6aa8:	7103f41f 	cmp	w0, #0xfd
    6aac:	54000148 	b.hi	6ad4 <fwp_caps12+0x154>  // b.pmore
    6ab0:	11000400 	add	w0, w0, #0x1
    6ab4:	39000040 	strb	w0, [x2]
    6ab8:	17ffffdd 	b	6a2c <fwp_caps12+0xac>
    6abc:	72003c1f 	tst	w0, #0xffff
    6ac0:	54fffb61 	b.ne	6a2c <fwp_caps12+0xac>  // b.any
    6ac4:	17ffffd2 	b	6a0c <fwp_caps12+0x8c>
    6ac8:	72003c1f 	tst	w0, #0xffff
    6acc:	54fffb01 	b.ne	6a2c <fwp_caps12+0xac>  // b.any
    6ad0:	17fffff4 	b	6aa0 <fwp_caps12+0x120>
    6ad4:	f9400bf3 	ldr	x19, [sp, #16]
    6ad8:	aa0203e0 	mov	x0, x2
    6adc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ae0:	17fff651 	b	4424 <fwp_rc_wide_dup>

0000000000006ae4 <fwp_drop2>:
    6ae4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6ae8:	910003fd 	mov	x29, sp
    6aec:	a9025bf5 	stp	x21, x22, [sp, #32]
    6af0:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc70>
    6af4:	9115c2d5 	add	x21, x22, #0x570
    6af8:	a90153f3 	stp	x19, x20, [sp, #16]
    6afc:	aa0003f3 	mov	x19, x0
    6b00:	f949daa1 	ldr	x1, [x21, #5040]
    6b04:	f949eea0 	ldr	x0, [x21, #5080]
    6b08:	cb010261 	sub	x1, x19, x1
    6b0c:	eb00403f 	cmp	x1, x0, lsl #16
    6b10:	54000382 	b.cs	6b80 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6b14:	d350fc22 	lsr	x2, x1, #16
    6b18:	f949fea3 	ldr	x3, [x21, #5112]
    6b1c:	8b020842 	add	x2, x2, x2, lsl #2
    6b20:	d37df042 	lsl	x2, x2, #3
    6b24:	8b020060 	add	x0, x3, x2
    6b28:	f9401014 	ldr	x20, [x0, #32]
    6b2c:	b40002b4 	cbz	x20, 6b80 <fwp_drop2+0x9c>
    6b30:	38626862 	ldrb	w2, [x3, x2]
    6b34:	7100085f 	cmp	w2, #0x2
    6b38:	540002c0 	b.eq	6b90 <fwp_drop2+0xac>  // b.none
    6b3c:	7100045f 	cmp	w2, #0x1
    6b40:	54000201 	b.ne	6b80 <fwp_drop2+0x9c>  // b.any
    6b44:	29430002 	ldp	w2, w0, [x0, #24]
    6b48:	92403c21 	and	x1, x1, #0xffff
    6b4c:	9b027c21 	mul	x1, x1, x2
    6b50:	d360fc21 	lsr	x1, x1, #32
    6b54:	eb00003f 	cmp	x1, x0
    6b58:	54000142 	b.cs	6b80 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6b5c:	8b010294 	add	x20, x20, x1
    6b60:	39400280 	ldrb	w0, [x20]
    6b64:	340000e0 	cbz	w0, 6b80 <fwp_drop2+0x9c>
    6b68:	7100041f 	cmp	w0, #0x1
    6b6c:	540001e0 	b.eq	6ba8 <fwp_drop2+0xc4>  // b.none
    6b70:	7103fc1f 	cmp	w0, #0xff
    6b74:	540007e0 	b.eq	6c70 <fwp_drop2+0x18c>  // b.none
    6b78:	51000400 	sub	w0, w0, #0x1
    6b7c:	39000280 	strb	w0, [x20]
    6b80:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b84:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6b88:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b8c:	d65f03c0 	ret
    6b90:	72003c3f 	tst	w1, #0xffff
    6b94:	54fffe60 	b.eq	6b60 <fwp_drop2+0x7c>  // b.none
    6b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6ba0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ba4:	d65f03c0 	ret
    6ba8:	9115c2c2 	add	x2, x22, #0x570
    6bac:	f9400660 	ldr	x0, [x19, #8]
    6bb0:	f949d841 	ldr	x1, [x2, #5040]
    6bb4:	f949ec42 	ldr	x2, [x2, #5080]
    6bb8:	cb010001 	sub	x1, x0, x1
    6bbc:	eb02403f 	cmp	x1, x2, lsl #16
    6bc0:	54000382 	b.cs	6c30 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6bc4:	d350fc22 	lsr	x2, x1, #16
    6bc8:	8b020842 	add	x2, x2, x2, lsl #2
    6bcc:	d37df042 	lsl	x2, x2, #3
    6bd0:	8b020064 	add	x4, x3, x2
    6bd4:	f9401094 	ldr	x20, [x4, #32]
    6bd8:	b40002d4 	cbz	x20, 6c30 <fwp_drop2+0x14c>
    6bdc:	38626862 	ldrb	w2, [x3, x2]
    6be0:	7100085f 	cmp	w2, #0x2
    6be4:	54000400 	b.eq	6c64 <fwp_drop2+0x180>  // b.none
    6be8:	7100045f 	cmp	w2, #0x1
    6bec:	54000221 	b.ne	6c30 <fwp_drop2+0x14c>  // b.any
    6bf0:	29430883 	ldp	w3, w2, [x4, #24]
    6bf4:	92403c21 	and	x1, x1, #0xffff
    6bf8:	9b037c21 	mul	x1, x1, x3
    6bfc:	d360fc21 	lsr	x1, x1, #32
    6c00:	eb02003f 	cmp	x1, x2
    6c04:	54000162 	b.cs	6c30 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6c08:	8b010294 	add	x20, x20, x1
    6c0c:	39400281 	ldrb	w1, [x20]
    6c10:	34000101 	cbz	w1, 6c30 <fwp_drop2+0x14c>
    6c14:	7100043f 	cmp	w1, #0x1
    6c18:	54000220 	b.eq	6c5c <fwp_drop2+0x178>  // b.none
    6c1c:	7103fc3f 	cmp	w1, #0xff
    6c20:	540005a0 	b.eq	6cd4 <fwp_drop2+0x1f0>  // b.none
    6c24:	51000421 	sub	w1, w1, #0x1
    6c28:	39000281 	strb	w1, [x20]
    6c2c:	d503201f 	nop
    6c30:	f9400a74 	ldr	x20, [x19, #16]
    6c34:	aa1303e0 	mov	x0, x19
    6c38:	97fffa9f 	bl	56b4 <fwp_rc_free_arr>
    6c3c:	9115c2c0 	add	x0, x22, #0x570
    6c40:	f949d801 	ldr	x1, [x0, #5040]
    6c44:	f949ec00 	ldr	x0, [x0, #5080]
    6c48:	cb010281 	sub	x1, x20, x1
    6c4c:	eb00403f 	cmp	x1, x0, lsl #16
    6c50:	54fff982 	b.cs	6b80 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6c54:	aa1403f3 	mov	x19, x20
    6c58:	17ffffaf 	b	6b14 <fwp_drop2+0x30>
    6c5c:	97fffa96 	bl	56b4 <fwp_rc_free_arr>
    6c60:	17fffff4 	b	6c30 <fwp_drop2+0x14c>
    6c64:	72003c3f 	tst	w1, #0xffff
    6c68:	54fffe41 	b.ne	6c30 <fwp_drop2+0x14c>  // b.any
    6c6c:	17ffffe8 	b	6c0c <fwp_drop2+0x128>
    6c70:	ca544681 	eor	x1, x20, x20, lsr #17
    6c74:	9115c2c0 	add	x0, x22, #0x570
    6c78:	ca412421 	eor	x1, x1, x1, lsr #9
    6c7c:	8b210c01 	add	x1, x0, w1, uxtb #3
    6c80:	f94a2420 	ldr	x0, [x1, #5192]
    6c84:	b5000080 	cbnz	x0, 6c94 <fwp_drop2+0x1b0>
    6c88:	14000010 	b	6cc8 <fwp_drop2+0x1e4>
    6c8c:	f9400800 	ldr	x0, [x0, #16]
    6c90:	b40001c0 	cbz	x0, 6cc8 <fwp_drop2+0x1e4>
    6c94:	f9400001 	ldr	x1, [x0]
    6c98:	eb14003f 	cmp	x1, x20
    6c9c:	54ffff81 	b.ne	6c8c <fwp_drop2+0x1a8>  // b.any
    6ca0:	f9400401 	ldr	x1, [x0, #8]
    6ca4:	d1000421 	sub	x1, x1, #0x1
    6ca8:	f9000401 	str	x1, [x0, #8]
    6cac:	f103f83f 	cmp	x1, #0xfe
    6cb0:	54fff681 	b.ne	6b80 <fwp_drop2+0x9c>  // b.any
    6cb4:	aa1403e0 	mov	x0, x20
    6cb8:	97fff622 	bl	4540 <fwp_rc_forget_slot>
    6cbc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6cc0:	39000280 	strb	w0, [x20]
    6cc4:	17ffffaf 	b	6b80 <fwp_drop2+0x9c>
    6cc8:	f0000020 	adrp	x0, d000 <__modti3+0x230>
    6ccc:	91106000 	add	x0, x0, #0x418
    6cd0:	97fff20c 	bl	3500 <fwp_trap>
    6cd4:	ca544680 	eor	x0, x20, x20, lsr #17
    6cd8:	9115c2c1 	add	x1, x22, #0x570
    6cdc:	ca402400 	eor	x0, x0, x0, lsr #9
    6ce0:	8b200c20 	add	x0, x1, w0, uxtb #3
    6ce4:	f94a2400 	ldr	x0, [x0, #5192]
    6ce8:	b5000080 	cbnz	x0, 6cf8 <fwp_drop2+0x214>
    6cec:	17fffff7 	b	6cc8 <fwp_drop2+0x1e4>
    6cf0:	f9400800 	ldr	x0, [x0, #16]
    6cf4:	b4fffea0 	cbz	x0, 6cc8 <fwp_drop2+0x1e4>
    6cf8:	f9400001 	ldr	x1, [x0]
    6cfc:	eb14003f 	cmp	x1, x20
    6d00:	54ffff81 	b.ne	6cf0 <fwp_drop2+0x20c>  // b.any
    6d04:	f9400401 	ldr	x1, [x0, #8]
    6d08:	d1000421 	sub	x1, x1, #0x1
    6d0c:	f9000401 	str	x1, [x0, #8]
    6d10:	f103f83f 	cmp	x1, #0xfe
    6d14:	54fff8e1 	b.ne	6c30 <fwp_drop2+0x14c>  // b.any
    6d18:	aa1403e0 	mov	x0, x20
    6d1c:	97fff609 	bl	4540 <fwp_rc_forget_slot>
    6d20:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6d24:	39000280 	strb	w0, [x20]
    6d28:	17ffffc2 	b	6c30 <fwp_drop2+0x14c>
    6d2c:	d503201f 	nop

0000000000006d30 <fwp_arg_drop23>:
    6d30:	7100003f 	cmp	w1, #0x0
    6d34:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6d38:	54000041 	b.ne	6d40 <fwp_arg_drop23+0x10>  // b.any
    6d3c:	d65f03c0 	ret
    6d40:	f9400000 	ldr	x0, [x0]
    6d44:	17ffff68 	b	6ae4 <fwp_drop2>
    6d48:	d503201f 	nop
    6d4c:	d503201f 	nop

0000000000006d50 <fwp_caps23>:
    6d50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d54:	910003fd 	mov	x29, sp
    6d58:	f9000bf3 	str	x19, [sp, #16]
    6d5c:	aa0003f3 	mov	x19, x0
    6d60:	b9400400 	ldr	w0, [x0, #4]
    6d64:	340004a0 	cbz	w0, 6df8 <fwp_caps23+0xa8>
    6d68:	f9400660 	ldr	x0, [x19, #8]
    6d6c:	350004e1 	cbnz	w1, 6e08 <fwp_caps23+0xb8>
    6d70:	97ffff5d 	bl	6ae4 <fwp_drop2>
    6d74:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    6d78:	9115c042 	add	x2, x2, #0x570
    6d7c:	f949d840 	ldr	x0, [x2, #5040]
    6d80:	f949ec41 	ldr	x1, [x2, #5080]
    6d84:	cb000260 	sub	x0, x19, x0
    6d88:	eb01401f 	cmp	x0, x1, lsl #16
    6d8c:	54000382 	b.cs	6dfc <fwp_caps23+0xac>  // b.hs, b.nlast
    6d90:	d350fc01 	lsr	x1, x0, #16
    6d94:	f949fc44 	ldr	x4, [x2, #5112]
    6d98:	8b010821 	add	x1, x1, x1, lsl #2
    6d9c:	d37df021 	lsl	x1, x1, #3
    6da0:	8b010083 	add	x3, x4, x1
    6da4:	f9401062 	ldr	x2, [x3, #32]
    6da8:	b40002a2 	cbz	x2, 6dfc <fwp_caps23+0xac>
    6dac:	38616881 	ldrb	w1, [x4, x1]
    6db0:	7100083f 	cmp	w1, #0x2
    6db4:	540006c0 	b.eq	6e8c <fwp_caps23+0x13c>  // b.none
    6db8:	7100043f 	cmp	w1, #0x1
    6dbc:	54000201 	b.ne	6dfc <fwp_caps23+0xac>  // b.any
    6dc0:	29430464 	ldp	w4, w1, [x3, #24]
    6dc4:	92403c00 	and	x0, x0, #0xffff
    6dc8:	9b047c00 	mul	x0, x0, x4
    6dcc:	d360fc00 	lsr	x0, x0, #32
    6dd0:	eb01001f 	cmp	x0, x1
    6dd4:	54000142 	b.cs	6dfc <fwp_caps23+0xac>  // b.hs, b.nlast
    6dd8:	8b000042 	add	x2, x2, x0
    6ddc:	39400040 	ldrb	w0, [x2]
    6de0:	7100041f 	cmp	w0, #0x1
    6de4:	540000c1 	b.ne	6dfc <fwp_caps23+0xac>  // b.any
    6de8:	aa1303e0 	mov	x0, x19
    6dec:	f9400bf3 	ldr	x19, [sp, #16]
    6df0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6df4:	17fff673 	b	47c0 <fwp_mem_free>
    6df8:	34fffbe1 	cbz	w1, 6d74 <fwp_caps23+0x24>
    6dfc:	f9400bf3 	ldr	x19, [sp, #16]
    6e00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e04:	d65f03c0 	ret
    6e08:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    6e0c:	9115c042 	add	x2, x2, #0x570
    6e10:	f949d843 	ldr	x3, [x2, #5040]
    6e14:	f949ec41 	ldr	x1, [x2, #5080]
    6e18:	cb030000 	sub	x0, x0, x3
    6e1c:	eb01401f 	cmp	x0, x1, lsl #16
    6e20:	54fffee2 	b.cs	6dfc <fwp_caps23+0xac>  // b.hs, b.nlast
    6e24:	d350fc01 	lsr	x1, x0, #16
    6e28:	f949fc44 	ldr	x4, [x2, #5112]
    6e2c:	8b010821 	add	x1, x1, x1, lsl #2
    6e30:	d37df021 	lsl	x1, x1, #3
    6e34:	8b010083 	add	x3, x4, x1
    6e38:	f9401062 	ldr	x2, [x3, #32]
    6e3c:	b4fffe02 	cbz	x2, 6dfc <fwp_caps23+0xac>
    6e40:	38616881 	ldrb	w1, [x4, x1]
    6e44:	7100083f 	cmp	w1, #0x2
    6e48:	54000280 	b.eq	6e98 <fwp_caps23+0x148>  // b.none
    6e4c:	7100043f 	cmp	w1, #0x1
    6e50:	54fffd61 	b.ne	6dfc <fwp_caps23+0xac>  // b.any
    6e54:	92403c01 	and	x1, x0, #0xffff
    6e58:	29430064 	ldp	w4, w0, [x3, #24]
    6e5c:	9b047c21 	mul	x1, x1, x4
    6e60:	d360fc21 	lsr	x1, x1, #32
    6e64:	eb00003f 	cmp	x1, x0
    6e68:	54fffca2 	b.cs	6dfc <fwp_caps23+0xac>  // b.hs, b.nlast
    6e6c:	8b010042 	add	x2, x2, x1
    6e70:	39400040 	ldrb	w0, [x2]
    6e74:	34fffc40 	cbz	w0, 6dfc <fwp_caps23+0xac>
    6e78:	7103f41f 	cmp	w0, #0xfd
    6e7c:	54000148 	b.hi	6ea4 <fwp_caps23+0x154>  // b.pmore
    6e80:	11000400 	add	w0, w0, #0x1
    6e84:	39000040 	strb	w0, [x2]
    6e88:	17ffffdd 	b	6dfc <fwp_caps23+0xac>
    6e8c:	72003c1f 	tst	w0, #0xffff
    6e90:	54fffb61 	b.ne	6dfc <fwp_caps23+0xac>  // b.any
    6e94:	17ffffd2 	b	6ddc <fwp_caps23+0x8c>
    6e98:	72003c1f 	tst	w0, #0xffff
    6e9c:	54fffb01 	b.ne	6dfc <fwp_caps23+0xac>  // b.any
    6ea0:	17fffff4 	b	6e70 <fwp_caps23+0x120>
    6ea4:	f9400bf3 	ldr	x19, [sp, #16]
    6ea8:	aa0203e0 	mov	x0, x2
    6eac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6eb0:	17fff55d 	b	4424 <fwp_rc_wide_dup>

0000000000006eb4 <f23>:
    6eb4:	d101c3ff 	sub	sp, sp, #0x70
    6eb8:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6ebc:	f947f421 	ldr	x1, [x1, #4072]
    6ec0:	a9027bfd 	stp	x29, x30, [sp, #32]
    6ec4:	910083fd 	add	x29, sp, #0x20
    6ec8:	a90563f7 	stp	x23, x24, [sp, #80]
    6ecc:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc70>
    6ed0:	9115c2e3 	add	x3, x23, #0x570
    6ed4:	a90353f3 	stp	x19, x20, [sp, #48]
    6ed8:	a9045bf5 	stp	x21, x22, [sp, #64]
    6edc:	aa0003f6 	mov	x22, x0
    6ee0:	a9066bf9 	stp	x25, x26, [sp, #96]
    6ee4:	f949ec62 	ldr	x2, [x3, #5080]
    6ee8:	f9400024 	ldr	x4, [x1]
    6eec:	f9000fe4 	str	x4, [sp, #24]
    6ef0:	d2800004 	mov	x4, #0x0                   	// #0
    6ef4:	f949d861 	ldr	x1, [x3, #5040]
    6ef8:	d370bc42 	lsl	x2, x2, #16
    6efc:	b40015a0 	cbz	x0, 71b0 <f23+0x2fc>
    6f00:	f9400818 	ldr	x24, [x0, #16]
    6f04:	cb010301 	sub	x1, x24, x1
    6f08:	eb02003f 	cmp	x1, x2
    6f0c:	54000362 	b.cs	6f78 <f23+0xc4>  // b.hs, b.nlast
    6f10:	f949fc60 	ldr	x0, [x3, #5112]
    6f14:	d350fc22 	lsr	x2, x1, #16
    6f18:	8b020842 	add	x2, x2, x2, lsl #2
    6f1c:	8b020c02 	add	x2, x0, x2, lsl #3
    6f20:	f9401040 	ldr	x0, [x2, #32]
    6f24:	b40002a0 	cbz	x0, 6f78 <f23+0xc4>
    6f28:	39400043 	ldrb	w3, [x2]
    6f2c:	7100087f 	cmp	w3, #0x2
    6f30:	540013a0 	b.eq	71a4 <f23+0x2f0>  // b.none
    6f34:	7100047f 	cmp	w3, #0x1
    6f38:	540001c1 	b.ne	6f70 <f23+0xbc>  // b.any
    6f3c:	29430843 	ldp	w3, w2, [x2, #24]
    6f40:	92403c21 	and	x1, x1, #0xffff
    6f44:	9b037c21 	mul	x1, x1, x3
    6f48:	d360fc21 	lsr	x1, x1, #32
    6f4c:	eb02003f 	cmp	x1, x2
    6f50:	54000102 	b.cs	6f70 <f23+0xbc>  // b.hs, b.nlast
    6f54:	8b010000 	add	x0, x0, x1
    6f58:	39400001 	ldrb	w1, [x0]
    6f5c:	340000a1 	cbz	w1, 6f70 <f23+0xbc>
    6f60:	7103f43f 	cmp	w1, #0xfd
    6f64:	54001688 	b.hi	7234 <f23+0x380>  // b.pmore
    6f68:	11000421 	add	w1, w1, #0x1
    6f6c:	39000001 	strb	w1, [x0]
    6f70:	d2800000 	mov	x0, #0x0                   	// #0
    6f74:	b40000d6 	cbz	x22, 6f8c <f23+0xd8>
    6f78:	aa1603e1 	mov	x1, x22
    6f7c:	d2800000 	mov	x0, #0x0                   	// #0
    6f80:	f9400821 	ldr	x1, [x1, #16]
    6f84:	91000400 	add	x0, x0, #0x1
    6f88:	b5ffffc1 	cbnz	x1, 6f80 <f23+0xcc>
    6f8c:	b40011b8 	cbz	x24, 71c0 <f23+0x30c>
    6f90:	aa1803e1 	mov	x1, x24
    6f94:	d2800002 	mov	x2, #0x0                   	// #0
    6f98:	f9400821 	ldr	x1, [x1, #16]
    6f9c:	91000442 	add	x2, x2, #0x1
    6fa0:	b5ffffc1 	cbnz	x1, 6f98 <f23+0xe4>
    6fa4:	eb00005f 	cmp	x2, x0
    6fa8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6fac:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6fb0:	eb01033f 	cmp	x25, x1
    6fb4:	54001468 	b.hi	7240 <f23+0x38c>  // b.pmore
    6fb8:	d37ffb33 	lsl	x19, x25, #1
    6fbc:	52800041 	mov	w1, #0x2                   	// #2
    6fc0:	91000660 	add	x0, x19, #0x1
    6fc4:	d37df000 	lsl	x0, x0, #3
    6fc8:	97fff71e 	bl	4c40 <fwp_heap_alloc>
    6fcc:	9115c2e1 	add	x1, x23, #0x570
    6fd0:	aa0003fa 	mov	x26, x0
    6fd4:	f9000013 	str	x19, [x0]
    6fd8:	aa0103e0 	mov	x0, x1
    6fdc:	f949d821 	ldr	x1, [x1, #5040]
    6fe0:	f949ec00 	ldr	x0, [x0, #5080]
    6fe4:	cb010341 	sub	x1, x26, x1
    6fe8:	eb00403f 	cmp	x1, x0, lsl #16
    6fec:	54000342 	b.cs	7054 <f23+0x1a0>  // b.hs, b.nlast
    6ff0:	9115c2e2 	add	x2, x23, #0x570
    6ff4:	d350fc20 	lsr	x0, x1, #16
    6ff8:	8b000800 	add	x0, x0, x0, lsl #2
    6ffc:	f949fc43 	ldr	x3, [x2, #5112]
    7000:	d37df002 	lsl	x2, x0, #3
    7004:	8b020060 	add	x0, x3, x2
    7008:	f9401013 	ldr	x19, [x0, #32]
    700c:	b4000253 	cbz	x19, 7054 <f23+0x1a0>
    7010:	38626862 	ldrb	w2, [x3, x2]
    7014:	7100085f 	cmp	w2, #0x2
    7018:	54000c00 	b.eq	7198 <f23+0x2e4>  // b.none
    701c:	7100045f 	cmp	w2, #0x1
    7020:	540001a1 	b.ne	7054 <f23+0x1a0>  // b.any
    7024:	29430002 	ldp	w2, w0, [x0, #24]
    7028:	92403c21 	and	x1, x1, #0xffff
    702c:	9b027c21 	mul	x1, x1, x2
    7030:	d360fc21 	lsr	x1, x1, #32
    7034:	eb00003f 	cmp	x1, x0
    7038:	540000e2 	b.cs	7054 <f23+0x1a0>  // b.hs, b.nlast
    703c:	8b010273 	add	x19, x19, x1
    7040:	39400260 	ldrb	w0, [x19]
    7044:	7103fc1f 	cmp	w0, #0xff
    7048:	54000da0 	b.eq	71fc <f23+0x348>  // b.none
    704c:	52800020 	mov	w0, #0x1                   	// #1
    7050:	39000260 	strb	w0, [x19]
    7054:	b4000259 	cbz	x25, 709c <f23+0x1e8>
    7058:	8b191359 	add	x25, x26, x25, lsl #4
    705c:	aa1a03f3 	mov	x19, x26
    7060:	aa1603f5 	mov	x21, x22
    7064:	aa1803f4 	mov	x20, x24
    7068:	f9400683 	ldr	x3, [x20, #8]
    706c:	f94006a2 	ldr	x2, [x21, #8]
    7070:	f9400861 	ldr	x1, [x3, #16]
    7074:	f9400840 	ldr	x0, [x2, #16]
    7078:	fd400461 	ldr	d1, [x3, #8]
    707c:	fd400440 	ldr	d0, [x2, #8]
    7080:	97fff870 	bl	5240 <w107>
    7084:	f9000660 	str	x0, [x19, #8]
    7088:	f8010e61 	str	x1, [x19, #16]!
    708c:	f9400a94 	ldr	x20, [x20, #16]
    7090:	f9400ab5 	ldr	x21, [x21, #16]
    7094:	eb13033f 	cmp	x25, x19
    7098:	54fffe81 	b.ne	7068 <f23+0x1b4>  // b.any
    709c:	aa1803e0 	mov	x0, x24
    70a0:	97fffe91 	bl	6ae4 <fwp_drop2>
    70a4:	aa1603e0 	mov	x0, x22
    70a8:	97fffe8f 	bl	6ae4 <fwp_drop2>
    70ac:	9115c2f7 	add	x23, x23, #0x570
    70b0:	aa1a03e0 	mov	x0, x26
    70b4:	97fff8b7 	bl	5390 <w164.constprop.0>
    70b8:	aa0103f3 	mov	x19, x1
    70bc:	aa0003f4 	mov	x20, x0
    70c0:	aa1a03e0 	mov	x0, x26
    70c4:	97fffd37 	bl	65a0 <fwp_drop4>
    70c8:	a900cff4 	stp	x20, x19, [sp, #8]
    70cc:	910023e1 	add	x1, sp, #0x8
    70d0:	52800000 	mov	w0, #0x0                   	// #0
    70d4:	97fff8db 	bl	5440 <fwp_data.part.0.constprop.0>
    70d8:	f949dae1 	ldr	x1, [x23, #5040]
    70dc:	aa0003f3 	mov	x19, x0
    70e0:	f949eee0 	ldr	x0, [x23, #5080]
    70e4:	cb010261 	sub	x1, x19, x1
    70e8:	eb00403f 	cmp	x1, x0, lsl #16
    70ec:	54000322 	b.cs	7150 <f23+0x29c>  // b.hs, b.nlast
    70f0:	d350fc22 	lsr	x2, x1, #16
    70f4:	f949fee3 	ldr	x3, [x23, #5112]
    70f8:	8b020842 	add	x2, x2, x2, lsl #2
    70fc:	d37df042 	lsl	x2, x2, #3
    7100:	8b020060 	add	x0, x3, x2
    7104:	f9401014 	ldr	x20, [x0, #32]
    7108:	b4000254 	cbz	x20, 7150 <f23+0x29c>
    710c:	38626862 	ldrb	w2, [x3, x2]
    7110:	7100085f 	cmp	w2, #0x2
    7114:	540003c0 	b.eq	718c <f23+0x2d8>  // b.none
    7118:	7100045f 	cmp	w2, #0x1
    711c:	540001a1 	b.ne	7150 <f23+0x29c>  // b.any
    7120:	29430002 	ldp	w2, w0, [x0, #24]
    7124:	92403c21 	and	x1, x1, #0xffff
    7128:	9b027c21 	mul	x1, x1, x2
    712c:	d360fc21 	lsr	x1, x1, #32
    7130:	eb00003f 	cmp	x1, x0
    7134:	540000e2 	b.cs	7150 <f23+0x29c>  // b.hs, b.nlast
    7138:	8b010294 	add	x20, x20, x1
    713c:	39400280 	ldrb	w0, [x20]
    7140:	7103fc1f 	cmp	w0, #0xff
    7144:	54000620 	b.eq	7208 <f23+0x354>  // b.none
    7148:	52800020 	mov	w0, #0x1                   	// #1
    714c:	39000280 	strb	w0, [x20]
    7150:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7154:	f947f400 	ldr	x0, [x0, #4072]
    7158:	f9400fe2 	ldr	x2, [sp, #24]
    715c:	f9400001 	ldr	x1, [x0]
    7160:	eb010042 	subs	x2, x2, x1
    7164:	d2800001 	mov	x1, #0x0                   	// #0
    7168:	540006a1 	b.ne	723c <f23+0x388>  // b.any
    716c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7170:	aa1303e0 	mov	x0, x19
    7174:	a94353f3 	ldp	x19, x20, [sp, #48]
    7178:	a9445bf5 	ldp	x21, x22, [sp, #64]
    717c:	a94563f7 	ldp	x23, x24, [sp, #80]
    7180:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7184:	9101c3ff 	add	sp, sp, #0x70
    7188:	d65f03c0 	ret
    718c:	72003c3f 	tst	w1, #0xffff
    7190:	54fffe01 	b.ne	7150 <f23+0x29c>  // b.any
    7194:	17ffffea 	b	713c <f23+0x288>
    7198:	72003c3f 	tst	w1, #0xffff
    719c:	54fff5c1 	b.ne	7054 <f23+0x1a0>  // b.any
    71a0:	17ffffa8 	b	7040 <f23+0x18c>
    71a4:	72003c3f 	tst	w1, #0xffff
    71a8:	54ffee41 	b.ne	6f70 <f23+0xbc>  // b.any
    71ac:	17ffff6b 	b	6f58 <f23+0xa4>
    71b0:	cb0103e1 	neg	x1, x1
    71b4:	eb02003f 	cmp	x1, x2
    71b8:	540002e3 	b.cc	7214 <f23+0x360>  // b.lo, b.ul, b.last
    71bc:	d503201f 	nop
    71c0:	52800041 	mov	w1, #0x2                   	// #2
    71c4:	d2800100 	mov	x0, #0x8                   	// #8
    71c8:	97fff69e 	bl	4c40 <fwp_heap_alloc>
    71cc:	aa0003e1 	mov	x1, x0
    71d0:	9115c2e0 	add	x0, x23, #0x570
    71d4:	aa0103fa 	mov	x26, x1
    71d8:	d2800018 	mov	x24, #0x0                   	// #0
    71dc:	f900003f 	str	xzr, [x1]
    71e0:	f949d801 	ldr	x1, [x0, #5040]
    71e4:	f949ec00 	ldr	x0, [x0, #5080]
    71e8:	cb010341 	sub	x1, x26, x1
    71ec:	eb00403f 	cmp	x1, x0, lsl #16
    71f0:	54fff562 	b.cs	709c <f23+0x1e8>  // b.hs, b.nlast
    71f4:	d2800019 	mov	x25, #0x0                   	// #0
    71f8:	17ffff7e 	b	6ff0 <f23+0x13c>
    71fc:	aa1303e0 	mov	x0, x19
    7200:	97fff4d0 	bl	4540 <fwp_rc_forget_slot>
    7204:	17ffff92 	b	704c <f23+0x198>
    7208:	aa1403e0 	mov	x0, x20
    720c:	97fff4cd 	bl	4540 <fwp_rc_forget_slot>
    7210:	17ffffce 	b	7148 <f23+0x294>
    7214:	f949fc62 	ldr	x2, [x3, #5112]
    7218:	d350fc20 	lsr	x0, x1, #16
    721c:	8b000800 	add	x0, x0, x0, lsl #2
    7220:	8b000c42 	add	x2, x2, x0, lsl #3
    7224:	f9401040 	ldr	x0, [x2, #32]
    7228:	b4fffcc0 	cbz	x0, 71c0 <f23+0x30c>
    722c:	d2800018 	mov	x24, #0x0                   	// #0
    7230:	17ffff3e 	b	6f28 <f23+0x74>
    7234:	97fff47c 	bl	4424 <fwp_rc_wide_dup>
    7238:	17ffff4e 	b	6f70 <f23+0xbc>
    723c:	97ffed6d 	bl	27f0 <__stack_chk_fail@plt>
    7240:	d0000020 	adrp	x0, d000 <__modti3+0x230>
    7244:	91156000 	add	x0, x0, #0x558
    7248:	97fff0ae 	bl	3500 <fwp_trap>
    724c:	d503201f 	nop

0000000000007250 <fwp_owned_entry23>:
    7250:	f9400000 	ldr	x0, [x0]
    7254:	17ffff18 	b	6eb4 <f23>
    7258:	d503201f 	nop
    725c:	d503201f 	nop

0000000000007260 <e23>:
    7260:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7264:	910003fd 	mov	x29, sp
    7268:	f9000bf3 	str	x19, [sp, #16]
    726c:	f9400013 	ldr	x19, [x0]
    7270:	aa1303e0 	mov	x0, x19
    7274:	97fff8bb 	bl	5560 <fwp_rc_share>
    7278:	aa1303e0 	mov	x0, x19
    727c:	97ffff0e 	bl	6eb4 <f23>
    7280:	aa0003f3 	mov	x19, x0
    7284:	97fff8b7 	bl	5560 <fwp_rc_share>
    7288:	aa1303e0 	mov	x0, x19
    728c:	f9400bf3 	ldr	x19, [sp, #16]
    7290:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7294:	d65f03c0 	ret
    7298:	d503201f 	nop
    729c:	d503201f 	nop

00000000000072a0 <f12>:
    72a0:	d10483ff 	sub	sp, sp, #0x120
    72a4:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    72a8:	f947f442 	ldr	x2, [x2, #4072]
    72ac:	a90b7bfd 	stp	x29, x30, [sp, #176]
    72b0:	9102c3fd 	add	x29, sp, #0xb0
    72b4:	a90d5bf5 	stp	x21, x22, [sp, #208]
    72b8:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc70>
    72bc:	9115c2a3 	add	x3, x21, #0x570
    72c0:	a90e63f7 	stp	x23, x24, [sp, #224]
    72c4:	b00000d7 	adrp	x23, 20000 <__data_start>
    72c8:	910102e4 	add	x4, x23, #0x40
    72cc:	f949d861 	ldr	x1, [x3, #5040]
    72d0:	a90c53f3 	stp	x19, x20, [sp, #192]
    72d4:	b00000d4 	adrp	x20, 20000 <__data_start>
    72d8:	f949ec65 	ldr	x5, [x3, #5080]
    72dc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    72e0:	91004294 	add	x20, x20, #0x10
    72e4:	a91073fb 	stp	x27, x28, [sp, #256]
    72e8:	9100c3fa 	add	x26, sp, #0x30
    72ec:	9100a3f9 	add	x25, sp, #0x28
    72f0:	f9417086 	ldr	x6, [x4, #736]
    72f4:	fd008be8 	str	d8, [sp, #272]
    72f8:	f9400047 	ldr	x7, [x2]
    72fc:	f90057e7 	str	x7, [sp, #168]
    7300:	d2800007 	mov	x7, #0x0                   	// #0
    7304:	f0fffff3 	adrp	x19, 6000 <fwp_tape_finish+0xb0>
    7308:	12800007 	mov	w7, #0xffffffff            	// #-1
    730c:	91014262 	add	x2, x19, #0x50
    7310:	cb010281 	sub	x1, x20, x1
    7314:	b9002be7 	str	w7, [sp, #40]
    7318:	a9030be6 	stp	x6, x2, [sp, #48]
    731c:	aa0003f6 	mov	x22, x0
    7320:	f90023f9 	str	x25, [sp, #64]
    7324:	f901709a 	str	x26, [x4, #736]
    7328:	eb05403f 	cmp	x1, x5, lsl #16
    732c:	54000342 	b.cs	7394 <f12+0xf4>  // b.hs, b.nlast
    7330:	d350fc20 	lsr	x0, x1, #16
    7334:	f949fc64 	ldr	x4, [x3, #5112]
    7338:	8b000800 	add	x0, x0, x0, lsl #2
    733c:	d37df002 	lsl	x2, x0, #3
    7340:	8b020083 	add	x3, x4, x2
    7344:	f9401060 	ldr	x0, [x3, #32]
    7348:	b4000260 	cbz	x0, 7394 <f12+0xf4>
    734c:	38626882 	ldrb	w2, [x4, x2]
    7350:	7100085f 	cmp	w2, #0x2
    7354:	54006ca0 	b.eq	80e8 <f12+0xe48>  // b.none
    7358:	7100045f 	cmp	w2, #0x1
    735c:	540001c1 	b.ne	7394 <f12+0xf4>  // b.any
    7360:	29430864 	ldp	w4, w2, [x3, #24]
    7364:	92403c21 	and	x1, x1, #0xffff
    7368:	9b047c21 	mul	x1, x1, x4
    736c:	d360fc21 	lsr	x1, x1, #32
    7370:	eb02003f 	cmp	x1, x2
    7374:	54000102 	b.cs	7394 <f12+0xf4>  // b.hs, b.nlast
    7378:	8b010000 	add	x0, x0, x1
    737c:	39400001 	ldrb	w1, [x0]
    7380:	340000a1 	cbz	w1, 7394 <f12+0xf4>
    7384:	7103f43f 	cmp	w1, #0xfd
    7388:	54007368 	b.hi	81f4 <f12+0xf54>  // b.pmore
    738c:	11000421 	add	w1, w1, #0x1
    7390:	39000001 	strb	w1, [x0]
    7394:	aa1403e0 	mov	x0, x20
    7398:	97fffa4e 	bl	5cd0 <fwp_closure_drop>
    739c:	b4006b16 	cbz	x22, 80fc <f12+0xe5c>
    73a0:	aa1603e0 	mov	x0, x22
    73a4:	d2800001 	mov	x1, #0x0                   	// #0
    73a8:	f9400800 	ldr	x0, [x0, #16]
    73ac:	91000421 	add	x1, x1, #0x1
    73b0:	b5ffffc0 	cbnz	x0, 73a8 <f12+0x108>
    73b4:	aa0103fc 	mov	x28, x1
    73b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    73bc:	eb00003f 	cmp	x1, x0
    73c0:	540074c8 	b.hi	8258 <f12+0xfb8>  // b.pmore
    73c4:	910102f4 	add	x20, x23, #0x40
    73c8:	b9431680 	ldr	w0, [x20, #788]
    73cc:	340067a0 	cbz	w0, 80c0 <f12+0xe20>
    73d0:	910102e0 	add	x0, x23, #0x40
    73d4:	f9402014 	ldr	x20, [x0, #64]
    73d8:	f9405c1b 	ldr	x27, [x0, #184]
    73dc:	eb14037f 	cmp	x27, x20
    73e0:	5400066a 	b.ge	74ac <f12+0x20c>  // b.tcont
    73e4:	f94022e1 	ldr	x1, [x23, #64]
    73e8:	8b1b0760 	add	x0, x27, x27, lsl #1
    73ec:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    73f0:	8b000b60 	add	x0, x27, x0, lsl #2
    73f4:	8b000c20 	add	x0, x1, x0, lsl #3
    73f8:	b9400401 	ldr	w1, [x0, #4]
    73fc:	35000081 	cbnz	w1, 740c <f12+0x16c>
    7400:	b9400001 	ldr	w1, [x0]
    7404:	6b02003f 	cmp	w1, w2
    7408:	54000529 	b.ls	74ac <f12+0x20c>  // b.plast
    740c:	9100077b 	add	x27, x27, #0x1
    7410:	9101a000 	add	x0, x0, #0x68
    7414:	eb14037f 	cmp	x27, x20
    7418:	54ffff01 	b.ne	73f8 <f12+0x158>  // b.any
    741c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7420:	eb00029f 	cmp	x20, x0
    7424:	5400722c 	b.gt	8268 <f12+0xfc8>
    7428:	910102e0 	add	x0, x23, #0x40
    742c:	f94022e3 	ldr	x3, [x23, #64]
    7430:	f9405800 	ldr	x0, [x0, #176]
    7434:	eb14001f 	cmp	x0, x20
    7438:	54000201 	b.ne	7478 <f12+0x1d8>  // b.any
    743c:	b4006c54 	cbz	x20, 81c4 <f12+0xf24>
    7440:	d37ffa98 	lsl	x24, x20, #1
    7444:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7448:	eb00031f 	cmp	x24, x0
    744c:	9a80d318 	csel	x24, x24, x0, le
    7450:	8b180701 	add	x1, x24, x24, lsl #1
    7454:	8b010b01 	add	x1, x24, x1, lsl #2
    7458:	d37df021 	lsl	x1, x1, #3
    745c:	aa0303e0 	mov	x0, x3
    7460:	97ffece0 	bl	27e0 <realloc@plt>
    7464:	aa0003e3 	mov	x3, x0
    7468:	b40060e0 	cbz	x0, 8084 <f12+0xde4>
    746c:	910102e0 	add	x0, x23, #0x40
    7470:	f90022e3 	str	x3, [x23, #64]
    7474:	f9005818 	str	x24, [x0, #176]
    7478:	8b140681 	add	x1, x20, x20, lsl #1
    747c:	910102e0 	add	x0, x23, #0x40
    7480:	4f000400 	movi	v0.4s, #0x0
    7484:	aa1403fb 	mov	x27, x20
    7488:	8b010a81 	add	x1, x20, x1, lsl #2
    748c:	91000694 	add	x20, x20, #0x1
    7490:	f9002014 	str	x20, [x0, #64]
    7494:	8b010c61 	add	x1, x3, x1, lsl #3
    7498:	ad000020 	stp	q0, q0, [x1]
    749c:	ad010020 	stp	q0, q0, [x1, #32]
    74a0:	ad020020 	stp	q0, q0, [x1, #64]
    74a4:	f900303f 	str	xzr, [x1, #96]
    74a8:	14000004 	b	74b8 <f12+0x218>
    74ac:	eb1b029f 	cmp	x20, x27
    74b0:	54fffb60 	b.eq	741c <f12+0x17c>  // b.none
    74b4:	f94022e3 	ldr	x3, [x23, #64]
    74b8:	8b1b0774 	add	x20, x27, x27, lsl #1
    74bc:	d0000020 	adrp	x0, d000 <__modti3+0x230>
    74c0:	910ea000 	add	x0, x0, #0x3a8
    74c4:	8b140b74 	add	x20, x27, x20, lsl #2
    74c8:	f90003e3 	str	x3, [sp]
    74cc:	8b140c74 	add	x20, x3, x20, lsl #3
    74d0:	f900329f 	str	xzr, [x20, #96]
    74d4:	97ffed2b 	bl	2980 <getenv@plt>
    74d8:	f94003e3 	ldr	x3, [sp]
    74dc:	b4000080 	cbz	x0, 74ec <f12+0x24c>
    74e0:	39400001 	ldrb	w1, [x0]
    74e4:	7100c03f 	cmp	w1, #0x30
    74e8:	54002e40 	b.eq	7ab0 <f12+0x810>  // b.none
    74ec:	910102e0 	add	x0, x23, #0x40
    74f0:	f9405001 	ldr	x1, [x0, #160]
    74f4:	b5006121 	cbnz	x1, 8118 <f12+0xe78>
    74f8:	910102e2 	add	x2, x23, #0x40
    74fc:	2f000400 	mvni	v0.2s, #0x0
    7500:	b9400298 	ldr	w24, [x20]
    7504:	52800024 	mov	w4, #0x1                   	// #1
    7508:	91000760 	add	x0, x27, #0x1
    750c:	a900f29c 	stp	x28, x28, [x20, #8]
    7510:	0b040318 	add	w24, w24, w4
    7514:	f9417041 	ldr	x1, [x2, #736]
    7518:	29001298 	stp	w24, w4, [x20]
    751c:	f9002a9f 	str	xzr, [x20, #80]
    7520:	f9005c40 	str	x0, [x2, #184]
    7524:	fd002e80 	str	d0, [x20, #88]
    7528:	b4006921 	cbz	x1, 824c <f12+0xfac>
    752c:	91014273 	add	x19, x19, #0x50
    7530:	14000003 	b	753c <f12+0x29c>
    7534:	f9400021 	ldr	x1, [x1]
    7538:	b40068a1 	cbz	x1, 824c <f12+0xfac>
    753c:	f9400422 	ldr	x2, [x1, #8]
    7540:	eb13005f 	cmp	x2, x19
    7544:	54ffff81 	b.ne	7534 <f12+0x294>  // b.any
    7548:	f9400821 	ldr	x1, [x1, #16]
    754c:	2a1b03e4 	mov	w4, w27
    7550:	b9400022 	ldr	w2, [x1]
    7554:	f9002a81 	str	x1, [x20, #80]
    7558:	b9005e82 	str	w2, [x20, #92]
    755c:	37f80082 	tbnz	w2, #31, 756c <f12+0x2cc>
    7560:	52800d05 	mov	w5, #0x68                  	// #104
    7564:	9b250c42 	smaddl	x2, w2, w5, x3
    7568:	b900585b 	str	w27, [x2, #88]
    756c:	b9000024 	str	w4, [x1]
    7570:	d3707f18 	ubfiz	x24, x24, #16, #32
    7574:	aa000318 	orr	x24, x24, x0
    7578:	d2800002 	mov	x2, #0x0                   	// #0
    757c:	aa1603e0 	mov	x0, x22
    7580:	b4005536 	cbz	x22, 8024 <f12+0xd84>
    7584:	d503201f 	nop
    7588:	f9400800 	ldr	x0, [x0, #16]
    758c:	91000442 	add	x2, x2, #0x1
    7590:	b5ffffc0 	cbnz	x0, 7588 <f12+0x2e8>
    7594:	aa1603e1 	mov	x1, x22
    7598:	f9400821 	ldr	x1, [x1, #16]
    759c:	91000400 	add	x0, x0, #0x1
    75a0:	b5ffffc1 	cbnz	x1, 7598 <f12+0x2f8>
    75a4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    75a8:	eb01001f 	cmp	x0, x1
    75ac:	54006448 	b.hi	8234 <f12+0xf94>  // b.pmore
    75b0:	f100005f 	cmp	x2, #0x0
    75b4:	5400538d 	b.le	8024 <f12+0xd84>
    75b8:	eb00005f 	cmp	x2, x0
    75bc:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    75c0:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    75c4:	eb01027f 	cmp	x19, x1
    75c8:	54006368 	b.hi	8234 <f12+0xf94>  // b.pmore
    75cc:	d37ffa74 	lsl	x20, x19, #1
    75d0:	52800041 	mov	w1, #0x2                   	// #2
    75d4:	91000680 	add	x0, x20, #0x1
    75d8:	d37df000 	lsl	x0, x0, #3
    75dc:	97fff599 	bl	4c40 <fwp_heap_alloc>
    75e0:	aa0003fb 	mov	x27, x0
    75e4:	9115c2a1 	add	x1, x21, #0x570
    75e8:	aa0103e0 	mov	x0, x1
    75ec:	f9000374 	str	x20, [x27]
    75f0:	f949d821 	ldr	x1, [x1, #5040]
    75f4:	f949ec00 	ldr	x0, [x0, #5080]
    75f8:	cb010361 	sub	x1, x27, x1
    75fc:	eb00403f 	cmp	x1, x0, lsl #16
    7600:	540055a2 	b.cs	80b4 <f12+0xe14>  // b.hs, b.nlast
    7604:	9115c2a2 	add	x2, x21, #0x570
    7608:	d350fc20 	lsr	x0, x1, #16
    760c:	8b000800 	add	x0, x0, x0, lsl #2
    7610:	f949fc43 	ldr	x3, [x2, #5112]
    7614:	d37df002 	lsl	x2, x0, #3
    7618:	8b020060 	add	x0, x3, x2
    761c:	f9401014 	ldr	x20, [x0, #32]
    7620:	b4000254 	cbz	x20, 7668 <f12+0x3c8>
    7624:	38626862 	ldrb	w2, [x3, x2]
    7628:	7100085f 	cmp	w2, #0x2
    762c:	54005580 	b.eq	80dc <f12+0xe3c>  // b.none
    7630:	7100045f 	cmp	w2, #0x1
    7634:	540001a1 	b.ne	7668 <f12+0x3c8>  // b.any
    7638:	29430002 	ldp	w2, w0, [x0, #24]
    763c:	92403c21 	and	x1, x1, #0xffff
    7640:	9b027c21 	mul	x1, x1, x2
    7644:	d360fc21 	lsr	x1, x1, #32
    7648:	eb00003f 	cmp	x1, x0
    764c:	540000e2 	b.cs	7668 <f12+0x3c8>  // b.hs, b.nlast
    7650:	8b010294 	add	x20, x20, x1
    7654:	39400280 	ldrb	w0, [x20]
    7658:	7103fc1f 	cmp	w0, #0xff
    765c:	54005c00 	b.eq	81dc <f12+0xf3c>  // b.none
    7660:	52800020 	mov	w0, #0x1                   	// #1
    7664:	39000280 	strb	w0, [x20]
    7668:	b4000233 	cbz	x19, 76ac <f12+0x40c>
    766c:	d3607f04 	lsl	x4, x24, #32
    7670:	aa1603e2 	mov	x2, x22
    7674:	f94006c5 	ldr	x5, [x22, #8]
    7678:	aa0403e3 	mov	x3, x4
    767c:	91002360 	add	x0, x27, #0x8
    7680:	d2800001 	mov	x1, #0x0                   	// #0
    7684:	14000005 	b	7698 <f12+0x3f8>
    7688:	f9400445 	ldr	x5, [x2, #8]
    768c:	ab040023 	adds	x3, x1, x4
    7690:	91004000 	add	x0, x0, #0x10
    7694:	54005f66 	b.vs	8280 <f12+0xfe0>
    7698:	a9000c05 	stp	x5, x3, [x0]
    769c:	91000421 	add	x1, x1, #0x1
    76a0:	f9400842 	ldr	x2, [x2, #16]
    76a4:	eb01027f 	cmp	x19, x1
    76a8:	54ffff08 	b.hi	7688 <f12+0x3e8>  // b.pmore
    76ac:	f9400360 	ldr	x0, [x27]
    76b0:	f100041f 	cmp	x0, #0x1
    76b4:	54005029 	b.ls	80b8 <f12+0xe18>  // b.plast
    76b8:	d341fc00 	lsr	x0, x0, #1
    76bc:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    76c0:	d1000401 	sub	x1, x0, #0x1
    76c4:	eb02003f 	cmp	x1, x2
    76c8:	54005b68 	b.hi	8234 <f12+0xf94>  // b.pmore
    76cc:	d37ff83c 	lsl	x28, x1, #1
    76d0:	b4004f41 	cbz	x1, 80b8 <f12+0xe18>
    76d4:	d1002361 	sub	x1, x27, #0x8
    76d8:	91002373 	add	x19, x27, #0x8
    76dc:	8b001034 	add	x20, x1, x0, lsl #4
    76e0:	f9400660 	ldr	x0, [x19, #8]
    76e4:	f9400e61 	ldr	x1, [x19, #24]
    76e8:	fd400260 	ldr	d0, [x19]
    76ec:	fd400a61 	ldr	d1, [x19, #16]
    76f0:	97fff6d4 	bl	5240 <w107>
    76f4:	a9000660 	stp	x0, x1, [x19]
    76f8:	91004273 	add	x19, x19, #0x10
    76fc:	eb14027f 	cmp	x19, x20
    7700:	54ffff01 	b.ne	76e0 <f12+0x440>  // b.any
    7704:	f900037c 	str	x28, [x27]
    7708:	aa1b03e0 	mov	x0, x27
    770c:	93407f13 	sxtw	x19, w24
    7710:	97fff720 	bl	5390 <w164.constprop.0>
    7714:	aa0103f4 	mov	x20, x1
    7718:	aa1b03e0 	mov	x0, x27
    771c:	97fffba1 	bl	65a0 <fwp_drop4>
    7720:	97fff229 	bl	3fc4 <caf61>
    7724:	9e670008 	fmov	d8, x0
    7728:	aa1303e0 	mov	x0, x19
    772c:	97fff041 	bl	3830 <fwp_tape_of>
    7730:	aa0003e8 	mov	x8, x0
    7734:	f9403001 	ldr	x1, [x0, #96]
    7738:	b5005841 	cbnz	x1, 8240 <f12+0xfa0>
    773c:	97ffedf5 	bl	2f10 <fwp_tape_unlink_scope>
    7740:	b9400002 	ldr	w2, [x0]
    7744:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    7748:	a940801c 	ldp	x28, x0, [x0, #8]
    774c:	b900051f 	str	wzr, [x8, #4]
    7750:	a941910a 	ldp	x10, x4, [x8, #24]
    7754:	a9429905 	ldp	x5, x6, [x8, #40]
    7758:	a9438d07 	ldp	x7, x3, [x8, #56]
    775c:	f940251b 	ldr	x27, [x8, #72]
    7760:	6b01005f 	cmp	w2, w1
    7764:	54000108 	b.hi	7784 <f12+0x4e4>  // b.pmore
    7768:	910102e2 	add	x2, x23, #0x40
    776c:	92403e61 	and	x1, x19, #0xffff
    7770:	d1000421 	sub	x1, x1, #0x1
    7774:	f9405c49 	ldr	x9, [x2, #184]
    7778:	eb09003f 	cmp	x1, x9
    777c:	5400004a 	b.ge	7784 <f12+0x4e4>  // b.tcont
    7780:	f9005c41 	str	x1, [x2, #184]
    7784:	4f000400 	movi	v0.4s, #0x0
    7788:	910102e9 	add	x9, x23, #0x40
    778c:	f9000d1f 	str	xzr, [x8, #24]
    7790:	910123e1 	add	x1, sp, #0x48
    7794:	910183f8 	add	x24, sp, #0x60
    7798:	b0ffffe2 	adrp	x2, 4000 <caf61+0x3c>
    779c:	f941712b 	ldr	x11, [x9, #736]
    77a0:	3c808100 	stur	q0, [x8, #8]
    77a4:	91034042 	add	x2, x2, #0xd0
    77a8:	ad010100 	stp	q0, q0, [x8, #32]
    77ac:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    77b0:	a9048beb 	stp	x11, x2, [sp, #72]
    77b4:	a90593f8 	stp	x24, x4, [sp, #88]
    77b8:	a9069be5 	stp	x5, x6, [sp, #104]
    77bc:	a9078fe7 	stp	x7, x3, [sp, #120]
    77c0:	a908efea 	stp	x10, x27, [sp, #136]
    77c4:	f9017121 	str	x1, [x9, #736]
    77c8:	b7f849f4 	tbnz	x20, #63, 8104 <f12+0xe64>
    77cc:	eb94827f 	cmp	x19, x20, asr #32
    77d0:	54005261 	b.ne	821c <f12+0xf7c>  // b.any
    77d4:	92407e93 	and	x19, x20, #0xffffffff
    77d8:	eb34401f 	cmp	x0, w20, uxtw
    77dc:	540051ad 	b.le	8210 <f12+0xf70>
    77e0:	eb13039f 	cmp	x28, x19
    77e4:	9a93c793 	csinc	x19, x28, x19, gt
    77e8:	eb13037f 	cmp	x27, x19
    77ec:	540043ca 	b.ge	8064 <f12+0xdc4>  // b.tcont
    77f0:	f100037f 	cmp	x27, #0x0
    77f4:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    77f8:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    77fc:	14000004 	b	780c <f12+0x56c>
    7800:	eb01037f 	cmp	x27, x1
    7804:	d37ffb7b 	lsl	x27, x27, #1
    7808:	9a93d37b 	csel	x27, x27, x19, le
    780c:	eb13037f 	cmp	x27, x19
    7810:	54ffff8b 	b.lt	7800 <f12+0x560>  // b.tstop
    7814:	a90017e4 	stp	x4, x5, [sp]
    7818:	a9011fe6 	stp	x6, x7, [sp, #16]
    781c:	b4004b03 	cbz	x3, 817c <f12+0xedc>
    7820:	aa0303e0 	mov	x0, x3
    7824:	d37df361 	lsl	x1, x27, #3
    7828:	97ffebee 	bl	27e0 <realloc@plt>
    782c:	aa0003e3 	mov	x3, x0
    7830:	a94017e4 	ldp	x4, x5, [sp]
    7834:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7838:	b4004163 	cbz	x3, 8064 <f12+0xdc4>
    783c:	f90043e3 	str	x3, [sp, #128]
    7840:	f9004bfb 	str	x27, [sp, #144]
    7844:	b50013d3 	cbnz	x19, 7abc <f12+0x81c>
    7848:	b7f800b4 	tbnz	x20, #63, 785c <f12+0x5bc>
    784c:	92407e94 	and	x20, x20, #0xffffffff
    7850:	fc747860 	ldr	d0, [x3, x20, lsl #3]
    7854:	1e682800 	fadd	d0, d0, d8
    7858:	fc347860 	str	d0, [x3, x20, lsl #3]
    785c:	d1000673 	sub	x19, x19, #0x1
    7860:	d1000788 	sub	x8, x28, #0x1
    7864:	eb13039f 	cmp	x28, x19
    7868:	540003ac 	b.gt	78dc <f12+0x63c>
    786c:	fc737860 	ldr	d0, [x3, x19, lsl #3]
    7870:	1e602008 	fcmp	d0, #0.0
    7874:	540002e0 	b.eq	78d0 <f12+0x630>  // b.none
    7878:	cb1c0be0 	neg	x0, x28, lsl #2
    787c:	cb1c03e2 	neg	x2, x28
    7880:	8b000081 	add	x1, x4, x0
    7884:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    7888:	37f80101 	tbnz	w1, #31, 78a8 <f12+0x608>
    788c:	8b020cc9 	add	x9, x6, x2, lsl #3
    7890:	93407c21 	sxtw	x1, w1
    7894:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    7898:	fc617861 	ldr	d1, [x3, x1, lsl #3]
    789c:	1e620802 	fmul	d2, d0, d2
    78a0:	1e622821 	fadd	d1, d1, d2
    78a4:	fc217861 	str	d1, [x3, x1, lsl #3]
    78a8:	8b0000a0 	add	x0, x5, x0
    78ac:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    78b0:	37f80100 	tbnz	w0, #31, 78d0 <f12+0x630>
    78b4:	8b020ce2 	add	x2, x7, x2, lsl #3
    78b8:	93407c00 	sxtw	x0, w0
    78bc:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    78c0:	fc607861 	ldr	d1, [x3, x0, lsl #3]
    78c4:	1e620800 	fmul	d0, d0, d2
    78c8:	1e602820 	fadd	d0, d1, d0
    78cc:	fc207860 	str	d0, [x3, x0, lsl #3]
    78d0:	d1000673 	sub	x19, x19, #0x1
    78d4:	eb13011f 	cmp	x8, x19
    78d8:	54fffca1 	b.ne	786c <f12+0x5cc>  // b.any
    78dc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    78e0:	eb00039f 	cmp	x28, x0
    78e4:	54004c88 	b.hi	8274 <f12+0xfd4>  // b.pmore
    78e8:	91000780 	add	x0, x28, #0x1
    78ec:	52800041 	mov	w1, #0x2                   	// #2
    78f0:	f90003e3 	str	x3, [sp]
    78f4:	d37df000 	lsl	x0, x0, #3
    78f8:	97fff4d2 	bl	4c40 <fwp_heap_alloc>
    78fc:	aa0003e2 	mov	x2, x0
    7900:	aa0003f3 	mov	x19, x0
    7904:	f94003e3 	ldr	x3, [sp]
    7908:	d2800001 	mov	x1, #0x0                   	// #0
    790c:	f800845c 	str	x28, [x2], #8
    7910:	b40000fc 	cbz	x28, 792c <f12+0x68c>
    7914:	d503201f 	nop
    7918:	f8617860 	ldr	x0, [x3, x1, lsl #3]
    791c:	f8217840 	str	x0, [x2, x1, lsl #3]
    7920:	91000421 	add	x1, x1, #0x1
    7924:	eb01039f 	cmp	x28, x1
    7928:	54ffff81 	b.ne	7918 <f12+0x678>  // b.any
    792c:	910102e1 	add	x1, x23, #0x40
    7930:	aa1803e0 	mov	x0, x24
    7934:	f94027f8 	ldr	x24, [sp, #72]
    7938:	f9017038 	str	x24, [x1, #736]
    793c:	97fff1e5 	bl	40d0 <fwp_tape_buffers_release>
    7940:	9115c2a2 	add	x2, x21, #0x570
    7944:	f949d841 	ldr	x1, [x2, #5040]
    7948:	f949ec40 	ldr	x0, [x2, #5080]
    794c:	cb010261 	sub	x1, x19, x1
    7950:	eb00403f 	cmp	x1, x0, lsl #16
    7954:	54000322 	b.cs	79b8 <f12+0x718>  // b.hs, b.nlast
    7958:	d350fc20 	lsr	x0, x1, #16
    795c:	f949fc43 	ldr	x3, [x2, #5112]
    7960:	8b000800 	add	x0, x0, x0, lsl #2
    7964:	d37df002 	lsl	x2, x0, #3
    7968:	8b020060 	add	x0, x3, x2
    796c:	f9401014 	ldr	x20, [x0, #32]
    7970:	b4000254 	cbz	x20, 79b8 <f12+0x718>
    7974:	38626862 	ldrb	w2, [x3, x2]
    7978:	7100085f 	cmp	w2, #0x2
    797c:	54003c80 	b.eq	810c <f12+0xe6c>  // b.none
    7980:	7100045f 	cmp	w2, #0x1
    7984:	540001a1 	b.ne	79b8 <f12+0x718>  // b.any
    7988:	29430002 	ldp	w2, w0, [x0, #24]
    798c:	92403c21 	and	x1, x1, #0xffff
    7990:	9b027c21 	mul	x1, x1, x2
    7994:	d360fc21 	lsr	x1, x1, #32
    7998:	eb00003f 	cmp	x1, x0
    799c:	540000e2 	b.cs	79b8 <f12+0x718>  // b.hs, b.nlast
    79a0:	8b010294 	add	x20, x20, x1
    79a4:	39400280 	ldrb	w0, [x20]
    79a8:	7103fc1f 	cmp	w0, #0xff
    79ac:	54004120 	b.eq	81d0 <f12+0xf30>  // b.none
    79b0:	52800020 	mov	w0, #0x1                   	// #1
    79b4:	39000280 	strb	w0, [x20]
    79b8:	eb1a031f 	cmp	x24, x26
    79bc:	54004641 	b.ne	8284 <f12+0xfe4>  // b.any
    79c0:	f9401be1 	ldr	x1, [sp, #48]
    79c4:	910102f7 	add	x23, x23, #0x40
    79c8:	aa1903e0 	mov	x0, x25
    79cc:	f90172e1 	str	x1, [x23, #736]
    79d0:	97fff9a0 	bl	6050 <fwp_tape_scope_release>
    79d4:	f9400260 	ldr	x0, [x19]
    79d8:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    79dc:	b7f82ca0 	tbnz	x0, #63, 7f70 <f12+0xcd0>
    79e0:	9115c2a2 	add	x2, x21, #0x570
    79e4:	f949d840 	ldr	x0, [x2, #5040]
    79e8:	f949ec41 	ldr	x1, [x2, #5080]
    79ec:	cb000260 	sub	x0, x19, x0
    79f0:	eb01401f 	cmp	x0, x1, lsl #16
    79f4:	54002be2 	b.cs	7f70 <f12+0xcd0>  // b.hs, b.nlast
    79f8:	d350fc01 	lsr	x1, x0, #16
    79fc:	f949fc44 	ldr	x4, [x2, #5112]
    7a00:	8b010821 	add	x1, x1, x1, lsl #2
    7a04:	d37df021 	lsl	x1, x1, #3
    7a08:	8b010083 	add	x3, x4, x1
    7a0c:	f9401062 	ldr	x2, [x3, #32]
    7a10:	b4002b02 	cbz	x2, 7f70 <f12+0xcd0>
    7a14:	38616881 	ldrb	w1, [x4, x1]
    7a18:	7100083f 	cmp	w1, #0x2
    7a1c:	54002a40 	b.eq	7f64 <f12+0xcc4>  // b.none
    7a20:	7100043f 	cmp	w1, #0x1
    7a24:	54002a61 	b.ne	7f70 <f12+0xcd0>  // b.any
    7a28:	29430464 	ldp	w4, w1, [x3, #24]
    7a2c:	92403c00 	and	x0, x0, #0xffff
    7a30:	9b047c00 	mul	x0, x0, x4
    7a34:	d360fc00 	lsr	x0, x0, #32
    7a38:	eb01001f 	cmp	x0, x1
    7a3c:	540029a2 	b.cs	7f70 <f12+0xcd0>  // b.hs, b.nlast
    7a40:	8b000042 	add	x2, x2, x0
    7a44:	39400040 	ldrb	w0, [x2]
    7a48:	7100041f 	cmp	w0, #0x1
    7a4c:	54002921 	b.ne	7f70 <f12+0xcd0>  // b.any
    7a50:	aa1303fa 	mov	x26, x19
    7a54:	d2800000 	mov	x0, #0x0                   	// #0
    7a58:	f90003f3 	str	x19, [sp]
    7a5c:	f94003e1 	ldr	x1, [sp]
    7a60:	91002023 	add	x3, x1, #0x8
    7a64:	d2800001 	mov	x1, #0x0                   	// #0
    7a68:	b40003f4 	cbz	x20, 7ae4 <f12+0x844>
    7a6c:	d0000022 	adrp	x2, d000 <__modti3+0x230>
    7a70:	91002265 	add	x5, x19, #0x8
    7a74:	fd472041 	ldr	d1, [x2, #3648]
    7a78:	14000009 	b	7a9c <f12+0x7fc>
    7a7c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7a80:	f9400342 	ldr	x2, [x26]
    7a84:	1e600820 	fmul	d0, d1, d0
    7a88:	b7f83d02 	tbnz	x2, #63, 8228 <f12+0xf88>
    7a8c:	91000421 	add	x1, x1, #0x1
    7a90:	fc008460 	str	d0, [x3], #8
    7a94:	eb01029f 	cmp	x20, x1
    7a98:	54000260 	b.eq	7ae4 <f12+0x844>  // b.none
    7a9c:	f9400264 	ldr	x4, [x19]
    7aa0:	aa0503e2 	mov	x2, x5
    7aa4:	b6fffec4 	tbz	x4, #63, 7a7c <f12+0x7dc>
    7aa8:	f9400a62 	ldr	x2, [x19, #16]
    7aac:	17fffff4 	b	7a7c <f12+0x7dc>
    7ab0:	39400400 	ldrb	w0, [x0, #1]
    7ab4:	34ffd220 	cbz	w0, 74f8 <f12+0x258>
    7ab8:	17fffe8d 	b	74ec <f12+0x24c>
    7abc:	aa0303e0 	mov	x0, x3
    7ac0:	d37df262 	lsl	x2, x19, #3
    7ac4:	52800001 	mov	w1, #0x0                   	// #0
    7ac8:	a90017e4 	stp	x4, x5, [sp]
    7acc:	a9011fe6 	stp	x6, x7, [sp, #16]
    7ad0:	97ffeb3c 	bl	27c0 <memset@plt>
    7ad4:	aa0003e3 	mov	x3, x0
    7ad8:	a94017e4 	ldp	x4, x5, [sp]
    7adc:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7ae0:	17ffff5a 	b	7848 <f12+0x5a8>
    7ae4:	97fffaaf 	bl	65a0 <fwp_drop4>
    7ae8:	aa1603e1 	mov	x1, x22
    7aec:	d2800002 	mov	x2, #0x0                   	// #0
    7af0:	b4003556 	cbz	x22, 8198 <f12+0xef8>
    7af4:	d503201f 	nop
    7af8:	f9400821 	ldr	x1, [x1, #16]
    7afc:	91000442 	add	x2, x2, #0x1
    7b00:	b5ffffc1 	cbnz	x1, 7af8 <f12+0x858>
    7b04:	f9400343 	ldr	x3, [x26]
    7b08:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7b0c:	b7f81f63 	tbnz	x3, #63, 7ef8 <f12+0xc58>
    7b10:	9115c2a1 	add	x1, x21, #0x570
    7b14:	f94003e4 	ldr	x4, [sp]
    7b18:	f949d820 	ldr	x0, [x1, #5040]
    7b1c:	f949ec21 	ldr	x1, [x1, #5080]
    7b20:	cb000080 	sub	x0, x4, x0
    7b24:	eb01401f 	cmp	x0, x1, lsl #16
    7b28:	54001e82 	b.cs	7ef8 <f12+0xc58>  // b.hs, b.nlast
    7b2c:	9115c2a4 	add	x4, x21, #0x570
    7b30:	d350fc01 	lsr	x1, x0, #16
    7b34:	8b010821 	add	x1, x1, x1, lsl #2
    7b38:	f949fc86 	ldr	x6, [x4, #5112]
    7b3c:	d37df021 	lsl	x1, x1, #3
    7b40:	8b0100c5 	add	x5, x6, x1
    7b44:	f94010a4 	ldr	x4, [x5, #32]
    7b48:	b4001d64 	cbz	x4, 7ef4 <f12+0xc54>
    7b4c:	386168c1 	ldrb	w1, [x6, x1]
    7b50:	7100083f 	cmp	w1, #0x2
    7b54:	54001cc0 	b.eq	7eec <f12+0xc4c>  // b.none
    7b58:	7100043f 	cmp	w1, #0x1
    7b5c:	54001cc1 	b.ne	7ef4 <f12+0xc54>  // b.any
    7b60:	294304a6 	ldp	w6, w1, [x5, #24]
    7b64:	92403c00 	and	x0, x0, #0xffff
    7b68:	9b067c00 	mul	x0, x0, x6
    7b6c:	d360fc00 	lsr	x0, x0, #32
    7b70:	eb01001f 	cmp	x0, x1
    7b74:	54001c02 	b.cs	7ef4 <f12+0xc54>  // b.hs, b.nlast
    7b78:	8b000084 	add	x4, x4, x0
    7b7c:	39400098 	ldrb	w24, [x4]
    7b80:	7100071f 	cmp	w24, #0x1
    7b84:	54001b81 	b.ne	7ef4 <f12+0xc54>  // b.any
    7b88:	b9000bf8 	str	w24, [sp, #8]
    7b8c:	eb1c005f 	cmp	x2, x28
    7b90:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    7b94:	91002359 	add	x25, x26, #0x8
    7b98:	b400337c 	cbz	x28, 8204 <f12+0xf64>
    7b9c:	f94003e0 	ldr	x0, [sp]
    7ba0:	d37df385 	lsl	x5, x28, #3
    7ba4:	aa1603e2 	mov	x2, x22
    7ba8:	d2800001 	mov	x1, #0x0                   	// #0
    7bac:	91002000 	add	x0, x0, #0x8
    7bb0:	1400000a 	b	7bd8 <f12+0x938>
    7bb4:	fc616881 	ldr	d1, [x4, x1]
    7bb8:	fd400440 	ldr	d0, [x2, #8]
    7bbc:	1e613800 	fsub	d0, d0, d1
    7bc0:	fc216b20 	str	d0, [x25, x1]
    7bc4:	91002021 	add	x1, x1, #0x8
    7bc8:	f9400842 	ldr	x2, [x2, #16]
    7bcc:	eb05003f 	cmp	x1, x5
    7bd0:	540001c0 	b.eq	7c08 <f12+0x968>  // b.none
    7bd4:	f9400343 	ldr	x3, [x26]
    7bd8:	aa0003e4 	mov	x4, x0
    7bdc:	b6fffec3 	tbz	x3, #63, 7bb4 <f12+0x914>
    7be0:	f94003e3 	ldr	x3, [sp]
    7be4:	fd400440 	ldr	d0, [x2, #8]
    7be8:	f9400864 	ldr	x4, [x3, #16]
    7bec:	fc616881 	ldr	d1, [x4, x1]
    7bf0:	1e613800 	fsub	d0, d0, d1
    7bf4:	fc216b20 	str	d0, [x25, x1]
    7bf8:	91002021 	add	x1, x1, #0x8
    7bfc:	f9400842 	ldr	x2, [x2, #16]
    7c00:	eb05003f 	cmp	x1, x5
    7c04:	54fffe81 	b.ne	7bd4 <f12+0x934>  // b.any
    7c08:	b4002fb6 	cbz	x22, 81fc <f12+0xf5c>
    7c0c:	9115c2a0 	add	x0, x21, #0x570
    7c10:	aa1603e2 	mov	x2, x22
    7c14:	d280001a 	mov	x26, #0x0                   	// #0
    7c18:	f949ec06 	ldr	x6, [x0, #5080]
    7c1c:	f949d807 	ldr	x7, [x0, #5040]
    7c20:	f949fc05 	ldr	x5, [x0, #5112]
    7c24:	d370bcc6 	lsl	x6, x6, #16
    7c28:	14000006 	b	7c40 <f12+0x9a0>
    7c2c:	f9400842 	ldr	x2, [x2, #16]
    7c30:	9100075a 	add	x26, x26, #0x1
    7c34:	f100005f 	cmp	x2, #0x0
    7c38:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    7c3c:	54001ee9 	b.ls	8018 <f12+0xd78>  // b.plast
    7c40:	cb070040 	sub	x0, x2, x7
    7c44:	eb06001f 	cmp	x0, x6
    7c48:	540002c2 	b.cs	7ca0 <f12+0xa00>  // b.hs, b.nlast
    7c4c:	d350fc01 	lsr	x1, x0, #16
    7c50:	8b010821 	add	x1, x1, x1, lsl #2
    7c54:	d37df021 	lsl	x1, x1, #3
    7c58:	8b0100a4 	add	x4, x5, x1
    7c5c:	f9401083 	ldr	x3, [x4, #32]
    7c60:	b4000203 	cbz	x3, 7ca0 <f12+0xa00>
    7c64:	386168a1 	ldrb	w1, [x5, x1]
    7c68:	7100083f 	cmp	w1, #0x2
    7c6c:	54000de0 	b.eq	7e28 <f12+0xb88>  // b.none
    7c70:	7100043f 	cmp	w1, #0x1
    7c74:	54000161 	b.ne	7ca0 <f12+0xa00>  // b.any
    7c78:	29430488 	ldp	w8, w1, [x4, #24]
    7c7c:	92403c00 	and	x0, x0, #0xffff
    7c80:	9b087c00 	mul	x0, x0, x8
    7c84:	d360fc00 	lsr	x0, x0, #32
    7c88:	eb01001f 	cmp	x0, x1
    7c8c:	540000a2 	b.cs	7ca0 <f12+0xa00>  // b.hs, b.nlast
    7c90:	8b000063 	add	x3, x3, x0
    7c94:	39400060 	ldrb	w0, [x3]
    7c98:	7100041f 	cmp	w0, #0x1
    7c9c:	54fffc80 	b.eq	7c2c <f12+0x98c>  // b.none
    7ca0:	eb1c035f 	cmp	x26, x28
    7ca4:	54000ca2 	b.cs	7e38 <f12+0xb98>  // b.hs, b.nlast
    7ca8:	d1002337 	sub	x23, x25, #0x8
    7cac:	910263f4 	add	x20, sp, #0x98
    7cb0:	9115c2b8 	add	x24, x21, #0x570
    7cb4:	d2800013 	mov	x19, #0x0                   	// #0
    7cb8:	14000012 	b	7d00 <f12+0xa60>
    7cbc:	7100045f 	cmp	w2, #0x1
    7cc0:	540001a1 	b.ne	7cf4 <f12+0xa54>  // b.any
    7cc4:	29430002 	ldp	w2, w0, [x0, #24]
    7cc8:	92403c21 	and	x1, x1, #0xffff
    7ccc:	9b027c21 	mul	x1, x1, x2
    7cd0:	d360fc21 	lsr	x1, x1, #32
    7cd4:	eb00003f 	cmp	x1, x0
    7cd8:	540000e2 	b.cs	7cf4 <f12+0xa54>  // b.hs, b.nlast
    7cdc:	8b01037b 	add	x27, x27, x1
    7ce0:	39400360 	ldrb	w0, [x27]
    7ce4:	7103fc1f 	cmp	w0, #0xff
    7ce8:	54001b80 	b.eq	8058 <f12+0xdb8>  // b.none
    7cec:	52800020 	mov	w0, #0x1                   	// #1
    7cf0:	39000360 	strb	w0, [x27]
    7cf4:	d100079c 	sub	x28, x28, #0x1
    7cf8:	eb1c035f 	cmp	x26, x28
    7cfc:	54000362 	b.cs	7d68 <f12+0xac8>  // b.hs, b.nlast
    7d00:	f87c7ae2 	ldr	x2, [x23, x28, lsl #3]
    7d04:	aa1403e1 	mov	x1, x20
    7d08:	52800020 	mov	w0, #0x1                   	// #1
    7d0c:	a909cfe2 	stp	x2, x19, [sp, #152]
    7d10:	97fff5cc 	bl	5440 <fwp_data.part.0.constprop.0>
    7d14:	aa0003f3 	mov	x19, x0
    7d18:	f949db01 	ldr	x1, [x24, #5040]
    7d1c:	f949ef00 	ldr	x0, [x24, #5080]
    7d20:	cb010261 	sub	x1, x19, x1
    7d24:	eb00403f 	cmp	x1, x0, lsl #16
    7d28:	54fffe62 	b.cs	7cf4 <f12+0xa54>  // b.hs, b.nlast
    7d2c:	d350fc22 	lsr	x2, x1, #16
    7d30:	f949ff03 	ldr	x3, [x24, #5112]
    7d34:	8b020842 	add	x2, x2, x2, lsl #2
    7d38:	d37df042 	lsl	x2, x2, #3
    7d3c:	8b020060 	add	x0, x3, x2
    7d40:	f940101b 	ldr	x27, [x0, #32]
    7d44:	b4fffd9b 	cbz	x27, 7cf4 <f12+0xa54>
    7d48:	38626862 	ldrb	w2, [x3, x2]
    7d4c:	7100085f 	cmp	w2, #0x2
    7d50:	54fffb61 	b.ne	7cbc <f12+0xa1c>  // b.any
    7d54:	72003c3f 	tst	w1, #0xffff
    7d58:	54fffc40 	b.eq	7ce0 <f12+0xa40>  // b.none
    7d5c:	d100079c 	sub	x28, x28, #0x1
    7d60:	eb1c035f 	cmp	x26, x28
    7d64:	54fffce3 	b.cc	7d00 <f12+0xa60>  // b.lo, b.ul, b.last
    7d68:	b50006ba 	cbnz	x26, 7e3c <f12+0xb9c>
    7d6c:	b9400be0 	ldr	w0, [sp, #8]
    7d70:	d2800038 	mov	x24, #0x1                   	// #1
    7d74:	d280001b 	mov	x27, #0x0                   	// #0
    7d78:	7100001f 	cmp	w0, #0x0
    7d7c:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7d80:	b40007db 	cbz	x27, 7e78 <f12+0xbd8>
    7d84:	d100077b 	sub	x27, x27, #0x1
    7d88:	9115c2b5 	add	x21, x21, #0x570
    7d8c:	d503201f 	nop
    7d90:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    7d94:	aa1403e1 	mov	x1, x20
    7d98:	52800020 	mov	w0, #0x1                   	// #1
    7d9c:	a909cfe2 	stp	x2, x19, [sp, #152]
    7da0:	97fff5a8 	bl	5440 <fwp_data.part.0.constprop.0>
    7da4:	aa0003f3 	mov	x19, x0
    7da8:	f949daa1 	ldr	x1, [x21, #5040]
    7dac:	f949eea0 	ldr	x0, [x21, #5080]
    7db0:	cb010261 	sub	x1, x19, x1
    7db4:	eb00403f 	cmp	x1, x0, lsl #16
    7db8:	54000302 	b.cs	7e18 <f12+0xb78>  // b.hs, b.nlast
    7dbc:	d350fc22 	lsr	x2, x1, #16
    7dc0:	f949fea3 	ldr	x3, [x21, #5112]
    7dc4:	8b020842 	add	x2, x2, x2, lsl #2
    7dc8:	d37df042 	lsl	x2, x2, #3
    7dcc:	8b020060 	add	x0, x3, x2
    7dd0:	f940101a 	ldr	x26, [x0, #32]
    7dd4:	b400023a 	cbz	x26, 7e18 <f12+0xb78>
    7dd8:	38626862 	ldrb	w2, [x3, x2]
    7ddc:	7100085f 	cmp	w2, #0x2
    7de0:	54000800 	b.eq	7ee0 <f12+0xc40>  // b.none
    7de4:	7100045f 	cmp	w2, #0x1
    7de8:	54000181 	b.ne	7e18 <f12+0xb78>  // b.any
    7dec:	29430002 	ldp	w2, w0, [x0, #24]
    7df0:	92403c21 	and	x1, x1, #0xffff
    7df4:	9b027c21 	mul	x1, x1, x2
    7df8:	d360fc21 	lsr	x1, x1, #32
    7dfc:	eb00003f 	cmp	x1, x0
    7e00:	540000c2 	b.cs	7e18 <f12+0xb78>  // b.hs, b.nlast
    7e04:	8b01035a 	add	x26, x26, x1
    7e08:	39400340 	ldrb	w0, [x26]
    7e0c:	7103fc1f 	cmp	w0, #0xff
    7e10:	54000620 	b.eq	7ed4 <f12+0xc34>  // b.none
    7e14:	39000358 	strb	w24, [x26]
    7e18:	d100077b 	sub	x27, x27, #0x1
    7e1c:	b100077f 	cmn	x27, #0x1
    7e20:	54fffb81 	b.ne	7d90 <f12+0xaf0>  // b.any
    7e24:	14000015 	b	7e78 <f12+0xbd8>
    7e28:	72003c1f 	tst	w0, #0xffff
    7e2c:	54fff340 	b.eq	7c94 <f12+0x9f4>  // b.none
    7e30:	eb1c035f 	cmp	x26, x28
    7e34:	54fff3a3 	b.cc	7ca8 <f12+0xa08>  // b.lo, b.ul, b.last
    7e38:	d2800013 	mov	x19, #0x0                   	// #0
    7e3c:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    7e40:	aa1903e1 	mov	x1, x25
    7e44:	aa1603e0 	mov	x0, x22
    7e48:	f8408422 	ldr	x2, [x1], #8
    7e4c:	f9000402 	str	x2, [x0, #8]
    7e50:	aa0003e2 	mov	x2, x0
    7e54:	f9400800 	ldr	x0, [x0, #16]
    7e58:	eb1a003f 	cmp	x1, x26
    7e5c:	54ffff61 	b.ne	7e48 <f12+0xba8>  // b.any
    7e60:	b9400be1 	ldr	w1, [sp, #8]
    7e64:	f9000853 	str	x19, [x2, #16]
    7e68:	aa1603f3 	mov	x19, x22
    7e6c:	aa0003f6 	mov	x22, x0
    7e70:	34000041 	cbz	w1, 7e78 <f12+0xbd8>
    7e74:	d2800019 	mov	x25, #0x0                   	// #0
    7e78:	aa1903e0 	mov	x0, x25
    7e7c:	97fff251 	bl	47c0 <fwp_mem_free>
    7e80:	f94003e0 	ldr	x0, [sp]
    7e84:	97fff9c7 	bl	65a0 <fwp_drop4>
    7e88:	aa1603e0 	mov	x0, x22
    7e8c:	97fff735 	bl	5b60 <fwp_drop0>
    7e90:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7e94:	f947f400 	ldr	x0, [x0, #4072]
    7e98:	f94057e2 	ldr	x2, [sp, #168]
    7e9c:	f9400001 	ldr	x1, [x0]
    7ea0:	eb010042 	subs	x2, x2, x1
    7ea4:	d2800001 	mov	x1, #0x0                   	// #0
    7ea8:	54001de1 	b.ne	8264 <f12+0xfc4>  // b.any
    7eac:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7eb0:	aa1303e0 	mov	x0, x19
    7eb4:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7eb8:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    7ebc:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7ec0:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7ec4:	a95073fb 	ldp	x27, x28, [sp, #256]
    7ec8:	fd408be8 	ldr	d8, [sp, #272]
    7ecc:	910483ff 	add	sp, sp, #0x120
    7ed0:	d65f03c0 	ret
    7ed4:	aa1a03e0 	mov	x0, x26
    7ed8:	97fff19a 	bl	4540 <fwp_rc_forget_slot>
    7edc:	17ffffce 	b	7e14 <f12+0xb74>
    7ee0:	72003c3f 	tst	w1, #0xffff
    7ee4:	54fff9a1 	b.ne	7e18 <f12+0xb78>  // b.any
    7ee8:	17ffffc8 	b	7e08 <f12+0xb68>
    7eec:	72003c1f 	tst	w0, #0xffff
    7ef0:	54ffe460 	b.eq	7b7c <f12+0x8dc>  // b.none
    7ef4:	b4001316 	cbz	x22, 8154 <f12+0xeb4>
    7ef8:	aa1603f3 	mov	x19, x22
    7efc:	d2800014 	mov	x20, #0x0                   	// #0
    7f00:	f9400a73 	ldr	x19, [x19, #16]
    7f04:	aa1403e0 	mov	x0, x20
    7f08:	91000694 	add	x20, x20, #0x1
    7f0c:	b5ffffb3 	cbnz	x19, 7f00 <f12+0xc60>
    7f10:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7f14:	eb01029f 	cmp	x20, x1
    7f18:	540018e8 	b.hi	8234 <f12+0xf94>  // b.pmore
    7f1c:	91000800 	add	x0, x0, #0x2
    7f20:	52800041 	mov	w1, #0x2                   	// #2
    7f24:	d37df000 	lsl	x0, x0, #3
    7f28:	97fff346 	bl	4c40 <fwp_heap_alloc>
    7f2c:	eb1c029f 	cmp	x20, x28
    7f30:	aa0003f9 	mov	x25, x0
    7f34:	9a9c929c 	csel	x28, x20, x28, ls	// ls = plast
    7f38:	aa1603e1 	mov	x1, x22
    7f3c:	d503201f 	nop
    7f40:	f9400420 	ldr	x0, [x1, #8]
    7f44:	f8337b20 	str	x0, [x25, x19, lsl #3]
    7f48:	91000673 	add	x19, x19, #0x1
    7f4c:	f9400821 	ldr	x1, [x1, #16]
    7f50:	b5ffff81 	cbnz	x1, 7f40 <f12+0xca0>
    7f54:	b400109c 	cbz	x28, 8164 <f12+0xec4>
    7f58:	f9400343 	ldr	x3, [x26]
    7f5c:	b9000bff 	str	wzr, [sp, #8]
    7f60:	17ffff0f 	b	7b9c <f12+0x8fc>
    7f64:	72003c1f 	tst	w0, #0xffff
    7f68:	54ffd6e0 	b.eq	7a44 <f12+0x7a4>  // b.none
    7f6c:	d503201f 	nop
    7f70:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7f74:	eb00029f 	cmp	x20, x0
    7f78:	540017e8 	b.hi	8274 <f12+0xfd4>  // b.pmore
    7f7c:	91000680 	add	x0, x20, #0x1
    7f80:	52800021 	mov	w1, #0x1                   	// #1
    7f84:	d37df000 	lsl	x0, x0, #3
    7f88:	97fff32e 	bl	4c40 <fwp_heap_alloc>
    7f8c:	9115c2a2 	add	x2, x21, #0x570
    7f90:	f9000014 	str	x20, [x0]
    7f94:	aa0003fa 	mov	x26, x0
    7f98:	f90003fa 	str	x26, [sp]
    7f9c:	f949d841 	ldr	x1, [x2, #5040]
    7fa0:	f949ec40 	ldr	x0, [x2, #5080]
    7fa4:	cb010341 	sub	x1, x26, x1
    7fa8:	eb00403f 	cmp	x1, x0, lsl #16
    7fac:	54000322 	b.cs	8010 <f12+0xd70>  // b.hs, b.nlast
    7fb0:	d350fc20 	lsr	x0, x1, #16
    7fb4:	f949fc43 	ldr	x3, [x2, #5112]
    7fb8:	8b000800 	add	x0, x0, x0, lsl #2
    7fbc:	d37df002 	lsl	x2, x0, #3
    7fc0:	8b020060 	add	x0, x3, x2
    7fc4:	f9401018 	ldr	x24, [x0, #32]
    7fc8:	b4000258 	cbz	x24, 8010 <f12+0xd70>
    7fcc:	38626862 	ldrb	w2, [x3, x2]
    7fd0:	7100085f 	cmp	w2, #0x2
    7fd4:	54000cc0 	b.eq	816c <f12+0xecc>  // b.none
    7fd8:	7100045f 	cmp	w2, #0x1
    7fdc:	540001a1 	b.ne	8010 <f12+0xd70>  // b.any
    7fe0:	29430002 	ldp	w2, w0, [x0, #24]
    7fe4:	92403c21 	and	x1, x1, #0xffff
    7fe8:	9b027c21 	mul	x1, x1, x2
    7fec:	d360fc21 	lsr	x1, x1, #32
    7ff0:	eb00003f 	cmp	x1, x0
    7ff4:	540000e2 	b.cs	8010 <f12+0xd70>  // b.hs, b.nlast
    7ff8:	8b010318 	add	x24, x24, x1
    7ffc:	39400300 	ldrb	w0, [x24]
    8000:	7103fc1f 	cmp	w0, #0xff
    8004:	54000f20 	b.eq	81e8 <f12+0xf48>  // b.none
    8008:	52800020 	mov	w0, #0x1                   	// #1
    800c:	39000300 	strb	w0, [x24]
    8010:	aa1303e0 	mov	x0, x19
    8014:	17fffe92 	b	7a5c <f12+0x7bc>
    8018:	eb1a039f 	cmp	x28, x26
    801c:	54ffe468 	b.hi	7ca8 <f12+0xa08>  // b.pmore
    8020:	17ffff86 	b	7e38 <f12+0xb98>
    8024:	52800041 	mov	w1, #0x2                   	// #2
    8028:	d2800100 	mov	x0, #0x8                   	// #8
    802c:	97fff305 	bl	4c40 <fwp_heap_alloc>
    8030:	aa0003fb 	mov	x27, x0
    8034:	9115c2a0 	add	x0, x21, #0x570
    8038:	f900037f 	str	xzr, [x27]
    803c:	f949d801 	ldr	x1, [x0, #5040]
    8040:	f949ec00 	ldr	x0, [x0, #5080]
    8044:	cb010361 	sub	x1, x27, x1
    8048:	eb00403f 	cmp	x1, x0, lsl #16
    804c:	54000362 	b.cs	80b8 <f12+0xe18>  // b.hs, b.nlast
    8050:	d2800013 	mov	x19, #0x0                   	// #0
    8054:	17fffd6c 	b	7604 <f12+0x364>
    8058:	aa1b03e0 	mov	x0, x27
    805c:	97fff139 	bl	4540 <fwp_rc_forget_slot>
    8060:	17ffff23 	b	7cec <f12+0xa4c>
    8064:	f100027f 	cmp	x19, #0x0
    8068:	fa401860 	ccmp	x3, #0x0, #0x0, ne	// ne = any
    806c:	54ffbec1 	b.ne	7844 <f12+0x5a4>  // b.any
    8070:	f94027e1 	ldr	x1, [sp, #72]
    8074:	910102f7 	add	x23, x23, #0x40
    8078:	aa1803e0 	mov	x0, x24
    807c:	f90172e1 	str	x1, [x23, #736]
    8080:	97fff014 	bl	40d0 <fwp_tape_buffers_release>
    8084:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    8088:	f947e863 	ldr	x3, [x3, #4048]
    808c:	d2800262 	mov	x2, #0x13                  	// #19
    8090:	d2800021 	mov	x1, #0x1                   	// #1
    8094:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    8098:	9105e000 	add	x0, x0, #0x178
    809c:	f9400063 	ldr	x3, [x3]
    80a0:	97ffea14 	bl	28f0 <fwrite@plt>
    80a4:	d2800000 	mov	x0, #0x0                   	// #0
    80a8:	97ffea1e 	bl	2920 <fflush@plt>
    80ac:	52800cc0 	mov	w0, #0x66                  	// #102
    80b0:	97ffea2c 	bl	2960 <_Exit@plt>
    80b4:	b5ffadd3 	cbnz	x19, 766c <f12+0x3cc>
    80b8:	d280001c 	mov	x28, #0x0                   	// #0
    80bc:	17fffd92 	b	7704 <f12+0x464>
    80c0:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x8c>
    80c4:	913d4000 	add	x0, x0, #0xf50
    80c8:	9400141e 	bl	d140 <atexit>
    80cc:	35fffdc0 	cbnz	w0, 8084 <f12+0xde4>
    80d0:	52800020 	mov	w0, #0x1                   	// #1
    80d4:	b9031680 	str	w0, [x20, #788]
    80d8:	17fffcbe 	b	73d0 <f12+0x130>
    80dc:	72003c3f 	tst	w1, #0xffff
    80e0:	54ffac41 	b.ne	7668 <f12+0x3c8>  // b.any
    80e4:	17fffd5c 	b	7654 <f12+0x3b4>
    80e8:	72003c3f 	tst	w1, #0xffff
    80ec:	54ff9480 	b.eq	737c <f12+0xdc>  // b.none
    80f0:	aa1403e0 	mov	x0, x20
    80f4:	97fff6f7 	bl	5cd0 <fwp_closure_drop>
    80f8:	b5ff9556 	cbnz	x22, 73a0 <f12+0x100>
    80fc:	d280001c 	mov	x28, #0x0                   	// #0
    8100:	17fffcb1 	b	73c4 <f12+0x124>
    8104:	aa1c03f3 	mov	x19, x28
    8108:	17fffdb8 	b	77e8 <f12+0x548>
    810c:	72003c3f 	tst	w1, #0xffff
    8110:	54ffc541 	b.ne	79b8 <f12+0x718>  // b.any
    8114:	17fffe24 	b	79a4 <f12+0x704>
    8118:	3cc68002 	ldur	q2, [x0, #104]
    811c:	9101a001 	add	x1, x0, #0x68
    8120:	3cc78001 	ldur	q1, [x0, #120]
    8124:	f900501f 	str	xzr, [x0, #160]
    8128:	4f000400 	movi	v0.4s, #0x0
    812c:	ad010682 	stp	q2, q1, [x20, #32]
    8130:	a9488002 	ldp	x2, x0, [x0, #136]
    8134:	f9000e80 	str	x0, [x20, #24]
    8138:	f9401820 	ldr	x0, [x1, #48]
    813c:	f9002282 	str	x2, [x20, #64]
    8140:	f9002680 	str	x0, [x20, #72]
    8144:	ad000020 	stp	q0, q0, [x1]
    8148:	3d800820 	str	q0, [x1, #32]
    814c:	f900183f 	str	xzr, [x1, #48]
    8150:	17fffcea 	b	74f8 <f12+0x258>
    8154:	52800041 	mov	w1, #0x2                   	// #2
    8158:	d2800100 	mov	x0, #0x8                   	// #8
    815c:	97fff2b9 	bl	4c40 <fwp_heap_alloc>
    8160:	aa0003f9 	mov	x25, x0
    8164:	d2800013 	mov	x19, #0x0                   	// #0
    8168:	17ffff44 	b	7e78 <f12+0xbd8>
    816c:	72003c3f 	tst	w1, #0xffff
    8170:	54fff460 	b.eq	7ffc <f12+0xd5c>  // b.none
    8174:	aa1303e0 	mov	x0, x19
    8178:	17fffe39 	b	7a5c <f12+0x7bc>
    817c:	aa1b03e0 	mov	x0, x27
    8180:	d2800101 	mov	x1, #0x8                   	// #8
    8184:	97ffe993 	bl	27d0 <calloc@plt>
    8188:	aa0003e3 	mov	x3, x0
    818c:	a94017e4 	ldp	x4, x5, [sp]
    8190:	a9411fe6 	ldp	x6, x7, [sp, #16]
    8194:	17fffda9 	b	7838 <f12+0x598>
    8198:	f9400343 	ldr	x3, [x26]
    819c:	b7fffdc3 	tbnz	x3, #63, 8154 <f12+0xeb4>
    81a0:	9115c2a1 	add	x1, x21, #0x570
    81a4:	f94003e4 	ldr	x4, [sp]
    81a8:	f949d820 	ldr	x0, [x1, #5040]
    81ac:	f949ec21 	ldr	x1, [x1, #5080]
    81b0:	cb000080 	sub	x0, x4, x0
    81b4:	eb01401f 	cmp	x0, x1, lsl #16
    81b8:	54fffce2 	b.cs	8154 <f12+0xeb4>  // b.hs, b.nlast
    81bc:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    81c0:	17fffe5b 	b	7b2c <f12+0x88c>
    81c4:	d2800d01 	mov	x1, #0x68                  	// #104
    81c8:	d2800038 	mov	x24, #0x1                   	// #1
    81cc:	17fffca4 	b	745c <f12+0x1bc>
    81d0:	aa1403e0 	mov	x0, x20
    81d4:	97fff0db 	bl	4540 <fwp_rc_forget_slot>
    81d8:	17fffdf6 	b	79b0 <f12+0x710>
    81dc:	aa1403e0 	mov	x0, x20
    81e0:	97fff0d8 	bl	4540 <fwp_rc_forget_slot>
    81e4:	17fffd1f 	b	7660 <f12+0x3c0>
    81e8:	aa1803e0 	mov	x0, x24
    81ec:	97fff0d5 	bl	4540 <fwp_rc_forget_slot>
    81f0:	17ffff86 	b	8008 <f12+0xd68>
    81f4:	97fff08c 	bl	4424 <fwp_rc_wide_dup>
    81f8:	17fffc67 	b	7394 <f12+0xf4>
    81fc:	d280001a 	mov	x26, #0x0                   	// #0
    8200:	17fffeaa 	b	7ca8 <f12+0xa08>
    8204:	d2800019 	mov	x25, #0x0                   	// #0
    8208:	d2800013 	mov	x19, #0x0                   	// #0
    820c:	17ffff1b 	b	7e78 <f12+0xbd8>
    8210:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    8214:	9113e000 	add	x0, x0, #0x4f8
    8218:	97ffecba 	bl	3500 <fwp_trap>
    821c:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    8220:	91118000 	add	x0, x0, #0x460
    8224:	97ffecb7 	bl	3500 <fwp_trap>
    8228:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    822c:	9117e000 	add	x0, x0, #0x5f8
    8230:	97ffecb4 	bl	3500 <fwp_trap>
    8234:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    8238:	91156000 	add	x0, x0, #0x558
    823c:	97ffecb1 	bl	3500 <fwp_trap>
    8240:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    8244:	9112a000 	add	x0, x0, #0x4a8
    8248:	97ffecae 	bl	3500 <fwp_trap>
    824c:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    8250:	9116e000 	add	x0, x0, #0x5b8
    8254:	97ffecab 	bl	3500 <fwp_trap>
    8258:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    825c:	9115a000 	add	x0, x0, #0x568
    8260:	97ffeca8 	bl	3500 <fwp_trap>
    8264:	97ffe963 	bl	27f0 <__stack_chk_fail@plt>
    8268:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    826c:	91162000 	add	x0, x0, #0x588
    8270:	97ffeca4 	bl	3500 <fwp_trap>
    8274:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    8278:	9117a000 	add	x0, x0, #0x5e8
    827c:	97ffeca1 	bl	3500 <fwp_trap>
    8280:	97ffe9e0 	bl	2a00 <fwp_trap_overflow.constprop.0>
    8284:	97ffe96f 	bl	2840 <abort@plt>
    8288:	d503201f 	nop
    828c:	d503201f 	nop

0000000000008290 <fwp_owned_entry12>:
    8290:	f9400000 	ldr	x0, [x0]
    8294:	17fffc03 	b	72a0 <f12>
    8298:	d503201f 	nop
    829c:	d503201f 	nop

00000000000082a0 <e12>:
    82a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    82a4:	910003fd 	mov	x29, sp
    82a8:	f9000bf3 	str	x19, [sp, #16]
    82ac:	f9400013 	ldr	x19, [x0]
    82b0:	aa1303e0 	mov	x0, x19
    82b4:	97fff4ab 	bl	5560 <fwp_rc_share>
    82b8:	aa1303e0 	mov	x0, x19
    82bc:	97fffbf9 	bl	72a0 <f12>
    82c0:	aa0003f3 	mov	x19, x0
    82c4:	97fff4a7 	bl	5560 <fwp_rc_share>
    82c8:	aa1303e0 	mov	x0, x19
    82cc:	f9400bf3 	ldr	x19, [sp, #16]
    82d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    82d4:	d65f03c0 	ret
    82d8:	d503201f 	nop
    82dc:	d503201f 	nop

00000000000082e0 <fwp_write>:
    82e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    82e4:	910003fd 	mov	x29, sp
    82e8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    82ec:	f947f484 	ldr	x4, [x4, #4072]
    82f0:	a90153f3 	stp	x19, x20, [sp, #16]
    82f4:	d10943ff 	sub	sp, sp, #0x250
    82f8:	b9400045 	ldr	w5, [x2]
    82fc:	aa0003f4 	mov	x20, x0
    8300:	f9400080 	ldr	x0, [x4]
    8304:	f90127e0 	str	x0, [sp, #584]
    8308:	d2800000 	mov	x0, #0x0                   	// #0
    830c:	710064bf 	cmp	w5, #0x19
    8310:	54000408 	b.hi	8390 <fwp_write+0xb0>  // b.pmore
    8314:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    8318:	aa0103f3 	mov	x19, x1
    831c:	91368000 	add	x0, x0, #0xda0
    8320:	f9013bf5 	str	x21, [sp, #624]
    8324:	f9013ff6 	str	x22, [sp, #632]
    8328:	f90153fb 	str	x27, [sp, #672]
    832c:	f90157fc 	str	x28, [sp, #680]
    8330:	aa0203fc 	mov	x28, x2
    8334:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8338:	10000061 	adr	x1, 8344 <fwp_write+0x64>
    833c:	8b20a820 	add	x0, x1, w0, sxth #2
    8340:	d61f0000 	br	x0
    8344:	910123e0 	add	x0, sp, #0x48
    8348:	aa1303e5 	mov	x5, x19
    834c:	b0000024 	adrp	x4, d000 <__modti3+0x230>
    8350:	aa0003f3 	mov	x19, x0
    8354:	91196084 	add	x4, x4, #0x658
    8358:	d2804003 	mov	x3, #0x200                 	// #512
    835c:	aa0303e1 	mov	x1, x3
    8360:	52800042 	mov	w2, #0x2                   	// #2
    8364:	97ffe8ff 	bl	2760 <__snprintf_chk@plt>
    8368:	aa1303e0 	mov	x0, x19
    836c:	97ffe8c5 	bl	2680 <strlen@plt>
    8370:	aa1303e1 	mov	x1, x19
    8374:	aa0003e2 	mov	x2, x0
    8378:	aa1403e0 	mov	x0, x20
    837c:	97ffec05 	bl	3390 <buf_put>
    8380:	f9413bf5 	ldr	x21, [sp, #624]
    8384:	f9413ff6 	ldr	x22, [sp, #632]
    8388:	f94153fb 	ldr	x27, [sp, #672]
    838c:	f94157fc 	ldr	x28, [sp, #680]
    8390:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8394:	f947f400 	ldr	x0, [x0, #4072]
    8398:	f94127e2 	ldr	x2, [sp, #584]
    839c:	f9400001 	ldr	x1, [x0]
    83a0:	eb010042 	subs	x2, x2, x1
    83a4:	d2800001 	mov	x1, #0x0                   	// #0
    83a8:	540077c1 	b.ne	92a0 <fwp_write+0xfc0>  // b.any
    83ac:	910943ff 	add	sp, sp, #0x250
    83b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    83b4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    83b8:	d65f03c0 	ret
    83bc:	910123e0 	add	x0, sp, #0x48
    83c0:	aa1303e5 	mov	x5, x19
    83c4:	b0000024 	adrp	x4, d000 <__modti3+0x230>
    83c8:	aa0003f3 	mov	x19, x0
    83cc:	91194084 	add	x4, x4, #0x650
    83d0:	d2804003 	mov	x3, #0x200                 	// #512
    83d4:	17ffffe2 	b	835c <fwp_write+0x7c>
    83d8:	71004cbf 	cmp	w5, #0x13
    83dc:	b0000020 	adrp	x0, d000 <__modti3+0x230>
    83e0:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    83e4:	91190000 	add	x0, x0, #0x640
    83e8:	91192021 	add	x1, x1, #0x648
    83ec:	d2800082 	mov	x2, #0x4                   	// #4
    83f0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    83f4:	aa1403e0 	mov	x0, x20
    83f8:	f90143f7 	str	x23, [sp, #640]
    83fc:	d2800016 	mov	x22, #0x0                   	// #0
    8400:	f90147f8 	str	x24, [sp, #648]
    8404:	97ffebe3 	bl	3390 <buf_put>
    8408:	f9400260 	ldr	x0, [x19]
    840c:	b0000037 	adrp	x23, d000 <__modti3+0x230>
    8410:	d2800015 	mov	x21, #0x0                   	// #0
    8414:	911b22f7 	add	x23, x23, #0x6c8
    8418:	b40047a0 	cbz	x0, 8d0c <fwp_write+0xa2c>
    841c:	b9400380 	ldr	w0, [x28]
    8420:	52800003 	mov	w3, #0x0                   	// #0
    8424:	f9401f82 	ldr	x2, [x28, #56]
    8428:	71004c1f 	cmp	w0, #0x13
    842c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8430:	aa1403e0 	mov	x0, x20
    8434:	8b010e61 	add	x1, x19, x1, lsl #3
    8438:	f9400421 	ldr	x1, [x1, #8]
    843c:	97ffffa9 	bl	82e0 <fwp_write>
    8440:	b9400380 	ldr	w0, [x28]
    8444:	7100481f 	cmp	w0, #0x12
    8448:	54004b40 	b.eq	8db0 <fwp_write+0xad0>  // b.none
    844c:	f9400260 	ldr	x0, [x19]
    8450:	910006b5 	add	x21, x21, #0x1
    8454:	91000ad6 	add	x22, x22, #0x2
    8458:	eb15001f 	cmp	x0, x21
    845c:	54004589 	b.ls	8d0c <fwp_write+0xa2c>  // b.plast
    8460:	aa1703e1 	mov	x1, x23
    8464:	aa1403e0 	mov	x0, x20
    8468:	d2800042 	mov	x2, #0x2                   	// #2
    846c:	97ffebc9 	bl	3390 <buf_put>
    8470:	17ffffeb 	b	841c <fwp_write+0x13c>
    8474:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8478:	911a0021 	add	x1, x1, #0x680
    847c:	d28000c2 	mov	x2, #0x6                   	// #6
    8480:	aa1403e0 	mov	x0, x20
    8484:	91004273 	add	x19, x19, #0x10
    8488:	97ffebc2 	bl	3390 <buf_put>
    848c:	aa1303e0 	mov	x0, x19
    8490:	97ffe87c 	bl	2680 <strlen@plt>
    8494:	aa1303e1 	mov	x1, x19
    8498:	aa0003e2 	mov	x2, x0
    849c:	aa1403e0 	mov	x0, x20
    84a0:	97ffebbc 	bl	3390 <buf_put>
    84a4:	528007c3 	mov	w3, #0x3e                  	// #62
    84a8:	aa1403e0 	mov	x0, x20
    84ac:	91001fe1 	add	x1, sp, #0x7
    84b0:	d2800022 	mov	x2, #0x1                   	// #1
    84b4:	39001fe3 	strb	w3, [sp, #7]
    84b8:	17ffffb1 	b	837c <fwp_write+0x9c>
    84bc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    84c0:	f947f400 	ldr	x0, [x0, #4072]
    84c4:	f94127e2 	ldr	x2, [sp, #584]
    84c8:	f9400001 	ldr	x1, [x0]
    84cc:	eb010042 	subs	x2, x2, x1
    84d0:	d2800001 	mov	x1, #0x0                   	// #0
    84d4:	540034e1 	b.ne	8b70 <fwp_write+0x890>  // b.any
    84d8:	f9413bf5 	ldr	x21, [sp, #624]
    84dc:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    84e0:	f9413ff6 	ldr	x22, [sp, #632]
    84e4:	aa1403e0 	mov	x0, x20
    84e8:	91198021 	add	x1, x1, #0x660
    84ec:	d2800142 	mov	x2, #0xa                   	// #10
    84f0:	f94153fb 	ldr	x27, [sp, #672]
    84f4:	f94157fc 	ldr	x28, [sp, #680]
    84f8:	910943ff 	add	sp, sp, #0x250
    84fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    8500:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8504:	17ffeba3 	b	3390 <buf_put>
    8508:	f9400456 	ldr	x22, [x2, #8]
    850c:	f90143f7 	str	x23, [sp, #640]
    8510:	f90147f8 	str	x24, [sp, #648]
    8514:	b4005b16 	cbz	x22, 9074 <fwp_write+0xd94>
    8518:	aa1603e0 	mov	x0, x22
    851c:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8520:	911b8021 	add	x1, x1, #0x6e0
    8524:	97ffe8d3 	bl	2870 <strcmp@plt>
    8528:	2a0003f5 	mov	w21, w0
    852c:	34005fe0 	cbz	w0, 9128 <fwp_write+0xe48>
    8530:	aa1603e0 	mov	x0, x22
    8534:	97ffe853 	bl	2680 <strlen@plt>
    8538:	aa1603e1 	mov	x1, x22
    853c:	aa0003e2 	mov	x2, x0
    8540:	aa1403e0 	mov	x0, x20
    8544:	97ffeb93 	bl	3390 <buf_put>
    8548:	52800403 	mov	w3, #0x20                  	// #32
    854c:	91001ff5 	add	x21, sp, #0x7
    8550:	aa1503e1 	mov	x1, x21
    8554:	aa1403e0 	mov	x0, x20
    8558:	d2800022 	mov	x2, #0x1                   	// #1
    855c:	39001fe3 	strb	w3, [sp, #7]
    8560:	97ffeb8c 	bl	3390 <buf_put>
    8564:	52800f63 	mov	w3, #0x7b                  	// #123
    8568:	aa1403e0 	mov	x0, x20
    856c:	aa1503e1 	mov	x1, x21
    8570:	d2800022 	mov	x2, #0x1                   	// #1
    8574:	39001fe3 	strb	w3, [sp, #7]
    8578:	97ffeb86 	bl	3390 <buf_put>
    857c:	b9401380 	ldr	w0, [x28, #16]
    8580:	52800018 	mov	w24, #0x0                   	// #0
    8584:	7100001f 	cmp	w0, #0x0
    8588:	54003aad 	b.le	8cdc <fwp_write+0x9fc>
    858c:	f9014bf9 	str	x25, [sp, #656]
    8590:	b0000039 	adrp	x25, d000 <__modti3+0x230>
    8594:	911c2339 	add	x25, x25, #0x708
    8598:	f9014ffa 	str	x26, [sp, #664]
    859c:	b000003a 	adrp	x26, d000 <__modti3+0x230>
    85a0:	911b235a 	add	x26, x26, #0x6c8
    85a4:	91002276 	add	x22, x19, #0x8
    85a8:	d2800013 	mov	x19, #0x0                   	// #0
    85ac:	b5003e93 	cbnz	x19, 8d7c <fwp_write+0xa9c>
    85b0:	d37df277 	lsl	x23, x19, #3
    85b4:	34003cb8 	cbz	w24, 8d48 <fwp_write+0xa68>
    85b8:	f9401382 	ldr	x2, [x28, #32]
    85bc:	aa1403e0 	mov	x0, x20
    85c0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    85c4:	52800003 	mov	w3, #0x0                   	// #0
    85c8:	f8776842 	ldr	x2, [x2, x23]
    85cc:	91000673 	add	x19, x19, #0x1
    85d0:	97ffff44 	bl	82e0 <fwp_write>
    85d4:	b9401380 	ldr	w0, [x28, #16]
    85d8:	6b13001f 	cmp	w0, w19
    85dc:	54fffe8c 	b.gt	85ac <fwp_write+0x2cc>
    85e0:	f9414bf9 	ldr	x25, [sp, #656]
    85e4:	f9414ffa 	ldr	x26, [sp, #664]
    85e8:	340037b8 	cbz	w24, 8cdc <fwp_write+0x9fc>
    85ec:	52800523 	mov	w3, #0x29                  	// #41
    85f0:	aa1503e1 	mov	x1, x21
    85f4:	aa1403e0 	mov	x0, x20
    85f8:	d2800022 	mov	x2, #0x1                   	// #1
    85fc:	39001fe3 	strb	w3, [sp, #7]
    8600:	97ffeb64 	bl	3390 <buf_put>
    8604:	f9413bf5 	ldr	x21, [sp, #624]
    8608:	f9413ff6 	ldr	x22, [sp, #632]
    860c:	f94143f7 	ldr	x23, [sp, #640]
    8610:	f94147f8 	ldr	x24, [sp, #648]
    8614:	f94153fb 	ldr	x27, [sp, #672]
    8618:	f94157fc 	ldr	x28, [sp, #680]
    861c:	17ffff5d 	b	8390 <fwp_write+0xb0>
    8620:	b9404855 	ldr	w21, [x2, #72]
    8624:	aa1403e0 	mov	x0, x20
    8628:	93407eb6 	sxtw	x22, w21
    862c:	91000ac1 	add	x1, x22, #0x2
    8630:	97ffeb25 	bl	32c4 <buf_grow>
    8634:	a9400281 	ldp	x1, x0, [x20]
    8638:	528e8603 	mov	w3, #0x7430                	// #29744
    863c:	78206823 	strh	w3, [x1, x0]
    8640:	8b000022 	add	x2, x1, x0
    8644:	710002bf 	cmp	w21, #0x0
    8648:	540036cd 	b.le	8d20 <fwp_write+0xa40>
    864c:	110006a3 	add	w3, w21, #0x1
    8650:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8654:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8658:	91000449 	add	x9, x2, #0x1
    865c:	8b23c043 	add	x3, x2, w3, sxtw
    8660:	f28aaac6 	movk	x6, #0x5556
    8664:	f2955568 	movk	x8, #0xaaab
    8668:	1400000d 	b	869c <fwp_write+0x3bc>
    866c:	d2800021 	mov	x1, #0x1                   	// #1
    8670:	528005a5 	mov	w5, #0x2d                  	// #45
    8674:	f100001f 	cmp	x0, #0x0
    8678:	9b467e60 	smulh	x0, x19, x6
    867c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8680:	381ff465 	strb	w5, [x3], #-1
    8684:	cb040000 	sub	x0, x0, x4
    8688:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    868c:	cb020000 	sub	x0, x0, x2
    8690:	8b010013 	add	x19, x0, x1
    8694:	eb03013f 	cmp	x9, x3
    8698:	54003440 	b.eq	8d20 <fwp_write+0xa40>  // b.none
    869c:	9b467e60 	smulh	x0, x19, x6
    86a0:	937ffe64 	asr	x4, x19, #63
    86a4:	52800605 	mov	w5, #0x30                  	// #48
    86a8:	cb040000 	sub	x0, x0, x4
    86ac:	8b000400 	add	x0, x0, x0, lsl #1
    86b0:	cb000260 	sub	x0, x19, x0
    86b4:	91000c01 	add	x1, x0, #0x3
    86b8:	9bc87c22 	umulh	x2, x1, x8
    86bc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    86c0:	8b4204e2 	add	x2, x7, x2, lsr #1
    86c4:	eb020021 	subs	x1, x1, x2
    86c8:	54fffd60 	b.eq	8674 <fwp_write+0x394>  // b.none
    86cc:	f100043f 	cmp	x1, #0x1
    86d0:	54fffce1 	b.ne	866c <fwp_write+0x38c>  // b.any
    86d4:	d2800001 	mov	x1, #0x0                   	// #0
    86d8:	52800565 	mov	w5, #0x2b                  	// #43
    86dc:	17ffffe6 	b	8674 <fwp_write+0x394>
    86e0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    86e4:	f947f400 	ldr	x0, [x0, #4072]
    86e8:	f94127e2 	ldr	x2, [sp, #584]
    86ec:	f9400001 	ldr	x1, [x0]
    86f0:	eb010042 	subs	x2, x2, x1
    86f4:	d2800001 	mov	x1, #0x0                   	// #0
    86f8:	540023c1 	b.ne	8b70 <fwp_write+0x890>  // b.any
    86fc:	f9413bf5 	ldr	x21, [sp, #624]
    8700:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8704:	f9413ff6 	ldr	x22, [sp, #632]
    8708:	aa1403e0 	mov	x0, x20
    870c:	9119c021 	add	x1, x1, #0x670
    8710:	d2800102 	mov	x2, #0x8                   	// #8
    8714:	17ffff77 	b	84f0 <fwp_write+0x210>
    8718:	aa1403e0 	mov	x0, x20
    871c:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8720:	d28000c2 	mov	x2, #0x6                   	// #6
    8724:	911b4021 	add	x1, x1, #0x6d0
    8728:	97ffeb1a 	bl	3390 <buf_put>
    872c:	d2800015 	mov	x21, #0x0                   	// #0
    8730:	f9400263 	ldr	x3, [x19]
    8734:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8738:	54002c60 	b.eq	8cc4 <fwp_write+0x9e4>  // b.none
    873c:	f9401f82 	ldr	x2, [x28, #56]
    8740:	f90143f7 	str	x23, [sp, #640]
    8744:	f90147f8 	str	x24, [sp, #648]
    8748:	d2800857 	mov	x23, #0x42                  	// #66
    874c:	f9014bf9 	str	x25, [sp, #656]
    8750:	b0000036 	adrp	x22, d000 <__modti3+0x230>
    8754:	f9014ffa 	str	x26, [sp, #664]
    8758:	911b22d6 	add	x22, x22, #0x6c8
    875c:	d2800038 	mov	x24, #0x1                   	// #1
    8760:	f2a18017 	movk	x23, #0xc00, lsl #16
    8764:	d2809099 	mov	x25, #0x484                 	// #1156
    8768:	b40004a2 	cbz	x2, 87fc <fwp_write+0x51c>
    876c:	b9400040 	ldr	w0, [x2]
    8770:	7100701f 	cmp	w0, #0x1c
    8774:	540042c0 	b.eq	8fcc <fwp_write+0xcec>  // b.none
    8778:	71006c1f 	cmp	w0, #0x1b
    877c:	54000408 	b.hi	87fc <fwp_write+0x51c>  // b.pmore
    8780:	9ac02301 	lsl	x1, x24, x0
    8784:	ea17003f 	tst	x1, x23
    8788:	540036a1 	b.ne	8e5c <fwp_write+0xb7c>  // b.any
    878c:	ea19003f 	tst	x1, x25
    8790:	54003521 	b.ne	8e34 <fwp_write+0xb54>  // b.any
    8794:	d2800424 	mov	x4, #0x21                  	// #33
    8798:	ea04003f 	tst	x1, x4
    879c:	54000300 	b.eq	87fc <fwp_write+0x51c>  // b.none
    87a0:	b7f849c3 	tbnz	x3, #63, 90d8 <fwp_write+0xdf8>
    87a4:	91002261 	add	x1, x19, #0x8
    87a8:	8b150021 	add	x1, x1, x21
    87ac:	39400021 	ldrb	w1, [x1]
    87b0:	7100001f 	cmp	w0, #0x0
    87b4:	93401c23 	sxtb	x3, w1
    87b8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    87bc:	d503201f 	nop
    87c0:	aa1403e0 	mov	x0, x20
    87c4:	52800003 	mov	w3, #0x0                   	// #0
    87c8:	97fffec6 	bl	82e0 <fwp_write>
    87cc:	910006b5 	add	x21, x21, #0x1
    87d0:	f9400260 	ldr	x0, [x19]
    87d4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    87d8:	eb0002bf 	cmp	x21, x0
    87dc:	540026c2 	b.cs	8cb4 <fwp_write+0x9d4>  // b.hs, b.nlast
    87e0:	d2800042 	mov	x2, #0x2                   	// #2
    87e4:	aa1603e1 	mov	x1, x22
    87e8:	aa1403e0 	mov	x0, x20
    87ec:	97ffeae9 	bl	3390 <buf_put>
    87f0:	f9401f82 	ldr	x2, [x28, #56]
    87f4:	f9400263 	ldr	x3, [x19]
    87f8:	b5fffba2 	cbnz	x2, 876c <fwp_write+0x48c>
    87fc:	d37df2a0 	lsl	x0, x21, #3
    8800:	b7f83f03 	tbnz	x3, #63, 8fe0 <fwp_write+0xd00>
    8804:	91002261 	add	x1, x19, #0x8
    8808:	8b000020 	add	x0, x1, x0
    880c:	f9400001 	ldr	x1, [x0]
    8810:	17ffffec 	b	87c0 <fwp_write+0x4e0>
    8814:	a9400e62 	ldp	x2, x3, [x19]
    8818:	b7f83ca3 	tbnz	x3, #63, 8fac <fwp_write+0xccc>
    881c:	910123f5 	add	x21, sp, #0x48
    8820:	aa1503e0 	mov	x0, x21
    8824:	97ffe95f 	bl	2da0 <fwp_fmt_u128>
    8828:	aa1503e0 	mov	x0, x21
    882c:	97ffe795 	bl	2680 <strlen@plt>
    8830:	aa1503e1 	mov	x1, x21
    8834:	aa0003e2 	mov	x2, x0
    8838:	17fffed0 	b	8378 <fwp_write+0x98>
    883c:	fd015be8 	str	d8, [sp, #688]
    8840:	1e270268 	fmov	s8, w19
    8844:	fd015fe9 	str	d9, [sp, #696]
    8848:	1e282100 	fcmp	s8, s8
    884c:	54004d26 	b.vs	91f0 <fwp_write+0xf10>
    8850:	1e20c101 	fabs	s1, s8
    8854:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8858:	1e270000 	fmov	s0, w0
    885c:	1e202020 	fcmp	s1, s0
    8860:	54002c0d 	b.le	8de0 <fwp_write+0xb00>
    8864:	1e202118 	fcmpe	s8, #0.0
    8868:	b0000022 	adrp	x2, d000 <__modti3+0x230>
    886c:	91064042 	add	x2, x2, #0x190
    8870:	910123f5 	add	x21, sp, #0x48
    8874:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8878:	91188021 	add	x1, x1, #0x620
    887c:	aa1503e0 	mov	x0, x21
    8880:	9a81c041 	csel	x1, x2, x1, gt
    8884:	97ffe82b 	bl	2930 <strcpy@plt>
    8888:	aa1503e0 	mov	x0, x21
    888c:	97ffe77d 	bl	2680 <strlen@plt>
    8890:	aa1503e1 	mov	x1, x21
    8894:	aa0003e2 	mov	x2, x0
    8898:	aa1403e0 	mov	x0, x20
    889c:	97ffeabd 	bl	3390 <buf_put>
    88a0:	f9413bf5 	ldr	x21, [sp, #624]
    88a4:	f9413ff6 	ldr	x22, [sp, #632]
    88a8:	f94153fb 	ldr	x27, [sp, #672]
    88ac:	f94157fc 	ldr	x28, [sp, #680]
    88b0:	fd415be8 	ldr	d8, [sp, #688]
    88b4:	fd415fe9 	ldr	d9, [sp, #696]
    88b8:	17fffeb6 	b	8390 <fwp_write+0xb0>
    88bc:	f9400276 	ldr	x22, [x19]
    88c0:	34002e03 	cbz	w3, 8e80 <fwp_write+0xba0>
    88c4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    88c8:	f947f400 	ldr	x0, [x0, #4072]
    88cc:	f94127e2 	ldr	x2, [sp, #584]
    88d0:	f9400001 	ldr	x1, [x0]
    88d4:	eb010042 	subs	x2, x2, x1
    88d8:	d2800001 	mov	x1, #0x0                   	// #0
    88dc:	540014a1 	b.ne	8b70 <fwp_write+0x890>  // b.any
    88e0:	aa1603e2 	mov	x2, x22
    88e4:	91002261 	add	x1, x19, #0x8
    88e8:	f9413bf5 	ldr	x21, [sp, #624]
    88ec:	aa1403e0 	mov	x0, x20
    88f0:	f9413ff6 	ldr	x22, [sp, #632]
    88f4:	17fffeff 	b	84f0 <fwp_write+0x210>
    88f8:	fd015be8 	str	d8, [sp, #688]
    88fc:	9e670268 	fmov	d8, x19
    8900:	fd015fe9 	str	d9, [sp, #696]
    8904:	1e682100 	fcmp	d8, d8
    8908:	54004746 	b.vs	91f0 <fwp_write+0xf10>
    890c:	1e60c101 	fabs	d1, d8
    8910:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8914:	9e670000 	fmov	d0, x0
    8918:	910123f5 	add	x21, sp, #0x48
    891c:	52800033 	mov	w19, #0x1                   	// #1
    8920:	1e602020 	fcmp	d1, d0
    8924:	540001ad 	b.le	8958 <fwp_write+0x678>
    8928:	1e602118 	fcmpe	d8, #0.0
    892c:	b0000022 	adrp	x2, d000 <__modti3+0x230>
    8930:	91064042 	add	x2, x2, #0x190
    8934:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8938:	91188021 	add	x1, x1, #0x620
    893c:	aa1503e0 	mov	x0, x21
    8940:	9a81c041 	csel	x1, x2, x1, gt
    8944:	97ffe7fb 	bl	2930 <strcpy@plt>
    8948:	17ffffd0 	b	8888 <fwp_write+0x5a8>
    894c:	11000673 	add	w19, w19, #0x1
    8950:	71004a7f 	cmp	w19, #0x12
    8954:	54003860 	b.eq	9060 <fwp_write+0xd80>  // b.none
    8958:	1e604100 	fmov	d0, d8
    895c:	2a1303e1 	mov	w1, w19
    8960:	aa1503e0 	mov	x0, x21
    8964:	97ffebcc 	bl	3894 <fwp_format_g.constprop.0>
    8968:	aa1503e0 	mov	x0, x21
    896c:	d2800001 	mov	x1, #0x0                   	// #0
    8970:	97ffe758 	bl	26d0 <strtod@plt>
    8974:	1e602100 	fcmp	d8, d0
    8978:	54fffea1 	b.ne	894c <fwp_write+0x66c>  // b.any
    897c:	aa1503e0 	mov	x0, x21
    8980:	97ffeabd 	bl	3474 <fwp_finish_float>
    8984:	17ffffc1 	b	8888 <fwp_write+0x5a8>
    8988:	a9400e62 	ldp	x2, x3, [x19]
    898c:	910123f3 	add	x19, sp, #0x48
    8990:	aa1303e0 	mov	x0, x19
    8994:	97ffe903 	bl	2da0 <fwp_fmt_u128>
    8998:	17fffe74 	b	8368 <fwp_write+0x88>
    899c:	f90143f7 	str	x23, [sp, #640]
    89a0:	f90147f8 	str	x24, [sp, #648]
    89a4:	2a1303f8 	mov	w24, w19
    89a8:	f9014bf9 	str	x25, [sp, #656]
    89ac:	f9014ffa 	str	x26, [sp, #664]
    89b0:	f13ffe7f 	cmp	x19, #0xfff
    89b4:	54000049 	b.ls	89bc <fwp_write+0x6dc>  // b.plast
    89b8:	b9400278 	ldr	w24, [x19]
    89bc:	f9400f80 	ldr	x0, [x28, #24]
    89c0:	2a1803f5 	mov	w21, w24
    89c4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    89c8:	d37ef6b9 	lsl	x25, x21, #2
    89cc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    89d0:	aa1603e0 	mov	x0, x22
    89d4:	97ffe72b 	bl	2680 <strlen@plt>
    89d8:	aa1603e1 	mov	x1, x22
    89dc:	aa0003e2 	mov	x2, x0
    89e0:	aa1403e0 	mov	x0, x20
    89e4:	97ffea6b 	bl	3390 <buf_put>
    89e8:	f9401780 	ldr	x0, [x28, #40]
    89ec:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    89f0:	7100001f 	cmp	w0, #0x0
    89f4:	5400068d 	b.le	8ac4 <fwp_write+0x7e4>
    89f8:	91002276 	add	x22, x19, #0x8
    89fc:	91001ff5 	add	x21, sp, #0x7
    8a00:	d280001b 	mov	x27, #0x0                   	// #0
    8a04:	5280041a 	mov	w26, #0x20                  	// #32
    8a08:	f9401b80 	ldr	x0, [x28, #48]
    8a0c:	aa1503e1 	mov	x1, x21
    8a10:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8a14:	d2800022 	mov	x2, #0x1                   	// #1
    8a18:	f8786803 	ldr	x3, [x0, x24]
    8a1c:	aa1403e0 	mov	x0, x20
    8a20:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8a24:	39001ffa 	strb	w26, [sp, #7]
    8a28:	97ffea5a 	bl	3390 <buf_put>
    8a2c:	f13ffeff 	cmp	x23, #0xfff
    8a30:	b9400261 	ldr	w1, [x19]
    8a34:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8a38:	7100383f 	cmp	w1, #0xe
    8a3c:	54000160 	b.eq	8a68 <fwp_write+0x788>  // b.none
    8a40:	7100403f 	cmp	w1, #0x10
    8a44:	54001a60 	b.eq	8d90 <fwp_write+0xab0>  // b.none
    8a48:	7100283f 	cmp	w1, #0xa
    8a4c:	54002aa0 	b.eq	8fa0 <fwp_write+0xcc0>  // b.none
    8a50:	540014ac 	b.gt	8ce4 <fwp_write+0xa04>
    8a54:	71000c3f 	cmp	w1, #0x3
    8a58:	540029ac 	b.gt	8f8c <fwp_write+0xcac>
    8a5c:	d37ffee0 	lsr	x0, x23, #63
    8a60:	37f814a1 	tbnz	w1, #31, 8cf4 <fwp_write+0xa14>
    8a64:	d503201f 	nop
    8a68:	34001460 	cbz	w0, 8cf4 <fwp_write+0xa14>
    8a6c:	52800503 	mov	w3, #0x28                  	// #40
    8a70:	aa1503e1 	mov	x1, x21
    8a74:	aa1403e0 	mov	x0, x20
    8a78:	d2800022 	mov	x2, #0x1                   	// #1
    8a7c:	39001fe3 	strb	w3, [sp, #7]
    8a80:	97ffea44 	bl	3390 <buf_put>
    8a84:	aa1303e2 	mov	x2, x19
    8a88:	aa1703e1 	mov	x1, x23
    8a8c:	aa1403e0 	mov	x0, x20
    8a90:	52800003 	mov	w3, #0x0                   	// #0
    8a94:	97fffe13 	bl	82e0 <fwp_write>
    8a98:	52800523 	mov	w3, #0x29                  	// #41
    8a9c:	aa1503e1 	mov	x1, x21
    8aa0:	aa1403e0 	mov	x0, x20
    8aa4:	d2800022 	mov	x2, #0x1                   	// #1
    8aa8:	39001fe3 	strb	w3, [sp, #7]
    8aac:	97ffea39 	bl	3390 <buf_put>
    8ab0:	f9401780 	ldr	x0, [x28, #40]
    8ab4:	9100077b 	add	x27, x27, #0x1
    8ab8:	b8796800 	ldr	w0, [x0, x25]
    8abc:	6b1b001f 	cmp	w0, w27
    8ac0:	54fffa4c 	b.gt	8a08 <fwp_write+0x728>
    8ac4:	f9413bf5 	ldr	x21, [sp, #624]
    8ac8:	f9413ff6 	ldr	x22, [sp, #632]
    8acc:	f94143f7 	ldr	x23, [sp, #640]
    8ad0:	f94147f8 	ldr	x24, [sp, #648]
    8ad4:	f9414bf9 	ldr	x25, [sp, #656]
    8ad8:	f9414ffa 	ldr	x26, [sp, #664]
    8adc:	f94153fb 	ldr	x27, [sp, #672]
    8ae0:	f94157fc 	ldr	x28, [sp, #680]
    8ae4:	17fffe2b 	b	8390 <fwp_write+0xb0>
    8ae8:	52800783 	mov	w3, #0x3c                  	// #60
    8aec:	91001ff3 	add	x19, sp, #0x7
    8af0:	aa1303e1 	mov	x1, x19
    8af4:	d2800022 	mov	x2, #0x1                   	// #1
    8af8:	aa1403e0 	mov	x0, x20
    8afc:	39001fe3 	strb	w3, [sp, #7]
    8b00:	97ffea24 	bl	3390 <buf_put>
    8b04:	f9400795 	ldr	x21, [x28, #8]
    8b08:	aa1503e0 	mov	x0, x21
    8b0c:	97ffe6dd 	bl	2680 <strlen@plt>
    8b10:	aa1503e1 	mov	x1, x21
    8b14:	aa0003e2 	mov	x2, x0
    8b18:	aa1403e0 	mov	x0, x20
    8b1c:	97ffea1d 	bl	3390 <buf_put>
    8b20:	528007c3 	mov	w3, #0x3e                  	// #62
    8b24:	aa1303e1 	mov	x1, x19
    8b28:	aa1403e0 	mov	x0, x20
    8b2c:	d2800022 	mov	x2, #0x1                   	// #1
    8b30:	39001fe3 	strb	w3, [sp, #7]
    8b34:	17fffe12 	b	837c <fwp_write+0x9c>
    8b38:	f100067f 	cmp	x19, #0x1
    8b3c:	540025a0 	b.eq	8ff0 <fwp_write+0xd10>  // b.none
    8b40:	b100067f 	cmn	x19, #0x1
    8b44:	54002bc0 	b.eq	90bc <fwp_write+0xddc>  // b.none
    8b48:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8b4c:	9118a021 	add	x1, x1, #0x628
    8b50:	d2800022 	mov	x2, #0x1                   	// #1
    8b54:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8b58:	f947f400 	ldr	x0, [x0, #4072]
    8b5c:	f94127e4 	ldr	x4, [sp, #584]
    8b60:	f9400003 	ldr	x3, [x0]
    8b64:	eb030084 	subs	x4, x4, x3
    8b68:	d2800003 	mov	x3, #0x0                   	// #0
    8b6c:	54ffebe0 	b.eq	88e8 <fwp_write+0x608>  // b.none
    8b70:	f90143f7 	str	x23, [sp, #640]
    8b74:	f90147f8 	str	x24, [sp, #648]
    8b78:	f9014bf9 	str	x25, [sp, #656]
    8b7c:	f9014ffa 	str	x26, [sp, #664]
    8b80:	fd015be8 	str	d8, [sp, #688]
    8b84:	fd015fe9 	str	d9, [sp, #696]
    8b88:	97ffe71a 	bl	27f0 <__stack_chk_fail@plt>
    8b8c:	52800b63 	mov	w3, #0x5b                  	// #91
    8b90:	91001ff5 	add	x21, sp, #0x7
    8b94:	aa1503e1 	mov	x1, x21
    8b98:	aa1403e0 	mov	x0, x20
    8b9c:	d2800022 	mov	x2, #0x1                   	// #1
    8ba0:	b0000036 	adrp	x22, d000 <__modti3+0x230>
    8ba4:	911b22d6 	add	x22, x22, #0x6c8
    8ba8:	39001fe3 	strb	w3, [sp, #7]
    8bac:	97ffe9f9 	bl	3390 <buf_put>
    8bb0:	b4000273 	cbz	x19, 8bfc <fwp_write+0x91c>
    8bb4:	f9400661 	ldr	x1, [x19, #8]
    8bb8:	aa1403e0 	mov	x0, x20
    8bbc:	f9401f82 	ldr	x2, [x28, #56]
    8bc0:	52800003 	mov	w3, #0x0                   	// #0
    8bc4:	97fffdc7 	bl	82e0 <fwp_write>
    8bc8:	f9400a73 	ldr	x19, [x19, #16]
    8bcc:	b4000193 	cbz	x19, 8bfc <fwp_write+0x91c>
    8bd0:	aa1603e1 	mov	x1, x22
    8bd4:	aa1403e0 	mov	x0, x20
    8bd8:	d2800042 	mov	x2, #0x2                   	// #2
    8bdc:	97ffe9ed 	bl	3390 <buf_put>
    8be0:	f9400661 	ldr	x1, [x19, #8]
    8be4:	aa1403e0 	mov	x0, x20
    8be8:	f9401f82 	ldr	x2, [x28, #56]
    8bec:	52800003 	mov	w3, #0x0                   	// #0
    8bf0:	97fffdbc 	bl	82e0 <fwp_write>
    8bf4:	f9400a73 	ldr	x19, [x19, #16]
    8bf8:	b5fffed3 	cbnz	x19, 8bd0 <fwp_write+0x8f0>
    8bfc:	52800ba3 	mov	w3, #0x5d                  	// #93
    8c00:	aa1503e1 	mov	x1, x21
    8c04:	aa1403e0 	mov	x0, x20
    8c08:	d2800022 	mov	x2, #0x1                   	// #1
    8c0c:	39001fe3 	strb	w3, [sp, #7]
    8c10:	17fffddb 	b	837c <fwp_write+0x9c>
    8c14:	aa1403e0 	mov	x0, x20
    8c18:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8c1c:	d28000c2 	mov	x2, #0x6                   	// #6
    8c20:	911ae021 	add	x1, x1, #0x6b8
    8c24:	97ffe9db 	bl	3390 <buf_put>
    8c28:	f9400260 	ldr	x0, [x19]
    8c2c:	b40004c0 	cbz	x0, 8cc4 <fwp_write+0x9e4>
    8c30:	910123f5 	add	x21, sp, #0x48
    8c34:	91002276 	add	x22, x19, #0x8
    8c38:	f90143f7 	str	x23, [sp, #640]
    8c3c:	d2800017 	mov	x23, #0x0                   	// #0
    8c40:	f90147f8 	str	x24, [sp, #648]
    8c44:	b0000038 	adrp	x24, d000 <__modti3+0x230>
    8c48:	911b0318 	add	x24, x24, #0x6c0
    8c4c:	f9014bf9 	str	x25, [sp, #656]
    8c50:	b0000039 	adrp	x25, d000 <__modti3+0x230>
    8c54:	911b2339 	add	x25, x25, #0x6c8
    8c58:	f9014ffa 	str	x26, [sp, #664]
    8c5c:	14000005 	b	8c70 <fwp_write+0x990>
    8c60:	aa1903e1 	mov	x1, x25
    8c64:	aa1403e0 	mov	x0, x20
    8c68:	d2800042 	mov	x2, #0x2                   	// #2
    8c6c:	97ffe9c9 	bl	3390 <buf_put>
    8c70:	38776ac5 	ldrb	w5, [x22, x23]
    8c74:	d2804003 	mov	x3, #0x200                 	// #512
    8c78:	aa1803e4 	mov	x4, x24
    8c7c:	aa0303e1 	mov	x1, x3
    8c80:	52800042 	mov	w2, #0x2                   	// #2
    8c84:	aa1503e0 	mov	x0, x21
    8c88:	910006f7 	add	x23, x23, #0x1
    8c8c:	97ffe6b5 	bl	2760 <__snprintf_chk@plt>
    8c90:	aa1503e0 	mov	x0, x21
    8c94:	97ffe67b 	bl	2680 <strlen@plt>
    8c98:	aa1503e1 	mov	x1, x21
    8c9c:	aa0003e2 	mov	x2, x0
    8ca0:	aa1403e0 	mov	x0, x20
    8ca4:	97ffe9bb 	bl	3390 <buf_put>
    8ca8:	f9400260 	ldr	x0, [x19]
    8cac:	eb17001f 	cmp	x0, x23
    8cb0:	54fffd88 	b.hi	8c60 <fwp_write+0x980>  // b.pmore
    8cb4:	f94143f7 	ldr	x23, [sp, #640]
    8cb8:	f94147f8 	ldr	x24, [sp, #648]
    8cbc:	f9414bf9 	ldr	x25, [sp, #656]
    8cc0:	f9414ffa 	ldr	x26, [sp, #664]
    8cc4:	52800ba3 	mov	w3, #0x5d                  	// #93
    8cc8:	aa1403e0 	mov	x0, x20
    8ccc:	91001fe1 	add	x1, sp, #0x7
    8cd0:	d2800022 	mov	x2, #0x1                   	// #1
    8cd4:	39001fe3 	strb	w3, [sp, #7]
    8cd8:	17fffda9 	b	837c <fwp_write+0x9c>
    8cdc:	52800fa3 	mov	w3, #0x7d                  	// #125
    8ce0:	17fffe44 	b	85f0 <fwp_write+0x310>
    8ce4:	f10002ff 	cmp	x23, #0x0
    8ce8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8cec:	71002c3f 	cmp	w1, #0xb
    8cf0:	54ffebc0 	b.eq	8a68 <fwp_write+0x788>  // b.none
    8cf4:	aa1303e2 	mov	x2, x19
    8cf8:	aa1703e1 	mov	x1, x23
    8cfc:	aa1403e0 	mov	x0, x20
    8d00:	52800003 	mov	w3, #0x0                   	// #0
    8d04:	97fffd77 	bl	82e0 <fwp_write>
    8d08:	17ffff6a 	b	8ab0 <fwp_write+0x7d0>
    8d0c:	aa1403e0 	mov	x0, x20
    8d10:	91001fe1 	add	x1, sp, #0x7
    8d14:	52800fa3 	mov	w3, #0x7d                  	// #125
    8d18:	d2800022 	mov	x2, #0x1                   	// #1
    8d1c:	17fffe38 	b	85fc <fwp_write+0x31c>
    8d20:	a9400281 	ldp	x1, x0, [x20]
    8d24:	91000800 	add	x0, x0, #0x2
    8d28:	8b160000 	add	x0, x0, x22
    8d2c:	f9000680 	str	x0, [x20, #8]
    8d30:	3820683f 	strb	wzr, [x1, x0]
    8d34:	f9413bf5 	ldr	x21, [sp, #624]
    8d38:	f9413ff6 	ldr	x22, [sp, #632]
    8d3c:	f94153fb 	ldr	x27, [sp, #672]
    8d40:	f94157fc 	ldr	x28, [sp, #680]
    8d44:	17fffd93 	b	8390 <fwp_write+0xb0>
    8d48:	f9400f80 	ldr	x0, [x28, #24]
    8d4c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8d50:	aa1b03e0 	mov	x0, x27
    8d54:	97ffe64b 	bl	2680 <strlen@plt>
    8d58:	aa1b03e1 	mov	x1, x27
    8d5c:	aa0003e2 	mov	x2, x0
    8d60:	aa1403e0 	mov	x0, x20
    8d64:	97ffe98b 	bl	3390 <buf_put>
    8d68:	aa1903e1 	mov	x1, x25
    8d6c:	aa1403e0 	mov	x0, x20
    8d70:	d2800062 	mov	x2, #0x3                   	// #3
    8d74:	97ffe987 	bl	3390 <buf_put>
    8d78:	17fffe10 	b	85b8 <fwp_write+0x2d8>
    8d7c:	aa1a03e1 	mov	x1, x26
    8d80:	aa1403e0 	mov	x0, x20
    8d84:	d2800042 	mov	x2, #0x2                   	// #2
    8d88:	97ffe982 	bl	3390 <buf_put>
    8d8c:	17fffe09 	b	85b0 <fwp_write+0x2d0>
    8d90:	f9400660 	ldr	x0, [x19, #8]
    8d94:	b4fffb00 	cbz	x0, 8cf4 <fwp_write+0xa14>
    8d98:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8d9c:	911b8021 	add	x1, x1, #0x6e0
    8da0:	97ffe6b4 	bl	2870 <strcmp@plt>
    8da4:	7100001f 	cmp	w0, #0x0
    8da8:	1a9f07e0 	cset	w0, ne	// ne = any
    8dac:	17ffff2f 	b	8a68 <fwp_write+0x788>
    8db0:	aa1403e0 	mov	x0, x20
    8db4:	d2800042 	mov	x2, #0x2                   	// #2
    8db8:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8dbc:	911b6021 	add	x1, x1, #0x6d8
    8dc0:	97ffe974 	bl	3390 <buf_put>
    8dc4:	91004261 	add	x1, x19, #0x10
    8dc8:	aa1403e0 	mov	x0, x20
    8dcc:	f9402382 	ldr	x2, [x28, #64]
    8dd0:	52800003 	mov	w3, #0x0                   	// #0
    8dd4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8dd8:	97fffd42 	bl	82e0 <fwp_write>
    8ddc:	17fffd9c 	b	844c <fwp_write+0x16c>
    8de0:	1e22c109 	fcvt	d9, s8
    8de4:	910123f5 	add	x21, sp, #0x48
    8de8:	52800033 	mov	w19, #0x1                   	// #1
    8dec:	d503201f 	nop
    8df0:	1e604120 	fmov	d0, d9
    8df4:	2a1303e1 	mov	w1, w19
    8df8:	aa1503e0 	mov	x0, x21
    8dfc:	97ffeaa6 	bl	3894 <fwp_format_g.constprop.0>
    8e00:	aa1503e0 	mov	x0, x21
    8e04:	d2800001 	mov	x1, #0x0                   	// #0
    8e08:	97ffe6a6 	bl	28a0 <strtof@plt>
    8e0c:	1e202100 	fcmp	s8, s0
    8e10:	54ffdb60 	b.eq	897c <fwp_write+0x69c>  // b.none
    8e14:	11000673 	add	w19, w19, #0x1
    8e18:	71002a7f 	cmp	w19, #0xa
    8e1c:	54fffea1 	b.ne	8df0 <fwp_write+0xb10>  // b.any
    8e20:	1e604120 	fmov	d0, d9
    8e24:	aa1503e0 	mov	x0, x21
    8e28:	52800121 	mov	w1, #0x9                   	// #9
    8e2c:	97ffea9a 	bl	3894 <fwp_format_g.constprop.0>
    8e30:	17fffed3 	b	897c <fwp_write+0x69c>
    8e34:	d37ef6a1 	lsl	x1, x21, #2
    8e38:	b7f81563 	tbnz	x3, #63, 90e4 <fwp_write+0xe04>
    8e3c:	91002263 	add	x3, x19, #0x8
    8e40:	8b010061 	add	x1, x3, x1
    8e44:	b9400023 	ldr	w3, [x1]
    8e48:	7100081f 	cmp	w0, #0x2
    8e4c:	2a0303e1 	mov	w1, w3
    8e50:	93407c63 	sxtw	x3, w3
    8e54:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8e58:	17fffe5a 	b	87c0 <fwp_write+0x4e0>
    8e5c:	d37ffaa1 	lsl	x1, x21, #1
    8e60:	b7f81363 	tbnz	x3, #63, 90cc <fwp_write+0xdec>
    8e64:	91002263 	add	x3, x19, #0x8
    8e68:	8b010061 	add	x1, x3, x1
    8e6c:	79400021 	ldrh	w1, [x1]
    8e70:	7100041f 	cmp	w0, #0x1
    8e74:	93403c23 	sxth	x3, w1
    8e78:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8e7c:	17fffe51 	b	87c0 <fwp_write+0x4e0>
    8e80:	52800443 	mov	w3, #0x22                  	// #34
    8e84:	91001ff5 	add	x21, sp, #0x7
    8e88:	91002273 	add	x19, x19, #0x8
    8e8c:	aa1503e1 	mov	x1, x21
    8e90:	aa1403e0 	mov	x0, x20
    8e94:	d2800022 	mov	x2, #0x1                   	// #1
    8e98:	39001fe3 	strb	w3, [sp, #7]
    8e9c:	f90143f7 	str	x23, [sp, #640]
    8ea0:	8b160277 	add	x23, x19, x22
    8ea4:	f90147f8 	str	x24, [sp, #648]
    8ea8:	97ffe93a 	bl	3390 <buf_put>
    8eac:	b4000696 	cbz	x22, 8f7c <fwp_write+0xc9c>
    8eb0:	b0000038 	adrp	x24, d000 <__modti3+0x230>
    8eb4:	911a2318 	add	x24, x24, #0x688
    8eb8:	f9014bf9 	str	x25, [sp, #656]
    8ebc:	b0000039 	adrp	x25, d000 <__modti3+0x230>
    8ec0:	911aa339 	add	x25, x25, #0x6a8
    8ec4:	f9014ffa 	str	x26, [sp, #664]
    8ec8:	1400000d 	b	8efc <fwp_write+0xc1c>
    8ecc:	710024bf 	cmp	w5, #0x9
    8ed0:	54000460 	b.eq	8f5c <fwp_write+0xc7c>  // b.none
    8ed4:	710028bf 	cmp	w5, #0xa
    8ed8:	54000a61 	b.ne	9024 <fwp_write+0xd44>  // b.any
    8edc:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8ee0:	aa1403e0 	mov	x0, x20
    8ee4:	911a6021 	add	x1, x1, #0x698
    8ee8:	d2800042 	mov	x2, #0x2                   	// #2
    8eec:	97ffe929 	bl	3390 <buf_put>
    8ef0:	91000673 	add	x19, x19, #0x1
    8ef4:	eb17027f 	cmp	x19, x23
    8ef8:	540003e0 	b.eq	8f74 <fwp_write+0xc94>  // b.none
    8efc:	39400265 	ldrb	w5, [x19]
    8f00:	710034bf 	cmp	w5, #0xd
    8f04:	54000180 	b.eq	8f34 <fwp_write+0xc54>  // b.none
    8f08:	54fffe29 	b.ls	8ecc <fwp_write+0xbec>  // b.plast
    8f0c:	710088bf 	cmp	w5, #0x22
    8f10:	540001c0 	b.eq	8f48 <fwp_write+0xc68>  // b.none
    8f14:	710170bf 	cmp	w5, #0x5c
    8f18:	54000741 	b.ne	9000 <fwp_write+0xd20>  // b.any
    8f1c:	aa1403e0 	mov	x0, x20
    8f20:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8f24:	d2800042 	mov	x2, #0x2                   	// #2
    8f28:	911a4021 	add	x1, x1, #0x690
    8f2c:	97ffe919 	bl	3390 <buf_put>
    8f30:	17fffff0 	b	8ef0 <fwp_write+0xc10>
    8f34:	aa1903e1 	mov	x1, x25
    8f38:	aa1403e0 	mov	x0, x20
    8f3c:	d2800042 	mov	x2, #0x2                   	// #2
    8f40:	97ffe914 	bl	3390 <buf_put>
    8f44:	17ffffeb 	b	8ef0 <fwp_write+0xc10>
    8f48:	aa1803e1 	mov	x1, x24
    8f4c:	aa1403e0 	mov	x0, x20
    8f50:	d2800042 	mov	x2, #0x2                   	// #2
    8f54:	97ffe90f 	bl	3390 <buf_put>
    8f58:	17ffffe6 	b	8ef0 <fwp_write+0xc10>
    8f5c:	aa1403e0 	mov	x0, x20
    8f60:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8f64:	d2800042 	mov	x2, #0x2                   	// #2
    8f68:	911a8021 	add	x1, x1, #0x6a0
    8f6c:	97ffe909 	bl	3390 <buf_put>
    8f70:	17ffffe0 	b	8ef0 <fwp_write+0xc10>
    8f74:	f9414bf9 	ldr	x25, [sp, #656]
    8f78:	f9414ffa 	ldr	x26, [sp, #664]
    8f7c:	aa1503e1 	mov	x1, x21
    8f80:	aa1403e0 	mov	x0, x20
    8f84:	52800443 	mov	w3, #0x22                  	// #34
    8f88:	17fffd9c 	b	85f8 <fwp_write+0x318>
    8f8c:	7100103f 	cmp	w1, #0x4
    8f90:	54ffeb21 	b.ne	8cf4 <fwp_write+0xa14>  // b.any
    8f94:	f94006e0 	ldr	x0, [x23, #8]
    8f98:	d37ffc00 	lsr	x0, x0, #63
    8f9c:	17fffeb3 	b	8a68 <fwp_write+0x788>
    8fa0:	710002ff 	cmp	w23, #0x0
    8fa4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8fa8:	17fffeb0 	b	8a68 <fwp_write+0x788>
    8fac:	528005a1 	mov	w1, #0x2d                  	// #45
    8fb0:	eb0203e2 	negs	x2, x2
    8fb4:	da0303e3 	ngc	x3, x3
    8fb8:	910127e0 	add	x0, sp, #0x49
    8fbc:	910123f5 	add	x21, sp, #0x48
    8fc0:	390123e1 	strb	w1, [sp, #72]
    8fc4:	97ffe777 	bl	2da0 <fwp_fmt_u128>
    8fc8:	17fffe18 	b	8828 <fwp_write+0x548>
    8fcc:	d37ceea1 	lsl	x1, x21, #4
    8fd0:	b7f810a3 	tbnz	x3, #63, 91e4 <fwp_write+0xf04>
    8fd4:	91002260 	add	x0, x19, #0x8
    8fd8:	8b010001 	add	x1, x0, x1
    8fdc:	17fffdf9 	b	87c0 <fwp_write+0x4e0>
    8fe0:	f9400a61 	ldr	x1, [x19, #16]
    8fe4:	8b010000 	add	x0, x0, x1
    8fe8:	f9400001 	ldr	x1, [x0]
    8fec:	17fffdf5 	b	87c0 <fwp_write+0x4e0>
    8ff0:	b0000021 	adrp	x1, d000 <__modti3+0x230>
    8ff4:	d2800042 	mov	x2, #0x2                   	// #2
    8ff8:	9118c021 	add	x1, x1, #0x630
    8ffc:	17fffed6 	b	8b54 <fwp_write+0x874>
    9000:	7101fcbf 	cmp	w5, #0x7f
    9004:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9008:	540000e9 	b.ls	9024 <fwp_write+0xd44>  // b.plast
    900c:	aa1503e1 	mov	x1, x21
    9010:	aa1403e0 	mov	x0, x20
    9014:	d2800022 	mov	x2, #0x1                   	// #1
    9018:	39001fe5 	strb	w5, [sp, #7]
    901c:	97ffe8dd 	bl	3390 <buf_put>
    9020:	17ffffb4 	b	8ef0 <fwp_write+0xc10>
    9024:	d2800203 	mov	x3, #0x10                  	// #16
    9028:	90000024 	adrp	x4, d000 <__modti3+0x230>
    902c:	aa0303e1 	mov	x1, x3
    9030:	911ac084 	add	x4, x4, #0x6b0
    9034:	910123f6 	add	x22, sp, #0x48
    9038:	52800042 	mov	w2, #0x2                   	// #2
    903c:	aa1603e0 	mov	x0, x22
    9040:	97ffe5c8 	bl	2760 <__snprintf_chk@plt>
    9044:	aa1603e0 	mov	x0, x22
    9048:	97ffe58e 	bl	2680 <strlen@plt>
    904c:	aa1603e1 	mov	x1, x22
    9050:	aa0003e2 	mov	x2, x0
    9054:	aa1403e0 	mov	x0, x20
    9058:	97ffe8ce 	bl	3390 <buf_put>
    905c:	17ffffa5 	b	8ef0 <fwp_write+0xc10>
    9060:	1e604100 	fmov	d0, d8
    9064:	aa1503e0 	mov	x0, x21
    9068:	52800221 	mov	w1, #0x11                  	// #17
    906c:	97ffea0a 	bl	3894 <fwp_format_g.constprop.0>
    9070:	17fffe43 	b	897c <fwp_write+0x69c>
    9074:	b9401040 	ldr	w0, [x2, #16]
    9078:	350003c0 	cbnz	w0, 90f0 <fwp_write+0xe10>
    907c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9080:	f947f400 	ldr	x0, [x0, #4072]
    9084:	f94127e2 	ldr	x2, [sp, #584]
    9088:	f9400001 	ldr	x1, [x0]
    908c:	eb010042 	subs	x2, x2, x1
    9090:	d2800001 	mov	x1, #0x0                   	// #0
    9094:	54ffd721 	b.ne	8b78 <fwp_write+0x898>  // b.any
    9098:	f9413bf5 	ldr	x21, [sp, #624]
    909c:	90000021 	adrp	x1, d000 <__modti3+0x230>
    90a0:	f9413ff6 	ldr	x22, [sp, #632]
    90a4:	aa1403e0 	mov	x0, x20
    90a8:	f94143f7 	ldr	x23, [sp, #640]
    90ac:	911c0021 	add	x1, x1, #0x700
    90b0:	f94147f8 	ldr	x24, [sp, #648]
    90b4:	d2800042 	mov	x2, #0x2                   	// #2
    90b8:	17fffd0e 	b	84f0 <fwp_write+0x210>
    90bc:	90000021 	adrp	x1, d000 <__modti3+0x230>
    90c0:	d2800042 	mov	x2, #0x2                   	// #2
    90c4:	9118e021 	add	x1, x1, #0x638
    90c8:	17fffea3 	b	8b54 <fwp_write+0x874>
    90cc:	f9400a63 	ldr	x3, [x19, #16]
    90d0:	8b030021 	add	x1, x1, x3
    90d4:	17ffff66 	b	8e6c <fwp_write+0xb8c>
    90d8:	f9400a61 	ldr	x1, [x19, #16]
    90dc:	8b0102a1 	add	x1, x21, x1
    90e0:	17fffdb3 	b	87ac <fwp_write+0x4cc>
    90e4:	f9400a63 	ldr	x3, [x19, #16]
    90e8:	8b030021 	add	x1, x1, x3
    90ec:	17ffff56 	b	8e44 <fwp_write+0xb64>
    90f0:	b9404840 	ldr	w0, [x2, #72]
    90f4:	91001ff5 	add	x21, sp, #0x7
    90f8:	34ffa360 	cbz	w0, 8564 <fwp_write+0x284>
    90fc:	52800503 	mov	w3, #0x28                  	// #40
    9100:	aa1403e0 	mov	x0, x20
    9104:	aa1503e1 	mov	x1, x21
    9108:	d2800022 	mov	x2, #0x1                   	// #1
    910c:	39001fe3 	strb	w3, [sp, #7]
    9110:	97ffe8a0 	bl	3390 <buf_put>
    9114:	b9401380 	ldr	w0, [x28, #16]
    9118:	52800038 	mov	w24, #0x1                   	// #1
    911c:	7100001f 	cmp	w0, #0x0
    9120:	54ffa36c 	b.gt	858c <fwp_write+0x2ac>
    9124:	17fffd32 	b	85ec <fwp_write+0x30c>
    9128:	f9014bf9 	str	x25, [sp, #656]
    912c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xed48>
    9130:	f9014ffa 	str	x26, [sp, #664]
    9134:	f9400676 	ldr	x22, [x19, #8]
    9138:	91102333 	add	x19, x25, #0x408
    913c:	91002273 	add	x19, x19, #0x8
    9140:	937ffed8 	asr	x24, x22, #63
    9144:	aa1802c0 	orr	x0, x22, x24
    9148:	b5000320 	cbnz	x0, 91ac <fwp_write+0xecc>
    914c:	110006b5 	add	w21, w21, #0x1
    9150:	710016bf 	cmp	w21, #0x5
    9154:	54ffffc1 	b.ne	914c <fwp_write+0xe6c>  // b.any
    9158:	b7f80578 	tbnz	x24, #63, 9204 <fwp_write+0xf24>
    915c:	910023f3 	add	x19, sp, #0x8
    9160:	aa1603e2 	mov	x2, x22
    9164:	aa1303e0 	mov	x0, x19
    9168:	d2800003 	mov	x3, #0x0                   	// #0
    916c:	97ffe70d 	bl	2da0 <fwp_fmt_u128>
    9170:	910123f5 	add	x21, sp, #0x48
    9174:	90000023 	adrp	x3, d000 <__modti3+0x230>
    9178:	aa1303e4 	mov	x4, x19
    917c:	aa1503e0 	mov	x0, x21
    9180:	911be063 	add	x3, x3, #0x6f8
    9184:	d2804002 	mov	x2, #0x200                 	// #512
    9188:	52800041 	mov	w1, #0x2                   	// #2
    918c:	97ffe541 	bl	2690 <__sprintf_chk@plt>
    9190:	aa1503e0 	mov	x0, x21
    9194:	97ffe53b 	bl	2680 <strlen@plt>
    9198:	aa1503e1 	mov	x1, x21
    919c:	aa0003e2 	mov	x2, x0
    91a0:	aa1403e0 	mov	x0, x20
    91a4:	97ffe87b 	bl	3390 <buf_put>
    91a8:	17fffe47 	b	8ac4 <fwp_write+0x7e4>
    91ac:	f9400277 	ldr	x23, [x19]
    91b0:	aa1603e0 	mov	x0, x22
    91b4:	aa1803e1 	mov	x1, x24
    91b8:	aa1703e2 	mov	x2, x23
    91bc:	937ffefa 	asr	x26, x23, #63
    91c0:	aa1a03e3 	mov	x3, x26
    91c4:	94000f03 	bl	cdd0 <__modti3>
    91c8:	aa010000 	orr	x0, x0, x1
    91cc:	b40002c0 	cbz	x0, 9224 <fwp_write+0xf44>
    91d0:	110006b5 	add	w21, w21, #0x1
    91d4:	91004273 	add	x19, x19, #0x10
    91d8:	710016bf 	cmp	w21, #0x5
    91dc:	54fffe81 	b.ne	91ac <fwp_write+0xecc>  // b.any
    91e0:	17ffffde 	b	9158 <fwp_write+0xe78>
    91e4:	f9400a60 	ldr	x0, [x19, #16]
    91e8:	8b000021 	add	x1, x1, x0
    91ec:	17fffd75 	b	87c0 <fwp_write+0x4e0>
    91f0:	528c29c0 	mov	w0, #0x614e                	// #24910
    91f4:	910123f5 	add	x21, sp, #0x48
    91f8:	72a009c0 	movk	w0, #0x4e, lsl #16
    91fc:	b9004be0 	str	w0, [sp, #72]
    9200:	17fffda2 	b	8888 <fwp_write+0x5a8>
    9204:	528005a1 	mov	w1, #0x2d                  	// #45
    9208:	eb1603e2 	negs	x2, x22
    920c:	da1803e3 	ngc	x3, x24
    9210:	910027e0 	add	x0, sp, #0x9
    9214:	910023f3 	add	x19, sp, #0x8
    9218:	390023e1 	strb	w1, [sp, #8]
    921c:	97ffe6e1 	bl	2da0 <fwp_fmt_u128>
    9220:	17ffffd4 	b	9170 <fwp_write+0xe90>
    9224:	aa1703e2 	mov	x2, x23
    9228:	aa1a03e3 	mov	x3, x26
    922c:	aa1603e0 	mov	x0, x22
    9230:	aa1803e1 	mov	x1, x24
    9234:	94000e07 	bl	ca50 <__divti3>
    9238:	aa0003e2 	mov	x2, x0
    923c:	aa0103e3 	mov	x3, x1
    9240:	b7f80201 	tbnz	x1, #63, 9280 <fwp_write+0xfa0>
    9244:	910023f3 	add	x19, sp, #0x8
    9248:	aa1303e0 	mov	x0, x19
    924c:	97ffe6d5 	bl	2da0 <fwp_fmt_u128>
    9250:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9254:	91102339 	add	x25, x25, #0x408
    9258:	910123f5 	add	x21, sp, #0x48
    925c:	aa1303e4 	mov	x4, x19
    9260:	aa1503e0 	mov	x0, x21
    9264:	90000023 	adrp	x3, d000 <__modti3+0x230>
    9268:	f8616b25 	ldr	x5, [x25, x1]
    926c:	911bc063 	add	x3, x3, #0x6f0
    9270:	d2804002 	mov	x2, #0x200                 	// #512
    9274:	52800041 	mov	w1, #0x2                   	// #2
    9278:	97ffe506 	bl	2690 <__sprintf_chk@plt>
    927c:	17ffffc5 	b	9190 <fwp_write+0xeb0>
    9280:	528005a4 	mov	w4, #0x2d                  	// #45
    9284:	eb0003e2 	negs	x2, x0
    9288:	da0103e3 	ngc	x3, x1
    928c:	910027e0 	add	x0, sp, #0x9
    9290:	910023f3 	add	x19, sp, #0x8
    9294:	390023e4 	strb	w4, [sp, #8]
    9298:	97ffe6c2 	bl	2da0 <fwp_fmt_u128>
    929c:	17ffffed 	b	9250 <fwp_write+0xf70>
    92a0:	f9013bf5 	str	x21, [sp, #624]
    92a4:	f9013ff6 	str	x22, [sp, #632]
    92a8:	f90143f7 	str	x23, [sp, #640]
    92ac:	f90147f8 	str	x24, [sp, #648]
    92b0:	f9014bf9 	str	x25, [sp, #656]
    92b4:	f9014ffa 	str	x26, [sp, #664]
    92b8:	f90153fb 	str	x27, [sp, #672]
    92bc:	f90157fc 	str	x28, [sp, #680]
    92c0:	fd015be8 	str	d8, [sp, #688]
    92c4:	fd015fe9 	str	d9, [sp, #696]
    92c8:	97ffe54a 	bl	27f0 <__stack_chk_fail@plt>
    92cc:	d503201f 	nop

00000000000092d0 <fwp_hof0.constprop.0>:
    92d0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    92d4:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    92d8:	f947f442 	ldr	x2, [x2, #4072]
    92dc:	910003fd 	mov	x29, sp
    92e0:	a90153f3 	stp	x19, x20, [sp, #16]
    92e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    92e8:	a90363f7 	stp	x23, x24, [sp, #48]
    92ec:	aa0003f7 	mov	x23, x0
    92f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    92f4:	a90573fb 	stp	x27, x28, [sp, #80]
    92f8:	d10243ff 	sub	sp, sp, #0x90
    92fc:	f9400040 	ldr	x0, [x2]
    9300:	f81f83a0 	stur	x0, [x29, #-8]
    9304:	d2800000 	mov	x0, #0x0                   	// #0
    9308:	b4002da1 	cbz	x1, 98bc <fwp_hof0.constprop.0+0x5ec>
    930c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9310:	9100401c 	add	x28, x0, #0x10
    9314:	9100239c 	add	x28, x28, #0x8
    9318:	f00000a0 	adrp	x0, 20000 <__data_start>
    931c:	aa0103fa 	mov	x26, x1
    9320:	d10083b4 	sub	x20, x29, #0x20
    9324:	91010015 	add	x21, x0, #0x40
    9328:	aa1c03f8 	mov	x24, x28
    932c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9330:	9115c002 	add	x2, x0, #0x570
    9334:	f949d841 	ldr	x1, [x2, #5040]
    9338:	f949ec40 	ldr	x0, [x2, #5080]
    933c:	cb0102e1 	sub	x1, x23, x1
    9340:	eb00403f 	cmp	x1, x0, lsl #16
    9344:	54000342 	b.cs	93ac <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9348:	d350fc20 	lsr	x0, x1, #16
    934c:	f949fc44 	ldr	x4, [x2, #5112]
    9350:	8b000800 	add	x0, x0, x0, lsl #2
    9354:	d37df002 	lsl	x2, x0, #3
    9358:	8b020083 	add	x3, x4, x2
    935c:	f9401060 	ldr	x0, [x3, #32]
    9360:	b4000260 	cbz	x0, 93ac <fwp_hof0.constprop.0+0xdc>
    9364:	38626882 	ldrb	w2, [x4, x2]
    9368:	7100085f 	cmp	w2, #0x2
    936c:	54005240 	b.eq	9db4 <fwp_hof0.constprop.0+0xae4>  // b.none
    9370:	7100045f 	cmp	w2, #0x1
    9374:	540001c1 	b.ne	93ac <fwp_hof0.constprop.0+0xdc>  // b.any
    9378:	29430864 	ldp	w4, w2, [x3, #24]
    937c:	92403c21 	and	x1, x1, #0xffff
    9380:	9b047c21 	mul	x1, x1, x4
    9384:	d360fc21 	lsr	x1, x1, #32
    9388:	eb02003f 	cmp	x1, x2
    938c:	54000102 	b.cs	93ac <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9390:	8b010000 	add	x0, x0, x1
    9394:	39400001 	ldrb	w1, [x0]
    9398:	340000a1 	cbz	w1, 93ac <fwp_hof0.constprop.0+0xdc>
    939c:	7103f43f 	cmp	w1, #0xfd
    93a0:	54005728 	b.hi	9e84 <fwp_hof0.constprop.0+0xbb4>  // b.pmore
    93a4:	11000421 	add	w1, w1, #0x1
    93a8:	39000001 	strb	w1, [x0]
    93ac:	aa1703f9 	mov	x25, x23
    93b0:	a938dfba 	stp	x26, x23, [x29, #-120]
    93b4:	aa1803fa 	mov	x26, x24
    93b8:	d28018f3 	mov	x19, #0xc7                  	// #199
    93bc:	f81983b3 	stur	x19, [x29, #-104]
    93c0:	f00000a0 	adrp	x0, 20000 <__data_start>
    93c4:	91004000 	add	x0, x0, #0x10
    93c8:	f9401ea3 	ldr	x3, [x21, #56]
    93cc:	91002005 	add	x5, x0, #0x8
    93d0:	b9400802 	ldr	w2, [x0, #8]
    93d4:	d37be842 	lsl	x2, x2, #5
    93d8:	8b02007b 	add	x27, x3, x2
    93dc:	f9400f61 	ldr	x1, [x27, #24]
    93e0:	f81e03b9 	stur	x25, [x29, #-32]
    93e4:	b4004ee1 	cbz	x1, 9dc0 <fwp_hof0.constprop.0+0xaf0>
    93e8:	f9400c20 	ldr	x0, [x1, #24]
    93ec:	b40042a0 	cbz	x0, 9c40 <fwp_hof0.constprop.0+0x970>
    93f0:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    93f4:	9115c002 	add	x2, x0, #0x570
    93f8:	f949d841 	ldr	x1, [x2, #5040]
    93fc:	f949ec40 	ldr	x0, [x2, #5080]
    9400:	cb010341 	sub	x1, x26, x1
    9404:	eb00403f 	cmp	x1, x0, lsl #16
    9408:	54000342 	b.cs	9470 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    940c:	d350fc20 	lsr	x0, x1, #16
    9410:	f949fc45 	ldr	x5, [x2, #5112]
    9414:	8b000800 	add	x0, x0, x0, lsl #2
    9418:	d37df002 	lsl	x2, x0, #3
    941c:	8b0200a3 	add	x3, x5, x2
    9420:	f9401060 	ldr	x0, [x3, #32]
    9424:	b4000260 	cbz	x0, 9470 <fwp_hof0.constprop.0+0x1a0>
    9428:	386268a2 	ldrb	w2, [x5, x2]
    942c:	7100085f 	cmp	w2, #0x2
    9430:	54004700 	b.eq	9d10 <fwp_hof0.constprop.0+0xa40>  // b.none
    9434:	7100045f 	cmp	w2, #0x1
    9438:	540001c1 	b.ne	9470 <fwp_hof0.constprop.0+0x1a0>  // b.any
    943c:	29430865 	ldp	w5, w2, [x3, #24]
    9440:	92403c21 	and	x1, x1, #0xffff
    9444:	9b057c21 	mul	x1, x1, x5
    9448:	d360fc21 	lsr	x1, x1, #32
    944c:	eb02003f 	cmp	x1, x2
    9450:	54000102 	b.cs	9470 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    9454:	8b010000 	add	x0, x0, x1
    9458:	39400001 	ldrb	w1, [x0]
    945c:	340000a1 	cbz	w1, 9470 <fwp_hof0.constprop.0+0x1a0>
    9460:	7103f43f 	cmp	w1, #0xfd
    9464:	54004988 	b.hi	9d94 <fwp_hof0.constprop.0+0xac4>  // b.pmore
    9468:	11000421 	add	w1, w1, #0x1
    946c:	39000001 	strb	w1, [x0]
    9470:	aa1a03f9 	mov	x25, x26
    9474:	aa1a03e0 	mov	x0, x26
    9478:	aa1b03e3 	mov	x3, x27
    947c:	52800037 	mov	w23, #0x1                   	// #1
    9480:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc70>
    9484:	9115c036 	add	x22, x1, #0x570
    9488:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    948c:	f81b03b6 	stur	x22, [x29, #-80]
    9490:	b81cc3b7 	stur	w23, [x29, #-52]
    9494:	f81d03b4 	stur	x20, [x29, #-48]
    9498:	b9400401 	ldr	w1, [x0, #4]
    949c:	b9400078 	ldr	w24, [x3]
    94a0:	b85cc3a0 	ldur	w0, [x29, #-52]
    94a4:	4b010318 	sub	w24, w24, w1
    94a8:	6b17031f 	cmp	w24, w23
    94ac:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    94b0:	6b0000ff 	cmp	w7, w0
    94b4:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    94b8:	b81c83a0 	stur	w0, [x29, #-56]
    94bc:	6b0000e2 	subs	w2, w7, w0
    94c0:	54000120 	b.eq	94e4 <fwp_hof0.constprop.0+0x214>  // b.none
    94c4:	f9400c63 	ldr	x3, [x3, #24]
    94c8:	0b000021 	add	w1, w1, w0
    94cc:	f85d03a4 	ldur	x4, [x29, #-48]
    94d0:	b81d83a7 	stur	w7, [x29, #-40]
    94d4:	f9400863 	ldr	x3, [x3, #16]
    94d8:	8b204c80 	add	x0, x4, w0, uxtw #3
    94dc:	d63f0060 	blr	x3
    94e0:	b85d83a7 	ldur	w7, [x29, #-40]
    94e4:	f9401ea0 	ldr	x0, [x21, #56]
    94e8:	aa1903e6 	mov	x6, x25
    94ec:	b9400323 	ldr	w3, [x25]
    94f0:	2a0703f4 	mov	w20, w7
    94f4:	f85d03bb 	ldur	x27, [x29, #-48]
    94f8:	aa1903fc 	mov	x28, x25
    94fc:	8b03141a 	add	x26, x0, x3, lsl #5
    9500:	f9400f40 	ldr	x0, [x26, #24]
    9504:	b40020e0 	cbz	x0, 9920 <fwp_hof0.constprop.0+0x650>
    9508:	f85b03bc 	ldur	x28, [x29, #-80]
    950c:	29371fb7 	stp	w23, w7, [x29, #-72]
    9510:	aa1a03f7 	mov	x23, x26
    9514:	b81c03b8 	stur	w24, [x29, #-64]
    9518:	aa1b03f8 	mov	x24, x27
    951c:	14000012 	b	9564 <fwp_hof0.constprop.0+0x294>
    9520:	f9400001 	ldr	x1, [x0]
    9524:	aa1803e0 	mov	x0, x24
    9528:	d63f0020 	blr	x1
    952c:	aa0003fb 	mov	x27, x0
    9530:	aa1903e0 	mov	x0, x25
    9534:	97fff1e7 	bl	5cd0 <fwp_closure_drop>
    9538:	6b13029f 	cmp	w20, w19
    953c:	54000ca0 	b.eq	96d0 <fwp_hof0.constprop.0+0x400>  // b.none
    9540:	f9401ea0 	ldr	x0, [x21, #56]
    9544:	8b334f18 	add	x24, x24, w19, uxtw #3
    9548:	b9400363 	ldr	w3, [x27]
    954c:	4b1a02d4 	sub	w20, w22, w26
    9550:	aa1b03e6 	mov	x6, x27
    9554:	8b031417 	add	x23, x0, x3, lsl #5
    9558:	f9400ee0 	ldr	x0, [x23, #24]
    955c:	b4001da0 	cbz	x0, 9910 <fwp_hof0.constprop.0+0x640>
    9560:	aa1b03f9 	mov	x25, x27
    9564:	b94004c1 	ldr	w1, [x6, #4]
    9568:	b94002fa 	ldr	w26, [x23]
    956c:	0b010296 	add	w22, w20, w1
    9570:	6b16035f 	cmp	w26, w22
    9574:	54002488 	b.hi	9a04 <fwp_hof0.constprop.0+0x734>  // b.pmore
    9578:	7100003f 	cmp	w1, #0x0
    957c:	4b010353 	sub	w19, w26, w1
    9580:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9584:	54fffce1 	b.ne	9520 <fwp_hof0.constprop.0+0x250>  // b.any
    9588:	7100035f 	cmp	w26, #0x0
    958c:	910003e2 	mov	x2, sp
    9590:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    9594:	f81d83a2 	stur	x2, [x29, #-40]
    9598:	d37df084 	lsl	x4, x4, #3
    959c:	91003c84 	add	x4, x4, #0xf
    95a0:	92704c87 	and	x7, x4, #0xfffff0000
    95a4:	927c7c84 	and	x4, x4, #0xffffffff0
    95a8:	cb2763e7 	sub	x7, sp, x7
    95ac:	eb2763ff 	cmp	sp, x7
    95b0:	540000a0 	b.eq	95c4 <fwp_hof0.constprop.0+0x2f4>  // b.none
    95b4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    95b8:	f90203ff 	str	xzr, [sp, #1024]
    95bc:	eb2763ff 	cmp	sp, x7
    95c0:	54ffffa1 	b.ne	95b4 <fwp_hof0.constprop.0+0x2e4>  // b.any
    95c4:	92403c84 	and	x4, x4, #0xffff
    95c8:	cb2463ff 	sub	sp, sp, x4
    95cc:	f90003ff 	str	xzr, [sp]
    95d0:	f110009f 	cmp	x4, #0x400
    95d4:	54000043 	b.cc	95dc <fwp_hof0.constprop.0+0x30c>  // b.lo, b.ul, b.last
    95d8:	f90203ff 	str	xzr, [sp, #1024]
    95dc:	910043fb 	add	x27, sp, #0x10
    95e0:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    95e4:	910020c9 	add	x9, x6, #0x8
    95e8:	d2800004 	mov	x4, #0x0                   	// #0
    95ec:	340000c1 	cbz	w1, 9604 <fwp_hof0.constprop.0+0x334>
    95f0:	f8646922 	ldr	x2, [x9, x4]
    95f4:	f8246b62 	str	x2, [x27, x4]
    95f8:	91002084 	add	x4, x4, #0x8
    95fc:	eb04015f 	cmp	x10, x4
    9600:	54ffff81 	b.ne	95f0 <fwp_hof0.constprop.0+0x320>  // b.any
    9604:	2a1303ea 	mov	w10, w19
    9608:	d2800004 	mov	x4, #0x0                   	// #0
    960c:	340000f3 	cbz	w19, 9628 <fwp_hof0.constprop.0+0x358>
    9610:	0b040022 	add	w2, w1, w4
    9614:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9618:	91000484 	add	x4, x4, #0x1
    961c:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9620:	eb04015f 	cmp	x10, x4
    9624:	54ffff61 	b.ne	9610 <fwp_hof0.constprop.0+0x340>  // b.any
    9628:	f949db81 	ldr	x1, [x28, #5040]
    962c:	f949ef84 	ldr	x4, [x28, #5080]
    9630:	cb010321 	sub	x1, x25, x1
    9634:	eb04403f 	cmp	x1, x4, lsl #16
    9638:	540002e2 	b.cs	9694 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    963c:	d350fc24 	lsr	x4, x1, #16
    9640:	f949ff8a 	ldr	x10, [x28, #5112]
    9644:	8b040884 	add	x4, x4, x4, lsl #2
    9648:	d37df084 	lsl	x4, x4, #3
    964c:	8b040149 	add	x9, x10, x4
    9650:	f9401128 	ldr	x8, [x9, #32]
    9654:	b4000208 	cbz	x8, 9694 <fwp_hof0.constprop.0+0x3c4>
    9658:	38646944 	ldrb	w4, [x10, x4]
    965c:	7100089f 	cmp	w4, #0x2
    9660:	54001520 	b.eq	9904 <fwp_hof0.constprop.0+0x634>  // b.none
    9664:	7100049f 	cmp	w4, #0x1
    9668:	54000161 	b.ne	9694 <fwp_hof0.constprop.0+0x3c4>  // b.any
    966c:	2943112a 	ldp	w10, w4, [x9, #24]
    9670:	92403c21 	and	x1, x1, #0xffff
    9674:	9b0a7c21 	mul	x1, x1, x10
    9678:	d360fc21 	lsr	x1, x1, #32
    967c:	eb04003f 	cmp	x1, x4
    9680:	540000a2 	b.cs	9694 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    9684:	8b010108 	add	x8, x8, x1
    9688:	39400101 	ldrb	w1, [x8]
    968c:	7100043f 	cmp	w1, #0x1
    9690:	54001360 	b.eq	98fc <fwp_hof0.constprop.0+0x62c>  // b.none
    9694:	f9400404 	ldr	x4, [x0, #8]
    9698:	52800021 	mov	w1, #0x1                   	// #1
    969c:	aa1903e0 	mov	x0, x25
    96a0:	d63f0080 	blr	x4
    96a4:	f9400ee1 	ldr	x1, [x23, #24]
    96a8:	aa1b03e0 	mov	x0, x27
    96ac:	f9400021 	ldr	x1, [x1]
    96b0:	d63f0020 	blr	x1
    96b4:	aa0003fb 	mov	x27, x0
    96b8:	f85d83a0 	ldur	x0, [x29, #-40]
    96bc:	9100001f 	mov	sp, x0
    96c0:	aa1903e0 	mov	x0, x25
    96c4:	97fff183 	bl	5cd0 <fwp_closure_drop>
    96c8:	6b13029f 	cmp	w20, w19
    96cc:	54fff3a1 	b.ne	9540 <fwp_hof0.constprop.0+0x270>  // b.any
    96d0:	29771fb7 	ldp	w23, w7, [x29, #-72]
    96d4:	aa1b03f9 	mov	x25, x27
    96d8:	b85c03b8 	ldur	w24, [x29, #-64]
    96dc:	6b17031f 	cmp	w24, w23
    96e0:	540014c3 	b.cc	9978 <fwp_hof0.constprop.0+0x6a8>  // b.lo, b.ul, b.last
    96e4:	f85983a0 	ldur	x0, [x29, #-104]
    96e8:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    96ec:	f1000400 	subs	x0, x0, #0x1
    96f0:	f81983a0 	stur	x0, [x29, #-104]
    96f4:	54ffe661 	b.ne	93c0 <fwp_hof0.constprop.0+0xf0>  // b.any
    96f8:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xed48>
    96fc:	91102042 	add	x2, x2, #0x408
    9700:	aa1903e1 	mov	x1, x25
    9704:	aa1403e0 	mov	x0, x20
    9708:	aa1a03f8 	mov	x24, x26
    970c:	aa1903fb 	mov	x27, x25
    9710:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9714:	91014042 	add	x2, x2, #0x50
    9718:	52800023 	mov	w3, #0x1                   	// #1
    971c:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9720:	f81f03bf 	stur	xzr, [x29, #-16]
    9724:	97fffaef 	bl	82e0 <fwp_write>
    9728:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    972c:	90000020 	adrp	x0, d000 <__modti3+0x230>
    9730:	912da000 	add	x0, x0, #0xb68
    9734:	f10002df 	cmp	x22, #0x0
    9738:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    973c:	b1002b3f 	cmn	x25, #0xa
    9740:	540039c8 	b.hi	9e78 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    9744:	91002720 	add	x0, x25, #0x9
    9748:	52800021 	mov	w1, #0x1                   	// #1
    974c:	97ffed3d 	bl	4c40 <fwp_heap_alloc>
    9750:	aa0003f3 	mov	x19, x0
    9754:	aa1603e1 	mov	x1, x22
    9758:	aa0003f6 	mov	x22, x0
    975c:	aa1903e2 	mov	x2, x25
    9760:	f80086d9 	str	x25, [x22], #8
    9764:	8b190279 	add	x25, x19, x25
    9768:	aa1603e0 	mov	x0, x22
    976c:	97ffe3b5 	bl	2640 <memcpy@plt>
    9770:	3900233f 	strb	wzr, [x25, #8]
    9774:	f85e03a0 	ldur	x0, [x29, #-32]
    9778:	97ffe44e 	bl	28b0 <free@plt>
    977c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9780:	9115c002 	add	x2, x0, #0x570
    9784:	f949d841 	ldr	x1, [x2, #5040]
    9788:	f949ec40 	ldr	x0, [x2, #5080]
    978c:	cb010261 	sub	x1, x19, x1
    9790:	eb00403f 	cmp	x1, x0, lsl #16
    9794:	54000322 	b.cs	97f8 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9798:	d350fc20 	lsr	x0, x1, #16
    979c:	f949fc43 	ldr	x3, [x2, #5112]
    97a0:	8b000800 	add	x0, x0, x0, lsl #2
    97a4:	d37df002 	lsl	x2, x0, #3
    97a8:	8b020060 	add	x0, x3, x2
    97ac:	f9401019 	ldr	x25, [x0, #32]
    97b0:	b4000259 	cbz	x25, 97f8 <fwp_hof0.constprop.0+0x528>
    97b4:	38626862 	ldrb	w2, [x3, x2]
    97b8:	7100085f 	cmp	w2, #0x2
    97bc:	54003220 	b.eq	9e00 <fwp_hof0.constprop.0+0xb30>  // b.none
    97c0:	7100045f 	cmp	w2, #0x1
    97c4:	540001a1 	b.ne	97f8 <fwp_hof0.constprop.0+0x528>  // b.any
    97c8:	29430002 	ldp	w2, w0, [x0, #24]
    97cc:	92403c21 	and	x1, x1, #0xffff
    97d0:	9b027c21 	mul	x1, x1, x2
    97d4:	d360fc21 	lsr	x1, x1, #32
    97d8:	eb00003f 	cmp	x1, x0
    97dc:	540000e2 	b.cs	97f8 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    97e0:	8b010339 	add	x25, x25, x1
    97e4:	39400320 	ldrb	w0, [x25]
    97e8:	7103fc1f 	cmp	w0, #0xff
    97ec:	54003520 	b.eq	9e90 <fwp_hof0.constprop.0+0xbc0>  // b.none
    97f0:	52800020 	mov	w0, #0x1                   	// #1
    97f4:	39000320 	strb	w0, [x25]
    97f8:	aa1b03e0 	mov	x0, x27
    97fc:	97fff0d9 	bl	5b60 <fwp_drop0>
    9800:	f00000a0 	adrp	x0, 20000 <__data_start>
    9804:	91010003 	add	x3, x0, #0x40
    9808:	f9400262 	ldr	x2, [x19]
    980c:	aa1603e0 	mov	x0, x22
    9810:	aa0303f6 	mov	x22, x3
    9814:	d2800021 	mov	x1, #0x1                   	// #1
    9818:	f9400463 	ldr	x3, [x3, #8]
    981c:	97ffe435 	bl	28f0 <fwrite@plt>
    9820:	f94006c1 	ldr	x1, [x22, #8]
    9824:	52800140 	mov	w0, #0xa                   	// #10
    9828:	97ffe3ba 	bl	2710 <fputc@plt>
    982c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9830:	9115c002 	add	x2, x0, #0x570
    9834:	f949d841 	ldr	x1, [x2, #5040]
    9838:	f949ec40 	ldr	x0, [x2, #5080]
    983c:	cb010261 	sub	x1, x19, x1
    9840:	eb00403f 	cmp	x1, x0, lsl #16
    9844:	54000382 	b.cs	98b4 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9848:	d350fc20 	lsr	x0, x1, #16
    984c:	f949fc43 	ldr	x3, [x2, #5112]
    9850:	8b000800 	add	x0, x0, x0, lsl #2
    9854:	d37df000 	lsl	x0, x0, #3
    9858:	8b000062 	add	x2, x3, x0
    985c:	f9401056 	ldr	x22, [x2, #32]
    9860:	b40002b6 	cbz	x22, 98b4 <fwp_hof0.constprop.0+0x5e4>
    9864:	38606860 	ldrb	w0, [x3, x0]
    9868:	7100081f 	cmp	w0, #0x2
    986c:	54002c40 	b.eq	9df4 <fwp_hof0.constprop.0+0xb24>  // b.none
    9870:	7100041f 	cmp	w0, #0x1
    9874:	54000201 	b.ne	98b4 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9878:	29430043 	ldp	w3, w0, [x2, #24]
    987c:	92403c21 	and	x1, x1, #0xffff
    9880:	9b037c21 	mul	x1, x1, x3
    9884:	d360fc21 	lsr	x1, x1, #32
    9888:	eb00003f 	cmp	x1, x0
    988c:	54000142 	b.cs	98b4 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9890:	8b0102d6 	add	x22, x22, x1
    9894:	394002c0 	ldrb	w0, [x22]
    9898:	340000e0 	cbz	w0, 98b4 <fwp_hof0.constprop.0+0x5e4>
    989c:	7100041f 	cmp	w0, #0x1
    98a0:	54002a00 	b.eq	9de0 <fwp_hof0.constprop.0+0xb10>  // b.none
    98a4:	7103fc1f 	cmp	w0, #0xff
    98a8:	54002b20 	b.eq	9e0c <fwp_hof0.constprop.0+0xb3c>  // b.none
    98ac:	51000400 	sub	w0, w0, #0x1
    98b0:	390002c0 	strb	w0, [x22]
    98b4:	f9400b5a 	ldr	x26, [x26, #16]
    98b8:	b5ffd3ba 	cbnz	x26, 932c <fwp_hof0.constprop.0+0x5c>
    98bc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    98c0:	f947f400 	ldr	x0, [x0, #4072]
    98c4:	f85f83a2 	ldur	x2, [x29, #-8]
    98c8:	f9400001 	ldr	x1, [x0]
    98cc:	eb010042 	subs	x2, x2, x1
    98d0:	d2800001 	mov	x1, #0x0                   	// #0
    98d4:	54002dc1 	b.ne	9e8c <fwp_hof0.constprop.0+0xbbc>  // b.any
    98d8:	910003bf 	mov	sp, x29
    98dc:	d2800000 	mov	x0, #0x0                   	// #0
    98e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    98e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    98e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    98ec:	a9446bf9 	ldp	x25, x26, [sp, #64]
    98f0:	a94573fb 	ldp	x27, x28, [sp, #80]
    98f4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    98f8:	d65f03c0 	ret
    98fc:	b90004df 	str	wzr, [x6, #4]
    9900:	17ffff69 	b	96a4 <fwp_hof0.constprop.0+0x3d4>
    9904:	72003c3f 	tst	w1, #0xffff
    9908:	54ffec61 	b.ne	9694 <fwp_hof0.constprop.0+0x3c4>  // b.any
    990c:	17ffff5f 	b	9688 <fwp_hof0.constprop.0+0x3b8>
    9910:	aa1b03fc 	mov	x28, x27
    9914:	aa1803fb 	mov	x27, x24
    9918:	29771fb7 	ldp	w23, w7, [x29, #-72]
    991c:	b85c03b8 	ldur	w24, [x29, #-64]
    9920:	aa1c03e0 	mov	x0, x28
    9924:	b81d83a7 	stur	w7, [x29, #-40]
    9928:	97ffef0e 	bl	5560 <fwp_rc_share>
    992c:	b85d83a7 	ldur	w7, [x29, #-40]
    9930:	34000134 	cbz	w20, 9954 <fwp_hof0.constprop.0+0x684>
    9934:	aa1b03f6 	mov	x22, x27
    9938:	8b344f73 	add	x19, x27, w20, uxtw #3
    993c:	2a0703f9 	mov	w25, w7
    9940:	f84086c0 	ldr	x0, [x22], #8
    9944:	97ffef07 	bl	5560 <fwp_rc_share>
    9948:	eb16027f 	cmp	x19, x22
    994c:	54ffffa1 	b.ne	9940 <fwp_hof0.constprop.0+0x670>  // b.any
    9950:	2a1903e7 	mov	w7, w25
    9954:	aa1b03e2 	mov	x2, x27
    9958:	2a1403e1 	mov	w1, w20
    995c:	aa1c03e0 	mov	x0, x28
    9960:	b81d83a7 	stur	w7, [x29, #-40]
    9964:	97ffecfc 	bl	4d54 <fwp_apply>
    9968:	aa0003f9 	mov	x25, x0
    996c:	b85d83a7 	ldur	w7, [x29, #-40]
    9970:	6b17031f 	cmp	w24, w23
    9974:	54ffeb82 	b.cs	96e4 <fwp_hof0.constprop.0+0x414>  // b.hs, b.nlast
    9978:	f9401ea1 	ldr	x1, [x21, #56]
    997c:	4b0702f7 	sub	w23, w23, w7
    9980:	b9400323 	ldr	w3, [x25]
    9984:	f85d03a0 	ldur	x0, [x29, #-48]
    9988:	8b031423 	add	x3, x1, x3, lsl #5
    998c:	b85c83a2 	ldur	w2, [x29, #-56]
    9990:	8b274c00 	add	x0, x0, w7, uxtw #3
    9994:	f81d03a0 	stur	x0, [x29, #-48]
    9998:	f9400c61 	ldr	x1, [x3, #24]
    999c:	b85cc3a0 	ldur	w0, [x29, #-52]
    99a0:	4b020000 	sub	w0, w0, w2
    99a4:	b81cc3a0 	stur	w0, [x29, #-52]
    99a8:	aa1903e0 	mov	x0, x25
    99ac:	b5ffd761 	cbnz	x1, 9498 <fwp_hof0.constprop.0+0x1c8>
    99b0:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    99b4:	aa1903e0 	mov	x0, x25
    99b8:	97ffeeea 	bl	5560 <fwp_rc_share>
    99bc:	34000117 	cbz	w23, 99dc <fwp_hof0.constprop.0+0x70c>
    99c0:	f85d03b8 	ldur	x24, [x29, #-48]
    99c4:	d2800016 	mov	x22, #0x0                   	// #0
    99c8:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    99cc:	910006d6 	add	x22, x22, #0x1
    99d0:	97ffeee4 	bl	5560 <fwp_rc_share>
    99d4:	6b1602ff 	cmp	w23, w22
    99d8:	54ffff88 	b.hi	99c8 <fwp_hof0.constprop.0+0x6f8>  // b.pmore
    99dc:	f85d03a2 	ldur	x2, [x29, #-48]
    99e0:	aa1903e0 	mov	x0, x25
    99e4:	2a1703e1 	mov	w1, w23
    99e8:	97ffecdb 	bl	4d54 <fwp_apply>
    99ec:	aa0003f9 	mov	x25, x0
    99f0:	f85983a0 	ldur	x0, [x29, #-104]
    99f4:	f1000400 	subs	x0, x0, #0x1
    99f8:	f81983a0 	stur	x0, [x29, #-104]
    99fc:	54ffce21 	b.ne	93c0 <fwp_hof0.constprop.0+0xf0>  // b.any
    9a00:	17ffff3e 	b	96f8 <fwp_hof0.constprop.0+0x428>
    9a04:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9a08:	9115c00a 	add	x10, x0, #0x570
    9a0c:	2a0103fc 	mov	w28, w1
    9a10:	110006c0 	add	w0, w22, #0x1
    9a14:	f120001f 	cmp	x0, #0x800
    9a18:	aa1703fa 	mov	x26, x23
    9a1c:	b953a541 	ldr	w1, [x10, #5028]
    9a20:	aa1803fb 	mov	x27, x24
    9a24:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9a28:	d37df000 	lsl	x0, x0, #3
    9a2c:	b85c03b8 	ldur	w24, [x29, #-64]
    9a30:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9a34:	54001860 	b.eq	9d40 <fwp_hof0.constprop.0+0xa70>  // b.none
    9a38:	91003c01 	add	x1, x0, #0xf
    9a3c:	8b411141 	add	x1, x10, x1, lsr #4
    9a40:	397e8021 	ldrb	w1, [x1, #4000]
    9a44:	910f002b 	add	x11, x1, #0x3c0
    9a48:	8b010429 	add	x9, x1, x1, lsl #1
    9a4c:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    9a50:	8b090d4c 	add	x12, x10, x9, lsl #3
    9a54:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    9a58:	2a0b03e1 	mov	w1, w11
    9a5c:	b4001613 	cbz	x19, 9d1c <fwp_hof0.constprop.0+0xa4c>
    9a60:	f940026c 	ldr	x12, [x19]
    9a64:	aa2c03ec 	mvn	x12, x12
    9a68:	f829794c 	str	x12, [x10, x9, lsl #3]
    9a6c:	eb01001f 	cmp	x0, x1
    9a70:	540000c2 	b.cs	9a88 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    9a74:	d503201f 	nop
    9a78:	f8206a7f 	str	xzr, [x19, x0]
    9a7c:	91002000 	add	x0, x0, #0x8
    9a80:	eb00003f 	cmp	x1, x0
    9a84:	54ffffa8 	b.hi	9a78 <fwp_hof0.constprop.0+0x7a8>  // b.pmore
    9a88:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9a8c:	9115c009 	add	x9, x0, #0x570
    9a90:	f94a1120 	ldr	x0, [x9, #5152]
    9a94:	ab010000 	adds	x0, x0, x1
    9a98:	54001e82 	b.cs	9e68 <fwp_hof0.constprop.0+0xb98>  // b.hs, b.nlast
    9a9c:	f94a1521 	ldr	x1, [x9, #5160]
    9aa0:	f90a1120 	str	x0, [x9, #5152]
    9aa4:	eb01001f 	cmp	x0, x1
    9aa8:	54000049 	b.ls	9ab0 <fwp_hof0.constprop.0+0x7e0>  // b.plast
    9aac:	f90a1520 	str	x0, [x9, #5160]
    9ab0:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9ab4:	9115c000 	add	x0, x0, #0x570
    9ab8:	1e630161 	ucvtf	d1, w11
    9abc:	fd4a1c00 	ldr	d0, [x0, #5176]
    9ac0:	1e612800 	fadd	d0, d0, d1
    9ac4:	fd0a1c00 	str	d0, [x0, #5176]
    9ac8:	b94000c0 	ldr	w0, [x6]
    9acc:	29005a60 	stp	w0, w22, [x19]
    9ad0:	3400013c 	cbz	w28, 9af4 <fwp_hof0.constprop.0+0x824>
    9ad4:	910020c1 	add	x1, x6, #0x8
    9ad8:	d37d7f82 	ubfiz	x2, x28, #3, #32
    9adc:	91002260 	add	x0, x19, #0x8
    9ae0:	b81c03a7 	stur	w7, [x29, #-64]
    9ae4:	f81d83a6 	stur	x6, [x29, #-40]
    9ae8:	97ffe2de 	bl	2660 <memmove@plt>
    9aec:	f85d83a6 	ldur	x6, [x29, #-40]
    9af0:	b85c03a7 	ldur	w7, [x29, #-64]
    9af4:	2a1403e9 	mov	w9, w20
    9af8:	d2800001 	mov	x1, #0x0                   	// #0
    9afc:	34000114 	cbz	w20, 9b1c <fwp_hof0.constprop.0+0x84c>
    9b00:	0b010380 	add	w0, w28, w1
    9b04:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9b08:	8b000e60 	add	x0, x19, x0, lsl #3
    9b0c:	91000421 	add	x1, x1, #0x1
    9b10:	f9000402 	str	x2, [x0, #8]
    9b14:	eb01013f 	cmp	x9, x1
    9b18:	54ffff41 	b.ne	9b00 <fwp_hof0.constprop.0+0x830>  // b.any
    9b1c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9b20:	9115c002 	add	x2, x0, #0x570
    9b24:	f949d840 	ldr	x0, [x2, #5040]
    9b28:	f949ec41 	ldr	x1, [x2, #5080]
    9b2c:	cb000320 	sub	x0, x25, x0
    9b30:	eb01401f 	cmp	x0, x1, lsl #16
    9b34:	540002e2 	b.cs	9b90 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9b38:	d350fc01 	lsr	x1, x0, #16
    9b3c:	f949fc45 	ldr	x5, [x2, #5112]
    9b40:	8b010821 	add	x1, x1, x1, lsl #2
    9b44:	d37df021 	lsl	x1, x1, #3
    9b48:	8b0100a4 	add	x4, x5, x1
    9b4c:	f9401082 	ldr	x2, [x4, #32]
    9b50:	b4000202 	cbz	x2, 9b90 <fwp_hof0.constprop.0+0x8c0>
    9b54:	386168a1 	ldrb	w1, [x5, x1]
    9b58:	7100083f 	cmp	w1, #0x2
    9b5c:	54001020 	b.eq	9d60 <fwp_hof0.constprop.0+0xa90>  // b.none
    9b60:	7100043f 	cmp	w1, #0x1
    9b64:	54000161 	b.ne	9b90 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9b68:	29430485 	ldp	w5, w1, [x4, #24]
    9b6c:	92403c00 	and	x0, x0, #0xffff
    9b70:	9b057c00 	mul	x0, x0, x5
    9b74:	d360fc00 	lsr	x0, x0, #32
    9b78:	eb01001f 	cmp	x0, x1
    9b7c:	540000a2 	b.cs	9b90 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9b80:	8b000042 	add	x2, x2, x0
    9b84:	39400040 	ldrb	w0, [x2]
    9b88:	7100041f 	cmp	w0, #0x1
    9b8c:	54000be0 	b.eq	9d08 <fwp_hof0.constprop.0+0xa38>  // b.none
    9b90:	f9400f42 	ldr	x2, [x26, #24]
    9b94:	aa1903e0 	mov	x0, x25
    9b98:	52800021 	mov	w1, #0x1                   	// #1
    9b9c:	b81d83a7 	stur	w7, [x29, #-40]
    9ba0:	f9400442 	ldr	x2, [x2, #8]
    9ba4:	d63f0040 	blr	x2
    9ba8:	b85d83a7 	ldur	w7, [x29, #-40]
    9bac:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9bb0:	9115c002 	add	x2, x0, #0x570
    9bb4:	f949d841 	ldr	x1, [x2, #5040]
    9bb8:	f949ec40 	ldr	x0, [x2, #5080]
    9bbc:	cb010261 	sub	x1, x19, x1
    9bc0:	eb00403f 	cmp	x1, x0, lsl #16
    9bc4:	54000322 	b.cs	9c28 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9bc8:	d350fc20 	lsr	x0, x1, #16
    9bcc:	f949fc43 	ldr	x3, [x2, #5112]
    9bd0:	8b000800 	add	x0, x0, x0, lsl #2
    9bd4:	d37df002 	lsl	x2, x0, #3
    9bd8:	8b020060 	add	x0, x3, x2
    9bdc:	f9401014 	ldr	x20, [x0, #32]
    9be0:	b4000254 	cbz	x20, 9c28 <fwp_hof0.constprop.0+0x958>
    9be4:	38626862 	ldrb	w2, [x3, x2]
    9be8:	7100085f 	cmp	w2, #0x2
    9bec:	54000c00 	b.eq	9d6c <fwp_hof0.constprop.0+0xa9c>  // b.none
    9bf0:	7100045f 	cmp	w2, #0x1
    9bf4:	540001a1 	b.ne	9c28 <fwp_hof0.constprop.0+0x958>  // b.any
    9bf8:	29430002 	ldp	w2, w0, [x0, #24]
    9bfc:	92403c21 	and	x1, x1, #0xffff
    9c00:	9b027c21 	mul	x1, x1, x2
    9c04:	d360fc21 	lsr	x1, x1, #32
    9c08:	eb00003f 	cmp	x1, x0
    9c0c:	540000e2 	b.cs	9c28 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9c10:	8b010294 	add	x20, x20, x1
    9c14:	39400280 	ldrb	w0, [x20]
    9c18:	7103fc1f 	cmp	w0, #0xff
    9c1c:	54000b20 	b.eq	9d80 <fwp_hof0.constprop.0+0xab0>  // b.none
    9c20:	52800020 	mov	w0, #0x1                   	// #1
    9c24:	39000280 	strb	w0, [x20]
    9c28:	aa1903e0 	mov	x0, x25
    9c2c:	b81d83a7 	stur	w7, [x29, #-40]
    9c30:	97fff028 	bl	5cd0 <fwp_closure_drop>
    9c34:	aa1303f9 	mov	x25, x19
    9c38:	b85d83a7 	ldur	w7, [x29, #-40]
    9c3c:	17ffff4d 	b	9970 <fwp_hof0.constprop.0+0x6a0>
    9c40:	b8626860 	ldr	w0, [x3, x2]
    9c44:	b94004a2 	ldr	w2, [x5, #4]
    9c48:	4b020003 	sub	w3, w0, w2
    9c4c:	7100047f 	cmp	w3, #0x1
    9c50:	54ffbd01 	b.ne	93f0 <fwp_hof0.constprop.0+0x120>  // b.any
    9c54:	910003f6 	mov	x22, sp
    9c58:	34000a22 	cbz	w2, 9d9c <fwp_hof0.constprop.0+0xacc>
    9c5c:	7100001f 	cmp	w0, #0x0
    9c60:	d37d7c00 	ubfiz	x0, x0, #3, #32
    9c64:	d2800101 	mov	x1, #0x8                   	// #8
    9c68:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    9c6c:	91003ee0 	add	x0, x23, #0xf
    9c70:	92704c01 	and	x1, x0, #0xfffff0000
    9c74:	927c7c00 	and	x0, x0, #0xffffffff0
    9c78:	cb2163e1 	sub	x1, sp, x1
    9c7c:	eb2163ff 	cmp	sp, x1
    9c80:	540000a0 	b.eq	9c94 <fwp_hof0.constprop.0+0x9c4>  // b.none
    9c84:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9c88:	f90203ff 	str	xzr, [sp, #1024]
    9c8c:	eb2163ff 	cmp	sp, x1
    9c90:	54ffffa1 	b.ne	9c84 <fwp_hof0.constprop.0+0x9b4>  // b.any
    9c94:	92403c00 	and	x0, x0, #0xffff
    9c98:	cb2063ff 	sub	sp, sp, x0
    9c9c:	f90003ff 	str	xzr, [sp]
    9ca0:	f110001f 	cmp	x0, #0x400
    9ca4:	54000043 	b.cc	9cac <fwp_hof0.constprop.0+0x9dc>  // b.lo, b.ul, b.last
    9ca8:	f90203ff 	str	xzr, [sp, #1024]
    9cac:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    9cb0:	910043f8 	add	x24, sp, #0x10
    9cb4:	f00000a0 	adrp	x0, 20000 <__data_start>
    9cb8:	91004001 	add	x1, x0, #0x10
    9cbc:	aa1c03e2 	mov	x2, x28
    9cc0:	91004021 	add	x1, x1, #0x10
    9cc4:	aa1703e3 	mov	x3, x23
    9cc8:	aa1803e0 	mov	x0, x24
    9ccc:	97ffe29d 	bl	2740 <__memcpy_chk@plt>
    9cd0:	eb1c02ff 	cmp	x23, x28
    9cd4:	aa1403e1 	mov	x1, x20
    9cd8:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    9cdc:	d2800102 	mov	x2, #0x8                   	// #8
    9ce0:	cb1c0063 	sub	x3, x3, x28
    9ce4:	8b1c0300 	add	x0, x24, x28
    9ce8:	97ffe296 	bl	2740 <__memcpy_chk@plt>
    9cec:	f9400f61 	ldr	x1, [x27, #24]
    9cf0:	aa1803e0 	mov	x0, x24
    9cf4:	f9400021 	ldr	x1, [x1]
    9cf8:	d63f0020 	blr	x1
    9cfc:	aa0003f9 	mov	x25, x0
    9d00:	910002df 	mov	sp, x22
    9d04:	17ffff3b 	b	99f0 <fwp_hof0.constprop.0+0x720>
    9d08:	b90004df 	str	wzr, [x6, #4]
    9d0c:	17ffffa8 	b	9bac <fwp_hof0.constprop.0+0x8dc>
    9d10:	72003c3f 	tst	w1, #0xffff
    9d14:	54ffbae1 	b.ne	9470 <fwp_hof0.constprop.0+0x1a0>  // b.any
    9d18:	17fffdd0 	b	9458 <fwp_hof0.constprop.0+0x188>
    9d1c:	f9400593 	ldr	x19, [x12, #8]
    9d20:	b4000113 	cbz	x19, 9d40 <fwp_hof0.constprop.0+0xa70>
    9d24:	f9400989 	ldr	x9, [x12, #16]
    9d28:	cb130129 	sub	x9, x9, x19
    9d2c:	eb09003f 	cmp	x1, x9
    9d30:	54000088 	b.hi	9d40 <fwp_hof0.constprop.0+0xa70>  // b.pmore
    9d34:	8b010269 	add	x9, x19, x1
    9d38:	f9000589 	str	x9, [x12, #8]
    9d3c:	17ffff4c 	b	9a6c <fwp_hof0.constprop.0+0x79c>
    9d40:	52800001 	mov	w1, #0x0                   	// #0
    9d44:	f81c03a6 	stur	x6, [x29, #-64]
    9d48:	b81d83a7 	stur	w7, [x29, #-40]
    9d4c:	97ffebbd 	bl	4c40 <fwp_heap_alloc>
    9d50:	f85c03a6 	ldur	x6, [x29, #-64]
    9d54:	aa0003f3 	mov	x19, x0
    9d58:	b85d83a7 	ldur	w7, [x29, #-40]
    9d5c:	17ffff5b 	b	9ac8 <fwp_hof0.constprop.0+0x7f8>
    9d60:	72003c1f 	tst	w0, #0xffff
    9d64:	54fff161 	b.ne	9b90 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9d68:	17ffff87 	b	9b84 <fwp_hof0.constprop.0+0x8b4>
    9d6c:	72003c3f 	tst	w1, #0xffff
    9d70:	54fff5c1 	b.ne	9c28 <fwp_hof0.constprop.0+0x958>  // b.any
    9d74:	39400280 	ldrb	w0, [x20]
    9d78:	7103fc1f 	cmp	w0, #0xff
    9d7c:	54fff521 	b.ne	9c20 <fwp_hof0.constprop.0+0x950>  // b.any
    9d80:	aa1403e0 	mov	x0, x20
    9d84:	b81d83a7 	stur	w7, [x29, #-40]
    9d88:	97ffe9ee 	bl	4540 <fwp_rc_forget_slot>
    9d8c:	b85d83a7 	ldur	w7, [x29, #-40]
    9d90:	17ffffa4 	b	9c20 <fwp_hof0.constprop.0+0x950>
    9d94:	97ffe9a4 	bl	4424 <fwp_rc_wide_dup>
    9d98:	17fffdb6 	b	9470 <fwp_hof0.constprop.0+0x1a0>
    9d9c:	f9400021 	ldr	x1, [x1]
    9da0:	aa1403e0 	mov	x0, x20
    9da4:	d63f0020 	blr	x1
    9da8:	aa0003f9 	mov	x25, x0
    9dac:	910002df 	mov	sp, x22
    9db0:	17ffff10 	b	99f0 <fwp_hof0.constprop.0+0x720>
    9db4:	72003c3f 	tst	w1, #0xffff
    9db8:	54ffafa1 	b.ne	93ac <fwp_hof0.constprop.0+0xdc>  // b.any
    9dbc:	17fffd76 	b	9394 <fwp_hof0.constprop.0+0xc4>
    9dc0:	aa1a03e0 	mov	x0, x26
    9dc4:	97ffede7 	bl	5560 <fwp_rc_share>
    9dc8:	aa1903e0 	mov	x0, x25
    9dcc:	52800037 	mov	w23, #0x1                   	// #1
    9dd0:	97ffede4 	bl	5560 <fwp_rc_share>
    9dd4:	aa1a03f9 	mov	x25, x26
    9dd8:	f81d03b4 	stur	x20, [x29, #-48]
    9ddc:	17ffff00 	b	99dc <fwp_hof0.constprop.0+0x70c>
    9de0:	aa1303e0 	mov	x0, x19
    9de4:	97ffee34 	bl	56b4 <fwp_rc_free_arr>
    9de8:	f9400b5a 	ldr	x26, [x26, #16]
    9dec:	b5ffaa1a 	cbnz	x26, 932c <fwp_hof0.constprop.0+0x5c>
    9df0:	17fffeb3 	b	98bc <fwp_hof0.constprop.0+0x5ec>
    9df4:	72003c3f 	tst	w1, #0xffff
    9df8:	54ffd5e1 	b.ne	98b4 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9dfc:	17fffea6 	b	9894 <fwp_hof0.constprop.0+0x5c4>
    9e00:	72003c3f 	tst	w1, #0xffff
    9e04:	54ffcfa1 	b.ne	97f8 <fwp_hof0.constprop.0+0x528>  // b.any
    9e08:	17fffe77 	b	97e4 <fwp_hof0.constprop.0+0x514>
    9e0c:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9e10:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc70>
    9e14:	9115c021 	add	x1, x1, #0x570
    9e18:	ca402400 	eor	x0, x0, x0, lsr #9
    9e1c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9e20:	f94a2400 	ldr	x0, [x0, #5192]
    9e24:	b5000080 	cbnz	x0, 9e34 <fwp_hof0.constprop.0+0xb64>
    9e28:	14000011 	b	9e6c <fwp_hof0.constprop.0+0xb9c>
    9e2c:	f9400800 	ldr	x0, [x0, #16]
    9e30:	b40001e0 	cbz	x0, 9e6c <fwp_hof0.constprop.0+0xb9c>
    9e34:	f9400001 	ldr	x1, [x0]
    9e38:	eb0102df 	cmp	x22, x1
    9e3c:	54ffff81 	b.ne	9e2c <fwp_hof0.constprop.0+0xb5c>  // b.any
    9e40:	f9400401 	ldr	x1, [x0, #8]
    9e44:	d1000421 	sub	x1, x1, #0x1
    9e48:	f9000401 	str	x1, [x0, #8]
    9e4c:	f103f83f 	cmp	x1, #0xfe
    9e50:	54ffd321 	b.ne	98b4 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9e54:	aa1603e0 	mov	x0, x22
    9e58:	97ffe9ba 	bl	4540 <fwp_rc_forget_slot>
    9e5c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e60:	390002c0 	strb	w0, [x22]
    9e64:	17fffe94 	b	98b4 <fwp_hof0.constprop.0+0x5e4>
    9e68:	97ffe452 	bl	2fb0 <fwp_heap_oom>
    9e6c:	90000020 	adrp	x0, d000 <__modti3+0x230>
    9e70:	91106000 	add	x0, x0, #0x418
    9e74:	97ffe5a3 	bl	3500 <fwp_trap>
    9e78:	90000020 	adrp	x0, d000 <__modti3+0x230>
    9e7c:	911c4000 	add	x0, x0, #0x710
    9e80:	97ffe5a0 	bl	3500 <fwp_trap>
    9e84:	97ffe968 	bl	4424 <fwp_rc_wide_dup>
    9e88:	17fffd49 	b	93ac <fwp_hof0.constprop.0+0xdc>
    9e8c:	97ffe259 	bl	27f0 <__stack_chk_fail@plt>
    9e90:	aa1903e0 	mov	x0, x25
    9e94:	97ffe9ab 	bl	4540 <fwp_rc_forget_slot>
    9e98:	17fffe56 	b	97f0 <fwp_hof0.constprop.0+0x520>
    9e9c:	d503201f 	nop

0000000000009ea0 <f0>:
    9ea0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9ea4:	910003fd 	mov	x29, sp
    9ea8:	a90153f3 	stp	x19, x20, [sp, #16]
    9eac:	a9025bf5 	stp	x21, x22, [sp, #32]
    9eb0:	a90363f7 	stp	x23, x24, [sp, #48]
    9eb4:	a9046bf9 	stp	x25, x26, [sp, #64]
    9eb8:	a90573fb 	stp	x27, x28, [sp, #80]
    9ebc:	d12183ff 	sub	sp, sp, #0x860
    9ec0:	f90203ff 	str	xzr, [sp, #1024]
    9ec4:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ec8:	91010005 	add	x5, x0, #0x40
    9ecc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9ed0:	f947f400 	ldr	x0, [x0, #4072]
    9ed4:	90000154 	adrp	x20, 31000 <fwp_root_context+0xc70>
    9ed8:	f94170a6 	ldr	x6, [x5, #736]
    9edc:	f9400001 	ldr	x1, [x0]
    9ee0:	f9042fe1 	str	x1, [sp, #2136]
    9ee4:	d2800001 	mov	x1, #0x0                   	// #0
    9ee8:	9115c298 	add	x24, x20, #0x570
    9eec:	912123f6 	add	x22, sp, #0x848
    9ef0:	910023e0 	add	x0, sp, #0x8
    9ef4:	910083e2 	add	x2, sp, #0x20
    9ef8:	90ffffe1 	adrp	x1, 5000 <fwp_p_ad_push+0x8c>
    9efc:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9f00:	91284021 	add	x1, x1, #0xa10
    9f04:	913b4084 	add	x4, x4, #0xed0
    9f08:	d2800013 	mov	x19, #0x0                   	// #0
    9f0c:	d2800119 	mov	x25, #0x8                   	// #8
    9f10:	d2800015 	mov	x21, #0x0                   	// #0
    9f14:	52800037 	mov	w23, #0x1                   	// #1
    9f18:	a90093e6 	stp	x6, x4, [sp, #8]
    9f1c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9f20:	a90307ff 	stp	xzr, x1, [sp, #48]
    9f24:	f90170a0 	str	x0, [x5, #736]
    9f28:	f100073a 	subs	x26, x25, #0x1
    9f2c:	aa1603e1 	mov	x1, x22
    9f30:	da1f02bc 	sbc	x28, x21, xzr
    9f34:	52800020 	mov	w0, #0x1                   	// #1
    9f38:	f90017fa 	str	x26, [sp, #40]
    9f3c:	aa1a03f9 	mov	x25, x26
    9f40:	f90427fa 	str	x26, [sp, #2120]
    9f44:	aa1c03f5 	mov	x21, x28
    9f48:	f9042bf3 	str	x19, [sp, #2128]
    9f4c:	97ffed3d 	bl	5440 <fwp_data.part.0.constprop.0>
    9f50:	f949db02 	ldr	x2, [x24, #5040]
    9f54:	aa0003f3 	mov	x19, x0
    9f58:	f949ef00 	ldr	x0, [x24, #5080]
    9f5c:	cb020262 	sub	x2, x19, x2
    9f60:	eb00405f 	cmp	x2, x0, lsl #16
    9f64:	54000302 	b.cs	9fc4 <f0+0x124>  // b.hs, b.nlast
    9f68:	d350fc40 	lsr	x0, x2, #16
    9f6c:	f949ff04 	ldr	x4, [x24, #5112]
    9f70:	8b000800 	add	x0, x0, x0, lsl #2
    9f74:	d37df001 	lsl	x1, x0, #3
    9f78:	8b010080 	add	x0, x4, x1
    9f7c:	f940101b 	ldr	x27, [x0, #32]
    9f80:	b400023b 	cbz	x27, 9fc4 <f0+0x124>
    9f84:	38616881 	ldrb	w1, [x4, x1]
    9f88:	7100083f 	cmp	w1, #0x2
    9f8c:	54010e20 	b.eq	c150 <f0+0x22b0>  // b.none
    9f90:	7100043f 	cmp	w1, #0x1
    9f94:	54000181 	b.ne	9fc4 <f0+0x124>  // b.any
    9f98:	29430001 	ldp	w1, w0, [x0, #24]
    9f9c:	92403c42 	and	x2, x2, #0xffff
    9fa0:	9b017c42 	mul	x2, x2, x1
    9fa4:	d360fc42 	lsr	x2, x2, #32
    9fa8:	eb00005f 	cmp	x2, x0
    9fac:	540000c2 	b.cs	9fc4 <f0+0x124>  // b.hs, b.nlast
    9fb0:	8b02037b 	add	x27, x27, x2
    9fb4:	39400360 	ldrb	w0, [x27]
    9fb8:	7103fc1f 	cmp	w0, #0xff
    9fbc:	54010c40 	b.eq	c144 <f0+0x22a4>  // b.none
    9fc0:	39000377 	strb	w23, [x27]
    9fc4:	f90013f3 	str	x19, [sp, #32]
    9fc8:	aa1c035a 	orr	x26, x26, x28
    9fcc:	b5fffafa 	cbnz	x26, 9f28 <f0+0x88>
    9fd0:	90000023 	adrp	x3, d000 <__modti3+0x230>
    9fd4:	910103e1 	add	x1, sp, #0x40
    9fd8:	f94007e2 	ldr	x2, [sp, #8]
    9fdc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9fe0:	3dc38c60 	ldr	q0, [x3, #3632]
    9fe4:	91010018 	add	x24, x0, #0x40
    9fe8:	52800020 	mov	w0, #0x1                   	// #1
    9fec:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9ff0:	3d8013e0 	str	q0, [sp, #64]
    9ff4:	f9017302 	str	x2, [x24, #736]
    9ff8:	97ffed12 	bl	5440 <fwp_data.part.0.constprop.0>
    9ffc:	97ffed7e 	bl	55f4 <fwp_rc_fresh>
    a000:	aa0003e2 	mov	x2, x0
    a004:	910163e1 	add	x1, sp, #0x58
    a008:	52800020 	mov	w0, #0x1                   	// #1
    a00c:	a9058bf5 	stp	x21, x2, [sp, #88]
    a010:	97ffed0c 	bl	5440 <fwp_data.part.0.constprop.0>
    a014:	97ffed78 	bl	55f4 <fwp_rc_fresh>
    a018:	aa0003e2 	mov	x2, x0
    a01c:	9101a3e1 	add	x1, sp, #0x68
    a020:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a024:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a028:	52800020 	mov	w0, #0x1                   	// #1
    a02c:	a9068be3 	stp	x3, x2, [sp, #104]
    a030:	97ffed04 	bl	5440 <fwp_data.part.0.constprop.0>
    a034:	97ffed70 	bl	55f4 <fwp_rc_fresh>
    a038:	aa0003e2 	mov	x2, x0
    a03c:	9101e3e1 	add	x1, sp, #0x78
    a040:	52800020 	mov	w0, #0x1                   	// #1
    a044:	a9078bf5 	stp	x21, x2, [sp, #120]
    a048:	97ffecfe 	bl	5440 <fwp_data.part.0.constprop.0>
    a04c:	97ffed6a 	bl	55f4 <fwp_rc_fresh>
    a050:	aa0003e2 	mov	x2, x0
    a054:	910223e1 	add	x1, sp, #0x88
    a058:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a05c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a060:	52800020 	mov	w0, #0x1                   	// #1
    a064:	a9088be3 	stp	x3, x2, [sp, #136]
    a068:	97ffecf6 	bl	5440 <fwp_data.part.0.constprop.0>
    a06c:	97ffed62 	bl	55f4 <fwp_rc_fresh>
    a070:	aa0003e2 	mov	x2, x0
    a074:	910263e1 	add	x1, sp, #0x98
    a078:	52800020 	mov	w0, #0x1                   	// #1
    a07c:	a9098bf5 	stp	x21, x2, [sp, #152]
    a080:	97ffecf0 	bl	5440 <fwp_data.part.0.constprop.0>
    a084:	97ffed5c 	bl	55f4 <fwp_rc_fresh>
    a088:	aa0003e2 	mov	x2, x0
    a08c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a090:	9102a3e1 	add	x1, sp, #0xa8
    a094:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a098:	52800020 	mov	w0, #0x1                   	// #1
    a09c:	a90a8be3 	stp	x3, x2, [sp, #168]
    a0a0:	97ffece8 	bl	5440 <fwp_data.part.0.constprop.0>
    a0a4:	97ffed54 	bl	55f4 <fwp_rc_fresh>
    a0a8:	aa0003e2 	mov	x2, x0
    a0ac:	9102e3e1 	add	x1, sp, #0xb8
    a0b0:	52800020 	mov	w0, #0x1                   	// #1
    a0b4:	a90b8bf5 	stp	x21, x2, [sp, #184]
    a0b8:	97ffece2 	bl	5440 <fwp_data.part.0.constprop.0>
    a0bc:	9115c283 	add	x3, x20, #0x570
    a0c0:	aa0003f5 	mov	x21, x0
    a0c4:	f949d861 	ldr	x1, [x3, #5040]
    a0c8:	f949ec60 	ldr	x0, [x3, #5080]
    a0cc:	cb0102a1 	sub	x1, x21, x1
    a0d0:	eb00403f 	cmp	x1, x0, lsl #16
    a0d4:	54000322 	b.cs	a138 <f0+0x298>  // b.hs, b.nlast
    a0d8:	d350fc22 	lsr	x2, x1, #16
    a0dc:	f949fc63 	ldr	x3, [x3, #5112]
    a0e0:	8b020842 	add	x2, x2, x2, lsl #2
    a0e4:	d37df042 	lsl	x2, x2, #3
    a0e8:	8b020060 	add	x0, x3, x2
    a0ec:	f9401017 	ldr	x23, [x0, #32]
    a0f0:	b4000257 	cbz	x23, a138 <f0+0x298>
    a0f4:	38626862 	ldrb	w2, [x3, x2]
    a0f8:	7100085f 	cmp	w2, #0x2
    a0fc:	540106c0 	b.eq	c1d4 <f0+0x2334>  // b.none
    a100:	7100045f 	cmp	w2, #0x1
    a104:	540001a1 	b.ne	a138 <f0+0x298>  // b.any
    a108:	29430002 	ldp	w2, w0, [x0, #24]
    a10c:	92403c21 	and	x1, x1, #0xffff
    a110:	9b027c21 	mul	x1, x1, x2
    a114:	d360fc21 	lsr	x1, x1, #32
    a118:	eb00003f 	cmp	x1, x0
    a11c:	540000e2 	b.cs	a138 <f0+0x298>  // b.hs, b.nlast
    a120:	8b0102f7 	add	x23, x23, x1
    a124:	394002e0 	ldrb	w0, [x23]
    a128:	7103fc1f 	cmp	w0, #0xff
    a12c:	54011080 	b.eq	c33c <f0+0x249c>  // b.none
    a130:	52800020 	mov	w0, #0x1                   	// #1
    a134:	390002e0 	strb	w0, [x23]
    a138:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a13c:	910323e1 	add	x1, sp, #0xc8
    a140:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a144:	52800020 	mov	w0, #0x1                   	// #1
    a148:	a90cd7e2 	stp	x2, x21, [sp, #200]
    a14c:	97ffecbd 	bl	5440 <fwp_data.part.0.constprop.0>
    a150:	9115c283 	add	x3, x20, #0x570
    a154:	aa0003f5 	mov	x21, x0
    a158:	f949d861 	ldr	x1, [x3, #5040]
    a15c:	f949ec60 	ldr	x0, [x3, #5080]
    a160:	cb0102a1 	sub	x1, x21, x1
    a164:	eb00403f 	cmp	x1, x0, lsl #16
    a168:	54000322 	b.cs	a1cc <f0+0x32c>  // b.hs, b.nlast
    a16c:	d350fc22 	lsr	x2, x1, #16
    a170:	f949fc63 	ldr	x3, [x3, #5112]
    a174:	8b020842 	add	x2, x2, x2, lsl #2
    a178:	d37df042 	lsl	x2, x2, #3
    a17c:	8b020060 	add	x0, x3, x2
    a180:	f9401017 	ldr	x23, [x0, #32]
    a184:	b4000257 	cbz	x23, a1cc <f0+0x32c>
    a188:	38626862 	ldrb	w2, [x3, x2]
    a18c:	7100085f 	cmp	w2, #0x2
    a190:	540101c0 	b.eq	c1c8 <f0+0x2328>  // b.none
    a194:	7100045f 	cmp	w2, #0x1
    a198:	540001a1 	b.ne	a1cc <f0+0x32c>  // b.any
    a19c:	29430002 	ldp	w2, w0, [x0, #24]
    a1a0:	92403c21 	and	x1, x1, #0xffff
    a1a4:	9b027c21 	mul	x1, x1, x2
    a1a8:	d360fc21 	lsr	x1, x1, #32
    a1ac:	eb00003f 	cmp	x1, x0
    a1b0:	540000e2 	b.cs	a1cc <f0+0x32c>  // b.hs, b.nlast
    a1b4:	8b0102f7 	add	x23, x23, x1
    a1b8:	394002e0 	ldrb	w0, [x23]
    a1bc:	7103fc1f 	cmp	w0, #0xff
    a1c0:	54010c40 	b.eq	c348 <f0+0x24a8>  // b.none
    a1c4:	52800020 	mov	w0, #0x1                   	// #1
    a1c8:	390002e0 	strb	w0, [x23]
    a1cc:	910363e1 	add	x1, sp, #0xd8
    a1d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a1d4:	52800020 	mov	w0, #0x1                   	// #1
    a1d8:	a90dd7e2 	stp	x2, x21, [sp, #216]
    a1dc:	97ffec99 	bl	5440 <fwp_data.part.0.constprop.0>
    a1e0:	97ffed05 	bl	55f4 <fwp_rc_fresh>
    a1e4:	aa0003e2 	mov	x2, x0
    a1e8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a1ec:	9103a3e1 	add	x1, sp, #0xe8
    a1f0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a1f4:	52800020 	mov	w0, #0x1                   	// #1
    a1f8:	a90e8be3 	stp	x3, x2, [sp, #232]
    a1fc:	97ffec91 	bl	5440 <fwp_data.part.0.constprop.0>
    a200:	9115c283 	add	x3, x20, #0x570
    a204:	aa0003f5 	mov	x21, x0
    a208:	f949d861 	ldr	x1, [x3, #5040]
    a20c:	f949ec60 	ldr	x0, [x3, #5080]
    a210:	cb0102a1 	sub	x1, x21, x1
    a214:	eb00403f 	cmp	x1, x0, lsl #16
    a218:	54000322 	b.cs	a27c <f0+0x3dc>  // b.hs, b.nlast
    a21c:	d350fc22 	lsr	x2, x1, #16
    a220:	f949fc63 	ldr	x3, [x3, #5112]
    a224:	8b020842 	add	x2, x2, x2, lsl #2
    a228:	d37df042 	lsl	x2, x2, #3
    a22c:	8b020060 	add	x0, x3, x2
    a230:	f9401017 	ldr	x23, [x0, #32]
    a234:	b4000257 	cbz	x23, a27c <f0+0x3dc>
    a238:	38626862 	ldrb	w2, [x3, x2]
    a23c:	7100085f 	cmp	w2, #0x2
    a240:	5400fbe0 	b.eq	c1bc <f0+0x231c>  // b.none
    a244:	7100045f 	cmp	w2, #0x1
    a248:	540001a1 	b.ne	a27c <f0+0x3dc>  // b.any
    a24c:	29430002 	ldp	w2, w0, [x0, #24]
    a250:	92403c21 	and	x1, x1, #0xffff
    a254:	9b027c21 	mul	x1, x1, x2
    a258:	d360fc21 	lsr	x1, x1, #32
    a25c:	eb00003f 	cmp	x1, x0
    a260:	540000e2 	b.cs	a27c <f0+0x3dc>  // b.hs, b.nlast
    a264:	8b0102f7 	add	x23, x23, x1
    a268:	394002e0 	ldrb	w0, [x23]
    a26c:	7103fc1f 	cmp	w0, #0xff
    a270:	54010720 	b.eq	c354 <f0+0x24b4>  // b.none
    a274:	52800020 	mov	w0, #0x1                   	// #1
    a278:	390002e0 	strb	w0, [x23]
    a27c:	9103e3e1 	add	x1, sp, #0xf8
    a280:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a284:	52800020 	mov	w0, #0x1                   	// #1
    a288:	a90fd7f7 	stp	x23, x21, [sp, #248]
    a28c:	97ffec6d 	bl	5440 <fwp_data.part.0.constprop.0>
    a290:	97ffecd9 	bl	55f4 <fwp_rc_fresh>
    a294:	aa0003e2 	mov	x2, x0
    a298:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a29c:	910423e1 	add	x1, sp, #0x108
    a2a0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a2a4:	52800020 	mov	w0, #0x1                   	// #1
    a2a8:	a9108be3 	stp	x3, x2, [sp, #264]
    a2ac:	97ffec65 	bl	5440 <fwp_data.part.0.constprop.0>
    a2b0:	97ffecd1 	bl	55f4 <fwp_rc_fresh>
    a2b4:	aa0003e2 	mov	x2, x0
    a2b8:	910463e1 	add	x1, sp, #0x118
    a2bc:	52800020 	mov	w0, #0x1                   	// #1
    a2c0:	a9118bf7 	stp	x23, x2, [sp, #280]
    a2c4:	97ffec5f 	bl	5440 <fwp_data.part.0.constprop.0>
    a2c8:	9115c283 	add	x3, x20, #0x570
    a2cc:	aa0003f5 	mov	x21, x0
    a2d0:	f949d861 	ldr	x1, [x3, #5040]
    a2d4:	f949ec60 	ldr	x0, [x3, #5080]
    a2d8:	cb0102a1 	sub	x1, x21, x1
    a2dc:	eb00403f 	cmp	x1, x0, lsl #16
    a2e0:	54000322 	b.cs	a344 <f0+0x4a4>  // b.hs, b.nlast
    a2e4:	d350fc22 	lsr	x2, x1, #16
    a2e8:	f949fc63 	ldr	x3, [x3, #5112]
    a2ec:	8b020842 	add	x2, x2, x2, lsl #2
    a2f0:	d37df042 	lsl	x2, x2, #3
    a2f4:	8b020060 	add	x0, x3, x2
    a2f8:	f9401017 	ldr	x23, [x0, #32]
    a2fc:	b4000257 	cbz	x23, a344 <f0+0x4a4>
    a300:	38626862 	ldrb	w2, [x3, x2]
    a304:	7100085f 	cmp	w2, #0x2
    a308:	5400f7e0 	b.eq	c204 <f0+0x2364>  // b.none
    a30c:	7100045f 	cmp	w2, #0x1
    a310:	540001a1 	b.ne	a344 <f0+0x4a4>  // b.any
    a314:	29430002 	ldp	w2, w0, [x0, #24]
    a318:	92403c21 	and	x1, x1, #0xffff
    a31c:	9b027c21 	mul	x1, x1, x2
    a320:	d360fc21 	lsr	x1, x1, #32
    a324:	eb00003f 	cmp	x1, x0
    a328:	540000e2 	b.cs	a344 <f0+0x4a4>  // b.hs, b.nlast
    a32c:	8b0102f7 	add	x23, x23, x1
    a330:	394002e0 	ldrb	w0, [x23]
    a334:	7103fc1f 	cmp	w0, #0xff
    a338:	54010140 	b.eq	c360 <f0+0x24c0>  // b.none
    a33c:	52800020 	mov	w0, #0x1                   	// #1
    a340:	390002e0 	strb	w0, [x23]
    a344:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a348:	9104a3e1 	add	x1, sp, #0x128
    a34c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a350:	52800020 	mov	w0, #0x1                   	// #1
    a354:	a912d7e2 	stp	x2, x21, [sp, #296]
    a358:	97ffec3a 	bl	5440 <fwp_data.part.0.constprop.0>
    a35c:	9115c283 	add	x3, x20, #0x570
    a360:	aa0003f5 	mov	x21, x0
    a364:	f949d861 	ldr	x1, [x3, #5040]
    a368:	f949ec60 	ldr	x0, [x3, #5080]
    a36c:	cb0102a1 	sub	x1, x21, x1
    a370:	eb00403f 	cmp	x1, x0, lsl #16
    a374:	54000322 	b.cs	a3d8 <f0+0x538>  // b.hs, b.nlast
    a378:	d350fc22 	lsr	x2, x1, #16
    a37c:	f949fc63 	ldr	x3, [x3, #5112]
    a380:	8b020842 	add	x2, x2, x2, lsl #2
    a384:	d37df042 	lsl	x2, x2, #3
    a388:	8b020060 	add	x0, x3, x2
    a38c:	f9401017 	ldr	x23, [x0, #32]
    a390:	b4000257 	cbz	x23, a3d8 <f0+0x538>
    a394:	38626862 	ldrb	w2, [x3, x2]
    a398:	7100085f 	cmp	w2, #0x2
    a39c:	5400f2e0 	b.eq	c1f8 <f0+0x2358>  // b.none
    a3a0:	7100045f 	cmp	w2, #0x1
    a3a4:	540001a1 	b.ne	a3d8 <f0+0x538>  // b.any
    a3a8:	29430002 	ldp	w2, w0, [x0, #24]
    a3ac:	92403c21 	and	x1, x1, #0xffff
    a3b0:	9b027c21 	mul	x1, x1, x2
    a3b4:	d360fc21 	lsr	x1, x1, #32
    a3b8:	eb00003f 	cmp	x1, x0
    a3bc:	540000e2 	b.cs	a3d8 <f0+0x538>  // b.hs, b.nlast
    a3c0:	8b0102f7 	add	x23, x23, x1
    a3c4:	394002e0 	ldrb	w0, [x23]
    a3c8:	7103fc1f 	cmp	w0, #0xff
    a3cc:	5400fd00 	b.eq	c36c <f0+0x24cc>  // b.none
    a3d0:	52800020 	mov	w0, #0x1                   	// #1
    a3d4:	390002e0 	strb	w0, [x23]
    a3d8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a3dc:	9104e3e1 	add	x1, sp, #0x138
    a3e0:	52800020 	mov	w0, #0x1                   	// #1
    a3e4:	a913d7e2 	stp	x2, x21, [sp, #312]
    a3e8:	97ffec16 	bl	5440 <fwp_data.part.0.constprop.0>
    a3ec:	9115c283 	add	x3, x20, #0x570
    a3f0:	aa0003f5 	mov	x21, x0
    a3f4:	f949d861 	ldr	x1, [x3, #5040]
    a3f8:	f949ec60 	ldr	x0, [x3, #5080]
    a3fc:	cb0102a1 	sub	x1, x21, x1
    a400:	eb00403f 	cmp	x1, x0, lsl #16
    a404:	54000322 	b.cs	a468 <f0+0x5c8>  // b.hs, b.nlast
    a408:	d350fc22 	lsr	x2, x1, #16
    a40c:	f949fc63 	ldr	x3, [x3, #5112]
    a410:	8b020842 	add	x2, x2, x2, lsl #2
    a414:	d37df042 	lsl	x2, x2, #3
    a418:	8b020060 	add	x0, x3, x2
    a41c:	f9401017 	ldr	x23, [x0, #32]
    a420:	b4000257 	cbz	x23, a468 <f0+0x5c8>
    a424:	38626862 	ldrb	w2, [x3, x2]
    a428:	7100085f 	cmp	w2, #0x2
    a42c:	5400ee00 	b.eq	c1ec <f0+0x234c>  // b.none
    a430:	7100045f 	cmp	w2, #0x1
    a434:	540001a1 	b.ne	a468 <f0+0x5c8>  // b.any
    a438:	29430002 	ldp	w2, w0, [x0, #24]
    a43c:	92403c21 	and	x1, x1, #0xffff
    a440:	9b027c21 	mul	x1, x1, x2
    a444:	d360fc21 	lsr	x1, x1, #32
    a448:	eb00003f 	cmp	x1, x0
    a44c:	540000e2 	b.cs	a468 <f0+0x5c8>  // b.hs, b.nlast
    a450:	8b0102f7 	add	x23, x23, x1
    a454:	394002e0 	ldrb	w0, [x23]
    a458:	7103fc1f 	cmp	w0, #0xff
    a45c:	5400f8e0 	b.eq	c378 <f0+0x24d8>  // b.none
    a460:	52800020 	mov	w0, #0x1                   	// #1
    a464:	390002e0 	strb	w0, [x23]
    a468:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a46c:	910523e1 	add	x1, sp, #0x148
    a470:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a474:	52800020 	mov	w0, #0x1                   	// #1
    a478:	a914d7e2 	stp	x2, x21, [sp, #328]
    a47c:	97ffebf1 	bl	5440 <fwp_data.part.0.constprop.0>
    a480:	9115c283 	add	x3, x20, #0x570
    a484:	aa0003f5 	mov	x21, x0
    a488:	f949d861 	ldr	x1, [x3, #5040]
    a48c:	f949ec60 	ldr	x0, [x3, #5080]
    a490:	cb0102a1 	sub	x1, x21, x1
    a494:	eb00403f 	cmp	x1, x0, lsl #16
    a498:	54000322 	b.cs	a4fc <f0+0x65c>  // b.hs, b.nlast
    a49c:	d350fc22 	lsr	x2, x1, #16
    a4a0:	f949fc63 	ldr	x3, [x3, #5112]
    a4a4:	8b020842 	add	x2, x2, x2, lsl #2
    a4a8:	d37df042 	lsl	x2, x2, #3
    a4ac:	8b020060 	add	x0, x3, x2
    a4b0:	f9401017 	ldr	x23, [x0, #32]
    a4b4:	b4000257 	cbz	x23, a4fc <f0+0x65c>
    a4b8:	38626862 	ldrb	w2, [x3, x2]
    a4bc:	7100085f 	cmp	w2, #0x2
    a4c0:	5400e900 	b.eq	c1e0 <f0+0x2340>  // b.none
    a4c4:	7100045f 	cmp	w2, #0x1
    a4c8:	540001a1 	b.ne	a4fc <f0+0x65c>  // b.any
    a4cc:	29430002 	ldp	w2, w0, [x0, #24]
    a4d0:	92403c21 	and	x1, x1, #0xffff
    a4d4:	9b027c21 	mul	x1, x1, x2
    a4d8:	d360fc21 	lsr	x1, x1, #32
    a4dc:	eb00003f 	cmp	x1, x0
    a4e0:	540000e2 	b.cs	a4fc <f0+0x65c>  // b.hs, b.nlast
    a4e4:	8b0102f7 	add	x23, x23, x1
    a4e8:	394002e0 	ldrb	w0, [x23]
    a4ec:	7103fc1f 	cmp	w0, #0xff
    a4f0:	5400f4a0 	b.eq	c384 <f0+0x24e4>  // b.none
    a4f4:	52800020 	mov	w0, #0x1                   	// #1
    a4f8:	390002e0 	strb	w0, [x23]
    a4fc:	910563e1 	add	x1, sp, #0x158
    a500:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a504:	52800020 	mov	w0, #0x1                   	// #1
    a508:	a915d7f7 	stp	x23, x21, [sp, #344]
    a50c:	97ffebcd 	bl	5440 <fwp_data.part.0.constprop.0>
    a510:	97ffec39 	bl	55f4 <fwp_rc_fresh>
    a514:	aa0003e2 	mov	x2, x0
    a518:	9105a3e1 	add	x1, sp, #0x168
    a51c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a520:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a524:	52800020 	mov	w0, #0x1                   	// #1
    a528:	a9168bf5 	stp	x21, x2, [sp, #360]
    a52c:	97ffebc5 	bl	5440 <fwp_data.part.0.constprop.0>
    a530:	97ffec31 	bl	55f4 <fwp_rc_fresh>
    a534:	aa0003e2 	mov	x2, x0
    a538:	9105e3e1 	add	x1, sp, #0x178
    a53c:	52800020 	mov	w0, #0x1                   	// #1
    a540:	a9178bf7 	stp	x23, x2, [sp, #376]
    a544:	97ffebbf 	bl	5440 <fwp_data.part.0.constprop.0>
    a548:	97ffec2b 	bl	55f4 <fwp_rc_fresh>
    a54c:	aa0003e2 	mov	x2, x0
    a550:	910623e1 	add	x1, sp, #0x188
    a554:	52800020 	mov	w0, #0x1                   	// #1
    a558:	a9188bf5 	stp	x21, x2, [sp, #392]
    a55c:	97ffebb9 	bl	5440 <fwp_data.part.0.constprop.0>
    a560:	9115c283 	add	x3, x20, #0x570
    a564:	aa0003f5 	mov	x21, x0
    a568:	f949d861 	ldr	x1, [x3, #5040]
    a56c:	f949ec60 	ldr	x0, [x3, #5080]
    a570:	cb0102a1 	sub	x1, x21, x1
    a574:	eb00403f 	cmp	x1, x0, lsl #16
    a578:	54000322 	b.cs	a5dc <f0+0x73c>  // b.hs, b.nlast
    a57c:	d350fc22 	lsr	x2, x1, #16
    a580:	f949fc63 	ldr	x3, [x3, #5112]
    a584:	8b020842 	add	x2, x2, x2, lsl #2
    a588:	d37df042 	lsl	x2, x2, #3
    a58c:	8b020060 	add	x0, x3, x2
    a590:	f9401017 	ldr	x23, [x0, #32]
    a594:	b4000257 	cbz	x23, a5dc <f0+0x73c>
    a598:	38626862 	ldrb	w2, [x3, x2]
    a59c:	7100085f 	cmp	w2, #0x2
    a5a0:	5400e620 	b.eq	c264 <f0+0x23c4>  // b.none
    a5a4:	7100045f 	cmp	w2, #0x1
    a5a8:	540001a1 	b.ne	a5dc <f0+0x73c>  // b.any
    a5ac:	29430002 	ldp	w2, w0, [x0, #24]
    a5b0:	92403c21 	and	x1, x1, #0xffff
    a5b4:	9b027c21 	mul	x1, x1, x2
    a5b8:	d360fc21 	lsr	x1, x1, #32
    a5bc:	eb00003f 	cmp	x1, x0
    a5c0:	540000e2 	b.cs	a5dc <f0+0x73c>  // b.hs, b.nlast
    a5c4:	8b0102f7 	add	x23, x23, x1
    a5c8:	394002e0 	ldrb	w0, [x23]
    a5cc:	7103fc1f 	cmp	w0, #0xff
    a5d0:	5400ee00 	b.eq	c390 <f0+0x24f0>  // b.none
    a5d4:	52800020 	mov	w0, #0x1                   	// #1
    a5d8:	390002e0 	strb	w0, [x23]
    a5dc:	910663e1 	add	x1, sp, #0x198
    a5e0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a5e4:	52800020 	mov	w0, #0x1                   	// #1
    a5e8:	a919d7e2 	stp	x2, x21, [sp, #408]
    a5ec:	97ffeb95 	bl	5440 <fwp_data.part.0.constprop.0>
    a5f0:	97ffec01 	bl	55f4 <fwp_rc_fresh>
    a5f4:	aa0003e2 	mov	x2, x0
    a5f8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a5fc:	9106a3e1 	add	x1, sp, #0x1a8
    a600:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a604:	52800020 	mov	w0, #0x1                   	// #1
    a608:	a91a8be3 	stp	x3, x2, [sp, #424]
    a60c:	97ffeb8d 	bl	5440 <fwp_data.part.0.constprop.0>
    a610:	9115c283 	add	x3, x20, #0x570
    a614:	aa0003f5 	mov	x21, x0
    a618:	f949d861 	ldr	x1, [x3, #5040]
    a61c:	f949ec60 	ldr	x0, [x3, #5080]
    a620:	cb0102a1 	sub	x1, x21, x1
    a624:	eb00403f 	cmp	x1, x0, lsl #16
    a628:	54000322 	b.cs	a68c <f0+0x7ec>  // b.hs, b.nlast
    a62c:	d350fc22 	lsr	x2, x1, #16
    a630:	f949fc63 	ldr	x3, [x3, #5112]
    a634:	8b020842 	add	x2, x2, x2, lsl #2
    a638:	d37df042 	lsl	x2, x2, #3
    a63c:	8b020060 	add	x0, x3, x2
    a640:	f9401017 	ldr	x23, [x0, #32]
    a644:	b4000257 	cbz	x23, a68c <f0+0x7ec>
    a648:	38626862 	ldrb	w2, [x3, x2]
    a64c:	7100085f 	cmp	w2, #0x2
    a650:	5400e040 	b.eq	c258 <f0+0x23b8>  // b.none
    a654:	7100045f 	cmp	w2, #0x1
    a658:	540001a1 	b.ne	a68c <f0+0x7ec>  // b.any
    a65c:	29430002 	ldp	w2, w0, [x0, #24]
    a660:	92403c21 	and	x1, x1, #0xffff
    a664:	9b027c21 	mul	x1, x1, x2
    a668:	d360fc21 	lsr	x1, x1, #32
    a66c:	eb00003f 	cmp	x1, x0
    a670:	540000e2 	b.cs	a68c <f0+0x7ec>  // b.hs, b.nlast
    a674:	8b0102f7 	add	x23, x23, x1
    a678:	394002e0 	ldrb	w0, [x23]
    a67c:	7103fc1f 	cmp	w0, #0xff
    a680:	5400e8e0 	b.eq	c39c <f0+0x24fc>  // b.none
    a684:	52800020 	mov	w0, #0x1                   	// #1
    a688:	390002e0 	strb	w0, [x23]
    a68c:	9106e3e1 	add	x1, sp, #0x1b8
    a690:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a694:	52800020 	mov	w0, #0x1                   	// #1
    a698:	a91bd7f7 	stp	x23, x21, [sp, #440]
    a69c:	97ffeb69 	bl	5440 <fwp_data.part.0.constprop.0>
    a6a0:	97ffebd5 	bl	55f4 <fwp_rc_fresh>
    a6a4:	aa0003e2 	mov	x2, x0
    a6a8:	910723e1 	add	x1, sp, #0x1c8
    a6ac:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a6b0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a6b4:	52800020 	mov	w0, #0x1                   	// #1
    a6b8:	a91c8bf5 	stp	x21, x2, [sp, #456]
    a6bc:	97ffeb61 	bl	5440 <fwp_data.part.0.constprop.0>
    a6c0:	97ffebcd 	bl	55f4 <fwp_rc_fresh>
    a6c4:	aa0003e2 	mov	x2, x0
    a6c8:	910763e1 	add	x1, sp, #0x1d8
    a6cc:	52800020 	mov	w0, #0x1                   	// #1
    a6d0:	a91d8bf7 	stp	x23, x2, [sp, #472]
    a6d4:	97ffeb5b 	bl	5440 <fwp_data.part.0.constprop.0>
    a6d8:	97ffebc7 	bl	55f4 <fwp_rc_fresh>
    a6dc:	aa0003e2 	mov	x2, x0
    a6e0:	9107a3e1 	add	x1, sp, #0x1e8
    a6e4:	52800020 	mov	w0, #0x1                   	// #1
    a6e8:	a91e8bf5 	stp	x21, x2, [sp, #488]
    a6ec:	97ffeb55 	bl	5440 <fwp_data.part.0.constprop.0>
    a6f0:	9115c283 	add	x3, x20, #0x570
    a6f4:	aa0003f5 	mov	x21, x0
    a6f8:	f949d861 	ldr	x1, [x3, #5040]
    a6fc:	f949ec60 	ldr	x0, [x3, #5080]
    a700:	cb0102a1 	sub	x1, x21, x1
    a704:	eb00403f 	cmp	x1, x0, lsl #16
    a708:	54000322 	b.cs	a76c <f0+0x8cc>  // b.hs, b.nlast
    a70c:	d350fc22 	lsr	x2, x1, #16
    a710:	f949fc63 	ldr	x3, [x3, #5112]
    a714:	8b020842 	add	x2, x2, x2, lsl #2
    a718:	d37df042 	lsl	x2, x2, #3
    a71c:	8b020060 	add	x0, x3, x2
    a720:	f9401017 	ldr	x23, [x0, #32]
    a724:	b4000257 	cbz	x23, a76c <f0+0x8cc>
    a728:	38626862 	ldrb	w2, [x3, x2]
    a72c:	7100085f 	cmp	w2, #0x2
    a730:	5400d8e0 	b.eq	c24c <f0+0x23ac>  // b.none
    a734:	7100045f 	cmp	w2, #0x1
    a738:	540001a1 	b.ne	a76c <f0+0x8cc>  // b.any
    a73c:	29430002 	ldp	w2, w0, [x0, #24]
    a740:	92403c21 	and	x1, x1, #0xffff
    a744:	9b027c21 	mul	x1, x1, x2
    a748:	d360fc21 	lsr	x1, x1, #32
    a74c:	eb00003f 	cmp	x1, x0
    a750:	540000e2 	b.cs	a76c <f0+0x8cc>  // b.hs, b.nlast
    a754:	8b0102f7 	add	x23, x23, x1
    a758:	394002e0 	ldrb	w0, [x23]
    a75c:	7103fc1f 	cmp	w0, #0xff
    a760:	5400e240 	b.eq	c3a8 <f0+0x2508>  // b.none
    a764:	52800020 	mov	w0, #0x1                   	// #1
    a768:	390002e0 	strb	w0, [x23]
    a76c:	9107e3e1 	add	x1, sp, #0x1f8
    a770:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a774:	52800020 	mov	w0, #0x1                   	// #1
    a778:	a91fd7f7 	stp	x23, x21, [sp, #504]
    a77c:	97ffeb31 	bl	5440 <fwp_data.part.0.constprop.0>
    a780:	97ffeb9d 	bl	55f4 <fwp_rc_fresh>
    a784:	aa0003e2 	mov	x2, x0
    a788:	910823e1 	add	x1, sp, #0x208
    a78c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a790:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a794:	52800020 	mov	w0, #0x1                   	// #1
    a798:	f90107f5 	str	x21, [sp, #520]
    a79c:	f9010be2 	str	x2, [sp, #528]
    a7a0:	97ffeb28 	bl	5440 <fwp_data.part.0.constprop.0>
    a7a4:	97ffeb94 	bl	55f4 <fwp_rc_fresh>
    a7a8:	aa0003e2 	mov	x2, x0
    a7ac:	910863e1 	add	x1, sp, #0x218
    a7b0:	52800020 	mov	w0, #0x1                   	// #1
    a7b4:	f9010ff7 	str	x23, [sp, #536]
    a7b8:	f90113e2 	str	x2, [sp, #544]
    a7bc:	97ffeb21 	bl	5440 <fwp_data.part.0.constprop.0>
    a7c0:	97ffeb8d 	bl	55f4 <fwp_rc_fresh>
    a7c4:	aa0003e2 	mov	x2, x0
    a7c8:	9108a3e1 	add	x1, sp, #0x228
    a7cc:	52800020 	mov	w0, #0x1                   	// #1
    a7d0:	f90117f5 	str	x21, [sp, #552]
    a7d4:	f9011be2 	str	x2, [sp, #560]
    a7d8:	97ffeb1a 	bl	5440 <fwp_data.part.0.constprop.0>
    a7dc:	9115c283 	add	x3, x20, #0x570
    a7e0:	aa0003f5 	mov	x21, x0
    a7e4:	f949d861 	ldr	x1, [x3, #5040]
    a7e8:	f949ec60 	ldr	x0, [x3, #5080]
    a7ec:	cb0102a1 	sub	x1, x21, x1
    a7f0:	eb00403f 	cmp	x1, x0, lsl #16
    a7f4:	54000322 	b.cs	a858 <f0+0x9b8>  // b.hs, b.nlast
    a7f8:	d350fc22 	lsr	x2, x1, #16
    a7fc:	f949fc63 	ldr	x3, [x3, #5112]
    a800:	8b020842 	add	x2, x2, x2, lsl #2
    a804:	d37df042 	lsl	x2, x2, #3
    a808:	8b020060 	add	x0, x3, x2
    a80c:	f9401017 	ldr	x23, [x0, #32]
    a810:	b4000257 	cbz	x23, a858 <f0+0x9b8>
    a814:	38626862 	ldrb	w2, [x3, x2]
    a818:	7100085f 	cmp	w2, #0x2
    a81c:	5400d120 	b.eq	c240 <f0+0x23a0>  // b.none
    a820:	7100045f 	cmp	w2, #0x1
    a824:	540001a1 	b.ne	a858 <f0+0x9b8>  // b.any
    a828:	29430002 	ldp	w2, w0, [x0, #24]
    a82c:	92403c21 	and	x1, x1, #0xffff
    a830:	9b027c21 	mul	x1, x1, x2
    a834:	d360fc21 	lsr	x1, x1, #32
    a838:	eb00003f 	cmp	x1, x0
    a83c:	540000e2 	b.cs	a858 <f0+0x9b8>  // b.hs, b.nlast
    a840:	8b0102f7 	add	x23, x23, x1
    a844:	394002e0 	ldrb	w0, [x23]
    a848:	7103fc1f 	cmp	w0, #0xff
    a84c:	5400db40 	b.eq	c3b4 <f0+0x2514>  // b.none
    a850:	52800020 	mov	w0, #0x1                   	// #1
    a854:	390002e0 	strb	w0, [x23]
    a858:	9108e3e1 	add	x1, sp, #0x238
    a85c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a860:	52800020 	mov	w0, #0x1                   	// #1
    a864:	f9011fe2 	str	x2, [sp, #568]
    a868:	f90123f5 	str	x21, [sp, #576]
    a86c:	97ffeaf5 	bl	5440 <fwp_data.part.0.constprop.0>
    a870:	97ffeb61 	bl	55f4 <fwp_rc_fresh>
    a874:	aa0003e2 	mov	x2, x0
    a878:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a87c:	910923e1 	add	x1, sp, #0x248
    a880:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a884:	52800020 	mov	w0, #0x1                   	// #1
    a888:	f90127e3 	str	x3, [sp, #584]
    a88c:	f9012be2 	str	x2, [sp, #592]
    a890:	97ffeaec 	bl	5440 <fwp_data.part.0.constprop.0>
    a894:	9115c283 	add	x3, x20, #0x570
    a898:	aa0003f5 	mov	x21, x0
    a89c:	f949d861 	ldr	x1, [x3, #5040]
    a8a0:	f949ec60 	ldr	x0, [x3, #5080]
    a8a4:	cb0102a1 	sub	x1, x21, x1
    a8a8:	eb00403f 	cmp	x1, x0, lsl #16
    a8ac:	54000322 	b.cs	a910 <f0+0xa70>  // b.hs, b.nlast
    a8b0:	d350fc22 	lsr	x2, x1, #16
    a8b4:	f949fc63 	ldr	x3, [x3, #5112]
    a8b8:	8b020842 	add	x2, x2, x2, lsl #2
    a8bc:	d37df042 	lsl	x2, x2, #3
    a8c0:	8b020060 	add	x0, x3, x2
    a8c4:	f9401017 	ldr	x23, [x0, #32]
    a8c8:	b4000257 	cbz	x23, a910 <f0+0xa70>
    a8cc:	38626862 	ldrb	w2, [x3, x2]
    a8d0:	7100085f 	cmp	w2, #0x2
    a8d4:	5400cb00 	b.eq	c234 <f0+0x2394>  // b.none
    a8d8:	7100045f 	cmp	w2, #0x1
    a8dc:	540001a1 	b.ne	a910 <f0+0xa70>  // b.any
    a8e0:	29430002 	ldp	w2, w0, [x0, #24]
    a8e4:	92403c21 	and	x1, x1, #0xffff
    a8e8:	9b027c21 	mul	x1, x1, x2
    a8ec:	d360fc21 	lsr	x1, x1, #32
    a8f0:	eb00003f 	cmp	x1, x0
    a8f4:	540000e2 	b.cs	a910 <f0+0xa70>  // b.hs, b.nlast
    a8f8:	8b0102f7 	add	x23, x23, x1
    a8fc:	394002e0 	ldrb	w0, [x23]
    a900:	7103fc1f 	cmp	w0, #0xff
    a904:	5400d5e0 	b.eq	c3c0 <f0+0x2520>  // b.none
    a908:	52800020 	mov	w0, #0x1                   	// #1
    a90c:	390002e0 	strb	w0, [x23]
    a910:	910963e1 	add	x1, sp, #0x258
    a914:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a918:	52800020 	mov	w0, #0x1                   	// #1
    a91c:	f9012fe2 	str	x2, [sp, #600]
    a920:	f90133f5 	str	x21, [sp, #608]
    a924:	97ffeac7 	bl	5440 <fwp_data.part.0.constprop.0>
    a928:	97ffeb33 	bl	55f4 <fwp_rc_fresh>
    a92c:	aa0003e2 	mov	x2, x0
    a930:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a934:	9109a3e1 	add	x1, sp, #0x268
    a938:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a93c:	52800020 	mov	w0, #0x1                   	// #1
    a940:	f90137e3 	str	x3, [sp, #616]
    a944:	f9013be2 	str	x2, [sp, #624]
    a948:	97ffeabe 	bl	5440 <fwp_data.part.0.constprop.0>
    a94c:	9115c283 	add	x3, x20, #0x570
    a950:	aa0003f5 	mov	x21, x0
    a954:	f949d861 	ldr	x1, [x3, #5040]
    a958:	f949ec60 	ldr	x0, [x3, #5080]
    a95c:	cb0102a1 	sub	x1, x21, x1
    a960:	eb00403f 	cmp	x1, x0, lsl #16
    a964:	54000322 	b.cs	a9c8 <f0+0xb28>  // b.hs, b.nlast
    a968:	d350fc22 	lsr	x2, x1, #16
    a96c:	f949fc63 	ldr	x3, [x3, #5112]
    a970:	8b020842 	add	x2, x2, x2, lsl #2
    a974:	d37df042 	lsl	x2, x2, #3
    a978:	8b020060 	add	x0, x3, x2
    a97c:	f9401017 	ldr	x23, [x0, #32]
    a980:	b4000257 	cbz	x23, a9c8 <f0+0xb28>
    a984:	38626862 	ldrb	w2, [x3, x2]
    a988:	7100085f 	cmp	w2, #0x2
    a98c:	5400c4e0 	b.eq	c228 <f0+0x2388>  // b.none
    a990:	7100045f 	cmp	w2, #0x1
    a994:	540001a1 	b.ne	a9c8 <f0+0xb28>  // b.any
    a998:	29430002 	ldp	w2, w0, [x0, #24]
    a99c:	92403c21 	and	x1, x1, #0xffff
    a9a0:	9b027c21 	mul	x1, x1, x2
    a9a4:	d360fc21 	lsr	x1, x1, #32
    a9a8:	eb00003f 	cmp	x1, x0
    a9ac:	540000e2 	b.cs	a9c8 <f0+0xb28>  // b.hs, b.nlast
    a9b0:	8b0102f7 	add	x23, x23, x1
    a9b4:	394002e0 	ldrb	w0, [x23]
    a9b8:	7103fc1f 	cmp	w0, #0xff
    a9bc:	5400d080 	b.eq	c3cc <f0+0x252c>  // b.none
    a9c0:	52800020 	mov	w0, #0x1                   	// #1
    a9c4:	390002e0 	strb	w0, [x23]
    a9c8:	9109e3e1 	add	x1, sp, #0x278
    a9cc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a9d0:	52800020 	mov	w0, #0x1                   	// #1
    a9d4:	f9013fe2 	str	x2, [sp, #632]
    a9d8:	f90143f5 	str	x21, [sp, #640]
    a9dc:	97ffea99 	bl	5440 <fwp_data.part.0.constprop.0>
    a9e0:	97ffeb05 	bl	55f4 <fwp_rc_fresh>
    a9e4:	aa0003e2 	mov	x2, x0
    a9e8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a9ec:	910a23e1 	add	x1, sp, #0x288
    a9f0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a9f4:	52800020 	mov	w0, #0x1                   	// #1
    a9f8:	f90147e3 	str	x3, [sp, #648]
    a9fc:	f9014be2 	str	x2, [sp, #656]
    aa00:	97ffea90 	bl	5440 <fwp_data.part.0.constprop.0>
    aa04:	9115c283 	add	x3, x20, #0x570
    aa08:	aa0003f5 	mov	x21, x0
    aa0c:	f949d861 	ldr	x1, [x3, #5040]
    aa10:	f949ec60 	ldr	x0, [x3, #5080]
    aa14:	cb0102a1 	sub	x1, x21, x1
    aa18:	eb00403f 	cmp	x1, x0, lsl #16
    aa1c:	54000322 	b.cs	aa80 <f0+0xbe0>  // b.hs, b.nlast
    aa20:	d350fc22 	lsr	x2, x1, #16
    aa24:	f949fc63 	ldr	x3, [x3, #5112]
    aa28:	8b020842 	add	x2, x2, x2, lsl #2
    aa2c:	d37df042 	lsl	x2, x2, #3
    aa30:	8b020060 	add	x0, x3, x2
    aa34:	f9401017 	ldr	x23, [x0, #32]
    aa38:	b4000257 	cbz	x23, aa80 <f0+0xbe0>
    aa3c:	38626862 	ldrb	w2, [x3, x2]
    aa40:	7100085f 	cmp	w2, #0x2
    aa44:	5400bec0 	b.eq	c21c <f0+0x237c>  // b.none
    aa48:	7100045f 	cmp	w2, #0x1
    aa4c:	540001a1 	b.ne	aa80 <f0+0xbe0>  // b.any
    aa50:	29430002 	ldp	w2, w0, [x0, #24]
    aa54:	92403c21 	and	x1, x1, #0xffff
    aa58:	9b027c21 	mul	x1, x1, x2
    aa5c:	d360fc21 	lsr	x1, x1, #32
    aa60:	eb00003f 	cmp	x1, x0
    aa64:	540000e2 	b.cs	aa80 <f0+0xbe0>  // b.hs, b.nlast
    aa68:	8b0102f7 	add	x23, x23, x1
    aa6c:	394002e0 	ldrb	w0, [x23]
    aa70:	7103fc1f 	cmp	w0, #0xff
    aa74:	5400cb20 	b.eq	c3d8 <f0+0x2538>  // b.none
    aa78:	52800020 	mov	w0, #0x1                   	// #1
    aa7c:	390002e0 	strb	w0, [x23]
    aa80:	910a63e1 	add	x1, sp, #0x298
    aa84:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    aa88:	52800020 	mov	w0, #0x1                   	// #1
    aa8c:	f9014ff7 	str	x23, [sp, #664]
    aa90:	f90153f5 	str	x21, [sp, #672]
    aa94:	97ffea6b 	bl	5440 <fwp_data.part.0.constprop.0>
    aa98:	97ffead7 	bl	55f4 <fwp_rc_fresh>
    aa9c:	aa0003e2 	mov	x2, x0
    aaa0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aaa4:	910aa3e1 	add	x1, sp, #0x2a8
    aaa8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aaac:	52800020 	mov	w0, #0x1                   	// #1
    aab0:	f90157e3 	str	x3, [sp, #680]
    aab4:	f9015be2 	str	x2, [sp, #688]
    aab8:	97ffea62 	bl	5440 <fwp_data.part.0.constprop.0>
    aabc:	97ffeace 	bl	55f4 <fwp_rc_fresh>
    aac0:	aa0003e2 	mov	x2, x0
    aac4:	910ae3e1 	add	x1, sp, #0x2b8
    aac8:	52800020 	mov	w0, #0x1                   	// #1
    aacc:	f9015ff7 	str	x23, [sp, #696]
    aad0:	f90163e2 	str	x2, [sp, #704]
    aad4:	97ffea5b 	bl	5440 <fwp_data.part.0.constprop.0>
    aad8:	9115c283 	add	x3, x20, #0x570
    aadc:	aa0003f5 	mov	x21, x0
    aae0:	f949d861 	ldr	x1, [x3, #5040]
    aae4:	f949ec60 	ldr	x0, [x3, #5080]
    aae8:	cb0102a1 	sub	x1, x21, x1
    aaec:	eb00403f 	cmp	x1, x0, lsl #16
    aaf0:	54000322 	b.cs	ab54 <f0+0xcb4>  // b.hs, b.nlast
    aaf4:	d350fc22 	lsr	x2, x1, #16
    aaf8:	f949fc63 	ldr	x3, [x3, #5112]
    aafc:	8b020842 	add	x2, x2, x2, lsl #2
    ab00:	d37df042 	lsl	x2, x2, #3
    ab04:	8b020060 	add	x0, x3, x2
    ab08:	f9401017 	ldr	x23, [x0, #32]
    ab0c:	b4000257 	cbz	x23, ab54 <f0+0xcb4>
    ab10:	38626862 	ldrb	w2, [x3, x2]
    ab14:	7100085f 	cmp	w2, #0x2
    ab18:	5400b7c0 	b.eq	c210 <f0+0x2370>  // b.none
    ab1c:	7100045f 	cmp	w2, #0x1
    ab20:	540001a1 	b.ne	ab54 <f0+0xcb4>  // b.any
    ab24:	29430002 	ldp	w2, w0, [x0, #24]
    ab28:	92403c21 	and	x1, x1, #0xffff
    ab2c:	9b027c21 	mul	x1, x1, x2
    ab30:	d360fc21 	lsr	x1, x1, #32
    ab34:	eb00003f 	cmp	x1, x0
    ab38:	540000e2 	b.cs	ab54 <f0+0xcb4>  // b.hs, b.nlast
    ab3c:	8b0102f7 	add	x23, x23, x1
    ab40:	394002e0 	ldrb	w0, [x23]
    ab44:	7103fc1f 	cmp	w0, #0xff
    ab48:	5400c4e0 	b.eq	c3e4 <f0+0x2544>  // b.none
    ab4c:	52800020 	mov	w0, #0x1                   	// #1
    ab50:	390002e0 	strb	w0, [x23]
    ab54:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ab58:	910b23e1 	add	x1, sp, #0x2c8
    ab5c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ab60:	52800020 	mov	w0, #0x1                   	// #1
    ab64:	f90167e2 	str	x2, [sp, #712]
    ab68:	f9016bf5 	str	x21, [sp, #720]
    ab6c:	97ffea35 	bl	5440 <fwp_data.part.0.constprop.0>
    ab70:	9115c283 	add	x3, x20, #0x570
    ab74:	aa0003f5 	mov	x21, x0
    ab78:	f949d861 	ldr	x1, [x3, #5040]
    ab7c:	f949ec60 	ldr	x0, [x3, #5080]
    ab80:	cb0102a1 	sub	x1, x21, x1
    ab84:	eb00403f 	cmp	x1, x0, lsl #16
    ab88:	54000322 	b.cs	abec <f0+0xd4c>  // b.hs, b.nlast
    ab8c:	d350fc22 	lsr	x2, x1, #16
    ab90:	f949fc63 	ldr	x3, [x3, #5112]
    ab94:	8b020842 	add	x2, x2, x2, lsl #2
    ab98:	d37df042 	lsl	x2, x2, #3
    ab9c:	8b020060 	add	x0, x3, x2
    aba0:	f9401017 	ldr	x23, [x0, #32]
    aba4:	b4000257 	cbz	x23, abec <f0+0xd4c>
    aba8:	38626862 	ldrb	w2, [x3, x2]
    abac:	7100085f 	cmp	w2, #0x2
    abb0:	5400b000 	b.eq	c1b0 <f0+0x2310>  // b.none
    abb4:	7100045f 	cmp	w2, #0x1
    abb8:	540001a1 	b.ne	abec <f0+0xd4c>  // b.any
    abbc:	29430002 	ldp	w2, w0, [x0, #24]
    abc0:	92403c21 	and	x1, x1, #0xffff
    abc4:	9b027c21 	mul	x1, x1, x2
    abc8:	d360fc21 	lsr	x1, x1, #32
    abcc:	eb00003f 	cmp	x1, x0
    abd0:	540000e2 	b.cs	abec <f0+0xd4c>  // b.hs, b.nlast
    abd4:	8b0102f7 	add	x23, x23, x1
    abd8:	394002e0 	ldrb	w0, [x23]
    abdc:	7103fc1f 	cmp	w0, #0xff
    abe0:	5400c080 	b.eq	c3f0 <f0+0x2550>  // b.none
    abe4:	52800020 	mov	w0, #0x1                   	// #1
    abe8:	390002e0 	strb	w0, [x23]
    abec:	910b63e1 	add	x1, sp, #0x2d8
    abf0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    abf4:	52800020 	mov	w0, #0x1                   	// #1
    abf8:	f9016ff7 	str	x23, [sp, #728]
    abfc:	f90173f5 	str	x21, [sp, #736]
    ac00:	97ffea10 	bl	5440 <fwp_data.part.0.constprop.0>
    ac04:	97ffea7c 	bl	55f4 <fwp_rc_fresh>
    ac08:	aa0003e2 	mov	x2, x0
    ac0c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac10:	910ba3e1 	add	x1, sp, #0x2e8
    ac14:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac18:	52800020 	mov	w0, #0x1                   	// #1
    ac1c:	f90177e3 	str	x3, [sp, #744]
    ac20:	f9017be2 	str	x2, [sp, #752]
    ac24:	97ffea07 	bl	5440 <fwp_data.part.0.constprop.0>
    ac28:	97ffea73 	bl	55f4 <fwp_rc_fresh>
    ac2c:	aa0003e2 	mov	x2, x0
    ac30:	910be3e1 	add	x1, sp, #0x2f8
    ac34:	52800020 	mov	w0, #0x1                   	// #1
    ac38:	f9017ff7 	str	x23, [sp, #760]
    ac3c:	f90183e2 	str	x2, [sp, #768]
    ac40:	97ffea00 	bl	5440 <fwp_data.part.0.constprop.0>
    ac44:	9115c283 	add	x3, x20, #0x570
    ac48:	aa0003f5 	mov	x21, x0
    ac4c:	f949d861 	ldr	x1, [x3, #5040]
    ac50:	f949ec60 	ldr	x0, [x3, #5080]
    ac54:	cb0102a1 	sub	x1, x21, x1
    ac58:	eb00403f 	cmp	x1, x0, lsl #16
    ac5c:	54000322 	b.cs	acc0 <f0+0xe20>  // b.hs, b.nlast
    ac60:	d350fc22 	lsr	x2, x1, #16
    ac64:	f949fc63 	ldr	x3, [x3, #5112]
    ac68:	8b020842 	add	x2, x2, x2, lsl #2
    ac6c:	d37df042 	lsl	x2, x2, #3
    ac70:	8b020060 	add	x0, x3, x2
    ac74:	f9401017 	ldr	x23, [x0, #32]
    ac78:	b4000257 	cbz	x23, acc0 <f0+0xe20>
    ac7c:	38626862 	ldrb	w2, [x3, x2]
    ac80:	7100085f 	cmp	w2, #0x2
    ac84:	5400a900 	b.eq	c1a4 <f0+0x2304>  // b.none
    ac88:	7100045f 	cmp	w2, #0x1
    ac8c:	540001a1 	b.ne	acc0 <f0+0xe20>  // b.any
    ac90:	29430002 	ldp	w2, w0, [x0, #24]
    ac94:	92403c21 	and	x1, x1, #0xffff
    ac98:	9b027c21 	mul	x1, x1, x2
    ac9c:	d360fc21 	lsr	x1, x1, #32
    aca0:	eb00003f 	cmp	x1, x0
    aca4:	540000e2 	b.cs	acc0 <f0+0xe20>  // b.hs, b.nlast
    aca8:	8b0102f7 	add	x23, x23, x1
    acac:	394002e0 	ldrb	w0, [x23]
    acb0:	7103fc1f 	cmp	w0, #0xff
    acb4:	5400ba40 	b.eq	c3fc <f0+0x255c>  // b.none
    acb8:	52800020 	mov	w0, #0x1                   	// #1
    acbc:	390002e0 	strb	w0, [x23]
    acc0:	910c23e1 	add	x1, sp, #0x308
    acc4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    acc8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    accc:	52800020 	mov	w0, #0x1                   	// #1
    acd0:	f90187f7 	str	x23, [sp, #776]
    acd4:	f9018bf5 	str	x21, [sp, #784]
    acd8:	97ffe9da 	bl	5440 <fwp_data.part.0.constprop.0>
    acdc:	97ffea46 	bl	55f4 <fwp_rc_fresh>
    ace0:	aa0003e2 	mov	x2, x0
    ace4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ace8:	910c63e1 	add	x1, sp, #0x318
    acec:	52800020 	mov	w0, #0x1                   	// #1
    acf0:	f9018fe3 	str	x3, [sp, #792]
    acf4:	f90193e2 	str	x2, [sp, #800]
    acf8:	97ffe9d2 	bl	5440 <fwp_data.part.0.constprop.0>
    acfc:	97ffea3e 	bl	55f4 <fwp_rc_fresh>
    ad00:	aa0003e2 	mov	x2, x0
    ad04:	910ca3e1 	add	x1, sp, #0x328
    ad08:	52800020 	mov	w0, #0x1                   	// #1
    ad0c:	f90197f7 	str	x23, [sp, #808]
    ad10:	f9019be2 	str	x2, [sp, #816]
    ad14:	97ffe9cb 	bl	5440 <fwp_data.part.0.constprop.0>
    ad18:	9115c283 	add	x3, x20, #0x570
    ad1c:	aa0003f5 	mov	x21, x0
    ad20:	f949d861 	ldr	x1, [x3, #5040]
    ad24:	f949ec60 	ldr	x0, [x3, #5080]
    ad28:	cb0102a1 	sub	x1, x21, x1
    ad2c:	eb00403f 	cmp	x1, x0, lsl #16
    ad30:	54000322 	b.cs	ad94 <f0+0xef4>  // b.hs, b.nlast
    ad34:	d350fc22 	lsr	x2, x1, #16
    ad38:	f949fc63 	ldr	x3, [x3, #5112]
    ad3c:	8b020842 	add	x2, x2, x2, lsl #2
    ad40:	d37df042 	lsl	x2, x2, #3
    ad44:	8b020060 	add	x0, x3, x2
    ad48:	f9401017 	ldr	x23, [x0, #32]
    ad4c:	b4000257 	cbz	x23, ad94 <f0+0xef4>
    ad50:	38626862 	ldrb	w2, [x3, x2]
    ad54:	7100085f 	cmp	w2, #0x2
    ad58:	5400a200 	b.eq	c198 <f0+0x22f8>  // b.none
    ad5c:	7100045f 	cmp	w2, #0x1
    ad60:	540001a1 	b.ne	ad94 <f0+0xef4>  // b.any
    ad64:	29430002 	ldp	w2, w0, [x0, #24]
    ad68:	92403c21 	and	x1, x1, #0xffff
    ad6c:	9b027c21 	mul	x1, x1, x2
    ad70:	d360fc21 	lsr	x1, x1, #32
    ad74:	eb00003f 	cmp	x1, x0
    ad78:	540000e2 	b.cs	ad94 <f0+0xef4>  // b.hs, b.nlast
    ad7c:	8b0102f7 	add	x23, x23, x1
    ad80:	394002e0 	ldrb	w0, [x23]
    ad84:	7103fc1f 	cmp	w0, #0xff
    ad88:	5400b400 	b.eq	c408 <f0+0x2568>  // b.none
    ad8c:	52800020 	mov	w0, #0x1                   	// #1
    ad90:	390002e0 	strb	w0, [x23]
    ad94:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad98:	910ce3e1 	add	x1, sp, #0x338
    ad9c:	52800020 	mov	w0, #0x1                   	// #1
    ada0:	f9019fe2 	str	x2, [sp, #824]
    ada4:	f901a3f5 	str	x21, [sp, #832]
    ada8:	97ffe9a6 	bl	5440 <fwp_data.part.0.constprop.0>
    adac:	9115c283 	add	x3, x20, #0x570
    adb0:	aa0003f5 	mov	x21, x0
    adb4:	f949d861 	ldr	x1, [x3, #5040]
    adb8:	f949ec60 	ldr	x0, [x3, #5080]
    adbc:	cb0102a1 	sub	x1, x21, x1
    adc0:	eb00403f 	cmp	x1, x0, lsl #16
    adc4:	54000322 	b.cs	ae28 <f0+0xf88>  // b.hs, b.nlast
    adc8:	d350fc22 	lsr	x2, x1, #16
    adcc:	f949fc63 	ldr	x3, [x3, #5112]
    add0:	8b020842 	add	x2, x2, x2, lsl #2
    add4:	d37df042 	lsl	x2, x2, #3
    add8:	8b020060 	add	x0, x3, x2
    addc:	f9401017 	ldr	x23, [x0, #32]
    ade0:	b4000257 	cbz	x23, ae28 <f0+0xf88>
    ade4:	38626862 	ldrb	w2, [x3, x2]
    ade8:	7100085f 	cmp	w2, #0x2
    adec:	54009d00 	b.eq	c18c <f0+0x22ec>  // b.none
    adf0:	7100045f 	cmp	w2, #0x1
    adf4:	540001a1 	b.ne	ae28 <f0+0xf88>  // b.any
    adf8:	29430002 	ldp	w2, w0, [x0, #24]
    adfc:	92403c21 	and	x1, x1, #0xffff
    ae00:	9b027c21 	mul	x1, x1, x2
    ae04:	d360fc21 	lsr	x1, x1, #32
    ae08:	eb00003f 	cmp	x1, x0
    ae0c:	540000e2 	b.cs	ae28 <f0+0xf88>  // b.hs, b.nlast
    ae10:	8b0102f7 	add	x23, x23, x1
    ae14:	394002e0 	ldrb	w0, [x23]
    ae18:	7103fc1f 	cmp	w0, #0xff
    ae1c:	5400afc0 	b.eq	c414 <f0+0x2574>  // b.none
    ae20:	52800020 	mov	w0, #0x1                   	// #1
    ae24:	390002e0 	strb	w0, [x23]
    ae28:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ae2c:	910d23e1 	add	x1, sp, #0x348
    ae30:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ae34:	52800020 	mov	w0, #0x1                   	// #1
    ae38:	f901a7e2 	str	x2, [sp, #840]
    ae3c:	f901abf5 	str	x21, [sp, #848]
    ae40:	97ffe980 	bl	5440 <fwp_data.part.0.constprop.0>
    ae44:	9115c283 	add	x3, x20, #0x570
    ae48:	aa0003f5 	mov	x21, x0
    ae4c:	f949d861 	ldr	x1, [x3, #5040]
    ae50:	f949ec60 	ldr	x0, [x3, #5080]
    ae54:	cb0102a1 	sub	x1, x21, x1
    ae58:	eb00403f 	cmp	x1, x0, lsl #16
    ae5c:	54000322 	b.cs	aec0 <f0+0x1020>  // b.hs, b.nlast
    ae60:	d350fc22 	lsr	x2, x1, #16
    ae64:	f949fc63 	ldr	x3, [x3, #5112]
    ae68:	8b020842 	add	x2, x2, x2, lsl #2
    ae6c:	d37df042 	lsl	x2, x2, #3
    ae70:	8b020060 	add	x0, x3, x2
    ae74:	f9401017 	ldr	x23, [x0, #32]
    ae78:	b4000257 	cbz	x23, aec0 <f0+0x1020>
    ae7c:	38626862 	ldrb	w2, [x3, x2]
    ae80:	7100085f 	cmp	w2, #0x2
    ae84:	540097e0 	b.eq	c180 <f0+0x22e0>  // b.none
    ae88:	7100045f 	cmp	w2, #0x1
    ae8c:	540001a1 	b.ne	aec0 <f0+0x1020>  // b.any
    ae90:	29430002 	ldp	w2, w0, [x0, #24]
    ae94:	92403c21 	and	x1, x1, #0xffff
    ae98:	9b027c21 	mul	x1, x1, x2
    ae9c:	d360fc21 	lsr	x1, x1, #32
    aea0:	eb00003f 	cmp	x1, x0
    aea4:	540000e2 	b.cs	aec0 <f0+0x1020>  // b.hs, b.nlast
    aea8:	8b0102f7 	add	x23, x23, x1
    aeac:	394002e0 	ldrb	w0, [x23]
    aeb0:	7103fc1f 	cmp	w0, #0xff
    aeb4:	5400ab60 	b.eq	c420 <f0+0x2580>  // b.none
    aeb8:	52800020 	mov	w0, #0x1                   	// #1
    aebc:	390002e0 	strb	w0, [x23]
    aec0:	910d63e1 	add	x1, sp, #0x358
    aec4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    aec8:	52800020 	mov	w0, #0x1                   	// #1
    aecc:	f901aff7 	str	x23, [sp, #856]
    aed0:	f901b3f5 	str	x21, [sp, #864]
    aed4:	97ffe95b 	bl	5440 <fwp_data.part.0.constprop.0>
    aed8:	97ffe9c7 	bl	55f4 <fwp_rc_fresh>
    aedc:	aa0003e2 	mov	x2, x0
    aee0:	910da3e1 	add	x1, sp, #0x368
    aee4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    aee8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    aeec:	52800020 	mov	w0, #0x1                   	// #1
    aef0:	f901b7f5 	str	x21, [sp, #872]
    aef4:	f901bbe2 	str	x2, [sp, #880]
    aef8:	97ffe952 	bl	5440 <fwp_data.part.0.constprop.0>
    aefc:	97ffe9be 	bl	55f4 <fwp_rc_fresh>
    af00:	aa0003e2 	mov	x2, x0
    af04:	910de3e1 	add	x1, sp, #0x378
    af08:	52800020 	mov	w0, #0x1                   	// #1
    af0c:	f901bff7 	str	x23, [sp, #888]
    af10:	f901c3e2 	str	x2, [sp, #896]
    af14:	97ffe94b 	bl	5440 <fwp_data.part.0.constprop.0>
    af18:	97ffe9b7 	bl	55f4 <fwp_rc_fresh>
    af1c:	aa0003e2 	mov	x2, x0
    af20:	910e23e1 	add	x1, sp, #0x388
    af24:	52800020 	mov	w0, #0x1                   	// #1
    af28:	f901c7f5 	str	x21, [sp, #904]
    af2c:	f901cbe2 	str	x2, [sp, #912]
    af30:	97ffe944 	bl	5440 <fwp_data.part.0.constprop.0>
    af34:	97ffe9b0 	bl	55f4 <fwp_rc_fresh>
    af38:	aa0003e2 	mov	x2, x0
    af3c:	910e63e1 	add	x1, sp, #0x398
    af40:	52800020 	mov	w0, #0x1                   	// #1
    af44:	f901cff7 	str	x23, [sp, #920]
    af48:	f901d3e2 	str	x2, [sp, #928]
    af4c:	97ffe93d 	bl	5440 <fwp_data.part.0.constprop.0>
    af50:	97ffe9a9 	bl	55f4 <fwp_rc_fresh>
    af54:	aa0003e2 	mov	x2, x0
    af58:	910ea3e1 	add	x1, sp, #0x3a8
    af5c:	52800020 	mov	w0, #0x1                   	// #1
    af60:	f901d7f5 	str	x21, [sp, #936]
    af64:	f901dbe2 	str	x2, [sp, #944]
    af68:	97ffe936 	bl	5440 <fwp_data.part.0.constprop.0>
    af6c:	97ffe9a2 	bl	55f4 <fwp_rc_fresh>
    af70:	aa0003e2 	mov	x2, x0
    af74:	910ee3e1 	add	x1, sp, #0x3b8
    af78:	52800020 	mov	w0, #0x1                   	// #1
    af7c:	f901dff7 	str	x23, [sp, #952]
    af80:	f901e3e2 	str	x2, [sp, #960]
    af84:	97ffe92f 	bl	5440 <fwp_data.part.0.constprop.0>
    af88:	97ffe99b 	bl	55f4 <fwp_rc_fresh>
    af8c:	aa0003e2 	mov	x2, x0
    af90:	910f23e1 	add	x1, sp, #0x3c8
    af94:	52800020 	mov	w0, #0x1                   	// #1
    af98:	f901e7f5 	str	x21, [sp, #968]
    af9c:	f901ebe2 	str	x2, [sp, #976]
    afa0:	97ffe928 	bl	5440 <fwp_data.part.0.constprop.0>
    afa4:	9115c283 	add	x3, x20, #0x570
    afa8:	aa0003f5 	mov	x21, x0
    afac:	f949d861 	ldr	x1, [x3, #5040]
    afb0:	f949ec60 	ldr	x0, [x3, #5080]
    afb4:	cb0102a1 	sub	x1, x21, x1
    afb8:	eb00403f 	cmp	x1, x0, lsl #16
    afbc:	54000322 	b.cs	b020 <f0+0x1180>  // b.hs, b.nlast
    afc0:	d350fc22 	lsr	x2, x1, #16
    afc4:	f949fc63 	ldr	x3, [x3, #5112]
    afc8:	8b020842 	add	x2, x2, x2, lsl #2
    afcc:	d37df042 	lsl	x2, x2, #3
    afd0:	8b020060 	add	x0, x3, x2
    afd4:	f9401017 	ldr	x23, [x0, #32]
    afd8:	b4000257 	cbz	x23, b020 <f0+0x1180>
    afdc:	38626862 	ldrb	w2, [x3, x2]
    afe0:	7100085f 	cmp	w2, #0x2
    afe4:	54008c80 	b.eq	c174 <f0+0x22d4>  // b.none
    afe8:	7100045f 	cmp	w2, #0x1
    afec:	540001a1 	b.ne	b020 <f0+0x1180>  // b.any
    aff0:	29430002 	ldp	w2, w0, [x0, #24]
    aff4:	92403c21 	and	x1, x1, #0xffff
    aff8:	9b027c21 	mul	x1, x1, x2
    affc:	d360fc21 	lsr	x1, x1, #32
    b000:	eb00003f 	cmp	x1, x0
    b004:	540000e2 	b.cs	b020 <f0+0x1180>  // b.hs, b.nlast
    b008:	8b0102f7 	add	x23, x23, x1
    b00c:	394002e0 	ldrb	w0, [x23]
    b010:	7103fc1f 	cmp	w0, #0xff
    b014:	5400a0c0 	b.eq	c42c <f0+0x258c>  // b.none
    b018:	52800020 	mov	w0, #0x1                   	// #1
    b01c:	390002e0 	strb	w0, [x23]
    b020:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b024:	910f63e1 	add	x1, sp, #0x3d8
    b028:	52800020 	mov	w0, #0x1                   	// #1
    b02c:	f901efe2 	str	x2, [sp, #984]
    b030:	f901f3f5 	str	x21, [sp, #992]
    b034:	97ffe903 	bl	5440 <fwp_data.part.0.constprop.0>
    b038:	9115c283 	add	x3, x20, #0x570
    b03c:	aa0003f5 	mov	x21, x0
    b040:	f949d861 	ldr	x1, [x3, #5040]
    b044:	f949ec60 	ldr	x0, [x3, #5080]
    b048:	cb0102a1 	sub	x1, x21, x1
    b04c:	eb00403f 	cmp	x1, x0, lsl #16
    b050:	54000322 	b.cs	b0b4 <f0+0x1214>  // b.hs, b.nlast
    b054:	d350fc22 	lsr	x2, x1, #16
    b058:	f949fc63 	ldr	x3, [x3, #5112]
    b05c:	8b020842 	add	x2, x2, x2, lsl #2
    b060:	d37df042 	lsl	x2, x2, #3
    b064:	8b020060 	add	x0, x3, x2
    b068:	f9401017 	ldr	x23, [x0, #32]
    b06c:	b4000257 	cbz	x23, b0b4 <f0+0x1214>
    b070:	38626862 	ldrb	w2, [x3, x2]
    b074:	7100085f 	cmp	w2, #0x2
    b078:	54008780 	b.eq	c168 <f0+0x22c8>  // b.none
    b07c:	7100045f 	cmp	w2, #0x1
    b080:	540001a1 	b.ne	b0b4 <f0+0x1214>  // b.any
    b084:	29430002 	ldp	w2, w0, [x0, #24]
    b088:	92403c21 	and	x1, x1, #0xffff
    b08c:	9b027c21 	mul	x1, x1, x2
    b090:	d360fc21 	lsr	x1, x1, #32
    b094:	eb00003f 	cmp	x1, x0
    b098:	540000e2 	b.cs	b0b4 <f0+0x1214>  // b.hs, b.nlast
    b09c:	8b0102f7 	add	x23, x23, x1
    b0a0:	394002e0 	ldrb	w0, [x23]
    b0a4:	7103fc1f 	cmp	w0, #0xff
    b0a8:	54009c80 	b.eq	c438 <f0+0x2598>  // b.none
    b0ac:	52800020 	mov	w0, #0x1                   	// #1
    b0b0:	390002e0 	strb	w0, [x23]
    b0b4:	910fa3e1 	add	x1, sp, #0x3e8
    b0b8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b0bc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b0c0:	52800020 	mov	w0, #0x1                   	// #1
    b0c4:	f901f7f7 	str	x23, [sp, #1000]
    b0c8:	f901fbf5 	str	x21, [sp, #1008]
    b0cc:	97ffe8dd 	bl	5440 <fwp_data.part.0.constprop.0>
    b0d0:	97ffe949 	bl	55f4 <fwp_rc_fresh>
    b0d4:	aa0003e2 	mov	x2, x0
    b0d8:	910fe3e1 	add	x1, sp, #0x3f8
    b0dc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b0e0:	52800020 	mov	w0, #0x1                   	// #1
    b0e4:	f901fff5 	str	x21, [sp, #1016]
    b0e8:	f90203e2 	str	x2, [sp, #1024]
    b0ec:	97ffe8d5 	bl	5440 <fwp_data.part.0.constprop.0>
    b0f0:	97ffe941 	bl	55f4 <fwp_rc_fresh>
    b0f4:	aa0003e2 	mov	x2, x0
    b0f8:	911023e1 	add	x1, sp, #0x408
    b0fc:	52800020 	mov	w0, #0x1                   	// #1
    b100:	f90207f7 	str	x23, [sp, #1032]
    b104:	f9020be2 	str	x2, [sp, #1040]
    b108:	97ffe8ce 	bl	5440 <fwp_data.part.0.constprop.0>
    b10c:	97ffe93a 	bl	55f4 <fwp_rc_fresh>
    b110:	aa0003e2 	mov	x2, x0
    b114:	911063e1 	add	x1, sp, #0x418
    b118:	52800020 	mov	w0, #0x1                   	// #1
    b11c:	f9020ff5 	str	x21, [sp, #1048]
    b120:	f90213e2 	str	x2, [sp, #1056]
    b124:	97ffe8c7 	bl	5440 <fwp_data.part.0.constprop.0>
    b128:	97ffe933 	bl	55f4 <fwp_rc_fresh>
    b12c:	aa0003e2 	mov	x2, x0
    b130:	9110a3e1 	add	x1, sp, #0x428
    b134:	52800020 	mov	w0, #0x1                   	// #1
    b138:	f90217f7 	str	x23, [sp, #1064]
    b13c:	f9021be2 	str	x2, [sp, #1072]
    b140:	97ffe8c0 	bl	5440 <fwp_data.part.0.constprop.0>
    b144:	9115c283 	add	x3, x20, #0x570
    b148:	aa0003f5 	mov	x21, x0
    b14c:	f949d861 	ldr	x1, [x3, #5040]
    b150:	f949ec60 	ldr	x0, [x3, #5080]
    b154:	cb0102a1 	sub	x1, x21, x1
    b158:	eb00403f 	cmp	x1, x0, lsl #16
    b15c:	54000322 	b.cs	b1c0 <f0+0x1320>  // b.hs, b.nlast
    b160:	d350fc22 	lsr	x2, x1, #16
    b164:	f949fc63 	ldr	x3, [x3, #5112]
    b168:	8b020842 	add	x2, x2, x2, lsl #2
    b16c:	d37df042 	lsl	x2, x2, #3
    b170:	8b020060 	add	x0, x3, x2
    b174:	f9401017 	ldr	x23, [x0, #32]
    b178:	b4000257 	cbz	x23, b1c0 <f0+0x1320>
    b17c:	38626862 	ldrb	w2, [x3, x2]
    b180:	7100085f 	cmp	w2, #0x2
    b184:	54007ec0 	b.eq	c15c <f0+0x22bc>  // b.none
    b188:	7100045f 	cmp	w2, #0x1
    b18c:	540001a1 	b.ne	b1c0 <f0+0x1320>  // b.any
    b190:	29430002 	ldp	w2, w0, [x0, #24]
    b194:	92403c21 	and	x1, x1, #0xffff
    b198:	9b027c21 	mul	x1, x1, x2
    b19c:	d360fc21 	lsr	x1, x1, #32
    b1a0:	eb00003f 	cmp	x1, x0
    b1a4:	540000e2 	b.cs	b1c0 <f0+0x1320>  // b.hs, b.nlast
    b1a8:	8b0102f7 	add	x23, x23, x1
    b1ac:	394002e0 	ldrb	w0, [x23]
    b1b0:	7103fc1f 	cmp	w0, #0xff
    b1b4:	54009480 	b.eq	c444 <f0+0x25a4>  // b.none
    b1b8:	52800020 	mov	w0, #0x1                   	// #1
    b1bc:	390002e0 	strb	w0, [x23]
    b1c0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b1c4:	9110e3e1 	add	x1, sp, #0x438
    b1c8:	52800020 	mov	w0, #0x1                   	// #1
    b1cc:	f9021fe2 	str	x2, [sp, #1080]
    b1d0:	f90223f5 	str	x21, [sp, #1088]
    b1d4:	97ffe89b 	bl	5440 <fwp_data.part.0.constprop.0>
    b1d8:	9115c283 	add	x3, x20, #0x570
    b1dc:	aa0003f5 	mov	x21, x0
    b1e0:	f949d861 	ldr	x1, [x3, #5040]
    b1e4:	f949ec60 	ldr	x0, [x3, #5080]
    b1e8:	cb0102a1 	sub	x1, x21, x1
    b1ec:	eb00403f 	cmp	x1, x0, lsl #16
    b1f0:	54000322 	b.cs	b254 <f0+0x13b4>  // b.hs, b.nlast
    b1f4:	d350fc22 	lsr	x2, x1, #16
    b1f8:	f949fc63 	ldr	x3, [x3, #5112]
    b1fc:	8b020842 	add	x2, x2, x2, lsl #2
    b200:	d37df042 	lsl	x2, x2, #3
    b204:	8b020060 	add	x0, x3, x2
    b208:	f9401017 	ldr	x23, [x0, #32]
    b20c:	b4000257 	cbz	x23, b254 <f0+0x13b4>
    b210:	38626862 	ldrb	w2, [x3, x2]
    b214:	7100085f 	cmp	w2, #0x2
    b218:	54008860 	b.eq	c324 <f0+0x2484>  // b.none
    b21c:	7100045f 	cmp	w2, #0x1
    b220:	540001a1 	b.ne	b254 <f0+0x13b4>  // b.any
    b224:	29430002 	ldp	w2, w0, [x0, #24]
    b228:	92403c21 	and	x1, x1, #0xffff
    b22c:	9b027c21 	mul	x1, x1, x2
    b230:	d360fc21 	lsr	x1, x1, #32
    b234:	eb00003f 	cmp	x1, x0
    b238:	540000e2 	b.cs	b254 <f0+0x13b4>  // b.hs, b.nlast
    b23c:	8b0102f7 	add	x23, x23, x1
    b240:	394002e0 	ldrb	w0, [x23]
    b244:	7103fc1f 	cmp	w0, #0xff
    b248:	54009040 	b.eq	c450 <f0+0x25b0>  // b.none
    b24c:	52800020 	mov	w0, #0x1                   	// #1
    b250:	390002e0 	strb	w0, [x23]
    b254:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b258:	911123e1 	add	x1, sp, #0x448
    b25c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b260:	52800020 	mov	w0, #0x1                   	// #1
    b264:	f90227e2 	str	x2, [sp, #1096]
    b268:	f9022bf5 	str	x21, [sp, #1104]
    b26c:	97ffe875 	bl	5440 <fwp_data.part.0.constprop.0>
    b270:	9115c283 	add	x3, x20, #0x570
    b274:	aa0003f5 	mov	x21, x0
    b278:	f949d861 	ldr	x1, [x3, #5040]
    b27c:	f949ec60 	ldr	x0, [x3, #5080]
    b280:	cb0102a1 	sub	x1, x21, x1
    b284:	eb00403f 	cmp	x1, x0, lsl #16
    b288:	54000322 	b.cs	b2ec <f0+0x144c>  // b.hs, b.nlast
    b28c:	d350fc22 	lsr	x2, x1, #16
    b290:	f949fc63 	ldr	x3, [x3, #5112]
    b294:	8b020842 	add	x2, x2, x2, lsl #2
    b298:	d37df042 	lsl	x2, x2, #3
    b29c:	8b020060 	add	x0, x3, x2
    b2a0:	f9401017 	ldr	x23, [x0, #32]
    b2a4:	b4000257 	cbz	x23, b2ec <f0+0x144c>
    b2a8:	38626862 	ldrb	w2, [x3, x2]
    b2ac:	7100085f 	cmp	w2, #0x2
    b2b0:	54008340 	b.eq	c318 <f0+0x2478>  // b.none
    b2b4:	7100045f 	cmp	w2, #0x1
    b2b8:	540001a1 	b.ne	b2ec <f0+0x144c>  // b.any
    b2bc:	29430002 	ldp	w2, w0, [x0, #24]
    b2c0:	92403c21 	and	x1, x1, #0xffff
    b2c4:	9b027c21 	mul	x1, x1, x2
    b2c8:	d360fc21 	lsr	x1, x1, #32
    b2cc:	eb00003f 	cmp	x1, x0
    b2d0:	540000e2 	b.cs	b2ec <f0+0x144c>  // b.hs, b.nlast
    b2d4:	8b0102f7 	add	x23, x23, x1
    b2d8:	394002e0 	ldrb	w0, [x23]
    b2dc:	7103fc1f 	cmp	w0, #0xff
    b2e0:	54008be0 	b.eq	c45c <f0+0x25bc>  // b.none
    b2e4:	52800020 	mov	w0, #0x1                   	// #1
    b2e8:	390002e0 	strb	w0, [x23]
    b2ec:	911163e1 	add	x1, sp, #0x458
    b2f0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b2f4:	52800020 	mov	w0, #0x1                   	// #1
    b2f8:	f9022ff7 	str	x23, [sp, #1112]
    b2fc:	f90233f5 	str	x21, [sp, #1120]
    b300:	97ffe850 	bl	5440 <fwp_data.part.0.constprop.0>
    b304:	97ffe8bc 	bl	55f4 <fwp_rc_fresh>
    b308:	aa0003e2 	mov	x2, x0
    b30c:	9111a3e1 	add	x1, sp, #0x468
    b310:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b314:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b318:	52800020 	mov	w0, #0x1                   	// #1
    b31c:	f90237f5 	str	x21, [sp, #1128]
    b320:	f9023be2 	str	x2, [sp, #1136]
    b324:	97ffe847 	bl	5440 <fwp_data.part.0.constprop.0>
    b328:	97ffe8b3 	bl	55f4 <fwp_rc_fresh>
    b32c:	aa0003e2 	mov	x2, x0
    b330:	9111e3e1 	add	x1, sp, #0x478
    b334:	52800020 	mov	w0, #0x1                   	// #1
    b338:	f9023ff7 	str	x23, [sp, #1144]
    b33c:	f90243e2 	str	x2, [sp, #1152]
    b340:	97ffe840 	bl	5440 <fwp_data.part.0.constprop.0>
    b344:	97ffe8ac 	bl	55f4 <fwp_rc_fresh>
    b348:	aa0003e2 	mov	x2, x0
    b34c:	911223e1 	add	x1, sp, #0x488
    b350:	52800020 	mov	w0, #0x1                   	// #1
    b354:	f90247f5 	str	x21, [sp, #1160]
    b358:	f9024be2 	str	x2, [sp, #1168]
    b35c:	97ffe839 	bl	5440 <fwp_data.part.0.constprop.0>
    b360:	97ffe8a5 	bl	55f4 <fwp_rc_fresh>
    b364:	aa0003e2 	mov	x2, x0
    b368:	911263e1 	add	x1, sp, #0x498
    b36c:	52800020 	mov	w0, #0x1                   	// #1
    b370:	f9024ff7 	str	x23, [sp, #1176]
    b374:	f90253e2 	str	x2, [sp, #1184]
    b378:	97ffe832 	bl	5440 <fwp_data.part.0.constprop.0>
    b37c:	97ffe89e 	bl	55f4 <fwp_rc_fresh>
    b380:	aa0003e2 	mov	x2, x0
    b384:	9112a3e1 	add	x1, sp, #0x4a8
    b388:	52800020 	mov	w0, #0x1                   	// #1
    b38c:	f90257f5 	str	x21, [sp, #1192]
    b390:	f9025be2 	str	x2, [sp, #1200]
    b394:	97ffe82b 	bl	5440 <fwp_data.part.0.constprop.0>
    b398:	97ffe897 	bl	55f4 <fwp_rc_fresh>
    b39c:	aa0003e2 	mov	x2, x0
    b3a0:	9112e3e1 	add	x1, sp, #0x4b8
    b3a4:	52800020 	mov	w0, #0x1                   	// #1
    b3a8:	f9025ff7 	str	x23, [sp, #1208]
    b3ac:	f90263e2 	str	x2, [sp, #1216]
    b3b0:	97ffe824 	bl	5440 <fwp_data.part.0.constprop.0>
    b3b4:	97ffe890 	bl	55f4 <fwp_rc_fresh>
    b3b8:	aa0003e2 	mov	x2, x0
    b3bc:	911323e1 	add	x1, sp, #0x4c8
    b3c0:	52800020 	mov	w0, #0x1                   	// #1
    b3c4:	f90267f5 	str	x21, [sp, #1224]
    b3c8:	f9026be2 	str	x2, [sp, #1232]
    b3cc:	97ffe81d 	bl	5440 <fwp_data.part.0.constprop.0>
    b3d0:	9115c283 	add	x3, x20, #0x570
    b3d4:	aa0003f7 	mov	x23, x0
    b3d8:	f949d861 	ldr	x1, [x3, #5040]
    b3dc:	f949ec60 	ldr	x0, [x3, #5080]
    b3e0:	cb0102e1 	sub	x1, x23, x1
    b3e4:	eb00403f 	cmp	x1, x0, lsl #16
    b3e8:	54000322 	b.cs	b44c <f0+0x15ac>  // b.hs, b.nlast
    b3ec:	d350fc22 	lsr	x2, x1, #16
    b3f0:	f949fc63 	ldr	x3, [x3, #5112]
    b3f4:	8b020842 	add	x2, x2, x2, lsl #2
    b3f8:	d37df042 	lsl	x2, x2, #3
    b3fc:	8b020060 	add	x0, x3, x2
    b400:	f9401015 	ldr	x21, [x0, #32]
    b404:	b4000255 	cbz	x21, b44c <f0+0x15ac>
    b408:	38626862 	ldrb	w2, [x3, x2]
    b40c:	7100085f 	cmp	w2, #0x2
    b410:	540077e0 	b.eq	c30c <f0+0x246c>  // b.none
    b414:	7100045f 	cmp	w2, #0x1
    b418:	540001a1 	b.ne	b44c <f0+0x15ac>  // b.any
    b41c:	29430002 	ldp	w2, w0, [x0, #24]
    b420:	92403c21 	and	x1, x1, #0xffff
    b424:	9b027c21 	mul	x1, x1, x2
    b428:	d360fc21 	lsr	x1, x1, #32
    b42c:	eb00003f 	cmp	x1, x0
    b430:	540000e2 	b.cs	b44c <f0+0x15ac>  // b.hs, b.nlast
    b434:	8b0102b5 	add	x21, x21, x1
    b438:	394002a0 	ldrb	w0, [x21]
    b43c:	7103fc1f 	cmp	w0, #0xff
    b440:	54008140 	b.eq	c468 <f0+0x25c8>  // b.none
    b444:	52800020 	mov	w0, #0x1                   	// #1
    b448:	390002a0 	strb	w0, [x21]
    b44c:	911363e1 	add	x1, sp, #0x4d8
    b450:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b454:	52800020 	mov	w0, #0x1                   	// #1
    b458:	f9026ff5 	str	x21, [sp, #1240]
    b45c:	f90273f7 	str	x23, [sp, #1248]
    b460:	97ffe7f8 	bl	5440 <fwp_data.part.0.constprop.0>
    b464:	97ffe864 	bl	55f4 <fwp_rc_fresh>
    b468:	aa0003e2 	mov	x2, x0
    b46c:	9113a3e1 	add	x1, sp, #0x4e8
    b470:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b474:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b478:	52800020 	mov	w0, #0x1                   	// #1
    b47c:	f90277f7 	str	x23, [sp, #1256]
    b480:	f9027be2 	str	x2, [sp, #1264]
    b484:	97ffe7ef 	bl	5440 <fwp_data.part.0.constprop.0>
    b488:	97ffe85b 	bl	55f4 <fwp_rc_fresh>
    b48c:	aa0003e2 	mov	x2, x0
    b490:	9113e3e1 	add	x1, sp, #0x4f8
    b494:	52800020 	mov	w0, #0x1                   	// #1
    b498:	f9027ff5 	str	x21, [sp, #1272]
    b49c:	f90283e2 	str	x2, [sp, #1280]
    b4a0:	97ffe7e8 	bl	5440 <fwp_data.part.0.constprop.0>
    b4a4:	97ffe854 	bl	55f4 <fwp_rc_fresh>
    b4a8:	aa0003e2 	mov	x2, x0
    b4ac:	911423e1 	add	x1, sp, #0x508
    b4b0:	52800020 	mov	w0, #0x1                   	// #1
    b4b4:	f90287f7 	str	x23, [sp, #1288]
    b4b8:	f9028be2 	str	x2, [sp, #1296]
    b4bc:	97ffe7e1 	bl	5440 <fwp_data.part.0.constprop.0>
    b4c0:	97ffe84d 	bl	55f4 <fwp_rc_fresh>
    b4c4:	aa0003e2 	mov	x2, x0
    b4c8:	911463e1 	add	x1, sp, #0x518
    b4cc:	52800020 	mov	w0, #0x1                   	// #1
    b4d0:	f9028ff5 	str	x21, [sp, #1304]
    b4d4:	f90293e2 	str	x2, [sp, #1312]
    b4d8:	97ffe7da 	bl	5440 <fwp_data.part.0.constprop.0>
    b4dc:	97ffe846 	bl	55f4 <fwp_rc_fresh>
    b4e0:	aa0003e2 	mov	x2, x0
    b4e4:	9114a3e1 	add	x1, sp, #0x528
    b4e8:	52800020 	mov	w0, #0x1                   	// #1
    b4ec:	f90297f7 	str	x23, [sp, #1320]
    b4f0:	f9029be2 	str	x2, [sp, #1328]
    b4f4:	97ffe7d3 	bl	5440 <fwp_data.part.0.constprop.0>
    b4f8:	97ffe83f 	bl	55f4 <fwp_rc_fresh>
    b4fc:	aa0003e2 	mov	x2, x0
    b500:	9114e3e1 	add	x1, sp, #0x538
    b504:	52800020 	mov	w0, #0x1                   	// #1
    b508:	f9029ff5 	str	x21, [sp, #1336]
    b50c:	f902a3e2 	str	x2, [sp, #1344]
    b510:	97ffe7cc 	bl	5440 <fwp_data.part.0.constprop.0>
    b514:	9115c283 	add	x3, x20, #0x570
    b518:	aa0003f5 	mov	x21, x0
    b51c:	f949d861 	ldr	x1, [x3, #5040]
    b520:	f949ec60 	ldr	x0, [x3, #5080]
    b524:	cb0102a1 	sub	x1, x21, x1
    b528:	eb00403f 	cmp	x1, x0, lsl #16
    b52c:	54000322 	b.cs	b590 <f0+0x16f0>  // b.hs, b.nlast
    b530:	d350fc22 	lsr	x2, x1, #16
    b534:	f949fc63 	ldr	x3, [x3, #5112]
    b538:	8b020842 	add	x2, x2, x2, lsl #2
    b53c:	d37df042 	lsl	x2, x2, #3
    b540:	8b020060 	add	x0, x3, x2
    b544:	f9401017 	ldr	x23, [x0, #32]
    b548:	b4000257 	cbz	x23, b590 <f0+0x16f0>
    b54c:	38626862 	ldrb	w2, [x3, x2]
    b550:	7100085f 	cmp	w2, #0x2
    b554:	54006d60 	b.eq	c300 <f0+0x2460>  // b.none
    b558:	7100045f 	cmp	w2, #0x1
    b55c:	540001a1 	b.ne	b590 <f0+0x16f0>  // b.any
    b560:	29430002 	ldp	w2, w0, [x0, #24]
    b564:	92403c21 	and	x1, x1, #0xffff
    b568:	9b027c21 	mul	x1, x1, x2
    b56c:	d360fc21 	lsr	x1, x1, #32
    b570:	eb00003f 	cmp	x1, x0
    b574:	540000e2 	b.cs	b590 <f0+0x16f0>  // b.hs, b.nlast
    b578:	8b0102f7 	add	x23, x23, x1
    b57c:	394002e0 	ldrb	w0, [x23]
    b580:	7103fc1f 	cmp	w0, #0xff
    b584:	54007780 	b.eq	c474 <f0+0x25d4>  // b.none
    b588:	52800020 	mov	w0, #0x1                   	// #1
    b58c:	390002e0 	strb	w0, [x23]
    b590:	911523e1 	add	x1, sp, #0x548
    b594:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b598:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b59c:	52800020 	mov	w0, #0x1                   	// #1
    b5a0:	f902a7f7 	str	x23, [sp, #1352]
    b5a4:	f902abf5 	str	x21, [sp, #1360]
    b5a8:	97ffe7a6 	bl	5440 <fwp_data.part.0.constprop.0>
    b5ac:	97ffe812 	bl	55f4 <fwp_rc_fresh>
    b5b0:	aa0003e2 	mov	x2, x0
    b5b4:	911563e1 	add	x1, sp, #0x558
    b5b8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b5bc:	52800020 	mov	w0, #0x1                   	// #1
    b5c0:	f902aff5 	str	x21, [sp, #1368]
    b5c4:	f902b3e2 	str	x2, [sp, #1376]
    b5c8:	97ffe79e 	bl	5440 <fwp_data.part.0.constprop.0>
    b5cc:	97ffe80a 	bl	55f4 <fwp_rc_fresh>
    b5d0:	aa0003e2 	mov	x2, x0
    b5d4:	9115a3e1 	add	x1, sp, #0x568
    b5d8:	52800020 	mov	w0, #0x1                   	// #1
    b5dc:	f902b7f7 	str	x23, [sp, #1384]
    b5e0:	f902bbe2 	str	x2, [sp, #1392]
    b5e4:	97ffe797 	bl	5440 <fwp_data.part.0.constprop.0>
    b5e8:	97ffe803 	bl	55f4 <fwp_rc_fresh>
    b5ec:	aa0003e2 	mov	x2, x0
    b5f0:	9115e3e1 	add	x1, sp, #0x578
    b5f4:	52800020 	mov	w0, #0x1                   	// #1
    b5f8:	f902bff5 	str	x21, [sp, #1400]
    b5fc:	f902c3e2 	str	x2, [sp, #1408]
    b600:	97ffe790 	bl	5440 <fwp_data.part.0.constprop.0>
    b604:	97ffe7fc 	bl	55f4 <fwp_rc_fresh>
    b608:	aa0003e2 	mov	x2, x0
    b60c:	911623e1 	add	x1, sp, #0x588
    b610:	52800020 	mov	w0, #0x1                   	// #1
    b614:	f902c7f7 	str	x23, [sp, #1416]
    b618:	f902cbe2 	str	x2, [sp, #1424]
    b61c:	97ffe789 	bl	5440 <fwp_data.part.0.constprop.0>
    b620:	9115c283 	add	x3, x20, #0x570
    b624:	aa0003f7 	mov	x23, x0
    b628:	f949d861 	ldr	x1, [x3, #5040]
    b62c:	f949ec60 	ldr	x0, [x3, #5080]
    b630:	cb0102e1 	sub	x1, x23, x1
    b634:	eb00403f 	cmp	x1, x0, lsl #16
    b638:	54000322 	b.cs	b69c <f0+0x17fc>  // b.hs, b.nlast
    b63c:	d350fc22 	lsr	x2, x1, #16
    b640:	f949fc63 	ldr	x3, [x3, #5112]
    b644:	8b020842 	add	x2, x2, x2, lsl #2
    b648:	d37df042 	lsl	x2, x2, #3
    b64c:	8b020060 	add	x0, x3, x2
    b650:	f9401015 	ldr	x21, [x0, #32]
    b654:	b4000255 	cbz	x21, b69c <f0+0x17fc>
    b658:	38626862 	ldrb	w2, [x3, x2]
    b65c:	7100085f 	cmp	w2, #0x2
    b660:	540064a0 	b.eq	c2f4 <f0+0x2454>  // b.none
    b664:	7100045f 	cmp	w2, #0x1
    b668:	540001a1 	b.ne	b69c <f0+0x17fc>  // b.any
    b66c:	29430002 	ldp	w2, w0, [x0, #24]
    b670:	92403c21 	and	x1, x1, #0xffff
    b674:	9b027c21 	mul	x1, x1, x2
    b678:	d360fc21 	lsr	x1, x1, #32
    b67c:	eb00003f 	cmp	x1, x0
    b680:	540000e2 	b.cs	b69c <f0+0x17fc>  // b.hs, b.nlast
    b684:	8b0102b5 	add	x21, x21, x1
    b688:	394002a0 	ldrb	w0, [x21]
    b68c:	7103fc1f 	cmp	w0, #0xff
    b690:	54006f80 	b.eq	c480 <f0+0x25e0>  // b.none
    b694:	52800020 	mov	w0, #0x1                   	// #1
    b698:	390002a0 	strb	w0, [x21]
    b69c:	911663e1 	add	x1, sp, #0x598
    b6a0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b6a4:	52800020 	mov	w0, #0x1                   	// #1
    b6a8:	f902cff5 	str	x21, [sp, #1432]
    b6ac:	f902d3f7 	str	x23, [sp, #1440]
    b6b0:	97ffe764 	bl	5440 <fwp_data.part.0.constprop.0>
    b6b4:	97ffe7d0 	bl	55f4 <fwp_rc_fresh>
    b6b8:	aa0003e2 	mov	x2, x0
    b6bc:	9116a3e1 	add	x1, sp, #0x5a8
    b6c0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b6c4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b6c8:	52800020 	mov	w0, #0x1                   	// #1
    b6cc:	f902d7f7 	str	x23, [sp, #1448]
    b6d0:	f902dbe2 	str	x2, [sp, #1456]
    b6d4:	97ffe75b 	bl	5440 <fwp_data.part.0.constprop.0>
    b6d8:	97ffe7c7 	bl	55f4 <fwp_rc_fresh>
    b6dc:	aa0003e2 	mov	x2, x0
    b6e0:	9116e3e1 	add	x1, sp, #0x5b8
    b6e4:	52800020 	mov	w0, #0x1                   	// #1
    b6e8:	f902dff5 	str	x21, [sp, #1464]
    b6ec:	f902e3e2 	str	x2, [sp, #1472]
    b6f0:	97ffe754 	bl	5440 <fwp_data.part.0.constprop.0>
    b6f4:	97ffe7c0 	bl	55f4 <fwp_rc_fresh>
    b6f8:	aa0003e2 	mov	x2, x0
    b6fc:	911723e1 	add	x1, sp, #0x5c8
    b700:	52800020 	mov	w0, #0x1                   	// #1
    b704:	f902e7f7 	str	x23, [sp, #1480]
    b708:	f902ebe2 	str	x2, [sp, #1488]
    b70c:	97ffe74d 	bl	5440 <fwp_data.part.0.constprop.0>
    b710:	97ffe7b9 	bl	55f4 <fwp_rc_fresh>
    b714:	aa0003e2 	mov	x2, x0
    b718:	911763e1 	add	x1, sp, #0x5d8
    b71c:	52800020 	mov	w0, #0x1                   	// #1
    b720:	f902eff5 	str	x21, [sp, #1496]
    b724:	f902f3e2 	str	x2, [sp, #1504]
    b728:	97ffe746 	bl	5440 <fwp_data.part.0.constprop.0>
    b72c:	97ffe7b2 	bl	55f4 <fwp_rc_fresh>
    b730:	aa0003e2 	mov	x2, x0
    b734:	9117a3e1 	add	x1, sp, #0x5e8
    b738:	52800020 	mov	w0, #0x1                   	// #1
    b73c:	f902f7f7 	str	x23, [sp, #1512]
    b740:	f902fbe2 	str	x2, [sp, #1520]
    b744:	97ffe73f 	bl	5440 <fwp_data.part.0.constprop.0>
    b748:	97ffe7ab 	bl	55f4 <fwp_rc_fresh>
    b74c:	aa0003e2 	mov	x2, x0
    b750:	9117e3e1 	add	x1, sp, #0x5f8
    b754:	52800020 	mov	w0, #0x1                   	// #1
    b758:	f902fff5 	str	x21, [sp, #1528]
    b75c:	f90303e2 	str	x2, [sp, #1536]
    b760:	97ffe738 	bl	5440 <fwp_data.part.0.constprop.0>
    b764:	97ffe7a4 	bl	55f4 <fwp_rc_fresh>
    b768:	aa0003e2 	mov	x2, x0
    b76c:	911823e1 	add	x1, sp, #0x608
    b770:	52800020 	mov	w0, #0x1                   	// #1
    b774:	f90307f7 	str	x23, [sp, #1544]
    b778:	f9030be2 	str	x2, [sp, #1552]
    b77c:	97ffe731 	bl	5440 <fwp_data.part.0.constprop.0>
    b780:	97ffe79d 	bl	55f4 <fwp_rc_fresh>
    b784:	aa0003e2 	mov	x2, x0
    b788:	911863e1 	add	x1, sp, #0x618
    b78c:	52800020 	mov	w0, #0x1                   	// #1
    b790:	f9030ff5 	str	x21, [sp, #1560]
    b794:	f90313e2 	str	x2, [sp, #1568]
    b798:	97ffe72a 	bl	5440 <fwp_data.part.0.constprop.0>
    b79c:	97ffe796 	bl	55f4 <fwp_rc_fresh>
    b7a0:	aa0003e2 	mov	x2, x0
    b7a4:	9118a3e1 	add	x1, sp, #0x628
    b7a8:	52800020 	mov	w0, #0x1                   	// #1
    b7ac:	f90317f7 	str	x23, [sp, #1576]
    b7b0:	f9031be2 	str	x2, [sp, #1584]
    b7b4:	97ffe723 	bl	5440 <fwp_data.part.0.constprop.0>
    b7b8:	97ffe78f 	bl	55f4 <fwp_rc_fresh>
    b7bc:	aa0003e2 	mov	x2, x0
    b7c0:	9118e3e1 	add	x1, sp, #0x638
    b7c4:	52800020 	mov	w0, #0x1                   	// #1
    b7c8:	f9031ff5 	str	x21, [sp, #1592]
    b7cc:	f90323e2 	str	x2, [sp, #1600]
    b7d0:	97ffe71c 	bl	5440 <fwp_data.part.0.constprop.0>
    b7d4:	9115c283 	add	x3, x20, #0x570
    b7d8:	aa0003f5 	mov	x21, x0
    b7dc:	f949d861 	ldr	x1, [x3, #5040]
    b7e0:	f949ec60 	ldr	x0, [x3, #5080]
    b7e4:	cb0102a1 	sub	x1, x21, x1
    b7e8:	eb00403f 	cmp	x1, x0, lsl #16
    b7ec:	54000322 	b.cs	b850 <f0+0x19b0>  // b.hs, b.nlast
    b7f0:	d350fc22 	lsr	x2, x1, #16
    b7f4:	f949fc63 	ldr	x3, [x3, #5112]
    b7f8:	8b020842 	add	x2, x2, x2, lsl #2
    b7fc:	d37df042 	lsl	x2, x2, #3
    b800:	8b020060 	add	x0, x3, x2
    b804:	f9401017 	ldr	x23, [x0, #32]
    b808:	b4000257 	cbz	x23, b850 <f0+0x19b0>
    b80c:	38626862 	ldrb	w2, [x3, x2]
    b810:	7100085f 	cmp	w2, #0x2
    b814:	540056a0 	b.eq	c2e8 <f0+0x2448>  // b.none
    b818:	7100045f 	cmp	w2, #0x1
    b81c:	540001a1 	b.ne	b850 <f0+0x19b0>  // b.any
    b820:	29430002 	ldp	w2, w0, [x0, #24]
    b824:	92403c21 	and	x1, x1, #0xffff
    b828:	9b027c21 	mul	x1, x1, x2
    b82c:	d360fc21 	lsr	x1, x1, #32
    b830:	eb00003f 	cmp	x1, x0
    b834:	540000e2 	b.cs	b850 <f0+0x19b0>  // b.hs, b.nlast
    b838:	8b0102f7 	add	x23, x23, x1
    b83c:	394002e0 	ldrb	w0, [x23]
    b840:	7103fc1f 	cmp	w0, #0xff
    b844:	54006240 	b.eq	c48c <f0+0x25ec>  // b.none
    b848:	52800020 	mov	w0, #0x1                   	// #1
    b84c:	390002e0 	strb	w0, [x23]
    b850:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b854:	911923e1 	add	x1, sp, #0x648
    b858:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b85c:	52800020 	mov	w0, #0x1                   	// #1
    b860:	f90327e2 	str	x2, [sp, #1608]
    b864:	f9032bf5 	str	x21, [sp, #1616]
    b868:	97ffe6f6 	bl	5440 <fwp_data.part.0.constprop.0>
    b86c:	9115c283 	add	x3, x20, #0x570
    b870:	aa0003f5 	mov	x21, x0
    b874:	f949d861 	ldr	x1, [x3, #5040]
    b878:	f949ec60 	ldr	x0, [x3, #5080]
    b87c:	cb0102a1 	sub	x1, x21, x1
    b880:	eb00403f 	cmp	x1, x0, lsl #16
    b884:	54000322 	b.cs	b8e8 <f0+0x1a48>  // b.hs, b.nlast
    b888:	d350fc22 	lsr	x2, x1, #16
    b88c:	f949fc63 	ldr	x3, [x3, #5112]
    b890:	8b020842 	add	x2, x2, x2, lsl #2
    b894:	d37df042 	lsl	x2, x2, #3
    b898:	8b020060 	add	x0, x3, x2
    b89c:	f9401017 	ldr	x23, [x0, #32]
    b8a0:	b4000257 	cbz	x23, b8e8 <f0+0x1a48>
    b8a4:	38626862 	ldrb	w2, [x3, x2]
    b8a8:	7100085f 	cmp	w2, #0x2
    b8ac:	54005180 	b.eq	c2dc <f0+0x243c>  // b.none
    b8b0:	7100045f 	cmp	w2, #0x1
    b8b4:	540001a1 	b.ne	b8e8 <f0+0x1a48>  // b.any
    b8b8:	29430002 	ldp	w2, w0, [x0, #24]
    b8bc:	92403c21 	and	x1, x1, #0xffff
    b8c0:	9b027c21 	mul	x1, x1, x2
    b8c4:	d360fc21 	lsr	x1, x1, #32
    b8c8:	eb00003f 	cmp	x1, x0
    b8cc:	540000e2 	b.cs	b8e8 <f0+0x1a48>  // b.hs, b.nlast
    b8d0:	8b0102f7 	add	x23, x23, x1
    b8d4:	394002e0 	ldrb	w0, [x23]
    b8d8:	7103fc1f 	cmp	w0, #0xff
    b8dc:	54005de0 	b.eq	c498 <f0+0x25f8>  // b.none
    b8e0:	52800020 	mov	w0, #0x1                   	// #1
    b8e4:	390002e0 	strb	w0, [x23]
    b8e8:	911963e1 	add	x1, sp, #0x658
    b8ec:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b8f0:	52800020 	mov	w0, #0x1                   	// #1
    b8f4:	f9032ff7 	str	x23, [sp, #1624]
    b8f8:	f90333f5 	str	x21, [sp, #1632]
    b8fc:	97ffe6d1 	bl	5440 <fwp_data.part.0.constprop.0>
    b900:	97ffe73d 	bl	55f4 <fwp_rc_fresh>
    b904:	aa0003e2 	mov	x2, x0
    b908:	9119a3e1 	add	x1, sp, #0x668
    b90c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b910:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b914:	52800020 	mov	w0, #0x1                   	// #1
    b918:	f90337f5 	str	x21, [sp, #1640]
    b91c:	f9033be2 	str	x2, [sp, #1648]
    b920:	97ffe6c8 	bl	5440 <fwp_data.part.0.constprop.0>
    b924:	97ffe734 	bl	55f4 <fwp_rc_fresh>
    b928:	aa0003e2 	mov	x2, x0
    b92c:	9119e3e1 	add	x1, sp, #0x678
    b930:	52800020 	mov	w0, #0x1                   	// #1
    b934:	f9033ff7 	str	x23, [sp, #1656]
    b938:	f90343e2 	str	x2, [sp, #1664]
    b93c:	97ffe6c1 	bl	5440 <fwp_data.part.0.constprop.0>
    b940:	97ffe72d 	bl	55f4 <fwp_rc_fresh>
    b944:	aa0003e2 	mov	x2, x0
    b948:	911a23e1 	add	x1, sp, #0x688
    b94c:	52800020 	mov	w0, #0x1                   	// #1
    b950:	f90347f5 	str	x21, [sp, #1672]
    b954:	f9034be2 	str	x2, [sp, #1680]
    b958:	97ffe6ba 	bl	5440 <fwp_data.part.0.constprop.0>
    b95c:	9115c283 	add	x3, x20, #0x570
    b960:	aa0003f5 	mov	x21, x0
    b964:	f949d861 	ldr	x1, [x3, #5040]
    b968:	f949ec60 	ldr	x0, [x3, #5080]
    b96c:	cb0102a1 	sub	x1, x21, x1
    b970:	eb00403f 	cmp	x1, x0, lsl #16
    b974:	54000322 	b.cs	b9d8 <f0+0x1b38>  // b.hs, b.nlast
    b978:	d350fc22 	lsr	x2, x1, #16
    b97c:	f949fc63 	ldr	x3, [x3, #5112]
    b980:	8b020842 	add	x2, x2, x2, lsl #2
    b984:	d37df042 	lsl	x2, x2, #3
    b988:	8b020060 	add	x0, x3, x2
    b98c:	f9401017 	ldr	x23, [x0, #32]
    b990:	b4000257 	cbz	x23, b9d8 <f0+0x1b38>
    b994:	38626862 	ldrb	w2, [x3, x2]
    b998:	7100085f 	cmp	w2, #0x2
    b99c:	540049a0 	b.eq	c2d0 <f0+0x2430>  // b.none
    b9a0:	7100045f 	cmp	w2, #0x1
    b9a4:	540001a1 	b.ne	b9d8 <f0+0x1b38>  // b.any
    b9a8:	29430002 	ldp	w2, w0, [x0, #24]
    b9ac:	92403c21 	and	x1, x1, #0xffff
    b9b0:	9b027c21 	mul	x1, x1, x2
    b9b4:	d360fc21 	lsr	x1, x1, #32
    b9b8:	eb00003f 	cmp	x1, x0
    b9bc:	540000e2 	b.cs	b9d8 <f0+0x1b38>  // b.hs, b.nlast
    b9c0:	8b0102f7 	add	x23, x23, x1
    b9c4:	394002e0 	ldrb	w0, [x23]
    b9c8:	7103fc1f 	cmp	w0, #0xff
    b9cc:	540056c0 	b.eq	c4a4 <f0+0x2604>  // b.none
    b9d0:	52800020 	mov	w0, #0x1                   	// #1
    b9d4:	390002e0 	strb	w0, [x23]
    b9d8:	911a63e1 	add	x1, sp, #0x698
    b9dc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b9e0:	52800020 	mov	w0, #0x1                   	// #1
    b9e4:	f9034ff7 	str	x23, [sp, #1688]
    b9e8:	f90353f5 	str	x21, [sp, #1696]
    b9ec:	97ffe695 	bl	5440 <fwp_data.part.0.constprop.0>
    b9f0:	97ffe701 	bl	55f4 <fwp_rc_fresh>
    b9f4:	aa0003e2 	mov	x2, x0
    b9f8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b9fc:	911aa3e1 	add	x1, sp, #0x6a8
    ba00:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ba04:	52800020 	mov	w0, #0x1                   	// #1
    ba08:	f90357e3 	str	x3, [sp, #1704]
    ba0c:	f9035be2 	str	x2, [sp, #1712]
    ba10:	97ffe68c 	bl	5440 <fwp_data.part.0.constprop.0>
    ba14:	97ffe6f8 	bl	55f4 <fwp_rc_fresh>
    ba18:	aa0003e2 	mov	x2, x0
    ba1c:	911ae3e1 	add	x1, sp, #0x6b8
    ba20:	52800020 	mov	w0, #0x1                   	// #1
    ba24:	f9035ff7 	str	x23, [sp, #1720]
    ba28:	f90363e2 	str	x2, [sp, #1728]
    ba2c:	97ffe685 	bl	5440 <fwp_data.part.0.constprop.0>
    ba30:	9115c283 	add	x3, x20, #0x570
    ba34:	aa0003f5 	mov	x21, x0
    ba38:	f949d861 	ldr	x1, [x3, #5040]
    ba3c:	f949ec60 	ldr	x0, [x3, #5080]
    ba40:	cb0102a1 	sub	x1, x21, x1
    ba44:	eb00403f 	cmp	x1, x0, lsl #16
    ba48:	54000322 	b.cs	baac <f0+0x1c0c>  // b.hs, b.nlast
    ba4c:	d350fc22 	lsr	x2, x1, #16
    ba50:	f949fc63 	ldr	x3, [x3, #5112]
    ba54:	8b020842 	add	x2, x2, x2, lsl #2
    ba58:	d37df042 	lsl	x2, x2, #3
    ba5c:	8b020060 	add	x0, x3, x2
    ba60:	f9401017 	ldr	x23, [x0, #32]
    ba64:	b4000257 	cbz	x23, baac <f0+0x1c0c>
    ba68:	38626862 	ldrb	w2, [x3, x2]
    ba6c:	7100085f 	cmp	w2, #0x2
    ba70:	540042a0 	b.eq	c2c4 <f0+0x2424>  // b.none
    ba74:	7100045f 	cmp	w2, #0x1
    ba78:	540001a1 	b.ne	baac <f0+0x1c0c>  // b.any
    ba7c:	29430002 	ldp	w2, w0, [x0, #24]
    ba80:	92403c21 	and	x1, x1, #0xffff
    ba84:	9b027c21 	mul	x1, x1, x2
    ba88:	d360fc21 	lsr	x1, x1, #32
    ba8c:	eb00003f 	cmp	x1, x0
    ba90:	540000e2 	b.cs	baac <f0+0x1c0c>  // b.hs, b.nlast
    ba94:	8b0102f7 	add	x23, x23, x1
    ba98:	394002e0 	ldrb	w0, [x23]
    ba9c:	7103fc1f 	cmp	w0, #0xff
    baa0:	54005080 	b.eq	c4b0 <f0+0x2610>  // b.none
    baa4:	52800020 	mov	w0, #0x1                   	// #1
    baa8:	390002e0 	strb	w0, [x23]
    baac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bab0:	911b23e1 	add	x1, sp, #0x6c8
    bab4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bab8:	52800020 	mov	w0, #0x1                   	// #1
    babc:	f90367e2 	str	x2, [sp, #1736]
    bac0:	f9036bf5 	str	x21, [sp, #1744]
    bac4:	97ffe65f 	bl	5440 <fwp_data.part.0.constprop.0>
    bac8:	9115c283 	add	x3, x20, #0x570
    bacc:	aa0003f7 	mov	x23, x0
    bad0:	f949d861 	ldr	x1, [x3, #5040]
    bad4:	f949ec60 	ldr	x0, [x3, #5080]
    bad8:	cb0102e1 	sub	x1, x23, x1
    badc:	eb00403f 	cmp	x1, x0, lsl #16
    bae0:	54000322 	b.cs	bb44 <f0+0x1ca4>  // b.hs, b.nlast
    bae4:	d350fc22 	lsr	x2, x1, #16
    bae8:	f949fc63 	ldr	x3, [x3, #5112]
    baec:	8b020842 	add	x2, x2, x2, lsl #2
    baf0:	d37df042 	lsl	x2, x2, #3
    baf4:	8b020060 	add	x0, x3, x2
    baf8:	f9401015 	ldr	x21, [x0, #32]
    bafc:	b4000255 	cbz	x21, bb44 <f0+0x1ca4>
    bb00:	38626862 	ldrb	w2, [x3, x2]
    bb04:	7100085f 	cmp	w2, #0x2
    bb08:	54003d80 	b.eq	c2b8 <f0+0x2418>  // b.none
    bb0c:	7100045f 	cmp	w2, #0x1
    bb10:	540001a1 	b.ne	bb44 <f0+0x1ca4>  // b.any
    bb14:	29430002 	ldp	w2, w0, [x0, #24]
    bb18:	92403c21 	and	x1, x1, #0xffff
    bb1c:	9b027c21 	mul	x1, x1, x2
    bb20:	d360fc21 	lsr	x1, x1, #32
    bb24:	eb00003f 	cmp	x1, x0
    bb28:	540000e2 	b.cs	bb44 <f0+0x1ca4>  // b.hs, b.nlast
    bb2c:	8b0102b5 	add	x21, x21, x1
    bb30:	394002a0 	ldrb	w0, [x21]
    bb34:	7103fc1f 	cmp	w0, #0xff
    bb38:	54004c20 	b.eq	c4bc <f0+0x261c>  // b.none
    bb3c:	52800020 	mov	w0, #0x1                   	// #1
    bb40:	390002a0 	strb	w0, [x21]
    bb44:	911b63e1 	add	x1, sp, #0x6d8
    bb48:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bb4c:	52800020 	mov	w0, #0x1                   	// #1
    bb50:	f9036ff5 	str	x21, [sp, #1752]
    bb54:	f90373f7 	str	x23, [sp, #1760]
    bb58:	97ffe63a 	bl	5440 <fwp_data.part.0.constprop.0>
    bb5c:	97ffe6a6 	bl	55f4 <fwp_rc_fresh>
    bb60:	aa0003e2 	mov	x2, x0
    bb64:	911ba3e1 	add	x1, sp, #0x6e8
    bb68:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bb6c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bb70:	52800020 	mov	w0, #0x1                   	// #1
    bb74:	f90377f7 	str	x23, [sp, #1768]
    bb78:	f9037be2 	str	x2, [sp, #1776]
    bb7c:	97ffe631 	bl	5440 <fwp_data.part.0.constprop.0>
    bb80:	97ffe69d 	bl	55f4 <fwp_rc_fresh>
    bb84:	aa0003e2 	mov	x2, x0
    bb88:	911be3e1 	add	x1, sp, #0x6f8
    bb8c:	52800020 	mov	w0, #0x1                   	// #1
    bb90:	f9037ff5 	str	x21, [sp, #1784]
    bb94:	f90383e2 	str	x2, [sp, #1792]
    bb98:	97ffe62a 	bl	5440 <fwp_data.part.0.constprop.0>
    bb9c:	97ffe696 	bl	55f4 <fwp_rc_fresh>
    bba0:	aa0003e2 	mov	x2, x0
    bba4:	911c23e1 	add	x1, sp, #0x708
    bba8:	52800020 	mov	w0, #0x1                   	// #1
    bbac:	f90387f7 	str	x23, [sp, #1800]
    bbb0:	f9038be2 	str	x2, [sp, #1808]
    bbb4:	97ffe623 	bl	5440 <fwp_data.part.0.constprop.0>
    bbb8:	97ffe68f 	bl	55f4 <fwp_rc_fresh>
    bbbc:	aa0003e2 	mov	x2, x0
    bbc0:	911c63e1 	add	x1, sp, #0x718
    bbc4:	52800020 	mov	w0, #0x1                   	// #1
    bbc8:	f9038ff5 	str	x21, [sp, #1816]
    bbcc:	f90393e2 	str	x2, [sp, #1824]
    bbd0:	97ffe61c 	bl	5440 <fwp_data.part.0.constprop.0>
    bbd4:	97ffe688 	bl	55f4 <fwp_rc_fresh>
    bbd8:	aa0003e2 	mov	x2, x0
    bbdc:	911ca3e1 	add	x1, sp, #0x728
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	f90397f7 	str	x23, [sp, #1832]
    bbe8:	f9039be2 	str	x2, [sp, #1840]
    bbec:	97ffe615 	bl	5440 <fwp_data.part.0.constprop.0>
    bbf0:	97ffe681 	bl	55f4 <fwp_rc_fresh>
    bbf4:	aa0003e2 	mov	x2, x0
    bbf8:	911ce3e1 	add	x1, sp, #0x738
    bbfc:	52800020 	mov	w0, #0x1                   	// #1
    bc00:	f9039ff5 	str	x21, [sp, #1848]
    bc04:	f903a3e2 	str	x2, [sp, #1856]
    bc08:	97ffe60e 	bl	5440 <fwp_data.part.0.constprop.0>
    bc0c:	9115c283 	add	x3, x20, #0x570
    bc10:	aa0003f5 	mov	x21, x0
    bc14:	f949d861 	ldr	x1, [x3, #5040]
    bc18:	f949ec60 	ldr	x0, [x3, #5080]
    bc1c:	cb0102a1 	sub	x1, x21, x1
    bc20:	eb00403f 	cmp	x1, x0, lsl #16
    bc24:	54000322 	b.cs	bc88 <f0+0x1de8>  // b.hs, b.nlast
    bc28:	d350fc22 	lsr	x2, x1, #16
    bc2c:	f949fc63 	ldr	x3, [x3, #5112]
    bc30:	8b020842 	add	x2, x2, x2, lsl #2
    bc34:	d37df042 	lsl	x2, x2, #3
    bc38:	8b020060 	add	x0, x3, x2
    bc3c:	f9401017 	ldr	x23, [x0, #32]
    bc40:	b4000257 	cbz	x23, bc88 <f0+0x1de8>
    bc44:	38626862 	ldrb	w2, [x3, x2]
    bc48:	7100085f 	cmp	w2, #0x2
    bc4c:	54003300 	b.eq	c2ac <f0+0x240c>  // b.none
    bc50:	7100045f 	cmp	w2, #0x1
    bc54:	540001a1 	b.ne	bc88 <f0+0x1de8>  // b.any
    bc58:	29430002 	ldp	w2, w0, [x0, #24]
    bc5c:	92403c21 	and	x1, x1, #0xffff
    bc60:	9b027c21 	mul	x1, x1, x2
    bc64:	d360fc21 	lsr	x1, x1, #32
    bc68:	eb00003f 	cmp	x1, x0
    bc6c:	540000e2 	b.cs	bc88 <f0+0x1de8>  // b.hs, b.nlast
    bc70:	8b0102f7 	add	x23, x23, x1
    bc74:	394002e0 	ldrb	w0, [x23]
    bc78:	7103fc1f 	cmp	w0, #0xff
    bc7c:	54004260 	b.eq	c4c8 <f0+0x2628>  // b.none
    bc80:	52800020 	mov	w0, #0x1                   	// #1
    bc84:	390002e0 	strb	w0, [x23]
    bc88:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bc8c:	911d23e1 	add	x1, sp, #0x748
    bc90:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bc94:	52800020 	mov	w0, #0x1                   	// #1
    bc98:	f903a7e2 	str	x2, [sp, #1864]
    bc9c:	f903abf5 	str	x21, [sp, #1872]
    bca0:	97ffe5e8 	bl	5440 <fwp_data.part.0.constprop.0>
    bca4:	9115c283 	add	x3, x20, #0x570
    bca8:	aa0003f5 	mov	x21, x0
    bcac:	f949d861 	ldr	x1, [x3, #5040]
    bcb0:	f949ec60 	ldr	x0, [x3, #5080]
    bcb4:	cb0102a1 	sub	x1, x21, x1
    bcb8:	eb00403f 	cmp	x1, x0, lsl #16
    bcbc:	54000322 	b.cs	bd20 <f0+0x1e80>  // b.hs, b.nlast
    bcc0:	d350fc22 	lsr	x2, x1, #16
    bcc4:	f949fc63 	ldr	x3, [x3, #5112]
    bcc8:	8b020842 	add	x2, x2, x2, lsl #2
    bccc:	d37df042 	lsl	x2, x2, #3
    bcd0:	8b020060 	add	x0, x3, x2
    bcd4:	f9401017 	ldr	x23, [x0, #32]
    bcd8:	b4000257 	cbz	x23, bd20 <f0+0x1e80>
    bcdc:	38626862 	ldrb	w2, [x3, x2]
    bce0:	7100085f 	cmp	w2, #0x2
    bce4:	54002de0 	b.eq	c2a0 <f0+0x2400>  // b.none
    bce8:	7100045f 	cmp	w2, #0x1
    bcec:	540001a1 	b.ne	bd20 <f0+0x1e80>  // b.any
    bcf0:	29430002 	ldp	w2, w0, [x0, #24]
    bcf4:	92403c21 	and	x1, x1, #0xffff
    bcf8:	9b027c21 	mul	x1, x1, x2
    bcfc:	d360fc21 	lsr	x1, x1, #32
    bd00:	eb00003f 	cmp	x1, x0
    bd04:	540000e2 	b.cs	bd20 <f0+0x1e80>  // b.hs, b.nlast
    bd08:	8b0102f7 	add	x23, x23, x1
    bd0c:	394002e0 	ldrb	w0, [x23]
    bd10:	7103fc1f 	cmp	w0, #0xff
    bd14:	54003e00 	b.eq	c4d4 <f0+0x2634>  // b.none
    bd18:	52800020 	mov	w0, #0x1                   	// #1
    bd1c:	390002e0 	strb	w0, [x23]
    bd20:	911d63e1 	add	x1, sp, #0x758
    bd24:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bd28:	52800020 	mov	w0, #0x1                   	// #1
    bd2c:	f903aff7 	str	x23, [sp, #1880]
    bd30:	f903b3f5 	str	x21, [sp, #1888]
    bd34:	97ffe5c3 	bl	5440 <fwp_data.part.0.constprop.0>
    bd38:	97ffe62f 	bl	55f4 <fwp_rc_fresh>
    bd3c:	aa0003e2 	mov	x2, x0
    bd40:	911da3e1 	add	x1, sp, #0x768
    bd44:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bd48:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bd4c:	52800020 	mov	w0, #0x1                   	// #1
    bd50:	f903b7f5 	str	x21, [sp, #1896]
    bd54:	f903bbe2 	str	x2, [sp, #1904]
    bd58:	97ffe5ba 	bl	5440 <fwp_data.part.0.constprop.0>
    bd5c:	97ffe626 	bl	55f4 <fwp_rc_fresh>
    bd60:	aa0003e2 	mov	x2, x0
    bd64:	911de3e1 	add	x1, sp, #0x778
    bd68:	52800020 	mov	w0, #0x1                   	// #1
    bd6c:	f903bff7 	str	x23, [sp, #1912]
    bd70:	f903c3e2 	str	x2, [sp, #1920]
    bd74:	97ffe5b3 	bl	5440 <fwp_data.part.0.constprop.0>
    bd78:	97ffe61f 	bl	55f4 <fwp_rc_fresh>
    bd7c:	aa0003e2 	mov	x2, x0
    bd80:	911e23e1 	add	x1, sp, #0x788
    bd84:	52800020 	mov	w0, #0x1                   	// #1
    bd88:	f903c7f5 	str	x21, [sp, #1928]
    bd8c:	f903cbe2 	str	x2, [sp, #1936]
    bd90:	97ffe5ac 	bl	5440 <fwp_data.part.0.constprop.0>
    bd94:	9115c283 	add	x3, x20, #0x570
    bd98:	aa0003f5 	mov	x21, x0
    bd9c:	f949d861 	ldr	x1, [x3, #5040]
    bda0:	f949ec60 	ldr	x0, [x3, #5080]
    bda4:	cb0102a1 	sub	x1, x21, x1
    bda8:	eb00403f 	cmp	x1, x0, lsl #16
    bdac:	54000322 	b.cs	be10 <f0+0x1f70>  // b.hs, b.nlast
    bdb0:	d350fc22 	lsr	x2, x1, #16
    bdb4:	f949fc63 	ldr	x3, [x3, #5112]
    bdb8:	8b020842 	add	x2, x2, x2, lsl #2
    bdbc:	d37df042 	lsl	x2, x2, #3
    bdc0:	8b020060 	add	x0, x3, x2
    bdc4:	f9401017 	ldr	x23, [x0, #32]
    bdc8:	b4000257 	cbz	x23, be10 <f0+0x1f70>
    bdcc:	38626862 	ldrb	w2, [x3, x2]
    bdd0:	7100085f 	cmp	w2, #0x2
    bdd4:	54002600 	b.eq	c294 <f0+0x23f4>  // b.none
    bdd8:	7100045f 	cmp	w2, #0x1
    bddc:	540001a1 	b.ne	be10 <f0+0x1f70>  // b.any
    bde0:	29430002 	ldp	w2, w0, [x0, #24]
    bde4:	92403c21 	and	x1, x1, #0xffff
    bde8:	9b027c21 	mul	x1, x1, x2
    bdec:	d360fc21 	lsr	x1, x1, #32
    bdf0:	eb00003f 	cmp	x1, x0
    bdf4:	540000e2 	b.cs	be10 <f0+0x1f70>  // b.hs, b.nlast
    bdf8:	8b0102f7 	add	x23, x23, x1
    bdfc:	394002e0 	ldrb	w0, [x23]
    be00:	7103fc1f 	cmp	w0, #0xff
    be04:	540036e0 	b.eq	c4e0 <f0+0x2640>  // b.none
    be08:	52800020 	mov	w0, #0x1                   	// #1
    be0c:	390002e0 	strb	w0, [x23]
    be10:	911e63e1 	add	x1, sp, #0x798
    be14:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    be18:	52800020 	mov	w0, #0x1                   	// #1
    be1c:	f903cff7 	str	x23, [sp, #1944]
    be20:	f903d3f5 	str	x21, [sp, #1952]
    be24:	97ffe587 	bl	5440 <fwp_data.part.0.constprop.0>
    be28:	97ffe5f3 	bl	55f4 <fwp_rc_fresh>
    be2c:	aa0003e2 	mov	x2, x0
    be30:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    be34:	911ea3e1 	add	x1, sp, #0x7a8
    be38:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    be3c:	52800020 	mov	w0, #0x1                   	// #1
    be40:	f903d7e3 	str	x3, [sp, #1960]
    be44:	f903dbe2 	str	x2, [sp, #1968]
    be48:	97ffe57e 	bl	5440 <fwp_data.part.0.constprop.0>
    be4c:	97ffe5ea 	bl	55f4 <fwp_rc_fresh>
    be50:	aa0003e2 	mov	x2, x0
    be54:	911ee3e1 	add	x1, sp, #0x7b8
    be58:	52800020 	mov	w0, #0x1                   	// #1
    be5c:	f903dff7 	str	x23, [sp, #1976]
    be60:	f903e3e2 	str	x2, [sp, #1984]
    be64:	97ffe577 	bl	5440 <fwp_data.part.0.constprop.0>
    be68:	9115c283 	add	x3, x20, #0x570
    be6c:	aa0003f5 	mov	x21, x0
    be70:	f949d861 	ldr	x1, [x3, #5040]
    be74:	f949ec60 	ldr	x0, [x3, #5080]
    be78:	cb0102a1 	sub	x1, x21, x1
    be7c:	eb00403f 	cmp	x1, x0, lsl #16
    be80:	54000322 	b.cs	bee4 <f0+0x2044>  // b.hs, b.nlast
    be84:	d350fc22 	lsr	x2, x1, #16
    be88:	f949fc63 	ldr	x3, [x3, #5112]
    be8c:	8b020842 	add	x2, x2, x2, lsl #2
    be90:	d37df042 	lsl	x2, x2, #3
    be94:	8b020060 	add	x0, x3, x2
    be98:	f9401017 	ldr	x23, [x0, #32]
    be9c:	b4000257 	cbz	x23, bee4 <f0+0x2044>
    bea0:	38626862 	ldrb	w2, [x3, x2]
    bea4:	7100085f 	cmp	w2, #0x2
    bea8:	54001f00 	b.eq	c288 <f0+0x23e8>  // b.none
    beac:	7100045f 	cmp	w2, #0x1
    beb0:	540001a1 	b.ne	bee4 <f0+0x2044>  // b.any
    beb4:	29430002 	ldp	w2, w0, [x0, #24]
    beb8:	92403c21 	and	x1, x1, #0xffff
    bebc:	9b027c21 	mul	x1, x1, x2
    bec0:	d360fc21 	lsr	x1, x1, #32
    bec4:	eb00003f 	cmp	x1, x0
    bec8:	540000e2 	b.cs	bee4 <f0+0x2044>  // b.hs, b.nlast
    becc:	8b0102f7 	add	x23, x23, x1
    bed0:	394002e0 	ldrb	w0, [x23]
    bed4:	7103fc1f 	cmp	w0, #0xff
    bed8:	540030a0 	b.eq	c4ec <f0+0x264c>  // b.none
    bedc:	52800020 	mov	w0, #0x1                   	// #1
    bee0:	390002e0 	strb	w0, [x23]
    bee4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bee8:	911f23e1 	add	x1, sp, #0x7c8
    beec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bef0:	52800020 	mov	w0, #0x1                   	// #1
    bef4:	f903e7e2 	str	x2, [sp, #1992]
    bef8:	f903ebf5 	str	x21, [sp, #2000]
    befc:	97ffe551 	bl	5440 <fwp_data.part.0.constprop.0>
    bf00:	9115c283 	add	x3, x20, #0x570
    bf04:	aa0003f5 	mov	x21, x0
    bf08:	f949d861 	ldr	x1, [x3, #5040]
    bf0c:	f949ec60 	ldr	x0, [x3, #5080]
    bf10:	cb0102a1 	sub	x1, x21, x1
    bf14:	eb00403f 	cmp	x1, x0, lsl #16
    bf18:	54000322 	b.cs	bf7c <f0+0x20dc>  // b.hs, b.nlast
    bf1c:	d350fc22 	lsr	x2, x1, #16
    bf20:	f949fc63 	ldr	x3, [x3, #5112]
    bf24:	8b020842 	add	x2, x2, x2, lsl #2
    bf28:	d37df042 	lsl	x2, x2, #3
    bf2c:	8b020060 	add	x0, x3, x2
    bf30:	f9401017 	ldr	x23, [x0, #32]
    bf34:	b4000257 	cbz	x23, bf7c <f0+0x20dc>
    bf38:	38626862 	ldrb	w2, [x3, x2]
    bf3c:	7100085f 	cmp	w2, #0x2
    bf40:	540019e0 	b.eq	c27c <f0+0x23dc>  // b.none
    bf44:	7100045f 	cmp	w2, #0x1
    bf48:	540001a1 	b.ne	bf7c <f0+0x20dc>  // b.any
    bf4c:	29430002 	ldp	w2, w0, [x0, #24]
    bf50:	92403c21 	and	x1, x1, #0xffff
    bf54:	9b027c21 	mul	x1, x1, x2
    bf58:	d360fc21 	lsr	x1, x1, #32
    bf5c:	eb00003f 	cmp	x1, x0
    bf60:	540000e2 	b.cs	bf7c <f0+0x20dc>  // b.hs, b.nlast
    bf64:	8b0102f7 	add	x23, x23, x1
    bf68:	394002e0 	ldrb	w0, [x23]
    bf6c:	7103fc1f 	cmp	w0, #0xff
    bf70:	54002c40 	b.eq	c4f8 <f0+0x2658>  // b.none
    bf74:	52800020 	mov	w0, #0x1                   	// #1
    bf78:	390002e0 	strb	w0, [x23]
    bf7c:	911f63e1 	add	x1, sp, #0x7d8
    bf80:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bf84:	52800020 	mov	w0, #0x1                   	// #1
    bf88:	f903eff7 	str	x23, [sp, #2008]
    bf8c:	f903f3f5 	str	x21, [sp, #2016]
    bf90:	97ffe52c 	bl	5440 <fwp_data.part.0.constprop.0>
    bf94:	97ffe598 	bl	55f4 <fwp_rc_fresh>
    bf98:	aa0003e2 	mov	x2, x0
    bf9c:	911fa3e1 	add	x1, sp, #0x7e8
    bfa0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bfa4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bfa8:	52800020 	mov	w0, #0x1                   	// #1
    bfac:	f903f7f5 	str	x21, [sp, #2024]
    bfb0:	9115c294 	add	x20, x20, #0x570
    bfb4:	f903fbe2 	str	x2, [sp, #2032]
    bfb8:	97ffe522 	bl	5440 <fwp_data.part.0.constprop.0>
    bfbc:	97ffe58e 	bl	55f4 <fwp_rc_fresh>
    bfc0:	aa0003e2 	mov	x2, x0
    bfc4:	911fe3e1 	add	x1, sp, #0x7f8
    bfc8:	52800020 	mov	w0, #0x1                   	// #1
    bfcc:	f903fff7 	str	x23, [sp, #2040]
    bfd0:	f90403e2 	str	x2, [sp, #2048]
    bfd4:	97ffe51b 	bl	5440 <fwp_data.part.0.constprop.0>
    bfd8:	97ffe587 	bl	55f4 <fwp_rc_fresh>
    bfdc:	aa0003e2 	mov	x2, x0
    bfe0:	912023e1 	add	x1, sp, #0x808
    bfe4:	52800020 	mov	w0, #0x1                   	// #1
    bfe8:	f90407f5 	str	x21, [sp, #2056]
    bfec:	f9040be2 	str	x2, [sp, #2064]
    bff0:	97ffe514 	bl	5440 <fwp_data.part.0.constprop.0>
    bff4:	97ffe580 	bl	55f4 <fwp_rc_fresh>
    bff8:	aa0003e2 	mov	x2, x0
    bffc:	912063e1 	add	x1, sp, #0x818
    c000:	52800020 	mov	w0, #0x1                   	// #1
    c004:	f9040ff7 	str	x23, [sp, #2072]
    c008:	f90413e2 	str	x2, [sp, #2080]
    c00c:	97ffe50d 	bl	5440 <fwp_data.part.0.constprop.0>
    c010:	97ffe579 	bl	55f4 <fwp_rc_fresh>
    c014:	aa0003e2 	mov	x2, x0
    c018:	9120a3e1 	add	x1, sp, #0x828
    c01c:	52800020 	mov	w0, #0x1                   	// #1
    c020:	f90417f5 	str	x21, [sp, #2088]
    c024:	f9041be2 	str	x2, [sp, #2096]
    c028:	97ffe506 	bl	5440 <fwp_data.part.0.constprop.0>
    c02c:	f949da81 	ldr	x1, [x20, #5040]
    c030:	aa0003f5 	mov	x21, x0
    c034:	f949ee80 	ldr	x0, [x20, #5080]
    c038:	cb0102a1 	sub	x1, x21, x1
    c03c:	eb00403f 	cmp	x1, x0, lsl #16
    c040:	54000322 	b.cs	c0a4 <f0+0x2204>  // b.hs, b.nlast
    c044:	d350fc22 	lsr	x2, x1, #16
    c048:	f949fe83 	ldr	x3, [x20, #5112]
    c04c:	8b020842 	add	x2, x2, x2, lsl #2
    c050:	d37df042 	lsl	x2, x2, #3
    c054:	8b020060 	add	x0, x3, x2
    c058:	f9401014 	ldr	x20, [x0, #32]
    c05c:	b4000254 	cbz	x20, c0a4 <f0+0x2204>
    c060:	38626862 	ldrb	w2, [x3, x2]
    c064:	7100085f 	cmp	w2, #0x2
    c068:	54001040 	b.eq	c270 <f0+0x23d0>  // b.none
    c06c:	7100045f 	cmp	w2, #0x1
    c070:	540001a1 	b.ne	c0a4 <f0+0x2204>  // b.any
    c074:	29430002 	ldp	w2, w0, [x0, #24]
    c078:	92403c21 	and	x1, x1, #0xffff
    c07c:	9b027c21 	mul	x1, x1, x2
    c080:	d360fc21 	lsr	x1, x1, #32
    c084:	eb00003f 	cmp	x1, x0
    c088:	540000e2 	b.cs	c0a4 <f0+0x2204>  // b.hs, b.nlast
    c08c:	8b010294 	add	x20, x20, x1
    c090:	39400280 	ldrb	w0, [x20]
    c094:	7103fc1f 	cmp	w0, #0xff
    c098:	540014c0 	b.eq	c330 <f0+0x2490>  // b.none
    c09c:	52800020 	mov	w0, #0x1                   	// #1
    c0a0:	39000280 	strb	w0, [x20]
    c0a4:	9120e3e1 	add	x1, sp, #0x838
    c0a8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c0ac:	52800020 	mov	w0, #0x1                   	// #1
    c0b0:	f9041fe2 	str	x2, [sp, #2104]
    c0b4:	f90423f5 	str	x21, [sp, #2112]
    c0b8:	97ffe4e2 	bl	5440 <fwp_data.part.0.constprop.0>
    c0bc:	97ffe54e 	bl	55f4 <fwp_rc_fresh>
    c0c0:	aa0003e2 	mov	x2, x0
    c0c4:	aa1603e1 	mov	x1, x22
    c0c8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c0cc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c0d0:	52800020 	mov	w0, #0x1                   	// #1
    c0d4:	f90427e3 	str	x3, [sp, #2120]
    c0d8:	f9042be2 	str	x2, [sp, #2128]
    c0dc:	97ffe4d9 	bl	5440 <fwp_data.part.0.constprop.0>
    c0e0:	97ffe545 	bl	55f4 <fwp_rc_fresh>
    c0e4:	aa0003f5 	mov	x21, x0
    c0e8:	aa1303e1 	mov	x1, x19
    c0ec:	97fff479 	bl	92d0 <fwp_hof0.constprop.0>
    c0f0:	aa0003f4 	mov	x20, x0
    c0f4:	aa1503e0 	mov	x0, x21
    c0f8:	97ffe69a 	bl	5b60 <fwp_drop0>
    c0fc:	aa1303e0 	mov	x0, x19
    c100:	97ffe698 	bl	5b60 <fwp_drop0>
    c104:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c108:	f947f400 	ldr	x0, [x0, #4072]
    c10c:	f9442fe2 	ldr	x2, [sp, #2136]
    c110:	f9400001 	ldr	x1, [x0]
    c114:	eb010042 	subs	x2, x2, x1
    c118:	d2800001 	mov	x1, #0x0                   	// #0
    c11c:	54001f41 	b.ne	c504 <f0+0x2664>  // b.any
    c120:	912183ff 	add	sp, sp, #0x860
    c124:	aa1403e0 	mov	x0, x20
    c128:	a94153f3 	ldp	x19, x20, [sp, #16]
    c12c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c130:	a94363f7 	ldp	x23, x24, [sp, #48]
    c134:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c138:	a94573fb 	ldp	x27, x28, [sp, #80]
    c13c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c140:	d65f03c0 	ret
    c144:	aa1b03e0 	mov	x0, x27
    c148:	97ffe0fe 	bl	4540 <fwp_rc_forget_slot>
    c14c:	17fff79d 	b	9fc0 <f0+0x120>
    c150:	72003c5f 	tst	w2, #0xffff
    c154:	54fef381 	b.ne	9fc4 <f0+0x124>  // b.any
    c158:	17fff797 	b	9fb4 <f0+0x114>
    c15c:	72003c3f 	tst	w1, #0xffff
    c160:	54ff8301 	b.ne	b1c0 <f0+0x1320>  // b.any
    c164:	17fffc12 	b	b1ac <f0+0x130c>
    c168:	72003c3f 	tst	w1, #0xffff
    c16c:	54ff7a41 	b.ne	b0b4 <f0+0x1214>  // b.any
    c170:	17fffbcc 	b	b0a0 <f0+0x1200>
    c174:	72003c3f 	tst	w1, #0xffff
    c178:	54ff7541 	b.ne	b020 <f0+0x1180>  // b.any
    c17c:	17fffba4 	b	b00c <f0+0x116c>
    c180:	72003c3f 	tst	w1, #0xffff
    c184:	54ff69e1 	b.ne	aec0 <f0+0x1020>  // b.any
    c188:	17fffb49 	b	aeac <f0+0x100c>
    c18c:	72003c3f 	tst	w1, #0xffff
    c190:	54ff64c1 	b.ne	ae28 <f0+0xf88>  // b.any
    c194:	17fffb20 	b	ae14 <f0+0xf74>
    c198:	72003c3f 	tst	w1, #0xffff
    c19c:	54ff5fc1 	b.ne	ad94 <f0+0xef4>  // b.any
    c1a0:	17fffaf8 	b	ad80 <f0+0xee0>
    c1a4:	72003c3f 	tst	w1, #0xffff
    c1a8:	54ff58c1 	b.ne	acc0 <f0+0xe20>  // b.any
    c1ac:	17fffac0 	b	acac <f0+0xe0c>
    c1b0:	72003c3f 	tst	w1, #0xffff
    c1b4:	54ff51c1 	b.ne	abec <f0+0xd4c>  // b.any
    c1b8:	17fffa88 	b	abd8 <f0+0xd38>
    c1bc:	72003c3f 	tst	w1, #0xffff
    c1c0:	54ff05e1 	b.ne	a27c <f0+0x3dc>  // b.any
    c1c4:	17fff829 	b	a268 <f0+0x3c8>
    c1c8:	72003c3f 	tst	w1, #0xffff
    c1cc:	54ff0001 	b.ne	a1cc <f0+0x32c>  // b.any
    c1d0:	17fff7fa 	b	a1b8 <f0+0x318>
    c1d4:	72003c3f 	tst	w1, #0xffff
    c1d8:	54fefb01 	b.ne	a138 <f0+0x298>  // b.any
    c1dc:	17fff7d2 	b	a124 <f0+0x284>
    c1e0:	72003c3f 	tst	w1, #0xffff
    c1e4:	54ff18c1 	b.ne	a4fc <f0+0x65c>  // b.any
    c1e8:	17fff8c0 	b	a4e8 <f0+0x648>
    c1ec:	72003c3f 	tst	w1, #0xffff
    c1f0:	54ff13c1 	b.ne	a468 <f0+0x5c8>  // b.any
    c1f4:	17fff898 	b	a454 <f0+0x5b4>
    c1f8:	72003c3f 	tst	w1, #0xffff
    c1fc:	54ff0ee1 	b.ne	a3d8 <f0+0x538>  // b.any
    c200:	17fff871 	b	a3c4 <f0+0x524>
    c204:	72003c3f 	tst	w1, #0xffff
    c208:	54ff09e1 	b.ne	a344 <f0+0x4a4>  // b.any
    c20c:	17fff849 	b	a330 <f0+0x490>
    c210:	72003c3f 	tst	w1, #0xffff
    c214:	54ff4a01 	b.ne	ab54 <f0+0xcb4>  // b.any
    c218:	17fffa4a 	b	ab40 <f0+0xca0>
    c21c:	72003c3f 	tst	w1, #0xffff
    c220:	54ff4301 	b.ne	aa80 <f0+0xbe0>  // b.any
    c224:	17fffa12 	b	aa6c <f0+0xbcc>
    c228:	72003c3f 	tst	w1, #0xffff
    c22c:	54ff3ce1 	b.ne	a9c8 <f0+0xb28>  // b.any
    c230:	17fff9e1 	b	a9b4 <f0+0xb14>
    c234:	72003c3f 	tst	w1, #0xffff
    c238:	54ff36c1 	b.ne	a910 <f0+0xa70>  // b.any
    c23c:	17fff9b0 	b	a8fc <f0+0xa5c>
    c240:	72003c3f 	tst	w1, #0xffff
    c244:	54ff30a1 	b.ne	a858 <f0+0x9b8>  // b.any
    c248:	17fff97f 	b	a844 <f0+0x9a4>
    c24c:	72003c3f 	tst	w1, #0xffff
    c250:	54ff28e1 	b.ne	a76c <f0+0x8cc>  // b.any
    c254:	17fff941 	b	a758 <f0+0x8b8>
    c258:	72003c3f 	tst	w1, #0xffff
    c25c:	54ff2181 	b.ne	a68c <f0+0x7ec>  // b.any
    c260:	17fff906 	b	a678 <f0+0x7d8>
    c264:	72003c3f 	tst	w1, #0xffff
    c268:	54ff1ba1 	b.ne	a5dc <f0+0x73c>  // b.any
    c26c:	17fff8d7 	b	a5c8 <f0+0x728>
    c270:	72003c3f 	tst	w1, #0xffff
    c274:	54fff181 	b.ne	c0a4 <f0+0x2204>  // b.any
    c278:	17ffff86 	b	c090 <f0+0x21f0>
    c27c:	72003c3f 	tst	w1, #0xffff
    c280:	54ffe7e1 	b.ne	bf7c <f0+0x20dc>  // b.any
    c284:	17ffff39 	b	bf68 <f0+0x20c8>
    c288:	72003c3f 	tst	w1, #0xffff
    c28c:	54ffe2c1 	b.ne	bee4 <f0+0x2044>  // b.any
    c290:	17ffff10 	b	bed0 <f0+0x2030>
    c294:	72003c3f 	tst	w1, #0xffff
    c298:	54ffdbc1 	b.ne	be10 <f0+0x1f70>  // b.any
    c29c:	17fffed8 	b	bdfc <f0+0x1f5c>
    c2a0:	72003c3f 	tst	w1, #0xffff
    c2a4:	54ffd3e1 	b.ne	bd20 <f0+0x1e80>  // b.any
    c2a8:	17fffe99 	b	bd0c <f0+0x1e6c>
    c2ac:	72003c3f 	tst	w1, #0xffff
    c2b0:	54ffcec1 	b.ne	bc88 <f0+0x1de8>  // b.any
    c2b4:	17fffe70 	b	bc74 <f0+0x1dd4>
    c2b8:	72003c3f 	tst	w1, #0xffff
    c2bc:	54ffc441 	b.ne	bb44 <f0+0x1ca4>  // b.any
    c2c0:	17fffe1c 	b	bb30 <f0+0x1c90>
    c2c4:	72003c3f 	tst	w1, #0xffff
    c2c8:	54ffbf21 	b.ne	baac <f0+0x1c0c>  // b.any
    c2cc:	17fffdf3 	b	ba98 <f0+0x1bf8>
    c2d0:	72003c3f 	tst	w1, #0xffff
    c2d4:	54ffb821 	b.ne	b9d8 <f0+0x1b38>  // b.any
    c2d8:	17fffdbb 	b	b9c4 <f0+0x1b24>
    c2dc:	72003c3f 	tst	w1, #0xffff
    c2e0:	54ffb041 	b.ne	b8e8 <f0+0x1a48>  // b.any
    c2e4:	17fffd7c 	b	b8d4 <f0+0x1a34>
    c2e8:	72003c3f 	tst	w1, #0xffff
    c2ec:	54ffab21 	b.ne	b850 <f0+0x19b0>  // b.any
    c2f0:	17fffd53 	b	b83c <f0+0x199c>
    c2f4:	72003c3f 	tst	w1, #0xffff
    c2f8:	54ff9d21 	b.ne	b69c <f0+0x17fc>  // b.any
    c2fc:	17fffce3 	b	b688 <f0+0x17e8>
    c300:	72003c3f 	tst	w1, #0xffff
    c304:	54ff9461 	b.ne	b590 <f0+0x16f0>  // b.any
    c308:	17fffc9d 	b	b57c <f0+0x16dc>
    c30c:	72003c3f 	tst	w1, #0xffff
    c310:	54ff89e1 	b.ne	b44c <f0+0x15ac>  // b.any
    c314:	17fffc49 	b	b438 <f0+0x1598>
    c318:	72003c3f 	tst	w1, #0xffff
    c31c:	54ff7e81 	b.ne	b2ec <f0+0x144c>  // b.any
    c320:	17fffbee 	b	b2d8 <f0+0x1438>
    c324:	72003c3f 	tst	w1, #0xffff
    c328:	54ff7961 	b.ne	b254 <f0+0x13b4>  // b.any
    c32c:	17fffbc5 	b	b240 <f0+0x13a0>
    c330:	aa1403e0 	mov	x0, x20
    c334:	97ffe083 	bl	4540 <fwp_rc_forget_slot>
    c338:	17ffff59 	b	c09c <f0+0x21fc>
    c33c:	aa1703e0 	mov	x0, x23
    c340:	97ffe080 	bl	4540 <fwp_rc_forget_slot>
    c344:	17fff77b 	b	a130 <f0+0x290>
    c348:	aa1703e0 	mov	x0, x23
    c34c:	97ffe07d 	bl	4540 <fwp_rc_forget_slot>
    c350:	17fff79d 	b	a1c4 <f0+0x324>
    c354:	aa1703e0 	mov	x0, x23
    c358:	97ffe07a 	bl	4540 <fwp_rc_forget_slot>
    c35c:	17fff7c6 	b	a274 <f0+0x3d4>
    c360:	aa1703e0 	mov	x0, x23
    c364:	97ffe077 	bl	4540 <fwp_rc_forget_slot>
    c368:	17fff7f5 	b	a33c <f0+0x49c>
    c36c:	aa1703e0 	mov	x0, x23
    c370:	97ffe074 	bl	4540 <fwp_rc_forget_slot>
    c374:	17fff817 	b	a3d0 <f0+0x530>
    c378:	aa1703e0 	mov	x0, x23
    c37c:	97ffe071 	bl	4540 <fwp_rc_forget_slot>
    c380:	17fff838 	b	a460 <f0+0x5c0>
    c384:	aa1703e0 	mov	x0, x23
    c388:	97ffe06e 	bl	4540 <fwp_rc_forget_slot>
    c38c:	17fff85a 	b	a4f4 <f0+0x654>
    c390:	aa1703e0 	mov	x0, x23
    c394:	97ffe06b 	bl	4540 <fwp_rc_forget_slot>
    c398:	17fff88f 	b	a5d4 <f0+0x734>
    c39c:	aa1703e0 	mov	x0, x23
    c3a0:	97ffe068 	bl	4540 <fwp_rc_forget_slot>
    c3a4:	17fff8b8 	b	a684 <f0+0x7e4>
    c3a8:	aa1703e0 	mov	x0, x23
    c3ac:	97ffe065 	bl	4540 <fwp_rc_forget_slot>
    c3b0:	17fff8ed 	b	a764 <f0+0x8c4>
    c3b4:	aa1703e0 	mov	x0, x23
    c3b8:	97ffe062 	bl	4540 <fwp_rc_forget_slot>
    c3bc:	17fff925 	b	a850 <f0+0x9b0>
    c3c0:	aa1703e0 	mov	x0, x23
    c3c4:	97ffe05f 	bl	4540 <fwp_rc_forget_slot>
    c3c8:	17fff950 	b	a908 <f0+0xa68>
    c3cc:	aa1703e0 	mov	x0, x23
    c3d0:	97ffe05c 	bl	4540 <fwp_rc_forget_slot>
    c3d4:	17fff97b 	b	a9c0 <f0+0xb20>
    c3d8:	aa1703e0 	mov	x0, x23
    c3dc:	97ffe059 	bl	4540 <fwp_rc_forget_slot>
    c3e0:	17fff9a6 	b	aa78 <f0+0xbd8>
    c3e4:	aa1703e0 	mov	x0, x23
    c3e8:	97ffe056 	bl	4540 <fwp_rc_forget_slot>
    c3ec:	17fff9d8 	b	ab4c <f0+0xcac>
    c3f0:	aa1703e0 	mov	x0, x23
    c3f4:	97ffe053 	bl	4540 <fwp_rc_forget_slot>
    c3f8:	17fff9fb 	b	abe4 <f0+0xd44>
    c3fc:	aa1703e0 	mov	x0, x23
    c400:	97ffe050 	bl	4540 <fwp_rc_forget_slot>
    c404:	17fffa2d 	b	acb8 <f0+0xe18>
    c408:	aa1703e0 	mov	x0, x23
    c40c:	97ffe04d 	bl	4540 <fwp_rc_forget_slot>
    c410:	17fffa5f 	b	ad8c <f0+0xeec>
    c414:	aa1703e0 	mov	x0, x23
    c418:	97ffe04a 	bl	4540 <fwp_rc_forget_slot>
    c41c:	17fffa81 	b	ae20 <f0+0xf80>
    c420:	aa1703e0 	mov	x0, x23
    c424:	97ffe047 	bl	4540 <fwp_rc_forget_slot>
    c428:	17fffaa4 	b	aeb8 <f0+0x1018>
    c42c:	aa1703e0 	mov	x0, x23
    c430:	97ffe044 	bl	4540 <fwp_rc_forget_slot>
    c434:	17fffaf9 	b	b018 <f0+0x1178>
    c438:	aa1703e0 	mov	x0, x23
    c43c:	97ffe041 	bl	4540 <fwp_rc_forget_slot>
    c440:	17fffb1b 	b	b0ac <f0+0x120c>
    c444:	aa1703e0 	mov	x0, x23
    c448:	97ffe03e 	bl	4540 <fwp_rc_forget_slot>
    c44c:	17fffb5b 	b	b1b8 <f0+0x1318>
    c450:	aa1703e0 	mov	x0, x23
    c454:	97ffe03b 	bl	4540 <fwp_rc_forget_slot>
    c458:	17fffb7d 	b	b24c <f0+0x13ac>
    c45c:	aa1703e0 	mov	x0, x23
    c460:	97ffe038 	bl	4540 <fwp_rc_forget_slot>
    c464:	17fffba0 	b	b2e4 <f0+0x1444>
    c468:	aa1503e0 	mov	x0, x21
    c46c:	97ffe035 	bl	4540 <fwp_rc_forget_slot>
    c470:	17fffbf5 	b	b444 <f0+0x15a4>
    c474:	aa1703e0 	mov	x0, x23
    c478:	97ffe032 	bl	4540 <fwp_rc_forget_slot>
    c47c:	17fffc43 	b	b588 <f0+0x16e8>
    c480:	aa1503e0 	mov	x0, x21
    c484:	97ffe02f 	bl	4540 <fwp_rc_forget_slot>
    c488:	17fffc83 	b	b694 <f0+0x17f4>
    c48c:	aa1703e0 	mov	x0, x23
    c490:	97ffe02c 	bl	4540 <fwp_rc_forget_slot>
    c494:	17fffced 	b	b848 <f0+0x19a8>
    c498:	aa1703e0 	mov	x0, x23
    c49c:	97ffe029 	bl	4540 <fwp_rc_forget_slot>
    c4a0:	17fffd10 	b	b8e0 <f0+0x1a40>
    c4a4:	aa1703e0 	mov	x0, x23
    c4a8:	97ffe026 	bl	4540 <fwp_rc_forget_slot>
    c4ac:	17fffd49 	b	b9d0 <f0+0x1b30>
    c4b0:	aa1703e0 	mov	x0, x23
    c4b4:	97ffe023 	bl	4540 <fwp_rc_forget_slot>
    c4b8:	17fffd7b 	b	baa4 <f0+0x1c04>
    c4bc:	aa1503e0 	mov	x0, x21
    c4c0:	97ffe020 	bl	4540 <fwp_rc_forget_slot>
    c4c4:	17fffd9e 	b	bb3c <f0+0x1c9c>
    c4c8:	aa1703e0 	mov	x0, x23
    c4cc:	97ffe01d 	bl	4540 <fwp_rc_forget_slot>
    c4d0:	17fffdec 	b	bc80 <f0+0x1de0>
    c4d4:	aa1703e0 	mov	x0, x23
    c4d8:	97ffe01a 	bl	4540 <fwp_rc_forget_slot>
    c4dc:	17fffe0f 	b	bd18 <f0+0x1e78>
    c4e0:	aa1703e0 	mov	x0, x23
    c4e4:	97ffe017 	bl	4540 <fwp_rc_forget_slot>
    c4e8:	17fffe48 	b	be08 <f0+0x1f68>
    c4ec:	aa1703e0 	mov	x0, x23
    c4f0:	97ffe014 	bl	4540 <fwp_rc_forget_slot>
    c4f4:	17fffe7a 	b	bedc <f0+0x203c>
    c4f8:	aa1703e0 	mov	x0, x23
    c4fc:	97ffe011 	bl	4540 <fwp_rc_forget_slot>
    c500:	17fffe9d 	b	bf74 <f0+0x20d4>
    c504:	97ffd8bb 	bl	27f0 <__stack_chk_fail@plt>
    c508:	d503201f 	nop
    c50c:	d503201f 	nop

000000000000c510 <fwp_main_thread>:
    c510:	d10443ff 	sub	sp, sp, #0x110
    c514:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c518:	f947f400 	ldr	x0, [x0, #4072]
    c51c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c520:	910303fd 	add	x29, sp, #0xc0
    c524:	a90d53f3 	stp	x19, x20, [sp, #208]
    c528:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc70>
    c52c:	9115c261 	add	x1, x19, #0x570
    c530:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c534:	b953a421 	ldr	w1, [x1, #5028]
    c538:	f9400002 	ldr	x2, [x0]
    c53c:	f9005fe2 	str	x2, [sp, #184]
    c540:	d2800002 	mov	x2, #0x0                   	// #0
    c544:	340025c1 	cbz	w1, c9fc <fwp_main_thread+0x4ec>
    c548:	9115c273 	add	x19, x19, #0x570
    c54c:	b953aa60 	ldr	w0, [x19, #5032]
    c550:	350024e0 	cbnz	w0, c9ec <fwp_main_thread+0x4dc>
    c554:	91001fe2 	add	x2, sp, #0x7
    c558:	900000b5 	adrp	x21, 20000 <__data_start>
    c55c:	900000a3 	adrp	x3, 20000 <__data_start>
    c560:	910102b3 	add	x19, x21, #0x40
    c564:	910e4063 	add	x3, x3, #0x390
    c568:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c56c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c570:	910023e0 	add	x0, sp, #0x8
    c574:	d2800001 	mov	x1, #0x0                   	// #0
    c578:	f90007e3 	str	x3, [sp, #8]
    c57c:	b90013ff 	str	wzr, [sp, #16]
    c580:	a9019262 	stp	x2, x4, [x19, #24]
    c584:	f9000fe5 	str	x5, [sp, #24]
    c588:	97ffd832 	bl	2650 <sigaltstack@plt>
    c58c:	35002520 	cbnz	w0, ca30 <fwp_main_thread+0x520>
    c590:	4f000400 	movi	v0.4s, #0x0
    c594:	9100a3e0 	add	x0, sp, #0x28
    c598:	d0ffffa1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    c59c:	52800082 	mov	w2, #0x4                   	// #4
    c5a0:	913fc021 	add	x1, x1, #0xff0
    c5a4:	72a10002 	movk	w2, #0x800, lsl #16
    c5a8:	910083f4 	add	x20, sp, #0x20
    c5ac:	f90013e1 	str	x1, [sp, #32]
    c5b0:	3d802000 	str	q0, [x0, #128]
    c5b4:	b900abe2 	str	w2, [sp, #168]
    c5b8:	ad000000 	stp	q0, q0, [x0]
    c5bc:	ad010000 	stp	q0, q0, [x0, #32]
    c5c0:	ad020000 	stp	q0, q0, [x0, #64]
    c5c4:	ad030000 	stp	q0, q0, [x0, #96]
    c5c8:	97ffd87a 	bl	27b0 <sigemptyset@plt>
    c5cc:	35002320 	cbnz	w0, ca30 <fwp_main_thread+0x520>
    c5d0:	aa1403e1 	mov	x1, x20
    c5d4:	d2800002 	mov	x2, #0x0                   	// #0
    c5d8:	52800160 	mov	w0, #0xb                   	// #11
    c5dc:	97ffd88d 	bl	2810 <sigaction@plt>
    c5e0:	35002280 	cbnz	w0, ca30 <fwp_main_thread+0x520>
    c5e4:	aa1403e1 	mov	x1, x20
    c5e8:	d2800002 	mov	x2, #0x0                   	// #0
    c5ec:	528000e0 	mov	w0, #0x7                   	// #7
    c5f0:	97ffd888 	bl	2810 <sigaction@plt>
    c5f4:	350021e0 	cbnz	w0, ca30 <fwp_main_thread+0x520>
    c5f8:	b9431a60 	ldr	w0, [x19, #792]
    c5fc:	a90f63f7 	stp	x23, x24, [sp, #240]
    c600:	34002020 	cbz	w0, ca04 <fwp_main_thread+0x4f4>
    c604:	910102b6 	add	x22, x21, #0x40
    c608:	f9400ad4 	ldr	x20, [x22, #16]
    c60c:	b40010d4 	cbz	x20, c824 <fwp_main_thread+0x314>
    c610:	aa1403f3 	mov	x19, x20
    c614:	91010297 	add	x23, x20, #0x40
    c618:	f90083f9 	str	x25, [sp, #256]
    c61c:	52800038 	mov	w24, #0x1                   	// #1
    c620:	39414a99 	ldrb	w25, [x20, #82]
    c624:	39014a98 	strb	w24, [x20, #82]
    c628:	f9401680 	ldr	x0, [x20, #40]
    c62c:	b4000620 	cbz	x0, c6f0 <fwp_main_thread+0x1e0>
    c630:	f9403281 	ldr	x1, [x20, #96]
    c634:	39414680 	ldrb	w0, [x20, #81]
    c638:	b4000b41 	cbz	x1, c7a0 <fwp_main_thread+0x290>
    c63c:	36000a80 	tbz	w0, #0, c78c <fwp_main_thread+0x27c>
    c640:	39414a62 	ldrb	w2, [x19, #82]
    c644:	f9402280 	ldr	x0, [x20, #64]
    c648:	37000d62 	tbnz	w2, #0, c7f4 <fwp_main_thread+0x2e4>
    c64c:	f9403261 	ldr	x1, [x19, #96]
    c650:	a911fe77 	stp	x23, xzr, [x19, #280]
    c654:	f9009660 	str	x0, [x19, #296]
    c658:	b4000040 	cbz	x0, c660 <fwp_main_thread+0x150>
    c65c:	f9009013 	str	x19, [x0, #288]
    c660:	f9002293 	str	x19, [x20, #64]
    c664:	b4000101 	cbz	x1, c684 <fwp_main_thread+0x174>
    c668:	f94056c0 	ldr	x0, [x22, #168]
    c66c:	39015678 	strb	w24, [x19, #85]
    c670:	f9003661 	str	x1, [x19, #104]
    c674:	a910827f 	stp	xzr, x0, [x19, #264]
    c678:	b4000040 	cbz	x0, c680 <fwp_main_thread+0x170>
    c67c:	f9008413 	str	x19, [x0, #264]
    c680:	f90056d3 	str	x19, [x22, #168]
    c684:	39015a7f 	strb	wzr, [x19, #86]
    c688:	97ffe76f 	bl	6444 <fwp_block>
    c68c:	f9408e62 	ldr	x2, [x19, #280]
    c690:	b4000142 	cbz	x2, c6b8 <fwp_main_thread+0x1a8>
    c694:	a9520261 	ldp	x1, x0, [x19, #288]
    c698:	b4000ba1 	cbz	x1, c80c <fwp_main_thread+0x2fc>
    c69c:	f9009420 	str	x0, [x1, #296]
    c6a0:	f9409660 	ldr	x0, [x19, #296]
    c6a4:	b4000040 	cbz	x0, c6ac <fwp_main_thread+0x19c>
    c6a8:	f9009001 	str	x1, [x0, #288]
    c6ac:	91080260 	add	x0, x19, #0x200
    c6b0:	f900967f 	str	xzr, [x19, #296]
    c6b4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c6b8:	39415660 	ldrb	w0, [x19, #85]
    c6bc:	f9400ac2 	ldr	x2, [x22, #16]
    c6c0:	36000960 	tbz	w0, #0, c7ec <fwp_main_thread+0x2dc>
    c6c4:	a9508261 	ldp	x1, x0, [x19, #264]
    c6c8:	b4000a61 	cbz	x1, c814 <fwp_main_thread+0x304>
    c6cc:	f9008820 	str	x0, [x1, #272]
    c6d0:	b4000040 	cbz	x0, c6d8 <fwp_main_thread+0x1c8>
    c6d4:	f9008401 	str	x1, [x0, #264]
    c6d8:	91080260 	add	x0, x19, #0x200
    c6dc:	3901567f 	strb	wzr, [x19, #85]
    c6e0:	aa0203f3 	mov	x19, x2
    c6e4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c6e8:	f9401680 	ldr	x0, [x20, #40]
    c6ec:	b5fffa20 	cbnz	x0, c630 <fwp_main_thread+0x120>
    c6f0:	910102a0 	add	x0, x21, #0x40
    c6f4:	39014a99 	strb	w25, [x20, #82]
    c6f8:	f94083f9 	ldr	x25, [sp, #256]
    c6fc:	f9417c00 	ldr	x0, [x0, #760]
    c700:	b4001560 	cbz	x0, c9ac <fwp_main_thread+0x49c>
    c704:	910102a0 	add	x0, x21, #0x40
    c708:	f9419801 	ldr	x1, [x0, #816]
    c70c:	b903281f 	str	wzr, [x0, #808]
    c710:	eb13003f 	cmp	x1, x19
    c714:	54001681 	b.ne	c9e4 <fwp_main_thread+0x4d4>  // b.any
    c718:	b4000913 	cbz	x19, c838 <fwp_main_thread+0x328>
    c71c:	910102a0 	add	x0, x21, #0x40
    c720:	52800021 	mov	w1, #0x1                   	// #1
    c724:	39014a61 	strb	w1, [x19, #82]
    c728:	f9416805 	ldr	x5, [x0, #720]
    c72c:	b4000865 	cbz	x5, c838 <fwp_main_thread+0x328>
    c730:	394140a0 	ldrb	w0, [x5, #80]
    c734:	37000060 	tbnz	w0, #0, c740 <fwp_main_thread+0x230>
    c738:	aa0503e0 	mov	x0, x5
    c73c:	97ffdb2d 	bl	33f0 <fwp_cancel_tree.part.0>
    c740:	f9409ca5 	ldr	x5, [x5, #312]
    c744:	b5ffff65 	cbnz	x5, c730 <fwp_main_thread+0x220>
    c748:	910102b4 	add	x20, x21, #0x40
    c74c:	52800036 	mov	w22, #0x1                   	// #1
    c750:	f9402a60 	ldr	x0, [x19, #80]
    c754:	f2001c1f 	tst	x0, #0xff000000ff
    c758:	540000e1 	b.ne	c774 <fwp_main_thread+0x264>  // b.any
    c75c:	f9401680 	ldr	x0, [x20, #40]
    c760:	39015276 	strb	w22, [x19, #84]
    c764:	f900827f 	str	xzr, [x19, #256]
    c768:	b40005a0 	cbz	x0, c81c <fwp_main_thread+0x30c>
    c76c:	f9008013 	str	x19, [x0, #256]
    c770:	f9001693 	str	x19, [x20, #40]
    c774:	97ffe734 	bl	6444 <fwp_block>
    c778:	97ffe6c6 	bl	6290 <fwp_free_zombie>
    c77c:	f9416a80 	ldr	x0, [x20, #720]
    c780:	b40005c0 	cbz	x0, c838 <fwp_main_thread+0x328>
    c784:	f9419a93 	ldr	x19, [x20, #816]
    c788:	17fffff2 	b	c750 <fwp_main_thread+0x240>
    c78c:	97ffdbbd 	bl	3680 <fwp_now_ns>
    c790:	f9403281 	ldr	x1, [x20, #96]
    c794:	eb01001f 	cmp	x0, x1
    c798:	54000fca 	b.ge	c990 <fwp_main_thread+0x480>  // b.tcont
    c79c:	39414680 	ldrb	w0, [x20, #81]
    c7a0:	39414a62 	ldrb	w2, [x19, #82]
    c7a4:	3707f500 	tbnz	w0, #0, c644 <fwp_main_thread+0x134>
    c7a8:	f9403281 	ldr	x1, [x20, #96]
    c7ac:	370001c2 	tbnz	w2, #0, c7e4 <fwp_main_thread+0x2d4>
    c7b0:	f9403260 	ldr	x0, [x19, #96]
    c7b4:	b4000180 	cbz	x0, c7e4 <fwp_main_thread+0x2d4>
    c7b8:	b4000061 	cbz	x1, c7c4 <fwp_main_thread+0x2b4>
    c7bc:	eb01001f 	cmp	x0, x1
    c7c0:	9a81d000 	csel	x0, x0, x1, le
    c7c4:	f9402281 	ldr	x1, [x20, #64]
    c7c8:	a911fe77 	stp	x23, xzr, [x19, #280]
    c7cc:	f9009661 	str	x1, [x19, #296]
    c7d0:	b4001241 	cbz	x1, ca18 <fwp_main_thread+0x508>
    c7d4:	f9009033 	str	x19, [x1, #288]
    c7d8:	aa0003e1 	mov	x1, x0
    c7dc:	f9002293 	str	x19, [x20, #64]
    c7e0:	17ffffa2 	b	c668 <fwp_main_thread+0x158>
    c7e4:	f9402280 	ldr	x0, [x20, #64]
    c7e8:	17ffff9a 	b	c650 <fwp_main_thread+0x140>
    c7ec:	aa0203f3 	mov	x19, x2
    c7f0:	17ffff8e 	b	c628 <fwp_main_thread+0x118>
    c7f4:	a911fe77 	stp	x23, xzr, [x19, #280]
    c7f8:	f9009660 	str	x0, [x19, #296]
    c7fc:	b4000040 	cbz	x0, c804 <fwp_main_thread+0x2f4>
    c800:	f9009013 	str	x19, [x0, #288]
    c804:	f9002293 	str	x19, [x20, #64]
    c808:	17ffff9f 	b	c684 <fwp_main_thread+0x174>
    c80c:	f9000040 	str	x0, [x2]
    c810:	17ffffa5 	b	c6a4 <fwp_main_thread+0x194>
    c814:	f90056c0 	str	x0, [x22, #168]
    c818:	17ffffae 	b	c6d0 <fwp_main_thread+0x1c0>
    c81c:	f9001a93 	str	x19, [x20, #48]
    c820:	17ffffd4 	b	c770 <fwp_main_thread+0x260>
    c824:	f9417ec0 	ldr	x0, [x22, #760]
    c828:	b4000c00 	cbz	x0, c9a8 <fwp_main_thread+0x498>
    c82c:	f9419ac0 	ldr	x0, [x22, #816]
    c830:	b9032adf 	str	wzr, [x22, #808]
    c834:	b5000d80 	cbnz	x0, c9e4 <fwp_main_thread+0x4d4>
    c838:	910102b4 	add	x20, x21, #0x40
    c83c:	97ffe695 	bl	6290 <fwp_free_zombie>
    c840:	f9401a80 	ldr	x0, [x20, #48]
    c844:	b5000d00 	cbnz	x0, c9e4 <fwp_main_thread+0x4d4>
    c848:	f9405680 	ldr	x0, [x20, #168]
    c84c:	b5000cc0 	cbnz	x0, c9e4 <fwp_main_thread+0x4d4>
    c850:	b940ca93 	ldr	w19, [x20, #200]
    c854:	340001d3 	cbz	w19, c88c <fwp_main_thread+0x37c>
    c858:	93407e76 	sxtw	x22, w19
    c85c:	51000673 	sub	w19, w19, #0x1
    c860:	d1000ad6 	sub	x22, x22, #0x2
    c864:	91034297 	add	x23, x20, #0xd0
    c868:	cb3342d6 	sub	x22, x22, w19, uxtw
    c86c:	93407e73 	sxtw	x19, w19
    c870:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c874:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c878:	b900ca93 	str	w19, [x20, #200]
    c87c:	d1000673 	sub	x19, x19, #0x1
    c880:	97ffd824 	bl	2910 <munmap@plt>
    c884:	eb16027f 	cmp	x19, x22
    c888:	54ffff41 	b.ne	c870 <fwp_main_thread+0x360>  // b.any
    c88c:	900000b3 	adrp	x19, 20000 <__data_start>
    c890:	91004260 	add	x0, x19, #0x10
    c894:	b9401000 	ldr	w0, [x0, #16]
    c898:	37f80040 	tbnz	w0, #31, c8a0 <fwp_main_thread+0x390>
    c89c:	97ffd7d9 	bl	2800 <close@plt>
    c8a0:	910102a0 	add	x0, x21, #0x40
    c8a4:	91004261 	add	x1, x19, #0x10
    c8a8:	12800002 	mov	w2, #0xffffffff            	// #-1
    c8ac:	d2800013 	mov	x19, #0x0                   	// #0
    c8b0:	f9419c16 	ldr	x22, [x0, #824]
    c8b4:	b9001022 	str	w2, [x1, #16]
    c8b8:	f941a014 	ldr	x20, [x0, #832]
    c8bc:	b4000176 	cbz	x22, c8e8 <fwp_main_thread+0x3d8>
    c8c0:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c8c4:	b40000c0 	cbz	x0, c8dc <fwp_main_thread+0x3cc>
    c8c8:	f9400001 	ldr	x1, [x0]
    c8cc:	b50008c1 	cbnz	x1, c9e4 <fwp_main_thread+0x4d4>
    c8d0:	f9400401 	ldr	x1, [x0, #8]
    c8d4:	b5000881 	cbnz	x1, c9e4 <fwp_main_thread+0x4d4>
    c8d8:	97ffdfba 	bl	47c0 <fwp_mem_free>
    c8dc:	91000673 	add	x19, x19, #0x1
    c8e0:	eb16027f 	cmp	x19, x22
    c8e4:	54fffee1 	b.ne	c8c0 <fwp_main_thread+0x3b0>  // b.any
    c8e8:	aa1403e0 	mov	x0, x20
    c8ec:	97ffdfb5 	bl	47c0 <fwp_mem_free>
    c8f0:	910102a0 	add	x0, x21, #0x40
    c8f4:	f9419813 	ldr	x19, [x0, #816]
    c8f8:	f9019c1f 	str	xzr, [x0, #824]
    c8fc:	f901a01f 	str	xzr, [x0, #832]
    c900:	b40001f3 	cbz	x19, c93c <fwp_main_thread+0x42c>
    c904:	f9401661 	ldr	x1, [x19, #40]
    c908:	b50006e1 	cbnz	x1, c9e4 <fwp_main_thread+0x4d4>
    c90c:	f9405661 	ldr	x1, [x19, #168]
    c910:	b50006a1 	cbnz	x1, c9e4 <fwp_main_thread+0x4d4>
    c914:	f9417c01 	ldr	x1, [x0, #760]
    c918:	b5000661 	cbnz	x1, c9e4 <fwp_main_thread+0x4d4>
    c91c:	f9418400 	ldr	x0, [x0, #776]
    c920:	b5000620 	cbnz	x0, c9e4 <fwp_main_thread+0x4d4>
    c924:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c928:	90000120 	adrp	x0, 30000 <alt.9+0xfc70>
    c92c:	910e4000 	add	x0, x0, #0x390
    c930:	97ffd7a4 	bl	27c0 <memset@plt>
    c934:	aa1303e0 	mov	x0, x19
    c938:	97ffdfa2 	bl	47c0 <fwp_mem_free>
    c93c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c940:	f947ec00 	ldr	x0, [x0, #4056]
    c944:	910102b5 	add	x21, x21, #0x40
    c948:	f9400000 	ldr	x0, [x0]
    c94c:	f9000abf 	str	xzr, [x21, #16]
    c950:	f9019abf 	str	xzr, [x21, #816]
    c954:	97ffd7f3 	bl	2920 <fflush@plt>
    c958:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c95c:	f947f400 	ldr	x0, [x0, #4072]
    c960:	f9405fe2 	ldr	x2, [sp, #184]
    c964:	f9400001 	ldr	x1, [x0]
    c968:	eb010042 	subs	x2, x2, x1
    c96c:	d2800001 	mov	x1, #0x0                   	// #0
    c970:	540006a1 	b.ne	ca44 <fwp_main_thread+0x534>  // b.any
    c974:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c978:	d2800000 	mov	x0, #0x0                   	// #0
    c97c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c980:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c984:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c988:	910443ff 	add	sp, sp, #0x110
    c98c:	d65f03c0 	ret
    c990:	39414280 	ldrb	w0, [x20, #80]
    c994:	3707f040 	tbnz	w0, #0, c79c <fwp_main_thread+0x28c>
    c998:	aa1403e0 	mov	x0, x20
    c99c:	97ffda95 	bl	33f0 <fwp_cancel_tree.part.0>
    c9a0:	39414680 	ldrb	w0, [x20, #81]
    c9a4:	17ffff7f 	b	c7a0 <fwp_main_thread+0x290>
    c9a8:	d2800013 	mov	x19, #0x0                   	// #0
    c9ac:	910102b4 	add	x20, x21, #0x40
    c9b0:	f9418680 	ldr	x0, [x20, #776]
    c9b4:	b5ffea80 	cbnz	x0, c704 <fwp_main_thread+0x1f4>
    c9b8:	f9417a80 	ldr	x0, [x20, #752]
    c9bc:	97ffdf81 	bl	47c0 <fwp_mem_free>
    c9c0:	f9017a9f 	str	xzr, [x20, #752]
    c9c4:	f901829f 	str	xzr, [x20, #768]
    c9c8:	f9419a80 	ldr	x0, [x20, #816]
    c9cc:	b40002d3 	cbz	x19, ca24 <fwp_main_thread+0x514>
    c9d0:	f900567f 	str	xzr, [x19, #168]
    c9d4:	f9005e7f 	str	xzr, [x19, #184]
    c9d8:	b9032a9f 	str	wzr, [x20, #808]
    c9dc:	eb00027f 	cmp	x19, x0
    c9e0:	54ffe9e0 	b.eq	c71c <fwp_main_thread+0x20c>  // b.none
    c9e4:	f90083f9 	str	x25, [sp, #256]
    c9e8:	97ffd796 	bl	2840 <abort@plt>
    c9ec:	f0ffffa0 	adrp	x0, 3000 <fwp_segv+0x10>
    c9f0:	91328000 	add	x0, x0, #0xca0
    c9f4:	940001d3 	bl	d140 <atexit>
    c9f8:	17fffed7 	b	c554 <fwp_main_thread+0x44>
    c9fc:	97ffdd02 	bl	3e04 <fwp_heap_init>
    ca00:	17fffed2 	b	c548 <fwp_main_thread+0x38>
    ca04:	97fff527 	bl	9ea0 <f0>
    ca08:	f9019260 	str	x0, [x19, #800]
    ca0c:	52800021 	mov	w1, #0x1                   	// #1
    ca10:	b9031a61 	str	w1, [x19, #792]
    ca14:	17fffefc 	b	c604 <fwp_main_thread+0xf4>
    ca18:	aa0003e1 	mov	x1, x0
    ca1c:	f9002293 	str	x19, [x20, #64]
    ca20:	17ffff12 	b	c668 <fwp_main_thread+0x158>
    ca24:	b9032a9f 	str	wzr, [x20, #808]
    ca28:	b4fff080 	cbz	x0, c838 <fwp_main_thread+0x328>
    ca2c:	17ffffee 	b	c9e4 <fwp_main_thread+0x4d4>
    ca30:	b0000000 	adrp	x0, d000 <__modti3+0x230>
    ca34:	911ca000 	add	x0, x0, #0x728
    ca38:	a90f63f7 	stp	x23, x24, [sp, #240]
    ca3c:	f90083f9 	str	x25, [sp, #256]
    ca40:	97ffdab0 	bl	3500 <fwp_trap>
    ca44:	f90083f9 	str	x25, [sp, #256]
    ca48:	97ffd76a 	bl	27f0 <__stack_chk_fail@plt>
    ca4c:	d503201f 	nop

000000000000ca50 <__divti3>:
    ca50:	d503245f 	bti	c
    ca54:	d2800004 	mov	x4, #0x0                   	// #0
    ca58:	b7f80721 	tbnz	x1, #63, cb3c <__divti3+0xec>
    ca5c:	b6f80083 	tbz	x3, #63, ca6c <__divti3+0x1c>
    ca60:	eb0203e2 	negs	x2, x2
    ca64:	aa2403e4 	mvn	x4, x4
    ca68:	da0303e3 	ngc	x3, x3
    ca6c:	aa0203e6 	mov	x6, x2
    ca70:	aa0003e7 	mov	x7, x0
    ca74:	aa0103e5 	mov	x5, x1
    ca78:	b5000583 	cbnz	x3, cb28 <__divti3+0xd8>
    ca7c:	eb01005f 	cmp	x2, x1
    ca80:	54000e69 	b.ls	cc4c <__divti3+0x1fc>  // b.plast
    ca84:	dac01040 	clz	x0, x2
    ca88:	b40000e0 	cbz	x0, caa4 <__divti3+0x54>
    ca8c:	4b0003e1 	neg	w1, w0
    ca90:	9ac020a5 	lsl	x5, x5, x0
    ca94:	9ac02046 	lsl	x6, x2, x0
    ca98:	9ac124e1 	lsr	x1, x7, x1
    ca9c:	aa050025 	orr	x5, x1, x5
    caa0:	9ac020e7 	lsl	x7, x7, x0
    caa4:	d360fcc8 	lsr	x8, x6, #32
    caa8:	92407cc2 	and	x2, x6, #0xffffffff
    caac:	9ac808a3 	udiv	x3, x5, x8
    cab0:	9b089465 	msub	x5, x3, x8, x5
    cab4:	aa0303e0 	mov	x0, x3
    cab8:	9b037c41 	mul	x1, x2, x3
    cabc:	93c780a5 	extr	x5, x5, x7, #32
    cac0:	eb05003f 	cmp	x1, x5
    cac4:	540000a9 	b.ls	cad8 <__divti3+0x88>  // b.plast
    cac8:	ab0500c5 	adds	x5, x6, x5
    cacc:	d1000460 	sub	x0, x3, #0x1
    cad0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    cad4:	540015a8 	b.hi	cd88 <__divti3+0x338>  // b.pmore
    cad8:	cb0100a5 	sub	x5, x5, x1
    cadc:	9ac808a3 	udiv	x3, x5, x8
    cae0:	9b089465 	msub	x5, x3, x8, x5
    cae4:	aa0303e1 	mov	x1, x3
    cae8:	9b037c42 	mul	x2, x2, x3
    caec:	aa0703e3 	mov	x3, x7
    caf0:	b3607ca3 	bfi	x3, x5, #32, #32
    caf4:	eb03005f 	cmp	x2, x3
    caf8:	540000c9 	b.ls	cb10 <__divti3+0xc0>  // b.plast
    cafc:	ab0300c3 	adds	x3, x6, x3
    cb00:	d1000425 	sub	x5, x1, #0x1
    cb04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cb08:	d1000821 	sub	x1, x1, #0x2
    cb0c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    cb10:	aa008020 	orr	x0, x1, x0, lsl #32
    cb14:	d2800001 	mov	x1, #0x0                   	// #0
    cb18:	b4000064 	cbz	x4, cb24 <__divti3+0xd4>
    cb1c:	eb0003e0 	negs	x0, x0
    cb20:	da0103e1 	ngc	x1, x1
    cb24:	d65f03c0 	ret
    cb28:	eb01007f 	cmp	x3, x1
    cb2c:	54000109 	b.ls	cb4c <__divti3+0xfc>  // b.plast
    cb30:	d2800001 	mov	x1, #0x0                   	// #0
    cb34:	d2800000 	mov	x0, #0x0                   	// #0
    cb38:	17fffff8 	b	cb18 <__divti3+0xc8>
    cb3c:	eb0003e0 	negs	x0, x0
    cb40:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cb44:	da0103e1 	ngc	x1, x1
    cb48:	17ffffc5 	b	ca5c <__divti3+0xc>
    cb4c:	dac01067 	clz	x7, x3
    cb50:	b40010e7 	cbz	x7, cd6c <__divti3+0x31c>
    cb54:	d2800805 	mov	x5, #0x40                  	// #64
    cb58:	cb0700a5 	sub	x5, x5, x7
    cb5c:	9ac72063 	lsl	x3, x3, x7
    cb60:	9ac52448 	lsr	x8, x2, x5
    cb64:	aa030108 	orr	x8, x8, x3
    cb68:	9ac52426 	lsr	x6, x1, x5
    cb6c:	92407d0a 	and	x10, x8, #0xffffffff
    cb70:	d360fd09 	lsr	x9, x8, #32
    cb74:	9ac52403 	lsr	x3, x0, x5
    cb78:	9ac72021 	lsl	x1, x1, x7
    cb7c:	aa010063 	orr	x3, x3, x1
    cb80:	9ac72042 	lsl	x2, x2, x7
    cb84:	9ac908cb 	udiv	x11, x6, x9
    cb88:	9b099965 	msub	x5, x11, x9, x6
    cb8c:	aa0b03e1 	mov	x1, x11
    cb90:	9b0b7d46 	mul	x6, x10, x11
    cb94:	93c380a5 	extr	x5, x5, x3, #32
    cb98:	eb0500df 	cmp	x6, x5
    cb9c:	540000a9 	b.ls	cbb0 <__divti3+0x160>  // b.plast
    cba0:	ab050105 	adds	x5, x8, x5
    cba4:	d1000561 	sub	x1, x11, #0x1
    cba8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cbac:	54000f48 	b.hi	cd94 <__divti3+0x344>  // b.pmore
    cbb0:	cb0600a6 	sub	x6, x5, x6
    cbb4:	9ac908cb 	udiv	x11, x6, x9
    cbb8:	9b099969 	msub	x9, x11, x9, x6
    cbbc:	aa0b03e5 	mov	x5, x11
    cbc0:	9b0b7d4a 	mul	x10, x10, x11
    cbc4:	b3607d23 	bfi	x3, x9, #32, #32
    cbc8:	eb03015f 	cmp	x10, x3
    cbcc:	540000a9 	b.ls	cbe0 <__divti3+0x190>  // b.plast
    cbd0:	ab030103 	adds	x3, x8, x3
    cbd4:	d1000565 	sub	x5, x11, #0x1
    cbd8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cbdc:	54000e28 	b.hi	cda0 <__divti3+0x350>  // b.pmore
    cbe0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cbe4:	92407c48 	and	x8, x2, #0xffffffff
    cbe8:	2a0503e5 	mov	w5, w5
    cbec:	d360fc42 	lsr	x2, x2, #32
    cbf0:	d360fc26 	lsr	x6, x1, #32
    cbf4:	cb0a0063 	sub	x3, x3, x10
    cbf8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cbfc:	9b087caa 	mul	x10, x5, x8
    cc00:	9b087cc8 	mul	x8, x6, x8
    cc04:	9b0220a5 	madd	x5, x5, x2, x8
    cc08:	9b027cc6 	mul	x6, x6, x2
    cc0c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cc10:	8b0900c5 	add	x5, x6, x9
    cc14:	eb02011f 	cmp	x8, x2
    cc18:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cc1c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cc20:	eb06007f 	cmp	x3, x6
    cc24:	540000e3 	b.cc	cc40 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cc28:	92407d4a 	and	x10, x10, #0xffffffff
    cc2c:	9ac72000 	lsl	x0, x0, x7
    cc30:	8b028142 	add	x2, x10, x2, lsl #32
    cc34:	eb02001f 	cmp	x0, x2
    cc38:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cc3c:	54000a01 	b.ne	cd7c <__divti3+0x32c>  // b.any
    cc40:	d1000420 	sub	x0, x1, #0x1
    cc44:	d2800001 	mov	x1, #0x0                   	// #0
    cc48:	17ffffb4 	b	cb18 <__divti3+0xc8>
    cc4c:	b5000062 	cbnz	x2, cc58 <__divti3+0x208>
    cc50:	d2800022 	mov	x2, #0x1                   	// #1
    cc54:	9ac30846 	udiv	x6, x2, x3
    cc58:	dac010c8 	clz	x8, x6
    cc5c:	b5000408 	cbnz	x8, ccdc <__divti3+0x28c>
    cc60:	d360fcc9 	lsr	x9, x6, #32
    cc64:	92407cc5 	and	x5, x6, #0xffffffff
    cc68:	cb060023 	sub	x3, x1, x6
    cc6c:	d2800021 	mov	x1, #0x1                   	// #1
    cc70:	9ac90868 	udiv	x8, x3, x9
    cc74:	9b098d03 	msub	x3, x8, x9, x3
    cc78:	aa0803e0 	mov	x0, x8
    cc7c:	9b057d02 	mul	x2, x8, x5
    cc80:	93c78063 	extr	x3, x3, x7, #32
    cc84:	eb03005f 	cmp	x2, x3
    cc88:	540000a9 	b.ls	cc9c <__divti3+0x24c>  // b.plast
    cc8c:	ab0300c3 	adds	x3, x6, x3
    cc90:	d1000500 	sub	x0, x8, #0x1
    cc94:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cc98:	54000968 	b.hi	cdc4 <__divti3+0x374>  // b.pmore
    cc9c:	cb020063 	sub	x3, x3, x2
    cca0:	9ac90862 	udiv	x2, x3, x9
    cca4:	aa0203e8 	mov	x8, x2
    cca8:	9b098c42 	msub	x2, x2, x9, x3
    ccac:	aa0703e3 	mov	x3, x7
    ccb0:	9b057d05 	mul	x5, x8, x5
    ccb4:	b3607c43 	bfi	x3, x2, #32, #32
    ccb8:	eb0300bf 	cmp	x5, x3
    ccbc:	540000c9 	b.ls	ccd4 <__divti3+0x284>  // b.plast
    ccc0:	ab0300c2 	adds	x2, x6, x3
    ccc4:	d1000503 	sub	x3, x8, #0x1
    ccc8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cccc:	d1000908 	sub	x8, x8, #0x2
    ccd0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ccd4:	aa008100 	orr	x0, x8, x0, lsl #32
    ccd8:	17ffff90 	b	cb18 <__divti3+0xc8>
    ccdc:	9ac820c6 	lsl	x6, x6, x8
    cce0:	d2800803 	mov	x3, #0x40                  	// #64
    cce4:	cb080063 	sub	x3, x3, x8
    cce8:	d360fcc9 	lsr	x9, x6, #32
    ccec:	9ac82027 	lsl	x7, x1, x8
    ccf0:	92407cc5 	and	x5, x6, #0xffffffff
    ccf4:	9ac32422 	lsr	x2, x1, x3
    ccf8:	9ac32403 	lsr	x3, x0, x3
    ccfc:	aa070063 	orr	x3, x3, x7
    cd00:	9ac9084a 	udiv	x10, x2, x9
    cd04:	9ac82007 	lsl	x7, x0, x8
    cd08:	9b098940 	msub	x0, x10, x9, x2
    cd0c:	aa0a03e1 	mov	x1, x10
    cd10:	9b0a7ca2 	mul	x2, x5, x10
    cd14:	93c38000 	extr	x0, x0, x3, #32
    cd18:	eb00005f 	cmp	x2, x0
    cd1c:	540000a9 	b.ls	cd30 <__divti3+0x2e0>  // b.plast
    cd20:	ab0000c0 	adds	x0, x6, x0
    cd24:	d1000541 	sub	x1, x10, #0x1
    cd28:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cd2c:	54000468 	b.hi	cdb8 <__divti3+0x368>  // b.pmore
    cd30:	cb020000 	sub	x0, x0, x2
    cd34:	9ac9080a 	udiv	x10, x0, x9
    cd38:	9b098140 	msub	x0, x10, x9, x0
    cd3c:	aa0a03e2 	mov	x2, x10
    cd40:	9b0a7ca8 	mul	x8, x5, x10
    cd44:	b3607c03 	bfi	x3, x0, #32, #32
    cd48:	eb03011f 	cmp	x8, x3
    cd4c:	540000a9 	b.ls	cd60 <__divti3+0x310>  // b.plast
    cd50:	ab0300c3 	adds	x3, x6, x3
    cd54:	d1000542 	sub	x2, x10, #0x1
    cd58:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cd5c:	54000288 	b.hi	cdac <__divti3+0x35c>  // b.pmore
    cd60:	cb080063 	sub	x3, x3, x8
    cd64:	aa018041 	orr	x1, x2, x1, lsl #32
    cd68:	17ffffc2 	b	cc70 <__divti3+0x220>
    cd6c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cd70:	d2800001 	mov	x1, #0x0                   	// #0
    cd74:	9a9f87e0 	cset	x0, ls	// ls = plast
    cd78:	17ffff68 	b	cb18 <__divti3+0xc8>
    cd7c:	aa0103e0 	mov	x0, x1
    cd80:	d2800001 	mov	x1, #0x0                   	// #0
    cd84:	17ffff65 	b	cb18 <__divti3+0xc8>
    cd88:	d1000860 	sub	x0, x3, #0x2
    cd8c:	8b0600a5 	add	x5, x5, x6
    cd90:	17ffff52 	b	cad8 <__divti3+0x88>
    cd94:	d1000961 	sub	x1, x11, #0x2
    cd98:	8b0800a5 	add	x5, x5, x8
    cd9c:	17ffff85 	b	cbb0 <__divti3+0x160>
    cda0:	d1000965 	sub	x5, x11, #0x2
    cda4:	8b080063 	add	x3, x3, x8
    cda8:	17ffff8e 	b	cbe0 <__divti3+0x190>
    cdac:	d1000942 	sub	x2, x10, #0x2
    cdb0:	8b060063 	add	x3, x3, x6
    cdb4:	17ffffeb 	b	cd60 <__divti3+0x310>
    cdb8:	d1000941 	sub	x1, x10, #0x2
    cdbc:	8b060000 	add	x0, x0, x6
    cdc0:	17ffffdc 	b	cd30 <__divti3+0x2e0>
    cdc4:	d1000900 	sub	x0, x8, #0x2
    cdc8:	8b060063 	add	x3, x3, x6
    cdcc:	17ffffb4 	b	cc9c <__divti3+0x24c>

000000000000cdd0 <__modti3>:
    cdd0:	d503245f 	bti	c
    cdd4:	d2800004 	mov	x4, #0x0                   	// #0
    cdd8:	b6f80081 	tbz	x1, #63, cde8 <__modti3+0x18>
    cddc:	eb0003e0 	negs	x0, x0
    cde0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cde4:	da0103e1 	ngc	x1, x1
    cde8:	f100007f 	cmp	x3, #0x0
    cdec:	5400128b 	b.lt	d03c <__modti3+0x26c>  // b.tstop
    cdf0:	aa0003e7 	mov	x7, x0
    cdf4:	aa0103e6 	mov	x6, x1
    cdf8:	540004e1 	b.ne	ce94 <__modti3+0xc4>  // b.any
    cdfc:	eb02003f 	cmp	x1, x2
    ce00:	54000dc2 	b.cs	cfb8 <__modti3+0x1e8>  // b.hs, b.nlast
    ce04:	dac01043 	clz	x3, x2
    ce08:	aa0303e5 	mov	x5, x3
    ce0c:	b40000e3 	cbz	x3, ce28 <__modti3+0x58>
    ce10:	4b0303e6 	neg	w6, w3
    ce14:	9ac32021 	lsl	x1, x1, x3
    ce18:	9ac32042 	lsl	x2, x2, x3
    ce1c:	9ac62406 	lsr	x6, x0, x6
    ce20:	aa0100c6 	orr	x6, x6, x1
    ce24:	9ac32007 	lsl	x7, x0, x3
    ce28:	d360fc40 	lsr	x0, x2, #32
    ce2c:	92407c43 	and	x3, x2, #0xffffffff
    ce30:	9ac008c1 	udiv	x1, x6, x0
    ce34:	9b009826 	msub	x6, x1, x0, x6
    ce38:	9b017c61 	mul	x1, x3, x1
    ce3c:	93c780c6 	extr	x6, x6, x7, #32
    ce40:	eb06003f 	cmp	x1, x6
    ce44:	540000a9 	b.ls	ce58 <__modti3+0x88>  // b.plast
    ce48:	ab060046 	adds	x6, x2, x6
    ce4c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    ce50:	8b0200c8 	add	x8, x6, x2
    ce54:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    ce58:	cb0100c6 	sub	x6, x6, x1
    ce5c:	9ac008c8 	udiv	x8, x6, x0
    ce60:	9b009901 	msub	x1, x8, x0, x6
    ce64:	aa0703e0 	mov	x0, x7
    ce68:	9b087c63 	mul	x3, x3, x8
    ce6c:	b3607c20 	bfi	x0, x1, #32, #32
    ce70:	eb00007f 	cmp	x3, x0
    ce74:	54001088 	b.hi	d084 <__modti3+0x2b4>  // b.pmore
    ce78:	cb030000 	sub	x0, x0, x3
    ce7c:	9ac52400 	lsr	x0, x0, x5
    ce80:	d2800001 	mov	x1, #0x0                   	// #0
    ce84:	b4000064 	cbz	x4, ce90 <__modti3+0xc0>
    ce88:	eb0003e0 	negs	x0, x0
    ce8c:	da0103e1 	ngc	x1, x1
    ce90:	d65f03c0 	ret
    ce94:	dac01066 	clz	x6, x3
    ce98:	eb03003f 	cmp	x1, x3
    ce9c:	54ffff43 	b.cc	ce84 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cea0:	93407cc5 	sxtw	x5, w6
    cea4:	d2800808 	mov	x8, #0x40                  	// #64
    cea8:	cb050108 	sub	x8, x8, x5
    ceac:	9ac62063 	lsl	x3, x3, x6
    ceb0:	9ac62025 	lsl	x5, x1, x6
    ceb4:	9ac82447 	lsr	x7, x2, x8
    ceb8:	aa0300e7 	orr	x7, x7, x3
    cebc:	9ac82423 	lsr	x3, x1, x8
    cec0:	92407cec 	and	x12, x7, #0xffffffff
    cec4:	d360fcea 	lsr	x10, x7, #32
    cec8:	9ac82401 	lsr	x1, x0, x8
    cecc:	aa050021 	orr	x1, x1, x5
    ced0:	9ac62042 	lsl	x2, x2, x6
    ced4:	9ac62000 	lsl	x0, x0, x6
    ced8:	9aca086b 	udiv	x11, x3, x10
    cedc:	9b0a8d63 	msub	x3, x11, x10, x3
    cee0:	aa0b03e5 	mov	x5, x11
    cee4:	9b0b7d89 	mul	x9, x12, x11
    cee8:	93c18063 	extr	x3, x3, x1, #32
    ceec:	eb03013f 	cmp	x9, x3
    cef0:	540000a9 	b.ls	cf04 <__modti3+0x134>  // b.plast
    cef4:	ab0300e3 	adds	x3, x7, x3
    cef8:	d1000565 	sub	x5, x11, #0x1
    cefc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    cf00:	54001168 	b.hi	d12c <__modti3+0x35c>  // b.pmore
    cf04:	cb090063 	sub	x3, x3, x9
    cf08:	9aca086b 	udiv	x11, x3, x10
    cf0c:	9b0a8d6a 	msub	x10, x11, x10, x3
    cf10:	aa0b03e9 	mov	x9, x11
    cf14:	9b0b7d8c 	mul	x12, x12, x11
    cf18:	b3607d41 	bfi	x1, x10, #32, #32
    cf1c:	eb01019f 	cmp	x12, x1
    cf20:	540000a9 	b.ls	cf34 <__modti3+0x164>  // b.plast
    cf24:	ab0100e1 	adds	x1, x7, x1
    cf28:	d1000569 	sub	x9, x11, #0x1
    cf2c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    cf30:	54000f88 	b.hi	d120 <__modti3+0x350>  // b.pmore
    cf34:	aa058123 	orr	x3, x9, x5, lsl #32
    cf38:	92407c4b 	and	x11, x2, #0xffffffff
    cf3c:	2a0903e9 	mov	w9, w9
    cf40:	d360fc4a 	lsr	x10, x2, #32
    cf44:	d360fc63 	lsr	x3, x3, #32
    cf48:	cb0c0021 	sub	x1, x1, x12
    cf4c:	aa0a03ec 	mov	x12, x10
    cf50:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    cf54:	9b0b7d25 	mul	x5, x9, x11
    cf58:	9b0b7c6b 	mul	x11, x3, x11
    cf5c:	9b0a2d29 	madd	x9, x9, x10, x11
    cf60:	92407caa 	and	x10, x5, #0xffffffff
    cf64:	9b0c7c63 	mul	x3, x3, x12
    cf68:	8b458125 	add	x5, x9, x5, lsr #32
    cf6c:	8b0d0069 	add	x9, x3, x13
    cf70:	eb05017f 	cmp	x11, x5
    cf74:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    cf78:	8b058149 	add	x9, x10, x5, lsl #32
    cf7c:	8b458063 	add	x3, x3, x5, lsr #32
    cf80:	eb03003f 	cmp	x1, x3
    cf84:	54000063 	b.cc	cf90 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    cf88:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    cf8c:	54000082 	b.cs	cf9c <__modti3+0x1cc>  // b.hs, b.nlast
    cf90:	eb020129 	subs	x9, x9, x2
    cf94:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    cf98:	cb070063 	sub	x3, x3, x7
    cf9c:	eb090000 	subs	x0, x0, x9
    cfa0:	da030021 	sbc	x1, x1, x3
    cfa4:	9ac62400 	lsr	x0, x0, x6
    cfa8:	9ac82028 	lsl	x8, x1, x8
    cfac:	aa000100 	orr	x0, x8, x0
    cfb0:	9ac62421 	lsr	x1, x1, x6
    cfb4:	17ffffb4 	b	ce84 <__modti3+0xb4>
    cfb8:	b5000062 	cbnz	x2, cfc4 <__modti3+0x1f4>
    cfbc:	d2800023 	mov	x3, #0x1                   	// #1
    cfc0:	9ac20862 	udiv	x2, x3, x2
    cfc4:	dac01048 	clz	x8, x2
    cfc8:	aa0803e5 	mov	x5, x8
    cfcc:	b5000668 	cbnz	x8, d098 <__modti3+0x2c8>
    cfd0:	cb020020 	sub	x0, x1, x2
    cfd4:	d360fc49 	lsr	x9, x2, #32
    cfd8:	92407c4a 	and	x10, x2, #0xffffffff
    cfdc:	9ac90801 	udiv	x1, x0, x9
    cfe0:	9b098020 	msub	x0, x1, x9, x0
    cfe4:	9b0a7c21 	mul	x1, x1, x10
    cfe8:	93c78000 	extr	x0, x0, x7, #32
    cfec:	eb00003f 	cmp	x1, x0
    cff0:	540000a9 	b.ls	d004 <__modti3+0x234>  // b.plast
    cff4:	ab000040 	adds	x0, x2, x0
    cff8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cffc:	8b020003 	add	x3, x0, x2
    d000:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d004:	cb010001 	sub	x1, x0, x1
    d008:	9ac90820 	udiv	x0, x1, x9
    d00c:	9b098403 	msub	x3, x0, x9, x1
    d010:	aa0703e1 	mov	x1, x7
    d014:	9b0a7c00 	mul	x0, x0, x10
    d018:	b3607c61 	bfi	x1, x3, #32, #32
    d01c:	eb01001f 	cmp	x0, x1
    d020:	540000a9 	b.ls	d034 <__modti3+0x264>  // b.plast
    d024:	ab010041 	adds	x1, x2, x1
    d028:	8b020022 	add	x2, x1, x2
    d02c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d030:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d034:	cb000020 	sub	x0, x1, x0
    d038:	17ffff91 	b	ce7c <__modti3+0xac>
    d03c:	eb0203e5 	negs	x5, x2
    d040:	aa0003e7 	mov	x7, x0
    d044:	da0303e8 	ngc	x8, x3
    d048:	aa0503e2 	mov	x2, x5
    d04c:	aa0803e3 	mov	x3, x8
    d050:	aa0103e6 	mov	x6, x1
    d054:	b4ffed48 	cbz	x8, cdfc <__modti3+0x2c>
    d058:	eb01011f 	cmp	x8, x1
    d05c:	54fff148 	b.hi	ce84 <__modti3+0xb4>  // b.pmore
    d060:	dac01109 	clz	x9, x8
    d064:	2a0903e6 	mov	w6, w9
    d068:	b5fff1c9 	cbnz	x9, cea0 <__modti3+0xd0>
    d06c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d070:	54000068 	b.hi	d07c <__modti3+0x2ac>  // b.pmore
    d074:	eb050007 	subs	x7, x0, x5
    d078:	da080021 	sbc	x1, x1, x8
    d07c:	aa0703e0 	mov	x0, x7
    d080:	17ffff81 	b	ce84 <__modti3+0xb4>
    d084:	ab000040 	adds	x0, x2, x0
    d088:	8b020002 	add	x2, x0, x2
    d08c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d090:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d094:	17ffff79 	b	ce78 <__modti3+0xa8>
    d098:	9ac82042 	lsl	x2, x2, x8
    d09c:	d2800803 	mov	x3, #0x40                  	// #64
    d0a0:	cb080063 	sub	x3, x3, x8
    d0a4:	d360fc49 	lsr	x9, x2, #32
    d0a8:	9ac82027 	lsl	x7, x1, x8
    d0ac:	92407c4a 	and	x10, x2, #0xffffffff
    d0b0:	9ac32426 	lsr	x6, x1, x3
    d0b4:	9ac32403 	lsr	x3, x0, x3
    d0b8:	aa070063 	orr	x3, x3, x7
    d0bc:	9ac908c1 	udiv	x1, x6, x9
    d0c0:	9ac82007 	lsl	x7, x0, x8
    d0c4:	9b099820 	msub	x0, x1, x9, x6
    d0c8:	9b017d41 	mul	x1, x10, x1
    d0cc:	93c38000 	extr	x0, x0, x3, #32
    d0d0:	eb00003f 	cmp	x1, x0
    d0d4:	540000a9 	b.ls	d0e8 <__modti3+0x318>  // b.plast
    d0d8:	ab000040 	adds	x0, x2, x0
    d0dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d0e0:	8b020006 	add	x6, x0, x2
    d0e4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d0e8:	cb010000 	sub	x0, x0, x1
    d0ec:	9ac90801 	udiv	x1, x0, x9
    d0f0:	9b098026 	msub	x6, x1, x9, x0
    d0f4:	aa0303e0 	mov	x0, x3
    d0f8:	9b017d41 	mul	x1, x10, x1
    d0fc:	b3607cc0 	bfi	x0, x6, #32, #32
    d100:	eb00003f 	cmp	x1, x0
    d104:	540000a9 	b.ls	d118 <__modti3+0x348>  // b.plast
    d108:	ab000040 	adds	x0, x2, x0
    d10c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d110:	8b020003 	add	x3, x0, x2
    d114:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d118:	cb010000 	sub	x0, x0, x1
    d11c:	17ffffb0 	b	cfdc <__modti3+0x20c>
    d120:	d1000969 	sub	x9, x11, #0x2
    d124:	8b070021 	add	x1, x1, x7
    d128:	17ffff83 	b	cf34 <__modti3+0x164>
    d12c:	d1000965 	sub	x5, x11, #0x2
    d130:	8b070063 	add	x3, x3, x7
    d134:	17ffff74 	b	cf04 <__modti3+0x134>
    d138:	d503201f 	nop
    d13c:	d503201f 	nop

000000000000d140 <atexit>:
    d140:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d144:	f0000082 	adrp	x2, 20000 <__data_start>
    d148:	d2800001 	mov	x1, #0x0                   	// #0
    d14c:	910003fd 	mov	x29, sp
    d150:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d154:	f9400442 	ldr	x2, [x2, #8]
    d158:	17ffd566 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d15c <_fini>:
    d15c:	d503201f 	nop
    d160:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d164:	910003fd 	mov	x29, sp
    d168:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d16c:	d65f03c0 	ret
