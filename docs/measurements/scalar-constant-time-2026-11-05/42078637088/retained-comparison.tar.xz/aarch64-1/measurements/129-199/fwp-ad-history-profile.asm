
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x440>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	912fe0a5 	add	x5, x5, #0xbf8
    2a20:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x440>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	91300084 	add	x4, x4, #0xc00
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	9400034c 	bl	3780 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91018261 	add	x1, x19, #0x60
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe2e0>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9006820 	str	x0, [x1, #208]
    2aac:	94000395 	bl	3900 <fwp_now_ns>
    2ab0:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x760>
    2ab4:	91052000 	add	x0, x0, #0x148
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x1a9c>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	912f0042 	add	x2, x2, #0xbc0
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91018273 	add	x19, x19, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943da60 	ldr	w0, [x19, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff4c 	bl	2900 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x760>
    2bfc:	91056000 	add	x0, x0, #0x158
    2c00:	940002e0 	bl	3780 <fwp_trap>
    2c04:	97ffff03 	bl	2810 <__stack_chk_fail@plt>
    2c08:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x760>
    2c0c:	9107e000 	add	x0, x0, #0x1f8
    2c10:	940002dc 	bl	3780 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffeea 	bl	27c0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x760>
    2c24:	91074000 	add	x0, x0, #0x1d0
    2c28:	940002d6 	bl	3780 <fwp_trap>
    2c2c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x760>
    2c30:	91068000 	add	x0, x0, #0x1a0
    2c34:	940002d3 	bl	3780 <fwp_trap>
    2c38:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x760>
    2c3c:	9105e000 	add	x0, x0, #0x178
    2c40:	940002d0 	bl	3780 <fwp_trap>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x760>
    2e34:	9120c021 	add	x1, x1, #0x830
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x760>
    30d8:	91204021 	add	x1, x1, #0x810
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    3110:	9122a000 	add	x0, x0, #0x8a8
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    3144:	911902a1 	add	x1, x21, #0x640
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    3158:	9128c0a5 	add	x5, x5, #0xa30
    315c:	911902a1 	add	x1, x21, #0x640
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911902b7 	add	x23, x21, #0x640
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911902b5 	add	x21, x21, #0x640
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911902b5 	add	x21, x21, #0x640
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    32e8:	9128a0a5 	add	x5, x5, #0xa28
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x440>
    331c:	91230042 	add	x2, x2, #0x8c0
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x440>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	91246042 	add	x2, x2, #0x918
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	d0000059 	adrp	x25, d000 <fwp_main_thread+0x440>
    33a8:	d000005a 	adrp	x26, d000 <fwp_main_thread+0x440>
    33ac:	9125e339 	add	x25, x25, #0x978
    33b0:	9123835a 	add	x26, x26, #0x8e0
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	d000005b 	adrp	x27, d000 <fwp_main_thread+0x440>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	9123a377 	add	x23, x27, #0x8e8
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	9126e000 	add	x0, x0, #0x9b8
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.5+0xfba0>
    3474:	b0000165 	adrp	x5, 30000 <alt.5+0xfba0>
    3478:	b0000162 	adrp	x2, 30000 <alt.5+0xfba0>
    347c:	d0000043 	adrp	x3, d000 <fwp_main_thread+0x440>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	d0000055 	adrp	x21, d000 <fwp_main_thread+0x440>
    3488:	f9423024 	ldr	x4, [x1, #1120]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94234a5 	ldr	x5, [x5, #1128]
    3494:	91118033 	add	x19, x1, #0x460
    3498:	f9423846 	ldr	x6, [x2, #1136]
    349c:	91238063 	add	x3, x3, #0x8e0
    34a0:	912742b5 	add	x21, x21, #0x9d0
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	91284000 	add	x0, x0, #0xa10
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    352c:	9123c000 	add	x0, x0, #0x8f0
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    35ec:	9122a000 	add	x0, x0, #0x8a8
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x440>
    3730:	aa1303e0 	mov	x0, x19
    3734:	91286021 	add	x1, x1, #0xa18
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x440>
    3744:	aa1303e0 	mov	x0, x19
    3748:	91288021 	add	x1, x1, #0xa20
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x440>
    3760:	9128a021 	add	x1, x1, #0xa28
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_trap>:
    3780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3784:	d53bd041 	mrs	x1, tpidr_el0
    3788:	91400021 	add	x1, x1, #0x0, lsl #12
    378c:	91004021 	add	x1, x1, #0x10
    3790:	910003fd 	mov	x29, sp
    3794:	a90153f3 	stp	x19, x20, [sp, #16]
    3798:	aa0003f3 	mov	x19, x0
    379c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    37a0:	f947ea94 	ldr	x20, [x20, #4048]
    37a4:	f90013f5 	str	x21, [sp, #32]
    37a8:	f9400035 	ldr	x21, [x1]
    37ac:	97fffe12 	bl	2ff4 <fwp_flush>
    37b0:	f9400280 	ldr	x0, [x20]
    37b4:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x440>
    37b8:	aa1303e3 	mov	x3, x19
    37bc:	9128c042 	add	x2, x2, #0xa30
    37c0:	52800041 	mov	w1, #0x2                   	// #2
    37c4:	97fffc2f 	bl	2880 <__fprintf_chk@plt>
    37c8:	b40000b5 	cbz	x21, 37dc <fwp_trap+0x5c>
    37cc:	f9400280 	ldr	x0, [x20]
    37d0:	97fffc5c 	bl	2940 <fflush@plt>
    37d4:	52800ca0 	mov	w0, #0x65                  	// #101
    37d8:	97fffc6a 	bl	2980 <_Exit@plt>
    37dc:	52800ca0 	mov	w0, #0x65                  	// #101
    37e0:	97fffbb8 	bl	26c0 <exit@plt>

00000000000037e4 <fwp_closure_drop_push>:
    37e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    37e8:	910003fd 	mov	x29, sp
    37ec:	a90153f3 	stp	x19, x20, [sp, #16]
    37f0:	aa0003f3 	mov	x19, x0
    37f4:	a9408014 	ldp	x20, x0, [x0, #8]
    37f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    37fc:	aa0103f5 	mov	x21, x1
    3800:	a90363f7 	stp	x23, x24, [sp, #48]
    3804:	eb00029f 	cmp	x20, x0
    3808:	54000160 	b.eq	3834 <fwp_closure_drop_push+0x50>  // b.none
    380c:	f9400276 	ldr	x22, [x19]
    3810:	d37df297 	lsl	x23, x20, #3
    3814:	91000694 	add	x20, x20, #0x1
    3818:	f9000674 	str	x20, [x19, #8]
    381c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3820:	f8376ad5 	str	x21, [x22, x23]
    3824:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3828:	a94363f7 	ldp	x23, x24, [sp, #48]
    382c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3830:	d65f03c0 	ret
    3834:	a9046bf9 	stp	x25, x26, [sp, #64]
    3838:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    383c:	eb00029f 	cmp	x20, x0
    3840:	54000568 	b.hi	38ec <fwp_closure_drop_push+0x108>  // b.pmore
    3844:	d37cee99 	lsl	x25, x20, #4
    3848:	d37ffa9a 	lsl	x26, x20, #1
    384c:	aa1903e0 	mov	x0, x25
    3850:	97fffbd8 	bl	27b0 <malloc@plt>
    3854:	aa0003f6 	mov	x22, x0
    3858:	b4000320 	cbz	x0, 38bc <fwp_closure_drop_push+0xd8>
    385c:	aa1303f8 	mov	x24, x19
    3860:	aa1903e3 	mov	x3, x25
    3864:	d37df297 	lsl	x23, x20, #3
    3868:	aa1703e2 	mov	x2, x23
    386c:	f8418719 	ldr	x25, [x24], #24
    3870:	aa1903e1 	mov	x1, x25
    3874:	97fffbbb 	bl	2760 <__memcpy_chk@plt>
    3878:	eb18033f 	cmp	x25, x24
    387c:	540000a0 	b.eq	3890 <fwp_closure_drop_push+0xac>  // b.none
    3880:	aa1903e0 	mov	x0, x25
    3884:	97fffc13 	bl	28d0 <free@plt>
    3888:	f9400674 	ldr	x20, [x19, #8]
    388c:	d37df297 	lsl	x23, x20, #3
    3890:	91000694 	add	x20, x20, #0x1
    3894:	f9000276 	str	x22, [x19]
    3898:	f9000a7a 	str	x26, [x19, #16]
    389c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    38a0:	f9000674 	str	x20, [x19, #8]
    38a4:	f8376ad5 	str	x21, [x22, x23]
    38a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    38b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b8:	d65f03c0 	ret
    38bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    38c0:	f947e863 	ldr	x3, [x3, #4048]
    38c4:	d2800262 	mov	x2, #0x13                  	// #19
    38c8:	d2800021 	mov	x1, #0x1                   	// #1
    38cc:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    38d0:	9122a000 	add	x0, x0, #0x8a8
    38d4:	f9400063 	ldr	x3, [x3]
    38d8:	97fffc0e 	bl	2910 <fwrite@plt>
    38dc:	d2800000 	mov	x0, #0x0                   	// #0
    38e0:	97fffc18 	bl	2940 <fflush@plt>
    38e4:	52800cc0 	mov	w0, #0x66                  	// #102
    38e8:	97fffc26 	bl	2980 <_Exit@plt>
    38ec:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    38f0:	91290000 	add	x0, x0, #0xa40
    38f4:	97ffffa3 	bl	3780 <fwp_trap>
    38f8:	d503201f 	nop
    38fc:	d503201f 	nop

0000000000003900 <fwp_now_ns>:
    3900:	d100c3ff 	sub	sp, sp, #0x30
    3904:	52800020 	mov	w0, #0x1                   	// #1
    3908:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    390c:	f947f442 	ldr	x2, [x2, #4072]
    3910:	910023e1 	add	x1, sp, #0x8
    3914:	a9027bfd 	stp	x29, x30, [sp, #32]
    3918:	910083fd 	add	x29, sp, #0x20
    391c:	f9400043 	ldr	x3, [x2]
    3920:	f9000fe3 	str	x3, [sp, #24]
    3924:	d2800003 	mov	x3, #0x0                   	// #0
    3928:	97fffb86 	bl	2740 <clock_gettime@plt>
    392c:	350002c0 	cbnz	w0, 3984 <fwp_now_ns+0x84>
    3930:	a9408be1 	ldp	x1, x2, [sp, #8]
    3934:	d2994003 	mov	x3, #0xca00                	// #51712
    3938:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    393c:	9b037c20 	mul	x0, x1, x3
    3940:	9b437c21 	smulh	x1, x1, x3
    3944:	ab020000 	adds	x0, x0, x2
    3948:	937ffc42 	asr	x2, x2, #63
    394c:	9a020021 	adc	x1, x1, x2
    3950:	f100001f 	cmp	x0, #0x0
    3954:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3958:	b50001e1 	cbnz	x1, 3994 <fwp_now_ns+0x94>
    395c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3960:	f947f421 	ldr	x1, [x1, #4072]
    3964:	f9400fe3 	ldr	x3, [sp, #24]
    3968:	f9400022 	ldr	x2, [x1]
    396c:	eb020063 	subs	x3, x3, x2
    3970:	d2800002 	mov	x2, #0x0                   	// #0
    3974:	540000e1 	b.ne	3990 <fwp_now_ns+0x90>  // b.any
    3978:	a9427bfd 	ldp	x29, x30, [sp, #32]
    397c:	9100c3ff 	add	sp, sp, #0x30
    3980:	d65f03c0 	ret
    3984:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    3988:	91298000 	add	x0, x0, #0xa60
    398c:	97ffff7d 	bl	3780 <fwp_trap>
    3990:	97fffba0 	bl	2810 <__stack_chk_fail@plt>
    3994:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    3998:	912a0000 	add	x0, x0, #0xa80
    399c:	97ffff79 	bl	3780 <fwp_trap>

00000000000039a0 <fwp_closure_drop.part.0>:
    39a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39a4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x760>
    39a8:	910003fd 	mov	x29, sp
    39ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    39b0:	f947f463 	ldr	x3, [x3, #4072]
    39b4:	a90153f3 	stp	x19, x20, [sp, #16]
    39b8:	d10883ff 	sub	sp, sp, #0x220
    39bc:	910003e2 	mov	x2, sp
    39c0:	d53bd053 	mrs	x19, tpidr_el0
    39c4:	910063f4 	add	x20, sp, #0x18
    39c8:	3dc21020 	ldr	q0, [x1, #2112]
    39cc:	91400264 	add	x4, x19, #0x0, lsl #12
    39d0:	91004084 	add	x4, x4, #0x10
    39d4:	aa0003e1 	mov	x1, x0
    39d8:	aa0203e0 	mov	x0, x2
    39dc:	f9400062 	ldr	x2, [x3]
    39e0:	f9010fe2 	str	x2, [sp, #536]
    39e4:	d2800002 	mov	x2, #0x0                   	// #0
    39e8:	f90003f4 	str	x20, [sp]
    39ec:	f9000080 	str	x0, [x4]
    39f0:	3c8083e0 	stur	q0, [sp, #8]
    39f4:	97ffff7c 	bl	37e4 <fwp_closure_drop_push>
    39f8:	f94007e0 	ldr	x0, [sp, #8]
    39fc:	b4000280 	cbz	x0, 3a4c <fwp_closure_drop.part.0+0xac>
    3a00:	f90123f5 	str	x21, [sp, #576]
    3a04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a08:	910182b5 	add	x21, x21, #0x60
    3a0c:	d503201f 	nop
    3a10:	f94003e1 	ldr	x1, [sp]
    3a14:	d1000400 	sub	x0, x0, #0x1
    3a18:	f90007e0 	str	x0, [sp, #8]
    3a1c:	f9406aa2 	ldr	x2, [x21, #208]
    3a20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3a24:	b9400001 	ldr	w1, [x0]
    3a28:	8b011441 	add	x1, x2, x1, lsl #5
    3a2c:	f9400c21 	ldr	x1, [x1, #24]
    3a30:	b4000321 	cbz	x1, 3a94 <fwp_closure_drop.part.0+0xf4>
    3a34:	f9400422 	ldr	x2, [x1, #8]
    3a38:	52800001 	mov	w1, #0x0                   	// #0
    3a3c:	d63f0040 	blr	x2
    3a40:	f94007e0 	ldr	x0, [sp, #8]
    3a44:	b5fffe60 	cbnz	x0, 3a10 <fwp_closure_drop.part.0+0x70>
    3a48:	f94123f5 	ldr	x21, [sp, #576]
    3a4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3a50:	91004273 	add	x19, x19, #0x10
    3a54:	f94003e0 	ldr	x0, [sp]
    3a58:	f900027f 	str	xzr, [x19]
    3a5c:	eb14001f 	cmp	x0, x20
    3a60:	54000040 	b.eq	3a68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3a64:	97fffb9b 	bl	28d0 <free@plt>
    3a68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3a6c:	f947f400 	ldr	x0, [x0, #4072]
    3a70:	f9410fe2 	ldr	x2, [sp, #536]
    3a74:	f9400001 	ldr	x1, [x0]
    3a78:	eb010042 	subs	x2, x2, x1
    3a7c:	d2800001 	mov	x1, #0x0                   	// #0
    3a80:	54000101 	b.ne	3aa0 <fwp_closure_drop.part.0+0x100>  // b.any
    3a84:	910883ff 	add	sp, sp, #0x220
    3a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a90:	d65f03c0 	ret
    3a94:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    3a98:	912aa000 	add	x0, x0, #0xaa8
    3a9c:	97ffff39 	bl	3780 <fwp_trap>
    3aa0:	f90123f5 	str	x21, [sp, #576]
    3aa4:	97fffb5b 	bl	2810 <__stack_chk_fail@plt>
    3aa8:	d503201f 	nop
    3aac:	d503201f 	nop

0000000000003ab0 <fwp_tape_of>:
    3ab0:	92403c02 	and	x2, x0, #0xffff
    3ab4:	b4000262 	cbz	x2, 3b00 <fwp_tape_of+0x50>
    3ab8:	b00000e3 	adrp	x3, 20000 <__data_start>
    3abc:	91018063 	add	x3, x3, #0x60
    3ac0:	9350fc01 	asr	x1, x0, #16
    3ac4:	d1000440 	sub	x0, x2, #0x1
    3ac8:	f9406c62 	ldr	x2, [x3, #216]
    3acc:	eb00005f 	cmp	x2, x0
    3ad0:	5400018d 	b.le	3b00 <fwp_tape_of+0x50>
    3ad4:	8b000402 	add	x2, x0, x0, lsl #1
    3ad8:	f9404463 	ldr	x3, [x3, #136]
    3adc:	8b020802 	add	x2, x0, x2, lsl #2
    3ae0:	d37df042 	lsl	x2, x2, #3
    3ae4:	8b020060 	add	x0, x3, x2
    3ae8:	b9400404 	ldr	w4, [x0, #4]
    3aec:	340000a4 	cbz	w4, 3b00 <fwp_tape_of+0x50>
    3af0:	b8626862 	ldr	w2, [x3, x2]
    3af4:	6b01005f 	cmp	w2, w1
    3af8:	54000041 	b.ne	3b00 <fwp_tape_of+0x50>  // b.any
    3afc:	d65f03c0 	ret
    3b00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b04:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    3b08:	912b6000 	add	x0, x0, #0xad8
    3b0c:	910003fd 	mov	x29, sp
    3b10:	97ffff1c 	bl	3780 <fwp_trap>

0000000000003b14 <fwp_format_g.constprop.0>:
    3b14:	d10483ff 	sub	sp, sp, #0x120
    3b18:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x440>
    3b1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    3b20:	f947f442 	ldr	x2, [x2, #4072]
    3b24:	912ca084 	add	x4, x4, #0xb28
    3b28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3b2c:	9102c3fd 	add	x29, sp, #0xb0
    3b30:	d2800803 	mov	x3, #0x40                  	// #64
    3b34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3b38:	93407c38 	sxtw	x24, w1
    3b3c:	aa0303e1 	mov	x1, x3
    3b40:	fd008be8 	str	d8, [sp, #272]
    3b44:	1e604008 	fmov	d8, d0
    3b48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3b4c:	910083f4 	add	x20, sp, #0x20
    3b50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3b54:	aa0003f5 	mov	x21, x0
    3b58:	a91073fb 	stp	x27, x28, [sp, #256]
    3b5c:	5100071c 	sub	w28, w24, #0x1
    3b60:	2a1c03e5 	mov	w5, w28
    3b64:	f9400040 	ldr	x0, [x2]
    3b68:	f90057e0 	str	x0, [sp, #168]
    3b6c:	d2800000 	mov	x0, #0x0                   	// #0
    3b70:	52800042 	mov	w2, #0x2                   	// #2
    3b74:	aa1403e0 	mov	x0, x20
    3b78:	97fffb02 	bl	2780 <__snprintf_chk@plt>
    3b7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3b80:	aa1403e0 	mov	x0, x20
    3b84:	97fffb5b 	bl	28f0 <strchr@plt>
    3b88:	aa0003f3 	mov	x19, x0
    3b8c:	52800142 	mov	w2, #0xa                   	// #10
    3b90:	91000400 	add	x0, x0, #0x1
    3b94:	d2800001 	mov	x1, #0x0                   	// #0
    3b98:	97fffb46 	bl	28b0 <strtol@plt>
    3b9c:	aa0003f7 	mov	x23, x0
    3ba0:	11001400 	add	w0, w0, #0x5
    3ba4:	7100541f 	cmp	w0, #0x15
    3ba8:	54000d88 	b.hi	3d58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3bac:	4b170385 	sub	w5, w28, w23
    3bb0:	710000bf 	cmp	w5, #0x0
    3bb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3bb8:	54000ba0 	b.eq	3d2c <fwp_format_g.constprop.0+0x218>  // b.none
    3bbc:	394083e0 	ldrb	w0, [sp, #32]
    3bc0:	cb180273 	sub	x19, x19, x24
    3bc4:	91000673 	add	x19, x19, #0x1
    3bc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bcc:	7100b41f 	cmp	w0, #0x2d
    3bd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3bd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3bd8:	cb010266 	sub	x6, x19, x1
    3bdc:	d10004da 	sub	x26, x6, #0x1
    3be0:	540018c0 	b.eq	3ef8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d280091b 	mov	x27, #0x48                  	// #72
    3bec:	aa1903e7 	mov	x7, x25
    3bf0:	91000423 	add	x3, x1, #0x1
    3bf4:	91011cc6 	add	x6, x6, #0x47
    3bf8:	910004f6 	add	x22, x7, #0x1
    3bfc:	37f81017 	tbnz	w23, #31, 3dfc <fwp_format_g.constprop.0+0x2e8>
    3c00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c04:	93407ef7 	sxtw	x23, w23
    3c08:	390000e4 	strb	w4, [x7]
    3c0c:	aa1303e1 	mov	x1, x19
    3c10:	aa1703e2 	mov	x2, x23
    3c14:	aa1603e0 	mov	x0, x22
    3c18:	b9000be5 	str	w5, [sp, #8]
    3c1c:	cb170374 	sub	x20, x27, x23
    3c20:	a9011be3 	stp	x3, x6, [sp, #16]
    3c24:	97fffa8f 	bl	2660 <memcpy@plt>
    3c28:	d1000694 	sub	x20, x20, #0x1
    3c2c:	f9400be3 	ldr	x3, [sp, #16]
    3c30:	8b1702d6 	add	x22, x22, x23
    3c34:	aa1603e0 	mov	x0, x22
    3c38:	aa1a03e2 	mov	x2, x26
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	aa1403e3 	mov	x3, x20
    3c44:	97fffac7 	bl	2760 <__memcpy_chk@plt>
    3c48:	8b1a02d6 	add	x22, x22, x26
    3c4c:	f9400fe6 	ldr	x6, [sp, #24]
    3c50:	d2800900 	mov	x0, #0x48                  	// #72
    3c54:	b9400be5 	ldr	w5, [sp, #8]
    3c58:	8b170261 	add	x1, x19, x23
    3c5c:	cb1400c3 	sub	x3, x6, x20
    3c60:	cb060294 	sub	x20, x20, x6
    3c64:	f101207f 	cmp	x3, #0x48
    3c68:	93407cb8 	sxtw	x24, w5
    3c6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c70:	aa1803e2 	mov	x2, x24
    3c74:	8b1802d3 	add	x19, x22, x24
    3c78:	8b140063 	add	x3, x3, x20
    3c7c:	aa1603e0 	mov	x0, x22
    3c80:	97fffab8 	bl	2760 <__memcpy_chk@plt>
    3c84:	cb190273 	sub	x19, x19, x25
    3c88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3c8c:	eb00027f 	cmp	x19, x0
    3c90:	aa1903e1 	mov	x1, x25
    3c94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3c98:	aa1503e0 	mov	x0, x21
    3c9c:	aa1303e2 	mov	x2, x19
    3ca0:	97fffa70 	bl	2660 <memcpy@plt>
    3ca4:	38336abf 	strb	wzr, [x21, x19]
    3ca8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3cac:	aa1503e0 	mov	x0, x21
    3cb0:	97fffa7c 	bl	26a0 <strlen@plt>
    3cb4:	aa0003f3 	mov	x19, x0
    3cb8:	528005c1 	mov	w1, #0x2e                  	// #46
    3cbc:	aa1503e0 	mov	x0, x21
    3cc0:	97fffb0c 	bl	28f0 <strchr@plt>
    3cc4:	b4000160 	cbz	x0, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3cc8:	b4000153 	cbz	x19, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ccc:	d503201f 	nop
    3cd0:	aa1303e1 	mov	x1, x19
    3cd4:	d1000673 	sub	x19, x19, #0x1
    3cd8:	38736aa0 	ldrb	w0, [x21, x19]
    3cdc:	7100c01f 	cmp	w0, #0x30
    3ce0:	54001001 	b.ne	3ee0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ce4:	38336abf 	strb	wzr, [x21, x19]
    3ce8:	b5ffff53 	cbnz	x19, 3cd0 <fwp_format_g.constprop.0+0x1bc>
    3cec:	d503201f 	nop
    3cf0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3cf4:	f947f400 	ldr	x0, [x0, #4072]
    3cf8:	f94057e2 	ldr	x2, [sp, #168]
    3cfc:	f9400001 	ldr	x1, [x0]
    3d00:	eb010042 	subs	x2, x2, x1
    3d04:	d2800001 	mov	x1, #0x0                   	// #0
    3d08:	54001061 	b.ne	3f14 <fwp_format_g.constprop.0+0x400>  // b.any
    3d0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3d20:	fd408be8 	ldr	d8, [sp, #272]
    3d24:	910483ff 	add	sp, sp, #0x120
    3d28:	d65f03c0 	ret
    3d2c:	1e604100 	fmov	d0, d8
    3d30:	710000bf 	cmp	w5, #0x0
    3d34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3d38:	aa1503e0 	mov	x0, x21
    3d3c:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x440>
    3d40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3d44:	912d0084 	add	x4, x4, #0xb40
    3d48:	52800042 	mov	w2, #0x2                   	// #2
    3d4c:	d2803201 	mov	x1, #0x190                 	// #400
    3d50:	97fffa8c 	bl	2780 <__snprintf_chk@plt>
    3d54:	17ffffd6 	b	3cac <fwp_format_g.constprop.0+0x198>
    3d58:	cb140273 	sub	x19, x19, x20
    3d5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d60:	910183f9 	add	x25, sp, #0x60
    3d64:	aa1303e2 	mov	x2, x19
    3d68:	aa1403e1 	mov	x1, x20
    3d6c:	aa1903e0 	mov	x0, x25
    3d70:	d2800803 	mov	x3, #0x40                  	// #64
    3d74:	97fffa7b 	bl	2760 <__memcpy_chk@plt>
    3d78:	38336b3f 	strb	wzr, [x25, x19]
    3d7c:	aa1903e0 	mov	x0, x25
    3d80:	528005c1 	mov	w1, #0x2e                  	// #46
    3d84:	97fffadb 	bl	28f0 <strchr@plt>
    3d88:	b40001c0 	cbz	x0, 3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d8c:	b50000b3 	cbnz	x19, 3da0 <fwp_format_g.constprop.0+0x28c>
    3d90:	1400000c 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d94:	381ff01f 	sturb	wzr, [x0, #-1]
    3d98:	f1000673 	subs	x19, x19, #0x1
    3d9c:	54000120 	b.eq	3dc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3da0:	8b130320 	add	x0, x25, x19
    3da4:	385ff001 	ldurb	w1, [x0, #-1]
    3da8:	7100c03f 	cmp	w1, #0x30
    3dac:	54ffff40 	b.eq	3d94 <fwp_format_g.constprop.0+0x280>  // b.none
    3db0:	d1000673 	sub	x19, x19, #0x1
    3db4:	38736b20 	ldrb	w0, [x25, x19]
    3db8:	7100b81f 	cmp	w0, #0x2e
    3dbc:	54000a80 	b.eq	3f0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3dc0:	710002ff 	cmp	w23, #0x0
    3dc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3dc8:	aa1903e5 	mov	x5, x25
    3dcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3dd0:	aa1503e0 	mov	x0, x21
    3dd4:	52800566 	mov	w6, #0x2b                  	// #43
    3dd8:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x440>
    3ddc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3de0:	912cc084 	add	x4, x4, #0xb30
    3de4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3de8:	52800042 	mov	w2, #0x2                   	// #2
    3dec:	d2803201 	mov	x1, #0x190                 	// #400
    3df0:	97fffa64 	bl	2780 <__snprintf_chk@plt>
    3df4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3df8:	17ffffbe 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3dfc:	52800605 	mov	w5, #0x30                  	// #48
    3e00:	390000e5 	strb	w5, [x7]
    3e04:	d100077b 	sub	x27, x27, #0x1
    3e08:	aa0303e1 	mov	x1, x3
    3e0c:	aa1603e0 	mov	x0, x22
    3e10:	aa1b03e3 	mov	x3, x27
    3e14:	aa1a03e2 	mov	x2, x26
    3e18:	f90007e6 	str	x6, [sp, #8]
    3e1c:	b90013e4 	str	w4, [sp, #16]
    3e20:	8b1a02d6 	add	x22, x22, x26
    3e24:	b9001be5 	str	w5, [sp, #24]
    3e28:	97fffa4e 	bl	2760 <__memcpy_chk@plt>
    3e2c:	f94007e6 	ldr	x6, [sp, #8]
    3e30:	2a3703e7 	mvn	w7, w23
    3e34:	b94013e4 	ldr	w4, [sp, #16]
    3e38:	cb1b00c1 	sub	x1, x6, x27
    3e3c:	cb06037b 	sub	x27, x27, x6
    3e40:	f101203f 	cmp	x1, #0x48
    3e44:	d2800906 	mov	x6, #0x48                  	// #72
    3e48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3e4c:	8b1b0023 	add	x3, x1, x27
    3e50:	310006ff 	cmn	w23, #0x1
    3e54:	54000220 	b.eq	3e98 <fwp_format_g.constprop.0+0x384>  // b.none
    3e58:	b9401be5 	ldr	w5, [sp, #24]
    3e5c:	d2800001 	mov	x1, #0x0                   	// #0
    3e60:	f101207f 	cmp	x3, #0x48
    3e64:	d1000462 	sub	x2, x3, #0x1
    3e68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3e6c:	38216ac5 	strb	w5, [x22, x1]
    3e70:	cb030003 	sub	x3, x0, x3
    3e74:	91000421 	add	x1, x1, #0x1
    3e78:	91000463 	add	x3, x3, #0x1
    3e7c:	eb00007f 	cmp	x3, x0
    3e80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3e84:	cb000063 	sub	x3, x3, x0
    3e88:	8b020063 	add	x3, x3, x2
    3e8c:	6b0100ff 	cmp	w7, w1
    3e90:	54fffe8c 	b.gt	3e60 <fwp_format_g.constprop.0+0x34c>
    3e94:	8b2742d6 	add	x22, x22, w7, uxtw
    3e98:	f101207f 	cmp	x3, #0x48
    3e9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ea0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ea4:	aa1603e0 	mov	x0, x22
    3ea8:	cb0300a1 	sub	x1, x5, x3
    3eac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3eb0:	91000421 	add	x1, x1, #0x1
    3eb4:	d1000463 	sub	x3, x3, #0x1
    3eb8:	eb05003f 	cmp	x1, x5
    3ebc:	38001402 	strb	w2, [x0], #1
    3ec0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3ec4:	93407f82 	sxtw	x2, w28
    3ec8:	cb050025 	sub	x5, x1, x5
    3ecc:	aa1303e1 	mov	x1, x19
    3ed0:	8b0300a3 	add	x3, x5, x3
    3ed4:	8b1802d3 	add	x19, x22, x24
    3ed8:	97fffa22 	bl	2760 <__memcpy_chk@plt>
    3edc:	17ffff6a 	b	3c84 <fwp_format_g.constprop.0+0x170>
    3ee0:	d1000421 	sub	x1, x1, #0x1
    3ee4:	38616aa0 	ldrb	w0, [x21, x1]
    3ee8:	7100b81f 	cmp	w0, #0x2e
    3eec:	54fff021 	b.ne	3cf0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ef0:	38216abf 	strb	wzr, [x21, x1]
    3ef4:	17ffff7f 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ef8:	910187e7 	add	x7, sp, #0x61
    3efc:	910183f9 	add	x25, sp, #0x60
    3f00:	d28008fb 	mov	x27, #0x47                  	// #71
    3f04:	390183e0 	strb	w0, [sp, #96]
    3f08:	17ffff3a 	b	3bf0 <fwp_format_g.constprop.0+0xdc>
    3f0c:	38336b3f 	strb	wzr, [x25, x19]
    3f10:	17ffffac 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3f14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f18:	97fffa3e 	bl	2810 <__stack_chk_fail@plt>
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_heap_report>:
    3f20:	d105c3ff 	sub	sp, sp, #0x170
    3f24:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    3f28:	91190042 	add	x2, x2, #0x640
    3f2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3f30:	f947e821 	ldr	x1, [x1, #4048]
    3f34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3f38:	910443fd 	add	x29, sp, #0x110
    3f3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3f40:	f947f400 	ldr	x0, [x0, #4072]
    3f44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3f48:	a91463f7 	stp	x23, x24, [sp, #320]
    3f4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3f50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3f54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3f58:	fd4a2049 	ldr	d9, [x2, #5184]
    3f5c:	f9400036 	ldr	x22, [x1]
    3f60:	f9400001 	ldr	x1, [x0]
    3f64:	f90087e1 	str	x1, [sp, #264]
    3f68:	d2800001 	mov	x1, #0x0                   	// #0
    3f6c:	f949e459 	ldr	x25, [x2, #5064]
    3f70:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x440>
    3f74:	f94a1057 	ldr	x23, [x2, #5152]
    3f78:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    3f7c:	f94a1458 	ldr	x24, [x2, #5160]
    3f80:	912d2021 	add	x1, x1, #0xb48
    3f84:	912d4000 	add	x0, x0, #0xb50
    3f88:	97fffa06 	bl	27a0 <fopen@plt>
    3f8c:	b4000740 	cbz	x0, 4074 <fwp_heap_report+0x154>
    3f90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3f94:	a91253f3 	stp	x19, x20, [sp, #288]
    3f98:	aa0003f4 	mov	x20, x0
    3f9c:	910023f3 	add	x19, sp, #0x8
    3fa0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3fa4:	72aae915 	movk	w21, #0x5748, lsl #16
    3fa8:	aa1403e2 	mov	x2, x20
    3fac:	aa1303e0 	mov	x0, x19
    3fb0:	52802001 	mov	w1, #0x100                 	// #256
    3fb4:	97fffa83 	bl	29c0 <fgets@plt>
    3fb8:	b4000280 	cbz	x0, 4008 <fwp_heap_report+0xe8>
    3fbc:	b9400261 	ldr	w1, [x19]
    3fc0:	6b15003f 	cmp	w1, w21
    3fc4:	54ffff21 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fc8:	39401260 	ldrb	w0, [x19, #4]
    3fcc:	7101341f 	cmp	w0, #0x4d
    3fd0:	54fffec1 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fd4:	394037e0 	ldrb	w0, [sp, #13]
    3fd8:	7100e81f 	cmp	w0, #0x3a
    3fdc:	54fffe61 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fe0:	52800142 	mov	w2, #0xa                   	// #10
    3fe4:	d2800001 	mov	x1, #0x0                   	// #0
    3fe8:	91003be0 	add	x0, sp, #0xe
    3fec:	97fffa31 	bl	28b0 <strtol@plt>
    3ff0:	aa1403e2 	mov	x2, x20
    3ff4:	aa0003fa 	mov	x26, x0
    3ff8:	52802001 	mov	w1, #0x100                 	// #256
    3ffc:	aa1303e0 	mov	x0, x19
    4000:	97fffa70 	bl	29c0 <fgets@plt>
    4004:	b5fffdc0 	cbnz	x0, 3fbc <fwp_heap_report+0x9c>
    4008:	aa1403e0 	mov	x0, x20
    400c:	97fff9e1 	bl	2790 <fclose@plt>
    4010:	a95253f3 	ldp	x19, x20, [sp, #288]
    4014:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4018:	f947f400 	ldr	x0, [x0, #4072]
    401c:	f94087e2 	ldr	x2, [sp, #264]
    4020:	f9400001 	ldr	x1, [x0]
    4024:	eb010042 	subs	x2, x2, x1
    4028:	d2800001 	mov	x1, #0x0                   	// #0
    402c:	54000281 	b.ne	407c <fwp_heap_report+0x15c>  // b.any
    4030:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4034:	aa1a03e6 	mov	x6, x26
    4038:	aa1903e5 	mov	x5, x25
    403c:	aa1803e4 	mov	x4, x24
    4040:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4044:	aa1703e3 	mov	x3, x23
    4048:	a95463f7 	ldp	x23, x24, [sp, #320]
    404c:	aa1603e0 	mov	x0, x22
    4050:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4054:	1e604121 	fmov	d1, d9
    4058:	1e604100 	fmov	d0, d8
    405c:	b0000042 	adrp	x2, d000 <fwp_main_thread+0x440>
    4060:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4064:	912dc042 	add	x2, x2, #0xb70
    4068:	9105c3ff 	add	sp, sp, #0x170
    406c:	52800041 	mov	w1, #0x2                   	// #2
    4070:	17fffa04 	b	2880 <__fprintf_chk@plt>
    4074:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4078:	17ffffe7 	b	4014 <fwp_heap_report+0xf4>
    407c:	a91253f3 	stp	x19, x20, [sp, #288]
    4080:	97fff9e4 	bl	2810 <__stack_chk_fail@plt>

0000000000004084 <fwp_heap_init>:
    4084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4088:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9c0>
    408c:	91150061 	add	x1, x3, #0x540
    4090:	910003fd 	mov	x29, sp
    4094:	a90153f3 	stp	x19, x20, [sp, #16]
    4098:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    409c:	91190262 	add	x2, x19, #0x640
    40a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a4:	52800024 	mov	w4, #0x1                   	// #1
    40a8:	52800200 	mov	w0, #0x10                  	// #16
    40ac:	b913a444 	str	w4, [x2, #5028]
    40b0:	b8004420 	str	w0, [x1], #4
    40b4:	11004000 	add	w0, w0, #0x10
    40b8:	7104401f 	cmp	w0, #0x110
    40bc:	54ffffa1 	b.ne	40b0 <fwp_heap_init+0x2c>  // b.any
    40c0:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0x760>
    40c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    40c8:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9c0>
    40cc:	91160021 	add	x1, x1, #0x580
    40d0:	3dc21443 	ldr	q3, [x2, #2128]
    40d4:	d2800000 	mov	x0, #0x0                   	// #0
    40d8:	4e040401 	dup	v1.4s, v0.s[0]
    40dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    40e0:	0f215400 	shl	v0.2s, v0.2s, #1
    40e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    40e8:	3ca06821 	str	q1, [x1, x0]
    40ec:	91004000 	add	x0, x0, #0x10
    40f0:	f101801f 	cmp	x0, #0x60
    40f4:	54ffff21 	b.ne	40d8 <fwp_heap_init+0x54>  // b.any
    40f8:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9c0>
    40fc:	91150063 	add	x3, x3, #0x540
    4100:	91178084 	add	x4, x4, #0x5e0
    4104:	91190266 	add	x6, x19, #0x640
    4108:	d2800002 	mov	x2, #0x0                   	// #0
    410c:	d2800000 	mov	x0, #0x0                   	// #0
    4110:	d2880205 	mov	x5, #0x4010                	// #16400
    4114:	d503201f 	nop
    4118:	910f0001 	add	x1, x0, #0x3c0
    411c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4120:	eb02003f 	cmp	x1, x2
    4124:	540000a2 	b.cs	4138 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4128:	91000400 	add	x0, x0, #0x1
    412c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4130:	eb02003f 	cmp	x1, x2
    4134:	54ffffa3 	b.cc	4128 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4138:	91004042 	add	x2, x2, #0x10
    413c:	38001480 	strb	w0, [x4], #1
    4140:	eb05005f 	cmp	x2, x5
    4144:	54fffea1 	b.ne	4118 <fwp_heap_init+0x94>  // b.any
    4148:	528000b5 	mov	w21, #0x5                   	// #5
    414c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4150:	14000004 	b	4160 <fwp_heap_init+0xdc>
    4154:	d342fe94 	lsr	x20, x20, #2
    4158:	710006b5 	subs	w21, w21, #0x1
    415c:	54000720 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    4160:	91404296 	add	x22, x20, #0x10, lsl #12
    4164:	d2800005 	mov	x5, #0x0                   	// #0
    4168:	aa1603e1 	mov	x1, x22
    416c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4170:	52880443 	mov	w3, #0x4022                	// #16418
    4174:	52800002 	mov	w2, #0x0                   	// #0
    4178:	d2800000 	mov	x0, #0x0                   	// #0
    417c:	97fff9c9 	bl	28a0 <mmap@plt>
    4180:	aa0003e6 	mov	x6, x0
    4184:	b100041f 	cmn	x0, #0x1
    4188:	54fffe60 	b.eq	4154 <fwp_heap_init+0xd0>  // b.none
    418c:	b40005a0 	cbz	x0, 4240 <fwp_heap_init+0x1bc>
    4190:	d350fe94 	lsr	x20, x20, #16
    4194:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4198:	8b0000c7 	add	x7, x6, x0
    419c:	91190275 	add	x21, x19, #0x640
    41a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    41a4:	8b140a81 	add	x1, x20, x20, lsl #2
    41a8:	d2800005 	mov	x5, #0x0                   	// #0
    41ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    41b0:	d37df021 	lsl	x1, x1, #3
    41b4:	52880443 	mov	w3, #0x4022                	// #16418
    41b8:	52800002 	mov	w2, #0x0                   	// #0
    41bc:	d2800000 	mov	x0, #0x0                   	// #0
    41c0:	f909daa7 	str	x7, [x21, #5040]
    41c4:	f909dea6 	str	x6, [x21, #5048]
    41c8:	f909e2b6 	str	x22, [x21, #5056]
    41cc:	f909eab4 	str	x20, [x21, #5072]
    41d0:	f90a02a1 	str	x1, [x21, #5120]
    41d4:	97fff9b3 	bl	28a0 <mmap@plt>
    41d8:	aa0003e1 	mov	x1, x0
    41dc:	b100041f 	cmn	x0, #0x1
    41e0:	54000300 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    41e4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    41e8:	91308000 	add	x0, x0, #0xc20
    41ec:	f909fea1 	str	x1, [x21, #5112]
    41f0:	97fff9ec 	bl	29a0 <getenv@plt>
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	aa0003e1 	mov	x1, x0
    41fc:	b40000e0 	cbz	x0, 4218 <fwp_heap_init+0x194>
    4200:	39400000 	ldrb	w0, [x0]
    4204:	340000a0 	cbz	w0, 4218 <fwp_heap_init+0x194>
    4208:	7100c000 	subs	w0, w0, #0x30
    420c:	54000120 	b.eq	4230 <fwp_heap_init+0x1ac>  // b.none
    4210:	7100001f 	cmp	w0, #0x0
    4214:	1a9f07e2 	cset	w2, ne	// ne = any
    4218:	91190273 	add	x19, x19, #0x640
    421c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4220:	b913aa62 	str	w2, [x19, #5032]
    4224:	a94153f3 	ldp	x19, x20, [sp, #16]
    4228:	a8c37bfd 	ldp	x29, x30, [sp], #48
    422c:	d65f03c0 	ret
    4230:	39400420 	ldrb	w0, [x1, #1]
    4234:	7100001f 	cmp	w0, #0x0
    4238:	1a9f07e2 	cset	w2, ne	// ne = any
    423c:	17fffff7 	b	4218 <fwp_heap_init+0x194>
    4240:	97fffbac 	bl	30f0 <fwp_heap_oom>

0000000000004244 <fwp_wake_io>:
    4244:	900000e9 	adrp	x9, 20000 <__data_start>
    4248:	91018122 	add	x2, x9, #0x60
    424c:	f9400001 	ldr	x1, [x0]
    4250:	5280000a 	mov	w10, #0x0                   	// #0
    4254:	f9406046 	ldr	x6, [x2, #192]
    4258:	52800008 	mov	w8, #0x0                   	// #0
    425c:	4f000400 	movi	v0.4s, #0x0
    4260:	52800027 	mov	w7, #0x1                   	// #1
    4264:	aa0103e2 	mov	x2, x1
    4268:	b4000321 	cbz	x1, 42cc <fwp_wake_io+0x88>
    426c:	f9408c25 	ldr	x5, [x1, #280]
    4270:	39015c27 	strb	w7, [x1, #87]
    4274:	b4000165 	cbz	x5, 42a0 <fwp_wake_io+0x5c>
    4278:	a9520c24 	ldp	x4, x3, [x1, #288]
    427c:	b4000364 	cbz	x4, 42e8 <fwp_wake_io+0xa4>
    4280:	f9009483 	str	x3, [x4, #296]
    4284:	f9409423 	ldr	x3, [x1, #296]
    4288:	b4000043 	cbz	x3, 4290 <fwp_wake_io+0x4c>
    428c:	f9009064 	str	x4, [x3, #288]
    4290:	91080023 	add	x3, x1, #0x200
    4294:	f900943f 	str	xzr, [x1, #296]
    4298:	3c918060 	stur	q0, [x3, #-232]
    429c:	f9400001 	ldr	x1, [x0]
    42a0:	f9402843 	ldr	x3, [x2, #80]
    42a4:	f2001c7f 	tst	x3, #0xff000000ff
    42a8:	54fffde1 	b.ne	4264 <fwp_wake_io+0x20>  // b.any
    42ac:	39015047 	strb	w7, [x2, #84]
    42b0:	f900805f 	str	xzr, [x2, #256]
    42b4:	b40001e6 	cbz	x6, 42f0 <fwp_wake_io+0xac>
    42b8:	f90080c2 	str	x2, [x6, #256]
    42bc:	aa0203e6 	mov	x6, x2
    42c0:	52800028 	mov	w8, #0x1                   	// #1
    42c4:	aa0103e2 	mov	x2, x1
    42c8:	b5fffd21 	cbnz	x1, 426c <fwp_wake_io+0x28>
    42cc:	3400006a 	cbz	w10, 42d8 <fwp_wake_io+0x94>
    42d0:	91018120 	add	x0, x9, #0x60
    42d4:	f900640b 	str	x11, [x0, #200]
    42d8:	34000068 	cbz	w8, 42e4 <fwp_wake_io+0xa0>
    42dc:	91018129 	add	x9, x9, #0x60
    42e0:	f9006126 	str	x6, [x9, #192]
    42e4:	d65f03c0 	ret
    42e8:	f90000a3 	str	x3, [x5]
    42ec:	17ffffe7 	b	4288 <fwp_wake_io+0x44>
    42f0:	aa0203eb 	mov	x11, x2
    42f4:	5280002a 	mov	w10, #0x1                   	// #1
    42f8:	17fffff1 	b	42bc <fwp_wake_io+0x78>
    42fc:	d503201f 	nop

0000000000004300 <ad_raw_free.part.0>:
    4300:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fba0>
    4304:	d2800001 	mov	x1, #0x0                   	// #0
    4308:	91118082 	add	x2, x4, #0x460
    430c:	14000005 	b	4320 <ad_raw_free.part.0+0x20>
    4310:	91000421 	add	x1, x1, #0x1
    4314:	91006042 	add	x2, x2, #0x18
    4318:	f140043f 	cmp	x1, #0x1, lsl #12
    431c:	54000220 	b.eq	4360 <ad_raw_free.part.0+0x60>  // b.none
    4320:	f9400043 	ldr	x3, [x2]
    4324:	eb03001f 	cmp	x0, x3
    4328:	54ffff41 	b.ne	4310 <ad_raw_free.part.0+0x10>  // b.any
    432c:	8b010421 	add	x1, x1, x1, lsl #1
    4330:	91118084 	add	x4, x4, #0x460
    4334:	900000e2 	adrp	x2, 20000 <__data_start>
    4338:	91018042 	add	x2, x2, #0x60
    433c:	8b010c81 	add	x1, x4, x1, lsl #3
    4340:	b9401024 	ldr	w4, [x1, #16]
    4344:	f9400425 	ldr	x5, [x1, #8]
    4348:	a9007c3f 	stp	xzr, xzr, [x1]
    434c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4350:	f900083f 	str	xzr, [x1, #16]
    4354:	cb050061 	sub	x1, x3, x5
    4358:	f8247841 	str	x1, [x2, x4, lsl #3]
    435c:	17fff95d 	b	28d0 <free@plt>
    4360:	f100001f 	cmp	x0, #0x0
    4364:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x440>
    4368:	91312021 	add	x1, x1, #0xc48
    436c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4370:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    4374:	9130c000 	add	x0, x0, #0xc30
    4378:	910003fd 	mov	x29, sp
    437c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4380:	97fffbe0 	bl	3300 <ad_raw_fail>

0000000000004384 <fwp_tape_buffers_dispose>:
    4384:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4388:	910003fd 	mov	x29, sp
    438c:	f9000bf3 	str	x19, [sp, #16]
    4390:	aa0003f3 	mov	x19, x0
    4394:	f9400000 	ldr	x0, [x0]
    4398:	b4000040 	cbz	x0, 43a0 <fwp_tape_buffers_dispose+0x1c>
    439c:	97ffffd9 	bl	4300 <ad_raw_free.part.0>
    43a0:	f9400a60 	ldr	x0, [x19, #16]
    43a4:	b4000040 	cbz	x0, 43ac <fwp_tape_buffers_dispose+0x28>
    43a8:	97ffffd6 	bl	4300 <ad_raw_free.part.0>
    43ac:	f9401260 	ldr	x0, [x19, #32]
    43b0:	b4000040 	cbz	x0, 43b8 <fwp_tape_buffers_dispose+0x34>
    43b4:	97ffffd3 	bl	4300 <ad_raw_free.part.0>
    43b8:	4f000400 	movi	v0.4s, #0x0
    43bc:	f9001a7f 	str	xzr, [x19, #48]
    43c0:	ad000260 	stp	q0, q0, [x19]
    43c4:	3d800a60 	str	q0, [x19, #32]
    43c8:	f9400bf3 	ldr	x19, [sp, #16]
    43cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43d0:	d65f03c0 	ret

00000000000043d4 <ad_raw_realloc>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	f90013f5 	str	x21, [sp, #32]
    43e4:	b40005a1 	cbz	x1, 4498 <ad_raw_realloc+0xc4>
    43e8:	aa0103f4 	mov	x20, x1
    43ec:	2a0203f5 	mov	w21, w2
    43f0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fba0>
    43f4:	d2800004 	mov	x4, #0x0                   	// #0
    43f8:	91118025 	add	x5, x1, #0x460
    43fc:	14000005 	b	4410 <ad_raw_realloc+0x3c>
    4400:	91000484 	add	x4, x4, #0x1
    4404:	910060a5 	add	x5, x5, #0x18
    4408:	f140049f 	cmp	x4, #0x1, lsl #12
    440c:	54000320 	b.eq	4470 <ad_raw_realloc+0x9c>  // b.none
    4410:	f94000a6 	ldr	x6, [x5]
    4414:	eb06001f 	cmp	x0, x6
    4418:	54ffff41 	b.ne	4400 <ad_raw_realloc+0x2c>  // b.any
    441c:	8b040484 	add	x4, x4, x4, lsl #1
    4420:	91118021 	add	x1, x1, #0x460
    4424:	8b040c33 	add	x19, x1, x4, lsl #3
    4428:	b4000080 	cbz	x0, 4438 <ad_raw_realloc+0x64>
    442c:	b9401261 	ldr	w1, [x19, #16]
    4430:	6b15003f 	cmp	w1, w21
    4434:	540002c1 	b.ne	448c <ad_raw_realloc+0xb8>  // b.any
    4438:	aa1403e1 	mov	x1, x20
    443c:	97fff8f1 	bl	2800 <realloc@plt>
    4440:	aa0003ed 	mov	x13, x0
    4444:	b40000c0 	cbz	x0, 445c <ad_raw_realloc+0x88>
    4448:	2a1503e3 	mov	w3, w21
    444c:	aa1403e2 	mov	x2, x20
    4450:	aa1303e0 	mov	x0, x19
    4454:	aa0d03e1 	mov	x1, x13
    4458:	97fffaae 	bl	2f10 <ad_raw_record>
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	aa0d03e0 	mov	x0, x13
    4464:	f94013f5 	ldr	x21, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	f100001f 	cmp	x0, #0x0
    4474:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x440>
    4478:	91312021 	add	x1, x1, #0xc48
    447c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    4480:	9130c000 	add	x0, x0, #0xc30
    4484:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4488:	97fffb9e 	bl	3300 <ad_raw_fail>
    448c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    4490:	91322000 	add	x0, x0, #0xc88
    4494:	97fffb9b 	bl	3300 <ad_raw_fail>
    4498:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    449c:	9131a000 	add	x0, x0, #0xc68
    44a0:	97fffb98 	bl	3300 <ad_raw_fail>

00000000000044a4 <fwp_tape_buffers_release>:
    44a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	aa0003f4 	mov	x20, x0
    44b4:	f9401400 	ldr	x0, [x0, #40]
    44b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44bc:	b7f80560 	tbnz	x0, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c0:	f9401a93 	ldr	x19, [x20, #48]
    44c4:	b7f80533 	tbnz	x19, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    44cc:	eb01001f 	cmp	x0, x1
    44d0:	540004c8 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44d4:	8b000400 	add	x0, x0, x0, lsl #1
    44d8:	d2a00101 	mov	x1, #0x80000               	// #524288
    44dc:	d37df000 	lsl	x0, x0, #3
    44e0:	cb000021 	sub	x1, x1, x0
    44e4:	eb410e7f 	cmp	x19, x1, lsr #3
    44e8:	54000408 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44ec:	8b130c13 	add	x19, x0, x19, lsl #3
    44f0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    44f4:	91328000 	add	x0, x0, #0xca0
    44f8:	97fff92a 	bl	29a0 <getenv@plt>
    44fc:	b4000080 	cbz	x0, 450c <fwp_tape_buffers_release+0x68>
    4500:	39400001 	ldrb	w1, [x0]
    4504:	7100c03f 	cmp	w1, #0x30
    4508:	54000880 	b.eq	4618 <fwp_tape_buffers_release+0x174>  // b.none
    450c:	d1000661 	sub	x1, x19, #0x1
    4510:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4514:	eb00003f 	cmp	x1, x0
    4518:	54000328 	b.hi	457c <fwp_tape_buffers_release+0xd8>  // b.pmore
    451c:	900000f5 	adrp	x21, 20000 <__data_start>
    4520:	f9001bf7 	str	x23, [sp, #48]
    4524:	910182b7 	add	x23, x21, #0x60
    4528:	910382f6 	add	x22, x23, #0xe0
    452c:	aa1603e0 	mov	x0, x22
    4530:	97ffff95 	bl	4384 <fwp_tape_buffers_dispose>
    4534:	ad400a81 	ldp	q1, q2, [x20]
    4538:	f9008ef3 	str	x19, [x23, #280]
    453c:	4f000400 	movi	v0.4s, #0x0
    4540:	ad000ac1 	stp	q1, q2, [x22]
    4544:	3dc00a81 	ldr	q1, [x20, #32]
    4548:	3d800ac1 	str	q1, [x22, #32]
    454c:	f9401a80 	ldr	x0, [x20, #48]
    4550:	f9001ac0 	str	x0, [x22, #48]
    4554:	f9001a9f 	str	xzr, [x20, #48]
    4558:	ad000280 	stp	q0, q0, [x20]
    455c:	3d800a80 	str	q0, [x20, #32]
    4560:	f9401bf7 	ldr	x23, [sp, #48]
    4564:	1400000b 	b	4590 <fwp_tape_buffers_release+0xec>
    4568:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    456c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4570:	91328000 	add	x0, x0, #0xca0
    4574:	97fff90b 	bl	29a0 <getenv@plt>
    4578:	b5fffc40 	cbnz	x0, 4500 <fwp_tape_buffers_release+0x5c>
    457c:	aa1403e0 	mov	x0, x20
    4580:	97ffff81 	bl	4384 <fwp_tape_buffers_dispose>
    4584:	900000f5 	adrp	x21, 20000 <__data_start>
    4588:	910182a0 	add	x0, x21, #0x60
    458c:	f9408c13 	ldr	x19, [x0, #280]
    4590:	910182a2 	add	x2, x21, #0x60
    4594:	f9409044 	ldr	x4, [x2, #288]
    4598:	a9400c45 	ldp	x5, x3, [x2]
    459c:	8b040481 	add	x1, x4, x4, lsl #1
    45a0:	f9400840 	ldr	x0, [x2, #16]
    45a4:	8b010881 	add	x1, x4, x1, lsl #2
    45a8:	f9400c44 	ldr	x4, [x2, #24]
    45ac:	8b0300a3 	add	x3, x5, x3
    45b0:	d37df021 	lsl	x1, x1, #3
    45b4:	8b040000 	add	x0, x0, x4
    45b8:	8b030000 	add	x0, x0, x3
    45bc:	eb05003f 	cmp	x1, x5
    45c0:	54000321 	b.ne	4624 <fwp_tape_buffers_release+0x180>  // b.any
    45c4:	8b130023 	add	x3, x1, x19
    45c8:	eb00007f 	cmp	x3, x0
    45cc:	540002c8 	b.hi	4624 <fwp_tape_buffers_release+0x180>  // b.pmore
    45d0:	f9405c43 	ldr	x3, [x2, #184]
    45d4:	f140087f 	cmp	x3, #0x2, lsl #12
    45d8:	540002e0 	b.eq	4634 <fwp_tape_buffers_release+0x190>  // b.none
    45dc:	8b030464 	add	x4, x3, x3, lsl #1
    45e0:	90000165 	adrp	x5, 30000 <alt.5+0xfba0>
    45e4:	911180a5 	add	x5, x5, #0x460
    45e8:	cb010000 	sub	x0, x0, x1
    45ec:	d37df084 	lsl	x4, x4, #3
    45f0:	cb130000 	sub	x0, x0, x19
    45f4:	8b0400a6 	add	x6, x5, x4
    45f8:	91000463 	add	x3, x3, #0x1
    45fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4600:	f82468a1 	str	x1, [x5, x4]
    4604:	a90080d3 	stp	x19, x0, [x6, #8]
    4608:	f9005c43 	str	x3, [x2, #184]
    460c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4610:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4614:	d65f03c0 	ret
    4618:	39400400 	ldrb	w0, [x0, #1]
    461c:	34fffb00 	cbz	w0, 457c <fwp_tape_buffers_release+0xd8>
    4620:	17ffffbb 	b	450c <fwp_tape_buffers_release+0x68>
    4624:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    4628:	9132e000 	add	x0, x0, #0xcb8
    462c:	f9001bf7 	str	x23, [sp, #48]
    4630:	97fffb34 	bl	3300 <ad_raw_fail>
    4634:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    4638:	9133a000 	add	x0, x0, #0xce8
    463c:	f9001bf7 	str	x23, [sp, #48]
    4640:	97fffb30 	bl	3300 <ad_raw_fail>

0000000000004644 <fwp_poll_events>:
    4644:	d10103ff 	sub	sp, sp, #0x40
    4648:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    464c:	f947f400 	ldr	x0, [x0, #4072]
    4650:	a9027bfd 	stp	x29, x30, [sp, #32]
    4654:	910083fd 	add	x29, sp, #0x20
    4658:	a90353f3 	stp	x19, x20, [sp, #48]
    465c:	900000f4 	adrp	x20, 20000 <__data_start>
    4660:	f9400001 	ldr	x1, [x0]
    4664:	f9000fe1 	str	x1, [sp, #24]
    4668:	d2800001 	mov	x1, #0x0                   	// #0
    466c:	97fffca5 	bl	3900 <fwp_now_ns>
    4670:	91018281 	add	x1, x20, #0x60
    4674:	f9409433 	ldr	x19, [x1, #296]
    4678:	b4000e73 	cbz	x19, 4844 <fwp_poll_events+0x200>
    467c:	aa1303e1 	mov	x1, x19
    4680:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4684:	14000005 	b	4698 <fwp_poll_events+0x54>
    4688:	f9408821 	ldr	x1, [x1, #272]
    468c:	eb03005f 	cmp	x2, x3
    4690:	9a83d042 	csel	x2, x2, x3, le
    4694:	b40000c1 	cbz	x1, 46ac <fwp_poll_events+0x68>
    4698:	f9403423 	ldr	x3, [x1, #104]
    469c:	b6ffff62 	tbz	x2, #63, 4688 <fwp_poll_events+0x44>
    46a0:	f9408821 	ldr	x1, [x1, #272]
    46a4:	aa0303e2 	mov	x2, x3
    46a8:	b5ffff81 	cbnz	x1, 4698 <fwp_poll_events+0x54>
    46ac:	b7f80cc2 	tbnz	x2, #63, 4844 <fwp_poll_events+0x200>
    46b0:	cb000042 	sub	x2, x2, x0
    46b4:	f100005f 	cmp	x2, #0x0
    46b8:	540005ad 	b.le	476c <fwp_poll_events+0x128>
    46bc:	d2869b60 	mov	x0, #0x34db                	// #13531
    46c0:	d2884801 	mov	x1, #0x4240                	// #16960
    46c4:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    46c8:	f2a001e1 	movk	x1, #0xf, lsl #16
    46cc:	f2dbd040 	movk	x0, #0xde82, lsl #32
    46d0:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    46d4:	f2e86360 	movk	x0, #0x431b, lsl #48
    46d8:	9b407c40 	smulh	x0, x2, x0
    46dc:	9352fc00 	asr	x0, x0, #18
    46e0:	cb82fc00 	sub	x0, x0, x2, asr #63
    46e4:	9b018802 	msub	x2, x0, x1, x2
    46e8:	f100005f 	cmp	x2, #0x0
    46ec:	9a800400 	cinc	x0, x0, ne	// ne = any
    46f0:	eb03001f 	cmp	x0, x3
    46f4:	540009ec 	b.gt	4830 <fwp_poll_events+0x1ec>
    46f8:	340003a0 	cbz	w0, 476c <fwp_poll_events+0x128>
    46fc:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4700:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4704:	72a20c42 	movk	w2, #0x1062, lsl #16
    4708:	9ba27c02 	umull	x2, w0, w2
    470c:	d366fc43 	lsr	x3, x2, #38
    4710:	aa0303e2 	mov	x2, x3
    4714:	1b048063 	msub	w3, w3, w4, w0
    4718:	9b217c63 	smull	x3, w3, w1
    471c:	d2800001 	mov	x1, #0x0                   	// #0
    4720:	910023e0 	add	x0, sp, #0x8
    4724:	a9008fe2 	stp	x2, x3, [sp, #8]
    4728:	97fff86e 	bl	28e0 <nanosleep@plt>
    472c:	91018280 	add	x0, x20, #0x60
    4730:	f9409413 	ldr	x19, [x0, #296]
    4734:	97fffc73 	bl	3900 <fwp_now_ns>
    4738:	aa0003e6 	mov	x6, x0
    473c:	b50001d3 	cbnz	x19, 4774 <fwp_poll_events+0x130>
    4740:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4744:	f947f400 	ldr	x0, [x0, #4072]
    4748:	f9400fe2 	ldr	x2, [sp, #24]
    474c:	f9400001 	ldr	x1, [x0]
    4750:	eb010042 	subs	x2, x2, x1
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	540008c1 	b.ne	4870 <fwp_poll_events+0x22c>  // b.any
    475c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4760:	a94353f3 	ldp	x19, x20, [sp, #48]
    4764:	910103ff 	add	sp, sp, #0x40
    4768:	d65f03c0 	ret
    476c:	97fffc65 	bl	3900 <fwp_now_ns>
    4770:	aa0003e6 	mov	x6, x0
    4774:	4f000400 	movi	v0.4s, #0x0
    4778:	91018288 	add	x8, x20, #0x60
    477c:	52800027 	mov	w7, #0x1                   	// #1
    4780:	f9403661 	ldr	x1, [x19, #104]
    4784:	aa1303e5 	mov	x5, x19
    4788:	f9408a73 	ldr	x19, [x19, #272]
    478c:	eb06003f 	cmp	x1, x6
    4790:	5400032c 	b.gt	47f4 <fwp_poll_events+0x1b0>
    4794:	394154a0 	ldrb	w0, [x5, #85]
    4798:	36000120 	tbz	w0, #0, 47bc <fwp_poll_events+0x178>
    479c:	f94084a0 	ldr	x0, [x5, #264]
    47a0:	b40003c0 	cbz	x0, 4818 <fwp_poll_events+0x1d4>
    47a4:	f9008813 	str	x19, [x0, #272]
    47a8:	b4000053 	cbz	x19, 47b0 <fwp_poll_events+0x16c>
    47ac:	f9008660 	str	x0, [x19, #264]
    47b0:	910800a0 	add	x0, x5, #0x200
    47b4:	390154bf 	strb	wzr, [x5, #85]
    47b8:	3c908000 	stur	q0, [x0, #-248]
    47bc:	f94030a0 	ldr	x0, [x5, #96]
    47c0:	390158a7 	strb	w7, [x5, #86]
    47c4:	f100001f 	cmp	x0, #0x0
    47c8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    47cc:	5400018d 	b.le	47fc <fwp_poll_events+0x1b8>
    47d0:	f94028a0 	ldr	x0, [x5, #80]
    47d4:	f2001c1f 	tst	x0, #0xff000000ff
    47d8:	540000e1 	b.ne	47f4 <fwp_poll_events+0x1b0>  // b.any
    47dc:	f9406100 	ldr	x0, [x8, #192]
    47e0:	390150a7 	strb	w7, [x5, #84]
    47e4:	f90080bf 	str	xzr, [x5, #256]
    47e8:	b40001e0 	cbz	x0, 4824 <fwp_poll_events+0x1e0>
    47ec:	f9006105 	str	x5, [x8, #192]
    47f0:	f9008005 	str	x5, [x0, #256]
    47f4:	b5fffc73 	cbnz	x19, 4780 <fwp_poll_events+0x13c>
    47f8:	17ffffd2 	b	4740 <fwp_poll_events+0xfc>
    47fc:	394144a0 	ldrb	w0, [x5, #81]
    4800:	3707fe80 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    4804:	394140a0 	ldrb	w0, [x5, #80]
    4808:	3707fe40 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    480c:	aa0503e0 	mov	x0, x5
    4810:	97fffb98 	bl	3670 <fwp_cancel_tree.part.0>
    4814:	17ffffef 	b	47d0 <fwp_poll_events+0x18c>
    4818:	91018281 	add	x1, x20, #0x60
    481c:	f9009433 	str	x19, [x1, #296]
    4820:	17ffffe2 	b	47a8 <fwp_poll_events+0x164>
    4824:	f9006105 	str	x5, [x8, #192]
    4828:	f9006505 	str	x5, [x8, #200]
    482c:	17fffff2 	b	47f4 <fwp_poll_events+0x1b0>
    4830:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4834:	d2989362 	mov	x2, #0xc49b                	// #50331
    4838:	f2a4d203 	movk	x3, #0x2690, lsl #16
    483c:	f2a00402 	movk	x2, #0x20, lsl #16
    4840:	17ffffb7 	b	471c <fwp_poll_events+0xd8>
    4844:	97fff9ec 	bl	2ff4 <fwp_flush>
    4848:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    484c:	f947e863 	ldr	x3, [x3, #4048]
    4850:	d2800562 	mov	x2, #0x2b                  	// #43
    4854:	d2800021 	mov	x1, #0x1                   	// #1
    4858:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    485c:	91342000 	add	x0, x0, #0xd08
    4860:	f9400063 	ldr	x3, [x3]
    4864:	97fff82b 	bl	2910 <fwrite@plt>
    4868:	52800ca0 	mov	w0, #0x65                  	// #101
    486c:	97fff795 	bl	26c0 <exit@plt>
    4870:	97fff7e8 	bl	2810 <__stack_chk_fail@plt>

0000000000004874 <fwp_rc_wide_dup>:
    4874:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4878:	910003fd 	mov	x29, sp
    487c:	a90153f3 	stp	x19, x20, [sp, #16]
    4880:	aa0003f3 	mov	x19, x0
    4884:	ca404400 	eor	x0, x0, x0, lsr #17
    4888:	f90013f5 	str	x21, [sp, #32]
    488c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4890:	ca402400 	eor	x0, x0, x0, lsr #9
    4894:	911902a2 	add	x2, x21, #0x640
    4898:	92401c00 	and	x0, x0, #0xff
    489c:	910a2403 	add	x3, x0, #0x289
    48a0:	8b000c40 	add	x0, x2, x0, lsl #3
    48a4:	8b030c54 	add	x20, x2, x3, lsl #3
    48a8:	f94a2401 	ldr	x1, [x0, #5192]
    48ac:	b50000a1 	cbnz	x1, 48c0 <fwp_rc_wide_dup+0x4c>
    48b0:	1400002d 	b	4964 <fwp_rc_wide_dup+0xf0>
    48b4:	91004034 	add	x20, x1, #0x10
    48b8:	f9400821 	ldr	x1, [x1, #16]
    48bc:	b4000241 	cbz	x1, 4904 <fwp_rc_wide_dup+0x90>
    48c0:	f9400022 	ldr	x2, [x1]
    48c4:	eb02027f 	cmp	x19, x2
    48c8:	54ffff61 	b.ne	48b4 <fwp_rc_wide_dup+0x40>  // b.any
    48cc:	f9400281 	ldr	x1, [x20]
    48d0:	39400260 	ldrb	w0, [x19]
    48d4:	7103f81f 	cmp	w0, #0xfe
    48d8:	54000220 	b.eq	491c <fwp_rc_wide_dup+0xa8>  // b.none
    48dc:	b40001a1 	cbz	x1, 4910 <fwp_rc_wide_dup+0x9c>
    48e0:	f9400420 	ldr	x0, [x1, #8]
    48e4:	b100041f 	cmn	x0, #0x1
    48e8:	540004a0 	b.eq	497c <fwp_rc_wide_dup+0x108>  // b.none
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f9000420 	str	x0, [x1, #8]
    48f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f8:	f94013f5 	ldr	x21, [sp, #32]
    48fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4900:	d65f03c0 	ret
    4904:	39400260 	ldrb	w0, [x19]
    4908:	7103f81f 	cmp	w0, #0xfe
    490c:	540000a0 	b.eq	4920 <fwp_rc_wide_dup+0xac>  // b.none
    4910:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    4914:	91358000 	add	x0, x0, #0xd60
    4918:	97fffb9a 	bl	3780 <fwp_trap>
    491c:	b5000281 	cbnz	x1, 496c <fwp_rc_wide_dup+0xf8>
    4920:	d2800300 	mov	x0, #0x18                  	// #24
    4924:	97fff7a3 	bl	27b0 <malloc@plt>
    4928:	b4000280 	cbz	x0, 4978 <fwp_rc_wide_dup+0x104>
    492c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4930:	a9000413 	stp	x19, x1, [x0]
    4934:	911902b5 	add	x21, x21, #0x640
    4938:	f900081f 	str	xzr, [x0, #16]
    493c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4940:	f9000280 	str	x0, [x20]
    4944:	39000261 	strb	w1, [x19]
    4948:	f94e26a0 	ldr	x0, [x21, #7240]
    494c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4950:	91000400 	add	x0, x0, #0x1
    4954:	f90e26a0 	str	x0, [x21, #7240]
    4958:	f94013f5 	ldr	x21, [sp, #32]
    495c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4960:	d65f03c0 	ret
    4964:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4968:	17ffffda 	b	48d0 <fwp_rc_wide_dup+0x5c>
    496c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    4970:	9134e000 	add	x0, x0, #0xd38
    4974:	97fffb83 	bl	3780 <fwp_trap>
    4978:	97fff9de 	bl	30f0 <fwp_heap_oom>
    497c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    4980:	91362000 	add	x0, x0, #0xd88
    4984:	97fffb7f 	bl	3780 <fwp_trap>
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_rc_forget_slot>:
    4990:	aa0003e1 	mov	x1, x0
    4994:	39400000 	ldrb	w0, [x0]
    4998:	7103fc1f 	cmp	w0, #0xff
    499c:	54000040 	b.eq	49a4 <fwp_rc_forget_slot+0x14>  // b.none
    49a0:	d65f03c0 	ret
    49a4:	ca414420 	eor	x0, x1, x1, lsr #17
    49a8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    49ac:	ca402400 	eor	x0, x0, x0, lsr #9
    49b0:	910003fd 	mov	x29, sp
    49b4:	92401c00 	and	x0, x0, #0xff
    49b8:	f9000bf3 	str	x19, [sp, #16]
    49bc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    49c0:	91190262 	add	x2, x19, #0x640
    49c4:	910a2403 	add	x3, x0, #0x289
    49c8:	8b000c40 	add	x0, x2, x0, lsl #3
    49cc:	8b030c43 	add	x3, x2, x3, lsl #3
    49d0:	f94a2400 	ldr	x0, [x0, #5192]
    49d4:	b50000a0 	cbnz	x0, 49e8 <fwp_rc_forget_slot+0x58>
    49d8:	14000011 	b	4a1c <fwp_rc_forget_slot+0x8c>
    49dc:	91004003 	add	x3, x0, #0x10
    49e0:	f9400800 	ldr	x0, [x0, #16]
    49e4:	b40001c0 	cbz	x0, 4a1c <fwp_rc_forget_slot+0x8c>
    49e8:	f9400002 	ldr	x2, [x0]
    49ec:	eb02003f 	cmp	x1, x2
    49f0:	54ffff61 	b.ne	49dc <fwp_rc_forget_slot+0x4c>  // b.any
    49f4:	f9400801 	ldr	x1, [x0, #16]
    49f8:	91190273 	add	x19, x19, #0x640
    49fc:	f9000061 	str	x1, [x3]
    4a00:	97fff7b4 	bl	28d0 <free@plt>
    4a04:	f94e2660 	ldr	x0, [x19, #7240]
    4a08:	d1000400 	sub	x0, x0, #0x1
    4a0c:	f90e2660 	str	x0, [x19, #7240]
    4a10:	f9400bf3 	ldr	x19, [sp, #16]
    4a14:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a18:	d65f03c0 	ret
    4a1c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    4a20:	91358000 	add	x0, x0, #0xd60
    4a24:	97fffb57 	bl	3780 <fwp_trap>
    4a28:	d503201f 	nop
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_rc_prepare_chunk>:
    4a30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xba0>
    4a40:	911902c2 	add	x2, x22, #0x640
    4a44:	b9401c03 	ldr	w3, [x0, #28]
    4a48:	aa0103f5 	mov	x21, x1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	aa0003f4 	mov	x20, x0
    4a54:	f94e2440 	ldr	x0, [x2, #7240]
    4a58:	b4000440 	cbz	x0, 4ae0 <fwp_rc_prepare_chunk+0xb0>
    4a5c:	d2800013 	mov	x19, #0x0                   	// #0
    4a60:	35000203 	cbnz	w3, 4aa0 <fwp_rc_prepare_chunk+0x70>
    4a64:	b4000361 	cbz	x1, 4ad0 <fwp_rc_prepare_chunk+0xa0>
    4a68:	f9401280 	ldr	x0, [x20, #32]
    4a6c:	97fff799 	bl	28d0 <free@plt>
    4a70:	aa1503e0 	mov	x0, x21
    4a74:	d2800021 	mov	x1, #0x1                   	// #1
    4a78:	97fff75e 	bl	27f0 <calloc@plt>
    4a7c:	f9001280 	str	x0, [x20, #32]
    4a80:	b5000460 	cbnz	x0, 4b0c <fwp_rc_prepare_chunk+0xdc>
    4a84:	97fff99b 	bl	30f0 <fwp_heap_oom>
    4a88:	97ffffc2 	bl	4990 <fwp_rc_forget_slot>
    4a8c:	91000673 	add	x19, x19, #0x1
    4a90:	b9401e83 	ldr	w3, [x20, #28]
    4a94:	eb13007f 	cmp	x3, x19
    4a98:	54000169 	b.ls	4ac4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4a9c:	d503201f 	nop
    4aa0:	f9401283 	ldr	x3, [x20, #32]
    4aa4:	8b130060 	add	x0, x3, x19
    4aa8:	38736863 	ldrb	w3, [x3, x19]
    4aac:	7103fc7f 	cmp	w3, #0xff
    4ab0:	54fffec0 	b.eq	4a88 <fwp_rc_prepare_chunk+0x58>  // b.none
    4ab4:	b9401e83 	ldr	w3, [x20, #28]
    4ab8:	91000673 	add	x19, x19, #0x1
    4abc:	eb13007f 	cmp	x3, x19
    4ac0:	54ffff08 	b.hi	4aa0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4ac4:	eb0302bf 	cmp	x21, x3
    4ac8:	54000121 	b.ne	4aec <fwp_rc_prepare_chunk+0xbc>  // b.any
    4acc:	b5000335 	cbnz	x21, 4b30 <fwp_rc_prepare_chunk+0x100>
    4ad0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ad8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4adc:	d65f03c0 	ret
    4ae0:	2a0303e3 	mov	w3, w3
    4ae4:	eb0302bf 	cmp	x21, x3
    4ae8:	54ffff20 	b.eq	4acc <fwp_rc_prepare_chunk+0x9c>  // b.none
    4aec:	911902c2 	add	x2, x22, #0x640
    4af0:	f9401280 	ldr	x0, [x20, #32]
    4af4:	f94e2841 	ldr	x1, [x2, #7248]
    4af8:	cb030021 	sub	x1, x1, x3
    4afc:	f90e2841 	str	x1, [x2, #7248]
    4b00:	97fff774 	bl	28d0 <free@plt>
    4b04:	b5fffb75 	cbnz	x21, 4a70 <fwp_rc_prepare_chunk+0x40>
    4b08:	f900129f 	str	xzr, [x20, #32]
    4b0c:	911902d6 	add	x22, x22, #0x640
    4b10:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b14:	b9001e95 	str	w21, [x20, #28]
    4b18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b1c:	8b150000 	add	x0, x0, x21
    4b20:	f90e2ac0 	str	x0, [x22, #7248]
    4b24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b2c:	d65f03c0 	ret
    4b30:	f9401280 	ldr	x0, [x20, #32]
    4b34:	aa1503e2 	mov	x2, x21
    4b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b3c:	52800001 	mov	w1, #0x0                   	// #0
    4b40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b48:	17fff726 	b	27e0 <memset@plt>
    4b4c:	d503201f 	nop

0000000000004b50 <fwp_heap_refill>:
    4b50:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b54:	910003fd 	mov	x29, sp
    4b58:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b5c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4b60:	911902b5 	add	x21, x21, #0x640
    4b64:	aa0003f6 	mov	x22, x0
    4b68:	d2800020 	mov	x0, #0x1                   	// #1
    4b6c:	a90153f3 	stp	x19, x20, [sp, #16]
    4b70:	a90363f7 	stp	x23, x24, [sp, #48]
    4b74:	2a0103f7 	mov	w23, w1
    4b78:	2a0203f8 	mov	w24, w2
    4b7c:	97fff96d 	bl	3130 <fwp_heap_chunks>
    4b80:	aa0003f3 	mov	x19, x0
    4b84:	f949fea2 	ldr	x2, [x21, #5112]
    4b88:	8b000800 	add	x0, x0, x0, lsl #2
    4b8c:	2a1703e1 	mov	w1, w23
    4b90:	52800025 	mov	w5, #0x1                   	// #1
    4b94:	d37df000 	lsl	x0, x0, #3
    4b98:	910f0021 	add	x1, x1, #0x3c0
    4b9c:	8b000054 	add	x20, x2, x0
    4ba0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4ba4:	52a00024 	mov	w4, #0x10000               	// #65536
    4ba8:	38206845 	strb	w5, [x2, x0]
    4bac:	aa1403e0 	mov	x0, x20
    4bb0:	39000698 	strb	w24, [x20, #1]
    4bb4:	39000a97 	strb	w23, [x20, #2]
    4bb8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4bbc:	b9000681 	str	w1, [x20, #4]
    4bc0:	2a0103e5 	mov	w5, w1
    4bc4:	8b0300a2 	add	x2, x5, x3
    4bc8:	1ac10881 	udiv	w1, w4, w1
    4bcc:	9ac50842 	udiv	x2, x2, x5
    4bd0:	b9000a81 	str	w1, [x20, #8]
    4bd4:	92404021 	and	x1, x1, #0x1ffff
    4bd8:	b9001a82 	str	w2, [x20, #24]
    4bdc:	97ffff95 	bl	4a30 <fwp_rc_prepare_chunk>
    4be0:	f949daa0 	ldr	x0, [x21, #5040]
    4be4:	29408a81 	ldp	w1, w2, [x20, #4]
    4be8:	8b134000 	add	x0, x0, x19, lsl #16
    4bec:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf0:	8b214003 	add	x3, x0, w1, uxtw
    4bf4:	9ba20021 	umaddl	x1, w1, w2, x0
    4bf8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bfc:	a90086c3 	stp	x3, x1, [x22, #8]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c08:	d65f03c0 	ret
    4c0c:	d503201f 	nop

0000000000004c10 <fwp_mem_free>:
    4c10:	b40003c0 	cbz	x0, 4c88 <fwp_mem_free+0x78>
    4c14:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c18:	910003fd 	mov	x29, sp
    4c1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c20:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4c24:	911902a1 	add	x1, x21, #0x640
    4c28:	a90153f3 	stp	x19, x20, [sp, #16]
    4c2c:	aa0003f3 	mov	x19, x0
    4c30:	f949d823 	ldr	x3, [x1, #5040]
    4c34:	f949ec22 	ldr	x2, [x1, #5080]
    4c38:	cb030000 	sub	x0, x0, x3
    4c3c:	eb02401f 	cmp	x0, x2, lsl #16
    4c40:	540001c2 	b.cs	4c78 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4c44:	d350fc16 	lsr	x22, x0, #16
    4c48:	a90363f7 	stp	x23, x24, [sp, #48]
    4c4c:	f949fc22 	ldr	x2, [x1, #5112]
    4c50:	8b160ad4 	add	x20, x22, x22, lsl #2
    4c54:	d37df294 	lsl	x20, x20, #3
    4c58:	ab140057 	adds	x23, x2, x20
    4c5c:	540000c0 	b.eq	4c74 <fwp_mem_free+0x64>  // b.none
    4c60:	38746842 	ldrb	w2, [x2, x20]
    4c64:	7100045f 	cmp	w2, #0x1
    4c68:	54000120 	b.eq	4c8c <fwp_mem_free+0x7c>  // b.none
    4c6c:	7100085f 	cmp	w2, #0x2
    4c70:	540005e0 	b.eq	4d2c <fwp_mem_free+0x11c>  // b.none
    4c74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c80:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c84:	d65f03c0 	ret
    4c88:	d65f03c0 	ret
    4c8c:	f94012f8 	ldr	x24, [x23, #32]
    4c90:	b94006e1 	ldr	w1, [x23, #4]
    4c94:	f90023f9 	str	x25, [sp, #64]
    4c98:	2a0103e2 	mov	w2, w1
    4c9c:	394006f9 	ldrb	w25, [x23, #1]
    4ca0:	39400af4 	ldrb	w20, [x23, #2]
    4ca4:	b4000158 	cbz	x24, 4ccc <fwp_mem_free+0xbc>
    4ca8:	92403e76 	and	x22, x19, #0xffff
    4cac:	9ac20ad6 	udiv	x22, x22, x2
    4cb0:	38766b01 	ldrb	w1, [x24, x22]
    4cb4:	8b160300 	add	x0, x24, x22
    4cb8:	7103fc3f 	cmp	w1, #0xff
    4cbc:	54000980 	b.eq	4dec <fwp_mem_free+0x1dc>  // b.none
    4cc0:	38366b1f 	strb	wzr, [x24, x22]
    4cc4:	b94006e1 	ldr	w1, [x23, #4]
    4cc8:	2a0103e2 	mov	w2, w1
    4ccc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4cd0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4cd4:	cb390000 	sub	x0, x0, w25, uxtb
    4cd8:	8b340074 	add	x20, x3, w20, uxtb
    4cdc:	911902b5 	add	x21, x21, #0x640
    4ce0:	1e630021 	ucvtf	d1, w1
    4ce4:	d37ae400 	lsl	x0, x0, #6
    4ce8:	8b140c14 	add	x20, x0, x20, lsl #3
    4cec:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf0:	f8746aa0 	ldr	x0, [x21, x20]
    4cf4:	f94023f9 	ldr	x25, [sp, #64]
    4cf8:	aa2003e0 	mvn	x0, x0
    4cfc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d00:	f9000260 	str	x0, [x19]
    4d04:	f8346ab3 	str	x19, [x21, x20]
    4d08:	f94a12a0 	ldr	x0, [x21, #5152]
    4d0c:	1e612800 	fadd	d0, d0, d1
    4d10:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d14:	cb020000 	sub	x0, x0, x2
    4d18:	f90a12a0 	str	x0, [x21, #5152]
    4d1c:	fd0a22a0 	str	d0, [x21, #5184]
    4d20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d24:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d28:	d65f03c0 	ret
    4d2c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4d30:	8b000063 	add	x3, x3, x0
    4d34:	eb03027f 	cmp	x19, x3
    4d38:	54fff9e1 	b.ne	4c74 <fwp_mem_free+0x64>  // b.any
    4d3c:	fd400ae1 	ldr	d1, [x23, #16]
    4d40:	fd4a2020 	ldr	d0, [x1, #5184]
    4d44:	f9400ae0 	ldr	x0, [x23, #16]
    4d48:	7e61d821 	ucvtf	d1, d1
    4d4c:	f94a1022 	ldr	x2, [x1, #5152]
    4d50:	f94012f3 	ldr	x19, [x23, #32]
    4d54:	1e612800 	fadd	d0, d0, d1
    4d58:	cb000042 	sub	x2, x2, x0
    4d5c:	f90a1022 	str	x2, [x1, #5152]
    4d60:	fd0a2020 	str	d0, [x1, #5184]
    4d64:	b40000b3 	cbz	x19, 4d78 <fwp_mem_free+0x168>
    4d68:	39400260 	ldrb	w0, [x19]
    4d6c:	7103fc1f 	cmp	w0, #0xff
    4d70:	54000380 	b.eq	4de0 <fwp_mem_free+0x1d0>  // b.none
    4d74:	3900027f 	strb	wzr, [x19]
    4d78:	b9400ee2 	ldr	w2, [x23, #12]
    4d7c:	b4000142 	cbz	x2, 4da4 <fwp_mem_free+0x194>
    4d80:	911902a1 	add	x1, x21, #0x640
    4d84:	8b160040 	add	x0, x2, x22
    4d88:	8b000800 	add	x0, x0, x0, lsl #2
    4d8c:	f949fc21 	ldr	x1, [x1, #5112]
    4d90:	8b140034 	add	x20, x1, x20
    4d94:	8b000c20 	add	x0, x1, x0, lsl #3
    4d98:	3802869f 	strb	wzr, [x20], #40
    4d9c:	eb00029f 	cmp	x20, x0
    4da0:	54ffffc1 	b.ne	4d98 <fwp_mem_free+0x188>  // b.any
    4da4:	911902a0 	add	x0, x21, #0x640
    4da8:	f94a1801 	ldr	x1, [x0, #5168]
    4dac:	f949f803 	ldr	x3, [x0, #5104]
    4db0:	8b020021 	add	x1, x1, x2
    4db4:	f90a1801 	str	x1, [x0, #5168]
    4db8:	eb16007f 	cmp	x3, x22
    4dbc:	54000049 	b.ls	4dc4 <fwp_mem_free+0x1b4>  // b.plast
    4dc0:	f909f816 	str	x22, [x0, #5104]
    4dc4:	911902b5 	add	x21, x21, #0x640
    4dc8:	f949f6a0 	ldr	x0, [x21, #5096]
    4dcc:	eb16001f 	cmp	x0, x22
    4dd0:	54fff529 	b.ls	4c74 <fwp_mem_free+0x64>  // b.plast
    4dd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dd8:	f909f6b6 	str	x22, [x21, #5096]
    4ddc:	17ffffa7 	b	4c78 <fwp_mem_free+0x68>
    4de0:	aa1303e0 	mov	x0, x19
    4de4:	97fffeeb 	bl	4990 <fwp_rc_forget_slot>
    4de8:	17ffffe3 	b	4d74 <fwp_mem_free+0x164>
    4dec:	97fffee9 	bl	4990 <fwp_rc_forget_slot>
    4df0:	17ffffb4 	b	4cc0 <fwp_mem_free+0xb0>

0000000000004df4 <fwp_heap_alloc_big>:
    4df4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df8:	910003fd 	mov	x29, sp
    4dfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4e00:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e04:	a90363f7 	stp	x23, x24, [sp, #48]
    4e08:	aa0003f7 	mov	x23, x0
    4e0c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e10:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e14:	eb0002ff 	cmp	x23, x0
    4e18:	54000888 	b.hi	4f28 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e1c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e20:	8b0002f4 	add	x20, x23, x0
    4e24:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xba0>
    4e28:	91190359 	add	x25, x26, #0x640
    4e2c:	d350fe94 	lsr	x20, x20, #16
    4e30:	2a0103f5 	mov	w21, w1
    4e34:	aa1403e0 	mov	x0, x20
    4e38:	97fff8be 	bl	3130 <fwp_heap_chunks>
    4e3c:	f949ff22 	ldr	x2, [x25, #5112]
    4e40:	8b000813 	add	x19, x0, x0, lsl #2
    4e44:	aa0003f8 	mov	x24, x0
    4e48:	52800043 	mov	w3, #0x2                   	// #2
    4e4c:	d37df273 	lsl	x19, x19, #3
    4e50:	d2800021 	mov	x1, #0x1                   	// #1
    4e54:	8b130040 	add	x0, x2, x19
    4e58:	38336843 	strb	w3, [x2, x19]
    4e5c:	39000415 	strb	w21, [x0, #1]
    4e60:	b9000c14 	str	w20, [x0, #12]
    4e64:	f9000817 	str	x23, [x0, #16]
    4e68:	97fffef2 	bl	4a30 <fwp_rc_prepare_chunk>
    4e6c:	f100069f 	cmp	x20, #0x1
    4e70:	54000269 	b.ls	4ebc <fwp_heap_alloc_big+0xc8>  // b.plast
    4e74:	8b180294 	add	x20, x20, x24
    4e78:	9100a273 	add	x19, x19, #0x28
    4e7c:	a90573fb 	stp	x27, x28, [sp, #80]
    4e80:	5280007b 	mov	w27, #0x3                   	// #3
    4e84:	8b140a94 	add	x20, x20, x20, lsl #2
    4e88:	2a1803fc 	mov	w28, w24
    4e8c:	9adb2296 	lsl	x22, x20, x27
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffee4 	bl	4a30 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0x9c>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	91190353 	add	x19, x26, #0x640
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9119035a 	add	x26, x26, #0x640
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    4f40:	91190262 	add	x2, x19, #0x640
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	91190262 	add	x2, x19, #0x640
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	91190260 	add	x0, x19, #0x640
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	91190273 	add	x19, x19, #0x640
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffc1c 	bl	4084 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff70 	b	4df4 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	91190260 	add	x0, x19, #0x640
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffeb5 	bl	4b50 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f00000d6 	adrp	x22, 20000 <__data_start>
    50a0:	910182c2 	add	x2, x22, #0x60
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	54000861 	b.ne	51c4 <fwp_heap_alloc+0x134>  // b.any
    50bc:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xba0>
    50c0:	911902f3 	add	x19, x23, #0x640
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	540006e2 	b.cs	5210 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	911902e0 	add	x0, x23, #0x640
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	911902e1 	add	x1, x23, #0x640
    5168:	910182c0 	add	x0, x22, #0x60
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	540002cc 	b.gt	51d8 <fwp_heap_alloc+0x148>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000209 	b.ls	51f4 <fwp_heap_alloc+0x164>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	17ffffe8 	b	5160 <fwp_heap_alloc+0xd0>
    51c4:	a9538c44 	ldp	x4, x3, [x2, #312]
    51c8:	91000484 	add	x4, x4, #0x1
    51cc:	8b000063 	add	x3, x3, x0
    51d0:	a9138c44 	stp	x4, x3, [x2, #312]
    51d4:	17ffffba 	b	50bc <fwp_heap_alloc+0x2c>
    51d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    51dc:	fd00a800 	str	d0, [x0, #336]
    51e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51e4:	aa0403e0 	mov	x0, x4
    51e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    51ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f0:	d65f03c0 	ret
    51f4:	7100043f 	cmp	w1, #0x1
    51f8:	8b140085 	add	x5, x4, x20
    51fc:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5200:	52800001 	mov	w1, #0x0                   	// #0
    5204:	aa0403e0 	mov	x0, x4
    5208:	f9000465 	str	x5, [x3, #8]
    520c:	17ffffc6 	b	5124 <fwp_heap_alloc+0x94>
    5210:	97fff7b8 	bl	30f0 <fwp_heap_oom>

0000000000005214 <fwp_apply>:
    5214:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5218:	aa0003e6 	mov	x6, x0
    521c:	910003fd 	mov	x29, sp
    5220:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5224:	f947f463 	ldr	x3, [x3, #4072]
    5228:	a90153f3 	stp	x19, x20, [sp, #16]
    522c:	aa0203f4 	mov	x20, x2
    5230:	a9025bf5 	stp	x21, x22, [sp, #32]
    5234:	2a0103f5 	mov	w21, w1
    5238:	52800033 	mov	w19, #0x1                   	// #1
    523c:	a90363f7 	stp	x23, x24, [sp, #48]
    5240:	f00000d7 	adrp	x23, 20000 <__data_start>
    5244:	910182f7 	add	x23, x23, #0x60
    5248:	a9046bf9 	stp	x25, x26, [sp, #64]
    524c:	d100c3ff 	sub	sp, sp, #0x30
    5250:	f9400060 	ldr	x0, [x3]
    5254:	f81f83a0 	stur	x0, [x29, #-8]
    5258:	d2800000 	mov	x0, #0x0                   	// #0
    525c:	294058c3 	ldp	w3, w22, [x6]
    5260:	910003f8 	mov	x24, sp
    5264:	f9406ae0 	ldr	x0, [x23, #208]
    5268:	710002df 	cmp	w22, #0x0
    526c:	d37be863 	lsl	x3, x3, #5
    5270:	8b030007 	add	x7, x0, x3
    5274:	b8636819 	ldr	w25, [x0, x3]
    5278:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    527c:	54000163 	b.cc	52a8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5280:	f94004e3 	ldr	x3, [x7, #8]
    5284:	34000bd9 	cbz	w25, 53fc <fwp_apply+0x1e8>
    5288:	aa1403e0 	mov	x0, x20
    528c:	d63f0060 	blr	x3
    5290:	aa0003e6 	mov	x6, x0
    5294:	6b1902bf 	cmp	w21, w25
    5298:	54000940 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    529c:	8b394e94 	add	x20, x20, w25, uxtw #3
    52a0:	4b1902b5 	sub	w21, w21, w25
    52a4:	17ffffee 	b	525c <fwp_apply+0x48>
    52a8:	0b1602ba 	add	w26, w21, w22
    52ac:	6b19035f 	cmp	w26, w25
    52b0:	54000543 	b.cc	5358 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    52b4:	7100033f 	cmp	w25, #0x0
    52b8:	4b16033a 	sub	w26, w25, w22
    52bc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52c0:	d37df000 	lsl	x0, x0, #3
    52c4:	91003c00 	add	x0, x0, #0xf
    52c8:	92704c01 	and	x1, x0, #0xfffff0000
    52cc:	927c7c00 	and	x0, x0, #0xffffffff0
    52d0:	cb2163e1 	sub	x1, sp, x1
    52d4:	eb2163ff 	cmp	sp, x1
    52d8:	540000a0 	b.eq	52ec <fwp_apply+0xd8>  // b.none
    52dc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52e0:	f90203ff 	str	xzr, [sp, #1024]
    52e4:	eb2163ff 	cmp	sp, x1
    52e8:	54ffffa1 	b.ne	52dc <fwp_apply+0xc8>  // b.any
    52ec:	92403c00 	and	x0, x0, #0xffff
    52f0:	cb2063ff 	sub	sp, sp, x0
    52f4:	f90003ff 	str	xzr, [sp]
    52f8:	f110001f 	cmp	x0, #0x400
    52fc:	54000962 	b.cs	5428 <fwp_apply+0x214>  // b.hs, b.nlast
    5300:	910020c6 	add	x6, x6, #0x8
    5304:	910043e0 	add	x0, sp, #0x10
    5308:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    530c:	d2800003 	mov	x3, #0x0                   	// #0
    5310:	340000f6 	cbz	w22, 532c <fwp_apply+0x118>
    5314:	d503201f 	nop
    5318:	f86368c4 	ldr	x4, [x6, x3]
    531c:	f8236804 	str	x4, [x0, x3]
    5320:	91002063 	add	x3, x3, #0x8
    5324:	eb0300bf 	cmp	x5, x3
    5328:	54ffff81 	b.ne	5318 <fwp_apply+0x104>  // b.any
    532c:	3400013a 	cbz	w26, 5350 <fwp_apply+0x13c>
    5330:	2a1a03e6 	mov	w6, w26
    5334:	d2800003 	mov	x3, #0x0                   	// #0
    5338:	0b0302c4 	add	w4, w22, w3
    533c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5340:	91000463 	add	x3, x3, #0x1
    5344:	f8247805 	str	x5, [x0, x4, lsl #3]
    5348:	eb0300df 	cmp	x6, x3
    534c:	54ffff61 	b.ne	5338 <fwp_apply+0x124>  // b.any
    5350:	f94004e3 	ldr	x3, [x7, #8]
    5354:	1400002c 	b	5404 <fwp_apply+0x1f0>
    5358:	11000740 	add	w0, w26, #0x1
    535c:	52800041 	mov	w1, #0x2                   	// #2
    5360:	f81e83a6 	stur	x6, [x29, #-24]
    5364:	d37df000 	lsl	x0, x0, #3
    5368:	97ffff4a 	bl	5090 <fwp_heap_alloc>
    536c:	f85e83a6 	ldur	x6, [x29, #-24]
    5370:	aa0003f3 	mov	x19, x0
    5374:	b94000c1 	ldr	w1, [x6]
    5378:	29006801 	stp	w1, w26, [x0]
    537c:	340000b6 	cbz	w22, 5390 <fwp_apply+0x17c>
    5380:	910020c1 	add	x1, x6, #0x8
    5384:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5388:	91002000 	add	x0, x0, #0x8
    538c:	97fff4bd 	bl	2680 <memmove@plt>
    5390:	2a1503e3 	mov	w3, w21
    5394:	d2800000 	mov	x0, #0x0                   	// #0
    5398:	34000135 	cbz	w21, 53bc <fwp_apply+0x1a8>
    539c:	d503201f 	nop
    53a0:	0b0002c1 	add	w1, w22, w0
    53a4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53a8:	8b010e61 	add	x1, x19, x1, lsl #3
    53ac:	91000400 	add	x0, x0, #0x1
    53b0:	f9000422 	str	x2, [x1, #8]
    53b4:	eb00007f 	cmp	x3, x0
    53b8:	54ffff41 	b.ne	53a0 <fwp_apply+0x18c>  // b.any
    53bc:	aa1303e6 	mov	x6, x19
    53c0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    53c4:	f947f400 	ldr	x0, [x0, #4072]
    53c8:	f85f83a2 	ldur	x2, [x29, #-8]
    53cc:	f9400001 	ldr	x1, [x0]
    53d0:	eb010042 	subs	x2, x2, x1
    53d4:	d2800001 	mov	x1, #0x0                   	// #0
    53d8:	540002c1 	b.ne	5430 <fwp_apply+0x21c>  // b.any
    53dc:	910003bf 	mov	sp, x29
    53e0:	aa0603e0 	mov	x0, x6
    53e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53f4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53f8:	d65f03c0 	ret
    53fc:	d10043a0 	sub	x0, x29, #0x10
    5400:	5280001a 	mov	w26, #0x0                   	// #0
    5404:	d63f0060 	blr	x3
    5408:	aa0003e6 	mov	x6, x0
    540c:	6b1a02bf 	cmp	w21, w26
    5410:	54fffd80 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    5414:	0b1602b6 	add	w22, w21, w22
    5418:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    541c:	4b1902d5 	sub	w21, w22, w25
    5420:	9100031f 	mov	sp, x24
    5424:	17ffff8e 	b	525c <fwp_apply+0x48>
    5428:	f90203ff 	str	xzr, [sp, #1024]
    542c:	17ffffb5 	b	5300 <fwp_apply+0xec>
    5430:	97fff4f8 	bl	2810 <__stack_chk_fail@plt>

0000000000005434 <fwp_p_ad_push>:
    5434:	f100001f 	cmp	x0, #0x0
    5438:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    543c:	54000eab 	b.lt	5610 <fwp_p_ad_push+0x1dc>  // b.tstop
    5440:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5444:	aa0003e4 	mov	x4, x0
    5448:	910003fd 	mov	x29, sp
    544c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5450:	aa0003f5 	mov	x21, x0
    5454:	aa020000 	orr	x0, x0, x2
    5458:	a90363f7 	stp	x23, x24, [sp, #48]
    545c:	aa0203f7 	mov	x23, x2
    5460:	6d0627e8 	stp	d8, d9, [sp, #96]
    5464:	9e670029 	fmov	d9, x1
    5468:	9e670068 	fmov	d8, x3
    546c:	b6f80920 	tbz	x0, #63, 5590 <fwp_p_ad_push+0x15c>
    5470:	a90153f3 	stp	x19, x20, [sp, #16]
    5474:	9360fc80 	asr	x0, x4, #32
    5478:	b6f800c4 	tbz	x4, #63, 5490 <fwp_p_ad_push+0x5c>
    547c:	1e604109 	fmov	d9, d8
    5480:	2f00e408 	movi	d8, #0x0
    5484:	9360fc40 	asr	x0, x2, #32
    5488:	aa0203f5 	mov	x21, x2
    548c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5490:	97fff988 	bl	3ab0 <fwp_tape_of>
    5494:	aa0003f3 	mov	x19, x0
    5498:	f9403000 	ldr	x0, [x0, #96]
    549c:	b5001240 	cbnz	x0, 56e4 <fwp_p_ad_push+0x2b0>
    54a0:	f9400a76 	ldr	x22, [x19, #16]
    54a4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54a8:	eb0002df 	cmp	x22, x0
    54ac:	54000d8c 	b.gt	565c <fwp_p_ad_push+0x228>
    54b0:	eb3542df 	cmp	x22, w21, uxtw
    54b4:	54000cad 	b.le	5648 <fwp_p_ad_push+0x214>
    54b8:	b7f80077 	tbnz	x23, #63, 54c4 <fwp_p_ad_push+0x90>
    54bc:	eb3742df 	cmp	x22, w23, uxtw
    54c0:	54000c4d 	b.le	5648 <fwp_p_ad_push+0x214>
    54c4:	f9400678 	ldr	x24, [x19, #8]
    54c8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54cc:	cb1802d8 	sub	x24, x22, x24
    54d0:	91000701 	add	x1, x24, #0x1
    54d4:	eb00003f 	cmp	x1, x0
    54d8:	54000c28 	b.hi	565c <fwp_p_ad_push+0x228>  // b.pmore
    54dc:	a9418274 	ldp	x20, x0, [x19, #24]
    54e0:	a90573fb 	stp	x27, x28, [sp, #80]
    54e4:	eb14003f 	cmp	x1, x20
    54e8:	540006ad 	b.le	55bc <fwp_p_ad_push+0x188>
    54ec:	f100029f 	cmp	x20, #0x0
    54f0:	d2800803 	mov	x3, #0x40                  	// #64
    54f4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54f8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54fc:	a9046bf9 	stp	x25, x26, [sp, #64]
    5500:	eb14003f 	cmp	x1, x20
    5504:	5400008d 	b.le	5514 <fwp_p_ad_push+0xe0>
    5508:	eb02029f 	cmp	x20, x2
    550c:	5400054d 	b.le	55b4 <fwp_p_ad_push+0x180>
    5510:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5514:	d37df299 	lsl	x25, x20, #3
    5518:	52800022 	mov	w2, #0x1                   	// #1
    551c:	aa1903e1 	mov	x1, x25
    5520:	97fffbad 	bl	43d4 <ad_raw_realloc>
    5524:	aa0003e1 	mov	x1, x0
    5528:	b4000a40 	cbz	x0, 5670 <fwp_p_ad_push+0x23c>
    552c:	f9400e63 	ldr	x3, [x19, #24]
    5530:	f9001261 	str	x1, [x19, #32]
    5534:	f9401a60 	ldr	x0, [x19, #48]
    5538:	52800042 	mov	w2, #0x2                   	// #2
    553c:	8b030821 	add	x1, x1, x3, lsl #2
    5540:	f9001661 	str	x1, [x19, #40]
    5544:	d37cee81 	lsl	x1, x20, #4
    5548:	97fffba3 	bl	43d4 <ad_raw_realloc>
    554c:	aa0003e2 	mov	x2, x0
    5550:	b4000900 	cbz	x0, 5670 <fwp_p_ad_push+0x23c>
    5554:	f9400e61 	ldr	x1, [x19, #24]
    5558:	d37df31b 	lsl	x27, x24, #3
    555c:	d37ef69a 	lsl	x26, x20, #2
    5560:	d37ef71c 	lsl	x28, x24, #2
    5564:	8b190003 	add	x3, x0, x25
    5568:	8b010c01 	add	x1, x0, x1, lsl #3
    556c:	a9030660 	stp	x0, x1, [x19, #48]
    5570:	b5000558 	cbnz	x24, 5618 <fwp_p_ad_push+0x1e4>
    5574:	f9001e63 	str	x3, [x19, #56]
    5578:	f9401260 	ldr	x0, [x19, #32]
    557c:	8b1a0001 	add	x1, x0, x26
    5580:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5584:	f9000e74 	str	x20, [x19, #24]
    5588:	f9001661 	str	x1, [x19, #40]
    558c:	14000010 	b	55cc <fwp_p_ad_push+0x198>
    5590:	9360fc40 	asr	x0, x2, #32
    5594:	a90153f3 	stp	x19, x20, [sp, #16]
    5598:	eb84801f 	cmp	x0, x4, asr #32
    559c:	54fff7a0 	b.eq	5490 <fwp_p_ad_push+0x5c>  // b.none
    55a0:	90000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    55a4:	9136a000 	add	x0, x0, #0xda8
    55a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    55ac:	a90573fb 	stp	x27, x28, [sp, #80]
    55b0:	97fff874 	bl	3780 <fwp_trap>
    55b4:	d37ffa94 	lsl	x20, x20, #1
    55b8:	17ffffd2 	b	5500 <fwp_p_ad_push+0xcc>
    55bc:	a9428a61 	ldp	x1, x2, [x19, #40]
    55c0:	d37ef71c 	lsl	x28, x24, #2
    55c4:	f9401e63 	ldr	x3, [x19, #56]
    55c8:	d37df31b 	lsl	x27, x24, #3
    55cc:	b83c6815 	str	w21, [x0, x28]
    55d0:	f10002ff 	cmp	x23, #0x0
    55d4:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    55d8:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55dc:	fc3b6849 	str	d9, [x2, x27]
    55e0:	aa1602a0 	orr	x0, x21, x22
    55e4:	b83c6837 	str	w23, [x1, x28]
    55e8:	910006d6 	add	x22, x22, #0x1
    55ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    55f0:	fc3b6868 	str	d8, [x3, x27]
    55f4:	a94573fb 	ldp	x27, x28, [sp, #80]
    55f8:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55fc:	f9000a76 	str	x22, [x19, #16]
    5600:	a94153f3 	ldp	x19, x20, [sp, #16]
    5604:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5608:	a8c77bfd 	ldp	x29, x30, [sp], #112
    560c:	d65f03c0 	ret
    5610:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5614:	d65f03c0 	ret
    5618:	aa0303e0 	mov	x0, x3
    561c:	aa1b03e2 	mov	x2, x27
    5620:	97fff418 	bl	2680 <memmove@plt>
    5624:	a9420660 	ldp	x0, x1, [x19, #32]
    5628:	aa1c03e2 	mov	x2, x28
    562c:	f9401a63 	ldr	x3, [x19, #48]
    5630:	8b190063 	add	x3, x3, x25
    5634:	f9001e63 	str	x3, [x19, #56]
    5638:	8b1a0000 	add	x0, x0, x26
    563c:	97fff411 	bl	2680 <memmove@plt>
    5640:	a9430e62 	ldp	x2, x3, [x19, #48]
    5644:	17ffffcd 	b	5578 <fwp_p_ad_push+0x144>
    5648:	90000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    564c:	91390000 	add	x0, x0, #0xe40
    5650:	a9046bf9 	stp	x25, x26, [sp, #64]
    5654:	a90573fb 	stp	x27, x28, [sp, #80]
    5658:	97fff84a 	bl	3780 <fwp_trap>
    565c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    5660:	91388000 	add	x0, x0, #0xe20
    5664:	a9046bf9 	stp	x25, x26, [sp, #64]
    5668:	a90573fb 	stp	x27, x28, [sp, #80]
    566c:	97fff845 	bl	3780 <fwp_trap>
    5670:	aa1303e0 	mov	x0, x19
    5674:	97fff648 	bl	2f94 <fwp_tape_unlink_scope>
    5678:	f9401260 	ldr	x0, [x19, #32]
    567c:	b4000040 	cbz	x0, 5684 <fwp_p_ad_push+0x250>
    5680:	97fffb20 	bl	4300 <ad_raw_free.part.0>
    5684:	f9401a60 	ldr	x0, [x19, #48]
    5688:	b4000040 	cbz	x0, 5690 <fwp_p_ad_push+0x25c>
    568c:	97fffb1d 	bl	4300 <ad_raw_free.part.0>
    5690:	f9402260 	ldr	x0, [x19, #64]
    5694:	b4000040 	cbz	x0, 569c <fwp_p_ad_push+0x268>
    5698:	97fffb1a 	bl	4300 <ad_raw_free.part.0>
    569c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    56a0:	f947e821 	ldr	x1, [x1, #4048]
    56a4:	f9000e7f 	str	xzr, [x19, #24]
    56a8:	4f000400 	movi	v0.4s, #0x0
    56ac:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    56b0:	d2800262 	mov	x2, #0x13                  	// #19
    56b4:	f9400023 	ldr	x3, [x1]
    56b8:	b900067f 	str	wzr, [x19, #4]
    56bc:	d2800021 	mov	x1, #0x1                   	// #1
    56c0:	90000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    56c4:	9122a000 	add	x0, x0, #0x8a8
    56c8:	3c808260 	stur	q0, [x19, #8]
    56cc:	ad010260 	stp	q0, q0, [x19, #32]
    56d0:	97fff490 	bl	2910 <fwrite@plt>
    56d4:	d2800000 	mov	x0, #0x0                   	// #0
    56d8:	97fff49a 	bl	2940 <fflush@plt>
    56dc:	52800cc0 	mov	w0, #0x66                  	// #102
    56e0:	97fff4a8 	bl	2980 <_Exit@plt>
    56e4:	90000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    56e8:	9137c000 	add	x0, x0, #0xdf0
    56ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    56f0:	a90573fb 	stp	x27, x28, [sp, #80]
    56f4:	97fff823 	bl	3780 <fwp_trap>
    56f8:	d503201f 	nop
    56fc:	d503201f 	nop

0000000000005700 <w107>:
    5700:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5704:	9e660003 	fmov	x3, d0
    5708:	aa0003e2 	mov	x2, x0
    570c:	910003fd 	mov	x29, sp
    5710:	6d0327e8 	stp	d8, d9, [sp, #48]
    5714:	1e604028 	fmov	d8, d1
    5718:	1e600809 	fmul	d9, d0, d0
    571c:	fd0023ea 	str	d10, [sp, #64]
    5720:	1e60400a 	fmov	d10, d0
    5724:	a90153f3 	stp	x19, x20, [sp, #16]
    5728:	aa0003f3 	mov	x19, x0
    572c:	aa0103f4 	mov	x20, x1
    5730:	aa0303e1 	mov	x1, x3
    5734:	a9025bf5 	stp	x21, x22, [sp, #32]
    5738:	97ffff3f 	bl	5434 <fwp_p_ad_push>
    573c:	1e693908 	fsub	d8, d8, d9
    5740:	aa1403e2 	mov	x2, x20
    5744:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5748:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    574c:	9e660116 	fmov	x22, d8
    5750:	97ffff39 	bl	5434 <fwp_p_ad_push>
    5754:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5758:	aa0003e1 	mov	x1, x0
    575c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5760:	aa1303e0 	mov	x0, x19
    5764:	1e6a3929 	fsub	d9, d9, d10
    5768:	aa0103f3 	mov	x19, x1
    576c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5770:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5774:	9e660135 	fmov	x21, d9
    5778:	97ffff2f 	bl	5434 <fwp_p_ad_push>
    577c:	1e680908 	fmul	d8, d8, d8
    5780:	aa0003f4 	mov	x20, x0
    5784:	aa1603e3 	mov	x3, x22
    5788:	aa1603e1 	mov	x1, x22
    578c:	aa1303e2 	mov	x2, x19
    5790:	aa1303e0 	mov	x0, x19
    5794:	97ffff28 	bl	5434 <fwp_p_ad_push>
    5798:	aa0003e2 	mov	x2, x0
    579c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    57a0:	9e670020 	fmov	d0, x1
    57a4:	9e660101 	fmov	x1, d8
    57a8:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    57ac:	1e600908 	fmul	d8, d8, d0
    57b0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57b4:	97ffff20 	bl	5434 <fwp_p_ad_push>
    57b8:	1e690929 	fmul	d9, d9, d9
    57bc:	aa0003f3 	mov	x19, x0
    57c0:	aa1503e3 	mov	x3, x21
    57c4:	aa1503e1 	mov	x1, x21
    57c8:	aa1403e2 	mov	x2, x20
    57cc:	aa1403e0 	mov	x0, x20
    57d0:	97ffff19 	bl	5434 <fwp_p_ad_push>
    57d4:	1e692908 	fadd	d8, d8, d9
    57d8:	aa1303e2 	mov	x2, x19
    57dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    57e0:	aa0303e1 	mov	x1, x3
    57e4:	97ffff14 	bl	5434 <fwp_p_ad_push>
    57e8:	aa0003e1 	mov	x1, x0
    57ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    57f0:	9e660100 	fmov	x0, d8
    57f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57f8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    57fc:	fd4023ea 	ldr	d10, [sp, #64]
    5800:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5804:	d65f03c0 	ret
    5808:	d503201f 	nop
    580c:	d503201f 	nop

0000000000005810 <fwp_data.part.0.constprop.0>:
    5810:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5814:	910003fd 	mov	x29, sp
    5818:	a9025bf5 	stp	x21, x22, [sp, #32]
    581c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5820:	910182c2 	add	x2, x22, #0x60
    5824:	a9046bf9 	stp	x25, x26, [sp, #64]
    5828:	b9413059 	ldr	w25, [x2, #304]
    582c:	a90153f3 	stp	x19, x20, [sp, #16]
    5830:	aa0103f4 	mov	x20, x1
    5834:	a90363f7 	stp	x23, x24, [sp, #48]
    5838:	2a0003f7 	mov	w23, w0
    583c:	340000b9 	cbz	w25, 5850 <fwp_data.part.0.constprop.0+0x40>
    5840:	a9538041 	ldp	x1, x0, [x2, #312]
    5844:	91000421 	add	x1, x1, #0x1
    5848:	91006000 	add	x0, x0, #0x18
    584c:	a9138041 	stp	x1, x0, [x2, #312]
    5850:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5854:	911902a3 	add	x3, x21, #0x640
    5858:	b953a460 	ldr	w0, [x3, #5028]
    585c:	34000840 	cbz	w0, 5964 <fwp_data.part.0.constprop.0+0x154>
    5860:	397e8862 	ldrb	w2, [x3, #4002]
    5864:	910f0040 	add	x0, x2, #0x3c0
    5868:	8b020442 	add	x2, x2, x2, lsl #1
    586c:	d37df042 	lsl	x2, x2, #3
    5870:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5874:	2a1a03f8 	mov	w24, w26
    5878:	f8626873 	ldr	x19, [x3, x2]
    587c:	b4000613 	cbz	x19, 593c <fwp_data.part.0.constprop.0+0x12c>
    5880:	f9400260 	ldr	x0, [x19]
    5884:	aa2003e0 	mvn	x0, x0
    5888:	f8226860 	str	x0, [x3, x2]
    588c:	f100631f 	cmp	x24, #0x18
    5890:	540000e9 	b.ls	58ac <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5894:	d1006702 	sub	x2, x24, #0x19
    5898:	91006260 	add	x0, x19, #0x18
    589c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    58a0:	52800001 	mov	w1, #0x0                   	// #0
    58a4:	91002042 	add	x2, x2, #0x8
    58a8:	97fff3ce 	bl	27e0 <memset@plt>
    58ac:	911902a0 	add	x0, x21, #0x640
    58b0:	f94a1001 	ldr	x1, [x0, #5152]
    58b4:	ab180021 	adds	x1, x1, x24
    58b8:	54000642 	b.cs	5980 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    58bc:	f94a1402 	ldr	x2, [x0, #5160]
    58c0:	f90a1001 	str	x1, [x0, #5152]
    58c4:	eb02003f 	cmp	x1, x2
    58c8:	54000049 	b.ls	58d0 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    58cc:	f90a1401 	str	x1, [x0, #5160]
    58d0:	911902a0 	add	x0, x21, #0x640
    58d4:	1e630341 	ucvtf	d1, w26
    58d8:	fd4a1c00 	ldr	d0, [x0, #5176]
    58dc:	1e612800 	fadd	d0, d0, d1
    58e0:	fd0a1c00 	str	d0, [x0, #5176]
    58e4:	34000139 	cbz	w25, 5908 <fwp_data.part.0.constprop.0+0xf8>
    58e8:	911902b5 	add	x21, x21, #0x640
    58ec:	910182d6 	add	x22, x22, #0x60
    58f0:	fd4a12a0 	ldr	d0, [x21, #5152]
    58f4:	6d5486c2 	ldp	d2, d1, [x22, #328]
    58f8:	7e61d800 	ucvtf	d0, d0
    58fc:	1e623800 	fsub	d0, d0, d2
    5900:	1e612010 	fcmpe	d0, d1
    5904:	540003ac 	b.gt	5978 <fwp_data.part.0.constprop.0+0x168>
    5908:	52800040 	mov	w0, #0x2                   	// #2
    590c:	29000277 	stp	w23, w0, [x19]
    5910:	aa1303e0 	mov	x0, x19
    5914:	f9400281 	ldr	x1, [x20]
    5918:	f9000661 	str	x1, [x19, #8]
    591c:	f9400681 	ldr	x1, [x20, #8]
    5920:	f9000a61 	str	x1, [x19, #16]
    5924:	a94153f3 	ldp	x19, x20, [sp, #16]
    5928:	a9425bf5 	ldp	x21, x22, [sp, #32]
    592c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5930:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5938:	d65f03c0 	ret
    593c:	8b020063 	add	x3, x3, x2
    5940:	f9400473 	ldr	x19, [x3, #8]
    5944:	b4000113 	cbz	x19, 5964 <fwp_data.part.0.constprop.0+0x154>
    5948:	f9400860 	ldr	x0, [x3, #16]
    594c:	cb130000 	sub	x0, x0, x19
    5950:	eb00031f 	cmp	x24, x0
    5954:	54000088 	b.hi	5964 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5958:	8b180260 	add	x0, x19, x24
    595c:	f9000460 	str	x0, [x3, #8]
    5960:	17ffffcb 	b	588c <fwp_data.part.0.constprop.0+0x7c>
    5964:	52800001 	mov	w1, #0x0                   	// #0
    5968:	d2800300 	mov	x0, #0x18                  	// #24
    596c:	97fffdc9 	bl	5090 <fwp_heap_alloc>
    5970:	aa0003f3 	mov	x19, x0
    5974:	17ffffdc 	b	58e4 <fwp_data.part.0.constprop.0+0xd4>
    5978:	fd00aac0 	str	d0, [x22, #336]
    597c:	17ffffe3 	b	5908 <fwp_data.part.0.constprop.0+0xf8>
    5980:	97fff5dc 	bl	30f0 <fwp_heap_oom>

0000000000005984 <fwp_rc_share>:
    5984:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5988:	91190042 	add	x2, x2, #0x640
    598c:	f949d843 	ldr	x3, [x2, #5040]
    5990:	f949ec41 	ldr	x1, [x2, #5080]
    5994:	cb030000 	sub	x0, x0, x3
    5998:	eb01401f 	cmp	x0, x1, lsl #16
    599c:	540002c2 	b.cs	59f4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    59a0:	d350fc01 	lsr	x1, x0, #16
    59a4:	f949fc44 	ldr	x4, [x2, #5112]
    59a8:	8b010821 	add	x1, x1, x1, lsl #2
    59ac:	d37df021 	lsl	x1, x1, #3
    59b0:	8b010083 	add	x3, x4, x1
    59b4:	f9401062 	ldr	x2, [x3, #32]
    59b8:	b40001e2 	cbz	x2, 59f4 <fwp_rc_share+0x70>
    59bc:	38616881 	ldrb	w1, [x4, x1]
    59c0:	7100083f 	cmp	w1, #0x2
    59c4:	540001a0 	b.eq	59f8 <fwp_rc_share+0x74>  // b.none
    59c8:	7100043f 	cmp	w1, #0x1
    59cc:	54000141 	b.ne	59f4 <fwp_rc_share+0x70>  // b.any
    59d0:	29430464 	ldp	w4, w1, [x3, #24]
    59d4:	92403c00 	and	x0, x0, #0xffff
    59d8:	9b047c00 	mul	x0, x0, x4
    59dc:	d360fc00 	lsr	x0, x0, #32
    59e0:	eb01001f 	cmp	x0, x1
    59e4:	54000082 	b.cs	59f4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    59e8:	8b000042 	add	x2, x2, x0
    59ec:	39400040 	ldrb	w0, [x2]
    59f0:	350000a0 	cbnz	w0, 5a04 <fwp_rc_share+0x80>
    59f4:	d65f03c0 	ret
    59f8:	72003c1f 	tst	w0, #0xffff
    59fc:	54ffff80 	b.eq	59ec <fwp_rc_share+0x68>  // b.none
    5a00:	d65f03c0 	ret
    5a04:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5a08:	90000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    5a0c:	91398000 	add	x0, x0, #0xe60
    5a10:	910003fd 	mov	x29, sp
    5a14:	97fff75b 	bl	3780 <fwp_trap>
    5a18:	d503201f 	nop
    5a1c:	d503201f 	nop

0000000000005a20 <fwp_rc_fresh>:
    5a20:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5a24:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5a28:	91190063 	add	x3, x3, #0x640
    5a2c:	910003fd 	mov	x29, sp
    5a30:	a90153f3 	stp	x19, x20, [sp, #16]
    5a34:	aa0003f3 	mov	x19, x0
    5a38:	f949d861 	ldr	x1, [x3, #5040]
    5a3c:	f949ec60 	ldr	x0, [x3, #5080]
    5a40:	cb010261 	sub	x1, x19, x1
    5a44:	eb00403f 	cmp	x1, x0, lsl #16
    5a48:	54000322 	b.cs	5aac <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5a4c:	d350fc22 	lsr	x2, x1, #16
    5a50:	f949fc63 	ldr	x3, [x3, #5112]
    5a54:	8b020842 	add	x2, x2, x2, lsl #2
    5a58:	d37df042 	lsl	x2, x2, #3
    5a5c:	8b020060 	add	x0, x3, x2
    5a60:	f9401014 	ldr	x20, [x0, #32]
    5a64:	b4000254 	cbz	x20, 5aac <fwp_rc_fresh+0x8c>
    5a68:	38626862 	ldrb	w2, [x3, x2]
    5a6c:	7100085f 	cmp	w2, #0x2
    5a70:	54000260 	b.eq	5abc <fwp_rc_fresh+0x9c>  // b.none
    5a74:	7100045f 	cmp	w2, #0x1
    5a78:	540001a1 	b.ne	5aac <fwp_rc_fresh+0x8c>  // b.any
    5a7c:	29430002 	ldp	w2, w0, [x0, #24]
    5a80:	92403c21 	and	x1, x1, #0xffff
    5a84:	9b027c21 	mul	x1, x1, x2
    5a88:	d360fc21 	lsr	x1, x1, #32
    5a8c:	eb00003f 	cmp	x1, x0
    5a90:	540000e2 	b.cs	5aac <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5a94:	8b010294 	add	x20, x20, x1
    5a98:	39400280 	ldrb	w0, [x20]
    5a9c:	7103fc1f 	cmp	w0, #0xff
    5aa0:	540001a0 	b.eq	5ad4 <fwp_rc_fresh+0xb4>  // b.none
    5aa4:	52800020 	mov	w0, #0x1                   	// #1
    5aa8:	39000280 	strb	w0, [x20]
    5aac:	aa1303e0 	mov	x0, x19
    5ab0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ab4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ab8:	d65f03c0 	ret
    5abc:	72003c3f 	tst	w1, #0xffff
    5ac0:	54fffec0 	b.eq	5a98 <fwp_rc_fresh+0x78>  // b.none
    5ac4:	aa1303e0 	mov	x0, x19
    5ac8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5acc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ad0:	d65f03c0 	ret
    5ad4:	aa1403e0 	mov	x0, x20
    5ad8:	97fffbae 	bl	4990 <fwp_rc_forget_slot>
    5adc:	17fffff2 	b	5aa4 <fwp_rc_fresh+0x84>

0000000000005ae0 <fwp_rc_free_arr>:
    5ae0:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5ae4:	91190063 	add	x3, x3, #0x640
    5ae8:	f949d861 	ldr	x1, [x3, #5040]
    5aec:	f949ec62 	ldr	x2, [x3, #5080]
    5af0:	cb010001 	sub	x1, x0, x1
    5af4:	eb02403f 	cmp	x1, x2, lsl #16
    5af8:	54000342 	b.cs	5b60 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5afc:	d350fc22 	lsr	x2, x1, #16
    5b00:	f949fc65 	ldr	x5, [x3, #5112]
    5b04:	8b020842 	add	x2, x2, x2, lsl #2
    5b08:	d37df042 	lsl	x2, x2, #3
    5b0c:	8b0200a4 	add	x4, x5, x2
    5b10:	f9401083 	ldr	x3, [x4, #32]
    5b14:	b4000263 	cbz	x3, 5b60 <fwp_rc_free_arr+0x80>
    5b18:	386268a2 	ldrb	w2, [x5, x2]
    5b1c:	7100085f 	cmp	w2, #0x2
    5b20:	540001c0 	b.eq	5b58 <fwp_rc_free_arr+0x78>  // b.none
    5b24:	7100045f 	cmp	w2, #0x1
    5b28:	540001c1 	b.ne	5b60 <fwp_rc_free_arr+0x80>  // b.any
    5b2c:	29430885 	ldp	w5, w2, [x4, #24]
    5b30:	92403c21 	and	x1, x1, #0xffff
    5b34:	9b057c21 	mul	x1, x1, x5
    5b38:	d360fc21 	lsr	x1, x1, #32
    5b3c:	eb02003f 	cmp	x1, x2
    5b40:	54000102 	b.cs	5b60 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b44:	8b010063 	add	x3, x3, x1
    5b48:	39400061 	ldrb	w1, [x3]
    5b4c:	7100043f 	cmp	w1, #0x1
    5b50:	54000081 	b.ne	5b60 <fwp_rc_free_arr+0x80>  // b.any
    5b54:	17fffc2f 	b	4c10 <fwp_mem_free>
    5b58:	72003c3f 	tst	w1, #0xffff
    5b5c:	54ffff60 	b.eq	5b48 <fwp_rc_free_arr+0x68>  // b.none
    5b60:	d65f03c0 	ret

0000000000005b64 <fwp_rc_dup>:
    5b64:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5b68:	91190042 	add	x2, x2, #0x640
    5b6c:	f949d841 	ldr	x1, [x2, #5040]
    5b70:	f949ec43 	ldr	x3, [x2, #5080]
    5b74:	cb010001 	sub	x1, x0, x1
    5b78:	eb03403f 	cmp	x1, x3, lsl #16
    5b7c:	540003c2 	b.cs	5bf4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5b80:	d350fc20 	lsr	x0, x1, #16
    5b84:	f949fc44 	ldr	x4, [x2, #5112]
    5b88:	8b000800 	add	x0, x0, x0, lsl #2
    5b8c:	d37df002 	lsl	x2, x0, #3
    5b90:	8b020083 	add	x3, x4, x2
    5b94:	f9401060 	ldr	x0, [x3, #32]
    5b98:	b40002e0 	cbz	x0, 5bf4 <fwp_rc_dup+0x90>
    5b9c:	38626882 	ldrb	w2, [x4, x2]
    5ba0:	7100085f 	cmp	w2, #0x2
    5ba4:	540002a0 	b.eq	5bf8 <fwp_rc_dup+0x94>  // b.none
    5ba8:	7100045f 	cmp	w2, #0x1
    5bac:	54000241 	b.ne	5bf4 <fwp_rc_dup+0x90>  // b.any
    5bb0:	29430864 	ldp	w4, w2, [x3, #24]
    5bb4:	92403c21 	and	x1, x1, #0xffff
    5bb8:	9b047c21 	mul	x1, x1, x4
    5bbc:	d360fc21 	lsr	x1, x1, #32
    5bc0:	eb02003f 	cmp	x1, x2
    5bc4:	54000182 	b.cs	5bf4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5bc8:	8b010000 	add	x0, x0, x1
    5bcc:	39400001 	ldrb	w1, [x0]
    5bd0:	34000121 	cbz	w1, 5bf4 <fwp_rc_dup+0x90>
    5bd4:	f00000c2 	adrp	x2, 20000 <__data_start>
    5bd8:	91018042 	add	x2, x2, #0x60
    5bdc:	b9413043 	ldr	w3, [x2, #304]
    5be0:	35000123 	cbnz	w3, 5c04 <fwp_rc_dup+0xa0>
    5be4:	7103f43f 	cmp	w1, #0xfd
    5be8:	54000168 	b.hi	5c14 <fwp_rc_dup+0xb0>  // b.pmore
    5bec:	11000421 	add	w1, w1, #0x1
    5bf0:	39000001 	strb	w1, [x0]
    5bf4:	d65f03c0 	ret
    5bf8:	72003c3f 	tst	w1, #0xffff
    5bfc:	54fffe80 	b.eq	5bcc <fwp_rc_dup+0x68>  // b.none
    5c00:	d65f03c0 	ret
    5c04:	f940ac43 	ldr	x3, [x2, #344]
    5c08:	91000463 	add	x3, x3, #0x1
    5c0c:	f900ac43 	str	x3, [x2, #344]
    5c10:	17fffff5 	b	5be4 <fwp_rc_dup+0x80>
    5c14:	17fffb18 	b	4874 <fwp_rc_wide_dup>
    5c18:	d503201f 	nop
    5c1c:	d503201f 	nop

0000000000005c20 <fwp_owned_entry161>:
    5c20:	d10103ff 	sub	sp, sp, #0x40
    5c24:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5c28:	f947f442 	ldr	x2, [x2, #4072]
    5c2c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c30:	910083fd 	add	x29, sp, #0x20
    5c34:	a90353f3 	stp	x19, x20, [sp, #48]
    5c38:	f9400043 	ldr	x3, [x2]
    5c3c:	f9000fe3 	str	x3, [sp, #24]
    5c40:	d2800003 	mov	x3, #0x0                   	// #0
    5c44:	a9400c01 	ldp	x1, x3, [x0]
    5c48:	f9400802 	ldr	x2, [x0, #16]
    5c4c:	ab020022 	adds	x2, x1, x2
    5c50:	540006e6 	b.vs	5d2c <fwp_owned_entry161+0x10c>
    5c54:	910023e1 	add	x1, sp, #0x8
    5c58:	52800000 	mov	w0, #0x0                   	// #0
    5c5c:	a9008be3 	stp	x3, x2, [sp, #8]
    5c60:	97fffeec 	bl	5810 <fwp_data.part.0.constprop.0>
    5c64:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5c68:	91190063 	add	x3, x3, #0x640
    5c6c:	aa0003f3 	mov	x19, x0
    5c70:	f949d861 	ldr	x1, [x3, #5040]
    5c74:	f949ec60 	ldr	x0, [x3, #5080]
    5c78:	cb010261 	sub	x1, x19, x1
    5c7c:	eb00403f 	cmp	x1, x0, lsl #16
    5c80:	54000322 	b.cs	5ce4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5c84:	d350fc22 	lsr	x2, x1, #16
    5c88:	f949fc63 	ldr	x3, [x3, #5112]
    5c8c:	8b020842 	add	x2, x2, x2, lsl #2
    5c90:	d37df042 	lsl	x2, x2, #3
    5c94:	8b020060 	add	x0, x3, x2
    5c98:	f9401014 	ldr	x20, [x0, #32]
    5c9c:	b4000254 	cbz	x20, 5ce4 <fwp_owned_entry161+0xc4>
    5ca0:	38626862 	ldrb	w2, [x3, x2]
    5ca4:	7100085f 	cmp	w2, #0x2
    5ca8:	54000360 	b.eq	5d14 <fwp_owned_entry161+0xf4>  // b.none
    5cac:	7100045f 	cmp	w2, #0x1
    5cb0:	540001a1 	b.ne	5ce4 <fwp_owned_entry161+0xc4>  // b.any
    5cb4:	29430002 	ldp	w2, w0, [x0, #24]
    5cb8:	92403c21 	and	x1, x1, #0xffff
    5cbc:	9b027c21 	mul	x1, x1, x2
    5cc0:	d360fc21 	lsr	x1, x1, #32
    5cc4:	eb00003f 	cmp	x1, x0
    5cc8:	540000e2 	b.cs	5ce4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5ccc:	8b010294 	add	x20, x20, x1
    5cd0:	39400280 	ldrb	w0, [x20]
    5cd4:	7103fc1f 	cmp	w0, #0xff
    5cd8:	54000240 	b.eq	5d20 <fwp_owned_entry161+0x100>  // b.none
    5cdc:	52800020 	mov	w0, #0x1                   	// #1
    5ce0:	39000280 	strb	w0, [x20]
    5ce4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5ce8:	f947f400 	ldr	x0, [x0, #4072]
    5cec:	f9400fe2 	ldr	x2, [sp, #24]
    5cf0:	f9400001 	ldr	x1, [x0]
    5cf4:	eb010042 	subs	x2, x2, x1
    5cf8:	d2800001 	mov	x1, #0x0                   	// #0
    5cfc:	540001a1 	b.ne	5d30 <fwp_owned_entry161+0x110>  // b.any
    5d00:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d04:	aa1303e0 	mov	x0, x19
    5d08:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d0c:	910103ff 	add	sp, sp, #0x40
    5d10:	d65f03c0 	ret
    5d14:	72003c3f 	tst	w1, #0xffff
    5d18:	54fffe61 	b.ne	5ce4 <fwp_owned_entry161+0xc4>  // b.any
    5d1c:	17ffffed 	b	5cd0 <fwp_owned_entry161+0xb0>
    5d20:	aa1403e0 	mov	x0, x20
    5d24:	97fffb1b 	bl	4990 <fwp_rc_forget_slot>
    5d28:	17ffffed 	b	5cdc <fwp_owned_entry161+0xbc>
    5d2c:	97fff335 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5d30:	97fff2b8 	bl	2810 <__stack_chk_fail@plt>

0000000000005d34 <e161>:
    5d34:	d10103ff 	sub	sp, sp, #0x40
    5d38:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5d3c:	f947f442 	ldr	x2, [x2, #4072]
    5d40:	a9027bfd 	stp	x29, x30, [sp, #32]
    5d44:	910083fd 	add	x29, sp, #0x20
    5d48:	a90353f3 	stp	x19, x20, [sp, #48]
    5d4c:	f9400043 	ldr	x3, [x2]
    5d50:	f9000fe3 	str	x3, [sp, #24]
    5d54:	d2800003 	mov	x3, #0x0                   	// #0
    5d58:	a9400c01 	ldp	x1, x3, [x0]
    5d5c:	f9400802 	ldr	x2, [x0, #16]
    5d60:	ab020022 	adds	x2, x1, x2
    5d64:	54000726 	b.vs	5e48 <e161+0x114>
    5d68:	910023e1 	add	x1, sp, #0x8
    5d6c:	52800000 	mov	w0, #0x0                   	// #0
    5d70:	a9008be3 	stp	x3, x2, [sp, #8]
    5d74:	97fffea7 	bl	5810 <fwp_data.part.0.constprop.0>
    5d78:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5d7c:	91190063 	add	x3, x3, #0x640
    5d80:	aa0003f3 	mov	x19, x0
    5d84:	f949d861 	ldr	x1, [x3, #5040]
    5d88:	f949ec60 	ldr	x0, [x3, #5080]
    5d8c:	cb010261 	sub	x1, x19, x1
    5d90:	eb00403f 	cmp	x1, x0, lsl #16
    5d94:	54000322 	b.cs	5df8 <e161+0xc4>  // b.hs, b.nlast
    5d98:	d350fc22 	lsr	x2, x1, #16
    5d9c:	f949fc63 	ldr	x3, [x3, #5112]
    5da0:	8b020842 	add	x2, x2, x2, lsl #2
    5da4:	d37df042 	lsl	x2, x2, #3
    5da8:	8b020060 	add	x0, x3, x2
    5dac:	f9401014 	ldr	x20, [x0, #32]
    5db0:	b4000254 	cbz	x20, 5df8 <e161+0xc4>
    5db4:	38626862 	ldrb	w2, [x3, x2]
    5db8:	7100085f 	cmp	w2, #0x2
    5dbc:	540003a0 	b.eq	5e30 <e161+0xfc>  // b.none
    5dc0:	7100045f 	cmp	w2, #0x1
    5dc4:	540001a1 	b.ne	5df8 <e161+0xc4>  // b.any
    5dc8:	29430002 	ldp	w2, w0, [x0, #24]
    5dcc:	92403c21 	and	x1, x1, #0xffff
    5dd0:	9b027c21 	mul	x1, x1, x2
    5dd4:	d360fc21 	lsr	x1, x1, #32
    5dd8:	eb00003f 	cmp	x1, x0
    5ddc:	540000e2 	b.cs	5df8 <e161+0xc4>  // b.hs, b.nlast
    5de0:	8b010294 	add	x20, x20, x1
    5de4:	39400280 	ldrb	w0, [x20]
    5de8:	7103fc1f 	cmp	w0, #0xff
    5dec:	54000280 	b.eq	5e3c <e161+0x108>  // b.none
    5df0:	52800020 	mov	w0, #0x1                   	// #1
    5df4:	39000280 	strb	w0, [x20]
    5df8:	aa1303e0 	mov	x0, x19
    5dfc:	97fffee2 	bl	5984 <fwp_rc_share>
    5e00:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5e04:	f947f400 	ldr	x0, [x0, #4072]
    5e08:	f9400fe2 	ldr	x2, [sp, #24]
    5e0c:	f9400001 	ldr	x1, [x0]
    5e10:	eb010042 	subs	x2, x2, x1
    5e14:	d2800001 	mov	x1, #0x0                   	// #0
    5e18:	540001a1 	b.ne	5e4c <e161+0x118>  // b.any
    5e1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5e20:	aa1303e0 	mov	x0, x19
    5e24:	a94353f3 	ldp	x19, x20, [sp, #48]
    5e28:	910103ff 	add	sp, sp, #0x40
    5e2c:	d65f03c0 	ret
    5e30:	72003c3f 	tst	w1, #0xffff
    5e34:	54fffe21 	b.ne	5df8 <e161+0xc4>  // b.any
    5e38:	17ffffeb 	b	5de4 <e161+0xb0>
    5e3c:	aa1403e0 	mov	x0, x20
    5e40:	97fffad4 	bl	4990 <fwp_rc_forget_slot>
    5e44:	17ffffeb 	b	5df0 <e161+0xbc>
    5e48:	97fff2ee 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5e4c:	97fff271 	bl	2810 <__stack_chk_fail@plt>

0000000000005e50 <fwp_drop1>:
    5e50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e54:	910003fd 	mov	x29, sp
    5e58:	a90153f3 	stp	x19, x20, [sp, #16]
    5e5c:	f90013f5 	str	x21, [sp, #32]
    5e60:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5e64:	911902b4 	add	x20, x21, #0x640
    5e68:	f949da81 	ldr	x1, [x20, #5040]
    5e6c:	f949ee82 	ldr	x2, [x20, #5080]
    5e70:	cb010001 	sub	x1, x0, x1
    5e74:	eb02403f 	cmp	x1, x2, lsl #16
    5e78:	54000382 	b.cs	5ee8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e7c:	d350fc22 	lsr	x2, x1, #16
    5e80:	f949fe84 	ldr	x4, [x20, #5112]
    5e84:	8b020842 	add	x2, x2, x2, lsl #2
    5e88:	d37df042 	lsl	x2, x2, #3
    5e8c:	8b020083 	add	x3, x4, x2
    5e90:	f9401073 	ldr	x19, [x3, #32]
    5e94:	b40002b3 	cbz	x19, 5ee8 <fwp_drop1+0x98>
    5e98:	38626882 	ldrb	w2, [x4, x2]
    5e9c:	7100085f 	cmp	w2, #0x2
    5ea0:	540002c0 	b.eq	5ef8 <fwp_drop1+0xa8>  // b.none
    5ea4:	7100045f 	cmp	w2, #0x1
    5ea8:	54000201 	b.ne	5ee8 <fwp_drop1+0x98>  // b.any
    5eac:	29430864 	ldp	w4, w2, [x3, #24]
    5eb0:	92403c21 	and	x1, x1, #0xffff
    5eb4:	9b047c21 	mul	x1, x1, x4
    5eb8:	d360fc21 	lsr	x1, x1, #32
    5ebc:	eb02003f 	cmp	x1, x2
    5ec0:	54000142 	b.cs	5ee8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ec4:	8b010273 	add	x19, x19, x1
    5ec8:	39400261 	ldrb	w1, [x19]
    5ecc:	340000e1 	cbz	w1, 5ee8 <fwp_drop1+0x98>
    5ed0:	7100043f 	cmp	w1, #0x1
    5ed4:	540001e0 	b.eq	5f10 <fwp_drop1+0xc0>  // b.none
    5ed8:	7103fc3f 	cmp	w1, #0xff
    5edc:	540002e0 	b.eq	5f38 <fwp_drop1+0xe8>  // b.none
    5ee0:	51000421 	sub	w1, w1, #0x1
    5ee4:	39000261 	strb	w1, [x19]
    5ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5eec:	f94013f5 	ldr	x21, [sp, #32]
    5ef0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ef4:	d65f03c0 	ret
    5ef8:	72003c3f 	tst	w1, #0xffff
    5efc:	54fffe60 	b.eq	5ec8 <fwp_drop1+0x78>  // b.none
    5f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f04:	f94013f5 	ldr	x21, [sp, #32]
    5f08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f0c:	d65f03c0 	ret
    5f10:	f9400813 	ldr	x19, [x0, #16]
    5f14:	97fffef3 	bl	5ae0 <fwp_rc_free_arr>
    5f18:	911902a0 	add	x0, x21, #0x640
    5f1c:	f949d801 	ldr	x1, [x0, #5040]
    5f20:	f949ec00 	ldr	x0, [x0, #5080]
    5f24:	cb010261 	sub	x1, x19, x1
    5f28:	eb00403f 	cmp	x1, x0, lsl #16
    5f2c:	54fffde2 	b.cs	5ee8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f30:	aa1303e0 	mov	x0, x19
    5f34:	17ffffd2 	b	5e7c <fwp_drop1+0x2c>
    5f38:	ca534660 	eor	x0, x19, x19, lsr #17
    5f3c:	911902b5 	add	x21, x21, #0x640
    5f40:	ca402400 	eor	x0, x0, x0, lsr #9
    5f44:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5f48:	f94a2400 	ldr	x0, [x0, #5192]
    5f4c:	b5000080 	cbnz	x0, 5f5c <fwp_drop1+0x10c>
    5f50:	14000010 	b	5f90 <fwp_drop1+0x140>
    5f54:	f9400800 	ldr	x0, [x0, #16]
    5f58:	b40001c0 	cbz	x0, 5f90 <fwp_drop1+0x140>
    5f5c:	f9400001 	ldr	x1, [x0]
    5f60:	eb13003f 	cmp	x1, x19
    5f64:	54ffff81 	b.ne	5f54 <fwp_drop1+0x104>  // b.any
    5f68:	f9400401 	ldr	x1, [x0, #8]
    5f6c:	d1000421 	sub	x1, x1, #0x1
    5f70:	f9000401 	str	x1, [x0, #8]
    5f74:	f103f83f 	cmp	x1, #0xfe
    5f78:	54fffb81 	b.ne	5ee8 <fwp_drop1+0x98>  // b.any
    5f7c:	aa1303e0 	mov	x0, x19
    5f80:	97fffa84 	bl	4990 <fwp_rc_forget_slot>
    5f84:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f88:	39000260 	strb	w0, [x19]
    5f8c:	17ffffd7 	b	5ee8 <fwp_drop1+0x98>
    5f90:	90000040 	adrp	x0, d000 <fwp_main_thread+0x440>
    5f94:	91358000 	add	x0, x0, #0xd60
    5f98:	97fff5fa 	bl	3780 <fwp_trap>
    5f9c:	d503201f 	nop

0000000000005fa0 <fwp_drop0>:
    5fa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fa4:	910003fd 	mov	x29, sp
    5fa8:	a90153f3 	stp	x19, x20, [sp, #16]
    5fac:	f90013f5 	str	x21, [sp, #32]
    5fb0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5fb4:	911902b4 	add	x20, x21, #0x640
    5fb8:	f949da81 	ldr	x1, [x20, #5040]
    5fbc:	f949ee82 	ldr	x2, [x20, #5080]
    5fc0:	cb010001 	sub	x1, x0, x1
    5fc4:	eb02403f 	cmp	x1, x2, lsl #16
    5fc8:	54000382 	b.cs	6038 <fwp_drop0+0x98>  // b.hs, b.nlast
    5fcc:	d350fc22 	lsr	x2, x1, #16
    5fd0:	f949fe84 	ldr	x4, [x20, #5112]
    5fd4:	8b020842 	add	x2, x2, x2, lsl #2
    5fd8:	d37df042 	lsl	x2, x2, #3
    5fdc:	8b020083 	add	x3, x4, x2
    5fe0:	f9401073 	ldr	x19, [x3, #32]
    5fe4:	b40002b3 	cbz	x19, 6038 <fwp_drop0+0x98>
    5fe8:	38626882 	ldrb	w2, [x4, x2]
    5fec:	7100085f 	cmp	w2, #0x2
    5ff0:	540002c0 	b.eq	6048 <fwp_drop0+0xa8>  // b.none
    5ff4:	7100045f 	cmp	w2, #0x1
    5ff8:	54000201 	b.ne	6038 <fwp_drop0+0x98>  // b.any
    5ffc:	29430864 	ldp	w4, w2, [x3, #24]
    6000:	92403c21 	and	x1, x1, #0xffff
    6004:	9b047c21 	mul	x1, x1, x4
    6008:	d360fc21 	lsr	x1, x1, #32
    600c:	eb02003f 	cmp	x1, x2
    6010:	54000142 	b.cs	6038 <fwp_drop0+0x98>  // b.hs, b.nlast
    6014:	8b010273 	add	x19, x19, x1
    6018:	39400261 	ldrb	w1, [x19]
    601c:	340000e1 	cbz	w1, 6038 <fwp_drop0+0x98>
    6020:	7100043f 	cmp	w1, #0x1
    6024:	540001e0 	b.eq	6060 <fwp_drop0+0xc0>  // b.none
    6028:	7103fc3f 	cmp	w1, #0xff
    602c:	540002e0 	b.eq	6088 <fwp_drop0+0xe8>  // b.none
    6030:	51000421 	sub	w1, w1, #0x1
    6034:	39000261 	strb	w1, [x19]
    6038:	a94153f3 	ldp	x19, x20, [sp, #16]
    603c:	f94013f5 	ldr	x21, [sp, #32]
    6040:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6044:	d65f03c0 	ret
    6048:	72003c3f 	tst	w1, #0xffff
    604c:	54fffe60 	b.eq	6018 <fwp_drop0+0x78>  // b.none
    6050:	a94153f3 	ldp	x19, x20, [sp, #16]
    6054:	f94013f5 	ldr	x21, [sp, #32]
    6058:	a8c37bfd 	ldp	x29, x30, [sp], #48
    605c:	d65f03c0 	ret
    6060:	f9400813 	ldr	x19, [x0, #16]
    6064:	97fffe9f 	bl	5ae0 <fwp_rc_free_arr>
    6068:	911902a0 	add	x0, x21, #0x640
    606c:	f949d801 	ldr	x1, [x0, #5040]
    6070:	f949ec00 	ldr	x0, [x0, #5080]
    6074:	cb010261 	sub	x1, x19, x1
    6078:	eb00403f 	cmp	x1, x0, lsl #16
    607c:	54fffde2 	b.cs	6038 <fwp_drop0+0x98>  // b.hs, b.nlast
    6080:	aa1303e0 	mov	x0, x19
    6084:	17ffffd2 	b	5fcc <fwp_drop0+0x2c>
    6088:	ca534660 	eor	x0, x19, x19, lsr #17
    608c:	911902b5 	add	x21, x21, #0x640
    6090:	ca402400 	eor	x0, x0, x0, lsr #9
    6094:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6098:	f94a2400 	ldr	x0, [x0, #5192]
    609c:	b5000080 	cbnz	x0, 60ac <fwp_drop0+0x10c>
    60a0:	14000010 	b	60e0 <fwp_drop0+0x140>
    60a4:	f9400800 	ldr	x0, [x0, #16]
    60a8:	b40001c0 	cbz	x0, 60e0 <fwp_drop0+0x140>
    60ac:	f9400001 	ldr	x1, [x0]
    60b0:	eb13003f 	cmp	x1, x19
    60b4:	54ffff81 	b.ne	60a4 <fwp_drop0+0x104>  // b.any
    60b8:	f9400401 	ldr	x1, [x0, #8]
    60bc:	d1000421 	sub	x1, x1, #0x1
    60c0:	f9000401 	str	x1, [x0, #8]
    60c4:	f103f83f 	cmp	x1, #0xfe
    60c8:	54fffb81 	b.ne	6038 <fwp_drop0+0x98>  // b.any
    60cc:	aa1303e0 	mov	x0, x19
    60d0:	97fffa30 	bl	4990 <fwp_rc_forget_slot>
    60d4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    60d8:	39000260 	strb	w0, [x19]
    60dc:	17ffffd7 	b	6038 <fwp_drop0+0x98>
    60e0:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    60e4:	91358000 	add	x0, x0, #0xd60
    60e8:	97fff5a6 	bl	3780 <fwp_trap>
    60ec:	d503201f 	nop

00000000000060f0 <fwp_arg_drop12>:
    60f0:	7100003f 	cmp	w1, #0x0
    60f4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    60f8:	54000041 	b.ne	6100 <fwp_arg_drop12+0x10>  // b.any
    60fc:	d65f03c0 	ret
    6100:	f9400000 	ldr	x0, [x0]
    6104:	17ffffa7 	b	5fa0 <fwp_drop0>
    6108:	d503201f 	nop
    610c:	d503201f 	nop

0000000000006110 <fwp_closure_drop>:
    6110:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xba0>
    6114:	911900a4 	add	x4, x5, #0x640
    6118:	aa0003e1 	mov	x1, x0
    611c:	f949d882 	ldr	x2, [x4, #5040]
    6120:	f949ec80 	ldr	x0, [x4, #5080]
    6124:	cb020022 	sub	x2, x1, x2
    6128:	eb00405f 	cmp	x2, x0, lsl #16
    612c:	54000662 	b.cs	61f8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6130:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6134:	d350fc43 	lsr	x3, x2, #16
    6138:	910003fd 	mov	x29, sp
    613c:	8b030863 	add	x3, x3, x3, lsl #2
    6140:	f949fc84 	ldr	x4, [x4, #5112]
    6144:	d37df063 	lsl	x3, x3, #3
    6148:	f9000bf3 	str	x19, [sp, #16]
    614c:	8b030080 	add	x0, x4, x3
    6150:	f9401013 	ldr	x19, [x0, #32]
    6154:	b40002b3 	cbz	x19, 61a8 <fwp_closure_drop+0x98>
    6158:	38636883 	ldrb	w3, [x4, x3]
    615c:	7100087f 	cmp	w3, #0x2
    6160:	54000420 	b.eq	61e4 <fwp_closure_drop+0xd4>  // b.none
    6164:	7100047f 	cmp	w3, #0x1
    6168:	54000201 	b.ne	61a8 <fwp_closure_drop+0x98>  // b.any
    616c:	29430003 	ldp	w3, w0, [x0, #24]
    6170:	92403c42 	and	x2, x2, #0xffff
    6174:	9b037c42 	mul	x2, x2, x3
    6178:	d360fc42 	lsr	x2, x2, #32
    617c:	eb00005f 	cmp	x2, x0
    6180:	54000142 	b.cs	61a8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6184:	8b020273 	add	x19, x19, x2
    6188:	39400260 	ldrb	w0, [x19]
    618c:	340000e0 	cbz	w0, 61a8 <fwp_closure_drop+0x98>
    6190:	7100041f 	cmp	w0, #0x1
    6194:	54000100 	b.eq	61b4 <fwp_closure_drop+0xa4>  // b.none
    6198:	7103fc1f 	cmp	w0, #0xff
    619c:	54000300 	b.eq	61fc <fwp_closure_drop+0xec>  // b.none
    61a0:	51000400 	sub	w0, w0, #0x1
    61a4:	39000260 	strb	w0, [x19]
    61a8:	f9400bf3 	ldr	x19, [sp, #16]
    61ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61b0:	d65f03c0 	ret
    61b4:	d53bd040 	mrs	x0, tpidr_el0
    61b8:	91400000 	add	x0, x0, #0x0, lsl #12
    61bc:	91004000 	add	x0, x0, #0x10
    61c0:	f9400000 	ldr	x0, [x0]
    61c4:	b4000080 	cbz	x0, 61d4 <fwp_closure_drop+0xc4>
    61c8:	f9400bf3 	ldr	x19, [sp, #16]
    61cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d0:	17fff585 	b	37e4 <fwp_closure_drop_push>
    61d4:	f9400bf3 	ldr	x19, [sp, #16]
    61d8:	aa0103e0 	mov	x0, x1
    61dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61e0:	17fff5f0 	b	39a0 <fwp_closure_drop.part.0>
    61e4:	72003c5f 	tst	w2, #0xffff
    61e8:	54fffd00 	b.eq	6188 <fwp_closure_drop+0x78>  // b.none
    61ec:	f9400bf3 	ldr	x19, [sp, #16]
    61f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61f4:	d65f03c0 	ret
    61f8:	d65f03c0 	ret
    61fc:	ca534660 	eor	x0, x19, x19, lsr #17
    6200:	911900a5 	add	x5, x5, #0x640
    6204:	ca402400 	eor	x0, x0, x0, lsr #9
    6208:	8b200ca0 	add	x0, x5, w0, uxtb #3
    620c:	f94a2400 	ldr	x0, [x0, #5192]
    6210:	b5000080 	cbnz	x0, 6220 <fwp_closure_drop+0x110>
    6214:	14000010 	b	6254 <fwp_closure_drop+0x144>
    6218:	f9400800 	ldr	x0, [x0, #16]
    621c:	b40001c0 	cbz	x0, 6254 <fwp_closure_drop+0x144>
    6220:	f9400001 	ldr	x1, [x0]
    6224:	eb13003f 	cmp	x1, x19
    6228:	54ffff81 	b.ne	6218 <fwp_closure_drop+0x108>  // b.any
    622c:	f9400401 	ldr	x1, [x0, #8]
    6230:	d1000421 	sub	x1, x1, #0x1
    6234:	f9000401 	str	x1, [x0, #8]
    6238:	f103f83f 	cmp	x1, #0xfe
    623c:	54fffb61 	b.ne	61a8 <fwp_closure_drop+0x98>  // b.any
    6240:	aa1303e0 	mov	x0, x19
    6244:	97fff9d3 	bl	4990 <fwp_rc_forget_slot>
    6248:	12800020 	mov	w0, #0xfffffffe            	// #-2
    624c:	39000260 	strb	w0, [x19]
    6250:	17ffffd6 	b	61a8 <fwp_closure_drop+0x98>
    6254:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    6258:	91358000 	add	x0, x0, #0xd60
    625c:	97fff549 	bl	3780 <fwp_trap>

0000000000006260 <fwp_owned_tape_release>:
    6260:	b4000940 	cbz	x0, 6388 <fwp_owned_tape_release+0x128>
    6264:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6268:	910003fd 	mov	x29, sp
    626c:	a90153f3 	stp	x19, x20, [sp, #16]
    6270:	aa0003f3 	mov	x19, x0
    6274:	f9400000 	ldr	x0, [x0]
    6278:	b4000060 	cbz	x0, 6284 <fwp_owned_tape_release+0x24>
    627c:	f9400661 	ldr	x1, [x19, #8]
    6280:	f9000401 	str	x1, [x0, #8]
    6284:	f9400661 	ldr	x1, [x19, #8]
    6288:	b4000041 	cbz	x1, 6290 <fwp_owned_tape_release+0x30>
    628c:	f9000020 	str	x0, [x1]
    6290:	f9400a60 	ldr	x0, [x19, #16]
    6294:	f9403401 	ldr	x1, [x0, #104]
    6298:	b40005c1 	cbz	x1, 6350 <fwp_owned_tape_release+0xf0>
    629c:	a9450a60 	ldp	x0, x2, [x19, #80]
    62a0:	eb00005f 	cmp	x2, x0
    62a4:	540002ed 	b.le	6300 <fwp_owned_tape_release+0xa0>
    62a8:	d2800014 	mov	x20, #0x0                   	// #0
    62ac:	f90013f5 	str	x21, [sp, #32]
    62b0:	d2800015 	mov	x21, #0x0                   	// #0
    62b4:	d503201f 	nop
    62b8:	f9402260 	ldr	x0, [x19, #64]
    62bc:	910006b5 	add	x21, x21, #0x1
    62c0:	f8746800 	ldr	x0, [x0, x20]
    62c4:	d63f0020 	blr	x1
    62c8:	f9402260 	ldr	x0, [x19, #64]
    62cc:	f9400a61 	ldr	x1, [x19, #16]
    62d0:	8b140000 	add	x0, x0, x20
    62d4:	91004294 	add	x20, x20, #0x10
    62d8:	f9400400 	ldr	x0, [x0, #8]
    62dc:	f9403421 	ldr	x1, [x1, #104]
    62e0:	d63f0020 	blr	x1
    62e4:	a9450261 	ldp	x1, x0, [x19, #80]
    62e8:	cb010000 	sub	x0, x0, x1
    62ec:	eb15001f 	cmp	x0, x21
    62f0:	f9400a60 	ldr	x0, [x19, #16]
    62f4:	f9403401 	ldr	x1, [x0, #104]
    62f8:	54fffe0c 	b.gt	62b8 <fwp_owned_tape_release+0x58>
    62fc:	f94013f5 	ldr	x21, [sp, #32]
    6300:	f9403663 	ldr	x3, [x19, #104]
    6304:	f9401262 	ldr	x2, [x19, #32]
    6308:	f100007f 	cmp	x3, #0x0
    630c:	540001ed 	b.le	6348 <fwp_owned_tape_release+0xe8>
    6310:	d2800014 	mov	x20, #0x0                   	// #0
    6314:	d503201f 	nop
    6318:	f9402660 	ldr	x0, [x19, #72]
    631c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6320:	eb02001f 	cmp	x0, x2
    6324:	540000c0 	b.eq	633c <fwp_owned_tape_release+0xdc>  // b.none
    6328:	d63f0020 	blr	x1
    632c:	f9400a60 	ldr	x0, [x19, #16]
    6330:	f9401262 	ldr	x2, [x19, #32]
    6334:	f9403663 	ldr	x3, [x19, #104]
    6338:	f9403401 	ldr	x1, [x0, #104]
    633c:	91000694 	add	x20, x20, #0x1
    6340:	eb14007f 	cmp	x3, x20
    6344:	54fffeac 	b.gt	6318 <fwp_owned_tape_release+0xb8>
    6348:	aa0203e0 	mov	x0, x2
    634c:	d63f0020 	blr	x1
    6350:	f9401660 	ldr	x0, [x19, #40]
    6354:	97ffff6f 	bl	6110 <fwp_closure_drop>
    6358:	f9401a60 	ldr	x0, [x19, #48]
    635c:	97ffff6d 	bl	6110 <fwp_closure_drop>
    6360:	f9401e60 	ldr	x0, [x19, #56]
    6364:	97ffff6b 	bl	6110 <fwp_closure_drop>
    6368:	f9402260 	ldr	x0, [x19, #64]
    636c:	97fffa29 	bl	4c10 <fwp_mem_free>
    6370:	f9402660 	ldr	x0, [x19, #72]
    6374:	97fffa27 	bl	4c10 <fwp_mem_free>
    6378:	aa1303e0 	mov	x0, x19
    637c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6380:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6384:	17fffa23 	b	4c10 <fwp_mem_free>
    6388:	d65f03c0 	ret
    638c:	d503201f 	nop

0000000000006390 <fwp_tape_finish>:
    6390:	d10203ff 	sub	sp, sp, #0x80
    6394:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    6398:	f947f421 	ldr	x1, [x1, #4072]
    639c:	a9047bfd 	stp	x29, x30, [sp, #64]
    63a0:	910103fd 	add	x29, sp, #0x40
    63a4:	a9065bf5 	stp	x21, x22, [sp, #96]
    63a8:	a90763f7 	stp	x23, x24, [sp, #112]
    63ac:	d00000d7 	adrp	x23, 20000 <__data_start>
    63b0:	910182f6 	add	x22, x23, #0x60
    63b4:	f9400022 	ldr	x2, [x1]
    63b8:	f9001fe2 	str	x2, [sp, #56]
    63bc:	d2800002 	mov	x2, #0x0                   	// #0
    63c0:	910382c0 	add	x0, x22, #0xe0
    63c4:	97fff7f0 	bl	4384 <fwp_tape_buffers_dispose>
    63c8:	f9008edf 	str	xzr, [x22, #280]
    63cc:	f9406ec0 	ldr	x0, [x22, #216]
    63d0:	f100001f 	cmp	x0, #0x0
    63d4:	5400034d 	b.le	643c <fwp_tape_finish+0xac>
    63d8:	910003f8 	mov	x24, sp
    63dc:	d2800015 	mov	x21, #0x0                   	// #0
    63e0:	a90553f3 	stp	x19, x20, [sp, #80]
    63e4:	d2800014 	mov	x20, #0x0                   	// #0
    63e8:	91000694 	add	x20, x20, #0x1
    63ec:	f94046d3 	ldr	x19, [x22, #136]
    63f0:	8b150273 	add	x19, x19, x21
    63f4:	9101a2b5 	add	x21, x21, #0x68
    63f8:	aa1303e0 	mov	x0, x19
    63fc:	97fff2e6 	bl	2f94 <fwp_tape_unlink_scope>
    6400:	aa1803e0 	mov	x0, x24
    6404:	a9440663 	ldp	x3, x1, [x19, #64]
    6408:	f9001be1 	str	x1, [sp, #48]
    640c:	f9400e62 	ldr	x2, [x19, #24]
    6410:	a9020be3 	stp	x3, x2, [sp, #32]
    6414:	ad410261 	ldp	q1, q0, [x19, #32]
    6418:	ad0003e1 	stp	q1, q0, [sp]
    641c:	97fff7da 	bl	4384 <fwp_tape_buffers_dispose>
    6420:	f9403260 	ldr	x0, [x19, #96]
    6424:	97ffff8f 	bl	6260 <fwp_owned_tape_release>
    6428:	f900327f 	str	xzr, [x19, #96]
    642c:	f9406ec0 	ldr	x0, [x22, #216]
    6430:	eb14001f 	cmp	x0, x20
    6434:	54fffdac 	b.gt	63e8 <fwp_tape_finish+0x58>
    6438:	a94553f3 	ldp	x19, x20, [sp, #80]
    643c:	910182e0 	add	x0, x23, #0x60
    6440:	f9404400 	ldr	x0, [x0, #136]
    6444:	b4000040 	cbz	x0, 644c <fwp_tape_finish+0xbc>
    6448:	97fff7ae 	bl	4300 <ad_raw_free.part.0>
    644c:	910182f7 	add	x23, x23, #0x60
    6450:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6454:	f947f400 	ldr	x0, [x0, #4072]
    6458:	f90046ff 	str	xzr, [x23, #136]
    645c:	f9006eff 	str	xzr, [x23, #216]
    6460:	f90092ff 	str	xzr, [x23, #288]
    6464:	f900b2ff 	str	xzr, [x23, #352]
    6468:	f9401fe2 	ldr	x2, [sp, #56]
    646c:	f9400001 	ldr	x1, [x0]
    6470:	eb010042 	subs	x2, x2, x1
    6474:	d2800001 	mov	x1, #0x0                   	// #0
    6478:	540000c1 	b.ne	6490 <fwp_tape_finish+0x100>  // b.any
    647c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6480:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6484:	a94763f7 	ldp	x23, x24, [sp, #112]
    6488:	910203ff 	add	sp, sp, #0x80
    648c:	d65f03c0 	ret
    6490:	a90553f3 	stp	x19, x20, [sp, #80]
    6494:	97fff0df 	bl	2810 <__stack_chk_fail@plt>
    6498:	d503201f 	nop
    649c:	d503201f 	nop

00000000000064a0 <fwp_tape_scope_release>:
    64a0:	d10243ff 	sub	sp, sp, #0x90
    64a4:	a9047bfd 	stp	x29, x30, [sp, #64]
    64a8:	910103fd 	add	x29, sp, #0x40
    64ac:	a90553f3 	stp	x19, x20, [sp, #80]
    64b0:	aa0003f4 	mov	x20, x0
    64b4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    64b8:	f947f400 	ldr	x0, [x0, #4072]
    64bc:	b9400285 	ldr	w5, [x20]
    64c0:	f9400001 	ldr	x1, [x0]
    64c4:	f9001fe1 	str	x1, [sp, #56]
    64c8:	d2800001 	mov	x1, #0x0                   	// #0
    64cc:	37f806c5 	tbnz	w5, #31, 65a4 <fwp_tape_scope_release+0x104>
    64d0:	a90763f7 	stp	x23, x24, [sp, #112]
    64d4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    64d8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    64dc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    64e0:	d00000d3 	adrp	x19, 20000 <__data_start>
    64e4:	910003f7 	mov	x23, sp
    64e8:	91018273 	add	x19, x19, #0x60
    64ec:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    64f0:	a9065bf5 	stp	x21, x22, [sp, #96]
    64f4:	52800d16 	mov	w22, #0x68                  	// #104
    64f8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    64fc:	f90043f9 	str	x25, [sp, #128]
    6500:	14000006 	b	6518 <fwp_tape_scope_release+0x78>
    6504:	97fff7a0 	bl	4384 <fwp_tape_buffers_dispose>
    6508:	aa1903e0 	mov	x0, x25
    650c:	97ffff55 	bl	6260 <fwp_owned_tape_release>
    6510:	b9400285 	ldr	w5, [x20]
    6514:	37f80425 	tbnz	w5, #31, 6598 <fwp_tape_scope_release+0xf8>
    6518:	f9404666 	ldr	x6, [x19, #136]
    651c:	9b367ca5 	smull	x5, w5, w22
    6520:	8b0500c0 	add	x0, x6, x5
    6524:	97fff29c 	bl	2f94 <fwp_tape_unlink_scope>
    6528:	ad410001 	ldp	q1, q0, [x0, #32]
    652c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6530:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6534:	f9400c03 	ldr	x3, [x0, #24]
    6538:	ad0003e1 	stp	q1, q0, [sp]
    653c:	b86568c1 	ldr	w1, [x6, x5]
    6540:	a9440804 	ldp	x4, x2, [x0, #64]
    6544:	b900041f 	str	wzr, [x0, #4]
    6548:	f9403019 	ldr	x25, [x0, #96]
    654c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6550:	f9000c1f 	str	xzr, [x0, #24]
    6554:	a9020fe4 	stp	x4, x3, [sp, #32]
    6558:	f9001be2 	str	x2, [sp, #48]
    655c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6560:	f900301f 	str	xzr, [x0, #96]
    6564:	6b15003f 	cmp	w1, w21
    6568:	540000e8 	b.hi	6584 <fwp_tape_scope_release+0xe4>  // b.pmore
    656c:	9343fca5 	asr	x5, x5, #3
    6570:	f940b260 	ldr	x0, [x19, #352]
    6574:	9b187ca5 	mul	x5, x5, x24
    6578:	eb0000bf 	cmp	x5, x0
    657c:	5400004a 	b.ge	6584 <fwp_tape_scope_release+0xe4>  // b.tcont
    6580:	f900b265 	str	x5, [x19, #352]
    6584:	aa1703e0 	mov	x0, x23
    6588:	b5fffbf9 	cbnz	x25, 6504 <fwp_tape_scope_release+0x64>
    658c:	97fff7c6 	bl	44a4 <fwp_tape_buffers_release>
    6590:	b9400285 	ldr	w5, [x20]
    6594:	36fffc25 	tbz	w5, #31, 6518 <fwp_tape_scope_release+0x78>
    6598:	a9465bf5 	ldp	x21, x22, [sp, #96]
    659c:	a94763f7 	ldp	x23, x24, [sp, #112]
    65a0:	f94043f9 	ldr	x25, [sp, #128]
    65a4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    65a8:	f947f400 	ldr	x0, [x0, #4072]
    65ac:	f9401fe2 	ldr	x2, [sp, #56]
    65b0:	f9400001 	ldr	x1, [x0]
    65b4:	eb010042 	subs	x2, x2, x1
    65b8:	d2800001 	mov	x1, #0x0                   	// #0
    65bc:	540000a1 	b.ne	65d0 <fwp_tape_scope_release+0x130>  // b.any
    65c0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    65c4:	a94553f3 	ldp	x19, x20, [sp, #80]
    65c8:	910243ff 	add	sp, sp, #0x90
    65cc:	d65f03c0 	ret
    65d0:	a9065bf5 	stp	x21, x22, [sp, #96]
    65d4:	a90763f7 	stp	x23, x24, [sp, #112]
    65d8:	f90043f9 	str	x25, [sp, #128]
    65dc:	97fff08d 	bl	2810 <__stack_chk_fail@plt>

00000000000065e0 <fwp_task_dispose>:
    65e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65e4:	910003fd 	mov	x29, sp
    65e8:	f9000bf3 	str	x19, [sp, #16]
    65ec:	aa0003f3 	mov	x19, x0
    65f0:	39414000 	ldrb	w0, [x0, #80]
    65f4:	36000720 	tbz	w0, #0, 66d8 <fwp_task_dispose+0xf8>
    65f8:	f9400a60 	ldr	x0, [x19, #16]
    65fc:	b50006e0 	cbnz	x0, 66d8 <fwp_task_dispose+0xf8>
    6600:	a9478660 	ldp	x0, x1, [x19, #120]
    6604:	39014e7f 	strb	wzr, [x19, #83]
    6608:	f9003e7f 	str	xzr, [x19, #120]
    660c:	f100003f 	cmp	x1, #0x0
    6610:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6614:	54000040 	b.eq	661c <fwp_task_dispose+0x3c>  // b.none
    6618:	d63f0020 	blr	x1
    661c:	f9405660 	ldr	x0, [x19, #168]
    6620:	97fff97c 	bl	4c10 <fwp_mem_free>
    6624:	f900567f 	str	xzr, [x19, #168]
    6628:	b9405e60 	ldr	w0, [x19, #92]
    662c:	7100041f 	cmp	w0, #0x1
    6630:	54000420 	b.eq	66b4 <fwp_task_dispose+0xd4>  // b.none
    6634:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    6638:	91190042 	add	x2, x2, #0x640
    663c:	f949d840 	ldr	x0, [x2, #5040]
    6640:	f949ec41 	ldr	x1, [x2, #5080]
    6644:	cb000260 	sub	x0, x19, x0
    6648:	eb01401f 	cmp	x0, x1, lsl #16
    664c:	540002e2 	b.cs	66a8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6650:	d350fc01 	lsr	x1, x0, #16
    6654:	f949fc44 	ldr	x4, [x2, #5112]
    6658:	8b010821 	add	x1, x1, x1, lsl #2
    665c:	d37df021 	lsl	x1, x1, #3
    6660:	8b010083 	add	x3, x4, x1
    6664:	f9401062 	ldr	x2, [x3, #32]
    6668:	b4000202 	cbz	x2, 66a8 <fwp_task_dispose+0xc8>
    666c:	38616881 	ldrb	w1, [x4, x1]
    6670:	7100083f 	cmp	w1, #0x2
    6674:	54000280 	b.eq	66c4 <fwp_task_dispose+0xe4>  // b.none
    6678:	7100043f 	cmp	w1, #0x1
    667c:	54000161 	b.ne	66a8 <fwp_task_dispose+0xc8>  // b.any
    6680:	29430464 	ldp	w4, w1, [x3, #24]
    6684:	92403c00 	and	x0, x0, #0xffff
    6688:	9b047c00 	mul	x0, x0, x4
    668c:	d360fc00 	lsr	x0, x0, #32
    6690:	eb01001f 	cmp	x0, x1
    6694:	540000a2 	b.cs	66a8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6698:	8b000042 	add	x2, x2, x0
    669c:	39400040 	ldrb	w0, [x2]
    66a0:	7100041f 	cmp	w0, #0x1
    66a4:	54000080 	b.eq	66b4 <fwp_task_dispose+0xd4>  // b.none
    66a8:	f9400bf3 	ldr	x19, [sp, #16]
    66ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66b0:	d65f03c0 	ret
    66b4:	aa1303e0 	mov	x0, x19
    66b8:	f9400bf3 	ldr	x19, [sp, #16]
    66bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66c0:	17fff954 	b	4c10 <fwp_mem_free>
    66c4:	72003c1f 	tst	w0, #0xffff
    66c8:	54fffea0 	b.eq	669c <fwp_task_dispose+0xbc>  // b.none
    66cc:	f9400bf3 	ldr	x19, [sp, #16]
    66d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66d4:	d65f03c0 	ret
    66d8:	97fff062 	bl	2860 <abort@plt>
    66dc:	d503201f 	nop

00000000000066e0 <fwp_free_zombie>:
    66e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66e4:	910003fd 	mov	x29, sp
    66e8:	a90153f3 	stp	x19, x20, [sp, #16]
    66ec:	d00000d4 	adrp	x20, 20000 <__data_start>
    66f0:	91018281 	add	x1, x20, #0x60
    66f4:	f940b433 	ldr	x19, [x1, #360]
    66f8:	b4000333 	cbz	x19, 675c <fwp_free_zombie+0x7c>
    66fc:	f9404c20 	ldr	x0, [x1, #152]
    6700:	eb00027f 	cmp	x19, x0
    6704:	540002c0 	b.eq	675c <fwp_free_zombie+0x7c>  // b.none
    6708:	b9417022 	ldr	w2, [x1, #368]
    670c:	f9400a60 	ldr	x0, [x19, #16]
    6710:	7100fc5f 	cmp	w2, #0x3f
    6714:	5400078c 	b.gt	6804 <fwp_free_zombie+0x124>
    6718:	91060023 	add	x3, x1, #0x180
    671c:	11000444 	add	w4, w2, #0x1
    6720:	b9017024 	str	w4, [x1, #368]
    6724:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6728:	f822d860 	str	x0, [x3, w2, sxtw #3]
    672c:	a9530261 	ldp	x1, x0, [x19, #304]
    6730:	b4000741 	cbz	x1, 6818 <fwp_free_zombie+0x138>
    6734:	f9009c20 	str	x0, [x1, #312]
    6738:	b4000040 	cbz	x0, 6740 <fwp_free_zombie+0x60>
    673c:	f9009801 	str	x1, [x0, #304]
    6740:	91018294 	add	x20, x20, #0x60
    6744:	b9405e60 	ldr	w0, [x19, #92]
    6748:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    674c:	f900b69f 	str	xzr, [x20, #360]
    6750:	34000140 	cbz	w0, 6778 <fwp_free_zombie+0x98>
    6754:	7100041f 	cmp	w0, #0x1
    6758:	54000080 	b.eq	6768 <fwp_free_zombie+0x88>  // b.none
    675c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6760:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6764:	d65f03c0 	ret
    6768:	aa1303e0 	mov	x0, x19
    676c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6770:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6774:	17ffff9b 	b	65e0 <fwp_task_dispose>
    6778:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xba0>
    677c:	91190082 	add	x2, x4, #0x640
    6780:	f949d841 	ldr	x1, [x2, #5040]
    6784:	f949ec40 	ldr	x0, [x2, #5080]
    6788:	cb010261 	sub	x1, x19, x1
    678c:	eb00403f 	cmp	x1, x0, lsl #16
    6790:	54fffe62 	b.cs	675c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6794:	d350fc20 	lsr	x0, x1, #16
    6798:	f949fc43 	ldr	x3, [x2, #5112]
    679c:	8b000800 	add	x0, x0, x0, lsl #2
    67a0:	d37df000 	lsl	x0, x0, #3
    67a4:	8b000062 	add	x2, x3, x0
    67a8:	f9401054 	ldr	x20, [x2, #32]
    67ac:	b4fffd94 	cbz	x20, 675c <fwp_free_zombie+0x7c>
    67b0:	38606860 	ldrb	w0, [x3, x0]
    67b4:	7100081f 	cmp	w0, #0x2
    67b8:	54000360 	b.eq	6824 <fwp_free_zombie+0x144>  // b.none
    67bc:	7100041f 	cmp	w0, #0x1
    67c0:	54fffce1 	b.ne	675c <fwp_free_zombie+0x7c>  // b.any
    67c4:	29430043 	ldp	w3, w0, [x2, #24]
    67c8:	92403c21 	and	x1, x1, #0xffff
    67cc:	9b037c21 	mul	x1, x1, x3
    67d0:	d360fc21 	lsr	x1, x1, #32
    67d4:	eb00003f 	cmp	x1, x0
    67d8:	54fffc22 	b.cs	675c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    67dc:	8b010294 	add	x20, x20, x1
    67e0:	39400280 	ldrb	w0, [x20]
    67e4:	34fffbc0 	cbz	w0, 675c <fwp_free_zombie+0x7c>
    67e8:	7100041f 	cmp	w0, #0x1
    67ec:	54fffbe0 	b.eq	6768 <fwp_free_zombie+0x88>  // b.none
    67f0:	7103fc1f 	cmp	w0, #0xff
    67f4:	540001e0 	b.eq	6830 <fwp_free_zombie+0x150>  // b.none
    67f8:	51000400 	sub	w0, w0, #0x1
    67fc:	39000280 	strb	w0, [x20]
    6800:	17ffffd7 	b	675c <fwp_free_zombie+0x7c>
    6804:	f9400e61 	ldr	x1, [x19, #24]
    6808:	97fff04a 	bl	2930 <munmap@plt>
    680c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6810:	a9530261 	ldp	x1, x0, [x19, #304]
    6814:	b5fff901 	cbnz	x1, 6734 <fwp_free_zombie+0x54>
    6818:	91018282 	add	x2, x20, #0x60
    681c:	f901c040 	str	x0, [x2, #896]
    6820:	17ffffc6 	b	6738 <fwp_free_zombie+0x58>
    6824:	72003c3f 	tst	w1, #0xffff
    6828:	54fff9a1 	b.ne	675c <fwp_free_zombie+0x7c>  // b.any
    682c:	17ffffed 	b	67e0 <fwp_free_zombie+0x100>
    6830:	ca544680 	eor	x0, x20, x20, lsr #17
    6834:	91190084 	add	x4, x4, #0x640
    6838:	ca402400 	eor	x0, x0, x0, lsr #9
    683c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6840:	f94a2400 	ldr	x0, [x0, #5192]
    6844:	b5000080 	cbnz	x0, 6854 <fwp_free_zombie+0x174>
    6848:	14000010 	b	6888 <fwp_free_zombie+0x1a8>
    684c:	f9400800 	ldr	x0, [x0, #16]
    6850:	b40001c0 	cbz	x0, 6888 <fwp_free_zombie+0x1a8>
    6854:	f9400001 	ldr	x1, [x0]
    6858:	eb14003f 	cmp	x1, x20
    685c:	54ffff81 	b.ne	684c <fwp_free_zombie+0x16c>  // b.any
    6860:	f9400401 	ldr	x1, [x0, #8]
    6864:	d1000421 	sub	x1, x1, #0x1
    6868:	f9000401 	str	x1, [x0, #8]
    686c:	f103f83f 	cmp	x1, #0xfe
    6870:	54fff761 	b.ne	675c <fwp_free_zombie+0x7c>  // b.any
    6874:	aa1403e0 	mov	x0, x20
    6878:	97fff846 	bl	4990 <fwp_rc_forget_slot>
    687c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6880:	39000280 	strb	w0, [x20]
    6884:	17ffffb6 	b	675c <fwp_free_zombie+0x7c>
    6888:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    688c:	91358000 	add	x0, x0, #0xd60
    6890:	97fff3bc 	bl	3780 <fwp_trap>

0000000000006894 <fwp_block>:
    6894:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6898:	910003fd 	mov	x29, sp
    689c:	a90153f3 	stp	x19, x20, [sp, #16]
    68a0:	d00000d3 	adrp	x19, 20000 <__data_start>
    68a4:	91018274 	add	x20, x19, #0x60
    68a8:	f9406682 	ldr	x2, [x20, #200]
    68ac:	b4000622 	cbz	x2, 6970 <fwp_block+0xdc>
    68b0:	91018261 	add	x1, x19, #0x60
    68b4:	f9408040 	ldr	x0, [x2, #256]
    68b8:	f9006420 	str	x0, [x1, #200]
    68bc:	b4000680 	cbz	x0, 698c <fwp_block+0xf8>
    68c0:	91018263 	add	x3, x19, #0x60
    68c4:	3901505f 	strb	wzr, [x2, #84]
    68c8:	f9404c64 	ldr	x4, [x3, #152]
    68cc:	eb02009f 	cmp	x4, x2
    68d0:	54000440 	b.eq	6958 <fwp_block+0xc4>  // b.none
    68d4:	f941c465 	ldr	x5, [x3, #904]
    68d8:	f9004c62 	str	x2, [x3, #152]
    68dc:	f9400441 	ldr	x1, [x2, #8]
    68e0:	f9004885 	str	x5, [x4, #144]
    68e4:	f941c865 	ldr	x5, [x3, #912]
    68e8:	f9004c85 	str	x5, [x4, #152]
    68ec:	f941cc65 	ldr	x5, [x3, #920]
    68f0:	f9005085 	str	x5, [x4, #160]
    68f4:	f941d065 	ldr	x5, [x3, #928]
    68f8:	f9005485 	str	x5, [x4, #168]
    68fc:	f941d465 	ldr	x5, [x3, #936]
    6900:	f9005885 	str	x5, [x4, #176]
    6904:	f941d865 	ldr	x5, [x3, #944]
    6908:	f9005c85 	str	x5, [x4, #184]
    690c:	f941dc65 	ldr	x5, [x3, #952]
    6910:	f9006085 	str	x5, [x4, #192]
    6914:	f9400480 	ldr	x0, [x4, #8]
    6918:	f9404844 	ldr	x4, [x2, #144]
    691c:	f901c464 	str	x4, [x3, #904]
    6920:	f9404c44 	ldr	x4, [x2, #152]
    6924:	f901c864 	str	x4, [x3, #912]
    6928:	f9405044 	ldr	x4, [x2, #160]
    692c:	f901cc64 	str	x4, [x3, #920]
    6930:	f9405444 	ldr	x4, [x2, #168]
    6934:	f901d064 	str	x4, [x3, #928]
    6938:	f9405844 	ldr	x4, [x2, #176]
    693c:	f901d464 	str	x4, [x3, #936]
    6940:	a94b8844 	ldp	x4, x2, [x2, #184]
    6944:	f901d864 	str	x4, [x3, #944]
    6948:	f901dc62 	str	x2, [x3, #952]
    694c:	97ffefc9 	bl	2870 <swapcontext@plt>
    6950:	97ffff64 	bl	66e0 <fwp_free_zombie>
    6954:	d503201f 	nop
    6958:	91018260 	add	x0, x19, #0x60
    695c:	b943c000 	ldr	w0, [x0, #960]
    6960:	340001a0 	cbz	w0, 6994 <fwp_block+0x100>
    6964:	a94153f3 	ldp	x19, x20, [sp, #16]
    6968:	a8c27bfd 	ldp	x29, x30, [sp], #32
    696c:	d65f03c0 	ret
    6970:	97fff735 	bl	4644 <fwp_poll_events>
    6974:	f9406682 	ldr	x2, [x20, #200]
    6978:	b4ffffc2 	cbz	x2, 6970 <fwp_block+0xdc>
    697c:	91018261 	add	x1, x19, #0x60
    6980:	f9408040 	ldr	x0, [x2, #256]
    6984:	f9006420 	str	x0, [x1, #200]
    6988:	b5fff9c0 	cbnz	x0, 68c0 <fwp_block+0x2c>
    698c:	f900603f 	str	xzr, [x1, #192]
    6990:	17ffffcc 	b	68c0 <fwp_block+0x2c>
    6994:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    6998:	913a4000 	add	x0, x0, #0xe90
    699c:	97fff001 	bl	29a0 <getenv@plt>
    69a0:	5284e202 	mov	w2, #0x2710                	// #10000
    69a4:	b4000060 	cbz	x0, 69b0 <fwp_block+0x11c>
    69a8:	39400001 	ldrb	w1, [x0]
    69ac:	350000c1 	cbnz	w1, 69c4 <fwp_block+0x130>
    69b0:	91018273 	add	x19, x19, #0x60
    69b4:	b903c262 	str	w2, [x19, #960]
    69b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    69bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69c0:	d65f03c0 	ret
    69c4:	52800142 	mov	w2, #0xa                   	// #10
    69c8:	d2800001 	mov	x1, #0x0                   	// #0
    69cc:	97ffef45 	bl	26e0 <strtoll@plt>
    69d0:	d1000403 	sub	x3, x0, #0x1
    69d4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    69d8:	eb02007f 	cmp	x3, x2
    69dc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69e0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69e4:	17fffff3 	b	69b0 <fwp_block+0x11c>
    69e8:	d503201f 	nop
    69ec:	d503201f 	nop

00000000000069f0 <fwp_drop4>:
    69f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69f4:	910003fd 	mov	x29, sp
    69f8:	a90153f3 	stp	x19, x20, [sp, #16]
    69fc:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xba0>
    6a00:	f90013f5 	str	x21, [sp, #32]
    6a04:	91190275 	add	x21, x19, #0x640
    6a08:	f949daa1 	ldr	x1, [x21, #5040]
    6a0c:	f949eea2 	ldr	x2, [x21, #5080]
    6a10:	cb010001 	sub	x1, x0, x1
    6a14:	eb02403f 	cmp	x1, x2, lsl #16
    6a18:	54000382 	b.cs	6a88 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a1c:	d350fc22 	lsr	x2, x1, #16
    6a20:	f949fea3 	ldr	x3, [x21, #5112]
    6a24:	8b020842 	add	x2, x2, x2, lsl #2
    6a28:	d37df042 	lsl	x2, x2, #3
    6a2c:	8b020064 	add	x4, x3, x2
    6a30:	f9401094 	ldr	x20, [x4, #32]
    6a34:	b40002b4 	cbz	x20, 6a88 <fwp_drop4+0x98>
    6a38:	38626862 	ldrb	w2, [x3, x2]
    6a3c:	7100085f 	cmp	w2, #0x2
    6a40:	540007a0 	b.eq	6b34 <fwp_drop4+0x144>  // b.none
    6a44:	7100045f 	cmp	w2, #0x1
    6a48:	54000201 	b.ne	6a88 <fwp_drop4+0x98>  // b.any
    6a4c:	29430885 	ldp	w5, w2, [x4, #24]
    6a50:	92403c21 	and	x1, x1, #0xffff
    6a54:	9b057c21 	mul	x1, x1, x5
    6a58:	d360fc21 	lsr	x1, x1, #32
    6a5c:	eb02003f 	cmp	x1, x2
    6a60:	54000142 	b.cs	6a88 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a64:	8b010294 	add	x20, x20, x1
    6a68:	39400281 	ldrb	w1, [x20]
    6a6c:	340000e1 	cbz	w1, 6a88 <fwp_drop4+0x98>
    6a70:	7100043f 	cmp	w1, #0x1
    6a74:	54000120 	b.eq	6a98 <fwp_drop4+0xa8>  // b.none
    6a78:	7103fc3f 	cmp	w1, #0xff
    6a7c:	540007c0 	b.eq	6b74 <fwp_drop4+0x184>  // b.none
    6a80:	51000421 	sub	w1, w1, #0x1
    6a84:	39000281 	strb	w1, [x20]
    6a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a8c:	f94013f5 	ldr	x21, [sp, #32]
    6a90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a94:	d65f03c0 	ret
    6a98:	f9400001 	ldr	x1, [x0]
    6a9c:	b7f80581 	tbnz	x1, #63, 6b4c <fwp_drop4+0x15c>
    6aa0:	91190273 	add	x19, x19, #0x640
    6aa4:	f949da61 	ldr	x1, [x19, #5040]
    6aa8:	f949ee62 	ldr	x2, [x19, #5080]
    6aac:	cb010001 	sub	x1, x0, x1
    6ab0:	eb02403f 	cmp	x1, x2, lsl #16
    6ab4:	54fffea2 	b.cs	6a88 <fwp_drop4+0x98>  // b.hs, b.nlast
    6ab8:	d350fc22 	lsr	x2, x1, #16
    6abc:	8b020842 	add	x2, x2, x2, lsl #2
    6ac0:	d37df042 	lsl	x2, x2, #3
    6ac4:	8b020065 	add	x5, x3, x2
    6ac8:	f94010a4 	ldr	x4, [x5, #32]
    6acc:	b4fffde4 	cbz	x4, 6a88 <fwp_drop4+0x98>
    6ad0:	38626862 	ldrb	w2, [x3, x2]
    6ad4:	7100085f 	cmp	w2, #0x2
    6ad8:	54000220 	b.eq	6b1c <fwp_drop4+0x12c>  // b.none
    6adc:	7100045f 	cmp	w2, #0x1
    6ae0:	54fffd41 	b.ne	6a88 <fwp_drop4+0x98>  // b.any
    6ae4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ae8:	92403c21 	and	x1, x1, #0xffff
    6aec:	9b037c21 	mul	x1, x1, x3
    6af0:	d360fc21 	lsr	x1, x1, #32
    6af4:	eb02003f 	cmp	x1, x2
    6af8:	54fffc82 	b.cs	6a88 <fwp_drop4+0x98>  // b.hs, b.nlast
    6afc:	8b010084 	add	x4, x4, x1
    6b00:	39400081 	ldrb	w1, [x4]
    6b04:	7100043f 	cmp	w1, #0x1
    6b08:	54fffc01 	b.ne	6a88 <fwp_drop4+0x98>  // b.any
    6b0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b10:	f94013f5 	ldr	x21, [sp, #32]
    6b14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b18:	17fff83e 	b	4c10 <fwp_mem_free>
    6b1c:	72003c3f 	tst	w1, #0xffff
    6b20:	54ffff00 	b.eq	6b00 <fwp_drop4+0x110>  // b.none
    6b24:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b28:	f94013f5 	ldr	x21, [sp, #32]
    6b2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b30:	d65f03c0 	ret
    6b34:	72003c3f 	tst	w1, #0xffff
    6b38:	54fff980 	b.eq	6a68 <fwp_drop4+0x78>  // b.none
    6b3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b40:	f94013f5 	ldr	x21, [sp, #32]
    6b44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b48:	d65f03c0 	ret
    6b4c:	f9400414 	ldr	x20, [x0, #8]
    6b50:	97fffbe4 	bl	5ae0 <fwp_rc_free_arr>
    6b54:	91190260 	add	x0, x19, #0x640
    6b58:	f949d801 	ldr	x1, [x0, #5040]
    6b5c:	f949ec00 	ldr	x0, [x0, #5080]
    6b60:	cb010281 	sub	x1, x20, x1
    6b64:	eb00403f 	cmp	x1, x0, lsl #16
    6b68:	54fff902 	b.cs	6a88 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b6c:	aa1403e0 	mov	x0, x20
    6b70:	17ffffab 	b	6a1c <fwp_drop4+0x2c>
    6b74:	ca544680 	eor	x0, x20, x20, lsr #17
    6b78:	91190273 	add	x19, x19, #0x640
    6b7c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b80:	8b200e60 	add	x0, x19, w0, uxtb #3
    6b84:	f94a2400 	ldr	x0, [x0, #5192]
    6b88:	b5000080 	cbnz	x0, 6b98 <fwp_drop4+0x1a8>
    6b8c:	14000010 	b	6bcc <fwp_drop4+0x1dc>
    6b90:	f9400800 	ldr	x0, [x0, #16]
    6b94:	b40001c0 	cbz	x0, 6bcc <fwp_drop4+0x1dc>
    6b98:	f9400001 	ldr	x1, [x0]
    6b9c:	eb14003f 	cmp	x1, x20
    6ba0:	54ffff81 	b.ne	6b90 <fwp_drop4+0x1a0>  // b.any
    6ba4:	f9400401 	ldr	x1, [x0, #8]
    6ba8:	d1000421 	sub	x1, x1, #0x1
    6bac:	f9000401 	str	x1, [x0, #8]
    6bb0:	f103f83f 	cmp	x1, #0xfe
    6bb4:	54fff6a1 	b.ne	6a88 <fwp_drop4+0x98>  // b.any
    6bb8:	aa1403e0 	mov	x0, x20
    6bbc:	97fff775 	bl	4990 <fwp_rc_forget_slot>
    6bc0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6bc4:	39000280 	strb	w0, [x20]
    6bc8:	17ffffb0 	b	6a88 <fwp_drop4+0x98>
    6bcc:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    6bd0:	91358000 	add	x0, x0, #0xd60
    6bd4:	97fff2eb 	bl	3780 <fwp_trap>
    6bd8:	d503201f 	nop
    6bdc:	d503201f 	nop

0000000000006be0 <fwp_caps161>:
    6be0:	34000041 	cbz	w1, 6be8 <fwp_caps161+0x8>
    6be4:	d65f03c0 	ret
    6be8:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xba0>
    6bec:	91190063 	add	x3, x3, #0x640
    6bf0:	f949d861 	ldr	x1, [x3, #5040]
    6bf4:	f949ec62 	ldr	x2, [x3, #5080]
    6bf8:	cb010001 	sub	x1, x0, x1
    6bfc:	eb02403f 	cmp	x1, x2, lsl #16
    6c00:	54ffff22 	b.cs	6be4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6c04:	d350fc22 	lsr	x2, x1, #16
    6c08:	f949fc65 	ldr	x5, [x3, #5112]
    6c0c:	8b020842 	add	x2, x2, x2, lsl #2
    6c10:	d37df042 	lsl	x2, x2, #3
    6c14:	8b0200a4 	add	x4, x5, x2
    6c18:	f9401083 	ldr	x3, [x4, #32]
    6c1c:	b4fffe43 	cbz	x3, 6be4 <fwp_caps161+0x4>
    6c20:	386268a2 	ldrb	w2, [x5, x2]
    6c24:	7100085f 	cmp	w2, #0x2
    6c28:	540001c0 	b.eq	6c60 <fwp_caps161+0x80>  // b.none
    6c2c:	7100045f 	cmp	w2, #0x1
    6c30:	54fffda1 	b.ne	6be4 <fwp_caps161+0x4>  // b.any
    6c34:	29430885 	ldp	w5, w2, [x4, #24]
    6c38:	92403c21 	and	x1, x1, #0xffff
    6c3c:	9b057c21 	mul	x1, x1, x5
    6c40:	d360fc21 	lsr	x1, x1, #32
    6c44:	eb02003f 	cmp	x1, x2
    6c48:	54fffce2 	b.cs	6be4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6c4c:	8b010063 	add	x3, x3, x1
    6c50:	39400061 	ldrb	w1, [x3]
    6c54:	7100043f 	cmp	w1, #0x1
    6c58:	54fffc61 	b.ne	6be4 <fwp_caps161+0x4>  // b.any
    6c5c:	17fff7ed 	b	4c10 <fwp_mem_free>
    6c60:	72003c3f 	tst	w1, #0xffff
    6c64:	54ffff60 	b.eq	6c50 <fwp_caps161+0x70>  // b.none
    6c68:	d65f03c0 	ret
    6c6c:	d503201f 	nop

0000000000006c70 <fwp_drop2>:
    6c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6c74:	910003fd 	mov	x29, sp
    6c78:	a9025bf5 	stp	x21, x22, [sp, #32]
    6c7c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xba0>
    6c80:	911902d5 	add	x21, x22, #0x640
    6c84:	a90153f3 	stp	x19, x20, [sp, #16]
    6c88:	aa0003f3 	mov	x19, x0
    6c8c:	f949daa1 	ldr	x1, [x21, #5040]
    6c90:	f949eea0 	ldr	x0, [x21, #5080]
    6c94:	cb010261 	sub	x1, x19, x1
    6c98:	eb00403f 	cmp	x1, x0, lsl #16
    6c9c:	54000382 	b.cs	6d0c <fwp_drop2+0x9c>  // b.hs, b.nlast
    6ca0:	d350fc22 	lsr	x2, x1, #16
    6ca4:	f949fea3 	ldr	x3, [x21, #5112]
    6ca8:	8b020842 	add	x2, x2, x2, lsl #2
    6cac:	d37df042 	lsl	x2, x2, #3
    6cb0:	8b020060 	add	x0, x3, x2
    6cb4:	f9401014 	ldr	x20, [x0, #32]
    6cb8:	b40002b4 	cbz	x20, 6d0c <fwp_drop2+0x9c>
    6cbc:	38626862 	ldrb	w2, [x3, x2]
    6cc0:	7100085f 	cmp	w2, #0x2
    6cc4:	540002c0 	b.eq	6d1c <fwp_drop2+0xac>  // b.none
    6cc8:	7100045f 	cmp	w2, #0x1
    6ccc:	54000201 	b.ne	6d0c <fwp_drop2+0x9c>  // b.any
    6cd0:	29430002 	ldp	w2, w0, [x0, #24]
    6cd4:	92403c21 	and	x1, x1, #0xffff
    6cd8:	9b027c21 	mul	x1, x1, x2
    6cdc:	d360fc21 	lsr	x1, x1, #32
    6ce0:	eb00003f 	cmp	x1, x0
    6ce4:	54000142 	b.cs	6d0c <fwp_drop2+0x9c>  // b.hs, b.nlast
    6ce8:	8b010294 	add	x20, x20, x1
    6cec:	39400280 	ldrb	w0, [x20]
    6cf0:	340000e0 	cbz	w0, 6d0c <fwp_drop2+0x9c>
    6cf4:	7100041f 	cmp	w0, #0x1
    6cf8:	540001e0 	b.eq	6d34 <fwp_drop2+0xc4>  // b.none
    6cfc:	7103fc1f 	cmp	w0, #0xff
    6d00:	540007c0 	b.eq	6df8 <fwp_drop2+0x188>  // b.none
    6d04:	51000400 	sub	w0, w0, #0x1
    6d08:	39000280 	strb	w0, [x20]
    6d0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6d14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d18:	d65f03c0 	ret
    6d1c:	72003c3f 	tst	w1, #0xffff
    6d20:	54fffe60 	b.eq	6cec <fwp_drop2+0x7c>  // b.none
    6d24:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6d2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d30:	d65f03c0 	ret
    6d34:	911902c2 	add	x2, x22, #0x640
    6d38:	f9400660 	ldr	x0, [x19, #8]
    6d3c:	f949d841 	ldr	x1, [x2, #5040]
    6d40:	f949ec42 	ldr	x2, [x2, #5080]
    6d44:	cb010001 	sub	x1, x0, x1
    6d48:	eb02403f 	cmp	x1, x2, lsl #16
    6d4c:	54000362 	b.cs	6db8 <fwp_drop2+0x148>  // b.hs, b.nlast
    6d50:	d350fc22 	lsr	x2, x1, #16
    6d54:	8b020842 	add	x2, x2, x2, lsl #2
    6d58:	d37df042 	lsl	x2, x2, #3
    6d5c:	8b020064 	add	x4, x3, x2
    6d60:	f9401094 	ldr	x20, [x4, #32]
    6d64:	b40002b4 	cbz	x20, 6db8 <fwp_drop2+0x148>
    6d68:	38626862 	ldrb	w2, [x3, x2]
    6d6c:	7100085f 	cmp	w2, #0x2
    6d70:	540003e0 	b.eq	6dec <fwp_drop2+0x17c>  // b.none
    6d74:	7100045f 	cmp	w2, #0x1
    6d78:	54000201 	b.ne	6db8 <fwp_drop2+0x148>  // b.any
    6d7c:	29430883 	ldp	w3, w2, [x4, #24]
    6d80:	92403c21 	and	x1, x1, #0xffff
    6d84:	9b037c21 	mul	x1, x1, x3
    6d88:	d360fc21 	lsr	x1, x1, #32
    6d8c:	eb02003f 	cmp	x1, x2
    6d90:	54000142 	b.cs	6db8 <fwp_drop2+0x148>  // b.hs, b.nlast
    6d94:	8b010294 	add	x20, x20, x1
    6d98:	39400281 	ldrb	w1, [x20]
    6d9c:	340000e1 	cbz	w1, 6db8 <fwp_drop2+0x148>
    6da0:	7100043f 	cmp	w1, #0x1
    6da4:	54000200 	b.eq	6de4 <fwp_drop2+0x174>  // b.none
    6da8:	7103fc3f 	cmp	w1, #0xff
    6dac:	54000580 	b.eq	6e5c <fwp_drop2+0x1ec>  // b.none
    6db0:	51000421 	sub	w1, w1, #0x1
    6db4:	39000281 	strb	w1, [x20]
    6db8:	f9400a74 	ldr	x20, [x19, #16]
    6dbc:	aa1303e0 	mov	x0, x19
    6dc0:	97fffb48 	bl	5ae0 <fwp_rc_free_arr>
    6dc4:	911902c0 	add	x0, x22, #0x640
    6dc8:	f949d801 	ldr	x1, [x0, #5040]
    6dcc:	f949ec00 	ldr	x0, [x0, #5080]
    6dd0:	cb010281 	sub	x1, x20, x1
    6dd4:	eb00403f 	cmp	x1, x0, lsl #16
    6dd8:	54fff9a2 	b.cs	6d0c <fwp_drop2+0x9c>  // b.hs, b.nlast
    6ddc:	aa1403f3 	mov	x19, x20
    6de0:	17ffffb0 	b	6ca0 <fwp_drop2+0x30>
    6de4:	97fffb3f 	bl	5ae0 <fwp_rc_free_arr>
    6de8:	17fffff4 	b	6db8 <fwp_drop2+0x148>
    6dec:	72003c3f 	tst	w1, #0xffff
    6df0:	54fffe41 	b.ne	6db8 <fwp_drop2+0x148>  // b.any
    6df4:	17ffffe9 	b	6d98 <fwp_drop2+0x128>
    6df8:	ca544681 	eor	x1, x20, x20, lsr #17
    6dfc:	911902c0 	add	x0, x22, #0x640
    6e00:	ca412421 	eor	x1, x1, x1, lsr #9
    6e04:	8b210c01 	add	x1, x0, w1, uxtb #3
    6e08:	f94a2420 	ldr	x0, [x1, #5192]
    6e0c:	b5000080 	cbnz	x0, 6e1c <fwp_drop2+0x1ac>
    6e10:	14000010 	b	6e50 <fwp_drop2+0x1e0>
    6e14:	f9400800 	ldr	x0, [x0, #16]
    6e18:	b40001c0 	cbz	x0, 6e50 <fwp_drop2+0x1e0>
    6e1c:	f9400001 	ldr	x1, [x0]
    6e20:	eb14003f 	cmp	x1, x20
    6e24:	54ffff81 	b.ne	6e14 <fwp_drop2+0x1a4>  // b.any
    6e28:	f9400401 	ldr	x1, [x0, #8]
    6e2c:	d1000421 	sub	x1, x1, #0x1
    6e30:	f9000401 	str	x1, [x0, #8]
    6e34:	f103f83f 	cmp	x1, #0xfe
    6e38:	54fff6a1 	b.ne	6d0c <fwp_drop2+0x9c>  // b.any
    6e3c:	aa1403e0 	mov	x0, x20
    6e40:	97fff6d4 	bl	4990 <fwp_rc_forget_slot>
    6e44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6e48:	39000280 	strb	w0, [x20]
    6e4c:	17ffffb0 	b	6d0c <fwp_drop2+0x9c>
    6e50:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    6e54:	91358000 	add	x0, x0, #0xd60
    6e58:	97fff24a 	bl	3780 <fwp_trap>
    6e5c:	ca544680 	eor	x0, x20, x20, lsr #17
    6e60:	911902c1 	add	x1, x22, #0x640
    6e64:	ca402400 	eor	x0, x0, x0, lsr #9
    6e68:	8b200c20 	add	x0, x1, w0, uxtb #3
    6e6c:	f94a2400 	ldr	x0, [x0, #5192]
    6e70:	b5000080 	cbnz	x0, 6e80 <fwp_drop2+0x210>
    6e74:	17fffff7 	b	6e50 <fwp_drop2+0x1e0>
    6e78:	f9400800 	ldr	x0, [x0, #16]
    6e7c:	b4fffea0 	cbz	x0, 6e50 <fwp_drop2+0x1e0>
    6e80:	f9400001 	ldr	x1, [x0]
    6e84:	eb14003f 	cmp	x1, x20
    6e88:	54ffff81 	b.ne	6e78 <fwp_drop2+0x208>  // b.any
    6e8c:	f9400401 	ldr	x1, [x0, #8]
    6e90:	d1000421 	sub	x1, x1, #0x1
    6e94:	f9000401 	str	x1, [x0, #8]
    6e98:	f103f83f 	cmp	x1, #0xfe
    6e9c:	54fff8e1 	b.ne	6db8 <fwp_drop2+0x148>  // b.any
    6ea0:	aa1403e0 	mov	x0, x20
    6ea4:	97fff6bb 	bl	4990 <fwp_rc_forget_slot>
    6ea8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6eac:	39000280 	strb	w0, [x20]
    6eb0:	17ffffc2 	b	6db8 <fwp_drop2+0x148>

0000000000006eb4 <fwp_arg_drop23>:
    6eb4:	7100003f 	cmp	w1, #0x0
    6eb8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6ebc:	54000041 	b.ne	6ec4 <fwp_arg_drop23+0x10>  // b.any
    6ec0:	d65f03c0 	ret
    6ec4:	f9400000 	ldr	x0, [x0]
    6ec8:	17ffff6a 	b	6c70 <fwp_drop2>
    6ecc:	d503201f 	nop

0000000000006ed0 <fwp_args23>:
    6ed0:	7100003f 	cmp	w1, #0x0
    6ed4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6ed8:	54000041 	b.ne	6ee0 <fwp_args23+0x10>  // b.any
    6edc:	d65f03c0 	ret
    6ee0:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    6ee4:	91190042 	add	x2, x2, #0x640
    6ee8:	f9400001 	ldr	x1, [x0]
    6eec:	f949d843 	ldr	x3, [x2, #5040]
    6ef0:	f949ec40 	ldr	x0, [x2, #5080]
    6ef4:	cb030021 	sub	x1, x1, x3
    6ef8:	eb00403f 	cmp	x1, x0, lsl #16
    6efc:	54ffff02 	b.cs	6edc <fwp_args23+0xc>  // b.hs, b.nlast
    6f00:	d350fc20 	lsr	x0, x1, #16
    6f04:	f949fc44 	ldr	x4, [x2, #5112]
    6f08:	8b000800 	add	x0, x0, x0, lsl #2
    6f0c:	d37df002 	lsl	x2, x0, #3
    6f10:	8b020083 	add	x3, x4, x2
    6f14:	f9401060 	ldr	x0, [x3, #32]
    6f18:	b4fffe20 	cbz	x0, 6edc <fwp_args23+0xc>
    6f1c:	38626882 	ldrb	w2, [x4, x2]
    6f20:	7100085f 	cmp	w2, #0x2
    6f24:	54000320 	b.eq	6f88 <fwp_args23+0xb8>  // b.none
    6f28:	7100045f 	cmp	w2, #0x1
    6f2c:	54fffd81 	b.ne	6edc <fwp_args23+0xc>  // b.any
    6f30:	29430864 	ldp	w4, w2, [x3, #24]
    6f34:	92403c21 	and	x1, x1, #0xffff
    6f38:	9b047c21 	mul	x1, x1, x4
    6f3c:	d360fc21 	lsr	x1, x1, #32
    6f40:	eb02003f 	cmp	x1, x2
    6f44:	54fffcc2 	b.cs	6edc <fwp_args23+0xc>  // b.hs, b.nlast
    6f48:	8b010000 	add	x0, x0, x1
    6f4c:	39400001 	ldrb	w1, [x0]
    6f50:	34fffc61 	cbz	w1, 6edc <fwp_args23+0xc>
    6f54:	d00000c2 	adrp	x2, 20000 <__data_start>
    6f58:	91018042 	add	x2, x2, #0x60
    6f5c:	b9413043 	ldr	w3, [x2, #304]
    6f60:	350000c3 	cbnz	w3, 6f78 <fwp_args23+0xa8>
    6f64:	7103f43f 	cmp	w1, #0xfd
    6f68:	54000168 	b.hi	6f94 <fwp_args23+0xc4>  // b.pmore
    6f6c:	11000421 	add	w1, w1, #0x1
    6f70:	39000001 	strb	w1, [x0]
    6f74:	d65f03c0 	ret
    6f78:	f940ac43 	ldr	x3, [x2, #344]
    6f7c:	91000463 	add	x3, x3, #0x1
    6f80:	f900ac43 	str	x3, [x2, #344]
    6f84:	17fffff8 	b	6f64 <fwp_args23+0x94>
    6f88:	72003c3f 	tst	w1, #0xffff
    6f8c:	54fffe00 	b.eq	6f4c <fwp_args23+0x7c>  // b.none
    6f90:	d65f03c0 	ret
    6f94:	17fff638 	b	4874 <fwp_rc_wide_dup>
    6f98:	d503201f 	nop
    6f9c:	d503201f 	nop

0000000000006fa0 <fwp_args12>:
    6fa0:	7100003f 	cmp	w1, #0x0
    6fa4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6fa8:	54000041 	b.ne	6fb0 <fwp_args12+0x10>  // b.any
    6fac:	d65f03c0 	ret
    6fb0:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    6fb4:	91190042 	add	x2, x2, #0x640
    6fb8:	f9400001 	ldr	x1, [x0]
    6fbc:	f949d843 	ldr	x3, [x2, #5040]
    6fc0:	f949ec40 	ldr	x0, [x2, #5080]
    6fc4:	cb030021 	sub	x1, x1, x3
    6fc8:	eb00403f 	cmp	x1, x0, lsl #16
    6fcc:	54ffff02 	b.cs	6fac <fwp_args12+0xc>  // b.hs, b.nlast
    6fd0:	d350fc20 	lsr	x0, x1, #16
    6fd4:	f949fc44 	ldr	x4, [x2, #5112]
    6fd8:	8b000800 	add	x0, x0, x0, lsl #2
    6fdc:	d37df002 	lsl	x2, x0, #3
    6fe0:	8b020083 	add	x3, x4, x2
    6fe4:	f9401060 	ldr	x0, [x3, #32]
    6fe8:	b4fffe20 	cbz	x0, 6fac <fwp_args12+0xc>
    6fec:	38626882 	ldrb	w2, [x4, x2]
    6ff0:	7100085f 	cmp	w2, #0x2
    6ff4:	54000320 	b.eq	7058 <fwp_args12+0xb8>  // b.none
    6ff8:	7100045f 	cmp	w2, #0x1
    6ffc:	54fffd81 	b.ne	6fac <fwp_args12+0xc>  // b.any
    7000:	29430864 	ldp	w4, w2, [x3, #24]
    7004:	92403c21 	and	x1, x1, #0xffff
    7008:	9b047c21 	mul	x1, x1, x4
    700c:	d360fc21 	lsr	x1, x1, #32
    7010:	eb02003f 	cmp	x1, x2
    7014:	54fffcc2 	b.cs	6fac <fwp_args12+0xc>  // b.hs, b.nlast
    7018:	8b010000 	add	x0, x0, x1
    701c:	39400001 	ldrb	w1, [x0]
    7020:	34fffc61 	cbz	w1, 6fac <fwp_args12+0xc>
    7024:	b00000c2 	adrp	x2, 20000 <__data_start>
    7028:	91018042 	add	x2, x2, #0x60
    702c:	b9413043 	ldr	w3, [x2, #304]
    7030:	350000c3 	cbnz	w3, 7048 <fwp_args12+0xa8>
    7034:	7103f43f 	cmp	w1, #0xfd
    7038:	54000168 	b.hi	7064 <fwp_args12+0xc4>  // b.pmore
    703c:	11000421 	add	w1, w1, #0x1
    7040:	39000001 	strb	w1, [x0]
    7044:	d65f03c0 	ret
    7048:	f940ac43 	ldr	x3, [x2, #344]
    704c:	91000463 	add	x3, x3, #0x1
    7050:	f900ac43 	str	x3, [x2, #344]
    7054:	17fffff8 	b	7034 <fwp_args12+0x94>
    7058:	72003c3f 	tst	w1, #0xffff
    705c:	54fffe00 	b.eq	701c <fwp_args12+0x7c>  // b.none
    7060:	d65f03c0 	ret
    7064:	17fff604 	b	4874 <fwp_rc_wide_dup>
    7068:	d503201f 	nop
    706c:	d503201f 	nop

0000000000007070 <fwp_caps12>:
    7070:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7074:	910003fd 	mov	x29, sp
    7078:	f9000bf3 	str	x19, [sp, #16]
    707c:	aa0003f3 	mov	x19, x0
    7080:	b9400400 	ldr	w0, [x0, #4]
    7084:	340004a0 	cbz	w0, 7118 <fwp_caps12+0xa8>
    7088:	f9400660 	ldr	x0, [x19, #8]
    708c:	350004e1 	cbnz	w1, 7128 <fwp_caps12+0xb8>
    7090:	97fffbc4 	bl	5fa0 <fwp_drop0>
    7094:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    7098:	91190042 	add	x2, x2, #0x640
    709c:	f949d840 	ldr	x0, [x2, #5040]
    70a0:	f949ec41 	ldr	x1, [x2, #5080]
    70a4:	cb000260 	sub	x0, x19, x0
    70a8:	eb01401f 	cmp	x0, x1, lsl #16
    70ac:	54000382 	b.cs	711c <fwp_caps12+0xac>  // b.hs, b.nlast
    70b0:	d350fc01 	lsr	x1, x0, #16
    70b4:	f949fc44 	ldr	x4, [x2, #5112]
    70b8:	8b010821 	add	x1, x1, x1, lsl #2
    70bc:	d37df021 	lsl	x1, x1, #3
    70c0:	8b010083 	add	x3, x4, x1
    70c4:	f9401062 	ldr	x2, [x3, #32]
    70c8:	b40002a2 	cbz	x2, 711c <fwp_caps12+0xac>
    70cc:	38616881 	ldrb	w1, [x4, x1]
    70d0:	7100083f 	cmp	w1, #0x2
    70d4:	54000740 	b.eq	71bc <fwp_caps12+0x14c>  // b.none
    70d8:	7100043f 	cmp	w1, #0x1
    70dc:	54000201 	b.ne	711c <fwp_caps12+0xac>  // b.any
    70e0:	29430464 	ldp	w4, w1, [x3, #24]
    70e4:	92403c00 	and	x0, x0, #0xffff
    70e8:	9b047c00 	mul	x0, x0, x4
    70ec:	d360fc00 	lsr	x0, x0, #32
    70f0:	eb01001f 	cmp	x0, x1
    70f4:	54000142 	b.cs	711c <fwp_caps12+0xac>  // b.hs, b.nlast
    70f8:	8b000042 	add	x2, x2, x0
    70fc:	39400040 	ldrb	w0, [x2]
    7100:	7100041f 	cmp	w0, #0x1
    7104:	540000c1 	b.ne	711c <fwp_caps12+0xac>  // b.any
    7108:	aa1303e0 	mov	x0, x19
    710c:	f9400bf3 	ldr	x19, [sp, #16]
    7110:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7114:	17fff6bf 	b	4c10 <fwp_mem_free>
    7118:	34fffbe1 	cbz	w1, 7094 <fwp_caps12+0x24>
    711c:	f9400bf3 	ldr	x19, [sp, #16]
    7120:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7124:	d65f03c0 	ret
    7128:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    712c:	91190042 	add	x2, x2, #0x640
    7130:	f949d843 	ldr	x3, [x2, #5040]
    7134:	f949ec41 	ldr	x1, [x2, #5080]
    7138:	cb030000 	sub	x0, x0, x3
    713c:	eb01401f 	cmp	x0, x1, lsl #16
    7140:	54fffee2 	b.cs	711c <fwp_caps12+0xac>  // b.hs, b.nlast
    7144:	d350fc01 	lsr	x1, x0, #16
    7148:	f949fc44 	ldr	x4, [x2, #5112]
    714c:	8b010821 	add	x1, x1, x1, lsl #2
    7150:	d37df021 	lsl	x1, x1, #3
    7154:	8b010083 	add	x3, x4, x1
    7158:	f9401062 	ldr	x2, [x3, #32]
    715c:	b4fffe02 	cbz	x2, 711c <fwp_caps12+0xac>
    7160:	38616881 	ldrb	w1, [x4, x1]
    7164:	7100083f 	cmp	w1, #0x2
    7168:	54000300 	b.eq	71c8 <fwp_caps12+0x158>  // b.none
    716c:	7100043f 	cmp	w1, #0x1
    7170:	54fffd61 	b.ne	711c <fwp_caps12+0xac>  // b.any
    7174:	92403c01 	and	x1, x0, #0xffff
    7178:	29430064 	ldp	w4, w0, [x3, #24]
    717c:	9b047c21 	mul	x1, x1, x4
    7180:	d360fc21 	lsr	x1, x1, #32
    7184:	eb00003f 	cmp	x1, x0
    7188:	54fffca2 	b.cs	711c <fwp_caps12+0xac>  // b.hs, b.nlast
    718c:	8b010042 	add	x2, x2, x1
    7190:	39400040 	ldrb	w0, [x2]
    7194:	34fffc40 	cbz	w0, 711c <fwp_caps12+0xac>
    7198:	b00000c1 	adrp	x1, 20000 <__data_start>
    719c:	91018021 	add	x1, x1, #0x60
    71a0:	b9413023 	ldr	w3, [x1, #304]
    71a4:	35000183 	cbnz	w3, 71d4 <fwp_caps12+0x164>
    71a8:	7103f41f 	cmp	w0, #0xfd
    71ac:	540001c8 	b.hi	71e4 <fwp_caps12+0x174>  // b.pmore
    71b0:	11000400 	add	w0, w0, #0x1
    71b4:	39000040 	strb	w0, [x2]
    71b8:	17ffffd9 	b	711c <fwp_caps12+0xac>
    71bc:	72003c1f 	tst	w0, #0xffff
    71c0:	54fffae1 	b.ne	711c <fwp_caps12+0xac>  // b.any
    71c4:	17ffffce 	b	70fc <fwp_caps12+0x8c>
    71c8:	72003c1f 	tst	w0, #0xffff
    71cc:	54fffa81 	b.ne	711c <fwp_caps12+0xac>  // b.any
    71d0:	17fffff0 	b	7190 <fwp_caps12+0x120>
    71d4:	f940ac23 	ldr	x3, [x1, #344]
    71d8:	91000463 	add	x3, x3, #0x1
    71dc:	f900ac23 	str	x3, [x1, #344]
    71e0:	17fffff2 	b	71a8 <fwp_caps12+0x138>
    71e4:	f9400bf3 	ldr	x19, [sp, #16]
    71e8:	aa0203e0 	mov	x0, x2
    71ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71f0:	17fff5a1 	b	4874 <fwp_rc_wide_dup>

00000000000071f4 <fwp_caps23>:
    71f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    71f8:	910003fd 	mov	x29, sp
    71fc:	f9000bf3 	str	x19, [sp, #16]
    7200:	aa0003f3 	mov	x19, x0
    7204:	b9400400 	ldr	w0, [x0, #4]
    7208:	340004a0 	cbz	w0, 729c <fwp_caps23+0xa8>
    720c:	f9400660 	ldr	x0, [x19, #8]
    7210:	350004e1 	cbnz	w1, 72ac <fwp_caps23+0xb8>
    7214:	97fffe97 	bl	6c70 <fwp_drop2>
    7218:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    721c:	91190042 	add	x2, x2, #0x640
    7220:	f949d840 	ldr	x0, [x2, #5040]
    7224:	f949ec41 	ldr	x1, [x2, #5080]
    7228:	cb000260 	sub	x0, x19, x0
    722c:	eb01401f 	cmp	x0, x1, lsl #16
    7230:	54000382 	b.cs	72a0 <fwp_caps23+0xac>  // b.hs, b.nlast
    7234:	d350fc01 	lsr	x1, x0, #16
    7238:	f949fc44 	ldr	x4, [x2, #5112]
    723c:	8b010821 	add	x1, x1, x1, lsl #2
    7240:	d37df021 	lsl	x1, x1, #3
    7244:	8b010083 	add	x3, x4, x1
    7248:	f9401062 	ldr	x2, [x3, #32]
    724c:	b40002a2 	cbz	x2, 72a0 <fwp_caps23+0xac>
    7250:	38616881 	ldrb	w1, [x4, x1]
    7254:	7100083f 	cmp	w1, #0x2
    7258:	54000740 	b.eq	7340 <fwp_caps23+0x14c>  // b.none
    725c:	7100043f 	cmp	w1, #0x1
    7260:	54000201 	b.ne	72a0 <fwp_caps23+0xac>  // b.any
    7264:	29430464 	ldp	w4, w1, [x3, #24]
    7268:	92403c00 	and	x0, x0, #0xffff
    726c:	9b047c00 	mul	x0, x0, x4
    7270:	d360fc00 	lsr	x0, x0, #32
    7274:	eb01001f 	cmp	x0, x1
    7278:	54000142 	b.cs	72a0 <fwp_caps23+0xac>  // b.hs, b.nlast
    727c:	8b000042 	add	x2, x2, x0
    7280:	39400040 	ldrb	w0, [x2]
    7284:	7100041f 	cmp	w0, #0x1
    7288:	540000c1 	b.ne	72a0 <fwp_caps23+0xac>  // b.any
    728c:	aa1303e0 	mov	x0, x19
    7290:	f9400bf3 	ldr	x19, [sp, #16]
    7294:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7298:	17fff65e 	b	4c10 <fwp_mem_free>
    729c:	34fffbe1 	cbz	w1, 7218 <fwp_caps23+0x24>
    72a0:	f9400bf3 	ldr	x19, [sp, #16]
    72a4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    72a8:	d65f03c0 	ret
    72ac:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    72b0:	91190042 	add	x2, x2, #0x640
    72b4:	f949d843 	ldr	x3, [x2, #5040]
    72b8:	f949ec41 	ldr	x1, [x2, #5080]
    72bc:	cb030000 	sub	x0, x0, x3
    72c0:	eb01401f 	cmp	x0, x1, lsl #16
    72c4:	54fffee2 	b.cs	72a0 <fwp_caps23+0xac>  // b.hs, b.nlast
    72c8:	d350fc01 	lsr	x1, x0, #16
    72cc:	f949fc44 	ldr	x4, [x2, #5112]
    72d0:	8b010821 	add	x1, x1, x1, lsl #2
    72d4:	d37df021 	lsl	x1, x1, #3
    72d8:	8b010083 	add	x3, x4, x1
    72dc:	f9401062 	ldr	x2, [x3, #32]
    72e0:	b4fffe02 	cbz	x2, 72a0 <fwp_caps23+0xac>
    72e4:	38616881 	ldrb	w1, [x4, x1]
    72e8:	7100083f 	cmp	w1, #0x2
    72ec:	54000300 	b.eq	734c <fwp_caps23+0x158>  // b.none
    72f0:	7100043f 	cmp	w1, #0x1
    72f4:	54fffd61 	b.ne	72a0 <fwp_caps23+0xac>  // b.any
    72f8:	92403c01 	and	x1, x0, #0xffff
    72fc:	29430064 	ldp	w4, w0, [x3, #24]
    7300:	9b047c21 	mul	x1, x1, x4
    7304:	d360fc21 	lsr	x1, x1, #32
    7308:	eb00003f 	cmp	x1, x0
    730c:	54fffca2 	b.cs	72a0 <fwp_caps23+0xac>  // b.hs, b.nlast
    7310:	8b010042 	add	x2, x2, x1
    7314:	39400040 	ldrb	w0, [x2]
    7318:	34fffc40 	cbz	w0, 72a0 <fwp_caps23+0xac>
    731c:	b00000c1 	adrp	x1, 20000 <__data_start>
    7320:	91018021 	add	x1, x1, #0x60
    7324:	b9413023 	ldr	w3, [x1, #304]
    7328:	35000183 	cbnz	w3, 7358 <fwp_caps23+0x164>
    732c:	7103f41f 	cmp	w0, #0xfd
    7330:	540001c8 	b.hi	7368 <fwp_caps23+0x174>  // b.pmore
    7334:	11000400 	add	w0, w0, #0x1
    7338:	39000040 	strb	w0, [x2]
    733c:	17ffffd9 	b	72a0 <fwp_caps23+0xac>
    7340:	72003c1f 	tst	w0, #0xffff
    7344:	54fffae1 	b.ne	72a0 <fwp_caps23+0xac>  // b.any
    7348:	17ffffce 	b	7280 <fwp_caps23+0x8c>
    734c:	72003c1f 	tst	w0, #0xffff
    7350:	54fffa81 	b.ne	72a0 <fwp_caps23+0xac>  // b.any
    7354:	17fffff0 	b	7314 <fwp_caps23+0x120>
    7358:	f940ac23 	ldr	x3, [x1, #344]
    735c:	91000463 	add	x3, x3, #0x1
    7360:	f900ac23 	str	x3, [x1, #344]
    7364:	17fffff2 	b	732c <fwp_caps23+0x138>
    7368:	f9400bf3 	ldr	x19, [sp, #16]
    736c:	aa0203e0 	mov	x0, x2
    7370:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7374:	17fff540 	b	4874 <fwp_rc_wide_dup>
    7378:	d503201f 	nop
    737c:	d503201f 	nop

0000000000007380 <f23>:
    7380:	d10203ff 	sub	sp, sp, #0x80
    7384:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    7388:	f947f421 	ldr	x1, [x1, #4072]
    738c:	a9027bfd 	stp	x29, x30, [sp, #32]
    7390:	910083fd 	add	x29, sp, #0x20
    7394:	a9045bf5 	stp	x21, x22, [sp, #64]
    7398:	d0000396 	adrp	x22, 79000 <fwp_root_context+0xba0>
    739c:	911902c3 	add	x3, x22, #0x640
    73a0:	a90353f3 	stp	x19, x20, [sp, #48]
    73a4:	a90563f7 	stp	x23, x24, [sp, #80]
    73a8:	aa0003f8 	mov	x24, x0
    73ac:	a9066bf9 	stp	x25, x26, [sp, #96]
    73b0:	f949ec62 	ldr	x2, [x3, #5080]
    73b4:	f9400024 	ldr	x4, [x1]
    73b8:	f9000fe4 	str	x4, [sp, #24]
    73bc:	d2800004 	mov	x4, #0x0                   	// #0
    73c0:	f949d861 	ldr	x1, [x3, #5040]
    73c4:	d370bc42 	lsl	x2, x2, #16
    73c8:	b40018e0 	cbz	x0, 76e4 <f23+0x364>
    73cc:	f9400819 	ldr	x25, [x0, #16]
    73d0:	cb010321 	sub	x1, x25, x1
    73d4:	eb02003f 	cmp	x1, x2
    73d8:	540003e2 	b.cs	7454 <f23+0xd4>  // b.hs, b.nlast
    73dc:	f949fc60 	ldr	x0, [x3, #5112]
    73e0:	d350fc22 	lsr	x2, x1, #16
    73e4:	8b020842 	add	x2, x2, x2, lsl #2
    73e8:	8b020c02 	add	x2, x0, x2, lsl #3
    73ec:	f9401040 	ldr	x0, [x2, #32]
    73f0:	b4000320 	cbz	x0, 7454 <f23+0xd4>
    73f4:	39400043 	ldrb	w3, [x2]
    73f8:	7100087f 	cmp	w3, #0x2
    73fc:	54001660 	b.eq	76c8 <f23+0x348>  // b.none
    7400:	7100047f 	cmp	w3, #0x1
    7404:	54000241 	b.ne	744c <f23+0xcc>  // b.any
    7408:	29430843 	ldp	w3, w2, [x2, #24]
    740c:	92403c21 	and	x1, x1, #0xffff
    7410:	9b037c21 	mul	x1, x1, x3
    7414:	d360fc21 	lsr	x1, x1, #32
    7418:	eb02003f 	cmp	x1, x2
    741c:	54000182 	b.cs	744c <f23+0xcc>  // b.hs, b.nlast
    7420:	8b010000 	add	x0, x0, x1
    7424:	39400001 	ldrb	w1, [x0]
    7428:	34000121 	cbz	w1, 744c <f23+0xcc>
    742c:	b00000c2 	adrp	x2, 20000 <__data_start>
    7430:	91018042 	add	x2, x2, #0x60
    7434:	b9413043 	ldr	w3, [x2, #304]
    7438:	350014e3 	cbnz	w3, 76d4 <f23+0x354>
    743c:	7103f43f 	cmp	w1, #0xfd
    7440:	54001908 	b.hi	7760 <f23+0x3e0>  // b.pmore
    7444:	11000421 	add	w1, w1, #0x1
    7448:	39000001 	strb	w1, [x0]
    744c:	d2800000 	mov	x0, #0x0                   	// #0
    7450:	b40000f8 	cbz	x24, 746c <f23+0xec>
    7454:	aa1803e1 	mov	x1, x24
    7458:	d2800000 	mov	x0, #0x0                   	// #0
    745c:	d503201f 	nop
    7460:	f9400821 	ldr	x1, [x1, #16]
    7464:	91000400 	add	x0, x0, #0x1
    7468:	b5ffffc1 	cbnz	x1, 7460 <f23+0xe0>
    746c:	b4001439 	cbz	x25, 76f0 <f23+0x370>
    7470:	aa1903e1 	mov	x1, x25
    7474:	d2800002 	mov	x2, #0x0                   	// #0
    7478:	f9400821 	ldr	x1, [x1, #16]
    747c:	91000442 	add	x2, x2, #0x1
    7480:	b5ffffc1 	cbnz	x1, 7478 <f23+0xf8>
    7484:	eb00005f 	cmp	x2, x0
    7488:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    748c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    7490:	eb01035f 	cmp	x26, x1
    7494:	540016e8 	b.hi	7770 <f23+0x3f0>  // b.pmore
    7498:	d37ffb53 	lsl	x19, x26, #1
    749c:	52800041 	mov	w1, #0x2                   	// #2
    74a0:	91000660 	add	x0, x19, #0x1
    74a4:	d37df000 	lsl	x0, x0, #3
    74a8:	97fff6fa 	bl	5090 <fwp_heap_alloc>
    74ac:	aa0003f7 	mov	x23, x0
    74b0:	911902c1 	add	x1, x22, #0x640
    74b4:	aa0103e0 	mov	x0, x1
    74b8:	f90002f3 	str	x19, [x23]
    74bc:	f949d821 	ldr	x1, [x1, #5040]
    74c0:	f949ec00 	ldr	x0, [x0, #5080]
    74c4:	cb0102e1 	sub	x1, x23, x1
    74c8:	eb00403f 	cmp	x1, x0, lsl #16
    74cc:	54000342 	b.cs	7534 <f23+0x1b4>  // b.hs, b.nlast
    74d0:	911902c2 	add	x2, x22, #0x640
    74d4:	d350fc20 	lsr	x0, x1, #16
    74d8:	8b000800 	add	x0, x0, x0, lsl #2
    74dc:	f949fc43 	ldr	x3, [x2, #5112]
    74e0:	d37df002 	lsl	x2, x0, #3
    74e4:	8b020060 	add	x0, x3, x2
    74e8:	f9401013 	ldr	x19, [x0, #32]
    74ec:	b4000253 	cbz	x19, 7534 <f23+0x1b4>
    74f0:	38626862 	ldrb	w2, [x3, x2]
    74f4:	7100085f 	cmp	w2, #0x2
    74f8:	54000e20 	b.eq	76bc <f23+0x33c>  // b.none
    74fc:	7100045f 	cmp	w2, #0x1
    7500:	540001a1 	b.ne	7534 <f23+0x1b4>  // b.any
    7504:	29430002 	ldp	w2, w0, [x0, #24]
    7508:	92403c21 	and	x1, x1, #0xffff
    750c:	9b027c21 	mul	x1, x1, x2
    7510:	d360fc21 	lsr	x1, x1, #32
    7514:	eb00003f 	cmp	x1, x0
    7518:	540000e2 	b.cs	7534 <f23+0x1b4>  // b.hs, b.nlast
    751c:	8b010273 	add	x19, x19, x1
    7520:	39400260 	ldrb	w0, [x19]
    7524:	7103fc1f 	cmp	w0, #0xff
    7528:	54001060 	b.eq	7734 <f23+0x3b4>  // b.none
    752c:	52800020 	mov	w0, #0x1                   	// #1
    7530:	39000260 	strb	w0, [x19]
    7534:	b400025a 	cbz	x26, 757c <f23+0x1fc>
    7538:	8b1a12fa 	add	x26, x23, x26, lsl #4
    753c:	aa1703f3 	mov	x19, x23
    7540:	aa1803f5 	mov	x21, x24
    7544:	aa1903f4 	mov	x20, x25
    7548:	f9400683 	ldr	x3, [x20, #8]
    754c:	f94006a2 	ldr	x2, [x21, #8]
    7550:	f9400861 	ldr	x1, [x3, #16]
    7554:	f9400840 	ldr	x0, [x2, #16]
    7558:	fd400461 	ldr	d1, [x3, #8]
    755c:	fd400440 	ldr	d0, [x2, #8]
    7560:	97fff868 	bl	5700 <w107>
    7564:	f9000660 	str	x0, [x19, #8]
    7568:	f8010e61 	str	x1, [x19, #16]!
    756c:	f9400a94 	ldr	x20, [x20, #16]
    7570:	f9400ab5 	ldr	x21, [x21, #16]
    7574:	eb13035f 	cmp	x26, x19
    7578:	54fffe81 	b.ne	7548 <f23+0x1c8>  // b.any
    757c:	aa1903e0 	mov	x0, x25
    7580:	97fffdbc 	bl	6c70 <fwp_drop2>
    7584:	aa1803e0 	mov	x0, x24
    7588:	97fffdba 	bl	6c70 <fwp_drop2>
    758c:	f94002f5 	ldr	x21, [x23]
    7590:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7594:	b4000275 	cbz	x21, 75e0 <f23+0x260>
    7598:	fd003be8 	str	d8, [sp, #112]
    759c:	2f00e408 	movi	d8, #0x0
    75a0:	910022f9 	add	x25, x23, #0x8
    75a4:	910042f8 	add	x24, x23, #0x10
    75a8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    75ac:	d2800013 	mov	x19, #0x0                   	// #0
    75b0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    75b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    75b8:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    75bc:	aa0303e1 	mov	x1, x3
    75c0:	1e602908 	fadd	d8, d8, d0
    75c4:	91000a73 	add	x19, x19, #0x2
    75c8:	97fff79b 	bl	5434 <fwp_p_ad_push>
    75cc:	aa0003f4 	mov	x20, x0
    75d0:	eb1302bf 	cmp	x21, x19
    75d4:	54fffee8 	b.hi	75b0 <f23+0x230>  // b.pmore
    75d8:	9e660115 	fmov	x21, d8
    75dc:	fd403be8 	ldr	d8, [sp, #112]
    75e0:	911902d6 	add	x22, x22, #0x640
    75e4:	aa1703e0 	mov	x0, x23
    75e8:	97fffd02 	bl	69f0 <fwp_drop4>
    75ec:	a900d3f5 	stp	x21, x20, [sp, #8]
    75f0:	910023e1 	add	x1, sp, #0x8
    75f4:	52800000 	mov	w0, #0x0                   	// #0
    75f8:	97fff886 	bl	5810 <fwp_data.part.0.constprop.0>
    75fc:	f949dac1 	ldr	x1, [x22, #5040]
    7600:	aa0003f3 	mov	x19, x0
    7604:	f949eec0 	ldr	x0, [x22, #5080]
    7608:	cb010261 	sub	x1, x19, x1
    760c:	eb00403f 	cmp	x1, x0, lsl #16
    7610:	54000322 	b.cs	7674 <f23+0x2f4>  // b.hs, b.nlast
    7614:	d350fc22 	lsr	x2, x1, #16
    7618:	f949fec3 	ldr	x3, [x22, #5112]
    761c:	8b020842 	add	x2, x2, x2, lsl #2
    7620:	d37df042 	lsl	x2, x2, #3
    7624:	8b020060 	add	x0, x3, x2
    7628:	f9401014 	ldr	x20, [x0, #32]
    762c:	b4000254 	cbz	x20, 7674 <f23+0x2f4>
    7630:	38626862 	ldrb	w2, [x3, x2]
    7634:	7100085f 	cmp	w2, #0x2
    7638:	540003c0 	b.eq	76b0 <f23+0x330>  // b.none
    763c:	7100045f 	cmp	w2, #0x1
    7640:	540001a1 	b.ne	7674 <f23+0x2f4>  // b.any
    7644:	29430002 	ldp	w2, w0, [x0, #24]
    7648:	92403c21 	and	x1, x1, #0xffff
    764c:	9b027c21 	mul	x1, x1, x2
    7650:	d360fc21 	lsr	x1, x1, #32
    7654:	eb00003f 	cmp	x1, x0
    7658:	540000e2 	b.cs	7674 <f23+0x2f4>  // b.hs, b.nlast
    765c:	8b010294 	add	x20, x20, x1
    7660:	39400280 	ldrb	w0, [x20]
    7664:	7103fc1f 	cmp	w0, #0xff
    7668:	54000600 	b.eq	7728 <f23+0x3a8>  // b.none
    766c:	52800020 	mov	w0, #0x1                   	// #1
    7670:	39000280 	strb	w0, [x20]
    7674:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    7678:	f947f400 	ldr	x0, [x0, #4072]
    767c:	f9400fe2 	ldr	x2, [sp, #24]
    7680:	f9400001 	ldr	x1, [x0]
    7684:	eb010042 	subs	x2, x2, x1
    7688:	d2800001 	mov	x1, #0x0                   	// #0
    768c:	540007a1 	b.ne	7780 <f23+0x400>  // b.any
    7690:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7694:	aa1303e0 	mov	x0, x19
    7698:	a94353f3 	ldp	x19, x20, [sp, #48]
    769c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    76a0:	a94563f7 	ldp	x23, x24, [sp, #80]
    76a4:	a9466bf9 	ldp	x25, x26, [sp, #96]
    76a8:	910203ff 	add	sp, sp, #0x80
    76ac:	d65f03c0 	ret
    76b0:	72003c3f 	tst	w1, #0xffff
    76b4:	54fffe01 	b.ne	7674 <f23+0x2f4>  // b.any
    76b8:	17ffffea 	b	7660 <f23+0x2e0>
    76bc:	72003c3f 	tst	w1, #0xffff
    76c0:	54fff3a1 	b.ne	7534 <f23+0x1b4>  // b.any
    76c4:	17ffff97 	b	7520 <f23+0x1a0>
    76c8:	72003c3f 	tst	w1, #0xffff
    76cc:	54ffec01 	b.ne	744c <f23+0xcc>  // b.any
    76d0:	17ffff55 	b	7424 <f23+0xa4>
    76d4:	f940ac43 	ldr	x3, [x2, #344]
    76d8:	91000463 	add	x3, x3, #0x1
    76dc:	f900ac43 	str	x3, [x2, #344]
    76e0:	17ffff57 	b	743c <f23+0xbc>
    76e4:	cb0103e1 	neg	x1, x1
    76e8:	eb02003f 	cmp	x1, x2
    76ec:	540002a3 	b.cc	7740 <f23+0x3c0>  // b.lo, b.ul, b.last
    76f0:	52800041 	mov	w1, #0x2                   	// #2
    76f4:	d2800100 	mov	x0, #0x8                   	// #8
    76f8:	97fff666 	bl	5090 <fwp_heap_alloc>
    76fc:	aa0003f7 	mov	x23, x0
    7700:	911902c0 	add	x0, x22, #0x640
    7704:	f90002ff 	str	xzr, [x23]
    7708:	f949d801 	ldr	x1, [x0, #5040]
    770c:	f949ec00 	ldr	x0, [x0, #5080]
    7710:	cb0102e1 	sub	x1, x23, x1
    7714:	eb00403f 	cmp	x1, x0, lsl #16
    7718:	54000282 	b.cs	7768 <f23+0x3e8>  // b.hs, b.nlast
    771c:	d280001a 	mov	x26, #0x0                   	// #0
    7720:	d2800019 	mov	x25, #0x0                   	// #0
    7724:	17ffff6b 	b	74d0 <f23+0x150>
    7728:	aa1403e0 	mov	x0, x20
    772c:	97fff499 	bl	4990 <fwp_rc_forget_slot>
    7730:	17ffffcf 	b	766c <f23+0x2ec>
    7734:	aa1303e0 	mov	x0, x19
    7738:	97fff496 	bl	4990 <fwp_rc_forget_slot>
    773c:	17ffff7c 	b	752c <f23+0x1ac>
    7740:	f949fc62 	ldr	x2, [x3, #5112]
    7744:	d350fc20 	lsr	x0, x1, #16
    7748:	8b000800 	add	x0, x0, x0, lsl #2
    774c:	8b000c42 	add	x2, x2, x0, lsl #3
    7750:	f9401040 	ldr	x0, [x2, #32]
    7754:	b4fffce0 	cbz	x0, 76f0 <f23+0x370>
    7758:	d2800019 	mov	x25, #0x0                   	// #0
    775c:	17ffff26 	b	73f4 <f23+0x74>
    7760:	97fff445 	bl	4874 <fwp_rc_wide_dup>
    7764:	17ffff3a 	b	744c <f23+0xcc>
    7768:	d2800019 	mov	x25, #0x0                   	// #0
    776c:	17ffff84 	b	757c <f23+0x1fc>
    7770:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    7774:	913a8000 	add	x0, x0, #0xea0
    7778:	fd003be8 	str	d8, [sp, #112]
    777c:	97fff001 	bl	3780 <fwp_trap>
    7780:	fd003be8 	str	d8, [sp, #112]
    7784:	97ffec23 	bl	2810 <__stack_chk_fail@plt>
    7788:	d503201f 	nop
    778c:	d503201f 	nop

0000000000007790 <fwp_owned_entry23>:
    7790:	f9400000 	ldr	x0, [x0]
    7794:	17fffefb 	b	7380 <f23>
    7798:	d503201f 	nop
    779c:	d503201f 	nop

00000000000077a0 <e23>:
    77a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    77a4:	910003fd 	mov	x29, sp
    77a8:	f9000bf3 	str	x19, [sp, #16]
    77ac:	f9400013 	ldr	x19, [x0]
    77b0:	aa1303e0 	mov	x0, x19
    77b4:	97fff874 	bl	5984 <fwp_rc_share>
    77b8:	aa1303e0 	mov	x0, x19
    77bc:	97fffef1 	bl	7380 <f23>
    77c0:	aa0003f3 	mov	x19, x0
    77c4:	97fff870 	bl	5984 <fwp_rc_share>
    77c8:	aa1303e0 	mov	x0, x19
    77cc:	f9400bf3 	ldr	x19, [sp, #16]
    77d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    77d4:	d65f03c0 	ret
    77d8:	d503201f 	nop
    77dc:	d503201f 	nop

00000000000077e0 <f12>:
    77e0:	d10483ff 	sub	sp, sp, #0x120
    77e4:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    77e8:	f947f442 	ldr	x2, [x2, #4072]
    77ec:	9100e3e8 	add	x8, sp, #0x38
    77f0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    77f4:	910303fd 	add	x29, sp, #0xc0
    77f8:	a90f63f7 	stp	x23, x24, [sp, #240]
    77fc:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xba0>
    7800:	911902e3 	add	x3, x23, #0x640
    7804:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7808:	b00000d5 	adrp	x21, 20000 <__data_start>
    780c:	910182a4 	add	x4, x21, #0x60
    7810:	f949d861 	ldr	x1, [x3, #5040]
    7814:	a90d53f3 	stp	x19, x20, [sp, #208]
    7818:	910103f8 	add	x24, sp, #0x40
    781c:	f949ec65 	ldr	x5, [x3, #5080]
    7820:	a9106bf9 	stp	x25, x26, [sp, #256]
    7824:	b00000d9 	adrp	x25, 20000 <__data_start>
    7828:	a91173fb 	stp	x27, x28, [sp, #272]
    782c:	91004339 	add	x25, x25, #0x10
    7830:	91008339 	add	x25, x25, #0x20
    7834:	f941c886 	ldr	x6, [x4, #912]
    7838:	f9400047 	ldr	x7, [x2]
    783c:	f9005fe7 	str	x7, [sp, #184]
    7840:	d2800007 	mov	x7, #0x0                   	// #0
    7844:	f0fffff3 	adrp	x19, 6000 <fwp_drop0+0x60>
    7848:	12800007 	mov	w7, #0xffffffff            	// #-1
    784c:	91128262 	add	x2, x19, #0x4a0
    7850:	cb010321 	sub	x1, x25, x1
    7854:	f90003e8 	str	x8, [sp]
    7858:	aa0003f4 	mov	x20, x0
    785c:	b9003be7 	str	w7, [sp, #56]
    7860:	a9040be6 	stp	x6, x2, [sp, #64]
    7864:	f9002be8 	str	x8, [sp, #80]
    7868:	f901c898 	str	x24, [x4, #912]
    786c:	eb05403f 	cmp	x1, x5, lsl #16
    7870:	540003a2 	b.cs	78e4 <f12+0x104>  // b.hs, b.nlast
    7874:	d350fc20 	lsr	x0, x1, #16
    7878:	f949fc64 	ldr	x4, [x3, #5112]
    787c:	8b000800 	add	x0, x0, x0, lsl #2
    7880:	d37df002 	lsl	x2, x0, #3
    7884:	8b020083 	add	x3, x4, x2
    7888:	f9401060 	ldr	x0, [x3, #32]
    788c:	b40002c0 	cbz	x0, 78e4 <f12+0x104>
    7890:	38626882 	ldrb	w2, [x4, x2]
    7894:	7100085f 	cmp	w2, #0x2
    7898:	54006ee0 	b.eq	8674 <f12+0xe94>  // b.none
    789c:	7100045f 	cmp	w2, #0x1
    78a0:	54000221 	b.ne	78e4 <f12+0x104>  // b.any
    78a4:	29430864 	ldp	w4, w2, [x3, #24]
    78a8:	92403c21 	and	x1, x1, #0xffff
    78ac:	9b047c21 	mul	x1, x1, x4
    78b0:	d360fc21 	lsr	x1, x1, #32
    78b4:	eb02003f 	cmp	x1, x2
    78b8:	54000162 	b.cs	78e4 <f12+0x104>  // b.hs, b.nlast
    78bc:	8b010000 	add	x0, x0, x1
    78c0:	39400001 	ldrb	w1, [x0]
    78c4:	34000101 	cbz	w1, 78e4 <f12+0x104>
    78c8:	910182a2 	add	x2, x21, #0x60
    78cc:	b9413043 	ldr	w3, [x2, #304]
    78d0:	35007063 	cbnz	w3, 86dc <f12+0xefc>
    78d4:	7103f43f 	cmp	w1, #0xfd
    78d8:	54007a28 	b.hi	881c <f12+0x103c>  // b.pmore
    78dc:	11000421 	add	w1, w1, #0x1
    78e0:	39000001 	strb	w1, [x0]
    78e4:	aa1903e0 	mov	x0, x25
    78e8:	97fffa0a 	bl	6110 <fwp_closure_drop>
    78ec:	b4006cf4 	cbz	x20, 8688 <f12+0xea8>
    78f0:	aa1403e0 	mov	x0, x20
    78f4:	d2800001 	mov	x1, #0x0                   	// #0
    78f8:	f9400800 	ldr	x0, [x0, #16]
    78fc:	91000421 	add	x1, x1, #0x1
    7900:	b5ffffc0 	cbnz	x0, 78f8 <f12+0x118>
    7904:	aa0103fa 	mov	x26, x1
    7908:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    790c:	eb00003f 	cmp	x1, x0
    7910:	54007c48 	b.hi	8898 <f12+0x10b8>  // b.pmore
    7914:	910182b9 	add	x25, x21, #0x60
    7918:	b943c720 	ldr	w0, [x25, #964]
    791c:	34006980 	cbz	w0, 864c <f12+0xe6c>
    7920:	910182a0 	add	x0, x21, #0x60
    7924:	f9406c1b 	ldr	x27, [x0, #216]
    7928:	f940b019 	ldr	x25, [x0, #352]
    792c:	eb1b033f 	cmp	x25, x27
    7930:	5400368a 	b.ge	8000 <f12+0x820>  // b.tcont
    7934:	f9404401 	ldr	x1, [x0, #136]
    7938:	8b190720 	add	x0, x25, x25, lsl #1
    793c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7940:	8b000b20 	add	x0, x25, x0, lsl #2
    7944:	8b000c20 	add	x0, x1, x0, lsl #3
    7948:	b9400401 	ldr	w1, [x0, #4]
    794c:	35000081 	cbnz	w1, 795c <f12+0x17c>
    7950:	b9400001 	ldr	w1, [x0]
    7954:	6b02003f 	cmp	w1, w2
    7958:	54003549 	b.ls	8000 <f12+0x820>  // b.plast
    795c:	91000739 	add	x25, x25, #0x1
    7960:	9101a000 	add	x0, x0, #0x68
    7964:	eb1b033f 	cmp	x25, x27
    7968:	54ffff01 	b.ne	7948 <f12+0x168>  // b.any
    796c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7970:	eb00037f 	cmp	x27, x0
    7974:	540079ec 	b.gt	88b0 <f12+0x10d0>
    7978:	910182a0 	add	x0, x21, #0x60
    797c:	f9409001 	ldr	x1, [x0, #288]
    7980:	f940441c 	ldr	x28, [x0, #136]
    7984:	eb1b003f 	cmp	x1, x27
    7988:	54000221 	b.ne	79cc <f12+0x1ec>  // b.any
    798c:	b400731b 	cbz	x27, 87ec <f12+0x100c>
    7990:	d37ffb76 	lsl	x22, x27, #1
    7994:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7998:	eb0002df 	cmp	x22, x0
    799c:	9a80d2d6 	csel	x22, x22, x0, le
    79a0:	8b1606c1 	add	x1, x22, x22, lsl #1
    79a4:	8b010ac1 	add	x1, x22, x1, lsl #2
    79a8:	d37df021 	lsl	x1, x1, #3
    79ac:	aa1c03e0 	mov	x0, x28
    79b0:	52800002 	mov	w2, #0x0                   	// #0
    79b4:	97fff288 	bl	43d4 <ad_raw_realloc>
    79b8:	aa0003fc 	mov	x28, x0
    79bc:	b40036e0 	cbz	x0, 8098 <f12+0x8b8>
    79c0:	910182a0 	add	x0, x21, #0x60
    79c4:	f900441c 	str	x28, [x0, #136]
    79c8:	f9009016 	str	x22, [x0, #288]
    79cc:	8b1b0761 	add	x1, x27, x27, lsl #1
    79d0:	91000762 	add	x2, x27, #0x1
    79d4:	4f000400 	movi	v0.4s, #0x0
    79d8:	910182a0 	add	x0, x21, #0x60
    79dc:	8b010b61 	add	x1, x27, x1, lsl #2
    79e0:	8b19073b 	add	x27, x25, x25, lsl #1
    79e4:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    79e8:	8b010f81 	add	x1, x28, x1, lsl #3
    79ec:	f9006c02 	str	x2, [x0, #216]
    79f0:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    79f4:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    79f8:	91328000 	add	x0, x0, #0xca0
    79fc:	ad000020 	stp	q0, q0, [x1]
    7a00:	ad010020 	stp	q0, q0, [x1, #32]
    7a04:	ad020020 	stp	q0, q0, [x1, #64]
    7a08:	f900303f 	str	xzr, [x1, #96]
    7a0c:	f900337f 	str	xzr, [x27, #96]
    7a10:	97ffebe4 	bl	29a0 <getenv@plt>
    7a14:	b50030e0 	cbnz	x0, 8030 <f12+0x850>
    7a18:	910182a0 	add	x0, x21, #0x60
    7a1c:	f9408c01 	ldr	x1, [x0, #280]
    7a20:	b5006421 	cbnz	x1, 86a4 <f12+0xec4>
    7a24:	910182a2 	add	x2, x21, #0x60
    7a28:	2f000400 	mvni	v0.2s, #0x0
    7a2c:	b9400363 	ldr	w3, [x27]
    7a30:	52800024 	mov	w4, #0x1                   	// #1
    7a34:	91000720 	add	x0, x25, #0x1
    7a38:	a900eb7a 	stp	x26, x26, [x27, #8]
    7a3c:	0b040063 	add	w3, w3, w4
    7a40:	f941c841 	ldr	x1, [x2, #912]
    7a44:	29001363 	stp	w3, w4, [x27]
    7a48:	f9002b7f 	str	xzr, [x27, #80]
    7a4c:	f900b040 	str	x0, [x2, #352]
    7a50:	fd002f60 	str	d0, [x27, #88]
    7a54:	b40071c1 	cbz	x1, 888c <f12+0x10ac>
    7a58:	91128273 	add	x19, x19, #0x4a0
    7a5c:	14000003 	b	7a68 <f12+0x288>
    7a60:	f9400021 	ldr	x1, [x1]
    7a64:	b4007141 	cbz	x1, 888c <f12+0x10ac>
    7a68:	f9400422 	ldr	x2, [x1, #8]
    7a6c:	eb13005f 	cmp	x2, x19
    7a70:	54ffff81 	b.ne	7a60 <f12+0x280>  // b.any
    7a74:	f9400821 	ldr	x1, [x1, #16]
    7a78:	2a1903e4 	mov	w4, w25
    7a7c:	b9400022 	ldr	w2, [x1]
    7a80:	f9002b61 	str	x1, [x27, #80]
    7a84:	b9005f62 	str	w2, [x27, #92]
    7a88:	37f80082 	tbnz	w2, #31, 7a98 <f12+0x2b8>
    7a8c:	52800d05 	mov	w5, #0x68                  	// #104
    7a90:	9b257042 	smaddl	x2, w2, w5, x28
    7a94:	b9005859 	str	w25, [x2, #88]
    7a98:	b9000024 	str	w4, [x1]
    7a9c:	d3707c79 	ubfiz	x25, x3, #16, #32
    7aa0:	aa000339 	orr	x25, x25, x0
    7aa4:	d2800002 	mov	x2, #0x0                   	// #0
    7aa8:	aa1403e0 	mov	x0, x20
    7aac:	b4005a74 	cbz	x20, 85f8 <f12+0xe18>
    7ab0:	f9400800 	ldr	x0, [x0, #16]
    7ab4:	91000442 	add	x2, x2, #0x1
    7ab8:	b5ffffc0 	cbnz	x0, 7ab0 <f12+0x2d0>
    7abc:	aa1403e1 	mov	x1, x20
    7ac0:	f9400821 	ldr	x1, [x1, #16]
    7ac4:	91000400 	add	x0, x0, #0x1
    7ac8:	b5ffffc1 	cbnz	x1, 7ac0 <f12+0x2e0>
    7acc:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7ad0:	eb01001f 	cmp	x0, x1
    7ad4:	54006ca8 	b.hi	8868 <f12+0x1088>  // b.pmore
    7ad8:	f100005f 	cmp	x2, #0x0
    7adc:	540058ed 	b.le	85f8 <f12+0xe18>
    7ae0:	eb00005f 	cmp	x2, x0
    7ae4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7ae8:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7aec:	eb01027f 	cmp	x19, x1
    7af0:	54006bc8 	b.hi	8868 <f12+0x1088>  // b.pmore
    7af4:	d37ffa7a 	lsl	x26, x19, #1
    7af8:	52800041 	mov	w1, #0x2                   	// #2
    7afc:	91000740 	add	x0, x26, #0x1
    7b00:	d37df000 	lsl	x0, x0, #3
    7b04:	97fff563 	bl	5090 <fwp_heap_alloc>
    7b08:	aa0003fb 	mov	x27, x0
    7b0c:	911902e1 	add	x1, x23, #0x640
    7b10:	aa0103e0 	mov	x0, x1
    7b14:	f900037a 	str	x26, [x27]
    7b18:	f949d821 	ldr	x1, [x1, #5040]
    7b1c:	f949ec00 	ldr	x0, [x0, #5080]
    7b20:	cb010361 	sub	x1, x27, x1
    7b24:	eb00403f 	cmp	x1, x0, lsl #16
    7b28:	54005882 	b.cs	8638 <f12+0xe58>  // b.hs, b.nlast
    7b2c:	911902e2 	add	x2, x23, #0x640
    7b30:	d350fc20 	lsr	x0, x1, #16
    7b34:	8b000800 	add	x0, x0, x0, lsl #2
    7b38:	f949fc43 	ldr	x3, [x2, #5112]
    7b3c:	d37df002 	lsl	x2, x0, #3
    7b40:	8b020060 	add	x0, x3, x2
    7b44:	f940101a 	ldr	x26, [x0, #32]
    7b48:	b400025a 	cbz	x26, 7b90 <f12+0x3b0>
    7b4c:	38626862 	ldrb	w2, [x3, x2]
    7b50:	7100085f 	cmp	w2, #0x2
    7b54:	540058a0 	b.eq	8668 <f12+0xe88>  // b.none
    7b58:	7100045f 	cmp	w2, #0x1
    7b5c:	540001a1 	b.ne	7b90 <f12+0x3b0>  // b.any
    7b60:	29430002 	ldp	w2, w0, [x0, #24]
    7b64:	92403c21 	and	x1, x1, #0xffff
    7b68:	9b027c21 	mul	x1, x1, x2
    7b6c:	d360fc21 	lsr	x1, x1, #32
    7b70:	eb00003f 	cmp	x1, x0
    7b74:	540000e2 	b.cs	7b90 <f12+0x3b0>  // b.hs, b.nlast
    7b78:	8b01035a 	add	x26, x26, x1
    7b7c:	39400340 	ldrb	w0, [x26]
    7b80:	7103fc1f 	cmp	w0, #0xff
    7b84:	540063a0 	b.eq	87f8 <f12+0x1018>  // b.none
    7b88:	52800020 	mov	w0, #0x1                   	// #1
    7b8c:	39000340 	strb	w0, [x26]
    7b90:	b4000233 	cbz	x19, 7bd4 <f12+0x3f4>
    7b94:	d3607f24 	lsl	x4, x25, #32
    7b98:	aa1403e0 	mov	x0, x20
    7b9c:	f9400685 	ldr	x5, [x20, #8]
    7ba0:	aa0403e3 	mov	x3, x4
    7ba4:	91002362 	add	x2, x27, #0x8
    7ba8:	d2800001 	mov	x1, #0x0                   	// #0
    7bac:	14000005 	b	7bc0 <f12+0x3e0>
    7bb0:	f9400405 	ldr	x5, [x0, #8]
    7bb4:	ab040023 	adds	x3, x1, x4
    7bb8:	91004042 	add	x2, x2, #0x10
    7bbc:	54006846 	b.vs	88c4 <f12+0x10e4>
    7bc0:	a9000c45 	stp	x5, x3, [x2]
    7bc4:	91000421 	add	x1, x1, #0x1
    7bc8:	f9400800 	ldr	x0, [x0, #16]
    7bcc:	eb01027f 	cmp	x19, x1
    7bd0:	54ffff08 	b.hi	7bb0 <f12+0x3d0>  // b.pmore
    7bd4:	f9400360 	ldr	x0, [x27]
    7bd8:	f100041f 	cmp	x0, #0x1
    7bdc:	54005329 	b.ls	8640 <f12+0xe60>  // b.plast
    7be0:	d341fc00 	lsr	x0, x0, #1
    7be4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7be8:	d100041a 	sub	x26, x0, #0x1
    7bec:	eb01035f 	cmp	x26, x1
    7bf0:	540063c8 	b.hi	8868 <f12+0x1088>  // b.pmore
    7bf4:	b400527a 	cbz	x26, 8640 <f12+0xe60>
    7bf8:	d1002361 	sub	x1, x27, #0x8
    7bfc:	91002373 	add	x19, x27, #0x8
    7c00:	8b00103c 	add	x28, x1, x0, lsl #4
    7c04:	d503201f 	nop
    7c08:	f9400660 	ldr	x0, [x19, #8]
    7c0c:	f9400e61 	ldr	x1, [x19, #24]
    7c10:	fd400260 	ldr	d0, [x19]
    7c14:	fd400a61 	ldr	d1, [x19, #16]
    7c18:	97fff6ba 	bl	5700 <w107>
    7c1c:	a9000660 	stp	x0, x1, [x19]
    7c20:	91004273 	add	x19, x19, #0x10
    7c24:	eb1c027f 	cmp	x19, x28
    7c28:	54ffff01 	b.ne	7c08 <f12+0x428>  // b.any
    7c2c:	aa1b03fc 	mov	x28, x27
    7c30:	d37ffb53 	lsl	x19, x26, #1
    7c34:	d2800016 	mov	x22, #0x0                   	// #0
    7c38:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    7c3c:	f8010793 	str	x19, [x28], #16
    7c40:	f8767b82 	ldr	x2, [x28, x22, lsl #3]
    7c44:	aa1a03e0 	mov	x0, x26
    7c48:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    7c4c:	91000ad6 	add	x22, x22, #0x2
    7c50:	aa0303e1 	mov	x1, x3
    7c54:	97fff5f8 	bl	5434 <fwp_p_ad_push>
    7c58:	aa0003fa 	mov	x26, x0
    7c5c:	eb1302df 	cmp	x22, x19
    7c60:	54ffff03 	b.cc	7c40 <f12+0x460>  // b.lo, b.ul, b.last
    7c64:	aa1b03e0 	mov	x0, x27
    7c68:	93407f33 	sxtw	x19, w25
    7c6c:	97fffb61 	bl	69f0 <fwp_drop4>
    7c70:	aa1303e0 	mov	x0, x19
    7c74:	97ffef8f 	bl	3ab0 <fwp_tape_of>
    7c78:	f9403001 	ldr	x1, [x0, #96]
    7c7c:	aa0003ea 	mov	x10, x0
    7c80:	b5006121 	cbnz	x1, 88a4 <f12+0x10c4>
    7c84:	97ffecc4 	bl	2f94 <fwp_tape_unlink_scope>
    7c88:	b9400002 	ldr	w2, [x0]
    7c8c:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    7c90:	a940801c 	ldp	x28, x0, [x0, #8]
    7c94:	b900055f 	str	wzr, [x10, #4]
    7c98:	a941994b 	ldp	x11, x6, [x10, #24]
    7c9c:	a942a147 	ldp	x7, x8, [x10, #40]
    7ca0:	a9439549 	ldp	x9, x5, [x10, #56]
    7ca4:	f940255b 	ldr	x27, [x10, #72]
    7ca8:	6b01005f 	cmp	w2, w1
    7cac:	54000108 	b.hi	7ccc <f12+0x4ec>  // b.pmore
    7cb0:	910182a2 	add	x2, x21, #0x60
    7cb4:	92403e61 	and	x1, x19, #0xffff
    7cb8:	d1000421 	sub	x1, x1, #0x1
    7cbc:	f940b043 	ldr	x3, [x2, #352]
    7cc0:	eb03003f 	cmp	x1, x3
    7cc4:	5400004a 	b.ge	7ccc <f12+0x4ec>  // b.tcont
    7cc8:	f900b041 	str	x1, [x2, #352]
    7ccc:	4f000400 	movi	v0.4s, #0x0
    7cd0:	910182a3 	add	x3, x21, #0x60
    7cd4:	f9000d5f 	str	xzr, [x10, #24]
    7cd8:	910163e1 	add	x1, sp, #0x58
    7cdc:	9101c3f9 	add	x25, sp, #0x70
    7ce0:	b0ffffe2 	adrp	x2, 4000 <fwp_heap_report+0xe0>
    7ce4:	f941c86c 	ldr	x12, [x3, #912]
    7ce8:	3c808140 	stur	q0, [x10, #8]
    7cec:	91129042 	add	x2, x2, #0x4a4
    7cf0:	ad010140 	stp	q0, q0, [x10, #32]
    7cf4:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    7cf8:	a9058bec 	stp	x12, x2, [sp, #88]
    7cfc:	a9069bf9 	stp	x25, x6, [sp, #104]
    7d00:	a907a3e7 	stp	x7, x8, [sp, #120]
    7d04:	a90897e9 	stp	x9, x5, [sp, #136]
    7d08:	a909efeb 	stp	x11, x27, [sp, #152]
    7d0c:	f901c861 	str	x1, [x3, #912]
    7d10:	b7f84c1a 	tbnz	x26, #63, 8690 <f12+0xeb0>
    7d14:	eb9a827f 	cmp	x19, x26, asr #32
    7d18:	54005961 	b.ne	8844 <f12+0x1064>  // b.any
    7d1c:	92407f53 	and	x19, x26, #0xffffffff
    7d20:	eb3a401f 	cmp	x0, w26, uxtw
    7d24:	5400596d 	b.le	8850 <f12+0x1070>
    7d28:	eb1c027f 	cmp	x19, x28
    7d2c:	9a93b793 	csinc	x19, x28, x19, lt	// lt = tstop
    7d30:	eb13037f 	cmp	x27, x19
    7d34:	540019ea 	b.ge	8070 <f12+0x890>  // b.tcont
    7d38:	f100037f 	cmp	x27, #0x0
    7d3c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7d40:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    7d44:	14000004 	b	7d54 <f12+0x574>
    7d48:	eb01037f 	cmp	x27, x1
    7d4c:	d37ffb7b 	lsl	x27, x27, #1
    7d50:	9a93d37b 	csel	x27, x27, x19, le
    7d54:	eb13037f 	cmp	x27, x19
    7d58:	54ffff8b 	b.lt	7d48 <f12+0x568>  // b.tstop
    7d5c:	b4004e25 	cbz	x5, 8720 <f12+0xf40>
    7d60:	aa0503e0 	mov	x0, x5
    7d64:	d37df361 	lsl	x1, x27, #3
    7d68:	52800062 	mov	w2, #0x3                   	// #3
    7d6c:	a9009fe6 	stp	x6, x7, [sp, #8]
    7d70:	a901a7e8 	stp	x8, x9, [sp, #24]
    7d74:	97fff198 	bl	43d4 <ad_raw_realloc>
    7d78:	aa0003e5 	mov	x5, x0
    7d7c:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7d80:	a941a7e8 	ldp	x8, x9, [sp, #24]
    7d84:	b4004b40 	cbz	x0, 86ec <f12+0xf0c>
    7d88:	f9004be5 	str	x5, [sp, #144]
    7d8c:	f90053fb 	str	x27, [sp, #160]
    7d90:	b50015d3 	cbnz	x19, 8048 <f12+0x868>
    7d94:	b7f800da 	tbnz	x26, #63, 7dac <f12+0x5cc>
    7d98:	92407f40 	and	x0, x26, #0xffffffff
    7d9c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7da0:	fc6078a0 	ldr	d0, [x5, x0, lsl #3]
    7da4:	1e612800 	fadd	d0, d0, d1
    7da8:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    7dac:	d1000673 	sub	x19, x19, #0x1
    7db0:	d1000783 	sub	x3, x28, #0x1
    7db4:	eb13039f 	cmp	x28, x19
    7db8:	540003ac 	b.gt	7e2c <f12+0x64c>
    7dbc:	fc7378a0 	ldr	d0, [x5, x19, lsl #3]
    7dc0:	1e602008 	fcmp	d0, #0.0
    7dc4:	540002e0 	b.eq	7e20 <f12+0x640>  // b.none
    7dc8:	cb1c0be0 	neg	x0, x28, lsl #2
    7dcc:	cb1c03e2 	neg	x2, x28
    7dd0:	8b0000c1 	add	x1, x6, x0
    7dd4:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    7dd8:	37f80101 	tbnz	w1, #31, 7df8 <f12+0x618>
    7ddc:	8b020d0a 	add	x10, x8, x2, lsl #3
    7de0:	93407c21 	sxtw	x1, w1
    7de4:	fc737942 	ldr	d2, [x10, x19, lsl #3]
    7de8:	fc6178a1 	ldr	d1, [x5, x1, lsl #3]
    7dec:	1e620802 	fmul	d2, d0, d2
    7df0:	1e622821 	fadd	d1, d1, d2
    7df4:	fc2178a1 	str	d1, [x5, x1, lsl #3]
    7df8:	8b0000e0 	add	x0, x7, x0
    7dfc:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    7e00:	37f80100 	tbnz	w0, #31, 7e20 <f12+0x640>
    7e04:	8b020d22 	add	x2, x9, x2, lsl #3
    7e08:	93407c00 	sxtw	x0, w0
    7e0c:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    7e10:	fc6078a1 	ldr	d1, [x5, x0, lsl #3]
    7e14:	1e620800 	fmul	d0, d0, d2
    7e18:	1e602820 	fadd	d0, d1, d0
    7e1c:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    7e20:	d1000673 	sub	x19, x19, #0x1
    7e24:	eb13007f 	cmp	x3, x19
    7e28:	54fffca1 	b.ne	7dbc <f12+0x5dc>  // b.any
    7e2c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7e30:	eb00039f 	cmp	x28, x0
    7e34:	54005208 	b.hi	8874 <f12+0x1094>  // b.pmore
    7e38:	91000780 	add	x0, x28, #0x1
    7e3c:	52800041 	mov	w1, #0x2                   	// #2
    7e40:	f90007e5 	str	x5, [sp, #8]
    7e44:	d37df000 	lsl	x0, x0, #3
    7e48:	97fff492 	bl	5090 <fwp_heap_alloc>
    7e4c:	aa0003e2 	mov	x2, x0
    7e50:	aa0003f3 	mov	x19, x0
    7e54:	f94007e5 	ldr	x5, [sp, #8]
    7e58:	d2800001 	mov	x1, #0x0                   	// #0
    7e5c:	f800845c 	str	x28, [x2], #8
    7e60:	b40000fc 	cbz	x28, 7e7c <f12+0x69c>
    7e64:	d503201f 	nop
    7e68:	f86178a0 	ldr	x0, [x5, x1, lsl #3]
    7e6c:	f8217840 	str	x0, [x2, x1, lsl #3]
    7e70:	91000421 	add	x1, x1, #0x1
    7e74:	eb01039f 	cmp	x28, x1
    7e78:	54ffff81 	b.ne	7e68 <f12+0x688>  // b.any
    7e7c:	910182a1 	add	x1, x21, #0x60
    7e80:	aa1903e0 	mov	x0, x25
    7e84:	f9402ffa 	ldr	x26, [sp, #88]
    7e88:	f901c83a 	str	x26, [x1, #912]
    7e8c:	97fff186 	bl	44a4 <fwp_tape_buffers_release>
    7e90:	911902e2 	add	x2, x23, #0x640
    7e94:	f949d841 	ldr	x1, [x2, #5040]
    7e98:	f949ec40 	ldr	x0, [x2, #5080]
    7e9c:	cb010261 	sub	x1, x19, x1
    7ea0:	eb00403f 	cmp	x1, x0, lsl #16
    7ea4:	54000322 	b.cs	7f08 <f12+0x728>  // b.hs, b.nlast
    7ea8:	d350fc20 	lsr	x0, x1, #16
    7eac:	f949fc43 	ldr	x3, [x2, #5112]
    7eb0:	8b000800 	add	x0, x0, x0, lsl #2
    7eb4:	d37df002 	lsl	x2, x0, #3
    7eb8:	8b020060 	add	x0, x3, x2
    7ebc:	f9401019 	ldr	x25, [x0, #32]
    7ec0:	b4000259 	cbz	x25, 7f08 <f12+0x728>
    7ec4:	38626862 	ldrb	w2, [x3, x2]
    7ec8:	7100085f 	cmp	w2, #0x2
    7ecc:	54003e60 	b.eq	8698 <f12+0xeb8>  // b.none
    7ed0:	7100045f 	cmp	w2, #0x1
    7ed4:	540001a1 	b.ne	7f08 <f12+0x728>  // b.any
    7ed8:	29430002 	ldp	w2, w0, [x0, #24]
    7edc:	92403c21 	and	x1, x1, #0xffff
    7ee0:	9b027c21 	mul	x1, x1, x2
    7ee4:	d360fc21 	lsr	x1, x1, #32
    7ee8:	eb00003f 	cmp	x1, x0
    7eec:	540000e2 	b.cs	7f08 <f12+0x728>  // b.hs, b.nlast
    7ef0:	8b010339 	add	x25, x25, x1
    7ef4:	39400320 	ldrb	w0, [x25]
    7ef8:	7103fc1f 	cmp	w0, #0xff
    7efc:	54004840 	b.eq	8804 <f12+0x1024>  // b.none
    7f00:	52800020 	mov	w0, #0x1                   	// #1
    7f04:	39000320 	strb	w0, [x25]
    7f08:	eb18035f 	cmp	x26, x24
    7f0c:	54004da1 	b.ne	88c0 <f12+0x10e0>  // b.any
    7f10:	f94003e0 	ldr	x0, [sp]
    7f14:	910182b5 	add	x21, x21, #0x60
    7f18:	f94023e1 	ldr	x1, [sp, #64]
    7f1c:	f901caa1 	str	x1, [x21, #912]
    7f20:	97fff960 	bl	64a0 <fwp_tape_scope_release>
    7f24:	f9400260 	ldr	x0, [x19]
    7f28:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    7f2c:	b7f83120 	tbnz	x0, #63, 8550 <f12+0xd70>
    7f30:	911902e2 	add	x2, x23, #0x640
    7f34:	f949d840 	ldr	x0, [x2, #5040]
    7f38:	f949ec41 	ldr	x1, [x2, #5080]
    7f3c:	cb000260 	sub	x0, x19, x0
    7f40:	eb01401f 	cmp	x0, x1, lsl #16
    7f44:	54003062 	b.cs	8550 <f12+0xd70>  // b.hs, b.nlast
    7f48:	d350fc01 	lsr	x1, x0, #16
    7f4c:	f949fc44 	ldr	x4, [x2, #5112]
    7f50:	8b010821 	add	x1, x1, x1, lsl #2
    7f54:	d37df021 	lsl	x1, x1, #3
    7f58:	8b010083 	add	x3, x4, x1
    7f5c:	f9401062 	ldr	x2, [x3, #32]
    7f60:	b4002f82 	cbz	x2, 8550 <f12+0xd70>
    7f64:	38616881 	ldrb	w1, [x4, x1]
    7f68:	7100083f 	cmp	w1, #0x2
    7f6c:	54002ec0 	b.eq	8544 <f12+0xd64>  // b.none
    7f70:	7100043f 	cmp	w1, #0x1
    7f74:	54002ee1 	b.ne	8550 <f12+0xd70>  // b.any
    7f78:	29430464 	ldp	w4, w1, [x3, #24]
    7f7c:	92403c00 	and	x0, x0, #0xffff
    7f80:	9b047c00 	mul	x0, x0, x4
    7f84:	d360fc00 	lsr	x0, x0, #32
    7f88:	eb01001f 	cmp	x0, x1
    7f8c:	54002e22 	b.cs	8550 <f12+0xd70>  // b.hs, b.nlast
    7f90:	8b000042 	add	x2, x2, x0
    7f94:	39400040 	ldrb	w0, [x2]
    7f98:	7100041f 	cmp	w0, #0x1
    7f9c:	54002da1 	b.ne	8550 <f12+0xd70>  // b.any
    7fa0:	aa1303f5 	mov	x21, x19
    7fa4:	d2800000 	mov	x0, #0x0                   	// #0
    7fa8:	f90003f3 	str	x19, [sp]
    7fac:	f94003e1 	ldr	x1, [sp]
    7fb0:	91002023 	add	x3, x1, #0x8
    7fb4:	d2800001 	mov	x1, #0x0                   	// #0
    7fb8:	b4000898 	cbz	x24, 80c8 <f12+0x8e8>
    7fbc:	f0000022 	adrp	x2, e000 <_IO_stdin_used+0x760>
    7fc0:	91002265 	add	x5, x19, #0x8
    7fc4:	fd443841 	ldr	d1, [x2, #2160]
    7fc8:	14000009 	b	7fec <f12+0x80c>
    7fcc:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7fd0:	f94002a2 	ldr	x2, [x21]
    7fd4:	1e600820 	fmul	d0, d1, d0
    7fd8:	b7f84422 	tbnz	x2, #63, 885c <f12+0x107c>
    7fdc:	91000421 	add	x1, x1, #0x1
    7fe0:	fc008460 	str	d0, [x3], #8
    7fe4:	eb01031f 	cmp	x24, x1
    7fe8:	54000700 	b.eq	80c8 <f12+0x8e8>  // b.none
    7fec:	f9400264 	ldr	x4, [x19]
    7ff0:	aa0503e2 	mov	x2, x5
    7ff4:	b6fffec4 	tbz	x4, #63, 7fcc <f12+0x7ec>
    7ff8:	f9400a62 	ldr	x2, [x19, #16]
    7ffc:	17fffff4 	b	7fcc <f12+0x7ec>
    8000:	eb1b033f 	cmp	x25, x27
    8004:	54ffcb40 	b.eq	796c <f12+0x18c>  // b.none
    8008:	910182a0 	add	x0, x21, #0x60
    800c:	8b19073b 	add	x27, x25, x25, lsl #1
    8010:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    8014:	f940441c 	ldr	x28, [x0, #136]
    8018:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    801c:	91328000 	add	x0, x0, #0xca0
    8020:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    8024:	f900337f 	str	xzr, [x27, #96]
    8028:	97ffea5e 	bl	29a0 <getenv@plt>
    802c:	b4ffcf60 	cbz	x0, 7a18 <f12+0x238>
    8030:	39400001 	ldrb	w1, [x0]
    8034:	7100c03f 	cmp	w1, #0x30
    8038:	54ffcf01 	b.ne	7a18 <f12+0x238>  // b.any
    803c:	39400400 	ldrb	w0, [x0, #1]
    8040:	34ffcf20 	cbz	w0, 7a24 <f12+0x244>
    8044:	17fffe75 	b	7a18 <f12+0x238>
    8048:	aa0503e0 	mov	x0, x5
    804c:	d37df262 	lsl	x2, x19, #3
    8050:	52800001 	mov	w1, #0x0                   	// #0
    8054:	a9009fe6 	stp	x6, x7, [sp, #8]
    8058:	a901a7e8 	stp	x8, x9, [sp, #24]
    805c:	97ffe9e1 	bl	27e0 <memset@plt>
    8060:	aa0003e5 	mov	x5, x0
    8064:	a9409fe6 	ldp	x6, x7, [sp, #8]
    8068:	a941a7e8 	ldp	x8, x9, [sp, #24]
    806c:	17ffff4a 	b	7d94 <f12+0x5b4>
    8070:	f10000bf 	cmp	x5, #0x0
    8074:	1a9f17e0 	cset	w0, eq	// eq = none
    8078:	f100027f 	cmp	x19, #0x0
    807c:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8080:	54ffe880 	b.eq	7d90 <f12+0x5b0>  // b.none
    8084:	f9402fe1 	ldr	x1, [sp, #88]
    8088:	910182b5 	add	x21, x21, #0x60
    808c:	aa1903e0 	mov	x0, x25
    8090:	f901caa1 	str	x1, [x21, #912]
    8094:	97fff104 	bl	44a4 <fwp_tape_buffers_release>
    8098:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    809c:	f947e863 	ldr	x3, [x3, #4048]
    80a0:	d2800262 	mov	x2, #0x13                  	// #19
    80a4:	d2800021 	mov	x1, #0x1                   	// #1
    80a8:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    80ac:	9122a000 	add	x0, x0, #0x8a8
    80b0:	f9400063 	ldr	x3, [x3]
    80b4:	97ffea17 	bl	2910 <fwrite@plt>
    80b8:	d2800000 	mov	x0, #0x0                   	// #0
    80bc:	97ffea21 	bl	2940 <fflush@plt>
    80c0:	52800cc0 	mov	w0, #0x66                  	// #102
    80c4:	97ffea2f 	bl	2980 <_Exit@plt>
    80c8:	97fffa4a 	bl	69f0 <fwp_drop4>
    80cc:	aa1403e1 	mov	x1, x20
    80d0:	d2800002 	mov	x2, #0x0                   	// #0
    80d4:	b4003774 	cbz	x20, 87c0 <f12+0xfe0>
    80d8:	f9400821 	ldr	x1, [x1, #16]
    80dc:	91000442 	add	x2, x2, #0x1
    80e0:	b5ffffc1 	cbnz	x1, 80d8 <f12+0x8f8>
    80e4:	f94002a3 	ldr	x3, [x21]
    80e8:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    80ec:	b7f81f43 	tbnz	x3, #63, 84d4 <f12+0xcf4>
    80f0:	911902e1 	add	x1, x23, #0x640
    80f4:	f94003e4 	ldr	x4, [sp]
    80f8:	f949d820 	ldr	x0, [x1, #5040]
    80fc:	f949ec21 	ldr	x1, [x1, #5080]
    8100:	cb000080 	sub	x0, x4, x0
    8104:	eb01401f 	cmp	x0, x1, lsl #16
    8108:	54001e62 	b.cs	84d4 <f12+0xcf4>  // b.hs, b.nlast
    810c:	911902e4 	add	x4, x23, #0x640
    8110:	d350fc01 	lsr	x1, x0, #16
    8114:	8b010821 	add	x1, x1, x1, lsl #2
    8118:	f949fc86 	ldr	x6, [x4, #5112]
    811c:	d37df021 	lsl	x1, x1, #3
    8120:	8b0100c5 	add	x5, x6, x1
    8124:	f94010a4 	ldr	x4, [x5, #32]
    8128:	b4001d44 	cbz	x4, 84d0 <f12+0xcf0>
    812c:	386168c1 	ldrb	w1, [x6, x1]
    8130:	7100083f 	cmp	w1, #0x2
    8134:	54001ca0 	b.eq	84c8 <f12+0xce8>  // b.none
    8138:	7100043f 	cmp	w1, #0x1
    813c:	54001ca1 	b.ne	84d0 <f12+0xcf0>  // b.any
    8140:	294304a6 	ldp	w6, w1, [x5, #24]
    8144:	92403c00 	and	x0, x0, #0xffff
    8148:	9b067c00 	mul	x0, x0, x6
    814c:	d360fc00 	lsr	x0, x0, #32
    8150:	eb01001f 	cmp	x0, x1
    8154:	54001be2 	b.cs	84d0 <f12+0xcf0>  // b.hs, b.nlast
    8158:	8b000084 	add	x4, x4, x0
    815c:	39400098 	ldrb	w24, [x4]
    8160:	7100071f 	cmp	w24, #0x1
    8164:	54001b61 	b.ne	84d0 <f12+0xcf0>  // b.any
    8168:	b9000bf8 	str	w24, [sp, #8]
    816c:	eb02039f 	cmp	x28, x2
    8170:	9a82939c 	csel	x28, x28, x2, ls	// ls = plast
    8174:	910022b9 	add	x25, x21, #0x8
    8178:	b400361c 	cbz	x28, 8838 <f12+0x1058>
    817c:	f94003e0 	ldr	x0, [sp]
    8180:	d37df385 	lsl	x5, x28, #3
    8184:	aa1403e2 	mov	x2, x20
    8188:	d2800001 	mov	x1, #0x0                   	// #0
    818c:	91002000 	add	x0, x0, #0x8
    8190:	1400000a 	b	81b8 <f12+0x9d8>
    8194:	fc616881 	ldr	d1, [x4, x1]
    8198:	fd400440 	ldr	d0, [x2, #8]
    819c:	1e613800 	fsub	d0, d0, d1
    81a0:	fc216b20 	str	d0, [x25, x1]
    81a4:	91002021 	add	x1, x1, #0x8
    81a8:	f9400842 	ldr	x2, [x2, #16]
    81ac:	eb05003f 	cmp	x1, x5
    81b0:	540001c0 	b.eq	81e8 <f12+0xa08>  // b.none
    81b4:	f94002a3 	ldr	x3, [x21]
    81b8:	aa0003e4 	mov	x4, x0
    81bc:	b6fffec3 	tbz	x3, #63, 8194 <f12+0x9b4>
    81c0:	f94003e3 	ldr	x3, [sp]
    81c4:	fd400440 	ldr	d0, [x2, #8]
    81c8:	f9400864 	ldr	x4, [x3, #16]
    81cc:	fc616881 	ldr	d1, [x4, x1]
    81d0:	1e613800 	fsub	d0, d0, d1
    81d4:	fc216b20 	str	d0, [x25, x1]
    81d8:	91002021 	add	x1, x1, #0x8
    81dc:	f9400842 	ldr	x2, [x2, #16]
    81e0:	eb05003f 	cmp	x1, x5
    81e4:	54fffe81 	b.ne	81b4 <f12+0x9d4>  // b.any
    81e8:	b4003254 	cbz	x20, 8830 <f12+0x1050>
    81ec:	911902e0 	add	x0, x23, #0x640
    81f0:	aa1403e2 	mov	x2, x20
    81f4:	d280001a 	mov	x26, #0x0                   	// #0
    81f8:	f949ec06 	ldr	x6, [x0, #5080]
    81fc:	f949d807 	ldr	x7, [x0, #5040]
    8200:	f949fc05 	ldr	x5, [x0, #5112]
    8204:	d370bcc6 	lsl	x6, x6, #16
    8208:	14000006 	b	8220 <f12+0xa40>
    820c:	f9400842 	ldr	x2, [x2, #16]
    8210:	9100075a 	add	x26, x26, #0x1
    8214:	f100005f 	cmp	x2, #0x0
    8218:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    821c:	54000329 	b.ls	8280 <f12+0xaa0>  // b.plast
    8220:	cb070040 	sub	x0, x2, x7
    8224:	eb06001f 	cmp	x0, x6
    8228:	540002c2 	b.cs	8280 <f12+0xaa0>  // b.hs, b.nlast
    822c:	d350fc01 	lsr	x1, x0, #16
    8230:	8b010821 	add	x1, x1, x1, lsl #2
    8234:	d37df021 	lsl	x1, x1, #3
    8238:	8b0100a4 	add	x4, x5, x1
    823c:	f9401083 	ldr	x3, [x4, #32]
    8240:	b4000203 	cbz	x3, 8280 <f12+0xaa0>
    8244:	386168a1 	ldrb	w1, [x5, x1]
    8248:	7100083f 	cmp	w1, #0x2
    824c:	54000de0 	b.eq	8408 <f12+0xc28>  // b.none
    8250:	7100043f 	cmp	w1, #0x1
    8254:	54000161 	b.ne	8280 <f12+0xaa0>  // b.any
    8258:	29430488 	ldp	w8, w1, [x4, #24]
    825c:	92403c00 	and	x0, x0, #0xffff
    8260:	9b087c00 	mul	x0, x0, x8
    8264:	d360fc00 	lsr	x0, x0, #32
    8268:	eb01001f 	cmp	x0, x1
    826c:	540000a2 	b.cs	8280 <f12+0xaa0>  // b.hs, b.nlast
    8270:	8b000063 	add	x3, x3, x0
    8274:	39400060 	ldrb	w0, [x3]
    8278:	7100041f 	cmp	w0, #0x1
    827c:	54fffc80 	b.eq	820c <f12+0xa2c>  // b.none
    8280:	eb1a039f 	cmp	x28, x26
    8284:	54000ca9 	b.ls	8418 <f12+0xc38>  // b.plast
    8288:	d1002336 	sub	x22, x25, #0x8
    828c:	9102a3f5 	add	x21, sp, #0xa8
    8290:	911902f8 	add	x24, x23, #0x640
    8294:	d2800013 	mov	x19, #0x0                   	// #0
    8298:	14000012 	b	82e0 <f12+0xb00>
    829c:	7100045f 	cmp	w2, #0x1
    82a0:	540001a1 	b.ne	82d4 <f12+0xaf4>  // b.any
    82a4:	29430002 	ldp	w2, w0, [x0, #24]
    82a8:	92403c21 	and	x1, x1, #0xffff
    82ac:	9b027c21 	mul	x1, x1, x2
    82b0:	d360fc21 	lsr	x1, x1, #32
    82b4:	eb00003f 	cmp	x1, x0
    82b8:	540000e2 	b.cs	82d4 <f12+0xaf4>  // b.hs, b.nlast
    82bc:	8b01037b 	add	x27, x27, x1
    82c0:	39400360 	ldrb	w0, [x27]
    82c4:	7103fc1f 	cmp	w0, #0xff
    82c8:	54001b20 	b.eq	862c <f12+0xe4c>  // b.none
    82cc:	52800020 	mov	w0, #0x1                   	// #1
    82d0:	39000360 	strb	w0, [x27]
    82d4:	d100079c 	sub	x28, x28, #0x1
    82d8:	eb1c035f 	cmp	x26, x28
    82dc:	54000362 	b.cs	8348 <f12+0xb68>  // b.hs, b.nlast
    82e0:	f87c7ac2 	ldr	x2, [x22, x28, lsl #3]
    82e4:	aa1503e1 	mov	x1, x21
    82e8:	52800020 	mov	w0, #0x1                   	// #1
    82ec:	a90acfe2 	stp	x2, x19, [sp, #168]
    82f0:	97fff548 	bl	5810 <fwp_data.part.0.constprop.0>
    82f4:	aa0003f3 	mov	x19, x0
    82f8:	f949db01 	ldr	x1, [x24, #5040]
    82fc:	f949ef00 	ldr	x0, [x24, #5080]
    8300:	cb010261 	sub	x1, x19, x1
    8304:	eb00403f 	cmp	x1, x0, lsl #16
    8308:	54fffe62 	b.cs	82d4 <f12+0xaf4>  // b.hs, b.nlast
    830c:	d350fc22 	lsr	x2, x1, #16
    8310:	f949ff03 	ldr	x3, [x24, #5112]
    8314:	8b020842 	add	x2, x2, x2, lsl #2
    8318:	d37df042 	lsl	x2, x2, #3
    831c:	8b020060 	add	x0, x3, x2
    8320:	f940101b 	ldr	x27, [x0, #32]
    8324:	b4fffd9b 	cbz	x27, 82d4 <f12+0xaf4>
    8328:	38626862 	ldrb	w2, [x3, x2]
    832c:	7100085f 	cmp	w2, #0x2
    8330:	54fffb61 	b.ne	829c <f12+0xabc>  // b.any
    8334:	72003c3f 	tst	w1, #0xffff
    8338:	54fffc40 	b.eq	82c0 <f12+0xae0>  // b.none
    833c:	d100079c 	sub	x28, x28, #0x1
    8340:	eb1c035f 	cmp	x26, x28
    8344:	54fffce3 	b.cc	82e0 <f12+0xb00>  // b.lo, b.ul, b.last
    8348:	b50006ba 	cbnz	x26, 841c <f12+0xc3c>
    834c:	b9400be0 	ldr	w0, [sp, #8]
    8350:	d2800038 	mov	x24, #0x1                   	// #1
    8354:	d280001b 	mov	x27, #0x0                   	// #0
    8358:	7100001f 	cmp	w0, #0x0
    835c:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    8360:	b40007db 	cbz	x27, 8458 <f12+0xc78>
    8364:	d100077b 	sub	x27, x27, #0x1
    8368:	911902f7 	add	x23, x23, #0x640
    836c:	d503201f 	nop
    8370:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    8374:	aa1503e1 	mov	x1, x21
    8378:	52800020 	mov	w0, #0x1                   	// #1
    837c:	a90acfe2 	stp	x2, x19, [sp, #168]
    8380:	97fff524 	bl	5810 <fwp_data.part.0.constprop.0>
    8384:	aa0003f3 	mov	x19, x0
    8388:	f949dae1 	ldr	x1, [x23, #5040]
    838c:	f949eee0 	ldr	x0, [x23, #5080]
    8390:	cb010261 	sub	x1, x19, x1
    8394:	eb00403f 	cmp	x1, x0, lsl #16
    8398:	54000302 	b.cs	83f8 <f12+0xc18>  // b.hs, b.nlast
    839c:	d350fc22 	lsr	x2, x1, #16
    83a0:	f949fee3 	ldr	x3, [x23, #5112]
    83a4:	8b020842 	add	x2, x2, x2, lsl #2
    83a8:	d37df042 	lsl	x2, x2, #3
    83ac:	8b020060 	add	x0, x3, x2
    83b0:	f940101a 	ldr	x26, [x0, #32]
    83b4:	b400023a 	cbz	x26, 83f8 <f12+0xc18>
    83b8:	38626862 	ldrb	w2, [x3, x2]
    83bc:	7100085f 	cmp	w2, #0x2
    83c0:	540007e0 	b.eq	84bc <f12+0xcdc>  // b.none
    83c4:	7100045f 	cmp	w2, #0x1
    83c8:	54000181 	b.ne	83f8 <f12+0xc18>  // b.any
    83cc:	29430002 	ldp	w2, w0, [x0, #24]
    83d0:	92403c21 	and	x1, x1, #0xffff
    83d4:	9b027c21 	mul	x1, x1, x2
    83d8:	d360fc21 	lsr	x1, x1, #32
    83dc:	eb00003f 	cmp	x1, x0
    83e0:	540000c2 	b.cs	83f8 <f12+0xc18>  // b.hs, b.nlast
    83e4:	8b01035a 	add	x26, x26, x1
    83e8:	39400340 	ldrb	w0, [x26]
    83ec:	7103fc1f 	cmp	w0, #0xff
    83f0:	54000600 	b.eq	84b0 <f12+0xcd0>  // b.none
    83f4:	39000358 	strb	w24, [x26]
    83f8:	d100077b 	sub	x27, x27, #0x1
    83fc:	b100077f 	cmn	x27, #0x1
    8400:	54fffb81 	b.ne	8370 <f12+0xb90>  // b.any
    8404:	14000015 	b	8458 <f12+0xc78>
    8408:	72003c1f 	tst	w0, #0xffff
    840c:	54fff340 	b.eq	8274 <f12+0xa94>  // b.none
    8410:	eb1a039f 	cmp	x28, x26
    8414:	54fff3a8 	b.hi	8288 <f12+0xaa8>  // b.pmore
    8418:	d2800013 	mov	x19, #0x0                   	// #0
    841c:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    8420:	aa1903e1 	mov	x1, x25
    8424:	aa1403e0 	mov	x0, x20
    8428:	f8408422 	ldr	x2, [x1], #8
    842c:	f9000402 	str	x2, [x0, #8]
    8430:	aa0003e2 	mov	x2, x0
    8434:	f9400800 	ldr	x0, [x0, #16]
    8438:	eb1a003f 	cmp	x1, x26
    843c:	54ffff61 	b.ne	8428 <f12+0xc48>  // b.any
    8440:	b9400be1 	ldr	w1, [sp, #8]
    8444:	f9000853 	str	x19, [x2, #16]
    8448:	aa1403f3 	mov	x19, x20
    844c:	aa0003f4 	mov	x20, x0
    8450:	34000041 	cbz	w1, 8458 <f12+0xc78>
    8454:	d2800019 	mov	x25, #0x0                   	// #0
    8458:	aa1903e0 	mov	x0, x25
    845c:	97fff1ed 	bl	4c10 <fwp_mem_free>
    8460:	f94003e0 	ldr	x0, [sp]
    8464:	97fff963 	bl	69f0 <fwp_drop4>
    8468:	aa1403e0 	mov	x0, x20
    846c:	97fff6cd 	bl	5fa0 <fwp_drop0>
    8470:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8474:	f947f400 	ldr	x0, [x0, #4072]
    8478:	f9405fe2 	ldr	x2, [sp, #184]
    847c:	f9400001 	ldr	x1, [x0]
    8480:	eb010042 	subs	x2, x2, x1
    8484:	d2800001 	mov	x1, #0x0                   	// #0
    8488:	540021a1 	b.ne	88bc <f12+0x10dc>  // b.any
    848c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    8490:	aa1303e0 	mov	x0, x19
    8494:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8498:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    849c:	a94f63f7 	ldp	x23, x24, [sp, #240]
    84a0:	a9506bf9 	ldp	x25, x26, [sp, #256]
    84a4:	a95173fb 	ldp	x27, x28, [sp, #272]
    84a8:	910483ff 	add	sp, sp, #0x120
    84ac:	d65f03c0 	ret
    84b0:	aa1a03e0 	mov	x0, x26
    84b4:	97fff137 	bl	4990 <fwp_rc_forget_slot>
    84b8:	17ffffcf 	b	83f4 <f12+0xc14>
    84bc:	72003c3f 	tst	w1, #0xffff
    84c0:	54fff9c1 	b.ne	83f8 <f12+0xc18>  // b.any
    84c4:	17ffffc9 	b	83e8 <f12+0xc08>
    84c8:	72003c1f 	tst	w0, #0xffff
    84cc:	54ffe480 	b.eq	815c <f12+0x97c>  // b.none
    84d0:	b4001154 	cbz	x20, 86f8 <f12+0xf18>
    84d4:	aa1403f3 	mov	x19, x20
    84d8:	d2800018 	mov	x24, #0x0                   	// #0
    84dc:	d503201f 	nop
    84e0:	f9400a73 	ldr	x19, [x19, #16]
    84e4:	aa1803e0 	mov	x0, x24
    84e8:	91000718 	add	x24, x24, #0x1
    84ec:	b5ffffb3 	cbnz	x19, 84e0 <f12+0xd00>
    84f0:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    84f4:	eb01031f 	cmp	x24, x1
    84f8:	54001b88 	b.hi	8868 <f12+0x1088>  // b.pmore
    84fc:	91000800 	add	x0, x0, #0x2
    8500:	52800041 	mov	w1, #0x2                   	// #2
    8504:	d37df000 	lsl	x0, x0, #3
    8508:	97fff2e2 	bl	5090 <fwp_heap_alloc>
    850c:	eb18039f 	cmp	x28, x24
    8510:	aa0003f9 	mov	x25, x0
    8514:	9a98939c 	csel	x28, x28, x24, ls	// ls = plast
    8518:	aa1403e1 	mov	x1, x20
    851c:	d503201f 	nop
    8520:	f9400420 	ldr	x0, [x1, #8]
    8524:	f8337b20 	str	x0, [x25, x19, lsl #3]
    8528:	91000673 	add	x19, x19, #0x1
    852c:	f9400821 	ldr	x1, [x1, #16]
    8530:	b5ffff81 	cbnz	x1, 8520 <f12+0xd40>
    8534:	b4000ebc 	cbz	x28, 8708 <f12+0xf28>
    8538:	f94002a3 	ldr	x3, [x21]
    853c:	b9000bff 	str	wzr, [sp, #8]
    8540:	17ffff0f 	b	817c <f12+0x99c>
    8544:	72003c1f 	tst	w0, #0xffff
    8548:	54ffd260 	b.eq	7f94 <f12+0x7b4>  // b.none
    854c:	d503201f 	nop
    8550:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8554:	eb00031f 	cmp	x24, x0
    8558:	540018e8 	b.hi	8874 <f12+0x1094>  // b.pmore
    855c:	91000700 	add	x0, x24, #0x1
    8560:	52800021 	mov	w1, #0x1                   	// #1
    8564:	d37df000 	lsl	x0, x0, #3
    8568:	97fff2ca 	bl	5090 <fwp_heap_alloc>
    856c:	911902e2 	add	x2, x23, #0x640
    8570:	f9000018 	str	x24, [x0]
    8574:	aa0003f5 	mov	x21, x0
    8578:	f90003f5 	str	x21, [sp]
    857c:	f949d841 	ldr	x1, [x2, #5040]
    8580:	f949ec40 	ldr	x0, [x2, #5080]
    8584:	cb0102a1 	sub	x1, x21, x1
    8588:	eb00403f 	cmp	x1, x0, lsl #16
    858c:	54000322 	b.cs	85f0 <f12+0xe10>  // b.hs, b.nlast
    8590:	d350fc20 	lsr	x0, x1, #16
    8594:	f949fc43 	ldr	x3, [x2, #5112]
    8598:	8b000800 	add	x0, x0, x0, lsl #2
    859c:	d37df002 	lsl	x2, x0, #3
    85a0:	8b020060 	add	x0, x3, x2
    85a4:	f9401019 	ldr	x25, [x0, #32]
    85a8:	b4000259 	cbz	x25, 85f0 <f12+0xe10>
    85ac:	38626862 	ldrb	w2, [x3, x2]
    85b0:	7100085f 	cmp	w2, #0x2
    85b4:	54000ae0 	b.eq	8710 <f12+0xf30>  // b.none
    85b8:	7100045f 	cmp	w2, #0x1
    85bc:	540001a1 	b.ne	85f0 <f12+0xe10>  // b.any
    85c0:	29430002 	ldp	w2, w0, [x0, #24]
    85c4:	92403c21 	and	x1, x1, #0xffff
    85c8:	9b027c21 	mul	x1, x1, x2
    85cc:	d360fc21 	lsr	x1, x1, #32
    85d0:	eb00003f 	cmp	x1, x0
    85d4:	540000e2 	b.cs	85f0 <f12+0xe10>  // b.hs, b.nlast
    85d8:	8b010339 	add	x25, x25, x1
    85dc:	39400320 	ldrb	w0, [x25]
    85e0:	7103fc1f 	cmp	w0, #0xff
    85e4:	54001160 	b.eq	8810 <f12+0x1030>  // b.none
    85e8:	52800020 	mov	w0, #0x1                   	// #1
    85ec:	39000320 	strb	w0, [x25]
    85f0:	aa1303e0 	mov	x0, x19
    85f4:	17fffe6e 	b	7fac <f12+0x7cc>
    85f8:	52800041 	mov	w1, #0x2                   	// #2
    85fc:	d2800100 	mov	x0, #0x8                   	// #8
    8600:	97fff2a4 	bl	5090 <fwp_heap_alloc>
    8604:	aa0003fb 	mov	x27, x0
    8608:	911902e0 	add	x0, x23, #0x640
    860c:	f900037f 	str	xzr, [x27]
    8610:	f949d801 	ldr	x1, [x0, #5040]
    8614:	f949ec00 	ldr	x0, [x0, #5080]
    8618:	cb010361 	sub	x1, x27, x1
    861c:	eb00403f 	cmp	x1, x0, lsl #16
    8620:	54000102 	b.cs	8640 <f12+0xe60>  // b.hs, b.nlast
    8624:	d2800013 	mov	x19, #0x0                   	// #0
    8628:	17fffd41 	b	7b2c <f12+0x34c>
    862c:	aa1b03e0 	mov	x0, x27
    8630:	97fff0d8 	bl	4990 <fwp_rc_forget_slot>
    8634:	17ffff26 	b	82cc <f12+0xaec>
    8638:	b5ffaaf3 	cbnz	x19, 7b94 <f12+0x3b4>
    863c:	d503201f 	nop
    8640:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    8644:	f900037f 	str	xzr, [x27]
    8648:	17fffd87 	b	7c64 <f12+0x484>
    864c:	d0ffffe0 	adrp	x0, 6000 <fwp_drop0+0x60>
    8650:	910e4000 	add	x0, x0, #0x390
    8654:	94001487 	bl	d870 <atexit>
    8658:	35ffd200 	cbnz	w0, 8098 <f12+0x8b8>
    865c:	52800020 	mov	w0, #0x1                   	// #1
    8660:	b903c720 	str	w0, [x25, #964]
    8664:	17fffcaf 	b	7920 <f12+0x140>
    8668:	72003c3f 	tst	w1, #0xffff
    866c:	54ffa921 	b.ne	7b90 <f12+0x3b0>  // b.any
    8670:	17fffd43 	b	7b7c <f12+0x39c>
    8674:	72003c3f 	tst	w1, #0xffff
    8678:	54ff9240 	b.eq	78c0 <f12+0xe0>  // b.none
    867c:	aa1903e0 	mov	x0, x25
    8680:	97fff6a4 	bl	6110 <fwp_closure_drop>
    8684:	b5ff9374 	cbnz	x20, 78f0 <f12+0x110>
    8688:	d280001a 	mov	x26, #0x0                   	// #0
    868c:	17fffca2 	b	7914 <f12+0x134>
    8690:	aa1c03f3 	mov	x19, x28
    8694:	17fffda7 	b	7d30 <f12+0x550>
    8698:	72003c3f 	tst	w1, #0xffff
    869c:	54ffc361 	b.ne	7f08 <f12+0x728>  // b.any
    86a0:	17fffe15 	b	7ef4 <f12+0x714>
    86a4:	ad470402 	ldp	q2, q1, [x0, #224]
    86a8:	91038001 	add	x1, x0, #0xe0
    86ac:	4f000400 	movi	v0.4s, #0x0
    86b0:	f9008c1f 	str	xzr, [x0, #280]
    86b4:	ad010762 	stp	q2, q1, [x27, #32]
    86b8:	a9500002 	ldp	x2, x0, [x0, #256]
    86bc:	f9000f60 	str	x0, [x27, #24]
    86c0:	f9401820 	ldr	x0, [x1, #48]
    86c4:	f9002362 	str	x2, [x27, #64]
    86c8:	f9002760 	str	x0, [x27, #72]
    86cc:	ad000020 	stp	q0, q0, [x1]
    86d0:	3d800820 	str	q0, [x1, #32]
    86d4:	f900183f 	str	xzr, [x1, #48]
    86d8:	17fffcd3 	b	7a24 <f12+0x244>
    86dc:	f940ac43 	ldr	x3, [x2, #344]
    86e0:	91000463 	add	x3, x3, #0x1
    86e4:	f900ac43 	str	x3, [x2, #344]
    86e8:	17fffc7b 	b	78d4 <f12+0xf4>
    86ec:	d2800005 	mov	x5, #0x0                   	// #0
    86f0:	52800020 	mov	w0, #0x1                   	// #1
    86f4:	17fffe61 	b	8078 <f12+0x898>
    86f8:	52800041 	mov	w1, #0x2                   	// #2
    86fc:	d2800100 	mov	x0, #0x8                   	// #8
    8700:	97fff264 	bl	5090 <fwp_heap_alloc>
    8704:	aa0003f9 	mov	x25, x0
    8708:	d2800013 	mov	x19, #0x0                   	// #0
    870c:	17ffff53 	b	8458 <f12+0xc78>
    8710:	72003c3f 	tst	w1, #0xffff
    8714:	54fff640 	b.eq	85dc <f12+0xdfc>  // b.none
    8718:	aa1303e0 	mov	x0, x19
    871c:	17fffe24 	b	7fac <f12+0x7cc>
    8720:	d1000761 	sub	x1, x27, #0x1
    8724:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8728:	eb00003f 	cmp	x1, x0
    872c:	54000aa8 	b.hi	8880 <f12+0x10a0>  // b.pmore
    8730:	900002c3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fba0>
    8734:	d2800000 	mov	x0, #0x0                   	// #0
    8738:	91118061 	add	x1, x3, #0x460
    873c:	14000005 	b	8750 <f12+0xf70>
    8740:	91000400 	add	x0, x0, #0x1
    8744:	91006021 	add	x1, x1, #0x18
    8748:	f140041f 	cmp	x0, #0x1, lsl #12
    874c:	540006c0 	b.eq	8824 <f12+0x1044>  // b.none
    8750:	f9400022 	ldr	x2, [x1]
    8754:	b5ffff62 	cbnz	x2, 8740 <f12+0xf60>
    8758:	8b000402 	add	x2, x0, x0, lsl #1
    875c:	91118063 	add	x3, x3, #0x460
    8760:	aa1b03e0 	mov	x0, x27
    8764:	d2800101 	mov	x1, #0x8                   	// #8
    8768:	8b020c76 	add	x22, x3, x2, lsl #3
    876c:	a9009fe6 	stp	x6, x7, [sp, #8]
    8770:	a901a7e8 	stp	x8, x9, [sp, #24]
    8774:	97ffe81f 	bl	27f0 <calloc@plt>
    8778:	aa0003e5 	mov	x5, x0
    877c:	a9409fe6 	ldp	x6, x7, [sp, #8]
    8780:	a941a7e8 	ldp	x8, x9, [sp, #24]
    8784:	b4fffb40 	cbz	x0, 86ec <f12+0xf0c>
    8788:	aa0503e1 	mov	x1, x5
    878c:	aa1603e0 	mov	x0, x22
    8790:	d37df362 	lsl	x2, x27, #3
    8794:	52800063 	mov	w3, #0x3                   	// #3
    8798:	a9009be5 	stp	x5, x6, [sp, #8]
    879c:	a901a3e7 	stp	x7, x8, [sp, #24]
    87a0:	f90017e9 	str	x9, [sp, #40]
    87a4:	97ffe9db 	bl	2f10 <ad_raw_record>
    87a8:	a9409be5 	ldp	x5, x6, [sp, #8]
    87ac:	f9004be5 	str	x5, [sp, #144]
    87b0:	a941a3e7 	ldp	x7, x8, [sp, #24]
    87b4:	f90053fb 	str	x27, [sp, #160]
    87b8:	f94017e9 	ldr	x9, [sp, #40]
    87bc:	17fffd75 	b	7d90 <f12+0x5b0>
    87c0:	f94002a3 	ldr	x3, [x21]
    87c4:	b7fff9a3 	tbnz	x3, #63, 86f8 <f12+0xf18>
    87c8:	911902e1 	add	x1, x23, #0x640
    87cc:	f94003e4 	ldr	x4, [sp]
    87d0:	f949d820 	ldr	x0, [x1, #5040]
    87d4:	f949ec21 	ldr	x1, [x1, #5080]
    87d8:	cb000080 	sub	x0, x4, x0
    87dc:	eb01401f 	cmp	x0, x1, lsl #16
    87e0:	54fff8c2 	b.cs	86f8 <f12+0xf18>  // b.hs, b.nlast
    87e4:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    87e8:	17fffe49 	b	810c <f12+0x92c>
    87ec:	d2800d01 	mov	x1, #0x68                  	// #104
    87f0:	d2800036 	mov	x22, #0x1                   	// #1
    87f4:	17fffc6e 	b	79ac <f12+0x1cc>
    87f8:	aa1a03e0 	mov	x0, x26
    87fc:	97fff065 	bl	4990 <fwp_rc_forget_slot>
    8800:	17fffce2 	b	7b88 <f12+0x3a8>
    8804:	aa1903e0 	mov	x0, x25
    8808:	97fff062 	bl	4990 <fwp_rc_forget_slot>
    880c:	17fffdbd 	b	7f00 <f12+0x720>
    8810:	aa1903e0 	mov	x0, x25
    8814:	97fff05f 	bl	4990 <fwp_rc_forget_slot>
    8818:	17ffff74 	b	85e8 <f12+0xe08>
    881c:	97fff016 	bl	4874 <fwp_rc_wide_dup>
    8820:	17fffc31 	b	78e4 <f12+0x104>
    8824:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    8828:	91312000 	add	x0, x0, #0xc48
    882c:	97ffeab5 	bl	3300 <ad_raw_fail>
    8830:	d280001a 	mov	x26, #0x0                   	// #0
    8834:	17fffe95 	b	8288 <f12+0xaa8>
    8838:	d2800019 	mov	x25, #0x0                   	// #0
    883c:	d2800013 	mov	x19, #0x0                   	// #0
    8840:	17ffff06 	b	8458 <f12+0xc78>
    8844:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    8848:	9136a000 	add	x0, x0, #0xda8
    884c:	97ffebcd 	bl	3780 <fwp_trap>
    8850:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    8854:	91390000 	add	x0, x0, #0xe40
    8858:	97ffebca 	bl	3780 <fwp_trap>
    885c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    8860:	913d8000 	add	x0, x0, #0xf60
    8864:	97ffebc7 	bl	3780 <fwp_trap>
    8868:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    886c:	913a8000 	add	x0, x0, #0xea0
    8870:	97ffebc4 	bl	3780 <fwp_trap>
    8874:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    8878:	913d4000 	add	x0, x0, #0xf50
    887c:	97ffebc1 	bl	3780 <fwp_trap>
    8880:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    8884:	913cc000 	add	x0, x0, #0xf30
    8888:	97ffea9e 	bl	3300 <ad_raw_fail>
    888c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    8890:	913c0000 	add	x0, x0, #0xf00
    8894:	97ffebbb 	bl	3780 <fwp_trap>
    8898:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    889c:	913ac000 	add	x0, x0, #0xeb0
    88a0:	97ffebb8 	bl	3780 <fwp_trap>
    88a4:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    88a8:	9137c000 	add	x0, x0, #0xdf0
    88ac:	97ffebb5 	bl	3780 <fwp_trap>
    88b0:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    88b4:	913b4000 	add	x0, x0, #0xed0
    88b8:	97ffebb2 	bl	3780 <fwp_trap>
    88bc:	97ffe7d5 	bl	2810 <__stack_chk_fail@plt>
    88c0:	97ffe7e8 	bl	2860 <abort@plt>
    88c4:	97ffe84f 	bl	2a00 <fwp_trap_overflow.constprop.0>
    88c8:	d503201f 	nop
    88cc:	d503201f 	nop

00000000000088d0 <fwp_owned_entry12>:
    88d0:	f9400000 	ldr	x0, [x0]
    88d4:	17fffbc3 	b	77e0 <f12>
    88d8:	d503201f 	nop
    88dc:	d503201f 	nop

00000000000088e0 <e12>:
    88e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    88e4:	910003fd 	mov	x29, sp
    88e8:	f9000bf3 	str	x19, [sp, #16]
    88ec:	f9400013 	ldr	x19, [x0]
    88f0:	aa1303e0 	mov	x0, x19
    88f4:	97fff424 	bl	5984 <fwp_rc_share>
    88f8:	aa1303e0 	mov	x0, x19
    88fc:	97fffbb9 	bl	77e0 <f12>
    8900:	aa0003f3 	mov	x19, x0
    8904:	97fff420 	bl	5984 <fwp_rc_share>
    8908:	aa1303e0 	mov	x0, x19
    890c:	f9400bf3 	ldr	x19, [sp, #16]
    8910:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8914:	d65f03c0 	ret
    8918:	d503201f 	nop
    891c:	d503201f 	nop

0000000000008920 <fwp_write>:
    8920:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8924:	910003fd 	mov	x29, sp
    8928:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    892c:	f947f484 	ldr	x4, [x4, #4072]
    8930:	a90153f3 	stp	x19, x20, [sp, #16]
    8934:	d10943ff 	sub	sp, sp, #0x250
    8938:	b9400045 	ldr	w5, [x2]
    893c:	aa0003f4 	mov	x20, x0
    8940:	f9400080 	ldr	x0, [x4]
    8944:	f90127e0 	str	x0, [sp, #584]
    8948:	d2800000 	mov	x0, #0x0                   	// #0
    894c:	710064bf 	cmp	w5, #0x19
    8950:	54000408 	b.hi	89d0 <fwp_write+0xb0>  // b.pmore
    8954:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x760>
    8958:	aa0103f3 	mov	x19, x1
    895c:	911f4000 	add	x0, x0, #0x7d0
    8960:	f9013bf5 	str	x21, [sp, #624]
    8964:	f9013ff6 	str	x22, [sp, #632]
    8968:	f90153fb 	str	x27, [sp, #672]
    896c:	f90157fc 	str	x28, [sp, #680]
    8970:	aa0203fc 	mov	x28, x2
    8974:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8978:	10000061 	adr	x1, 8984 <fwp_write+0x64>
    897c:	8b20a820 	add	x0, x1, w0, sxth #2
    8980:	d61f0000 	br	x0
    8984:	910123e0 	add	x0, sp, #0x48
    8988:	aa1303e5 	mov	x5, x19
    898c:	b0000024 	adrp	x4, d000 <fwp_main_thread+0x440>
    8990:	aa0003f3 	mov	x19, x0
    8994:	913f0084 	add	x4, x4, #0xfc0
    8998:	d2804003 	mov	x3, #0x200                 	// #512
    899c:	aa0303e1 	mov	x1, x3
    89a0:	52800042 	mov	w2, #0x2                   	// #2
    89a4:	97ffe777 	bl	2780 <__snprintf_chk@plt>
    89a8:	aa1303e0 	mov	x0, x19
    89ac:	97ffe73d 	bl	26a0 <strlen@plt>
    89b0:	aa1303e1 	mov	x1, x19
    89b4:	aa0003e2 	mov	x2, x0
    89b8:	aa1403e0 	mov	x0, x20
    89bc:	97ffeb15 	bl	3610 <buf_put>
    89c0:	f9413bf5 	ldr	x21, [sp, #624]
    89c4:	f9413ff6 	ldr	x22, [sp, #632]
    89c8:	f94153fb 	ldr	x27, [sp, #672]
    89cc:	f94157fc 	ldr	x28, [sp, #680]
    89d0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    89d4:	f947f400 	ldr	x0, [x0, #4072]
    89d8:	f94127e2 	ldr	x2, [sp, #584]
    89dc:	f9400001 	ldr	x1, [x0]
    89e0:	eb010042 	subs	x2, x2, x1
    89e4:	d2800001 	mov	x1, #0x0                   	// #0
    89e8:	540077c1 	b.ne	98e0 <fwp_write+0xfc0>  // b.any
    89ec:	910943ff 	add	sp, sp, #0x250
    89f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    89f4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    89f8:	d65f03c0 	ret
    89fc:	910123e0 	add	x0, sp, #0x48
    8a00:	aa1303e5 	mov	x5, x19
    8a04:	b0000024 	adrp	x4, d000 <fwp_main_thread+0x440>
    8a08:	aa0003f3 	mov	x19, x0
    8a0c:	913ee084 	add	x4, x4, #0xfb8
    8a10:	d2804003 	mov	x3, #0x200                 	// #512
    8a14:	17ffffe2 	b	899c <fwp_write+0x7c>
    8a18:	71004cbf 	cmp	w5, #0x13
    8a1c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    8a20:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    8a24:	913ea000 	add	x0, x0, #0xfa8
    8a28:	913ec021 	add	x1, x1, #0xfb0
    8a2c:	d2800082 	mov	x2, #0x4                   	// #4
    8a30:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8a34:	aa1403e0 	mov	x0, x20
    8a38:	f90143f7 	str	x23, [sp, #640]
    8a3c:	d2800016 	mov	x22, #0x0                   	// #0
    8a40:	f90147f8 	str	x24, [sp, #648]
    8a44:	97ffeaf3 	bl	3610 <buf_put>
    8a48:	f9400260 	ldr	x0, [x19]
    8a4c:	d0000037 	adrp	x23, e000 <_IO_stdin_used+0x760>
    8a50:	d2800015 	mov	x21, #0x0                   	// #0
    8a54:	9100c2f7 	add	x23, x23, #0x30
    8a58:	b40047a0 	cbz	x0, 934c <fwp_write+0xa2c>
    8a5c:	b9400380 	ldr	w0, [x28]
    8a60:	52800003 	mov	w3, #0x0                   	// #0
    8a64:	f9401f82 	ldr	x2, [x28, #56]
    8a68:	71004c1f 	cmp	w0, #0x13
    8a6c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8a70:	aa1403e0 	mov	x0, x20
    8a74:	8b010e61 	add	x1, x19, x1, lsl #3
    8a78:	f9400421 	ldr	x1, [x1, #8]
    8a7c:	97ffffa9 	bl	8920 <fwp_write>
    8a80:	b9400380 	ldr	w0, [x28]
    8a84:	7100481f 	cmp	w0, #0x12
    8a88:	54004b40 	b.eq	93f0 <fwp_write+0xad0>  // b.none
    8a8c:	f9400260 	ldr	x0, [x19]
    8a90:	910006b5 	add	x21, x21, #0x1
    8a94:	91000ad6 	add	x22, x22, #0x2
    8a98:	eb15001f 	cmp	x0, x21
    8a9c:	54004589 	b.ls	934c <fwp_write+0xa2c>  // b.plast
    8aa0:	aa1703e1 	mov	x1, x23
    8aa4:	aa1403e0 	mov	x0, x20
    8aa8:	d2800042 	mov	x2, #0x2                   	// #2
    8aac:	97ffead9 	bl	3610 <buf_put>
    8ab0:	17ffffeb 	b	8a5c <fwp_write+0x13c>
    8ab4:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    8ab8:	913fa021 	add	x1, x1, #0xfe8
    8abc:	d28000c2 	mov	x2, #0x6                   	// #6
    8ac0:	aa1403e0 	mov	x0, x20
    8ac4:	91004273 	add	x19, x19, #0x10
    8ac8:	97ffead2 	bl	3610 <buf_put>
    8acc:	aa1303e0 	mov	x0, x19
    8ad0:	97ffe6f4 	bl	26a0 <strlen@plt>
    8ad4:	aa1303e1 	mov	x1, x19
    8ad8:	aa0003e2 	mov	x2, x0
    8adc:	aa1403e0 	mov	x0, x20
    8ae0:	97ffeacc 	bl	3610 <buf_put>
    8ae4:	528007c3 	mov	w3, #0x3e                  	// #62
    8ae8:	aa1403e0 	mov	x0, x20
    8aec:	91001fe1 	add	x1, sp, #0x7
    8af0:	d2800022 	mov	x2, #0x1                   	// #1
    8af4:	39001fe3 	strb	w3, [sp, #7]
    8af8:	17ffffb1 	b	89bc <fwp_write+0x9c>
    8afc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8b00:	f947f400 	ldr	x0, [x0, #4072]
    8b04:	f94127e2 	ldr	x2, [sp, #584]
    8b08:	f9400001 	ldr	x1, [x0]
    8b0c:	eb010042 	subs	x2, x2, x1
    8b10:	d2800001 	mov	x1, #0x0                   	// #0
    8b14:	540034e1 	b.ne	91b0 <fwp_write+0x890>  // b.any
    8b18:	f9413bf5 	ldr	x21, [sp, #624]
    8b1c:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    8b20:	f9413ff6 	ldr	x22, [sp, #632]
    8b24:	aa1403e0 	mov	x0, x20
    8b28:	913f2021 	add	x1, x1, #0xfc8
    8b2c:	d2800142 	mov	x2, #0xa                   	// #10
    8b30:	f94153fb 	ldr	x27, [sp, #672]
    8b34:	f94157fc 	ldr	x28, [sp, #680]
    8b38:	910943ff 	add	sp, sp, #0x250
    8b3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8b40:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8b44:	17ffeab3 	b	3610 <buf_put>
    8b48:	f9400456 	ldr	x22, [x2, #8]
    8b4c:	f90143f7 	str	x23, [sp, #640]
    8b50:	f90147f8 	str	x24, [sp, #648]
    8b54:	b4005b16 	cbz	x22, 96b4 <fwp_write+0xd94>
    8b58:	aa1603e0 	mov	x0, x22
    8b5c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x760>
    8b60:	91012021 	add	x1, x1, #0x48
    8b64:	97ffe74b 	bl	2890 <strcmp@plt>
    8b68:	2a0003f5 	mov	w21, w0
    8b6c:	34005fe0 	cbz	w0, 9768 <fwp_write+0xe48>
    8b70:	aa1603e0 	mov	x0, x22
    8b74:	97ffe6cb 	bl	26a0 <strlen@plt>
    8b78:	aa1603e1 	mov	x1, x22
    8b7c:	aa0003e2 	mov	x2, x0
    8b80:	aa1403e0 	mov	x0, x20
    8b84:	97ffeaa3 	bl	3610 <buf_put>
    8b88:	52800403 	mov	w3, #0x20                  	// #32
    8b8c:	91001ff5 	add	x21, sp, #0x7
    8b90:	aa1503e1 	mov	x1, x21
    8b94:	aa1403e0 	mov	x0, x20
    8b98:	d2800022 	mov	x2, #0x1                   	// #1
    8b9c:	39001fe3 	strb	w3, [sp, #7]
    8ba0:	97ffea9c 	bl	3610 <buf_put>
    8ba4:	52800f63 	mov	w3, #0x7b                  	// #123
    8ba8:	aa1403e0 	mov	x0, x20
    8bac:	aa1503e1 	mov	x1, x21
    8bb0:	d2800022 	mov	x2, #0x1                   	// #1
    8bb4:	39001fe3 	strb	w3, [sp, #7]
    8bb8:	97ffea96 	bl	3610 <buf_put>
    8bbc:	b9401380 	ldr	w0, [x28, #16]
    8bc0:	52800018 	mov	w24, #0x0                   	// #0
    8bc4:	7100001f 	cmp	w0, #0x0
    8bc8:	54003aad 	b.le	931c <fwp_write+0x9fc>
    8bcc:	f9014bf9 	str	x25, [sp, #656]
    8bd0:	d0000039 	adrp	x25, e000 <_IO_stdin_used+0x760>
    8bd4:	9101c339 	add	x25, x25, #0x70
    8bd8:	f9014ffa 	str	x26, [sp, #664]
    8bdc:	d000003a 	adrp	x26, e000 <_IO_stdin_used+0x760>
    8be0:	9100c35a 	add	x26, x26, #0x30
    8be4:	91002276 	add	x22, x19, #0x8
    8be8:	d2800013 	mov	x19, #0x0                   	// #0
    8bec:	b5003e93 	cbnz	x19, 93bc <fwp_write+0xa9c>
    8bf0:	d37df277 	lsl	x23, x19, #3
    8bf4:	34003cb8 	cbz	w24, 9388 <fwp_write+0xa68>
    8bf8:	f9401382 	ldr	x2, [x28, #32]
    8bfc:	aa1403e0 	mov	x0, x20
    8c00:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8c04:	52800003 	mov	w3, #0x0                   	// #0
    8c08:	f8776842 	ldr	x2, [x2, x23]
    8c0c:	91000673 	add	x19, x19, #0x1
    8c10:	97ffff44 	bl	8920 <fwp_write>
    8c14:	b9401380 	ldr	w0, [x28, #16]
    8c18:	6b13001f 	cmp	w0, w19
    8c1c:	54fffe8c 	b.gt	8bec <fwp_write+0x2cc>
    8c20:	f9414bf9 	ldr	x25, [sp, #656]
    8c24:	f9414ffa 	ldr	x26, [sp, #664]
    8c28:	340037b8 	cbz	w24, 931c <fwp_write+0x9fc>
    8c2c:	52800523 	mov	w3, #0x29                  	// #41
    8c30:	aa1503e1 	mov	x1, x21
    8c34:	aa1403e0 	mov	x0, x20
    8c38:	d2800022 	mov	x2, #0x1                   	// #1
    8c3c:	39001fe3 	strb	w3, [sp, #7]
    8c40:	97ffea74 	bl	3610 <buf_put>
    8c44:	f9413bf5 	ldr	x21, [sp, #624]
    8c48:	f9413ff6 	ldr	x22, [sp, #632]
    8c4c:	f94143f7 	ldr	x23, [sp, #640]
    8c50:	f94147f8 	ldr	x24, [sp, #648]
    8c54:	f94153fb 	ldr	x27, [sp, #672]
    8c58:	f94157fc 	ldr	x28, [sp, #680]
    8c5c:	17ffff5d 	b	89d0 <fwp_write+0xb0>
    8c60:	b9404855 	ldr	w21, [x2, #72]
    8c64:	aa1403e0 	mov	x0, x20
    8c68:	93407eb6 	sxtw	x22, w21
    8c6c:	91000ac1 	add	x1, x22, #0x2
    8c70:	97ffea34 	bl	3540 <buf_grow>
    8c74:	a9400281 	ldp	x1, x0, [x20]
    8c78:	528e8603 	mov	w3, #0x7430                	// #29744
    8c7c:	78206823 	strh	w3, [x1, x0]
    8c80:	8b000022 	add	x2, x1, x0
    8c84:	710002bf 	cmp	w21, #0x0
    8c88:	540036cd 	b.le	9360 <fwp_write+0xa40>
    8c8c:	110006a3 	add	w3, w21, #0x1
    8c90:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8c94:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8c98:	91000449 	add	x9, x2, #0x1
    8c9c:	8b23c043 	add	x3, x2, w3, sxtw
    8ca0:	f28aaac6 	movk	x6, #0x5556
    8ca4:	f2955568 	movk	x8, #0xaaab
    8ca8:	1400000d 	b	8cdc <fwp_write+0x3bc>
    8cac:	d2800021 	mov	x1, #0x1                   	// #1
    8cb0:	528005a5 	mov	w5, #0x2d                  	// #45
    8cb4:	f100001f 	cmp	x0, #0x0
    8cb8:	9b467e60 	smulh	x0, x19, x6
    8cbc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8cc0:	381ff465 	strb	w5, [x3], #-1
    8cc4:	cb040000 	sub	x0, x0, x4
    8cc8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8ccc:	cb020000 	sub	x0, x0, x2
    8cd0:	8b010013 	add	x19, x0, x1
    8cd4:	eb03013f 	cmp	x9, x3
    8cd8:	54003440 	b.eq	9360 <fwp_write+0xa40>  // b.none
    8cdc:	9b467e60 	smulh	x0, x19, x6
    8ce0:	937ffe64 	asr	x4, x19, #63
    8ce4:	52800605 	mov	w5, #0x30                  	// #48
    8ce8:	cb040000 	sub	x0, x0, x4
    8cec:	8b000400 	add	x0, x0, x0, lsl #1
    8cf0:	cb000260 	sub	x0, x19, x0
    8cf4:	91000c01 	add	x1, x0, #0x3
    8cf8:	9bc87c22 	umulh	x2, x1, x8
    8cfc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8d00:	8b4204e2 	add	x2, x7, x2, lsr #1
    8d04:	eb020021 	subs	x1, x1, x2
    8d08:	54fffd60 	b.eq	8cb4 <fwp_write+0x394>  // b.none
    8d0c:	f100043f 	cmp	x1, #0x1
    8d10:	54fffce1 	b.ne	8cac <fwp_write+0x38c>  // b.any
    8d14:	d2800001 	mov	x1, #0x0                   	// #0
    8d18:	52800565 	mov	w5, #0x2b                  	// #43
    8d1c:	17ffffe6 	b	8cb4 <fwp_write+0x394>
    8d20:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8d24:	f947f400 	ldr	x0, [x0, #4072]
    8d28:	f94127e2 	ldr	x2, [sp, #584]
    8d2c:	f9400001 	ldr	x1, [x0]
    8d30:	eb010042 	subs	x2, x2, x1
    8d34:	d2800001 	mov	x1, #0x0                   	// #0
    8d38:	540023c1 	b.ne	91b0 <fwp_write+0x890>  // b.any
    8d3c:	f9413bf5 	ldr	x21, [sp, #624]
    8d40:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    8d44:	f9413ff6 	ldr	x22, [sp, #632]
    8d48:	aa1403e0 	mov	x0, x20
    8d4c:	913f6021 	add	x1, x1, #0xfd8
    8d50:	d2800102 	mov	x2, #0x8                   	// #8
    8d54:	17ffff77 	b	8b30 <fwp_write+0x210>
    8d58:	aa1403e0 	mov	x0, x20
    8d5c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x760>
    8d60:	d28000c2 	mov	x2, #0x6                   	// #6
    8d64:	9100e021 	add	x1, x1, #0x38
    8d68:	97ffea2a 	bl	3610 <buf_put>
    8d6c:	d2800015 	mov	x21, #0x0                   	// #0
    8d70:	f9400263 	ldr	x3, [x19]
    8d74:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8d78:	54002c60 	b.eq	9304 <fwp_write+0x9e4>  // b.none
    8d7c:	f9401f82 	ldr	x2, [x28, #56]
    8d80:	f90143f7 	str	x23, [sp, #640]
    8d84:	f90147f8 	str	x24, [sp, #648]
    8d88:	d2800857 	mov	x23, #0x42                  	// #66
    8d8c:	f9014bf9 	str	x25, [sp, #656]
    8d90:	d0000036 	adrp	x22, e000 <_IO_stdin_used+0x760>
    8d94:	f9014ffa 	str	x26, [sp, #664]
    8d98:	9100c2d6 	add	x22, x22, #0x30
    8d9c:	d2800038 	mov	x24, #0x1                   	// #1
    8da0:	f2a18017 	movk	x23, #0xc00, lsl #16
    8da4:	d2809099 	mov	x25, #0x484                 	// #1156
    8da8:	b40004a2 	cbz	x2, 8e3c <fwp_write+0x51c>
    8dac:	b9400040 	ldr	w0, [x2]
    8db0:	7100701f 	cmp	w0, #0x1c
    8db4:	540042c0 	b.eq	960c <fwp_write+0xcec>  // b.none
    8db8:	71006c1f 	cmp	w0, #0x1b
    8dbc:	54000408 	b.hi	8e3c <fwp_write+0x51c>  // b.pmore
    8dc0:	9ac02301 	lsl	x1, x24, x0
    8dc4:	ea17003f 	tst	x1, x23
    8dc8:	540036a1 	b.ne	949c <fwp_write+0xb7c>  // b.any
    8dcc:	ea19003f 	tst	x1, x25
    8dd0:	54003521 	b.ne	9474 <fwp_write+0xb54>  // b.any
    8dd4:	d2800424 	mov	x4, #0x21                  	// #33
    8dd8:	ea04003f 	tst	x1, x4
    8ddc:	54000300 	b.eq	8e3c <fwp_write+0x51c>  // b.none
    8de0:	b7f849c3 	tbnz	x3, #63, 9718 <fwp_write+0xdf8>
    8de4:	91002261 	add	x1, x19, #0x8
    8de8:	8b150021 	add	x1, x1, x21
    8dec:	39400021 	ldrb	w1, [x1]
    8df0:	7100001f 	cmp	w0, #0x0
    8df4:	93401c23 	sxtb	x3, w1
    8df8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8dfc:	d503201f 	nop
    8e00:	aa1403e0 	mov	x0, x20
    8e04:	52800003 	mov	w3, #0x0                   	// #0
    8e08:	97fffec6 	bl	8920 <fwp_write>
    8e0c:	910006b5 	add	x21, x21, #0x1
    8e10:	f9400260 	ldr	x0, [x19]
    8e14:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8e18:	eb0002bf 	cmp	x21, x0
    8e1c:	540026c2 	b.cs	92f4 <fwp_write+0x9d4>  // b.hs, b.nlast
    8e20:	d2800042 	mov	x2, #0x2                   	// #2
    8e24:	aa1603e1 	mov	x1, x22
    8e28:	aa1403e0 	mov	x0, x20
    8e2c:	97ffe9f9 	bl	3610 <buf_put>
    8e30:	f9401f82 	ldr	x2, [x28, #56]
    8e34:	f9400263 	ldr	x3, [x19]
    8e38:	b5fffba2 	cbnz	x2, 8dac <fwp_write+0x48c>
    8e3c:	d37df2a0 	lsl	x0, x21, #3
    8e40:	b7f83f03 	tbnz	x3, #63, 9620 <fwp_write+0xd00>
    8e44:	91002261 	add	x1, x19, #0x8
    8e48:	8b000020 	add	x0, x1, x0
    8e4c:	f9400001 	ldr	x1, [x0]
    8e50:	17ffffec 	b	8e00 <fwp_write+0x4e0>
    8e54:	a9400e62 	ldp	x2, x3, [x19]
    8e58:	b7f83ca3 	tbnz	x3, #63, 95ec <fwp_write+0xccc>
    8e5c:	910123f5 	add	x21, sp, #0x48
    8e60:	aa1503e0 	mov	x0, x21
    8e64:	97ffe7cf 	bl	2da0 <fwp_fmt_u128>
    8e68:	aa1503e0 	mov	x0, x21
    8e6c:	97ffe60d 	bl	26a0 <strlen@plt>
    8e70:	aa1503e1 	mov	x1, x21
    8e74:	aa0003e2 	mov	x2, x0
    8e78:	17fffed0 	b	89b8 <fwp_write+0x98>
    8e7c:	fd015be8 	str	d8, [sp, #688]
    8e80:	1e270268 	fmov	s8, w19
    8e84:	fd015fe9 	str	d9, [sp, #696]
    8e88:	1e282100 	fcmp	s8, s8
    8e8c:	54004d26 	b.vs	9830 <fwp_write+0xf10>
    8e90:	1e20c101 	fabs	s1, s8
    8e94:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8e98:	1e270000 	fmov	s0, w0
    8e9c:	1e202020 	fcmp	s1, s0
    8ea0:	54002c0d 	b.le	9420 <fwp_write+0xb00>
    8ea4:	1e202118 	fcmpe	s8, #0.0
    8ea8:	b0000022 	adrp	x2, d000 <fwp_main_thread+0x440>
    8eac:	91286042 	add	x2, x2, #0xa18
    8eb0:	910123f5 	add	x21, sp, #0x48
    8eb4:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    8eb8:	913e2021 	add	x1, x1, #0xf88
    8ebc:	aa1503e0 	mov	x0, x21
    8ec0:	9a81c041 	csel	x1, x2, x1, gt
    8ec4:	97ffe6a3 	bl	2950 <strcpy@plt>
    8ec8:	aa1503e0 	mov	x0, x21
    8ecc:	97ffe5f5 	bl	26a0 <strlen@plt>
    8ed0:	aa1503e1 	mov	x1, x21
    8ed4:	aa0003e2 	mov	x2, x0
    8ed8:	aa1403e0 	mov	x0, x20
    8edc:	97ffe9cd 	bl	3610 <buf_put>
    8ee0:	f9413bf5 	ldr	x21, [sp, #624]
    8ee4:	f9413ff6 	ldr	x22, [sp, #632]
    8ee8:	f94153fb 	ldr	x27, [sp, #672]
    8eec:	f94157fc 	ldr	x28, [sp, #680]
    8ef0:	fd415be8 	ldr	d8, [sp, #688]
    8ef4:	fd415fe9 	ldr	d9, [sp, #696]
    8ef8:	17fffeb6 	b	89d0 <fwp_write+0xb0>
    8efc:	f9400276 	ldr	x22, [x19]
    8f00:	34002e03 	cbz	w3, 94c0 <fwp_write+0xba0>
    8f04:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8f08:	f947f400 	ldr	x0, [x0, #4072]
    8f0c:	f94127e2 	ldr	x2, [sp, #584]
    8f10:	f9400001 	ldr	x1, [x0]
    8f14:	eb010042 	subs	x2, x2, x1
    8f18:	d2800001 	mov	x1, #0x0                   	// #0
    8f1c:	540014a1 	b.ne	91b0 <fwp_write+0x890>  // b.any
    8f20:	aa1603e2 	mov	x2, x22
    8f24:	91002261 	add	x1, x19, #0x8
    8f28:	f9413bf5 	ldr	x21, [sp, #624]
    8f2c:	aa1403e0 	mov	x0, x20
    8f30:	f9413ff6 	ldr	x22, [sp, #632]
    8f34:	17fffeff 	b	8b30 <fwp_write+0x210>
    8f38:	fd015be8 	str	d8, [sp, #688]
    8f3c:	9e670268 	fmov	d8, x19
    8f40:	fd015fe9 	str	d9, [sp, #696]
    8f44:	1e682100 	fcmp	d8, d8
    8f48:	54004746 	b.vs	9830 <fwp_write+0xf10>
    8f4c:	1e60c101 	fabs	d1, d8
    8f50:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8f54:	9e670000 	fmov	d0, x0
    8f58:	910123f5 	add	x21, sp, #0x48
    8f5c:	52800033 	mov	w19, #0x1                   	// #1
    8f60:	1e602020 	fcmp	d1, d0
    8f64:	540001ad 	b.le	8f98 <fwp_write+0x678>
    8f68:	1e602118 	fcmpe	d8, #0.0
    8f6c:	b0000022 	adrp	x2, d000 <fwp_main_thread+0x440>
    8f70:	91286042 	add	x2, x2, #0xa18
    8f74:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    8f78:	913e2021 	add	x1, x1, #0xf88
    8f7c:	aa1503e0 	mov	x0, x21
    8f80:	9a81c041 	csel	x1, x2, x1, gt
    8f84:	97ffe673 	bl	2950 <strcpy@plt>
    8f88:	17ffffd0 	b	8ec8 <fwp_write+0x5a8>
    8f8c:	11000673 	add	w19, w19, #0x1
    8f90:	71004a7f 	cmp	w19, #0x12
    8f94:	54003860 	b.eq	96a0 <fwp_write+0xd80>  // b.none
    8f98:	1e604100 	fmov	d0, d8
    8f9c:	2a1303e1 	mov	w1, w19
    8fa0:	aa1503e0 	mov	x0, x21
    8fa4:	97ffeadc 	bl	3b14 <fwp_format_g.constprop.0>
    8fa8:	aa1503e0 	mov	x0, x21
    8fac:	d2800001 	mov	x1, #0x0                   	// #0
    8fb0:	97ffe5d0 	bl	26f0 <strtod@plt>
    8fb4:	1e602100 	fcmp	d8, d0
    8fb8:	54fffea1 	b.ne	8f8c <fwp_write+0x66c>  // b.any
    8fbc:	aa1503e0 	mov	x0, x21
    8fc0:	97ffe9cd 	bl	36f4 <fwp_finish_float>
    8fc4:	17ffffc1 	b	8ec8 <fwp_write+0x5a8>
    8fc8:	a9400e62 	ldp	x2, x3, [x19]
    8fcc:	910123f3 	add	x19, sp, #0x48
    8fd0:	aa1303e0 	mov	x0, x19
    8fd4:	97ffe773 	bl	2da0 <fwp_fmt_u128>
    8fd8:	17fffe74 	b	89a8 <fwp_write+0x88>
    8fdc:	f90143f7 	str	x23, [sp, #640]
    8fe0:	f90147f8 	str	x24, [sp, #648]
    8fe4:	2a1303f8 	mov	w24, w19
    8fe8:	f9014bf9 	str	x25, [sp, #656]
    8fec:	f9014ffa 	str	x26, [sp, #664]
    8ff0:	f13ffe7f 	cmp	x19, #0xfff
    8ff4:	54000049 	b.ls	8ffc <fwp_write+0x6dc>  // b.plast
    8ff8:	b9400278 	ldr	w24, [x19]
    8ffc:	f9400f80 	ldr	x0, [x28, #24]
    9000:	2a1803f5 	mov	w21, w24
    9004:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9008:	d37ef6b9 	lsl	x25, x21, #2
    900c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    9010:	aa1603e0 	mov	x0, x22
    9014:	97ffe5a3 	bl	26a0 <strlen@plt>
    9018:	aa1603e1 	mov	x1, x22
    901c:	aa0003e2 	mov	x2, x0
    9020:	aa1403e0 	mov	x0, x20
    9024:	97ffe97b 	bl	3610 <buf_put>
    9028:	f9401780 	ldr	x0, [x28, #40]
    902c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9030:	7100001f 	cmp	w0, #0x0
    9034:	5400068d 	b.le	9104 <fwp_write+0x7e4>
    9038:	91002276 	add	x22, x19, #0x8
    903c:	91001ff5 	add	x21, sp, #0x7
    9040:	d280001b 	mov	x27, #0x0                   	// #0
    9044:	5280041a 	mov	w26, #0x20                  	// #32
    9048:	f9401b80 	ldr	x0, [x28, #48]
    904c:	aa1503e1 	mov	x1, x21
    9050:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    9054:	d2800022 	mov	x2, #0x1                   	// #1
    9058:	f8786803 	ldr	x3, [x0, x24]
    905c:	aa1403e0 	mov	x0, x20
    9060:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9064:	39001ffa 	strb	w26, [sp, #7]
    9068:	97ffe96a 	bl	3610 <buf_put>
    906c:	f13ffeff 	cmp	x23, #0xfff
    9070:	b9400261 	ldr	w1, [x19]
    9074:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9078:	7100383f 	cmp	w1, #0xe
    907c:	54000160 	b.eq	90a8 <fwp_write+0x788>  // b.none
    9080:	7100403f 	cmp	w1, #0x10
    9084:	54001a60 	b.eq	93d0 <fwp_write+0xab0>  // b.none
    9088:	7100283f 	cmp	w1, #0xa
    908c:	54002aa0 	b.eq	95e0 <fwp_write+0xcc0>  // b.none
    9090:	540014ac 	b.gt	9324 <fwp_write+0xa04>
    9094:	71000c3f 	cmp	w1, #0x3
    9098:	540029ac 	b.gt	95cc <fwp_write+0xcac>
    909c:	d37ffee0 	lsr	x0, x23, #63
    90a0:	37f814a1 	tbnz	w1, #31, 9334 <fwp_write+0xa14>
    90a4:	d503201f 	nop
    90a8:	34001460 	cbz	w0, 9334 <fwp_write+0xa14>
    90ac:	52800503 	mov	w3, #0x28                  	// #40
    90b0:	aa1503e1 	mov	x1, x21
    90b4:	aa1403e0 	mov	x0, x20
    90b8:	d2800022 	mov	x2, #0x1                   	// #1
    90bc:	39001fe3 	strb	w3, [sp, #7]
    90c0:	97ffe954 	bl	3610 <buf_put>
    90c4:	aa1303e2 	mov	x2, x19
    90c8:	aa1703e1 	mov	x1, x23
    90cc:	aa1403e0 	mov	x0, x20
    90d0:	52800003 	mov	w3, #0x0                   	// #0
    90d4:	97fffe13 	bl	8920 <fwp_write>
    90d8:	52800523 	mov	w3, #0x29                  	// #41
    90dc:	aa1503e1 	mov	x1, x21
    90e0:	aa1403e0 	mov	x0, x20
    90e4:	d2800022 	mov	x2, #0x1                   	// #1
    90e8:	39001fe3 	strb	w3, [sp, #7]
    90ec:	97ffe949 	bl	3610 <buf_put>
    90f0:	f9401780 	ldr	x0, [x28, #40]
    90f4:	9100077b 	add	x27, x27, #0x1
    90f8:	b8796800 	ldr	w0, [x0, x25]
    90fc:	6b1b001f 	cmp	w0, w27
    9100:	54fffa4c 	b.gt	9048 <fwp_write+0x728>
    9104:	f9413bf5 	ldr	x21, [sp, #624]
    9108:	f9413ff6 	ldr	x22, [sp, #632]
    910c:	f94143f7 	ldr	x23, [sp, #640]
    9110:	f94147f8 	ldr	x24, [sp, #648]
    9114:	f9414bf9 	ldr	x25, [sp, #656]
    9118:	f9414ffa 	ldr	x26, [sp, #664]
    911c:	f94153fb 	ldr	x27, [sp, #672]
    9120:	f94157fc 	ldr	x28, [sp, #680]
    9124:	17fffe2b 	b	89d0 <fwp_write+0xb0>
    9128:	52800783 	mov	w3, #0x3c                  	// #60
    912c:	91001ff3 	add	x19, sp, #0x7
    9130:	aa1303e1 	mov	x1, x19
    9134:	d2800022 	mov	x2, #0x1                   	// #1
    9138:	aa1403e0 	mov	x0, x20
    913c:	39001fe3 	strb	w3, [sp, #7]
    9140:	97ffe934 	bl	3610 <buf_put>
    9144:	f9400795 	ldr	x21, [x28, #8]
    9148:	aa1503e0 	mov	x0, x21
    914c:	97ffe555 	bl	26a0 <strlen@plt>
    9150:	aa1503e1 	mov	x1, x21
    9154:	aa0003e2 	mov	x2, x0
    9158:	aa1403e0 	mov	x0, x20
    915c:	97ffe92d 	bl	3610 <buf_put>
    9160:	528007c3 	mov	w3, #0x3e                  	// #62
    9164:	aa1303e1 	mov	x1, x19
    9168:	aa1403e0 	mov	x0, x20
    916c:	d2800022 	mov	x2, #0x1                   	// #1
    9170:	39001fe3 	strb	w3, [sp, #7]
    9174:	17fffe12 	b	89bc <fwp_write+0x9c>
    9178:	f100067f 	cmp	x19, #0x1
    917c:	540025a0 	b.eq	9630 <fwp_write+0xd10>  // b.none
    9180:	b100067f 	cmn	x19, #0x1
    9184:	54002bc0 	b.eq	96fc <fwp_write+0xddc>  // b.none
    9188:	90000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    918c:	913e4021 	add	x1, x1, #0xf90
    9190:	d2800022 	mov	x2, #0x1                   	// #1
    9194:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9198:	f947f400 	ldr	x0, [x0, #4072]
    919c:	f94127e4 	ldr	x4, [sp, #584]
    91a0:	f9400003 	ldr	x3, [x0]
    91a4:	eb030084 	subs	x4, x4, x3
    91a8:	d2800003 	mov	x3, #0x0                   	// #0
    91ac:	54ffebe0 	b.eq	8f28 <fwp_write+0x608>  // b.none
    91b0:	f90143f7 	str	x23, [sp, #640]
    91b4:	f90147f8 	str	x24, [sp, #648]
    91b8:	f9014bf9 	str	x25, [sp, #656]
    91bc:	f9014ffa 	str	x26, [sp, #664]
    91c0:	fd015be8 	str	d8, [sp, #688]
    91c4:	fd015fe9 	str	d9, [sp, #696]
    91c8:	97ffe592 	bl	2810 <__stack_chk_fail@plt>
    91cc:	52800b63 	mov	w3, #0x5b                  	// #91
    91d0:	91001ff5 	add	x21, sp, #0x7
    91d4:	aa1503e1 	mov	x1, x21
    91d8:	aa1403e0 	mov	x0, x20
    91dc:	d2800022 	mov	x2, #0x1                   	// #1
    91e0:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x760>
    91e4:	9100c2d6 	add	x22, x22, #0x30
    91e8:	39001fe3 	strb	w3, [sp, #7]
    91ec:	97ffe909 	bl	3610 <buf_put>
    91f0:	b4000273 	cbz	x19, 923c <fwp_write+0x91c>
    91f4:	f9400661 	ldr	x1, [x19, #8]
    91f8:	aa1403e0 	mov	x0, x20
    91fc:	f9401f82 	ldr	x2, [x28, #56]
    9200:	52800003 	mov	w3, #0x0                   	// #0
    9204:	97fffdc7 	bl	8920 <fwp_write>
    9208:	f9400a73 	ldr	x19, [x19, #16]
    920c:	b4000193 	cbz	x19, 923c <fwp_write+0x91c>
    9210:	aa1603e1 	mov	x1, x22
    9214:	aa1403e0 	mov	x0, x20
    9218:	d2800042 	mov	x2, #0x2                   	// #2
    921c:	97ffe8fd 	bl	3610 <buf_put>
    9220:	f9400661 	ldr	x1, [x19, #8]
    9224:	aa1403e0 	mov	x0, x20
    9228:	f9401f82 	ldr	x2, [x28, #56]
    922c:	52800003 	mov	w3, #0x0                   	// #0
    9230:	97fffdbc 	bl	8920 <fwp_write>
    9234:	f9400a73 	ldr	x19, [x19, #16]
    9238:	b5fffed3 	cbnz	x19, 9210 <fwp_write+0x8f0>
    923c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9240:	aa1503e1 	mov	x1, x21
    9244:	aa1403e0 	mov	x0, x20
    9248:	d2800022 	mov	x2, #0x1                   	// #1
    924c:	39001fe3 	strb	w3, [sp, #7]
    9250:	17fffddb 	b	89bc <fwp_write+0x9c>
    9254:	aa1403e0 	mov	x0, x20
    9258:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x760>
    925c:	d28000c2 	mov	x2, #0x6                   	// #6
    9260:	91008021 	add	x1, x1, #0x20
    9264:	97ffe8eb 	bl	3610 <buf_put>
    9268:	f9400260 	ldr	x0, [x19]
    926c:	b40004c0 	cbz	x0, 9304 <fwp_write+0x9e4>
    9270:	910123f5 	add	x21, sp, #0x48
    9274:	91002276 	add	x22, x19, #0x8
    9278:	f90143f7 	str	x23, [sp, #640]
    927c:	d2800017 	mov	x23, #0x0                   	// #0
    9280:	f90147f8 	str	x24, [sp, #648]
    9284:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x760>
    9288:	9100a318 	add	x24, x24, #0x28
    928c:	f9014bf9 	str	x25, [sp, #656]
    9290:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x760>
    9294:	9100c339 	add	x25, x25, #0x30
    9298:	f9014ffa 	str	x26, [sp, #664]
    929c:	14000005 	b	92b0 <fwp_write+0x990>
    92a0:	aa1903e1 	mov	x1, x25
    92a4:	aa1403e0 	mov	x0, x20
    92a8:	d2800042 	mov	x2, #0x2                   	// #2
    92ac:	97ffe8d9 	bl	3610 <buf_put>
    92b0:	38776ac5 	ldrb	w5, [x22, x23]
    92b4:	d2804003 	mov	x3, #0x200                 	// #512
    92b8:	aa1803e4 	mov	x4, x24
    92bc:	aa0303e1 	mov	x1, x3
    92c0:	52800042 	mov	w2, #0x2                   	// #2
    92c4:	aa1503e0 	mov	x0, x21
    92c8:	910006f7 	add	x23, x23, #0x1
    92cc:	97ffe52d 	bl	2780 <__snprintf_chk@plt>
    92d0:	aa1503e0 	mov	x0, x21
    92d4:	97ffe4f3 	bl	26a0 <strlen@plt>
    92d8:	aa1503e1 	mov	x1, x21
    92dc:	aa0003e2 	mov	x2, x0
    92e0:	aa1403e0 	mov	x0, x20
    92e4:	97ffe8cb 	bl	3610 <buf_put>
    92e8:	f9400260 	ldr	x0, [x19]
    92ec:	eb17001f 	cmp	x0, x23
    92f0:	54fffd88 	b.hi	92a0 <fwp_write+0x980>  // b.pmore
    92f4:	f94143f7 	ldr	x23, [sp, #640]
    92f8:	f94147f8 	ldr	x24, [sp, #648]
    92fc:	f9414bf9 	ldr	x25, [sp, #656]
    9300:	f9414ffa 	ldr	x26, [sp, #664]
    9304:	52800ba3 	mov	w3, #0x5d                  	// #93
    9308:	aa1403e0 	mov	x0, x20
    930c:	91001fe1 	add	x1, sp, #0x7
    9310:	d2800022 	mov	x2, #0x1                   	// #1
    9314:	39001fe3 	strb	w3, [sp, #7]
    9318:	17fffda9 	b	89bc <fwp_write+0x9c>
    931c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9320:	17fffe44 	b	8c30 <fwp_write+0x310>
    9324:	f10002ff 	cmp	x23, #0x0
    9328:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    932c:	71002c3f 	cmp	w1, #0xb
    9330:	54ffebc0 	b.eq	90a8 <fwp_write+0x788>  // b.none
    9334:	aa1303e2 	mov	x2, x19
    9338:	aa1703e1 	mov	x1, x23
    933c:	aa1403e0 	mov	x0, x20
    9340:	52800003 	mov	w3, #0x0                   	// #0
    9344:	97fffd77 	bl	8920 <fwp_write>
    9348:	17ffff6a 	b	90f0 <fwp_write+0x7d0>
    934c:	aa1403e0 	mov	x0, x20
    9350:	91001fe1 	add	x1, sp, #0x7
    9354:	52800fa3 	mov	w3, #0x7d                  	// #125
    9358:	d2800022 	mov	x2, #0x1                   	// #1
    935c:	17fffe38 	b	8c3c <fwp_write+0x31c>
    9360:	a9400281 	ldp	x1, x0, [x20]
    9364:	91000800 	add	x0, x0, #0x2
    9368:	8b160000 	add	x0, x0, x22
    936c:	f9000680 	str	x0, [x20, #8]
    9370:	3820683f 	strb	wzr, [x1, x0]
    9374:	f9413bf5 	ldr	x21, [sp, #624]
    9378:	f9413ff6 	ldr	x22, [sp, #632]
    937c:	f94153fb 	ldr	x27, [sp, #672]
    9380:	f94157fc 	ldr	x28, [sp, #680]
    9384:	17fffd93 	b	89d0 <fwp_write+0xb0>
    9388:	f9400f80 	ldr	x0, [x28, #24]
    938c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9390:	aa1b03e0 	mov	x0, x27
    9394:	97ffe4c3 	bl	26a0 <strlen@plt>
    9398:	aa1b03e1 	mov	x1, x27
    939c:	aa0003e2 	mov	x2, x0
    93a0:	aa1403e0 	mov	x0, x20
    93a4:	97ffe89b 	bl	3610 <buf_put>
    93a8:	aa1903e1 	mov	x1, x25
    93ac:	aa1403e0 	mov	x0, x20
    93b0:	d2800062 	mov	x2, #0x3                   	// #3
    93b4:	97ffe897 	bl	3610 <buf_put>
    93b8:	17fffe10 	b	8bf8 <fwp_write+0x2d8>
    93bc:	aa1a03e1 	mov	x1, x26
    93c0:	aa1403e0 	mov	x0, x20
    93c4:	d2800042 	mov	x2, #0x2                   	// #2
    93c8:	97ffe892 	bl	3610 <buf_put>
    93cc:	17fffe09 	b	8bf0 <fwp_write+0x2d0>
    93d0:	f9400660 	ldr	x0, [x19, #8]
    93d4:	b4fffb00 	cbz	x0, 9334 <fwp_write+0xa14>
    93d8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x760>
    93dc:	91012021 	add	x1, x1, #0x48
    93e0:	97ffe52c 	bl	2890 <strcmp@plt>
    93e4:	7100001f 	cmp	w0, #0x0
    93e8:	1a9f07e0 	cset	w0, ne	// ne = any
    93ec:	17ffff2f 	b	90a8 <fwp_write+0x788>
    93f0:	aa1403e0 	mov	x0, x20
    93f4:	d2800042 	mov	x2, #0x2                   	// #2
    93f8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x760>
    93fc:	91010021 	add	x1, x1, #0x40
    9400:	97ffe884 	bl	3610 <buf_put>
    9404:	91004261 	add	x1, x19, #0x10
    9408:	aa1403e0 	mov	x0, x20
    940c:	f9402382 	ldr	x2, [x28, #64]
    9410:	52800003 	mov	w3, #0x0                   	// #0
    9414:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9418:	97fffd42 	bl	8920 <fwp_write>
    941c:	17fffd9c 	b	8a8c <fwp_write+0x16c>
    9420:	1e22c109 	fcvt	d9, s8
    9424:	910123f5 	add	x21, sp, #0x48
    9428:	52800033 	mov	w19, #0x1                   	// #1
    942c:	d503201f 	nop
    9430:	1e604120 	fmov	d0, d9
    9434:	2a1303e1 	mov	w1, w19
    9438:	aa1503e0 	mov	x0, x21
    943c:	97ffe9b6 	bl	3b14 <fwp_format_g.constprop.0>
    9440:	aa1503e0 	mov	x0, x21
    9444:	d2800001 	mov	x1, #0x0                   	// #0
    9448:	97ffe51e 	bl	28c0 <strtof@plt>
    944c:	1e202100 	fcmp	s8, s0
    9450:	54ffdb60 	b.eq	8fbc <fwp_write+0x69c>  // b.none
    9454:	11000673 	add	w19, w19, #0x1
    9458:	71002a7f 	cmp	w19, #0xa
    945c:	54fffea1 	b.ne	9430 <fwp_write+0xb10>  // b.any
    9460:	1e604120 	fmov	d0, d9
    9464:	aa1503e0 	mov	x0, x21
    9468:	52800121 	mov	w1, #0x9                   	// #9
    946c:	97ffe9aa 	bl	3b14 <fwp_format_g.constprop.0>
    9470:	17fffed3 	b	8fbc <fwp_write+0x69c>
    9474:	d37ef6a1 	lsl	x1, x21, #2
    9478:	b7f81563 	tbnz	x3, #63, 9724 <fwp_write+0xe04>
    947c:	91002263 	add	x3, x19, #0x8
    9480:	8b010061 	add	x1, x3, x1
    9484:	b9400023 	ldr	w3, [x1]
    9488:	7100081f 	cmp	w0, #0x2
    948c:	2a0303e1 	mov	w1, w3
    9490:	93407c63 	sxtw	x3, w3
    9494:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9498:	17fffe5a 	b	8e00 <fwp_write+0x4e0>
    949c:	d37ffaa1 	lsl	x1, x21, #1
    94a0:	b7f81363 	tbnz	x3, #63, 970c <fwp_write+0xdec>
    94a4:	91002263 	add	x3, x19, #0x8
    94a8:	8b010061 	add	x1, x3, x1
    94ac:	79400021 	ldrh	w1, [x1]
    94b0:	7100041f 	cmp	w0, #0x1
    94b4:	93403c23 	sxth	x3, w1
    94b8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    94bc:	17fffe51 	b	8e00 <fwp_write+0x4e0>
    94c0:	52800443 	mov	w3, #0x22                  	// #34
    94c4:	91001ff5 	add	x21, sp, #0x7
    94c8:	91002273 	add	x19, x19, #0x8
    94cc:	aa1503e1 	mov	x1, x21
    94d0:	aa1403e0 	mov	x0, x20
    94d4:	d2800022 	mov	x2, #0x1                   	// #1
    94d8:	39001fe3 	strb	w3, [sp, #7]
    94dc:	f90143f7 	str	x23, [sp, #640]
    94e0:	8b160277 	add	x23, x19, x22
    94e4:	f90147f8 	str	x24, [sp, #648]
    94e8:	97ffe84a 	bl	3610 <buf_put>
    94ec:	b4000696 	cbz	x22, 95bc <fwp_write+0xc9c>
    94f0:	90000038 	adrp	x24, d000 <fwp_main_thread+0x440>
    94f4:	913fc318 	add	x24, x24, #0xff0
    94f8:	f9014bf9 	str	x25, [sp, #656]
    94fc:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x760>
    9500:	91004339 	add	x25, x25, #0x10
    9504:	f9014ffa 	str	x26, [sp, #664]
    9508:	1400000d 	b	953c <fwp_write+0xc1c>
    950c:	710024bf 	cmp	w5, #0x9
    9510:	54000460 	b.eq	959c <fwp_write+0xc7c>  // b.none
    9514:	710028bf 	cmp	w5, #0xa
    9518:	54000a61 	b.ne	9664 <fwp_write+0xd44>  // b.any
    951c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x760>
    9520:	aa1403e0 	mov	x0, x20
    9524:	91000021 	add	x1, x1, #0x0
    9528:	d2800042 	mov	x2, #0x2                   	// #2
    952c:	97ffe839 	bl	3610 <buf_put>
    9530:	91000673 	add	x19, x19, #0x1
    9534:	eb17027f 	cmp	x19, x23
    9538:	540003e0 	b.eq	95b4 <fwp_write+0xc94>  // b.none
    953c:	39400265 	ldrb	w5, [x19]
    9540:	710034bf 	cmp	w5, #0xd
    9544:	54000180 	b.eq	9574 <fwp_write+0xc54>  // b.none
    9548:	54fffe29 	b.ls	950c <fwp_write+0xbec>  // b.plast
    954c:	710088bf 	cmp	w5, #0x22
    9550:	540001c0 	b.eq	9588 <fwp_write+0xc68>  // b.none
    9554:	710170bf 	cmp	w5, #0x5c
    9558:	54000741 	b.ne	9640 <fwp_write+0xd20>  // b.any
    955c:	aa1403e0 	mov	x0, x20
    9560:	90000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    9564:	d2800042 	mov	x2, #0x2                   	// #2
    9568:	913fe021 	add	x1, x1, #0xff8
    956c:	97ffe829 	bl	3610 <buf_put>
    9570:	17fffff0 	b	9530 <fwp_write+0xc10>
    9574:	aa1903e1 	mov	x1, x25
    9578:	aa1403e0 	mov	x0, x20
    957c:	d2800042 	mov	x2, #0x2                   	// #2
    9580:	97ffe824 	bl	3610 <buf_put>
    9584:	17ffffeb 	b	9530 <fwp_write+0xc10>
    9588:	aa1803e1 	mov	x1, x24
    958c:	aa1403e0 	mov	x0, x20
    9590:	d2800042 	mov	x2, #0x2                   	// #2
    9594:	97ffe81f 	bl	3610 <buf_put>
    9598:	17ffffe6 	b	9530 <fwp_write+0xc10>
    959c:	aa1403e0 	mov	x0, x20
    95a0:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x760>
    95a4:	d2800042 	mov	x2, #0x2                   	// #2
    95a8:	91002021 	add	x1, x1, #0x8
    95ac:	97ffe819 	bl	3610 <buf_put>
    95b0:	17ffffe0 	b	9530 <fwp_write+0xc10>
    95b4:	f9414bf9 	ldr	x25, [sp, #656]
    95b8:	f9414ffa 	ldr	x26, [sp, #664]
    95bc:	aa1503e1 	mov	x1, x21
    95c0:	aa1403e0 	mov	x0, x20
    95c4:	52800443 	mov	w3, #0x22                  	// #34
    95c8:	17fffd9c 	b	8c38 <fwp_write+0x318>
    95cc:	7100103f 	cmp	w1, #0x4
    95d0:	54ffeb21 	b.ne	9334 <fwp_write+0xa14>  // b.any
    95d4:	f94006e0 	ldr	x0, [x23, #8]
    95d8:	d37ffc00 	lsr	x0, x0, #63
    95dc:	17fffeb3 	b	90a8 <fwp_write+0x788>
    95e0:	710002ff 	cmp	w23, #0x0
    95e4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    95e8:	17fffeb0 	b	90a8 <fwp_write+0x788>
    95ec:	528005a1 	mov	w1, #0x2d                  	// #45
    95f0:	eb0203e2 	negs	x2, x2
    95f4:	da0303e3 	ngc	x3, x3
    95f8:	910127e0 	add	x0, sp, #0x49
    95fc:	910123f5 	add	x21, sp, #0x48
    9600:	390123e1 	strb	w1, [sp, #72]
    9604:	97ffe5e7 	bl	2da0 <fwp_fmt_u128>
    9608:	17fffe18 	b	8e68 <fwp_write+0x548>
    960c:	d37ceea1 	lsl	x1, x21, #4
    9610:	b7f810a3 	tbnz	x3, #63, 9824 <fwp_write+0xf04>
    9614:	91002260 	add	x0, x19, #0x8
    9618:	8b010001 	add	x1, x0, x1
    961c:	17fffdf9 	b	8e00 <fwp_write+0x4e0>
    9620:	f9400a61 	ldr	x1, [x19, #16]
    9624:	8b010000 	add	x0, x0, x1
    9628:	f9400001 	ldr	x1, [x0]
    962c:	17fffdf5 	b	8e00 <fwp_write+0x4e0>
    9630:	90000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    9634:	d2800042 	mov	x2, #0x2                   	// #2
    9638:	913e6021 	add	x1, x1, #0xf98
    963c:	17fffed6 	b	9194 <fwp_write+0x874>
    9640:	7101fcbf 	cmp	w5, #0x7f
    9644:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9648:	540000e9 	b.ls	9664 <fwp_write+0xd44>  // b.plast
    964c:	aa1503e1 	mov	x1, x21
    9650:	aa1403e0 	mov	x0, x20
    9654:	d2800022 	mov	x2, #0x1                   	// #1
    9658:	39001fe5 	strb	w5, [sp, #7]
    965c:	97ffe7ed 	bl	3610 <buf_put>
    9660:	17ffffb4 	b	9530 <fwp_write+0xc10>
    9664:	d2800203 	mov	x3, #0x10                  	// #16
    9668:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x760>
    966c:	aa0303e1 	mov	x1, x3
    9670:	91006084 	add	x4, x4, #0x18
    9674:	910123f6 	add	x22, sp, #0x48
    9678:	52800042 	mov	w2, #0x2                   	// #2
    967c:	aa1603e0 	mov	x0, x22
    9680:	97ffe440 	bl	2780 <__snprintf_chk@plt>
    9684:	aa1603e0 	mov	x0, x22
    9688:	97ffe406 	bl	26a0 <strlen@plt>
    968c:	aa1603e1 	mov	x1, x22
    9690:	aa0003e2 	mov	x2, x0
    9694:	aa1403e0 	mov	x0, x20
    9698:	97ffe7de 	bl	3610 <buf_put>
    969c:	17ffffa5 	b	9530 <fwp_write+0xc10>
    96a0:	1e604100 	fmov	d0, d8
    96a4:	aa1503e0 	mov	x0, x21
    96a8:	52800221 	mov	w1, #0x11                  	// #17
    96ac:	97ffe91a 	bl	3b14 <fwp_format_g.constprop.0>
    96b0:	17fffe43 	b	8fbc <fwp_write+0x69c>
    96b4:	b9401040 	ldr	w0, [x2, #16]
    96b8:	350003c0 	cbnz	w0, 9730 <fwp_write+0xe10>
    96bc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    96c0:	f947f400 	ldr	x0, [x0, #4072]
    96c4:	f94127e2 	ldr	x2, [sp, #584]
    96c8:	f9400001 	ldr	x1, [x0]
    96cc:	eb010042 	subs	x2, x2, x1
    96d0:	d2800001 	mov	x1, #0x0                   	// #0
    96d4:	54ffd721 	b.ne	91b8 <fwp_write+0x898>  // b.any
    96d8:	f9413bf5 	ldr	x21, [sp, #624]
    96dc:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x760>
    96e0:	f9413ff6 	ldr	x22, [sp, #632]
    96e4:	aa1403e0 	mov	x0, x20
    96e8:	f94143f7 	ldr	x23, [sp, #640]
    96ec:	9101a021 	add	x1, x1, #0x68
    96f0:	f94147f8 	ldr	x24, [sp, #648]
    96f4:	d2800042 	mov	x2, #0x2                   	// #2
    96f8:	17fffd0e 	b	8b30 <fwp_write+0x210>
    96fc:	90000021 	adrp	x1, d000 <fwp_main_thread+0x440>
    9700:	d2800042 	mov	x2, #0x2                   	// #2
    9704:	913e8021 	add	x1, x1, #0xfa0
    9708:	17fffea3 	b	9194 <fwp_write+0x874>
    970c:	f9400a63 	ldr	x3, [x19, #16]
    9710:	8b030021 	add	x1, x1, x3
    9714:	17ffff66 	b	94ac <fwp_write+0xb8c>
    9718:	f9400a61 	ldr	x1, [x19, #16]
    971c:	8b0102a1 	add	x1, x21, x1
    9720:	17fffdb3 	b	8dec <fwp_write+0x4cc>
    9724:	f9400a63 	ldr	x3, [x19, #16]
    9728:	8b030021 	add	x1, x1, x3
    972c:	17ffff56 	b	9484 <fwp_write+0xb64>
    9730:	b9404840 	ldr	w0, [x2, #72]
    9734:	91001ff5 	add	x21, sp, #0x7
    9738:	34ffa360 	cbz	w0, 8ba4 <fwp_write+0x284>
    973c:	52800503 	mov	w3, #0x28                  	// #40
    9740:	aa1403e0 	mov	x0, x20
    9744:	aa1503e1 	mov	x1, x21
    9748:	d2800022 	mov	x2, #0x1                   	// #1
    974c:	39001fe3 	strb	w3, [sp, #7]
    9750:	97ffe7b0 	bl	3610 <buf_put>
    9754:	b9401380 	ldr	w0, [x28, #16]
    9758:	52800038 	mov	w24, #0x1                   	// #1
    975c:	7100001f 	cmp	w0, #0x0
    9760:	54ffa36c 	b.gt	8bcc <fwp_write+0x2ac>
    9764:	17fffd32 	b	8c2c <fwp_write+0x30c>
    9768:	f9014bf9 	str	x25, [sp, #656]
    976c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe2e0>
    9770:	f9014ffa 	str	x26, [sp, #664]
    9774:	f9400676 	ldr	x22, [x19, #8]
    9778:	91104333 	add	x19, x25, #0x410
    977c:	91002273 	add	x19, x19, #0x8
    9780:	937ffed8 	asr	x24, x22, #63
    9784:	aa1802c0 	orr	x0, x22, x24
    9788:	b5000320 	cbnz	x0, 97ec <fwp_write+0xecc>
    978c:	110006b5 	add	w21, w21, #0x1
    9790:	710016bf 	cmp	w21, #0x5
    9794:	54ffffc1 	b.ne	978c <fwp_write+0xe6c>  // b.any
    9798:	b7f80578 	tbnz	x24, #63, 9844 <fwp_write+0xf24>
    979c:	910023f3 	add	x19, sp, #0x8
    97a0:	aa1603e2 	mov	x2, x22
    97a4:	aa1303e0 	mov	x0, x19
    97a8:	d2800003 	mov	x3, #0x0                   	// #0
    97ac:	97ffe57d 	bl	2da0 <fwp_fmt_u128>
    97b0:	910123f5 	add	x21, sp, #0x48
    97b4:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x760>
    97b8:	aa1303e4 	mov	x4, x19
    97bc:	aa1503e0 	mov	x0, x21
    97c0:	91018063 	add	x3, x3, #0x60
    97c4:	d2804002 	mov	x2, #0x200                 	// #512
    97c8:	52800041 	mov	w1, #0x2                   	// #2
    97cc:	97ffe3b9 	bl	26b0 <__sprintf_chk@plt>
    97d0:	aa1503e0 	mov	x0, x21
    97d4:	97ffe3b3 	bl	26a0 <strlen@plt>
    97d8:	aa1503e1 	mov	x1, x21
    97dc:	aa0003e2 	mov	x2, x0
    97e0:	aa1403e0 	mov	x0, x20
    97e4:	97ffe78b 	bl	3610 <buf_put>
    97e8:	17fffe47 	b	9104 <fwp_write+0x7e4>
    97ec:	f9400277 	ldr	x23, [x19]
    97f0:	aa1603e0 	mov	x0, x22
    97f4:	aa1803e1 	mov	x1, x24
    97f8:	aa1703e2 	mov	x2, x23
    97fc:	937ffefa 	asr	x26, x23, #63
    9800:	aa1a03e3 	mov	x3, x26
    9804:	94000f3f 	bl	d500 <__modti3>
    9808:	aa010000 	orr	x0, x0, x1
    980c:	b40002c0 	cbz	x0, 9864 <fwp_write+0xf44>
    9810:	110006b5 	add	w21, w21, #0x1
    9814:	91004273 	add	x19, x19, #0x10
    9818:	710016bf 	cmp	w21, #0x5
    981c:	54fffe81 	b.ne	97ec <fwp_write+0xecc>  // b.any
    9820:	17ffffde 	b	9798 <fwp_write+0xe78>
    9824:	f9400a60 	ldr	x0, [x19, #16]
    9828:	8b000021 	add	x1, x1, x0
    982c:	17fffd75 	b	8e00 <fwp_write+0x4e0>
    9830:	528c29c0 	mov	w0, #0x614e                	// #24910
    9834:	910123f5 	add	x21, sp, #0x48
    9838:	72a009c0 	movk	w0, #0x4e, lsl #16
    983c:	b9004be0 	str	w0, [sp, #72]
    9840:	17fffda2 	b	8ec8 <fwp_write+0x5a8>
    9844:	528005a1 	mov	w1, #0x2d                  	// #45
    9848:	eb1603e2 	negs	x2, x22
    984c:	da1803e3 	ngc	x3, x24
    9850:	910027e0 	add	x0, sp, #0x9
    9854:	910023f3 	add	x19, sp, #0x8
    9858:	390023e1 	strb	w1, [sp, #8]
    985c:	97ffe551 	bl	2da0 <fwp_fmt_u128>
    9860:	17ffffd4 	b	97b0 <fwp_write+0xe90>
    9864:	aa1703e2 	mov	x2, x23
    9868:	aa1a03e3 	mov	x3, x26
    986c:	aa1603e0 	mov	x0, x22
    9870:	aa1803e1 	mov	x1, x24
    9874:	94000e43 	bl	d180 <__divti3>
    9878:	aa0003e2 	mov	x2, x0
    987c:	aa0103e3 	mov	x3, x1
    9880:	b7f80201 	tbnz	x1, #63, 98c0 <fwp_write+0xfa0>
    9884:	910023f3 	add	x19, sp, #0x8
    9888:	aa1303e0 	mov	x0, x19
    988c:	97ffe545 	bl	2da0 <fwp_fmt_u128>
    9890:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9894:	91104339 	add	x25, x25, #0x410
    9898:	910123f5 	add	x21, sp, #0x48
    989c:	aa1303e4 	mov	x4, x19
    98a0:	aa1503e0 	mov	x0, x21
    98a4:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x760>
    98a8:	f8616b25 	ldr	x5, [x25, x1]
    98ac:	91016063 	add	x3, x3, #0x58
    98b0:	d2804002 	mov	x2, #0x200                 	// #512
    98b4:	52800041 	mov	w1, #0x2                   	// #2
    98b8:	97ffe37e 	bl	26b0 <__sprintf_chk@plt>
    98bc:	17ffffc5 	b	97d0 <fwp_write+0xeb0>
    98c0:	528005a4 	mov	w4, #0x2d                  	// #45
    98c4:	eb0003e2 	negs	x2, x0
    98c8:	da0103e3 	ngc	x3, x1
    98cc:	910027e0 	add	x0, sp, #0x9
    98d0:	910023f3 	add	x19, sp, #0x8
    98d4:	390023e4 	strb	w4, [sp, #8]
    98d8:	97ffe532 	bl	2da0 <fwp_fmt_u128>
    98dc:	17ffffed 	b	9890 <fwp_write+0xf70>
    98e0:	f9013bf5 	str	x21, [sp, #624]
    98e4:	f9013ff6 	str	x22, [sp, #632]
    98e8:	f90143f7 	str	x23, [sp, #640]
    98ec:	f90147f8 	str	x24, [sp, #648]
    98f0:	f9014bf9 	str	x25, [sp, #656]
    98f4:	f9014ffa 	str	x26, [sp, #664]
    98f8:	f90153fb 	str	x27, [sp, #672]
    98fc:	f90157fc 	str	x28, [sp, #680]
    9900:	fd015be8 	str	d8, [sp, #688]
    9904:	fd015fe9 	str	d9, [sp, #696]
    9908:	97ffe3c2 	bl	2810 <__stack_chk_fail@plt>
    990c:	d503201f 	nop

0000000000009910 <fwp_hof0.constprop.0>:
    9910:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9914:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    9918:	f947f442 	ldr	x2, [x2, #4072]
    991c:	910003fd 	mov	x29, sp
    9920:	a90153f3 	stp	x19, x20, [sp, #16]
    9924:	a9025bf5 	stp	x21, x22, [sp, #32]
    9928:	a90363f7 	stp	x23, x24, [sp, #48]
    992c:	aa0003f7 	mov	x23, x0
    9930:	a9046bf9 	stp	x25, x26, [sp, #64]
    9934:	a90573fb 	stp	x27, x28, [sp, #80]
    9938:	d10243ff 	sub	sp, sp, #0x90
    993c:	f9400040 	ldr	x0, [x2]
    9940:	f81f83a0 	stur	x0, [x29, #-8]
    9944:	d2800000 	mov	x0, #0x0                   	// #0
    9948:	b4002ee1 	cbz	x1, 9f24 <fwp_hof0.constprop.0+0x614>
    994c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9950:	9100401c 	add	x28, x0, #0x10
    9954:	9100a39c 	add	x28, x28, #0x28
    9958:	f00000a0 	adrp	x0, 20000 <__data_start>
    995c:	aa0103fa 	mov	x26, x1
    9960:	d10083b4 	sub	x20, x29, #0x20
    9964:	91018015 	add	x21, x0, #0x60
    9968:	aa1c03f8 	mov	x24, x28
    996c:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9970:	91190002 	add	x2, x0, #0x640
    9974:	f949d841 	ldr	x1, [x2, #5040]
    9978:	f949ec40 	ldr	x0, [x2, #5080]
    997c:	cb0102e1 	sub	x1, x23, x1
    9980:	eb00403f 	cmp	x1, x0, lsl #16
    9984:	540003c2 	b.cs	99fc <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9988:	d350fc20 	lsr	x0, x1, #16
    998c:	f949fc44 	ldr	x4, [x2, #5112]
    9990:	8b000800 	add	x0, x0, x0, lsl #2
    9994:	d37df002 	lsl	x2, x0, #3
    9998:	8b020083 	add	x3, x4, x2
    999c:	f9401060 	ldr	x0, [x3, #32]
    99a0:	b40002e0 	cbz	x0, 99fc <fwp_hof0.constprop.0+0xec>
    99a4:	38626882 	ldrb	w2, [x4, x2]
    99a8:	7100085f 	cmp	w2, #0x2
    99ac:	54005600 	b.eq	a46c <fwp_hof0.constprop.0+0xb5c>  // b.none
    99b0:	7100045f 	cmp	w2, #0x1
    99b4:	54000241 	b.ne	99fc <fwp_hof0.constprop.0+0xec>  // b.any
    99b8:	29430864 	ldp	w4, w2, [x3, #24]
    99bc:	92403c21 	and	x1, x1, #0xffff
    99c0:	9b047c21 	mul	x1, x1, x4
    99c4:	d360fc21 	lsr	x1, x1, #32
    99c8:	eb02003f 	cmp	x1, x2
    99cc:	54000182 	b.cs	99fc <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    99d0:	8b010000 	add	x0, x0, x1
    99d4:	39400001 	ldrb	w1, [x0]
    99d8:	34000121 	cbz	w1, 99fc <fwp_hof0.constprop.0+0xec>
    99dc:	f00000a2 	adrp	x2, 20000 <__data_start>
    99e0:	91018042 	add	x2, x2, #0x60
    99e4:	b9413043 	ldr	w3, [x2, #304]
    99e8:	35005583 	cbnz	w3, a498 <fwp_hof0.constprop.0+0xb88>
    99ec:	7103f43f 	cmp	w1, #0xfd
    99f0:	54005ae8 	b.hi	a54c <fwp_hof0.constprop.0+0xc3c>  // b.pmore
    99f4:	11000421 	add	w1, w1, #0x1
    99f8:	39000001 	strb	w1, [x0]
    99fc:	aa1703f9 	mov	x25, x23
    9a00:	a938dfba 	stp	x26, x23, [x29, #-120]
    9a04:	aa1803fa 	mov	x26, x24
    9a08:	d28018f3 	mov	x19, #0xc7                  	// #199
    9a0c:	f81983b3 	stur	x19, [x29, #-104]
    9a10:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a14:	91004000 	add	x0, x0, #0x10
    9a18:	f9406aa3 	ldr	x3, [x21, #208]
    9a1c:	9100a005 	add	x5, x0, #0x28
    9a20:	b9402802 	ldr	w2, [x0, #40]
    9a24:	d37be842 	lsl	x2, x2, #5
    9a28:	8b02007b 	add	x27, x3, x2
    9a2c:	f9400f61 	ldr	x1, [x27, #24]
    9a30:	f81e03b9 	stur	x25, [x29, #-32]
    9a34:	b4005221 	cbz	x1, a478 <fwp_hof0.constprop.0+0xb68>
    9a38:	f9400c20 	ldr	x0, [x1, #24]
    9a3c:	b4004560 	cbz	x0, a2e8 <fwp_hof0.constprop.0+0x9d8>
    9a40:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9a44:	91190002 	add	x2, x0, #0x640
    9a48:	f949d841 	ldr	x1, [x2, #5040]
    9a4c:	f949ec40 	ldr	x0, [x2, #5080]
    9a50:	cb010341 	sub	x1, x26, x1
    9a54:	eb00403f 	cmp	x1, x0, lsl #16
    9a58:	540003e2 	b.cs	9ad4 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9a5c:	d350fc20 	lsr	x0, x1, #16
    9a60:	f949fc45 	ldr	x5, [x2, #5112]
    9a64:	8b000800 	add	x0, x0, x0, lsl #2
    9a68:	d37df002 	lsl	x2, x0, #3
    9a6c:	8b0200a3 	add	x3, x5, x2
    9a70:	f9401060 	ldr	x0, [x3, #32]
    9a74:	b4000300 	cbz	x0, 9ad4 <fwp_hof0.constprop.0+0x1c4>
    9a78:	386268a2 	ldrb	w2, [x5, x2]
    9a7c:	7100085f 	cmp	w2, #0x2
    9a80:	540049c0 	b.eq	a3b8 <fwp_hof0.constprop.0+0xaa8>  // b.none
    9a84:	7100045f 	cmp	w2, #0x1
    9a88:	54000261 	b.ne	9ad4 <fwp_hof0.constprop.0+0x1c4>  // b.any
    9a8c:	29430865 	ldp	w5, w2, [x3, #24]
    9a90:	92403c21 	and	x1, x1, #0xffff
    9a94:	9b057c21 	mul	x1, x1, x5
    9a98:	d360fc21 	lsr	x1, x1, #32
    9a9c:	eb02003f 	cmp	x1, x2
    9aa0:	540001a2 	b.cs	9ad4 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9aa4:	8b010000 	add	x0, x0, x1
    9aa8:	39400001 	ldrb	w1, [x0]
    9aac:	34000141 	cbz	w1, 9ad4 <fwp_hof0.constprop.0+0x1c4>
    9ab0:	b94132a2 	ldr	w2, [x21, #304]
    9ab4:	34000082 	cbz	w2, 9ac4 <fwp_hof0.constprop.0+0x1b4>
    9ab8:	f940aea2 	ldr	x2, [x21, #344]
    9abc:	91000442 	add	x2, x2, #0x1
    9ac0:	f900aea2 	str	x2, [x21, #344]
    9ac4:	7103f43f 	cmp	w1, #0xfd
    9ac8:	54004c28 	b.hi	a44c <fwp_hof0.constprop.0+0xb3c>  // b.pmore
    9acc:	11000421 	add	w1, w1, #0x1
    9ad0:	39000001 	strb	w1, [x0]
    9ad4:	aa1a03f9 	mov	x25, x26
    9ad8:	aa1a03e0 	mov	x0, x26
    9adc:	aa1b03e3 	mov	x3, x27
    9ae0:	52800037 	mov	w23, #0x1                   	// #1
    9ae4:	90000381 	adrp	x1, 79000 <fwp_root_context+0xba0>
    9ae8:	91190036 	add	x22, x1, #0x640
    9aec:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    9af0:	f81b03b6 	stur	x22, [x29, #-80]
    9af4:	b81cc3b7 	stur	w23, [x29, #-52]
    9af8:	f81d03b4 	stur	x20, [x29, #-48]
    9afc:	b9400401 	ldr	w1, [x0, #4]
    9b00:	b9400078 	ldr	w24, [x3]
    9b04:	b85cc3a0 	ldur	w0, [x29, #-52]
    9b08:	4b010318 	sub	w24, w24, w1
    9b0c:	6b17031f 	cmp	w24, w23
    9b10:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    9b14:	6b0000ff 	cmp	w7, w0
    9b18:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    9b1c:	b81c83a0 	stur	w0, [x29, #-56]
    9b20:	6b0000e2 	subs	w2, w7, w0
    9b24:	54000120 	b.eq	9b48 <fwp_hof0.constprop.0+0x238>  // b.none
    9b28:	f9400c63 	ldr	x3, [x3, #24]
    9b2c:	0b000021 	add	w1, w1, w0
    9b30:	f85d03a4 	ldur	x4, [x29, #-48]
    9b34:	b81d83a7 	stur	w7, [x29, #-40]
    9b38:	f9400863 	ldr	x3, [x3, #16]
    9b3c:	8b204c80 	add	x0, x4, w0, uxtw #3
    9b40:	d63f0060 	blr	x3
    9b44:	b85d83a7 	ldur	w7, [x29, #-40]
    9b48:	f9406aa0 	ldr	x0, [x21, #208]
    9b4c:	aa1903e6 	mov	x6, x25
    9b50:	b9400323 	ldr	w3, [x25]
    9b54:	2a0703f4 	mov	w20, w7
    9b58:	f85d03bb 	ldur	x27, [x29, #-48]
    9b5c:	aa1903fc 	mov	x28, x25
    9b60:	8b03141a 	add	x26, x0, x3, lsl #5
    9b64:	f9400f40 	ldr	x0, [x26, #24]
    9b68:	b4002100 	cbz	x0, 9f88 <fwp_hof0.constprop.0+0x678>
    9b6c:	f85b03bc 	ldur	x28, [x29, #-80]
    9b70:	29371fb7 	stp	w23, w7, [x29, #-72]
    9b74:	aa1a03f7 	mov	x23, x26
    9b78:	b81c03b8 	stur	w24, [x29, #-64]
    9b7c:	aa1b03f8 	mov	x24, x27
    9b80:	14000012 	b	9bc8 <fwp_hof0.constprop.0+0x2b8>
    9b84:	f9400001 	ldr	x1, [x0]
    9b88:	aa1803e0 	mov	x0, x24
    9b8c:	d63f0020 	blr	x1
    9b90:	aa0003fb 	mov	x27, x0
    9b94:	aa1903e0 	mov	x0, x25
    9b98:	97fff15e 	bl	6110 <fwp_closure_drop>
    9b9c:	6b13029f 	cmp	w20, w19
    9ba0:	54000cc0 	b.eq	9d38 <fwp_hof0.constprop.0+0x428>  // b.none
    9ba4:	f9406aa0 	ldr	x0, [x21, #208]
    9ba8:	8b334f18 	add	x24, x24, w19, uxtw #3
    9bac:	b9400363 	ldr	w3, [x27]
    9bb0:	4b1a02d4 	sub	w20, w22, w26
    9bb4:	aa1b03e6 	mov	x6, x27
    9bb8:	8b031417 	add	x23, x0, x3, lsl #5
    9bbc:	f9400ee0 	ldr	x0, [x23, #24]
    9bc0:	b4001dc0 	cbz	x0, 9f78 <fwp_hof0.constprop.0+0x668>
    9bc4:	aa1b03f9 	mov	x25, x27
    9bc8:	b94004c1 	ldr	w1, [x6, #4]
    9bcc:	b94002fa 	ldr	w26, [x23]
    9bd0:	0b010296 	add	w22, w20, w1
    9bd4:	6b16035f 	cmp	w26, w22
    9bd8:	540024a8 	b.hi	a06c <fwp_hof0.constprop.0+0x75c>  // b.pmore
    9bdc:	7100003f 	cmp	w1, #0x0
    9be0:	4b010353 	sub	w19, w26, w1
    9be4:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9be8:	54fffce1 	b.ne	9b84 <fwp_hof0.constprop.0+0x274>  // b.any
    9bec:	7100035f 	cmp	w26, #0x0
    9bf0:	910003e2 	mov	x2, sp
    9bf4:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    9bf8:	f81d83a2 	stur	x2, [x29, #-40]
    9bfc:	d37df084 	lsl	x4, x4, #3
    9c00:	91003c84 	add	x4, x4, #0xf
    9c04:	92704c87 	and	x7, x4, #0xfffff0000
    9c08:	927c7c84 	and	x4, x4, #0xffffffff0
    9c0c:	cb2763e7 	sub	x7, sp, x7
    9c10:	eb2763ff 	cmp	sp, x7
    9c14:	540000a0 	b.eq	9c28 <fwp_hof0.constprop.0+0x318>  // b.none
    9c18:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9c1c:	f90203ff 	str	xzr, [sp, #1024]
    9c20:	eb2763ff 	cmp	sp, x7
    9c24:	54ffffa1 	b.ne	9c18 <fwp_hof0.constprop.0+0x308>  // b.any
    9c28:	92403c84 	and	x4, x4, #0xffff
    9c2c:	cb2463ff 	sub	sp, sp, x4
    9c30:	f90003ff 	str	xzr, [sp]
    9c34:	f110009f 	cmp	x4, #0x400
    9c38:	54000043 	b.cc	9c40 <fwp_hof0.constprop.0+0x330>  // b.lo, b.ul, b.last
    9c3c:	f90203ff 	str	xzr, [sp, #1024]
    9c40:	910043fb 	add	x27, sp, #0x10
    9c44:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9c48:	910020c9 	add	x9, x6, #0x8
    9c4c:	d2800004 	mov	x4, #0x0                   	// #0
    9c50:	340000e1 	cbz	w1, 9c6c <fwp_hof0.constprop.0+0x35c>
    9c54:	d503201f 	nop
    9c58:	f8646922 	ldr	x2, [x9, x4]
    9c5c:	f8246b62 	str	x2, [x27, x4]
    9c60:	91002084 	add	x4, x4, #0x8
    9c64:	eb04015f 	cmp	x10, x4
    9c68:	54ffff81 	b.ne	9c58 <fwp_hof0.constprop.0+0x348>  // b.any
    9c6c:	2a1303ea 	mov	w10, w19
    9c70:	d2800004 	mov	x4, #0x0                   	// #0
    9c74:	340000f3 	cbz	w19, 9c90 <fwp_hof0.constprop.0+0x380>
    9c78:	0b040022 	add	w2, w1, w4
    9c7c:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9c80:	91000484 	add	x4, x4, #0x1
    9c84:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9c88:	eb04015f 	cmp	x10, x4
    9c8c:	54ffff61 	b.ne	9c78 <fwp_hof0.constprop.0+0x368>  // b.any
    9c90:	f949db81 	ldr	x1, [x28, #5040]
    9c94:	f949ef84 	ldr	x4, [x28, #5080]
    9c98:	cb010321 	sub	x1, x25, x1
    9c9c:	eb04403f 	cmp	x1, x4, lsl #16
    9ca0:	540002e2 	b.cs	9cfc <fwp_hof0.constprop.0+0x3ec>  // b.hs, b.nlast
    9ca4:	d350fc24 	lsr	x4, x1, #16
    9ca8:	f949ff8a 	ldr	x10, [x28, #5112]
    9cac:	8b040884 	add	x4, x4, x4, lsl #2
    9cb0:	d37df084 	lsl	x4, x4, #3
    9cb4:	8b040149 	add	x9, x10, x4
    9cb8:	f9401128 	ldr	x8, [x9, #32]
    9cbc:	b4000208 	cbz	x8, 9cfc <fwp_hof0.constprop.0+0x3ec>
    9cc0:	38646944 	ldrb	w4, [x10, x4]
    9cc4:	7100089f 	cmp	w4, #0x2
    9cc8:	54001520 	b.eq	9f6c <fwp_hof0.constprop.0+0x65c>  // b.none
    9ccc:	7100049f 	cmp	w4, #0x1
    9cd0:	54000161 	b.ne	9cfc <fwp_hof0.constprop.0+0x3ec>  // b.any
    9cd4:	2943112a 	ldp	w10, w4, [x9, #24]
    9cd8:	92403c21 	and	x1, x1, #0xffff
    9cdc:	9b0a7c21 	mul	x1, x1, x10
    9ce0:	d360fc21 	lsr	x1, x1, #32
    9ce4:	eb04003f 	cmp	x1, x4
    9ce8:	540000a2 	b.cs	9cfc <fwp_hof0.constprop.0+0x3ec>  // b.hs, b.nlast
    9cec:	8b010108 	add	x8, x8, x1
    9cf0:	39400101 	ldrb	w1, [x8]
    9cf4:	7100043f 	cmp	w1, #0x1
    9cf8:	54001360 	b.eq	9f64 <fwp_hof0.constprop.0+0x654>  // b.none
    9cfc:	f9400404 	ldr	x4, [x0, #8]
    9d00:	52800021 	mov	w1, #0x1                   	// #1
    9d04:	aa1903e0 	mov	x0, x25
    9d08:	d63f0080 	blr	x4
    9d0c:	f9400ee1 	ldr	x1, [x23, #24]
    9d10:	aa1b03e0 	mov	x0, x27
    9d14:	f9400021 	ldr	x1, [x1]
    9d18:	d63f0020 	blr	x1
    9d1c:	aa0003fb 	mov	x27, x0
    9d20:	f85d83a0 	ldur	x0, [x29, #-40]
    9d24:	9100001f 	mov	sp, x0
    9d28:	aa1903e0 	mov	x0, x25
    9d2c:	97fff0f9 	bl	6110 <fwp_closure_drop>
    9d30:	6b13029f 	cmp	w20, w19
    9d34:	54fff381 	b.ne	9ba4 <fwp_hof0.constprop.0+0x294>  // b.any
    9d38:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9d3c:	aa1b03f9 	mov	x25, x27
    9d40:	b85c03b8 	ldur	w24, [x29, #-64]
    9d44:	6b17031f 	cmp	w24, w23
    9d48:	540014c3 	b.cc	9fe0 <fwp_hof0.constprop.0+0x6d0>  // b.lo, b.ul, b.last
    9d4c:	f85983a0 	ldur	x0, [x29, #-104]
    9d50:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9d54:	f1000400 	subs	x0, x0, #0x1
    9d58:	f81983a0 	stur	x0, [x29, #-104]
    9d5c:	54ffe5a1 	b.ne	9a10 <fwp_hof0.constprop.0+0x100>  // b.any
    9d60:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe2e0>
    9d64:	91104042 	add	x2, x2, #0x410
    9d68:	aa1903e1 	mov	x1, x25
    9d6c:	aa1403e0 	mov	x0, x20
    9d70:	aa1a03f8 	mov	x24, x26
    9d74:	aa1903fb 	mov	x27, x25
    9d78:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9d7c:	91014042 	add	x2, x2, #0x50
    9d80:	52800023 	mov	w3, #0x1                   	// #1
    9d84:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9d88:	f81f03bf 	stur	xzr, [x29, #-16]
    9d8c:	97fffae5 	bl	8920 <fwp_write>
    9d90:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    9d94:	90000020 	adrp	x0, d000 <fwp_main_thread+0x440>
    9d98:	91238000 	add	x0, x0, #0x8e0
    9d9c:	f10002df 	cmp	x22, #0x0
    9da0:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9da4:	b1002b3f 	cmn	x25, #0xa
    9da8:	54003cc8 	b.hi	a540 <fwp_hof0.constprop.0+0xc30>  // b.pmore
    9dac:	91002720 	add	x0, x25, #0x9
    9db0:	52800021 	mov	w1, #0x1                   	// #1
    9db4:	97ffecb7 	bl	5090 <fwp_heap_alloc>
    9db8:	aa0003f3 	mov	x19, x0
    9dbc:	aa1603e1 	mov	x1, x22
    9dc0:	aa0003f6 	mov	x22, x0
    9dc4:	aa1903e2 	mov	x2, x25
    9dc8:	f80086d9 	str	x25, [x22], #8
    9dcc:	8b190279 	add	x25, x19, x25
    9dd0:	aa1603e0 	mov	x0, x22
    9dd4:	97ffe223 	bl	2660 <memcpy@plt>
    9dd8:	3900233f 	strb	wzr, [x25, #8]
    9ddc:	f85e03a0 	ldur	x0, [x29, #-32]
    9de0:	97ffe2bc 	bl	28d0 <free@plt>
    9de4:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9de8:	91190002 	add	x2, x0, #0x640
    9dec:	f949d841 	ldr	x1, [x2, #5040]
    9df0:	f949ec40 	ldr	x0, [x2, #5080]
    9df4:	cb010261 	sub	x1, x19, x1
    9df8:	eb00403f 	cmp	x1, x0, lsl #16
    9dfc:	54000322 	b.cs	9e60 <fwp_hof0.constprop.0+0x550>  // b.hs, b.nlast
    9e00:	d350fc20 	lsr	x0, x1, #16
    9e04:	f949fc43 	ldr	x3, [x2, #5112]
    9e08:	8b000800 	add	x0, x0, x0, lsl #2
    9e0c:	d37df002 	lsl	x2, x0, #3
    9e10:	8b020060 	add	x0, x3, x2
    9e14:	f9401019 	ldr	x25, [x0, #32]
    9e18:	b4000259 	cbz	x25, 9e60 <fwp_hof0.constprop.0+0x550>
    9e1c:	38626862 	ldrb	w2, [x3, x2]
    9e20:	7100085f 	cmp	w2, #0x2
    9e24:	54003520 	b.eq	a4c8 <fwp_hof0.constprop.0+0xbb8>  // b.none
    9e28:	7100045f 	cmp	w2, #0x1
    9e2c:	540001a1 	b.ne	9e60 <fwp_hof0.constprop.0+0x550>  // b.any
    9e30:	29430002 	ldp	w2, w0, [x0, #24]
    9e34:	92403c21 	and	x1, x1, #0xffff
    9e38:	9b027c21 	mul	x1, x1, x2
    9e3c:	d360fc21 	lsr	x1, x1, #32
    9e40:	eb00003f 	cmp	x1, x0
    9e44:	540000e2 	b.cs	9e60 <fwp_hof0.constprop.0+0x550>  // b.hs, b.nlast
    9e48:	8b010339 	add	x25, x25, x1
    9e4c:	39400320 	ldrb	w0, [x25]
    9e50:	7103fc1f 	cmp	w0, #0xff
    9e54:	54003820 	b.eq	a558 <fwp_hof0.constprop.0+0xc48>  // b.none
    9e58:	52800020 	mov	w0, #0x1                   	// #1
    9e5c:	39000320 	strb	w0, [x25]
    9e60:	aa1b03e0 	mov	x0, x27
    9e64:	97fff04f 	bl	5fa0 <fwp_drop0>
    9e68:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e6c:	91018003 	add	x3, x0, #0x60
    9e70:	f9400262 	ldr	x2, [x19]
    9e74:	aa1603e0 	mov	x0, x22
    9e78:	aa0303f6 	mov	x22, x3
    9e7c:	d2800021 	mov	x1, #0x1                   	// #1
    9e80:	f9404863 	ldr	x3, [x3, #144]
    9e84:	97ffe2a3 	bl	2910 <fwrite@plt>
    9e88:	f9404ac1 	ldr	x1, [x22, #144]
    9e8c:	52800140 	mov	w0, #0xa                   	// #10
    9e90:	97ffe228 	bl	2730 <fputc@plt>
    9e94:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9e98:	91190002 	add	x2, x0, #0x640
    9e9c:	f949d841 	ldr	x1, [x2, #5040]
    9ea0:	f949ec40 	ldr	x0, [x2, #5080]
    9ea4:	cb010261 	sub	x1, x19, x1
    9ea8:	eb00403f 	cmp	x1, x0, lsl #16
    9eac:	54000382 	b.cs	9f1c <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    9eb0:	d350fc20 	lsr	x0, x1, #16
    9eb4:	f949fc43 	ldr	x3, [x2, #5112]
    9eb8:	8b000800 	add	x0, x0, x0, lsl #2
    9ebc:	d37df000 	lsl	x0, x0, #3
    9ec0:	8b000062 	add	x2, x3, x0
    9ec4:	f9401056 	ldr	x22, [x2, #32]
    9ec8:	b40002b6 	cbz	x22, 9f1c <fwp_hof0.constprop.0+0x60c>
    9ecc:	38606860 	ldrb	w0, [x3, x0]
    9ed0:	7100081f 	cmp	w0, #0x2
    9ed4:	54002f40 	b.eq	a4bc <fwp_hof0.constprop.0+0xbac>  // b.none
    9ed8:	7100041f 	cmp	w0, #0x1
    9edc:	54000201 	b.ne	9f1c <fwp_hof0.constprop.0+0x60c>  // b.any
    9ee0:	29430043 	ldp	w3, w0, [x2, #24]
    9ee4:	92403c21 	and	x1, x1, #0xffff
    9ee8:	9b037c21 	mul	x1, x1, x3
    9eec:	d360fc21 	lsr	x1, x1, #32
    9ef0:	eb00003f 	cmp	x1, x0
    9ef4:	54000142 	b.cs	9f1c <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    9ef8:	8b0102d6 	add	x22, x22, x1
    9efc:	394002c0 	ldrb	w0, [x22]
    9f00:	340000e0 	cbz	w0, 9f1c <fwp_hof0.constprop.0+0x60c>
    9f04:	7100041f 	cmp	w0, #0x1
    9f08:	54002d00 	b.eq	a4a8 <fwp_hof0.constprop.0+0xb98>  // b.none
    9f0c:	7103fc1f 	cmp	w0, #0xff
    9f10:	54002e20 	b.eq	a4d4 <fwp_hof0.constprop.0+0xbc4>  // b.none
    9f14:	51000400 	sub	w0, w0, #0x1
    9f18:	390002c0 	strb	w0, [x22]
    9f1c:	f9400b5a 	ldr	x26, [x26, #16]
    9f20:	b5ffd27a 	cbnz	x26, 996c <fwp_hof0.constprop.0+0x5c>
    9f24:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9f28:	f947f400 	ldr	x0, [x0, #4072]
    9f2c:	f85f83a2 	ldur	x2, [x29, #-8]
    9f30:	f9400001 	ldr	x1, [x0]
    9f34:	eb010042 	subs	x2, x2, x1
    9f38:	d2800001 	mov	x1, #0x0                   	// #0
    9f3c:	540030c1 	b.ne	a554 <fwp_hof0.constprop.0+0xc44>  // b.any
    9f40:	910003bf 	mov	sp, x29
    9f44:	d2800000 	mov	x0, #0x0                   	// #0
    9f48:	a94153f3 	ldp	x19, x20, [sp, #16]
    9f4c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9f50:	a94363f7 	ldp	x23, x24, [sp, #48]
    9f54:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9f58:	a94573fb 	ldp	x27, x28, [sp, #80]
    9f5c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9f60:	d65f03c0 	ret
    9f64:	b90004df 	str	wzr, [x6, #4]
    9f68:	17ffff69 	b	9d0c <fwp_hof0.constprop.0+0x3fc>
    9f6c:	72003c3f 	tst	w1, #0xffff
    9f70:	54ffec61 	b.ne	9cfc <fwp_hof0.constprop.0+0x3ec>  // b.any
    9f74:	17ffff5f 	b	9cf0 <fwp_hof0.constprop.0+0x3e0>
    9f78:	aa1b03fc 	mov	x28, x27
    9f7c:	aa1803fb 	mov	x27, x24
    9f80:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9f84:	b85c03b8 	ldur	w24, [x29, #-64]
    9f88:	aa1c03e0 	mov	x0, x28
    9f8c:	b81d83a7 	stur	w7, [x29, #-40]
    9f90:	97ffee7d 	bl	5984 <fwp_rc_share>
    9f94:	b85d83a7 	ldur	w7, [x29, #-40]
    9f98:	34000134 	cbz	w20, 9fbc <fwp_hof0.constprop.0+0x6ac>
    9f9c:	aa1b03f6 	mov	x22, x27
    9fa0:	8b344f73 	add	x19, x27, w20, uxtw #3
    9fa4:	2a0703f9 	mov	w25, w7
    9fa8:	f84086c0 	ldr	x0, [x22], #8
    9fac:	97ffee76 	bl	5984 <fwp_rc_share>
    9fb0:	eb16027f 	cmp	x19, x22
    9fb4:	54ffffa1 	b.ne	9fa8 <fwp_hof0.constprop.0+0x698>  // b.any
    9fb8:	2a1903e7 	mov	w7, w25
    9fbc:	aa1b03e2 	mov	x2, x27
    9fc0:	2a1403e1 	mov	w1, w20
    9fc4:	aa1c03e0 	mov	x0, x28
    9fc8:	b81d83a7 	stur	w7, [x29, #-40]
    9fcc:	97ffec92 	bl	5214 <fwp_apply>
    9fd0:	aa0003f9 	mov	x25, x0
    9fd4:	b85d83a7 	ldur	w7, [x29, #-40]
    9fd8:	6b17031f 	cmp	w24, w23
    9fdc:	54ffeb82 	b.cs	9d4c <fwp_hof0.constprop.0+0x43c>  // b.hs, b.nlast
    9fe0:	f9406aa1 	ldr	x1, [x21, #208]
    9fe4:	4b0702f7 	sub	w23, w23, w7
    9fe8:	b9400323 	ldr	w3, [x25]
    9fec:	f85d03a0 	ldur	x0, [x29, #-48]
    9ff0:	8b031423 	add	x3, x1, x3, lsl #5
    9ff4:	b85c83a2 	ldur	w2, [x29, #-56]
    9ff8:	8b274c00 	add	x0, x0, w7, uxtw #3
    9ffc:	f81d03a0 	stur	x0, [x29, #-48]
    a000:	f9400c61 	ldr	x1, [x3, #24]
    a004:	b85cc3a0 	ldur	w0, [x29, #-52]
    a008:	4b020000 	sub	w0, w0, w2
    a00c:	b81cc3a0 	stur	w0, [x29, #-52]
    a010:	aa1903e0 	mov	x0, x25
    a014:	b5ffd741 	cbnz	x1, 9afc <fwp_hof0.constprop.0+0x1ec>
    a018:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    a01c:	aa1903e0 	mov	x0, x25
    a020:	97ffee59 	bl	5984 <fwp_rc_share>
    a024:	34000117 	cbz	w23, a044 <fwp_hof0.constprop.0+0x734>
    a028:	f85d03b8 	ldur	x24, [x29, #-48]
    a02c:	d2800016 	mov	x22, #0x0                   	// #0
    a030:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    a034:	910006d6 	add	x22, x22, #0x1
    a038:	97ffee53 	bl	5984 <fwp_rc_share>
    a03c:	6b1602ff 	cmp	w23, w22
    a040:	54ffff88 	b.hi	a030 <fwp_hof0.constprop.0+0x720>  // b.pmore
    a044:	f85d03a2 	ldur	x2, [x29, #-48]
    a048:	aa1903e0 	mov	x0, x25
    a04c:	2a1703e1 	mov	w1, w23
    a050:	97ffec71 	bl	5214 <fwp_apply>
    a054:	aa0003f9 	mov	x25, x0
    a058:	f85983a0 	ldur	x0, [x29, #-104]
    a05c:	f1000400 	subs	x0, x0, #0x1
    a060:	f81983a0 	stur	x0, [x29, #-104]
    a064:	54ffcd61 	b.ne	9a10 <fwp_hof0.constprop.0+0x100>  // b.any
    a068:	17ffff3e 	b	9d60 <fwp_hof0.constprop.0+0x450>
    a06c:	b94132ab 	ldr	w11, [x21, #304]
    a070:	110006c0 	add	w0, w22, #0x1
    a074:	aa1703fa 	mov	x26, x23
    a078:	aa1803fb 	mov	x27, x24
    a07c:	29771fb7 	ldp	w23, w7, [x29, #-72]
    a080:	2a0103fc 	mov	w28, w1
    a084:	b85c03b8 	ldur	w24, [x29, #-64]
    a088:	d37df000 	lsl	x0, x0, #3
    a08c:	340000ab 	cbz	w11, a0a0 <fwp_hof0.constprop.0+0x790>
    a090:	a95386a9 	ldp	x9, x1, [x21, #312]
    a094:	91000529 	add	x9, x9, #0x1
    a098:	8b000021 	add	x1, x1, x0
    a09c:	a91386a9 	stp	x9, x1, [x21, #312]
    a0a0:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a0a4:	9119002a 	add	x10, x1, #0x640
    a0a8:	f140101f 	cmp	x0, #0x4, lsl #12
    a0ac:	b953a541 	ldr	w1, [x10, #5028]
    a0b0:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a0b4:	540019a0 	b.eq	a3e8 <fwp_hof0.constprop.0+0xad8>  // b.none
    a0b8:	91003c01 	add	x1, x0, #0xf
    a0bc:	8b411141 	add	x1, x10, x1, lsr #4
    a0c0:	397e8021 	ldrb	w1, [x1, #4000]
    a0c4:	910f002c 	add	x12, x1, #0x3c0
    a0c8:	8b010429 	add	x9, x1, x1, lsl #1
    a0cc:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    a0d0:	8b090d4d 	add	x13, x10, x9, lsl #3
    a0d4:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    a0d8:	2a0c03e1 	mov	w1, w12
    a0dc:	b4001753 	cbz	x19, a3c4 <fwp_hof0.constprop.0+0xab4>
    a0e0:	f940026d 	ldr	x13, [x19]
    a0e4:	aa2d03ed 	mvn	x13, x13
    a0e8:	f829794d 	str	x13, [x10, x9, lsl #3]
    a0ec:	eb01001f 	cmp	x0, x1
    a0f0:	540000c2 	b.cs	a108 <fwp_hof0.constprop.0+0x7f8>  // b.hs, b.nlast
    a0f4:	d503201f 	nop
    a0f8:	f8206a7f 	str	xzr, [x19, x0]
    a0fc:	91002000 	add	x0, x0, #0x8
    a100:	eb00003f 	cmp	x1, x0
    a104:	54ffffa8 	b.hi	a0f8 <fwp_hof0.constprop.0+0x7e8>  // b.pmore
    a108:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a10c:	91190009 	add	x9, x0, #0x640
    a110:	f94a1120 	ldr	x0, [x9, #5152]
    a114:	ab010000 	adds	x0, x0, x1
    a118:	540020c2 	b.cs	a530 <fwp_hof0.constprop.0+0xc20>  // b.hs, b.nlast
    a11c:	f94a1521 	ldr	x1, [x9, #5160]
    a120:	f90a1120 	str	x0, [x9, #5152]
    a124:	eb01001f 	cmp	x0, x1
    a128:	54000049 	b.ls	a130 <fwp_hof0.constprop.0+0x820>  // b.plast
    a12c:	f90a1520 	str	x0, [x9, #5160]
    a130:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a134:	91190000 	add	x0, x0, #0x640
    a138:	1e630181 	ucvtf	d1, w12
    a13c:	fd4a1c00 	ldr	d0, [x0, #5176]
    a140:	1e612800 	fadd	d0, d0, d1
    a144:	fd0a1c00 	str	d0, [x0, #5176]
    a148:	3400012b 	cbz	w11, a16c <fwp_hof0.constprop.0+0x85c>
    a14c:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a150:	91190000 	add	x0, x0, #0x640
    a154:	6d5486a2 	ldp	d2, d1, [x21, #328]
    a158:	fd4a1000 	ldr	d0, [x0, #5152]
    a15c:	7e61d800 	ucvtf	d0, d0
    a160:	1e623800 	fsub	d0, d0, d2
    a164:	1e612010 	fcmpe	d0, d1
    a168:	540016ec 	b.gt	a444 <fwp_hof0.constprop.0+0xb34>
    a16c:	b94000c0 	ldr	w0, [x6]
    a170:	29005a60 	stp	w0, w22, [x19]
    a174:	3400013c 	cbz	w28, a198 <fwp_hof0.constprop.0+0x888>
    a178:	910020c1 	add	x1, x6, #0x8
    a17c:	d37d7f82 	ubfiz	x2, x28, #3, #32
    a180:	91002260 	add	x0, x19, #0x8
    a184:	b81c03a7 	stur	w7, [x29, #-64]
    a188:	f81d83a6 	stur	x6, [x29, #-40]
    a18c:	97ffe13d 	bl	2680 <memmove@plt>
    a190:	f85d83a6 	ldur	x6, [x29, #-40]
    a194:	b85c03a7 	ldur	w7, [x29, #-64]
    a198:	2a1403e9 	mov	w9, w20
    a19c:	d2800001 	mov	x1, #0x0                   	// #0
    a1a0:	34000134 	cbz	w20, a1c4 <fwp_hof0.constprop.0+0x8b4>
    a1a4:	d503201f 	nop
    a1a8:	0b010380 	add	w0, w28, w1
    a1ac:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    a1b0:	8b000e60 	add	x0, x19, x0, lsl #3
    a1b4:	91000421 	add	x1, x1, #0x1
    a1b8:	f9000402 	str	x2, [x0, #8]
    a1bc:	eb01013f 	cmp	x9, x1
    a1c0:	54ffff41 	b.ne	a1a8 <fwp_hof0.constprop.0+0x898>  // b.any
    a1c4:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a1c8:	91190002 	add	x2, x0, #0x640
    a1cc:	f949d840 	ldr	x0, [x2, #5040]
    a1d0:	f949ec41 	ldr	x1, [x2, #5080]
    a1d4:	cb000320 	sub	x0, x25, x0
    a1d8:	eb01401f 	cmp	x0, x1, lsl #16
    a1dc:	540002e2 	b.cs	a238 <fwp_hof0.constprop.0+0x928>  // b.hs, b.nlast
    a1e0:	d350fc01 	lsr	x1, x0, #16
    a1e4:	f949fc45 	ldr	x5, [x2, #5112]
    a1e8:	8b010821 	add	x1, x1, x1, lsl #2
    a1ec:	d37df021 	lsl	x1, x1, #3
    a1f0:	8b0100a4 	add	x4, x5, x1
    a1f4:	f9401082 	ldr	x2, [x4, #32]
    a1f8:	b4000202 	cbz	x2, a238 <fwp_hof0.constprop.0+0x928>
    a1fc:	386168a1 	ldrb	w1, [x5, x1]
    a200:	7100083f 	cmp	w1, #0x2
    a204:	54001060 	b.eq	a410 <fwp_hof0.constprop.0+0xb00>  // b.none
    a208:	7100043f 	cmp	w1, #0x1
    a20c:	54000161 	b.ne	a238 <fwp_hof0.constprop.0+0x928>  // b.any
    a210:	29430485 	ldp	w5, w1, [x4, #24]
    a214:	92403c00 	and	x0, x0, #0xffff
    a218:	9b057c00 	mul	x0, x0, x5
    a21c:	d360fc00 	lsr	x0, x0, #32
    a220:	eb01001f 	cmp	x0, x1
    a224:	540000a2 	b.cs	a238 <fwp_hof0.constprop.0+0x928>  // b.hs, b.nlast
    a228:	8b000042 	add	x2, x2, x0
    a22c:	39400040 	ldrb	w0, [x2]
    a230:	7100041f 	cmp	w0, #0x1
    a234:	54000be0 	b.eq	a3b0 <fwp_hof0.constprop.0+0xaa0>  // b.none
    a238:	f9400f42 	ldr	x2, [x26, #24]
    a23c:	aa1903e0 	mov	x0, x25
    a240:	52800021 	mov	w1, #0x1                   	// #1
    a244:	b81d83a7 	stur	w7, [x29, #-40]
    a248:	f9400442 	ldr	x2, [x2, #8]
    a24c:	d63f0040 	blr	x2
    a250:	b85d83a7 	ldur	w7, [x29, #-40]
    a254:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a258:	91190002 	add	x2, x0, #0x640
    a25c:	f949d841 	ldr	x1, [x2, #5040]
    a260:	f949ec40 	ldr	x0, [x2, #5080]
    a264:	cb010261 	sub	x1, x19, x1
    a268:	eb00403f 	cmp	x1, x0, lsl #16
    a26c:	54000322 	b.cs	a2d0 <fwp_hof0.constprop.0+0x9c0>  // b.hs, b.nlast
    a270:	d350fc20 	lsr	x0, x1, #16
    a274:	f949fc43 	ldr	x3, [x2, #5112]
    a278:	8b000800 	add	x0, x0, x0, lsl #2
    a27c:	d37df002 	lsl	x2, x0, #3
    a280:	8b020060 	add	x0, x3, x2
    a284:	f9401014 	ldr	x20, [x0, #32]
    a288:	b4000254 	cbz	x20, a2d0 <fwp_hof0.constprop.0+0x9c0>
    a28c:	38626862 	ldrb	w2, [x3, x2]
    a290:	7100085f 	cmp	w2, #0x2
    a294:	54000c40 	b.eq	a41c <fwp_hof0.constprop.0+0xb0c>  // b.none
    a298:	7100045f 	cmp	w2, #0x1
    a29c:	540001a1 	b.ne	a2d0 <fwp_hof0.constprop.0+0x9c0>  // b.any
    a2a0:	29430002 	ldp	w2, w0, [x0, #24]
    a2a4:	92403c21 	and	x1, x1, #0xffff
    a2a8:	9b027c21 	mul	x1, x1, x2
    a2ac:	d360fc21 	lsr	x1, x1, #32
    a2b0:	eb00003f 	cmp	x1, x0
    a2b4:	540000e2 	b.cs	a2d0 <fwp_hof0.constprop.0+0x9c0>  // b.hs, b.nlast
    a2b8:	8b010294 	add	x20, x20, x1
    a2bc:	39400280 	ldrb	w0, [x20]
    a2c0:	7103fc1f 	cmp	w0, #0xff
    a2c4:	54000b60 	b.eq	a430 <fwp_hof0.constprop.0+0xb20>  // b.none
    a2c8:	52800020 	mov	w0, #0x1                   	// #1
    a2cc:	39000280 	strb	w0, [x20]
    a2d0:	aa1903e0 	mov	x0, x25
    a2d4:	b81d83a7 	stur	w7, [x29, #-40]
    a2d8:	97ffef8e 	bl	6110 <fwp_closure_drop>
    a2dc:	aa1303f9 	mov	x25, x19
    a2e0:	b85d83a7 	ldur	w7, [x29, #-40]
    a2e4:	17ffff3d 	b	9fd8 <fwp_hof0.constprop.0+0x6c8>
    a2e8:	b8626860 	ldr	w0, [x3, x2]
    a2ec:	b94004a2 	ldr	w2, [x5, #4]
    a2f0:	4b020003 	sub	w3, w0, w2
    a2f4:	7100047f 	cmp	w3, #0x1
    a2f8:	54ffba41 	b.ne	9a40 <fwp_hof0.constprop.0+0x130>  // b.any
    a2fc:	910003f6 	mov	x22, sp
    a300:	34000aa2 	cbz	w2, a454 <fwp_hof0.constprop.0+0xb44>
    a304:	7100001f 	cmp	w0, #0x0
    a308:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a30c:	d2800101 	mov	x1, #0x8                   	// #8
    a310:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a314:	91003ee0 	add	x0, x23, #0xf
    a318:	92704c01 	and	x1, x0, #0xfffff0000
    a31c:	927c7c00 	and	x0, x0, #0xffffffff0
    a320:	cb2163e1 	sub	x1, sp, x1
    a324:	eb2163ff 	cmp	sp, x1
    a328:	540000a0 	b.eq	a33c <fwp_hof0.constprop.0+0xa2c>  // b.none
    a32c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a330:	f90203ff 	str	xzr, [sp, #1024]
    a334:	eb2163ff 	cmp	sp, x1
    a338:	54ffffa1 	b.ne	a32c <fwp_hof0.constprop.0+0xa1c>  // b.any
    a33c:	92403c00 	and	x0, x0, #0xffff
    a340:	cb2063ff 	sub	sp, sp, x0
    a344:	f90003ff 	str	xzr, [sp]
    a348:	f110001f 	cmp	x0, #0x400
    a34c:	54000043 	b.cc	a354 <fwp_hof0.constprop.0+0xa44>  // b.lo, b.ul, b.last
    a350:	f90203ff 	str	xzr, [sp, #1024]
    a354:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    a358:	910043f8 	add	x24, sp, #0x10
    a35c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a360:	91004001 	add	x1, x0, #0x10
    a364:	aa1c03e2 	mov	x2, x28
    a368:	9100c021 	add	x1, x1, #0x30
    a36c:	aa1703e3 	mov	x3, x23
    a370:	aa1803e0 	mov	x0, x24
    a374:	97ffe0fb 	bl	2760 <__memcpy_chk@plt>
    a378:	eb1c02ff 	cmp	x23, x28
    a37c:	aa1403e1 	mov	x1, x20
    a380:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    a384:	d2800102 	mov	x2, #0x8                   	// #8
    a388:	cb1c0063 	sub	x3, x3, x28
    a38c:	8b1c0300 	add	x0, x24, x28
    a390:	97ffe0f4 	bl	2760 <__memcpy_chk@plt>
    a394:	f9400f61 	ldr	x1, [x27, #24]
    a398:	aa1803e0 	mov	x0, x24
    a39c:	f9400021 	ldr	x1, [x1]
    a3a0:	d63f0020 	blr	x1
    a3a4:	aa0003f9 	mov	x25, x0
    a3a8:	910002df 	mov	sp, x22
    a3ac:	17ffff2b 	b	a058 <fwp_hof0.constprop.0+0x748>
    a3b0:	b90004df 	str	wzr, [x6, #4]
    a3b4:	17ffffa8 	b	a254 <fwp_hof0.constprop.0+0x944>
    a3b8:	72003c3f 	tst	w1, #0xffff
    a3bc:	54ffb8c1 	b.ne	9ad4 <fwp_hof0.constprop.0+0x1c4>  // b.any
    a3c0:	17fffdba 	b	9aa8 <fwp_hof0.constprop.0+0x198>
    a3c4:	f94005b3 	ldr	x19, [x13, #8]
    a3c8:	b4000113 	cbz	x19, a3e8 <fwp_hof0.constprop.0+0xad8>
    a3cc:	f94009a9 	ldr	x9, [x13, #16]
    a3d0:	cb130129 	sub	x9, x9, x19
    a3d4:	eb09003f 	cmp	x1, x9
    a3d8:	54000088 	b.hi	a3e8 <fwp_hof0.constprop.0+0xad8>  // b.pmore
    a3dc:	8b010269 	add	x9, x19, x1
    a3e0:	f90005a9 	str	x9, [x13, #8]
    a3e4:	17ffff42 	b	a0ec <fwp_hof0.constprop.0+0x7dc>
    a3e8:	52800001 	mov	w1, #0x0                   	// #0
    a3ec:	b81bc3ab 	stur	w11, [x29, #-68]
    a3f0:	f81c03a6 	stur	x6, [x29, #-64]
    a3f4:	b81d83a7 	stur	w7, [x29, #-40]
    a3f8:	97ffeb26 	bl	5090 <fwp_heap_alloc>
    a3fc:	f85c03a6 	ldur	x6, [x29, #-64]
    a400:	aa0003f3 	mov	x19, x0
    a404:	b85bc3ab 	ldur	w11, [x29, #-68]
    a408:	b85d83a7 	ldur	w7, [x29, #-40]
    a40c:	17ffff4f 	b	a148 <fwp_hof0.constprop.0+0x838>
    a410:	72003c1f 	tst	w0, #0xffff
    a414:	54fff121 	b.ne	a238 <fwp_hof0.constprop.0+0x928>  // b.any
    a418:	17ffff85 	b	a22c <fwp_hof0.constprop.0+0x91c>
    a41c:	72003c3f 	tst	w1, #0xffff
    a420:	54fff581 	b.ne	a2d0 <fwp_hof0.constprop.0+0x9c0>  // b.any
    a424:	39400280 	ldrb	w0, [x20]
    a428:	7103fc1f 	cmp	w0, #0xff
    a42c:	54fff4e1 	b.ne	a2c8 <fwp_hof0.constprop.0+0x9b8>  // b.any
    a430:	aa1403e0 	mov	x0, x20
    a434:	b81d83a7 	stur	w7, [x29, #-40]
    a438:	97ffe956 	bl	4990 <fwp_rc_forget_slot>
    a43c:	b85d83a7 	ldur	w7, [x29, #-40]
    a440:	17ffffa2 	b	a2c8 <fwp_hof0.constprop.0+0x9b8>
    a444:	fd00aaa0 	str	d0, [x21, #336]
    a448:	17ffff49 	b	a16c <fwp_hof0.constprop.0+0x85c>
    a44c:	97ffe90a 	bl	4874 <fwp_rc_wide_dup>
    a450:	17fffda1 	b	9ad4 <fwp_hof0.constprop.0+0x1c4>
    a454:	f9400021 	ldr	x1, [x1]
    a458:	aa1403e0 	mov	x0, x20
    a45c:	d63f0020 	blr	x1
    a460:	aa0003f9 	mov	x25, x0
    a464:	910002df 	mov	sp, x22
    a468:	17fffefc 	b	a058 <fwp_hof0.constprop.0+0x748>
    a46c:	72003c3f 	tst	w1, #0xffff
    a470:	54ffac61 	b.ne	99fc <fwp_hof0.constprop.0+0xec>  // b.any
    a474:	17fffd58 	b	99d4 <fwp_hof0.constprop.0+0xc4>
    a478:	aa1a03e0 	mov	x0, x26
    a47c:	97ffed42 	bl	5984 <fwp_rc_share>
    a480:	aa1903e0 	mov	x0, x25
    a484:	52800037 	mov	w23, #0x1                   	// #1
    a488:	97ffed3f 	bl	5984 <fwp_rc_share>
    a48c:	aa1a03f9 	mov	x25, x26
    a490:	f81d03b4 	stur	x20, [x29, #-48]
    a494:	17fffeec 	b	a044 <fwp_hof0.constprop.0+0x734>
    a498:	f940ac43 	ldr	x3, [x2, #344]
    a49c:	91000463 	add	x3, x3, #0x1
    a4a0:	f900ac43 	str	x3, [x2, #344]
    a4a4:	17fffd52 	b	99ec <fwp_hof0.constprop.0+0xdc>
    a4a8:	aa1303e0 	mov	x0, x19
    a4ac:	97ffed8d 	bl	5ae0 <fwp_rc_free_arr>
    a4b0:	f9400b5a 	ldr	x26, [x26, #16]
    a4b4:	b5ffa5da 	cbnz	x26, 996c <fwp_hof0.constprop.0+0x5c>
    a4b8:	17fffe9b 	b	9f24 <fwp_hof0.constprop.0+0x614>
    a4bc:	72003c3f 	tst	w1, #0xffff
    a4c0:	54ffd2e1 	b.ne	9f1c <fwp_hof0.constprop.0+0x60c>  // b.any
    a4c4:	17fffe8e 	b	9efc <fwp_hof0.constprop.0+0x5ec>
    a4c8:	72003c3f 	tst	w1, #0xffff
    a4cc:	54ffcca1 	b.ne	9e60 <fwp_hof0.constprop.0+0x550>  // b.any
    a4d0:	17fffe5f 	b	9e4c <fwp_hof0.constprop.0+0x53c>
    a4d4:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a4d8:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a4dc:	91190021 	add	x1, x1, #0x640
    a4e0:	ca402400 	eor	x0, x0, x0, lsr #9
    a4e4:	8b200c20 	add	x0, x1, w0, uxtb #3
    a4e8:	f94a2400 	ldr	x0, [x0, #5192]
    a4ec:	b5000080 	cbnz	x0, a4fc <fwp_hof0.constprop.0+0xbec>
    a4f0:	14000011 	b	a534 <fwp_hof0.constprop.0+0xc24>
    a4f4:	f9400800 	ldr	x0, [x0, #16]
    a4f8:	b40001e0 	cbz	x0, a534 <fwp_hof0.constprop.0+0xc24>
    a4fc:	f9400001 	ldr	x1, [x0]
    a500:	eb16003f 	cmp	x1, x22
    a504:	54ffff81 	b.ne	a4f4 <fwp_hof0.constprop.0+0xbe4>  // b.any
    a508:	f9400401 	ldr	x1, [x0, #8]
    a50c:	d1000421 	sub	x1, x1, #0x1
    a510:	f9000401 	str	x1, [x0, #8]
    a514:	f103f83f 	cmp	x1, #0xfe
    a518:	54ffd021 	b.ne	9f1c <fwp_hof0.constprop.0+0x60c>  // b.any
    a51c:	aa1603e0 	mov	x0, x22
    a520:	97ffe91c 	bl	4990 <fwp_rc_forget_slot>
    a524:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a528:	390002c0 	strb	w0, [x22]
    a52c:	17fffe7c 	b	9f1c <fwp_hof0.constprop.0+0x60c>
    a530:	97ffe2f0 	bl	30f0 <fwp_heap_oom>
    a534:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x440>
    a538:	91358000 	add	x0, x0, #0xd60
    a53c:	97ffe491 	bl	3780 <fwp_trap>
    a540:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x760>
    a544:	9101e000 	add	x0, x0, #0x78
    a548:	97ffe48e 	bl	3780 <fwp_trap>
    a54c:	97ffe8ca 	bl	4874 <fwp_rc_wide_dup>
    a550:	17fffd2b 	b	99fc <fwp_hof0.constprop.0+0xec>
    a554:	97ffe0af 	bl	2810 <__stack_chk_fail@plt>
    a558:	aa1903e0 	mov	x0, x25
    a55c:	97ffe90d 	bl	4990 <fwp_rc_forget_slot>
    a560:	17fffe3e 	b	9e58 <fwp_hof0.constprop.0+0x548>

000000000000a564 <f0>:
    a564:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a568:	910003fd 	mov	x29, sp
    a56c:	a90153f3 	stp	x19, x20, [sp, #16]
    a570:	a9025bf5 	stp	x21, x22, [sp, #32]
    a574:	a90363f7 	stp	x23, x24, [sp, #48]
    a578:	a9046bf9 	stp	x25, x26, [sp, #64]
    a57c:	a90573fb 	stp	x27, x28, [sp, #80]
    a580:	d12183ff 	sub	sp, sp, #0x860
    a584:	f90203ff 	str	xzr, [sp, #1024]
    a588:	d00000a0 	adrp	x0, 20000 <__data_start>
    a58c:	91018005 	add	x5, x0, #0x60
    a590:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    a594:	f947f400 	ldr	x0, [x0, #4072]
    a598:	f0000374 	adrp	x20, 79000 <fwp_root_context+0xba0>
    a59c:	f941c8a6 	ldr	x6, [x5, #912]
    a5a0:	f9400001 	ldr	x1, [x0]
    a5a4:	f9042fe1 	str	x1, [sp, #2136]
    a5a8:	d2800001 	mov	x1, #0x0                   	// #0
    a5ac:	91190298 	add	x24, x20, #0x640
    a5b0:	912123f6 	add	x22, sp, #0x848
    a5b4:	910023e0 	add	x0, sp, #0x8
    a5b8:	910083e2 	add	x2, sp, #0x20
    a5bc:	f0ffffc1 	adrp	x1, 5000 <fwp_heap_alloc_slow+0xd0>
    a5c0:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a5c4:	91394021 	add	x1, x1, #0xe50
    a5c8:	913b4084 	add	x4, x4, #0xed0
    a5cc:	d2800013 	mov	x19, #0x0                   	// #0
    a5d0:	d2800119 	mov	x25, #0x8                   	// #8
    a5d4:	d2800015 	mov	x21, #0x0                   	// #0
    a5d8:	52800037 	mov	w23, #0x1                   	// #1
    a5dc:	a90093e6 	stp	x6, x4, [sp, #8]
    a5e0:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a5e4:	a90307ff 	stp	xzr, x1, [sp, #48]
    a5e8:	f901c8a0 	str	x0, [x5, #912]
    a5ec:	d503201f 	nop
    a5f0:	f100073a 	subs	x26, x25, #0x1
    a5f4:	aa1603e1 	mov	x1, x22
    a5f8:	da1f02bc 	sbc	x28, x21, xzr
    a5fc:	52800020 	mov	w0, #0x1                   	// #1
    a600:	f90017fa 	str	x26, [sp, #40]
    a604:	aa1a03f9 	mov	x25, x26
    a608:	f90427fa 	str	x26, [sp, #2120]
    a60c:	aa1c03f5 	mov	x21, x28
    a610:	f9042bf3 	str	x19, [sp, #2128]
    a614:	97ffec7f 	bl	5810 <fwp_data.part.0.constprop.0>
    a618:	f949db02 	ldr	x2, [x24, #5040]
    a61c:	aa0003f3 	mov	x19, x0
    a620:	f949ef00 	ldr	x0, [x24, #5080]
    a624:	cb020262 	sub	x2, x19, x2
    a628:	eb00405f 	cmp	x2, x0, lsl #16
    a62c:	54000302 	b.cs	a68c <f0+0x128>  // b.hs, b.nlast
    a630:	d350fc40 	lsr	x0, x2, #16
    a634:	f949ff04 	ldr	x4, [x24, #5112]
    a638:	8b000800 	add	x0, x0, x0, lsl #2
    a63c:	d37df001 	lsl	x1, x0, #3
    a640:	8b010080 	add	x0, x4, x1
    a644:	f940101b 	ldr	x27, [x0, #32]
    a648:	b400023b 	cbz	x27, a68c <f0+0x128>
    a64c:	38616881 	ldrb	w1, [x4, x1]
    a650:	7100083f 	cmp	w1, #0x2
    a654:	54010da0 	b.eq	c808 <f0+0x22a4>  // b.none
    a658:	7100043f 	cmp	w1, #0x1
    a65c:	54000181 	b.ne	a68c <f0+0x128>  // b.any
    a660:	29430001 	ldp	w1, w0, [x0, #24]
    a664:	92403c42 	and	x2, x2, #0xffff
    a668:	9b017c42 	mul	x2, x2, x1
    a66c:	d360fc42 	lsr	x2, x2, #32
    a670:	eb00005f 	cmp	x2, x0
    a674:	540000c2 	b.cs	a68c <f0+0x128>  // b.hs, b.nlast
    a678:	8b02037b 	add	x27, x27, x2
    a67c:	39400360 	ldrb	w0, [x27]
    a680:	7103fc1f 	cmp	w0, #0xff
    a684:	54010bc0 	b.eq	c7fc <f0+0x2298>  // b.none
    a688:	39000377 	strb	w23, [x27]
    a68c:	f90013f3 	str	x19, [sp, #32]
    a690:	aa1c035a 	orr	x26, x26, x28
    a694:	b5fffafa 	cbnz	x26, a5f0 <f0+0x8c>
    a698:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x760>
    a69c:	910103e1 	add	x1, sp, #0x40
    a6a0:	f94007e2 	ldr	x2, [sp, #8]
    a6a4:	3dc21800 	ldr	q0, [x0, #2144]
    a6a8:	d00000a0 	adrp	x0, 20000 <__data_start>
    a6ac:	91018018 	add	x24, x0, #0x60
    a6b0:	52800020 	mov	w0, #0x1                   	// #1
    a6b4:	3d8013e0 	str	q0, [sp, #64]
    a6b8:	f901cb02 	str	x2, [x24, #912]
    a6bc:	97ffec55 	bl	5810 <fwp_data.part.0.constprop.0>
    a6c0:	97ffecd8 	bl	5a20 <fwp_rc_fresh>
    a6c4:	aa0003e2 	mov	x2, x0
    a6c8:	910163e1 	add	x1, sp, #0x58
    a6cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a6d0:	52800020 	mov	w0, #0x1                   	// #1
    a6d4:	a9058be3 	stp	x3, x2, [sp, #88]
    a6d8:	97ffec4e 	bl	5810 <fwp_data.part.0.constprop.0>
    a6dc:	97ffecd1 	bl	5a20 <fwp_rc_fresh>
    a6e0:	aa0003e2 	mov	x2, x0
    a6e4:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x760>
    a6e8:	9101a3e1 	add	x1, sp, #0x68
    a6ec:	52800020 	mov	w0, #0x1                   	// #1
    a6f0:	f9003be2 	str	x2, [sp, #112]
    a6f4:	3dc21860 	ldr	q0, [x3, #2144]
    a6f8:	fd0037e0 	str	d0, [sp, #104]
    a6fc:	97ffec45 	bl	5810 <fwp_data.part.0.constprop.0>
    a700:	91190283 	add	x3, x20, #0x640
    a704:	aa0003f5 	mov	x21, x0
    a708:	f949d861 	ldr	x1, [x3, #5040]
    a70c:	f949ec60 	ldr	x0, [x3, #5080]
    a710:	cb0102a1 	sub	x1, x21, x1
    a714:	eb00403f 	cmp	x1, x0, lsl #16
    a718:	54000322 	b.cs	a77c <f0+0x218>  // b.hs, b.nlast
    a71c:	d350fc22 	lsr	x2, x1, #16
    a720:	f949fc63 	ldr	x3, [x3, #5112]
    a724:	8b020842 	add	x2, x2, x2, lsl #2
    a728:	d37df042 	lsl	x2, x2, #3
    a72c:	8b020060 	add	x0, x3, x2
    a730:	f9401017 	ldr	x23, [x0, #32]
    a734:	b4000257 	cbz	x23, a77c <f0+0x218>
    a738:	38626862 	ldrb	w2, [x3, x2]
    a73c:	7100085f 	cmp	w2, #0x2
    a740:	54010a60 	b.eq	c88c <f0+0x2328>  // b.none
    a744:	7100045f 	cmp	w2, #0x1
    a748:	540001a1 	b.ne	a77c <f0+0x218>  // b.any
    a74c:	29430002 	ldp	w2, w0, [x0, #24]
    a750:	92403c21 	and	x1, x1, #0xffff
    a754:	9b027c21 	mul	x1, x1, x2
    a758:	d360fc21 	lsr	x1, x1, #32
    a75c:	eb00003f 	cmp	x1, x0
    a760:	540000e2 	b.cs	a77c <f0+0x218>  // b.hs, b.nlast
    a764:	8b0102f7 	add	x23, x23, x1
    a768:	394002e0 	ldrb	w0, [x23]
    a76c:	7103fc1f 	cmp	w0, #0xff
    a770:	54011420 	b.eq	c9f4 <f0+0x2490>  // b.none
    a774:	52800020 	mov	w0, #0x1                   	// #1
    a778:	390002e0 	strb	w0, [x23]
    a77c:	9101e3e1 	add	x1, sp, #0x78
    a780:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a784:	52800020 	mov	w0, #0x1                   	// #1
    a788:	a907d7f7 	stp	x23, x21, [sp, #120]
    a78c:	97ffec21 	bl	5810 <fwp_data.part.0.constprop.0>
    a790:	97ffeca4 	bl	5a20 <fwp_rc_fresh>
    a794:	aa0003e2 	mov	x2, x0
    a798:	910223e1 	add	x1, sp, #0x88
    a79c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a7a0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a7a4:	52800020 	mov	w0, #0x1                   	// #1
    a7a8:	a9088bf5 	stp	x21, x2, [sp, #136]
    a7ac:	97ffec19 	bl	5810 <fwp_data.part.0.constprop.0>
    a7b0:	97ffec9c 	bl	5a20 <fwp_rc_fresh>
    a7b4:	aa0003e2 	mov	x2, x0
    a7b8:	910263e1 	add	x1, sp, #0x98
    a7bc:	52800020 	mov	w0, #0x1                   	// #1
    a7c0:	a9098bf7 	stp	x23, x2, [sp, #152]
    a7c4:	97ffec13 	bl	5810 <fwp_data.part.0.constprop.0>
    a7c8:	97ffec96 	bl	5a20 <fwp_rc_fresh>
    a7cc:	aa0003e2 	mov	x2, x0
    a7d0:	9102a3e1 	add	x1, sp, #0xa8
    a7d4:	52800020 	mov	w0, #0x1                   	// #1
    a7d8:	a90a8bf5 	stp	x21, x2, [sp, #168]
    a7dc:	97ffec0d 	bl	5810 <fwp_data.part.0.constprop.0>
    a7e0:	91190283 	add	x3, x20, #0x640
    a7e4:	aa0003f5 	mov	x21, x0
    a7e8:	f949d861 	ldr	x1, [x3, #5040]
    a7ec:	f949ec60 	ldr	x0, [x3, #5080]
    a7f0:	cb0102a1 	sub	x1, x21, x1
    a7f4:	eb00403f 	cmp	x1, x0, lsl #16
    a7f8:	54000322 	b.cs	a85c <f0+0x2f8>  // b.hs, b.nlast
    a7fc:	d350fc22 	lsr	x2, x1, #16
    a800:	f949fc63 	ldr	x3, [x3, #5112]
    a804:	8b020842 	add	x2, x2, x2, lsl #2
    a808:	d37df042 	lsl	x2, x2, #3
    a80c:	8b020060 	add	x0, x3, x2
    a810:	f9401017 	ldr	x23, [x0, #32]
    a814:	b4000257 	cbz	x23, a85c <f0+0x2f8>
    a818:	38626862 	ldrb	w2, [x3, x2]
    a81c:	7100085f 	cmp	w2, #0x2
    a820:	54010300 	b.eq	c880 <f0+0x231c>  // b.none
    a824:	7100045f 	cmp	w2, #0x1
    a828:	540001a1 	b.ne	a85c <f0+0x2f8>  // b.any
    a82c:	29430002 	ldp	w2, w0, [x0, #24]
    a830:	92403c21 	and	x1, x1, #0xffff
    a834:	9b027c21 	mul	x1, x1, x2
    a838:	d360fc21 	lsr	x1, x1, #32
    a83c:	eb00003f 	cmp	x1, x0
    a840:	540000e2 	b.cs	a85c <f0+0x2f8>  // b.hs, b.nlast
    a844:	8b0102f7 	add	x23, x23, x1
    a848:	394002e0 	ldrb	w0, [x23]
    a84c:	7103fc1f 	cmp	w0, #0xff
    a850:	54010d80 	b.eq	ca00 <f0+0x249c>  // b.none
    a854:	52800020 	mov	w0, #0x1                   	// #1
    a858:	390002e0 	strb	w0, [x23]
    a85c:	9102e3e1 	add	x1, sp, #0xb8
    a860:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a864:	52800020 	mov	w0, #0x1                   	// #1
    a868:	a90bd7f7 	stp	x23, x21, [sp, #184]
    a86c:	97ffebe9 	bl	5810 <fwp_data.part.0.constprop.0>
    a870:	97ffec6c 	bl	5a20 <fwp_rc_fresh>
    a874:	aa0003e2 	mov	x2, x0
    a878:	910323e1 	add	x1, sp, #0xc8
    a87c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a880:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a884:	52800020 	mov	w0, #0x1                   	// #1
    a888:	a90c8bf5 	stp	x21, x2, [sp, #200]
    a88c:	97ffebe1 	bl	5810 <fwp_data.part.0.constprop.0>
    a890:	97ffec64 	bl	5a20 <fwp_rc_fresh>
    a894:	aa0003e2 	mov	x2, x0
    a898:	910363e1 	add	x1, sp, #0xd8
    a89c:	52800020 	mov	w0, #0x1                   	// #1
    a8a0:	a90d8bf7 	stp	x23, x2, [sp, #216]
    a8a4:	97ffebdb 	bl	5810 <fwp_data.part.0.constprop.0>
    a8a8:	97ffec5e 	bl	5a20 <fwp_rc_fresh>
    a8ac:	aa0003e2 	mov	x2, x0
    a8b0:	9103a3e1 	add	x1, sp, #0xe8
    a8b4:	52800020 	mov	w0, #0x1                   	// #1
    a8b8:	a90e8bf5 	stp	x21, x2, [sp, #232]
    a8bc:	97ffebd5 	bl	5810 <fwp_data.part.0.constprop.0>
    a8c0:	97ffec58 	bl	5a20 <fwp_rc_fresh>
    a8c4:	aa0003e2 	mov	x2, x0
    a8c8:	9103e3e1 	add	x1, sp, #0xf8
    a8cc:	52800020 	mov	w0, #0x1                   	// #1
    a8d0:	a90f8bf7 	stp	x23, x2, [sp, #248]
    a8d4:	97ffebcf 	bl	5810 <fwp_data.part.0.constprop.0>
    a8d8:	97ffec52 	bl	5a20 <fwp_rc_fresh>
    a8dc:	aa0003e2 	mov	x2, x0
    a8e0:	910423e1 	add	x1, sp, #0x108
    a8e4:	52800020 	mov	w0, #0x1                   	// #1
    a8e8:	a9108bf5 	stp	x21, x2, [sp, #264]
    a8ec:	97ffebc9 	bl	5810 <fwp_data.part.0.constprop.0>
    a8f0:	97ffec4c 	bl	5a20 <fwp_rc_fresh>
    a8f4:	aa0003e2 	mov	x2, x0
    a8f8:	910463e1 	add	x1, sp, #0x118
    a8fc:	52800020 	mov	w0, #0x1                   	// #1
    a900:	a9118bf7 	stp	x23, x2, [sp, #280]
    a904:	97ffebc3 	bl	5810 <fwp_data.part.0.constprop.0>
    a908:	97ffec46 	bl	5a20 <fwp_rc_fresh>
    a90c:	aa0003e2 	mov	x2, x0
    a910:	9104a3e1 	add	x1, sp, #0x128
    a914:	52800020 	mov	w0, #0x1                   	// #1
    a918:	a9128bf5 	stp	x21, x2, [sp, #296]
    a91c:	97ffebbd 	bl	5810 <fwp_data.part.0.constprop.0>
    a920:	91190283 	add	x3, x20, #0x640
    a924:	aa0003f5 	mov	x21, x0
    a928:	f949d861 	ldr	x1, [x3, #5040]
    a92c:	f949ec60 	ldr	x0, [x3, #5080]
    a930:	cb0102a1 	sub	x1, x21, x1
    a934:	eb00403f 	cmp	x1, x0, lsl #16
    a938:	54000322 	b.cs	a99c <f0+0x438>  // b.hs, b.nlast
    a93c:	d350fc22 	lsr	x2, x1, #16
    a940:	f949fc63 	ldr	x3, [x3, #5112]
    a944:	8b020842 	add	x2, x2, x2, lsl #2
    a948:	d37df042 	lsl	x2, x2, #3
    a94c:	8b020060 	add	x0, x3, x2
    a950:	f9401017 	ldr	x23, [x0, #32]
    a954:	b4000257 	cbz	x23, a99c <f0+0x438>
    a958:	38626862 	ldrb	w2, [x3, x2]
    a95c:	7100085f 	cmp	w2, #0x2
    a960:	5400f8a0 	b.eq	c874 <f0+0x2310>  // b.none
    a964:	7100045f 	cmp	w2, #0x1
    a968:	540001a1 	b.ne	a99c <f0+0x438>  // b.any
    a96c:	29430002 	ldp	w2, w0, [x0, #24]
    a970:	92403c21 	and	x1, x1, #0xffff
    a974:	9b027c21 	mul	x1, x1, x2
    a978:	d360fc21 	lsr	x1, x1, #32
    a97c:	eb00003f 	cmp	x1, x0
    a980:	540000e2 	b.cs	a99c <f0+0x438>  // b.hs, b.nlast
    a984:	8b0102f7 	add	x23, x23, x1
    a988:	394002e0 	ldrb	w0, [x23]
    a98c:	7103fc1f 	cmp	w0, #0xff
    a990:	540103e0 	b.eq	ca0c <f0+0x24a8>  // b.none
    a994:	52800020 	mov	w0, #0x1                   	// #1
    a998:	390002e0 	strb	w0, [x23]
    a99c:	9104e3e1 	add	x1, sp, #0x138
    a9a0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a9a4:	52800020 	mov	w0, #0x1                   	// #1
    a9a8:	a913d7f7 	stp	x23, x21, [sp, #312]
    a9ac:	97ffeb99 	bl	5810 <fwp_data.part.0.constprop.0>
    a9b0:	97ffec1c 	bl	5a20 <fwp_rc_fresh>
    a9b4:	aa0003e2 	mov	x2, x0
    a9b8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a9bc:	910523e1 	add	x1, sp, #0x148
    a9c0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a9c4:	52800020 	mov	w0, #0x1                   	// #1
    a9c8:	a9148be3 	stp	x3, x2, [sp, #328]
    a9cc:	97ffeb91 	bl	5810 <fwp_data.part.0.constprop.0>
    a9d0:	97ffec14 	bl	5a20 <fwp_rc_fresh>
    a9d4:	aa0003e2 	mov	x2, x0
    a9d8:	910563e1 	add	x1, sp, #0x158
    a9dc:	52800020 	mov	w0, #0x1                   	// #1
    a9e0:	a9158bf7 	stp	x23, x2, [sp, #344]
    a9e4:	97ffeb8b 	bl	5810 <fwp_data.part.0.constprop.0>
    a9e8:	91190283 	add	x3, x20, #0x640
    a9ec:	aa0003f5 	mov	x21, x0
    a9f0:	f949d861 	ldr	x1, [x3, #5040]
    a9f4:	f949ec60 	ldr	x0, [x3, #5080]
    a9f8:	cb0102a1 	sub	x1, x21, x1
    a9fc:	eb00403f 	cmp	x1, x0, lsl #16
    aa00:	54000322 	b.cs	aa64 <f0+0x500>  // b.hs, b.nlast
    aa04:	d350fc22 	lsr	x2, x1, #16
    aa08:	f949fc63 	ldr	x3, [x3, #5112]
    aa0c:	8b020842 	add	x2, x2, x2, lsl #2
    aa10:	d37df042 	lsl	x2, x2, #3
    aa14:	8b020060 	add	x0, x3, x2
    aa18:	f9401017 	ldr	x23, [x0, #32]
    aa1c:	b4000257 	cbz	x23, aa64 <f0+0x500>
    aa20:	38626862 	ldrb	w2, [x3, x2]
    aa24:	7100085f 	cmp	w2, #0x2
    aa28:	5400f4a0 	b.eq	c8bc <f0+0x2358>  // b.none
    aa2c:	7100045f 	cmp	w2, #0x1
    aa30:	540001a1 	b.ne	aa64 <f0+0x500>  // b.any
    aa34:	29430002 	ldp	w2, w0, [x0, #24]
    aa38:	92403c21 	and	x1, x1, #0xffff
    aa3c:	9b027c21 	mul	x1, x1, x2
    aa40:	d360fc21 	lsr	x1, x1, #32
    aa44:	eb00003f 	cmp	x1, x0
    aa48:	540000e2 	b.cs	aa64 <f0+0x500>  // b.hs, b.nlast
    aa4c:	8b0102f7 	add	x23, x23, x1
    aa50:	394002e0 	ldrb	w0, [x23]
    aa54:	7103fc1f 	cmp	w0, #0xff
    aa58:	5400fe00 	b.eq	ca18 <f0+0x24b4>  // b.none
    aa5c:	52800020 	mov	w0, #0x1                   	// #1
    aa60:	390002e0 	strb	w0, [x23]
    aa64:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aa68:	9105a3e1 	add	x1, sp, #0x168
    aa6c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aa70:	52800020 	mov	w0, #0x1                   	// #1
    aa74:	a916d7e2 	stp	x2, x21, [sp, #360]
    aa78:	97ffeb66 	bl	5810 <fwp_data.part.0.constprop.0>
    aa7c:	91190283 	add	x3, x20, #0x640
    aa80:	aa0003f5 	mov	x21, x0
    aa84:	f949d861 	ldr	x1, [x3, #5040]
    aa88:	f949ec60 	ldr	x0, [x3, #5080]
    aa8c:	cb0102a1 	sub	x1, x21, x1
    aa90:	eb00403f 	cmp	x1, x0, lsl #16
    aa94:	54000322 	b.cs	aaf8 <f0+0x594>  // b.hs, b.nlast
    aa98:	d350fc22 	lsr	x2, x1, #16
    aa9c:	f949fc63 	ldr	x3, [x3, #5112]
    aaa0:	8b020842 	add	x2, x2, x2, lsl #2
    aaa4:	d37df042 	lsl	x2, x2, #3
    aaa8:	8b020060 	add	x0, x3, x2
    aaac:	f9401017 	ldr	x23, [x0, #32]
    aab0:	b4000257 	cbz	x23, aaf8 <f0+0x594>
    aab4:	38626862 	ldrb	w2, [x3, x2]
    aab8:	7100085f 	cmp	w2, #0x2
    aabc:	5400efa0 	b.eq	c8b0 <f0+0x234c>  // b.none
    aac0:	7100045f 	cmp	w2, #0x1
    aac4:	540001a1 	b.ne	aaf8 <f0+0x594>  // b.any
    aac8:	29430002 	ldp	w2, w0, [x0, #24]
    aacc:	92403c21 	and	x1, x1, #0xffff
    aad0:	9b027c21 	mul	x1, x1, x2
    aad4:	d360fc21 	lsr	x1, x1, #32
    aad8:	eb00003f 	cmp	x1, x0
    aadc:	540000e2 	b.cs	aaf8 <f0+0x594>  // b.hs, b.nlast
    aae0:	8b0102f7 	add	x23, x23, x1
    aae4:	394002e0 	ldrb	w0, [x23]
    aae8:	7103fc1f 	cmp	w0, #0xff
    aaec:	5400f9c0 	b.eq	ca24 <f0+0x24c0>  // b.none
    aaf0:	52800020 	mov	w0, #0x1                   	// #1
    aaf4:	390002e0 	strb	w0, [x23]
    aaf8:	9105e3e1 	add	x1, sp, #0x178
    aafc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ab00:	52800020 	mov	w0, #0x1                   	// #1
    ab04:	a917d7f7 	stp	x23, x21, [sp, #376]
    ab08:	97ffeb42 	bl	5810 <fwp_data.part.0.constprop.0>
    ab0c:	97ffebc5 	bl	5a20 <fwp_rc_fresh>
    ab10:	aa0003e2 	mov	x2, x0
    ab14:	910623e1 	add	x1, sp, #0x188
    ab18:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ab1c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ab20:	52800020 	mov	w0, #0x1                   	// #1
    ab24:	a9188bf5 	stp	x21, x2, [sp, #392]
    ab28:	97ffeb3a 	bl	5810 <fwp_data.part.0.constprop.0>
    ab2c:	97ffebbd 	bl	5a20 <fwp_rc_fresh>
    ab30:	aa0003e2 	mov	x2, x0
    ab34:	910663e1 	add	x1, sp, #0x198
    ab38:	52800020 	mov	w0, #0x1                   	// #1
    ab3c:	a9198bf7 	stp	x23, x2, [sp, #408]
    ab40:	97ffeb34 	bl	5810 <fwp_data.part.0.constprop.0>
    ab44:	97ffebb7 	bl	5a20 <fwp_rc_fresh>
    ab48:	aa0003e2 	mov	x2, x0
    ab4c:	9106a3e1 	add	x1, sp, #0x1a8
    ab50:	52800020 	mov	w0, #0x1                   	// #1
    ab54:	a91a8bf5 	stp	x21, x2, [sp, #424]
    ab58:	97ffeb2e 	bl	5810 <fwp_data.part.0.constprop.0>
    ab5c:	97ffebb1 	bl	5a20 <fwp_rc_fresh>
    ab60:	aa0003e2 	mov	x2, x0
    ab64:	9106e3e1 	add	x1, sp, #0x1b8
    ab68:	52800020 	mov	w0, #0x1                   	// #1
    ab6c:	a91b8bf7 	stp	x23, x2, [sp, #440]
    ab70:	97ffeb28 	bl	5810 <fwp_data.part.0.constprop.0>
    ab74:	97ffebab 	bl	5a20 <fwp_rc_fresh>
    ab78:	aa0003e2 	mov	x2, x0
    ab7c:	910723e1 	add	x1, sp, #0x1c8
    ab80:	52800020 	mov	w0, #0x1                   	// #1
    ab84:	a91c8bf5 	stp	x21, x2, [sp, #456]
    ab88:	97ffeb22 	bl	5810 <fwp_data.part.0.constprop.0>
    ab8c:	91190283 	add	x3, x20, #0x640
    ab90:	aa0003f5 	mov	x21, x0
    ab94:	f949d861 	ldr	x1, [x3, #5040]
    ab98:	f949ec60 	ldr	x0, [x3, #5080]
    ab9c:	cb0102a1 	sub	x1, x21, x1
    aba0:	eb00403f 	cmp	x1, x0, lsl #16
    aba4:	54000322 	b.cs	ac08 <f0+0x6a4>  // b.hs, b.nlast
    aba8:	d350fc22 	lsr	x2, x1, #16
    abac:	f949fc63 	ldr	x3, [x3, #5112]
    abb0:	8b020842 	add	x2, x2, x2, lsl #2
    abb4:	d37df042 	lsl	x2, x2, #3
    abb8:	8b020060 	add	x0, x3, x2
    abbc:	f9401017 	ldr	x23, [x0, #32]
    abc0:	b4000257 	cbz	x23, ac08 <f0+0x6a4>
    abc4:	38626862 	ldrb	w2, [x3, x2]
    abc8:	7100085f 	cmp	w2, #0x2
    abcc:	5400e6c0 	b.eq	c8a4 <f0+0x2340>  // b.none
    abd0:	7100045f 	cmp	w2, #0x1
    abd4:	540001a1 	b.ne	ac08 <f0+0x6a4>  // b.any
    abd8:	29430002 	ldp	w2, w0, [x0, #24]
    abdc:	92403c21 	and	x1, x1, #0xffff
    abe0:	9b027c21 	mul	x1, x1, x2
    abe4:	d360fc21 	lsr	x1, x1, #32
    abe8:	eb00003f 	cmp	x1, x0
    abec:	540000e2 	b.cs	ac08 <f0+0x6a4>  // b.hs, b.nlast
    abf0:	8b0102f7 	add	x23, x23, x1
    abf4:	394002e0 	ldrb	w0, [x23]
    abf8:	7103fc1f 	cmp	w0, #0xff
    abfc:	5400f1a0 	b.eq	ca30 <f0+0x24cc>  // b.none
    ac00:	52800020 	mov	w0, #0x1                   	// #1
    ac04:	390002e0 	strb	w0, [x23]
    ac08:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ac0c:	910763e1 	add	x1, sp, #0x1d8
    ac10:	52800020 	mov	w0, #0x1                   	// #1
    ac14:	a91dd7e2 	stp	x2, x21, [sp, #472]
    ac18:	97ffeafe 	bl	5810 <fwp_data.part.0.constprop.0>
    ac1c:	91190283 	add	x3, x20, #0x640
    ac20:	aa0003f5 	mov	x21, x0
    ac24:	f949d861 	ldr	x1, [x3, #5040]
    ac28:	f949ec60 	ldr	x0, [x3, #5080]
    ac2c:	cb0102a1 	sub	x1, x21, x1
    ac30:	eb00403f 	cmp	x1, x0, lsl #16
    ac34:	54000322 	b.cs	ac98 <f0+0x734>  // b.hs, b.nlast
    ac38:	d350fc22 	lsr	x2, x1, #16
    ac3c:	f949fc63 	ldr	x3, [x3, #5112]
    ac40:	8b020842 	add	x2, x2, x2, lsl #2
    ac44:	d37df042 	lsl	x2, x2, #3
    ac48:	8b020060 	add	x0, x3, x2
    ac4c:	f9401017 	ldr	x23, [x0, #32]
    ac50:	b4000257 	cbz	x23, ac98 <f0+0x734>
    ac54:	38626862 	ldrb	w2, [x3, x2]
    ac58:	7100085f 	cmp	w2, #0x2
    ac5c:	5400e1e0 	b.eq	c898 <f0+0x2334>  // b.none
    ac60:	7100045f 	cmp	w2, #0x1
    ac64:	540001a1 	b.ne	ac98 <f0+0x734>  // b.any
    ac68:	29430002 	ldp	w2, w0, [x0, #24]
    ac6c:	92403c21 	and	x1, x1, #0xffff
    ac70:	9b027c21 	mul	x1, x1, x2
    ac74:	d360fc21 	lsr	x1, x1, #32
    ac78:	eb00003f 	cmp	x1, x0
    ac7c:	540000e2 	b.cs	ac98 <f0+0x734>  // b.hs, b.nlast
    ac80:	8b0102f7 	add	x23, x23, x1
    ac84:	394002e0 	ldrb	w0, [x23]
    ac88:	7103fc1f 	cmp	w0, #0xff
    ac8c:	5400ed80 	b.eq	ca3c <f0+0x24d8>  // b.none
    ac90:	52800020 	mov	w0, #0x1                   	// #1
    ac94:	390002e0 	strb	w0, [x23]
    ac98:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ac9c:	9107a3e1 	add	x1, sp, #0x1e8
    aca0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aca4:	52800020 	mov	w0, #0x1                   	// #1
    aca8:	a91ed7e2 	stp	x2, x21, [sp, #488]
    acac:	97ffead9 	bl	5810 <fwp_data.part.0.constprop.0>
    acb0:	91190283 	add	x3, x20, #0x640
    acb4:	aa0003f5 	mov	x21, x0
    acb8:	f949d861 	ldr	x1, [x3, #5040]
    acbc:	f949ec60 	ldr	x0, [x3, #5080]
    acc0:	cb0102a1 	sub	x1, x21, x1
    acc4:	eb00403f 	cmp	x1, x0, lsl #16
    acc8:	54000322 	b.cs	ad2c <f0+0x7c8>  // b.hs, b.nlast
    accc:	d350fc22 	lsr	x2, x1, #16
    acd0:	f949fc63 	ldr	x3, [x3, #5112]
    acd4:	8b020842 	add	x2, x2, x2, lsl #2
    acd8:	d37df042 	lsl	x2, x2, #3
    acdc:	8b020060 	add	x0, x3, x2
    ace0:	f9401017 	ldr	x23, [x0, #32]
    ace4:	b4000257 	cbz	x23, ad2c <f0+0x7c8>
    ace8:	38626862 	ldrb	w2, [x3, x2]
    acec:	7100085f 	cmp	w2, #0x2
    acf0:	5400e160 	b.eq	c91c <f0+0x23b8>  // b.none
    acf4:	7100045f 	cmp	w2, #0x1
    acf8:	540001a1 	b.ne	ad2c <f0+0x7c8>  // b.any
    acfc:	29430002 	ldp	w2, w0, [x0, #24]
    ad00:	92403c21 	and	x1, x1, #0xffff
    ad04:	9b027c21 	mul	x1, x1, x2
    ad08:	d360fc21 	lsr	x1, x1, #32
    ad0c:	eb00003f 	cmp	x1, x0
    ad10:	540000e2 	b.cs	ad2c <f0+0x7c8>  // b.hs, b.nlast
    ad14:	8b0102f7 	add	x23, x23, x1
    ad18:	394002e0 	ldrb	w0, [x23]
    ad1c:	7103fc1f 	cmp	w0, #0xff
    ad20:	5400e940 	b.eq	ca48 <f0+0x24e4>  // b.none
    ad24:	52800020 	mov	w0, #0x1                   	// #1
    ad28:	390002e0 	strb	w0, [x23]
    ad2c:	9107e3e1 	add	x1, sp, #0x1f8
    ad30:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ad34:	52800020 	mov	w0, #0x1                   	// #1
    ad38:	a91fd7f7 	stp	x23, x21, [sp, #504]
    ad3c:	97ffeab5 	bl	5810 <fwp_data.part.0.constprop.0>
    ad40:	97ffeb38 	bl	5a20 <fwp_rc_fresh>
    ad44:	aa0003e2 	mov	x2, x0
    ad48:	910823e1 	add	x1, sp, #0x208
    ad4c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ad50:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ad54:	52800020 	mov	w0, #0x1                   	// #1
    ad58:	f90107f5 	str	x21, [sp, #520]
    ad5c:	f9010be2 	str	x2, [sp, #528]
    ad60:	97ffeaac 	bl	5810 <fwp_data.part.0.constprop.0>
    ad64:	97ffeb2f 	bl	5a20 <fwp_rc_fresh>
    ad68:	aa0003e2 	mov	x2, x0
    ad6c:	910863e1 	add	x1, sp, #0x218
    ad70:	52800020 	mov	w0, #0x1                   	// #1
    ad74:	f9010ff7 	str	x23, [sp, #536]
    ad78:	f90113e2 	str	x2, [sp, #544]
    ad7c:	97ffeaa5 	bl	5810 <fwp_data.part.0.constprop.0>
    ad80:	97ffeb28 	bl	5a20 <fwp_rc_fresh>
    ad84:	aa0003e2 	mov	x2, x0
    ad88:	9108a3e1 	add	x1, sp, #0x228
    ad8c:	52800020 	mov	w0, #0x1                   	// #1
    ad90:	f90117f5 	str	x21, [sp, #552]
    ad94:	f9011be2 	str	x2, [sp, #560]
    ad98:	97ffea9e 	bl	5810 <fwp_data.part.0.constprop.0>
    ad9c:	91190283 	add	x3, x20, #0x640
    ada0:	aa0003f5 	mov	x21, x0
    ada4:	f949d861 	ldr	x1, [x3, #5040]
    ada8:	f949ec60 	ldr	x0, [x3, #5080]
    adac:	cb0102a1 	sub	x1, x21, x1
    adb0:	eb00403f 	cmp	x1, x0, lsl #16
    adb4:	54000322 	b.cs	ae18 <f0+0x8b4>  // b.hs, b.nlast
    adb8:	d350fc22 	lsr	x2, x1, #16
    adbc:	f949fc63 	ldr	x3, [x3, #5112]
    adc0:	8b020842 	add	x2, x2, x2, lsl #2
    adc4:	d37df042 	lsl	x2, x2, #3
    adc8:	8b020060 	add	x0, x3, x2
    adcc:	f9401017 	ldr	x23, [x0, #32]
    add0:	b4000257 	cbz	x23, ae18 <f0+0x8b4>
    add4:	38626862 	ldrb	w2, [x3, x2]
    add8:	7100085f 	cmp	w2, #0x2
    addc:	5400d9a0 	b.eq	c910 <f0+0x23ac>  // b.none
    ade0:	7100045f 	cmp	w2, #0x1
    ade4:	540001a1 	b.ne	ae18 <f0+0x8b4>  // b.any
    ade8:	29430002 	ldp	w2, w0, [x0, #24]
    adec:	92403c21 	and	x1, x1, #0xffff
    adf0:	9b027c21 	mul	x1, x1, x2
    adf4:	d360fc21 	lsr	x1, x1, #32
    adf8:	eb00003f 	cmp	x1, x0
    adfc:	540000e2 	b.cs	ae18 <f0+0x8b4>  // b.hs, b.nlast
    ae00:	8b0102f7 	add	x23, x23, x1
    ae04:	394002e0 	ldrb	w0, [x23]
    ae08:	7103fc1f 	cmp	w0, #0xff
    ae0c:	5400e240 	b.eq	ca54 <f0+0x24f0>  // b.none
    ae10:	52800020 	mov	w0, #0x1                   	// #1
    ae14:	390002e0 	strb	w0, [x23]
    ae18:	9108e3e1 	add	x1, sp, #0x238
    ae1c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ae20:	52800020 	mov	w0, #0x1                   	// #1
    ae24:	f9011ff7 	str	x23, [sp, #568]
    ae28:	f90123f5 	str	x21, [sp, #576]
    ae2c:	97ffea79 	bl	5810 <fwp_data.part.0.constprop.0>
    ae30:	97ffeafc 	bl	5a20 <fwp_rc_fresh>
    ae34:	aa0003e2 	mov	x2, x0
    ae38:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae3c:	910923e1 	add	x1, sp, #0x248
    ae40:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae44:	52800020 	mov	w0, #0x1                   	// #1
    ae48:	f90127e3 	str	x3, [sp, #584]
    ae4c:	f9012be2 	str	x2, [sp, #592]
    ae50:	97ffea70 	bl	5810 <fwp_data.part.0.constprop.0>
    ae54:	97ffeaf3 	bl	5a20 <fwp_rc_fresh>
    ae58:	aa0003e2 	mov	x2, x0
    ae5c:	910963e1 	add	x1, sp, #0x258
    ae60:	52800020 	mov	w0, #0x1                   	// #1
    ae64:	f9012ff7 	str	x23, [sp, #600]
    ae68:	f90133e2 	str	x2, [sp, #608]
    ae6c:	97ffea69 	bl	5810 <fwp_data.part.0.constprop.0>
    ae70:	91190283 	add	x3, x20, #0x640
    ae74:	aa0003f5 	mov	x21, x0
    ae78:	f949d861 	ldr	x1, [x3, #5040]
    ae7c:	f949ec60 	ldr	x0, [x3, #5080]
    ae80:	cb0102a1 	sub	x1, x21, x1
    ae84:	eb00403f 	cmp	x1, x0, lsl #16
    ae88:	54000322 	b.cs	aeec <f0+0x988>  // b.hs, b.nlast
    ae8c:	d350fc22 	lsr	x2, x1, #16
    ae90:	f949fc63 	ldr	x3, [x3, #5112]
    ae94:	8b020842 	add	x2, x2, x2, lsl #2
    ae98:	d37df042 	lsl	x2, x2, #3
    ae9c:	8b020060 	add	x0, x3, x2
    aea0:	f9401017 	ldr	x23, [x0, #32]
    aea4:	b4000257 	cbz	x23, aeec <f0+0x988>
    aea8:	38626862 	ldrb	w2, [x3, x2]
    aeac:	7100085f 	cmp	w2, #0x2
    aeb0:	5400d2a0 	b.eq	c904 <f0+0x23a0>  // b.none
    aeb4:	7100045f 	cmp	w2, #0x1
    aeb8:	540001a1 	b.ne	aeec <f0+0x988>  // b.any
    aebc:	29430002 	ldp	w2, w0, [x0, #24]
    aec0:	92403c21 	and	x1, x1, #0xffff
    aec4:	9b027c21 	mul	x1, x1, x2
    aec8:	d360fc21 	lsr	x1, x1, #32
    aecc:	eb00003f 	cmp	x1, x0
    aed0:	540000e2 	b.cs	aeec <f0+0x988>  // b.hs, b.nlast
    aed4:	8b0102f7 	add	x23, x23, x1
    aed8:	394002e0 	ldrb	w0, [x23]
    aedc:	7103fc1f 	cmp	w0, #0xff
    aee0:	5400dc00 	b.eq	ca60 <f0+0x24fc>  // b.none
    aee4:	52800020 	mov	w0, #0x1                   	// #1
    aee8:	390002e0 	strb	w0, [x23]
    aeec:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aef0:	9109a3e1 	add	x1, sp, #0x268
    aef4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aef8:	52800020 	mov	w0, #0x1                   	// #1
    aefc:	f90137e2 	str	x2, [sp, #616]
    af00:	f9013bf5 	str	x21, [sp, #624]
    af04:	97ffea43 	bl	5810 <fwp_data.part.0.constprop.0>
    af08:	91190283 	add	x3, x20, #0x640
    af0c:	aa0003f5 	mov	x21, x0
    af10:	f949d861 	ldr	x1, [x3, #5040]
    af14:	f949ec60 	ldr	x0, [x3, #5080]
    af18:	cb0102a1 	sub	x1, x21, x1
    af1c:	eb00403f 	cmp	x1, x0, lsl #16
    af20:	54000322 	b.cs	af84 <f0+0xa20>  // b.hs, b.nlast
    af24:	d350fc22 	lsr	x2, x1, #16
    af28:	f949fc63 	ldr	x3, [x3, #5112]
    af2c:	8b020842 	add	x2, x2, x2, lsl #2
    af30:	d37df042 	lsl	x2, x2, #3
    af34:	8b020060 	add	x0, x3, x2
    af38:	f9401017 	ldr	x23, [x0, #32]
    af3c:	b4000257 	cbz	x23, af84 <f0+0xa20>
    af40:	38626862 	ldrb	w2, [x3, x2]
    af44:	7100085f 	cmp	w2, #0x2
    af48:	5400cd80 	b.eq	c8f8 <f0+0x2394>  // b.none
    af4c:	7100045f 	cmp	w2, #0x1
    af50:	540001a1 	b.ne	af84 <f0+0xa20>  // b.any
    af54:	29430002 	ldp	w2, w0, [x0, #24]
    af58:	92403c21 	and	x1, x1, #0xffff
    af5c:	9b027c21 	mul	x1, x1, x2
    af60:	d360fc21 	lsr	x1, x1, #32
    af64:	eb00003f 	cmp	x1, x0
    af68:	540000e2 	b.cs	af84 <f0+0xa20>  // b.hs, b.nlast
    af6c:	8b0102f7 	add	x23, x23, x1
    af70:	394002e0 	ldrb	w0, [x23]
    af74:	7103fc1f 	cmp	w0, #0xff
    af78:	5400d7a0 	b.eq	ca6c <f0+0x2508>  // b.none
    af7c:	52800020 	mov	w0, #0x1                   	// #1
    af80:	390002e0 	strb	w0, [x23]
    af84:	9109e3e1 	add	x1, sp, #0x278
    af88:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af8c:	52800020 	mov	w0, #0x1                   	// #1
    af90:	f9013ff7 	str	x23, [sp, #632]
    af94:	f90143f5 	str	x21, [sp, #640]
    af98:	97ffea1e 	bl	5810 <fwp_data.part.0.constprop.0>
    af9c:	97ffeaa1 	bl	5a20 <fwp_rc_fresh>
    afa0:	aa0003e2 	mov	x2, x0
    afa4:	910a23e1 	add	x1, sp, #0x288
    afa8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    afac:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    afb0:	52800020 	mov	w0, #0x1                   	// #1
    afb4:	f90147f5 	str	x21, [sp, #648]
    afb8:	f9014be2 	str	x2, [sp, #656]
    afbc:	97ffea15 	bl	5810 <fwp_data.part.0.constprop.0>
    afc0:	97ffea98 	bl	5a20 <fwp_rc_fresh>
    afc4:	aa0003e2 	mov	x2, x0
    afc8:	910a63e1 	add	x1, sp, #0x298
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f9014ff7 	str	x23, [sp, #664]
    afd4:	f90153e2 	str	x2, [sp, #672]
    afd8:	97ffea0e 	bl	5810 <fwp_data.part.0.constprop.0>
    afdc:	97ffea91 	bl	5a20 <fwp_rc_fresh>
    afe0:	aa0003e2 	mov	x2, x0
    afe4:	910aa3e1 	add	x1, sp, #0x2a8
    afe8:	52800020 	mov	w0, #0x1                   	// #1
    afec:	f90157f5 	str	x21, [sp, #680]
    aff0:	f9015be2 	str	x2, [sp, #688]
    aff4:	97ffea07 	bl	5810 <fwp_data.part.0.constprop.0>
    aff8:	97ffea8a 	bl	5a20 <fwp_rc_fresh>
    affc:	aa0003e2 	mov	x2, x0
    b000:	910ae3e1 	add	x1, sp, #0x2b8
    b004:	52800020 	mov	w0, #0x1                   	// #1
    b008:	f9015ff7 	str	x23, [sp, #696]
    b00c:	f90163e2 	str	x2, [sp, #704]
    b010:	97ffea00 	bl	5810 <fwp_data.part.0.constprop.0>
    b014:	97ffea83 	bl	5a20 <fwp_rc_fresh>
    b018:	aa0003e2 	mov	x2, x0
    b01c:	910b23e1 	add	x1, sp, #0x2c8
    b020:	52800020 	mov	w0, #0x1                   	// #1
    b024:	f90167f5 	str	x21, [sp, #712]
    b028:	f9016be2 	str	x2, [sp, #720]
    b02c:	97ffe9f9 	bl	5810 <fwp_data.part.0.constprop.0>
    b030:	91190283 	add	x3, x20, #0x640
    b034:	aa0003f5 	mov	x21, x0
    b038:	f949d861 	ldr	x1, [x3, #5040]
    b03c:	f949ec60 	ldr	x0, [x3, #5080]
    b040:	cb0102a1 	sub	x1, x21, x1
    b044:	eb00403f 	cmp	x1, x0, lsl #16
    b048:	54000322 	b.cs	b0ac <f0+0xb48>  // b.hs, b.nlast
    b04c:	d350fc22 	lsr	x2, x1, #16
    b050:	f949fc63 	ldr	x3, [x3, #5112]
    b054:	8b020842 	add	x2, x2, x2, lsl #2
    b058:	d37df042 	lsl	x2, x2, #3
    b05c:	8b020060 	add	x0, x3, x2
    b060:	f9401017 	ldr	x23, [x0, #32]
    b064:	b4000257 	cbz	x23, b0ac <f0+0xb48>
    b068:	38626862 	ldrb	w2, [x3, x2]
    b06c:	7100085f 	cmp	w2, #0x2
    b070:	5400c3e0 	b.eq	c8ec <f0+0x2388>  // b.none
    b074:	7100045f 	cmp	w2, #0x1
    b078:	540001a1 	b.ne	b0ac <f0+0xb48>  // b.any
    b07c:	29430002 	ldp	w2, w0, [x0, #24]
    b080:	92403c21 	and	x1, x1, #0xffff
    b084:	9b027c21 	mul	x1, x1, x2
    b088:	d360fc21 	lsr	x1, x1, #32
    b08c:	eb00003f 	cmp	x1, x0
    b090:	540000e2 	b.cs	b0ac <f0+0xb48>  // b.hs, b.nlast
    b094:	8b0102f7 	add	x23, x23, x1
    b098:	394002e0 	ldrb	w0, [x23]
    b09c:	7103fc1f 	cmp	w0, #0xff
    b0a0:	5400cec0 	b.eq	ca78 <f0+0x2514>  // b.none
    b0a4:	52800020 	mov	w0, #0x1                   	// #1
    b0a8:	390002e0 	strb	w0, [x23]
    b0ac:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b0b0:	910b63e1 	add	x1, sp, #0x2d8
    b0b4:	52800020 	mov	w0, #0x1                   	// #1
    b0b8:	f9016fe2 	str	x2, [sp, #728]
    b0bc:	f90173f5 	str	x21, [sp, #736]
    b0c0:	97ffe9d4 	bl	5810 <fwp_data.part.0.constprop.0>
    b0c4:	91190283 	add	x3, x20, #0x640
    b0c8:	aa0003f5 	mov	x21, x0
    b0cc:	f949d861 	ldr	x1, [x3, #5040]
    b0d0:	f949ec60 	ldr	x0, [x3, #5080]
    b0d4:	cb0102a1 	sub	x1, x21, x1
    b0d8:	eb00403f 	cmp	x1, x0, lsl #16
    b0dc:	54000322 	b.cs	b140 <f0+0xbdc>  // b.hs, b.nlast
    b0e0:	d350fc22 	lsr	x2, x1, #16
    b0e4:	f949fc63 	ldr	x3, [x3, #5112]
    b0e8:	8b020842 	add	x2, x2, x2, lsl #2
    b0ec:	d37df042 	lsl	x2, x2, #3
    b0f0:	8b020060 	add	x0, x3, x2
    b0f4:	f9401017 	ldr	x23, [x0, #32]
    b0f8:	b4000257 	cbz	x23, b140 <f0+0xbdc>
    b0fc:	38626862 	ldrb	w2, [x3, x2]
    b100:	7100085f 	cmp	w2, #0x2
    b104:	5400bee0 	b.eq	c8e0 <f0+0x237c>  // b.none
    b108:	7100045f 	cmp	w2, #0x1
    b10c:	540001a1 	b.ne	b140 <f0+0xbdc>  // b.any
    b110:	29430002 	ldp	w2, w0, [x0, #24]
    b114:	92403c21 	and	x1, x1, #0xffff
    b118:	9b027c21 	mul	x1, x1, x2
    b11c:	d360fc21 	lsr	x1, x1, #32
    b120:	eb00003f 	cmp	x1, x0
    b124:	540000e2 	b.cs	b140 <f0+0xbdc>  // b.hs, b.nlast
    b128:	8b0102f7 	add	x23, x23, x1
    b12c:	394002e0 	ldrb	w0, [x23]
    b130:	7103fc1f 	cmp	w0, #0xff
    b134:	5400ca80 	b.eq	ca84 <f0+0x2520>  // b.none
    b138:	52800020 	mov	w0, #0x1                   	// #1
    b13c:	390002e0 	strb	w0, [x23]
    b140:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b144:	910ba3e1 	add	x1, sp, #0x2e8
    b148:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b14c:	52800020 	mov	w0, #0x1                   	// #1
    b150:	f90177e2 	str	x2, [sp, #744]
    b154:	f9017bf5 	str	x21, [sp, #752]
    b158:	97ffe9ae 	bl	5810 <fwp_data.part.0.constprop.0>
    b15c:	91190283 	add	x3, x20, #0x640
    b160:	aa0003f5 	mov	x21, x0
    b164:	f949d861 	ldr	x1, [x3, #5040]
    b168:	f949ec60 	ldr	x0, [x3, #5080]
    b16c:	cb0102a1 	sub	x1, x21, x1
    b170:	eb00403f 	cmp	x1, x0, lsl #16
    b174:	54000322 	b.cs	b1d8 <f0+0xc74>  // b.hs, b.nlast
    b178:	d350fc22 	lsr	x2, x1, #16
    b17c:	f949fc63 	ldr	x3, [x3, #5112]
    b180:	8b020842 	add	x2, x2, x2, lsl #2
    b184:	d37df042 	lsl	x2, x2, #3
    b188:	8b020060 	add	x0, x3, x2
    b18c:	f9401017 	ldr	x23, [x0, #32]
    b190:	b4000257 	cbz	x23, b1d8 <f0+0xc74>
    b194:	38626862 	ldrb	w2, [x3, x2]
    b198:	7100085f 	cmp	w2, #0x2
    b19c:	5400b9c0 	b.eq	c8d4 <f0+0x2370>  // b.none
    b1a0:	7100045f 	cmp	w2, #0x1
    b1a4:	540001a1 	b.ne	b1d8 <f0+0xc74>  // b.any
    b1a8:	29430002 	ldp	w2, w0, [x0, #24]
    b1ac:	92403c21 	and	x1, x1, #0xffff
    b1b0:	9b027c21 	mul	x1, x1, x2
    b1b4:	d360fc21 	lsr	x1, x1, #32
    b1b8:	eb00003f 	cmp	x1, x0
    b1bc:	540000e2 	b.cs	b1d8 <f0+0xc74>  // b.hs, b.nlast
    b1c0:	8b0102f7 	add	x23, x23, x1
    b1c4:	394002e0 	ldrb	w0, [x23]
    b1c8:	7103fc1f 	cmp	w0, #0xff
    b1cc:	5400c620 	b.eq	ca90 <f0+0x252c>  // b.none
    b1d0:	52800020 	mov	w0, #0x1                   	// #1
    b1d4:	390002e0 	strb	w0, [x23]
    b1d8:	910be3e1 	add	x1, sp, #0x2f8
    b1dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b1e0:	52800020 	mov	w0, #0x1                   	// #1
    b1e4:	f9017fe2 	str	x2, [sp, #760]
    b1e8:	f90183f5 	str	x21, [sp, #768]
    b1ec:	97ffe989 	bl	5810 <fwp_data.part.0.constprop.0>
    b1f0:	97ffea0c 	bl	5a20 <fwp_rc_fresh>
    b1f4:	aa0003e2 	mov	x2, x0
    b1f8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b1fc:	910c23e1 	add	x1, sp, #0x308
    b200:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b204:	52800020 	mov	w0, #0x1                   	// #1
    b208:	f90187e3 	str	x3, [sp, #776]
    b20c:	f9018be2 	str	x2, [sp, #784]
    b210:	97ffe980 	bl	5810 <fwp_data.part.0.constprop.0>
    b214:	91190283 	add	x3, x20, #0x640
    b218:	aa0003f5 	mov	x21, x0
    b21c:	f949d861 	ldr	x1, [x3, #5040]
    b220:	f949ec60 	ldr	x0, [x3, #5080]
    b224:	cb0102a1 	sub	x1, x21, x1
    b228:	eb00403f 	cmp	x1, x0, lsl #16
    b22c:	54000322 	b.cs	b290 <f0+0xd2c>  // b.hs, b.nlast
    b230:	d350fc22 	lsr	x2, x1, #16
    b234:	f949fc63 	ldr	x3, [x3, #5112]
    b238:	8b020842 	add	x2, x2, x2, lsl #2
    b23c:	d37df042 	lsl	x2, x2, #3
    b240:	8b020060 	add	x0, x3, x2
    b244:	f9401017 	ldr	x23, [x0, #32]
    b248:	b4000257 	cbz	x23, b290 <f0+0xd2c>
    b24c:	38626862 	ldrb	w2, [x3, x2]
    b250:	7100085f 	cmp	w2, #0x2
    b254:	5400b3a0 	b.eq	c8c8 <f0+0x2364>  // b.none
    b258:	7100045f 	cmp	w2, #0x1
    b25c:	540001a1 	b.ne	b290 <f0+0xd2c>  // b.any
    b260:	29430002 	ldp	w2, w0, [x0, #24]
    b264:	92403c21 	and	x1, x1, #0xffff
    b268:	9b027c21 	mul	x1, x1, x2
    b26c:	d360fc21 	lsr	x1, x1, #32
    b270:	eb00003f 	cmp	x1, x0
    b274:	540000e2 	b.cs	b290 <f0+0xd2c>  // b.hs, b.nlast
    b278:	8b0102f7 	add	x23, x23, x1
    b27c:	394002e0 	ldrb	w0, [x23]
    b280:	7103fc1f 	cmp	w0, #0xff
    b284:	5400c0c0 	b.eq	ca9c <f0+0x2538>  // b.none
    b288:	52800020 	mov	w0, #0x1                   	// #1
    b28c:	390002e0 	strb	w0, [x23]
    b290:	910c63e1 	add	x1, sp, #0x318
    b294:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b298:	52800020 	mov	w0, #0x1                   	// #1
    b29c:	f9018ff7 	str	x23, [sp, #792]
    b2a0:	f90193f5 	str	x21, [sp, #800]
    b2a4:	97ffe95b 	bl	5810 <fwp_data.part.0.constprop.0>
    b2a8:	97ffe9de 	bl	5a20 <fwp_rc_fresh>
    b2ac:	aa0003e2 	mov	x2, x0
    b2b0:	910ca3e1 	add	x1, sp, #0x328
    b2b4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b2b8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b2bc:	52800020 	mov	w0, #0x1                   	// #1
    b2c0:	f90197f5 	str	x21, [sp, #808]
    b2c4:	f9019be2 	str	x2, [sp, #816]
    b2c8:	97ffe952 	bl	5810 <fwp_data.part.0.constprop.0>
    b2cc:	97ffe9d5 	bl	5a20 <fwp_rc_fresh>
    b2d0:	aa0003e2 	mov	x2, x0
    b2d4:	910ce3e1 	add	x1, sp, #0x338
    b2d8:	52800020 	mov	w0, #0x1                   	// #1
    b2dc:	f9019ff7 	str	x23, [sp, #824]
    b2e0:	f901a3e2 	str	x2, [sp, #832]
    b2e4:	97ffe94b 	bl	5810 <fwp_data.part.0.constprop.0>
    b2e8:	97ffe9ce 	bl	5a20 <fwp_rc_fresh>
    b2ec:	aa0003e2 	mov	x2, x0
    b2f0:	910d23e1 	add	x1, sp, #0x348
    b2f4:	52800020 	mov	w0, #0x1                   	// #1
    b2f8:	f901a7f5 	str	x21, [sp, #840]
    b2fc:	f901abe2 	str	x2, [sp, #848]
    b300:	97ffe944 	bl	5810 <fwp_data.part.0.constprop.0>
    b304:	97ffe9c7 	bl	5a20 <fwp_rc_fresh>
    b308:	aa0003e2 	mov	x2, x0
    b30c:	910d63e1 	add	x1, sp, #0x358
    b310:	52800020 	mov	w0, #0x1                   	// #1
    b314:	f901aff7 	str	x23, [sp, #856]
    b318:	f901b3e2 	str	x2, [sp, #864]
    b31c:	97ffe93d 	bl	5810 <fwp_data.part.0.constprop.0>
    b320:	97ffe9c0 	bl	5a20 <fwp_rc_fresh>
    b324:	aa0003e2 	mov	x2, x0
    b328:	910da3e1 	add	x1, sp, #0x368
    b32c:	52800020 	mov	w0, #0x1                   	// #1
    b330:	f901b7f5 	str	x21, [sp, #872]
    b334:	f901bbe2 	str	x2, [sp, #880]
    b338:	97ffe936 	bl	5810 <fwp_data.part.0.constprop.0>
    b33c:	97ffe9b9 	bl	5a20 <fwp_rc_fresh>
    b340:	aa0003e2 	mov	x2, x0
    b344:	910de3e1 	add	x1, sp, #0x378
    b348:	52800020 	mov	w0, #0x1                   	// #1
    b34c:	f901bff7 	str	x23, [sp, #888]
    b350:	f901c3e2 	str	x2, [sp, #896]
    b354:	97ffe92f 	bl	5810 <fwp_data.part.0.constprop.0>
    b358:	97ffe9b2 	bl	5a20 <fwp_rc_fresh>
    b35c:	aa0003e2 	mov	x2, x0
    b360:	910e23e1 	add	x1, sp, #0x388
    b364:	52800020 	mov	w0, #0x1                   	// #1
    b368:	f901c7f5 	str	x21, [sp, #904]
    b36c:	f901cbe2 	str	x2, [sp, #912]
    b370:	97ffe928 	bl	5810 <fwp_data.part.0.constprop.0>
    b374:	97ffe9ab 	bl	5a20 <fwp_rc_fresh>
    b378:	aa0003e2 	mov	x2, x0
    b37c:	910e63e1 	add	x1, sp, #0x398
    b380:	52800020 	mov	w0, #0x1                   	// #1
    b384:	f901cff7 	str	x23, [sp, #920]
    b388:	f901d3e2 	str	x2, [sp, #928]
    b38c:	97ffe921 	bl	5810 <fwp_data.part.0.constprop.0>
    b390:	97ffe9a4 	bl	5a20 <fwp_rc_fresh>
    b394:	aa0003e2 	mov	x2, x0
    b398:	910ea3e1 	add	x1, sp, #0x3a8
    b39c:	52800020 	mov	w0, #0x1                   	// #1
    b3a0:	f901d7f5 	str	x21, [sp, #936]
    b3a4:	f901dbe2 	str	x2, [sp, #944]
    b3a8:	97ffe91a 	bl	5810 <fwp_data.part.0.constprop.0>
    b3ac:	91190283 	add	x3, x20, #0x640
    b3b0:	aa0003f5 	mov	x21, x0
    b3b4:	f949d861 	ldr	x1, [x3, #5040]
    b3b8:	f949ec60 	ldr	x0, [x3, #5080]
    b3bc:	cb0102a1 	sub	x1, x21, x1
    b3c0:	eb00403f 	cmp	x1, x0, lsl #16
    b3c4:	54000322 	b.cs	b428 <f0+0xec4>  // b.hs, b.nlast
    b3c8:	d350fc22 	lsr	x2, x1, #16
    b3cc:	f949fc63 	ldr	x3, [x3, #5112]
    b3d0:	8b020842 	add	x2, x2, x2, lsl #2
    b3d4:	d37df042 	lsl	x2, x2, #3
    b3d8:	8b020060 	add	x0, x3, x2
    b3dc:	f9401017 	ldr	x23, [x0, #32]
    b3e0:	b4000257 	cbz	x23, b428 <f0+0xec4>
    b3e4:	38626862 	ldrb	w2, [x3, x2]
    b3e8:	7100085f 	cmp	w2, #0x2
    b3ec:	5400a3e0 	b.eq	c868 <f0+0x2304>  // b.none
    b3f0:	7100045f 	cmp	w2, #0x1
    b3f4:	540001a1 	b.ne	b428 <f0+0xec4>  // b.any
    b3f8:	29430002 	ldp	w2, w0, [x0, #24]
    b3fc:	92403c21 	and	x1, x1, #0xffff
    b400:	9b027c21 	mul	x1, x1, x2
    b404:	d360fc21 	lsr	x1, x1, #32
    b408:	eb00003f 	cmp	x1, x0
    b40c:	540000e2 	b.cs	b428 <f0+0xec4>  // b.hs, b.nlast
    b410:	8b0102f7 	add	x23, x23, x1
    b414:	394002e0 	ldrb	w0, [x23]
    b418:	7103fc1f 	cmp	w0, #0xff
    b41c:	5400b460 	b.eq	caa8 <f0+0x2544>  // b.none
    b420:	52800020 	mov	w0, #0x1                   	// #1
    b424:	390002e0 	strb	w0, [x23]
    b428:	910ee3e1 	add	x1, sp, #0x3b8
    b42c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b430:	52800020 	mov	w0, #0x1                   	// #1
    b434:	f901dfe2 	str	x2, [sp, #952]
    b438:	f901e3f5 	str	x21, [sp, #960]
    b43c:	97ffe8f5 	bl	5810 <fwp_data.part.0.constprop.0>
    b440:	97ffe978 	bl	5a20 <fwp_rc_fresh>
    b444:	aa0003e2 	mov	x2, x0
    b448:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b44c:	910f23e1 	add	x1, sp, #0x3c8
    b450:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b454:	52800020 	mov	w0, #0x1                   	// #1
    b458:	f901e7e3 	str	x3, [sp, #968]
    b45c:	f901ebe2 	str	x2, [sp, #976]
    b460:	97ffe8ec 	bl	5810 <fwp_data.part.0.constprop.0>
    b464:	91190283 	add	x3, x20, #0x640
    b468:	aa0003f5 	mov	x21, x0
    b46c:	f949d861 	ldr	x1, [x3, #5040]
    b470:	f949ec60 	ldr	x0, [x3, #5080]
    b474:	cb0102a1 	sub	x1, x21, x1
    b478:	eb00403f 	cmp	x1, x0, lsl #16
    b47c:	54000322 	b.cs	b4e0 <f0+0xf7c>  // b.hs, b.nlast
    b480:	d350fc22 	lsr	x2, x1, #16
    b484:	f949fc63 	ldr	x3, [x3, #5112]
    b488:	8b020842 	add	x2, x2, x2, lsl #2
    b48c:	d37df042 	lsl	x2, x2, #3
    b490:	8b020060 	add	x0, x3, x2
    b494:	f9401017 	ldr	x23, [x0, #32]
    b498:	b4000257 	cbz	x23, b4e0 <f0+0xf7c>
    b49c:	38626862 	ldrb	w2, [x3, x2]
    b4a0:	7100085f 	cmp	w2, #0x2
    b4a4:	54009dc0 	b.eq	c85c <f0+0x22f8>  // b.none
    b4a8:	7100045f 	cmp	w2, #0x1
    b4ac:	540001a1 	b.ne	b4e0 <f0+0xf7c>  // b.any
    b4b0:	29430002 	ldp	w2, w0, [x0, #24]
    b4b4:	92403c21 	and	x1, x1, #0xffff
    b4b8:	9b027c21 	mul	x1, x1, x2
    b4bc:	d360fc21 	lsr	x1, x1, #32
    b4c0:	eb00003f 	cmp	x1, x0
    b4c4:	540000e2 	b.cs	b4e0 <f0+0xf7c>  // b.hs, b.nlast
    b4c8:	8b0102f7 	add	x23, x23, x1
    b4cc:	394002e0 	ldrb	w0, [x23]
    b4d0:	7103fc1f 	cmp	w0, #0xff
    b4d4:	5400af00 	b.eq	cab4 <f0+0x2550>  // b.none
    b4d8:	52800020 	mov	w0, #0x1                   	// #1
    b4dc:	390002e0 	strb	w0, [x23]
    b4e0:	910f63e1 	add	x1, sp, #0x3d8
    b4e4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b4e8:	52800020 	mov	w0, #0x1                   	// #1
    b4ec:	f901efe2 	str	x2, [sp, #984]
    b4f0:	f901f3f5 	str	x21, [sp, #992]
    b4f4:	97ffe8c7 	bl	5810 <fwp_data.part.0.constprop.0>
    b4f8:	97ffe94a 	bl	5a20 <fwp_rc_fresh>
    b4fc:	aa0003e2 	mov	x2, x0
    b500:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b504:	910fa3e1 	add	x1, sp, #0x3e8
    b508:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b50c:	52800020 	mov	w0, #0x1                   	// #1
    b510:	f901f7e3 	str	x3, [sp, #1000]
    b514:	f901fbe2 	str	x2, [sp, #1008]
    b518:	97ffe8be 	bl	5810 <fwp_data.part.0.constprop.0>
    b51c:	91190283 	add	x3, x20, #0x640
    b520:	aa0003f7 	mov	x23, x0
    b524:	f949d861 	ldr	x1, [x3, #5040]
    b528:	f949ec60 	ldr	x0, [x3, #5080]
    b52c:	cb0102e1 	sub	x1, x23, x1
    b530:	eb00403f 	cmp	x1, x0, lsl #16
    b534:	54000322 	b.cs	b598 <f0+0x1034>  // b.hs, b.nlast
    b538:	d350fc22 	lsr	x2, x1, #16
    b53c:	f949fc63 	ldr	x3, [x3, #5112]
    b540:	8b020842 	add	x2, x2, x2, lsl #2
    b544:	d37df042 	lsl	x2, x2, #3
    b548:	8b020060 	add	x0, x3, x2
    b54c:	f9401015 	ldr	x21, [x0, #32]
    b550:	b4000255 	cbz	x21, b598 <f0+0x1034>
    b554:	38626862 	ldrb	w2, [x3, x2]
    b558:	7100085f 	cmp	w2, #0x2
    b55c:	540097a0 	b.eq	c850 <f0+0x22ec>  // b.none
    b560:	7100045f 	cmp	w2, #0x1
    b564:	540001a1 	b.ne	b598 <f0+0x1034>  // b.any
    b568:	29430002 	ldp	w2, w0, [x0, #24]
    b56c:	92403c21 	and	x1, x1, #0xffff
    b570:	9b027c21 	mul	x1, x1, x2
    b574:	d360fc21 	lsr	x1, x1, #32
    b578:	eb00003f 	cmp	x1, x0
    b57c:	540000e2 	b.cs	b598 <f0+0x1034>  // b.hs, b.nlast
    b580:	8b0102b5 	add	x21, x21, x1
    b584:	394002a0 	ldrb	w0, [x21]
    b588:	7103fc1f 	cmp	w0, #0xff
    b58c:	5400a9a0 	b.eq	cac0 <f0+0x255c>  // b.none
    b590:	52800020 	mov	w0, #0x1                   	// #1
    b594:	390002a0 	strb	w0, [x21]
    b598:	910fe3e1 	add	x1, sp, #0x3f8
    b59c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b5a0:	52800020 	mov	w0, #0x1                   	// #1
    b5a4:	f901fff5 	str	x21, [sp, #1016]
    b5a8:	f90203f7 	str	x23, [sp, #1024]
    b5ac:	97ffe899 	bl	5810 <fwp_data.part.0.constprop.0>
    b5b0:	97ffe91c 	bl	5a20 <fwp_rc_fresh>
    b5b4:	aa0003e2 	mov	x2, x0
    b5b8:	911023e1 	add	x1, sp, #0x408
    b5bc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b5c0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b5c4:	52800020 	mov	w0, #0x1                   	// #1
    b5c8:	f90207f7 	str	x23, [sp, #1032]
    b5cc:	f9020be2 	str	x2, [sp, #1040]
    b5d0:	97ffe890 	bl	5810 <fwp_data.part.0.constprop.0>
    b5d4:	97ffe913 	bl	5a20 <fwp_rc_fresh>
    b5d8:	aa0003e2 	mov	x2, x0
    b5dc:	911063e1 	add	x1, sp, #0x418
    b5e0:	52800020 	mov	w0, #0x1                   	// #1
    b5e4:	f9020ff5 	str	x21, [sp, #1048]
    b5e8:	f90213e2 	str	x2, [sp, #1056]
    b5ec:	97ffe889 	bl	5810 <fwp_data.part.0.constprop.0>
    b5f0:	97ffe90c 	bl	5a20 <fwp_rc_fresh>
    b5f4:	aa0003e2 	mov	x2, x0
    b5f8:	9110a3e1 	add	x1, sp, #0x428
    b5fc:	52800020 	mov	w0, #0x1                   	// #1
    b600:	f90217f7 	str	x23, [sp, #1064]
    b604:	f9021be2 	str	x2, [sp, #1072]
    b608:	97ffe882 	bl	5810 <fwp_data.part.0.constprop.0>
    b60c:	97ffe905 	bl	5a20 <fwp_rc_fresh>
    b610:	aa0003e2 	mov	x2, x0
    b614:	9110e3e1 	add	x1, sp, #0x438
    b618:	52800020 	mov	w0, #0x1                   	// #1
    b61c:	f9021ff5 	str	x21, [sp, #1080]
    b620:	f90223e2 	str	x2, [sp, #1088]
    b624:	97ffe87b 	bl	5810 <fwp_data.part.0.constprop.0>
    b628:	97ffe8fe 	bl	5a20 <fwp_rc_fresh>
    b62c:	aa0003e2 	mov	x2, x0
    b630:	911123e1 	add	x1, sp, #0x448
    b634:	52800020 	mov	w0, #0x1                   	// #1
    b638:	f90227f7 	str	x23, [sp, #1096]
    b63c:	f9022be2 	str	x2, [sp, #1104]
    b640:	97ffe874 	bl	5810 <fwp_data.part.0.constprop.0>
    b644:	97ffe8f7 	bl	5a20 <fwp_rc_fresh>
    b648:	aa0003e2 	mov	x2, x0
    b64c:	911163e1 	add	x1, sp, #0x458
    b650:	52800020 	mov	w0, #0x1                   	// #1
    b654:	f9022ff5 	str	x21, [sp, #1112]
    b658:	f90233e2 	str	x2, [sp, #1120]
    b65c:	97ffe86d 	bl	5810 <fwp_data.part.0.constprop.0>
    b660:	91190283 	add	x3, x20, #0x640
    b664:	aa0003f5 	mov	x21, x0
    b668:	f949d861 	ldr	x1, [x3, #5040]
    b66c:	f949ec60 	ldr	x0, [x3, #5080]
    b670:	cb0102a1 	sub	x1, x21, x1
    b674:	eb00403f 	cmp	x1, x0, lsl #16
    b678:	54000322 	b.cs	b6dc <f0+0x1178>  // b.hs, b.nlast
    b67c:	d350fc22 	lsr	x2, x1, #16
    b680:	f949fc63 	ldr	x3, [x3, #5112]
    b684:	8b020842 	add	x2, x2, x2, lsl #2
    b688:	d37df042 	lsl	x2, x2, #3
    b68c:	8b020060 	add	x0, x3, x2
    b690:	f9401017 	ldr	x23, [x0, #32]
    b694:	b4000257 	cbz	x23, b6dc <f0+0x1178>
    b698:	38626862 	ldrb	w2, [x3, x2]
    b69c:	7100085f 	cmp	w2, #0x2
    b6a0:	54008d20 	b.eq	c844 <f0+0x22e0>  // b.none
    b6a4:	7100045f 	cmp	w2, #0x1
    b6a8:	540001a1 	b.ne	b6dc <f0+0x1178>  // b.any
    b6ac:	29430002 	ldp	w2, w0, [x0, #24]
    b6b0:	92403c21 	and	x1, x1, #0xffff
    b6b4:	9b027c21 	mul	x1, x1, x2
    b6b8:	d360fc21 	lsr	x1, x1, #32
    b6bc:	eb00003f 	cmp	x1, x0
    b6c0:	540000e2 	b.cs	b6dc <f0+0x1178>  // b.hs, b.nlast
    b6c4:	8b0102f7 	add	x23, x23, x1
    b6c8:	394002e0 	ldrb	w0, [x23]
    b6cc:	7103fc1f 	cmp	w0, #0xff
    b6d0:	54009fe0 	b.eq	cacc <f0+0x2568>  // b.none
    b6d4:	52800020 	mov	w0, #0x1                   	// #1
    b6d8:	390002e0 	strb	w0, [x23]
    b6dc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b6e0:	9111a3e1 	add	x1, sp, #0x468
    b6e4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b6e8:	52800020 	mov	w0, #0x1                   	// #1
    b6ec:	f90237e2 	str	x2, [sp, #1128]
    b6f0:	f9023bf5 	str	x21, [sp, #1136]
    b6f4:	97ffe847 	bl	5810 <fwp_data.part.0.constprop.0>
    b6f8:	91190283 	add	x3, x20, #0x640
    b6fc:	aa0003f5 	mov	x21, x0
    b700:	f949d861 	ldr	x1, [x3, #5040]
    b704:	f949ec60 	ldr	x0, [x3, #5080]
    b708:	cb0102a1 	sub	x1, x21, x1
    b70c:	eb00403f 	cmp	x1, x0, lsl #16
    b710:	54000322 	b.cs	b774 <f0+0x1210>  // b.hs, b.nlast
    b714:	d350fc22 	lsr	x2, x1, #16
    b718:	f949fc63 	ldr	x3, [x3, #5112]
    b71c:	8b020842 	add	x2, x2, x2, lsl #2
    b720:	d37df042 	lsl	x2, x2, #3
    b724:	8b020060 	add	x0, x3, x2
    b728:	f9401017 	ldr	x23, [x0, #32]
    b72c:	b4000257 	cbz	x23, b774 <f0+0x1210>
    b730:	38626862 	ldrb	w2, [x3, x2]
    b734:	7100085f 	cmp	w2, #0x2
    b738:	54008800 	b.eq	c838 <f0+0x22d4>  // b.none
    b73c:	7100045f 	cmp	w2, #0x1
    b740:	540001a1 	b.ne	b774 <f0+0x1210>  // b.any
    b744:	29430002 	ldp	w2, w0, [x0, #24]
    b748:	92403c21 	and	x1, x1, #0xffff
    b74c:	9b027c21 	mul	x1, x1, x2
    b750:	d360fc21 	lsr	x1, x1, #32
    b754:	eb00003f 	cmp	x1, x0
    b758:	540000e2 	b.cs	b774 <f0+0x1210>  // b.hs, b.nlast
    b75c:	8b0102f7 	add	x23, x23, x1
    b760:	394002e0 	ldrb	w0, [x23]
    b764:	7103fc1f 	cmp	w0, #0xff
    b768:	54009b80 	b.eq	cad8 <f0+0x2574>  // b.none
    b76c:	52800020 	mov	w0, #0x1                   	// #1
    b770:	390002e0 	strb	w0, [x23]
    b774:	9111e3e1 	add	x1, sp, #0x478
    b778:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b77c:	52800020 	mov	w0, #0x1                   	// #1
    b780:	f9023ff7 	str	x23, [sp, #1144]
    b784:	f90243f5 	str	x21, [sp, #1152]
    b788:	97ffe822 	bl	5810 <fwp_data.part.0.constprop.0>
    b78c:	97ffe8a5 	bl	5a20 <fwp_rc_fresh>
    b790:	aa0003e2 	mov	x2, x0
    b794:	911223e1 	add	x1, sp, #0x488
    b798:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b79c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b7a0:	52800020 	mov	w0, #0x1                   	// #1
    b7a4:	f90247f5 	str	x21, [sp, #1160]
    b7a8:	f9024be2 	str	x2, [sp, #1168]
    b7ac:	97ffe819 	bl	5810 <fwp_data.part.0.constprop.0>
    b7b0:	97ffe89c 	bl	5a20 <fwp_rc_fresh>
    b7b4:	aa0003e2 	mov	x2, x0
    b7b8:	911263e1 	add	x1, sp, #0x498
    b7bc:	52800020 	mov	w0, #0x1                   	// #1
    b7c0:	f9024ff7 	str	x23, [sp, #1176]
    b7c4:	f90253e2 	str	x2, [sp, #1184]
    b7c8:	97ffe812 	bl	5810 <fwp_data.part.0.constprop.0>
    b7cc:	97ffe895 	bl	5a20 <fwp_rc_fresh>
    b7d0:	aa0003e2 	mov	x2, x0
    b7d4:	9112a3e1 	add	x1, sp, #0x4a8
    b7d8:	52800020 	mov	w0, #0x1                   	// #1
    b7dc:	f90257f5 	str	x21, [sp, #1192]
    b7e0:	f9025be2 	str	x2, [sp, #1200]
    b7e4:	97ffe80b 	bl	5810 <fwp_data.part.0.constprop.0>
    b7e8:	91190283 	add	x3, x20, #0x640
    b7ec:	aa0003f5 	mov	x21, x0
    b7f0:	f949d861 	ldr	x1, [x3, #5040]
    b7f4:	f949ec60 	ldr	x0, [x3, #5080]
    b7f8:	cb0102a1 	sub	x1, x21, x1
    b7fc:	eb00403f 	cmp	x1, x0, lsl #16
    b800:	54000322 	b.cs	b864 <f0+0x1300>  // b.hs, b.nlast
    b804:	d350fc22 	lsr	x2, x1, #16
    b808:	f949fc63 	ldr	x3, [x3, #5112]
    b80c:	8b020842 	add	x2, x2, x2, lsl #2
    b810:	d37df042 	lsl	x2, x2, #3
    b814:	8b020060 	add	x0, x3, x2
    b818:	f9401017 	ldr	x23, [x0, #32]
    b81c:	b4000257 	cbz	x23, b864 <f0+0x1300>
    b820:	38626862 	ldrb	w2, [x3, x2]
    b824:	7100085f 	cmp	w2, #0x2
    b828:	54008020 	b.eq	c82c <f0+0x22c8>  // b.none
    b82c:	7100045f 	cmp	w2, #0x1
    b830:	540001a1 	b.ne	b864 <f0+0x1300>  // b.any
    b834:	29430002 	ldp	w2, w0, [x0, #24]
    b838:	92403c21 	and	x1, x1, #0xffff
    b83c:	9b027c21 	mul	x1, x1, x2
    b840:	d360fc21 	lsr	x1, x1, #32
    b844:	eb00003f 	cmp	x1, x0
    b848:	540000e2 	b.cs	b864 <f0+0x1300>  // b.hs, b.nlast
    b84c:	8b0102f7 	add	x23, x23, x1
    b850:	394002e0 	ldrb	w0, [x23]
    b854:	7103fc1f 	cmp	w0, #0xff
    b858:	54009460 	b.eq	cae4 <f0+0x2580>  // b.none
    b85c:	52800020 	mov	w0, #0x1                   	// #1
    b860:	390002e0 	strb	w0, [x23]
    b864:	9112e3e1 	add	x1, sp, #0x4b8
    b868:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b86c:	52800020 	mov	w0, #0x1                   	// #1
    b870:	f9025ff7 	str	x23, [sp, #1208]
    b874:	f90263f5 	str	x21, [sp, #1216]
    b878:	97ffe7e6 	bl	5810 <fwp_data.part.0.constprop.0>
    b87c:	97ffe869 	bl	5a20 <fwp_rc_fresh>
    b880:	aa0003e2 	mov	x2, x0
    b884:	911323e1 	add	x1, sp, #0x4c8
    b888:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b88c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b890:	52800020 	mov	w0, #0x1                   	// #1
    b894:	f90267f5 	str	x21, [sp, #1224]
    b898:	f9026be2 	str	x2, [sp, #1232]
    b89c:	97ffe7dd 	bl	5810 <fwp_data.part.0.constprop.0>
    b8a0:	97ffe860 	bl	5a20 <fwp_rc_fresh>
    b8a4:	aa0003e2 	mov	x2, x0
    b8a8:	911363e1 	add	x1, sp, #0x4d8
    b8ac:	52800020 	mov	w0, #0x1                   	// #1
    b8b0:	f9026ff7 	str	x23, [sp, #1240]
    b8b4:	f90273e2 	str	x2, [sp, #1248]
    b8b8:	97ffe7d6 	bl	5810 <fwp_data.part.0.constprop.0>
    b8bc:	97ffe859 	bl	5a20 <fwp_rc_fresh>
    b8c0:	aa0003e2 	mov	x2, x0
    b8c4:	9113a3e1 	add	x1, sp, #0x4e8
    b8c8:	52800020 	mov	w0, #0x1                   	// #1
    b8cc:	f90277f5 	str	x21, [sp, #1256]
    b8d0:	f9027be2 	str	x2, [sp, #1264]
    b8d4:	97ffe7cf 	bl	5810 <fwp_data.part.0.constprop.0>
    b8d8:	91190283 	add	x3, x20, #0x640
    b8dc:	aa0003f5 	mov	x21, x0
    b8e0:	f949d861 	ldr	x1, [x3, #5040]
    b8e4:	f949ec60 	ldr	x0, [x3, #5080]
    b8e8:	cb0102a1 	sub	x1, x21, x1
    b8ec:	eb00403f 	cmp	x1, x0, lsl #16
    b8f0:	54000322 	b.cs	b954 <f0+0x13f0>  // b.hs, b.nlast
    b8f4:	d350fc22 	lsr	x2, x1, #16
    b8f8:	f949fc63 	ldr	x3, [x3, #5112]
    b8fc:	8b020842 	add	x2, x2, x2, lsl #2
    b900:	d37df042 	lsl	x2, x2, #3
    b904:	8b020060 	add	x0, x3, x2
    b908:	f9401017 	ldr	x23, [x0, #32]
    b90c:	b4000257 	cbz	x23, b954 <f0+0x13f0>
    b910:	38626862 	ldrb	w2, [x3, x2]
    b914:	7100085f 	cmp	w2, #0x2
    b918:	54007840 	b.eq	c820 <f0+0x22bc>  // b.none
    b91c:	7100045f 	cmp	w2, #0x1
    b920:	540001a1 	b.ne	b954 <f0+0x13f0>  // b.any
    b924:	29430002 	ldp	w2, w0, [x0, #24]
    b928:	92403c21 	and	x1, x1, #0xffff
    b92c:	9b027c21 	mul	x1, x1, x2
    b930:	d360fc21 	lsr	x1, x1, #32
    b934:	eb00003f 	cmp	x1, x0
    b938:	540000e2 	b.cs	b954 <f0+0x13f0>  // b.hs, b.nlast
    b93c:	8b0102f7 	add	x23, x23, x1
    b940:	394002e0 	ldrb	w0, [x23]
    b944:	7103fc1f 	cmp	w0, #0xff
    b948:	54008d40 	b.eq	caf0 <f0+0x258c>  // b.none
    b94c:	52800020 	mov	w0, #0x1                   	// #1
    b950:	390002e0 	strb	w0, [x23]
    b954:	9113e3e1 	add	x1, sp, #0x4f8
    b958:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b95c:	52800020 	mov	w0, #0x1                   	// #1
    b960:	f9027fe2 	str	x2, [sp, #1272]
    b964:	f90283f5 	str	x21, [sp, #1280]
    b968:	97ffe7aa 	bl	5810 <fwp_data.part.0.constprop.0>
    b96c:	97ffe82d 	bl	5a20 <fwp_rc_fresh>
    b970:	aa0003e2 	mov	x2, x0
    b974:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b978:	911423e1 	add	x1, sp, #0x508
    b97c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b980:	52800020 	mov	w0, #0x1                   	// #1
    b984:	f90287e3 	str	x3, [sp, #1288]
    b988:	f9028be2 	str	x2, [sp, #1296]
    b98c:	97ffe7a1 	bl	5810 <fwp_data.part.0.constprop.0>
    b990:	91190283 	add	x3, x20, #0x640
    b994:	aa0003f5 	mov	x21, x0
    b998:	f949d861 	ldr	x1, [x3, #5040]
    b99c:	f949ec60 	ldr	x0, [x3, #5080]
    b9a0:	cb0102a1 	sub	x1, x21, x1
    b9a4:	eb00403f 	cmp	x1, x0, lsl #16
    b9a8:	54000322 	b.cs	ba0c <f0+0x14a8>  // b.hs, b.nlast
    b9ac:	d350fc22 	lsr	x2, x1, #16
    b9b0:	f949fc63 	ldr	x3, [x3, #5112]
    b9b4:	8b020842 	add	x2, x2, x2, lsl #2
    b9b8:	d37df042 	lsl	x2, x2, #3
    b9bc:	8b020060 	add	x0, x3, x2
    b9c0:	f9401017 	ldr	x23, [x0, #32]
    b9c4:	b4000257 	cbz	x23, ba0c <f0+0x14a8>
    b9c8:	38626862 	ldrb	w2, [x3, x2]
    b9cc:	7100085f 	cmp	w2, #0x2
    b9d0:	54007220 	b.eq	c814 <f0+0x22b0>  // b.none
    b9d4:	7100045f 	cmp	w2, #0x1
    b9d8:	540001a1 	b.ne	ba0c <f0+0x14a8>  // b.any
    b9dc:	29430002 	ldp	w2, w0, [x0, #24]
    b9e0:	92403c21 	and	x1, x1, #0xffff
    b9e4:	9b027c21 	mul	x1, x1, x2
    b9e8:	d360fc21 	lsr	x1, x1, #32
    b9ec:	eb00003f 	cmp	x1, x0
    b9f0:	540000e2 	b.cs	ba0c <f0+0x14a8>  // b.hs, b.nlast
    b9f4:	8b0102f7 	add	x23, x23, x1
    b9f8:	394002e0 	ldrb	w0, [x23]
    b9fc:	7103fc1f 	cmp	w0, #0xff
    ba00:	540087e0 	b.eq	cafc <f0+0x2598>  // b.none
    ba04:	52800020 	mov	w0, #0x1                   	// #1
    ba08:	390002e0 	strb	w0, [x23]
    ba0c:	911463e1 	add	x1, sp, #0x518
    ba10:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba14:	52800020 	mov	w0, #0x1                   	// #1
    ba18:	f9028fe2 	str	x2, [sp, #1304]
    ba1c:	f90293f5 	str	x21, [sp, #1312]
    ba20:	97ffe77c 	bl	5810 <fwp_data.part.0.constprop.0>
    ba24:	97ffe7ff 	bl	5a20 <fwp_rc_fresh>
    ba28:	aa0003e2 	mov	x2, x0
    ba2c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ba30:	9114a3e1 	add	x1, sp, #0x528
    ba34:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ba38:	52800020 	mov	w0, #0x1                   	// #1
    ba3c:	f90297e3 	str	x3, [sp, #1320]
    ba40:	f9029be2 	str	x2, [sp, #1328]
    ba44:	97ffe773 	bl	5810 <fwp_data.part.0.constprop.0>
    ba48:	91190283 	add	x3, x20, #0x640
    ba4c:	aa0003f5 	mov	x21, x0
    ba50:	f949d861 	ldr	x1, [x3, #5040]
    ba54:	f949ec60 	ldr	x0, [x3, #5080]
    ba58:	cb0102a1 	sub	x1, x21, x1
    ba5c:	eb00403f 	cmp	x1, x0, lsl #16
    ba60:	54000322 	b.cs	bac4 <f0+0x1560>  // b.hs, b.nlast
    ba64:	d350fc22 	lsr	x2, x1, #16
    ba68:	f949fc63 	ldr	x3, [x3, #5112]
    ba6c:	8b020842 	add	x2, x2, x2, lsl #2
    ba70:	d37df042 	lsl	x2, x2, #3
    ba74:	8b020060 	add	x0, x3, x2
    ba78:	f9401017 	ldr	x23, [x0, #32]
    ba7c:	b4000257 	cbz	x23, bac4 <f0+0x1560>
    ba80:	38626862 	ldrb	w2, [x3, x2]
    ba84:	7100085f 	cmp	w2, #0x2
    ba88:	54007aa0 	b.eq	c9dc <f0+0x2478>  // b.none
    ba8c:	7100045f 	cmp	w2, #0x1
    ba90:	540001a1 	b.ne	bac4 <f0+0x1560>  // b.any
    ba94:	29430002 	ldp	w2, w0, [x0, #24]
    ba98:	92403c21 	and	x1, x1, #0xffff
    ba9c:	9b027c21 	mul	x1, x1, x2
    baa0:	d360fc21 	lsr	x1, x1, #32
    baa4:	eb00003f 	cmp	x1, x0
    baa8:	540000e2 	b.cs	bac4 <f0+0x1560>  // b.hs, b.nlast
    baac:	8b0102f7 	add	x23, x23, x1
    bab0:	394002e0 	ldrb	w0, [x23]
    bab4:	7103fc1f 	cmp	w0, #0xff
    bab8:	54008280 	b.eq	cb08 <f0+0x25a4>  // b.none
    babc:	52800020 	mov	w0, #0x1                   	// #1
    bac0:	390002e0 	strb	w0, [x23]
    bac4:	9114e3e1 	add	x1, sp, #0x538
    bac8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bacc:	52800020 	mov	w0, #0x1                   	// #1
    bad0:	f9029ff7 	str	x23, [sp, #1336]
    bad4:	f902a3f5 	str	x21, [sp, #1344]
    bad8:	97ffe74e 	bl	5810 <fwp_data.part.0.constprop.0>
    badc:	97ffe7d1 	bl	5a20 <fwp_rc_fresh>
    bae0:	aa0003e2 	mov	x2, x0
    bae4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bae8:	911523e1 	add	x1, sp, #0x548
    baec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    baf0:	52800020 	mov	w0, #0x1                   	// #1
    baf4:	f902a7e3 	str	x3, [sp, #1352]
    baf8:	f902abe2 	str	x2, [sp, #1360]
    bafc:	97ffe745 	bl	5810 <fwp_data.part.0.constprop.0>
    bb00:	97ffe7c8 	bl	5a20 <fwp_rc_fresh>
    bb04:	aa0003e2 	mov	x2, x0
    bb08:	911563e1 	add	x1, sp, #0x558
    bb0c:	52800020 	mov	w0, #0x1                   	// #1
    bb10:	f902aff7 	str	x23, [sp, #1368]
    bb14:	f902b3e2 	str	x2, [sp, #1376]
    bb18:	97ffe73e 	bl	5810 <fwp_data.part.0.constprop.0>
    bb1c:	91190283 	add	x3, x20, #0x640
    bb20:	aa0003f5 	mov	x21, x0
    bb24:	f949d861 	ldr	x1, [x3, #5040]
    bb28:	f949ec60 	ldr	x0, [x3, #5080]
    bb2c:	cb0102a1 	sub	x1, x21, x1
    bb30:	eb00403f 	cmp	x1, x0, lsl #16
    bb34:	54000322 	b.cs	bb98 <f0+0x1634>  // b.hs, b.nlast
    bb38:	d350fc22 	lsr	x2, x1, #16
    bb3c:	f949fc63 	ldr	x3, [x3, #5112]
    bb40:	8b020842 	add	x2, x2, x2, lsl #2
    bb44:	d37df042 	lsl	x2, x2, #3
    bb48:	8b020060 	add	x0, x3, x2
    bb4c:	f9401017 	ldr	x23, [x0, #32]
    bb50:	b4000257 	cbz	x23, bb98 <f0+0x1634>
    bb54:	38626862 	ldrb	w2, [x3, x2]
    bb58:	7100085f 	cmp	w2, #0x2
    bb5c:	540073a0 	b.eq	c9d0 <f0+0x246c>  // b.none
    bb60:	7100045f 	cmp	w2, #0x1
    bb64:	540001a1 	b.ne	bb98 <f0+0x1634>  // b.any
    bb68:	29430002 	ldp	w2, w0, [x0, #24]
    bb6c:	92403c21 	and	x1, x1, #0xffff
    bb70:	9b027c21 	mul	x1, x1, x2
    bb74:	d360fc21 	lsr	x1, x1, #32
    bb78:	eb00003f 	cmp	x1, x0
    bb7c:	540000e2 	b.cs	bb98 <f0+0x1634>  // b.hs, b.nlast
    bb80:	8b0102f7 	add	x23, x23, x1
    bb84:	394002e0 	ldrb	w0, [x23]
    bb88:	7103fc1f 	cmp	w0, #0xff
    bb8c:	54007c40 	b.eq	cb14 <f0+0x25b0>  // b.none
    bb90:	52800020 	mov	w0, #0x1                   	// #1
    bb94:	390002e0 	strb	w0, [x23]
    bb98:	9115a3e1 	add	x1, sp, #0x568
    bb9c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bba0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bba4:	52800020 	mov	w0, #0x1                   	// #1
    bba8:	f902b7f7 	str	x23, [sp, #1384]
    bbac:	f902bbf5 	str	x21, [sp, #1392]
    bbb0:	97ffe718 	bl	5810 <fwp_data.part.0.constprop.0>
    bbb4:	97ffe79b 	bl	5a20 <fwp_rc_fresh>
    bbb8:	aa0003e2 	mov	x2, x0
    bbbc:	9115e3e1 	add	x1, sp, #0x578
    bbc0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bbc4:	52800020 	mov	w0, #0x1                   	// #1
    bbc8:	f902bff5 	str	x21, [sp, #1400]
    bbcc:	f902c3e2 	str	x2, [sp, #1408]
    bbd0:	97ffe710 	bl	5810 <fwp_data.part.0.constprop.0>
    bbd4:	97ffe793 	bl	5a20 <fwp_rc_fresh>
    bbd8:	aa0003e2 	mov	x2, x0
    bbdc:	911623e1 	add	x1, sp, #0x588
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	f902c7f7 	str	x23, [sp, #1416]
    bbe8:	f902cbe2 	str	x2, [sp, #1424]
    bbec:	97ffe709 	bl	5810 <fwp_data.part.0.constprop.0>
    bbf0:	97ffe78c 	bl	5a20 <fwp_rc_fresh>
    bbf4:	aa0003e2 	mov	x2, x0
    bbf8:	911663e1 	add	x1, sp, #0x598
    bbfc:	52800020 	mov	w0, #0x1                   	// #1
    bc00:	f902cff5 	str	x21, [sp, #1432]
    bc04:	f902d3e2 	str	x2, [sp, #1440]
    bc08:	97ffe702 	bl	5810 <fwp_data.part.0.constprop.0>
    bc0c:	97ffe785 	bl	5a20 <fwp_rc_fresh>
    bc10:	aa0003e2 	mov	x2, x0
    bc14:	9116a3e1 	add	x1, sp, #0x5a8
    bc18:	52800020 	mov	w0, #0x1                   	// #1
    bc1c:	f902d7f7 	str	x23, [sp, #1448]
    bc20:	f902dbe2 	str	x2, [sp, #1456]
    bc24:	97ffe6fb 	bl	5810 <fwp_data.part.0.constprop.0>
    bc28:	91190283 	add	x3, x20, #0x640
    bc2c:	aa0003f5 	mov	x21, x0
    bc30:	f949d861 	ldr	x1, [x3, #5040]
    bc34:	f949ec60 	ldr	x0, [x3, #5080]
    bc38:	cb0102a1 	sub	x1, x21, x1
    bc3c:	eb00403f 	cmp	x1, x0, lsl #16
    bc40:	54000322 	b.cs	bca4 <f0+0x1740>  // b.hs, b.nlast
    bc44:	d350fc22 	lsr	x2, x1, #16
    bc48:	f949fc63 	ldr	x3, [x3, #5112]
    bc4c:	8b020842 	add	x2, x2, x2, lsl #2
    bc50:	d37df042 	lsl	x2, x2, #3
    bc54:	8b020060 	add	x0, x3, x2
    bc58:	f9401017 	ldr	x23, [x0, #32]
    bc5c:	b4000257 	cbz	x23, bca4 <f0+0x1740>
    bc60:	38626862 	ldrb	w2, [x3, x2]
    bc64:	7100085f 	cmp	w2, #0x2
    bc68:	54006ae0 	b.eq	c9c4 <f0+0x2460>  // b.none
    bc6c:	7100045f 	cmp	w2, #0x1
    bc70:	540001a1 	b.ne	bca4 <f0+0x1740>  // b.any
    bc74:	29430002 	ldp	w2, w0, [x0, #24]
    bc78:	92403c21 	and	x1, x1, #0xffff
    bc7c:	9b027c21 	mul	x1, x1, x2
    bc80:	d360fc21 	lsr	x1, x1, #32
    bc84:	eb00003f 	cmp	x1, x0
    bc88:	540000e2 	b.cs	bca4 <f0+0x1740>  // b.hs, b.nlast
    bc8c:	8b0102f7 	add	x23, x23, x1
    bc90:	394002e0 	ldrb	w0, [x23]
    bc94:	7103fc1f 	cmp	w0, #0xff
    bc98:	54007440 	b.eq	cb20 <f0+0x25bc>  // b.none
    bc9c:	52800020 	mov	w0, #0x1                   	// #1
    bca0:	390002e0 	strb	w0, [x23]
    bca4:	9116e3e1 	add	x1, sp, #0x5b8
    bca8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bcac:	52800020 	mov	w0, #0x1                   	// #1
    bcb0:	f902dff7 	str	x23, [sp, #1464]
    bcb4:	f902e3f5 	str	x21, [sp, #1472]
    bcb8:	97ffe6d6 	bl	5810 <fwp_data.part.0.constprop.0>
    bcbc:	97ffe759 	bl	5a20 <fwp_rc_fresh>
    bcc0:	aa0003e2 	mov	x2, x0
    bcc4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bcc8:	911723e1 	add	x1, sp, #0x5c8
    bccc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bcd0:	52800020 	mov	w0, #0x1                   	// #1
    bcd4:	f902e7e3 	str	x3, [sp, #1480]
    bcd8:	f902ebe2 	str	x2, [sp, #1488]
    bcdc:	97ffe6cd 	bl	5810 <fwp_data.part.0.constprop.0>
    bce0:	97ffe750 	bl	5a20 <fwp_rc_fresh>
    bce4:	aa0003e2 	mov	x2, x0
    bce8:	911763e1 	add	x1, sp, #0x5d8
    bcec:	52800020 	mov	w0, #0x1                   	// #1
    bcf0:	f902eff7 	str	x23, [sp, #1496]
    bcf4:	f902f3e2 	str	x2, [sp, #1504]
    bcf8:	97ffe6c6 	bl	5810 <fwp_data.part.0.constprop.0>
    bcfc:	91190283 	add	x3, x20, #0x640
    bd00:	aa0003f5 	mov	x21, x0
    bd04:	f949d861 	ldr	x1, [x3, #5040]
    bd08:	f949ec60 	ldr	x0, [x3, #5080]
    bd0c:	cb0102a1 	sub	x1, x21, x1
    bd10:	eb00403f 	cmp	x1, x0, lsl #16
    bd14:	54000322 	b.cs	bd78 <f0+0x1814>  // b.hs, b.nlast
    bd18:	d350fc22 	lsr	x2, x1, #16
    bd1c:	f949fc63 	ldr	x3, [x3, #5112]
    bd20:	8b020842 	add	x2, x2, x2, lsl #2
    bd24:	d37df042 	lsl	x2, x2, #3
    bd28:	8b020060 	add	x0, x3, x2
    bd2c:	f9401017 	ldr	x23, [x0, #32]
    bd30:	b4000257 	cbz	x23, bd78 <f0+0x1814>
    bd34:	38626862 	ldrb	w2, [x3, x2]
    bd38:	7100085f 	cmp	w2, #0x2
    bd3c:	540063e0 	b.eq	c9b8 <f0+0x2454>  // b.none
    bd40:	7100045f 	cmp	w2, #0x1
    bd44:	540001a1 	b.ne	bd78 <f0+0x1814>  // b.any
    bd48:	29430002 	ldp	w2, w0, [x0, #24]
    bd4c:	92403c21 	and	x1, x1, #0xffff
    bd50:	9b027c21 	mul	x1, x1, x2
    bd54:	d360fc21 	lsr	x1, x1, #32
    bd58:	eb00003f 	cmp	x1, x0
    bd5c:	540000e2 	b.cs	bd78 <f0+0x1814>  // b.hs, b.nlast
    bd60:	8b0102f7 	add	x23, x23, x1
    bd64:	394002e0 	ldrb	w0, [x23]
    bd68:	7103fc1f 	cmp	w0, #0xff
    bd6c:	54006e00 	b.eq	cb2c <f0+0x25c8>  // b.none
    bd70:	52800020 	mov	w0, #0x1                   	// #1
    bd74:	390002e0 	strb	w0, [x23]
    bd78:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bd7c:	9117a3e1 	add	x1, sp, #0x5e8
    bd80:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bd84:	52800020 	mov	w0, #0x1                   	// #1
    bd88:	f902f7e2 	str	x2, [sp, #1512]
    bd8c:	f902fbf5 	str	x21, [sp, #1520]
    bd90:	97ffe6a0 	bl	5810 <fwp_data.part.0.constprop.0>
    bd94:	91190283 	add	x3, x20, #0x640
    bd98:	aa0003f5 	mov	x21, x0
    bd9c:	f949d861 	ldr	x1, [x3, #5040]
    bda0:	f949ec60 	ldr	x0, [x3, #5080]
    bda4:	cb0102a1 	sub	x1, x21, x1
    bda8:	eb00403f 	cmp	x1, x0, lsl #16
    bdac:	54000322 	b.cs	be10 <f0+0x18ac>  // b.hs, b.nlast
    bdb0:	d350fc22 	lsr	x2, x1, #16
    bdb4:	f949fc63 	ldr	x3, [x3, #5112]
    bdb8:	8b020842 	add	x2, x2, x2, lsl #2
    bdbc:	d37df042 	lsl	x2, x2, #3
    bdc0:	8b020060 	add	x0, x3, x2
    bdc4:	f9401017 	ldr	x23, [x0, #32]
    bdc8:	b4000257 	cbz	x23, be10 <f0+0x18ac>
    bdcc:	38626862 	ldrb	w2, [x3, x2]
    bdd0:	7100085f 	cmp	w2, #0x2
    bdd4:	54005ec0 	b.eq	c9ac <f0+0x2448>  // b.none
    bdd8:	7100045f 	cmp	w2, #0x1
    bddc:	540001a1 	b.ne	be10 <f0+0x18ac>  // b.any
    bde0:	29430002 	ldp	w2, w0, [x0, #24]
    bde4:	92403c21 	and	x1, x1, #0xffff
    bde8:	9b027c21 	mul	x1, x1, x2
    bdec:	d360fc21 	lsr	x1, x1, #32
    bdf0:	eb00003f 	cmp	x1, x0
    bdf4:	540000e2 	b.cs	be10 <f0+0x18ac>  // b.hs, b.nlast
    bdf8:	8b0102f7 	add	x23, x23, x1
    bdfc:	394002e0 	ldrb	w0, [x23]
    be00:	7103fc1f 	cmp	w0, #0xff
    be04:	540069a0 	b.eq	cb38 <f0+0x25d4>  // b.none
    be08:	52800020 	mov	w0, #0x1                   	// #1
    be0c:	390002e0 	strb	w0, [x23]
    be10:	9117e3e1 	add	x1, sp, #0x5f8
    be14:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    be18:	52800020 	mov	w0, #0x1                   	// #1
    be1c:	f902ffe2 	str	x2, [sp, #1528]
    be20:	f90303f5 	str	x21, [sp, #1536]
    be24:	97ffe67b 	bl	5810 <fwp_data.part.0.constprop.0>
    be28:	97ffe6fe 	bl	5a20 <fwp_rc_fresh>
    be2c:	aa0003e2 	mov	x2, x0
    be30:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    be34:	911823e1 	add	x1, sp, #0x608
    be38:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    be3c:	52800020 	mov	w0, #0x1                   	// #1
    be40:	f90307e3 	str	x3, [sp, #1544]
    be44:	f9030be2 	str	x2, [sp, #1552]
    be48:	97ffe672 	bl	5810 <fwp_data.part.0.constprop.0>
    be4c:	91190283 	add	x3, x20, #0x640
    be50:	aa0003f5 	mov	x21, x0
    be54:	f949d861 	ldr	x1, [x3, #5040]
    be58:	f949ec60 	ldr	x0, [x3, #5080]
    be5c:	cb0102a1 	sub	x1, x21, x1
    be60:	eb00403f 	cmp	x1, x0, lsl #16
    be64:	54000322 	b.cs	bec8 <f0+0x1964>  // b.hs, b.nlast
    be68:	d350fc22 	lsr	x2, x1, #16
    be6c:	f949fc63 	ldr	x3, [x3, #5112]
    be70:	8b020842 	add	x2, x2, x2, lsl #2
    be74:	d37df042 	lsl	x2, x2, #3
    be78:	8b020060 	add	x0, x3, x2
    be7c:	f9401017 	ldr	x23, [x0, #32]
    be80:	b4000257 	cbz	x23, bec8 <f0+0x1964>
    be84:	38626862 	ldrb	w2, [x3, x2]
    be88:	7100085f 	cmp	w2, #0x2
    be8c:	540058a0 	b.eq	c9a0 <f0+0x243c>  // b.none
    be90:	7100045f 	cmp	w2, #0x1
    be94:	540001a1 	b.ne	bec8 <f0+0x1964>  // b.any
    be98:	29430002 	ldp	w2, w0, [x0, #24]
    be9c:	92403c21 	and	x1, x1, #0xffff
    bea0:	9b027c21 	mul	x1, x1, x2
    bea4:	d360fc21 	lsr	x1, x1, #32
    bea8:	eb00003f 	cmp	x1, x0
    beac:	540000e2 	b.cs	bec8 <f0+0x1964>  // b.hs, b.nlast
    beb0:	8b0102f7 	add	x23, x23, x1
    beb4:	394002e0 	ldrb	w0, [x23]
    beb8:	7103fc1f 	cmp	w0, #0xff
    bebc:	54006440 	b.eq	cb44 <f0+0x25e0>  // b.none
    bec0:	52800020 	mov	w0, #0x1                   	// #1
    bec4:	390002e0 	strb	w0, [x23]
    bec8:	911863e1 	add	x1, sp, #0x618
    becc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bed0:	52800020 	mov	w0, #0x1                   	// #1
    bed4:	f9030ff7 	str	x23, [sp, #1560]
    bed8:	f90313f5 	str	x21, [sp, #1568]
    bedc:	97ffe64d 	bl	5810 <fwp_data.part.0.constprop.0>
    bee0:	97ffe6d0 	bl	5a20 <fwp_rc_fresh>
    bee4:	aa0003e2 	mov	x2, x0
    bee8:	9118a3e1 	add	x1, sp, #0x628
    beec:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bef0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bef4:	52800020 	mov	w0, #0x1                   	// #1
    bef8:	f90317f5 	str	x21, [sp, #1576]
    befc:	f9031be2 	str	x2, [sp, #1584]
    bf00:	97ffe644 	bl	5810 <fwp_data.part.0.constprop.0>
    bf04:	97ffe6c7 	bl	5a20 <fwp_rc_fresh>
    bf08:	aa0003e2 	mov	x2, x0
    bf0c:	9118e3e1 	add	x1, sp, #0x638
    bf10:	52800020 	mov	w0, #0x1                   	// #1
    bf14:	f9031ff7 	str	x23, [sp, #1592]
    bf18:	f90323e2 	str	x2, [sp, #1600]
    bf1c:	97ffe63d 	bl	5810 <fwp_data.part.0.constprop.0>
    bf20:	97ffe6c0 	bl	5a20 <fwp_rc_fresh>
    bf24:	aa0003e2 	mov	x2, x0
    bf28:	911923e1 	add	x1, sp, #0x648
    bf2c:	52800020 	mov	w0, #0x1                   	// #1
    bf30:	f90327f5 	str	x21, [sp, #1608]
    bf34:	f9032be2 	str	x2, [sp, #1616]
    bf38:	97ffe636 	bl	5810 <fwp_data.part.0.constprop.0>
    bf3c:	97ffe6b9 	bl	5a20 <fwp_rc_fresh>
    bf40:	aa0003e2 	mov	x2, x0
    bf44:	911963e1 	add	x1, sp, #0x658
    bf48:	52800020 	mov	w0, #0x1                   	// #1
    bf4c:	f9032ff7 	str	x23, [sp, #1624]
    bf50:	f90333e2 	str	x2, [sp, #1632]
    bf54:	97ffe62f 	bl	5810 <fwp_data.part.0.constprop.0>
    bf58:	91190283 	add	x3, x20, #0x640
    bf5c:	aa0003f5 	mov	x21, x0
    bf60:	f949d861 	ldr	x1, [x3, #5040]
    bf64:	f949ec60 	ldr	x0, [x3, #5080]
    bf68:	cb0102a1 	sub	x1, x21, x1
    bf6c:	eb00403f 	cmp	x1, x0, lsl #16
    bf70:	54000322 	b.cs	bfd4 <f0+0x1a70>  // b.hs, b.nlast
    bf74:	d350fc22 	lsr	x2, x1, #16
    bf78:	f949fc63 	ldr	x3, [x3, #5112]
    bf7c:	8b020842 	add	x2, x2, x2, lsl #2
    bf80:	d37df042 	lsl	x2, x2, #3
    bf84:	8b020060 	add	x0, x3, x2
    bf88:	f9401017 	ldr	x23, [x0, #32]
    bf8c:	b4000257 	cbz	x23, bfd4 <f0+0x1a70>
    bf90:	38626862 	ldrb	w2, [x3, x2]
    bf94:	7100085f 	cmp	w2, #0x2
    bf98:	54004fe0 	b.eq	c994 <f0+0x2430>  // b.none
    bf9c:	7100045f 	cmp	w2, #0x1
    bfa0:	540001a1 	b.ne	bfd4 <f0+0x1a70>  // b.any
    bfa4:	29430002 	ldp	w2, w0, [x0, #24]
    bfa8:	92403c21 	and	x1, x1, #0xffff
    bfac:	9b027c21 	mul	x1, x1, x2
    bfb0:	d360fc21 	lsr	x1, x1, #32
    bfb4:	eb00003f 	cmp	x1, x0
    bfb8:	540000e2 	b.cs	bfd4 <f0+0x1a70>  // b.hs, b.nlast
    bfbc:	8b0102f7 	add	x23, x23, x1
    bfc0:	394002e0 	ldrb	w0, [x23]
    bfc4:	7103fc1f 	cmp	w0, #0xff
    bfc8:	54005c40 	b.eq	cb50 <f0+0x25ec>  // b.none
    bfcc:	52800020 	mov	w0, #0x1                   	// #1
    bfd0:	390002e0 	strb	w0, [x23]
    bfd4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bfd8:	9119a3e1 	add	x1, sp, #0x668
    bfdc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bfe0:	52800020 	mov	w0, #0x1                   	// #1
    bfe4:	f90337e2 	str	x2, [sp, #1640]
    bfe8:	f9033bf5 	str	x21, [sp, #1648]
    bfec:	97ffe609 	bl	5810 <fwp_data.part.0.constprop.0>
    bff0:	91190283 	add	x3, x20, #0x640
    bff4:	aa0003f5 	mov	x21, x0
    bff8:	f949d861 	ldr	x1, [x3, #5040]
    bffc:	f949ec60 	ldr	x0, [x3, #5080]
    c000:	cb0102a1 	sub	x1, x21, x1
    c004:	eb00403f 	cmp	x1, x0, lsl #16
    c008:	54000322 	b.cs	c06c <f0+0x1b08>  // b.hs, b.nlast
    c00c:	d350fc22 	lsr	x2, x1, #16
    c010:	f949fc63 	ldr	x3, [x3, #5112]
    c014:	8b020842 	add	x2, x2, x2, lsl #2
    c018:	d37df042 	lsl	x2, x2, #3
    c01c:	8b020060 	add	x0, x3, x2
    c020:	f9401017 	ldr	x23, [x0, #32]
    c024:	b4000257 	cbz	x23, c06c <f0+0x1b08>
    c028:	38626862 	ldrb	w2, [x3, x2]
    c02c:	7100085f 	cmp	w2, #0x2
    c030:	54004ac0 	b.eq	c988 <f0+0x2424>  // b.none
    c034:	7100045f 	cmp	w2, #0x1
    c038:	540001a1 	b.ne	c06c <f0+0x1b08>  // b.any
    c03c:	29430002 	ldp	w2, w0, [x0, #24]
    c040:	92403c21 	and	x1, x1, #0xffff
    c044:	9b027c21 	mul	x1, x1, x2
    c048:	d360fc21 	lsr	x1, x1, #32
    c04c:	eb00003f 	cmp	x1, x0
    c050:	540000e2 	b.cs	c06c <f0+0x1b08>  // b.hs, b.nlast
    c054:	8b0102f7 	add	x23, x23, x1
    c058:	394002e0 	ldrb	w0, [x23]
    c05c:	7103fc1f 	cmp	w0, #0xff
    c060:	540057e0 	b.eq	cb5c <f0+0x25f8>  // b.none
    c064:	52800020 	mov	w0, #0x1                   	// #1
    c068:	390002e0 	strb	w0, [x23]
    c06c:	9119e3e1 	add	x1, sp, #0x678
    c070:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c074:	52800020 	mov	w0, #0x1                   	// #1
    c078:	f9033ff7 	str	x23, [sp, #1656]
    c07c:	f90343f5 	str	x21, [sp, #1664]
    c080:	97ffe5e4 	bl	5810 <fwp_data.part.0.constprop.0>
    c084:	97ffe667 	bl	5a20 <fwp_rc_fresh>
    c088:	aa0003e2 	mov	x2, x0
    c08c:	911a23e1 	add	x1, sp, #0x688
    c090:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c094:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c098:	52800020 	mov	w0, #0x1                   	// #1
    c09c:	f90347f5 	str	x21, [sp, #1672]
    c0a0:	f9034be2 	str	x2, [sp, #1680]
    c0a4:	97ffe5db 	bl	5810 <fwp_data.part.0.constprop.0>
    c0a8:	97ffe65e 	bl	5a20 <fwp_rc_fresh>
    c0ac:	aa0003e2 	mov	x2, x0
    c0b0:	911a63e1 	add	x1, sp, #0x698
    c0b4:	52800020 	mov	w0, #0x1                   	// #1
    c0b8:	f9034ff7 	str	x23, [sp, #1688]
    c0bc:	f90353e2 	str	x2, [sp, #1696]
    c0c0:	97ffe5d4 	bl	5810 <fwp_data.part.0.constprop.0>
    c0c4:	97ffe657 	bl	5a20 <fwp_rc_fresh>
    c0c8:	aa0003e2 	mov	x2, x0
    c0cc:	911aa3e1 	add	x1, sp, #0x6a8
    c0d0:	52800020 	mov	w0, #0x1                   	// #1
    c0d4:	f90357f5 	str	x21, [sp, #1704]
    c0d8:	f9035be2 	str	x2, [sp, #1712]
    c0dc:	97ffe5cd 	bl	5810 <fwp_data.part.0.constprop.0>
    c0e0:	91190283 	add	x3, x20, #0x640
    c0e4:	aa0003f5 	mov	x21, x0
    c0e8:	f949d861 	ldr	x1, [x3, #5040]
    c0ec:	f949ec60 	ldr	x0, [x3, #5080]
    c0f0:	cb0102a1 	sub	x1, x21, x1
    c0f4:	eb00403f 	cmp	x1, x0, lsl #16
    c0f8:	54000322 	b.cs	c15c <f0+0x1bf8>  // b.hs, b.nlast
    c0fc:	d350fc22 	lsr	x2, x1, #16
    c100:	f949fc63 	ldr	x3, [x3, #5112]
    c104:	8b020842 	add	x2, x2, x2, lsl #2
    c108:	d37df042 	lsl	x2, x2, #3
    c10c:	8b020060 	add	x0, x3, x2
    c110:	f9401017 	ldr	x23, [x0, #32]
    c114:	b4000257 	cbz	x23, c15c <f0+0x1bf8>
    c118:	38626862 	ldrb	w2, [x3, x2]
    c11c:	7100085f 	cmp	w2, #0x2
    c120:	540042e0 	b.eq	c97c <f0+0x2418>  // b.none
    c124:	7100045f 	cmp	w2, #0x1
    c128:	540001a1 	b.ne	c15c <f0+0x1bf8>  // b.any
    c12c:	29430002 	ldp	w2, w0, [x0, #24]
    c130:	92403c21 	and	x1, x1, #0xffff
    c134:	9b027c21 	mul	x1, x1, x2
    c138:	d360fc21 	lsr	x1, x1, #32
    c13c:	eb00003f 	cmp	x1, x0
    c140:	540000e2 	b.cs	c15c <f0+0x1bf8>  // b.hs, b.nlast
    c144:	8b0102f7 	add	x23, x23, x1
    c148:	394002e0 	ldrb	w0, [x23]
    c14c:	7103fc1f 	cmp	w0, #0xff
    c150:	540050c0 	b.eq	cb68 <f0+0x2604>  // b.none
    c154:	52800020 	mov	w0, #0x1                   	// #1
    c158:	390002e0 	strb	w0, [x23]
    c15c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c160:	911ae3e1 	add	x1, sp, #0x6b8
    c164:	52800020 	mov	w0, #0x1                   	// #1
    c168:	f9035fe2 	str	x2, [sp, #1720]
    c16c:	f90363f5 	str	x21, [sp, #1728]
    c170:	97ffe5a8 	bl	5810 <fwp_data.part.0.constprop.0>
    c174:	91190283 	add	x3, x20, #0x640
    c178:	aa0003f5 	mov	x21, x0
    c17c:	f949d861 	ldr	x1, [x3, #5040]
    c180:	f949ec60 	ldr	x0, [x3, #5080]
    c184:	cb0102a1 	sub	x1, x21, x1
    c188:	eb00403f 	cmp	x1, x0, lsl #16
    c18c:	54000322 	b.cs	c1f0 <f0+0x1c8c>  // b.hs, b.nlast
    c190:	d350fc22 	lsr	x2, x1, #16
    c194:	f949fc63 	ldr	x3, [x3, #5112]
    c198:	8b020842 	add	x2, x2, x2, lsl #2
    c19c:	d37df042 	lsl	x2, x2, #3
    c1a0:	8b020060 	add	x0, x3, x2
    c1a4:	f9401017 	ldr	x23, [x0, #32]
    c1a8:	b4000257 	cbz	x23, c1f0 <f0+0x1c8c>
    c1ac:	38626862 	ldrb	w2, [x3, x2]
    c1b0:	7100085f 	cmp	w2, #0x2
    c1b4:	54003de0 	b.eq	c970 <f0+0x240c>  // b.none
    c1b8:	7100045f 	cmp	w2, #0x1
    c1bc:	540001a1 	b.ne	c1f0 <f0+0x1c8c>  // b.any
    c1c0:	29430002 	ldp	w2, w0, [x0, #24]
    c1c4:	92403c21 	and	x1, x1, #0xffff
    c1c8:	9b027c21 	mul	x1, x1, x2
    c1cc:	d360fc21 	lsr	x1, x1, #32
    c1d0:	eb00003f 	cmp	x1, x0
    c1d4:	540000e2 	b.cs	c1f0 <f0+0x1c8c>  // b.hs, b.nlast
    c1d8:	8b0102f7 	add	x23, x23, x1
    c1dc:	394002e0 	ldrb	w0, [x23]
    c1e0:	7103fc1f 	cmp	w0, #0xff
    c1e4:	54004c80 	b.eq	cb74 <f0+0x2610>  // b.none
    c1e8:	52800020 	mov	w0, #0x1                   	// #1
    c1ec:	390002e0 	strb	w0, [x23]
    c1f0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c1f4:	911b23e1 	add	x1, sp, #0x6c8
    c1f8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c1fc:	52800020 	mov	w0, #0x1                   	// #1
    c200:	f90367e2 	str	x2, [sp, #1736]
    c204:	f9036bf5 	str	x21, [sp, #1744]
    c208:	97ffe582 	bl	5810 <fwp_data.part.0.constprop.0>
    c20c:	91190283 	add	x3, x20, #0x640
    c210:	aa0003f5 	mov	x21, x0
    c214:	f949d861 	ldr	x1, [x3, #5040]
    c218:	f949ec60 	ldr	x0, [x3, #5080]
    c21c:	cb0102a1 	sub	x1, x21, x1
    c220:	eb00403f 	cmp	x1, x0, lsl #16
    c224:	54000322 	b.cs	c288 <f0+0x1d24>  // b.hs, b.nlast
    c228:	d350fc22 	lsr	x2, x1, #16
    c22c:	f949fc63 	ldr	x3, [x3, #5112]
    c230:	8b020842 	add	x2, x2, x2, lsl #2
    c234:	d37df042 	lsl	x2, x2, #3
    c238:	8b020060 	add	x0, x3, x2
    c23c:	f9401017 	ldr	x23, [x0, #32]
    c240:	b4000257 	cbz	x23, c288 <f0+0x1d24>
    c244:	38626862 	ldrb	w2, [x3, x2]
    c248:	7100085f 	cmp	w2, #0x2
    c24c:	540038c0 	b.eq	c964 <f0+0x2400>  // b.none
    c250:	7100045f 	cmp	w2, #0x1
    c254:	540001a1 	b.ne	c288 <f0+0x1d24>  // b.any
    c258:	29430002 	ldp	w2, w0, [x0, #24]
    c25c:	92403c21 	and	x1, x1, #0xffff
    c260:	9b027c21 	mul	x1, x1, x2
    c264:	d360fc21 	lsr	x1, x1, #32
    c268:	eb00003f 	cmp	x1, x0
    c26c:	540000e2 	b.cs	c288 <f0+0x1d24>  // b.hs, b.nlast
    c270:	8b0102f7 	add	x23, x23, x1
    c274:	394002e0 	ldrb	w0, [x23]
    c278:	7103fc1f 	cmp	w0, #0xff
    c27c:	54004820 	b.eq	cb80 <f0+0x261c>  // b.none
    c280:	52800020 	mov	w0, #0x1                   	// #1
    c284:	390002e0 	strb	w0, [x23]
    c288:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c28c:	911b63e1 	add	x1, sp, #0x6d8
    c290:	52800020 	mov	w0, #0x1                   	// #1
    c294:	f9036fe2 	str	x2, [sp, #1752]
    c298:	f90373f5 	str	x21, [sp, #1760]
    c29c:	97ffe55d 	bl	5810 <fwp_data.part.0.constprop.0>
    c2a0:	91190283 	add	x3, x20, #0x640
    c2a4:	aa0003f5 	mov	x21, x0
    c2a8:	f949d861 	ldr	x1, [x3, #5040]
    c2ac:	f949ec60 	ldr	x0, [x3, #5080]
    c2b0:	cb0102a1 	sub	x1, x21, x1
    c2b4:	eb00403f 	cmp	x1, x0, lsl #16
    c2b8:	54000322 	b.cs	c31c <f0+0x1db8>  // b.hs, b.nlast
    c2bc:	d350fc22 	lsr	x2, x1, #16
    c2c0:	f949fc63 	ldr	x3, [x3, #5112]
    c2c4:	8b020842 	add	x2, x2, x2, lsl #2
    c2c8:	d37df042 	lsl	x2, x2, #3
    c2cc:	8b020060 	add	x0, x3, x2
    c2d0:	f9401017 	ldr	x23, [x0, #32]
    c2d4:	b4000257 	cbz	x23, c31c <f0+0x1db8>
    c2d8:	38626862 	ldrb	w2, [x3, x2]
    c2dc:	7100085f 	cmp	w2, #0x2
    c2e0:	540033c0 	b.eq	c958 <f0+0x23f4>  // b.none
    c2e4:	7100045f 	cmp	w2, #0x1
    c2e8:	540001a1 	b.ne	c31c <f0+0x1db8>  // b.any
    c2ec:	29430002 	ldp	w2, w0, [x0, #24]
    c2f0:	92403c21 	and	x1, x1, #0xffff
    c2f4:	9b027c21 	mul	x1, x1, x2
    c2f8:	d360fc21 	lsr	x1, x1, #32
    c2fc:	eb00003f 	cmp	x1, x0
    c300:	540000e2 	b.cs	c31c <f0+0x1db8>  // b.hs, b.nlast
    c304:	8b0102f7 	add	x23, x23, x1
    c308:	394002e0 	ldrb	w0, [x23]
    c30c:	7103fc1f 	cmp	w0, #0xff
    c310:	540043e0 	b.eq	cb8c <f0+0x2628>  // b.none
    c314:	52800020 	mov	w0, #0x1                   	// #1
    c318:	390002e0 	strb	w0, [x23]
    c31c:	911ba3e1 	add	x1, sp, #0x6e8
    c320:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c324:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c328:	52800020 	mov	w0, #0x1                   	// #1
    c32c:	f90377f7 	str	x23, [sp, #1768]
    c330:	f9037bf5 	str	x21, [sp, #1776]
    c334:	97ffe537 	bl	5810 <fwp_data.part.0.constprop.0>
    c338:	97ffe5ba 	bl	5a20 <fwp_rc_fresh>
    c33c:	aa0003e2 	mov	x2, x0
    c340:	911be3e1 	add	x1, sp, #0x6f8
    c344:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c348:	52800020 	mov	w0, #0x1                   	// #1
    c34c:	f9037ff5 	str	x21, [sp, #1784]
    c350:	f90383e2 	str	x2, [sp, #1792]
    c354:	97ffe52f 	bl	5810 <fwp_data.part.0.constprop.0>
    c358:	97ffe5b2 	bl	5a20 <fwp_rc_fresh>
    c35c:	aa0003e2 	mov	x2, x0
    c360:	911c23e1 	add	x1, sp, #0x708
    c364:	52800020 	mov	w0, #0x1                   	// #1
    c368:	f90387f7 	str	x23, [sp, #1800]
    c36c:	f9038be2 	str	x2, [sp, #1808]
    c370:	97ffe528 	bl	5810 <fwp_data.part.0.constprop.0>
    c374:	97ffe5ab 	bl	5a20 <fwp_rc_fresh>
    c378:	aa0003e2 	mov	x2, x0
    c37c:	911c63e1 	add	x1, sp, #0x718
    c380:	52800020 	mov	w0, #0x1                   	// #1
    c384:	f9038ff5 	str	x21, [sp, #1816]
    c388:	f90393e2 	str	x2, [sp, #1824]
    c38c:	97ffe521 	bl	5810 <fwp_data.part.0.constprop.0>
    c390:	97ffe5a4 	bl	5a20 <fwp_rc_fresh>
    c394:	aa0003e2 	mov	x2, x0
    c398:	911ca3e1 	add	x1, sp, #0x728
    c39c:	52800020 	mov	w0, #0x1                   	// #1
    c3a0:	f90397f7 	str	x23, [sp, #1832]
    c3a4:	f9039be2 	str	x2, [sp, #1840]
    c3a8:	97ffe51a 	bl	5810 <fwp_data.part.0.constprop.0>
    c3ac:	97ffe59d 	bl	5a20 <fwp_rc_fresh>
    c3b0:	aa0003e2 	mov	x2, x0
    c3b4:	911ce3e1 	add	x1, sp, #0x738
    c3b8:	52800020 	mov	w0, #0x1                   	// #1
    c3bc:	f9039ff5 	str	x21, [sp, #1848]
    c3c0:	f903a3e2 	str	x2, [sp, #1856]
    c3c4:	97ffe513 	bl	5810 <fwp_data.part.0.constprop.0>
    c3c8:	91190283 	add	x3, x20, #0x640
    c3cc:	aa0003f5 	mov	x21, x0
    c3d0:	f949d861 	ldr	x1, [x3, #5040]
    c3d4:	f949ec60 	ldr	x0, [x3, #5080]
    c3d8:	cb0102a1 	sub	x1, x21, x1
    c3dc:	eb00403f 	cmp	x1, x0, lsl #16
    c3e0:	54000322 	b.cs	c444 <f0+0x1ee0>  // b.hs, b.nlast
    c3e4:	d350fc22 	lsr	x2, x1, #16
    c3e8:	f949fc63 	ldr	x3, [x3, #5112]
    c3ec:	8b020842 	add	x2, x2, x2, lsl #2
    c3f0:	d37df042 	lsl	x2, x2, #3
    c3f4:	8b020060 	add	x0, x3, x2
    c3f8:	f9401017 	ldr	x23, [x0, #32]
    c3fc:	b4000257 	cbz	x23, c444 <f0+0x1ee0>
    c400:	38626862 	ldrb	w2, [x3, x2]
    c404:	7100085f 	cmp	w2, #0x2
    c408:	54002a20 	b.eq	c94c <f0+0x23e8>  // b.none
    c40c:	7100045f 	cmp	w2, #0x1
    c410:	540001a1 	b.ne	c444 <f0+0x1ee0>  // b.any
    c414:	29430002 	ldp	w2, w0, [x0, #24]
    c418:	92403c21 	and	x1, x1, #0xffff
    c41c:	9b027c21 	mul	x1, x1, x2
    c420:	d360fc21 	lsr	x1, x1, #32
    c424:	eb00003f 	cmp	x1, x0
    c428:	540000e2 	b.cs	c444 <f0+0x1ee0>  // b.hs, b.nlast
    c42c:	8b0102f7 	add	x23, x23, x1
    c430:	394002e0 	ldrb	w0, [x23]
    c434:	7103fc1f 	cmp	w0, #0xff
    c438:	54003b00 	b.eq	cb98 <f0+0x2634>  // b.none
    c43c:	52800020 	mov	w0, #0x1                   	// #1
    c440:	390002e0 	strb	w0, [x23]
    c444:	911d23e1 	add	x1, sp, #0x748
    c448:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c44c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c450:	52800020 	mov	w0, #0x1                   	// #1
    c454:	f903a7f7 	str	x23, [sp, #1864]
    c458:	f903abf5 	str	x21, [sp, #1872]
    c45c:	97ffe4ed 	bl	5810 <fwp_data.part.0.constprop.0>
    c460:	97ffe570 	bl	5a20 <fwp_rc_fresh>
    c464:	aa0003e2 	mov	x2, x0
    c468:	911d63e1 	add	x1, sp, #0x758
    c46c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c470:	52800020 	mov	w0, #0x1                   	// #1
    c474:	f903aff5 	str	x21, [sp, #1880]
    c478:	f903b3e2 	str	x2, [sp, #1888]
    c47c:	97ffe4e5 	bl	5810 <fwp_data.part.0.constprop.0>
    c480:	97ffe568 	bl	5a20 <fwp_rc_fresh>
    c484:	aa0003e2 	mov	x2, x0
    c488:	911da3e1 	add	x1, sp, #0x768
    c48c:	52800020 	mov	w0, #0x1                   	// #1
    c490:	f903b7f7 	str	x23, [sp, #1896]
    c494:	f903bbe2 	str	x2, [sp, #1904]
    c498:	97ffe4de 	bl	5810 <fwp_data.part.0.constprop.0>
    c49c:	97ffe561 	bl	5a20 <fwp_rc_fresh>
    c4a0:	aa0003e2 	mov	x2, x0
    c4a4:	911de3e1 	add	x1, sp, #0x778
    c4a8:	52800020 	mov	w0, #0x1                   	// #1
    c4ac:	f903bff5 	str	x21, [sp, #1912]
    c4b0:	f903c3e2 	str	x2, [sp, #1920]
    c4b4:	97ffe4d7 	bl	5810 <fwp_data.part.0.constprop.0>
    c4b8:	97ffe55a 	bl	5a20 <fwp_rc_fresh>
    c4bc:	aa0003e2 	mov	x2, x0
    c4c0:	911e23e1 	add	x1, sp, #0x788
    c4c4:	52800020 	mov	w0, #0x1                   	// #1
    c4c8:	f903c7f7 	str	x23, [sp, #1928]
    c4cc:	f903cbe2 	str	x2, [sp, #1936]
    c4d0:	97ffe4d0 	bl	5810 <fwp_data.part.0.constprop.0>
    c4d4:	97ffe553 	bl	5a20 <fwp_rc_fresh>
    c4d8:	aa0003e2 	mov	x2, x0
    c4dc:	911e63e1 	add	x1, sp, #0x798
    c4e0:	52800020 	mov	w0, #0x1                   	// #1
    c4e4:	f903cff5 	str	x21, [sp, #1944]
    c4e8:	f903d3e2 	str	x2, [sp, #1952]
    c4ec:	97ffe4c9 	bl	5810 <fwp_data.part.0.constprop.0>
    c4f0:	97ffe54c 	bl	5a20 <fwp_rc_fresh>
    c4f4:	aa0003e2 	mov	x2, x0
    c4f8:	911ea3e1 	add	x1, sp, #0x7a8
    c4fc:	52800020 	mov	w0, #0x1                   	// #1
    c500:	f903d7f7 	str	x23, [sp, #1960]
    c504:	f903dbe2 	str	x2, [sp, #1968]
    c508:	97ffe4c2 	bl	5810 <fwp_data.part.0.constprop.0>
    c50c:	97ffe545 	bl	5a20 <fwp_rc_fresh>
    c510:	aa0003e2 	mov	x2, x0
    c514:	911ee3e1 	add	x1, sp, #0x7b8
    c518:	52800020 	mov	w0, #0x1                   	// #1
    c51c:	f903dff5 	str	x21, [sp, #1976]
    c520:	f903e3e2 	str	x2, [sp, #1984]
    c524:	97ffe4bb 	bl	5810 <fwp_data.part.0.constprop.0>
    c528:	97ffe53e 	bl	5a20 <fwp_rc_fresh>
    c52c:	aa0003e2 	mov	x2, x0
    c530:	911f23e1 	add	x1, sp, #0x7c8
    c534:	52800020 	mov	w0, #0x1                   	// #1
    c538:	f903e7f7 	str	x23, [sp, #1992]
    c53c:	f903ebe2 	str	x2, [sp, #2000]
    c540:	97ffe4b4 	bl	5810 <fwp_data.part.0.constprop.0>
    c544:	97ffe537 	bl	5a20 <fwp_rc_fresh>
    c548:	aa0003e2 	mov	x2, x0
    c54c:	911f63e1 	add	x1, sp, #0x7d8
    c550:	52800020 	mov	w0, #0x1                   	// #1
    c554:	f903eff5 	str	x21, [sp, #2008]
    c558:	f903f3e2 	str	x2, [sp, #2016]
    c55c:	97ffe4ad 	bl	5810 <fwp_data.part.0.constprop.0>
    c560:	97ffe530 	bl	5a20 <fwp_rc_fresh>
    c564:	aa0003e2 	mov	x2, x0
    c568:	911fa3e1 	add	x1, sp, #0x7e8
    c56c:	52800020 	mov	w0, #0x1                   	// #1
    c570:	f903f7f7 	str	x23, [sp, #2024]
    c574:	f903fbe2 	str	x2, [sp, #2032]
    c578:	97ffe4a6 	bl	5810 <fwp_data.part.0.constprop.0>
    c57c:	97ffe529 	bl	5a20 <fwp_rc_fresh>
    c580:	aa0003e2 	mov	x2, x0
    c584:	911fe3e1 	add	x1, sp, #0x7f8
    c588:	52800020 	mov	w0, #0x1                   	// #1
    c58c:	f903fff5 	str	x21, [sp, #2040]
    c590:	f90403e2 	str	x2, [sp, #2048]
    c594:	97ffe49f 	bl	5810 <fwp_data.part.0.constprop.0>
    c598:	91190283 	add	x3, x20, #0x640
    c59c:	aa0003f5 	mov	x21, x0
    c5a0:	f949d861 	ldr	x1, [x3, #5040]
    c5a4:	f949ec60 	ldr	x0, [x3, #5080]
    c5a8:	cb0102a1 	sub	x1, x21, x1
    c5ac:	eb00403f 	cmp	x1, x0, lsl #16
    c5b0:	54000322 	b.cs	c614 <f0+0x20b0>  // b.hs, b.nlast
    c5b4:	d350fc22 	lsr	x2, x1, #16
    c5b8:	f949fc63 	ldr	x3, [x3, #5112]
    c5bc:	8b020842 	add	x2, x2, x2, lsl #2
    c5c0:	d37df042 	lsl	x2, x2, #3
    c5c4:	8b020060 	add	x0, x3, x2
    c5c8:	f9401017 	ldr	x23, [x0, #32]
    c5cc:	b4000257 	cbz	x23, c614 <f0+0x20b0>
    c5d0:	38626862 	ldrb	w2, [x3, x2]
    c5d4:	7100085f 	cmp	w2, #0x2
    c5d8:	54001b40 	b.eq	c940 <f0+0x23dc>  // b.none
    c5dc:	7100045f 	cmp	w2, #0x1
    c5e0:	540001a1 	b.ne	c614 <f0+0x20b0>  // b.any
    c5e4:	29430002 	ldp	w2, w0, [x0, #24]
    c5e8:	92403c21 	and	x1, x1, #0xffff
    c5ec:	9b027c21 	mul	x1, x1, x2
    c5f0:	d360fc21 	lsr	x1, x1, #32
    c5f4:	eb00003f 	cmp	x1, x0
    c5f8:	540000e2 	b.cs	c614 <f0+0x20b0>  // b.hs, b.nlast
    c5fc:	8b0102f7 	add	x23, x23, x1
    c600:	394002e0 	ldrb	w0, [x23]
    c604:	7103fc1f 	cmp	w0, #0xff
    c608:	54002ce0 	b.eq	cba4 <f0+0x2640>  // b.none
    c60c:	52800020 	mov	w0, #0x1                   	// #1
    c610:	390002e0 	strb	w0, [x23]
    c614:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c618:	912023e1 	add	x1, sp, #0x808
    c61c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c620:	52800020 	mov	w0, #0x1                   	// #1
    c624:	f90407e2 	str	x2, [sp, #2056]
    c628:	f9040bf5 	str	x21, [sp, #2064]
    c62c:	97ffe479 	bl	5810 <fwp_data.part.0.constprop.0>
    c630:	91190283 	add	x3, x20, #0x640
    c634:	aa0003f5 	mov	x21, x0
    c638:	f949d861 	ldr	x1, [x3, #5040]
    c63c:	f949ec60 	ldr	x0, [x3, #5080]
    c640:	cb0102a1 	sub	x1, x21, x1
    c644:	eb00403f 	cmp	x1, x0, lsl #16
    c648:	54000322 	b.cs	c6ac <f0+0x2148>  // b.hs, b.nlast
    c64c:	d350fc22 	lsr	x2, x1, #16
    c650:	f949fc63 	ldr	x3, [x3, #5112]
    c654:	8b020842 	add	x2, x2, x2, lsl #2
    c658:	d37df042 	lsl	x2, x2, #3
    c65c:	8b020060 	add	x0, x3, x2
    c660:	f9401017 	ldr	x23, [x0, #32]
    c664:	b4000257 	cbz	x23, c6ac <f0+0x2148>
    c668:	38626862 	ldrb	w2, [x3, x2]
    c66c:	7100085f 	cmp	w2, #0x2
    c670:	54001620 	b.eq	c934 <f0+0x23d0>  // b.none
    c674:	7100045f 	cmp	w2, #0x1
    c678:	540001a1 	b.ne	c6ac <f0+0x2148>  // b.any
    c67c:	29430002 	ldp	w2, w0, [x0, #24]
    c680:	92403c21 	and	x1, x1, #0xffff
    c684:	9b027c21 	mul	x1, x1, x2
    c688:	d360fc21 	lsr	x1, x1, #32
    c68c:	eb00003f 	cmp	x1, x0
    c690:	540000e2 	b.cs	c6ac <f0+0x2148>  // b.hs, b.nlast
    c694:	8b0102f7 	add	x23, x23, x1
    c698:	394002e0 	ldrb	w0, [x23]
    c69c:	7103fc1f 	cmp	w0, #0xff
    c6a0:	54002880 	b.eq	cbb0 <f0+0x264c>  // b.none
    c6a4:	52800020 	mov	w0, #0x1                   	// #1
    c6a8:	390002e0 	strb	w0, [x23]
    c6ac:	91190294 	add	x20, x20, #0x640
    c6b0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c6b4:	912063e1 	add	x1, sp, #0x818
    c6b8:	52800020 	mov	w0, #0x1                   	// #1
    c6bc:	f9040fe2 	str	x2, [sp, #2072]
    c6c0:	f90413f5 	str	x21, [sp, #2080]
    c6c4:	97ffe453 	bl	5810 <fwp_data.part.0.constprop.0>
    c6c8:	f949da81 	ldr	x1, [x20, #5040]
    c6cc:	aa0003f5 	mov	x21, x0
    c6d0:	f949ee80 	ldr	x0, [x20, #5080]
    c6d4:	cb0102a1 	sub	x1, x21, x1
    c6d8:	eb00403f 	cmp	x1, x0, lsl #16
    c6dc:	54000322 	b.cs	c740 <f0+0x21dc>  // b.hs, b.nlast
    c6e0:	d350fc22 	lsr	x2, x1, #16
    c6e4:	f949fe83 	ldr	x3, [x20, #5112]
    c6e8:	8b020842 	add	x2, x2, x2, lsl #2
    c6ec:	d37df042 	lsl	x2, x2, #3
    c6f0:	8b020060 	add	x0, x3, x2
    c6f4:	f9401014 	ldr	x20, [x0, #32]
    c6f8:	b4000254 	cbz	x20, c740 <f0+0x21dc>
    c6fc:	38626862 	ldrb	w2, [x3, x2]
    c700:	7100085f 	cmp	w2, #0x2
    c704:	54001120 	b.eq	c928 <f0+0x23c4>  // b.none
    c708:	7100045f 	cmp	w2, #0x1
    c70c:	540001a1 	b.ne	c740 <f0+0x21dc>  // b.any
    c710:	29430002 	ldp	w2, w0, [x0, #24]
    c714:	92403c21 	and	x1, x1, #0xffff
    c718:	9b027c21 	mul	x1, x1, x2
    c71c:	d360fc21 	lsr	x1, x1, #32
    c720:	eb00003f 	cmp	x1, x0
    c724:	540000e2 	b.cs	c740 <f0+0x21dc>  // b.hs, b.nlast
    c728:	8b010294 	add	x20, x20, x1
    c72c:	39400280 	ldrb	w0, [x20]
    c730:	7103fc1f 	cmp	w0, #0xff
    c734:	540015a0 	b.eq	c9e8 <f0+0x2484>  // b.none
    c738:	52800020 	mov	w0, #0x1                   	// #1
    c73c:	39000280 	strb	w0, [x20]
    c740:	9120a3e1 	add	x1, sp, #0x828
    c744:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c748:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c74c:	52800020 	mov	w0, #0x1                   	// #1
    c750:	f90417f4 	str	x20, [sp, #2088]
    c754:	f9041bf5 	str	x21, [sp, #2096]
    c758:	97ffe42e 	bl	5810 <fwp_data.part.0.constprop.0>
    c75c:	97ffe4b1 	bl	5a20 <fwp_rc_fresh>
    c760:	aa0003e2 	mov	x2, x0
    c764:	9120e3e1 	add	x1, sp, #0x838
    c768:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c76c:	52800020 	mov	w0, #0x1                   	// #1
    c770:	f9041fe3 	str	x3, [sp, #2104]
    c774:	f90423e2 	str	x2, [sp, #2112]
    c778:	97ffe426 	bl	5810 <fwp_data.part.0.constprop.0>
    c77c:	97ffe4a9 	bl	5a20 <fwp_rc_fresh>
    c780:	aa0003e2 	mov	x2, x0
    c784:	aa1603e1 	mov	x1, x22
    c788:	52800020 	mov	w0, #0x1                   	// #1
    c78c:	f90427f4 	str	x20, [sp, #2120]
    c790:	f9042be2 	str	x2, [sp, #2128]
    c794:	97ffe41f 	bl	5810 <fwp_data.part.0.constprop.0>
    c798:	97ffe4a2 	bl	5a20 <fwp_rc_fresh>
    c79c:	aa0003f5 	mov	x21, x0
    c7a0:	aa1303e1 	mov	x1, x19
    c7a4:	97fff45b 	bl	9910 <fwp_hof0.constprop.0>
    c7a8:	aa0003f4 	mov	x20, x0
    c7ac:	aa1503e0 	mov	x0, x21
    c7b0:	97ffe5fc 	bl	5fa0 <fwp_drop0>
    c7b4:	aa1303e0 	mov	x0, x19
    c7b8:	97ffe5fa 	bl	5fa0 <fwp_drop0>
    c7bc:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    c7c0:	f947f400 	ldr	x0, [x0, #4072]
    c7c4:	f9442fe2 	ldr	x2, [sp, #2136]
    c7c8:	f9400001 	ldr	x1, [x0]
    c7cc:	eb010042 	subs	x2, x2, x1
    c7d0:	d2800001 	mov	x1, #0x0                   	// #0
    c7d4:	54001f41 	b.ne	cbbc <f0+0x2658>  // b.any
    c7d8:	912183ff 	add	sp, sp, #0x860
    c7dc:	aa1403e0 	mov	x0, x20
    c7e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    c7e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c7e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    c7ec:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c7f0:	a94573fb 	ldp	x27, x28, [sp, #80]
    c7f4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c7f8:	d65f03c0 	ret
    c7fc:	aa1b03e0 	mov	x0, x27
    c800:	97ffe064 	bl	4990 <fwp_rc_forget_slot>
    c804:	17fff7a1 	b	a688 <f0+0x124>
    c808:	72003c5f 	tst	w2, #0xffff
    c80c:	54fef401 	b.ne	a68c <f0+0x128>  // b.any
    c810:	17fff79b 	b	a67c <f0+0x118>
    c814:	72003c3f 	tst	w1, #0xffff
    c818:	54ff8fa1 	b.ne	ba0c <f0+0x14a8>  // b.any
    c81c:	17fffc77 	b	b9f8 <f0+0x1494>
    c820:	72003c3f 	tst	w1, #0xffff
    c824:	54ff8981 	b.ne	b954 <f0+0x13f0>  // b.any
    c828:	17fffc46 	b	b940 <f0+0x13dc>
    c82c:	72003c3f 	tst	w1, #0xffff
    c830:	54ff81a1 	b.ne	b864 <f0+0x1300>  // b.any
    c834:	17fffc07 	b	b850 <f0+0x12ec>
    c838:	72003c3f 	tst	w1, #0xffff
    c83c:	54ff79c1 	b.ne	b774 <f0+0x1210>  // b.any
    c840:	17fffbc8 	b	b760 <f0+0x11fc>
    c844:	72003c3f 	tst	w1, #0xffff
    c848:	54ff74a1 	b.ne	b6dc <f0+0x1178>  // b.any
    c84c:	17fffb9f 	b	b6c8 <f0+0x1164>
    c850:	72003c3f 	tst	w1, #0xffff
    c854:	54ff6a21 	b.ne	b598 <f0+0x1034>  // b.any
    c858:	17fffb4b 	b	b584 <f0+0x1020>
    c85c:	72003c3f 	tst	w1, #0xffff
    c860:	54ff6401 	b.ne	b4e0 <f0+0xf7c>  // b.any
    c864:	17fffb1a 	b	b4cc <f0+0xf68>
    c868:	72003c3f 	tst	w1, #0xffff
    c86c:	54ff5de1 	b.ne	b428 <f0+0xec4>  // b.any
    c870:	17fffae9 	b	b414 <f0+0xeb0>
    c874:	72003c3f 	tst	w1, #0xffff
    c878:	54ff0921 	b.ne	a99c <f0+0x438>  // b.any
    c87c:	17fff843 	b	a988 <f0+0x424>
    c880:	72003c3f 	tst	w1, #0xffff
    c884:	54fefec1 	b.ne	a85c <f0+0x2f8>  // b.any
    c888:	17fff7f0 	b	a848 <f0+0x2e4>
    c88c:	72003c3f 	tst	w1, #0xffff
    c890:	54fef761 	b.ne	a77c <f0+0x218>  // b.any
    c894:	17fff7b5 	b	a768 <f0+0x204>
    c898:	72003c3f 	tst	w1, #0xffff
    c89c:	54ff1fe1 	b.ne	ac98 <f0+0x734>  // b.any
    c8a0:	17fff8f9 	b	ac84 <f0+0x720>
    c8a4:	72003c3f 	tst	w1, #0xffff
    c8a8:	54ff1b01 	b.ne	ac08 <f0+0x6a4>  // b.any
    c8ac:	17fff8d2 	b	abf4 <f0+0x690>
    c8b0:	72003c3f 	tst	w1, #0xffff
    c8b4:	54ff1221 	b.ne	aaf8 <f0+0x594>  // b.any
    c8b8:	17fff88b 	b	aae4 <f0+0x580>
    c8bc:	72003c3f 	tst	w1, #0xffff
    c8c0:	54ff0d21 	b.ne	aa64 <f0+0x500>  // b.any
    c8c4:	17fff863 	b	aa50 <f0+0x4ec>
    c8c8:	72003c3f 	tst	w1, #0xffff
    c8cc:	54ff4e21 	b.ne	b290 <f0+0xd2c>  // b.any
    c8d0:	17fffa6b 	b	b27c <f0+0xd18>
    c8d4:	72003c3f 	tst	w1, #0xffff
    c8d8:	54ff4801 	b.ne	b1d8 <f0+0xc74>  // b.any
    c8dc:	17fffa3a 	b	b1c4 <f0+0xc60>
    c8e0:	72003c3f 	tst	w1, #0xffff
    c8e4:	54ff42e1 	b.ne	b140 <f0+0xbdc>  // b.any
    c8e8:	17fffa11 	b	b12c <f0+0xbc8>
    c8ec:	72003c3f 	tst	w1, #0xffff
    c8f0:	54ff3de1 	b.ne	b0ac <f0+0xb48>  // b.any
    c8f4:	17fff9e9 	b	b098 <f0+0xb34>
    c8f8:	72003c3f 	tst	w1, #0xffff
    c8fc:	54ff3441 	b.ne	af84 <f0+0xa20>  // b.any
    c900:	17fff99c 	b	af70 <f0+0xa0c>
    c904:	72003c3f 	tst	w1, #0xffff
    c908:	54ff2f21 	b.ne	aeec <f0+0x988>  // b.any
    c90c:	17fff973 	b	aed8 <f0+0x974>
    c910:	72003c3f 	tst	w1, #0xffff
    c914:	54ff2821 	b.ne	ae18 <f0+0x8b4>  // b.any
    c918:	17fff93b 	b	ae04 <f0+0x8a0>
    c91c:	72003c3f 	tst	w1, #0xffff
    c920:	54ff2061 	b.ne	ad2c <f0+0x7c8>  // b.any
    c924:	17fff8fd 	b	ad18 <f0+0x7b4>
    c928:	72003c3f 	tst	w1, #0xffff
    c92c:	54fff0a1 	b.ne	c740 <f0+0x21dc>  // b.any
    c930:	17ffff7f 	b	c72c <f0+0x21c8>
    c934:	72003c3f 	tst	w1, #0xffff
    c938:	54ffeba1 	b.ne	c6ac <f0+0x2148>  // b.any
    c93c:	17ffff57 	b	c698 <f0+0x2134>
    c940:	72003c3f 	tst	w1, #0xffff
    c944:	54ffe681 	b.ne	c614 <f0+0x20b0>  // b.any
    c948:	17ffff2e 	b	c600 <f0+0x209c>
    c94c:	72003c3f 	tst	w1, #0xffff
    c950:	54ffd7a1 	b.ne	c444 <f0+0x1ee0>  // b.any
    c954:	17fffeb7 	b	c430 <f0+0x1ecc>
    c958:	72003c3f 	tst	w1, #0xffff
    c95c:	54ffce01 	b.ne	c31c <f0+0x1db8>  // b.any
    c960:	17fffe6a 	b	c308 <f0+0x1da4>
    c964:	72003c3f 	tst	w1, #0xffff
    c968:	54ffc901 	b.ne	c288 <f0+0x1d24>  // b.any
    c96c:	17fffe42 	b	c274 <f0+0x1d10>
    c970:	72003c3f 	tst	w1, #0xffff
    c974:	54ffc3e1 	b.ne	c1f0 <f0+0x1c8c>  // b.any
    c978:	17fffe19 	b	c1dc <f0+0x1c78>
    c97c:	72003c3f 	tst	w1, #0xffff
    c980:	54ffbee1 	b.ne	c15c <f0+0x1bf8>  // b.any
    c984:	17fffdf1 	b	c148 <f0+0x1be4>
    c988:	72003c3f 	tst	w1, #0xffff
    c98c:	54ffb701 	b.ne	c06c <f0+0x1b08>  // b.any
    c990:	17fffdb2 	b	c058 <f0+0x1af4>
    c994:	72003c3f 	tst	w1, #0xffff
    c998:	54ffb1e1 	b.ne	bfd4 <f0+0x1a70>  // b.any
    c99c:	17fffd89 	b	bfc0 <f0+0x1a5c>
    c9a0:	72003c3f 	tst	w1, #0xffff
    c9a4:	54ffa921 	b.ne	bec8 <f0+0x1964>  // b.any
    c9a8:	17fffd43 	b	beb4 <f0+0x1950>
    c9ac:	72003c3f 	tst	w1, #0xffff
    c9b0:	54ffa301 	b.ne	be10 <f0+0x18ac>  // b.any
    c9b4:	17fffd12 	b	bdfc <f0+0x1898>
    c9b8:	72003c3f 	tst	w1, #0xffff
    c9bc:	54ff9de1 	b.ne	bd78 <f0+0x1814>  // b.any
    c9c0:	17fffce9 	b	bd64 <f0+0x1800>
    c9c4:	72003c3f 	tst	w1, #0xffff
    c9c8:	54ff96e1 	b.ne	bca4 <f0+0x1740>  // b.any
    c9cc:	17fffcb1 	b	bc90 <f0+0x172c>
    c9d0:	72003c3f 	tst	w1, #0xffff
    c9d4:	54ff8e21 	b.ne	bb98 <f0+0x1634>  // b.any
    c9d8:	17fffc6b 	b	bb84 <f0+0x1620>
    c9dc:	72003c3f 	tst	w1, #0xffff
    c9e0:	54ff8721 	b.ne	bac4 <f0+0x1560>  // b.any
    c9e4:	17fffc33 	b	bab0 <f0+0x154c>
    c9e8:	aa1403e0 	mov	x0, x20
    c9ec:	97ffdfe9 	bl	4990 <fwp_rc_forget_slot>
    c9f0:	17ffff52 	b	c738 <f0+0x21d4>
    c9f4:	aa1703e0 	mov	x0, x23
    c9f8:	97ffdfe6 	bl	4990 <fwp_rc_forget_slot>
    c9fc:	17fff75e 	b	a774 <f0+0x210>
    ca00:	aa1703e0 	mov	x0, x23
    ca04:	97ffdfe3 	bl	4990 <fwp_rc_forget_slot>
    ca08:	17fff793 	b	a854 <f0+0x2f0>
    ca0c:	aa1703e0 	mov	x0, x23
    ca10:	97ffdfe0 	bl	4990 <fwp_rc_forget_slot>
    ca14:	17fff7e0 	b	a994 <f0+0x430>
    ca18:	aa1703e0 	mov	x0, x23
    ca1c:	97ffdfdd 	bl	4990 <fwp_rc_forget_slot>
    ca20:	17fff80f 	b	aa5c <f0+0x4f8>
    ca24:	aa1703e0 	mov	x0, x23
    ca28:	97ffdfda 	bl	4990 <fwp_rc_forget_slot>
    ca2c:	17fff831 	b	aaf0 <f0+0x58c>
    ca30:	aa1703e0 	mov	x0, x23
    ca34:	97ffdfd7 	bl	4990 <fwp_rc_forget_slot>
    ca38:	17fff872 	b	ac00 <f0+0x69c>
    ca3c:	aa1703e0 	mov	x0, x23
    ca40:	97ffdfd4 	bl	4990 <fwp_rc_forget_slot>
    ca44:	17fff893 	b	ac90 <f0+0x72c>
    ca48:	aa1703e0 	mov	x0, x23
    ca4c:	97ffdfd1 	bl	4990 <fwp_rc_forget_slot>
    ca50:	17fff8b5 	b	ad24 <f0+0x7c0>
    ca54:	aa1703e0 	mov	x0, x23
    ca58:	97ffdfce 	bl	4990 <fwp_rc_forget_slot>
    ca5c:	17fff8ed 	b	ae10 <f0+0x8ac>
    ca60:	aa1703e0 	mov	x0, x23
    ca64:	97ffdfcb 	bl	4990 <fwp_rc_forget_slot>
    ca68:	17fff91f 	b	aee4 <f0+0x980>
    ca6c:	aa1703e0 	mov	x0, x23
    ca70:	97ffdfc8 	bl	4990 <fwp_rc_forget_slot>
    ca74:	17fff942 	b	af7c <f0+0xa18>
    ca78:	aa1703e0 	mov	x0, x23
    ca7c:	97ffdfc5 	bl	4990 <fwp_rc_forget_slot>
    ca80:	17fff989 	b	b0a4 <f0+0xb40>
    ca84:	aa1703e0 	mov	x0, x23
    ca88:	97ffdfc2 	bl	4990 <fwp_rc_forget_slot>
    ca8c:	17fff9ab 	b	b138 <f0+0xbd4>
    ca90:	aa1703e0 	mov	x0, x23
    ca94:	97ffdfbf 	bl	4990 <fwp_rc_forget_slot>
    ca98:	17fff9ce 	b	b1d0 <f0+0xc6c>
    ca9c:	aa1703e0 	mov	x0, x23
    caa0:	97ffdfbc 	bl	4990 <fwp_rc_forget_slot>
    caa4:	17fff9f9 	b	b288 <f0+0xd24>
    caa8:	aa1703e0 	mov	x0, x23
    caac:	97ffdfb9 	bl	4990 <fwp_rc_forget_slot>
    cab0:	17fffa5c 	b	b420 <f0+0xebc>
    cab4:	aa1703e0 	mov	x0, x23
    cab8:	97ffdfb6 	bl	4990 <fwp_rc_forget_slot>
    cabc:	17fffa87 	b	b4d8 <f0+0xf74>
    cac0:	aa1503e0 	mov	x0, x21
    cac4:	97ffdfb3 	bl	4990 <fwp_rc_forget_slot>
    cac8:	17fffab2 	b	b590 <f0+0x102c>
    cacc:	aa1703e0 	mov	x0, x23
    cad0:	97ffdfb0 	bl	4990 <fwp_rc_forget_slot>
    cad4:	17fffb00 	b	b6d4 <f0+0x1170>
    cad8:	aa1703e0 	mov	x0, x23
    cadc:	97ffdfad 	bl	4990 <fwp_rc_forget_slot>
    cae0:	17fffb23 	b	b76c <f0+0x1208>
    cae4:	aa1703e0 	mov	x0, x23
    cae8:	97ffdfaa 	bl	4990 <fwp_rc_forget_slot>
    caec:	17fffb5c 	b	b85c <f0+0x12f8>
    caf0:	aa1703e0 	mov	x0, x23
    caf4:	97ffdfa7 	bl	4990 <fwp_rc_forget_slot>
    caf8:	17fffb95 	b	b94c <f0+0x13e8>
    cafc:	aa1703e0 	mov	x0, x23
    cb00:	97ffdfa4 	bl	4990 <fwp_rc_forget_slot>
    cb04:	17fffbc0 	b	ba04 <f0+0x14a0>
    cb08:	aa1703e0 	mov	x0, x23
    cb0c:	97ffdfa1 	bl	4990 <fwp_rc_forget_slot>
    cb10:	17fffbeb 	b	babc <f0+0x1558>
    cb14:	aa1703e0 	mov	x0, x23
    cb18:	97ffdf9e 	bl	4990 <fwp_rc_forget_slot>
    cb1c:	17fffc1d 	b	bb90 <f0+0x162c>
    cb20:	aa1703e0 	mov	x0, x23
    cb24:	97ffdf9b 	bl	4990 <fwp_rc_forget_slot>
    cb28:	17fffc5d 	b	bc9c <f0+0x1738>
    cb2c:	aa1703e0 	mov	x0, x23
    cb30:	97ffdf98 	bl	4990 <fwp_rc_forget_slot>
    cb34:	17fffc8f 	b	bd70 <f0+0x180c>
    cb38:	aa1703e0 	mov	x0, x23
    cb3c:	97ffdf95 	bl	4990 <fwp_rc_forget_slot>
    cb40:	17fffcb2 	b	be08 <f0+0x18a4>
    cb44:	aa1703e0 	mov	x0, x23
    cb48:	97ffdf92 	bl	4990 <fwp_rc_forget_slot>
    cb4c:	17fffcdd 	b	bec0 <f0+0x195c>
    cb50:	aa1703e0 	mov	x0, x23
    cb54:	97ffdf8f 	bl	4990 <fwp_rc_forget_slot>
    cb58:	17fffd1d 	b	bfcc <f0+0x1a68>
    cb5c:	aa1703e0 	mov	x0, x23
    cb60:	97ffdf8c 	bl	4990 <fwp_rc_forget_slot>
    cb64:	17fffd40 	b	c064 <f0+0x1b00>
    cb68:	aa1703e0 	mov	x0, x23
    cb6c:	97ffdf89 	bl	4990 <fwp_rc_forget_slot>
    cb70:	17fffd79 	b	c154 <f0+0x1bf0>
    cb74:	aa1703e0 	mov	x0, x23
    cb78:	97ffdf86 	bl	4990 <fwp_rc_forget_slot>
    cb7c:	17fffd9b 	b	c1e8 <f0+0x1c84>
    cb80:	aa1703e0 	mov	x0, x23
    cb84:	97ffdf83 	bl	4990 <fwp_rc_forget_slot>
    cb88:	17fffdbe 	b	c280 <f0+0x1d1c>
    cb8c:	aa1703e0 	mov	x0, x23
    cb90:	97ffdf80 	bl	4990 <fwp_rc_forget_slot>
    cb94:	17fffde0 	b	c314 <f0+0x1db0>
    cb98:	aa1703e0 	mov	x0, x23
    cb9c:	97ffdf7d 	bl	4990 <fwp_rc_forget_slot>
    cba0:	17fffe27 	b	c43c <f0+0x1ed8>
    cba4:	aa1703e0 	mov	x0, x23
    cba8:	97ffdf7a 	bl	4990 <fwp_rc_forget_slot>
    cbac:	17fffe98 	b	c60c <f0+0x20a8>
    cbb0:	aa1703e0 	mov	x0, x23
    cbb4:	97ffdf77 	bl	4990 <fwp_rc_forget_slot>
    cbb8:	17fffebb 	b	c6a4 <f0+0x2140>
    cbbc:	97ffd715 	bl	2810 <__stack_chk_fail@plt>

000000000000cbc0 <fwp_main_thread>:
    cbc0:	d10443ff 	sub	sp, sp, #0x110
    cbc4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    cbc8:	f947f400 	ldr	x0, [x0, #4072]
    cbcc:	a90c7bfd 	stp	x29, x30, [sp, #192]
    cbd0:	910303fd 	add	x29, sp, #0xc0
    cbd4:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cbd8:	b0000376 	adrp	x22, 79000 <fwp_root_context+0xba0>
    cbdc:	911902c1 	add	x1, x22, #0x640
    cbe0:	a90d53f3 	stp	x19, x20, [sp, #208]
    cbe4:	a90f63f7 	stp	x23, x24, [sp, #240]
    cbe8:	b953a421 	ldr	w1, [x1, #5028]
    cbec:	a9106bf9 	stp	x25, x26, [sp, #256]
    cbf0:	f9400002 	ldr	x2, [x0]
    cbf4:	f9005fe2 	str	x2, [sp, #184]
    cbf8:	d2800002 	mov	x2, #0x0                   	// #0
    cbfc:	34002961 	cbz	w1, d128 <fwp_main_thread+0x568>
    cc00:	911902c0 	add	x0, x22, #0x640
    cc04:	b953a800 	ldr	w0, [x0, #5032]
    cc08:	35002880 	cbnz	w0, d118 <fwp_main_thread+0x558>
    cc0c:	91001fe2 	add	x2, sp, #0x7
    cc10:	900000b5 	adrp	x21, 20000 <__data_start>
    cc14:	900000a3 	adrp	x3, 20000 <__data_start>
    cc18:	910182b3 	add	x19, x21, #0x60
    cc1c:	91118063 	add	x3, x3, #0x460
    cc20:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cc24:	d2a00025 	mov	x5, #0x10000               	// #65536
    cc28:	910023e0 	add	x0, sp, #0x8
    cc2c:	d2800001 	mov	x1, #0x0                   	// #0
    cc30:	f90007e3 	str	x3, [sp, #8]
    cc34:	b90013ff 	str	wzr, [sp, #16]
    cc38:	f9000fe5 	str	x5, [sp, #24]
    cc3c:	a90a1262 	stp	x2, x4, [x19, #160]
    cc40:	97ffd68c 	bl	2670 <sigaltstack@plt>
    cc44:	350028a0 	cbnz	w0, d158 <fwp_main_thread+0x598>
    cc48:	4f000400 	movi	v0.4s, #0x0
    cc4c:	9100a3e0 	add	x0, sp, #0x28
    cc50:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0xc>
    cc54:	52800082 	mov	w2, #0x4                   	// #4
    cc58:	9100c021 	add	x1, x1, #0x30
    cc5c:	72a10002 	movk	w2, #0x800, lsl #16
    cc60:	910083f4 	add	x20, sp, #0x20
    cc64:	f90013e1 	str	x1, [sp, #32]
    cc68:	3d802000 	str	q0, [x0, #128]
    cc6c:	b900abe2 	str	w2, [sp, #168]
    cc70:	ad000000 	stp	q0, q0, [x0]
    cc74:	ad010000 	stp	q0, q0, [x0, #32]
    cc78:	ad020000 	stp	q0, q0, [x0, #64]
    cc7c:	ad030000 	stp	q0, q0, [x0, #96]
    cc80:	97ffd6d4 	bl	27d0 <sigemptyset@plt>
    cc84:	350026a0 	cbnz	w0, d158 <fwp_main_thread+0x598>
    cc88:	aa1403e1 	mov	x1, x20
    cc8c:	d2800002 	mov	x2, #0x0                   	// #0
    cc90:	52800160 	mov	w0, #0xb                   	// #11
    cc94:	97ffd6e7 	bl	2830 <sigaction@plt>
    cc98:	35002600 	cbnz	w0, d158 <fwp_main_thread+0x598>
    cc9c:	aa1403e1 	mov	x1, x20
    cca0:	d2800002 	mov	x2, #0x0                   	// #0
    cca4:	528000e0 	mov	w0, #0x7                   	// #7
    cca8:	97ffd6e2 	bl	2830 <sigaction@plt>
    ccac:	35002560 	cbnz	w0, d158 <fwp_main_thread+0x598>
    ccb0:	911902c1 	add	x1, x22, #0x640
    ccb4:	52800034 	mov	w20, #0x1                   	// #1
    ccb8:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    ccbc:	910cc000 	add	x0, x0, #0x330
    ccc0:	b9013274 	str	w20, [x19, #304]
    ccc4:	fd4a1020 	ldr	d0, [x1, #5152]
    ccc8:	7e61d800 	ucvtf	d0, d0
    cccc:	fd00a660 	str	d0, [x19, #328]
    ccd0:	940002e8 	bl	d870 <atexit>
    ccd4:	35002480 	cbnz	w0, d164 <fwp_main_thread+0x5a4>
    ccd8:	b943ca60 	ldr	w0, [x19, #968]
    ccdc:	340022a0 	cbz	w0, d130 <fwp_main_thread+0x570>
    cce0:	910182ba 	add	x26, x21, #0x60
    cce4:	f9404f54 	ldr	x20, [x26, #152]
    cce8:	b40010b4 	cbz	x20, cefc <fwp_main_thread+0x33c>
    ccec:	aa1403f3 	mov	x19, x20
    ccf0:	91010297 	add	x23, x20, #0x40
    ccf4:	39414a99 	ldrb	w25, [x20, #82]
    ccf8:	52800038 	mov	w24, #0x1                   	// #1
    ccfc:	39014a98 	strb	w24, [x20, #82]
    cd00:	f9401680 	ldr	x0, [x20, #40]
    cd04:	b4000620 	cbz	x0, cdc8 <fwp_main_thread+0x208>
    cd08:	f9403281 	ldr	x1, [x20, #96]
    cd0c:	39414680 	ldrb	w0, [x20, #81]
    cd10:	b4000b41 	cbz	x1, ce78 <fwp_main_thread+0x2b8>
    cd14:	36000a80 	tbz	w0, #0, ce64 <fwp_main_thread+0x2a4>
    cd18:	39414a62 	ldrb	w2, [x19, #82]
    cd1c:	f9402280 	ldr	x0, [x20, #64]
    cd20:	37000d62 	tbnz	w2, #0, cecc <fwp_main_thread+0x30c>
    cd24:	f9403261 	ldr	x1, [x19, #96]
    cd28:	a911fe77 	stp	x23, xzr, [x19, #280]
    cd2c:	f9009660 	str	x0, [x19, #296]
    cd30:	b4000040 	cbz	x0, cd38 <fwp_main_thread+0x178>
    cd34:	f9009013 	str	x19, [x0, #288]
    cd38:	f9002293 	str	x19, [x20, #64]
    cd3c:	b4000101 	cbz	x1, cd5c <fwp_main_thread+0x19c>
    cd40:	f9409740 	ldr	x0, [x26, #296]
    cd44:	39015678 	strb	w24, [x19, #85]
    cd48:	f9003661 	str	x1, [x19, #104]
    cd4c:	a910827f 	stp	xzr, x0, [x19, #264]
    cd50:	b4000040 	cbz	x0, cd58 <fwp_main_thread+0x198>
    cd54:	f9008413 	str	x19, [x0, #264]
    cd58:	f9009753 	str	x19, [x26, #296]
    cd5c:	39015a7f 	strb	wzr, [x19, #86]
    cd60:	97ffe6cd 	bl	6894 <fwp_block>
    cd64:	f9408e62 	ldr	x2, [x19, #280]
    cd68:	b4000142 	cbz	x2, cd90 <fwp_main_thread+0x1d0>
    cd6c:	a9520261 	ldp	x1, x0, [x19, #288]
    cd70:	b4000ba1 	cbz	x1, cee4 <fwp_main_thread+0x324>
    cd74:	f9009420 	str	x0, [x1, #296]
    cd78:	f9409660 	ldr	x0, [x19, #296]
    cd7c:	b4000040 	cbz	x0, cd84 <fwp_main_thread+0x1c4>
    cd80:	f9009001 	str	x1, [x0, #288]
    cd84:	91080260 	add	x0, x19, #0x200
    cd88:	f900967f 	str	xzr, [x19, #296]
    cd8c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    cd90:	39415660 	ldrb	w0, [x19, #85]
    cd94:	f9404f42 	ldr	x2, [x26, #152]
    cd98:	36000960 	tbz	w0, #0, cec4 <fwp_main_thread+0x304>
    cd9c:	a9508261 	ldp	x1, x0, [x19, #264]
    cda0:	b4000a61 	cbz	x1, ceec <fwp_main_thread+0x32c>
    cda4:	f9008820 	str	x0, [x1, #272]
    cda8:	b4000040 	cbz	x0, cdb0 <fwp_main_thread+0x1f0>
    cdac:	f9008401 	str	x1, [x0, #264]
    cdb0:	91080260 	add	x0, x19, #0x200
    cdb4:	3901567f 	strb	wzr, [x19, #85]
    cdb8:	aa0203f3 	mov	x19, x2
    cdbc:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    cdc0:	f9401680 	ldr	x0, [x20, #40]
    cdc4:	b5fffa20 	cbnz	x0, cd08 <fwp_main_thread+0x148>
    cdc8:	910182a0 	add	x0, x21, #0x60
    cdcc:	39014a99 	strb	w25, [x20, #82]
    cdd0:	f941d400 	ldr	x0, [x0, #936]
    cdd4:	b4001840 	cbz	x0, d0dc <fwp_main_thread+0x51c>
    cdd8:	910182a0 	add	x0, x21, #0x60
    cddc:	f941f001 	ldr	x1, [x0, #992]
    cde0:	b903d81f 	str	wzr, [x0, #984]
    cde4:	eb13003f 	cmp	x1, x19
    cde8:	54001961 	b.ne	d114 <fwp_main_thread+0x554>  // b.any
    cdec:	b4000933 	cbz	x19, cf10 <fwp_main_thread+0x350>
    cdf0:	910182a0 	add	x0, x21, #0x60
    cdf4:	52800021 	mov	w1, #0x1                   	// #1
    cdf8:	39014a61 	strb	w1, [x19, #82]
    cdfc:	f941c005 	ldr	x5, [x0, #896]
    ce00:	b4000885 	cbz	x5, cf10 <fwp_main_thread+0x350>
    ce04:	d503201f 	nop
    ce08:	394140a0 	ldrb	w0, [x5, #80]
    ce0c:	37000060 	tbnz	w0, #0, ce18 <fwp_main_thread+0x258>
    ce10:	aa0503e0 	mov	x0, x5
    ce14:	97ffda17 	bl	3670 <fwp_cancel_tree.part.0>
    ce18:	f9409ca5 	ldr	x5, [x5, #312]
    ce1c:	b5ffff65 	cbnz	x5, ce08 <fwp_main_thread+0x248>
    ce20:	910182b4 	add	x20, x21, #0x60
    ce24:	52800037 	mov	w23, #0x1                   	// #1
    ce28:	f9402a60 	ldr	x0, [x19, #80]
    ce2c:	f2001c1f 	tst	x0, #0xff000000ff
    ce30:	540000e1 	b.ne	ce4c <fwp_main_thread+0x28c>  // b.any
    ce34:	f9406280 	ldr	x0, [x20, #192]
    ce38:	39015277 	strb	w23, [x19, #84]
    ce3c:	f900827f 	str	xzr, [x19, #256]
    ce40:	b40005a0 	cbz	x0, cef4 <fwp_main_thread+0x334>
    ce44:	f9008013 	str	x19, [x0, #256]
    ce48:	f9006293 	str	x19, [x20, #192]
    ce4c:	97ffe692 	bl	6894 <fwp_block>
    ce50:	97ffe624 	bl	66e0 <fwp_free_zombie>
    ce54:	f941c280 	ldr	x0, [x20, #896]
    ce58:	b40005c0 	cbz	x0, cf10 <fwp_main_thread+0x350>
    ce5c:	f941f293 	ldr	x19, [x20, #992]
    ce60:	17fffff2 	b	ce28 <fwp_main_thread+0x268>
    ce64:	97ffdaa7 	bl	3900 <fwp_now_ns>
    ce68:	f9403281 	ldr	x1, [x20, #96]
    ce6c:	eb01001f 	cmp	x0, x1
    ce70:	5400128a 	b.ge	d0c0 <fwp_main_thread+0x500>  // b.tcont
    ce74:	39414680 	ldrb	w0, [x20, #81]
    ce78:	39414a62 	ldrb	w2, [x19, #82]
    ce7c:	3707f500 	tbnz	w0, #0, cd1c <fwp_main_thread+0x15c>
    ce80:	f9403281 	ldr	x1, [x20, #96]
    ce84:	370001c2 	tbnz	w2, #0, cebc <fwp_main_thread+0x2fc>
    ce88:	f9403260 	ldr	x0, [x19, #96]
    ce8c:	b4000180 	cbz	x0, cebc <fwp_main_thread+0x2fc>
    ce90:	b4000061 	cbz	x1, ce9c <fwp_main_thread+0x2dc>
    ce94:	eb01001f 	cmp	x0, x1
    ce98:	9a81d000 	csel	x0, x0, x1, le
    ce9c:	f9402281 	ldr	x1, [x20, #64]
    cea0:	a911fe77 	stp	x23, xzr, [x19, #280]
    cea4:	f9009661 	str	x1, [x19, #296]
    cea8:	b40014c1 	cbz	x1, d140 <fwp_main_thread+0x580>
    ceac:	f9009033 	str	x19, [x1, #288]
    ceb0:	aa0003e1 	mov	x1, x0
    ceb4:	f9002293 	str	x19, [x20, #64]
    ceb8:	17ffffa2 	b	cd40 <fwp_main_thread+0x180>
    cebc:	f9402280 	ldr	x0, [x20, #64]
    cec0:	17ffff9a 	b	cd28 <fwp_main_thread+0x168>
    cec4:	aa0203f3 	mov	x19, x2
    cec8:	17ffff8e 	b	cd00 <fwp_main_thread+0x140>
    cecc:	a911fe77 	stp	x23, xzr, [x19, #280]
    ced0:	f9009660 	str	x0, [x19, #296]
    ced4:	b4000040 	cbz	x0, cedc <fwp_main_thread+0x31c>
    ced8:	f9009013 	str	x19, [x0, #288]
    cedc:	f9002293 	str	x19, [x20, #64]
    cee0:	17ffff9f 	b	cd5c <fwp_main_thread+0x19c>
    cee4:	f9000040 	str	x0, [x2]
    cee8:	17ffffa5 	b	cd7c <fwp_main_thread+0x1bc>
    ceec:	f9009740 	str	x0, [x26, #296]
    cef0:	17ffffae 	b	cda8 <fwp_main_thread+0x1e8>
    cef4:	f9006693 	str	x19, [x20, #200]
    cef8:	17ffffd4 	b	ce48 <fwp_main_thread+0x288>
    cefc:	f941d740 	ldr	x0, [x26, #936]
    cf00:	b4000ec0 	cbz	x0, d0d8 <fwp_main_thread+0x518>
    cf04:	f941f340 	ldr	x0, [x26, #992]
    cf08:	b903db5f 	str	wzr, [x26, #984]
    cf0c:	b5001040 	cbnz	x0, d114 <fwp_main_thread+0x554>
    cf10:	910182b4 	add	x20, x21, #0x60
    cf14:	97ffe5f3 	bl	66e0 <fwp_free_zombie>
    cf18:	f9406680 	ldr	x0, [x20, #200]
    cf1c:	b5000fc0 	cbnz	x0, d114 <fwp_main_thread+0x554>
    cf20:	f9409680 	ldr	x0, [x20, #296]
    cf24:	b5000f80 	cbnz	x0, d114 <fwp_main_thread+0x554>
    cf28:	b9417293 	ldr	w19, [x20, #368]
    cf2c:	340001d3 	cbz	w19, cf64 <fwp_main_thread+0x3a4>
    cf30:	93407e77 	sxtw	x23, w19
    cf34:	51000673 	sub	w19, w19, #0x1
    cf38:	d1000af7 	sub	x23, x23, #0x2
    cf3c:	91060298 	add	x24, x20, #0x180
    cf40:	cb3342f7 	sub	x23, x23, w19, uxtw
    cf44:	93407e73 	sxtw	x19, w19
    cf48:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    cf4c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cf50:	b9017293 	str	w19, [x20, #368]
    cf54:	d1000673 	sub	x19, x19, #0x1
    cf58:	97ffd676 	bl	2930 <munmap@plt>
    cf5c:	eb1302ff 	cmp	x23, x19
    cf60:	54ffff41 	b.ne	cf48 <fwp_main_thread+0x388>  // b.any
    cf64:	900000b3 	adrp	x19, 20000 <__data_start>
    cf68:	91004260 	add	x0, x19, #0x10
    cf6c:	b9403000 	ldr	w0, [x0, #48]
    cf70:	37f80040 	tbnz	w0, #31, cf78 <fwp_main_thread+0x3b8>
    cf74:	97ffd62b 	bl	2820 <close@plt>
    cf78:	910182a0 	add	x0, x21, #0x60
    cf7c:	91004261 	add	x1, x19, #0x10
    cf80:	12800002 	mov	w2, #0xffffffff            	// #-1
    cf84:	d2800013 	mov	x19, #0x0                   	// #0
    cf88:	f941f417 	ldr	x23, [x0, #1000]
    cf8c:	b9003022 	str	w2, [x1, #48]
    cf90:	f941f814 	ldr	x20, [x0, #1008]
    cf94:	b4000177 	cbz	x23, cfc0 <fwp_main_thread+0x400>
    cf98:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    cf9c:	b40000c0 	cbz	x0, cfb4 <fwp_main_thread+0x3f4>
    cfa0:	f9400001 	ldr	x1, [x0]
    cfa4:	b5000b81 	cbnz	x1, d114 <fwp_main_thread+0x554>
    cfa8:	f9400401 	ldr	x1, [x0, #8]
    cfac:	b5000b41 	cbnz	x1, d114 <fwp_main_thread+0x554>
    cfb0:	97ffdf18 	bl	4c10 <fwp_mem_free>
    cfb4:	91000673 	add	x19, x19, #0x1
    cfb8:	eb1302ff 	cmp	x23, x19
    cfbc:	54fffee1 	b.ne	cf98 <fwp_main_thread+0x3d8>  // b.any
    cfc0:	aa1403e0 	mov	x0, x20
    cfc4:	97ffdf13 	bl	4c10 <fwp_mem_free>
    cfc8:	910182a0 	add	x0, x21, #0x60
    cfcc:	f941f013 	ldr	x19, [x0, #992]
    cfd0:	f901f41f 	str	xzr, [x0, #1000]
    cfd4:	f901f81f 	str	xzr, [x0, #1008]
    cfd8:	b40001f3 	cbz	x19, d014 <fwp_main_thread+0x454>
    cfdc:	f9401661 	ldr	x1, [x19, #40]
    cfe0:	b50009a1 	cbnz	x1, d114 <fwp_main_thread+0x554>
    cfe4:	f9405661 	ldr	x1, [x19, #168]
    cfe8:	b5000961 	cbnz	x1, d114 <fwp_main_thread+0x554>
    cfec:	f941d401 	ldr	x1, [x0, #936]
    cff0:	b5000921 	cbnz	x1, d114 <fwp_main_thread+0x554>
    cff4:	f941dc00 	ldr	x0, [x0, #952]
    cff8:	b50008e0 	cbnz	x0, d114 <fwp_main_thread+0x554>
    cffc:	d2823a02 	mov	x2, #0x11d0                	// #4560
    d000:	f0000340 	adrp	x0, 78000 <ad_raw_blocks+0x17ba0>
    d004:	91118000 	add	x0, x0, #0x460
    d008:	97ffd5f6 	bl	27e0 <memset@plt>
    d00c:	aa1303e0 	mov	x0, x19
    d010:	97ffdf00 	bl	4c10 <fwp_mem_free>
    d014:	910182a6 	add	x6, x21, #0x60
    d018:	911902d6 	add	x22, x22, #0x640
    d01c:	3dc01aa1 	ldr	q1, [x21, #96]
    d020:	52800041 	mov	w1, #0x2                   	// #2
    d024:	3dc004c2 	ldr	q2, [x6, #16]
    d028:	b0000002 	adrp	x2, e000 <_IO_stdin_used+0x760>
    d02c:	fd4a12c0 	ldr	d0, [x22, #5152]
    d030:	91036042 	add	x2, x2, #0xd8
    d034:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    d038:	fd40a4c1 	ldr	d1, [x6, #328]
    d03c:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d040:	f947e800 	ldr	x0, [x0, #4048]
    d044:	7e61d800 	ucvtf	d0, d0
    d048:	a95390c3 	ldp	x3, x4, [x6, #312]
    d04c:	f9004cdf 	str	xzr, [x6, #152]
    d050:	f9400000 	ldr	x0, [x0]
    d054:	1e613801 	fsub	d1, d0, d1
    d058:	f940acc5 	ldr	x5, [x6, #344]
    d05c:	b90130df 	str	wzr, [x6, #304]
    d060:	5ef1b842 	addp	d2, v2.2d
    d064:	fd40a8c0 	ldr	d0, [x6, #336]
    d068:	f901f0df 	str	xzr, [x6, #992]
    d06c:	fd0058c2 	str	d2, [x6, #176]
    d070:	97ffd604 	bl	2880 <__fprintf_chk@plt>
    d074:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d078:	f947ec00 	ldr	x0, [x0, #4056]
    d07c:	f9400000 	ldr	x0, [x0]
    d080:	97ffd630 	bl	2940 <fflush@plt>
    d084:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d088:	f947f400 	ldr	x0, [x0, #4072]
    d08c:	f9405fe2 	ldr	x2, [sp, #184]
    d090:	f9400001 	ldr	x1, [x0]
    d094:	eb010042 	subs	x2, x2, x1
    d098:	d2800001 	mov	x1, #0x0                   	// #0
    d09c:	540006a1 	b.ne	d170 <fwp_main_thread+0x5b0>  // b.any
    d0a0:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d0a4:	d2800000 	mov	x0, #0x0                   	// #0
    d0a8:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d0ac:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d0b0:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d0b4:	a9506bf9 	ldp	x25, x26, [sp, #256]
    d0b8:	910443ff 	add	sp, sp, #0x110
    d0bc:	d65f03c0 	ret
    d0c0:	39414280 	ldrb	w0, [x20, #80]
    d0c4:	3707ed80 	tbnz	w0, #0, ce74 <fwp_main_thread+0x2b4>
    d0c8:	aa1403e0 	mov	x0, x20
    d0cc:	97ffd969 	bl	3670 <fwp_cancel_tree.part.0>
    d0d0:	39414680 	ldrb	w0, [x20, #81]
    d0d4:	17ffff69 	b	ce78 <fwp_main_thread+0x2b8>
    d0d8:	d2800013 	mov	x19, #0x0                   	// #0
    d0dc:	910182b4 	add	x20, x21, #0x60
    d0e0:	f941de80 	ldr	x0, [x20, #952]
    d0e4:	b5ffe7a0 	cbnz	x0, cdd8 <fwp_main_thread+0x218>
    d0e8:	f941d280 	ldr	x0, [x20, #928]
    d0ec:	97ffdec9 	bl	4c10 <fwp_mem_free>
    d0f0:	f901d29f 	str	xzr, [x20, #928]
    d0f4:	f901da9f 	str	xzr, [x20, #944]
    d0f8:	f941f280 	ldr	x0, [x20, #992]
    d0fc:	b4000293 	cbz	x19, d14c <fwp_main_thread+0x58c>
    d100:	f900567f 	str	xzr, [x19, #168]
    d104:	f9005e7f 	str	xzr, [x19, #184]
    d108:	b903da9f 	str	wzr, [x20, #984]
    d10c:	eb13001f 	cmp	x0, x19
    d110:	54ffe700 	b.eq	cdf0 <fwp_main_thread+0x230>  // b.none
    d114:	97ffd5d3 	bl	2860 <abort@plt>
    d118:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    d11c:	913c8000 	add	x0, x0, #0xf20
    d120:	940001d4 	bl	d870 <atexit>
    d124:	17fffeba 	b	cc0c <fwp_main_thread+0x4c>
    d128:	97ffdbd7 	bl	4084 <fwp_heap_init>
    d12c:	17fffeb5 	b	cc00 <fwp_main_thread+0x40>
    d130:	97fff50d 	bl	a564 <f0>
    d134:	b903ca74 	str	w20, [x19, #968]
    d138:	f901ea60 	str	x0, [x19, #976]
    d13c:	17fffee9 	b	cce0 <fwp_main_thread+0x120>
    d140:	aa0003e1 	mov	x1, x0
    d144:	f9002293 	str	x19, [x20, #64]
    d148:	17fffefe 	b	cd40 <fwp_main_thread+0x180>
    d14c:	b903da9f 	str	wzr, [x20, #984]
    d150:	b4ffee00 	cbz	x0, cf10 <fwp_main_thread+0x350>
    d154:	97ffd5c3 	bl	2860 <abort@plt>
    d158:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x760>
    d15c:	91024000 	add	x0, x0, #0x90
    d160:	97ffd988 	bl	3780 <fwp_trap>
    d164:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x760>
    d168:	9102e000 	add	x0, x0, #0xb8
    d16c:	97ffd865 	bl	3300 <ad_raw_fail>
    d170:	97ffd5a8 	bl	2810 <__stack_chk_fail@plt>
    d174:	d503201f 	nop
    d178:	d503201f 	nop
    d17c:	d503201f 	nop

000000000000d180 <__divti3>:
    d180:	d503245f 	bti	c
    d184:	d2800004 	mov	x4, #0x0                   	// #0
    d188:	b7f80721 	tbnz	x1, #63, d26c <__divti3+0xec>
    d18c:	b6f80083 	tbz	x3, #63, d19c <__divti3+0x1c>
    d190:	eb0203e2 	negs	x2, x2
    d194:	aa2403e4 	mvn	x4, x4
    d198:	da0303e3 	ngc	x3, x3
    d19c:	aa0203e6 	mov	x6, x2
    d1a0:	aa0003e7 	mov	x7, x0
    d1a4:	aa0103e5 	mov	x5, x1
    d1a8:	b5000583 	cbnz	x3, d258 <__divti3+0xd8>
    d1ac:	eb01005f 	cmp	x2, x1
    d1b0:	54000e69 	b.ls	d37c <__divti3+0x1fc>  // b.plast
    d1b4:	dac01040 	clz	x0, x2
    d1b8:	b40000e0 	cbz	x0, d1d4 <__divti3+0x54>
    d1bc:	4b0003e1 	neg	w1, w0
    d1c0:	9ac020a5 	lsl	x5, x5, x0
    d1c4:	9ac02046 	lsl	x6, x2, x0
    d1c8:	9ac124e1 	lsr	x1, x7, x1
    d1cc:	aa050025 	orr	x5, x1, x5
    d1d0:	9ac020e7 	lsl	x7, x7, x0
    d1d4:	d360fcc8 	lsr	x8, x6, #32
    d1d8:	92407cc2 	and	x2, x6, #0xffffffff
    d1dc:	9ac808a3 	udiv	x3, x5, x8
    d1e0:	9b089465 	msub	x5, x3, x8, x5
    d1e4:	aa0303e0 	mov	x0, x3
    d1e8:	9b037c41 	mul	x1, x2, x3
    d1ec:	93c780a5 	extr	x5, x5, x7, #32
    d1f0:	eb05003f 	cmp	x1, x5
    d1f4:	540000a9 	b.ls	d208 <__divti3+0x88>  // b.plast
    d1f8:	ab0500c5 	adds	x5, x6, x5
    d1fc:	d1000460 	sub	x0, x3, #0x1
    d200:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d204:	540015a8 	b.hi	d4b8 <__divti3+0x338>  // b.pmore
    d208:	cb0100a5 	sub	x5, x5, x1
    d20c:	9ac808a3 	udiv	x3, x5, x8
    d210:	9b089465 	msub	x5, x3, x8, x5
    d214:	aa0303e1 	mov	x1, x3
    d218:	9b037c42 	mul	x2, x2, x3
    d21c:	aa0703e3 	mov	x3, x7
    d220:	b3607ca3 	bfi	x3, x5, #32, #32
    d224:	eb03005f 	cmp	x2, x3
    d228:	540000c9 	b.ls	d240 <__divti3+0xc0>  // b.plast
    d22c:	ab0300c3 	adds	x3, x6, x3
    d230:	d1000425 	sub	x5, x1, #0x1
    d234:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d238:	d1000821 	sub	x1, x1, #0x2
    d23c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d240:	aa008020 	orr	x0, x1, x0, lsl #32
    d244:	d2800001 	mov	x1, #0x0                   	// #0
    d248:	b4000064 	cbz	x4, d254 <__divti3+0xd4>
    d24c:	eb0003e0 	negs	x0, x0
    d250:	da0103e1 	ngc	x1, x1
    d254:	d65f03c0 	ret
    d258:	eb01007f 	cmp	x3, x1
    d25c:	54000109 	b.ls	d27c <__divti3+0xfc>  // b.plast
    d260:	d2800001 	mov	x1, #0x0                   	// #0
    d264:	d2800000 	mov	x0, #0x0                   	// #0
    d268:	17fffff8 	b	d248 <__divti3+0xc8>
    d26c:	eb0003e0 	negs	x0, x0
    d270:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d274:	da0103e1 	ngc	x1, x1
    d278:	17ffffc5 	b	d18c <__divti3+0xc>
    d27c:	dac01067 	clz	x7, x3
    d280:	b40010e7 	cbz	x7, d49c <__divti3+0x31c>
    d284:	d2800805 	mov	x5, #0x40                  	// #64
    d288:	cb0700a5 	sub	x5, x5, x7
    d28c:	9ac72063 	lsl	x3, x3, x7
    d290:	9ac52448 	lsr	x8, x2, x5
    d294:	aa030108 	orr	x8, x8, x3
    d298:	9ac52426 	lsr	x6, x1, x5
    d29c:	92407d0a 	and	x10, x8, #0xffffffff
    d2a0:	d360fd09 	lsr	x9, x8, #32
    d2a4:	9ac52403 	lsr	x3, x0, x5
    d2a8:	9ac72021 	lsl	x1, x1, x7
    d2ac:	aa010063 	orr	x3, x3, x1
    d2b0:	9ac72042 	lsl	x2, x2, x7
    d2b4:	9ac908cb 	udiv	x11, x6, x9
    d2b8:	9b099965 	msub	x5, x11, x9, x6
    d2bc:	aa0b03e1 	mov	x1, x11
    d2c0:	9b0b7d46 	mul	x6, x10, x11
    d2c4:	93c380a5 	extr	x5, x5, x3, #32
    d2c8:	eb0500df 	cmp	x6, x5
    d2cc:	540000a9 	b.ls	d2e0 <__divti3+0x160>  // b.plast
    d2d0:	ab050105 	adds	x5, x8, x5
    d2d4:	d1000561 	sub	x1, x11, #0x1
    d2d8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d2dc:	54000f48 	b.hi	d4c4 <__divti3+0x344>  // b.pmore
    d2e0:	cb0600a6 	sub	x6, x5, x6
    d2e4:	9ac908cb 	udiv	x11, x6, x9
    d2e8:	9b099969 	msub	x9, x11, x9, x6
    d2ec:	aa0b03e5 	mov	x5, x11
    d2f0:	9b0b7d4a 	mul	x10, x10, x11
    d2f4:	b3607d23 	bfi	x3, x9, #32, #32
    d2f8:	eb03015f 	cmp	x10, x3
    d2fc:	540000a9 	b.ls	d310 <__divti3+0x190>  // b.plast
    d300:	ab030103 	adds	x3, x8, x3
    d304:	d1000565 	sub	x5, x11, #0x1
    d308:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d30c:	54000e28 	b.hi	d4d0 <__divti3+0x350>  // b.pmore
    d310:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d314:	92407c48 	and	x8, x2, #0xffffffff
    d318:	2a0503e5 	mov	w5, w5
    d31c:	d360fc42 	lsr	x2, x2, #32
    d320:	d360fc26 	lsr	x6, x1, #32
    d324:	cb0a0063 	sub	x3, x3, x10
    d328:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d32c:	9b087caa 	mul	x10, x5, x8
    d330:	9b087cc8 	mul	x8, x6, x8
    d334:	9b0220a5 	madd	x5, x5, x2, x8
    d338:	9b027cc6 	mul	x6, x6, x2
    d33c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d340:	8b0900c5 	add	x5, x6, x9
    d344:	eb02011f 	cmp	x8, x2
    d348:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d34c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d350:	eb06007f 	cmp	x3, x6
    d354:	540000e3 	b.cc	d370 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d358:	92407d4a 	and	x10, x10, #0xffffffff
    d35c:	9ac72000 	lsl	x0, x0, x7
    d360:	8b028142 	add	x2, x10, x2, lsl #32
    d364:	eb02001f 	cmp	x0, x2
    d368:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d36c:	54000a01 	b.ne	d4ac <__divti3+0x32c>  // b.any
    d370:	d1000420 	sub	x0, x1, #0x1
    d374:	d2800001 	mov	x1, #0x0                   	// #0
    d378:	17ffffb4 	b	d248 <__divti3+0xc8>
    d37c:	b5000062 	cbnz	x2, d388 <__divti3+0x208>
    d380:	d2800022 	mov	x2, #0x1                   	// #1
    d384:	9ac30846 	udiv	x6, x2, x3
    d388:	dac010c8 	clz	x8, x6
    d38c:	b5000408 	cbnz	x8, d40c <__divti3+0x28c>
    d390:	d360fcc9 	lsr	x9, x6, #32
    d394:	92407cc5 	and	x5, x6, #0xffffffff
    d398:	cb060023 	sub	x3, x1, x6
    d39c:	d2800021 	mov	x1, #0x1                   	// #1
    d3a0:	9ac90868 	udiv	x8, x3, x9
    d3a4:	9b098d03 	msub	x3, x8, x9, x3
    d3a8:	aa0803e0 	mov	x0, x8
    d3ac:	9b057d02 	mul	x2, x8, x5
    d3b0:	93c78063 	extr	x3, x3, x7, #32
    d3b4:	eb03005f 	cmp	x2, x3
    d3b8:	540000a9 	b.ls	d3cc <__divti3+0x24c>  // b.plast
    d3bc:	ab0300c3 	adds	x3, x6, x3
    d3c0:	d1000500 	sub	x0, x8, #0x1
    d3c4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d3c8:	54000968 	b.hi	d4f4 <__divti3+0x374>  // b.pmore
    d3cc:	cb020063 	sub	x3, x3, x2
    d3d0:	9ac90862 	udiv	x2, x3, x9
    d3d4:	aa0203e8 	mov	x8, x2
    d3d8:	9b098c42 	msub	x2, x2, x9, x3
    d3dc:	aa0703e3 	mov	x3, x7
    d3e0:	9b057d05 	mul	x5, x8, x5
    d3e4:	b3607c43 	bfi	x3, x2, #32, #32
    d3e8:	eb0300bf 	cmp	x5, x3
    d3ec:	540000c9 	b.ls	d404 <__divti3+0x284>  // b.plast
    d3f0:	ab0300c2 	adds	x2, x6, x3
    d3f4:	d1000503 	sub	x3, x8, #0x1
    d3f8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d3fc:	d1000908 	sub	x8, x8, #0x2
    d400:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d404:	aa008100 	orr	x0, x8, x0, lsl #32
    d408:	17ffff90 	b	d248 <__divti3+0xc8>
    d40c:	9ac820c6 	lsl	x6, x6, x8
    d410:	d2800803 	mov	x3, #0x40                  	// #64
    d414:	cb080063 	sub	x3, x3, x8
    d418:	d360fcc9 	lsr	x9, x6, #32
    d41c:	9ac82027 	lsl	x7, x1, x8
    d420:	92407cc5 	and	x5, x6, #0xffffffff
    d424:	9ac32422 	lsr	x2, x1, x3
    d428:	9ac32403 	lsr	x3, x0, x3
    d42c:	aa070063 	orr	x3, x3, x7
    d430:	9ac9084a 	udiv	x10, x2, x9
    d434:	9ac82007 	lsl	x7, x0, x8
    d438:	9b098940 	msub	x0, x10, x9, x2
    d43c:	aa0a03e1 	mov	x1, x10
    d440:	9b0a7ca2 	mul	x2, x5, x10
    d444:	93c38000 	extr	x0, x0, x3, #32
    d448:	eb00005f 	cmp	x2, x0
    d44c:	540000a9 	b.ls	d460 <__divti3+0x2e0>  // b.plast
    d450:	ab0000c0 	adds	x0, x6, x0
    d454:	d1000541 	sub	x1, x10, #0x1
    d458:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d45c:	54000468 	b.hi	d4e8 <__divti3+0x368>  // b.pmore
    d460:	cb020000 	sub	x0, x0, x2
    d464:	9ac9080a 	udiv	x10, x0, x9
    d468:	9b098140 	msub	x0, x10, x9, x0
    d46c:	aa0a03e2 	mov	x2, x10
    d470:	9b0a7ca8 	mul	x8, x5, x10
    d474:	b3607c03 	bfi	x3, x0, #32, #32
    d478:	eb03011f 	cmp	x8, x3
    d47c:	540000a9 	b.ls	d490 <__divti3+0x310>  // b.plast
    d480:	ab0300c3 	adds	x3, x6, x3
    d484:	d1000542 	sub	x2, x10, #0x1
    d488:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d48c:	54000288 	b.hi	d4dc <__divti3+0x35c>  // b.pmore
    d490:	cb080063 	sub	x3, x3, x8
    d494:	aa018041 	orr	x1, x2, x1, lsl #32
    d498:	17ffffc2 	b	d3a0 <__divti3+0x220>
    d49c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d4a0:	d2800001 	mov	x1, #0x0                   	// #0
    d4a4:	9a9f87e0 	cset	x0, ls	// ls = plast
    d4a8:	17ffff68 	b	d248 <__divti3+0xc8>
    d4ac:	aa0103e0 	mov	x0, x1
    d4b0:	d2800001 	mov	x1, #0x0                   	// #0
    d4b4:	17ffff65 	b	d248 <__divti3+0xc8>
    d4b8:	d1000860 	sub	x0, x3, #0x2
    d4bc:	8b0600a5 	add	x5, x5, x6
    d4c0:	17ffff52 	b	d208 <__divti3+0x88>
    d4c4:	d1000961 	sub	x1, x11, #0x2
    d4c8:	8b0800a5 	add	x5, x5, x8
    d4cc:	17ffff85 	b	d2e0 <__divti3+0x160>
    d4d0:	d1000965 	sub	x5, x11, #0x2
    d4d4:	8b080063 	add	x3, x3, x8
    d4d8:	17ffff8e 	b	d310 <__divti3+0x190>
    d4dc:	d1000942 	sub	x2, x10, #0x2
    d4e0:	8b060063 	add	x3, x3, x6
    d4e4:	17ffffeb 	b	d490 <__divti3+0x310>
    d4e8:	d1000941 	sub	x1, x10, #0x2
    d4ec:	8b060000 	add	x0, x0, x6
    d4f0:	17ffffdc 	b	d460 <__divti3+0x2e0>
    d4f4:	d1000900 	sub	x0, x8, #0x2
    d4f8:	8b060063 	add	x3, x3, x6
    d4fc:	17ffffb4 	b	d3cc <__divti3+0x24c>

000000000000d500 <__modti3>:
    d500:	d503245f 	bti	c
    d504:	d2800004 	mov	x4, #0x0                   	// #0
    d508:	b6f80081 	tbz	x1, #63, d518 <__modti3+0x18>
    d50c:	eb0003e0 	negs	x0, x0
    d510:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d514:	da0103e1 	ngc	x1, x1
    d518:	f100007f 	cmp	x3, #0x0
    d51c:	5400128b 	b.lt	d76c <__modti3+0x26c>  // b.tstop
    d520:	aa0003e7 	mov	x7, x0
    d524:	aa0103e6 	mov	x6, x1
    d528:	540004e1 	b.ne	d5c4 <__modti3+0xc4>  // b.any
    d52c:	eb02003f 	cmp	x1, x2
    d530:	54000dc2 	b.cs	d6e8 <__modti3+0x1e8>  // b.hs, b.nlast
    d534:	dac01043 	clz	x3, x2
    d538:	aa0303e5 	mov	x5, x3
    d53c:	b40000e3 	cbz	x3, d558 <__modti3+0x58>
    d540:	4b0303e6 	neg	w6, w3
    d544:	9ac32021 	lsl	x1, x1, x3
    d548:	9ac32042 	lsl	x2, x2, x3
    d54c:	9ac62406 	lsr	x6, x0, x6
    d550:	aa0100c6 	orr	x6, x6, x1
    d554:	9ac32007 	lsl	x7, x0, x3
    d558:	d360fc40 	lsr	x0, x2, #32
    d55c:	92407c43 	and	x3, x2, #0xffffffff
    d560:	9ac008c1 	udiv	x1, x6, x0
    d564:	9b009826 	msub	x6, x1, x0, x6
    d568:	9b017c61 	mul	x1, x3, x1
    d56c:	93c780c6 	extr	x6, x6, x7, #32
    d570:	eb06003f 	cmp	x1, x6
    d574:	540000a9 	b.ls	d588 <__modti3+0x88>  // b.plast
    d578:	ab060046 	adds	x6, x2, x6
    d57c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d580:	8b0200c8 	add	x8, x6, x2
    d584:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d588:	cb0100c6 	sub	x6, x6, x1
    d58c:	9ac008c8 	udiv	x8, x6, x0
    d590:	9b009901 	msub	x1, x8, x0, x6
    d594:	aa0703e0 	mov	x0, x7
    d598:	9b087c63 	mul	x3, x3, x8
    d59c:	b3607c20 	bfi	x0, x1, #32, #32
    d5a0:	eb00007f 	cmp	x3, x0
    d5a4:	54001088 	b.hi	d7b4 <__modti3+0x2b4>  // b.pmore
    d5a8:	cb030000 	sub	x0, x0, x3
    d5ac:	9ac52400 	lsr	x0, x0, x5
    d5b0:	d2800001 	mov	x1, #0x0                   	// #0
    d5b4:	b4000064 	cbz	x4, d5c0 <__modti3+0xc0>
    d5b8:	eb0003e0 	negs	x0, x0
    d5bc:	da0103e1 	ngc	x1, x1
    d5c0:	d65f03c0 	ret
    d5c4:	dac01066 	clz	x6, x3
    d5c8:	eb03003f 	cmp	x1, x3
    d5cc:	54ffff43 	b.cc	d5b4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d5d0:	93407cc5 	sxtw	x5, w6
    d5d4:	d2800808 	mov	x8, #0x40                  	// #64
    d5d8:	cb050108 	sub	x8, x8, x5
    d5dc:	9ac62063 	lsl	x3, x3, x6
    d5e0:	9ac62025 	lsl	x5, x1, x6
    d5e4:	9ac82447 	lsr	x7, x2, x8
    d5e8:	aa0300e7 	orr	x7, x7, x3
    d5ec:	9ac82423 	lsr	x3, x1, x8
    d5f0:	92407cec 	and	x12, x7, #0xffffffff
    d5f4:	d360fcea 	lsr	x10, x7, #32
    d5f8:	9ac82401 	lsr	x1, x0, x8
    d5fc:	aa050021 	orr	x1, x1, x5
    d600:	9ac62042 	lsl	x2, x2, x6
    d604:	9ac62000 	lsl	x0, x0, x6
    d608:	9aca086b 	udiv	x11, x3, x10
    d60c:	9b0a8d63 	msub	x3, x11, x10, x3
    d610:	aa0b03e5 	mov	x5, x11
    d614:	9b0b7d89 	mul	x9, x12, x11
    d618:	93c18063 	extr	x3, x3, x1, #32
    d61c:	eb03013f 	cmp	x9, x3
    d620:	540000a9 	b.ls	d634 <__modti3+0x134>  // b.plast
    d624:	ab0300e3 	adds	x3, x7, x3
    d628:	d1000565 	sub	x5, x11, #0x1
    d62c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d630:	54001168 	b.hi	d85c <__modti3+0x35c>  // b.pmore
    d634:	cb090063 	sub	x3, x3, x9
    d638:	9aca086b 	udiv	x11, x3, x10
    d63c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d640:	aa0b03e9 	mov	x9, x11
    d644:	9b0b7d8c 	mul	x12, x12, x11
    d648:	b3607d41 	bfi	x1, x10, #32, #32
    d64c:	eb01019f 	cmp	x12, x1
    d650:	540000a9 	b.ls	d664 <__modti3+0x164>  // b.plast
    d654:	ab0100e1 	adds	x1, x7, x1
    d658:	d1000569 	sub	x9, x11, #0x1
    d65c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d660:	54000f88 	b.hi	d850 <__modti3+0x350>  // b.pmore
    d664:	aa058123 	orr	x3, x9, x5, lsl #32
    d668:	92407c4b 	and	x11, x2, #0xffffffff
    d66c:	2a0903e9 	mov	w9, w9
    d670:	d360fc4a 	lsr	x10, x2, #32
    d674:	d360fc63 	lsr	x3, x3, #32
    d678:	cb0c0021 	sub	x1, x1, x12
    d67c:	aa0a03ec 	mov	x12, x10
    d680:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d684:	9b0b7d25 	mul	x5, x9, x11
    d688:	9b0b7c6b 	mul	x11, x3, x11
    d68c:	9b0a2d29 	madd	x9, x9, x10, x11
    d690:	92407caa 	and	x10, x5, #0xffffffff
    d694:	9b0c7c63 	mul	x3, x3, x12
    d698:	8b458125 	add	x5, x9, x5, lsr #32
    d69c:	8b0d0069 	add	x9, x3, x13
    d6a0:	eb05017f 	cmp	x11, x5
    d6a4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d6a8:	8b058149 	add	x9, x10, x5, lsl #32
    d6ac:	8b458063 	add	x3, x3, x5, lsr #32
    d6b0:	eb03003f 	cmp	x1, x3
    d6b4:	54000063 	b.cc	d6c0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d6b8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d6bc:	54000082 	b.cs	d6cc <__modti3+0x1cc>  // b.hs, b.nlast
    d6c0:	eb020129 	subs	x9, x9, x2
    d6c4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d6c8:	cb070063 	sub	x3, x3, x7
    d6cc:	eb090000 	subs	x0, x0, x9
    d6d0:	da030021 	sbc	x1, x1, x3
    d6d4:	9ac62400 	lsr	x0, x0, x6
    d6d8:	9ac82028 	lsl	x8, x1, x8
    d6dc:	aa000100 	orr	x0, x8, x0
    d6e0:	9ac62421 	lsr	x1, x1, x6
    d6e4:	17ffffb4 	b	d5b4 <__modti3+0xb4>
    d6e8:	b5000062 	cbnz	x2, d6f4 <__modti3+0x1f4>
    d6ec:	d2800023 	mov	x3, #0x1                   	// #1
    d6f0:	9ac20862 	udiv	x2, x3, x2
    d6f4:	dac01048 	clz	x8, x2
    d6f8:	aa0803e5 	mov	x5, x8
    d6fc:	b5000668 	cbnz	x8, d7c8 <__modti3+0x2c8>
    d700:	cb020020 	sub	x0, x1, x2
    d704:	d360fc49 	lsr	x9, x2, #32
    d708:	92407c4a 	and	x10, x2, #0xffffffff
    d70c:	9ac90801 	udiv	x1, x0, x9
    d710:	9b098020 	msub	x0, x1, x9, x0
    d714:	9b0a7c21 	mul	x1, x1, x10
    d718:	93c78000 	extr	x0, x0, x7, #32
    d71c:	eb00003f 	cmp	x1, x0
    d720:	540000a9 	b.ls	d734 <__modti3+0x234>  // b.plast
    d724:	ab000040 	adds	x0, x2, x0
    d728:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d72c:	8b020003 	add	x3, x0, x2
    d730:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d734:	cb010001 	sub	x1, x0, x1
    d738:	9ac90820 	udiv	x0, x1, x9
    d73c:	9b098403 	msub	x3, x0, x9, x1
    d740:	aa0703e1 	mov	x1, x7
    d744:	9b0a7c00 	mul	x0, x0, x10
    d748:	b3607c61 	bfi	x1, x3, #32, #32
    d74c:	eb01001f 	cmp	x0, x1
    d750:	540000a9 	b.ls	d764 <__modti3+0x264>  // b.plast
    d754:	ab010041 	adds	x1, x2, x1
    d758:	8b020022 	add	x2, x1, x2
    d75c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d760:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d764:	cb000020 	sub	x0, x1, x0
    d768:	17ffff91 	b	d5ac <__modti3+0xac>
    d76c:	eb0203e5 	negs	x5, x2
    d770:	aa0003e7 	mov	x7, x0
    d774:	da0303e8 	ngc	x8, x3
    d778:	aa0503e2 	mov	x2, x5
    d77c:	aa0803e3 	mov	x3, x8
    d780:	aa0103e6 	mov	x6, x1
    d784:	b4ffed48 	cbz	x8, d52c <__modti3+0x2c>
    d788:	eb01011f 	cmp	x8, x1
    d78c:	54fff148 	b.hi	d5b4 <__modti3+0xb4>  // b.pmore
    d790:	dac01109 	clz	x9, x8
    d794:	2a0903e6 	mov	w6, w9
    d798:	b5fff1c9 	cbnz	x9, d5d0 <__modti3+0xd0>
    d79c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d7a0:	54000068 	b.hi	d7ac <__modti3+0x2ac>  // b.pmore
    d7a4:	eb050007 	subs	x7, x0, x5
    d7a8:	da080021 	sbc	x1, x1, x8
    d7ac:	aa0703e0 	mov	x0, x7
    d7b0:	17ffff81 	b	d5b4 <__modti3+0xb4>
    d7b4:	ab000040 	adds	x0, x2, x0
    d7b8:	8b020002 	add	x2, x0, x2
    d7bc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d7c0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d7c4:	17ffff79 	b	d5a8 <__modti3+0xa8>
    d7c8:	9ac82042 	lsl	x2, x2, x8
    d7cc:	d2800803 	mov	x3, #0x40                  	// #64
    d7d0:	cb080063 	sub	x3, x3, x8
    d7d4:	d360fc49 	lsr	x9, x2, #32
    d7d8:	9ac82027 	lsl	x7, x1, x8
    d7dc:	92407c4a 	and	x10, x2, #0xffffffff
    d7e0:	9ac32426 	lsr	x6, x1, x3
    d7e4:	9ac32403 	lsr	x3, x0, x3
    d7e8:	aa070063 	orr	x3, x3, x7
    d7ec:	9ac908c1 	udiv	x1, x6, x9
    d7f0:	9ac82007 	lsl	x7, x0, x8
    d7f4:	9b099820 	msub	x0, x1, x9, x6
    d7f8:	9b017d41 	mul	x1, x10, x1
    d7fc:	93c38000 	extr	x0, x0, x3, #32
    d800:	eb00003f 	cmp	x1, x0
    d804:	540000a9 	b.ls	d818 <__modti3+0x318>  // b.plast
    d808:	ab000040 	adds	x0, x2, x0
    d80c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d810:	8b020006 	add	x6, x0, x2
    d814:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d818:	cb010000 	sub	x0, x0, x1
    d81c:	9ac90801 	udiv	x1, x0, x9
    d820:	9b098026 	msub	x6, x1, x9, x0
    d824:	aa0303e0 	mov	x0, x3
    d828:	9b017d41 	mul	x1, x10, x1
    d82c:	b3607cc0 	bfi	x0, x6, #32, #32
    d830:	eb00003f 	cmp	x1, x0
    d834:	540000a9 	b.ls	d848 <__modti3+0x348>  // b.plast
    d838:	ab000040 	adds	x0, x2, x0
    d83c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d840:	8b020003 	add	x3, x0, x2
    d844:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d848:	cb010000 	sub	x0, x0, x1
    d84c:	17ffffb0 	b	d70c <__modti3+0x20c>
    d850:	d1000969 	sub	x9, x11, #0x2
    d854:	8b070021 	add	x1, x1, x7
    d858:	17ffff83 	b	d664 <__modti3+0x164>
    d85c:	d1000965 	sub	x5, x11, #0x2
    d860:	8b070063 	add	x3, x3, x7
    d864:	17ffff74 	b	d634 <__modti3+0x134>
    d868:	d503201f 	nop
    d86c:	d503201f 	nop

000000000000d870 <atexit>:
    d870:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d874:	f0000082 	adrp	x2, 20000 <__data_start>
    d878:	d2800001 	mov	x1, #0x0                   	// #0
    d87c:	910003fd 	mov	x29, sp
    d880:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d884:	f9400442 	ldr	x2, [x2, #8]
    d888:	17ffd3a2 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d88c <_fini>:
    d88c:	d503201f 	nop
    d890:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d894:	910003fd 	mov	x29, sp
    d898:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d89c:	d65f03c0 	ret
