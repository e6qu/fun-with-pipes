
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x34c>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	9133a0a5 	add	x5, x5, #0xce8
    2a20:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x34c>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	9133c084 	add	x4, x4, #0xcf0
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	9400034c 	bl	3780 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91018261 	add	x1, x19, #0x60
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe188>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9006820 	str	x0, [x1, #208]
    2aac:	94000395 	bl	3900 <fwp_now_ns>
    2ab0:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x670>
    2ab4:	9108e000 	add	x0, x0, #0x238
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x19cc>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	9132d042 	add	x2, x2, #0xcb4
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91018273 	add	x19, x19, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943fa60 	ldr	w0, [x19, #1016]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff4c 	bl	2900 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x670>
    2bfc:	91092000 	add	x0, x0, #0x248
    2c00:	940002e0 	bl	3780 <fwp_trap>
    2c04:	97ffff03 	bl	2810 <__stack_chk_fail@plt>
    2c08:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x670>
    2c0c:	910ba000 	add	x0, x0, #0x2e8
    2c10:	940002dc 	bl	3780 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffeea 	bl	27c0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x670>
    2c24:	910b0000 	add	x0, x0, #0x2c0
    2c28:	940002d6 	bl	3780 <fwp_trap>
    2c2c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x670>
    2c30:	910a4000 	add	x0, x0, #0x290
    2c34:	940002d3 	bl	3780 <fwp_trap>
    2c38:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x670>
    2c3c:	9109a000 	add	x0, x0, #0x268
    2c40:	940002d0 	bl	3780 <fwp_trap>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x670>
    2e34:	91248021 	add	x1, x1, #0x920
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x670>
    30d8:	91240021 	add	x1, x1, #0x900
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    3110:	91266000 	add	x0, x0, #0x998
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    3144:	911982a1 	add	x1, x21, #0x660
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9a0>
    3158:	912940a5 	add	x5, x5, #0xa50
    315c:	911982a1 	add	x1, x21, #0x660
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911982b7 	add	x23, x21, #0x660
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911982b5 	add	x21, x21, #0x660
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911982b5 	add	x21, x21, #0x660
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9a0>
    32e8:	912920a5 	add	x5, x5, #0xa48
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x34c>
    331c:	9126c042 	add	x2, x2, #0x9b0
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x34c>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	91282042 	add	x2, x2, #0xa08
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	d0000059 	adrp	x25, d000 <fwp_main_thread+0x34c>
    33a8:	d000005a 	adrp	x26, d000 <fwp_main_thread+0x34c>
    33ac:	9129a339 	add	x25, x25, #0xa68
    33b0:	9127435a 	add	x26, x26, #0x9d0
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	d000005b 	adrp	x27, d000 <fwp_main_thread+0x34c>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	91276377 	add	x23, x27, #0x9d8
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	912aa000 	add	x0, x0, #0xaa8
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.9+0xfb80>
    3474:	b0000165 	adrp	x5, 30000 <alt.9+0xfb80>
    3478:	b0000162 	adrp	x2, 30000 <alt.9+0xfb80>
    347c:	d0000043 	adrp	x3, d000 <fwp_main_thread+0x34c>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	d0000055 	adrp	x21, d000 <fwp_main_thread+0x34c>
    3488:	f9424024 	ldr	x4, [x1, #1152]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94244a5 	ldr	x5, [x5, #1160]
    3494:	91120033 	add	x19, x1, #0x480
    3498:	f9424846 	ldr	x6, [x2, #1168]
    349c:	91274063 	add	x3, x3, #0x9d0
    34a0:	912b02b5 	add	x21, x21, #0xac0
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	912c0000 	add	x0, x0, #0xb00
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    352c:	91278000 	add	x0, x0, #0x9e0
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    35ec:	91266000 	add	x0, x0, #0x998
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x34c>
    3730:	aa1303e0 	mov	x0, x19
    3734:	912c2021 	add	x1, x1, #0xb08
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x34c>
    3744:	aa1303e0 	mov	x0, x19
    3748:	912c4021 	add	x1, x1, #0xb10
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x34c>
    3760:	912c6021 	add	x1, x1, #0xb18
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_trap>:
    3780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3784:	d53bd041 	mrs	x1, tpidr_el0
    3788:	91400021 	add	x1, x1, #0x0, lsl #12
    378c:	91004021 	add	x1, x1, #0x10
    3790:	910003fd 	mov	x29, sp
    3794:	a90153f3 	stp	x19, x20, [sp, #16]
    3798:	aa0003f3 	mov	x19, x0
    379c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    37a0:	f947ea94 	ldr	x20, [x20, #4048]
    37a4:	f90013f5 	str	x21, [sp, #32]
    37a8:	f9400035 	ldr	x21, [x1]
    37ac:	97fffe12 	bl	2ff4 <fwp_flush>
    37b0:	f9400280 	ldr	x0, [x20]
    37b4:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x34c>
    37b8:	aa1303e3 	mov	x3, x19
    37bc:	912c8042 	add	x2, x2, #0xb20
    37c0:	52800041 	mov	w1, #0x2                   	// #2
    37c4:	97fffc2f 	bl	2880 <__fprintf_chk@plt>
    37c8:	b40000b5 	cbz	x21, 37dc <fwp_trap+0x5c>
    37cc:	f9400280 	ldr	x0, [x20]
    37d0:	97fffc5c 	bl	2940 <fflush@plt>
    37d4:	52800ca0 	mov	w0, #0x65                  	// #101
    37d8:	97fffc6a 	bl	2980 <_Exit@plt>
    37dc:	52800ca0 	mov	w0, #0x65                  	// #101
    37e0:	97fffbb8 	bl	26c0 <exit@plt>

00000000000037e4 <fwp_closure_drop_push>:
    37e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    37e8:	910003fd 	mov	x29, sp
    37ec:	a90153f3 	stp	x19, x20, [sp, #16]
    37f0:	aa0003f3 	mov	x19, x0
    37f4:	a9408014 	ldp	x20, x0, [x0, #8]
    37f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    37fc:	aa0103f5 	mov	x21, x1
    3800:	a90363f7 	stp	x23, x24, [sp, #48]
    3804:	eb00029f 	cmp	x20, x0
    3808:	54000160 	b.eq	3834 <fwp_closure_drop_push+0x50>  // b.none
    380c:	f9400276 	ldr	x22, [x19]
    3810:	d37df297 	lsl	x23, x20, #3
    3814:	91000694 	add	x20, x20, #0x1
    3818:	f9000674 	str	x20, [x19, #8]
    381c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3820:	f8376ad5 	str	x21, [x22, x23]
    3824:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3828:	a94363f7 	ldp	x23, x24, [sp, #48]
    382c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3830:	d65f03c0 	ret
    3834:	a9046bf9 	stp	x25, x26, [sp, #64]
    3838:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    383c:	eb00029f 	cmp	x20, x0
    3840:	54000568 	b.hi	38ec <fwp_closure_drop_push+0x108>  // b.pmore
    3844:	d37cee99 	lsl	x25, x20, #4
    3848:	d37ffa9a 	lsl	x26, x20, #1
    384c:	aa1903e0 	mov	x0, x25
    3850:	97fffbd8 	bl	27b0 <malloc@plt>
    3854:	aa0003f6 	mov	x22, x0
    3858:	b4000320 	cbz	x0, 38bc <fwp_closure_drop_push+0xd8>
    385c:	aa1303f8 	mov	x24, x19
    3860:	aa1903e3 	mov	x3, x25
    3864:	d37df297 	lsl	x23, x20, #3
    3868:	aa1703e2 	mov	x2, x23
    386c:	f8418719 	ldr	x25, [x24], #24
    3870:	aa1903e1 	mov	x1, x25
    3874:	97fffbbb 	bl	2760 <__memcpy_chk@plt>
    3878:	eb18033f 	cmp	x25, x24
    387c:	540000a0 	b.eq	3890 <fwp_closure_drop_push+0xac>  // b.none
    3880:	aa1903e0 	mov	x0, x25
    3884:	97fffc13 	bl	28d0 <free@plt>
    3888:	f9400674 	ldr	x20, [x19, #8]
    388c:	d37df297 	lsl	x23, x20, #3
    3890:	91000694 	add	x20, x20, #0x1
    3894:	f9000276 	str	x22, [x19]
    3898:	f9000a7a 	str	x26, [x19, #16]
    389c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    38a0:	f9000674 	str	x20, [x19, #8]
    38a4:	f8376ad5 	str	x21, [x22, x23]
    38a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    38b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b8:	d65f03c0 	ret
    38bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    38c0:	f947e863 	ldr	x3, [x3, #4048]
    38c4:	d2800262 	mov	x2, #0x13                  	// #19
    38c8:	d2800021 	mov	x1, #0x1                   	// #1
    38cc:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    38d0:	91266000 	add	x0, x0, #0x998
    38d4:	f9400063 	ldr	x3, [x3]
    38d8:	97fffc0e 	bl	2910 <fwrite@plt>
    38dc:	d2800000 	mov	x0, #0x0                   	// #0
    38e0:	97fffc18 	bl	2940 <fflush@plt>
    38e4:	52800cc0 	mov	w0, #0x66                  	// #102
    38e8:	97fffc26 	bl	2980 <_Exit@plt>
    38ec:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    38f0:	912cc000 	add	x0, x0, #0xb30
    38f4:	97ffffa3 	bl	3780 <fwp_trap>
    38f8:	d503201f 	nop
    38fc:	d503201f 	nop

0000000000003900 <fwp_now_ns>:
    3900:	d100c3ff 	sub	sp, sp, #0x30
    3904:	52800020 	mov	w0, #0x1                   	// #1
    3908:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    390c:	f947f442 	ldr	x2, [x2, #4072]
    3910:	910023e1 	add	x1, sp, #0x8
    3914:	a9027bfd 	stp	x29, x30, [sp, #32]
    3918:	910083fd 	add	x29, sp, #0x20
    391c:	f9400043 	ldr	x3, [x2]
    3920:	f9000fe3 	str	x3, [sp, #24]
    3924:	d2800003 	mov	x3, #0x0                   	// #0
    3928:	97fffb86 	bl	2740 <clock_gettime@plt>
    392c:	350002c0 	cbnz	w0, 3984 <fwp_now_ns+0x84>
    3930:	a9408be1 	ldp	x1, x2, [sp, #8]
    3934:	d2994003 	mov	x3, #0xca00                	// #51712
    3938:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    393c:	9b037c20 	mul	x0, x1, x3
    3940:	9b437c21 	smulh	x1, x1, x3
    3944:	ab020000 	adds	x0, x0, x2
    3948:	937ffc42 	asr	x2, x2, #63
    394c:	9a020021 	adc	x1, x1, x2
    3950:	f100001f 	cmp	x0, #0x0
    3954:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3958:	b50001e1 	cbnz	x1, 3994 <fwp_now_ns+0x94>
    395c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3960:	f947f421 	ldr	x1, [x1, #4072]
    3964:	f9400fe3 	ldr	x3, [sp, #24]
    3968:	f9400022 	ldr	x2, [x1]
    396c:	eb020063 	subs	x3, x3, x2
    3970:	d2800002 	mov	x2, #0x0                   	// #0
    3974:	540000e1 	b.ne	3990 <fwp_now_ns+0x90>  // b.any
    3978:	a9427bfd 	ldp	x29, x30, [sp, #32]
    397c:	9100c3ff 	add	sp, sp, #0x30
    3980:	d65f03c0 	ret
    3984:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    3988:	912d4000 	add	x0, x0, #0xb50
    398c:	97ffff7d 	bl	3780 <fwp_trap>
    3990:	97fffba0 	bl	2810 <__stack_chk_fail@plt>
    3994:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    3998:	912dc000 	add	x0, x0, #0xb70
    399c:	97ffff79 	bl	3780 <fwp_trap>

00000000000039a0 <fwp_closure_drop.part.0>:
    39a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39a4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x670>
    39a8:	910003fd 	mov	x29, sp
    39ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    39b0:	f947f463 	ldr	x3, [x3, #4072]
    39b4:	a90153f3 	stp	x19, x20, [sp, #16]
    39b8:	d10883ff 	sub	sp, sp, #0x220
    39bc:	910003e2 	mov	x2, sp
    39c0:	d53bd053 	mrs	x19, tpidr_el0
    39c4:	910063f4 	add	x20, sp, #0x18
    39c8:	3dc24c20 	ldr	q0, [x1, #2352]
    39cc:	91400264 	add	x4, x19, #0x0, lsl #12
    39d0:	91004084 	add	x4, x4, #0x10
    39d4:	aa0003e1 	mov	x1, x0
    39d8:	aa0203e0 	mov	x0, x2
    39dc:	f9400062 	ldr	x2, [x3]
    39e0:	f9010fe2 	str	x2, [sp, #536]
    39e4:	d2800002 	mov	x2, #0x0                   	// #0
    39e8:	f90003f4 	str	x20, [sp]
    39ec:	f9000080 	str	x0, [x4]
    39f0:	3c8083e0 	stur	q0, [sp, #8]
    39f4:	97ffff7c 	bl	37e4 <fwp_closure_drop_push>
    39f8:	f94007e0 	ldr	x0, [sp, #8]
    39fc:	b4000280 	cbz	x0, 3a4c <fwp_closure_drop.part.0+0xac>
    3a00:	f90123f5 	str	x21, [sp, #576]
    3a04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a08:	910182b5 	add	x21, x21, #0x60
    3a0c:	d503201f 	nop
    3a10:	f94003e1 	ldr	x1, [sp]
    3a14:	d1000400 	sub	x0, x0, #0x1
    3a18:	f90007e0 	str	x0, [sp, #8]
    3a1c:	f9406aa2 	ldr	x2, [x21, #208]
    3a20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3a24:	b9400001 	ldr	w1, [x0]
    3a28:	8b011441 	add	x1, x2, x1, lsl #5
    3a2c:	f9400c21 	ldr	x1, [x1, #24]
    3a30:	b4000321 	cbz	x1, 3a94 <fwp_closure_drop.part.0+0xf4>
    3a34:	f9400422 	ldr	x2, [x1, #8]
    3a38:	52800001 	mov	w1, #0x0                   	// #0
    3a3c:	d63f0040 	blr	x2
    3a40:	f94007e0 	ldr	x0, [sp, #8]
    3a44:	b5fffe60 	cbnz	x0, 3a10 <fwp_closure_drop.part.0+0x70>
    3a48:	f94123f5 	ldr	x21, [sp, #576]
    3a4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3a50:	91004273 	add	x19, x19, #0x10
    3a54:	f94003e0 	ldr	x0, [sp]
    3a58:	f900027f 	str	xzr, [x19]
    3a5c:	eb14001f 	cmp	x0, x20
    3a60:	54000040 	b.eq	3a68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3a64:	97fffb9b 	bl	28d0 <free@plt>
    3a68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3a6c:	f947f400 	ldr	x0, [x0, #4072]
    3a70:	f9410fe2 	ldr	x2, [sp, #536]
    3a74:	f9400001 	ldr	x1, [x0]
    3a78:	eb010042 	subs	x2, x2, x1
    3a7c:	d2800001 	mov	x1, #0x0                   	// #0
    3a80:	54000101 	b.ne	3aa0 <fwp_closure_drop.part.0+0x100>  // b.any
    3a84:	910883ff 	add	sp, sp, #0x220
    3a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a90:	d65f03c0 	ret
    3a94:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    3a98:	912e6000 	add	x0, x0, #0xb98
    3a9c:	97ffff39 	bl	3780 <fwp_trap>
    3aa0:	f90123f5 	str	x21, [sp, #576]
    3aa4:	97fffb5b 	bl	2810 <__stack_chk_fail@plt>
    3aa8:	d503201f 	nop
    3aac:	d503201f 	nop

0000000000003ab0 <fwp_tape_of>:
    3ab0:	92403c02 	and	x2, x0, #0xffff
    3ab4:	b4000262 	cbz	x2, 3b00 <fwp_tape_of+0x50>
    3ab8:	b00000e3 	adrp	x3, 20000 <__data_start>
    3abc:	91018063 	add	x3, x3, #0x60
    3ac0:	9350fc01 	asr	x1, x0, #16
    3ac4:	d1000440 	sub	x0, x2, #0x1
    3ac8:	f9406c62 	ldr	x2, [x3, #216]
    3acc:	eb00005f 	cmp	x2, x0
    3ad0:	5400018d 	b.le	3b00 <fwp_tape_of+0x50>
    3ad4:	8b000402 	add	x2, x0, x0, lsl #1
    3ad8:	f9404463 	ldr	x3, [x3, #136]
    3adc:	8b020802 	add	x2, x0, x2, lsl #2
    3ae0:	d37df042 	lsl	x2, x2, #3
    3ae4:	8b020060 	add	x0, x3, x2
    3ae8:	b9400404 	ldr	w4, [x0, #4]
    3aec:	340000a4 	cbz	w4, 3b00 <fwp_tape_of+0x50>
    3af0:	b8626862 	ldr	w2, [x3, x2]
    3af4:	6b01005f 	cmp	w2, w1
    3af8:	54000041 	b.ne	3b00 <fwp_tape_of+0x50>  // b.any
    3afc:	d65f03c0 	ret
    3b00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b04:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    3b08:	912f2000 	add	x0, x0, #0xbc8
    3b0c:	910003fd 	mov	x29, sp
    3b10:	97ffff1c 	bl	3780 <fwp_trap>

0000000000003b14 <fwp_format_g.constprop.0>:
    3b14:	d10483ff 	sub	sp, sp, #0x120
    3b18:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x34c>
    3b1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    3b20:	f947f442 	ldr	x2, [x2, #4072]
    3b24:	91306084 	add	x4, x4, #0xc18
    3b28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3b2c:	9102c3fd 	add	x29, sp, #0xb0
    3b30:	d2800803 	mov	x3, #0x40                  	// #64
    3b34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3b38:	93407c38 	sxtw	x24, w1
    3b3c:	aa0303e1 	mov	x1, x3
    3b40:	fd008be8 	str	d8, [sp, #272]
    3b44:	1e604008 	fmov	d8, d0
    3b48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3b4c:	910083f4 	add	x20, sp, #0x20
    3b50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3b54:	aa0003f5 	mov	x21, x0
    3b58:	a91073fb 	stp	x27, x28, [sp, #256]
    3b5c:	5100071c 	sub	w28, w24, #0x1
    3b60:	2a1c03e5 	mov	w5, w28
    3b64:	f9400040 	ldr	x0, [x2]
    3b68:	f90057e0 	str	x0, [sp, #168]
    3b6c:	d2800000 	mov	x0, #0x0                   	// #0
    3b70:	52800042 	mov	w2, #0x2                   	// #2
    3b74:	aa1403e0 	mov	x0, x20
    3b78:	97fffb02 	bl	2780 <__snprintf_chk@plt>
    3b7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3b80:	aa1403e0 	mov	x0, x20
    3b84:	97fffb5b 	bl	28f0 <strchr@plt>
    3b88:	aa0003f3 	mov	x19, x0
    3b8c:	52800142 	mov	w2, #0xa                   	// #10
    3b90:	91000400 	add	x0, x0, #0x1
    3b94:	d2800001 	mov	x1, #0x0                   	// #0
    3b98:	97fffb46 	bl	28b0 <strtol@plt>
    3b9c:	aa0003f7 	mov	x23, x0
    3ba0:	11001400 	add	w0, w0, #0x5
    3ba4:	7100541f 	cmp	w0, #0x15
    3ba8:	54000d88 	b.hi	3d58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3bac:	4b170385 	sub	w5, w28, w23
    3bb0:	710000bf 	cmp	w5, #0x0
    3bb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3bb8:	54000ba0 	b.eq	3d2c <fwp_format_g.constprop.0+0x218>  // b.none
    3bbc:	394083e0 	ldrb	w0, [sp, #32]
    3bc0:	cb180273 	sub	x19, x19, x24
    3bc4:	91000673 	add	x19, x19, #0x1
    3bc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bcc:	7100b41f 	cmp	w0, #0x2d
    3bd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3bd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3bd8:	cb010266 	sub	x6, x19, x1
    3bdc:	d10004da 	sub	x26, x6, #0x1
    3be0:	540018c0 	b.eq	3ef8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d280091b 	mov	x27, #0x48                  	// #72
    3bec:	aa1903e7 	mov	x7, x25
    3bf0:	91000423 	add	x3, x1, #0x1
    3bf4:	91011cc6 	add	x6, x6, #0x47
    3bf8:	910004f6 	add	x22, x7, #0x1
    3bfc:	37f81017 	tbnz	w23, #31, 3dfc <fwp_format_g.constprop.0+0x2e8>
    3c00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c04:	93407ef7 	sxtw	x23, w23
    3c08:	390000e4 	strb	w4, [x7]
    3c0c:	aa1303e1 	mov	x1, x19
    3c10:	aa1703e2 	mov	x2, x23
    3c14:	aa1603e0 	mov	x0, x22
    3c18:	b9000be5 	str	w5, [sp, #8]
    3c1c:	cb170374 	sub	x20, x27, x23
    3c20:	a9011be3 	stp	x3, x6, [sp, #16]
    3c24:	97fffa8f 	bl	2660 <memcpy@plt>
    3c28:	d1000694 	sub	x20, x20, #0x1
    3c2c:	f9400be3 	ldr	x3, [sp, #16]
    3c30:	8b1702d6 	add	x22, x22, x23
    3c34:	aa1603e0 	mov	x0, x22
    3c38:	aa1a03e2 	mov	x2, x26
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	aa1403e3 	mov	x3, x20
    3c44:	97fffac7 	bl	2760 <__memcpy_chk@plt>
    3c48:	8b1a02d6 	add	x22, x22, x26
    3c4c:	f9400fe6 	ldr	x6, [sp, #24]
    3c50:	d2800900 	mov	x0, #0x48                  	// #72
    3c54:	b9400be5 	ldr	w5, [sp, #8]
    3c58:	8b170261 	add	x1, x19, x23
    3c5c:	cb1400c3 	sub	x3, x6, x20
    3c60:	cb060294 	sub	x20, x20, x6
    3c64:	f101207f 	cmp	x3, #0x48
    3c68:	93407cb8 	sxtw	x24, w5
    3c6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c70:	aa1803e2 	mov	x2, x24
    3c74:	8b1802d3 	add	x19, x22, x24
    3c78:	8b140063 	add	x3, x3, x20
    3c7c:	aa1603e0 	mov	x0, x22
    3c80:	97fffab8 	bl	2760 <__memcpy_chk@plt>
    3c84:	cb190273 	sub	x19, x19, x25
    3c88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3c8c:	eb00027f 	cmp	x19, x0
    3c90:	aa1903e1 	mov	x1, x25
    3c94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3c98:	aa1503e0 	mov	x0, x21
    3c9c:	aa1303e2 	mov	x2, x19
    3ca0:	97fffa70 	bl	2660 <memcpy@plt>
    3ca4:	38336abf 	strb	wzr, [x21, x19]
    3ca8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3cac:	aa1503e0 	mov	x0, x21
    3cb0:	97fffa7c 	bl	26a0 <strlen@plt>
    3cb4:	aa0003f3 	mov	x19, x0
    3cb8:	528005c1 	mov	w1, #0x2e                  	// #46
    3cbc:	aa1503e0 	mov	x0, x21
    3cc0:	97fffb0c 	bl	28f0 <strchr@plt>
    3cc4:	b4000160 	cbz	x0, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3cc8:	b4000153 	cbz	x19, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ccc:	d503201f 	nop
    3cd0:	aa1303e1 	mov	x1, x19
    3cd4:	d1000673 	sub	x19, x19, #0x1
    3cd8:	38736aa0 	ldrb	w0, [x21, x19]
    3cdc:	7100c01f 	cmp	w0, #0x30
    3ce0:	54001001 	b.ne	3ee0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ce4:	38336abf 	strb	wzr, [x21, x19]
    3ce8:	b5ffff53 	cbnz	x19, 3cd0 <fwp_format_g.constprop.0+0x1bc>
    3cec:	d503201f 	nop
    3cf0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3cf4:	f947f400 	ldr	x0, [x0, #4072]
    3cf8:	f94057e2 	ldr	x2, [sp, #168]
    3cfc:	f9400001 	ldr	x1, [x0]
    3d00:	eb010042 	subs	x2, x2, x1
    3d04:	d2800001 	mov	x1, #0x0                   	// #0
    3d08:	54001061 	b.ne	3f14 <fwp_format_g.constprop.0+0x400>  // b.any
    3d0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3d20:	fd408be8 	ldr	d8, [sp, #272]
    3d24:	910483ff 	add	sp, sp, #0x120
    3d28:	d65f03c0 	ret
    3d2c:	1e604100 	fmov	d0, d8
    3d30:	710000bf 	cmp	w5, #0x0
    3d34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3d38:	aa1503e0 	mov	x0, x21
    3d3c:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x34c>
    3d40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3d44:	9130c084 	add	x4, x4, #0xc30
    3d48:	52800042 	mov	w2, #0x2                   	// #2
    3d4c:	d2803201 	mov	x1, #0x190                 	// #400
    3d50:	97fffa8c 	bl	2780 <__snprintf_chk@plt>
    3d54:	17ffffd6 	b	3cac <fwp_format_g.constprop.0+0x198>
    3d58:	cb140273 	sub	x19, x19, x20
    3d5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d60:	910183f9 	add	x25, sp, #0x60
    3d64:	aa1303e2 	mov	x2, x19
    3d68:	aa1403e1 	mov	x1, x20
    3d6c:	aa1903e0 	mov	x0, x25
    3d70:	d2800803 	mov	x3, #0x40                  	// #64
    3d74:	97fffa7b 	bl	2760 <__memcpy_chk@plt>
    3d78:	38336b3f 	strb	wzr, [x25, x19]
    3d7c:	aa1903e0 	mov	x0, x25
    3d80:	528005c1 	mov	w1, #0x2e                  	// #46
    3d84:	97fffadb 	bl	28f0 <strchr@plt>
    3d88:	b40001c0 	cbz	x0, 3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d8c:	b50000b3 	cbnz	x19, 3da0 <fwp_format_g.constprop.0+0x28c>
    3d90:	1400000c 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d94:	381ff01f 	sturb	wzr, [x0, #-1]
    3d98:	f1000673 	subs	x19, x19, #0x1
    3d9c:	54000120 	b.eq	3dc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3da0:	8b130320 	add	x0, x25, x19
    3da4:	385ff001 	ldurb	w1, [x0, #-1]
    3da8:	7100c03f 	cmp	w1, #0x30
    3dac:	54ffff40 	b.eq	3d94 <fwp_format_g.constprop.0+0x280>  // b.none
    3db0:	d1000673 	sub	x19, x19, #0x1
    3db4:	38736b20 	ldrb	w0, [x25, x19]
    3db8:	7100b81f 	cmp	w0, #0x2e
    3dbc:	54000a80 	b.eq	3f0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3dc0:	710002ff 	cmp	w23, #0x0
    3dc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3dc8:	aa1903e5 	mov	x5, x25
    3dcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3dd0:	aa1503e0 	mov	x0, x21
    3dd4:	52800566 	mov	w6, #0x2b                  	// #43
    3dd8:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x34c>
    3ddc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3de0:	91308084 	add	x4, x4, #0xc20
    3de4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3de8:	52800042 	mov	w2, #0x2                   	// #2
    3dec:	d2803201 	mov	x1, #0x190                 	// #400
    3df0:	97fffa64 	bl	2780 <__snprintf_chk@plt>
    3df4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3df8:	17ffffbe 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3dfc:	52800605 	mov	w5, #0x30                  	// #48
    3e00:	390000e5 	strb	w5, [x7]
    3e04:	d100077b 	sub	x27, x27, #0x1
    3e08:	aa0303e1 	mov	x1, x3
    3e0c:	aa1603e0 	mov	x0, x22
    3e10:	aa1b03e3 	mov	x3, x27
    3e14:	aa1a03e2 	mov	x2, x26
    3e18:	f90007e6 	str	x6, [sp, #8]
    3e1c:	b90013e4 	str	w4, [sp, #16]
    3e20:	8b1a02d6 	add	x22, x22, x26
    3e24:	b9001be5 	str	w5, [sp, #24]
    3e28:	97fffa4e 	bl	2760 <__memcpy_chk@plt>
    3e2c:	f94007e6 	ldr	x6, [sp, #8]
    3e30:	2a3703e7 	mvn	w7, w23
    3e34:	b94013e4 	ldr	w4, [sp, #16]
    3e38:	cb1b00c1 	sub	x1, x6, x27
    3e3c:	cb06037b 	sub	x27, x27, x6
    3e40:	f101203f 	cmp	x1, #0x48
    3e44:	d2800906 	mov	x6, #0x48                  	// #72
    3e48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3e4c:	8b1b0023 	add	x3, x1, x27
    3e50:	310006ff 	cmn	w23, #0x1
    3e54:	54000220 	b.eq	3e98 <fwp_format_g.constprop.0+0x384>  // b.none
    3e58:	b9401be5 	ldr	w5, [sp, #24]
    3e5c:	d2800001 	mov	x1, #0x0                   	// #0
    3e60:	f101207f 	cmp	x3, #0x48
    3e64:	d1000462 	sub	x2, x3, #0x1
    3e68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3e6c:	38216ac5 	strb	w5, [x22, x1]
    3e70:	cb030003 	sub	x3, x0, x3
    3e74:	91000421 	add	x1, x1, #0x1
    3e78:	91000463 	add	x3, x3, #0x1
    3e7c:	eb00007f 	cmp	x3, x0
    3e80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3e84:	cb000063 	sub	x3, x3, x0
    3e88:	8b020063 	add	x3, x3, x2
    3e8c:	6b0100ff 	cmp	w7, w1
    3e90:	54fffe8c 	b.gt	3e60 <fwp_format_g.constprop.0+0x34c>
    3e94:	8b2742d6 	add	x22, x22, w7, uxtw
    3e98:	f101207f 	cmp	x3, #0x48
    3e9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ea0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ea4:	aa1603e0 	mov	x0, x22
    3ea8:	cb0300a1 	sub	x1, x5, x3
    3eac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3eb0:	91000421 	add	x1, x1, #0x1
    3eb4:	d1000463 	sub	x3, x3, #0x1
    3eb8:	eb05003f 	cmp	x1, x5
    3ebc:	38001402 	strb	w2, [x0], #1
    3ec0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3ec4:	93407f82 	sxtw	x2, w28
    3ec8:	cb050025 	sub	x5, x1, x5
    3ecc:	aa1303e1 	mov	x1, x19
    3ed0:	8b0300a3 	add	x3, x5, x3
    3ed4:	8b1802d3 	add	x19, x22, x24
    3ed8:	97fffa22 	bl	2760 <__memcpy_chk@plt>
    3edc:	17ffff6a 	b	3c84 <fwp_format_g.constprop.0+0x170>
    3ee0:	d1000421 	sub	x1, x1, #0x1
    3ee4:	38616aa0 	ldrb	w0, [x21, x1]
    3ee8:	7100b81f 	cmp	w0, #0x2e
    3eec:	54fff021 	b.ne	3cf0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ef0:	38216abf 	strb	wzr, [x21, x1]
    3ef4:	17ffff7f 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ef8:	910187e7 	add	x7, sp, #0x61
    3efc:	910183f9 	add	x25, sp, #0x60
    3f00:	d28008fb 	mov	x27, #0x47                  	// #71
    3f04:	390183e0 	strb	w0, [sp, #96]
    3f08:	17ffff3a 	b	3bf0 <fwp_format_g.constprop.0+0xdc>
    3f0c:	38336b3f 	strb	wzr, [x25, x19]
    3f10:	17ffffac 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3f14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f18:	97fffa3e 	bl	2810 <__stack_chk_fail@plt>
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_heap_report>:
    3f20:	d105c3ff 	sub	sp, sp, #0x170
    3f24:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xb80>
    3f28:	91198042 	add	x2, x2, #0x660
    3f2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3f30:	f947e821 	ldr	x1, [x1, #4048]
    3f34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3f38:	910443fd 	add	x29, sp, #0x110
    3f3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3f40:	f947f400 	ldr	x0, [x0, #4072]
    3f44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3f48:	a91463f7 	stp	x23, x24, [sp, #320]
    3f4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3f50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3f54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3f58:	fd4a2049 	ldr	d9, [x2, #5184]
    3f5c:	f9400036 	ldr	x22, [x1]
    3f60:	f9400001 	ldr	x1, [x0]
    3f64:	f90087e1 	str	x1, [sp, #264]
    3f68:	d2800001 	mov	x1, #0x0                   	// #0
    3f6c:	f949e459 	ldr	x25, [x2, #5064]
    3f70:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x34c>
    3f74:	f94a1057 	ldr	x23, [x2, #5152]
    3f78:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    3f7c:	f94a1458 	ldr	x24, [x2, #5160]
    3f80:	9130e021 	add	x1, x1, #0xc38
    3f84:	91310000 	add	x0, x0, #0xc40
    3f88:	97fffa06 	bl	27a0 <fopen@plt>
    3f8c:	b4000740 	cbz	x0, 4074 <fwp_heap_report+0x154>
    3f90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3f94:	a91253f3 	stp	x19, x20, [sp, #288]
    3f98:	aa0003f4 	mov	x20, x0
    3f9c:	910023f3 	add	x19, sp, #0x8
    3fa0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3fa4:	72aae915 	movk	w21, #0x5748, lsl #16
    3fa8:	aa1403e2 	mov	x2, x20
    3fac:	aa1303e0 	mov	x0, x19
    3fb0:	52802001 	mov	w1, #0x100                 	// #256
    3fb4:	97fffa83 	bl	29c0 <fgets@plt>
    3fb8:	b4000280 	cbz	x0, 4008 <fwp_heap_report+0xe8>
    3fbc:	b9400261 	ldr	w1, [x19]
    3fc0:	6b15003f 	cmp	w1, w21
    3fc4:	54ffff21 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fc8:	39401260 	ldrb	w0, [x19, #4]
    3fcc:	7101341f 	cmp	w0, #0x4d
    3fd0:	54fffec1 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fd4:	394037e0 	ldrb	w0, [sp, #13]
    3fd8:	7100e81f 	cmp	w0, #0x3a
    3fdc:	54fffe61 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fe0:	52800142 	mov	w2, #0xa                   	// #10
    3fe4:	d2800001 	mov	x1, #0x0                   	// #0
    3fe8:	91003be0 	add	x0, sp, #0xe
    3fec:	97fffa31 	bl	28b0 <strtol@plt>
    3ff0:	aa1403e2 	mov	x2, x20
    3ff4:	aa0003fa 	mov	x26, x0
    3ff8:	52802001 	mov	w1, #0x100                 	// #256
    3ffc:	aa1303e0 	mov	x0, x19
    4000:	97fffa70 	bl	29c0 <fgets@plt>
    4004:	b5fffdc0 	cbnz	x0, 3fbc <fwp_heap_report+0x9c>
    4008:	aa1403e0 	mov	x0, x20
    400c:	97fff9e1 	bl	2790 <fclose@plt>
    4010:	a95253f3 	ldp	x19, x20, [sp, #288]
    4014:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4018:	f947f400 	ldr	x0, [x0, #4072]
    401c:	f94087e2 	ldr	x2, [sp, #264]
    4020:	f9400001 	ldr	x1, [x0]
    4024:	eb010042 	subs	x2, x2, x1
    4028:	d2800001 	mov	x1, #0x0                   	// #0
    402c:	54000281 	b.ne	407c <fwp_heap_report+0x15c>  // b.any
    4030:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4034:	aa1a03e6 	mov	x6, x26
    4038:	aa1903e5 	mov	x5, x25
    403c:	aa1803e4 	mov	x4, x24
    4040:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4044:	aa1703e3 	mov	x3, x23
    4048:	a95463f7 	ldp	x23, x24, [sp, #320]
    404c:	aa1603e0 	mov	x0, x22
    4050:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4054:	1e604121 	fmov	d1, d9
    4058:	1e604100 	fmov	d0, d8
    405c:	b0000042 	adrp	x2, d000 <fwp_main_thread+0x34c>
    4060:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4064:	91318042 	add	x2, x2, #0xc60
    4068:	9105c3ff 	add	sp, sp, #0x170
    406c:	52800041 	mov	w1, #0x2                   	// #2
    4070:	17fffa04 	b	2880 <__fprintf_chk@plt>
    4074:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4078:	17ffffe7 	b	4014 <fwp_heap_report+0xf4>
    407c:	a91253f3 	stp	x19, x20, [sp, #288]
    4080:	97fff9e4 	bl	2810 <__stack_chk_fail@plt>

0000000000004084 <fwp_heap_init>:
    4084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4088:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9a0>
    408c:	91158061 	add	x1, x3, #0x560
    4090:	910003fd 	mov	x29, sp
    4094:	a90153f3 	stp	x19, x20, [sp, #16]
    4098:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xb80>
    409c:	91198262 	add	x2, x19, #0x660
    40a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a4:	52800024 	mov	w4, #0x1                   	// #1
    40a8:	52800200 	mov	w0, #0x10                  	// #16
    40ac:	b913a444 	str	w4, [x2, #5028]
    40b0:	b8004420 	str	w0, [x1], #4
    40b4:	11004000 	add	w0, w0, #0x10
    40b8:	7104401f 	cmp	w0, #0x110
    40bc:	54ffffa1 	b.ne	40b0 <fwp_heap_init+0x2c>  // b.any
    40c0:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0x670>
    40c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    40c8:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9a0>
    40cc:	91168021 	add	x1, x1, #0x5a0
    40d0:	3dc25043 	ldr	q3, [x2, #2368]
    40d4:	d2800000 	mov	x0, #0x0                   	// #0
    40d8:	4e040401 	dup	v1.4s, v0.s[0]
    40dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    40e0:	0f215400 	shl	v0.2s, v0.2s, #1
    40e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    40e8:	3ca06821 	str	q1, [x1, x0]
    40ec:	91004000 	add	x0, x0, #0x10
    40f0:	f101801f 	cmp	x0, #0x60
    40f4:	54ffff21 	b.ne	40d8 <fwp_heap_init+0x54>  // b.any
    40f8:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9a0>
    40fc:	91158063 	add	x3, x3, #0x560
    4100:	91180084 	add	x4, x4, #0x600
    4104:	91198266 	add	x6, x19, #0x660
    4108:	d2800002 	mov	x2, #0x0                   	// #0
    410c:	d2800000 	mov	x0, #0x0                   	// #0
    4110:	d2880205 	mov	x5, #0x4010                	// #16400
    4114:	d503201f 	nop
    4118:	910f0001 	add	x1, x0, #0x3c0
    411c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4120:	eb02003f 	cmp	x1, x2
    4124:	540000a2 	b.cs	4138 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4128:	91000400 	add	x0, x0, #0x1
    412c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4130:	eb02003f 	cmp	x1, x2
    4134:	54ffffa3 	b.cc	4128 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4138:	91004042 	add	x2, x2, #0x10
    413c:	38001480 	strb	w0, [x4], #1
    4140:	eb05005f 	cmp	x2, x5
    4144:	54fffea1 	b.ne	4118 <fwp_heap_init+0x94>  // b.any
    4148:	528000b5 	mov	w21, #0x5                   	// #5
    414c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4150:	14000004 	b	4160 <fwp_heap_init+0xdc>
    4154:	d342fe94 	lsr	x20, x20, #2
    4158:	710006b5 	subs	w21, w21, #0x1
    415c:	54000720 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    4160:	91404296 	add	x22, x20, #0x10, lsl #12
    4164:	d2800005 	mov	x5, #0x0                   	// #0
    4168:	aa1603e1 	mov	x1, x22
    416c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4170:	52880443 	mov	w3, #0x4022                	// #16418
    4174:	52800002 	mov	w2, #0x0                   	// #0
    4178:	d2800000 	mov	x0, #0x0                   	// #0
    417c:	97fff9c9 	bl	28a0 <mmap@plt>
    4180:	aa0003e6 	mov	x6, x0
    4184:	b100041f 	cmn	x0, #0x1
    4188:	54fffe60 	b.eq	4154 <fwp_heap_init+0xd0>  // b.none
    418c:	b40005a0 	cbz	x0, 4240 <fwp_heap_init+0x1bc>
    4190:	d350fe94 	lsr	x20, x20, #16
    4194:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4198:	8b0000c7 	add	x7, x6, x0
    419c:	91198275 	add	x21, x19, #0x660
    41a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    41a4:	8b140a81 	add	x1, x20, x20, lsl #2
    41a8:	d2800005 	mov	x5, #0x0                   	// #0
    41ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    41b0:	d37df021 	lsl	x1, x1, #3
    41b4:	52880443 	mov	w3, #0x4022                	// #16418
    41b8:	52800002 	mov	w2, #0x0                   	// #0
    41bc:	d2800000 	mov	x0, #0x0                   	// #0
    41c0:	f909daa7 	str	x7, [x21, #5040]
    41c4:	f909dea6 	str	x6, [x21, #5048]
    41c8:	f909e2b6 	str	x22, [x21, #5056]
    41cc:	f909eab4 	str	x20, [x21, #5072]
    41d0:	f90a02a1 	str	x1, [x21, #5120]
    41d4:	97fff9b3 	bl	28a0 <mmap@plt>
    41d8:	aa0003e1 	mov	x1, x0
    41dc:	b100041f 	cmn	x0, #0x1
    41e0:	54000300 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    41e4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    41e8:	91344000 	add	x0, x0, #0xd10
    41ec:	f909fea1 	str	x1, [x21, #5112]
    41f0:	97fff9ec 	bl	29a0 <getenv@plt>
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	aa0003e1 	mov	x1, x0
    41fc:	b40000e0 	cbz	x0, 4218 <fwp_heap_init+0x194>
    4200:	39400000 	ldrb	w0, [x0]
    4204:	340000a0 	cbz	w0, 4218 <fwp_heap_init+0x194>
    4208:	7100c000 	subs	w0, w0, #0x30
    420c:	54000120 	b.eq	4230 <fwp_heap_init+0x1ac>  // b.none
    4210:	7100001f 	cmp	w0, #0x0
    4214:	1a9f07e2 	cset	w2, ne	// ne = any
    4218:	91198273 	add	x19, x19, #0x660
    421c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4220:	b913aa62 	str	w2, [x19, #5032]
    4224:	a94153f3 	ldp	x19, x20, [sp, #16]
    4228:	a8c37bfd 	ldp	x29, x30, [sp], #48
    422c:	d65f03c0 	ret
    4230:	39400420 	ldrb	w0, [x1, #1]
    4234:	7100001f 	cmp	w0, #0x0
    4238:	1a9f07e2 	cset	w2, ne	// ne = any
    423c:	17fffff7 	b	4218 <fwp_heap_init+0x194>
    4240:	97fffbac 	bl	30f0 <fwp_heap_oom>

0000000000004244 <caf61>:
    4244:	900000e2 	adrp	x2, 20000 <__data_start>
    4248:	91018041 	add	x1, x2, #0x60
    424c:	b940e020 	ldr	w0, [x1, #224]
    4250:	34000060 	cbz	w0, 425c <caf61+0x18>
    4254:	f9407420 	ldr	x0, [x1, #232]
    4258:	d65f03c0 	ret
    425c:	b940f020 	ldr	w0, [x1, #240]
    4260:	340000e0 	cbz	w0, 427c <caf61+0x38>
    4264:	f9407c20 	ldr	x0, [x1, #248]
    4268:	91018042 	add	x2, x2, #0x60
    426c:	52800021 	mov	w1, #0x1                   	// #1
    4270:	b900e041 	str	w1, [x2, #224]
    4274:	f9007440 	str	x0, [x2, #232]
    4278:	d65f03c0 	ret
    427c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4280:	52800024 	mov	w4, #0x1                   	// #1
    4284:	aa0303e0 	mov	x0, x3
    4288:	b900f024 	str	w4, [x1, #240]
    428c:	f9007c23 	str	x3, [x1, #248]
    4290:	17fffff6 	b	4268 <caf61+0x24>

0000000000004294 <fwp_wake_io>:
    4294:	900000e9 	adrp	x9, 20000 <__data_start>
    4298:	91018122 	add	x2, x9, #0x60
    429c:	f9400001 	ldr	x1, [x0]
    42a0:	5280000a 	mov	w10, #0x0                   	// #0
    42a4:	f9406046 	ldr	x6, [x2, #192]
    42a8:	52800008 	mov	w8, #0x0                   	// #0
    42ac:	4f000400 	movi	v0.4s, #0x0
    42b0:	52800027 	mov	w7, #0x1                   	// #1
    42b4:	aa0103e2 	mov	x2, x1
    42b8:	b4000321 	cbz	x1, 431c <fwp_wake_io+0x88>
    42bc:	f9408c25 	ldr	x5, [x1, #280]
    42c0:	39015c27 	strb	w7, [x1, #87]
    42c4:	b4000165 	cbz	x5, 42f0 <fwp_wake_io+0x5c>
    42c8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42cc:	b4000364 	cbz	x4, 4338 <fwp_wake_io+0xa4>
    42d0:	f9009483 	str	x3, [x4, #296]
    42d4:	f9409423 	ldr	x3, [x1, #296]
    42d8:	b4000043 	cbz	x3, 42e0 <fwp_wake_io+0x4c>
    42dc:	f9009064 	str	x4, [x3, #288]
    42e0:	91080023 	add	x3, x1, #0x200
    42e4:	f900943f 	str	xzr, [x1, #296]
    42e8:	3c918060 	stur	q0, [x3, #-232]
    42ec:	f9400001 	ldr	x1, [x0]
    42f0:	f9402843 	ldr	x3, [x2, #80]
    42f4:	f2001c7f 	tst	x3, #0xff000000ff
    42f8:	54fffde1 	b.ne	42b4 <fwp_wake_io+0x20>  // b.any
    42fc:	39015047 	strb	w7, [x2, #84]
    4300:	f900805f 	str	xzr, [x2, #256]
    4304:	b40001e6 	cbz	x6, 4340 <fwp_wake_io+0xac>
    4308:	f90080c2 	str	x2, [x6, #256]
    430c:	aa0203e6 	mov	x6, x2
    4310:	52800028 	mov	w8, #0x1                   	// #1
    4314:	aa0103e2 	mov	x2, x1
    4318:	b5fffd21 	cbnz	x1, 42bc <fwp_wake_io+0x28>
    431c:	3400006a 	cbz	w10, 4328 <fwp_wake_io+0x94>
    4320:	91018120 	add	x0, x9, #0x60
    4324:	f900640b 	str	x11, [x0, #200]
    4328:	34000068 	cbz	w8, 4334 <fwp_wake_io+0xa0>
    432c:	91018129 	add	x9, x9, #0x60
    4330:	f9006126 	str	x6, [x9, #192]
    4334:	d65f03c0 	ret
    4338:	f90000a3 	str	x3, [x5]
    433c:	17ffffe7 	b	42d8 <fwp_wake_io+0x44>
    4340:	aa0203eb 	mov	x11, x2
    4344:	5280002a 	mov	w10, #0x1                   	// #1
    4348:	17fffff1 	b	430c <fwp_wake_io+0x78>
    434c:	d503201f 	nop

0000000000004350 <ad_raw_free.part.0>:
    4350:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fb80>
    4354:	d2800001 	mov	x1, #0x0                   	// #0
    4358:	91120082 	add	x2, x4, #0x480
    435c:	14000005 	b	4370 <ad_raw_free.part.0+0x20>
    4360:	91000421 	add	x1, x1, #0x1
    4364:	91006042 	add	x2, x2, #0x18
    4368:	f140043f 	cmp	x1, #0x1, lsl #12
    436c:	54000220 	b.eq	43b0 <ad_raw_free.part.0+0x60>  // b.none
    4370:	f9400043 	ldr	x3, [x2]
    4374:	eb03001f 	cmp	x0, x3
    4378:	54ffff41 	b.ne	4360 <ad_raw_free.part.0+0x10>  // b.any
    437c:	8b010421 	add	x1, x1, x1, lsl #1
    4380:	91120084 	add	x4, x4, #0x480
    4384:	900000e2 	adrp	x2, 20000 <__data_start>
    4388:	91018042 	add	x2, x2, #0x60
    438c:	8b010c81 	add	x1, x4, x1, lsl #3
    4390:	b9401024 	ldr	w4, [x1, #16]
    4394:	f9400425 	ldr	x5, [x1, #8]
    4398:	a9007c3f 	stp	xzr, xzr, [x1]
    439c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    43a0:	f900083f 	str	xzr, [x1, #16]
    43a4:	cb050061 	sub	x1, x3, x5
    43a8:	f8247841 	str	x1, [x2, x4, lsl #3]
    43ac:	17fff949 	b	28d0 <free@plt>
    43b0:	f100001f 	cmp	x0, #0x0
    43b4:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x34c>
    43b8:	9134e021 	add	x1, x1, #0xd38
    43bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    43c0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    43c4:	91348000 	add	x0, x0, #0xd20
    43c8:	910003fd 	mov	x29, sp
    43cc:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    43d0:	97fffbcc 	bl	3300 <ad_raw_fail>

00000000000043d4 <fwp_tape_buffers_dispose>:
    43d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	f9000bf3 	str	x19, [sp, #16]
    43e0:	aa0003f3 	mov	x19, x0
    43e4:	f9400000 	ldr	x0, [x0]
    43e8:	b4000040 	cbz	x0, 43f0 <fwp_tape_buffers_dispose+0x1c>
    43ec:	97ffffd9 	bl	4350 <ad_raw_free.part.0>
    43f0:	f9400a60 	ldr	x0, [x19, #16]
    43f4:	b4000040 	cbz	x0, 43fc <fwp_tape_buffers_dispose+0x28>
    43f8:	97ffffd6 	bl	4350 <ad_raw_free.part.0>
    43fc:	f9401260 	ldr	x0, [x19, #32]
    4400:	b4000040 	cbz	x0, 4408 <fwp_tape_buffers_dispose+0x34>
    4404:	97ffffd3 	bl	4350 <ad_raw_free.part.0>
    4408:	4f000400 	movi	v0.4s, #0x0
    440c:	f9001a7f 	str	xzr, [x19, #48]
    4410:	ad000260 	stp	q0, q0, [x19]
    4414:	3d800a60 	str	q0, [x19, #32]
    4418:	f9400bf3 	ldr	x19, [sp, #16]
    441c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4420:	d65f03c0 	ret

0000000000004424 <ad_raw_realloc>:
    4424:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4428:	910003fd 	mov	x29, sp
    442c:	a90153f3 	stp	x19, x20, [sp, #16]
    4430:	f90013f5 	str	x21, [sp, #32]
    4434:	b40005a1 	cbz	x1, 44e8 <ad_raw_realloc+0xc4>
    4438:	aa0103f4 	mov	x20, x1
    443c:	2a0203f5 	mov	w21, w2
    4440:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fb80>
    4444:	d2800004 	mov	x4, #0x0                   	// #0
    4448:	91120025 	add	x5, x1, #0x480
    444c:	14000005 	b	4460 <ad_raw_realloc+0x3c>
    4450:	91000484 	add	x4, x4, #0x1
    4454:	910060a5 	add	x5, x5, #0x18
    4458:	f140049f 	cmp	x4, #0x1, lsl #12
    445c:	54000320 	b.eq	44c0 <ad_raw_realloc+0x9c>  // b.none
    4460:	f94000a6 	ldr	x6, [x5]
    4464:	eb06001f 	cmp	x0, x6
    4468:	54ffff41 	b.ne	4450 <ad_raw_realloc+0x2c>  // b.any
    446c:	8b040484 	add	x4, x4, x4, lsl #1
    4470:	91120021 	add	x1, x1, #0x480
    4474:	8b040c33 	add	x19, x1, x4, lsl #3
    4478:	b4000080 	cbz	x0, 4488 <ad_raw_realloc+0x64>
    447c:	b9401261 	ldr	w1, [x19, #16]
    4480:	6b15003f 	cmp	w1, w21
    4484:	540002c1 	b.ne	44dc <ad_raw_realloc+0xb8>  // b.any
    4488:	aa1403e1 	mov	x1, x20
    448c:	97fff8dd 	bl	2800 <realloc@plt>
    4490:	aa0003ed 	mov	x13, x0
    4494:	b40000c0 	cbz	x0, 44ac <ad_raw_realloc+0x88>
    4498:	2a1503e3 	mov	w3, w21
    449c:	aa1403e2 	mov	x2, x20
    44a0:	aa1303e0 	mov	x0, x19
    44a4:	aa0d03e1 	mov	x1, x13
    44a8:	97fffa9a 	bl	2f10 <ad_raw_record>
    44ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b0:	aa0d03e0 	mov	x0, x13
    44b4:	f94013f5 	ldr	x21, [sp, #32]
    44b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44bc:	d65f03c0 	ret
    44c0:	f100001f 	cmp	x0, #0x0
    44c4:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x34c>
    44c8:	9134e021 	add	x1, x1, #0xd38
    44cc:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    44d0:	91348000 	add	x0, x0, #0xd20
    44d4:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    44d8:	97fffb8a 	bl	3300 <ad_raw_fail>
    44dc:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    44e0:	9135e000 	add	x0, x0, #0xd78
    44e4:	97fffb87 	bl	3300 <ad_raw_fail>
    44e8:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    44ec:	91356000 	add	x0, x0, #0xd58
    44f0:	97fffb84 	bl	3300 <ad_raw_fail>

00000000000044f4 <fwp_tape_buffers_release>:
    44f4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44f8:	910003fd 	mov	x29, sp
    44fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4500:	aa0003f4 	mov	x20, x0
    4504:	f9401400 	ldr	x0, [x0, #40]
    4508:	a9025bf5 	stp	x21, x22, [sp, #32]
    450c:	b7f80560 	tbnz	x0, #63, 45b8 <fwp_tape_buffers_release+0xc4>
    4510:	f9401a93 	ldr	x19, [x20, #48]
    4514:	b7f80533 	tbnz	x19, #63, 45b8 <fwp_tape_buffers_release+0xc4>
    4518:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    451c:	eb01001f 	cmp	x0, x1
    4520:	540004c8 	b.hi	45b8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4524:	8b000400 	add	x0, x0, x0, lsl #1
    4528:	d2a00101 	mov	x1, #0x80000               	// #524288
    452c:	d37df000 	lsl	x0, x0, #3
    4530:	cb000021 	sub	x1, x1, x0
    4534:	eb410e7f 	cmp	x19, x1, lsr #3
    4538:	54000408 	b.hi	45b8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    453c:	8b130c13 	add	x19, x0, x19, lsl #3
    4540:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    4544:	91364000 	add	x0, x0, #0xd90
    4548:	97fff916 	bl	29a0 <getenv@plt>
    454c:	b4000080 	cbz	x0, 455c <fwp_tape_buffers_release+0x68>
    4550:	39400001 	ldrb	w1, [x0]
    4554:	7100c03f 	cmp	w1, #0x30
    4558:	54000880 	b.eq	4668 <fwp_tape_buffers_release+0x174>  // b.none
    455c:	d1000661 	sub	x1, x19, #0x1
    4560:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4564:	eb00003f 	cmp	x1, x0
    4568:	54000328 	b.hi	45cc <fwp_tape_buffers_release+0xd8>  // b.pmore
    456c:	900000f5 	adrp	x21, 20000 <__data_start>
    4570:	f9001bf7 	str	x23, [sp, #48]
    4574:	910182b7 	add	x23, x21, #0x60
    4578:	910402f6 	add	x22, x23, #0x100
    457c:	aa1603e0 	mov	x0, x22
    4580:	97ffff95 	bl	43d4 <fwp_tape_buffers_dispose>
    4584:	ad400a81 	ldp	q1, q2, [x20]
    4588:	f9009ef3 	str	x19, [x23, #312]
    458c:	4f000400 	movi	v0.4s, #0x0
    4590:	ad000ac1 	stp	q1, q2, [x22]
    4594:	3dc00a81 	ldr	q1, [x20, #32]
    4598:	3d800ac1 	str	q1, [x22, #32]
    459c:	f9401a80 	ldr	x0, [x20, #48]
    45a0:	f9001ac0 	str	x0, [x22, #48]
    45a4:	f9001a9f 	str	xzr, [x20, #48]
    45a8:	ad000280 	stp	q0, q0, [x20]
    45ac:	3d800a80 	str	q0, [x20, #32]
    45b0:	f9401bf7 	ldr	x23, [sp, #48]
    45b4:	1400000b 	b	45e0 <fwp_tape_buffers_release+0xec>
    45b8:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    45bc:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    45c0:	91364000 	add	x0, x0, #0xd90
    45c4:	97fff8f7 	bl	29a0 <getenv@plt>
    45c8:	b5fffc40 	cbnz	x0, 4550 <fwp_tape_buffers_release+0x5c>
    45cc:	aa1403e0 	mov	x0, x20
    45d0:	97ffff81 	bl	43d4 <fwp_tape_buffers_dispose>
    45d4:	900000f5 	adrp	x21, 20000 <__data_start>
    45d8:	910182a0 	add	x0, x21, #0x60
    45dc:	f9409c13 	ldr	x19, [x0, #312]
    45e0:	910182a2 	add	x2, x21, #0x60
    45e4:	f940a044 	ldr	x4, [x2, #320]
    45e8:	a9400c45 	ldp	x5, x3, [x2]
    45ec:	8b040481 	add	x1, x4, x4, lsl #1
    45f0:	f9400840 	ldr	x0, [x2, #16]
    45f4:	8b010881 	add	x1, x4, x1, lsl #2
    45f8:	f9400c44 	ldr	x4, [x2, #24]
    45fc:	8b0300a3 	add	x3, x5, x3
    4600:	d37df021 	lsl	x1, x1, #3
    4604:	8b040000 	add	x0, x0, x4
    4608:	8b030000 	add	x0, x0, x3
    460c:	eb05003f 	cmp	x1, x5
    4610:	54000321 	b.ne	4674 <fwp_tape_buffers_release+0x180>  // b.any
    4614:	8b130023 	add	x3, x1, x19
    4618:	eb00007f 	cmp	x3, x0
    461c:	540002c8 	b.hi	4674 <fwp_tape_buffers_release+0x180>  // b.pmore
    4620:	f9405c43 	ldr	x3, [x2, #184]
    4624:	f140087f 	cmp	x3, #0x2, lsl #12
    4628:	540002e0 	b.eq	4684 <fwp_tape_buffers_release+0x190>  // b.none
    462c:	8b030464 	add	x4, x3, x3, lsl #1
    4630:	90000165 	adrp	x5, 30000 <alt.9+0xfb80>
    4634:	911200a5 	add	x5, x5, #0x480
    4638:	cb010000 	sub	x0, x0, x1
    463c:	d37df084 	lsl	x4, x4, #3
    4640:	cb130000 	sub	x0, x0, x19
    4644:	8b0400a6 	add	x6, x5, x4
    4648:	91000463 	add	x3, x3, #0x1
    464c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4650:	f82468a1 	str	x1, [x5, x4]
    4654:	a90080d3 	stp	x19, x0, [x6, #8]
    4658:	f9005c43 	str	x3, [x2, #184]
    465c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4660:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4664:	d65f03c0 	ret
    4668:	39400400 	ldrb	w0, [x0, #1]
    466c:	34fffb00 	cbz	w0, 45cc <fwp_tape_buffers_release+0xd8>
    4670:	17ffffbb 	b	455c <fwp_tape_buffers_release+0x68>
    4674:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    4678:	9136a000 	add	x0, x0, #0xda8
    467c:	f9001bf7 	str	x23, [sp, #48]
    4680:	97fffb20 	bl	3300 <ad_raw_fail>
    4684:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    4688:	91376000 	add	x0, x0, #0xdd8
    468c:	f9001bf7 	str	x23, [sp, #48]
    4690:	97fffb1c 	bl	3300 <ad_raw_fail>

0000000000004694 <fwp_poll_events>:
    4694:	d10103ff 	sub	sp, sp, #0x40
    4698:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    469c:	f947f400 	ldr	x0, [x0, #4072]
    46a0:	a9027bfd 	stp	x29, x30, [sp, #32]
    46a4:	910083fd 	add	x29, sp, #0x20
    46a8:	a90353f3 	stp	x19, x20, [sp, #48]
    46ac:	900000f4 	adrp	x20, 20000 <__data_start>
    46b0:	f9400001 	ldr	x1, [x0]
    46b4:	f9000fe1 	str	x1, [sp, #24]
    46b8:	d2800001 	mov	x1, #0x0                   	// #0
    46bc:	97fffc91 	bl	3900 <fwp_now_ns>
    46c0:	91018281 	add	x1, x20, #0x60
    46c4:	f940a433 	ldr	x19, [x1, #328]
    46c8:	b4000e73 	cbz	x19, 4894 <fwp_poll_events+0x200>
    46cc:	aa1303e1 	mov	x1, x19
    46d0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    46d4:	14000005 	b	46e8 <fwp_poll_events+0x54>
    46d8:	f9408821 	ldr	x1, [x1, #272]
    46dc:	eb03005f 	cmp	x2, x3
    46e0:	9a83d042 	csel	x2, x2, x3, le
    46e4:	b40000c1 	cbz	x1, 46fc <fwp_poll_events+0x68>
    46e8:	f9403423 	ldr	x3, [x1, #104]
    46ec:	b6ffff62 	tbz	x2, #63, 46d8 <fwp_poll_events+0x44>
    46f0:	f9408821 	ldr	x1, [x1, #272]
    46f4:	aa0303e2 	mov	x2, x3
    46f8:	b5ffff81 	cbnz	x1, 46e8 <fwp_poll_events+0x54>
    46fc:	b7f80cc2 	tbnz	x2, #63, 4894 <fwp_poll_events+0x200>
    4700:	cb000042 	sub	x2, x2, x0
    4704:	f100005f 	cmp	x2, #0x0
    4708:	540005ad 	b.le	47bc <fwp_poll_events+0x128>
    470c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4710:	d2884801 	mov	x1, #0x4240                	// #16960
    4714:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4718:	f2a001e1 	movk	x1, #0xf, lsl #16
    471c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4720:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4724:	f2e86360 	movk	x0, #0x431b, lsl #48
    4728:	9b407c40 	smulh	x0, x2, x0
    472c:	9352fc00 	asr	x0, x0, #18
    4730:	cb82fc00 	sub	x0, x0, x2, asr #63
    4734:	9b018802 	msub	x2, x0, x1, x2
    4738:	f100005f 	cmp	x2, #0x0
    473c:	9a800400 	cinc	x0, x0, ne	// ne = any
    4740:	eb03001f 	cmp	x0, x3
    4744:	540009ec 	b.gt	4880 <fwp_poll_events+0x1ec>
    4748:	340003a0 	cbz	w0, 47bc <fwp_poll_events+0x128>
    474c:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4750:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4754:	72a20c42 	movk	w2, #0x1062, lsl #16
    4758:	9ba27c02 	umull	x2, w0, w2
    475c:	d366fc43 	lsr	x3, x2, #38
    4760:	aa0303e2 	mov	x2, x3
    4764:	1b048063 	msub	w3, w3, w4, w0
    4768:	9b217c63 	smull	x3, w3, w1
    476c:	d2800001 	mov	x1, #0x0                   	// #0
    4770:	910023e0 	add	x0, sp, #0x8
    4774:	a9008fe2 	stp	x2, x3, [sp, #8]
    4778:	97fff85a 	bl	28e0 <nanosleep@plt>
    477c:	91018280 	add	x0, x20, #0x60
    4780:	f940a413 	ldr	x19, [x0, #328]
    4784:	97fffc5f 	bl	3900 <fwp_now_ns>
    4788:	aa0003e6 	mov	x6, x0
    478c:	b50001d3 	cbnz	x19, 47c4 <fwp_poll_events+0x130>
    4790:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4794:	f947f400 	ldr	x0, [x0, #4072]
    4798:	f9400fe2 	ldr	x2, [sp, #24]
    479c:	f9400001 	ldr	x1, [x0]
    47a0:	eb010042 	subs	x2, x2, x1
    47a4:	d2800001 	mov	x1, #0x0                   	// #0
    47a8:	540008c1 	b.ne	48c0 <fwp_poll_events+0x22c>  // b.any
    47ac:	a9427bfd 	ldp	x29, x30, [sp, #32]
    47b0:	a94353f3 	ldp	x19, x20, [sp, #48]
    47b4:	910103ff 	add	sp, sp, #0x40
    47b8:	d65f03c0 	ret
    47bc:	97fffc51 	bl	3900 <fwp_now_ns>
    47c0:	aa0003e6 	mov	x6, x0
    47c4:	4f000400 	movi	v0.4s, #0x0
    47c8:	91018288 	add	x8, x20, #0x60
    47cc:	52800027 	mov	w7, #0x1                   	// #1
    47d0:	f9403661 	ldr	x1, [x19, #104]
    47d4:	aa1303e5 	mov	x5, x19
    47d8:	f9408a73 	ldr	x19, [x19, #272]
    47dc:	eb06003f 	cmp	x1, x6
    47e0:	5400032c 	b.gt	4844 <fwp_poll_events+0x1b0>
    47e4:	394154a0 	ldrb	w0, [x5, #85]
    47e8:	36000120 	tbz	w0, #0, 480c <fwp_poll_events+0x178>
    47ec:	f94084a0 	ldr	x0, [x5, #264]
    47f0:	b40003c0 	cbz	x0, 4868 <fwp_poll_events+0x1d4>
    47f4:	f9008813 	str	x19, [x0, #272]
    47f8:	b4000053 	cbz	x19, 4800 <fwp_poll_events+0x16c>
    47fc:	f9008660 	str	x0, [x19, #264]
    4800:	910800a0 	add	x0, x5, #0x200
    4804:	390154bf 	strb	wzr, [x5, #85]
    4808:	3c908000 	stur	q0, [x0, #-248]
    480c:	f94030a0 	ldr	x0, [x5, #96]
    4810:	390158a7 	strb	w7, [x5, #86]
    4814:	f100001f 	cmp	x0, #0x0
    4818:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    481c:	5400018d 	b.le	484c <fwp_poll_events+0x1b8>
    4820:	f94028a0 	ldr	x0, [x5, #80]
    4824:	f2001c1f 	tst	x0, #0xff000000ff
    4828:	540000e1 	b.ne	4844 <fwp_poll_events+0x1b0>  // b.any
    482c:	f9406100 	ldr	x0, [x8, #192]
    4830:	390150a7 	strb	w7, [x5, #84]
    4834:	f90080bf 	str	xzr, [x5, #256]
    4838:	b40001e0 	cbz	x0, 4874 <fwp_poll_events+0x1e0>
    483c:	f9006105 	str	x5, [x8, #192]
    4840:	f9008005 	str	x5, [x0, #256]
    4844:	b5fffc73 	cbnz	x19, 47d0 <fwp_poll_events+0x13c>
    4848:	17ffffd2 	b	4790 <fwp_poll_events+0xfc>
    484c:	394144a0 	ldrb	w0, [x5, #81]
    4850:	3707fe80 	tbnz	w0, #0, 4820 <fwp_poll_events+0x18c>
    4854:	394140a0 	ldrb	w0, [x5, #80]
    4858:	3707fe40 	tbnz	w0, #0, 4820 <fwp_poll_events+0x18c>
    485c:	aa0503e0 	mov	x0, x5
    4860:	97fffb84 	bl	3670 <fwp_cancel_tree.part.0>
    4864:	17ffffef 	b	4820 <fwp_poll_events+0x18c>
    4868:	91018281 	add	x1, x20, #0x60
    486c:	f900a433 	str	x19, [x1, #328]
    4870:	17ffffe2 	b	47f8 <fwp_poll_events+0x164>
    4874:	f9006105 	str	x5, [x8, #192]
    4878:	f9006505 	str	x5, [x8, #200]
    487c:	17fffff2 	b	4844 <fwp_poll_events+0x1b0>
    4880:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4884:	d2989362 	mov	x2, #0xc49b                	// #50331
    4888:	f2a4d203 	movk	x3, #0x2690, lsl #16
    488c:	f2a00402 	movk	x2, #0x20, lsl #16
    4890:	17ffffb7 	b	476c <fwp_poll_events+0xd8>
    4894:	97fff9d8 	bl	2ff4 <fwp_flush>
    4898:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    489c:	f947e863 	ldr	x3, [x3, #4048]
    48a0:	d2800562 	mov	x2, #0x2b                  	// #43
    48a4:	d2800021 	mov	x1, #0x1                   	// #1
    48a8:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    48ac:	9137e000 	add	x0, x0, #0xdf8
    48b0:	f9400063 	ldr	x3, [x3]
    48b4:	97fff817 	bl	2910 <fwrite@plt>
    48b8:	52800ca0 	mov	w0, #0x65                  	// #101
    48bc:	97fff781 	bl	26c0 <exit@plt>
    48c0:	97fff7d4 	bl	2810 <__stack_chk_fail@plt>

00000000000048c4 <fwp_rc_wide_dup>:
    48c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48c8:	910003fd 	mov	x29, sp
    48cc:	a90153f3 	stp	x19, x20, [sp, #16]
    48d0:	aa0003f3 	mov	x19, x0
    48d4:	ca404400 	eor	x0, x0, x0, lsr #17
    48d8:	f90013f5 	str	x21, [sp, #32]
    48dc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    48e0:	ca402400 	eor	x0, x0, x0, lsr #9
    48e4:	911982a2 	add	x2, x21, #0x660
    48e8:	92401c00 	and	x0, x0, #0xff
    48ec:	910a2403 	add	x3, x0, #0x289
    48f0:	8b000c40 	add	x0, x2, x0, lsl #3
    48f4:	8b030c54 	add	x20, x2, x3, lsl #3
    48f8:	f94a2401 	ldr	x1, [x0, #5192]
    48fc:	b50000a1 	cbnz	x1, 4910 <fwp_rc_wide_dup+0x4c>
    4900:	1400002d 	b	49b4 <fwp_rc_wide_dup+0xf0>
    4904:	91004034 	add	x20, x1, #0x10
    4908:	f9400821 	ldr	x1, [x1, #16]
    490c:	b4000241 	cbz	x1, 4954 <fwp_rc_wide_dup+0x90>
    4910:	f9400022 	ldr	x2, [x1]
    4914:	eb02027f 	cmp	x19, x2
    4918:	54ffff61 	b.ne	4904 <fwp_rc_wide_dup+0x40>  // b.any
    491c:	f9400281 	ldr	x1, [x20]
    4920:	39400260 	ldrb	w0, [x19]
    4924:	7103f81f 	cmp	w0, #0xfe
    4928:	54000220 	b.eq	496c <fwp_rc_wide_dup+0xa8>  // b.none
    492c:	b40001a1 	cbz	x1, 4960 <fwp_rc_wide_dup+0x9c>
    4930:	f9400420 	ldr	x0, [x1, #8]
    4934:	b100041f 	cmn	x0, #0x1
    4938:	540004a0 	b.eq	49cc <fwp_rc_wide_dup+0x108>  // b.none
    493c:	91000400 	add	x0, x0, #0x1
    4940:	f9000420 	str	x0, [x1, #8]
    4944:	a94153f3 	ldp	x19, x20, [sp, #16]
    4948:	f94013f5 	ldr	x21, [sp, #32]
    494c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4950:	d65f03c0 	ret
    4954:	39400260 	ldrb	w0, [x19]
    4958:	7103f81f 	cmp	w0, #0xfe
    495c:	540000a0 	b.eq	4970 <fwp_rc_wide_dup+0xac>  // b.none
    4960:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    4964:	91394000 	add	x0, x0, #0xe50
    4968:	97fffb86 	bl	3780 <fwp_trap>
    496c:	b5000281 	cbnz	x1, 49bc <fwp_rc_wide_dup+0xf8>
    4970:	d2800300 	mov	x0, #0x18                  	// #24
    4974:	97fff78f 	bl	27b0 <malloc@plt>
    4978:	b4000280 	cbz	x0, 49c8 <fwp_rc_wide_dup+0x104>
    497c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4980:	a9000413 	stp	x19, x1, [x0]
    4984:	911982b5 	add	x21, x21, #0x660
    4988:	f900081f 	str	xzr, [x0, #16]
    498c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4990:	f9000280 	str	x0, [x20]
    4994:	39000261 	strb	w1, [x19]
    4998:	f94e26a0 	ldr	x0, [x21, #7240]
    499c:	a94153f3 	ldp	x19, x20, [sp, #16]
    49a0:	91000400 	add	x0, x0, #0x1
    49a4:	f90e26a0 	str	x0, [x21, #7240]
    49a8:	f94013f5 	ldr	x21, [sp, #32]
    49ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49b0:	d65f03c0 	ret
    49b4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    49b8:	17ffffda 	b	4920 <fwp_rc_wide_dup+0x5c>
    49bc:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    49c0:	9138a000 	add	x0, x0, #0xe28
    49c4:	97fffb6f 	bl	3780 <fwp_trap>
    49c8:	97fff9ca 	bl	30f0 <fwp_heap_oom>
    49cc:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    49d0:	9139e000 	add	x0, x0, #0xe78
    49d4:	97fffb6b 	bl	3780 <fwp_trap>
    49d8:	d503201f 	nop
    49dc:	d503201f 	nop

00000000000049e0 <fwp_rc_forget_slot>:
    49e0:	aa0003e1 	mov	x1, x0
    49e4:	39400000 	ldrb	w0, [x0]
    49e8:	7103fc1f 	cmp	w0, #0xff
    49ec:	54000040 	b.eq	49f4 <fwp_rc_forget_slot+0x14>  // b.none
    49f0:	d65f03c0 	ret
    49f4:	ca414420 	eor	x0, x1, x1, lsr #17
    49f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    49fc:	ca402400 	eor	x0, x0, x0, lsr #9
    4a00:	910003fd 	mov	x29, sp
    4a04:	92401c00 	and	x0, x0, #0xff
    4a08:	f9000bf3 	str	x19, [sp, #16]
    4a0c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xb80>
    4a10:	91198262 	add	x2, x19, #0x660
    4a14:	910a2403 	add	x3, x0, #0x289
    4a18:	8b000c40 	add	x0, x2, x0, lsl #3
    4a1c:	8b030c43 	add	x3, x2, x3, lsl #3
    4a20:	f94a2400 	ldr	x0, [x0, #5192]
    4a24:	b50000a0 	cbnz	x0, 4a38 <fwp_rc_forget_slot+0x58>
    4a28:	14000011 	b	4a6c <fwp_rc_forget_slot+0x8c>
    4a2c:	91004003 	add	x3, x0, #0x10
    4a30:	f9400800 	ldr	x0, [x0, #16]
    4a34:	b40001c0 	cbz	x0, 4a6c <fwp_rc_forget_slot+0x8c>
    4a38:	f9400002 	ldr	x2, [x0]
    4a3c:	eb02003f 	cmp	x1, x2
    4a40:	54ffff61 	b.ne	4a2c <fwp_rc_forget_slot+0x4c>  // b.any
    4a44:	f9400801 	ldr	x1, [x0, #16]
    4a48:	91198273 	add	x19, x19, #0x660
    4a4c:	f9000061 	str	x1, [x3]
    4a50:	97fff7a0 	bl	28d0 <free@plt>
    4a54:	f94e2660 	ldr	x0, [x19, #7240]
    4a58:	d1000400 	sub	x0, x0, #0x1
    4a5c:	f90e2660 	str	x0, [x19, #7240]
    4a60:	f9400bf3 	ldr	x19, [sp, #16]
    4a64:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a68:	d65f03c0 	ret
    4a6c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    4a70:	91394000 	add	x0, x0, #0xe50
    4a74:	97fffb43 	bl	3780 <fwp_trap>
    4a78:	d503201f 	nop
    4a7c:	d503201f 	nop

0000000000004a80 <fwp_rc_prepare_chunk>:
    4a80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a84:	910003fd 	mov	x29, sp
    4a88:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a8c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xb80>
    4a90:	911982c2 	add	x2, x22, #0x660
    4a94:	b9401c03 	ldr	w3, [x0, #28]
    4a98:	aa0103f5 	mov	x21, x1
    4a9c:	a90153f3 	stp	x19, x20, [sp, #16]
    4aa0:	aa0003f4 	mov	x20, x0
    4aa4:	f94e2440 	ldr	x0, [x2, #7240]
    4aa8:	b4000440 	cbz	x0, 4b30 <fwp_rc_prepare_chunk+0xb0>
    4aac:	d2800013 	mov	x19, #0x0                   	// #0
    4ab0:	35000203 	cbnz	w3, 4af0 <fwp_rc_prepare_chunk+0x70>
    4ab4:	b4000361 	cbz	x1, 4b20 <fwp_rc_prepare_chunk+0xa0>
    4ab8:	f9401280 	ldr	x0, [x20, #32]
    4abc:	97fff785 	bl	28d0 <free@plt>
    4ac0:	aa1503e0 	mov	x0, x21
    4ac4:	d2800021 	mov	x1, #0x1                   	// #1
    4ac8:	97fff74a 	bl	27f0 <calloc@plt>
    4acc:	f9001280 	str	x0, [x20, #32]
    4ad0:	b5000460 	cbnz	x0, 4b5c <fwp_rc_prepare_chunk+0xdc>
    4ad4:	97fff987 	bl	30f0 <fwp_heap_oom>
    4ad8:	97ffffc2 	bl	49e0 <fwp_rc_forget_slot>
    4adc:	91000673 	add	x19, x19, #0x1
    4ae0:	b9401e83 	ldr	w3, [x20, #28]
    4ae4:	eb13007f 	cmp	x3, x19
    4ae8:	54000169 	b.ls	4b14 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4aec:	d503201f 	nop
    4af0:	f9401283 	ldr	x3, [x20, #32]
    4af4:	8b130060 	add	x0, x3, x19
    4af8:	38736863 	ldrb	w3, [x3, x19]
    4afc:	7103fc7f 	cmp	w3, #0xff
    4b00:	54fffec0 	b.eq	4ad8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b04:	b9401e83 	ldr	w3, [x20, #28]
    4b08:	91000673 	add	x19, x19, #0x1
    4b0c:	eb13007f 	cmp	x3, x19
    4b10:	54ffff08 	b.hi	4af0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b14:	eb0302bf 	cmp	x21, x3
    4b18:	54000121 	b.ne	4b3c <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b1c:	b5000335 	cbnz	x21, 4b80 <fwp_rc_prepare_chunk+0x100>
    4b20:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b2c:	d65f03c0 	ret
    4b30:	2a0303e3 	mov	w3, w3
    4b34:	eb0302bf 	cmp	x21, x3
    4b38:	54ffff20 	b.eq	4b1c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4b3c:	911982c2 	add	x2, x22, #0x660
    4b40:	f9401280 	ldr	x0, [x20, #32]
    4b44:	f94e2841 	ldr	x1, [x2, #7248]
    4b48:	cb030021 	sub	x1, x1, x3
    4b4c:	f90e2841 	str	x1, [x2, #7248]
    4b50:	97fff760 	bl	28d0 <free@plt>
    4b54:	b5fffb75 	cbnz	x21, 4ac0 <fwp_rc_prepare_chunk+0x40>
    4b58:	f900129f 	str	xzr, [x20, #32]
    4b5c:	911982d6 	add	x22, x22, #0x660
    4b60:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b64:	b9001e95 	str	w21, [x20, #28]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	8b150000 	add	x0, x0, x21
    4b70:	f90e2ac0 	str	x0, [x22, #7248]
    4b74:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b7c:	d65f03c0 	ret
    4b80:	f9401280 	ldr	x0, [x20, #32]
    4b84:	aa1503e2 	mov	x2, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	52800001 	mov	w1, #0x0                   	// #0
    4b90:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b94:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b98:	17fff712 	b	27e0 <memset@plt>
    4b9c:	d503201f 	nop

0000000000004ba0 <fwp_heap_refill>:
    4ba0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4ba4:	910003fd 	mov	x29, sp
    4ba8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4bac:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    4bb0:	911982b5 	add	x21, x21, #0x660
    4bb4:	aa0003f6 	mov	x22, x0
    4bb8:	d2800020 	mov	x0, #0x1                   	// #1
    4bbc:	a90153f3 	stp	x19, x20, [sp, #16]
    4bc0:	a90363f7 	stp	x23, x24, [sp, #48]
    4bc4:	2a0103f7 	mov	w23, w1
    4bc8:	2a0203f8 	mov	w24, w2
    4bcc:	97fff959 	bl	3130 <fwp_heap_chunks>
    4bd0:	aa0003f3 	mov	x19, x0
    4bd4:	f949fea2 	ldr	x2, [x21, #5112]
    4bd8:	8b000800 	add	x0, x0, x0, lsl #2
    4bdc:	2a1703e1 	mov	w1, w23
    4be0:	52800025 	mov	w5, #0x1                   	// #1
    4be4:	d37df000 	lsl	x0, x0, #3
    4be8:	910f0021 	add	x1, x1, #0x3c0
    4bec:	8b000054 	add	x20, x2, x0
    4bf0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4bf4:	52a00024 	mov	w4, #0x10000               	// #65536
    4bf8:	38206845 	strb	w5, [x2, x0]
    4bfc:	aa1403e0 	mov	x0, x20
    4c00:	39000698 	strb	w24, [x20, #1]
    4c04:	39000a97 	strb	w23, [x20, #2]
    4c08:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c0c:	b9000681 	str	w1, [x20, #4]
    4c10:	2a0103e5 	mov	w5, w1
    4c14:	8b0300a2 	add	x2, x5, x3
    4c18:	1ac10881 	udiv	w1, w4, w1
    4c1c:	9ac50842 	udiv	x2, x2, x5
    4c20:	b9000a81 	str	w1, [x20, #8]
    4c24:	92404021 	and	x1, x1, #0x1ffff
    4c28:	b9001a82 	str	w2, [x20, #24]
    4c2c:	97ffff95 	bl	4a80 <fwp_rc_prepare_chunk>
    4c30:	f949daa0 	ldr	x0, [x21, #5040]
    4c34:	29408a81 	ldp	w1, w2, [x20, #4]
    4c38:	8b134000 	add	x0, x0, x19, lsl #16
    4c3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c40:	8b214003 	add	x3, x0, w1, uxtw
    4c44:	9ba20021 	umaddl	x1, w1, w2, x0
    4c48:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c4c:	a90086c3 	stp	x3, x1, [x22, #8]
    4c50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c54:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c58:	d65f03c0 	ret
    4c5c:	d503201f 	nop

0000000000004c60 <fwp_mem_free>:
    4c60:	b40003c0 	cbz	x0, 4cd8 <fwp_mem_free+0x78>
    4c64:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c68:	910003fd 	mov	x29, sp
    4c6c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c70:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    4c74:	911982a1 	add	x1, x21, #0x660
    4c78:	a90153f3 	stp	x19, x20, [sp, #16]
    4c7c:	aa0003f3 	mov	x19, x0
    4c80:	f949d823 	ldr	x3, [x1, #5040]
    4c84:	f949ec22 	ldr	x2, [x1, #5080]
    4c88:	cb030000 	sub	x0, x0, x3
    4c8c:	eb02401f 	cmp	x0, x2, lsl #16
    4c90:	540001c2 	b.cs	4cc8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4c94:	d350fc16 	lsr	x22, x0, #16
    4c98:	a90363f7 	stp	x23, x24, [sp, #48]
    4c9c:	f949fc22 	ldr	x2, [x1, #5112]
    4ca0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4ca4:	d37df294 	lsl	x20, x20, #3
    4ca8:	ab140057 	adds	x23, x2, x20
    4cac:	540000c0 	b.eq	4cc4 <fwp_mem_free+0x64>  // b.none
    4cb0:	38746842 	ldrb	w2, [x2, x20]
    4cb4:	7100045f 	cmp	w2, #0x1
    4cb8:	54000120 	b.eq	4cdc <fwp_mem_free+0x7c>  // b.none
    4cbc:	7100085f 	cmp	w2, #0x2
    4cc0:	540005e0 	b.eq	4d7c <fwp_mem_free+0x11c>  // b.none
    4cc4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ccc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4cd4:	d65f03c0 	ret
    4cd8:	d65f03c0 	ret
    4cdc:	f94012f8 	ldr	x24, [x23, #32]
    4ce0:	b94006e1 	ldr	w1, [x23, #4]
    4ce4:	f90023f9 	str	x25, [sp, #64]
    4ce8:	2a0103e2 	mov	w2, w1
    4cec:	394006f9 	ldrb	w25, [x23, #1]
    4cf0:	39400af4 	ldrb	w20, [x23, #2]
    4cf4:	b4000158 	cbz	x24, 4d1c <fwp_mem_free+0xbc>
    4cf8:	92403e76 	and	x22, x19, #0xffff
    4cfc:	9ac20ad6 	udiv	x22, x22, x2
    4d00:	38766b01 	ldrb	w1, [x24, x22]
    4d04:	8b160300 	add	x0, x24, x22
    4d08:	7103fc3f 	cmp	w1, #0xff
    4d0c:	54000980 	b.eq	4e3c <fwp_mem_free+0x1dc>  // b.none
    4d10:	38366b1f 	strb	wzr, [x24, x22]
    4d14:	b94006e1 	ldr	w1, [x23, #4]
    4d18:	2a0103e2 	mov	w2, w1
    4d1c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4d20:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4d24:	cb390000 	sub	x0, x0, w25, uxtb
    4d28:	8b340074 	add	x20, x3, w20, uxtb
    4d2c:	911982b5 	add	x21, x21, #0x660
    4d30:	1e630021 	ucvtf	d1, w1
    4d34:	d37ae400 	lsl	x0, x0, #6
    4d38:	8b140c14 	add	x20, x0, x20, lsl #3
    4d3c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d40:	f8746aa0 	ldr	x0, [x21, x20]
    4d44:	f94023f9 	ldr	x25, [sp, #64]
    4d48:	aa2003e0 	mvn	x0, x0
    4d4c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d50:	f9000260 	str	x0, [x19]
    4d54:	f8346ab3 	str	x19, [x21, x20]
    4d58:	f94a12a0 	ldr	x0, [x21, #5152]
    4d5c:	1e612800 	fadd	d0, d0, d1
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	cb020000 	sub	x0, x0, x2
    4d68:	f90a12a0 	str	x0, [x21, #5152]
    4d6c:	fd0a22a0 	str	d0, [x21, #5184]
    4d70:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d74:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d78:	d65f03c0 	ret
    4d7c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4d80:	8b000063 	add	x3, x3, x0
    4d84:	eb03027f 	cmp	x19, x3
    4d88:	54fff9e1 	b.ne	4cc4 <fwp_mem_free+0x64>  // b.any
    4d8c:	fd400ae1 	ldr	d1, [x23, #16]
    4d90:	fd4a2020 	ldr	d0, [x1, #5184]
    4d94:	f9400ae0 	ldr	x0, [x23, #16]
    4d98:	7e61d821 	ucvtf	d1, d1
    4d9c:	f94a1022 	ldr	x2, [x1, #5152]
    4da0:	f94012f3 	ldr	x19, [x23, #32]
    4da4:	1e612800 	fadd	d0, d0, d1
    4da8:	cb000042 	sub	x2, x2, x0
    4dac:	f90a1022 	str	x2, [x1, #5152]
    4db0:	fd0a2020 	str	d0, [x1, #5184]
    4db4:	b40000b3 	cbz	x19, 4dc8 <fwp_mem_free+0x168>
    4db8:	39400260 	ldrb	w0, [x19]
    4dbc:	7103fc1f 	cmp	w0, #0xff
    4dc0:	54000380 	b.eq	4e30 <fwp_mem_free+0x1d0>  // b.none
    4dc4:	3900027f 	strb	wzr, [x19]
    4dc8:	b9400ee2 	ldr	w2, [x23, #12]
    4dcc:	b4000142 	cbz	x2, 4df4 <fwp_mem_free+0x194>
    4dd0:	911982a1 	add	x1, x21, #0x660
    4dd4:	8b160040 	add	x0, x2, x22
    4dd8:	8b000800 	add	x0, x0, x0, lsl #2
    4ddc:	f949fc21 	ldr	x1, [x1, #5112]
    4de0:	8b140034 	add	x20, x1, x20
    4de4:	8b000c20 	add	x0, x1, x0, lsl #3
    4de8:	3802869f 	strb	wzr, [x20], #40
    4dec:	eb00029f 	cmp	x20, x0
    4df0:	54ffffc1 	b.ne	4de8 <fwp_mem_free+0x188>  // b.any
    4df4:	911982a0 	add	x0, x21, #0x660
    4df8:	f94a1801 	ldr	x1, [x0, #5168]
    4dfc:	f949f803 	ldr	x3, [x0, #5104]
    4e00:	8b020021 	add	x1, x1, x2
    4e04:	f90a1801 	str	x1, [x0, #5168]
    4e08:	eb16007f 	cmp	x3, x22
    4e0c:	54000049 	b.ls	4e14 <fwp_mem_free+0x1b4>  // b.plast
    4e10:	f909f816 	str	x22, [x0, #5104]
    4e14:	911982b5 	add	x21, x21, #0x660
    4e18:	f949f6a0 	ldr	x0, [x21, #5096]
    4e1c:	eb16001f 	cmp	x0, x22
    4e20:	54fff529 	b.ls	4cc4 <fwp_mem_free+0x64>  // b.plast
    4e24:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e28:	f909f6b6 	str	x22, [x21, #5096]
    4e2c:	17ffffa7 	b	4cc8 <fwp_mem_free+0x68>
    4e30:	aa1303e0 	mov	x0, x19
    4e34:	97fffeeb 	bl	49e0 <fwp_rc_forget_slot>
    4e38:	17ffffe3 	b	4dc4 <fwp_mem_free+0x164>
    4e3c:	97fffee9 	bl	49e0 <fwp_rc_forget_slot>
    4e40:	17ffffb4 	b	4d10 <fwp_mem_free+0xb0>

0000000000004e44 <fwp_heap_alloc_big>:
    4e44:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e48:	910003fd 	mov	x29, sp
    4e4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4e50:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e54:	a90363f7 	stp	x23, x24, [sp, #48]
    4e58:	aa0003f7 	mov	x23, x0
    4e5c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e60:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e64:	eb0002ff 	cmp	x23, x0
    4e68:	54000888 	b.hi	4f78 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e6c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e70:	8b0002f4 	add	x20, x23, x0
    4e74:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xb80>
    4e78:	91198359 	add	x25, x26, #0x660
    4e7c:	d350fe94 	lsr	x20, x20, #16
    4e80:	2a0103f5 	mov	w21, w1
    4e84:	aa1403e0 	mov	x0, x20
    4e88:	97fff8aa 	bl	3130 <fwp_heap_chunks>
    4e8c:	f949ff22 	ldr	x2, [x25, #5112]
    4e90:	8b000813 	add	x19, x0, x0, lsl #2
    4e94:	aa0003f8 	mov	x24, x0
    4e98:	52800043 	mov	w3, #0x2                   	// #2
    4e9c:	d37df273 	lsl	x19, x19, #3
    4ea0:	d2800021 	mov	x1, #0x1                   	// #1
    4ea4:	8b130040 	add	x0, x2, x19
    4ea8:	38336843 	strb	w3, [x2, x19]
    4eac:	39000415 	strb	w21, [x0, #1]
    4eb0:	b9000c14 	str	w20, [x0, #12]
    4eb4:	f9000817 	str	x23, [x0, #16]
    4eb8:	97fffef2 	bl	4a80 <fwp_rc_prepare_chunk>
    4ebc:	f100069f 	cmp	x20, #0x1
    4ec0:	54000269 	b.ls	4f0c <fwp_heap_alloc_big+0xc8>  // b.plast
    4ec4:	8b180294 	add	x20, x20, x24
    4ec8:	9100a273 	add	x19, x19, #0x28
    4ecc:	a90573fb 	stp	x27, x28, [sp, #80]
    4ed0:	5280007b 	mov	w27, #0x3                   	// #3
    4ed4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ed8:	2a1803fc 	mov	w28, w24
    4edc:	9adb2296 	lsl	x22, x20, x27
    4ee0:	f949ff35 	ldr	x21, [x25, #5112]
    4ee4:	d2800001 	mov	x1, #0x0                   	// #0
    4ee8:	8b1302b4 	add	x20, x21, x19
    4eec:	aa1403e0 	mov	x0, x20
    4ef0:	97fffee4 	bl	4a80 <fwp_rc_prepare_chunk>
    4ef4:	38336abb 	strb	w27, [x21, x19]
    4ef8:	9100a273 	add	x19, x19, #0x28
    4efc:	b9000e9c 	str	w28, [x20, #12]
    4f00:	eb1302df 	cmp	x22, x19
    4f04:	54fffee1 	b.ne	4ee0 <fwp_heap_alloc_big+0x9c>  // b.any
    4f08:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f0c:	91198353 	add	x19, x26, #0x660
    4f10:	aa1703e2 	mov	x2, x23
    4f14:	52800001 	mov	w1, #0x0                   	// #0
    4f18:	f949da60 	ldr	x0, [x19, #5040]
    4f1c:	8b184018 	add	x24, x0, x24, lsl #16
    4f20:	aa1803e0 	mov	x0, x24
    4f24:	97fff62f 	bl	27e0 <memset@plt>
    4f28:	f94a1260 	ldr	x0, [x19, #5152]
    4f2c:	ab170000 	adds	x0, x0, x23
    4f30:	54000242 	b.cs	4f78 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4f34:	f94a1661 	ldr	x1, [x19, #5160]
    4f38:	f90a1260 	str	x0, [x19, #5152]
    4f3c:	eb01001f 	cmp	x0, x1
    4f40:	54000049 	b.ls	4f48 <fwp_heap_alloc_big+0x104>  // b.plast
    4f44:	f90a1660 	str	x0, [x19, #5160]
    4f48:	9119835a 	add	x26, x26, #0x660
    4f4c:	9e6202e0 	scvtf	d0, x23
    4f50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f54:	aa1803e0 	mov	x0, x24
    4f58:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f60:	1e602820 	fadd	d0, d1, d0
    4f64:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f68:	fd0a1f40 	str	d0, [x26, #5176]
    4f6c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f70:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f74:	d65f03c0 	ret
    4f78:	a90573fb 	stp	x27, x28, [sp, #80]
    4f7c:	97fff85d 	bl	30f0 <fwp_heap_oom>

0000000000004f80 <fwp_heap_alloc_slow>:
    4f80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f84:	910003fd 	mov	x29, sp
    4f88:	a90153f3 	stp	x19, x20, [sp, #16]
    4f8c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xb80>
    4f90:	91198262 	add	x2, x19, #0x660
    4f94:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f98:	aa0003f5 	mov	x21, x0
    4f9c:	2a0103f4 	mov	w20, w1
    4fa0:	b953a440 	ldr	w0, [x2, #5028]
    4fa4:	34000600 	cbz	w0, 5064 <fwp_heap_alloc_slow+0xe4>
    4fa8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fac:	54000628 	b.hi	5070 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fb0:	91003ea0 	add	x0, x21, #0xf
    4fb4:	91198262 	add	x2, x19, #0x660
    4fb8:	f9001bf7 	str	x23, [sp, #48]
    4fbc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4fc0:	8b401040 	add	x0, x2, x0, lsr #4
    4fc4:	cb34c084 	sub	x4, x4, w20, sxtw
    4fc8:	d37ae484 	lsl	x4, x4, #6
    4fcc:	397e8003 	ldrb	w3, [x0, #4000]
    4fd0:	910f0060 	add	x0, x3, #0x3c0
    4fd4:	aa0303e1 	mov	x1, x3
    4fd8:	8b030463 	add	x3, x3, x3, lsl #1
    4fdc:	8b030c83 	add	x3, x4, x3, lsl #3
    4fe0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4fe4:	2a1703f6 	mov	w22, w23
    4fe8:	f8636844 	ldr	x4, [x2, x3]
    4fec:	b40004e4 	cbz	x4, 5088 <fwp_heap_alloc_slow+0x108>
    4ff0:	f9400080 	ldr	x0, [x4]
    4ff4:	aa2003e0 	mvn	x0, x0
    4ff8:	f8236840 	str	x0, [x2, x3]
    4ffc:	7100069f 	cmp	w20, #0x1
    5000:	aa0403e0 	mov	x0, x4
    5004:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5008:	52800001 	mov	w1, #0x0                   	// #0
    500c:	97fff5f5 	bl	27e0 <memset@plt>
    5010:	aa0003e4 	mov	x4, x0
    5014:	91198260 	add	x0, x19, #0x660
    5018:	f94a1001 	ldr	x1, [x0, #5152]
    501c:	ab160021 	adds	x1, x1, x22
    5020:	540005c2 	b.cs	50d8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5024:	f94a1402 	ldr	x2, [x0, #5160]
    5028:	f90a1001 	str	x1, [x0, #5152]
    502c:	eb02003f 	cmp	x1, x2
    5030:	54000049 	b.ls	5038 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5034:	f90a1401 	str	x1, [x0, #5160]
    5038:	91198273 	add	x19, x19, #0x660
    503c:	1e6302e1 	ucvtf	d1, w23
    5040:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5044:	aa0403e0 	mov	x0, x4
    5048:	fd4a1e60 	ldr	d0, [x19, #5176]
    504c:	f9401bf7 	ldr	x23, [sp, #48]
    5050:	1e612800 	fadd	d0, d0, d1
    5054:	fd0a1e60 	str	d0, [x19, #5176]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5060:	d65f03c0 	ret
    5064:	97fffc08 	bl	4084 <fwp_heap_init>
    5068:	f14012bf 	cmp	x21, #0x4, lsl #12
    506c:	54fffa29 	b.ls	4fb0 <fwp_heap_alloc_slow+0x30>  // b.plast
    5070:	2a1403e1 	mov	w1, w20
    5074:	aa1503e0 	mov	x0, x21
    5078:	a94153f3 	ldp	x19, x20, [sp, #16]
    507c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5080:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5084:	17ffff70 	b	4e44 <fwp_heap_alloc_big>
    5088:	8b030042 	add	x2, x2, x3
    508c:	f9400444 	ldr	x4, [x2, #8]
    5090:	b4000104 	cbz	x4, 50b0 <fwp_heap_alloc_slow+0x130>
    5094:	f9400840 	ldr	x0, [x2, #16]
    5098:	cb040000 	sub	x0, x0, x4
    509c:	eb16001f 	cmp	x0, x22
    50a0:	54000083 	b.cc	50b0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50a4:	8b160080 	add	x0, x4, x22
    50a8:	f9000440 	str	x0, [x2, #8]
    50ac:	17ffffd4 	b	4ffc <fwp_heap_alloc_slow+0x7c>
    50b0:	52800302 	mov	w2, #0x18                  	// #24
    50b4:	52807804 	mov	w4, #0x3c0                 	// #960
    50b8:	91198260 	add	x0, x19, #0x660
    50bc:	9ba27c23 	umull	x3, w1, w2
    50c0:	2a1403e2 	mov	w2, w20
    50c4:	9b240e84 	smaddl	x4, w20, w4, x3
    50c8:	8b040000 	add	x0, x0, x4
    50cc:	97fffeb5 	bl	4ba0 <fwp_heap_refill>
    50d0:	aa0003e4 	mov	x4, x0
    50d4:	17ffffca 	b	4ffc <fwp_heap_alloc_slow+0x7c>
    50d8:	97fff806 	bl	30f0 <fwp_heap_oom>
    50dc:	d503201f 	nop

00000000000050e0 <fwp_heap_alloc>:
    50e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    50e4:	910003fd 	mov	x29, sp
    50e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    50ec:	f00000d6 	adrp	x22, 20000 <__data_start>
    50f0:	910182c2 	add	x2, x22, #0x60
    50f4:	a90363f7 	stp	x23, x24, [sp, #48]
    50f8:	b9415058 	ldr	w24, [x2, #336]
    50fc:	a90153f3 	stp	x19, x20, [sp, #16]
    5100:	7100031f 	cmp	w24, #0x0
    5104:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5108:	54000861 	b.ne	5214 <fwp_heap_alloc+0x134>  // b.any
    510c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xb80>
    5110:	911982f3 	add	x19, x23, #0x660
    5114:	f140101f 	cmp	x0, #0x4, lsl #12
    5118:	b953a662 	ldr	w2, [x19, #5028]
    511c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5120:	54000740 	b.eq	5208 <fwp_heap_alloc+0x128>  // b.none
    5124:	91003c03 	add	x3, x0, #0xf
    5128:	937c7c22 	sbfiz	x2, x1, #4, #32
    512c:	cb21c042 	sub	x2, x2, w1, sxtw
    5130:	8b431263 	add	x3, x19, x3, lsr #4
    5134:	d37ae442 	lsl	x2, x2, #6
    5138:	397e8063 	ldrb	w3, [x3, #4000]
    513c:	910f0064 	add	x4, x3, #0x3c0
    5140:	8b030463 	add	x3, x3, x3, lsl #1
    5144:	8b030c43 	add	x3, x2, x3, lsl #3
    5148:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    514c:	2a1503f4 	mov	w20, w21
    5150:	f8636a64 	ldr	x4, [x19, x3]
    5154:	b40004c4 	cbz	x4, 51ec <fwp_heap_alloc+0x10c>
    5158:	f9400085 	ldr	x5, [x4]
    515c:	7100043f 	cmp	w1, #0x1
    5160:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5164:	aa0403e0 	mov	x0, x4
    5168:	aa2503e5 	mvn	x5, x5
    516c:	52800001 	mov	w1, #0x0                   	// #0
    5170:	f8236a65 	str	x5, [x19, x3]
    5174:	97fff59b 	bl	27e0 <memset@plt>
    5178:	aa0003e4 	mov	x4, x0
    517c:	f94a1260 	ldr	x0, [x19, #5152]
    5180:	ab140000 	adds	x0, x0, x20
    5184:	540006e2 	b.cs	5260 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5188:	f94a1661 	ldr	x1, [x19, #5160]
    518c:	f90a1260 	str	x0, [x19, #5152]
    5190:	eb01001f 	cmp	x0, x1
    5194:	54000049 	b.ls	519c <fwp_heap_alloc+0xbc>  // b.plast
    5198:	f90a1660 	str	x0, [x19, #5160]
    519c:	911982e0 	add	x0, x23, #0x660
    51a0:	1e6302a1 	ucvtf	d1, w21
    51a4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51a8:	1e612800 	fadd	d0, d0, d1
    51ac:	fd0a1c00 	str	d0, [x0, #5176]
    51b0:	34000138 	cbz	w24, 51d4 <fwp_heap_alloc+0xf4>
    51b4:	911982e1 	add	x1, x23, #0x660
    51b8:	910182c0 	add	x0, x22, #0x60
    51bc:	fd4a1020 	ldr	d0, [x1, #5152]
    51c0:	6d568402 	ldp	d2, d1, [x0, #360]
    51c4:	7e61d800 	ucvtf	d0, d0
    51c8:	1e623800 	fsub	d0, d0, d2
    51cc:	1e612010 	fcmpe	d0, d1
    51d0:	540002cc 	b.gt	5228 <fwp_heap_alloc+0x148>
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	aa0403e0 	mov	x0, x4
    51dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51e0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51e8:	d65f03c0 	ret
    51ec:	8b030263 	add	x3, x19, x3
    51f0:	f9400464 	ldr	x4, [x3, #8]
    51f4:	b40000a4 	cbz	x4, 5208 <fwp_heap_alloc+0x128>
    51f8:	f9400862 	ldr	x2, [x3, #16]
    51fc:	cb040042 	sub	x2, x2, x4
    5200:	eb02029f 	cmp	x20, x2
    5204:	54000209 	b.ls	5244 <fwp_heap_alloc+0x164>  // b.plast
    5208:	97ffff5e 	bl	4f80 <fwp_heap_alloc_slow>
    520c:	aa0003e4 	mov	x4, x0
    5210:	17ffffe8 	b	51b0 <fwp_heap_alloc+0xd0>
    5214:	a9558c44 	ldp	x4, x3, [x2, #344]
    5218:	91000484 	add	x4, x4, #0x1
    521c:	8b000063 	add	x3, x3, x0
    5220:	a9158c44 	stp	x4, x3, [x2, #344]
    5224:	17ffffba 	b	510c <fwp_heap_alloc+0x2c>
    5228:	a94153f3 	ldp	x19, x20, [sp, #16]
    522c:	fd00b800 	str	d0, [x0, #368]
    5230:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5234:	aa0403e0 	mov	x0, x4
    5238:	a94363f7 	ldp	x23, x24, [sp, #48]
    523c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5240:	d65f03c0 	ret
    5244:	7100043f 	cmp	w1, #0x1
    5248:	8b140085 	add	x5, x4, x20
    524c:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5250:	52800001 	mov	w1, #0x0                   	// #0
    5254:	aa0403e0 	mov	x0, x4
    5258:	f9000465 	str	x5, [x3, #8]
    525c:	17ffffc6 	b	5174 <fwp_heap_alloc+0x94>
    5260:	97fff7a4 	bl	30f0 <fwp_heap_oom>

0000000000005264 <fwp_apply>:
    5264:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5268:	aa0003e6 	mov	x6, x0
    526c:	910003fd 	mov	x29, sp
    5270:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5274:	f947f463 	ldr	x3, [x3, #4072]
    5278:	a90153f3 	stp	x19, x20, [sp, #16]
    527c:	aa0203f4 	mov	x20, x2
    5280:	a9025bf5 	stp	x21, x22, [sp, #32]
    5284:	2a0103f5 	mov	w21, w1
    5288:	52800033 	mov	w19, #0x1                   	// #1
    528c:	a90363f7 	stp	x23, x24, [sp, #48]
    5290:	f00000d7 	adrp	x23, 20000 <__data_start>
    5294:	910182f7 	add	x23, x23, #0x60
    5298:	a9046bf9 	stp	x25, x26, [sp, #64]
    529c:	d100c3ff 	sub	sp, sp, #0x30
    52a0:	f9400060 	ldr	x0, [x3]
    52a4:	f81f83a0 	stur	x0, [x29, #-8]
    52a8:	d2800000 	mov	x0, #0x0                   	// #0
    52ac:	294058c3 	ldp	w3, w22, [x6]
    52b0:	910003f8 	mov	x24, sp
    52b4:	f9406ae0 	ldr	x0, [x23, #208]
    52b8:	710002df 	cmp	w22, #0x0
    52bc:	d37be863 	lsl	x3, x3, #5
    52c0:	8b030007 	add	x7, x0, x3
    52c4:	b8636819 	ldr	w25, [x0, x3]
    52c8:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    52cc:	54000163 	b.cc	52f8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    52d0:	f94004e3 	ldr	x3, [x7, #8]
    52d4:	34000bd9 	cbz	w25, 544c <fwp_apply+0x1e8>
    52d8:	aa1403e0 	mov	x0, x20
    52dc:	d63f0060 	blr	x3
    52e0:	aa0003e6 	mov	x6, x0
    52e4:	6b1902bf 	cmp	w21, w25
    52e8:	54000940 	b.eq	5410 <fwp_apply+0x1ac>  // b.none
    52ec:	8b394e94 	add	x20, x20, w25, uxtw #3
    52f0:	4b1902b5 	sub	w21, w21, w25
    52f4:	17ffffee 	b	52ac <fwp_apply+0x48>
    52f8:	0b1602ba 	add	w26, w21, w22
    52fc:	6b19035f 	cmp	w26, w25
    5300:	54000543 	b.cc	53a8 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    5304:	7100033f 	cmp	w25, #0x0
    5308:	4b16033a 	sub	w26, w25, w22
    530c:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    5310:	d37df000 	lsl	x0, x0, #3
    5314:	91003c00 	add	x0, x0, #0xf
    5318:	92704c01 	and	x1, x0, #0xfffff0000
    531c:	927c7c00 	and	x0, x0, #0xffffffff0
    5320:	cb2163e1 	sub	x1, sp, x1
    5324:	eb2163ff 	cmp	sp, x1
    5328:	540000a0 	b.eq	533c <fwp_apply+0xd8>  // b.none
    532c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    5330:	f90203ff 	str	xzr, [sp, #1024]
    5334:	eb2163ff 	cmp	sp, x1
    5338:	54ffffa1 	b.ne	532c <fwp_apply+0xc8>  // b.any
    533c:	92403c00 	and	x0, x0, #0xffff
    5340:	cb2063ff 	sub	sp, sp, x0
    5344:	f90003ff 	str	xzr, [sp]
    5348:	f110001f 	cmp	x0, #0x400
    534c:	54000962 	b.cs	5478 <fwp_apply+0x214>  // b.hs, b.nlast
    5350:	910020c6 	add	x6, x6, #0x8
    5354:	910043e0 	add	x0, sp, #0x10
    5358:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    535c:	d2800003 	mov	x3, #0x0                   	// #0
    5360:	340000f6 	cbz	w22, 537c <fwp_apply+0x118>
    5364:	d503201f 	nop
    5368:	f86368c4 	ldr	x4, [x6, x3]
    536c:	f8236804 	str	x4, [x0, x3]
    5370:	91002063 	add	x3, x3, #0x8
    5374:	eb0300bf 	cmp	x5, x3
    5378:	54ffff81 	b.ne	5368 <fwp_apply+0x104>  // b.any
    537c:	3400013a 	cbz	w26, 53a0 <fwp_apply+0x13c>
    5380:	2a1a03e6 	mov	w6, w26
    5384:	d2800003 	mov	x3, #0x0                   	// #0
    5388:	0b0302c4 	add	w4, w22, w3
    538c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5390:	91000463 	add	x3, x3, #0x1
    5394:	f8247805 	str	x5, [x0, x4, lsl #3]
    5398:	eb0300df 	cmp	x6, x3
    539c:	54ffff61 	b.ne	5388 <fwp_apply+0x124>  // b.any
    53a0:	f94004e3 	ldr	x3, [x7, #8]
    53a4:	1400002c 	b	5454 <fwp_apply+0x1f0>
    53a8:	11000740 	add	w0, w26, #0x1
    53ac:	52800041 	mov	w1, #0x2                   	// #2
    53b0:	f81e83a6 	stur	x6, [x29, #-24]
    53b4:	d37df000 	lsl	x0, x0, #3
    53b8:	97ffff4a 	bl	50e0 <fwp_heap_alloc>
    53bc:	f85e83a6 	ldur	x6, [x29, #-24]
    53c0:	aa0003f3 	mov	x19, x0
    53c4:	b94000c1 	ldr	w1, [x6]
    53c8:	29006801 	stp	w1, w26, [x0]
    53cc:	340000b6 	cbz	w22, 53e0 <fwp_apply+0x17c>
    53d0:	910020c1 	add	x1, x6, #0x8
    53d4:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    53d8:	91002000 	add	x0, x0, #0x8
    53dc:	97fff4a9 	bl	2680 <memmove@plt>
    53e0:	2a1503e3 	mov	w3, w21
    53e4:	d2800000 	mov	x0, #0x0                   	// #0
    53e8:	34000135 	cbz	w21, 540c <fwp_apply+0x1a8>
    53ec:	d503201f 	nop
    53f0:	0b0002c1 	add	w1, w22, w0
    53f4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53f8:	8b010e61 	add	x1, x19, x1, lsl #3
    53fc:	91000400 	add	x0, x0, #0x1
    5400:	f9000422 	str	x2, [x1, #8]
    5404:	eb00007f 	cmp	x3, x0
    5408:	54ffff41 	b.ne	53f0 <fwp_apply+0x18c>  // b.any
    540c:	aa1303e6 	mov	x6, x19
    5410:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5414:	f947f400 	ldr	x0, [x0, #4072]
    5418:	f85f83a2 	ldur	x2, [x29, #-8]
    541c:	f9400001 	ldr	x1, [x0]
    5420:	eb010042 	subs	x2, x2, x1
    5424:	d2800001 	mov	x1, #0x0                   	// #0
    5428:	540002c1 	b.ne	5480 <fwp_apply+0x21c>  // b.any
    542c:	910003bf 	mov	sp, x29
    5430:	aa0603e0 	mov	x0, x6
    5434:	a94153f3 	ldp	x19, x20, [sp, #16]
    5438:	a9425bf5 	ldp	x21, x22, [sp, #32]
    543c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5440:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5444:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5448:	d65f03c0 	ret
    544c:	d10043a0 	sub	x0, x29, #0x10
    5450:	5280001a 	mov	w26, #0x0                   	// #0
    5454:	d63f0060 	blr	x3
    5458:	aa0003e6 	mov	x6, x0
    545c:	6b1a02bf 	cmp	w21, w26
    5460:	54fffd80 	b.eq	5410 <fwp_apply+0x1ac>  // b.none
    5464:	0b1602b6 	add	w22, w21, w22
    5468:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    546c:	4b1902d5 	sub	w21, w22, w25
    5470:	9100031f 	mov	sp, x24
    5474:	17ffff8e 	b	52ac <fwp_apply+0x48>
    5478:	f90203ff 	str	xzr, [sp, #1024]
    547c:	17ffffb5 	b	5350 <fwp_apply+0xec>
    5480:	97fff4e4 	bl	2810 <__stack_chk_fail@plt>

0000000000005484 <fwp_p_ad_push>:
    5484:	f100001f 	cmp	x0, #0x0
    5488:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    548c:	54000eab 	b.lt	5660 <fwp_p_ad_push+0x1dc>  // b.tstop
    5490:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5494:	aa0003e4 	mov	x4, x0
    5498:	910003fd 	mov	x29, sp
    549c:	a9025bf5 	stp	x21, x22, [sp, #32]
    54a0:	aa0003f5 	mov	x21, x0
    54a4:	aa020000 	orr	x0, x0, x2
    54a8:	a90363f7 	stp	x23, x24, [sp, #48]
    54ac:	aa0203f7 	mov	x23, x2
    54b0:	6d0627e8 	stp	d8, d9, [sp, #96]
    54b4:	9e670029 	fmov	d9, x1
    54b8:	9e670068 	fmov	d8, x3
    54bc:	b6f80920 	tbz	x0, #63, 55e0 <fwp_p_ad_push+0x15c>
    54c0:	a90153f3 	stp	x19, x20, [sp, #16]
    54c4:	9360fc80 	asr	x0, x4, #32
    54c8:	b6f800c4 	tbz	x4, #63, 54e0 <fwp_p_ad_push+0x5c>
    54cc:	1e604109 	fmov	d9, d8
    54d0:	2f00e408 	movi	d8, #0x0
    54d4:	9360fc40 	asr	x0, x2, #32
    54d8:	aa0203f5 	mov	x21, x2
    54dc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    54e0:	97fff974 	bl	3ab0 <fwp_tape_of>
    54e4:	aa0003f3 	mov	x19, x0
    54e8:	f9403000 	ldr	x0, [x0, #96]
    54ec:	b5001240 	cbnz	x0, 5734 <fwp_p_ad_push+0x2b0>
    54f0:	f9400a76 	ldr	x22, [x19, #16]
    54f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54f8:	eb0002df 	cmp	x22, x0
    54fc:	54000d8c 	b.gt	56ac <fwp_p_ad_push+0x228>
    5500:	eb3542df 	cmp	x22, w21, uxtw
    5504:	54000cad 	b.le	5698 <fwp_p_ad_push+0x214>
    5508:	b7f80077 	tbnz	x23, #63, 5514 <fwp_p_ad_push+0x90>
    550c:	eb3742df 	cmp	x22, w23, uxtw
    5510:	54000c4d 	b.le	5698 <fwp_p_ad_push+0x214>
    5514:	f9400678 	ldr	x24, [x19, #8]
    5518:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    551c:	cb1802d8 	sub	x24, x22, x24
    5520:	91000701 	add	x1, x24, #0x1
    5524:	eb00003f 	cmp	x1, x0
    5528:	54000c28 	b.hi	56ac <fwp_p_ad_push+0x228>  // b.pmore
    552c:	a9418274 	ldp	x20, x0, [x19, #24]
    5530:	a90573fb 	stp	x27, x28, [sp, #80]
    5534:	eb14003f 	cmp	x1, x20
    5538:	540006ad 	b.le	560c <fwp_p_ad_push+0x188>
    553c:	f100029f 	cmp	x20, #0x0
    5540:	d2800803 	mov	x3, #0x40                  	// #64
    5544:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5548:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    554c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5550:	eb14003f 	cmp	x1, x20
    5554:	5400008d 	b.le	5564 <fwp_p_ad_push+0xe0>
    5558:	eb02029f 	cmp	x20, x2
    555c:	5400054d 	b.le	5604 <fwp_p_ad_push+0x180>
    5560:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5564:	d37df299 	lsl	x25, x20, #3
    5568:	52800022 	mov	w2, #0x1                   	// #1
    556c:	aa1903e1 	mov	x1, x25
    5570:	97fffbad 	bl	4424 <ad_raw_realloc>
    5574:	aa0003e1 	mov	x1, x0
    5578:	b4000a40 	cbz	x0, 56c0 <fwp_p_ad_push+0x23c>
    557c:	f9400e63 	ldr	x3, [x19, #24]
    5580:	f9001261 	str	x1, [x19, #32]
    5584:	f9401a60 	ldr	x0, [x19, #48]
    5588:	52800042 	mov	w2, #0x2                   	// #2
    558c:	8b030821 	add	x1, x1, x3, lsl #2
    5590:	f9001661 	str	x1, [x19, #40]
    5594:	d37cee81 	lsl	x1, x20, #4
    5598:	97fffba3 	bl	4424 <ad_raw_realloc>
    559c:	aa0003e2 	mov	x2, x0
    55a0:	b4000900 	cbz	x0, 56c0 <fwp_p_ad_push+0x23c>
    55a4:	f9400e61 	ldr	x1, [x19, #24]
    55a8:	d37df31b 	lsl	x27, x24, #3
    55ac:	d37ef69a 	lsl	x26, x20, #2
    55b0:	d37ef71c 	lsl	x28, x24, #2
    55b4:	8b190003 	add	x3, x0, x25
    55b8:	8b010c01 	add	x1, x0, x1, lsl #3
    55bc:	a9030660 	stp	x0, x1, [x19, #48]
    55c0:	b5000558 	cbnz	x24, 5668 <fwp_p_ad_push+0x1e4>
    55c4:	f9001e63 	str	x3, [x19, #56]
    55c8:	f9401260 	ldr	x0, [x19, #32]
    55cc:	8b1a0001 	add	x1, x0, x26
    55d0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    55d4:	f9000e74 	str	x20, [x19, #24]
    55d8:	f9001661 	str	x1, [x19, #40]
    55dc:	14000010 	b	561c <fwp_p_ad_push+0x198>
    55e0:	9360fc40 	asr	x0, x2, #32
    55e4:	a90153f3 	stp	x19, x20, [sp, #16]
    55e8:	eb84801f 	cmp	x0, x4, asr #32
    55ec:	54fff7a0 	b.eq	54e0 <fwp_p_ad_push+0x5c>  // b.none
    55f0:	90000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    55f4:	913a6000 	add	x0, x0, #0xe98
    55f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    55fc:	a90573fb 	stp	x27, x28, [sp, #80]
    5600:	97fff860 	bl	3780 <fwp_trap>
    5604:	d37ffa94 	lsl	x20, x20, #1
    5608:	17ffffd2 	b	5550 <fwp_p_ad_push+0xcc>
    560c:	a9428a61 	ldp	x1, x2, [x19, #40]
    5610:	d37ef71c 	lsl	x28, x24, #2
    5614:	f9401e63 	ldr	x3, [x19, #56]
    5618:	d37df31b 	lsl	x27, x24, #3
    561c:	b83c6815 	str	w21, [x0, x28]
    5620:	f10002ff 	cmp	x23, #0x0
    5624:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5628:	92607eb5 	and	x21, x21, #0xffffffff00000000
    562c:	fc3b6849 	str	d9, [x2, x27]
    5630:	aa1602a0 	orr	x0, x21, x22
    5634:	b83c6837 	str	w23, [x1, x28]
    5638:	910006d6 	add	x22, x22, #0x1
    563c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5640:	fc3b6868 	str	d8, [x3, x27]
    5644:	a94573fb 	ldp	x27, x28, [sp, #80]
    5648:	6d4627e8 	ldp	d8, d9, [sp, #96]
    564c:	f9000a76 	str	x22, [x19, #16]
    5650:	a94153f3 	ldp	x19, x20, [sp, #16]
    5654:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5658:	a8c77bfd 	ldp	x29, x30, [sp], #112
    565c:	d65f03c0 	ret
    5660:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5664:	d65f03c0 	ret
    5668:	aa0303e0 	mov	x0, x3
    566c:	aa1b03e2 	mov	x2, x27
    5670:	97fff404 	bl	2680 <memmove@plt>
    5674:	a9420660 	ldp	x0, x1, [x19, #32]
    5678:	aa1c03e2 	mov	x2, x28
    567c:	f9401a63 	ldr	x3, [x19, #48]
    5680:	8b190063 	add	x3, x3, x25
    5684:	f9001e63 	str	x3, [x19, #56]
    5688:	8b1a0000 	add	x0, x0, x26
    568c:	97fff3fd 	bl	2680 <memmove@plt>
    5690:	a9430e62 	ldp	x2, x3, [x19, #48]
    5694:	17ffffcd 	b	55c8 <fwp_p_ad_push+0x144>
    5698:	90000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    569c:	913cc000 	add	x0, x0, #0xf30
    56a0:	a9046bf9 	stp	x25, x26, [sp, #64]
    56a4:	a90573fb 	stp	x27, x28, [sp, #80]
    56a8:	97fff836 	bl	3780 <fwp_trap>
    56ac:	90000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    56b0:	913c4000 	add	x0, x0, #0xf10
    56b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    56b8:	a90573fb 	stp	x27, x28, [sp, #80]
    56bc:	97fff831 	bl	3780 <fwp_trap>
    56c0:	aa1303e0 	mov	x0, x19
    56c4:	97fff634 	bl	2f94 <fwp_tape_unlink_scope>
    56c8:	f9401260 	ldr	x0, [x19, #32]
    56cc:	b4000040 	cbz	x0, 56d4 <fwp_p_ad_push+0x250>
    56d0:	97fffb20 	bl	4350 <ad_raw_free.part.0>
    56d4:	f9401a60 	ldr	x0, [x19, #48]
    56d8:	b4000040 	cbz	x0, 56e0 <fwp_p_ad_push+0x25c>
    56dc:	97fffb1d 	bl	4350 <ad_raw_free.part.0>
    56e0:	f9402260 	ldr	x0, [x19, #64]
    56e4:	b4000040 	cbz	x0, 56ec <fwp_p_ad_push+0x268>
    56e8:	97fffb1a 	bl	4350 <ad_raw_free.part.0>
    56ec:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    56f0:	f947e821 	ldr	x1, [x1, #4048]
    56f4:	f9000e7f 	str	xzr, [x19, #24]
    56f8:	4f000400 	movi	v0.4s, #0x0
    56fc:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5700:	d2800262 	mov	x2, #0x13                  	// #19
    5704:	f9400023 	ldr	x3, [x1]
    5708:	b900067f 	str	wzr, [x19, #4]
    570c:	d2800021 	mov	x1, #0x1                   	// #1
    5710:	90000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    5714:	91266000 	add	x0, x0, #0x998
    5718:	3c808260 	stur	q0, [x19, #8]
    571c:	ad010260 	stp	q0, q0, [x19, #32]
    5720:	97fff47c 	bl	2910 <fwrite@plt>
    5724:	d2800000 	mov	x0, #0x0                   	// #0
    5728:	97fff486 	bl	2940 <fflush@plt>
    572c:	52800cc0 	mov	w0, #0x66                  	// #102
    5730:	97fff494 	bl	2980 <_Exit@plt>
    5734:	90000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    5738:	913b8000 	add	x0, x0, #0xee0
    573c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5740:	a90573fb 	stp	x27, x28, [sp, #80]
    5744:	97fff80f 	bl	3780 <fwp_trap>
    5748:	d503201f 	nop
    574c:	d503201f 	nop

0000000000005750 <w107>:
    5750:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5754:	9e660003 	fmov	x3, d0
    5758:	aa0003e2 	mov	x2, x0
    575c:	910003fd 	mov	x29, sp
    5760:	fd001fea 	str	d10, [sp, #56]
    5764:	1e60400a 	fmov	d10, d0
    5768:	6d0427e8 	stp	d8, d9, [sp, #64]
    576c:	1e604028 	fmov	d8, d1
    5770:	1e600809 	fmul	d9, d0, d0
    5774:	a90153f3 	stp	x19, x20, [sp, #16]
    5778:	aa0103f4 	mov	x20, x1
    577c:	aa0303e1 	mov	x1, x3
    5780:	aa0003f3 	mov	x19, x0
    5784:	a9025bf5 	stp	x21, x22, [sp, #32]
    5788:	f9001bf7 	str	x23, [sp, #48]
    578c:	97ffff3e 	bl	5484 <fwp_p_ad_push>
    5790:	aa0003e5 	mov	x5, x0
    5794:	97fffaac 	bl	4244 <caf61>
    5798:	9e670000 	fmov	d0, x0
    579c:	97fffaaa 	bl	4244 <caf61>
    57a0:	1e693908 	fsub	d8, d8, d9
    57a4:	aa1403e2 	mov	x2, x20
    57a8:	1e614000 	fneg	d0, d0
    57ac:	aa0003e3 	mov	x3, x0
    57b0:	aa0503e0 	mov	x0, x5
    57b4:	9e660117 	fmov	x23, d8
    57b8:	9e660001 	fmov	x1, d0
    57bc:	97ffff32 	bl	5484 <fwp_p_ad_push>
    57c0:	aa0003f5 	mov	x21, x0
    57c4:	97fffaa0 	bl	4244 <caf61>
    57c8:	9e670000 	fmov	d0, x0
    57cc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    57d0:	97fffa9d 	bl	4244 <caf61>
    57d4:	1e614000 	fneg	d0, d0
    57d8:	aa0003e3 	mov	x3, x0
    57dc:	1e6a3929 	fsub	d9, d9, d10
    57e0:	aa1303e0 	mov	x0, x19
    57e4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    57e8:	9e660001 	fmov	x1, d0
    57ec:	9e660136 	fmov	x22, d9
    57f0:	97ffff25 	bl	5484 <fwp_p_ad_push>
    57f4:	1e680908 	fmul	d8, d8, d8
    57f8:	aa0003f4 	mov	x20, x0
    57fc:	aa1703e3 	mov	x3, x23
    5800:	aa1703e1 	mov	x1, x23
    5804:	aa1503e2 	mov	x2, x21
    5808:	aa1503e0 	mov	x0, x21
    580c:	97ffff1e 	bl	5484 <fwp_p_ad_push>
    5810:	aa0003e2 	mov	x2, x0
    5814:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5818:	9e670020 	fmov	d0, x1
    581c:	9e660101 	fmov	x1, d8
    5820:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5824:	1e600908 	fmul	d8, d8, d0
    5828:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    582c:	97ffff16 	bl	5484 <fwp_p_ad_push>
    5830:	1e690929 	fmul	d9, d9, d9
    5834:	aa1603e3 	mov	x3, x22
    5838:	aa1603e1 	mov	x1, x22
    583c:	aa1403e2 	mov	x2, x20
    5840:	aa0003f3 	mov	x19, x0
    5844:	aa1403e0 	mov	x0, x20
    5848:	97ffff0f 	bl	5484 <fwp_p_ad_push>
    584c:	aa0003e5 	mov	x5, x0
    5850:	97fffa7d 	bl	4244 <caf61>
    5854:	aa0003e6 	mov	x6, x0
    5858:	97fffa7b 	bl	4244 <caf61>
    585c:	1e692908 	fadd	d8, d8, d9
    5860:	aa1303e2 	mov	x2, x19
    5864:	aa0603e1 	mov	x1, x6
    5868:	aa0003e3 	mov	x3, x0
    586c:	aa0503e0 	mov	x0, x5
    5870:	97ffff05 	bl	5484 <fwp_p_ad_push>
    5874:	aa0003e1 	mov	x1, x0
    5878:	a94153f3 	ldp	x19, x20, [sp, #16]
    587c:	9e660100 	fmov	x0, d8
    5880:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5884:	f9401bf7 	ldr	x23, [sp, #48]
    5888:	fd401fea 	ldr	d10, [sp, #56]
    588c:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5890:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5894:	d65f03c0 	ret
    5898:	d503201f 	nop
    589c:	d503201f 	nop

00000000000058a0 <w164.constprop.0>:
    58a0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    58a4:	910003fd 	mov	x29, sp
    58a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    58ac:	fd001be8 	str	d8, [sp, #48]
    58b0:	f9400015 	ldr	x21, [x0]
    58b4:	b40003b5 	cbz	x21, 5928 <w164.constprop.0+0x88>
    58b8:	2f00e408 	movi	d8, #0x0
    58bc:	91002016 	add	x22, x0, #0x8
    58c0:	a90153f3 	stp	x19, x20, [sp, #16]
    58c4:	91004014 	add	x20, x0, #0x10
    58c8:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    58cc:	d2800013 	mov	x19, #0x0                   	// #0
    58d0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    58d4:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    58d8:	97fffa5b 	bl	4244 <caf61>
    58dc:	aa0003e6 	mov	x6, x0
    58e0:	97fffa59 	bl	4244 <caf61>
    58e4:	1e602908 	fadd	d8, d8, d0
    58e8:	aa0003e3 	mov	x3, x0
    58ec:	aa0703e2 	mov	x2, x7
    58f0:	aa0503e0 	mov	x0, x5
    58f4:	aa0603e1 	mov	x1, x6
    58f8:	91000a73 	add	x19, x19, #0x2
    58fc:	97fffee2 	bl	5484 <fwp_p_ad_push>
    5900:	aa0003e5 	mov	x5, x0
    5904:	eb1302bf 	cmp	x21, x19
    5908:	54fffe48 	b.hi	58d0 <w164.constprop.0+0x30>  // b.pmore
    590c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5910:	9e660100 	fmov	x0, d8
    5914:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5918:	aa0503e1 	mov	x1, x5
    591c:	fd401be8 	ldr	d8, [sp, #48]
    5920:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5924:	d65f03c0 	ret
    5928:	2f00e408 	movi	d8, #0x0
    592c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    5930:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5934:	aa0503e1 	mov	x1, x5
    5938:	9e660100 	fmov	x0, d8
    593c:	fd401be8 	ldr	d8, [sp, #48]
    5940:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5944:	d65f03c0 	ret
    5948:	d503201f 	nop
    594c:	d503201f 	nop

0000000000005950 <fwp_data.part.0.constprop.0>:
    5950:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5954:	910003fd 	mov	x29, sp
    5958:	a9025bf5 	stp	x21, x22, [sp, #32]
    595c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5960:	910182c2 	add	x2, x22, #0x60
    5964:	a9046bf9 	stp	x25, x26, [sp, #64]
    5968:	b9415059 	ldr	w25, [x2, #336]
    596c:	a90153f3 	stp	x19, x20, [sp, #16]
    5970:	aa0103f4 	mov	x20, x1
    5974:	a90363f7 	stp	x23, x24, [sp, #48]
    5978:	2a0003f7 	mov	w23, w0
    597c:	340000b9 	cbz	w25, 5990 <fwp_data.part.0.constprop.0+0x40>
    5980:	a9558041 	ldp	x1, x0, [x2, #344]
    5984:	91000421 	add	x1, x1, #0x1
    5988:	91006000 	add	x0, x0, #0x18
    598c:	a9158041 	stp	x1, x0, [x2, #344]
    5990:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    5994:	911982a3 	add	x3, x21, #0x660
    5998:	b953a460 	ldr	w0, [x3, #5028]
    599c:	34000840 	cbz	w0, 5aa4 <fwp_data.part.0.constprop.0+0x154>
    59a0:	397e8862 	ldrb	w2, [x3, #4002]
    59a4:	910f0040 	add	x0, x2, #0x3c0
    59a8:	8b020442 	add	x2, x2, x2, lsl #1
    59ac:	d37df042 	lsl	x2, x2, #3
    59b0:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    59b4:	2a1a03f8 	mov	w24, w26
    59b8:	f8626873 	ldr	x19, [x3, x2]
    59bc:	b4000613 	cbz	x19, 5a7c <fwp_data.part.0.constprop.0+0x12c>
    59c0:	f9400260 	ldr	x0, [x19]
    59c4:	aa2003e0 	mvn	x0, x0
    59c8:	f8226860 	str	x0, [x3, x2]
    59cc:	f100631f 	cmp	x24, #0x18
    59d0:	540000e9 	b.ls	59ec <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    59d4:	d1006702 	sub	x2, x24, #0x19
    59d8:	91006260 	add	x0, x19, #0x18
    59dc:	927df042 	and	x2, x2, #0xfffffffffffffff8
    59e0:	52800001 	mov	w1, #0x0                   	// #0
    59e4:	91002042 	add	x2, x2, #0x8
    59e8:	97fff37e 	bl	27e0 <memset@plt>
    59ec:	911982a0 	add	x0, x21, #0x660
    59f0:	f94a1001 	ldr	x1, [x0, #5152]
    59f4:	ab180021 	adds	x1, x1, x24
    59f8:	54000642 	b.cs	5ac0 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    59fc:	f94a1402 	ldr	x2, [x0, #5160]
    5a00:	f90a1001 	str	x1, [x0, #5152]
    5a04:	eb02003f 	cmp	x1, x2
    5a08:	54000049 	b.ls	5a10 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5a0c:	f90a1401 	str	x1, [x0, #5160]
    5a10:	911982a0 	add	x0, x21, #0x660
    5a14:	1e630341 	ucvtf	d1, w26
    5a18:	fd4a1c00 	ldr	d0, [x0, #5176]
    5a1c:	1e612800 	fadd	d0, d0, d1
    5a20:	fd0a1c00 	str	d0, [x0, #5176]
    5a24:	34000139 	cbz	w25, 5a48 <fwp_data.part.0.constprop.0+0xf8>
    5a28:	911982b5 	add	x21, x21, #0x660
    5a2c:	910182d6 	add	x22, x22, #0x60
    5a30:	fd4a12a0 	ldr	d0, [x21, #5152]
    5a34:	6d5686c2 	ldp	d2, d1, [x22, #360]
    5a38:	7e61d800 	ucvtf	d0, d0
    5a3c:	1e623800 	fsub	d0, d0, d2
    5a40:	1e612010 	fcmpe	d0, d1
    5a44:	540003ac 	b.gt	5ab8 <fwp_data.part.0.constprop.0+0x168>
    5a48:	52800040 	mov	w0, #0x2                   	// #2
    5a4c:	29000277 	stp	w23, w0, [x19]
    5a50:	aa1303e0 	mov	x0, x19
    5a54:	f9400281 	ldr	x1, [x20]
    5a58:	f9000661 	str	x1, [x19, #8]
    5a5c:	f9400681 	ldr	x1, [x20, #8]
    5a60:	f9000a61 	str	x1, [x19, #16]
    5a64:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a68:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5a6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5a70:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5a74:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5a78:	d65f03c0 	ret
    5a7c:	8b020063 	add	x3, x3, x2
    5a80:	f9400473 	ldr	x19, [x3, #8]
    5a84:	b4000113 	cbz	x19, 5aa4 <fwp_data.part.0.constprop.0+0x154>
    5a88:	f9400860 	ldr	x0, [x3, #16]
    5a8c:	cb130000 	sub	x0, x0, x19
    5a90:	eb00031f 	cmp	x24, x0
    5a94:	54000088 	b.hi	5aa4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5a98:	8b180260 	add	x0, x19, x24
    5a9c:	f9000460 	str	x0, [x3, #8]
    5aa0:	17ffffcb 	b	59cc <fwp_data.part.0.constprop.0+0x7c>
    5aa4:	52800001 	mov	w1, #0x0                   	// #0
    5aa8:	d2800300 	mov	x0, #0x18                  	// #24
    5aac:	97fffd8d 	bl	50e0 <fwp_heap_alloc>
    5ab0:	aa0003f3 	mov	x19, x0
    5ab4:	17ffffdc 	b	5a24 <fwp_data.part.0.constprop.0+0xd4>
    5ab8:	fd00bac0 	str	d0, [x22, #368]
    5abc:	17ffffe3 	b	5a48 <fwp_data.part.0.constprop.0+0xf8>
    5ac0:	97fff58c 	bl	30f0 <fwp_heap_oom>

0000000000005ac4 <fwp_rc_share>:
    5ac4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xb80>
    5ac8:	91198042 	add	x2, x2, #0x660
    5acc:	f949d843 	ldr	x3, [x2, #5040]
    5ad0:	f949ec41 	ldr	x1, [x2, #5080]
    5ad4:	cb030000 	sub	x0, x0, x3
    5ad8:	eb01401f 	cmp	x0, x1, lsl #16
    5adc:	540002c2 	b.cs	5b34 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5ae0:	d350fc01 	lsr	x1, x0, #16
    5ae4:	f949fc44 	ldr	x4, [x2, #5112]
    5ae8:	8b010821 	add	x1, x1, x1, lsl #2
    5aec:	d37df021 	lsl	x1, x1, #3
    5af0:	8b010083 	add	x3, x4, x1
    5af4:	f9401062 	ldr	x2, [x3, #32]
    5af8:	b40001e2 	cbz	x2, 5b34 <fwp_rc_share+0x70>
    5afc:	38616881 	ldrb	w1, [x4, x1]
    5b00:	7100083f 	cmp	w1, #0x2
    5b04:	540001a0 	b.eq	5b38 <fwp_rc_share+0x74>  // b.none
    5b08:	7100043f 	cmp	w1, #0x1
    5b0c:	54000141 	b.ne	5b34 <fwp_rc_share+0x70>  // b.any
    5b10:	29430464 	ldp	w4, w1, [x3, #24]
    5b14:	92403c00 	and	x0, x0, #0xffff
    5b18:	9b047c00 	mul	x0, x0, x4
    5b1c:	d360fc00 	lsr	x0, x0, #32
    5b20:	eb01001f 	cmp	x0, x1
    5b24:	54000082 	b.cs	5b34 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5b28:	8b000042 	add	x2, x2, x0
    5b2c:	39400040 	ldrb	w0, [x2]
    5b30:	350000a0 	cbnz	w0, 5b44 <fwp_rc_share+0x80>
    5b34:	d65f03c0 	ret
    5b38:	72003c1f 	tst	w0, #0xffff
    5b3c:	54ffff80 	b.eq	5b2c <fwp_rc_share+0x68>  // b.none
    5b40:	d65f03c0 	ret
    5b44:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5b48:	90000040 	adrp	x0, d000 <fwp_main_thread+0x34c>
    5b4c:	913d4000 	add	x0, x0, #0xf50
    5b50:	910003fd 	mov	x29, sp
    5b54:	97fff70b 	bl	3780 <fwp_trap>
    5b58:	d503201f 	nop
    5b5c:	d503201f 	nop

0000000000005b60 <fwp_rc_fresh>:
    5b60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5b64:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb80>
    5b68:	91198063 	add	x3, x3, #0x660
    5b6c:	910003fd 	mov	x29, sp
    5b70:	a90153f3 	stp	x19, x20, [sp, #16]
    5b74:	aa0003f3 	mov	x19, x0
    5b78:	f949d861 	ldr	x1, [x3, #5040]
    5b7c:	f949ec60 	ldr	x0, [x3, #5080]
    5b80:	cb010261 	sub	x1, x19, x1
    5b84:	eb00403f 	cmp	x1, x0, lsl #16
    5b88:	54000322 	b.cs	5bec <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5b8c:	d350fc22 	lsr	x2, x1, #16
    5b90:	f949fc63 	ldr	x3, [x3, #5112]
    5b94:	8b020842 	add	x2, x2, x2, lsl #2
    5b98:	d37df042 	lsl	x2, x2, #3
    5b9c:	8b020060 	add	x0, x3, x2
    5ba0:	f9401014 	ldr	x20, [x0, #32]
    5ba4:	b4000254 	cbz	x20, 5bec <fwp_rc_fresh+0x8c>
    5ba8:	38626862 	ldrb	w2, [x3, x2]
    5bac:	7100085f 	cmp	w2, #0x2
    5bb0:	54000260 	b.eq	5bfc <fwp_rc_fresh+0x9c>  // b.none
    5bb4:	7100045f 	cmp	w2, #0x1
    5bb8:	540001a1 	b.ne	5bec <fwp_rc_fresh+0x8c>  // b.any
    5bbc:	29430002 	ldp	w2, w0, [x0, #24]
    5bc0:	92403c21 	and	x1, x1, #0xffff
    5bc4:	9b027c21 	mul	x1, x1, x2
    5bc8:	d360fc21 	lsr	x1, x1, #32
    5bcc:	eb00003f 	cmp	x1, x0
    5bd0:	540000e2 	b.cs	5bec <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5bd4:	8b010294 	add	x20, x20, x1
    5bd8:	39400280 	ldrb	w0, [x20]
    5bdc:	7103fc1f 	cmp	w0, #0xff
    5be0:	540001a0 	b.eq	5c14 <fwp_rc_fresh+0xb4>  // b.none
    5be4:	52800020 	mov	w0, #0x1                   	// #1
    5be8:	39000280 	strb	w0, [x20]
    5bec:	aa1303e0 	mov	x0, x19
    5bf0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bf4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5bf8:	d65f03c0 	ret
    5bfc:	72003c3f 	tst	w1, #0xffff
    5c00:	54fffec0 	b.eq	5bd8 <fwp_rc_fresh+0x78>  // b.none
    5c04:	aa1303e0 	mov	x0, x19
    5c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c10:	d65f03c0 	ret
    5c14:	aa1403e0 	mov	x0, x20
    5c18:	97fffb72 	bl	49e0 <fwp_rc_forget_slot>
    5c1c:	17fffff2 	b	5be4 <fwp_rc_fresh+0x84>

0000000000005c20 <fwp_rc_free_arr>:
    5c20:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb80>
    5c24:	91198063 	add	x3, x3, #0x660
    5c28:	f949d861 	ldr	x1, [x3, #5040]
    5c2c:	f949ec62 	ldr	x2, [x3, #5080]
    5c30:	cb010001 	sub	x1, x0, x1
    5c34:	eb02403f 	cmp	x1, x2, lsl #16
    5c38:	54000342 	b.cs	5ca0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c3c:	d350fc22 	lsr	x2, x1, #16
    5c40:	f949fc65 	ldr	x5, [x3, #5112]
    5c44:	8b020842 	add	x2, x2, x2, lsl #2
    5c48:	d37df042 	lsl	x2, x2, #3
    5c4c:	8b0200a4 	add	x4, x5, x2
    5c50:	f9401083 	ldr	x3, [x4, #32]
    5c54:	b4000263 	cbz	x3, 5ca0 <fwp_rc_free_arr+0x80>
    5c58:	386268a2 	ldrb	w2, [x5, x2]
    5c5c:	7100085f 	cmp	w2, #0x2
    5c60:	540001c0 	b.eq	5c98 <fwp_rc_free_arr+0x78>  // b.none
    5c64:	7100045f 	cmp	w2, #0x1
    5c68:	540001c1 	b.ne	5ca0 <fwp_rc_free_arr+0x80>  // b.any
    5c6c:	29430885 	ldp	w5, w2, [x4, #24]
    5c70:	92403c21 	and	x1, x1, #0xffff
    5c74:	9b057c21 	mul	x1, x1, x5
    5c78:	d360fc21 	lsr	x1, x1, #32
    5c7c:	eb02003f 	cmp	x1, x2
    5c80:	54000102 	b.cs	5ca0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c84:	8b010063 	add	x3, x3, x1
    5c88:	39400061 	ldrb	w1, [x3]
    5c8c:	7100043f 	cmp	w1, #0x1
    5c90:	54000081 	b.ne	5ca0 <fwp_rc_free_arr+0x80>  // b.any
    5c94:	17fffbf3 	b	4c60 <fwp_mem_free>
    5c98:	72003c3f 	tst	w1, #0xffff
    5c9c:	54ffff60 	b.eq	5c88 <fwp_rc_free_arr+0x68>  // b.none
    5ca0:	d65f03c0 	ret

0000000000005ca4 <fwp_rc_dup>:
    5ca4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xb80>
    5ca8:	91198042 	add	x2, x2, #0x660
    5cac:	f949d841 	ldr	x1, [x2, #5040]
    5cb0:	f949ec43 	ldr	x3, [x2, #5080]
    5cb4:	cb010001 	sub	x1, x0, x1
    5cb8:	eb03403f 	cmp	x1, x3, lsl #16
    5cbc:	540003c2 	b.cs	5d34 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5cc0:	d350fc20 	lsr	x0, x1, #16
    5cc4:	f949fc44 	ldr	x4, [x2, #5112]
    5cc8:	8b000800 	add	x0, x0, x0, lsl #2
    5ccc:	d37df002 	lsl	x2, x0, #3
    5cd0:	8b020083 	add	x3, x4, x2
    5cd4:	f9401060 	ldr	x0, [x3, #32]
    5cd8:	b40002e0 	cbz	x0, 5d34 <fwp_rc_dup+0x90>
    5cdc:	38626882 	ldrb	w2, [x4, x2]
    5ce0:	7100085f 	cmp	w2, #0x2
    5ce4:	540002a0 	b.eq	5d38 <fwp_rc_dup+0x94>  // b.none
    5ce8:	7100045f 	cmp	w2, #0x1
    5cec:	54000241 	b.ne	5d34 <fwp_rc_dup+0x90>  // b.any
    5cf0:	29430864 	ldp	w4, w2, [x3, #24]
    5cf4:	92403c21 	and	x1, x1, #0xffff
    5cf8:	9b047c21 	mul	x1, x1, x4
    5cfc:	d360fc21 	lsr	x1, x1, #32
    5d00:	eb02003f 	cmp	x1, x2
    5d04:	54000182 	b.cs	5d34 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5d08:	8b010000 	add	x0, x0, x1
    5d0c:	39400001 	ldrb	w1, [x0]
    5d10:	34000121 	cbz	w1, 5d34 <fwp_rc_dup+0x90>
    5d14:	f00000c2 	adrp	x2, 20000 <__data_start>
    5d18:	91018042 	add	x2, x2, #0x60
    5d1c:	b9415043 	ldr	w3, [x2, #336]
    5d20:	35000123 	cbnz	w3, 5d44 <fwp_rc_dup+0xa0>
    5d24:	7103f43f 	cmp	w1, #0xfd
    5d28:	54000168 	b.hi	5d54 <fwp_rc_dup+0xb0>  // b.pmore
    5d2c:	11000421 	add	w1, w1, #0x1
    5d30:	39000001 	strb	w1, [x0]
    5d34:	d65f03c0 	ret
    5d38:	72003c3f 	tst	w1, #0xffff
    5d3c:	54fffe80 	b.eq	5d0c <fwp_rc_dup+0x68>  // b.none
    5d40:	d65f03c0 	ret
    5d44:	f940bc43 	ldr	x3, [x2, #376]
    5d48:	91000463 	add	x3, x3, #0x1
    5d4c:	f900bc43 	str	x3, [x2, #376]
    5d50:	17fffff5 	b	5d24 <fwp_rc_dup+0x80>
    5d54:	17fffadc 	b	48c4 <fwp_rc_wide_dup>
    5d58:	d503201f 	nop
    5d5c:	d503201f 	nop

0000000000005d60 <fwp_owned_entry161>:
    5d60:	d10103ff 	sub	sp, sp, #0x40
    5d64:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5d68:	f947f442 	ldr	x2, [x2, #4072]
    5d6c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5d70:	910083fd 	add	x29, sp, #0x20
    5d74:	a90353f3 	stp	x19, x20, [sp, #48]
    5d78:	f9400043 	ldr	x3, [x2]
    5d7c:	f9000fe3 	str	x3, [sp, #24]
    5d80:	d2800003 	mov	x3, #0x0                   	// #0
    5d84:	a9400c01 	ldp	x1, x3, [x0]
    5d88:	f9400802 	ldr	x2, [x0, #16]
    5d8c:	ab020022 	adds	x2, x1, x2
    5d90:	540006e6 	b.vs	5e6c <fwp_owned_entry161+0x10c>
    5d94:	910023e1 	add	x1, sp, #0x8
    5d98:	52800000 	mov	w0, #0x0                   	// #0
    5d9c:	a9008be3 	stp	x3, x2, [sp, #8]
    5da0:	97fffeec 	bl	5950 <fwp_data.part.0.constprop.0>
    5da4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb80>
    5da8:	91198063 	add	x3, x3, #0x660
    5dac:	aa0003f3 	mov	x19, x0
    5db0:	f949d861 	ldr	x1, [x3, #5040]
    5db4:	f949ec60 	ldr	x0, [x3, #5080]
    5db8:	cb010261 	sub	x1, x19, x1
    5dbc:	eb00403f 	cmp	x1, x0, lsl #16
    5dc0:	54000322 	b.cs	5e24 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5dc4:	d350fc22 	lsr	x2, x1, #16
    5dc8:	f949fc63 	ldr	x3, [x3, #5112]
    5dcc:	8b020842 	add	x2, x2, x2, lsl #2
    5dd0:	d37df042 	lsl	x2, x2, #3
    5dd4:	8b020060 	add	x0, x3, x2
    5dd8:	f9401014 	ldr	x20, [x0, #32]
    5ddc:	b4000254 	cbz	x20, 5e24 <fwp_owned_entry161+0xc4>
    5de0:	38626862 	ldrb	w2, [x3, x2]
    5de4:	7100085f 	cmp	w2, #0x2
    5de8:	54000360 	b.eq	5e54 <fwp_owned_entry161+0xf4>  // b.none
    5dec:	7100045f 	cmp	w2, #0x1
    5df0:	540001a1 	b.ne	5e24 <fwp_owned_entry161+0xc4>  // b.any
    5df4:	29430002 	ldp	w2, w0, [x0, #24]
    5df8:	92403c21 	and	x1, x1, #0xffff
    5dfc:	9b027c21 	mul	x1, x1, x2
    5e00:	d360fc21 	lsr	x1, x1, #32
    5e04:	eb00003f 	cmp	x1, x0
    5e08:	540000e2 	b.cs	5e24 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5e0c:	8b010294 	add	x20, x20, x1
    5e10:	39400280 	ldrb	w0, [x20]
    5e14:	7103fc1f 	cmp	w0, #0xff
    5e18:	54000240 	b.eq	5e60 <fwp_owned_entry161+0x100>  // b.none
    5e1c:	52800020 	mov	w0, #0x1                   	// #1
    5e20:	39000280 	strb	w0, [x20]
    5e24:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5e28:	f947f400 	ldr	x0, [x0, #4072]
    5e2c:	f9400fe2 	ldr	x2, [sp, #24]
    5e30:	f9400001 	ldr	x1, [x0]
    5e34:	eb010042 	subs	x2, x2, x1
    5e38:	d2800001 	mov	x1, #0x0                   	// #0
    5e3c:	540001a1 	b.ne	5e70 <fwp_owned_entry161+0x110>  // b.any
    5e40:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5e44:	aa1303e0 	mov	x0, x19
    5e48:	a94353f3 	ldp	x19, x20, [sp, #48]
    5e4c:	910103ff 	add	sp, sp, #0x40
    5e50:	d65f03c0 	ret
    5e54:	72003c3f 	tst	w1, #0xffff
    5e58:	54fffe61 	b.ne	5e24 <fwp_owned_entry161+0xc4>  // b.any
    5e5c:	17ffffed 	b	5e10 <fwp_owned_entry161+0xb0>
    5e60:	aa1403e0 	mov	x0, x20
    5e64:	97fffadf 	bl	49e0 <fwp_rc_forget_slot>
    5e68:	17ffffed 	b	5e1c <fwp_owned_entry161+0xbc>
    5e6c:	97fff2e5 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5e70:	97fff268 	bl	2810 <__stack_chk_fail@plt>

0000000000005e74 <e161>:
    5e74:	d10103ff 	sub	sp, sp, #0x40
    5e78:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5e7c:	f947f442 	ldr	x2, [x2, #4072]
    5e80:	a9027bfd 	stp	x29, x30, [sp, #32]
    5e84:	910083fd 	add	x29, sp, #0x20
    5e88:	a90353f3 	stp	x19, x20, [sp, #48]
    5e8c:	f9400043 	ldr	x3, [x2]
    5e90:	f9000fe3 	str	x3, [sp, #24]
    5e94:	d2800003 	mov	x3, #0x0                   	// #0
    5e98:	a9400c01 	ldp	x1, x3, [x0]
    5e9c:	f9400802 	ldr	x2, [x0, #16]
    5ea0:	ab020022 	adds	x2, x1, x2
    5ea4:	54000726 	b.vs	5f88 <e161+0x114>
    5ea8:	910023e1 	add	x1, sp, #0x8
    5eac:	52800000 	mov	w0, #0x0                   	// #0
    5eb0:	a9008be3 	stp	x3, x2, [sp, #8]
    5eb4:	97fffea7 	bl	5950 <fwp_data.part.0.constprop.0>
    5eb8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb80>
    5ebc:	91198063 	add	x3, x3, #0x660
    5ec0:	aa0003f3 	mov	x19, x0
    5ec4:	f949d861 	ldr	x1, [x3, #5040]
    5ec8:	f949ec60 	ldr	x0, [x3, #5080]
    5ecc:	cb010261 	sub	x1, x19, x1
    5ed0:	eb00403f 	cmp	x1, x0, lsl #16
    5ed4:	54000322 	b.cs	5f38 <e161+0xc4>  // b.hs, b.nlast
    5ed8:	d350fc22 	lsr	x2, x1, #16
    5edc:	f949fc63 	ldr	x3, [x3, #5112]
    5ee0:	8b020842 	add	x2, x2, x2, lsl #2
    5ee4:	d37df042 	lsl	x2, x2, #3
    5ee8:	8b020060 	add	x0, x3, x2
    5eec:	f9401014 	ldr	x20, [x0, #32]
    5ef0:	b4000254 	cbz	x20, 5f38 <e161+0xc4>
    5ef4:	38626862 	ldrb	w2, [x3, x2]
    5ef8:	7100085f 	cmp	w2, #0x2
    5efc:	540003a0 	b.eq	5f70 <e161+0xfc>  // b.none
    5f00:	7100045f 	cmp	w2, #0x1
    5f04:	540001a1 	b.ne	5f38 <e161+0xc4>  // b.any
    5f08:	29430002 	ldp	w2, w0, [x0, #24]
    5f0c:	92403c21 	and	x1, x1, #0xffff
    5f10:	9b027c21 	mul	x1, x1, x2
    5f14:	d360fc21 	lsr	x1, x1, #32
    5f18:	eb00003f 	cmp	x1, x0
    5f1c:	540000e2 	b.cs	5f38 <e161+0xc4>  // b.hs, b.nlast
    5f20:	8b010294 	add	x20, x20, x1
    5f24:	39400280 	ldrb	w0, [x20]
    5f28:	7103fc1f 	cmp	w0, #0xff
    5f2c:	54000280 	b.eq	5f7c <e161+0x108>  // b.none
    5f30:	52800020 	mov	w0, #0x1                   	// #1
    5f34:	39000280 	strb	w0, [x20]
    5f38:	aa1303e0 	mov	x0, x19
    5f3c:	97fffee2 	bl	5ac4 <fwp_rc_share>
    5f40:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5f44:	f947f400 	ldr	x0, [x0, #4072]
    5f48:	f9400fe2 	ldr	x2, [sp, #24]
    5f4c:	f9400001 	ldr	x1, [x0]
    5f50:	eb010042 	subs	x2, x2, x1
    5f54:	d2800001 	mov	x1, #0x0                   	// #0
    5f58:	540001a1 	b.ne	5f8c <e161+0x118>  // b.any
    5f5c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5f60:	aa1303e0 	mov	x0, x19
    5f64:	a94353f3 	ldp	x19, x20, [sp, #48]
    5f68:	910103ff 	add	sp, sp, #0x40
    5f6c:	d65f03c0 	ret
    5f70:	72003c3f 	tst	w1, #0xffff
    5f74:	54fffe21 	b.ne	5f38 <e161+0xc4>  // b.any
    5f78:	17ffffeb 	b	5f24 <e161+0xb0>
    5f7c:	aa1403e0 	mov	x0, x20
    5f80:	97fffa98 	bl	49e0 <fwp_rc_forget_slot>
    5f84:	17ffffeb 	b	5f30 <e161+0xbc>
    5f88:	97fff29e 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5f8c:	97fff221 	bl	2810 <__stack_chk_fail@plt>

0000000000005f90 <fwp_drop1>:
    5f90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f94:	910003fd 	mov	x29, sp
    5f98:	a90153f3 	stp	x19, x20, [sp, #16]
    5f9c:	f90013f5 	str	x21, [sp, #32]
    5fa0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xb80>
    5fa4:	911982b4 	add	x20, x21, #0x660
    5fa8:	f949da81 	ldr	x1, [x20, #5040]
    5fac:	f949ee82 	ldr	x2, [x20, #5080]
    5fb0:	cb010001 	sub	x1, x0, x1
    5fb4:	eb02403f 	cmp	x1, x2, lsl #16
    5fb8:	54000382 	b.cs	6028 <fwp_drop1+0x98>  // b.hs, b.nlast
    5fbc:	d350fc22 	lsr	x2, x1, #16
    5fc0:	f949fe84 	ldr	x4, [x20, #5112]
    5fc4:	8b020842 	add	x2, x2, x2, lsl #2
    5fc8:	d37df042 	lsl	x2, x2, #3
    5fcc:	8b020083 	add	x3, x4, x2
    5fd0:	f9401073 	ldr	x19, [x3, #32]
    5fd4:	b40002b3 	cbz	x19, 6028 <fwp_drop1+0x98>
    5fd8:	38626882 	ldrb	w2, [x4, x2]
    5fdc:	7100085f 	cmp	w2, #0x2
    5fe0:	540002c0 	b.eq	6038 <fwp_drop1+0xa8>  // b.none
    5fe4:	7100045f 	cmp	w2, #0x1
    5fe8:	54000201 	b.ne	6028 <fwp_drop1+0x98>  // b.any
    5fec:	29430864 	ldp	w4, w2, [x3, #24]
    5ff0:	92403c21 	and	x1, x1, #0xffff
    5ff4:	9b047c21 	mul	x1, x1, x4
    5ff8:	d360fc21 	lsr	x1, x1, #32
    5ffc:	eb02003f 	cmp	x1, x2
    6000:	54000142 	b.cs	6028 <fwp_drop1+0x98>  // b.hs, b.nlast
    6004:	8b010273 	add	x19, x19, x1
    6008:	39400261 	ldrb	w1, [x19]
    600c:	340000e1 	cbz	w1, 6028 <fwp_drop1+0x98>
    6010:	7100043f 	cmp	w1, #0x1
    6014:	540001e0 	b.eq	6050 <fwp_drop1+0xc0>  // b.none
    6018:	7103fc3f 	cmp	w1, #0xff
    601c:	540002e0 	b.eq	6078 <fwp_drop1+0xe8>  // b.none
    6020:	51000421 	sub	w1, w1, #0x1
    6024:	39000261 	strb	w1, [x19]
    6028:	a94153f3 	ldp	x19, x20, [sp, #16]
    602c:	f94013f5 	ldr	x21, [sp, #32]
    6030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6034:	d65f03c0 	ret
    6038:	72003c3f 	tst	w1, #0xffff
    603c:	54fffe60 	b.eq	6008 <fwp_drop1+0x78>  // b.none
    6040:	a94153f3 	ldp	x19, x20, [sp, #16]
    6044:	f94013f5 	ldr	x21, [sp, #32]
    6048:	a8c37bfd 	ldp	x29, x30, [sp], #48
    604c:	d65f03c0 	ret
    6050:	f9400813 	ldr	x19, [x0, #16]
    6054:	97fffef3 	bl	5c20 <fwp_rc_free_arr>
    6058:	911982a0 	add	x0, x21, #0x660
    605c:	f949d801 	ldr	x1, [x0, #5040]
    6060:	f949ec00 	ldr	x0, [x0, #5080]
    6064:	cb010261 	sub	x1, x19, x1
    6068:	eb00403f 	cmp	x1, x0, lsl #16
    606c:	54fffde2 	b.cs	6028 <fwp_drop1+0x98>  // b.hs, b.nlast
    6070:	aa1303e0 	mov	x0, x19
    6074:	17ffffd2 	b	5fbc <fwp_drop1+0x2c>
    6078:	ca534660 	eor	x0, x19, x19, lsr #17
    607c:	911982b5 	add	x21, x21, #0x660
    6080:	ca402400 	eor	x0, x0, x0, lsr #9
    6084:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6088:	f94a2400 	ldr	x0, [x0, #5192]
    608c:	b5000080 	cbnz	x0, 609c <fwp_drop1+0x10c>
    6090:	14000010 	b	60d0 <fwp_drop1+0x140>
    6094:	f9400800 	ldr	x0, [x0, #16]
    6098:	b40001c0 	cbz	x0, 60d0 <fwp_drop1+0x140>
    609c:	f9400001 	ldr	x1, [x0]
    60a0:	eb13003f 	cmp	x1, x19
    60a4:	54ffff81 	b.ne	6094 <fwp_drop1+0x104>  // b.any
    60a8:	f9400401 	ldr	x1, [x0, #8]
    60ac:	d1000421 	sub	x1, x1, #0x1
    60b0:	f9000401 	str	x1, [x0, #8]
    60b4:	f103f83f 	cmp	x1, #0xfe
    60b8:	54fffb81 	b.ne	6028 <fwp_drop1+0x98>  // b.any
    60bc:	aa1303e0 	mov	x0, x19
    60c0:	97fffa48 	bl	49e0 <fwp_rc_forget_slot>
    60c4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    60c8:	39000260 	strb	w0, [x19]
    60cc:	17ffffd7 	b	6028 <fwp_drop1+0x98>
    60d0:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    60d4:	91394000 	add	x0, x0, #0xe50
    60d8:	97fff5aa 	bl	3780 <fwp_trap>
    60dc:	d503201f 	nop

00000000000060e0 <fwp_drop0>:
    60e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    60e4:	910003fd 	mov	x29, sp
    60e8:	a90153f3 	stp	x19, x20, [sp, #16]
    60ec:	f90013f5 	str	x21, [sp, #32]
    60f0:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xb80>
    60f4:	911982b4 	add	x20, x21, #0x660
    60f8:	f949da81 	ldr	x1, [x20, #5040]
    60fc:	f949ee82 	ldr	x2, [x20, #5080]
    6100:	cb010001 	sub	x1, x0, x1
    6104:	eb02403f 	cmp	x1, x2, lsl #16
    6108:	54000382 	b.cs	6178 <fwp_drop0+0x98>  // b.hs, b.nlast
    610c:	d350fc22 	lsr	x2, x1, #16
    6110:	f949fe84 	ldr	x4, [x20, #5112]
    6114:	8b020842 	add	x2, x2, x2, lsl #2
    6118:	d37df042 	lsl	x2, x2, #3
    611c:	8b020083 	add	x3, x4, x2
    6120:	f9401073 	ldr	x19, [x3, #32]
    6124:	b40002b3 	cbz	x19, 6178 <fwp_drop0+0x98>
    6128:	38626882 	ldrb	w2, [x4, x2]
    612c:	7100085f 	cmp	w2, #0x2
    6130:	540002c0 	b.eq	6188 <fwp_drop0+0xa8>  // b.none
    6134:	7100045f 	cmp	w2, #0x1
    6138:	54000201 	b.ne	6178 <fwp_drop0+0x98>  // b.any
    613c:	29430864 	ldp	w4, w2, [x3, #24]
    6140:	92403c21 	and	x1, x1, #0xffff
    6144:	9b047c21 	mul	x1, x1, x4
    6148:	d360fc21 	lsr	x1, x1, #32
    614c:	eb02003f 	cmp	x1, x2
    6150:	54000142 	b.cs	6178 <fwp_drop0+0x98>  // b.hs, b.nlast
    6154:	8b010273 	add	x19, x19, x1
    6158:	39400261 	ldrb	w1, [x19]
    615c:	340000e1 	cbz	w1, 6178 <fwp_drop0+0x98>
    6160:	7100043f 	cmp	w1, #0x1
    6164:	540001e0 	b.eq	61a0 <fwp_drop0+0xc0>  // b.none
    6168:	7103fc3f 	cmp	w1, #0xff
    616c:	540002e0 	b.eq	61c8 <fwp_drop0+0xe8>  // b.none
    6170:	51000421 	sub	w1, w1, #0x1
    6174:	39000261 	strb	w1, [x19]
    6178:	a94153f3 	ldp	x19, x20, [sp, #16]
    617c:	f94013f5 	ldr	x21, [sp, #32]
    6180:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6184:	d65f03c0 	ret
    6188:	72003c3f 	tst	w1, #0xffff
    618c:	54fffe60 	b.eq	6158 <fwp_drop0+0x78>  // b.none
    6190:	a94153f3 	ldp	x19, x20, [sp, #16]
    6194:	f94013f5 	ldr	x21, [sp, #32]
    6198:	a8c37bfd 	ldp	x29, x30, [sp], #48
    619c:	d65f03c0 	ret
    61a0:	f9400813 	ldr	x19, [x0, #16]
    61a4:	97fffe9f 	bl	5c20 <fwp_rc_free_arr>
    61a8:	911982a0 	add	x0, x21, #0x660
    61ac:	f949d801 	ldr	x1, [x0, #5040]
    61b0:	f949ec00 	ldr	x0, [x0, #5080]
    61b4:	cb010261 	sub	x1, x19, x1
    61b8:	eb00403f 	cmp	x1, x0, lsl #16
    61bc:	54fffde2 	b.cs	6178 <fwp_drop0+0x98>  // b.hs, b.nlast
    61c0:	aa1303e0 	mov	x0, x19
    61c4:	17ffffd2 	b	610c <fwp_drop0+0x2c>
    61c8:	ca534660 	eor	x0, x19, x19, lsr #17
    61cc:	911982b5 	add	x21, x21, #0x660
    61d0:	ca402400 	eor	x0, x0, x0, lsr #9
    61d4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    61d8:	f94a2400 	ldr	x0, [x0, #5192]
    61dc:	b5000080 	cbnz	x0, 61ec <fwp_drop0+0x10c>
    61e0:	14000010 	b	6220 <fwp_drop0+0x140>
    61e4:	f9400800 	ldr	x0, [x0, #16]
    61e8:	b40001c0 	cbz	x0, 6220 <fwp_drop0+0x140>
    61ec:	f9400001 	ldr	x1, [x0]
    61f0:	eb13003f 	cmp	x1, x19
    61f4:	54ffff81 	b.ne	61e4 <fwp_drop0+0x104>  // b.any
    61f8:	f9400401 	ldr	x1, [x0, #8]
    61fc:	d1000421 	sub	x1, x1, #0x1
    6200:	f9000401 	str	x1, [x0, #8]
    6204:	f103f83f 	cmp	x1, #0xfe
    6208:	54fffb81 	b.ne	6178 <fwp_drop0+0x98>  // b.any
    620c:	aa1303e0 	mov	x0, x19
    6210:	97fff9f4 	bl	49e0 <fwp_rc_forget_slot>
    6214:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6218:	39000260 	strb	w0, [x19]
    621c:	17ffffd7 	b	6178 <fwp_drop0+0x98>
    6220:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    6224:	91394000 	add	x0, x0, #0xe50
    6228:	97fff556 	bl	3780 <fwp_trap>
    622c:	d503201f 	nop

0000000000006230 <fwp_arg_drop12>:
    6230:	7100003f 	cmp	w1, #0x0
    6234:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6238:	54000041 	b.ne	6240 <fwp_arg_drop12+0x10>  // b.any
    623c:	d65f03c0 	ret
    6240:	f9400000 	ldr	x0, [x0]
    6244:	17ffffa7 	b	60e0 <fwp_drop0>
    6248:	d503201f 	nop
    624c:	d503201f 	nop

0000000000006250 <fwp_closure_drop>:
    6250:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xb80>
    6254:	911980a4 	add	x4, x5, #0x660
    6258:	aa0003e1 	mov	x1, x0
    625c:	f949d882 	ldr	x2, [x4, #5040]
    6260:	f949ec80 	ldr	x0, [x4, #5080]
    6264:	cb020022 	sub	x2, x1, x2
    6268:	eb00405f 	cmp	x2, x0, lsl #16
    626c:	54000662 	b.cs	6338 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6270:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6274:	d350fc43 	lsr	x3, x2, #16
    6278:	910003fd 	mov	x29, sp
    627c:	8b030863 	add	x3, x3, x3, lsl #2
    6280:	f949fc84 	ldr	x4, [x4, #5112]
    6284:	d37df063 	lsl	x3, x3, #3
    6288:	f9000bf3 	str	x19, [sp, #16]
    628c:	8b030080 	add	x0, x4, x3
    6290:	f9401013 	ldr	x19, [x0, #32]
    6294:	b40002b3 	cbz	x19, 62e8 <fwp_closure_drop+0x98>
    6298:	38636883 	ldrb	w3, [x4, x3]
    629c:	7100087f 	cmp	w3, #0x2
    62a0:	54000420 	b.eq	6324 <fwp_closure_drop+0xd4>  // b.none
    62a4:	7100047f 	cmp	w3, #0x1
    62a8:	54000201 	b.ne	62e8 <fwp_closure_drop+0x98>  // b.any
    62ac:	29430003 	ldp	w3, w0, [x0, #24]
    62b0:	92403c42 	and	x2, x2, #0xffff
    62b4:	9b037c42 	mul	x2, x2, x3
    62b8:	d360fc42 	lsr	x2, x2, #32
    62bc:	eb00005f 	cmp	x2, x0
    62c0:	54000142 	b.cs	62e8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    62c4:	8b020273 	add	x19, x19, x2
    62c8:	39400260 	ldrb	w0, [x19]
    62cc:	340000e0 	cbz	w0, 62e8 <fwp_closure_drop+0x98>
    62d0:	7100041f 	cmp	w0, #0x1
    62d4:	54000100 	b.eq	62f4 <fwp_closure_drop+0xa4>  // b.none
    62d8:	7103fc1f 	cmp	w0, #0xff
    62dc:	54000300 	b.eq	633c <fwp_closure_drop+0xec>  // b.none
    62e0:	51000400 	sub	w0, w0, #0x1
    62e4:	39000260 	strb	w0, [x19]
    62e8:	f9400bf3 	ldr	x19, [sp, #16]
    62ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62f0:	d65f03c0 	ret
    62f4:	d53bd040 	mrs	x0, tpidr_el0
    62f8:	91400000 	add	x0, x0, #0x0, lsl #12
    62fc:	91004000 	add	x0, x0, #0x10
    6300:	f9400000 	ldr	x0, [x0]
    6304:	b4000080 	cbz	x0, 6314 <fwp_closure_drop+0xc4>
    6308:	f9400bf3 	ldr	x19, [sp, #16]
    630c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6310:	17fff535 	b	37e4 <fwp_closure_drop_push>
    6314:	f9400bf3 	ldr	x19, [sp, #16]
    6318:	aa0103e0 	mov	x0, x1
    631c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6320:	17fff5a0 	b	39a0 <fwp_closure_drop.part.0>
    6324:	72003c5f 	tst	w2, #0xffff
    6328:	54fffd00 	b.eq	62c8 <fwp_closure_drop+0x78>  // b.none
    632c:	f9400bf3 	ldr	x19, [sp, #16]
    6330:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6334:	d65f03c0 	ret
    6338:	d65f03c0 	ret
    633c:	ca534660 	eor	x0, x19, x19, lsr #17
    6340:	911980a5 	add	x5, x5, #0x660
    6344:	ca402400 	eor	x0, x0, x0, lsr #9
    6348:	8b200ca0 	add	x0, x5, w0, uxtb #3
    634c:	f94a2400 	ldr	x0, [x0, #5192]
    6350:	b5000080 	cbnz	x0, 6360 <fwp_closure_drop+0x110>
    6354:	14000010 	b	6394 <fwp_closure_drop+0x144>
    6358:	f9400800 	ldr	x0, [x0, #16]
    635c:	b40001c0 	cbz	x0, 6394 <fwp_closure_drop+0x144>
    6360:	f9400001 	ldr	x1, [x0]
    6364:	eb13003f 	cmp	x1, x19
    6368:	54ffff81 	b.ne	6358 <fwp_closure_drop+0x108>  // b.any
    636c:	f9400401 	ldr	x1, [x0, #8]
    6370:	d1000421 	sub	x1, x1, #0x1
    6374:	f9000401 	str	x1, [x0, #8]
    6378:	f103f83f 	cmp	x1, #0xfe
    637c:	54fffb61 	b.ne	62e8 <fwp_closure_drop+0x98>  // b.any
    6380:	aa1303e0 	mov	x0, x19
    6384:	97fff997 	bl	49e0 <fwp_rc_forget_slot>
    6388:	12800020 	mov	w0, #0xfffffffe            	// #-2
    638c:	39000260 	strb	w0, [x19]
    6390:	17ffffd6 	b	62e8 <fwp_closure_drop+0x98>
    6394:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    6398:	91394000 	add	x0, x0, #0xe50
    639c:	97fff4f9 	bl	3780 <fwp_trap>

00000000000063a0 <fwp_owned_tape_release>:
    63a0:	b4000940 	cbz	x0, 64c8 <fwp_owned_tape_release+0x128>
    63a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    63a8:	910003fd 	mov	x29, sp
    63ac:	a90153f3 	stp	x19, x20, [sp, #16]
    63b0:	aa0003f3 	mov	x19, x0
    63b4:	f9400000 	ldr	x0, [x0]
    63b8:	b4000060 	cbz	x0, 63c4 <fwp_owned_tape_release+0x24>
    63bc:	f9400661 	ldr	x1, [x19, #8]
    63c0:	f9000401 	str	x1, [x0, #8]
    63c4:	f9400661 	ldr	x1, [x19, #8]
    63c8:	b4000041 	cbz	x1, 63d0 <fwp_owned_tape_release+0x30>
    63cc:	f9000020 	str	x0, [x1]
    63d0:	f9400a60 	ldr	x0, [x19, #16]
    63d4:	f9403401 	ldr	x1, [x0, #104]
    63d8:	b40005c1 	cbz	x1, 6490 <fwp_owned_tape_release+0xf0>
    63dc:	a9450a60 	ldp	x0, x2, [x19, #80]
    63e0:	eb00005f 	cmp	x2, x0
    63e4:	540002ed 	b.le	6440 <fwp_owned_tape_release+0xa0>
    63e8:	d2800014 	mov	x20, #0x0                   	// #0
    63ec:	f90013f5 	str	x21, [sp, #32]
    63f0:	d2800015 	mov	x21, #0x0                   	// #0
    63f4:	d503201f 	nop
    63f8:	f9402260 	ldr	x0, [x19, #64]
    63fc:	910006b5 	add	x21, x21, #0x1
    6400:	f8746800 	ldr	x0, [x0, x20]
    6404:	d63f0020 	blr	x1
    6408:	f9402260 	ldr	x0, [x19, #64]
    640c:	f9400a61 	ldr	x1, [x19, #16]
    6410:	8b140000 	add	x0, x0, x20
    6414:	91004294 	add	x20, x20, #0x10
    6418:	f9400400 	ldr	x0, [x0, #8]
    641c:	f9403421 	ldr	x1, [x1, #104]
    6420:	d63f0020 	blr	x1
    6424:	a9450261 	ldp	x1, x0, [x19, #80]
    6428:	cb010000 	sub	x0, x0, x1
    642c:	eb15001f 	cmp	x0, x21
    6430:	f9400a60 	ldr	x0, [x19, #16]
    6434:	f9403401 	ldr	x1, [x0, #104]
    6438:	54fffe0c 	b.gt	63f8 <fwp_owned_tape_release+0x58>
    643c:	f94013f5 	ldr	x21, [sp, #32]
    6440:	f9403663 	ldr	x3, [x19, #104]
    6444:	f9401262 	ldr	x2, [x19, #32]
    6448:	f100007f 	cmp	x3, #0x0
    644c:	540001ed 	b.le	6488 <fwp_owned_tape_release+0xe8>
    6450:	d2800014 	mov	x20, #0x0                   	// #0
    6454:	d503201f 	nop
    6458:	f9402660 	ldr	x0, [x19, #72]
    645c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6460:	eb02001f 	cmp	x0, x2
    6464:	540000c0 	b.eq	647c <fwp_owned_tape_release+0xdc>  // b.none
    6468:	d63f0020 	blr	x1
    646c:	f9400a60 	ldr	x0, [x19, #16]
    6470:	f9401262 	ldr	x2, [x19, #32]
    6474:	f9403663 	ldr	x3, [x19, #104]
    6478:	f9403401 	ldr	x1, [x0, #104]
    647c:	91000694 	add	x20, x20, #0x1
    6480:	eb14007f 	cmp	x3, x20
    6484:	54fffeac 	b.gt	6458 <fwp_owned_tape_release+0xb8>
    6488:	aa0203e0 	mov	x0, x2
    648c:	d63f0020 	blr	x1
    6490:	f9401660 	ldr	x0, [x19, #40]
    6494:	97ffff6f 	bl	6250 <fwp_closure_drop>
    6498:	f9401a60 	ldr	x0, [x19, #48]
    649c:	97ffff6d 	bl	6250 <fwp_closure_drop>
    64a0:	f9401e60 	ldr	x0, [x19, #56]
    64a4:	97ffff6b 	bl	6250 <fwp_closure_drop>
    64a8:	f9402260 	ldr	x0, [x19, #64]
    64ac:	97fff9ed 	bl	4c60 <fwp_mem_free>
    64b0:	f9402660 	ldr	x0, [x19, #72]
    64b4:	97fff9eb 	bl	4c60 <fwp_mem_free>
    64b8:	aa1303e0 	mov	x0, x19
    64bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    64c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    64c4:	17fff9e7 	b	4c60 <fwp_mem_free>
    64c8:	d65f03c0 	ret
    64cc:	d503201f 	nop

00000000000064d0 <fwp_tape_finish>:
    64d0:	d10203ff 	sub	sp, sp, #0x80
    64d4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    64d8:	f947f421 	ldr	x1, [x1, #4072]
    64dc:	a9047bfd 	stp	x29, x30, [sp, #64]
    64e0:	910103fd 	add	x29, sp, #0x40
    64e4:	a9065bf5 	stp	x21, x22, [sp, #96]
    64e8:	a90763f7 	stp	x23, x24, [sp, #112]
    64ec:	d00000d7 	adrp	x23, 20000 <__data_start>
    64f0:	910182f6 	add	x22, x23, #0x60
    64f4:	f9400022 	ldr	x2, [x1]
    64f8:	f9001fe2 	str	x2, [sp, #56]
    64fc:	d2800002 	mov	x2, #0x0                   	// #0
    6500:	910402c0 	add	x0, x22, #0x100
    6504:	97fff7b4 	bl	43d4 <fwp_tape_buffers_dispose>
    6508:	f9009edf 	str	xzr, [x22, #312]
    650c:	f9406ec0 	ldr	x0, [x22, #216]
    6510:	f100001f 	cmp	x0, #0x0
    6514:	5400034d 	b.le	657c <fwp_tape_finish+0xac>
    6518:	910003f8 	mov	x24, sp
    651c:	d2800015 	mov	x21, #0x0                   	// #0
    6520:	a90553f3 	stp	x19, x20, [sp, #80]
    6524:	d2800014 	mov	x20, #0x0                   	// #0
    6528:	91000694 	add	x20, x20, #0x1
    652c:	f94046d3 	ldr	x19, [x22, #136]
    6530:	8b150273 	add	x19, x19, x21
    6534:	9101a2b5 	add	x21, x21, #0x68
    6538:	aa1303e0 	mov	x0, x19
    653c:	97fff296 	bl	2f94 <fwp_tape_unlink_scope>
    6540:	aa1803e0 	mov	x0, x24
    6544:	a9440663 	ldp	x3, x1, [x19, #64]
    6548:	f9001be1 	str	x1, [sp, #48]
    654c:	f9400e62 	ldr	x2, [x19, #24]
    6550:	a9020be3 	stp	x3, x2, [sp, #32]
    6554:	ad410261 	ldp	q1, q0, [x19, #32]
    6558:	ad0003e1 	stp	q1, q0, [sp]
    655c:	97fff79e 	bl	43d4 <fwp_tape_buffers_dispose>
    6560:	f9403260 	ldr	x0, [x19, #96]
    6564:	97ffff8f 	bl	63a0 <fwp_owned_tape_release>
    6568:	f900327f 	str	xzr, [x19, #96]
    656c:	f9406ec0 	ldr	x0, [x22, #216]
    6570:	eb14001f 	cmp	x0, x20
    6574:	54fffdac 	b.gt	6528 <fwp_tape_finish+0x58>
    6578:	a94553f3 	ldp	x19, x20, [sp, #80]
    657c:	910182e0 	add	x0, x23, #0x60
    6580:	f9404400 	ldr	x0, [x0, #136]
    6584:	b4000040 	cbz	x0, 658c <fwp_tape_finish+0xbc>
    6588:	97fff772 	bl	4350 <ad_raw_free.part.0>
    658c:	910182f7 	add	x23, x23, #0x60
    6590:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6594:	f947f400 	ldr	x0, [x0, #4072]
    6598:	f90046ff 	str	xzr, [x23, #136]
    659c:	f9006eff 	str	xzr, [x23, #216]
    65a0:	f900a2ff 	str	xzr, [x23, #320]
    65a4:	f900c2ff 	str	xzr, [x23, #384]
    65a8:	f9401fe2 	ldr	x2, [sp, #56]
    65ac:	f9400001 	ldr	x1, [x0]
    65b0:	eb010042 	subs	x2, x2, x1
    65b4:	d2800001 	mov	x1, #0x0                   	// #0
    65b8:	540000c1 	b.ne	65d0 <fwp_tape_finish+0x100>  // b.any
    65bc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    65c0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    65c4:	a94763f7 	ldp	x23, x24, [sp, #112]
    65c8:	910203ff 	add	sp, sp, #0x80
    65cc:	d65f03c0 	ret
    65d0:	a90553f3 	stp	x19, x20, [sp, #80]
    65d4:	97fff08f 	bl	2810 <__stack_chk_fail@plt>
    65d8:	d503201f 	nop
    65dc:	d503201f 	nop

00000000000065e0 <fwp_tape_scope_release>:
    65e0:	d10243ff 	sub	sp, sp, #0x90
    65e4:	a9047bfd 	stp	x29, x30, [sp, #64]
    65e8:	910103fd 	add	x29, sp, #0x40
    65ec:	a90553f3 	stp	x19, x20, [sp, #80]
    65f0:	aa0003f4 	mov	x20, x0
    65f4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    65f8:	f947f400 	ldr	x0, [x0, #4072]
    65fc:	b9400285 	ldr	w5, [x20]
    6600:	f9400001 	ldr	x1, [x0]
    6604:	f9001fe1 	str	x1, [sp, #56]
    6608:	d2800001 	mov	x1, #0x0                   	// #0
    660c:	37f806c5 	tbnz	w5, #31, 66e4 <fwp_tape_scope_release+0x104>
    6610:	a90763f7 	stp	x23, x24, [sp, #112]
    6614:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6618:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    661c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6620:	d00000d3 	adrp	x19, 20000 <__data_start>
    6624:	910003f7 	mov	x23, sp
    6628:	91018273 	add	x19, x19, #0x60
    662c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6630:	a9065bf5 	stp	x21, x22, [sp, #96]
    6634:	52800d16 	mov	w22, #0x68                  	// #104
    6638:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    663c:	f90043f9 	str	x25, [sp, #128]
    6640:	14000006 	b	6658 <fwp_tape_scope_release+0x78>
    6644:	97fff764 	bl	43d4 <fwp_tape_buffers_dispose>
    6648:	aa1903e0 	mov	x0, x25
    664c:	97ffff55 	bl	63a0 <fwp_owned_tape_release>
    6650:	b9400285 	ldr	w5, [x20]
    6654:	37f80425 	tbnz	w5, #31, 66d8 <fwp_tape_scope_release+0xf8>
    6658:	f9404666 	ldr	x6, [x19, #136]
    665c:	9b367ca5 	smull	x5, w5, w22
    6660:	8b0500c0 	add	x0, x6, x5
    6664:	97fff24c 	bl	2f94 <fwp_tape_unlink_scope>
    6668:	ad410001 	ldp	q1, q0, [x0, #32]
    666c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6670:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6674:	f9400c03 	ldr	x3, [x0, #24]
    6678:	ad0003e1 	stp	q1, q0, [sp]
    667c:	b86568c1 	ldr	w1, [x6, x5]
    6680:	a9440804 	ldp	x4, x2, [x0, #64]
    6684:	b900041f 	str	wzr, [x0, #4]
    6688:	f9403019 	ldr	x25, [x0, #96]
    668c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6690:	f9000c1f 	str	xzr, [x0, #24]
    6694:	a9020fe4 	stp	x4, x3, [sp, #32]
    6698:	f9001be2 	str	x2, [sp, #48]
    669c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    66a0:	f900301f 	str	xzr, [x0, #96]
    66a4:	6b15003f 	cmp	w1, w21
    66a8:	540000e8 	b.hi	66c4 <fwp_tape_scope_release+0xe4>  // b.pmore
    66ac:	9343fca5 	asr	x5, x5, #3
    66b0:	f940c260 	ldr	x0, [x19, #384]
    66b4:	9b187ca5 	mul	x5, x5, x24
    66b8:	eb0000bf 	cmp	x5, x0
    66bc:	5400004a 	b.ge	66c4 <fwp_tape_scope_release+0xe4>  // b.tcont
    66c0:	f900c265 	str	x5, [x19, #384]
    66c4:	aa1703e0 	mov	x0, x23
    66c8:	b5fffbf9 	cbnz	x25, 6644 <fwp_tape_scope_release+0x64>
    66cc:	97fff78a 	bl	44f4 <fwp_tape_buffers_release>
    66d0:	b9400285 	ldr	w5, [x20]
    66d4:	36fffc25 	tbz	w5, #31, 6658 <fwp_tape_scope_release+0x78>
    66d8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    66dc:	a94763f7 	ldp	x23, x24, [sp, #112]
    66e0:	f94043f9 	ldr	x25, [sp, #128]
    66e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    66e8:	f947f400 	ldr	x0, [x0, #4072]
    66ec:	f9401fe2 	ldr	x2, [sp, #56]
    66f0:	f9400001 	ldr	x1, [x0]
    66f4:	eb010042 	subs	x2, x2, x1
    66f8:	d2800001 	mov	x1, #0x0                   	// #0
    66fc:	540000a1 	b.ne	6710 <fwp_tape_scope_release+0x130>  // b.any
    6700:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6704:	a94553f3 	ldp	x19, x20, [sp, #80]
    6708:	910243ff 	add	sp, sp, #0x90
    670c:	d65f03c0 	ret
    6710:	a9065bf5 	stp	x21, x22, [sp, #96]
    6714:	a90763f7 	stp	x23, x24, [sp, #112]
    6718:	f90043f9 	str	x25, [sp, #128]
    671c:	97fff03d 	bl	2810 <__stack_chk_fail@plt>

0000000000006720 <fwp_task_dispose>:
    6720:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6724:	910003fd 	mov	x29, sp
    6728:	f9000bf3 	str	x19, [sp, #16]
    672c:	aa0003f3 	mov	x19, x0
    6730:	39414000 	ldrb	w0, [x0, #80]
    6734:	36000720 	tbz	w0, #0, 6818 <fwp_task_dispose+0xf8>
    6738:	f9400a60 	ldr	x0, [x19, #16]
    673c:	b50006e0 	cbnz	x0, 6818 <fwp_task_dispose+0xf8>
    6740:	a9478660 	ldp	x0, x1, [x19, #120]
    6744:	39014e7f 	strb	wzr, [x19, #83]
    6748:	f9003e7f 	str	xzr, [x19, #120]
    674c:	f100003f 	cmp	x1, #0x0
    6750:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6754:	54000040 	b.eq	675c <fwp_task_dispose+0x3c>  // b.none
    6758:	d63f0020 	blr	x1
    675c:	f9405660 	ldr	x0, [x19, #168]
    6760:	97fff940 	bl	4c60 <fwp_mem_free>
    6764:	f900567f 	str	xzr, [x19, #168]
    6768:	b9405e60 	ldr	w0, [x19, #92]
    676c:	7100041f 	cmp	w0, #0x1
    6770:	54000420 	b.eq	67f4 <fwp_task_dispose+0xd4>  // b.none
    6774:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    6778:	91198042 	add	x2, x2, #0x660
    677c:	f949d840 	ldr	x0, [x2, #5040]
    6780:	f949ec41 	ldr	x1, [x2, #5080]
    6784:	cb000260 	sub	x0, x19, x0
    6788:	eb01401f 	cmp	x0, x1, lsl #16
    678c:	540002e2 	b.cs	67e8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6790:	d350fc01 	lsr	x1, x0, #16
    6794:	f949fc44 	ldr	x4, [x2, #5112]
    6798:	8b010821 	add	x1, x1, x1, lsl #2
    679c:	d37df021 	lsl	x1, x1, #3
    67a0:	8b010083 	add	x3, x4, x1
    67a4:	f9401062 	ldr	x2, [x3, #32]
    67a8:	b4000202 	cbz	x2, 67e8 <fwp_task_dispose+0xc8>
    67ac:	38616881 	ldrb	w1, [x4, x1]
    67b0:	7100083f 	cmp	w1, #0x2
    67b4:	54000280 	b.eq	6804 <fwp_task_dispose+0xe4>  // b.none
    67b8:	7100043f 	cmp	w1, #0x1
    67bc:	54000161 	b.ne	67e8 <fwp_task_dispose+0xc8>  // b.any
    67c0:	29430464 	ldp	w4, w1, [x3, #24]
    67c4:	92403c00 	and	x0, x0, #0xffff
    67c8:	9b047c00 	mul	x0, x0, x4
    67cc:	d360fc00 	lsr	x0, x0, #32
    67d0:	eb01001f 	cmp	x0, x1
    67d4:	540000a2 	b.cs	67e8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    67d8:	8b000042 	add	x2, x2, x0
    67dc:	39400040 	ldrb	w0, [x2]
    67e0:	7100041f 	cmp	w0, #0x1
    67e4:	54000080 	b.eq	67f4 <fwp_task_dispose+0xd4>  // b.none
    67e8:	f9400bf3 	ldr	x19, [sp, #16]
    67ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67f0:	d65f03c0 	ret
    67f4:	aa1303e0 	mov	x0, x19
    67f8:	f9400bf3 	ldr	x19, [sp, #16]
    67fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6800:	17fff918 	b	4c60 <fwp_mem_free>
    6804:	72003c1f 	tst	w0, #0xffff
    6808:	54fffea0 	b.eq	67dc <fwp_task_dispose+0xbc>  // b.none
    680c:	f9400bf3 	ldr	x19, [sp, #16]
    6810:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6814:	d65f03c0 	ret
    6818:	97fff012 	bl	2860 <abort@plt>
    681c:	d503201f 	nop

0000000000006820 <fwp_free_zombie>:
    6820:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6824:	910003fd 	mov	x29, sp
    6828:	a90153f3 	stp	x19, x20, [sp, #16]
    682c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6830:	91018281 	add	x1, x20, #0x60
    6834:	f940c433 	ldr	x19, [x1, #392]
    6838:	b4000333 	cbz	x19, 689c <fwp_free_zombie+0x7c>
    683c:	f9404c20 	ldr	x0, [x1, #152]
    6840:	eb00027f 	cmp	x19, x0
    6844:	540002c0 	b.eq	689c <fwp_free_zombie+0x7c>  // b.none
    6848:	b9419022 	ldr	w2, [x1, #400]
    684c:	f9400a60 	ldr	x0, [x19, #16]
    6850:	7100fc5f 	cmp	w2, #0x3f
    6854:	5400078c 	b.gt	6944 <fwp_free_zombie+0x124>
    6858:	91068023 	add	x3, x1, #0x1a0
    685c:	11000444 	add	w4, w2, #0x1
    6860:	b9019024 	str	w4, [x1, #400]
    6864:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6868:	f822d860 	str	x0, [x3, w2, sxtw #3]
    686c:	a9530261 	ldp	x1, x0, [x19, #304]
    6870:	b4000741 	cbz	x1, 6958 <fwp_free_zombie+0x138>
    6874:	f9009c20 	str	x0, [x1, #312]
    6878:	b4000040 	cbz	x0, 6880 <fwp_free_zombie+0x60>
    687c:	f9009801 	str	x1, [x0, #304]
    6880:	91018294 	add	x20, x20, #0x60
    6884:	b9405e60 	ldr	w0, [x19, #92]
    6888:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    688c:	f900c69f 	str	xzr, [x20, #392]
    6890:	34000140 	cbz	w0, 68b8 <fwp_free_zombie+0x98>
    6894:	7100041f 	cmp	w0, #0x1
    6898:	54000080 	b.eq	68a8 <fwp_free_zombie+0x88>  // b.none
    689c:	a94153f3 	ldp	x19, x20, [sp, #16]
    68a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68a4:	d65f03c0 	ret
    68a8:	aa1303e0 	mov	x0, x19
    68ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    68b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68b4:	17ffff9b 	b	6720 <fwp_task_dispose>
    68b8:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xb80>
    68bc:	91198082 	add	x2, x4, #0x660
    68c0:	f949d841 	ldr	x1, [x2, #5040]
    68c4:	f949ec40 	ldr	x0, [x2, #5080]
    68c8:	cb010261 	sub	x1, x19, x1
    68cc:	eb00403f 	cmp	x1, x0, lsl #16
    68d0:	54fffe62 	b.cs	689c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    68d4:	d350fc20 	lsr	x0, x1, #16
    68d8:	f949fc43 	ldr	x3, [x2, #5112]
    68dc:	8b000800 	add	x0, x0, x0, lsl #2
    68e0:	d37df000 	lsl	x0, x0, #3
    68e4:	8b000062 	add	x2, x3, x0
    68e8:	f9401054 	ldr	x20, [x2, #32]
    68ec:	b4fffd94 	cbz	x20, 689c <fwp_free_zombie+0x7c>
    68f0:	38606860 	ldrb	w0, [x3, x0]
    68f4:	7100081f 	cmp	w0, #0x2
    68f8:	54000360 	b.eq	6964 <fwp_free_zombie+0x144>  // b.none
    68fc:	7100041f 	cmp	w0, #0x1
    6900:	54fffce1 	b.ne	689c <fwp_free_zombie+0x7c>  // b.any
    6904:	29430043 	ldp	w3, w0, [x2, #24]
    6908:	92403c21 	and	x1, x1, #0xffff
    690c:	9b037c21 	mul	x1, x1, x3
    6910:	d360fc21 	lsr	x1, x1, #32
    6914:	eb00003f 	cmp	x1, x0
    6918:	54fffc22 	b.cs	689c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    691c:	8b010294 	add	x20, x20, x1
    6920:	39400280 	ldrb	w0, [x20]
    6924:	34fffbc0 	cbz	w0, 689c <fwp_free_zombie+0x7c>
    6928:	7100041f 	cmp	w0, #0x1
    692c:	54fffbe0 	b.eq	68a8 <fwp_free_zombie+0x88>  // b.none
    6930:	7103fc1f 	cmp	w0, #0xff
    6934:	540001e0 	b.eq	6970 <fwp_free_zombie+0x150>  // b.none
    6938:	51000400 	sub	w0, w0, #0x1
    693c:	39000280 	strb	w0, [x20]
    6940:	17ffffd7 	b	689c <fwp_free_zombie+0x7c>
    6944:	f9400e61 	ldr	x1, [x19, #24]
    6948:	97ffeffa 	bl	2930 <munmap@plt>
    694c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6950:	a9530261 	ldp	x1, x0, [x19, #304]
    6954:	b5fff901 	cbnz	x1, 6874 <fwp_free_zombie+0x54>
    6958:	91018282 	add	x2, x20, #0x60
    695c:	f901d040 	str	x0, [x2, #928]
    6960:	17ffffc6 	b	6878 <fwp_free_zombie+0x58>
    6964:	72003c3f 	tst	w1, #0xffff
    6968:	54fff9a1 	b.ne	689c <fwp_free_zombie+0x7c>  // b.any
    696c:	17ffffed 	b	6920 <fwp_free_zombie+0x100>
    6970:	ca544680 	eor	x0, x20, x20, lsr #17
    6974:	91198084 	add	x4, x4, #0x660
    6978:	ca402400 	eor	x0, x0, x0, lsr #9
    697c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6980:	f94a2400 	ldr	x0, [x0, #5192]
    6984:	b5000080 	cbnz	x0, 6994 <fwp_free_zombie+0x174>
    6988:	14000010 	b	69c8 <fwp_free_zombie+0x1a8>
    698c:	f9400800 	ldr	x0, [x0, #16]
    6990:	b40001c0 	cbz	x0, 69c8 <fwp_free_zombie+0x1a8>
    6994:	f9400001 	ldr	x1, [x0]
    6998:	eb14003f 	cmp	x1, x20
    699c:	54ffff81 	b.ne	698c <fwp_free_zombie+0x16c>  // b.any
    69a0:	f9400401 	ldr	x1, [x0, #8]
    69a4:	d1000421 	sub	x1, x1, #0x1
    69a8:	f9000401 	str	x1, [x0, #8]
    69ac:	f103f83f 	cmp	x1, #0xfe
    69b0:	54fff761 	b.ne	689c <fwp_free_zombie+0x7c>  // b.any
    69b4:	aa1403e0 	mov	x0, x20
    69b8:	97fff80a 	bl	49e0 <fwp_rc_forget_slot>
    69bc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    69c0:	39000280 	strb	w0, [x20]
    69c4:	17ffffb6 	b	689c <fwp_free_zombie+0x7c>
    69c8:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    69cc:	91394000 	add	x0, x0, #0xe50
    69d0:	97fff36c 	bl	3780 <fwp_trap>

00000000000069d4 <fwp_block>:
    69d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    69d8:	910003fd 	mov	x29, sp
    69dc:	a90153f3 	stp	x19, x20, [sp, #16]
    69e0:	d00000d3 	adrp	x19, 20000 <__data_start>
    69e4:	91018274 	add	x20, x19, #0x60
    69e8:	f9406682 	ldr	x2, [x20, #200]
    69ec:	b4000622 	cbz	x2, 6ab0 <fwp_block+0xdc>
    69f0:	91018261 	add	x1, x19, #0x60
    69f4:	f9408040 	ldr	x0, [x2, #256]
    69f8:	f9006420 	str	x0, [x1, #200]
    69fc:	b4000680 	cbz	x0, 6acc <fwp_block+0xf8>
    6a00:	91018263 	add	x3, x19, #0x60
    6a04:	3901505f 	strb	wzr, [x2, #84]
    6a08:	f9404c64 	ldr	x4, [x3, #152]
    6a0c:	eb02009f 	cmp	x4, x2
    6a10:	54000440 	b.eq	6a98 <fwp_block+0xc4>  // b.none
    6a14:	f941d465 	ldr	x5, [x3, #936]
    6a18:	f9004c62 	str	x2, [x3, #152]
    6a1c:	f9400441 	ldr	x1, [x2, #8]
    6a20:	f9004885 	str	x5, [x4, #144]
    6a24:	f941d865 	ldr	x5, [x3, #944]
    6a28:	f9004c85 	str	x5, [x4, #152]
    6a2c:	f941dc65 	ldr	x5, [x3, #952]
    6a30:	f9005085 	str	x5, [x4, #160]
    6a34:	f941e065 	ldr	x5, [x3, #960]
    6a38:	f9005485 	str	x5, [x4, #168]
    6a3c:	f941e465 	ldr	x5, [x3, #968]
    6a40:	f9005885 	str	x5, [x4, #176]
    6a44:	f941e865 	ldr	x5, [x3, #976]
    6a48:	f9005c85 	str	x5, [x4, #184]
    6a4c:	f941ec65 	ldr	x5, [x3, #984]
    6a50:	f9006085 	str	x5, [x4, #192]
    6a54:	f9400480 	ldr	x0, [x4, #8]
    6a58:	f9404844 	ldr	x4, [x2, #144]
    6a5c:	f901d464 	str	x4, [x3, #936]
    6a60:	f9404c44 	ldr	x4, [x2, #152]
    6a64:	f901d864 	str	x4, [x3, #944]
    6a68:	f9405044 	ldr	x4, [x2, #160]
    6a6c:	f901dc64 	str	x4, [x3, #952]
    6a70:	f9405444 	ldr	x4, [x2, #168]
    6a74:	f901e064 	str	x4, [x3, #960]
    6a78:	f9405844 	ldr	x4, [x2, #176]
    6a7c:	f901e464 	str	x4, [x3, #968]
    6a80:	a94b8844 	ldp	x4, x2, [x2, #184]
    6a84:	f901e864 	str	x4, [x3, #976]
    6a88:	f901ec62 	str	x2, [x3, #984]
    6a8c:	97ffef79 	bl	2870 <swapcontext@plt>
    6a90:	97ffff64 	bl	6820 <fwp_free_zombie>
    6a94:	d503201f 	nop
    6a98:	91018260 	add	x0, x19, #0x60
    6a9c:	b943e000 	ldr	w0, [x0, #992]
    6aa0:	340001a0 	cbz	w0, 6ad4 <fwp_block+0x100>
    6aa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6aa8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6aac:	d65f03c0 	ret
    6ab0:	97fff6f9 	bl	4694 <fwp_poll_events>
    6ab4:	f9406682 	ldr	x2, [x20, #200]
    6ab8:	b4ffffc2 	cbz	x2, 6ab0 <fwp_block+0xdc>
    6abc:	91018261 	add	x1, x19, #0x60
    6ac0:	f9408040 	ldr	x0, [x2, #256]
    6ac4:	f9006420 	str	x0, [x1, #200]
    6ac8:	b5fff9c0 	cbnz	x0, 6a00 <fwp_block+0x2c>
    6acc:	f900603f 	str	xzr, [x1, #192]
    6ad0:	17ffffcc 	b	6a00 <fwp_block+0x2c>
    6ad4:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    6ad8:	913e0000 	add	x0, x0, #0xf80
    6adc:	97ffefb1 	bl	29a0 <getenv@plt>
    6ae0:	5284e202 	mov	w2, #0x2710                	// #10000
    6ae4:	b4000060 	cbz	x0, 6af0 <fwp_block+0x11c>
    6ae8:	39400001 	ldrb	w1, [x0]
    6aec:	350000c1 	cbnz	w1, 6b04 <fwp_block+0x130>
    6af0:	91018273 	add	x19, x19, #0x60
    6af4:	b903e262 	str	w2, [x19, #992]
    6af8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6afc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b00:	d65f03c0 	ret
    6b04:	52800142 	mov	w2, #0xa                   	// #10
    6b08:	d2800001 	mov	x1, #0x0                   	// #0
    6b0c:	97ffeef5 	bl	26e0 <strtoll@plt>
    6b10:	d1000403 	sub	x3, x0, #0x1
    6b14:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6b18:	eb02007f 	cmp	x3, x2
    6b1c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6b20:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6b24:	17fffff3 	b	6af0 <fwp_block+0x11c>
    6b28:	d503201f 	nop
    6b2c:	d503201f 	nop

0000000000006b30 <fwp_drop4>:
    6b30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6b34:	910003fd 	mov	x29, sp
    6b38:	a90153f3 	stp	x19, x20, [sp, #16]
    6b3c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xb80>
    6b40:	f90013f5 	str	x21, [sp, #32]
    6b44:	91198275 	add	x21, x19, #0x660
    6b48:	f949daa1 	ldr	x1, [x21, #5040]
    6b4c:	f949eea2 	ldr	x2, [x21, #5080]
    6b50:	cb010001 	sub	x1, x0, x1
    6b54:	eb02403f 	cmp	x1, x2, lsl #16
    6b58:	54000382 	b.cs	6bc8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b5c:	d350fc22 	lsr	x2, x1, #16
    6b60:	f949fea3 	ldr	x3, [x21, #5112]
    6b64:	8b020842 	add	x2, x2, x2, lsl #2
    6b68:	d37df042 	lsl	x2, x2, #3
    6b6c:	8b020064 	add	x4, x3, x2
    6b70:	f9401094 	ldr	x20, [x4, #32]
    6b74:	b40002b4 	cbz	x20, 6bc8 <fwp_drop4+0x98>
    6b78:	38626862 	ldrb	w2, [x3, x2]
    6b7c:	7100085f 	cmp	w2, #0x2
    6b80:	540007a0 	b.eq	6c74 <fwp_drop4+0x144>  // b.none
    6b84:	7100045f 	cmp	w2, #0x1
    6b88:	54000201 	b.ne	6bc8 <fwp_drop4+0x98>  // b.any
    6b8c:	29430885 	ldp	w5, w2, [x4, #24]
    6b90:	92403c21 	and	x1, x1, #0xffff
    6b94:	9b057c21 	mul	x1, x1, x5
    6b98:	d360fc21 	lsr	x1, x1, #32
    6b9c:	eb02003f 	cmp	x1, x2
    6ba0:	54000142 	b.cs	6bc8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6ba4:	8b010294 	add	x20, x20, x1
    6ba8:	39400281 	ldrb	w1, [x20]
    6bac:	340000e1 	cbz	w1, 6bc8 <fwp_drop4+0x98>
    6bb0:	7100043f 	cmp	w1, #0x1
    6bb4:	54000120 	b.eq	6bd8 <fwp_drop4+0xa8>  // b.none
    6bb8:	7103fc3f 	cmp	w1, #0xff
    6bbc:	540007c0 	b.eq	6cb4 <fwp_drop4+0x184>  // b.none
    6bc0:	51000421 	sub	w1, w1, #0x1
    6bc4:	39000281 	strb	w1, [x20]
    6bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bcc:	f94013f5 	ldr	x21, [sp, #32]
    6bd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bd4:	d65f03c0 	ret
    6bd8:	f9400001 	ldr	x1, [x0]
    6bdc:	b7f80581 	tbnz	x1, #63, 6c8c <fwp_drop4+0x15c>
    6be0:	91198273 	add	x19, x19, #0x660
    6be4:	f949da61 	ldr	x1, [x19, #5040]
    6be8:	f949ee62 	ldr	x2, [x19, #5080]
    6bec:	cb010001 	sub	x1, x0, x1
    6bf0:	eb02403f 	cmp	x1, x2, lsl #16
    6bf4:	54fffea2 	b.cs	6bc8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6bf8:	d350fc22 	lsr	x2, x1, #16
    6bfc:	8b020842 	add	x2, x2, x2, lsl #2
    6c00:	d37df042 	lsl	x2, x2, #3
    6c04:	8b020065 	add	x5, x3, x2
    6c08:	f94010a4 	ldr	x4, [x5, #32]
    6c0c:	b4fffde4 	cbz	x4, 6bc8 <fwp_drop4+0x98>
    6c10:	38626862 	ldrb	w2, [x3, x2]
    6c14:	7100085f 	cmp	w2, #0x2
    6c18:	54000220 	b.eq	6c5c <fwp_drop4+0x12c>  // b.none
    6c1c:	7100045f 	cmp	w2, #0x1
    6c20:	54fffd41 	b.ne	6bc8 <fwp_drop4+0x98>  // b.any
    6c24:	294308a3 	ldp	w3, w2, [x5, #24]
    6c28:	92403c21 	and	x1, x1, #0xffff
    6c2c:	9b037c21 	mul	x1, x1, x3
    6c30:	d360fc21 	lsr	x1, x1, #32
    6c34:	eb02003f 	cmp	x1, x2
    6c38:	54fffc82 	b.cs	6bc8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6c3c:	8b010084 	add	x4, x4, x1
    6c40:	39400081 	ldrb	w1, [x4]
    6c44:	7100043f 	cmp	w1, #0x1
    6c48:	54fffc01 	b.ne	6bc8 <fwp_drop4+0x98>  // b.any
    6c4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c50:	f94013f5 	ldr	x21, [sp, #32]
    6c54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c58:	17fff802 	b	4c60 <fwp_mem_free>
    6c5c:	72003c3f 	tst	w1, #0xffff
    6c60:	54ffff00 	b.eq	6c40 <fwp_drop4+0x110>  // b.none
    6c64:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c68:	f94013f5 	ldr	x21, [sp, #32]
    6c6c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c70:	d65f03c0 	ret
    6c74:	72003c3f 	tst	w1, #0xffff
    6c78:	54fff980 	b.eq	6ba8 <fwp_drop4+0x78>  // b.none
    6c7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c80:	f94013f5 	ldr	x21, [sp, #32]
    6c84:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c88:	d65f03c0 	ret
    6c8c:	f9400414 	ldr	x20, [x0, #8]
    6c90:	97fffbe4 	bl	5c20 <fwp_rc_free_arr>
    6c94:	91198260 	add	x0, x19, #0x660
    6c98:	f949d801 	ldr	x1, [x0, #5040]
    6c9c:	f949ec00 	ldr	x0, [x0, #5080]
    6ca0:	cb010281 	sub	x1, x20, x1
    6ca4:	eb00403f 	cmp	x1, x0, lsl #16
    6ca8:	54fff902 	b.cs	6bc8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6cac:	aa1403e0 	mov	x0, x20
    6cb0:	17ffffab 	b	6b5c <fwp_drop4+0x2c>
    6cb4:	ca544680 	eor	x0, x20, x20, lsr #17
    6cb8:	91198273 	add	x19, x19, #0x660
    6cbc:	ca402400 	eor	x0, x0, x0, lsr #9
    6cc0:	8b200e60 	add	x0, x19, w0, uxtb #3
    6cc4:	f94a2400 	ldr	x0, [x0, #5192]
    6cc8:	b5000080 	cbnz	x0, 6cd8 <fwp_drop4+0x1a8>
    6ccc:	14000010 	b	6d0c <fwp_drop4+0x1dc>
    6cd0:	f9400800 	ldr	x0, [x0, #16]
    6cd4:	b40001c0 	cbz	x0, 6d0c <fwp_drop4+0x1dc>
    6cd8:	f9400001 	ldr	x1, [x0]
    6cdc:	eb14003f 	cmp	x1, x20
    6ce0:	54ffff81 	b.ne	6cd0 <fwp_drop4+0x1a0>  // b.any
    6ce4:	f9400401 	ldr	x1, [x0, #8]
    6ce8:	d1000421 	sub	x1, x1, #0x1
    6cec:	f9000401 	str	x1, [x0, #8]
    6cf0:	f103f83f 	cmp	x1, #0xfe
    6cf4:	54fff6a1 	b.ne	6bc8 <fwp_drop4+0x98>  // b.any
    6cf8:	aa1403e0 	mov	x0, x20
    6cfc:	97fff739 	bl	49e0 <fwp_rc_forget_slot>
    6d00:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6d04:	39000280 	strb	w0, [x20]
    6d08:	17ffffb0 	b	6bc8 <fwp_drop4+0x98>
    6d0c:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    6d10:	91394000 	add	x0, x0, #0xe50
    6d14:	97fff29b 	bl	3780 <fwp_trap>
    6d18:	d503201f 	nop
    6d1c:	d503201f 	nop

0000000000006d20 <fwp_caps161>:
    6d20:	34000041 	cbz	w1, 6d28 <fwp_caps161+0x8>
    6d24:	d65f03c0 	ret
    6d28:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xb80>
    6d2c:	91198063 	add	x3, x3, #0x660
    6d30:	f949d861 	ldr	x1, [x3, #5040]
    6d34:	f949ec62 	ldr	x2, [x3, #5080]
    6d38:	cb010001 	sub	x1, x0, x1
    6d3c:	eb02403f 	cmp	x1, x2, lsl #16
    6d40:	54ffff22 	b.cs	6d24 <fwp_caps161+0x4>  // b.hs, b.nlast
    6d44:	d350fc22 	lsr	x2, x1, #16
    6d48:	f949fc65 	ldr	x5, [x3, #5112]
    6d4c:	8b020842 	add	x2, x2, x2, lsl #2
    6d50:	d37df042 	lsl	x2, x2, #3
    6d54:	8b0200a4 	add	x4, x5, x2
    6d58:	f9401083 	ldr	x3, [x4, #32]
    6d5c:	b4fffe43 	cbz	x3, 6d24 <fwp_caps161+0x4>
    6d60:	386268a2 	ldrb	w2, [x5, x2]
    6d64:	7100085f 	cmp	w2, #0x2
    6d68:	540001c0 	b.eq	6da0 <fwp_caps161+0x80>  // b.none
    6d6c:	7100045f 	cmp	w2, #0x1
    6d70:	54fffda1 	b.ne	6d24 <fwp_caps161+0x4>  // b.any
    6d74:	29430885 	ldp	w5, w2, [x4, #24]
    6d78:	92403c21 	and	x1, x1, #0xffff
    6d7c:	9b057c21 	mul	x1, x1, x5
    6d80:	d360fc21 	lsr	x1, x1, #32
    6d84:	eb02003f 	cmp	x1, x2
    6d88:	54fffce2 	b.cs	6d24 <fwp_caps161+0x4>  // b.hs, b.nlast
    6d8c:	8b010063 	add	x3, x3, x1
    6d90:	39400061 	ldrb	w1, [x3]
    6d94:	7100043f 	cmp	w1, #0x1
    6d98:	54fffc61 	b.ne	6d24 <fwp_caps161+0x4>  // b.any
    6d9c:	17fff7b1 	b	4c60 <fwp_mem_free>
    6da0:	72003c3f 	tst	w1, #0xffff
    6da4:	54ffff60 	b.eq	6d90 <fwp_caps161+0x70>  // b.none
    6da8:	d65f03c0 	ret
    6dac:	d503201f 	nop

0000000000006db0 <fwp_drop2>:
    6db0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6db4:	910003fd 	mov	x29, sp
    6db8:	a9025bf5 	stp	x21, x22, [sp, #32]
    6dbc:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xb80>
    6dc0:	911982d5 	add	x21, x22, #0x660
    6dc4:	a90153f3 	stp	x19, x20, [sp, #16]
    6dc8:	aa0003f3 	mov	x19, x0
    6dcc:	f949daa1 	ldr	x1, [x21, #5040]
    6dd0:	f949eea0 	ldr	x0, [x21, #5080]
    6dd4:	cb010261 	sub	x1, x19, x1
    6dd8:	eb00403f 	cmp	x1, x0, lsl #16
    6ddc:	54000382 	b.cs	6e4c <fwp_drop2+0x9c>  // b.hs, b.nlast
    6de0:	d350fc22 	lsr	x2, x1, #16
    6de4:	f949fea3 	ldr	x3, [x21, #5112]
    6de8:	8b020842 	add	x2, x2, x2, lsl #2
    6dec:	d37df042 	lsl	x2, x2, #3
    6df0:	8b020060 	add	x0, x3, x2
    6df4:	f9401014 	ldr	x20, [x0, #32]
    6df8:	b40002b4 	cbz	x20, 6e4c <fwp_drop2+0x9c>
    6dfc:	38626862 	ldrb	w2, [x3, x2]
    6e00:	7100085f 	cmp	w2, #0x2
    6e04:	540002c0 	b.eq	6e5c <fwp_drop2+0xac>  // b.none
    6e08:	7100045f 	cmp	w2, #0x1
    6e0c:	54000201 	b.ne	6e4c <fwp_drop2+0x9c>  // b.any
    6e10:	29430002 	ldp	w2, w0, [x0, #24]
    6e14:	92403c21 	and	x1, x1, #0xffff
    6e18:	9b027c21 	mul	x1, x1, x2
    6e1c:	d360fc21 	lsr	x1, x1, #32
    6e20:	eb00003f 	cmp	x1, x0
    6e24:	54000142 	b.cs	6e4c <fwp_drop2+0x9c>  // b.hs, b.nlast
    6e28:	8b010294 	add	x20, x20, x1
    6e2c:	39400280 	ldrb	w0, [x20]
    6e30:	340000e0 	cbz	w0, 6e4c <fwp_drop2+0x9c>
    6e34:	7100041f 	cmp	w0, #0x1
    6e38:	540001e0 	b.eq	6e74 <fwp_drop2+0xc4>  // b.none
    6e3c:	7103fc1f 	cmp	w0, #0xff
    6e40:	540007c0 	b.eq	6f38 <fwp_drop2+0x188>  // b.none
    6e44:	51000400 	sub	w0, w0, #0x1
    6e48:	39000280 	strb	w0, [x20]
    6e4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6e54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e58:	d65f03c0 	ret
    6e5c:	72003c3f 	tst	w1, #0xffff
    6e60:	54fffe60 	b.eq	6e2c <fwp_drop2+0x7c>  // b.none
    6e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e68:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6e6c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e70:	d65f03c0 	ret
    6e74:	911982c2 	add	x2, x22, #0x660
    6e78:	f9400660 	ldr	x0, [x19, #8]
    6e7c:	f949d841 	ldr	x1, [x2, #5040]
    6e80:	f949ec42 	ldr	x2, [x2, #5080]
    6e84:	cb010001 	sub	x1, x0, x1
    6e88:	eb02403f 	cmp	x1, x2, lsl #16
    6e8c:	54000362 	b.cs	6ef8 <fwp_drop2+0x148>  // b.hs, b.nlast
    6e90:	d350fc22 	lsr	x2, x1, #16
    6e94:	8b020842 	add	x2, x2, x2, lsl #2
    6e98:	d37df042 	lsl	x2, x2, #3
    6e9c:	8b020064 	add	x4, x3, x2
    6ea0:	f9401094 	ldr	x20, [x4, #32]
    6ea4:	b40002b4 	cbz	x20, 6ef8 <fwp_drop2+0x148>
    6ea8:	38626862 	ldrb	w2, [x3, x2]
    6eac:	7100085f 	cmp	w2, #0x2
    6eb0:	540003e0 	b.eq	6f2c <fwp_drop2+0x17c>  // b.none
    6eb4:	7100045f 	cmp	w2, #0x1
    6eb8:	54000201 	b.ne	6ef8 <fwp_drop2+0x148>  // b.any
    6ebc:	29430883 	ldp	w3, w2, [x4, #24]
    6ec0:	92403c21 	and	x1, x1, #0xffff
    6ec4:	9b037c21 	mul	x1, x1, x3
    6ec8:	d360fc21 	lsr	x1, x1, #32
    6ecc:	eb02003f 	cmp	x1, x2
    6ed0:	54000142 	b.cs	6ef8 <fwp_drop2+0x148>  // b.hs, b.nlast
    6ed4:	8b010294 	add	x20, x20, x1
    6ed8:	39400281 	ldrb	w1, [x20]
    6edc:	340000e1 	cbz	w1, 6ef8 <fwp_drop2+0x148>
    6ee0:	7100043f 	cmp	w1, #0x1
    6ee4:	54000200 	b.eq	6f24 <fwp_drop2+0x174>  // b.none
    6ee8:	7103fc3f 	cmp	w1, #0xff
    6eec:	54000580 	b.eq	6f9c <fwp_drop2+0x1ec>  // b.none
    6ef0:	51000421 	sub	w1, w1, #0x1
    6ef4:	39000281 	strb	w1, [x20]
    6ef8:	f9400a74 	ldr	x20, [x19, #16]
    6efc:	aa1303e0 	mov	x0, x19
    6f00:	97fffb48 	bl	5c20 <fwp_rc_free_arr>
    6f04:	911982c0 	add	x0, x22, #0x660
    6f08:	f949d801 	ldr	x1, [x0, #5040]
    6f0c:	f949ec00 	ldr	x0, [x0, #5080]
    6f10:	cb010281 	sub	x1, x20, x1
    6f14:	eb00403f 	cmp	x1, x0, lsl #16
    6f18:	54fff9a2 	b.cs	6e4c <fwp_drop2+0x9c>  // b.hs, b.nlast
    6f1c:	aa1403f3 	mov	x19, x20
    6f20:	17ffffb0 	b	6de0 <fwp_drop2+0x30>
    6f24:	97fffb3f 	bl	5c20 <fwp_rc_free_arr>
    6f28:	17fffff4 	b	6ef8 <fwp_drop2+0x148>
    6f2c:	72003c3f 	tst	w1, #0xffff
    6f30:	54fffe41 	b.ne	6ef8 <fwp_drop2+0x148>  // b.any
    6f34:	17ffffe9 	b	6ed8 <fwp_drop2+0x128>
    6f38:	ca544681 	eor	x1, x20, x20, lsr #17
    6f3c:	911982c0 	add	x0, x22, #0x660
    6f40:	ca412421 	eor	x1, x1, x1, lsr #9
    6f44:	8b210c01 	add	x1, x0, w1, uxtb #3
    6f48:	f94a2420 	ldr	x0, [x1, #5192]
    6f4c:	b5000080 	cbnz	x0, 6f5c <fwp_drop2+0x1ac>
    6f50:	14000010 	b	6f90 <fwp_drop2+0x1e0>
    6f54:	f9400800 	ldr	x0, [x0, #16]
    6f58:	b40001c0 	cbz	x0, 6f90 <fwp_drop2+0x1e0>
    6f5c:	f9400001 	ldr	x1, [x0]
    6f60:	eb14003f 	cmp	x1, x20
    6f64:	54ffff81 	b.ne	6f54 <fwp_drop2+0x1a4>  // b.any
    6f68:	f9400401 	ldr	x1, [x0, #8]
    6f6c:	d1000421 	sub	x1, x1, #0x1
    6f70:	f9000401 	str	x1, [x0, #8]
    6f74:	f103f83f 	cmp	x1, #0xfe
    6f78:	54fff6a1 	b.ne	6e4c <fwp_drop2+0x9c>  // b.any
    6f7c:	aa1403e0 	mov	x0, x20
    6f80:	97fff698 	bl	49e0 <fwp_rc_forget_slot>
    6f84:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6f88:	39000280 	strb	w0, [x20]
    6f8c:	17ffffb0 	b	6e4c <fwp_drop2+0x9c>
    6f90:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    6f94:	91394000 	add	x0, x0, #0xe50
    6f98:	97fff1fa 	bl	3780 <fwp_trap>
    6f9c:	ca544680 	eor	x0, x20, x20, lsr #17
    6fa0:	911982c1 	add	x1, x22, #0x660
    6fa4:	ca402400 	eor	x0, x0, x0, lsr #9
    6fa8:	8b200c20 	add	x0, x1, w0, uxtb #3
    6fac:	f94a2400 	ldr	x0, [x0, #5192]
    6fb0:	b5000080 	cbnz	x0, 6fc0 <fwp_drop2+0x210>
    6fb4:	17fffff7 	b	6f90 <fwp_drop2+0x1e0>
    6fb8:	f9400800 	ldr	x0, [x0, #16]
    6fbc:	b4fffea0 	cbz	x0, 6f90 <fwp_drop2+0x1e0>
    6fc0:	f9400001 	ldr	x1, [x0]
    6fc4:	eb14003f 	cmp	x1, x20
    6fc8:	54ffff81 	b.ne	6fb8 <fwp_drop2+0x208>  // b.any
    6fcc:	f9400401 	ldr	x1, [x0, #8]
    6fd0:	d1000421 	sub	x1, x1, #0x1
    6fd4:	f9000401 	str	x1, [x0, #8]
    6fd8:	f103f83f 	cmp	x1, #0xfe
    6fdc:	54fff8e1 	b.ne	6ef8 <fwp_drop2+0x148>  // b.any
    6fe0:	aa1403e0 	mov	x0, x20
    6fe4:	97fff67f 	bl	49e0 <fwp_rc_forget_slot>
    6fe8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6fec:	39000280 	strb	w0, [x20]
    6ff0:	17ffffc2 	b	6ef8 <fwp_drop2+0x148>

0000000000006ff4 <fwp_arg_drop23>:
    6ff4:	7100003f 	cmp	w1, #0x0
    6ff8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6ffc:	54000041 	b.ne	7004 <fwp_arg_drop23+0x10>  // b.any
    7000:	d65f03c0 	ret
    7004:	f9400000 	ldr	x0, [x0]
    7008:	17ffff6a 	b	6db0 <fwp_drop2>
    700c:	d503201f 	nop

0000000000007010 <fwp_args12>:
    7010:	7100003f 	cmp	w1, #0x0
    7014:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7018:	54000041 	b.ne	7020 <fwp_args12+0x10>  // b.any
    701c:	d65f03c0 	ret
    7020:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    7024:	91198042 	add	x2, x2, #0x660
    7028:	f9400001 	ldr	x1, [x0]
    702c:	f949d843 	ldr	x3, [x2, #5040]
    7030:	f949ec40 	ldr	x0, [x2, #5080]
    7034:	cb030021 	sub	x1, x1, x3
    7038:	eb00403f 	cmp	x1, x0, lsl #16
    703c:	54ffff02 	b.cs	701c <fwp_args12+0xc>  // b.hs, b.nlast
    7040:	d350fc20 	lsr	x0, x1, #16
    7044:	f949fc44 	ldr	x4, [x2, #5112]
    7048:	8b000800 	add	x0, x0, x0, lsl #2
    704c:	d37df002 	lsl	x2, x0, #3
    7050:	8b020083 	add	x3, x4, x2
    7054:	f9401060 	ldr	x0, [x3, #32]
    7058:	b4fffe20 	cbz	x0, 701c <fwp_args12+0xc>
    705c:	38626882 	ldrb	w2, [x4, x2]
    7060:	7100085f 	cmp	w2, #0x2
    7064:	54000320 	b.eq	70c8 <fwp_args12+0xb8>  // b.none
    7068:	7100045f 	cmp	w2, #0x1
    706c:	54fffd81 	b.ne	701c <fwp_args12+0xc>  // b.any
    7070:	29430864 	ldp	w4, w2, [x3, #24]
    7074:	92403c21 	and	x1, x1, #0xffff
    7078:	9b047c21 	mul	x1, x1, x4
    707c:	d360fc21 	lsr	x1, x1, #32
    7080:	eb02003f 	cmp	x1, x2
    7084:	54fffcc2 	b.cs	701c <fwp_args12+0xc>  // b.hs, b.nlast
    7088:	8b010000 	add	x0, x0, x1
    708c:	39400001 	ldrb	w1, [x0]
    7090:	34fffc61 	cbz	w1, 701c <fwp_args12+0xc>
    7094:	b00000c2 	adrp	x2, 20000 <__data_start>
    7098:	91018042 	add	x2, x2, #0x60
    709c:	b9415043 	ldr	w3, [x2, #336]
    70a0:	350000c3 	cbnz	w3, 70b8 <fwp_args12+0xa8>
    70a4:	7103f43f 	cmp	w1, #0xfd
    70a8:	54000168 	b.hi	70d4 <fwp_args12+0xc4>  // b.pmore
    70ac:	11000421 	add	w1, w1, #0x1
    70b0:	39000001 	strb	w1, [x0]
    70b4:	d65f03c0 	ret
    70b8:	f940bc43 	ldr	x3, [x2, #376]
    70bc:	91000463 	add	x3, x3, #0x1
    70c0:	f900bc43 	str	x3, [x2, #376]
    70c4:	17fffff8 	b	70a4 <fwp_args12+0x94>
    70c8:	72003c3f 	tst	w1, #0xffff
    70cc:	54fffe00 	b.eq	708c <fwp_args12+0x7c>  // b.none
    70d0:	d65f03c0 	ret
    70d4:	17fff5fc 	b	48c4 <fwp_rc_wide_dup>
    70d8:	d503201f 	nop
    70dc:	d503201f 	nop

00000000000070e0 <fwp_args23>:
    70e0:	7100003f 	cmp	w1, #0x0
    70e4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    70e8:	54000041 	b.ne	70f0 <fwp_args23+0x10>  // b.any
    70ec:	d65f03c0 	ret
    70f0:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    70f4:	91198042 	add	x2, x2, #0x660
    70f8:	f9400001 	ldr	x1, [x0]
    70fc:	f949d843 	ldr	x3, [x2, #5040]
    7100:	f949ec40 	ldr	x0, [x2, #5080]
    7104:	cb030021 	sub	x1, x1, x3
    7108:	eb00403f 	cmp	x1, x0, lsl #16
    710c:	54ffff02 	b.cs	70ec <fwp_args23+0xc>  // b.hs, b.nlast
    7110:	d350fc20 	lsr	x0, x1, #16
    7114:	f949fc44 	ldr	x4, [x2, #5112]
    7118:	8b000800 	add	x0, x0, x0, lsl #2
    711c:	d37df002 	lsl	x2, x0, #3
    7120:	8b020083 	add	x3, x4, x2
    7124:	f9401060 	ldr	x0, [x3, #32]
    7128:	b4fffe20 	cbz	x0, 70ec <fwp_args23+0xc>
    712c:	38626882 	ldrb	w2, [x4, x2]
    7130:	7100085f 	cmp	w2, #0x2
    7134:	54000320 	b.eq	7198 <fwp_args23+0xb8>  // b.none
    7138:	7100045f 	cmp	w2, #0x1
    713c:	54fffd81 	b.ne	70ec <fwp_args23+0xc>  // b.any
    7140:	29430864 	ldp	w4, w2, [x3, #24]
    7144:	92403c21 	and	x1, x1, #0xffff
    7148:	9b047c21 	mul	x1, x1, x4
    714c:	d360fc21 	lsr	x1, x1, #32
    7150:	eb02003f 	cmp	x1, x2
    7154:	54fffcc2 	b.cs	70ec <fwp_args23+0xc>  // b.hs, b.nlast
    7158:	8b010000 	add	x0, x0, x1
    715c:	39400001 	ldrb	w1, [x0]
    7160:	34fffc61 	cbz	w1, 70ec <fwp_args23+0xc>
    7164:	b00000c2 	adrp	x2, 20000 <__data_start>
    7168:	91018042 	add	x2, x2, #0x60
    716c:	b9415043 	ldr	w3, [x2, #336]
    7170:	350000c3 	cbnz	w3, 7188 <fwp_args23+0xa8>
    7174:	7103f43f 	cmp	w1, #0xfd
    7178:	54000168 	b.hi	71a4 <fwp_args23+0xc4>  // b.pmore
    717c:	11000421 	add	w1, w1, #0x1
    7180:	39000001 	strb	w1, [x0]
    7184:	d65f03c0 	ret
    7188:	f940bc43 	ldr	x3, [x2, #376]
    718c:	91000463 	add	x3, x3, #0x1
    7190:	f900bc43 	str	x3, [x2, #376]
    7194:	17fffff8 	b	7174 <fwp_args23+0x94>
    7198:	72003c3f 	tst	w1, #0xffff
    719c:	54fffe00 	b.eq	715c <fwp_args23+0x7c>  // b.none
    71a0:	d65f03c0 	ret
    71a4:	17fff5c8 	b	48c4 <fwp_rc_wide_dup>
    71a8:	d503201f 	nop
    71ac:	d503201f 	nop

00000000000071b0 <fwp_caps23>:
    71b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    71b4:	910003fd 	mov	x29, sp
    71b8:	f9000bf3 	str	x19, [sp, #16]
    71bc:	aa0003f3 	mov	x19, x0
    71c0:	b9400400 	ldr	w0, [x0, #4]
    71c4:	340004a0 	cbz	w0, 7258 <fwp_caps23+0xa8>
    71c8:	f9400660 	ldr	x0, [x19, #8]
    71cc:	350004e1 	cbnz	w1, 7268 <fwp_caps23+0xb8>
    71d0:	97fffef8 	bl	6db0 <fwp_drop2>
    71d4:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    71d8:	91198042 	add	x2, x2, #0x660
    71dc:	f949d840 	ldr	x0, [x2, #5040]
    71e0:	f949ec41 	ldr	x1, [x2, #5080]
    71e4:	cb000260 	sub	x0, x19, x0
    71e8:	eb01401f 	cmp	x0, x1, lsl #16
    71ec:	54000382 	b.cs	725c <fwp_caps23+0xac>  // b.hs, b.nlast
    71f0:	d350fc01 	lsr	x1, x0, #16
    71f4:	f949fc44 	ldr	x4, [x2, #5112]
    71f8:	8b010821 	add	x1, x1, x1, lsl #2
    71fc:	d37df021 	lsl	x1, x1, #3
    7200:	8b010083 	add	x3, x4, x1
    7204:	f9401062 	ldr	x2, [x3, #32]
    7208:	b40002a2 	cbz	x2, 725c <fwp_caps23+0xac>
    720c:	38616881 	ldrb	w1, [x4, x1]
    7210:	7100083f 	cmp	w1, #0x2
    7214:	54000740 	b.eq	72fc <fwp_caps23+0x14c>  // b.none
    7218:	7100043f 	cmp	w1, #0x1
    721c:	54000201 	b.ne	725c <fwp_caps23+0xac>  // b.any
    7220:	29430464 	ldp	w4, w1, [x3, #24]
    7224:	92403c00 	and	x0, x0, #0xffff
    7228:	9b047c00 	mul	x0, x0, x4
    722c:	d360fc00 	lsr	x0, x0, #32
    7230:	eb01001f 	cmp	x0, x1
    7234:	54000142 	b.cs	725c <fwp_caps23+0xac>  // b.hs, b.nlast
    7238:	8b000042 	add	x2, x2, x0
    723c:	39400040 	ldrb	w0, [x2]
    7240:	7100041f 	cmp	w0, #0x1
    7244:	540000c1 	b.ne	725c <fwp_caps23+0xac>  // b.any
    7248:	aa1303e0 	mov	x0, x19
    724c:	f9400bf3 	ldr	x19, [sp, #16]
    7250:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7254:	17fff683 	b	4c60 <fwp_mem_free>
    7258:	34fffbe1 	cbz	w1, 71d4 <fwp_caps23+0x24>
    725c:	f9400bf3 	ldr	x19, [sp, #16]
    7260:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7264:	d65f03c0 	ret
    7268:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    726c:	91198042 	add	x2, x2, #0x660
    7270:	f949d843 	ldr	x3, [x2, #5040]
    7274:	f949ec41 	ldr	x1, [x2, #5080]
    7278:	cb030000 	sub	x0, x0, x3
    727c:	eb01401f 	cmp	x0, x1, lsl #16
    7280:	54fffee2 	b.cs	725c <fwp_caps23+0xac>  // b.hs, b.nlast
    7284:	d350fc01 	lsr	x1, x0, #16
    7288:	f949fc44 	ldr	x4, [x2, #5112]
    728c:	8b010821 	add	x1, x1, x1, lsl #2
    7290:	d37df021 	lsl	x1, x1, #3
    7294:	8b010083 	add	x3, x4, x1
    7298:	f9401062 	ldr	x2, [x3, #32]
    729c:	b4fffe02 	cbz	x2, 725c <fwp_caps23+0xac>
    72a0:	38616881 	ldrb	w1, [x4, x1]
    72a4:	7100083f 	cmp	w1, #0x2
    72a8:	54000300 	b.eq	7308 <fwp_caps23+0x158>  // b.none
    72ac:	7100043f 	cmp	w1, #0x1
    72b0:	54fffd61 	b.ne	725c <fwp_caps23+0xac>  // b.any
    72b4:	92403c01 	and	x1, x0, #0xffff
    72b8:	29430064 	ldp	w4, w0, [x3, #24]
    72bc:	9b047c21 	mul	x1, x1, x4
    72c0:	d360fc21 	lsr	x1, x1, #32
    72c4:	eb00003f 	cmp	x1, x0
    72c8:	54fffca2 	b.cs	725c <fwp_caps23+0xac>  // b.hs, b.nlast
    72cc:	8b010042 	add	x2, x2, x1
    72d0:	39400040 	ldrb	w0, [x2]
    72d4:	34fffc40 	cbz	w0, 725c <fwp_caps23+0xac>
    72d8:	b00000c1 	adrp	x1, 20000 <__data_start>
    72dc:	91018021 	add	x1, x1, #0x60
    72e0:	b9415023 	ldr	w3, [x1, #336]
    72e4:	35000183 	cbnz	w3, 7314 <fwp_caps23+0x164>
    72e8:	7103f41f 	cmp	w0, #0xfd
    72ec:	540001c8 	b.hi	7324 <fwp_caps23+0x174>  // b.pmore
    72f0:	11000400 	add	w0, w0, #0x1
    72f4:	39000040 	strb	w0, [x2]
    72f8:	17ffffd9 	b	725c <fwp_caps23+0xac>
    72fc:	72003c1f 	tst	w0, #0xffff
    7300:	54fffae1 	b.ne	725c <fwp_caps23+0xac>  // b.any
    7304:	17ffffce 	b	723c <fwp_caps23+0x8c>
    7308:	72003c1f 	tst	w0, #0xffff
    730c:	54fffa81 	b.ne	725c <fwp_caps23+0xac>  // b.any
    7310:	17fffff0 	b	72d0 <fwp_caps23+0x120>
    7314:	f940bc23 	ldr	x3, [x1, #376]
    7318:	91000463 	add	x3, x3, #0x1
    731c:	f900bc23 	str	x3, [x1, #376]
    7320:	17fffff2 	b	72e8 <fwp_caps23+0x138>
    7324:	f9400bf3 	ldr	x19, [sp, #16]
    7328:	aa0203e0 	mov	x0, x2
    732c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7330:	17fff565 	b	48c4 <fwp_rc_wide_dup>

0000000000007334 <fwp_caps12>:
    7334:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7338:	910003fd 	mov	x29, sp
    733c:	f9000bf3 	str	x19, [sp, #16]
    7340:	aa0003f3 	mov	x19, x0
    7344:	b9400400 	ldr	w0, [x0, #4]
    7348:	340004a0 	cbz	w0, 73dc <fwp_caps12+0xa8>
    734c:	f9400660 	ldr	x0, [x19, #8]
    7350:	350004e1 	cbnz	w1, 73ec <fwp_caps12+0xb8>
    7354:	97fffb63 	bl	60e0 <fwp_drop0>
    7358:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    735c:	91198042 	add	x2, x2, #0x660
    7360:	f949d840 	ldr	x0, [x2, #5040]
    7364:	f949ec41 	ldr	x1, [x2, #5080]
    7368:	cb000260 	sub	x0, x19, x0
    736c:	eb01401f 	cmp	x0, x1, lsl #16
    7370:	54000382 	b.cs	73e0 <fwp_caps12+0xac>  // b.hs, b.nlast
    7374:	d350fc01 	lsr	x1, x0, #16
    7378:	f949fc44 	ldr	x4, [x2, #5112]
    737c:	8b010821 	add	x1, x1, x1, lsl #2
    7380:	d37df021 	lsl	x1, x1, #3
    7384:	8b010083 	add	x3, x4, x1
    7388:	f9401062 	ldr	x2, [x3, #32]
    738c:	b40002a2 	cbz	x2, 73e0 <fwp_caps12+0xac>
    7390:	38616881 	ldrb	w1, [x4, x1]
    7394:	7100083f 	cmp	w1, #0x2
    7398:	54000740 	b.eq	7480 <fwp_caps12+0x14c>  // b.none
    739c:	7100043f 	cmp	w1, #0x1
    73a0:	54000201 	b.ne	73e0 <fwp_caps12+0xac>  // b.any
    73a4:	29430464 	ldp	w4, w1, [x3, #24]
    73a8:	92403c00 	and	x0, x0, #0xffff
    73ac:	9b047c00 	mul	x0, x0, x4
    73b0:	d360fc00 	lsr	x0, x0, #32
    73b4:	eb01001f 	cmp	x0, x1
    73b8:	54000142 	b.cs	73e0 <fwp_caps12+0xac>  // b.hs, b.nlast
    73bc:	8b000042 	add	x2, x2, x0
    73c0:	39400040 	ldrb	w0, [x2]
    73c4:	7100041f 	cmp	w0, #0x1
    73c8:	540000c1 	b.ne	73e0 <fwp_caps12+0xac>  // b.any
    73cc:	aa1303e0 	mov	x0, x19
    73d0:	f9400bf3 	ldr	x19, [sp, #16]
    73d4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    73d8:	17fff622 	b	4c60 <fwp_mem_free>
    73dc:	34fffbe1 	cbz	w1, 7358 <fwp_caps12+0x24>
    73e0:	f9400bf3 	ldr	x19, [sp, #16]
    73e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    73e8:	d65f03c0 	ret
    73ec:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xb80>
    73f0:	91198042 	add	x2, x2, #0x660
    73f4:	f949d843 	ldr	x3, [x2, #5040]
    73f8:	f949ec41 	ldr	x1, [x2, #5080]
    73fc:	cb030000 	sub	x0, x0, x3
    7400:	eb01401f 	cmp	x0, x1, lsl #16
    7404:	54fffee2 	b.cs	73e0 <fwp_caps12+0xac>  // b.hs, b.nlast
    7408:	d350fc01 	lsr	x1, x0, #16
    740c:	f949fc44 	ldr	x4, [x2, #5112]
    7410:	8b010821 	add	x1, x1, x1, lsl #2
    7414:	d37df021 	lsl	x1, x1, #3
    7418:	8b010083 	add	x3, x4, x1
    741c:	f9401062 	ldr	x2, [x3, #32]
    7420:	b4fffe02 	cbz	x2, 73e0 <fwp_caps12+0xac>
    7424:	38616881 	ldrb	w1, [x4, x1]
    7428:	7100083f 	cmp	w1, #0x2
    742c:	54000300 	b.eq	748c <fwp_caps12+0x158>  // b.none
    7430:	7100043f 	cmp	w1, #0x1
    7434:	54fffd61 	b.ne	73e0 <fwp_caps12+0xac>  // b.any
    7438:	92403c01 	and	x1, x0, #0xffff
    743c:	29430064 	ldp	w4, w0, [x3, #24]
    7440:	9b047c21 	mul	x1, x1, x4
    7444:	d360fc21 	lsr	x1, x1, #32
    7448:	eb00003f 	cmp	x1, x0
    744c:	54fffca2 	b.cs	73e0 <fwp_caps12+0xac>  // b.hs, b.nlast
    7450:	8b010042 	add	x2, x2, x1
    7454:	39400040 	ldrb	w0, [x2]
    7458:	34fffc40 	cbz	w0, 73e0 <fwp_caps12+0xac>
    745c:	b00000c1 	adrp	x1, 20000 <__data_start>
    7460:	91018021 	add	x1, x1, #0x60
    7464:	b9415023 	ldr	w3, [x1, #336]
    7468:	35000183 	cbnz	w3, 7498 <fwp_caps12+0x164>
    746c:	7103f41f 	cmp	w0, #0xfd
    7470:	540001c8 	b.hi	74a8 <fwp_caps12+0x174>  // b.pmore
    7474:	11000400 	add	w0, w0, #0x1
    7478:	39000040 	strb	w0, [x2]
    747c:	17ffffd9 	b	73e0 <fwp_caps12+0xac>
    7480:	72003c1f 	tst	w0, #0xffff
    7484:	54fffae1 	b.ne	73e0 <fwp_caps12+0xac>  // b.any
    7488:	17ffffce 	b	73c0 <fwp_caps12+0x8c>
    748c:	72003c1f 	tst	w0, #0xffff
    7490:	54fffa81 	b.ne	73e0 <fwp_caps12+0xac>  // b.any
    7494:	17fffff0 	b	7454 <fwp_caps12+0x120>
    7498:	f940bc23 	ldr	x3, [x1, #376]
    749c:	91000463 	add	x3, x3, #0x1
    74a0:	f900bc23 	str	x3, [x1, #376]
    74a4:	17fffff2 	b	746c <fwp_caps12+0x138>
    74a8:	f9400bf3 	ldr	x19, [sp, #16]
    74ac:	aa0203e0 	mov	x0, x2
    74b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    74b4:	17fff504 	b	48c4 <fwp_rc_wide_dup>
    74b8:	d503201f 	nop
    74bc:	d503201f 	nop

00000000000074c0 <f23>:
    74c0:	d101c3ff 	sub	sp, sp, #0x70
    74c4:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    74c8:	f947f421 	ldr	x1, [x1, #4072]
    74cc:	a9027bfd 	stp	x29, x30, [sp, #32]
    74d0:	910083fd 	add	x29, sp, #0x20
    74d4:	a90563f7 	stp	x23, x24, [sp, #80]
    74d8:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xb80>
    74dc:	911982e3 	add	x3, x23, #0x660
    74e0:	a90353f3 	stp	x19, x20, [sp, #48]
    74e4:	a9045bf5 	stp	x21, x22, [sp, #64]
    74e8:	aa0003f6 	mov	x22, x0
    74ec:	a9066bf9 	stp	x25, x26, [sp, #96]
    74f0:	f949ec62 	ldr	x2, [x3, #5080]
    74f4:	f9400024 	ldr	x4, [x1]
    74f8:	f9000fe4 	str	x4, [sp, #24]
    74fc:	d2800004 	mov	x4, #0x0                   	// #0
    7500:	f949d861 	ldr	x1, [x3, #5040]
    7504:	d370bc42 	lsl	x2, x2, #16
    7508:	b40016c0 	cbz	x0, 77e0 <f23+0x320>
    750c:	f9400818 	ldr	x24, [x0, #16]
    7510:	cb010301 	sub	x1, x24, x1
    7514:	eb02003f 	cmp	x1, x2
    7518:	540003e2 	b.cs	7594 <f23+0xd4>  // b.hs, b.nlast
    751c:	f949fc60 	ldr	x0, [x3, #5112]
    7520:	d350fc22 	lsr	x2, x1, #16
    7524:	8b020842 	add	x2, x2, x2, lsl #2
    7528:	8b020c02 	add	x2, x0, x2, lsl #3
    752c:	f9401040 	ldr	x0, [x2, #32]
    7530:	b4000320 	cbz	x0, 7594 <f23+0xd4>
    7534:	39400043 	ldrb	w3, [x2]
    7538:	7100087f 	cmp	w3, #0x2
    753c:	54001440 	b.eq	77c4 <f23+0x304>  // b.none
    7540:	7100047f 	cmp	w3, #0x1
    7544:	54000241 	b.ne	758c <f23+0xcc>  // b.any
    7548:	29430843 	ldp	w3, w2, [x2, #24]
    754c:	92403c21 	and	x1, x1, #0xffff
    7550:	9b037c21 	mul	x1, x1, x3
    7554:	d360fc21 	lsr	x1, x1, #32
    7558:	eb02003f 	cmp	x1, x2
    755c:	54000182 	b.cs	758c <f23+0xcc>  // b.hs, b.nlast
    7560:	8b010000 	add	x0, x0, x1
    7564:	39400001 	ldrb	w1, [x0]
    7568:	34000121 	cbz	w1, 758c <f23+0xcc>
    756c:	b00000c2 	adrp	x2, 20000 <__data_start>
    7570:	91018042 	add	x2, x2, #0x60
    7574:	b9415043 	ldr	w3, [x2, #336]
    7578:	350012c3 	cbnz	w3, 77d0 <f23+0x310>
    757c:	7103f43f 	cmp	w1, #0xfd
    7580:	54001728 	b.hi	7864 <f23+0x3a4>  // b.pmore
    7584:	11000421 	add	w1, w1, #0x1
    7588:	39000001 	strb	w1, [x0]
    758c:	d2800000 	mov	x0, #0x0                   	// #0
    7590:	b40000f6 	cbz	x22, 75ac <f23+0xec>
    7594:	aa1603e1 	mov	x1, x22
    7598:	d2800000 	mov	x0, #0x0                   	// #0
    759c:	d503201f 	nop
    75a0:	f9400821 	ldr	x1, [x1, #16]
    75a4:	91000400 	add	x0, x0, #0x1
    75a8:	b5ffffc1 	cbnz	x1, 75a0 <f23+0xe0>
    75ac:	b4001238 	cbz	x24, 77f0 <f23+0x330>
    75b0:	aa1803e1 	mov	x1, x24
    75b4:	d2800002 	mov	x2, #0x0                   	// #0
    75b8:	f9400821 	ldr	x1, [x1, #16]
    75bc:	91000442 	add	x2, x2, #0x1
    75c0:	b5ffffc1 	cbnz	x1, 75b8 <f23+0xf8>
    75c4:	eb00005f 	cmp	x2, x0
    75c8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    75cc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    75d0:	eb01033f 	cmp	x25, x1
    75d4:	540014e8 	b.hi	7870 <f23+0x3b0>  // b.pmore
    75d8:	d37ffb33 	lsl	x19, x25, #1
    75dc:	52800041 	mov	w1, #0x2                   	// #2
    75e0:	91000660 	add	x0, x19, #0x1
    75e4:	d37df000 	lsl	x0, x0, #3
    75e8:	97fff6be 	bl	50e0 <fwp_heap_alloc>
    75ec:	911982e1 	add	x1, x23, #0x660
    75f0:	aa0003fa 	mov	x26, x0
    75f4:	f9000013 	str	x19, [x0]
    75f8:	aa0103e0 	mov	x0, x1
    75fc:	f949d821 	ldr	x1, [x1, #5040]
    7600:	f949ec00 	ldr	x0, [x0, #5080]
    7604:	cb010341 	sub	x1, x26, x1
    7608:	eb00403f 	cmp	x1, x0, lsl #16
    760c:	54000342 	b.cs	7674 <f23+0x1b4>  // b.hs, b.nlast
    7610:	911982e2 	add	x2, x23, #0x660
    7614:	d350fc20 	lsr	x0, x1, #16
    7618:	8b000800 	add	x0, x0, x0, lsl #2
    761c:	f949fc43 	ldr	x3, [x2, #5112]
    7620:	d37df002 	lsl	x2, x0, #3
    7624:	8b020060 	add	x0, x3, x2
    7628:	f9401013 	ldr	x19, [x0, #32]
    762c:	b4000253 	cbz	x19, 7674 <f23+0x1b4>
    7630:	38626862 	ldrb	w2, [x3, x2]
    7634:	7100085f 	cmp	w2, #0x2
    7638:	54000c00 	b.eq	77b8 <f23+0x2f8>  // b.none
    763c:	7100045f 	cmp	w2, #0x1
    7640:	540001a1 	b.ne	7674 <f23+0x1b4>  // b.any
    7644:	29430002 	ldp	w2, w0, [x0, #24]
    7648:	92403c21 	and	x1, x1, #0xffff
    764c:	9b027c21 	mul	x1, x1, x2
    7650:	d360fc21 	lsr	x1, x1, #32
    7654:	eb00003f 	cmp	x1, x0
    7658:	540000e2 	b.cs	7674 <f23+0x1b4>  // b.hs, b.nlast
    765c:	8b010273 	add	x19, x19, x1
    7660:	39400260 	ldrb	w0, [x19]
    7664:	7103fc1f 	cmp	w0, #0xff
    7668:	54000e80 	b.eq	7838 <f23+0x378>  // b.none
    766c:	52800020 	mov	w0, #0x1                   	// #1
    7670:	39000260 	strb	w0, [x19]
    7674:	b4000259 	cbz	x25, 76bc <f23+0x1fc>
    7678:	8b191359 	add	x25, x26, x25, lsl #4
    767c:	aa1a03f3 	mov	x19, x26
    7680:	aa1603f5 	mov	x21, x22
    7684:	aa1803f4 	mov	x20, x24
    7688:	f9400683 	ldr	x3, [x20, #8]
    768c:	f94006a2 	ldr	x2, [x21, #8]
    7690:	f9400861 	ldr	x1, [x3, #16]
    7694:	f9400840 	ldr	x0, [x2, #16]
    7698:	fd400461 	ldr	d1, [x3, #8]
    769c:	fd400440 	ldr	d0, [x2, #8]
    76a0:	97fff82c 	bl	5750 <w107>
    76a4:	f9000660 	str	x0, [x19, #8]
    76a8:	f8010e61 	str	x1, [x19, #16]!
    76ac:	f9400a94 	ldr	x20, [x20, #16]
    76b0:	f9400ab5 	ldr	x21, [x21, #16]
    76b4:	eb13033f 	cmp	x25, x19
    76b8:	54fffe81 	b.ne	7688 <f23+0x1c8>  // b.any
    76bc:	aa1803e0 	mov	x0, x24
    76c0:	97fffdbc 	bl	6db0 <fwp_drop2>
    76c4:	aa1603e0 	mov	x0, x22
    76c8:	97fffdba 	bl	6db0 <fwp_drop2>
    76cc:	911982f7 	add	x23, x23, #0x660
    76d0:	aa1a03e0 	mov	x0, x26
    76d4:	97fff873 	bl	58a0 <w164.constprop.0>
    76d8:	aa0103f3 	mov	x19, x1
    76dc:	aa0003f4 	mov	x20, x0
    76e0:	aa1a03e0 	mov	x0, x26
    76e4:	97fffd13 	bl	6b30 <fwp_drop4>
    76e8:	a900cff4 	stp	x20, x19, [sp, #8]
    76ec:	910023e1 	add	x1, sp, #0x8
    76f0:	52800000 	mov	w0, #0x0                   	// #0
    76f4:	97fff897 	bl	5950 <fwp_data.part.0.constprop.0>
    76f8:	f949dae1 	ldr	x1, [x23, #5040]
    76fc:	aa0003f3 	mov	x19, x0
    7700:	f949eee0 	ldr	x0, [x23, #5080]
    7704:	cb010261 	sub	x1, x19, x1
    7708:	eb00403f 	cmp	x1, x0, lsl #16
    770c:	54000322 	b.cs	7770 <f23+0x2b0>  // b.hs, b.nlast
    7710:	d350fc22 	lsr	x2, x1, #16
    7714:	f949fee3 	ldr	x3, [x23, #5112]
    7718:	8b020842 	add	x2, x2, x2, lsl #2
    771c:	d37df042 	lsl	x2, x2, #3
    7720:	8b020060 	add	x0, x3, x2
    7724:	f9401014 	ldr	x20, [x0, #32]
    7728:	b4000254 	cbz	x20, 7770 <f23+0x2b0>
    772c:	38626862 	ldrb	w2, [x3, x2]
    7730:	7100085f 	cmp	w2, #0x2
    7734:	540003c0 	b.eq	77ac <f23+0x2ec>  // b.none
    7738:	7100045f 	cmp	w2, #0x1
    773c:	540001a1 	b.ne	7770 <f23+0x2b0>  // b.any
    7740:	29430002 	ldp	w2, w0, [x0, #24]
    7744:	92403c21 	and	x1, x1, #0xffff
    7748:	9b027c21 	mul	x1, x1, x2
    774c:	d360fc21 	lsr	x1, x1, #32
    7750:	eb00003f 	cmp	x1, x0
    7754:	540000e2 	b.cs	7770 <f23+0x2b0>  // b.hs, b.nlast
    7758:	8b010294 	add	x20, x20, x1
    775c:	39400280 	ldrb	w0, [x20]
    7760:	7103fc1f 	cmp	w0, #0xff
    7764:	54000640 	b.eq	782c <f23+0x36c>  // b.none
    7768:	52800020 	mov	w0, #0x1                   	// #1
    776c:	39000280 	strb	w0, [x20]
    7770:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    7774:	f947f400 	ldr	x0, [x0, #4072]
    7778:	f9400fe2 	ldr	x2, [sp, #24]
    777c:	f9400001 	ldr	x1, [x0]
    7780:	eb010042 	subs	x2, x2, x1
    7784:	d2800001 	mov	x1, #0x0                   	// #0
    7788:	54000721 	b.ne	786c <f23+0x3ac>  // b.any
    778c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7790:	aa1303e0 	mov	x0, x19
    7794:	a94353f3 	ldp	x19, x20, [sp, #48]
    7798:	a9445bf5 	ldp	x21, x22, [sp, #64]
    779c:	a94563f7 	ldp	x23, x24, [sp, #80]
    77a0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    77a4:	9101c3ff 	add	sp, sp, #0x70
    77a8:	d65f03c0 	ret
    77ac:	72003c3f 	tst	w1, #0xffff
    77b0:	54fffe01 	b.ne	7770 <f23+0x2b0>  // b.any
    77b4:	17ffffea 	b	775c <f23+0x29c>
    77b8:	72003c3f 	tst	w1, #0xffff
    77bc:	54fff5c1 	b.ne	7674 <f23+0x1b4>  // b.any
    77c0:	17ffffa8 	b	7660 <f23+0x1a0>
    77c4:	72003c3f 	tst	w1, #0xffff
    77c8:	54ffee21 	b.ne	758c <f23+0xcc>  // b.any
    77cc:	17ffff66 	b	7564 <f23+0xa4>
    77d0:	f940bc43 	ldr	x3, [x2, #376]
    77d4:	91000463 	add	x3, x3, #0x1
    77d8:	f900bc43 	str	x3, [x2, #376]
    77dc:	17ffff68 	b	757c <f23+0xbc>
    77e0:	cb0103e1 	neg	x1, x1
    77e4:	eb02003f 	cmp	x1, x2
    77e8:	540002e3 	b.cc	7844 <f23+0x384>  // b.lo, b.ul, b.last
    77ec:	d503201f 	nop
    77f0:	52800041 	mov	w1, #0x2                   	// #2
    77f4:	d2800100 	mov	x0, #0x8                   	// #8
    77f8:	97fff63a 	bl	50e0 <fwp_heap_alloc>
    77fc:	aa0003e1 	mov	x1, x0
    7800:	911982e0 	add	x0, x23, #0x660
    7804:	aa0103fa 	mov	x26, x1
    7808:	d2800018 	mov	x24, #0x0                   	// #0
    780c:	f900003f 	str	xzr, [x1]
    7810:	f949d801 	ldr	x1, [x0, #5040]
    7814:	f949ec00 	ldr	x0, [x0, #5080]
    7818:	cb010341 	sub	x1, x26, x1
    781c:	eb00403f 	cmp	x1, x0, lsl #16
    7820:	54fff4e2 	b.cs	76bc <f23+0x1fc>  // b.hs, b.nlast
    7824:	d2800019 	mov	x25, #0x0                   	// #0
    7828:	17ffff7a 	b	7610 <f23+0x150>
    782c:	aa1403e0 	mov	x0, x20
    7830:	97fff46c 	bl	49e0 <fwp_rc_forget_slot>
    7834:	17ffffcd 	b	7768 <f23+0x2a8>
    7838:	aa1303e0 	mov	x0, x19
    783c:	97fff469 	bl	49e0 <fwp_rc_forget_slot>
    7840:	17ffff8b 	b	766c <f23+0x1ac>
    7844:	f949fc62 	ldr	x2, [x3, #5112]
    7848:	d350fc20 	lsr	x0, x1, #16
    784c:	8b000800 	add	x0, x0, x0, lsl #2
    7850:	8b000c42 	add	x2, x2, x0, lsl #3
    7854:	f9401040 	ldr	x0, [x2, #32]
    7858:	b4fffcc0 	cbz	x0, 77f0 <f23+0x330>
    785c:	d2800018 	mov	x24, #0x0                   	// #0
    7860:	17ffff35 	b	7534 <f23+0x74>
    7864:	97fff418 	bl	48c4 <fwp_rc_wide_dup>
    7868:	17ffff49 	b	758c <f23+0xcc>
    786c:	97ffebe9 	bl	2810 <__stack_chk_fail@plt>
    7870:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    7874:	913e4000 	add	x0, x0, #0xf90
    7878:	97ffefc2 	bl	3780 <fwp_trap>
    787c:	d503201f 	nop

0000000000007880 <fwp_owned_entry23>:
    7880:	f9400000 	ldr	x0, [x0]
    7884:	17ffff0f 	b	74c0 <f23>
    7888:	d503201f 	nop
    788c:	d503201f 	nop

0000000000007890 <e23>:
    7890:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7894:	910003fd 	mov	x29, sp
    7898:	f9000bf3 	str	x19, [sp, #16]
    789c:	f9400013 	ldr	x19, [x0]
    78a0:	aa1303e0 	mov	x0, x19
    78a4:	97fff888 	bl	5ac4 <fwp_rc_share>
    78a8:	aa1303e0 	mov	x0, x19
    78ac:	97ffff05 	bl	74c0 <f23>
    78b0:	aa0003f3 	mov	x19, x0
    78b4:	97fff884 	bl	5ac4 <fwp_rc_share>
    78b8:	aa1303e0 	mov	x0, x19
    78bc:	f9400bf3 	ldr	x19, [sp, #16]
    78c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    78c4:	d65f03c0 	ret
    78c8:	d503201f 	nop
    78cc:	d503201f 	nop

00000000000078d0 <f12>:
    78d0:	d104c3ff 	sub	sp, sp, #0x130
    78d4:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    78d8:	f947f442 	ldr	x2, [x2, #4072]
    78dc:	a90c7bfd 	stp	x29, x30, [sp, #192]
    78e0:	910303fd 	add	x29, sp, #0xc0
    78e4:	a90f63f7 	stp	x23, x24, [sp, #240]
    78e8:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xb80>
    78ec:	911982e3 	add	x3, x23, #0x660
    78f0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    78f4:	b00000d5 	adrp	x21, 20000 <__data_start>
    78f8:	910182a4 	add	x4, x21, #0x60
    78fc:	f949d861 	ldr	x1, [x3, #5040]
    7900:	a90d53f3 	stp	x19, x20, [sp, #208]
    7904:	910103f8 	add	x24, sp, #0x40
    7908:	f949ec65 	ldr	x5, [x3, #5080]
    790c:	a9106bf9 	stp	x25, x26, [sp, #256]
    7910:	b00000d9 	adrp	x25, 20000 <__data_start>
    7914:	a91173fb 	stp	x27, x28, [sp, #272]
    7918:	91004339 	add	x25, x25, #0x10
    791c:	91008339 	add	x25, x25, #0x20
    7920:	f941d886 	ldr	x6, [x4, #944]
    7924:	fd0093e8 	str	d8, [sp, #288]
    7928:	f9400047 	ldr	x7, [x2]
    792c:	f9005fe7 	str	x7, [sp, #184]
    7930:	d2800007 	mov	x7, #0x0                   	// #0
    7934:	9100e3f6 	add	x22, sp, #0x38
    7938:	f0fffff3 	adrp	x19, 6000 <fwp_drop1+0x70>
    793c:	12800007 	mov	w7, #0xffffffff            	// #-1
    7940:	91178262 	add	x2, x19, #0x5e0
    7944:	cb010321 	sub	x1, x25, x1
    7948:	b9003be7 	str	w7, [sp, #56]
    794c:	aa0003f4 	mov	x20, x0
    7950:	a9040be6 	stp	x6, x2, [sp, #64]
    7954:	f9002bf6 	str	x22, [sp, #80]
    7958:	f901d898 	str	x24, [x4, #944]
    795c:	eb05403f 	cmp	x1, x5, lsl #16
    7960:	540003a2 	b.cs	79d4 <f12+0x104>  // b.hs, b.nlast
    7964:	d350fc20 	lsr	x0, x1, #16
    7968:	f949fc64 	ldr	x4, [x3, #5112]
    796c:	8b000800 	add	x0, x0, x0, lsl #2
    7970:	d37df002 	lsl	x2, x0, #3
    7974:	8b020083 	add	x3, x4, x2
    7978:	f9401060 	ldr	x0, [x3, #32]
    797c:	b40002c0 	cbz	x0, 79d4 <f12+0x104>
    7980:	38626882 	ldrb	w2, [x4, x2]
    7984:	7100085f 	cmp	w2, #0x2
    7988:	54006dc0 	b.eq	8740 <f12+0xe70>  // b.none
    798c:	7100045f 	cmp	w2, #0x1
    7990:	54000221 	b.ne	79d4 <f12+0x104>  // b.any
    7994:	29430864 	ldp	w4, w2, [x3, #24]
    7998:	92403c21 	and	x1, x1, #0xffff
    799c:	9b047c21 	mul	x1, x1, x4
    79a0:	d360fc21 	lsr	x1, x1, #32
    79a4:	eb02003f 	cmp	x1, x2
    79a8:	54000162 	b.cs	79d4 <f12+0x104>  // b.hs, b.nlast
    79ac:	8b010000 	add	x0, x0, x1
    79b0:	39400001 	ldrb	w1, [x0]
    79b4:	34000101 	cbz	w1, 79d4 <f12+0x104>
    79b8:	910182a2 	add	x2, x21, #0x60
    79bc:	b9415043 	ldr	w3, [x2, #336]
    79c0:	35006f43 	cbnz	w3, 87a8 <f12+0xed8>
    79c4:	7103f43f 	cmp	w1, #0xfd
    79c8:	54007928 	b.hi	88ec <f12+0x101c>  // b.pmore
    79cc:	11000421 	add	w1, w1, #0x1
    79d0:	39000001 	strb	w1, [x0]
    79d4:	aa1903e0 	mov	x0, x25
    79d8:	97fffa1e 	bl	6250 <fwp_closure_drop>
    79dc:	b4006bd4 	cbz	x20, 8754 <f12+0xe84>
    79e0:	aa1403e0 	mov	x0, x20
    79e4:	d2800001 	mov	x1, #0x0                   	// #0
    79e8:	f9400800 	ldr	x0, [x0, #16]
    79ec:	91000421 	add	x1, x1, #0x1
    79f0:	b5ffffc0 	cbnz	x0, 79e8 <f12+0x118>
    79f4:	aa0103fa 	mov	x26, x1
    79f8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    79fc:	eb00003f 	cmp	x1, x0
    7a00:	54007b48 	b.hi	8968 <f12+0x1098>  // b.pmore
    7a04:	910182b9 	add	x25, x21, #0x60
    7a08:	b943e720 	ldr	w0, [x25, #996]
    7a0c:	34006860 	cbz	w0, 8718 <f12+0xe48>
    7a10:	910182a0 	add	x0, x21, #0x60
    7a14:	f9406c1b 	ldr	x27, [x0, #216]
    7a18:	f940c019 	ldr	x25, [x0, #384]
    7a1c:	eb1b033f 	cmp	x25, x27
    7a20:	5400358a 	b.ge	80d0 <f12+0x800>  // b.tcont
    7a24:	f9404401 	ldr	x1, [x0, #136]
    7a28:	8b190720 	add	x0, x25, x25, lsl #1
    7a2c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7a30:	8b000b20 	add	x0, x25, x0, lsl #2
    7a34:	8b000c20 	add	x0, x1, x0, lsl #3
    7a38:	b9400401 	ldr	w1, [x0, #4]
    7a3c:	35000081 	cbnz	w1, 7a4c <f12+0x17c>
    7a40:	b9400001 	ldr	w1, [x0]
    7a44:	6b02003f 	cmp	w1, w2
    7a48:	54003449 	b.ls	80d0 <f12+0x800>  // b.plast
    7a4c:	91000739 	add	x25, x25, #0x1
    7a50:	9101a000 	add	x0, x0, #0x68
    7a54:	eb1b033f 	cmp	x25, x27
    7a58:	54ffff01 	b.ne	7a38 <f12+0x168>  // b.any
    7a5c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7a60:	eb00037f 	cmp	x27, x0
    7a64:	540078ec 	b.gt	8980 <f12+0x10b0>
    7a68:	910182a0 	add	x0, x21, #0x60
    7a6c:	f940a001 	ldr	x1, [x0, #320]
    7a70:	f940441c 	ldr	x28, [x0, #136]
    7a74:	eb1b003f 	cmp	x1, x27
    7a78:	54000221 	b.ne	7abc <f12+0x1ec>  // b.any
    7a7c:	b400721b 	cbz	x27, 88bc <f12+0xfec>
    7a80:	d37ffb79 	lsl	x25, x27, #1
    7a84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7a88:	eb00033f 	cmp	x25, x0
    7a8c:	9a80d339 	csel	x25, x25, x0, le
    7a90:	8b190721 	add	x1, x25, x25, lsl #1
    7a94:	8b010b21 	add	x1, x25, x1, lsl #2
    7a98:	d37df021 	lsl	x1, x1, #3
    7a9c:	aa1c03e0 	mov	x0, x28
    7aa0:	52800002 	mov	w2, #0x0                   	// #0
    7aa4:	97fff260 	bl	4424 <ad_raw_realloc>
    7aa8:	aa0003fc 	mov	x28, x0
    7aac:	b40035e0 	cbz	x0, 8168 <f12+0x898>
    7ab0:	910182a0 	add	x0, x21, #0x60
    7ab4:	f900441c 	str	x28, [x0, #136]
    7ab8:	f900a019 	str	x25, [x0, #320]
    7abc:	8b1b0761 	add	x1, x27, x27, lsl #1
    7ac0:	910182a0 	add	x0, x21, #0x60
    7ac4:	4f000400 	movi	v0.4s, #0x0
    7ac8:	aa1b03f9 	mov	x25, x27
    7acc:	8b010b61 	add	x1, x27, x1, lsl #2
    7ad0:	9100077b 	add	x27, x27, #0x1
    7ad4:	f9006c1b 	str	x27, [x0, #216]
    7ad8:	8b19073b 	add	x27, x25, x25, lsl #1
    7adc:	8b010f81 	add	x1, x28, x1, lsl #3
    7ae0:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    7ae4:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    7ae8:	91364000 	add	x0, x0, #0xd90
    7aec:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7af0:	ad000020 	stp	q0, q0, [x1]
    7af4:	ad010020 	stp	q0, q0, [x1, #32]
    7af8:	ad020020 	stp	q0, q0, [x1, #64]
    7afc:	f900303f 	str	xzr, [x1, #96]
    7b00:	f900337f 	str	xzr, [x27, #96]
    7b04:	97ffeba7 	bl	29a0 <getenv@plt>
    7b08:	b5002fc0 	cbnz	x0, 8100 <f12+0x830>
    7b0c:	d503201f 	nop
    7b10:	910182a0 	add	x0, x21, #0x60
    7b14:	f9409c01 	ldr	x1, [x0, #312]
    7b18:	b50062c1 	cbnz	x1, 8770 <f12+0xea0>
    7b1c:	910182a2 	add	x2, x21, #0x60
    7b20:	2f000400 	mvni	v0.2s, #0x0
    7b24:	b9400363 	ldr	w3, [x27]
    7b28:	52800024 	mov	w4, #0x1                   	// #1
    7b2c:	91000720 	add	x0, x25, #0x1
    7b30:	a900eb7a 	stp	x26, x26, [x27, #8]
    7b34:	0b040063 	add	w3, w3, w4
    7b38:	f941d841 	ldr	x1, [x2, #944]
    7b3c:	29001363 	stp	w3, w4, [x27]
    7b40:	f9002b7f 	str	xzr, [x27, #80]
    7b44:	f900c040 	str	x0, [x2, #384]
    7b48:	fd002f60 	str	d0, [x27, #88]
    7b4c:	b4007081 	cbz	x1, 895c <f12+0x108c>
    7b50:	91178273 	add	x19, x19, #0x5e0
    7b54:	14000003 	b	7b60 <f12+0x290>
    7b58:	f9400021 	ldr	x1, [x1]
    7b5c:	b4007001 	cbz	x1, 895c <f12+0x108c>
    7b60:	f9400422 	ldr	x2, [x1, #8]
    7b64:	eb13005f 	cmp	x2, x19
    7b68:	54ffff81 	b.ne	7b58 <f12+0x288>  // b.any
    7b6c:	f9400821 	ldr	x1, [x1, #16]
    7b70:	2a1903e4 	mov	w4, w25
    7b74:	b9400022 	ldr	w2, [x1]
    7b78:	f9002b61 	str	x1, [x27, #80]
    7b7c:	b9005f62 	str	w2, [x27, #92]
    7b80:	37f80082 	tbnz	w2, #31, 7b90 <f12+0x2c0>
    7b84:	52800d05 	mov	w5, #0x68                  	// #104
    7b88:	9b257042 	smaddl	x2, w2, w5, x28
    7b8c:	b9005859 	str	w25, [x2, #88]
    7b90:	b9000024 	str	w4, [x1]
    7b94:	d3707c79 	ubfiz	x25, x3, #16, #32
    7b98:	aa000339 	orr	x25, x25, x0
    7b9c:	d2800002 	mov	x2, #0x0                   	// #0
    7ba0:	aa1403e0 	mov	x0, x20
    7ba4:	b4005934 	cbz	x20, 86c8 <f12+0xdf8>
    7ba8:	f9400800 	ldr	x0, [x0, #16]
    7bac:	91000442 	add	x2, x2, #0x1
    7bb0:	b5ffffc0 	cbnz	x0, 7ba8 <f12+0x2d8>
    7bb4:	aa1403e1 	mov	x1, x20
    7bb8:	f9400821 	ldr	x1, [x1, #16]
    7bbc:	91000400 	add	x0, x0, #0x1
    7bc0:	b5ffffc1 	cbnz	x1, 7bb8 <f12+0x2e8>
    7bc4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7bc8:	eb01001f 	cmp	x0, x1
    7bcc:	54006b68 	b.hi	8938 <f12+0x1068>  // b.pmore
    7bd0:	f100005f 	cmp	x2, #0x0
    7bd4:	540057ad 	b.le	86c8 <f12+0xdf8>
    7bd8:	eb00005f 	cmp	x2, x0
    7bdc:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7be0:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7be4:	eb01027f 	cmp	x19, x1
    7be8:	54006a88 	b.hi	8938 <f12+0x1068>  // b.pmore
    7bec:	d37ffa7a 	lsl	x26, x19, #1
    7bf0:	52800041 	mov	w1, #0x2                   	// #2
    7bf4:	91000740 	add	x0, x26, #0x1
    7bf8:	d37df000 	lsl	x0, x0, #3
    7bfc:	97fff539 	bl	50e0 <fwp_heap_alloc>
    7c00:	aa0003fb 	mov	x27, x0
    7c04:	911982e1 	add	x1, x23, #0x660
    7c08:	aa0103e0 	mov	x0, x1
    7c0c:	f900037a 	str	x26, [x27]
    7c10:	f949d821 	ldr	x1, [x1, #5040]
    7c14:	f949ec00 	ldr	x0, [x0, #5080]
    7c18:	cb010361 	sub	x1, x27, x1
    7c1c:	eb00403f 	cmp	x1, x0, lsl #16
    7c20:	54005742 	b.cs	8708 <f12+0xe38>  // b.hs, b.nlast
    7c24:	911982e2 	add	x2, x23, #0x660
    7c28:	d350fc20 	lsr	x0, x1, #16
    7c2c:	8b000800 	add	x0, x0, x0, lsl #2
    7c30:	f949fc43 	ldr	x3, [x2, #5112]
    7c34:	d37df002 	lsl	x2, x0, #3
    7c38:	8b020060 	add	x0, x3, x2
    7c3c:	f940101a 	ldr	x26, [x0, #32]
    7c40:	b400025a 	cbz	x26, 7c88 <f12+0x3b8>
    7c44:	38626862 	ldrb	w2, [x3, x2]
    7c48:	7100085f 	cmp	w2, #0x2
    7c4c:	54005740 	b.eq	8734 <f12+0xe64>  // b.none
    7c50:	7100045f 	cmp	w2, #0x1
    7c54:	540001a1 	b.ne	7c88 <f12+0x3b8>  // b.any
    7c58:	29430002 	ldp	w2, w0, [x0, #24]
    7c5c:	92403c21 	and	x1, x1, #0xffff
    7c60:	9b027c21 	mul	x1, x1, x2
    7c64:	d360fc21 	lsr	x1, x1, #32
    7c68:	eb00003f 	cmp	x1, x0
    7c6c:	540000e2 	b.cs	7c88 <f12+0x3b8>  // b.hs, b.nlast
    7c70:	8b01035a 	add	x26, x26, x1
    7c74:	39400340 	ldrb	w0, [x26]
    7c78:	7103fc1f 	cmp	w0, #0xff
    7c7c:	54006260 	b.eq	88c8 <f12+0xff8>  // b.none
    7c80:	52800020 	mov	w0, #0x1                   	// #1
    7c84:	39000340 	strb	w0, [x26]
    7c88:	b4000233 	cbz	x19, 7ccc <f12+0x3fc>
    7c8c:	d3607f24 	lsl	x4, x25, #32
    7c90:	aa1403e2 	mov	x2, x20
    7c94:	f9400685 	ldr	x5, [x20, #8]
    7c98:	aa0403e3 	mov	x3, x4
    7c9c:	91002360 	add	x0, x27, #0x8
    7ca0:	d2800001 	mov	x1, #0x0                   	// #0
    7ca4:	14000005 	b	7cb8 <f12+0x3e8>
    7ca8:	f9400445 	ldr	x5, [x2, #8]
    7cac:	ab040023 	adds	x3, x1, x4
    7cb0:	91004000 	add	x0, x0, #0x10
    7cb4:	54006706 	b.vs	8994 <f12+0x10c4>
    7cb8:	a9000c05 	stp	x5, x3, [x0]
    7cbc:	91000421 	add	x1, x1, #0x1
    7cc0:	f9400842 	ldr	x2, [x2, #16]
    7cc4:	eb01027f 	cmp	x19, x1
    7cc8:	54ffff08 	b.hi	7ca8 <f12+0x3d8>  // b.pmore
    7ccc:	f9400360 	ldr	x0, [x27]
    7cd0:	f100041f 	cmp	x0, #0x1
    7cd4:	540051e9 	b.ls	8710 <f12+0xe40>  // b.plast
    7cd8:	d341fc00 	lsr	x0, x0, #1
    7cdc:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7ce0:	d1000401 	sub	x1, x0, #0x1
    7ce4:	eb02003f 	cmp	x1, x2
    7ce8:	54006288 	b.hi	8938 <f12+0x1068>  // b.pmore
    7cec:	d37ff83c 	lsl	x28, x1, #1
    7cf0:	b4005101 	cbz	x1, 8710 <f12+0xe40>
    7cf4:	d1002361 	sub	x1, x27, #0x8
    7cf8:	91002373 	add	x19, x27, #0x8
    7cfc:	8b00103a 	add	x26, x1, x0, lsl #4
    7d00:	f9400660 	ldr	x0, [x19, #8]
    7d04:	f9400e61 	ldr	x1, [x19, #24]
    7d08:	fd400260 	ldr	d0, [x19]
    7d0c:	fd400a61 	ldr	d1, [x19, #16]
    7d10:	97fff690 	bl	5750 <w107>
    7d14:	a9000660 	stp	x0, x1, [x19]
    7d18:	91004273 	add	x19, x19, #0x10
    7d1c:	eb1a027f 	cmp	x19, x26
    7d20:	54ffff01 	b.ne	7d00 <f12+0x430>  // b.any
    7d24:	f900037c 	str	x28, [x27]
    7d28:	aa1b03e0 	mov	x0, x27
    7d2c:	93407f33 	sxtw	x19, w25
    7d30:	97fff6dc 	bl	58a0 <w164.constprop.0>
    7d34:	aa0103fa 	mov	x26, x1
    7d38:	aa1b03e0 	mov	x0, x27
    7d3c:	97fffb7d 	bl	6b30 <fwp_drop4>
    7d40:	97fff141 	bl	4244 <caf61>
    7d44:	9e670008 	fmov	d8, x0
    7d48:	aa1303e0 	mov	x0, x19
    7d4c:	97ffef59 	bl	3ab0 <fwp_tape_of>
    7d50:	aa0003ea 	mov	x10, x0
    7d54:	f9403001 	ldr	x1, [x0, #96]
    7d58:	b50060e1 	cbnz	x1, 8974 <f12+0x10a4>
    7d5c:	97ffec8e 	bl	2f94 <fwp_tape_unlink_scope>
    7d60:	b9400002 	ldr	w2, [x0]
    7d64:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    7d68:	a940801c 	ldp	x28, x0, [x0, #8]
    7d6c:	b900055f 	str	wzr, [x10, #4]
    7d70:	a941994b 	ldp	x11, x6, [x10, #24]
    7d74:	a942a147 	ldp	x7, x8, [x10, #40]
    7d78:	a9439549 	ldp	x9, x5, [x10, #56]
    7d7c:	f940255b 	ldr	x27, [x10, #72]
    7d80:	6b01005f 	cmp	w2, w1
    7d84:	54000108 	b.hi	7da4 <f12+0x4d4>  // b.pmore
    7d88:	910182a2 	add	x2, x21, #0x60
    7d8c:	92403e61 	and	x1, x19, #0xffff
    7d90:	d1000421 	sub	x1, x1, #0x1
    7d94:	f940c043 	ldr	x3, [x2, #384]
    7d98:	eb03003f 	cmp	x1, x3
    7d9c:	5400004a 	b.ge	7da4 <f12+0x4d4>  // b.tcont
    7da0:	f900c041 	str	x1, [x2, #384]
    7da4:	4f000400 	movi	v0.4s, #0x0
    7da8:	910182a3 	add	x3, x21, #0x60
    7dac:	f9000d5f 	str	xzr, [x10, #24]
    7db0:	910163e1 	add	x1, sp, #0x58
    7db4:	9101c3f9 	add	x25, sp, #0x70
    7db8:	b0ffffe2 	adrp	x2, 4000 <fwp_heap_report+0xe0>
    7dbc:	f941d86c 	ldr	x12, [x3, #944]
    7dc0:	3c808140 	stur	q0, [x10, #8]
    7dc4:	9113d042 	add	x2, x2, #0x4f4
    7dc8:	ad010140 	stp	q0, q0, [x10, #32]
    7dcc:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    7dd0:	a9058bec 	stp	x12, x2, [sp, #88]
    7dd4:	a9069bf9 	stp	x25, x6, [sp, #104]
    7dd8:	a907a3e7 	stp	x7, x8, [sp, #120]
    7ddc:	a90897e9 	stp	x9, x5, [sp, #136]
    7de0:	a909efeb 	stp	x11, x27, [sp, #152]
    7de4:	f901d861 	str	x1, [x3, #944]
    7de8:	b7f84bba 	tbnz	x26, #63, 875c <f12+0xe8c>
    7dec:	eb9a827f 	cmp	x19, x26, asr #32
    7df0:	54005921 	b.ne	8914 <f12+0x1044>  // b.any
    7df4:	92407f53 	and	x19, x26, #0xffffffff
    7df8:	eb3a401f 	cmp	x0, w26, uxtw
    7dfc:	5400592d 	b.le	8920 <f12+0x1050>
    7e00:	eb13039f 	cmp	x28, x19
    7e04:	9a93c793 	csinc	x19, x28, x19, gt
    7e08:	eb13037f 	cmp	x27, x19
    7e0c:	540019aa 	b.ge	8140 <f12+0x870>  // b.tcont
    7e10:	f100037f 	cmp	x27, #0x0
    7e14:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7e18:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    7e1c:	14000004 	b	7e2c <f12+0x55c>
    7e20:	eb01037f 	cmp	x27, x1
    7e24:	d37ffb7b 	lsl	x27, x27, #1
    7e28:	9a93d37b 	csel	x27, x27, x19, le
    7e2c:	eb13037f 	cmp	x27, x19
    7e30:	54ffff8b 	b.lt	7e20 <f12+0x550>  // b.tstop
    7e34:	b4004dc5 	cbz	x5, 87ec <f12+0xf1c>
    7e38:	aa0503e0 	mov	x0, x5
    7e3c:	d37df361 	lsl	x1, x27, #3
    7e40:	52800062 	mov	w2, #0x3                   	// #3
    7e44:	a9009fe6 	stp	x6, x7, [sp, #8]
    7e48:	a901a7e8 	stp	x8, x9, [sp, #24]
    7e4c:	97fff176 	bl	4424 <ad_raw_realloc>
    7e50:	aa0003e5 	mov	x5, x0
    7e54:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7e58:	a941a7e8 	ldp	x8, x9, [sp, #24]
    7e5c:	b4004ae0 	cbz	x0, 87b8 <f12+0xee8>
    7e60:	f9004be5 	str	x5, [sp, #144]
    7e64:	f90053fb 	str	x27, [sp, #160]
    7e68:	b5001593 	cbnz	x19, 8118 <f12+0x848>
    7e6c:	b7f800ba 	tbnz	x26, #63, 7e80 <f12+0x5b0>
    7e70:	92407f41 	and	x1, x26, #0xffffffff
    7e74:	fc6178a0 	ldr	d0, [x5, x1, lsl #3]
    7e78:	1e682800 	fadd	d0, d0, d8
    7e7c:	fc2178a0 	str	d0, [x5, x1, lsl #3]
    7e80:	d1000673 	sub	x19, x19, #0x1
    7e84:	d1000783 	sub	x3, x28, #0x1
    7e88:	eb13039f 	cmp	x28, x19
    7e8c:	540003ac 	b.gt	7f00 <f12+0x630>
    7e90:	fc7378a0 	ldr	d0, [x5, x19, lsl #3]
    7e94:	1e602008 	fcmp	d0, #0.0
    7e98:	540002e0 	b.eq	7ef4 <f12+0x624>  // b.none
    7e9c:	cb1c0be0 	neg	x0, x28, lsl #2
    7ea0:	cb1c03e2 	neg	x2, x28
    7ea4:	8b0000c1 	add	x1, x6, x0
    7ea8:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    7eac:	37f80101 	tbnz	w1, #31, 7ecc <f12+0x5fc>
    7eb0:	8b020d0a 	add	x10, x8, x2, lsl #3
    7eb4:	93407c21 	sxtw	x1, w1
    7eb8:	fc737942 	ldr	d2, [x10, x19, lsl #3]
    7ebc:	fc6178a1 	ldr	d1, [x5, x1, lsl #3]
    7ec0:	1e620802 	fmul	d2, d0, d2
    7ec4:	1e622821 	fadd	d1, d1, d2
    7ec8:	fc2178a1 	str	d1, [x5, x1, lsl #3]
    7ecc:	8b0000e0 	add	x0, x7, x0
    7ed0:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    7ed4:	37f80100 	tbnz	w0, #31, 7ef4 <f12+0x624>
    7ed8:	8b020d22 	add	x2, x9, x2, lsl #3
    7edc:	93407c00 	sxtw	x0, w0
    7ee0:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    7ee4:	fc6078a1 	ldr	d1, [x5, x0, lsl #3]
    7ee8:	1e620800 	fmul	d0, d0, d2
    7eec:	1e602820 	fadd	d0, d1, d0
    7ef0:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    7ef4:	d1000673 	sub	x19, x19, #0x1
    7ef8:	eb13007f 	cmp	x3, x19
    7efc:	54fffca1 	b.ne	7e90 <f12+0x5c0>  // b.any
    7f00:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7f04:	eb00039f 	cmp	x28, x0
    7f08:	540051e8 	b.hi	8944 <f12+0x1074>  // b.pmore
    7f0c:	91000780 	add	x0, x28, #0x1
    7f10:	52800041 	mov	w1, #0x2                   	// #2
    7f14:	f90007e5 	str	x5, [sp, #8]
    7f18:	d37df000 	lsl	x0, x0, #3
    7f1c:	97fff471 	bl	50e0 <fwp_heap_alloc>
    7f20:	aa0003e2 	mov	x2, x0
    7f24:	aa0003f3 	mov	x19, x0
    7f28:	f94007e5 	ldr	x5, [sp, #8]
    7f2c:	d2800001 	mov	x1, #0x0                   	// #0
    7f30:	f800845c 	str	x28, [x2], #8
    7f34:	b40000dc 	cbz	x28, 7f4c <f12+0x67c>
    7f38:	f86178a0 	ldr	x0, [x5, x1, lsl #3]
    7f3c:	f8217840 	str	x0, [x2, x1, lsl #3]
    7f40:	91000421 	add	x1, x1, #0x1
    7f44:	eb01039f 	cmp	x28, x1
    7f48:	54ffff81 	b.ne	7f38 <f12+0x668>  // b.any
    7f4c:	910182a1 	add	x1, x21, #0x60
    7f50:	aa1903e0 	mov	x0, x25
    7f54:	f9402ffa 	ldr	x26, [sp, #88]
    7f58:	f901d83a 	str	x26, [x1, #944]
    7f5c:	97fff166 	bl	44f4 <fwp_tape_buffers_release>
    7f60:	911982e2 	add	x2, x23, #0x660
    7f64:	f949d841 	ldr	x1, [x2, #5040]
    7f68:	f949ec40 	ldr	x0, [x2, #5080]
    7f6c:	cb010261 	sub	x1, x19, x1
    7f70:	eb00403f 	cmp	x1, x0, lsl #16
    7f74:	54000322 	b.cs	7fd8 <f12+0x708>  // b.hs, b.nlast
    7f78:	d350fc20 	lsr	x0, x1, #16
    7f7c:	f949fc43 	ldr	x3, [x2, #5112]
    7f80:	8b000800 	add	x0, x0, x0, lsl #2
    7f84:	d37df002 	lsl	x2, x0, #3
    7f88:	8b020060 	add	x0, x3, x2
    7f8c:	f9401019 	ldr	x25, [x0, #32]
    7f90:	b4000259 	cbz	x25, 7fd8 <f12+0x708>
    7f94:	38626862 	ldrb	w2, [x3, x2]
    7f98:	7100085f 	cmp	w2, #0x2
    7f9c:	54003e40 	b.eq	8764 <f12+0xe94>  // b.none
    7fa0:	7100045f 	cmp	w2, #0x1
    7fa4:	540001a1 	b.ne	7fd8 <f12+0x708>  // b.any
    7fa8:	29430002 	ldp	w2, w0, [x0, #24]
    7fac:	92403c21 	and	x1, x1, #0xffff
    7fb0:	9b027c21 	mul	x1, x1, x2
    7fb4:	d360fc21 	lsr	x1, x1, #32
    7fb8:	eb00003f 	cmp	x1, x0
    7fbc:	540000e2 	b.cs	7fd8 <f12+0x708>  // b.hs, b.nlast
    7fc0:	8b010339 	add	x25, x25, x1
    7fc4:	39400320 	ldrb	w0, [x25]
    7fc8:	7103fc1f 	cmp	w0, #0xff
    7fcc:	54004840 	b.eq	88d4 <f12+0x1004>  // b.none
    7fd0:	52800020 	mov	w0, #0x1                   	// #1
    7fd4:	39000320 	strb	w0, [x25]
    7fd8:	eb18035f 	cmp	x26, x24
    7fdc:	54004da1 	b.ne	8990 <f12+0x10c0>  // b.any
    7fe0:	f94023e1 	ldr	x1, [sp, #64]
    7fe4:	910182b5 	add	x21, x21, #0x60
    7fe8:	aa1603e0 	mov	x0, x22
    7fec:	f901daa1 	str	x1, [x21, #944]
    7ff0:	97fff97c 	bl	65e0 <fwp_tape_scope_release>
    7ff4:	f9400260 	ldr	x0, [x19]
    7ff8:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    7ffc:	b7f83120 	tbnz	x0, #63, 8620 <f12+0xd50>
    8000:	911982e2 	add	x2, x23, #0x660
    8004:	f949d840 	ldr	x0, [x2, #5040]
    8008:	f949ec41 	ldr	x1, [x2, #5080]
    800c:	cb000260 	sub	x0, x19, x0
    8010:	eb01401f 	cmp	x0, x1, lsl #16
    8014:	54003062 	b.cs	8620 <f12+0xd50>  // b.hs, b.nlast
    8018:	d350fc01 	lsr	x1, x0, #16
    801c:	f949fc44 	ldr	x4, [x2, #5112]
    8020:	8b010821 	add	x1, x1, x1, lsl #2
    8024:	d37df021 	lsl	x1, x1, #3
    8028:	8b010083 	add	x3, x4, x1
    802c:	f9401062 	ldr	x2, [x3, #32]
    8030:	b4002f82 	cbz	x2, 8620 <f12+0xd50>
    8034:	38616881 	ldrb	w1, [x4, x1]
    8038:	7100083f 	cmp	w1, #0x2
    803c:	54002ec0 	b.eq	8614 <f12+0xd44>  // b.none
    8040:	7100043f 	cmp	w1, #0x1
    8044:	54002ee1 	b.ne	8620 <f12+0xd50>  // b.any
    8048:	29430464 	ldp	w4, w1, [x3, #24]
    804c:	92403c00 	and	x0, x0, #0xffff
    8050:	9b047c00 	mul	x0, x0, x4
    8054:	d360fc00 	lsr	x0, x0, #32
    8058:	eb01001f 	cmp	x0, x1
    805c:	54002e22 	b.cs	8620 <f12+0xd50>  // b.hs, b.nlast
    8060:	8b000042 	add	x2, x2, x0
    8064:	39400040 	ldrb	w0, [x2]
    8068:	7100041f 	cmp	w0, #0x1
    806c:	54002da1 	b.ne	8620 <f12+0xd50>  // b.any
    8070:	aa1303f5 	mov	x21, x19
    8074:	d2800000 	mov	x0, #0x0                   	// #0
    8078:	f90007f3 	str	x19, [sp, #8]
    807c:	f94007e1 	ldr	x1, [sp, #8]
    8080:	91002023 	add	x3, x1, #0x8
    8084:	d2800001 	mov	x1, #0x0                   	// #0
    8088:	b4000898 	cbz	x24, 8198 <f12+0x8c8>
    808c:	d0000022 	adrp	x2, e000 <_IO_stdin_used+0x670>
    8090:	91002265 	add	x5, x19, #0x8
    8094:	fd44b041 	ldr	d1, [x2, #2400]
    8098:	14000009 	b	80bc <f12+0x7ec>
    809c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    80a0:	f94002a2 	ldr	x2, [x21]
    80a4:	1e600820 	fmul	d0, d1, d0
    80a8:	b7f84422 	tbnz	x2, #63, 892c <f12+0x105c>
    80ac:	91000421 	add	x1, x1, #0x1
    80b0:	fc008460 	str	d0, [x3], #8
    80b4:	eb01031f 	cmp	x24, x1
    80b8:	54000700 	b.eq	8198 <f12+0x8c8>  // b.none
    80bc:	f9400264 	ldr	x4, [x19]
    80c0:	aa0503e2 	mov	x2, x5
    80c4:	b6fffec4 	tbz	x4, #63, 809c <f12+0x7cc>
    80c8:	f9400a62 	ldr	x2, [x19, #16]
    80cc:	17fffff4 	b	809c <f12+0x7cc>
    80d0:	eb19037f 	cmp	x27, x25
    80d4:	54ffcc40 	b.eq	7a5c <f12+0x18c>  // b.none
    80d8:	910182a0 	add	x0, x21, #0x60
    80dc:	8b19073b 	add	x27, x25, x25, lsl #1
    80e0:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    80e4:	f940441c 	ldr	x28, [x0, #136]
    80e8:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    80ec:	91364000 	add	x0, x0, #0xd90
    80f0:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    80f4:	f900337f 	str	xzr, [x27, #96]
    80f8:	97ffea2a 	bl	29a0 <getenv@plt>
    80fc:	b4ffd0a0 	cbz	x0, 7b10 <f12+0x240>
    8100:	39400001 	ldrb	w1, [x0]
    8104:	7100c03f 	cmp	w1, #0x30
    8108:	54ffd041 	b.ne	7b10 <f12+0x240>  // b.any
    810c:	39400400 	ldrb	w0, [x0, #1]
    8110:	34ffd060 	cbz	w0, 7b1c <f12+0x24c>
    8114:	17fffe7f 	b	7b10 <f12+0x240>
    8118:	aa0503e0 	mov	x0, x5
    811c:	d37df262 	lsl	x2, x19, #3
    8120:	52800001 	mov	w1, #0x0                   	// #0
    8124:	a9009fe6 	stp	x6, x7, [sp, #8]
    8128:	a901a7e8 	stp	x8, x9, [sp, #24]
    812c:	97ffe9ad 	bl	27e0 <memset@plt>
    8130:	aa0003e5 	mov	x5, x0
    8134:	a9409fe6 	ldp	x6, x7, [sp, #8]
    8138:	a941a7e8 	ldp	x8, x9, [sp, #24]
    813c:	17ffff4c 	b	7e6c <f12+0x59c>
    8140:	f10000bf 	cmp	x5, #0x0
    8144:	1a9f17e0 	cset	w0, eq	// eq = none
    8148:	f100027f 	cmp	x19, #0x0
    814c:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8150:	54ffe8c0 	b.eq	7e68 <f12+0x598>  // b.none
    8154:	f9402fe1 	ldr	x1, [sp, #88]
    8158:	910182b5 	add	x21, x21, #0x60
    815c:	aa1903e0 	mov	x0, x25
    8160:	f901daa1 	str	x1, [x21, #944]
    8164:	97fff0e4 	bl	44f4 <fwp_tape_buffers_release>
    8168:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    816c:	f947e863 	ldr	x3, [x3, #4048]
    8170:	d2800262 	mov	x2, #0x13                  	// #19
    8174:	d2800021 	mov	x1, #0x1                   	// #1
    8178:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    817c:	91266000 	add	x0, x0, #0x998
    8180:	f9400063 	ldr	x3, [x3]
    8184:	97ffe9e3 	bl	2910 <fwrite@plt>
    8188:	d2800000 	mov	x0, #0x0                   	// #0
    818c:	97ffe9ed 	bl	2940 <fflush@plt>
    8190:	52800cc0 	mov	w0, #0x66                  	// #102
    8194:	97ffe9fb 	bl	2980 <_Exit@plt>
    8198:	97fffa66 	bl	6b30 <fwp_drop4>
    819c:	aa1403e1 	mov	x1, x20
    81a0:	d2800002 	mov	x2, #0x0                   	// #0
    81a4:	b4003774 	cbz	x20, 8890 <f12+0xfc0>
    81a8:	f9400821 	ldr	x1, [x1, #16]
    81ac:	91000442 	add	x2, x2, #0x1
    81b0:	b5ffffc1 	cbnz	x1, 81a8 <f12+0x8d8>
    81b4:	f94002a3 	ldr	x3, [x21]
    81b8:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    81bc:	b7f81f63 	tbnz	x3, #63, 85a8 <f12+0xcd8>
    81c0:	911982e1 	add	x1, x23, #0x660
    81c4:	f94007e4 	ldr	x4, [sp, #8]
    81c8:	f949d820 	ldr	x0, [x1, #5040]
    81cc:	f949ec21 	ldr	x1, [x1, #5080]
    81d0:	cb000080 	sub	x0, x4, x0
    81d4:	eb01401f 	cmp	x0, x1, lsl #16
    81d8:	54001e82 	b.cs	85a8 <f12+0xcd8>  // b.hs, b.nlast
    81dc:	911982e4 	add	x4, x23, #0x660
    81e0:	d350fc01 	lsr	x1, x0, #16
    81e4:	8b010821 	add	x1, x1, x1, lsl #2
    81e8:	f949fc86 	ldr	x6, [x4, #5112]
    81ec:	d37df021 	lsl	x1, x1, #3
    81f0:	8b0100c5 	add	x5, x6, x1
    81f4:	f94010a4 	ldr	x4, [x5, #32]
    81f8:	b4001d64 	cbz	x4, 85a4 <f12+0xcd4>
    81fc:	386168c1 	ldrb	w1, [x6, x1]
    8200:	7100083f 	cmp	w1, #0x2
    8204:	54001cc0 	b.eq	859c <f12+0xccc>  // b.none
    8208:	7100043f 	cmp	w1, #0x1
    820c:	54001cc1 	b.ne	85a4 <f12+0xcd4>  // b.any
    8210:	294304a6 	ldp	w6, w1, [x5, #24]
    8214:	92403c00 	and	x0, x0, #0xffff
    8218:	9b067c00 	mul	x0, x0, x6
    821c:	d360fc00 	lsr	x0, x0, #32
    8220:	eb01001f 	cmp	x0, x1
    8224:	54001c02 	b.cs	85a4 <f12+0xcd4>  // b.hs, b.nlast
    8228:	8b000084 	add	x4, x4, x0
    822c:	39400098 	ldrb	w24, [x4]
    8230:	7100071f 	cmp	w24, #0x1
    8234:	54001b81 	b.ne	85a4 <f12+0xcd4>  // b.any
    8238:	b90013f8 	str	w24, [sp, #16]
    823c:	eb1c005f 	cmp	x2, x28
    8240:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    8244:	910022b9 	add	x25, x21, #0x8
    8248:	b400361c 	cbz	x28, 8908 <f12+0x1038>
    824c:	f94007e0 	ldr	x0, [sp, #8]
    8250:	d37df385 	lsl	x5, x28, #3
    8254:	aa1403e2 	mov	x2, x20
    8258:	d2800001 	mov	x1, #0x0                   	// #0
    825c:	91002000 	add	x0, x0, #0x8
    8260:	1400000a 	b	8288 <f12+0x9b8>
    8264:	fc616881 	ldr	d1, [x4, x1]
    8268:	fd400440 	ldr	d0, [x2, #8]
    826c:	1e613800 	fsub	d0, d0, d1
    8270:	fc216b20 	str	d0, [x25, x1]
    8274:	91002021 	add	x1, x1, #0x8
    8278:	f9400842 	ldr	x2, [x2, #16]
    827c:	eb05003f 	cmp	x1, x5
    8280:	540001c0 	b.eq	82b8 <f12+0x9e8>  // b.none
    8284:	f94002a3 	ldr	x3, [x21]
    8288:	aa0003e4 	mov	x4, x0
    828c:	b6fffec3 	tbz	x3, #63, 8264 <f12+0x994>
    8290:	f94007e3 	ldr	x3, [sp, #8]
    8294:	fd400440 	ldr	d0, [x2, #8]
    8298:	f9400864 	ldr	x4, [x3, #16]
    829c:	fc616881 	ldr	d1, [x4, x1]
    82a0:	1e613800 	fsub	d0, d0, d1
    82a4:	fc216b20 	str	d0, [x25, x1]
    82a8:	91002021 	add	x1, x1, #0x8
    82ac:	f9400842 	ldr	x2, [x2, #16]
    82b0:	eb05003f 	cmp	x1, x5
    82b4:	54fffe81 	b.ne	8284 <f12+0x9b4>  // b.any
    82b8:	b4003254 	cbz	x20, 8900 <f12+0x1030>
    82bc:	911982e0 	add	x0, x23, #0x660
    82c0:	aa1403e2 	mov	x2, x20
    82c4:	d280001a 	mov	x26, #0x0                   	// #0
    82c8:	f949ec06 	ldr	x6, [x0, #5080]
    82cc:	f949d807 	ldr	x7, [x0, #5040]
    82d0:	f949fc05 	ldr	x5, [x0, #5112]
    82d4:	d370bcc6 	lsl	x6, x6, #16
    82d8:	14000006 	b	82f0 <f12+0xa20>
    82dc:	f9400842 	ldr	x2, [x2, #16]
    82e0:	9100075a 	add	x26, x26, #0x1
    82e4:	f100005f 	cmp	x2, #0x0
    82e8:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    82ec:	54000329 	b.ls	8350 <f12+0xa80>  // b.plast
    82f0:	cb070040 	sub	x0, x2, x7
    82f4:	eb06001f 	cmp	x0, x6
    82f8:	540002c2 	b.cs	8350 <f12+0xa80>  // b.hs, b.nlast
    82fc:	d350fc01 	lsr	x1, x0, #16
    8300:	8b010821 	add	x1, x1, x1, lsl #2
    8304:	d37df021 	lsl	x1, x1, #3
    8308:	8b0100a4 	add	x4, x5, x1
    830c:	f9401083 	ldr	x3, [x4, #32]
    8310:	b4000203 	cbz	x3, 8350 <f12+0xa80>
    8314:	386168a1 	ldrb	w1, [x5, x1]
    8318:	7100083f 	cmp	w1, #0x2
    831c:	54000de0 	b.eq	84d8 <f12+0xc08>  // b.none
    8320:	7100043f 	cmp	w1, #0x1
    8324:	54000161 	b.ne	8350 <f12+0xa80>  // b.any
    8328:	29430488 	ldp	w8, w1, [x4, #24]
    832c:	92403c00 	and	x0, x0, #0xffff
    8330:	9b087c00 	mul	x0, x0, x8
    8334:	d360fc00 	lsr	x0, x0, #32
    8338:	eb01001f 	cmp	x0, x1
    833c:	540000a2 	b.cs	8350 <f12+0xa80>  // b.hs, b.nlast
    8340:	8b000063 	add	x3, x3, x0
    8344:	39400060 	ldrb	w0, [x3]
    8348:	7100041f 	cmp	w0, #0x1
    834c:	54fffc80 	b.eq	82dc <f12+0xa0c>  // b.none
    8350:	eb1a039f 	cmp	x28, x26
    8354:	54000ca9 	b.ls	84e8 <f12+0xc18>  // b.plast
    8358:	d1002336 	sub	x22, x25, #0x8
    835c:	9102a3f5 	add	x21, sp, #0xa8
    8360:	911982f8 	add	x24, x23, #0x660
    8364:	d2800013 	mov	x19, #0x0                   	// #0
    8368:	14000012 	b	83b0 <f12+0xae0>
    836c:	7100045f 	cmp	w2, #0x1
    8370:	540001a1 	b.ne	83a4 <f12+0xad4>  // b.any
    8374:	29430002 	ldp	w2, w0, [x0, #24]
    8378:	92403c21 	and	x1, x1, #0xffff
    837c:	9b027c21 	mul	x1, x1, x2
    8380:	d360fc21 	lsr	x1, x1, #32
    8384:	eb00003f 	cmp	x1, x0
    8388:	540000e2 	b.cs	83a4 <f12+0xad4>  // b.hs, b.nlast
    838c:	8b01037b 	add	x27, x27, x1
    8390:	39400360 	ldrb	w0, [x27]
    8394:	7103fc1f 	cmp	w0, #0xff
    8398:	54001b20 	b.eq	86fc <f12+0xe2c>  // b.none
    839c:	52800020 	mov	w0, #0x1                   	// #1
    83a0:	39000360 	strb	w0, [x27]
    83a4:	d100079c 	sub	x28, x28, #0x1
    83a8:	eb1c035f 	cmp	x26, x28
    83ac:	54000362 	b.cs	8418 <f12+0xb48>  // b.hs, b.nlast
    83b0:	f87c7ac2 	ldr	x2, [x22, x28, lsl #3]
    83b4:	aa1503e1 	mov	x1, x21
    83b8:	52800020 	mov	w0, #0x1                   	// #1
    83bc:	a90acfe2 	stp	x2, x19, [sp, #168]
    83c0:	97fff564 	bl	5950 <fwp_data.part.0.constprop.0>
    83c4:	aa0003f3 	mov	x19, x0
    83c8:	f949db01 	ldr	x1, [x24, #5040]
    83cc:	f949ef00 	ldr	x0, [x24, #5080]
    83d0:	cb010261 	sub	x1, x19, x1
    83d4:	eb00403f 	cmp	x1, x0, lsl #16
    83d8:	54fffe62 	b.cs	83a4 <f12+0xad4>  // b.hs, b.nlast
    83dc:	d350fc22 	lsr	x2, x1, #16
    83e0:	f949ff03 	ldr	x3, [x24, #5112]
    83e4:	8b020842 	add	x2, x2, x2, lsl #2
    83e8:	d37df042 	lsl	x2, x2, #3
    83ec:	8b020060 	add	x0, x3, x2
    83f0:	f940101b 	ldr	x27, [x0, #32]
    83f4:	b4fffd9b 	cbz	x27, 83a4 <f12+0xad4>
    83f8:	38626862 	ldrb	w2, [x3, x2]
    83fc:	7100085f 	cmp	w2, #0x2
    8400:	54fffb61 	b.ne	836c <f12+0xa9c>  // b.any
    8404:	72003c3f 	tst	w1, #0xffff
    8408:	54fffc40 	b.eq	8390 <f12+0xac0>  // b.none
    840c:	d100079c 	sub	x28, x28, #0x1
    8410:	eb1c035f 	cmp	x26, x28
    8414:	54fffce3 	b.cc	83b0 <f12+0xae0>  // b.lo, b.ul, b.last
    8418:	b50006ba 	cbnz	x26, 84ec <f12+0xc1c>
    841c:	b94013e0 	ldr	w0, [sp, #16]
    8420:	d2800038 	mov	x24, #0x1                   	// #1
    8424:	d280001b 	mov	x27, #0x0                   	// #0
    8428:	7100001f 	cmp	w0, #0x0
    842c:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    8430:	b40007db 	cbz	x27, 8528 <f12+0xc58>
    8434:	d100077b 	sub	x27, x27, #0x1
    8438:	911982f7 	add	x23, x23, #0x660
    843c:	d503201f 	nop
    8440:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    8444:	aa1503e1 	mov	x1, x21
    8448:	52800020 	mov	w0, #0x1                   	// #1
    844c:	a90acfe2 	stp	x2, x19, [sp, #168]
    8450:	97fff540 	bl	5950 <fwp_data.part.0.constprop.0>
    8454:	aa0003f3 	mov	x19, x0
    8458:	f949dae1 	ldr	x1, [x23, #5040]
    845c:	f949eee0 	ldr	x0, [x23, #5080]
    8460:	cb010261 	sub	x1, x19, x1
    8464:	eb00403f 	cmp	x1, x0, lsl #16
    8468:	54000302 	b.cs	84c8 <f12+0xbf8>  // b.hs, b.nlast
    846c:	d350fc22 	lsr	x2, x1, #16
    8470:	f949fee3 	ldr	x3, [x23, #5112]
    8474:	8b020842 	add	x2, x2, x2, lsl #2
    8478:	d37df042 	lsl	x2, x2, #3
    847c:	8b020060 	add	x0, x3, x2
    8480:	f940101a 	ldr	x26, [x0, #32]
    8484:	b400023a 	cbz	x26, 84c8 <f12+0xbf8>
    8488:	38626862 	ldrb	w2, [x3, x2]
    848c:	7100085f 	cmp	w2, #0x2
    8490:	54000800 	b.eq	8590 <f12+0xcc0>  // b.none
    8494:	7100045f 	cmp	w2, #0x1
    8498:	54000181 	b.ne	84c8 <f12+0xbf8>  // b.any
    849c:	29430002 	ldp	w2, w0, [x0, #24]
    84a0:	92403c21 	and	x1, x1, #0xffff
    84a4:	9b027c21 	mul	x1, x1, x2
    84a8:	d360fc21 	lsr	x1, x1, #32
    84ac:	eb00003f 	cmp	x1, x0
    84b0:	540000c2 	b.cs	84c8 <f12+0xbf8>  // b.hs, b.nlast
    84b4:	8b01035a 	add	x26, x26, x1
    84b8:	39400340 	ldrb	w0, [x26]
    84bc:	7103fc1f 	cmp	w0, #0xff
    84c0:	54000620 	b.eq	8584 <f12+0xcb4>  // b.none
    84c4:	39000358 	strb	w24, [x26]
    84c8:	d100077b 	sub	x27, x27, #0x1
    84cc:	b100077f 	cmn	x27, #0x1
    84d0:	54fffb81 	b.ne	8440 <f12+0xb70>  // b.any
    84d4:	14000015 	b	8528 <f12+0xc58>
    84d8:	72003c1f 	tst	w0, #0xffff
    84dc:	54fff340 	b.eq	8344 <f12+0xa74>  // b.none
    84e0:	eb1a039f 	cmp	x28, x26
    84e4:	54fff3a8 	b.hi	8358 <f12+0xa88>  // b.pmore
    84e8:	d2800013 	mov	x19, #0x0                   	// #0
    84ec:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    84f0:	aa1903e1 	mov	x1, x25
    84f4:	aa1403e0 	mov	x0, x20
    84f8:	f8408422 	ldr	x2, [x1], #8
    84fc:	f9000402 	str	x2, [x0, #8]
    8500:	aa0003e2 	mov	x2, x0
    8504:	f9400800 	ldr	x0, [x0, #16]
    8508:	eb01035f 	cmp	x26, x1
    850c:	54ffff61 	b.ne	84f8 <f12+0xc28>  // b.any
    8510:	b94013e1 	ldr	w1, [sp, #16]
    8514:	f9000853 	str	x19, [x2, #16]
    8518:	aa1403f3 	mov	x19, x20
    851c:	aa0003f4 	mov	x20, x0
    8520:	34000041 	cbz	w1, 8528 <f12+0xc58>
    8524:	d2800019 	mov	x25, #0x0                   	// #0
    8528:	aa1903e0 	mov	x0, x25
    852c:	97fff1cd 	bl	4c60 <fwp_mem_free>
    8530:	f94007e0 	ldr	x0, [sp, #8]
    8534:	97fff97f 	bl	6b30 <fwp_drop4>
    8538:	aa1403e0 	mov	x0, x20
    853c:	97fff6e9 	bl	60e0 <fwp_drop0>
    8540:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8544:	f947f400 	ldr	x0, [x0, #4072]
    8548:	f9405fe2 	ldr	x2, [sp, #184]
    854c:	f9400001 	ldr	x1, [x0]
    8550:	eb010042 	subs	x2, x2, x1
    8554:	d2800001 	mov	x1, #0x0                   	// #0
    8558:	540021a1 	b.ne	898c <f12+0x10bc>  // b.any
    855c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    8560:	aa1303e0 	mov	x0, x19
    8564:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8568:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    856c:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8570:	a9506bf9 	ldp	x25, x26, [sp, #256]
    8574:	a95173fb 	ldp	x27, x28, [sp, #272]
    8578:	fd4093e8 	ldr	d8, [sp, #288]
    857c:	9104c3ff 	add	sp, sp, #0x130
    8580:	d65f03c0 	ret
    8584:	aa1a03e0 	mov	x0, x26
    8588:	97fff116 	bl	49e0 <fwp_rc_forget_slot>
    858c:	17ffffce 	b	84c4 <f12+0xbf4>
    8590:	72003c3f 	tst	w1, #0xffff
    8594:	54fff9a1 	b.ne	84c8 <f12+0xbf8>  // b.any
    8598:	17ffffc8 	b	84b8 <f12+0xbe8>
    859c:	72003c1f 	tst	w0, #0xffff
    85a0:	54ffe460 	b.eq	822c <f12+0x95c>  // b.none
    85a4:	b4001114 	cbz	x20, 87c4 <f12+0xef4>
    85a8:	aa1403f3 	mov	x19, x20
    85ac:	d2800018 	mov	x24, #0x0                   	// #0
    85b0:	f9400a73 	ldr	x19, [x19, #16]
    85b4:	aa1803e0 	mov	x0, x24
    85b8:	91000718 	add	x24, x24, #0x1
    85bc:	b5ffffb3 	cbnz	x19, 85b0 <f12+0xce0>
    85c0:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    85c4:	eb01031f 	cmp	x24, x1
    85c8:	54001b88 	b.hi	8938 <f12+0x1068>  // b.pmore
    85cc:	91000800 	add	x0, x0, #0x2
    85d0:	52800041 	mov	w1, #0x2                   	// #2
    85d4:	d37df000 	lsl	x0, x0, #3
    85d8:	97fff2c2 	bl	50e0 <fwp_heap_alloc>
    85dc:	eb1c031f 	cmp	x24, x28
    85e0:	aa0003f9 	mov	x25, x0
    85e4:	9a9c931c 	csel	x28, x24, x28, ls	// ls = plast
    85e8:	aa1403e1 	mov	x1, x20
    85ec:	d503201f 	nop
    85f0:	f9400420 	ldr	x0, [x1, #8]
    85f4:	f8337b20 	str	x0, [x25, x19, lsl #3]
    85f8:	91000673 	add	x19, x19, #0x1
    85fc:	f9400821 	ldr	x1, [x1, #16]
    8600:	b5ffff81 	cbnz	x1, 85f0 <f12+0xd20>
    8604:	b4000e9c 	cbz	x28, 87d4 <f12+0xf04>
    8608:	f94002a3 	ldr	x3, [x21]
    860c:	b90013ff 	str	wzr, [sp, #16]
    8610:	17ffff0f 	b	824c <f12+0x97c>
    8614:	72003c1f 	tst	w0, #0xffff
    8618:	54ffd260 	b.eq	8064 <f12+0x794>  // b.none
    861c:	d503201f 	nop
    8620:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8624:	eb00031f 	cmp	x24, x0
    8628:	540018e8 	b.hi	8944 <f12+0x1074>  // b.pmore
    862c:	91000700 	add	x0, x24, #0x1
    8630:	52800021 	mov	w1, #0x1                   	// #1
    8634:	d37df000 	lsl	x0, x0, #3
    8638:	97fff2aa 	bl	50e0 <fwp_heap_alloc>
    863c:	911982e2 	add	x2, x23, #0x660
    8640:	f9000018 	str	x24, [x0]
    8644:	aa0003f5 	mov	x21, x0
    8648:	f90007f5 	str	x21, [sp, #8]
    864c:	f949d841 	ldr	x1, [x2, #5040]
    8650:	f949ec40 	ldr	x0, [x2, #5080]
    8654:	cb0102a1 	sub	x1, x21, x1
    8658:	eb00403f 	cmp	x1, x0, lsl #16
    865c:	54000322 	b.cs	86c0 <f12+0xdf0>  // b.hs, b.nlast
    8660:	d350fc20 	lsr	x0, x1, #16
    8664:	f949fc43 	ldr	x3, [x2, #5112]
    8668:	8b000800 	add	x0, x0, x0, lsl #2
    866c:	d37df002 	lsl	x2, x0, #3
    8670:	8b020060 	add	x0, x3, x2
    8674:	f9401019 	ldr	x25, [x0, #32]
    8678:	b4000259 	cbz	x25, 86c0 <f12+0xdf0>
    867c:	38626862 	ldrb	w2, [x3, x2]
    8680:	7100085f 	cmp	w2, #0x2
    8684:	54000ac0 	b.eq	87dc <f12+0xf0c>  // b.none
    8688:	7100045f 	cmp	w2, #0x1
    868c:	540001a1 	b.ne	86c0 <f12+0xdf0>  // b.any
    8690:	29430002 	ldp	w2, w0, [x0, #24]
    8694:	92403c21 	and	x1, x1, #0xffff
    8698:	9b027c21 	mul	x1, x1, x2
    869c:	d360fc21 	lsr	x1, x1, #32
    86a0:	eb00003f 	cmp	x1, x0
    86a4:	540000e2 	b.cs	86c0 <f12+0xdf0>  // b.hs, b.nlast
    86a8:	8b010339 	add	x25, x25, x1
    86ac:	39400320 	ldrb	w0, [x25]
    86b0:	7103fc1f 	cmp	w0, #0xff
    86b4:	54001160 	b.eq	88e0 <f12+0x1010>  // b.none
    86b8:	52800020 	mov	w0, #0x1                   	// #1
    86bc:	39000320 	strb	w0, [x25]
    86c0:	aa1303e0 	mov	x0, x19
    86c4:	17fffe6e 	b	807c <f12+0x7ac>
    86c8:	52800041 	mov	w1, #0x2                   	// #2
    86cc:	d2800100 	mov	x0, #0x8                   	// #8
    86d0:	97fff284 	bl	50e0 <fwp_heap_alloc>
    86d4:	aa0003fb 	mov	x27, x0
    86d8:	911982e0 	add	x0, x23, #0x660
    86dc:	f900037f 	str	xzr, [x27]
    86e0:	f949d801 	ldr	x1, [x0, #5040]
    86e4:	f949ec00 	ldr	x0, [x0, #5080]
    86e8:	cb010361 	sub	x1, x27, x1
    86ec:	eb00403f 	cmp	x1, x0, lsl #16
    86f0:	54000102 	b.cs	8710 <f12+0xe40>  // b.hs, b.nlast
    86f4:	d2800013 	mov	x19, #0x0                   	// #0
    86f8:	17fffd4b 	b	7c24 <f12+0x354>
    86fc:	aa1b03e0 	mov	x0, x27
    8700:	97fff0b8 	bl	49e0 <fwp_rc_forget_slot>
    8704:	17ffff26 	b	839c <f12+0xacc>
    8708:	b5ffac33 	cbnz	x19, 7c8c <f12+0x3bc>
    870c:	d503201f 	nop
    8710:	d280001c 	mov	x28, #0x0                   	// #0
    8714:	17fffd84 	b	7d24 <f12+0x454>
    8718:	d0ffffe0 	adrp	x0, 6000 <fwp_drop1+0x70>
    871c:	91134000 	add	x0, x0, #0x4d0
    8720:	94001490 	bl	d960 <atexit>
    8724:	35ffd220 	cbnz	w0, 8168 <f12+0x898>
    8728:	52800020 	mov	w0, #0x1                   	// #1
    872c:	b903e720 	str	w0, [x25, #996]
    8730:	17fffcb8 	b	7a10 <f12+0x140>
    8734:	72003c3f 	tst	w1, #0xffff
    8738:	54ffaa81 	b.ne	7c88 <f12+0x3b8>  // b.any
    873c:	17fffd4e 	b	7c74 <f12+0x3a4>
    8740:	72003c3f 	tst	w1, #0xffff
    8744:	54ff9360 	b.eq	79b0 <f12+0xe0>  // b.none
    8748:	aa1903e0 	mov	x0, x25
    874c:	97fff6c1 	bl	6250 <fwp_closure_drop>
    8750:	b5ff9494 	cbnz	x20, 79e0 <f12+0x110>
    8754:	d280001a 	mov	x26, #0x0                   	// #0
    8758:	17fffcab 	b	7a04 <f12+0x134>
    875c:	aa1c03f3 	mov	x19, x28
    8760:	17fffdaa 	b	7e08 <f12+0x538>
    8764:	72003c3f 	tst	w1, #0xffff
    8768:	54ffc381 	b.ne	7fd8 <f12+0x708>  // b.any
    876c:	17fffe16 	b	7fc4 <f12+0x6f4>
    8770:	ad480402 	ldp	q2, q1, [x0, #256]
    8774:	91040001 	add	x1, x0, #0x100
    8778:	4f000400 	movi	v0.4s, #0x0
    877c:	f9009c1f 	str	xzr, [x0, #312]
    8780:	ad010762 	stp	q2, q1, [x27, #32]
    8784:	a9520002 	ldp	x2, x0, [x0, #288]
    8788:	f9000f60 	str	x0, [x27, #24]
    878c:	f9401820 	ldr	x0, [x1, #48]
    8790:	f9002362 	str	x2, [x27, #64]
    8794:	f9002760 	str	x0, [x27, #72]
    8798:	ad000020 	stp	q0, q0, [x1]
    879c:	3d800820 	str	q0, [x1, #32]
    87a0:	f900183f 	str	xzr, [x1, #48]
    87a4:	17fffcde 	b	7b1c <f12+0x24c>
    87a8:	f940bc43 	ldr	x3, [x2, #376]
    87ac:	91000463 	add	x3, x3, #0x1
    87b0:	f900bc43 	str	x3, [x2, #376]
    87b4:	17fffc84 	b	79c4 <f12+0xf4>
    87b8:	d2800005 	mov	x5, #0x0                   	// #0
    87bc:	52800020 	mov	w0, #0x1                   	// #1
    87c0:	17fffe62 	b	8148 <f12+0x878>
    87c4:	52800041 	mov	w1, #0x2                   	// #2
    87c8:	d2800100 	mov	x0, #0x8                   	// #8
    87cc:	97fff245 	bl	50e0 <fwp_heap_alloc>
    87d0:	aa0003f9 	mov	x25, x0
    87d4:	d2800013 	mov	x19, #0x0                   	// #0
    87d8:	17ffff54 	b	8528 <f12+0xc58>
    87dc:	72003c3f 	tst	w1, #0xffff
    87e0:	54fff660 	b.eq	86ac <f12+0xddc>  // b.none
    87e4:	aa1303e0 	mov	x0, x19
    87e8:	17fffe25 	b	807c <f12+0x7ac>
    87ec:	d1000761 	sub	x1, x27, #0x1
    87f0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    87f4:	eb00003f 	cmp	x1, x0
    87f8:	54000ac8 	b.hi	8950 <f12+0x1080>  // b.pmore
    87fc:	900002c3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fb80>
    8800:	d2800000 	mov	x0, #0x0                   	// #0
    8804:	91120061 	add	x1, x3, #0x480
    8808:	14000005 	b	881c <f12+0xf4c>
    880c:	91000400 	add	x0, x0, #0x1
    8810:	91006021 	add	x1, x1, #0x18
    8814:	f140041f 	cmp	x0, #0x1, lsl #12
    8818:	540006e0 	b.eq	88f4 <f12+0x1024>  // b.none
    881c:	f9400022 	ldr	x2, [x1]
    8820:	b5ffff62 	cbnz	x2, 880c <f12+0xf3c>
    8824:	8b000402 	add	x2, x0, x0, lsl #1
    8828:	91120063 	add	x3, x3, #0x480
    882c:	aa1b03e0 	mov	x0, x27
    8830:	d2800101 	mov	x1, #0x8                   	// #8
    8834:	8b020c62 	add	x2, x3, x2, lsl #3
    8838:	a9009be2 	stp	x2, x6, [sp, #8]
    883c:	a901a3e7 	stp	x7, x8, [sp, #24]
    8840:	f90017e9 	str	x9, [sp, #40]
    8844:	97ffe7eb 	bl	27f0 <calloc@plt>
    8848:	a9411fe6 	ldp	x6, x7, [sp, #16]
    884c:	aa0003e5 	mov	x5, x0
    8850:	a94227e8 	ldp	x8, x9, [sp, #32]
    8854:	b4fffb20 	cbz	x0, 87b8 <f12+0xee8>
    8858:	aa0003e1 	mov	x1, x0
    885c:	d37df362 	lsl	x2, x27, #3
    8860:	f94007e0 	ldr	x0, [sp, #8]
    8864:	52800063 	mov	w3, #0x3                   	// #3
    8868:	a9009be5 	stp	x5, x6, [sp, #8]
    886c:	a901a3e7 	stp	x7, x8, [sp, #24]
    8870:	f90017e9 	str	x9, [sp, #40]
    8874:	97ffe9a7 	bl	2f10 <ad_raw_record>
    8878:	a9409be5 	ldp	x5, x6, [sp, #8]
    887c:	f9004be5 	str	x5, [sp, #144]
    8880:	a941a3e7 	ldp	x7, x8, [sp, #24]
    8884:	f90053fb 	str	x27, [sp, #160]
    8888:	f94017e9 	ldr	x9, [sp, #40]
    888c:	17fffd77 	b	7e68 <f12+0x598>
    8890:	f94002a3 	ldr	x3, [x21]
    8894:	b7fff983 	tbnz	x3, #63, 87c4 <f12+0xef4>
    8898:	911982e1 	add	x1, x23, #0x660
    889c:	f94007e4 	ldr	x4, [sp, #8]
    88a0:	f949d820 	ldr	x0, [x1, #5040]
    88a4:	f949ec21 	ldr	x1, [x1, #5080]
    88a8:	cb000080 	sub	x0, x4, x0
    88ac:	eb01401f 	cmp	x0, x1, lsl #16
    88b0:	54fff8a2 	b.cs	87c4 <f12+0xef4>  // b.hs, b.nlast
    88b4:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    88b8:	17fffe49 	b	81dc <f12+0x90c>
    88bc:	d2800d01 	mov	x1, #0x68                  	// #104
    88c0:	d2800039 	mov	x25, #0x1                   	// #1
    88c4:	17fffc76 	b	7a9c <f12+0x1cc>
    88c8:	aa1a03e0 	mov	x0, x26
    88cc:	97fff045 	bl	49e0 <fwp_rc_forget_slot>
    88d0:	17fffcec 	b	7c80 <f12+0x3b0>
    88d4:	aa1903e0 	mov	x0, x25
    88d8:	97fff042 	bl	49e0 <fwp_rc_forget_slot>
    88dc:	17fffdbd 	b	7fd0 <f12+0x700>
    88e0:	aa1903e0 	mov	x0, x25
    88e4:	97fff03f 	bl	49e0 <fwp_rc_forget_slot>
    88e8:	17ffff74 	b	86b8 <f12+0xde8>
    88ec:	97ffeff6 	bl	48c4 <fwp_rc_wide_dup>
    88f0:	17fffc39 	b	79d4 <f12+0x104>
    88f4:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    88f8:	9134e000 	add	x0, x0, #0xd38
    88fc:	97ffea81 	bl	3300 <ad_raw_fail>
    8900:	d280001a 	mov	x26, #0x0                   	// #0
    8904:	17fffe95 	b	8358 <f12+0xa88>
    8908:	d2800019 	mov	x25, #0x0                   	// #0
    890c:	d2800013 	mov	x19, #0x0                   	// #0
    8910:	17ffff06 	b	8528 <f12+0xc58>
    8914:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    8918:	913a6000 	add	x0, x0, #0xe98
    891c:	97ffeb99 	bl	3780 <fwp_trap>
    8920:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    8924:	913cc000 	add	x0, x0, #0xf30
    8928:	97ffeb96 	bl	3780 <fwp_trap>
    892c:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x670>
    8930:	91014000 	add	x0, x0, #0x50
    8934:	97ffeb93 	bl	3780 <fwp_trap>
    8938:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    893c:	913e4000 	add	x0, x0, #0xf90
    8940:	97ffeb90 	bl	3780 <fwp_trap>
    8944:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x670>
    8948:	91010000 	add	x0, x0, #0x40
    894c:	97ffeb8d 	bl	3780 <fwp_trap>
    8950:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x670>
    8954:	91008000 	add	x0, x0, #0x20
    8958:	97ffea6a 	bl	3300 <ad_raw_fail>
    895c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    8960:	913fc000 	add	x0, x0, #0xff0
    8964:	97ffeb87 	bl	3780 <fwp_trap>
    8968:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    896c:	913e8000 	add	x0, x0, #0xfa0
    8970:	97ffeb84 	bl	3780 <fwp_trap>
    8974:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    8978:	913b8000 	add	x0, x0, #0xee0
    897c:	97ffeb81 	bl	3780 <fwp_trap>
    8980:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    8984:	913f0000 	add	x0, x0, #0xfc0
    8988:	97ffeb7e 	bl	3780 <fwp_trap>
    898c:	97ffe7a1 	bl	2810 <__stack_chk_fail@plt>
    8990:	97ffe7b4 	bl	2860 <abort@plt>
    8994:	97ffe81b 	bl	2a00 <fwp_trap_overflow.constprop.0>
    8998:	d503201f 	nop
    899c:	d503201f 	nop

00000000000089a0 <fwp_owned_entry12>:
    89a0:	f9400000 	ldr	x0, [x0]
    89a4:	17fffbcb 	b	78d0 <f12>
    89a8:	d503201f 	nop
    89ac:	d503201f 	nop

00000000000089b0 <e12>:
    89b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    89b4:	910003fd 	mov	x29, sp
    89b8:	f9000bf3 	str	x19, [sp, #16]
    89bc:	f9400013 	ldr	x19, [x0]
    89c0:	aa1303e0 	mov	x0, x19
    89c4:	97fff440 	bl	5ac4 <fwp_rc_share>
    89c8:	aa1303e0 	mov	x0, x19
    89cc:	97fffbc1 	bl	78d0 <f12>
    89d0:	aa0003f3 	mov	x19, x0
    89d4:	97fff43c 	bl	5ac4 <fwp_rc_share>
    89d8:	aa1303e0 	mov	x0, x19
    89dc:	f9400bf3 	ldr	x19, [sp, #16]
    89e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    89e4:	d65f03c0 	ret
    89e8:	d503201f 	nop
    89ec:	d503201f 	nop

00000000000089f0 <fwp_write>:
    89f0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    89f4:	910003fd 	mov	x29, sp
    89f8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    89fc:	f947f484 	ldr	x4, [x4, #4072]
    8a00:	a90153f3 	stp	x19, x20, [sp, #16]
    8a04:	d10943ff 	sub	sp, sp, #0x250
    8a08:	b9400045 	ldr	w5, [x2]
    8a0c:	aa0003f4 	mov	x20, x0
    8a10:	f9400080 	ldr	x0, [x4]
    8a14:	f90127e0 	str	x0, [sp, #584]
    8a18:	d2800000 	mov	x0, #0x0                   	// #0
    8a1c:	710064bf 	cmp	w5, #0x19
    8a20:	54000408 	b.hi	8aa0 <fwp_write+0xb0>  // b.pmore
    8a24:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x670>
    8a28:	aa0103f3 	mov	x19, x1
    8a2c:	91230000 	add	x0, x0, #0x8c0
    8a30:	f9013bf5 	str	x21, [sp, #624]
    8a34:	f9013ff6 	str	x22, [sp, #632]
    8a38:	f90153fb 	str	x27, [sp, #672]
    8a3c:	f90157fc 	str	x28, [sp, #680]
    8a40:	aa0203fc 	mov	x28, x2
    8a44:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8a48:	10000061 	adr	x1, 8a54 <fwp_write+0x64>
    8a4c:	8b20a820 	add	x0, x1, w0, sxth #2
    8a50:	d61f0000 	br	x0
    8a54:	910123e0 	add	x0, sp, #0x48
    8a58:	aa1303e5 	mov	x5, x19
    8a5c:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x670>
    8a60:	aa0003f3 	mov	x19, x0
    8a64:	9102c084 	add	x4, x4, #0xb0
    8a68:	d2804003 	mov	x3, #0x200                 	// #512
    8a6c:	aa0303e1 	mov	x1, x3
    8a70:	52800042 	mov	w2, #0x2                   	// #2
    8a74:	97ffe743 	bl	2780 <__snprintf_chk@plt>
    8a78:	aa1303e0 	mov	x0, x19
    8a7c:	97ffe709 	bl	26a0 <strlen@plt>
    8a80:	aa1303e1 	mov	x1, x19
    8a84:	aa0003e2 	mov	x2, x0
    8a88:	aa1403e0 	mov	x0, x20
    8a8c:	97ffeae1 	bl	3610 <buf_put>
    8a90:	f9413bf5 	ldr	x21, [sp, #624]
    8a94:	f9413ff6 	ldr	x22, [sp, #632]
    8a98:	f94153fb 	ldr	x27, [sp, #672]
    8a9c:	f94157fc 	ldr	x28, [sp, #680]
    8aa0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8aa4:	f947f400 	ldr	x0, [x0, #4072]
    8aa8:	f94127e2 	ldr	x2, [sp, #584]
    8aac:	f9400001 	ldr	x1, [x0]
    8ab0:	eb010042 	subs	x2, x2, x1
    8ab4:	d2800001 	mov	x1, #0x0                   	// #0
    8ab8:	540077c1 	b.ne	99b0 <fwp_write+0xfc0>  // b.any
    8abc:	910943ff 	add	sp, sp, #0x250
    8ac0:	a94153f3 	ldp	x19, x20, [sp, #16]
    8ac4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8ac8:	d65f03c0 	ret
    8acc:	910123e0 	add	x0, sp, #0x48
    8ad0:	aa1303e5 	mov	x5, x19
    8ad4:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x670>
    8ad8:	aa0003f3 	mov	x19, x0
    8adc:	9102a084 	add	x4, x4, #0xa8
    8ae0:	d2804003 	mov	x3, #0x200                 	// #512
    8ae4:	17ffffe2 	b	8a6c <fwp_write+0x7c>
    8ae8:	71004cbf 	cmp	w5, #0x13
    8aec:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x670>
    8af0:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    8af4:	91026000 	add	x0, x0, #0x98
    8af8:	91028021 	add	x1, x1, #0xa0
    8afc:	d2800082 	mov	x2, #0x4                   	// #4
    8b00:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8b04:	aa1403e0 	mov	x0, x20
    8b08:	f90143f7 	str	x23, [sp, #640]
    8b0c:	d2800016 	mov	x22, #0x0                   	// #0
    8b10:	f90147f8 	str	x24, [sp, #648]
    8b14:	97ffeabf 	bl	3610 <buf_put>
    8b18:	f9400260 	ldr	x0, [x19]
    8b1c:	d0000037 	adrp	x23, e000 <_IO_stdin_used+0x670>
    8b20:	d2800015 	mov	x21, #0x0                   	// #0
    8b24:	910482f7 	add	x23, x23, #0x120
    8b28:	b40047a0 	cbz	x0, 941c <fwp_write+0xa2c>
    8b2c:	b9400380 	ldr	w0, [x28]
    8b30:	52800003 	mov	w3, #0x0                   	// #0
    8b34:	f9401f82 	ldr	x2, [x28, #56]
    8b38:	71004c1f 	cmp	w0, #0x13
    8b3c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8b40:	aa1403e0 	mov	x0, x20
    8b44:	8b010e61 	add	x1, x19, x1, lsl #3
    8b48:	f9400421 	ldr	x1, [x1, #8]
    8b4c:	97ffffa9 	bl	89f0 <fwp_write>
    8b50:	b9400380 	ldr	w0, [x28]
    8b54:	7100481f 	cmp	w0, #0x12
    8b58:	54004b40 	b.eq	94c0 <fwp_write+0xad0>  // b.none
    8b5c:	f9400260 	ldr	x0, [x19]
    8b60:	910006b5 	add	x21, x21, #0x1
    8b64:	91000ad6 	add	x22, x22, #0x2
    8b68:	eb15001f 	cmp	x0, x21
    8b6c:	54004589 	b.ls	941c <fwp_write+0xa2c>  // b.plast
    8b70:	aa1703e1 	mov	x1, x23
    8b74:	aa1403e0 	mov	x0, x20
    8b78:	d2800042 	mov	x2, #0x2                   	// #2
    8b7c:	97ffeaa5 	bl	3610 <buf_put>
    8b80:	17ffffeb 	b	8b2c <fwp_write+0x13c>
    8b84:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    8b88:	91036021 	add	x1, x1, #0xd8
    8b8c:	d28000c2 	mov	x2, #0x6                   	// #6
    8b90:	aa1403e0 	mov	x0, x20
    8b94:	91004273 	add	x19, x19, #0x10
    8b98:	97ffea9e 	bl	3610 <buf_put>
    8b9c:	aa1303e0 	mov	x0, x19
    8ba0:	97ffe6c0 	bl	26a0 <strlen@plt>
    8ba4:	aa1303e1 	mov	x1, x19
    8ba8:	aa0003e2 	mov	x2, x0
    8bac:	aa1403e0 	mov	x0, x20
    8bb0:	97ffea98 	bl	3610 <buf_put>
    8bb4:	528007c3 	mov	w3, #0x3e                  	// #62
    8bb8:	aa1403e0 	mov	x0, x20
    8bbc:	91001fe1 	add	x1, sp, #0x7
    8bc0:	d2800022 	mov	x2, #0x1                   	// #1
    8bc4:	39001fe3 	strb	w3, [sp, #7]
    8bc8:	17ffffb1 	b	8a8c <fwp_write+0x9c>
    8bcc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8bd0:	f947f400 	ldr	x0, [x0, #4072]
    8bd4:	f94127e2 	ldr	x2, [sp, #584]
    8bd8:	f9400001 	ldr	x1, [x0]
    8bdc:	eb010042 	subs	x2, x2, x1
    8be0:	d2800001 	mov	x1, #0x0                   	// #0
    8be4:	540034e1 	b.ne	9280 <fwp_write+0x890>  // b.any
    8be8:	f9413bf5 	ldr	x21, [sp, #624]
    8bec:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    8bf0:	f9413ff6 	ldr	x22, [sp, #632]
    8bf4:	aa1403e0 	mov	x0, x20
    8bf8:	9102e021 	add	x1, x1, #0xb8
    8bfc:	d2800142 	mov	x2, #0xa                   	// #10
    8c00:	f94153fb 	ldr	x27, [sp, #672]
    8c04:	f94157fc 	ldr	x28, [sp, #680]
    8c08:	910943ff 	add	sp, sp, #0x250
    8c0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8c10:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8c14:	17ffea7f 	b	3610 <buf_put>
    8c18:	f9400456 	ldr	x22, [x2, #8]
    8c1c:	f90143f7 	str	x23, [sp, #640]
    8c20:	f90147f8 	str	x24, [sp, #648]
    8c24:	b4005b16 	cbz	x22, 9784 <fwp_write+0xd94>
    8c28:	aa1603e0 	mov	x0, x22
    8c2c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    8c30:	9104e021 	add	x1, x1, #0x138
    8c34:	97ffe717 	bl	2890 <strcmp@plt>
    8c38:	2a0003f5 	mov	w21, w0
    8c3c:	34005fe0 	cbz	w0, 9838 <fwp_write+0xe48>
    8c40:	aa1603e0 	mov	x0, x22
    8c44:	97ffe697 	bl	26a0 <strlen@plt>
    8c48:	aa1603e1 	mov	x1, x22
    8c4c:	aa0003e2 	mov	x2, x0
    8c50:	aa1403e0 	mov	x0, x20
    8c54:	97ffea6f 	bl	3610 <buf_put>
    8c58:	52800403 	mov	w3, #0x20                  	// #32
    8c5c:	91001ff5 	add	x21, sp, #0x7
    8c60:	aa1503e1 	mov	x1, x21
    8c64:	aa1403e0 	mov	x0, x20
    8c68:	d2800022 	mov	x2, #0x1                   	// #1
    8c6c:	39001fe3 	strb	w3, [sp, #7]
    8c70:	97ffea68 	bl	3610 <buf_put>
    8c74:	52800f63 	mov	w3, #0x7b                  	// #123
    8c78:	aa1403e0 	mov	x0, x20
    8c7c:	aa1503e1 	mov	x1, x21
    8c80:	d2800022 	mov	x2, #0x1                   	// #1
    8c84:	39001fe3 	strb	w3, [sp, #7]
    8c88:	97ffea62 	bl	3610 <buf_put>
    8c8c:	b9401380 	ldr	w0, [x28, #16]
    8c90:	52800018 	mov	w24, #0x0                   	// #0
    8c94:	7100001f 	cmp	w0, #0x0
    8c98:	54003aad 	b.le	93ec <fwp_write+0x9fc>
    8c9c:	f9014bf9 	str	x25, [sp, #656]
    8ca0:	d0000039 	adrp	x25, e000 <_IO_stdin_used+0x670>
    8ca4:	91058339 	add	x25, x25, #0x160
    8ca8:	f9014ffa 	str	x26, [sp, #664]
    8cac:	d000003a 	adrp	x26, e000 <_IO_stdin_used+0x670>
    8cb0:	9104835a 	add	x26, x26, #0x120
    8cb4:	91002276 	add	x22, x19, #0x8
    8cb8:	d2800013 	mov	x19, #0x0                   	// #0
    8cbc:	b5003e93 	cbnz	x19, 948c <fwp_write+0xa9c>
    8cc0:	d37df277 	lsl	x23, x19, #3
    8cc4:	34003cb8 	cbz	w24, 9458 <fwp_write+0xa68>
    8cc8:	f9401382 	ldr	x2, [x28, #32]
    8ccc:	aa1403e0 	mov	x0, x20
    8cd0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8cd4:	52800003 	mov	w3, #0x0                   	// #0
    8cd8:	f8776842 	ldr	x2, [x2, x23]
    8cdc:	91000673 	add	x19, x19, #0x1
    8ce0:	97ffff44 	bl	89f0 <fwp_write>
    8ce4:	b9401380 	ldr	w0, [x28, #16]
    8ce8:	6b13001f 	cmp	w0, w19
    8cec:	54fffe8c 	b.gt	8cbc <fwp_write+0x2cc>
    8cf0:	f9414bf9 	ldr	x25, [sp, #656]
    8cf4:	f9414ffa 	ldr	x26, [sp, #664]
    8cf8:	340037b8 	cbz	w24, 93ec <fwp_write+0x9fc>
    8cfc:	52800523 	mov	w3, #0x29                  	// #41
    8d00:	aa1503e1 	mov	x1, x21
    8d04:	aa1403e0 	mov	x0, x20
    8d08:	d2800022 	mov	x2, #0x1                   	// #1
    8d0c:	39001fe3 	strb	w3, [sp, #7]
    8d10:	97ffea40 	bl	3610 <buf_put>
    8d14:	f9413bf5 	ldr	x21, [sp, #624]
    8d18:	f9413ff6 	ldr	x22, [sp, #632]
    8d1c:	f94143f7 	ldr	x23, [sp, #640]
    8d20:	f94147f8 	ldr	x24, [sp, #648]
    8d24:	f94153fb 	ldr	x27, [sp, #672]
    8d28:	f94157fc 	ldr	x28, [sp, #680]
    8d2c:	17ffff5d 	b	8aa0 <fwp_write+0xb0>
    8d30:	b9404855 	ldr	w21, [x2, #72]
    8d34:	aa1403e0 	mov	x0, x20
    8d38:	93407eb6 	sxtw	x22, w21
    8d3c:	91000ac1 	add	x1, x22, #0x2
    8d40:	97ffea00 	bl	3540 <buf_grow>
    8d44:	a9400281 	ldp	x1, x0, [x20]
    8d48:	528e8603 	mov	w3, #0x7430                	// #29744
    8d4c:	78206823 	strh	w3, [x1, x0]
    8d50:	8b000022 	add	x2, x1, x0
    8d54:	710002bf 	cmp	w21, #0x0
    8d58:	540036cd 	b.le	9430 <fwp_write+0xa40>
    8d5c:	110006a3 	add	w3, w21, #0x1
    8d60:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8d64:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8d68:	91000449 	add	x9, x2, #0x1
    8d6c:	8b23c043 	add	x3, x2, w3, sxtw
    8d70:	f28aaac6 	movk	x6, #0x5556
    8d74:	f2955568 	movk	x8, #0xaaab
    8d78:	1400000d 	b	8dac <fwp_write+0x3bc>
    8d7c:	d2800021 	mov	x1, #0x1                   	// #1
    8d80:	528005a5 	mov	w5, #0x2d                  	// #45
    8d84:	f100001f 	cmp	x0, #0x0
    8d88:	9b467e60 	smulh	x0, x19, x6
    8d8c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8d90:	381ff465 	strb	w5, [x3], #-1
    8d94:	cb040000 	sub	x0, x0, x4
    8d98:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8d9c:	cb020000 	sub	x0, x0, x2
    8da0:	8b010013 	add	x19, x0, x1
    8da4:	eb03013f 	cmp	x9, x3
    8da8:	54003440 	b.eq	9430 <fwp_write+0xa40>  // b.none
    8dac:	9b467e60 	smulh	x0, x19, x6
    8db0:	937ffe64 	asr	x4, x19, #63
    8db4:	52800605 	mov	w5, #0x30                  	// #48
    8db8:	cb040000 	sub	x0, x0, x4
    8dbc:	8b000400 	add	x0, x0, x0, lsl #1
    8dc0:	cb000260 	sub	x0, x19, x0
    8dc4:	91000c01 	add	x1, x0, #0x3
    8dc8:	9bc87c22 	umulh	x2, x1, x8
    8dcc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8dd0:	8b4204e2 	add	x2, x7, x2, lsr #1
    8dd4:	eb020021 	subs	x1, x1, x2
    8dd8:	54fffd60 	b.eq	8d84 <fwp_write+0x394>  // b.none
    8ddc:	f100043f 	cmp	x1, #0x1
    8de0:	54fffce1 	b.ne	8d7c <fwp_write+0x38c>  // b.any
    8de4:	d2800001 	mov	x1, #0x0                   	// #0
    8de8:	52800565 	mov	w5, #0x2b                  	// #43
    8dec:	17ffffe6 	b	8d84 <fwp_write+0x394>
    8df0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8df4:	f947f400 	ldr	x0, [x0, #4072]
    8df8:	f94127e2 	ldr	x2, [sp, #584]
    8dfc:	f9400001 	ldr	x1, [x0]
    8e00:	eb010042 	subs	x2, x2, x1
    8e04:	d2800001 	mov	x1, #0x0                   	// #0
    8e08:	540023c1 	b.ne	9280 <fwp_write+0x890>  // b.any
    8e0c:	f9413bf5 	ldr	x21, [sp, #624]
    8e10:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    8e14:	f9413ff6 	ldr	x22, [sp, #632]
    8e18:	aa1403e0 	mov	x0, x20
    8e1c:	91032021 	add	x1, x1, #0xc8
    8e20:	d2800102 	mov	x2, #0x8                   	// #8
    8e24:	17ffff77 	b	8c00 <fwp_write+0x210>
    8e28:	aa1403e0 	mov	x0, x20
    8e2c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    8e30:	d28000c2 	mov	x2, #0x6                   	// #6
    8e34:	9104a021 	add	x1, x1, #0x128
    8e38:	97ffe9f6 	bl	3610 <buf_put>
    8e3c:	d2800015 	mov	x21, #0x0                   	// #0
    8e40:	f9400263 	ldr	x3, [x19]
    8e44:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8e48:	54002c60 	b.eq	93d4 <fwp_write+0x9e4>  // b.none
    8e4c:	f9401f82 	ldr	x2, [x28, #56]
    8e50:	f90143f7 	str	x23, [sp, #640]
    8e54:	f90147f8 	str	x24, [sp, #648]
    8e58:	d2800857 	mov	x23, #0x42                  	// #66
    8e5c:	f9014bf9 	str	x25, [sp, #656]
    8e60:	d0000036 	adrp	x22, e000 <_IO_stdin_used+0x670>
    8e64:	f9014ffa 	str	x26, [sp, #664]
    8e68:	910482d6 	add	x22, x22, #0x120
    8e6c:	d2800038 	mov	x24, #0x1                   	// #1
    8e70:	f2a18017 	movk	x23, #0xc00, lsl #16
    8e74:	d2809099 	mov	x25, #0x484                 	// #1156
    8e78:	b40004a2 	cbz	x2, 8f0c <fwp_write+0x51c>
    8e7c:	b9400040 	ldr	w0, [x2]
    8e80:	7100701f 	cmp	w0, #0x1c
    8e84:	540042c0 	b.eq	96dc <fwp_write+0xcec>  // b.none
    8e88:	71006c1f 	cmp	w0, #0x1b
    8e8c:	54000408 	b.hi	8f0c <fwp_write+0x51c>  // b.pmore
    8e90:	9ac02301 	lsl	x1, x24, x0
    8e94:	ea17003f 	tst	x1, x23
    8e98:	540036a1 	b.ne	956c <fwp_write+0xb7c>  // b.any
    8e9c:	ea19003f 	tst	x1, x25
    8ea0:	54003521 	b.ne	9544 <fwp_write+0xb54>  // b.any
    8ea4:	d2800424 	mov	x4, #0x21                  	// #33
    8ea8:	ea04003f 	tst	x1, x4
    8eac:	54000300 	b.eq	8f0c <fwp_write+0x51c>  // b.none
    8eb0:	b7f849c3 	tbnz	x3, #63, 97e8 <fwp_write+0xdf8>
    8eb4:	91002261 	add	x1, x19, #0x8
    8eb8:	8b150021 	add	x1, x1, x21
    8ebc:	39400021 	ldrb	w1, [x1]
    8ec0:	7100001f 	cmp	w0, #0x0
    8ec4:	93401c23 	sxtb	x3, w1
    8ec8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8ecc:	d503201f 	nop
    8ed0:	aa1403e0 	mov	x0, x20
    8ed4:	52800003 	mov	w3, #0x0                   	// #0
    8ed8:	97fffec6 	bl	89f0 <fwp_write>
    8edc:	910006b5 	add	x21, x21, #0x1
    8ee0:	f9400260 	ldr	x0, [x19]
    8ee4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8ee8:	eb0002bf 	cmp	x21, x0
    8eec:	540026c2 	b.cs	93c4 <fwp_write+0x9d4>  // b.hs, b.nlast
    8ef0:	d2800042 	mov	x2, #0x2                   	// #2
    8ef4:	aa1603e1 	mov	x1, x22
    8ef8:	aa1403e0 	mov	x0, x20
    8efc:	97ffe9c5 	bl	3610 <buf_put>
    8f00:	f9401f82 	ldr	x2, [x28, #56]
    8f04:	f9400263 	ldr	x3, [x19]
    8f08:	b5fffba2 	cbnz	x2, 8e7c <fwp_write+0x48c>
    8f0c:	d37df2a0 	lsl	x0, x21, #3
    8f10:	b7f83f03 	tbnz	x3, #63, 96f0 <fwp_write+0xd00>
    8f14:	91002261 	add	x1, x19, #0x8
    8f18:	8b000020 	add	x0, x1, x0
    8f1c:	f9400001 	ldr	x1, [x0]
    8f20:	17ffffec 	b	8ed0 <fwp_write+0x4e0>
    8f24:	a9400e62 	ldp	x2, x3, [x19]
    8f28:	b7f83ca3 	tbnz	x3, #63, 96bc <fwp_write+0xccc>
    8f2c:	910123f5 	add	x21, sp, #0x48
    8f30:	aa1503e0 	mov	x0, x21
    8f34:	97ffe79b 	bl	2da0 <fwp_fmt_u128>
    8f38:	aa1503e0 	mov	x0, x21
    8f3c:	97ffe5d9 	bl	26a0 <strlen@plt>
    8f40:	aa1503e1 	mov	x1, x21
    8f44:	aa0003e2 	mov	x2, x0
    8f48:	17fffed0 	b	8a88 <fwp_write+0x98>
    8f4c:	fd015be8 	str	d8, [sp, #688]
    8f50:	1e270268 	fmov	s8, w19
    8f54:	fd015fe9 	str	d9, [sp, #696]
    8f58:	1e282100 	fcmp	s8, s8
    8f5c:	54004d26 	b.vs	9900 <fwp_write+0xf10>
    8f60:	1e20c101 	fabs	s1, s8
    8f64:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8f68:	1e270000 	fmov	s0, w0
    8f6c:	1e202020 	fcmp	s1, s0
    8f70:	54002c0d 	b.le	94f0 <fwp_write+0xb00>
    8f74:	1e202118 	fcmpe	s8, #0.0
    8f78:	b0000022 	adrp	x2, d000 <fwp_main_thread+0x34c>
    8f7c:	912c2042 	add	x2, x2, #0xb08
    8f80:	910123f5 	add	x21, sp, #0x48
    8f84:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    8f88:	9101e021 	add	x1, x1, #0x78
    8f8c:	aa1503e0 	mov	x0, x21
    8f90:	9a81c041 	csel	x1, x2, x1, gt
    8f94:	97ffe66f 	bl	2950 <strcpy@plt>
    8f98:	aa1503e0 	mov	x0, x21
    8f9c:	97ffe5c1 	bl	26a0 <strlen@plt>
    8fa0:	aa1503e1 	mov	x1, x21
    8fa4:	aa0003e2 	mov	x2, x0
    8fa8:	aa1403e0 	mov	x0, x20
    8fac:	97ffe999 	bl	3610 <buf_put>
    8fb0:	f9413bf5 	ldr	x21, [sp, #624]
    8fb4:	f9413ff6 	ldr	x22, [sp, #632]
    8fb8:	f94153fb 	ldr	x27, [sp, #672]
    8fbc:	f94157fc 	ldr	x28, [sp, #680]
    8fc0:	fd415be8 	ldr	d8, [sp, #688]
    8fc4:	fd415fe9 	ldr	d9, [sp, #696]
    8fc8:	17fffeb6 	b	8aa0 <fwp_write+0xb0>
    8fcc:	f9400276 	ldr	x22, [x19]
    8fd0:	34002e03 	cbz	w3, 9590 <fwp_write+0xba0>
    8fd4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8fd8:	f947f400 	ldr	x0, [x0, #4072]
    8fdc:	f94127e2 	ldr	x2, [sp, #584]
    8fe0:	f9400001 	ldr	x1, [x0]
    8fe4:	eb010042 	subs	x2, x2, x1
    8fe8:	d2800001 	mov	x1, #0x0                   	// #0
    8fec:	540014a1 	b.ne	9280 <fwp_write+0x890>  // b.any
    8ff0:	aa1603e2 	mov	x2, x22
    8ff4:	91002261 	add	x1, x19, #0x8
    8ff8:	f9413bf5 	ldr	x21, [sp, #624]
    8ffc:	aa1403e0 	mov	x0, x20
    9000:	f9413ff6 	ldr	x22, [sp, #632]
    9004:	17fffeff 	b	8c00 <fwp_write+0x210>
    9008:	fd015be8 	str	d8, [sp, #688]
    900c:	9e670268 	fmov	d8, x19
    9010:	fd015fe9 	str	d9, [sp, #696]
    9014:	1e682100 	fcmp	d8, d8
    9018:	54004746 	b.vs	9900 <fwp_write+0xf10>
    901c:	1e60c101 	fabs	d1, d8
    9020:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    9024:	9e670000 	fmov	d0, x0
    9028:	910123f5 	add	x21, sp, #0x48
    902c:	52800033 	mov	w19, #0x1                   	// #1
    9030:	1e602020 	fcmp	d1, d0
    9034:	540001ad 	b.le	9068 <fwp_write+0x678>
    9038:	1e602118 	fcmpe	d8, #0.0
    903c:	90000022 	adrp	x2, d000 <fwp_main_thread+0x34c>
    9040:	912c2042 	add	x2, x2, #0xb08
    9044:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    9048:	9101e021 	add	x1, x1, #0x78
    904c:	aa1503e0 	mov	x0, x21
    9050:	9a81c041 	csel	x1, x2, x1, gt
    9054:	97ffe63f 	bl	2950 <strcpy@plt>
    9058:	17ffffd0 	b	8f98 <fwp_write+0x5a8>
    905c:	11000673 	add	w19, w19, #0x1
    9060:	71004a7f 	cmp	w19, #0x12
    9064:	54003860 	b.eq	9770 <fwp_write+0xd80>  // b.none
    9068:	1e604100 	fmov	d0, d8
    906c:	2a1303e1 	mov	w1, w19
    9070:	aa1503e0 	mov	x0, x21
    9074:	97ffeaa8 	bl	3b14 <fwp_format_g.constprop.0>
    9078:	aa1503e0 	mov	x0, x21
    907c:	d2800001 	mov	x1, #0x0                   	// #0
    9080:	97ffe59c 	bl	26f0 <strtod@plt>
    9084:	1e602100 	fcmp	d8, d0
    9088:	54fffea1 	b.ne	905c <fwp_write+0x66c>  // b.any
    908c:	aa1503e0 	mov	x0, x21
    9090:	97ffe999 	bl	36f4 <fwp_finish_float>
    9094:	17ffffc1 	b	8f98 <fwp_write+0x5a8>
    9098:	a9400e62 	ldp	x2, x3, [x19]
    909c:	910123f3 	add	x19, sp, #0x48
    90a0:	aa1303e0 	mov	x0, x19
    90a4:	97ffe73f 	bl	2da0 <fwp_fmt_u128>
    90a8:	17fffe74 	b	8a78 <fwp_write+0x88>
    90ac:	f90143f7 	str	x23, [sp, #640]
    90b0:	f90147f8 	str	x24, [sp, #648]
    90b4:	2a1303f8 	mov	w24, w19
    90b8:	f9014bf9 	str	x25, [sp, #656]
    90bc:	f9014ffa 	str	x26, [sp, #664]
    90c0:	f13ffe7f 	cmp	x19, #0xfff
    90c4:	54000049 	b.ls	90cc <fwp_write+0x6dc>  // b.plast
    90c8:	b9400278 	ldr	w24, [x19]
    90cc:	f9400f80 	ldr	x0, [x28, #24]
    90d0:	2a1803f5 	mov	w21, w24
    90d4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    90d8:	d37ef6b9 	lsl	x25, x21, #2
    90dc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    90e0:	aa1603e0 	mov	x0, x22
    90e4:	97ffe56f 	bl	26a0 <strlen@plt>
    90e8:	aa1603e1 	mov	x1, x22
    90ec:	aa0003e2 	mov	x2, x0
    90f0:	aa1403e0 	mov	x0, x20
    90f4:	97ffe947 	bl	3610 <buf_put>
    90f8:	f9401780 	ldr	x0, [x28, #40]
    90fc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9100:	7100001f 	cmp	w0, #0x0
    9104:	5400068d 	b.le	91d4 <fwp_write+0x7e4>
    9108:	91002276 	add	x22, x19, #0x8
    910c:	91001ff5 	add	x21, sp, #0x7
    9110:	d280001b 	mov	x27, #0x0                   	// #0
    9114:	5280041a 	mov	w26, #0x20                  	// #32
    9118:	f9401b80 	ldr	x0, [x28, #48]
    911c:	aa1503e1 	mov	x1, x21
    9120:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    9124:	d2800022 	mov	x2, #0x1                   	// #1
    9128:	f8786803 	ldr	x3, [x0, x24]
    912c:	aa1403e0 	mov	x0, x20
    9130:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9134:	39001ffa 	strb	w26, [sp, #7]
    9138:	97ffe936 	bl	3610 <buf_put>
    913c:	f13ffeff 	cmp	x23, #0xfff
    9140:	b9400261 	ldr	w1, [x19]
    9144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9148:	7100383f 	cmp	w1, #0xe
    914c:	54000160 	b.eq	9178 <fwp_write+0x788>  // b.none
    9150:	7100403f 	cmp	w1, #0x10
    9154:	54001a60 	b.eq	94a0 <fwp_write+0xab0>  // b.none
    9158:	7100283f 	cmp	w1, #0xa
    915c:	54002aa0 	b.eq	96b0 <fwp_write+0xcc0>  // b.none
    9160:	540014ac 	b.gt	93f4 <fwp_write+0xa04>
    9164:	71000c3f 	cmp	w1, #0x3
    9168:	540029ac 	b.gt	969c <fwp_write+0xcac>
    916c:	d37ffee0 	lsr	x0, x23, #63
    9170:	37f814a1 	tbnz	w1, #31, 9404 <fwp_write+0xa14>
    9174:	d503201f 	nop
    9178:	34001460 	cbz	w0, 9404 <fwp_write+0xa14>
    917c:	52800503 	mov	w3, #0x28                  	// #40
    9180:	aa1503e1 	mov	x1, x21
    9184:	aa1403e0 	mov	x0, x20
    9188:	d2800022 	mov	x2, #0x1                   	// #1
    918c:	39001fe3 	strb	w3, [sp, #7]
    9190:	97ffe920 	bl	3610 <buf_put>
    9194:	aa1303e2 	mov	x2, x19
    9198:	aa1703e1 	mov	x1, x23
    919c:	aa1403e0 	mov	x0, x20
    91a0:	52800003 	mov	w3, #0x0                   	// #0
    91a4:	97fffe13 	bl	89f0 <fwp_write>
    91a8:	52800523 	mov	w3, #0x29                  	// #41
    91ac:	aa1503e1 	mov	x1, x21
    91b0:	aa1403e0 	mov	x0, x20
    91b4:	d2800022 	mov	x2, #0x1                   	// #1
    91b8:	39001fe3 	strb	w3, [sp, #7]
    91bc:	97ffe915 	bl	3610 <buf_put>
    91c0:	f9401780 	ldr	x0, [x28, #40]
    91c4:	9100077b 	add	x27, x27, #0x1
    91c8:	b8796800 	ldr	w0, [x0, x25]
    91cc:	6b1b001f 	cmp	w0, w27
    91d0:	54fffa4c 	b.gt	9118 <fwp_write+0x728>
    91d4:	f9413bf5 	ldr	x21, [sp, #624]
    91d8:	f9413ff6 	ldr	x22, [sp, #632]
    91dc:	f94143f7 	ldr	x23, [sp, #640]
    91e0:	f94147f8 	ldr	x24, [sp, #648]
    91e4:	f9414bf9 	ldr	x25, [sp, #656]
    91e8:	f9414ffa 	ldr	x26, [sp, #664]
    91ec:	f94153fb 	ldr	x27, [sp, #672]
    91f0:	f94157fc 	ldr	x28, [sp, #680]
    91f4:	17fffe2b 	b	8aa0 <fwp_write+0xb0>
    91f8:	52800783 	mov	w3, #0x3c                  	// #60
    91fc:	91001ff3 	add	x19, sp, #0x7
    9200:	aa1303e1 	mov	x1, x19
    9204:	d2800022 	mov	x2, #0x1                   	// #1
    9208:	aa1403e0 	mov	x0, x20
    920c:	39001fe3 	strb	w3, [sp, #7]
    9210:	97ffe900 	bl	3610 <buf_put>
    9214:	f9400795 	ldr	x21, [x28, #8]
    9218:	aa1503e0 	mov	x0, x21
    921c:	97ffe521 	bl	26a0 <strlen@plt>
    9220:	aa1503e1 	mov	x1, x21
    9224:	aa0003e2 	mov	x2, x0
    9228:	aa1403e0 	mov	x0, x20
    922c:	97ffe8f9 	bl	3610 <buf_put>
    9230:	528007c3 	mov	w3, #0x3e                  	// #62
    9234:	aa1303e1 	mov	x1, x19
    9238:	aa1403e0 	mov	x0, x20
    923c:	d2800022 	mov	x2, #0x1                   	// #1
    9240:	39001fe3 	strb	w3, [sp, #7]
    9244:	17fffe12 	b	8a8c <fwp_write+0x9c>
    9248:	f100067f 	cmp	x19, #0x1
    924c:	540025a0 	b.eq	9700 <fwp_write+0xd10>  // b.none
    9250:	b100067f 	cmn	x19, #0x1
    9254:	54002bc0 	b.eq	97cc <fwp_write+0xddc>  // b.none
    9258:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    925c:	91020021 	add	x1, x1, #0x80
    9260:	d2800022 	mov	x2, #0x1                   	// #1
    9264:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9268:	f947f400 	ldr	x0, [x0, #4072]
    926c:	f94127e4 	ldr	x4, [sp, #584]
    9270:	f9400003 	ldr	x3, [x0]
    9274:	eb030084 	subs	x4, x4, x3
    9278:	d2800003 	mov	x3, #0x0                   	// #0
    927c:	54ffebe0 	b.eq	8ff8 <fwp_write+0x608>  // b.none
    9280:	f90143f7 	str	x23, [sp, #640]
    9284:	f90147f8 	str	x24, [sp, #648]
    9288:	f9014bf9 	str	x25, [sp, #656]
    928c:	f9014ffa 	str	x26, [sp, #664]
    9290:	fd015be8 	str	d8, [sp, #688]
    9294:	fd015fe9 	str	d9, [sp, #696]
    9298:	97ffe55e 	bl	2810 <__stack_chk_fail@plt>
    929c:	52800b63 	mov	w3, #0x5b                  	// #91
    92a0:	91001ff5 	add	x21, sp, #0x7
    92a4:	aa1503e1 	mov	x1, x21
    92a8:	aa1403e0 	mov	x0, x20
    92ac:	d2800022 	mov	x2, #0x1                   	// #1
    92b0:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x670>
    92b4:	910482d6 	add	x22, x22, #0x120
    92b8:	39001fe3 	strb	w3, [sp, #7]
    92bc:	97ffe8d5 	bl	3610 <buf_put>
    92c0:	b4000273 	cbz	x19, 930c <fwp_write+0x91c>
    92c4:	f9400661 	ldr	x1, [x19, #8]
    92c8:	aa1403e0 	mov	x0, x20
    92cc:	f9401f82 	ldr	x2, [x28, #56]
    92d0:	52800003 	mov	w3, #0x0                   	// #0
    92d4:	97fffdc7 	bl	89f0 <fwp_write>
    92d8:	f9400a73 	ldr	x19, [x19, #16]
    92dc:	b4000193 	cbz	x19, 930c <fwp_write+0x91c>
    92e0:	aa1603e1 	mov	x1, x22
    92e4:	aa1403e0 	mov	x0, x20
    92e8:	d2800042 	mov	x2, #0x2                   	// #2
    92ec:	97ffe8c9 	bl	3610 <buf_put>
    92f0:	f9400661 	ldr	x1, [x19, #8]
    92f4:	aa1403e0 	mov	x0, x20
    92f8:	f9401f82 	ldr	x2, [x28, #56]
    92fc:	52800003 	mov	w3, #0x0                   	// #0
    9300:	97fffdbc 	bl	89f0 <fwp_write>
    9304:	f9400a73 	ldr	x19, [x19, #16]
    9308:	b5fffed3 	cbnz	x19, 92e0 <fwp_write+0x8f0>
    930c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9310:	aa1503e1 	mov	x1, x21
    9314:	aa1403e0 	mov	x0, x20
    9318:	d2800022 	mov	x2, #0x1                   	// #1
    931c:	39001fe3 	strb	w3, [sp, #7]
    9320:	17fffddb 	b	8a8c <fwp_write+0x9c>
    9324:	aa1403e0 	mov	x0, x20
    9328:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    932c:	d28000c2 	mov	x2, #0x6                   	// #6
    9330:	91044021 	add	x1, x1, #0x110
    9334:	97ffe8b7 	bl	3610 <buf_put>
    9338:	f9400260 	ldr	x0, [x19]
    933c:	b40004c0 	cbz	x0, 93d4 <fwp_write+0x9e4>
    9340:	910123f5 	add	x21, sp, #0x48
    9344:	91002276 	add	x22, x19, #0x8
    9348:	f90143f7 	str	x23, [sp, #640]
    934c:	d2800017 	mov	x23, #0x0                   	// #0
    9350:	f90147f8 	str	x24, [sp, #648]
    9354:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x670>
    9358:	91046318 	add	x24, x24, #0x118
    935c:	f9014bf9 	str	x25, [sp, #656]
    9360:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x670>
    9364:	91048339 	add	x25, x25, #0x120
    9368:	f9014ffa 	str	x26, [sp, #664]
    936c:	14000005 	b	9380 <fwp_write+0x990>
    9370:	aa1903e1 	mov	x1, x25
    9374:	aa1403e0 	mov	x0, x20
    9378:	d2800042 	mov	x2, #0x2                   	// #2
    937c:	97ffe8a5 	bl	3610 <buf_put>
    9380:	38776ac5 	ldrb	w5, [x22, x23]
    9384:	d2804003 	mov	x3, #0x200                 	// #512
    9388:	aa1803e4 	mov	x4, x24
    938c:	aa0303e1 	mov	x1, x3
    9390:	52800042 	mov	w2, #0x2                   	// #2
    9394:	aa1503e0 	mov	x0, x21
    9398:	910006f7 	add	x23, x23, #0x1
    939c:	97ffe4f9 	bl	2780 <__snprintf_chk@plt>
    93a0:	aa1503e0 	mov	x0, x21
    93a4:	97ffe4bf 	bl	26a0 <strlen@plt>
    93a8:	aa1503e1 	mov	x1, x21
    93ac:	aa0003e2 	mov	x2, x0
    93b0:	aa1403e0 	mov	x0, x20
    93b4:	97ffe897 	bl	3610 <buf_put>
    93b8:	f9400260 	ldr	x0, [x19]
    93bc:	eb17001f 	cmp	x0, x23
    93c0:	54fffd88 	b.hi	9370 <fwp_write+0x980>  // b.pmore
    93c4:	f94143f7 	ldr	x23, [sp, #640]
    93c8:	f94147f8 	ldr	x24, [sp, #648]
    93cc:	f9414bf9 	ldr	x25, [sp, #656]
    93d0:	f9414ffa 	ldr	x26, [sp, #664]
    93d4:	52800ba3 	mov	w3, #0x5d                  	// #93
    93d8:	aa1403e0 	mov	x0, x20
    93dc:	91001fe1 	add	x1, sp, #0x7
    93e0:	d2800022 	mov	x2, #0x1                   	// #1
    93e4:	39001fe3 	strb	w3, [sp, #7]
    93e8:	17fffda9 	b	8a8c <fwp_write+0x9c>
    93ec:	52800fa3 	mov	w3, #0x7d                  	// #125
    93f0:	17fffe44 	b	8d00 <fwp_write+0x310>
    93f4:	f10002ff 	cmp	x23, #0x0
    93f8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    93fc:	71002c3f 	cmp	w1, #0xb
    9400:	54ffebc0 	b.eq	9178 <fwp_write+0x788>  // b.none
    9404:	aa1303e2 	mov	x2, x19
    9408:	aa1703e1 	mov	x1, x23
    940c:	aa1403e0 	mov	x0, x20
    9410:	52800003 	mov	w3, #0x0                   	// #0
    9414:	97fffd77 	bl	89f0 <fwp_write>
    9418:	17ffff6a 	b	91c0 <fwp_write+0x7d0>
    941c:	aa1403e0 	mov	x0, x20
    9420:	91001fe1 	add	x1, sp, #0x7
    9424:	52800fa3 	mov	w3, #0x7d                  	// #125
    9428:	d2800022 	mov	x2, #0x1                   	// #1
    942c:	17fffe38 	b	8d0c <fwp_write+0x31c>
    9430:	a9400281 	ldp	x1, x0, [x20]
    9434:	91000800 	add	x0, x0, #0x2
    9438:	8b160000 	add	x0, x0, x22
    943c:	f9000680 	str	x0, [x20, #8]
    9440:	3820683f 	strb	wzr, [x1, x0]
    9444:	f9413bf5 	ldr	x21, [sp, #624]
    9448:	f9413ff6 	ldr	x22, [sp, #632]
    944c:	f94153fb 	ldr	x27, [sp, #672]
    9450:	f94157fc 	ldr	x28, [sp, #680]
    9454:	17fffd93 	b	8aa0 <fwp_write+0xb0>
    9458:	f9400f80 	ldr	x0, [x28, #24]
    945c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9460:	aa1b03e0 	mov	x0, x27
    9464:	97ffe48f 	bl	26a0 <strlen@plt>
    9468:	aa1b03e1 	mov	x1, x27
    946c:	aa0003e2 	mov	x2, x0
    9470:	aa1403e0 	mov	x0, x20
    9474:	97ffe867 	bl	3610 <buf_put>
    9478:	aa1903e1 	mov	x1, x25
    947c:	aa1403e0 	mov	x0, x20
    9480:	d2800062 	mov	x2, #0x3                   	// #3
    9484:	97ffe863 	bl	3610 <buf_put>
    9488:	17fffe10 	b	8cc8 <fwp_write+0x2d8>
    948c:	aa1a03e1 	mov	x1, x26
    9490:	aa1403e0 	mov	x0, x20
    9494:	d2800042 	mov	x2, #0x2                   	// #2
    9498:	97ffe85e 	bl	3610 <buf_put>
    949c:	17fffe09 	b	8cc0 <fwp_write+0x2d0>
    94a0:	f9400660 	ldr	x0, [x19, #8]
    94a4:	b4fffb00 	cbz	x0, 9404 <fwp_write+0xa14>
    94a8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    94ac:	9104e021 	add	x1, x1, #0x138
    94b0:	97ffe4f8 	bl	2890 <strcmp@plt>
    94b4:	7100001f 	cmp	w0, #0x0
    94b8:	1a9f07e0 	cset	w0, ne	// ne = any
    94bc:	17ffff2f 	b	9178 <fwp_write+0x788>
    94c0:	aa1403e0 	mov	x0, x20
    94c4:	d2800042 	mov	x2, #0x2                   	// #2
    94c8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    94cc:	9104c021 	add	x1, x1, #0x130
    94d0:	97ffe850 	bl	3610 <buf_put>
    94d4:	91004261 	add	x1, x19, #0x10
    94d8:	aa1403e0 	mov	x0, x20
    94dc:	f9402382 	ldr	x2, [x28, #64]
    94e0:	52800003 	mov	w3, #0x0                   	// #0
    94e4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    94e8:	97fffd42 	bl	89f0 <fwp_write>
    94ec:	17fffd9c 	b	8b5c <fwp_write+0x16c>
    94f0:	1e22c109 	fcvt	d9, s8
    94f4:	910123f5 	add	x21, sp, #0x48
    94f8:	52800033 	mov	w19, #0x1                   	// #1
    94fc:	d503201f 	nop
    9500:	1e604120 	fmov	d0, d9
    9504:	2a1303e1 	mov	w1, w19
    9508:	aa1503e0 	mov	x0, x21
    950c:	97ffe982 	bl	3b14 <fwp_format_g.constprop.0>
    9510:	aa1503e0 	mov	x0, x21
    9514:	d2800001 	mov	x1, #0x0                   	// #0
    9518:	97ffe4ea 	bl	28c0 <strtof@plt>
    951c:	1e202100 	fcmp	s8, s0
    9520:	54ffdb60 	b.eq	908c <fwp_write+0x69c>  // b.none
    9524:	11000673 	add	w19, w19, #0x1
    9528:	71002a7f 	cmp	w19, #0xa
    952c:	54fffea1 	b.ne	9500 <fwp_write+0xb10>  // b.any
    9530:	1e604120 	fmov	d0, d9
    9534:	aa1503e0 	mov	x0, x21
    9538:	52800121 	mov	w1, #0x9                   	// #9
    953c:	97ffe976 	bl	3b14 <fwp_format_g.constprop.0>
    9540:	17fffed3 	b	908c <fwp_write+0x69c>
    9544:	d37ef6a1 	lsl	x1, x21, #2
    9548:	b7f81563 	tbnz	x3, #63, 97f4 <fwp_write+0xe04>
    954c:	91002263 	add	x3, x19, #0x8
    9550:	8b010061 	add	x1, x3, x1
    9554:	b9400023 	ldr	w3, [x1]
    9558:	7100081f 	cmp	w0, #0x2
    955c:	2a0303e1 	mov	w1, w3
    9560:	93407c63 	sxtw	x3, w3
    9564:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9568:	17fffe5a 	b	8ed0 <fwp_write+0x4e0>
    956c:	d37ffaa1 	lsl	x1, x21, #1
    9570:	b7f81363 	tbnz	x3, #63, 97dc <fwp_write+0xdec>
    9574:	91002263 	add	x3, x19, #0x8
    9578:	8b010061 	add	x1, x3, x1
    957c:	79400021 	ldrh	w1, [x1]
    9580:	7100041f 	cmp	w0, #0x1
    9584:	93403c23 	sxth	x3, w1
    9588:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    958c:	17fffe51 	b	8ed0 <fwp_write+0x4e0>
    9590:	52800443 	mov	w3, #0x22                  	// #34
    9594:	91001ff5 	add	x21, sp, #0x7
    9598:	91002273 	add	x19, x19, #0x8
    959c:	aa1503e1 	mov	x1, x21
    95a0:	aa1403e0 	mov	x0, x20
    95a4:	d2800022 	mov	x2, #0x1                   	// #1
    95a8:	39001fe3 	strb	w3, [sp, #7]
    95ac:	f90143f7 	str	x23, [sp, #640]
    95b0:	8b160277 	add	x23, x19, x22
    95b4:	f90147f8 	str	x24, [sp, #648]
    95b8:	97ffe816 	bl	3610 <buf_put>
    95bc:	b4000696 	cbz	x22, 968c <fwp_write+0xc9c>
    95c0:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x670>
    95c4:	91038318 	add	x24, x24, #0xe0
    95c8:	f9014bf9 	str	x25, [sp, #656]
    95cc:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x670>
    95d0:	91040339 	add	x25, x25, #0x100
    95d4:	f9014ffa 	str	x26, [sp, #664]
    95d8:	1400000d 	b	960c <fwp_write+0xc1c>
    95dc:	710024bf 	cmp	w5, #0x9
    95e0:	54000460 	b.eq	966c <fwp_write+0xc7c>  // b.none
    95e4:	710028bf 	cmp	w5, #0xa
    95e8:	54000a61 	b.ne	9734 <fwp_write+0xd44>  // b.any
    95ec:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    95f0:	aa1403e0 	mov	x0, x20
    95f4:	9103c021 	add	x1, x1, #0xf0
    95f8:	d2800042 	mov	x2, #0x2                   	// #2
    95fc:	97ffe805 	bl	3610 <buf_put>
    9600:	91000673 	add	x19, x19, #0x1
    9604:	eb17027f 	cmp	x19, x23
    9608:	540003e0 	b.eq	9684 <fwp_write+0xc94>  // b.none
    960c:	39400265 	ldrb	w5, [x19]
    9610:	710034bf 	cmp	w5, #0xd
    9614:	54000180 	b.eq	9644 <fwp_write+0xc54>  // b.none
    9618:	54fffe29 	b.ls	95dc <fwp_write+0xbec>  // b.plast
    961c:	710088bf 	cmp	w5, #0x22
    9620:	540001c0 	b.eq	9658 <fwp_write+0xc68>  // b.none
    9624:	710170bf 	cmp	w5, #0x5c
    9628:	54000741 	b.ne	9710 <fwp_write+0xd20>  // b.any
    962c:	aa1403e0 	mov	x0, x20
    9630:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    9634:	d2800042 	mov	x2, #0x2                   	// #2
    9638:	9103a021 	add	x1, x1, #0xe8
    963c:	97ffe7f5 	bl	3610 <buf_put>
    9640:	17fffff0 	b	9600 <fwp_write+0xc10>
    9644:	aa1903e1 	mov	x1, x25
    9648:	aa1403e0 	mov	x0, x20
    964c:	d2800042 	mov	x2, #0x2                   	// #2
    9650:	97ffe7f0 	bl	3610 <buf_put>
    9654:	17ffffeb 	b	9600 <fwp_write+0xc10>
    9658:	aa1803e1 	mov	x1, x24
    965c:	aa1403e0 	mov	x0, x20
    9660:	d2800042 	mov	x2, #0x2                   	// #2
    9664:	97ffe7eb 	bl	3610 <buf_put>
    9668:	17ffffe6 	b	9600 <fwp_write+0xc10>
    966c:	aa1403e0 	mov	x0, x20
    9670:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    9674:	d2800042 	mov	x2, #0x2                   	// #2
    9678:	9103e021 	add	x1, x1, #0xf8
    967c:	97ffe7e5 	bl	3610 <buf_put>
    9680:	17ffffe0 	b	9600 <fwp_write+0xc10>
    9684:	f9414bf9 	ldr	x25, [sp, #656]
    9688:	f9414ffa 	ldr	x26, [sp, #664]
    968c:	aa1503e1 	mov	x1, x21
    9690:	aa1403e0 	mov	x0, x20
    9694:	52800443 	mov	w3, #0x22                  	// #34
    9698:	17fffd9c 	b	8d08 <fwp_write+0x318>
    969c:	7100103f 	cmp	w1, #0x4
    96a0:	54ffeb21 	b.ne	9404 <fwp_write+0xa14>  // b.any
    96a4:	f94006e0 	ldr	x0, [x23, #8]
    96a8:	d37ffc00 	lsr	x0, x0, #63
    96ac:	17fffeb3 	b	9178 <fwp_write+0x788>
    96b0:	710002ff 	cmp	w23, #0x0
    96b4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    96b8:	17fffeb0 	b	9178 <fwp_write+0x788>
    96bc:	528005a1 	mov	w1, #0x2d                  	// #45
    96c0:	eb0203e2 	negs	x2, x2
    96c4:	da0303e3 	ngc	x3, x3
    96c8:	910127e0 	add	x0, sp, #0x49
    96cc:	910123f5 	add	x21, sp, #0x48
    96d0:	390123e1 	strb	w1, [sp, #72]
    96d4:	97ffe5b3 	bl	2da0 <fwp_fmt_u128>
    96d8:	17fffe18 	b	8f38 <fwp_write+0x548>
    96dc:	d37ceea1 	lsl	x1, x21, #4
    96e0:	b7f810a3 	tbnz	x3, #63, 98f4 <fwp_write+0xf04>
    96e4:	91002260 	add	x0, x19, #0x8
    96e8:	8b010001 	add	x1, x0, x1
    96ec:	17fffdf9 	b	8ed0 <fwp_write+0x4e0>
    96f0:	f9400a61 	ldr	x1, [x19, #16]
    96f4:	8b010000 	add	x0, x0, x1
    96f8:	f9400001 	ldr	x1, [x0]
    96fc:	17fffdf5 	b	8ed0 <fwp_write+0x4e0>
    9700:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    9704:	d2800042 	mov	x2, #0x2                   	// #2
    9708:	91022021 	add	x1, x1, #0x88
    970c:	17fffed6 	b	9264 <fwp_write+0x874>
    9710:	7101fcbf 	cmp	w5, #0x7f
    9714:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9718:	540000e9 	b.ls	9734 <fwp_write+0xd44>  // b.plast
    971c:	aa1503e1 	mov	x1, x21
    9720:	aa1403e0 	mov	x0, x20
    9724:	d2800022 	mov	x2, #0x1                   	// #1
    9728:	39001fe5 	strb	w5, [sp, #7]
    972c:	97ffe7b9 	bl	3610 <buf_put>
    9730:	17ffffb4 	b	9600 <fwp_write+0xc10>
    9734:	d2800203 	mov	x3, #0x10                  	// #16
    9738:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x670>
    973c:	aa0303e1 	mov	x1, x3
    9740:	91042084 	add	x4, x4, #0x108
    9744:	910123f6 	add	x22, sp, #0x48
    9748:	52800042 	mov	w2, #0x2                   	// #2
    974c:	aa1603e0 	mov	x0, x22
    9750:	97ffe40c 	bl	2780 <__snprintf_chk@plt>
    9754:	aa1603e0 	mov	x0, x22
    9758:	97ffe3d2 	bl	26a0 <strlen@plt>
    975c:	aa1603e1 	mov	x1, x22
    9760:	aa0003e2 	mov	x2, x0
    9764:	aa1403e0 	mov	x0, x20
    9768:	97ffe7aa 	bl	3610 <buf_put>
    976c:	17ffffa5 	b	9600 <fwp_write+0xc10>
    9770:	1e604100 	fmov	d0, d8
    9774:	aa1503e0 	mov	x0, x21
    9778:	52800221 	mov	w1, #0x11                  	// #17
    977c:	97ffe8e6 	bl	3b14 <fwp_format_g.constprop.0>
    9780:	17fffe43 	b	908c <fwp_write+0x69c>
    9784:	b9401040 	ldr	w0, [x2, #16]
    9788:	350003c0 	cbnz	w0, 9800 <fwp_write+0xe10>
    978c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9790:	f947f400 	ldr	x0, [x0, #4072]
    9794:	f94127e2 	ldr	x2, [sp, #584]
    9798:	f9400001 	ldr	x1, [x0]
    979c:	eb010042 	subs	x2, x2, x1
    97a0:	d2800001 	mov	x1, #0x0                   	// #0
    97a4:	54ffd721 	b.ne	9288 <fwp_write+0x898>  // b.any
    97a8:	f9413bf5 	ldr	x21, [sp, #624]
    97ac:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    97b0:	f9413ff6 	ldr	x22, [sp, #632]
    97b4:	aa1403e0 	mov	x0, x20
    97b8:	f94143f7 	ldr	x23, [sp, #640]
    97bc:	91056021 	add	x1, x1, #0x158
    97c0:	f94147f8 	ldr	x24, [sp, #648]
    97c4:	d2800042 	mov	x2, #0x2                   	// #2
    97c8:	17fffd0e 	b	8c00 <fwp_write+0x210>
    97cc:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x670>
    97d0:	d2800042 	mov	x2, #0x2                   	// #2
    97d4:	91024021 	add	x1, x1, #0x90
    97d8:	17fffea3 	b	9264 <fwp_write+0x874>
    97dc:	f9400a63 	ldr	x3, [x19, #16]
    97e0:	8b030021 	add	x1, x1, x3
    97e4:	17ffff66 	b	957c <fwp_write+0xb8c>
    97e8:	f9400a61 	ldr	x1, [x19, #16]
    97ec:	8b0102a1 	add	x1, x21, x1
    97f0:	17fffdb3 	b	8ebc <fwp_write+0x4cc>
    97f4:	f9400a63 	ldr	x3, [x19, #16]
    97f8:	8b030021 	add	x1, x1, x3
    97fc:	17ffff56 	b	9554 <fwp_write+0xb64>
    9800:	b9404840 	ldr	w0, [x2, #72]
    9804:	91001ff5 	add	x21, sp, #0x7
    9808:	34ffa360 	cbz	w0, 8c74 <fwp_write+0x284>
    980c:	52800503 	mov	w3, #0x28                  	// #40
    9810:	aa1403e0 	mov	x0, x20
    9814:	aa1503e1 	mov	x1, x21
    9818:	d2800022 	mov	x2, #0x1                   	// #1
    981c:	39001fe3 	strb	w3, [sp, #7]
    9820:	97ffe77c 	bl	3610 <buf_put>
    9824:	b9401380 	ldr	w0, [x28, #16]
    9828:	52800038 	mov	w24, #0x1                   	// #1
    982c:	7100001f 	cmp	w0, #0x0
    9830:	54ffa36c 	b.gt	8c9c <fwp_write+0x2ac>
    9834:	17fffd32 	b	8cfc <fwp_write+0x30c>
    9838:	f9014bf9 	str	x25, [sp, #656]
    983c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe188>
    9840:	f9014ffa 	str	x26, [sp, #664]
    9844:	f9400676 	ldr	x22, [x19, #8]
    9848:	91104333 	add	x19, x25, #0x410
    984c:	91002273 	add	x19, x19, #0x8
    9850:	937ffed8 	asr	x24, x22, #63
    9854:	aa1802c0 	orr	x0, x22, x24
    9858:	b5000320 	cbnz	x0, 98bc <fwp_write+0xecc>
    985c:	110006b5 	add	w21, w21, #0x1
    9860:	710016bf 	cmp	w21, #0x5
    9864:	54ffffc1 	b.ne	985c <fwp_write+0xe6c>  // b.any
    9868:	b7f80578 	tbnz	x24, #63, 9914 <fwp_write+0xf24>
    986c:	910023f3 	add	x19, sp, #0x8
    9870:	aa1603e2 	mov	x2, x22
    9874:	aa1303e0 	mov	x0, x19
    9878:	d2800003 	mov	x3, #0x0                   	// #0
    987c:	97ffe549 	bl	2da0 <fwp_fmt_u128>
    9880:	910123f5 	add	x21, sp, #0x48
    9884:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x670>
    9888:	aa1303e4 	mov	x4, x19
    988c:	aa1503e0 	mov	x0, x21
    9890:	91054063 	add	x3, x3, #0x150
    9894:	d2804002 	mov	x2, #0x200                 	// #512
    9898:	52800041 	mov	w1, #0x2                   	// #2
    989c:	97ffe385 	bl	26b0 <__sprintf_chk@plt>
    98a0:	aa1503e0 	mov	x0, x21
    98a4:	97ffe37f 	bl	26a0 <strlen@plt>
    98a8:	aa1503e1 	mov	x1, x21
    98ac:	aa0003e2 	mov	x2, x0
    98b0:	aa1403e0 	mov	x0, x20
    98b4:	97ffe757 	bl	3610 <buf_put>
    98b8:	17fffe47 	b	91d4 <fwp_write+0x7e4>
    98bc:	f9400277 	ldr	x23, [x19]
    98c0:	aa1603e0 	mov	x0, x22
    98c4:	aa1803e1 	mov	x1, x24
    98c8:	aa1703e2 	mov	x2, x23
    98cc:	937ffefa 	asr	x26, x23, #63
    98d0:	aa1a03e3 	mov	x3, x26
    98d4:	94000f47 	bl	d5f0 <__modti3>
    98d8:	aa010000 	orr	x0, x0, x1
    98dc:	b40002c0 	cbz	x0, 9934 <fwp_write+0xf44>
    98e0:	110006b5 	add	w21, w21, #0x1
    98e4:	91004273 	add	x19, x19, #0x10
    98e8:	710016bf 	cmp	w21, #0x5
    98ec:	54fffe81 	b.ne	98bc <fwp_write+0xecc>  // b.any
    98f0:	17ffffde 	b	9868 <fwp_write+0xe78>
    98f4:	f9400a60 	ldr	x0, [x19, #16]
    98f8:	8b000021 	add	x1, x1, x0
    98fc:	17fffd75 	b	8ed0 <fwp_write+0x4e0>
    9900:	528c29c0 	mov	w0, #0x614e                	// #24910
    9904:	910123f5 	add	x21, sp, #0x48
    9908:	72a009c0 	movk	w0, #0x4e, lsl #16
    990c:	b9004be0 	str	w0, [sp, #72]
    9910:	17fffda2 	b	8f98 <fwp_write+0x5a8>
    9914:	528005a1 	mov	w1, #0x2d                  	// #45
    9918:	eb1603e2 	negs	x2, x22
    991c:	da1803e3 	ngc	x3, x24
    9920:	910027e0 	add	x0, sp, #0x9
    9924:	910023f3 	add	x19, sp, #0x8
    9928:	390023e1 	strb	w1, [sp, #8]
    992c:	97ffe51d 	bl	2da0 <fwp_fmt_u128>
    9930:	17ffffd4 	b	9880 <fwp_write+0xe90>
    9934:	aa1703e2 	mov	x2, x23
    9938:	aa1a03e3 	mov	x3, x26
    993c:	aa1603e0 	mov	x0, x22
    9940:	aa1803e1 	mov	x1, x24
    9944:	94000e4b 	bl	d270 <__divti3>
    9948:	aa0003e2 	mov	x2, x0
    994c:	aa0103e3 	mov	x3, x1
    9950:	b7f80201 	tbnz	x1, #63, 9990 <fwp_write+0xfa0>
    9954:	910023f3 	add	x19, sp, #0x8
    9958:	aa1303e0 	mov	x0, x19
    995c:	97ffe511 	bl	2da0 <fwp_fmt_u128>
    9960:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9964:	91104339 	add	x25, x25, #0x410
    9968:	910123f5 	add	x21, sp, #0x48
    996c:	aa1303e4 	mov	x4, x19
    9970:	aa1503e0 	mov	x0, x21
    9974:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x670>
    9978:	f8616b25 	ldr	x5, [x25, x1]
    997c:	91052063 	add	x3, x3, #0x148
    9980:	d2804002 	mov	x2, #0x200                 	// #512
    9984:	52800041 	mov	w1, #0x2                   	// #2
    9988:	97ffe34a 	bl	26b0 <__sprintf_chk@plt>
    998c:	17ffffc5 	b	98a0 <fwp_write+0xeb0>
    9990:	528005a4 	mov	w4, #0x2d                  	// #45
    9994:	eb0003e2 	negs	x2, x0
    9998:	da0103e3 	ngc	x3, x1
    999c:	910027e0 	add	x0, sp, #0x9
    99a0:	910023f3 	add	x19, sp, #0x8
    99a4:	390023e4 	strb	w4, [sp, #8]
    99a8:	97ffe4fe 	bl	2da0 <fwp_fmt_u128>
    99ac:	17ffffed 	b	9960 <fwp_write+0xf70>
    99b0:	f9013bf5 	str	x21, [sp, #624]
    99b4:	f9013ff6 	str	x22, [sp, #632]
    99b8:	f90143f7 	str	x23, [sp, #640]
    99bc:	f90147f8 	str	x24, [sp, #648]
    99c0:	f9014bf9 	str	x25, [sp, #656]
    99c4:	f9014ffa 	str	x26, [sp, #664]
    99c8:	f90153fb 	str	x27, [sp, #672]
    99cc:	f90157fc 	str	x28, [sp, #680]
    99d0:	fd015be8 	str	d8, [sp, #688]
    99d4:	fd015fe9 	str	d9, [sp, #696]
    99d8:	97ffe38e 	bl	2810 <__stack_chk_fail@plt>
    99dc:	d503201f 	nop

00000000000099e0 <fwp_hof0.constprop.0>:
    99e0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    99e4:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    99e8:	f947f442 	ldr	x2, [x2, #4072]
    99ec:	910003fd 	mov	x29, sp
    99f0:	a90153f3 	stp	x19, x20, [sp, #16]
    99f4:	a9025bf5 	stp	x21, x22, [sp, #32]
    99f8:	a90363f7 	stp	x23, x24, [sp, #48]
    99fc:	aa0003f7 	mov	x23, x0
    9a00:	a9046bf9 	stp	x25, x26, [sp, #64]
    9a04:	a90573fb 	stp	x27, x28, [sp, #80]
    9a08:	d10243ff 	sub	sp, sp, #0x90
    9a0c:	f9400040 	ldr	x0, [x2]
    9a10:	f81f83a0 	stur	x0, [x29, #-8]
    9a14:	d2800000 	mov	x0, #0x0                   	// #0
    9a18:	b4002ee1 	cbz	x1, 9ff4 <fwp_hof0.constprop.0+0x614>
    9a1c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a20:	9100401c 	add	x28, x0, #0x10
    9a24:	9100a39c 	add	x28, x28, #0x28
    9a28:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a2c:	aa0103fa 	mov	x26, x1
    9a30:	d10083b4 	sub	x20, x29, #0x20
    9a34:	91018015 	add	x21, x0, #0x60
    9a38:	aa1c03f8 	mov	x24, x28
    9a3c:	90000380 	adrp	x0, 79000 <fwp_root_context+0xb80>
    9a40:	91198002 	add	x2, x0, #0x660
    9a44:	f949d841 	ldr	x1, [x2, #5040]
    9a48:	f949ec40 	ldr	x0, [x2, #5080]
    9a4c:	cb0102e1 	sub	x1, x23, x1
    9a50:	eb00403f 	cmp	x1, x0, lsl #16
    9a54:	540003c2 	b.cs	9acc <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9a58:	d350fc20 	lsr	x0, x1, #16
    9a5c:	f949fc44 	ldr	x4, [x2, #5112]
    9a60:	8b000800 	add	x0, x0, x0, lsl #2
    9a64:	d37df002 	lsl	x2, x0, #3
    9a68:	8b020083 	add	x3, x4, x2
    9a6c:	f9401060 	ldr	x0, [x3, #32]
    9a70:	b40002e0 	cbz	x0, 9acc <fwp_hof0.constprop.0+0xec>
    9a74:	38626882 	ldrb	w2, [x4, x2]
    9a78:	7100085f 	cmp	w2, #0x2
    9a7c:	54005600 	b.eq	a53c <fwp_hof0.constprop.0+0xb5c>  // b.none
    9a80:	7100045f 	cmp	w2, #0x1
    9a84:	54000241 	b.ne	9acc <fwp_hof0.constprop.0+0xec>  // b.any
    9a88:	29430864 	ldp	w4, w2, [x3, #24]
    9a8c:	92403c21 	and	x1, x1, #0xffff
    9a90:	9b047c21 	mul	x1, x1, x4
    9a94:	d360fc21 	lsr	x1, x1, #32
    9a98:	eb02003f 	cmp	x1, x2
    9a9c:	54000182 	b.cs	9acc <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9aa0:	8b010000 	add	x0, x0, x1
    9aa4:	39400001 	ldrb	w1, [x0]
    9aa8:	34000121 	cbz	w1, 9acc <fwp_hof0.constprop.0+0xec>
    9aac:	f00000a2 	adrp	x2, 20000 <__data_start>
    9ab0:	91018042 	add	x2, x2, #0x60
    9ab4:	b9415043 	ldr	w3, [x2, #336]
    9ab8:	35005583 	cbnz	w3, a568 <fwp_hof0.constprop.0+0xb88>
    9abc:	7103f43f 	cmp	w1, #0xfd
    9ac0:	54005ae8 	b.hi	a61c <fwp_hof0.constprop.0+0xc3c>  // b.pmore
    9ac4:	11000421 	add	w1, w1, #0x1
    9ac8:	39000001 	strb	w1, [x0]
    9acc:	aa1703f9 	mov	x25, x23
    9ad0:	a938dfba 	stp	x26, x23, [x29, #-120]
    9ad4:	aa1803fa 	mov	x26, x24
    9ad8:	d28018f3 	mov	x19, #0xc7                  	// #199
    9adc:	f81983b3 	stur	x19, [x29, #-104]
    9ae0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ae4:	91004000 	add	x0, x0, #0x10
    9ae8:	f9406aa3 	ldr	x3, [x21, #208]
    9aec:	9100a005 	add	x5, x0, #0x28
    9af0:	b9402802 	ldr	w2, [x0, #40]
    9af4:	d37be842 	lsl	x2, x2, #5
    9af8:	8b02007b 	add	x27, x3, x2
    9afc:	f9400f61 	ldr	x1, [x27, #24]
    9b00:	f81e03b9 	stur	x25, [x29, #-32]
    9b04:	b4005221 	cbz	x1, a548 <fwp_hof0.constprop.0+0xb68>
    9b08:	f9400c20 	ldr	x0, [x1, #24]
    9b0c:	b4004560 	cbz	x0, a3b8 <fwp_hof0.constprop.0+0x9d8>
    9b10:	90000380 	adrp	x0, 79000 <fwp_root_context+0xb80>
    9b14:	91198002 	add	x2, x0, #0x660
    9b18:	f949d841 	ldr	x1, [x2, #5040]
    9b1c:	f949ec40 	ldr	x0, [x2, #5080]
    9b20:	cb010341 	sub	x1, x26, x1
    9b24:	eb00403f 	cmp	x1, x0, lsl #16
    9b28:	540003e2 	b.cs	9ba4 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9b2c:	d350fc20 	lsr	x0, x1, #16
    9b30:	f949fc45 	ldr	x5, [x2, #5112]
    9b34:	8b000800 	add	x0, x0, x0, lsl #2
    9b38:	d37df002 	lsl	x2, x0, #3
    9b3c:	8b0200a3 	add	x3, x5, x2
    9b40:	f9401060 	ldr	x0, [x3, #32]
    9b44:	b4000300 	cbz	x0, 9ba4 <fwp_hof0.constprop.0+0x1c4>
    9b48:	386268a2 	ldrb	w2, [x5, x2]
    9b4c:	7100085f 	cmp	w2, #0x2
    9b50:	540049c0 	b.eq	a488 <fwp_hof0.constprop.0+0xaa8>  // b.none
    9b54:	7100045f 	cmp	w2, #0x1
    9b58:	54000261 	b.ne	9ba4 <fwp_hof0.constprop.0+0x1c4>  // b.any
    9b5c:	29430865 	ldp	w5, w2, [x3, #24]
    9b60:	92403c21 	and	x1, x1, #0xffff
    9b64:	9b057c21 	mul	x1, x1, x5
    9b68:	d360fc21 	lsr	x1, x1, #32
    9b6c:	eb02003f 	cmp	x1, x2
    9b70:	540001a2 	b.cs	9ba4 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9b74:	8b010000 	add	x0, x0, x1
    9b78:	39400001 	ldrb	w1, [x0]
    9b7c:	34000141 	cbz	w1, 9ba4 <fwp_hof0.constprop.0+0x1c4>
    9b80:	b94152a2 	ldr	w2, [x21, #336]
    9b84:	34000082 	cbz	w2, 9b94 <fwp_hof0.constprop.0+0x1b4>
    9b88:	f940bea2 	ldr	x2, [x21, #376]
    9b8c:	91000442 	add	x2, x2, #0x1
    9b90:	f900bea2 	str	x2, [x21, #376]
    9b94:	7103f43f 	cmp	w1, #0xfd
    9b98:	54004c28 	b.hi	a51c <fwp_hof0.constprop.0+0xb3c>  // b.pmore
    9b9c:	11000421 	add	w1, w1, #0x1
    9ba0:	39000001 	strb	w1, [x0]
    9ba4:	aa1a03f9 	mov	x25, x26
    9ba8:	aa1a03e0 	mov	x0, x26
    9bac:	aa1b03e3 	mov	x3, x27
    9bb0:	52800037 	mov	w23, #0x1                   	// #1
    9bb4:	90000381 	adrp	x1, 79000 <fwp_root_context+0xb80>
    9bb8:	91198036 	add	x22, x1, #0x660
    9bbc:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    9bc0:	f81b03b6 	stur	x22, [x29, #-80]
    9bc4:	b81cc3b7 	stur	w23, [x29, #-52]
    9bc8:	f81d03b4 	stur	x20, [x29, #-48]
    9bcc:	b9400401 	ldr	w1, [x0, #4]
    9bd0:	b9400078 	ldr	w24, [x3]
    9bd4:	b85cc3a0 	ldur	w0, [x29, #-52]
    9bd8:	4b010318 	sub	w24, w24, w1
    9bdc:	6b17031f 	cmp	w24, w23
    9be0:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    9be4:	6b0000ff 	cmp	w7, w0
    9be8:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    9bec:	b81c83a0 	stur	w0, [x29, #-56]
    9bf0:	6b0000e2 	subs	w2, w7, w0
    9bf4:	54000120 	b.eq	9c18 <fwp_hof0.constprop.0+0x238>  // b.none
    9bf8:	f9400c63 	ldr	x3, [x3, #24]
    9bfc:	0b000021 	add	w1, w1, w0
    9c00:	f85d03a4 	ldur	x4, [x29, #-48]
    9c04:	b81d83a7 	stur	w7, [x29, #-40]
    9c08:	f9400863 	ldr	x3, [x3, #16]
    9c0c:	8b204c80 	add	x0, x4, w0, uxtw #3
    9c10:	d63f0060 	blr	x3
    9c14:	b85d83a7 	ldur	w7, [x29, #-40]
    9c18:	f9406aa0 	ldr	x0, [x21, #208]
    9c1c:	aa1903e6 	mov	x6, x25
    9c20:	b9400323 	ldr	w3, [x25]
    9c24:	2a0703f4 	mov	w20, w7
    9c28:	f85d03bb 	ldur	x27, [x29, #-48]
    9c2c:	aa1903fc 	mov	x28, x25
    9c30:	8b03141a 	add	x26, x0, x3, lsl #5
    9c34:	f9400f40 	ldr	x0, [x26, #24]
    9c38:	b4002100 	cbz	x0, a058 <fwp_hof0.constprop.0+0x678>
    9c3c:	f85b03bc 	ldur	x28, [x29, #-80]
    9c40:	29371fb7 	stp	w23, w7, [x29, #-72]
    9c44:	aa1a03f7 	mov	x23, x26
    9c48:	b81c03b8 	stur	w24, [x29, #-64]
    9c4c:	aa1b03f8 	mov	x24, x27
    9c50:	14000012 	b	9c98 <fwp_hof0.constprop.0+0x2b8>
    9c54:	f9400001 	ldr	x1, [x0]
    9c58:	aa1803e0 	mov	x0, x24
    9c5c:	d63f0020 	blr	x1
    9c60:	aa0003fb 	mov	x27, x0
    9c64:	aa1903e0 	mov	x0, x25
    9c68:	97fff17a 	bl	6250 <fwp_closure_drop>
    9c6c:	6b13029f 	cmp	w20, w19
    9c70:	54000cc0 	b.eq	9e08 <fwp_hof0.constprop.0+0x428>  // b.none
    9c74:	f9406aa0 	ldr	x0, [x21, #208]
    9c78:	8b334f18 	add	x24, x24, w19, uxtw #3
    9c7c:	b9400363 	ldr	w3, [x27]
    9c80:	4b1a02d4 	sub	w20, w22, w26
    9c84:	aa1b03e6 	mov	x6, x27
    9c88:	8b031417 	add	x23, x0, x3, lsl #5
    9c8c:	f9400ee0 	ldr	x0, [x23, #24]
    9c90:	b4001dc0 	cbz	x0, a048 <fwp_hof0.constprop.0+0x668>
    9c94:	aa1b03f9 	mov	x25, x27
    9c98:	b94004c1 	ldr	w1, [x6, #4]
    9c9c:	b94002fa 	ldr	w26, [x23]
    9ca0:	0b010296 	add	w22, w20, w1
    9ca4:	6b16035f 	cmp	w26, w22
    9ca8:	540024a8 	b.hi	a13c <fwp_hof0.constprop.0+0x75c>  // b.pmore
    9cac:	7100003f 	cmp	w1, #0x0
    9cb0:	4b010353 	sub	w19, w26, w1
    9cb4:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9cb8:	54fffce1 	b.ne	9c54 <fwp_hof0.constprop.0+0x274>  // b.any
    9cbc:	7100035f 	cmp	w26, #0x0
    9cc0:	910003e2 	mov	x2, sp
    9cc4:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    9cc8:	f81d83a2 	stur	x2, [x29, #-40]
    9ccc:	d37df084 	lsl	x4, x4, #3
    9cd0:	91003c84 	add	x4, x4, #0xf
    9cd4:	92704c87 	and	x7, x4, #0xfffff0000
    9cd8:	927c7c84 	and	x4, x4, #0xffffffff0
    9cdc:	cb2763e7 	sub	x7, sp, x7
    9ce0:	eb2763ff 	cmp	sp, x7
    9ce4:	540000a0 	b.eq	9cf8 <fwp_hof0.constprop.0+0x318>  // b.none
    9ce8:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9cec:	f90203ff 	str	xzr, [sp, #1024]
    9cf0:	eb2763ff 	cmp	sp, x7
    9cf4:	54ffffa1 	b.ne	9ce8 <fwp_hof0.constprop.0+0x308>  // b.any
    9cf8:	92403c84 	and	x4, x4, #0xffff
    9cfc:	cb2463ff 	sub	sp, sp, x4
    9d00:	f90003ff 	str	xzr, [sp]
    9d04:	f110009f 	cmp	x4, #0x400
    9d08:	54000043 	b.cc	9d10 <fwp_hof0.constprop.0+0x330>  // b.lo, b.ul, b.last
    9d0c:	f90203ff 	str	xzr, [sp, #1024]
    9d10:	910043fb 	add	x27, sp, #0x10
    9d14:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9d18:	910020c9 	add	x9, x6, #0x8
    9d1c:	d2800004 	mov	x4, #0x0                   	// #0
    9d20:	340000e1 	cbz	w1, 9d3c <fwp_hof0.constprop.0+0x35c>
    9d24:	d503201f 	nop
    9d28:	f8646922 	ldr	x2, [x9, x4]
    9d2c:	f8246b62 	str	x2, [x27, x4]
    9d30:	91002084 	add	x4, x4, #0x8
    9d34:	eb04015f 	cmp	x10, x4
    9d38:	54ffff81 	b.ne	9d28 <fwp_hof0.constprop.0+0x348>  // b.any
    9d3c:	2a1303ea 	mov	w10, w19
    9d40:	d2800004 	mov	x4, #0x0                   	// #0
    9d44:	340000f3 	cbz	w19, 9d60 <fwp_hof0.constprop.0+0x380>
    9d48:	0b040022 	add	w2, w1, w4
    9d4c:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9d50:	91000484 	add	x4, x4, #0x1
    9d54:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9d58:	eb04015f 	cmp	x10, x4
    9d5c:	54ffff61 	b.ne	9d48 <fwp_hof0.constprop.0+0x368>  // b.any
    9d60:	f949db81 	ldr	x1, [x28, #5040]
    9d64:	f949ef84 	ldr	x4, [x28, #5080]
    9d68:	cb010321 	sub	x1, x25, x1
    9d6c:	eb04403f 	cmp	x1, x4, lsl #16
    9d70:	540002e2 	b.cs	9dcc <fwp_hof0.constprop.0+0x3ec>  // b.hs, b.nlast
    9d74:	d350fc24 	lsr	x4, x1, #16
    9d78:	f949ff8a 	ldr	x10, [x28, #5112]
    9d7c:	8b040884 	add	x4, x4, x4, lsl #2
    9d80:	d37df084 	lsl	x4, x4, #3
    9d84:	8b040149 	add	x9, x10, x4
    9d88:	f9401128 	ldr	x8, [x9, #32]
    9d8c:	b4000208 	cbz	x8, 9dcc <fwp_hof0.constprop.0+0x3ec>
    9d90:	38646944 	ldrb	w4, [x10, x4]
    9d94:	7100089f 	cmp	w4, #0x2
    9d98:	54001520 	b.eq	a03c <fwp_hof0.constprop.0+0x65c>  // b.none
    9d9c:	7100049f 	cmp	w4, #0x1
    9da0:	54000161 	b.ne	9dcc <fwp_hof0.constprop.0+0x3ec>  // b.any
    9da4:	2943112a 	ldp	w10, w4, [x9, #24]
    9da8:	92403c21 	and	x1, x1, #0xffff
    9dac:	9b0a7c21 	mul	x1, x1, x10
    9db0:	d360fc21 	lsr	x1, x1, #32
    9db4:	eb04003f 	cmp	x1, x4
    9db8:	540000a2 	b.cs	9dcc <fwp_hof0.constprop.0+0x3ec>  // b.hs, b.nlast
    9dbc:	8b010108 	add	x8, x8, x1
    9dc0:	39400101 	ldrb	w1, [x8]
    9dc4:	7100043f 	cmp	w1, #0x1
    9dc8:	54001360 	b.eq	a034 <fwp_hof0.constprop.0+0x654>  // b.none
    9dcc:	f9400404 	ldr	x4, [x0, #8]
    9dd0:	52800021 	mov	w1, #0x1                   	// #1
    9dd4:	aa1903e0 	mov	x0, x25
    9dd8:	d63f0080 	blr	x4
    9ddc:	f9400ee1 	ldr	x1, [x23, #24]
    9de0:	aa1b03e0 	mov	x0, x27
    9de4:	f9400021 	ldr	x1, [x1]
    9de8:	d63f0020 	blr	x1
    9dec:	aa0003fb 	mov	x27, x0
    9df0:	f85d83a0 	ldur	x0, [x29, #-40]
    9df4:	9100001f 	mov	sp, x0
    9df8:	aa1903e0 	mov	x0, x25
    9dfc:	97fff115 	bl	6250 <fwp_closure_drop>
    9e00:	6b13029f 	cmp	w20, w19
    9e04:	54fff381 	b.ne	9c74 <fwp_hof0.constprop.0+0x294>  // b.any
    9e08:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9e0c:	aa1b03f9 	mov	x25, x27
    9e10:	b85c03b8 	ldur	w24, [x29, #-64]
    9e14:	6b17031f 	cmp	w24, w23
    9e18:	540014c3 	b.cc	a0b0 <fwp_hof0.constprop.0+0x6d0>  // b.lo, b.ul, b.last
    9e1c:	f85983a0 	ldur	x0, [x29, #-104]
    9e20:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9e24:	f1000400 	subs	x0, x0, #0x1
    9e28:	f81983a0 	stur	x0, [x29, #-104]
    9e2c:	54ffe5a1 	b.ne	9ae0 <fwp_hof0.constprop.0+0x100>  // b.any
    9e30:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe188>
    9e34:	91104042 	add	x2, x2, #0x410
    9e38:	aa1903e1 	mov	x1, x25
    9e3c:	aa1403e0 	mov	x0, x20
    9e40:	aa1a03f8 	mov	x24, x26
    9e44:	aa1903fb 	mov	x27, x25
    9e48:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9e4c:	91014042 	add	x2, x2, #0x50
    9e50:	52800023 	mov	w3, #0x1                   	// #1
    9e54:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9e58:	f81f03bf 	stur	xzr, [x29, #-16]
    9e5c:	97fffae5 	bl	89f0 <fwp_write>
    9e60:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    9e64:	90000020 	adrp	x0, d000 <fwp_main_thread+0x34c>
    9e68:	91274000 	add	x0, x0, #0x9d0
    9e6c:	f10002df 	cmp	x22, #0x0
    9e70:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9e74:	b1002b3f 	cmn	x25, #0xa
    9e78:	54003cc8 	b.hi	a610 <fwp_hof0.constprop.0+0xc30>  // b.pmore
    9e7c:	91002720 	add	x0, x25, #0x9
    9e80:	52800021 	mov	w1, #0x1                   	// #1
    9e84:	97ffec97 	bl	50e0 <fwp_heap_alloc>
    9e88:	aa0003f3 	mov	x19, x0
    9e8c:	aa1603e1 	mov	x1, x22
    9e90:	aa0003f6 	mov	x22, x0
    9e94:	aa1903e2 	mov	x2, x25
    9e98:	f80086d9 	str	x25, [x22], #8
    9e9c:	8b190279 	add	x25, x19, x25
    9ea0:	aa1603e0 	mov	x0, x22
    9ea4:	97ffe1ef 	bl	2660 <memcpy@plt>
    9ea8:	3900233f 	strb	wzr, [x25, #8]
    9eac:	f85e03a0 	ldur	x0, [x29, #-32]
    9eb0:	97ffe288 	bl	28d0 <free@plt>
    9eb4:	90000380 	adrp	x0, 79000 <fwp_root_context+0xb80>
    9eb8:	91198002 	add	x2, x0, #0x660
    9ebc:	f949d841 	ldr	x1, [x2, #5040]
    9ec0:	f949ec40 	ldr	x0, [x2, #5080]
    9ec4:	cb010261 	sub	x1, x19, x1
    9ec8:	eb00403f 	cmp	x1, x0, lsl #16
    9ecc:	54000322 	b.cs	9f30 <fwp_hof0.constprop.0+0x550>  // b.hs, b.nlast
    9ed0:	d350fc20 	lsr	x0, x1, #16
    9ed4:	f949fc43 	ldr	x3, [x2, #5112]
    9ed8:	8b000800 	add	x0, x0, x0, lsl #2
    9edc:	d37df002 	lsl	x2, x0, #3
    9ee0:	8b020060 	add	x0, x3, x2
    9ee4:	f9401019 	ldr	x25, [x0, #32]
    9ee8:	b4000259 	cbz	x25, 9f30 <fwp_hof0.constprop.0+0x550>
    9eec:	38626862 	ldrb	w2, [x3, x2]
    9ef0:	7100085f 	cmp	w2, #0x2
    9ef4:	54003520 	b.eq	a598 <fwp_hof0.constprop.0+0xbb8>  // b.none
    9ef8:	7100045f 	cmp	w2, #0x1
    9efc:	540001a1 	b.ne	9f30 <fwp_hof0.constprop.0+0x550>  // b.any
    9f00:	29430002 	ldp	w2, w0, [x0, #24]
    9f04:	92403c21 	and	x1, x1, #0xffff
    9f08:	9b027c21 	mul	x1, x1, x2
    9f0c:	d360fc21 	lsr	x1, x1, #32
    9f10:	eb00003f 	cmp	x1, x0
    9f14:	540000e2 	b.cs	9f30 <fwp_hof0.constprop.0+0x550>  // b.hs, b.nlast
    9f18:	8b010339 	add	x25, x25, x1
    9f1c:	39400320 	ldrb	w0, [x25]
    9f20:	7103fc1f 	cmp	w0, #0xff
    9f24:	54003820 	b.eq	a628 <fwp_hof0.constprop.0+0xc48>  // b.none
    9f28:	52800020 	mov	w0, #0x1                   	// #1
    9f2c:	39000320 	strb	w0, [x25]
    9f30:	aa1b03e0 	mov	x0, x27
    9f34:	97fff06b 	bl	60e0 <fwp_drop0>
    9f38:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f3c:	91018003 	add	x3, x0, #0x60
    9f40:	f9400262 	ldr	x2, [x19]
    9f44:	aa1603e0 	mov	x0, x22
    9f48:	aa0303f6 	mov	x22, x3
    9f4c:	d2800021 	mov	x1, #0x1                   	// #1
    9f50:	f9404863 	ldr	x3, [x3, #144]
    9f54:	97ffe26f 	bl	2910 <fwrite@plt>
    9f58:	f9404ac1 	ldr	x1, [x22, #144]
    9f5c:	52800140 	mov	w0, #0xa                   	// #10
    9f60:	97ffe1f4 	bl	2730 <fputc@plt>
    9f64:	90000380 	adrp	x0, 79000 <fwp_root_context+0xb80>
    9f68:	91198002 	add	x2, x0, #0x660
    9f6c:	f949d841 	ldr	x1, [x2, #5040]
    9f70:	f949ec40 	ldr	x0, [x2, #5080]
    9f74:	cb010261 	sub	x1, x19, x1
    9f78:	eb00403f 	cmp	x1, x0, lsl #16
    9f7c:	54000382 	b.cs	9fec <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    9f80:	d350fc20 	lsr	x0, x1, #16
    9f84:	f949fc43 	ldr	x3, [x2, #5112]
    9f88:	8b000800 	add	x0, x0, x0, lsl #2
    9f8c:	d37df000 	lsl	x0, x0, #3
    9f90:	8b000062 	add	x2, x3, x0
    9f94:	f9401056 	ldr	x22, [x2, #32]
    9f98:	b40002b6 	cbz	x22, 9fec <fwp_hof0.constprop.0+0x60c>
    9f9c:	38606860 	ldrb	w0, [x3, x0]
    9fa0:	7100081f 	cmp	w0, #0x2
    9fa4:	54002f40 	b.eq	a58c <fwp_hof0.constprop.0+0xbac>  // b.none
    9fa8:	7100041f 	cmp	w0, #0x1
    9fac:	54000201 	b.ne	9fec <fwp_hof0.constprop.0+0x60c>  // b.any
    9fb0:	29430043 	ldp	w3, w0, [x2, #24]
    9fb4:	92403c21 	and	x1, x1, #0xffff
    9fb8:	9b037c21 	mul	x1, x1, x3
    9fbc:	d360fc21 	lsr	x1, x1, #32
    9fc0:	eb00003f 	cmp	x1, x0
    9fc4:	54000142 	b.cs	9fec <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    9fc8:	8b0102d6 	add	x22, x22, x1
    9fcc:	394002c0 	ldrb	w0, [x22]
    9fd0:	340000e0 	cbz	w0, 9fec <fwp_hof0.constprop.0+0x60c>
    9fd4:	7100041f 	cmp	w0, #0x1
    9fd8:	54002d00 	b.eq	a578 <fwp_hof0.constprop.0+0xb98>  // b.none
    9fdc:	7103fc1f 	cmp	w0, #0xff
    9fe0:	54002e20 	b.eq	a5a4 <fwp_hof0.constprop.0+0xbc4>  // b.none
    9fe4:	51000400 	sub	w0, w0, #0x1
    9fe8:	390002c0 	strb	w0, [x22]
    9fec:	f9400b5a 	ldr	x26, [x26, #16]
    9ff0:	b5ffd27a 	cbnz	x26, 9a3c <fwp_hof0.constprop.0+0x5c>
    9ff4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9ff8:	f947f400 	ldr	x0, [x0, #4072]
    9ffc:	f85f83a2 	ldur	x2, [x29, #-8]
    a000:	f9400001 	ldr	x1, [x0]
    a004:	eb010042 	subs	x2, x2, x1
    a008:	d2800001 	mov	x1, #0x0                   	// #0
    a00c:	540030c1 	b.ne	a624 <fwp_hof0.constprop.0+0xc44>  // b.any
    a010:	910003bf 	mov	sp, x29
    a014:	d2800000 	mov	x0, #0x0                   	// #0
    a018:	a94153f3 	ldp	x19, x20, [sp, #16]
    a01c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a020:	a94363f7 	ldp	x23, x24, [sp, #48]
    a024:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a028:	a94573fb 	ldp	x27, x28, [sp, #80]
    a02c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    a030:	d65f03c0 	ret
    a034:	b90004df 	str	wzr, [x6, #4]
    a038:	17ffff69 	b	9ddc <fwp_hof0.constprop.0+0x3fc>
    a03c:	72003c3f 	tst	w1, #0xffff
    a040:	54ffec61 	b.ne	9dcc <fwp_hof0.constprop.0+0x3ec>  // b.any
    a044:	17ffff5f 	b	9dc0 <fwp_hof0.constprop.0+0x3e0>
    a048:	aa1b03fc 	mov	x28, x27
    a04c:	aa1803fb 	mov	x27, x24
    a050:	29771fb7 	ldp	w23, w7, [x29, #-72]
    a054:	b85c03b8 	ldur	w24, [x29, #-64]
    a058:	aa1c03e0 	mov	x0, x28
    a05c:	b81d83a7 	stur	w7, [x29, #-40]
    a060:	97ffee99 	bl	5ac4 <fwp_rc_share>
    a064:	b85d83a7 	ldur	w7, [x29, #-40]
    a068:	34000134 	cbz	w20, a08c <fwp_hof0.constprop.0+0x6ac>
    a06c:	aa1b03f6 	mov	x22, x27
    a070:	8b344f73 	add	x19, x27, w20, uxtw #3
    a074:	2a0703f9 	mov	w25, w7
    a078:	f84086c0 	ldr	x0, [x22], #8
    a07c:	97ffee92 	bl	5ac4 <fwp_rc_share>
    a080:	eb16027f 	cmp	x19, x22
    a084:	54ffffa1 	b.ne	a078 <fwp_hof0.constprop.0+0x698>  // b.any
    a088:	2a1903e7 	mov	w7, w25
    a08c:	aa1b03e2 	mov	x2, x27
    a090:	2a1403e1 	mov	w1, w20
    a094:	aa1c03e0 	mov	x0, x28
    a098:	b81d83a7 	stur	w7, [x29, #-40]
    a09c:	97ffec72 	bl	5264 <fwp_apply>
    a0a0:	aa0003f9 	mov	x25, x0
    a0a4:	b85d83a7 	ldur	w7, [x29, #-40]
    a0a8:	6b17031f 	cmp	w24, w23
    a0ac:	54ffeb82 	b.cs	9e1c <fwp_hof0.constprop.0+0x43c>  // b.hs, b.nlast
    a0b0:	f9406aa1 	ldr	x1, [x21, #208]
    a0b4:	4b0702f7 	sub	w23, w23, w7
    a0b8:	b9400323 	ldr	w3, [x25]
    a0bc:	f85d03a0 	ldur	x0, [x29, #-48]
    a0c0:	8b031423 	add	x3, x1, x3, lsl #5
    a0c4:	b85c83a2 	ldur	w2, [x29, #-56]
    a0c8:	8b274c00 	add	x0, x0, w7, uxtw #3
    a0cc:	f81d03a0 	stur	x0, [x29, #-48]
    a0d0:	f9400c61 	ldr	x1, [x3, #24]
    a0d4:	b85cc3a0 	ldur	w0, [x29, #-52]
    a0d8:	4b020000 	sub	w0, w0, w2
    a0dc:	b81cc3a0 	stur	w0, [x29, #-52]
    a0e0:	aa1903e0 	mov	x0, x25
    a0e4:	b5ffd741 	cbnz	x1, 9bcc <fwp_hof0.constprop.0+0x1ec>
    a0e8:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    a0ec:	aa1903e0 	mov	x0, x25
    a0f0:	97ffee75 	bl	5ac4 <fwp_rc_share>
    a0f4:	34000117 	cbz	w23, a114 <fwp_hof0.constprop.0+0x734>
    a0f8:	f85d03b8 	ldur	x24, [x29, #-48]
    a0fc:	d2800016 	mov	x22, #0x0                   	// #0
    a100:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    a104:	910006d6 	add	x22, x22, #0x1
    a108:	97ffee6f 	bl	5ac4 <fwp_rc_share>
    a10c:	6b1602ff 	cmp	w23, w22
    a110:	54ffff88 	b.hi	a100 <fwp_hof0.constprop.0+0x720>  // b.pmore
    a114:	f85d03a2 	ldur	x2, [x29, #-48]
    a118:	aa1903e0 	mov	x0, x25
    a11c:	2a1703e1 	mov	w1, w23
    a120:	97ffec51 	bl	5264 <fwp_apply>
    a124:	aa0003f9 	mov	x25, x0
    a128:	f85983a0 	ldur	x0, [x29, #-104]
    a12c:	f1000400 	subs	x0, x0, #0x1
    a130:	f81983a0 	stur	x0, [x29, #-104]
    a134:	54ffcd61 	b.ne	9ae0 <fwp_hof0.constprop.0+0x100>  // b.any
    a138:	17ffff3e 	b	9e30 <fwp_hof0.constprop.0+0x450>
    a13c:	b94152ab 	ldr	w11, [x21, #336]
    a140:	110006c0 	add	w0, w22, #0x1
    a144:	aa1703fa 	mov	x26, x23
    a148:	aa1803fb 	mov	x27, x24
    a14c:	29771fb7 	ldp	w23, w7, [x29, #-72]
    a150:	2a0103fc 	mov	w28, w1
    a154:	b85c03b8 	ldur	w24, [x29, #-64]
    a158:	d37df000 	lsl	x0, x0, #3
    a15c:	340000ab 	cbz	w11, a170 <fwp_hof0.constprop.0+0x790>
    a160:	a95586a9 	ldp	x9, x1, [x21, #344]
    a164:	91000529 	add	x9, x9, #0x1
    a168:	8b000021 	add	x1, x1, x0
    a16c:	a91586a9 	stp	x9, x1, [x21, #344]
    a170:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xb80>
    a174:	9119802a 	add	x10, x1, #0x660
    a178:	f140101f 	cmp	x0, #0x4, lsl #12
    a17c:	b953a541 	ldr	w1, [x10, #5028]
    a180:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a184:	540019a0 	b.eq	a4b8 <fwp_hof0.constprop.0+0xad8>  // b.none
    a188:	91003c01 	add	x1, x0, #0xf
    a18c:	8b411141 	add	x1, x10, x1, lsr #4
    a190:	397e8021 	ldrb	w1, [x1, #4000]
    a194:	910f002c 	add	x12, x1, #0x3c0
    a198:	8b010429 	add	x9, x1, x1, lsl #1
    a19c:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    a1a0:	8b090d4d 	add	x13, x10, x9, lsl #3
    a1a4:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    a1a8:	2a0c03e1 	mov	w1, w12
    a1ac:	b4001753 	cbz	x19, a494 <fwp_hof0.constprop.0+0xab4>
    a1b0:	f940026d 	ldr	x13, [x19]
    a1b4:	aa2d03ed 	mvn	x13, x13
    a1b8:	f829794d 	str	x13, [x10, x9, lsl #3]
    a1bc:	eb01001f 	cmp	x0, x1
    a1c0:	540000c2 	b.cs	a1d8 <fwp_hof0.constprop.0+0x7f8>  // b.hs, b.nlast
    a1c4:	d503201f 	nop
    a1c8:	f8206a7f 	str	xzr, [x19, x0]
    a1cc:	91002000 	add	x0, x0, #0x8
    a1d0:	eb00003f 	cmp	x1, x0
    a1d4:	54ffffa8 	b.hi	a1c8 <fwp_hof0.constprop.0+0x7e8>  // b.pmore
    a1d8:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    a1dc:	91198009 	add	x9, x0, #0x660
    a1e0:	f94a1120 	ldr	x0, [x9, #5152]
    a1e4:	ab010000 	adds	x0, x0, x1
    a1e8:	540020c2 	b.cs	a600 <fwp_hof0.constprop.0+0xc20>  // b.hs, b.nlast
    a1ec:	f94a1521 	ldr	x1, [x9, #5160]
    a1f0:	f90a1120 	str	x0, [x9, #5152]
    a1f4:	eb01001f 	cmp	x0, x1
    a1f8:	54000049 	b.ls	a200 <fwp_hof0.constprop.0+0x820>  // b.plast
    a1fc:	f90a1520 	str	x0, [x9, #5160]
    a200:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    a204:	91198000 	add	x0, x0, #0x660
    a208:	1e630181 	ucvtf	d1, w12
    a20c:	fd4a1c00 	ldr	d0, [x0, #5176]
    a210:	1e612800 	fadd	d0, d0, d1
    a214:	fd0a1c00 	str	d0, [x0, #5176]
    a218:	3400012b 	cbz	w11, a23c <fwp_hof0.constprop.0+0x85c>
    a21c:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    a220:	91198000 	add	x0, x0, #0x660
    a224:	6d5686a2 	ldp	d2, d1, [x21, #360]
    a228:	fd4a1000 	ldr	d0, [x0, #5152]
    a22c:	7e61d800 	ucvtf	d0, d0
    a230:	1e623800 	fsub	d0, d0, d2
    a234:	1e612010 	fcmpe	d0, d1
    a238:	540016ec 	b.gt	a514 <fwp_hof0.constprop.0+0xb34>
    a23c:	b94000c0 	ldr	w0, [x6]
    a240:	29005a60 	stp	w0, w22, [x19]
    a244:	3400013c 	cbz	w28, a268 <fwp_hof0.constprop.0+0x888>
    a248:	910020c1 	add	x1, x6, #0x8
    a24c:	d37d7f82 	ubfiz	x2, x28, #3, #32
    a250:	91002260 	add	x0, x19, #0x8
    a254:	b81c03a7 	stur	w7, [x29, #-64]
    a258:	f81d83a6 	stur	x6, [x29, #-40]
    a25c:	97ffe109 	bl	2680 <memmove@plt>
    a260:	f85d83a6 	ldur	x6, [x29, #-40]
    a264:	b85c03a7 	ldur	w7, [x29, #-64]
    a268:	2a1403e9 	mov	w9, w20
    a26c:	d2800001 	mov	x1, #0x0                   	// #0
    a270:	34000134 	cbz	w20, a294 <fwp_hof0.constprop.0+0x8b4>
    a274:	d503201f 	nop
    a278:	0b010380 	add	w0, w28, w1
    a27c:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    a280:	8b000e60 	add	x0, x19, x0, lsl #3
    a284:	91000421 	add	x1, x1, #0x1
    a288:	f9000402 	str	x2, [x0, #8]
    a28c:	eb01013f 	cmp	x9, x1
    a290:	54ffff41 	b.ne	a278 <fwp_hof0.constprop.0+0x898>  // b.any
    a294:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    a298:	91198002 	add	x2, x0, #0x660
    a29c:	f949d840 	ldr	x0, [x2, #5040]
    a2a0:	f949ec41 	ldr	x1, [x2, #5080]
    a2a4:	cb000320 	sub	x0, x25, x0
    a2a8:	eb01401f 	cmp	x0, x1, lsl #16
    a2ac:	540002e2 	b.cs	a308 <fwp_hof0.constprop.0+0x928>  // b.hs, b.nlast
    a2b0:	d350fc01 	lsr	x1, x0, #16
    a2b4:	f949fc45 	ldr	x5, [x2, #5112]
    a2b8:	8b010821 	add	x1, x1, x1, lsl #2
    a2bc:	d37df021 	lsl	x1, x1, #3
    a2c0:	8b0100a4 	add	x4, x5, x1
    a2c4:	f9401082 	ldr	x2, [x4, #32]
    a2c8:	b4000202 	cbz	x2, a308 <fwp_hof0.constprop.0+0x928>
    a2cc:	386168a1 	ldrb	w1, [x5, x1]
    a2d0:	7100083f 	cmp	w1, #0x2
    a2d4:	54001060 	b.eq	a4e0 <fwp_hof0.constprop.0+0xb00>  // b.none
    a2d8:	7100043f 	cmp	w1, #0x1
    a2dc:	54000161 	b.ne	a308 <fwp_hof0.constprop.0+0x928>  // b.any
    a2e0:	29430485 	ldp	w5, w1, [x4, #24]
    a2e4:	92403c00 	and	x0, x0, #0xffff
    a2e8:	9b057c00 	mul	x0, x0, x5
    a2ec:	d360fc00 	lsr	x0, x0, #32
    a2f0:	eb01001f 	cmp	x0, x1
    a2f4:	540000a2 	b.cs	a308 <fwp_hof0.constprop.0+0x928>  // b.hs, b.nlast
    a2f8:	8b000042 	add	x2, x2, x0
    a2fc:	39400040 	ldrb	w0, [x2]
    a300:	7100041f 	cmp	w0, #0x1
    a304:	54000be0 	b.eq	a480 <fwp_hof0.constprop.0+0xaa0>  // b.none
    a308:	f9400f42 	ldr	x2, [x26, #24]
    a30c:	aa1903e0 	mov	x0, x25
    a310:	52800021 	mov	w1, #0x1                   	// #1
    a314:	b81d83a7 	stur	w7, [x29, #-40]
    a318:	f9400442 	ldr	x2, [x2, #8]
    a31c:	d63f0040 	blr	x2
    a320:	b85d83a7 	ldur	w7, [x29, #-40]
    a324:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xb80>
    a328:	91198002 	add	x2, x0, #0x660
    a32c:	f949d841 	ldr	x1, [x2, #5040]
    a330:	f949ec40 	ldr	x0, [x2, #5080]
    a334:	cb010261 	sub	x1, x19, x1
    a338:	eb00403f 	cmp	x1, x0, lsl #16
    a33c:	54000322 	b.cs	a3a0 <fwp_hof0.constprop.0+0x9c0>  // b.hs, b.nlast
    a340:	d350fc20 	lsr	x0, x1, #16
    a344:	f949fc43 	ldr	x3, [x2, #5112]
    a348:	8b000800 	add	x0, x0, x0, lsl #2
    a34c:	d37df002 	lsl	x2, x0, #3
    a350:	8b020060 	add	x0, x3, x2
    a354:	f9401014 	ldr	x20, [x0, #32]
    a358:	b4000254 	cbz	x20, a3a0 <fwp_hof0.constprop.0+0x9c0>
    a35c:	38626862 	ldrb	w2, [x3, x2]
    a360:	7100085f 	cmp	w2, #0x2
    a364:	54000c40 	b.eq	a4ec <fwp_hof0.constprop.0+0xb0c>  // b.none
    a368:	7100045f 	cmp	w2, #0x1
    a36c:	540001a1 	b.ne	a3a0 <fwp_hof0.constprop.0+0x9c0>  // b.any
    a370:	29430002 	ldp	w2, w0, [x0, #24]
    a374:	92403c21 	and	x1, x1, #0xffff
    a378:	9b027c21 	mul	x1, x1, x2
    a37c:	d360fc21 	lsr	x1, x1, #32
    a380:	eb00003f 	cmp	x1, x0
    a384:	540000e2 	b.cs	a3a0 <fwp_hof0.constprop.0+0x9c0>  // b.hs, b.nlast
    a388:	8b010294 	add	x20, x20, x1
    a38c:	39400280 	ldrb	w0, [x20]
    a390:	7103fc1f 	cmp	w0, #0xff
    a394:	54000b60 	b.eq	a500 <fwp_hof0.constprop.0+0xb20>  // b.none
    a398:	52800020 	mov	w0, #0x1                   	// #1
    a39c:	39000280 	strb	w0, [x20]
    a3a0:	aa1903e0 	mov	x0, x25
    a3a4:	b81d83a7 	stur	w7, [x29, #-40]
    a3a8:	97ffefaa 	bl	6250 <fwp_closure_drop>
    a3ac:	aa1303f9 	mov	x25, x19
    a3b0:	b85d83a7 	ldur	w7, [x29, #-40]
    a3b4:	17ffff3d 	b	a0a8 <fwp_hof0.constprop.0+0x6c8>
    a3b8:	b8626860 	ldr	w0, [x3, x2]
    a3bc:	b94004a2 	ldr	w2, [x5, #4]
    a3c0:	4b020003 	sub	w3, w0, w2
    a3c4:	7100047f 	cmp	w3, #0x1
    a3c8:	54ffba41 	b.ne	9b10 <fwp_hof0.constprop.0+0x130>  // b.any
    a3cc:	910003f6 	mov	x22, sp
    a3d0:	34000aa2 	cbz	w2, a524 <fwp_hof0.constprop.0+0xb44>
    a3d4:	7100001f 	cmp	w0, #0x0
    a3d8:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a3dc:	d2800101 	mov	x1, #0x8                   	// #8
    a3e0:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a3e4:	91003ee0 	add	x0, x23, #0xf
    a3e8:	92704c01 	and	x1, x0, #0xfffff0000
    a3ec:	927c7c00 	and	x0, x0, #0xffffffff0
    a3f0:	cb2163e1 	sub	x1, sp, x1
    a3f4:	eb2163ff 	cmp	sp, x1
    a3f8:	540000a0 	b.eq	a40c <fwp_hof0.constprop.0+0xa2c>  // b.none
    a3fc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a400:	f90203ff 	str	xzr, [sp, #1024]
    a404:	eb2163ff 	cmp	sp, x1
    a408:	54ffffa1 	b.ne	a3fc <fwp_hof0.constprop.0+0xa1c>  // b.any
    a40c:	92403c00 	and	x0, x0, #0xffff
    a410:	cb2063ff 	sub	sp, sp, x0
    a414:	f90003ff 	str	xzr, [sp]
    a418:	f110001f 	cmp	x0, #0x400
    a41c:	54000043 	b.cc	a424 <fwp_hof0.constprop.0+0xa44>  // b.lo, b.ul, b.last
    a420:	f90203ff 	str	xzr, [sp, #1024]
    a424:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    a428:	910043f8 	add	x24, sp, #0x10
    a42c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a430:	91004001 	add	x1, x0, #0x10
    a434:	aa1c03e2 	mov	x2, x28
    a438:	9100c021 	add	x1, x1, #0x30
    a43c:	aa1703e3 	mov	x3, x23
    a440:	aa1803e0 	mov	x0, x24
    a444:	97ffe0c7 	bl	2760 <__memcpy_chk@plt>
    a448:	eb1c02ff 	cmp	x23, x28
    a44c:	aa1403e1 	mov	x1, x20
    a450:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    a454:	d2800102 	mov	x2, #0x8                   	// #8
    a458:	cb1c0063 	sub	x3, x3, x28
    a45c:	8b1c0300 	add	x0, x24, x28
    a460:	97ffe0c0 	bl	2760 <__memcpy_chk@plt>
    a464:	f9400f61 	ldr	x1, [x27, #24]
    a468:	aa1803e0 	mov	x0, x24
    a46c:	f9400021 	ldr	x1, [x1]
    a470:	d63f0020 	blr	x1
    a474:	aa0003f9 	mov	x25, x0
    a478:	910002df 	mov	sp, x22
    a47c:	17ffff2b 	b	a128 <fwp_hof0.constprop.0+0x748>
    a480:	b90004df 	str	wzr, [x6, #4]
    a484:	17ffffa8 	b	a324 <fwp_hof0.constprop.0+0x944>
    a488:	72003c3f 	tst	w1, #0xffff
    a48c:	54ffb8c1 	b.ne	9ba4 <fwp_hof0.constprop.0+0x1c4>  // b.any
    a490:	17fffdba 	b	9b78 <fwp_hof0.constprop.0+0x198>
    a494:	f94005b3 	ldr	x19, [x13, #8]
    a498:	b4000113 	cbz	x19, a4b8 <fwp_hof0.constprop.0+0xad8>
    a49c:	f94009a9 	ldr	x9, [x13, #16]
    a4a0:	cb130129 	sub	x9, x9, x19
    a4a4:	eb09003f 	cmp	x1, x9
    a4a8:	54000088 	b.hi	a4b8 <fwp_hof0.constprop.0+0xad8>  // b.pmore
    a4ac:	8b010269 	add	x9, x19, x1
    a4b0:	f90005a9 	str	x9, [x13, #8]
    a4b4:	17ffff42 	b	a1bc <fwp_hof0.constprop.0+0x7dc>
    a4b8:	52800001 	mov	w1, #0x0                   	// #0
    a4bc:	b81bc3ab 	stur	w11, [x29, #-68]
    a4c0:	f81c03a6 	stur	x6, [x29, #-64]
    a4c4:	b81d83a7 	stur	w7, [x29, #-40]
    a4c8:	97ffeb06 	bl	50e0 <fwp_heap_alloc>
    a4cc:	f85c03a6 	ldur	x6, [x29, #-64]
    a4d0:	aa0003f3 	mov	x19, x0
    a4d4:	b85bc3ab 	ldur	w11, [x29, #-68]
    a4d8:	b85d83a7 	ldur	w7, [x29, #-40]
    a4dc:	17ffff4f 	b	a218 <fwp_hof0.constprop.0+0x838>
    a4e0:	72003c1f 	tst	w0, #0xffff
    a4e4:	54fff121 	b.ne	a308 <fwp_hof0.constprop.0+0x928>  // b.any
    a4e8:	17ffff85 	b	a2fc <fwp_hof0.constprop.0+0x91c>
    a4ec:	72003c3f 	tst	w1, #0xffff
    a4f0:	54fff581 	b.ne	a3a0 <fwp_hof0.constprop.0+0x9c0>  // b.any
    a4f4:	39400280 	ldrb	w0, [x20]
    a4f8:	7103fc1f 	cmp	w0, #0xff
    a4fc:	54fff4e1 	b.ne	a398 <fwp_hof0.constprop.0+0x9b8>  // b.any
    a500:	aa1403e0 	mov	x0, x20
    a504:	b81d83a7 	stur	w7, [x29, #-40]
    a508:	97ffe936 	bl	49e0 <fwp_rc_forget_slot>
    a50c:	b85d83a7 	ldur	w7, [x29, #-40]
    a510:	17ffffa2 	b	a398 <fwp_hof0.constprop.0+0x9b8>
    a514:	fd00baa0 	str	d0, [x21, #368]
    a518:	17ffff49 	b	a23c <fwp_hof0.constprop.0+0x85c>
    a51c:	97ffe8ea 	bl	48c4 <fwp_rc_wide_dup>
    a520:	17fffda1 	b	9ba4 <fwp_hof0.constprop.0+0x1c4>
    a524:	f9400021 	ldr	x1, [x1]
    a528:	aa1403e0 	mov	x0, x20
    a52c:	d63f0020 	blr	x1
    a530:	aa0003f9 	mov	x25, x0
    a534:	910002df 	mov	sp, x22
    a538:	17fffefc 	b	a128 <fwp_hof0.constprop.0+0x748>
    a53c:	72003c3f 	tst	w1, #0xffff
    a540:	54ffac61 	b.ne	9acc <fwp_hof0.constprop.0+0xec>  // b.any
    a544:	17fffd58 	b	9aa4 <fwp_hof0.constprop.0+0xc4>
    a548:	aa1a03e0 	mov	x0, x26
    a54c:	97ffed5e 	bl	5ac4 <fwp_rc_share>
    a550:	aa1903e0 	mov	x0, x25
    a554:	52800037 	mov	w23, #0x1                   	// #1
    a558:	97ffed5b 	bl	5ac4 <fwp_rc_share>
    a55c:	aa1a03f9 	mov	x25, x26
    a560:	f81d03b4 	stur	x20, [x29, #-48]
    a564:	17fffeec 	b	a114 <fwp_hof0.constprop.0+0x734>
    a568:	f940bc43 	ldr	x3, [x2, #376]
    a56c:	91000463 	add	x3, x3, #0x1
    a570:	f900bc43 	str	x3, [x2, #376]
    a574:	17fffd52 	b	9abc <fwp_hof0.constprop.0+0xdc>
    a578:	aa1303e0 	mov	x0, x19
    a57c:	97ffeda9 	bl	5c20 <fwp_rc_free_arr>
    a580:	f9400b5a 	ldr	x26, [x26, #16]
    a584:	b5ffa5da 	cbnz	x26, 9a3c <fwp_hof0.constprop.0+0x5c>
    a588:	17fffe9b 	b	9ff4 <fwp_hof0.constprop.0+0x614>
    a58c:	72003c3f 	tst	w1, #0xffff
    a590:	54ffd2e1 	b.ne	9fec <fwp_hof0.constprop.0+0x60c>  // b.any
    a594:	17fffe8e 	b	9fcc <fwp_hof0.constprop.0+0x5ec>
    a598:	72003c3f 	tst	w1, #0xffff
    a59c:	54ffcca1 	b.ne	9f30 <fwp_hof0.constprop.0+0x550>  // b.any
    a5a0:	17fffe5f 	b	9f1c <fwp_hof0.constprop.0+0x53c>
    a5a4:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a5a8:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xb80>
    a5ac:	91198021 	add	x1, x1, #0x660
    a5b0:	ca402400 	eor	x0, x0, x0, lsr #9
    a5b4:	8b200c20 	add	x0, x1, w0, uxtb #3
    a5b8:	f94a2400 	ldr	x0, [x0, #5192]
    a5bc:	b5000080 	cbnz	x0, a5cc <fwp_hof0.constprop.0+0xbec>
    a5c0:	14000011 	b	a604 <fwp_hof0.constprop.0+0xc24>
    a5c4:	f9400800 	ldr	x0, [x0, #16]
    a5c8:	b40001e0 	cbz	x0, a604 <fwp_hof0.constprop.0+0xc24>
    a5cc:	f9400001 	ldr	x1, [x0]
    a5d0:	eb16003f 	cmp	x1, x22
    a5d4:	54ffff81 	b.ne	a5c4 <fwp_hof0.constprop.0+0xbe4>  // b.any
    a5d8:	f9400401 	ldr	x1, [x0, #8]
    a5dc:	d1000421 	sub	x1, x1, #0x1
    a5e0:	f9000401 	str	x1, [x0, #8]
    a5e4:	f103f83f 	cmp	x1, #0xfe
    a5e8:	54ffd021 	b.ne	9fec <fwp_hof0.constprop.0+0x60c>  // b.any
    a5ec:	aa1603e0 	mov	x0, x22
    a5f0:	97ffe8fc 	bl	49e0 <fwp_rc_forget_slot>
    a5f4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a5f8:	390002c0 	strb	w0, [x22]
    a5fc:	17fffe7c 	b	9fec <fwp_hof0.constprop.0+0x60c>
    a600:	97ffe2bc 	bl	30f0 <fwp_heap_oom>
    a604:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x34c>
    a608:	91394000 	add	x0, x0, #0xe50
    a60c:	97ffe45d 	bl	3780 <fwp_trap>
    a610:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x670>
    a614:	9105a000 	add	x0, x0, #0x168
    a618:	97ffe45a 	bl	3780 <fwp_trap>
    a61c:	97ffe8aa 	bl	48c4 <fwp_rc_wide_dup>
    a620:	17fffd2b 	b	9acc <fwp_hof0.constprop.0+0xec>
    a624:	97ffe07b 	bl	2810 <__stack_chk_fail@plt>
    a628:	aa1903e0 	mov	x0, x25
    a62c:	97ffe8ed 	bl	49e0 <fwp_rc_forget_slot>
    a630:	17fffe3e 	b	9f28 <fwp_hof0.constprop.0+0x548>

000000000000a634 <f0>:
    a634:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a638:	910003fd 	mov	x29, sp
    a63c:	a90153f3 	stp	x19, x20, [sp, #16]
    a640:	a9025bf5 	stp	x21, x22, [sp, #32]
    a644:	a90363f7 	stp	x23, x24, [sp, #48]
    a648:	a9046bf9 	stp	x25, x26, [sp, #64]
    a64c:	a90573fb 	stp	x27, x28, [sp, #80]
    a650:	d12183ff 	sub	sp, sp, #0x860
    a654:	f90203ff 	str	xzr, [sp, #1024]
    a658:	d00000a0 	adrp	x0, 20000 <__data_start>
    a65c:	91018005 	add	x5, x0, #0x60
    a660:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    a664:	f947f400 	ldr	x0, [x0, #4072]
    a668:	f0000374 	adrp	x20, 79000 <fwp_root_context+0xb80>
    a66c:	f941d8a6 	ldr	x6, [x5, #944]
    a670:	f9400001 	ldr	x1, [x0]
    a674:	f9042fe1 	str	x1, [sp, #2136]
    a678:	d2800001 	mov	x1, #0x0                   	// #0
    a67c:	91198298 	add	x24, x20, #0x660
    a680:	912123f6 	add	x22, sp, #0x848
    a684:	910023e0 	add	x0, sp, #0x8
    a688:	910083e2 	add	x2, sp, #0x20
    a68c:	f0ffffc1 	adrp	x1, 5000 <fwp_heap_alloc_slow+0x80>
    a690:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a694:	913e4021 	add	x1, x1, #0xf90
    a698:	913b4084 	add	x4, x4, #0xed0
    a69c:	d2800013 	mov	x19, #0x0                   	// #0
    a6a0:	d2800119 	mov	x25, #0x8                   	// #8
    a6a4:	d2800015 	mov	x21, #0x0                   	// #0
    a6a8:	52800037 	mov	w23, #0x1                   	// #1
    a6ac:	a90093e6 	stp	x6, x4, [sp, #8]
    a6b0:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a6b4:	a90307ff 	stp	xzr, x1, [sp, #48]
    a6b8:	f901d8a0 	str	x0, [x5, #944]
    a6bc:	d503201f 	nop
    a6c0:	f100073a 	subs	x26, x25, #0x1
    a6c4:	aa1603e1 	mov	x1, x22
    a6c8:	da1f02bc 	sbc	x28, x21, xzr
    a6cc:	52800020 	mov	w0, #0x1                   	// #1
    a6d0:	f90017fa 	str	x26, [sp, #40]
    a6d4:	aa1a03f9 	mov	x25, x26
    a6d8:	f90427fa 	str	x26, [sp, #2120]
    a6dc:	aa1c03f5 	mov	x21, x28
    a6e0:	f9042bf3 	str	x19, [sp, #2128]
    a6e4:	97ffec9b 	bl	5950 <fwp_data.part.0.constprop.0>
    a6e8:	f949db02 	ldr	x2, [x24, #5040]
    a6ec:	aa0003f3 	mov	x19, x0
    a6f0:	f949ef00 	ldr	x0, [x24, #5080]
    a6f4:	cb020262 	sub	x2, x19, x2
    a6f8:	eb00405f 	cmp	x2, x0, lsl #16
    a6fc:	54000302 	b.cs	a75c <f0+0x128>  // b.hs, b.nlast
    a700:	d350fc40 	lsr	x0, x2, #16
    a704:	f949ff04 	ldr	x4, [x24, #5112]
    a708:	8b000800 	add	x0, x0, x0, lsl #2
    a70c:	d37df001 	lsl	x1, x0, #3
    a710:	8b010080 	add	x0, x4, x1
    a714:	f940101b 	ldr	x27, [x0, #32]
    a718:	b400023b 	cbz	x27, a75c <f0+0x128>
    a71c:	38616881 	ldrb	w1, [x4, x1]
    a720:	7100083f 	cmp	w1, #0x2
    a724:	54010ec0 	b.eq	c8fc <f0+0x22c8>  // b.none
    a728:	7100043f 	cmp	w1, #0x1
    a72c:	54000181 	b.ne	a75c <f0+0x128>  // b.any
    a730:	29430001 	ldp	w1, w0, [x0, #24]
    a734:	92403c42 	and	x2, x2, #0xffff
    a738:	9b017c42 	mul	x2, x2, x1
    a73c:	d360fc42 	lsr	x2, x2, #32
    a740:	eb00005f 	cmp	x2, x0
    a744:	540000c2 	b.cs	a75c <f0+0x128>  // b.hs, b.nlast
    a748:	8b02037b 	add	x27, x27, x2
    a74c:	39400360 	ldrb	w0, [x27]
    a750:	7103fc1f 	cmp	w0, #0xff
    a754:	54010ce0 	b.eq	c8f0 <f0+0x22bc>  // b.none
    a758:	39000377 	strb	w23, [x27]
    a75c:	f90013f3 	str	x19, [sp, #32]
    a760:	aa1c035a 	orr	x26, x26, x28
    a764:	b5fffafa 	cbnz	x26, a6c0 <f0+0x8c>
    a768:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x670>
    a76c:	910103e1 	add	x1, sp, #0x40
    a770:	f94007e2 	ldr	x2, [sp, #8]
    a774:	d00000a0 	adrp	x0, 20000 <__data_start>
    a778:	3dc25460 	ldr	q0, [x3, #2384]
    a77c:	91018018 	add	x24, x0, #0x60
    a780:	52800020 	mov	w0, #0x1                   	// #1
    a784:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a788:	3d8013e0 	str	q0, [sp, #64]
    a78c:	f901db02 	str	x2, [x24, #944]
    a790:	97ffec70 	bl	5950 <fwp_data.part.0.constprop.0>
    a794:	97ffecf3 	bl	5b60 <fwp_rc_fresh>
    a798:	aa0003e2 	mov	x2, x0
    a79c:	910163e1 	add	x1, sp, #0x58
    a7a0:	52800020 	mov	w0, #0x1                   	// #1
    a7a4:	a9058bf5 	stp	x21, x2, [sp, #88]
    a7a8:	97ffec6a 	bl	5950 <fwp_data.part.0.constprop.0>
    a7ac:	97ffeced 	bl	5b60 <fwp_rc_fresh>
    a7b0:	aa0003e2 	mov	x2, x0
    a7b4:	9101a3e1 	add	x1, sp, #0x68
    a7b8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a7bc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a7c0:	52800020 	mov	w0, #0x1                   	// #1
    a7c4:	a9068be3 	stp	x3, x2, [sp, #104]
    a7c8:	97ffec62 	bl	5950 <fwp_data.part.0.constprop.0>
    a7cc:	97ffece5 	bl	5b60 <fwp_rc_fresh>
    a7d0:	aa0003e2 	mov	x2, x0
    a7d4:	9101e3e1 	add	x1, sp, #0x78
    a7d8:	52800020 	mov	w0, #0x1                   	// #1
    a7dc:	a9078bf5 	stp	x21, x2, [sp, #120]
    a7e0:	97ffec5c 	bl	5950 <fwp_data.part.0.constprop.0>
    a7e4:	97ffecdf 	bl	5b60 <fwp_rc_fresh>
    a7e8:	aa0003e2 	mov	x2, x0
    a7ec:	910223e1 	add	x1, sp, #0x88
    a7f0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a7f4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a7f8:	52800020 	mov	w0, #0x1                   	// #1
    a7fc:	a9088be3 	stp	x3, x2, [sp, #136]
    a800:	97ffec54 	bl	5950 <fwp_data.part.0.constprop.0>
    a804:	97ffecd7 	bl	5b60 <fwp_rc_fresh>
    a808:	aa0003e2 	mov	x2, x0
    a80c:	910263e1 	add	x1, sp, #0x98
    a810:	52800020 	mov	w0, #0x1                   	// #1
    a814:	a9098bf5 	stp	x21, x2, [sp, #152]
    a818:	97ffec4e 	bl	5950 <fwp_data.part.0.constprop.0>
    a81c:	97ffecd1 	bl	5b60 <fwp_rc_fresh>
    a820:	aa0003e2 	mov	x2, x0
    a824:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a828:	9102a3e1 	add	x1, sp, #0xa8
    a82c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a830:	52800020 	mov	w0, #0x1                   	// #1
    a834:	a90a8be3 	stp	x3, x2, [sp, #168]
    a838:	97ffec46 	bl	5950 <fwp_data.part.0.constprop.0>
    a83c:	91198283 	add	x3, x20, #0x660
    a840:	aa0003f5 	mov	x21, x0
    a844:	f949d861 	ldr	x1, [x3, #5040]
    a848:	f949ec60 	ldr	x0, [x3, #5080]
    a84c:	cb0102a1 	sub	x1, x21, x1
    a850:	eb00403f 	cmp	x1, x0, lsl #16
    a854:	54000322 	b.cs	a8b8 <f0+0x284>  // b.hs, b.nlast
    a858:	d350fc22 	lsr	x2, x1, #16
    a85c:	f949fc63 	ldr	x3, [x3, #5112]
    a860:	8b020842 	add	x2, x2, x2, lsl #2
    a864:	d37df042 	lsl	x2, x2, #3
    a868:	8b020060 	add	x0, x3, x2
    a86c:	f9401017 	ldr	x23, [x0, #32]
    a870:	b4000257 	cbz	x23, a8b8 <f0+0x284>
    a874:	38626862 	ldrb	w2, [x3, x2]
    a878:	7100085f 	cmp	w2, #0x2
    a87c:	54010820 	b.eq	c980 <f0+0x234c>  // b.none
    a880:	7100045f 	cmp	w2, #0x1
    a884:	540001a1 	b.ne	a8b8 <f0+0x284>  // b.any
    a888:	29430002 	ldp	w2, w0, [x0, #24]
    a88c:	92403c21 	and	x1, x1, #0xffff
    a890:	9b027c21 	mul	x1, x1, x2
    a894:	d360fc21 	lsr	x1, x1, #32
    a898:	eb00003f 	cmp	x1, x0
    a89c:	540000e2 	b.cs	a8b8 <f0+0x284>  // b.hs, b.nlast
    a8a0:	8b0102f7 	add	x23, x23, x1
    a8a4:	394002e0 	ldrb	w0, [x23]
    a8a8:	7103fc1f 	cmp	w0, #0xff
    a8ac:	540111e0 	b.eq	cae8 <f0+0x24b4>  // b.none
    a8b0:	52800020 	mov	w0, #0x1                   	// #1
    a8b4:	390002e0 	strb	w0, [x23]
    a8b8:	9102e3e1 	add	x1, sp, #0xb8
    a8bc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a8c0:	52800020 	mov	w0, #0x1                   	// #1
    a8c4:	a90bd7f7 	stp	x23, x21, [sp, #184]
    a8c8:	97ffec22 	bl	5950 <fwp_data.part.0.constprop.0>
    a8cc:	97ffeca5 	bl	5b60 <fwp_rc_fresh>
    a8d0:	aa0003e2 	mov	x2, x0
    a8d4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a8d8:	910323e1 	add	x1, sp, #0xc8
    a8dc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a8e0:	52800020 	mov	w0, #0x1                   	// #1
    a8e4:	a90c8be3 	stp	x3, x2, [sp, #200]
    a8e8:	97ffec1a 	bl	5950 <fwp_data.part.0.constprop.0>
    a8ec:	97ffec9d 	bl	5b60 <fwp_rc_fresh>
    a8f0:	aa0003e2 	mov	x2, x0
    a8f4:	910363e1 	add	x1, sp, #0xd8
    a8f8:	52800020 	mov	w0, #0x1                   	// #1
    a8fc:	a90d8bf7 	stp	x23, x2, [sp, #216]
    a900:	97ffec14 	bl	5950 <fwp_data.part.0.constprop.0>
    a904:	91198283 	add	x3, x20, #0x660
    a908:	aa0003f5 	mov	x21, x0
    a90c:	f949d861 	ldr	x1, [x3, #5040]
    a910:	f949ec60 	ldr	x0, [x3, #5080]
    a914:	cb0102a1 	sub	x1, x21, x1
    a918:	eb00403f 	cmp	x1, x0, lsl #16
    a91c:	54000322 	b.cs	a980 <f0+0x34c>  // b.hs, b.nlast
    a920:	d350fc22 	lsr	x2, x1, #16
    a924:	f949fc63 	ldr	x3, [x3, #5112]
    a928:	8b020842 	add	x2, x2, x2, lsl #2
    a92c:	d37df042 	lsl	x2, x2, #3
    a930:	8b020060 	add	x0, x3, x2
    a934:	f9401017 	ldr	x23, [x0, #32]
    a938:	b4000257 	cbz	x23, a980 <f0+0x34c>
    a93c:	38626862 	ldrb	w2, [x3, x2]
    a940:	7100085f 	cmp	w2, #0x2
    a944:	54010180 	b.eq	c974 <f0+0x2340>  // b.none
    a948:	7100045f 	cmp	w2, #0x1
    a94c:	540001a1 	b.ne	a980 <f0+0x34c>  // b.any
    a950:	29430002 	ldp	w2, w0, [x0, #24]
    a954:	92403c21 	and	x1, x1, #0xffff
    a958:	9b027c21 	mul	x1, x1, x2
    a95c:	d360fc21 	lsr	x1, x1, #32
    a960:	eb00003f 	cmp	x1, x0
    a964:	540000e2 	b.cs	a980 <f0+0x34c>  // b.hs, b.nlast
    a968:	8b0102f7 	add	x23, x23, x1
    a96c:	394002e0 	ldrb	w0, [x23]
    a970:	7103fc1f 	cmp	w0, #0xff
    a974:	54010c00 	b.eq	caf4 <f0+0x24c0>  // b.none
    a978:	52800020 	mov	w0, #0x1                   	// #1
    a97c:	390002e0 	strb	w0, [x23]
    a980:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a984:	9103a3e1 	add	x1, sp, #0xe8
    a988:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a98c:	52800020 	mov	w0, #0x1                   	// #1
    a990:	a90ed7e2 	stp	x2, x21, [sp, #232]
    a994:	97ffebef 	bl	5950 <fwp_data.part.0.constprop.0>
    a998:	91198283 	add	x3, x20, #0x660
    a99c:	aa0003f5 	mov	x21, x0
    a9a0:	f949d861 	ldr	x1, [x3, #5040]
    a9a4:	f949ec60 	ldr	x0, [x3, #5080]
    a9a8:	cb0102a1 	sub	x1, x21, x1
    a9ac:	eb00403f 	cmp	x1, x0, lsl #16
    a9b0:	54000322 	b.cs	aa14 <f0+0x3e0>  // b.hs, b.nlast
    a9b4:	d350fc22 	lsr	x2, x1, #16
    a9b8:	f949fc63 	ldr	x3, [x3, #5112]
    a9bc:	8b020842 	add	x2, x2, x2, lsl #2
    a9c0:	d37df042 	lsl	x2, x2, #3
    a9c4:	8b020060 	add	x0, x3, x2
    a9c8:	f9401017 	ldr	x23, [x0, #32]
    a9cc:	b4000257 	cbz	x23, aa14 <f0+0x3e0>
    a9d0:	38626862 	ldrb	w2, [x3, x2]
    a9d4:	7100085f 	cmp	w2, #0x2
    a9d8:	5400fc80 	b.eq	c968 <f0+0x2334>  // b.none
    a9dc:	7100045f 	cmp	w2, #0x1
    a9e0:	540001a1 	b.ne	aa14 <f0+0x3e0>  // b.any
    a9e4:	29430002 	ldp	w2, w0, [x0, #24]
    a9e8:	92403c21 	and	x1, x1, #0xffff
    a9ec:	9b027c21 	mul	x1, x1, x2
    a9f0:	d360fc21 	lsr	x1, x1, #32
    a9f4:	eb00003f 	cmp	x1, x0
    a9f8:	540000e2 	b.cs	aa14 <f0+0x3e0>  // b.hs, b.nlast
    a9fc:	8b0102f7 	add	x23, x23, x1
    aa00:	394002e0 	ldrb	w0, [x23]
    aa04:	7103fc1f 	cmp	w0, #0xff
    aa08:	540107c0 	b.eq	cb00 <f0+0x24cc>  // b.none
    aa0c:	52800020 	mov	w0, #0x1                   	// #1
    aa10:	390002e0 	strb	w0, [x23]
    aa14:	9103e3e1 	add	x1, sp, #0xf8
    aa18:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aa1c:	52800020 	mov	w0, #0x1                   	// #1
    aa20:	a90fd7e2 	stp	x2, x21, [sp, #248]
    aa24:	97ffebcb 	bl	5950 <fwp_data.part.0.constprop.0>
    aa28:	97ffec4e 	bl	5b60 <fwp_rc_fresh>
    aa2c:	aa0003e2 	mov	x2, x0
    aa30:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aa34:	910423e1 	add	x1, sp, #0x108
    aa38:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aa3c:	52800020 	mov	w0, #0x1                   	// #1
    aa40:	a9108be3 	stp	x3, x2, [sp, #264]
    aa44:	97ffebc3 	bl	5950 <fwp_data.part.0.constprop.0>
    aa48:	91198283 	add	x3, x20, #0x660
    aa4c:	aa0003f5 	mov	x21, x0
    aa50:	f949d861 	ldr	x1, [x3, #5040]
    aa54:	f949ec60 	ldr	x0, [x3, #5080]
    aa58:	cb0102a1 	sub	x1, x21, x1
    aa5c:	eb00403f 	cmp	x1, x0, lsl #16
    aa60:	54000322 	b.cs	aac4 <f0+0x490>  // b.hs, b.nlast
    aa64:	d350fc22 	lsr	x2, x1, #16
    aa68:	f949fc63 	ldr	x3, [x3, #5112]
    aa6c:	8b020842 	add	x2, x2, x2, lsl #2
    aa70:	d37df042 	lsl	x2, x2, #3
    aa74:	8b020060 	add	x0, x3, x2
    aa78:	f9401017 	ldr	x23, [x0, #32]
    aa7c:	b4000257 	cbz	x23, aac4 <f0+0x490>
    aa80:	38626862 	ldrb	w2, [x3, x2]
    aa84:	7100085f 	cmp	w2, #0x2
    aa88:	5400f940 	b.eq	c9b0 <f0+0x237c>  // b.none
    aa8c:	7100045f 	cmp	w2, #0x1
    aa90:	540001a1 	b.ne	aac4 <f0+0x490>  // b.any
    aa94:	29430002 	ldp	w2, w0, [x0, #24]
    aa98:	92403c21 	and	x1, x1, #0xffff
    aa9c:	9b027c21 	mul	x1, x1, x2
    aaa0:	d360fc21 	lsr	x1, x1, #32
    aaa4:	eb00003f 	cmp	x1, x0
    aaa8:	540000e2 	b.cs	aac4 <f0+0x490>  // b.hs, b.nlast
    aaac:	8b0102f7 	add	x23, x23, x1
    aab0:	394002e0 	ldrb	w0, [x23]
    aab4:	7103fc1f 	cmp	w0, #0xff
    aab8:	540102a0 	b.eq	cb0c <f0+0x24d8>  // b.none
    aabc:	52800020 	mov	w0, #0x1                   	// #1
    aac0:	390002e0 	strb	w0, [x23]
    aac4:	910463e1 	add	x1, sp, #0x118
    aac8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aacc:	52800020 	mov	w0, #0x1                   	// #1
    aad0:	a911d7e2 	stp	x2, x21, [sp, #280]
    aad4:	97ffeb9f 	bl	5950 <fwp_data.part.0.constprop.0>
    aad8:	97ffec22 	bl	5b60 <fwp_rc_fresh>
    aadc:	aa0003e2 	mov	x2, x0
    aae0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aae4:	9104a3e1 	add	x1, sp, #0x128
    aae8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aaec:	52800020 	mov	w0, #0x1                   	// #1
    aaf0:	a9128be3 	stp	x3, x2, [sp, #296]
    aaf4:	97ffeb97 	bl	5950 <fwp_data.part.0.constprop.0>
    aaf8:	91198283 	add	x3, x20, #0x660
    aafc:	aa0003f5 	mov	x21, x0
    ab00:	f949d861 	ldr	x1, [x3, #5040]
    ab04:	f949ec60 	ldr	x0, [x3, #5080]
    ab08:	cb0102a1 	sub	x1, x21, x1
    ab0c:	eb00403f 	cmp	x1, x0, lsl #16
    ab10:	54000322 	b.cs	ab74 <f0+0x540>  // b.hs, b.nlast
    ab14:	d350fc22 	lsr	x2, x1, #16
    ab18:	f949fc63 	ldr	x3, [x3, #5112]
    ab1c:	8b020842 	add	x2, x2, x2, lsl #2
    ab20:	d37df042 	lsl	x2, x2, #3
    ab24:	8b020060 	add	x0, x3, x2
    ab28:	f9401017 	ldr	x23, [x0, #32]
    ab2c:	b4000257 	cbz	x23, ab74 <f0+0x540>
    ab30:	38626862 	ldrb	w2, [x3, x2]
    ab34:	7100085f 	cmp	w2, #0x2
    ab38:	5400f360 	b.eq	c9a4 <f0+0x2370>  // b.none
    ab3c:	7100045f 	cmp	w2, #0x1
    ab40:	540001a1 	b.ne	ab74 <f0+0x540>  // b.any
    ab44:	29430002 	ldp	w2, w0, [x0, #24]
    ab48:	92403c21 	and	x1, x1, #0xffff
    ab4c:	9b027c21 	mul	x1, x1, x2
    ab50:	d360fc21 	lsr	x1, x1, #32
    ab54:	eb00003f 	cmp	x1, x0
    ab58:	540000e2 	b.cs	ab74 <f0+0x540>  // b.hs, b.nlast
    ab5c:	8b0102f7 	add	x23, x23, x1
    ab60:	394002e0 	ldrb	w0, [x23]
    ab64:	7103fc1f 	cmp	w0, #0xff
    ab68:	5400fd80 	b.eq	cb18 <f0+0x24e4>  // b.none
    ab6c:	52800020 	mov	w0, #0x1                   	// #1
    ab70:	390002e0 	strb	w0, [x23]
    ab74:	9104e3e1 	add	x1, sp, #0x138
    ab78:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ab7c:	52800020 	mov	w0, #0x1                   	// #1
    ab80:	a913d7f7 	stp	x23, x21, [sp, #312]
    ab84:	97ffeb73 	bl	5950 <fwp_data.part.0.constprop.0>
    ab88:	97ffebf6 	bl	5b60 <fwp_rc_fresh>
    ab8c:	aa0003e2 	mov	x2, x0
    ab90:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ab94:	910523e1 	add	x1, sp, #0x148
    ab98:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ab9c:	52800020 	mov	w0, #0x1                   	// #1
    aba0:	a9148be3 	stp	x3, x2, [sp, #328]
    aba4:	97ffeb6b 	bl	5950 <fwp_data.part.0.constprop.0>
    aba8:	97ffebee 	bl	5b60 <fwp_rc_fresh>
    abac:	aa0003e2 	mov	x2, x0
    abb0:	910563e1 	add	x1, sp, #0x158
    abb4:	52800020 	mov	w0, #0x1                   	// #1
    abb8:	a9158bf7 	stp	x23, x2, [sp, #344]
    abbc:	97ffeb65 	bl	5950 <fwp_data.part.0.constprop.0>
    abc0:	91198283 	add	x3, x20, #0x660
    abc4:	aa0003f5 	mov	x21, x0
    abc8:	f949d861 	ldr	x1, [x3, #5040]
    abcc:	f949ec60 	ldr	x0, [x3, #5080]
    abd0:	cb0102a1 	sub	x1, x21, x1
    abd4:	eb00403f 	cmp	x1, x0, lsl #16
    abd8:	54000322 	b.cs	ac3c <f0+0x608>  // b.hs, b.nlast
    abdc:	d350fc22 	lsr	x2, x1, #16
    abe0:	f949fc63 	ldr	x3, [x3, #5112]
    abe4:	8b020842 	add	x2, x2, x2, lsl #2
    abe8:	d37df042 	lsl	x2, x2, #3
    abec:	8b020060 	add	x0, x3, x2
    abf0:	f9401017 	ldr	x23, [x0, #32]
    abf4:	b4000257 	cbz	x23, ac3c <f0+0x608>
    abf8:	38626862 	ldrb	w2, [x3, x2]
    abfc:	7100085f 	cmp	w2, #0x2
    ac00:	5400ecc0 	b.eq	c998 <f0+0x2364>  // b.none
    ac04:	7100045f 	cmp	w2, #0x1
    ac08:	540001a1 	b.ne	ac3c <f0+0x608>  // b.any
    ac0c:	29430002 	ldp	w2, w0, [x0, #24]
    ac10:	92403c21 	and	x1, x1, #0xffff
    ac14:	9b027c21 	mul	x1, x1, x2
    ac18:	d360fc21 	lsr	x1, x1, #32
    ac1c:	eb00003f 	cmp	x1, x0
    ac20:	540000e2 	b.cs	ac3c <f0+0x608>  // b.hs, b.nlast
    ac24:	8b0102f7 	add	x23, x23, x1
    ac28:	394002e0 	ldrb	w0, [x23]
    ac2c:	7103fc1f 	cmp	w0, #0xff
    ac30:	5400f7a0 	b.eq	cb24 <f0+0x24f0>  // b.none
    ac34:	52800020 	mov	w0, #0x1                   	// #1
    ac38:	390002e0 	strb	w0, [x23]
    ac3c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ac40:	9105a3e1 	add	x1, sp, #0x168
    ac44:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ac48:	52800020 	mov	w0, #0x1                   	// #1
    ac4c:	a916d7e2 	stp	x2, x21, [sp, #360]
    ac50:	97ffeb40 	bl	5950 <fwp_data.part.0.constprop.0>
    ac54:	91198283 	add	x3, x20, #0x660
    ac58:	aa0003f5 	mov	x21, x0
    ac5c:	f949d861 	ldr	x1, [x3, #5040]
    ac60:	f949ec60 	ldr	x0, [x3, #5080]
    ac64:	cb0102a1 	sub	x1, x21, x1
    ac68:	eb00403f 	cmp	x1, x0, lsl #16
    ac6c:	54000322 	b.cs	acd0 <f0+0x69c>  // b.hs, b.nlast
    ac70:	d350fc22 	lsr	x2, x1, #16
    ac74:	f949fc63 	ldr	x3, [x3, #5112]
    ac78:	8b020842 	add	x2, x2, x2, lsl #2
    ac7c:	d37df042 	lsl	x2, x2, #3
    ac80:	8b020060 	add	x0, x3, x2
    ac84:	f9401017 	ldr	x23, [x0, #32]
    ac88:	b4000257 	cbz	x23, acd0 <f0+0x69c>
    ac8c:	38626862 	ldrb	w2, [x3, x2]
    ac90:	7100085f 	cmp	w2, #0x2
    ac94:	5400e7c0 	b.eq	c98c <f0+0x2358>  // b.none
    ac98:	7100045f 	cmp	w2, #0x1
    ac9c:	540001a1 	b.ne	acd0 <f0+0x69c>  // b.any
    aca0:	29430002 	ldp	w2, w0, [x0, #24]
    aca4:	92403c21 	and	x1, x1, #0xffff
    aca8:	9b027c21 	mul	x1, x1, x2
    acac:	d360fc21 	lsr	x1, x1, #32
    acb0:	eb00003f 	cmp	x1, x0
    acb4:	540000e2 	b.cs	acd0 <f0+0x69c>  // b.hs, b.nlast
    acb8:	8b0102f7 	add	x23, x23, x1
    acbc:	394002e0 	ldrb	w0, [x23]
    acc0:	7103fc1f 	cmp	w0, #0xff
    acc4:	5400f360 	b.eq	cb30 <f0+0x24fc>  // b.none
    acc8:	52800020 	mov	w0, #0x1                   	// #1
    accc:	390002e0 	strb	w0, [x23]
    acd0:	9105e3e1 	add	x1, sp, #0x178
    acd4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    acd8:	52800020 	mov	w0, #0x1                   	// #1
    acdc:	a917d7e2 	stp	x2, x21, [sp, #376]
    ace0:	97ffeb1c 	bl	5950 <fwp_data.part.0.constprop.0>
    ace4:	97ffeb9f 	bl	5b60 <fwp_rc_fresh>
    ace8:	aa0003e2 	mov	x2, x0
    acec:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    acf0:	910623e1 	add	x1, sp, #0x188
    acf4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    acf8:	52800020 	mov	w0, #0x1                   	// #1
    acfc:	a9188be3 	stp	x3, x2, [sp, #392]
    ad00:	97ffeb14 	bl	5950 <fwp_data.part.0.constprop.0>
    ad04:	91198283 	add	x3, x20, #0x660
    ad08:	aa0003f5 	mov	x21, x0
    ad0c:	f949d861 	ldr	x1, [x3, #5040]
    ad10:	f949ec60 	ldr	x0, [x3, #5080]
    ad14:	cb0102a1 	sub	x1, x21, x1
    ad18:	eb00403f 	cmp	x1, x0, lsl #16
    ad1c:	54000322 	b.cs	ad80 <f0+0x74c>  // b.hs, b.nlast
    ad20:	d350fc22 	lsr	x2, x1, #16
    ad24:	f949fc63 	ldr	x3, [x3, #5112]
    ad28:	8b020842 	add	x2, x2, x2, lsl #2
    ad2c:	d37df042 	lsl	x2, x2, #3
    ad30:	8b020060 	add	x0, x3, x2
    ad34:	f9401017 	ldr	x23, [x0, #32]
    ad38:	b4000257 	cbz	x23, ad80 <f0+0x74c>
    ad3c:	38626862 	ldrb	w2, [x3, x2]
    ad40:	7100085f 	cmp	w2, #0x2
    ad44:	5400e660 	b.eq	ca10 <f0+0x23dc>  // b.none
    ad48:	7100045f 	cmp	w2, #0x1
    ad4c:	540001a1 	b.ne	ad80 <f0+0x74c>  // b.any
    ad50:	29430002 	ldp	w2, w0, [x0, #24]
    ad54:	92403c21 	and	x1, x1, #0xffff
    ad58:	9b027c21 	mul	x1, x1, x2
    ad5c:	d360fc21 	lsr	x1, x1, #32
    ad60:	eb00003f 	cmp	x1, x0
    ad64:	540000e2 	b.cs	ad80 <f0+0x74c>  // b.hs, b.nlast
    ad68:	8b0102f7 	add	x23, x23, x1
    ad6c:	394002e0 	ldrb	w0, [x23]
    ad70:	7103fc1f 	cmp	w0, #0xff
    ad74:	5400ee40 	b.eq	cb3c <f0+0x2508>  // b.none
    ad78:	52800020 	mov	w0, #0x1                   	// #1
    ad7c:	390002e0 	strb	w0, [x23]
    ad80:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad84:	910663e1 	add	x1, sp, #0x198
    ad88:	52800020 	mov	w0, #0x1                   	// #1
    ad8c:	a919d7e2 	stp	x2, x21, [sp, #408]
    ad90:	97ffeaf0 	bl	5950 <fwp_data.part.0.constprop.0>
    ad94:	91198283 	add	x3, x20, #0x660
    ad98:	aa0003f5 	mov	x21, x0
    ad9c:	f949d861 	ldr	x1, [x3, #5040]
    ada0:	f949ec60 	ldr	x0, [x3, #5080]
    ada4:	cb0102a1 	sub	x1, x21, x1
    ada8:	eb00403f 	cmp	x1, x0, lsl #16
    adac:	54000322 	b.cs	ae10 <f0+0x7dc>  // b.hs, b.nlast
    adb0:	d350fc22 	lsr	x2, x1, #16
    adb4:	f949fc63 	ldr	x3, [x3, #5112]
    adb8:	8b020842 	add	x2, x2, x2, lsl #2
    adbc:	d37df042 	lsl	x2, x2, #3
    adc0:	8b020060 	add	x0, x3, x2
    adc4:	f9401017 	ldr	x23, [x0, #32]
    adc8:	b4000257 	cbz	x23, ae10 <f0+0x7dc>
    adcc:	38626862 	ldrb	w2, [x3, x2]
    add0:	7100085f 	cmp	w2, #0x2
    add4:	5400e180 	b.eq	ca04 <f0+0x23d0>  // b.none
    add8:	7100045f 	cmp	w2, #0x1
    addc:	540001a1 	b.ne	ae10 <f0+0x7dc>  // b.any
    ade0:	29430002 	ldp	w2, w0, [x0, #24]
    ade4:	92403c21 	and	x1, x1, #0xffff
    ade8:	9b027c21 	mul	x1, x1, x2
    adec:	d360fc21 	lsr	x1, x1, #32
    adf0:	eb00003f 	cmp	x1, x0
    adf4:	540000e2 	b.cs	ae10 <f0+0x7dc>  // b.hs, b.nlast
    adf8:	8b0102f7 	add	x23, x23, x1
    adfc:	394002e0 	ldrb	w0, [x23]
    ae00:	7103fc1f 	cmp	w0, #0xff
    ae04:	5400ea20 	b.eq	cb48 <f0+0x2514>  // b.none
    ae08:	52800020 	mov	w0, #0x1                   	// #1
    ae0c:	390002e0 	strb	w0, [x23]
    ae10:	9106a3e1 	add	x1, sp, #0x1a8
    ae14:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ae18:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ae1c:	52800020 	mov	w0, #0x1                   	// #1
    ae20:	a91ad7f7 	stp	x23, x21, [sp, #424]
    ae24:	97ffeacb 	bl	5950 <fwp_data.part.0.constprop.0>
    ae28:	97ffeb4e 	bl	5b60 <fwp_rc_fresh>
    ae2c:	aa0003e2 	mov	x2, x0
    ae30:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ae34:	9106e3e1 	add	x1, sp, #0x1b8
    ae38:	52800020 	mov	w0, #0x1                   	// #1
    ae3c:	a91b8be3 	stp	x3, x2, [sp, #440]
    ae40:	97ffeac4 	bl	5950 <fwp_data.part.0.constprop.0>
    ae44:	97ffeb47 	bl	5b60 <fwp_rc_fresh>
    ae48:	aa0003e2 	mov	x2, x0
    ae4c:	910723e1 	add	x1, sp, #0x1c8
    ae50:	52800020 	mov	w0, #0x1                   	// #1
    ae54:	a91c8bf7 	stp	x23, x2, [sp, #456]
    ae58:	97ffeabe 	bl	5950 <fwp_data.part.0.constprop.0>
    ae5c:	91198283 	add	x3, x20, #0x660
    ae60:	aa0003f5 	mov	x21, x0
    ae64:	f949d861 	ldr	x1, [x3, #5040]
    ae68:	f949ec60 	ldr	x0, [x3, #5080]
    ae6c:	cb0102a1 	sub	x1, x21, x1
    ae70:	eb00403f 	cmp	x1, x0, lsl #16
    ae74:	54000322 	b.cs	aed8 <f0+0x8a4>  // b.hs, b.nlast
    ae78:	d350fc22 	lsr	x2, x1, #16
    ae7c:	f949fc63 	ldr	x3, [x3, #5112]
    ae80:	8b020842 	add	x2, x2, x2, lsl #2
    ae84:	d37df042 	lsl	x2, x2, #3
    ae88:	8b020060 	add	x0, x3, x2
    ae8c:	f9401017 	ldr	x23, [x0, #32]
    ae90:	b4000257 	cbz	x23, aed8 <f0+0x8a4>
    ae94:	38626862 	ldrb	w2, [x3, x2]
    ae98:	7100085f 	cmp	w2, #0x2
    ae9c:	5400dae0 	b.eq	c9f8 <f0+0x23c4>  // b.none
    aea0:	7100045f 	cmp	w2, #0x1
    aea4:	540001a1 	b.ne	aed8 <f0+0x8a4>  // b.any
    aea8:	29430002 	ldp	w2, w0, [x0, #24]
    aeac:	92403c21 	and	x1, x1, #0xffff
    aeb0:	9b027c21 	mul	x1, x1, x2
    aeb4:	d360fc21 	lsr	x1, x1, #32
    aeb8:	eb00003f 	cmp	x1, x0
    aebc:	540000e2 	b.cs	aed8 <f0+0x8a4>  // b.hs, b.nlast
    aec0:	8b0102f7 	add	x23, x23, x1
    aec4:	394002e0 	ldrb	w0, [x23]
    aec8:	7103fc1f 	cmp	w0, #0xff
    aecc:	5400e440 	b.eq	cb54 <f0+0x2520>  // b.none
    aed0:	52800020 	mov	w0, #0x1                   	// #1
    aed4:	390002e0 	strb	w0, [x23]
    aed8:	910763e1 	add	x1, sp, #0x1d8
    aedc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    aee0:	52800020 	mov	w0, #0x1                   	// #1
    aee4:	a91dd7f7 	stp	x23, x21, [sp, #472]
    aee8:	97ffea9a 	bl	5950 <fwp_data.part.0.constprop.0>
    aeec:	97ffeb1d 	bl	5b60 <fwp_rc_fresh>
    aef0:	aa0003e2 	mov	x2, x0
    aef4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aef8:	9107a3e1 	add	x1, sp, #0x1e8
    aefc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    af00:	52800020 	mov	w0, #0x1                   	// #1
    af04:	a91e8be3 	stp	x3, x2, [sp, #488]
    af08:	97ffea92 	bl	5950 <fwp_data.part.0.constprop.0>
    af0c:	97ffeb15 	bl	5b60 <fwp_rc_fresh>
    af10:	aa0003e2 	mov	x2, x0
    af14:	9107e3e1 	add	x1, sp, #0x1f8
    af18:	52800020 	mov	w0, #0x1                   	// #1
    af1c:	a91f8bf7 	stp	x23, x2, [sp, #504]
    af20:	97ffea8c 	bl	5950 <fwp_data.part.0.constprop.0>
    af24:	91198283 	add	x3, x20, #0x660
    af28:	aa0003f5 	mov	x21, x0
    af2c:	f949d861 	ldr	x1, [x3, #5040]
    af30:	f949ec60 	ldr	x0, [x3, #5080]
    af34:	cb0102a1 	sub	x1, x21, x1
    af38:	eb00403f 	cmp	x1, x0, lsl #16
    af3c:	54000322 	b.cs	afa0 <f0+0x96c>  // b.hs, b.nlast
    af40:	d350fc22 	lsr	x2, x1, #16
    af44:	f949fc63 	ldr	x3, [x3, #5112]
    af48:	8b020842 	add	x2, x2, x2, lsl #2
    af4c:	d37df042 	lsl	x2, x2, #3
    af50:	8b020060 	add	x0, x3, x2
    af54:	f9401017 	ldr	x23, [x0, #32]
    af58:	b4000257 	cbz	x23, afa0 <f0+0x96c>
    af5c:	38626862 	ldrb	w2, [x3, x2]
    af60:	7100085f 	cmp	w2, #0x2
    af64:	5400d440 	b.eq	c9ec <f0+0x23b8>  // b.none
    af68:	7100045f 	cmp	w2, #0x1
    af6c:	540001a1 	b.ne	afa0 <f0+0x96c>  // b.any
    af70:	29430002 	ldp	w2, w0, [x0, #24]
    af74:	92403c21 	and	x1, x1, #0xffff
    af78:	9b027c21 	mul	x1, x1, x2
    af7c:	d360fc21 	lsr	x1, x1, #32
    af80:	eb00003f 	cmp	x1, x0
    af84:	540000e2 	b.cs	afa0 <f0+0x96c>  // b.hs, b.nlast
    af88:	8b0102f7 	add	x23, x23, x1
    af8c:	394002e0 	ldrb	w0, [x23]
    af90:	7103fc1f 	cmp	w0, #0xff
    af94:	5400de60 	b.eq	cb60 <f0+0x252c>  // b.none
    af98:	52800020 	mov	w0, #0x1                   	// #1
    af9c:	390002e0 	strb	w0, [x23]
    afa0:	910823e1 	add	x1, sp, #0x208
    afa4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    afa8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    afac:	52800020 	mov	w0, #0x1                   	// #1
    afb0:	f90107f7 	str	x23, [sp, #520]
    afb4:	f9010bf5 	str	x21, [sp, #528]
    afb8:	97ffea66 	bl	5950 <fwp_data.part.0.constprop.0>
    afbc:	97ffeae9 	bl	5b60 <fwp_rc_fresh>
    afc0:	aa0003e2 	mov	x2, x0
    afc4:	910863e1 	add	x1, sp, #0x218
    afc8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f9010ff5 	str	x21, [sp, #536]
    afd4:	f90113e2 	str	x2, [sp, #544]
    afd8:	97ffea5e 	bl	5950 <fwp_data.part.0.constprop.0>
    afdc:	97ffeae1 	bl	5b60 <fwp_rc_fresh>
    afe0:	aa0003e2 	mov	x2, x0
    afe4:	9108a3e1 	add	x1, sp, #0x228
    afe8:	52800020 	mov	w0, #0x1                   	// #1
    afec:	f90117f7 	str	x23, [sp, #552]
    aff0:	f9011be2 	str	x2, [sp, #560]
    aff4:	97ffea57 	bl	5950 <fwp_data.part.0.constprop.0>
    aff8:	97ffeada 	bl	5b60 <fwp_rc_fresh>
    affc:	aa0003e2 	mov	x2, x0
    b000:	9108e3e1 	add	x1, sp, #0x238
    b004:	52800020 	mov	w0, #0x1                   	// #1
    b008:	f9011ff5 	str	x21, [sp, #568]
    b00c:	f90123e2 	str	x2, [sp, #576]
    b010:	97ffea50 	bl	5950 <fwp_data.part.0.constprop.0>
    b014:	97ffead3 	bl	5b60 <fwp_rc_fresh>
    b018:	aa0003e2 	mov	x2, x0
    b01c:	910923e1 	add	x1, sp, #0x248
    b020:	52800020 	mov	w0, #0x1                   	// #1
    b024:	f90127f7 	str	x23, [sp, #584]
    b028:	f9012be2 	str	x2, [sp, #592]
    b02c:	97ffea49 	bl	5950 <fwp_data.part.0.constprop.0>
    b030:	97ffeacc 	bl	5b60 <fwp_rc_fresh>
    b034:	aa0003e2 	mov	x2, x0
    b038:	910963e1 	add	x1, sp, #0x258
    b03c:	52800020 	mov	w0, #0x1                   	// #1
    b040:	f9012ff5 	str	x21, [sp, #600]
    b044:	f90133e2 	str	x2, [sp, #608]
    b048:	97ffea42 	bl	5950 <fwp_data.part.0.constprop.0>
    b04c:	97ffeac5 	bl	5b60 <fwp_rc_fresh>
    b050:	aa0003e2 	mov	x2, x0
    b054:	9109a3e1 	add	x1, sp, #0x268
    b058:	52800020 	mov	w0, #0x1                   	// #1
    b05c:	f90137f7 	str	x23, [sp, #616]
    b060:	f9013be2 	str	x2, [sp, #624]
    b064:	97ffea3b 	bl	5950 <fwp_data.part.0.constprop.0>
    b068:	97ffeabe 	bl	5b60 <fwp_rc_fresh>
    b06c:	aa0003e2 	mov	x2, x0
    b070:	9109e3e1 	add	x1, sp, #0x278
    b074:	52800020 	mov	w0, #0x1                   	// #1
    b078:	f9013ff5 	str	x21, [sp, #632]
    b07c:	f90143e2 	str	x2, [sp, #640]
    b080:	97ffea34 	bl	5950 <fwp_data.part.0.constprop.0>
    b084:	97ffeab7 	bl	5b60 <fwp_rc_fresh>
    b088:	aa0003e2 	mov	x2, x0
    b08c:	910a23e1 	add	x1, sp, #0x288
    b090:	52800020 	mov	w0, #0x1                   	// #1
    b094:	f90147f7 	str	x23, [sp, #648]
    b098:	f9014be2 	str	x2, [sp, #656]
    b09c:	97ffea2d 	bl	5950 <fwp_data.part.0.constprop.0>
    b0a0:	97ffeab0 	bl	5b60 <fwp_rc_fresh>
    b0a4:	aa0003e2 	mov	x2, x0
    b0a8:	910a63e1 	add	x1, sp, #0x298
    b0ac:	52800020 	mov	w0, #0x1                   	// #1
    b0b0:	f9014ff5 	str	x21, [sp, #664]
    b0b4:	f90153e2 	str	x2, [sp, #672]
    b0b8:	97ffea26 	bl	5950 <fwp_data.part.0.constprop.0>
    b0bc:	91198283 	add	x3, x20, #0x660
    b0c0:	aa0003f7 	mov	x23, x0
    b0c4:	f949d861 	ldr	x1, [x3, #5040]
    b0c8:	f949ec60 	ldr	x0, [x3, #5080]
    b0cc:	cb0102e1 	sub	x1, x23, x1
    b0d0:	eb00403f 	cmp	x1, x0, lsl #16
    b0d4:	54000322 	b.cs	b138 <f0+0xb04>  // b.hs, b.nlast
    b0d8:	d350fc22 	lsr	x2, x1, #16
    b0dc:	f949fc63 	ldr	x3, [x3, #5112]
    b0e0:	8b020842 	add	x2, x2, x2, lsl #2
    b0e4:	d37df042 	lsl	x2, x2, #3
    b0e8:	8b020060 	add	x0, x3, x2
    b0ec:	f9401015 	ldr	x21, [x0, #32]
    b0f0:	b4000255 	cbz	x21, b138 <f0+0xb04>
    b0f4:	38626862 	ldrb	w2, [x3, x2]
    b0f8:	7100085f 	cmp	w2, #0x2
    b0fc:	5400c720 	b.eq	c9e0 <f0+0x23ac>  // b.none
    b100:	7100045f 	cmp	w2, #0x1
    b104:	540001a1 	b.ne	b138 <f0+0xb04>  // b.any
    b108:	29430002 	ldp	w2, w0, [x0, #24]
    b10c:	92403c21 	and	x1, x1, #0xffff
    b110:	9b027c21 	mul	x1, x1, x2
    b114:	d360fc21 	lsr	x1, x1, #32
    b118:	eb00003f 	cmp	x1, x0
    b11c:	540000e2 	b.cs	b138 <f0+0xb04>  // b.hs, b.nlast
    b120:	8b0102b5 	add	x21, x21, x1
    b124:	394002a0 	ldrb	w0, [x21]
    b128:	7103fc1f 	cmp	w0, #0xff
    b12c:	5400d200 	b.eq	cb6c <f0+0x2538>  // b.none
    b130:	52800020 	mov	w0, #0x1                   	// #1
    b134:	390002a0 	strb	w0, [x21]
    b138:	910aa3e1 	add	x1, sp, #0x2a8
    b13c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b140:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b144:	52800020 	mov	w0, #0x1                   	// #1
    b148:	f90157f5 	str	x21, [sp, #680]
    b14c:	f9015bf7 	str	x23, [sp, #688]
    b150:	97ffea00 	bl	5950 <fwp_data.part.0.constprop.0>
    b154:	97ffea83 	bl	5b60 <fwp_rc_fresh>
    b158:	aa0003e2 	mov	x2, x0
    b15c:	910ae3e1 	add	x1, sp, #0x2b8
    b160:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b164:	52800020 	mov	w0, #0x1                   	// #1
    b168:	f9015ff7 	str	x23, [sp, #696]
    b16c:	f90163e2 	str	x2, [sp, #704]
    b170:	97ffe9f8 	bl	5950 <fwp_data.part.0.constprop.0>
    b174:	97ffea7b 	bl	5b60 <fwp_rc_fresh>
    b178:	aa0003e2 	mov	x2, x0
    b17c:	910b23e1 	add	x1, sp, #0x2c8
    b180:	52800020 	mov	w0, #0x1                   	// #1
    b184:	f90167f5 	str	x21, [sp, #712]
    b188:	f9016be2 	str	x2, [sp, #720]
    b18c:	97ffe9f1 	bl	5950 <fwp_data.part.0.constprop.0>
    b190:	97ffea74 	bl	5b60 <fwp_rc_fresh>
    b194:	aa0003e2 	mov	x2, x0
    b198:	910b63e1 	add	x1, sp, #0x2d8
    b19c:	52800020 	mov	w0, #0x1                   	// #1
    b1a0:	f9016ff7 	str	x23, [sp, #728]
    b1a4:	f90173e2 	str	x2, [sp, #736]
    b1a8:	97ffe9ea 	bl	5950 <fwp_data.part.0.constprop.0>
    b1ac:	97ffea6d 	bl	5b60 <fwp_rc_fresh>
    b1b0:	aa0003e2 	mov	x2, x0
    b1b4:	910ba3e1 	add	x1, sp, #0x2e8
    b1b8:	52800020 	mov	w0, #0x1                   	// #1
    b1bc:	f90177f5 	str	x21, [sp, #744]
    b1c0:	f9017be2 	str	x2, [sp, #752]
    b1c4:	97ffe9e3 	bl	5950 <fwp_data.part.0.constprop.0>
    b1c8:	97ffea66 	bl	5b60 <fwp_rc_fresh>
    b1cc:	aa0003e2 	mov	x2, x0
    b1d0:	910be3e1 	add	x1, sp, #0x2f8
    b1d4:	52800020 	mov	w0, #0x1                   	// #1
    b1d8:	f9017ff7 	str	x23, [sp, #760]
    b1dc:	f90183e2 	str	x2, [sp, #768]
    b1e0:	97ffe9dc 	bl	5950 <fwp_data.part.0.constprop.0>
    b1e4:	97ffea5f 	bl	5b60 <fwp_rc_fresh>
    b1e8:	aa0003e2 	mov	x2, x0
    b1ec:	910c23e1 	add	x1, sp, #0x308
    b1f0:	52800020 	mov	w0, #0x1                   	// #1
    b1f4:	f90187f5 	str	x21, [sp, #776]
    b1f8:	f9018be2 	str	x2, [sp, #784]
    b1fc:	97ffe9d5 	bl	5950 <fwp_data.part.0.constprop.0>
    b200:	97ffea58 	bl	5b60 <fwp_rc_fresh>
    b204:	aa0003e2 	mov	x2, x0
    b208:	910c63e1 	add	x1, sp, #0x318
    b20c:	52800020 	mov	w0, #0x1                   	// #1
    b210:	f9018ff7 	str	x23, [sp, #792]
    b214:	f90193e2 	str	x2, [sp, #800]
    b218:	97ffe9ce 	bl	5950 <fwp_data.part.0.constprop.0>
    b21c:	97ffea51 	bl	5b60 <fwp_rc_fresh>
    b220:	aa0003e2 	mov	x2, x0
    b224:	910ca3e1 	add	x1, sp, #0x328
    b228:	52800020 	mov	w0, #0x1                   	// #1
    b22c:	f90197f5 	str	x21, [sp, #808]
    b230:	f9019be2 	str	x2, [sp, #816]
    b234:	97ffe9c7 	bl	5950 <fwp_data.part.0.constprop.0>
    b238:	97ffea4a 	bl	5b60 <fwp_rc_fresh>
    b23c:	aa0003e2 	mov	x2, x0
    b240:	910ce3e1 	add	x1, sp, #0x338
    b244:	52800020 	mov	w0, #0x1                   	// #1
    b248:	f9019ff7 	str	x23, [sp, #824]
    b24c:	f901a3e2 	str	x2, [sp, #832]
    b250:	97ffe9c0 	bl	5950 <fwp_data.part.0.constprop.0>
    b254:	97ffea43 	bl	5b60 <fwp_rc_fresh>
    b258:	aa0003e2 	mov	x2, x0
    b25c:	910d23e1 	add	x1, sp, #0x348
    b260:	52800020 	mov	w0, #0x1                   	// #1
    b264:	f901a7f5 	str	x21, [sp, #840]
    b268:	f901abe2 	str	x2, [sp, #848]
    b26c:	97ffe9b9 	bl	5950 <fwp_data.part.0.constprop.0>
    b270:	97ffea3c 	bl	5b60 <fwp_rc_fresh>
    b274:	aa0003e2 	mov	x2, x0
    b278:	910d63e1 	add	x1, sp, #0x358
    b27c:	52800020 	mov	w0, #0x1                   	// #1
    b280:	f901aff7 	str	x23, [sp, #856]
    b284:	f901b3e2 	str	x2, [sp, #864]
    b288:	97ffe9b2 	bl	5950 <fwp_data.part.0.constprop.0>
    b28c:	97ffea35 	bl	5b60 <fwp_rc_fresh>
    b290:	aa0003e2 	mov	x2, x0
    b294:	910da3e1 	add	x1, sp, #0x368
    b298:	52800020 	mov	w0, #0x1                   	// #1
    b29c:	f901b7f5 	str	x21, [sp, #872]
    b2a0:	f901bbe2 	str	x2, [sp, #880]
    b2a4:	97ffe9ab 	bl	5950 <fwp_data.part.0.constprop.0>
    b2a8:	97ffea2e 	bl	5b60 <fwp_rc_fresh>
    b2ac:	aa0003e2 	mov	x2, x0
    b2b0:	910de3e1 	add	x1, sp, #0x378
    b2b4:	52800020 	mov	w0, #0x1                   	// #1
    b2b8:	f901bff7 	str	x23, [sp, #888]
    b2bc:	f901c3e2 	str	x2, [sp, #896]
    b2c0:	97ffe9a4 	bl	5950 <fwp_data.part.0.constprop.0>
    b2c4:	97ffea27 	bl	5b60 <fwp_rc_fresh>
    b2c8:	aa0003e2 	mov	x2, x0
    b2cc:	910e23e1 	add	x1, sp, #0x388
    b2d0:	52800020 	mov	w0, #0x1                   	// #1
    b2d4:	f901c7f5 	str	x21, [sp, #904]
    b2d8:	f901cbe2 	str	x2, [sp, #912]
    b2dc:	97ffe99d 	bl	5950 <fwp_data.part.0.constprop.0>
    b2e0:	97ffea20 	bl	5b60 <fwp_rc_fresh>
    b2e4:	aa0003e2 	mov	x2, x0
    b2e8:	910e63e1 	add	x1, sp, #0x398
    b2ec:	52800020 	mov	w0, #0x1                   	// #1
    b2f0:	f901cff7 	str	x23, [sp, #920]
    b2f4:	f901d3e2 	str	x2, [sp, #928]
    b2f8:	97ffe996 	bl	5950 <fwp_data.part.0.constprop.0>
    b2fc:	97ffea19 	bl	5b60 <fwp_rc_fresh>
    b300:	aa0003e2 	mov	x2, x0
    b304:	910ea3e1 	add	x1, sp, #0x3a8
    b308:	52800020 	mov	w0, #0x1                   	// #1
    b30c:	f901d7f5 	str	x21, [sp, #936]
    b310:	f901dbe2 	str	x2, [sp, #944]
    b314:	97ffe98f 	bl	5950 <fwp_data.part.0.constprop.0>
    b318:	97ffea12 	bl	5b60 <fwp_rc_fresh>
    b31c:	aa0003e2 	mov	x2, x0
    b320:	910ee3e1 	add	x1, sp, #0x3b8
    b324:	52800020 	mov	w0, #0x1                   	// #1
    b328:	f901dff7 	str	x23, [sp, #952]
    b32c:	f901e3e2 	str	x2, [sp, #960]
    b330:	97ffe988 	bl	5950 <fwp_data.part.0.constprop.0>
    b334:	97ffea0b 	bl	5b60 <fwp_rc_fresh>
    b338:	aa0003e2 	mov	x2, x0
    b33c:	910f23e1 	add	x1, sp, #0x3c8
    b340:	52800020 	mov	w0, #0x1                   	// #1
    b344:	f901e7f5 	str	x21, [sp, #968]
    b348:	f901ebe2 	str	x2, [sp, #976]
    b34c:	97ffe981 	bl	5950 <fwp_data.part.0.constprop.0>
    b350:	97ffea04 	bl	5b60 <fwp_rc_fresh>
    b354:	aa0003e2 	mov	x2, x0
    b358:	910f63e1 	add	x1, sp, #0x3d8
    b35c:	52800020 	mov	w0, #0x1                   	// #1
    b360:	f901eff7 	str	x23, [sp, #984]
    b364:	f901f3e2 	str	x2, [sp, #992]
    b368:	97ffe97a 	bl	5950 <fwp_data.part.0.constprop.0>
    b36c:	97ffe9fd 	bl	5b60 <fwp_rc_fresh>
    b370:	aa0003e2 	mov	x2, x0
    b374:	910fa3e1 	add	x1, sp, #0x3e8
    b378:	52800020 	mov	w0, #0x1                   	// #1
    b37c:	f901f7f5 	str	x21, [sp, #1000]
    b380:	f901fbe2 	str	x2, [sp, #1008]
    b384:	97ffe973 	bl	5950 <fwp_data.part.0.constprop.0>
    b388:	91198283 	add	x3, x20, #0x660
    b38c:	aa0003f5 	mov	x21, x0
    b390:	f949d861 	ldr	x1, [x3, #5040]
    b394:	f949ec60 	ldr	x0, [x3, #5080]
    b398:	cb0102a1 	sub	x1, x21, x1
    b39c:	eb00403f 	cmp	x1, x0, lsl #16
    b3a0:	54000322 	b.cs	b404 <f0+0xdd0>  // b.hs, b.nlast
    b3a4:	d350fc22 	lsr	x2, x1, #16
    b3a8:	f949fc63 	ldr	x3, [x3, #5112]
    b3ac:	8b020842 	add	x2, x2, x2, lsl #2
    b3b0:	d37df042 	lsl	x2, x2, #3
    b3b4:	8b020060 	add	x0, x3, x2
    b3b8:	f9401017 	ldr	x23, [x0, #32]
    b3bc:	b4000257 	cbz	x23, b404 <f0+0xdd0>
    b3c0:	38626862 	ldrb	w2, [x3, x2]
    b3c4:	7100085f 	cmp	w2, #0x2
    b3c8:	5400b060 	b.eq	c9d4 <f0+0x23a0>  // b.none
    b3cc:	7100045f 	cmp	w2, #0x1
    b3d0:	540001a1 	b.ne	b404 <f0+0xdd0>  // b.any
    b3d4:	29430002 	ldp	w2, w0, [x0, #24]
    b3d8:	92403c21 	and	x1, x1, #0xffff
    b3dc:	9b027c21 	mul	x1, x1, x2
    b3e0:	d360fc21 	lsr	x1, x1, #32
    b3e4:	eb00003f 	cmp	x1, x0
    b3e8:	540000e2 	b.cs	b404 <f0+0xdd0>  // b.hs, b.nlast
    b3ec:	8b0102f7 	add	x23, x23, x1
    b3f0:	394002e0 	ldrb	w0, [x23]
    b3f4:	7103fc1f 	cmp	w0, #0xff
    b3f8:	5400bc00 	b.eq	cb78 <f0+0x2544>  // b.none
    b3fc:	52800020 	mov	w0, #0x1                   	// #1
    b400:	390002e0 	strb	w0, [x23]
    b404:	910fe3e1 	add	x1, sp, #0x3f8
    b408:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b40c:	52800020 	mov	w0, #0x1                   	// #1
    b410:	f901fff7 	str	x23, [sp, #1016]
    b414:	f90203f5 	str	x21, [sp, #1024]
    b418:	97ffe94e 	bl	5950 <fwp_data.part.0.constprop.0>
    b41c:	97ffe9d1 	bl	5b60 <fwp_rc_fresh>
    b420:	aa0003e2 	mov	x2, x0
    b424:	911023e1 	add	x1, sp, #0x408
    b428:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b42c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b430:	52800020 	mov	w0, #0x1                   	// #1
    b434:	f90207f5 	str	x21, [sp, #1032]
    b438:	f9020be2 	str	x2, [sp, #1040]
    b43c:	97ffe945 	bl	5950 <fwp_data.part.0.constprop.0>
    b440:	97ffe9c8 	bl	5b60 <fwp_rc_fresh>
    b444:	aa0003e2 	mov	x2, x0
    b448:	911063e1 	add	x1, sp, #0x418
    b44c:	52800020 	mov	w0, #0x1                   	// #1
    b450:	f9020ff7 	str	x23, [sp, #1048]
    b454:	f90213e2 	str	x2, [sp, #1056]
    b458:	97ffe93e 	bl	5950 <fwp_data.part.0.constprop.0>
    b45c:	97ffe9c1 	bl	5b60 <fwp_rc_fresh>
    b460:	aa0003e2 	mov	x2, x0
    b464:	9110a3e1 	add	x1, sp, #0x428
    b468:	52800020 	mov	w0, #0x1                   	// #1
    b46c:	f90217f5 	str	x21, [sp, #1064]
    b470:	f9021be2 	str	x2, [sp, #1072]
    b474:	97ffe937 	bl	5950 <fwp_data.part.0.constprop.0>
    b478:	91198283 	add	x3, x20, #0x660
    b47c:	aa0003f5 	mov	x21, x0
    b480:	f949d861 	ldr	x1, [x3, #5040]
    b484:	f949ec60 	ldr	x0, [x3, #5080]
    b488:	cb0102a1 	sub	x1, x21, x1
    b48c:	eb00403f 	cmp	x1, x0, lsl #16
    b490:	54000322 	b.cs	b4f4 <f0+0xec0>  // b.hs, b.nlast
    b494:	d350fc22 	lsr	x2, x1, #16
    b498:	f949fc63 	ldr	x3, [x3, #5112]
    b49c:	8b020842 	add	x2, x2, x2, lsl #2
    b4a0:	d37df042 	lsl	x2, x2, #3
    b4a4:	8b020060 	add	x0, x3, x2
    b4a8:	f9401017 	ldr	x23, [x0, #32]
    b4ac:	b4000257 	cbz	x23, b4f4 <f0+0xec0>
    b4b0:	38626862 	ldrb	w2, [x3, x2]
    b4b4:	7100085f 	cmp	w2, #0x2
    b4b8:	5400a880 	b.eq	c9c8 <f0+0x2394>  // b.none
    b4bc:	7100045f 	cmp	w2, #0x1
    b4c0:	540001a1 	b.ne	b4f4 <f0+0xec0>  // b.any
    b4c4:	29430002 	ldp	w2, w0, [x0, #24]
    b4c8:	92403c21 	and	x1, x1, #0xffff
    b4cc:	9b027c21 	mul	x1, x1, x2
    b4d0:	d360fc21 	lsr	x1, x1, #32
    b4d4:	eb00003f 	cmp	x1, x0
    b4d8:	540000e2 	b.cs	b4f4 <f0+0xec0>  // b.hs, b.nlast
    b4dc:	8b0102f7 	add	x23, x23, x1
    b4e0:	394002e0 	ldrb	w0, [x23]
    b4e4:	7103fc1f 	cmp	w0, #0xff
    b4e8:	5400b4e0 	b.eq	cb84 <f0+0x2550>  // b.none
    b4ec:	52800020 	mov	w0, #0x1                   	// #1
    b4f0:	390002e0 	strb	w0, [x23]
    b4f4:	9110e3e1 	add	x1, sp, #0x438
    b4f8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b4fc:	52800020 	mov	w0, #0x1                   	// #1
    b500:	f9021fe2 	str	x2, [sp, #1080]
    b504:	f90223f5 	str	x21, [sp, #1088]
    b508:	97ffe912 	bl	5950 <fwp_data.part.0.constprop.0>
    b50c:	97ffe995 	bl	5b60 <fwp_rc_fresh>
    b510:	aa0003e2 	mov	x2, x0
    b514:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b518:	911123e1 	add	x1, sp, #0x448
    b51c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b520:	52800020 	mov	w0, #0x1                   	// #1
    b524:	f90227e3 	str	x3, [sp, #1096]
    b528:	f9022be2 	str	x2, [sp, #1104]
    b52c:	97ffe909 	bl	5950 <fwp_data.part.0.constprop.0>
    b530:	91198283 	add	x3, x20, #0x660
    b534:	aa0003f5 	mov	x21, x0
    b538:	f949d861 	ldr	x1, [x3, #5040]
    b53c:	f949ec60 	ldr	x0, [x3, #5080]
    b540:	cb0102a1 	sub	x1, x21, x1
    b544:	eb00403f 	cmp	x1, x0, lsl #16
    b548:	54000322 	b.cs	b5ac <f0+0xf78>  // b.hs, b.nlast
    b54c:	d350fc22 	lsr	x2, x1, #16
    b550:	f949fc63 	ldr	x3, [x3, #5112]
    b554:	8b020842 	add	x2, x2, x2, lsl #2
    b558:	d37df042 	lsl	x2, x2, #3
    b55c:	8b020060 	add	x0, x3, x2
    b560:	f9401017 	ldr	x23, [x0, #32]
    b564:	b4000257 	cbz	x23, b5ac <f0+0xf78>
    b568:	38626862 	ldrb	w2, [x3, x2]
    b56c:	7100085f 	cmp	w2, #0x2
    b570:	5400a260 	b.eq	c9bc <f0+0x2388>  // b.none
    b574:	7100045f 	cmp	w2, #0x1
    b578:	540001a1 	b.ne	b5ac <f0+0xf78>  // b.any
    b57c:	29430002 	ldp	w2, w0, [x0, #24]
    b580:	92403c21 	and	x1, x1, #0xffff
    b584:	9b027c21 	mul	x1, x1, x2
    b588:	d360fc21 	lsr	x1, x1, #32
    b58c:	eb00003f 	cmp	x1, x0
    b590:	540000e2 	b.cs	b5ac <f0+0xf78>  // b.hs, b.nlast
    b594:	8b0102f7 	add	x23, x23, x1
    b598:	394002e0 	ldrb	w0, [x23]
    b59c:	7103fc1f 	cmp	w0, #0xff
    b5a0:	5400af80 	b.eq	cb90 <f0+0x255c>  // b.none
    b5a4:	52800020 	mov	w0, #0x1                   	// #1
    b5a8:	390002e0 	strb	w0, [x23]
    b5ac:	911163e1 	add	x1, sp, #0x458
    b5b0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b5b4:	52800020 	mov	w0, #0x1                   	// #1
    b5b8:	f9022fe2 	str	x2, [sp, #1112]
    b5bc:	f90233f5 	str	x21, [sp, #1120]
    b5c0:	97ffe8e4 	bl	5950 <fwp_data.part.0.constprop.0>
    b5c4:	97ffe967 	bl	5b60 <fwp_rc_fresh>
    b5c8:	aa0003e2 	mov	x2, x0
    b5cc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b5d0:	9111a3e1 	add	x1, sp, #0x468
    b5d4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b5d8:	52800020 	mov	w0, #0x1                   	// #1
    b5dc:	f90237e3 	str	x3, [sp, #1128]
    b5e0:	f9023be2 	str	x2, [sp, #1136]
    b5e4:	97ffe8db 	bl	5950 <fwp_data.part.0.constprop.0>
    b5e8:	91198283 	add	x3, x20, #0x660
    b5ec:	aa0003f7 	mov	x23, x0
    b5f0:	f949d861 	ldr	x1, [x3, #5040]
    b5f4:	f949ec60 	ldr	x0, [x3, #5080]
    b5f8:	cb0102e1 	sub	x1, x23, x1
    b5fc:	eb00403f 	cmp	x1, x0, lsl #16
    b600:	54000322 	b.cs	b664 <f0+0x1030>  // b.hs, b.nlast
    b604:	d350fc22 	lsr	x2, x1, #16
    b608:	f949fc63 	ldr	x3, [x3, #5112]
    b60c:	8b020842 	add	x2, x2, x2, lsl #2
    b610:	d37df042 	lsl	x2, x2, #3
    b614:	8b020060 	add	x0, x3, x2
    b618:	f9401015 	ldr	x21, [x0, #32]
    b61c:	b4000255 	cbz	x21, b664 <f0+0x1030>
    b620:	38626862 	ldrb	w2, [x3, x2]
    b624:	7100085f 	cmp	w2, #0x2
    b628:	540099a0 	b.eq	c95c <f0+0x2328>  // b.none
    b62c:	7100045f 	cmp	w2, #0x1
    b630:	540001a1 	b.ne	b664 <f0+0x1030>  // b.any
    b634:	29430002 	ldp	w2, w0, [x0, #24]
    b638:	92403c21 	and	x1, x1, #0xffff
    b63c:	9b027c21 	mul	x1, x1, x2
    b640:	d360fc21 	lsr	x1, x1, #32
    b644:	eb00003f 	cmp	x1, x0
    b648:	540000e2 	b.cs	b664 <f0+0x1030>  // b.hs, b.nlast
    b64c:	8b0102b5 	add	x21, x21, x1
    b650:	394002a0 	ldrb	w0, [x21]
    b654:	7103fc1f 	cmp	w0, #0xff
    b658:	5400aa20 	b.eq	cb9c <f0+0x2568>  // b.none
    b65c:	52800020 	mov	w0, #0x1                   	// #1
    b660:	390002a0 	strb	w0, [x21]
    b664:	9111e3e1 	add	x1, sp, #0x478
    b668:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b66c:	52800020 	mov	w0, #0x1                   	// #1
    b670:	f9023ff5 	str	x21, [sp, #1144]
    b674:	f90243f7 	str	x23, [sp, #1152]
    b678:	97ffe8b6 	bl	5950 <fwp_data.part.0.constprop.0>
    b67c:	97ffe939 	bl	5b60 <fwp_rc_fresh>
    b680:	aa0003e2 	mov	x2, x0
    b684:	911223e1 	add	x1, sp, #0x488
    b688:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b68c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b690:	52800020 	mov	w0, #0x1                   	// #1
    b694:	f90247f7 	str	x23, [sp, #1160]
    b698:	f9024be2 	str	x2, [sp, #1168]
    b69c:	97ffe8ad 	bl	5950 <fwp_data.part.0.constprop.0>
    b6a0:	97ffe930 	bl	5b60 <fwp_rc_fresh>
    b6a4:	aa0003e2 	mov	x2, x0
    b6a8:	911263e1 	add	x1, sp, #0x498
    b6ac:	52800020 	mov	w0, #0x1                   	// #1
    b6b0:	f9024ff5 	str	x21, [sp, #1176]
    b6b4:	f90253e2 	str	x2, [sp, #1184]
    b6b8:	97ffe8a6 	bl	5950 <fwp_data.part.0.constprop.0>
    b6bc:	97ffe929 	bl	5b60 <fwp_rc_fresh>
    b6c0:	aa0003e2 	mov	x2, x0
    b6c4:	9112a3e1 	add	x1, sp, #0x4a8
    b6c8:	52800020 	mov	w0, #0x1                   	// #1
    b6cc:	f90257f7 	str	x23, [sp, #1192]
    b6d0:	f9025be2 	str	x2, [sp, #1200]
    b6d4:	97ffe89f 	bl	5950 <fwp_data.part.0.constprop.0>
    b6d8:	97ffe922 	bl	5b60 <fwp_rc_fresh>
    b6dc:	aa0003e2 	mov	x2, x0
    b6e0:	9112e3e1 	add	x1, sp, #0x4b8
    b6e4:	52800020 	mov	w0, #0x1                   	// #1
    b6e8:	f9025ff5 	str	x21, [sp, #1208]
    b6ec:	f90263e2 	str	x2, [sp, #1216]
    b6f0:	97ffe898 	bl	5950 <fwp_data.part.0.constprop.0>
    b6f4:	97ffe91b 	bl	5b60 <fwp_rc_fresh>
    b6f8:	aa0003e2 	mov	x2, x0
    b6fc:	911323e1 	add	x1, sp, #0x4c8
    b700:	52800020 	mov	w0, #0x1                   	// #1
    b704:	f90267f7 	str	x23, [sp, #1224]
    b708:	f9026be2 	str	x2, [sp, #1232]
    b70c:	97ffe891 	bl	5950 <fwp_data.part.0.constprop.0>
    b710:	97ffe914 	bl	5b60 <fwp_rc_fresh>
    b714:	aa0003e2 	mov	x2, x0
    b718:	911363e1 	add	x1, sp, #0x4d8
    b71c:	52800020 	mov	w0, #0x1                   	// #1
    b720:	f9026ff5 	str	x21, [sp, #1240]
    b724:	f90273e2 	str	x2, [sp, #1248]
    b728:	97ffe88a 	bl	5950 <fwp_data.part.0.constprop.0>
    b72c:	91198283 	add	x3, x20, #0x660
    b730:	aa0003f5 	mov	x21, x0
    b734:	f949d861 	ldr	x1, [x3, #5040]
    b738:	f949ec60 	ldr	x0, [x3, #5080]
    b73c:	cb0102a1 	sub	x1, x21, x1
    b740:	eb00403f 	cmp	x1, x0, lsl #16
    b744:	54000322 	b.cs	b7a8 <f0+0x1174>  // b.hs, b.nlast
    b748:	d350fc22 	lsr	x2, x1, #16
    b74c:	f949fc63 	ldr	x3, [x3, #5112]
    b750:	8b020842 	add	x2, x2, x2, lsl #2
    b754:	d37df042 	lsl	x2, x2, #3
    b758:	8b020060 	add	x0, x3, x2
    b75c:	f9401017 	ldr	x23, [x0, #32]
    b760:	b4000257 	cbz	x23, b7a8 <f0+0x1174>
    b764:	38626862 	ldrb	w2, [x3, x2]
    b768:	7100085f 	cmp	w2, #0x2
    b76c:	54008f20 	b.eq	c950 <f0+0x231c>  // b.none
    b770:	7100045f 	cmp	w2, #0x1
    b774:	540001a1 	b.ne	b7a8 <f0+0x1174>  // b.any
    b778:	29430002 	ldp	w2, w0, [x0, #24]
    b77c:	92403c21 	and	x1, x1, #0xffff
    b780:	9b027c21 	mul	x1, x1, x2
    b784:	d360fc21 	lsr	x1, x1, #32
    b788:	eb00003f 	cmp	x1, x0
    b78c:	540000e2 	b.cs	b7a8 <f0+0x1174>  // b.hs, b.nlast
    b790:	8b0102f7 	add	x23, x23, x1
    b794:	394002e0 	ldrb	w0, [x23]
    b798:	7103fc1f 	cmp	w0, #0xff
    b79c:	5400a060 	b.eq	cba8 <f0+0x2574>  // b.none
    b7a0:	52800020 	mov	w0, #0x1                   	// #1
    b7a4:	390002e0 	strb	w0, [x23]
    b7a8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b7ac:	9113a3e1 	add	x1, sp, #0x4e8
    b7b0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b7b4:	52800020 	mov	w0, #0x1                   	// #1
    b7b8:	f90277e2 	str	x2, [sp, #1256]
    b7bc:	f9027bf5 	str	x21, [sp, #1264]
    b7c0:	97ffe864 	bl	5950 <fwp_data.part.0.constprop.0>
    b7c4:	91198283 	add	x3, x20, #0x660
    b7c8:	aa0003f5 	mov	x21, x0
    b7cc:	f949d861 	ldr	x1, [x3, #5040]
    b7d0:	f949ec60 	ldr	x0, [x3, #5080]
    b7d4:	cb0102a1 	sub	x1, x21, x1
    b7d8:	eb00403f 	cmp	x1, x0, lsl #16
    b7dc:	54000322 	b.cs	b840 <f0+0x120c>  // b.hs, b.nlast
    b7e0:	d350fc22 	lsr	x2, x1, #16
    b7e4:	f949fc63 	ldr	x3, [x3, #5112]
    b7e8:	8b020842 	add	x2, x2, x2, lsl #2
    b7ec:	d37df042 	lsl	x2, x2, #3
    b7f0:	8b020060 	add	x0, x3, x2
    b7f4:	f9401017 	ldr	x23, [x0, #32]
    b7f8:	b4000257 	cbz	x23, b840 <f0+0x120c>
    b7fc:	38626862 	ldrb	w2, [x3, x2]
    b800:	7100085f 	cmp	w2, #0x2
    b804:	54008a00 	b.eq	c944 <f0+0x2310>  // b.none
    b808:	7100045f 	cmp	w2, #0x1
    b80c:	540001a1 	b.ne	b840 <f0+0x120c>  // b.any
    b810:	29430002 	ldp	w2, w0, [x0, #24]
    b814:	92403c21 	and	x1, x1, #0xffff
    b818:	9b027c21 	mul	x1, x1, x2
    b81c:	d360fc21 	lsr	x1, x1, #32
    b820:	eb00003f 	cmp	x1, x0
    b824:	540000e2 	b.cs	b840 <f0+0x120c>  // b.hs, b.nlast
    b828:	8b0102f7 	add	x23, x23, x1
    b82c:	394002e0 	ldrb	w0, [x23]
    b830:	7103fc1f 	cmp	w0, #0xff
    b834:	54009c00 	b.eq	cbb4 <f0+0x2580>  // b.none
    b838:	52800020 	mov	w0, #0x1                   	// #1
    b83c:	390002e0 	strb	w0, [x23]
    b840:	9113e3e1 	add	x1, sp, #0x4f8
    b844:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b848:	52800020 	mov	w0, #0x1                   	// #1
    b84c:	f9027fe2 	str	x2, [sp, #1272]
    b850:	f90283f5 	str	x21, [sp, #1280]
    b854:	97ffe83f 	bl	5950 <fwp_data.part.0.constprop.0>
    b858:	97ffe8c2 	bl	5b60 <fwp_rc_fresh>
    b85c:	aa0003e2 	mov	x2, x0
    b860:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b864:	911423e1 	add	x1, sp, #0x508
    b868:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b86c:	52800020 	mov	w0, #0x1                   	// #1
    b870:	f90287e3 	str	x3, [sp, #1288]
    b874:	f9028be2 	str	x2, [sp, #1296]
    b878:	97ffe836 	bl	5950 <fwp_data.part.0.constprop.0>
    b87c:	91198283 	add	x3, x20, #0x660
    b880:	aa0003f5 	mov	x21, x0
    b884:	f949d861 	ldr	x1, [x3, #5040]
    b888:	f949ec60 	ldr	x0, [x3, #5080]
    b88c:	cb0102a1 	sub	x1, x21, x1
    b890:	eb00403f 	cmp	x1, x0, lsl #16
    b894:	54000322 	b.cs	b8f8 <f0+0x12c4>  // b.hs, b.nlast
    b898:	d350fc22 	lsr	x2, x1, #16
    b89c:	f949fc63 	ldr	x3, [x3, #5112]
    b8a0:	8b020842 	add	x2, x2, x2, lsl #2
    b8a4:	d37df042 	lsl	x2, x2, #3
    b8a8:	8b020060 	add	x0, x3, x2
    b8ac:	f9401017 	ldr	x23, [x0, #32]
    b8b0:	b4000257 	cbz	x23, b8f8 <f0+0x12c4>
    b8b4:	38626862 	ldrb	w2, [x3, x2]
    b8b8:	7100085f 	cmp	w2, #0x2
    b8bc:	540083e0 	b.eq	c938 <f0+0x2304>  // b.none
    b8c0:	7100045f 	cmp	w2, #0x1
    b8c4:	540001a1 	b.ne	b8f8 <f0+0x12c4>  // b.any
    b8c8:	29430002 	ldp	w2, w0, [x0, #24]
    b8cc:	92403c21 	and	x1, x1, #0xffff
    b8d0:	9b027c21 	mul	x1, x1, x2
    b8d4:	d360fc21 	lsr	x1, x1, #32
    b8d8:	eb00003f 	cmp	x1, x0
    b8dc:	540000e2 	b.cs	b8f8 <f0+0x12c4>  // b.hs, b.nlast
    b8e0:	8b0102f7 	add	x23, x23, x1
    b8e4:	394002e0 	ldrb	w0, [x23]
    b8e8:	7103fc1f 	cmp	w0, #0xff
    b8ec:	540096a0 	b.eq	cbc0 <f0+0x258c>  // b.none
    b8f0:	52800020 	mov	w0, #0x1                   	// #1
    b8f4:	390002e0 	strb	w0, [x23]
    b8f8:	911463e1 	add	x1, sp, #0x518
    b8fc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b900:	52800020 	mov	w0, #0x1                   	// #1
    b904:	f9028fe2 	str	x2, [sp, #1304]
    b908:	f90293f5 	str	x21, [sp, #1312]
    b90c:	97ffe811 	bl	5950 <fwp_data.part.0.constprop.0>
    b910:	97ffe894 	bl	5b60 <fwp_rc_fresh>
    b914:	aa0003e2 	mov	x2, x0
    b918:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b91c:	9114a3e1 	add	x1, sp, #0x528
    b920:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b924:	52800020 	mov	w0, #0x1                   	// #1
    b928:	f90297e3 	str	x3, [sp, #1320]
    b92c:	f9029be2 	str	x2, [sp, #1328]
    b930:	97ffe808 	bl	5950 <fwp_data.part.0.constprop.0>
    b934:	91198283 	add	x3, x20, #0x660
    b938:	aa0003f5 	mov	x21, x0
    b93c:	f949d861 	ldr	x1, [x3, #5040]
    b940:	f949ec60 	ldr	x0, [x3, #5080]
    b944:	cb0102a1 	sub	x1, x21, x1
    b948:	eb00403f 	cmp	x1, x0, lsl #16
    b94c:	54000322 	b.cs	b9b0 <f0+0x137c>  // b.hs, b.nlast
    b950:	d350fc22 	lsr	x2, x1, #16
    b954:	f949fc63 	ldr	x3, [x3, #5112]
    b958:	8b020842 	add	x2, x2, x2, lsl #2
    b95c:	d37df042 	lsl	x2, x2, #3
    b960:	8b020060 	add	x0, x3, x2
    b964:	f9401017 	ldr	x23, [x0, #32]
    b968:	b4000257 	cbz	x23, b9b0 <f0+0x137c>
    b96c:	38626862 	ldrb	w2, [x3, x2]
    b970:	7100085f 	cmp	w2, #0x2
    b974:	54007dc0 	b.eq	c92c <f0+0x22f8>  // b.none
    b978:	7100045f 	cmp	w2, #0x1
    b97c:	540001a1 	b.ne	b9b0 <f0+0x137c>  // b.any
    b980:	29430002 	ldp	w2, w0, [x0, #24]
    b984:	92403c21 	and	x1, x1, #0xffff
    b988:	9b027c21 	mul	x1, x1, x2
    b98c:	d360fc21 	lsr	x1, x1, #32
    b990:	eb00003f 	cmp	x1, x0
    b994:	540000e2 	b.cs	b9b0 <f0+0x137c>  // b.hs, b.nlast
    b998:	8b0102f7 	add	x23, x23, x1
    b99c:	394002e0 	ldrb	w0, [x23]
    b9a0:	7103fc1f 	cmp	w0, #0xff
    b9a4:	54009140 	b.eq	cbcc <f0+0x2598>  // b.none
    b9a8:	52800020 	mov	w0, #0x1                   	// #1
    b9ac:	390002e0 	strb	w0, [x23]
    b9b0:	9114e3e1 	add	x1, sp, #0x538
    b9b4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b9b8:	52800020 	mov	w0, #0x1                   	// #1
    b9bc:	f9029fe2 	str	x2, [sp, #1336]
    b9c0:	f902a3f5 	str	x21, [sp, #1344]
    b9c4:	97ffe7e3 	bl	5950 <fwp_data.part.0.constprop.0>
    b9c8:	97ffe866 	bl	5b60 <fwp_rc_fresh>
    b9cc:	aa0003e2 	mov	x2, x0
    b9d0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b9d4:	911523e1 	add	x1, sp, #0x548
    b9d8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b9dc:	52800020 	mov	w0, #0x1                   	// #1
    b9e0:	f902a7e3 	str	x3, [sp, #1352]
    b9e4:	f902abe2 	str	x2, [sp, #1360]
    b9e8:	97ffe7da 	bl	5950 <fwp_data.part.0.constprop.0>
    b9ec:	91198283 	add	x3, x20, #0x660
    b9f0:	aa0003f5 	mov	x21, x0
    b9f4:	f949d861 	ldr	x1, [x3, #5040]
    b9f8:	f949ec60 	ldr	x0, [x3, #5080]
    b9fc:	cb0102a1 	sub	x1, x21, x1
    ba00:	eb00403f 	cmp	x1, x0, lsl #16
    ba04:	54000322 	b.cs	ba68 <f0+0x1434>  // b.hs, b.nlast
    ba08:	d350fc22 	lsr	x2, x1, #16
    ba0c:	f949fc63 	ldr	x3, [x3, #5112]
    ba10:	8b020842 	add	x2, x2, x2, lsl #2
    ba14:	d37df042 	lsl	x2, x2, #3
    ba18:	8b020060 	add	x0, x3, x2
    ba1c:	f9401017 	ldr	x23, [x0, #32]
    ba20:	b4000257 	cbz	x23, ba68 <f0+0x1434>
    ba24:	38626862 	ldrb	w2, [x3, x2]
    ba28:	7100085f 	cmp	w2, #0x2
    ba2c:	540077a0 	b.eq	c920 <f0+0x22ec>  // b.none
    ba30:	7100045f 	cmp	w2, #0x1
    ba34:	540001a1 	b.ne	ba68 <f0+0x1434>  // b.any
    ba38:	29430002 	ldp	w2, w0, [x0, #24]
    ba3c:	92403c21 	and	x1, x1, #0xffff
    ba40:	9b027c21 	mul	x1, x1, x2
    ba44:	d360fc21 	lsr	x1, x1, #32
    ba48:	eb00003f 	cmp	x1, x0
    ba4c:	540000e2 	b.cs	ba68 <f0+0x1434>  // b.hs, b.nlast
    ba50:	8b0102f7 	add	x23, x23, x1
    ba54:	394002e0 	ldrb	w0, [x23]
    ba58:	7103fc1f 	cmp	w0, #0xff
    ba5c:	54008be0 	b.eq	cbd8 <f0+0x25a4>  // b.none
    ba60:	52800020 	mov	w0, #0x1                   	// #1
    ba64:	390002e0 	strb	w0, [x23]
    ba68:	911563e1 	add	x1, sp, #0x558
    ba6c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba70:	52800020 	mov	w0, #0x1                   	// #1
    ba74:	f902afe2 	str	x2, [sp, #1368]
    ba78:	f902b3f5 	str	x21, [sp, #1376]
    ba7c:	97ffe7b5 	bl	5950 <fwp_data.part.0.constprop.0>
    ba80:	97ffe838 	bl	5b60 <fwp_rc_fresh>
    ba84:	aa0003e2 	mov	x2, x0
    ba88:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ba8c:	9115a3e1 	add	x1, sp, #0x568
    ba90:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ba94:	52800020 	mov	w0, #0x1                   	// #1
    ba98:	f902b7e3 	str	x3, [sp, #1384]
    ba9c:	f902bbe2 	str	x2, [sp, #1392]
    baa0:	97ffe7ac 	bl	5950 <fwp_data.part.0.constprop.0>
    baa4:	91198283 	add	x3, x20, #0x660
    baa8:	aa0003f5 	mov	x21, x0
    baac:	f949d861 	ldr	x1, [x3, #5040]
    bab0:	f949ec60 	ldr	x0, [x3, #5080]
    bab4:	cb0102a1 	sub	x1, x21, x1
    bab8:	eb00403f 	cmp	x1, x0, lsl #16
    babc:	54000322 	b.cs	bb20 <f0+0x14ec>  // b.hs, b.nlast
    bac0:	d350fc22 	lsr	x2, x1, #16
    bac4:	f949fc63 	ldr	x3, [x3, #5112]
    bac8:	8b020842 	add	x2, x2, x2, lsl #2
    bacc:	d37df042 	lsl	x2, x2, #3
    bad0:	8b020060 	add	x0, x3, x2
    bad4:	f9401017 	ldr	x23, [x0, #32]
    bad8:	b4000257 	cbz	x23, bb20 <f0+0x14ec>
    badc:	38626862 	ldrb	w2, [x3, x2]
    bae0:	7100085f 	cmp	w2, #0x2
    bae4:	54007180 	b.eq	c914 <f0+0x22e0>  // b.none
    bae8:	7100045f 	cmp	w2, #0x1
    baec:	540001a1 	b.ne	bb20 <f0+0x14ec>  // b.any
    baf0:	29430002 	ldp	w2, w0, [x0, #24]
    baf4:	92403c21 	and	x1, x1, #0xffff
    baf8:	9b027c21 	mul	x1, x1, x2
    bafc:	d360fc21 	lsr	x1, x1, #32
    bb00:	eb00003f 	cmp	x1, x0
    bb04:	540000e2 	b.cs	bb20 <f0+0x14ec>  // b.hs, b.nlast
    bb08:	8b0102f7 	add	x23, x23, x1
    bb0c:	394002e0 	ldrb	w0, [x23]
    bb10:	7103fc1f 	cmp	w0, #0xff
    bb14:	54008680 	b.eq	cbe4 <f0+0x25b0>  // b.none
    bb18:	52800020 	mov	w0, #0x1                   	// #1
    bb1c:	390002e0 	strb	w0, [x23]
    bb20:	9115e3e1 	add	x1, sp, #0x578
    bb24:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bb28:	52800020 	mov	w0, #0x1                   	// #1
    bb2c:	f902bfe2 	str	x2, [sp, #1400]
    bb30:	f902c3f5 	str	x21, [sp, #1408]
    bb34:	97ffe787 	bl	5950 <fwp_data.part.0.constprop.0>
    bb38:	97ffe80a 	bl	5b60 <fwp_rc_fresh>
    bb3c:	aa0003e2 	mov	x2, x0
    bb40:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bb44:	911623e1 	add	x1, sp, #0x588
    bb48:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bb4c:	52800020 	mov	w0, #0x1                   	// #1
    bb50:	f902c7e3 	str	x3, [sp, #1416]
    bb54:	f902cbe2 	str	x2, [sp, #1424]
    bb58:	97ffe77e 	bl	5950 <fwp_data.part.0.constprop.0>
    bb5c:	91198283 	add	x3, x20, #0x660
    bb60:	aa0003f5 	mov	x21, x0
    bb64:	f949d861 	ldr	x1, [x3, #5040]
    bb68:	f949ec60 	ldr	x0, [x3, #5080]
    bb6c:	cb0102a1 	sub	x1, x21, x1
    bb70:	eb00403f 	cmp	x1, x0, lsl #16
    bb74:	54000322 	b.cs	bbd8 <f0+0x15a4>  // b.hs, b.nlast
    bb78:	d350fc22 	lsr	x2, x1, #16
    bb7c:	f949fc63 	ldr	x3, [x3, #5112]
    bb80:	8b020842 	add	x2, x2, x2, lsl #2
    bb84:	d37df042 	lsl	x2, x2, #3
    bb88:	8b020060 	add	x0, x3, x2
    bb8c:	f9401017 	ldr	x23, [x0, #32]
    bb90:	b4000257 	cbz	x23, bbd8 <f0+0x15a4>
    bb94:	38626862 	ldrb	w2, [x3, x2]
    bb98:	7100085f 	cmp	w2, #0x2
    bb9c:	54006b60 	b.eq	c908 <f0+0x22d4>  // b.none
    bba0:	7100045f 	cmp	w2, #0x1
    bba4:	540001a1 	b.ne	bbd8 <f0+0x15a4>  // b.any
    bba8:	29430002 	ldp	w2, w0, [x0, #24]
    bbac:	92403c21 	and	x1, x1, #0xffff
    bbb0:	9b027c21 	mul	x1, x1, x2
    bbb4:	d360fc21 	lsr	x1, x1, #32
    bbb8:	eb00003f 	cmp	x1, x0
    bbbc:	540000e2 	b.cs	bbd8 <f0+0x15a4>  // b.hs, b.nlast
    bbc0:	8b0102f7 	add	x23, x23, x1
    bbc4:	394002e0 	ldrb	w0, [x23]
    bbc8:	7103fc1f 	cmp	w0, #0xff
    bbcc:	54008120 	b.eq	cbf0 <f0+0x25bc>  // b.none
    bbd0:	52800020 	mov	w0, #0x1                   	// #1
    bbd4:	390002e0 	strb	w0, [x23]
    bbd8:	911663e1 	add	x1, sp, #0x598
    bbdc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	f902cfe2 	str	x2, [sp, #1432]
    bbe8:	f902d3f5 	str	x21, [sp, #1440]
    bbec:	97ffe759 	bl	5950 <fwp_data.part.0.constprop.0>
    bbf0:	97ffe7dc 	bl	5b60 <fwp_rc_fresh>
    bbf4:	aa0003e2 	mov	x2, x0
    bbf8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bbfc:	9116a3e1 	add	x1, sp, #0x5a8
    bc00:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bc04:	52800020 	mov	w0, #0x1                   	// #1
    bc08:	f902d7e3 	str	x3, [sp, #1448]
    bc0c:	f902dbe2 	str	x2, [sp, #1456]
    bc10:	97ffe750 	bl	5950 <fwp_data.part.0.constprop.0>
    bc14:	91198283 	add	x3, x20, #0x660
    bc18:	aa0003f5 	mov	x21, x0
    bc1c:	f949d861 	ldr	x1, [x3, #5040]
    bc20:	f949ec60 	ldr	x0, [x3, #5080]
    bc24:	cb0102a1 	sub	x1, x21, x1
    bc28:	eb00403f 	cmp	x1, x0, lsl #16
    bc2c:	54000322 	b.cs	bc90 <f0+0x165c>  // b.hs, b.nlast
    bc30:	d350fc22 	lsr	x2, x1, #16
    bc34:	f949fc63 	ldr	x3, [x3, #5112]
    bc38:	8b020842 	add	x2, x2, x2, lsl #2
    bc3c:	d37df042 	lsl	x2, x2, #3
    bc40:	8b020060 	add	x0, x3, x2
    bc44:	f9401017 	ldr	x23, [x0, #32]
    bc48:	b4000257 	cbz	x23, bc90 <f0+0x165c>
    bc4c:	38626862 	ldrb	w2, [x3, x2]
    bc50:	7100085f 	cmp	w2, #0x2
    bc54:	540073e0 	b.eq	cad0 <f0+0x249c>  // b.none
    bc58:	7100045f 	cmp	w2, #0x1
    bc5c:	540001a1 	b.ne	bc90 <f0+0x165c>  // b.any
    bc60:	29430002 	ldp	w2, w0, [x0, #24]
    bc64:	92403c21 	and	x1, x1, #0xffff
    bc68:	9b027c21 	mul	x1, x1, x2
    bc6c:	d360fc21 	lsr	x1, x1, #32
    bc70:	eb00003f 	cmp	x1, x0
    bc74:	540000e2 	b.cs	bc90 <f0+0x165c>  // b.hs, b.nlast
    bc78:	8b0102f7 	add	x23, x23, x1
    bc7c:	394002e0 	ldrb	w0, [x23]
    bc80:	7103fc1f 	cmp	w0, #0xff
    bc84:	54007bc0 	b.eq	cbfc <f0+0x25c8>  // b.none
    bc88:	52800020 	mov	w0, #0x1                   	// #1
    bc8c:	390002e0 	strb	w0, [x23]
    bc90:	9116e3e1 	add	x1, sp, #0x5b8
    bc94:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bc98:	52800020 	mov	w0, #0x1                   	// #1
    bc9c:	f902dff7 	str	x23, [sp, #1464]
    bca0:	f902e3f5 	str	x21, [sp, #1472]
    bca4:	97ffe72b 	bl	5950 <fwp_data.part.0.constprop.0>
    bca8:	97ffe7ae 	bl	5b60 <fwp_rc_fresh>
    bcac:	aa0003e2 	mov	x2, x0
    bcb0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bcb4:	911723e1 	add	x1, sp, #0x5c8
    bcb8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bcbc:	52800020 	mov	w0, #0x1                   	// #1
    bcc0:	f902e7e3 	str	x3, [sp, #1480]
    bcc4:	f902ebe2 	str	x2, [sp, #1488]
    bcc8:	97ffe722 	bl	5950 <fwp_data.part.0.constprop.0>
    bccc:	97ffe7a5 	bl	5b60 <fwp_rc_fresh>
    bcd0:	aa0003e2 	mov	x2, x0
    bcd4:	911763e1 	add	x1, sp, #0x5d8
    bcd8:	52800020 	mov	w0, #0x1                   	// #1
    bcdc:	f902eff7 	str	x23, [sp, #1496]
    bce0:	f902f3e2 	str	x2, [sp, #1504]
    bce4:	97ffe71b 	bl	5950 <fwp_data.part.0.constprop.0>
    bce8:	91198283 	add	x3, x20, #0x660
    bcec:	aa0003f5 	mov	x21, x0
    bcf0:	f949d861 	ldr	x1, [x3, #5040]
    bcf4:	f949ec60 	ldr	x0, [x3, #5080]
    bcf8:	cb0102a1 	sub	x1, x21, x1
    bcfc:	eb00403f 	cmp	x1, x0, lsl #16
    bd00:	54000322 	b.cs	bd64 <f0+0x1730>  // b.hs, b.nlast
    bd04:	d350fc22 	lsr	x2, x1, #16
    bd08:	f949fc63 	ldr	x3, [x3, #5112]
    bd0c:	8b020842 	add	x2, x2, x2, lsl #2
    bd10:	d37df042 	lsl	x2, x2, #3
    bd14:	8b020060 	add	x0, x3, x2
    bd18:	f9401017 	ldr	x23, [x0, #32]
    bd1c:	b4000257 	cbz	x23, bd64 <f0+0x1730>
    bd20:	38626862 	ldrb	w2, [x3, x2]
    bd24:	7100085f 	cmp	w2, #0x2
    bd28:	54006ce0 	b.eq	cac4 <f0+0x2490>  // b.none
    bd2c:	7100045f 	cmp	w2, #0x1
    bd30:	540001a1 	b.ne	bd64 <f0+0x1730>  // b.any
    bd34:	29430002 	ldp	w2, w0, [x0, #24]
    bd38:	92403c21 	and	x1, x1, #0xffff
    bd3c:	9b027c21 	mul	x1, x1, x2
    bd40:	d360fc21 	lsr	x1, x1, #32
    bd44:	eb00003f 	cmp	x1, x0
    bd48:	540000e2 	b.cs	bd64 <f0+0x1730>  // b.hs, b.nlast
    bd4c:	8b0102f7 	add	x23, x23, x1
    bd50:	394002e0 	ldrb	w0, [x23]
    bd54:	7103fc1f 	cmp	w0, #0xff
    bd58:	54007580 	b.eq	cc08 <f0+0x25d4>  // b.none
    bd5c:	52800020 	mov	w0, #0x1                   	// #1
    bd60:	390002e0 	strb	w0, [x23]
    bd64:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bd68:	9117a3e1 	add	x1, sp, #0x5e8
    bd6c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bd70:	52800020 	mov	w0, #0x1                   	// #1
    bd74:	f902f7e2 	str	x2, [sp, #1512]
    bd78:	f902fbf5 	str	x21, [sp, #1520]
    bd7c:	97ffe6f5 	bl	5950 <fwp_data.part.0.constprop.0>
    bd80:	91198283 	add	x3, x20, #0x660
    bd84:	aa0003f5 	mov	x21, x0
    bd88:	f949d861 	ldr	x1, [x3, #5040]
    bd8c:	f949ec60 	ldr	x0, [x3, #5080]
    bd90:	cb0102a1 	sub	x1, x21, x1
    bd94:	eb00403f 	cmp	x1, x0, lsl #16
    bd98:	54000322 	b.cs	bdfc <f0+0x17c8>  // b.hs, b.nlast
    bd9c:	d350fc22 	lsr	x2, x1, #16
    bda0:	f949fc63 	ldr	x3, [x3, #5112]
    bda4:	8b020842 	add	x2, x2, x2, lsl #2
    bda8:	d37df042 	lsl	x2, x2, #3
    bdac:	8b020060 	add	x0, x3, x2
    bdb0:	f9401017 	ldr	x23, [x0, #32]
    bdb4:	b4000257 	cbz	x23, bdfc <f0+0x17c8>
    bdb8:	38626862 	ldrb	w2, [x3, x2]
    bdbc:	7100085f 	cmp	w2, #0x2
    bdc0:	540067c0 	b.eq	cab8 <f0+0x2484>  // b.none
    bdc4:	7100045f 	cmp	w2, #0x1
    bdc8:	540001a1 	b.ne	bdfc <f0+0x17c8>  // b.any
    bdcc:	29430002 	ldp	w2, w0, [x0, #24]
    bdd0:	92403c21 	and	x1, x1, #0xffff
    bdd4:	9b027c21 	mul	x1, x1, x2
    bdd8:	d360fc21 	lsr	x1, x1, #32
    bddc:	eb00003f 	cmp	x1, x0
    bde0:	540000e2 	b.cs	bdfc <f0+0x17c8>  // b.hs, b.nlast
    bde4:	8b0102f7 	add	x23, x23, x1
    bde8:	394002e0 	ldrb	w0, [x23]
    bdec:	7103fc1f 	cmp	w0, #0xff
    bdf0:	54007120 	b.eq	cc14 <f0+0x25e0>  // b.none
    bdf4:	52800020 	mov	w0, #0x1                   	// #1
    bdf8:	390002e0 	strb	w0, [x23]
    bdfc:	9117e3e1 	add	x1, sp, #0x5f8
    be00:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    be04:	52800020 	mov	w0, #0x1                   	// #1
    be08:	f902fff7 	str	x23, [sp, #1528]
    be0c:	f90303f5 	str	x21, [sp, #1536]
    be10:	97ffe6d0 	bl	5950 <fwp_data.part.0.constprop.0>
    be14:	97ffe753 	bl	5b60 <fwp_rc_fresh>
    be18:	aa0003e2 	mov	x2, x0
    be1c:	911823e1 	add	x1, sp, #0x608
    be20:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    be24:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    be28:	52800020 	mov	w0, #0x1                   	// #1
    be2c:	f90307f5 	str	x21, [sp, #1544]
    be30:	f9030be2 	str	x2, [sp, #1552]
    be34:	97ffe6c7 	bl	5950 <fwp_data.part.0.constprop.0>
    be38:	97ffe74a 	bl	5b60 <fwp_rc_fresh>
    be3c:	aa0003e2 	mov	x2, x0
    be40:	911863e1 	add	x1, sp, #0x618
    be44:	52800020 	mov	w0, #0x1                   	// #1
    be48:	f9030ff7 	str	x23, [sp, #1560]
    be4c:	f90313e2 	str	x2, [sp, #1568]
    be50:	97ffe6c0 	bl	5950 <fwp_data.part.0.constprop.0>
    be54:	97ffe743 	bl	5b60 <fwp_rc_fresh>
    be58:	aa0003e2 	mov	x2, x0
    be5c:	9118a3e1 	add	x1, sp, #0x628
    be60:	52800020 	mov	w0, #0x1                   	// #1
    be64:	f90317f5 	str	x21, [sp, #1576]
    be68:	f9031be2 	str	x2, [sp, #1584]
    be6c:	97ffe6b9 	bl	5950 <fwp_data.part.0.constprop.0>
    be70:	91198283 	add	x3, x20, #0x660
    be74:	aa0003f5 	mov	x21, x0
    be78:	f949d861 	ldr	x1, [x3, #5040]
    be7c:	f949ec60 	ldr	x0, [x3, #5080]
    be80:	cb0102a1 	sub	x1, x21, x1
    be84:	eb00403f 	cmp	x1, x0, lsl #16
    be88:	54000322 	b.cs	beec <f0+0x18b8>  // b.hs, b.nlast
    be8c:	d350fc22 	lsr	x2, x1, #16
    be90:	f949fc63 	ldr	x3, [x3, #5112]
    be94:	8b020842 	add	x2, x2, x2, lsl #2
    be98:	d37df042 	lsl	x2, x2, #3
    be9c:	8b020060 	add	x0, x3, x2
    bea0:	f9401017 	ldr	x23, [x0, #32]
    bea4:	b4000257 	cbz	x23, beec <f0+0x18b8>
    bea8:	38626862 	ldrb	w2, [x3, x2]
    beac:	7100085f 	cmp	w2, #0x2
    beb0:	54005fe0 	b.eq	caac <f0+0x2478>  // b.none
    beb4:	7100045f 	cmp	w2, #0x1
    beb8:	540001a1 	b.ne	beec <f0+0x18b8>  // b.any
    bebc:	29430002 	ldp	w2, w0, [x0, #24]
    bec0:	92403c21 	and	x1, x1, #0xffff
    bec4:	9b027c21 	mul	x1, x1, x2
    bec8:	d360fc21 	lsr	x1, x1, #32
    becc:	eb00003f 	cmp	x1, x0
    bed0:	540000e2 	b.cs	beec <f0+0x18b8>  // b.hs, b.nlast
    bed4:	8b0102f7 	add	x23, x23, x1
    bed8:	394002e0 	ldrb	w0, [x23]
    bedc:	7103fc1f 	cmp	w0, #0xff
    bee0:	54006a00 	b.eq	cc20 <f0+0x25ec>  // b.none
    bee4:	52800020 	mov	w0, #0x1                   	// #1
    bee8:	390002e0 	strb	w0, [x23]
    beec:	9118e3e1 	add	x1, sp, #0x638
    bef0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bef4:	52800020 	mov	w0, #0x1                   	// #1
    bef8:	f9031ff7 	str	x23, [sp, #1592]
    befc:	f90323f5 	str	x21, [sp, #1600]
    bf00:	97ffe694 	bl	5950 <fwp_data.part.0.constprop.0>
    bf04:	97ffe717 	bl	5b60 <fwp_rc_fresh>
    bf08:	aa0003e2 	mov	x2, x0
    bf0c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bf10:	911923e1 	add	x1, sp, #0x648
    bf14:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bf18:	52800020 	mov	w0, #0x1                   	// #1
    bf1c:	f90327e3 	str	x3, [sp, #1608]
    bf20:	f9032be2 	str	x2, [sp, #1616]
    bf24:	97ffe68b 	bl	5950 <fwp_data.part.0.constprop.0>
    bf28:	97ffe70e 	bl	5b60 <fwp_rc_fresh>
    bf2c:	aa0003e2 	mov	x2, x0
    bf30:	911963e1 	add	x1, sp, #0x658
    bf34:	52800020 	mov	w0, #0x1                   	// #1
    bf38:	f9032ff7 	str	x23, [sp, #1624]
    bf3c:	f90333e2 	str	x2, [sp, #1632]
    bf40:	97ffe684 	bl	5950 <fwp_data.part.0.constprop.0>
    bf44:	91198283 	add	x3, x20, #0x660
    bf48:	aa0003f5 	mov	x21, x0
    bf4c:	f949d861 	ldr	x1, [x3, #5040]
    bf50:	f949ec60 	ldr	x0, [x3, #5080]
    bf54:	cb0102a1 	sub	x1, x21, x1
    bf58:	eb00403f 	cmp	x1, x0, lsl #16
    bf5c:	54000322 	b.cs	bfc0 <f0+0x198c>  // b.hs, b.nlast
    bf60:	d350fc22 	lsr	x2, x1, #16
    bf64:	f949fc63 	ldr	x3, [x3, #5112]
    bf68:	8b020842 	add	x2, x2, x2, lsl #2
    bf6c:	d37df042 	lsl	x2, x2, #3
    bf70:	8b020060 	add	x0, x3, x2
    bf74:	f9401017 	ldr	x23, [x0, #32]
    bf78:	b4000257 	cbz	x23, bfc0 <f0+0x198c>
    bf7c:	38626862 	ldrb	w2, [x3, x2]
    bf80:	7100085f 	cmp	w2, #0x2
    bf84:	540058e0 	b.eq	caa0 <f0+0x246c>  // b.none
    bf88:	7100045f 	cmp	w2, #0x1
    bf8c:	540001a1 	b.ne	bfc0 <f0+0x198c>  // b.any
    bf90:	29430002 	ldp	w2, w0, [x0, #24]
    bf94:	92403c21 	and	x1, x1, #0xffff
    bf98:	9b027c21 	mul	x1, x1, x2
    bf9c:	d360fc21 	lsr	x1, x1, #32
    bfa0:	eb00003f 	cmp	x1, x0
    bfa4:	540000e2 	b.cs	bfc0 <f0+0x198c>  // b.hs, b.nlast
    bfa8:	8b0102f7 	add	x23, x23, x1
    bfac:	394002e0 	ldrb	w0, [x23]
    bfb0:	7103fc1f 	cmp	w0, #0xff
    bfb4:	540063c0 	b.eq	cc2c <f0+0x25f8>  // b.none
    bfb8:	52800020 	mov	w0, #0x1                   	// #1
    bfbc:	390002e0 	strb	w0, [x23]
    bfc0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bfc4:	9119a3e1 	add	x1, sp, #0x668
    bfc8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bfcc:	52800020 	mov	w0, #0x1                   	// #1
    bfd0:	f90337e2 	str	x2, [sp, #1640]
    bfd4:	f9033bf5 	str	x21, [sp, #1648]
    bfd8:	97ffe65e 	bl	5950 <fwp_data.part.0.constprop.0>
    bfdc:	91198283 	add	x3, x20, #0x660
    bfe0:	aa0003f5 	mov	x21, x0
    bfe4:	f949d861 	ldr	x1, [x3, #5040]
    bfe8:	f949ec60 	ldr	x0, [x3, #5080]
    bfec:	cb0102a1 	sub	x1, x21, x1
    bff0:	eb00403f 	cmp	x1, x0, lsl #16
    bff4:	54000322 	b.cs	c058 <f0+0x1a24>  // b.hs, b.nlast
    bff8:	d350fc22 	lsr	x2, x1, #16
    bffc:	f949fc63 	ldr	x3, [x3, #5112]
    c000:	8b020842 	add	x2, x2, x2, lsl #2
    c004:	d37df042 	lsl	x2, x2, #3
    c008:	8b020060 	add	x0, x3, x2
    c00c:	f9401017 	ldr	x23, [x0, #32]
    c010:	b4000257 	cbz	x23, c058 <f0+0x1a24>
    c014:	38626862 	ldrb	w2, [x3, x2]
    c018:	7100085f 	cmp	w2, #0x2
    c01c:	540053c0 	b.eq	ca94 <f0+0x2460>  // b.none
    c020:	7100045f 	cmp	w2, #0x1
    c024:	540001a1 	b.ne	c058 <f0+0x1a24>  // b.any
    c028:	29430002 	ldp	w2, w0, [x0, #24]
    c02c:	92403c21 	and	x1, x1, #0xffff
    c030:	9b027c21 	mul	x1, x1, x2
    c034:	d360fc21 	lsr	x1, x1, #32
    c038:	eb00003f 	cmp	x1, x0
    c03c:	540000e2 	b.cs	c058 <f0+0x1a24>  // b.hs, b.nlast
    c040:	8b0102f7 	add	x23, x23, x1
    c044:	394002e0 	ldrb	w0, [x23]
    c048:	7103fc1f 	cmp	w0, #0xff
    c04c:	54005f60 	b.eq	cc38 <f0+0x2604>  // b.none
    c050:	52800020 	mov	w0, #0x1                   	// #1
    c054:	390002e0 	strb	w0, [x23]
    c058:	9119e3e1 	add	x1, sp, #0x678
    c05c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c060:	52800020 	mov	w0, #0x1                   	// #1
    c064:	f9033fe2 	str	x2, [sp, #1656]
    c068:	f90343f5 	str	x21, [sp, #1664]
    c06c:	97ffe639 	bl	5950 <fwp_data.part.0.constprop.0>
    c070:	97ffe6bc 	bl	5b60 <fwp_rc_fresh>
    c074:	aa0003e2 	mov	x2, x0
    c078:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c07c:	911a23e1 	add	x1, sp, #0x688
    c080:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c084:	52800020 	mov	w0, #0x1                   	// #1
    c088:	f90347e3 	str	x3, [sp, #1672]
    c08c:	f9034be2 	str	x2, [sp, #1680]
    c090:	97ffe630 	bl	5950 <fwp_data.part.0.constprop.0>
    c094:	91198283 	add	x3, x20, #0x660
    c098:	aa0003f5 	mov	x21, x0
    c09c:	f949d861 	ldr	x1, [x3, #5040]
    c0a0:	f949ec60 	ldr	x0, [x3, #5080]
    c0a4:	cb0102a1 	sub	x1, x21, x1
    c0a8:	eb00403f 	cmp	x1, x0, lsl #16
    c0ac:	54000322 	b.cs	c110 <f0+0x1adc>  // b.hs, b.nlast
    c0b0:	d350fc22 	lsr	x2, x1, #16
    c0b4:	f949fc63 	ldr	x3, [x3, #5112]
    c0b8:	8b020842 	add	x2, x2, x2, lsl #2
    c0bc:	d37df042 	lsl	x2, x2, #3
    c0c0:	8b020060 	add	x0, x3, x2
    c0c4:	f9401017 	ldr	x23, [x0, #32]
    c0c8:	b4000257 	cbz	x23, c110 <f0+0x1adc>
    c0cc:	38626862 	ldrb	w2, [x3, x2]
    c0d0:	7100085f 	cmp	w2, #0x2
    c0d4:	54004da0 	b.eq	ca88 <f0+0x2454>  // b.none
    c0d8:	7100045f 	cmp	w2, #0x1
    c0dc:	540001a1 	b.ne	c110 <f0+0x1adc>  // b.any
    c0e0:	29430002 	ldp	w2, w0, [x0, #24]
    c0e4:	92403c21 	and	x1, x1, #0xffff
    c0e8:	9b027c21 	mul	x1, x1, x2
    c0ec:	d360fc21 	lsr	x1, x1, #32
    c0f0:	eb00003f 	cmp	x1, x0
    c0f4:	540000e2 	b.cs	c110 <f0+0x1adc>  // b.hs, b.nlast
    c0f8:	8b0102f7 	add	x23, x23, x1
    c0fc:	394002e0 	ldrb	w0, [x23]
    c100:	7103fc1f 	cmp	w0, #0xff
    c104:	54005a00 	b.eq	cc44 <f0+0x2610>  // b.none
    c108:	52800020 	mov	w0, #0x1                   	// #1
    c10c:	390002e0 	strb	w0, [x23]
    c110:	911a63e1 	add	x1, sp, #0x698
    c114:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c118:	52800020 	mov	w0, #0x1                   	// #1
    c11c:	f9034ff7 	str	x23, [sp, #1688]
    c120:	f90353f5 	str	x21, [sp, #1696]
    c124:	97ffe60b 	bl	5950 <fwp_data.part.0.constprop.0>
    c128:	97ffe68e 	bl	5b60 <fwp_rc_fresh>
    c12c:	aa0003e2 	mov	x2, x0
    c130:	911aa3e1 	add	x1, sp, #0x6a8
    c134:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c138:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c13c:	52800020 	mov	w0, #0x1                   	// #1
    c140:	f90357f5 	str	x21, [sp, #1704]
    c144:	f9035be2 	str	x2, [sp, #1712]
    c148:	97ffe602 	bl	5950 <fwp_data.part.0.constprop.0>
    c14c:	97ffe685 	bl	5b60 <fwp_rc_fresh>
    c150:	aa0003e2 	mov	x2, x0
    c154:	911ae3e1 	add	x1, sp, #0x6b8
    c158:	52800020 	mov	w0, #0x1                   	// #1
    c15c:	f9035ff7 	str	x23, [sp, #1720]
    c160:	f90363e2 	str	x2, [sp, #1728]
    c164:	97ffe5fb 	bl	5950 <fwp_data.part.0.constprop.0>
    c168:	97ffe67e 	bl	5b60 <fwp_rc_fresh>
    c16c:	aa0003e2 	mov	x2, x0
    c170:	911b23e1 	add	x1, sp, #0x6c8
    c174:	52800020 	mov	w0, #0x1                   	// #1
    c178:	f90367f5 	str	x21, [sp, #1736]
    c17c:	f9036be2 	str	x2, [sp, #1744]
    c180:	97ffe5f4 	bl	5950 <fwp_data.part.0.constprop.0>
    c184:	97ffe677 	bl	5b60 <fwp_rc_fresh>
    c188:	aa0003e2 	mov	x2, x0
    c18c:	911b63e1 	add	x1, sp, #0x6d8
    c190:	52800020 	mov	w0, #0x1                   	// #1
    c194:	f9036ff7 	str	x23, [sp, #1752]
    c198:	f90373e2 	str	x2, [sp, #1760]
    c19c:	97ffe5ed 	bl	5950 <fwp_data.part.0.constprop.0>
    c1a0:	91198283 	add	x3, x20, #0x660
    c1a4:	aa0003f5 	mov	x21, x0
    c1a8:	f949d861 	ldr	x1, [x3, #5040]
    c1ac:	f949ec60 	ldr	x0, [x3, #5080]
    c1b0:	cb0102a1 	sub	x1, x21, x1
    c1b4:	eb00403f 	cmp	x1, x0, lsl #16
    c1b8:	54000322 	b.cs	c21c <f0+0x1be8>  // b.hs, b.nlast
    c1bc:	d350fc22 	lsr	x2, x1, #16
    c1c0:	f949fc63 	ldr	x3, [x3, #5112]
    c1c4:	8b020842 	add	x2, x2, x2, lsl #2
    c1c8:	d37df042 	lsl	x2, x2, #3
    c1cc:	8b020060 	add	x0, x3, x2
    c1d0:	f9401017 	ldr	x23, [x0, #32]
    c1d4:	b4000257 	cbz	x23, c21c <f0+0x1be8>
    c1d8:	38626862 	ldrb	w2, [x3, x2]
    c1dc:	7100085f 	cmp	w2, #0x2
    c1e0:	540044e0 	b.eq	ca7c <f0+0x2448>  // b.none
    c1e4:	7100045f 	cmp	w2, #0x1
    c1e8:	540001a1 	b.ne	c21c <f0+0x1be8>  // b.any
    c1ec:	29430002 	ldp	w2, w0, [x0, #24]
    c1f0:	92403c21 	and	x1, x1, #0xffff
    c1f4:	9b027c21 	mul	x1, x1, x2
    c1f8:	d360fc21 	lsr	x1, x1, #32
    c1fc:	eb00003f 	cmp	x1, x0
    c200:	540000e2 	b.cs	c21c <f0+0x1be8>  // b.hs, b.nlast
    c204:	8b0102f7 	add	x23, x23, x1
    c208:	394002e0 	ldrb	w0, [x23]
    c20c:	7103fc1f 	cmp	w0, #0xff
    c210:	54005200 	b.eq	cc50 <f0+0x261c>  // b.none
    c214:	52800020 	mov	w0, #0x1                   	// #1
    c218:	390002e0 	strb	w0, [x23]
    c21c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c220:	911ba3e1 	add	x1, sp, #0x6e8
    c224:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c228:	52800020 	mov	w0, #0x1                   	// #1
    c22c:	f90377e2 	str	x2, [sp, #1768]
    c230:	f9037bf5 	str	x21, [sp, #1776]
    c234:	97ffe5c7 	bl	5950 <fwp_data.part.0.constprop.0>
    c238:	91198283 	add	x3, x20, #0x660
    c23c:	aa0003f5 	mov	x21, x0
    c240:	f949d861 	ldr	x1, [x3, #5040]
    c244:	f949ec60 	ldr	x0, [x3, #5080]
    c248:	cb0102a1 	sub	x1, x21, x1
    c24c:	eb00403f 	cmp	x1, x0, lsl #16
    c250:	54000322 	b.cs	c2b4 <f0+0x1c80>  // b.hs, b.nlast
    c254:	d350fc22 	lsr	x2, x1, #16
    c258:	f949fc63 	ldr	x3, [x3, #5112]
    c25c:	8b020842 	add	x2, x2, x2, lsl #2
    c260:	d37df042 	lsl	x2, x2, #3
    c264:	8b020060 	add	x0, x3, x2
    c268:	f9401017 	ldr	x23, [x0, #32]
    c26c:	b4000257 	cbz	x23, c2b4 <f0+0x1c80>
    c270:	38626862 	ldrb	w2, [x3, x2]
    c274:	7100085f 	cmp	w2, #0x2
    c278:	54003fc0 	b.eq	ca70 <f0+0x243c>  // b.none
    c27c:	7100045f 	cmp	w2, #0x1
    c280:	540001a1 	b.ne	c2b4 <f0+0x1c80>  // b.any
    c284:	29430002 	ldp	w2, w0, [x0, #24]
    c288:	92403c21 	and	x1, x1, #0xffff
    c28c:	9b027c21 	mul	x1, x1, x2
    c290:	d360fc21 	lsr	x1, x1, #32
    c294:	eb00003f 	cmp	x1, x0
    c298:	540000e2 	b.cs	c2b4 <f0+0x1c80>  // b.hs, b.nlast
    c29c:	8b0102f7 	add	x23, x23, x1
    c2a0:	394002e0 	ldrb	w0, [x23]
    c2a4:	7103fc1f 	cmp	w0, #0xff
    c2a8:	54004da0 	b.eq	cc5c <f0+0x2628>  // b.none
    c2ac:	52800020 	mov	w0, #0x1                   	// #1
    c2b0:	390002e0 	strb	w0, [x23]
    c2b4:	911be3e1 	add	x1, sp, #0x6f8
    c2b8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c2bc:	52800020 	mov	w0, #0x1                   	// #1
    c2c0:	f9037ff7 	str	x23, [sp, #1784]
    c2c4:	f90383f5 	str	x21, [sp, #1792]
    c2c8:	97ffe5a2 	bl	5950 <fwp_data.part.0.constprop.0>
    c2cc:	97ffe625 	bl	5b60 <fwp_rc_fresh>
    c2d0:	aa0003e2 	mov	x2, x0
    c2d4:	911c23e1 	add	x1, sp, #0x708
    c2d8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c2dc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c2e0:	52800020 	mov	w0, #0x1                   	// #1
    c2e4:	f90387f5 	str	x21, [sp, #1800]
    c2e8:	f9038be2 	str	x2, [sp, #1808]
    c2ec:	97ffe599 	bl	5950 <fwp_data.part.0.constprop.0>
    c2f0:	97ffe61c 	bl	5b60 <fwp_rc_fresh>
    c2f4:	aa0003e2 	mov	x2, x0
    c2f8:	911c63e1 	add	x1, sp, #0x718
    c2fc:	52800020 	mov	w0, #0x1                   	// #1
    c300:	f9038ff7 	str	x23, [sp, #1816]
    c304:	f90393e2 	str	x2, [sp, #1824]
    c308:	97ffe592 	bl	5950 <fwp_data.part.0.constprop.0>
    c30c:	97ffe615 	bl	5b60 <fwp_rc_fresh>
    c310:	aa0003e2 	mov	x2, x0
    c314:	911ca3e1 	add	x1, sp, #0x728
    c318:	52800020 	mov	w0, #0x1                   	// #1
    c31c:	f90397f5 	str	x21, [sp, #1832]
    c320:	f9039be2 	str	x2, [sp, #1840]
    c324:	97ffe58b 	bl	5950 <fwp_data.part.0.constprop.0>
    c328:	91198283 	add	x3, x20, #0x660
    c32c:	aa0003f5 	mov	x21, x0
    c330:	f949d861 	ldr	x1, [x3, #5040]
    c334:	f949ec60 	ldr	x0, [x3, #5080]
    c338:	cb0102a1 	sub	x1, x21, x1
    c33c:	eb00403f 	cmp	x1, x0, lsl #16
    c340:	54000322 	b.cs	c3a4 <f0+0x1d70>  // b.hs, b.nlast
    c344:	d350fc22 	lsr	x2, x1, #16
    c348:	f949fc63 	ldr	x3, [x3, #5112]
    c34c:	8b020842 	add	x2, x2, x2, lsl #2
    c350:	d37df042 	lsl	x2, x2, #3
    c354:	8b020060 	add	x0, x3, x2
    c358:	f9401017 	ldr	x23, [x0, #32]
    c35c:	b4000257 	cbz	x23, c3a4 <f0+0x1d70>
    c360:	38626862 	ldrb	w2, [x3, x2]
    c364:	7100085f 	cmp	w2, #0x2
    c368:	540037e0 	b.eq	ca64 <f0+0x2430>  // b.none
    c36c:	7100045f 	cmp	w2, #0x1
    c370:	540001a1 	b.ne	c3a4 <f0+0x1d70>  // b.any
    c374:	29430002 	ldp	w2, w0, [x0, #24]
    c378:	92403c21 	and	x1, x1, #0xffff
    c37c:	9b027c21 	mul	x1, x1, x2
    c380:	d360fc21 	lsr	x1, x1, #32
    c384:	eb00003f 	cmp	x1, x0
    c388:	540000e2 	b.cs	c3a4 <f0+0x1d70>  // b.hs, b.nlast
    c38c:	8b0102f7 	add	x23, x23, x1
    c390:	394002e0 	ldrb	w0, [x23]
    c394:	7103fc1f 	cmp	w0, #0xff
    c398:	54004680 	b.eq	cc68 <f0+0x2634>  // b.none
    c39c:	52800020 	mov	w0, #0x1                   	// #1
    c3a0:	390002e0 	strb	w0, [x23]
    c3a4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c3a8:	911ce3e1 	add	x1, sp, #0x738
    c3ac:	52800020 	mov	w0, #0x1                   	// #1
    c3b0:	f9039fe2 	str	x2, [sp, #1848]
    c3b4:	f903a3f5 	str	x21, [sp, #1856]
    c3b8:	97ffe566 	bl	5950 <fwp_data.part.0.constprop.0>
    c3bc:	91198283 	add	x3, x20, #0x660
    c3c0:	aa0003f5 	mov	x21, x0
    c3c4:	f949d861 	ldr	x1, [x3, #5040]
    c3c8:	f949ec60 	ldr	x0, [x3, #5080]
    c3cc:	cb0102a1 	sub	x1, x21, x1
    c3d0:	eb00403f 	cmp	x1, x0, lsl #16
    c3d4:	54000322 	b.cs	c438 <f0+0x1e04>  // b.hs, b.nlast
    c3d8:	d350fc22 	lsr	x2, x1, #16
    c3dc:	f949fc63 	ldr	x3, [x3, #5112]
    c3e0:	8b020842 	add	x2, x2, x2, lsl #2
    c3e4:	d37df042 	lsl	x2, x2, #3
    c3e8:	8b020060 	add	x0, x3, x2
    c3ec:	f9401017 	ldr	x23, [x0, #32]
    c3f0:	b4000257 	cbz	x23, c438 <f0+0x1e04>
    c3f4:	38626862 	ldrb	w2, [x3, x2]
    c3f8:	7100085f 	cmp	w2, #0x2
    c3fc:	540032e0 	b.eq	ca58 <f0+0x2424>  // b.none
    c400:	7100045f 	cmp	w2, #0x1
    c404:	540001a1 	b.ne	c438 <f0+0x1e04>  // b.any
    c408:	29430002 	ldp	w2, w0, [x0, #24]
    c40c:	92403c21 	and	x1, x1, #0xffff
    c410:	9b027c21 	mul	x1, x1, x2
    c414:	d360fc21 	lsr	x1, x1, #32
    c418:	eb00003f 	cmp	x1, x0
    c41c:	540000e2 	b.cs	c438 <f0+0x1e04>  // b.hs, b.nlast
    c420:	8b0102f7 	add	x23, x23, x1
    c424:	394002e0 	ldrb	w0, [x23]
    c428:	7103fc1f 	cmp	w0, #0xff
    c42c:	54004240 	b.eq	cc74 <f0+0x2640>  // b.none
    c430:	52800020 	mov	w0, #0x1                   	// #1
    c434:	390002e0 	strb	w0, [x23]
    c438:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c43c:	911d23e1 	add	x1, sp, #0x748
    c440:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c444:	52800020 	mov	w0, #0x1                   	// #1
    c448:	f903a7e2 	str	x2, [sp, #1864]
    c44c:	f903abf5 	str	x21, [sp, #1872]
    c450:	97ffe540 	bl	5950 <fwp_data.part.0.constprop.0>
    c454:	91198283 	add	x3, x20, #0x660
    c458:	aa0003f5 	mov	x21, x0
    c45c:	f949d861 	ldr	x1, [x3, #5040]
    c460:	f949ec60 	ldr	x0, [x3, #5080]
    c464:	cb0102a1 	sub	x1, x21, x1
    c468:	eb00403f 	cmp	x1, x0, lsl #16
    c46c:	54000322 	b.cs	c4d0 <f0+0x1e9c>  // b.hs, b.nlast
    c470:	d350fc22 	lsr	x2, x1, #16
    c474:	f949fc63 	ldr	x3, [x3, #5112]
    c478:	8b020842 	add	x2, x2, x2, lsl #2
    c47c:	d37df042 	lsl	x2, x2, #3
    c480:	8b020060 	add	x0, x3, x2
    c484:	f9401017 	ldr	x23, [x0, #32]
    c488:	b4000257 	cbz	x23, c4d0 <f0+0x1e9c>
    c48c:	38626862 	ldrb	w2, [x3, x2]
    c490:	7100085f 	cmp	w2, #0x2
    c494:	54002dc0 	b.eq	ca4c <f0+0x2418>  // b.none
    c498:	7100045f 	cmp	w2, #0x1
    c49c:	540001a1 	b.ne	c4d0 <f0+0x1e9c>  // b.any
    c4a0:	29430002 	ldp	w2, w0, [x0, #24]
    c4a4:	92403c21 	and	x1, x1, #0xffff
    c4a8:	9b027c21 	mul	x1, x1, x2
    c4ac:	d360fc21 	lsr	x1, x1, #32
    c4b0:	eb00003f 	cmp	x1, x0
    c4b4:	540000e2 	b.cs	c4d0 <f0+0x1e9c>  // b.hs, b.nlast
    c4b8:	8b0102f7 	add	x23, x23, x1
    c4bc:	394002e0 	ldrb	w0, [x23]
    c4c0:	7103fc1f 	cmp	w0, #0xff
    c4c4:	54003de0 	b.eq	cc80 <f0+0x264c>  // b.none
    c4c8:	52800020 	mov	w0, #0x1                   	// #1
    c4cc:	390002e0 	strb	w0, [x23]
    c4d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c4d4:	911d63e1 	add	x1, sp, #0x758
    c4d8:	52800020 	mov	w0, #0x1                   	// #1
    c4dc:	f903afe2 	str	x2, [sp, #1880]
    c4e0:	f903b3f5 	str	x21, [sp, #1888]
    c4e4:	97ffe51b 	bl	5950 <fwp_data.part.0.constprop.0>
    c4e8:	91198283 	add	x3, x20, #0x660
    c4ec:	aa0003f5 	mov	x21, x0
    c4f0:	f949d861 	ldr	x1, [x3, #5040]
    c4f4:	f949ec60 	ldr	x0, [x3, #5080]
    c4f8:	cb0102a1 	sub	x1, x21, x1
    c4fc:	eb00403f 	cmp	x1, x0, lsl #16
    c500:	54000322 	b.cs	c564 <f0+0x1f30>  // b.hs, b.nlast
    c504:	d350fc22 	lsr	x2, x1, #16
    c508:	f949fc63 	ldr	x3, [x3, #5112]
    c50c:	8b020842 	add	x2, x2, x2, lsl #2
    c510:	d37df042 	lsl	x2, x2, #3
    c514:	8b020060 	add	x0, x3, x2
    c518:	f9401017 	ldr	x23, [x0, #32]
    c51c:	b4000257 	cbz	x23, c564 <f0+0x1f30>
    c520:	38626862 	ldrb	w2, [x3, x2]
    c524:	7100085f 	cmp	w2, #0x2
    c528:	540028c0 	b.eq	ca40 <f0+0x240c>  // b.none
    c52c:	7100045f 	cmp	w2, #0x1
    c530:	540001a1 	b.ne	c564 <f0+0x1f30>  // b.any
    c534:	29430002 	ldp	w2, w0, [x0, #24]
    c538:	92403c21 	and	x1, x1, #0xffff
    c53c:	9b027c21 	mul	x1, x1, x2
    c540:	d360fc21 	lsr	x1, x1, #32
    c544:	eb00003f 	cmp	x1, x0
    c548:	540000e2 	b.cs	c564 <f0+0x1f30>  // b.hs, b.nlast
    c54c:	8b0102f7 	add	x23, x23, x1
    c550:	394002e0 	ldrb	w0, [x23]
    c554:	7103fc1f 	cmp	w0, #0xff
    c558:	540039a0 	b.eq	cc8c <f0+0x2658>  // b.none
    c55c:	52800020 	mov	w0, #0x1                   	// #1
    c560:	390002e0 	strb	w0, [x23]
    c564:	911da3e1 	add	x1, sp, #0x768
    c568:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c56c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c570:	52800020 	mov	w0, #0x1                   	// #1
    c574:	f903b7f7 	str	x23, [sp, #1896]
    c578:	f903bbf5 	str	x21, [sp, #1904]
    c57c:	97ffe4f5 	bl	5950 <fwp_data.part.0.constprop.0>
    c580:	97ffe578 	bl	5b60 <fwp_rc_fresh>
    c584:	aa0003e2 	mov	x2, x0
    c588:	911de3e1 	add	x1, sp, #0x778
    c58c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c590:	52800020 	mov	w0, #0x1                   	// #1
    c594:	f903bff5 	str	x21, [sp, #1912]
    c598:	f903c3e2 	str	x2, [sp, #1920]
    c59c:	97ffe4ed 	bl	5950 <fwp_data.part.0.constprop.0>
    c5a0:	97ffe570 	bl	5b60 <fwp_rc_fresh>
    c5a4:	aa0003e2 	mov	x2, x0
    c5a8:	911e23e1 	add	x1, sp, #0x788
    c5ac:	52800020 	mov	w0, #0x1                   	// #1
    c5b0:	f903c7f7 	str	x23, [sp, #1928]
    c5b4:	f903cbe2 	str	x2, [sp, #1936]
    c5b8:	97ffe4e6 	bl	5950 <fwp_data.part.0.constprop.0>
    c5bc:	97ffe569 	bl	5b60 <fwp_rc_fresh>
    c5c0:	aa0003e2 	mov	x2, x0
    c5c4:	911e63e1 	add	x1, sp, #0x798
    c5c8:	52800020 	mov	w0, #0x1                   	// #1
    c5cc:	f903cff5 	str	x21, [sp, #1944]
    c5d0:	f903d3e2 	str	x2, [sp, #1952]
    c5d4:	97ffe4df 	bl	5950 <fwp_data.part.0.constprop.0>
    c5d8:	97ffe562 	bl	5b60 <fwp_rc_fresh>
    c5dc:	aa0003e2 	mov	x2, x0
    c5e0:	911ea3e1 	add	x1, sp, #0x7a8
    c5e4:	52800020 	mov	w0, #0x1                   	// #1
    c5e8:	f903d7f7 	str	x23, [sp, #1960]
    c5ec:	f903dbe2 	str	x2, [sp, #1968]
    c5f0:	97ffe4d8 	bl	5950 <fwp_data.part.0.constprop.0>
    c5f4:	91198283 	add	x3, x20, #0x660
    c5f8:	aa0003f5 	mov	x21, x0
    c5fc:	f949d861 	ldr	x1, [x3, #5040]
    c600:	f949ec60 	ldr	x0, [x3, #5080]
    c604:	cb0102a1 	sub	x1, x21, x1
    c608:	eb00403f 	cmp	x1, x0, lsl #16
    c60c:	54000322 	b.cs	c670 <f0+0x203c>  // b.hs, b.nlast
    c610:	d350fc22 	lsr	x2, x1, #16
    c614:	f949fc63 	ldr	x3, [x3, #5112]
    c618:	8b020842 	add	x2, x2, x2, lsl #2
    c61c:	d37df042 	lsl	x2, x2, #3
    c620:	8b020060 	add	x0, x3, x2
    c624:	f9401017 	ldr	x23, [x0, #32]
    c628:	b4000257 	cbz	x23, c670 <f0+0x203c>
    c62c:	38626862 	ldrb	w2, [x3, x2]
    c630:	7100085f 	cmp	w2, #0x2
    c634:	54002000 	b.eq	ca34 <f0+0x2400>  // b.none
    c638:	7100045f 	cmp	w2, #0x1
    c63c:	540001a1 	b.ne	c670 <f0+0x203c>  // b.any
    c640:	29430002 	ldp	w2, w0, [x0, #24]
    c644:	92403c21 	and	x1, x1, #0xffff
    c648:	9b027c21 	mul	x1, x1, x2
    c64c:	d360fc21 	lsr	x1, x1, #32
    c650:	eb00003f 	cmp	x1, x0
    c654:	540000e2 	b.cs	c670 <f0+0x203c>  // b.hs, b.nlast
    c658:	8b0102f7 	add	x23, x23, x1
    c65c:	394002e0 	ldrb	w0, [x23]
    c660:	7103fc1f 	cmp	w0, #0xff
    c664:	540031a0 	b.eq	cc98 <f0+0x2664>  // b.none
    c668:	52800020 	mov	w0, #0x1                   	// #1
    c66c:	390002e0 	strb	w0, [x23]
    c670:	911ee3e1 	add	x1, sp, #0x7b8
    c674:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c678:	52800020 	mov	w0, #0x1                   	// #1
    c67c:	f903dff7 	str	x23, [sp, #1976]
    c680:	f903e3f5 	str	x21, [sp, #1984]
    c684:	97ffe4b3 	bl	5950 <fwp_data.part.0.constprop.0>
    c688:	97ffe536 	bl	5b60 <fwp_rc_fresh>
    c68c:	aa0003e2 	mov	x2, x0
    c690:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c694:	911f23e1 	add	x1, sp, #0x7c8
    c698:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c69c:	52800020 	mov	w0, #0x1                   	// #1
    c6a0:	f903e7e3 	str	x3, [sp, #1992]
    c6a4:	f903ebe2 	str	x2, [sp, #2000]
    c6a8:	97ffe4aa 	bl	5950 <fwp_data.part.0.constprop.0>
    c6ac:	97ffe52d 	bl	5b60 <fwp_rc_fresh>
    c6b0:	aa0003e2 	mov	x2, x0
    c6b4:	911f63e1 	add	x1, sp, #0x7d8
    c6b8:	52800020 	mov	w0, #0x1                   	// #1
    c6bc:	f903eff7 	str	x23, [sp, #2008]
    c6c0:	f903f3e2 	str	x2, [sp, #2016]
    c6c4:	97ffe4a3 	bl	5950 <fwp_data.part.0.constprop.0>
    c6c8:	91198283 	add	x3, x20, #0x660
    c6cc:	aa0003f5 	mov	x21, x0
    c6d0:	f949d861 	ldr	x1, [x3, #5040]
    c6d4:	f949ec60 	ldr	x0, [x3, #5080]
    c6d8:	cb0102a1 	sub	x1, x21, x1
    c6dc:	eb00403f 	cmp	x1, x0, lsl #16
    c6e0:	54000322 	b.cs	c744 <f0+0x2110>  // b.hs, b.nlast
    c6e4:	d350fc22 	lsr	x2, x1, #16
    c6e8:	f949fc63 	ldr	x3, [x3, #5112]
    c6ec:	8b020842 	add	x2, x2, x2, lsl #2
    c6f0:	d37df042 	lsl	x2, x2, #3
    c6f4:	8b020060 	add	x0, x3, x2
    c6f8:	f9401017 	ldr	x23, [x0, #32]
    c6fc:	b4000257 	cbz	x23, c744 <f0+0x2110>
    c700:	38626862 	ldrb	w2, [x3, x2]
    c704:	7100085f 	cmp	w2, #0x2
    c708:	54001900 	b.eq	ca28 <f0+0x23f4>  // b.none
    c70c:	7100045f 	cmp	w2, #0x1
    c710:	540001a1 	b.ne	c744 <f0+0x2110>  // b.any
    c714:	29430002 	ldp	w2, w0, [x0, #24]
    c718:	92403c21 	and	x1, x1, #0xffff
    c71c:	9b027c21 	mul	x1, x1, x2
    c720:	d360fc21 	lsr	x1, x1, #32
    c724:	eb00003f 	cmp	x1, x0
    c728:	540000e2 	b.cs	c744 <f0+0x2110>  // b.hs, b.nlast
    c72c:	8b0102f7 	add	x23, x23, x1
    c730:	394002e0 	ldrb	w0, [x23]
    c734:	7103fc1f 	cmp	w0, #0xff
    c738:	54002b60 	b.eq	cca4 <f0+0x2670>  // b.none
    c73c:	52800020 	mov	w0, #0x1                   	// #1
    c740:	390002e0 	strb	w0, [x23]
    c744:	911fa3e1 	add	x1, sp, #0x7e8
    c748:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c74c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c750:	52800020 	mov	w0, #0x1                   	// #1
    c754:	f903f7f7 	str	x23, [sp, #2024]
    c758:	91198294 	add	x20, x20, #0x660
    c75c:	f903fbf5 	str	x21, [sp, #2032]
    c760:	97ffe47c 	bl	5950 <fwp_data.part.0.constprop.0>
    c764:	97ffe4ff 	bl	5b60 <fwp_rc_fresh>
    c768:	aa0003e2 	mov	x2, x0
    c76c:	911fe3e1 	add	x1, sp, #0x7f8
    c770:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c774:	52800020 	mov	w0, #0x1                   	// #1
    c778:	f903fff5 	str	x21, [sp, #2040]
    c77c:	f90403e2 	str	x2, [sp, #2048]
    c780:	97ffe474 	bl	5950 <fwp_data.part.0.constprop.0>
    c784:	97ffe4f7 	bl	5b60 <fwp_rc_fresh>
    c788:	aa0003e2 	mov	x2, x0
    c78c:	912023e1 	add	x1, sp, #0x808
    c790:	52800020 	mov	w0, #0x1                   	// #1
    c794:	f90407f7 	str	x23, [sp, #2056]
    c798:	f9040be2 	str	x2, [sp, #2064]
    c79c:	97ffe46d 	bl	5950 <fwp_data.part.0.constprop.0>
    c7a0:	97ffe4f0 	bl	5b60 <fwp_rc_fresh>
    c7a4:	aa0003e2 	mov	x2, x0
    c7a8:	912063e1 	add	x1, sp, #0x818
    c7ac:	52800020 	mov	w0, #0x1                   	// #1
    c7b0:	f9040ff5 	str	x21, [sp, #2072]
    c7b4:	f90413e2 	str	x2, [sp, #2080]
    c7b8:	97ffe466 	bl	5950 <fwp_data.part.0.constprop.0>
    c7bc:	97ffe4e9 	bl	5b60 <fwp_rc_fresh>
    c7c0:	aa0003e2 	mov	x2, x0
    c7c4:	9120a3e1 	add	x1, sp, #0x828
    c7c8:	52800020 	mov	w0, #0x1                   	// #1
    c7cc:	f90417f7 	str	x23, [sp, #2088]
    c7d0:	f9041be2 	str	x2, [sp, #2096]
    c7d4:	97ffe45f 	bl	5950 <fwp_data.part.0.constprop.0>
    c7d8:	f949da81 	ldr	x1, [x20, #5040]
    c7dc:	aa0003f5 	mov	x21, x0
    c7e0:	f949ee80 	ldr	x0, [x20, #5080]
    c7e4:	cb0102a1 	sub	x1, x21, x1
    c7e8:	eb00403f 	cmp	x1, x0, lsl #16
    c7ec:	54000322 	b.cs	c850 <f0+0x221c>  // b.hs, b.nlast
    c7f0:	d350fc22 	lsr	x2, x1, #16
    c7f4:	f949fe83 	ldr	x3, [x20, #5112]
    c7f8:	8b020842 	add	x2, x2, x2, lsl #2
    c7fc:	d37df042 	lsl	x2, x2, #3
    c800:	8b020060 	add	x0, x3, x2
    c804:	f9401014 	ldr	x20, [x0, #32]
    c808:	b4000254 	cbz	x20, c850 <f0+0x221c>
    c80c:	38626862 	ldrb	w2, [x3, x2]
    c810:	7100085f 	cmp	w2, #0x2
    c814:	54001040 	b.eq	ca1c <f0+0x23e8>  // b.none
    c818:	7100045f 	cmp	w2, #0x1
    c81c:	540001a1 	b.ne	c850 <f0+0x221c>  // b.any
    c820:	29430002 	ldp	w2, w0, [x0, #24]
    c824:	92403c21 	and	x1, x1, #0xffff
    c828:	9b027c21 	mul	x1, x1, x2
    c82c:	d360fc21 	lsr	x1, x1, #32
    c830:	eb00003f 	cmp	x1, x0
    c834:	540000e2 	b.cs	c850 <f0+0x221c>  // b.hs, b.nlast
    c838:	8b010294 	add	x20, x20, x1
    c83c:	39400280 	ldrb	w0, [x20]
    c840:	7103fc1f 	cmp	w0, #0xff
    c844:	540014c0 	b.eq	cadc <f0+0x24a8>  // b.none
    c848:	52800020 	mov	w0, #0x1                   	// #1
    c84c:	39000280 	strb	w0, [x20]
    c850:	9120e3e1 	add	x1, sp, #0x838
    c854:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c858:	52800020 	mov	w0, #0x1                   	// #1
    c85c:	f9041fe2 	str	x2, [sp, #2104]
    c860:	f90423f5 	str	x21, [sp, #2112]
    c864:	97ffe43b 	bl	5950 <fwp_data.part.0.constprop.0>
    c868:	97ffe4be 	bl	5b60 <fwp_rc_fresh>
    c86c:	aa0003e2 	mov	x2, x0
    c870:	aa1603e1 	mov	x1, x22
    c874:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c878:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c87c:	52800020 	mov	w0, #0x1                   	// #1
    c880:	f90427e3 	str	x3, [sp, #2120]
    c884:	f9042be2 	str	x2, [sp, #2128]
    c888:	97ffe432 	bl	5950 <fwp_data.part.0.constprop.0>
    c88c:	97ffe4b5 	bl	5b60 <fwp_rc_fresh>
    c890:	aa0003f5 	mov	x21, x0
    c894:	aa1303e1 	mov	x1, x19
    c898:	97fff452 	bl	99e0 <fwp_hof0.constprop.0>
    c89c:	aa0003f4 	mov	x20, x0
    c8a0:	aa1503e0 	mov	x0, x21
    c8a4:	97ffe60f 	bl	60e0 <fwp_drop0>
    c8a8:	aa1303e0 	mov	x0, x19
    c8ac:	97ffe60d 	bl	60e0 <fwp_drop0>
    c8b0:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    c8b4:	f947f400 	ldr	x0, [x0, #4072]
    c8b8:	f9442fe2 	ldr	x2, [sp, #2136]
    c8bc:	f9400001 	ldr	x1, [x0]
    c8c0:	eb010042 	subs	x2, x2, x1
    c8c4:	d2800001 	mov	x1, #0x0                   	// #0
    c8c8:	54001f41 	b.ne	ccb0 <f0+0x267c>  // b.any
    c8cc:	912183ff 	add	sp, sp, #0x860
    c8d0:	aa1403e0 	mov	x0, x20
    c8d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    c8d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c8dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    c8e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c8e4:	a94573fb 	ldp	x27, x28, [sp, #80]
    c8e8:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c8ec:	d65f03c0 	ret
    c8f0:	aa1b03e0 	mov	x0, x27
    c8f4:	97ffe03b 	bl	49e0 <fwp_rc_forget_slot>
    c8f8:	17fff798 	b	a758 <f0+0x124>
    c8fc:	72003c5f 	tst	w2, #0xffff
    c900:	54fef2e1 	b.ne	a75c <f0+0x128>  // b.any
    c904:	17fff792 	b	a74c <f0+0x118>
    c908:	72003c3f 	tst	w1, #0xffff
    c90c:	54ff9661 	b.ne	bbd8 <f0+0x15a4>  // b.any
    c910:	17fffcad 	b	bbc4 <f0+0x1590>
    c914:	72003c3f 	tst	w1, #0xffff
    c918:	54ff9041 	b.ne	bb20 <f0+0x14ec>  // b.any
    c91c:	17fffc7c 	b	bb0c <f0+0x14d8>
    c920:	72003c3f 	tst	w1, #0xffff
    c924:	54ff8a21 	b.ne	ba68 <f0+0x1434>  // b.any
    c928:	17fffc4b 	b	ba54 <f0+0x1420>
    c92c:	72003c3f 	tst	w1, #0xffff
    c930:	54ff8401 	b.ne	b9b0 <f0+0x137c>  // b.any
    c934:	17fffc1a 	b	b99c <f0+0x1368>
    c938:	72003c3f 	tst	w1, #0xffff
    c93c:	54ff7de1 	b.ne	b8f8 <f0+0x12c4>  // b.any
    c940:	17fffbe9 	b	b8e4 <f0+0x12b0>
    c944:	72003c3f 	tst	w1, #0xffff
    c948:	54ff77c1 	b.ne	b840 <f0+0x120c>  // b.any
    c94c:	17fffbb8 	b	b82c <f0+0x11f8>
    c950:	72003c3f 	tst	w1, #0xffff
    c954:	54ff72a1 	b.ne	b7a8 <f0+0x1174>  // b.any
    c958:	17fffb8f 	b	b794 <f0+0x1160>
    c95c:	72003c3f 	tst	w1, #0xffff
    c960:	54ff6821 	b.ne	b664 <f0+0x1030>  // b.any
    c964:	17fffb3b 	b	b650 <f0+0x101c>
    c968:	72003c3f 	tst	w1, #0xffff
    c96c:	54ff0541 	b.ne	aa14 <f0+0x3e0>  // b.any
    c970:	17fff824 	b	aa00 <f0+0x3cc>
    c974:	72003c3f 	tst	w1, #0xffff
    c978:	54ff0041 	b.ne	a980 <f0+0x34c>  // b.any
    c97c:	17fff7fc 	b	a96c <f0+0x338>
    c980:	72003c3f 	tst	w1, #0xffff
    c984:	54fef9a1 	b.ne	a8b8 <f0+0x284>  // b.any
    c988:	17fff7c7 	b	a8a4 <f0+0x270>
    c98c:	72003c3f 	tst	w1, #0xffff
    c990:	54ff1a01 	b.ne	acd0 <f0+0x69c>  // b.any
    c994:	17fff8ca 	b	acbc <f0+0x688>
    c998:	72003c3f 	tst	w1, #0xffff
    c99c:	54ff1501 	b.ne	ac3c <f0+0x608>  // b.any
    c9a0:	17fff8a2 	b	ac28 <f0+0x5f4>
    c9a4:	72003c3f 	tst	w1, #0xffff
    c9a8:	54ff0e61 	b.ne	ab74 <f0+0x540>  // b.any
    c9ac:	17fff86d 	b	ab60 <f0+0x52c>
    c9b0:	72003c3f 	tst	w1, #0xffff
    c9b4:	54ff0881 	b.ne	aac4 <f0+0x490>  // b.any
    c9b8:	17fff83e 	b	aab0 <f0+0x47c>
    c9bc:	72003c3f 	tst	w1, #0xffff
    c9c0:	54ff5f61 	b.ne	b5ac <f0+0xf78>  // b.any
    c9c4:	17fffaf5 	b	b598 <f0+0xf64>
    c9c8:	72003c3f 	tst	w1, #0xffff
    c9cc:	54ff5941 	b.ne	b4f4 <f0+0xec0>  // b.any
    c9d0:	17fffac4 	b	b4e0 <f0+0xeac>
    c9d4:	72003c3f 	tst	w1, #0xffff
    c9d8:	54ff5161 	b.ne	b404 <f0+0xdd0>  // b.any
    c9dc:	17fffa85 	b	b3f0 <f0+0xdbc>
    c9e0:	72003c3f 	tst	w1, #0xffff
    c9e4:	54ff3aa1 	b.ne	b138 <f0+0xb04>  // b.any
    c9e8:	17fff9cf 	b	b124 <f0+0xaf0>
    c9ec:	72003c3f 	tst	w1, #0xffff
    c9f0:	54ff2d81 	b.ne	afa0 <f0+0x96c>  // b.any
    c9f4:	17fff966 	b	af8c <f0+0x958>
    c9f8:	72003c3f 	tst	w1, #0xffff
    c9fc:	54ff26e1 	b.ne	aed8 <f0+0x8a4>  // b.any
    ca00:	17fff931 	b	aec4 <f0+0x890>
    ca04:	72003c3f 	tst	w1, #0xffff
    ca08:	54ff2041 	b.ne	ae10 <f0+0x7dc>  // b.any
    ca0c:	17fff8fc 	b	adfc <f0+0x7c8>
    ca10:	72003c3f 	tst	w1, #0xffff
    ca14:	54ff1b61 	b.ne	ad80 <f0+0x74c>  // b.any
    ca18:	17fff8d5 	b	ad6c <f0+0x738>
    ca1c:	72003c3f 	tst	w1, #0xffff
    ca20:	54fff181 	b.ne	c850 <f0+0x221c>  // b.any
    ca24:	17ffff86 	b	c83c <f0+0x2208>
    ca28:	72003c3f 	tst	w1, #0xffff
    ca2c:	54ffe8c1 	b.ne	c744 <f0+0x2110>  // b.any
    ca30:	17ffff40 	b	c730 <f0+0x20fc>
    ca34:	72003c3f 	tst	w1, #0xffff
    ca38:	54ffe1c1 	b.ne	c670 <f0+0x203c>  // b.any
    ca3c:	17ffff08 	b	c65c <f0+0x2028>
    ca40:	72003c3f 	tst	w1, #0xffff
    ca44:	54ffd901 	b.ne	c564 <f0+0x1f30>  // b.any
    ca48:	17fffec2 	b	c550 <f0+0x1f1c>
    ca4c:	72003c3f 	tst	w1, #0xffff
    ca50:	54ffd401 	b.ne	c4d0 <f0+0x1e9c>  // b.any
    ca54:	17fffe9a 	b	c4bc <f0+0x1e88>
    ca58:	72003c3f 	tst	w1, #0xffff
    ca5c:	54ffcee1 	b.ne	c438 <f0+0x1e04>  // b.any
    ca60:	17fffe71 	b	c424 <f0+0x1df0>
    ca64:	72003c3f 	tst	w1, #0xffff
    ca68:	54ffc9e1 	b.ne	c3a4 <f0+0x1d70>  // b.any
    ca6c:	17fffe49 	b	c390 <f0+0x1d5c>
    ca70:	72003c3f 	tst	w1, #0xffff
    ca74:	54ffc201 	b.ne	c2b4 <f0+0x1c80>  // b.any
    ca78:	17fffe0a 	b	c2a0 <f0+0x1c6c>
    ca7c:	72003c3f 	tst	w1, #0xffff
    ca80:	54ffbce1 	b.ne	c21c <f0+0x1be8>  // b.any
    ca84:	17fffde1 	b	c208 <f0+0x1bd4>
    ca88:	72003c3f 	tst	w1, #0xffff
    ca8c:	54ffb421 	b.ne	c110 <f0+0x1adc>  // b.any
    ca90:	17fffd9b 	b	c0fc <f0+0x1ac8>
    ca94:	72003c3f 	tst	w1, #0xffff
    ca98:	54ffae01 	b.ne	c058 <f0+0x1a24>  // b.any
    ca9c:	17fffd6a 	b	c044 <f0+0x1a10>
    caa0:	72003c3f 	tst	w1, #0xffff
    caa4:	54ffa8e1 	b.ne	bfc0 <f0+0x198c>  // b.any
    caa8:	17fffd41 	b	bfac <f0+0x1978>
    caac:	72003c3f 	tst	w1, #0xffff
    cab0:	54ffa1e1 	b.ne	beec <f0+0x18b8>  // b.any
    cab4:	17fffd09 	b	bed8 <f0+0x18a4>
    cab8:	72003c3f 	tst	w1, #0xffff
    cabc:	54ff9a01 	b.ne	bdfc <f0+0x17c8>  // b.any
    cac0:	17fffcca 	b	bde8 <f0+0x17b4>
    cac4:	72003c3f 	tst	w1, #0xffff
    cac8:	54ff94e1 	b.ne	bd64 <f0+0x1730>  // b.any
    cacc:	17fffca1 	b	bd50 <f0+0x171c>
    cad0:	72003c3f 	tst	w1, #0xffff
    cad4:	54ff8de1 	b.ne	bc90 <f0+0x165c>  // b.any
    cad8:	17fffc69 	b	bc7c <f0+0x1648>
    cadc:	aa1403e0 	mov	x0, x20
    cae0:	97ffdfc0 	bl	49e0 <fwp_rc_forget_slot>
    cae4:	17ffff59 	b	c848 <f0+0x2214>
    cae8:	aa1703e0 	mov	x0, x23
    caec:	97ffdfbd 	bl	49e0 <fwp_rc_forget_slot>
    caf0:	17fff770 	b	a8b0 <f0+0x27c>
    caf4:	aa1703e0 	mov	x0, x23
    caf8:	97ffdfba 	bl	49e0 <fwp_rc_forget_slot>
    cafc:	17fff79f 	b	a978 <f0+0x344>
    cb00:	aa1703e0 	mov	x0, x23
    cb04:	97ffdfb7 	bl	49e0 <fwp_rc_forget_slot>
    cb08:	17fff7c1 	b	aa0c <f0+0x3d8>
    cb0c:	aa1703e0 	mov	x0, x23
    cb10:	97ffdfb4 	bl	49e0 <fwp_rc_forget_slot>
    cb14:	17fff7ea 	b	aabc <f0+0x488>
    cb18:	aa1703e0 	mov	x0, x23
    cb1c:	97ffdfb1 	bl	49e0 <fwp_rc_forget_slot>
    cb20:	17fff813 	b	ab6c <f0+0x538>
    cb24:	aa1703e0 	mov	x0, x23
    cb28:	97ffdfae 	bl	49e0 <fwp_rc_forget_slot>
    cb2c:	17fff842 	b	ac34 <f0+0x600>
    cb30:	aa1703e0 	mov	x0, x23
    cb34:	97ffdfab 	bl	49e0 <fwp_rc_forget_slot>
    cb38:	17fff864 	b	acc8 <f0+0x694>
    cb3c:	aa1703e0 	mov	x0, x23
    cb40:	97ffdfa8 	bl	49e0 <fwp_rc_forget_slot>
    cb44:	17fff88d 	b	ad78 <f0+0x744>
    cb48:	aa1703e0 	mov	x0, x23
    cb4c:	97ffdfa5 	bl	49e0 <fwp_rc_forget_slot>
    cb50:	17fff8ae 	b	ae08 <f0+0x7d4>
    cb54:	aa1703e0 	mov	x0, x23
    cb58:	97ffdfa2 	bl	49e0 <fwp_rc_forget_slot>
    cb5c:	17fff8dd 	b	aed0 <f0+0x89c>
    cb60:	aa1703e0 	mov	x0, x23
    cb64:	97ffdf9f 	bl	49e0 <fwp_rc_forget_slot>
    cb68:	17fff90c 	b	af98 <f0+0x964>
    cb6c:	aa1503e0 	mov	x0, x21
    cb70:	97ffdf9c 	bl	49e0 <fwp_rc_forget_slot>
    cb74:	17fff96f 	b	b130 <f0+0xafc>
    cb78:	aa1703e0 	mov	x0, x23
    cb7c:	97ffdf99 	bl	49e0 <fwp_rc_forget_slot>
    cb80:	17fffa1f 	b	b3fc <f0+0xdc8>
    cb84:	aa1703e0 	mov	x0, x23
    cb88:	97ffdf96 	bl	49e0 <fwp_rc_forget_slot>
    cb8c:	17fffa58 	b	b4ec <f0+0xeb8>
    cb90:	aa1703e0 	mov	x0, x23
    cb94:	97ffdf93 	bl	49e0 <fwp_rc_forget_slot>
    cb98:	17fffa83 	b	b5a4 <f0+0xf70>
    cb9c:	aa1503e0 	mov	x0, x21
    cba0:	97ffdf90 	bl	49e0 <fwp_rc_forget_slot>
    cba4:	17fffaae 	b	b65c <f0+0x1028>
    cba8:	aa1703e0 	mov	x0, x23
    cbac:	97ffdf8d 	bl	49e0 <fwp_rc_forget_slot>
    cbb0:	17fffafc 	b	b7a0 <f0+0x116c>
    cbb4:	aa1703e0 	mov	x0, x23
    cbb8:	97ffdf8a 	bl	49e0 <fwp_rc_forget_slot>
    cbbc:	17fffb1f 	b	b838 <f0+0x1204>
    cbc0:	aa1703e0 	mov	x0, x23
    cbc4:	97ffdf87 	bl	49e0 <fwp_rc_forget_slot>
    cbc8:	17fffb4a 	b	b8f0 <f0+0x12bc>
    cbcc:	aa1703e0 	mov	x0, x23
    cbd0:	97ffdf84 	bl	49e0 <fwp_rc_forget_slot>
    cbd4:	17fffb75 	b	b9a8 <f0+0x1374>
    cbd8:	aa1703e0 	mov	x0, x23
    cbdc:	97ffdf81 	bl	49e0 <fwp_rc_forget_slot>
    cbe0:	17fffba0 	b	ba60 <f0+0x142c>
    cbe4:	aa1703e0 	mov	x0, x23
    cbe8:	97ffdf7e 	bl	49e0 <fwp_rc_forget_slot>
    cbec:	17fffbcb 	b	bb18 <f0+0x14e4>
    cbf0:	aa1703e0 	mov	x0, x23
    cbf4:	97ffdf7b 	bl	49e0 <fwp_rc_forget_slot>
    cbf8:	17fffbf6 	b	bbd0 <f0+0x159c>
    cbfc:	aa1703e0 	mov	x0, x23
    cc00:	97ffdf78 	bl	49e0 <fwp_rc_forget_slot>
    cc04:	17fffc21 	b	bc88 <f0+0x1654>
    cc08:	aa1703e0 	mov	x0, x23
    cc0c:	97ffdf75 	bl	49e0 <fwp_rc_forget_slot>
    cc10:	17fffc53 	b	bd5c <f0+0x1728>
    cc14:	aa1703e0 	mov	x0, x23
    cc18:	97ffdf72 	bl	49e0 <fwp_rc_forget_slot>
    cc1c:	17fffc76 	b	bdf4 <f0+0x17c0>
    cc20:	aa1703e0 	mov	x0, x23
    cc24:	97ffdf6f 	bl	49e0 <fwp_rc_forget_slot>
    cc28:	17fffcaf 	b	bee4 <f0+0x18b0>
    cc2c:	aa1703e0 	mov	x0, x23
    cc30:	97ffdf6c 	bl	49e0 <fwp_rc_forget_slot>
    cc34:	17fffce1 	b	bfb8 <f0+0x1984>
    cc38:	aa1703e0 	mov	x0, x23
    cc3c:	97ffdf69 	bl	49e0 <fwp_rc_forget_slot>
    cc40:	17fffd04 	b	c050 <f0+0x1a1c>
    cc44:	aa1703e0 	mov	x0, x23
    cc48:	97ffdf66 	bl	49e0 <fwp_rc_forget_slot>
    cc4c:	17fffd2f 	b	c108 <f0+0x1ad4>
    cc50:	aa1703e0 	mov	x0, x23
    cc54:	97ffdf63 	bl	49e0 <fwp_rc_forget_slot>
    cc58:	17fffd6f 	b	c214 <f0+0x1be0>
    cc5c:	aa1703e0 	mov	x0, x23
    cc60:	97ffdf60 	bl	49e0 <fwp_rc_forget_slot>
    cc64:	17fffd92 	b	c2ac <f0+0x1c78>
    cc68:	aa1703e0 	mov	x0, x23
    cc6c:	97ffdf5d 	bl	49e0 <fwp_rc_forget_slot>
    cc70:	17fffdcb 	b	c39c <f0+0x1d68>
    cc74:	aa1703e0 	mov	x0, x23
    cc78:	97ffdf5a 	bl	49e0 <fwp_rc_forget_slot>
    cc7c:	17fffded 	b	c430 <f0+0x1dfc>
    cc80:	aa1703e0 	mov	x0, x23
    cc84:	97ffdf57 	bl	49e0 <fwp_rc_forget_slot>
    cc88:	17fffe10 	b	c4c8 <f0+0x1e94>
    cc8c:	aa1703e0 	mov	x0, x23
    cc90:	97ffdf54 	bl	49e0 <fwp_rc_forget_slot>
    cc94:	17fffe32 	b	c55c <f0+0x1f28>
    cc98:	aa1703e0 	mov	x0, x23
    cc9c:	97ffdf51 	bl	49e0 <fwp_rc_forget_slot>
    cca0:	17fffe72 	b	c668 <f0+0x2034>
    cca4:	aa1703e0 	mov	x0, x23
    cca8:	97ffdf4e 	bl	49e0 <fwp_rc_forget_slot>
    ccac:	17fffea4 	b	c73c <f0+0x2108>
    ccb0:	97ffd6d8 	bl	2810 <__stack_chk_fail@plt>

000000000000ccb4 <fwp_main_thread>:
    ccb4:	d10443ff 	sub	sp, sp, #0x110
    ccb8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    ccbc:	f947f400 	ldr	x0, [x0, #4072]
    ccc0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    ccc4:	910303fd 	add	x29, sp, #0xc0
    ccc8:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cccc:	b0000376 	adrp	x22, 79000 <fwp_root_context+0xb80>
    ccd0:	911982c1 	add	x1, x22, #0x660
    ccd4:	a90d53f3 	stp	x19, x20, [sp, #208]
    ccd8:	a90f63f7 	stp	x23, x24, [sp, #240]
    ccdc:	b953a421 	ldr	w1, [x1, #5028]
    cce0:	a9106bf9 	stp	x25, x26, [sp, #256]
    cce4:	f9400002 	ldr	x2, [x0]
    cce8:	f9005fe2 	str	x2, [sp, #184]
    ccec:	d2800002 	mov	x2, #0x0                   	// #0
    ccf0:	34002941 	cbz	w1, d218 <fwp_main_thread+0x564>
    ccf4:	911982c0 	add	x0, x22, #0x660
    ccf8:	b953a800 	ldr	w0, [x0, #5032]
    ccfc:	35002860 	cbnz	w0, d208 <fwp_main_thread+0x554>
    cd00:	91001fe2 	add	x2, sp, #0x7
    cd04:	900000b5 	adrp	x21, 20000 <__data_start>
    cd08:	900000a3 	adrp	x3, 20000 <__data_start>
    cd0c:	910182b3 	add	x19, x21, #0x60
    cd10:	91120063 	add	x3, x3, #0x480
    cd14:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cd18:	d2a00025 	mov	x5, #0x10000               	// #65536
    cd1c:	910023e0 	add	x0, sp, #0x8
    cd20:	d2800001 	mov	x1, #0x0                   	// #0
    cd24:	f90007e3 	str	x3, [sp, #8]
    cd28:	b90013ff 	str	wzr, [sp, #16]
    cd2c:	f9000fe5 	str	x5, [sp, #24]
    cd30:	a90a1262 	stp	x2, x4, [x19, #160]
    cd34:	97ffd64f 	bl	2670 <sigaltstack@plt>
    cd38:	35002880 	cbnz	w0, d248 <fwp_main_thread+0x594>
    cd3c:	4f000400 	movi	v0.4s, #0x0
    cd40:	9100a3e0 	add	x0, sp, #0x28
    cd44:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0xc>
    cd48:	52800082 	mov	w2, #0x4                   	// #4
    cd4c:	9100c021 	add	x1, x1, #0x30
    cd50:	72a10002 	movk	w2, #0x800, lsl #16
    cd54:	910083f4 	add	x20, sp, #0x20
    cd58:	f90013e1 	str	x1, [sp, #32]
    cd5c:	3d802000 	str	q0, [x0, #128]
    cd60:	b900abe2 	str	w2, [sp, #168]
    cd64:	ad000000 	stp	q0, q0, [x0]
    cd68:	ad010000 	stp	q0, q0, [x0, #32]
    cd6c:	ad020000 	stp	q0, q0, [x0, #64]
    cd70:	ad030000 	stp	q0, q0, [x0, #96]
    cd74:	97ffd697 	bl	27d0 <sigemptyset@plt>
    cd78:	35002680 	cbnz	w0, d248 <fwp_main_thread+0x594>
    cd7c:	aa1403e1 	mov	x1, x20
    cd80:	d2800002 	mov	x2, #0x0                   	// #0
    cd84:	52800160 	mov	w0, #0xb                   	// #11
    cd88:	97ffd6aa 	bl	2830 <sigaction@plt>
    cd8c:	350025e0 	cbnz	w0, d248 <fwp_main_thread+0x594>
    cd90:	aa1403e1 	mov	x1, x20
    cd94:	d2800002 	mov	x2, #0x0                   	// #0
    cd98:	528000e0 	mov	w0, #0x7                   	// #7
    cd9c:	97ffd6a5 	bl	2830 <sigaction@plt>
    cda0:	35002540 	cbnz	w0, d248 <fwp_main_thread+0x594>
    cda4:	911982c1 	add	x1, x22, #0x660
    cda8:	52800034 	mov	w20, #0x1                   	// #1
    cdac:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    cdb0:	910cc000 	add	x0, x0, #0x330
    cdb4:	b9015274 	str	w20, [x19, #336]
    cdb8:	fd4a1020 	ldr	d0, [x1, #5152]
    cdbc:	7e61d800 	ucvtf	d0, d0
    cdc0:	fd00b660 	str	d0, [x19, #360]
    cdc4:	940002e7 	bl	d960 <atexit>
    cdc8:	35002460 	cbnz	w0, d254 <fwp_main_thread+0x5a0>
    cdcc:	b943ea60 	ldr	w0, [x19, #1000]
    cdd0:	34002280 	cbz	w0, d220 <fwp_main_thread+0x56c>
    cdd4:	910182ba 	add	x26, x21, #0x60
    cdd8:	f9404f54 	ldr	x20, [x26, #152]
    cddc:	b4001094 	cbz	x20, cfec <fwp_main_thread+0x338>
    cde0:	aa1403f3 	mov	x19, x20
    cde4:	91010297 	add	x23, x20, #0x40
    cde8:	39414a99 	ldrb	w25, [x20, #82]
    cdec:	52800038 	mov	w24, #0x1                   	// #1
    cdf0:	39014a98 	strb	w24, [x20, #82]
    cdf4:	f9401680 	ldr	x0, [x20, #40]
    cdf8:	b4000620 	cbz	x0, cebc <fwp_main_thread+0x208>
    cdfc:	f9403281 	ldr	x1, [x20, #96]
    ce00:	39414680 	ldrb	w0, [x20, #81]
    ce04:	b4000b21 	cbz	x1, cf68 <fwp_main_thread+0x2b4>
    ce08:	36000a60 	tbz	w0, #0, cf54 <fwp_main_thread+0x2a0>
    ce0c:	39414a62 	ldrb	w2, [x19, #82]
    ce10:	f9402280 	ldr	x0, [x20, #64]
    ce14:	37000d42 	tbnz	w2, #0, cfbc <fwp_main_thread+0x308>
    ce18:	f9403261 	ldr	x1, [x19, #96]
    ce1c:	a911fe77 	stp	x23, xzr, [x19, #280]
    ce20:	f9009660 	str	x0, [x19, #296]
    ce24:	b4000040 	cbz	x0, ce2c <fwp_main_thread+0x178>
    ce28:	f9009013 	str	x19, [x0, #288]
    ce2c:	f9002293 	str	x19, [x20, #64]
    ce30:	b4000101 	cbz	x1, ce50 <fwp_main_thread+0x19c>
    ce34:	f940a740 	ldr	x0, [x26, #328]
    ce38:	39015678 	strb	w24, [x19, #85]
    ce3c:	f9003661 	str	x1, [x19, #104]
    ce40:	a910827f 	stp	xzr, x0, [x19, #264]
    ce44:	b4000040 	cbz	x0, ce4c <fwp_main_thread+0x198>
    ce48:	f9008413 	str	x19, [x0, #264]
    ce4c:	f900a753 	str	x19, [x26, #328]
    ce50:	39015a7f 	strb	wzr, [x19, #86]
    ce54:	97ffe6e0 	bl	69d4 <fwp_block>
    ce58:	f9408e62 	ldr	x2, [x19, #280]
    ce5c:	b4000142 	cbz	x2, ce84 <fwp_main_thread+0x1d0>
    ce60:	a9520261 	ldp	x1, x0, [x19, #288]
    ce64:	b4000b81 	cbz	x1, cfd4 <fwp_main_thread+0x320>
    ce68:	f9009420 	str	x0, [x1, #296]
    ce6c:	f9409660 	ldr	x0, [x19, #296]
    ce70:	b4000040 	cbz	x0, ce78 <fwp_main_thread+0x1c4>
    ce74:	f9009001 	str	x1, [x0, #288]
    ce78:	91080260 	add	x0, x19, #0x200
    ce7c:	f900967f 	str	xzr, [x19, #296]
    ce80:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    ce84:	39415660 	ldrb	w0, [x19, #85]
    ce88:	f9404f42 	ldr	x2, [x26, #152]
    ce8c:	36000940 	tbz	w0, #0, cfb4 <fwp_main_thread+0x300>
    ce90:	a9508261 	ldp	x1, x0, [x19, #264]
    ce94:	b4000a41 	cbz	x1, cfdc <fwp_main_thread+0x328>
    ce98:	f9008820 	str	x0, [x1, #272]
    ce9c:	b4000040 	cbz	x0, cea4 <fwp_main_thread+0x1f0>
    cea0:	f9008401 	str	x1, [x0, #264]
    cea4:	91080260 	add	x0, x19, #0x200
    cea8:	3901567f 	strb	wzr, [x19, #85]
    ceac:	aa0203f3 	mov	x19, x2
    ceb0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    ceb4:	f9401680 	ldr	x0, [x20, #40]
    ceb8:	b5fffa20 	cbnz	x0, cdfc <fwp_main_thread+0x148>
    cebc:	910182a0 	add	x0, x21, #0x60
    cec0:	39014a99 	strb	w25, [x20, #82]
    cec4:	f941e400 	ldr	x0, [x0, #968]
    cec8:	b4001820 	cbz	x0, d1cc <fwp_main_thread+0x518>
    cecc:	910182a0 	add	x0, x21, #0x60
    ced0:	f9420001 	ldr	x1, [x0, #1024]
    ced4:	b903f81f 	str	wzr, [x0, #1016]
    ced8:	eb13003f 	cmp	x1, x19
    cedc:	54001941 	b.ne	d204 <fwp_main_thread+0x550>  // b.any
    cee0:	b4000913 	cbz	x19, d000 <fwp_main_thread+0x34c>
    cee4:	910182a0 	add	x0, x21, #0x60
    cee8:	52800021 	mov	w1, #0x1                   	// #1
    ceec:	39014a61 	strb	w1, [x19, #82]
    cef0:	f941d005 	ldr	x5, [x0, #928]
    cef4:	b4000865 	cbz	x5, d000 <fwp_main_thread+0x34c>
    cef8:	394140a0 	ldrb	w0, [x5, #80]
    cefc:	37000060 	tbnz	w0, #0, cf08 <fwp_main_thread+0x254>
    cf00:	aa0503e0 	mov	x0, x5
    cf04:	97ffd9db 	bl	3670 <fwp_cancel_tree.part.0>
    cf08:	f9409ca5 	ldr	x5, [x5, #312]
    cf0c:	b5ffff65 	cbnz	x5, cef8 <fwp_main_thread+0x244>
    cf10:	910182b4 	add	x20, x21, #0x60
    cf14:	52800037 	mov	w23, #0x1                   	// #1
    cf18:	f9402a60 	ldr	x0, [x19, #80]
    cf1c:	f2001c1f 	tst	x0, #0xff000000ff
    cf20:	540000e1 	b.ne	cf3c <fwp_main_thread+0x288>  // b.any
    cf24:	f9406280 	ldr	x0, [x20, #192]
    cf28:	39015277 	strb	w23, [x19, #84]
    cf2c:	f900827f 	str	xzr, [x19, #256]
    cf30:	b40005a0 	cbz	x0, cfe4 <fwp_main_thread+0x330>
    cf34:	f9008013 	str	x19, [x0, #256]
    cf38:	f9006293 	str	x19, [x20, #192]
    cf3c:	97ffe6a6 	bl	69d4 <fwp_block>
    cf40:	97ffe638 	bl	6820 <fwp_free_zombie>
    cf44:	f941d280 	ldr	x0, [x20, #928]
    cf48:	b40005c0 	cbz	x0, d000 <fwp_main_thread+0x34c>
    cf4c:	f9420293 	ldr	x19, [x20, #1024]
    cf50:	17fffff2 	b	cf18 <fwp_main_thread+0x264>
    cf54:	97ffda6b 	bl	3900 <fwp_now_ns>
    cf58:	f9403281 	ldr	x1, [x20, #96]
    cf5c:	eb01001f 	cmp	x0, x1
    cf60:	5400128a 	b.ge	d1b0 <fwp_main_thread+0x4fc>  // b.tcont
    cf64:	39414680 	ldrb	w0, [x20, #81]
    cf68:	39414a62 	ldrb	w2, [x19, #82]
    cf6c:	3707f520 	tbnz	w0, #0, ce10 <fwp_main_thread+0x15c>
    cf70:	f9403281 	ldr	x1, [x20, #96]
    cf74:	370001c2 	tbnz	w2, #0, cfac <fwp_main_thread+0x2f8>
    cf78:	f9403260 	ldr	x0, [x19, #96]
    cf7c:	b4000180 	cbz	x0, cfac <fwp_main_thread+0x2f8>
    cf80:	b4000061 	cbz	x1, cf8c <fwp_main_thread+0x2d8>
    cf84:	eb01001f 	cmp	x0, x1
    cf88:	9a81d000 	csel	x0, x0, x1, le
    cf8c:	f9402281 	ldr	x1, [x20, #64]
    cf90:	a911fe77 	stp	x23, xzr, [x19, #280]
    cf94:	f9009661 	str	x1, [x19, #296]
    cf98:	b40014c1 	cbz	x1, d230 <fwp_main_thread+0x57c>
    cf9c:	f9009033 	str	x19, [x1, #288]
    cfa0:	aa0003e1 	mov	x1, x0
    cfa4:	f9002293 	str	x19, [x20, #64]
    cfa8:	17ffffa3 	b	ce34 <fwp_main_thread+0x180>
    cfac:	f9402280 	ldr	x0, [x20, #64]
    cfb0:	17ffff9b 	b	ce1c <fwp_main_thread+0x168>
    cfb4:	aa0203f3 	mov	x19, x2
    cfb8:	17ffff8f 	b	cdf4 <fwp_main_thread+0x140>
    cfbc:	a911fe77 	stp	x23, xzr, [x19, #280]
    cfc0:	f9009660 	str	x0, [x19, #296]
    cfc4:	b4000040 	cbz	x0, cfcc <fwp_main_thread+0x318>
    cfc8:	f9009013 	str	x19, [x0, #288]
    cfcc:	f9002293 	str	x19, [x20, #64]
    cfd0:	17ffffa0 	b	ce50 <fwp_main_thread+0x19c>
    cfd4:	f9000040 	str	x0, [x2]
    cfd8:	17ffffa6 	b	ce70 <fwp_main_thread+0x1bc>
    cfdc:	f900a740 	str	x0, [x26, #328]
    cfe0:	17ffffaf 	b	ce9c <fwp_main_thread+0x1e8>
    cfe4:	f9006693 	str	x19, [x20, #200]
    cfe8:	17ffffd4 	b	cf38 <fwp_main_thread+0x284>
    cfec:	f941e740 	ldr	x0, [x26, #968]
    cff0:	b4000ec0 	cbz	x0, d1c8 <fwp_main_thread+0x514>
    cff4:	f9420340 	ldr	x0, [x26, #1024]
    cff8:	b903fb5f 	str	wzr, [x26, #1016]
    cffc:	b5001040 	cbnz	x0, d204 <fwp_main_thread+0x550>
    d000:	910182b4 	add	x20, x21, #0x60
    d004:	97ffe607 	bl	6820 <fwp_free_zombie>
    d008:	f9406680 	ldr	x0, [x20, #200]
    d00c:	b5000fc0 	cbnz	x0, d204 <fwp_main_thread+0x550>
    d010:	f940a680 	ldr	x0, [x20, #328]
    d014:	b5000f80 	cbnz	x0, d204 <fwp_main_thread+0x550>
    d018:	b9419293 	ldr	w19, [x20, #400]
    d01c:	340001d3 	cbz	w19, d054 <fwp_main_thread+0x3a0>
    d020:	93407e77 	sxtw	x23, w19
    d024:	51000673 	sub	w19, w19, #0x1
    d028:	d1000af7 	sub	x23, x23, #0x2
    d02c:	91068298 	add	x24, x20, #0x1a0
    d030:	cb3342f7 	sub	x23, x23, w19, uxtw
    d034:	93407e73 	sxtw	x19, w19
    d038:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    d03c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    d040:	b9019293 	str	w19, [x20, #400]
    d044:	d1000673 	sub	x19, x19, #0x1
    d048:	97ffd63a 	bl	2930 <munmap@plt>
    d04c:	eb1302ff 	cmp	x23, x19
    d050:	54ffff41 	b.ne	d038 <fwp_main_thread+0x384>  // b.any
    d054:	f0000093 	adrp	x19, 20000 <__data_start>
    d058:	91004260 	add	x0, x19, #0x10
    d05c:	b9403000 	ldr	w0, [x0, #48]
    d060:	37f80040 	tbnz	w0, #31, d068 <fwp_main_thread+0x3b4>
    d064:	97ffd5ef 	bl	2820 <close@plt>
    d068:	910182a0 	add	x0, x21, #0x60
    d06c:	91004261 	add	x1, x19, #0x10
    d070:	12800002 	mov	w2, #0xffffffff            	// #-1
    d074:	d2800013 	mov	x19, #0x0                   	// #0
    d078:	f9420417 	ldr	x23, [x0, #1032]
    d07c:	b9003022 	str	w2, [x1, #48]
    d080:	f9420814 	ldr	x20, [x0, #1040]
    d084:	b4000177 	cbz	x23, d0b0 <fwp_main_thread+0x3fc>
    d088:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    d08c:	b40000c0 	cbz	x0, d0a4 <fwp_main_thread+0x3f0>
    d090:	f9400001 	ldr	x1, [x0]
    d094:	b5000b81 	cbnz	x1, d204 <fwp_main_thread+0x550>
    d098:	f9400401 	ldr	x1, [x0, #8]
    d09c:	b5000b41 	cbnz	x1, d204 <fwp_main_thread+0x550>
    d0a0:	97ffdef0 	bl	4c60 <fwp_mem_free>
    d0a4:	91000673 	add	x19, x19, #0x1
    d0a8:	eb1302ff 	cmp	x23, x19
    d0ac:	54fffee1 	b.ne	d088 <fwp_main_thread+0x3d4>  // b.any
    d0b0:	aa1403e0 	mov	x0, x20
    d0b4:	97ffdeeb 	bl	4c60 <fwp_mem_free>
    d0b8:	910182a0 	add	x0, x21, #0x60
    d0bc:	f9420013 	ldr	x19, [x0, #1024]
    d0c0:	f902041f 	str	xzr, [x0, #1032]
    d0c4:	f902081f 	str	xzr, [x0, #1040]
    d0c8:	b40001f3 	cbz	x19, d104 <fwp_main_thread+0x450>
    d0cc:	f9401661 	ldr	x1, [x19, #40]
    d0d0:	b50009a1 	cbnz	x1, d204 <fwp_main_thread+0x550>
    d0d4:	f9405661 	ldr	x1, [x19, #168]
    d0d8:	b5000961 	cbnz	x1, d204 <fwp_main_thread+0x550>
    d0dc:	f941e401 	ldr	x1, [x0, #968]
    d0e0:	b5000921 	cbnz	x1, d204 <fwp_main_thread+0x550>
    d0e4:	f941ec00 	ldr	x0, [x0, #984]
    d0e8:	b50008e0 	cbnz	x0, d204 <fwp_main_thread+0x550>
    d0ec:	d2823a02 	mov	x2, #0x11d0                	// #4560
    d0f0:	f0000340 	adrp	x0, 78000 <ad_raw_blocks+0x17b80>
    d0f4:	91120000 	add	x0, x0, #0x480
    d0f8:	97ffd5ba 	bl	27e0 <memset@plt>
    d0fc:	aa1303e0 	mov	x0, x19
    d100:	97ffded8 	bl	4c60 <fwp_mem_free>
    d104:	910182a6 	add	x6, x21, #0x60
    d108:	911982d6 	add	x22, x22, #0x660
    d10c:	3dc01aa1 	ldr	q1, [x21, #96]
    d110:	52800041 	mov	w1, #0x2                   	// #2
    d114:	3dc004c2 	ldr	q2, [x6, #16]
    d118:	b0000002 	adrp	x2, e000 <_IO_stdin_used+0x670>
    d11c:	fd4a12c0 	ldr	d0, [x22, #5152]
    d120:	91072042 	add	x2, x2, #0x1c8
    d124:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    d128:	fd40b4c1 	ldr	d1, [x6, #360]
    d12c:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d130:	f947e800 	ldr	x0, [x0, #4048]
    d134:	7e61d800 	ucvtf	d0, d0
    d138:	a95590c3 	ldp	x3, x4, [x6, #344]
    d13c:	f9004cdf 	str	xzr, [x6, #152]
    d140:	f9400000 	ldr	x0, [x0]
    d144:	1e613801 	fsub	d1, d0, d1
    d148:	f940bcc5 	ldr	x5, [x6, #376]
    d14c:	b90150df 	str	wzr, [x6, #336]
    d150:	5ef1b842 	addp	d2, v2.2d
    d154:	fd40b8c0 	ldr	d0, [x6, #368]
    d158:	f90200df 	str	xzr, [x6, #1024]
    d15c:	fd0058c2 	str	d2, [x6, #176]
    d160:	97ffd5c8 	bl	2880 <__fprintf_chk@plt>
    d164:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d168:	f947ec00 	ldr	x0, [x0, #4056]
    d16c:	f9400000 	ldr	x0, [x0]
    d170:	97ffd5f4 	bl	2940 <fflush@plt>
    d174:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d178:	f947f400 	ldr	x0, [x0, #4072]
    d17c:	f9405fe2 	ldr	x2, [sp, #184]
    d180:	f9400001 	ldr	x1, [x0]
    d184:	eb010042 	subs	x2, x2, x1
    d188:	d2800001 	mov	x1, #0x0                   	// #0
    d18c:	540006a1 	b.ne	d260 <fwp_main_thread+0x5ac>  // b.any
    d190:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d194:	d2800000 	mov	x0, #0x0                   	// #0
    d198:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d19c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d1a0:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d1a4:	a9506bf9 	ldp	x25, x26, [sp, #256]
    d1a8:	910443ff 	add	sp, sp, #0x110
    d1ac:	d65f03c0 	ret
    d1b0:	39414280 	ldrb	w0, [x20, #80]
    d1b4:	3707ed80 	tbnz	w0, #0, cf64 <fwp_main_thread+0x2b0>
    d1b8:	aa1403e0 	mov	x0, x20
    d1bc:	97ffd92d 	bl	3670 <fwp_cancel_tree.part.0>
    d1c0:	39414680 	ldrb	w0, [x20, #81]
    d1c4:	17ffff69 	b	cf68 <fwp_main_thread+0x2b4>
    d1c8:	d2800013 	mov	x19, #0x0                   	// #0
    d1cc:	910182b4 	add	x20, x21, #0x60
    d1d0:	f941ee80 	ldr	x0, [x20, #984]
    d1d4:	b5ffe7c0 	cbnz	x0, cecc <fwp_main_thread+0x218>
    d1d8:	f941e280 	ldr	x0, [x20, #960]
    d1dc:	97ffdea1 	bl	4c60 <fwp_mem_free>
    d1e0:	f901e29f 	str	xzr, [x20, #960]
    d1e4:	f901ea9f 	str	xzr, [x20, #976]
    d1e8:	f9420280 	ldr	x0, [x20, #1024]
    d1ec:	b4000293 	cbz	x19, d23c <fwp_main_thread+0x588>
    d1f0:	f900567f 	str	xzr, [x19, #168]
    d1f4:	f9005e7f 	str	xzr, [x19, #184]
    d1f8:	b903fa9f 	str	wzr, [x20, #1016]
    d1fc:	eb13001f 	cmp	x0, x19
    d200:	54ffe720 	b.eq	cee4 <fwp_main_thread+0x230>  // b.none
    d204:	97ffd597 	bl	2860 <abort@plt>
    d208:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    d20c:	913c8000 	add	x0, x0, #0xf20
    d210:	940001d4 	bl	d960 <atexit>
    d214:	17fffebb 	b	cd00 <fwp_main_thread+0x4c>
    d218:	97ffdb9b 	bl	4084 <fwp_heap_init>
    d21c:	17fffeb6 	b	ccf4 <fwp_main_thread+0x40>
    d220:	97fff505 	bl	a634 <f0>
    d224:	b903ea74 	str	w20, [x19, #1000]
    d228:	f901fa60 	str	x0, [x19, #1008]
    d22c:	17fffeea 	b	cdd4 <fwp_main_thread+0x120>
    d230:	aa0003e1 	mov	x1, x0
    d234:	f9002293 	str	x19, [x20, #64]
    d238:	17fffeff 	b	ce34 <fwp_main_thread+0x180>
    d23c:	b903fa9f 	str	wzr, [x20, #1016]
    d240:	b4ffee00 	cbz	x0, d000 <fwp_main_thread+0x34c>
    d244:	97ffd587 	bl	2860 <abort@plt>
    d248:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x670>
    d24c:	91060000 	add	x0, x0, #0x180
    d250:	97ffd94c 	bl	3780 <fwp_trap>
    d254:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x670>
    d258:	9106a000 	add	x0, x0, #0x1a8
    d25c:	97ffd829 	bl	3300 <ad_raw_fail>
    d260:	97ffd56c 	bl	2810 <__stack_chk_fail@plt>
    d264:	d503201f 	nop
    d268:	d503201f 	nop
    d26c:	d503201f 	nop

000000000000d270 <__divti3>:
    d270:	d503245f 	bti	c
    d274:	d2800004 	mov	x4, #0x0                   	// #0
    d278:	b7f80721 	tbnz	x1, #63, d35c <__divti3+0xec>
    d27c:	b6f80083 	tbz	x3, #63, d28c <__divti3+0x1c>
    d280:	eb0203e2 	negs	x2, x2
    d284:	aa2403e4 	mvn	x4, x4
    d288:	da0303e3 	ngc	x3, x3
    d28c:	aa0203e6 	mov	x6, x2
    d290:	aa0003e7 	mov	x7, x0
    d294:	aa0103e5 	mov	x5, x1
    d298:	b5000583 	cbnz	x3, d348 <__divti3+0xd8>
    d29c:	eb01005f 	cmp	x2, x1
    d2a0:	54000e69 	b.ls	d46c <__divti3+0x1fc>  // b.plast
    d2a4:	dac01040 	clz	x0, x2
    d2a8:	b40000e0 	cbz	x0, d2c4 <__divti3+0x54>
    d2ac:	4b0003e1 	neg	w1, w0
    d2b0:	9ac020a5 	lsl	x5, x5, x0
    d2b4:	9ac02046 	lsl	x6, x2, x0
    d2b8:	9ac124e1 	lsr	x1, x7, x1
    d2bc:	aa050025 	orr	x5, x1, x5
    d2c0:	9ac020e7 	lsl	x7, x7, x0
    d2c4:	d360fcc8 	lsr	x8, x6, #32
    d2c8:	92407cc2 	and	x2, x6, #0xffffffff
    d2cc:	9ac808a3 	udiv	x3, x5, x8
    d2d0:	9b089465 	msub	x5, x3, x8, x5
    d2d4:	aa0303e0 	mov	x0, x3
    d2d8:	9b037c41 	mul	x1, x2, x3
    d2dc:	93c780a5 	extr	x5, x5, x7, #32
    d2e0:	eb05003f 	cmp	x1, x5
    d2e4:	540000a9 	b.ls	d2f8 <__divti3+0x88>  // b.plast
    d2e8:	ab0500c5 	adds	x5, x6, x5
    d2ec:	d1000460 	sub	x0, x3, #0x1
    d2f0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d2f4:	540015a8 	b.hi	d5a8 <__divti3+0x338>  // b.pmore
    d2f8:	cb0100a5 	sub	x5, x5, x1
    d2fc:	9ac808a3 	udiv	x3, x5, x8
    d300:	9b089465 	msub	x5, x3, x8, x5
    d304:	aa0303e1 	mov	x1, x3
    d308:	9b037c42 	mul	x2, x2, x3
    d30c:	aa0703e3 	mov	x3, x7
    d310:	b3607ca3 	bfi	x3, x5, #32, #32
    d314:	eb03005f 	cmp	x2, x3
    d318:	540000c9 	b.ls	d330 <__divti3+0xc0>  // b.plast
    d31c:	ab0300c3 	adds	x3, x6, x3
    d320:	d1000425 	sub	x5, x1, #0x1
    d324:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d328:	d1000821 	sub	x1, x1, #0x2
    d32c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d330:	aa008020 	orr	x0, x1, x0, lsl #32
    d334:	d2800001 	mov	x1, #0x0                   	// #0
    d338:	b4000064 	cbz	x4, d344 <__divti3+0xd4>
    d33c:	eb0003e0 	negs	x0, x0
    d340:	da0103e1 	ngc	x1, x1
    d344:	d65f03c0 	ret
    d348:	eb01007f 	cmp	x3, x1
    d34c:	54000109 	b.ls	d36c <__divti3+0xfc>  // b.plast
    d350:	d2800001 	mov	x1, #0x0                   	// #0
    d354:	d2800000 	mov	x0, #0x0                   	// #0
    d358:	17fffff8 	b	d338 <__divti3+0xc8>
    d35c:	eb0003e0 	negs	x0, x0
    d360:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d364:	da0103e1 	ngc	x1, x1
    d368:	17ffffc5 	b	d27c <__divti3+0xc>
    d36c:	dac01067 	clz	x7, x3
    d370:	b40010e7 	cbz	x7, d58c <__divti3+0x31c>
    d374:	d2800805 	mov	x5, #0x40                  	// #64
    d378:	cb0700a5 	sub	x5, x5, x7
    d37c:	9ac72063 	lsl	x3, x3, x7
    d380:	9ac52448 	lsr	x8, x2, x5
    d384:	aa030108 	orr	x8, x8, x3
    d388:	9ac52426 	lsr	x6, x1, x5
    d38c:	92407d0a 	and	x10, x8, #0xffffffff
    d390:	d360fd09 	lsr	x9, x8, #32
    d394:	9ac52403 	lsr	x3, x0, x5
    d398:	9ac72021 	lsl	x1, x1, x7
    d39c:	aa010063 	orr	x3, x3, x1
    d3a0:	9ac72042 	lsl	x2, x2, x7
    d3a4:	9ac908cb 	udiv	x11, x6, x9
    d3a8:	9b099965 	msub	x5, x11, x9, x6
    d3ac:	aa0b03e1 	mov	x1, x11
    d3b0:	9b0b7d46 	mul	x6, x10, x11
    d3b4:	93c380a5 	extr	x5, x5, x3, #32
    d3b8:	eb0500df 	cmp	x6, x5
    d3bc:	540000a9 	b.ls	d3d0 <__divti3+0x160>  // b.plast
    d3c0:	ab050105 	adds	x5, x8, x5
    d3c4:	d1000561 	sub	x1, x11, #0x1
    d3c8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d3cc:	54000f48 	b.hi	d5b4 <__divti3+0x344>  // b.pmore
    d3d0:	cb0600a6 	sub	x6, x5, x6
    d3d4:	9ac908cb 	udiv	x11, x6, x9
    d3d8:	9b099969 	msub	x9, x11, x9, x6
    d3dc:	aa0b03e5 	mov	x5, x11
    d3e0:	9b0b7d4a 	mul	x10, x10, x11
    d3e4:	b3607d23 	bfi	x3, x9, #32, #32
    d3e8:	eb03015f 	cmp	x10, x3
    d3ec:	540000a9 	b.ls	d400 <__divti3+0x190>  // b.plast
    d3f0:	ab030103 	adds	x3, x8, x3
    d3f4:	d1000565 	sub	x5, x11, #0x1
    d3f8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d3fc:	54000e28 	b.hi	d5c0 <__divti3+0x350>  // b.pmore
    d400:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d404:	92407c48 	and	x8, x2, #0xffffffff
    d408:	2a0503e5 	mov	w5, w5
    d40c:	d360fc42 	lsr	x2, x2, #32
    d410:	d360fc26 	lsr	x6, x1, #32
    d414:	cb0a0063 	sub	x3, x3, x10
    d418:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d41c:	9b087caa 	mul	x10, x5, x8
    d420:	9b087cc8 	mul	x8, x6, x8
    d424:	9b0220a5 	madd	x5, x5, x2, x8
    d428:	9b027cc6 	mul	x6, x6, x2
    d42c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d430:	8b0900c5 	add	x5, x6, x9
    d434:	eb02011f 	cmp	x8, x2
    d438:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d43c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d440:	eb06007f 	cmp	x3, x6
    d444:	540000e3 	b.cc	d460 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d448:	92407d4a 	and	x10, x10, #0xffffffff
    d44c:	9ac72000 	lsl	x0, x0, x7
    d450:	8b028142 	add	x2, x10, x2, lsl #32
    d454:	eb02001f 	cmp	x0, x2
    d458:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d45c:	54000a01 	b.ne	d59c <__divti3+0x32c>  // b.any
    d460:	d1000420 	sub	x0, x1, #0x1
    d464:	d2800001 	mov	x1, #0x0                   	// #0
    d468:	17ffffb4 	b	d338 <__divti3+0xc8>
    d46c:	b5000062 	cbnz	x2, d478 <__divti3+0x208>
    d470:	d2800022 	mov	x2, #0x1                   	// #1
    d474:	9ac30846 	udiv	x6, x2, x3
    d478:	dac010c8 	clz	x8, x6
    d47c:	b5000408 	cbnz	x8, d4fc <__divti3+0x28c>
    d480:	d360fcc9 	lsr	x9, x6, #32
    d484:	92407cc5 	and	x5, x6, #0xffffffff
    d488:	cb060023 	sub	x3, x1, x6
    d48c:	d2800021 	mov	x1, #0x1                   	// #1
    d490:	9ac90868 	udiv	x8, x3, x9
    d494:	9b098d03 	msub	x3, x8, x9, x3
    d498:	aa0803e0 	mov	x0, x8
    d49c:	9b057d02 	mul	x2, x8, x5
    d4a0:	93c78063 	extr	x3, x3, x7, #32
    d4a4:	eb03005f 	cmp	x2, x3
    d4a8:	540000a9 	b.ls	d4bc <__divti3+0x24c>  // b.plast
    d4ac:	ab0300c3 	adds	x3, x6, x3
    d4b0:	d1000500 	sub	x0, x8, #0x1
    d4b4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d4b8:	54000968 	b.hi	d5e4 <__divti3+0x374>  // b.pmore
    d4bc:	cb020063 	sub	x3, x3, x2
    d4c0:	9ac90862 	udiv	x2, x3, x9
    d4c4:	aa0203e8 	mov	x8, x2
    d4c8:	9b098c42 	msub	x2, x2, x9, x3
    d4cc:	aa0703e3 	mov	x3, x7
    d4d0:	9b057d05 	mul	x5, x8, x5
    d4d4:	b3607c43 	bfi	x3, x2, #32, #32
    d4d8:	eb0300bf 	cmp	x5, x3
    d4dc:	540000c9 	b.ls	d4f4 <__divti3+0x284>  // b.plast
    d4e0:	ab0300c2 	adds	x2, x6, x3
    d4e4:	d1000503 	sub	x3, x8, #0x1
    d4e8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d4ec:	d1000908 	sub	x8, x8, #0x2
    d4f0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d4f4:	aa008100 	orr	x0, x8, x0, lsl #32
    d4f8:	17ffff90 	b	d338 <__divti3+0xc8>
    d4fc:	9ac820c6 	lsl	x6, x6, x8
    d500:	d2800803 	mov	x3, #0x40                  	// #64
    d504:	cb080063 	sub	x3, x3, x8
    d508:	d360fcc9 	lsr	x9, x6, #32
    d50c:	9ac82027 	lsl	x7, x1, x8
    d510:	92407cc5 	and	x5, x6, #0xffffffff
    d514:	9ac32422 	lsr	x2, x1, x3
    d518:	9ac32403 	lsr	x3, x0, x3
    d51c:	aa070063 	orr	x3, x3, x7
    d520:	9ac9084a 	udiv	x10, x2, x9
    d524:	9ac82007 	lsl	x7, x0, x8
    d528:	9b098940 	msub	x0, x10, x9, x2
    d52c:	aa0a03e1 	mov	x1, x10
    d530:	9b0a7ca2 	mul	x2, x5, x10
    d534:	93c38000 	extr	x0, x0, x3, #32
    d538:	eb00005f 	cmp	x2, x0
    d53c:	540000a9 	b.ls	d550 <__divti3+0x2e0>  // b.plast
    d540:	ab0000c0 	adds	x0, x6, x0
    d544:	d1000541 	sub	x1, x10, #0x1
    d548:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d54c:	54000468 	b.hi	d5d8 <__divti3+0x368>  // b.pmore
    d550:	cb020000 	sub	x0, x0, x2
    d554:	9ac9080a 	udiv	x10, x0, x9
    d558:	9b098140 	msub	x0, x10, x9, x0
    d55c:	aa0a03e2 	mov	x2, x10
    d560:	9b0a7ca8 	mul	x8, x5, x10
    d564:	b3607c03 	bfi	x3, x0, #32, #32
    d568:	eb03011f 	cmp	x8, x3
    d56c:	540000a9 	b.ls	d580 <__divti3+0x310>  // b.plast
    d570:	ab0300c3 	adds	x3, x6, x3
    d574:	d1000542 	sub	x2, x10, #0x1
    d578:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d57c:	54000288 	b.hi	d5cc <__divti3+0x35c>  // b.pmore
    d580:	cb080063 	sub	x3, x3, x8
    d584:	aa018041 	orr	x1, x2, x1, lsl #32
    d588:	17ffffc2 	b	d490 <__divti3+0x220>
    d58c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d590:	d2800001 	mov	x1, #0x0                   	// #0
    d594:	9a9f87e0 	cset	x0, ls	// ls = plast
    d598:	17ffff68 	b	d338 <__divti3+0xc8>
    d59c:	aa0103e0 	mov	x0, x1
    d5a0:	d2800001 	mov	x1, #0x0                   	// #0
    d5a4:	17ffff65 	b	d338 <__divti3+0xc8>
    d5a8:	d1000860 	sub	x0, x3, #0x2
    d5ac:	8b0600a5 	add	x5, x5, x6
    d5b0:	17ffff52 	b	d2f8 <__divti3+0x88>
    d5b4:	d1000961 	sub	x1, x11, #0x2
    d5b8:	8b0800a5 	add	x5, x5, x8
    d5bc:	17ffff85 	b	d3d0 <__divti3+0x160>
    d5c0:	d1000965 	sub	x5, x11, #0x2
    d5c4:	8b080063 	add	x3, x3, x8
    d5c8:	17ffff8e 	b	d400 <__divti3+0x190>
    d5cc:	d1000942 	sub	x2, x10, #0x2
    d5d0:	8b060063 	add	x3, x3, x6
    d5d4:	17ffffeb 	b	d580 <__divti3+0x310>
    d5d8:	d1000941 	sub	x1, x10, #0x2
    d5dc:	8b060000 	add	x0, x0, x6
    d5e0:	17ffffdc 	b	d550 <__divti3+0x2e0>
    d5e4:	d1000900 	sub	x0, x8, #0x2
    d5e8:	8b060063 	add	x3, x3, x6
    d5ec:	17ffffb4 	b	d4bc <__divti3+0x24c>

000000000000d5f0 <__modti3>:
    d5f0:	d503245f 	bti	c
    d5f4:	d2800004 	mov	x4, #0x0                   	// #0
    d5f8:	b6f80081 	tbz	x1, #63, d608 <__modti3+0x18>
    d5fc:	eb0003e0 	negs	x0, x0
    d600:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d604:	da0103e1 	ngc	x1, x1
    d608:	f100007f 	cmp	x3, #0x0
    d60c:	5400128b 	b.lt	d85c <__modti3+0x26c>  // b.tstop
    d610:	aa0003e7 	mov	x7, x0
    d614:	aa0103e6 	mov	x6, x1
    d618:	540004e1 	b.ne	d6b4 <__modti3+0xc4>  // b.any
    d61c:	eb02003f 	cmp	x1, x2
    d620:	54000dc2 	b.cs	d7d8 <__modti3+0x1e8>  // b.hs, b.nlast
    d624:	dac01043 	clz	x3, x2
    d628:	aa0303e5 	mov	x5, x3
    d62c:	b40000e3 	cbz	x3, d648 <__modti3+0x58>
    d630:	4b0303e6 	neg	w6, w3
    d634:	9ac32021 	lsl	x1, x1, x3
    d638:	9ac32042 	lsl	x2, x2, x3
    d63c:	9ac62406 	lsr	x6, x0, x6
    d640:	aa0100c6 	orr	x6, x6, x1
    d644:	9ac32007 	lsl	x7, x0, x3
    d648:	d360fc40 	lsr	x0, x2, #32
    d64c:	92407c43 	and	x3, x2, #0xffffffff
    d650:	9ac008c1 	udiv	x1, x6, x0
    d654:	9b009826 	msub	x6, x1, x0, x6
    d658:	9b017c61 	mul	x1, x3, x1
    d65c:	93c780c6 	extr	x6, x6, x7, #32
    d660:	eb06003f 	cmp	x1, x6
    d664:	540000a9 	b.ls	d678 <__modti3+0x88>  // b.plast
    d668:	ab060046 	adds	x6, x2, x6
    d66c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d670:	8b0200c8 	add	x8, x6, x2
    d674:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d678:	cb0100c6 	sub	x6, x6, x1
    d67c:	9ac008c8 	udiv	x8, x6, x0
    d680:	9b009901 	msub	x1, x8, x0, x6
    d684:	aa0703e0 	mov	x0, x7
    d688:	9b087c63 	mul	x3, x3, x8
    d68c:	b3607c20 	bfi	x0, x1, #32, #32
    d690:	eb00007f 	cmp	x3, x0
    d694:	54001088 	b.hi	d8a4 <__modti3+0x2b4>  // b.pmore
    d698:	cb030000 	sub	x0, x0, x3
    d69c:	9ac52400 	lsr	x0, x0, x5
    d6a0:	d2800001 	mov	x1, #0x0                   	// #0
    d6a4:	b4000064 	cbz	x4, d6b0 <__modti3+0xc0>
    d6a8:	eb0003e0 	negs	x0, x0
    d6ac:	da0103e1 	ngc	x1, x1
    d6b0:	d65f03c0 	ret
    d6b4:	dac01066 	clz	x6, x3
    d6b8:	eb03003f 	cmp	x1, x3
    d6bc:	54ffff43 	b.cc	d6a4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d6c0:	93407cc5 	sxtw	x5, w6
    d6c4:	d2800808 	mov	x8, #0x40                  	// #64
    d6c8:	cb050108 	sub	x8, x8, x5
    d6cc:	9ac62063 	lsl	x3, x3, x6
    d6d0:	9ac62025 	lsl	x5, x1, x6
    d6d4:	9ac82447 	lsr	x7, x2, x8
    d6d8:	aa0300e7 	orr	x7, x7, x3
    d6dc:	9ac82423 	lsr	x3, x1, x8
    d6e0:	92407cec 	and	x12, x7, #0xffffffff
    d6e4:	d360fcea 	lsr	x10, x7, #32
    d6e8:	9ac82401 	lsr	x1, x0, x8
    d6ec:	aa050021 	orr	x1, x1, x5
    d6f0:	9ac62042 	lsl	x2, x2, x6
    d6f4:	9ac62000 	lsl	x0, x0, x6
    d6f8:	9aca086b 	udiv	x11, x3, x10
    d6fc:	9b0a8d63 	msub	x3, x11, x10, x3
    d700:	aa0b03e5 	mov	x5, x11
    d704:	9b0b7d89 	mul	x9, x12, x11
    d708:	93c18063 	extr	x3, x3, x1, #32
    d70c:	eb03013f 	cmp	x9, x3
    d710:	540000a9 	b.ls	d724 <__modti3+0x134>  // b.plast
    d714:	ab0300e3 	adds	x3, x7, x3
    d718:	d1000565 	sub	x5, x11, #0x1
    d71c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d720:	54001168 	b.hi	d94c <__modti3+0x35c>  // b.pmore
    d724:	cb090063 	sub	x3, x3, x9
    d728:	9aca086b 	udiv	x11, x3, x10
    d72c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d730:	aa0b03e9 	mov	x9, x11
    d734:	9b0b7d8c 	mul	x12, x12, x11
    d738:	b3607d41 	bfi	x1, x10, #32, #32
    d73c:	eb01019f 	cmp	x12, x1
    d740:	540000a9 	b.ls	d754 <__modti3+0x164>  // b.plast
    d744:	ab0100e1 	adds	x1, x7, x1
    d748:	d1000569 	sub	x9, x11, #0x1
    d74c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d750:	54000f88 	b.hi	d940 <__modti3+0x350>  // b.pmore
    d754:	aa058123 	orr	x3, x9, x5, lsl #32
    d758:	92407c4b 	and	x11, x2, #0xffffffff
    d75c:	2a0903e9 	mov	w9, w9
    d760:	d360fc4a 	lsr	x10, x2, #32
    d764:	d360fc63 	lsr	x3, x3, #32
    d768:	cb0c0021 	sub	x1, x1, x12
    d76c:	aa0a03ec 	mov	x12, x10
    d770:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d774:	9b0b7d25 	mul	x5, x9, x11
    d778:	9b0b7c6b 	mul	x11, x3, x11
    d77c:	9b0a2d29 	madd	x9, x9, x10, x11
    d780:	92407caa 	and	x10, x5, #0xffffffff
    d784:	9b0c7c63 	mul	x3, x3, x12
    d788:	8b458125 	add	x5, x9, x5, lsr #32
    d78c:	8b0d0069 	add	x9, x3, x13
    d790:	eb05017f 	cmp	x11, x5
    d794:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d798:	8b058149 	add	x9, x10, x5, lsl #32
    d79c:	8b458063 	add	x3, x3, x5, lsr #32
    d7a0:	eb03003f 	cmp	x1, x3
    d7a4:	54000063 	b.cc	d7b0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d7a8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d7ac:	54000082 	b.cs	d7bc <__modti3+0x1cc>  // b.hs, b.nlast
    d7b0:	eb020129 	subs	x9, x9, x2
    d7b4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d7b8:	cb070063 	sub	x3, x3, x7
    d7bc:	eb090000 	subs	x0, x0, x9
    d7c0:	da030021 	sbc	x1, x1, x3
    d7c4:	9ac62400 	lsr	x0, x0, x6
    d7c8:	9ac82028 	lsl	x8, x1, x8
    d7cc:	aa000100 	orr	x0, x8, x0
    d7d0:	9ac62421 	lsr	x1, x1, x6
    d7d4:	17ffffb4 	b	d6a4 <__modti3+0xb4>
    d7d8:	b5000062 	cbnz	x2, d7e4 <__modti3+0x1f4>
    d7dc:	d2800023 	mov	x3, #0x1                   	// #1
    d7e0:	9ac20862 	udiv	x2, x3, x2
    d7e4:	dac01048 	clz	x8, x2
    d7e8:	aa0803e5 	mov	x5, x8
    d7ec:	b5000668 	cbnz	x8, d8b8 <__modti3+0x2c8>
    d7f0:	cb020020 	sub	x0, x1, x2
    d7f4:	d360fc49 	lsr	x9, x2, #32
    d7f8:	92407c4a 	and	x10, x2, #0xffffffff
    d7fc:	9ac90801 	udiv	x1, x0, x9
    d800:	9b098020 	msub	x0, x1, x9, x0
    d804:	9b0a7c21 	mul	x1, x1, x10
    d808:	93c78000 	extr	x0, x0, x7, #32
    d80c:	eb00003f 	cmp	x1, x0
    d810:	540000a9 	b.ls	d824 <__modti3+0x234>  // b.plast
    d814:	ab000040 	adds	x0, x2, x0
    d818:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d81c:	8b020003 	add	x3, x0, x2
    d820:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d824:	cb010001 	sub	x1, x0, x1
    d828:	9ac90820 	udiv	x0, x1, x9
    d82c:	9b098403 	msub	x3, x0, x9, x1
    d830:	aa0703e1 	mov	x1, x7
    d834:	9b0a7c00 	mul	x0, x0, x10
    d838:	b3607c61 	bfi	x1, x3, #32, #32
    d83c:	eb01001f 	cmp	x0, x1
    d840:	540000a9 	b.ls	d854 <__modti3+0x264>  // b.plast
    d844:	ab010041 	adds	x1, x2, x1
    d848:	8b020022 	add	x2, x1, x2
    d84c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d850:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d854:	cb000020 	sub	x0, x1, x0
    d858:	17ffff91 	b	d69c <__modti3+0xac>
    d85c:	eb0203e5 	negs	x5, x2
    d860:	aa0003e7 	mov	x7, x0
    d864:	da0303e8 	ngc	x8, x3
    d868:	aa0503e2 	mov	x2, x5
    d86c:	aa0803e3 	mov	x3, x8
    d870:	aa0103e6 	mov	x6, x1
    d874:	b4ffed48 	cbz	x8, d61c <__modti3+0x2c>
    d878:	eb01011f 	cmp	x8, x1
    d87c:	54fff148 	b.hi	d6a4 <__modti3+0xb4>  // b.pmore
    d880:	dac01109 	clz	x9, x8
    d884:	2a0903e6 	mov	w6, w9
    d888:	b5fff1c9 	cbnz	x9, d6c0 <__modti3+0xd0>
    d88c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d890:	54000068 	b.hi	d89c <__modti3+0x2ac>  // b.pmore
    d894:	eb050007 	subs	x7, x0, x5
    d898:	da080021 	sbc	x1, x1, x8
    d89c:	aa0703e0 	mov	x0, x7
    d8a0:	17ffff81 	b	d6a4 <__modti3+0xb4>
    d8a4:	ab000040 	adds	x0, x2, x0
    d8a8:	8b020002 	add	x2, x0, x2
    d8ac:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d8b0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d8b4:	17ffff79 	b	d698 <__modti3+0xa8>
    d8b8:	9ac82042 	lsl	x2, x2, x8
    d8bc:	d2800803 	mov	x3, #0x40                  	// #64
    d8c0:	cb080063 	sub	x3, x3, x8
    d8c4:	d360fc49 	lsr	x9, x2, #32
    d8c8:	9ac82027 	lsl	x7, x1, x8
    d8cc:	92407c4a 	and	x10, x2, #0xffffffff
    d8d0:	9ac32426 	lsr	x6, x1, x3
    d8d4:	9ac32403 	lsr	x3, x0, x3
    d8d8:	aa070063 	orr	x3, x3, x7
    d8dc:	9ac908c1 	udiv	x1, x6, x9
    d8e0:	9ac82007 	lsl	x7, x0, x8
    d8e4:	9b099820 	msub	x0, x1, x9, x6
    d8e8:	9b017d41 	mul	x1, x10, x1
    d8ec:	93c38000 	extr	x0, x0, x3, #32
    d8f0:	eb00003f 	cmp	x1, x0
    d8f4:	540000a9 	b.ls	d908 <__modti3+0x318>  // b.plast
    d8f8:	ab000040 	adds	x0, x2, x0
    d8fc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d900:	8b020006 	add	x6, x0, x2
    d904:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d908:	cb010000 	sub	x0, x0, x1
    d90c:	9ac90801 	udiv	x1, x0, x9
    d910:	9b098026 	msub	x6, x1, x9, x0
    d914:	aa0303e0 	mov	x0, x3
    d918:	9b017d41 	mul	x1, x10, x1
    d91c:	b3607cc0 	bfi	x0, x6, #32, #32
    d920:	eb00003f 	cmp	x1, x0
    d924:	540000a9 	b.ls	d938 <__modti3+0x348>  // b.plast
    d928:	ab000040 	adds	x0, x2, x0
    d92c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d930:	8b020003 	add	x3, x0, x2
    d934:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d938:	cb010000 	sub	x0, x0, x1
    d93c:	17ffffb0 	b	d7fc <__modti3+0x20c>
    d940:	d1000969 	sub	x9, x11, #0x2
    d944:	8b070021 	add	x1, x1, x7
    d948:	17ffff83 	b	d754 <__modti3+0x164>
    d94c:	d1000965 	sub	x5, x11, #0x2
    d950:	8b070063 	add	x3, x3, x7
    d954:	17ffff74 	b	d724 <__modti3+0x134>
    d958:	d503201f 	nop
    d95c:	d503201f 	nop

000000000000d960 <atexit>:
    d960:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d964:	f0000082 	adrp	x2, 20000 <__data_start>
    d968:	d2800001 	mov	x1, #0x0                   	// #0
    d96c:	910003fd 	mov	x29, sp
    d970:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d974:	f9400442 	ldr	x2, [x2, #8]
    d978:	17ffd366 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d97c <_fini>:
    d97c:	d503201f 	nop
    d980:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d984:	910003fd 	mov	x29, sp
    d988:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d98c:	d65f03c0 	ret
