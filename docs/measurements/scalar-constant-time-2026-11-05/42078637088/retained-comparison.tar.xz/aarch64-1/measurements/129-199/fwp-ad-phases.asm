
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000045 	adrp	x5, d000 <_IO_stdin_used+0xe0>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	910760a5 	add	x5, x5, #0x1d8
    2b20:	f0000044 	adrp	x4, d000 <_IO_stdin_used+0xe0>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	91078084 	add	x4, x4, #0x1e0
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	9101c261 	add	x1, x19, #0x70
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xef20>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    2bb4:	9116e000 	add	x0, x0, #0x5b8
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000042 	adrp	x2, c000 <f0+0x23e0>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	910a0042 	add	x2, x2, #0x280
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c273 	add	x19, x19, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435a60 	ldr	w0, [x19, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    2cfc:	91172000 	add	x0, x0, #0x5c8
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    2d0c:	9119a000 	add	x0, x0, #0x668
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    2d24:	91190000 	add	x0, x0, #0x640
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    2d30:	91184000 	add	x0, x0, #0x610
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    2d3c:	9117a000 	add	x0, x0, #0x5e8
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	f0000041 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    2f34:	9133c021 	add	x1, x1, #0xcf0
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	b0000040 	adrp	x0, c000 <f0+0x23e0>
    30d0:	913ca000 	add	x0, x0, #0xf28
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    3198:	91334021 	add	x1, x1, #0xcd0
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	b0000040 	adrp	x0, c000 <f0+0x23e0>
    31d0:	913d0000 	add	x0, x0, #0xf40
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	b0000042 	adrp	x2, c000 <f0+0x23e0>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	b0000056 	adrp	x22, c000 <f0+0x23e0>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	d0000058 	adrp	x24, d000 <_IO_stdin_used+0xe0>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	913e2042 	add	x2, x2, #0xf88
    3260:	913f82d6 	add	x22, x22, #0xfe0
    3264:	9129c318 	add	x24, x24, #0xa70
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	b0000059 	adrp	x25, c000 <f0+0x23e0>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	913f6323 	add	x3, x25, #0xfd8
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	b0000040 	adrp	x0, c000 <f0+0x23e0>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	913fc000 	add	x0, x0, #0xff0
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    3344:	911742a1 	add	x1, x21, #0x5d0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3358:	912700a5 	add	x5, x5, #0x9c0
    335c:	911742a1 	add	x1, x21, #0x5d0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911742b7 	add	x23, x21, #0x5d0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911742b5 	add	x21, x21, #0x5d0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911742b5 	add	x21, x21, #0x5d0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    34e8:	9126e0a5 	add	x5, x5, #0x9b8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	b0000040 	adrp	x0, c000 <f0+0x23e0>
    35f0:	913ca000 	add	x0, x0, #0xf28
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	b0000041 	adrp	x1, c000 <f0+0x23e0>
    3830:	aa1303e0 	mov	x0, x19
    3834:	913fe021 	add	x1, x1, #0xff8
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91000021 	add	x1, x1, #0x0
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    3860:	91002021 	add	x1, x1, #0x8
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	d0000042 	adrp	x2, d000 <_IO_stdin_used+0xe0>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	91004042 	add	x2, x2, #0x10
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	b0000040 	adrp	x0, c000 <f0+0x23e0>
    39d0:	913ca000 	add	x0, x0, #0xf28
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    39f0:	91008000 	add	x0, x0, #0x20
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    3a88:	91010000 	add	x0, x0, #0x40
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    3a98:	91018000 	add	x0, x0, #0x60
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc34020 	ldr	q0, [x1, #3328]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	9101c2b5 	add	x21, x21, #0x70
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    3b98:	91022000 	add	x0, x0, #0x88
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	9101c062 	add	x2, x3, #0x70
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403863 	ldr	x3, [x3, #112]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    3c08:	9102e000 	add	x0, x0, #0xb8
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	d0000044 	adrp	x4, d000 <_IO_stdin_used+0xe0>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	91042084 	add	x4, x4, #0x108
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	d0000044 	adrp	x4, d000 <_IO_stdin_used+0xe0>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	91048084 	add	x4, x4, #0x120
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	d0000044 	adrp	x4, d000 <_IO_stdin_used+0xe0>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	91044084 	add	x4, x4, #0x110
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    4028:	91174042 	add	x2, x2, #0x5d0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	b0000041 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	9104a021 	add	x1, x1, #0x128
    4084:	9104c000 	add	x0, x0, #0x130
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	b0000042 	adrp	x2, d000 <_IO_stdin_used+0xe0>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	91054042 	add	x2, x2, #0x150
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    418c:	91134061 	add	x1, x3, #0x4d0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    419c:	91174262 	add	x2, x19, #0x5d0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	b0000042 	adrp	x2, d000 <_IO_stdin_used+0xe0>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    41cc:	91144021 	add	x1, x1, #0x510
    41d0:	3dc34443 	ldr	q3, [x2, #3344]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    41fc:	91134063 	add	x3, x3, #0x4d0
    4200:	9115c084 	add	x4, x4, #0x570
    4204:	91174266 	add	x6, x19, #0x5d0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	91174275 	add	x21, x19, #0x5d0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    42e8:	91080000 	add	x0, x0, #0x200
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	91174273 	add	x19, x19, #0x5d0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <fwp_wake_io>:
    4344:	900000e9 	adrp	x9, 20000 <__data_start>
    4348:	9101c122 	add	x2, x9, #0x70
    434c:	f9400001 	ldr	x1, [x0]
    4350:	5280000a 	mov	w10, #0x0                   	// #0
    4354:	f9403c46 	ldr	x6, [x2, #120]
    4358:	52800008 	mov	w8, #0x0                   	// #0
    435c:	4f000400 	movi	v0.4s, #0x0
    4360:	52800027 	mov	w7, #0x1                   	// #1
    4364:	aa0103e2 	mov	x2, x1
    4368:	b4000321 	cbz	x1, 43cc <fwp_wake_io+0x88>
    436c:	f9408c25 	ldr	x5, [x1, #280]
    4370:	39015c27 	strb	w7, [x1, #87]
    4374:	b4000165 	cbz	x5, 43a0 <fwp_wake_io+0x5c>
    4378:	a9520c24 	ldp	x4, x3, [x1, #288]
    437c:	b4000364 	cbz	x4, 43e8 <fwp_wake_io+0xa4>
    4380:	f9009483 	str	x3, [x4, #296]
    4384:	f9409423 	ldr	x3, [x1, #296]
    4388:	b4000043 	cbz	x3, 4390 <fwp_wake_io+0x4c>
    438c:	f9009064 	str	x4, [x3, #288]
    4390:	91080023 	add	x3, x1, #0x200
    4394:	f900943f 	str	xzr, [x1, #296]
    4398:	3c918060 	stur	q0, [x3, #-232]
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	f9402843 	ldr	x3, [x2, #80]
    43a4:	f2001c7f 	tst	x3, #0xff000000ff
    43a8:	54fffde1 	b.ne	4364 <fwp_wake_io+0x20>  // b.any
    43ac:	39015047 	strb	w7, [x2, #84]
    43b0:	f900805f 	str	xzr, [x2, #256]
    43b4:	b40001e6 	cbz	x6, 43f0 <fwp_wake_io+0xac>
    43b8:	f90080c2 	str	x2, [x6, #256]
    43bc:	aa0203e6 	mov	x6, x2
    43c0:	52800028 	mov	w8, #0x1                   	// #1
    43c4:	aa0103e2 	mov	x2, x1
    43c8:	b5fffd21 	cbnz	x1, 436c <fwp_wake_io+0x28>
    43cc:	3400006a 	cbz	w10, 43d8 <fwp_wake_io+0x94>
    43d0:	9101c120 	add	x0, x9, #0x70
    43d4:	f900400b 	str	x11, [x0, #128]
    43d8:	34000068 	cbz	w8, 43e4 <fwp_wake_io+0xa0>
    43dc:	9101c129 	add	x9, x9, #0x70
    43e0:	f9003d26 	str	x6, [x9, #120]
    43e4:	d65f03c0 	ret
    43e8:	f90000a3 	str	x3, [x5]
    43ec:	17ffffe7 	b	4388 <fwp_wake_io+0x44>
    43f0:	aa0203eb 	mov	x11, x2
    43f4:	5280002a 	mov	w10, #0x1                   	// #1
    43f8:	17fffff1 	b	43bc <fwp_wake_io+0x78>
    43fc:	d503201f 	nop

0000000000004400 <fwp_tape_buffers_release>:
    4400:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	f9401400 	ldr	x0, [x0, #40]
    4414:	b7f80760 	tbnz	x0, #63, 4500 <fwp_tape_buffers_release+0x100>
    4418:	f9401a61 	ldr	x1, [x19, #48]
    441c:	b7f80301 	tbnz	x1, #63, 447c <fwp_tape_buffers_release+0x7c>
    4420:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4424:	eb02001f 	cmp	x0, x2
    4428:	540002a8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    442c:	8b000400 	add	x0, x0, x0, lsl #1
    4430:	d2a00102 	mov	x2, #0x80000               	// #524288
    4434:	d37df000 	lsl	x0, x0, #3
    4438:	cb000042 	sub	x2, x2, x0
    443c:	eb420c3f 	cmp	x1, x2, lsr #3
    4440:	540001e8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4444:	8b010c14 	add	x20, x0, x1, lsl #3
    4448:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    444c:	91084000 	add	x0, x0, #0x210
    4450:	97fff994 	bl	2aa0 <getenv@plt>
    4454:	b4000240 	cbz	x0, 449c <fwp_tape_buffers_release+0x9c>
    4458:	39400001 	ldrb	w1, [x0]
    445c:	7100c03f 	cmp	w1, #0x30
    4460:	540001e1 	b.ne	449c <fwp_tape_buffers_release+0x9c>  // b.any
    4464:	39400400 	ldrb	w0, [x0, #1]
    4468:	350001a0 	cbnz	w0, 449c <fwp_tape_buffers_release+0x9c>
    446c:	aa1303e0 	mov	x0, x19
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4478:	17fffc22 	b	3500 <fwp_tape_buffers_dispose>
    447c:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    4480:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4484:	91084000 	add	x0, x0, #0x210
    4488:	97fff986 	bl	2aa0 <getenv@plt>
    448c:	b4ffff00 	cbz	x0, 446c <fwp_tape_buffers_release+0x6c>
    4490:	39400001 	ldrb	w1, [x0]
    4494:	7100c03f 	cmp	w1, #0x30
    4498:	54fffe60 	b.eq	4464 <fwp_tape_buffers_release+0x64>  // b.none
    449c:	d1000681 	sub	x1, x20, #0x1
    44a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44a4:	eb00003f 	cmp	x1, x0
    44a8:	54fffe28 	b.hi	446c <fwp_tape_buffers_release+0x6c>  // b.pmore
    44ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    44b0:	900000f6 	adrp	x22, 20000 <__data_start>
    44b4:	9101c2d6 	add	x22, x22, #0x70
    44b8:	910262d5 	add	x21, x22, #0x98
    44bc:	aa1503e0 	mov	x0, x21
    44c0:	97fffc10 	bl	3500 <fwp_tape_buffers_dispose>
    44c4:	ad400a61 	ldp	q1, q2, [x19]
    44c8:	f9006ad4 	str	x20, [x22, #208]
    44cc:	4f000400 	movi	v0.4s, #0x0
    44d0:	ad000aa1 	stp	q1, q2, [x21]
    44d4:	3dc00a61 	ldr	q1, [x19, #32]
    44d8:	3d800aa1 	str	q1, [x21, #32]
    44dc:	f9401a60 	ldr	x0, [x19, #48]
    44e0:	f9001aa0 	str	x0, [x21, #48]
    44e4:	f9001a7f 	str	xzr, [x19, #48]
    44e8:	ad000260 	stp	q0, q0, [x19]
    44ec:	3d800a60 	str	q0, [x19, #32]
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44fc:	d65f03c0 	ret
    4500:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    4504:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4508:	91084000 	add	x0, x0, #0x210
    450c:	97fff965 	bl	2aa0 <getenv@plt>
    4510:	b5fffa40 	cbnz	x0, 4458 <fwp_tape_buffers_release+0x58>
    4514:	17ffffd6 	b	446c <fwp_tape_buffers_release+0x6c>
    4518:	d503201f 	nop
    451c:	d503201f 	nop

0000000000004520 <fwp_poll_events>:
    4520:	d10103ff 	sub	sp, sp, #0x40
    4524:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4528:	f947f400 	ldr	x0, [x0, #4072]
    452c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4530:	910083fd 	add	x29, sp, #0x20
    4534:	a90353f3 	stp	x19, x20, [sp, #48]
    4538:	900000f4 	adrp	x20, 20000 <__data_start>
    453c:	f9400001 	ldr	x1, [x0]
    4540:	f9000fe1 	str	x1, [sp, #24]
    4544:	d2800001 	mov	x1, #0x0                   	// #0
    4548:	97fffd2e 	bl	3a00 <fwp_now_ns>
    454c:	9101c281 	add	x1, x20, #0x70
    4550:	f9406c33 	ldr	x19, [x1, #216]
    4554:	b4000e93 	cbz	x19, 4724 <fwp_poll_events+0x204>
    4558:	aa1303e1 	mov	x1, x19
    455c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4560:	14000005 	b	4574 <fwp_poll_events+0x54>
    4564:	f9408821 	ldr	x1, [x1, #272]
    4568:	eb03005f 	cmp	x2, x3
    456c:	9a83d042 	csel	x2, x2, x3, le
    4570:	b40000c1 	cbz	x1, 4588 <fwp_poll_events+0x68>
    4574:	f9403423 	ldr	x3, [x1, #104]
    4578:	b6ffff62 	tbz	x2, #63, 4564 <fwp_poll_events+0x44>
    457c:	f9408821 	ldr	x1, [x1, #272]
    4580:	aa0303e2 	mov	x2, x3
    4584:	b5ffff81 	cbnz	x1, 4574 <fwp_poll_events+0x54>
    4588:	b7f80ce2 	tbnz	x2, #63, 4724 <fwp_poll_events+0x204>
    458c:	cb000042 	sub	x2, x2, x0
    4590:	f100005f 	cmp	x2, #0x0
    4594:	540005cd 	b.le	464c <fwp_poll_events+0x12c>
    4598:	d2869b60 	mov	x0, #0x34db                	// #13531
    459c:	d2884801 	mov	x1, #0x4240                	// #16960
    45a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    45b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    45b4:	9b407c40 	smulh	x0, x2, x0
    45b8:	9352fc00 	asr	x0, x0, #18
    45bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    45c0:	9b018802 	msub	x2, x0, x1, x2
    45c4:	f100005f 	cmp	x2, #0x0
    45c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    45cc:	eb03001f 	cmp	x0, x3
    45d0:	54000a0c 	b.gt	4710 <fwp_poll_events+0x1f0>
    45d4:	340003c0 	cbz	w0, 464c <fwp_poll_events+0x12c>
    45d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    45dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    45e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    45e4:	9ba27c02 	umull	x2, w0, w2
    45e8:	d366fc43 	lsr	x3, x2, #38
    45ec:	aa0303e2 	mov	x2, x3
    45f0:	1b048063 	msub	w3, w3, w4, w0
    45f4:	9b217c63 	smull	x3, w3, w1
    45f8:	d2800001 	mov	x1, #0x0                   	// #0
    45fc:	910023e0 	add	x0, sp, #0x8
    4600:	a9008fe2 	stp	x2, x3, [sp, #8]
    4604:	97fff8f7 	bl	29e0 <nanosleep@plt>
    4608:	9101c280 	add	x0, x20, #0x70
    460c:	f9406c13 	ldr	x19, [x0, #216]
    4610:	97fffcfc 	bl	3a00 <fwp_now_ns>
    4614:	aa0003e6 	mov	x6, x0
    4618:	b50001f3 	cbnz	x19, 4654 <fwp_poll_events+0x134>
    461c:	d503201f 	nop
    4620:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4624:	f947f400 	ldr	x0, [x0, #4072]
    4628:	f9400fe2 	ldr	x2, [sp, #24]
    462c:	f9400001 	ldr	x1, [x0]
    4630:	eb010042 	subs	x2, x2, x1
    4634:	d2800001 	mov	x1, #0x0                   	// #0
    4638:	540008c1 	b.ne	4750 <fwp_poll_events+0x230>  // b.any
    463c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4640:	a94353f3 	ldp	x19, x20, [sp, #48]
    4644:	910103ff 	add	sp, sp, #0x40
    4648:	d65f03c0 	ret
    464c:	97fffced 	bl	3a00 <fwp_now_ns>
    4650:	aa0003e6 	mov	x6, x0
    4654:	4f000400 	movi	v0.4s, #0x0
    4658:	9101c288 	add	x8, x20, #0x70
    465c:	52800027 	mov	w7, #0x1                   	// #1
    4660:	f9403661 	ldr	x1, [x19, #104]
    4664:	aa1303e5 	mov	x5, x19
    4668:	f9408a73 	ldr	x19, [x19, #272]
    466c:	eb06003f 	cmp	x1, x6
    4670:	5400032c 	b.gt	46d4 <fwp_poll_events+0x1b4>
    4674:	394154a0 	ldrb	w0, [x5, #85]
    4678:	36000120 	tbz	w0, #0, 469c <fwp_poll_events+0x17c>
    467c:	f94084a0 	ldr	x0, [x5, #264]
    4680:	b40003c0 	cbz	x0, 46f8 <fwp_poll_events+0x1d8>
    4684:	f9008813 	str	x19, [x0, #272]
    4688:	b4000053 	cbz	x19, 4690 <fwp_poll_events+0x170>
    468c:	f9008660 	str	x0, [x19, #264]
    4690:	910800a0 	add	x0, x5, #0x200
    4694:	390154bf 	strb	wzr, [x5, #85]
    4698:	3c908000 	stur	q0, [x0, #-248]
    469c:	f94030a0 	ldr	x0, [x5, #96]
    46a0:	390158a7 	strb	w7, [x5, #86]
    46a4:	f100001f 	cmp	x0, #0x0
    46a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46ac:	5400018d 	b.le	46dc <fwp_poll_events+0x1bc>
    46b0:	f94028a0 	ldr	x0, [x5, #80]
    46b4:	f2001c1f 	tst	x0, #0xff000000ff
    46b8:	540000e1 	b.ne	46d4 <fwp_poll_events+0x1b4>  // b.any
    46bc:	f9403d00 	ldr	x0, [x8, #120]
    46c0:	390150a7 	strb	w7, [x5, #84]
    46c4:	f90080bf 	str	xzr, [x5, #256]
    46c8:	b40001e0 	cbz	x0, 4704 <fwp_poll_events+0x1e4>
    46cc:	f9003d05 	str	x5, [x8, #120]
    46d0:	f9008005 	str	x5, [x0, #256]
    46d4:	b5fffc73 	cbnz	x19, 4660 <fwp_poll_events+0x140>
    46d8:	17ffffd2 	b	4620 <fwp_poll_events+0x100>
    46dc:	394144a0 	ldrb	w0, [x5, #81]
    46e0:	3707fe80 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46e4:	394140a0 	ldrb	w0, [x5, #80]
    46e8:	3707fe40 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46ec:	aa0503e0 	mov	x0, x5
    46f0:	97fffc20 	bl	3770 <fwp_cancel_tree.part.0>
    46f4:	17ffffef 	b	46b0 <fwp_poll_events+0x190>
    46f8:	9101c281 	add	x1, x20, #0x70
    46fc:	f9006c33 	str	x19, [x1, #216]
    4700:	17ffffe2 	b	4688 <fwp_poll_events+0x168>
    4704:	f9003d05 	str	x5, [x8, #120]
    4708:	f9004105 	str	x5, [x8, #128]
    470c:	17fffff2 	b	46d4 <fwp_poll_events+0x1b4>
    4710:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4714:	d2989362 	mov	x2, #0xc49b                	// #50331
    4718:	f2a4d203 	movk	x3, #0x2690, lsl #16
    471c:	f2a00402 	movk	x2, #0x20, lsl #16
    4720:	17ffffb6 	b	45f8 <fwp_poll_events+0xd8>
    4724:	97fffa53 	bl	3070 <fwp_flush>
    4728:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    472c:	f947e863 	ldr	x3, [x3, #4048]
    4730:	d2800562 	mov	x2, #0x2b                  	// #43
    4734:	d2800021 	mov	x1, #0x1                   	// #1
    4738:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    473c:	9108a000 	add	x0, x0, #0x228
    4740:	f9400063 	ldr	x3, [x3]
    4744:	97fff8b3 	bl	2a10 <fwrite@plt>
    4748:	52800ca0 	mov	w0, #0x65                  	// #101
    474c:	97fff81d 	bl	27c0 <exit@plt>
    4750:	97fff870 	bl	2910 <__stack_chk_fail@plt>

0000000000004754 <fwp_rc_wide_dup>:
    4754:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4758:	910003fd 	mov	x29, sp
    475c:	a90153f3 	stp	x19, x20, [sp, #16]
    4760:	aa0003f3 	mov	x19, x0
    4764:	ca404400 	eor	x0, x0, x0, lsr #17
    4768:	f90013f5 	str	x21, [sp, #32]
    476c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4770:	ca402400 	eor	x0, x0, x0, lsr #9
    4774:	911742a2 	add	x2, x21, #0x5d0
    4778:	92401c00 	and	x0, x0, #0xff
    477c:	910a2403 	add	x3, x0, #0x289
    4780:	8b000c40 	add	x0, x2, x0, lsl #3
    4784:	8b030c54 	add	x20, x2, x3, lsl #3
    4788:	f94a2401 	ldr	x1, [x0, #5192]
    478c:	b50000a1 	cbnz	x1, 47a0 <fwp_rc_wide_dup+0x4c>
    4790:	1400002d 	b	4844 <fwp_rc_wide_dup+0xf0>
    4794:	91004034 	add	x20, x1, #0x10
    4798:	f9400821 	ldr	x1, [x1, #16]
    479c:	b4000241 	cbz	x1, 47e4 <fwp_rc_wide_dup+0x90>
    47a0:	f9400022 	ldr	x2, [x1]
    47a4:	eb02027f 	cmp	x19, x2
    47a8:	54ffff61 	b.ne	4794 <fwp_rc_wide_dup+0x40>  // b.any
    47ac:	f9400281 	ldr	x1, [x20]
    47b0:	39400260 	ldrb	w0, [x19]
    47b4:	7103f81f 	cmp	w0, #0xfe
    47b8:	54000220 	b.eq	47fc <fwp_rc_wide_dup+0xa8>  // b.none
    47bc:	b40001a1 	cbz	x1, 47f0 <fwp_rc_wide_dup+0x9c>
    47c0:	f9400420 	ldr	x0, [x1, #8]
    47c4:	b100041f 	cmn	x0, #0x1
    47c8:	540004a0 	b.eq	485c <fwp_rc_wide_dup+0x108>  // b.none
    47cc:	91000400 	add	x0, x0, #0x1
    47d0:	f9000420 	str	x0, [x1, #8]
    47d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d8:	f94013f5 	ldr	x21, [sp, #32]
    47dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47e0:	d65f03c0 	ret
    47e4:	39400260 	ldrb	w0, [x19]
    47e8:	7103f81f 	cmp	w0, #0xfe
    47ec:	540000a0 	b.eq	4800 <fwp_rc_wide_dup+0xac>  // b.none
    47f0:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    47f4:	910a0000 	add	x0, x0, #0x280
    47f8:	97fffc22 	bl	3880 <fwp_trap>
    47fc:	b5000281 	cbnz	x1, 484c <fwp_rc_wide_dup+0xf8>
    4800:	d2800300 	mov	x0, #0x18                  	// #24
    4804:	97fff82b 	bl	28b0 <malloc@plt>
    4808:	b4000280 	cbz	x0, 4858 <fwp_rc_wide_dup+0x104>
    480c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4810:	a9000413 	stp	x19, x1, [x0]
    4814:	911742b5 	add	x21, x21, #0x5d0
    4818:	f900081f 	str	xzr, [x0, #16]
    481c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4820:	f9000280 	str	x0, [x20]
    4824:	39000261 	strb	w1, [x19]
    4828:	f94e26a0 	ldr	x0, [x21, #7240]
    482c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4830:	91000400 	add	x0, x0, #0x1
    4834:	f90e26a0 	str	x0, [x21, #7240]
    4838:	f94013f5 	ldr	x21, [sp, #32]
    483c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4840:	d65f03c0 	ret
    4844:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4848:	17ffffda 	b	47b0 <fwp_rc_wide_dup+0x5c>
    484c:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    4850:	91096000 	add	x0, x0, #0x258
    4854:	97fffc0b 	bl	3880 <fwp_trap>
    4858:	97fffa16 	bl	30b0 <fwp_heap_oom>
    485c:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    4860:	910aa000 	add	x0, x0, #0x2a8
    4864:	97fffc07 	bl	3880 <fwp_trap>
    4868:	d503201f 	nop
    486c:	d503201f 	nop

0000000000004870 <fwp_rc_forget_slot>:
    4870:	aa0003e1 	mov	x1, x0
    4874:	39400000 	ldrb	w0, [x0]
    4878:	7103fc1f 	cmp	w0, #0xff
    487c:	54000040 	b.eq	4884 <fwp_rc_forget_slot+0x14>  // b.none
    4880:	d65f03c0 	ret
    4884:	ca414420 	eor	x0, x1, x1, lsr #17
    4888:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    488c:	ca402400 	eor	x0, x0, x0, lsr #9
    4890:	910003fd 	mov	x29, sp
    4894:	92401c00 	and	x0, x0, #0xff
    4898:	f9000bf3 	str	x19, [sp, #16]
    489c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    48a0:	91174262 	add	x2, x19, #0x5d0
    48a4:	910a2403 	add	x3, x0, #0x289
    48a8:	8b000c40 	add	x0, x2, x0, lsl #3
    48ac:	8b030c43 	add	x3, x2, x3, lsl #3
    48b0:	f94a2400 	ldr	x0, [x0, #5192]
    48b4:	b50000a0 	cbnz	x0, 48c8 <fwp_rc_forget_slot+0x58>
    48b8:	14000011 	b	48fc <fwp_rc_forget_slot+0x8c>
    48bc:	91004003 	add	x3, x0, #0x10
    48c0:	f9400800 	ldr	x0, [x0, #16]
    48c4:	b40001c0 	cbz	x0, 48fc <fwp_rc_forget_slot+0x8c>
    48c8:	f9400002 	ldr	x2, [x0]
    48cc:	eb02003f 	cmp	x1, x2
    48d0:	54ffff61 	b.ne	48bc <fwp_rc_forget_slot+0x4c>  // b.any
    48d4:	f9400801 	ldr	x1, [x0, #16]
    48d8:	91174273 	add	x19, x19, #0x5d0
    48dc:	f9000061 	str	x1, [x3]
    48e0:	97fff83c 	bl	29d0 <free@plt>
    48e4:	f94e2660 	ldr	x0, [x19, #7240]
    48e8:	d1000400 	sub	x0, x0, #0x1
    48ec:	f90e2660 	str	x0, [x19, #7240]
    48f0:	f9400bf3 	ldr	x19, [sp, #16]
    48f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48f8:	d65f03c0 	ret
    48fc:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    4900:	910a0000 	add	x0, x0, #0x280
    4904:	97fffbdf 	bl	3880 <fwp_trap>
    4908:	d503201f 	nop
    490c:	d503201f 	nop

0000000000004910 <fwp_rc_prepare_chunk>:
    4910:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4914:	910003fd 	mov	x29, sp
    4918:	a9025bf5 	stp	x21, x22, [sp, #32]
    491c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4920:	911742c2 	add	x2, x22, #0x5d0
    4924:	b9401c03 	ldr	w3, [x0, #28]
    4928:	aa0103f5 	mov	x21, x1
    492c:	a90153f3 	stp	x19, x20, [sp, #16]
    4930:	aa0003f4 	mov	x20, x0
    4934:	f94e2440 	ldr	x0, [x2, #7240]
    4938:	b4000440 	cbz	x0, 49c0 <fwp_rc_prepare_chunk+0xb0>
    493c:	d2800013 	mov	x19, #0x0                   	// #0
    4940:	35000203 	cbnz	w3, 4980 <fwp_rc_prepare_chunk+0x70>
    4944:	b4000361 	cbz	x1, 49b0 <fwp_rc_prepare_chunk+0xa0>
    4948:	f9401280 	ldr	x0, [x20, #32]
    494c:	97fff821 	bl	29d0 <free@plt>
    4950:	aa1503e0 	mov	x0, x21
    4954:	d2800021 	mov	x1, #0x1                   	// #1
    4958:	97fff7e6 	bl	28f0 <calloc@plt>
    495c:	f9001280 	str	x0, [x20, #32]
    4960:	b5000460 	cbnz	x0, 49ec <fwp_rc_prepare_chunk+0xdc>
    4964:	97fff9d3 	bl	30b0 <fwp_heap_oom>
    4968:	97ffffc2 	bl	4870 <fwp_rc_forget_slot>
    496c:	91000673 	add	x19, x19, #0x1
    4970:	b9401e83 	ldr	w3, [x20, #28]
    4974:	eb13007f 	cmp	x3, x19
    4978:	54000169 	b.ls	49a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    497c:	d503201f 	nop
    4980:	f9401283 	ldr	x3, [x20, #32]
    4984:	8b130060 	add	x0, x3, x19
    4988:	38736863 	ldrb	w3, [x3, x19]
    498c:	7103fc7f 	cmp	w3, #0xff
    4990:	54fffec0 	b.eq	4968 <fwp_rc_prepare_chunk+0x58>  // b.none
    4994:	b9401e83 	ldr	w3, [x20, #28]
    4998:	91000673 	add	x19, x19, #0x1
    499c:	eb13007f 	cmp	x3, x19
    49a0:	54ffff08 	b.hi	4980 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49a4:	eb0302bf 	cmp	x21, x3
    49a8:	54000121 	b.ne	49cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    49ac:	b5000335 	cbnz	x21, 4a10 <fwp_rc_prepare_chunk+0x100>
    49b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    49b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49bc:	d65f03c0 	ret
    49c0:	2a0303e3 	mov	w3, w3
    49c4:	eb0302bf 	cmp	x21, x3
    49c8:	54ffff20 	b.eq	49ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    49cc:	911742c2 	add	x2, x22, #0x5d0
    49d0:	f9401280 	ldr	x0, [x20, #32]
    49d4:	f94e2841 	ldr	x1, [x2, #7248]
    49d8:	cb030021 	sub	x1, x1, x3
    49dc:	f90e2841 	str	x1, [x2, #7248]
    49e0:	97fff7fc 	bl	29d0 <free@plt>
    49e4:	b5fffb75 	cbnz	x21, 4950 <fwp_rc_prepare_chunk+0x40>
    49e8:	f900129f 	str	xzr, [x20, #32]
    49ec:	911742d6 	add	x22, x22, #0x5d0
    49f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    49f4:	b9001e95 	str	w21, [x20, #28]
    49f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49fc:	8b150000 	add	x0, x0, x21
    4a00:	f90e2ac0 	str	x0, [x22, #7248]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	f9401280 	ldr	x0, [x20, #32]
    4a14:	aa1503e2 	mov	x2, x21
    4a18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a1c:	52800001 	mov	w1, #0x0                   	// #0
    4a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a28:	17fff7ae 	b	28e0 <memset@plt>
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_heap_refill>:
    4a30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a40:	911742b5 	add	x21, x21, #0x5d0
    4a44:	aa0003f6 	mov	x22, x0
    4a48:	d2800020 	mov	x0, #0x1                   	// #1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	a90363f7 	stp	x23, x24, [sp, #48]
    4a54:	2a0103f7 	mov	w23, w1
    4a58:	2a0203f8 	mov	w24, w2
    4a5c:	97fffa35 	bl	3330 <fwp_heap_chunks>
    4a60:	aa0003f3 	mov	x19, x0
    4a64:	f949fea2 	ldr	x2, [x21, #5112]
    4a68:	8b000800 	add	x0, x0, x0, lsl #2
    4a6c:	2a1703e1 	mov	w1, w23
    4a70:	52800025 	mov	w5, #0x1                   	// #1
    4a74:	d37df000 	lsl	x0, x0, #3
    4a78:	910f0021 	add	x1, x1, #0x3c0
    4a7c:	8b000054 	add	x20, x2, x0
    4a80:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a84:	52a00024 	mov	w4, #0x10000               	// #65536
    4a88:	38206845 	strb	w5, [x2, x0]
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	39000698 	strb	w24, [x20, #1]
    4a94:	39000a97 	strb	w23, [x20, #2]
    4a98:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a9c:	b9000681 	str	w1, [x20, #4]
    4aa0:	2a0103e5 	mov	w5, w1
    4aa4:	8b0300a2 	add	x2, x5, x3
    4aa8:	1ac10881 	udiv	w1, w4, w1
    4aac:	9ac50842 	udiv	x2, x2, x5
    4ab0:	b9000a81 	str	w1, [x20, #8]
    4ab4:	92404021 	and	x1, x1, #0x1ffff
    4ab8:	b9001a82 	str	w2, [x20, #24]
    4abc:	97ffff95 	bl	4910 <fwp_rc_prepare_chunk>
    4ac0:	f949daa0 	ldr	x0, [x21, #5040]
    4ac4:	29408a81 	ldp	w1, w2, [x20, #4]
    4ac8:	8b134000 	add	x0, x0, x19, lsl #16
    4acc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad0:	8b214003 	add	x3, x0, w1, uxtw
    4ad4:	9ba20021 	umaddl	x1, w1, w2, x0
    4ad8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4adc:	a90086c3 	stp	x3, x1, [x22, #8]
    4ae0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ae8:	d65f03c0 	ret
    4aec:	d503201f 	nop

0000000000004af0 <fwp_mem_free>:
    4af0:	b40003c0 	cbz	x0, 4b68 <fwp_mem_free+0x78>
    4af4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4af8:	910003fd 	mov	x29, sp
    4afc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b00:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4b04:	911742a1 	add	x1, x21, #0x5d0
    4b08:	a90153f3 	stp	x19, x20, [sp, #16]
    4b0c:	aa0003f3 	mov	x19, x0
    4b10:	f949d823 	ldr	x3, [x1, #5040]
    4b14:	f949ec22 	ldr	x2, [x1, #5080]
    4b18:	cb030000 	sub	x0, x0, x3
    4b1c:	eb02401f 	cmp	x0, x2, lsl #16
    4b20:	540001c2 	b.cs	4b58 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b24:	d350fc16 	lsr	x22, x0, #16
    4b28:	a90363f7 	stp	x23, x24, [sp, #48]
    4b2c:	f949fc22 	ldr	x2, [x1, #5112]
    4b30:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b34:	d37df294 	lsl	x20, x20, #3
    4b38:	ab140057 	adds	x23, x2, x20
    4b3c:	540000c0 	b.eq	4b54 <fwp_mem_free+0x64>  // b.none
    4b40:	38746842 	ldrb	w2, [x2, x20]
    4b44:	7100045f 	cmp	w2, #0x1
    4b48:	54000120 	b.eq	4b6c <fwp_mem_free+0x7c>  // b.none
    4b4c:	7100085f 	cmp	w2, #0x2
    4b50:	540005e0 	b.eq	4c0c <fwp_mem_free+0x11c>  // b.none
    4b54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b60:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b64:	d65f03c0 	ret
    4b68:	d65f03c0 	ret
    4b6c:	f94012f8 	ldr	x24, [x23, #32]
    4b70:	b94006e1 	ldr	w1, [x23, #4]
    4b74:	f90023f9 	str	x25, [sp, #64]
    4b78:	2a0103e2 	mov	w2, w1
    4b7c:	394006f9 	ldrb	w25, [x23, #1]
    4b80:	39400af4 	ldrb	w20, [x23, #2]
    4b84:	b4000158 	cbz	x24, 4bac <fwp_mem_free+0xbc>
    4b88:	92403e76 	and	x22, x19, #0xffff
    4b8c:	9ac20ad6 	udiv	x22, x22, x2
    4b90:	38766b01 	ldrb	w1, [x24, x22]
    4b94:	8b160300 	add	x0, x24, x22
    4b98:	7103fc3f 	cmp	w1, #0xff
    4b9c:	54000980 	b.eq	4ccc <fwp_mem_free+0x1dc>  // b.none
    4ba0:	38366b1f 	strb	wzr, [x24, x22]
    4ba4:	b94006e1 	ldr	w1, [x23, #4]
    4ba8:	2a0103e2 	mov	w2, w1
    4bac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4bb0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4bb4:	cb390000 	sub	x0, x0, w25, uxtb
    4bb8:	8b340074 	add	x20, x3, w20, uxtb
    4bbc:	911742b5 	add	x21, x21, #0x5d0
    4bc0:	1e630021 	ucvtf	d1, w1
    4bc4:	d37ae400 	lsl	x0, x0, #6
    4bc8:	8b140c14 	add	x20, x0, x20, lsl #3
    4bcc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bd0:	f8746aa0 	ldr	x0, [x21, x20]
    4bd4:	f94023f9 	ldr	x25, [sp, #64]
    4bd8:	aa2003e0 	mvn	x0, x0
    4bdc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4be0:	f9000260 	str	x0, [x19]
    4be4:	f8346ab3 	str	x19, [x21, x20]
    4be8:	f94a12a0 	ldr	x0, [x21, #5152]
    4bec:	1e612800 	fadd	d0, d0, d1
    4bf0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf4:	cb020000 	sub	x0, x0, x2
    4bf8:	f90a12a0 	str	x0, [x21, #5152]
    4bfc:	fd0a22a0 	str	d0, [x21, #5184]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c08:	d65f03c0 	ret
    4c0c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c10:	8b000063 	add	x3, x3, x0
    4c14:	eb03027f 	cmp	x19, x3
    4c18:	54fff9e1 	b.ne	4b54 <fwp_mem_free+0x64>  // b.any
    4c1c:	fd400ae1 	ldr	d1, [x23, #16]
    4c20:	fd4a2020 	ldr	d0, [x1, #5184]
    4c24:	f9400ae0 	ldr	x0, [x23, #16]
    4c28:	7e61d821 	ucvtf	d1, d1
    4c2c:	f94a1022 	ldr	x2, [x1, #5152]
    4c30:	f94012f3 	ldr	x19, [x23, #32]
    4c34:	1e612800 	fadd	d0, d0, d1
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f90a1022 	str	x2, [x1, #5152]
    4c40:	fd0a2020 	str	d0, [x1, #5184]
    4c44:	b40000b3 	cbz	x19, 4c58 <fwp_mem_free+0x168>
    4c48:	39400260 	ldrb	w0, [x19]
    4c4c:	7103fc1f 	cmp	w0, #0xff
    4c50:	54000380 	b.eq	4cc0 <fwp_mem_free+0x1d0>  // b.none
    4c54:	3900027f 	strb	wzr, [x19]
    4c58:	b9400ee2 	ldr	w2, [x23, #12]
    4c5c:	b4000142 	cbz	x2, 4c84 <fwp_mem_free+0x194>
    4c60:	911742a1 	add	x1, x21, #0x5d0
    4c64:	8b160040 	add	x0, x2, x22
    4c68:	8b000800 	add	x0, x0, x0, lsl #2
    4c6c:	f949fc21 	ldr	x1, [x1, #5112]
    4c70:	8b140034 	add	x20, x1, x20
    4c74:	8b000c20 	add	x0, x1, x0, lsl #3
    4c78:	3802869f 	strb	wzr, [x20], #40
    4c7c:	eb00029f 	cmp	x20, x0
    4c80:	54ffffc1 	b.ne	4c78 <fwp_mem_free+0x188>  // b.any
    4c84:	911742a0 	add	x0, x21, #0x5d0
    4c88:	f94a1801 	ldr	x1, [x0, #5168]
    4c8c:	f949f803 	ldr	x3, [x0, #5104]
    4c90:	8b020021 	add	x1, x1, x2
    4c94:	f90a1801 	str	x1, [x0, #5168]
    4c98:	eb16007f 	cmp	x3, x22
    4c9c:	54000049 	b.ls	4ca4 <fwp_mem_free+0x1b4>  // b.plast
    4ca0:	f909f816 	str	x22, [x0, #5104]
    4ca4:	911742b5 	add	x21, x21, #0x5d0
    4ca8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cac:	eb16001f 	cmp	x0, x22
    4cb0:	54fff529 	b.ls	4b54 <fwp_mem_free+0x64>  // b.plast
    4cb4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cb8:	f909f6b6 	str	x22, [x21, #5096]
    4cbc:	17ffffa7 	b	4b58 <fwp_mem_free+0x68>
    4cc0:	aa1303e0 	mov	x0, x19
    4cc4:	97fffeeb 	bl	4870 <fwp_rc_forget_slot>
    4cc8:	17ffffe3 	b	4c54 <fwp_mem_free+0x164>
    4ccc:	97fffee9 	bl	4870 <fwp_rc_forget_slot>
    4cd0:	17ffffb4 	b	4ba0 <fwp_mem_free+0xb0>

0000000000004cd4 <fwp_heap_alloc_big>:
    4cd4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd8:	910003fd 	mov	x29, sp
    4cdc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ce0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce4:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce8:	aa0003f7 	mov	x23, x0
    4cec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cf0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf4:	eb0002ff 	cmp	x23, x0
    4cf8:	54000888 	b.hi	4e08 <fwp_heap_alloc_big+0x134>  // b.pmore
    4cfc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d00:	8b0002f4 	add	x20, x23, x0
    4d04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4d08:	91174359 	add	x25, x26, #0x5d0
    4d0c:	d350fe94 	lsr	x20, x20, #16
    4d10:	2a0103f5 	mov	w21, w1
    4d14:	aa1403e0 	mov	x0, x20
    4d18:	97fff986 	bl	3330 <fwp_heap_chunks>
    4d1c:	f949ff22 	ldr	x2, [x25, #5112]
    4d20:	8b000813 	add	x19, x0, x0, lsl #2
    4d24:	aa0003f8 	mov	x24, x0
    4d28:	52800043 	mov	w3, #0x2                   	// #2
    4d2c:	d37df273 	lsl	x19, x19, #3
    4d30:	d2800021 	mov	x1, #0x1                   	// #1
    4d34:	8b130040 	add	x0, x2, x19
    4d38:	38336843 	strb	w3, [x2, x19]
    4d3c:	39000415 	strb	w21, [x0, #1]
    4d40:	b9000c14 	str	w20, [x0, #12]
    4d44:	f9000817 	str	x23, [x0, #16]
    4d48:	97fffef2 	bl	4910 <fwp_rc_prepare_chunk>
    4d4c:	f100069f 	cmp	x20, #0x1
    4d50:	54000269 	b.ls	4d9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4d54:	8b180294 	add	x20, x20, x24
    4d58:	9100a273 	add	x19, x19, #0x28
    4d5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4d60:	5280007b 	mov	w27, #0x3                   	// #3
    4d64:	8b140a94 	add	x20, x20, x20, lsl #2
    4d68:	2a1803fc 	mov	w28, w24
    4d6c:	9adb2296 	lsl	x22, x20, x27
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffee4 	bl	4910 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0x9c>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91174353 	add	x19, x26, #0x5d0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x104>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117435a 	add	x26, x26, #0x5d0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4e20:	91174262 	add	x2, x19, #0x5d0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91174262 	add	x2, x19, #0x5d0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91174260 	add	x0, x19, #0x5d0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91174273 	add	x19, x19, #0x5d0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffca4 	bl	4184 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff70 	b	4cd4 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91174260 	add	x0, x19, #0x5d0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffeb5 	bl	4a30 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f84:	91174293 	add	x19, x20, #0x5d0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91174294 	add	x20, x20, #0x5d0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5094:	91174283 	add	x3, x20, #0x5d0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91174282 	add	x2, x20, #0x5d0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91174294 	add	x20, x20, #0x5d0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_p_ad_push>:
    51a4:	f100001f 	cmp	x0, #0x0
    51a8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51ac:	54000e8b 	b.lt	537c <fwp_p_ad_push+0x1d8>  // b.tstop
    51b0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    51b4:	aa0003e4 	mov	x4, x0
    51b8:	910003fd 	mov	x29, sp
    51bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51c0:	aa0003f5 	mov	x21, x0
    51c4:	aa020000 	orr	x0, x0, x2
    51c8:	a90363f7 	stp	x23, x24, [sp, #48]
    51cc:	aa0203f7 	mov	x23, x2
    51d0:	6d0627e8 	stp	d8, d9, [sp, #96]
    51d4:	9e670029 	fmov	d9, x1
    51d8:	9e670068 	fmov	d8, x3
    51dc:	b6f80900 	tbz	x0, #63, 52fc <fwp_p_ad_push+0x158>
    51e0:	a90153f3 	stp	x19, x20, [sp, #16]
    51e4:	9360fc80 	asr	x0, x4, #32
    51e8:	b6f800c4 	tbz	x4, #63, 5200 <fwp_p_ad_push+0x5c>
    51ec:	1e604109 	fmov	d9, d8
    51f0:	2f00e408 	movi	d8, #0x0
    51f4:	9360fc40 	asr	x0, x2, #32
    51f8:	aa0203f5 	mov	x21, x2
    51fc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5200:	97fffa6c 	bl	3bb0 <fwp_tape_of>
    5204:	aa0003f3 	mov	x19, x0
    5208:	f9403000 	ldr	x0, [x0, #96]
    520c:	b5001280 	cbnz	x0, 545c <fwp_p_ad_push+0x2b8>
    5210:	f9400a76 	ldr	x22, [x19, #16]
    5214:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5218:	eb0002df 	cmp	x22, x0
    521c:	54000e2c 	b.gt	53e0 <fwp_p_ad_push+0x23c>
    5220:	eb3542df 	cmp	x22, w21, uxtw
    5224:	54000d4d 	b.le	53cc <fwp_p_ad_push+0x228>
    5228:	b7f80077 	tbnz	x23, #63, 5234 <fwp_p_ad_push+0x90>
    522c:	eb3742df 	cmp	x22, w23, uxtw
    5230:	54000ced 	b.le	53cc <fwp_p_ad_push+0x228>
    5234:	f9400678 	ldr	x24, [x19, #8]
    5238:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    523c:	cb1802d8 	sub	x24, x22, x24
    5240:	91000701 	add	x1, x24, #0x1
    5244:	eb00003f 	cmp	x1, x0
    5248:	54000cc8 	b.hi	53e0 <fwp_p_ad_push+0x23c>  // b.pmore
    524c:	a9418274 	ldp	x20, x0, [x19, #24]
    5250:	a90573fb 	stp	x27, x28, [sp, #80]
    5254:	eb14003f 	cmp	x1, x20
    5258:	5400068d 	b.le	5328 <fwp_p_ad_push+0x184>
    525c:	f100029f 	cmp	x20, #0x0
    5260:	d2800803 	mov	x3, #0x40                  	// #64
    5264:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5268:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    526c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5270:	eb14003f 	cmp	x1, x20
    5274:	5400008d 	b.le	5284 <fwp_p_ad_push+0xe0>
    5278:	eb02029f 	cmp	x20, x2
    527c:	5400052d 	b.le	5320 <fwp_p_ad_push+0x17c>
    5280:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5284:	d37df299 	lsl	x25, x20, #3
    5288:	aa1903e1 	mov	x1, x25
    528c:	97fff59d 	bl	2900 <realloc@plt>
    5290:	aa0003e1 	mov	x1, x0
    5294:	b4000b00 	cbz	x0, 53f4 <fwp_p_ad_push+0x250>
    5298:	f9400e62 	ldr	x2, [x19, #24]
    529c:	f9001261 	str	x1, [x19, #32]
    52a0:	f9401a60 	ldr	x0, [x19, #48]
    52a4:	d37cee9a 	lsl	x26, x20, #4
    52a8:	8b020821 	add	x1, x1, x2, lsl #2
    52ac:	f9001661 	str	x1, [x19, #40]
    52b0:	aa1a03e1 	mov	x1, x26
    52b4:	97fff593 	bl	2900 <realloc@plt>
    52b8:	aa0003e2 	mov	x2, x0
    52bc:	b40009c0 	cbz	x0, 53f4 <fwp_p_ad_push+0x250>
    52c0:	f9400e61 	ldr	x1, [x19, #24]
    52c4:	d37df31b 	lsl	x27, x24, #3
    52c8:	d37ef685 	lsl	x5, x20, #2
    52cc:	d37ef71c 	lsl	x28, x24, #2
    52d0:	8b190004 	add	x4, x0, x25
    52d4:	8b010c01 	add	x1, x0, x1, lsl #3
    52d8:	a9030660 	stp	x0, x1, [x19, #48]
    52dc:	b5000558 	cbnz	x24, 5384 <fwp_p_ad_push+0x1e0>
    52e0:	f9001e64 	str	x4, [x19, #56]
    52e4:	f9401260 	ldr	x0, [x19, #32]
    52e8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    52ec:	8b050001 	add	x1, x0, x5
    52f0:	f9000e74 	str	x20, [x19, #24]
    52f4:	f9001661 	str	x1, [x19, #40]
    52f8:	14000010 	b	5338 <fwp_p_ad_push+0x194>
    52fc:	9360fc40 	asr	x0, x2, #32
    5300:	a90153f3 	stp	x19, x20, [sp, #16]
    5304:	eb84801f 	cmp	x0, x4, asr #32
    5308:	54fff7c0 	b.eq	5200 <fwp_p_ad_push+0x5c>  // b.none
    530c:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    5310:	910b2000 	add	x0, x0, #0x2c8
    5314:	a9046bf9 	stp	x25, x26, [sp, #64]
    5318:	a90573fb 	stp	x27, x28, [sp, #80]
    531c:	97fff959 	bl	3880 <fwp_trap>
    5320:	d37ffa94 	lsl	x20, x20, #1
    5324:	17ffffd3 	b	5270 <fwp_p_ad_push+0xcc>
    5328:	a9428a61 	ldp	x1, x2, [x19, #40]
    532c:	d37ef71c 	lsl	x28, x24, #2
    5330:	f9401e64 	ldr	x4, [x19, #56]
    5334:	d37df31b 	lsl	x27, x24, #3
    5338:	b83c6815 	str	w21, [x0, x28]
    533c:	f10002ff 	cmp	x23, #0x0
    5340:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5344:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5348:	fc3b6849 	str	d9, [x2, x27]
    534c:	aa1602a0 	orr	x0, x21, x22
    5350:	b83c6837 	str	w23, [x1, x28]
    5354:	910006d6 	add	x22, x22, #0x1
    5358:	a94363f7 	ldp	x23, x24, [sp, #48]
    535c:	fc3b6888 	str	d8, [x4, x27]
    5360:	a94573fb 	ldp	x27, x28, [sp, #80]
    5364:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5368:	f9000a76 	str	x22, [x19, #16]
    536c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5370:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5374:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5378:	d65f03c0 	ret
    537c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5380:	d65f03c0 	ret
    5384:	eb1a033f 	cmp	x25, x26
    5388:	aa0403e0 	mov	x0, x4
    538c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5390:	aa1b03e2 	mov	x2, x27
    5394:	cb190063 	sub	x3, x3, x25
    5398:	f9003fe5 	str	x5, [sp, #120]
    539c:	97fff5c5 	bl	2ab0 <__memmove_chk@plt>
    53a0:	a9420660 	ldp	x0, x1, [x19, #32]
    53a4:	aa1c03e2 	mov	x2, x28
    53a8:	f9401a63 	ldr	x3, [x19, #48]
    53ac:	f9403fe5 	ldr	x5, [sp, #120]
    53b0:	8b190063 	add	x3, x3, x25
    53b4:	f9001e63 	str	x3, [x19, #56]
    53b8:	8b050000 	add	x0, x0, x5
    53bc:	97fff4f1 	bl	2780 <memmove@plt>
    53c0:	a9431262 	ldp	x2, x4, [x19, #48]
    53c4:	f9403fe5 	ldr	x5, [sp, #120]
    53c8:	17ffffc7 	b	52e4 <fwp_p_ad_push+0x140>
    53cc:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    53d0:	910d8000 	add	x0, x0, #0x360
    53d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    53d8:	a90573fb 	stp	x27, x28, [sp, #80]
    53dc:	97fff929 	bl	3880 <fwp_trap>
    53e0:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    53e4:	910d0000 	add	x0, x0, #0x340
    53e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    53ec:	a90573fb 	stp	x27, x28, [sp, #80]
    53f0:	97fff924 	bl	3880 <fwp_trap>
    53f4:	aa1303e0 	mov	x0, x19
    53f8:	97fff706 	bl	3010 <fwp_tape_unlink_scope>
    53fc:	f9401260 	ldr	x0, [x19, #32]
    5400:	97fff574 	bl	29d0 <free@plt>
    5404:	f9401a60 	ldr	x0, [x19, #48]
    5408:	97fff572 	bl	29d0 <free@plt>
    540c:	f9402260 	ldr	x0, [x19, #64]
    5410:	97fff570 	bl	29d0 <free@plt>
    5414:	f9000e7f 	str	xzr, [x19, #24]
    5418:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    541c:	f947e821 	ldr	x1, [x1, #4048]
    5420:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5424:	d2800262 	mov	x2, #0x13                  	// #19
    5428:	4f000400 	movi	v0.4s, #0x0
    542c:	f0000020 	adrp	x0, c000 <f0+0x23e0>
    5430:	f9400023 	ldr	x3, [x1]
    5434:	b900067f 	str	wzr, [x19, #4]
    5438:	d2800021 	mov	x1, #0x1                   	// #1
    543c:	913ca000 	add	x0, x0, #0xf28
    5440:	3c808260 	stur	q0, [x19, #8]
    5444:	ad010260 	stp	q0, q0, [x19, #32]
    5448:	97fff572 	bl	2a10 <fwrite@plt>
    544c:	d2800000 	mov	x0, #0x0                   	// #0
    5450:	97fff57c 	bl	2a40 <fflush@plt>
    5454:	52800cc0 	mov	w0, #0x66                  	// #102
    5458:	97fff58a 	bl	2a80 <_Exit@plt>
    545c:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    5460:	910c4000 	add	x0, x0, #0x310
    5464:	a9046bf9 	stp	x25, x26, [sp, #64]
    5468:	a90573fb 	stp	x27, x28, [sp, #80]
    546c:	97fff905 	bl	3880 <fwp_trap>

0000000000005470 <w120>:
    5470:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5474:	9e660003 	fmov	x3, d0
    5478:	aa0003e2 	mov	x2, x0
    547c:	910003fd 	mov	x29, sp
    5480:	6d0327e8 	stp	d8, d9, [sp, #48]
    5484:	1e604028 	fmov	d8, d1
    5488:	1e600809 	fmul	d9, d0, d0
    548c:	fd0023ea 	str	d10, [sp, #64]
    5490:	1e60400a 	fmov	d10, d0
    5494:	a90153f3 	stp	x19, x20, [sp, #16]
    5498:	aa0003f3 	mov	x19, x0
    549c:	aa0103f4 	mov	x20, x1
    54a0:	aa0303e1 	mov	x1, x3
    54a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54a8:	97ffff3f 	bl	51a4 <fwp_p_ad_push>
    54ac:	1e693908 	fsub	d8, d8, d9
    54b0:	aa1403e2 	mov	x2, x20
    54b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54b8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54bc:	9e660116 	fmov	x22, d8
    54c0:	97ffff39 	bl	51a4 <fwp_p_ad_push>
    54c4:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    54c8:	aa0003e1 	mov	x1, x0
    54cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54d0:	aa1303e0 	mov	x0, x19
    54d4:	1e6a3929 	fsub	d9, d9, d10
    54d8:	aa0103f3 	mov	x19, x1
    54dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    54e0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54e4:	9e660135 	fmov	x21, d9
    54e8:	97ffff2f 	bl	51a4 <fwp_p_ad_push>
    54ec:	1e680908 	fmul	d8, d8, d8
    54f0:	aa0003f4 	mov	x20, x0
    54f4:	aa1603e3 	mov	x3, x22
    54f8:	aa1603e1 	mov	x1, x22
    54fc:	aa1303e2 	mov	x2, x19
    5500:	aa1303e0 	mov	x0, x19
    5504:	97ffff28 	bl	51a4 <fwp_p_ad_push>
    5508:	aa0003e2 	mov	x2, x0
    550c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5510:	9e670020 	fmov	d0, x1
    5514:	9e660101 	fmov	x1, d8
    5518:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    551c:	1e600908 	fmul	d8, d8, d0
    5520:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5524:	97ffff20 	bl	51a4 <fwp_p_ad_push>
    5528:	1e690929 	fmul	d9, d9, d9
    552c:	aa0003f3 	mov	x19, x0
    5530:	aa1503e3 	mov	x3, x21
    5534:	aa1503e1 	mov	x1, x21
    5538:	aa1403e2 	mov	x2, x20
    553c:	aa1403e0 	mov	x0, x20
    5540:	97ffff19 	bl	51a4 <fwp_p_ad_push>
    5544:	1e692908 	fadd	d8, d8, d9
    5548:	aa1303e2 	mov	x2, x19
    554c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5550:	aa0303e1 	mov	x1, x3
    5554:	97ffff14 	bl	51a4 <fwp_p_ad_push>
    5558:	aa0003e1 	mov	x1, x0
    555c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5560:	9e660100 	fmov	x0, d8
    5564:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5568:	6d4327e8 	ldp	d8, d9, [sp, #48]
    556c:	fd4023ea 	ldr	d10, [sp, #64]
    5570:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5574:	d65f03c0 	ret
    5578:	d503201f 	nop
    557c:	d503201f 	nop

0000000000005580 <fwp_rc_share>:
    5580:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5584:	91174042 	add	x2, x2, #0x5d0
    5588:	f949d843 	ldr	x3, [x2, #5040]
    558c:	f949ec41 	ldr	x1, [x2, #5080]
    5590:	cb030000 	sub	x0, x0, x3
    5594:	eb01401f 	cmp	x0, x1, lsl #16
    5598:	540002c2 	b.cs	55f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    559c:	d350fc01 	lsr	x1, x0, #16
    55a0:	f949fc44 	ldr	x4, [x2, #5112]
    55a4:	8b010821 	add	x1, x1, x1, lsl #2
    55a8:	d37df021 	lsl	x1, x1, #3
    55ac:	8b010083 	add	x3, x4, x1
    55b0:	f9401062 	ldr	x2, [x3, #32]
    55b4:	b40001e2 	cbz	x2, 55f0 <fwp_rc_share+0x70>
    55b8:	38616881 	ldrb	w1, [x4, x1]
    55bc:	7100083f 	cmp	w1, #0x2
    55c0:	540001a0 	b.eq	55f4 <fwp_rc_share+0x74>  // b.none
    55c4:	7100043f 	cmp	w1, #0x1
    55c8:	54000141 	b.ne	55f0 <fwp_rc_share+0x70>  // b.any
    55cc:	29430464 	ldp	w4, w1, [x3, #24]
    55d0:	92403c00 	and	x0, x0, #0xffff
    55d4:	9b047c00 	mul	x0, x0, x4
    55d8:	d360fc00 	lsr	x0, x0, #32
    55dc:	eb01001f 	cmp	x0, x1
    55e0:	54000082 	b.cs	55f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    55e4:	8b000042 	add	x2, x2, x0
    55e8:	39400040 	ldrb	w0, [x2]
    55ec:	350000a0 	cbnz	w0, 5600 <fwp_rc_share+0x80>
    55f0:	d65f03c0 	ret
    55f4:	72003c1f 	tst	w0, #0xffff
    55f8:	54ffff80 	b.eq	55e8 <fwp_rc_share+0x68>  // b.none
    55fc:	d65f03c0 	ret
    5600:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5604:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    5608:	910e0000 	add	x0, x0, #0x380
    560c:	910003fd 	mov	x29, sp
    5610:	97fff89c 	bl	3880 <fwp_trap>

0000000000005614 <fwp_rc_fresh>:
    5614:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5618:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    561c:	91174063 	add	x3, x3, #0x5d0
    5620:	910003fd 	mov	x29, sp
    5624:	a90153f3 	stp	x19, x20, [sp, #16]
    5628:	aa0003f3 	mov	x19, x0
    562c:	f949d861 	ldr	x1, [x3, #5040]
    5630:	f949ec60 	ldr	x0, [x3, #5080]
    5634:	cb010261 	sub	x1, x19, x1
    5638:	eb00403f 	cmp	x1, x0, lsl #16
    563c:	54000322 	b.cs	56a0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5640:	d350fc22 	lsr	x2, x1, #16
    5644:	f949fc63 	ldr	x3, [x3, #5112]
    5648:	8b020842 	add	x2, x2, x2, lsl #2
    564c:	d37df042 	lsl	x2, x2, #3
    5650:	8b020060 	add	x0, x3, x2
    5654:	f9401014 	ldr	x20, [x0, #32]
    5658:	b4000254 	cbz	x20, 56a0 <fwp_rc_fresh+0x8c>
    565c:	38626862 	ldrb	w2, [x3, x2]
    5660:	7100085f 	cmp	w2, #0x2
    5664:	54000260 	b.eq	56b0 <fwp_rc_fresh+0x9c>  // b.none
    5668:	7100045f 	cmp	w2, #0x1
    566c:	540001a1 	b.ne	56a0 <fwp_rc_fresh+0x8c>  // b.any
    5670:	29430002 	ldp	w2, w0, [x0, #24]
    5674:	92403c21 	and	x1, x1, #0xffff
    5678:	9b027c21 	mul	x1, x1, x2
    567c:	d360fc21 	lsr	x1, x1, #32
    5680:	eb00003f 	cmp	x1, x0
    5684:	540000e2 	b.cs	56a0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5688:	8b010294 	add	x20, x20, x1
    568c:	39400280 	ldrb	w0, [x20]
    5690:	7103fc1f 	cmp	w0, #0xff
    5694:	540001a0 	b.eq	56c8 <fwp_rc_fresh+0xb4>  // b.none
    5698:	52800020 	mov	w0, #0x1                   	// #1
    569c:	39000280 	strb	w0, [x20]
    56a0:	aa1303e0 	mov	x0, x19
    56a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    56a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    56ac:	d65f03c0 	ret
    56b0:	72003c3f 	tst	w1, #0xffff
    56b4:	54fffec0 	b.eq	568c <fwp_rc_fresh+0x78>  // b.none
    56b8:	aa1303e0 	mov	x0, x19
    56bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    56c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    56c4:	d65f03c0 	ret
    56c8:	aa1403e0 	mov	x0, x20
    56cc:	97fffc69 	bl	4870 <fwp_rc_forget_slot>
    56d0:	17fffff2 	b	5698 <fwp_rc_fresh+0x84>

00000000000056d4 <fwp_rc_free_arr>:
    56d4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    56d8:	91174063 	add	x3, x3, #0x5d0
    56dc:	f949d861 	ldr	x1, [x3, #5040]
    56e0:	f949ec62 	ldr	x2, [x3, #5080]
    56e4:	cb010001 	sub	x1, x0, x1
    56e8:	eb02403f 	cmp	x1, x2, lsl #16
    56ec:	54000342 	b.cs	5754 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    56f0:	d350fc22 	lsr	x2, x1, #16
    56f4:	f949fc65 	ldr	x5, [x3, #5112]
    56f8:	8b020842 	add	x2, x2, x2, lsl #2
    56fc:	d37df042 	lsl	x2, x2, #3
    5700:	8b0200a4 	add	x4, x5, x2
    5704:	f9401083 	ldr	x3, [x4, #32]
    5708:	b4000263 	cbz	x3, 5754 <fwp_rc_free_arr+0x80>
    570c:	386268a2 	ldrb	w2, [x5, x2]
    5710:	7100085f 	cmp	w2, #0x2
    5714:	540001c0 	b.eq	574c <fwp_rc_free_arr+0x78>  // b.none
    5718:	7100045f 	cmp	w2, #0x1
    571c:	540001c1 	b.ne	5754 <fwp_rc_free_arr+0x80>  // b.any
    5720:	29430885 	ldp	w5, w2, [x4, #24]
    5724:	92403c21 	and	x1, x1, #0xffff
    5728:	9b057c21 	mul	x1, x1, x5
    572c:	d360fc21 	lsr	x1, x1, #32
    5730:	eb02003f 	cmp	x1, x2
    5734:	54000102 	b.cs	5754 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5738:	8b010063 	add	x3, x3, x1
    573c:	39400061 	ldrb	w1, [x3]
    5740:	7100043f 	cmp	w1, #0x1
    5744:	54000081 	b.ne	5754 <fwp_rc_free_arr+0x80>  // b.any
    5748:	17fffcea 	b	4af0 <fwp_mem_free>
    574c:	72003c3f 	tst	w1, #0xffff
    5750:	54ffff60 	b.eq	573c <fwp_rc_free_arr+0x68>  // b.none
    5754:	d65f03c0 	ret
    5758:	d503201f 	nop
    575c:	d503201f 	nop

0000000000005760 <fwp_rc_dup>:
    5760:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5764:	91174042 	add	x2, x2, #0x5d0
    5768:	f949d841 	ldr	x1, [x2, #5040]
    576c:	f949ec43 	ldr	x3, [x2, #5080]
    5770:	cb010001 	sub	x1, x0, x1
    5774:	eb03403f 	cmp	x1, x3, lsl #16
    5778:	54000342 	b.cs	57e0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    577c:	d350fc20 	lsr	x0, x1, #16
    5780:	f949fc44 	ldr	x4, [x2, #5112]
    5784:	8b000800 	add	x0, x0, x0, lsl #2
    5788:	d37df002 	lsl	x2, x0, #3
    578c:	8b020083 	add	x3, x4, x2
    5790:	f9401060 	ldr	x0, [x3, #32]
    5794:	b4000260 	cbz	x0, 57e0 <fwp_rc_dup+0x80>
    5798:	38626882 	ldrb	w2, [x4, x2]
    579c:	7100085f 	cmp	w2, #0x2
    57a0:	54000220 	b.eq	57e4 <fwp_rc_dup+0x84>  // b.none
    57a4:	7100045f 	cmp	w2, #0x1
    57a8:	540001c1 	b.ne	57e0 <fwp_rc_dup+0x80>  // b.any
    57ac:	29430864 	ldp	w4, w2, [x3, #24]
    57b0:	92403c21 	and	x1, x1, #0xffff
    57b4:	9b047c21 	mul	x1, x1, x4
    57b8:	d360fc21 	lsr	x1, x1, #32
    57bc:	eb02003f 	cmp	x1, x2
    57c0:	54000102 	b.cs	57e0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    57c4:	8b010000 	add	x0, x0, x1
    57c8:	39400001 	ldrb	w1, [x0]
    57cc:	340000a1 	cbz	w1, 57e0 <fwp_rc_dup+0x80>
    57d0:	7103f43f 	cmp	w1, #0xfd
    57d4:	540000e8 	b.hi	57f0 <fwp_rc_dup+0x90>  // b.pmore
    57d8:	11000421 	add	w1, w1, #0x1
    57dc:	39000001 	strb	w1, [x0]
    57e0:	d65f03c0 	ret
    57e4:	72003c3f 	tst	w1, #0xffff
    57e8:	54ffff00 	b.eq	57c8 <fwp_rc_dup+0x68>  // b.none
    57ec:	d65f03c0 	ret
    57f0:	17fffbd9 	b	4754 <fwp_rc_wide_dup>

00000000000057f4 <fwp_owned_entry173>:
    57f4:	d10103ff 	sub	sp, sp, #0x40
    57f8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    57fc:	f947f442 	ldr	x2, [x2, #4072]
    5800:	a9027bfd 	stp	x29, x30, [sp, #32]
    5804:	910083fd 	add	x29, sp, #0x20
    5808:	a90353f3 	stp	x19, x20, [sp, #48]
    580c:	f9400043 	ldr	x3, [x2]
    5810:	f9000fe3 	str	x3, [sp, #24]
    5814:	d2800003 	mov	x3, #0x0                   	// #0
    5818:	a9400c01 	ldp	x1, x3, [x0]
    581c:	f9400802 	ldr	x2, [x0, #16]
    5820:	ab020022 	adds	x2, x1, x2
    5824:	540006e6 	b.vs	5900 <fwp_owned_entry173+0x10c>
    5828:	910023e1 	add	x1, sp, #0x8
    582c:	52800000 	mov	w0, #0x0                   	// #0
    5830:	a9008be3 	stp	x3, x2, [sp, #8]
    5834:	97fffe14 	bl	5084 <fwp_data.part.0.constprop.0>
    5838:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    583c:	91174063 	add	x3, x3, #0x5d0
    5840:	aa0003f3 	mov	x19, x0
    5844:	f949d861 	ldr	x1, [x3, #5040]
    5848:	f949ec60 	ldr	x0, [x3, #5080]
    584c:	cb010261 	sub	x1, x19, x1
    5850:	eb00403f 	cmp	x1, x0, lsl #16
    5854:	54000322 	b.cs	58b8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5858:	d350fc22 	lsr	x2, x1, #16
    585c:	f949fc63 	ldr	x3, [x3, #5112]
    5860:	8b020842 	add	x2, x2, x2, lsl #2
    5864:	d37df042 	lsl	x2, x2, #3
    5868:	8b020060 	add	x0, x3, x2
    586c:	f9401014 	ldr	x20, [x0, #32]
    5870:	b4000254 	cbz	x20, 58b8 <fwp_owned_entry173+0xc4>
    5874:	38626862 	ldrb	w2, [x3, x2]
    5878:	7100085f 	cmp	w2, #0x2
    587c:	54000360 	b.eq	58e8 <fwp_owned_entry173+0xf4>  // b.none
    5880:	7100045f 	cmp	w2, #0x1
    5884:	540001a1 	b.ne	58b8 <fwp_owned_entry173+0xc4>  // b.any
    5888:	29430002 	ldp	w2, w0, [x0, #24]
    588c:	92403c21 	and	x1, x1, #0xffff
    5890:	9b027c21 	mul	x1, x1, x2
    5894:	d360fc21 	lsr	x1, x1, #32
    5898:	eb00003f 	cmp	x1, x0
    589c:	540000e2 	b.cs	58b8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    58a0:	8b010294 	add	x20, x20, x1
    58a4:	39400280 	ldrb	w0, [x20]
    58a8:	7103fc1f 	cmp	w0, #0xff
    58ac:	54000240 	b.eq	58f4 <fwp_owned_entry173+0x100>  // b.none
    58b0:	52800020 	mov	w0, #0x1                   	// #1
    58b4:	39000280 	strb	w0, [x20]
    58b8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    58bc:	f947f400 	ldr	x0, [x0, #4072]
    58c0:	f9400fe2 	ldr	x2, [sp, #24]
    58c4:	f9400001 	ldr	x1, [x0]
    58c8:	eb010042 	subs	x2, x2, x1
    58cc:	d2800001 	mov	x1, #0x0                   	// #0
    58d0:	540001a1 	b.ne	5904 <fwp_owned_entry173+0x110>  // b.any
    58d4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    58d8:	aa1303e0 	mov	x0, x19
    58dc:	a94353f3 	ldp	x19, x20, [sp, #48]
    58e0:	910103ff 	add	sp, sp, #0x40
    58e4:	d65f03c0 	ret
    58e8:	72003c3f 	tst	w1, #0xffff
    58ec:	54fffe61 	b.ne	58b8 <fwp_owned_entry173+0xc4>  // b.any
    58f0:	17ffffed 	b	58a4 <fwp_owned_entry173+0xb0>
    58f4:	aa1403e0 	mov	x0, x20
    58f8:	97fffbde 	bl	4870 <fwp_rc_forget_slot>
    58fc:	17ffffed 	b	58b0 <fwp_owned_entry173+0xbc>
    5900:	97fff480 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5904:	97fff403 	bl	2910 <__stack_chk_fail@plt>
    5908:	d503201f 	nop
    590c:	d503201f 	nop

0000000000005910 <e173>:
    5910:	d10103ff 	sub	sp, sp, #0x40
    5914:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5918:	f947f442 	ldr	x2, [x2, #4072]
    591c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5920:	910083fd 	add	x29, sp, #0x20
    5924:	a90353f3 	stp	x19, x20, [sp, #48]
    5928:	f9400043 	ldr	x3, [x2]
    592c:	f9000fe3 	str	x3, [sp, #24]
    5930:	d2800003 	mov	x3, #0x0                   	// #0
    5934:	a9400c01 	ldp	x1, x3, [x0]
    5938:	f9400802 	ldr	x2, [x0, #16]
    593c:	ab020022 	adds	x2, x1, x2
    5940:	54000726 	b.vs	5a24 <e173+0x114>
    5944:	910023e1 	add	x1, sp, #0x8
    5948:	52800000 	mov	w0, #0x0                   	// #0
    594c:	a9008be3 	stp	x3, x2, [sp, #8]
    5950:	97fffdcd 	bl	5084 <fwp_data.part.0.constprop.0>
    5954:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5958:	91174063 	add	x3, x3, #0x5d0
    595c:	aa0003f3 	mov	x19, x0
    5960:	f949d861 	ldr	x1, [x3, #5040]
    5964:	f949ec60 	ldr	x0, [x3, #5080]
    5968:	cb010261 	sub	x1, x19, x1
    596c:	eb00403f 	cmp	x1, x0, lsl #16
    5970:	54000322 	b.cs	59d4 <e173+0xc4>  // b.hs, b.nlast
    5974:	d350fc22 	lsr	x2, x1, #16
    5978:	f949fc63 	ldr	x3, [x3, #5112]
    597c:	8b020842 	add	x2, x2, x2, lsl #2
    5980:	d37df042 	lsl	x2, x2, #3
    5984:	8b020060 	add	x0, x3, x2
    5988:	f9401014 	ldr	x20, [x0, #32]
    598c:	b4000254 	cbz	x20, 59d4 <e173+0xc4>
    5990:	38626862 	ldrb	w2, [x3, x2]
    5994:	7100085f 	cmp	w2, #0x2
    5998:	540003a0 	b.eq	5a0c <e173+0xfc>  // b.none
    599c:	7100045f 	cmp	w2, #0x1
    59a0:	540001a1 	b.ne	59d4 <e173+0xc4>  // b.any
    59a4:	29430002 	ldp	w2, w0, [x0, #24]
    59a8:	92403c21 	and	x1, x1, #0xffff
    59ac:	9b027c21 	mul	x1, x1, x2
    59b0:	d360fc21 	lsr	x1, x1, #32
    59b4:	eb00003f 	cmp	x1, x0
    59b8:	540000e2 	b.cs	59d4 <e173+0xc4>  // b.hs, b.nlast
    59bc:	8b010294 	add	x20, x20, x1
    59c0:	39400280 	ldrb	w0, [x20]
    59c4:	7103fc1f 	cmp	w0, #0xff
    59c8:	54000280 	b.eq	5a18 <e173+0x108>  // b.none
    59cc:	52800020 	mov	w0, #0x1                   	// #1
    59d0:	39000280 	strb	w0, [x20]
    59d4:	aa1303e0 	mov	x0, x19
    59d8:	97fffeea 	bl	5580 <fwp_rc_share>
    59dc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    59e0:	f947f400 	ldr	x0, [x0, #4072]
    59e4:	f9400fe2 	ldr	x2, [sp, #24]
    59e8:	f9400001 	ldr	x1, [x0]
    59ec:	eb010042 	subs	x2, x2, x1
    59f0:	d2800001 	mov	x1, #0x0                   	// #0
    59f4:	540001a1 	b.ne	5a28 <e173+0x118>  // b.any
    59f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    59fc:	aa1303e0 	mov	x0, x19
    5a00:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a04:	910103ff 	add	sp, sp, #0x40
    5a08:	d65f03c0 	ret
    5a0c:	72003c3f 	tst	w1, #0xffff
    5a10:	54fffe21 	b.ne	59d4 <e173+0xc4>  // b.any
    5a14:	17ffffeb 	b	59c0 <e173+0xb0>
    5a18:	aa1403e0 	mov	x0, x20
    5a1c:	97fffb95 	bl	4870 <fwp_rc_forget_slot>
    5a20:	17ffffeb 	b	59cc <e173+0xbc>
    5a24:	97fff437 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5a28:	97fff3ba 	bl	2910 <__stack_chk_fail@plt>
    5a2c:	d503201f 	nop

0000000000005a30 <fwp_drop1>:
    5a30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a34:	910003fd 	mov	x29, sp
    5a38:	a90153f3 	stp	x19, x20, [sp, #16]
    5a3c:	f90013f5 	str	x21, [sp, #32]
    5a40:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5a44:	911742b4 	add	x20, x21, #0x5d0
    5a48:	f949da81 	ldr	x1, [x20, #5040]
    5a4c:	f949ee82 	ldr	x2, [x20, #5080]
    5a50:	cb010001 	sub	x1, x0, x1
    5a54:	eb02403f 	cmp	x1, x2, lsl #16
    5a58:	54000382 	b.cs	5ac8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a5c:	d350fc22 	lsr	x2, x1, #16
    5a60:	f949fe84 	ldr	x4, [x20, #5112]
    5a64:	8b020842 	add	x2, x2, x2, lsl #2
    5a68:	d37df042 	lsl	x2, x2, #3
    5a6c:	8b020083 	add	x3, x4, x2
    5a70:	f9401073 	ldr	x19, [x3, #32]
    5a74:	b40002b3 	cbz	x19, 5ac8 <fwp_drop1+0x98>
    5a78:	38626882 	ldrb	w2, [x4, x2]
    5a7c:	7100085f 	cmp	w2, #0x2
    5a80:	540002c0 	b.eq	5ad8 <fwp_drop1+0xa8>  // b.none
    5a84:	7100045f 	cmp	w2, #0x1
    5a88:	54000201 	b.ne	5ac8 <fwp_drop1+0x98>  // b.any
    5a8c:	29430864 	ldp	w4, w2, [x3, #24]
    5a90:	92403c21 	and	x1, x1, #0xffff
    5a94:	9b047c21 	mul	x1, x1, x4
    5a98:	d360fc21 	lsr	x1, x1, #32
    5a9c:	eb02003f 	cmp	x1, x2
    5aa0:	54000142 	b.cs	5ac8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5aa4:	8b010273 	add	x19, x19, x1
    5aa8:	39400261 	ldrb	w1, [x19]
    5aac:	340000e1 	cbz	w1, 5ac8 <fwp_drop1+0x98>
    5ab0:	7100043f 	cmp	w1, #0x1
    5ab4:	540001e0 	b.eq	5af0 <fwp_drop1+0xc0>  // b.none
    5ab8:	7103fc3f 	cmp	w1, #0xff
    5abc:	540002e0 	b.eq	5b18 <fwp_drop1+0xe8>  // b.none
    5ac0:	51000421 	sub	w1, w1, #0x1
    5ac4:	39000261 	strb	w1, [x19]
    5ac8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5acc:	f94013f5 	ldr	x21, [sp, #32]
    5ad0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ad4:	d65f03c0 	ret
    5ad8:	72003c3f 	tst	w1, #0xffff
    5adc:	54fffe60 	b.eq	5aa8 <fwp_drop1+0x78>  // b.none
    5ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ae4:	f94013f5 	ldr	x21, [sp, #32]
    5ae8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5aec:	d65f03c0 	ret
    5af0:	f9400813 	ldr	x19, [x0, #16]
    5af4:	97fffef8 	bl	56d4 <fwp_rc_free_arr>
    5af8:	911742a0 	add	x0, x21, #0x5d0
    5afc:	f949d801 	ldr	x1, [x0, #5040]
    5b00:	f949ec00 	ldr	x0, [x0, #5080]
    5b04:	cb010261 	sub	x1, x19, x1
    5b08:	eb00403f 	cmp	x1, x0, lsl #16
    5b0c:	54fffde2 	b.cs	5ac8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b10:	aa1303e0 	mov	x0, x19
    5b14:	17ffffd2 	b	5a5c <fwp_drop1+0x2c>
    5b18:	ca534660 	eor	x0, x19, x19, lsr #17
    5b1c:	911742b5 	add	x21, x21, #0x5d0
    5b20:	ca402400 	eor	x0, x0, x0, lsr #9
    5b24:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5b28:	f94a2400 	ldr	x0, [x0, #5192]
    5b2c:	b5000080 	cbnz	x0, 5b3c <fwp_drop1+0x10c>
    5b30:	14000010 	b	5b70 <fwp_drop1+0x140>
    5b34:	f9400800 	ldr	x0, [x0, #16]
    5b38:	b40001c0 	cbz	x0, 5b70 <fwp_drop1+0x140>
    5b3c:	f9400001 	ldr	x1, [x0]
    5b40:	eb13003f 	cmp	x1, x19
    5b44:	54ffff81 	b.ne	5b34 <fwp_drop1+0x104>  // b.any
    5b48:	f9400401 	ldr	x1, [x0, #8]
    5b4c:	d1000421 	sub	x1, x1, #0x1
    5b50:	f9000401 	str	x1, [x0, #8]
    5b54:	f103f83f 	cmp	x1, #0xfe
    5b58:	54fffb81 	b.ne	5ac8 <fwp_drop1+0x98>  // b.any
    5b5c:	aa1303e0 	mov	x0, x19
    5b60:	97fffb44 	bl	4870 <fwp_rc_forget_slot>
    5b64:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b68:	39000260 	strb	w0, [x19]
    5b6c:	17ffffd7 	b	5ac8 <fwp_drop1+0x98>
    5b70:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    5b74:	910a0000 	add	x0, x0, #0x280
    5b78:	97fff742 	bl	3880 <fwp_trap>
    5b7c:	d503201f 	nop

0000000000005b80 <fwp_drop0>:
    5b80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b84:	910003fd 	mov	x29, sp
    5b88:	a90153f3 	stp	x19, x20, [sp, #16]
    5b8c:	f90013f5 	str	x21, [sp, #32]
    5b90:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5b94:	911742b4 	add	x20, x21, #0x5d0
    5b98:	f949da81 	ldr	x1, [x20, #5040]
    5b9c:	f949ee82 	ldr	x2, [x20, #5080]
    5ba0:	cb010001 	sub	x1, x0, x1
    5ba4:	eb02403f 	cmp	x1, x2, lsl #16
    5ba8:	54000382 	b.cs	5c18 <fwp_drop0+0x98>  // b.hs, b.nlast
    5bac:	d350fc22 	lsr	x2, x1, #16
    5bb0:	f949fe84 	ldr	x4, [x20, #5112]
    5bb4:	8b020842 	add	x2, x2, x2, lsl #2
    5bb8:	d37df042 	lsl	x2, x2, #3
    5bbc:	8b020083 	add	x3, x4, x2
    5bc0:	f9401073 	ldr	x19, [x3, #32]
    5bc4:	b40002b3 	cbz	x19, 5c18 <fwp_drop0+0x98>
    5bc8:	38626882 	ldrb	w2, [x4, x2]
    5bcc:	7100085f 	cmp	w2, #0x2
    5bd0:	540002c0 	b.eq	5c28 <fwp_drop0+0xa8>  // b.none
    5bd4:	7100045f 	cmp	w2, #0x1
    5bd8:	54000201 	b.ne	5c18 <fwp_drop0+0x98>  // b.any
    5bdc:	29430864 	ldp	w4, w2, [x3, #24]
    5be0:	92403c21 	and	x1, x1, #0xffff
    5be4:	9b047c21 	mul	x1, x1, x4
    5be8:	d360fc21 	lsr	x1, x1, #32
    5bec:	eb02003f 	cmp	x1, x2
    5bf0:	54000142 	b.cs	5c18 <fwp_drop0+0x98>  // b.hs, b.nlast
    5bf4:	8b010273 	add	x19, x19, x1
    5bf8:	39400261 	ldrb	w1, [x19]
    5bfc:	340000e1 	cbz	w1, 5c18 <fwp_drop0+0x98>
    5c00:	7100043f 	cmp	w1, #0x1
    5c04:	540001e0 	b.eq	5c40 <fwp_drop0+0xc0>  // b.none
    5c08:	7103fc3f 	cmp	w1, #0xff
    5c0c:	540002e0 	b.eq	5c68 <fwp_drop0+0xe8>  // b.none
    5c10:	51000421 	sub	w1, w1, #0x1
    5c14:	39000261 	strb	w1, [x19]
    5c18:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c1c:	f94013f5 	ldr	x21, [sp, #32]
    5c20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c24:	d65f03c0 	ret
    5c28:	72003c3f 	tst	w1, #0xffff
    5c2c:	54fffe60 	b.eq	5bf8 <fwp_drop0+0x78>  // b.none
    5c30:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c34:	f94013f5 	ldr	x21, [sp, #32]
    5c38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c3c:	d65f03c0 	ret
    5c40:	f9400813 	ldr	x19, [x0, #16]
    5c44:	97fffea4 	bl	56d4 <fwp_rc_free_arr>
    5c48:	911742a0 	add	x0, x21, #0x5d0
    5c4c:	f949d801 	ldr	x1, [x0, #5040]
    5c50:	f949ec00 	ldr	x0, [x0, #5080]
    5c54:	cb010261 	sub	x1, x19, x1
    5c58:	eb00403f 	cmp	x1, x0, lsl #16
    5c5c:	54fffde2 	b.cs	5c18 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c60:	aa1303e0 	mov	x0, x19
    5c64:	17ffffd2 	b	5bac <fwp_drop0+0x2c>
    5c68:	ca534660 	eor	x0, x19, x19, lsr #17
    5c6c:	911742b5 	add	x21, x21, #0x5d0
    5c70:	ca402400 	eor	x0, x0, x0, lsr #9
    5c74:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5c78:	f94a2400 	ldr	x0, [x0, #5192]
    5c7c:	b5000080 	cbnz	x0, 5c8c <fwp_drop0+0x10c>
    5c80:	14000010 	b	5cc0 <fwp_drop0+0x140>
    5c84:	f9400800 	ldr	x0, [x0, #16]
    5c88:	b40001c0 	cbz	x0, 5cc0 <fwp_drop0+0x140>
    5c8c:	f9400001 	ldr	x1, [x0]
    5c90:	eb13003f 	cmp	x1, x19
    5c94:	54ffff81 	b.ne	5c84 <fwp_drop0+0x104>  // b.any
    5c98:	f9400401 	ldr	x1, [x0, #8]
    5c9c:	d1000421 	sub	x1, x1, #0x1
    5ca0:	f9000401 	str	x1, [x0, #8]
    5ca4:	f103f83f 	cmp	x1, #0xfe
    5ca8:	54fffb81 	b.ne	5c18 <fwp_drop0+0x98>  // b.any
    5cac:	aa1303e0 	mov	x0, x19
    5cb0:	97fffaf0 	bl	4870 <fwp_rc_forget_slot>
    5cb4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5cb8:	39000260 	strb	w0, [x19]
    5cbc:	17ffffd7 	b	5c18 <fwp_drop0+0x98>
    5cc0:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    5cc4:	910a0000 	add	x0, x0, #0x280
    5cc8:	97fff6ee 	bl	3880 <fwp_trap>
    5ccc:	d503201f 	nop

0000000000005cd0 <fwp_closure_drop>:
    5cd0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5cd4:	911740a4 	add	x4, x5, #0x5d0
    5cd8:	aa0003e1 	mov	x1, x0
    5cdc:	f949d882 	ldr	x2, [x4, #5040]
    5ce0:	f949ec80 	ldr	x0, [x4, #5080]
    5ce4:	cb020022 	sub	x2, x1, x2
    5ce8:	eb00405f 	cmp	x2, x0, lsl #16
    5cec:	54000662 	b.cs	5db8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5cf0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5cf4:	d350fc43 	lsr	x3, x2, #16
    5cf8:	910003fd 	mov	x29, sp
    5cfc:	8b030863 	add	x3, x3, x3, lsl #2
    5d00:	f949fc84 	ldr	x4, [x4, #5112]
    5d04:	d37df063 	lsl	x3, x3, #3
    5d08:	f9000bf3 	str	x19, [sp, #16]
    5d0c:	8b030080 	add	x0, x4, x3
    5d10:	f9401013 	ldr	x19, [x0, #32]
    5d14:	b40002b3 	cbz	x19, 5d68 <fwp_closure_drop+0x98>
    5d18:	38636883 	ldrb	w3, [x4, x3]
    5d1c:	7100087f 	cmp	w3, #0x2
    5d20:	54000420 	b.eq	5da4 <fwp_closure_drop+0xd4>  // b.none
    5d24:	7100047f 	cmp	w3, #0x1
    5d28:	54000201 	b.ne	5d68 <fwp_closure_drop+0x98>  // b.any
    5d2c:	29430003 	ldp	w3, w0, [x0, #24]
    5d30:	92403c42 	and	x2, x2, #0xffff
    5d34:	9b037c42 	mul	x2, x2, x3
    5d38:	d360fc42 	lsr	x2, x2, #32
    5d3c:	eb00005f 	cmp	x2, x0
    5d40:	54000142 	b.cs	5d68 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5d44:	8b020273 	add	x19, x19, x2
    5d48:	39400260 	ldrb	w0, [x19]
    5d4c:	340000e0 	cbz	w0, 5d68 <fwp_closure_drop+0x98>
    5d50:	7100041f 	cmp	w0, #0x1
    5d54:	54000100 	b.eq	5d74 <fwp_closure_drop+0xa4>  // b.none
    5d58:	7103fc1f 	cmp	w0, #0xff
    5d5c:	54000300 	b.eq	5dbc <fwp_closure_drop+0xec>  // b.none
    5d60:	51000400 	sub	w0, w0, #0x1
    5d64:	39000260 	strb	w0, [x19]
    5d68:	f9400bf3 	ldr	x19, [sp, #16]
    5d6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d70:	d65f03c0 	ret
    5d74:	d53bd040 	mrs	x0, tpidr_el0
    5d78:	91400000 	add	x0, x0, #0x0, lsl #12
    5d7c:	91004000 	add	x0, x0, #0x10
    5d80:	f9400000 	ldr	x0, [x0]
    5d84:	b4000080 	cbz	x0, 5d94 <fwp_closure_drop+0xc4>
    5d88:	f9400bf3 	ldr	x19, [sp, #16]
    5d8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d90:	17fff6d5 	b	38e4 <fwp_closure_drop_push>
    5d94:	f9400bf3 	ldr	x19, [sp, #16]
    5d98:	aa0103e0 	mov	x0, x1
    5d9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5da0:	17fff740 	b	3aa0 <fwp_closure_drop.part.0>
    5da4:	72003c5f 	tst	w2, #0xffff
    5da8:	54fffd00 	b.eq	5d48 <fwp_closure_drop+0x78>  // b.none
    5dac:	f9400bf3 	ldr	x19, [sp, #16]
    5db0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5db4:	d65f03c0 	ret
    5db8:	d65f03c0 	ret
    5dbc:	ca534660 	eor	x0, x19, x19, lsr #17
    5dc0:	911740a5 	add	x5, x5, #0x5d0
    5dc4:	ca402400 	eor	x0, x0, x0, lsr #9
    5dc8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5dcc:	f94a2400 	ldr	x0, [x0, #5192]
    5dd0:	b5000080 	cbnz	x0, 5de0 <fwp_closure_drop+0x110>
    5dd4:	14000010 	b	5e14 <fwp_closure_drop+0x144>
    5dd8:	f9400800 	ldr	x0, [x0, #16]
    5ddc:	b40001c0 	cbz	x0, 5e14 <fwp_closure_drop+0x144>
    5de0:	f9400001 	ldr	x1, [x0]
    5de4:	eb13003f 	cmp	x1, x19
    5de8:	54ffff81 	b.ne	5dd8 <fwp_closure_drop+0x108>  // b.any
    5dec:	f9400401 	ldr	x1, [x0, #8]
    5df0:	d1000421 	sub	x1, x1, #0x1
    5df4:	f9000401 	str	x1, [x0, #8]
    5df8:	f103f83f 	cmp	x1, #0xfe
    5dfc:	54fffb61 	b.ne	5d68 <fwp_closure_drop+0x98>  // b.any
    5e00:	aa1303e0 	mov	x0, x19
    5e04:	97fffa9b 	bl	4870 <fwp_rc_forget_slot>
    5e08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e0c:	39000260 	strb	w0, [x19]
    5e10:	17ffffd6 	b	5d68 <fwp_closure_drop+0x98>
    5e14:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    5e18:	910a0000 	add	x0, x0, #0x280
    5e1c:	97fff699 	bl	3880 <fwp_trap>

0000000000005e20 <fwp_owned_tape_release>:
    5e20:	b4000940 	cbz	x0, 5f48 <fwp_owned_tape_release+0x128>
    5e24:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e28:	910003fd 	mov	x29, sp
    5e2c:	a90153f3 	stp	x19, x20, [sp, #16]
    5e30:	aa0003f3 	mov	x19, x0
    5e34:	f9400000 	ldr	x0, [x0]
    5e38:	b4000060 	cbz	x0, 5e44 <fwp_owned_tape_release+0x24>
    5e3c:	f9400661 	ldr	x1, [x19, #8]
    5e40:	f9000401 	str	x1, [x0, #8]
    5e44:	f9400661 	ldr	x1, [x19, #8]
    5e48:	b4000041 	cbz	x1, 5e50 <fwp_owned_tape_release+0x30>
    5e4c:	f9000020 	str	x0, [x1]
    5e50:	f9400a60 	ldr	x0, [x19, #16]
    5e54:	f9403401 	ldr	x1, [x0, #104]
    5e58:	b40005c1 	cbz	x1, 5f10 <fwp_owned_tape_release+0xf0>
    5e5c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5e60:	eb00005f 	cmp	x2, x0
    5e64:	540002ed 	b.le	5ec0 <fwp_owned_tape_release+0xa0>
    5e68:	d2800014 	mov	x20, #0x0                   	// #0
    5e6c:	f90013f5 	str	x21, [sp, #32]
    5e70:	d2800015 	mov	x21, #0x0                   	// #0
    5e74:	d503201f 	nop
    5e78:	f9402260 	ldr	x0, [x19, #64]
    5e7c:	910006b5 	add	x21, x21, #0x1
    5e80:	f8746800 	ldr	x0, [x0, x20]
    5e84:	d63f0020 	blr	x1
    5e88:	f9402260 	ldr	x0, [x19, #64]
    5e8c:	f9400a61 	ldr	x1, [x19, #16]
    5e90:	8b140000 	add	x0, x0, x20
    5e94:	91004294 	add	x20, x20, #0x10
    5e98:	f9400400 	ldr	x0, [x0, #8]
    5e9c:	f9403421 	ldr	x1, [x1, #104]
    5ea0:	d63f0020 	blr	x1
    5ea4:	a9450261 	ldp	x1, x0, [x19, #80]
    5ea8:	cb010000 	sub	x0, x0, x1
    5eac:	eb15001f 	cmp	x0, x21
    5eb0:	f9400a60 	ldr	x0, [x19, #16]
    5eb4:	f9403401 	ldr	x1, [x0, #104]
    5eb8:	54fffe0c 	b.gt	5e78 <fwp_owned_tape_release+0x58>
    5ebc:	f94013f5 	ldr	x21, [sp, #32]
    5ec0:	f9403663 	ldr	x3, [x19, #104]
    5ec4:	f9401262 	ldr	x2, [x19, #32]
    5ec8:	f100007f 	cmp	x3, #0x0
    5ecc:	540001ed 	b.le	5f08 <fwp_owned_tape_release+0xe8>
    5ed0:	d2800014 	mov	x20, #0x0                   	// #0
    5ed4:	d503201f 	nop
    5ed8:	f9402660 	ldr	x0, [x19, #72]
    5edc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5ee0:	eb02001f 	cmp	x0, x2
    5ee4:	540000c0 	b.eq	5efc <fwp_owned_tape_release+0xdc>  // b.none
    5ee8:	d63f0020 	blr	x1
    5eec:	f9400a60 	ldr	x0, [x19, #16]
    5ef0:	f9401262 	ldr	x2, [x19, #32]
    5ef4:	f9403663 	ldr	x3, [x19, #104]
    5ef8:	f9403401 	ldr	x1, [x0, #104]
    5efc:	91000694 	add	x20, x20, #0x1
    5f00:	eb14007f 	cmp	x3, x20
    5f04:	54fffeac 	b.gt	5ed8 <fwp_owned_tape_release+0xb8>
    5f08:	aa0203e0 	mov	x0, x2
    5f0c:	d63f0020 	blr	x1
    5f10:	f9401660 	ldr	x0, [x19, #40]
    5f14:	97ffff6f 	bl	5cd0 <fwp_closure_drop>
    5f18:	f9401a60 	ldr	x0, [x19, #48]
    5f1c:	97ffff6d 	bl	5cd0 <fwp_closure_drop>
    5f20:	f9401e60 	ldr	x0, [x19, #56]
    5f24:	97ffff6b 	bl	5cd0 <fwp_closure_drop>
    5f28:	f9402260 	ldr	x0, [x19, #64]
    5f2c:	97fffaf1 	bl	4af0 <fwp_mem_free>
    5f30:	f9402660 	ldr	x0, [x19, #72]
    5f34:	97fffaef 	bl	4af0 <fwp_mem_free>
    5f38:	aa1303e0 	mov	x0, x19
    5f3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f44:	17fffaeb 	b	4af0 <fwp_mem_free>
    5f48:	d65f03c0 	ret
    5f4c:	d503201f 	nop

0000000000005f50 <fwp_tape_finish>:
    5f50:	d10203ff 	sub	sp, sp, #0x80
    5f54:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5f58:	f947f421 	ldr	x1, [x1, #4072]
    5f5c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f60:	910103fd 	add	x29, sp, #0x40
    5f64:	a90553f3 	stp	x19, x20, [sp, #80]
    5f68:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f6c:	a90763f7 	stp	x23, x24, [sp, #112]
    5f70:	f00000d8 	adrp	x24, 20000 <__data_start>
    5f74:	9101c316 	add	x22, x24, #0x70
    5f78:	f9400022 	ldr	x2, [x1]
    5f7c:	f9001fe2 	str	x2, [sp, #56]
    5f80:	d2800002 	mov	x2, #0x0                   	// #0
    5f84:	910262c0 	add	x0, x22, #0x98
    5f88:	97fff55e 	bl	3500 <fwp_tape_buffers_dispose>
    5f8c:	f9006adf 	str	xzr, [x22, #208]
    5f90:	f9404ac0 	ldr	x0, [x22, #144]
    5f94:	f100001f 	cmp	x0, #0x0
    5f98:	5400030d 	b.le	5ff8 <fwp_tape_finish+0xa8>
    5f9c:	910003f7 	mov	x23, sp
    5fa0:	d2800015 	mov	x21, #0x0                   	// #0
    5fa4:	d2800014 	mov	x20, #0x0                   	// #0
    5fa8:	f94002d3 	ldr	x19, [x22]
    5fac:	91000694 	add	x20, x20, #0x1
    5fb0:	8b150273 	add	x19, x19, x21
    5fb4:	9101a2b5 	add	x21, x21, #0x68
    5fb8:	aa1303e0 	mov	x0, x19
    5fbc:	97fff415 	bl	3010 <fwp_tape_unlink_scope>
    5fc0:	aa1703e0 	mov	x0, x23
    5fc4:	f9401261 	ldr	x1, [x19, #32]
    5fc8:	f90003e1 	str	x1, [sp]
    5fcc:	f9401a62 	ldr	x2, [x19, #48]
    5fd0:	f9000be2 	str	x2, [sp, #16]
    5fd4:	f9402261 	ldr	x1, [x19, #64]
    5fd8:	f90013e1 	str	x1, [sp, #32]
    5fdc:	97fff549 	bl	3500 <fwp_tape_buffers_dispose>
    5fe0:	f9403260 	ldr	x0, [x19, #96]
    5fe4:	97ffff8f 	bl	5e20 <fwp_owned_tape_release>
    5fe8:	f900327f 	str	xzr, [x19, #96]
    5fec:	f9404ac0 	ldr	x0, [x22, #144]
    5ff0:	eb14001f 	cmp	x0, x20
    5ff4:	54fffdac 	b.gt	5fa8 <fwp_tape_finish+0x58>
    5ff8:	f9403b00 	ldr	x0, [x24, #112]
    5ffc:	9101c313 	add	x19, x24, #0x70
    6000:	97fff274 	bl	29d0 <free@plt>
    6004:	f9003b1f 	str	xzr, [x24, #112]
    6008:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    600c:	f947f400 	ldr	x0, [x0, #4072]
    6010:	f9004a7f 	str	xzr, [x19, #144]
    6014:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6018:	f9401fe2 	ldr	x2, [sp, #56]
    601c:	f9400001 	ldr	x1, [x0]
    6020:	eb010042 	subs	x2, x2, x1
    6024:	d2800001 	mov	x1, #0x0                   	// #0
    6028:	540000e1 	b.ne	6044 <fwp_tape_finish+0xf4>  // b.any
    602c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6030:	a94553f3 	ldp	x19, x20, [sp, #80]
    6034:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6038:	a94763f7 	ldp	x23, x24, [sp, #112]
    603c:	910203ff 	add	sp, sp, #0x80
    6040:	d65f03c0 	ret
    6044:	97fff233 	bl	2910 <__stack_chk_fail@plt>
    6048:	d503201f 	nop
    604c:	d503201f 	nop

0000000000006050 <fwp_tape_scope_release>:
    6050:	d10243ff 	sub	sp, sp, #0x90
    6054:	a9047bfd 	stp	x29, x30, [sp, #64]
    6058:	910103fd 	add	x29, sp, #0x40
    605c:	a90553f3 	stp	x19, x20, [sp, #80]
    6060:	aa0003f4 	mov	x20, x0
    6064:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6068:	f947f400 	ldr	x0, [x0, #4072]
    606c:	b9400285 	ldr	w5, [x20]
    6070:	f9400001 	ldr	x1, [x0]
    6074:	f9001fe1 	str	x1, [sp, #56]
    6078:	d2800001 	mov	x1, #0x0                   	// #0
    607c:	37f806c5 	tbnz	w5, #31, 6154 <fwp_tape_scope_release+0x104>
    6080:	a90763f7 	stp	x23, x24, [sp, #112]
    6084:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6088:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    608c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6090:	d00000d3 	adrp	x19, 20000 <__data_start>
    6094:	910003f7 	mov	x23, sp
    6098:	9101c273 	add	x19, x19, #0x70
    609c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    60a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    60a4:	52800d16 	mov	w22, #0x68                  	// #104
    60a8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    60ac:	f90043f9 	str	x25, [sp, #128]
    60b0:	14000006 	b	60c8 <fwp_tape_scope_release+0x78>
    60b4:	97fff513 	bl	3500 <fwp_tape_buffers_dispose>
    60b8:	aa1903e0 	mov	x0, x25
    60bc:	97ffff59 	bl	5e20 <fwp_owned_tape_release>
    60c0:	b9400285 	ldr	w5, [x20]
    60c4:	37f80425 	tbnz	w5, #31, 6148 <fwp_tape_scope_release+0xf8>
    60c8:	f9400266 	ldr	x6, [x19]
    60cc:	9b367ca5 	smull	x5, w5, w22
    60d0:	8b0500c0 	add	x0, x6, x5
    60d4:	97fff3cf 	bl	3010 <fwp_tape_unlink_scope>
    60d8:	ad410001 	ldp	q1, q0, [x0, #32]
    60dc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    60e0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    60e4:	f9400c03 	ldr	x3, [x0, #24]
    60e8:	ad0003e1 	stp	q1, q0, [sp]
    60ec:	b86568c1 	ldr	w1, [x6, x5]
    60f0:	a9440804 	ldp	x4, x2, [x0, #64]
    60f4:	b900041f 	str	wzr, [x0, #4]
    60f8:	f9403019 	ldr	x25, [x0, #96]
    60fc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6100:	f9000c1f 	str	xzr, [x0, #24]
    6104:	a9020fe4 	stp	x4, x3, [sp, #32]
    6108:	f9001be2 	str	x2, [sp, #48]
    610c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6110:	f900301f 	str	xzr, [x0, #96]
    6114:	6b15003f 	cmp	w1, w21
    6118:	540000e8 	b.hi	6134 <fwp_tape_scope_release+0xe4>  // b.pmore
    611c:	9343fca5 	asr	x5, x5, #3
    6120:	f9407660 	ldr	x0, [x19, #232]
    6124:	9b187ca5 	mul	x5, x5, x24
    6128:	eb0000bf 	cmp	x5, x0
    612c:	5400004a 	b.ge	6134 <fwp_tape_scope_release+0xe4>  // b.tcont
    6130:	f9007665 	str	x5, [x19, #232]
    6134:	aa1703e0 	mov	x0, x23
    6138:	b5fffbf9 	cbnz	x25, 60b4 <fwp_tape_scope_release+0x64>
    613c:	97fff8b1 	bl	4400 <fwp_tape_buffers_release>
    6140:	b9400285 	ldr	w5, [x20]
    6144:	36fffc25 	tbz	w5, #31, 60c8 <fwp_tape_scope_release+0x78>
    6148:	a9465bf5 	ldp	x21, x22, [sp, #96]
    614c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6150:	f94043f9 	ldr	x25, [sp, #128]
    6154:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6158:	f947f400 	ldr	x0, [x0, #4072]
    615c:	f9401fe2 	ldr	x2, [sp, #56]
    6160:	f9400001 	ldr	x1, [x0]
    6164:	eb010042 	subs	x2, x2, x1
    6168:	d2800001 	mov	x1, #0x0                   	// #0
    616c:	540000a1 	b.ne	6180 <fwp_tape_scope_release+0x130>  // b.any
    6170:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6174:	a94553f3 	ldp	x19, x20, [sp, #80]
    6178:	910243ff 	add	sp, sp, #0x90
    617c:	d65f03c0 	ret
    6180:	a9065bf5 	stp	x21, x22, [sp, #96]
    6184:	a90763f7 	stp	x23, x24, [sp, #112]
    6188:	f90043f9 	str	x25, [sp, #128]
    618c:	97fff1e1 	bl	2910 <__stack_chk_fail@plt>

0000000000006190 <fwp_drop4>:
    6190:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6194:	910003fd 	mov	x29, sp
    6198:	a9025bf5 	stp	x21, x22, [sp, #32]
    619c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    61a0:	911742d5 	add	x21, x22, #0x5d0
    61a4:	a90153f3 	stp	x19, x20, [sp, #16]
    61a8:	aa0003f3 	mov	x19, x0
    61ac:	f949daa1 	ldr	x1, [x21, #5040]
    61b0:	f949eea0 	ldr	x0, [x21, #5080]
    61b4:	cb010261 	sub	x1, x19, x1
    61b8:	eb00403f 	cmp	x1, x0, lsl #16
    61bc:	54000382 	b.cs	622c <fwp_drop4+0x9c>  // b.hs, b.nlast
    61c0:	d350fc22 	lsr	x2, x1, #16
    61c4:	f949fea3 	ldr	x3, [x21, #5112]
    61c8:	8b020842 	add	x2, x2, x2, lsl #2
    61cc:	d37df042 	lsl	x2, x2, #3
    61d0:	8b020060 	add	x0, x3, x2
    61d4:	f9401014 	ldr	x20, [x0, #32]
    61d8:	b40002b4 	cbz	x20, 622c <fwp_drop4+0x9c>
    61dc:	38626862 	ldrb	w2, [x3, x2]
    61e0:	7100085f 	cmp	w2, #0x2
    61e4:	540002c0 	b.eq	623c <fwp_drop4+0xac>  // b.none
    61e8:	7100045f 	cmp	w2, #0x1
    61ec:	54000201 	b.ne	622c <fwp_drop4+0x9c>  // b.any
    61f0:	29430002 	ldp	w2, w0, [x0, #24]
    61f4:	92403c21 	and	x1, x1, #0xffff
    61f8:	9b027c21 	mul	x1, x1, x2
    61fc:	d360fc21 	lsr	x1, x1, #32
    6200:	eb00003f 	cmp	x1, x0
    6204:	54000142 	b.cs	622c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6208:	8b010294 	add	x20, x20, x1
    620c:	39400280 	ldrb	w0, [x20]
    6210:	340000e0 	cbz	w0, 622c <fwp_drop4+0x9c>
    6214:	7100041f 	cmp	w0, #0x1
    6218:	540001e0 	b.eq	6254 <fwp_drop4+0xc4>  // b.none
    621c:	7103fc1f 	cmp	w0, #0xff
    6220:	540007c0 	b.eq	6318 <fwp_drop4+0x188>  // b.none
    6224:	51000400 	sub	w0, w0, #0x1
    6228:	39000280 	strb	w0, [x20]
    622c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6230:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6234:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6238:	d65f03c0 	ret
    623c:	72003c3f 	tst	w1, #0xffff
    6240:	54fffe60 	b.eq	620c <fwp_drop4+0x7c>  // b.none
    6244:	a94153f3 	ldp	x19, x20, [sp, #16]
    6248:	a9425bf5 	ldp	x21, x22, [sp, #32]
    624c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6250:	d65f03c0 	ret
    6254:	911742c2 	add	x2, x22, #0x5d0
    6258:	f9400660 	ldr	x0, [x19, #8]
    625c:	f949d841 	ldr	x1, [x2, #5040]
    6260:	f949ec42 	ldr	x2, [x2, #5080]
    6264:	cb010001 	sub	x1, x0, x1
    6268:	eb02403f 	cmp	x1, x2, lsl #16
    626c:	54000362 	b.cs	62d8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6270:	d350fc22 	lsr	x2, x1, #16
    6274:	8b020842 	add	x2, x2, x2, lsl #2
    6278:	d37df042 	lsl	x2, x2, #3
    627c:	8b020064 	add	x4, x3, x2
    6280:	f9401094 	ldr	x20, [x4, #32]
    6284:	b40002b4 	cbz	x20, 62d8 <fwp_drop4+0x148>
    6288:	38626862 	ldrb	w2, [x3, x2]
    628c:	7100085f 	cmp	w2, #0x2
    6290:	540003e0 	b.eq	630c <fwp_drop4+0x17c>  // b.none
    6294:	7100045f 	cmp	w2, #0x1
    6298:	54000201 	b.ne	62d8 <fwp_drop4+0x148>  // b.any
    629c:	29430883 	ldp	w3, w2, [x4, #24]
    62a0:	92403c21 	and	x1, x1, #0xffff
    62a4:	9b037c21 	mul	x1, x1, x3
    62a8:	d360fc21 	lsr	x1, x1, #32
    62ac:	eb02003f 	cmp	x1, x2
    62b0:	54000142 	b.cs	62d8 <fwp_drop4+0x148>  // b.hs, b.nlast
    62b4:	8b010294 	add	x20, x20, x1
    62b8:	39400281 	ldrb	w1, [x20]
    62bc:	340000e1 	cbz	w1, 62d8 <fwp_drop4+0x148>
    62c0:	7100043f 	cmp	w1, #0x1
    62c4:	54000200 	b.eq	6304 <fwp_drop4+0x174>  // b.none
    62c8:	7103fc3f 	cmp	w1, #0xff
    62cc:	54000580 	b.eq	637c <fwp_drop4+0x1ec>  // b.none
    62d0:	51000421 	sub	w1, w1, #0x1
    62d4:	39000281 	strb	w1, [x20]
    62d8:	f9400a74 	ldr	x20, [x19, #16]
    62dc:	aa1303e0 	mov	x0, x19
    62e0:	97fffcfd 	bl	56d4 <fwp_rc_free_arr>
    62e4:	911742c0 	add	x0, x22, #0x5d0
    62e8:	f949d801 	ldr	x1, [x0, #5040]
    62ec:	f949ec00 	ldr	x0, [x0, #5080]
    62f0:	cb010281 	sub	x1, x20, x1
    62f4:	eb00403f 	cmp	x1, x0, lsl #16
    62f8:	54fff9a2 	b.cs	622c <fwp_drop4+0x9c>  // b.hs, b.nlast
    62fc:	aa1403f3 	mov	x19, x20
    6300:	17ffffb0 	b	61c0 <fwp_drop4+0x30>
    6304:	97fffcf4 	bl	56d4 <fwp_rc_free_arr>
    6308:	17fffff4 	b	62d8 <fwp_drop4+0x148>
    630c:	72003c3f 	tst	w1, #0xffff
    6310:	54fffe41 	b.ne	62d8 <fwp_drop4+0x148>  // b.any
    6314:	17ffffe9 	b	62b8 <fwp_drop4+0x128>
    6318:	ca544681 	eor	x1, x20, x20, lsr #17
    631c:	911742c0 	add	x0, x22, #0x5d0
    6320:	ca412421 	eor	x1, x1, x1, lsr #9
    6324:	8b210c01 	add	x1, x0, w1, uxtb #3
    6328:	f94a2420 	ldr	x0, [x1, #5192]
    632c:	b5000080 	cbnz	x0, 633c <fwp_drop4+0x1ac>
    6330:	14000010 	b	6370 <fwp_drop4+0x1e0>
    6334:	f9400800 	ldr	x0, [x0, #16]
    6338:	b40001c0 	cbz	x0, 6370 <fwp_drop4+0x1e0>
    633c:	f9400001 	ldr	x1, [x0]
    6340:	eb14003f 	cmp	x1, x20
    6344:	54ffff81 	b.ne	6334 <fwp_drop4+0x1a4>  // b.any
    6348:	f9400401 	ldr	x1, [x0, #8]
    634c:	d1000421 	sub	x1, x1, #0x1
    6350:	f9000401 	str	x1, [x0, #8]
    6354:	f103f83f 	cmp	x1, #0xfe
    6358:	54fff6a1 	b.ne	622c <fwp_drop4+0x9c>  // b.any
    635c:	aa1403e0 	mov	x0, x20
    6360:	97fff944 	bl	4870 <fwp_rc_forget_slot>
    6364:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6368:	39000280 	strb	w0, [x20]
    636c:	17ffffb0 	b	622c <fwp_drop4+0x9c>
    6370:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    6374:	910a0000 	add	x0, x0, #0x280
    6378:	97fff542 	bl	3880 <fwp_trap>
    637c:	ca544680 	eor	x0, x20, x20, lsr #17
    6380:	911742c1 	add	x1, x22, #0x5d0
    6384:	ca402400 	eor	x0, x0, x0, lsr #9
    6388:	8b200c20 	add	x0, x1, w0, uxtb #3
    638c:	f94a2400 	ldr	x0, [x0, #5192]
    6390:	b5000080 	cbnz	x0, 63a0 <fwp_drop4+0x210>
    6394:	17fffff7 	b	6370 <fwp_drop4+0x1e0>
    6398:	f9400800 	ldr	x0, [x0, #16]
    639c:	b4fffea0 	cbz	x0, 6370 <fwp_drop4+0x1e0>
    63a0:	f9400001 	ldr	x1, [x0]
    63a4:	eb14003f 	cmp	x1, x20
    63a8:	54ffff81 	b.ne	6398 <fwp_drop4+0x208>  // b.any
    63ac:	f9400401 	ldr	x1, [x0, #8]
    63b0:	d1000421 	sub	x1, x1, #0x1
    63b4:	f9000401 	str	x1, [x0, #8]
    63b8:	f103f83f 	cmp	x1, #0xfe
    63bc:	54fff8e1 	b.ne	62d8 <fwp_drop4+0x148>  // b.any
    63c0:	aa1403e0 	mov	x0, x20
    63c4:	97fff92b 	bl	4870 <fwp_rc_forget_slot>
    63c8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    63cc:	39000280 	strb	w0, [x20]
    63d0:	17ffffc2 	b	62d8 <fwp_drop4+0x148>

00000000000063d4 <fwp_arg_drop37>:
    63d4:	7100003f 	cmp	w1, #0x0
    63d8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    63dc:	54000041 	b.ne	63e4 <fwp_arg_drop37+0x10>  // b.any
    63e0:	d65f03c0 	ret
    63e4:	f9400000 	ldr	x0, [x0]
    63e8:	17ffff6a 	b	6190 <fwp_drop4>
    63ec:	d503201f 	nop

00000000000063f0 <fwp_task_dispose>:
    63f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63f4:	910003fd 	mov	x29, sp
    63f8:	f9000bf3 	str	x19, [sp, #16]
    63fc:	aa0003f3 	mov	x19, x0
    6400:	39414000 	ldrb	w0, [x0, #80]
    6404:	36000720 	tbz	w0, #0, 64e8 <fwp_task_dispose+0xf8>
    6408:	f9400a60 	ldr	x0, [x19, #16]
    640c:	b50006e0 	cbnz	x0, 64e8 <fwp_task_dispose+0xf8>
    6410:	a9478660 	ldp	x0, x1, [x19, #120]
    6414:	39014e7f 	strb	wzr, [x19, #83]
    6418:	f9003e7f 	str	xzr, [x19, #120]
    641c:	f100003f 	cmp	x1, #0x0
    6420:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6424:	54000040 	b.eq	642c <fwp_task_dispose+0x3c>  // b.none
    6428:	d63f0020 	blr	x1
    642c:	f9405660 	ldr	x0, [x19, #168]
    6430:	97fff9b0 	bl	4af0 <fwp_mem_free>
    6434:	f900567f 	str	xzr, [x19, #168]
    6438:	b9405e60 	ldr	w0, [x19, #92]
    643c:	7100041f 	cmp	w0, #0x1
    6440:	54000420 	b.eq	64c4 <fwp_task_dispose+0xd4>  // b.none
    6444:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6448:	91174042 	add	x2, x2, #0x5d0
    644c:	f949d840 	ldr	x0, [x2, #5040]
    6450:	f949ec41 	ldr	x1, [x2, #5080]
    6454:	cb000260 	sub	x0, x19, x0
    6458:	eb01401f 	cmp	x0, x1, lsl #16
    645c:	540002e2 	b.cs	64b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6460:	d350fc01 	lsr	x1, x0, #16
    6464:	f949fc44 	ldr	x4, [x2, #5112]
    6468:	8b010821 	add	x1, x1, x1, lsl #2
    646c:	d37df021 	lsl	x1, x1, #3
    6470:	8b010083 	add	x3, x4, x1
    6474:	f9401062 	ldr	x2, [x3, #32]
    6478:	b4000202 	cbz	x2, 64b8 <fwp_task_dispose+0xc8>
    647c:	38616881 	ldrb	w1, [x4, x1]
    6480:	7100083f 	cmp	w1, #0x2
    6484:	54000280 	b.eq	64d4 <fwp_task_dispose+0xe4>  // b.none
    6488:	7100043f 	cmp	w1, #0x1
    648c:	54000161 	b.ne	64b8 <fwp_task_dispose+0xc8>  // b.any
    6490:	29430464 	ldp	w4, w1, [x3, #24]
    6494:	92403c00 	and	x0, x0, #0xffff
    6498:	9b047c00 	mul	x0, x0, x4
    649c:	d360fc00 	lsr	x0, x0, #32
    64a0:	eb01001f 	cmp	x0, x1
    64a4:	540000a2 	b.cs	64b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    64a8:	8b000042 	add	x2, x2, x0
    64ac:	39400040 	ldrb	w0, [x2]
    64b0:	7100041f 	cmp	w0, #0x1
    64b4:	54000080 	b.eq	64c4 <fwp_task_dispose+0xd4>  // b.none
    64b8:	f9400bf3 	ldr	x19, [sp, #16]
    64bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64c0:	d65f03c0 	ret
    64c4:	aa1303e0 	mov	x0, x19
    64c8:	f9400bf3 	ldr	x19, [sp, #16]
    64cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64d0:	17fff988 	b	4af0 <fwp_mem_free>
    64d4:	72003c1f 	tst	w0, #0xffff
    64d8:	54fffea0 	b.eq	64ac <fwp_task_dispose+0xbc>  // b.none
    64dc:	f9400bf3 	ldr	x19, [sp, #16]
    64e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64e4:	d65f03c0 	ret
    64e8:	97fff11e 	bl	2960 <abort@plt>
    64ec:	d503201f 	nop

00000000000064f0 <fwp_free_zombie>:
    64f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64f4:	910003fd 	mov	x29, sp
    64f8:	a90153f3 	stp	x19, x20, [sp, #16]
    64fc:	d00000d4 	adrp	x20, 20000 <__data_start>
    6500:	9101c281 	add	x1, x20, #0x70
    6504:	f9407833 	ldr	x19, [x1, #240]
    6508:	b4000333 	cbz	x19, 656c <fwp_free_zombie+0x7c>
    650c:	f9400820 	ldr	x0, [x1, #16]
    6510:	eb00027f 	cmp	x19, x0
    6514:	540002c0 	b.eq	656c <fwp_free_zombie+0x7c>  // b.none
    6518:	b940f822 	ldr	w2, [x1, #248]
    651c:	f9400a60 	ldr	x0, [x19, #16]
    6520:	7100fc5f 	cmp	w2, #0x3f
    6524:	5400078c 	b.gt	6614 <fwp_free_zombie+0x124>
    6528:	91040023 	add	x3, x1, #0x100
    652c:	11000444 	add	w4, w2, #0x1
    6530:	b900f824 	str	w4, [x1, #248]
    6534:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6538:	f822d860 	str	x0, [x3, w2, sxtw #3]
    653c:	a9530261 	ldp	x1, x0, [x19, #304]
    6540:	b4000741 	cbz	x1, 6628 <fwp_free_zombie+0x138>
    6544:	f9009c20 	str	x0, [x1, #312]
    6548:	b4000040 	cbz	x0, 6550 <fwp_free_zombie+0x60>
    654c:	f9009801 	str	x1, [x0, #304]
    6550:	9101c294 	add	x20, x20, #0x70
    6554:	b9405e60 	ldr	w0, [x19, #92]
    6558:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    655c:	f9007a9f 	str	xzr, [x20, #240]
    6560:	34000140 	cbz	w0, 6588 <fwp_free_zombie+0x98>
    6564:	7100041f 	cmp	w0, #0x1
    6568:	54000080 	b.eq	6578 <fwp_free_zombie+0x88>  // b.none
    656c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6570:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6574:	d65f03c0 	ret
    6578:	aa1303e0 	mov	x0, x19
    657c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6580:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6584:	17ffff9b 	b	63f0 <fwp_task_dispose>
    6588:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    658c:	91174082 	add	x2, x4, #0x5d0
    6590:	f949d841 	ldr	x1, [x2, #5040]
    6594:	f949ec40 	ldr	x0, [x2, #5080]
    6598:	cb010261 	sub	x1, x19, x1
    659c:	eb00403f 	cmp	x1, x0, lsl #16
    65a0:	54fffe62 	b.cs	656c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    65a4:	d350fc20 	lsr	x0, x1, #16
    65a8:	f949fc43 	ldr	x3, [x2, #5112]
    65ac:	8b000800 	add	x0, x0, x0, lsl #2
    65b0:	d37df000 	lsl	x0, x0, #3
    65b4:	8b000062 	add	x2, x3, x0
    65b8:	f9401054 	ldr	x20, [x2, #32]
    65bc:	b4fffd94 	cbz	x20, 656c <fwp_free_zombie+0x7c>
    65c0:	38606860 	ldrb	w0, [x3, x0]
    65c4:	7100081f 	cmp	w0, #0x2
    65c8:	54000360 	b.eq	6634 <fwp_free_zombie+0x144>  // b.none
    65cc:	7100041f 	cmp	w0, #0x1
    65d0:	54fffce1 	b.ne	656c <fwp_free_zombie+0x7c>  // b.any
    65d4:	29430043 	ldp	w3, w0, [x2, #24]
    65d8:	92403c21 	and	x1, x1, #0xffff
    65dc:	9b037c21 	mul	x1, x1, x3
    65e0:	d360fc21 	lsr	x1, x1, #32
    65e4:	eb00003f 	cmp	x1, x0
    65e8:	54fffc22 	b.cs	656c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    65ec:	8b010294 	add	x20, x20, x1
    65f0:	39400280 	ldrb	w0, [x20]
    65f4:	34fffbc0 	cbz	w0, 656c <fwp_free_zombie+0x7c>
    65f8:	7100041f 	cmp	w0, #0x1
    65fc:	54fffbe0 	b.eq	6578 <fwp_free_zombie+0x88>  // b.none
    6600:	7103fc1f 	cmp	w0, #0xff
    6604:	540001e0 	b.eq	6640 <fwp_free_zombie+0x150>  // b.none
    6608:	51000400 	sub	w0, w0, #0x1
    660c:	39000280 	strb	w0, [x20]
    6610:	17ffffd7 	b	656c <fwp_free_zombie+0x7c>
    6614:	f9400e61 	ldr	x1, [x19, #24]
    6618:	97fff106 	bl	2a30 <munmap@plt>
    661c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6620:	a9530261 	ldp	x1, x0, [x19, #304]
    6624:	b5fff901 	cbnz	x1, 6544 <fwp_free_zombie+0x54>
    6628:	9101c282 	add	x2, x20, #0x70
    662c:	f9018040 	str	x0, [x2, #768]
    6630:	17ffffc6 	b	6548 <fwp_free_zombie+0x58>
    6634:	72003c3f 	tst	w1, #0xffff
    6638:	54fff9a1 	b.ne	656c <fwp_free_zombie+0x7c>  // b.any
    663c:	17ffffed 	b	65f0 <fwp_free_zombie+0x100>
    6640:	ca544680 	eor	x0, x20, x20, lsr #17
    6644:	91174084 	add	x4, x4, #0x5d0
    6648:	ca402400 	eor	x0, x0, x0, lsr #9
    664c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6650:	f94a2400 	ldr	x0, [x0, #5192]
    6654:	b5000080 	cbnz	x0, 6664 <fwp_free_zombie+0x174>
    6658:	14000010 	b	6698 <fwp_free_zombie+0x1a8>
    665c:	f9400800 	ldr	x0, [x0, #16]
    6660:	b40001c0 	cbz	x0, 6698 <fwp_free_zombie+0x1a8>
    6664:	f9400001 	ldr	x1, [x0]
    6668:	eb14003f 	cmp	x1, x20
    666c:	54ffff81 	b.ne	665c <fwp_free_zombie+0x16c>  // b.any
    6670:	f9400401 	ldr	x1, [x0, #8]
    6674:	d1000421 	sub	x1, x1, #0x1
    6678:	f9000401 	str	x1, [x0, #8]
    667c:	f103f83f 	cmp	x1, #0xfe
    6680:	54fff761 	b.ne	656c <fwp_free_zombie+0x7c>  // b.any
    6684:	aa1403e0 	mov	x0, x20
    6688:	97fff87a 	bl	4870 <fwp_rc_forget_slot>
    668c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6690:	39000280 	strb	w0, [x20]
    6694:	17ffffb6 	b	656c <fwp_free_zombie+0x7c>
    6698:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    669c:	910a0000 	add	x0, x0, #0x280
    66a0:	97fff478 	bl	3880 <fwp_trap>

00000000000066a4 <fwp_block>:
    66a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66a8:	910003fd 	mov	x29, sp
    66ac:	a90153f3 	stp	x19, x20, [sp, #16]
    66b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    66b4:	9101c274 	add	x20, x19, #0x70
    66b8:	f9404282 	ldr	x2, [x20, #128]
    66bc:	b4000622 	cbz	x2, 6780 <fwp_block+0xdc>
    66c0:	9101c261 	add	x1, x19, #0x70
    66c4:	f9408040 	ldr	x0, [x2, #256]
    66c8:	f9004020 	str	x0, [x1, #128]
    66cc:	b4000680 	cbz	x0, 679c <fwp_block+0xf8>
    66d0:	9101c263 	add	x3, x19, #0x70
    66d4:	3901505f 	strb	wzr, [x2, #84]
    66d8:	f9400864 	ldr	x4, [x3, #16]
    66dc:	eb02009f 	cmp	x4, x2
    66e0:	54000440 	b.eq	6768 <fwp_block+0xc4>  // b.none
    66e4:	f9418465 	ldr	x5, [x3, #776]
    66e8:	f9000862 	str	x2, [x3, #16]
    66ec:	f9400441 	ldr	x1, [x2, #8]
    66f0:	f9004885 	str	x5, [x4, #144]
    66f4:	f9418865 	ldr	x5, [x3, #784]
    66f8:	f9004c85 	str	x5, [x4, #152]
    66fc:	f9418c65 	ldr	x5, [x3, #792]
    6700:	f9005085 	str	x5, [x4, #160]
    6704:	f9419065 	ldr	x5, [x3, #800]
    6708:	f9005485 	str	x5, [x4, #168]
    670c:	f9419465 	ldr	x5, [x3, #808]
    6710:	f9005885 	str	x5, [x4, #176]
    6714:	f9419865 	ldr	x5, [x3, #816]
    6718:	f9005c85 	str	x5, [x4, #184]
    671c:	f9419c65 	ldr	x5, [x3, #824]
    6720:	f9006085 	str	x5, [x4, #192]
    6724:	f9400480 	ldr	x0, [x4, #8]
    6728:	f9404844 	ldr	x4, [x2, #144]
    672c:	f9018464 	str	x4, [x3, #776]
    6730:	f9404c44 	ldr	x4, [x2, #152]
    6734:	f9018864 	str	x4, [x3, #784]
    6738:	f9405044 	ldr	x4, [x2, #160]
    673c:	f9018c64 	str	x4, [x3, #792]
    6740:	f9405444 	ldr	x4, [x2, #168]
    6744:	f9019064 	str	x4, [x3, #800]
    6748:	f9405844 	ldr	x4, [x2, #176]
    674c:	f9019464 	str	x4, [x3, #808]
    6750:	a94b8844 	ldp	x4, x2, [x2, #184]
    6754:	f9019864 	str	x4, [x3, #816]
    6758:	f9019c62 	str	x2, [x3, #824]
    675c:	97fff085 	bl	2970 <swapcontext@plt>
    6760:	97ffff64 	bl	64f0 <fwp_free_zombie>
    6764:	d503201f 	nop
    6768:	9101c260 	add	x0, x19, #0x70
    676c:	b9434000 	ldr	w0, [x0, #832]
    6770:	340001a0 	cbz	w0, 67a4 <fwp_block+0x100>
    6774:	a94153f3 	ldp	x19, x20, [sp, #16]
    6778:	a8c27bfd 	ldp	x29, x30, [sp], #32
    677c:	d65f03c0 	ret
    6780:	97fff768 	bl	4520 <fwp_poll_events>
    6784:	f9404282 	ldr	x2, [x20, #128]
    6788:	b4ffffc2 	cbz	x2, 6780 <fwp_block+0xdc>
    678c:	9101c261 	add	x1, x19, #0x70
    6790:	f9408040 	ldr	x0, [x2, #256]
    6794:	f9004020 	str	x0, [x1, #128]
    6798:	b5fff9c0 	cbnz	x0, 66d0 <fwp_block+0x2c>
    679c:	f9003c3f 	str	xzr, [x1, #120]
    67a0:	17ffffcc 	b	66d0 <fwp_block+0x2c>
    67a4:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    67a8:	910ec000 	add	x0, x0, #0x3b0
    67ac:	97fff0bd 	bl	2aa0 <getenv@plt>
    67b0:	5284e202 	mov	w2, #0x2710                	// #10000
    67b4:	b4000060 	cbz	x0, 67c0 <fwp_block+0x11c>
    67b8:	39400001 	ldrb	w1, [x0]
    67bc:	350000c1 	cbnz	w1, 67d4 <fwp_block+0x130>
    67c0:	9101c273 	add	x19, x19, #0x70
    67c4:	b9034262 	str	w2, [x19, #832]
    67c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    67cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67d0:	d65f03c0 	ret
    67d4:	52800142 	mov	w2, #0xa                   	// #10
    67d8:	d2800001 	mov	x1, #0x0                   	// #0
    67dc:	97fff001 	bl	27e0 <strtoll@plt>
    67e0:	d1000403 	sub	x3, x0, #0x1
    67e4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    67e8:	eb02007f 	cmp	x3, x2
    67ec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    67f0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    67f4:	17fffff3 	b	67c0 <fwp_block+0x11c>
    67f8:	d503201f 	nop
    67fc:	d503201f 	nop

0000000000006800 <fwp_drop10>:
    6800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6804:	910003fd 	mov	x29, sp
    6808:	a90153f3 	stp	x19, x20, [sp, #16]
    680c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6810:	f90013f5 	str	x21, [sp, #32]
    6814:	91174275 	add	x21, x19, #0x5d0
    6818:	f949daa1 	ldr	x1, [x21, #5040]
    681c:	f949eea2 	ldr	x2, [x21, #5080]
    6820:	cb010001 	sub	x1, x0, x1
    6824:	eb02403f 	cmp	x1, x2, lsl #16
    6828:	54000382 	b.cs	6898 <fwp_drop10+0x98>  // b.hs, b.nlast
    682c:	d350fc22 	lsr	x2, x1, #16
    6830:	f949fea3 	ldr	x3, [x21, #5112]
    6834:	8b020842 	add	x2, x2, x2, lsl #2
    6838:	d37df042 	lsl	x2, x2, #3
    683c:	8b020064 	add	x4, x3, x2
    6840:	f9401094 	ldr	x20, [x4, #32]
    6844:	b40002b4 	cbz	x20, 6898 <fwp_drop10+0x98>
    6848:	38626862 	ldrb	w2, [x3, x2]
    684c:	7100085f 	cmp	w2, #0x2
    6850:	540007a0 	b.eq	6944 <fwp_drop10+0x144>  // b.none
    6854:	7100045f 	cmp	w2, #0x1
    6858:	54000201 	b.ne	6898 <fwp_drop10+0x98>  // b.any
    685c:	29430885 	ldp	w5, w2, [x4, #24]
    6860:	92403c21 	and	x1, x1, #0xffff
    6864:	9b057c21 	mul	x1, x1, x5
    6868:	d360fc21 	lsr	x1, x1, #32
    686c:	eb02003f 	cmp	x1, x2
    6870:	54000142 	b.cs	6898 <fwp_drop10+0x98>  // b.hs, b.nlast
    6874:	8b010294 	add	x20, x20, x1
    6878:	39400281 	ldrb	w1, [x20]
    687c:	340000e1 	cbz	w1, 6898 <fwp_drop10+0x98>
    6880:	7100043f 	cmp	w1, #0x1
    6884:	54000120 	b.eq	68a8 <fwp_drop10+0xa8>  // b.none
    6888:	7103fc3f 	cmp	w1, #0xff
    688c:	540007c0 	b.eq	6984 <fwp_drop10+0x184>  // b.none
    6890:	51000421 	sub	w1, w1, #0x1
    6894:	39000281 	strb	w1, [x20]
    6898:	a94153f3 	ldp	x19, x20, [sp, #16]
    689c:	f94013f5 	ldr	x21, [sp, #32]
    68a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    68a4:	d65f03c0 	ret
    68a8:	f9400001 	ldr	x1, [x0]
    68ac:	b7f80581 	tbnz	x1, #63, 695c <fwp_drop10+0x15c>
    68b0:	91174273 	add	x19, x19, #0x5d0
    68b4:	f949da61 	ldr	x1, [x19, #5040]
    68b8:	f949ee62 	ldr	x2, [x19, #5080]
    68bc:	cb010001 	sub	x1, x0, x1
    68c0:	eb02403f 	cmp	x1, x2, lsl #16
    68c4:	54fffea2 	b.cs	6898 <fwp_drop10+0x98>  // b.hs, b.nlast
    68c8:	d350fc22 	lsr	x2, x1, #16
    68cc:	8b020842 	add	x2, x2, x2, lsl #2
    68d0:	d37df042 	lsl	x2, x2, #3
    68d4:	8b020065 	add	x5, x3, x2
    68d8:	f94010a4 	ldr	x4, [x5, #32]
    68dc:	b4fffde4 	cbz	x4, 6898 <fwp_drop10+0x98>
    68e0:	38626862 	ldrb	w2, [x3, x2]
    68e4:	7100085f 	cmp	w2, #0x2
    68e8:	54000220 	b.eq	692c <fwp_drop10+0x12c>  // b.none
    68ec:	7100045f 	cmp	w2, #0x1
    68f0:	54fffd41 	b.ne	6898 <fwp_drop10+0x98>  // b.any
    68f4:	294308a3 	ldp	w3, w2, [x5, #24]
    68f8:	92403c21 	and	x1, x1, #0xffff
    68fc:	9b037c21 	mul	x1, x1, x3
    6900:	d360fc21 	lsr	x1, x1, #32
    6904:	eb02003f 	cmp	x1, x2
    6908:	54fffc82 	b.cs	6898 <fwp_drop10+0x98>  // b.hs, b.nlast
    690c:	8b010084 	add	x4, x4, x1
    6910:	39400081 	ldrb	w1, [x4]
    6914:	7100043f 	cmp	w1, #0x1
    6918:	54fffc01 	b.ne	6898 <fwp_drop10+0x98>  // b.any
    691c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6920:	f94013f5 	ldr	x21, [sp, #32]
    6924:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6928:	17fff872 	b	4af0 <fwp_mem_free>
    692c:	72003c3f 	tst	w1, #0xffff
    6930:	54ffff00 	b.eq	6910 <fwp_drop10+0x110>  // b.none
    6934:	a94153f3 	ldp	x19, x20, [sp, #16]
    6938:	f94013f5 	ldr	x21, [sp, #32]
    693c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6940:	d65f03c0 	ret
    6944:	72003c3f 	tst	w1, #0xffff
    6948:	54fff980 	b.eq	6878 <fwp_drop10+0x78>  // b.none
    694c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6950:	f94013f5 	ldr	x21, [sp, #32]
    6954:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6958:	d65f03c0 	ret
    695c:	f9400414 	ldr	x20, [x0, #8]
    6960:	97fffb5d 	bl	56d4 <fwp_rc_free_arr>
    6964:	91174260 	add	x0, x19, #0x5d0
    6968:	f949d801 	ldr	x1, [x0, #5040]
    696c:	f949ec00 	ldr	x0, [x0, #5080]
    6970:	cb010281 	sub	x1, x20, x1
    6974:	eb00403f 	cmp	x1, x0, lsl #16
    6978:	54fff902 	b.cs	6898 <fwp_drop10+0x98>  // b.hs, b.nlast
    697c:	aa1403e0 	mov	x0, x20
    6980:	17ffffab 	b	682c <fwp_drop10+0x2c>
    6984:	ca544680 	eor	x0, x20, x20, lsr #17
    6988:	91174273 	add	x19, x19, #0x5d0
    698c:	ca402400 	eor	x0, x0, x0, lsr #9
    6990:	8b200e60 	add	x0, x19, w0, uxtb #3
    6994:	f94a2400 	ldr	x0, [x0, #5192]
    6998:	b5000080 	cbnz	x0, 69a8 <fwp_drop10+0x1a8>
    699c:	14000010 	b	69dc <fwp_drop10+0x1dc>
    69a0:	f9400800 	ldr	x0, [x0, #16]
    69a4:	b40001c0 	cbz	x0, 69dc <fwp_drop10+0x1dc>
    69a8:	f9400001 	ldr	x1, [x0]
    69ac:	eb14003f 	cmp	x1, x20
    69b0:	54ffff81 	b.ne	69a0 <fwp_drop10+0x1a0>  // b.any
    69b4:	f9400401 	ldr	x1, [x0, #8]
    69b8:	d1000421 	sub	x1, x1, #0x1
    69bc:	f9000401 	str	x1, [x0, #8]
    69c0:	f103f83f 	cmp	x1, #0xfe
    69c4:	54fff6a1 	b.ne	6898 <fwp_drop10+0x98>  // b.any
    69c8:	aa1403e0 	mov	x0, x20
    69cc:	97fff7a9 	bl	4870 <fwp_rc_forget_slot>
    69d0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    69d4:	39000280 	strb	w0, [x20]
    69d8:	17ffffb0 	b	6898 <fwp_drop10+0x98>
    69dc:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    69e0:	910a0000 	add	x0, x0, #0x280
    69e4:	97fff3a7 	bl	3880 <fwp_trap>
    69e8:	d503201f 	nop
    69ec:	d503201f 	nop

00000000000069f0 <fwp_caps173>:
    69f0:	34000041 	cbz	w1, 69f8 <fwp_caps173+0x8>
    69f4:	d65f03c0 	ret
    69f8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    69fc:	91174063 	add	x3, x3, #0x5d0
    6a00:	f949d861 	ldr	x1, [x3, #5040]
    6a04:	f949ec62 	ldr	x2, [x3, #5080]
    6a08:	cb010001 	sub	x1, x0, x1
    6a0c:	eb02403f 	cmp	x1, x2, lsl #16
    6a10:	54ffff22 	b.cs	69f4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6a14:	d350fc22 	lsr	x2, x1, #16
    6a18:	f949fc65 	ldr	x5, [x3, #5112]
    6a1c:	8b020842 	add	x2, x2, x2, lsl #2
    6a20:	d37df042 	lsl	x2, x2, #3
    6a24:	8b0200a4 	add	x4, x5, x2
    6a28:	f9401083 	ldr	x3, [x4, #32]
    6a2c:	b4fffe43 	cbz	x3, 69f4 <fwp_caps173+0x4>
    6a30:	386268a2 	ldrb	w2, [x5, x2]
    6a34:	7100085f 	cmp	w2, #0x2
    6a38:	540001c0 	b.eq	6a70 <fwp_caps173+0x80>  // b.none
    6a3c:	7100045f 	cmp	w2, #0x1
    6a40:	54fffda1 	b.ne	69f4 <fwp_caps173+0x4>  // b.any
    6a44:	29430885 	ldp	w5, w2, [x4, #24]
    6a48:	92403c21 	and	x1, x1, #0xffff
    6a4c:	9b057c21 	mul	x1, x1, x5
    6a50:	d360fc21 	lsr	x1, x1, #32
    6a54:	eb02003f 	cmp	x1, x2
    6a58:	54fffce2 	b.cs	69f4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6a5c:	8b010063 	add	x3, x3, x1
    6a60:	39400061 	ldrb	w1, [x3]
    6a64:	7100043f 	cmp	w1, #0x1
    6a68:	54fffc61 	b.ne	69f4 <fwp_caps173+0x4>  // b.any
    6a6c:	17fff821 	b	4af0 <fwp_mem_free>
    6a70:	72003c3f 	tst	w1, #0xffff
    6a74:	54ffff60 	b.eq	6a60 <fwp_caps173+0x70>  // b.none
    6a78:	d65f03c0 	ret
    6a7c:	d503201f 	nop

0000000000006a80 <fwp_args37>:
    6a80:	7100003f 	cmp	w1, #0x0
    6a84:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6a88:	54000041 	b.ne	6a90 <fwp_args37+0x10>  // b.any
    6a8c:	d65f03c0 	ret
    6a90:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6a94:	91174042 	add	x2, x2, #0x5d0
    6a98:	f9400001 	ldr	x1, [x0]
    6a9c:	f949d843 	ldr	x3, [x2, #5040]
    6aa0:	f949ec40 	ldr	x0, [x2, #5080]
    6aa4:	cb030021 	sub	x1, x1, x3
    6aa8:	eb00403f 	cmp	x1, x0, lsl #16
    6aac:	54ffff02 	b.cs	6a8c <fwp_args37+0xc>  // b.hs, b.nlast
    6ab0:	d350fc20 	lsr	x0, x1, #16
    6ab4:	f949fc44 	ldr	x4, [x2, #5112]
    6ab8:	8b000800 	add	x0, x0, x0, lsl #2
    6abc:	d37df002 	lsl	x2, x0, #3
    6ac0:	8b020083 	add	x3, x4, x2
    6ac4:	f9401060 	ldr	x0, [x3, #32]
    6ac8:	b4fffe20 	cbz	x0, 6a8c <fwp_args37+0xc>
    6acc:	38626882 	ldrb	w2, [x4, x2]
    6ad0:	7100085f 	cmp	w2, #0x2
    6ad4:	54000220 	b.eq	6b18 <fwp_args37+0x98>  // b.none
    6ad8:	7100045f 	cmp	w2, #0x1
    6adc:	54fffd81 	b.ne	6a8c <fwp_args37+0xc>  // b.any
    6ae0:	29430864 	ldp	w4, w2, [x3, #24]
    6ae4:	92403c21 	and	x1, x1, #0xffff
    6ae8:	9b047c21 	mul	x1, x1, x4
    6aec:	d360fc21 	lsr	x1, x1, #32
    6af0:	eb02003f 	cmp	x1, x2
    6af4:	54fffcc2 	b.cs	6a8c <fwp_args37+0xc>  // b.hs, b.nlast
    6af8:	8b010000 	add	x0, x0, x1
    6afc:	39400001 	ldrb	w1, [x0]
    6b00:	34fffc61 	cbz	w1, 6a8c <fwp_args37+0xc>
    6b04:	7103f43f 	cmp	w1, #0xfd
    6b08:	540000e8 	b.hi	6b24 <fwp_args37+0xa4>  // b.pmore
    6b0c:	11000421 	add	w1, w1, #0x1
    6b10:	39000001 	strb	w1, [x0]
    6b14:	d65f03c0 	ret
    6b18:	72003c3f 	tst	w1, #0xffff
    6b1c:	54ffff00 	b.eq	6afc <fwp_args37+0x7c>  // b.none
    6b20:	d65f03c0 	ret
    6b24:	17fff70c 	b	4754 <fwp_rc_wide_dup>
    6b28:	d503201f 	nop
    6b2c:	d503201f 	nop

0000000000006b30 <fwp_caps37>:
    6b30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b34:	910003fd 	mov	x29, sp
    6b38:	f9000bf3 	str	x19, [sp, #16]
    6b3c:	aa0003f3 	mov	x19, x0
    6b40:	b9400400 	ldr	w0, [x0, #4]
    6b44:	340004a0 	cbz	w0, 6bd8 <fwp_caps37+0xa8>
    6b48:	f9400660 	ldr	x0, [x19, #8]
    6b4c:	350004e1 	cbnz	w1, 6be8 <fwp_caps37+0xb8>
    6b50:	97fffd90 	bl	6190 <fwp_drop4>
    6b54:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6b58:	91174042 	add	x2, x2, #0x5d0
    6b5c:	f949d840 	ldr	x0, [x2, #5040]
    6b60:	f949ec41 	ldr	x1, [x2, #5080]
    6b64:	cb000260 	sub	x0, x19, x0
    6b68:	eb01401f 	cmp	x0, x1, lsl #16
    6b6c:	54000382 	b.cs	6bdc <fwp_caps37+0xac>  // b.hs, b.nlast
    6b70:	d350fc01 	lsr	x1, x0, #16
    6b74:	f949fc44 	ldr	x4, [x2, #5112]
    6b78:	8b010821 	add	x1, x1, x1, lsl #2
    6b7c:	d37df021 	lsl	x1, x1, #3
    6b80:	8b010083 	add	x3, x4, x1
    6b84:	f9401062 	ldr	x2, [x3, #32]
    6b88:	b40002a2 	cbz	x2, 6bdc <fwp_caps37+0xac>
    6b8c:	38616881 	ldrb	w1, [x4, x1]
    6b90:	7100083f 	cmp	w1, #0x2
    6b94:	540006c0 	b.eq	6c6c <fwp_caps37+0x13c>  // b.none
    6b98:	7100043f 	cmp	w1, #0x1
    6b9c:	54000201 	b.ne	6bdc <fwp_caps37+0xac>  // b.any
    6ba0:	29430464 	ldp	w4, w1, [x3, #24]
    6ba4:	92403c00 	and	x0, x0, #0xffff
    6ba8:	9b047c00 	mul	x0, x0, x4
    6bac:	d360fc00 	lsr	x0, x0, #32
    6bb0:	eb01001f 	cmp	x0, x1
    6bb4:	54000142 	b.cs	6bdc <fwp_caps37+0xac>  // b.hs, b.nlast
    6bb8:	8b000042 	add	x2, x2, x0
    6bbc:	39400040 	ldrb	w0, [x2]
    6bc0:	7100041f 	cmp	w0, #0x1
    6bc4:	540000c1 	b.ne	6bdc <fwp_caps37+0xac>  // b.any
    6bc8:	aa1303e0 	mov	x0, x19
    6bcc:	f9400bf3 	ldr	x19, [sp, #16]
    6bd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bd4:	17fff7c7 	b	4af0 <fwp_mem_free>
    6bd8:	34fffbe1 	cbz	w1, 6b54 <fwp_caps37+0x24>
    6bdc:	f9400bf3 	ldr	x19, [sp, #16]
    6be0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6be4:	d65f03c0 	ret
    6be8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6bec:	91174042 	add	x2, x2, #0x5d0
    6bf0:	f949d843 	ldr	x3, [x2, #5040]
    6bf4:	f949ec41 	ldr	x1, [x2, #5080]
    6bf8:	cb030000 	sub	x0, x0, x3
    6bfc:	eb01401f 	cmp	x0, x1, lsl #16
    6c00:	54fffee2 	b.cs	6bdc <fwp_caps37+0xac>  // b.hs, b.nlast
    6c04:	d350fc01 	lsr	x1, x0, #16
    6c08:	f949fc44 	ldr	x4, [x2, #5112]
    6c0c:	8b010821 	add	x1, x1, x1, lsl #2
    6c10:	d37df021 	lsl	x1, x1, #3
    6c14:	8b010083 	add	x3, x4, x1
    6c18:	f9401062 	ldr	x2, [x3, #32]
    6c1c:	b4fffe02 	cbz	x2, 6bdc <fwp_caps37+0xac>
    6c20:	38616881 	ldrb	w1, [x4, x1]
    6c24:	7100083f 	cmp	w1, #0x2
    6c28:	54000280 	b.eq	6c78 <fwp_caps37+0x148>  // b.none
    6c2c:	7100043f 	cmp	w1, #0x1
    6c30:	54fffd61 	b.ne	6bdc <fwp_caps37+0xac>  // b.any
    6c34:	92403c01 	and	x1, x0, #0xffff
    6c38:	29430064 	ldp	w4, w0, [x3, #24]
    6c3c:	9b047c21 	mul	x1, x1, x4
    6c40:	d360fc21 	lsr	x1, x1, #32
    6c44:	eb00003f 	cmp	x1, x0
    6c48:	54fffca2 	b.cs	6bdc <fwp_caps37+0xac>  // b.hs, b.nlast
    6c4c:	8b010042 	add	x2, x2, x1
    6c50:	39400040 	ldrb	w0, [x2]
    6c54:	34fffc40 	cbz	w0, 6bdc <fwp_caps37+0xac>
    6c58:	7103f41f 	cmp	w0, #0xfd
    6c5c:	54000148 	b.hi	6c84 <fwp_caps37+0x154>  // b.pmore
    6c60:	11000400 	add	w0, w0, #0x1
    6c64:	39000040 	strb	w0, [x2]
    6c68:	17ffffdd 	b	6bdc <fwp_caps37+0xac>
    6c6c:	72003c1f 	tst	w0, #0xffff
    6c70:	54fffb61 	b.ne	6bdc <fwp_caps37+0xac>  // b.any
    6c74:	17ffffd2 	b	6bbc <fwp_caps37+0x8c>
    6c78:	72003c1f 	tst	w0, #0xffff
    6c7c:	54fffb01 	b.ne	6bdc <fwp_caps37+0xac>  // b.any
    6c80:	17fffff4 	b	6c50 <fwp_caps37+0x120>
    6c84:	f9400bf3 	ldr	x19, [sp, #16]
    6c88:	aa0203e0 	mov	x0, x2
    6c8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c90:	17fff6b1 	b	4754 <fwp_rc_wide_dup>

0000000000006c94 <f37>:
    6c94:	d10203ff 	sub	sp, sp, #0x80
    6c98:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6c9c:	f947f421 	ldr	x1, [x1, #4072]
    6ca0:	a9027bfd 	stp	x29, x30, [sp, #32]
    6ca4:	910083fd 	add	x29, sp, #0x20
    6ca8:	a9045bf5 	stp	x21, x22, [sp, #64]
    6cac:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    6cb0:	911742c3 	add	x3, x22, #0x5d0
    6cb4:	a90353f3 	stp	x19, x20, [sp, #48]
    6cb8:	a90563f7 	stp	x23, x24, [sp, #80]
    6cbc:	aa0003f8 	mov	x24, x0
    6cc0:	a9066bf9 	stp	x25, x26, [sp, #96]
    6cc4:	f949ec62 	ldr	x2, [x3, #5080]
    6cc8:	f9400024 	ldr	x4, [x1]
    6ccc:	f9000fe4 	str	x4, [sp, #24]
    6cd0:	d2800004 	mov	x4, #0x0                   	// #0
    6cd4:	f949d861 	ldr	x1, [x3, #5040]
    6cd8:	d370bc42 	lsl	x2, x2, #16
    6cdc:	b40017c0 	cbz	x0, 6fd4 <f37+0x340>
    6ce0:	f9400819 	ldr	x25, [x0, #16]
    6ce4:	cb010321 	sub	x1, x25, x1
    6ce8:	eb02003f 	cmp	x1, x2
    6cec:	54000362 	b.cs	6d58 <f37+0xc4>  // b.hs, b.nlast
    6cf0:	f949fc60 	ldr	x0, [x3, #5112]
    6cf4:	d350fc22 	lsr	x2, x1, #16
    6cf8:	8b020842 	add	x2, x2, x2, lsl #2
    6cfc:	8b020c02 	add	x2, x0, x2, lsl #3
    6d00:	f9401040 	ldr	x0, [x2, #32]
    6d04:	b40002a0 	cbz	x0, 6d58 <f37+0xc4>
    6d08:	39400043 	ldrb	w3, [x2]
    6d0c:	7100087f 	cmp	w3, #0x2
    6d10:	540015c0 	b.eq	6fc8 <f37+0x334>  // b.none
    6d14:	7100047f 	cmp	w3, #0x1
    6d18:	540001c1 	b.ne	6d50 <f37+0xbc>  // b.any
    6d1c:	29430843 	ldp	w3, w2, [x2, #24]
    6d20:	92403c21 	and	x1, x1, #0xffff
    6d24:	9b037c21 	mul	x1, x1, x3
    6d28:	d360fc21 	lsr	x1, x1, #32
    6d2c:	eb02003f 	cmp	x1, x2
    6d30:	54000102 	b.cs	6d50 <f37+0xbc>  // b.hs, b.nlast
    6d34:	8b010000 	add	x0, x0, x1
    6d38:	39400001 	ldrb	w1, [x0]
    6d3c:	340000a1 	cbz	w1, 6d50 <f37+0xbc>
    6d40:	7103f43f 	cmp	w1, #0xfd
    6d44:	54001868 	b.hi	7050 <f37+0x3bc>  // b.pmore
    6d48:	11000421 	add	w1, w1, #0x1
    6d4c:	39000001 	strb	w1, [x0]
    6d50:	d2800000 	mov	x0, #0x0                   	// #0
    6d54:	b40000d8 	cbz	x24, 6d6c <f37+0xd8>
    6d58:	aa1803e1 	mov	x1, x24
    6d5c:	d2800000 	mov	x0, #0x0                   	// #0
    6d60:	f9400821 	ldr	x1, [x1, #16]
    6d64:	91000400 	add	x0, x0, #0x1
    6d68:	b5ffffc1 	cbnz	x1, 6d60 <f37+0xcc>
    6d6c:	b40013b9 	cbz	x25, 6fe0 <f37+0x34c>
    6d70:	aa1903e1 	mov	x1, x25
    6d74:	d2800002 	mov	x2, #0x0                   	// #0
    6d78:	f9400821 	ldr	x1, [x1, #16]
    6d7c:	91000442 	add	x2, x2, #0x1
    6d80:	b5ffffc1 	cbnz	x1, 6d78 <f37+0xe4>
    6d84:	eb00005f 	cmp	x2, x0
    6d88:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6d8c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    6d90:	eb01035f 	cmp	x26, x1
    6d94:	54001668 	b.hi	7060 <f37+0x3cc>  // b.pmore
    6d98:	d37ffb53 	lsl	x19, x26, #1
    6d9c:	52800041 	mov	w1, #0x2                   	// #2
    6da0:	91000660 	add	x0, x19, #0x1
    6da4:	d37df000 	lsl	x0, x0, #3
    6da8:	97fff872 	bl	4f70 <fwp_heap_alloc>
    6dac:	aa0003f7 	mov	x23, x0
    6db0:	911742c1 	add	x1, x22, #0x5d0
    6db4:	aa0103e0 	mov	x0, x1
    6db8:	f90002f3 	str	x19, [x23]
    6dbc:	f949d821 	ldr	x1, [x1, #5040]
    6dc0:	f949ec00 	ldr	x0, [x0, #5080]
    6dc4:	cb0102e1 	sub	x1, x23, x1
    6dc8:	eb00403f 	cmp	x1, x0, lsl #16
    6dcc:	54000342 	b.cs	6e34 <f37+0x1a0>  // b.hs, b.nlast
    6dd0:	911742c2 	add	x2, x22, #0x5d0
    6dd4:	d350fc20 	lsr	x0, x1, #16
    6dd8:	8b000800 	add	x0, x0, x0, lsl #2
    6ddc:	f949fc43 	ldr	x3, [x2, #5112]
    6de0:	d37df002 	lsl	x2, x0, #3
    6de4:	8b020060 	add	x0, x3, x2
    6de8:	f9401013 	ldr	x19, [x0, #32]
    6dec:	b4000253 	cbz	x19, 6e34 <f37+0x1a0>
    6df0:	38626862 	ldrb	w2, [x3, x2]
    6df4:	7100085f 	cmp	w2, #0x2
    6df8:	54000e20 	b.eq	6fbc <f37+0x328>  // b.none
    6dfc:	7100045f 	cmp	w2, #0x1
    6e00:	540001a1 	b.ne	6e34 <f37+0x1a0>  // b.any
    6e04:	29430002 	ldp	w2, w0, [x0, #24]
    6e08:	92403c21 	and	x1, x1, #0xffff
    6e0c:	9b027c21 	mul	x1, x1, x2
    6e10:	d360fc21 	lsr	x1, x1, #32
    6e14:	eb00003f 	cmp	x1, x0
    6e18:	540000e2 	b.cs	6e34 <f37+0x1a0>  // b.hs, b.nlast
    6e1c:	8b010273 	add	x19, x19, x1
    6e20:	39400260 	ldrb	w0, [x19]
    6e24:	7103fc1f 	cmp	w0, #0xff
    6e28:	54000f80 	b.eq	7018 <f37+0x384>  // b.none
    6e2c:	52800020 	mov	w0, #0x1                   	// #1
    6e30:	39000260 	strb	w0, [x19]
    6e34:	b400025a 	cbz	x26, 6e7c <f37+0x1e8>
    6e38:	8b1a12fa 	add	x26, x23, x26, lsl #4
    6e3c:	aa1703f3 	mov	x19, x23
    6e40:	aa1803f5 	mov	x21, x24
    6e44:	aa1903f4 	mov	x20, x25
    6e48:	f9400683 	ldr	x3, [x20, #8]
    6e4c:	f94006a2 	ldr	x2, [x21, #8]
    6e50:	f9400861 	ldr	x1, [x3, #16]
    6e54:	f9400840 	ldr	x0, [x2, #16]
    6e58:	fd400461 	ldr	d1, [x3, #8]
    6e5c:	fd400440 	ldr	d0, [x2, #8]
    6e60:	97fff984 	bl	5470 <w120>
    6e64:	f9000660 	str	x0, [x19, #8]
    6e68:	f8010e61 	str	x1, [x19, #16]!
    6e6c:	f9400a94 	ldr	x20, [x20, #16]
    6e70:	f9400ab5 	ldr	x21, [x21, #16]
    6e74:	eb13035f 	cmp	x26, x19
    6e78:	54fffe81 	b.ne	6e48 <f37+0x1b4>  // b.any
    6e7c:	aa1903e0 	mov	x0, x25
    6e80:	97fffcc4 	bl	6190 <fwp_drop4>
    6e84:	aa1803e0 	mov	x0, x24
    6e88:	97fffcc2 	bl	6190 <fwp_drop4>
    6e8c:	f94002f5 	ldr	x21, [x23]
    6e90:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6e94:	b4000275 	cbz	x21, 6ee0 <f37+0x24c>
    6e98:	fd003be8 	str	d8, [sp, #112]
    6e9c:	2f00e408 	movi	d8, #0x0
    6ea0:	910022f9 	add	x25, x23, #0x8
    6ea4:	910042f8 	add	x24, x23, #0x10
    6ea8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    6eac:	d2800013 	mov	x19, #0x0                   	// #0
    6eb0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    6eb4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6eb8:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    6ebc:	aa0303e1 	mov	x1, x3
    6ec0:	1e602908 	fadd	d8, d8, d0
    6ec4:	91000a73 	add	x19, x19, #0x2
    6ec8:	97fff8b7 	bl	51a4 <fwp_p_ad_push>
    6ecc:	aa0003f4 	mov	x20, x0
    6ed0:	eb1302bf 	cmp	x21, x19
    6ed4:	54fffee8 	b.hi	6eb0 <f37+0x21c>  // b.pmore
    6ed8:	9e660115 	fmov	x21, d8
    6edc:	fd403be8 	ldr	d8, [sp, #112]
    6ee0:	911742d6 	add	x22, x22, #0x5d0
    6ee4:	aa1703e0 	mov	x0, x23
    6ee8:	97fffe46 	bl	6800 <fwp_drop10>
    6eec:	a900d3f5 	stp	x21, x20, [sp, #8]
    6ef0:	910023e1 	add	x1, sp, #0x8
    6ef4:	52800000 	mov	w0, #0x0                   	// #0
    6ef8:	97fff863 	bl	5084 <fwp_data.part.0.constprop.0>
    6efc:	f949dac1 	ldr	x1, [x22, #5040]
    6f00:	aa0003f3 	mov	x19, x0
    6f04:	f949eec0 	ldr	x0, [x22, #5080]
    6f08:	cb010261 	sub	x1, x19, x1
    6f0c:	eb00403f 	cmp	x1, x0, lsl #16
    6f10:	54000322 	b.cs	6f74 <f37+0x2e0>  // b.hs, b.nlast
    6f14:	d350fc22 	lsr	x2, x1, #16
    6f18:	f949fec3 	ldr	x3, [x22, #5112]
    6f1c:	8b020842 	add	x2, x2, x2, lsl #2
    6f20:	d37df042 	lsl	x2, x2, #3
    6f24:	8b020060 	add	x0, x3, x2
    6f28:	f9401014 	ldr	x20, [x0, #32]
    6f2c:	b4000254 	cbz	x20, 6f74 <f37+0x2e0>
    6f30:	38626862 	ldrb	w2, [x3, x2]
    6f34:	7100085f 	cmp	w2, #0x2
    6f38:	540003c0 	b.eq	6fb0 <f37+0x31c>  // b.none
    6f3c:	7100045f 	cmp	w2, #0x1
    6f40:	540001a1 	b.ne	6f74 <f37+0x2e0>  // b.any
    6f44:	29430002 	ldp	w2, w0, [x0, #24]
    6f48:	92403c21 	and	x1, x1, #0xffff
    6f4c:	9b027c21 	mul	x1, x1, x2
    6f50:	d360fc21 	lsr	x1, x1, #32
    6f54:	eb00003f 	cmp	x1, x0
    6f58:	540000e2 	b.cs	6f74 <f37+0x2e0>  // b.hs, b.nlast
    6f5c:	8b010294 	add	x20, x20, x1
    6f60:	39400280 	ldrb	w0, [x20]
    6f64:	7103fc1f 	cmp	w0, #0xff
    6f68:	540005e0 	b.eq	7024 <f37+0x390>  // b.none
    6f6c:	52800020 	mov	w0, #0x1                   	// #1
    6f70:	39000280 	strb	w0, [x20]
    6f74:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6f78:	f947f400 	ldr	x0, [x0, #4072]
    6f7c:	f9400fe2 	ldr	x2, [sp, #24]
    6f80:	f9400001 	ldr	x1, [x0]
    6f84:	eb010042 	subs	x2, x2, x1
    6f88:	d2800001 	mov	x1, #0x0                   	// #0
    6f8c:	54000721 	b.ne	7070 <f37+0x3dc>  // b.any
    6f90:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6f94:	aa1303e0 	mov	x0, x19
    6f98:	a94353f3 	ldp	x19, x20, [sp, #48]
    6f9c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6fa0:	a94563f7 	ldp	x23, x24, [sp, #80]
    6fa4:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6fa8:	910203ff 	add	sp, sp, #0x80
    6fac:	d65f03c0 	ret
    6fb0:	72003c3f 	tst	w1, #0xffff
    6fb4:	54fffe01 	b.ne	6f74 <f37+0x2e0>  // b.any
    6fb8:	17ffffea 	b	6f60 <f37+0x2cc>
    6fbc:	72003c3f 	tst	w1, #0xffff
    6fc0:	54fff3a1 	b.ne	6e34 <f37+0x1a0>  // b.any
    6fc4:	17ffff97 	b	6e20 <f37+0x18c>
    6fc8:	72003c3f 	tst	w1, #0xffff
    6fcc:	54ffec21 	b.ne	6d50 <f37+0xbc>  // b.any
    6fd0:	17ffff5a 	b	6d38 <f37+0xa4>
    6fd4:	cb0103e1 	neg	x1, x1
    6fd8:	eb02003f 	cmp	x1, x2
    6fdc:	540002a3 	b.cc	7030 <f37+0x39c>  // b.lo, b.ul, b.last
    6fe0:	52800041 	mov	w1, #0x2                   	// #2
    6fe4:	d2800100 	mov	x0, #0x8                   	// #8
    6fe8:	97fff7e2 	bl	4f70 <fwp_heap_alloc>
    6fec:	aa0003f7 	mov	x23, x0
    6ff0:	911742c0 	add	x0, x22, #0x5d0
    6ff4:	f90002ff 	str	xzr, [x23]
    6ff8:	f949d801 	ldr	x1, [x0, #5040]
    6ffc:	f949ec00 	ldr	x0, [x0, #5080]
    7000:	cb0102e1 	sub	x1, x23, x1
    7004:	eb00403f 	cmp	x1, x0, lsl #16
    7008:	54000282 	b.cs	7058 <f37+0x3c4>  // b.hs, b.nlast
    700c:	d280001a 	mov	x26, #0x0                   	// #0
    7010:	d2800019 	mov	x25, #0x0                   	// #0
    7014:	17ffff6f 	b	6dd0 <f37+0x13c>
    7018:	aa1303e0 	mov	x0, x19
    701c:	97fff615 	bl	4870 <fwp_rc_forget_slot>
    7020:	17ffff83 	b	6e2c <f37+0x198>
    7024:	aa1403e0 	mov	x0, x20
    7028:	97fff612 	bl	4870 <fwp_rc_forget_slot>
    702c:	17ffffd0 	b	6f6c <f37+0x2d8>
    7030:	f949fc62 	ldr	x2, [x3, #5112]
    7034:	d350fc20 	lsr	x0, x1, #16
    7038:	8b000800 	add	x0, x0, x0, lsl #2
    703c:	8b000c42 	add	x2, x2, x0, lsl #3
    7040:	f9401040 	ldr	x0, [x2, #32]
    7044:	b4fffce0 	cbz	x0, 6fe0 <f37+0x34c>
    7048:	d2800019 	mov	x25, #0x0                   	// #0
    704c:	17ffff2f 	b	6d08 <f37+0x74>
    7050:	97fff5c1 	bl	4754 <fwp_rc_wide_dup>
    7054:	17ffff3f 	b	6d50 <f37+0xbc>
    7058:	d2800019 	mov	x25, #0x0                   	// #0
    705c:	17ffff88 	b	6e7c <f37+0x1e8>
    7060:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    7064:	910f0000 	add	x0, x0, #0x3c0
    7068:	fd003be8 	str	d8, [sp, #112]
    706c:	97fff205 	bl	3880 <fwp_trap>
    7070:	fd003be8 	str	d8, [sp, #112]
    7074:	97ffee27 	bl	2910 <__stack_chk_fail@plt>
    7078:	d503201f 	nop
    707c:	d503201f 	nop

0000000000007080 <fwp_owned_entry37>:
    7080:	f9400000 	ldr	x0, [x0]
    7084:	17ffff04 	b	6c94 <f37>
    7088:	d503201f 	nop
    708c:	d503201f 	nop

0000000000007090 <e37>:
    7090:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7094:	910003fd 	mov	x29, sp
    7098:	f9000bf3 	str	x19, [sp, #16]
    709c:	f9400013 	ldr	x19, [x0]
    70a0:	aa1303e0 	mov	x0, x19
    70a4:	97fff937 	bl	5580 <fwp_rc_share>
    70a8:	aa1303e0 	mov	x0, x19
    70ac:	97fffefa 	bl	6c94 <f37>
    70b0:	aa0003f3 	mov	x19, x0
    70b4:	97fff933 	bl	5580 <fwp_rc_share>
    70b8:	aa1303e0 	mov	x0, x19
    70bc:	f9400bf3 	ldr	x19, [sp, #16]
    70c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70c4:	d65f03c0 	ret
    70c8:	d503201f 	nop
    70cc:	d503201f 	nop

00000000000070d0 <fwp_write>:
    70d0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    70d4:	910003fd 	mov	x29, sp
    70d8:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    70dc:	f947f484 	ldr	x4, [x4, #4072]
    70e0:	a90153f3 	stp	x19, x20, [sp, #16]
    70e4:	d10943ff 	sub	sp, sp, #0x250
    70e8:	b9400045 	ldr	w5, [x2]
    70ec:	aa0003f4 	mov	x20, x0
    70f0:	f9400080 	ldr	x0, [x4]
    70f4:	f90127e0 	str	x0, [sp, #584]
    70f8:	d2800000 	mov	x0, #0x0                   	// #0
    70fc:	710064bf 	cmp	w5, #0x19
    7100:	54000408 	b.hi	7180 <fwp_write+0xb0>  // b.pmore
    7104:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    7108:	aa0103f3 	mov	x19, x1
    710c:	91324000 	add	x0, x0, #0xc90
    7110:	f9013bf5 	str	x21, [sp, #624]
    7114:	f9013ff6 	str	x22, [sp, #632]
    7118:	f90153fb 	str	x27, [sp, #672]
    711c:	f90157fc 	str	x28, [sp, #680]
    7120:	aa0203fc 	mov	x28, x2
    7124:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7128:	10000061 	adr	x1, 7134 <fwp_write+0x64>
    712c:	8b20a820 	add	x0, x1, w0, sxth #2
    7130:	d61f0000 	br	x0
    7134:	910123e0 	add	x0, sp, #0x48
    7138:	aa1303e5 	mov	x5, x19
    713c:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0xe0>
    7140:	aa0003f3 	mov	x19, x0
    7144:	91102084 	add	x4, x4, #0x408
    7148:	d2804003 	mov	x3, #0x200                 	// #512
    714c:	aa0303e1 	mov	x1, x3
    7150:	52800042 	mov	w2, #0x2                   	// #2
    7154:	97ffedcb 	bl	2880 <__snprintf_chk@plt>
    7158:	aa1303e0 	mov	x0, x19
    715c:	97ffed91 	bl	27a0 <strlen@plt>
    7160:	aa1303e1 	mov	x1, x19
    7164:	aa0003e2 	mov	x2, x0
    7168:	aa1403e0 	mov	x0, x20
    716c:	97fff129 	bl	3610 <buf_put>
    7170:	f9413bf5 	ldr	x21, [sp, #624]
    7174:	f9413ff6 	ldr	x22, [sp, #632]
    7178:	f94153fb 	ldr	x27, [sp, #672]
    717c:	f94157fc 	ldr	x28, [sp, #680]
    7180:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7184:	f947f400 	ldr	x0, [x0, #4072]
    7188:	f94127e2 	ldr	x2, [sp, #584]
    718c:	f9400001 	ldr	x1, [x0]
    7190:	eb010042 	subs	x2, x2, x1
    7194:	d2800001 	mov	x1, #0x0                   	// #0
    7198:	540077c1 	b.ne	8090 <fwp_write+0xfc0>  // b.any
    719c:	910943ff 	add	sp, sp, #0x250
    71a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    71a4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    71a8:	d65f03c0 	ret
    71ac:	910123e0 	add	x0, sp, #0x48
    71b0:	aa1303e5 	mov	x5, x19
    71b4:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0xe0>
    71b8:	aa0003f3 	mov	x19, x0
    71bc:	91100084 	add	x4, x4, #0x400
    71c0:	d2804003 	mov	x3, #0x200                 	// #512
    71c4:	17ffffe2 	b	714c <fwp_write+0x7c>
    71c8:	71004cbf 	cmp	w5, #0x13
    71cc:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    71d0:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    71d4:	910fc000 	add	x0, x0, #0x3f0
    71d8:	910fe021 	add	x1, x1, #0x3f8
    71dc:	d2800082 	mov	x2, #0x4                   	// #4
    71e0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    71e4:	aa1403e0 	mov	x0, x20
    71e8:	f90143f7 	str	x23, [sp, #640]
    71ec:	d2800016 	mov	x22, #0x0                   	// #0
    71f0:	f90147f8 	str	x24, [sp, #648]
    71f4:	97fff107 	bl	3610 <buf_put>
    71f8:	f9400260 	ldr	x0, [x19]
    71fc:	d0000037 	adrp	x23, d000 <_IO_stdin_used+0xe0>
    7200:	d2800015 	mov	x21, #0x0                   	// #0
    7204:	9111e2f7 	add	x23, x23, #0x478
    7208:	b40047a0 	cbz	x0, 7afc <fwp_write+0xa2c>
    720c:	b9400380 	ldr	w0, [x28]
    7210:	52800003 	mov	w3, #0x0                   	// #0
    7214:	f9401f82 	ldr	x2, [x28, #56]
    7218:	71004c1f 	cmp	w0, #0x13
    721c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7220:	aa1403e0 	mov	x0, x20
    7224:	8b010e61 	add	x1, x19, x1, lsl #3
    7228:	f9400421 	ldr	x1, [x1, #8]
    722c:	97ffffa9 	bl	70d0 <fwp_write>
    7230:	b9400380 	ldr	w0, [x28]
    7234:	7100481f 	cmp	w0, #0x12
    7238:	54004b40 	b.eq	7ba0 <fwp_write+0xad0>  // b.none
    723c:	f9400260 	ldr	x0, [x19]
    7240:	910006b5 	add	x21, x21, #0x1
    7244:	91000ad6 	add	x22, x22, #0x2
    7248:	eb15001f 	cmp	x0, x21
    724c:	54004589 	b.ls	7afc <fwp_write+0xa2c>  // b.plast
    7250:	aa1703e1 	mov	x1, x23
    7254:	aa1403e0 	mov	x0, x20
    7258:	d2800042 	mov	x2, #0x2                   	// #2
    725c:	97fff0ed 	bl	3610 <buf_put>
    7260:	17ffffeb 	b	720c <fwp_write+0x13c>
    7264:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7268:	9110c021 	add	x1, x1, #0x430
    726c:	d28000c2 	mov	x2, #0x6                   	// #6
    7270:	aa1403e0 	mov	x0, x20
    7274:	91004273 	add	x19, x19, #0x10
    7278:	97fff0e6 	bl	3610 <buf_put>
    727c:	aa1303e0 	mov	x0, x19
    7280:	97ffed48 	bl	27a0 <strlen@plt>
    7284:	aa1303e1 	mov	x1, x19
    7288:	aa0003e2 	mov	x2, x0
    728c:	aa1403e0 	mov	x0, x20
    7290:	97fff0e0 	bl	3610 <buf_put>
    7294:	528007c3 	mov	w3, #0x3e                  	// #62
    7298:	aa1403e0 	mov	x0, x20
    729c:	91001fe1 	add	x1, sp, #0x7
    72a0:	d2800022 	mov	x2, #0x1                   	// #1
    72a4:	39001fe3 	strb	w3, [sp, #7]
    72a8:	17ffffb1 	b	716c <fwp_write+0x9c>
    72ac:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    72b0:	f947f400 	ldr	x0, [x0, #4072]
    72b4:	f94127e2 	ldr	x2, [sp, #584]
    72b8:	f9400001 	ldr	x1, [x0]
    72bc:	eb010042 	subs	x2, x2, x1
    72c0:	d2800001 	mov	x1, #0x0                   	// #0
    72c4:	540034e1 	b.ne	7960 <fwp_write+0x890>  // b.any
    72c8:	f9413bf5 	ldr	x21, [sp, #624]
    72cc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    72d0:	f9413ff6 	ldr	x22, [sp, #632]
    72d4:	aa1403e0 	mov	x0, x20
    72d8:	91104021 	add	x1, x1, #0x410
    72dc:	d2800142 	mov	x2, #0xa                   	// #10
    72e0:	f94153fb 	ldr	x27, [sp, #672]
    72e4:	f94157fc 	ldr	x28, [sp, #680]
    72e8:	910943ff 	add	sp, sp, #0x250
    72ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    72f0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    72f4:	17fff0c7 	b	3610 <buf_put>
    72f8:	f9400456 	ldr	x22, [x2, #8]
    72fc:	f90143f7 	str	x23, [sp, #640]
    7300:	f90147f8 	str	x24, [sp, #648]
    7304:	b4005b16 	cbz	x22, 7e64 <fwp_write+0xd94>
    7308:	aa1603e0 	mov	x0, x22
    730c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7310:	91124021 	add	x1, x1, #0x490
    7314:	97ffed9f 	bl	2990 <strcmp@plt>
    7318:	2a0003f5 	mov	w21, w0
    731c:	34005fe0 	cbz	w0, 7f18 <fwp_write+0xe48>
    7320:	aa1603e0 	mov	x0, x22
    7324:	97ffed1f 	bl	27a0 <strlen@plt>
    7328:	aa1603e1 	mov	x1, x22
    732c:	aa0003e2 	mov	x2, x0
    7330:	aa1403e0 	mov	x0, x20
    7334:	97fff0b7 	bl	3610 <buf_put>
    7338:	52800403 	mov	w3, #0x20                  	// #32
    733c:	91001ff5 	add	x21, sp, #0x7
    7340:	aa1503e1 	mov	x1, x21
    7344:	aa1403e0 	mov	x0, x20
    7348:	d2800022 	mov	x2, #0x1                   	// #1
    734c:	39001fe3 	strb	w3, [sp, #7]
    7350:	97fff0b0 	bl	3610 <buf_put>
    7354:	52800f63 	mov	w3, #0x7b                  	// #123
    7358:	aa1403e0 	mov	x0, x20
    735c:	aa1503e1 	mov	x1, x21
    7360:	d2800022 	mov	x2, #0x1                   	// #1
    7364:	39001fe3 	strb	w3, [sp, #7]
    7368:	97fff0aa 	bl	3610 <buf_put>
    736c:	b9401380 	ldr	w0, [x28, #16]
    7370:	52800018 	mov	w24, #0x0                   	// #0
    7374:	7100001f 	cmp	w0, #0x0
    7378:	54003aad 	b.le	7acc <fwp_write+0x9fc>
    737c:	f9014bf9 	str	x25, [sp, #656]
    7380:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0xe0>
    7384:	9112e339 	add	x25, x25, #0x4b8
    7388:	f9014ffa 	str	x26, [sp, #664]
    738c:	d000003a 	adrp	x26, d000 <_IO_stdin_used+0xe0>
    7390:	9111e35a 	add	x26, x26, #0x478
    7394:	91002276 	add	x22, x19, #0x8
    7398:	d2800013 	mov	x19, #0x0                   	// #0
    739c:	b5003e93 	cbnz	x19, 7b6c <fwp_write+0xa9c>
    73a0:	d37df277 	lsl	x23, x19, #3
    73a4:	34003cb8 	cbz	w24, 7b38 <fwp_write+0xa68>
    73a8:	f9401382 	ldr	x2, [x28, #32]
    73ac:	aa1403e0 	mov	x0, x20
    73b0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    73b4:	52800003 	mov	w3, #0x0                   	// #0
    73b8:	f8776842 	ldr	x2, [x2, x23]
    73bc:	91000673 	add	x19, x19, #0x1
    73c0:	97ffff44 	bl	70d0 <fwp_write>
    73c4:	b9401380 	ldr	w0, [x28, #16]
    73c8:	6b13001f 	cmp	w0, w19
    73cc:	54fffe8c 	b.gt	739c <fwp_write+0x2cc>
    73d0:	f9414bf9 	ldr	x25, [sp, #656]
    73d4:	f9414ffa 	ldr	x26, [sp, #664]
    73d8:	340037b8 	cbz	w24, 7acc <fwp_write+0x9fc>
    73dc:	52800523 	mov	w3, #0x29                  	// #41
    73e0:	aa1503e1 	mov	x1, x21
    73e4:	aa1403e0 	mov	x0, x20
    73e8:	d2800022 	mov	x2, #0x1                   	// #1
    73ec:	39001fe3 	strb	w3, [sp, #7]
    73f0:	97fff088 	bl	3610 <buf_put>
    73f4:	f9413bf5 	ldr	x21, [sp, #624]
    73f8:	f9413ff6 	ldr	x22, [sp, #632]
    73fc:	f94143f7 	ldr	x23, [sp, #640]
    7400:	f94147f8 	ldr	x24, [sp, #648]
    7404:	f94153fb 	ldr	x27, [sp, #672]
    7408:	f94157fc 	ldr	x28, [sp, #680]
    740c:	17ffff5d 	b	7180 <fwp_write+0xb0>
    7410:	b9404855 	ldr	w21, [x2, #72]
    7414:	aa1403e0 	mov	x0, x20
    7418:	93407eb6 	sxtw	x22, w21
    741c:	91000ac1 	add	x1, x22, #0x2
    7420:	97fff049 	bl	3544 <buf_grow>
    7424:	a9400281 	ldp	x1, x0, [x20]
    7428:	528e8603 	mov	w3, #0x7430                	// #29744
    742c:	78206823 	strh	w3, [x1, x0]
    7430:	8b000022 	add	x2, x1, x0
    7434:	710002bf 	cmp	w21, #0x0
    7438:	540036cd 	b.le	7b10 <fwp_write+0xa40>
    743c:	110006a3 	add	w3, w21, #0x1
    7440:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7444:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7448:	91000449 	add	x9, x2, #0x1
    744c:	8b23c043 	add	x3, x2, w3, sxtw
    7450:	f28aaac6 	movk	x6, #0x5556
    7454:	f2955568 	movk	x8, #0xaaab
    7458:	1400000d 	b	748c <fwp_write+0x3bc>
    745c:	d2800021 	mov	x1, #0x1                   	// #1
    7460:	528005a5 	mov	w5, #0x2d                  	// #45
    7464:	f100001f 	cmp	x0, #0x0
    7468:	9b467e60 	smulh	x0, x19, x6
    746c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7470:	381ff465 	strb	w5, [x3], #-1
    7474:	cb040000 	sub	x0, x0, x4
    7478:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    747c:	cb020000 	sub	x0, x0, x2
    7480:	8b010013 	add	x19, x0, x1
    7484:	eb03013f 	cmp	x9, x3
    7488:	54003440 	b.eq	7b10 <fwp_write+0xa40>  // b.none
    748c:	9b467e60 	smulh	x0, x19, x6
    7490:	937ffe64 	asr	x4, x19, #63
    7494:	52800605 	mov	w5, #0x30                  	// #48
    7498:	cb040000 	sub	x0, x0, x4
    749c:	8b000400 	add	x0, x0, x0, lsl #1
    74a0:	cb000260 	sub	x0, x19, x0
    74a4:	91000c01 	add	x1, x0, #0x3
    74a8:	9bc87c22 	umulh	x2, x1, x8
    74ac:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    74b0:	8b4204e2 	add	x2, x7, x2, lsr #1
    74b4:	eb020021 	subs	x1, x1, x2
    74b8:	54fffd60 	b.eq	7464 <fwp_write+0x394>  // b.none
    74bc:	f100043f 	cmp	x1, #0x1
    74c0:	54fffce1 	b.ne	745c <fwp_write+0x38c>  // b.any
    74c4:	d2800001 	mov	x1, #0x0                   	// #0
    74c8:	52800565 	mov	w5, #0x2b                  	// #43
    74cc:	17ffffe6 	b	7464 <fwp_write+0x394>
    74d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    74d4:	f947f400 	ldr	x0, [x0, #4072]
    74d8:	f94127e2 	ldr	x2, [sp, #584]
    74dc:	f9400001 	ldr	x1, [x0]
    74e0:	eb010042 	subs	x2, x2, x1
    74e4:	d2800001 	mov	x1, #0x0                   	// #0
    74e8:	540023c1 	b.ne	7960 <fwp_write+0x890>  // b.any
    74ec:	f9413bf5 	ldr	x21, [sp, #624]
    74f0:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    74f4:	f9413ff6 	ldr	x22, [sp, #632]
    74f8:	aa1403e0 	mov	x0, x20
    74fc:	91108021 	add	x1, x1, #0x420
    7500:	d2800102 	mov	x2, #0x8                   	// #8
    7504:	17ffff77 	b	72e0 <fwp_write+0x210>
    7508:	aa1403e0 	mov	x0, x20
    750c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7510:	d28000c2 	mov	x2, #0x6                   	// #6
    7514:	91120021 	add	x1, x1, #0x480
    7518:	97fff03e 	bl	3610 <buf_put>
    751c:	d2800015 	mov	x21, #0x0                   	// #0
    7520:	f9400263 	ldr	x3, [x19]
    7524:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7528:	54002c60 	b.eq	7ab4 <fwp_write+0x9e4>  // b.none
    752c:	f9401f82 	ldr	x2, [x28, #56]
    7530:	f90143f7 	str	x23, [sp, #640]
    7534:	f90147f8 	str	x24, [sp, #648]
    7538:	d2800857 	mov	x23, #0x42                  	// #66
    753c:	f9014bf9 	str	x25, [sp, #656]
    7540:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0xe0>
    7544:	f9014ffa 	str	x26, [sp, #664]
    7548:	9111e2d6 	add	x22, x22, #0x478
    754c:	d2800038 	mov	x24, #0x1                   	// #1
    7550:	f2a18017 	movk	x23, #0xc00, lsl #16
    7554:	d2809099 	mov	x25, #0x484                 	// #1156
    7558:	b40004a2 	cbz	x2, 75ec <fwp_write+0x51c>
    755c:	b9400040 	ldr	w0, [x2]
    7560:	7100701f 	cmp	w0, #0x1c
    7564:	540042c0 	b.eq	7dbc <fwp_write+0xcec>  // b.none
    7568:	71006c1f 	cmp	w0, #0x1b
    756c:	54000408 	b.hi	75ec <fwp_write+0x51c>  // b.pmore
    7570:	9ac02301 	lsl	x1, x24, x0
    7574:	ea17003f 	tst	x1, x23
    7578:	540036a1 	b.ne	7c4c <fwp_write+0xb7c>  // b.any
    757c:	ea19003f 	tst	x1, x25
    7580:	54003521 	b.ne	7c24 <fwp_write+0xb54>  // b.any
    7584:	d2800424 	mov	x4, #0x21                  	// #33
    7588:	ea04003f 	tst	x1, x4
    758c:	54000300 	b.eq	75ec <fwp_write+0x51c>  // b.none
    7590:	b7f849c3 	tbnz	x3, #63, 7ec8 <fwp_write+0xdf8>
    7594:	91002261 	add	x1, x19, #0x8
    7598:	8b150021 	add	x1, x1, x21
    759c:	39400021 	ldrb	w1, [x1]
    75a0:	7100001f 	cmp	w0, #0x0
    75a4:	93401c23 	sxtb	x3, w1
    75a8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    75ac:	d503201f 	nop
    75b0:	aa1403e0 	mov	x0, x20
    75b4:	52800003 	mov	w3, #0x0                   	// #0
    75b8:	97fffec6 	bl	70d0 <fwp_write>
    75bc:	910006b5 	add	x21, x21, #0x1
    75c0:	f9400260 	ldr	x0, [x19]
    75c4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    75c8:	eb0002bf 	cmp	x21, x0
    75cc:	540026c2 	b.cs	7aa4 <fwp_write+0x9d4>  // b.hs, b.nlast
    75d0:	d2800042 	mov	x2, #0x2                   	// #2
    75d4:	aa1603e1 	mov	x1, x22
    75d8:	aa1403e0 	mov	x0, x20
    75dc:	97fff00d 	bl	3610 <buf_put>
    75e0:	f9401f82 	ldr	x2, [x28, #56]
    75e4:	f9400263 	ldr	x3, [x19]
    75e8:	b5fffba2 	cbnz	x2, 755c <fwp_write+0x48c>
    75ec:	d37df2a0 	lsl	x0, x21, #3
    75f0:	b7f83f03 	tbnz	x3, #63, 7dd0 <fwp_write+0xd00>
    75f4:	91002261 	add	x1, x19, #0x8
    75f8:	8b000020 	add	x0, x1, x0
    75fc:	f9400001 	ldr	x1, [x0]
    7600:	17ffffec 	b	75b0 <fwp_write+0x4e0>
    7604:	a9400e62 	ldp	x2, x3, [x19]
    7608:	b7f83ca3 	tbnz	x3, #63, 7d9c <fwp_write+0xccc>
    760c:	910123f5 	add	x21, sp, #0x48
    7610:	aa1503e0 	mov	x0, x21
    7614:	97ffee23 	bl	2ea0 <fwp_fmt_u128>
    7618:	aa1503e0 	mov	x0, x21
    761c:	97ffec61 	bl	27a0 <strlen@plt>
    7620:	aa1503e1 	mov	x1, x21
    7624:	aa0003e2 	mov	x2, x0
    7628:	17fffed0 	b	7168 <fwp_write+0x98>
    762c:	fd015be8 	str	d8, [sp, #688]
    7630:	1e270268 	fmov	s8, w19
    7634:	fd015fe9 	str	d9, [sp, #696]
    7638:	1e282100 	fcmp	s8, s8
    763c:	54004d26 	b.vs	7fe0 <fwp_write+0xf10>
    7640:	1e20c101 	fabs	s1, s8
    7644:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7648:	1e270000 	fmov	s0, w0
    764c:	1e202020 	fcmp	s1, s0
    7650:	54002c0d 	b.le	7bd0 <fwp_write+0xb00>
    7654:	1e202118 	fcmpe	s8, #0.0
    7658:	b0000022 	adrp	x2, c000 <f0+0x23e0>
    765c:	913fe042 	add	x2, x2, #0xff8
    7660:	910123f5 	add	x21, sp, #0x48
    7664:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7668:	910f4021 	add	x1, x1, #0x3d0
    766c:	aa1503e0 	mov	x0, x21
    7670:	9a81c041 	csel	x1, x2, x1, gt
    7674:	97ffecf7 	bl	2a50 <strcpy@plt>
    7678:	aa1503e0 	mov	x0, x21
    767c:	97ffec49 	bl	27a0 <strlen@plt>
    7680:	aa1503e1 	mov	x1, x21
    7684:	aa0003e2 	mov	x2, x0
    7688:	aa1403e0 	mov	x0, x20
    768c:	97ffefe1 	bl	3610 <buf_put>
    7690:	f9413bf5 	ldr	x21, [sp, #624]
    7694:	f9413ff6 	ldr	x22, [sp, #632]
    7698:	f94153fb 	ldr	x27, [sp, #672]
    769c:	f94157fc 	ldr	x28, [sp, #680]
    76a0:	fd415be8 	ldr	d8, [sp, #688]
    76a4:	fd415fe9 	ldr	d9, [sp, #696]
    76a8:	17fffeb6 	b	7180 <fwp_write+0xb0>
    76ac:	f9400276 	ldr	x22, [x19]
    76b0:	34002e03 	cbz	w3, 7c70 <fwp_write+0xba0>
    76b4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    76b8:	f947f400 	ldr	x0, [x0, #4072]
    76bc:	f94127e2 	ldr	x2, [sp, #584]
    76c0:	f9400001 	ldr	x1, [x0]
    76c4:	eb010042 	subs	x2, x2, x1
    76c8:	d2800001 	mov	x1, #0x0                   	// #0
    76cc:	540014a1 	b.ne	7960 <fwp_write+0x890>  // b.any
    76d0:	aa1603e2 	mov	x2, x22
    76d4:	91002261 	add	x1, x19, #0x8
    76d8:	f9413bf5 	ldr	x21, [sp, #624]
    76dc:	aa1403e0 	mov	x0, x20
    76e0:	f9413ff6 	ldr	x22, [sp, #632]
    76e4:	17fffeff 	b	72e0 <fwp_write+0x210>
    76e8:	fd015be8 	str	d8, [sp, #688]
    76ec:	9e670268 	fmov	d8, x19
    76f0:	fd015fe9 	str	d9, [sp, #696]
    76f4:	1e682100 	fcmp	d8, d8
    76f8:	54004746 	b.vs	7fe0 <fwp_write+0xf10>
    76fc:	1e60c101 	fabs	d1, d8
    7700:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7704:	9e670000 	fmov	d0, x0
    7708:	910123f5 	add	x21, sp, #0x48
    770c:	52800033 	mov	w19, #0x1                   	// #1
    7710:	1e602020 	fcmp	d1, d0
    7714:	540001ad 	b.le	7748 <fwp_write+0x678>
    7718:	1e602118 	fcmpe	d8, #0.0
    771c:	b0000022 	adrp	x2, c000 <f0+0x23e0>
    7720:	913fe042 	add	x2, x2, #0xff8
    7724:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7728:	910f4021 	add	x1, x1, #0x3d0
    772c:	aa1503e0 	mov	x0, x21
    7730:	9a81c041 	csel	x1, x2, x1, gt
    7734:	97ffecc7 	bl	2a50 <strcpy@plt>
    7738:	17ffffd0 	b	7678 <fwp_write+0x5a8>
    773c:	11000673 	add	w19, w19, #0x1
    7740:	71004a7f 	cmp	w19, #0x12
    7744:	54003860 	b.eq	7e50 <fwp_write+0xd80>  // b.none
    7748:	1e604100 	fmov	d0, d8
    774c:	2a1303e1 	mov	w1, w19
    7750:	aa1503e0 	mov	x0, x21
    7754:	97fff130 	bl	3c14 <fwp_format_g.constprop.0>
    7758:	aa1503e0 	mov	x0, x21
    775c:	d2800001 	mov	x1, #0x0                   	// #0
    7760:	97ffec24 	bl	27f0 <strtod@plt>
    7764:	1e602100 	fcmp	d8, d0
    7768:	54fffea1 	b.ne	773c <fwp_write+0x66c>  // b.any
    776c:	aa1503e0 	mov	x0, x21
    7770:	97fff021 	bl	37f4 <fwp_finish_float>
    7774:	17ffffc1 	b	7678 <fwp_write+0x5a8>
    7778:	a9400e62 	ldp	x2, x3, [x19]
    777c:	910123f3 	add	x19, sp, #0x48
    7780:	aa1303e0 	mov	x0, x19
    7784:	97ffedc7 	bl	2ea0 <fwp_fmt_u128>
    7788:	17fffe74 	b	7158 <fwp_write+0x88>
    778c:	f90143f7 	str	x23, [sp, #640]
    7790:	f90147f8 	str	x24, [sp, #648]
    7794:	2a1303f8 	mov	w24, w19
    7798:	f9014bf9 	str	x25, [sp, #656]
    779c:	f9014ffa 	str	x26, [sp, #664]
    77a0:	f13ffe7f 	cmp	x19, #0xfff
    77a4:	54000049 	b.ls	77ac <fwp_write+0x6dc>  // b.plast
    77a8:	b9400278 	ldr	w24, [x19]
    77ac:	f9400f80 	ldr	x0, [x28, #24]
    77b0:	2a1803f5 	mov	w21, w24
    77b4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    77b8:	d37ef6b9 	lsl	x25, x21, #2
    77bc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    77c0:	aa1603e0 	mov	x0, x22
    77c4:	97ffebf7 	bl	27a0 <strlen@plt>
    77c8:	aa1603e1 	mov	x1, x22
    77cc:	aa0003e2 	mov	x2, x0
    77d0:	aa1403e0 	mov	x0, x20
    77d4:	97ffef8f 	bl	3610 <buf_put>
    77d8:	f9401780 	ldr	x0, [x28, #40]
    77dc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    77e0:	7100001f 	cmp	w0, #0x0
    77e4:	5400068d 	b.le	78b4 <fwp_write+0x7e4>
    77e8:	91002276 	add	x22, x19, #0x8
    77ec:	91001ff5 	add	x21, sp, #0x7
    77f0:	d280001b 	mov	x27, #0x0                   	// #0
    77f4:	5280041a 	mov	w26, #0x20                  	// #32
    77f8:	f9401b80 	ldr	x0, [x28, #48]
    77fc:	aa1503e1 	mov	x1, x21
    7800:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7804:	d2800022 	mov	x2, #0x1                   	// #1
    7808:	f8786803 	ldr	x3, [x0, x24]
    780c:	aa1403e0 	mov	x0, x20
    7810:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7814:	39001ffa 	strb	w26, [sp, #7]
    7818:	97ffef7e 	bl	3610 <buf_put>
    781c:	f13ffeff 	cmp	x23, #0xfff
    7820:	b9400261 	ldr	w1, [x19]
    7824:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7828:	7100383f 	cmp	w1, #0xe
    782c:	54000160 	b.eq	7858 <fwp_write+0x788>  // b.none
    7830:	7100403f 	cmp	w1, #0x10
    7834:	54001a60 	b.eq	7b80 <fwp_write+0xab0>  // b.none
    7838:	7100283f 	cmp	w1, #0xa
    783c:	54002aa0 	b.eq	7d90 <fwp_write+0xcc0>  // b.none
    7840:	540014ac 	b.gt	7ad4 <fwp_write+0xa04>
    7844:	71000c3f 	cmp	w1, #0x3
    7848:	540029ac 	b.gt	7d7c <fwp_write+0xcac>
    784c:	d37ffee0 	lsr	x0, x23, #63
    7850:	37f814a1 	tbnz	w1, #31, 7ae4 <fwp_write+0xa14>
    7854:	d503201f 	nop
    7858:	34001460 	cbz	w0, 7ae4 <fwp_write+0xa14>
    785c:	52800503 	mov	w3, #0x28                  	// #40
    7860:	aa1503e1 	mov	x1, x21
    7864:	aa1403e0 	mov	x0, x20
    7868:	d2800022 	mov	x2, #0x1                   	// #1
    786c:	39001fe3 	strb	w3, [sp, #7]
    7870:	97ffef68 	bl	3610 <buf_put>
    7874:	aa1303e2 	mov	x2, x19
    7878:	aa1703e1 	mov	x1, x23
    787c:	aa1403e0 	mov	x0, x20
    7880:	52800003 	mov	w3, #0x0                   	// #0
    7884:	97fffe13 	bl	70d0 <fwp_write>
    7888:	52800523 	mov	w3, #0x29                  	// #41
    788c:	aa1503e1 	mov	x1, x21
    7890:	aa1403e0 	mov	x0, x20
    7894:	d2800022 	mov	x2, #0x1                   	// #1
    7898:	39001fe3 	strb	w3, [sp, #7]
    789c:	97ffef5d 	bl	3610 <buf_put>
    78a0:	f9401780 	ldr	x0, [x28, #40]
    78a4:	9100077b 	add	x27, x27, #0x1
    78a8:	b8796800 	ldr	w0, [x0, x25]
    78ac:	6b1b001f 	cmp	w0, w27
    78b0:	54fffa4c 	b.gt	77f8 <fwp_write+0x728>
    78b4:	f9413bf5 	ldr	x21, [sp, #624]
    78b8:	f9413ff6 	ldr	x22, [sp, #632]
    78bc:	f94143f7 	ldr	x23, [sp, #640]
    78c0:	f94147f8 	ldr	x24, [sp, #648]
    78c4:	f9414bf9 	ldr	x25, [sp, #656]
    78c8:	f9414ffa 	ldr	x26, [sp, #664]
    78cc:	f94153fb 	ldr	x27, [sp, #672]
    78d0:	f94157fc 	ldr	x28, [sp, #680]
    78d4:	17fffe2b 	b	7180 <fwp_write+0xb0>
    78d8:	52800783 	mov	w3, #0x3c                  	// #60
    78dc:	91001ff3 	add	x19, sp, #0x7
    78e0:	aa1303e1 	mov	x1, x19
    78e4:	d2800022 	mov	x2, #0x1                   	// #1
    78e8:	aa1403e0 	mov	x0, x20
    78ec:	39001fe3 	strb	w3, [sp, #7]
    78f0:	97ffef48 	bl	3610 <buf_put>
    78f4:	f9400795 	ldr	x21, [x28, #8]
    78f8:	aa1503e0 	mov	x0, x21
    78fc:	97ffeba9 	bl	27a0 <strlen@plt>
    7900:	aa1503e1 	mov	x1, x21
    7904:	aa0003e2 	mov	x2, x0
    7908:	aa1403e0 	mov	x0, x20
    790c:	97ffef41 	bl	3610 <buf_put>
    7910:	528007c3 	mov	w3, #0x3e                  	// #62
    7914:	aa1303e1 	mov	x1, x19
    7918:	aa1403e0 	mov	x0, x20
    791c:	d2800022 	mov	x2, #0x1                   	// #1
    7920:	39001fe3 	strb	w3, [sp, #7]
    7924:	17fffe12 	b	716c <fwp_write+0x9c>
    7928:	f100067f 	cmp	x19, #0x1
    792c:	540025a0 	b.eq	7de0 <fwp_write+0xd10>  // b.none
    7930:	b100067f 	cmn	x19, #0x1
    7934:	54002bc0 	b.eq	7eac <fwp_write+0xddc>  // b.none
    7938:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    793c:	910f6021 	add	x1, x1, #0x3d8
    7940:	d2800022 	mov	x2, #0x1                   	// #1
    7944:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7948:	f947f400 	ldr	x0, [x0, #4072]
    794c:	f94127e4 	ldr	x4, [sp, #584]
    7950:	f9400003 	ldr	x3, [x0]
    7954:	eb030084 	subs	x4, x4, x3
    7958:	d2800003 	mov	x3, #0x0                   	// #0
    795c:	54ffebe0 	b.eq	76d8 <fwp_write+0x608>  // b.none
    7960:	f90143f7 	str	x23, [sp, #640]
    7964:	f90147f8 	str	x24, [sp, #648]
    7968:	f9014bf9 	str	x25, [sp, #656]
    796c:	f9014ffa 	str	x26, [sp, #664]
    7970:	fd015be8 	str	d8, [sp, #688]
    7974:	fd015fe9 	str	d9, [sp, #696]
    7978:	97ffebe6 	bl	2910 <__stack_chk_fail@plt>
    797c:	52800b63 	mov	w3, #0x5b                  	// #91
    7980:	91001ff5 	add	x21, sp, #0x7
    7984:	aa1503e1 	mov	x1, x21
    7988:	aa1403e0 	mov	x0, x20
    798c:	d2800022 	mov	x2, #0x1                   	// #1
    7990:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0xe0>
    7994:	9111e2d6 	add	x22, x22, #0x478
    7998:	39001fe3 	strb	w3, [sp, #7]
    799c:	97ffef1d 	bl	3610 <buf_put>
    79a0:	b4000273 	cbz	x19, 79ec <fwp_write+0x91c>
    79a4:	f9400661 	ldr	x1, [x19, #8]
    79a8:	aa1403e0 	mov	x0, x20
    79ac:	f9401f82 	ldr	x2, [x28, #56]
    79b0:	52800003 	mov	w3, #0x0                   	// #0
    79b4:	97fffdc7 	bl	70d0 <fwp_write>
    79b8:	f9400a73 	ldr	x19, [x19, #16]
    79bc:	b4000193 	cbz	x19, 79ec <fwp_write+0x91c>
    79c0:	aa1603e1 	mov	x1, x22
    79c4:	aa1403e0 	mov	x0, x20
    79c8:	d2800042 	mov	x2, #0x2                   	// #2
    79cc:	97ffef11 	bl	3610 <buf_put>
    79d0:	f9400661 	ldr	x1, [x19, #8]
    79d4:	aa1403e0 	mov	x0, x20
    79d8:	f9401f82 	ldr	x2, [x28, #56]
    79dc:	52800003 	mov	w3, #0x0                   	// #0
    79e0:	97fffdbc 	bl	70d0 <fwp_write>
    79e4:	f9400a73 	ldr	x19, [x19, #16]
    79e8:	b5fffed3 	cbnz	x19, 79c0 <fwp_write+0x8f0>
    79ec:	52800ba3 	mov	w3, #0x5d                  	// #93
    79f0:	aa1503e1 	mov	x1, x21
    79f4:	aa1403e0 	mov	x0, x20
    79f8:	d2800022 	mov	x2, #0x1                   	// #1
    79fc:	39001fe3 	strb	w3, [sp, #7]
    7a00:	17fffddb 	b	716c <fwp_write+0x9c>
    7a04:	aa1403e0 	mov	x0, x20
    7a08:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7a0c:	d28000c2 	mov	x2, #0x6                   	// #6
    7a10:	9111a021 	add	x1, x1, #0x468
    7a14:	97ffeeff 	bl	3610 <buf_put>
    7a18:	f9400260 	ldr	x0, [x19]
    7a1c:	b40004c0 	cbz	x0, 7ab4 <fwp_write+0x9e4>
    7a20:	910123f5 	add	x21, sp, #0x48
    7a24:	91002276 	add	x22, x19, #0x8
    7a28:	f90143f7 	str	x23, [sp, #640]
    7a2c:	d2800017 	mov	x23, #0x0                   	// #0
    7a30:	f90147f8 	str	x24, [sp, #648]
    7a34:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0xe0>
    7a38:	9111c318 	add	x24, x24, #0x470
    7a3c:	f9014bf9 	str	x25, [sp, #656]
    7a40:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0xe0>
    7a44:	9111e339 	add	x25, x25, #0x478
    7a48:	f9014ffa 	str	x26, [sp, #664]
    7a4c:	14000005 	b	7a60 <fwp_write+0x990>
    7a50:	aa1903e1 	mov	x1, x25
    7a54:	aa1403e0 	mov	x0, x20
    7a58:	d2800042 	mov	x2, #0x2                   	// #2
    7a5c:	97ffeeed 	bl	3610 <buf_put>
    7a60:	38776ac5 	ldrb	w5, [x22, x23]
    7a64:	d2804003 	mov	x3, #0x200                 	// #512
    7a68:	aa1803e4 	mov	x4, x24
    7a6c:	aa0303e1 	mov	x1, x3
    7a70:	52800042 	mov	w2, #0x2                   	// #2
    7a74:	aa1503e0 	mov	x0, x21
    7a78:	910006f7 	add	x23, x23, #0x1
    7a7c:	97ffeb81 	bl	2880 <__snprintf_chk@plt>
    7a80:	aa1503e0 	mov	x0, x21
    7a84:	97ffeb47 	bl	27a0 <strlen@plt>
    7a88:	aa1503e1 	mov	x1, x21
    7a8c:	aa0003e2 	mov	x2, x0
    7a90:	aa1403e0 	mov	x0, x20
    7a94:	97ffeedf 	bl	3610 <buf_put>
    7a98:	f9400260 	ldr	x0, [x19]
    7a9c:	eb17001f 	cmp	x0, x23
    7aa0:	54fffd88 	b.hi	7a50 <fwp_write+0x980>  // b.pmore
    7aa4:	f94143f7 	ldr	x23, [sp, #640]
    7aa8:	f94147f8 	ldr	x24, [sp, #648]
    7aac:	f9414bf9 	ldr	x25, [sp, #656]
    7ab0:	f9414ffa 	ldr	x26, [sp, #664]
    7ab4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ab8:	aa1403e0 	mov	x0, x20
    7abc:	91001fe1 	add	x1, sp, #0x7
    7ac0:	d2800022 	mov	x2, #0x1                   	// #1
    7ac4:	39001fe3 	strb	w3, [sp, #7]
    7ac8:	17fffda9 	b	716c <fwp_write+0x9c>
    7acc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7ad0:	17fffe44 	b	73e0 <fwp_write+0x310>
    7ad4:	f10002ff 	cmp	x23, #0x0
    7ad8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7adc:	71002c3f 	cmp	w1, #0xb
    7ae0:	54ffebc0 	b.eq	7858 <fwp_write+0x788>  // b.none
    7ae4:	aa1303e2 	mov	x2, x19
    7ae8:	aa1703e1 	mov	x1, x23
    7aec:	aa1403e0 	mov	x0, x20
    7af0:	52800003 	mov	w3, #0x0                   	// #0
    7af4:	97fffd77 	bl	70d0 <fwp_write>
    7af8:	17ffff6a 	b	78a0 <fwp_write+0x7d0>
    7afc:	aa1403e0 	mov	x0, x20
    7b00:	91001fe1 	add	x1, sp, #0x7
    7b04:	52800fa3 	mov	w3, #0x7d                  	// #125
    7b08:	d2800022 	mov	x2, #0x1                   	// #1
    7b0c:	17fffe38 	b	73ec <fwp_write+0x31c>
    7b10:	a9400281 	ldp	x1, x0, [x20]
    7b14:	91000800 	add	x0, x0, #0x2
    7b18:	8b160000 	add	x0, x0, x22
    7b1c:	f9000680 	str	x0, [x20, #8]
    7b20:	3820683f 	strb	wzr, [x1, x0]
    7b24:	f9413bf5 	ldr	x21, [sp, #624]
    7b28:	f9413ff6 	ldr	x22, [sp, #632]
    7b2c:	f94153fb 	ldr	x27, [sp, #672]
    7b30:	f94157fc 	ldr	x28, [sp, #680]
    7b34:	17fffd93 	b	7180 <fwp_write+0xb0>
    7b38:	f9400f80 	ldr	x0, [x28, #24]
    7b3c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7b40:	aa1b03e0 	mov	x0, x27
    7b44:	97ffeb17 	bl	27a0 <strlen@plt>
    7b48:	aa1b03e1 	mov	x1, x27
    7b4c:	aa0003e2 	mov	x2, x0
    7b50:	aa1403e0 	mov	x0, x20
    7b54:	97ffeeaf 	bl	3610 <buf_put>
    7b58:	aa1903e1 	mov	x1, x25
    7b5c:	aa1403e0 	mov	x0, x20
    7b60:	d2800062 	mov	x2, #0x3                   	// #3
    7b64:	97ffeeab 	bl	3610 <buf_put>
    7b68:	17fffe10 	b	73a8 <fwp_write+0x2d8>
    7b6c:	aa1a03e1 	mov	x1, x26
    7b70:	aa1403e0 	mov	x0, x20
    7b74:	d2800042 	mov	x2, #0x2                   	// #2
    7b78:	97ffeea6 	bl	3610 <buf_put>
    7b7c:	17fffe09 	b	73a0 <fwp_write+0x2d0>
    7b80:	f9400660 	ldr	x0, [x19, #8]
    7b84:	b4fffb00 	cbz	x0, 7ae4 <fwp_write+0xa14>
    7b88:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7b8c:	91124021 	add	x1, x1, #0x490
    7b90:	97ffeb80 	bl	2990 <strcmp@plt>
    7b94:	7100001f 	cmp	w0, #0x0
    7b98:	1a9f07e0 	cset	w0, ne	// ne = any
    7b9c:	17ffff2f 	b	7858 <fwp_write+0x788>
    7ba0:	aa1403e0 	mov	x0, x20
    7ba4:	d2800042 	mov	x2, #0x2                   	// #2
    7ba8:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7bac:	91122021 	add	x1, x1, #0x488
    7bb0:	97ffee98 	bl	3610 <buf_put>
    7bb4:	91004261 	add	x1, x19, #0x10
    7bb8:	aa1403e0 	mov	x0, x20
    7bbc:	f9402382 	ldr	x2, [x28, #64]
    7bc0:	52800003 	mov	w3, #0x0                   	// #0
    7bc4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7bc8:	97fffd42 	bl	70d0 <fwp_write>
    7bcc:	17fffd9c 	b	723c <fwp_write+0x16c>
    7bd0:	1e22c109 	fcvt	d9, s8
    7bd4:	910123f5 	add	x21, sp, #0x48
    7bd8:	52800033 	mov	w19, #0x1                   	// #1
    7bdc:	d503201f 	nop
    7be0:	1e604120 	fmov	d0, d9
    7be4:	2a1303e1 	mov	w1, w19
    7be8:	aa1503e0 	mov	x0, x21
    7bec:	97fff00a 	bl	3c14 <fwp_format_g.constprop.0>
    7bf0:	aa1503e0 	mov	x0, x21
    7bf4:	d2800001 	mov	x1, #0x0                   	// #0
    7bf8:	97ffeb72 	bl	29c0 <strtof@plt>
    7bfc:	1e202100 	fcmp	s8, s0
    7c00:	54ffdb60 	b.eq	776c <fwp_write+0x69c>  // b.none
    7c04:	11000673 	add	w19, w19, #0x1
    7c08:	71002a7f 	cmp	w19, #0xa
    7c0c:	54fffea1 	b.ne	7be0 <fwp_write+0xb10>  // b.any
    7c10:	1e604120 	fmov	d0, d9
    7c14:	aa1503e0 	mov	x0, x21
    7c18:	52800121 	mov	w1, #0x9                   	// #9
    7c1c:	97ffeffe 	bl	3c14 <fwp_format_g.constprop.0>
    7c20:	17fffed3 	b	776c <fwp_write+0x69c>
    7c24:	d37ef6a1 	lsl	x1, x21, #2
    7c28:	b7f81563 	tbnz	x3, #63, 7ed4 <fwp_write+0xe04>
    7c2c:	91002263 	add	x3, x19, #0x8
    7c30:	8b010061 	add	x1, x3, x1
    7c34:	b9400023 	ldr	w3, [x1]
    7c38:	7100081f 	cmp	w0, #0x2
    7c3c:	2a0303e1 	mov	w1, w3
    7c40:	93407c63 	sxtw	x3, w3
    7c44:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7c48:	17fffe5a 	b	75b0 <fwp_write+0x4e0>
    7c4c:	d37ffaa1 	lsl	x1, x21, #1
    7c50:	b7f81363 	tbnz	x3, #63, 7ebc <fwp_write+0xdec>
    7c54:	91002263 	add	x3, x19, #0x8
    7c58:	8b010061 	add	x1, x3, x1
    7c5c:	79400021 	ldrh	w1, [x1]
    7c60:	7100041f 	cmp	w0, #0x1
    7c64:	93403c23 	sxth	x3, w1
    7c68:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7c6c:	17fffe51 	b	75b0 <fwp_write+0x4e0>
    7c70:	52800443 	mov	w3, #0x22                  	// #34
    7c74:	91001ff5 	add	x21, sp, #0x7
    7c78:	91002273 	add	x19, x19, #0x8
    7c7c:	aa1503e1 	mov	x1, x21
    7c80:	aa1403e0 	mov	x0, x20
    7c84:	d2800022 	mov	x2, #0x1                   	// #1
    7c88:	39001fe3 	strb	w3, [sp, #7]
    7c8c:	f90143f7 	str	x23, [sp, #640]
    7c90:	8b160277 	add	x23, x19, x22
    7c94:	f90147f8 	str	x24, [sp, #648]
    7c98:	97ffee5e 	bl	3610 <buf_put>
    7c9c:	b4000696 	cbz	x22, 7d6c <fwp_write+0xc9c>
    7ca0:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0xe0>
    7ca4:	9110e318 	add	x24, x24, #0x438
    7ca8:	f9014bf9 	str	x25, [sp, #656]
    7cac:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0xe0>
    7cb0:	91116339 	add	x25, x25, #0x458
    7cb4:	f9014ffa 	str	x26, [sp, #664]
    7cb8:	1400000d 	b	7cec <fwp_write+0xc1c>
    7cbc:	710024bf 	cmp	w5, #0x9
    7cc0:	54000460 	b.eq	7d4c <fwp_write+0xc7c>  // b.none
    7cc4:	710028bf 	cmp	w5, #0xa
    7cc8:	54000a61 	b.ne	7e14 <fwp_write+0xd44>  // b.any
    7ccc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7cd0:	aa1403e0 	mov	x0, x20
    7cd4:	91112021 	add	x1, x1, #0x448
    7cd8:	d2800042 	mov	x2, #0x2                   	// #2
    7cdc:	97ffee4d 	bl	3610 <buf_put>
    7ce0:	91000673 	add	x19, x19, #0x1
    7ce4:	eb17027f 	cmp	x19, x23
    7ce8:	540003e0 	b.eq	7d64 <fwp_write+0xc94>  // b.none
    7cec:	39400265 	ldrb	w5, [x19]
    7cf0:	710034bf 	cmp	w5, #0xd
    7cf4:	54000180 	b.eq	7d24 <fwp_write+0xc54>  // b.none
    7cf8:	54fffe29 	b.ls	7cbc <fwp_write+0xbec>  // b.plast
    7cfc:	710088bf 	cmp	w5, #0x22
    7d00:	540001c0 	b.eq	7d38 <fwp_write+0xc68>  // b.none
    7d04:	710170bf 	cmp	w5, #0x5c
    7d08:	54000741 	b.ne	7df0 <fwp_write+0xd20>  // b.any
    7d0c:	aa1403e0 	mov	x0, x20
    7d10:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7d14:	d2800042 	mov	x2, #0x2                   	// #2
    7d18:	91110021 	add	x1, x1, #0x440
    7d1c:	97ffee3d 	bl	3610 <buf_put>
    7d20:	17fffff0 	b	7ce0 <fwp_write+0xc10>
    7d24:	aa1903e1 	mov	x1, x25
    7d28:	aa1403e0 	mov	x0, x20
    7d2c:	d2800042 	mov	x2, #0x2                   	// #2
    7d30:	97ffee38 	bl	3610 <buf_put>
    7d34:	17ffffeb 	b	7ce0 <fwp_write+0xc10>
    7d38:	aa1803e1 	mov	x1, x24
    7d3c:	aa1403e0 	mov	x0, x20
    7d40:	d2800042 	mov	x2, #0x2                   	// #2
    7d44:	97ffee33 	bl	3610 <buf_put>
    7d48:	17ffffe6 	b	7ce0 <fwp_write+0xc10>
    7d4c:	aa1403e0 	mov	x0, x20
    7d50:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7d54:	d2800042 	mov	x2, #0x2                   	// #2
    7d58:	91114021 	add	x1, x1, #0x450
    7d5c:	97ffee2d 	bl	3610 <buf_put>
    7d60:	17ffffe0 	b	7ce0 <fwp_write+0xc10>
    7d64:	f9414bf9 	ldr	x25, [sp, #656]
    7d68:	f9414ffa 	ldr	x26, [sp, #664]
    7d6c:	aa1503e1 	mov	x1, x21
    7d70:	aa1403e0 	mov	x0, x20
    7d74:	52800443 	mov	w3, #0x22                  	// #34
    7d78:	17fffd9c 	b	73e8 <fwp_write+0x318>
    7d7c:	7100103f 	cmp	w1, #0x4
    7d80:	54ffeb21 	b.ne	7ae4 <fwp_write+0xa14>  // b.any
    7d84:	f94006e0 	ldr	x0, [x23, #8]
    7d88:	d37ffc00 	lsr	x0, x0, #63
    7d8c:	17fffeb3 	b	7858 <fwp_write+0x788>
    7d90:	710002ff 	cmp	w23, #0x0
    7d94:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7d98:	17fffeb0 	b	7858 <fwp_write+0x788>
    7d9c:	528005a1 	mov	w1, #0x2d                  	// #45
    7da0:	eb0203e2 	negs	x2, x2
    7da4:	da0303e3 	ngc	x3, x3
    7da8:	910127e0 	add	x0, sp, #0x49
    7dac:	910123f5 	add	x21, sp, #0x48
    7db0:	390123e1 	strb	w1, [sp, #72]
    7db4:	97ffec3b 	bl	2ea0 <fwp_fmt_u128>
    7db8:	17fffe18 	b	7618 <fwp_write+0x548>
    7dbc:	d37ceea1 	lsl	x1, x21, #4
    7dc0:	b7f810a3 	tbnz	x3, #63, 7fd4 <fwp_write+0xf04>
    7dc4:	91002260 	add	x0, x19, #0x8
    7dc8:	8b010001 	add	x1, x0, x1
    7dcc:	17fffdf9 	b	75b0 <fwp_write+0x4e0>
    7dd0:	f9400a61 	ldr	x1, [x19, #16]
    7dd4:	8b010000 	add	x0, x0, x1
    7dd8:	f9400001 	ldr	x1, [x0]
    7ddc:	17fffdf5 	b	75b0 <fwp_write+0x4e0>
    7de0:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7de4:	d2800042 	mov	x2, #0x2                   	// #2
    7de8:	910f8021 	add	x1, x1, #0x3e0
    7dec:	17fffed6 	b	7944 <fwp_write+0x874>
    7df0:	7101fcbf 	cmp	w5, #0x7f
    7df4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7df8:	540000e9 	b.ls	7e14 <fwp_write+0xd44>  // b.plast
    7dfc:	aa1503e1 	mov	x1, x21
    7e00:	aa1403e0 	mov	x0, x20
    7e04:	d2800022 	mov	x2, #0x1                   	// #1
    7e08:	39001fe5 	strb	w5, [sp, #7]
    7e0c:	97ffee01 	bl	3610 <buf_put>
    7e10:	17ffffb4 	b	7ce0 <fwp_write+0xc10>
    7e14:	d2800203 	mov	x3, #0x10                  	// #16
    7e18:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0xe0>
    7e1c:	aa0303e1 	mov	x1, x3
    7e20:	91118084 	add	x4, x4, #0x460
    7e24:	910123f6 	add	x22, sp, #0x48
    7e28:	52800042 	mov	w2, #0x2                   	// #2
    7e2c:	aa1603e0 	mov	x0, x22
    7e30:	97ffea94 	bl	2880 <__snprintf_chk@plt>
    7e34:	aa1603e0 	mov	x0, x22
    7e38:	97ffea5a 	bl	27a0 <strlen@plt>
    7e3c:	aa1603e1 	mov	x1, x22
    7e40:	aa0003e2 	mov	x2, x0
    7e44:	aa1403e0 	mov	x0, x20
    7e48:	97ffedf2 	bl	3610 <buf_put>
    7e4c:	17ffffa5 	b	7ce0 <fwp_write+0xc10>
    7e50:	1e604100 	fmov	d0, d8
    7e54:	aa1503e0 	mov	x0, x21
    7e58:	52800221 	mov	w1, #0x11                  	// #17
    7e5c:	97ffef6e 	bl	3c14 <fwp_format_g.constprop.0>
    7e60:	17fffe43 	b	776c <fwp_write+0x69c>
    7e64:	b9401040 	ldr	w0, [x2, #16]
    7e68:	350003c0 	cbnz	w0, 7ee0 <fwp_write+0xe10>
    7e6c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7e70:	f947f400 	ldr	x0, [x0, #4072]
    7e74:	f94127e2 	ldr	x2, [sp, #584]
    7e78:	f9400001 	ldr	x1, [x0]
    7e7c:	eb010042 	subs	x2, x2, x1
    7e80:	d2800001 	mov	x1, #0x0                   	// #0
    7e84:	54ffd721 	b.ne	7968 <fwp_write+0x898>  // b.any
    7e88:	f9413bf5 	ldr	x21, [sp, #624]
    7e8c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7e90:	f9413ff6 	ldr	x22, [sp, #632]
    7e94:	aa1403e0 	mov	x0, x20
    7e98:	f94143f7 	ldr	x23, [sp, #640]
    7e9c:	9112c021 	add	x1, x1, #0x4b0
    7ea0:	f94147f8 	ldr	x24, [sp, #648]
    7ea4:	d2800042 	mov	x2, #0x2                   	// #2
    7ea8:	17fffd0e 	b	72e0 <fwp_write+0x210>
    7eac:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xe0>
    7eb0:	d2800042 	mov	x2, #0x2                   	// #2
    7eb4:	910fa021 	add	x1, x1, #0x3e8
    7eb8:	17fffea3 	b	7944 <fwp_write+0x874>
    7ebc:	f9400a63 	ldr	x3, [x19, #16]
    7ec0:	8b030021 	add	x1, x1, x3
    7ec4:	17ffff66 	b	7c5c <fwp_write+0xb8c>
    7ec8:	f9400a61 	ldr	x1, [x19, #16]
    7ecc:	8b0102a1 	add	x1, x21, x1
    7ed0:	17fffdb3 	b	759c <fwp_write+0x4cc>
    7ed4:	f9400a63 	ldr	x3, [x19, #16]
    7ed8:	8b030021 	add	x1, x1, x3
    7edc:	17ffff56 	b	7c34 <fwp_write+0xb64>
    7ee0:	b9404840 	ldr	w0, [x2, #72]
    7ee4:	91001ff5 	add	x21, sp, #0x7
    7ee8:	34ffa360 	cbz	w0, 7354 <fwp_write+0x284>
    7eec:	52800503 	mov	w3, #0x28                  	// #40
    7ef0:	aa1403e0 	mov	x0, x20
    7ef4:	aa1503e1 	mov	x1, x21
    7ef8:	d2800022 	mov	x2, #0x1                   	// #1
    7efc:	39001fe3 	strb	w3, [sp, #7]
    7f00:	97ffedc4 	bl	3610 <buf_put>
    7f04:	b9401380 	ldr	w0, [x28, #16]
    7f08:	52800038 	mov	w24, #0x1                   	// #1
    7f0c:	7100001f 	cmp	w0, #0x0
    7f10:	54ffa36c 	b.gt	737c <fwp_write+0x2ac>
    7f14:	17fffd32 	b	73dc <fwp_write+0x30c>
    7f18:	f9014bf9 	str	x25, [sp, #656]
    7f1c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xef20>
    7f20:	f9014ffa 	str	x26, [sp, #664]
    7f24:	f9400676 	ldr	x22, [x19, #8]
    7f28:	910aa333 	add	x19, x25, #0x2a8
    7f2c:	91002273 	add	x19, x19, #0x8
    7f30:	937ffed8 	asr	x24, x22, #63
    7f34:	aa1802c0 	orr	x0, x22, x24
    7f38:	b5000320 	cbnz	x0, 7f9c <fwp_write+0xecc>
    7f3c:	110006b5 	add	w21, w21, #0x1
    7f40:	710016bf 	cmp	w21, #0x5
    7f44:	54ffffc1 	b.ne	7f3c <fwp_write+0xe6c>  // b.any
    7f48:	b7f80578 	tbnz	x24, #63, 7ff4 <fwp_write+0xf24>
    7f4c:	910023f3 	add	x19, sp, #0x8
    7f50:	aa1603e2 	mov	x2, x22
    7f54:	aa1303e0 	mov	x0, x19
    7f58:	d2800003 	mov	x3, #0x0                   	// #0
    7f5c:	97ffebd1 	bl	2ea0 <fwp_fmt_u128>
    7f60:	910123f5 	add	x21, sp, #0x48
    7f64:	d0000023 	adrp	x3, d000 <_IO_stdin_used+0xe0>
    7f68:	aa1303e4 	mov	x4, x19
    7f6c:	aa1503e0 	mov	x0, x21
    7f70:	9112a063 	add	x3, x3, #0x4a8
    7f74:	d2804002 	mov	x2, #0x200                 	// #512
    7f78:	52800041 	mov	w1, #0x2                   	// #2
    7f7c:	97ffea0d 	bl	27b0 <__sprintf_chk@plt>
    7f80:	aa1503e0 	mov	x0, x21
    7f84:	97ffea07 	bl	27a0 <strlen@plt>
    7f88:	aa1503e1 	mov	x1, x21
    7f8c:	aa0003e2 	mov	x2, x0
    7f90:	aa1403e0 	mov	x0, x20
    7f94:	97ffed9f 	bl	3610 <buf_put>
    7f98:	17fffe47 	b	78b4 <fwp_write+0x7e4>
    7f9c:	f9400277 	ldr	x23, [x19]
    7fa0:	aa1603e0 	mov	x0, x22
    7fa4:	aa1803e1 	mov	x1, x24
    7fa8:	aa1703e2 	mov	x2, x23
    7fac:	937ffefa 	asr	x26, x23, #63
    7fb0:	aa1a03e3 	mov	x3, x26
    7fb4:	940012f3 	bl	cb80 <__modti3>
    7fb8:	aa010000 	orr	x0, x0, x1
    7fbc:	b40002c0 	cbz	x0, 8014 <fwp_write+0xf44>
    7fc0:	110006b5 	add	w21, w21, #0x1
    7fc4:	91004273 	add	x19, x19, #0x10
    7fc8:	710016bf 	cmp	w21, #0x5
    7fcc:	54fffe81 	b.ne	7f9c <fwp_write+0xecc>  // b.any
    7fd0:	17ffffde 	b	7f48 <fwp_write+0xe78>
    7fd4:	f9400a60 	ldr	x0, [x19, #16]
    7fd8:	8b000021 	add	x1, x1, x0
    7fdc:	17fffd75 	b	75b0 <fwp_write+0x4e0>
    7fe0:	528c29c0 	mov	w0, #0x614e                	// #24910
    7fe4:	910123f5 	add	x21, sp, #0x48
    7fe8:	72a009c0 	movk	w0, #0x4e, lsl #16
    7fec:	b9004be0 	str	w0, [sp, #72]
    7ff0:	17fffda2 	b	7678 <fwp_write+0x5a8>
    7ff4:	528005a1 	mov	w1, #0x2d                  	// #45
    7ff8:	eb1603e2 	negs	x2, x22
    7ffc:	da1803e3 	ngc	x3, x24
    8000:	910027e0 	add	x0, sp, #0x9
    8004:	910023f3 	add	x19, sp, #0x8
    8008:	390023e1 	strb	w1, [sp, #8]
    800c:	97ffeba5 	bl	2ea0 <fwp_fmt_u128>
    8010:	17ffffd4 	b	7f60 <fwp_write+0xe90>
    8014:	aa1703e2 	mov	x2, x23
    8018:	aa1a03e3 	mov	x3, x26
    801c:	aa1603e0 	mov	x0, x22
    8020:	aa1803e1 	mov	x1, x24
    8024:	940011f7 	bl	c800 <__divti3>
    8028:	aa0003e2 	mov	x2, x0
    802c:	aa0103e3 	mov	x3, x1
    8030:	b7f80201 	tbnz	x1, #63, 8070 <fwp_write+0xfa0>
    8034:	910023f3 	add	x19, sp, #0x8
    8038:	aa1303e0 	mov	x0, x19
    803c:	97ffeb99 	bl	2ea0 <fwp_fmt_u128>
    8040:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8044:	910aa339 	add	x25, x25, #0x2a8
    8048:	910123f5 	add	x21, sp, #0x48
    804c:	aa1303e4 	mov	x4, x19
    8050:	aa1503e0 	mov	x0, x21
    8054:	b0000023 	adrp	x3, d000 <_IO_stdin_used+0xe0>
    8058:	f8616b25 	ldr	x5, [x25, x1]
    805c:	91128063 	add	x3, x3, #0x4a0
    8060:	d2804002 	mov	x2, #0x200                 	// #512
    8064:	52800041 	mov	w1, #0x2                   	// #2
    8068:	97ffe9d2 	bl	27b0 <__sprintf_chk@plt>
    806c:	17ffffc5 	b	7f80 <fwp_write+0xeb0>
    8070:	528005a4 	mov	w4, #0x2d                  	// #45
    8074:	eb0003e2 	negs	x2, x0
    8078:	da0103e3 	ngc	x3, x1
    807c:	910027e0 	add	x0, sp, #0x9
    8080:	910023f3 	add	x19, sp, #0x8
    8084:	390023e4 	strb	w4, [sp, #8]
    8088:	97ffeb86 	bl	2ea0 <fwp_fmt_u128>
    808c:	17ffffed 	b	8040 <fwp_write+0xf70>
    8090:	f9013bf5 	str	x21, [sp, #624]
    8094:	f9013ff6 	str	x22, [sp, #632]
    8098:	f90143f7 	str	x23, [sp, #640]
    809c:	f90147f8 	str	x24, [sp, #648]
    80a0:	f9014bf9 	str	x25, [sp, #656]
    80a4:	f9014ffa 	str	x26, [sp, #664]
    80a8:	f90153fb 	str	x27, [sp, #672]
    80ac:	f90157fc 	str	x28, [sp, #680]
    80b0:	fd015be8 	str	d8, [sp, #688]
    80b4:	fd015fe9 	str	d9, [sp, #696]
    80b8:	97ffea16 	bl	2910 <__stack_chk_fail@plt>
    80bc:	d503201f 	nop

00000000000080c0 <fwp_hof0.constprop.0>:
    80c0:	d10543ff 	sub	sp, sp, #0x150
    80c4:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    80c8:	f947f442 	ldr	x2, [x2, #4072]
    80cc:	a90e7bfd 	stp	x29, x30, [sp, #224]
    80d0:	910383fd 	add	x29, sp, #0xe0
    80d4:	f90023e0 	str	x0, [sp, #64]
    80d8:	f9400040 	ldr	x0, [x2]
    80dc:	f9006fe0 	str	x0, [sp, #216]
    80e0:	d2800000 	mov	x0, #0x0                   	// #0
    80e4:	f90027e1 	str	x1, [sp, #72]
    80e8:	b400a7e1 	cbz	x1, 95e4 <fwp_hof0.constprop.0+0x1524>
    80ec:	900000c0 	adrp	x0, 20000 <__data_start>
    80f0:	91004000 	add	x0, x0, #0x10
    80f4:	9100e000 	add	x0, x0, #0x38
    80f8:	f90017e0 	str	x0, [sp, #40]
    80fc:	910163e0 	add	x0, sp, #0x58
    8100:	f9000fe0 	str	x0, [sp, #24]
    8104:	910183e0 	add	x0, sp, #0x60
    8108:	f90013e0 	str	x0, [sp, #32]
    810c:	b0000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    8110:	fd00a3e8 	str	d8, [sp, #320]
    8114:	a90f53f3 	stp	x19, x20, [sp, #240]
    8118:	b0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    811c:	fd469808 	ldr	d8, [x0, #3376]
    8120:	a9105bf5 	stp	x21, x22, [sp, #256]
    8124:	900000d5 	adrp	x21, 20000 <__data_start>
    8128:	a91163f7 	stp	x23, x24, [sp, #272]
    812c:	a9126bf9 	stp	x25, x26, [sp, #288]
    8130:	a91373fb 	stp	x27, x28, [sp, #304]
    8134:	91174282 	add	x2, x20, #0x5d0
    8138:	f94023e0 	ldr	x0, [sp, #64]
    813c:	f949ec43 	ldr	x3, [x2, #5080]
    8140:	f949d841 	ldr	x1, [x2, #5040]
    8144:	d370bc63 	lsl	x3, x3, #16
    8148:	cb010004 	sub	x4, x0, x1
    814c:	eb03009f 	cmp	x4, x3
    8150:	540003e2 	b.cs	81cc <fwp_hof0.constprop.0+0x10c>  // b.hs, b.nlast
    8154:	d350fc80 	lsr	x0, x4, #16
    8158:	f949fc46 	ldr	x6, [x2, #5112]
    815c:	8b000800 	add	x0, x0, x0, lsl #2
    8160:	d37df002 	lsl	x2, x0, #3
    8164:	8b0200c5 	add	x5, x6, x2
    8168:	f94010a0 	ldr	x0, [x5, #32]
    816c:	b4000300 	cbz	x0, 81cc <fwp_hof0.constprop.0+0x10c>
    8170:	386268c2 	ldrb	w2, [x6, x2]
    8174:	7100085f 	cmp	w2, #0x2
    8178:	5400bda0 	b.eq	992c <fwp_hof0.constprop.0+0x186c>  // b.none
    817c:	7100045f 	cmp	w2, #0x1
    8180:	54000261 	b.ne	81cc <fwp_hof0.constprop.0+0x10c>  // b.any
    8184:	92403c82 	and	x2, x4, #0xffff
    8188:	294310a6 	ldp	w6, w4, [x5, #24]
    818c:	9b067c42 	mul	x2, x2, x6
    8190:	d360fc42 	lsr	x2, x2, #32
    8194:	eb04005f 	cmp	x2, x4
    8198:	540001a2 	b.cs	81cc <fwp_hof0.constprop.0+0x10c>  // b.hs, b.nlast
    819c:	8b020000 	add	x0, x0, x2
    81a0:	39400002 	ldrb	w2, [x0]
    81a4:	34000142 	cbz	w2, 81cc <fwp_hof0.constprop.0+0x10c>
    81a8:	7103f45f 	cmp	w2, #0xfd
    81ac:	5400ce48 	b.hi	9b74 <fwp_hof0.constprop.0+0x1ab4>  // b.pmore
    81b0:	91174281 	add	x1, x20, #0x5d0
    81b4:	11000442 	add	w2, w2, #0x1
    81b8:	39000002 	strb	w2, [x0]
    81bc:	aa0103e0 	mov	x0, x1
    81c0:	f949d821 	ldr	x1, [x1, #5040]
    81c4:	f949ec03 	ldr	x3, [x0, #5080]
    81c8:	d370bc63 	lsl	x3, x3, #16
    81cc:	f94023f6 	ldr	x22, [sp, #64]
    81d0:	d28018c0 	mov	x0, #0xc6                  	// #198
    81d4:	f90007e0 	str	x0, [sp, #8]
    81d8:	f94017e0 	ldr	x0, [sp, #40]
    81dc:	9101c2a2 	add	x2, x21, #0x70
    81e0:	12800004 	mov	w4, #0xffffffff            	// #-1
    81e4:	b9005be4 	str	w4, [sp, #88]
    81e8:	cb010001 	sub	x1, x0, x1
    81ec:	d0ffffe0 	adrp	x0, 6000 <fwp_tape_finish+0xb0>
    81f0:	91014000 	add	x0, x0, #0x50
    81f4:	f90037e0 	str	x0, [sp, #104]
    81f8:	f9418840 	ldr	x0, [x2, #784]
    81fc:	f90033e0 	str	x0, [sp, #96]
    8200:	f9400fe0 	ldr	x0, [sp, #24]
    8204:	f9003be0 	str	x0, [sp, #112]
    8208:	f94013e0 	ldr	x0, [sp, #32]
    820c:	f9018840 	str	x0, [x2, #784]
    8210:	eb03003f 	cmp	x1, x3
    8214:	540007a2 	b.cs	8308 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8218:	91174282 	add	x2, x20, #0x5d0
    821c:	d350fc20 	lsr	x0, x1, #16
    8220:	8b000800 	add	x0, x0, x0, lsl #2
    8224:	f949fc44 	ldr	x4, [x2, #5112]
    8228:	d37df003 	lsl	x3, x0, #3
    822c:	8b030082 	add	x2, x4, x3
    8230:	f9401053 	ldr	x19, [x2, #32]
    8234:	b40006b3 	cbz	x19, 8308 <fwp_hof0.constprop.0+0x248>
    8238:	38636880 	ldrb	w0, [x4, x3]
    823c:	7100081f 	cmp	w0, #0x2
    8240:	5400a960 	b.eq	976c <fwp_hof0.constprop.0+0x16ac>  // b.none
    8244:	7100041f 	cmp	w0, #0x1
    8248:	54000601 	b.ne	8308 <fwp_hof0.constprop.0+0x248>  // b.any
    824c:	29430c44 	ldp	w4, w3, [x2, #24]
    8250:	92403c20 	and	x0, x1, #0xffff
    8254:	9b047c00 	mul	x0, x0, x4
    8258:	d360fc00 	lsr	x0, x0, #32
    825c:	eb03001f 	cmp	x0, x3
    8260:	540002a2 	b.cs	82b4 <fwp_hof0.constprop.0+0x1f4>  // b.hs, b.nlast
    8264:	8b000260 	add	x0, x19, x0
    8268:	39400003 	ldrb	w3, [x0]
    826c:	34000243 	cbz	w3, 82b4 <fwp_hof0.constprop.0+0x1f4>
    8270:	7103f47f 	cmp	w3, #0xfd
    8274:	5400c408 	b.hi	9af4 <fwp_hof0.constprop.0+0x1a34>  // b.pmore
    8278:	11000463 	add	w3, w3, #0x1
    827c:	39000003 	strb	w3, [x0]
    8280:	91174280 	add	x0, x20, #0x5d0
    8284:	f94017e3 	ldr	x3, [sp, #40]
    8288:	f949d801 	ldr	x1, [x0, #5040]
    828c:	f949ec02 	ldr	x2, [x0, #5080]
    8290:	cb010061 	sub	x1, x3, x1
    8294:	eb02403f 	cmp	x1, x2, lsl #16
    8298:	54000382 	b.cs	8308 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    829c:	f949fc00 	ldr	x0, [x0, #5112]
    82a0:	d350fc22 	lsr	x2, x1, #16
    82a4:	8b020842 	add	x2, x2, x2, lsl #2
    82a8:	8b020c02 	add	x2, x0, x2, lsl #3
    82ac:	f9401053 	ldr	x19, [x2, #32]
    82b0:	b40002d3 	cbz	x19, 8308 <fwp_hof0.constprop.0+0x248>
    82b4:	39400040 	ldrb	w0, [x2]
    82b8:	7100081f 	cmp	w0, #0x2
    82bc:	5400a600 	b.eq	977c <fwp_hof0.constprop.0+0x16bc>  // b.none
    82c0:	7100041f 	cmp	w0, #0x1
    82c4:	54000221 	b.ne	8308 <fwp_hof0.constprop.0+0x248>  // b.any
    82c8:	29430043 	ldp	w3, w0, [x2, #24]
    82cc:	92403c21 	and	x1, x1, #0xffff
    82d0:	9b037c21 	mul	x1, x1, x3
    82d4:	d360fc21 	lsr	x1, x1, #32
    82d8:	eb00003f 	cmp	x1, x0
    82dc:	54000162 	b.cs	8308 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    82e0:	8b010273 	add	x19, x19, x1
    82e4:	39400261 	ldrb	w1, [x19]
    82e8:	34000101 	cbz	w1, 8308 <fwp_hof0.constprop.0+0x248>
    82ec:	7100043f 	cmp	w1, #0x1
    82f0:	54007960 	b.eq	921c <fwp_hof0.constprop.0+0x115c>  // b.none
    82f4:	7103fc3f 	cmp	w1, #0xff
    82f8:	5400bd20 	b.eq	9a9c <fwp_hof0.constprop.0+0x19dc>  // b.none
    82fc:	51000421 	sub	w1, w1, #0x1
    8300:	39000261 	strb	w1, [x19]
    8304:	d503201f 	nop
    8308:	b40079b6 	cbz	x22, 923c <fwp_hof0.constprop.0+0x117c>
    830c:	aa1603e0 	mov	x0, x22
    8310:	d2800013 	mov	x19, #0x0                   	// #0
    8314:	d503201f 	nop
    8318:	f9400800 	ldr	x0, [x0, #16]
    831c:	91000673 	add	x19, x19, #0x1
    8320:	b5ffffc0 	cbnz	x0, 8318 <fwp_hof0.constprop.0+0x258>
    8324:	52800000 	mov	w0, #0x0                   	// #0
    8328:	97ffecd2 	bl	3670 <descent_phase_step>
    832c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8330:	eb00027f 	cmp	x19, x0
    8334:	5400c548 	b.hi	9bdc <fwp_hof0.constprop.0+0x1b1c>  // b.pmore
    8338:	9101c2b7 	add	x23, x21, #0x70
    833c:	b94346e0 	ldr	w0, [x23, #836]
    8340:	340078c0 	cbz	w0, 9258 <fwp_hof0.constprop.0+0x1198>
    8344:	9101c2a0 	add	x0, x21, #0x70
    8348:	f9404817 	ldr	x23, [x0, #144]
    834c:	f9407418 	ldr	x24, [x0, #232]
    8350:	eb17031f 	cmp	x24, x23
    8354:	540079aa 	b.ge	9288 <fwp_hof0.constprop.0+0x11c8>  // b.tcont
    8358:	f9403aa1 	ldr	x1, [x21, #112]
    835c:	8b180700 	add	x0, x24, x24, lsl #1
    8360:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8364:	8b000b00 	add	x0, x24, x0, lsl #2
    8368:	8b000c20 	add	x0, x1, x0, lsl #3
    836c:	d503201f 	nop
    8370:	b9400401 	ldr	w1, [x0, #4]
    8374:	35000081 	cbnz	w1, 8384 <fwp_hof0.constprop.0+0x2c4>
    8378:	b9400001 	ldr	w1, [x0]
    837c:	6b02003f 	cmp	w1, w2
    8380:	54007849 	b.ls	9288 <fwp_hof0.constprop.0+0x11c8>  // b.plast
    8384:	91000718 	add	x24, x24, #0x1
    8388:	9101a000 	add	x0, x0, #0x68
    838c:	eb17031f 	cmp	x24, x23
    8390:	54ffff01 	b.ne	8370 <fwp_hof0.constprop.0+0x2b0>  // b.any
    8394:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8398:	eb0002ff 	cmp	x23, x0
    839c:	5400c1ac 	b.gt	9bd0 <fwp_hof0.constprop.0+0x1b10>
    83a0:	9101c2a0 	add	x0, x21, #0x70
    83a4:	f9403ab9 	ldr	x25, [x21, #112]
    83a8:	f9407000 	ldr	x0, [x0, #224]
    83ac:	eb17001f 	cmp	x0, x23
    83b0:	54000201 	b.ne	83f0 <fwp_hof0.constprop.0+0x330>  // b.any
    83b4:	b400a897 	cbz	x23, 98c4 <fwp_hof0.constprop.0+0x1804>
    83b8:	d37ffafc 	lsl	x28, x23, #1
    83bc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    83c0:	eb00039f 	cmp	x28, x0
    83c4:	9a80d39c 	csel	x28, x28, x0, le
    83c8:	8b1c0781 	add	x1, x28, x28, lsl #1
    83cc:	8b010b81 	add	x1, x28, x1, lsl #2
    83d0:	d37df021 	lsl	x1, x1, #3
    83d4:	aa1903e0 	mov	x0, x25
    83d8:	97ffe94a 	bl	2900 <realloc@plt>
    83dc:	aa0003f9 	mov	x25, x0
    83e0:	b4003ac0 	cbz	x0, 8b38 <fwp_hof0.constprop.0+0xa78>
    83e4:	9101c2a0 	add	x0, x21, #0x70
    83e8:	f9003ab9 	str	x25, [x21, #112]
    83ec:	f900701c 	str	x28, [x0, #224]
    83f0:	8b1706e1 	add	x1, x23, x23, lsl #1
    83f4:	910006e2 	add	x2, x23, #0x1
    83f8:	4f000400 	movi	v0.4s, #0x0
    83fc:	9101c2a0 	add	x0, x21, #0x70
    8400:	8b010ae1 	add	x1, x23, x1, lsl #2
    8404:	8b180717 	add	x23, x24, x24, lsl #1
    8408:	8b170b17 	add	x23, x24, x23, lsl #2
    840c:	8b010f21 	add	x1, x25, x1, lsl #3
    8410:	f9004802 	str	x2, [x0, #144]
    8414:	b0000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    8418:	8b170f37 	add	x23, x25, x23, lsl #3
    841c:	91084000 	add	x0, x0, #0x210
    8420:	ad000020 	stp	q0, q0, [x1]
    8424:	ad010020 	stp	q0, q0, [x1, #32]
    8428:	ad020020 	stp	q0, q0, [x1, #64]
    842c:	f900303f 	str	xzr, [x1, #96]
    8430:	f90032ff 	str	xzr, [x23, #96]
    8434:	97ffe99b 	bl	2aa0 <getenv@plt>
    8438:	b40073e0 	cbz	x0, 92b4 <fwp_hof0.constprop.0+0x11f4>
    843c:	39400001 	ldrb	w1, [x0]
    8440:	7100c03f 	cmp	w1, #0x30
    8444:	54007381 	b.ne	92b4 <fwp_hof0.constprop.0+0x11f4>  // b.any
    8448:	39400400 	ldrb	w0, [x0, #1]
    844c:	35007340 	cbnz	w0, 92b4 <fwp_hof0.constprop.0+0x11f4>
    8450:	9101c2a0 	add	x0, x21, #0x70
    8454:	2f000400 	mvni	v0.2s, #0x0
    8458:	b94002e4 	ldr	w4, [x23]
    845c:	52800022 	mov	w2, #0x1                   	// #1
    8460:	91000705 	add	x5, x24, #0x1
    8464:	a900cef3 	stp	x19, x19, [x23, #8]
    8468:	0b020084 	add	w4, w4, w2
    846c:	f9418801 	ldr	x1, [x0, #784]
    8470:	29000ae4 	stp	w4, w2, [x23]
    8474:	f9002aff 	str	xzr, [x23, #80]
    8478:	f9007405 	str	x5, [x0, #232]
    847c:	fd002ee0 	str	d0, [x23, #88]
    8480:	b400bb41 	cbz	x1, 9be8 <fwp_hof0.constprop.0+0x1b28>
    8484:	d0ffffe0 	adrp	x0, 6000 <fwp_tape_finish+0xb0>
    8488:	91014003 	add	x3, x0, #0x50
    848c:	14000003 	b	8498 <fwp_hof0.constprop.0+0x3d8>
    8490:	f9400021 	ldr	x1, [x1]
    8494:	b400baa1 	cbz	x1, 9be8 <fwp_hof0.constprop.0+0x1b28>
    8498:	f9400422 	ldr	x2, [x1, #8]
    849c:	eb03005f 	cmp	x2, x3
    84a0:	54ffff81 	b.ne	8490 <fwp_hof0.constprop.0+0x3d0>  // b.any
    84a4:	f9400820 	ldr	x0, [x1, #16]
    84a8:	2a1803e2 	mov	w2, w24
    84ac:	b9400001 	ldr	w1, [x0]
    84b0:	f9002ae0 	str	x0, [x23, #80]
    84b4:	b9005ee1 	str	w1, [x23, #92]
    84b8:	37f80081 	tbnz	w1, #31, 84c8 <fwp_hof0.constprop.0+0x408>
    84bc:	52800d03 	mov	w3, #0x68                  	// #104
    84c0:	9b236421 	smaddl	x1, w1, w3, x25
    84c4:	b9005838 	str	w24, [x1, #88]
    84c8:	b9000002 	str	w2, [x0]
    84cc:	d3707c93 	ubfiz	x19, x4, #16, #32
    84d0:	52800020 	mov	w0, #0x1                   	// #1
    84d4:	aa050273 	orr	x19, x19, x5
    84d8:	97ffec66 	bl	3670 <descent_phase_step>
    84dc:	aa1603e0 	mov	x0, x22
    84e0:	d2800002 	mov	x2, #0x0                   	// #0
    84e4:	b4007796 	cbz	x22, 93d4 <fwp_hof0.constprop.0+0x1314>
    84e8:	f9400800 	ldr	x0, [x0, #16]
    84ec:	91000442 	add	x2, x2, #0x1
    84f0:	b5ffffc0 	cbnz	x0, 84e8 <fwp_hof0.constprop.0+0x428>
    84f4:	aa1603e1 	mov	x1, x22
    84f8:	f9400821 	ldr	x1, [x1, #16]
    84fc:	91000400 	add	x0, x0, #0x1
    8500:	b5ffffc1 	cbnz	x1, 84f8 <fwp_hof0.constprop.0+0x438>
    8504:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8508:	eb01001f 	cmp	x0, x1
    850c:	5400b468 	b.hi	9b98 <fwp_hof0.constprop.0+0x1ad8>  // b.pmore
    8510:	f100005f 	cmp	x2, #0x0
    8514:	5400760d 	b.le	93d4 <fwp_hof0.constprop.0+0x1314>
    8518:	eb00005f 	cmp	x2, x0
    851c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8520:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8524:	eb0102ff 	cmp	x23, x1
    8528:	5400b388 	b.hi	9b98 <fwp_hof0.constprop.0+0x1ad8>  // b.pmore
    852c:	d37ffaf8 	lsl	x24, x23, #1
    8530:	52800041 	mov	w1, #0x2                   	// #2
    8534:	91000700 	add	x0, x24, #0x1
    8538:	d37df000 	lsl	x0, x0, #3
    853c:	97fff28d 	bl	4f70 <fwp_heap_alloc>
    8540:	aa0003f9 	mov	x25, x0
    8544:	91174281 	add	x1, x20, #0x5d0
    8548:	aa0003fc 	mov	x28, x0
    854c:	aa0103e0 	mov	x0, x1
    8550:	f9000338 	str	x24, [x25]
    8554:	f949d821 	ldr	x1, [x1, #5040]
    8558:	f949ec00 	ldr	x0, [x0, #5080]
    855c:	cb010321 	sub	x1, x25, x1
    8560:	eb00403f 	cmp	x1, x0, lsl #16
    8564:	54008562 	b.cs	9610 <fwp_hof0.constprop.0+0x1550>  // b.hs, b.nlast
    8568:	91174282 	add	x2, x20, #0x5d0
    856c:	d350fc20 	lsr	x0, x1, #16
    8570:	8b000800 	add	x0, x0, x0, lsl #2
    8574:	f949fc43 	ldr	x3, [x2, #5112]
    8578:	d37df002 	lsl	x2, x0, #3
    857c:	8b020060 	add	x0, x3, x2
    8580:	f9401018 	ldr	x24, [x0, #32]
    8584:	b4000258 	cbz	x24, 85cc <fwp_hof0.constprop.0+0x50c>
    8588:	38626862 	ldrb	w2, [x3, x2]
    858c:	7100085f 	cmp	w2, #0x2
    8590:	54008fc0 	b.eq	9788 <fwp_hof0.constprop.0+0x16c8>  // b.none
    8594:	7100045f 	cmp	w2, #0x1
    8598:	540001a1 	b.ne	85cc <fwp_hof0.constprop.0+0x50c>  // b.any
    859c:	29430002 	ldp	w2, w0, [x0, #24]
    85a0:	92403c21 	and	x1, x1, #0xffff
    85a4:	9b027c21 	mul	x1, x1, x2
    85a8:	d360fc21 	lsr	x1, x1, #32
    85ac:	eb00003f 	cmp	x1, x0
    85b0:	540000e2 	b.cs	85cc <fwp_hof0.constprop.0+0x50c>  // b.hs, b.nlast
    85b4:	8b010318 	add	x24, x24, x1
    85b8:	39400300 	ldrb	w0, [x24]
    85bc:	7103fc1f 	cmp	w0, #0xff
    85c0:	54008ee0 	b.eq	979c <fwp_hof0.constprop.0+0x16dc>  // b.none
    85c4:	52800020 	mov	w0, #0x1                   	// #1
    85c8:	39000300 	strb	w0, [x24]
    85cc:	b4000237 	cbz	x23, 8610 <fwp_hof0.constprop.0+0x550>
    85d0:	d3607e64 	lsl	x4, x19, #32
    85d4:	aa1603e1 	mov	x1, x22
    85d8:	f94006c5 	ldr	x5, [x22, #8]
    85dc:	aa0403e3 	mov	x3, x4
    85e0:	91002322 	add	x2, x25, #0x8
    85e4:	d2800000 	mov	x0, #0x0                   	// #0
    85e8:	14000005 	b	85fc <fwp_hof0.constprop.0+0x53c>
    85ec:	f9400425 	ldr	x5, [x1, #8]
    85f0:	ab040003 	adds	x3, x0, x4
    85f4:	91004042 	add	x2, x2, #0x10
    85f8:	5400b0c6 	b.vs	9c10 <fwp_hof0.constprop.0+0x1b50>
    85fc:	a9000c45 	stp	x5, x3, [x2]
    8600:	91000400 	add	x0, x0, #0x1
    8604:	f9400821 	ldr	x1, [x1, #16]
    8608:	eb17001f 	cmp	x0, x23
    860c:	54ffff03 	b.cc	85ec <fwp_hof0.constprop.0+0x52c>  // b.lo, b.ul, b.last
    8610:	f9400320 	ldr	x0, [x25]
    8614:	f100041f 	cmp	x0, #0x1
    8618:	54008009 	b.ls	9618 <fwp_hof0.constprop.0+0x1558>  // b.plast
    861c:	d341fc00 	lsr	x0, x0, #1
    8620:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8624:	d1000418 	sub	x24, x0, #0x1
    8628:	eb01031f 	cmp	x24, x1
    862c:	5400ab68 	b.hi	9b98 <fwp_hof0.constprop.0+0x1ad8>  // b.pmore
    8630:	b4007f58 	cbz	x24, 9618 <fwp_hof0.constprop.0+0x1558>
    8634:	d1002321 	sub	x1, x25, #0x8
    8638:	9100233a 	add	x26, x25, #0x8
    863c:	8b001037 	add	x23, x1, x0, lsl #4
    8640:	f9400740 	ldr	x0, [x26, #8]
    8644:	f9400f41 	ldr	x1, [x26, #24]
    8648:	fd400340 	ldr	d0, [x26]
    864c:	fd400b41 	ldr	d1, [x26, #16]
    8650:	97fff388 	bl	5470 <w120>
    8654:	a9000740 	stp	x0, x1, [x26]
    8658:	9100435a 	add	x26, x26, #0x10
    865c:	eb17035f 	cmp	x26, x23
    8660:	54ffff01 	b.ne	8640 <fwp_hof0.constprop.0+0x580>  // b.any
    8664:	aa1903f7 	mov	x23, x25
    8668:	d37ffb18 	lsl	x24, x24, #1
    866c:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8670:	d280001a 	mov	x26, #0x0                   	// #0
    8674:	f80106f8 	str	x24, [x23], #16
    8678:	f87a7ae2 	ldr	x2, [x23, x26, lsl #3]
    867c:	aa0403e0 	mov	x0, x4
    8680:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    8684:	91000b5a 	add	x26, x26, #0x2
    8688:	aa0303e1 	mov	x1, x3
    868c:	97fff2c6 	bl	51a4 <fwp_p_ad_push>
    8690:	aa0003e4 	mov	x4, x0
    8694:	eb18035f 	cmp	x26, x24
    8698:	54ffff03 	b.cc	8678 <fwp_hof0.constprop.0+0x5b8>  // b.lo, b.ul, b.last
    869c:	91174297 	add	x23, x20, #0x5d0
    86a0:	f949dae1 	ldr	x1, [x23, #5040]
    86a4:	f949eee0 	ldr	x0, [x23, #5080]
    86a8:	cb010321 	sub	x1, x25, x1
    86ac:	eb00403f 	cmp	x1, x0, lsl #16
    86b0:	54000382 	b.cs	8720 <fwp_hof0.constprop.0+0x660>  // b.hs, b.nlast
    86b4:	d350fc20 	lsr	x0, x1, #16
    86b8:	f949fee5 	ldr	x5, [x23, #5112]
    86bc:	8b000800 	add	x0, x0, x0, lsl #2
    86c0:	d37df000 	lsl	x0, x0, #3
    86c4:	8b0000a2 	add	x2, x5, x0
    86c8:	f9401058 	ldr	x24, [x2, #32]
    86cc:	b40002b8 	cbz	x24, 8720 <fwp_hof0.constprop.0+0x660>
    86d0:	386068a0 	ldrb	w0, [x5, x0]
    86d4:	7100081f 	cmp	w0, #0x2
    86d8:	54007a60 	b.eq	9624 <fwp_hof0.constprop.0+0x1564>  // b.none
    86dc:	7100041f 	cmp	w0, #0x1
    86e0:	54000201 	b.ne	8720 <fwp_hof0.constprop.0+0x660>  // b.any
    86e4:	29430043 	ldp	w3, w0, [x2, #24]
    86e8:	92403c21 	and	x1, x1, #0xffff
    86ec:	9b037c21 	mul	x1, x1, x3
    86f0:	d360fc21 	lsr	x1, x1, #32
    86f4:	eb00003f 	cmp	x1, x0
    86f8:	54000142 	b.cs	8720 <fwp_hof0.constprop.0+0x660>  // b.hs, b.nlast
    86fc:	8b010318 	add	x24, x24, x1
    8700:	39400300 	ldrb	w0, [x24]
    8704:	340000e0 	cbz	w0, 8720 <fwp_hof0.constprop.0+0x660>
    8708:	7100041f 	cmp	w0, #0x1
    870c:	540022e0 	b.eq	8b68 <fwp_hof0.constprop.0+0xaa8>  // b.none
    8710:	7103fc1f 	cmp	w0, #0xff
    8714:	54009120 	b.eq	9938 <fwp_hof0.constprop.0+0x1878>  // b.none
    8718:	51000400 	sub	w0, w0, #0x1
    871c:	39000300 	strb	w0, [x24]
    8720:	52800040 	mov	w0, #0x2                   	// #2
    8724:	93407e7b 	sxtw	x27, w19
    8728:	f90003e4 	str	x4, [sp]
    872c:	97ffebd1 	bl	3670 <descent_phase_step>
    8730:	aa1b03e0 	mov	x0, x27
    8734:	97ffed1f 	bl	3bb0 <fwp_tape_of>
    8738:	f9403002 	ldr	x2, [x0, #96]
    873c:	aa0003e7 	mov	x7, x0
    8740:	f94003e4 	ldr	x4, [sp]
    8744:	b500a302 	cbnz	x2, 9ba4 <fwp_hof0.constprop.0+0x1ae4>
    8748:	f90003e4 	str	x4, [sp]
    874c:	97ffea31 	bl	3010 <fwp_tape_unlink_scope>
    8750:	b9400008 	ldr	w8, [x0]
    8754:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    8758:	a9408013 	ldp	x19, x0, [x0, #8]
    875c:	b90004ff 	str	wzr, [x7, #4]
    8760:	f94003e4 	ldr	x4, [sp]
    8764:	6b03011f 	cmp	w8, w3
    8768:	a941dcea 	ldp	x10, x23, [x7, #24]
    876c:	a942e4f8 	ldp	x24, x25, [x7, #40]
    8770:	a943e8fc 	ldp	x28, x26, [x7, #56]
    8774:	f94024e2 	ldr	x2, [x7, #72]
    8778:	54000108 	b.hi	8798 <fwp_hof0.constprop.0+0x6d8>  // b.pmore
    877c:	9101c2a8 	add	x8, x21, #0x70
    8780:	92403f63 	and	x3, x27, #0xffff
    8784:	d1000463 	sub	x3, x3, #0x1
    8788:	f9407509 	ldr	x9, [x8, #232]
    878c:	eb09007f 	cmp	x3, x9
    8790:	5400004a 	b.ge	8798 <fwp_hof0.constprop.0+0x6d8>  // b.tcont
    8794:	f9007503 	str	x3, [x8, #232]
    8798:	4f000400 	movi	v0.4s, #0x0
    879c:	9101c2a9 	add	x9, x21, #0x70
    87a0:	f9000cff 	str	xzr, [x7, #24]
    87a4:	910243e1 	add	x1, sp, #0x90
    87a8:	a9047cff 	stp	xzr, xzr, [x7, #64]
    87ac:	9101e3e3 	add	x3, sp, #0x78
    87b0:	90ffffe8 	adrp	x8, 4000 <fwp_format_g.constprop.0+0x3ec>
    87b4:	f941892b 	ldr	x11, [x9, #784]
    87b8:	3c8080e0 	stur	q0, [x7, #8]
    87bc:	91100108 	add	x8, x8, #0x400
    87c0:	ad0100e0 	stp	q0, q0, [x7, #32]
    87c4:	f9000be1 	str	x1, [sp, #16]
    87c8:	a907a3eb 	stp	x11, x8, [sp, #120]
    87cc:	a908dfe1 	stp	x1, x23, [sp, #136]
    87d0:	a909e7f8 	stp	x24, x25, [sp, #152]
    87d4:	a90aebfc 	stp	x28, x26, [sp, #168]
    87d8:	a90b8bea 	stp	x10, x2, [sp, #184]
    87dc:	f9018923 	str	x3, [x9, #784]
    87e0:	b7f87e44 	tbnz	x4, #63, 97a8 <fwp_hof0.constprop.0+0x16e8>
    87e4:	eb84837f 	cmp	x27, x4, asr #32
    87e8:	54009941 	b.ne	9b10 <fwp_hof0.constprop.0+0x1a50>  // b.any
    87ec:	92407c83 	and	x3, x4, #0xffffffff
    87f0:	eb24401f 	cmp	x0, w4, uxtw
    87f4:	5400988d 	b.le	9b04 <fwp_hof0.constprop.0+0x1a44>
    87f8:	eb03027f 	cmp	x19, x3
    87fc:	9a83c67b 	csinc	x27, x19, x3, gt
    8800:	eb1b005f 	cmp	x2, x27
    8804:	5400186a 	b.ge	8b10 <fwp_hof0.constprop.0+0xa50>  // b.tcont
    8808:	f100005f 	cmp	x2, #0x0
    880c:	9a9b1042 	csel	x2, x2, x27, ne	// ne = any
    8810:	14000005 	b	8824 <fwp_hof0.constprop.0+0x764>
    8814:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8818:	eb00005f 	cmp	x2, x0
    881c:	d37ff842 	lsl	x2, x2, #1
    8820:	9a9bd042 	csel	x2, x2, x27, le
    8824:	eb1b005f 	cmp	x2, x27
    8828:	54ffff6b 	b.lt	8814 <fwp_hof0.constprop.0+0x754>  // b.tstop
    882c:	f9001be4 	str	x4, [sp, #48]
    8830:	b40083ba 	cbz	x26, 98a4 <fwp_hof0.constprop.0+0x17e4>
    8834:	aa1a03e0 	mov	x0, x26
    8838:	d37df041 	lsl	x1, x2, #3
    883c:	f90003e2 	str	x2, [sp]
    8840:	97ffe830 	bl	2900 <realloc@plt>
    8844:	f94003e2 	ldr	x2, [sp]
    8848:	aa0003fa 	mov	x26, x0
    884c:	f9401be4 	ldr	x4, [sp, #48]
    8850:	b4009bda 	cbz	x26, 9bc8 <fwp_hof0.constprop.0+0x1b08>
    8854:	f9005bfa 	str	x26, [sp, #176]
    8858:	f90063e2 	str	x2, [sp, #192]
    885c:	b50014db 	cbnz	x27, 8af4 <fwp_hof0.constprop.0+0xa34>
    8860:	b7f800c4 	tbnz	x4, #63, 8878 <fwp_hof0.constprop.0+0x7b8>
    8864:	92407c80 	and	x0, x4, #0xffffffff
    8868:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    886c:	fc607b40 	ldr	d0, [x26, x0, lsl #3]
    8870:	1e612800 	fadd	d0, d0, d1
    8874:	fc207b40 	str	d0, [x26, x0, lsl #3]
    8878:	9101c2a1 	add	x1, x21, #0x70
    887c:	cb130364 	sub	x4, x27, x19
    8880:	52800060 	mov	w0, #0x3                   	// #3
    8884:	a9428827 	ldp	x7, x2, [x1, #40]
    8888:	8b070084 	add	x4, x4, x7
    888c:	8b130042 	add	x2, x2, x19
    8890:	a9028824 	stp	x4, x2, [x1, #40]
    8894:	97ffeb77 	bl	3670 <descent_phase_step>
    8898:	d1000763 	sub	x3, x27, #0x1
    889c:	d1000664 	sub	x4, x19, #0x1
    88a0:	eb03027f 	cmp	x19, x3
    88a4:	540003ac 	b.gt	8918 <fwp_hof0.constprop.0+0x858>
    88a8:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    88ac:	1e602008 	fcmp	d0, #0.0
    88b0:	540002e0 	b.eq	890c <fwp_hof0.constprop.0+0x84c>  // b.none
    88b4:	cb130be0 	neg	x0, x19, lsl #2
    88b8:	cb1303e2 	neg	x2, x19
    88bc:	8b0002e1 	add	x1, x23, x0
    88c0:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    88c4:	37f80101 	tbnz	w1, #31, 88e4 <fwp_hof0.constprop.0+0x824>
    88c8:	8b020f27 	add	x7, x25, x2, lsl #3
    88cc:	93407c21 	sxtw	x1, w1
    88d0:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    88d4:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    88d8:	1e620802 	fmul	d2, d0, d2
    88dc:	1e622821 	fadd	d1, d1, d2
    88e0:	fc217b41 	str	d1, [x26, x1, lsl #3]
    88e4:	8b000300 	add	x0, x24, x0
    88e8:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    88ec:	37f80100 	tbnz	w0, #31, 890c <fwp_hof0.constprop.0+0x84c>
    88f0:	8b020f82 	add	x2, x28, x2, lsl #3
    88f4:	93407c00 	sxtw	x0, w0
    88f8:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    88fc:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    8900:	1e620800 	fmul	d0, d0, d2
    8904:	1e602820 	fadd	d0, d1, d0
    8908:	fc207b40 	str	d0, [x26, x0, lsl #3]
    890c:	d1000463 	sub	x3, x3, #0x1
    8910:	eb03009f 	cmp	x4, x3
    8914:	54fffca1 	b.ne	88a8 <fwp_hof0.constprop.0+0x7e8>  // b.any
    8918:	52800080 	mov	w0, #0x4                   	// #4
    891c:	97ffeb55 	bl	3670 <descent_phase_step>
    8920:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8924:	eb00027f 	cmp	x19, x0
    8928:	540094a8 	b.hi	9bbc <fwp_hof0.constprop.0+0x1afc>  // b.pmore
    892c:	91000660 	add	x0, x19, #0x1
    8930:	52800041 	mov	w1, #0x2                   	// #2
    8934:	d37df000 	lsl	x0, x0, #3
    8938:	97fff18e 	bl	4f70 <fwp_heap_alloc>
    893c:	aa0003e2 	mov	x2, x0
    8940:	aa0003f7 	mov	x23, x0
    8944:	d2800001 	mov	x1, #0x0                   	// #0
    8948:	f8008453 	str	x19, [x2], #8
    894c:	b40000d3 	cbz	x19, 8964 <fwp_hof0.constprop.0+0x8a4>
    8950:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    8954:	f8217840 	str	x0, [x2, x1, lsl #3]
    8958:	91000421 	add	x1, x1, #0x1
    895c:	eb01027f 	cmp	x19, x1
    8960:	54ffff81 	b.ne	8950 <fwp_hof0.constprop.0+0x890>  // b.any
    8964:	528000a0 	mov	w0, #0x5                   	// #5
    8968:	97ffeb42 	bl	3670 <descent_phase_step>
    896c:	f9400be0 	ldr	x0, [sp, #16]
    8970:	9101c2a1 	add	x1, x21, #0x70
    8974:	f9403ff9 	ldr	x25, [sp, #120]
    8978:	f9018839 	str	x25, [x1, #784]
    897c:	97ffeea1 	bl	4400 <fwp_tape_buffers_release>
    8980:	528000c0 	mov	w0, #0x6                   	// #6
    8984:	97ffeb3b 	bl	3670 <descent_phase_step>
    8988:	91174282 	add	x2, x20, #0x5d0
    898c:	f949d841 	ldr	x1, [x2, #5040]
    8990:	f949ec40 	ldr	x0, [x2, #5080]
    8994:	cb0102e1 	sub	x1, x23, x1
    8998:	eb00403f 	cmp	x1, x0, lsl #16
    899c:	54000322 	b.cs	8a00 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    89a0:	d350fc20 	lsr	x0, x1, #16
    89a4:	f949fc43 	ldr	x3, [x2, #5112]
    89a8:	8b000800 	add	x0, x0, x0, lsl #2
    89ac:	d37df002 	lsl	x2, x0, #3
    89b0:	8b020060 	add	x0, x3, x2
    89b4:	f9401018 	ldr	x24, [x0, #32]
    89b8:	b4000258 	cbz	x24, 8a00 <fwp_hof0.constprop.0+0x940>
    89bc:	38626862 	ldrb	w2, [x3, x2]
    89c0:	7100085f 	cmp	w2, #0x2
    89c4:	54006f60 	b.eq	97b0 <fwp_hof0.constprop.0+0x16f0>  // b.none
    89c8:	7100045f 	cmp	w2, #0x1
    89cc:	540001a1 	b.ne	8a00 <fwp_hof0.constprop.0+0x940>  // b.any
    89d0:	29430002 	ldp	w2, w0, [x0, #24]
    89d4:	92403c21 	and	x1, x1, #0xffff
    89d8:	9b027c21 	mul	x1, x1, x2
    89dc:	d360fc21 	lsr	x1, x1, #32
    89e0:	eb00003f 	cmp	x1, x0
    89e4:	540000e2 	b.cs	8a00 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    89e8:	8b010318 	add	x24, x24, x1
    89ec:	39400300 	ldrb	w0, [x24]
    89f0:	7103fc1f 	cmp	w0, #0xff
    89f4:	54006e80 	b.eq	97c4 <fwp_hof0.constprop.0+0x1704>  // b.none
    89f8:	52800020 	mov	w0, #0x1                   	// #1
    89fc:	39000300 	strb	w0, [x24]
    8a00:	f94013e0 	ldr	x0, [sp, #32]
    8a04:	eb00033f 	cmp	x25, x0
    8a08:	54009061 	b.ne	9c14 <fwp_hof0.constprop.0+0x1b54>  // b.any
    8a0c:	f9400fe0 	ldr	x0, [sp, #24]
    8a10:	9101c2a1 	add	x1, x21, #0x70
    8a14:	f94033e2 	ldr	x2, [sp, #96]
    8a18:	f9018822 	str	x2, [x1, #784]
    8a1c:	97fff58d 	bl	6050 <fwp_tape_scope_release>
    8a20:	f94002e0 	ldr	x0, [x23]
    8a24:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    8a28:	b7f84700 	tbnz	x0, #63, 9308 <fwp_hof0.constprop.0+0x1248>
    8a2c:	91174282 	add	x2, x20, #0x5d0
    8a30:	f949d840 	ldr	x0, [x2, #5040]
    8a34:	f949ec41 	ldr	x1, [x2, #5080]
    8a38:	cb0002e0 	sub	x0, x23, x0
    8a3c:	eb01401f 	cmp	x0, x1, lsl #16
    8a40:	54004642 	b.cs	9308 <fwp_hof0.constprop.0+0x1248>  // b.hs, b.nlast
    8a44:	d350fc01 	lsr	x1, x0, #16
    8a48:	f949fc44 	ldr	x4, [x2, #5112]
    8a4c:	8b010821 	add	x1, x1, x1, lsl #2
    8a50:	d37df021 	lsl	x1, x1, #3
    8a54:	8b010083 	add	x3, x4, x1
    8a58:	f9401062 	ldr	x2, [x3, #32]
    8a5c:	b4004562 	cbz	x2, 9308 <fwp_hof0.constprop.0+0x1248>
    8a60:	38616881 	ldrb	w1, [x4, x1]
    8a64:	7100083f 	cmp	w1, #0x2
    8a68:	540044a0 	b.eq	92fc <fwp_hof0.constprop.0+0x123c>  // b.none
    8a6c:	7100043f 	cmp	w1, #0x1
    8a70:	540044c1 	b.ne	9308 <fwp_hof0.constprop.0+0x1248>  // b.any
    8a74:	29430464 	ldp	w4, w1, [x3, #24]
    8a78:	92403c00 	and	x0, x0, #0xffff
    8a7c:	9b047c00 	mul	x0, x0, x4
    8a80:	d360fc00 	lsr	x0, x0, #32
    8a84:	eb01001f 	cmp	x0, x1
    8a88:	54004402 	b.cs	9308 <fwp_hof0.constprop.0+0x1248>  // b.hs, b.nlast
    8a8c:	8b000042 	add	x2, x2, x0
    8a90:	39400040 	ldrb	w0, [x2]
    8a94:	7100041f 	cmp	w0, #0x1
    8a98:	54004381 	b.ne	9308 <fwp_hof0.constprop.0+0x1248>  // b.any
    8a9c:	aa1703fc 	mov	x28, x23
    8aa0:	d2800000 	mov	x0, #0x0                   	// #0
    8aa4:	f90003f7 	str	x23, [sp]
    8aa8:	f94003e1 	ldr	x1, [sp]
    8aac:	910022e5 	add	x5, x23, #0x8
    8ab0:	91002023 	add	x3, x1, #0x8
    8ab4:	d2800001 	mov	x1, #0x0                   	// #0
    8ab8:	b5000159 	cbnz	x25, 8ae0 <fwp_hof0.constprop.0+0xa20>
    8abc:	1400004e 	b	8bf4 <fwp_hof0.constprop.0+0xb34>
    8ac0:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8ac4:	f9400382 	ldr	x2, [x28]
    8ac8:	1e600900 	fmul	d0, d8, d0
    8acc:	b7f88602 	tbnz	x2, #63, 9b8c <fwp_hof0.constprop.0+0x1acc>
    8ad0:	91000421 	add	x1, x1, #0x1
    8ad4:	fc008460 	str	d0, [x3], #8
    8ad8:	eb01033f 	cmp	x25, x1
    8adc:	540008c0 	b.eq	8bf4 <fwp_hof0.constprop.0+0xb34>  // b.none
    8ae0:	f94002e4 	ldr	x4, [x23]
    8ae4:	aa0503e2 	mov	x2, x5
    8ae8:	b6fffec4 	tbz	x4, #63, 8ac0 <fwp_hof0.constprop.0+0xa00>
    8aec:	f9400ae2 	ldr	x2, [x23, #16]
    8af0:	17fffff4 	b	8ac0 <fwp_hof0.constprop.0+0xa00>
    8af4:	d37df362 	lsl	x2, x27, #3
    8af8:	aa1a03e0 	mov	x0, x26
    8afc:	52800001 	mov	w1, #0x0                   	// #0
    8b00:	f90003e4 	str	x4, [sp]
    8b04:	97ffe777 	bl	28e0 <memset@plt>
    8b08:	f94003e4 	ldr	x4, [sp]
    8b0c:	17ffff55 	b	8860 <fwp_hof0.constprop.0+0x7a0>
    8b10:	f100035f 	cmp	x26, #0x0
    8b14:	1a9f17e0 	cset	w0, eq	// eq = none
    8b18:	f100037f 	cmp	x27, #0x0
    8b1c:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8b20:	54ffe9e0 	b.eq	885c <fwp_hof0.constprop.0+0x79c>  // b.none
    8b24:	f9400be0 	ldr	x0, [sp, #16]
    8b28:	9101c2b5 	add	x21, x21, #0x70
    8b2c:	f9403fe1 	ldr	x1, [sp, #120]
    8b30:	f9018aa1 	str	x1, [x21, #784]
    8b34:	97ffee33 	bl	4400 <fwp_tape_buffers_release>
    8b38:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    8b3c:	f947e863 	ldr	x3, [x3, #4048]
    8b40:	d2800262 	mov	x2, #0x13                  	// #19
    8b44:	d2800021 	mov	x1, #0x1                   	// #1
    8b48:	90000020 	adrp	x0, c000 <f0+0x23e0>
    8b4c:	913ca000 	add	x0, x0, #0xf28
    8b50:	f9400063 	ldr	x3, [x3]
    8b54:	97ffe7af 	bl	2a10 <fwrite@plt>
    8b58:	d2800000 	mov	x0, #0x0                   	// #0
    8b5c:	97ffe7b9 	bl	2a40 <fflush@plt>
    8b60:	52800cc0 	mov	w0, #0x66                  	// #102
    8b64:	97ffe7c7 	bl	2a80 <_Exit@plt>
    8b68:	f9400386 	ldr	x6, [x28]
    8b6c:	aa1c03e0 	mov	x0, x28
    8b70:	f949eee3 	ldr	x3, [x23, #5080]
    8b74:	f949dae1 	ldr	x1, [x23, #5040]
    8b78:	d370bc63 	lsl	x3, x3, #16
    8b7c:	cb010382 	sub	x2, x28, x1
    8b80:	b7f855e6 	tbnz	x6, #63, 963c <fwp_hof0.constprop.0+0x157c>
    8b84:	eb02007f 	cmp	x3, x2
    8b88:	54ffdcc9 	b.ls	8720 <fwp_hof0.constprop.0+0x660>  // b.plast
    8b8c:	d350fc40 	lsr	x0, x2, #16
    8b90:	8b000800 	add	x0, x0, x0, lsl #2
    8b94:	d37df000 	lsl	x0, x0, #3
    8b98:	8b0000a3 	add	x3, x5, x0
    8b9c:	f9401061 	ldr	x1, [x3, #32]
    8ba0:	b4ffdc01 	cbz	x1, 8720 <fwp_hof0.constprop.0+0x660>
    8ba4:	386068a0 	ldrb	w0, [x5, x0]
    8ba8:	7100081f 	cmp	w0, #0x2
    8bac:	54006120 	b.eq	97d0 <fwp_hof0.constprop.0+0x1710>  // b.none
    8bb0:	7100041f 	cmp	w0, #0x1
    8bb4:	54ffdb61 	b.ne	8720 <fwp_hof0.constprop.0+0x660>  // b.any
    8bb8:	92403c40 	and	x0, x2, #0xffff
    8bbc:	29430865 	ldp	w5, w2, [x3, #24]
    8bc0:	9b057c00 	mul	x0, x0, x5
    8bc4:	d360fc00 	lsr	x0, x0, #32
    8bc8:	eb02001f 	cmp	x0, x2
    8bcc:	54ffdaa2 	b.cs	8720 <fwp_hof0.constprop.0+0x660>  // b.hs, b.nlast
    8bd0:	8b000021 	add	x1, x1, x0
    8bd4:	39400020 	ldrb	w0, [x1]
    8bd8:	7100041f 	cmp	w0, #0x1
    8bdc:	54ffda21 	b.ne	8720 <fwp_hof0.constprop.0+0x660>  // b.any
    8be0:	aa1c03e0 	mov	x0, x28
    8be4:	f90003e4 	str	x4, [sp]
    8be8:	97ffefc2 	bl	4af0 <fwp_mem_free>
    8bec:	f94003e4 	ldr	x4, [sp]
    8bf0:	17fffecc 	b	8720 <fwp_hof0.constprop.0+0x660>
    8bf4:	97fff703 	bl	6800 <fwp_drop10>
    8bf8:	aa1603e1 	mov	x1, x22
    8bfc:	d2800002 	mov	x2, #0x0                   	// #0
    8c00:	b4006696 	cbz	x22, 98d0 <fwp_hof0.constprop.0+0x1810>
    8c04:	d503201f 	nop
    8c08:	f9400821 	ldr	x1, [x1, #16]
    8c0c:	91000442 	add	x2, x2, #0x1
    8c10:	b5ffffc1 	cbnz	x1, 8c08 <fwp_hof0.constprop.0+0xb48>
    8c14:	f9400380 	ldr	x0, [x28]
    8c18:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    8c1c:	b7f82c40 	tbnz	x0, #63, 91a4 <fwp_hof0.constprop.0+0x10e4>
    8c20:	91174283 	add	x3, x20, #0x5d0
    8c24:	f94003e4 	ldr	x4, [sp]
    8c28:	f949d861 	ldr	x1, [x3, #5040]
    8c2c:	f949ec63 	ldr	x3, [x3, #5080]
    8c30:	cb010081 	sub	x1, x4, x1
    8c34:	eb03403f 	cmp	x1, x3, lsl #16
    8c38:	54002b62 	b.cs	91a4 <fwp_hof0.constprop.0+0x10e4>  // b.hs, b.nlast
    8c3c:	91174284 	add	x4, x20, #0x5d0
    8c40:	d350fc23 	lsr	x3, x1, #16
    8c44:	8b030863 	add	x3, x3, x3, lsl #2
    8c48:	f949fc87 	ldr	x7, [x4, #5112]
    8c4c:	d37df063 	lsl	x3, x3, #3
    8c50:	8b0300e6 	add	x6, x7, x3
    8c54:	f94010c4 	ldr	x4, [x6, #32]
    8c58:	b4002a44 	cbz	x4, 91a0 <fwp_hof0.constprop.0+0x10e0>
    8c5c:	386368e3 	ldrb	w3, [x7, x3]
    8c60:	7100087f 	cmp	w3, #0x2
    8c64:	540029a0 	b.eq	9198 <fwp_hof0.constprop.0+0x10d8>  // b.none
    8c68:	7100047f 	cmp	w3, #0x1
    8c6c:	540029a1 	b.ne	91a0 <fwp_hof0.constprop.0+0x10e0>  // b.any
    8c70:	29430cc7 	ldp	w7, w3, [x6, #24]
    8c74:	92403c21 	and	x1, x1, #0xffff
    8c78:	9b077c21 	mul	x1, x1, x7
    8c7c:	d360fc21 	lsr	x1, x1, #32
    8c80:	eb03003f 	cmp	x1, x3
    8c84:	540028e2 	b.cs	91a0 <fwp_hof0.constprop.0+0x10e0>  // b.hs, b.nlast
    8c88:	8b010084 	add	x4, x4, x1
    8c8c:	39400081 	ldrb	w1, [x4]
    8c90:	7100043f 	cmp	w1, #0x1
    8c94:	54002861 	b.ne	91a0 <fwp_hof0.constprop.0+0x10e0>  // b.any
    8c98:	b90033e1 	str	w1, [sp, #48]
    8c9c:	eb05005f 	cmp	x2, x5
    8ca0:	9a859045 	csel	x5, x2, x5, ls	// ls = plast
    8ca4:	91002393 	add	x19, x28, #0x8
    8ca8:	b4006f45 	cbz	x5, 9a90 <fwp_hof0.constprop.0+0x19d0>
    8cac:	f94003e1 	ldr	x1, [sp]
    8cb0:	d37df0a7 	lsl	x7, x5, #3
    8cb4:	aa1603e2 	mov	x2, x22
    8cb8:	91002026 	add	x6, x1, #0x8
    8cbc:	d2800001 	mov	x1, #0x0                   	// #0
    8cc0:	1400000a 	b	8ce8 <fwp_hof0.constprop.0+0xc28>
    8cc4:	fc616881 	ldr	d1, [x4, x1]
    8cc8:	fd400440 	ldr	d0, [x2, #8]
    8ccc:	1e613800 	fsub	d0, d0, d1
    8cd0:	fc216a60 	str	d0, [x19, x1]
    8cd4:	91002021 	add	x1, x1, #0x8
    8cd8:	f9400842 	ldr	x2, [x2, #16]
    8cdc:	eb07003f 	cmp	x1, x7
    8ce0:	540001c0 	b.eq	8d18 <fwp_hof0.constprop.0+0xc58>  // b.none
    8ce4:	f9400380 	ldr	x0, [x28]
    8ce8:	aa0603e4 	mov	x4, x6
    8cec:	b6fffec0 	tbz	x0, #63, 8cc4 <fwp_hof0.constprop.0+0xc04>
    8cf0:	f94003e0 	ldr	x0, [sp]
    8cf4:	fd400440 	ldr	d0, [x2, #8]
    8cf8:	f9400804 	ldr	x4, [x0, #16]
    8cfc:	fc616881 	ldr	d1, [x4, x1]
    8d00:	1e613800 	fsub	d0, d0, d1
    8d04:	fc216a60 	str	d0, [x19, x1]
    8d08:	91002021 	add	x1, x1, #0x8
    8d0c:	f9400842 	ldr	x2, [x2, #16]
    8d10:	eb07003f 	cmp	x1, x7
    8d14:	54fffe81 	b.ne	8ce4 <fwp_hof0.constprop.0+0xc24>  // b.any
    8d18:	b4006f36 	cbz	x22, 9afc <fwp_hof0.constprop.0+0x1a3c>
    8d1c:	91174280 	add	x0, x20, #0x5d0
    8d20:	aa1603e7 	mov	x7, x22
    8d24:	d2800019 	mov	x25, #0x0                   	// #0
    8d28:	f949ec09 	ldr	x9, [x0, #5080]
    8d2c:	f949d80a 	ldr	x10, [x0, #5040]
    8d30:	f949fc08 	ldr	x8, [x0, #5112]
    8d34:	d370bd29 	lsl	x9, x9, #16
    8d38:	14000006 	b	8d50 <fwp_hof0.constprop.0+0xc90>
    8d3c:	f94008e7 	ldr	x7, [x7, #16]
    8d40:	91000739 	add	x25, x25, #0x1
    8d44:	f10000ff 	cmp	x7, #0x0
    8d48:	fa5910a0 	ccmp	x5, x25, #0x0, ne	// ne = any
    8d4c:	54003329 	b.ls	93b0 <fwp_hof0.constprop.0+0x12f0>  // b.plast
    8d50:	cb0a00e0 	sub	x0, x7, x10
    8d54:	eb09001f 	cmp	x0, x9
    8d58:	540002c2 	b.cs	8db0 <fwp_hof0.constprop.0+0xcf0>  // b.hs, b.nlast
    8d5c:	d350fc01 	lsr	x1, x0, #16
    8d60:	8b010821 	add	x1, x1, x1, lsl #2
    8d64:	d37df021 	lsl	x1, x1, #3
    8d68:	8b010106 	add	x6, x8, x1
    8d6c:	f94010c2 	ldr	x2, [x6, #32]
    8d70:	b4000202 	cbz	x2, 8db0 <fwp_hof0.constprop.0+0xcf0>
    8d74:	38616901 	ldrb	w1, [x8, x1]
    8d78:	7100083f 	cmp	w1, #0x2
    8d7c:	54000e20 	b.eq	8f40 <fwp_hof0.constprop.0+0xe80>  // b.none
    8d80:	7100043f 	cmp	w1, #0x1
    8d84:	54000161 	b.ne	8db0 <fwp_hof0.constprop.0+0xcf0>  // b.any
    8d88:	294304cb 	ldp	w11, w1, [x6, #24]
    8d8c:	92403c00 	and	x0, x0, #0xffff
    8d90:	9b0b7c00 	mul	x0, x0, x11
    8d94:	d360fc00 	lsr	x0, x0, #32
    8d98:	eb01001f 	cmp	x0, x1
    8d9c:	540000a2 	b.cs	8db0 <fwp_hof0.constprop.0+0xcf0>  // b.hs, b.nlast
    8da0:	8b000042 	add	x2, x2, x0
    8da4:	39400040 	ldrb	w0, [x2]
    8da8:	7100041f 	cmp	w0, #0x1
    8dac:	54fffc80 	b.eq	8d3c <fwp_hof0.constprop.0+0xc7c>  // b.none
    8db0:	eb05033f 	cmp	x25, x5
    8db4:	54000ce2 	b.cs	8f50 <fwp_hof0.constprop.0+0xe90>  // b.hs, b.nlast
    8db8:	aa0503f8 	mov	x24, x5
    8dbc:	d100227a 	sub	x26, x19, #0x8
    8dc0:	910323f7 	add	x23, sp, #0xc8
    8dc4:	9117429b 	add	x27, x20, #0x5d0
    8dc8:	d280001c 	mov	x28, #0x0                   	// #0
    8dcc:	14000012 	b	8e14 <fwp_hof0.constprop.0+0xd54>
    8dd0:	7100045f 	cmp	w2, #0x1
    8dd4:	540001a1 	b.ne	8e08 <fwp_hof0.constprop.0+0xd48>  // b.any
    8dd8:	29430909 	ldp	w9, w2, [x8, #24]
    8ddc:	92403c21 	and	x1, x1, #0xffff
    8de0:	9b097c21 	mul	x1, x1, x9
    8de4:	d360fc21 	lsr	x1, x1, #32
    8de8:	eb02003f 	cmp	x1, x2
    8dec:	540000e2 	b.cs	8e08 <fwp_hof0.constprop.0+0xd48>  // b.hs, b.nlast
    8df0:	8b010000 	add	x0, x0, x1
    8df4:	39400001 	ldrb	w1, [x0]
    8df8:	7103fc3f 	cmp	w1, #0xff
    8dfc:	54003080 	b.eq	940c <fwp_hof0.constprop.0+0x134c>  // b.none
    8e00:	52800021 	mov	w1, #0x1                   	// #1
    8e04:	39000001 	strb	w1, [x0]
    8e08:	d1000718 	sub	x24, x24, #0x1
    8e0c:	eb18033f 	cmp	x25, x24
    8e10:	54000382 	b.cs	8e80 <fwp_hof0.constprop.0+0xdc0>  // b.hs, b.nlast
    8e14:	f8787b42 	ldr	x2, [x26, x24, lsl #3]
    8e18:	aa1703e1 	mov	x1, x23
    8e1c:	52800020 	mov	w0, #0x1                   	// #1
    8e20:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8e24:	97fff098 	bl	5084 <fwp_data.part.0.constprop.0>
    8e28:	aa0003fc 	mov	x28, x0
    8e2c:	f949db61 	ldr	x1, [x27, #5040]
    8e30:	f949ef60 	ldr	x0, [x27, #5080]
    8e34:	cb010381 	sub	x1, x28, x1
    8e38:	eb00403f 	cmp	x1, x0, lsl #16
    8e3c:	54fffe62 	b.cs	8e08 <fwp_hof0.constprop.0+0xd48>  // b.hs, b.nlast
    8e40:	d350fc20 	lsr	x0, x1, #16
    8e44:	f949ff69 	ldr	x9, [x27, #5112]
    8e48:	8b000800 	add	x0, x0, x0, lsl #2
    8e4c:	d37df002 	lsl	x2, x0, #3
    8e50:	8b020128 	add	x8, x9, x2
    8e54:	f9401100 	ldr	x0, [x8, #32]
    8e58:	b4fffd80 	cbz	x0, 8e08 <fwp_hof0.constprop.0+0xd48>
    8e5c:	38626922 	ldrb	w2, [x9, x2]
    8e60:	7100085f 	cmp	w2, #0x2
    8e64:	54fffb61 	b.ne	8dd0 <fwp_hof0.constprop.0+0xd10>  // b.any
    8e68:	72003c3f 	tst	w1, #0xffff
    8e6c:	54fffc40 	b.eq	8df4 <fwp_hof0.constprop.0+0xd34>  // b.none
    8e70:	d1000718 	sub	x24, x24, #0x1
    8e74:	eb18033f 	cmp	x25, x24
    8e78:	54fffce3 	b.cc	8e14 <fwp_hof0.constprop.0+0xd54>  // b.lo, b.ul, b.last
    8e7c:	d503201f 	nop
    8e80:	b50006b9 	cbnz	x25, 8f54 <fwp_hof0.constprop.0+0xe94>
    8e84:	b94033e0 	ldr	w0, [sp, #48]
    8e88:	d2800004 	mov	x4, #0x0                   	// #0
    8e8c:	7100001f 	cmp	w0, #0x0
    8e90:	d2800020 	mov	x0, #0x1                   	// #1
    8e94:	9a9f0273 	csel	x19, x19, xzr, eq	// eq = none
    8e98:	b40007c4 	cbz	x4, 8f90 <fwp_hof0.constprop.0+0xed0>
    8e9c:	d1000499 	sub	x25, x4, #0x1
    8ea0:	2a0003fa 	mov	w26, w0
    8ea4:	9117429b 	add	x27, x20, #0x5d0
    8ea8:	f8797a62 	ldr	x2, [x19, x25, lsl #3]
    8eac:	aa1703e1 	mov	x1, x23
    8eb0:	52800020 	mov	w0, #0x1                   	// #1
    8eb4:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8eb8:	97fff073 	bl	5084 <fwp_data.part.0.constprop.0>
    8ebc:	aa0003fc 	mov	x28, x0
    8ec0:	f949db61 	ldr	x1, [x27, #5040]
    8ec4:	f949ef60 	ldr	x0, [x27, #5080]
    8ec8:	cb010381 	sub	x1, x28, x1
    8ecc:	eb00403f 	cmp	x1, x0, lsl #16
    8ed0:	54000302 	b.cs	8f30 <fwp_hof0.constprop.0+0xe70>  // b.hs, b.nlast
    8ed4:	d350fc22 	lsr	x2, x1, #16
    8ed8:	f949ff67 	ldr	x7, [x27, #5112]
    8edc:	8b020842 	add	x2, x2, x2, lsl #2
    8ee0:	d37df042 	lsl	x2, x2, #3
    8ee4:	8b0200e6 	add	x6, x7, x2
    8ee8:	f94010d8 	ldr	x24, [x6, #32]
    8eec:	b4000238 	cbz	x24, 8f30 <fwp_hof0.constprop.0+0xe70>
    8ef0:	386268e2 	ldrb	w2, [x7, x2]
    8ef4:	7100085f 	cmp	w2, #0x2
    8ef8:	540014a0 	b.eq	918c <fwp_hof0.constprop.0+0x10cc>  // b.none
    8efc:	7100045f 	cmp	w2, #0x1
    8f00:	54000181 	b.ne	8f30 <fwp_hof0.constprop.0+0xe70>  // b.any
    8f04:	294308c7 	ldp	w7, w2, [x6, #24]
    8f08:	92403c21 	and	x1, x1, #0xffff
    8f0c:	9b077c21 	mul	x1, x1, x7
    8f10:	d360fc21 	lsr	x1, x1, #32
    8f14:	eb02003f 	cmp	x1, x2
    8f18:	540000c2 	b.cs	8f30 <fwp_hof0.constprop.0+0xe70>  // b.hs, b.nlast
    8f1c:	8b010318 	add	x24, x24, x1
    8f20:	39400301 	ldrb	w1, [x24]
    8f24:	7103fc3f 	cmp	w1, #0xff
    8f28:	540012c0 	b.eq	9180 <fwp_hof0.constprop.0+0x10c0>  // b.none
    8f2c:	3900031a 	strb	w26, [x24]
    8f30:	d1000739 	sub	x25, x25, #0x1
    8f34:	b100073f 	cmn	x25, #0x1
    8f38:	54fffb81 	b.ne	8ea8 <fwp_hof0.constprop.0+0xde8>  // b.any
    8f3c:	14000015 	b	8f90 <fwp_hof0.constprop.0+0xed0>
    8f40:	72003c1f 	tst	w0, #0xffff
    8f44:	54fff300 	b.eq	8da4 <fwp_hof0.constprop.0+0xce4>  // b.none
    8f48:	eb05033f 	cmp	x25, x5
    8f4c:	54fff363 	b.cc	8db8 <fwp_hof0.constprop.0+0xcf8>  // b.lo, b.ul, b.last
    8f50:	d280001c 	mov	x28, #0x0                   	// #0
    8f54:	8b190e64 	add	x4, x19, x25, lsl #3
    8f58:	aa1303e1 	mov	x1, x19
    8f5c:	aa1603e0 	mov	x0, x22
    8f60:	f8408422 	ldr	x2, [x1], #8
    8f64:	f9000402 	str	x2, [x0, #8]
    8f68:	aa0003e2 	mov	x2, x0
    8f6c:	f9400800 	ldr	x0, [x0, #16]
    8f70:	eb04003f 	cmp	x1, x4
    8f74:	54ffff61 	b.ne	8f60 <fwp_hof0.constprop.0+0xea0>  // b.any
    8f78:	b94033e1 	ldr	w1, [sp, #48]
    8f7c:	f900085c 	str	x28, [x2, #16]
    8f80:	aa1603fc 	mov	x28, x22
    8f84:	aa0003f6 	mov	x22, x0
    8f88:	34000041 	cbz	w1, 8f90 <fwp_hof0.constprop.0+0xed0>
    8f8c:	d2800013 	mov	x19, #0x0                   	// #0
    8f90:	91174297 	add	x23, x20, #0x5d0
    8f94:	aa1303e0 	mov	x0, x19
    8f98:	97ffeed6 	bl	4af0 <fwp_mem_free>
    8f9c:	f94003e0 	ldr	x0, [sp]
    8fa0:	f949eee2 	ldr	x2, [x23, #5080]
    8fa4:	f949dae1 	ldr	x1, [x23, #5040]
    8fa8:	d370bc42 	lsl	x2, x2, #16
    8fac:	cb010003 	sub	x3, x0, x1
    8fb0:	eb03005f 	cmp	x2, x3
    8fb4:	54000429 	b.ls	9038 <fwp_hof0.constprop.0+0xf78>  // b.plast
    8fb8:	d350fc60 	lsr	x0, x3, #16
    8fbc:	f949fee5 	ldr	x5, [x23, #5112]
    8fc0:	8b000800 	add	x0, x0, x0, lsl #2
    8fc4:	d37df000 	lsl	x0, x0, #3
    8fc8:	8b0000a2 	add	x2, x5, x0
    8fcc:	f9401059 	ldr	x25, [x2, #32]
    8fd0:	b4000cf9 	cbz	x25, 916c <fwp_hof0.constprop.0+0x10ac>
    8fd4:	386068a1 	ldrb	w1, [x5, x0]
    8fd8:	7100083f 	cmp	w1, #0x2
    8fdc:	540032a0 	b.eq	9630 <fwp_hof0.constprop.0+0x1570>  // b.none
    8fe0:	7100043f 	cmp	w1, #0x1
    8fe4:	54000c41 	b.ne	916c <fwp_hof0.constprop.0+0x10ac>  // b.any
    8fe8:	29430844 	ldp	w4, w2, [x2, #24]
    8fec:	92403c61 	and	x1, x3, #0xffff
    8ff0:	9b047c21 	mul	x1, x1, x4
    8ff4:	d360fc21 	lsr	x1, x1, #32
    8ff8:	eb02003f 	cmp	x1, x2
    8ffc:	54000b82 	b.cs	916c <fwp_hof0.constprop.0+0x10ac>  // b.hs, b.nlast
    9000:	8b010339 	add	x25, x25, x1
    9004:	39400321 	ldrb	w1, [x25]
    9008:	34000b21 	cbz	w1, 916c <fwp_hof0.constprop.0+0x10ac>
    900c:	7100043f 	cmp	w1, #0x1
    9010:	540006c0 	b.eq	90e8 <fwp_hof0.constprop.0+0x1028>  // b.none
    9014:	7103fc3f 	cmp	w1, #0xff
    9018:	54004c60 	b.eq	99a4 <fwp_hof0.constprop.0+0x18e4>  // b.none
    901c:	91174280 	add	x0, x20, #0x5d0
    9020:	51000421 	sub	w1, w1, #0x1
    9024:	39000321 	strb	w1, [x25]
    9028:	f949ec02 	ldr	x2, [x0, #5080]
    902c:	f949d801 	ldr	x1, [x0, #5040]
    9030:	d370bc42 	lsl	x2, x2, #16
    9034:	d503201f 	nop
    9038:	cb0102c1 	sub	x1, x22, x1
    903c:	eb02003f 	cmp	x1, x2
    9040:	540003c2 	b.cs	90b8 <fwp_hof0.constprop.0+0xff8>  // b.hs, b.nlast
    9044:	91174298 	add	x24, x20, #0x5d0
    9048:	d350fc20 	lsr	x0, x1, #16
    904c:	f949ff03 	ldr	x3, [x24, #5112]
    9050:	8b000800 	add	x0, x0, x0, lsl #2
    9054:	d37df000 	lsl	x0, x0, #3
    9058:	8b000062 	add	x2, x3, x0
    905c:	f9401057 	ldr	x23, [x2, #32]
    9060:	b40002d7 	cbz	x23, 90b8 <fwp_hof0.constprop.0+0xff8>
    9064:	38606860 	ldrb	w0, [x3, x0]
    9068:	7100081f 	cmp	w0, #0x2
    906c:	540032e0 	b.eq	96c8 <fwp_hof0.constprop.0+0x1608>  // b.none
    9070:	7100041f 	cmp	w0, #0x1
    9074:	54000221 	b.ne	90b8 <fwp_hof0.constprop.0+0xff8>  // b.any
    9078:	29430044 	ldp	w4, w0, [x2, #24]
    907c:	92403c21 	and	x1, x1, #0xffff
    9080:	9b047c21 	mul	x1, x1, x4
    9084:	d360fc21 	lsr	x1, x1, #32
    9088:	eb00003f 	cmp	x1, x0
    908c:	54000162 	b.cs	90b8 <fwp_hof0.constprop.0+0xff8>  // b.hs, b.nlast
    9090:	8b0102f7 	add	x23, x23, x1
    9094:	394002e0 	ldrb	w0, [x23]
    9098:	34000100 	cbz	w0, 90b8 <fwp_hof0.constprop.0+0xff8>
    909c:	7100041f 	cmp	w0, #0x1
    90a0:	540039e0 	b.eq	97dc <fwp_hof0.constprop.0+0x171c>  // b.none
    90a4:	7103fc1f 	cmp	w0, #0xff
    90a8:	54004b80 	b.eq	9a18 <fwp_hof0.constprop.0+0x1958>  // b.none
    90ac:	51000400 	sub	w0, w0, #0x1
    90b0:	390002e0 	strb	w0, [x23]
    90b4:	d503201f 	nop
    90b8:	f94007e0 	ldr	x0, [sp, #8]
    90bc:	b4001b00 	cbz	x0, 941c <fwp_hof0.constprop.0+0x135c>
    90c0:	f94007e0 	ldr	x0, [sp, #8]
    90c4:	f100041b 	subs	x27, x0, #0x1
    90c8:	f90007fb 	str	x27, [sp, #8]
    90cc:	54005a26 	b.vs	9c10 <fwp_hof0.constprop.0+0x1b50>
    90d0:	91174280 	add	x0, x20, #0x5d0
    90d4:	aa1c03f6 	mov	x22, x28
    90d8:	f949ec03 	ldr	x3, [x0, #5080]
    90dc:	f949d801 	ldr	x1, [x0, #5040]
    90e0:	d370bc63 	lsl	x3, x3, #16
    90e4:	17fffc3d 	b	81d8 <fwp_hof0.constprop.0+0x118>
    90e8:	f94003e4 	ldr	x4, [sp]
    90ec:	f949eee2 	ldr	x2, [x23, #5080]
    90f0:	aa0403e0 	mov	x0, x4
    90f4:	f9400083 	ldr	x3, [x4]
    90f8:	f949dae1 	ldr	x1, [x23, #5040]
    90fc:	d370bc42 	lsl	x2, x2, #16
    9100:	cb010087 	sub	x7, x4, x1
    9104:	b7f82e83 	tbnz	x3, #63, 96d4 <fwp_hof0.constprop.0+0x1614>
    9108:	eb07005f 	cmp	x2, x7
    910c:	54fff969 	b.ls	9038 <fwp_hof0.constprop.0+0xf78>  // b.plast
    9110:	d350fce3 	lsr	x3, x7, #16
    9114:	8b030863 	add	x3, x3, x3, lsl #2
    9118:	d37df063 	lsl	x3, x3, #3
    911c:	8b0300a6 	add	x6, x5, x3
    9120:	f94010c4 	ldr	x4, [x6, #32]
    9124:	b4fff8a4 	cbz	x4, 9038 <fwp_hof0.constprop.0+0xf78>
    9128:	386368a3 	ldrb	w3, [x5, x3]
    912c:	7100087f 	cmp	w3, #0x2
    9130:	54003a60 	b.eq	987c <fwp_hof0.constprop.0+0x17bc>  // b.none
    9134:	7100047f 	cmp	w3, #0x1
    9138:	54fff801 	b.ne	9038 <fwp_hof0.constprop.0+0xf78>  // b.any
    913c:	29430cc5 	ldp	w5, w3, [x6, #24]
    9140:	92403ce0 	and	x0, x7, #0xffff
    9144:	9b057c00 	mul	x0, x0, x5
    9148:	d360fc00 	lsr	x0, x0, #32
    914c:	eb03001f 	cmp	x0, x3
    9150:	54fff742 	b.cs	9038 <fwp_hof0.constprop.0+0xf78>  // b.hs, b.nlast
    9154:	8b000084 	add	x4, x4, x0
    9158:	39400080 	ldrb	w0, [x4]
    915c:	7100041f 	cmp	w0, #0x1
    9160:	54fff6c1 	b.ne	9038 <fwp_hof0.constprop.0+0xf78>  // b.any
    9164:	f94003e0 	ldr	x0, [sp]
    9168:	97ffee62 	bl	4af0 <fwp_mem_free>
    916c:	91174280 	add	x0, x20, #0x5d0
    9170:	f949ec02 	ldr	x2, [x0, #5080]
    9174:	f949d801 	ldr	x1, [x0, #5040]
    9178:	d370bc42 	lsl	x2, x2, #16
    917c:	17ffffaf 	b	9038 <fwp_hof0.constprop.0+0xf78>
    9180:	aa1803e0 	mov	x0, x24
    9184:	97ffedbb 	bl	4870 <fwp_rc_forget_slot>
    9188:	17ffff69 	b	8f2c <fwp_hof0.constprop.0+0xe6c>
    918c:	72003c3f 	tst	w1, #0xffff
    9190:	54ffed01 	b.ne	8f30 <fwp_hof0.constprop.0+0xe70>  // b.any
    9194:	17ffff63 	b	8f20 <fwp_hof0.constprop.0+0xe60>
    9198:	72003c3f 	tst	w1, #0xffff
    919c:	54ffd780 	b.eq	8c8c <fwp_hof0.constprop.0+0xbcc>  // b.none
    91a0:	b40010f6 	cbz	x22, 93bc <fwp_hof0.constprop.0+0x12fc>
    91a4:	aa1603f7 	mov	x23, x22
    91a8:	d2800019 	mov	x25, #0x0                   	// #0
    91ac:	d503201f 	nop
    91b0:	f9400af7 	ldr	x23, [x23, #16]
    91b4:	aa1903e0 	mov	x0, x25
    91b8:	91000739 	add	x25, x25, #0x1
    91bc:	b5ffffb7 	cbnz	x23, 91b0 <fwp_hof0.constprop.0+0x10f0>
    91c0:	f9001be5 	str	x5, [sp, #48]
    91c4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    91c8:	eb01033f 	cmp	x25, x1
    91cc:	54004e68 	b.hi	9b98 <fwp_hof0.constprop.0+0x1ad8>  // b.pmore
    91d0:	91000800 	add	x0, x0, #0x2
    91d4:	52800041 	mov	w1, #0x2                   	// #2
    91d8:	d37df000 	lsl	x0, x0, #3
    91dc:	97ffef65 	bl	4f70 <fwp_heap_alloc>
    91e0:	f9401be5 	ldr	x5, [sp, #48]
    91e4:	aa0003f3 	mov	x19, x0
    91e8:	aa1603e1 	mov	x1, x22
    91ec:	eb1900bf 	cmp	x5, x25
    91f0:	9a9990a5 	csel	x5, x5, x25, ls	// ls = plast
    91f4:	d503201f 	nop
    91f8:	f9400420 	ldr	x0, [x1, #8]
    91fc:	f8377a60 	str	x0, [x19, x23, lsl #3]
    9200:	910006f7 	add	x23, x23, #0x1
    9204:	f9400821 	ldr	x1, [x1, #16]
    9208:	b5ffff81 	cbnz	x1, 91f8 <fwp_hof0.constprop.0+0x1138>
    920c:	b4000e05 	cbz	x5, 93cc <fwp_hof0.constprop.0+0x130c>
    9210:	f9400380 	ldr	x0, [x28]
    9214:	b90033ff 	str	wzr, [sp, #48]
    9218:	17fffea5 	b	8cac <fwp_hof0.constprop.0+0xbec>
    921c:	d53bd040 	mrs	x0, tpidr_el0
    9220:	91400000 	add	x0, x0, #0x0, lsl #12
    9224:	91004000 	add	x0, x0, #0x10
    9228:	f9400000 	ldr	x0, [x0]
    922c:	b40029a0 	cbz	x0, 9760 <fwp_hof0.constprop.0+0x16a0>
    9230:	f94017e1 	ldr	x1, [sp, #40]
    9234:	97ffe9ac 	bl	38e4 <fwp_closure_drop_push>
    9238:	b5ff86b6 	cbnz	x22, 830c <fwp_hof0.constprop.0+0x24c>
    923c:	9101c2b7 	add	x23, x21, #0x70
    9240:	52800000 	mov	w0, #0x0                   	// #0
    9244:	97ffe90b 	bl	3670 <descent_phase_step>
    9248:	d2800013 	mov	x19, #0x0                   	// #0
    924c:	b94346e0 	ldr	w0, [x23, #836]
    9250:	35ff87a0 	cbnz	w0, 8344 <fwp_hof0.constprop.0+0x284>
    9254:	d503201f 	nop
    9258:	90ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0x90>
    925c:	913d4000 	add	x0, x0, #0xf50
    9260:	94000f24 	bl	cef0 <atexit>
    9264:	35ffc6a0 	cbnz	w0, 8b38 <fwp_hof0.constprop.0+0xa78>
    9268:	52800020 	mov	w0, #0x1                   	// #1
    926c:	b90346e0 	str	w0, [x23, #836]
    9270:	9101c2a0 	add	x0, x21, #0x70
    9274:	f9404817 	ldr	x23, [x0, #144]
    9278:	f9407418 	ldr	x24, [x0, #232]
    927c:	eb17031f 	cmp	x24, x23
    9280:	54ff86cb 	b.lt	8358 <fwp_hof0.constprop.0+0x298>  // b.tstop
    9284:	d503201f 	nop
    9288:	eb17031f 	cmp	x24, x23
    928c:	54ff8840 	b.eq	8394 <fwp_hof0.constprop.0+0x2d4>  // b.none
    9290:	f9403ab9 	ldr	x25, [x21, #112]
    9294:	8b180717 	add	x23, x24, x24, lsl #1
    9298:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    929c:	91084000 	add	x0, x0, #0x210
    92a0:	8b170b17 	add	x23, x24, x23, lsl #2
    92a4:	8b170f37 	add	x23, x25, x23, lsl #3
    92a8:	f90032ff 	str	xzr, [x23, #96]
    92ac:	97ffe5fd 	bl	2aa0 <getenv@plt>
    92b0:	b5ff8c60 	cbnz	x0, 843c <fwp_hof0.constprop.0+0x37c>
    92b4:	9101c2a0 	add	x0, x21, #0x70
    92b8:	f9406801 	ldr	x1, [x0, #208]
    92bc:	b4ff8ca1 	cbz	x1, 8450 <fwp_hof0.constprop.0+0x390>
    92c0:	3cc98002 	ldur	q2, [x0, #152]
    92c4:	91026001 	add	x1, x0, #0x98
    92c8:	3cca8001 	ldur	q1, [x0, #168]
    92cc:	f900681f 	str	xzr, [x0, #208]
    92d0:	4f000400 	movi	v0.4s, #0x0
    92d4:	ad0106e2 	stp	q2, q1, [x23, #32]
    92d8:	a94b8002 	ldp	x2, x0, [x0, #184]
    92dc:	f9000ee0 	str	x0, [x23, #24]
    92e0:	f9401820 	ldr	x0, [x1, #48]
    92e4:	f90022e2 	str	x2, [x23, #64]
    92e8:	f90026e0 	str	x0, [x23, #72]
    92ec:	ad000020 	stp	q0, q0, [x1]
    92f0:	3d800820 	str	q0, [x1, #32]
    92f4:	f900183f 	str	xzr, [x1, #48]
    92f8:	17fffc56 	b	8450 <fwp_hof0.constprop.0+0x390>
    92fc:	72003c1f 	tst	w0, #0xffff
    9300:	54ffbc80 	b.eq	8a90 <fwp_hof0.constprop.0+0x9d0>  // b.none
    9304:	d503201f 	nop
    9308:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    930c:	eb00033f 	cmp	x25, x0
    9310:	54004568 	b.hi	9bbc <fwp_hof0.constprop.0+0x1afc>  // b.pmore
    9314:	91000720 	add	x0, x25, #0x1
    9318:	52800021 	mov	w1, #0x1                   	// #1
    931c:	d37df000 	lsl	x0, x0, #3
    9320:	97ffef14 	bl	4f70 <fwp_heap_alloc>
    9324:	91174282 	add	x2, x20, #0x5d0
    9328:	f9000019 	str	x25, [x0]
    932c:	aa0003fc 	mov	x28, x0
    9330:	f90003fc 	str	x28, [sp]
    9334:	f949d841 	ldr	x1, [x2, #5040]
    9338:	f949ec40 	ldr	x0, [x2, #5080]
    933c:	cb010381 	sub	x1, x28, x1
    9340:	eb00403f 	cmp	x1, x0, lsl #16
    9344:	54000322 	b.cs	93a8 <fwp_hof0.constprop.0+0x12e8>  // b.hs, b.nlast
    9348:	d350fc20 	lsr	x0, x1, #16
    934c:	f949fc44 	ldr	x4, [x2, #5112]
    9350:	8b000800 	add	x0, x0, x0, lsl #2
    9354:	d37df002 	lsl	x2, x0, #3
    9358:	8b020083 	add	x3, x4, x2
    935c:	f9401073 	ldr	x19, [x3, #32]
    9360:	b4000253 	cbz	x19, 93a8 <fwp_hof0.constprop.0+0x12e8>
    9364:	38626882 	ldrb	w2, [x4, x2]
    9368:	7100085f 	cmp	w2, #0x2
    936c:	540028e0 	b.eq	9888 <fwp_hof0.constprop.0+0x17c8>  // b.none
    9370:	7100045f 	cmp	w2, #0x1
    9374:	540001a1 	b.ne	93a8 <fwp_hof0.constprop.0+0x12e8>  // b.any
    9378:	29430864 	ldp	w4, w2, [x3, #24]
    937c:	92403c21 	and	x1, x1, #0xffff
    9380:	9b047c21 	mul	x1, x1, x4
    9384:	d360fc21 	lsr	x1, x1, #32
    9388:	eb02003f 	cmp	x1, x2
    938c:	540000e2 	b.cs	93a8 <fwp_hof0.constprop.0+0x12e8>  // b.hs, b.nlast
    9390:	8b010273 	add	x19, x19, x1
    9394:	39400261 	ldrb	w1, [x19]
    9398:	7103fc3f 	cmp	w1, #0xff
    939c:	540027e0 	b.eq	9898 <fwp_hof0.constprop.0+0x17d8>  // b.none
    93a0:	52800021 	mov	w1, #0x1                   	// #1
    93a4:	39000261 	strb	w1, [x19]
    93a8:	aa1703e0 	mov	x0, x23
    93ac:	17fffdbf 	b	8aa8 <fwp_hof0.constprop.0+0x9e8>
    93b0:	eb1900bf 	cmp	x5, x25
    93b4:	54ffd028 	b.hi	8db8 <fwp_hof0.constprop.0+0xcf8>  // b.pmore
    93b8:	17fffee6 	b	8f50 <fwp_hof0.constprop.0+0xe90>
    93bc:	52800041 	mov	w1, #0x2                   	// #2
    93c0:	d2800100 	mov	x0, #0x8                   	// #8
    93c4:	97ffeeeb 	bl	4f70 <fwp_heap_alloc>
    93c8:	aa0003f3 	mov	x19, x0
    93cc:	d280001c 	mov	x28, #0x0                   	// #0
    93d0:	17fffef0 	b	8f90 <fwp_hof0.constprop.0+0xed0>
    93d4:	52800041 	mov	w1, #0x2                   	// #2
    93d8:	d2800100 	mov	x0, #0x8                   	// #8
    93dc:	97ffeee5 	bl	4f70 <fwp_heap_alloc>
    93e0:	aa0003f9 	mov	x25, x0
    93e4:	91174280 	add	x0, x20, #0x5d0
    93e8:	aa1903fc 	mov	x28, x25
    93ec:	f900033f 	str	xzr, [x25]
    93f0:	f949d801 	ldr	x1, [x0, #5040]
    93f4:	f949ec00 	ldr	x0, [x0, #5080]
    93f8:	cb010321 	sub	x1, x25, x1
    93fc:	eb00403f 	cmp	x1, x0, lsl #16
    9400:	540010c2 	b.cs	9618 <fwp_hof0.constprop.0+0x1558>  // b.hs, b.nlast
    9404:	d2800017 	mov	x23, #0x0                   	// #0
    9408:	17fffc58 	b	8568 <fwp_hof0.constprop.0+0x4a8>
    940c:	f9001fe0 	str	x0, [sp, #56]
    9410:	97ffed18 	bl	4870 <fwp_rc_forget_slot>
    9414:	f9401fe0 	ldr	x0, [sp, #56]
    9418:	17fffe7a 	b	8e00 <fwp_hof0.constprop.0+0xd40>
    941c:	f9400be0 	ldr	x0, [sp, #16]
    9420:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xef20>
    9424:	910aa042 	add	x2, x2, #0x2a8
    9428:	aa1c03e1 	mov	x1, x28
    942c:	91014042 	add	x2, x2, #0x50
    9430:	52800023 	mov	w3, #0x1                   	// #1
    9434:	a9097fff 	stp	xzr, xzr, [sp, #144]
    9438:	f90053ff 	str	xzr, [sp, #160]
    943c:	97fff725 	bl	70d0 <fwp_write>
    9440:	a9495ff6 	ldp	x22, x23, [sp, #144]
    9444:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9448:	9129c000 	add	x0, x0, #0xa70
    944c:	f10002df 	cmp	x22, #0x0
    9450:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9454:	b1002aff 	cmn	x23, #0xa
    9458:	54003ac8 	b.hi	9bb0 <fwp_hof0.constprop.0+0x1af0>  // b.pmore
    945c:	910026e0 	add	x0, x23, #0x9
    9460:	52800021 	mov	w1, #0x1                   	// #1
    9464:	97ffeec3 	bl	4f70 <fwp_heap_alloc>
    9468:	aa0003f8 	mov	x24, x0
    946c:	aa0003f3 	mov	x19, x0
    9470:	aa1703e2 	mov	x2, x23
    9474:	aa1603e1 	mov	x1, x22
    9478:	f8008717 	str	x23, [x24], #8
    947c:	8b170277 	add	x23, x19, x23
    9480:	aa1803e0 	mov	x0, x24
    9484:	97ffe4b7 	bl	2760 <memcpy@plt>
    9488:	390022ff 	strb	wzr, [x23, #8]
    948c:	f9404be0 	ldr	x0, [sp, #144]
    9490:	97ffe550 	bl	29d0 <free@plt>
    9494:	91174281 	add	x1, x20, #0x5d0
    9498:	f949d822 	ldr	x2, [x1, #5040]
    949c:	f949ec20 	ldr	x0, [x1, #5080]
    94a0:	cb020262 	sub	x2, x19, x2
    94a4:	eb00405f 	cmp	x2, x0, lsl #16
    94a8:	54000322 	b.cs	950c <fwp_hof0.constprop.0+0x144c>  // b.hs, b.nlast
    94ac:	d350fc40 	lsr	x0, x2, #16
    94b0:	f949fc23 	ldr	x3, [x1, #5112]
    94b4:	8b000800 	add	x0, x0, x0, lsl #2
    94b8:	d37df001 	lsl	x1, x0, #3
    94bc:	8b010060 	add	x0, x3, x1
    94c0:	f9401016 	ldr	x22, [x0, #32]
    94c4:	b4000256 	cbz	x22, 950c <fwp_hof0.constprop.0+0x144c>
    94c8:	38616861 	ldrb	w1, [x3, x1]
    94cc:	7100083f 	cmp	w1, #0x2
    94d0:	54002d00 	b.eq	9a70 <fwp_hof0.constprop.0+0x19b0>  // b.none
    94d4:	7100043f 	cmp	w1, #0x1
    94d8:	540001a1 	b.ne	950c <fwp_hof0.constprop.0+0x144c>  // b.any
    94dc:	29430003 	ldp	w3, w0, [x0, #24]
    94e0:	92403c41 	and	x1, x2, #0xffff
    94e4:	9b037c21 	mul	x1, x1, x3
    94e8:	d360fc21 	lsr	x1, x1, #32
    94ec:	eb00003f 	cmp	x1, x0
    94f0:	540000e2 	b.cs	950c <fwp_hof0.constprop.0+0x144c>  // b.hs, b.nlast
    94f4:	8b0102d6 	add	x22, x22, x1
    94f8:	394002c0 	ldrb	w0, [x22]
    94fc:	7103fc1f 	cmp	w0, #0xff
    9500:	54002c20 	b.eq	9a84 <fwp_hof0.constprop.0+0x19c4>  // b.none
    9504:	52800020 	mov	w0, #0x1                   	// #1
    9508:	390002c0 	strb	w0, [x22]
    950c:	9101c2b6 	add	x22, x21, #0x70
    9510:	aa1c03e0 	mov	x0, x28
    9514:	97fff19b 	bl	5b80 <fwp_drop0>
    9518:	f9400262 	ldr	x2, [x19]
    951c:	d2800021 	mov	x1, #0x1                   	// #1
    9520:	f94006c3 	ldr	x3, [x22, #8]
    9524:	aa1803e0 	mov	x0, x24
    9528:	97ffe53a 	bl	2a10 <fwrite@plt>
    952c:	f94006c1 	ldr	x1, [x22, #8]
    9530:	52800140 	mov	w0, #0xa                   	// #10
    9534:	97ffe4bf 	bl	2830 <fputc@plt>
    9538:	91174281 	add	x1, x20, #0x5d0
    953c:	f949d822 	ldr	x2, [x1, #5040]
    9540:	f949ec20 	ldr	x0, [x1, #5080]
    9544:	cb020262 	sub	x2, x19, x2
    9548:	eb00405f 	cmp	x2, x0, lsl #16
    954c:	54000382 	b.cs	95bc <fwp_hof0.constprop.0+0x14fc>  // b.hs, b.nlast
    9550:	d350fc40 	lsr	x0, x2, #16
    9554:	f949fc23 	ldr	x3, [x1, #5112]
    9558:	8b000800 	add	x0, x0, x0, lsl #2
    955c:	d37df001 	lsl	x1, x0, #3
    9560:	8b010060 	add	x0, x3, x1
    9564:	f9401016 	ldr	x22, [x0, #32]
    9568:	b40002b6 	cbz	x22, 95bc <fwp_hof0.constprop.0+0x14fc>
    956c:	38616861 	ldrb	w1, [x3, x1]
    9570:	7100083f 	cmp	w1, #0x2
    9574:	540024c0 	b.eq	9a0c <fwp_hof0.constprop.0+0x194c>  // b.none
    9578:	7100043f 	cmp	w1, #0x1
    957c:	54000201 	b.ne	95bc <fwp_hof0.constprop.0+0x14fc>  // b.any
    9580:	29430003 	ldp	w3, w0, [x0, #24]
    9584:	92403c41 	and	x1, x2, #0xffff
    9588:	9b037c21 	mul	x1, x1, x3
    958c:	d360fc21 	lsr	x1, x1, #32
    9590:	eb00003f 	cmp	x1, x0
    9594:	54000142 	b.cs	95bc <fwp_hof0.constprop.0+0x14fc>  // b.hs, b.nlast
    9598:	8b0102d6 	add	x22, x22, x1
    959c:	394002c0 	ldrb	w0, [x22]
    95a0:	340000e0 	cbz	w0, 95bc <fwp_hof0.constprop.0+0x14fc>
    95a4:	7100041f 	cmp	w0, #0x1
    95a8:	54001aa0 	b.eq	98fc <fwp_hof0.constprop.0+0x183c>  // b.none
    95ac:	7103fc1f 	cmp	w0, #0xff
    95b0:	54002b60 	b.eq	9b1c <fwp_hof0.constprop.0+0x1a5c>  // b.none
    95b4:	51000400 	sub	w0, w0, #0x1
    95b8:	390002c0 	strb	w0, [x22]
    95bc:	f94027e0 	ldr	x0, [sp, #72]
    95c0:	f9400800 	ldr	x0, [x0, #16]
    95c4:	f90027e0 	str	x0, [sp, #72]
    95c8:	b5ff5b60 	cbnz	x0, 8134 <fwp_hof0.constprop.0+0x74>
    95cc:	a94f53f3 	ldp	x19, x20, [sp, #240]
    95d0:	a9505bf5 	ldp	x21, x22, [sp, #256]
    95d4:	a95163f7 	ldp	x23, x24, [sp, #272]
    95d8:	a9526bf9 	ldp	x25, x26, [sp, #288]
    95dc:	a95373fb 	ldp	x27, x28, [sp, #304]
    95e0:	fd40a3e8 	ldr	d8, [sp, #320]
    95e4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    95e8:	f947f400 	ldr	x0, [x0, #4072]
    95ec:	f9406fe2 	ldr	x2, [sp, #216]
    95f0:	f9400001 	ldr	x1, [x0]
    95f4:	eb010042 	subs	x2, x2, x1
    95f8:	d2800001 	mov	x1, #0x0                   	// #0
    95fc:	54002fc1 	b.ne	9bf4 <fwp_hof0.constprop.0+0x1b34>  // b.any
    9600:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    9604:	d2800000 	mov	x0, #0x0                   	// #0
    9608:	910543ff 	add	sp, sp, #0x150
    960c:	d65f03c0 	ret
    9610:	b5ff7e17 	cbnz	x23, 85d0 <fwp_hof0.constprop.0+0x510>
    9614:	d503201f 	nop
    9618:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    961c:	f900033f 	str	xzr, [x25]
    9620:	17fffc1f 	b	869c <fwp_hof0.constprop.0+0x5dc>
    9624:	72003c3f 	tst	w1, #0xffff
    9628:	54ff87c1 	b.ne	8720 <fwp_hof0.constprop.0+0x660>  // b.any
    962c:	17fffc35 	b	8700 <fwp_hof0.constprop.0+0x640>
    9630:	72003c7f 	tst	w3, #0xffff
    9634:	54ffd9c1 	b.ne	916c <fwp_hof0.constprop.0+0x10ac>  // b.any
    9638:	17fffe73 	b	9004 <fwp_hof0.constprop.0+0xf44>
    963c:	f940079c 	ldr	x28, [x28, #8]
    9640:	eb02007f 	cmp	x3, x2
    9644:	540003a9 	b.ls	96b8 <fwp_hof0.constprop.0+0x15f8>  // b.plast
    9648:	d350fc46 	lsr	x6, x2, #16
    964c:	8b0608c6 	add	x6, x6, x6, lsl #2
    9650:	d37df0c6 	lsl	x6, x6, #3
    9654:	8b0600a8 	add	x8, x5, x6
    9658:	f9401107 	ldr	x7, [x8, #32]
    965c:	b40002e7 	cbz	x7, 96b8 <fwp_hof0.constprop.0+0x15f8>
    9660:	386668a5 	ldrb	w5, [x5, x6]
    9664:	710008bf 	cmp	w5, #0x2
    9668:	54001500 	b.eq	9908 <fwp_hof0.constprop.0+0x1848>  // b.none
    966c:	710004bf 	cmp	w5, #0x1
    9670:	54000241 	b.ne	96b8 <fwp_hof0.constprop.0+0x15f8>  // b.any
    9674:	29431506 	ldp	w6, w5, [x8, #24]
    9678:	92403c42 	and	x2, x2, #0xffff
    967c:	9b067c42 	mul	x2, x2, x6
    9680:	d360fc42 	lsr	x2, x2, #32
    9684:	eb05005f 	cmp	x2, x5
    9688:	54000182 	b.cs	96b8 <fwp_hof0.constprop.0+0x15f8>  // b.hs, b.nlast
    968c:	8b0200e7 	add	x7, x7, x2
    9690:	394000e2 	ldrb	w2, [x7]
    9694:	7100045f 	cmp	w2, #0x1
    9698:	54000101 	b.ne	96b8 <fwp_hof0.constprop.0+0x15f8>  // b.any
    969c:	f90003e4 	str	x4, [sp]
    96a0:	97ffed14 	bl	4af0 <fwp_mem_free>
    96a4:	91174280 	add	x0, x20, #0x5d0
    96a8:	f94003e4 	ldr	x4, [sp]
    96ac:	f949ec03 	ldr	x3, [x0, #5080]
    96b0:	f949d801 	ldr	x1, [x0, #5040]
    96b4:	d370bc63 	lsl	x3, x3, #16
    96b8:	cb010381 	sub	x1, x28, x1
    96bc:	eb03003f 	cmp	x1, x3
    96c0:	54ff7fa3 	b.cc	86b4 <fwp_hof0.constprop.0+0x5f4>  // b.lo, b.ul, b.last
    96c4:	17fffc17 	b	8720 <fwp_hof0.constprop.0+0x660>
    96c8:	72003c3f 	tst	w1, #0xffff
    96cc:	54ffcf61 	b.ne	90b8 <fwp_hof0.constprop.0+0xff8>  // b.any
    96d0:	17fffe71 	b	9094 <fwp_hof0.constprop.0+0xfd4>
    96d4:	f9400483 	ldr	x3, [x4, #8]
    96d8:	f90003e3 	str	x3, [sp]
    96dc:	eb07005f 	cmp	x2, x7
    96e0:	54000369 	b.ls	974c <fwp_hof0.constprop.0+0x168c>  // b.plast
    96e4:	d350fce3 	lsr	x3, x7, #16
    96e8:	8b030863 	add	x3, x3, x3, lsl #2
    96ec:	d37df063 	lsl	x3, x3, #3
    96f0:	8b0300a6 	add	x6, x5, x3
    96f4:	f94010c4 	ldr	x4, [x6, #32]
    96f8:	b40002a4 	cbz	x4, 974c <fwp_hof0.constprop.0+0x168c>
    96fc:	386368a3 	ldrb	w3, [x5, x3]
    9700:	7100087f 	cmp	w3, #0x2
    9704:	54001080 	b.eq	9914 <fwp_hof0.constprop.0+0x1854>  // b.none
    9708:	7100047f 	cmp	w3, #0x1
    970c:	54000201 	b.ne	974c <fwp_hof0.constprop.0+0x168c>  // b.any
    9710:	294314c8 	ldp	w8, w5, [x6, #24]
    9714:	92403ce3 	and	x3, x7, #0xffff
    9718:	9b087c63 	mul	x3, x3, x8
    971c:	d360fc63 	lsr	x3, x3, #32
    9720:	eb05007f 	cmp	x3, x5
    9724:	54000142 	b.cs	974c <fwp_hof0.constprop.0+0x168c>  // b.hs, b.nlast
    9728:	8b030084 	add	x4, x4, x3
    972c:	39400083 	ldrb	w3, [x4]
    9730:	7100047f 	cmp	w3, #0x1
    9734:	540000c1 	b.ne	974c <fwp_hof0.constprop.0+0x168c>  // b.any
    9738:	97ffecee 	bl	4af0 <fwp_mem_free>
    973c:	91174280 	add	x0, x20, #0x5d0
    9740:	f949ec02 	ldr	x2, [x0, #5080]
    9744:	f949d801 	ldr	x1, [x0, #5040]
    9748:	d370bc42 	lsl	x2, x2, #16
    974c:	f94003e0 	ldr	x0, [sp]
    9750:	cb010003 	sub	x3, x0, x1
    9754:	eb03005f 	cmp	x2, x3
    9758:	54ffc308 	b.hi	8fb8 <fwp_hof0.constprop.0+0xef8>  // b.pmore
    975c:	17fffe37 	b	9038 <fwp_hof0.constprop.0+0xf78>
    9760:	f94017e0 	ldr	x0, [sp, #40]
    9764:	97ffe8cf 	bl	3aa0 <fwp_closure_drop.part.0>
    9768:	17fffae8 	b	8308 <fwp_hof0.constprop.0+0x248>
    976c:	72003c3f 	tst	w1, #0xffff
    9770:	54ff5a21 	b.ne	82b4 <fwp_hof0.constprop.0+0x1f4>  // b.any
    9774:	aa1303e0 	mov	x0, x19
    9778:	17fffabc 	b	8268 <fwp_hof0.constprop.0+0x1a8>
    977c:	72003c3f 	tst	w1, #0xffff
    9780:	54ff5c41 	b.ne	8308 <fwp_hof0.constprop.0+0x248>  // b.any
    9784:	17fffad8 	b	82e4 <fwp_hof0.constprop.0+0x224>
    9788:	72003c3f 	tst	w1, #0xffff
    978c:	54ff7201 	b.ne	85cc <fwp_hof0.constprop.0+0x50c>  // b.any
    9790:	39400300 	ldrb	w0, [x24]
    9794:	7103fc1f 	cmp	w0, #0xff
    9798:	54ff7161 	b.ne	85c4 <fwp_hof0.constprop.0+0x504>  // b.any
    979c:	aa1803e0 	mov	x0, x24
    97a0:	97ffec34 	bl	4870 <fwp_rc_forget_slot>
    97a4:	17fffb88 	b	85c4 <fwp_hof0.constprop.0+0x504>
    97a8:	aa1303fb 	mov	x27, x19
    97ac:	17fffc15 	b	8800 <fwp_hof0.constprop.0+0x740>
    97b0:	72003c3f 	tst	w1, #0xffff
    97b4:	54ff9261 	b.ne	8a00 <fwp_hof0.constprop.0+0x940>  // b.any
    97b8:	39400300 	ldrb	w0, [x24]
    97bc:	7103fc1f 	cmp	w0, #0xff
    97c0:	54ff91c1 	b.ne	89f8 <fwp_hof0.constprop.0+0x938>  // b.any
    97c4:	aa1803e0 	mov	x0, x24
    97c8:	97ffec2a 	bl	4870 <fwp_rc_forget_slot>
    97cc:	17fffc8b 	b	89f8 <fwp_hof0.constprop.0+0x938>
    97d0:	72003c5f 	tst	w2, #0xffff
    97d4:	54ff7a61 	b.ne	8720 <fwp_hof0.constprop.0+0x660>  // b.any
    97d8:	17fffcff 	b	8bd4 <fwp_hof0.constprop.0+0xb14>
    97dc:	91174280 	add	x0, x20, #0x5d0
    97e0:	f9400ad7 	ldr	x23, [x22, #16]
    97e4:	f949ec04 	ldr	x4, [x0, #5080]
    97e8:	f949d801 	ldr	x1, [x0, #5040]
    97ec:	d370bc84 	lsl	x4, x4, #16
    97f0:	cb0102c0 	sub	x0, x22, x1
    97f4:	eb04001f 	cmp	x0, x4
    97f8:	54000382 	b.cs	9868 <fwp_hof0.constprop.0+0x17a8>  // b.hs, b.nlast
    97fc:	d350fc02 	lsr	x2, x0, #16
    9800:	8b020842 	add	x2, x2, x2, lsl #2
    9804:	d37df042 	lsl	x2, x2, #3
    9808:	8b020066 	add	x6, x3, x2
    980c:	f94010c5 	ldr	x5, [x6, #32]
    9810:	b40002c5 	cbz	x5, 9868 <fwp_hof0.constprop.0+0x17a8>
    9814:	38626862 	ldrb	w2, [x3, x2]
    9818:	7100085f 	cmp	w2, #0x2
    981c:	54000820 	b.eq	9920 <fwp_hof0.constprop.0+0x1860>  // b.none
    9820:	7100045f 	cmp	w2, #0x1
    9824:	54000221 	b.ne	9868 <fwp_hof0.constprop.0+0x17a8>  // b.any
    9828:	294308c3 	ldp	w3, w2, [x6, #24]
    982c:	92403c00 	and	x0, x0, #0xffff
    9830:	9b037c00 	mul	x0, x0, x3
    9834:	d360fc00 	lsr	x0, x0, #32
    9838:	eb02001f 	cmp	x0, x2
    983c:	54000162 	b.cs	9868 <fwp_hof0.constprop.0+0x17a8>  // b.hs, b.nlast
    9840:	8b0000a5 	add	x5, x5, x0
    9844:	394000a0 	ldrb	w0, [x5]
    9848:	7100041f 	cmp	w0, #0x1
    984c:	540000e1 	b.ne	9868 <fwp_hof0.constprop.0+0x17a8>  // b.any
    9850:	aa1603e0 	mov	x0, x22
    9854:	97ffeca7 	bl	4af0 <fwp_mem_free>
    9858:	91174280 	add	x0, x20, #0x5d0
    985c:	f949ec04 	ldr	x4, [x0, #5080]
    9860:	f949d801 	ldr	x1, [x0, #5040]
    9864:	d370bc84 	lsl	x4, x4, #16
    9868:	cb0102e1 	sub	x1, x23, x1
    986c:	eb04003f 	cmp	x1, x4
    9870:	54ffc242 	b.cs	90b8 <fwp_hof0.constprop.0+0xff8>  // b.hs, b.nlast
    9874:	aa1703f6 	mov	x22, x23
    9878:	17fffdf4 	b	9048 <fwp_hof0.constprop.0+0xf88>
    987c:	72003cff 	tst	w7, #0xffff
    9880:	54ffbdc1 	b.ne	9038 <fwp_hof0.constprop.0+0xf78>  // b.any
    9884:	17fffe35 	b	9158 <fwp_hof0.constprop.0+0x1098>
    9888:	72003c3f 	tst	w1, #0xffff
    988c:	54ffd840 	b.eq	9394 <fwp_hof0.constprop.0+0x12d4>  // b.none
    9890:	aa1703e0 	mov	x0, x23
    9894:	17fffc85 	b	8aa8 <fwp_hof0.constprop.0+0x9e8>
    9898:	aa1303e0 	mov	x0, x19
    989c:	97ffebf5 	bl	4870 <fwp_rc_forget_slot>
    98a0:	17fffec0 	b	93a0 <fwp_hof0.constprop.0+0x12e0>
    98a4:	aa0203e0 	mov	x0, x2
    98a8:	d2800101 	mov	x1, #0x8                   	// #8
    98ac:	f90003e2 	str	x2, [sp]
    98b0:	97ffe410 	bl	28f0 <calloc@plt>
    98b4:	f94003e2 	ldr	x2, [sp]
    98b8:	aa0003fa 	mov	x26, x0
    98bc:	f9401be4 	ldr	x4, [sp, #48]
    98c0:	17fffbe4 	b	8850 <fwp_hof0.constprop.0+0x790>
    98c4:	d2800d01 	mov	x1, #0x68                  	// #104
    98c8:	d280003c 	mov	x28, #0x1                   	// #1
    98cc:	17fffac2 	b	83d4 <fwp_hof0.constprop.0+0x314>
    98d0:	f9400380 	ldr	x0, [x28]
    98d4:	b7ffd740 	tbnz	x0, #63, 93bc <fwp_hof0.constprop.0+0x12fc>
    98d8:	91174283 	add	x3, x20, #0x5d0
    98dc:	f94003e4 	ldr	x4, [sp]
    98e0:	f949d861 	ldr	x1, [x3, #5040]
    98e4:	f949ec63 	ldr	x3, [x3, #5080]
    98e8:	cb010081 	sub	x1, x4, x1
    98ec:	eb03403f 	cmp	x1, x3, lsl #16
    98f0:	54ffd662 	b.cs	93bc <fwp_hof0.constprop.0+0x12fc>  // b.hs, b.nlast
    98f4:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    98f8:	17fffcd1 	b	8c3c <fwp_hof0.constprop.0+0xb7c>
    98fc:	aa1303e0 	mov	x0, x19
    9900:	97ffef75 	bl	56d4 <fwp_rc_free_arr>
    9904:	17ffff2e 	b	95bc <fwp_hof0.constprop.0+0x14fc>
    9908:	72003c5f 	tst	w2, #0xffff
    990c:	54ffed61 	b.ne	96b8 <fwp_hof0.constprop.0+0x15f8>  // b.any
    9910:	17ffff60 	b	9690 <fwp_hof0.constprop.0+0x15d0>
    9914:	72003cff 	tst	w7, #0xffff
    9918:	54fff1a1 	b.ne	974c <fwp_hof0.constprop.0+0x168c>  // b.any
    991c:	17ffff84 	b	972c <fwp_hof0.constprop.0+0x166c>
    9920:	72003c1f 	tst	w0, #0xffff
    9924:	54fffa21 	b.ne	9868 <fwp_hof0.constprop.0+0x17a8>  // b.any
    9928:	17ffffc7 	b	9844 <fwp_hof0.constprop.0+0x1784>
    992c:	72003c9f 	tst	w4, #0xffff
    9930:	54ff44e1 	b.ne	81cc <fwp_hof0.constprop.0+0x10c>  // b.any
    9934:	17fffa1b 	b	81a0 <fwp_hof0.constprop.0+0xe0>
    9938:	ca584700 	eor	x0, x24, x24, lsr #17
    993c:	91174281 	add	x1, x20, #0x5d0
    9940:	ca402400 	eor	x0, x0, x0, lsr #9
    9944:	8b200c20 	add	x0, x1, w0, uxtb #3
    9948:	f94a2400 	ldr	x0, [x0, #5192]
    994c:	b5000080 	cbnz	x0, 995c <fwp_hof0.constprop.0+0x189c>
    9950:	14000012 	b	9998 <fwp_hof0.constprop.0+0x18d8>
    9954:	f9400800 	ldr	x0, [x0, #16]
    9958:	b4000200 	cbz	x0, 9998 <fwp_hof0.constprop.0+0x18d8>
    995c:	f9400001 	ldr	x1, [x0]
    9960:	eb18003f 	cmp	x1, x24
    9964:	54ffff81 	b.ne	9954 <fwp_hof0.constprop.0+0x1894>  // b.any
    9968:	f9400401 	ldr	x1, [x0, #8]
    996c:	d1000421 	sub	x1, x1, #0x1
    9970:	f9000401 	str	x1, [x0, #8]
    9974:	f103f83f 	cmp	x1, #0xfe
    9978:	54ff6d41 	b.ne	8720 <fwp_hof0.constprop.0+0x660>  // b.any
    997c:	aa1803e0 	mov	x0, x24
    9980:	f90003e4 	str	x4, [sp]
    9984:	97ffebbb 	bl	4870 <fwp_rc_forget_slot>
    9988:	f94003e4 	ldr	x4, [sp]
    998c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9990:	39000300 	strb	w0, [x24]
    9994:	17fffb63 	b	8720 <fwp_hof0.constprop.0+0x660>
    9998:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    999c:	910a0000 	add	x0, x0, #0x280
    99a0:	97ffe7b8 	bl	3880 <fwp_trap>
    99a4:	ca594720 	eor	x0, x25, x25, lsr #17
    99a8:	91174281 	add	x1, x20, #0x5d0
    99ac:	ca402400 	eor	x0, x0, x0, lsr #9
    99b0:	8b200c20 	add	x0, x1, w0, uxtb #3
    99b4:	f94a2401 	ldr	x1, [x0, #5192]
    99b8:	b5000081 	cbnz	x1, 99c8 <fwp_hof0.constprop.0+0x1908>
    99bc:	17fffff7 	b	9998 <fwp_hof0.constprop.0+0x18d8>
    99c0:	f9400821 	ldr	x1, [x1, #16]
    99c4:	b4fffea1 	cbz	x1, 9998 <fwp_hof0.constprop.0+0x18d8>
    99c8:	f9400020 	ldr	x0, [x1]
    99cc:	eb19001f 	cmp	x0, x25
    99d0:	54ffff81 	b.ne	99c0 <fwp_hof0.constprop.0+0x1900>  // b.any
    99d4:	f9400420 	ldr	x0, [x1, #8]
    99d8:	d1000400 	sub	x0, x0, #0x1
    99dc:	f9000420 	str	x0, [x1, #8]
    99e0:	f103f81f 	cmp	x0, #0xfe
    99e4:	54ffbc41 	b.ne	916c <fwp_hof0.constprop.0+0x10ac>  // b.any
    99e8:	aa1903e0 	mov	x0, x25
    99ec:	97ffeba1 	bl	4870 <fwp_rc_forget_slot>
    99f0:	91174280 	add	x0, x20, #0x5d0
    99f4:	12800021 	mov	w1, #0xfffffffe            	// #-2
    99f8:	39000321 	strb	w1, [x25]
    99fc:	f949ec02 	ldr	x2, [x0, #5080]
    9a00:	f949d801 	ldr	x1, [x0, #5040]
    9a04:	d370bc42 	lsl	x2, x2, #16
    9a08:	17fffd8c 	b	9038 <fwp_hof0.constprop.0+0xf78>
    9a0c:	72003c5f 	tst	w2, #0xffff
    9a10:	54ffdd61 	b.ne	95bc <fwp_hof0.constprop.0+0x14fc>  // b.any
    9a14:	17fffee2 	b	959c <fwp_hof0.constprop.0+0x14dc>
    9a18:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9a1c:	91174281 	add	x1, x20, #0x5d0
    9a20:	ca402400 	eor	x0, x0, x0, lsr #9
    9a24:	8b200c20 	add	x0, x1, w0, uxtb #3
    9a28:	f94a2400 	ldr	x0, [x0, #5192]
    9a2c:	b5000080 	cbnz	x0, 9a3c <fwp_hof0.constprop.0+0x197c>
    9a30:	17ffffda 	b	9998 <fwp_hof0.constprop.0+0x18d8>
    9a34:	f9400800 	ldr	x0, [x0, #16]
    9a38:	b4fffb00 	cbz	x0, 9998 <fwp_hof0.constprop.0+0x18d8>
    9a3c:	f9400001 	ldr	x1, [x0]
    9a40:	eb0102ff 	cmp	x23, x1
    9a44:	54ffff81 	b.ne	9a34 <fwp_hof0.constprop.0+0x1974>  // b.any
    9a48:	f9400401 	ldr	x1, [x0, #8]
    9a4c:	d1000421 	sub	x1, x1, #0x1
    9a50:	f9000401 	str	x1, [x0, #8]
    9a54:	f103f83f 	cmp	x1, #0xfe
    9a58:	54ffb301 	b.ne	90b8 <fwp_hof0.constprop.0+0xff8>  // b.any
    9a5c:	aa1703e0 	mov	x0, x23
    9a60:	97ffeb84 	bl	4870 <fwp_rc_forget_slot>
    9a64:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9a68:	390002e0 	strb	w0, [x23]
    9a6c:	17fffd93 	b	90b8 <fwp_hof0.constprop.0+0xff8>
    9a70:	72003c5f 	tst	w2, #0xffff
    9a74:	54ffd4c1 	b.ne	950c <fwp_hof0.constprop.0+0x144c>  // b.any
    9a78:	394002c0 	ldrb	w0, [x22]
    9a7c:	7103fc1f 	cmp	w0, #0xff
    9a80:	54ffd421 	b.ne	9504 <fwp_hof0.constprop.0+0x1444>  // b.any
    9a84:	aa1603e0 	mov	x0, x22
    9a88:	97ffeb7a 	bl	4870 <fwp_rc_forget_slot>
    9a8c:	17fffe9e 	b	9504 <fwp_hof0.constprop.0+0x1444>
    9a90:	d2800013 	mov	x19, #0x0                   	// #0
    9a94:	d280001c 	mov	x28, #0x0                   	// #0
    9a98:	17fffd3e 	b	8f90 <fwp_hof0.constprop.0+0xed0>
    9a9c:	ca534660 	eor	x0, x19, x19, lsr #17
    9aa0:	91174281 	add	x1, x20, #0x5d0
    9aa4:	ca402400 	eor	x0, x0, x0, lsr #9
    9aa8:	8b200c20 	add	x0, x1, w0, uxtb #3
    9aac:	f94a2400 	ldr	x0, [x0, #5192]
    9ab0:	b5000080 	cbnz	x0, 9ac0 <fwp_hof0.constprop.0+0x1a00>
    9ab4:	17ffffb9 	b	9998 <fwp_hof0.constprop.0+0x18d8>
    9ab8:	f9400800 	ldr	x0, [x0, #16]
    9abc:	b4fff6e0 	cbz	x0, 9998 <fwp_hof0.constprop.0+0x18d8>
    9ac0:	f9400001 	ldr	x1, [x0]
    9ac4:	eb01027f 	cmp	x19, x1
    9ac8:	54ffff81 	b.ne	9ab8 <fwp_hof0.constprop.0+0x19f8>  // b.any
    9acc:	f9400401 	ldr	x1, [x0, #8]
    9ad0:	d1000421 	sub	x1, x1, #0x1
    9ad4:	f9000401 	str	x1, [x0, #8]
    9ad8:	f103f83f 	cmp	x1, #0xfe
    9adc:	54ff4161 	b.ne	8308 <fwp_hof0.constprop.0+0x248>  // b.any
    9ae0:	aa1303e0 	mov	x0, x19
    9ae4:	97ffeb63 	bl	4870 <fwp_rc_forget_slot>
    9ae8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9aec:	39000260 	strb	w0, [x19]
    9af0:	17fffa06 	b	8308 <fwp_hof0.constprop.0+0x248>
    9af4:	97ffeb18 	bl	4754 <fwp_rc_wide_dup>
    9af8:	17fff9e2 	b	8280 <fwp_hof0.constprop.0+0x1c0>
    9afc:	d2800019 	mov	x25, #0x0                   	// #0
    9b00:	17fffcae 	b	8db8 <fwp_hof0.constprop.0+0xcf8>
    9b04:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9b08:	910d8000 	add	x0, x0, #0x360
    9b0c:	97ffe75d 	bl	3880 <fwp_trap>
    9b10:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9b14:	910b2000 	add	x0, x0, #0x2c8
    9b18:	97ffe75a 	bl	3880 <fwp_trap>
    9b1c:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9b20:	91174281 	add	x1, x20, #0x5d0
    9b24:	ca402400 	eor	x0, x0, x0, lsr #9
    9b28:	8b200c20 	add	x0, x1, w0, uxtb #3
    9b2c:	f94a2400 	ldr	x0, [x0, #5192]
    9b30:	b5000080 	cbnz	x0, 9b40 <fwp_hof0.constprop.0+0x1a80>
    9b34:	17ffff99 	b	9998 <fwp_hof0.constprop.0+0x18d8>
    9b38:	f9400800 	ldr	x0, [x0, #16]
    9b3c:	b4fff2e0 	cbz	x0, 9998 <fwp_hof0.constprop.0+0x18d8>
    9b40:	f9400001 	ldr	x1, [x0]
    9b44:	eb0102df 	cmp	x22, x1
    9b48:	54ffff81 	b.ne	9b38 <fwp_hof0.constprop.0+0x1a78>  // b.any
    9b4c:	f9400401 	ldr	x1, [x0, #8]
    9b50:	d1000421 	sub	x1, x1, #0x1
    9b54:	f9000401 	str	x1, [x0, #8]
    9b58:	f103f83f 	cmp	x1, #0xfe
    9b5c:	54ffd301 	b.ne	95bc <fwp_hof0.constprop.0+0x14fc>  // b.any
    9b60:	aa1603e0 	mov	x0, x22
    9b64:	97ffeb43 	bl	4870 <fwp_rc_forget_slot>
    9b68:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9b6c:	390002c0 	strb	w0, [x22]
    9b70:	17fffe93 	b	95bc <fwp_hof0.constprop.0+0x14fc>
    9b74:	97ffeaf8 	bl	4754 <fwp_rc_wide_dup>
    9b78:	91174280 	add	x0, x20, #0x5d0
    9b7c:	f949ec03 	ldr	x3, [x0, #5080]
    9b80:	f949d801 	ldr	x1, [x0, #5040]
    9b84:	d370bc63 	lsl	x3, x3, #16
    9b88:	17fff991 	b	81cc <fwp_hof0.constprop.0+0x10c>
    9b8c:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9b90:	91148000 	add	x0, x0, #0x520
    9b94:	97ffe73b 	bl	3880 <fwp_trap>
    9b98:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9b9c:	910f0000 	add	x0, x0, #0x3c0
    9ba0:	97ffe738 	bl	3880 <fwp_trap>
    9ba4:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9ba8:	910c4000 	add	x0, x0, #0x310
    9bac:	97ffe735 	bl	3880 <fwp_trap>
    9bb0:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9bb4:	91152000 	add	x0, x0, #0x548
    9bb8:	97ffe732 	bl	3880 <fwp_trap>
    9bbc:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9bc0:	91144000 	add	x0, x0, #0x510
    9bc4:	97ffe72f 	bl	3880 <fwp_trap>
    9bc8:	52800020 	mov	w0, #0x1                   	// #1
    9bcc:	17fffbd3 	b	8b18 <fwp_hof0.constprop.0+0xa58>
    9bd0:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9bd4:	91138000 	add	x0, x0, #0x4e0
    9bd8:	97ffe72a 	bl	3880 <fwp_trap>
    9bdc:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9be0:	91130000 	add	x0, x0, #0x4c0
    9be4:	97ffe727 	bl	3880 <fwp_trap>
    9be8:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9bec:	91158000 	add	x0, x0, #0x560
    9bf0:	97ffe724 	bl	3880 <fwp_trap>
    9bf4:	a90f53f3 	stp	x19, x20, [sp, #240]
    9bf8:	a9105bf5 	stp	x21, x22, [sp, #256]
    9bfc:	a91163f7 	stp	x23, x24, [sp, #272]
    9c00:	a9126bf9 	stp	x25, x26, [sp, #288]
    9c04:	a91373fb 	stp	x27, x28, [sp, #304]
    9c08:	fd00a3e8 	str	d8, [sp, #320]
    9c0c:	97ffe341 	bl	2910 <__stack_chk_fail@plt>
    9c10:	97ffe3bc 	bl	2b00 <fwp_trap_overflow.constprop.0>
    9c14:	97ffe353 	bl	2960 <abort@plt>
    9c18:	d503201f 	nop
    9c1c:	d503201f 	nop

0000000000009c20 <f0>:
    9c20:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9c24:	910003fd 	mov	x29, sp
    9c28:	a90153f3 	stp	x19, x20, [sp, #16]
    9c2c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9c30:	a90363f7 	stp	x23, x24, [sp, #48]
    9c34:	a9046bf9 	stp	x25, x26, [sp, #64]
    9c38:	a90573fb 	stp	x27, x28, [sp, #80]
    9c3c:	d12183ff 	sub	sp, sp, #0x860
    9c40:	f90203ff 	str	xzr, [sp, #1024]
    9c44:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c48:	9101c005 	add	x5, x0, #0x70
    9c4c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9c50:	f947f400 	ldr	x0, [x0, #4072]
    9c54:	90000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    9c58:	f94188a6 	ldr	x6, [x5, #784]
    9c5c:	f9400001 	ldr	x1, [x0]
    9c60:	f9042fe1 	str	x1, [sp, #2136]
    9c64:	d2800001 	mov	x1, #0x0                   	// #0
    9c68:	91174298 	add	x24, x20, #0x5d0
    9c6c:	912123f6 	add	x22, sp, #0x848
    9c70:	910023e0 	add	x0, sp, #0x8
    9c74:	910083e2 	add	x2, sp, #0x20
    9c78:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    9c7c:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9c80:	9128c021 	add	x1, x1, #0xa30
    9c84:	913f4084 	add	x4, x4, #0xfd0
    9c88:	d2800013 	mov	x19, #0x0                   	// #0
    9c8c:	d2800119 	mov	x25, #0x8                   	// #8
    9c90:	d2800015 	mov	x21, #0x0                   	// #0
    9c94:	52800037 	mov	w23, #0x1                   	// #1
    9c98:	a90093e6 	stp	x6, x4, [sp, #8]
    9c9c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9ca0:	a90307ff 	stp	xzr, x1, [sp, #48]
    9ca4:	f90188a0 	str	x0, [x5, #784]
    9ca8:	f100073a 	subs	x26, x25, #0x1
    9cac:	aa1603e1 	mov	x1, x22
    9cb0:	da1f02bc 	sbc	x28, x21, xzr
    9cb4:	52800020 	mov	w0, #0x1                   	// #1
    9cb8:	f90017fa 	str	x26, [sp, #40]
    9cbc:	aa1a03f9 	mov	x25, x26
    9cc0:	f90427fa 	str	x26, [sp, #2120]
    9cc4:	aa1c03f5 	mov	x21, x28
    9cc8:	f9042bf3 	str	x19, [sp, #2128]
    9ccc:	97ffecee 	bl	5084 <fwp_data.part.0.constprop.0>
    9cd0:	f949db02 	ldr	x2, [x24, #5040]
    9cd4:	aa0003f3 	mov	x19, x0
    9cd8:	f949ef00 	ldr	x0, [x24, #5080]
    9cdc:	cb020262 	sub	x2, x19, x2
    9ce0:	eb00405f 	cmp	x2, x0, lsl #16
    9ce4:	54000302 	b.cs	9d44 <f0+0x124>  // b.hs, b.nlast
    9ce8:	d350fc40 	lsr	x0, x2, #16
    9cec:	f949ff04 	ldr	x4, [x24, #5112]
    9cf0:	8b000800 	add	x0, x0, x0, lsl #2
    9cf4:	d37df001 	lsl	x1, x0, #3
    9cf8:	8b010080 	add	x0, x4, x1
    9cfc:	f940101b 	ldr	x27, [x0, #32]
    9d00:	b400023b 	cbz	x27, 9d44 <f0+0x124>
    9d04:	38616881 	ldrb	w1, [x4, x1]
    9d08:	7100083f 	cmp	w1, #0x2
    9d0c:	54010de0 	b.eq	bec8 <f0+0x22a8>  // b.none
    9d10:	7100043f 	cmp	w1, #0x1
    9d14:	54000181 	b.ne	9d44 <f0+0x124>  // b.any
    9d18:	29430001 	ldp	w1, w0, [x0, #24]
    9d1c:	92403c42 	and	x2, x2, #0xffff
    9d20:	9b017c42 	mul	x2, x2, x1
    9d24:	d360fc42 	lsr	x2, x2, #32
    9d28:	eb00005f 	cmp	x2, x0
    9d2c:	540000c2 	b.cs	9d44 <f0+0x124>  // b.hs, b.nlast
    9d30:	8b02037b 	add	x27, x27, x2
    9d34:	39400360 	ldrb	w0, [x27]
    9d38:	7103fc1f 	cmp	w0, #0xff
    9d3c:	54010c00 	b.eq	bebc <f0+0x229c>  // b.none
    9d40:	39000377 	strb	w23, [x27]
    9d44:	f90013f3 	str	x19, [sp, #32]
    9d48:	aa1c035a 	orr	x26, x26, x28
    9d4c:	b5fffafa 	cbnz	x26, 9ca8 <f0+0x88>
    9d50:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    9d54:	910103e1 	add	x1, sp, #0x40
    9d58:	f94007e2 	ldr	x2, [sp, #8]
    9d5c:	3dc34800 	ldr	q0, [x0, #3360]
    9d60:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d64:	9101c018 	add	x24, x0, #0x70
    9d68:	52800020 	mov	w0, #0x1                   	// #1
    9d6c:	3d8013e0 	str	q0, [sp, #64]
    9d70:	f9018b02 	str	x2, [x24, #784]
    9d74:	97ffecc4 	bl	5084 <fwp_data.part.0.constprop.0>
    9d78:	91174283 	add	x3, x20, #0x5d0
    9d7c:	aa0003f7 	mov	x23, x0
    9d80:	f949d861 	ldr	x1, [x3, #5040]
    9d84:	f949ec60 	ldr	x0, [x3, #5080]
    9d88:	cb0102e1 	sub	x1, x23, x1
    9d8c:	eb00403f 	cmp	x1, x0, lsl #16
    9d90:	54000322 	b.cs	9df4 <f0+0x1d4>  // b.hs, b.nlast
    9d94:	d350fc22 	lsr	x2, x1, #16
    9d98:	f949fc63 	ldr	x3, [x3, #5112]
    9d9c:	8b020842 	add	x2, x2, x2, lsl #2
    9da0:	d37df042 	lsl	x2, x2, #3
    9da4:	8b020060 	add	x0, x3, x2
    9da8:	f9401015 	ldr	x21, [x0, #32]
    9dac:	b4000255 	cbz	x21, 9df4 <f0+0x1d4>
    9db0:	38626862 	ldrb	w2, [x3, x2]
    9db4:	7100085f 	cmp	w2, #0x2
    9db8:	54010ca0 	b.eq	bf4c <f0+0x232c>  // b.none
    9dbc:	7100045f 	cmp	w2, #0x1
    9dc0:	540001a1 	b.ne	9df4 <f0+0x1d4>  // b.any
    9dc4:	29430002 	ldp	w2, w0, [x0, #24]
    9dc8:	92403c21 	and	x1, x1, #0xffff
    9dcc:	9b027c21 	mul	x1, x1, x2
    9dd0:	d360fc21 	lsr	x1, x1, #32
    9dd4:	eb00003f 	cmp	x1, x0
    9dd8:	540000e2 	b.cs	9df4 <f0+0x1d4>  // b.hs, b.nlast
    9ddc:	8b0102b5 	add	x21, x21, x1
    9de0:	394002a0 	ldrb	w0, [x21]
    9de4:	7103fc1f 	cmp	w0, #0xff
    9de8:	54011660 	b.eq	c0b4 <f0+0x2494>  // b.none
    9dec:	52800020 	mov	w0, #0x1                   	// #1
    9df0:	390002a0 	strb	w0, [x21]
    9df4:	910163e1 	add	x1, sp, #0x58
    9df8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9dfc:	52800020 	mov	w0, #0x1                   	// #1
    9e00:	a905dff5 	stp	x21, x23, [sp, #88]
    9e04:	97ffeca0 	bl	5084 <fwp_data.part.0.constprop.0>
    9e08:	97ffee03 	bl	5614 <fwp_rc_fresh>
    9e0c:	aa0003e2 	mov	x2, x0
    9e10:	9101a3e1 	add	x1, sp, #0x68
    9e14:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9e18:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9e1c:	52800020 	mov	w0, #0x1                   	// #1
    9e20:	a9068bf7 	stp	x23, x2, [sp, #104]
    9e24:	97ffec98 	bl	5084 <fwp_data.part.0.constprop.0>
    9e28:	97ffedfb 	bl	5614 <fwp_rc_fresh>
    9e2c:	aa0003e2 	mov	x2, x0
    9e30:	9101e3e1 	add	x1, sp, #0x78
    9e34:	52800020 	mov	w0, #0x1                   	// #1
    9e38:	a9078bf5 	stp	x21, x2, [sp, #120]
    9e3c:	97ffec92 	bl	5084 <fwp_data.part.0.constprop.0>
    9e40:	97ffedf5 	bl	5614 <fwp_rc_fresh>
    9e44:	aa0003e2 	mov	x2, x0
    9e48:	910223e1 	add	x1, sp, #0x88
    9e4c:	52800020 	mov	w0, #0x1                   	// #1
    9e50:	a9088bf7 	stp	x23, x2, [sp, #136]
    9e54:	97ffec8c 	bl	5084 <fwp_data.part.0.constprop.0>
    9e58:	97ffedef 	bl	5614 <fwp_rc_fresh>
    9e5c:	aa0003e2 	mov	x2, x0
    9e60:	910263e1 	add	x1, sp, #0x98
    9e64:	52800020 	mov	w0, #0x1                   	// #1
    9e68:	a9098bf5 	stp	x21, x2, [sp, #152]
    9e6c:	97ffec86 	bl	5084 <fwp_data.part.0.constprop.0>
    9e70:	97ffede9 	bl	5614 <fwp_rc_fresh>
    9e74:	aa0003e2 	mov	x2, x0
    9e78:	9102a3e1 	add	x1, sp, #0xa8
    9e7c:	52800020 	mov	w0, #0x1                   	// #1
    9e80:	a90a8bf7 	stp	x23, x2, [sp, #168]
    9e84:	97ffec80 	bl	5084 <fwp_data.part.0.constprop.0>
    9e88:	97ffede3 	bl	5614 <fwp_rc_fresh>
    9e8c:	aa0003e2 	mov	x2, x0
    9e90:	9102e3e1 	add	x1, sp, #0xb8
    9e94:	52800020 	mov	w0, #0x1                   	// #1
    9e98:	a90b8bf5 	stp	x21, x2, [sp, #184]
    9e9c:	97ffec7a 	bl	5084 <fwp_data.part.0.constprop.0>
    9ea0:	91174283 	add	x3, x20, #0x5d0
    9ea4:	aa0003f7 	mov	x23, x0
    9ea8:	f949d861 	ldr	x1, [x3, #5040]
    9eac:	f949ec60 	ldr	x0, [x3, #5080]
    9eb0:	cb0102e1 	sub	x1, x23, x1
    9eb4:	eb00403f 	cmp	x1, x0, lsl #16
    9eb8:	54000322 	b.cs	9f1c <f0+0x2fc>  // b.hs, b.nlast
    9ebc:	d350fc22 	lsr	x2, x1, #16
    9ec0:	f949fc63 	ldr	x3, [x3, #5112]
    9ec4:	8b020842 	add	x2, x2, x2, lsl #2
    9ec8:	d37df042 	lsl	x2, x2, #3
    9ecc:	8b020060 	add	x0, x3, x2
    9ed0:	f9401015 	ldr	x21, [x0, #32]
    9ed4:	b4000255 	cbz	x21, 9f1c <f0+0x2fc>
    9ed8:	38626862 	ldrb	w2, [x3, x2]
    9edc:	7100085f 	cmp	w2, #0x2
    9ee0:	54010300 	b.eq	bf40 <f0+0x2320>  // b.none
    9ee4:	7100045f 	cmp	w2, #0x1
    9ee8:	540001a1 	b.ne	9f1c <f0+0x2fc>  // b.any
    9eec:	29430002 	ldp	w2, w0, [x0, #24]
    9ef0:	92403c21 	and	x1, x1, #0xffff
    9ef4:	9b027c21 	mul	x1, x1, x2
    9ef8:	d360fc21 	lsr	x1, x1, #32
    9efc:	eb00003f 	cmp	x1, x0
    9f00:	540000e2 	b.cs	9f1c <f0+0x2fc>  // b.hs, b.nlast
    9f04:	8b0102b5 	add	x21, x21, x1
    9f08:	394002a0 	ldrb	w0, [x21]
    9f0c:	7103fc1f 	cmp	w0, #0xff
    9f10:	54010d80 	b.eq	c0c0 <f0+0x24a0>  // b.none
    9f14:	52800020 	mov	w0, #0x1                   	// #1
    9f18:	390002a0 	strb	w0, [x21]
    9f1c:	910323e1 	add	x1, sp, #0xc8
    9f20:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    9f24:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    9f28:	52800020 	mov	w0, #0x1                   	// #1
    9f2c:	a90cdff5 	stp	x21, x23, [sp, #200]
    9f30:	97ffec55 	bl	5084 <fwp_data.part.0.constprop.0>
    9f34:	97ffedb8 	bl	5614 <fwp_rc_fresh>
    9f38:	aa0003e2 	mov	x2, x0
    9f3c:	910363e1 	add	x1, sp, #0xd8
    9f40:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    9f44:	52800020 	mov	w0, #0x1                   	// #1
    9f48:	a90d8bf7 	stp	x23, x2, [sp, #216]
    9f4c:	97ffec4e 	bl	5084 <fwp_data.part.0.constprop.0>
    9f50:	97ffedb1 	bl	5614 <fwp_rc_fresh>
    9f54:	aa0003e2 	mov	x2, x0
    9f58:	9103a3e1 	add	x1, sp, #0xe8
    9f5c:	52800020 	mov	w0, #0x1                   	// #1
    9f60:	a90e8bf5 	stp	x21, x2, [sp, #232]
    9f64:	97ffec48 	bl	5084 <fwp_data.part.0.constprop.0>
    9f68:	97ffedab 	bl	5614 <fwp_rc_fresh>
    9f6c:	aa0003e2 	mov	x2, x0
    9f70:	9103e3e1 	add	x1, sp, #0xf8
    9f74:	52800020 	mov	w0, #0x1                   	// #1
    9f78:	a90f8bf7 	stp	x23, x2, [sp, #248]
    9f7c:	97ffec42 	bl	5084 <fwp_data.part.0.constprop.0>
    9f80:	97ffeda5 	bl	5614 <fwp_rc_fresh>
    9f84:	aa0003e2 	mov	x2, x0
    9f88:	910423e1 	add	x1, sp, #0x108
    9f8c:	52800020 	mov	w0, #0x1                   	// #1
    9f90:	a9108bf5 	stp	x21, x2, [sp, #264]
    9f94:	97ffec3c 	bl	5084 <fwp_data.part.0.constprop.0>
    9f98:	97ffed9f 	bl	5614 <fwp_rc_fresh>
    9f9c:	aa0003e2 	mov	x2, x0
    9fa0:	910463e1 	add	x1, sp, #0x118
    9fa4:	52800020 	mov	w0, #0x1                   	// #1
    9fa8:	a9118bf7 	stp	x23, x2, [sp, #280]
    9fac:	97ffec36 	bl	5084 <fwp_data.part.0.constprop.0>
    9fb0:	97ffed99 	bl	5614 <fwp_rc_fresh>
    9fb4:	aa0003e2 	mov	x2, x0
    9fb8:	9104a3e1 	add	x1, sp, #0x128
    9fbc:	52800020 	mov	w0, #0x1                   	// #1
    9fc0:	a9128bf5 	stp	x21, x2, [sp, #296]
    9fc4:	97ffec30 	bl	5084 <fwp_data.part.0.constprop.0>
    9fc8:	91174283 	add	x3, x20, #0x5d0
    9fcc:	aa0003f5 	mov	x21, x0
    9fd0:	f949d861 	ldr	x1, [x3, #5040]
    9fd4:	f949ec60 	ldr	x0, [x3, #5080]
    9fd8:	cb0102a1 	sub	x1, x21, x1
    9fdc:	eb00403f 	cmp	x1, x0, lsl #16
    9fe0:	54000322 	b.cs	a044 <f0+0x424>  // b.hs, b.nlast
    9fe4:	d350fc22 	lsr	x2, x1, #16
    9fe8:	f949fc63 	ldr	x3, [x3, #5112]
    9fec:	8b020842 	add	x2, x2, x2, lsl #2
    9ff0:	d37df042 	lsl	x2, x2, #3
    9ff4:	8b020060 	add	x0, x3, x2
    9ff8:	f9401017 	ldr	x23, [x0, #32]
    9ffc:	b4000257 	cbz	x23, a044 <f0+0x424>
    a000:	38626862 	ldrb	w2, [x3, x2]
    a004:	7100085f 	cmp	w2, #0x2
    a008:	5400f960 	b.eq	bf34 <f0+0x2314>  // b.none
    a00c:	7100045f 	cmp	w2, #0x1
    a010:	540001a1 	b.ne	a044 <f0+0x424>  // b.any
    a014:	29430002 	ldp	w2, w0, [x0, #24]
    a018:	92403c21 	and	x1, x1, #0xffff
    a01c:	9b027c21 	mul	x1, x1, x2
    a020:	d360fc21 	lsr	x1, x1, #32
    a024:	eb00003f 	cmp	x1, x0
    a028:	540000e2 	b.cs	a044 <f0+0x424>  // b.hs, b.nlast
    a02c:	8b0102f7 	add	x23, x23, x1
    a030:	394002e0 	ldrb	w0, [x23]
    a034:	7103fc1f 	cmp	w0, #0xff
    a038:	540104a0 	b.eq	c0cc <f0+0x24ac>  // b.none
    a03c:	52800020 	mov	w0, #0x1                   	// #1
    a040:	390002e0 	strb	w0, [x23]
    a044:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a048:	9104e3e1 	add	x1, sp, #0x138
    a04c:	52800020 	mov	w0, #0x1                   	// #1
    a050:	a913d7e2 	stp	x2, x21, [sp, #312]
    a054:	97ffec0c 	bl	5084 <fwp_data.part.0.constprop.0>
    a058:	91174283 	add	x3, x20, #0x5d0
    a05c:	aa0003f5 	mov	x21, x0
    a060:	f949d861 	ldr	x1, [x3, #5040]
    a064:	f949ec60 	ldr	x0, [x3, #5080]
    a068:	cb0102a1 	sub	x1, x21, x1
    a06c:	eb00403f 	cmp	x1, x0, lsl #16
    a070:	54000322 	b.cs	a0d4 <f0+0x4b4>  // b.hs, b.nlast
    a074:	d350fc22 	lsr	x2, x1, #16
    a078:	f949fc63 	ldr	x3, [x3, #5112]
    a07c:	8b020842 	add	x2, x2, x2, lsl #2
    a080:	d37df042 	lsl	x2, x2, #3
    a084:	8b020060 	add	x0, x3, x2
    a088:	f9401017 	ldr	x23, [x0, #32]
    a08c:	b4000257 	cbz	x23, a0d4 <f0+0x4b4>
    a090:	38626862 	ldrb	w2, [x3, x2]
    a094:	7100085f 	cmp	w2, #0x2
    a098:	5400f720 	b.eq	bf7c <f0+0x235c>  // b.none
    a09c:	7100045f 	cmp	w2, #0x1
    a0a0:	540001a1 	b.ne	a0d4 <f0+0x4b4>  // b.any
    a0a4:	29430002 	ldp	w2, w0, [x0, #24]
    a0a8:	92403c21 	and	x1, x1, #0xffff
    a0ac:	9b027c21 	mul	x1, x1, x2
    a0b0:	d360fc21 	lsr	x1, x1, #32
    a0b4:	eb00003f 	cmp	x1, x0
    a0b8:	540000e2 	b.cs	a0d4 <f0+0x4b4>  // b.hs, b.nlast
    a0bc:	8b0102f7 	add	x23, x23, x1
    a0c0:	394002e0 	ldrb	w0, [x23]
    a0c4:	7103fc1f 	cmp	w0, #0xff
    a0c8:	54010080 	b.eq	c0d8 <f0+0x24b8>  // b.none
    a0cc:	52800020 	mov	w0, #0x1                   	// #1
    a0d0:	390002e0 	strb	w0, [x23]
    a0d4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a0d8:	910523e1 	add	x1, sp, #0x148
    a0dc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a0e0:	52800020 	mov	w0, #0x1                   	// #1
    a0e4:	a914d7e2 	stp	x2, x21, [sp, #328]
    a0e8:	97ffebe7 	bl	5084 <fwp_data.part.0.constprop.0>
    a0ec:	91174283 	add	x3, x20, #0x5d0
    a0f0:	aa0003f5 	mov	x21, x0
    a0f4:	f949d861 	ldr	x1, [x3, #5040]
    a0f8:	f949ec60 	ldr	x0, [x3, #5080]
    a0fc:	cb0102a1 	sub	x1, x21, x1
    a100:	eb00403f 	cmp	x1, x0, lsl #16
    a104:	54000322 	b.cs	a168 <f0+0x548>  // b.hs, b.nlast
    a108:	d350fc22 	lsr	x2, x1, #16
    a10c:	f949fc63 	ldr	x3, [x3, #5112]
    a110:	8b020842 	add	x2, x2, x2, lsl #2
    a114:	d37df042 	lsl	x2, x2, #3
    a118:	8b020060 	add	x0, x3, x2
    a11c:	f9401017 	ldr	x23, [x0, #32]
    a120:	b4000257 	cbz	x23, a168 <f0+0x548>
    a124:	38626862 	ldrb	w2, [x3, x2]
    a128:	7100085f 	cmp	w2, #0x2
    a12c:	5400f220 	b.eq	bf70 <f0+0x2350>  // b.none
    a130:	7100045f 	cmp	w2, #0x1
    a134:	540001a1 	b.ne	a168 <f0+0x548>  // b.any
    a138:	29430002 	ldp	w2, w0, [x0, #24]
    a13c:	92403c21 	and	x1, x1, #0xffff
    a140:	9b027c21 	mul	x1, x1, x2
    a144:	d360fc21 	lsr	x1, x1, #32
    a148:	eb00003f 	cmp	x1, x0
    a14c:	540000e2 	b.cs	a168 <f0+0x548>  // b.hs, b.nlast
    a150:	8b0102f7 	add	x23, x23, x1
    a154:	394002e0 	ldrb	w0, [x23]
    a158:	7103fc1f 	cmp	w0, #0xff
    a15c:	5400fc40 	b.eq	c0e4 <f0+0x24c4>  // b.none
    a160:	52800020 	mov	w0, #0x1                   	// #1
    a164:	390002e0 	strb	w0, [x23]
    a168:	910563e1 	add	x1, sp, #0x158
    a16c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a170:	52800020 	mov	w0, #0x1                   	// #1
    a174:	a915d7e2 	stp	x2, x21, [sp, #344]
    a178:	97ffebc3 	bl	5084 <fwp_data.part.0.constprop.0>
    a17c:	97ffed26 	bl	5614 <fwp_rc_fresh>
    a180:	aa0003e2 	mov	x2, x0
    a184:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a188:	9105a3e1 	add	x1, sp, #0x168
    a18c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a190:	52800020 	mov	w0, #0x1                   	// #1
    a194:	a9168be3 	stp	x3, x2, [sp, #360]
    a198:	97ffebbb 	bl	5084 <fwp_data.part.0.constprop.0>
    a19c:	91174283 	add	x3, x20, #0x5d0
    a1a0:	aa0003f5 	mov	x21, x0
    a1a4:	f949d861 	ldr	x1, [x3, #5040]
    a1a8:	f949ec60 	ldr	x0, [x3, #5080]
    a1ac:	cb0102a1 	sub	x1, x21, x1
    a1b0:	eb00403f 	cmp	x1, x0, lsl #16
    a1b4:	54000322 	b.cs	a218 <f0+0x5f8>  // b.hs, b.nlast
    a1b8:	d350fc22 	lsr	x2, x1, #16
    a1bc:	f949fc63 	ldr	x3, [x3, #5112]
    a1c0:	8b020842 	add	x2, x2, x2, lsl #2
    a1c4:	d37df042 	lsl	x2, x2, #3
    a1c8:	8b020060 	add	x0, x3, x2
    a1cc:	f9401017 	ldr	x23, [x0, #32]
    a1d0:	b4000257 	cbz	x23, a218 <f0+0x5f8>
    a1d4:	38626862 	ldrb	w2, [x3, x2]
    a1d8:	7100085f 	cmp	w2, #0x2
    a1dc:	5400ec40 	b.eq	bf64 <f0+0x2344>  // b.none
    a1e0:	7100045f 	cmp	w2, #0x1
    a1e4:	540001a1 	b.ne	a218 <f0+0x5f8>  // b.any
    a1e8:	29430002 	ldp	w2, w0, [x0, #24]
    a1ec:	92403c21 	and	x1, x1, #0xffff
    a1f0:	9b027c21 	mul	x1, x1, x2
    a1f4:	d360fc21 	lsr	x1, x1, #32
    a1f8:	eb00003f 	cmp	x1, x0
    a1fc:	540000e2 	b.cs	a218 <f0+0x5f8>  // b.hs, b.nlast
    a200:	8b0102f7 	add	x23, x23, x1
    a204:	394002e0 	ldrb	w0, [x23]
    a208:	7103fc1f 	cmp	w0, #0xff
    a20c:	5400f720 	b.eq	c0f0 <f0+0x24d0>  // b.none
    a210:	52800020 	mov	w0, #0x1                   	// #1
    a214:	390002e0 	strb	w0, [x23]
    a218:	9105e3e1 	add	x1, sp, #0x178
    a21c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a220:	52800020 	mov	w0, #0x1                   	// #1
    a224:	a917d7e2 	stp	x2, x21, [sp, #376]
    a228:	97ffeb97 	bl	5084 <fwp_data.part.0.constprop.0>
    a22c:	97ffecfa 	bl	5614 <fwp_rc_fresh>
    a230:	aa0003e2 	mov	x2, x0
    a234:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a238:	910623e1 	add	x1, sp, #0x188
    a23c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a240:	52800020 	mov	w0, #0x1                   	// #1
    a244:	a9188be3 	stp	x3, x2, [sp, #392]
    a248:	97ffeb8f 	bl	5084 <fwp_data.part.0.constprop.0>
    a24c:	91174283 	add	x3, x20, #0x5d0
    a250:	aa0003f5 	mov	x21, x0
    a254:	f949d861 	ldr	x1, [x3, #5040]
    a258:	f949ec60 	ldr	x0, [x3, #5080]
    a25c:	cb0102a1 	sub	x1, x21, x1
    a260:	eb00403f 	cmp	x1, x0, lsl #16
    a264:	54000322 	b.cs	a2c8 <f0+0x6a8>  // b.hs, b.nlast
    a268:	d350fc22 	lsr	x2, x1, #16
    a26c:	f949fc63 	ldr	x3, [x3, #5112]
    a270:	8b020842 	add	x2, x2, x2, lsl #2
    a274:	d37df042 	lsl	x2, x2, #3
    a278:	8b020060 	add	x0, x3, x2
    a27c:	f9401017 	ldr	x23, [x0, #32]
    a280:	b4000257 	cbz	x23, a2c8 <f0+0x6a8>
    a284:	38626862 	ldrb	w2, [x3, x2]
    a288:	7100085f 	cmp	w2, #0x2
    a28c:	5400e660 	b.eq	bf58 <f0+0x2338>  // b.none
    a290:	7100045f 	cmp	w2, #0x1
    a294:	540001a1 	b.ne	a2c8 <f0+0x6a8>  // b.any
    a298:	29430002 	ldp	w2, w0, [x0, #24]
    a29c:	92403c21 	and	x1, x1, #0xffff
    a2a0:	9b027c21 	mul	x1, x1, x2
    a2a4:	d360fc21 	lsr	x1, x1, #32
    a2a8:	eb00003f 	cmp	x1, x0
    a2ac:	540000e2 	b.cs	a2c8 <f0+0x6a8>  // b.hs, b.nlast
    a2b0:	8b0102f7 	add	x23, x23, x1
    a2b4:	394002e0 	ldrb	w0, [x23]
    a2b8:	7103fc1f 	cmp	w0, #0xff
    a2bc:	5400f200 	b.eq	c0fc <f0+0x24dc>  // b.none
    a2c0:	52800020 	mov	w0, #0x1                   	// #1
    a2c4:	390002e0 	strb	w0, [x23]
    a2c8:	910663e1 	add	x1, sp, #0x198
    a2cc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a2d0:	52800020 	mov	w0, #0x1                   	// #1
    a2d4:	a919d7f7 	stp	x23, x21, [sp, #408]
    a2d8:	97ffeb6b 	bl	5084 <fwp_data.part.0.constprop.0>
    a2dc:	97ffecce 	bl	5614 <fwp_rc_fresh>
    a2e0:	aa0003e2 	mov	x2, x0
    a2e4:	9106a3e1 	add	x1, sp, #0x1a8
    a2e8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a2ec:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a2f0:	52800020 	mov	w0, #0x1                   	// #1
    a2f4:	a91a8bf5 	stp	x21, x2, [sp, #424]
    a2f8:	97ffeb63 	bl	5084 <fwp_data.part.0.constprop.0>
    a2fc:	97ffecc6 	bl	5614 <fwp_rc_fresh>
    a300:	aa0003e2 	mov	x2, x0
    a304:	9106e3e1 	add	x1, sp, #0x1b8
    a308:	52800020 	mov	w0, #0x1                   	// #1
    a30c:	a91b8bf7 	stp	x23, x2, [sp, #440]
    a310:	97ffeb5d 	bl	5084 <fwp_data.part.0.constprop.0>
    a314:	97ffecc0 	bl	5614 <fwp_rc_fresh>
    a318:	aa0003e2 	mov	x2, x0
    a31c:	910723e1 	add	x1, sp, #0x1c8
    a320:	52800020 	mov	w0, #0x1                   	// #1
    a324:	a91c8bf5 	stp	x21, x2, [sp, #456]
    a328:	97ffeb57 	bl	5084 <fwp_data.part.0.constprop.0>
    a32c:	91174283 	add	x3, x20, #0x5d0
    a330:	aa0003f5 	mov	x21, x0
    a334:	f949d861 	ldr	x1, [x3, #5040]
    a338:	f949ec60 	ldr	x0, [x3, #5080]
    a33c:	cb0102a1 	sub	x1, x21, x1
    a340:	eb00403f 	cmp	x1, x0, lsl #16
    a344:	54000322 	b.cs	a3a8 <f0+0x788>  // b.hs, b.nlast
    a348:	d350fc22 	lsr	x2, x1, #16
    a34c:	f949fc63 	ldr	x3, [x3, #5112]
    a350:	8b020842 	add	x2, x2, x2, lsl #2
    a354:	d37df042 	lsl	x2, x2, #3
    a358:	8b020060 	add	x0, x3, x2
    a35c:	f9401017 	ldr	x23, [x0, #32]
    a360:	b4000257 	cbz	x23, a3a8 <f0+0x788>
    a364:	38626862 	ldrb	w2, [x3, x2]
    a368:	7100085f 	cmp	w2, #0x2
    a36c:	5400e380 	b.eq	bfdc <f0+0x23bc>  // b.none
    a370:	7100045f 	cmp	w2, #0x1
    a374:	540001a1 	b.ne	a3a8 <f0+0x788>  // b.any
    a378:	29430002 	ldp	w2, w0, [x0, #24]
    a37c:	92403c21 	and	x1, x1, #0xffff
    a380:	9b027c21 	mul	x1, x1, x2
    a384:	d360fc21 	lsr	x1, x1, #32
    a388:	eb00003f 	cmp	x1, x0
    a38c:	540000e2 	b.cs	a3a8 <f0+0x788>  // b.hs, b.nlast
    a390:	8b0102f7 	add	x23, x23, x1
    a394:	394002e0 	ldrb	w0, [x23]
    a398:	7103fc1f 	cmp	w0, #0xff
    a39c:	5400eb60 	b.eq	c108 <f0+0x24e8>  // b.none
    a3a0:	52800020 	mov	w0, #0x1                   	// #1
    a3a4:	390002e0 	strb	w0, [x23]
    a3a8:	910763e1 	add	x1, sp, #0x1d8
    a3ac:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a3b0:	52800020 	mov	w0, #0x1                   	// #1
    a3b4:	a91dd7e2 	stp	x2, x21, [sp, #472]
    a3b8:	97ffeb33 	bl	5084 <fwp_data.part.0.constprop.0>
    a3bc:	97ffec96 	bl	5614 <fwp_rc_fresh>
    a3c0:	aa0003e2 	mov	x2, x0
    a3c4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a3c8:	9107a3e1 	add	x1, sp, #0x1e8
    a3cc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a3d0:	52800020 	mov	w0, #0x1                   	// #1
    a3d4:	a91e8be3 	stp	x3, x2, [sp, #488]
    a3d8:	97ffeb2b 	bl	5084 <fwp_data.part.0.constprop.0>
    a3dc:	91174283 	add	x3, x20, #0x5d0
    a3e0:	aa0003f5 	mov	x21, x0
    a3e4:	f949d861 	ldr	x1, [x3, #5040]
    a3e8:	f949ec60 	ldr	x0, [x3, #5080]
    a3ec:	cb0102a1 	sub	x1, x21, x1
    a3f0:	eb00403f 	cmp	x1, x0, lsl #16
    a3f4:	54000322 	b.cs	a458 <f0+0x838>  // b.hs, b.nlast
    a3f8:	d350fc22 	lsr	x2, x1, #16
    a3fc:	f949fc63 	ldr	x3, [x3, #5112]
    a400:	8b020842 	add	x2, x2, x2, lsl #2
    a404:	d37df042 	lsl	x2, x2, #3
    a408:	8b020060 	add	x0, x3, x2
    a40c:	f9401017 	ldr	x23, [x0, #32]
    a410:	b4000257 	cbz	x23, a458 <f0+0x838>
    a414:	38626862 	ldrb	w2, [x3, x2]
    a418:	7100085f 	cmp	w2, #0x2
    a41c:	5400dda0 	b.eq	bfd0 <f0+0x23b0>  // b.none
    a420:	7100045f 	cmp	w2, #0x1
    a424:	540001a1 	b.ne	a458 <f0+0x838>  // b.any
    a428:	29430002 	ldp	w2, w0, [x0, #24]
    a42c:	92403c21 	and	x1, x1, #0xffff
    a430:	9b027c21 	mul	x1, x1, x2
    a434:	d360fc21 	lsr	x1, x1, #32
    a438:	eb00003f 	cmp	x1, x0
    a43c:	540000e2 	b.cs	a458 <f0+0x838>  // b.hs, b.nlast
    a440:	8b0102f7 	add	x23, x23, x1
    a444:	394002e0 	ldrb	w0, [x23]
    a448:	7103fc1f 	cmp	w0, #0xff
    a44c:	5400e640 	b.eq	c114 <f0+0x24f4>  // b.none
    a450:	52800020 	mov	w0, #0x1                   	// #1
    a454:	390002e0 	strb	w0, [x23]
    a458:	9107e3e1 	add	x1, sp, #0x1f8
    a45c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a460:	52800020 	mov	w0, #0x1                   	// #1
    a464:	a91fd7e2 	stp	x2, x21, [sp, #504]
    a468:	97ffeb07 	bl	5084 <fwp_data.part.0.constprop.0>
    a46c:	97ffec6a 	bl	5614 <fwp_rc_fresh>
    a470:	aa0003e2 	mov	x2, x0
    a474:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a478:	910823e1 	add	x1, sp, #0x208
    a47c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a480:	52800020 	mov	w0, #0x1                   	// #1
    a484:	f90107e3 	str	x3, [sp, #520]
    a488:	f9010be2 	str	x2, [sp, #528]
    a48c:	97ffeafe 	bl	5084 <fwp_data.part.0.constprop.0>
    a490:	91174283 	add	x3, x20, #0x5d0
    a494:	aa0003f5 	mov	x21, x0
    a498:	f949d861 	ldr	x1, [x3, #5040]
    a49c:	f949ec60 	ldr	x0, [x3, #5080]
    a4a0:	cb0102a1 	sub	x1, x21, x1
    a4a4:	eb00403f 	cmp	x1, x0, lsl #16
    a4a8:	54000322 	b.cs	a50c <f0+0x8ec>  // b.hs, b.nlast
    a4ac:	d350fc22 	lsr	x2, x1, #16
    a4b0:	f949fc63 	ldr	x3, [x3, #5112]
    a4b4:	8b020842 	add	x2, x2, x2, lsl #2
    a4b8:	d37df042 	lsl	x2, x2, #3
    a4bc:	8b020060 	add	x0, x3, x2
    a4c0:	f9401017 	ldr	x23, [x0, #32]
    a4c4:	b4000257 	cbz	x23, a50c <f0+0x8ec>
    a4c8:	38626862 	ldrb	w2, [x3, x2]
    a4cc:	7100085f 	cmp	w2, #0x2
    a4d0:	5400d7a0 	b.eq	bfc4 <f0+0x23a4>  // b.none
    a4d4:	7100045f 	cmp	w2, #0x1
    a4d8:	540001a1 	b.ne	a50c <f0+0x8ec>  // b.any
    a4dc:	29430002 	ldp	w2, w0, [x0, #24]
    a4e0:	92403c21 	and	x1, x1, #0xffff
    a4e4:	9b027c21 	mul	x1, x1, x2
    a4e8:	d360fc21 	lsr	x1, x1, #32
    a4ec:	eb00003f 	cmp	x1, x0
    a4f0:	540000e2 	b.cs	a50c <f0+0x8ec>  // b.hs, b.nlast
    a4f4:	8b0102f7 	add	x23, x23, x1
    a4f8:	394002e0 	ldrb	w0, [x23]
    a4fc:	7103fc1f 	cmp	w0, #0xff
    a500:	5400e100 	b.eq	c120 <f0+0x2500>  // b.none
    a504:	52800020 	mov	w0, #0x1                   	// #1
    a508:	390002e0 	strb	w0, [x23]
    a50c:	910863e1 	add	x1, sp, #0x218
    a510:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a514:	52800020 	mov	w0, #0x1                   	// #1
    a518:	f9010ff7 	str	x23, [sp, #536]
    a51c:	f90113f5 	str	x21, [sp, #544]
    a520:	97ffead9 	bl	5084 <fwp_data.part.0.constprop.0>
    a524:	97ffec3c 	bl	5614 <fwp_rc_fresh>
    a528:	aa0003e2 	mov	x2, x0
    a52c:	9108a3e1 	add	x1, sp, #0x228
    a530:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a534:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a538:	52800020 	mov	w0, #0x1                   	// #1
    a53c:	f90117f5 	str	x21, [sp, #552]
    a540:	f9011be2 	str	x2, [sp, #560]
    a544:	97ffead0 	bl	5084 <fwp_data.part.0.constprop.0>
    a548:	97ffec33 	bl	5614 <fwp_rc_fresh>
    a54c:	aa0003e2 	mov	x2, x0
    a550:	9108e3e1 	add	x1, sp, #0x238
    a554:	52800020 	mov	w0, #0x1                   	// #1
    a558:	f9011ff7 	str	x23, [sp, #568]
    a55c:	f90123e2 	str	x2, [sp, #576]
    a560:	97ffeac9 	bl	5084 <fwp_data.part.0.constprop.0>
    a564:	97ffec2c 	bl	5614 <fwp_rc_fresh>
    a568:	aa0003e2 	mov	x2, x0
    a56c:	910923e1 	add	x1, sp, #0x248
    a570:	52800020 	mov	w0, #0x1                   	// #1
    a574:	f90127f5 	str	x21, [sp, #584]
    a578:	f9012be2 	str	x2, [sp, #592]
    a57c:	97ffeac2 	bl	5084 <fwp_data.part.0.constprop.0>
    a580:	91174283 	add	x3, x20, #0x5d0
    a584:	aa0003f5 	mov	x21, x0
    a588:	f949d861 	ldr	x1, [x3, #5040]
    a58c:	f949ec60 	ldr	x0, [x3, #5080]
    a590:	cb0102a1 	sub	x1, x21, x1
    a594:	eb00403f 	cmp	x1, x0, lsl #16
    a598:	54000322 	b.cs	a5fc <f0+0x9dc>  // b.hs, b.nlast
    a59c:	d350fc22 	lsr	x2, x1, #16
    a5a0:	f949fc63 	ldr	x3, [x3, #5112]
    a5a4:	8b020842 	add	x2, x2, x2, lsl #2
    a5a8:	d37df042 	lsl	x2, x2, #3
    a5ac:	8b020060 	add	x0, x3, x2
    a5b0:	f9401017 	ldr	x23, [x0, #32]
    a5b4:	b4000257 	cbz	x23, a5fc <f0+0x9dc>
    a5b8:	38626862 	ldrb	w2, [x3, x2]
    a5bc:	7100085f 	cmp	w2, #0x2
    a5c0:	5400cfc0 	b.eq	bfb8 <f0+0x2398>  // b.none
    a5c4:	7100045f 	cmp	w2, #0x1
    a5c8:	540001a1 	b.ne	a5fc <f0+0x9dc>  // b.any
    a5cc:	29430002 	ldp	w2, w0, [x0, #24]
    a5d0:	92403c21 	and	x1, x1, #0xffff
    a5d4:	9b027c21 	mul	x1, x1, x2
    a5d8:	d360fc21 	lsr	x1, x1, #32
    a5dc:	eb00003f 	cmp	x1, x0
    a5e0:	540000e2 	b.cs	a5fc <f0+0x9dc>  // b.hs, b.nlast
    a5e4:	8b0102f7 	add	x23, x23, x1
    a5e8:	394002e0 	ldrb	w0, [x23]
    a5ec:	7103fc1f 	cmp	w0, #0xff
    a5f0:	5400d9e0 	b.eq	c12c <f0+0x250c>  // b.none
    a5f4:	52800020 	mov	w0, #0x1                   	// #1
    a5f8:	390002e0 	strb	w0, [x23]
    a5fc:	910963e1 	add	x1, sp, #0x258
    a600:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a604:	52800020 	mov	w0, #0x1                   	// #1
    a608:	f9012fe2 	str	x2, [sp, #600]
    a60c:	f90133f5 	str	x21, [sp, #608]
    a610:	97ffea9d 	bl	5084 <fwp_data.part.0.constprop.0>
    a614:	97ffec00 	bl	5614 <fwp_rc_fresh>
    a618:	aa0003e2 	mov	x2, x0
    a61c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a620:	9109a3e1 	add	x1, sp, #0x268
    a624:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a628:	52800020 	mov	w0, #0x1                   	// #1
    a62c:	f90137e3 	str	x3, [sp, #616]
    a630:	f9013be2 	str	x2, [sp, #624]
    a634:	97ffea94 	bl	5084 <fwp_data.part.0.constprop.0>
    a638:	91174283 	add	x3, x20, #0x5d0
    a63c:	aa0003f5 	mov	x21, x0
    a640:	f949d861 	ldr	x1, [x3, #5040]
    a644:	f949ec60 	ldr	x0, [x3, #5080]
    a648:	cb0102a1 	sub	x1, x21, x1
    a64c:	eb00403f 	cmp	x1, x0, lsl #16
    a650:	54000322 	b.cs	a6b4 <f0+0xa94>  // b.hs, b.nlast
    a654:	d350fc22 	lsr	x2, x1, #16
    a658:	f949fc63 	ldr	x3, [x3, #5112]
    a65c:	8b020842 	add	x2, x2, x2, lsl #2
    a660:	d37df042 	lsl	x2, x2, #3
    a664:	8b020060 	add	x0, x3, x2
    a668:	f9401017 	ldr	x23, [x0, #32]
    a66c:	b4000257 	cbz	x23, a6b4 <f0+0xa94>
    a670:	38626862 	ldrb	w2, [x3, x2]
    a674:	7100085f 	cmp	w2, #0x2
    a678:	5400c9a0 	b.eq	bfac <f0+0x238c>  // b.none
    a67c:	7100045f 	cmp	w2, #0x1
    a680:	540001a1 	b.ne	a6b4 <f0+0xa94>  // b.any
    a684:	29430002 	ldp	w2, w0, [x0, #24]
    a688:	92403c21 	and	x1, x1, #0xffff
    a68c:	9b027c21 	mul	x1, x1, x2
    a690:	d360fc21 	lsr	x1, x1, #32
    a694:	eb00003f 	cmp	x1, x0
    a698:	540000e2 	b.cs	a6b4 <f0+0xa94>  // b.hs, b.nlast
    a69c:	8b0102f7 	add	x23, x23, x1
    a6a0:	394002e0 	ldrb	w0, [x23]
    a6a4:	7103fc1f 	cmp	w0, #0xff
    a6a8:	5400d480 	b.eq	c138 <f0+0x2518>  // b.none
    a6ac:	52800020 	mov	w0, #0x1                   	// #1
    a6b0:	390002e0 	strb	w0, [x23]
    a6b4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a6b8:	9109e3e1 	add	x1, sp, #0x278
    a6bc:	52800020 	mov	w0, #0x1                   	// #1
    a6c0:	f9013fe2 	str	x2, [sp, #632]
    a6c4:	f90143f5 	str	x21, [sp, #640]
    a6c8:	97ffea6f 	bl	5084 <fwp_data.part.0.constprop.0>
    a6cc:	91174283 	add	x3, x20, #0x5d0
    a6d0:	aa0003f5 	mov	x21, x0
    a6d4:	f949d861 	ldr	x1, [x3, #5040]
    a6d8:	f949ec60 	ldr	x0, [x3, #5080]
    a6dc:	cb0102a1 	sub	x1, x21, x1
    a6e0:	eb00403f 	cmp	x1, x0, lsl #16
    a6e4:	54000322 	b.cs	a748 <f0+0xb28>  // b.hs, b.nlast
    a6e8:	d350fc22 	lsr	x2, x1, #16
    a6ec:	f949fc63 	ldr	x3, [x3, #5112]
    a6f0:	8b020842 	add	x2, x2, x2, lsl #2
    a6f4:	d37df042 	lsl	x2, x2, #3
    a6f8:	8b020060 	add	x0, x3, x2
    a6fc:	f9401017 	ldr	x23, [x0, #32]
    a700:	b4000257 	cbz	x23, a748 <f0+0xb28>
    a704:	38626862 	ldrb	w2, [x3, x2]
    a708:	7100085f 	cmp	w2, #0x2
    a70c:	5400c4a0 	b.eq	bfa0 <f0+0x2380>  // b.none
    a710:	7100045f 	cmp	w2, #0x1
    a714:	540001a1 	b.ne	a748 <f0+0xb28>  // b.any
    a718:	29430002 	ldp	w2, w0, [x0, #24]
    a71c:	92403c21 	and	x1, x1, #0xffff
    a720:	9b027c21 	mul	x1, x1, x2
    a724:	d360fc21 	lsr	x1, x1, #32
    a728:	eb00003f 	cmp	x1, x0
    a72c:	540000e2 	b.cs	a748 <f0+0xb28>  // b.hs, b.nlast
    a730:	8b0102f7 	add	x23, x23, x1
    a734:	394002e0 	ldrb	w0, [x23]
    a738:	7103fc1f 	cmp	w0, #0xff
    a73c:	5400d040 	b.eq	c144 <f0+0x2524>  // b.none
    a740:	52800020 	mov	w0, #0x1                   	// #1
    a744:	390002e0 	strb	w0, [x23]
    a748:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a74c:	910a23e1 	add	x1, sp, #0x288
    a750:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a754:	52800020 	mov	w0, #0x1                   	// #1
    a758:	f90147e2 	str	x2, [sp, #648]
    a75c:	f9014bf5 	str	x21, [sp, #656]
    a760:	97ffea49 	bl	5084 <fwp_data.part.0.constprop.0>
    a764:	91174283 	add	x3, x20, #0x5d0
    a768:	aa0003f5 	mov	x21, x0
    a76c:	f949d861 	ldr	x1, [x3, #5040]
    a770:	f949ec60 	ldr	x0, [x3, #5080]
    a774:	cb0102a1 	sub	x1, x21, x1
    a778:	eb00403f 	cmp	x1, x0, lsl #16
    a77c:	54000322 	b.cs	a7e0 <f0+0xbc0>  // b.hs, b.nlast
    a780:	d350fc22 	lsr	x2, x1, #16
    a784:	f949fc63 	ldr	x3, [x3, #5112]
    a788:	8b020842 	add	x2, x2, x2, lsl #2
    a78c:	d37df042 	lsl	x2, x2, #3
    a790:	8b020060 	add	x0, x3, x2
    a794:	f9401017 	ldr	x23, [x0, #32]
    a798:	b4000257 	cbz	x23, a7e0 <f0+0xbc0>
    a79c:	38626862 	ldrb	w2, [x3, x2]
    a7a0:	7100085f 	cmp	w2, #0x2
    a7a4:	5400bf80 	b.eq	bf94 <f0+0x2374>  // b.none
    a7a8:	7100045f 	cmp	w2, #0x1
    a7ac:	540001a1 	b.ne	a7e0 <f0+0xbc0>  // b.any
    a7b0:	29430002 	ldp	w2, w0, [x0, #24]
    a7b4:	92403c21 	and	x1, x1, #0xffff
    a7b8:	9b027c21 	mul	x1, x1, x2
    a7bc:	d360fc21 	lsr	x1, x1, #32
    a7c0:	eb00003f 	cmp	x1, x0
    a7c4:	540000e2 	b.cs	a7e0 <f0+0xbc0>  // b.hs, b.nlast
    a7c8:	8b0102f7 	add	x23, x23, x1
    a7cc:	394002e0 	ldrb	w0, [x23]
    a7d0:	7103fc1f 	cmp	w0, #0xff
    a7d4:	5400cbe0 	b.eq	c150 <f0+0x2530>  // b.none
    a7d8:	52800020 	mov	w0, #0x1                   	// #1
    a7dc:	390002e0 	strb	w0, [x23]
    a7e0:	910a63e1 	add	x1, sp, #0x298
    a7e4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a7e8:	52800020 	mov	w0, #0x1                   	// #1
    a7ec:	f9014ff7 	str	x23, [sp, #664]
    a7f0:	f90153f5 	str	x21, [sp, #672]
    a7f4:	97ffea24 	bl	5084 <fwp_data.part.0.constprop.0>
    a7f8:	97ffeb87 	bl	5614 <fwp_rc_fresh>
    a7fc:	aa0003e2 	mov	x2, x0
    a800:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a804:	910aa3e1 	add	x1, sp, #0x2a8
    a808:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a80c:	52800020 	mov	w0, #0x1                   	// #1
    a810:	f90157e3 	str	x3, [sp, #680]
    a814:	f9015be2 	str	x2, [sp, #688]
    a818:	97ffea1b 	bl	5084 <fwp_data.part.0.constprop.0>
    a81c:	97ffeb7e 	bl	5614 <fwp_rc_fresh>
    a820:	aa0003e2 	mov	x2, x0
    a824:	910ae3e1 	add	x1, sp, #0x2b8
    a828:	52800020 	mov	w0, #0x1                   	// #1
    a82c:	f9015ff7 	str	x23, [sp, #696]
    a830:	f90163e2 	str	x2, [sp, #704]
    a834:	97ffea14 	bl	5084 <fwp_data.part.0.constprop.0>
    a838:	91174283 	add	x3, x20, #0x5d0
    a83c:	aa0003f5 	mov	x21, x0
    a840:	f949d861 	ldr	x1, [x3, #5040]
    a844:	f949ec60 	ldr	x0, [x3, #5080]
    a848:	cb0102a1 	sub	x1, x21, x1
    a84c:	eb00403f 	cmp	x1, x0, lsl #16
    a850:	54000322 	b.cs	a8b4 <f0+0xc94>  // b.hs, b.nlast
    a854:	d350fc22 	lsr	x2, x1, #16
    a858:	f949fc63 	ldr	x3, [x3, #5112]
    a85c:	8b020842 	add	x2, x2, x2, lsl #2
    a860:	d37df042 	lsl	x2, x2, #3
    a864:	8b020060 	add	x0, x3, x2
    a868:	f9401017 	ldr	x23, [x0, #32]
    a86c:	b4000257 	cbz	x23, a8b4 <f0+0xc94>
    a870:	38626862 	ldrb	w2, [x3, x2]
    a874:	7100085f 	cmp	w2, #0x2
    a878:	5400b880 	b.eq	bf88 <f0+0x2368>  // b.none
    a87c:	7100045f 	cmp	w2, #0x1
    a880:	540001a1 	b.ne	a8b4 <f0+0xc94>  // b.any
    a884:	29430002 	ldp	w2, w0, [x0, #24]
    a888:	92403c21 	and	x1, x1, #0xffff
    a88c:	9b027c21 	mul	x1, x1, x2
    a890:	d360fc21 	lsr	x1, x1, #32
    a894:	eb00003f 	cmp	x1, x0
    a898:	540000e2 	b.cs	a8b4 <f0+0xc94>  // b.hs, b.nlast
    a89c:	8b0102f7 	add	x23, x23, x1
    a8a0:	394002e0 	ldrb	w0, [x23]
    a8a4:	7103fc1f 	cmp	w0, #0xff
    a8a8:	5400c5a0 	b.eq	c15c <f0+0x253c>  // b.none
    a8ac:	52800020 	mov	w0, #0x1                   	// #1
    a8b0:	390002e0 	strb	w0, [x23]
    a8b4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a8b8:	910b23e1 	add	x1, sp, #0x2c8
    a8bc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a8c0:	52800020 	mov	w0, #0x1                   	// #1
    a8c4:	f90167e2 	str	x2, [sp, #712]
    a8c8:	f9016bf5 	str	x21, [sp, #720]
    a8cc:	97ffe9ee 	bl	5084 <fwp_data.part.0.constprop.0>
    a8d0:	91174283 	add	x3, x20, #0x5d0
    a8d4:	aa0003f5 	mov	x21, x0
    a8d8:	f949d861 	ldr	x1, [x3, #5040]
    a8dc:	f949ec60 	ldr	x0, [x3, #5080]
    a8e0:	cb0102a1 	sub	x1, x21, x1
    a8e4:	eb00403f 	cmp	x1, x0, lsl #16
    a8e8:	54000322 	b.cs	a94c <f0+0xd2c>  // b.hs, b.nlast
    a8ec:	d350fc22 	lsr	x2, x1, #16
    a8f0:	f949fc63 	ldr	x3, [x3, #5112]
    a8f4:	8b020842 	add	x2, x2, x2, lsl #2
    a8f8:	d37df042 	lsl	x2, x2, #3
    a8fc:	8b020060 	add	x0, x3, x2
    a900:	f9401017 	ldr	x23, [x0, #32]
    a904:	b4000257 	cbz	x23, a94c <f0+0xd2c>
    a908:	38626862 	ldrb	w2, [x3, x2]
    a90c:	7100085f 	cmp	w2, #0x2
    a910:	5400b0c0 	b.eq	bf28 <f0+0x2308>  // b.none
    a914:	7100045f 	cmp	w2, #0x1
    a918:	540001a1 	b.ne	a94c <f0+0xd2c>  // b.any
    a91c:	29430002 	ldp	w2, w0, [x0, #24]
    a920:	92403c21 	and	x1, x1, #0xffff
    a924:	9b027c21 	mul	x1, x1, x2
    a928:	d360fc21 	lsr	x1, x1, #32
    a92c:	eb00003f 	cmp	x1, x0
    a930:	540000e2 	b.cs	a94c <f0+0xd2c>  // b.hs, b.nlast
    a934:	8b0102f7 	add	x23, x23, x1
    a938:	394002e0 	ldrb	w0, [x23]
    a93c:	7103fc1f 	cmp	w0, #0xff
    a940:	5400c140 	b.eq	c168 <f0+0x2548>  // b.none
    a944:	52800020 	mov	w0, #0x1                   	// #1
    a948:	390002e0 	strb	w0, [x23]
    a94c:	910b63e1 	add	x1, sp, #0x2d8
    a950:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a954:	52800020 	mov	w0, #0x1                   	// #1
    a958:	f9016ff7 	str	x23, [sp, #728]
    a95c:	f90173f5 	str	x21, [sp, #736]
    a960:	97ffe9c9 	bl	5084 <fwp_data.part.0.constprop.0>
    a964:	97ffeb2c 	bl	5614 <fwp_rc_fresh>
    a968:	aa0003e2 	mov	x2, x0
    a96c:	910ba3e1 	add	x1, sp, #0x2e8
    a970:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a974:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a978:	52800020 	mov	w0, #0x1                   	// #1
    a97c:	f90177f5 	str	x21, [sp, #744]
    a980:	f9017be2 	str	x2, [sp, #752]
    a984:	97ffe9c0 	bl	5084 <fwp_data.part.0.constprop.0>
    a988:	97ffeb23 	bl	5614 <fwp_rc_fresh>
    a98c:	aa0003e2 	mov	x2, x0
    a990:	910be3e1 	add	x1, sp, #0x2f8
    a994:	52800020 	mov	w0, #0x1                   	// #1
    a998:	f9017ff7 	str	x23, [sp, #760]
    a99c:	f90183e2 	str	x2, [sp, #768]
    a9a0:	97ffe9b9 	bl	5084 <fwp_data.part.0.constprop.0>
    a9a4:	97ffeb1c 	bl	5614 <fwp_rc_fresh>
    a9a8:	aa0003e2 	mov	x2, x0
    a9ac:	910c23e1 	add	x1, sp, #0x308
    a9b0:	52800020 	mov	w0, #0x1                   	// #1
    a9b4:	f90187f5 	str	x21, [sp, #776]
    a9b8:	f9018be2 	str	x2, [sp, #784]
    a9bc:	97ffe9b2 	bl	5084 <fwp_data.part.0.constprop.0>
    a9c0:	91174283 	add	x3, x20, #0x5d0
    a9c4:	aa0003f5 	mov	x21, x0
    a9c8:	f949d861 	ldr	x1, [x3, #5040]
    a9cc:	f949ec60 	ldr	x0, [x3, #5080]
    a9d0:	cb0102a1 	sub	x1, x21, x1
    a9d4:	eb00403f 	cmp	x1, x0, lsl #16
    a9d8:	54000322 	b.cs	aa3c <f0+0xe1c>  // b.hs, b.nlast
    a9dc:	d350fc22 	lsr	x2, x1, #16
    a9e0:	f949fc63 	ldr	x3, [x3, #5112]
    a9e4:	8b020842 	add	x2, x2, x2, lsl #2
    a9e8:	d37df042 	lsl	x2, x2, #3
    a9ec:	8b020060 	add	x0, x3, x2
    a9f0:	f9401017 	ldr	x23, [x0, #32]
    a9f4:	b4000257 	cbz	x23, aa3c <f0+0xe1c>
    a9f8:	38626862 	ldrb	w2, [x3, x2]
    a9fc:	7100085f 	cmp	w2, #0x2
    aa00:	5400a8e0 	b.eq	bf1c <f0+0x22fc>  // b.none
    aa04:	7100045f 	cmp	w2, #0x1
    aa08:	540001a1 	b.ne	aa3c <f0+0xe1c>  // b.any
    aa0c:	29430002 	ldp	w2, w0, [x0, #24]
    aa10:	92403c21 	and	x1, x1, #0xffff
    aa14:	9b027c21 	mul	x1, x1, x2
    aa18:	d360fc21 	lsr	x1, x1, #32
    aa1c:	eb00003f 	cmp	x1, x0
    aa20:	540000e2 	b.cs	aa3c <f0+0xe1c>  // b.hs, b.nlast
    aa24:	8b0102f7 	add	x23, x23, x1
    aa28:	394002e0 	ldrb	w0, [x23]
    aa2c:	7103fc1f 	cmp	w0, #0xff
    aa30:	5400ba20 	b.eq	c174 <f0+0x2554>  // b.none
    aa34:	52800020 	mov	w0, #0x1                   	// #1
    aa38:	390002e0 	strb	w0, [x23]
    aa3c:	910c63e1 	add	x1, sp, #0x318
    aa40:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    aa44:	52800020 	mov	w0, #0x1                   	// #1
    aa48:	f9018ff7 	str	x23, [sp, #792]
    aa4c:	f90193f5 	str	x21, [sp, #800]
    aa50:	97ffe98d 	bl	5084 <fwp_data.part.0.constprop.0>
    aa54:	97ffeaf0 	bl	5614 <fwp_rc_fresh>
    aa58:	aa0003e2 	mov	x2, x0
    aa5c:	910ca3e1 	add	x1, sp, #0x328
    aa60:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    aa64:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    aa68:	52800020 	mov	w0, #0x1                   	// #1
    aa6c:	f90197f5 	str	x21, [sp, #808]
    aa70:	f9019be2 	str	x2, [sp, #816]
    aa74:	97ffe984 	bl	5084 <fwp_data.part.0.constprop.0>
    aa78:	97ffeae7 	bl	5614 <fwp_rc_fresh>
    aa7c:	aa0003e2 	mov	x2, x0
    aa80:	910ce3e1 	add	x1, sp, #0x338
    aa84:	52800020 	mov	w0, #0x1                   	// #1
    aa88:	f9019ff7 	str	x23, [sp, #824]
    aa8c:	f901a3e2 	str	x2, [sp, #832]
    aa90:	97ffe97d 	bl	5084 <fwp_data.part.0.constprop.0>
    aa94:	97ffeae0 	bl	5614 <fwp_rc_fresh>
    aa98:	aa0003e2 	mov	x2, x0
    aa9c:	910d23e1 	add	x1, sp, #0x348
    aaa0:	52800020 	mov	w0, #0x1                   	// #1
    aaa4:	f901a7f5 	str	x21, [sp, #840]
    aaa8:	f901abe2 	str	x2, [sp, #848]
    aaac:	97ffe976 	bl	5084 <fwp_data.part.0.constprop.0>
    aab0:	97ffead9 	bl	5614 <fwp_rc_fresh>
    aab4:	aa0003e2 	mov	x2, x0
    aab8:	910d63e1 	add	x1, sp, #0x358
    aabc:	52800020 	mov	w0, #0x1                   	// #1
    aac0:	f901aff7 	str	x23, [sp, #856]
    aac4:	f901b3e2 	str	x2, [sp, #864]
    aac8:	97ffe96f 	bl	5084 <fwp_data.part.0.constprop.0>
    aacc:	97ffead2 	bl	5614 <fwp_rc_fresh>
    aad0:	aa0003e2 	mov	x2, x0
    aad4:	910da3e1 	add	x1, sp, #0x368
    aad8:	52800020 	mov	w0, #0x1                   	// #1
    aadc:	f901b7f5 	str	x21, [sp, #872]
    aae0:	f901bbe2 	str	x2, [sp, #880]
    aae4:	97ffe968 	bl	5084 <fwp_data.part.0.constprop.0>
    aae8:	97ffeacb 	bl	5614 <fwp_rc_fresh>
    aaec:	aa0003e2 	mov	x2, x0
    aaf0:	910de3e1 	add	x1, sp, #0x378
    aaf4:	52800020 	mov	w0, #0x1                   	// #1
    aaf8:	f901bff7 	str	x23, [sp, #888]
    aafc:	f901c3e2 	str	x2, [sp, #896]
    ab00:	97ffe961 	bl	5084 <fwp_data.part.0.constprop.0>
    ab04:	97ffeac4 	bl	5614 <fwp_rc_fresh>
    ab08:	aa0003e2 	mov	x2, x0
    ab0c:	910e23e1 	add	x1, sp, #0x388
    ab10:	52800020 	mov	w0, #0x1                   	// #1
    ab14:	f901c7f5 	str	x21, [sp, #904]
    ab18:	f901cbe2 	str	x2, [sp, #912]
    ab1c:	97ffe95a 	bl	5084 <fwp_data.part.0.constprop.0>
    ab20:	91174283 	add	x3, x20, #0x5d0
    ab24:	aa0003f5 	mov	x21, x0
    ab28:	f949d861 	ldr	x1, [x3, #5040]
    ab2c:	f949ec60 	ldr	x0, [x3, #5080]
    ab30:	cb0102a1 	sub	x1, x21, x1
    ab34:	eb00403f 	cmp	x1, x0, lsl #16
    ab38:	54000322 	b.cs	ab9c <f0+0xf7c>  // b.hs, b.nlast
    ab3c:	d350fc22 	lsr	x2, x1, #16
    ab40:	f949fc63 	ldr	x3, [x3, #5112]
    ab44:	8b020842 	add	x2, x2, x2, lsl #2
    ab48:	d37df042 	lsl	x2, x2, #3
    ab4c:	8b020060 	add	x0, x3, x2
    ab50:	f9401017 	ldr	x23, [x0, #32]
    ab54:	b4000257 	cbz	x23, ab9c <f0+0xf7c>
    ab58:	38626862 	ldrb	w2, [x3, x2]
    ab5c:	7100085f 	cmp	w2, #0x2
    ab60:	54009d80 	b.eq	bf10 <f0+0x22f0>  // b.none
    ab64:	7100045f 	cmp	w2, #0x1
    ab68:	540001a1 	b.ne	ab9c <f0+0xf7c>  // b.any
    ab6c:	29430002 	ldp	w2, w0, [x0, #24]
    ab70:	92403c21 	and	x1, x1, #0xffff
    ab74:	9b027c21 	mul	x1, x1, x2
    ab78:	d360fc21 	lsr	x1, x1, #32
    ab7c:	eb00003f 	cmp	x1, x0
    ab80:	540000e2 	b.cs	ab9c <f0+0xf7c>  // b.hs, b.nlast
    ab84:	8b0102f7 	add	x23, x23, x1
    ab88:	394002e0 	ldrb	w0, [x23]
    ab8c:	7103fc1f 	cmp	w0, #0xff
    ab90:	5400af80 	b.eq	c180 <f0+0x2560>  // b.none
    ab94:	52800020 	mov	w0, #0x1                   	// #1
    ab98:	390002e0 	strb	w0, [x23]
    ab9c:	910e63e1 	add	x1, sp, #0x398
    aba0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    aba4:	52800020 	mov	w0, #0x1                   	// #1
    aba8:	f901cff7 	str	x23, [sp, #920]
    abac:	f901d3f5 	str	x21, [sp, #928]
    abb0:	97ffe935 	bl	5084 <fwp_data.part.0.constprop.0>
    abb4:	97ffea98 	bl	5614 <fwp_rc_fresh>
    abb8:	aa0003e2 	mov	x2, x0
    abbc:	910ea3e1 	add	x1, sp, #0x3a8
    abc0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    abc4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    abc8:	52800020 	mov	w0, #0x1                   	// #1
    abcc:	f901d7f5 	str	x21, [sp, #936]
    abd0:	f901dbe2 	str	x2, [sp, #944]
    abd4:	97ffe92c 	bl	5084 <fwp_data.part.0.constprop.0>
    abd8:	97ffea8f 	bl	5614 <fwp_rc_fresh>
    abdc:	aa0003e2 	mov	x2, x0
    abe0:	910ee3e1 	add	x1, sp, #0x3b8
    abe4:	52800020 	mov	w0, #0x1                   	// #1
    abe8:	f901dff7 	str	x23, [sp, #952]
    abec:	f901e3e2 	str	x2, [sp, #960]
    abf0:	97ffe925 	bl	5084 <fwp_data.part.0.constprop.0>
    abf4:	97ffea88 	bl	5614 <fwp_rc_fresh>
    abf8:	aa0003e2 	mov	x2, x0
    abfc:	910f23e1 	add	x1, sp, #0x3c8
    ac00:	52800020 	mov	w0, #0x1                   	// #1
    ac04:	f901e7f5 	str	x21, [sp, #968]
    ac08:	f901ebe2 	str	x2, [sp, #976]
    ac0c:	97ffe91e 	bl	5084 <fwp_data.part.0.constprop.0>
    ac10:	91174283 	add	x3, x20, #0x5d0
    ac14:	aa0003f5 	mov	x21, x0
    ac18:	f949d861 	ldr	x1, [x3, #5040]
    ac1c:	f949ec60 	ldr	x0, [x3, #5080]
    ac20:	cb0102a1 	sub	x1, x21, x1
    ac24:	eb00403f 	cmp	x1, x0, lsl #16
    ac28:	54000322 	b.cs	ac8c <f0+0x106c>  // b.hs, b.nlast
    ac2c:	d350fc22 	lsr	x2, x1, #16
    ac30:	f949fc63 	ldr	x3, [x3, #5112]
    ac34:	8b020842 	add	x2, x2, x2, lsl #2
    ac38:	d37df042 	lsl	x2, x2, #3
    ac3c:	8b020060 	add	x0, x3, x2
    ac40:	f9401017 	ldr	x23, [x0, #32]
    ac44:	b4000257 	cbz	x23, ac8c <f0+0x106c>
    ac48:	38626862 	ldrb	w2, [x3, x2]
    ac4c:	7100085f 	cmp	w2, #0x2
    ac50:	540095a0 	b.eq	bf04 <f0+0x22e4>  // b.none
    ac54:	7100045f 	cmp	w2, #0x1
    ac58:	540001a1 	b.ne	ac8c <f0+0x106c>  // b.any
    ac5c:	29430002 	ldp	w2, w0, [x0, #24]
    ac60:	92403c21 	and	x1, x1, #0xffff
    ac64:	9b027c21 	mul	x1, x1, x2
    ac68:	d360fc21 	lsr	x1, x1, #32
    ac6c:	eb00003f 	cmp	x1, x0
    ac70:	540000e2 	b.cs	ac8c <f0+0x106c>  // b.hs, b.nlast
    ac74:	8b0102f7 	add	x23, x23, x1
    ac78:	394002e0 	ldrb	w0, [x23]
    ac7c:	7103fc1f 	cmp	w0, #0xff
    ac80:	5400a860 	b.eq	c18c <f0+0x256c>  // b.none
    ac84:	52800020 	mov	w0, #0x1                   	// #1
    ac88:	390002e0 	strb	w0, [x23]
    ac8c:	910f63e1 	add	x1, sp, #0x3d8
    ac90:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ac94:	52800020 	mov	w0, #0x1                   	// #1
    ac98:	f901eff7 	str	x23, [sp, #984]
    ac9c:	f901f3f5 	str	x21, [sp, #992]
    aca0:	97ffe8f9 	bl	5084 <fwp_data.part.0.constprop.0>
    aca4:	97ffea5c 	bl	5614 <fwp_rc_fresh>
    aca8:	aa0003e2 	mov	x2, x0
    acac:	910fa3e1 	add	x1, sp, #0x3e8
    acb0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    acb4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    acb8:	52800020 	mov	w0, #0x1                   	// #1
    acbc:	f901f7f5 	str	x21, [sp, #1000]
    acc0:	f901fbe2 	str	x2, [sp, #1008]
    acc4:	97ffe8f0 	bl	5084 <fwp_data.part.0.constprop.0>
    acc8:	97ffea53 	bl	5614 <fwp_rc_fresh>
    accc:	aa0003e2 	mov	x2, x0
    acd0:	910fe3e1 	add	x1, sp, #0x3f8
    acd4:	52800020 	mov	w0, #0x1                   	// #1
    acd8:	f901fff7 	str	x23, [sp, #1016]
    acdc:	f90203e2 	str	x2, [sp, #1024]
    ace0:	97ffe8e9 	bl	5084 <fwp_data.part.0.constprop.0>
    ace4:	97ffea4c 	bl	5614 <fwp_rc_fresh>
    ace8:	aa0003e2 	mov	x2, x0
    acec:	911023e1 	add	x1, sp, #0x408
    acf0:	52800020 	mov	w0, #0x1                   	// #1
    acf4:	f90207f5 	str	x21, [sp, #1032]
    acf8:	f9020be2 	str	x2, [sp, #1040]
    acfc:	97ffe8e2 	bl	5084 <fwp_data.part.0.constprop.0>
    ad00:	91174283 	add	x3, x20, #0x5d0
    ad04:	aa0003f5 	mov	x21, x0
    ad08:	f949d861 	ldr	x1, [x3, #5040]
    ad0c:	f949ec60 	ldr	x0, [x3, #5080]
    ad10:	cb0102a1 	sub	x1, x21, x1
    ad14:	eb00403f 	cmp	x1, x0, lsl #16
    ad18:	54000322 	b.cs	ad7c <f0+0x115c>  // b.hs, b.nlast
    ad1c:	d350fc22 	lsr	x2, x1, #16
    ad20:	f949fc63 	ldr	x3, [x3, #5112]
    ad24:	8b020842 	add	x2, x2, x2, lsl #2
    ad28:	d37df042 	lsl	x2, x2, #3
    ad2c:	8b020060 	add	x0, x3, x2
    ad30:	f9401017 	ldr	x23, [x0, #32]
    ad34:	b4000257 	cbz	x23, ad7c <f0+0x115c>
    ad38:	38626862 	ldrb	w2, [x3, x2]
    ad3c:	7100085f 	cmp	w2, #0x2
    ad40:	54008dc0 	b.eq	bef8 <f0+0x22d8>  // b.none
    ad44:	7100045f 	cmp	w2, #0x1
    ad48:	540001a1 	b.ne	ad7c <f0+0x115c>  // b.any
    ad4c:	29430002 	ldp	w2, w0, [x0, #24]
    ad50:	92403c21 	and	x1, x1, #0xffff
    ad54:	9b027c21 	mul	x1, x1, x2
    ad58:	d360fc21 	lsr	x1, x1, #32
    ad5c:	eb00003f 	cmp	x1, x0
    ad60:	540000e2 	b.cs	ad7c <f0+0x115c>  // b.hs, b.nlast
    ad64:	8b0102f7 	add	x23, x23, x1
    ad68:	394002e0 	ldrb	w0, [x23]
    ad6c:	7103fc1f 	cmp	w0, #0xff
    ad70:	5400a140 	b.eq	c198 <f0+0x2578>  // b.none
    ad74:	52800020 	mov	w0, #0x1                   	// #1
    ad78:	390002e0 	strb	w0, [x23]
    ad7c:	911063e1 	add	x1, sp, #0x418
    ad80:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ad84:	52800020 	mov	w0, #0x1                   	// #1
    ad88:	f9020ff7 	str	x23, [sp, #1048]
    ad8c:	f90213f5 	str	x21, [sp, #1056]
    ad90:	97ffe8bd 	bl	5084 <fwp_data.part.0.constprop.0>
    ad94:	97ffea20 	bl	5614 <fwp_rc_fresh>
    ad98:	aa0003e2 	mov	x2, x0
    ad9c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ada0:	9110a3e1 	add	x1, sp, #0x428
    ada4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ada8:	52800020 	mov	w0, #0x1                   	// #1
    adac:	f90217e3 	str	x3, [sp, #1064]
    adb0:	f9021be2 	str	x2, [sp, #1072]
    adb4:	97ffe8b4 	bl	5084 <fwp_data.part.0.constprop.0>
    adb8:	97ffea17 	bl	5614 <fwp_rc_fresh>
    adbc:	aa0003e2 	mov	x2, x0
    adc0:	9110e3e1 	add	x1, sp, #0x438
    adc4:	52800020 	mov	w0, #0x1                   	// #1
    adc8:	f9021ff7 	str	x23, [sp, #1080]
    adcc:	f90223e2 	str	x2, [sp, #1088]
    add0:	97ffe8ad 	bl	5084 <fwp_data.part.0.constprop.0>
    add4:	91174283 	add	x3, x20, #0x5d0
    add8:	aa0003f5 	mov	x21, x0
    addc:	f949d861 	ldr	x1, [x3, #5040]
    ade0:	f949ec60 	ldr	x0, [x3, #5080]
    ade4:	cb0102a1 	sub	x1, x21, x1
    ade8:	eb00403f 	cmp	x1, x0, lsl #16
    adec:	54000322 	b.cs	ae50 <f0+0x1230>  // b.hs, b.nlast
    adf0:	d350fc22 	lsr	x2, x1, #16
    adf4:	f949fc63 	ldr	x3, [x3, #5112]
    adf8:	8b020842 	add	x2, x2, x2, lsl #2
    adfc:	d37df042 	lsl	x2, x2, #3
    ae00:	8b020060 	add	x0, x3, x2
    ae04:	f9401017 	ldr	x23, [x0, #32]
    ae08:	b4000257 	cbz	x23, ae50 <f0+0x1230>
    ae0c:	38626862 	ldrb	w2, [x3, x2]
    ae10:	7100085f 	cmp	w2, #0x2
    ae14:	540086c0 	b.eq	beec <f0+0x22cc>  // b.none
    ae18:	7100045f 	cmp	w2, #0x1
    ae1c:	540001a1 	b.ne	ae50 <f0+0x1230>  // b.any
    ae20:	29430002 	ldp	w2, w0, [x0, #24]
    ae24:	92403c21 	and	x1, x1, #0xffff
    ae28:	9b027c21 	mul	x1, x1, x2
    ae2c:	d360fc21 	lsr	x1, x1, #32
    ae30:	eb00003f 	cmp	x1, x0
    ae34:	540000e2 	b.cs	ae50 <f0+0x1230>  // b.hs, b.nlast
    ae38:	8b0102f7 	add	x23, x23, x1
    ae3c:	394002e0 	ldrb	w0, [x23]
    ae40:	7103fc1f 	cmp	w0, #0xff
    ae44:	54009b00 	b.eq	c1a4 <f0+0x2584>  // b.none
    ae48:	52800020 	mov	w0, #0x1                   	// #1
    ae4c:	390002e0 	strb	w0, [x23]
    ae50:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ae54:	911123e1 	add	x1, sp, #0x448
    ae58:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	f90227e2 	str	x2, [sp, #1096]
    ae64:	f9022bf5 	str	x21, [sp, #1104]
    ae68:	97ffe887 	bl	5084 <fwp_data.part.0.constprop.0>
    ae6c:	91174283 	add	x3, x20, #0x5d0
    ae70:	aa0003f5 	mov	x21, x0
    ae74:	f949d861 	ldr	x1, [x3, #5040]
    ae78:	f949ec60 	ldr	x0, [x3, #5080]
    ae7c:	cb0102a1 	sub	x1, x21, x1
    ae80:	eb00403f 	cmp	x1, x0, lsl #16
    ae84:	54000322 	b.cs	aee8 <f0+0x12c8>  // b.hs, b.nlast
    ae88:	d350fc22 	lsr	x2, x1, #16
    ae8c:	f949fc63 	ldr	x3, [x3, #5112]
    ae90:	8b020842 	add	x2, x2, x2, lsl #2
    ae94:	d37df042 	lsl	x2, x2, #3
    ae98:	8b020060 	add	x0, x3, x2
    ae9c:	f9401017 	ldr	x23, [x0, #32]
    aea0:	b4000257 	cbz	x23, aee8 <f0+0x12c8>
    aea4:	38626862 	ldrb	w2, [x3, x2]
    aea8:	7100085f 	cmp	w2, #0x2
    aeac:	540081a0 	b.eq	bee0 <f0+0x22c0>  // b.none
    aeb0:	7100045f 	cmp	w2, #0x1
    aeb4:	540001a1 	b.ne	aee8 <f0+0x12c8>  // b.any
    aeb8:	29430002 	ldp	w2, w0, [x0, #24]
    aebc:	92403c21 	and	x1, x1, #0xffff
    aec0:	9b027c21 	mul	x1, x1, x2
    aec4:	d360fc21 	lsr	x1, x1, #32
    aec8:	eb00003f 	cmp	x1, x0
    aecc:	540000e2 	b.cs	aee8 <f0+0x12c8>  // b.hs, b.nlast
    aed0:	8b0102f7 	add	x23, x23, x1
    aed4:	394002e0 	ldrb	w0, [x23]
    aed8:	7103fc1f 	cmp	w0, #0xff
    aedc:	540096a0 	b.eq	c1b0 <f0+0x2590>  // b.none
    aee0:	52800020 	mov	w0, #0x1                   	// #1
    aee4:	390002e0 	strb	w0, [x23]
    aee8:	911163e1 	add	x1, sp, #0x458
    aeec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aef0:	52800020 	mov	w0, #0x1                   	// #1
    aef4:	f9022fe2 	str	x2, [sp, #1112]
    aef8:	f90233f5 	str	x21, [sp, #1120]
    aefc:	97ffe862 	bl	5084 <fwp_data.part.0.constprop.0>
    af00:	97ffe9c5 	bl	5614 <fwp_rc_fresh>
    af04:	aa0003e2 	mov	x2, x0
    af08:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    af0c:	9111a3e1 	add	x1, sp, #0x468
    af10:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    af14:	52800020 	mov	w0, #0x1                   	// #1
    af18:	f90237e3 	str	x3, [sp, #1128]
    af1c:	f9023be2 	str	x2, [sp, #1136]
    af20:	97ffe859 	bl	5084 <fwp_data.part.0.constprop.0>
    af24:	91174283 	add	x3, x20, #0x5d0
    af28:	aa0003f5 	mov	x21, x0
    af2c:	f949d861 	ldr	x1, [x3, #5040]
    af30:	f949ec60 	ldr	x0, [x3, #5080]
    af34:	cb0102a1 	sub	x1, x21, x1
    af38:	eb00403f 	cmp	x1, x0, lsl #16
    af3c:	54000322 	b.cs	afa0 <f0+0x1380>  // b.hs, b.nlast
    af40:	d350fc22 	lsr	x2, x1, #16
    af44:	f949fc63 	ldr	x3, [x3, #5112]
    af48:	8b020842 	add	x2, x2, x2, lsl #2
    af4c:	d37df042 	lsl	x2, x2, #3
    af50:	8b020060 	add	x0, x3, x2
    af54:	f9401017 	ldr	x23, [x0, #32]
    af58:	b4000257 	cbz	x23, afa0 <f0+0x1380>
    af5c:	38626862 	ldrb	w2, [x3, x2]
    af60:	7100085f 	cmp	w2, #0x2
    af64:	54007b80 	b.eq	bed4 <f0+0x22b4>  // b.none
    af68:	7100045f 	cmp	w2, #0x1
    af6c:	540001a1 	b.ne	afa0 <f0+0x1380>  // b.any
    af70:	29430002 	ldp	w2, w0, [x0, #24]
    af74:	92403c21 	and	x1, x1, #0xffff
    af78:	9b027c21 	mul	x1, x1, x2
    af7c:	d360fc21 	lsr	x1, x1, #32
    af80:	eb00003f 	cmp	x1, x0
    af84:	540000e2 	b.cs	afa0 <f0+0x1380>  // b.hs, b.nlast
    af88:	8b0102f7 	add	x23, x23, x1
    af8c:	394002e0 	ldrb	w0, [x23]
    af90:	7103fc1f 	cmp	w0, #0xff
    af94:	54009140 	b.eq	c1bc <f0+0x259c>  // b.none
    af98:	52800020 	mov	w0, #0x1                   	// #1
    af9c:	390002e0 	strb	w0, [x23]
    afa0:	9111e3e1 	add	x1, sp, #0x478
    afa4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    afa8:	52800020 	mov	w0, #0x1                   	// #1
    afac:	f9023fe2 	str	x2, [sp, #1144]
    afb0:	f90243f5 	str	x21, [sp, #1152]
    afb4:	97ffe834 	bl	5084 <fwp_data.part.0.constprop.0>
    afb8:	97ffe997 	bl	5614 <fwp_rc_fresh>
    afbc:	aa0003e2 	mov	x2, x0
    afc0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    afc4:	911223e1 	add	x1, sp, #0x488
    afc8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f90247e3 	str	x3, [sp, #1160]
    afd4:	f9024be2 	str	x2, [sp, #1168]
    afd8:	97ffe82b 	bl	5084 <fwp_data.part.0.constprop.0>
    afdc:	91174283 	add	x3, x20, #0x5d0
    afe0:	aa0003f5 	mov	x21, x0
    afe4:	f949d861 	ldr	x1, [x3, #5040]
    afe8:	f949ec60 	ldr	x0, [x3, #5080]
    afec:	cb0102a1 	sub	x1, x21, x1
    aff0:	eb00403f 	cmp	x1, x0, lsl #16
    aff4:	54000322 	b.cs	b058 <f0+0x1438>  // b.hs, b.nlast
    aff8:	d350fc22 	lsr	x2, x1, #16
    affc:	f949fc63 	ldr	x3, [x3, #5112]
    b000:	8b020842 	add	x2, x2, x2, lsl #2
    b004:	d37df042 	lsl	x2, x2, #3
    b008:	8b020060 	add	x0, x3, x2
    b00c:	f9401017 	ldr	x23, [x0, #32]
    b010:	b4000257 	cbz	x23, b058 <f0+0x1438>
    b014:	38626862 	ldrb	w2, [x3, x2]
    b018:	7100085f 	cmp	w2, #0x2
    b01c:	54008400 	b.eq	c09c <f0+0x247c>  // b.none
    b020:	7100045f 	cmp	w2, #0x1
    b024:	540001a1 	b.ne	b058 <f0+0x1438>  // b.any
    b028:	29430002 	ldp	w2, w0, [x0, #24]
    b02c:	92403c21 	and	x1, x1, #0xffff
    b030:	9b027c21 	mul	x1, x1, x2
    b034:	d360fc21 	lsr	x1, x1, #32
    b038:	eb00003f 	cmp	x1, x0
    b03c:	540000e2 	b.cs	b058 <f0+0x1438>  // b.hs, b.nlast
    b040:	8b0102f7 	add	x23, x23, x1
    b044:	394002e0 	ldrb	w0, [x23]
    b048:	7103fc1f 	cmp	w0, #0xff
    b04c:	54008be0 	b.eq	c1c8 <f0+0x25a8>  // b.none
    b050:	52800020 	mov	w0, #0x1                   	// #1
    b054:	390002e0 	strb	w0, [x23]
    b058:	911263e1 	add	x1, sp, #0x498
    b05c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b060:	52800020 	mov	w0, #0x1                   	// #1
    b064:	f9024ff7 	str	x23, [sp, #1176]
    b068:	f90253f5 	str	x21, [sp, #1184]
    b06c:	97ffe806 	bl	5084 <fwp_data.part.0.constprop.0>
    b070:	97ffe969 	bl	5614 <fwp_rc_fresh>
    b074:	aa0003e2 	mov	x2, x0
    b078:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b07c:	9112a3e1 	add	x1, sp, #0x4a8
    b080:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b084:	52800020 	mov	w0, #0x1                   	// #1
    b088:	f90257e3 	str	x3, [sp, #1192]
    b08c:	f9025be2 	str	x2, [sp, #1200]
    b090:	97ffe7fd 	bl	5084 <fwp_data.part.0.constprop.0>
    b094:	97ffe960 	bl	5614 <fwp_rc_fresh>
    b098:	aa0003e2 	mov	x2, x0
    b09c:	9112e3e1 	add	x1, sp, #0x4b8
    b0a0:	52800020 	mov	w0, #0x1                   	// #1
    b0a4:	f9025ff7 	str	x23, [sp, #1208]
    b0a8:	f90263e2 	str	x2, [sp, #1216]
    b0ac:	97ffe7f6 	bl	5084 <fwp_data.part.0.constprop.0>
    b0b0:	91174283 	add	x3, x20, #0x5d0
    b0b4:	aa0003f5 	mov	x21, x0
    b0b8:	f949d861 	ldr	x1, [x3, #5040]
    b0bc:	f949ec60 	ldr	x0, [x3, #5080]
    b0c0:	cb0102a1 	sub	x1, x21, x1
    b0c4:	eb00403f 	cmp	x1, x0, lsl #16
    b0c8:	54000322 	b.cs	b12c <f0+0x150c>  // b.hs, b.nlast
    b0cc:	d350fc22 	lsr	x2, x1, #16
    b0d0:	f949fc63 	ldr	x3, [x3, #5112]
    b0d4:	8b020842 	add	x2, x2, x2, lsl #2
    b0d8:	d37df042 	lsl	x2, x2, #3
    b0dc:	8b020060 	add	x0, x3, x2
    b0e0:	f9401017 	ldr	x23, [x0, #32]
    b0e4:	b4000257 	cbz	x23, b12c <f0+0x150c>
    b0e8:	38626862 	ldrb	w2, [x3, x2]
    b0ec:	7100085f 	cmp	w2, #0x2
    b0f0:	54007d00 	b.eq	c090 <f0+0x2470>  // b.none
    b0f4:	7100045f 	cmp	w2, #0x1
    b0f8:	540001a1 	b.ne	b12c <f0+0x150c>  // b.any
    b0fc:	29430002 	ldp	w2, w0, [x0, #24]
    b100:	92403c21 	and	x1, x1, #0xffff
    b104:	9b027c21 	mul	x1, x1, x2
    b108:	d360fc21 	lsr	x1, x1, #32
    b10c:	eb00003f 	cmp	x1, x0
    b110:	540000e2 	b.cs	b12c <f0+0x150c>  // b.hs, b.nlast
    b114:	8b0102f7 	add	x23, x23, x1
    b118:	394002e0 	ldrb	w0, [x23]
    b11c:	7103fc1f 	cmp	w0, #0xff
    b120:	540085a0 	b.eq	c1d4 <f0+0x25b4>  // b.none
    b124:	52800020 	mov	w0, #0x1                   	// #1
    b128:	390002e0 	strb	w0, [x23]
    b12c:	911323e1 	add	x1, sp, #0x4c8
    b130:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b134:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b138:	52800020 	mov	w0, #0x1                   	// #1
    b13c:	f90267f7 	str	x23, [sp, #1224]
    b140:	f9026bf5 	str	x21, [sp, #1232]
    b144:	97ffe7d0 	bl	5084 <fwp_data.part.0.constprop.0>
    b148:	97ffe933 	bl	5614 <fwp_rc_fresh>
    b14c:	aa0003e2 	mov	x2, x0
    b150:	911363e1 	add	x1, sp, #0x4d8
    b154:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b158:	52800020 	mov	w0, #0x1                   	// #1
    b15c:	f9026ff5 	str	x21, [sp, #1240]
    b160:	f90273e2 	str	x2, [sp, #1248]
    b164:	97ffe7c8 	bl	5084 <fwp_data.part.0.constprop.0>
    b168:	97ffe92b 	bl	5614 <fwp_rc_fresh>
    b16c:	aa0003e2 	mov	x2, x0
    b170:	9113a3e1 	add	x1, sp, #0x4e8
    b174:	52800020 	mov	w0, #0x1                   	// #1
    b178:	f90277f7 	str	x23, [sp, #1256]
    b17c:	f9027be2 	str	x2, [sp, #1264]
    b180:	97ffe7c1 	bl	5084 <fwp_data.part.0.constprop.0>
    b184:	97ffe924 	bl	5614 <fwp_rc_fresh>
    b188:	aa0003e2 	mov	x2, x0
    b18c:	9113e3e1 	add	x1, sp, #0x4f8
    b190:	52800020 	mov	w0, #0x1                   	// #1
    b194:	f9027ff5 	str	x21, [sp, #1272]
    b198:	f90283e2 	str	x2, [sp, #1280]
    b19c:	97ffe7ba 	bl	5084 <fwp_data.part.0.constprop.0>
    b1a0:	97ffe91d 	bl	5614 <fwp_rc_fresh>
    b1a4:	aa0003e2 	mov	x2, x0
    b1a8:	911423e1 	add	x1, sp, #0x508
    b1ac:	52800020 	mov	w0, #0x1                   	// #1
    b1b0:	f90287f7 	str	x23, [sp, #1288]
    b1b4:	f9028be2 	str	x2, [sp, #1296]
    b1b8:	97ffe7b3 	bl	5084 <fwp_data.part.0.constprop.0>
    b1bc:	91174283 	add	x3, x20, #0x5d0
    b1c0:	aa0003f5 	mov	x21, x0
    b1c4:	f949d861 	ldr	x1, [x3, #5040]
    b1c8:	f949ec60 	ldr	x0, [x3, #5080]
    b1cc:	cb0102a1 	sub	x1, x21, x1
    b1d0:	eb00403f 	cmp	x1, x0, lsl #16
    b1d4:	54000322 	b.cs	b238 <f0+0x1618>  // b.hs, b.nlast
    b1d8:	d350fc22 	lsr	x2, x1, #16
    b1dc:	f949fc63 	ldr	x3, [x3, #5112]
    b1e0:	8b020842 	add	x2, x2, x2, lsl #2
    b1e4:	d37df042 	lsl	x2, x2, #3
    b1e8:	8b020060 	add	x0, x3, x2
    b1ec:	f9401017 	ldr	x23, [x0, #32]
    b1f0:	b4000257 	cbz	x23, b238 <f0+0x1618>
    b1f4:	38626862 	ldrb	w2, [x3, x2]
    b1f8:	7100085f 	cmp	w2, #0x2
    b1fc:	54007440 	b.eq	c084 <f0+0x2464>  // b.none
    b200:	7100045f 	cmp	w2, #0x1
    b204:	540001a1 	b.ne	b238 <f0+0x1618>  // b.any
    b208:	29430002 	ldp	w2, w0, [x0, #24]
    b20c:	92403c21 	and	x1, x1, #0xffff
    b210:	9b027c21 	mul	x1, x1, x2
    b214:	d360fc21 	lsr	x1, x1, #32
    b218:	eb00003f 	cmp	x1, x0
    b21c:	540000e2 	b.cs	b238 <f0+0x1618>  // b.hs, b.nlast
    b220:	8b0102f7 	add	x23, x23, x1
    b224:	394002e0 	ldrb	w0, [x23]
    b228:	7103fc1f 	cmp	w0, #0xff
    b22c:	54007da0 	b.eq	c1e0 <f0+0x25c0>  // b.none
    b230:	52800020 	mov	w0, #0x1                   	// #1
    b234:	390002e0 	strb	w0, [x23]
    b238:	911463e1 	add	x1, sp, #0x518
    b23c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b240:	52800020 	mov	w0, #0x1                   	// #1
    b244:	f9028fe2 	str	x2, [sp, #1304]
    b248:	f90293f5 	str	x21, [sp, #1312]
    b24c:	97ffe78e 	bl	5084 <fwp_data.part.0.constprop.0>
    b250:	97ffe8f1 	bl	5614 <fwp_rc_fresh>
    b254:	aa0003e2 	mov	x2, x0
    b258:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b25c:	9114a3e1 	add	x1, sp, #0x528
    b260:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b264:	52800020 	mov	w0, #0x1                   	// #1
    b268:	f90297e3 	str	x3, [sp, #1320]
    b26c:	f9029be2 	str	x2, [sp, #1328]
    b270:	97ffe785 	bl	5084 <fwp_data.part.0.constprop.0>
    b274:	91174283 	add	x3, x20, #0x5d0
    b278:	aa0003f5 	mov	x21, x0
    b27c:	f949d861 	ldr	x1, [x3, #5040]
    b280:	f949ec60 	ldr	x0, [x3, #5080]
    b284:	cb0102a1 	sub	x1, x21, x1
    b288:	eb00403f 	cmp	x1, x0, lsl #16
    b28c:	54000322 	b.cs	b2f0 <f0+0x16d0>  // b.hs, b.nlast
    b290:	d350fc22 	lsr	x2, x1, #16
    b294:	f949fc63 	ldr	x3, [x3, #5112]
    b298:	8b020842 	add	x2, x2, x2, lsl #2
    b29c:	d37df042 	lsl	x2, x2, #3
    b2a0:	8b020060 	add	x0, x3, x2
    b2a4:	f9401017 	ldr	x23, [x0, #32]
    b2a8:	b4000257 	cbz	x23, b2f0 <f0+0x16d0>
    b2ac:	38626862 	ldrb	w2, [x3, x2]
    b2b0:	7100085f 	cmp	w2, #0x2
    b2b4:	54006e20 	b.eq	c078 <f0+0x2458>  // b.none
    b2b8:	7100045f 	cmp	w2, #0x1
    b2bc:	540001a1 	b.ne	b2f0 <f0+0x16d0>  // b.any
    b2c0:	29430002 	ldp	w2, w0, [x0, #24]
    b2c4:	92403c21 	and	x1, x1, #0xffff
    b2c8:	9b027c21 	mul	x1, x1, x2
    b2cc:	d360fc21 	lsr	x1, x1, #32
    b2d0:	eb00003f 	cmp	x1, x0
    b2d4:	540000e2 	b.cs	b2f0 <f0+0x16d0>  // b.hs, b.nlast
    b2d8:	8b0102f7 	add	x23, x23, x1
    b2dc:	394002e0 	ldrb	w0, [x23]
    b2e0:	7103fc1f 	cmp	w0, #0xff
    b2e4:	54007840 	b.eq	c1ec <f0+0x25cc>  // b.none
    b2e8:	52800020 	mov	w0, #0x1                   	// #1
    b2ec:	390002e0 	strb	w0, [x23]
    b2f0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b2f4:	9114e3e1 	add	x1, sp, #0x538
    b2f8:	52800020 	mov	w0, #0x1                   	// #1
    b2fc:	f9029fe2 	str	x2, [sp, #1336]
    b300:	f902a3f5 	str	x21, [sp, #1344]
    b304:	97ffe760 	bl	5084 <fwp_data.part.0.constprop.0>
    b308:	91174283 	add	x3, x20, #0x5d0
    b30c:	aa0003f5 	mov	x21, x0
    b310:	f949d861 	ldr	x1, [x3, #5040]
    b314:	f949ec60 	ldr	x0, [x3, #5080]
    b318:	cb0102a1 	sub	x1, x21, x1
    b31c:	eb00403f 	cmp	x1, x0, lsl #16
    b320:	54000322 	b.cs	b384 <f0+0x1764>  // b.hs, b.nlast
    b324:	d350fc22 	lsr	x2, x1, #16
    b328:	f949fc63 	ldr	x3, [x3, #5112]
    b32c:	8b020842 	add	x2, x2, x2, lsl #2
    b330:	d37df042 	lsl	x2, x2, #3
    b334:	8b020060 	add	x0, x3, x2
    b338:	f9401017 	ldr	x23, [x0, #32]
    b33c:	b4000257 	cbz	x23, b384 <f0+0x1764>
    b340:	38626862 	ldrb	w2, [x3, x2]
    b344:	7100085f 	cmp	w2, #0x2
    b348:	54006920 	b.eq	c06c <f0+0x244c>  // b.none
    b34c:	7100045f 	cmp	w2, #0x1
    b350:	540001a1 	b.ne	b384 <f0+0x1764>  // b.any
    b354:	29430002 	ldp	w2, w0, [x0, #24]
    b358:	92403c21 	and	x1, x1, #0xffff
    b35c:	9b027c21 	mul	x1, x1, x2
    b360:	d360fc21 	lsr	x1, x1, #32
    b364:	eb00003f 	cmp	x1, x0
    b368:	540000e2 	b.cs	b384 <f0+0x1764>  // b.hs, b.nlast
    b36c:	8b0102f7 	add	x23, x23, x1
    b370:	394002e0 	ldrb	w0, [x23]
    b374:	7103fc1f 	cmp	w0, #0xff
    b378:	54007400 	b.eq	c1f8 <f0+0x25d8>  // b.none
    b37c:	52800020 	mov	w0, #0x1                   	// #1
    b380:	390002e0 	strb	w0, [x23]
    b384:	911523e1 	add	x1, sp, #0x548
    b388:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b38c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b390:	52800020 	mov	w0, #0x1                   	// #1
    b394:	f902a7f7 	str	x23, [sp, #1352]
    b398:	f902abf5 	str	x21, [sp, #1360]
    b39c:	97ffe73a 	bl	5084 <fwp_data.part.0.constprop.0>
    b3a0:	97ffe89d 	bl	5614 <fwp_rc_fresh>
    b3a4:	aa0003e2 	mov	x2, x0
    b3a8:	911563e1 	add	x1, sp, #0x558
    b3ac:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b3b0:	52800020 	mov	w0, #0x1                   	// #1
    b3b4:	f902aff5 	str	x21, [sp, #1368]
    b3b8:	f902b3e2 	str	x2, [sp, #1376]
    b3bc:	97ffe732 	bl	5084 <fwp_data.part.0.constprop.0>
    b3c0:	97ffe895 	bl	5614 <fwp_rc_fresh>
    b3c4:	aa0003e2 	mov	x2, x0
    b3c8:	9115a3e1 	add	x1, sp, #0x568
    b3cc:	52800020 	mov	w0, #0x1                   	// #1
    b3d0:	f902b7f7 	str	x23, [sp, #1384]
    b3d4:	f902bbe2 	str	x2, [sp, #1392]
    b3d8:	97ffe72b 	bl	5084 <fwp_data.part.0.constprop.0>
    b3dc:	97ffe88e 	bl	5614 <fwp_rc_fresh>
    b3e0:	aa0003e2 	mov	x2, x0
    b3e4:	9115e3e1 	add	x1, sp, #0x578
    b3e8:	52800020 	mov	w0, #0x1                   	// #1
    b3ec:	f902bff5 	str	x21, [sp, #1400]
    b3f0:	f902c3e2 	str	x2, [sp, #1408]
    b3f4:	97ffe724 	bl	5084 <fwp_data.part.0.constprop.0>
    b3f8:	97ffe887 	bl	5614 <fwp_rc_fresh>
    b3fc:	aa0003e2 	mov	x2, x0
    b400:	911623e1 	add	x1, sp, #0x588
    b404:	52800020 	mov	w0, #0x1                   	// #1
    b408:	f902c7f7 	str	x23, [sp, #1416]
    b40c:	f902cbe2 	str	x2, [sp, #1424]
    b410:	97ffe71d 	bl	5084 <fwp_data.part.0.constprop.0>
    b414:	91174283 	add	x3, x20, #0x5d0
    b418:	aa0003f5 	mov	x21, x0
    b41c:	f949d861 	ldr	x1, [x3, #5040]
    b420:	f949ec60 	ldr	x0, [x3, #5080]
    b424:	cb0102a1 	sub	x1, x21, x1
    b428:	eb00403f 	cmp	x1, x0, lsl #16
    b42c:	54000322 	b.cs	b490 <f0+0x1870>  // b.hs, b.nlast
    b430:	d350fc22 	lsr	x2, x1, #16
    b434:	f949fc63 	ldr	x3, [x3, #5112]
    b438:	8b020842 	add	x2, x2, x2, lsl #2
    b43c:	d37df042 	lsl	x2, x2, #3
    b440:	8b020060 	add	x0, x3, x2
    b444:	f9401017 	ldr	x23, [x0, #32]
    b448:	b4000257 	cbz	x23, b490 <f0+0x1870>
    b44c:	38626862 	ldrb	w2, [x3, x2]
    b450:	7100085f 	cmp	w2, #0x2
    b454:	54006060 	b.eq	c060 <f0+0x2440>  // b.none
    b458:	7100045f 	cmp	w2, #0x1
    b45c:	540001a1 	b.ne	b490 <f0+0x1870>  // b.any
    b460:	29430002 	ldp	w2, w0, [x0, #24]
    b464:	92403c21 	and	x1, x1, #0xffff
    b468:	9b027c21 	mul	x1, x1, x2
    b46c:	d360fc21 	lsr	x1, x1, #32
    b470:	eb00003f 	cmp	x1, x0
    b474:	540000e2 	b.cs	b490 <f0+0x1870>  // b.hs, b.nlast
    b478:	8b0102f7 	add	x23, x23, x1
    b47c:	394002e0 	ldrb	w0, [x23]
    b480:	7103fc1f 	cmp	w0, #0xff
    b484:	54006c00 	b.eq	c204 <f0+0x25e4>  // b.none
    b488:	52800020 	mov	w0, #0x1                   	// #1
    b48c:	390002e0 	strb	w0, [x23]
    b490:	911663e1 	add	x1, sp, #0x598
    b494:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b498:	52800020 	mov	w0, #0x1                   	// #1
    b49c:	f902cff7 	str	x23, [sp, #1432]
    b4a0:	f902d3f5 	str	x21, [sp, #1440]
    b4a4:	97ffe6f8 	bl	5084 <fwp_data.part.0.constprop.0>
    b4a8:	97ffe85b 	bl	5614 <fwp_rc_fresh>
    b4ac:	aa0003e2 	mov	x2, x0
    b4b0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b4b4:	9116a3e1 	add	x1, sp, #0x5a8
    b4b8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b4bc:	52800020 	mov	w0, #0x1                   	// #1
    b4c0:	f902d7e3 	str	x3, [sp, #1448]
    b4c4:	f902dbe2 	str	x2, [sp, #1456]
    b4c8:	97ffe6ef 	bl	5084 <fwp_data.part.0.constprop.0>
    b4cc:	97ffe852 	bl	5614 <fwp_rc_fresh>
    b4d0:	aa0003e2 	mov	x2, x0
    b4d4:	9116e3e1 	add	x1, sp, #0x5b8
    b4d8:	52800020 	mov	w0, #0x1                   	// #1
    b4dc:	f902dff7 	str	x23, [sp, #1464]
    b4e0:	f902e3e2 	str	x2, [sp, #1472]
    b4e4:	97ffe6e8 	bl	5084 <fwp_data.part.0.constprop.0>
    b4e8:	91174283 	add	x3, x20, #0x5d0
    b4ec:	aa0003f5 	mov	x21, x0
    b4f0:	f949d861 	ldr	x1, [x3, #5040]
    b4f4:	f949ec60 	ldr	x0, [x3, #5080]
    b4f8:	cb0102a1 	sub	x1, x21, x1
    b4fc:	eb00403f 	cmp	x1, x0, lsl #16
    b500:	54000322 	b.cs	b564 <f0+0x1944>  // b.hs, b.nlast
    b504:	d350fc22 	lsr	x2, x1, #16
    b508:	f949fc63 	ldr	x3, [x3, #5112]
    b50c:	8b020842 	add	x2, x2, x2, lsl #2
    b510:	d37df042 	lsl	x2, x2, #3
    b514:	8b020060 	add	x0, x3, x2
    b518:	f9401017 	ldr	x23, [x0, #32]
    b51c:	b4000257 	cbz	x23, b564 <f0+0x1944>
    b520:	38626862 	ldrb	w2, [x3, x2]
    b524:	7100085f 	cmp	w2, #0x2
    b528:	54005960 	b.eq	c054 <f0+0x2434>  // b.none
    b52c:	7100045f 	cmp	w2, #0x1
    b530:	540001a1 	b.ne	b564 <f0+0x1944>  // b.any
    b534:	29430002 	ldp	w2, w0, [x0, #24]
    b538:	92403c21 	and	x1, x1, #0xffff
    b53c:	9b027c21 	mul	x1, x1, x2
    b540:	d360fc21 	lsr	x1, x1, #32
    b544:	eb00003f 	cmp	x1, x0
    b548:	540000e2 	b.cs	b564 <f0+0x1944>  // b.hs, b.nlast
    b54c:	8b0102f7 	add	x23, x23, x1
    b550:	394002e0 	ldrb	w0, [x23]
    b554:	7103fc1f 	cmp	w0, #0xff
    b558:	540065c0 	b.eq	c210 <f0+0x25f0>  // b.none
    b55c:	52800020 	mov	w0, #0x1                   	// #1
    b560:	390002e0 	strb	w0, [x23]
    b564:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b568:	911723e1 	add	x1, sp, #0x5c8
    b56c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b570:	52800020 	mov	w0, #0x1                   	// #1
    b574:	f902e7e2 	str	x2, [sp, #1480]
    b578:	f902ebf5 	str	x21, [sp, #1488]
    b57c:	97ffe6c2 	bl	5084 <fwp_data.part.0.constprop.0>
    b580:	91174283 	add	x3, x20, #0x5d0
    b584:	aa0003f7 	mov	x23, x0
    b588:	f949d861 	ldr	x1, [x3, #5040]
    b58c:	f949ec60 	ldr	x0, [x3, #5080]
    b590:	cb0102e1 	sub	x1, x23, x1
    b594:	eb00403f 	cmp	x1, x0, lsl #16
    b598:	54000322 	b.cs	b5fc <f0+0x19dc>  // b.hs, b.nlast
    b59c:	d350fc22 	lsr	x2, x1, #16
    b5a0:	f949fc63 	ldr	x3, [x3, #5112]
    b5a4:	8b020842 	add	x2, x2, x2, lsl #2
    b5a8:	d37df042 	lsl	x2, x2, #3
    b5ac:	8b020060 	add	x0, x3, x2
    b5b0:	f9401015 	ldr	x21, [x0, #32]
    b5b4:	b4000255 	cbz	x21, b5fc <f0+0x19dc>
    b5b8:	38626862 	ldrb	w2, [x3, x2]
    b5bc:	7100085f 	cmp	w2, #0x2
    b5c0:	54005440 	b.eq	c048 <f0+0x2428>  // b.none
    b5c4:	7100045f 	cmp	w2, #0x1
    b5c8:	540001a1 	b.ne	b5fc <f0+0x19dc>  // b.any
    b5cc:	29430002 	ldp	w2, w0, [x0, #24]
    b5d0:	92403c21 	and	x1, x1, #0xffff
    b5d4:	9b027c21 	mul	x1, x1, x2
    b5d8:	d360fc21 	lsr	x1, x1, #32
    b5dc:	eb00003f 	cmp	x1, x0
    b5e0:	540000e2 	b.cs	b5fc <f0+0x19dc>  // b.hs, b.nlast
    b5e4:	8b0102b5 	add	x21, x21, x1
    b5e8:	394002a0 	ldrb	w0, [x21]
    b5ec:	7103fc1f 	cmp	w0, #0xff
    b5f0:	54006160 	b.eq	c21c <f0+0x25fc>  // b.none
    b5f4:	52800020 	mov	w0, #0x1                   	// #1
    b5f8:	390002a0 	strb	w0, [x21]
    b5fc:	911763e1 	add	x1, sp, #0x5d8
    b600:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b604:	52800020 	mov	w0, #0x1                   	// #1
    b608:	f902eff5 	str	x21, [sp, #1496]
    b60c:	f902f3f7 	str	x23, [sp, #1504]
    b610:	97ffe69d 	bl	5084 <fwp_data.part.0.constprop.0>
    b614:	97ffe800 	bl	5614 <fwp_rc_fresh>
    b618:	aa0003e2 	mov	x2, x0
    b61c:	9117a3e1 	add	x1, sp, #0x5e8
    b620:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b624:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b628:	52800020 	mov	w0, #0x1                   	// #1
    b62c:	f902f7f7 	str	x23, [sp, #1512]
    b630:	f902fbe2 	str	x2, [sp, #1520]
    b634:	97ffe694 	bl	5084 <fwp_data.part.0.constprop.0>
    b638:	97ffe7f7 	bl	5614 <fwp_rc_fresh>
    b63c:	aa0003e2 	mov	x2, x0
    b640:	9117e3e1 	add	x1, sp, #0x5f8
    b644:	52800020 	mov	w0, #0x1                   	// #1
    b648:	f902fff5 	str	x21, [sp, #1528]
    b64c:	f90303e2 	str	x2, [sp, #1536]
    b650:	97ffe68d 	bl	5084 <fwp_data.part.0.constprop.0>
    b654:	97ffe7f0 	bl	5614 <fwp_rc_fresh>
    b658:	aa0003e2 	mov	x2, x0
    b65c:	911823e1 	add	x1, sp, #0x608
    b660:	52800020 	mov	w0, #0x1                   	// #1
    b664:	f90307f7 	str	x23, [sp, #1544]
    b668:	f9030be2 	str	x2, [sp, #1552]
    b66c:	97ffe686 	bl	5084 <fwp_data.part.0.constprop.0>
    b670:	97ffe7e9 	bl	5614 <fwp_rc_fresh>
    b674:	aa0003e2 	mov	x2, x0
    b678:	911863e1 	add	x1, sp, #0x618
    b67c:	52800020 	mov	w0, #0x1                   	// #1
    b680:	f9030ff5 	str	x21, [sp, #1560]
    b684:	f90313e2 	str	x2, [sp, #1568]
    b688:	97ffe67f 	bl	5084 <fwp_data.part.0.constprop.0>
    b68c:	97ffe7e2 	bl	5614 <fwp_rc_fresh>
    b690:	aa0003e2 	mov	x2, x0
    b694:	9118a3e1 	add	x1, sp, #0x628
    b698:	52800020 	mov	w0, #0x1                   	// #1
    b69c:	f90317f7 	str	x23, [sp, #1576]
    b6a0:	f9031be2 	str	x2, [sp, #1584]
    b6a4:	97ffe678 	bl	5084 <fwp_data.part.0.constprop.0>
    b6a8:	97ffe7db 	bl	5614 <fwp_rc_fresh>
    b6ac:	aa0003e2 	mov	x2, x0
    b6b0:	9118e3e1 	add	x1, sp, #0x638
    b6b4:	52800020 	mov	w0, #0x1                   	// #1
    b6b8:	f9031ff5 	str	x21, [sp, #1592]
    b6bc:	f90323e2 	str	x2, [sp, #1600]
    b6c0:	97ffe671 	bl	5084 <fwp_data.part.0.constprop.0>
    b6c4:	91174283 	add	x3, x20, #0x5d0
    b6c8:	aa0003f5 	mov	x21, x0
    b6cc:	f949d861 	ldr	x1, [x3, #5040]
    b6d0:	f949ec60 	ldr	x0, [x3, #5080]
    b6d4:	cb0102a1 	sub	x1, x21, x1
    b6d8:	eb00403f 	cmp	x1, x0, lsl #16
    b6dc:	54000322 	b.cs	b740 <f0+0x1b20>  // b.hs, b.nlast
    b6e0:	d350fc22 	lsr	x2, x1, #16
    b6e4:	f949fc63 	ldr	x3, [x3, #5112]
    b6e8:	8b020842 	add	x2, x2, x2, lsl #2
    b6ec:	d37df042 	lsl	x2, x2, #3
    b6f0:	8b020060 	add	x0, x3, x2
    b6f4:	f9401017 	ldr	x23, [x0, #32]
    b6f8:	b4000257 	cbz	x23, b740 <f0+0x1b20>
    b6fc:	38626862 	ldrb	w2, [x3, x2]
    b700:	7100085f 	cmp	w2, #0x2
    b704:	540049c0 	b.eq	c03c <f0+0x241c>  // b.none
    b708:	7100045f 	cmp	w2, #0x1
    b70c:	540001a1 	b.ne	b740 <f0+0x1b20>  // b.any
    b710:	29430002 	ldp	w2, w0, [x0, #24]
    b714:	92403c21 	and	x1, x1, #0xffff
    b718:	9b027c21 	mul	x1, x1, x2
    b71c:	d360fc21 	lsr	x1, x1, #32
    b720:	eb00003f 	cmp	x1, x0
    b724:	540000e2 	b.cs	b740 <f0+0x1b20>  // b.hs, b.nlast
    b728:	8b0102f7 	add	x23, x23, x1
    b72c:	394002e0 	ldrb	w0, [x23]
    b730:	7103fc1f 	cmp	w0, #0xff
    b734:	540057a0 	b.eq	c228 <f0+0x2608>  // b.none
    b738:	52800020 	mov	w0, #0x1                   	// #1
    b73c:	390002e0 	strb	w0, [x23]
    b740:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b744:	911923e1 	add	x1, sp, #0x648
    b748:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b74c:	52800020 	mov	w0, #0x1                   	// #1
    b750:	f90327e2 	str	x2, [sp, #1608]
    b754:	f9032bf5 	str	x21, [sp, #1616]
    b758:	97ffe64b 	bl	5084 <fwp_data.part.0.constprop.0>
    b75c:	91174283 	add	x3, x20, #0x5d0
    b760:	aa0003f5 	mov	x21, x0
    b764:	f949d861 	ldr	x1, [x3, #5040]
    b768:	f949ec60 	ldr	x0, [x3, #5080]
    b76c:	cb0102a1 	sub	x1, x21, x1
    b770:	eb00403f 	cmp	x1, x0, lsl #16
    b774:	54000322 	b.cs	b7d8 <f0+0x1bb8>  // b.hs, b.nlast
    b778:	d350fc22 	lsr	x2, x1, #16
    b77c:	f949fc63 	ldr	x3, [x3, #5112]
    b780:	8b020842 	add	x2, x2, x2, lsl #2
    b784:	d37df042 	lsl	x2, x2, #3
    b788:	8b020060 	add	x0, x3, x2
    b78c:	f9401017 	ldr	x23, [x0, #32]
    b790:	b4000257 	cbz	x23, b7d8 <f0+0x1bb8>
    b794:	38626862 	ldrb	w2, [x3, x2]
    b798:	7100085f 	cmp	w2, #0x2
    b79c:	540044a0 	b.eq	c030 <f0+0x2410>  // b.none
    b7a0:	7100045f 	cmp	w2, #0x1
    b7a4:	540001a1 	b.ne	b7d8 <f0+0x1bb8>  // b.any
    b7a8:	29430002 	ldp	w2, w0, [x0, #24]
    b7ac:	92403c21 	and	x1, x1, #0xffff
    b7b0:	9b027c21 	mul	x1, x1, x2
    b7b4:	d360fc21 	lsr	x1, x1, #32
    b7b8:	eb00003f 	cmp	x1, x0
    b7bc:	540000e2 	b.cs	b7d8 <f0+0x1bb8>  // b.hs, b.nlast
    b7c0:	8b0102f7 	add	x23, x23, x1
    b7c4:	394002e0 	ldrb	w0, [x23]
    b7c8:	7103fc1f 	cmp	w0, #0xff
    b7cc:	54005340 	b.eq	c234 <f0+0x2614>  // b.none
    b7d0:	52800020 	mov	w0, #0x1                   	// #1
    b7d4:	390002e0 	strb	w0, [x23]
    b7d8:	911963e1 	add	x1, sp, #0x658
    b7dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b7e0:	52800020 	mov	w0, #0x1                   	// #1
    b7e4:	f9032fe2 	str	x2, [sp, #1624]
    b7e8:	f90333f5 	str	x21, [sp, #1632]
    b7ec:	97ffe626 	bl	5084 <fwp_data.part.0.constprop.0>
    b7f0:	97ffe789 	bl	5614 <fwp_rc_fresh>
    b7f4:	aa0003e2 	mov	x2, x0
    b7f8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b7fc:	9119a3e1 	add	x1, sp, #0x668
    b800:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b804:	52800020 	mov	w0, #0x1                   	// #1
    b808:	f90337e3 	str	x3, [sp, #1640]
    b80c:	f9033be2 	str	x2, [sp, #1648]
    b810:	97ffe61d 	bl	5084 <fwp_data.part.0.constprop.0>
    b814:	91174283 	add	x3, x20, #0x5d0
    b818:	aa0003f5 	mov	x21, x0
    b81c:	f949d861 	ldr	x1, [x3, #5040]
    b820:	f949ec60 	ldr	x0, [x3, #5080]
    b824:	cb0102a1 	sub	x1, x21, x1
    b828:	eb00403f 	cmp	x1, x0, lsl #16
    b82c:	54000322 	b.cs	b890 <f0+0x1c70>  // b.hs, b.nlast
    b830:	d350fc22 	lsr	x2, x1, #16
    b834:	f949fc63 	ldr	x3, [x3, #5112]
    b838:	8b020842 	add	x2, x2, x2, lsl #2
    b83c:	d37df042 	lsl	x2, x2, #3
    b840:	8b020060 	add	x0, x3, x2
    b844:	f9401017 	ldr	x23, [x0, #32]
    b848:	b4000257 	cbz	x23, b890 <f0+0x1c70>
    b84c:	38626862 	ldrb	w2, [x3, x2]
    b850:	7100085f 	cmp	w2, #0x2
    b854:	54003e80 	b.eq	c024 <f0+0x2404>  // b.none
    b858:	7100045f 	cmp	w2, #0x1
    b85c:	540001a1 	b.ne	b890 <f0+0x1c70>  // b.any
    b860:	29430002 	ldp	w2, w0, [x0, #24]
    b864:	92403c21 	and	x1, x1, #0xffff
    b868:	9b027c21 	mul	x1, x1, x2
    b86c:	d360fc21 	lsr	x1, x1, #32
    b870:	eb00003f 	cmp	x1, x0
    b874:	540000e2 	b.cs	b890 <f0+0x1c70>  // b.hs, b.nlast
    b878:	8b0102f7 	add	x23, x23, x1
    b87c:	394002e0 	ldrb	w0, [x23]
    b880:	7103fc1f 	cmp	w0, #0xff
    b884:	54004de0 	b.eq	c240 <f0+0x2620>  // b.none
    b888:	52800020 	mov	w0, #0x1                   	// #1
    b88c:	390002e0 	strb	w0, [x23]
    b890:	9119e3e1 	add	x1, sp, #0x678
    b894:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b898:	52800020 	mov	w0, #0x1                   	// #1
    b89c:	f9033fe2 	str	x2, [sp, #1656]
    b8a0:	f90343f5 	str	x21, [sp, #1664]
    b8a4:	97ffe5f8 	bl	5084 <fwp_data.part.0.constprop.0>
    b8a8:	97ffe75b 	bl	5614 <fwp_rc_fresh>
    b8ac:	aa0003e2 	mov	x2, x0
    b8b0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b8b4:	911a23e1 	add	x1, sp, #0x688
    b8b8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b8bc:	52800020 	mov	w0, #0x1                   	// #1
    b8c0:	f90347e3 	str	x3, [sp, #1672]
    b8c4:	f9034be2 	str	x2, [sp, #1680]
    b8c8:	97ffe5ef 	bl	5084 <fwp_data.part.0.constprop.0>
    b8cc:	91174283 	add	x3, x20, #0x5d0
    b8d0:	aa0003f5 	mov	x21, x0
    b8d4:	f949d861 	ldr	x1, [x3, #5040]
    b8d8:	f949ec60 	ldr	x0, [x3, #5080]
    b8dc:	cb0102a1 	sub	x1, x21, x1
    b8e0:	eb00403f 	cmp	x1, x0, lsl #16
    b8e4:	54000322 	b.cs	b948 <f0+0x1d28>  // b.hs, b.nlast
    b8e8:	d350fc22 	lsr	x2, x1, #16
    b8ec:	f949fc63 	ldr	x3, [x3, #5112]
    b8f0:	8b020842 	add	x2, x2, x2, lsl #2
    b8f4:	d37df042 	lsl	x2, x2, #3
    b8f8:	8b020060 	add	x0, x3, x2
    b8fc:	f9401017 	ldr	x23, [x0, #32]
    b900:	b4000257 	cbz	x23, b948 <f0+0x1d28>
    b904:	38626862 	ldrb	w2, [x3, x2]
    b908:	7100085f 	cmp	w2, #0x2
    b90c:	54003860 	b.eq	c018 <f0+0x23f8>  // b.none
    b910:	7100045f 	cmp	w2, #0x1
    b914:	540001a1 	b.ne	b948 <f0+0x1d28>  // b.any
    b918:	29430002 	ldp	w2, w0, [x0, #24]
    b91c:	92403c21 	and	x1, x1, #0xffff
    b920:	9b027c21 	mul	x1, x1, x2
    b924:	d360fc21 	lsr	x1, x1, #32
    b928:	eb00003f 	cmp	x1, x0
    b92c:	540000e2 	b.cs	b948 <f0+0x1d28>  // b.hs, b.nlast
    b930:	8b0102f7 	add	x23, x23, x1
    b934:	394002e0 	ldrb	w0, [x23]
    b938:	7103fc1f 	cmp	w0, #0xff
    b93c:	54004880 	b.eq	c24c <f0+0x262c>  // b.none
    b940:	52800020 	mov	w0, #0x1                   	// #1
    b944:	390002e0 	strb	w0, [x23]
    b948:	911a63e1 	add	x1, sp, #0x698
    b94c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b950:	52800020 	mov	w0, #0x1                   	// #1
    b954:	f9034ff7 	str	x23, [sp, #1688]
    b958:	f90353f5 	str	x21, [sp, #1696]
    b95c:	97ffe5ca 	bl	5084 <fwp_data.part.0.constprop.0>
    b960:	97ffe72d 	bl	5614 <fwp_rc_fresh>
    b964:	aa0003e2 	mov	x2, x0
    b968:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b96c:	911aa3e1 	add	x1, sp, #0x6a8
    b970:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b974:	52800020 	mov	w0, #0x1                   	// #1
    b978:	f90357e3 	str	x3, [sp, #1704]
    b97c:	f9035be2 	str	x2, [sp, #1712]
    b980:	97ffe5c1 	bl	5084 <fwp_data.part.0.constprop.0>
    b984:	97ffe724 	bl	5614 <fwp_rc_fresh>
    b988:	aa0003e2 	mov	x2, x0
    b98c:	911ae3e1 	add	x1, sp, #0x6b8
    b990:	52800020 	mov	w0, #0x1                   	// #1
    b994:	f9035ff7 	str	x23, [sp, #1720]
    b998:	f90363e2 	str	x2, [sp, #1728]
    b99c:	97ffe5ba 	bl	5084 <fwp_data.part.0.constprop.0>
    b9a0:	91174283 	add	x3, x20, #0x5d0
    b9a4:	aa0003f5 	mov	x21, x0
    b9a8:	f949d861 	ldr	x1, [x3, #5040]
    b9ac:	f949ec60 	ldr	x0, [x3, #5080]
    b9b0:	cb0102a1 	sub	x1, x21, x1
    b9b4:	eb00403f 	cmp	x1, x0, lsl #16
    b9b8:	54000322 	b.cs	ba1c <f0+0x1dfc>  // b.hs, b.nlast
    b9bc:	d350fc22 	lsr	x2, x1, #16
    b9c0:	f949fc63 	ldr	x3, [x3, #5112]
    b9c4:	8b020842 	add	x2, x2, x2, lsl #2
    b9c8:	d37df042 	lsl	x2, x2, #3
    b9cc:	8b020060 	add	x0, x3, x2
    b9d0:	f9401017 	ldr	x23, [x0, #32]
    b9d4:	b4000257 	cbz	x23, ba1c <f0+0x1dfc>
    b9d8:	38626862 	ldrb	w2, [x3, x2]
    b9dc:	7100085f 	cmp	w2, #0x2
    b9e0:	54003160 	b.eq	c00c <f0+0x23ec>  // b.none
    b9e4:	7100045f 	cmp	w2, #0x1
    b9e8:	540001a1 	b.ne	ba1c <f0+0x1dfc>  // b.any
    b9ec:	29430002 	ldp	w2, w0, [x0, #24]
    b9f0:	92403c21 	and	x1, x1, #0xffff
    b9f4:	9b027c21 	mul	x1, x1, x2
    b9f8:	d360fc21 	lsr	x1, x1, #32
    b9fc:	eb00003f 	cmp	x1, x0
    ba00:	540000e2 	b.cs	ba1c <f0+0x1dfc>  // b.hs, b.nlast
    ba04:	8b0102f7 	add	x23, x23, x1
    ba08:	394002e0 	ldrb	w0, [x23]
    ba0c:	7103fc1f 	cmp	w0, #0xff
    ba10:	54004240 	b.eq	c258 <f0+0x2638>  // b.none
    ba14:	52800020 	mov	w0, #0x1                   	// #1
    ba18:	390002e0 	strb	w0, [x23]
    ba1c:	911b23e1 	add	x1, sp, #0x6c8
    ba20:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ba24:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ba28:	52800020 	mov	w0, #0x1                   	// #1
    ba2c:	f90367f7 	str	x23, [sp, #1736]
    ba30:	f9036bf5 	str	x21, [sp, #1744]
    ba34:	97ffe594 	bl	5084 <fwp_data.part.0.constprop.0>
    ba38:	97ffe6f7 	bl	5614 <fwp_rc_fresh>
    ba3c:	aa0003e2 	mov	x2, x0
    ba40:	911b63e1 	add	x1, sp, #0x6d8
    ba44:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ba48:	52800020 	mov	w0, #0x1                   	// #1
    ba4c:	f9036ff5 	str	x21, [sp, #1752]
    ba50:	f90373e2 	str	x2, [sp, #1760]
    ba54:	97ffe58c 	bl	5084 <fwp_data.part.0.constprop.0>
    ba58:	97ffe6ef 	bl	5614 <fwp_rc_fresh>
    ba5c:	aa0003e2 	mov	x2, x0
    ba60:	911ba3e1 	add	x1, sp, #0x6e8
    ba64:	52800020 	mov	w0, #0x1                   	// #1
    ba68:	f90377f7 	str	x23, [sp, #1768]
    ba6c:	f9037be2 	str	x2, [sp, #1776]
    ba70:	97ffe585 	bl	5084 <fwp_data.part.0.constprop.0>
    ba74:	97ffe6e8 	bl	5614 <fwp_rc_fresh>
    ba78:	aa0003e2 	mov	x2, x0
    ba7c:	911be3e1 	add	x1, sp, #0x6f8
    ba80:	52800020 	mov	w0, #0x1                   	// #1
    ba84:	f9037ff5 	str	x21, [sp, #1784]
    ba88:	f90383e2 	str	x2, [sp, #1792]
    ba8c:	97ffe57e 	bl	5084 <fwp_data.part.0.constprop.0>
    ba90:	97ffe6e1 	bl	5614 <fwp_rc_fresh>
    ba94:	aa0003e2 	mov	x2, x0
    ba98:	911c23e1 	add	x1, sp, #0x708
    ba9c:	52800020 	mov	w0, #0x1                   	// #1
    baa0:	f90387f7 	str	x23, [sp, #1800]
    baa4:	f9038be2 	str	x2, [sp, #1808]
    baa8:	97ffe577 	bl	5084 <fwp_data.part.0.constprop.0>
    baac:	97ffe6da 	bl	5614 <fwp_rc_fresh>
    bab0:	aa0003e2 	mov	x2, x0
    bab4:	911c63e1 	add	x1, sp, #0x718
    bab8:	52800020 	mov	w0, #0x1                   	// #1
    babc:	f9038ff5 	str	x21, [sp, #1816]
    bac0:	f90393e2 	str	x2, [sp, #1824]
    bac4:	97ffe570 	bl	5084 <fwp_data.part.0.constprop.0>
    bac8:	97ffe6d3 	bl	5614 <fwp_rc_fresh>
    bacc:	aa0003e2 	mov	x2, x0
    bad0:	911ca3e1 	add	x1, sp, #0x728
    bad4:	52800020 	mov	w0, #0x1                   	// #1
    bad8:	f90397f7 	str	x23, [sp, #1832]
    badc:	f9039be2 	str	x2, [sp, #1840]
    bae0:	97ffe569 	bl	5084 <fwp_data.part.0.constprop.0>
    bae4:	97ffe6cc 	bl	5614 <fwp_rc_fresh>
    bae8:	aa0003e2 	mov	x2, x0
    baec:	911ce3e1 	add	x1, sp, #0x738
    baf0:	52800020 	mov	w0, #0x1                   	// #1
    baf4:	f9039ff5 	str	x21, [sp, #1848]
    baf8:	f903a3e2 	str	x2, [sp, #1856]
    bafc:	97ffe562 	bl	5084 <fwp_data.part.0.constprop.0>
    bb00:	97ffe6c5 	bl	5614 <fwp_rc_fresh>
    bb04:	aa0003e2 	mov	x2, x0
    bb08:	911d23e1 	add	x1, sp, #0x748
    bb0c:	52800020 	mov	w0, #0x1                   	// #1
    bb10:	f903a7f7 	str	x23, [sp, #1864]
    bb14:	f903abe2 	str	x2, [sp, #1872]
    bb18:	97ffe55b 	bl	5084 <fwp_data.part.0.constprop.0>
    bb1c:	97ffe6be 	bl	5614 <fwp_rc_fresh>
    bb20:	aa0003e2 	mov	x2, x0
    bb24:	911d63e1 	add	x1, sp, #0x758
    bb28:	52800020 	mov	w0, #0x1                   	// #1
    bb2c:	f903aff5 	str	x21, [sp, #1880]
    bb30:	f903b3e2 	str	x2, [sp, #1888]
    bb34:	97ffe554 	bl	5084 <fwp_data.part.0.constprop.0>
    bb38:	97ffe6b7 	bl	5614 <fwp_rc_fresh>
    bb3c:	aa0003e2 	mov	x2, x0
    bb40:	911da3e1 	add	x1, sp, #0x768
    bb44:	52800020 	mov	w0, #0x1                   	// #1
    bb48:	f903b7f7 	str	x23, [sp, #1896]
    bb4c:	f903bbe2 	str	x2, [sp, #1904]
    bb50:	97ffe54d 	bl	5084 <fwp_data.part.0.constprop.0>
    bb54:	97ffe6b0 	bl	5614 <fwp_rc_fresh>
    bb58:	aa0003e2 	mov	x2, x0
    bb5c:	911de3e1 	add	x1, sp, #0x778
    bb60:	52800020 	mov	w0, #0x1                   	// #1
    bb64:	f903bff5 	str	x21, [sp, #1912]
    bb68:	f903c3e2 	str	x2, [sp, #1920]
    bb6c:	97ffe546 	bl	5084 <fwp_data.part.0.constprop.0>
    bb70:	97ffe6a9 	bl	5614 <fwp_rc_fresh>
    bb74:	aa0003e2 	mov	x2, x0
    bb78:	911e23e1 	add	x1, sp, #0x788
    bb7c:	52800020 	mov	w0, #0x1                   	// #1
    bb80:	f903c7f7 	str	x23, [sp, #1928]
    bb84:	f903cbe2 	str	x2, [sp, #1936]
    bb88:	97ffe53f 	bl	5084 <fwp_data.part.0.constprop.0>
    bb8c:	97ffe6a2 	bl	5614 <fwp_rc_fresh>
    bb90:	aa0003e2 	mov	x2, x0
    bb94:	911e63e1 	add	x1, sp, #0x798
    bb98:	52800020 	mov	w0, #0x1                   	// #1
    bb9c:	f903cff5 	str	x21, [sp, #1944]
    bba0:	f903d3e2 	str	x2, [sp, #1952]
    bba4:	97ffe538 	bl	5084 <fwp_data.part.0.constprop.0>
    bba8:	91174283 	add	x3, x20, #0x5d0
    bbac:	aa0003f7 	mov	x23, x0
    bbb0:	f949d861 	ldr	x1, [x3, #5040]
    bbb4:	f949ec60 	ldr	x0, [x3, #5080]
    bbb8:	cb0102e1 	sub	x1, x23, x1
    bbbc:	eb00403f 	cmp	x1, x0, lsl #16
    bbc0:	54000322 	b.cs	bc24 <f0+0x2004>  // b.hs, b.nlast
    bbc4:	d350fc22 	lsr	x2, x1, #16
    bbc8:	f949fc63 	ldr	x3, [x3, #5112]
    bbcc:	8b020842 	add	x2, x2, x2, lsl #2
    bbd0:	d37df042 	lsl	x2, x2, #3
    bbd4:	8b020060 	add	x0, x3, x2
    bbd8:	f9401015 	ldr	x21, [x0, #32]
    bbdc:	b4000255 	cbz	x21, bc24 <f0+0x2004>
    bbe0:	38626862 	ldrb	w2, [x3, x2]
    bbe4:	7100085f 	cmp	w2, #0x2
    bbe8:	540020c0 	b.eq	c000 <f0+0x23e0>  // b.none
    bbec:	7100045f 	cmp	w2, #0x1
    bbf0:	540001a1 	b.ne	bc24 <f0+0x2004>  // b.any
    bbf4:	29430002 	ldp	w2, w0, [x0, #24]
    bbf8:	92403c21 	and	x1, x1, #0xffff
    bbfc:	9b027c21 	mul	x1, x1, x2
    bc00:	d360fc21 	lsr	x1, x1, #32
    bc04:	eb00003f 	cmp	x1, x0
    bc08:	540000e2 	b.cs	bc24 <f0+0x2004>  // b.hs, b.nlast
    bc0c:	8b0102b5 	add	x21, x21, x1
    bc10:	394002a0 	ldrb	w0, [x21]
    bc14:	7103fc1f 	cmp	w0, #0xff
    bc18:	54003260 	b.eq	c264 <f0+0x2644>  // b.none
    bc1c:	52800020 	mov	w0, #0x1                   	// #1
    bc20:	390002a0 	strb	w0, [x21]
    bc24:	911ea3e1 	add	x1, sp, #0x7a8
    bc28:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bc2c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bc30:	52800020 	mov	w0, #0x1                   	// #1
    bc34:	f903d7f5 	str	x21, [sp, #1960]
    bc38:	f903dbf7 	str	x23, [sp, #1968]
    bc3c:	97ffe512 	bl	5084 <fwp_data.part.0.constprop.0>
    bc40:	97ffe675 	bl	5614 <fwp_rc_fresh>
    bc44:	aa0003e2 	mov	x2, x0
    bc48:	911ee3e1 	add	x1, sp, #0x7b8
    bc4c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bc50:	52800020 	mov	w0, #0x1                   	// #1
    bc54:	f903dff7 	str	x23, [sp, #1976]
    bc58:	f903e3e2 	str	x2, [sp, #1984]
    bc5c:	97ffe50a 	bl	5084 <fwp_data.part.0.constprop.0>
    bc60:	97ffe66d 	bl	5614 <fwp_rc_fresh>
    bc64:	aa0003e2 	mov	x2, x0
    bc68:	911f23e1 	add	x1, sp, #0x7c8
    bc6c:	52800020 	mov	w0, #0x1                   	// #1
    bc70:	f903e7f5 	str	x21, [sp, #1992]
    bc74:	f903ebe2 	str	x2, [sp, #2000]
    bc78:	97ffe503 	bl	5084 <fwp_data.part.0.constprop.0>
    bc7c:	97ffe666 	bl	5614 <fwp_rc_fresh>
    bc80:	aa0003e2 	mov	x2, x0
    bc84:	911f63e1 	add	x1, sp, #0x7d8
    bc88:	52800020 	mov	w0, #0x1                   	// #1
    bc8c:	f903eff7 	str	x23, [sp, #2008]
    bc90:	f903f3e2 	str	x2, [sp, #2016]
    bc94:	97ffe4fc 	bl	5084 <fwp_data.part.0.constprop.0>
    bc98:	97ffe65f 	bl	5614 <fwp_rc_fresh>
    bc9c:	aa0003e2 	mov	x2, x0
    bca0:	911fa3e1 	add	x1, sp, #0x7e8
    bca4:	52800020 	mov	w0, #0x1                   	// #1
    bca8:	f903f7f5 	str	x21, [sp, #2024]
    bcac:	f903fbe2 	str	x2, [sp, #2032]
    bcb0:	97ffe4f5 	bl	5084 <fwp_data.part.0.constprop.0>
    bcb4:	97ffe658 	bl	5614 <fwp_rc_fresh>
    bcb8:	aa0003e2 	mov	x2, x0
    bcbc:	911fe3e1 	add	x1, sp, #0x7f8
    bcc0:	52800020 	mov	w0, #0x1                   	// #1
    bcc4:	f903fff7 	str	x23, [sp, #2040]
    bcc8:	f90403e2 	str	x2, [sp, #2048]
    bccc:	97ffe4ee 	bl	5084 <fwp_data.part.0.constprop.0>
    bcd0:	97ffe651 	bl	5614 <fwp_rc_fresh>
    bcd4:	aa0003e2 	mov	x2, x0
    bcd8:	912023e1 	add	x1, sp, #0x808
    bcdc:	52800020 	mov	w0, #0x1                   	// #1
    bce0:	f90407f5 	str	x21, [sp, #2056]
    bce4:	f9040be2 	str	x2, [sp, #2064]
    bce8:	97ffe4e7 	bl	5084 <fwp_data.part.0.constprop.0>
    bcec:	91174283 	add	x3, x20, #0x5d0
    bcf0:	aa0003f5 	mov	x21, x0
    bcf4:	f949d861 	ldr	x1, [x3, #5040]
    bcf8:	f949ec60 	ldr	x0, [x3, #5080]
    bcfc:	cb0102a1 	sub	x1, x21, x1
    bd00:	eb00403f 	cmp	x1, x0, lsl #16
    bd04:	54000322 	b.cs	bd68 <f0+0x2148>  // b.hs, b.nlast
    bd08:	d350fc22 	lsr	x2, x1, #16
    bd0c:	f949fc63 	ldr	x3, [x3, #5112]
    bd10:	8b020842 	add	x2, x2, x2, lsl #2
    bd14:	d37df042 	lsl	x2, x2, #3
    bd18:	8b020060 	add	x0, x3, x2
    bd1c:	f9401017 	ldr	x23, [x0, #32]
    bd20:	b4000257 	cbz	x23, bd68 <f0+0x2148>
    bd24:	38626862 	ldrb	w2, [x3, x2]
    bd28:	7100085f 	cmp	w2, #0x2
    bd2c:	54001640 	b.eq	bff4 <f0+0x23d4>  // b.none
    bd30:	7100045f 	cmp	w2, #0x1
    bd34:	540001a1 	b.ne	bd68 <f0+0x2148>  // b.any
    bd38:	29430002 	ldp	w2, w0, [x0, #24]
    bd3c:	92403c21 	and	x1, x1, #0xffff
    bd40:	9b027c21 	mul	x1, x1, x2
    bd44:	d360fc21 	lsr	x1, x1, #32
    bd48:	eb00003f 	cmp	x1, x0
    bd4c:	540000e2 	b.cs	bd68 <f0+0x2148>  // b.hs, b.nlast
    bd50:	8b0102f7 	add	x23, x23, x1
    bd54:	394002e0 	ldrb	w0, [x23]
    bd58:	7103fc1f 	cmp	w0, #0xff
    bd5c:	540028a0 	b.eq	c270 <f0+0x2650>  // b.none
    bd60:	52800020 	mov	w0, #0x1                   	// #1
    bd64:	390002e0 	strb	w0, [x23]
    bd68:	912063e1 	add	x1, sp, #0x818
    bd6c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bd70:	52800020 	mov	w0, #0x1                   	// #1
    bd74:	f9040ff7 	str	x23, [sp, #2072]
    bd78:	f90413f5 	str	x21, [sp, #2080]
    bd7c:	97ffe4c2 	bl	5084 <fwp_data.part.0.constprop.0>
    bd80:	97ffe625 	bl	5614 <fwp_rc_fresh>
    bd84:	aa0003e2 	mov	x2, x0
    bd88:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bd8c:	9120a3e1 	add	x1, sp, #0x828
    bd90:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bd94:	52800020 	mov	w0, #0x1                   	// #1
    bd98:	f90417e3 	str	x3, [sp, #2088]
    bd9c:	91174294 	add	x20, x20, #0x5d0
    bda0:	f9041be2 	str	x2, [sp, #2096]
    bda4:	97ffe4b8 	bl	5084 <fwp_data.part.0.constprop.0>
    bda8:	97ffe61b 	bl	5614 <fwp_rc_fresh>
    bdac:	aa0003e2 	mov	x2, x0
    bdb0:	9120e3e1 	add	x1, sp, #0x838
    bdb4:	52800020 	mov	w0, #0x1                   	// #1
    bdb8:	f9041ff7 	str	x23, [sp, #2104]
    bdbc:	f90423e2 	str	x2, [sp, #2112]
    bdc0:	97ffe4b1 	bl	5084 <fwp_data.part.0.constprop.0>
    bdc4:	f949da81 	ldr	x1, [x20, #5040]
    bdc8:	aa0003f5 	mov	x21, x0
    bdcc:	f949ee80 	ldr	x0, [x20, #5080]
    bdd0:	cb0102a1 	sub	x1, x21, x1
    bdd4:	eb00403f 	cmp	x1, x0, lsl #16
    bdd8:	54000322 	b.cs	be3c <f0+0x221c>  // b.hs, b.nlast
    bddc:	d350fc22 	lsr	x2, x1, #16
    bde0:	f949fe83 	ldr	x3, [x20, #5112]
    bde4:	8b020842 	add	x2, x2, x2, lsl #2
    bde8:	d37df042 	lsl	x2, x2, #3
    bdec:	8b020060 	add	x0, x3, x2
    bdf0:	f9401014 	ldr	x20, [x0, #32]
    bdf4:	b4000254 	cbz	x20, be3c <f0+0x221c>
    bdf8:	38626862 	ldrb	w2, [x3, x2]
    bdfc:	7100085f 	cmp	w2, #0x2
    be00:	54000f40 	b.eq	bfe8 <f0+0x23c8>  // b.none
    be04:	7100045f 	cmp	w2, #0x1
    be08:	540001a1 	b.ne	be3c <f0+0x221c>  // b.any
    be0c:	29430002 	ldp	w2, w0, [x0, #24]
    be10:	92403c21 	and	x1, x1, #0xffff
    be14:	9b027c21 	mul	x1, x1, x2
    be18:	d360fc21 	lsr	x1, x1, #32
    be1c:	eb00003f 	cmp	x1, x0
    be20:	540000e2 	b.cs	be3c <f0+0x221c>  // b.hs, b.nlast
    be24:	8b010294 	add	x20, x20, x1
    be28:	39400280 	ldrb	w0, [x20]
    be2c:	7103fc1f 	cmp	w0, #0xff
    be30:	540013c0 	b.eq	c0a8 <f0+0x2488>  // b.none
    be34:	52800020 	mov	w0, #0x1                   	// #1
    be38:	39000280 	strb	w0, [x20]
    be3c:	aa1603e1 	mov	x1, x22
    be40:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be44:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be48:	52800020 	mov	w0, #0x1                   	// #1
    be4c:	f90427e2 	str	x2, [sp, #2120]
    be50:	f9042bf5 	str	x21, [sp, #2128]
    be54:	97ffe48c 	bl	5084 <fwp_data.part.0.constprop.0>
    be58:	97ffe5ef 	bl	5614 <fwp_rc_fresh>
    be5c:	aa0003f5 	mov	x21, x0
    be60:	aa1303e1 	mov	x1, x19
    be64:	97fff097 	bl	80c0 <fwp_hof0.constprop.0>
    be68:	aa0003f4 	mov	x20, x0
    be6c:	aa1503e0 	mov	x0, x21
    be70:	97ffe744 	bl	5b80 <fwp_drop0>
    be74:	aa1303e0 	mov	x0, x19
    be78:	97ffe742 	bl	5b80 <fwp_drop0>
    be7c:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    be80:	f947f400 	ldr	x0, [x0, #4072]
    be84:	f9442fe2 	ldr	x2, [sp, #2136]
    be88:	f9400001 	ldr	x1, [x0]
    be8c:	eb010042 	subs	x2, x2, x1
    be90:	d2800001 	mov	x1, #0x0                   	// #0
    be94:	54001f41 	b.ne	c27c <f0+0x265c>  // b.any
    be98:	912183ff 	add	sp, sp, #0x860
    be9c:	aa1403e0 	mov	x0, x20
    bea0:	a94153f3 	ldp	x19, x20, [sp, #16]
    bea4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    bea8:	a94363f7 	ldp	x23, x24, [sp, #48]
    beac:	a9446bf9 	ldp	x25, x26, [sp, #64]
    beb0:	a94573fb 	ldp	x27, x28, [sp, #80]
    beb4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    beb8:	d65f03c0 	ret
    bebc:	aa1b03e0 	mov	x0, x27
    bec0:	97ffe26c 	bl	4870 <fwp_rc_forget_slot>
    bec4:	17fff79f 	b	9d40 <f0+0x120>
    bec8:	72003c5f 	tst	w2, #0xffff
    becc:	54fef3c1 	b.ne	9d44 <f0+0x124>  // b.any
    bed0:	17fff799 	b	9d34 <f0+0x114>
    bed4:	72003c3f 	tst	w1, #0xffff
    bed8:	54ff8641 	b.ne	afa0 <f0+0x1380>  // b.any
    bedc:	17fffc2c 	b	af8c <f0+0x136c>
    bee0:	72003c3f 	tst	w1, #0xffff
    bee4:	54ff8021 	b.ne	aee8 <f0+0x12c8>  // b.any
    bee8:	17fffbfb 	b	aed4 <f0+0x12b4>
    beec:	72003c3f 	tst	w1, #0xffff
    bef0:	54ff7b01 	b.ne	ae50 <f0+0x1230>  // b.any
    bef4:	17fffbd2 	b	ae3c <f0+0x121c>
    bef8:	72003c3f 	tst	w1, #0xffff
    befc:	54ff7401 	b.ne	ad7c <f0+0x115c>  // b.any
    bf00:	17fffb9a 	b	ad68 <f0+0x1148>
    bf04:	72003c3f 	tst	w1, #0xffff
    bf08:	54ff6c21 	b.ne	ac8c <f0+0x106c>  // b.any
    bf0c:	17fffb5b 	b	ac78 <f0+0x1058>
    bf10:	72003c3f 	tst	w1, #0xffff
    bf14:	54ff6441 	b.ne	ab9c <f0+0xf7c>  // b.any
    bf18:	17fffb1c 	b	ab88 <f0+0xf68>
    bf1c:	72003c3f 	tst	w1, #0xffff
    bf20:	54ff58e1 	b.ne	aa3c <f0+0xe1c>  // b.any
    bf24:	17fffac1 	b	aa28 <f0+0xe08>
    bf28:	72003c3f 	tst	w1, #0xffff
    bf2c:	54ff5101 	b.ne	a94c <f0+0xd2c>  // b.any
    bf30:	17fffa82 	b	a938 <f0+0xd18>
    bf34:	72003c3f 	tst	w1, #0xffff
    bf38:	54ff0861 	b.ne	a044 <f0+0x424>  // b.any
    bf3c:	17fff83d 	b	a030 <f0+0x410>
    bf40:	72003c3f 	tst	w1, #0xffff
    bf44:	54fefec1 	b.ne	9f1c <f0+0x2fc>  // b.any
    bf48:	17fff7f0 	b	9f08 <f0+0x2e8>
    bf4c:	72003c3f 	tst	w1, #0xffff
    bf50:	54fef521 	b.ne	9df4 <f0+0x1d4>  // b.any
    bf54:	17fff7a3 	b	9de0 <f0+0x1c0>
    bf58:	72003c3f 	tst	w1, #0xffff
    bf5c:	54ff1b61 	b.ne	a2c8 <f0+0x6a8>  // b.any
    bf60:	17fff8d5 	b	a2b4 <f0+0x694>
    bf64:	72003c3f 	tst	w1, #0xffff
    bf68:	54ff1581 	b.ne	a218 <f0+0x5f8>  // b.any
    bf6c:	17fff8a6 	b	a204 <f0+0x5e4>
    bf70:	72003c3f 	tst	w1, #0xffff
    bf74:	54ff0fa1 	b.ne	a168 <f0+0x548>  // b.any
    bf78:	17fff877 	b	a154 <f0+0x534>
    bf7c:	72003c3f 	tst	w1, #0xffff
    bf80:	54ff0aa1 	b.ne	a0d4 <f0+0x4b4>  // b.any
    bf84:	17fff84f 	b	a0c0 <f0+0x4a0>
    bf88:	72003c3f 	tst	w1, #0xffff
    bf8c:	54ff4941 	b.ne	a8b4 <f0+0xc94>  // b.any
    bf90:	17fffa44 	b	a8a0 <f0+0xc80>
    bf94:	72003c3f 	tst	w1, #0xffff
    bf98:	54ff4241 	b.ne	a7e0 <f0+0xbc0>  // b.any
    bf9c:	17fffa0c 	b	a7cc <f0+0xbac>
    bfa0:	72003c3f 	tst	w1, #0xffff
    bfa4:	54ff3d21 	b.ne	a748 <f0+0xb28>  // b.any
    bfa8:	17fff9e3 	b	a734 <f0+0xb14>
    bfac:	72003c3f 	tst	w1, #0xffff
    bfb0:	54ff3821 	b.ne	a6b4 <f0+0xa94>  // b.any
    bfb4:	17fff9bb 	b	a6a0 <f0+0xa80>
    bfb8:	72003c3f 	tst	w1, #0xffff
    bfbc:	54ff3201 	b.ne	a5fc <f0+0x9dc>  // b.any
    bfc0:	17fff98a 	b	a5e8 <f0+0x9c8>
    bfc4:	72003c3f 	tst	w1, #0xffff
    bfc8:	54ff2a21 	b.ne	a50c <f0+0x8ec>  // b.any
    bfcc:	17fff94b 	b	a4f8 <f0+0x8d8>
    bfd0:	72003c3f 	tst	w1, #0xffff
    bfd4:	54ff2421 	b.ne	a458 <f0+0x838>  // b.any
    bfd8:	17fff91b 	b	a444 <f0+0x824>
    bfdc:	72003c3f 	tst	w1, #0xffff
    bfe0:	54ff1e41 	b.ne	a3a8 <f0+0x788>  // b.any
    bfe4:	17fff8ec 	b	a394 <f0+0x774>
    bfe8:	72003c3f 	tst	w1, #0xffff
    bfec:	54fff281 	b.ne	be3c <f0+0x221c>  // b.any
    bff0:	17ffff8e 	b	be28 <f0+0x2208>
    bff4:	72003c3f 	tst	w1, #0xffff
    bff8:	54ffeb81 	b.ne	bd68 <f0+0x2148>  // b.any
    bffc:	17ffff56 	b	bd54 <f0+0x2134>
    c000:	72003c3f 	tst	w1, #0xffff
    c004:	54ffe101 	b.ne	bc24 <f0+0x2004>  // b.any
    c008:	17ffff02 	b	bc10 <f0+0x1ff0>
    c00c:	72003c3f 	tst	w1, #0xffff
    c010:	54ffd061 	b.ne	ba1c <f0+0x1dfc>  // b.any
    c014:	17fffe7d 	b	ba08 <f0+0x1de8>
    c018:	72003c3f 	tst	w1, #0xffff
    c01c:	54ffc961 	b.ne	b948 <f0+0x1d28>  // b.any
    c020:	17fffe45 	b	b934 <f0+0x1d14>
    c024:	72003c3f 	tst	w1, #0xffff
    c028:	54ffc341 	b.ne	b890 <f0+0x1c70>  // b.any
    c02c:	17fffe14 	b	b87c <f0+0x1c5c>
    c030:	72003c3f 	tst	w1, #0xffff
    c034:	54ffbd21 	b.ne	b7d8 <f0+0x1bb8>  // b.any
    c038:	17fffde3 	b	b7c4 <f0+0x1ba4>
    c03c:	72003c3f 	tst	w1, #0xffff
    c040:	54ffb801 	b.ne	b740 <f0+0x1b20>  // b.any
    c044:	17fffdba 	b	b72c <f0+0x1b0c>
    c048:	72003c3f 	tst	w1, #0xffff
    c04c:	54ffad81 	b.ne	b5fc <f0+0x19dc>  // b.any
    c050:	17fffd66 	b	b5e8 <f0+0x19c8>
    c054:	72003c3f 	tst	w1, #0xffff
    c058:	54ffa861 	b.ne	b564 <f0+0x1944>  // b.any
    c05c:	17fffd3d 	b	b550 <f0+0x1930>
    c060:	72003c3f 	tst	w1, #0xffff
    c064:	54ffa161 	b.ne	b490 <f0+0x1870>  // b.any
    c068:	17fffd05 	b	b47c <f0+0x185c>
    c06c:	72003c3f 	tst	w1, #0xffff
    c070:	54ff98a1 	b.ne	b384 <f0+0x1764>  // b.any
    c074:	17fffcbf 	b	b370 <f0+0x1750>
    c078:	72003c3f 	tst	w1, #0xffff
    c07c:	54ff93a1 	b.ne	b2f0 <f0+0x16d0>  // b.any
    c080:	17fffc97 	b	b2dc <f0+0x16bc>
    c084:	72003c3f 	tst	w1, #0xffff
    c088:	54ff8d81 	b.ne	b238 <f0+0x1618>  // b.any
    c08c:	17fffc66 	b	b224 <f0+0x1604>
    c090:	72003c3f 	tst	w1, #0xffff
    c094:	54ff84c1 	b.ne	b12c <f0+0x150c>  // b.any
    c098:	17fffc20 	b	b118 <f0+0x14f8>
    c09c:	72003c3f 	tst	w1, #0xffff
    c0a0:	54ff7dc1 	b.ne	b058 <f0+0x1438>  // b.any
    c0a4:	17fffbe8 	b	b044 <f0+0x1424>
    c0a8:	aa1403e0 	mov	x0, x20
    c0ac:	97ffe1f1 	bl	4870 <fwp_rc_forget_slot>
    c0b0:	17ffff61 	b	be34 <f0+0x2214>
    c0b4:	aa1503e0 	mov	x0, x21
    c0b8:	97ffe1ee 	bl	4870 <fwp_rc_forget_slot>
    c0bc:	17fff74c 	b	9dec <f0+0x1cc>
    c0c0:	aa1503e0 	mov	x0, x21
    c0c4:	97ffe1eb 	bl	4870 <fwp_rc_forget_slot>
    c0c8:	17fff793 	b	9f14 <f0+0x2f4>
    c0cc:	aa1703e0 	mov	x0, x23
    c0d0:	97ffe1e8 	bl	4870 <fwp_rc_forget_slot>
    c0d4:	17fff7da 	b	a03c <f0+0x41c>
    c0d8:	aa1703e0 	mov	x0, x23
    c0dc:	97ffe1e5 	bl	4870 <fwp_rc_forget_slot>
    c0e0:	17fff7fb 	b	a0cc <f0+0x4ac>
    c0e4:	aa1703e0 	mov	x0, x23
    c0e8:	97ffe1e2 	bl	4870 <fwp_rc_forget_slot>
    c0ec:	17fff81d 	b	a160 <f0+0x540>
    c0f0:	aa1703e0 	mov	x0, x23
    c0f4:	97ffe1df 	bl	4870 <fwp_rc_forget_slot>
    c0f8:	17fff846 	b	a210 <f0+0x5f0>
    c0fc:	aa1703e0 	mov	x0, x23
    c100:	97ffe1dc 	bl	4870 <fwp_rc_forget_slot>
    c104:	17fff86f 	b	a2c0 <f0+0x6a0>
    c108:	aa1703e0 	mov	x0, x23
    c10c:	97ffe1d9 	bl	4870 <fwp_rc_forget_slot>
    c110:	17fff8a4 	b	a3a0 <f0+0x780>
    c114:	aa1703e0 	mov	x0, x23
    c118:	97ffe1d6 	bl	4870 <fwp_rc_forget_slot>
    c11c:	17fff8cd 	b	a450 <f0+0x830>
    c120:	aa1703e0 	mov	x0, x23
    c124:	97ffe1d3 	bl	4870 <fwp_rc_forget_slot>
    c128:	17fff8f7 	b	a504 <f0+0x8e4>
    c12c:	aa1703e0 	mov	x0, x23
    c130:	97ffe1d0 	bl	4870 <fwp_rc_forget_slot>
    c134:	17fff930 	b	a5f4 <f0+0x9d4>
    c138:	aa1703e0 	mov	x0, x23
    c13c:	97ffe1cd 	bl	4870 <fwp_rc_forget_slot>
    c140:	17fff95b 	b	a6ac <f0+0xa8c>
    c144:	aa1703e0 	mov	x0, x23
    c148:	97ffe1ca 	bl	4870 <fwp_rc_forget_slot>
    c14c:	17fff97d 	b	a740 <f0+0xb20>
    c150:	aa1703e0 	mov	x0, x23
    c154:	97ffe1c7 	bl	4870 <fwp_rc_forget_slot>
    c158:	17fff9a0 	b	a7d8 <f0+0xbb8>
    c15c:	aa1703e0 	mov	x0, x23
    c160:	97ffe1c4 	bl	4870 <fwp_rc_forget_slot>
    c164:	17fff9d2 	b	a8ac <f0+0xc8c>
    c168:	aa1703e0 	mov	x0, x23
    c16c:	97ffe1c1 	bl	4870 <fwp_rc_forget_slot>
    c170:	17fff9f5 	b	a944 <f0+0xd24>
    c174:	aa1703e0 	mov	x0, x23
    c178:	97ffe1be 	bl	4870 <fwp_rc_forget_slot>
    c17c:	17fffa2e 	b	aa34 <f0+0xe14>
    c180:	aa1703e0 	mov	x0, x23
    c184:	97ffe1bb 	bl	4870 <fwp_rc_forget_slot>
    c188:	17fffa83 	b	ab94 <f0+0xf74>
    c18c:	aa1703e0 	mov	x0, x23
    c190:	97ffe1b8 	bl	4870 <fwp_rc_forget_slot>
    c194:	17fffabc 	b	ac84 <f0+0x1064>
    c198:	aa1703e0 	mov	x0, x23
    c19c:	97ffe1b5 	bl	4870 <fwp_rc_forget_slot>
    c1a0:	17fffaf5 	b	ad74 <f0+0x1154>
    c1a4:	aa1703e0 	mov	x0, x23
    c1a8:	97ffe1b2 	bl	4870 <fwp_rc_forget_slot>
    c1ac:	17fffb27 	b	ae48 <f0+0x1228>
    c1b0:	aa1703e0 	mov	x0, x23
    c1b4:	97ffe1af 	bl	4870 <fwp_rc_forget_slot>
    c1b8:	17fffb4a 	b	aee0 <f0+0x12c0>
    c1bc:	aa1703e0 	mov	x0, x23
    c1c0:	97ffe1ac 	bl	4870 <fwp_rc_forget_slot>
    c1c4:	17fffb75 	b	af98 <f0+0x1378>
    c1c8:	aa1703e0 	mov	x0, x23
    c1cc:	97ffe1a9 	bl	4870 <fwp_rc_forget_slot>
    c1d0:	17fffba0 	b	b050 <f0+0x1430>
    c1d4:	aa1703e0 	mov	x0, x23
    c1d8:	97ffe1a6 	bl	4870 <fwp_rc_forget_slot>
    c1dc:	17fffbd2 	b	b124 <f0+0x1504>
    c1e0:	aa1703e0 	mov	x0, x23
    c1e4:	97ffe1a3 	bl	4870 <fwp_rc_forget_slot>
    c1e8:	17fffc12 	b	b230 <f0+0x1610>
    c1ec:	aa1703e0 	mov	x0, x23
    c1f0:	97ffe1a0 	bl	4870 <fwp_rc_forget_slot>
    c1f4:	17fffc3d 	b	b2e8 <f0+0x16c8>
    c1f8:	aa1703e0 	mov	x0, x23
    c1fc:	97ffe19d 	bl	4870 <fwp_rc_forget_slot>
    c200:	17fffc5f 	b	b37c <f0+0x175c>
    c204:	aa1703e0 	mov	x0, x23
    c208:	97ffe19a 	bl	4870 <fwp_rc_forget_slot>
    c20c:	17fffc9f 	b	b488 <f0+0x1868>
    c210:	aa1703e0 	mov	x0, x23
    c214:	97ffe197 	bl	4870 <fwp_rc_forget_slot>
    c218:	17fffcd1 	b	b55c <f0+0x193c>
    c21c:	aa1503e0 	mov	x0, x21
    c220:	97ffe194 	bl	4870 <fwp_rc_forget_slot>
    c224:	17fffcf4 	b	b5f4 <f0+0x19d4>
    c228:	aa1703e0 	mov	x0, x23
    c22c:	97ffe191 	bl	4870 <fwp_rc_forget_slot>
    c230:	17fffd42 	b	b738 <f0+0x1b18>
    c234:	aa1703e0 	mov	x0, x23
    c238:	97ffe18e 	bl	4870 <fwp_rc_forget_slot>
    c23c:	17fffd65 	b	b7d0 <f0+0x1bb0>
    c240:	aa1703e0 	mov	x0, x23
    c244:	97ffe18b 	bl	4870 <fwp_rc_forget_slot>
    c248:	17fffd90 	b	b888 <f0+0x1c68>
    c24c:	aa1703e0 	mov	x0, x23
    c250:	97ffe188 	bl	4870 <fwp_rc_forget_slot>
    c254:	17fffdbb 	b	b940 <f0+0x1d20>
    c258:	aa1703e0 	mov	x0, x23
    c25c:	97ffe185 	bl	4870 <fwp_rc_forget_slot>
    c260:	17fffded 	b	ba14 <f0+0x1df4>
    c264:	aa1503e0 	mov	x0, x21
    c268:	97ffe182 	bl	4870 <fwp_rc_forget_slot>
    c26c:	17fffe6c 	b	bc1c <f0+0x1ffc>
    c270:	aa1703e0 	mov	x0, x23
    c274:	97ffe17f 	bl	4870 <fwp_rc_forget_slot>
    c278:	17fffeba 	b	bd60 <f0+0x2140>
    c27c:	97ffd9a5 	bl	2910 <__stack_chk_fail@plt>

000000000000c280 <fwp_main_thread>:
    c280:	d10443ff 	sub	sp, sp, #0x110
    c284:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c288:	f947f400 	ldr	x0, [x0, #4072]
    c28c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c290:	910303fd 	add	x29, sp, #0xc0
    c294:	a90d53f3 	stp	x19, x20, [sp, #208]
    c298:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    c29c:	91174261 	add	x1, x19, #0x5d0
    c2a0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c2a4:	b953a421 	ldr	w1, [x1, #5028]
    c2a8:	f9400002 	ldr	x2, [x0]
    c2ac:	f9005fe2 	str	x2, [sp, #184]
    c2b0:	d2800002 	mov	x2, #0x0                   	// #0
    c2b4:	34002821 	cbz	w1, c7b8 <fwp_main_thread+0x538>
    c2b8:	91174273 	add	x19, x19, #0x5d0
    c2bc:	b953aa60 	ldr	w0, [x19, #5032]
    c2c0:	35002740 	cbnz	w0, c7a8 <fwp_main_thread+0x528>
    c2c4:	91001fe2 	add	x2, sp, #0x7
    c2c8:	900000b5 	adrp	x21, 20000 <__data_start>
    c2cc:	900000a3 	adrp	x3, 20000 <__data_start>
    c2d0:	9101c2b3 	add	x19, x21, #0x70
    c2d4:	910fc063 	add	x3, x3, #0x3f0
    c2d8:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c2dc:	d2a00025 	mov	x5, #0x10000               	// #65536
    c2e0:	910023e0 	add	x0, sp, #0x8
    c2e4:	d2800001 	mov	x1, #0x0                   	// #0
    c2e8:	f90007e3 	str	x3, [sp, #8]
    c2ec:	b90013ff 	str	wzr, [sp, #16]
    c2f0:	a9019262 	stp	x2, x4, [x19, #24]
    c2f4:	f9000fe5 	str	x5, [sp, #24]
    c2f8:	97ffd91e 	bl	2770 <sigaltstack@plt>
    c2fc:	350026e0 	cbnz	w0, c7d8 <fwp_main_thread+0x558>
    c300:	4f000400 	movi	v0.4s, #0x0
    c304:	9100a3e0 	add	x0, sp, #0x28
    c308:	f0ffffa1 	adrp	x1, 3000 <fwp_range_release+0x30>
    c30c:	52800082 	mov	w2, #0x4                   	// #4
    c310:	9103c021 	add	x1, x1, #0xf0
    c314:	72a10002 	movk	w2, #0x800, lsl #16
    c318:	910083f4 	add	x20, sp, #0x20
    c31c:	f90013e1 	str	x1, [sp, #32]
    c320:	3d802000 	str	q0, [x0, #128]
    c324:	b900abe2 	str	w2, [sp, #168]
    c328:	ad000000 	stp	q0, q0, [x0]
    c32c:	ad010000 	stp	q0, q0, [x0, #32]
    c330:	ad020000 	stp	q0, q0, [x0, #64]
    c334:	ad030000 	stp	q0, q0, [x0, #96]
    c338:	97ffd966 	bl	28d0 <sigemptyset@plt>
    c33c:	350024e0 	cbnz	w0, c7d8 <fwp_main_thread+0x558>
    c340:	aa1403e1 	mov	x1, x20
    c344:	d2800002 	mov	x2, #0x0                   	// #0
    c348:	52800160 	mov	w0, #0xb                   	// #11
    c34c:	97ffd979 	bl	2930 <sigaction@plt>
    c350:	35002440 	cbnz	w0, c7d8 <fwp_main_thread+0x558>
    c354:	aa1403e1 	mov	x1, x20
    c358:	d2800002 	mov	x2, #0x0                   	// #0
    c35c:	528000e0 	mov	w0, #0x7                   	// #7
    c360:	97ffd974 	bl	2930 <sigaction@plt>
    c364:	350023a0 	cbnz	w0, c7d8 <fwp_main_thread+0x558>
    c368:	b9434a60 	ldr	w0, [x19, #840]
    c36c:	34002000 	cbz	w0, c76c <fwp_main_thread+0x4ec>
    c370:	9101c2b3 	add	x19, x21, #0x70
    c374:	a90f63f7 	stp	x23, x24, [sp, #240]
    c378:	b9434e60 	ldr	w0, [x19, #844]
    c37c:	340020c0 	cbz	w0, c794 <fwp_main_thread+0x514>
    c380:	9101c2b6 	add	x22, x21, #0x70
    c384:	f9400ad4 	ldr	x20, [x22, #16]
    c388:	b40010f4 	cbz	x20, c5a4 <fwp_main_thread+0x324>
    c38c:	aa1403f3 	mov	x19, x20
    c390:	91010297 	add	x23, x20, #0x40
    c394:	f90083f9 	str	x25, [sp, #256]
    c398:	52800038 	mov	w24, #0x1                   	// #1
    c39c:	39414a99 	ldrb	w25, [x20, #82]
    c3a0:	39014a98 	strb	w24, [x20, #82]
    c3a4:	f9401680 	ldr	x0, [x20, #40]
    c3a8:	b4000620 	cbz	x0, c46c <fwp_main_thread+0x1ec>
    c3ac:	f9403281 	ldr	x1, [x20, #96]
    c3b0:	39414680 	ldrb	w0, [x20, #81]
    c3b4:	b4000b61 	cbz	x1, c520 <fwp_main_thread+0x2a0>
    c3b8:	36000aa0 	tbz	w0, #0, c50c <fwp_main_thread+0x28c>
    c3bc:	39414a62 	ldrb	w2, [x19, #82]
    c3c0:	f9402280 	ldr	x0, [x20, #64]
    c3c4:	37000d82 	tbnz	w2, #0, c574 <fwp_main_thread+0x2f4>
    c3c8:	f9403261 	ldr	x1, [x19, #96]
    c3cc:	a911fe77 	stp	x23, xzr, [x19, #280]
    c3d0:	f9009660 	str	x0, [x19, #296]
    c3d4:	b4000040 	cbz	x0, c3dc <fwp_main_thread+0x15c>
    c3d8:	f9009013 	str	x19, [x0, #288]
    c3dc:	f9002293 	str	x19, [x20, #64]
    c3e0:	b4000101 	cbz	x1, c400 <fwp_main_thread+0x180>
    c3e4:	f9406ec0 	ldr	x0, [x22, #216]
    c3e8:	39015678 	strb	w24, [x19, #85]
    c3ec:	f9003661 	str	x1, [x19, #104]
    c3f0:	a910827f 	stp	xzr, x0, [x19, #264]
    c3f4:	b4000040 	cbz	x0, c3fc <fwp_main_thread+0x17c>
    c3f8:	f9008413 	str	x19, [x0, #264]
    c3fc:	f9006ed3 	str	x19, [x22, #216]
    c400:	39015a7f 	strb	wzr, [x19, #86]
    c404:	97ffe8a8 	bl	66a4 <fwp_block>
    c408:	f9408e62 	ldr	x2, [x19, #280]
    c40c:	b4000142 	cbz	x2, c434 <fwp_main_thread+0x1b4>
    c410:	a9520261 	ldp	x1, x0, [x19, #288]
    c414:	b4000bc1 	cbz	x1, c58c <fwp_main_thread+0x30c>
    c418:	f9009420 	str	x0, [x1, #296]
    c41c:	f9409660 	ldr	x0, [x19, #296]
    c420:	b4000040 	cbz	x0, c428 <fwp_main_thread+0x1a8>
    c424:	f9009001 	str	x1, [x0, #288]
    c428:	91080260 	add	x0, x19, #0x200
    c42c:	f900967f 	str	xzr, [x19, #296]
    c430:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c434:	39415660 	ldrb	w0, [x19, #85]
    c438:	f9400ac2 	ldr	x2, [x22, #16]
    c43c:	36000980 	tbz	w0, #0, c56c <fwp_main_thread+0x2ec>
    c440:	a9508261 	ldp	x1, x0, [x19, #264]
    c444:	b4000a81 	cbz	x1, c594 <fwp_main_thread+0x314>
    c448:	f9008820 	str	x0, [x1, #272]
    c44c:	b4000040 	cbz	x0, c454 <fwp_main_thread+0x1d4>
    c450:	f9008401 	str	x1, [x0, #264]
    c454:	91080260 	add	x0, x19, #0x200
    c458:	3901567f 	strb	wzr, [x19, #85]
    c45c:	aa0203f3 	mov	x19, x2
    c460:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c464:	f9401680 	ldr	x0, [x20, #40]
    c468:	b5fffa20 	cbnz	x0, c3ac <fwp_main_thread+0x12c>
    c46c:	9101c2a0 	add	x0, x21, #0x70
    c470:	39014a99 	strb	w25, [x20, #82]
    c474:	f94083f9 	ldr	x25, [sp, #256]
    c478:	f9419400 	ldr	x0, [x0, #808]
    c47c:	b4001580 	cbz	x0, c72c <fwp_main_thread+0x4ac>
    c480:	9101c2a0 	add	x0, x21, #0x70
    c484:	f941b001 	ldr	x1, [x0, #864]
    c488:	b903581f 	str	wzr, [x0, #856]
    c48c:	eb13003f 	cmp	x1, x19
    c490:	540016a1 	b.ne	c764 <fwp_main_thread+0x4e4>  // b.any
    c494:	b4000933 	cbz	x19, c5b8 <fwp_main_thread+0x338>
    c498:	9101c2a0 	add	x0, x21, #0x70
    c49c:	52800021 	mov	w1, #0x1                   	// #1
    c4a0:	39014a61 	strb	w1, [x19, #82]
    c4a4:	f9418005 	ldr	x5, [x0, #768]
    c4a8:	b4000885 	cbz	x5, c5b8 <fwp_main_thread+0x338>
    c4ac:	d503201f 	nop
    c4b0:	394140a0 	ldrb	w0, [x5, #80]
    c4b4:	37000060 	tbnz	w0, #0, c4c0 <fwp_main_thread+0x240>
    c4b8:	aa0503e0 	mov	x0, x5
    c4bc:	97ffdcad 	bl	3770 <fwp_cancel_tree.part.0>
    c4c0:	f9409ca5 	ldr	x5, [x5, #312]
    c4c4:	b5ffff65 	cbnz	x5, c4b0 <fwp_main_thread+0x230>
    c4c8:	9101c2b4 	add	x20, x21, #0x70
    c4cc:	52800036 	mov	w22, #0x1                   	// #1
    c4d0:	f9402a60 	ldr	x0, [x19, #80]
    c4d4:	f2001c1f 	tst	x0, #0xff000000ff
    c4d8:	540000e1 	b.ne	c4f4 <fwp_main_thread+0x274>  // b.any
    c4dc:	f9403e80 	ldr	x0, [x20, #120]
    c4e0:	39015276 	strb	w22, [x19, #84]
    c4e4:	f900827f 	str	xzr, [x19, #256]
    c4e8:	b40005a0 	cbz	x0, c59c <fwp_main_thread+0x31c>
    c4ec:	f9008013 	str	x19, [x0, #256]
    c4f0:	f9003e93 	str	x19, [x20, #120]
    c4f4:	97ffe86c 	bl	66a4 <fwp_block>
    c4f8:	97ffe7fe 	bl	64f0 <fwp_free_zombie>
    c4fc:	f9418280 	ldr	x0, [x20, #768]
    c500:	b40005c0 	cbz	x0, c5b8 <fwp_main_thread+0x338>
    c504:	f941b293 	ldr	x19, [x20, #864]
    c508:	17fffff2 	b	c4d0 <fwp_main_thread+0x250>
    c50c:	97ffdd3d 	bl	3a00 <fwp_now_ns>
    c510:	f9403281 	ldr	x1, [x20, #96]
    c514:	eb01001f 	cmp	x0, x1
    c518:	54000fca 	b.ge	c710 <fwp_main_thread+0x490>  // b.tcont
    c51c:	39414680 	ldrb	w0, [x20, #81]
    c520:	39414a62 	ldrb	w2, [x19, #82]
    c524:	3707f4e0 	tbnz	w0, #0, c3c0 <fwp_main_thread+0x140>
    c528:	f9403281 	ldr	x1, [x20, #96]
    c52c:	370001c2 	tbnz	w2, #0, c564 <fwp_main_thread+0x2e4>
    c530:	f9403260 	ldr	x0, [x19, #96]
    c534:	b4000180 	cbz	x0, c564 <fwp_main_thread+0x2e4>
    c538:	b4000061 	cbz	x1, c544 <fwp_main_thread+0x2c4>
    c53c:	eb01001f 	cmp	x0, x1
    c540:	9a81d000 	csel	x0, x0, x1, le
    c544:	f9402281 	ldr	x1, [x20, #64]
    c548:	a911fe77 	stp	x23, xzr, [x19, #280]
    c54c:	f9009661 	str	x1, [x19, #296]
    c550:	b4001381 	cbz	x1, c7c0 <fwp_main_thread+0x540>
    c554:	f9009033 	str	x19, [x1, #288]
    c558:	aa0003e1 	mov	x1, x0
    c55c:	f9002293 	str	x19, [x20, #64]
    c560:	17ffffa1 	b	c3e4 <fwp_main_thread+0x164>
    c564:	f9402280 	ldr	x0, [x20, #64]
    c568:	17ffff99 	b	c3cc <fwp_main_thread+0x14c>
    c56c:	aa0203f3 	mov	x19, x2
    c570:	17ffff8d 	b	c3a4 <fwp_main_thread+0x124>
    c574:	a911fe77 	stp	x23, xzr, [x19, #280]
    c578:	f9009660 	str	x0, [x19, #296]
    c57c:	b4000040 	cbz	x0, c584 <fwp_main_thread+0x304>
    c580:	f9009013 	str	x19, [x0, #288]
    c584:	f9002293 	str	x19, [x20, #64]
    c588:	17ffff9e 	b	c400 <fwp_main_thread+0x180>
    c58c:	f9000040 	str	x0, [x2]
    c590:	17ffffa4 	b	c420 <fwp_main_thread+0x1a0>
    c594:	f9006ec0 	str	x0, [x22, #216]
    c598:	17ffffad 	b	c44c <fwp_main_thread+0x1cc>
    c59c:	f9004293 	str	x19, [x20, #128]
    c5a0:	17ffffd4 	b	c4f0 <fwp_main_thread+0x270>
    c5a4:	f94196c0 	ldr	x0, [x22, #808]
    c5a8:	b4000c00 	cbz	x0, c728 <fwp_main_thread+0x4a8>
    c5ac:	f941b2c0 	ldr	x0, [x22, #864]
    c5b0:	b9035adf 	str	wzr, [x22, #856]
    c5b4:	b5000d80 	cbnz	x0, c764 <fwp_main_thread+0x4e4>
    c5b8:	9101c2b4 	add	x20, x21, #0x70
    c5bc:	97ffe7cd 	bl	64f0 <fwp_free_zombie>
    c5c0:	f9404280 	ldr	x0, [x20, #128]
    c5c4:	b5000d00 	cbnz	x0, c764 <fwp_main_thread+0x4e4>
    c5c8:	f9406e80 	ldr	x0, [x20, #216]
    c5cc:	b5000cc0 	cbnz	x0, c764 <fwp_main_thread+0x4e4>
    c5d0:	b940fa93 	ldr	w19, [x20, #248]
    c5d4:	340001d3 	cbz	w19, c60c <fwp_main_thread+0x38c>
    c5d8:	93407e76 	sxtw	x22, w19
    c5dc:	51000673 	sub	w19, w19, #0x1
    c5e0:	d1000ad6 	sub	x22, x22, #0x2
    c5e4:	91040297 	add	x23, x20, #0x100
    c5e8:	cb3342d6 	sub	x22, x22, w19, uxtw
    c5ec:	93407e73 	sxtw	x19, w19
    c5f0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c5f4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c5f8:	b900fa93 	str	w19, [x20, #248]
    c5fc:	d1000673 	sub	x19, x19, #0x1
    c600:	97ffd90c 	bl	2a30 <munmap@plt>
    c604:	eb16027f 	cmp	x19, x22
    c608:	54ffff41 	b.ne	c5f0 <fwp_main_thread+0x370>  // b.any
    c60c:	900000b3 	adrp	x19, 20000 <__data_start>
    c610:	91004260 	add	x0, x19, #0x10
    c614:	b9404000 	ldr	w0, [x0, #64]
    c618:	37f80040 	tbnz	w0, #31, c620 <fwp_main_thread+0x3a0>
    c61c:	97ffd8c1 	bl	2920 <close@plt>
    c620:	9101c2a0 	add	x0, x21, #0x70
    c624:	91004261 	add	x1, x19, #0x10
    c628:	12800002 	mov	w2, #0xffffffff            	// #-1
    c62c:	d2800013 	mov	x19, #0x0                   	// #0
    c630:	f941b416 	ldr	x22, [x0, #872]
    c634:	b9004022 	str	w2, [x1, #64]
    c638:	f941b814 	ldr	x20, [x0, #880]
    c63c:	b4000176 	cbz	x22, c668 <fwp_main_thread+0x3e8>
    c640:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c644:	b40000c0 	cbz	x0, c65c <fwp_main_thread+0x3dc>
    c648:	f9400001 	ldr	x1, [x0]
    c64c:	b50008c1 	cbnz	x1, c764 <fwp_main_thread+0x4e4>
    c650:	f9400401 	ldr	x1, [x0, #8]
    c654:	b5000881 	cbnz	x1, c764 <fwp_main_thread+0x4e4>
    c658:	97ffe126 	bl	4af0 <fwp_mem_free>
    c65c:	91000673 	add	x19, x19, #0x1
    c660:	eb16027f 	cmp	x19, x22
    c664:	54fffee1 	b.ne	c640 <fwp_main_thread+0x3c0>  // b.any
    c668:	aa1403e0 	mov	x0, x20
    c66c:	97ffe121 	bl	4af0 <fwp_mem_free>
    c670:	9101c2a0 	add	x0, x21, #0x70
    c674:	f941b013 	ldr	x19, [x0, #864]
    c678:	f901b41f 	str	xzr, [x0, #872]
    c67c:	f901b81f 	str	xzr, [x0, #880]
    c680:	b40001f3 	cbz	x19, c6bc <fwp_main_thread+0x43c>
    c684:	f9401661 	ldr	x1, [x19, #40]
    c688:	b50006e1 	cbnz	x1, c764 <fwp_main_thread+0x4e4>
    c68c:	f9405661 	ldr	x1, [x19, #168]
    c690:	b50006a1 	cbnz	x1, c764 <fwp_main_thread+0x4e4>
    c694:	f9419401 	ldr	x1, [x0, #808]
    c698:	b5000661 	cbnz	x1, c764 <fwp_main_thread+0x4e4>
    c69c:	f9419c00 	ldr	x0, [x0, #824]
    c6a0:	b5000620 	cbnz	x0, c764 <fwp_main_thread+0x4e4>
    c6a4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c6a8:	90000120 	adrp	x0, 30000 <alt.5+0xfc10>
    c6ac:	910fc000 	add	x0, x0, #0x3f0
    c6b0:	97ffd88c 	bl	28e0 <memset@plt>
    c6b4:	aa1303e0 	mov	x0, x19
    c6b8:	97ffe10e 	bl	4af0 <fwp_mem_free>
    c6bc:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c6c0:	f947ec00 	ldr	x0, [x0, #4056]
    c6c4:	9101c2b5 	add	x21, x21, #0x70
    c6c8:	f9400000 	ldr	x0, [x0]
    c6cc:	f9000abf 	str	xzr, [x21, #16]
    c6d0:	f901b2bf 	str	xzr, [x21, #864]
    c6d4:	97ffd8db 	bl	2a40 <fflush@plt>
    c6d8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c6dc:	f947f400 	ldr	x0, [x0, #4072]
    c6e0:	f9405fe2 	ldr	x2, [sp, #184]
    c6e4:	f9400001 	ldr	x1, [x0]
    c6e8:	eb010042 	subs	x2, x2, x1
    c6ec:	d2800001 	mov	x1, #0x0                   	// #0
    c6f0:	54000821 	b.ne	c7f4 <fwp_main_thread+0x574>  // b.any
    c6f4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c6f8:	d2800000 	mov	x0, #0x0                   	// #0
    c6fc:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c700:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c704:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c708:	910443ff 	add	sp, sp, #0x110
    c70c:	d65f03c0 	ret
    c710:	39414280 	ldrb	w0, [x20, #80]
    c714:	3707f040 	tbnz	w0, #0, c51c <fwp_main_thread+0x29c>
    c718:	aa1403e0 	mov	x0, x20
    c71c:	97ffdc15 	bl	3770 <fwp_cancel_tree.part.0>
    c720:	39414680 	ldrb	w0, [x20, #81]
    c724:	17ffff7f 	b	c520 <fwp_main_thread+0x2a0>
    c728:	d2800013 	mov	x19, #0x0                   	// #0
    c72c:	9101c2b4 	add	x20, x21, #0x70
    c730:	f9419e80 	ldr	x0, [x20, #824]
    c734:	b5ffea60 	cbnz	x0, c480 <fwp_main_thread+0x200>
    c738:	f9419280 	ldr	x0, [x20, #800]
    c73c:	97ffe0ed 	bl	4af0 <fwp_mem_free>
    c740:	f901929f 	str	xzr, [x20, #800]
    c744:	f9019a9f 	str	xzr, [x20, #816]
    c748:	f941b280 	ldr	x0, [x20, #864]
    c74c:	b4000413 	cbz	x19, c7cc <fwp_main_thread+0x54c>
    c750:	f900567f 	str	xzr, [x19, #168]
    c754:	f9005e7f 	str	xzr, [x19, #184]
    c758:	b9035a9f 	str	wzr, [x20, #856]
    c75c:	eb00027f 	cmp	x19, x0
    c760:	54ffe9c0 	b.eq	c498 <fwp_main_thread+0x218>  // b.none
    c764:	f90083f9 	str	x25, [sp, #256]
    c768:	97ffd87e 	bl	2960 <abort@plt>
    c76c:	f0ffffa0 	adrp	x0, 3000 <fwp_range_release+0x30>
    c770:	91078000 	add	x0, x0, #0x1e0
    c774:	940001df 	bl	cef0 <atexit>
    c778:	a90f63f7 	stp	x23, x24, [sp, #240]
    c77c:	35000380 	cbnz	w0, c7ec <fwp_main_thread+0x56c>
    c780:	52800020 	mov	w0, #0x1                   	// #1
    c784:	b9034a60 	str	w0, [x19, #840]
    c788:	9101c2b3 	add	x19, x21, #0x70
    c78c:	b9434e60 	ldr	w0, [x19, #844]
    c790:	35ffdf80 	cbnz	w0, c380 <fwp_main_thread+0x100>
    c794:	97fff523 	bl	9c20 <f0>
    c798:	f901aa60 	str	x0, [x19, #848]
    c79c:	52800021 	mov	w1, #0x1                   	// #1
    c7a0:	b9034e61 	str	w1, [x19, #844]
    c7a4:	17fffef7 	b	c380 <fwp_main_thread+0x100>
    c7a8:	90ffffc0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    c7ac:	91008000 	add	x0, x0, #0x20
    c7b0:	940001d0 	bl	cef0 <atexit>
    c7b4:	17fffec4 	b	c2c4 <fwp_main_thread+0x44>
    c7b8:	97ffde73 	bl	4184 <fwp_heap_init>
    c7bc:	17fffebf 	b	c2b8 <fwp_main_thread+0x38>
    c7c0:	aa0003e1 	mov	x1, x0
    c7c4:	f9002293 	str	x19, [x20, #64]
    c7c8:	17ffff07 	b	c3e4 <fwp_main_thread+0x164>
    c7cc:	b9035a9f 	str	wzr, [x20, #856]
    c7d0:	b4ffef40 	cbz	x0, c5b8 <fwp_main_thread+0x338>
    c7d4:	17ffffe4 	b	c764 <fwp_main_thread+0x4e4>
    c7d8:	b0000000 	adrp	x0, d000 <_IO_stdin_used+0xe0>
    c7dc:	91164000 	add	x0, x0, #0x590
    c7e0:	a90f63f7 	stp	x23, x24, [sp, #240]
    c7e4:	f90083f9 	str	x25, [sp, #256]
    c7e8:	97ffdc26 	bl	3880 <fwp_trap>
    c7ec:	f90083f9 	str	x25, [sp, #256]
    c7f0:	97ffda70 	bl	31b0 <descent_phase_fail>
    c7f4:	f90083f9 	str	x25, [sp, #256]
    c7f8:	97ffd846 	bl	2910 <__stack_chk_fail@plt>
    c7fc:	d503201f 	nop

000000000000c800 <__divti3>:
    c800:	d503245f 	bti	c
    c804:	d2800004 	mov	x4, #0x0                   	// #0
    c808:	b7f80721 	tbnz	x1, #63, c8ec <__divti3+0xec>
    c80c:	b6f80083 	tbz	x3, #63, c81c <__divti3+0x1c>
    c810:	eb0203e2 	negs	x2, x2
    c814:	aa2403e4 	mvn	x4, x4
    c818:	da0303e3 	ngc	x3, x3
    c81c:	aa0203e6 	mov	x6, x2
    c820:	aa0003e7 	mov	x7, x0
    c824:	aa0103e5 	mov	x5, x1
    c828:	b5000583 	cbnz	x3, c8d8 <__divti3+0xd8>
    c82c:	eb01005f 	cmp	x2, x1
    c830:	54000e69 	b.ls	c9fc <__divti3+0x1fc>  // b.plast
    c834:	dac01040 	clz	x0, x2
    c838:	b40000e0 	cbz	x0, c854 <__divti3+0x54>
    c83c:	4b0003e1 	neg	w1, w0
    c840:	9ac020a5 	lsl	x5, x5, x0
    c844:	9ac02046 	lsl	x6, x2, x0
    c848:	9ac124e1 	lsr	x1, x7, x1
    c84c:	aa050025 	orr	x5, x1, x5
    c850:	9ac020e7 	lsl	x7, x7, x0
    c854:	d360fcc8 	lsr	x8, x6, #32
    c858:	92407cc2 	and	x2, x6, #0xffffffff
    c85c:	9ac808a3 	udiv	x3, x5, x8
    c860:	9b089465 	msub	x5, x3, x8, x5
    c864:	aa0303e0 	mov	x0, x3
    c868:	9b037c41 	mul	x1, x2, x3
    c86c:	93c780a5 	extr	x5, x5, x7, #32
    c870:	eb05003f 	cmp	x1, x5
    c874:	540000a9 	b.ls	c888 <__divti3+0x88>  // b.plast
    c878:	ab0500c5 	adds	x5, x6, x5
    c87c:	d1000460 	sub	x0, x3, #0x1
    c880:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c884:	540015a8 	b.hi	cb38 <__divti3+0x338>  // b.pmore
    c888:	cb0100a5 	sub	x5, x5, x1
    c88c:	9ac808a3 	udiv	x3, x5, x8
    c890:	9b089465 	msub	x5, x3, x8, x5
    c894:	aa0303e1 	mov	x1, x3
    c898:	9b037c42 	mul	x2, x2, x3
    c89c:	aa0703e3 	mov	x3, x7
    c8a0:	b3607ca3 	bfi	x3, x5, #32, #32
    c8a4:	eb03005f 	cmp	x2, x3
    c8a8:	540000c9 	b.ls	c8c0 <__divti3+0xc0>  // b.plast
    c8ac:	ab0300c3 	adds	x3, x6, x3
    c8b0:	d1000425 	sub	x5, x1, #0x1
    c8b4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c8b8:	d1000821 	sub	x1, x1, #0x2
    c8bc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    c8c0:	aa008020 	orr	x0, x1, x0, lsl #32
    c8c4:	d2800001 	mov	x1, #0x0                   	// #0
    c8c8:	b4000064 	cbz	x4, c8d4 <__divti3+0xd4>
    c8cc:	eb0003e0 	negs	x0, x0
    c8d0:	da0103e1 	ngc	x1, x1
    c8d4:	d65f03c0 	ret
    c8d8:	eb01007f 	cmp	x3, x1
    c8dc:	54000109 	b.ls	c8fc <__divti3+0xfc>  // b.plast
    c8e0:	d2800001 	mov	x1, #0x0                   	// #0
    c8e4:	d2800000 	mov	x0, #0x0                   	// #0
    c8e8:	17fffff8 	b	c8c8 <__divti3+0xc8>
    c8ec:	eb0003e0 	negs	x0, x0
    c8f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c8f4:	da0103e1 	ngc	x1, x1
    c8f8:	17ffffc5 	b	c80c <__divti3+0xc>
    c8fc:	dac01067 	clz	x7, x3
    c900:	b40010e7 	cbz	x7, cb1c <__divti3+0x31c>
    c904:	d2800805 	mov	x5, #0x40                  	// #64
    c908:	cb0700a5 	sub	x5, x5, x7
    c90c:	9ac72063 	lsl	x3, x3, x7
    c910:	9ac52448 	lsr	x8, x2, x5
    c914:	aa030108 	orr	x8, x8, x3
    c918:	9ac52426 	lsr	x6, x1, x5
    c91c:	92407d0a 	and	x10, x8, #0xffffffff
    c920:	d360fd09 	lsr	x9, x8, #32
    c924:	9ac52403 	lsr	x3, x0, x5
    c928:	9ac72021 	lsl	x1, x1, x7
    c92c:	aa010063 	orr	x3, x3, x1
    c930:	9ac72042 	lsl	x2, x2, x7
    c934:	9ac908cb 	udiv	x11, x6, x9
    c938:	9b099965 	msub	x5, x11, x9, x6
    c93c:	aa0b03e1 	mov	x1, x11
    c940:	9b0b7d46 	mul	x6, x10, x11
    c944:	93c380a5 	extr	x5, x5, x3, #32
    c948:	eb0500df 	cmp	x6, x5
    c94c:	540000a9 	b.ls	c960 <__divti3+0x160>  // b.plast
    c950:	ab050105 	adds	x5, x8, x5
    c954:	d1000561 	sub	x1, x11, #0x1
    c958:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    c95c:	54000f48 	b.hi	cb44 <__divti3+0x344>  // b.pmore
    c960:	cb0600a6 	sub	x6, x5, x6
    c964:	9ac908cb 	udiv	x11, x6, x9
    c968:	9b099969 	msub	x9, x11, x9, x6
    c96c:	aa0b03e5 	mov	x5, x11
    c970:	9b0b7d4a 	mul	x10, x10, x11
    c974:	b3607d23 	bfi	x3, x9, #32, #32
    c978:	eb03015f 	cmp	x10, x3
    c97c:	540000a9 	b.ls	c990 <__divti3+0x190>  // b.plast
    c980:	ab030103 	adds	x3, x8, x3
    c984:	d1000565 	sub	x5, x11, #0x1
    c988:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    c98c:	54000e28 	b.hi	cb50 <__divti3+0x350>  // b.pmore
    c990:	aa0180a1 	orr	x1, x5, x1, lsl #32
    c994:	92407c48 	and	x8, x2, #0xffffffff
    c998:	2a0503e5 	mov	w5, w5
    c99c:	d360fc42 	lsr	x2, x2, #32
    c9a0:	d360fc26 	lsr	x6, x1, #32
    c9a4:	cb0a0063 	sub	x3, x3, x10
    c9a8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    c9ac:	9b087caa 	mul	x10, x5, x8
    c9b0:	9b087cc8 	mul	x8, x6, x8
    c9b4:	9b0220a5 	madd	x5, x5, x2, x8
    c9b8:	9b027cc6 	mul	x6, x6, x2
    c9bc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    c9c0:	8b0900c5 	add	x5, x6, x9
    c9c4:	eb02011f 	cmp	x8, x2
    c9c8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    c9cc:	8b4280c6 	add	x6, x6, x2, lsr #32
    c9d0:	eb06007f 	cmp	x3, x6
    c9d4:	540000e3 	b.cc	c9f0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    c9d8:	92407d4a 	and	x10, x10, #0xffffffff
    c9dc:	9ac72000 	lsl	x0, x0, x7
    c9e0:	8b028142 	add	x2, x10, x2, lsl #32
    c9e4:	eb02001f 	cmp	x0, x2
    c9e8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    c9ec:	54000a01 	b.ne	cb2c <__divti3+0x32c>  // b.any
    c9f0:	d1000420 	sub	x0, x1, #0x1
    c9f4:	d2800001 	mov	x1, #0x0                   	// #0
    c9f8:	17ffffb4 	b	c8c8 <__divti3+0xc8>
    c9fc:	b5000062 	cbnz	x2, ca08 <__divti3+0x208>
    ca00:	d2800022 	mov	x2, #0x1                   	// #1
    ca04:	9ac30846 	udiv	x6, x2, x3
    ca08:	dac010c8 	clz	x8, x6
    ca0c:	b5000408 	cbnz	x8, ca8c <__divti3+0x28c>
    ca10:	d360fcc9 	lsr	x9, x6, #32
    ca14:	92407cc5 	and	x5, x6, #0xffffffff
    ca18:	cb060023 	sub	x3, x1, x6
    ca1c:	d2800021 	mov	x1, #0x1                   	// #1
    ca20:	9ac90868 	udiv	x8, x3, x9
    ca24:	9b098d03 	msub	x3, x8, x9, x3
    ca28:	aa0803e0 	mov	x0, x8
    ca2c:	9b057d02 	mul	x2, x8, x5
    ca30:	93c78063 	extr	x3, x3, x7, #32
    ca34:	eb03005f 	cmp	x2, x3
    ca38:	540000a9 	b.ls	ca4c <__divti3+0x24c>  // b.plast
    ca3c:	ab0300c3 	adds	x3, x6, x3
    ca40:	d1000500 	sub	x0, x8, #0x1
    ca44:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ca48:	54000968 	b.hi	cb74 <__divti3+0x374>  // b.pmore
    ca4c:	cb020063 	sub	x3, x3, x2
    ca50:	9ac90862 	udiv	x2, x3, x9
    ca54:	aa0203e8 	mov	x8, x2
    ca58:	9b098c42 	msub	x2, x2, x9, x3
    ca5c:	aa0703e3 	mov	x3, x7
    ca60:	9b057d05 	mul	x5, x8, x5
    ca64:	b3607c43 	bfi	x3, x2, #32, #32
    ca68:	eb0300bf 	cmp	x5, x3
    ca6c:	540000c9 	b.ls	ca84 <__divti3+0x284>  // b.plast
    ca70:	ab0300c2 	adds	x2, x6, x3
    ca74:	d1000503 	sub	x3, x8, #0x1
    ca78:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ca7c:	d1000908 	sub	x8, x8, #0x2
    ca80:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ca84:	aa008100 	orr	x0, x8, x0, lsl #32
    ca88:	17ffff90 	b	c8c8 <__divti3+0xc8>
    ca8c:	9ac820c6 	lsl	x6, x6, x8
    ca90:	d2800803 	mov	x3, #0x40                  	// #64
    ca94:	cb080063 	sub	x3, x3, x8
    ca98:	d360fcc9 	lsr	x9, x6, #32
    ca9c:	9ac82027 	lsl	x7, x1, x8
    caa0:	92407cc5 	and	x5, x6, #0xffffffff
    caa4:	9ac32422 	lsr	x2, x1, x3
    caa8:	9ac32403 	lsr	x3, x0, x3
    caac:	aa070063 	orr	x3, x3, x7
    cab0:	9ac9084a 	udiv	x10, x2, x9
    cab4:	9ac82007 	lsl	x7, x0, x8
    cab8:	9b098940 	msub	x0, x10, x9, x2
    cabc:	aa0a03e1 	mov	x1, x10
    cac0:	9b0a7ca2 	mul	x2, x5, x10
    cac4:	93c38000 	extr	x0, x0, x3, #32
    cac8:	eb00005f 	cmp	x2, x0
    cacc:	540000a9 	b.ls	cae0 <__divti3+0x2e0>  // b.plast
    cad0:	ab0000c0 	adds	x0, x6, x0
    cad4:	d1000541 	sub	x1, x10, #0x1
    cad8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cadc:	54000468 	b.hi	cb68 <__divti3+0x368>  // b.pmore
    cae0:	cb020000 	sub	x0, x0, x2
    cae4:	9ac9080a 	udiv	x10, x0, x9
    cae8:	9b098140 	msub	x0, x10, x9, x0
    caec:	aa0a03e2 	mov	x2, x10
    caf0:	9b0a7ca8 	mul	x8, x5, x10
    caf4:	b3607c03 	bfi	x3, x0, #32, #32
    caf8:	eb03011f 	cmp	x8, x3
    cafc:	540000a9 	b.ls	cb10 <__divti3+0x310>  // b.plast
    cb00:	ab0300c3 	adds	x3, x6, x3
    cb04:	d1000542 	sub	x2, x10, #0x1
    cb08:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cb0c:	54000288 	b.hi	cb5c <__divti3+0x35c>  // b.pmore
    cb10:	cb080063 	sub	x3, x3, x8
    cb14:	aa018041 	orr	x1, x2, x1, lsl #32
    cb18:	17ffffc2 	b	ca20 <__divti3+0x220>
    cb1c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cb20:	d2800001 	mov	x1, #0x0                   	// #0
    cb24:	9a9f87e0 	cset	x0, ls	// ls = plast
    cb28:	17ffff68 	b	c8c8 <__divti3+0xc8>
    cb2c:	aa0103e0 	mov	x0, x1
    cb30:	d2800001 	mov	x1, #0x0                   	// #0
    cb34:	17ffff65 	b	c8c8 <__divti3+0xc8>
    cb38:	d1000860 	sub	x0, x3, #0x2
    cb3c:	8b0600a5 	add	x5, x5, x6
    cb40:	17ffff52 	b	c888 <__divti3+0x88>
    cb44:	d1000961 	sub	x1, x11, #0x2
    cb48:	8b0800a5 	add	x5, x5, x8
    cb4c:	17ffff85 	b	c960 <__divti3+0x160>
    cb50:	d1000965 	sub	x5, x11, #0x2
    cb54:	8b080063 	add	x3, x3, x8
    cb58:	17ffff8e 	b	c990 <__divti3+0x190>
    cb5c:	d1000942 	sub	x2, x10, #0x2
    cb60:	8b060063 	add	x3, x3, x6
    cb64:	17ffffeb 	b	cb10 <__divti3+0x310>
    cb68:	d1000941 	sub	x1, x10, #0x2
    cb6c:	8b060000 	add	x0, x0, x6
    cb70:	17ffffdc 	b	cae0 <__divti3+0x2e0>
    cb74:	d1000900 	sub	x0, x8, #0x2
    cb78:	8b060063 	add	x3, x3, x6
    cb7c:	17ffffb4 	b	ca4c <__divti3+0x24c>

000000000000cb80 <__modti3>:
    cb80:	d503245f 	bti	c
    cb84:	d2800004 	mov	x4, #0x0                   	// #0
    cb88:	b6f80081 	tbz	x1, #63, cb98 <__modti3+0x18>
    cb8c:	eb0003e0 	negs	x0, x0
    cb90:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cb94:	da0103e1 	ngc	x1, x1
    cb98:	f100007f 	cmp	x3, #0x0
    cb9c:	5400128b 	b.lt	cdec <__modti3+0x26c>  // b.tstop
    cba0:	aa0003e7 	mov	x7, x0
    cba4:	aa0103e6 	mov	x6, x1
    cba8:	540004e1 	b.ne	cc44 <__modti3+0xc4>  // b.any
    cbac:	eb02003f 	cmp	x1, x2
    cbb0:	54000dc2 	b.cs	cd68 <__modti3+0x1e8>  // b.hs, b.nlast
    cbb4:	dac01043 	clz	x3, x2
    cbb8:	aa0303e5 	mov	x5, x3
    cbbc:	b40000e3 	cbz	x3, cbd8 <__modti3+0x58>
    cbc0:	4b0303e6 	neg	w6, w3
    cbc4:	9ac32021 	lsl	x1, x1, x3
    cbc8:	9ac32042 	lsl	x2, x2, x3
    cbcc:	9ac62406 	lsr	x6, x0, x6
    cbd0:	aa0100c6 	orr	x6, x6, x1
    cbd4:	9ac32007 	lsl	x7, x0, x3
    cbd8:	d360fc40 	lsr	x0, x2, #32
    cbdc:	92407c43 	and	x3, x2, #0xffffffff
    cbe0:	9ac008c1 	udiv	x1, x6, x0
    cbe4:	9b009826 	msub	x6, x1, x0, x6
    cbe8:	9b017c61 	mul	x1, x3, x1
    cbec:	93c780c6 	extr	x6, x6, x7, #32
    cbf0:	eb06003f 	cmp	x1, x6
    cbf4:	540000a9 	b.ls	cc08 <__modti3+0x88>  // b.plast
    cbf8:	ab060046 	adds	x6, x2, x6
    cbfc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    cc00:	8b0200c8 	add	x8, x6, x2
    cc04:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    cc08:	cb0100c6 	sub	x6, x6, x1
    cc0c:	9ac008c8 	udiv	x8, x6, x0
    cc10:	9b009901 	msub	x1, x8, x0, x6
    cc14:	aa0703e0 	mov	x0, x7
    cc18:	9b087c63 	mul	x3, x3, x8
    cc1c:	b3607c20 	bfi	x0, x1, #32, #32
    cc20:	eb00007f 	cmp	x3, x0
    cc24:	54001088 	b.hi	ce34 <__modti3+0x2b4>  // b.pmore
    cc28:	cb030000 	sub	x0, x0, x3
    cc2c:	9ac52400 	lsr	x0, x0, x5
    cc30:	d2800001 	mov	x1, #0x0                   	// #0
    cc34:	b4000064 	cbz	x4, cc40 <__modti3+0xc0>
    cc38:	eb0003e0 	negs	x0, x0
    cc3c:	da0103e1 	ngc	x1, x1
    cc40:	d65f03c0 	ret
    cc44:	dac01066 	clz	x6, x3
    cc48:	eb03003f 	cmp	x1, x3
    cc4c:	54ffff43 	b.cc	cc34 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cc50:	93407cc5 	sxtw	x5, w6
    cc54:	d2800808 	mov	x8, #0x40                  	// #64
    cc58:	cb050108 	sub	x8, x8, x5
    cc5c:	9ac62063 	lsl	x3, x3, x6
    cc60:	9ac62025 	lsl	x5, x1, x6
    cc64:	9ac82447 	lsr	x7, x2, x8
    cc68:	aa0300e7 	orr	x7, x7, x3
    cc6c:	9ac82423 	lsr	x3, x1, x8
    cc70:	92407cec 	and	x12, x7, #0xffffffff
    cc74:	d360fcea 	lsr	x10, x7, #32
    cc78:	9ac82401 	lsr	x1, x0, x8
    cc7c:	aa050021 	orr	x1, x1, x5
    cc80:	9ac62042 	lsl	x2, x2, x6
    cc84:	9ac62000 	lsl	x0, x0, x6
    cc88:	9aca086b 	udiv	x11, x3, x10
    cc8c:	9b0a8d63 	msub	x3, x11, x10, x3
    cc90:	aa0b03e5 	mov	x5, x11
    cc94:	9b0b7d89 	mul	x9, x12, x11
    cc98:	93c18063 	extr	x3, x3, x1, #32
    cc9c:	eb03013f 	cmp	x9, x3
    cca0:	540000a9 	b.ls	ccb4 <__modti3+0x134>  // b.plast
    cca4:	ab0300e3 	adds	x3, x7, x3
    cca8:	d1000565 	sub	x5, x11, #0x1
    ccac:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ccb0:	54001168 	b.hi	cedc <__modti3+0x35c>  // b.pmore
    ccb4:	cb090063 	sub	x3, x3, x9
    ccb8:	9aca086b 	udiv	x11, x3, x10
    ccbc:	9b0a8d6a 	msub	x10, x11, x10, x3
    ccc0:	aa0b03e9 	mov	x9, x11
    ccc4:	9b0b7d8c 	mul	x12, x12, x11
    ccc8:	b3607d41 	bfi	x1, x10, #32, #32
    cccc:	eb01019f 	cmp	x12, x1
    ccd0:	540000a9 	b.ls	cce4 <__modti3+0x164>  // b.plast
    ccd4:	ab0100e1 	adds	x1, x7, x1
    ccd8:	d1000569 	sub	x9, x11, #0x1
    ccdc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    cce0:	54000f88 	b.hi	ced0 <__modti3+0x350>  // b.pmore
    cce4:	aa058123 	orr	x3, x9, x5, lsl #32
    cce8:	92407c4b 	and	x11, x2, #0xffffffff
    ccec:	2a0903e9 	mov	w9, w9
    ccf0:	d360fc4a 	lsr	x10, x2, #32
    ccf4:	d360fc63 	lsr	x3, x3, #32
    ccf8:	cb0c0021 	sub	x1, x1, x12
    ccfc:	aa0a03ec 	mov	x12, x10
    cd00:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    cd04:	9b0b7d25 	mul	x5, x9, x11
    cd08:	9b0b7c6b 	mul	x11, x3, x11
    cd0c:	9b0a2d29 	madd	x9, x9, x10, x11
    cd10:	92407caa 	and	x10, x5, #0xffffffff
    cd14:	9b0c7c63 	mul	x3, x3, x12
    cd18:	8b458125 	add	x5, x9, x5, lsr #32
    cd1c:	8b0d0069 	add	x9, x3, x13
    cd20:	eb05017f 	cmp	x11, x5
    cd24:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    cd28:	8b058149 	add	x9, x10, x5, lsl #32
    cd2c:	8b458063 	add	x3, x3, x5, lsr #32
    cd30:	eb03003f 	cmp	x1, x3
    cd34:	54000063 	b.cc	cd40 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    cd38:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    cd3c:	54000082 	b.cs	cd4c <__modti3+0x1cc>  // b.hs, b.nlast
    cd40:	eb020129 	subs	x9, x9, x2
    cd44:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    cd48:	cb070063 	sub	x3, x3, x7
    cd4c:	eb090000 	subs	x0, x0, x9
    cd50:	da030021 	sbc	x1, x1, x3
    cd54:	9ac62400 	lsr	x0, x0, x6
    cd58:	9ac82028 	lsl	x8, x1, x8
    cd5c:	aa000100 	orr	x0, x8, x0
    cd60:	9ac62421 	lsr	x1, x1, x6
    cd64:	17ffffb4 	b	cc34 <__modti3+0xb4>
    cd68:	b5000062 	cbnz	x2, cd74 <__modti3+0x1f4>
    cd6c:	d2800023 	mov	x3, #0x1                   	// #1
    cd70:	9ac20862 	udiv	x2, x3, x2
    cd74:	dac01048 	clz	x8, x2
    cd78:	aa0803e5 	mov	x5, x8
    cd7c:	b5000668 	cbnz	x8, ce48 <__modti3+0x2c8>
    cd80:	cb020020 	sub	x0, x1, x2
    cd84:	d360fc49 	lsr	x9, x2, #32
    cd88:	92407c4a 	and	x10, x2, #0xffffffff
    cd8c:	9ac90801 	udiv	x1, x0, x9
    cd90:	9b098020 	msub	x0, x1, x9, x0
    cd94:	9b0a7c21 	mul	x1, x1, x10
    cd98:	93c78000 	extr	x0, x0, x7, #32
    cd9c:	eb00003f 	cmp	x1, x0
    cda0:	540000a9 	b.ls	cdb4 <__modti3+0x234>  // b.plast
    cda4:	ab000040 	adds	x0, x2, x0
    cda8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cdac:	8b020003 	add	x3, x0, x2
    cdb0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cdb4:	cb010001 	sub	x1, x0, x1
    cdb8:	9ac90820 	udiv	x0, x1, x9
    cdbc:	9b098403 	msub	x3, x0, x9, x1
    cdc0:	aa0703e1 	mov	x1, x7
    cdc4:	9b0a7c00 	mul	x0, x0, x10
    cdc8:	b3607c61 	bfi	x1, x3, #32, #32
    cdcc:	eb01001f 	cmp	x0, x1
    cdd0:	540000a9 	b.ls	cde4 <__modti3+0x264>  // b.plast
    cdd4:	ab010041 	adds	x1, x2, x1
    cdd8:	8b020022 	add	x2, x1, x2
    cddc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cde0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cde4:	cb000020 	sub	x0, x1, x0
    cde8:	17ffff91 	b	cc2c <__modti3+0xac>
    cdec:	eb0203e5 	negs	x5, x2
    cdf0:	aa0003e7 	mov	x7, x0
    cdf4:	da0303e8 	ngc	x8, x3
    cdf8:	aa0503e2 	mov	x2, x5
    cdfc:	aa0803e3 	mov	x3, x8
    ce00:	aa0103e6 	mov	x6, x1
    ce04:	b4ffed48 	cbz	x8, cbac <__modti3+0x2c>
    ce08:	eb01011f 	cmp	x8, x1
    ce0c:	54fff148 	b.hi	cc34 <__modti3+0xb4>  // b.pmore
    ce10:	dac01109 	clz	x9, x8
    ce14:	2a0903e6 	mov	w6, w9
    ce18:	b5fff1c9 	cbnz	x9, cc50 <__modti3+0xd0>
    ce1c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    ce20:	54000068 	b.hi	ce2c <__modti3+0x2ac>  // b.pmore
    ce24:	eb050007 	subs	x7, x0, x5
    ce28:	da080021 	sbc	x1, x1, x8
    ce2c:	aa0703e0 	mov	x0, x7
    ce30:	17ffff81 	b	cc34 <__modti3+0xb4>
    ce34:	ab000040 	adds	x0, x2, x0
    ce38:	8b020002 	add	x2, x0, x2
    ce3c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    ce40:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    ce44:	17ffff79 	b	cc28 <__modti3+0xa8>
    ce48:	9ac82042 	lsl	x2, x2, x8
    ce4c:	d2800803 	mov	x3, #0x40                  	// #64
    ce50:	cb080063 	sub	x3, x3, x8
    ce54:	d360fc49 	lsr	x9, x2, #32
    ce58:	9ac82027 	lsl	x7, x1, x8
    ce5c:	92407c4a 	and	x10, x2, #0xffffffff
    ce60:	9ac32426 	lsr	x6, x1, x3
    ce64:	9ac32403 	lsr	x3, x0, x3
    ce68:	aa070063 	orr	x3, x3, x7
    ce6c:	9ac908c1 	udiv	x1, x6, x9
    ce70:	9ac82007 	lsl	x7, x0, x8
    ce74:	9b099820 	msub	x0, x1, x9, x6
    ce78:	9b017d41 	mul	x1, x10, x1
    ce7c:	93c38000 	extr	x0, x0, x3, #32
    ce80:	eb00003f 	cmp	x1, x0
    ce84:	540000a9 	b.ls	ce98 <__modti3+0x318>  // b.plast
    ce88:	ab000040 	adds	x0, x2, x0
    ce8c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ce90:	8b020006 	add	x6, x0, x2
    ce94:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    ce98:	cb010000 	sub	x0, x0, x1
    ce9c:	9ac90801 	udiv	x1, x0, x9
    cea0:	9b098026 	msub	x6, x1, x9, x0
    cea4:	aa0303e0 	mov	x0, x3
    cea8:	9b017d41 	mul	x1, x10, x1
    ceac:	b3607cc0 	bfi	x0, x6, #32, #32
    ceb0:	eb00003f 	cmp	x1, x0
    ceb4:	540000a9 	b.ls	cec8 <__modti3+0x348>  // b.plast
    ceb8:	ab000040 	adds	x0, x2, x0
    cebc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cec0:	8b020003 	add	x3, x0, x2
    cec4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cec8:	cb010000 	sub	x0, x0, x1
    cecc:	17ffffb0 	b	cd8c <__modti3+0x20c>
    ced0:	d1000969 	sub	x9, x11, #0x2
    ced4:	8b070021 	add	x1, x1, x7
    ced8:	17ffff83 	b	cce4 <__modti3+0x164>
    cedc:	d1000965 	sub	x5, x11, #0x2
    cee0:	8b070063 	add	x3, x3, x7
    cee4:	17ffff74 	b	ccb4 <__modti3+0x134>
    cee8:	d503201f 	nop
    ceec:	d503201f 	nop

000000000000cef0 <atexit>:
    cef0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cef4:	900000a2 	adrp	x2, 20000 <__data_start>
    cef8:	d2800001 	mov	x1, #0x0                   	// #0
    cefc:	910003fd 	mov	x29, sp
    cf00:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cf04:	f9400442 	ldr	x2, [x2, #8]
    cf08:	17ffd642 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000cf0c <_fini>:
    cf0c:	d503201f 	nop
    cf10:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cf14:	910003fd 	mov	x29, sp
    cf18:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cf1c:	d65f03c0 	ret
