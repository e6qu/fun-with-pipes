
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__modti3+0x30>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911b20a5 	add	x5, x5, #0x6c8
    2aa0:	f0000044 	adrp	x4, d000 <__modti3+0x30>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	911b4084 	add	x4, x4, #0x6d0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	91014261 	add	x1, x19, #0x50
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe888>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9006820 	str	x0, [x1, #208]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__modti3+0x30>
    2b34:	91306000 	add	x0, x0, #0xc18
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1fd0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	911a5042 	add	x2, x2, #0x694
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	91014273 	add	x19, x19, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943fa60 	ldr	w0, [x19, #1016]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff50 	bl	2990 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <__modti3+0x30>
    2c7c:	9130a000 	add	x0, x0, #0xc28
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97ffff07 	bl	28a0 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <__modti3+0x30>
    2c8c:	91332000 	add	x0, x0, #0xcc8
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffeee 	bl	2850 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <__modti3+0x30>
    2ca4:	91328000 	add	x0, x0, #0xca0
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <__modti3+0x30>
    2cb0:	9131c000 	add	x0, x0, #0xc70
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <__modti3+0x30>
    2cbc:	91312000 	add	x0, x0, #0xc48
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91010000 	add	x0, x0, #0x40
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91010021 	add	x1, x1, #0x40
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91010000 	add	x0, x0, #0x40
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91010021 	add	x1, x1, #0x40
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xc90>
    2eb4:	910c8021 	add	x1, x1, #0x320
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xc90>
    3158:	910c0021 	add	x1, x1, #0x300
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    3190:	910de000 	add	x0, x0, #0x378
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xb90>
    31c4:	911942a1 	add	x1, x21, #0x650
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9b0>
    31d8:	912900a5 	add	x5, x5, #0xa40
    31dc:	911942a1 	add	x1, x21, #0x650
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	911942b7 	add	x23, x21, #0x650
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	911942b5 	add	x21, x21, #0x650
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	911942b5 	add	x21, x21, #0x650
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9b0>
    3368:	9128e0a5 	add	x5, x5, #0xa38
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000042 	adrp	x2, d000 <__modti3+0x30>
    339c:	910e4042 	add	x2, x2, #0x390
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000042 	adrp	x2, d000 <__modti3+0x30>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	910fa042 	add	x2, x2, #0x3e8
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000059 	adrp	x25, d000 <__modti3+0x30>
    3428:	d000005a 	adrp	x26, d000 <__modti3+0x30>
    342c:	91112339 	add	x25, x25, #0x448
    3430:	910ec35a 	add	x26, x26, #0x3b0
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000005b 	adrp	x27, d000 <__modti3+0x30>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	910ee377 	add	x23, x27, #0x3b8
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	91122000 	add	x0, x0, #0x488
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.9+0xfb90>
    34f4:	b0000165 	adrp	x5, 30000 <alt.9+0xfb90>
    34f8:	b0000162 	adrp	x2, 30000 <alt.9+0xfb90>
    34fc:	d0000043 	adrp	x3, d000 <__modti3+0x30>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000055 	adrp	x21, d000 <__modti3+0x30>
    3508:	f9423824 	ldr	x4, [x1, #1136]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f9423ca5 	ldr	x5, [x5, #1144]
    3514:	9111c033 	add	x19, x1, #0x470
    3518:	f9424046 	ldr	x6, [x2, #1152]
    351c:	910ec063 	add	x3, x3, #0x3b0
    3520:	911282b5 	add	x21, x21, #0x4a0
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	91138000 	add	x0, x0, #0x4e0
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    35ac:	910f0000 	add	x0, x0, #0x3c0
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    366c:	910de000 	add	x0, x0, #0x378
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <__modti3+0x30>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9113a021 	add	x1, x1, #0x4e8
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <__modti3+0x30>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	9113c021 	add	x1, x1, #0x4f0
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <__modti3+0x30>
    37e0:	9113e021 	add	x1, x1, #0x4f8
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffe12 	bl	3074 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000042 	adrp	x2, d000 <__modti3+0x30>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91140042 	add	x2, x2, #0x500
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc33 	bl	2910 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc60 	bl	29d0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc6e 	bl	2a10 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbbc 	bl	2750 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbdc 	bl	2840 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbbf 	bl	27f0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc17 	bl	2960 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    3950:	910de000 	add	x0, x0, #0x378
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc12 	bl	29a0 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc1c 	bl	29d0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc2a 	bl	2a10 <_Exit@plt>
    396c:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    3970:	91144000 	add	x0, x0, #0x510
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb8a 	bl	27d0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    3a08:	9114c000 	add	x0, x0, #0x530
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffba4 	bl	28a0 <__stack_chk_fail@plt>
    3a14:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    3a18:	91154000 	add	x0, x0, #0x550
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xc90>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc0cc20 	ldr	q0, [x1, #816]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	910142b5 	add	x21, x21, #0x50
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f9406aa2 	ldr	x2, [x21, #208]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb9f 	bl	2960 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    3b18:	9115e000 	add	x0, x0, #0x578
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb5f 	bl	28a0 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b3c:	91014063 	add	x3, x3, #0x50
    3b40:	9350fc01 	asr	x1, x0, #16
    3b44:	d1000440 	sub	x0, x2, #0x1
    3b48:	f9406c62 	ldr	x2, [x3, #216]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9404463 	ldr	x3, [x3, #136]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    3b88:	9116a000 	add	x0, x0, #0x5a8
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000044 	adrp	x4, d000 <__modti3+0x30>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	9117e084 	add	x4, x4, #0x5f8
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffb06 	bl	2810 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb5f 	bl	2980 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb4a 	bl	2940 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa93 	bl	26f0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffacb 	bl	27f0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffabc 	bl	27f0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa74 	bl	26f0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa80 	bl	2730 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb10 	bl	2980 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000044 	adrp	x4, d000 <__modti3+0x30>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	91184084 	add	x4, x4, #0x610
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa90 	bl	2810 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa7f 	bl	27f0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffadf 	bl	2980 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000044 	adrp	x4, d000 <__modti3+0x30>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	91180084 	add	x4, x4, #0x600
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa68 	bl	2810 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa52 	bl	27f0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa26 	bl	27f0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa42 	bl	28a0 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xb90>
    3fa8:	91194042 	add	x2, x2, #0x650
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000041 	adrp	x1, d000 <__modti3+0x30>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000040 	adrp	x0, d000 <__modti3+0x30>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	91186021 	add	x1, x1, #0x618
    4004:	91188000 	add	x0, x0, #0x620
    4008:	97fffa0a 	bl	2830 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa87 	bl	2a50 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa35 	bl	2940 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa74 	bl	2a50 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9e5 	bl	2820 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000042 	adrp	x2, d000 <__modti3+0x30>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	91190042 	add	x2, x2, #0x640
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa08 	b	2910 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9b0>
    410c:	91154061 	add	x1, x3, #0x550
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xb90>
    411c:	91194262 	add	x2, x19, #0x650
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0xc90>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9b0>
    414c:	91164021 	add	x1, x1, #0x590
    4150:	3dc0d043 	ldr	q3, [x2, #832]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9b0>
    417c:	91154063 	add	x3, x3, #0x550
    4180:	9117c084 	add	x4, x4, #0x5f0
    4184:	91194266 	add	x6, x19, #0x650
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9cd 	bl	2930 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91194275 	add	x21, x19, #0x650
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9b7 	bl	2930 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    4268:	911bc000 	add	x0, x0, #0x6f0
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9f0 	bl	2a30 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91194273 	add	x19, x19, #0x650
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffbac 	bl	3170 <fwp_heap_oom>

00000000000042c4 <caf75>:
    42c4:	900000e2 	adrp	x2, 20000 <__data_start>
    42c8:	91014041 	add	x1, x2, #0x50
    42cc:	b940e020 	ldr	w0, [x1, #224]
    42d0:	34000060 	cbz	w0, 42dc <caf75+0x18>
    42d4:	f9407420 	ldr	x0, [x1, #232]
    42d8:	d65f03c0 	ret
    42dc:	b940f020 	ldr	w0, [x1, #240]
    42e0:	340000e0 	cbz	w0, 42fc <caf75+0x38>
    42e4:	f9407c20 	ldr	x0, [x1, #248]
    42e8:	91014042 	add	x2, x2, #0x50
    42ec:	52800021 	mov	w1, #0x1                   	// #1
    42f0:	b900e041 	str	w1, [x2, #224]
    42f4:	f9007440 	str	x0, [x2, #232]
    42f8:	d65f03c0 	ret
    42fc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4300:	52800024 	mov	w4, #0x1                   	// #1
    4304:	aa0303e0 	mov	x0, x3
    4308:	b900f024 	str	w4, [x1, #240]
    430c:	f9007c23 	str	x3, [x1, #248]
    4310:	17fffff6 	b	42e8 <caf75+0x24>

0000000000004314 <fwp_wake_io>:
    4314:	900000e9 	adrp	x9, 20000 <__data_start>
    4318:	91014122 	add	x2, x9, #0x50
    431c:	f9400001 	ldr	x1, [x0]
    4320:	5280000a 	mov	w10, #0x0                   	// #0
    4324:	f9406046 	ldr	x6, [x2, #192]
    4328:	52800008 	mov	w8, #0x0                   	// #0
    432c:	4f000400 	movi	v0.4s, #0x0
    4330:	52800027 	mov	w7, #0x1                   	// #1
    4334:	aa0103e2 	mov	x2, x1
    4338:	b4000321 	cbz	x1, 439c <fwp_wake_io+0x88>
    433c:	f9408c25 	ldr	x5, [x1, #280]
    4340:	39015c27 	strb	w7, [x1, #87]
    4344:	b4000165 	cbz	x5, 4370 <fwp_wake_io+0x5c>
    4348:	a9520c24 	ldp	x4, x3, [x1, #288]
    434c:	b4000364 	cbz	x4, 43b8 <fwp_wake_io+0xa4>
    4350:	f9009483 	str	x3, [x4, #296]
    4354:	f9409423 	ldr	x3, [x1, #296]
    4358:	b4000043 	cbz	x3, 4360 <fwp_wake_io+0x4c>
    435c:	f9009064 	str	x4, [x3, #288]
    4360:	91080023 	add	x3, x1, #0x200
    4364:	f900943f 	str	xzr, [x1, #296]
    4368:	3c918060 	stur	q0, [x3, #-232]
    436c:	f9400001 	ldr	x1, [x0]
    4370:	f9402843 	ldr	x3, [x2, #80]
    4374:	f2001c7f 	tst	x3, #0xff000000ff
    4378:	54fffde1 	b.ne	4334 <fwp_wake_io+0x20>  // b.any
    437c:	39015047 	strb	w7, [x2, #84]
    4380:	f900805f 	str	xzr, [x2, #256]
    4384:	b40001e6 	cbz	x6, 43c0 <fwp_wake_io+0xac>
    4388:	f90080c2 	str	x2, [x6, #256]
    438c:	aa0203e6 	mov	x6, x2
    4390:	52800028 	mov	w8, #0x1                   	// #1
    4394:	aa0103e2 	mov	x2, x1
    4398:	b5fffd21 	cbnz	x1, 433c <fwp_wake_io+0x28>
    439c:	3400006a 	cbz	w10, 43a8 <fwp_wake_io+0x94>
    43a0:	91014120 	add	x0, x9, #0x50
    43a4:	f900640b 	str	x11, [x0, #200]
    43a8:	34000068 	cbz	w8, 43b4 <fwp_wake_io+0xa0>
    43ac:	91014129 	add	x9, x9, #0x50
    43b0:	f9006126 	str	x6, [x9, #192]
    43b4:	d65f03c0 	ret
    43b8:	f90000a3 	str	x3, [x5]
    43bc:	17ffffe7 	b	4358 <fwp_wake_io+0x44>
    43c0:	aa0203eb 	mov	x11, x2
    43c4:	5280002a 	mov	w10, #0x1                   	// #1
    43c8:	17fffff1 	b	438c <fwp_wake_io+0x78>
    43cc:	d503201f 	nop

00000000000043d0 <ad_raw_free.part.0>:
    43d0:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fb90>
    43d4:	d2800001 	mov	x1, #0x0                   	// #0
    43d8:	9111c082 	add	x2, x4, #0x470
    43dc:	14000005 	b	43f0 <ad_raw_free.part.0+0x20>
    43e0:	91000421 	add	x1, x1, #0x1
    43e4:	91006042 	add	x2, x2, #0x18
    43e8:	f140043f 	cmp	x1, #0x1, lsl #12
    43ec:	54000220 	b.eq	4430 <ad_raw_free.part.0+0x60>  // b.none
    43f0:	f9400043 	ldr	x3, [x2]
    43f4:	eb03001f 	cmp	x0, x3
    43f8:	54ffff41 	b.ne	43e0 <ad_raw_free.part.0+0x10>  // b.any
    43fc:	8b010421 	add	x1, x1, x1, lsl #1
    4400:	9111c084 	add	x4, x4, #0x470
    4404:	900000e2 	adrp	x2, 20000 <__data_start>
    4408:	91014042 	add	x2, x2, #0x50
    440c:	8b010c81 	add	x1, x4, x1, lsl #3
    4410:	b9401024 	ldr	w4, [x1, #16]
    4414:	f9400425 	ldr	x5, [x1, #8]
    4418:	a9007c3f 	stp	xzr, xzr, [x1]
    441c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4420:	f900083f 	str	xzr, [x1, #16]
    4424:	cb050061 	sub	x1, x3, x5
    4428:	f8247841 	str	x1, [x2, x4, lsl #3]
    442c:	17fff94d 	b	2960 <free@plt>
    4430:	f100001f 	cmp	x0, #0x0
    4434:	b0000041 	adrp	x1, d000 <__modti3+0x30>
    4438:	911c6021 	add	x1, x1, #0x718
    443c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4440:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    4444:	911c0000 	add	x0, x0, #0x700
    4448:	910003fd 	mov	x29, sp
    444c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4450:	97fffbcc 	bl	3380 <ad_raw_fail>

0000000000004454 <fwp_tape_buffers_dispose>:
    4454:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4458:	910003fd 	mov	x29, sp
    445c:	f9000bf3 	str	x19, [sp, #16]
    4460:	aa0003f3 	mov	x19, x0
    4464:	f9400000 	ldr	x0, [x0]
    4468:	b4000040 	cbz	x0, 4470 <fwp_tape_buffers_dispose+0x1c>
    446c:	97ffffd9 	bl	43d0 <ad_raw_free.part.0>
    4470:	f9400a60 	ldr	x0, [x19, #16]
    4474:	b4000040 	cbz	x0, 447c <fwp_tape_buffers_dispose+0x28>
    4478:	97ffffd6 	bl	43d0 <ad_raw_free.part.0>
    447c:	f9401260 	ldr	x0, [x19, #32]
    4480:	b4000040 	cbz	x0, 4488 <fwp_tape_buffers_dispose+0x34>
    4484:	97ffffd3 	bl	43d0 <ad_raw_free.part.0>
    4488:	4f000400 	movi	v0.4s, #0x0
    448c:	f9001a7f 	str	xzr, [x19, #48]
    4490:	ad000260 	stp	q0, q0, [x19]
    4494:	3d800a60 	str	q0, [x19, #32]
    4498:	f9400bf3 	ldr	x19, [sp, #16]
    449c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    44a0:	d65f03c0 	ret

00000000000044a4 <ad_raw_realloc>:
    44a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	f90013f5 	str	x21, [sp, #32]
    44b4:	b40005a1 	cbz	x1, 4568 <ad_raw_realloc+0xc4>
    44b8:	aa0103f4 	mov	x20, x1
    44bc:	2a0203f5 	mov	w21, w2
    44c0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fb90>
    44c4:	d2800004 	mov	x4, #0x0                   	// #0
    44c8:	9111c025 	add	x5, x1, #0x470
    44cc:	14000005 	b	44e0 <ad_raw_realloc+0x3c>
    44d0:	91000484 	add	x4, x4, #0x1
    44d4:	910060a5 	add	x5, x5, #0x18
    44d8:	f140049f 	cmp	x4, #0x1, lsl #12
    44dc:	54000320 	b.eq	4540 <ad_raw_realloc+0x9c>  // b.none
    44e0:	f94000a6 	ldr	x6, [x5]
    44e4:	eb06001f 	cmp	x0, x6
    44e8:	54ffff41 	b.ne	44d0 <ad_raw_realloc+0x2c>  // b.any
    44ec:	8b040484 	add	x4, x4, x4, lsl #1
    44f0:	9111c021 	add	x1, x1, #0x470
    44f4:	8b040c33 	add	x19, x1, x4, lsl #3
    44f8:	b4000080 	cbz	x0, 4508 <ad_raw_realloc+0x64>
    44fc:	b9401261 	ldr	w1, [x19, #16]
    4500:	6b15003f 	cmp	w1, w21
    4504:	540002c1 	b.ne	455c <ad_raw_realloc+0xb8>  // b.any
    4508:	aa1403e1 	mov	x1, x20
    450c:	97fff8e1 	bl	2890 <realloc@plt>
    4510:	aa0003ed 	mov	x13, x0
    4514:	b40000c0 	cbz	x0, 452c <ad_raw_realloc+0x88>
    4518:	2a1503e3 	mov	w3, w21
    451c:	aa1403e2 	mov	x2, x20
    4520:	aa1303e0 	mov	x0, x19
    4524:	aa0d03e1 	mov	x1, x13
    4528:	97fffa9a 	bl	2f90 <ad_raw_record>
    452c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4530:	aa0d03e0 	mov	x0, x13
    4534:	f94013f5 	ldr	x21, [sp, #32]
    4538:	a8c37bfd 	ldp	x29, x30, [sp], #48
    453c:	d65f03c0 	ret
    4540:	f100001f 	cmp	x0, #0x0
    4544:	b0000041 	adrp	x1, d000 <__modti3+0x30>
    4548:	911c6021 	add	x1, x1, #0x718
    454c:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    4550:	911c0000 	add	x0, x0, #0x700
    4554:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4558:	97fffb8a 	bl	3380 <ad_raw_fail>
    455c:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    4560:	911d6000 	add	x0, x0, #0x758
    4564:	97fffb87 	bl	3380 <ad_raw_fail>
    4568:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    456c:	911ce000 	add	x0, x0, #0x738
    4570:	97fffb84 	bl	3380 <ad_raw_fail>

0000000000004574 <fwp_tape_buffers_release>:
    4574:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4578:	910003fd 	mov	x29, sp
    457c:	a90153f3 	stp	x19, x20, [sp, #16]
    4580:	aa0003f4 	mov	x20, x0
    4584:	f9401400 	ldr	x0, [x0, #40]
    4588:	a9025bf5 	stp	x21, x22, [sp, #32]
    458c:	b7f80560 	tbnz	x0, #63, 4638 <fwp_tape_buffers_release+0xc4>
    4590:	f9401a93 	ldr	x19, [x20, #48]
    4594:	b7f80533 	tbnz	x19, #63, 4638 <fwp_tape_buffers_release+0xc4>
    4598:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    459c:	eb01001f 	cmp	x0, x1
    45a0:	540004c8 	b.hi	4638 <fwp_tape_buffers_release+0xc4>  // b.pmore
    45a4:	8b000400 	add	x0, x0, x0, lsl #1
    45a8:	d2a00101 	mov	x1, #0x80000               	// #524288
    45ac:	d37df000 	lsl	x0, x0, #3
    45b0:	cb000021 	sub	x1, x1, x0
    45b4:	eb410e7f 	cmp	x19, x1, lsr #3
    45b8:	54000408 	b.hi	4638 <fwp_tape_buffers_release+0xc4>  // b.pmore
    45bc:	8b130c13 	add	x19, x0, x19, lsl #3
    45c0:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    45c4:	911dc000 	add	x0, x0, #0x770
    45c8:	97fff91a 	bl	2a30 <getenv@plt>
    45cc:	b4000080 	cbz	x0, 45dc <fwp_tape_buffers_release+0x68>
    45d0:	39400001 	ldrb	w1, [x0]
    45d4:	7100c03f 	cmp	w1, #0x30
    45d8:	54000880 	b.eq	46e8 <fwp_tape_buffers_release+0x174>  // b.none
    45dc:	d1000661 	sub	x1, x19, #0x1
    45e0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    45e4:	eb00003f 	cmp	x1, x0
    45e8:	54000328 	b.hi	464c <fwp_tape_buffers_release+0xd8>  // b.pmore
    45ec:	900000f5 	adrp	x21, 20000 <__data_start>
    45f0:	f9001bf7 	str	x23, [sp, #48]
    45f4:	910142b7 	add	x23, x21, #0x50
    45f8:	910402f6 	add	x22, x23, #0x100
    45fc:	aa1603e0 	mov	x0, x22
    4600:	97ffff95 	bl	4454 <fwp_tape_buffers_dispose>
    4604:	ad400a81 	ldp	q1, q2, [x20]
    4608:	f9009ef3 	str	x19, [x23, #312]
    460c:	4f000400 	movi	v0.4s, #0x0
    4610:	ad000ac1 	stp	q1, q2, [x22]
    4614:	3dc00a81 	ldr	q1, [x20, #32]
    4618:	3d800ac1 	str	q1, [x22, #32]
    461c:	f9401a80 	ldr	x0, [x20, #48]
    4620:	f9001ac0 	str	x0, [x22, #48]
    4624:	f9001a9f 	str	xzr, [x20, #48]
    4628:	ad000280 	stp	q0, q0, [x20]
    462c:	3d800a80 	str	q0, [x20, #32]
    4630:	f9401bf7 	ldr	x23, [sp, #48]
    4634:	1400000b 	b	4660 <fwp_tape_buffers_release+0xec>
    4638:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    463c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4640:	911dc000 	add	x0, x0, #0x770
    4644:	97fff8fb 	bl	2a30 <getenv@plt>
    4648:	b5fffc40 	cbnz	x0, 45d0 <fwp_tape_buffers_release+0x5c>
    464c:	aa1403e0 	mov	x0, x20
    4650:	97ffff81 	bl	4454 <fwp_tape_buffers_dispose>
    4654:	900000f5 	adrp	x21, 20000 <__data_start>
    4658:	910142a0 	add	x0, x21, #0x50
    465c:	f9409c13 	ldr	x19, [x0, #312]
    4660:	910142a2 	add	x2, x21, #0x50
    4664:	f940a044 	ldr	x4, [x2, #320]
    4668:	a9400c45 	ldp	x5, x3, [x2]
    466c:	8b040481 	add	x1, x4, x4, lsl #1
    4670:	f9400840 	ldr	x0, [x2, #16]
    4674:	8b010881 	add	x1, x4, x1, lsl #2
    4678:	f9400c44 	ldr	x4, [x2, #24]
    467c:	8b0300a3 	add	x3, x5, x3
    4680:	d37df021 	lsl	x1, x1, #3
    4684:	8b040000 	add	x0, x0, x4
    4688:	8b030000 	add	x0, x0, x3
    468c:	eb05003f 	cmp	x1, x5
    4690:	54000321 	b.ne	46f4 <fwp_tape_buffers_release+0x180>  // b.any
    4694:	8b130023 	add	x3, x1, x19
    4698:	eb00007f 	cmp	x3, x0
    469c:	540002c8 	b.hi	46f4 <fwp_tape_buffers_release+0x180>  // b.pmore
    46a0:	f9405c43 	ldr	x3, [x2, #184]
    46a4:	f140087f 	cmp	x3, #0x2, lsl #12
    46a8:	540002e0 	b.eq	4704 <fwp_tape_buffers_release+0x190>  // b.none
    46ac:	8b030464 	add	x4, x3, x3, lsl #1
    46b0:	90000165 	adrp	x5, 30000 <alt.9+0xfb90>
    46b4:	9111c0a5 	add	x5, x5, #0x470
    46b8:	cb010000 	sub	x0, x0, x1
    46bc:	d37df084 	lsl	x4, x4, #3
    46c0:	cb130000 	sub	x0, x0, x19
    46c4:	8b0400a6 	add	x6, x5, x4
    46c8:	91000463 	add	x3, x3, #0x1
    46cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46d0:	f82468a1 	str	x1, [x5, x4]
    46d4:	a90080d3 	stp	x19, x0, [x6, #8]
    46d8:	f9005c43 	str	x3, [x2, #184]
    46dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    46e0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    46e4:	d65f03c0 	ret
    46e8:	39400400 	ldrb	w0, [x0, #1]
    46ec:	34fffb00 	cbz	w0, 464c <fwp_tape_buffers_release+0xd8>
    46f0:	17ffffbb 	b	45dc <fwp_tape_buffers_release+0x68>
    46f4:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    46f8:	911e2000 	add	x0, x0, #0x788
    46fc:	f9001bf7 	str	x23, [sp, #48]
    4700:	97fffb20 	bl	3380 <ad_raw_fail>
    4704:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    4708:	911ee000 	add	x0, x0, #0x7b8
    470c:	f9001bf7 	str	x23, [sp, #48]
    4710:	97fffb1c 	bl	3380 <ad_raw_fail>

0000000000004714 <fwp_poll_events>:
    4714:	d10103ff 	sub	sp, sp, #0x40
    4718:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    471c:	f947f400 	ldr	x0, [x0, #4072]
    4720:	a9027bfd 	stp	x29, x30, [sp, #32]
    4724:	910083fd 	add	x29, sp, #0x20
    4728:	a90353f3 	stp	x19, x20, [sp, #48]
    472c:	900000f4 	adrp	x20, 20000 <__data_start>
    4730:	f9400001 	ldr	x1, [x0]
    4734:	f9000fe1 	str	x1, [sp, #24]
    4738:	d2800001 	mov	x1, #0x0                   	// #0
    473c:	97fffc91 	bl	3980 <fwp_now_ns>
    4740:	91014281 	add	x1, x20, #0x50
    4744:	f940a433 	ldr	x19, [x1, #328]
    4748:	b4000e73 	cbz	x19, 4914 <fwp_poll_events+0x200>
    474c:	aa1303e1 	mov	x1, x19
    4750:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4754:	14000005 	b	4768 <fwp_poll_events+0x54>
    4758:	f9408821 	ldr	x1, [x1, #272]
    475c:	eb03005f 	cmp	x2, x3
    4760:	9a83d042 	csel	x2, x2, x3, le
    4764:	b40000c1 	cbz	x1, 477c <fwp_poll_events+0x68>
    4768:	f9403423 	ldr	x3, [x1, #104]
    476c:	b6ffff62 	tbz	x2, #63, 4758 <fwp_poll_events+0x44>
    4770:	f9408821 	ldr	x1, [x1, #272]
    4774:	aa0303e2 	mov	x2, x3
    4778:	b5ffff81 	cbnz	x1, 4768 <fwp_poll_events+0x54>
    477c:	b7f80cc2 	tbnz	x2, #63, 4914 <fwp_poll_events+0x200>
    4780:	cb000042 	sub	x2, x2, x0
    4784:	f100005f 	cmp	x2, #0x0
    4788:	540005ad 	b.le	483c <fwp_poll_events+0x128>
    478c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4790:	d2884801 	mov	x1, #0x4240                	// #16960
    4794:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4798:	f2a001e1 	movk	x1, #0xf, lsl #16
    479c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    47a0:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    47a4:	f2e86360 	movk	x0, #0x431b, lsl #48
    47a8:	9b407c40 	smulh	x0, x2, x0
    47ac:	9352fc00 	asr	x0, x0, #18
    47b0:	cb82fc00 	sub	x0, x0, x2, asr #63
    47b4:	9b018802 	msub	x2, x0, x1, x2
    47b8:	f100005f 	cmp	x2, #0x0
    47bc:	9a800400 	cinc	x0, x0, ne	// ne = any
    47c0:	eb03001f 	cmp	x0, x3
    47c4:	540009ec 	b.gt	4900 <fwp_poll_events+0x1ec>
    47c8:	340003a0 	cbz	w0, 483c <fwp_poll_events+0x128>
    47cc:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    47d0:	52807d04 	mov	w4, #0x3e8                 	// #1000
    47d4:	72a20c42 	movk	w2, #0x1062, lsl #16
    47d8:	9ba27c02 	umull	x2, w0, w2
    47dc:	d366fc43 	lsr	x3, x2, #38
    47e0:	aa0303e2 	mov	x2, x3
    47e4:	1b048063 	msub	w3, w3, w4, w0
    47e8:	9b217c63 	smull	x3, w3, w1
    47ec:	d2800001 	mov	x1, #0x0                   	// #0
    47f0:	910023e0 	add	x0, sp, #0x8
    47f4:	a9008fe2 	stp	x2, x3, [sp, #8]
    47f8:	97fff85e 	bl	2970 <nanosleep@plt>
    47fc:	91014280 	add	x0, x20, #0x50
    4800:	f940a413 	ldr	x19, [x0, #328]
    4804:	97fffc5f 	bl	3980 <fwp_now_ns>
    4808:	aa0003e6 	mov	x6, x0
    480c:	b50001d3 	cbnz	x19, 4844 <fwp_poll_events+0x130>
    4810:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4814:	f947f400 	ldr	x0, [x0, #4072]
    4818:	f9400fe2 	ldr	x2, [sp, #24]
    481c:	f9400001 	ldr	x1, [x0]
    4820:	eb010042 	subs	x2, x2, x1
    4824:	d2800001 	mov	x1, #0x0                   	// #0
    4828:	540008c1 	b.ne	4940 <fwp_poll_events+0x22c>  // b.any
    482c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4830:	a94353f3 	ldp	x19, x20, [sp, #48]
    4834:	910103ff 	add	sp, sp, #0x40
    4838:	d65f03c0 	ret
    483c:	97fffc51 	bl	3980 <fwp_now_ns>
    4840:	aa0003e6 	mov	x6, x0
    4844:	4f000400 	movi	v0.4s, #0x0
    4848:	91014288 	add	x8, x20, #0x50
    484c:	52800027 	mov	w7, #0x1                   	// #1
    4850:	f9403661 	ldr	x1, [x19, #104]
    4854:	aa1303e5 	mov	x5, x19
    4858:	f9408a73 	ldr	x19, [x19, #272]
    485c:	eb06003f 	cmp	x1, x6
    4860:	5400032c 	b.gt	48c4 <fwp_poll_events+0x1b0>
    4864:	394154a0 	ldrb	w0, [x5, #85]
    4868:	36000120 	tbz	w0, #0, 488c <fwp_poll_events+0x178>
    486c:	f94084a0 	ldr	x0, [x5, #264]
    4870:	b40003c0 	cbz	x0, 48e8 <fwp_poll_events+0x1d4>
    4874:	f9008813 	str	x19, [x0, #272]
    4878:	b4000053 	cbz	x19, 4880 <fwp_poll_events+0x16c>
    487c:	f9008660 	str	x0, [x19, #264]
    4880:	910800a0 	add	x0, x5, #0x200
    4884:	390154bf 	strb	wzr, [x5, #85]
    4888:	3c908000 	stur	q0, [x0, #-248]
    488c:	f94030a0 	ldr	x0, [x5, #96]
    4890:	390158a7 	strb	w7, [x5, #86]
    4894:	f100001f 	cmp	x0, #0x0
    4898:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    489c:	5400018d 	b.le	48cc <fwp_poll_events+0x1b8>
    48a0:	f94028a0 	ldr	x0, [x5, #80]
    48a4:	f2001c1f 	tst	x0, #0xff000000ff
    48a8:	540000e1 	b.ne	48c4 <fwp_poll_events+0x1b0>  // b.any
    48ac:	f9406100 	ldr	x0, [x8, #192]
    48b0:	390150a7 	strb	w7, [x5, #84]
    48b4:	f90080bf 	str	xzr, [x5, #256]
    48b8:	b40001e0 	cbz	x0, 48f4 <fwp_poll_events+0x1e0>
    48bc:	f9006105 	str	x5, [x8, #192]
    48c0:	f9008005 	str	x5, [x0, #256]
    48c4:	b5fffc73 	cbnz	x19, 4850 <fwp_poll_events+0x13c>
    48c8:	17ffffd2 	b	4810 <fwp_poll_events+0xfc>
    48cc:	394144a0 	ldrb	w0, [x5, #81]
    48d0:	3707fe80 	tbnz	w0, #0, 48a0 <fwp_poll_events+0x18c>
    48d4:	394140a0 	ldrb	w0, [x5, #80]
    48d8:	3707fe40 	tbnz	w0, #0, 48a0 <fwp_poll_events+0x18c>
    48dc:	aa0503e0 	mov	x0, x5
    48e0:	97fffb84 	bl	36f0 <fwp_cancel_tree.part.0>
    48e4:	17ffffef 	b	48a0 <fwp_poll_events+0x18c>
    48e8:	91014281 	add	x1, x20, #0x50
    48ec:	f900a433 	str	x19, [x1, #328]
    48f0:	17ffffe2 	b	4878 <fwp_poll_events+0x164>
    48f4:	f9006105 	str	x5, [x8, #192]
    48f8:	f9006505 	str	x5, [x8, #200]
    48fc:	17fffff2 	b	48c4 <fwp_poll_events+0x1b0>
    4900:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4904:	d2989362 	mov	x2, #0xc49b                	// #50331
    4908:	f2a4d203 	movk	x3, #0x2690, lsl #16
    490c:	f2a00402 	movk	x2, #0x20, lsl #16
    4910:	17ffffb7 	b	47ec <fwp_poll_events+0xd8>
    4914:	97fff9d8 	bl	3074 <fwp_flush>
    4918:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    491c:	f947e863 	ldr	x3, [x3, #4048]
    4920:	d2800562 	mov	x2, #0x2b                  	// #43
    4924:	d2800021 	mov	x1, #0x1                   	// #1
    4928:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    492c:	911f6000 	add	x0, x0, #0x7d8
    4930:	f9400063 	ldr	x3, [x3]
    4934:	97fff81b 	bl	29a0 <fwrite@plt>
    4938:	52800ca0 	mov	w0, #0x65                  	// #101
    493c:	97fff785 	bl	2750 <exit@plt>
    4940:	97fff7d8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004944 <fwp_rc_wide_dup>:
    4944:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4948:	910003fd 	mov	x29, sp
    494c:	a90153f3 	stp	x19, x20, [sp, #16]
    4950:	aa0003f3 	mov	x19, x0
    4954:	ca404400 	eor	x0, x0, x0, lsr #17
    4958:	f90013f5 	str	x21, [sp, #32]
    495c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xb90>
    4960:	ca402400 	eor	x0, x0, x0, lsr #9
    4964:	911942a2 	add	x2, x21, #0x650
    4968:	92401c00 	and	x0, x0, #0xff
    496c:	910a2403 	add	x3, x0, #0x289
    4970:	8b000c40 	add	x0, x2, x0, lsl #3
    4974:	8b030c54 	add	x20, x2, x3, lsl #3
    4978:	f94a2401 	ldr	x1, [x0, #5192]
    497c:	b50000a1 	cbnz	x1, 4990 <fwp_rc_wide_dup+0x4c>
    4980:	1400002d 	b	4a34 <fwp_rc_wide_dup+0xf0>
    4984:	91004034 	add	x20, x1, #0x10
    4988:	f9400821 	ldr	x1, [x1, #16]
    498c:	b4000241 	cbz	x1, 49d4 <fwp_rc_wide_dup+0x90>
    4990:	f9400022 	ldr	x2, [x1]
    4994:	eb02027f 	cmp	x19, x2
    4998:	54ffff61 	b.ne	4984 <fwp_rc_wide_dup+0x40>  // b.any
    499c:	f9400281 	ldr	x1, [x20]
    49a0:	39400260 	ldrb	w0, [x19]
    49a4:	7103f81f 	cmp	w0, #0xfe
    49a8:	54000220 	b.eq	49ec <fwp_rc_wide_dup+0xa8>  // b.none
    49ac:	b40001a1 	cbz	x1, 49e0 <fwp_rc_wide_dup+0x9c>
    49b0:	f9400420 	ldr	x0, [x1, #8]
    49b4:	b100041f 	cmn	x0, #0x1
    49b8:	540004a0 	b.eq	4a4c <fwp_rc_wide_dup+0x108>  // b.none
    49bc:	91000400 	add	x0, x0, #0x1
    49c0:	f9000420 	str	x0, [x1, #8]
    49c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    49c8:	f94013f5 	ldr	x21, [sp, #32]
    49cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49d0:	d65f03c0 	ret
    49d4:	39400260 	ldrb	w0, [x19]
    49d8:	7103f81f 	cmp	w0, #0xfe
    49dc:	540000a0 	b.eq	49f0 <fwp_rc_wide_dup+0xac>  // b.none
    49e0:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    49e4:	9120c000 	add	x0, x0, #0x830
    49e8:	97fffb86 	bl	3800 <fwp_trap>
    49ec:	b5000281 	cbnz	x1, 4a3c <fwp_rc_wide_dup+0xf8>
    49f0:	d2800300 	mov	x0, #0x18                  	// #24
    49f4:	97fff793 	bl	2840 <malloc@plt>
    49f8:	b4000280 	cbz	x0, 4a48 <fwp_rc_wide_dup+0x104>
    49fc:	d2801fe1 	mov	x1, #0xff                  	// #255
    4a00:	a9000413 	stp	x19, x1, [x0]
    4a04:	911942b5 	add	x21, x21, #0x650
    4a08:	f900081f 	str	xzr, [x0, #16]
    4a0c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4a10:	f9000280 	str	x0, [x20]
    4a14:	39000261 	strb	w1, [x19]
    4a18:	f94e26a0 	ldr	x0, [x21, #7240]
    4a1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a20:	91000400 	add	x0, x0, #0x1
    4a24:	f90e26a0 	str	x0, [x21, #7240]
    4a28:	f94013f5 	ldr	x21, [sp, #32]
    4a2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a30:	d65f03c0 	ret
    4a34:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4a38:	17ffffda 	b	49a0 <fwp_rc_wide_dup+0x5c>
    4a3c:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    4a40:	91202000 	add	x0, x0, #0x808
    4a44:	97fffb6f 	bl	3800 <fwp_trap>
    4a48:	97fff9ca 	bl	3170 <fwp_heap_oom>
    4a4c:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    4a50:	91216000 	add	x0, x0, #0x858
    4a54:	97fffb6b 	bl	3800 <fwp_trap>
    4a58:	d503201f 	nop
    4a5c:	d503201f 	nop

0000000000004a60 <fwp_rc_forget_slot>:
    4a60:	aa0003e1 	mov	x1, x0
    4a64:	39400000 	ldrb	w0, [x0]
    4a68:	7103fc1f 	cmp	w0, #0xff
    4a6c:	54000040 	b.eq	4a74 <fwp_rc_forget_slot+0x14>  // b.none
    4a70:	d65f03c0 	ret
    4a74:	ca414420 	eor	x0, x1, x1, lsr #17
    4a78:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4a7c:	ca402400 	eor	x0, x0, x0, lsr #9
    4a80:	910003fd 	mov	x29, sp
    4a84:	92401c00 	and	x0, x0, #0xff
    4a88:	f9000bf3 	str	x19, [sp, #16]
    4a8c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xb90>
    4a90:	91194262 	add	x2, x19, #0x650
    4a94:	910a2403 	add	x3, x0, #0x289
    4a98:	8b000c40 	add	x0, x2, x0, lsl #3
    4a9c:	8b030c43 	add	x3, x2, x3, lsl #3
    4aa0:	f94a2400 	ldr	x0, [x0, #5192]
    4aa4:	b50000a0 	cbnz	x0, 4ab8 <fwp_rc_forget_slot+0x58>
    4aa8:	14000011 	b	4aec <fwp_rc_forget_slot+0x8c>
    4aac:	91004003 	add	x3, x0, #0x10
    4ab0:	f9400800 	ldr	x0, [x0, #16]
    4ab4:	b40001c0 	cbz	x0, 4aec <fwp_rc_forget_slot+0x8c>
    4ab8:	f9400002 	ldr	x2, [x0]
    4abc:	eb02003f 	cmp	x1, x2
    4ac0:	54ffff61 	b.ne	4aac <fwp_rc_forget_slot+0x4c>  // b.any
    4ac4:	f9400801 	ldr	x1, [x0, #16]
    4ac8:	91194273 	add	x19, x19, #0x650
    4acc:	f9000061 	str	x1, [x3]
    4ad0:	97fff7a4 	bl	2960 <free@plt>
    4ad4:	f94e2660 	ldr	x0, [x19, #7240]
    4ad8:	d1000400 	sub	x0, x0, #0x1
    4adc:	f90e2660 	str	x0, [x19, #7240]
    4ae0:	f9400bf3 	ldr	x19, [sp, #16]
    4ae4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4ae8:	d65f03c0 	ret
    4aec:	b0000040 	adrp	x0, d000 <__modti3+0x30>
    4af0:	9120c000 	add	x0, x0, #0x830
    4af4:	97fffb43 	bl	3800 <fwp_trap>
    4af8:	d503201f 	nop
    4afc:	d503201f 	nop

0000000000004b00 <fwp_rc_prepare_chunk>:
    4b00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4b04:	910003fd 	mov	x29, sp
    4b08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b0c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xb90>
    4b10:	911942c2 	add	x2, x22, #0x650
    4b14:	b9401c03 	ldr	w3, [x0, #28]
    4b18:	aa0103f5 	mov	x21, x1
    4b1c:	a90153f3 	stp	x19, x20, [sp, #16]
    4b20:	aa0003f4 	mov	x20, x0
    4b24:	f94e2440 	ldr	x0, [x2, #7240]
    4b28:	b4000440 	cbz	x0, 4bb0 <fwp_rc_prepare_chunk+0xb0>
    4b2c:	d2800013 	mov	x19, #0x0                   	// #0
    4b30:	35000203 	cbnz	w3, 4b70 <fwp_rc_prepare_chunk+0x70>
    4b34:	b4000361 	cbz	x1, 4ba0 <fwp_rc_prepare_chunk+0xa0>
    4b38:	f9401280 	ldr	x0, [x20, #32]
    4b3c:	97fff789 	bl	2960 <free@plt>
    4b40:	aa1503e0 	mov	x0, x21
    4b44:	d2800021 	mov	x1, #0x1                   	// #1
    4b48:	97fff74e 	bl	2880 <calloc@plt>
    4b4c:	f9001280 	str	x0, [x20, #32]
    4b50:	b5000460 	cbnz	x0, 4bdc <fwp_rc_prepare_chunk+0xdc>
    4b54:	97fff987 	bl	3170 <fwp_heap_oom>
    4b58:	97ffffc2 	bl	4a60 <fwp_rc_forget_slot>
    4b5c:	91000673 	add	x19, x19, #0x1
    4b60:	b9401e83 	ldr	w3, [x20, #28]
    4b64:	eb13007f 	cmp	x3, x19
    4b68:	54000169 	b.ls	4b94 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4b6c:	d503201f 	nop
    4b70:	f9401283 	ldr	x3, [x20, #32]
    4b74:	8b130060 	add	x0, x3, x19
    4b78:	38736863 	ldrb	w3, [x3, x19]
    4b7c:	7103fc7f 	cmp	w3, #0xff
    4b80:	54fffec0 	b.eq	4b58 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b84:	b9401e83 	ldr	w3, [x20, #28]
    4b88:	91000673 	add	x19, x19, #0x1
    4b8c:	eb13007f 	cmp	x3, x19
    4b90:	54ffff08 	b.hi	4b70 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b94:	eb0302bf 	cmp	x21, x3
    4b98:	54000121 	b.ne	4bbc <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b9c:	b5000335 	cbnz	x21, 4c00 <fwp_rc_prepare_chunk+0x100>
    4ba0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bac:	d65f03c0 	ret
    4bb0:	2a0303e3 	mov	w3, w3
    4bb4:	eb0302bf 	cmp	x21, x3
    4bb8:	54ffff20 	b.eq	4b9c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4bbc:	911942c2 	add	x2, x22, #0x650
    4bc0:	f9401280 	ldr	x0, [x20, #32]
    4bc4:	f94e2841 	ldr	x1, [x2, #7248]
    4bc8:	cb030021 	sub	x1, x1, x3
    4bcc:	f90e2841 	str	x1, [x2, #7248]
    4bd0:	97fff764 	bl	2960 <free@plt>
    4bd4:	b5fffb75 	cbnz	x21, 4b40 <fwp_rc_prepare_chunk+0x40>
    4bd8:	f900129f 	str	xzr, [x20, #32]
    4bdc:	911942d6 	add	x22, x22, #0x650
    4be0:	f94e2ac0 	ldr	x0, [x22, #7248]
    4be4:	b9001e95 	str	w21, [x20, #28]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	8b150000 	add	x0, x0, x21
    4bf0:	f90e2ac0 	str	x0, [x22, #7248]
    4bf4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bf8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bfc:	d65f03c0 	ret
    4c00:	f9401280 	ldr	x0, [x20, #32]
    4c04:	aa1503e2 	mov	x2, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	52800001 	mov	w1, #0x0                   	// #0
    4c10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4c18:	17fff716 	b	2870 <memset@plt>
    4c1c:	d503201f 	nop

0000000000004c20 <fwp_heap_refill>:
    4c20:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4c24:	910003fd 	mov	x29, sp
    4c28:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c2c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xb90>
    4c30:	911942b5 	add	x21, x21, #0x650
    4c34:	aa0003f6 	mov	x22, x0
    4c38:	d2800020 	mov	x0, #0x1                   	// #1
    4c3c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c40:	a90363f7 	stp	x23, x24, [sp, #48]
    4c44:	2a0103f7 	mov	w23, w1
    4c48:	2a0203f8 	mov	w24, w2
    4c4c:	97fff959 	bl	31b0 <fwp_heap_chunks>
    4c50:	aa0003f3 	mov	x19, x0
    4c54:	f949fea2 	ldr	x2, [x21, #5112]
    4c58:	8b000800 	add	x0, x0, x0, lsl #2
    4c5c:	2a1703e1 	mov	w1, w23
    4c60:	52800025 	mov	w5, #0x1                   	// #1
    4c64:	d37df000 	lsl	x0, x0, #3
    4c68:	910f0021 	add	x1, x1, #0x3c0
    4c6c:	8b000054 	add	x20, x2, x0
    4c70:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4c74:	52a00024 	mov	w4, #0x10000               	// #65536
    4c78:	38206845 	strb	w5, [x2, x0]
    4c7c:	aa1403e0 	mov	x0, x20
    4c80:	39000698 	strb	w24, [x20, #1]
    4c84:	39000a97 	strb	w23, [x20, #2]
    4c88:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c8c:	b9000681 	str	w1, [x20, #4]
    4c90:	2a0103e5 	mov	w5, w1
    4c94:	8b0300a2 	add	x2, x5, x3
    4c98:	1ac10881 	udiv	w1, w4, w1
    4c9c:	9ac50842 	udiv	x2, x2, x5
    4ca0:	b9000a81 	str	w1, [x20, #8]
    4ca4:	92404021 	and	x1, x1, #0x1ffff
    4ca8:	b9001a82 	str	w2, [x20, #24]
    4cac:	97ffff95 	bl	4b00 <fwp_rc_prepare_chunk>
    4cb0:	f949daa0 	ldr	x0, [x21, #5040]
    4cb4:	29408a81 	ldp	w1, w2, [x20, #4]
    4cb8:	8b134000 	add	x0, x0, x19, lsl #16
    4cbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cc0:	8b214003 	add	x3, x0, w1, uxtw
    4cc4:	9ba20021 	umaddl	x1, w1, w2, x0
    4cc8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ccc:	a90086c3 	stp	x3, x1, [x22, #8]
    4cd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4cd8:	d65f03c0 	ret
    4cdc:	d503201f 	nop

0000000000004ce0 <fwp_mem_free>:
    4ce0:	b40003c0 	cbz	x0, 4d58 <fwp_mem_free+0x78>
    4ce4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4ce8:	910003fd 	mov	x29, sp
    4cec:	a9025bf5 	stp	x21, x22, [sp, #32]
    4cf0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xb90>
    4cf4:	911942a1 	add	x1, x21, #0x650
    4cf8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cfc:	aa0003f3 	mov	x19, x0
    4d00:	f949d823 	ldr	x3, [x1, #5040]
    4d04:	f949ec22 	ldr	x2, [x1, #5080]
    4d08:	cb030000 	sub	x0, x0, x3
    4d0c:	eb02401f 	cmp	x0, x2, lsl #16
    4d10:	540001c2 	b.cs	4d48 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4d14:	d350fc16 	lsr	x22, x0, #16
    4d18:	a90363f7 	stp	x23, x24, [sp, #48]
    4d1c:	f949fc22 	ldr	x2, [x1, #5112]
    4d20:	8b160ad4 	add	x20, x22, x22, lsl #2
    4d24:	d37df294 	lsl	x20, x20, #3
    4d28:	ab140057 	adds	x23, x2, x20
    4d2c:	540000c0 	b.eq	4d44 <fwp_mem_free+0x64>  // b.none
    4d30:	38746842 	ldrb	w2, [x2, x20]
    4d34:	7100045f 	cmp	w2, #0x1
    4d38:	54000120 	b.eq	4d5c <fwp_mem_free+0x7c>  // b.none
    4d3c:	7100085f 	cmp	w2, #0x2
    4d40:	540005e0 	b.eq	4dfc <fwp_mem_free+0x11c>  // b.none
    4d44:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d4c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d50:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d54:	d65f03c0 	ret
    4d58:	d65f03c0 	ret
    4d5c:	f94012f8 	ldr	x24, [x23, #32]
    4d60:	b94006e1 	ldr	w1, [x23, #4]
    4d64:	f90023f9 	str	x25, [sp, #64]
    4d68:	2a0103e2 	mov	w2, w1
    4d6c:	394006f9 	ldrb	w25, [x23, #1]
    4d70:	39400af4 	ldrb	w20, [x23, #2]
    4d74:	b4000158 	cbz	x24, 4d9c <fwp_mem_free+0xbc>
    4d78:	92403e76 	and	x22, x19, #0xffff
    4d7c:	9ac20ad6 	udiv	x22, x22, x2
    4d80:	38766b01 	ldrb	w1, [x24, x22]
    4d84:	8b160300 	add	x0, x24, x22
    4d88:	7103fc3f 	cmp	w1, #0xff
    4d8c:	54000980 	b.eq	4ebc <fwp_mem_free+0x1dc>  // b.none
    4d90:	38366b1f 	strb	wzr, [x24, x22]
    4d94:	b94006e1 	ldr	w1, [x23, #4]
    4d98:	2a0103e2 	mov	w2, w1
    4d9c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4da0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4da4:	cb390000 	sub	x0, x0, w25, uxtb
    4da8:	8b340074 	add	x20, x3, w20, uxtb
    4dac:	911942b5 	add	x21, x21, #0x650
    4db0:	1e630021 	ucvtf	d1, w1
    4db4:	d37ae400 	lsl	x0, x0, #6
    4db8:	8b140c14 	add	x20, x0, x20, lsl #3
    4dbc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dc0:	f8746aa0 	ldr	x0, [x21, x20]
    4dc4:	f94023f9 	ldr	x25, [sp, #64]
    4dc8:	aa2003e0 	mvn	x0, x0
    4dcc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4dd0:	f9000260 	str	x0, [x19]
    4dd4:	f8346ab3 	str	x19, [x21, x20]
    4dd8:	f94a12a0 	ldr	x0, [x21, #5152]
    4ddc:	1e612800 	fadd	d0, d0, d1
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	cb020000 	sub	x0, x0, x2
    4de8:	f90a12a0 	str	x0, [x21, #5152]
    4dec:	fd0a22a0 	str	d0, [x21, #5184]
    4df0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4df8:	d65f03c0 	ret
    4dfc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4e00:	8b000063 	add	x3, x3, x0
    4e04:	eb03027f 	cmp	x19, x3
    4e08:	54fff9e1 	b.ne	4d44 <fwp_mem_free+0x64>  // b.any
    4e0c:	fd400ae1 	ldr	d1, [x23, #16]
    4e10:	fd4a2020 	ldr	d0, [x1, #5184]
    4e14:	f9400ae0 	ldr	x0, [x23, #16]
    4e18:	7e61d821 	ucvtf	d1, d1
    4e1c:	f94a1022 	ldr	x2, [x1, #5152]
    4e20:	f94012f3 	ldr	x19, [x23, #32]
    4e24:	1e612800 	fadd	d0, d0, d1
    4e28:	cb000042 	sub	x2, x2, x0
    4e2c:	f90a1022 	str	x2, [x1, #5152]
    4e30:	fd0a2020 	str	d0, [x1, #5184]
    4e34:	b40000b3 	cbz	x19, 4e48 <fwp_mem_free+0x168>
    4e38:	39400260 	ldrb	w0, [x19]
    4e3c:	7103fc1f 	cmp	w0, #0xff
    4e40:	54000380 	b.eq	4eb0 <fwp_mem_free+0x1d0>  // b.none
    4e44:	3900027f 	strb	wzr, [x19]
    4e48:	b9400ee2 	ldr	w2, [x23, #12]
    4e4c:	b4000142 	cbz	x2, 4e74 <fwp_mem_free+0x194>
    4e50:	911942a1 	add	x1, x21, #0x650
    4e54:	8b160040 	add	x0, x2, x22
    4e58:	8b000800 	add	x0, x0, x0, lsl #2
    4e5c:	f949fc21 	ldr	x1, [x1, #5112]
    4e60:	8b140034 	add	x20, x1, x20
    4e64:	8b000c20 	add	x0, x1, x0, lsl #3
    4e68:	3802869f 	strb	wzr, [x20], #40
    4e6c:	eb00029f 	cmp	x20, x0
    4e70:	54ffffc1 	b.ne	4e68 <fwp_mem_free+0x188>  // b.any
    4e74:	911942a0 	add	x0, x21, #0x650
    4e78:	f94a1801 	ldr	x1, [x0, #5168]
    4e7c:	f949f803 	ldr	x3, [x0, #5104]
    4e80:	8b020021 	add	x1, x1, x2
    4e84:	f90a1801 	str	x1, [x0, #5168]
    4e88:	eb16007f 	cmp	x3, x22
    4e8c:	54000049 	b.ls	4e94 <fwp_mem_free+0x1b4>  // b.plast
    4e90:	f909f816 	str	x22, [x0, #5104]
    4e94:	911942b5 	add	x21, x21, #0x650
    4e98:	f949f6a0 	ldr	x0, [x21, #5096]
    4e9c:	eb16001f 	cmp	x0, x22
    4ea0:	54fff529 	b.ls	4d44 <fwp_mem_free+0x64>  // b.plast
    4ea4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ea8:	f909f6b6 	str	x22, [x21, #5096]
    4eac:	17ffffa7 	b	4d48 <fwp_mem_free+0x68>
    4eb0:	aa1303e0 	mov	x0, x19
    4eb4:	97fffeeb 	bl	4a60 <fwp_rc_forget_slot>
    4eb8:	17ffffe3 	b	4e44 <fwp_mem_free+0x164>
    4ebc:	97fffee9 	bl	4a60 <fwp_rc_forget_slot>
    4ec0:	17ffffb4 	b	4d90 <fwp_mem_free+0xb0>

0000000000004ec4 <fwp_heap_alloc_big>:
    4ec4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4ec8:	910003fd 	mov	x29, sp
    4ecc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ed0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ed4:	a90363f7 	stp	x23, x24, [sp, #48]
    4ed8:	aa0003f7 	mov	x23, x0
    4edc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4ee0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4ee4:	eb0002ff 	cmp	x23, x0
    4ee8:	54000888 	b.hi	4ff8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4eec:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4ef0:	8b0002f4 	add	x20, x23, x0
    4ef4:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xb90>
    4ef8:	91194359 	add	x25, x26, #0x650
    4efc:	d350fe94 	lsr	x20, x20, #16
    4f00:	2a0103f5 	mov	w21, w1
    4f04:	aa1403e0 	mov	x0, x20
    4f08:	97fff8aa 	bl	31b0 <fwp_heap_chunks>
    4f0c:	f949ff22 	ldr	x2, [x25, #5112]
    4f10:	8b000813 	add	x19, x0, x0, lsl #2
    4f14:	aa0003f8 	mov	x24, x0
    4f18:	52800043 	mov	w3, #0x2                   	// #2
    4f1c:	d37df273 	lsl	x19, x19, #3
    4f20:	d2800021 	mov	x1, #0x1                   	// #1
    4f24:	8b130040 	add	x0, x2, x19
    4f28:	38336843 	strb	w3, [x2, x19]
    4f2c:	39000415 	strb	w21, [x0, #1]
    4f30:	b9000c14 	str	w20, [x0, #12]
    4f34:	f9000817 	str	x23, [x0, #16]
    4f38:	97fffef2 	bl	4b00 <fwp_rc_prepare_chunk>
    4f3c:	f100069f 	cmp	x20, #0x1
    4f40:	54000269 	b.ls	4f8c <fwp_heap_alloc_big+0xc8>  // b.plast
    4f44:	8b180294 	add	x20, x20, x24
    4f48:	9100a273 	add	x19, x19, #0x28
    4f4c:	a90573fb 	stp	x27, x28, [sp, #80]
    4f50:	5280007b 	mov	w27, #0x3                   	// #3
    4f54:	8b140a94 	add	x20, x20, x20, lsl #2
    4f58:	2a1803fc 	mov	w28, w24
    4f5c:	9adb2296 	lsl	x22, x20, x27
    4f60:	f949ff35 	ldr	x21, [x25, #5112]
    4f64:	d2800001 	mov	x1, #0x0                   	// #0
    4f68:	8b1302b4 	add	x20, x21, x19
    4f6c:	aa1403e0 	mov	x0, x20
    4f70:	97fffee4 	bl	4b00 <fwp_rc_prepare_chunk>
    4f74:	38336abb 	strb	w27, [x21, x19]
    4f78:	9100a273 	add	x19, x19, #0x28
    4f7c:	b9000e9c 	str	w28, [x20, #12]
    4f80:	eb1302df 	cmp	x22, x19
    4f84:	54fffee1 	b.ne	4f60 <fwp_heap_alloc_big+0x9c>  // b.any
    4f88:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f8c:	91194353 	add	x19, x26, #0x650
    4f90:	aa1703e2 	mov	x2, x23
    4f94:	52800001 	mov	w1, #0x0                   	// #0
    4f98:	f949da60 	ldr	x0, [x19, #5040]
    4f9c:	8b184018 	add	x24, x0, x24, lsl #16
    4fa0:	aa1803e0 	mov	x0, x24
    4fa4:	97fff633 	bl	2870 <memset@plt>
    4fa8:	f94a1260 	ldr	x0, [x19, #5152]
    4fac:	ab170000 	adds	x0, x0, x23
    4fb0:	54000242 	b.cs	4ff8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4fb4:	f94a1661 	ldr	x1, [x19, #5160]
    4fb8:	f90a1260 	str	x0, [x19, #5152]
    4fbc:	eb01001f 	cmp	x0, x1
    4fc0:	54000049 	b.ls	4fc8 <fwp_heap_alloc_big+0x104>  // b.plast
    4fc4:	f90a1660 	str	x0, [x19, #5160]
    4fc8:	9119435a 	add	x26, x26, #0x650
    4fcc:	9e6202e0 	scvtf	d0, x23
    4fd0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fd4:	aa1803e0 	mov	x0, x24
    4fd8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4fdc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fe0:	1e602820 	fadd	d0, d1, d0
    4fe4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4fe8:	fd0a1f40 	str	d0, [x26, #5176]
    4fec:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ff0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4ff4:	d65f03c0 	ret
    4ff8:	a90573fb 	stp	x27, x28, [sp, #80]
    4ffc:	97fff85d 	bl	3170 <fwp_heap_oom>

0000000000005000 <fwp_heap_alloc_slow>:
    5000:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5004:	910003fd 	mov	x29, sp
    5008:	a90153f3 	stp	x19, x20, [sp, #16]
    500c:	900003b3 	adrp	x19, 79000 <fwp_root_context+0xb90>
    5010:	91194262 	add	x2, x19, #0x650
    5014:	a9025bf5 	stp	x21, x22, [sp, #32]
    5018:	aa0003f5 	mov	x21, x0
    501c:	2a0103f4 	mov	w20, w1
    5020:	b953a440 	ldr	w0, [x2, #5028]
    5024:	34000600 	cbz	w0, 50e4 <fwp_heap_alloc_slow+0xe4>
    5028:	f14012bf 	cmp	x21, #0x4, lsl #12
    502c:	54000628 	b.hi	50f0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    5030:	91003ea0 	add	x0, x21, #0xf
    5034:	91194262 	add	x2, x19, #0x650
    5038:	f9001bf7 	str	x23, [sp, #48]
    503c:	937c7e84 	sbfiz	x4, x20, #4, #32
    5040:	8b401040 	add	x0, x2, x0, lsr #4
    5044:	cb34c084 	sub	x4, x4, w20, sxtw
    5048:	d37ae484 	lsl	x4, x4, #6
    504c:	397e8003 	ldrb	w3, [x0, #4000]
    5050:	910f0060 	add	x0, x3, #0x3c0
    5054:	aa0303e1 	mov	x1, x3
    5058:	8b030463 	add	x3, x3, x3, lsl #1
    505c:	8b030c83 	add	x3, x4, x3, lsl #3
    5060:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5064:	2a1703f6 	mov	w22, w23
    5068:	f8636844 	ldr	x4, [x2, x3]
    506c:	b40004e4 	cbz	x4, 5108 <fwp_heap_alloc_slow+0x108>
    5070:	f9400080 	ldr	x0, [x4]
    5074:	aa2003e0 	mvn	x0, x0
    5078:	f8236840 	str	x0, [x2, x3]
    507c:	7100069f 	cmp	w20, #0x1
    5080:	aa0403e0 	mov	x0, x4
    5084:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5088:	52800001 	mov	w1, #0x0                   	// #0
    508c:	97fff5f9 	bl	2870 <memset@plt>
    5090:	aa0003e4 	mov	x4, x0
    5094:	91194260 	add	x0, x19, #0x650
    5098:	f94a1001 	ldr	x1, [x0, #5152]
    509c:	ab160021 	adds	x1, x1, x22
    50a0:	540005c2 	b.cs	5158 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    50a4:	f94a1402 	ldr	x2, [x0, #5160]
    50a8:	f90a1001 	str	x1, [x0, #5152]
    50ac:	eb02003f 	cmp	x1, x2
    50b0:	54000049 	b.ls	50b8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    50b4:	f90a1401 	str	x1, [x0, #5160]
    50b8:	91194273 	add	x19, x19, #0x650
    50bc:	1e6302e1 	ucvtf	d1, w23
    50c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50c4:	aa0403e0 	mov	x0, x4
    50c8:	fd4a1e60 	ldr	d0, [x19, #5176]
    50cc:	f9401bf7 	ldr	x23, [sp, #48]
    50d0:	1e612800 	fadd	d0, d0, d1
    50d4:	fd0a1e60 	str	d0, [x19, #5176]
    50d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50dc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50e0:	d65f03c0 	ret
    50e4:	97fffc08 	bl	4104 <fwp_heap_init>
    50e8:	f14012bf 	cmp	x21, #0x4, lsl #12
    50ec:	54fffa29 	b.ls	5030 <fwp_heap_alloc_slow+0x30>  // b.plast
    50f0:	2a1403e1 	mov	w1, w20
    50f4:	aa1503e0 	mov	x0, x21
    50f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5100:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5104:	17ffff70 	b	4ec4 <fwp_heap_alloc_big>
    5108:	8b030042 	add	x2, x2, x3
    510c:	f9400444 	ldr	x4, [x2, #8]
    5110:	b4000104 	cbz	x4, 5130 <fwp_heap_alloc_slow+0x130>
    5114:	f9400840 	ldr	x0, [x2, #16]
    5118:	cb040000 	sub	x0, x0, x4
    511c:	eb16001f 	cmp	x0, x22
    5120:	54000083 	b.cc	5130 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5124:	8b160080 	add	x0, x4, x22
    5128:	f9000440 	str	x0, [x2, #8]
    512c:	17ffffd4 	b	507c <fwp_heap_alloc_slow+0x7c>
    5130:	52800302 	mov	w2, #0x18                  	// #24
    5134:	52807804 	mov	w4, #0x3c0                 	// #960
    5138:	91194260 	add	x0, x19, #0x650
    513c:	9ba27c23 	umull	x3, w1, w2
    5140:	2a1403e2 	mov	w2, w20
    5144:	9b240e84 	smaddl	x4, w20, w4, x3
    5148:	8b040000 	add	x0, x0, x4
    514c:	97fffeb5 	bl	4c20 <fwp_heap_refill>
    5150:	aa0003e4 	mov	x4, x0
    5154:	17ffffca 	b	507c <fwp_heap_alloc_slow+0x7c>
    5158:	97fff806 	bl	3170 <fwp_heap_oom>
    515c:	d503201f 	nop

0000000000005160 <fwp_heap_alloc>:
    5160:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5164:	910003fd 	mov	x29, sp
    5168:	a9025bf5 	stp	x21, x22, [sp, #32]
    516c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5170:	910142c2 	add	x2, x22, #0x50
    5174:	a90363f7 	stp	x23, x24, [sp, #48]
    5178:	b9415058 	ldr	w24, [x2, #336]
    517c:	a90153f3 	stp	x19, x20, [sp, #16]
    5180:	7100031f 	cmp	w24, #0x0
    5184:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5188:	54000861 	b.ne	5294 <fwp_heap_alloc+0x134>  // b.any
    518c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xb90>
    5190:	911942f3 	add	x19, x23, #0x650
    5194:	f140101f 	cmp	x0, #0x4, lsl #12
    5198:	b953a662 	ldr	w2, [x19, #5028]
    519c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    51a0:	54000740 	b.eq	5288 <fwp_heap_alloc+0x128>  // b.none
    51a4:	91003c03 	add	x3, x0, #0xf
    51a8:	937c7c22 	sbfiz	x2, x1, #4, #32
    51ac:	cb21c042 	sub	x2, x2, w1, sxtw
    51b0:	8b431263 	add	x3, x19, x3, lsr #4
    51b4:	d37ae442 	lsl	x2, x2, #6
    51b8:	397e8063 	ldrb	w3, [x3, #4000]
    51bc:	910f0064 	add	x4, x3, #0x3c0
    51c0:	8b030463 	add	x3, x3, x3, lsl #1
    51c4:	8b030c43 	add	x3, x2, x3, lsl #3
    51c8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    51cc:	2a1503f4 	mov	w20, w21
    51d0:	f8636a64 	ldr	x4, [x19, x3]
    51d4:	b40004c4 	cbz	x4, 526c <fwp_heap_alloc+0x10c>
    51d8:	f9400085 	ldr	x5, [x4]
    51dc:	7100043f 	cmp	w1, #0x1
    51e0:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    51e4:	aa0403e0 	mov	x0, x4
    51e8:	aa2503e5 	mvn	x5, x5
    51ec:	52800001 	mov	w1, #0x0                   	// #0
    51f0:	f8236a65 	str	x5, [x19, x3]
    51f4:	97fff59f 	bl	2870 <memset@plt>
    51f8:	aa0003e4 	mov	x4, x0
    51fc:	f94a1260 	ldr	x0, [x19, #5152]
    5200:	ab140000 	adds	x0, x0, x20
    5204:	540006e2 	b.cs	52e0 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5208:	f94a1661 	ldr	x1, [x19, #5160]
    520c:	f90a1260 	str	x0, [x19, #5152]
    5210:	eb01001f 	cmp	x0, x1
    5214:	54000049 	b.ls	521c <fwp_heap_alloc+0xbc>  // b.plast
    5218:	f90a1660 	str	x0, [x19, #5160]
    521c:	911942e0 	add	x0, x23, #0x650
    5220:	1e6302a1 	ucvtf	d1, w21
    5224:	fd4a1c00 	ldr	d0, [x0, #5176]
    5228:	1e612800 	fadd	d0, d0, d1
    522c:	fd0a1c00 	str	d0, [x0, #5176]
    5230:	34000138 	cbz	w24, 5254 <fwp_heap_alloc+0xf4>
    5234:	911942e1 	add	x1, x23, #0x650
    5238:	910142c0 	add	x0, x22, #0x50
    523c:	fd4a1020 	ldr	d0, [x1, #5152]
    5240:	6d568402 	ldp	d2, d1, [x0, #360]
    5244:	7e61d800 	ucvtf	d0, d0
    5248:	1e623800 	fsub	d0, d0, d2
    524c:	1e612010 	fcmpe	d0, d1
    5250:	540002cc 	b.gt	52a8 <fwp_heap_alloc+0x148>
    5254:	a94153f3 	ldp	x19, x20, [sp, #16]
    5258:	aa0403e0 	mov	x0, x4
    525c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5260:	a94363f7 	ldp	x23, x24, [sp, #48]
    5264:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5268:	d65f03c0 	ret
    526c:	8b030263 	add	x3, x19, x3
    5270:	f9400464 	ldr	x4, [x3, #8]
    5274:	b40000a4 	cbz	x4, 5288 <fwp_heap_alloc+0x128>
    5278:	f9400862 	ldr	x2, [x3, #16]
    527c:	cb040042 	sub	x2, x2, x4
    5280:	eb02029f 	cmp	x20, x2
    5284:	54000209 	b.ls	52c4 <fwp_heap_alloc+0x164>  // b.plast
    5288:	97ffff5e 	bl	5000 <fwp_heap_alloc_slow>
    528c:	aa0003e4 	mov	x4, x0
    5290:	17ffffe8 	b	5230 <fwp_heap_alloc+0xd0>
    5294:	a9558c44 	ldp	x4, x3, [x2, #344]
    5298:	91000484 	add	x4, x4, #0x1
    529c:	8b000063 	add	x3, x3, x0
    52a0:	a9158c44 	stp	x4, x3, [x2, #344]
    52a4:	17ffffba 	b	518c <fwp_heap_alloc+0x2c>
    52a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    52ac:	fd00b800 	str	d0, [x0, #368]
    52b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52b4:	aa0403e0 	mov	x0, x4
    52b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    52bc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    52c0:	d65f03c0 	ret
    52c4:	7100043f 	cmp	w1, #0x1
    52c8:	8b140085 	add	x5, x4, x20
    52cc:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    52d0:	52800001 	mov	w1, #0x0                   	// #0
    52d4:	aa0403e0 	mov	x0, x4
    52d8:	f9000465 	str	x5, [x3, #8]
    52dc:	17ffffc6 	b	51f4 <fwp_heap_alloc+0x94>
    52e0:	97fff7a4 	bl	3170 <fwp_heap_oom>

00000000000052e4 <fwp_data.part.0.constprop.0>:
    52e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    52e8:	910003fd 	mov	x29, sp
    52ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    52f0:	f00000d6 	adrp	x22, 20000 <__data_start>
    52f4:	910142c2 	add	x2, x22, #0x50
    52f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52fc:	b9415059 	ldr	w25, [x2, #336]
    5300:	a90153f3 	stp	x19, x20, [sp, #16]
    5304:	aa0103f4 	mov	x20, x1
    5308:	a90363f7 	stp	x23, x24, [sp, #48]
    530c:	2a0003f7 	mov	w23, w0
    5310:	340000b9 	cbz	w25, 5324 <fwp_data.part.0.constprop.0+0x40>
    5314:	a9558041 	ldp	x1, x0, [x2, #344]
    5318:	91000421 	add	x1, x1, #0x1
    531c:	91006000 	add	x0, x0, #0x18
    5320:	a9158041 	stp	x1, x0, [x2, #344]
    5324:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xb90>
    5328:	911942a3 	add	x3, x21, #0x650
    532c:	b953a460 	ldr	w0, [x3, #5028]
    5330:	34000840 	cbz	w0, 5438 <fwp_data.part.0.constprop.0+0x154>
    5334:	397e8862 	ldrb	w2, [x3, #4002]
    5338:	910f0040 	add	x0, x2, #0x3c0
    533c:	8b020442 	add	x2, x2, x2, lsl #1
    5340:	d37df042 	lsl	x2, x2, #3
    5344:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5348:	2a1a03f8 	mov	w24, w26
    534c:	f8626873 	ldr	x19, [x3, x2]
    5350:	b4000613 	cbz	x19, 5410 <fwp_data.part.0.constprop.0+0x12c>
    5354:	f9400260 	ldr	x0, [x19]
    5358:	aa2003e0 	mvn	x0, x0
    535c:	f8226860 	str	x0, [x3, x2]
    5360:	f100631f 	cmp	x24, #0x18
    5364:	540000e9 	b.ls	5380 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5368:	d1006702 	sub	x2, x24, #0x19
    536c:	91006260 	add	x0, x19, #0x18
    5370:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5374:	52800001 	mov	w1, #0x0                   	// #0
    5378:	91002042 	add	x2, x2, #0x8
    537c:	97fff53d 	bl	2870 <memset@plt>
    5380:	911942a0 	add	x0, x21, #0x650
    5384:	f94a1001 	ldr	x1, [x0, #5152]
    5388:	ab180021 	adds	x1, x1, x24
    538c:	54000642 	b.cs	5454 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5390:	f94a1402 	ldr	x2, [x0, #5160]
    5394:	f90a1001 	str	x1, [x0, #5152]
    5398:	eb02003f 	cmp	x1, x2
    539c:	54000049 	b.ls	53a4 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    53a0:	f90a1401 	str	x1, [x0, #5160]
    53a4:	911942a0 	add	x0, x21, #0x650
    53a8:	1e630341 	ucvtf	d1, w26
    53ac:	fd4a1c00 	ldr	d0, [x0, #5176]
    53b0:	1e612800 	fadd	d0, d0, d1
    53b4:	fd0a1c00 	str	d0, [x0, #5176]
    53b8:	34000139 	cbz	w25, 53dc <fwp_data.part.0.constprop.0+0xf8>
    53bc:	911942b5 	add	x21, x21, #0x650
    53c0:	910142d6 	add	x22, x22, #0x50
    53c4:	fd4a12a0 	ldr	d0, [x21, #5152]
    53c8:	6d5686c2 	ldp	d2, d1, [x22, #360]
    53cc:	7e61d800 	ucvtf	d0, d0
    53d0:	1e623800 	fsub	d0, d0, d2
    53d4:	1e612010 	fcmpe	d0, d1
    53d8:	540003ac 	b.gt	544c <fwp_data.part.0.constprop.0+0x168>
    53dc:	52800040 	mov	w0, #0x2                   	// #2
    53e0:	29000277 	stp	w23, w0, [x19]
    53e4:	aa1303e0 	mov	x0, x19
    53e8:	f9400281 	ldr	x1, [x20]
    53ec:	f9000661 	str	x1, [x19, #8]
    53f0:	f9400681 	ldr	x1, [x20, #8]
    53f4:	f9000a61 	str	x1, [x19, #16]
    53f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    53fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5400:	a94363f7 	ldp	x23, x24, [sp, #48]
    5404:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5408:	a8c57bfd 	ldp	x29, x30, [sp], #80
    540c:	d65f03c0 	ret
    5410:	8b020063 	add	x3, x3, x2
    5414:	f9400473 	ldr	x19, [x3, #8]
    5418:	b4000113 	cbz	x19, 5438 <fwp_data.part.0.constprop.0+0x154>
    541c:	f9400860 	ldr	x0, [x3, #16]
    5420:	cb130000 	sub	x0, x0, x19
    5424:	eb00031f 	cmp	x24, x0
    5428:	54000088 	b.hi	5438 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    542c:	8b180260 	add	x0, x19, x24
    5430:	f9000460 	str	x0, [x3, #8]
    5434:	17ffffcb 	b	5360 <fwp_data.part.0.constprop.0+0x7c>
    5438:	52800001 	mov	w1, #0x0                   	// #0
    543c:	d2800300 	mov	x0, #0x18                  	// #24
    5440:	97ffff48 	bl	5160 <fwp_heap_alloc>
    5444:	aa0003f3 	mov	x19, x0
    5448:	17ffffdc 	b	53b8 <fwp_data.part.0.constprop.0+0xd4>
    544c:	fd00bac0 	str	d0, [x22, #368]
    5450:	17ffffe3 	b	53dc <fwp_data.part.0.constprop.0+0xf8>
    5454:	97fff747 	bl	3170 <fwp_heap_oom>
    5458:	d503201f 	nop
    545c:	d503201f 	nop

0000000000005460 <fwp_p_ad_push>:
    5460:	f100001f 	cmp	x0, #0x0
    5464:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    5468:	54000eab 	b.lt	563c <fwp_p_ad_push+0x1dc>  // b.tstop
    546c:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5470:	aa0003e4 	mov	x4, x0
    5474:	910003fd 	mov	x29, sp
    5478:	a9025bf5 	stp	x21, x22, [sp, #32]
    547c:	aa0003f5 	mov	x21, x0
    5480:	aa020000 	orr	x0, x0, x2
    5484:	a90363f7 	stp	x23, x24, [sp, #48]
    5488:	aa0203f7 	mov	x23, x2
    548c:	6d0627e8 	stp	d8, d9, [sp, #96]
    5490:	9e670029 	fmov	d9, x1
    5494:	9e670068 	fmov	d8, x3
    5498:	b6f80920 	tbz	x0, #63, 55bc <fwp_p_ad_push+0x15c>
    549c:	a90153f3 	stp	x19, x20, [sp, #16]
    54a0:	9360fc80 	asr	x0, x4, #32
    54a4:	b6f800c4 	tbz	x4, #63, 54bc <fwp_p_ad_push+0x5c>
    54a8:	1e604109 	fmov	d9, d8
    54ac:	2f00e408 	movi	d8, #0x0
    54b0:	9360fc40 	asr	x0, x2, #32
    54b4:	aa0203f5 	mov	x21, x2
    54b8:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    54bc:	97fff99d 	bl	3b30 <fwp_tape_of>
    54c0:	aa0003f3 	mov	x19, x0
    54c4:	f9403000 	ldr	x0, [x0, #96]
    54c8:	b5001240 	cbnz	x0, 5710 <fwp_p_ad_push+0x2b0>
    54cc:	f9400a76 	ldr	x22, [x19, #16]
    54d0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54d4:	eb0002df 	cmp	x22, x0
    54d8:	54000d8c 	b.gt	5688 <fwp_p_ad_push+0x228>
    54dc:	eb3542df 	cmp	x22, w21, uxtw
    54e0:	54000cad 	b.le	5674 <fwp_p_ad_push+0x214>
    54e4:	b7f80077 	tbnz	x23, #63, 54f0 <fwp_p_ad_push+0x90>
    54e8:	eb3742df 	cmp	x22, w23, uxtw
    54ec:	54000c4d 	b.le	5674 <fwp_p_ad_push+0x214>
    54f0:	f9400678 	ldr	x24, [x19, #8]
    54f4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54f8:	cb1802d8 	sub	x24, x22, x24
    54fc:	91000701 	add	x1, x24, #0x1
    5500:	eb00003f 	cmp	x1, x0
    5504:	54000c28 	b.hi	5688 <fwp_p_ad_push+0x228>  // b.pmore
    5508:	a9418274 	ldp	x20, x0, [x19, #24]
    550c:	a90573fb 	stp	x27, x28, [sp, #80]
    5510:	eb14003f 	cmp	x1, x20
    5514:	540006ad 	b.le	55e8 <fwp_p_ad_push+0x188>
    5518:	f100029f 	cmp	x20, #0x0
    551c:	d2800803 	mov	x3, #0x40                  	// #64
    5520:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5524:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5528:	a9046bf9 	stp	x25, x26, [sp, #64]
    552c:	eb14003f 	cmp	x1, x20
    5530:	5400008d 	b.le	5540 <fwp_p_ad_push+0xe0>
    5534:	eb02029f 	cmp	x20, x2
    5538:	5400054d 	b.le	55e0 <fwp_p_ad_push+0x180>
    553c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5540:	d37df299 	lsl	x25, x20, #3
    5544:	52800022 	mov	w2, #0x1                   	// #1
    5548:	aa1903e1 	mov	x1, x25
    554c:	97fffbd6 	bl	44a4 <ad_raw_realloc>
    5550:	aa0003e1 	mov	x1, x0
    5554:	b4000a40 	cbz	x0, 569c <fwp_p_ad_push+0x23c>
    5558:	f9400e63 	ldr	x3, [x19, #24]
    555c:	f9001261 	str	x1, [x19, #32]
    5560:	f9401a60 	ldr	x0, [x19, #48]
    5564:	52800042 	mov	w2, #0x2                   	// #2
    5568:	8b030821 	add	x1, x1, x3, lsl #2
    556c:	f9001661 	str	x1, [x19, #40]
    5570:	d37cee81 	lsl	x1, x20, #4
    5574:	97fffbcc 	bl	44a4 <ad_raw_realloc>
    5578:	aa0003e2 	mov	x2, x0
    557c:	b4000900 	cbz	x0, 569c <fwp_p_ad_push+0x23c>
    5580:	f9400e61 	ldr	x1, [x19, #24]
    5584:	d37df31b 	lsl	x27, x24, #3
    5588:	d37ef69a 	lsl	x26, x20, #2
    558c:	d37ef71c 	lsl	x28, x24, #2
    5590:	8b190003 	add	x3, x0, x25
    5594:	8b010c01 	add	x1, x0, x1, lsl #3
    5598:	a9030660 	stp	x0, x1, [x19, #48]
    559c:	b5000558 	cbnz	x24, 5644 <fwp_p_ad_push+0x1e4>
    55a0:	f9001e63 	str	x3, [x19, #56]
    55a4:	f9401260 	ldr	x0, [x19, #32]
    55a8:	8b1a0001 	add	x1, x0, x26
    55ac:	a9446bf9 	ldp	x25, x26, [sp, #64]
    55b0:	f9000e74 	str	x20, [x19, #24]
    55b4:	f9001661 	str	x1, [x19, #40]
    55b8:	14000010 	b	55f8 <fwp_p_ad_push+0x198>
    55bc:	9360fc40 	asr	x0, x2, #32
    55c0:	a90153f3 	stp	x19, x20, [sp, #16]
    55c4:	eb84801f 	cmp	x0, x4, asr #32
    55c8:	54fff7a0 	b.eq	54bc <fwp_p_ad_push+0x5c>  // b.none
    55cc:	90000040 	adrp	x0, d000 <__modti3+0x30>
    55d0:	9121e000 	add	x0, x0, #0x878
    55d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    55d8:	a90573fb 	stp	x27, x28, [sp, #80]
    55dc:	97fff889 	bl	3800 <fwp_trap>
    55e0:	d37ffa94 	lsl	x20, x20, #1
    55e4:	17ffffd2 	b	552c <fwp_p_ad_push+0xcc>
    55e8:	a9428a61 	ldp	x1, x2, [x19, #40]
    55ec:	d37ef71c 	lsl	x28, x24, #2
    55f0:	f9401e63 	ldr	x3, [x19, #56]
    55f4:	d37df31b 	lsl	x27, x24, #3
    55f8:	b83c6815 	str	w21, [x0, x28]
    55fc:	f10002ff 	cmp	x23, #0x0
    5600:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5604:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5608:	fc3b6849 	str	d9, [x2, x27]
    560c:	aa1602a0 	orr	x0, x21, x22
    5610:	b83c6837 	str	w23, [x1, x28]
    5614:	910006d6 	add	x22, x22, #0x1
    5618:	a94363f7 	ldp	x23, x24, [sp, #48]
    561c:	fc3b6868 	str	d8, [x3, x27]
    5620:	a94573fb 	ldp	x27, x28, [sp, #80]
    5624:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5628:	f9000a76 	str	x22, [x19, #16]
    562c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5630:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5634:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5638:	d65f03c0 	ret
    563c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5640:	d65f03c0 	ret
    5644:	aa0303e0 	mov	x0, x3
    5648:	aa1b03e2 	mov	x2, x27
    564c:	97fff431 	bl	2710 <memmove@plt>
    5650:	a9420660 	ldp	x0, x1, [x19, #32]
    5654:	aa1c03e2 	mov	x2, x28
    5658:	f9401a63 	ldr	x3, [x19, #48]
    565c:	8b190063 	add	x3, x3, x25
    5660:	f9001e63 	str	x3, [x19, #56]
    5664:	8b1a0000 	add	x0, x0, x26
    5668:	97fff42a 	bl	2710 <memmove@plt>
    566c:	a9430e62 	ldp	x2, x3, [x19, #48]
    5670:	17ffffcd 	b	55a4 <fwp_p_ad_push+0x144>
    5674:	90000040 	adrp	x0, d000 <__modti3+0x30>
    5678:	91244000 	add	x0, x0, #0x910
    567c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5680:	a90573fb 	stp	x27, x28, [sp, #80]
    5684:	97fff85f 	bl	3800 <fwp_trap>
    5688:	90000040 	adrp	x0, d000 <__modti3+0x30>
    568c:	9123c000 	add	x0, x0, #0x8f0
    5690:	a9046bf9 	stp	x25, x26, [sp, #64]
    5694:	a90573fb 	stp	x27, x28, [sp, #80]
    5698:	97fff85a 	bl	3800 <fwp_trap>
    569c:	aa1303e0 	mov	x0, x19
    56a0:	97fff65d 	bl	3014 <fwp_tape_unlink_scope>
    56a4:	f9401260 	ldr	x0, [x19, #32]
    56a8:	b4000040 	cbz	x0, 56b0 <fwp_p_ad_push+0x250>
    56ac:	97fffb49 	bl	43d0 <ad_raw_free.part.0>
    56b0:	f9401a60 	ldr	x0, [x19, #48]
    56b4:	b4000040 	cbz	x0, 56bc <fwp_p_ad_push+0x25c>
    56b8:	97fffb46 	bl	43d0 <ad_raw_free.part.0>
    56bc:	f9402260 	ldr	x0, [x19, #64]
    56c0:	b4000040 	cbz	x0, 56c8 <fwp_p_ad_push+0x268>
    56c4:	97fffb43 	bl	43d0 <ad_raw_free.part.0>
    56c8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    56cc:	f947e821 	ldr	x1, [x1, #4048]
    56d0:	f9000e7f 	str	xzr, [x19, #24]
    56d4:	4f000400 	movi	v0.4s, #0x0
    56d8:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    56dc:	d2800262 	mov	x2, #0x13                  	// #19
    56e0:	f9400023 	ldr	x3, [x1]
    56e4:	b900067f 	str	wzr, [x19, #4]
    56e8:	d2800021 	mov	x1, #0x1                   	// #1
    56ec:	90000040 	adrp	x0, d000 <__modti3+0x30>
    56f0:	910de000 	add	x0, x0, #0x378
    56f4:	3c808260 	stur	q0, [x19, #8]
    56f8:	ad010260 	stp	q0, q0, [x19, #32]
    56fc:	97fff4a9 	bl	29a0 <fwrite@plt>
    5700:	d2800000 	mov	x0, #0x0                   	// #0
    5704:	97fff4b3 	bl	29d0 <fflush@plt>
    5708:	52800cc0 	mov	w0, #0x66                  	// #102
    570c:	97fff4c1 	bl	2a10 <_Exit@plt>
    5710:	90000040 	adrp	x0, d000 <__modti3+0x30>
    5714:	91230000 	add	x0, x0, #0x8c0
    5718:	a9046bf9 	stp	x25, x26, [sp, #64]
    571c:	a90573fb 	stp	x27, x28, [sp, #80]
    5720:	97fff838 	bl	3800 <fwp_trap>

0000000000005724 <w120>:
    5724:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5728:	9e660003 	fmov	x3, d0
    572c:	aa0003e2 	mov	x2, x0
    5730:	910003fd 	mov	x29, sp
    5734:	fd001fea 	str	d10, [sp, #56]
    5738:	1e60400a 	fmov	d10, d0
    573c:	6d0427e8 	stp	d8, d9, [sp, #64]
    5740:	1e604028 	fmov	d8, d1
    5744:	1e600809 	fmul	d9, d0, d0
    5748:	a90153f3 	stp	x19, x20, [sp, #16]
    574c:	aa0103f4 	mov	x20, x1
    5750:	aa0303e1 	mov	x1, x3
    5754:	aa0003f3 	mov	x19, x0
    5758:	a9025bf5 	stp	x21, x22, [sp, #32]
    575c:	f9001bf7 	str	x23, [sp, #48]
    5760:	97ffff40 	bl	5460 <fwp_p_ad_push>
    5764:	aa0003e5 	mov	x5, x0
    5768:	97fffad7 	bl	42c4 <caf75>
    576c:	9e670000 	fmov	d0, x0
    5770:	97fffad5 	bl	42c4 <caf75>
    5774:	1e693908 	fsub	d8, d8, d9
    5778:	aa1403e2 	mov	x2, x20
    577c:	1e614000 	fneg	d0, d0
    5780:	aa0003e3 	mov	x3, x0
    5784:	aa0503e0 	mov	x0, x5
    5788:	9e660117 	fmov	x23, d8
    578c:	9e660001 	fmov	x1, d0
    5790:	97ffff34 	bl	5460 <fwp_p_ad_push>
    5794:	aa0003f5 	mov	x21, x0
    5798:	97fffacb 	bl	42c4 <caf75>
    579c:	9e670000 	fmov	d0, x0
    57a0:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    57a4:	97fffac8 	bl	42c4 <caf75>
    57a8:	1e614000 	fneg	d0, d0
    57ac:	aa0003e3 	mov	x3, x0
    57b0:	1e6a3929 	fsub	d9, d9, d10
    57b4:	aa1303e0 	mov	x0, x19
    57b8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    57bc:	9e660001 	fmov	x1, d0
    57c0:	9e660136 	fmov	x22, d9
    57c4:	97ffff27 	bl	5460 <fwp_p_ad_push>
    57c8:	1e680908 	fmul	d8, d8, d8
    57cc:	aa0003f4 	mov	x20, x0
    57d0:	aa1703e3 	mov	x3, x23
    57d4:	aa1703e1 	mov	x1, x23
    57d8:	aa1503e2 	mov	x2, x21
    57dc:	aa1503e0 	mov	x0, x21
    57e0:	97ffff20 	bl	5460 <fwp_p_ad_push>
    57e4:	aa0003e2 	mov	x2, x0
    57e8:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    57ec:	9e670020 	fmov	d0, x1
    57f0:	9e660101 	fmov	x1, d8
    57f4:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    57f8:	1e600908 	fmul	d8, d8, d0
    57fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5800:	97ffff18 	bl	5460 <fwp_p_ad_push>
    5804:	1e690929 	fmul	d9, d9, d9
    5808:	aa1603e3 	mov	x3, x22
    580c:	aa1603e1 	mov	x1, x22
    5810:	aa1403e2 	mov	x2, x20
    5814:	aa0003f3 	mov	x19, x0
    5818:	aa1403e0 	mov	x0, x20
    581c:	97ffff11 	bl	5460 <fwp_p_ad_push>
    5820:	aa0003e5 	mov	x5, x0
    5824:	97fffaa8 	bl	42c4 <caf75>
    5828:	aa0003e6 	mov	x6, x0
    582c:	97fffaa6 	bl	42c4 <caf75>
    5830:	1e692908 	fadd	d8, d8, d9
    5834:	aa1303e2 	mov	x2, x19
    5838:	aa0603e1 	mov	x1, x6
    583c:	aa0003e3 	mov	x3, x0
    5840:	aa0503e0 	mov	x0, x5
    5844:	97ffff07 	bl	5460 <fwp_p_ad_push>
    5848:	aa0003e1 	mov	x1, x0
    584c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5850:	9e660100 	fmov	x0, d8
    5854:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5858:	f9401bf7 	ldr	x23, [sp, #48]
    585c:	fd401fea 	ldr	d10, [sp, #56]
    5860:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5864:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5868:	d65f03c0 	ret
    586c:	d503201f 	nop

0000000000005870 <w176.constprop.0>:
    5870:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5874:	910003fd 	mov	x29, sp
    5878:	a9025bf5 	stp	x21, x22, [sp, #32]
    587c:	fd001be8 	str	d8, [sp, #48]
    5880:	f9400015 	ldr	x21, [x0]
    5884:	b40003b5 	cbz	x21, 58f8 <w176.constprop.0+0x88>
    5888:	2f00e408 	movi	d8, #0x0
    588c:	91002016 	add	x22, x0, #0x8
    5890:	a90153f3 	stp	x19, x20, [sp, #16]
    5894:	91004014 	add	x20, x0, #0x10
    5898:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    589c:	d2800013 	mov	x19, #0x0                   	// #0
    58a0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    58a4:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    58a8:	97fffa87 	bl	42c4 <caf75>
    58ac:	aa0003e6 	mov	x6, x0
    58b0:	97fffa85 	bl	42c4 <caf75>
    58b4:	1e602908 	fadd	d8, d8, d0
    58b8:	aa0003e3 	mov	x3, x0
    58bc:	aa0703e2 	mov	x2, x7
    58c0:	aa0503e0 	mov	x0, x5
    58c4:	aa0603e1 	mov	x1, x6
    58c8:	91000a73 	add	x19, x19, #0x2
    58cc:	97fffee5 	bl	5460 <fwp_p_ad_push>
    58d0:	aa0003e5 	mov	x5, x0
    58d4:	eb1302bf 	cmp	x21, x19
    58d8:	54fffe48 	b.hi	58a0 <w176.constprop.0+0x30>  // b.pmore
    58dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    58e0:	9e660100 	fmov	x0, d8
    58e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    58e8:	aa0503e1 	mov	x1, x5
    58ec:	fd401be8 	ldr	d8, [sp, #48]
    58f0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    58f4:	d65f03c0 	ret
    58f8:	2f00e408 	movi	d8, #0x0
    58fc:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    5900:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5904:	aa0503e1 	mov	x1, x5
    5908:	9e660100 	fmov	x0, d8
    590c:	fd401be8 	ldr	d8, [sp, #48]
    5910:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5914:	d65f03c0 	ret
    5918:	d503201f 	nop
    591c:	d503201f 	nop

0000000000005920 <fwp_rc_share>:
    5920:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xb90>
    5924:	91194042 	add	x2, x2, #0x650
    5928:	f949d843 	ldr	x3, [x2, #5040]
    592c:	f949ec41 	ldr	x1, [x2, #5080]
    5930:	cb030000 	sub	x0, x0, x3
    5934:	eb01401f 	cmp	x0, x1, lsl #16
    5938:	540002c2 	b.cs	5990 <fwp_rc_share+0x70>  // b.hs, b.nlast
    593c:	d350fc01 	lsr	x1, x0, #16
    5940:	f949fc44 	ldr	x4, [x2, #5112]
    5944:	8b010821 	add	x1, x1, x1, lsl #2
    5948:	d37df021 	lsl	x1, x1, #3
    594c:	8b010083 	add	x3, x4, x1
    5950:	f9401062 	ldr	x2, [x3, #32]
    5954:	b40001e2 	cbz	x2, 5990 <fwp_rc_share+0x70>
    5958:	38616881 	ldrb	w1, [x4, x1]
    595c:	7100083f 	cmp	w1, #0x2
    5960:	540001a0 	b.eq	5994 <fwp_rc_share+0x74>  // b.none
    5964:	7100043f 	cmp	w1, #0x1
    5968:	54000141 	b.ne	5990 <fwp_rc_share+0x70>  // b.any
    596c:	29430464 	ldp	w4, w1, [x3, #24]
    5970:	92403c00 	and	x0, x0, #0xffff
    5974:	9b047c00 	mul	x0, x0, x4
    5978:	d360fc00 	lsr	x0, x0, #32
    597c:	eb01001f 	cmp	x0, x1
    5980:	54000082 	b.cs	5990 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5984:	8b000042 	add	x2, x2, x0
    5988:	39400040 	ldrb	w0, [x2]
    598c:	350000a0 	cbnz	w0, 59a0 <fwp_rc_share+0x80>
    5990:	d65f03c0 	ret
    5994:	72003c1f 	tst	w0, #0xffff
    5998:	54ffff80 	b.eq	5988 <fwp_rc_share+0x68>  // b.none
    599c:	d65f03c0 	ret
    59a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    59a4:	90000040 	adrp	x0, d000 <__modti3+0x30>
    59a8:	9124c000 	add	x0, x0, #0x930
    59ac:	910003fd 	mov	x29, sp
    59b0:	97fff794 	bl	3800 <fwp_trap>

00000000000059b4 <fwp_rc_fresh>:
    59b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    59b8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb90>
    59bc:	91194063 	add	x3, x3, #0x650
    59c0:	910003fd 	mov	x29, sp
    59c4:	a90153f3 	stp	x19, x20, [sp, #16]
    59c8:	aa0003f3 	mov	x19, x0
    59cc:	f949d861 	ldr	x1, [x3, #5040]
    59d0:	f949ec60 	ldr	x0, [x3, #5080]
    59d4:	cb010261 	sub	x1, x19, x1
    59d8:	eb00403f 	cmp	x1, x0, lsl #16
    59dc:	54000322 	b.cs	5a40 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    59e0:	d350fc22 	lsr	x2, x1, #16
    59e4:	f949fc63 	ldr	x3, [x3, #5112]
    59e8:	8b020842 	add	x2, x2, x2, lsl #2
    59ec:	d37df042 	lsl	x2, x2, #3
    59f0:	8b020060 	add	x0, x3, x2
    59f4:	f9401014 	ldr	x20, [x0, #32]
    59f8:	b4000254 	cbz	x20, 5a40 <fwp_rc_fresh+0x8c>
    59fc:	38626862 	ldrb	w2, [x3, x2]
    5a00:	7100085f 	cmp	w2, #0x2
    5a04:	54000260 	b.eq	5a50 <fwp_rc_fresh+0x9c>  // b.none
    5a08:	7100045f 	cmp	w2, #0x1
    5a0c:	540001a1 	b.ne	5a40 <fwp_rc_fresh+0x8c>  // b.any
    5a10:	29430002 	ldp	w2, w0, [x0, #24]
    5a14:	92403c21 	and	x1, x1, #0xffff
    5a18:	9b027c21 	mul	x1, x1, x2
    5a1c:	d360fc21 	lsr	x1, x1, #32
    5a20:	eb00003f 	cmp	x1, x0
    5a24:	540000e2 	b.cs	5a40 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5a28:	8b010294 	add	x20, x20, x1
    5a2c:	39400280 	ldrb	w0, [x20]
    5a30:	7103fc1f 	cmp	w0, #0xff
    5a34:	540001a0 	b.eq	5a68 <fwp_rc_fresh+0xb4>  // b.none
    5a38:	52800020 	mov	w0, #0x1                   	// #1
    5a3c:	39000280 	strb	w0, [x20]
    5a40:	aa1303e0 	mov	x0, x19
    5a44:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a48:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a4c:	d65f03c0 	ret
    5a50:	72003c3f 	tst	w1, #0xffff
    5a54:	54fffec0 	b.eq	5a2c <fwp_rc_fresh+0x78>  // b.none
    5a58:	aa1303e0 	mov	x0, x19
    5a5c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a64:	d65f03c0 	ret
    5a68:	aa1403e0 	mov	x0, x20
    5a6c:	97fffbfd 	bl	4a60 <fwp_rc_forget_slot>
    5a70:	17fffff2 	b	5a38 <fwp_rc_fresh+0x84>

0000000000005a74 <fwp_rc_free_arr>:
    5a74:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb90>
    5a78:	91194063 	add	x3, x3, #0x650
    5a7c:	f949d861 	ldr	x1, [x3, #5040]
    5a80:	f949ec62 	ldr	x2, [x3, #5080]
    5a84:	cb010001 	sub	x1, x0, x1
    5a88:	eb02403f 	cmp	x1, x2, lsl #16
    5a8c:	54000342 	b.cs	5af4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a90:	d350fc22 	lsr	x2, x1, #16
    5a94:	f949fc65 	ldr	x5, [x3, #5112]
    5a98:	8b020842 	add	x2, x2, x2, lsl #2
    5a9c:	d37df042 	lsl	x2, x2, #3
    5aa0:	8b0200a4 	add	x4, x5, x2
    5aa4:	f9401083 	ldr	x3, [x4, #32]
    5aa8:	b4000263 	cbz	x3, 5af4 <fwp_rc_free_arr+0x80>
    5aac:	386268a2 	ldrb	w2, [x5, x2]
    5ab0:	7100085f 	cmp	w2, #0x2
    5ab4:	540001c0 	b.eq	5aec <fwp_rc_free_arr+0x78>  // b.none
    5ab8:	7100045f 	cmp	w2, #0x1
    5abc:	540001c1 	b.ne	5af4 <fwp_rc_free_arr+0x80>  // b.any
    5ac0:	29430885 	ldp	w5, w2, [x4, #24]
    5ac4:	92403c21 	and	x1, x1, #0xffff
    5ac8:	9b057c21 	mul	x1, x1, x5
    5acc:	d360fc21 	lsr	x1, x1, #32
    5ad0:	eb02003f 	cmp	x1, x2
    5ad4:	54000102 	b.cs	5af4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5ad8:	8b010063 	add	x3, x3, x1
    5adc:	39400061 	ldrb	w1, [x3]
    5ae0:	7100043f 	cmp	w1, #0x1
    5ae4:	54000081 	b.ne	5af4 <fwp_rc_free_arr+0x80>  // b.any
    5ae8:	17fffc7e 	b	4ce0 <fwp_mem_free>
    5aec:	72003c3f 	tst	w1, #0xffff
    5af0:	54ffff60 	b.eq	5adc <fwp_rc_free_arr+0x68>  // b.none
    5af4:	d65f03c0 	ret
    5af8:	d503201f 	nop
    5afc:	d503201f 	nop

0000000000005b00 <fwp_rc_dup>:
    5b00:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xb90>
    5b04:	91194042 	add	x2, x2, #0x650
    5b08:	f949d841 	ldr	x1, [x2, #5040]
    5b0c:	f949ec43 	ldr	x3, [x2, #5080]
    5b10:	cb010001 	sub	x1, x0, x1
    5b14:	eb03403f 	cmp	x1, x3, lsl #16
    5b18:	540003c2 	b.cs	5b90 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5b1c:	d350fc20 	lsr	x0, x1, #16
    5b20:	f949fc44 	ldr	x4, [x2, #5112]
    5b24:	8b000800 	add	x0, x0, x0, lsl #2
    5b28:	d37df002 	lsl	x2, x0, #3
    5b2c:	8b020083 	add	x3, x4, x2
    5b30:	f9401060 	ldr	x0, [x3, #32]
    5b34:	b40002e0 	cbz	x0, 5b90 <fwp_rc_dup+0x90>
    5b38:	38626882 	ldrb	w2, [x4, x2]
    5b3c:	7100085f 	cmp	w2, #0x2
    5b40:	540002a0 	b.eq	5b94 <fwp_rc_dup+0x94>  // b.none
    5b44:	7100045f 	cmp	w2, #0x1
    5b48:	54000241 	b.ne	5b90 <fwp_rc_dup+0x90>  // b.any
    5b4c:	29430864 	ldp	w4, w2, [x3, #24]
    5b50:	92403c21 	and	x1, x1, #0xffff
    5b54:	9b047c21 	mul	x1, x1, x4
    5b58:	d360fc21 	lsr	x1, x1, #32
    5b5c:	eb02003f 	cmp	x1, x2
    5b60:	54000182 	b.cs	5b90 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5b64:	8b010000 	add	x0, x0, x1
    5b68:	39400001 	ldrb	w1, [x0]
    5b6c:	34000121 	cbz	w1, 5b90 <fwp_rc_dup+0x90>
    5b70:	f00000c2 	adrp	x2, 20000 <__data_start>
    5b74:	91014042 	add	x2, x2, #0x50
    5b78:	b9415043 	ldr	w3, [x2, #336]
    5b7c:	35000123 	cbnz	w3, 5ba0 <fwp_rc_dup+0xa0>
    5b80:	7103f43f 	cmp	w1, #0xfd
    5b84:	54000168 	b.hi	5bb0 <fwp_rc_dup+0xb0>  // b.pmore
    5b88:	11000421 	add	w1, w1, #0x1
    5b8c:	39000001 	strb	w1, [x0]
    5b90:	d65f03c0 	ret
    5b94:	72003c3f 	tst	w1, #0xffff
    5b98:	54fffe80 	b.eq	5b68 <fwp_rc_dup+0x68>  // b.none
    5b9c:	d65f03c0 	ret
    5ba0:	f940bc43 	ldr	x3, [x2, #376]
    5ba4:	91000463 	add	x3, x3, #0x1
    5ba8:	f900bc43 	str	x3, [x2, #376]
    5bac:	17fffff5 	b	5b80 <fwp_rc_dup+0x80>
    5bb0:	17fffb65 	b	4944 <fwp_rc_wide_dup>

0000000000005bb4 <fwp_owned_entry173>:
    5bb4:	d10103ff 	sub	sp, sp, #0x40
    5bb8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5bbc:	f947f442 	ldr	x2, [x2, #4072]
    5bc0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5bc4:	910083fd 	add	x29, sp, #0x20
    5bc8:	a90353f3 	stp	x19, x20, [sp, #48]
    5bcc:	f9400043 	ldr	x3, [x2]
    5bd0:	f9000fe3 	str	x3, [sp, #24]
    5bd4:	d2800003 	mov	x3, #0x0                   	// #0
    5bd8:	a9400c01 	ldp	x1, x3, [x0]
    5bdc:	f9400802 	ldr	x2, [x0, #16]
    5be0:	ab020022 	adds	x2, x1, x2
    5be4:	540006e6 	b.vs	5cc0 <fwp_owned_entry173+0x10c>
    5be8:	910023e1 	add	x1, sp, #0x8
    5bec:	52800000 	mov	w0, #0x0                   	// #0
    5bf0:	a9008be3 	stp	x3, x2, [sp, #8]
    5bf4:	97fffdbc 	bl	52e4 <fwp_data.part.0.constprop.0>
    5bf8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb90>
    5bfc:	91194063 	add	x3, x3, #0x650
    5c00:	aa0003f3 	mov	x19, x0
    5c04:	f949d861 	ldr	x1, [x3, #5040]
    5c08:	f949ec60 	ldr	x0, [x3, #5080]
    5c0c:	cb010261 	sub	x1, x19, x1
    5c10:	eb00403f 	cmp	x1, x0, lsl #16
    5c14:	54000322 	b.cs	5c78 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5c18:	d350fc22 	lsr	x2, x1, #16
    5c1c:	f949fc63 	ldr	x3, [x3, #5112]
    5c20:	8b020842 	add	x2, x2, x2, lsl #2
    5c24:	d37df042 	lsl	x2, x2, #3
    5c28:	8b020060 	add	x0, x3, x2
    5c2c:	f9401014 	ldr	x20, [x0, #32]
    5c30:	b4000254 	cbz	x20, 5c78 <fwp_owned_entry173+0xc4>
    5c34:	38626862 	ldrb	w2, [x3, x2]
    5c38:	7100085f 	cmp	w2, #0x2
    5c3c:	54000360 	b.eq	5ca8 <fwp_owned_entry173+0xf4>  // b.none
    5c40:	7100045f 	cmp	w2, #0x1
    5c44:	540001a1 	b.ne	5c78 <fwp_owned_entry173+0xc4>  // b.any
    5c48:	29430002 	ldp	w2, w0, [x0, #24]
    5c4c:	92403c21 	and	x1, x1, #0xffff
    5c50:	9b027c21 	mul	x1, x1, x2
    5c54:	d360fc21 	lsr	x1, x1, #32
    5c58:	eb00003f 	cmp	x1, x0
    5c5c:	540000e2 	b.cs	5c78 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5c60:	8b010294 	add	x20, x20, x1
    5c64:	39400280 	ldrb	w0, [x20]
    5c68:	7103fc1f 	cmp	w0, #0xff
    5c6c:	54000240 	b.eq	5cb4 <fwp_owned_entry173+0x100>  // b.none
    5c70:	52800020 	mov	w0, #0x1                   	// #1
    5c74:	39000280 	strb	w0, [x20]
    5c78:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5c7c:	f947f400 	ldr	x0, [x0, #4072]
    5c80:	f9400fe2 	ldr	x2, [sp, #24]
    5c84:	f9400001 	ldr	x1, [x0]
    5c88:	eb010042 	subs	x2, x2, x1
    5c8c:	d2800001 	mov	x1, #0x0                   	// #0
    5c90:	540001a1 	b.ne	5cc4 <fwp_owned_entry173+0x110>  // b.any
    5c94:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c98:	aa1303e0 	mov	x0, x19
    5c9c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ca0:	910103ff 	add	sp, sp, #0x40
    5ca4:	d65f03c0 	ret
    5ca8:	72003c3f 	tst	w1, #0xffff
    5cac:	54fffe61 	b.ne	5c78 <fwp_owned_entry173+0xc4>  // b.any
    5cb0:	17ffffed 	b	5c64 <fwp_owned_entry173+0xb0>
    5cb4:	aa1403e0 	mov	x0, x20
    5cb8:	97fffb6a 	bl	4a60 <fwp_rc_forget_slot>
    5cbc:	17ffffed 	b	5c70 <fwp_owned_entry173+0xbc>
    5cc0:	97fff370 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5cc4:	97fff2f7 	bl	28a0 <__stack_chk_fail@plt>
    5cc8:	d503201f 	nop
    5ccc:	d503201f 	nop

0000000000005cd0 <e173>:
    5cd0:	d10103ff 	sub	sp, sp, #0x40
    5cd4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5cd8:	f947f442 	ldr	x2, [x2, #4072]
    5cdc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ce0:	910083fd 	add	x29, sp, #0x20
    5ce4:	a90353f3 	stp	x19, x20, [sp, #48]
    5ce8:	f9400043 	ldr	x3, [x2]
    5cec:	f9000fe3 	str	x3, [sp, #24]
    5cf0:	d2800003 	mov	x3, #0x0                   	// #0
    5cf4:	a9400c01 	ldp	x1, x3, [x0]
    5cf8:	f9400802 	ldr	x2, [x0, #16]
    5cfc:	ab020022 	adds	x2, x1, x2
    5d00:	54000726 	b.vs	5de4 <e173+0x114>
    5d04:	910023e1 	add	x1, sp, #0x8
    5d08:	52800000 	mov	w0, #0x0                   	// #0
    5d0c:	a9008be3 	stp	x3, x2, [sp, #8]
    5d10:	97fffd75 	bl	52e4 <fwp_data.part.0.constprop.0>
    5d14:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xb90>
    5d18:	91194063 	add	x3, x3, #0x650
    5d1c:	aa0003f3 	mov	x19, x0
    5d20:	f949d861 	ldr	x1, [x3, #5040]
    5d24:	f949ec60 	ldr	x0, [x3, #5080]
    5d28:	cb010261 	sub	x1, x19, x1
    5d2c:	eb00403f 	cmp	x1, x0, lsl #16
    5d30:	54000322 	b.cs	5d94 <e173+0xc4>  // b.hs, b.nlast
    5d34:	d350fc22 	lsr	x2, x1, #16
    5d38:	f949fc63 	ldr	x3, [x3, #5112]
    5d3c:	8b020842 	add	x2, x2, x2, lsl #2
    5d40:	d37df042 	lsl	x2, x2, #3
    5d44:	8b020060 	add	x0, x3, x2
    5d48:	f9401014 	ldr	x20, [x0, #32]
    5d4c:	b4000254 	cbz	x20, 5d94 <e173+0xc4>
    5d50:	38626862 	ldrb	w2, [x3, x2]
    5d54:	7100085f 	cmp	w2, #0x2
    5d58:	540003a0 	b.eq	5dcc <e173+0xfc>  // b.none
    5d5c:	7100045f 	cmp	w2, #0x1
    5d60:	540001a1 	b.ne	5d94 <e173+0xc4>  // b.any
    5d64:	29430002 	ldp	w2, w0, [x0, #24]
    5d68:	92403c21 	and	x1, x1, #0xffff
    5d6c:	9b027c21 	mul	x1, x1, x2
    5d70:	d360fc21 	lsr	x1, x1, #32
    5d74:	eb00003f 	cmp	x1, x0
    5d78:	540000e2 	b.cs	5d94 <e173+0xc4>  // b.hs, b.nlast
    5d7c:	8b010294 	add	x20, x20, x1
    5d80:	39400280 	ldrb	w0, [x20]
    5d84:	7103fc1f 	cmp	w0, #0xff
    5d88:	54000280 	b.eq	5dd8 <e173+0x108>  // b.none
    5d8c:	52800020 	mov	w0, #0x1                   	// #1
    5d90:	39000280 	strb	w0, [x20]
    5d94:	aa1303e0 	mov	x0, x19
    5d98:	97fffee2 	bl	5920 <fwp_rc_share>
    5d9c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5da0:	f947f400 	ldr	x0, [x0, #4072]
    5da4:	f9400fe2 	ldr	x2, [sp, #24]
    5da8:	f9400001 	ldr	x1, [x0]
    5dac:	eb010042 	subs	x2, x2, x1
    5db0:	d2800001 	mov	x1, #0x0                   	// #0
    5db4:	540001a1 	b.ne	5de8 <e173+0x118>  // b.any
    5db8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5dbc:	aa1303e0 	mov	x0, x19
    5dc0:	a94353f3 	ldp	x19, x20, [sp, #48]
    5dc4:	910103ff 	add	sp, sp, #0x40
    5dc8:	d65f03c0 	ret
    5dcc:	72003c3f 	tst	w1, #0xffff
    5dd0:	54fffe21 	b.ne	5d94 <e173+0xc4>  // b.any
    5dd4:	17ffffeb 	b	5d80 <e173+0xb0>
    5dd8:	aa1403e0 	mov	x0, x20
    5ddc:	97fffb21 	bl	4a60 <fwp_rc_forget_slot>
    5de0:	17ffffeb 	b	5d8c <e173+0xbc>
    5de4:	97fff327 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5de8:	97fff2ae 	bl	28a0 <__stack_chk_fail@plt>
    5dec:	d503201f 	nop

0000000000005df0 <fwp_drop1>:
    5df0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5df4:	910003fd 	mov	x29, sp
    5df8:	a90153f3 	stp	x19, x20, [sp, #16]
    5dfc:	f90013f5 	str	x21, [sp, #32]
    5e00:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xb90>
    5e04:	911942b4 	add	x20, x21, #0x650
    5e08:	f949da81 	ldr	x1, [x20, #5040]
    5e0c:	f949ee82 	ldr	x2, [x20, #5080]
    5e10:	cb010001 	sub	x1, x0, x1
    5e14:	eb02403f 	cmp	x1, x2, lsl #16
    5e18:	54000382 	b.cs	5e88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e1c:	d350fc22 	lsr	x2, x1, #16
    5e20:	f949fe84 	ldr	x4, [x20, #5112]
    5e24:	8b020842 	add	x2, x2, x2, lsl #2
    5e28:	d37df042 	lsl	x2, x2, #3
    5e2c:	8b020083 	add	x3, x4, x2
    5e30:	f9401073 	ldr	x19, [x3, #32]
    5e34:	b40002b3 	cbz	x19, 5e88 <fwp_drop1+0x98>
    5e38:	38626882 	ldrb	w2, [x4, x2]
    5e3c:	7100085f 	cmp	w2, #0x2
    5e40:	540002c0 	b.eq	5e98 <fwp_drop1+0xa8>  // b.none
    5e44:	7100045f 	cmp	w2, #0x1
    5e48:	54000201 	b.ne	5e88 <fwp_drop1+0x98>  // b.any
    5e4c:	29430864 	ldp	w4, w2, [x3, #24]
    5e50:	92403c21 	and	x1, x1, #0xffff
    5e54:	9b047c21 	mul	x1, x1, x4
    5e58:	d360fc21 	lsr	x1, x1, #32
    5e5c:	eb02003f 	cmp	x1, x2
    5e60:	54000142 	b.cs	5e88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e64:	8b010273 	add	x19, x19, x1
    5e68:	39400261 	ldrb	w1, [x19]
    5e6c:	340000e1 	cbz	w1, 5e88 <fwp_drop1+0x98>
    5e70:	7100043f 	cmp	w1, #0x1
    5e74:	540001e0 	b.eq	5eb0 <fwp_drop1+0xc0>  // b.none
    5e78:	7103fc3f 	cmp	w1, #0xff
    5e7c:	540002e0 	b.eq	5ed8 <fwp_drop1+0xe8>  // b.none
    5e80:	51000421 	sub	w1, w1, #0x1
    5e84:	39000261 	strb	w1, [x19]
    5e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e8c:	f94013f5 	ldr	x21, [sp, #32]
    5e90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e94:	d65f03c0 	ret
    5e98:	72003c3f 	tst	w1, #0xffff
    5e9c:	54fffe60 	b.eq	5e68 <fwp_drop1+0x78>  // b.none
    5ea0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ea4:	f94013f5 	ldr	x21, [sp, #32]
    5ea8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5eac:	d65f03c0 	ret
    5eb0:	f9400813 	ldr	x19, [x0, #16]
    5eb4:	97fffef0 	bl	5a74 <fwp_rc_free_arr>
    5eb8:	911942a0 	add	x0, x21, #0x650
    5ebc:	f949d801 	ldr	x1, [x0, #5040]
    5ec0:	f949ec00 	ldr	x0, [x0, #5080]
    5ec4:	cb010261 	sub	x1, x19, x1
    5ec8:	eb00403f 	cmp	x1, x0, lsl #16
    5ecc:	54fffde2 	b.cs	5e88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ed0:	aa1303e0 	mov	x0, x19
    5ed4:	17ffffd2 	b	5e1c <fwp_drop1+0x2c>
    5ed8:	ca534660 	eor	x0, x19, x19, lsr #17
    5edc:	911942b5 	add	x21, x21, #0x650
    5ee0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ee4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5ee8:	f94a2400 	ldr	x0, [x0, #5192]
    5eec:	b5000080 	cbnz	x0, 5efc <fwp_drop1+0x10c>
    5ef0:	14000010 	b	5f30 <fwp_drop1+0x140>
    5ef4:	f9400800 	ldr	x0, [x0, #16]
    5ef8:	b40001c0 	cbz	x0, 5f30 <fwp_drop1+0x140>
    5efc:	f9400001 	ldr	x1, [x0]
    5f00:	eb13003f 	cmp	x1, x19
    5f04:	54ffff81 	b.ne	5ef4 <fwp_drop1+0x104>  // b.any
    5f08:	f9400401 	ldr	x1, [x0, #8]
    5f0c:	d1000421 	sub	x1, x1, #0x1
    5f10:	f9000401 	str	x1, [x0, #8]
    5f14:	f103f83f 	cmp	x1, #0xfe
    5f18:	54fffb81 	b.ne	5e88 <fwp_drop1+0x98>  // b.any
    5f1c:	aa1303e0 	mov	x0, x19
    5f20:	97fffad0 	bl	4a60 <fwp_rc_forget_slot>
    5f24:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f28:	39000260 	strb	w0, [x19]
    5f2c:	17ffffd7 	b	5e88 <fwp_drop1+0x98>
    5f30:	90000040 	adrp	x0, d000 <__modti3+0x30>
    5f34:	9120c000 	add	x0, x0, #0x830
    5f38:	97fff632 	bl	3800 <fwp_trap>
    5f3c:	d503201f 	nop

0000000000005f40 <fwp_drop0>:
    5f40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f44:	910003fd 	mov	x29, sp
    5f48:	a90153f3 	stp	x19, x20, [sp, #16]
    5f4c:	f90013f5 	str	x21, [sp, #32]
    5f50:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xb90>
    5f54:	911942b4 	add	x20, x21, #0x650
    5f58:	f949da81 	ldr	x1, [x20, #5040]
    5f5c:	f949ee82 	ldr	x2, [x20, #5080]
    5f60:	cb010001 	sub	x1, x0, x1
    5f64:	eb02403f 	cmp	x1, x2, lsl #16
    5f68:	54000382 	b.cs	5fd8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f6c:	d350fc22 	lsr	x2, x1, #16
    5f70:	f949fe84 	ldr	x4, [x20, #5112]
    5f74:	8b020842 	add	x2, x2, x2, lsl #2
    5f78:	d37df042 	lsl	x2, x2, #3
    5f7c:	8b020083 	add	x3, x4, x2
    5f80:	f9401073 	ldr	x19, [x3, #32]
    5f84:	b40002b3 	cbz	x19, 5fd8 <fwp_drop0+0x98>
    5f88:	38626882 	ldrb	w2, [x4, x2]
    5f8c:	7100085f 	cmp	w2, #0x2
    5f90:	540002c0 	b.eq	5fe8 <fwp_drop0+0xa8>  // b.none
    5f94:	7100045f 	cmp	w2, #0x1
    5f98:	54000201 	b.ne	5fd8 <fwp_drop0+0x98>  // b.any
    5f9c:	29430864 	ldp	w4, w2, [x3, #24]
    5fa0:	92403c21 	and	x1, x1, #0xffff
    5fa4:	9b047c21 	mul	x1, x1, x4
    5fa8:	d360fc21 	lsr	x1, x1, #32
    5fac:	eb02003f 	cmp	x1, x2
    5fb0:	54000142 	b.cs	5fd8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5fb4:	8b010273 	add	x19, x19, x1
    5fb8:	39400261 	ldrb	w1, [x19]
    5fbc:	340000e1 	cbz	w1, 5fd8 <fwp_drop0+0x98>
    5fc0:	7100043f 	cmp	w1, #0x1
    5fc4:	540001e0 	b.eq	6000 <fwp_drop0+0xc0>  // b.none
    5fc8:	7103fc3f 	cmp	w1, #0xff
    5fcc:	540002e0 	b.eq	6028 <fwp_drop0+0xe8>  // b.none
    5fd0:	51000421 	sub	w1, w1, #0x1
    5fd4:	39000261 	strb	w1, [x19]
    5fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fdc:	f94013f5 	ldr	x21, [sp, #32]
    5fe0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fe4:	d65f03c0 	ret
    5fe8:	72003c3f 	tst	w1, #0xffff
    5fec:	54fffe60 	b.eq	5fb8 <fwp_drop0+0x78>  // b.none
    5ff0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ff4:	f94013f5 	ldr	x21, [sp, #32]
    5ff8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ffc:	d65f03c0 	ret
    6000:	f9400813 	ldr	x19, [x0, #16]
    6004:	97fffe9c 	bl	5a74 <fwp_rc_free_arr>
    6008:	911942a0 	add	x0, x21, #0x650
    600c:	f949d801 	ldr	x1, [x0, #5040]
    6010:	f949ec00 	ldr	x0, [x0, #5080]
    6014:	cb010261 	sub	x1, x19, x1
    6018:	eb00403f 	cmp	x1, x0, lsl #16
    601c:	54fffde2 	b.cs	5fd8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6020:	aa1303e0 	mov	x0, x19
    6024:	17ffffd2 	b	5f6c <fwp_drop0+0x2c>
    6028:	ca534660 	eor	x0, x19, x19, lsr #17
    602c:	911942b5 	add	x21, x21, #0x650
    6030:	ca402400 	eor	x0, x0, x0, lsr #9
    6034:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6038:	f94a2400 	ldr	x0, [x0, #5192]
    603c:	b5000080 	cbnz	x0, 604c <fwp_drop0+0x10c>
    6040:	14000010 	b	6080 <fwp_drop0+0x140>
    6044:	f9400800 	ldr	x0, [x0, #16]
    6048:	b40001c0 	cbz	x0, 6080 <fwp_drop0+0x140>
    604c:	f9400001 	ldr	x1, [x0]
    6050:	eb13003f 	cmp	x1, x19
    6054:	54ffff81 	b.ne	6044 <fwp_drop0+0x104>  // b.any
    6058:	f9400401 	ldr	x1, [x0, #8]
    605c:	d1000421 	sub	x1, x1, #0x1
    6060:	f9000401 	str	x1, [x0, #8]
    6064:	f103f83f 	cmp	x1, #0xfe
    6068:	54fffb81 	b.ne	5fd8 <fwp_drop0+0x98>  // b.any
    606c:	aa1303e0 	mov	x0, x19
    6070:	97fffa7c 	bl	4a60 <fwp_rc_forget_slot>
    6074:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6078:	39000260 	strb	w0, [x19]
    607c:	17ffffd7 	b	5fd8 <fwp_drop0+0x98>
    6080:	f0000020 	adrp	x0, d000 <__modti3+0x30>
    6084:	9120c000 	add	x0, x0, #0x830
    6088:	97fff5de 	bl	3800 <fwp_trap>
    608c:	d503201f 	nop

0000000000006090 <fwp_closure_drop>:
    6090:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xb90>
    6094:	911940a4 	add	x4, x5, #0x650
    6098:	aa0003e1 	mov	x1, x0
    609c:	f949d882 	ldr	x2, [x4, #5040]
    60a0:	f949ec80 	ldr	x0, [x4, #5080]
    60a4:	cb020022 	sub	x2, x1, x2
    60a8:	eb00405f 	cmp	x2, x0, lsl #16
    60ac:	54000662 	b.cs	6178 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    60b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    60b4:	d350fc43 	lsr	x3, x2, #16
    60b8:	910003fd 	mov	x29, sp
    60bc:	8b030863 	add	x3, x3, x3, lsl #2
    60c0:	f949fc84 	ldr	x4, [x4, #5112]
    60c4:	d37df063 	lsl	x3, x3, #3
    60c8:	f9000bf3 	str	x19, [sp, #16]
    60cc:	8b030080 	add	x0, x4, x3
    60d0:	f9401013 	ldr	x19, [x0, #32]
    60d4:	b40002b3 	cbz	x19, 6128 <fwp_closure_drop+0x98>
    60d8:	38636883 	ldrb	w3, [x4, x3]
    60dc:	7100087f 	cmp	w3, #0x2
    60e0:	54000420 	b.eq	6164 <fwp_closure_drop+0xd4>  // b.none
    60e4:	7100047f 	cmp	w3, #0x1
    60e8:	54000201 	b.ne	6128 <fwp_closure_drop+0x98>  // b.any
    60ec:	29430003 	ldp	w3, w0, [x0, #24]
    60f0:	92403c42 	and	x2, x2, #0xffff
    60f4:	9b037c42 	mul	x2, x2, x3
    60f8:	d360fc42 	lsr	x2, x2, #32
    60fc:	eb00005f 	cmp	x2, x0
    6100:	54000142 	b.cs	6128 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6104:	8b020273 	add	x19, x19, x2
    6108:	39400260 	ldrb	w0, [x19]
    610c:	340000e0 	cbz	w0, 6128 <fwp_closure_drop+0x98>
    6110:	7100041f 	cmp	w0, #0x1
    6114:	54000100 	b.eq	6134 <fwp_closure_drop+0xa4>  // b.none
    6118:	7103fc1f 	cmp	w0, #0xff
    611c:	54000300 	b.eq	617c <fwp_closure_drop+0xec>  // b.none
    6120:	51000400 	sub	w0, w0, #0x1
    6124:	39000260 	strb	w0, [x19]
    6128:	f9400bf3 	ldr	x19, [sp, #16]
    612c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6130:	d65f03c0 	ret
    6134:	d53bd040 	mrs	x0, tpidr_el0
    6138:	91400000 	add	x0, x0, #0x0, lsl #12
    613c:	91004000 	add	x0, x0, #0x10
    6140:	f9400000 	ldr	x0, [x0]
    6144:	b4000080 	cbz	x0, 6154 <fwp_closure_drop+0xc4>
    6148:	f9400bf3 	ldr	x19, [sp, #16]
    614c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6150:	17fff5c5 	b	3864 <fwp_closure_drop_push>
    6154:	f9400bf3 	ldr	x19, [sp, #16]
    6158:	aa0103e0 	mov	x0, x1
    615c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6160:	17fff630 	b	3a20 <fwp_closure_drop.part.0>
    6164:	72003c5f 	tst	w2, #0xffff
    6168:	54fffd00 	b.eq	6108 <fwp_closure_drop+0x78>  // b.none
    616c:	f9400bf3 	ldr	x19, [sp, #16]
    6170:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6174:	d65f03c0 	ret
    6178:	d65f03c0 	ret
    617c:	ca534660 	eor	x0, x19, x19, lsr #17
    6180:	911940a5 	add	x5, x5, #0x650
    6184:	ca402400 	eor	x0, x0, x0, lsr #9
    6188:	8b200ca0 	add	x0, x5, w0, uxtb #3
    618c:	f94a2400 	ldr	x0, [x0, #5192]
    6190:	b5000080 	cbnz	x0, 61a0 <fwp_closure_drop+0x110>
    6194:	14000010 	b	61d4 <fwp_closure_drop+0x144>
    6198:	f9400800 	ldr	x0, [x0, #16]
    619c:	b40001c0 	cbz	x0, 61d4 <fwp_closure_drop+0x144>
    61a0:	f9400001 	ldr	x1, [x0]
    61a4:	eb13003f 	cmp	x1, x19
    61a8:	54ffff81 	b.ne	6198 <fwp_closure_drop+0x108>  // b.any
    61ac:	f9400401 	ldr	x1, [x0, #8]
    61b0:	d1000421 	sub	x1, x1, #0x1
    61b4:	f9000401 	str	x1, [x0, #8]
    61b8:	f103f83f 	cmp	x1, #0xfe
    61bc:	54fffb61 	b.ne	6128 <fwp_closure_drop+0x98>  // b.any
    61c0:	aa1303e0 	mov	x0, x19
    61c4:	97fffa27 	bl	4a60 <fwp_rc_forget_slot>
    61c8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    61cc:	39000260 	strb	w0, [x19]
    61d0:	17ffffd6 	b	6128 <fwp_closure_drop+0x98>
    61d4:	f0000020 	adrp	x0, d000 <__modti3+0x30>
    61d8:	9120c000 	add	x0, x0, #0x830
    61dc:	97fff589 	bl	3800 <fwp_trap>

00000000000061e0 <fwp_owned_tape_release>:
    61e0:	b4000940 	cbz	x0, 6308 <fwp_owned_tape_release+0x128>
    61e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    61e8:	910003fd 	mov	x29, sp
    61ec:	a90153f3 	stp	x19, x20, [sp, #16]
    61f0:	aa0003f3 	mov	x19, x0
    61f4:	f9400000 	ldr	x0, [x0]
    61f8:	b4000060 	cbz	x0, 6204 <fwp_owned_tape_release+0x24>
    61fc:	f9400661 	ldr	x1, [x19, #8]
    6200:	f9000401 	str	x1, [x0, #8]
    6204:	f9400661 	ldr	x1, [x19, #8]
    6208:	b4000041 	cbz	x1, 6210 <fwp_owned_tape_release+0x30>
    620c:	f9000020 	str	x0, [x1]
    6210:	f9400a60 	ldr	x0, [x19, #16]
    6214:	f9403401 	ldr	x1, [x0, #104]
    6218:	b40005c1 	cbz	x1, 62d0 <fwp_owned_tape_release+0xf0>
    621c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6220:	eb00005f 	cmp	x2, x0
    6224:	540002ed 	b.le	6280 <fwp_owned_tape_release+0xa0>
    6228:	d2800014 	mov	x20, #0x0                   	// #0
    622c:	f90013f5 	str	x21, [sp, #32]
    6230:	d2800015 	mov	x21, #0x0                   	// #0
    6234:	d503201f 	nop
    6238:	f9402260 	ldr	x0, [x19, #64]
    623c:	910006b5 	add	x21, x21, #0x1
    6240:	f8746800 	ldr	x0, [x0, x20]
    6244:	d63f0020 	blr	x1
    6248:	f9402260 	ldr	x0, [x19, #64]
    624c:	f9400a61 	ldr	x1, [x19, #16]
    6250:	8b140000 	add	x0, x0, x20
    6254:	91004294 	add	x20, x20, #0x10
    6258:	f9400400 	ldr	x0, [x0, #8]
    625c:	f9403421 	ldr	x1, [x1, #104]
    6260:	d63f0020 	blr	x1
    6264:	a9450261 	ldp	x1, x0, [x19, #80]
    6268:	cb010000 	sub	x0, x0, x1
    626c:	eb15001f 	cmp	x0, x21
    6270:	f9400a60 	ldr	x0, [x19, #16]
    6274:	f9403401 	ldr	x1, [x0, #104]
    6278:	54fffe0c 	b.gt	6238 <fwp_owned_tape_release+0x58>
    627c:	f94013f5 	ldr	x21, [sp, #32]
    6280:	f9403663 	ldr	x3, [x19, #104]
    6284:	f9401262 	ldr	x2, [x19, #32]
    6288:	f100007f 	cmp	x3, #0x0
    628c:	540001ed 	b.le	62c8 <fwp_owned_tape_release+0xe8>
    6290:	d2800014 	mov	x20, #0x0                   	// #0
    6294:	d503201f 	nop
    6298:	f9402660 	ldr	x0, [x19, #72]
    629c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    62a0:	eb02001f 	cmp	x0, x2
    62a4:	540000c0 	b.eq	62bc <fwp_owned_tape_release+0xdc>  // b.none
    62a8:	d63f0020 	blr	x1
    62ac:	f9400a60 	ldr	x0, [x19, #16]
    62b0:	f9401262 	ldr	x2, [x19, #32]
    62b4:	f9403663 	ldr	x3, [x19, #104]
    62b8:	f9403401 	ldr	x1, [x0, #104]
    62bc:	91000694 	add	x20, x20, #0x1
    62c0:	eb14007f 	cmp	x3, x20
    62c4:	54fffeac 	b.gt	6298 <fwp_owned_tape_release+0xb8>
    62c8:	aa0203e0 	mov	x0, x2
    62cc:	d63f0020 	blr	x1
    62d0:	f9401660 	ldr	x0, [x19, #40]
    62d4:	97ffff6f 	bl	6090 <fwp_closure_drop>
    62d8:	f9401a60 	ldr	x0, [x19, #48]
    62dc:	97ffff6d 	bl	6090 <fwp_closure_drop>
    62e0:	f9401e60 	ldr	x0, [x19, #56]
    62e4:	97ffff6b 	bl	6090 <fwp_closure_drop>
    62e8:	f9402260 	ldr	x0, [x19, #64]
    62ec:	97fffa7d 	bl	4ce0 <fwp_mem_free>
    62f0:	f9402660 	ldr	x0, [x19, #72]
    62f4:	97fffa7b 	bl	4ce0 <fwp_mem_free>
    62f8:	aa1303e0 	mov	x0, x19
    62fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6300:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6304:	17fffa77 	b	4ce0 <fwp_mem_free>
    6308:	d65f03c0 	ret
    630c:	d503201f 	nop

0000000000006310 <fwp_tape_finish>:
    6310:	d10203ff 	sub	sp, sp, #0x80
    6314:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6318:	f947f421 	ldr	x1, [x1, #4072]
    631c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6320:	910103fd 	add	x29, sp, #0x40
    6324:	a9065bf5 	stp	x21, x22, [sp, #96]
    6328:	a90763f7 	stp	x23, x24, [sp, #112]
    632c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6330:	910142f6 	add	x22, x23, #0x50
    6334:	f9400022 	ldr	x2, [x1]
    6338:	f9001fe2 	str	x2, [sp, #56]
    633c:	d2800002 	mov	x2, #0x0                   	// #0
    6340:	910402c0 	add	x0, x22, #0x100
    6344:	97fff844 	bl	4454 <fwp_tape_buffers_dispose>
    6348:	f9009edf 	str	xzr, [x22, #312]
    634c:	f9406ec0 	ldr	x0, [x22, #216]
    6350:	f100001f 	cmp	x0, #0x0
    6354:	5400034d 	b.le	63bc <fwp_tape_finish+0xac>
    6358:	910003f8 	mov	x24, sp
    635c:	d2800015 	mov	x21, #0x0                   	// #0
    6360:	a90553f3 	stp	x19, x20, [sp, #80]
    6364:	d2800014 	mov	x20, #0x0                   	// #0
    6368:	91000694 	add	x20, x20, #0x1
    636c:	f94046d3 	ldr	x19, [x22, #136]
    6370:	8b150273 	add	x19, x19, x21
    6374:	9101a2b5 	add	x21, x21, #0x68
    6378:	aa1303e0 	mov	x0, x19
    637c:	97fff326 	bl	3014 <fwp_tape_unlink_scope>
    6380:	aa1803e0 	mov	x0, x24
    6384:	a9440663 	ldp	x3, x1, [x19, #64]
    6388:	f9001be1 	str	x1, [sp, #48]
    638c:	f9400e62 	ldr	x2, [x19, #24]
    6390:	a9020be3 	stp	x3, x2, [sp, #32]
    6394:	ad410261 	ldp	q1, q0, [x19, #32]
    6398:	ad0003e1 	stp	q1, q0, [sp]
    639c:	97fff82e 	bl	4454 <fwp_tape_buffers_dispose>
    63a0:	f9403260 	ldr	x0, [x19, #96]
    63a4:	97ffff8f 	bl	61e0 <fwp_owned_tape_release>
    63a8:	f900327f 	str	xzr, [x19, #96]
    63ac:	f9406ec0 	ldr	x0, [x22, #216]
    63b0:	eb14001f 	cmp	x0, x20
    63b4:	54fffdac 	b.gt	6368 <fwp_tape_finish+0x58>
    63b8:	a94553f3 	ldp	x19, x20, [sp, #80]
    63bc:	910142e0 	add	x0, x23, #0x50
    63c0:	f9404400 	ldr	x0, [x0, #136]
    63c4:	b4000040 	cbz	x0, 63cc <fwp_tape_finish+0xbc>
    63c8:	97fff802 	bl	43d0 <ad_raw_free.part.0>
    63cc:	910142f7 	add	x23, x23, #0x50
    63d0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    63d4:	f947f400 	ldr	x0, [x0, #4072]
    63d8:	f90046ff 	str	xzr, [x23, #136]
    63dc:	f9006eff 	str	xzr, [x23, #216]
    63e0:	f900a2ff 	str	xzr, [x23, #320]
    63e4:	f900c2ff 	str	xzr, [x23, #384]
    63e8:	f9401fe2 	ldr	x2, [sp, #56]
    63ec:	f9400001 	ldr	x1, [x0]
    63f0:	eb010042 	subs	x2, x2, x1
    63f4:	d2800001 	mov	x1, #0x0                   	// #0
    63f8:	540000c1 	b.ne	6410 <fwp_tape_finish+0x100>  // b.any
    63fc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6400:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6404:	a94763f7 	ldp	x23, x24, [sp, #112]
    6408:	910203ff 	add	sp, sp, #0x80
    640c:	d65f03c0 	ret
    6410:	a90553f3 	stp	x19, x20, [sp, #80]
    6414:	97fff123 	bl	28a0 <__stack_chk_fail@plt>
    6418:	d503201f 	nop
    641c:	d503201f 	nop

0000000000006420 <fwp_tape_scope_release>:
    6420:	d10243ff 	sub	sp, sp, #0x90
    6424:	a9047bfd 	stp	x29, x30, [sp, #64]
    6428:	910103fd 	add	x29, sp, #0x40
    642c:	a90553f3 	stp	x19, x20, [sp, #80]
    6430:	aa0003f4 	mov	x20, x0
    6434:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6438:	f947f400 	ldr	x0, [x0, #4072]
    643c:	b9400285 	ldr	w5, [x20]
    6440:	f9400001 	ldr	x1, [x0]
    6444:	f9001fe1 	str	x1, [sp, #56]
    6448:	d2800001 	mov	x1, #0x0                   	// #0
    644c:	37f806c5 	tbnz	w5, #31, 6524 <fwp_tape_scope_release+0x104>
    6450:	a90763f7 	stp	x23, x24, [sp, #112]
    6454:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6458:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    645c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6460:	d00000d3 	adrp	x19, 20000 <__data_start>
    6464:	910003f7 	mov	x23, sp
    6468:	91014273 	add	x19, x19, #0x50
    646c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6470:	a9065bf5 	stp	x21, x22, [sp, #96]
    6474:	52800d16 	mov	w22, #0x68                  	// #104
    6478:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    647c:	f90043f9 	str	x25, [sp, #128]
    6480:	14000006 	b	6498 <fwp_tape_scope_release+0x78>
    6484:	97fff7f4 	bl	4454 <fwp_tape_buffers_dispose>
    6488:	aa1903e0 	mov	x0, x25
    648c:	97ffff55 	bl	61e0 <fwp_owned_tape_release>
    6490:	b9400285 	ldr	w5, [x20]
    6494:	37f80425 	tbnz	w5, #31, 6518 <fwp_tape_scope_release+0xf8>
    6498:	f9404666 	ldr	x6, [x19, #136]
    649c:	9b367ca5 	smull	x5, w5, w22
    64a0:	8b0500c0 	add	x0, x6, x5
    64a4:	97fff2dc 	bl	3014 <fwp_tape_unlink_scope>
    64a8:	ad410001 	ldp	q1, q0, [x0, #32]
    64ac:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    64b0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    64b4:	f9400c03 	ldr	x3, [x0, #24]
    64b8:	ad0003e1 	stp	q1, q0, [sp]
    64bc:	b86568c1 	ldr	w1, [x6, x5]
    64c0:	a9440804 	ldp	x4, x2, [x0, #64]
    64c4:	b900041f 	str	wzr, [x0, #4]
    64c8:	f9403019 	ldr	x25, [x0, #96]
    64cc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    64d0:	f9000c1f 	str	xzr, [x0, #24]
    64d4:	a9020fe4 	stp	x4, x3, [sp, #32]
    64d8:	f9001be2 	str	x2, [sp, #48]
    64dc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    64e0:	f900301f 	str	xzr, [x0, #96]
    64e4:	6b15003f 	cmp	w1, w21
    64e8:	540000e8 	b.hi	6504 <fwp_tape_scope_release+0xe4>  // b.pmore
    64ec:	9343fca5 	asr	x5, x5, #3
    64f0:	f940c260 	ldr	x0, [x19, #384]
    64f4:	9b187ca5 	mul	x5, x5, x24
    64f8:	eb0000bf 	cmp	x5, x0
    64fc:	5400004a 	b.ge	6504 <fwp_tape_scope_release+0xe4>  // b.tcont
    6500:	f900c265 	str	x5, [x19, #384]
    6504:	aa1703e0 	mov	x0, x23
    6508:	b5fffbf9 	cbnz	x25, 6484 <fwp_tape_scope_release+0x64>
    650c:	97fff81a 	bl	4574 <fwp_tape_buffers_release>
    6510:	b9400285 	ldr	w5, [x20]
    6514:	36fffc25 	tbz	w5, #31, 6498 <fwp_tape_scope_release+0x78>
    6518:	a9465bf5 	ldp	x21, x22, [sp, #96]
    651c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6520:	f94043f9 	ldr	x25, [sp, #128]
    6524:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6528:	f947f400 	ldr	x0, [x0, #4072]
    652c:	f9401fe2 	ldr	x2, [sp, #56]
    6530:	f9400001 	ldr	x1, [x0]
    6534:	eb010042 	subs	x2, x2, x1
    6538:	d2800001 	mov	x1, #0x0                   	// #0
    653c:	540000a1 	b.ne	6550 <fwp_tape_scope_release+0x130>  // b.any
    6540:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6544:	a94553f3 	ldp	x19, x20, [sp, #80]
    6548:	910243ff 	add	sp, sp, #0x90
    654c:	d65f03c0 	ret
    6550:	a9065bf5 	stp	x21, x22, [sp, #96]
    6554:	a90763f7 	stp	x23, x24, [sp, #112]
    6558:	f90043f9 	str	x25, [sp, #128]
    655c:	97fff0d1 	bl	28a0 <__stack_chk_fail@plt>

0000000000006560 <fwp_drop4>:
    6560:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6564:	910003fd 	mov	x29, sp
    6568:	a9025bf5 	stp	x21, x22, [sp, #32]
    656c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xb90>
    6570:	911942d5 	add	x21, x22, #0x650
    6574:	a90153f3 	stp	x19, x20, [sp, #16]
    6578:	aa0003f3 	mov	x19, x0
    657c:	f949daa1 	ldr	x1, [x21, #5040]
    6580:	f949eea0 	ldr	x0, [x21, #5080]
    6584:	cb010261 	sub	x1, x19, x1
    6588:	eb00403f 	cmp	x1, x0, lsl #16
    658c:	54000382 	b.cs	65fc <fwp_drop4+0x9c>  // b.hs, b.nlast
    6590:	d350fc22 	lsr	x2, x1, #16
    6594:	f949fea3 	ldr	x3, [x21, #5112]
    6598:	8b020842 	add	x2, x2, x2, lsl #2
    659c:	d37df042 	lsl	x2, x2, #3
    65a0:	8b020060 	add	x0, x3, x2
    65a4:	f9401014 	ldr	x20, [x0, #32]
    65a8:	b40002b4 	cbz	x20, 65fc <fwp_drop4+0x9c>
    65ac:	38626862 	ldrb	w2, [x3, x2]
    65b0:	7100085f 	cmp	w2, #0x2
    65b4:	540002c0 	b.eq	660c <fwp_drop4+0xac>  // b.none
    65b8:	7100045f 	cmp	w2, #0x1
    65bc:	54000201 	b.ne	65fc <fwp_drop4+0x9c>  // b.any
    65c0:	29430002 	ldp	w2, w0, [x0, #24]
    65c4:	92403c21 	and	x1, x1, #0xffff
    65c8:	9b027c21 	mul	x1, x1, x2
    65cc:	d360fc21 	lsr	x1, x1, #32
    65d0:	eb00003f 	cmp	x1, x0
    65d4:	54000142 	b.cs	65fc <fwp_drop4+0x9c>  // b.hs, b.nlast
    65d8:	8b010294 	add	x20, x20, x1
    65dc:	39400280 	ldrb	w0, [x20]
    65e0:	340000e0 	cbz	w0, 65fc <fwp_drop4+0x9c>
    65e4:	7100041f 	cmp	w0, #0x1
    65e8:	540001e0 	b.eq	6624 <fwp_drop4+0xc4>  // b.none
    65ec:	7103fc1f 	cmp	w0, #0xff
    65f0:	540007c0 	b.eq	66e8 <fwp_drop4+0x188>  // b.none
    65f4:	51000400 	sub	w0, w0, #0x1
    65f8:	39000280 	strb	w0, [x20]
    65fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6600:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6604:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6608:	d65f03c0 	ret
    660c:	72003c3f 	tst	w1, #0xffff
    6610:	54fffe60 	b.eq	65dc <fwp_drop4+0x7c>  // b.none
    6614:	a94153f3 	ldp	x19, x20, [sp, #16]
    6618:	a9425bf5 	ldp	x21, x22, [sp, #32]
    661c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6620:	d65f03c0 	ret
    6624:	911942c2 	add	x2, x22, #0x650
    6628:	f9400660 	ldr	x0, [x19, #8]
    662c:	f949d841 	ldr	x1, [x2, #5040]
    6630:	f949ec42 	ldr	x2, [x2, #5080]
    6634:	cb010001 	sub	x1, x0, x1
    6638:	eb02403f 	cmp	x1, x2, lsl #16
    663c:	54000362 	b.cs	66a8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6640:	d350fc22 	lsr	x2, x1, #16
    6644:	8b020842 	add	x2, x2, x2, lsl #2
    6648:	d37df042 	lsl	x2, x2, #3
    664c:	8b020064 	add	x4, x3, x2
    6650:	f9401094 	ldr	x20, [x4, #32]
    6654:	b40002b4 	cbz	x20, 66a8 <fwp_drop4+0x148>
    6658:	38626862 	ldrb	w2, [x3, x2]
    665c:	7100085f 	cmp	w2, #0x2
    6660:	540003e0 	b.eq	66dc <fwp_drop4+0x17c>  // b.none
    6664:	7100045f 	cmp	w2, #0x1
    6668:	54000201 	b.ne	66a8 <fwp_drop4+0x148>  // b.any
    666c:	29430883 	ldp	w3, w2, [x4, #24]
    6670:	92403c21 	and	x1, x1, #0xffff
    6674:	9b037c21 	mul	x1, x1, x3
    6678:	d360fc21 	lsr	x1, x1, #32
    667c:	eb02003f 	cmp	x1, x2
    6680:	54000142 	b.cs	66a8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6684:	8b010294 	add	x20, x20, x1
    6688:	39400281 	ldrb	w1, [x20]
    668c:	340000e1 	cbz	w1, 66a8 <fwp_drop4+0x148>
    6690:	7100043f 	cmp	w1, #0x1
    6694:	54000200 	b.eq	66d4 <fwp_drop4+0x174>  // b.none
    6698:	7103fc3f 	cmp	w1, #0xff
    669c:	54000580 	b.eq	674c <fwp_drop4+0x1ec>  // b.none
    66a0:	51000421 	sub	w1, w1, #0x1
    66a4:	39000281 	strb	w1, [x20]
    66a8:	f9400a74 	ldr	x20, [x19, #16]
    66ac:	aa1303e0 	mov	x0, x19
    66b0:	97fffcf1 	bl	5a74 <fwp_rc_free_arr>
    66b4:	911942c0 	add	x0, x22, #0x650
    66b8:	f949d801 	ldr	x1, [x0, #5040]
    66bc:	f949ec00 	ldr	x0, [x0, #5080]
    66c0:	cb010281 	sub	x1, x20, x1
    66c4:	eb00403f 	cmp	x1, x0, lsl #16
    66c8:	54fff9a2 	b.cs	65fc <fwp_drop4+0x9c>  // b.hs, b.nlast
    66cc:	aa1403f3 	mov	x19, x20
    66d0:	17ffffb0 	b	6590 <fwp_drop4+0x30>
    66d4:	97fffce8 	bl	5a74 <fwp_rc_free_arr>
    66d8:	17fffff4 	b	66a8 <fwp_drop4+0x148>
    66dc:	72003c3f 	tst	w1, #0xffff
    66e0:	54fffe41 	b.ne	66a8 <fwp_drop4+0x148>  // b.any
    66e4:	17ffffe9 	b	6688 <fwp_drop4+0x128>
    66e8:	ca544681 	eor	x1, x20, x20, lsr #17
    66ec:	911942c0 	add	x0, x22, #0x650
    66f0:	ca412421 	eor	x1, x1, x1, lsr #9
    66f4:	8b210c01 	add	x1, x0, w1, uxtb #3
    66f8:	f94a2420 	ldr	x0, [x1, #5192]
    66fc:	b5000080 	cbnz	x0, 670c <fwp_drop4+0x1ac>
    6700:	14000010 	b	6740 <fwp_drop4+0x1e0>
    6704:	f9400800 	ldr	x0, [x0, #16]
    6708:	b40001c0 	cbz	x0, 6740 <fwp_drop4+0x1e0>
    670c:	f9400001 	ldr	x1, [x0]
    6710:	eb14003f 	cmp	x1, x20
    6714:	54ffff81 	b.ne	6704 <fwp_drop4+0x1a4>  // b.any
    6718:	f9400401 	ldr	x1, [x0, #8]
    671c:	d1000421 	sub	x1, x1, #0x1
    6720:	f9000401 	str	x1, [x0, #8]
    6724:	f103f83f 	cmp	x1, #0xfe
    6728:	54fff6a1 	b.ne	65fc <fwp_drop4+0x9c>  // b.any
    672c:	aa1403e0 	mov	x0, x20
    6730:	97fff8cc 	bl	4a60 <fwp_rc_forget_slot>
    6734:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6738:	39000280 	strb	w0, [x20]
    673c:	17ffffb0 	b	65fc <fwp_drop4+0x9c>
    6740:	f0000020 	adrp	x0, d000 <__modti3+0x30>
    6744:	9120c000 	add	x0, x0, #0x830
    6748:	97fff42e 	bl	3800 <fwp_trap>
    674c:	ca544680 	eor	x0, x20, x20, lsr #17
    6750:	911942c1 	add	x1, x22, #0x650
    6754:	ca402400 	eor	x0, x0, x0, lsr #9
    6758:	8b200c20 	add	x0, x1, w0, uxtb #3
    675c:	f94a2400 	ldr	x0, [x0, #5192]
    6760:	b5000080 	cbnz	x0, 6770 <fwp_drop4+0x210>
    6764:	17fffff7 	b	6740 <fwp_drop4+0x1e0>
    6768:	f9400800 	ldr	x0, [x0, #16]
    676c:	b4fffea0 	cbz	x0, 6740 <fwp_drop4+0x1e0>
    6770:	f9400001 	ldr	x1, [x0]
    6774:	eb14003f 	cmp	x1, x20
    6778:	54ffff81 	b.ne	6768 <fwp_drop4+0x208>  // b.any
    677c:	f9400401 	ldr	x1, [x0, #8]
    6780:	d1000421 	sub	x1, x1, #0x1
    6784:	f9000401 	str	x1, [x0, #8]
    6788:	f103f83f 	cmp	x1, #0xfe
    678c:	54fff8e1 	b.ne	66a8 <fwp_drop4+0x148>  // b.any
    6790:	aa1403e0 	mov	x0, x20
    6794:	97fff8b3 	bl	4a60 <fwp_rc_forget_slot>
    6798:	12800020 	mov	w0, #0xfffffffe            	// #-2
    679c:	39000280 	strb	w0, [x20]
    67a0:	17ffffc2 	b	66a8 <fwp_drop4+0x148>

00000000000067a4 <fwp_arg_drop37>:
    67a4:	7100003f 	cmp	w1, #0x0
    67a8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    67ac:	54000041 	b.ne	67b4 <fwp_arg_drop37+0x10>  // b.any
    67b0:	d65f03c0 	ret
    67b4:	f9400000 	ldr	x0, [x0]
    67b8:	17ffff6a 	b	6560 <fwp_drop4>
    67bc:	d503201f 	nop

00000000000067c0 <fwp_task_dispose>:
    67c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67c4:	910003fd 	mov	x29, sp
    67c8:	f9000bf3 	str	x19, [sp, #16]
    67cc:	aa0003f3 	mov	x19, x0
    67d0:	39414000 	ldrb	w0, [x0, #80]
    67d4:	36000720 	tbz	w0, #0, 68b8 <fwp_task_dispose+0xf8>
    67d8:	f9400a60 	ldr	x0, [x19, #16]
    67dc:	b50006e0 	cbnz	x0, 68b8 <fwp_task_dispose+0xf8>
    67e0:	a9478660 	ldp	x0, x1, [x19, #120]
    67e4:	39014e7f 	strb	wzr, [x19, #83]
    67e8:	f9003e7f 	str	xzr, [x19, #120]
    67ec:	f100003f 	cmp	x1, #0x0
    67f0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    67f4:	54000040 	b.eq	67fc <fwp_task_dispose+0x3c>  // b.none
    67f8:	d63f0020 	blr	x1
    67fc:	f9405660 	ldr	x0, [x19, #168]
    6800:	97fff938 	bl	4ce0 <fwp_mem_free>
    6804:	f900567f 	str	xzr, [x19, #168]
    6808:	b9405e60 	ldr	w0, [x19, #92]
    680c:	7100041f 	cmp	w0, #0x1
    6810:	54000420 	b.eq	6894 <fwp_task_dispose+0xd4>  // b.none
    6814:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xb90>
    6818:	91194042 	add	x2, x2, #0x650
    681c:	f949d840 	ldr	x0, [x2, #5040]
    6820:	f949ec41 	ldr	x1, [x2, #5080]
    6824:	cb000260 	sub	x0, x19, x0
    6828:	eb01401f 	cmp	x0, x1, lsl #16
    682c:	540002e2 	b.cs	6888 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6830:	d350fc01 	lsr	x1, x0, #16
    6834:	f949fc44 	ldr	x4, [x2, #5112]
    6838:	8b010821 	add	x1, x1, x1, lsl #2
    683c:	d37df021 	lsl	x1, x1, #3
    6840:	8b010083 	add	x3, x4, x1
    6844:	f9401062 	ldr	x2, [x3, #32]
    6848:	b4000202 	cbz	x2, 6888 <fwp_task_dispose+0xc8>
    684c:	38616881 	ldrb	w1, [x4, x1]
    6850:	7100083f 	cmp	w1, #0x2
    6854:	54000280 	b.eq	68a4 <fwp_task_dispose+0xe4>  // b.none
    6858:	7100043f 	cmp	w1, #0x1
    685c:	54000161 	b.ne	6888 <fwp_task_dispose+0xc8>  // b.any
    6860:	29430464 	ldp	w4, w1, [x3, #24]
    6864:	92403c00 	and	x0, x0, #0xffff
    6868:	9b047c00 	mul	x0, x0, x4
    686c:	d360fc00 	lsr	x0, x0, #32
    6870:	eb01001f 	cmp	x0, x1
    6874:	540000a2 	b.cs	6888 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6878:	8b000042 	add	x2, x2, x0
    687c:	39400040 	ldrb	w0, [x2]
    6880:	7100041f 	cmp	w0, #0x1
    6884:	54000080 	b.eq	6894 <fwp_task_dispose+0xd4>  // b.none
    6888:	f9400bf3 	ldr	x19, [sp, #16]
    688c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6890:	d65f03c0 	ret
    6894:	aa1303e0 	mov	x0, x19
    6898:	f9400bf3 	ldr	x19, [sp, #16]
    689c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68a0:	17fff910 	b	4ce0 <fwp_mem_free>
    68a4:	72003c1f 	tst	w0, #0xffff
    68a8:	54fffea0 	b.eq	687c <fwp_task_dispose+0xbc>  // b.none
    68ac:	f9400bf3 	ldr	x19, [sp, #16]
    68b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68b4:	d65f03c0 	ret
    68b8:	97fff00e 	bl	28f0 <abort@plt>
    68bc:	d503201f 	nop

00000000000068c0 <fwp_free_zombie>:
    68c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    68c4:	910003fd 	mov	x29, sp
    68c8:	a90153f3 	stp	x19, x20, [sp, #16]
    68cc:	d00000d4 	adrp	x20, 20000 <__data_start>
    68d0:	91014281 	add	x1, x20, #0x50
    68d4:	f940c433 	ldr	x19, [x1, #392]
    68d8:	b4000333 	cbz	x19, 693c <fwp_free_zombie+0x7c>
    68dc:	f9404c20 	ldr	x0, [x1, #152]
    68e0:	eb00027f 	cmp	x19, x0
    68e4:	540002c0 	b.eq	693c <fwp_free_zombie+0x7c>  // b.none
    68e8:	b9419022 	ldr	w2, [x1, #400]
    68ec:	f9400a60 	ldr	x0, [x19, #16]
    68f0:	7100fc5f 	cmp	w2, #0x3f
    68f4:	5400078c 	b.gt	69e4 <fwp_free_zombie+0x124>
    68f8:	91068023 	add	x3, x1, #0x1a0
    68fc:	11000444 	add	w4, w2, #0x1
    6900:	b9019024 	str	w4, [x1, #400]
    6904:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6908:	f822d860 	str	x0, [x3, w2, sxtw #3]
    690c:	a9530261 	ldp	x1, x0, [x19, #304]
    6910:	b4000741 	cbz	x1, 69f8 <fwp_free_zombie+0x138>
    6914:	f9009c20 	str	x0, [x1, #312]
    6918:	b4000040 	cbz	x0, 6920 <fwp_free_zombie+0x60>
    691c:	f9009801 	str	x1, [x0, #304]
    6920:	91014294 	add	x20, x20, #0x50
    6924:	b9405e60 	ldr	w0, [x19, #92]
    6928:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    692c:	f900c69f 	str	xzr, [x20, #392]
    6930:	34000140 	cbz	w0, 6958 <fwp_free_zombie+0x98>
    6934:	7100041f 	cmp	w0, #0x1
    6938:	54000080 	b.eq	6948 <fwp_free_zombie+0x88>  // b.none
    693c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6940:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6944:	d65f03c0 	ret
    6948:	aa1303e0 	mov	x0, x19
    694c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6950:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6954:	17ffff9b 	b	67c0 <fwp_task_dispose>
    6958:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xb90>
    695c:	91194082 	add	x2, x4, #0x650
    6960:	f949d841 	ldr	x1, [x2, #5040]
    6964:	f949ec40 	ldr	x0, [x2, #5080]
    6968:	cb010261 	sub	x1, x19, x1
    696c:	eb00403f 	cmp	x1, x0, lsl #16
    6970:	54fffe62 	b.cs	693c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6974:	d350fc20 	lsr	x0, x1, #16
    6978:	f949fc43 	ldr	x3, [x2, #5112]
    697c:	8b000800 	add	x0, x0, x0, lsl #2
    6980:	d37df000 	lsl	x0, x0, #3
    6984:	8b000062 	add	x2, x3, x0
    6988:	f9401054 	ldr	x20, [x2, #32]
    698c:	b4fffd94 	cbz	x20, 693c <fwp_free_zombie+0x7c>
    6990:	38606860 	ldrb	w0, [x3, x0]
    6994:	7100081f 	cmp	w0, #0x2
    6998:	54000360 	b.eq	6a04 <fwp_free_zombie+0x144>  // b.none
    699c:	7100041f 	cmp	w0, #0x1
    69a0:	54fffce1 	b.ne	693c <fwp_free_zombie+0x7c>  // b.any
    69a4:	29430043 	ldp	w3, w0, [x2, #24]
    69a8:	92403c21 	and	x1, x1, #0xffff
    69ac:	9b037c21 	mul	x1, x1, x3
    69b0:	d360fc21 	lsr	x1, x1, #32
    69b4:	eb00003f 	cmp	x1, x0
    69b8:	54fffc22 	b.cs	693c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    69bc:	8b010294 	add	x20, x20, x1
    69c0:	39400280 	ldrb	w0, [x20]
    69c4:	34fffbc0 	cbz	w0, 693c <fwp_free_zombie+0x7c>
    69c8:	7100041f 	cmp	w0, #0x1
    69cc:	54fffbe0 	b.eq	6948 <fwp_free_zombie+0x88>  // b.none
    69d0:	7103fc1f 	cmp	w0, #0xff
    69d4:	540001e0 	b.eq	6a10 <fwp_free_zombie+0x150>  // b.none
    69d8:	51000400 	sub	w0, w0, #0x1
    69dc:	39000280 	strb	w0, [x20]
    69e0:	17ffffd7 	b	693c <fwp_free_zombie+0x7c>
    69e4:	f9400e61 	ldr	x1, [x19, #24]
    69e8:	97ffeff6 	bl	29c0 <munmap@plt>
    69ec:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69f0:	a9530261 	ldp	x1, x0, [x19, #304]
    69f4:	b5fff901 	cbnz	x1, 6914 <fwp_free_zombie+0x54>
    69f8:	91014282 	add	x2, x20, #0x50
    69fc:	f901d040 	str	x0, [x2, #928]
    6a00:	17ffffc6 	b	6918 <fwp_free_zombie+0x58>
    6a04:	72003c3f 	tst	w1, #0xffff
    6a08:	54fff9a1 	b.ne	693c <fwp_free_zombie+0x7c>  // b.any
    6a0c:	17ffffed 	b	69c0 <fwp_free_zombie+0x100>
    6a10:	ca544680 	eor	x0, x20, x20, lsr #17
    6a14:	91194084 	add	x4, x4, #0x650
    6a18:	ca402400 	eor	x0, x0, x0, lsr #9
    6a1c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6a20:	f94a2400 	ldr	x0, [x0, #5192]
    6a24:	b5000080 	cbnz	x0, 6a34 <fwp_free_zombie+0x174>
    6a28:	14000010 	b	6a68 <fwp_free_zombie+0x1a8>
    6a2c:	f9400800 	ldr	x0, [x0, #16]
    6a30:	b40001c0 	cbz	x0, 6a68 <fwp_free_zombie+0x1a8>
    6a34:	f9400001 	ldr	x1, [x0]
    6a38:	eb14003f 	cmp	x1, x20
    6a3c:	54ffff81 	b.ne	6a2c <fwp_free_zombie+0x16c>  // b.any
    6a40:	f9400401 	ldr	x1, [x0, #8]
    6a44:	d1000421 	sub	x1, x1, #0x1
    6a48:	f9000401 	str	x1, [x0, #8]
    6a4c:	f103f83f 	cmp	x1, #0xfe
    6a50:	54fff761 	b.ne	693c <fwp_free_zombie+0x7c>  // b.any
    6a54:	aa1403e0 	mov	x0, x20
    6a58:	97fff802 	bl	4a60 <fwp_rc_forget_slot>
    6a5c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a60:	39000280 	strb	w0, [x20]
    6a64:	17ffffb6 	b	693c <fwp_free_zombie+0x7c>
    6a68:	f0000020 	adrp	x0, d000 <__modti3+0x30>
    6a6c:	9120c000 	add	x0, x0, #0x830
    6a70:	97fff364 	bl	3800 <fwp_trap>

0000000000006a74 <fwp_block>:
    6a74:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a78:	910003fd 	mov	x29, sp
    6a7c:	a90153f3 	stp	x19, x20, [sp, #16]
    6a80:	d00000d3 	adrp	x19, 20000 <__data_start>
    6a84:	91014274 	add	x20, x19, #0x50
    6a88:	f9406682 	ldr	x2, [x20, #200]
    6a8c:	b4000622 	cbz	x2, 6b50 <fwp_block+0xdc>
    6a90:	91014261 	add	x1, x19, #0x50
    6a94:	f9408040 	ldr	x0, [x2, #256]
    6a98:	f9006420 	str	x0, [x1, #200]
    6a9c:	b4000680 	cbz	x0, 6b6c <fwp_block+0xf8>
    6aa0:	91014263 	add	x3, x19, #0x50
    6aa4:	3901505f 	strb	wzr, [x2, #84]
    6aa8:	f9404c64 	ldr	x4, [x3, #152]
    6aac:	eb02009f 	cmp	x4, x2
    6ab0:	54000440 	b.eq	6b38 <fwp_block+0xc4>  // b.none
    6ab4:	f941d465 	ldr	x5, [x3, #936]
    6ab8:	f9004c62 	str	x2, [x3, #152]
    6abc:	f9400441 	ldr	x1, [x2, #8]
    6ac0:	f9004885 	str	x5, [x4, #144]
    6ac4:	f941d865 	ldr	x5, [x3, #944]
    6ac8:	f9004c85 	str	x5, [x4, #152]
    6acc:	f941dc65 	ldr	x5, [x3, #952]
    6ad0:	f9005085 	str	x5, [x4, #160]
    6ad4:	f941e065 	ldr	x5, [x3, #960]
    6ad8:	f9005485 	str	x5, [x4, #168]
    6adc:	f941e465 	ldr	x5, [x3, #968]
    6ae0:	f9005885 	str	x5, [x4, #176]
    6ae4:	f941e865 	ldr	x5, [x3, #976]
    6ae8:	f9005c85 	str	x5, [x4, #184]
    6aec:	f941ec65 	ldr	x5, [x3, #984]
    6af0:	f9006085 	str	x5, [x4, #192]
    6af4:	f9400480 	ldr	x0, [x4, #8]
    6af8:	f9404844 	ldr	x4, [x2, #144]
    6afc:	f901d464 	str	x4, [x3, #936]
    6b00:	f9404c44 	ldr	x4, [x2, #152]
    6b04:	f901d864 	str	x4, [x3, #944]
    6b08:	f9405044 	ldr	x4, [x2, #160]
    6b0c:	f901dc64 	str	x4, [x3, #952]
    6b10:	f9405444 	ldr	x4, [x2, #168]
    6b14:	f901e064 	str	x4, [x3, #960]
    6b18:	f9405844 	ldr	x4, [x2, #176]
    6b1c:	f901e464 	str	x4, [x3, #968]
    6b20:	a94b8844 	ldp	x4, x2, [x2, #184]
    6b24:	f901e864 	str	x4, [x3, #976]
    6b28:	f901ec62 	str	x2, [x3, #984]
    6b2c:	97ffef75 	bl	2900 <swapcontext@plt>
    6b30:	97ffff64 	bl	68c0 <fwp_free_zombie>
    6b34:	d503201f 	nop
    6b38:	91014260 	add	x0, x19, #0x50
    6b3c:	b943e000 	ldr	w0, [x0, #992]
    6b40:	340001a0 	cbz	w0, 6b74 <fwp_block+0x100>
    6b44:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b48:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b4c:	d65f03c0 	ret
    6b50:	97fff6f1 	bl	4714 <fwp_poll_events>
    6b54:	f9406682 	ldr	x2, [x20, #200]
    6b58:	b4ffffc2 	cbz	x2, 6b50 <fwp_block+0xdc>
    6b5c:	91014261 	add	x1, x19, #0x50
    6b60:	f9408040 	ldr	x0, [x2, #256]
    6b64:	f9006420 	str	x0, [x1, #200]
    6b68:	b5fff9c0 	cbnz	x0, 6aa0 <fwp_block+0x2c>
    6b6c:	f900603f 	str	xzr, [x1, #192]
    6b70:	17ffffcc 	b	6aa0 <fwp_block+0x2c>
    6b74:	f0000020 	adrp	x0, d000 <__modti3+0x30>
    6b78:	91258000 	add	x0, x0, #0x960
    6b7c:	97ffefad 	bl	2a30 <getenv@plt>
    6b80:	5284e202 	mov	w2, #0x2710                	// #10000
    6b84:	b4000060 	cbz	x0, 6b90 <fwp_block+0x11c>
    6b88:	39400001 	ldrb	w1, [x0]
    6b8c:	350000c1 	cbnz	w1, 6ba4 <fwp_block+0x130>
    6b90:	91014273 	add	x19, x19, #0x50
    6b94:	b903e262 	str	w2, [x19, #992]
    6b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ba0:	d65f03c0 	ret
    6ba4:	52800142 	mov	w2, #0xa                   	// #10
    6ba8:	d2800001 	mov	x1, #0x0                   	// #0
    6bac:	97ffeef1 	bl	2770 <strtoll@plt>
    6bb0:	d1000403 	sub	x3, x0, #0x1
    6bb4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6bb8:	eb02007f 	cmp	x3, x2
    6bbc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6bc0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6bc4:	17fffff3 	b	6b90 <fwp_block+0x11c>
    6bc8:	d503201f 	nop
    6bcc:	d503201f 	nop

0000000000006bd0 <fwp_drop10>:
    6bd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6bd4:	910003fd 	mov	x29, sp
    6bd8:	a90153f3 	stp	x19, x20, [sp, #16]
    6bdc:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xb90>
    6be0:	f90013f5 	str	x21, [sp, #32]
    6be4:	91194275 	add	x21, x19, #0x650
    6be8:	f949daa1 	ldr	x1, [x21, #5040]
    6bec:	f949eea2 	ldr	x2, [x21, #5080]
    6bf0:	cb010001 	sub	x1, x0, x1
    6bf4:	eb02403f 	cmp	x1, x2, lsl #16
    6bf8:	54000382 	b.cs	6c68 <fwp_drop10+0x98>  // b.hs, b.nlast
    6bfc:	d350fc22 	lsr	x2, x1, #16
    6c00:	f949fea3 	ldr	x3, [x21, #5112]
    6c04:	8b020842 	add	x2, x2, x2, lsl #2
    6c08:	d37df042 	lsl	x2, x2, #3
    6c0c:	8b020064 	add	x4, x3, x2
    6c10:	f9401094 	ldr	x20, [x4, #32]
    6c14:	b40002b4 	cbz	x20, 6c68 <fwp_drop10+0x98>
    6c18:	38626862 	ldrb	w2, [x3, x2]
    6c1c:	7100085f 	cmp	w2, #0x2
    6c20:	540007a0 	b.eq	6d14 <fwp_drop10+0x144>  // b.none
    6c24:	7100045f 	cmp	w2, #0x1
    6c28:	54000201 	b.ne	6c68 <fwp_drop10+0x98>  // b.any
    6c2c:	29430885 	ldp	w5, w2, [x4, #24]
    6c30:	92403c21 	and	x1, x1, #0xffff
    6c34:	9b057c21 	mul	x1, x1, x5
    6c38:	d360fc21 	lsr	x1, x1, #32
    6c3c:	eb02003f 	cmp	x1, x2
    6c40:	54000142 	b.cs	6c68 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c44:	8b010294 	add	x20, x20, x1
    6c48:	39400281 	ldrb	w1, [x20]
    6c4c:	340000e1 	cbz	w1, 6c68 <fwp_drop10+0x98>
    6c50:	7100043f 	cmp	w1, #0x1
    6c54:	54000120 	b.eq	6c78 <fwp_drop10+0xa8>  // b.none
    6c58:	7103fc3f 	cmp	w1, #0xff
    6c5c:	540007c0 	b.eq	6d54 <fwp_drop10+0x184>  // b.none
    6c60:	51000421 	sub	w1, w1, #0x1
    6c64:	39000281 	strb	w1, [x20]
    6c68:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c6c:	f94013f5 	ldr	x21, [sp, #32]
    6c70:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c74:	d65f03c0 	ret
    6c78:	f9400001 	ldr	x1, [x0]
    6c7c:	b7f80581 	tbnz	x1, #63, 6d2c <fwp_drop10+0x15c>
    6c80:	91194273 	add	x19, x19, #0x650
    6c84:	f949da61 	ldr	x1, [x19, #5040]
    6c88:	f949ee62 	ldr	x2, [x19, #5080]
    6c8c:	cb010001 	sub	x1, x0, x1
    6c90:	eb02403f 	cmp	x1, x2, lsl #16
    6c94:	54fffea2 	b.cs	6c68 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c98:	d350fc22 	lsr	x2, x1, #16
    6c9c:	8b020842 	add	x2, x2, x2, lsl #2
    6ca0:	d37df042 	lsl	x2, x2, #3
    6ca4:	8b020065 	add	x5, x3, x2
    6ca8:	f94010a4 	ldr	x4, [x5, #32]
    6cac:	b4fffde4 	cbz	x4, 6c68 <fwp_drop10+0x98>
    6cb0:	38626862 	ldrb	w2, [x3, x2]
    6cb4:	7100085f 	cmp	w2, #0x2
    6cb8:	54000220 	b.eq	6cfc <fwp_drop10+0x12c>  // b.none
    6cbc:	7100045f 	cmp	w2, #0x1
    6cc0:	54fffd41 	b.ne	6c68 <fwp_drop10+0x98>  // b.any
    6cc4:	294308a3 	ldp	w3, w2, [x5, #24]
    6cc8:	92403c21 	and	x1, x1, #0xffff
    6ccc:	9b037c21 	mul	x1, x1, x3
    6cd0:	d360fc21 	lsr	x1, x1, #32
    6cd4:	eb02003f 	cmp	x1, x2
    6cd8:	54fffc82 	b.cs	6c68 <fwp_drop10+0x98>  // b.hs, b.nlast
    6cdc:	8b010084 	add	x4, x4, x1
    6ce0:	39400081 	ldrb	w1, [x4]
    6ce4:	7100043f 	cmp	w1, #0x1
    6ce8:	54fffc01 	b.ne	6c68 <fwp_drop10+0x98>  // b.any
    6cec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cf0:	f94013f5 	ldr	x21, [sp, #32]
    6cf4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6cf8:	17fff7fa 	b	4ce0 <fwp_mem_free>
    6cfc:	72003c3f 	tst	w1, #0xffff
    6d00:	54ffff00 	b.eq	6ce0 <fwp_drop10+0x110>  // b.none
    6d04:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d08:	f94013f5 	ldr	x21, [sp, #32]
    6d0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d10:	d65f03c0 	ret
    6d14:	72003c3f 	tst	w1, #0xffff
    6d18:	54fff980 	b.eq	6c48 <fwp_drop10+0x78>  // b.none
    6d1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d20:	f94013f5 	ldr	x21, [sp, #32]
    6d24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d28:	d65f03c0 	ret
    6d2c:	f9400414 	ldr	x20, [x0, #8]
    6d30:	97fffb51 	bl	5a74 <fwp_rc_free_arr>
    6d34:	91194260 	add	x0, x19, #0x650
    6d38:	f949d801 	ldr	x1, [x0, #5040]
    6d3c:	f949ec00 	ldr	x0, [x0, #5080]
    6d40:	cb010281 	sub	x1, x20, x1
    6d44:	eb00403f 	cmp	x1, x0, lsl #16
    6d48:	54fff902 	b.cs	6c68 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d4c:	aa1403e0 	mov	x0, x20
    6d50:	17ffffab 	b	6bfc <fwp_drop10+0x2c>
    6d54:	ca544680 	eor	x0, x20, x20, lsr #17
    6d58:	91194273 	add	x19, x19, #0x650
    6d5c:	ca402400 	eor	x0, x0, x0, lsr #9
    6d60:	8b200e60 	add	x0, x19, w0, uxtb #3
    6d64:	f94a2400 	ldr	x0, [x0, #5192]
    6d68:	b5000080 	cbnz	x0, 6d78 <fwp_drop10+0x1a8>
    6d6c:	14000010 	b	6dac <fwp_drop10+0x1dc>
    6d70:	f9400800 	ldr	x0, [x0, #16]
    6d74:	b40001c0 	cbz	x0, 6dac <fwp_drop10+0x1dc>
    6d78:	f9400001 	ldr	x1, [x0]
    6d7c:	eb14003f 	cmp	x1, x20
    6d80:	54ffff81 	b.ne	6d70 <fwp_drop10+0x1a0>  // b.any
    6d84:	f9400401 	ldr	x1, [x0, #8]
    6d88:	d1000421 	sub	x1, x1, #0x1
    6d8c:	f9000401 	str	x1, [x0, #8]
    6d90:	f103f83f 	cmp	x1, #0xfe
    6d94:	54fff6a1 	b.ne	6c68 <fwp_drop10+0x98>  // b.any
    6d98:	aa1403e0 	mov	x0, x20
    6d9c:	97fff731 	bl	4a60 <fwp_rc_forget_slot>
    6da0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6da4:	39000280 	strb	w0, [x20]
    6da8:	17ffffb0 	b	6c68 <fwp_drop10+0x98>
    6dac:	f0000020 	adrp	x0, d000 <__modti3+0x30>
    6db0:	9120c000 	add	x0, x0, #0x830
    6db4:	97fff293 	bl	3800 <fwp_trap>
    6db8:	d503201f 	nop
    6dbc:	d503201f 	nop

0000000000006dc0 <fwp_caps173>:
    6dc0:	34000041 	cbz	w1, 6dc8 <fwp_caps173+0x8>
    6dc4:	d65f03c0 	ret
    6dc8:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xb90>
    6dcc:	91194063 	add	x3, x3, #0x650
    6dd0:	f949d861 	ldr	x1, [x3, #5040]
    6dd4:	f949ec62 	ldr	x2, [x3, #5080]
    6dd8:	cb010001 	sub	x1, x0, x1
    6ddc:	eb02403f 	cmp	x1, x2, lsl #16
    6de0:	54ffff22 	b.cs	6dc4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6de4:	d350fc22 	lsr	x2, x1, #16
    6de8:	f949fc65 	ldr	x5, [x3, #5112]
    6dec:	8b020842 	add	x2, x2, x2, lsl #2
    6df0:	d37df042 	lsl	x2, x2, #3
    6df4:	8b0200a4 	add	x4, x5, x2
    6df8:	f9401083 	ldr	x3, [x4, #32]
    6dfc:	b4fffe43 	cbz	x3, 6dc4 <fwp_caps173+0x4>
    6e00:	386268a2 	ldrb	w2, [x5, x2]
    6e04:	7100085f 	cmp	w2, #0x2
    6e08:	540001c0 	b.eq	6e40 <fwp_caps173+0x80>  // b.none
    6e0c:	7100045f 	cmp	w2, #0x1
    6e10:	54fffda1 	b.ne	6dc4 <fwp_caps173+0x4>  // b.any
    6e14:	29430885 	ldp	w5, w2, [x4, #24]
    6e18:	92403c21 	and	x1, x1, #0xffff
    6e1c:	9b057c21 	mul	x1, x1, x5
    6e20:	d360fc21 	lsr	x1, x1, #32
    6e24:	eb02003f 	cmp	x1, x2
    6e28:	54fffce2 	b.cs	6dc4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6e2c:	8b010063 	add	x3, x3, x1
    6e30:	39400061 	ldrb	w1, [x3]
    6e34:	7100043f 	cmp	w1, #0x1
    6e38:	54fffc61 	b.ne	6dc4 <fwp_caps173+0x4>  // b.any
    6e3c:	17fff7a9 	b	4ce0 <fwp_mem_free>
    6e40:	72003c3f 	tst	w1, #0xffff
    6e44:	54ffff60 	b.eq	6e30 <fwp_caps173+0x70>  // b.none
    6e48:	d65f03c0 	ret
    6e4c:	d503201f 	nop

0000000000006e50 <fwp_args37>:
    6e50:	7100003f 	cmp	w1, #0x0
    6e54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6e58:	54000041 	b.ne	6e60 <fwp_args37+0x10>  // b.any
    6e5c:	d65f03c0 	ret
    6e60:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xb90>
    6e64:	91194042 	add	x2, x2, #0x650
    6e68:	f9400001 	ldr	x1, [x0]
    6e6c:	f949d843 	ldr	x3, [x2, #5040]
    6e70:	f949ec40 	ldr	x0, [x2, #5080]
    6e74:	cb030021 	sub	x1, x1, x3
    6e78:	eb00403f 	cmp	x1, x0, lsl #16
    6e7c:	54ffff02 	b.cs	6e5c <fwp_args37+0xc>  // b.hs, b.nlast
    6e80:	d350fc20 	lsr	x0, x1, #16
    6e84:	f949fc44 	ldr	x4, [x2, #5112]
    6e88:	8b000800 	add	x0, x0, x0, lsl #2
    6e8c:	d37df002 	lsl	x2, x0, #3
    6e90:	8b020083 	add	x3, x4, x2
    6e94:	f9401060 	ldr	x0, [x3, #32]
    6e98:	b4fffe20 	cbz	x0, 6e5c <fwp_args37+0xc>
    6e9c:	38626882 	ldrb	w2, [x4, x2]
    6ea0:	7100085f 	cmp	w2, #0x2
    6ea4:	54000320 	b.eq	6f08 <fwp_args37+0xb8>  // b.none
    6ea8:	7100045f 	cmp	w2, #0x1
    6eac:	54fffd81 	b.ne	6e5c <fwp_args37+0xc>  // b.any
    6eb0:	29430864 	ldp	w4, w2, [x3, #24]
    6eb4:	92403c21 	and	x1, x1, #0xffff
    6eb8:	9b047c21 	mul	x1, x1, x4
    6ebc:	d360fc21 	lsr	x1, x1, #32
    6ec0:	eb02003f 	cmp	x1, x2
    6ec4:	54fffcc2 	b.cs	6e5c <fwp_args37+0xc>  // b.hs, b.nlast
    6ec8:	8b010000 	add	x0, x0, x1
    6ecc:	39400001 	ldrb	w1, [x0]
    6ed0:	34fffc61 	cbz	w1, 6e5c <fwp_args37+0xc>
    6ed4:	d00000c2 	adrp	x2, 20000 <__data_start>
    6ed8:	91014042 	add	x2, x2, #0x50
    6edc:	b9415043 	ldr	w3, [x2, #336]
    6ee0:	350000c3 	cbnz	w3, 6ef8 <fwp_args37+0xa8>
    6ee4:	7103f43f 	cmp	w1, #0xfd
    6ee8:	54000168 	b.hi	6f14 <fwp_args37+0xc4>  // b.pmore
    6eec:	11000421 	add	w1, w1, #0x1
    6ef0:	39000001 	strb	w1, [x0]
    6ef4:	d65f03c0 	ret
    6ef8:	f940bc43 	ldr	x3, [x2, #376]
    6efc:	91000463 	add	x3, x3, #0x1
    6f00:	f900bc43 	str	x3, [x2, #376]
    6f04:	17fffff8 	b	6ee4 <fwp_args37+0x94>
    6f08:	72003c3f 	tst	w1, #0xffff
    6f0c:	54fffe00 	b.eq	6ecc <fwp_args37+0x7c>  // b.none
    6f10:	d65f03c0 	ret
    6f14:	17fff68c 	b	4944 <fwp_rc_wide_dup>
    6f18:	d503201f 	nop
    6f1c:	d503201f 	nop

0000000000006f20 <fwp_caps37>:
    6f20:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6f24:	910003fd 	mov	x29, sp
    6f28:	f9000bf3 	str	x19, [sp, #16]
    6f2c:	aa0003f3 	mov	x19, x0
    6f30:	b9400400 	ldr	w0, [x0, #4]
    6f34:	340004a0 	cbz	w0, 6fc8 <fwp_caps37+0xa8>
    6f38:	f9400660 	ldr	x0, [x19, #8]
    6f3c:	350004e1 	cbnz	w1, 6fd8 <fwp_caps37+0xb8>
    6f40:	97fffd88 	bl	6560 <fwp_drop4>
    6f44:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xb90>
    6f48:	91194042 	add	x2, x2, #0x650
    6f4c:	f949d840 	ldr	x0, [x2, #5040]
    6f50:	f949ec41 	ldr	x1, [x2, #5080]
    6f54:	cb000260 	sub	x0, x19, x0
    6f58:	eb01401f 	cmp	x0, x1, lsl #16
    6f5c:	54000382 	b.cs	6fcc <fwp_caps37+0xac>  // b.hs, b.nlast
    6f60:	d350fc01 	lsr	x1, x0, #16
    6f64:	f949fc44 	ldr	x4, [x2, #5112]
    6f68:	8b010821 	add	x1, x1, x1, lsl #2
    6f6c:	d37df021 	lsl	x1, x1, #3
    6f70:	8b010083 	add	x3, x4, x1
    6f74:	f9401062 	ldr	x2, [x3, #32]
    6f78:	b40002a2 	cbz	x2, 6fcc <fwp_caps37+0xac>
    6f7c:	38616881 	ldrb	w1, [x4, x1]
    6f80:	7100083f 	cmp	w1, #0x2
    6f84:	54000740 	b.eq	706c <fwp_caps37+0x14c>  // b.none
    6f88:	7100043f 	cmp	w1, #0x1
    6f8c:	54000201 	b.ne	6fcc <fwp_caps37+0xac>  // b.any
    6f90:	29430464 	ldp	w4, w1, [x3, #24]
    6f94:	92403c00 	and	x0, x0, #0xffff
    6f98:	9b047c00 	mul	x0, x0, x4
    6f9c:	d360fc00 	lsr	x0, x0, #32
    6fa0:	eb01001f 	cmp	x0, x1
    6fa4:	54000142 	b.cs	6fcc <fwp_caps37+0xac>  // b.hs, b.nlast
    6fa8:	8b000042 	add	x2, x2, x0
    6fac:	39400040 	ldrb	w0, [x2]
    6fb0:	7100041f 	cmp	w0, #0x1
    6fb4:	540000c1 	b.ne	6fcc <fwp_caps37+0xac>  // b.any
    6fb8:	aa1303e0 	mov	x0, x19
    6fbc:	f9400bf3 	ldr	x19, [sp, #16]
    6fc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6fc4:	17fff747 	b	4ce0 <fwp_mem_free>
    6fc8:	34fffbe1 	cbz	w1, 6f44 <fwp_caps37+0x24>
    6fcc:	f9400bf3 	ldr	x19, [sp, #16]
    6fd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6fd4:	d65f03c0 	ret
    6fd8:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xb90>
    6fdc:	91194042 	add	x2, x2, #0x650
    6fe0:	f949d843 	ldr	x3, [x2, #5040]
    6fe4:	f949ec41 	ldr	x1, [x2, #5080]
    6fe8:	cb030000 	sub	x0, x0, x3
    6fec:	eb01401f 	cmp	x0, x1, lsl #16
    6ff0:	54fffee2 	b.cs	6fcc <fwp_caps37+0xac>  // b.hs, b.nlast
    6ff4:	d350fc01 	lsr	x1, x0, #16
    6ff8:	f949fc44 	ldr	x4, [x2, #5112]
    6ffc:	8b010821 	add	x1, x1, x1, lsl #2
    7000:	d37df021 	lsl	x1, x1, #3
    7004:	8b010083 	add	x3, x4, x1
    7008:	f9401062 	ldr	x2, [x3, #32]
    700c:	b4fffe02 	cbz	x2, 6fcc <fwp_caps37+0xac>
    7010:	38616881 	ldrb	w1, [x4, x1]
    7014:	7100083f 	cmp	w1, #0x2
    7018:	54000300 	b.eq	7078 <fwp_caps37+0x158>  // b.none
    701c:	7100043f 	cmp	w1, #0x1
    7020:	54fffd61 	b.ne	6fcc <fwp_caps37+0xac>  // b.any
    7024:	92403c01 	and	x1, x0, #0xffff
    7028:	29430064 	ldp	w4, w0, [x3, #24]
    702c:	9b047c21 	mul	x1, x1, x4
    7030:	d360fc21 	lsr	x1, x1, #32
    7034:	eb00003f 	cmp	x1, x0
    7038:	54fffca2 	b.cs	6fcc <fwp_caps37+0xac>  // b.hs, b.nlast
    703c:	8b010042 	add	x2, x2, x1
    7040:	39400040 	ldrb	w0, [x2]
    7044:	34fffc40 	cbz	w0, 6fcc <fwp_caps37+0xac>
    7048:	b00000c1 	adrp	x1, 20000 <__data_start>
    704c:	91014021 	add	x1, x1, #0x50
    7050:	b9415023 	ldr	w3, [x1, #336]
    7054:	35000183 	cbnz	w3, 7084 <fwp_caps37+0x164>
    7058:	7103f41f 	cmp	w0, #0xfd
    705c:	540001c8 	b.hi	7094 <fwp_caps37+0x174>  // b.pmore
    7060:	11000400 	add	w0, w0, #0x1
    7064:	39000040 	strb	w0, [x2]
    7068:	17ffffd9 	b	6fcc <fwp_caps37+0xac>
    706c:	72003c1f 	tst	w0, #0xffff
    7070:	54fffae1 	b.ne	6fcc <fwp_caps37+0xac>  // b.any
    7074:	17ffffce 	b	6fac <fwp_caps37+0x8c>
    7078:	72003c1f 	tst	w0, #0xffff
    707c:	54fffa81 	b.ne	6fcc <fwp_caps37+0xac>  // b.any
    7080:	17fffff0 	b	7040 <fwp_caps37+0x120>
    7084:	f940bc23 	ldr	x3, [x1, #376]
    7088:	91000463 	add	x3, x3, #0x1
    708c:	f900bc23 	str	x3, [x1, #376]
    7090:	17fffff2 	b	7058 <fwp_caps37+0x138>
    7094:	f9400bf3 	ldr	x19, [sp, #16]
    7098:	aa0203e0 	mov	x0, x2
    709c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70a0:	17fff629 	b	4944 <fwp_rc_wide_dup>

00000000000070a4 <f37>:
    70a4:	d101c3ff 	sub	sp, sp, #0x70
    70a8:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    70ac:	f947f421 	ldr	x1, [x1, #4072]
    70b0:	a9027bfd 	stp	x29, x30, [sp, #32]
    70b4:	910083fd 	add	x29, sp, #0x20
    70b8:	a90563f7 	stp	x23, x24, [sp, #80]
    70bc:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xb90>
    70c0:	911942e3 	add	x3, x23, #0x650
    70c4:	a90353f3 	stp	x19, x20, [sp, #48]
    70c8:	a9045bf5 	stp	x21, x22, [sp, #64]
    70cc:	aa0003f6 	mov	x22, x0
    70d0:	a9066bf9 	stp	x25, x26, [sp, #96]
    70d4:	f949ec62 	ldr	x2, [x3, #5080]
    70d8:	f9400024 	ldr	x4, [x1]
    70dc:	f9000fe4 	str	x4, [sp, #24]
    70e0:	d2800004 	mov	x4, #0x0                   	// #0
    70e4:	f949d861 	ldr	x1, [x3, #5040]
    70e8:	d370bc42 	lsl	x2, x2, #16
    70ec:	b40016a0 	cbz	x0, 73c0 <f37+0x31c>
    70f0:	f9400818 	ldr	x24, [x0, #16]
    70f4:	cb010301 	sub	x1, x24, x1
    70f8:	eb02003f 	cmp	x1, x2
    70fc:	540003e2 	b.cs	7178 <f37+0xd4>  // b.hs, b.nlast
    7100:	f949fc60 	ldr	x0, [x3, #5112]
    7104:	d350fc22 	lsr	x2, x1, #16
    7108:	8b020842 	add	x2, x2, x2, lsl #2
    710c:	8b020c02 	add	x2, x0, x2, lsl #3
    7110:	f9401040 	ldr	x0, [x2, #32]
    7114:	b4000320 	cbz	x0, 7178 <f37+0xd4>
    7118:	39400043 	ldrb	w3, [x2]
    711c:	7100087f 	cmp	w3, #0x2
    7120:	54001420 	b.eq	73a4 <f37+0x300>  // b.none
    7124:	7100047f 	cmp	w3, #0x1
    7128:	54000241 	b.ne	7170 <f37+0xcc>  // b.any
    712c:	29430843 	ldp	w3, w2, [x2, #24]
    7130:	92403c21 	and	x1, x1, #0xffff
    7134:	9b037c21 	mul	x1, x1, x3
    7138:	d360fc21 	lsr	x1, x1, #32
    713c:	eb02003f 	cmp	x1, x2
    7140:	54000182 	b.cs	7170 <f37+0xcc>  // b.hs, b.nlast
    7144:	8b010000 	add	x0, x0, x1
    7148:	39400001 	ldrb	w1, [x0]
    714c:	34000121 	cbz	w1, 7170 <f37+0xcc>
    7150:	b00000c2 	adrp	x2, 20000 <__data_start>
    7154:	91014042 	add	x2, x2, #0x50
    7158:	b9415043 	ldr	w3, [x2, #336]
    715c:	350012a3 	cbnz	w3, 73b0 <f37+0x30c>
    7160:	7103f43f 	cmp	w1, #0xfd
    7164:	54001708 	b.hi	7444 <f37+0x3a0>  // b.pmore
    7168:	11000421 	add	w1, w1, #0x1
    716c:	39000001 	strb	w1, [x0]
    7170:	d2800000 	mov	x0, #0x0                   	// #0
    7174:	b40000d6 	cbz	x22, 718c <f37+0xe8>
    7178:	aa1603e1 	mov	x1, x22
    717c:	d2800000 	mov	x0, #0x0                   	// #0
    7180:	f9400821 	ldr	x1, [x1, #16]
    7184:	91000400 	add	x0, x0, #0x1
    7188:	b5ffffc1 	cbnz	x1, 7180 <f37+0xdc>
    718c:	b4001238 	cbz	x24, 73d0 <f37+0x32c>
    7190:	aa1803e1 	mov	x1, x24
    7194:	d2800002 	mov	x2, #0x0                   	// #0
    7198:	f9400821 	ldr	x1, [x1, #16]
    719c:	91000442 	add	x2, x2, #0x1
    71a0:	b5ffffc1 	cbnz	x1, 7198 <f37+0xf4>
    71a4:	eb00005f 	cmp	x2, x0
    71a8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    71ac:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    71b0:	eb01033f 	cmp	x25, x1
    71b4:	540014e8 	b.hi	7450 <f37+0x3ac>  // b.pmore
    71b8:	d37ffb33 	lsl	x19, x25, #1
    71bc:	52800041 	mov	w1, #0x2                   	// #2
    71c0:	91000660 	add	x0, x19, #0x1
    71c4:	d37df000 	lsl	x0, x0, #3
    71c8:	97fff7e6 	bl	5160 <fwp_heap_alloc>
    71cc:	911942e1 	add	x1, x23, #0x650
    71d0:	aa0003fa 	mov	x26, x0
    71d4:	f9000013 	str	x19, [x0]
    71d8:	aa0103e0 	mov	x0, x1
    71dc:	f949d821 	ldr	x1, [x1, #5040]
    71e0:	f949ec00 	ldr	x0, [x0, #5080]
    71e4:	cb010341 	sub	x1, x26, x1
    71e8:	eb00403f 	cmp	x1, x0, lsl #16
    71ec:	54000342 	b.cs	7254 <f37+0x1b0>  // b.hs, b.nlast
    71f0:	911942e2 	add	x2, x23, #0x650
    71f4:	d350fc20 	lsr	x0, x1, #16
    71f8:	8b000800 	add	x0, x0, x0, lsl #2
    71fc:	f949fc43 	ldr	x3, [x2, #5112]
    7200:	d37df002 	lsl	x2, x0, #3
    7204:	8b020060 	add	x0, x3, x2
    7208:	f9401013 	ldr	x19, [x0, #32]
    720c:	b4000253 	cbz	x19, 7254 <f37+0x1b0>
    7210:	38626862 	ldrb	w2, [x3, x2]
    7214:	7100085f 	cmp	w2, #0x2
    7218:	54000c00 	b.eq	7398 <f37+0x2f4>  // b.none
    721c:	7100045f 	cmp	w2, #0x1
    7220:	540001a1 	b.ne	7254 <f37+0x1b0>  // b.any
    7224:	29430002 	ldp	w2, w0, [x0, #24]
    7228:	92403c21 	and	x1, x1, #0xffff
    722c:	9b027c21 	mul	x1, x1, x2
    7230:	d360fc21 	lsr	x1, x1, #32
    7234:	eb00003f 	cmp	x1, x0
    7238:	540000e2 	b.cs	7254 <f37+0x1b0>  // b.hs, b.nlast
    723c:	8b010273 	add	x19, x19, x1
    7240:	39400260 	ldrb	w0, [x19]
    7244:	7103fc1f 	cmp	w0, #0xff
    7248:	54000e80 	b.eq	7418 <f37+0x374>  // b.none
    724c:	52800020 	mov	w0, #0x1                   	// #1
    7250:	39000260 	strb	w0, [x19]
    7254:	b4000259 	cbz	x25, 729c <f37+0x1f8>
    7258:	8b191359 	add	x25, x26, x25, lsl #4
    725c:	aa1a03f3 	mov	x19, x26
    7260:	aa1603f5 	mov	x21, x22
    7264:	aa1803f4 	mov	x20, x24
    7268:	f9400683 	ldr	x3, [x20, #8]
    726c:	f94006a2 	ldr	x2, [x21, #8]
    7270:	f9400861 	ldr	x1, [x3, #16]
    7274:	f9400840 	ldr	x0, [x2, #16]
    7278:	fd400461 	ldr	d1, [x3, #8]
    727c:	fd400440 	ldr	d0, [x2, #8]
    7280:	97fff929 	bl	5724 <w120>
    7284:	f9000660 	str	x0, [x19, #8]
    7288:	f8010e61 	str	x1, [x19, #16]!
    728c:	f9400a94 	ldr	x20, [x20, #16]
    7290:	f9400ab5 	ldr	x21, [x21, #16]
    7294:	eb13033f 	cmp	x25, x19
    7298:	54fffe81 	b.ne	7268 <f37+0x1c4>  // b.any
    729c:	aa1803e0 	mov	x0, x24
    72a0:	97fffcb0 	bl	6560 <fwp_drop4>
    72a4:	aa1603e0 	mov	x0, x22
    72a8:	97fffcae 	bl	6560 <fwp_drop4>
    72ac:	911942f7 	add	x23, x23, #0x650
    72b0:	aa1a03e0 	mov	x0, x26
    72b4:	97fff96f 	bl	5870 <w176.constprop.0>
    72b8:	aa0103f3 	mov	x19, x1
    72bc:	aa0003f4 	mov	x20, x0
    72c0:	aa1a03e0 	mov	x0, x26
    72c4:	97fffe43 	bl	6bd0 <fwp_drop10>
    72c8:	a900cff4 	stp	x20, x19, [sp, #8]
    72cc:	910023e1 	add	x1, sp, #0x8
    72d0:	52800000 	mov	w0, #0x0                   	// #0
    72d4:	97fff804 	bl	52e4 <fwp_data.part.0.constprop.0>
    72d8:	f949dae1 	ldr	x1, [x23, #5040]
    72dc:	aa0003f3 	mov	x19, x0
    72e0:	f949eee0 	ldr	x0, [x23, #5080]
    72e4:	cb010261 	sub	x1, x19, x1
    72e8:	eb00403f 	cmp	x1, x0, lsl #16
    72ec:	54000322 	b.cs	7350 <f37+0x2ac>  // b.hs, b.nlast
    72f0:	d350fc22 	lsr	x2, x1, #16
    72f4:	f949fee3 	ldr	x3, [x23, #5112]
    72f8:	8b020842 	add	x2, x2, x2, lsl #2
    72fc:	d37df042 	lsl	x2, x2, #3
    7300:	8b020060 	add	x0, x3, x2
    7304:	f9401014 	ldr	x20, [x0, #32]
    7308:	b4000254 	cbz	x20, 7350 <f37+0x2ac>
    730c:	38626862 	ldrb	w2, [x3, x2]
    7310:	7100085f 	cmp	w2, #0x2
    7314:	540003c0 	b.eq	738c <f37+0x2e8>  // b.none
    7318:	7100045f 	cmp	w2, #0x1
    731c:	540001a1 	b.ne	7350 <f37+0x2ac>  // b.any
    7320:	29430002 	ldp	w2, w0, [x0, #24]
    7324:	92403c21 	and	x1, x1, #0xffff
    7328:	9b027c21 	mul	x1, x1, x2
    732c:	d360fc21 	lsr	x1, x1, #32
    7330:	eb00003f 	cmp	x1, x0
    7334:	540000e2 	b.cs	7350 <f37+0x2ac>  // b.hs, b.nlast
    7338:	8b010294 	add	x20, x20, x1
    733c:	39400280 	ldrb	w0, [x20]
    7340:	7103fc1f 	cmp	w0, #0xff
    7344:	54000640 	b.eq	740c <f37+0x368>  // b.none
    7348:	52800020 	mov	w0, #0x1                   	// #1
    734c:	39000280 	strb	w0, [x20]
    7350:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7354:	f947f400 	ldr	x0, [x0, #4072]
    7358:	f9400fe2 	ldr	x2, [sp, #24]
    735c:	f9400001 	ldr	x1, [x0]
    7360:	eb010042 	subs	x2, x2, x1
    7364:	d2800001 	mov	x1, #0x0                   	// #0
    7368:	54000721 	b.ne	744c <f37+0x3a8>  // b.any
    736c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7370:	aa1303e0 	mov	x0, x19
    7374:	a94353f3 	ldp	x19, x20, [sp, #48]
    7378:	a9445bf5 	ldp	x21, x22, [sp, #64]
    737c:	a94563f7 	ldp	x23, x24, [sp, #80]
    7380:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7384:	9101c3ff 	add	sp, sp, #0x70
    7388:	d65f03c0 	ret
    738c:	72003c3f 	tst	w1, #0xffff
    7390:	54fffe01 	b.ne	7350 <f37+0x2ac>  // b.any
    7394:	17ffffea 	b	733c <f37+0x298>
    7398:	72003c3f 	tst	w1, #0xffff
    739c:	54fff5c1 	b.ne	7254 <f37+0x1b0>  // b.any
    73a0:	17ffffa8 	b	7240 <f37+0x19c>
    73a4:	72003c3f 	tst	w1, #0xffff
    73a8:	54ffee41 	b.ne	7170 <f37+0xcc>  // b.any
    73ac:	17ffff67 	b	7148 <f37+0xa4>
    73b0:	f940bc43 	ldr	x3, [x2, #376]
    73b4:	91000463 	add	x3, x3, #0x1
    73b8:	f900bc43 	str	x3, [x2, #376]
    73bc:	17ffff69 	b	7160 <f37+0xbc>
    73c0:	cb0103e1 	neg	x1, x1
    73c4:	eb02003f 	cmp	x1, x2
    73c8:	540002e3 	b.cc	7424 <f37+0x380>  // b.lo, b.ul, b.last
    73cc:	d503201f 	nop
    73d0:	52800041 	mov	w1, #0x2                   	// #2
    73d4:	d2800100 	mov	x0, #0x8                   	// #8
    73d8:	97fff762 	bl	5160 <fwp_heap_alloc>
    73dc:	aa0003e1 	mov	x1, x0
    73e0:	911942e0 	add	x0, x23, #0x650
    73e4:	aa0103fa 	mov	x26, x1
    73e8:	d2800018 	mov	x24, #0x0                   	// #0
    73ec:	f900003f 	str	xzr, [x1]
    73f0:	f949d801 	ldr	x1, [x0, #5040]
    73f4:	f949ec00 	ldr	x0, [x0, #5080]
    73f8:	cb010341 	sub	x1, x26, x1
    73fc:	eb00403f 	cmp	x1, x0, lsl #16
    7400:	54fff4e2 	b.cs	729c <f37+0x1f8>  // b.hs, b.nlast
    7404:	d2800019 	mov	x25, #0x0                   	// #0
    7408:	17ffff7a 	b	71f0 <f37+0x14c>
    740c:	aa1403e0 	mov	x0, x20
    7410:	97fff594 	bl	4a60 <fwp_rc_forget_slot>
    7414:	17ffffcd 	b	7348 <f37+0x2a4>
    7418:	aa1303e0 	mov	x0, x19
    741c:	97fff591 	bl	4a60 <fwp_rc_forget_slot>
    7420:	17ffff8b 	b	724c <f37+0x1a8>
    7424:	f949fc62 	ldr	x2, [x3, #5112]
    7428:	d350fc20 	lsr	x0, x1, #16
    742c:	8b000800 	add	x0, x0, x0, lsl #2
    7430:	8b000c42 	add	x2, x2, x0, lsl #3
    7434:	f9401040 	ldr	x0, [x2, #32]
    7438:	b4fffcc0 	cbz	x0, 73d0 <f37+0x32c>
    743c:	d2800018 	mov	x24, #0x0                   	// #0
    7440:	17ffff36 	b	7118 <f37+0x74>
    7444:	97fff540 	bl	4944 <fwp_rc_wide_dup>
    7448:	17ffff4a 	b	7170 <f37+0xcc>
    744c:	97ffed15 	bl	28a0 <__stack_chk_fail@plt>
    7450:	d0000020 	adrp	x0, d000 <__modti3+0x30>
    7454:	9125c000 	add	x0, x0, #0x970
    7458:	97fff0ea 	bl	3800 <fwp_trap>
    745c:	d503201f 	nop

0000000000007460 <fwp_owned_entry37>:
    7460:	f9400000 	ldr	x0, [x0]
    7464:	17ffff10 	b	70a4 <f37>
    7468:	d503201f 	nop
    746c:	d503201f 	nop

0000000000007470 <e37>:
    7470:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7474:	910003fd 	mov	x29, sp
    7478:	f9000bf3 	str	x19, [sp, #16]
    747c:	f9400013 	ldr	x19, [x0]
    7480:	aa1303e0 	mov	x0, x19
    7484:	97fff927 	bl	5920 <fwp_rc_share>
    7488:	aa1303e0 	mov	x0, x19
    748c:	97ffff06 	bl	70a4 <f37>
    7490:	aa0003f3 	mov	x19, x0
    7494:	97fff923 	bl	5920 <fwp_rc_share>
    7498:	aa1303e0 	mov	x0, x19
    749c:	f9400bf3 	ldr	x19, [sp, #16]
    74a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    74a4:	d65f03c0 	ret
    74a8:	d503201f 	nop
    74ac:	d503201f 	nop

00000000000074b0 <fwp_write>:
    74b0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    74b4:	910003fd 	mov	x29, sp
    74b8:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    74bc:	f947f484 	ldr	x4, [x4, #4072]
    74c0:	a90153f3 	stp	x19, x20, [sp, #16]
    74c4:	d10943ff 	sub	sp, sp, #0x250
    74c8:	b9400045 	ldr	w5, [x2]
    74cc:	aa0003f4 	mov	x20, x0
    74d0:	f9400080 	ldr	x0, [x4]
    74d4:	f90127e0 	str	x0, [sp, #584]
    74d8:	d2800000 	mov	x0, #0x0                   	// #0
    74dc:	710064bf 	cmp	w5, #0x19
    74e0:	54000408 	b.hi	7560 <fwp_write+0xb0>  // b.pmore
    74e4:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0xc90>
    74e8:	aa0103f3 	mov	x19, x1
    74ec:	910b0000 	add	x0, x0, #0x2c0
    74f0:	f9013bf5 	str	x21, [sp, #624]
    74f4:	f9013ff6 	str	x22, [sp, #632]
    74f8:	f90153fb 	str	x27, [sp, #672]
    74fc:	f90157fc 	str	x28, [sp, #680]
    7500:	aa0203fc 	mov	x28, x2
    7504:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7508:	10000061 	adr	x1, 7514 <fwp_write+0x64>
    750c:	8b20a820 	add	x0, x1, w0, sxth #2
    7510:	d61f0000 	br	x0
    7514:	910123e0 	add	x0, sp, #0x48
    7518:	aa1303e5 	mov	x5, x19
    751c:	d0000024 	adrp	x4, d000 <__modti3+0x30>
    7520:	aa0003f3 	mov	x19, x0
    7524:	9126e084 	add	x4, x4, #0x9b8
    7528:	d2804003 	mov	x3, #0x200                 	// #512
    752c:	aa0303e1 	mov	x1, x3
    7530:	52800042 	mov	w2, #0x2                   	// #2
    7534:	97ffecb7 	bl	2810 <__snprintf_chk@plt>
    7538:	aa1303e0 	mov	x0, x19
    753c:	97ffec7d 	bl	2730 <strlen@plt>
    7540:	aa1303e1 	mov	x1, x19
    7544:	aa0003e2 	mov	x2, x0
    7548:	aa1403e0 	mov	x0, x20
    754c:	97fff051 	bl	3690 <buf_put>
    7550:	f9413bf5 	ldr	x21, [sp, #624]
    7554:	f9413ff6 	ldr	x22, [sp, #632]
    7558:	f94153fb 	ldr	x27, [sp, #672]
    755c:	f94157fc 	ldr	x28, [sp, #680]
    7560:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7564:	f947f400 	ldr	x0, [x0, #4072]
    7568:	f94127e2 	ldr	x2, [sp, #584]
    756c:	f9400001 	ldr	x1, [x0]
    7570:	eb010042 	subs	x2, x2, x1
    7574:	d2800001 	mov	x1, #0x0                   	// #0
    7578:	540077c1 	b.ne	8470 <fwp_write+0xfc0>  // b.any
    757c:	910943ff 	add	sp, sp, #0x250
    7580:	a94153f3 	ldp	x19, x20, [sp, #16]
    7584:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7588:	d65f03c0 	ret
    758c:	910123e0 	add	x0, sp, #0x48
    7590:	aa1303e5 	mov	x5, x19
    7594:	d0000024 	adrp	x4, d000 <__modti3+0x30>
    7598:	aa0003f3 	mov	x19, x0
    759c:	9126c084 	add	x4, x4, #0x9b0
    75a0:	d2804003 	mov	x3, #0x200                 	// #512
    75a4:	17ffffe2 	b	752c <fwp_write+0x7c>
    75a8:	71004cbf 	cmp	w5, #0x13
    75ac:	d0000020 	adrp	x0, d000 <__modti3+0x30>
    75b0:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    75b4:	91268000 	add	x0, x0, #0x9a0
    75b8:	9126a021 	add	x1, x1, #0x9a8
    75bc:	d2800082 	mov	x2, #0x4                   	// #4
    75c0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    75c4:	aa1403e0 	mov	x0, x20
    75c8:	f90143f7 	str	x23, [sp, #640]
    75cc:	d2800016 	mov	x22, #0x0                   	// #0
    75d0:	f90147f8 	str	x24, [sp, #648]
    75d4:	97fff02f 	bl	3690 <buf_put>
    75d8:	f9400260 	ldr	x0, [x19]
    75dc:	d0000037 	adrp	x23, d000 <__modti3+0x30>
    75e0:	d2800015 	mov	x21, #0x0                   	// #0
    75e4:	9128a2f7 	add	x23, x23, #0xa28
    75e8:	b40047a0 	cbz	x0, 7edc <fwp_write+0xa2c>
    75ec:	b9400380 	ldr	w0, [x28]
    75f0:	52800003 	mov	w3, #0x0                   	// #0
    75f4:	f9401f82 	ldr	x2, [x28, #56]
    75f8:	71004c1f 	cmp	w0, #0x13
    75fc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7600:	aa1403e0 	mov	x0, x20
    7604:	8b010e61 	add	x1, x19, x1, lsl #3
    7608:	f9400421 	ldr	x1, [x1, #8]
    760c:	97ffffa9 	bl	74b0 <fwp_write>
    7610:	b9400380 	ldr	w0, [x28]
    7614:	7100481f 	cmp	w0, #0x12
    7618:	54004b40 	b.eq	7f80 <fwp_write+0xad0>  // b.none
    761c:	f9400260 	ldr	x0, [x19]
    7620:	910006b5 	add	x21, x21, #0x1
    7624:	91000ad6 	add	x22, x22, #0x2
    7628:	eb15001f 	cmp	x0, x21
    762c:	54004589 	b.ls	7edc <fwp_write+0xa2c>  // b.plast
    7630:	aa1703e1 	mov	x1, x23
    7634:	aa1403e0 	mov	x0, x20
    7638:	d2800042 	mov	x2, #0x2                   	// #2
    763c:	97fff015 	bl	3690 <buf_put>
    7640:	17ffffeb 	b	75ec <fwp_write+0x13c>
    7644:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    7648:	91278021 	add	x1, x1, #0x9e0
    764c:	d28000c2 	mov	x2, #0x6                   	// #6
    7650:	aa1403e0 	mov	x0, x20
    7654:	91004273 	add	x19, x19, #0x10
    7658:	97fff00e 	bl	3690 <buf_put>
    765c:	aa1303e0 	mov	x0, x19
    7660:	97ffec34 	bl	2730 <strlen@plt>
    7664:	aa1303e1 	mov	x1, x19
    7668:	aa0003e2 	mov	x2, x0
    766c:	aa1403e0 	mov	x0, x20
    7670:	97fff008 	bl	3690 <buf_put>
    7674:	528007c3 	mov	w3, #0x3e                  	// #62
    7678:	aa1403e0 	mov	x0, x20
    767c:	91001fe1 	add	x1, sp, #0x7
    7680:	d2800022 	mov	x2, #0x1                   	// #1
    7684:	39001fe3 	strb	w3, [sp, #7]
    7688:	17ffffb1 	b	754c <fwp_write+0x9c>
    768c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7690:	f947f400 	ldr	x0, [x0, #4072]
    7694:	f94127e2 	ldr	x2, [sp, #584]
    7698:	f9400001 	ldr	x1, [x0]
    769c:	eb010042 	subs	x2, x2, x1
    76a0:	d2800001 	mov	x1, #0x0                   	// #0
    76a4:	540034e1 	b.ne	7d40 <fwp_write+0x890>  // b.any
    76a8:	f9413bf5 	ldr	x21, [sp, #624]
    76ac:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    76b0:	f9413ff6 	ldr	x22, [sp, #632]
    76b4:	aa1403e0 	mov	x0, x20
    76b8:	91270021 	add	x1, x1, #0x9c0
    76bc:	d2800142 	mov	x2, #0xa                   	// #10
    76c0:	f94153fb 	ldr	x27, [sp, #672]
    76c4:	f94157fc 	ldr	x28, [sp, #680]
    76c8:	910943ff 	add	sp, sp, #0x250
    76cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    76d0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    76d4:	17ffefef 	b	3690 <buf_put>
    76d8:	f9400456 	ldr	x22, [x2, #8]
    76dc:	f90143f7 	str	x23, [sp, #640]
    76e0:	f90147f8 	str	x24, [sp, #648]
    76e4:	b4005b16 	cbz	x22, 8244 <fwp_write+0xd94>
    76e8:	aa1603e0 	mov	x0, x22
    76ec:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    76f0:	91290021 	add	x1, x1, #0xa40
    76f4:	97ffec8b 	bl	2920 <strcmp@plt>
    76f8:	2a0003f5 	mov	w21, w0
    76fc:	34005fe0 	cbz	w0, 82f8 <fwp_write+0xe48>
    7700:	aa1603e0 	mov	x0, x22
    7704:	97ffec0b 	bl	2730 <strlen@plt>
    7708:	aa1603e1 	mov	x1, x22
    770c:	aa0003e2 	mov	x2, x0
    7710:	aa1403e0 	mov	x0, x20
    7714:	97ffefdf 	bl	3690 <buf_put>
    7718:	52800403 	mov	w3, #0x20                  	// #32
    771c:	91001ff5 	add	x21, sp, #0x7
    7720:	aa1503e1 	mov	x1, x21
    7724:	aa1403e0 	mov	x0, x20
    7728:	d2800022 	mov	x2, #0x1                   	// #1
    772c:	39001fe3 	strb	w3, [sp, #7]
    7730:	97ffefd8 	bl	3690 <buf_put>
    7734:	52800f63 	mov	w3, #0x7b                  	// #123
    7738:	aa1403e0 	mov	x0, x20
    773c:	aa1503e1 	mov	x1, x21
    7740:	d2800022 	mov	x2, #0x1                   	// #1
    7744:	39001fe3 	strb	w3, [sp, #7]
    7748:	97ffefd2 	bl	3690 <buf_put>
    774c:	b9401380 	ldr	w0, [x28, #16]
    7750:	52800018 	mov	w24, #0x0                   	// #0
    7754:	7100001f 	cmp	w0, #0x0
    7758:	54003aad 	b.le	7eac <fwp_write+0x9fc>
    775c:	f9014bf9 	str	x25, [sp, #656]
    7760:	d0000039 	adrp	x25, d000 <__modti3+0x30>
    7764:	9129a339 	add	x25, x25, #0xa68
    7768:	f9014ffa 	str	x26, [sp, #664]
    776c:	d000003a 	adrp	x26, d000 <__modti3+0x30>
    7770:	9128a35a 	add	x26, x26, #0xa28
    7774:	91002276 	add	x22, x19, #0x8
    7778:	d2800013 	mov	x19, #0x0                   	// #0
    777c:	b5003e93 	cbnz	x19, 7f4c <fwp_write+0xa9c>
    7780:	d37df277 	lsl	x23, x19, #3
    7784:	34003cb8 	cbz	w24, 7f18 <fwp_write+0xa68>
    7788:	f9401382 	ldr	x2, [x28, #32]
    778c:	aa1403e0 	mov	x0, x20
    7790:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7794:	52800003 	mov	w3, #0x0                   	// #0
    7798:	f8776842 	ldr	x2, [x2, x23]
    779c:	91000673 	add	x19, x19, #0x1
    77a0:	97ffff44 	bl	74b0 <fwp_write>
    77a4:	b9401380 	ldr	w0, [x28, #16]
    77a8:	6b13001f 	cmp	w0, w19
    77ac:	54fffe8c 	b.gt	777c <fwp_write+0x2cc>
    77b0:	f9414bf9 	ldr	x25, [sp, #656]
    77b4:	f9414ffa 	ldr	x26, [sp, #664]
    77b8:	340037b8 	cbz	w24, 7eac <fwp_write+0x9fc>
    77bc:	52800523 	mov	w3, #0x29                  	// #41
    77c0:	aa1503e1 	mov	x1, x21
    77c4:	aa1403e0 	mov	x0, x20
    77c8:	d2800022 	mov	x2, #0x1                   	// #1
    77cc:	39001fe3 	strb	w3, [sp, #7]
    77d0:	97ffefb0 	bl	3690 <buf_put>
    77d4:	f9413bf5 	ldr	x21, [sp, #624]
    77d8:	f9413ff6 	ldr	x22, [sp, #632]
    77dc:	f94143f7 	ldr	x23, [sp, #640]
    77e0:	f94147f8 	ldr	x24, [sp, #648]
    77e4:	f94153fb 	ldr	x27, [sp, #672]
    77e8:	f94157fc 	ldr	x28, [sp, #680]
    77ec:	17ffff5d 	b	7560 <fwp_write+0xb0>
    77f0:	b9404855 	ldr	w21, [x2, #72]
    77f4:	aa1403e0 	mov	x0, x20
    77f8:	93407eb6 	sxtw	x22, w21
    77fc:	91000ac1 	add	x1, x22, #0x2
    7800:	97ffef70 	bl	35c0 <buf_grow>
    7804:	a9400281 	ldp	x1, x0, [x20]
    7808:	528e8603 	mov	w3, #0x7430                	// #29744
    780c:	78206823 	strh	w3, [x1, x0]
    7810:	8b000022 	add	x2, x1, x0
    7814:	710002bf 	cmp	w21, #0x0
    7818:	540036cd 	b.le	7ef0 <fwp_write+0xa40>
    781c:	110006a3 	add	w3, w21, #0x1
    7820:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7824:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7828:	91000449 	add	x9, x2, #0x1
    782c:	8b23c043 	add	x3, x2, w3, sxtw
    7830:	f28aaac6 	movk	x6, #0x5556
    7834:	f2955568 	movk	x8, #0xaaab
    7838:	1400000d 	b	786c <fwp_write+0x3bc>
    783c:	d2800021 	mov	x1, #0x1                   	// #1
    7840:	528005a5 	mov	w5, #0x2d                  	// #45
    7844:	f100001f 	cmp	x0, #0x0
    7848:	9b467e60 	smulh	x0, x19, x6
    784c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7850:	381ff465 	strb	w5, [x3], #-1
    7854:	cb040000 	sub	x0, x0, x4
    7858:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    785c:	cb020000 	sub	x0, x0, x2
    7860:	8b010013 	add	x19, x0, x1
    7864:	eb03013f 	cmp	x9, x3
    7868:	54003440 	b.eq	7ef0 <fwp_write+0xa40>  // b.none
    786c:	9b467e60 	smulh	x0, x19, x6
    7870:	937ffe64 	asr	x4, x19, #63
    7874:	52800605 	mov	w5, #0x30                  	// #48
    7878:	cb040000 	sub	x0, x0, x4
    787c:	8b000400 	add	x0, x0, x0, lsl #1
    7880:	cb000260 	sub	x0, x19, x0
    7884:	91000c01 	add	x1, x0, #0x3
    7888:	9bc87c22 	umulh	x2, x1, x8
    788c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7890:	8b4204e2 	add	x2, x7, x2, lsr #1
    7894:	eb020021 	subs	x1, x1, x2
    7898:	54fffd60 	b.eq	7844 <fwp_write+0x394>  // b.none
    789c:	f100043f 	cmp	x1, #0x1
    78a0:	54fffce1 	b.ne	783c <fwp_write+0x38c>  // b.any
    78a4:	d2800001 	mov	x1, #0x0                   	// #0
    78a8:	52800565 	mov	w5, #0x2b                  	// #43
    78ac:	17ffffe6 	b	7844 <fwp_write+0x394>
    78b0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    78b4:	f947f400 	ldr	x0, [x0, #4072]
    78b8:	f94127e2 	ldr	x2, [sp, #584]
    78bc:	f9400001 	ldr	x1, [x0]
    78c0:	eb010042 	subs	x2, x2, x1
    78c4:	d2800001 	mov	x1, #0x0                   	// #0
    78c8:	540023c1 	b.ne	7d40 <fwp_write+0x890>  // b.any
    78cc:	f9413bf5 	ldr	x21, [sp, #624]
    78d0:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    78d4:	f9413ff6 	ldr	x22, [sp, #632]
    78d8:	aa1403e0 	mov	x0, x20
    78dc:	91274021 	add	x1, x1, #0x9d0
    78e0:	d2800102 	mov	x2, #0x8                   	// #8
    78e4:	17ffff77 	b	76c0 <fwp_write+0x210>
    78e8:	aa1403e0 	mov	x0, x20
    78ec:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    78f0:	d28000c2 	mov	x2, #0x6                   	// #6
    78f4:	9128c021 	add	x1, x1, #0xa30
    78f8:	97ffef66 	bl	3690 <buf_put>
    78fc:	d2800015 	mov	x21, #0x0                   	// #0
    7900:	f9400263 	ldr	x3, [x19]
    7904:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7908:	54002c60 	b.eq	7e94 <fwp_write+0x9e4>  // b.none
    790c:	f9401f82 	ldr	x2, [x28, #56]
    7910:	f90143f7 	str	x23, [sp, #640]
    7914:	f90147f8 	str	x24, [sp, #648]
    7918:	d2800857 	mov	x23, #0x42                  	// #66
    791c:	f9014bf9 	str	x25, [sp, #656]
    7920:	d0000036 	adrp	x22, d000 <__modti3+0x30>
    7924:	f9014ffa 	str	x26, [sp, #664]
    7928:	9128a2d6 	add	x22, x22, #0xa28
    792c:	d2800038 	mov	x24, #0x1                   	// #1
    7930:	f2a18017 	movk	x23, #0xc00, lsl #16
    7934:	d2809099 	mov	x25, #0x484                 	// #1156
    7938:	b40004a2 	cbz	x2, 79cc <fwp_write+0x51c>
    793c:	b9400040 	ldr	w0, [x2]
    7940:	7100701f 	cmp	w0, #0x1c
    7944:	540042c0 	b.eq	819c <fwp_write+0xcec>  // b.none
    7948:	71006c1f 	cmp	w0, #0x1b
    794c:	54000408 	b.hi	79cc <fwp_write+0x51c>  // b.pmore
    7950:	9ac02301 	lsl	x1, x24, x0
    7954:	ea17003f 	tst	x1, x23
    7958:	540036a1 	b.ne	802c <fwp_write+0xb7c>  // b.any
    795c:	ea19003f 	tst	x1, x25
    7960:	54003521 	b.ne	8004 <fwp_write+0xb54>  // b.any
    7964:	d2800424 	mov	x4, #0x21                  	// #33
    7968:	ea04003f 	tst	x1, x4
    796c:	54000300 	b.eq	79cc <fwp_write+0x51c>  // b.none
    7970:	b7f849c3 	tbnz	x3, #63, 82a8 <fwp_write+0xdf8>
    7974:	91002261 	add	x1, x19, #0x8
    7978:	8b150021 	add	x1, x1, x21
    797c:	39400021 	ldrb	w1, [x1]
    7980:	7100001f 	cmp	w0, #0x0
    7984:	93401c23 	sxtb	x3, w1
    7988:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    798c:	d503201f 	nop
    7990:	aa1403e0 	mov	x0, x20
    7994:	52800003 	mov	w3, #0x0                   	// #0
    7998:	97fffec6 	bl	74b0 <fwp_write>
    799c:	910006b5 	add	x21, x21, #0x1
    79a0:	f9400260 	ldr	x0, [x19]
    79a4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    79a8:	eb0002bf 	cmp	x21, x0
    79ac:	540026c2 	b.cs	7e84 <fwp_write+0x9d4>  // b.hs, b.nlast
    79b0:	d2800042 	mov	x2, #0x2                   	// #2
    79b4:	aa1603e1 	mov	x1, x22
    79b8:	aa1403e0 	mov	x0, x20
    79bc:	97ffef35 	bl	3690 <buf_put>
    79c0:	f9401f82 	ldr	x2, [x28, #56]
    79c4:	f9400263 	ldr	x3, [x19]
    79c8:	b5fffba2 	cbnz	x2, 793c <fwp_write+0x48c>
    79cc:	d37df2a0 	lsl	x0, x21, #3
    79d0:	b7f83f03 	tbnz	x3, #63, 81b0 <fwp_write+0xd00>
    79d4:	91002261 	add	x1, x19, #0x8
    79d8:	8b000020 	add	x0, x1, x0
    79dc:	f9400001 	ldr	x1, [x0]
    79e0:	17ffffec 	b	7990 <fwp_write+0x4e0>
    79e4:	a9400e62 	ldp	x2, x3, [x19]
    79e8:	b7f83ca3 	tbnz	x3, #63, 817c <fwp_write+0xccc>
    79ec:	910123f5 	add	x21, sp, #0x48
    79f0:	aa1503e0 	mov	x0, x21
    79f4:	97ffed0b 	bl	2e20 <fwp_fmt_u128>
    79f8:	aa1503e0 	mov	x0, x21
    79fc:	97ffeb4d 	bl	2730 <strlen@plt>
    7a00:	aa1503e1 	mov	x1, x21
    7a04:	aa0003e2 	mov	x2, x0
    7a08:	17fffed0 	b	7548 <fwp_write+0x98>
    7a0c:	fd015be8 	str	d8, [sp, #688]
    7a10:	1e270268 	fmov	s8, w19
    7a14:	fd015fe9 	str	d9, [sp, #696]
    7a18:	1e282100 	fcmp	s8, s8
    7a1c:	54004d26 	b.vs	83c0 <fwp_write+0xf10>
    7a20:	1e20c101 	fabs	s1, s8
    7a24:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7a28:	1e270000 	fmov	s0, w0
    7a2c:	1e202020 	fcmp	s1, s0
    7a30:	54002c0d 	b.le	7fb0 <fwp_write+0xb00>
    7a34:	1e202118 	fcmpe	s8, #0.0
    7a38:	d0000022 	adrp	x2, d000 <__modti3+0x30>
    7a3c:	9113a042 	add	x2, x2, #0x4e8
    7a40:	910123f5 	add	x21, sp, #0x48
    7a44:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    7a48:	91260021 	add	x1, x1, #0x980
    7a4c:	aa1503e0 	mov	x0, x21
    7a50:	9a81c041 	csel	x1, x2, x1, gt
    7a54:	97ffebe3 	bl	29e0 <strcpy@plt>
    7a58:	aa1503e0 	mov	x0, x21
    7a5c:	97ffeb35 	bl	2730 <strlen@plt>
    7a60:	aa1503e1 	mov	x1, x21
    7a64:	aa0003e2 	mov	x2, x0
    7a68:	aa1403e0 	mov	x0, x20
    7a6c:	97ffef09 	bl	3690 <buf_put>
    7a70:	f9413bf5 	ldr	x21, [sp, #624]
    7a74:	f9413ff6 	ldr	x22, [sp, #632]
    7a78:	f94153fb 	ldr	x27, [sp, #672]
    7a7c:	f94157fc 	ldr	x28, [sp, #680]
    7a80:	fd415be8 	ldr	d8, [sp, #688]
    7a84:	fd415fe9 	ldr	d9, [sp, #696]
    7a88:	17fffeb6 	b	7560 <fwp_write+0xb0>
    7a8c:	f9400276 	ldr	x22, [x19]
    7a90:	34002e03 	cbz	w3, 8050 <fwp_write+0xba0>
    7a94:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7a98:	f947f400 	ldr	x0, [x0, #4072]
    7a9c:	f94127e2 	ldr	x2, [sp, #584]
    7aa0:	f9400001 	ldr	x1, [x0]
    7aa4:	eb010042 	subs	x2, x2, x1
    7aa8:	d2800001 	mov	x1, #0x0                   	// #0
    7aac:	540014a1 	b.ne	7d40 <fwp_write+0x890>  // b.any
    7ab0:	aa1603e2 	mov	x2, x22
    7ab4:	91002261 	add	x1, x19, #0x8
    7ab8:	f9413bf5 	ldr	x21, [sp, #624]
    7abc:	aa1403e0 	mov	x0, x20
    7ac0:	f9413ff6 	ldr	x22, [sp, #632]
    7ac4:	17fffeff 	b	76c0 <fwp_write+0x210>
    7ac8:	fd015be8 	str	d8, [sp, #688]
    7acc:	9e670268 	fmov	d8, x19
    7ad0:	fd015fe9 	str	d9, [sp, #696]
    7ad4:	1e682100 	fcmp	d8, d8
    7ad8:	54004746 	b.vs	83c0 <fwp_write+0xf10>
    7adc:	1e60c101 	fabs	d1, d8
    7ae0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7ae4:	9e670000 	fmov	d0, x0
    7ae8:	910123f5 	add	x21, sp, #0x48
    7aec:	52800033 	mov	w19, #0x1                   	// #1
    7af0:	1e602020 	fcmp	d1, d0
    7af4:	540001ad 	b.le	7b28 <fwp_write+0x678>
    7af8:	1e602118 	fcmpe	d8, #0.0
    7afc:	d0000022 	adrp	x2, d000 <__modti3+0x30>
    7b00:	9113a042 	add	x2, x2, #0x4e8
    7b04:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    7b08:	91260021 	add	x1, x1, #0x980
    7b0c:	aa1503e0 	mov	x0, x21
    7b10:	9a81c041 	csel	x1, x2, x1, gt
    7b14:	97ffebb3 	bl	29e0 <strcpy@plt>
    7b18:	17ffffd0 	b	7a58 <fwp_write+0x5a8>
    7b1c:	11000673 	add	w19, w19, #0x1
    7b20:	71004a7f 	cmp	w19, #0x12
    7b24:	54003860 	b.eq	8230 <fwp_write+0xd80>  // b.none
    7b28:	1e604100 	fmov	d0, d8
    7b2c:	2a1303e1 	mov	w1, w19
    7b30:	aa1503e0 	mov	x0, x21
    7b34:	97fff018 	bl	3b94 <fwp_format_g.constprop.0>
    7b38:	aa1503e0 	mov	x0, x21
    7b3c:	d2800001 	mov	x1, #0x0                   	// #0
    7b40:	97ffeb10 	bl	2780 <strtod@plt>
    7b44:	1e602100 	fcmp	d8, d0
    7b48:	54fffea1 	b.ne	7b1c <fwp_write+0x66c>  // b.any
    7b4c:	aa1503e0 	mov	x0, x21
    7b50:	97ffef09 	bl	3774 <fwp_finish_float>
    7b54:	17ffffc1 	b	7a58 <fwp_write+0x5a8>
    7b58:	a9400e62 	ldp	x2, x3, [x19]
    7b5c:	910123f3 	add	x19, sp, #0x48
    7b60:	aa1303e0 	mov	x0, x19
    7b64:	97ffecaf 	bl	2e20 <fwp_fmt_u128>
    7b68:	17fffe74 	b	7538 <fwp_write+0x88>
    7b6c:	f90143f7 	str	x23, [sp, #640]
    7b70:	f90147f8 	str	x24, [sp, #648]
    7b74:	2a1303f8 	mov	w24, w19
    7b78:	f9014bf9 	str	x25, [sp, #656]
    7b7c:	f9014ffa 	str	x26, [sp, #664]
    7b80:	f13ffe7f 	cmp	x19, #0xfff
    7b84:	54000049 	b.ls	7b8c <fwp_write+0x6dc>  // b.plast
    7b88:	b9400278 	ldr	w24, [x19]
    7b8c:	f9400f80 	ldr	x0, [x28, #24]
    7b90:	2a1803f5 	mov	w21, w24
    7b94:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7b98:	d37ef6b9 	lsl	x25, x21, #2
    7b9c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7ba0:	aa1603e0 	mov	x0, x22
    7ba4:	97ffeae3 	bl	2730 <strlen@plt>
    7ba8:	aa1603e1 	mov	x1, x22
    7bac:	aa0003e2 	mov	x2, x0
    7bb0:	aa1403e0 	mov	x0, x20
    7bb4:	97ffeeb7 	bl	3690 <buf_put>
    7bb8:	f9401780 	ldr	x0, [x28, #40]
    7bbc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7bc0:	7100001f 	cmp	w0, #0x0
    7bc4:	5400068d 	b.le	7c94 <fwp_write+0x7e4>
    7bc8:	91002276 	add	x22, x19, #0x8
    7bcc:	91001ff5 	add	x21, sp, #0x7
    7bd0:	d280001b 	mov	x27, #0x0                   	// #0
    7bd4:	5280041a 	mov	w26, #0x20                  	// #32
    7bd8:	f9401b80 	ldr	x0, [x28, #48]
    7bdc:	aa1503e1 	mov	x1, x21
    7be0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7be4:	d2800022 	mov	x2, #0x1                   	// #1
    7be8:	f8786803 	ldr	x3, [x0, x24]
    7bec:	aa1403e0 	mov	x0, x20
    7bf0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7bf4:	39001ffa 	strb	w26, [sp, #7]
    7bf8:	97ffeea6 	bl	3690 <buf_put>
    7bfc:	f13ffeff 	cmp	x23, #0xfff
    7c00:	b9400261 	ldr	w1, [x19]
    7c04:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7c08:	7100383f 	cmp	w1, #0xe
    7c0c:	54000160 	b.eq	7c38 <fwp_write+0x788>  // b.none
    7c10:	7100403f 	cmp	w1, #0x10
    7c14:	54001a60 	b.eq	7f60 <fwp_write+0xab0>  // b.none
    7c18:	7100283f 	cmp	w1, #0xa
    7c1c:	54002aa0 	b.eq	8170 <fwp_write+0xcc0>  // b.none
    7c20:	540014ac 	b.gt	7eb4 <fwp_write+0xa04>
    7c24:	71000c3f 	cmp	w1, #0x3
    7c28:	540029ac 	b.gt	815c <fwp_write+0xcac>
    7c2c:	d37ffee0 	lsr	x0, x23, #63
    7c30:	37f814a1 	tbnz	w1, #31, 7ec4 <fwp_write+0xa14>
    7c34:	d503201f 	nop
    7c38:	34001460 	cbz	w0, 7ec4 <fwp_write+0xa14>
    7c3c:	52800503 	mov	w3, #0x28                  	// #40
    7c40:	aa1503e1 	mov	x1, x21
    7c44:	aa1403e0 	mov	x0, x20
    7c48:	d2800022 	mov	x2, #0x1                   	// #1
    7c4c:	39001fe3 	strb	w3, [sp, #7]
    7c50:	97ffee90 	bl	3690 <buf_put>
    7c54:	aa1303e2 	mov	x2, x19
    7c58:	aa1703e1 	mov	x1, x23
    7c5c:	aa1403e0 	mov	x0, x20
    7c60:	52800003 	mov	w3, #0x0                   	// #0
    7c64:	97fffe13 	bl	74b0 <fwp_write>
    7c68:	52800523 	mov	w3, #0x29                  	// #41
    7c6c:	aa1503e1 	mov	x1, x21
    7c70:	aa1403e0 	mov	x0, x20
    7c74:	d2800022 	mov	x2, #0x1                   	// #1
    7c78:	39001fe3 	strb	w3, [sp, #7]
    7c7c:	97ffee85 	bl	3690 <buf_put>
    7c80:	f9401780 	ldr	x0, [x28, #40]
    7c84:	9100077b 	add	x27, x27, #0x1
    7c88:	b8796800 	ldr	w0, [x0, x25]
    7c8c:	6b1b001f 	cmp	w0, w27
    7c90:	54fffa4c 	b.gt	7bd8 <fwp_write+0x728>
    7c94:	f9413bf5 	ldr	x21, [sp, #624]
    7c98:	f9413ff6 	ldr	x22, [sp, #632]
    7c9c:	f94143f7 	ldr	x23, [sp, #640]
    7ca0:	f94147f8 	ldr	x24, [sp, #648]
    7ca4:	f9414bf9 	ldr	x25, [sp, #656]
    7ca8:	f9414ffa 	ldr	x26, [sp, #664]
    7cac:	f94153fb 	ldr	x27, [sp, #672]
    7cb0:	f94157fc 	ldr	x28, [sp, #680]
    7cb4:	17fffe2b 	b	7560 <fwp_write+0xb0>
    7cb8:	52800783 	mov	w3, #0x3c                  	// #60
    7cbc:	91001ff3 	add	x19, sp, #0x7
    7cc0:	aa1303e1 	mov	x1, x19
    7cc4:	d2800022 	mov	x2, #0x1                   	// #1
    7cc8:	aa1403e0 	mov	x0, x20
    7ccc:	39001fe3 	strb	w3, [sp, #7]
    7cd0:	97ffee70 	bl	3690 <buf_put>
    7cd4:	f9400795 	ldr	x21, [x28, #8]
    7cd8:	aa1503e0 	mov	x0, x21
    7cdc:	97ffea95 	bl	2730 <strlen@plt>
    7ce0:	aa1503e1 	mov	x1, x21
    7ce4:	aa0003e2 	mov	x2, x0
    7ce8:	aa1403e0 	mov	x0, x20
    7cec:	97ffee69 	bl	3690 <buf_put>
    7cf0:	528007c3 	mov	w3, #0x3e                  	// #62
    7cf4:	aa1303e1 	mov	x1, x19
    7cf8:	aa1403e0 	mov	x0, x20
    7cfc:	d2800022 	mov	x2, #0x1                   	// #1
    7d00:	39001fe3 	strb	w3, [sp, #7]
    7d04:	17fffe12 	b	754c <fwp_write+0x9c>
    7d08:	f100067f 	cmp	x19, #0x1
    7d0c:	540025a0 	b.eq	81c0 <fwp_write+0xd10>  // b.none
    7d10:	b100067f 	cmn	x19, #0x1
    7d14:	54002bc0 	b.eq	828c <fwp_write+0xddc>  // b.none
    7d18:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    7d1c:	91262021 	add	x1, x1, #0x988
    7d20:	d2800022 	mov	x2, #0x1                   	// #1
    7d24:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7d28:	f947f400 	ldr	x0, [x0, #4072]
    7d2c:	f94127e4 	ldr	x4, [sp, #584]
    7d30:	f9400003 	ldr	x3, [x0]
    7d34:	eb030084 	subs	x4, x4, x3
    7d38:	d2800003 	mov	x3, #0x0                   	// #0
    7d3c:	54ffebe0 	b.eq	7ab8 <fwp_write+0x608>  // b.none
    7d40:	f90143f7 	str	x23, [sp, #640]
    7d44:	f90147f8 	str	x24, [sp, #648]
    7d48:	f9014bf9 	str	x25, [sp, #656]
    7d4c:	f9014ffa 	str	x26, [sp, #664]
    7d50:	fd015be8 	str	d8, [sp, #688]
    7d54:	fd015fe9 	str	d9, [sp, #696]
    7d58:	97ffead2 	bl	28a0 <__stack_chk_fail@plt>
    7d5c:	52800b63 	mov	w3, #0x5b                  	// #91
    7d60:	91001ff5 	add	x21, sp, #0x7
    7d64:	aa1503e1 	mov	x1, x21
    7d68:	aa1403e0 	mov	x0, x20
    7d6c:	d2800022 	mov	x2, #0x1                   	// #1
    7d70:	d0000036 	adrp	x22, d000 <__modti3+0x30>
    7d74:	9128a2d6 	add	x22, x22, #0xa28
    7d78:	39001fe3 	strb	w3, [sp, #7]
    7d7c:	97ffee45 	bl	3690 <buf_put>
    7d80:	b4000273 	cbz	x19, 7dcc <fwp_write+0x91c>
    7d84:	f9400661 	ldr	x1, [x19, #8]
    7d88:	aa1403e0 	mov	x0, x20
    7d8c:	f9401f82 	ldr	x2, [x28, #56]
    7d90:	52800003 	mov	w3, #0x0                   	// #0
    7d94:	97fffdc7 	bl	74b0 <fwp_write>
    7d98:	f9400a73 	ldr	x19, [x19, #16]
    7d9c:	b4000193 	cbz	x19, 7dcc <fwp_write+0x91c>
    7da0:	aa1603e1 	mov	x1, x22
    7da4:	aa1403e0 	mov	x0, x20
    7da8:	d2800042 	mov	x2, #0x2                   	// #2
    7dac:	97ffee39 	bl	3690 <buf_put>
    7db0:	f9400661 	ldr	x1, [x19, #8]
    7db4:	aa1403e0 	mov	x0, x20
    7db8:	f9401f82 	ldr	x2, [x28, #56]
    7dbc:	52800003 	mov	w3, #0x0                   	// #0
    7dc0:	97fffdbc 	bl	74b0 <fwp_write>
    7dc4:	f9400a73 	ldr	x19, [x19, #16]
    7dc8:	b5fffed3 	cbnz	x19, 7da0 <fwp_write+0x8f0>
    7dcc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7dd0:	aa1503e1 	mov	x1, x21
    7dd4:	aa1403e0 	mov	x0, x20
    7dd8:	d2800022 	mov	x2, #0x1                   	// #1
    7ddc:	39001fe3 	strb	w3, [sp, #7]
    7de0:	17fffddb 	b	754c <fwp_write+0x9c>
    7de4:	aa1403e0 	mov	x0, x20
    7de8:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    7dec:	d28000c2 	mov	x2, #0x6                   	// #6
    7df0:	91286021 	add	x1, x1, #0xa18
    7df4:	97ffee27 	bl	3690 <buf_put>
    7df8:	f9400260 	ldr	x0, [x19]
    7dfc:	b40004c0 	cbz	x0, 7e94 <fwp_write+0x9e4>
    7e00:	910123f5 	add	x21, sp, #0x48
    7e04:	91002276 	add	x22, x19, #0x8
    7e08:	f90143f7 	str	x23, [sp, #640]
    7e0c:	d2800017 	mov	x23, #0x0                   	// #0
    7e10:	f90147f8 	str	x24, [sp, #648]
    7e14:	d0000038 	adrp	x24, d000 <__modti3+0x30>
    7e18:	91288318 	add	x24, x24, #0xa20
    7e1c:	f9014bf9 	str	x25, [sp, #656]
    7e20:	d0000039 	adrp	x25, d000 <__modti3+0x30>
    7e24:	9128a339 	add	x25, x25, #0xa28
    7e28:	f9014ffa 	str	x26, [sp, #664]
    7e2c:	14000005 	b	7e40 <fwp_write+0x990>
    7e30:	aa1903e1 	mov	x1, x25
    7e34:	aa1403e0 	mov	x0, x20
    7e38:	d2800042 	mov	x2, #0x2                   	// #2
    7e3c:	97ffee15 	bl	3690 <buf_put>
    7e40:	38776ac5 	ldrb	w5, [x22, x23]
    7e44:	d2804003 	mov	x3, #0x200                 	// #512
    7e48:	aa1803e4 	mov	x4, x24
    7e4c:	aa0303e1 	mov	x1, x3
    7e50:	52800042 	mov	w2, #0x2                   	// #2
    7e54:	aa1503e0 	mov	x0, x21
    7e58:	910006f7 	add	x23, x23, #0x1
    7e5c:	97ffea6d 	bl	2810 <__snprintf_chk@plt>
    7e60:	aa1503e0 	mov	x0, x21
    7e64:	97ffea33 	bl	2730 <strlen@plt>
    7e68:	aa1503e1 	mov	x1, x21
    7e6c:	aa0003e2 	mov	x2, x0
    7e70:	aa1403e0 	mov	x0, x20
    7e74:	97ffee07 	bl	3690 <buf_put>
    7e78:	f9400260 	ldr	x0, [x19]
    7e7c:	eb17001f 	cmp	x0, x23
    7e80:	54fffd88 	b.hi	7e30 <fwp_write+0x980>  // b.pmore
    7e84:	f94143f7 	ldr	x23, [sp, #640]
    7e88:	f94147f8 	ldr	x24, [sp, #648]
    7e8c:	f9414bf9 	ldr	x25, [sp, #656]
    7e90:	f9414ffa 	ldr	x26, [sp, #664]
    7e94:	52800ba3 	mov	w3, #0x5d                  	// #93
    7e98:	aa1403e0 	mov	x0, x20
    7e9c:	91001fe1 	add	x1, sp, #0x7
    7ea0:	d2800022 	mov	x2, #0x1                   	// #1
    7ea4:	39001fe3 	strb	w3, [sp, #7]
    7ea8:	17fffda9 	b	754c <fwp_write+0x9c>
    7eac:	52800fa3 	mov	w3, #0x7d                  	// #125
    7eb0:	17fffe44 	b	77c0 <fwp_write+0x310>
    7eb4:	f10002ff 	cmp	x23, #0x0
    7eb8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7ebc:	71002c3f 	cmp	w1, #0xb
    7ec0:	54ffebc0 	b.eq	7c38 <fwp_write+0x788>  // b.none
    7ec4:	aa1303e2 	mov	x2, x19
    7ec8:	aa1703e1 	mov	x1, x23
    7ecc:	aa1403e0 	mov	x0, x20
    7ed0:	52800003 	mov	w3, #0x0                   	// #0
    7ed4:	97fffd77 	bl	74b0 <fwp_write>
    7ed8:	17ffff6a 	b	7c80 <fwp_write+0x7d0>
    7edc:	aa1403e0 	mov	x0, x20
    7ee0:	91001fe1 	add	x1, sp, #0x7
    7ee4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7ee8:	d2800022 	mov	x2, #0x1                   	// #1
    7eec:	17fffe38 	b	77cc <fwp_write+0x31c>
    7ef0:	a9400281 	ldp	x1, x0, [x20]
    7ef4:	91000800 	add	x0, x0, #0x2
    7ef8:	8b160000 	add	x0, x0, x22
    7efc:	f9000680 	str	x0, [x20, #8]
    7f00:	3820683f 	strb	wzr, [x1, x0]
    7f04:	f9413bf5 	ldr	x21, [sp, #624]
    7f08:	f9413ff6 	ldr	x22, [sp, #632]
    7f0c:	f94153fb 	ldr	x27, [sp, #672]
    7f10:	f94157fc 	ldr	x28, [sp, #680]
    7f14:	17fffd93 	b	7560 <fwp_write+0xb0>
    7f18:	f9400f80 	ldr	x0, [x28, #24]
    7f1c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7f20:	aa1b03e0 	mov	x0, x27
    7f24:	97ffea03 	bl	2730 <strlen@plt>
    7f28:	aa1b03e1 	mov	x1, x27
    7f2c:	aa0003e2 	mov	x2, x0
    7f30:	aa1403e0 	mov	x0, x20
    7f34:	97ffedd7 	bl	3690 <buf_put>
    7f38:	aa1903e1 	mov	x1, x25
    7f3c:	aa1403e0 	mov	x0, x20
    7f40:	d2800062 	mov	x2, #0x3                   	// #3
    7f44:	97ffedd3 	bl	3690 <buf_put>
    7f48:	17fffe10 	b	7788 <fwp_write+0x2d8>
    7f4c:	aa1a03e1 	mov	x1, x26
    7f50:	aa1403e0 	mov	x0, x20
    7f54:	d2800042 	mov	x2, #0x2                   	// #2
    7f58:	97ffedce 	bl	3690 <buf_put>
    7f5c:	17fffe09 	b	7780 <fwp_write+0x2d0>
    7f60:	f9400660 	ldr	x0, [x19, #8]
    7f64:	b4fffb00 	cbz	x0, 7ec4 <fwp_write+0xa14>
    7f68:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    7f6c:	91290021 	add	x1, x1, #0xa40
    7f70:	97ffea6c 	bl	2920 <strcmp@plt>
    7f74:	7100001f 	cmp	w0, #0x0
    7f78:	1a9f07e0 	cset	w0, ne	// ne = any
    7f7c:	17ffff2f 	b	7c38 <fwp_write+0x788>
    7f80:	aa1403e0 	mov	x0, x20
    7f84:	d2800042 	mov	x2, #0x2                   	// #2
    7f88:	d0000021 	adrp	x1, d000 <__modti3+0x30>
    7f8c:	9128e021 	add	x1, x1, #0xa38
    7f90:	97ffedc0 	bl	3690 <buf_put>
    7f94:	91004261 	add	x1, x19, #0x10
    7f98:	aa1403e0 	mov	x0, x20
    7f9c:	f9402382 	ldr	x2, [x28, #64]
    7fa0:	52800003 	mov	w3, #0x0                   	// #0
    7fa4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7fa8:	97fffd42 	bl	74b0 <fwp_write>
    7fac:	17fffd9c 	b	761c <fwp_write+0x16c>
    7fb0:	1e22c109 	fcvt	d9, s8
    7fb4:	910123f5 	add	x21, sp, #0x48
    7fb8:	52800033 	mov	w19, #0x1                   	// #1
    7fbc:	d503201f 	nop
    7fc0:	1e604120 	fmov	d0, d9
    7fc4:	2a1303e1 	mov	w1, w19
    7fc8:	aa1503e0 	mov	x0, x21
    7fcc:	97ffeef2 	bl	3b94 <fwp_format_g.constprop.0>
    7fd0:	aa1503e0 	mov	x0, x21
    7fd4:	d2800001 	mov	x1, #0x0                   	// #0
    7fd8:	97ffea5e 	bl	2950 <strtof@plt>
    7fdc:	1e202100 	fcmp	s8, s0
    7fe0:	54ffdb60 	b.eq	7b4c <fwp_write+0x69c>  // b.none
    7fe4:	11000673 	add	w19, w19, #0x1
    7fe8:	71002a7f 	cmp	w19, #0xa
    7fec:	54fffea1 	b.ne	7fc0 <fwp_write+0xb10>  // b.any
    7ff0:	1e604120 	fmov	d0, d9
    7ff4:	aa1503e0 	mov	x0, x21
    7ff8:	52800121 	mov	w1, #0x9                   	// #9
    7ffc:	97ffeee6 	bl	3b94 <fwp_format_g.constprop.0>
    8000:	17fffed3 	b	7b4c <fwp_write+0x69c>
    8004:	d37ef6a1 	lsl	x1, x21, #2
    8008:	b7f81563 	tbnz	x3, #63, 82b4 <fwp_write+0xe04>
    800c:	91002263 	add	x3, x19, #0x8
    8010:	8b010061 	add	x1, x3, x1
    8014:	b9400023 	ldr	w3, [x1]
    8018:	7100081f 	cmp	w0, #0x2
    801c:	2a0303e1 	mov	w1, w3
    8020:	93407c63 	sxtw	x3, w3
    8024:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8028:	17fffe5a 	b	7990 <fwp_write+0x4e0>
    802c:	d37ffaa1 	lsl	x1, x21, #1
    8030:	b7f81363 	tbnz	x3, #63, 829c <fwp_write+0xdec>
    8034:	91002263 	add	x3, x19, #0x8
    8038:	8b010061 	add	x1, x3, x1
    803c:	79400021 	ldrh	w1, [x1]
    8040:	7100041f 	cmp	w0, #0x1
    8044:	93403c23 	sxth	x3, w1
    8048:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    804c:	17fffe51 	b	7990 <fwp_write+0x4e0>
    8050:	52800443 	mov	w3, #0x22                  	// #34
    8054:	91001ff5 	add	x21, sp, #0x7
    8058:	91002273 	add	x19, x19, #0x8
    805c:	aa1503e1 	mov	x1, x21
    8060:	aa1403e0 	mov	x0, x20
    8064:	d2800022 	mov	x2, #0x1                   	// #1
    8068:	39001fe3 	strb	w3, [sp, #7]
    806c:	f90143f7 	str	x23, [sp, #640]
    8070:	8b160277 	add	x23, x19, x22
    8074:	f90147f8 	str	x24, [sp, #648]
    8078:	97ffed86 	bl	3690 <buf_put>
    807c:	b4000696 	cbz	x22, 814c <fwp_write+0xc9c>
    8080:	b0000038 	adrp	x24, d000 <__modti3+0x30>
    8084:	9127a318 	add	x24, x24, #0x9e8
    8088:	f9014bf9 	str	x25, [sp, #656]
    808c:	b0000039 	adrp	x25, d000 <__modti3+0x30>
    8090:	91282339 	add	x25, x25, #0xa08
    8094:	f9014ffa 	str	x26, [sp, #664]
    8098:	1400000d 	b	80cc <fwp_write+0xc1c>
    809c:	710024bf 	cmp	w5, #0x9
    80a0:	54000460 	b.eq	812c <fwp_write+0xc7c>  // b.none
    80a4:	710028bf 	cmp	w5, #0xa
    80a8:	54000a61 	b.ne	81f4 <fwp_write+0xd44>  // b.any
    80ac:	b0000021 	adrp	x1, d000 <__modti3+0x30>
    80b0:	aa1403e0 	mov	x0, x20
    80b4:	9127e021 	add	x1, x1, #0x9f8
    80b8:	d2800042 	mov	x2, #0x2                   	// #2
    80bc:	97ffed75 	bl	3690 <buf_put>
    80c0:	91000673 	add	x19, x19, #0x1
    80c4:	eb17027f 	cmp	x19, x23
    80c8:	540003e0 	b.eq	8144 <fwp_write+0xc94>  // b.none
    80cc:	39400265 	ldrb	w5, [x19]
    80d0:	710034bf 	cmp	w5, #0xd
    80d4:	54000180 	b.eq	8104 <fwp_write+0xc54>  // b.none
    80d8:	54fffe29 	b.ls	809c <fwp_write+0xbec>  // b.plast
    80dc:	710088bf 	cmp	w5, #0x22
    80e0:	540001c0 	b.eq	8118 <fwp_write+0xc68>  // b.none
    80e4:	710170bf 	cmp	w5, #0x5c
    80e8:	54000741 	b.ne	81d0 <fwp_write+0xd20>  // b.any
    80ec:	aa1403e0 	mov	x0, x20
    80f0:	b0000021 	adrp	x1, d000 <__modti3+0x30>
    80f4:	d2800042 	mov	x2, #0x2                   	// #2
    80f8:	9127c021 	add	x1, x1, #0x9f0
    80fc:	97ffed65 	bl	3690 <buf_put>
    8100:	17fffff0 	b	80c0 <fwp_write+0xc10>
    8104:	aa1903e1 	mov	x1, x25
    8108:	aa1403e0 	mov	x0, x20
    810c:	d2800042 	mov	x2, #0x2                   	// #2
    8110:	97ffed60 	bl	3690 <buf_put>
    8114:	17ffffeb 	b	80c0 <fwp_write+0xc10>
    8118:	aa1803e1 	mov	x1, x24
    811c:	aa1403e0 	mov	x0, x20
    8120:	d2800042 	mov	x2, #0x2                   	// #2
    8124:	97ffed5b 	bl	3690 <buf_put>
    8128:	17ffffe6 	b	80c0 <fwp_write+0xc10>
    812c:	aa1403e0 	mov	x0, x20
    8130:	b0000021 	adrp	x1, d000 <__modti3+0x30>
    8134:	d2800042 	mov	x2, #0x2                   	// #2
    8138:	91280021 	add	x1, x1, #0xa00
    813c:	97ffed55 	bl	3690 <buf_put>
    8140:	17ffffe0 	b	80c0 <fwp_write+0xc10>
    8144:	f9414bf9 	ldr	x25, [sp, #656]
    8148:	f9414ffa 	ldr	x26, [sp, #664]
    814c:	aa1503e1 	mov	x1, x21
    8150:	aa1403e0 	mov	x0, x20
    8154:	52800443 	mov	w3, #0x22                  	// #34
    8158:	17fffd9c 	b	77c8 <fwp_write+0x318>
    815c:	7100103f 	cmp	w1, #0x4
    8160:	54ffeb21 	b.ne	7ec4 <fwp_write+0xa14>  // b.any
    8164:	f94006e0 	ldr	x0, [x23, #8]
    8168:	d37ffc00 	lsr	x0, x0, #63
    816c:	17fffeb3 	b	7c38 <fwp_write+0x788>
    8170:	710002ff 	cmp	w23, #0x0
    8174:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8178:	17fffeb0 	b	7c38 <fwp_write+0x788>
    817c:	528005a1 	mov	w1, #0x2d                  	// #45
    8180:	eb0203e2 	negs	x2, x2
    8184:	da0303e3 	ngc	x3, x3
    8188:	910127e0 	add	x0, sp, #0x49
    818c:	910123f5 	add	x21, sp, #0x48
    8190:	390123e1 	strb	w1, [sp, #72]
    8194:	97ffeb23 	bl	2e20 <fwp_fmt_u128>
    8198:	17fffe18 	b	79f8 <fwp_write+0x548>
    819c:	d37ceea1 	lsl	x1, x21, #4
    81a0:	b7f810a3 	tbnz	x3, #63, 83b4 <fwp_write+0xf04>
    81a4:	91002260 	add	x0, x19, #0x8
    81a8:	8b010001 	add	x1, x0, x1
    81ac:	17fffdf9 	b	7990 <fwp_write+0x4e0>
    81b0:	f9400a61 	ldr	x1, [x19, #16]
    81b4:	8b010000 	add	x0, x0, x1
    81b8:	f9400001 	ldr	x1, [x0]
    81bc:	17fffdf5 	b	7990 <fwp_write+0x4e0>
    81c0:	b0000021 	adrp	x1, d000 <__modti3+0x30>
    81c4:	d2800042 	mov	x2, #0x2                   	// #2
    81c8:	91264021 	add	x1, x1, #0x990
    81cc:	17fffed6 	b	7d24 <fwp_write+0x874>
    81d0:	7101fcbf 	cmp	w5, #0x7f
    81d4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    81d8:	540000e9 	b.ls	81f4 <fwp_write+0xd44>  // b.plast
    81dc:	aa1503e1 	mov	x1, x21
    81e0:	aa1403e0 	mov	x0, x20
    81e4:	d2800022 	mov	x2, #0x1                   	// #1
    81e8:	39001fe5 	strb	w5, [sp, #7]
    81ec:	97ffed29 	bl	3690 <buf_put>
    81f0:	17ffffb4 	b	80c0 <fwp_write+0xc10>
    81f4:	d2800203 	mov	x3, #0x10                  	// #16
    81f8:	b0000024 	adrp	x4, d000 <__modti3+0x30>
    81fc:	aa0303e1 	mov	x1, x3
    8200:	91284084 	add	x4, x4, #0xa10
    8204:	910123f6 	add	x22, sp, #0x48
    8208:	52800042 	mov	w2, #0x2                   	// #2
    820c:	aa1603e0 	mov	x0, x22
    8210:	97ffe980 	bl	2810 <__snprintf_chk@plt>
    8214:	aa1603e0 	mov	x0, x22
    8218:	97ffe946 	bl	2730 <strlen@plt>
    821c:	aa1603e1 	mov	x1, x22
    8220:	aa0003e2 	mov	x2, x0
    8224:	aa1403e0 	mov	x0, x20
    8228:	97ffed1a 	bl	3690 <buf_put>
    822c:	17ffffa5 	b	80c0 <fwp_write+0xc10>
    8230:	1e604100 	fmov	d0, d8
    8234:	aa1503e0 	mov	x0, x21
    8238:	52800221 	mov	w1, #0x11                  	// #17
    823c:	97ffee56 	bl	3b94 <fwp_format_g.constprop.0>
    8240:	17fffe43 	b	7b4c <fwp_write+0x69c>
    8244:	b9401040 	ldr	w0, [x2, #16]
    8248:	350003c0 	cbnz	w0, 82c0 <fwp_write+0xe10>
    824c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8250:	f947f400 	ldr	x0, [x0, #4072]
    8254:	f94127e2 	ldr	x2, [sp, #584]
    8258:	f9400001 	ldr	x1, [x0]
    825c:	eb010042 	subs	x2, x2, x1
    8260:	d2800001 	mov	x1, #0x0                   	// #0
    8264:	54ffd721 	b.ne	7d48 <fwp_write+0x898>  // b.any
    8268:	f9413bf5 	ldr	x21, [sp, #624]
    826c:	b0000021 	adrp	x1, d000 <__modti3+0x30>
    8270:	f9413ff6 	ldr	x22, [sp, #632]
    8274:	aa1403e0 	mov	x0, x20
    8278:	f94143f7 	ldr	x23, [sp, #640]
    827c:	91298021 	add	x1, x1, #0xa60
    8280:	f94147f8 	ldr	x24, [sp, #648]
    8284:	d2800042 	mov	x2, #0x2                   	// #2
    8288:	17fffd0e 	b	76c0 <fwp_write+0x210>
    828c:	b0000021 	adrp	x1, d000 <__modti3+0x30>
    8290:	d2800042 	mov	x2, #0x2                   	// #2
    8294:	91266021 	add	x1, x1, #0x998
    8298:	17fffea3 	b	7d24 <fwp_write+0x874>
    829c:	f9400a63 	ldr	x3, [x19, #16]
    82a0:	8b030021 	add	x1, x1, x3
    82a4:	17ffff66 	b	803c <fwp_write+0xb8c>
    82a8:	f9400a61 	ldr	x1, [x19, #16]
    82ac:	8b0102a1 	add	x1, x21, x1
    82b0:	17fffdb3 	b	797c <fwp_write+0x4cc>
    82b4:	f9400a63 	ldr	x3, [x19, #16]
    82b8:	8b030021 	add	x1, x1, x3
    82bc:	17ffff56 	b	8014 <fwp_write+0xb64>
    82c0:	b9404840 	ldr	w0, [x2, #72]
    82c4:	91001ff5 	add	x21, sp, #0x7
    82c8:	34ffa360 	cbz	w0, 7734 <fwp_write+0x284>
    82cc:	52800503 	mov	w3, #0x28                  	// #40
    82d0:	aa1403e0 	mov	x0, x20
    82d4:	aa1503e1 	mov	x1, x21
    82d8:	d2800022 	mov	x2, #0x1                   	// #1
    82dc:	39001fe3 	strb	w3, [sp, #7]
    82e0:	97ffecec 	bl	3690 <buf_put>
    82e4:	b9401380 	ldr	w0, [x28, #16]
    82e8:	52800038 	mov	w24, #0x1                   	// #1
    82ec:	7100001f 	cmp	w0, #0x0
    82f0:	54ffa36c 	b.gt	775c <fwp_write+0x2ac>
    82f4:	17fffd32 	b	77bc <fwp_write+0x30c>
    82f8:	f9014bf9 	str	x25, [sp, #656]
    82fc:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe888>
    8300:	f9014ffa 	str	x26, [sp, #664]
    8304:	f9400676 	ldr	x22, [x19, #8]
    8308:	910ac333 	add	x19, x25, #0x2b0
    830c:	91002273 	add	x19, x19, #0x8
    8310:	937ffed8 	asr	x24, x22, #63
    8314:	aa1802c0 	orr	x0, x22, x24
    8318:	b5000320 	cbnz	x0, 837c <fwp_write+0xecc>
    831c:	110006b5 	add	w21, w21, #0x1
    8320:	710016bf 	cmp	w21, #0x5
    8324:	54ffffc1 	b.ne	831c <fwp_write+0xe6c>  // b.any
    8328:	b7f80578 	tbnz	x24, #63, 83d4 <fwp_write+0xf24>
    832c:	910023f3 	add	x19, sp, #0x8
    8330:	aa1603e2 	mov	x2, x22
    8334:	aa1303e0 	mov	x0, x19
    8338:	d2800003 	mov	x3, #0x0                   	// #0
    833c:	97ffeab9 	bl	2e20 <fwp_fmt_u128>
    8340:	910123f5 	add	x21, sp, #0x48
    8344:	b0000023 	adrp	x3, d000 <__modti3+0x30>
    8348:	aa1303e4 	mov	x4, x19
    834c:	aa1503e0 	mov	x0, x21
    8350:	91296063 	add	x3, x3, #0xa58
    8354:	d2804002 	mov	x2, #0x200                 	// #512
    8358:	52800041 	mov	w1, #0x2                   	// #2
    835c:	97ffe8f9 	bl	2740 <__sprintf_chk@plt>
    8360:	aa1503e0 	mov	x0, x21
    8364:	97ffe8f3 	bl	2730 <strlen@plt>
    8368:	aa1503e1 	mov	x1, x21
    836c:	aa0003e2 	mov	x2, x0
    8370:	aa1403e0 	mov	x0, x20
    8374:	97ffecc7 	bl	3690 <buf_put>
    8378:	17fffe47 	b	7c94 <fwp_write+0x7e4>
    837c:	f9400277 	ldr	x23, [x19]
    8380:	aa1603e0 	mov	x0, x22
    8384:	aa1803e1 	mov	x1, x24
    8388:	aa1703e2 	mov	x2, x23
    838c:	937ffefa 	asr	x26, x23, #63
    8390:	aa1a03e3 	mov	x3, x26
    8394:	9400130f 	bl	cfd0 <__modti3>
    8398:	aa010000 	orr	x0, x0, x1
    839c:	b40002c0 	cbz	x0, 83f4 <fwp_write+0xf44>
    83a0:	110006b5 	add	w21, w21, #0x1
    83a4:	91004273 	add	x19, x19, #0x10
    83a8:	710016bf 	cmp	w21, #0x5
    83ac:	54fffe81 	b.ne	837c <fwp_write+0xecc>  // b.any
    83b0:	17ffffde 	b	8328 <fwp_write+0xe78>
    83b4:	f9400a60 	ldr	x0, [x19, #16]
    83b8:	8b000021 	add	x1, x1, x0
    83bc:	17fffd75 	b	7990 <fwp_write+0x4e0>
    83c0:	528c29c0 	mov	w0, #0x614e                	// #24910
    83c4:	910123f5 	add	x21, sp, #0x48
    83c8:	72a009c0 	movk	w0, #0x4e, lsl #16
    83cc:	b9004be0 	str	w0, [sp, #72]
    83d0:	17fffda2 	b	7a58 <fwp_write+0x5a8>
    83d4:	528005a1 	mov	w1, #0x2d                  	// #45
    83d8:	eb1603e2 	negs	x2, x22
    83dc:	da1803e3 	ngc	x3, x24
    83e0:	910027e0 	add	x0, sp, #0x9
    83e4:	910023f3 	add	x19, sp, #0x8
    83e8:	390023e1 	strb	w1, [sp, #8]
    83ec:	97ffea8d 	bl	2e20 <fwp_fmt_u128>
    83f0:	17ffffd4 	b	8340 <fwp_write+0xe90>
    83f4:	aa1703e2 	mov	x2, x23
    83f8:	aa1a03e3 	mov	x3, x26
    83fc:	aa1603e0 	mov	x0, x22
    8400:	aa1803e1 	mov	x1, x24
    8404:	94001213 	bl	cc50 <__divti3>
    8408:	aa0003e2 	mov	x2, x0
    840c:	aa0103e3 	mov	x3, x1
    8410:	b7f80201 	tbnz	x1, #63, 8450 <fwp_write+0xfa0>
    8414:	910023f3 	add	x19, sp, #0x8
    8418:	aa1303e0 	mov	x0, x19
    841c:	97ffea81 	bl	2e20 <fwp_fmt_u128>
    8420:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8424:	910ac339 	add	x25, x25, #0x2b0
    8428:	910123f5 	add	x21, sp, #0x48
    842c:	aa1303e4 	mov	x4, x19
    8430:	aa1503e0 	mov	x0, x21
    8434:	b0000023 	adrp	x3, d000 <__modti3+0x30>
    8438:	f8616b25 	ldr	x5, [x25, x1]
    843c:	91294063 	add	x3, x3, #0xa50
    8440:	d2804002 	mov	x2, #0x200                 	// #512
    8444:	52800041 	mov	w1, #0x2                   	// #2
    8448:	97ffe8be 	bl	2740 <__sprintf_chk@plt>
    844c:	17ffffc5 	b	8360 <fwp_write+0xeb0>
    8450:	528005a4 	mov	w4, #0x2d                  	// #45
    8454:	eb0003e2 	negs	x2, x0
    8458:	da0103e3 	ngc	x3, x1
    845c:	910027e0 	add	x0, sp, #0x9
    8460:	910023f3 	add	x19, sp, #0x8
    8464:	390023e4 	strb	w4, [sp, #8]
    8468:	97ffea6e 	bl	2e20 <fwp_fmt_u128>
    846c:	17ffffed 	b	8420 <fwp_write+0xf70>
    8470:	f9013bf5 	str	x21, [sp, #624]
    8474:	f9013ff6 	str	x22, [sp, #632]
    8478:	f90143f7 	str	x23, [sp, #640]
    847c:	f90147f8 	str	x24, [sp, #648]
    8480:	f9014bf9 	str	x25, [sp, #656]
    8484:	f9014ffa 	str	x26, [sp, #664]
    8488:	f90153fb 	str	x27, [sp, #672]
    848c:	f90157fc 	str	x28, [sp, #680]
    8490:	fd015be8 	str	d8, [sp, #688]
    8494:	fd015fe9 	str	d9, [sp, #696]
    8498:	97ffe902 	bl	28a0 <__stack_chk_fail@plt>
    849c:	d503201f 	nop

00000000000084a0 <fwp_hof0.constprop.0>:
    84a0:	d10543ff 	sub	sp, sp, #0x150
    84a4:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    84a8:	f947f442 	ldr	x2, [x2, #4072]
    84ac:	a90e7bfd 	stp	x29, x30, [sp, #224]
    84b0:	910383fd 	add	x29, sp, #0xe0
    84b4:	f90023e0 	str	x0, [sp, #64]
    84b8:	f9400040 	ldr	x0, [x2]
    84bc:	f9006fe0 	str	x0, [sp, #216]
    84c0:	d2800000 	mov	x0, #0x0                   	// #0
    84c4:	f90027e1 	str	x1, [sp, #72]
    84c8:	b400a5a1 	cbz	x1, 997c <fwp_hof0.constprop.0+0x14dc>
    84cc:	900000c0 	adrp	x0, 20000 <__data_start>
    84d0:	91004000 	add	x0, x0, #0x10
    84d4:	91008000 	add	x0, x0, #0x20
    84d8:	f90017e0 	str	x0, [sp, #40]
    84dc:	910163e0 	add	x0, sp, #0x58
    84e0:	f9000fe0 	str	x0, [sp, #24]
    84e4:	910183e0 	add	x0, sp, #0x60
    84e8:	f90013e0 	str	x0, [sp, #32]
    84ec:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0xc90>
    84f0:	6d1427e8 	stp	d8, d9, [sp, #320]
    84f4:	fd41b008 	ldr	d8, [x0, #864]
    84f8:	a90f53f3 	stp	x19, x20, [sp, #240]
    84fc:	b0000394 	adrp	x20, 79000 <fwp_root_context+0xb90>
    8500:	a9105bf5 	stp	x21, x22, [sp, #256]
    8504:	a91163f7 	stp	x23, x24, [sp, #272]
    8508:	a9126bf9 	stp	x25, x26, [sp, #288]
    850c:	a91373fb 	stp	x27, x28, [sp, #304]
    8510:	91194282 	add	x2, x20, #0x650
    8514:	f94023e0 	ldr	x0, [sp, #64]
    8518:	f949ec43 	ldr	x3, [x2, #5080]
    851c:	f949d841 	ldr	x1, [x2, #5040]
    8520:	d370bc63 	lsl	x3, x3, #16
    8524:	cb010004 	sub	x4, x0, x1
    8528:	eb03009f 	cmp	x4, x3
    852c:	540004c2 	b.cs	85c4 <fwp_hof0.constprop.0+0x124>  // b.hs, b.nlast
    8530:	d350fc80 	lsr	x0, x4, #16
    8534:	f949fc46 	ldr	x6, [x2, #5112]
    8538:	8b000800 	add	x0, x0, x0, lsl #2
    853c:	d37df002 	lsl	x2, x0, #3
    8540:	8b0200c5 	add	x5, x6, x2
    8544:	f94010a0 	ldr	x0, [x5, #32]
    8548:	b40003e0 	cbz	x0, 85c4 <fwp_hof0.constprop.0+0x124>
    854c:	386268c2 	ldrb	w2, [x6, x2]
    8550:	7100085f 	cmp	w2, #0x2
    8554:	5400bea0 	b.eq	9d28 <fwp_hof0.constprop.0+0x1888>  // b.none
    8558:	7100045f 	cmp	w2, #0x1
    855c:	54000341 	b.ne	85c4 <fwp_hof0.constprop.0+0x124>  // b.any
    8560:	92403c82 	and	x2, x4, #0xffff
    8564:	294310a6 	ldp	w6, w4, [x5, #24]
    8568:	9b067c42 	mul	x2, x2, x6
    856c:	d360fc42 	lsr	x2, x2, #32
    8570:	eb04005f 	cmp	x2, x4
    8574:	54000282 	b.cs	85c4 <fwp_hof0.constprop.0+0x124>  // b.hs, b.nlast
    8578:	8b020000 	add	x0, x0, x2
    857c:	39400002 	ldrb	w2, [x0]
    8580:	34000222 	cbz	w2, 85c4 <fwp_hof0.constprop.0+0x124>
    8584:	900000c1 	adrp	x1, 20000 <__data_start>
    8588:	91014021 	add	x1, x1, #0x50
    858c:	b9415023 	ldr	w3, [x1, #336]
    8590:	34000083 	cbz	w3, 85a0 <fwp_hof0.constprop.0+0x100>
    8594:	f940bc23 	ldr	x3, [x1, #376]
    8598:	91000463 	add	x3, x3, #0x1
    859c:	f900bc23 	str	x3, [x1, #376]
    85a0:	7103f45f 	cmp	w2, #0xfd
    85a4:	5400cbe8 	b.hi	9f20 <fwp_hof0.constprop.0+0x1a80>  // b.pmore
    85a8:	91194281 	add	x1, x20, #0x650
    85ac:	11000442 	add	w2, w2, #0x1
    85b0:	39000002 	strb	w2, [x0]
    85b4:	aa0103e0 	mov	x0, x1
    85b8:	f949d821 	ldr	x1, [x1, #5040]
    85bc:	f949ec03 	ldr	x3, [x0, #5080]
    85c0:	d370bc63 	lsl	x3, x3, #16
    85c4:	f94023f5 	ldr	x21, [sp, #64]
    85c8:	d28018c0 	mov	x0, #0xc6                  	// #198
    85cc:	f90007e0 	str	x0, [sp, #8]
    85d0:	900000c0 	adrp	x0, 20000 <__data_start>
    85d4:	91014002 	add	x2, x0, #0x50
    85d8:	f94017e0 	ldr	x0, [sp, #40]
    85dc:	12800004 	mov	w4, #0xffffffff            	// #-1
    85e0:	b9005be4 	str	w4, [sp, #88]
    85e4:	cb010001 	sub	x1, x0, x1
    85e8:	d0ffffe0 	adrp	x0, 6000 <fwp_drop0+0xc0>
    85ec:	91108000 	add	x0, x0, #0x420
    85f0:	f90037e0 	str	x0, [sp, #104]
    85f4:	f941d840 	ldr	x0, [x2, #944]
    85f8:	f90033e0 	str	x0, [sp, #96]
    85fc:	f9400fe0 	ldr	x0, [sp, #24]
    8600:	f9003be0 	str	x0, [sp, #112]
    8604:	f94013e0 	ldr	x0, [sp, #32]
    8608:	f901d840 	str	x0, [x2, #944]
    860c:	eb03003f 	cmp	x1, x3
    8610:	54000882 	b.cs	8720 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    8614:	91194282 	add	x2, x20, #0x650
    8618:	d350fc20 	lsr	x0, x1, #16
    861c:	8b000800 	add	x0, x0, x0, lsl #2
    8620:	f949fc44 	ldr	x4, [x2, #5112]
    8624:	d37df003 	lsl	x3, x0, #3
    8628:	8b030082 	add	x2, x4, x3
    862c:	f9401053 	ldr	x19, [x2, #32]
    8630:	b4000793 	cbz	x19, 8720 <fwp_hof0.constprop.0+0x280>
    8634:	38636880 	ldrb	w0, [x4, x3]
    8638:	7100081f 	cmp	w0, #0x2
    863c:	5400a5a0 	b.eq	9af0 <fwp_hof0.constprop.0+0x1650>  // b.none
    8640:	7100041f 	cmp	w0, #0x1
    8644:	540006e1 	b.ne	8720 <fwp_hof0.constprop.0+0x280>  // b.any
    8648:	29430c44 	ldp	w4, w3, [x2, #24]
    864c:	92403c20 	and	x0, x1, #0xffff
    8650:	9b047c00 	mul	x0, x0, x4
    8654:	d360fc00 	lsr	x0, x0, #32
    8658:	eb03001f 	cmp	x0, x3
    865c:	54000382 	b.cs	86cc <fwp_hof0.constprop.0+0x22c>  // b.hs, b.nlast
    8660:	8b000260 	add	x0, x19, x0
    8664:	39400003 	ldrb	w3, [x0]
    8668:	34000323 	cbz	w3, 86cc <fwp_hof0.constprop.0+0x22c>
    866c:	900000c1 	adrp	x1, 20000 <__data_start>
    8670:	91014021 	add	x1, x1, #0x50
    8674:	b9415022 	ldr	w2, [x1, #336]
    8678:	34000082 	cbz	w2, 8688 <fwp_hof0.constprop.0+0x1e8>
    867c:	f940bc22 	ldr	x2, [x1, #376]
    8680:	91000442 	add	x2, x2, #0x1
    8684:	f900bc22 	str	x2, [x1, #376]
    8688:	7103f47f 	cmp	w3, #0xfd
    868c:	5400c0a8 	b.hi	9ea0 <fwp_hof0.constprop.0+0x1a00>  // b.pmore
    8690:	11000463 	add	w3, w3, #0x1
    8694:	39000003 	strb	w3, [x0]
    8698:	91194280 	add	x0, x20, #0x650
    869c:	f94017e3 	ldr	x3, [sp, #40]
    86a0:	f949d801 	ldr	x1, [x0, #5040]
    86a4:	f949ec02 	ldr	x2, [x0, #5080]
    86a8:	cb010061 	sub	x1, x3, x1
    86ac:	eb02403f 	cmp	x1, x2, lsl #16
    86b0:	54000382 	b.cs	8720 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    86b4:	f949fc00 	ldr	x0, [x0, #5112]
    86b8:	d350fc22 	lsr	x2, x1, #16
    86bc:	8b020842 	add	x2, x2, x2, lsl #2
    86c0:	8b020c02 	add	x2, x0, x2, lsl #3
    86c4:	f9401053 	ldr	x19, [x2, #32]
    86c8:	b40002d3 	cbz	x19, 8720 <fwp_hof0.constprop.0+0x280>
    86cc:	39400040 	ldrb	w0, [x2]
    86d0:	7100081f 	cmp	w0, #0x2
    86d4:	5400a160 	b.eq	9b00 <fwp_hof0.constprop.0+0x1660>  // b.none
    86d8:	7100041f 	cmp	w0, #0x1
    86dc:	54000221 	b.ne	8720 <fwp_hof0.constprop.0+0x280>  // b.any
    86e0:	29430043 	ldp	w3, w0, [x2, #24]
    86e4:	92403c21 	and	x1, x1, #0xffff
    86e8:	9b037c21 	mul	x1, x1, x3
    86ec:	d360fc21 	lsr	x1, x1, #32
    86f0:	eb00003f 	cmp	x1, x0
    86f4:	54000162 	b.cs	8720 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    86f8:	8b010273 	add	x19, x19, x1
    86fc:	39400261 	ldrb	w1, [x19]
    8700:	34000101 	cbz	w1, 8720 <fwp_hof0.constprop.0+0x280>
    8704:	7100043f 	cmp	w1, #0x1
    8708:	540075a0 	b.eq	95bc <fwp_hof0.constprop.0+0x111c>  // b.none
    870c:	7103fc3f 	cmp	w1, #0xff
    8710:	5400bcc0 	b.eq	9ea8 <fwp_hof0.constprop.0+0x1a08>  // b.none
    8714:	51000421 	sub	w1, w1, #0x1
    8718:	39000261 	strb	w1, [x19]
    871c:	d503201f 	nop
    8720:	b40075f5 	cbz	x21, 95dc <fwp_hof0.constprop.0+0x113c>
    8724:	aa1503e0 	mov	x0, x21
    8728:	d2800001 	mov	x1, #0x0                   	// #0
    872c:	d503201f 	nop
    8730:	f9400800 	ldr	x0, [x0, #16]
    8734:	91000421 	add	x1, x1, #0x1
    8738:	b5ffffc0 	cbnz	x0, 8730 <fwp_hof0.constprop.0+0x290>
    873c:	aa0103f6 	mov	x22, x1
    8740:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8744:	eb00003f 	cmp	x1, x0
    8748:	5400c4a8 	b.hi	9fdc <fwp_hof0.constprop.0+0x1b3c>  // b.pmore
    874c:	900000c0 	adrp	x0, 20000 <__data_start>
    8750:	91014013 	add	x19, x0, #0x50
    8754:	b943e660 	ldr	w0, [x19, #996]
    8758:	340074c0 	cbz	w0, 95f0 <fwp_hof0.constprop.0+0x1150>
    875c:	900000c0 	adrp	x0, 20000 <__data_start>
    8760:	91014000 	add	x0, x0, #0x50
    8764:	f9406c13 	ldr	x19, [x0, #216]
    8768:	f940c017 	ldr	x23, [x0, #384]
    876c:	eb1302ff 	cmp	x23, x19
    8770:	5400758a 	b.ge	9620 <fwp_hof0.constprop.0+0x1180>  // b.tcont
    8774:	f9404401 	ldr	x1, [x0, #136]
    8778:	8b1706e0 	add	x0, x23, x23, lsl #1
    877c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8780:	8b000ae0 	add	x0, x23, x0, lsl #2
    8784:	8b000c20 	add	x0, x1, x0, lsl #3
    8788:	b9400401 	ldr	w1, [x0, #4]
    878c:	35000081 	cbnz	w1, 879c <fwp_hof0.constprop.0+0x2fc>
    8790:	b9400001 	ldr	w1, [x0]
    8794:	6b02003f 	cmp	w1, w2
    8798:	54007449 	b.ls	9620 <fwp_hof0.constprop.0+0x1180>  // b.plast
    879c:	910006f7 	add	x23, x23, #0x1
    87a0:	9101a000 	add	x0, x0, #0x68
    87a4:	eb1302ff 	cmp	x23, x19
    87a8:	54ffff01 	b.ne	8788 <fwp_hof0.constprop.0+0x2e8>  // b.any
    87ac:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    87b0:	eb00027f 	cmp	x19, x0
    87b4:	5400c1ac 	b.gt	9fe8 <fwp_hof0.constprop.0+0x1b48>
    87b8:	900000c0 	adrp	x0, 20000 <__data_start>
    87bc:	91014000 	add	x0, x0, #0x50
    87c0:	f940a001 	ldr	x1, [x0, #320]
    87c4:	f940441c 	ldr	x28, [x0, #136]
    87c8:	eb13003f 	cmp	x1, x19
    87cc:	54000241 	b.ne	8814 <fwp_hof0.constprop.0+0x374>  // b.any
    87d0:	b400a873 	cbz	x19, 9cdc <fwp_hof0.constprop.0+0x183c>
    87d4:	d37ffa7b 	lsl	x27, x19, #1
    87d8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    87dc:	eb00037f 	cmp	x27, x0
    87e0:	9a80d37b 	csel	x27, x27, x0, le
    87e4:	8b1b0761 	add	x1, x27, x27, lsl #1
    87e8:	8b010b61 	add	x1, x27, x1, lsl #2
    87ec:	d37df021 	lsl	x1, x1, #3
    87f0:	aa1c03e0 	mov	x0, x28
    87f4:	52800002 	mov	w2, #0x0                   	// #0
    87f8:	97ffef2b 	bl	44a4 <ad_raw_realloc>
    87fc:	aa0003fc 	mov	x28, x0
    8800:	b4003800 	cbz	x0, 8f00 <fwp_hof0.constprop.0+0xa60>
    8804:	900000c0 	adrp	x0, 20000 <__data_start>
    8808:	91014000 	add	x0, x0, #0x50
    880c:	f900441c 	str	x28, [x0, #136]
    8810:	f900a01b 	str	x27, [x0, #320]
    8814:	8b130660 	add	x0, x19, x19, lsl #1
    8818:	8b1706fb 	add	x27, x23, x23, lsl #1
    881c:	4f000400 	movi	v0.4s, #0x0
    8820:	91000662 	add	x2, x19, #0x1
    8824:	8b000a60 	add	x0, x19, x0, lsl #2
    8828:	8b1b0afb 	add	x27, x23, x27, lsl #2
    882c:	900000c1 	adrp	x1, 20000 <__data_start>
    8830:	91014021 	add	x1, x1, #0x50
    8834:	8b000f80 	add	x0, x28, x0, lsl #3
    8838:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    883c:	f9006c22 	str	x2, [x1, #216]
    8840:	ad000000 	stp	q0, q0, [x0]
    8844:	ad010000 	stp	q0, q0, [x0, #32]
    8848:	ad020000 	stp	q0, q0, [x0, #64]
    884c:	f900301f 	str	xzr, [x0, #96]
    8850:	b0000020 	adrp	x0, d000 <__modti3+0x30>
    8854:	f900337f 	str	xzr, [x27, #96]
    8858:	911dc000 	add	x0, x0, #0x770
    885c:	97ffe875 	bl	2a30 <getenv@plt>
    8860:	b4006fa0 	cbz	x0, 9654 <fwp_hof0.constprop.0+0x11b4>
    8864:	39400001 	ldrb	w1, [x0]
    8868:	7100c03f 	cmp	w1, #0x30
    886c:	54006f41 	b.ne	9654 <fwp_hof0.constprop.0+0x11b4>  // b.any
    8870:	39400400 	ldrb	w0, [x0, #1]
    8874:	35006f00 	cbnz	w0, 9654 <fwp_hof0.constprop.0+0x11b4>
    8878:	900000c0 	adrp	x0, 20000 <__data_start>
    887c:	91014000 	add	x0, x0, #0x50
    8880:	2f000400 	mvni	v0.2s, #0x0
    8884:	b9400373 	ldr	w19, [x27]
    8888:	52800022 	mov	w2, #0x1                   	// #1
    888c:	910006e4 	add	x4, x23, #0x1
    8890:	f941d801 	ldr	x1, [x0, #944]
    8894:	0b020273 	add	w19, w19, w2
    8898:	29000b73 	stp	w19, w2, [x27]
    889c:	a900db76 	stp	x22, x22, [x27, #8]
    88a0:	f9002b7f 	str	xzr, [x27, #80]
    88a4:	f900c004 	str	x4, [x0, #384]
    88a8:	fd002f60 	str	d0, [x27, #88]
    88ac:	b400ba41 	cbz	x1, 9ff4 <fwp_hof0.constprop.0+0x1b54>
    88b0:	d0ffffe0 	adrp	x0, 6000 <fwp_drop0+0xc0>
    88b4:	91108003 	add	x3, x0, #0x420
    88b8:	14000003 	b	88c4 <fwp_hof0.constprop.0+0x424>
    88bc:	f9400021 	ldr	x1, [x1]
    88c0:	b400b9a1 	cbz	x1, 9ff4 <fwp_hof0.constprop.0+0x1b54>
    88c4:	f9400422 	ldr	x2, [x1, #8]
    88c8:	eb03005f 	cmp	x2, x3
    88cc:	54ffff81 	b.ne	88bc <fwp_hof0.constprop.0+0x41c>  // b.any
    88d0:	f9400820 	ldr	x0, [x1, #16]
    88d4:	2a1703e2 	mov	w2, w23
    88d8:	b9400001 	ldr	w1, [x0]
    88dc:	f9002b60 	str	x0, [x27, #80]
    88e0:	b9005f61 	str	w1, [x27, #92]
    88e4:	37f80081 	tbnz	w1, #31, 88f4 <fwp_hof0.constprop.0+0x454>
    88e8:	52800d03 	mov	w3, #0x68                  	// #104
    88ec:	9b237021 	smaddl	x1, w1, w3, x28
    88f0:	b9005837 	str	w23, [x1, #88]
    88f4:	b9000002 	str	w2, [x0]
    88f8:	d3707e73 	ubfiz	x19, x19, #16, #32
    88fc:	aa040273 	orr	x19, x19, x4
    8900:	aa1503e0 	mov	x0, x21
    8904:	d2800002 	mov	x2, #0x0                   	// #0
    8908:	b4007255 	cbz	x21, 9750 <fwp_hof0.constprop.0+0x12b0>
    890c:	d503201f 	nop
    8910:	f9400800 	ldr	x0, [x0, #16]
    8914:	91000442 	add	x2, x2, #0x1
    8918:	b5ffffc0 	cbnz	x0, 8910 <fwp_hof0.constprop.0+0x470>
    891c:	aa1503e1 	mov	x1, x21
    8920:	f9400821 	ldr	x1, [x1, #16]
    8924:	91000400 	add	x0, x0, #0x1
    8928:	b5ffffc1 	cbnz	x1, 8920 <fwp_hof0.constprop.0+0x480>
    892c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8930:	eb01001f 	cmp	x0, x1
    8934:	5400b3a8 	b.hi	9fa8 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    8938:	f100005f 	cmp	x2, #0x0
    893c:	540070ad 	b.le	9750 <fwp_hof0.constprop.0+0x12b0>
    8940:	eb00005f 	cmp	x2, x0
    8944:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8948:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    894c:	eb0102df 	cmp	x22, x1
    8950:	5400b2c8 	b.hi	9fa8 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    8954:	d37ffadc 	lsl	x28, x22, #1
    8958:	52800041 	mov	w1, #0x2                   	// #2
    895c:	91000780 	add	x0, x28, #0x1
    8960:	d37df000 	lsl	x0, x0, #3
    8964:	97fff1ff 	bl	5160 <fwp_heap_alloc>
    8968:	aa0003f7 	mov	x23, x0
    896c:	91194281 	add	x1, x20, #0x650
    8970:	aa0003fb 	mov	x27, x0
    8974:	aa0103e0 	mov	x0, x1
    8978:	f90002fc 	str	x28, [x23]
    897c:	f949d821 	ldr	x1, [x1, #5040]
    8980:	f949ec00 	ldr	x0, [x0, #5080]
    8984:	cb0102e1 	sub	x1, x23, x1
    8988:	eb00403f 	cmp	x1, x0, lsl #16
    898c:	540080e2 	b.cs	99a8 <fwp_hof0.constprop.0+0x1508>  // b.hs, b.nlast
    8990:	91194282 	add	x2, x20, #0x650
    8994:	d350fc20 	lsr	x0, x1, #16
    8998:	8b000800 	add	x0, x0, x0, lsl #2
    899c:	f949fc43 	ldr	x3, [x2, #5112]
    89a0:	d37df002 	lsl	x2, x0, #3
    89a4:	8b020060 	add	x0, x3, x2
    89a8:	f940101c 	ldr	x28, [x0, #32]
    89ac:	b400025c 	cbz	x28, 89f4 <fwp_hof0.constprop.0+0x554>
    89b0:	38626862 	ldrb	w2, [x3, x2]
    89b4:	7100085f 	cmp	w2, #0x2
    89b8:	54008aa0 	b.eq	9b0c <fwp_hof0.constprop.0+0x166c>  // b.none
    89bc:	7100045f 	cmp	w2, #0x1
    89c0:	540001a1 	b.ne	89f4 <fwp_hof0.constprop.0+0x554>  // b.any
    89c4:	29430002 	ldp	w2, w0, [x0, #24]
    89c8:	92403c21 	and	x1, x1, #0xffff
    89cc:	9b027c21 	mul	x1, x1, x2
    89d0:	d360fc21 	lsr	x1, x1, #32
    89d4:	eb00003f 	cmp	x1, x0
    89d8:	540000e2 	b.cs	89f4 <fwp_hof0.constprop.0+0x554>  // b.hs, b.nlast
    89dc:	8b01039c 	add	x28, x28, x1
    89e0:	39400380 	ldrb	w0, [x28]
    89e4:	7103fc1f 	cmp	w0, #0xff
    89e8:	540089c0 	b.eq	9b20 <fwp_hof0.constprop.0+0x1680>  // b.none
    89ec:	52800020 	mov	w0, #0x1                   	// #1
    89f0:	39000380 	strb	w0, [x28]
    89f4:	b4000236 	cbz	x22, 8a38 <fwp_hof0.constprop.0+0x598>
    89f8:	d3607e64 	lsl	x4, x19, #32
    89fc:	aa1503e1 	mov	x1, x21
    8a00:	f94006a5 	ldr	x5, [x21, #8]
    8a04:	aa0403e3 	mov	x3, x4
    8a08:	910022e2 	add	x2, x23, #0x8
    8a0c:	d2800000 	mov	x0, #0x0                   	// #0
    8a10:	14000005 	b	8a24 <fwp_hof0.constprop.0+0x584>
    8a14:	f9400425 	ldr	x5, [x1, #8]
    8a18:	ab040003 	adds	x3, x0, x4
    8a1c:	91004042 	add	x2, x2, #0x10
    8a20:	5400b046 	b.vs	a028 <fwp_hof0.constprop.0+0x1b88>
    8a24:	a9000c45 	stp	x5, x3, [x2]
    8a28:	91000400 	add	x0, x0, #0x1
    8a2c:	f9400821 	ldr	x1, [x1, #16]
    8a30:	eb16001f 	cmp	x0, x22
    8a34:	54ffff03 	b.cc	8a14 <fwp_hof0.constprop.0+0x574>  // b.lo, b.ul, b.last
    8a38:	f94002e0 	ldr	x0, [x23]
    8a3c:	f100041f 	cmp	x0, #0x1
    8a40:	54007b89 	b.ls	99b0 <fwp_hof0.constprop.0+0x1510>  // b.plast
    8a44:	d341fc00 	lsr	x0, x0, #1
    8a48:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8a4c:	d1000401 	sub	x1, x0, #0x1
    8a50:	eb02003f 	cmp	x1, x2
    8a54:	5400aaa8 	b.hi	9fa8 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    8a58:	d37ff83c 	lsl	x28, x1, #1
    8a5c:	b4007aa1 	cbz	x1, 99b0 <fwp_hof0.constprop.0+0x1510>
    8a60:	d10022e1 	sub	x1, x23, #0x8
    8a64:	910022f8 	add	x24, x23, #0x8
    8a68:	8b001036 	add	x22, x1, x0, lsl #4
    8a6c:	d503201f 	nop
    8a70:	f9400700 	ldr	x0, [x24, #8]
    8a74:	f9400f01 	ldr	x1, [x24, #24]
    8a78:	fd400300 	ldr	d0, [x24]
    8a7c:	fd400b01 	ldr	d1, [x24, #16]
    8a80:	97fff329 	bl	5724 <w120>
    8a84:	a9000700 	stp	x0, x1, [x24]
    8a88:	91004318 	add	x24, x24, #0x10
    8a8c:	eb16031f 	cmp	x24, x22
    8a90:	54ffff01 	b.ne	8a70 <fwp_hof0.constprop.0+0x5d0>  // b.any
    8a94:	91194296 	add	x22, x20, #0x650
    8a98:	f90002fc 	str	x28, [x23]
    8a9c:	aa1703e0 	mov	x0, x23
    8aa0:	97fff374 	bl	5870 <w176.constprop.0>
    8aa4:	aa0103fc 	mov	x28, x1
    8aa8:	f949dac1 	ldr	x1, [x22, #5040]
    8aac:	f949eec0 	ldr	x0, [x22, #5080]
    8ab0:	cb0102e1 	sub	x1, x23, x1
    8ab4:	eb00403f 	cmp	x1, x0, lsl #16
    8ab8:	54000382 	b.cs	8b28 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8abc:	d350fc20 	lsr	x0, x1, #16
    8ac0:	f949fec4 	ldr	x4, [x22, #5112]
    8ac4:	8b000800 	add	x0, x0, x0, lsl #2
    8ac8:	d37df000 	lsl	x0, x0, #3
    8acc:	8b000082 	add	x2, x4, x0
    8ad0:	f9401057 	ldr	x23, [x2, #32]
    8ad4:	b40002b7 	cbz	x23, 8b28 <fwp_hof0.constprop.0+0x688>
    8ad8:	38606880 	ldrb	w0, [x4, x0]
    8adc:	7100081f 	cmp	w0, #0x2
    8ae0:	540076c0 	b.eq	99b8 <fwp_hof0.constprop.0+0x1518>  // b.none
    8ae4:	7100041f 	cmp	w0, #0x1
    8ae8:	54000201 	b.ne	8b28 <fwp_hof0.constprop.0+0x688>  // b.any
    8aec:	29430043 	ldp	w3, w0, [x2, #24]
    8af0:	92403c21 	and	x1, x1, #0xffff
    8af4:	9b037c21 	mul	x1, x1, x3
    8af8:	d360fc21 	lsr	x1, x1, #32
    8afc:	eb00003f 	cmp	x1, x0
    8b00:	54000142 	b.cs	8b28 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8b04:	8b0102f7 	add	x23, x23, x1
    8b08:	394002e0 	ldrb	w0, [x23]
    8b0c:	340000e0 	cbz	w0, 8b28 <fwp_hof0.constprop.0+0x688>
    8b10:	7100041f 	cmp	w0, #0x1
    8b14:	540020e0 	b.eq	8f30 <fwp_hof0.constprop.0+0xa90>  // b.none
    8b18:	7103fc1f 	cmp	w0, #0xff
    8b1c:	540090c0 	b.eq	9d34 <fwp_hof0.constprop.0+0x1894>  // b.none
    8b20:	51000400 	sub	w0, w0, #0x1
    8b24:	390002e0 	strb	w0, [x23]
    8b28:	97ffede7 	bl	42c4 <caf75>
    8b2c:	9e670009 	fmov	d9, x0
    8b30:	93407e73 	sxtw	x19, w19
    8b34:	aa1303e0 	mov	x0, x19
    8b38:	97ffebfe 	bl	3b30 <fwp_tape_of>
    8b3c:	f9403001 	ldr	x1, [x0, #96]
    8b40:	aa0003ea 	mov	x10, x0
    8b44:	b500a461 	cbnz	x1, 9fd0 <fwp_hof0.constprop.0+0x1b30>
    8b48:	97ffe933 	bl	3014 <fwp_tape_unlink_scope>
    8b4c:	b9400002 	ldr	w2, [x0]
    8b50:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    8b54:	a9408018 	ldp	x24, x0, [x0, #8]
    8b58:	b900055f 	str	wzr, [x10, #4]
    8b5c:	a941e94b 	ldp	x11, x26, [x10, #24]
    8b60:	a942a15b 	ldp	x27, x8, [x10, #40]
    8b64:	a943e549 	ldp	x9, x25, [x10, #56]
    8b68:	f9402557 	ldr	x23, [x10, #72]
    8b6c:	6b01005f 	cmp	w2, w1
    8b70:	54000128 	b.hi	8b94 <fwp_hof0.constprop.0+0x6f4>  // b.pmore
    8b74:	900000c1 	adrp	x1, 20000 <__data_start>
    8b78:	91014022 	add	x2, x1, #0x50
    8b7c:	92403e61 	and	x1, x19, #0xffff
    8b80:	d1000421 	sub	x1, x1, #0x1
    8b84:	f940c043 	ldr	x3, [x2, #384]
    8b88:	eb03003f 	cmp	x1, x3
    8b8c:	5400004a 	b.ge	8b94 <fwp_hof0.constprop.0+0x6f4>  // b.tcont
    8b90:	f900c041 	str	x1, [x2, #384]
    8b94:	4f000400 	movi	v0.4s, #0x0
    8b98:	900000c1 	adrp	x1, 20000 <__data_start>
    8b9c:	91014023 	add	x3, x1, #0x50
    8ba0:	f9000d5f 	str	xzr, [x10, #24]
    8ba4:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    8ba8:	910243e4 	add	x4, sp, #0x90
    8bac:	9101e3e1 	add	x1, sp, #0x78
    8bb0:	f941d86c 	ldr	x12, [x3, #944]
    8bb4:	3c808140 	stur	q0, [x10, #8]
    8bb8:	90ffffe2 	adrp	x2, 4000 <fwp_heap_report+0x60>
    8bbc:	ad010140 	stp	q0, q0, [x10, #32]
    8bc0:	9115d042 	add	x2, x2, #0x574
    8bc4:	f9000be4 	str	x4, [sp, #16]
    8bc8:	a9078bec 	stp	x12, x2, [sp, #120]
    8bcc:	a908ebe4 	stp	x4, x26, [sp, #136]
    8bd0:	a909a3fb 	stp	x27, x8, [sp, #152]
    8bd4:	a90ae7e9 	stp	x9, x25, [sp, #168]
    8bd8:	a90bdfeb 	stp	x11, x23, [sp, #184]
    8bdc:	f901d861 	str	x1, [x3, #944]
    8be0:	b7f87a7c 	tbnz	x28, #63, 9b2c <fwp_hof0.constprop.0+0x168c>
    8be4:	eb9c827f 	cmp	x19, x28, asr #32
    8be8:	54009a81 	b.ne	9f38 <fwp_hof0.constprop.0+0x1a98>  // b.any
    8bec:	92407f96 	and	x22, x28, #0xffffffff
    8bf0:	eb3c401f 	cmp	x0, w28, uxtw
    8bf4:	5400990d 	b.le	9f14 <fwp_hof0.constprop.0+0x1a74>
    8bf8:	eb16031f 	cmp	x24, x22
    8bfc:	9a96c716 	csinc	x22, x24, x22, gt
    8c00:	eb1602ff 	cmp	x23, x22
    8c04:	5400168a 	b.ge	8ed4 <fwp_hof0.constprop.0+0xa34>  // b.tcont
    8c08:	f10002ff 	cmp	x23, #0x0
    8c0c:	9a9612f7 	csel	x23, x23, x22, ne	// ne = any
    8c10:	14000005 	b	8c24 <fwp_hof0.constprop.0+0x784>
    8c14:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8c18:	eb0002ff 	cmp	x23, x0
    8c1c:	d37ffaf7 	lsl	x23, x23, #1
    8c20:	9a96d2f7 	csel	x23, x23, x22, le
    8c24:	eb1602ff 	cmp	x23, x22
    8c28:	54ffff6b 	b.lt	8c14 <fwp_hof0.constprop.0+0x774>  // b.tstop
    8c2c:	b4008059 	cbz	x25, 9c34 <fwp_hof0.constprop.0+0x1794>
    8c30:	aa1903e0 	mov	x0, x25
    8c34:	d37df2e1 	lsl	x1, x23, #3
    8c38:	52800062 	mov	w2, #0x3                   	// #3
    8c3c:	a90327e8 	stp	x8, x9, [sp, #48]
    8c40:	97ffee19 	bl	44a4 <ad_raw_realloc>
    8c44:	a94327e8 	ldp	x8, x9, [sp, #48]
    8c48:	aa0003f9 	mov	x25, x0
    8c4c:	b4007e00 	cbz	x0, 9c0c <fwp_hof0.constprop.0+0x176c>
    8c50:	f9005bf9 	str	x25, [sp, #176]
    8c54:	f90063f7 	str	x23, [sp, #192]
    8c58:	b5001316 	cbnz	x22, 8eb8 <fwp_hof0.constprop.0+0xa18>
    8c5c:	b7f800bc 	tbnz	x28, #63, 8c70 <fwp_hof0.constprop.0+0x7d0>
    8c60:	92407f81 	and	x1, x28, #0xffffffff
    8c64:	fc617b20 	ldr	d0, [x25, x1, lsl #3]
    8c68:	1e692800 	fadd	d0, d0, d9
    8c6c:	fc217b20 	str	d0, [x25, x1, lsl #3]
    8c70:	d10006d6 	sub	x22, x22, #0x1
    8c74:	d1000703 	sub	x3, x24, #0x1
    8c78:	eb16031f 	cmp	x24, x22
    8c7c:	540003ac 	b.gt	8cf0 <fwp_hof0.constprop.0+0x850>
    8c80:	fc767b20 	ldr	d0, [x25, x22, lsl #3]
    8c84:	1e602008 	fcmp	d0, #0.0
    8c88:	540002e0 	b.eq	8ce4 <fwp_hof0.constprop.0+0x844>  // b.none
    8c8c:	cb180be0 	neg	x0, x24, lsl #2
    8c90:	cb1803e2 	neg	x2, x24
    8c94:	8b000341 	add	x1, x26, x0
    8c98:	b8767821 	ldr	w1, [x1, x22, lsl #2]
    8c9c:	37f80101 	tbnz	w1, #31, 8cbc <fwp_hof0.constprop.0+0x81c>
    8ca0:	8b020d0a 	add	x10, x8, x2, lsl #3
    8ca4:	93407c21 	sxtw	x1, w1
    8ca8:	fc767942 	ldr	d2, [x10, x22, lsl #3]
    8cac:	fc617b21 	ldr	d1, [x25, x1, lsl #3]
    8cb0:	1e620802 	fmul	d2, d0, d2
    8cb4:	1e622821 	fadd	d1, d1, d2
    8cb8:	fc217b21 	str	d1, [x25, x1, lsl #3]
    8cbc:	8b000360 	add	x0, x27, x0
    8cc0:	b8767800 	ldr	w0, [x0, x22, lsl #2]
    8cc4:	37f80100 	tbnz	w0, #31, 8ce4 <fwp_hof0.constprop.0+0x844>
    8cc8:	8b020d22 	add	x2, x9, x2, lsl #3
    8ccc:	93407c00 	sxtw	x0, w0
    8cd0:	fc767842 	ldr	d2, [x2, x22, lsl #3]
    8cd4:	fc607b21 	ldr	d1, [x25, x0, lsl #3]
    8cd8:	1e620800 	fmul	d0, d0, d2
    8cdc:	1e602820 	fadd	d0, d1, d0
    8ce0:	fc207b20 	str	d0, [x25, x0, lsl #3]
    8ce4:	d10006d6 	sub	x22, x22, #0x1
    8ce8:	eb16007f 	cmp	x3, x22
    8cec:	54fffca1 	b.ne	8c80 <fwp_hof0.constprop.0+0x7e0>  // b.any
    8cf0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8cf4:	eb00031f 	cmp	x24, x0
    8cf8:	540098a8 	b.hi	a00c <fwp_hof0.constprop.0+0x1b6c>  // b.pmore
    8cfc:	91000700 	add	x0, x24, #0x1
    8d00:	52800041 	mov	w1, #0x2                   	// #2
    8d04:	d37df000 	lsl	x0, x0, #3
    8d08:	97fff116 	bl	5160 <fwp_heap_alloc>
    8d0c:	aa0003e2 	mov	x2, x0
    8d10:	aa0003f3 	mov	x19, x0
    8d14:	d2800001 	mov	x1, #0x0                   	// #0
    8d18:	f8008458 	str	x24, [x2], #8
    8d1c:	b40000d8 	cbz	x24, 8d34 <fwp_hof0.constprop.0+0x894>
    8d20:	f8617b20 	ldr	x0, [x25, x1, lsl #3]
    8d24:	f8217840 	str	x0, [x2, x1, lsl #3]
    8d28:	91000421 	add	x1, x1, #0x1
    8d2c:	eb01031f 	cmp	x24, x1
    8d30:	54ffff81 	b.ne	8d20 <fwp_hof0.constprop.0+0x880>  // b.any
    8d34:	900000c0 	adrp	x0, 20000 <__data_start>
    8d38:	91014001 	add	x1, x0, #0x50
    8d3c:	f9400be0 	ldr	x0, [sp, #16]
    8d40:	f9403ff7 	ldr	x23, [sp, #120]
    8d44:	f901d837 	str	x23, [x1, #944]
    8d48:	97ffee0b 	bl	4574 <fwp_tape_buffers_release>
    8d4c:	91194282 	add	x2, x20, #0x650
    8d50:	f949d841 	ldr	x1, [x2, #5040]
    8d54:	f949ec40 	ldr	x0, [x2, #5080]
    8d58:	cb010261 	sub	x1, x19, x1
    8d5c:	eb00403f 	cmp	x1, x0, lsl #16
    8d60:	54000322 	b.cs	8dc4 <fwp_hof0.constprop.0+0x924>  // b.hs, b.nlast
    8d64:	d350fc20 	lsr	x0, x1, #16
    8d68:	f949fc43 	ldr	x3, [x2, #5112]
    8d6c:	8b000800 	add	x0, x0, x0, lsl #2
    8d70:	d37df002 	lsl	x2, x0, #3
    8d74:	8b020060 	add	x0, x3, x2
    8d78:	f9401016 	ldr	x22, [x0, #32]
    8d7c:	b4000256 	cbz	x22, 8dc4 <fwp_hof0.constprop.0+0x924>
    8d80:	38626862 	ldrb	w2, [x3, x2]
    8d84:	7100085f 	cmp	w2, #0x2
    8d88:	54006d60 	b.eq	9b34 <fwp_hof0.constprop.0+0x1694>  // b.none
    8d8c:	7100045f 	cmp	w2, #0x1
    8d90:	540001a1 	b.ne	8dc4 <fwp_hof0.constprop.0+0x924>  // b.any
    8d94:	29430002 	ldp	w2, w0, [x0, #24]
    8d98:	92403c21 	and	x1, x1, #0xffff
    8d9c:	9b027c21 	mul	x1, x1, x2
    8da0:	d360fc21 	lsr	x1, x1, #32
    8da4:	eb00003f 	cmp	x1, x0
    8da8:	540000e2 	b.cs	8dc4 <fwp_hof0.constprop.0+0x924>  // b.hs, b.nlast
    8dac:	8b0102d6 	add	x22, x22, x1
    8db0:	394002c0 	ldrb	w0, [x22]
    8db4:	7103fc1f 	cmp	w0, #0xff
    8db8:	54006c80 	b.eq	9b48 <fwp_hof0.constprop.0+0x16a8>  // b.none
    8dbc:	52800020 	mov	w0, #0x1                   	// #1
    8dc0:	390002c0 	strb	w0, [x22]
    8dc4:	f94013e0 	ldr	x0, [sp, #32]
    8dc8:	eb0002ff 	cmp	x23, x0
    8dcc:	540092c1 	b.ne	a024 <fwp_hof0.constprop.0+0x1b84>  // b.any
    8dd0:	900000c0 	adrp	x0, 20000 <__data_start>
    8dd4:	91014001 	add	x1, x0, #0x50
    8dd8:	f9400fe0 	ldr	x0, [sp, #24]
    8ddc:	f94033e2 	ldr	x2, [sp, #96]
    8de0:	f901d822 	str	x2, [x1, #944]
    8de4:	97fff58f 	bl	6420 <fwp_tape_scope_release>
    8de8:	f9400260 	ldr	x0, [x19]
    8dec:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    8df0:	b7f845c0 	tbnz	x0, #63, 96a8 <fwp_hof0.constprop.0+0x1208>
    8df4:	91194282 	add	x2, x20, #0x650
    8df8:	f949d840 	ldr	x0, [x2, #5040]
    8dfc:	f949ec41 	ldr	x1, [x2, #5080]
    8e00:	cb000260 	sub	x0, x19, x0
    8e04:	eb01401f 	cmp	x0, x1, lsl #16
    8e08:	54004502 	b.cs	96a8 <fwp_hof0.constprop.0+0x1208>  // b.hs, b.nlast
    8e0c:	d350fc01 	lsr	x1, x0, #16
    8e10:	f949fc44 	ldr	x4, [x2, #5112]
    8e14:	8b010821 	add	x1, x1, x1, lsl #2
    8e18:	d37df021 	lsl	x1, x1, #3
    8e1c:	8b010083 	add	x3, x4, x1
    8e20:	f9401062 	ldr	x2, [x3, #32]
    8e24:	b4004422 	cbz	x2, 96a8 <fwp_hof0.constprop.0+0x1208>
    8e28:	38616881 	ldrb	w1, [x4, x1]
    8e2c:	7100083f 	cmp	w1, #0x2
    8e30:	54004360 	b.eq	969c <fwp_hof0.constprop.0+0x11fc>  // b.none
    8e34:	7100043f 	cmp	w1, #0x1
    8e38:	54004381 	b.ne	96a8 <fwp_hof0.constprop.0+0x1208>  // b.any
    8e3c:	29430464 	ldp	w4, w1, [x3, #24]
    8e40:	92403c00 	and	x0, x0, #0xffff
    8e44:	9b047c00 	mul	x0, x0, x4
    8e48:	d360fc00 	lsr	x0, x0, #32
    8e4c:	eb01001f 	cmp	x0, x1
    8e50:	540042c2 	b.cs	96a8 <fwp_hof0.constprop.0+0x1208>  // b.hs, b.nlast
    8e54:	8b000042 	add	x2, x2, x0
    8e58:	39400040 	ldrb	w0, [x2]
    8e5c:	7100041f 	cmp	w0, #0x1
    8e60:	54004241 	b.ne	96a8 <fwp_hof0.constprop.0+0x1208>  // b.any
    8e64:	aa1303fc 	mov	x28, x19
    8e68:	aa1303f6 	mov	x22, x19
    8e6c:	d2800000 	mov	x0, #0x0                   	// #0
    8e70:	910022c3 	add	x3, x22, #0x8
    8e74:	91002265 	add	x5, x19, #0x8
    8e78:	d2800001 	mov	x1, #0x0                   	// #0
    8e7c:	b5000157 	cbnz	x23, 8ea4 <fwp_hof0.constprop.0+0xa04>
    8e80:	1400004d 	b	8fb4 <fwp_hof0.constprop.0+0xb14>
    8e84:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8e88:	f9400382 	ldr	x2, [x28]
    8e8c:	1e600900 	fmul	d0, d8, d0
    8e90:	b7f88862 	tbnz	x2, #63, 9f9c <fwp_hof0.constprop.0+0x1afc>
    8e94:	91000421 	add	x1, x1, #0x1
    8e98:	fc008460 	str	d0, [x3], #8
    8e9c:	eb0102ff 	cmp	x23, x1
    8ea0:	540008a0 	b.eq	8fb4 <fwp_hof0.constprop.0+0xb14>  // b.none
    8ea4:	f9400264 	ldr	x4, [x19]
    8ea8:	aa0503e2 	mov	x2, x5
    8eac:	b6fffec4 	tbz	x4, #63, 8e84 <fwp_hof0.constprop.0+0x9e4>
    8eb0:	f9400a62 	ldr	x2, [x19, #16]
    8eb4:	17fffff4 	b	8e84 <fwp_hof0.constprop.0+0x9e4>
    8eb8:	d37df2c2 	lsl	x2, x22, #3
    8ebc:	aa1903e0 	mov	x0, x25
    8ec0:	52800001 	mov	w1, #0x0                   	// #0
    8ec4:	a90327e8 	stp	x8, x9, [sp, #48]
    8ec8:	97ffe66a 	bl	2870 <memset@plt>
    8ecc:	a94327e8 	ldp	x8, x9, [sp, #48]
    8ed0:	17ffff63 	b	8c5c <fwp_hof0.constprop.0+0x7bc>
    8ed4:	f100033f 	cmp	x25, #0x0
    8ed8:	1a9f17e0 	cset	w0, eq	// eq = none
    8edc:	f10002df 	cmp	x22, #0x0
    8ee0:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8ee4:	54ffeba0 	b.eq	8c58 <fwp_hof0.constprop.0+0x7b8>  // b.none
    8ee8:	900000c0 	adrp	x0, 20000 <__data_start>
    8eec:	91014018 	add	x24, x0, #0x50
    8ef0:	f9400be0 	ldr	x0, [sp, #16]
    8ef4:	f9403fe1 	ldr	x1, [sp, #120]
    8ef8:	f901db01 	str	x1, [x24, #944]
    8efc:	97ffed9e 	bl	4574 <fwp_tape_buffers_release>
    8f00:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    8f04:	f947e863 	ldr	x3, [x3, #4048]
    8f08:	d2800262 	mov	x2, #0x13                  	// #19
    8f0c:	d2800021 	mov	x1, #0x1                   	// #1
    8f10:	b0000020 	adrp	x0, d000 <__modti3+0x30>
    8f14:	910de000 	add	x0, x0, #0x378
    8f18:	f9400063 	ldr	x3, [x3]
    8f1c:	97ffe6a1 	bl	29a0 <fwrite@plt>
    8f20:	d2800000 	mov	x0, #0x0                   	// #0
    8f24:	97ffe6ab 	bl	29d0 <fflush@plt>
    8f28:	52800cc0 	mov	w0, #0x66                  	// #102
    8f2c:	97ffe6b9 	bl	2a10 <_Exit@plt>
    8f30:	f9400365 	ldr	x5, [x27]
    8f34:	aa1b03e0 	mov	x0, x27
    8f38:	f949eec3 	ldr	x3, [x22, #5080]
    8f3c:	f949dac1 	ldr	x1, [x22, #5040]
    8f40:	d370bc63 	lsl	x3, x3, #16
    8f44:	cb010362 	sub	x2, x27, x1
    8f48:	b7f85445 	tbnz	x5, #63, 99d0 <fwp_hof0.constprop.0+0x1530>
    8f4c:	eb02007f 	cmp	x3, x2
    8f50:	54ffdec9 	b.ls	8b28 <fwp_hof0.constprop.0+0x688>  // b.plast
    8f54:	d350fc40 	lsr	x0, x2, #16
    8f58:	8b000800 	add	x0, x0, x0, lsl #2
    8f5c:	d37df000 	lsl	x0, x0, #3
    8f60:	8b000083 	add	x3, x4, x0
    8f64:	f9401061 	ldr	x1, [x3, #32]
    8f68:	b4ffde01 	cbz	x1, 8b28 <fwp_hof0.constprop.0+0x688>
    8f6c:	38606880 	ldrb	w0, [x4, x0]
    8f70:	7100081f 	cmp	w0, #0x2
    8f74:	54005f00 	b.eq	9b54 <fwp_hof0.constprop.0+0x16b4>  // b.none
    8f78:	7100041f 	cmp	w0, #0x1
    8f7c:	54ffdd61 	b.ne	8b28 <fwp_hof0.constprop.0+0x688>  // b.any
    8f80:	92403c40 	and	x0, x2, #0xffff
    8f84:	29430864 	ldp	w4, w2, [x3, #24]
    8f88:	9b047c00 	mul	x0, x0, x4
    8f8c:	d360fc00 	lsr	x0, x0, #32
    8f90:	eb02001f 	cmp	x0, x2
    8f94:	54ffdca2 	b.cs	8b28 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8f98:	8b000021 	add	x1, x1, x0
    8f9c:	39400020 	ldrb	w0, [x1]
    8fa0:	7100041f 	cmp	w0, #0x1
    8fa4:	54ffdc21 	b.ne	8b28 <fwp_hof0.constprop.0+0x688>  // b.any
    8fa8:	aa1b03e0 	mov	x0, x27
    8fac:	97ffef4d 	bl	4ce0 <fwp_mem_free>
    8fb0:	17fffede 	b	8b28 <fwp_hof0.constprop.0+0x688>
    8fb4:	97fff707 	bl	6bd0 <fwp_drop10>
    8fb8:	aa1503e1 	mov	x1, x21
    8fbc:	d2800002 	mov	x2, #0x0                   	// #0
    8fc0:	b40067b5 	cbz	x21, 9cb4 <fwp_hof0.constprop.0+0x1814>
    8fc4:	d503201f 	nop
    8fc8:	f9400821 	ldr	x1, [x1, #16]
    8fcc:	91000442 	add	x2, x2, #0x1
    8fd0:	b5ffffc1 	cbnz	x1, 8fc8 <fwp_hof0.constprop.0+0xb28>
    8fd4:	f9400385 	ldr	x5, [x28]
    8fd8:	9240f8a4 	and	x4, x5, #0x7fffffffffffffff
    8fdc:	b7f82b65 	tbnz	x5, #63, 9548 <fwp_hof0.constprop.0+0x10a8>
    8fe0:	91194281 	add	x1, x20, #0x650
    8fe4:	f949d820 	ldr	x0, [x1, #5040]
    8fe8:	f949ec21 	ldr	x1, [x1, #5080]
    8fec:	cb0002c0 	sub	x0, x22, x0
    8ff0:	eb01401f 	cmp	x0, x1, lsl #16
    8ff4:	54002aa2 	b.cs	9548 <fwp_hof0.constprop.0+0x10a8>  // b.hs, b.nlast
    8ff8:	91194283 	add	x3, x20, #0x650
    8ffc:	d350fc01 	lsr	x1, x0, #16
    9000:	8b010821 	add	x1, x1, x1, lsl #2
    9004:	f949fc67 	ldr	x7, [x3, #5112]
    9008:	d37df021 	lsl	x1, x1, #3
    900c:	8b0100e6 	add	x6, x7, x1
    9010:	f94010c3 	ldr	x3, [x6, #32]
    9014:	b4002983 	cbz	x3, 9544 <fwp_hof0.constprop.0+0x10a4>
    9018:	386168e1 	ldrb	w1, [x7, x1]
    901c:	7100083f 	cmp	w1, #0x2
    9020:	540028e0 	b.eq	953c <fwp_hof0.constprop.0+0x109c>  // b.none
    9024:	7100043f 	cmp	w1, #0x1
    9028:	540028e1 	b.ne	9544 <fwp_hof0.constprop.0+0x10a4>  // b.any
    902c:	294304c7 	ldp	w7, w1, [x6, #24]
    9030:	92403c00 	and	x0, x0, #0xffff
    9034:	9b077c00 	mul	x0, x0, x7
    9038:	d360fc00 	lsr	x0, x0, #32
    903c:	eb01001f 	cmp	x0, x1
    9040:	54002822 	b.cs	9544 <fwp_hof0.constprop.0+0x10a4>  // b.hs, b.nlast
    9044:	8b000063 	add	x3, x3, x0
    9048:	39400060 	ldrb	w0, [x3]
    904c:	7100041f 	cmp	w0, #0x1
    9050:	540027a1 	b.ne	9544 <fwp_hof0.constprop.0+0x10a4>  // b.any
    9054:	b90033e0 	str	w0, [sp, #48]
    9058:	eb02009f 	cmp	x4, x2
    905c:	9a829084 	csel	x4, x4, x2, ls	// ls = plast
    9060:	9100239b 	add	x27, x28, #0x8
    9064:	b4007184 	cbz	x4, 9e94 <fwp_hof0.constprop.0+0x19f4>
    9068:	d37df087 	lsl	x7, x4, #3
    906c:	aa1503e2 	mov	x2, x21
    9070:	910022c0 	add	x0, x22, #0x8
    9074:	d2800001 	mov	x1, #0x0                   	// #0
    9078:	1400000a 	b	90a0 <fwp_hof0.constprop.0+0xc00>
    907c:	fc6168c1 	ldr	d1, [x6, x1]
    9080:	fd400440 	ldr	d0, [x2, #8]
    9084:	1e613800 	fsub	d0, d0, d1
    9088:	fc216b60 	str	d0, [x27, x1]
    908c:	91002021 	add	x1, x1, #0x8
    9090:	f9400842 	ldr	x2, [x2, #16]
    9094:	eb07003f 	cmp	x1, x7
    9098:	540001a0 	b.eq	90cc <fwp_hof0.constprop.0+0xc2c>  // b.none
    909c:	f9400385 	ldr	x5, [x28]
    90a0:	aa0003e6 	mov	x6, x0
    90a4:	b6fffec5 	tbz	x5, #63, 907c <fwp_hof0.constprop.0+0xbdc>
    90a8:	f9400ac6 	ldr	x6, [x22, #16]
    90ac:	fd400440 	ldr	d0, [x2, #8]
    90b0:	fc6168c1 	ldr	d1, [x6, x1]
    90b4:	1e613800 	fsub	d0, d0, d1
    90b8:	fc216b60 	str	d0, [x27, x1]
    90bc:	91002021 	add	x1, x1, #0x8
    90c0:	f9400842 	ldr	x2, [x2, #16]
    90c4:	eb07003f 	cmp	x1, x7
    90c8:	54fffea1 	b.ne	909c <fwp_hof0.constprop.0+0xbfc>  // b.any
    90cc:	b4007215 	cbz	x21, 9f0c <fwp_hof0.constprop.0+0x1a6c>
    90d0:	91194280 	add	x0, x20, #0x650
    90d4:	aa1503e7 	mov	x7, x21
    90d8:	d2800017 	mov	x23, #0x0                   	// #0
    90dc:	f949ec09 	ldr	x9, [x0, #5080]
    90e0:	f949d80a 	ldr	x10, [x0, #5040]
    90e4:	f949fc08 	ldr	x8, [x0, #5112]
    90e8:	d370bd29 	lsl	x9, x9, #16
    90ec:	14000006 	b	9104 <fwp_hof0.constprop.0+0xc64>
    90f0:	f94008e7 	ldr	x7, [x7, #16]
    90f4:	910006f7 	add	x23, x23, #0x1
    90f8:	f10000ff 	cmp	x7, #0x0
    90fc:	fa571080 	ccmp	x4, x23, #0x0, ne	// ne = any
    9100:	54000329 	b.ls	9164 <fwp_hof0.constprop.0+0xcc4>  // b.plast
    9104:	cb0a00e0 	sub	x0, x7, x10
    9108:	eb09001f 	cmp	x0, x9
    910c:	540002c2 	b.cs	9164 <fwp_hof0.constprop.0+0xcc4>  // b.hs, b.nlast
    9110:	d350fc01 	lsr	x1, x0, #16
    9114:	8b010821 	add	x1, x1, x1, lsl #2
    9118:	d37df021 	lsl	x1, x1, #3
    911c:	8b010106 	add	x6, x8, x1
    9120:	f94010c2 	ldr	x2, [x6, #32]
    9124:	b4000202 	cbz	x2, 9164 <fwp_hof0.constprop.0+0xcc4>
    9128:	38616901 	ldrb	w1, [x8, x1]
    912c:	7100083f 	cmp	w1, #0x2
    9130:	54000e00 	b.eq	92f0 <fwp_hof0.constprop.0+0xe50>  // b.none
    9134:	7100043f 	cmp	w1, #0x1
    9138:	54000161 	b.ne	9164 <fwp_hof0.constprop.0+0xcc4>  // b.any
    913c:	294304cb 	ldp	w11, w1, [x6, #24]
    9140:	92403c00 	and	x0, x0, #0xffff
    9144:	9b0b7c00 	mul	x0, x0, x11
    9148:	d360fc00 	lsr	x0, x0, #32
    914c:	eb01001f 	cmp	x0, x1
    9150:	540000a2 	b.cs	9164 <fwp_hof0.constprop.0+0xcc4>  // b.hs, b.nlast
    9154:	8b000042 	add	x2, x2, x0
    9158:	39400040 	ldrb	w0, [x2]
    915c:	7100041f 	cmp	w0, #0x1
    9160:	54fffc80 	b.eq	90f0 <fwp_hof0.constprop.0+0xc50>  // b.none
    9164:	eb17009f 	cmp	x4, x23
    9168:	54000cc9 	b.ls	9300 <fwp_hof0.constprop.0+0xe60>  // b.plast
    916c:	aa0403f8 	mov	x24, x4
    9170:	d1002379 	sub	x25, x27, #0x8
    9174:	910323f3 	add	x19, sp, #0xc8
    9178:	9119429a 	add	x26, x20, #0x650
    917c:	d280001c 	mov	x28, #0x0                   	// #0
    9180:	14000012 	b	91c8 <fwp_hof0.constprop.0+0xd28>
    9184:	7100045f 	cmp	w2, #0x1
    9188:	540001a1 	b.ne	91bc <fwp_hof0.constprop.0+0xd1c>  // b.any
    918c:	29430909 	ldp	w9, w2, [x8, #24]
    9190:	92403c21 	and	x1, x1, #0xffff
    9194:	9b097c21 	mul	x1, x1, x9
    9198:	d360fc21 	lsr	x1, x1, #32
    919c:	eb02003f 	cmp	x1, x2
    91a0:	540000e2 	b.cs	91bc <fwp_hof0.constprop.0+0xd1c>  // b.hs, b.nlast
    91a4:	8b010000 	add	x0, x0, x1
    91a8:	39400001 	ldrb	w1, [x0]
    91ac:	7103fc3f 	cmp	w1, #0xff
    91b0:	54002f80 	b.eq	97a0 <fwp_hof0.constprop.0+0x1300>  // b.none
    91b4:	52800021 	mov	w1, #0x1                   	// #1
    91b8:	39000001 	strb	w1, [x0]
    91bc:	d1000718 	sub	x24, x24, #0x1
    91c0:	eb1802ff 	cmp	x23, x24
    91c4:	54000362 	b.cs	9230 <fwp_hof0.constprop.0+0xd90>  // b.hs, b.nlast
    91c8:	f8787b22 	ldr	x2, [x25, x24, lsl #3]
    91cc:	aa1303e1 	mov	x1, x19
    91d0:	52800020 	mov	w0, #0x1                   	// #1
    91d4:	a90cf3e2 	stp	x2, x28, [sp, #200]
    91d8:	97fff043 	bl	52e4 <fwp_data.part.0.constprop.0>
    91dc:	aa0003fc 	mov	x28, x0
    91e0:	f949db41 	ldr	x1, [x26, #5040]
    91e4:	f949ef40 	ldr	x0, [x26, #5080]
    91e8:	cb010381 	sub	x1, x28, x1
    91ec:	eb00403f 	cmp	x1, x0, lsl #16
    91f0:	54fffe62 	b.cs	91bc <fwp_hof0.constprop.0+0xd1c>  // b.hs, b.nlast
    91f4:	d350fc20 	lsr	x0, x1, #16
    91f8:	f949ff49 	ldr	x9, [x26, #5112]
    91fc:	8b000800 	add	x0, x0, x0, lsl #2
    9200:	d37df002 	lsl	x2, x0, #3
    9204:	8b020128 	add	x8, x9, x2
    9208:	f9401100 	ldr	x0, [x8, #32]
    920c:	b4fffd80 	cbz	x0, 91bc <fwp_hof0.constprop.0+0xd1c>
    9210:	38626922 	ldrb	w2, [x9, x2]
    9214:	7100085f 	cmp	w2, #0x2
    9218:	54fffb61 	b.ne	9184 <fwp_hof0.constprop.0+0xce4>  // b.any
    921c:	72003c3f 	tst	w1, #0xffff
    9220:	54fffc40 	b.eq	91a8 <fwp_hof0.constprop.0+0xd08>  // b.none
    9224:	d1000718 	sub	x24, x24, #0x1
    9228:	eb1802ff 	cmp	x23, x24
    922c:	54fffce3 	b.cc	91c8 <fwp_hof0.constprop.0+0xd28>  // b.lo, b.ul, b.last
    9230:	b50006b7 	cbnz	x23, 9304 <fwp_hof0.constprop.0+0xe64>
    9234:	b94033e0 	ldr	w0, [sp, #48]
    9238:	d2800004 	mov	x4, #0x0                   	// #0
    923c:	7100001f 	cmp	w0, #0x0
    9240:	d2800020 	mov	x0, #0x1                   	// #1
    9244:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    9248:	b40007c4 	cbz	x4, 9340 <fwp_hof0.constprop.0+0xea0>
    924c:	d1000497 	sub	x23, x4, #0x1
    9250:	2a0003f9 	mov	w25, w0
    9254:	9119429a 	add	x26, x20, #0x650
    9258:	f8777b62 	ldr	x2, [x27, x23, lsl #3]
    925c:	aa1303e1 	mov	x1, x19
    9260:	52800020 	mov	w0, #0x1                   	// #1
    9264:	a90cf3e2 	stp	x2, x28, [sp, #200]
    9268:	97fff01f 	bl	52e4 <fwp_data.part.0.constprop.0>
    926c:	aa0003fc 	mov	x28, x0
    9270:	f949db41 	ldr	x1, [x26, #5040]
    9274:	f949ef40 	ldr	x0, [x26, #5080]
    9278:	cb010381 	sub	x1, x28, x1
    927c:	eb00403f 	cmp	x1, x0, lsl #16
    9280:	54000302 	b.cs	92e0 <fwp_hof0.constprop.0+0xe40>  // b.hs, b.nlast
    9284:	d350fc22 	lsr	x2, x1, #16
    9288:	f949ff47 	ldr	x7, [x26, #5112]
    928c:	8b020842 	add	x2, x2, x2, lsl #2
    9290:	d37df042 	lsl	x2, x2, #3
    9294:	8b0200e5 	add	x5, x7, x2
    9298:	f94010b8 	ldr	x24, [x5, #32]
    929c:	b4000238 	cbz	x24, 92e0 <fwp_hof0.constprop.0+0xe40>
    92a0:	386268e2 	ldrb	w2, [x7, x2]
    92a4:	7100085f 	cmp	w2, #0x2
    92a8:	54001440 	b.eq	9530 <fwp_hof0.constprop.0+0x1090>  // b.none
    92ac:	7100045f 	cmp	w2, #0x1
    92b0:	54000181 	b.ne	92e0 <fwp_hof0.constprop.0+0xe40>  // b.any
    92b4:	294308a7 	ldp	w7, w2, [x5, #24]
    92b8:	92403c21 	and	x1, x1, #0xffff
    92bc:	9b077c21 	mul	x1, x1, x7
    92c0:	d360fc21 	lsr	x1, x1, #32
    92c4:	eb02003f 	cmp	x1, x2
    92c8:	540000c2 	b.cs	92e0 <fwp_hof0.constprop.0+0xe40>  // b.hs, b.nlast
    92cc:	8b010318 	add	x24, x24, x1
    92d0:	39400301 	ldrb	w1, [x24]
    92d4:	7103fc3f 	cmp	w1, #0xff
    92d8:	54001260 	b.eq	9524 <fwp_hof0.constprop.0+0x1084>  // b.none
    92dc:	39000319 	strb	w25, [x24]
    92e0:	d10006f7 	sub	x23, x23, #0x1
    92e4:	b10006ff 	cmn	x23, #0x1
    92e8:	54fffb81 	b.ne	9258 <fwp_hof0.constprop.0+0xdb8>  // b.any
    92ec:	14000015 	b	9340 <fwp_hof0.constprop.0+0xea0>
    92f0:	72003c1f 	tst	w0, #0xffff
    92f4:	54fff320 	b.eq	9158 <fwp_hof0.constprop.0+0xcb8>  // b.none
    92f8:	eb17009f 	cmp	x4, x23
    92fc:	54fff388 	b.hi	916c <fwp_hof0.constprop.0+0xccc>  // b.pmore
    9300:	d280001c 	mov	x28, #0x0                   	// #0
    9304:	8b170f65 	add	x5, x27, x23, lsl #3
    9308:	aa1b03e1 	mov	x1, x27
    930c:	aa1503e0 	mov	x0, x21
    9310:	f8408422 	ldr	x2, [x1], #8
    9314:	f9000402 	str	x2, [x0, #8]
    9318:	aa0003e2 	mov	x2, x0
    931c:	f9400800 	ldr	x0, [x0, #16]
    9320:	eb05003f 	cmp	x1, x5
    9324:	54ffff61 	b.ne	9310 <fwp_hof0.constprop.0+0xe70>  // b.any
    9328:	b94033e1 	ldr	w1, [sp, #48]
    932c:	f900085c 	str	x28, [x2, #16]
    9330:	aa1503fc 	mov	x28, x21
    9334:	aa0003f5 	mov	x21, x0
    9338:	34000041 	cbz	w1, 9340 <fwp_hof0.constprop.0+0xea0>
    933c:	d280001b 	mov	x27, #0x0                   	// #0
    9340:	91194293 	add	x19, x20, #0x650
    9344:	aa1b03e0 	mov	x0, x27
    9348:	97ffee66 	bl	4ce0 <fwp_mem_free>
    934c:	f949ee62 	ldr	x2, [x19, #5080]
    9350:	f949da61 	ldr	x1, [x19, #5040]
    9354:	d370bc42 	lsl	x2, x2, #16
    9358:	cb0102c3 	sub	x3, x22, x1
    935c:	eb02007f 	cmp	x3, x2
    9360:	54000402 	b.cs	93e0 <fwp_hof0.constprop.0+0xf40>  // b.hs, b.nlast
    9364:	d350fc60 	lsr	x0, x3, #16
    9368:	f949fe65 	ldr	x5, [x19, #5112]
    936c:	8b000800 	add	x0, x0, x0, lsl #2
    9370:	d37df000 	lsl	x0, x0, #3
    9374:	8b0000a2 	add	x2, x5, x0
    9378:	f9401057 	ldr	x23, [x2, #32]
    937c:	b4000cb7 	cbz	x23, 9510 <fwp_hof0.constprop.0+0x1070>
    9380:	386068a1 	ldrb	w1, [x5, x0]
    9384:	7100083f 	cmp	w1, #0x2
    9388:	540031e0 	b.eq	99c4 <fwp_hof0.constprop.0+0x1524>  // b.none
    938c:	7100043f 	cmp	w1, #0x1
    9390:	54000c01 	b.ne	9510 <fwp_hof0.constprop.0+0x1070>  // b.any
    9394:	29430844 	ldp	w4, w2, [x2, #24]
    9398:	92403c61 	and	x1, x3, #0xffff
    939c:	9b047c21 	mul	x1, x1, x4
    93a0:	d360fc21 	lsr	x1, x1, #32
    93a4:	eb02003f 	cmp	x1, x2
    93a8:	54000b42 	b.cs	9510 <fwp_hof0.constprop.0+0x1070>  // b.hs, b.nlast
    93ac:	8b0102f7 	add	x23, x23, x1
    93b0:	394002e1 	ldrb	w1, [x23]
    93b4:	34000ae1 	cbz	w1, 9510 <fwp_hof0.constprop.0+0x1070>
    93b8:	7100043f 	cmp	w1, #0x1
    93bc:	540006a0 	b.eq	9490 <fwp_hof0.constprop.0+0xff0>  // b.none
    93c0:	7103fc3f 	cmp	w1, #0xff
    93c4:	54005340 	b.eq	9e2c <fwp_hof0.constprop.0+0x198c>  // b.none
    93c8:	91194280 	add	x0, x20, #0x650
    93cc:	51000421 	sub	w1, w1, #0x1
    93d0:	390002e1 	strb	w1, [x23]
    93d4:	f949ec02 	ldr	x2, [x0, #5080]
    93d8:	f949d801 	ldr	x1, [x0, #5040]
    93dc:	d370bc42 	lsl	x2, x2, #16
    93e0:	cb0102a1 	sub	x1, x21, x1
    93e4:	eb01005f 	cmp	x2, x1
    93e8:	540003c9 	b.ls	9460 <fwp_hof0.constprop.0+0xfc0>  // b.plast
    93ec:	91194296 	add	x22, x20, #0x650
    93f0:	d350fc20 	lsr	x0, x1, #16
    93f4:	f949fec3 	ldr	x3, [x22, #5112]
    93f8:	8b000800 	add	x0, x0, x0, lsl #2
    93fc:	d37df000 	lsl	x0, x0, #3
    9400:	8b000062 	add	x2, x3, x0
    9404:	f9401053 	ldr	x19, [x2, #32]
    9408:	b40002d3 	cbz	x19, 9460 <fwp_hof0.constprop.0+0xfc0>
    940c:	38606860 	ldrb	w0, [x3, x0]
    9410:	7100081f 	cmp	w0, #0x2
    9414:	54003200 	b.eq	9a54 <fwp_hof0.constprop.0+0x15b4>  // b.none
    9418:	7100041f 	cmp	w0, #0x1
    941c:	54000221 	b.ne	9460 <fwp_hof0.constprop.0+0xfc0>  // b.any
    9420:	29430044 	ldp	w4, w0, [x2, #24]
    9424:	92403c21 	and	x1, x1, #0xffff
    9428:	9b047c21 	mul	x1, x1, x4
    942c:	d360fc21 	lsr	x1, x1, #32
    9430:	eb00003f 	cmp	x1, x0
    9434:	54000162 	b.cs	9460 <fwp_hof0.constprop.0+0xfc0>  // b.hs, b.nlast
    9438:	8b010273 	add	x19, x19, x1
    943c:	39400260 	ldrb	w0, [x19]
    9440:	34000100 	cbz	w0, 9460 <fwp_hof0.constprop.0+0xfc0>
    9444:	7100041f 	cmp	w0, #0x1
    9448:	540038c0 	b.eq	9b60 <fwp_hof0.constprop.0+0x16c0>  // b.none
    944c:	7103fc1f 	cmp	w0, #0xff
    9450:	54004b20 	b.eq	9db4 <fwp_hof0.constprop.0+0x1914>  // b.none
    9454:	51000400 	sub	w0, w0, #0x1
    9458:	39000260 	strb	w0, [x19]
    945c:	d503201f 	nop
    9460:	f94007e0 	ldr	x0, [sp, #8]
    9464:	b4001a60 	cbz	x0, 97b0 <fwp_hof0.constprop.0+0x1310>
    9468:	f94007e0 	ldr	x0, [sp, #8]
    946c:	f100041a 	subs	x26, x0, #0x1
    9470:	f90007fa 	str	x26, [sp, #8]
    9474:	54005da6 	b.vs	a028 <fwp_hof0.constprop.0+0x1b88>
    9478:	91194280 	add	x0, x20, #0x650
    947c:	aa1c03f5 	mov	x21, x28
    9480:	f949ec03 	ldr	x3, [x0, #5080]
    9484:	f949d801 	ldr	x1, [x0, #5040]
    9488:	d370bc63 	lsl	x3, x3, #16
    948c:	17fffc51 	b	85d0 <fwp_hof0.constprop.0+0x130>
    9490:	f94002c3 	ldr	x3, [x22]
    9494:	aa1603e0 	mov	x0, x22
    9498:	f949ee62 	ldr	x2, [x19, #5080]
    949c:	f949da61 	ldr	x1, [x19, #5040]
    94a0:	d370bc42 	lsl	x2, x2, #16
    94a4:	cb0102c7 	sub	x7, x22, x1
    94a8:	b7f82dc3 	tbnz	x3, #63, 9a60 <fwp_hof0.constprop.0+0x15c0>
    94ac:	eb07005f 	cmp	x2, x7
    94b0:	54fff989 	b.ls	93e0 <fwp_hof0.constprop.0+0xf40>  // b.plast
    94b4:	d350fce3 	lsr	x3, x7, #16
    94b8:	8b030863 	add	x3, x3, x3, lsl #2
    94bc:	d37df063 	lsl	x3, x3, #3
    94c0:	8b0300a6 	add	x6, x5, x3
    94c4:	f94010c4 	ldr	x4, [x6, #32]
    94c8:	b4fff8c4 	cbz	x4, 93e0 <fwp_hof0.constprop.0+0xf40>
    94cc:	386368a3 	ldrb	w3, [x5, x3]
    94d0:	7100087f 	cmp	w3, #0x2
    94d4:	54003960 	b.eq	9c00 <fwp_hof0.constprop.0+0x1760>  // b.none
    94d8:	7100047f 	cmp	w3, #0x1
    94dc:	54fff821 	b.ne	93e0 <fwp_hof0.constprop.0+0xf40>  // b.any
    94e0:	29430cc5 	ldp	w5, w3, [x6, #24]
    94e4:	92403ce0 	and	x0, x7, #0xffff
    94e8:	9b057c00 	mul	x0, x0, x5
    94ec:	d360fc00 	lsr	x0, x0, #32
    94f0:	eb03001f 	cmp	x0, x3
    94f4:	54fff762 	b.cs	93e0 <fwp_hof0.constprop.0+0xf40>  // b.hs, b.nlast
    94f8:	8b000084 	add	x4, x4, x0
    94fc:	39400080 	ldrb	w0, [x4]
    9500:	7100041f 	cmp	w0, #0x1
    9504:	54fff6e1 	b.ne	93e0 <fwp_hof0.constprop.0+0xf40>  // b.any
    9508:	aa1603e0 	mov	x0, x22
    950c:	97ffedf5 	bl	4ce0 <fwp_mem_free>
    9510:	91194280 	add	x0, x20, #0x650
    9514:	f949ec02 	ldr	x2, [x0, #5080]
    9518:	f949d801 	ldr	x1, [x0, #5040]
    951c:	d370bc42 	lsl	x2, x2, #16
    9520:	17ffffb0 	b	93e0 <fwp_hof0.constprop.0+0xf40>
    9524:	aa1803e0 	mov	x0, x24
    9528:	97ffed4e 	bl	4a60 <fwp_rc_forget_slot>
    952c:	17ffff6c 	b	92dc <fwp_hof0.constprop.0+0xe3c>
    9530:	72003c3f 	tst	w1, #0xffff
    9534:	54ffed61 	b.ne	92e0 <fwp_hof0.constprop.0+0xe40>  // b.any
    9538:	17ffff66 	b	92d0 <fwp_hof0.constprop.0+0xe30>
    953c:	72003c1f 	tst	w0, #0xffff
    9540:	54ffd840 	b.eq	9048 <fwp_hof0.constprop.0+0xba8>  // b.none
    9544:	b4001235 	cbz	x21, 9788 <fwp_hof0.constprop.0+0x12e8>
    9548:	aa1503f3 	mov	x19, x21
    954c:	d2800017 	mov	x23, #0x0                   	// #0
    9550:	f9400a73 	ldr	x19, [x19, #16]
    9554:	aa1703e0 	mov	x0, x23
    9558:	910006f7 	add	x23, x23, #0x1
    955c:	b5ffffb3 	cbnz	x19, 9550 <fwp_hof0.constprop.0+0x10b0>
    9560:	f9001be4 	str	x4, [sp, #48]
    9564:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9568:	eb0102ff 	cmp	x23, x1
    956c:	540051e8 	b.hi	9fa8 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    9570:	91000800 	add	x0, x0, #0x2
    9574:	52800041 	mov	w1, #0x2                   	// #2
    9578:	d37df000 	lsl	x0, x0, #3
    957c:	97ffeef9 	bl	5160 <fwp_heap_alloc>
    9580:	f9401be4 	ldr	x4, [sp, #48]
    9584:	aa0003fb 	mov	x27, x0
    9588:	aa1503e1 	mov	x1, x21
    958c:	eb0402ff 	cmp	x23, x4
    9590:	9a8492e4 	csel	x4, x23, x4, ls	// ls = plast
    9594:	d503201f 	nop
    9598:	f9400420 	ldr	x0, [x1, #8]
    959c:	f8337b60 	str	x0, [x27, x19, lsl #3]
    95a0:	91000673 	add	x19, x19, #0x1
    95a4:	f9400821 	ldr	x1, [x1, #16]
    95a8:	b5ffff81 	cbnz	x1, 9598 <fwp_hof0.constprop.0+0x10f8>
    95ac:	b4000f64 	cbz	x4, 9798 <fwp_hof0.constprop.0+0x12f8>
    95b0:	f9400385 	ldr	x5, [x28]
    95b4:	b90033ff 	str	wzr, [sp, #48]
    95b8:	17fffeac 	b	9068 <fwp_hof0.constprop.0+0xbc8>
    95bc:	d53bd040 	mrs	x0, tpidr_el0
    95c0:	91400000 	add	x0, x0, #0x0, lsl #12
    95c4:	91004000 	add	x0, x0, #0x10
    95c8:	f9400000 	ldr	x0, [x0]
    95cc:	b40028c0 	cbz	x0, 9ae4 <fwp_hof0.constprop.0+0x1644>
    95d0:	f94017e1 	ldr	x1, [sp, #40]
    95d4:	97ffe8a4 	bl	3864 <fwp_closure_drop_push>
    95d8:	b5ff8a75 	cbnz	x21, 8724 <fwp_hof0.constprop.0+0x284>
    95dc:	f00000a0 	adrp	x0, 20000 <__data_start>
    95e0:	91014013 	add	x19, x0, #0x50
    95e4:	d2800016 	mov	x22, #0x0                   	// #0
    95e8:	b943e660 	ldr	w0, [x19, #996]
    95ec:	35ff8b80 	cbnz	w0, 875c <fwp_hof0.constprop.0+0x2bc>
    95f0:	b0ffffe0 	adrp	x0, 6000 <fwp_drop0+0xc0>
    95f4:	910c4000 	add	x0, x0, #0x310
    95f8:	94000f52 	bl	d340 <atexit>
    95fc:	35ffc820 	cbnz	w0, 8f00 <fwp_hof0.constprop.0+0xa60>
    9600:	52800020 	mov	w0, #0x1                   	// #1
    9604:	b903e660 	str	w0, [x19, #996]
    9608:	f00000a0 	adrp	x0, 20000 <__data_start>
    960c:	91014000 	add	x0, x0, #0x50
    9610:	f9406c13 	ldr	x19, [x0, #216]
    9614:	f940c017 	ldr	x23, [x0, #384]
    9618:	eb1302ff 	cmp	x23, x19
    961c:	54ff8acb 	b.lt	8774 <fwp_hof0.constprop.0+0x2d4>  // b.tstop
    9620:	eb1302ff 	cmp	x23, x19
    9624:	54ff8c40 	b.eq	87ac <fwp_hof0.constprop.0+0x30c>  // b.none
    9628:	f00000a0 	adrp	x0, 20000 <__data_start>
    962c:	91014000 	add	x0, x0, #0x50
    9630:	8b1706fb 	add	x27, x23, x23, lsl #1
    9634:	f940441c 	ldr	x28, [x0, #136]
    9638:	8b1b0afb 	add	x27, x23, x27, lsl #2
    963c:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9640:	911dc000 	add	x0, x0, #0x770
    9644:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    9648:	f900337f 	str	xzr, [x27, #96]
    964c:	97ffe4f9 	bl	2a30 <getenv@plt>
    9650:	b5ff90a0 	cbnz	x0, 8864 <fwp_hof0.constprop.0+0x3c4>
    9654:	f00000a0 	adrp	x0, 20000 <__data_start>
    9658:	91014000 	add	x0, x0, #0x50
    965c:	f9409c01 	ldr	x1, [x0, #312]
    9660:	b4ff90c1 	cbz	x1, 8878 <fwp_hof0.constprop.0+0x3d8>
    9664:	ad480402 	ldp	q2, q1, [x0, #256]
    9668:	91040001 	add	x1, x0, #0x100
    966c:	4f000400 	movi	v0.4s, #0x0
    9670:	f9009c1f 	str	xzr, [x0, #312]
    9674:	ad010762 	stp	q2, q1, [x27, #32]
    9678:	a9520002 	ldp	x2, x0, [x0, #288]
    967c:	f9000f60 	str	x0, [x27, #24]
    9680:	f9401820 	ldr	x0, [x1, #48]
    9684:	f9002362 	str	x2, [x27, #64]
    9688:	f9002760 	str	x0, [x27, #72]
    968c:	ad000020 	stp	q0, q0, [x1]
    9690:	3d800820 	str	q0, [x1, #32]
    9694:	f900183f 	str	xzr, [x1, #48]
    9698:	17fffc78 	b	8878 <fwp_hof0.constprop.0+0x3d8>
    969c:	72003c1f 	tst	w0, #0xffff
    96a0:	54ffbdc0 	b.eq	8e58 <fwp_hof0.constprop.0+0x9b8>  // b.none
    96a4:	d503201f 	nop
    96a8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    96ac:	eb0002ff 	cmp	x23, x0
    96b0:	54004ae8 	b.hi	a00c <fwp_hof0.constprop.0+0x1b6c>  // b.pmore
    96b4:	910006e0 	add	x0, x23, #0x1
    96b8:	52800021 	mov	w1, #0x1                   	// #1
    96bc:	d37df000 	lsl	x0, x0, #3
    96c0:	97ffeea8 	bl	5160 <fwp_heap_alloc>
    96c4:	91194282 	add	x2, x20, #0x650
    96c8:	f9000017 	str	x23, [x0]
    96cc:	aa0003fc 	mov	x28, x0
    96d0:	aa0003f6 	mov	x22, x0
    96d4:	f949d841 	ldr	x1, [x2, #5040]
    96d8:	f949ec40 	ldr	x0, [x2, #5080]
    96dc:	cb010381 	sub	x1, x28, x1
    96e0:	eb00403f 	cmp	x1, x0, lsl #16
    96e4:	54000322 	b.cs	9748 <fwp_hof0.constprop.0+0x12a8>  // b.hs, b.nlast
    96e8:	d350fc20 	lsr	x0, x1, #16
    96ec:	f949fc44 	ldr	x4, [x2, #5112]
    96f0:	8b000800 	add	x0, x0, x0, lsl #2
    96f4:	d37df002 	lsl	x2, x0, #3
    96f8:	8b020083 	add	x3, x4, x2
    96fc:	f9401078 	ldr	x24, [x3, #32]
    9700:	b4000258 	cbz	x24, 9748 <fwp_hof0.constprop.0+0x12a8>
    9704:	38626882 	ldrb	w2, [x4, x2]
    9708:	7100085f 	cmp	w2, #0x2
    970c:	54002860 	b.eq	9c18 <fwp_hof0.constprop.0+0x1778>  // b.none
    9710:	7100045f 	cmp	w2, #0x1
    9714:	540001a1 	b.ne	9748 <fwp_hof0.constprop.0+0x12a8>  // b.any
    9718:	29430864 	ldp	w4, w2, [x3, #24]
    971c:	92403c21 	and	x1, x1, #0xffff
    9720:	9b047c21 	mul	x1, x1, x4
    9724:	d360fc21 	lsr	x1, x1, #32
    9728:	eb02003f 	cmp	x1, x2
    972c:	540000e2 	b.cs	9748 <fwp_hof0.constprop.0+0x12a8>  // b.hs, b.nlast
    9730:	8b010318 	add	x24, x24, x1
    9734:	39400301 	ldrb	w1, [x24]
    9738:	7103fc3f 	cmp	w1, #0xff
    973c:	54002760 	b.eq	9c28 <fwp_hof0.constprop.0+0x1788>  // b.none
    9740:	52800021 	mov	w1, #0x1                   	// #1
    9744:	39000301 	strb	w1, [x24]
    9748:	aa1303e0 	mov	x0, x19
    974c:	17fffdc9 	b	8e70 <fwp_hof0.constprop.0+0x9d0>
    9750:	52800041 	mov	w1, #0x2                   	// #2
    9754:	d2800100 	mov	x0, #0x8                   	// #8
    9758:	97ffee82 	bl	5160 <fwp_heap_alloc>
    975c:	aa0003f7 	mov	x23, x0
    9760:	91194280 	add	x0, x20, #0x650
    9764:	aa1703fb 	mov	x27, x23
    9768:	f90002ff 	str	xzr, [x23]
    976c:	f949d801 	ldr	x1, [x0, #5040]
    9770:	f949ec00 	ldr	x0, [x0, #5080]
    9774:	cb0102e1 	sub	x1, x23, x1
    9778:	eb00403f 	cmp	x1, x0, lsl #16
    977c:	540011a2 	b.cs	99b0 <fwp_hof0.constprop.0+0x1510>  // b.hs, b.nlast
    9780:	d2800016 	mov	x22, #0x0                   	// #0
    9784:	17fffc83 	b	8990 <fwp_hof0.constprop.0+0x4f0>
    9788:	52800041 	mov	w1, #0x2                   	// #2
    978c:	d2800100 	mov	x0, #0x8                   	// #8
    9790:	97ffee74 	bl	5160 <fwp_heap_alloc>
    9794:	aa0003fb 	mov	x27, x0
    9798:	d280001c 	mov	x28, #0x0                   	// #0
    979c:	17fffee9 	b	9340 <fwp_hof0.constprop.0+0xea0>
    97a0:	f9001fe0 	str	x0, [sp, #56]
    97a4:	97ffecaf 	bl	4a60 <fwp_rc_forget_slot>
    97a8:	f9401fe0 	ldr	x0, [sp, #56]
    97ac:	17fffe82 	b	91b4 <fwp_hof0.constprop.0+0xd14>
    97b0:	f9400be0 	ldr	x0, [sp, #16]
    97b4:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe888>
    97b8:	910ac042 	add	x2, x2, #0x2b0
    97bc:	aa1c03e1 	mov	x1, x28
    97c0:	91014042 	add	x2, x2, #0x50
    97c4:	52800023 	mov	w3, #0x1                   	// #1
    97c8:	a9097fff 	stp	xzr, xzr, [sp, #144]
    97cc:	f90053ff 	str	xzr, [sp, #160]
    97d0:	97fff738 	bl	74b0 <fwp_write>
    97d4:	a9495bf5 	ldp	x21, x22, [sp, #144]
    97d8:	90000020 	adrp	x0, d000 <__modti3+0x30>
    97dc:	910ec000 	add	x0, x0, #0x3b0
    97e0:	f10002bf 	cmp	x21, #0x0
    97e4:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    97e8:	b1002adf 	cmn	x22, #0xa
    97ec:	54004168 	b.hi	a018 <fwp_hof0.constprop.0+0x1b78>  // b.pmore
    97f0:	910026c0 	add	x0, x22, #0x9
    97f4:	52800021 	mov	w1, #0x1                   	// #1
    97f8:	97ffee5a 	bl	5160 <fwp_heap_alloc>
    97fc:	aa0003f7 	mov	x23, x0
    9800:	aa0003f3 	mov	x19, x0
    9804:	aa1603e2 	mov	x2, x22
    9808:	aa1503e1 	mov	x1, x21
    980c:	f80086f6 	str	x22, [x23], #8
    9810:	8b160276 	add	x22, x19, x22
    9814:	aa1703e0 	mov	x0, x23
    9818:	97ffe3b6 	bl	26f0 <memcpy@plt>
    981c:	390022df 	strb	wzr, [x22, #8]
    9820:	f9404be0 	ldr	x0, [sp, #144]
    9824:	97ffe44f 	bl	2960 <free@plt>
    9828:	91194281 	add	x1, x20, #0x650
    982c:	f949d822 	ldr	x2, [x1, #5040]
    9830:	f949ec20 	ldr	x0, [x1, #5080]
    9834:	cb020262 	sub	x2, x19, x2
    9838:	eb00405f 	cmp	x2, x0, lsl #16
    983c:	54000322 	b.cs	98a0 <fwp_hof0.constprop.0+0x1400>  // b.hs, b.nlast
    9840:	d350fc40 	lsr	x0, x2, #16
    9844:	f949fc23 	ldr	x3, [x1, #5112]
    9848:	8b000800 	add	x0, x0, x0, lsl #2
    984c:	d37df001 	lsl	x1, x0, #3
    9850:	8b010060 	add	x0, x3, x1
    9854:	f9401015 	ldr	x21, [x0, #32]
    9858:	b4000255 	cbz	x21, 98a0 <fwp_hof0.constprop.0+0x1400>
    985c:	38616861 	ldrb	w1, [x3, x1]
    9860:	7100083f 	cmp	w1, #0x2
    9864:	54002d40 	b.eq	9e0c <fwp_hof0.constprop.0+0x196c>  // b.none
    9868:	7100043f 	cmp	w1, #0x1
    986c:	540001a1 	b.ne	98a0 <fwp_hof0.constprop.0+0x1400>  // b.any
    9870:	29430003 	ldp	w3, w0, [x0, #24]
    9874:	92403c41 	and	x1, x2, #0xffff
    9878:	9b037c21 	mul	x1, x1, x3
    987c:	d360fc21 	lsr	x1, x1, #32
    9880:	eb00003f 	cmp	x1, x0
    9884:	540000e2 	b.cs	98a0 <fwp_hof0.constprop.0+0x1400>  // b.hs, b.nlast
    9888:	8b0102b5 	add	x21, x21, x1
    988c:	394002a0 	ldrb	w0, [x21]
    9890:	7103fc1f 	cmp	w0, #0xff
    9894:	54002c60 	b.eq	9e20 <fwp_hof0.constprop.0+0x1980>  // b.none
    9898:	52800020 	mov	w0, #0x1                   	// #1
    989c:	390002a0 	strb	w0, [x21]
    98a0:	aa1c03e0 	mov	x0, x28
    98a4:	97fff1a7 	bl	5f40 <fwp_drop0>
    98a8:	f00000a0 	adrp	x0, 20000 <__data_start>
    98ac:	91014015 	add	x21, x0, #0x50
    98b0:	f9400262 	ldr	x2, [x19]
    98b4:	d2800021 	mov	x1, #0x1                   	// #1
    98b8:	f9404aa3 	ldr	x3, [x21, #144]
    98bc:	aa1703e0 	mov	x0, x23
    98c0:	97ffe438 	bl	29a0 <fwrite@plt>
    98c4:	f9404aa1 	ldr	x1, [x21, #144]
    98c8:	52800140 	mov	w0, #0xa                   	// #10
    98cc:	97ffe3bd 	bl	27c0 <fputc@plt>
    98d0:	91194281 	add	x1, x20, #0x650
    98d4:	f949d822 	ldr	x2, [x1, #5040]
    98d8:	f949ec20 	ldr	x0, [x1, #5080]
    98dc:	cb020262 	sub	x2, x19, x2
    98e0:	eb00405f 	cmp	x2, x0, lsl #16
    98e4:	54000382 	b.cs	9954 <fwp_hof0.constprop.0+0x14b4>  // b.hs, b.nlast
    98e8:	d350fc40 	lsr	x0, x2, #16
    98ec:	f949fc23 	ldr	x3, [x1, #5112]
    98f0:	8b000800 	add	x0, x0, x0, lsl #2
    98f4:	d37df001 	lsl	x1, x0, #3
    98f8:	8b010060 	add	x0, x3, x1
    98fc:	f9401015 	ldr	x21, [x0, #32]
    9900:	b40002b5 	cbz	x21, 9954 <fwp_hof0.constprop.0+0x14b4>
    9904:	38616861 	ldrb	w1, [x3, x1]
    9908:	7100083f 	cmp	w1, #0x2
    990c:	54002460 	b.eq	9d98 <fwp_hof0.constprop.0+0x18f8>  // b.none
    9910:	7100043f 	cmp	w1, #0x1
    9914:	54000201 	b.ne	9954 <fwp_hof0.constprop.0+0x14b4>  // b.any
    9918:	29430003 	ldp	w3, w0, [x0, #24]
    991c:	92403c41 	and	x1, x2, #0xffff
    9920:	9b037c21 	mul	x1, x1, x3
    9924:	d360fc21 	lsr	x1, x1, #32
    9928:	eb00003f 	cmp	x1, x0
    992c:	54000142 	b.cs	9954 <fwp_hof0.constprop.0+0x14b4>  // b.hs, b.nlast
    9930:	8b0102b5 	add	x21, x21, x1
    9934:	394002a0 	ldrb	w0, [x21]
    9938:	340000e0 	cbz	w0, 9954 <fwp_hof0.constprop.0+0x14b4>
    993c:	7100041f 	cmp	w0, #0x1
    9940:	54001da0 	b.eq	9cf4 <fwp_hof0.constprop.0+0x1854>  // b.none
    9944:	7103fc1f 	cmp	w0, #0xff
    9948:	54002fe0 	b.eq	9f44 <fwp_hof0.constprop.0+0x1aa4>  // b.none
    994c:	51000400 	sub	w0, w0, #0x1
    9950:	390002a0 	strb	w0, [x21]
    9954:	f94027e0 	ldr	x0, [sp, #72]
    9958:	f9400800 	ldr	x0, [x0, #16]
    995c:	f90027e0 	str	x0, [sp, #72]
    9960:	b5ff5d80 	cbnz	x0, 8510 <fwp_hof0.constprop.0+0x70>
    9964:	a94f53f3 	ldp	x19, x20, [sp, #240]
    9968:	a9505bf5 	ldp	x21, x22, [sp, #256]
    996c:	a95163f7 	ldp	x23, x24, [sp, #272]
    9970:	a9526bf9 	ldp	x25, x26, [sp, #288]
    9974:	a95373fb 	ldp	x27, x28, [sp, #304]
    9978:	6d5427e8 	ldp	d8, d9, [sp, #320]
    997c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    9980:	f947f400 	ldr	x0, [x0, #4072]
    9984:	f9406fe2 	ldr	x2, [sp, #216]
    9988:	f9400001 	ldr	x1, [x0]
    998c:	eb010042 	subs	x2, x2, x1
    9990:	d2800001 	mov	x1, #0x0                   	// #0
    9994:	54003101 	b.ne	9fb4 <fwp_hof0.constprop.0+0x1b14>  // b.any
    9998:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    999c:	d2800000 	mov	x0, #0x0                   	// #0
    99a0:	910543ff 	add	sp, sp, #0x150
    99a4:	d65f03c0 	ret
    99a8:	b5ff8296 	cbnz	x22, 89f8 <fwp_hof0.constprop.0+0x558>
    99ac:	d503201f 	nop
    99b0:	d280001c 	mov	x28, #0x0                   	// #0
    99b4:	17fffc38 	b	8a94 <fwp_hof0.constprop.0+0x5f4>
    99b8:	72003c3f 	tst	w1, #0xffff
    99bc:	54ff8b61 	b.ne	8b28 <fwp_hof0.constprop.0+0x688>  // b.any
    99c0:	17fffc52 	b	8b08 <fwp_hof0.constprop.0+0x668>
    99c4:	72003c7f 	tst	w3, #0xffff
    99c8:	54ffda41 	b.ne	9510 <fwp_hof0.constprop.0+0x1070>  // b.any
    99cc:	17fffe79 	b	93b0 <fwp_hof0.constprop.0+0xf10>
    99d0:	f940077b 	ldr	x27, [x27, #8]
    99d4:	eb02007f 	cmp	x3, x2
    99d8:	54000369 	b.ls	9a44 <fwp_hof0.constprop.0+0x15a4>  // b.plast
    99dc:	d350fc45 	lsr	x5, x2, #16
    99e0:	8b0508a5 	add	x5, x5, x5, lsl #2
    99e4:	d37df0a5 	lsl	x5, x5, #3
    99e8:	8b050087 	add	x7, x4, x5
    99ec:	f94010e6 	ldr	x6, [x7, #32]
    99f0:	b40002a6 	cbz	x6, 9a44 <fwp_hof0.constprop.0+0x15a4>
    99f4:	38656884 	ldrb	w4, [x4, x5]
    99f8:	7100089f 	cmp	w4, #0x2
    99fc:	54001760 	b.eq	9ce8 <fwp_hof0.constprop.0+0x1848>  // b.none
    9a00:	7100049f 	cmp	w4, #0x1
    9a04:	54000201 	b.ne	9a44 <fwp_hof0.constprop.0+0x15a4>  // b.any
    9a08:	294310e5 	ldp	w5, w4, [x7, #24]
    9a0c:	92403c42 	and	x2, x2, #0xffff
    9a10:	9b057c42 	mul	x2, x2, x5
    9a14:	d360fc42 	lsr	x2, x2, #32
    9a18:	eb04005f 	cmp	x2, x4
    9a1c:	54000142 	b.cs	9a44 <fwp_hof0.constprop.0+0x15a4>  // b.hs, b.nlast
    9a20:	8b0200c6 	add	x6, x6, x2
    9a24:	394000c2 	ldrb	w2, [x6]
    9a28:	7100045f 	cmp	w2, #0x1
    9a2c:	540000c1 	b.ne	9a44 <fwp_hof0.constprop.0+0x15a4>  // b.any
    9a30:	97ffecac 	bl	4ce0 <fwp_mem_free>
    9a34:	91194280 	add	x0, x20, #0x650
    9a38:	f949ec03 	ldr	x3, [x0, #5080]
    9a3c:	f949d801 	ldr	x1, [x0, #5040]
    9a40:	d370bc63 	lsl	x3, x3, #16
    9a44:	cb010361 	sub	x1, x27, x1
    9a48:	eb03003f 	cmp	x1, x3
    9a4c:	54ff8383 	b.cc	8abc <fwp_hof0.constprop.0+0x61c>  // b.lo, b.ul, b.last
    9a50:	17fffc36 	b	8b28 <fwp_hof0.constprop.0+0x688>
    9a54:	72003c3f 	tst	w1, #0xffff
    9a58:	54ffd041 	b.ne	9460 <fwp_hof0.constprop.0+0xfc0>  // b.any
    9a5c:	17fffe78 	b	943c <fwp_hof0.constprop.0+0xf9c>
    9a60:	f94006d6 	ldr	x22, [x22, #8]
    9a64:	eb07005f 	cmp	x2, x7
    9a68:	54000369 	b.ls	9ad4 <fwp_hof0.constprop.0+0x1634>  // b.plast
    9a6c:	d350fce3 	lsr	x3, x7, #16
    9a70:	8b030863 	add	x3, x3, x3, lsl #2
    9a74:	d37df063 	lsl	x3, x3, #3
    9a78:	8b0300a6 	add	x6, x5, x3
    9a7c:	f94010c4 	ldr	x4, [x6, #32]
    9a80:	b40002a4 	cbz	x4, 9ad4 <fwp_hof0.constprop.0+0x1634>
    9a84:	386368a3 	ldrb	w3, [x5, x3]
    9a88:	7100087f 	cmp	w3, #0x2
    9a8c:	54001420 	b.eq	9d10 <fwp_hof0.constprop.0+0x1870>  // b.none
    9a90:	7100047f 	cmp	w3, #0x1
    9a94:	54000201 	b.ne	9ad4 <fwp_hof0.constprop.0+0x1634>  // b.any
    9a98:	294314c8 	ldp	w8, w5, [x6, #24]
    9a9c:	92403ce3 	and	x3, x7, #0xffff
    9aa0:	9b087c63 	mul	x3, x3, x8
    9aa4:	d360fc63 	lsr	x3, x3, #32
    9aa8:	eb05007f 	cmp	x3, x5
    9aac:	54000142 	b.cs	9ad4 <fwp_hof0.constprop.0+0x1634>  // b.hs, b.nlast
    9ab0:	8b030084 	add	x4, x4, x3
    9ab4:	39400083 	ldrb	w3, [x4]
    9ab8:	7100047f 	cmp	w3, #0x1
    9abc:	540000c1 	b.ne	9ad4 <fwp_hof0.constprop.0+0x1634>  // b.any
    9ac0:	97ffec88 	bl	4ce0 <fwp_mem_free>
    9ac4:	91194280 	add	x0, x20, #0x650
    9ac8:	f949ec02 	ldr	x2, [x0, #5080]
    9acc:	f949d801 	ldr	x1, [x0, #5040]
    9ad0:	d370bc42 	lsl	x2, x2, #16
    9ad4:	cb0102c3 	sub	x3, x22, x1
    9ad8:	eb02007f 	cmp	x3, x2
    9adc:	54ffc443 	b.cc	9364 <fwp_hof0.constprop.0+0xec4>  // b.lo, b.ul, b.last
    9ae0:	17fffe40 	b	93e0 <fwp_hof0.constprop.0+0xf40>
    9ae4:	f94017e0 	ldr	x0, [sp, #40]
    9ae8:	97ffe7ce 	bl	3a20 <fwp_closure_drop.part.0>
    9aec:	17fffb0d 	b	8720 <fwp_hof0.constprop.0+0x280>
    9af0:	72003c3f 	tst	w1, #0xffff
    9af4:	54ff5ec1 	b.ne	86cc <fwp_hof0.constprop.0+0x22c>  // b.any
    9af8:	aa1303e0 	mov	x0, x19
    9afc:	17fffada 	b	8664 <fwp_hof0.constprop.0+0x1c4>
    9b00:	72003c3f 	tst	w1, #0xffff
    9b04:	54ff60e1 	b.ne	8720 <fwp_hof0.constprop.0+0x280>  // b.any
    9b08:	17fffafd 	b	86fc <fwp_hof0.constprop.0+0x25c>
    9b0c:	72003c3f 	tst	w1, #0xffff
    9b10:	54ff7721 	b.ne	89f4 <fwp_hof0.constprop.0+0x554>  // b.any
    9b14:	39400380 	ldrb	w0, [x28]
    9b18:	7103fc1f 	cmp	w0, #0xff
    9b1c:	54ff7681 	b.ne	89ec <fwp_hof0.constprop.0+0x54c>  // b.any
    9b20:	aa1c03e0 	mov	x0, x28
    9b24:	97ffebcf 	bl	4a60 <fwp_rc_forget_slot>
    9b28:	17fffbb1 	b	89ec <fwp_hof0.constprop.0+0x54c>
    9b2c:	aa1803f6 	mov	x22, x24
    9b30:	17fffc34 	b	8c00 <fwp_hof0.constprop.0+0x760>
    9b34:	72003c3f 	tst	w1, #0xffff
    9b38:	54ff9461 	b.ne	8dc4 <fwp_hof0.constprop.0+0x924>  // b.any
    9b3c:	394002c0 	ldrb	w0, [x22]
    9b40:	7103fc1f 	cmp	w0, #0xff
    9b44:	54ff93c1 	b.ne	8dbc <fwp_hof0.constprop.0+0x91c>  // b.any
    9b48:	aa1603e0 	mov	x0, x22
    9b4c:	97ffebc5 	bl	4a60 <fwp_rc_forget_slot>
    9b50:	17fffc9b 	b	8dbc <fwp_hof0.constprop.0+0x91c>
    9b54:	72003c5f 	tst	w2, #0xffff
    9b58:	54ff7e81 	b.ne	8b28 <fwp_hof0.constprop.0+0x688>  // b.any
    9b5c:	17fffd10 	b	8f9c <fwp_hof0.constprop.0+0xafc>
    9b60:	91194280 	add	x0, x20, #0x650
    9b64:	f9400ab3 	ldr	x19, [x21, #16]
    9b68:	f949ec04 	ldr	x4, [x0, #5080]
    9b6c:	f949d801 	ldr	x1, [x0, #5040]
    9b70:	d370bc84 	lsl	x4, x4, #16
    9b74:	cb0102a0 	sub	x0, x21, x1
    9b78:	eb04001f 	cmp	x0, x4
    9b7c:	54000382 	b.cs	9bec <fwp_hof0.constprop.0+0x174c>  // b.hs, b.nlast
    9b80:	d350fc02 	lsr	x2, x0, #16
    9b84:	8b020842 	add	x2, x2, x2, lsl #2
    9b88:	d37df042 	lsl	x2, x2, #3
    9b8c:	8b020066 	add	x6, x3, x2
    9b90:	f94010c5 	ldr	x5, [x6, #32]
    9b94:	b40002c5 	cbz	x5, 9bec <fwp_hof0.constprop.0+0x174c>
    9b98:	38626862 	ldrb	w2, [x3, x2]
    9b9c:	7100085f 	cmp	w2, #0x2
    9ba0:	54000be0 	b.eq	9d1c <fwp_hof0.constprop.0+0x187c>  // b.none
    9ba4:	7100045f 	cmp	w2, #0x1
    9ba8:	54000221 	b.ne	9bec <fwp_hof0.constprop.0+0x174c>  // b.any
    9bac:	294308c3 	ldp	w3, w2, [x6, #24]
    9bb0:	92403c00 	and	x0, x0, #0xffff
    9bb4:	9b037c00 	mul	x0, x0, x3
    9bb8:	d360fc00 	lsr	x0, x0, #32
    9bbc:	eb02001f 	cmp	x0, x2
    9bc0:	54000162 	b.cs	9bec <fwp_hof0.constprop.0+0x174c>  // b.hs, b.nlast
    9bc4:	8b0000a5 	add	x5, x5, x0
    9bc8:	394000a0 	ldrb	w0, [x5]
    9bcc:	7100041f 	cmp	w0, #0x1
    9bd0:	540000e1 	b.ne	9bec <fwp_hof0.constprop.0+0x174c>  // b.any
    9bd4:	aa1503e0 	mov	x0, x21
    9bd8:	97ffec42 	bl	4ce0 <fwp_mem_free>
    9bdc:	91194280 	add	x0, x20, #0x650
    9be0:	f949ec04 	ldr	x4, [x0, #5080]
    9be4:	f949d801 	ldr	x1, [x0, #5040]
    9be8:	d370bc84 	lsl	x4, x4, #16
    9bec:	cb010261 	sub	x1, x19, x1
    9bf0:	eb01009f 	cmp	x4, x1
    9bf4:	54ffc369 	b.ls	9460 <fwp_hof0.constprop.0+0xfc0>  // b.plast
    9bf8:	aa1303f5 	mov	x21, x19
    9bfc:	17fffdfd 	b	93f0 <fwp_hof0.constprop.0+0xf50>
    9c00:	72003cff 	tst	w7, #0xffff
    9c04:	54ffbee1 	b.ne	93e0 <fwp_hof0.constprop.0+0xf40>  // b.any
    9c08:	17fffe3d 	b	94fc <fwp_hof0.constprop.0+0x105c>
    9c0c:	d2800019 	mov	x25, #0x0                   	// #0
    9c10:	52800020 	mov	w0, #0x1                   	// #1
    9c14:	17fffcb2 	b	8edc <fwp_hof0.constprop.0+0xa3c>
    9c18:	72003c3f 	tst	w1, #0xffff
    9c1c:	54ffd8c0 	b.eq	9734 <fwp_hof0.constprop.0+0x1294>  // b.none
    9c20:	aa1303e0 	mov	x0, x19
    9c24:	17fffc93 	b	8e70 <fwp_hof0.constprop.0+0x9d0>
    9c28:	aa1803e0 	mov	x0, x24
    9c2c:	97ffeb8d 	bl	4a60 <fwp_rc_forget_slot>
    9c30:	17fffec4 	b	9740 <fwp_hof0.constprop.0+0x12a0>
    9c34:	d10006e1 	sub	x1, x23, #0x1
    9c38:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9c3c:	eb00003f 	cmp	x1, x0
    9c40:	54001e08 	b.hi	a000 <fwp_hof0.constprop.0+0x1b60>  // b.pmore
    9c44:	f00002a3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fb90>
    9c48:	d2800000 	mov	x0, #0x0                   	// #0
    9c4c:	9111c061 	add	x1, x3, #0x470
    9c50:	14000005 	b	9c64 <fwp_hof0.constprop.0+0x17c4>
    9c54:	91000400 	add	x0, x0, #0x1
    9c58:	91006021 	add	x1, x1, #0x18
    9c5c:	f140041f 	cmp	x0, #0x1, lsl #12
    9c60:	54001500 	b.eq	9f00 <fwp_hof0.constprop.0+0x1a60>  // b.none
    9c64:	f9400022 	ldr	x2, [x1]
    9c68:	b5ffff62 	cbnz	x2, 9c54 <fwp_hof0.constprop.0+0x17b4>
    9c6c:	8b000402 	add	x2, x0, x0, lsl #1
    9c70:	9111c063 	add	x3, x3, #0x470
    9c74:	aa1703e0 	mov	x0, x23
    9c78:	d2800101 	mov	x1, #0x8                   	// #8
    9c7c:	8b020c73 	add	x19, x3, x2, lsl #3
    9c80:	a90327e8 	stp	x8, x9, [sp, #48]
    9c84:	97ffe2ff 	bl	2880 <calloc@plt>
    9c88:	a94327e8 	ldp	x8, x9, [sp, #48]
    9c8c:	aa0003f9 	mov	x25, x0
    9c90:	b4fffbe0 	cbz	x0, 9c0c <fwp_hof0.constprop.0+0x176c>
    9c94:	aa1303e0 	mov	x0, x19
    9c98:	d37df2e2 	lsl	x2, x23, #3
    9c9c:	aa1903e1 	mov	x1, x25
    9ca0:	52800063 	mov	w3, #0x3                   	// #3
    9ca4:	a90327e8 	stp	x8, x9, [sp, #48]
    9ca8:	97ffe4ba 	bl	2f90 <ad_raw_record>
    9cac:	a94327e8 	ldp	x8, x9, [sp, #48]
    9cb0:	17fffbe8 	b	8c50 <fwp_hof0.constprop.0+0x7b0>
    9cb4:	f9400385 	ldr	x5, [x28]
    9cb8:	b7ffd685 	tbnz	x5, #63, 9788 <fwp_hof0.constprop.0+0x12e8>
    9cbc:	91194281 	add	x1, x20, #0x650
    9cc0:	f949d820 	ldr	x0, [x1, #5040]
    9cc4:	f949ec21 	ldr	x1, [x1, #5080]
    9cc8:	cb0002c0 	sub	x0, x22, x0
    9ccc:	eb01401f 	cmp	x0, x1, lsl #16
    9cd0:	54ffd5c2 	b.cs	9788 <fwp_hof0.constprop.0+0x12e8>  // b.hs, b.nlast
    9cd4:	9240f8a4 	and	x4, x5, #0x7fffffffffffffff
    9cd8:	17fffcc8 	b	8ff8 <fwp_hof0.constprop.0+0xb58>
    9cdc:	d2800d01 	mov	x1, #0x68                  	// #104
    9ce0:	d280003b 	mov	x27, #0x1                   	// #1
    9ce4:	17fffac3 	b	87f0 <fwp_hof0.constprop.0+0x350>
    9ce8:	72003c5f 	tst	w2, #0xffff
    9cec:	54ffeac1 	b.ne	9a44 <fwp_hof0.constprop.0+0x15a4>  // b.any
    9cf0:	17ffff4d 	b	9a24 <fwp_hof0.constprop.0+0x1584>
    9cf4:	aa1303e0 	mov	x0, x19
    9cf8:	97ffef5f 	bl	5a74 <fwp_rc_free_arr>
    9cfc:	f94027e0 	ldr	x0, [sp, #72]
    9d00:	f9400800 	ldr	x0, [x0, #16]
    9d04:	f90027e0 	str	x0, [sp, #72]
    9d08:	b5ff4040 	cbnz	x0, 8510 <fwp_hof0.constprop.0+0x70>
    9d0c:	17ffff16 	b	9964 <fwp_hof0.constprop.0+0x14c4>
    9d10:	72003cff 	tst	w7, #0xffff
    9d14:	54ffee01 	b.ne	9ad4 <fwp_hof0.constprop.0+0x1634>  // b.any
    9d18:	17ffff67 	b	9ab4 <fwp_hof0.constprop.0+0x1614>
    9d1c:	72003c1f 	tst	w0, #0xffff
    9d20:	54fff661 	b.ne	9bec <fwp_hof0.constprop.0+0x174c>  // b.any
    9d24:	17ffffa9 	b	9bc8 <fwp_hof0.constprop.0+0x1728>
    9d28:	72003c9f 	tst	w4, #0xffff
    9d2c:	54ff44c1 	b.ne	85c4 <fwp_hof0.constprop.0+0x124>  // b.any
    9d30:	17fffa13 	b	857c <fwp_hof0.constprop.0+0xdc>
    9d34:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9d38:	91194281 	add	x1, x20, #0x650
    9d3c:	ca402400 	eor	x0, x0, x0, lsr #9
    9d40:	8b200c20 	add	x0, x1, w0, uxtb #3
    9d44:	f94a2400 	ldr	x0, [x0, #5192]
    9d48:	b5000080 	cbnz	x0, 9d58 <fwp_hof0.constprop.0+0x18b8>
    9d4c:	14000010 	b	9d8c <fwp_hof0.constprop.0+0x18ec>
    9d50:	f9400800 	ldr	x0, [x0, #16]
    9d54:	b40001c0 	cbz	x0, 9d8c <fwp_hof0.constprop.0+0x18ec>
    9d58:	f9400001 	ldr	x1, [x0]
    9d5c:	eb17003f 	cmp	x1, x23
    9d60:	54ffff81 	b.ne	9d50 <fwp_hof0.constprop.0+0x18b0>  // b.any
    9d64:	f9400401 	ldr	x1, [x0, #8]
    9d68:	d1000421 	sub	x1, x1, #0x1
    9d6c:	f9000401 	str	x1, [x0, #8]
    9d70:	f103f83f 	cmp	x1, #0xfe
    9d74:	54ff6da1 	b.ne	8b28 <fwp_hof0.constprop.0+0x688>  // b.any
    9d78:	aa1703e0 	mov	x0, x23
    9d7c:	97ffeb39 	bl	4a60 <fwp_rc_forget_slot>
    9d80:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9d84:	390002e0 	strb	w0, [x23]
    9d88:	17fffb68 	b	8b28 <fwp_hof0.constprop.0+0x688>
    9d8c:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9d90:	9120c000 	add	x0, x0, #0x830
    9d94:	97ffe69b 	bl	3800 <fwp_trap>
    9d98:	72003c5f 	tst	w2, #0xffff
    9d9c:	54ffdcc0 	b.eq	9934 <fwp_hof0.constprop.0+0x1494>  // b.none
    9da0:	f94027e0 	ldr	x0, [sp, #72]
    9da4:	f9400800 	ldr	x0, [x0, #16]
    9da8:	f90027e0 	str	x0, [sp, #72]
    9dac:	b5ff3b20 	cbnz	x0, 8510 <fwp_hof0.constprop.0+0x70>
    9db0:	17fffeed 	b	9964 <fwp_hof0.constprop.0+0x14c4>
    9db4:	ca534660 	eor	x0, x19, x19, lsr #17
    9db8:	91194281 	add	x1, x20, #0x650
    9dbc:	ca402400 	eor	x0, x0, x0, lsr #9
    9dc0:	8b200c20 	add	x0, x1, w0, uxtb #3
    9dc4:	f94a2400 	ldr	x0, [x0, #5192]
    9dc8:	b5000080 	cbnz	x0, 9dd8 <fwp_hof0.constprop.0+0x1938>
    9dcc:	17fffff0 	b	9d8c <fwp_hof0.constprop.0+0x18ec>
    9dd0:	f9400800 	ldr	x0, [x0, #16]
    9dd4:	b4fffdc0 	cbz	x0, 9d8c <fwp_hof0.constprop.0+0x18ec>
    9dd8:	f9400001 	ldr	x1, [x0]
    9ddc:	eb01027f 	cmp	x19, x1
    9de0:	54ffff81 	b.ne	9dd0 <fwp_hof0.constprop.0+0x1930>  // b.any
    9de4:	f9400401 	ldr	x1, [x0, #8]
    9de8:	d1000421 	sub	x1, x1, #0x1
    9dec:	f9000401 	str	x1, [x0, #8]
    9df0:	f103f83f 	cmp	x1, #0xfe
    9df4:	54ffb361 	b.ne	9460 <fwp_hof0.constprop.0+0xfc0>  // b.any
    9df8:	aa1303e0 	mov	x0, x19
    9dfc:	97ffeb19 	bl	4a60 <fwp_rc_forget_slot>
    9e00:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e04:	39000260 	strb	w0, [x19]
    9e08:	17fffd96 	b	9460 <fwp_hof0.constprop.0+0xfc0>
    9e0c:	72003c5f 	tst	w2, #0xffff
    9e10:	54ffd481 	b.ne	98a0 <fwp_hof0.constprop.0+0x1400>  // b.any
    9e14:	394002a0 	ldrb	w0, [x21]
    9e18:	7103fc1f 	cmp	w0, #0xff
    9e1c:	54ffd3e1 	b.ne	9898 <fwp_hof0.constprop.0+0x13f8>  // b.any
    9e20:	aa1503e0 	mov	x0, x21
    9e24:	97ffeb0f 	bl	4a60 <fwp_rc_forget_slot>
    9e28:	17fffe9c 	b	9898 <fwp_hof0.constprop.0+0x13f8>
    9e2c:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9e30:	91194281 	add	x1, x20, #0x650
    9e34:	ca402400 	eor	x0, x0, x0, lsr #9
    9e38:	8b200c20 	add	x0, x1, w0, uxtb #3
    9e3c:	f94a2401 	ldr	x1, [x0, #5192]
    9e40:	b5000081 	cbnz	x1, 9e50 <fwp_hof0.constprop.0+0x19b0>
    9e44:	17ffffd2 	b	9d8c <fwp_hof0.constprop.0+0x18ec>
    9e48:	f9400821 	ldr	x1, [x1, #16]
    9e4c:	b4fffa01 	cbz	x1, 9d8c <fwp_hof0.constprop.0+0x18ec>
    9e50:	f9400020 	ldr	x0, [x1]
    9e54:	eb17001f 	cmp	x0, x23
    9e58:	54ffff81 	b.ne	9e48 <fwp_hof0.constprop.0+0x19a8>  // b.any
    9e5c:	f9400420 	ldr	x0, [x1, #8]
    9e60:	d1000400 	sub	x0, x0, #0x1
    9e64:	f9000420 	str	x0, [x1, #8]
    9e68:	f103f81f 	cmp	x0, #0xfe
    9e6c:	54ffb521 	b.ne	9510 <fwp_hof0.constprop.0+0x1070>  // b.any
    9e70:	aa1703e0 	mov	x0, x23
    9e74:	97ffeafb 	bl	4a60 <fwp_rc_forget_slot>
    9e78:	91194280 	add	x0, x20, #0x650
    9e7c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9e80:	390002e1 	strb	w1, [x23]
    9e84:	f949ec02 	ldr	x2, [x0, #5080]
    9e88:	f949d801 	ldr	x1, [x0, #5040]
    9e8c:	d370bc42 	lsl	x2, x2, #16
    9e90:	17fffd54 	b	93e0 <fwp_hof0.constprop.0+0xf40>
    9e94:	d280001b 	mov	x27, #0x0                   	// #0
    9e98:	d280001c 	mov	x28, #0x0                   	// #0
    9e9c:	17fffd29 	b	9340 <fwp_hof0.constprop.0+0xea0>
    9ea0:	97ffeaa9 	bl	4944 <fwp_rc_wide_dup>
    9ea4:	17fff9fd 	b	8698 <fwp_hof0.constprop.0+0x1f8>
    9ea8:	ca534660 	eor	x0, x19, x19, lsr #17
    9eac:	91194281 	add	x1, x20, #0x650
    9eb0:	ca402400 	eor	x0, x0, x0, lsr #9
    9eb4:	8b200c20 	add	x0, x1, w0, uxtb #3
    9eb8:	f94a2400 	ldr	x0, [x0, #5192]
    9ebc:	b5000080 	cbnz	x0, 9ecc <fwp_hof0.constprop.0+0x1a2c>
    9ec0:	17ffffb3 	b	9d8c <fwp_hof0.constprop.0+0x18ec>
    9ec4:	f9400800 	ldr	x0, [x0, #16]
    9ec8:	b4fff620 	cbz	x0, 9d8c <fwp_hof0.constprop.0+0x18ec>
    9ecc:	f9400001 	ldr	x1, [x0]
    9ed0:	eb01027f 	cmp	x19, x1
    9ed4:	54ffff81 	b.ne	9ec4 <fwp_hof0.constprop.0+0x1a24>  // b.any
    9ed8:	f9400401 	ldr	x1, [x0, #8]
    9edc:	d1000421 	sub	x1, x1, #0x1
    9ee0:	f9000401 	str	x1, [x0, #8]
    9ee4:	f103f83f 	cmp	x1, #0xfe
    9ee8:	54ff41c1 	b.ne	8720 <fwp_hof0.constprop.0+0x280>  // b.any
    9eec:	aa1303e0 	mov	x0, x19
    9ef0:	97ffeadc 	bl	4a60 <fwp_rc_forget_slot>
    9ef4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9ef8:	39000260 	strb	w0, [x19]
    9efc:	17fffa09 	b	8720 <fwp_hof0.constprop.0+0x280>
    9f00:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9f04:	911c6000 	add	x0, x0, #0x718
    9f08:	97ffe51e 	bl	3380 <ad_raw_fail>
    9f0c:	d2800017 	mov	x23, #0x0                   	// #0
    9f10:	17fffc97 	b	916c <fwp_hof0.constprop.0+0xccc>
    9f14:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9f18:	91244000 	add	x0, x0, #0x910
    9f1c:	97ffe639 	bl	3800 <fwp_trap>
    9f20:	97ffea89 	bl	4944 <fwp_rc_wide_dup>
    9f24:	91194280 	add	x0, x20, #0x650
    9f28:	f949ec03 	ldr	x3, [x0, #5080]
    9f2c:	f949d801 	ldr	x1, [x0, #5040]
    9f30:	d370bc63 	lsl	x3, x3, #16
    9f34:	17fff9a4 	b	85c4 <fwp_hof0.constprop.0+0x124>
    9f38:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9f3c:	9121e000 	add	x0, x0, #0x878
    9f40:	97ffe630 	bl	3800 <fwp_trap>
    9f44:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9f48:	91194281 	add	x1, x20, #0x650
    9f4c:	ca402400 	eor	x0, x0, x0, lsr #9
    9f50:	8b200c20 	add	x0, x1, w0, uxtb #3
    9f54:	f94a2400 	ldr	x0, [x0, #5192]
    9f58:	b5000080 	cbnz	x0, 9f68 <fwp_hof0.constprop.0+0x1ac8>
    9f5c:	17ffff8c 	b	9d8c <fwp_hof0.constprop.0+0x18ec>
    9f60:	f9400800 	ldr	x0, [x0, #16]
    9f64:	b4fff140 	cbz	x0, 9d8c <fwp_hof0.constprop.0+0x18ec>
    9f68:	f9400001 	ldr	x1, [x0]
    9f6c:	eb0102bf 	cmp	x21, x1
    9f70:	54ffff81 	b.ne	9f60 <fwp_hof0.constprop.0+0x1ac0>  // b.any
    9f74:	f9400401 	ldr	x1, [x0, #8]
    9f78:	d1000421 	sub	x1, x1, #0x1
    9f7c:	f9000401 	str	x1, [x0, #8]
    9f80:	f103f83f 	cmp	x1, #0xfe
    9f84:	54ffce81 	b.ne	9954 <fwp_hof0.constprop.0+0x14b4>  // b.any
    9f88:	aa1503e0 	mov	x0, x21
    9f8c:	97ffeab5 	bl	4a60 <fwp_rc_forget_slot>
    9f90:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9f94:	390002a0 	strb	w0, [x21]
    9f98:	17fffe6f 	b	9954 <fwp_hof0.constprop.0+0x14b4>
    9f9c:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9fa0:	912bc000 	add	x0, x0, #0xaf0
    9fa4:	97ffe617 	bl	3800 <fwp_trap>
    9fa8:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9fac:	9125c000 	add	x0, x0, #0x970
    9fb0:	97ffe614 	bl	3800 <fwp_trap>
    9fb4:	a90f53f3 	stp	x19, x20, [sp, #240]
    9fb8:	a9105bf5 	stp	x21, x22, [sp, #256]
    9fbc:	a91163f7 	stp	x23, x24, [sp, #272]
    9fc0:	a9126bf9 	stp	x25, x26, [sp, #288]
    9fc4:	a91373fb 	stp	x27, x28, [sp, #304]
    9fc8:	6d1427e8 	stp	d8, d9, [sp, #320]
    9fcc:	97ffe235 	bl	28a0 <__stack_chk_fail@plt>
    9fd0:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9fd4:	91230000 	add	x0, x0, #0x8c0
    9fd8:	97ffe60a 	bl	3800 <fwp_trap>
    9fdc:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9fe0:	9129c000 	add	x0, x0, #0xa70
    9fe4:	97ffe607 	bl	3800 <fwp_trap>
    9fe8:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9fec:	912a4000 	add	x0, x0, #0xa90
    9ff0:	97ffe604 	bl	3800 <fwp_trap>
    9ff4:	90000020 	adrp	x0, d000 <__modti3+0x30>
    9ff8:	912cc000 	add	x0, x0, #0xb30
    9ffc:	97ffe601 	bl	3800 <fwp_trap>
    a000:	f0000000 	adrp	x0, d000 <__modti3+0x30>
    a004:	912b0000 	add	x0, x0, #0xac0
    a008:	97ffe4de 	bl	3380 <ad_raw_fail>
    a00c:	f0000000 	adrp	x0, d000 <__modti3+0x30>
    a010:	912b8000 	add	x0, x0, #0xae0
    a014:	97ffe5fb 	bl	3800 <fwp_trap>
    a018:	f0000000 	adrp	x0, d000 <__modti3+0x30>
    a01c:	912c6000 	add	x0, x0, #0xb18
    a020:	97ffe5f8 	bl	3800 <fwp_trap>
    a024:	97ffe233 	bl	28f0 <abort@plt>
    a028:	97ffe296 	bl	2a80 <fwp_trap_overflow.constprop.0>
    a02c:	d503201f 	nop

000000000000a030 <f0>:
    a030:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a034:	910003fd 	mov	x29, sp
    a038:	a90153f3 	stp	x19, x20, [sp, #16]
    a03c:	a9025bf5 	stp	x21, x22, [sp, #32]
    a040:	a90363f7 	stp	x23, x24, [sp, #48]
    a044:	a9046bf9 	stp	x25, x26, [sp, #64]
    a048:	a90573fb 	stp	x27, x28, [sp, #80]
    a04c:	d12183ff 	sub	sp, sp, #0x860
    a050:	f90203ff 	str	xzr, [sp, #1024]
    a054:	d00000a0 	adrp	x0, 20000 <__data_start>
    a058:	91014005 	add	x5, x0, #0x50
    a05c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    a060:	f947f400 	ldr	x0, [x0, #4072]
    a064:	f0000374 	adrp	x20, 79000 <fwp_root_context+0xb90>
    a068:	f941d8a6 	ldr	x6, [x5, #944]
    a06c:	f9400001 	ldr	x1, [x0]
    a070:	f9042fe1 	str	x1, [sp, #2136]
    a074:	d2800001 	mov	x1, #0x0                   	// #0
    a078:	91194298 	add	x24, x20, #0x650
    a07c:	912123f6 	add	x22, sp, #0x848
    a080:	910023e0 	add	x0, sp, #0x8
    a084:	910083e2 	add	x2, sp, #0x20
    a088:	f0ffffc1 	adrp	x1, 5000 <fwp_heap_alloc_slow>
    a08c:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a090:	9137c021 	add	x1, x1, #0xdf0
    a094:	913d4084 	add	x4, x4, #0xf50
    a098:	d2800013 	mov	x19, #0x0                   	// #0
    a09c:	d2800119 	mov	x25, #0x8                   	// #8
    a0a0:	d2800015 	mov	x21, #0x0                   	// #0
    a0a4:	52800037 	mov	w23, #0x1                   	// #1
    a0a8:	a90093e6 	stp	x6, x4, [sp, #8]
    a0ac:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a0b0:	a90307ff 	stp	xzr, x1, [sp, #48]
    a0b4:	f901d8a0 	str	x0, [x5, #944]
    a0b8:	f100073a 	subs	x26, x25, #0x1
    a0bc:	aa1603e1 	mov	x1, x22
    a0c0:	da1f02bc 	sbc	x28, x21, xzr
    a0c4:	52800020 	mov	w0, #0x1                   	// #1
    a0c8:	f90017fa 	str	x26, [sp, #40]
    a0cc:	aa1a03f9 	mov	x25, x26
    a0d0:	f90427fa 	str	x26, [sp, #2120]
    a0d4:	aa1c03f5 	mov	x21, x28
    a0d8:	f9042bf3 	str	x19, [sp, #2128]
    a0dc:	97ffec82 	bl	52e4 <fwp_data.part.0.constprop.0>
    a0e0:	f949db02 	ldr	x2, [x24, #5040]
    a0e4:	aa0003f3 	mov	x19, x0
    a0e8:	f949ef00 	ldr	x0, [x24, #5080]
    a0ec:	cb020262 	sub	x2, x19, x2
    a0f0:	eb00405f 	cmp	x2, x0, lsl #16
    a0f4:	54000302 	b.cs	a154 <f0+0x124>  // b.hs, b.nlast
    a0f8:	d350fc40 	lsr	x0, x2, #16
    a0fc:	f949ff04 	ldr	x4, [x24, #5112]
    a100:	8b000800 	add	x0, x0, x0, lsl #2
    a104:	d37df001 	lsl	x1, x0, #3
    a108:	8b010080 	add	x0, x4, x1
    a10c:	f940101b 	ldr	x27, [x0, #32]
    a110:	b400023b 	cbz	x27, a154 <f0+0x124>
    a114:	38616881 	ldrb	w1, [x4, x1]
    a118:	7100083f 	cmp	w1, #0x2
    a11c:	54010e00 	b.eq	c2dc <f0+0x22ac>  // b.none
    a120:	7100043f 	cmp	w1, #0x1
    a124:	54000181 	b.ne	a154 <f0+0x124>  // b.any
    a128:	29430001 	ldp	w1, w0, [x0, #24]
    a12c:	92403c42 	and	x2, x2, #0xffff
    a130:	9b017c42 	mul	x2, x2, x1
    a134:	d360fc42 	lsr	x2, x2, #32
    a138:	eb00005f 	cmp	x2, x0
    a13c:	540000c2 	b.cs	a154 <f0+0x124>  // b.hs, b.nlast
    a140:	8b02037b 	add	x27, x27, x2
    a144:	39400360 	ldrb	w0, [x27]
    a148:	7103fc1f 	cmp	w0, #0xff
    a14c:	54010c20 	b.eq	c2d0 <f0+0x22a0>  // b.none
    a150:	39000377 	strb	w23, [x27]
    a154:	f90013f3 	str	x19, [sp, #32]
    a158:	aa1c035a 	orr	x26, x26, x28
    a15c:	b5fffafa 	cbnz	x26, a0b8 <f0+0x88>
    a160:	90000020 	adrp	x0, e000 <_IO_stdin_used+0xc90>
    a164:	910103e1 	add	x1, sp, #0x40
    a168:	f94007e2 	ldr	x2, [sp, #8]
    a16c:	3dc0d400 	ldr	q0, [x0, #848]
    a170:	d00000a0 	adrp	x0, 20000 <__data_start>
    a174:	91014018 	add	x24, x0, #0x50
    a178:	52800020 	mov	w0, #0x1                   	// #1
    a17c:	3d8013e0 	str	q0, [sp, #64]
    a180:	f901db02 	str	x2, [x24, #944]
    a184:	97ffec58 	bl	52e4 <fwp_data.part.0.constprop.0>
    a188:	97ffee0b 	bl	59b4 <fwp_rc_fresh>
    a18c:	aa0003e2 	mov	x2, x0
    a190:	910163e1 	add	x1, sp, #0x58
    a194:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a198:	52800020 	mov	w0, #0x1                   	// #1
    a19c:	a9058be3 	stp	x3, x2, [sp, #88]
    a1a0:	97ffec51 	bl	52e4 <fwp_data.part.0.constprop.0>
    a1a4:	97ffee04 	bl	59b4 <fwp_rc_fresh>
    a1a8:	aa0003e2 	mov	x2, x0
    a1ac:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xc90>
    a1b0:	9101a3e1 	add	x1, sp, #0x68
    a1b4:	52800020 	mov	w0, #0x1                   	// #1
    a1b8:	f9003be2 	str	x2, [sp, #112]
    a1bc:	3dc0d460 	ldr	q0, [x3, #848]
    a1c0:	fd0037e0 	str	d0, [sp, #104]
    a1c4:	97ffec48 	bl	52e4 <fwp_data.part.0.constprop.0>
    a1c8:	91194283 	add	x3, x20, #0x650
    a1cc:	aa0003f5 	mov	x21, x0
    a1d0:	f949d861 	ldr	x1, [x3, #5040]
    a1d4:	f949ec60 	ldr	x0, [x3, #5080]
    a1d8:	cb0102a1 	sub	x1, x21, x1
    a1dc:	eb00403f 	cmp	x1, x0, lsl #16
    a1e0:	54000322 	b.cs	a244 <f0+0x214>  // b.hs, b.nlast
    a1e4:	d350fc22 	lsr	x2, x1, #16
    a1e8:	f949fc63 	ldr	x3, [x3, #5112]
    a1ec:	8b020842 	add	x2, x2, x2, lsl #2
    a1f0:	d37df042 	lsl	x2, x2, #3
    a1f4:	8b020060 	add	x0, x3, x2
    a1f8:	f9401017 	ldr	x23, [x0, #32]
    a1fc:	b4000257 	cbz	x23, a244 <f0+0x214>
    a200:	38626862 	ldrb	w2, [x3, x2]
    a204:	7100085f 	cmp	w2, #0x2
    a208:	54010ac0 	b.eq	c360 <f0+0x2330>  // b.none
    a20c:	7100045f 	cmp	w2, #0x1
    a210:	540001a1 	b.ne	a244 <f0+0x214>  // b.any
    a214:	29430002 	ldp	w2, w0, [x0, #24]
    a218:	92403c21 	and	x1, x1, #0xffff
    a21c:	9b027c21 	mul	x1, x1, x2
    a220:	d360fc21 	lsr	x1, x1, #32
    a224:	eb00003f 	cmp	x1, x0
    a228:	540000e2 	b.cs	a244 <f0+0x214>  // b.hs, b.nlast
    a22c:	8b0102f7 	add	x23, x23, x1
    a230:	394002e0 	ldrb	w0, [x23]
    a234:	7103fc1f 	cmp	w0, #0xff
    a238:	54011480 	b.eq	c4c8 <f0+0x2498>  // b.none
    a23c:	52800020 	mov	w0, #0x1                   	// #1
    a240:	390002e0 	strb	w0, [x23]
    a244:	9101e3e1 	add	x1, sp, #0x78
    a248:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a24c:	52800020 	mov	w0, #0x1                   	// #1
    a250:	a907d7e2 	stp	x2, x21, [sp, #120]
    a254:	97ffec24 	bl	52e4 <fwp_data.part.0.constprop.0>
    a258:	97ffedd7 	bl	59b4 <fwp_rc_fresh>
    a25c:	aa0003e2 	mov	x2, x0
    a260:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a264:	910223e1 	add	x1, sp, #0x88
    a268:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a26c:	52800020 	mov	w0, #0x1                   	// #1
    a270:	a9088be3 	stp	x3, x2, [sp, #136]
    a274:	97ffec1c 	bl	52e4 <fwp_data.part.0.constprop.0>
    a278:	91194283 	add	x3, x20, #0x650
    a27c:	aa0003f7 	mov	x23, x0
    a280:	f949d861 	ldr	x1, [x3, #5040]
    a284:	f949ec60 	ldr	x0, [x3, #5080]
    a288:	cb0102e1 	sub	x1, x23, x1
    a28c:	eb00403f 	cmp	x1, x0, lsl #16
    a290:	54000322 	b.cs	a2f4 <f0+0x2c4>  // b.hs, b.nlast
    a294:	d350fc22 	lsr	x2, x1, #16
    a298:	f949fc63 	ldr	x3, [x3, #5112]
    a29c:	8b020842 	add	x2, x2, x2, lsl #2
    a2a0:	d37df042 	lsl	x2, x2, #3
    a2a4:	8b020060 	add	x0, x3, x2
    a2a8:	f9401015 	ldr	x21, [x0, #32]
    a2ac:	b4000255 	cbz	x21, a2f4 <f0+0x2c4>
    a2b0:	38626862 	ldrb	w2, [x3, x2]
    a2b4:	7100085f 	cmp	w2, #0x2
    a2b8:	540104e0 	b.eq	c354 <f0+0x2324>  // b.none
    a2bc:	7100045f 	cmp	w2, #0x1
    a2c0:	540001a1 	b.ne	a2f4 <f0+0x2c4>  // b.any
    a2c4:	29430002 	ldp	w2, w0, [x0, #24]
    a2c8:	92403c21 	and	x1, x1, #0xffff
    a2cc:	9b027c21 	mul	x1, x1, x2
    a2d0:	d360fc21 	lsr	x1, x1, #32
    a2d4:	eb00003f 	cmp	x1, x0
    a2d8:	540000e2 	b.cs	a2f4 <f0+0x2c4>  // b.hs, b.nlast
    a2dc:	8b0102b5 	add	x21, x21, x1
    a2e0:	394002a0 	ldrb	w0, [x21]
    a2e4:	7103fc1f 	cmp	w0, #0xff
    a2e8:	54010f60 	b.eq	c4d4 <f0+0x24a4>  // b.none
    a2ec:	52800020 	mov	w0, #0x1                   	// #1
    a2f0:	390002a0 	strb	w0, [x21]
    a2f4:	910263e1 	add	x1, sp, #0x98
    a2f8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a2fc:	52800020 	mov	w0, #0x1                   	// #1
    a300:	a909dff5 	stp	x21, x23, [sp, #152]
    a304:	97ffebf8 	bl	52e4 <fwp_data.part.0.constprop.0>
    a308:	97ffedab 	bl	59b4 <fwp_rc_fresh>
    a30c:	aa0003e2 	mov	x2, x0
    a310:	9102a3e1 	add	x1, sp, #0xa8
    a314:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a318:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a31c:	52800020 	mov	w0, #0x1                   	// #1
    a320:	a90a8bf7 	stp	x23, x2, [sp, #168]
    a324:	97ffebf0 	bl	52e4 <fwp_data.part.0.constprop.0>
    a328:	97ffeda3 	bl	59b4 <fwp_rc_fresh>
    a32c:	aa0003e2 	mov	x2, x0
    a330:	9102e3e1 	add	x1, sp, #0xb8
    a334:	52800020 	mov	w0, #0x1                   	// #1
    a338:	a90b8bf5 	stp	x21, x2, [sp, #184]
    a33c:	97ffebea 	bl	52e4 <fwp_data.part.0.constprop.0>
    a340:	97ffed9d 	bl	59b4 <fwp_rc_fresh>
    a344:	aa0003e2 	mov	x2, x0
    a348:	910323e1 	add	x1, sp, #0xc8
    a34c:	52800020 	mov	w0, #0x1                   	// #1
    a350:	a90c8bf7 	stp	x23, x2, [sp, #200]
    a354:	97ffebe4 	bl	52e4 <fwp_data.part.0.constprop.0>
    a358:	97ffed97 	bl	59b4 <fwp_rc_fresh>
    a35c:	aa0003e2 	mov	x2, x0
    a360:	910363e1 	add	x1, sp, #0xd8
    a364:	52800020 	mov	w0, #0x1                   	// #1
    a368:	a90d8bf5 	stp	x21, x2, [sp, #216]
    a36c:	97ffebde 	bl	52e4 <fwp_data.part.0.constprop.0>
    a370:	97ffed91 	bl	59b4 <fwp_rc_fresh>
    a374:	aa0003e2 	mov	x2, x0
    a378:	9103a3e1 	add	x1, sp, #0xe8
    a37c:	52800020 	mov	w0, #0x1                   	// #1
    a380:	a90e8bf7 	stp	x23, x2, [sp, #232]
    a384:	97ffebd8 	bl	52e4 <fwp_data.part.0.constprop.0>
    a388:	97ffed8b 	bl	59b4 <fwp_rc_fresh>
    a38c:	aa0003e2 	mov	x2, x0
    a390:	9103e3e1 	add	x1, sp, #0xf8
    a394:	52800020 	mov	w0, #0x1                   	// #1
    a398:	a90f8bf5 	stp	x21, x2, [sp, #248]
    a39c:	97ffebd2 	bl	52e4 <fwp_data.part.0.constprop.0>
    a3a0:	97ffed85 	bl	59b4 <fwp_rc_fresh>
    a3a4:	aa0003e2 	mov	x2, x0
    a3a8:	910423e1 	add	x1, sp, #0x108
    a3ac:	52800020 	mov	w0, #0x1                   	// #1
    a3b0:	a9108bf7 	stp	x23, x2, [sp, #264]
    a3b4:	97ffebcc 	bl	52e4 <fwp_data.part.0.constprop.0>
    a3b8:	97ffed7f 	bl	59b4 <fwp_rc_fresh>
    a3bc:	aa0003e2 	mov	x2, x0
    a3c0:	910463e1 	add	x1, sp, #0x118
    a3c4:	52800020 	mov	w0, #0x1                   	// #1
    a3c8:	a9118bf5 	stp	x21, x2, [sp, #280]
    a3cc:	97ffebc6 	bl	52e4 <fwp_data.part.0.constprop.0>
    a3d0:	97ffed79 	bl	59b4 <fwp_rc_fresh>
    a3d4:	aa0003e2 	mov	x2, x0
    a3d8:	9104a3e1 	add	x1, sp, #0x128
    a3dc:	52800020 	mov	w0, #0x1                   	// #1
    a3e0:	a9128bf7 	stp	x23, x2, [sp, #296]
    a3e4:	97ffebc0 	bl	52e4 <fwp_data.part.0.constprop.0>
    a3e8:	97ffed73 	bl	59b4 <fwp_rc_fresh>
    a3ec:	aa0003e2 	mov	x2, x0
    a3f0:	9104e3e1 	add	x1, sp, #0x138
    a3f4:	52800020 	mov	w0, #0x1                   	// #1
    a3f8:	a9138bf5 	stp	x21, x2, [sp, #312]
    a3fc:	97ffebba 	bl	52e4 <fwp_data.part.0.constprop.0>
    a400:	97ffed6d 	bl	59b4 <fwp_rc_fresh>
    a404:	aa0003e2 	mov	x2, x0
    a408:	910523e1 	add	x1, sp, #0x148
    a40c:	52800020 	mov	w0, #0x1                   	// #1
    a410:	a9148bf7 	stp	x23, x2, [sp, #328]
    a414:	97ffebb4 	bl	52e4 <fwp_data.part.0.constprop.0>
    a418:	97ffed67 	bl	59b4 <fwp_rc_fresh>
    a41c:	aa0003e2 	mov	x2, x0
    a420:	910563e1 	add	x1, sp, #0x158
    a424:	52800020 	mov	w0, #0x1                   	// #1
    a428:	a9158bf5 	stp	x21, x2, [sp, #344]
    a42c:	97ffebae 	bl	52e4 <fwp_data.part.0.constprop.0>
    a430:	97ffed61 	bl	59b4 <fwp_rc_fresh>
    a434:	aa0003e2 	mov	x2, x0
    a438:	9105a3e1 	add	x1, sp, #0x168
    a43c:	52800020 	mov	w0, #0x1                   	// #1
    a440:	a9168bf7 	stp	x23, x2, [sp, #360]
    a444:	97ffeba8 	bl	52e4 <fwp_data.part.0.constprop.0>
    a448:	97ffed5b 	bl	59b4 <fwp_rc_fresh>
    a44c:	aa0003e2 	mov	x2, x0
    a450:	9105e3e1 	add	x1, sp, #0x178
    a454:	52800020 	mov	w0, #0x1                   	// #1
    a458:	a9178bf5 	stp	x21, x2, [sp, #376]
    a45c:	97ffeba2 	bl	52e4 <fwp_data.part.0.constprop.0>
    a460:	91194283 	add	x3, x20, #0x650
    a464:	aa0003f5 	mov	x21, x0
    a468:	f949d861 	ldr	x1, [x3, #5040]
    a46c:	f949ec60 	ldr	x0, [x3, #5080]
    a470:	cb0102a1 	sub	x1, x21, x1
    a474:	eb00403f 	cmp	x1, x0, lsl #16
    a478:	54000322 	b.cs	a4dc <f0+0x4ac>  // b.hs, b.nlast
    a47c:	d350fc22 	lsr	x2, x1, #16
    a480:	f949fc63 	ldr	x3, [x3, #5112]
    a484:	8b020842 	add	x2, x2, x2, lsl #2
    a488:	d37df042 	lsl	x2, x2, #3
    a48c:	8b020060 	add	x0, x3, x2
    a490:	f9401017 	ldr	x23, [x0, #32]
    a494:	b4000257 	cbz	x23, a4dc <f0+0x4ac>
    a498:	38626862 	ldrb	w2, [x3, x2]
    a49c:	7100085f 	cmp	w2, #0x2
    a4a0:	5400f540 	b.eq	c348 <f0+0x2318>  // b.none
    a4a4:	7100045f 	cmp	w2, #0x1
    a4a8:	540001a1 	b.ne	a4dc <f0+0x4ac>  // b.any
    a4ac:	29430002 	ldp	w2, w0, [x0, #24]
    a4b0:	92403c21 	and	x1, x1, #0xffff
    a4b4:	9b027c21 	mul	x1, x1, x2
    a4b8:	d360fc21 	lsr	x1, x1, #32
    a4bc:	eb00003f 	cmp	x1, x0
    a4c0:	540000e2 	b.cs	a4dc <f0+0x4ac>  // b.hs, b.nlast
    a4c4:	8b0102f7 	add	x23, x23, x1
    a4c8:	394002e0 	ldrb	w0, [x23]
    a4cc:	7103fc1f 	cmp	w0, #0xff
    a4d0:	54010080 	b.eq	c4e0 <f0+0x24b0>  // b.none
    a4d4:	52800020 	mov	w0, #0x1                   	// #1
    a4d8:	390002e0 	strb	w0, [x23]
    a4dc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a4e0:	910623e1 	add	x1, sp, #0x188
    a4e4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a4e8:	52800020 	mov	w0, #0x1                   	// #1
    a4ec:	a918d7e2 	stp	x2, x21, [sp, #392]
    a4f0:	97ffeb7d 	bl	52e4 <fwp_data.part.0.constprop.0>
    a4f4:	97ffed30 	bl	59b4 <fwp_rc_fresh>
    a4f8:	aa0003e2 	mov	x2, x0
    a4fc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a500:	910663e1 	add	x1, sp, #0x198
    a504:	52800020 	mov	w0, #0x1                   	// #1
    a508:	a9198be3 	stp	x3, x2, [sp, #408]
    a50c:	97ffeb76 	bl	52e4 <fwp_data.part.0.constprop.0>
    a510:	91194283 	add	x3, x20, #0x650
    a514:	aa0003f5 	mov	x21, x0
    a518:	f949d861 	ldr	x1, [x3, #5040]
    a51c:	f949ec60 	ldr	x0, [x3, #5080]
    a520:	cb0102a1 	sub	x1, x21, x1
    a524:	eb00403f 	cmp	x1, x0, lsl #16
    a528:	54000322 	b.cs	a58c <f0+0x55c>  // b.hs, b.nlast
    a52c:	d350fc22 	lsr	x2, x1, #16
    a530:	f949fc63 	ldr	x3, [x3, #5112]
    a534:	8b020842 	add	x2, x2, x2, lsl #2
    a538:	d37df042 	lsl	x2, x2, #3
    a53c:	8b020060 	add	x0, x3, x2
    a540:	f9401017 	ldr	x23, [x0, #32]
    a544:	b4000257 	cbz	x23, a58c <f0+0x55c>
    a548:	38626862 	ldrb	w2, [x3, x2]
    a54c:	7100085f 	cmp	w2, #0x2
    a550:	5400f200 	b.eq	c390 <f0+0x2360>  // b.none
    a554:	7100045f 	cmp	w2, #0x1
    a558:	540001a1 	b.ne	a58c <f0+0x55c>  // b.any
    a55c:	29430002 	ldp	w2, w0, [x0, #24]
    a560:	92403c21 	and	x1, x1, #0xffff
    a564:	9b027c21 	mul	x1, x1, x2
    a568:	d360fc21 	lsr	x1, x1, #32
    a56c:	eb00003f 	cmp	x1, x0
    a570:	540000e2 	b.cs	a58c <f0+0x55c>  // b.hs, b.nlast
    a574:	8b0102f7 	add	x23, x23, x1
    a578:	394002e0 	ldrb	w0, [x23]
    a57c:	7103fc1f 	cmp	w0, #0xff
    a580:	5400fb60 	b.eq	c4ec <f0+0x24bc>  // b.none
    a584:	52800020 	mov	w0, #0x1                   	// #1
    a588:	390002e0 	strb	w0, [x23]
    a58c:	9106a3e1 	add	x1, sp, #0x1a8
    a590:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a594:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a598:	52800020 	mov	w0, #0x1                   	// #1
    a59c:	a91ad7f7 	stp	x23, x21, [sp, #424]
    a5a0:	97ffeb51 	bl	52e4 <fwp_data.part.0.constprop.0>
    a5a4:	97ffed04 	bl	59b4 <fwp_rc_fresh>
    a5a8:	aa0003e2 	mov	x2, x0
    a5ac:	9106e3e1 	add	x1, sp, #0x1b8
    a5b0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a5b4:	52800020 	mov	w0, #0x1                   	// #1
    a5b8:	a91b8bf5 	stp	x21, x2, [sp, #440]
    a5bc:	97ffeb4a 	bl	52e4 <fwp_data.part.0.constprop.0>
    a5c0:	97ffecfd 	bl	59b4 <fwp_rc_fresh>
    a5c4:	aa0003e2 	mov	x2, x0
    a5c8:	910723e1 	add	x1, sp, #0x1c8
    a5cc:	52800020 	mov	w0, #0x1                   	// #1
    a5d0:	a91c8bf7 	stp	x23, x2, [sp, #456]
    a5d4:	97ffeb44 	bl	52e4 <fwp_data.part.0.constprop.0>
    a5d8:	97ffecf7 	bl	59b4 <fwp_rc_fresh>
    a5dc:	aa0003e2 	mov	x2, x0
    a5e0:	910763e1 	add	x1, sp, #0x1d8
    a5e4:	52800020 	mov	w0, #0x1                   	// #1
    a5e8:	a91d8bf5 	stp	x21, x2, [sp, #472]
    a5ec:	97ffeb3e 	bl	52e4 <fwp_data.part.0.constprop.0>
    a5f0:	91194283 	add	x3, x20, #0x650
    a5f4:	aa0003f5 	mov	x21, x0
    a5f8:	f949d861 	ldr	x1, [x3, #5040]
    a5fc:	f949ec60 	ldr	x0, [x3, #5080]
    a600:	cb0102a1 	sub	x1, x21, x1
    a604:	eb00403f 	cmp	x1, x0, lsl #16
    a608:	54000322 	b.cs	a66c <f0+0x63c>  // b.hs, b.nlast
    a60c:	d350fc22 	lsr	x2, x1, #16
    a610:	f949fc63 	ldr	x3, [x3, #5112]
    a614:	8b020842 	add	x2, x2, x2, lsl #2
    a618:	d37df042 	lsl	x2, x2, #3
    a61c:	8b020060 	add	x0, x3, x2
    a620:	f9401017 	ldr	x23, [x0, #32]
    a624:	b4000257 	cbz	x23, a66c <f0+0x63c>
    a628:	38626862 	ldrb	w2, [x3, x2]
    a62c:	7100085f 	cmp	w2, #0x2
    a630:	5400eaa0 	b.eq	c384 <f0+0x2354>  // b.none
    a634:	7100045f 	cmp	w2, #0x1
    a638:	540001a1 	b.ne	a66c <f0+0x63c>  // b.any
    a63c:	29430002 	ldp	w2, w0, [x0, #24]
    a640:	92403c21 	and	x1, x1, #0xffff
    a644:	9b027c21 	mul	x1, x1, x2
    a648:	d360fc21 	lsr	x1, x1, #32
    a64c:	eb00003f 	cmp	x1, x0
    a650:	540000e2 	b.cs	a66c <f0+0x63c>  // b.hs, b.nlast
    a654:	8b0102f7 	add	x23, x23, x1
    a658:	394002e0 	ldrb	w0, [x23]
    a65c:	7103fc1f 	cmp	w0, #0xff
    a660:	5400f4c0 	b.eq	c4f8 <f0+0x24c8>  // b.none
    a664:	52800020 	mov	w0, #0x1                   	// #1
    a668:	390002e0 	strb	w0, [x23]
    a66c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a670:	9107a3e1 	add	x1, sp, #0x1e8
    a674:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a678:	52800020 	mov	w0, #0x1                   	// #1
    a67c:	a91ed7e2 	stp	x2, x21, [sp, #488]
    a680:	97ffeb19 	bl	52e4 <fwp_data.part.0.constprop.0>
    a684:	97ffeccc 	bl	59b4 <fwp_rc_fresh>
    a688:	aa0003e2 	mov	x2, x0
    a68c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a690:	9107e3e1 	add	x1, sp, #0x1f8
    a694:	52800020 	mov	w0, #0x1                   	// #1
    a698:	a91f8be3 	stp	x3, x2, [sp, #504]
    a69c:	97ffeb12 	bl	52e4 <fwp_data.part.0.constprop.0>
    a6a0:	91194283 	add	x3, x20, #0x650
    a6a4:	aa0003f5 	mov	x21, x0
    a6a8:	f949d861 	ldr	x1, [x3, #5040]
    a6ac:	f949ec60 	ldr	x0, [x3, #5080]
    a6b0:	cb0102a1 	sub	x1, x21, x1
    a6b4:	eb00403f 	cmp	x1, x0, lsl #16
    a6b8:	54000322 	b.cs	a71c <f0+0x6ec>  // b.hs, b.nlast
    a6bc:	d350fc22 	lsr	x2, x1, #16
    a6c0:	f949fc63 	ldr	x3, [x3, #5112]
    a6c4:	8b020842 	add	x2, x2, x2, lsl #2
    a6c8:	d37df042 	lsl	x2, x2, #3
    a6cc:	8b020060 	add	x0, x3, x2
    a6d0:	f9401017 	ldr	x23, [x0, #32]
    a6d4:	b4000257 	cbz	x23, a71c <f0+0x6ec>
    a6d8:	38626862 	ldrb	w2, [x3, x2]
    a6dc:	7100085f 	cmp	w2, #0x2
    a6e0:	5400e4c0 	b.eq	c378 <f0+0x2348>  // b.none
    a6e4:	7100045f 	cmp	w2, #0x1
    a6e8:	540001a1 	b.ne	a71c <f0+0x6ec>  // b.any
    a6ec:	29430002 	ldp	w2, w0, [x0, #24]
    a6f0:	92403c21 	and	x1, x1, #0xffff
    a6f4:	9b027c21 	mul	x1, x1, x2
    a6f8:	d360fc21 	lsr	x1, x1, #32
    a6fc:	eb00003f 	cmp	x1, x0
    a700:	540000e2 	b.cs	a71c <f0+0x6ec>  // b.hs, b.nlast
    a704:	8b0102f7 	add	x23, x23, x1
    a708:	394002e0 	ldrb	w0, [x23]
    a70c:	7103fc1f 	cmp	w0, #0xff
    a710:	5400efa0 	b.eq	c504 <f0+0x24d4>  // b.none
    a714:	52800020 	mov	w0, #0x1                   	// #1
    a718:	390002e0 	strb	w0, [x23]
    a71c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a720:	910823e1 	add	x1, sp, #0x208
    a724:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a728:	52800020 	mov	w0, #0x1                   	// #1
    a72c:	f90107e2 	str	x2, [sp, #520]
    a730:	f9010bf5 	str	x21, [sp, #528]
    a734:	97ffeaec 	bl	52e4 <fwp_data.part.0.constprop.0>
    a738:	97ffec9f 	bl	59b4 <fwp_rc_fresh>
    a73c:	aa0003e2 	mov	x2, x0
    a740:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a744:	910863e1 	add	x1, sp, #0x218
    a748:	52800020 	mov	w0, #0x1                   	// #1
    a74c:	f9010fe3 	str	x3, [sp, #536]
    a750:	f90113e2 	str	x2, [sp, #544]
    a754:	97ffeae4 	bl	52e4 <fwp_data.part.0.constprop.0>
    a758:	91194283 	add	x3, x20, #0x650
    a75c:	aa0003f5 	mov	x21, x0
    a760:	f949d861 	ldr	x1, [x3, #5040]
    a764:	f949ec60 	ldr	x0, [x3, #5080]
    a768:	cb0102a1 	sub	x1, x21, x1
    a76c:	eb00403f 	cmp	x1, x0, lsl #16
    a770:	54000322 	b.cs	a7d4 <f0+0x7a4>  // b.hs, b.nlast
    a774:	d350fc22 	lsr	x2, x1, #16
    a778:	f949fc63 	ldr	x3, [x3, #5112]
    a77c:	8b020842 	add	x2, x2, x2, lsl #2
    a780:	d37df042 	lsl	x2, x2, #3
    a784:	8b020060 	add	x0, x3, x2
    a788:	f9401017 	ldr	x23, [x0, #32]
    a78c:	b4000257 	cbz	x23, a7d4 <f0+0x7a4>
    a790:	38626862 	ldrb	w2, [x3, x2]
    a794:	7100085f 	cmp	w2, #0x2
    a798:	5400dea0 	b.eq	c36c <f0+0x233c>  // b.none
    a79c:	7100045f 	cmp	w2, #0x1
    a7a0:	540001a1 	b.ne	a7d4 <f0+0x7a4>  // b.any
    a7a4:	29430002 	ldp	w2, w0, [x0, #24]
    a7a8:	92403c21 	and	x1, x1, #0xffff
    a7ac:	9b027c21 	mul	x1, x1, x2
    a7b0:	d360fc21 	lsr	x1, x1, #32
    a7b4:	eb00003f 	cmp	x1, x0
    a7b8:	540000e2 	b.cs	a7d4 <f0+0x7a4>  // b.hs, b.nlast
    a7bc:	8b0102f7 	add	x23, x23, x1
    a7c0:	394002e0 	ldrb	w0, [x23]
    a7c4:	7103fc1f 	cmp	w0, #0xff
    a7c8:	5400ea40 	b.eq	c510 <f0+0x24e0>  // b.none
    a7cc:	52800020 	mov	w0, #0x1                   	// #1
    a7d0:	390002e0 	strb	w0, [x23]
    a7d4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a7d8:	9108a3e1 	add	x1, sp, #0x228
    a7dc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a7e0:	52800020 	mov	w0, #0x1                   	// #1
    a7e4:	f90117e2 	str	x2, [sp, #552]
    a7e8:	f9011bf5 	str	x21, [sp, #560]
    a7ec:	97ffeabe 	bl	52e4 <fwp_data.part.0.constprop.0>
    a7f0:	97ffec71 	bl	59b4 <fwp_rc_fresh>
    a7f4:	aa0003e2 	mov	x2, x0
    a7f8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a7fc:	9108e3e1 	add	x1, sp, #0x238
    a800:	52800020 	mov	w0, #0x1                   	// #1
    a804:	f9011fe3 	str	x3, [sp, #568]
    a808:	f90123e2 	str	x2, [sp, #576]
    a80c:	97ffeab6 	bl	52e4 <fwp_data.part.0.constprop.0>
    a810:	91194283 	add	x3, x20, #0x650
    a814:	aa0003f5 	mov	x21, x0
    a818:	f949d861 	ldr	x1, [x3, #5040]
    a81c:	f949ec60 	ldr	x0, [x3, #5080]
    a820:	cb0102a1 	sub	x1, x21, x1
    a824:	eb00403f 	cmp	x1, x0, lsl #16
    a828:	54000322 	b.cs	a88c <f0+0x85c>  // b.hs, b.nlast
    a82c:	d350fc22 	lsr	x2, x1, #16
    a830:	f949fc63 	ldr	x3, [x3, #5112]
    a834:	8b020842 	add	x2, x2, x2, lsl #2
    a838:	d37df042 	lsl	x2, x2, #3
    a83c:	8b020060 	add	x0, x3, x2
    a840:	f9401017 	ldr	x23, [x0, #32]
    a844:	b4000257 	cbz	x23, a88c <f0+0x85c>
    a848:	38626862 	ldrb	w2, [x3, x2]
    a84c:	7100085f 	cmp	w2, #0x2
    a850:	5400dd00 	b.eq	c3f0 <f0+0x23c0>  // b.none
    a854:	7100045f 	cmp	w2, #0x1
    a858:	540001a1 	b.ne	a88c <f0+0x85c>  // b.any
    a85c:	29430002 	ldp	w2, w0, [x0, #24]
    a860:	92403c21 	and	x1, x1, #0xffff
    a864:	9b027c21 	mul	x1, x1, x2
    a868:	d360fc21 	lsr	x1, x1, #32
    a86c:	eb00003f 	cmp	x1, x0
    a870:	540000e2 	b.cs	a88c <f0+0x85c>  // b.hs, b.nlast
    a874:	8b0102f7 	add	x23, x23, x1
    a878:	394002e0 	ldrb	w0, [x23]
    a87c:	7103fc1f 	cmp	w0, #0xff
    a880:	5400e4e0 	b.eq	c51c <f0+0x24ec>  // b.none
    a884:	52800020 	mov	w0, #0x1                   	// #1
    a888:	390002e0 	strb	w0, [x23]
    a88c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a890:	910923e1 	add	x1, sp, #0x248
    a894:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a898:	52800020 	mov	w0, #0x1                   	// #1
    a89c:	f90127e2 	str	x2, [sp, #584]
    a8a0:	f9012bf5 	str	x21, [sp, #592]
    a8a4:	97ffea90 	bl	52e4 <fwp_data.part.0.constprop.0>
    a8a8:	91194283 	add	x3, x20, #0x650
    a8ac:	aa0003f5 	mov	x21, x0
    a8b0:	f949d861 	ldr	x1, [x3, #5040]
    a8b4:	f949ec60 	ldr	x0, [x3, #5080]
    a8b8:	cb0102a1 	sub	x1, x21, x1
    a8bc:	eb00403f 	cmp	x1, x0, lsl #16
    a8c0:	54000322 	b.cs	a924 <f0+0x8f4>  // b.hs, b.nlast
    a8c4:	d350fc22 	lsr	x2, x1, #16
    a8c8:	f949fc63 	ldr	x3, [x3, #5112]
    a8cc:	8b020842 	add	x2, x2, x2, lsl #2
    a8d0:	d37df042 	lsl	x2, x2, #3
    a8d4:	8b020060 	add	x0, x3, x2
    a8d8:	f9401017 	ldr	x23, [x0, #32]
    a8dc:	b4000257 	cbz	x23, a924 <f0+0x8f4>
    a8e0:	38626862 	ldrb	w2, [x3, x2]
    a8e4:	7100085f 	cmp	w2, #0x2
    a8e8:	5400d7e0 	b.eq	c3e4 <f0+0x23b4>  // b.none
    a8ec:	7100045f 	cmp	w2, #0x1
    a8f0:	540001a1 	b.ne	a924 <f0+0x8f4>  // b.any
    a8f4:	29430002 	ldp	w2, w0, [x0, #24]
    a8f8:	92403c21 	and	x1, x1, #0xffff
    a8fc:	9b027c21 	mul	x1, x1, x2
    a900:	d360fc21 	lsr	x1, x1, #32
    a904:	eb00003f 	cmp	x1, x0
    a908:	540000e2 	b.cs	a924 <f0+0x8f4>  // b.hs, b.nlast
    a90c:	8b0102f7 	add	x23, x23, x1
    a910:	394002e0 	ldrb	w0, [x23]
    a914:	7103fc1f 	cmp	w0, #0xff
    a918:	5400e080 	b.eq	c528 <f0+0x24f8>  // b.none
    a91c:	52800020 	mov	w0, #0x1                   	// #1
    a920:	390002e0 	strb	w0, [x23]
    a924:	910963e1 	add	x1, sp, #0x258
    a928:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a92c:	52800020 	mov	w0, #0x1                   	// #1
    a930:	f9012ff7 	str	x23, [sp, #600]
    a934:	f90133f5 	str	x21, [sp, #608]
    a938:	97ffea6b 	bl	52e4 <fwp_data.part.0.constprop.0>
    a93c:	97ffec1e 	bl	59b4 <fwp_rc_fresh>
    a940:	aa0003e2 	mov	x2, x0
    a944:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a948:	9109a3e1 	add	x1, sp, #0x268
    a94c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a950:	52800020 	mov	w0, #0x1                   	// #1
    a954:	f90137e3 	str	x3, [sp, #616]
    a958:	f9013be2 	str	x2, [sp, #624]
    a95c:	97ffea62 	bl	52e4 <fwp_data.part.0.constprop.0>
    a960:	97ffec15 	bl	59b4 <fwp_rc_fresh>
    a964:	aa0003e2 	mov	x2, x0
    a968:	9109e3e1 	add	x1, sp, #0x278
    a96c:	52800020 	mov	w0, #0x1                   	// #1
    a970:	f9013ff7 	str	x23, [sp, #632]
    a974:	f90143e2 	str	x2, [sp, #640]
    a978:	97ffea5b 	bl	52e4 <fwp_data.part.0.constprop.0>
    a97c:	91194283 	add	x3, x20, #0x650
    a980:	aa0003f5 	mov	x21, x0
    a984:	f949d861 	ldr	x1, [x3, #5040]
    a988:	f949ec60 	ldr	x0, [x3, #5080]
    a98c:	cb0102a1 	sub	x1, x21, x1
    a990:	eb00403f 	cmp	x1, x0, lsl #16
    a994:	54000322 	b.cs	a9f8 <f0+0x9c8>  // b.hs, b.nlast
    a998:	d350fc22 	lsr	x2, x1, #16
    a99c:	f949fc63 	ldr	x3, [x3, #5112]
    a9a0:	8b020842 	add	x2, x2, x2, lsl #2
    a9a4:	d37df042 	lsl	x2, x2, #3
    a9a8:	8b020060 	add	x0, x3, x2
    a9ac:	f9401017 	ldr	x23, [x0, #32]
    a9b0:	b4000257 	cbz	x23, a9f8 <f0+0x9c8>
    a9b4:	38626862 	ldrb	w2, [x3, x2]
    a9b8:	7100085f 	cmp	w2, #0x2
    a9bc:	5400d0e0 	b.eq	c3d8 <f0+0x23a8>  // b.none
    a9c0:	7100045f 	cmp	w2, #0x1
    a9c4:	540001a1 	b.ne	a9f8 <f0+0x9c8>  // b.any
    a9c8:	29430002 	ldp	w2, w0, [x0, #24]
    a9cc:	92403c21 	and	x1, x1, #0xffff
    a9d0:	9b027c21 	mul	x1, x1, x2
    a9d4:	d360fc21 	lsr	x1, x1, #32
    a9d8:	eb00003f 	cmp	x1, x0
    a9dc:	540000e2 	b.cs	a9f8 <f0+0x9c8>  // b.hs, b.nlast
    a9e0:	8b0102f7 	add	x23, x23, x1
    a9e4:	394002e0 	ldrb	w0, [x23]
    a9e8:	7103fc1f 	cmp	w0, #0xff
    a9ec:	5400da40 	b.eq	c534 <f0+0x2504>  // b.none
    a9f0:	52800020 	mov	w0, #0x1                   	// #1
    a9f4:	390002e0 	strb	w0, [x23]
    a9f8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a9fc:	910a23e1 	add	x1, sp, #0x288
    aa00:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aa04:	52800020 	mov	w0, #0x1                   	// #1
    aa08:	f90147e2 	str	x2, [sp, #648]
    aa0c:	f9014bf5 	str	x21, [sp, #656]
    aa10:	97ffea35 	bl	52e4 <fwp_data.part.0.constprop.0>
    aa14:	97ffebe8 	bl	59b4 <fwp_rc_fresh>
    aa18:	aa0003e2 	mov	x2, x0
    aa1c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aa20:	910a63e1 	add	x1, sp, #0x298
    aa24:	52800020 	mov	w0, #0x1                   	// #1
    aa28:	f9014fe3 	str	x3, [sp, #664]
    aa2c:	f90153e2 	str	x2, [sp, #672]
    aa30:	97ffea2d 	bl	52e4 <fwp_data.part.0.constprop.0>
    aa34:	91194283 	add	x3, x20, #0x650
    aa38:	aa0003f5 	mov	x21, x0
    aa3c:	f949d861 	ldr	x1, [x3, #5040]
    aa40:	f949ec60 	ldr	x0, [x3, #5080]
    aa44:	cb0102a1 	sub	x1, x21, x1
    aa48:	eb00403f 	cmp	x1, x0, lsl #16
    aa4c:	54000322 	b.cs	aab0 <f0+0xa80>  // b.hs, b.nlast
    aa50:	d350fc22 	lsr	x2, x1, #16
    aa54:	f949fc63 	ldr	x3, [x3, #5112]
    aa58:	8b020842 	add	x2, x2, x2, lsl #2
    aa5c:	d37df042 	lsl	x2, x2, #3
    aa60:	8b020060 	add	x0, x3, x2
    aa64:	f9401017 	ldr	x23, [x0, #32]
    aa68:	b4000257 	cbz	x23, aab0 <f0+0xa80>
    aa6c:	38626862 	ldrb	w2, [x3, x2]
    aa70:	7100085f 	cmp	w2, #0x2
    aa74:	5400cac0 	b.eq	c3cc <f0+0x239c>  // b.none
    aa78:	7100045f 	cmp	w2, #0x1
    aa7c:	540001a1 	b.ne	aab0 <f0+0xa80>  // b.any
    aa80:	29430002 	ldp	w2, w0, [x0, #24]
    aa84:	92403c21 	and	x1, x1, #0xffff
    aa88:	9b027c21 	mul	x1, x1, x2
    aa8c:	d360fc21 	lsr	x1, x1, #32
    aa90:	eb00003f 	cmp	x1, x0
    aa94:	540000e2 	b.cs	aab0 <f0+0xa80>  // b.hs, b.nlast
    aa98:	8b0102f7 	add	x23, x23, x1
    aa9c:	394002e0 	ldrb	w0, [x23]
    aaa0:	7103fc1f 	cmp	w0, #0xff
    aaa4:	5400d4e0 	b.eq	c540 <f0+0x2510>  // b.none
    aaa8:	52800020 	mov	w0, #0x1                   	// #1
    aaac:	390002e0 	strb	w0, [x23]
    aab0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aab4:	910aa3e1 	add	x1, sp, #0x2a8
    aab8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aabc:	52800020 	mov	w0, #0x1                   	// #1
    aac0:	f90157e2 	str	x2, [sp, #680]
    aac4:	f9015bf5 	str	x21, [sp, #688]
    aac8:	97ffea07 	bl	52e4 <fwp_data.part.0.constprop.0>
    aacc:	97ffebba 	bl	59b4 <fwp_rc_fresh>
    aad0:	aa0003e2 	mov	x2, x0
    aad4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aad8:	910ae3e1 	add	x1, sp, #0x2b8
    aadc:	52800020 	mov	w0, #0x1                   	// #1
    aae0:	f9015fe3 	str	x3, [sp, #696]
    aae4:	f90163e2 	str	x2, [sp, #704]
    aae8:	97ffe9ff 	bl	52e4 <fwp_data.part.0.constprop.0>
    aaec:	91194283 	add	x3, x20, #0x650
    aaf0:	aa0003f5 	mov	x21, x0
    aaf4:	f949d861 	ldr	x1, [x3, #5040]
    aaf8:	f949ec60 	ldr	x0, [x3, #5080]
    aafc:	cb0102a1 	sub	x1, x21, x1
    ab00:	eb00403f 	cmp	x1, x0, lsl #16
    ab04:	54000322 	b.cs	ab68 <f0+0xb38>  // b.hs, b.nlast
    ab08:	d350fc22 	lsr	x2, x1, #16
    ab0c:	f949fc63 	ldr	x3, [x3, #5112]
    ab10:	8b020842 	add	x2, x2, x2, lsl #2
    ab14:	d37df042 	lsl	x2, x2, #3
    ab18:	8b020060 	add	x0, x3, x2
    ab1c:	f9401017 	ldr	x23, [x0, #32]
    ab20:	b4000257 	cbz	x23, ab68 <f0+0xb38>
    ab24:	38626862 	ldrb	w2, [x3, x2]
    ab28:	7100085f 	cmp	w2, #0x2
    ab2c:	5400c4a0 	b.eq	c3c0 <f0+0x2390>  // b.none
    ab30:	7100045f 	cmp	w2, #0x1
    ab34:	540001a1 	b.ne	ab68 <f0+0xb38>  // b.any
    ab38:	29430002 	ldp	w2, w0, [x0, #24]
    ab3c:	92403c21 	and	x1, x1, #0xffff
    ab40:	9b027c21 	mul	x1, x1, x2
    ab44:	d360fc21 	lsr	x1, x1, #32
    ab48:	eb00003f 	cmp	x1, x0
    ab4c:	540000e2 	b.cs	ab68 <f0+0xb38>  // b.hs, b.nlast
    ab50:	8b0102f7 	add	x23, x23, x1
    ab54:	394002e0 	ldrb	w0, [x23]
    ab58:	7103fc1f 	cmp	w0, #0xff
    ab5c:	5400cf80 	b.eq	c54c <f0+0x251c>  // b.none
    ab60:	52800020 	mov	w0, #0x1                   	// #1
    ab64:	390002e0 	strb	w0, [x23]
    ab68:	910b23e1 	add	x1, sp, #0x2c8
    ab6c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ab70:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ab74:	52800020 	mov	w0, #0x1                   	// #1
    ab78:	f90167f7 	str	x23, [sp, #712]
    ab7c:	f9016bf5 	str	x21, [sp, #720]
    ab80:	97ffe9d9 	bl	52e4 <fwp_data.part.0.constprop.0>
    ab84:	97ffeb8c 	bl	59b4 <fwp_rc_fresh>
    ab88:	aa0003e2 	mov	x2, x0
    ab8c:	910b63e1 	add	x1, sp, #0x2d8
    ab90:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ab94:	52800020 	mov	w0, #0x1                   	// #1
    ab98:	f9016ff5 	str	x21, [sp, #728]
    ab9c:	f90173e2 	str	x2, [sp, #736]
    aba0:	97ffe9d1 	bl	52e4 <fwp_data.part.0.constprop.0>
    aba4:	97ffeb84 	bl	59b4 <fwp_rc_fresh>
    aba8:	aa0003e2 	mov	x2, x0
    abac:	910ba3e1 	add	x1, sp, #0x2e8
    abb0:	52800020 	mov	w0, #0x1                   	// #1
    abb4:	f90177f7 	str	x23, [sp, #744]
    abb8:	f9017be2 	str	x2, [sp, #752]
    abbc:	97ffe9ca 	bl	52e4 <fwp_data.part.0.constprop.0>
    abc0:	97ffeb7d 	bl	59b4 <fwp_rc_fresh>
    abc4:	aa0003e2 	mov	x2, x0
    abc8:	910be3e1 	add	x1, sp, #0x2f8
    abcc:	52800020 	mov	w0, #0x1                   	// #1
    abd0:	f9017ff5 	str	x21, [sp, #760]
    abd4:	f90183e2 	str	x2, [sp, #768]
    abd8:	97ffe9c3 	bl	52e4 <fwp_data.part.0.constprop.0>
    abdc:	97ffeb76 	bl	59b4 <fwp_rc_fresh>
    abe0:	aa0003e2 	mov	x2, x0
    abe4:	910c23e1 	add	x1, sp, #0x308
    abe8:	52800020 	mov	w0, #0x1                   	// #1
    abec:	f90187f7 	str	x23, [sp, #776]
    abf0:	f9018be2 	str	x2, [sp, #784]
    abf4:	97ffe9bc 	bl	52e4 <fwp_data.part.0.constprop.0>
    abf8:	91194283 	add	x3, x20, #0x650
    abfc:	aa0003f5 	mov	x21, x0
    ac00:	f949d861 	ldr	x1, [x3, #5040]
    ac04:	f949ec60 	ldr	x0, [x3, #5080]
    ac08:	cb0102a1 	sub	x1, x21, x1
    ac0c:	eb00403f 	cmp	x1, x0, lsl #16
    ac10:	54000322 	b.cs	ac74 <f0+0xc44>  // b.hs, b.nlast
    ac14:	d350fc22 	lsr	x2, x1, #16
    ac18:	f949fc63 	ldr	x3, [x3, #5112]
    ac1c:	8b020842 	add	x2, x2, x2, lsl #2
    ac20:	d37df042 	lsl	x2, x2, #3
    ac24:	8b020060 	add	x0, x3, x2
    ac28:	f9401017 	ldr	x23, [x0, #32]
    ac2c:	b4000257 	cbz	x23, ac74 <f0+0xc44>
    ac30:	38626862 	ldrb	w2, [x3, x2]
    ac34:	7100085f 	cmp	w2, #0x2
    ac38:	5400bbe0 	b.eq	c3b4 <f0+0x2384>  // b.none
    ac3c:	7100045f 	cmp	w2, #0x1
    ac40:	540001a1 	b.ne	ac74 <f0+0xc44>  // b.any
    ac44:	29430002 	ldp	w2, w0, [x0, #24]
    ac48:	92403c21 	and	x1, x1, #0xffff
    ac4c:	9b027c21 	mul	x1, x1, x2
    ac50:	d360fc21 	lsr	x1, x1, #32
    ac54:	eb00003f 	cmp	x1, x0
    ac58:	540000e2 	b.cs	ac74 <f0+0xc44>  // b.hs, b.nlast
    ac5c:	8b0102f7 	add	x23, x23, x1
    ac60:	394002e0 	ldrb	w0, [x23]
    ac64:	7103fc1f 	cmp	w0, #0xff
    ac68:	5400c780 	b.eq	c558 <f0+0x2528>  // b.none
    ac6c:	52800020 	mov	w0, #0x1                   	// #1
    ac70:	390002e0 	strb	w0, [x23]
    ac74:	910c63e1 	add	x1, sp, #0x318
    ac78:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ac7c:	52800020 	mov	w0, #0x1                   	// #1
    ac80:	f9018ff7 	str	x23, [sp, #792]
    ac84:	f90193f5 	str	x21, [sp, #800]
    ac88:	97ffe997 	bl	52e4 <fwp_data.part.0.constprop.0>
    ac8c:	97ffeb4a 	bl	59b4 <fwp_rc_fresh>
    ac90:	aa0003e2 	mov	x2, x0
    ac94:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac98:	910ca3e1 	add	x1, sp, #0x328
    ac9c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aca0:	52800020 	mov	w0, #0x1                   	// #1
    aca4:	f90197e3 	str	x3, [sp, #808]
    aca8:	f9019be2 	str	x2, [sp, #816]
    acac:	97ffe98e 	bl	52e4 <fwp_data.part.0.constprop.0>
    acb0:	97ffeb41 	bl	59b4 <fwp_rc_fresh>
    acb4:	aa0003e2 	mov	x2, x0
    acb8:	910ce3e1 	add	x1, sp, #0x338
    acbc:	52800020 	mov	w0, #0x1                   	// #1
    acc0:	f9019ff7 	str	x23, [sp, #824]
    acc4:	f901a3e2 	str	x2, [sp, #832]
    acc8:	97ffe987 	bl	52e4 <fwp_data.part.0.constprop.0>
    accc:	91194283 	add	x3, x20, #0x650
    acd0:	aa0003f5 	mov	x21, x0
    acd4:	f949d861 	ldr	x1, [x3, #5040]
    acd8:	f949ec60 	ldr	x0, [x3, #5080]
    acdc:	cb0102a1 	sub	x1, x21, x1
    ace0:	eb00403f 	cmp	x1, x0, lsl #16
    ace4:	54000322 	b.cs	ad48 <f0+0xd18>  // b.hs, b.nlast
    ace8:	d350fc22 	lsr	x2, x1, #16
    acec:	f949fc63 	ldr	x3, [x3, #5112]
    acf0:	8b020842 	add	x2, x2, x2, lsl #2
    acf4:	d37df042 	lsl	x2, x2, #3
    acf8:	8b020060 	add	x0, x3, x2
    acfc:	f9401017 	ldr	x23, [x0, #32]
    ad00:	b4000257 	cbz	x23, ad48 <f0+0xd18>
    ad04:	38626862 	ldrb	w2, [x3, x2]
    ad08:	7100085f 	cmp	w2, #0x2
    ad0c:	5400b4e0 	b.eq	c3a8 <f0+0x2378>  // b.none
    ad10:	7100045f 	cmp	w2, #0x1
    ad14:	540001a1 	b.ne	ad48 <f0+0xd18>  // b.any
    ad18:	29430002 	ldp	w2, w0, [x0, #24]
    ad1c:	92403c21 	and	x1, x1, #0xffff
    ad20:	9b027c21 	mul	x1, x1, x2
    ad24:	d360fc21 	lsr	x1, x1, #32
    ad28:	eb00003f 	cmp	x1, x0
    ad2c:	540000e2 	b.cs	ad48 <f0+0xd18>  // b.hs, b.nlast
    ad30:	8b0102f7 	add	x23, x23, x1
    ad34:	394002e0 	ldrb	w0, [x23]
    ad38:	7103fc1f 	cmp	w0, #0xff
    ad3c:	5400c140 	b.eq	c564 <f0+0x2534>  // b.none
    ad40:	52800020 	mov	w0, #0x1                   	// #1
    ad44:	390002e0 	strb	w0, [x23]
    ad48:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ad4c:	910d23e1 	add	x1, sp, #0x348
    ad50:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ad54:	52800020 	mov	w0, #0x1                   	// #1
    ad58:	f901a7e2 	str	x2, [sp, #840]
    ad5c:	f901abf5 	str	x21, [sp, #848]
    ad60:	97ffe961 	bl	52e4 <fwp_data.part.0.constprop.0>
    ad64:	91194283 	add	x3, x20, #0x650
    ad68:	aa0003f5 	mov	x21, x0
    ad6c:	f949d861 	ldr	x1, [x3, #5040]
    ad70:	f949ec60 	ldr	x0, [x3, #5080]
    ad74:	cb0102a1 	sub	x1, x21, x1
    ad78:	eb00403f 	cmp	x1, x0, lsl #16
    ad7c:	54000322 	b.cs	ade0 <f0+0xdb0>  // b.hs, b.nlast
    ad80:	d350fc22 	lsr	x2, x1, #16
    ad84:	f949fc63 	ldr	x3, [x3, #5112]
    ad88:	8b020842 	add	x2, x2, x2, lsl #2
    ad8c:	d37df042 	lsl	x2, x2, #3
    ad90:	8b020060 	add	x0, x3, x2
    ad94:	f9401017 	ldr	x23, [x0, #32]
    ad98:	b4000257 	cbz	x23, ade0 <f0+0xdb0>
    ad9c:	38626862 	ldrb	w2, [x3, x2]
    ada0:	7100085f 	cmp	w2, #0x2
    ada4:	5400afc0 	b.eq	c39c <f0+0x236c>  // b.none
    ada8:	7100045f 	cmp	w2, #0x1
    adac:	540001a1 	b.ne	ade0 <f0+0xdb0>  // b.any
    adb0:	29430002 	ldp	w2, w0, [x0, #24]
    adb4:	92403c21 	and	x1, x1, #0xffff
    adb8:	9b027c21 	mul	x1, x1, x2
    adbc:	d360fc21 	lsr	x1, x1, #32
    adc0:	eb00003f 	cmp	x1, x0
    adc4:	540000e2 	b.cs	ade0 <f0+0xdb0>  // b.hs, b.nlast
    adc8:	8b0102f7 	add	x23, x23, x1
    adcc:	394002e0 	ldrb	w0, [x23]
    add0:	7103fc1f 	cmp	w0, #0xff
    add4:	5400bce0 	b.eq	c570 <f0+0x2540>  // b.none
    add8:	52800020 	mov	w0, #0x1                   	// #1
    addc:	390002e0 	strb	w0, [x23]
    ade0:	910d63e1 	add	x1, sp, #0x358
    ade4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ade8:	52800020 	mov	w0, #0x1                   	// #1
    adec:	f901aff7 	str	x23, [sp, #856]
    adf0:	f901b3f5 	str	x21, [sp, #864]
    adf4:	97ffe93c 	bl	52e4 <fwp_data.part.0.constprop.0>
    adf8:	97ffeaef 	bl	59b4 <fwp_rc_fresh>
    adfc:	aa0003e2 	mov	x2, x0
    ae00:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae04:	910da3e1 	add	x1, sp, #0x368
    ae08:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae0c:	52800020 	mov	w0, #0x1                   	// #1
    ae10:	f901b7e3 	str	x3, [sp, #872]
    ae14:	f901bbe2 	str	x2, [sp, #880]
    ae18:	97ffe933 	bl	52e4 <fwp_data.part.0.constprop.0>
    ae1c:	97ffeae6 	bl	59b4 <fwp_rc_fresh>
    ae20:	aa0003e2 	mov	x2, x0
    ae24:	910de3e1 	add	x1, sp, #0x378
    ae28:	52800020 	mov	w0, #0x1                   	// #1
    ae2c:	f901bff7 	str	x23, [sp, #888]
    ae30:	f901c3e2 	str	x2, [sp, #896]
    ae34:	97ffe92c 	bl	52e4 <fwp_data.part.0.constprop.0>
    ae38:	91194283 	add	x3, x20, #0x650
    ae3c:	aa0003f5 	mov	x21, x0
    ae40:	f949d861 	ldr	x1, [x3, #5040]
    ae44:	f949ec60 	ldr	x0, [x3, #5080]
    ae48:	cb0102a1 	sub	x1, x21, x1
    ae4c:	eb00403f 	cmp	x1, x0, lsl #16
    ae50:	54000322 	b.cs	aeb4 <f0+0xe84>  // b.hs, b.nlast
    ae54:	d350fc22 	lsr	x2, x1, #16
    ae58:	f949fc63 	ldr	x3, [x3, #5112]
    ae5c:	8b020842 	add	x2, x2, x2, lsl #2
    ae60:	d37df042 	lsl	x2, x2, #3
    ae64:	8b020060 	add	x0, x3, x2
    ae68:	f9401017 	ldr	x23, [x0, #32]
    ae6c:	b4000257 	cbz	x23, aeb4 <f0+0xe84>
    ae70:	38626862 	ldrb	w2, [x3, x2]
    ae74:	7100085f 	cmp	w2, #0x2
    ae78:	5400a620 	b.eq	c33c <f0+0x230c>  // b.none
    ae7c:	7100045f 	cmp	w2, #0x1
    ae80:	540001a1 	b.ne	aeb4 <f0+0xe84>  // b.any
    ae84:	29430002 	ldp	w2, w0, [x0, #24]
    ae88:	92403c21 	and	x1, x1, #0xffff
    ae8c:	9b027c21 	mul	x1, x1, x2
    ae90:	d360fc21 	lsr	x1, x1, #32
    ae94:	eb00003f 	cmp	x1, x0
    ae98:	540000e2 	b.cs	aeb4 <f0+0xe84>  // b.hs, b.nlast
    ae9c:	8b0102f7 	add	x23, x23, x1
    aea0:	394002e0 	ldrb	w0, [x23]
    aea4:	7103fc1f 	cmp	w0, #0xff
    aea8:	5400b6a0 	b.eq	c57c <f0+0x254c>  // b.none
    aeac:	52800020 	mov	w0, #0x1                   	// #1
    aeb0:	390002e0 	strb	w0, [x23]
    aeb4:	910e23e1 	add	x1, sp, #0x388
    aeb8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aebc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    aec0:	52800020 	mov	w0, #0x1                   	// #1
    aec4:	f901c7f7 	str	x23, [sp, #904]
    aec8:	f901cbf5 	str	x21, [sp, #912]
    aecc:	97ffe906 	bl	52e4 <fwp_data.part.0.constprop.0>
    aed0:	97ffeab9 	bl	59b4 <fwp_rc_fresh>
    aed4:	aa0003e2 	mov	x2, x0
    aed8:	910e63e1 	add	x1, sp, #0x398
    aedc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    aee0:	52800020 	mov	w0, #0x1                   	// #1
    aee4:	f901cff5 	str	x21, [sp, #920]
    aee8:	f901d3e2 	str	x2, [sp, #928]
    aeec:	97ffe8fe 	bl	52e4 <fwp_data.part.0.constprop.0>
    aef0:	97ffeab1 	bl	59b4 <fwp_rc_fresh>
    aef4:	aa0003e2 	mov	x2, x0
    aef8:	910ea3e1 	add	x1, sp, #0x3a8
    aefc:	52800020 	mov	w0, #0x1                   	// #1
    af00:	f901d7f7 	str	x23, [sp, #936]
    af04:	f901dbe2 	str	x2, [sp, #944]
    af08:	97ffe8f7 	bl	52e4 <fwp_data.part.0.constprop.0>
    af0c:	97ffeaaa 	bl	59b4 <fwp_rc_fresh>
    af10:	aa0003e2 	mov	x2, x0
    af14:	910ee3e1 	add	x1, sp, #0x3b8
    af18:	52800020 	mov	w0, #0x1                   	// #1
    af1c:	f901dff5 	str	x21, [sp, #952]
    af20:	f901e3e2 	str	x2, [sp, #960]
    af24:	97ffe8f0 	bl	52e4 <fwp_data.part.0.constprop.0>
    af28:	97ffeaa3 	bl	59b4 <fwp_rc_fresh>
    af2c:	aa0003e2 	mov	x2, x0
    af30:	910f23e1 	add	x1, sp, #0x3c8
    af34:	52800020 	mov	w0, #0x1                   	// #1
    af38:	f901e7f7 	str	x23, [sp, #968]
    af3c:	f901ebe2 	str	x2, [sp, #976]
    af40:	97ffe8e9 	bl	52e4 <fwp_data.part.0.constprop.0>
    af44:	91194283 	add	x3, x20, #0x650
    af48:	aa0003f5 	mov	x21, x0
    af4c:	f949d861 	ldr	x1, [x3, #5040]
    af50:	f949ec60 	ldr	x0, [x3, #5080]
    af54:	cb0102a1 	sub	x1, x21, x1
    af58:	eb00403f 	cmp	x1, x0, lsl #16
    af5c:	54000322 	b.cs	afc0 <f0+0xf90>  // b.hs, b.nlast
    af60:	d350fc22 	lsr	x2, x1, #16
    af64:	f949fc63 	ldr	x3, [x3, #5112]
    af68:	8b020842 	add	x2, x2, x2, lsl #2
    af6c:	d37df042 	lsl	x2, x2, #3
    af70:	8b020060 	add	x0, x3, x2
    af74:	f9401017 	ldr	x23, [x0, #32]
    af78:	b4000257 	cbz	x23, afc0 <f0+0xf90>
    af7c:	38626862 	ldrb	w2, [x3, x2]
    af80:	7100085f 	cmp	w2, #0x2
    af84:	54009d60 	b.eq	c330 <f0+0x2300>  // b.none
    af88:	7100045f 	cmp	w2, #0x1
    af8c:	540001a1 	b.ne	afc0 <f0+0xf90>  // b.any
    af90:	29430002 	ldp	w2, w0, [x0, #24]
    af94:	92403c21 	and	x1, x1, #0xffff
    af98:	9b027c21 	mul	x1, x1, x2
    af9c:	d360fc21 	lsr	x1, x1, #32
    afa0:	eb00003f 	cmp	x1, x0
    afa4:	540000e2 	b.cs	afc0 <f0+0xf90>  // b.hs, b.nlast
    afa8:	8b0102f7 	add	x23, x23, x1
    afac:	394002e0 	ldrb	w0, [x23]
    afb0:	7103fc1f 	cmp	w0, #0xff
    afb4:	5400aea0 	b.eq	c588 <f0+0x2558>  // b.none
    afb8:	52800020 	mov	w0, #0x1                   	// #1
    afbc:	390002e0 	strb	w0, [x23]
    afc0:	910f63e1 	add	x1, sp, #0x3d8
    afc4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    afc8:	52800020 	mov	w0, #0x1                   	// #1
    afcc:	f901eff7 	str	x23, [sp, #984]
    afd0:	f901f3f5 	str	x21, [sp, #992]
    afd4:	97ffe8c4 	bl	52e4 <fwp_data.part.0.constprop.0>
    afd8:	97ffea77 	bl	59b4 <fwp_rc_fresh>
    afdc:	aa0003e2 	mov	x2, x0
    afe0:	910fa3e1 	add	x1, sp, #0x3e8
    afe4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    afe8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    afec:	52800020 	mov	w0, #0x1                   	// #1
    aff0:	f901f7f5 	str	x21, [sp, #1000]
    aff4:	f901fbe2 	str	x2, [sp, #1008]
    aff8:	97ffe8bb 	bl	52e4 <fwp_data.part.0.constprop.0>
    affc:	97ffea6e 	bl	59b4 <fwp_rc_fresh>
    b000:	aa0003e2 	mov	x2, x0
    b004:	910fe3e1 	add	x1, sp, #0x3f8
    b008:	52800020 	mov	w0, #0x1                   	// #1
    b00c:	f901fff7 	str	x23, [sp, #1016]
    b010:	f90203e2 	str	x2, [sp, #1024]
    b014:	97ffe8b4 	bl	52e4 <fwp_data.part.0.constprop.0>
    b018:	97ffea67 	bl	59b4 <fwp_rc_fresh>
    b01c:	aa0003e2 	mov	x2, x0
    b020:	911023e1 	add	x1, sp, #0x408
    b024:	52800020 	mov	w0, #0x1                   	// #1
    b028:	f90207f5 	str	x21, [sp, #1032]
    b02c:	f9020be2 	str	x2, [sp, #1040]
    b030:	97ffe8ad 	bl	52e4 <fwp_data.part.0.constprop.0>
    b034:	97ffea60 	bl	59b4 <fwp_rc_fresh>
    b038:	aa0003e2 	mov	x2, x0
    b03c:	911063e1 	add	x1, sp, #0x418
    b040:	52800020 	mov	w0, #0x1                   	// #1
    b044:	f9020ff7 	str	x23, [sp, #1048]
    b048:	f90213e2 	str	x2, [sp, #1056]
    b04c:	97ffe8a6 	bl	52e4 <fwp_data.part.0.constprop.0>
    b050:	91194283 	add	x3, x20, #0x650
    b054:	aa0003f5 	mov	x21, x0
    b058:	f949d861 	ldr	x1, [x3, #5040]
    b05c:	f949ec60 	ldr	x0, [x3, #5080]
    b060:	cb0102a1 	sub	x1, x21, x1
    b064:	eb00403f 	cmp	x1, x0, lsl #16
    b068:	54000322 	b.cs	b0cc <f0+0x109c>  // b.hs, b.nlast
    b06c:	d350fc22 	lsr	x2, x1, #16
    b070:	f949fc63 	ldr	x3, [x3, #5112]
    b074:	8b020842 	add	x2, x2, x2, lsl #2
    b078:	d37df042 	lsl	x2, x2, #3
    b07c:	8b020060 	add	x0, x3, x2
    b080:	f9401017 	ldr	x23, [x0, #32]
    b084:	b4000257 	cbz	x23, b0cc <f0+0x109c>
    b088:	38626862 	ldrb	w2, [x3, x2]
    b08c:	7100085f 	cmp	w2, #0x2
    b090:	540094a0 	b.eq	c324 <f0+0x22f4>  // b.none
    b094:	7100045f 	cmp	w2, #0x1
    b098:	540001a1 	b.ne	b0cc <f0+0x109c>  // b.any
    b09c:	29430002 	ldp	w2, w0, [x0, #24]
    b0a0:	92403c21 	and	x1, x1, #0xffff
    b0a4:	9b027c21 	mul	x1, x1, x2
    b0a8:	d360fc21 	lsr	x1, x1, #32
    b0ac:	eb00003f 	cmp	x1, x0
    b0b0:	540000e2 	b.cs	b0cc <f0+0x109c>  // b.hs, b.nlast
    b0b4:	8b0102f7 	add	x23, x23, x1
    b0b8:	394002e0 	ldrb	w0, [x23]
    b0bc:	7103fc1f 	cmp	w0, #0xff
    b0c0:	5400a6a0 	b.eq	c594 <f0+0x2564>  // b.none
    b0c4:	52800020 	mov	w0, #0x1                   	// #1
    b0c8:	390002e0 	strb	w0, [x23]
    b0cc:	9110a3e1 	add	x1, sp, #0x428
    b0d0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b0d4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b0d8:	52800020 	mov	w0, #0x1                   	// #1
    b0dc:	f90217f7 	str	x23, [sp, #1064]
    b0e0:	f9021bf5 	str	x21, [sp, #1072]
    b0e4:	97ffe880 	bl	52e4 <fwp_data.part.0.constprop.0>
    b0e8:	97ffea33 	bl	59b4 <fwp_rc_fresh>
    b0ec:	aa0003e2 	mov	x2, x0
    b0f0:	9110e3e1 	add	x1, sp, #0x438
    b0f4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b0f8:	52800020 	mov	w0, #0x1                   	// #1
    b0fc:	f9021ff5 	str	x21, [sp, #1080]
    b100:	f90223e2 	str	x2, [sp, #1088]
    b104:	97ffe878 	bl	52e4 <fwp_data.part.0.constprop.0>
    b108:	97ffea2b 	bl	59b4 <fwp_rc_fresh>
    b10c:	aa0003e2 	mov	x2, x0
    b110:	911123e1 	add	x1, sp, #0x448
    b114:	52800020 	mov	w0, #0x1                   	// #1
    b118:	f90227f7 	str	x23, [sp, #1096]
    b11c:	f9022be2 	str	x2, [sp, #1104]
    b120:	97ffe871 	bl	52e4 <fwp_data.part.0.constprop.0>
    b124:	97ffea24 	bl	59b4 <fwp_rc_fresh>
    b128:	aa0003e2 	mov	x2, x0
    b12c:	911163e1 	add	x1, sp, #0x458
    b130:	52800020 	mov	w0, #0x1                   	// #1
    b134:	f9022ff5 	str	x21, [sp, #1112]
    b138:	f90233e2 	str	x2, [sp, #1120]
    b13c:	97ffe86a 	bl	52e4 <fwp_data.part.0.constprop.0>
    b140:	91194283 	add	x3, x20, #0x650
    b144:	aa0003f7 	mov	x23, x0
    b148:	f949d861 	ldr	x1, [x3, #5040]
    b14c:	f949ec60 	ldr	x0, [x3, #5080]
    b150:	cb0102e1 	sub	x1, x23, x1
    b154:	eb00403f 	cmp	x1, x0, lsl #16
    b158:	54000322 	b.cs	b1bc <f0+0x118c>  // b.hs, b.nlast
    b15c:	d350fc22 	lsr	x2, x1, #16
    b160:	f949fc63 	ldr	x3, [x3, #5112]
    b164:	8b020842 	add	x2, x2, x2, lsl #2
    b168:	d37df042 	lsl	x2, x2, #3
    b16c:	8b020060 	add	x0, x3, x2
    b170:	f9401015 	ldr	x21, [x0, #32]
    b174:	b4000255 	cbz	x21, b1bc <f0+0x118c>
    b178:	38626862 	ldrb	w2, [x3, x2]
    b17c:	7100085f 	cmp	w2, #0x2
    b180:	54008cc0 	b.eq	c318 <f0+0x22e8>  // b.none
    b184:	7100045f 	cmp	w2, #0x1
    b188:	540001a1 	b.ne	b1bc <f0+0x118c>  // b.any
    b18c:	29430002 	ldp	w2, w0, [x0, #24]
    b190:	92403c21 	and	x1, x1, #0xffff
    b194:	9b027c21 	mul	x1, x1, x2
    b198:	d360fc21 	lsr	x1, x1, #32
    b19c:	eb00003f 	cmp	x1, x0
    b1a0:	540000e2 	b.cs	b1bc <f0+0x118c>  // b.hs, b.nlast
    b1a4:	8b0102b5 	add	x21, x21, x1
    b1a8:	394002a0 	ldrb	w0, [x21]
    b1ac:	7103fc1f 	cmp	w0, #0xff
    b1b0:	54009f80 	b.eq	c5a0 <f0+0x2570>  // b.none
    b1b4:	52800020 	mov	w0, #0x1                   	// #1
    b1b8:	390002a0 	strb	w0, [x21]
    b1bc:	9111a3e1 	add	x1, sp, #0x468
    b1c0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b1c4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b1c8:	52800020 	mov	w0, #0x1                   	// #1
    b1cc:	f90237f5 	str	x21, [sp, #1128]
    b1d0:	f9023bf7 	str	x23, [sp, #1136]
    b1d4:	97ffe844 	bl	52e4 <fwp_data.part.0.constprop.0>
    b1d8:	97ffe9f7 	bl	59b4 <fwp_rc_fresh>
    b1dc:	aa0003e2 	mov	x2, x0
    b1e0:	9111e3e1 	add	x1, sp, #0x478
    b1e4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b1e8:	52800020 	mov	w0, #0x1                   	// #1
    b1ec:	f9023ff7 	str	x23, [sp, #1144]
    b1f0:	f90243e2 	str	x2, [sp, #1152]
    b1f4:	97ffe83c 	bl	52e4 <fwp_data.part.0.constprop.0>
    b1f8:	97ffe9ef 	bl	59b4 <fwp_rc_fresh>
    b1fc:	aa0003e2 	mov	x2, x0
    b200:	911223e1 	add	x1, sp, #0x488
    b204:	52800020 	mov	w0, #0x1                   	// #1
    b208:	f90247f5 	str	x21, [sp, #1160]
    b20c:	f9024be2 	str	x2, [sp, #1168]
    b210:	97ffe835 	bl	52e4 <fwp_data.part.0.constprop.0>
    b214:	97ffe9e8 	bl	59b4 <fwp_rc_fresh>
    b218:	aa0003e2 	mov	x2, x0
    b21c:	911263e1 	add	x1, sp, #0x498
    b220:	52800020 	mov	w0, #0x1                   	// #1
    b224:	f9024ff7 	str	x23, [sp, #1176]
    b228:	f90253e2 	str	x2, [sp, #1184]
    b22c:	97ffe82e 	bl	52e4 <fwp_data.part.0.constprop.0>
    b230:	97ffe9e1 	bl	59b4 <fwp_rc_fresh>
    b234:	aa0003e2 	mov	x2, x0
    b238:	9112a3e1 	add	x1, sp, #0x4a8
    b23c:	52800020 	mov	w0, #0x1                   	// #1
    b240:	f90257f5 	str	x21, [sp, #1192]
    b244:	f9025be2 	str	x2, [sp, #1200]
    b248:	97ffe827 	bl	52e4 <fwp_data.part.0.constprop.0>
    b24c:	97ffe9da 	bl	59b4 <fwp_rc_fresh>
    b250:	aa0003e2 	mov	x2, x0
    b254:	9112e3e1 	add	x1, sp, #0x4b8
    b258:	52800020 	mov	w0, #0x1                   	// #1
    b25c:	f9025ff7 	str	x23, [sp, #1208]
    b260:	f90263e2 	str	x2, [sp, #1216]
    b264:	97ffe820 	bl	52e4 <fwp_data.part.0.constprop.0>
    b268:	97ffe9d3 	bl	59b4 <fwp_rc_fresh>
    b26c:	aa0003e2 	mov	x2, x0
    b270:	911323e1 	add	x1, sp, #0x4c8
    b274:	52800020 	mov	w0, #0x1                   	// #1
    b278:	f90267f5 	str	x21, [sp, #1224]
    b27c:	f9026be2 	str	x2, [sp, #1232]
    b280:	97ffe819 	bl	52e4 <fwp_data.part.0.constprop.0>
    b284:	91194283 	add	x3, x20, #0x650
    b288:	aa0003f5 	mov	x21, x0
    b28c:	f949d861 	ldr	x1, [x3, #5040]
    b290:	f949ec60 	ldr	x0, [x3, #5080]
    b294:	cb0102a1 	sub	x1, x21, x1
    b298:	eb00403f 	cmp	x1, x0, lsl #16
    b29c:	54000322 	b.cs	b300 <f0+0x12d0>  // b.hs, b.nlast
    b2a0:	d350fc22 	lsr	x2, x1, #16
    b2a4:	f949fc63 	ldr	x3, [x3, #5112]
    b2a8:	8b020842 	add	x2, x2, x2, lsl #2
    b2ac:	d37df042 	lsl	x2, x2, #3
    b2b0:	8b020060 	add	x0, x3, x2
    b2b4:	f9401017 	ldr	x23, [x0, #32]
    b2b8:	b4000257 	cbz	x23, b300 <f0+0x12d0>
    b2bc:	38626862 	ldrb	w2, [x3, x2]
    b2c0:	7100085f 	cmp	w2, #0x2
    b2c4:	54008240 	b.eq	c30c <f0+0x22dc>  // b.none
    b2c8:	7100045f 	cmp	w2, #0x1
    b2cc:	540001a1 	b.ne	b300 <f0+0x12d0>  // b.any
    b2d0:	29430002 	ldp	w2, w0, [x0, #24]
    b2d4:	92403c21 	and	x1, x1, #0xffff
    b2d8:	9b027c21 	mul	x1, x1, x2
    b2dc:	d360fc21 	lsr	x1, x1, #32
    b2e0:	eb00003f 	cmp	x1, x0
    b2e4:	540000e2 	b.cs	b300 <f0+0x12d0>  // b.hs, b.nlast
    b2e8:	8b0102f7 	add	x23, x23, x1
    b2ec:	394002e0 	ldrb	w0, [x23]
    b2f0:	7103fc1f 	cmp	w0, #0xff
    b2f4:	540095c0 	b.eq	c5ac <f0+0x257c>  // b.none
    b2f8:	52800020 	mov	w0, #0x1                   	// #1
    b2fc:	390002e0 	strb	w0, [x23]
    b300:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b304:	911363e1 	add	x1, sp, #0x4d8
    b308:	52800020 	mov	w0, #0x1                   	// #1
    b30c:	f9026fe2 	str	x2, [sp, #1240]
    b310:	f90273f5 	str	x21, [sp, #1248]
    b314:	97ffe7f4 	bl	52e4 <fwp_data.part.0.constprop.0>
    b318:	91194283 	add	x3, x20, #0x650
    b31c:	aa0003f5 	mov	x21, x0
    b320:	f949d861 	ldr	x1, [x3, #5040]
    b324:	f949ec60 	ldr	x0, [x3, #5080]
    b328:	cb0102a1 	sub	x1, x21, x1
    b32c:	eb00403f 	cmp	x1, x0, lsl #16
    b330:	54000322 	b.cs	b394 <f0+0x1364>  // b.hs, b.nlast
    b334:	d350fc22 	lsr	x2, x1, #16
    b338:	f949fc63 	ldr	x3, [x3, #5112]
    b33c:	8b020842 	add	x2, x2, x2, lsl #2
    b340:	d37df042 	lsl	x2, x2, #3
    b344:	8b020060 	add	x0, x3, x2
    b348:	f9401017 	ldr	x23, [x0, #32]
    b34c:	b4000257 	cbz	x23, b394 <f0+0x1364>
    b350:	38626862 	ldrb	w2, [x3, x2]
    b354:	7100085f 	cmp	w2, #0x2
    b358:	54007d40 	b.eq	c300 <f0+0x22d0>  // b.none
    b35c:	7100045f 	cmp	w2, #0x1
    b360:	540001a1 	b.ne	b394 <f0+0x1364>  // b.any
    b364:	29430002 	ldp	w2, w0, [x0, #24]
    b368:	92403c21 	and	x1, x1, #0xffff
    b36c:	9b027c21 	mul	x1, x1, x2
    b370:	d360fc21 	lsr	x1, x1, #32
    b374:	eb00003f 	cmp	x1, x0
    b378:	540000e2 	b.cs	b394 <f0+0x1364>  // b.hs, b.nlast
    b37c:	8b0102f7 	add	x23, x23, x1
    b380:	394002e0 	ldrb	w0, [x23]
    b384:	7103fc1f 	cmp	w0, #0xff
    b388:	54009180 	b.eq	c5b8 <f0+0x2588>  // b.none
    b38c:	52800020 	mov	w0, #0x1                   	// #1
    b390:	390002e0 	strb	w0, [x23]
    b394:	9113a3e1 	add	x1, sp, #0x4e8
    b398:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b39c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b3a0:	52800020 	mov	w0, #0x1                   	// #1
    b3a4:	f90277f7 	str	x23, [sp, #1256]
    b3a8:	f9027bf5 	str	x21, [sp, #1264]
    b3ac:	97ffe7ce 	bl	52e4 <fwp_data.part.0.constprop.0>
    b3b0:	97ffe981 	bl	59b4 <fwp_rc_fresh>
    b3b4:	aa0003e2 	mov	x2, x0
    b3b8:	9113e3e1 	add	x1, sp, #0x4f8
    b3bc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b3c0:	52800020 	mov	w0, #0x1                   	// #1
    b3c4:	f9027ff5 	str	x21, [sp, #1272]
    b3c8:	f90283e2 	str	x2, [sp, #1280]
    b3cc:	97ffe7c6 	bl	52e4 <fwp_data.part.0.constprop.0>
    b3d0:	97ffe979 	bl	59b4 <fwp_rc_fresh>
    b3d4:	aa0003e2 	mov	x2, x0
    b3d8:	911423e1 	add	x1, sp, #0x508
    b3dc:	52800020 	mov	w0, #0x1                   	// #1
    b3e0:	f90287f7 	str	x23, [sp, #1288]
    b3e4:	f9028be2 	str	x2, [sp, #1296]
    b3e8:	97ffe7bf 	bl	52e4 <fwp_data.part.0.constprop.0>
    b3ec:	97ffe972 	bl	59b4 <fwp_rc_fresh>
    b3f0:	aa0003e2 	mov	x2, x0
    b3f4:	911463e1 	add	x1, sp, #0x518
    b3f8:	52800020 	mov	w0, #0x1                   	// #1
    b3fc:	f9028ff5 	str	x21, [sp, #1304]
    b400:	f90293e2 	str	x2, [sp, #1312]
    b404:	97ffe7b8 	bl	52e4 <fwp_data.part.0.constprop.0>
    b408:	91194283 	add	x3, x20, #0x650
    b40c:	aa0003f5 	mov	x21, x0
    b410:	f949d861 	ldr	x1, [x3, #5040]
    b414:	f949ec60 	ldr	x0, [x3, #5080]
    b418:	cb0102a1 	sub	x1, x21, x1
    b41c:	eb00403f 	cmp	x1, x0, lsl #16
    b420:	54000322 	b.cs	b484 <f0+0x1454>  // b.hs, b.nlast
    b424:	d350fc22 	lsr	x2, x1, #16
    b428:	f949fc63 	ldr	x3, [x3, #5112]
    b42c:	8b020842 	add	x2, x2, x2, lsl #2
    b430:	d37df042 	lsl	x2, x2, #3
    b434:	8b020060 	add	x0, x3, x2
    b438:	f9401017 	ldr	x23, [x0, #32]
    b43c:	b4000257 	cbz	x23, b484 <f0+0x1454>
    b440:	38626862 	ldrb	w2, [x3, x2]
    b444:	7100085f 	cmp	w2, #0x2
    b448:	54007560 	b.eq	c2f4 <f0+0x22c4>  // b.none
    b44c:	7100045f 	cmp	w2, #0x1
    b450:	540001a1 	b.ne	b484 <f0+0x1454>  // b.any
    b454:	29430002 	ldp	w2, w0, [x0, #24]
    b458:	92403c21 	and	x1, x1, #0xffff
    b45c:	9b027c21 	mul	x1, x1, x2
    b460:	d360fc21 	lsr	x1, x1, #32
    b464:	eb00003f 	cmp	x1, x0
    b468:	540000e2 	b.cs	b484 <f0+0x1454>  // b.hs, b.nlast
    b46c:	8b0102f7 	add	x23, x23, x1
    b470:	394002e0 	ldrb	w0, [x23]
    b474:	7103fc1f 	cmp	w0, #0xff
    b478:	54008a60 	b.eq	c5c4 <f0+0x2594>  // b.none
    b47c:	52800020 	mov	w0, #0x1                   	// #1
    b480:	390002e0 	strb	w0, [x23]
    b484:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b488:	9114a3e1 	add	x1, sp, #0x528
    b48c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b490:	52800020 	mov	w0, #0x1                   	// #1
    b494:	f90297e2 	str	x2, [sp, #1320]
    b498:	f9029bf5 	str	x21, [sp, #1328]
    b49c:	97ffe792 	bl	52e4 <fwp_data.part.0.constprop.0>
    b4a0:	97ffe945 	bl	59b4 <fwp_rc_fresh>
    b4a4:	aa0003e2 	mov	x2, x0
    b4a8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b4ac:	9114e3e1 	add	x1, sp, #0x538
    b4b0:	52800020 	mov	w0, #0x1                   	// #1
    b4b4:	f9029fe3 	str	x3, [sp, #1336]
    b4b8:	f902a3e2 	str	x2, [sp, #1344]
    b4bc:	97ffe78a 	bl	52e4 <fwp_data.part.0.constprop.0>
    b4c0:	91194283 	add	x3, x20, #0x650
    b4c4:	aa0003f5 	mov	x21, x0
    b4c8:	f949d861 	ldr	x1, [x3, #5040]
    b4cc:	f949ec60 	ldr	x0, [x3, #5080]
    b4d0:	cb0102a1 	sub	x1, x21, x1
    b4d4:	eb00403f 	cmp	x1, x0, lsl #16
    b4d8:	54000322 	b.cs	b53c <f0+0x150c>  // b.hs, b.nlast
    b4dc:	d350fc22 	lsr	x2, x1, #16
    b4e0:	f949fc63 	ldr	x3, [x3, #5112]
    b4e4:	8b020842 	add	x2, x2, x2, lsl #2
    b4e8:	d37df042 	lsl	x2, x2, #3
    b4ec:	8b020060 	add	x0, x3, x2
    b4f0:	f9401017 	ldr	x23, [x0, #32]
    b4f4:	b4000257 	cbz	x23, b53c <f0+0x150c>
    b4f8:	38626862 	ldrb	w2, [x3, x2]
    b4fc:	7100085f 	cmp	w2, #0x2
    b500:	54006f40 	b.eq	c2e8 <f0+0x22b8>  // b.none
    b504:	7100045f 	cmp	w2, #0x1
    b508:	540001a1 	b.ne	b53c <f0+0x150c>  // b.any
    b50c:	29430002 	ldp	w2, w0, [x0, #24]
    b510:	92403c21 	and	x1, x1, #0xffff
    b514:	9b027c21 	mul	x1, x1, x2
    b518:	d360fc21 	lsr	x1, x1, #32
    b51c:	eb00003f 	cmp	x1, x0
    b520:	540000e2 	b.cs	b53c <f0+0x150c>  // b.hs, b.nlast
    b524:	8b0102f7 	add	x23, x23, x1
    b528:	394002e0 	ldrb	w0, [x23]
    b52c:	7103fc1f 	cmp	w0, #0xff
    b530:	54008500 	b.eq	c5d0 <f0+0x25a0>  // b.none
    b534:	52800020 	mov	w0, #0x1                   	// #1
    b538:	390002e0 	strb	w0, [x23]
    b53c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b540:	911523e1 	add	x1, sp, #0x548
    b544:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b548:	52800020 	mov	w0, #0x1                   	// #1
    b54c:	f902a7e2 	str	x2, [sp, #1352]
    b550:	f902abf5 	str	x21, [sp, #1360]
    b554:	97ffe764 	bl	52e4 <fwp_data.part.0.constprop.0>
    b558:	91194283 	add	x3, x20, #0x650
    b55c:	aa0003f5 	mov	x21, x0
    b560:	f949d861 	ldr	x1, [x3, #5040]
    b564:	f949ec60 	ldr	x0, [x3, #5080]
    b568:	cb0102a1 	sub	x1, x21, x1
    b56c:	eb00403f 	cmp	x1, x0, lsl #16
    b570:	54000322 	b.cs	b5d4 <f0+0x15a4>  // b.hs, b.nlast
    b574:	d350fc22 	lsr	x2, x1, #16
    b578:	f949fc63 	ldr	x3, [x3, #5112]
    b57c:	8b020842 	add	x2, x2, x2, lsl #2
    b580:	d37df042 	lsl	x2, x2, #3
    b584:	8b020060 	add	x0, x3, x2
    b588:	f9401017 	ldr	x23, [x0, #32]
    b58c:	b4000257 	cbz	x23, b5d4 <f0+0x15a4>
    b590:	38626862 	ldrb	w2, [x3, x2]
    b594:	7100085f 	cmp	w2, #0x2
    b598:	540078c0 	b.eq	c4b0 <f0+0x2480>  // b.none
    b59c:	7100045f 	cmp	w2, #0x1
    b5a0:	540001a1 	b.ne	b5d4 <f0+0x15a4>  // b.any
    b5a4:	29430002 	ldp	w2, w0, [x0, #24]
    b5a8:	92403c21 	and	x1, x1, #0xffff
    b5ac:	9b027c21 	mul	x1, x1, x2
    b5b0:	d360fc21 	lsr	x1, x1, #32
    b5b4:	eb00003f 	cmp	x1, x0
    b5b8:	540000e2 	b.cs	b5d4 <f0+0x15a4>  // b.hs, b.nlast
    b5bc:	8b0102f7 	add	x23, x23, x1
    b5c0:	394002e0 	ldrb	w0, [x23]
    b5c4:	7103fc1f 	cmp	w0, #0xff
    b5c8:	540080a0 	b.eq	c5dc <f0+0x25ac>  // b.none
    b5cc:	52800020 	mov	w0, #0x1                   	// #1
    b5d0:	390002e0 	strb	w0, [x23]
    b5d4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b5d8:	911563e1 	add	x1, sp, #0x558
    b5dc:	52800020 	mov	w0, #0x1                   	// #1
    b5e0:	f902afe2 	str	x2, [sp, #1368]
    b5e4:	f902b3f5 	str	x21, [sp, #1376]
    b5e8:	97ffe73f 	bl	52e4 <fwp_data.part.0.constprop.0>
    b5ec:	91194283 	add	x3, x20, #0x650
    b5f0:	aa0003f5 	mov	x21, x0
    b5f4:	f949d861 	ldr	x1, [x3, #5040]
    b5f8:	f949ec60 	ldr	x0, [x3, #5080]
    b5fc:	cb0102a1 	sub	x1, x21, x1
    b600:	eb00403f 	cmp	x1, x0, lsl #16
    b604:	54000322 	b.cs	b668 <f0+0x1638>  // b.hs, b.nlast
    b608:	d350fc22 	lsr	x2, x1, #16
    b60c:	f949fc63 	ldr	x3, [x3, #5112]
    b610:	8b020842 	add	x2, x2, x2, lsl #2
    b614:	d37df042 	lsl	x2, x2, #3
    b618:	8b020060 	add	x0, x3, x2
    b61c:	f9401017 	ldr	x23, [x0, #32]
    b620:	b4000257 	cbz	x23, b668 <f0+0x1638>
    b624:	38626862 	ldrb	w2, [x3, x2]
    b628:	7100085f 	cmp	w2, #0x2
    b62c:	540073c0 	b.eq	c4a4 <f0+0x2474>  // b.none
    b630:	7100045f 	cmp	w2, #0x1
    b634:	540001a1 	b.ne	b668 <f0+0x1638>  // b.any
    b638:	29430002 	ldp	w2, w0, [x0, #24]
    b63c:	92403c21 	and	x1, x1, #0xffff
    b640:	9b027c21 	mul	x1, x1, x2
    b644:	d360fc21 	lsr	x1, x1, #32
    b648:	eb00003f 	cmp	x1, x0
    b64c:	540000e2 	b.cs	b668 <f0+0x1638>  // b.hs, b.nlast
    b650:	8b0102f7 	add	x23, x23, x1
    b654:	394002e0 	ldrb	w0, [x23]
    b658:	7103fc1f 	cmp	w0, #0xff
    b65c:	54007c60 	b.eq	c5e8 <f0+0x25b8>  // b.none
    b660:	52800020 	mov	w0, #0x1                   	// #1
    b664:	390002e0 	strb	w0, [x23]
    b668:	9115a3e1 	add	x1, sp, #0x568
    b66c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b670:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b674:	52800020 	mov	w0, #0x1                   	// #1
    b678:	f902b7f7 	str	x23, [sp, #1384]
    b67c:	f902bbf5 	str	x21, [sp, #1392]
    b680:	97ffe719 	bl	52e4 <fwp_data.part.0.constprop.0>
    b684:	97ffe8cc 	bl	59b4 <fwp_rc_fresh>
    b688:	aa0003e2 	mov	x2, x0
    b68c:	9115e3e1 	add	x1, sp, #0x578
    b690:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b694:	52800020 	mov	w0, #0x1                   	// #1
    b698:	f902bff5 	str	x21, [sp, #1400]
    b69c:	f902c3e2 	str	x2, [sp, #1408]
    b6a0:	97ffe711 	bl	52e4 <fwp_data.part.0.constprop.0>
    b6a4:	97ffe8c4 	bl	59b4 <fwp_rc_fresh>
    b6a8:	aa0003e2 	mov	x2, x0
    b6ac:	911623e1 	add	x1, sp, #0x588
    b6b0:	52800020 	mov	w0, #0x1                   	// #1
    b6b4:	f902c7f7 	str	x23, [sp, #1416]
    b6b8:	f902cbe2 	str	x2, [sp, #1424]
    b6bc:	97ffe70a 	bl	52e4 <fwp_data.part.0.constprop.0>
    b6c0:	97ffe8bd 	bl	59b4 <fwp_rc_fresh>
    b6c4:	aa0003e2 	mov	x2, x0
    b6c8:	911663e1 	add	x1, sp, #0x598
    b6cc:	52800020 	mov	w0, #0x1                   	// #1
    b6d0:	f902cff5 	str	x21, [sp, #1432]
    b6d4:	f902d3e2 	str	x2, [sp, #1440]
    b6d8:	97ffe703 	bl	52e4 <fwp_data.part.0.constprop.0>
    b6dc:	91194283 	add	x3, x20, #0x650
    b6e0:	aa0003f5 	mov	x21, x0
    b6e4:	f949d861 	ldr	x1, [x3, #5040]
    b6e8:	f949ec60 	ldr	x0, [x3, #5080]
    b6ec:	cb0102a1 	sub	x1, x21, x1
    b6f0:	eb00403f 	cmp	x1, x0, lsl #16
    b6f4:	54000322 	b.cs	b758 <f0+0x1728>  // b.hs, b.nlast
    b6f8:	d350fc22 	lsr	x2, x1, #16
    b6fc:	f949fc63 	ldr	x3, [x3, #5112]
    b700:	8b020842 	add	x2, x2, x2, lsl #2
    b704:	d37df042 	lsl	x2, x2, #3
    b708:	8b020060 	add	x0, x3, x2
    b70c:	f9401017 	ldr	x23, [x0, #32]
    b710:	b4000257 	cbz	x23, b758 <f0+0x1728>
    b714:	38626862 	ldrb	w2, [x3, x2]
    b718:	7100085f 	cmp	w2, #0x2
    b71c:	54006be0 	b.eq	c498 <f0+0x2468>  // b.none
    b720:	7100045f 	cmp	w2, #0x1
    b724:	540001a1 	b.ne	b758 <f0+0x1728>  // b.any
    b728:	29430002 	ldp	w2, w0, [x0, #24]
    b72c:	92403c21 	and	x1, x1, #0xffff
    b730:	9b027c21 	mul	x1, x1, x2
    b734:	d360fc21 	lsr	x1, x1, #32
    b738:	eb00003f 	cmp	x1, x0
    b73c:	540000e2 	b.cs	b758 <f0+0x1728>  // b.hs, b.nlast
    b740:	8b0102f7 	add	x23, x23, x1
    b744:	394002e0 	ldrb	w0, [x23]
    b748:	7103fc1f 	cmp	w0, #0xff
    b74c:	54007540 	b.eq	c5f4 <f0+0x25c4>  // b.none
    b750:	52800020 	mov	w0, #0x1                   	// #1
    b754:	390002e0 	strb	w0, [x23]
    b758:	9116a3e1 	add	x1, sp, #0x5a8
    b75c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b760:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b764:	52800020 	mov	w0, #0x1                   	// #1
    b768:	f902d7f7 	str	x23, [sp, #1448]
    b76c:	f902dbf5 	str	x21, [sp, #1456]
    b770:	97ffe6dd 	bl	52e4 <fwp_data.part.0.constprop.0>
    b774:	97ffe890 	bl	59b4 <fwp_rc_fresh>
    b778:	aa0003e2 	mov	x2, x0
    b77c:	9116e3e1 	add	x1, sp, #0x5b8
    b780:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b784:	52800020 	mov	w0, #0x1                   	// #1
    b788:	f902dff5 	str	x21, [sp, #1464]
    b78c:	f902e3e2 	str	x2, [sp, #1472]
    b790:	97ffe6d5 	bl	52e4 <fwp_data.part.0.constprop.0>
    b794:	97ffe888 	bl	59b4 <fwp_rc_fresh>
    b798:	aa0003e2 	mov	x2, x0
    b79c:	911723e1 	add	x1, sp, #0x5c8
    b7a0:	52800020 	mov	w0, #0x1                   	// #1
    b7a4:	f902e7f7 	str	x23, [sp, #1480]
    b7a8:	f902ebe2 	str	x2, [sp, #1488]
    b7ac:	97ffe6ce 	bl	52e4 <fwp_data.part.0.constprop.0>
    b7b0:	97ffe881 	bl	59b4 <fwp_rc_fresh>
    b7b4:	aa0003e2 	mov	x2, x0
    b7b8:	911763e1 	add	x1, sp, #0x5d8
    b7bc:	52800020 	mov	w0, #0x1                   	// #1
    b7c0:	f902eff5 	str	x21, [sp, #1496]
    b7c4:	f902f3e2 	str	x2, [sp, #1504]
    b7c8:	97ffe6c7 	bl	52e4 <fwp_data.part.0.constprop.0>
    b7cc:	97ffe87a 	bl	59b4 <fwp_rc_fresh>
    b7d0:	aa0003e2 	mov	x2, x0
    b7d4:	9117a3e1 	add	x1, sp, #0x5e8
    b7d8:	52800020 	mov	w0, #0x1                   	// #1
    b7dc:	f902f7f7 	str	x23, [sp, #1512]
    b7e0:	f902fbe2 	str	x2, [sp, #1520]
    b7e4:	97ffe6c0 	bl	52e4 <fwp_data.part.0.constprop.0>
    b7e8:	97ffe873 	bl	59b4 <fwp_rc_fresh>
    b7ec:	aa0003e2 	mov	x2, x0
    b7f0:	9117e3e1 	add	x1, sp, #0x5f8
    b7f4:	52800020 	mov	w0, #0x1                   	// #1
    b7f8:	f902fff5 	str	x21, [sp, #1528]
    b7fc:	f90303e2 	str	x2, [sp, #1536]
    b800:	97ffe6b9 	bl	52e4 <fwp_data.part.0.constprop.0>
    b804:	97ffe86c 	bl	59b4 <fwp_rc_fresh>
    b808:	aa0003e2 	mov	x2, x0
    b80c:	911823e1 	add	x1, sp, #0x608
    b810:	52800020 	mov	w0, #0x1                   	// #1
    b814:	f90307f7 	str	x23, [sp, #1544]
    b818:	f9030be2 	str	x2, [sp, #1552]
    b81c:	97ffe6b2 	bl	52e4 <fwp_data.part.0.constprop.0>
    b820:	97ffe865 	bl	59b4 <fwp_rc_fresh>
    b824:	aa0003e2 	mov	x2, x0
    b828:	911863e1 	add	x1, sp, #0x618
    b82c:	52800020 	mov	w0, #0x1                   	// #1
    b830:	f9030ff5 	str	x21, [sp, #1560]
    b834:	f90313e2 	str	x2, [sp, #1568]
    b838:	97ffe6ab 	bl	52e4 <fwp_data.part.0.constprop.0>
    b83c:	91194283 	add	x3, x20, #0x650
    b840:	aa0003f5 	mov	x21, x0
    b844:	f949d861 	ldr	x1, [x3, #5040]
    b848:	f949ec60 	ldr	x0, [x3, #5080]
    b84c:	cb0102a1 	sub	x1, x21, x1
    b850:	eb00403f 	cmp	x1, x0, lsl #16
    b854:	54000322 	b.cs	b8b8 <f0+0x1888>  // b.hs, b.nlast
    b858:	d350fc22 	lsr	x2, x1, #16
    b85c:	f949fc63 	ldr	x3, [x3, #5112]
    b860:	8b020842 	add	x2, x2, x2, lsl #2
    b864:	d37df042 	lsl	x2, x2, #3
    b868:	8b020060 	add	x0, x3, x2
    b86c:	f9401017 	ldr	x23, [x0, #32]
    b870:	b4000257 	cbz	x23, b8b8 <f0+0x1888>
    b874:	38626862 	ldrb	w2, [x3, x2]
    b878:	7100085f 	cmp	w2, #0x2
    b87c:	54006080 	b.eq	c48c <f0+0x245c>  // b.none
    b880:	7100045f 	cmp	w2, #0x1
    b884:	540001a1 	b.ne	b8b8 <f0+0x1888>  // b.any
    b888:	29430002 	ldp	w2, w0, [x0, #24]
    b88c:	92403c21 	and	x1, x1, #0xffff
    b890:	9b027c21 	mul	x1, x1, x2
    b894:	d360fc21 	lsr	x1, x1, #32
    b898:	eb00003f 	cmp	x1, x0
    b89c:	540000e2 	b.cs	b8b8 <f0+0x1888>  // b.hs, b.nlast
    b8a0:	8b0102f7 	add	x23, x23, x1
    b8a4:	394002e0 	ldrb	w0, [x23]
    b8a8:	7103fc1f 	cmp	w0, #0xff
    b8ac:	54006aa0 	b.eq	c600 <f0+0x25d0>  // b.none
    b8b0:	52800020 	mov	w0, #0x1                   	// #1
    b8b4:	390002e0 	strb	w0, [x23]
    b8b8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b8bc:	9118a3e1 	add	x1, sp, #0x628
    b8c0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b8c4:	52800020 	mov	w0, #0x1                   	// #1
    b8c8:	f90317e2 	str	x2, [sp, #1576]
    b8cc:	f9031bf5 	str	x21, [sp, #1584]
    b8d0:	97ffe685 	bl	52e4 <fwp_data.part.0.constprop.0>
    b8d4:	97ffe838 	bl	59b4 <fwp_rc_fresh>
    b8d8:	aa0003e2 	mov	x2, x0
    b8dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b8e0:	9118e3e1 	add	x1, sp, #0x638
    b8e4:	52800020 	mov	w0, #0x1                   	// #1
    b8e8:	f9031fe3 	str	x3, [sp, #1592]
    b8ec:	f90323e2 	str	x2, [sp, #1600]
    b8f0:	97ffe67d 	bl	52e4 <fwp_data.part.0.constprop.0>
    b8f4:	91194283 	add	x3, x20, #0x650
    b8f8:	aa0003f5 	mov	x21, x0
    b8fc:	f949d861 	ldr	x1, [x3, #5040]
    b900:	f949ec60 	ldr	x0, [x3, #5080]
    b904:	cb0102a1 	sub	x1, x21, x1
    b908:	eb00403f 	cmp	x1, x0, lsl #16
    b90c:	54000322 	b.cs	b970 <f0+0x1940>  // b.hs, b.nlast
    b910:	d350fc22 	lsr	x2, x1, #16
    b914:	f949fc63 	ldr	x3, [x3, #5112]
    b918:	8b020842 	add	x2, x2, x2, lsl #2
    b91c:	d37df042 	lsl	x2, x2, #3
    b920:	8b020060 	add	x0, x3, x2
    b924:	f9401017 	ldr	x23, [x0, #32]
    b928:	b4000257 	cbz	x23, b970 <f0+0x1940>
    b92c:	38626862 	ldrb	w2, [x3, x2]
    b930:	7100085f 	cmp	w2, #0x2
    b934:	54005a60 	b.eq	c480 <f0+0x2450>  // b.none
    b938:	7100045f 	cmp	w2, #0x1
    b93c:	540001a1 	b.ne	b970 <f0+0x1940>  // b.any
    b940:	29430002 	ldp	w2, w0, [x0, #24]
    b944:	92403c21 	and	x1, x1, #0xffff
    b948:	9b027c21 	mul	x1, x1, x2
    b94c:	d360fc21 	lsr	x1, x1, #32
    b950:	eb00003f 	cmp	x1, x0
    b954:	540000e2 	b.cs	b970 <f0+0x1940>  // b.hs, b.nlast
    b958:	8b0102f7 	add	x23, x23, x1
    b95c:	394002e0 	ldrb	w0, [x23]
    b960:	7103fc1f 	cmp	w0, #0xff
    b964:	54006540 	b.eq	c60c <f0+0x25dc>  // b.none
    b968:	52800020 	mov	w0, #0x1                   	// #1
    b96c:	390002e0 	strb	w0, [x23]
    b970:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b974:	911923e1 	add	x1, sp, #0x648
    b978:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b97c:	52800020 	mov	w0, #0x1                   	// #1
    b980:	f90327e2 	str	x2, [sp, #1608]
    b984:	f9032bf5 	str	x21, [sp, #1616]
    b988:	97ffe657 	bl	52e4 <fwp_data.part.0.constprop.0>
    b98c:	91194283 	add	x3, x20, #0x650
    b990:	aa0003f5 	mov	x21, x0
    b994:	f949d861 	ldr	x1, [x3, #5040]
    b998:	f949ec60 	ldr	x0, [x3, #5080]
    b99c:	cb0102a1 	sub	x1, x21, x1
    b9a0:	eb00403f 	cmp	x1, x0, lsl #16
    b9a4:	54000322 	b.cs	ba08 <f0+0x19d8>  // b.hs, b.nlast
    b9a8:	d350fc22 	lsr	x2, x1, #16
    b9ac:	f949fc63 	ldr	x3, [x3, #5112]
    b9b0:	8b020842 	add	x2, x2, x2, lsl #2
    b9b4:	d37df042 	lsl	x2, x2, #3
    b9b8:	8b020060 	add	x0, x3, x2
    b9bc:	f9401017 	ldr	x23, [x0, #32]
    b9c0:	b4000257 	cbz	x23, ba08 <f0+0x19d8>
    b9c4:	38626862 	ldrb	w2, [x3, x2]
    b9c8:	7100085f 	cmp	w2, #0x2
    b9cc:	54005540 	b.eq	c474 <f0+0x2444>  // b.none
    b9d0:	7100045f 	cmp	w2, #0x1
    b9d4:	540001a1 	b.ne	ba08 <f0+0x19d8>  // b.any
    b9d8:	29430002 	ldp	w2, w0, [x0, #24]
    b9dc:	92403c21 	and	x1, x1, #0xffff
    b9e0:	9b027c21 	mul	x1, x1, x2
    b9e4:	d360fc21 	lsr	x1, x1, #32
    b9e8:	eb00003f 	cmp	x1, x0
    b9ec:	540000e2 	b.cs	ba08 <f0+0x19d8>  // b.hs, b.nlast
    b9f0:	8b0102f7 	add	x23, x23, x1
    b9f4:	394002e0 	ldrb	w0, [x23]
    b9f8:	7103fc1f 	cmp	w0, #0xff
    b9fc:	540060e0 	b.eq	c618 <f0+0x25e8>  // b.none
    ba00:	52800020 	mov	w0, #0x1                   	// #1
    ba04:	390002e0 	strb	w0, [x23]
    ba08:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba0c:	911963e1 	add	x1, sp, #0x658
    ba10:	52800020 	mov	w0, #0x1                   	// #1
    ba14:	f9032fe2 	str	x2, [sp, #1624]
    ba18:	f90333f5 	str	x21, [sp, #1632]
    ba1c:	97ffe632 	bl	52e4 <fwp_data.part.0.constprop.0>
    ba20:	91194283 	add	x3, x20, #0x650
    ba24:	aa0003f7 	mov	x23, x0
    ba28:	f949d861 	ldr	x1, [x3, #5040]
    ba2c:	f949ec60 	ldr	x0, [x3, #5080]
    ba30:	cb0102e1 	sub	x1, x23, x1
    ba34:	eb00403f 	cmp	x1, x0, lsl #16
    ba38:	54000322 	b.cs	ba9c <f0+0x1a6c>  // b.hs, b.nlast
    ba3c:	d350fc22 	lsr	x2, x1, #16
    ba40:	f949fc63 	ldr	x3, [x3, #5112]
    ba44:	8b020842 	add	x2, x2, x2, lsl #2
    ba48:	d37df042 	lsl	x2, x2, #3
    ba4c:	8b020060 	add	x0, x3, x2
    ba50:	f9401015 	ldr	x21, [x0, #32]
    ba54:	b4000255 	cbz	x21, ba9c <f0+0x1a6c>
    ba58:	38626862 	ldrb	w2, [x3, x2]
    ba5c:	7100085f 	cmp	w2, #0x2
    ba60:	54005040 	b.eq	c468 <f0+0x2438>  // b.none
    ba64:	7100045f 	cmp	w2, #0x1
    ba68:	540001a1 	b.ne	ba9c <f0+0x1a6c>  // b.any
    ba6c:	29430002 	ldp	w2, w0, [x0, #24]
    ba70:	92403c21 	and	x1, x1, #0xffff
    ba74:	9b027c21 	mul	x1, x1, x2
    ba78:	d360fc21 	lsr	x1, x1, #32
    ba7c:	eb00003f 	cmp	x1, x0
    ba80:	540000e2 	b.cs	ba9c <f0+0x1a6c>  // b.hs, b.nlast
    ba84:	8b0102b5 	add	x21, x21, x1
    ba88:	394002a0 	ldrb	w0, [x21]
    ba8c:	7103fc1f 	cmp	w0, #0xff
    ba90:	54005ca0 	b.eq	c624 <f0+0x25f4>  // b.none
    ba94:	52800020 	mov	w0, #0x1                   	// #1
    ba98:	390002a0 	strb	w0, [x21]
    ba9c:	9119a3e1 	add	x1, sp, #0x668
    baa0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    baa4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    baa8:	52800020 	mov	w0, #0x1                   	// #1
    baac:	f90337f5 	str	x21, [sp, #1640]
    bab0:	f9033bf7 	str	x23, [sp, #1648]
    bab4:	97ffe60c 	bl	52e4 <fwp_data.part.0.constprop.0>
    bab8:	97ffe7bf 	bl	59b4 <fwp_rc_fresh>
    babc:	aa0003e2 	mov	x2, x0
    bac0:	9119e3e1 	add	x1, sp, #0x678
    bac4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bac8:	52800020 	mov	w0, #0x1                   	// #1
    bacc:	f9033ff7 	str	x23, [sp, #1656]
    bad0:	f90343e2 	str	x2, [sp, #1664]
    bad4:	97ffe604 	bl	52e4 <fwp_data.part.0.constprop.0>
    bad8:	97ffe7b7 	bl	59b4 <fwp_rc_fresh>
    badc:	aa0003e2 	mov	x2, x0
    bae0:	911a23e1 	add	x1, sp, #0x688
    bae4:	52800020 	mov	w0, #0x1                   	// #1
    bae8:	f90347f5 	str	x21, [sp, #1672]
    baec:	f9034be2 	str	x2, [sp, #1680]
    baf0:	97ffe5fd 	bl	52e4 <fwp_data.part.0.constprop.0>
    baf4:	97ffe7b0 	bl	59b4 <fwp_rc_fresh>
    baf8:	aa0003e2 	mov	x2, x0
    bafc:	911a63e1 	add	x1, sp, #0x698
    bb00:	52800020 	mov	w0, #0x1                   	// #1
    bb04:	f9034ff7 	str	x23, [sp, #1688]
    bb08:	f90353e2 	str	x2, [sp, #1696]
    bb0c:	97ffe5f6 	bl	52e4 <fwp_data.part.0.constprop.0>
    bb10:	97ffe7a9 	bl	59b4 <fwp_rc_fresh>
    bb14:	aa0003e2 	mov	x2, x0
    bb18:	911aa3e1 	add	x1, sp, #0x6a8
    bb1c:	52800020 	mov	w0, #0x1                   	// #1
    bb20:	f90357f5 	str	x21, [sp, #1704]
    bb24:	f9035be2 	str	x2, [sp, #1712]
    bb28:	97ffe5ef 	bl	52e4 <fwp_data.part.0.constprop.0>
    bb2c:	97ffe7a2 	bl	59b4 <fwp_rc_fresh>
    bb30:	aa0003e2 	mov	x2, x0
    bb34:	911ae3e1 	add	x1, sp, #0x6b8
    bb38:	52800020 	mov	w0, #0x1                   	// #1
    bb3c:	f9035ff7 	str	x23, [sp, #1720]
    bb40:	f90363e2 	str	x2, [sp, #1728]
    bb44:	97ffe5e8 	bl	52e4 <fwp_data.part.0.constprop.0>
    bb48:	97ffe79b 	bl	59b4 <fwp_rc_fresh>
    bb4c:	aa0003e2 	mov	x2, x0
    bb50:	911b23e1 	add	x1, sp, #0x6c8
    bb54:	52800020 	mov	w0, #0x1                   	// #1
    bb58:	f90367f5 	str	x21, [sp, #1736]
    bb5c:	f9036be2 	str	x2, [sp, #1744]
    bb60:	97ffe5e1 	bl	52e4 <fwp_data.part.0.constprop.0>
    bb64:	91194283 	add	x3, x20, #0x650
    bb68:	aa0003f5 	mov	x21, x0
    bb6c:	f949d861 	ldr	x1, [x3, #5040]
    bb70:	f949ec60 	ldr	x0, [x3, #5080]
    bb74:	cb0102a1 	sub	x1, x21, x1
    bb78:	eb00403f 	cmp	x1, x0, lsl #16
    bb7c:	54000322 	b.cs	bbe0 <f0+0x1bb0>  // b.hs, b.nlast
    bb80:	d350fc22 	lsr	x2, x1, #16
    bb84:	f949fc63 	ldr	x3, [x3, #5112]
    bb88:	8b020842 	add	x2, x2, x2, lsl #2
    bb8c:	d37df042 	lsl	x2, x2, #3
    bb90:	8b020060 	add	x0, x3, x2
    bb94:	f9401017 	ldr	x23, [x0, #32]
    bb98:	b4000257 	cbz	x23, bbe0 <f0+0x1bb0>
    bb9c:	38626862 	ldrb	w2, [x3, x2]
    bba0:	7100085f 	cmp	w2, #0x2
    bba4:	540045c0 	b.eq	c45c <f0+0x242c>  // b.none
    bba8:	7100045f 	cmp	w2, #0x1
    bbac:	540001a1 	b.ne	bbe0 <f0+0x1bb0>  // b.any
    bbb0:	29430002 	ldp	w2, w0, [x0, #24]
    bbb4:	92403c21 	and	x1, x1, #0xffff
    bbb8:	9b027c21 	mul	x1, x1, x2
    bbbc:	d360fc21 	lsr	x1, x1, #32
    bbc0:	eb00003f 	cmp	x1, x0
    bbc4:	540000e2 	b.cs	bbe0 <f0+0x1bb0>  // b.hs, b.nlast
    bbc8:	8b0102f7 	add	x23, x23, x1
    bbcc:	394002e0 	ldrb	w0, [x23]
    bbd0:	7103fc1f 	cmp	w0, #0xff
    bbd4:	540052e0 	b.eq	c630 <f0+0x2600>  // b.none
    bbd8:	52800020 	mov	w0, #0x1                   	// #1
    bbdc:	390002e0 	strb	w0, [x23]
    bbe0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bbe4:	911b63e1 	add	x1, sp, #0x6d8
    bbe8:	52800020 	mov	w0, #0x1                   	// #1
    bbec:	f9036fe2 	str	x2, [sp, #1752]
    bbf0:	f90373f5 	str	x21, [sp, #1760]
    bbf4:	97ffe5bc 	bl	52e4 <fwp_data.part.0.constprop.0>
    bbf8:	91194283 	add	x3, x20, #0x650
    bbfc:	aa0003f5 	mov	x21, x0
    bc00:	f949d861 	ldr	x1, [x3, #5040]
    bc04:	f949ec60 	ldr	x0, [x3, #5080]
    bc08:	cb0102a1 	sub	x1, x21, x1
    bc0c:	eb00403f 	cmp	x1, x0, lsl #16
    bc10:	54000322 	b.cs	bc74 <f0+0x1c44>  // b.hs, b.nlast
    bc14:	d350fc22 	lsr	x2, x1, #16
    bc18:	f949fc63 	ldr	x3, [x3, #5112]
    bc1c:	8b020842 	add	x2, x2, x2, lsl #2
    bc20:	d37df042 	lsl	x2, x2, #3
    bc24:	8b020060 	add	x0, x3, x2
    bc28:	f9401017 	ldr	x23, [x0, #32]
    bc2c:	b4000257 	cbz	x23, bc74 <f0+0x1c44>
    bc30:	38626862 	ldrb	w2, [x3, x2]
    bc34:	7100085f 	cmp	w2, #0x2
    bc38:	540040c0 	b.eq	c450 <f0+0x2420>  // b.none
    bc3c:	7100045f 	cmp	w2, #0x1
    bc40:	540001a1 	b.ne	bc74 <f0+0x1c44>  // b.any
    bc44:	29430002 	ldp	w2, w0, [x0, #24]
    bc48:	92403c21 	and	x1, x1, #0xffff
    bc4c:	9b027c21 	mul	x1, x1, x2
    bc50:	d360fc21 	lsr	x1, x1, #32
    bc54:	eb00003f 	cmp	x1, x0
    bc58:	540000e2 	b.cs	bc74 <f0+0x1c44>  // b.hs, b.nlast
    bc5c:	8b0102f7 	add	x23, x23, x1
    bc60:	394002e0 	ldrb	w0, [x23]
    bc64:	7103fc1f 	cmp	w0, #0xff
    bc68:	54004ea0 	b.eq	c63c <f0+0x260c>  // b.none
    bc6c:	52800020 	mov	w0, #0x1                   	// #1
    bc70:	390002e0 	strb	w0, [x23]
    bc74:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bc78:	911ba3e1 	add	x1, sp, #0x6e8
    bc7c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bc80:	52800020 	mov	w0, #0x1                   	// #1
    bc84:	f90377e2 	str	x2, [sp, #1768]
    bc88:	f9037bf5 	str	x21, [sp, #1776]
    bc8c:	97ffe596 	bl	52e4 <fwp_data.part.0.constprop.0>
    bc90:	97ffe749 	bl	59b4 <fwp_rc_fresh>
    bc94:	aa0003e2 	mov	x2, x0
    bc98:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bc9c:	911be3e1 	add	x1, sp, #0x6f8
    bca0:	52800020 	mov	w0, #0x1                   	// #1
    bca4:	f9037fe3 	str	x3, [sp, #1784]
    bca8:	f90383e2 	str	x2, [sp, #1792]
    bcac:	97ffe58e 	bl	52e4 <fwp_data.part.0.constprop.0>
    bcb0:	91194283 	add	x3, x20, #0x650
    bcb4:	aa0003f5 	mov	x21, x0
    bcb8:	f949d861 	ldr	x1, [x3, #5040]
    bcbc:	f949ec60 	ldr	x0, [x3, #5080]
    bcc0:	cb0102a1 	sub	x1, x21, x1
    bcc4:	eb00403f 	cmp	x1, x0, lsl #16
    bcc8:	54000322 	b.cs	bd2c <f0+0x1cfc>  // b.hs, b.nlast
    bccc:	d350fc22 	lsr	x2, x1, #16
    bcd0:	f949fc63 	ldr	x3, [x3, #5112]
    bcd4:	8b020842 	add	x2, x2, x2, lsl #2
    bcd8:	d37df042 	lsl	x2, x2, #3
    bcdc:	8b020060 	add	x0, x3, x2
    bce0:	f9401017 	ldr	x23, [x0, #32]
    bce4:	b4000257 	cbz	x23, bd2c <f0+0x1cfc>
    bce8:	38626862 	ldrb	w2, [x3, x2]
    bcec:	7100085f 	cmp	w2, #0x2
    bcf0:	54003aa0 	b.eq	c444 <f0+0x2414>  // b.none
    bcf4:	7100045f 	cmp	w2, #0x1
    bcf8:	540001a1 	b.ne	bd2c <f0+0x1cfc>  // b.any
    bcfc:	29430002 	ldp	w2, w0, [x0, #24]
    bd00:	92403c21 	and	x1, x1, #0xffff
    bd04:	9b027c21 	mul	x1, x1, x2
    bd08:	d360fc21 	lsr	x1, x1, #32
    bd0c:	eb00003f 	cmp	x1, x0
    bd10:	540000e2 	b.cs	bd2c <f0+0x1cfc>  // b.hs, b.nlast
    bd14:	8b0102f7 	add	x23, x23, x1
    bd18:	394002e0 	ldrb	w0, [x23]
    bd1c:	7103fc1f 	cmp	w0, #0xff
    bd20:	54004940 	b.eq	c648 <f0+0x2618>  // b.none
    bd24:	52800020 	mov	w0, #0x1                   	// #1
    bd28:	390002e0 	strb	w0, [x23]
    bd2c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bd30:	911c23e1 	add	x1, sp, #0x708
    bd34:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bd38:	52800020 	mov	w0, #0x1                   	// #1
    bd3c:	f90387e2 	str	x2, [sp, #1800]
    bd40:	f9038bf5 	str	x21, [sp, #1808]
    bd44:	97ffe568 	bl	52e4 <fwp_data.part.0.constprop.0>
    bd48:	97ffe71b 	bl	59b4 <fwp_rc_fresh>
    bd4c:	aa0003e2 	mov	x2, x0
    bd50:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bd54:	911c63e1 	add	x1, sp, #0x718
    bd58:	52800020 	mov	w0, #0x1                   	// #1
    bd5c:	f9038fe3 	str	x3, [sp, #1816]
    bd60:	f90393e2 	str	x2, [sp, #1824]
    bd64:	97ffe560 	bl	52e4 <fwp_data.part.0.constprop.0>
    bd68:	91194283 	add	x3, x20, #0x650
    bd6c:	aa0003f5 	mov	x21, x0
    bd70:	f949d861 	ldr	x1, [x3, #5040]
    bd74:	f949ec60 	ldr	x0, [x3, #5080]
    bd78:	cb0102a1 	sub	x1, x21, x1
    bd7c:	eb00403f 	cmp	x1, x0, lsl #16
    bd80:	54000322 	b.cs	bde4 <f0+0x1db4>  // b.hs, b.nlast
    bd84:	d350fc22 	lsr	x2, x1, #16
    bd88:	f949fc63 	ldr	x3, [x3, #5112]
    bd8c:	8b020842 	add	x2, x2, x2, lsl #2
    bd90:	d37df042 	lsl	x2, x2, #3
    bd94:	8b020060 	add	x0, x3, x2
    bd98:	f9401017 	ldr	x23, [x0, #32]
    bd9c:	b4000257 	cbz	x23, bde4 <f0+0x1db4>
    bda0:	38626862 	ldrb	w2, [x3, x2]
    bda4:	7100085f 	cmp	w2, #0x2
    bda8:	54003480 	b.eq	c438 <f0+0x2408>  // b.none
    bdac:	7100045f 	cmp	w2, #0x1
    bdb0:	540001a1 	b.ne	bde4 <f0+0x1db4>  // b.any
    bdb4:	29430002 	ldp	w2, w0, [x0, #24]
    bdb8:	92403c21 	and	x1, x1, #0xffff
    bdbc:	9b027c21 	mul	x1, x1, x2
    bdc0:	d360fc21 	lsr	x1, x1, #32
    bdc4:	eb00003f 	cmp	x1, x0
    bdc8:	540000e2 	b.cs	bde4 <f0+0x1db4>  // b.hs, b.nlast
    bdcc:	8b0102f7 	add	x23, x23, x1
    bdd0:	394002e0 	ldrb	w0, [x23]
    bdd4:	7103fc1f 	cmp	w0, #0xff
    bdd8:	540043e0 	b.eq	c654 <f0+0x2624>  // b.none
    bddc:	52800020 	mov	w0, #0x1                   	// #1
    bde0:	390002e0 	strb	w0, [x23]
    bde4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bde8:	911ca3e1 	add	x1, sp, #0x728
    bdec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bdf0:	52800020 	mov	w0, #0x1                   	// #1
    bdf4:	f90397e2 	str	x2, [sp, #1832]
    bdf8:	f9039bf5 	str	x21, [sp, #1840]
    bdfc:	97ffe53a 	bl	52e4 <fwp_data.part.0.constprop.0>
    be00:	97ffe6ed 	bl	59b4 <fwp_rc_fresh>
    be04:	aa0003e2 	mov	x2, x0
    be08:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    be0c:	911ce3e1 	add	x1, sp, #0x738
    be10:	52800020 	mov	w0, #0x1                   	// #1
    be14:	f9039fe3 	str	x3, [sp, #1848]
    be18:	f903a3e2 	str	x2, [sp, #1856]
    be1c:	97ffe532 	bl	52e4 <fwp_data.part.0.constprop.0>
    be20:	91194283 	add	x3, x20, #0x650
    be24:	aa0003f5 	mov	x21, x0
    be28:	f949d861 	ldr	x1, [x3, #5040]
    be2c:	f949ec60 	ldr	x0, [x3, #5080]
    be30:	cb0102a1 	sub	x1, x21, x1
    be34:	eb00403f 	cmp	x1, x0, lsl #16
    be38:	54000322 	b.cs	be9c <f0+0x1e6c>  // b.hs, b.nlast
    be3c:	d350fc22 	lsr	x2, x1, #16
    be40:	f949fc63 	ldr	x3, [x3, #5112]
    be44:	8b020842 	add	x2, x2, x2, lsl #2
    be48:	d37df042 	lsl	x2, x2, #3
    be4c:	8b020060 	add	x0, x3, x2
    be50:	f9401017 	ldr	x23, [x0, #32]
    be54:	b4000257 	cbz	x23, be9c <f0+0x1e6c>
    be58:	38626862 	ldrb	w2, [x3, x2]
    be5c:	7100085f 	cmp	w2, #0x2
    be60:	54002e60 	b.eq	c42c <f0+0x23fc>  // b.none
    be64:	7100045f 	cmp	w2, #0x1
    be68:	540001a1 	b.ne	be9c <f0+0x1e6c>  // b.any
    be6c:	29430002 	ldp	w2, w0, [x0, #24]
    be70:	92403c21 	and	x1, x1, #0xffff
    be74:	9b027c21 	mul	x1, x1, x2
    be78:	d360fc21 	lsr	x1, x1, #32
    be7c:	eb00003f 	cmp	x1, x0
    be80:	540000e2 	b.cs	be9c <f0+0x1e6c>  // b.hs, b.nlast
    be84:	8b0102f7 	add	x23, x23, x1
    be88:	394002e0 	ldrb	w0, [x23]
    be8c:	7103fc1f 	cmp	w0, #0xff
    be90:	54003e80 	b.eq	c660 <f0+0x2630>  // b.none
    be94:	52800020 	mov	w0, #0x1                   	// #1
    be98:	390002e0 	strb	w0, [x23]
    be9c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bea0:	911d23e1 	add	x1, sp, #0x748
    bea4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bea8:	52800020 	mov	w0, #0x1                   	// #1
    beac:	f903a7e2 	str	x2, [sp, #1864]
    beb0:	f903abf5 	str	x21, [sp, #1872]
    beb4:	97ffe50c 	bl	52e4 <fwp_data.part.0.constprop.0>
    beb8:	91194283 	add	x3, x20, #0x650
    bebc:	aa0003f7 	mov	x23, x0
    bec0:	f949d861 	ldr	x1, [x3, #5040]
    bec4:	f949ec60 	ldr	x0, [x3, #5080]
    bec8:	cb0102e1 	sub	x1, x23, x1
    becc:	eb00403f 	cmp	x1, x0, lsl #16
    bed0:	54000322 	b.cs	bf34 <f0+0x1f04>  // b.hs, b.nlast
    bed4:	d350fc22 	lsr	x2, x1, #16
    bed8:	f949fc63 	ldr	x3, [x3, #5112]
    bedc:	8b020842 	add	x2, x2, x2, lsl #2
    bee0:	d37df042 	lsl	x2, x2, #3
    bee4:	8b020060 	add	x0, x3, x2
    bee8:	f9401015 	ldr	x21, [x0, #32]
    beec:	b4000255 	cbz	x21, bf34 <f0+0x1f04>
    bef0:	38626862 	ldrb	w2, [x3, x2]
    bef4:	7100085f 	cmp	w2, #0x2
    bef8:	54002940 	b.eq	c420 <f0+0x23f0>  // b.none
    befc:	7100045f 	cmp	w2, #0x1
    bf00:	540001a1 	b.ne	bf34 <f0+0x1f04>  // b.any
    bf04:	29430002 	ldp	w2, w0, [x0, #24]
    bf08:	92403c21 	and	x1, x1, #0xffff
    bf0c:	9b027c21 	mul	x1, x1, x2
    bf10:	d360fc21 	lsr	x1, x1, #32
    bf14:	eb00003f 	cmp	x1, x0
    bf18:	540000e2 	b.cs	bf34 <f0+0x1f04>  // b.hs, b.nlast
    bf1c:	8b0102b5 	add	x21, x21, x1
    bf20:	394002a0 	ldrb	w0, [x21]
    bf24:	7103fc1f 	cmp	w0, #0xff
    bf28:	54003a20 	b.eq	c66c <f0+0x263c>  // b.none
    bf2c:	52800020 	mov	w0, #0x1                   	// #1
    bf30:	390002a0 	strb	w0, [x21]
    bf34:	911d63e1 	add	x1, sp, #0x758
    bf38:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bf3c:	52800020 	mov	w0, #0x1                   	// #1
    bf40:	f903aff5 	str	x21, [sp, #1880]
    bf44:	f903b3f7 	str	x23, [sp, #1888]
    bf48:	97ffe4e7 	bl	52e4 <fwp_data.part.0.constprop.0>
    bf4c:	97ffe69a 	bl	59b4 <fwp_rc_fresh>
    bf50:	aa0003e2 	mov	x2, x0
    bf54:	911da3e1 	add	x1, sp, #0x768
    bf58:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bf5c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bf60:	52800020 	mov	w0, #0x1                   	// #1
    bf64:	f903b7f7 	str	x23, [sp, #1896]
    bf68:	f903bbe2 	str	x2, [sp, #1904]
    bf6c:	97ffe4de 	bl	52e4 <fwp_data.part.0.constprop.0>
    bf70:	97ffe691 	bl	59b4 <fwp_rc_fresh>
    bf74:	aa0003e2 	mov	x2, x0
    bf78:	911de3e1 	add	x1, sp, #0x778
    bf7c:	52800020 	mov	w0, #0x1                   	// #1
    bf80:	f903bff5 	str	x21, [sp, #1912]
    bf84:	f903c3e2 	str	x2, [sp, #1920]
    bf88:	97ffe4d7 	bl	52e4 <fwp_data.part.0.constprop.0>
    bf8c:	97ffe68a 	bl	59b4 <fwp_rc_fresh>
    bf90:	aa0003e2 	mov	x2, x0
    bf94:	911e23e1 	add	x1, sp, #0x788
    bf98:	52800020 	mov	w0, #0x1                   	// #1
    bf9c:	f903c7f7 	str	x23, [sp, #1928]
    bfa0:	f903cbe2 	str	x2, [sp, #1936]
    bfa4:	97ffe4d0 	bl	52e4 <fwp_data.part.0.constprop.0>
    bfa8:	97ffe683 	bl	59b4 <fwp_rc_fresh>
    bfac:	aa0003e2 	mov	x2, x0
    bfb0:	911e63e1 	add	x1, sp, #0x798
    bfb4:	52800020 	mov	w0, #0x1                   	// #1
    bfb8:	f903cff5 	str	x21, [sp, #1944]
    bfbc:	f903d3e2 	str	x2, [sp, #1952]
    bfc0:	97ffe4c9 	bl	52e4 <fwp_data.part.0.constprop.0>
    bfc4:	97ffe67c 	bl	59b4 <fwp_rc_fresh>
    bfc8:	aa0003e2 	mov	x2, x0
    bfcc:	911ea3e1 	add	x1, sp, #0x7a8
    bfd0:	52800020 	mov	w0, #0x1                   	// #1
    bfd4:	f903d7f7 	str	x23, [sp, #1960]
    bfd8:	f903dbe2 	str	x2, [sp, #1968]
    bfdc:	97ffe4c2 	bl	52e4 <fwp_data.part.0.constprop.0>
    bfe0:	97ffe675 	bl	59b4 <fwp_rc_fresh>
    bfe4:	aa0003e2 	mov	x2, x0
    bfe8:	911ee3e1 	add	x1, sp, #0x7b8
    bfec:	52800020 	mov	w0, #0x1                   	// #1
    bff0:	f903dff5 	str	x21, [sp, #1976]
    bff4:	f903e3e2 	str	x2, [sp, #1984]
    bff8:	97ffe4bb 	bl	52e4 <fwp_data.part.0.constprop.0>
    bffc:	97ffe66e 	bl	59b4 <fwp_rc_fresh>
    c000:	aa0003e2 	mov	x2, x0
    c004:	911f23e1 	add	x1, sp, #0x7c8
    c008:	52800020 	mov	w0, #0x1                   	// #1
    c00c:	f903e7f7 	str	x23, [sp, #1992]
    c010:	f903ebe2 	str	x2, [sp, #2000]
    c014:	97ffe4b4 	bl	52e4 <fwp_data.part.0.constprop.0>
    c018:	97ffe667 	bl	59b4 <fwp_rc_fresh>
    c01c:	aa0003e2 	mov	x2, x0
    c020:	911f63e1 	add	x1, sp, #0x7d8
    c024:	52800020 	mov	w0, #0x1                   	// #1
    c028:	f903eff5 	str	x21, [sp, #2008]
    c02c:	f903f3e2 	str	x2, [sp, #2016]
    c030:	97ffe4ad 	bl	52e4 <fwp_data.part.0.constprop.0>
    c034:	97ffe660 	bl	59b4 <fwp_rc_fresh>
    c038:	aa0003e2 	mov	x2, x0
    c03c:	911fa3e1 	add	x1, sp, #0x7e8
    c040:	52800020 	mov	w0, #0x1                   	// #1
    c044:	f903f7f7 	str	x23, [sp, #2024]
    c048:	f903fbe2 	str	x2, [sp, #2032]
    c04c:	97ffe4a6 	bl	52e4 <fwp_data.part.0.constprop.0>
    c050:	97ffe659 	bl	59b4 <fwp_rc_fresh>
    c054:	aa0003e2 	mov	x2, x0
    c058:	911fe3e1 	add	x1, sp, #0x7f8
    c05c:	52800020 	mov	w0, #0x1                   	// #1
    c060:	f903fff5 	str	x21, [sp, #2040]
    c064:	f90403e2 	str	x2, [sp, #2048]
    c068:	97ffe49f 	bl	52e4 <fwp_data.part.0.constprop.0>
    c06c:	97ffe652 	bl	59b4 <fwp_rc_fresh>
    c070:	aa0003e2 	mov	x2, x0
    c074:	912023e1 	add	x1, sp, #0x808
    c078:	52800020 	mov	w0, #0x1                   	// #1
    c07c:	f90407f7 	str	x23, [sp, #2056]
    c080:	f9040be2 	str	x2, [sp, #2064]
    c084:	97ffe498 	bl	52e4 <fwp_data.part.0.constprop.0>
    c088:	97ffe64b 	bl	59b4 <fwp_rc_fresh>
    c08c:	aa0003e2 	mov	x2, x0
    c090:	912063e1 	add	x1, sp, #0x818
    c094:	52800020 	mov	w0, #0x1                   	// #1
    c098:	f9040ff5 	str	x21, [sp, #2072]
    c09c:	f90413e2 	str	x2, [sp, #2080]
    c0a0:	97ffe491 	bl	52e4 <fwp_data.part.0.constprop.0>
    c0a4:	91194283 	add	x3, x20, #0x650
    c0a8:	aa0003f5 	mov	x21, x0
    c0ac:	f949d861 	ldr	x1, [x3, #5040]
    c0b0:	f949ec60 	ldr	x0, [x3, #5080]
    c0b4:	cb0102a1 	sub	x1, x21, x1
    c0b8:	eb00403f 	cmp	x1, x0, lsl #16
    c0bc:	54000322 	b.cs	c120 <f0+0x20f0>  // b.hs, b.nlast
    c0c0:	d350fc22 	lsr	x2, x1, #16
    c0c4:	f949fc63 	ldr	x3, [x3, #5112]
    c0c8:	8b020842 	add	x2, x2, x2, lsl #2
    c0cc:	d37df042 	lsl	x2, x2, #3
    c0d0:	8b020060 	add	x0, x3, x2
    c0d4:	f9401017 	ldr	x23, [x0, #32]
    c0d8:	b4000257 	cbz	x23, c120 <f0+0x20f0>
    c0dc:	38626862 	ldrb	w2, [x3, x2]
    c0e0:	7100085f 	cmp	w2, #0x2
    c0e4:	54001980 	b.eq	c414 <f0+0x23e4>  // b.none
    c0e8:	7100045f 	cmp	w2, #0x1
    c0ec:	540001a1 	b.ne	c120 <f0+0x20f0>  // b.any
    c0f0:	29430002 	ldp	w2, w0, [x0, #24]
    c0f4:	92403c21 	and	x1, x1, #0xffff
    c0f8:	9b027c21 	mul	x1, x1, x2
    c0fc:	d360fc21 	lsr	x1, x1, #32
    c100:	eb00003f 	cmp	x1, x0
    c104:	540000e2 	b.cs	c120 <f0+0x20f0>  // b.hs, b.nlast
    c108:	8b0102f7 	add	x23, x23, x1
    c10c:	394002e0 	ldrb	w0, [x23]
    c110:	7103fc1f 	cmp	w0, #0xff
    c114:	54002b20 	b.eq	c678 <f0+0x2648>  // b.none
    c118:	52800020 	mov	w0, #0x1                   	// #1
    c11c:	390002e0 	strb	w0, [x23]
    c120:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c124:	9120a3e1 	add	x1, sp, #0x828
    c128:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c12c:	52800020 	mov	w0, #0x1                   	// #1
    c130:	f90417e2 	str	x2, [sp, #2088]
    c134:	f9041bf5 	str	x21, [sp, #2096]
    c138:	97ffe46b 	bl	52e4 <fwp_data.part.0.constprop.0>
    c13c:	91194283 	add	x3, x20, #0x650
    c140:	aa0003f5 	mov	x21, x0
    c144:	f949d861 	ldr	x1, [x3, #5040]
    c148:	f949ec60 	ldr	x0, [x3, #5080]
    c14c:	cb0102a1 	sub	x1, x21, x1
    c150:	eb00403f 	cmp	x1, x0, lsl #16
    c154:	54000322 	b.cs	c1b8 <f0+0x2188>  // b.hs, b.nlast
    c158:	d350fc22 	lsr	x2, x1, #16
    c15c:	f949fc63 	ldr	x3, [x3, #5112]
    c160:	8b020842 	add	x2, x2, x2, lsl #2
    c164:	d37df042 	lsl	x2, x2, #3
    c168:	8b020060 	add	x0, x3, x2
    c16c:	f9401017 	ldr	x23, [x0, #32]
    c170:	b4000257 	cbz	x23, c1b8 <f0+0x2188>
    c174:	38626862 	ldrb	w2, [x3, x2]
    c178:	7100085f 	cmp	w2, #0x2
    c17c:	54001460 	b.eq	c408 <f0+0x23d8>  // b.none
    c180:	7100045f 	cmp	w2, #0x1
    c184:	540001a1 	b.ne	c1b8 <f0+0x2188>  // b.any
    c188:	29430002 	ldp	w2, w0, [x0, #24]
    c18c:	92403c21 	and	x1, x1, #0xffff
    c190:	9b027c21 	mul	x1, x1, x2
    c194:	d360fc21 	lsr	x1, x1, #32
    c198:	eb00003f 	cmp	x1, x0
    c19c:	540000e2 	b.cs	c1b8 <f0+0x2188>  // b.hs, b.nlast
    c1a0:	8b0102f7 	add	x23, x23, x1
    c1a4:	394002e0 	ldrb	w0, [x23]
    c1a8:	7103fc1f 	cmp	w0, #0xff
    c1ac:	540026c0 	b.eq	c684 <f0+0x2654>  // b.none
    c1b0:	52800020 	mov	w0, #0x1                   	// #1
    c1b4:	390002e0 	strb	w0, [x23]
    c1b8:	9120e3e1 	add	x1, sp, #0x838
    c1bc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c1c0:	52800020 	mov	w0, #0x1                   	// #1
    c1c4:	f9041fe2 	str	x2, [sp, #2104]
    c1c8:	f90423f5 	str	x21, [sp, #2112]
    c1cc:	97ffe446 	bl	52e4 <fwp_data.part.0.constprop.0>
    c1d0:	97ffe5f9 	bl	59b4 <fwp_rc_fresh>
    c1d4:	aa0003e2 	mov	x2, x0
    c1d8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c1dc:	91194294 	add	x20, x20, #0x650
    c1e0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c1e4:	aa1603e1 	mov	x1, x22
    c1e8:	52800020 	mov	w0, #0x1                   	// #1
    c1ec:	f90427e3 	str	x3, [sp, #2120]
    c1f0:	f9042be2 	str	x2, [sp, #2128]
    c1f4:	97ffe43c 	bl	52e4 <fwp_data.part.0.constprop.0>
    c1f8:	f949da81 	ldr	x1, [x20, #5040]
    c1fc:	aa0003f5 	mov	x21, x0
    c200:	f949ee80 	ldr	x0, [x20, #5080]
    c204:	cb0102a1 	sub	x1, x21, x1
    c208:	eb00403f 	cmp	x1, x0, lsl #16
    c20c:	54000322 	b.cs	c270 <f0+0x2240>  // b.hs, b.nlast
    c210:	d350fc22 	lsr	x2, x1, #16
    c214:	f949fe83 	ldr	x3, [x20, #5112]
    c218:	8b020842 	add	x2, x2, x2, lsl #2
    c21c:	d37df042 	lsl	x2, x2, #3
    c220:	8b020060 	add	x0, x3, x2
    c224:	f9401014 	ldr	x20, [x0, #32]
    c228:	b4000254 	cbz	x20, c270 <f0+0x2240>
    c22c:	38626862 	ldrb	w2, [x3, x2]
    c230:	7100085f 	cmp	w2, #0x2
    c234:	54000e40 	b.eq	c3fc <f0+0x23cc>  // b.none
    c238:	7100045f 	cmp	w2, #0x1
    c23c:	540001a1 	b.ne	c270 <f0+0x2240>  // b.any
    c240:	29430002 	ldp	w2, w0, [x0, #24]
    c244:	92403c21 	and	x1, x1, #0xffff
    c248:	9b027c21 	mul	x1, x1, x2
    c24c:	d360fc21 	lsr	x1, x1, #32
    c250:	eb00003f 	cmp	x1, x0
    c254:	540000e2 	b.cs	c270 <f0+0x2240>  // b.hs, b.nlast
    c258:	8b010294 	add	x20, x20, x1
    c25c:	39400280 	ldrb	w0, [x20]
    c260:	7103fc1f 	cmp	w0, #0xff
    c264:	540012c0 	b.eq	c4bc <f0+0x248c>  // b.none
    c268:	52800020 	mov	w0, #0x1                   	// #1
    c26c:	39000280 	strb	w0, [x20]
    c270:	aa1303e1 	mov	x1, x19
    c274:	aa1503e0 	mov	x0, x21
    c278:	97fff08a 	bl	84a0 <fwp_hof0.constprop.0>
    c27c:	aa0003f4 	mov	x20, x0
    c280:	aa1503e0 	mov	x0, x21
    c284:	97ffe72f 	bl	5f40 <fwp_drop0>
    c288:	aa1303e0 	mov	x0, x19
    c28c:	97ffe72d 	bl	5f40 <fwp_drop0>
    c290:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    c294:	f947f400 	ldr	x0, [x0, #4072]
    c298:	f9442fe2 	ldr	x2, [sp, #2136]
    c29c:	f9400001 	ldr	x1, [x0]
    c2a0:	eb010042 	subs	x2, x2, x1
    c2a4:	d2800001 	mov	x1, #0x0                   	// #0
    c2a8:	54001f41 	b.ne	c690 <f0+0x2660>  // b.any
    c2ac:	912183ff 	add	sp, sp, #0x860
    c2b0:	aa1403e0 	mov	x0, x20
    c2b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    c2b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c2bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    c2c0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c2c4:	a94573fb 	ldp	x27, x28, [sp, #80]
    c2c8:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c2cc:	d65f03c0 	ret
    c2d0:	aa1b03e0 	mov	x0, x27
    c2d4:	97ffe1e3 	bl	4a60 <fwp_rc_forget_slot>
    c2d8:	17fff79e 	b	a150 <f0+0x120>
    c2dc:	72003c5f 	tst	w2, #0xffff
    c2e0:	54fef3a1 	b.ne	a154 <f0+0x124>  // b.any
    c2e4:	17fff798 	b	a144 <f0+0x114>
    c2e8:	72003c3f 	tst	w1, #0xffff
    c2ec:	54ff9281 	b.ne	b53c <f0+0x150c>  // b.any
    c2f0:	17fffc8e 	b	b528 <f0+0x14f8>
    c2f4:	72003c3f 	tst	w1, #0xffff
    c2f8:	54ff8c61 	b.ne	b484 <f0+0x1454>  // b.any
    c2fc:	17fffc5d 	b	b470 <f0+0x1440>
    c300:	72003c3f 	tst	w1, #0xffff
    c304:	54ff8481 	b.ne	b394 <f0+0x1364>  // b.any
    c308:	17fffc1e 	b	b380 <f0+0x1350>
    c30c:	72003c3f 	tst	w1, #0xffff
    c310:	54ff7f81 	b.ne	b300 <f0+0x12d0>  // b.any
    c314:	17fffbf6 	b	b2ec <f0+0x12bc>
    c318:	72003c3f 	tst	w1, #0xffff
    c31c:	54ff7501 	b.ne	b1bc <f0+0x118c>  // b.any
    c320:	17fffba2 	b	b1a8 <f0+0x1178>
    c324:	72003c3f 	tst	w1, #0xffff
    c328:	54ff6d21 	b.ne	b0cc <f0+0x109c>  // b.any
    c32c:	17fffb63 	b	b0b8 <f0+0x1088>
    c330:	72003c3f 	tst	w1, #0xffff
    c334:	54ff6461 	b.ne	afc0 <f0+0xf90>  // b.any
    c338:	17fffb1d 	b	afac <f0+0xf7c>
    c33c:	72003c3f 	tst	w1, #0xffff
    c340:	54ff5ba1 	b.ne	aeb4 <f0+0xe84>  // b.any
    c344:	17fffad7 	b	aea0 <f0+0xe70>
    c348:	72003c3f 	tst	w1, #0xffff
    c34c:	54ff0c81 	b.ne	a4dc <f0+0x4ac>  // b.any
    c350:	17fff85e 	b	a4c8 <f0+0x498>
    c354:	72003c3f 	tst	w1, #0xffff
    c358:	54fefce1 	b.ne	a2f4 <f0+0x2c4>  // b.any
    c35c:	17fff7e1 	b	a2e0 <f0+0x2b0>
    c360:	72003c3f 	tst	w1, #0xffff
    c364:	54fef701 	b.ne	a244 <f0+0x214>  // b.any
    c368:	17fff7b2 	b	a230 <f0+0x200>
    c36c:	72003c3f 	tst	w1, #0xffff
    c370:	54ff2321 	b.ne	a7d4 <f0+0x7a4>  // b.any
    c374:	17fff913 	b	a7c0 <f0+0x790>
    c378:	72003c3f 	tst	w1, #0xffff
    c37c:	54ff1d01 	b.ne	a71c <f0+0x6ec>  // b.any
    c380:	17fff8e2 	b	a708 <f0+0x6d8>
    c384:	72003c3f 	tst	w1, #0xffff
    c388:	54ff1721 	b.ne	a66c <f0+0x63c>  // b.any
    c38c:	17fff8b3 	b	a658 <f0+0x628>
    c390:	72003c3f 	tst	w1, #0xffff
    c394:	54ff0fc1 	b.ne	a58c <f0+0x55c>  // b.any
    c398:	17fff878 	b	a578 <f0+0x548>
    c39c:	72003c3f 	tst	w1, #0xffff
    c3a0:	54ff5201 	b.ne	ade0 <f0+0xdb0>  // b.any
    c3a4:	17fffa8a 	b	adcc <f0+0xd9c>
    c3a8:	72003c3f 	tst	w1, #0xffff
    c3ac:	54ff4ce1 	b.ne	ad48 <f0+0xd18>  // b.any
    c3b0:	17fffa61 	b	ad34 <f0+0xd04>
    c3b4:	72003c3f 	tst	w1, #0xffff
    c3b8:	54ff45e1 	b.ne	ac74 <f0+0xc44>  // b.any
    c3bc:	17fffa29 	b	ac60 <f0+0xc30>
    c3c0:	72003c3f 	tst	w1, #0xffff
    c3c4:	54ff3d21 	b.ne	ab68 <f0+0xb38>  // b.any
    c3c8:	17fff9e3 	b	ab54 <f0+0xb24>
    c3cc:	72003c3f 	tst	w1, #0xffff
    c3d0:	54ff3701 	b.ne	aab0 <f0+0xa80>  // b.any
    c3d4:	17fff9b2 	b	aa9c <f0+0xa6c>
    c3d8:	72003c3f 	tst	w1, #0xffff
    c3dc:	54ff30e1 	b.ne	a9f8 <f0+0x9c8>  // b.any
    c3e0:	17fff981 	b	a9e4 <f0+0x9b4>
    c3e4:	72003c3f 	tst	w1, #0xffff
    c3e8:	54ff29e1 	b.ne	a924 <f0+0x8f4>  // b.any
    c3ec:	17fff949 	b	a910 <f0+0x8e0>
    c3f0:	72003c3f 	tst	w1, #0xffff
    c3f4:	54ff24c1 	b.ne	a88c <f0+0x85c>  // b.any
    c3f8:	17fff920 	b	a878 <f0+0x848>
    c3fc:	72003c3f 	tst	w1, #0xffff
    c400:	54fff381 	b.ne	c270 <f0+0x2240>  // b.any
    c404:	17ffff96 	b	c25c <f0+0x222c>
    c408:	72003c3f 	tst	w1, #0xffff
    c40c:	54ffed61 	b.ne	c1b8 <f0+0x2188>  // b.any
    c410:	17ffff65 	b	c1a4 <f0+0x2174>
    c414:	72003c3f 	tst	w1, #0xffff
    c418:	54ffe841 	b.ne	c120 <f0+0x20f0>  // b.any
    c41c:	17ffff3c 	b	c10c <f0+0x20dc>
    c420:	72003c3f 	tst	w1, #0xffff
    c424:	54ffd881 	b.ne	bf34 <f0+0x1f04>  // b.any
    c428:	17fffebe 	b	bf20 <f0+0x1ef0>
    c42c:	72003c3f 	tst	w1, #0xffff
    c430:	54ffd361 	b.ne	be9c <f0+0x1e6c>  // b.any
    c434:	17fffe95 	b	be88 <f0+0x1e58>
    c438:	72003c3f 	tst	w1, #0xffff
    c43c:	54ffcd41 	b.ne	bde4 <f0+0x1db4>  // b.any
    c440:	17fffe64 	b	bdd0 <f0+0x1da0>
    c444:	72003c3f 	tst	w1, #0xffff
    c448:	54ffc721 	b.ne	bd2c <f0+0x1cfc>  // b.any
    c44c:	17fffe33 	b	bd18 <f0+0x1ce8>
    c450:	72003c3f 	tst	w1, #0xffff
    c454:	54ffc101 	b.ne	bc74 <f0+0x1c44>  // b.any
    c458:	17fffe02 	b	bc60 <f0+0x1c30>
    c45c:	72003c3f 	tst	w1, #0xffff
    c460:	54ffbc01 	b.ne	bbe0 <f0+0x1bb0>  // b.any
    c464:	17fffdda 	b	bbcc <f0+0x1b9c>
    c468:	72003c3f 	tst	w1, #0xffff
    c46c:	54ffb181 	b.ne	ba9c <f0+0x1a6c>  // b.any
    c470:	17fffd86 	b	ba88 <f0+0x1a58>
    c474:	72003c3f 	tst	w1, #0xffff
    c478:	54ffac81 	b.ne	ba08 <f0+0x19d8>  // b.any
    c47c:	17fffd5e 	b	b9f4 <f0+0x19c4>
    c480:	72003c3f 	tst	w1, #0xffff
    c484:	54ffa761 	b.ne	b970 <f0+0x1940>  // b.any
    c488:	17fffd35 	b	b95c <f0+0x192c>
    c48c:	72003c3f 	tst	w1, #0xffff
    c490:	54ffa141 	b.ne	b8b8 <f0+0x1888>  // b.any
    c494:	17fffd04 	b	b8a4 <f0+0x1874>
    c498:	72003c3f 	tst	w1, #0xffff
    c49c:	54ff95e1 	b.ne	b758 <f0+0x1728>  // b.any
    c4a0:	17fffca9 	b	b744 <f0+0x1714>
    c4a4:	72003c3f 	tst	w1, #0xffff
    c4a8:	54ff8e01 	b.ne	b668 <f0+0x1638>  // b.any
    c4ac:	17fffc6a 	b	b654 <f0+0x1624>
    c4b0:	72003c3f 	tst	w1, #0xffff
    c4b4:	54ff8901 	b.ne	b5d4 <f0+0x15a4>  // b.any
    c4b8:	17fffc42 	b	b5c0 <f0+0x1590>
    c4bc:	aa1403e0 	mov	x0, x20
    c4c0:	97ffe168 	bl	4a60 <fwp_rc_forget_slot>
    c4c4:	17ffff69 	b	c268 <f0+0x2238>
    c4c8:	aa1703e0 	mov	x0, x23
    c4cc:	97ffe165 	bl	4a60 <fwp_rc_forget_slot>
    c4d0:	17fff75b 	b	a23c <f0+0x20c>
    c4d4:	aa1503e0 	mov	x0, x21
    c4d8:	97ffe162 	bl	4a60 <fwp_rc_forget_slot>
    c4dc:	17fff784 	b	a2ec <f0+0x2bc>
    c4e0:	aa1703e0 	mov	x0, x23
    c4e4:	97ffe15f 	bl	4a60 <fwp_rc_forget_slot>
    c4e8:	17fff7fb 	b	a4d4 <f0+0x4a4>
    c4ec:	aa1703e0 	mov	x0, x23
    c4f0:	97ffe15c 	bl	4a60 <fwp_rc_forget_slot>
    c4f4:	17fff824 	b	a584 <f0+0x554>
    c4f8:	aa1703e0 	mov	x0, x23
    c4fc:	97ffe159 	bl	4a60 <fwp_rc_forget_slot>
    c500:	17fff859 	b	a664 <f0+0x634>
    c504:	aa1703e0 	mov	x0, x23
    c508:	97ffe156 	bl	4a60 <fwp_rc_forget_slot>
    c50c:	17fff882 	b	a714 <f0+0x6e4>
    c510:	aa1703e0 	mov	x0, x23
    c514:	97ffe153 	bl	4a60 <fwp_rc_forget_slot>
    c518:	17fff8ad 	b	a7cc <f0+0x79c>
    c51c:	aa1703e0 	mov	x0, x23
    c520:	97ffe150 	bl	4a60 <fwp_rc_forget_slot>
    c524:	17fff8d8 	b	a884 <f0+0x854>
    c528:	aa1703e0 	mov	x0, x23
    c52c:	97ffe14d 	bl	4a60 <fwp_rc_forget_slot>
    c530:	17fff8fb 	b	a91c <f0+0x8ec>
    c534:	aa1703e0 	mov	x0, x23
    c538:	97ffe14a 	bl	4a60 <fwp_rc_forget_slot>
    c53c:	17fff92d 	b	a9f0 <f0+0x9c0>
    c540:	aa1703e0 	mov	x0, x23
    c544:	97ffe147 	bl	4a60 <fwp_rc_forget_slot>
    c548:	17fff958 	b	aaa8 <f0+0xa78>
    c54c:	aa1703e0 	mov	x0, x23
    c550:	97ffe144 	bl	4a60 <fwp_rc_forget_slot>
    c554:	17fff983 	b	ab60 <f0+0xb30>
    c558:	aa1703e0 	mov	x0, x23
    c55c:	97ffe141 	bl	4a60 <fwp_rc_forget_slot>
    c560:	17fff9c3 	b	ac6c <f0+0xc3c>
    c564:	aa1703e0 	mov	x0, x23
    c568:	97ffe13e 	bl	4a60 <fwp_rc_forget_slot>
    c56c:	17fff9f5 	b	ad40 <f0+0xd10>
    c570:	aa1703e0 	mov	x0, x23
    c574:	97ffe13b 	bl	4a60 <fwp_rc_forget_slot>
    c578:	17fffa18 	b	add8 <f0+0xda8>
    c57c:	aa1703e0 	mov	x0, x23
    c580:	97ffe138 	bl	4a60 <fwp_rc_forget_slot>
    c584:	17fffa4a 	b	aeac <f0+0xe7c>
    c588:	aa1703e0 	mov	x0, x23
    c58c:	97ffe135 	bl	4a60 <fwp_rc_forget_slot>
    c590:	17fffa8a 	b	afb8 <f0+0xf88>
    c594:	aa1703e0 	mov	x0, x23
    c598:	97ffe132 	bl	4a60 <fwp_rc_forget_slot>
    c59c:	17fffaca 	b	b0c4 <f0+0x1094>
    c5a0:	aa1503e0 	mov	x0, x21
    c5a4:	97ffe12f 	bl	4a60 <fwp_rc_forget_slot>
    c5a8:	17fffb03 	b	b1b4 <f0+0x1184>
    c5ac:	aa1703e0 	mov	x0, x23
    c5b0:	97ffe12c 	bl	4a60 <fwp_rc_forget_slot>
    c5b4:	17fffb51 	b	b2f8 <f0+0x12c8>
    c5b8:	aa1703e0 	mov	x0, x23
    c5bc:	97ffe129 	bl	4a60 <fwp_rc_forget_slot>
    c5c0:	17fffb73 	b	b38c <f0+0x135c>
    c5c4:	aa1703e0 	mov	x0, x23
    c5c8:	97ffe126 	bl	4a60 <fwp_rc_forget_slot>
    c5cc:	17fffbac 	b	b47c <f0+0x144c>
    c5d0:	aa1703e0 	mov	x0, x23
    c5d4:	97ffe123 	bl	4a60 <fwp_rc_forget_slot>
    c5d8:	17fffbd7 	b	b534 <f0+0x1504>
    c5dc:	aa1703e0 	mov	x0, x23
    c5e0:	97ffe120 	bl	4a60 <fwp_rc_forget_slot>
    c5e4:	17fffbfa 	b	b5cc <f0+0x159c>
    c5e8:	aa1703e0 	mov	x0, x23
    c5ec:	97ffe11d 	bl	4a60 <fwp_rc_forget_slot>
    c5f0:	17fffc1c 	b	b660 <f0+0x1630>
    c5f4:	aa1703e0 	mov	x0, x23
    c5f8:	97ffe11a 	bl	4a60 <fwp_rc_forget_slot>
    c5fc:	17fffc55 	b	b750 <f0+0x1720>
    c600:	aa1703e0 	mov	x0, x23
    c604:	97ffe117 	bl	4a60 <fwp_rc_forget_slot>
    c608:	17fffcaa 	b	b8b0 <f0+0x1880>
    c60c:	aa1703e0 	mov	x0, x23
    c610:	97ffe114 	bl	4a60 <fwp_rc_forget_slot>
    c614:	17fffcd5 	b	b968 <f0+0x1938>
    c618:	aa1703e0 	mov	x0, x23
    c61c:	97ffe111 	bl	4a60 <fwp_rc_forget_slot>
    c620:	17fffcf8 	b	ba00 <f0+0x19d0>
    c624:	aa1503e0 	mov	x0, x21
    c628:	97ffe10e 	bl	4a60 <fwp_rc_forget_slot>
    c62c:	17fffd1a 	b	ba94 <f0+0x1a64>
    c630:	aa1703e0 	mov	x0, x23
    c634:	97ffe10b 	bl	4a60 <fwp_rc_forget_slot>
    c638:	17fffd68 	b	bbd8 <f0+0x1ba8>
    c63c:	aa1703e0 	mov	x0, x23
    c640:	97ffe108 	bl	4a60 <fwp_rc_forget_slot>
    c644:	17fffd8a 	b	bc6c <f0+0x1c3c>
    c648:	aa1703e0 	mov	x0, x23
    c64c:	97ffe105 	bl	4a60 <fwp_rc_forget_slot>
    c650:	17fffdb5 	b	bd24 <f0+0x1cf4>
    c654:	aa1703e0 	mov	x0, x23
    c658:	97ffe102 	bl	4a60 <fwp_rc_forget_slot>
    c65c:	17fffde0 	b	bddc <f0+0x1dac>
    c660:	aa1703e0 	mov	x0, x23
    c664:	97ffe0ff 	bl	4a60 <fwp_rc_forget_slot>
    c668:	17fffe0b 	b	be94 <f0+0x1e64>
    c66c:	aa1503e0 	mov	x0, x21
    c670:	97ffe0fc 	bl	4a60 <fwp_rc_forget_slot>
    c674:	17fffe2e 	b	bf2c <f0+0x1efc>
    c678:	aa1703e0 	mov	x0, x23
    c67c:	97ffe0f9 	bl	4a60 <fwp_rc_forget_slot>
    c680:	17fffea6 	b	c118 <f0+0x20e8>
    c684:	aa1703e0 	mov	x0, x23
    c688:	97ffe0f6 	bl	4a60 <fwp_rc_forget_slot>
    c68c:	17fffec9 	b	c1b0 <f0+0x2180>
    c690:	97ffd884 	bl	28a0 <__stack_chk_fail@plt>

000000000000c694 <fwp_main_thread>:
    c694:	d10443ff 	sub	sp, sp, #0x110
    c698:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    c69c:	f947f400 	ldr	x0, [x0, #4072]
    c6a0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c6a4:	910303fd 	add	x29, sp, #0xc0
    c6a8:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c6ac:	b0000376 	adrp	x22, 79000 <fwp_root_context+0xb90>
    c6b0:	911942c1 	add	x1, x22, #0x650
    c6b4:	a90d53f3 	stp	x19, x20, [sp, #208]
    c6b8:	a90f63f7 	stp	x23, x24, [sp, #240]
    c6bc:	b953a421 	ldr	w1, [x1, #5028]
    c6c0:	a9106bf9 	stp	x25, x26, [sp, #256]
    c6c4:	f9400002 	ldr	x2, [x0]
    c6c8:	f9005fe2 	str	x2, [sp, #184]
    c6cc:	d2800002 	mov	x2, #0x0                   	// #0
    c6d0:	34002941 	cbz	w1, cbf8 <fwp_main_thread+0x564>
    c6d4:	911942c0 	add	x0, x22, #0x650
    c6d8:	b953a800 	ldr	w0, [x0, #5032]
    c6dc:	35002860 	cbnz	w0, cbe8 <fwp_main_thread+0x554>
    c6e0:	91001fe2 	add	x2, sp, #0x7
    c6e4:	900000b5 	adrp	x21, 20000 <__data_start>
    c6e8:	900000a3 	adrp	x3, 20000 <__data_start>
    c6ec:	910142b3 	add	x19, x21, #0x50
    c6f0:	9111c063 	add	x3, x3, #0x470
    c6f4:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c6f8:	d2a00025 	mov	x5, #0x10000               	// #65536
    c6fc:	910023e0 	add	x0, sp, #0x8
    c700:	d2800001 	mov	x1, #0x0                   	// #0
    c704:	f90007e3 	str	x3, [sp, #8]
    c708:	b90013ff 	str	wzr, [sp, #16]
    c70c:	f9000fe5 	str	x5, [sp, #24]
    c710:	a90a1262 	stp	x2, x4, [x19, #160]
    c714:	97ffd7fb 	bl	2700 <sigaltstack@plt>
    c718:	35002880 	cbnz	w0, cc28 <fwp_main_thread+0x594>
    c71c:	4f000400 	movi	v0.4s, #0x0
    c720:	9100a3e0 	add	x0, sp, #0x28
    c724:	f0ffffa1 	adrp	x1, 3000 <ad_raw_record+0x70>
    c728:	52800082 	mov	w2, #0x4                   	// #4
    c72c:	9102c021 	add	x1, x1, #0xb0
    c730:	72a10002 	movk	w2, #0x800, lsl #16
    c734:	910083f4 	add	x20, sp, #0x20
    c738:	f90013e1 	str	x1, [sp, #32]
    c73c:	3d802000 	str	q0, [x0, #128]
    c740:	b900abe2 	str	w2, [sp, #168]
    c744:	ad000000 	stp	q0, q0, [x0]
    c748:	ad010000 	stp	q0, q0, [x0, #32]
    c74c:	ad020000 	stp	q0, q0, [x0, #64]
    c750:	ad030000 	stp	q0, q0, [x0, #96]
    c754:	97ffd843 	bl	2860 <sigemptyset@plt>
    c758:	35002680 	cbnz	w0, cc28 <fwp_main_thread+0x594>
    c75c:	aa1403e1 	mov	x1, x20
    c760:	d2800002 	mov	x2, #0x0                   	// #0
    c764:	52800160 	mov	w0, #0xb                   	// #11
    c768:	97ffd856 	bl	28c0 <sigaction@plt>
    c76c:	350025e0 	cbnz	w0, cc28 <fwp_main_thread+0x594>
    c770:	aa1403e1 	mov	x1, x20
    c774:	d2800002 	mov	x2, #0x0                   	// #0
    c778:	528000e0 	mov	w0, #0x7                   	// #7
    c77c:	97ffd851 	bl	28c0 <sigaction@plt>
    c780:	35002540 	cbnz	w0, cc28 <fwp_main_thread+0x594>
    c784:	911942c1 	add	x1, x22, #0x650
    c788:	52800034 	mov	w20, #0x1                   	// #1
    c78c:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    c790:	910ec000 	add	x0, x0, #0x3b0
    c794:	b9015274 	str	w20, [x19, #336]
    c798:	fd4a1020 	ldr	d0, [x1, #5152]
    c79c:	7e61d800 	ucvtf	d0, d0
    c7a0:	fd00b660 	str	d0, [x19, #360]
    c7a4:	940002e7 	bl	d340 <atexit>
    c7a8:	35002460 	cbnz	w0, cc34 <fwp_main_thread+0x5a0>
    c7ac:	b943ea60 	ldr	w0, [x19, #1000]
    c7b0:	34002280 	cbz	w0, cc00 <fwp_main_thread+0x56c>
    c7b4:	910142ba 	add	x26, x21, #0x50
    c7b8:	f9404f54 	ldr	x20, [x26, #152]
    c7bc:	b4001094 	cbz	x20, c9cc <fwp_main_thread+0x338>
    c7c0:	aa1403f3 	mov	x19, x20
    c7c4:	91010297 	add	x23, x20, #0x40
    c7c8:	39414a99 	ldrb	w25, [x20, #82]
    c7cc:	52800038 	mov	w24, #0x1                   	// #1
    c7d0:	39014a98 	strb	w24, [x20, #82]
    c7d4:	f9401680 	ldr	x0, [x20, #40]
    c7d8:	b4000620 	cbz	x0, c89c <fwp_main_thread+0x208>
    c7dc:	f9403281 	ldr	x1, [x20, #96]
    c7e0:	39414680 	ldrb	w0, [x20, #81]
    c7e4:	b4000b21 	cbz	x1, c948 <fwp_main_thread+0x2b4>
    c7e8:	36000a60 	tbz	w0, #0, c934 <fwp_main_thread+0x2a0>
    c7ec:	39414a62 	ldrb	w2, [x19, #82]
    c7f0:	f9402280 	ldr	x0, [x20, #64]
    c7f4:	37000d42 	tbnz	w2, #0, c99c <fwp_main_thread+0x308>
    c7f8:	f9403261 	ldr	x1, [x19, #96]
    c7fc:	a911fe77 	stp	x23, xzr, [x19, #280]
    c800:	f9009660 	str	x0, [x19, #296]
    c804:	b4000040 	cbz	x0, c80c <fwp_main_thread+0x178>
    c808:	f9009013 	str	x19, [x0, #288]
    c80c:	f9002293 	str	x19, [x20, #64]
    c810:	b4000101 	cbz	x1, c830 <fwp_main_thread+0x19c>
    c814:	f940a740 	ldr	x0, [x26, #328]
    c818:	39015678 	strb	w24, [x19, #85]
    c81c:	f9003661 	str	x1, [x19, #104]
    c820:	a910827f 	stp	xzr, x0, [x19, #264]
    c824:	b4000040 	cbz	x0, c82c <fwp_main_thread+0x198>
    c828:	f9008413 	str	x19, [x0, #264]
    c82c:	f900a753 	str	x19, [x26, #328]
    c830:	39015a7f 	strb	wzr, [x19, #86]
    c834:	97ffe890 	bl	6a74 <fwp_block>
    c838:	f9408e62 	ldr	x2, [x19, #280]
    c83c:	b4000142 	cbz	x2, c864 <fwp_main_thread+0x1d0>
    c840:	a9520261 	ldp	x1, x0, [x19, #288]
    c844:	b4000b81 	cbz	x1, c9b4 <fwp_main_thread+0x320>
    c848:	f9009420 	str	x0, [x1, #296]
    c84c:	f9409660 	ldr	x0, [x19, #296]
    c850:	b4000040 	cbz	x0, c858 <fwp_main_thread+0x1c4>
    c854:	f9009001 	str	x1, [x0, #288]
    c858:	91080260 	add	x0, x19, #0x200
    c85c:	f900967f 	str	xzr, [x19, #296]
    c860:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c864:	39415660 	ldrb	w0, [x19, #85]
    c868:	f9404f42 	ldr	x2, [x26, #152]
    c86c:	36000940 	tbz	w0, #0, c994 <fwp_main_thread+0x300>
    c870:	a9508261 	ldp	x1, x0, [x19, #264]
    c874:	b4000a41 	cbz	x1, c9bc <fwp_main_thread+0x328>
    c878:	f9008820 	str	x0, [x1, #272]
    c87c:	b4000040 	cbz	x0, c884 <fwp_main_thread+0x1f0>
    c880:	f9008401 	str	x1, [x0, #264]
    c884:	91080260 	add	x0, x19, #0x200
    c888:	3901567f 	strb	wzr, [x19, #85]
    c88c:	aa0203f3 	mov	x19, x2
    c890:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c894:	f9401680 	ldr	x0, [x20, #40]
    c898:	b5fffa20 	cbnz	x0, c7dc <fwp_main_thread+0x148>
    c89c:	910142a0 	add	x0, x21, #0x50
    c8a0:	39014a99 	strb	w25, [x20, #82]
    c8a4:	f941e400 	ldr	x0, [x0, #968]
    c8a8:	b4001820 	cbz	x0, cbac <fwp_main_thread+0x518>
    c8ac:	910142a0 	add	x0, x21, #0x50
    c8b0:	f9420001 	ldr	x1, [x0, #1024]
    c8b4:	b903f81f 	str	wzr, [x0, #1016]
    c8b8:	eb13003f 	cmp	x1, x19
    c8bc:	54001941 	b.ne	cbe4 <fwp_main_thread+0x550>  // b.any
    c8c0:	b4000913 	cbz	x19, c9e0 <fwp_main_thread+0x34c>
    c8c4:	910142a0 	add	x0, x21, #0x50
    c8c8:	52800021 	mov	w1, #0x1                   	// #1
    c8cc:	39014a61 	strb	w1, [x19, #82]
    c8d0:	f941d005 	ldr	x5, [x0, #928]
    c8d4:	b4000865 	cbz	x5, c9e0 <fwp_main_thread+0x34c>
    c8d8:	394140a0 	ldrb	w0, [x5, #80]
    c8dc:	37000060 	tbnz	w0, #0, c8e8 <fwp_main_thread+0x254>
    c8e0:	aa0503e0 	mov	x0, x5
    c8e4:	97ffdb83 	bl	36f0 <fwp_cancel_tree.part.0>
    c8e8:	f9409ca5 	ldr	x5, [x5, #312]
    c8ec:	b5ffff65 	cbnz	x5, c8d8 <fwp_main_thread+0x244>
    c8f0:	910142b4 	add	x20, x21, #0x50
    c8f4:	52800037 	mov	w23, #0x1                   	// #1
    c8f8:	f9402a60 	ldr	x0, [x19, #80]
    c8fc:	f2001c1f 	tst	x0, #0xff000000ff
    c900:	540000e1 	b.ne	c91c <fwp_main_thread+0x288>  // b.any
    c904:	f9406280 	ldr	x0, [x20, #192]
    c908:	39015277 	strb	w23, [x19, #84]
    c90c:	f900827f 	str	xzr, [x19, #256]
    c910:	b40005a0 	cbz	x0, c9c4 <fwp_main_thread+0x330>
    c914:	f9008013 	str	x19, [x0, #256]
    c918:	f9006293 	str	x19, [x20, #192]
    c91c:	97ffe856 	bl	6a74 <fwp_block>
    c920:	97ffe7e8 	bl	68c0 <fwp_free_zombie>
    c924:	f941d280 	ldr	x0, [x20, #928]
    c928:	b40005c0 	cbz	x0, c9e0 <fwp_main_thread+0x34c>
    c92c:	f9420293 	ldr	x19, [x20, #1024]
    c930:	17fffff2 	b	c8f8 <fwp_main_thread+0x264>
    c934:	97ffdc13 	bl	3980 <fwp_now_ns>
    c938:	f9403281 	ldr	x1, [x20, #96]
    c93c:	eb01001f 	cmp	x0, x1
    c940:	5400128a 	b.ge	cb90 <fwp_main_thread+0x4fc>  // b.tcont
    c944:	39414680 	ldrb	w0, [x20, #81]
    c948:	39414a62 	ldrb	w2, [x19, #82]
    c94c:	3707f520 	tbnz	w0, #0, c7f0 <fwp_main_thread+0x15c>
    c950:	f9403281 	ldr	x1, [x20, #96]
    c954:	370001c2 	tbnz	w2, #0, c98c <fwp_main_thread+0x2f8>
    c958:	f9403260 	ldr	x0, [x19, #96]
    c95c:	b4000180 	cbz	x0, c98c <fwp_main_thread+0x2f8>
    c960:	b4000061 	cbz	x1, c96c <fwp_main_thread+0x2d8>
    c964:	eb01001f 	cmp	x0, x1
    c968:	9a81d000 	csel	x0, x0, x1, le
    c96c:	f9402281 	ldr	x1, [x20, #64]
    c970:	a911fe77 	stp	x23, xzr, [x19, #280]
    c974:	f9009661 	str	x1, [x19, #296]
    c978:	b40014c1 	cbz	x1, cc10 <fwp_main_thread+0x57c>
    c97c:	f9009033 	str	x19, [x1, #288]
    c980:	aa0003e1 	mov	x1, x0
    c984:	f9002293 	str	x19, [x20, #64]
    c988:	17ffffa3 	b	c814 <fwp_main_thread+0x180>
    c98c:	f9402280 	ldr	x0, [x20, #64]
    c990:	17ffff9b 	b	c7fc <fwp_main_thread+0x168>
    c994:	aa0203f3 	mov	x19, x2
    c998:	17ffff8f 	b	c7d4 <fwp_main_thread+0x140>
    c99c:	a911fe77 	stp	x23, xzr, [x19, #280]
    c9a0:	f9009660 	str	x0, [x19, #296]
    c9a4:	b4000040 	cbz	x0, c9ac <fwp_main_thread+0x318>
    c9a8:	f9009013 	str	x19, [x0, #288]
    c9ac:	f9002293 	str	x19, [x20, #64]
    c9b0:	17ffffa0 	b	c830 <fwp_main_thread+0x19c>
    c9b4:	f9000040 	str	x0, [x2]
    c9b8:	17ffffa6 	b	c850 <fwp_main_thread+0x1bc>
    c9bc:	f900a740 	str	x0, [x26, #328]
    c9c0:	17ffffaf 	b	c87c <fwp_main_thread+0x1e8>
    c9c4:	f9006693 	str	x19, [x20, #200]
    c9c8:	17ffffd4 	b	c918 <fwp_main_thread+0x284>
    c9cc:	f941e740 	ldr	x0, [x26, #968]
    c9d0:	b4000ec0 	cbz	x0, cba8 <fwp_main_thread+0x514>
    c9d4:	f9420340 	ldr	x0, [x26, #1024]
    c9d8:	b903fb5f 	str	wzr, [x26, #1016]
    c9dc:	b5001040 	cbnz	x0, cbe4 <fwp_main_thread+0x550>
    c9e0:	910142b4 	add	x20, x21, #0x50
    c9e4:	97ffe7b7 	bl	68c0 <fwp_free_zombie>
    c9e8:	f9406680 	ldr	x0, [x20, #200]
    c9ec:	b5000fc0 	cbnz	x0, cbe4 <fwp_main_thread+0x550>
    c9f0:	f940a680 	ldr	x0, [x20, #328]
    c9f4:	b5000f80 	cbnz	x0, cbe4 <fwp_main_thread+0x550>
    c9f8:	b9419293 	ldr	w19, [x20, #400]
    c9fc:	340001d3 	cbz	w19, ca34 <fwp_main_thread+0x3a0>
    ca00:	93407e77 	sxtw	x23, w19
    ca04:	51000673 	sub	w19, w19, #0x1
    ca08:	d1000af7 	sub	x23, x23, #0x2
    ca0c:	91068298 	add	x24, x20, #0x1a0
    ca10:	cb3342f7 	sub	x23, x23, w19, uxtw
    ca14:	93407e73 	sxtw	x19, w19
    ca18:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    ca1c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    ca20:	b9019293 	str	w19, [x20, #400]
    ca24:	d1000673 	sub	x19, x19, #0x1
    ca28:	97ffd7e6 	bl	29c0 <munmap@plt>
    ca2c:	eb1302ff 	cmp	x23, x19
    ca30:	54ffff41 	b.ne	ca18 <fwp_main_thread+0x384>  // b.any
    ca34:	900000b3 	adrp	x19, 20000 <__data_start>
    ca38:	91004260 	add	x0, x19, #0x10
    ca3c:	b9402800 	ldr	w0, [x0, #40]
    ca40:	37f80040 	tbnz	w0, #31, ca48 <fwp_main_thread+0x3b4>
    ca44:	97ffd79b 	bl	28b0 <close@plt>
    ca48:	910142a0 	add	x0, x21, #0x50
    ca4c:	91004261 	add	x1, x19, #0x10
    ca50:	12800002 	mov	w2, #0xffffffff            	// #-1
    ca54:	d2800013 	mov	x19, #0x0                   	// #0
    ca58:	f9420417 	ldr	x23, [x0, #1032]
    ca5c:	b9002822 	str	w2, [x1, #40]
    ca60:	f9420814 	ldr	x20, [x0, #1040]
    ca64:	b4000177 	cbz	x23, ca90 <fwp_main_thread+0x3fc>
    ca68:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    ca6c:	b40000c0 	cbz	x0, ca84 <fwp_main_thread+0x3f0>
    ca70:	f9400001 	ldr	x1, [x0]
    ca74:	b5000b81 	cbnz	x1, cbe4 <fwp_main_thread+0x550>
    ca78:	f9400401 	ldr	x1, [x0, #8]
    ca7c:	b5000b41 	cbnz	x1, cbe4 <fwp_main_thread+0x550>
    ca80:	97ffe098 	bl	4ce0 <fwp_mem_free>
    ca84:	91000673 	add	x19, x19, #0x1
    ca88:	eb1302ff 	cmp	x23, x19
    ca8c:	54fffee1 	b.ne	ca68 <fwp_main_thread+0x3d4>  // b.any
    ca90:	aa1403e0 	mov	x0, x20
    ca94:	97ffe093 	bl	4ce0 <fwp_mem_free>
    ca98:	910142a0 	add	x0, x21, #0x50
    ca9c:	f9420013 	ldr	x19, [x0, #1024]
    caa0:	f902041f 	str	xzr, [x0, #1032]
    caa4:	f902081f 	str	xzr, [x0, #1040]
    caa8:	b40001f3 	cbz	x19, cae4 <fwp_main_thread+0x450>
    caac:	f9401661 	ldr	x1, [x19, #40]
    cab0:	b50009a1 	cbnz	x1, cbe4 <fwp_main_thread+0x550>
    cab4:	f9405661 	ldr	x1, [x19, #168]
    cab8:	b5000961 	cbnz	x1, cbe4 <fwp_main_thread+0x550>
    cabc:	f941e401 	ldr	x1, [x0, #968]
    cac0:	b5000921 	cbnz	x1, cbe4 <fwp_main_thread+0x550>
    cac4:	f941ec00 	ldr	x0, [x0, #984]
    cac8:	b50008e0 	cbnz	x0, cbe4 <fwp_main_thread+0x550>
    cacc:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cad0:	90000360 	adrp	x0, 78000 <ad_raw_blocks+0x17b90>
    cad4:	9111c000 	add	x0, x0, #0x470
    cad8:	97ffd766 	bl	2870 <memset@plt>
    cadc:	aa1303e0 	mov	x0, x19
    cae0:	97ffe080 	bl	4ce0 <fwp_mem_free>
    cae4:	910142a6 	add	x6, x21, #0x50
    cae8:	911942d6 	add	x22, x22, #0x650
    caec:	3dc016a1 	ldr	q1, [x21, #80]
    caf0:	52800041 	mov	w1, #0x2                   	// #2
    caf4:	3dc004c2 	ldr	q2, [x6, #16]
    caf8:	b0000002 	adrp	x2, d000 <__modti3+0x30>
    cafc:	fd4a12c0 	ldr	d0, [x22, #5152]
    cb00:	912ea042 	add	x2, x2, #0xba8
    cb04:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    cb08:	fd40b4c1 	ldr	d1, [x6, #360]
    cb0c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cb10:	f947e800 	ldr	x0, [x0, #4048]
    cb14:	7e61d800 	ucvtf	d0, d0
    cb18:	a95590c3 	ldp	x3, x4, [x6, #344]
    cb1c:	f9004cdf 	str	xzr, [x6, #152]
    cb20:	f9400000 	ldr	x0, [x0]
    cb24:	1e613801 	fsub	d1, d0, d1
    cb28:	f940bcc5 	ldr	x5, [x6, #376]
    cb2c:	b90150df 	str	wzr, [x6, #336]
    cb30:	5ef1b842 	addp	d2, v2.2d
    cb34:	fd40b8c0 	ldr	d0, [x6, #368]
    cb38:	f90200df 	str	xzr, [x6, #1024]
    cb3c:	fd0058c2 	str	d2, [x6, #176]
    cb40:	97ffd774 	bl	2910 <__fprintf_chk@plt>
    cb44:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cb48:	f947ec00 	ldr	x0, [x0, #4056]
    cb4c:	f9400000 	ldr	x0, [x0]
    cb50:	97ffd7a0 	bl	29d0 <fflush@plt>
    cb54:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cb58:	f947f400 	ldr	x0, [x0, #4072]
    cb5c:	f9405fe2 	ldr	x2, [sp, #184]
    cb60:	f9400001 	ldr	x1, [x0]
    cb64:	eb010042 	subs	x2, x2, x1
    cb68:	d2800001 	mov	x1, #0x0                   	// #0
    cb6c:	540006a1 	b.ne	cc40 <fwp_main_thread+0x5ac>  // b.any
    cb70:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cb74:	d2800000 	mov	x0, #0x0                   	// #0
    cb78:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cb7c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cb80:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cb84:	a9506bf9 	ldp	x25, x26, [sp, #256]
    cb88:	910443ff 	add	sp, sp, #0x110
    cb8c:	d65f03c0 	ret
    cb90:	39414280 	ldrb	w0, [x20, #80]
    cb94:	3707ed80 	tbnz	w0, #0, c944 <fwp_main_thread+0x2b0>
    cb98:	aa1403e0 	mov	x0, x20
    cb9c:	97ffdad5 	bl	36f0 <fwp_cancel_tree.part.0>
    cba0:	39414680 	ldrb	w0, [x20, #81]
    cba4:	17ffff69 	b	c948 <fwp_main_thread+0x2b4>
    cba8:	d2800013 	mov	x19, #0x0                   	// #0
    cbac:	910142b4 	add	x20, x21, #0x50
    cbb0:	f941ee80 	ldr	x0, [x20, #984]
    cbb4:	b5ffe7c0 	cbnz	x0, c8ac <fwp_main_thread+0x218>
    cbb8:	f941e280 	ldr	x0, [x20, #960]
    cbbc:	97ffe049 	bl	4ce0 <fwp_mem_free>
    cbc0:	f901e29f 	str	xzr, [x20, #960]
    cbc4:	f901ea9f 	str	xzr, [x20, #976]
    cbc8:	f9420280 	ldr	x0, [x20, #1024]
    cbcc:	b4000293 	cbz	x19, cc1c <fwp_main_thread+0x588>
    cbd0:	f900567f 	str	xzr, [x19, #168]
    cbd4:	f9005e7f 	str	xzr, [x19, #184]
    cbd8:	b903fa9f 	str	wzr, [x20, #1016]
    cbdc:	eb13001f 	cmp	x0, x19
    cbe0:	54ffe720 	b.eq	c8c4 <fwp_main_thread+0x230>  // b.none
    cbe4:	97ffd743 	bl	28f0 <abort@plt>
    cbe8:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    cbec:	913e8000 	add	x0, x0, #0xfa0
    cbf0:	940001d4 	bl	d340 <atexit>
    cbf4:	17fffebb 	b	c6e0 <fwp_main_thread+0x4c>
    cbf8:	97ffdd43 	bl	4104 <fwp_heap_init>
    cbfc:	17fffeb6 	b	c6d4 <fwp_main_thread+0x40>
    cc00:	97fff50c 	bl	a030 <f0>
    cc04:	b903ea74 	str	w20, [x19, #1000]
    cc08:	f901fa60 	str	x0, [x19, #1008]
    cc0c:	17fffeea 	b	c7b4 <fwp_main_thread+0x120>
    cc10:	aa0003e1 	mov	x1, x0
    cc14:	f9002293 	str	x19, [x20, #64]
    cc18:	17fffeff 	b	c814 <fwp_main_thread+0x180>
    cc1c:	b903fa9f 	str	wzr, [x20, #1016]
    cc20:	b4ffee00 	cbz	x0, c9e0 <fwp_main_thread+0x34c>
    cc24:	97ffd733 	bl	28f0 <abort@plt>
    cc28:	b0000000 	adrp	x0, d000 <__modti3+0x30>
    cc2c:	912d8000 	add	x0, x0, #0xb60
    cc30:	97ffdaf4 	bl	3800 <fwp_trap>
    cc34:	b0000000 	adrp	x0, d000 <__modti3+0x30>
    cc38:	912e2000 	add	x0, x0, #0xb88
    cc3c:	97ffd9d1 	bl	3380 <ad_raw_fail>
    cc40:	97ffd718 	bl	28a0 <__stack_chk_fail@plt>
    cc44:	d503201f 	nop
    cc48:	d503201f 	nop
    cc4c:	d503201f 	nop

000000000000cc50 <__divti3>:
    cc50:	d503245f 	bti	c
    cc54:	d2800004 	mov	x4, #0x0                   	// #0
    cc58:	b7f80721 	tbnz	x1, #63, cd3c <__divti3+0xec>
    cc5c:	b6f80083 	tbz	x3, #63, cc6c <__divti3+0x1c>
    cc60:	eb0203e2 	negs	x2, x2
    cc64:	aa2403e4 	mvn	x4, x4
    cc68:	da0303e3 	ngc	x3, x3
    cc6c:	aa0203e6 	mov	x6, x2
    cc70:	aa0003e7 	mov	x7, x0
    cc74:	aa0103e5 	mov	x5, x1
    cc78:	b5000583 	cbnz	x3, cd28 <__divti3+0xd8>
    cc7c:	eb01005f 	cmp	x2, x1
    cc80:	54000e69 	b.ls	ce4c <__divti3+0x1fc>  // b.plast
    cc84:	dac01040 	clz	x0, x2
    cc88:	b40000e0 	cbz	x0, cca4 <__divti3+0x54>
    cc8c:	4b0003e1 	neg	w1, w0
    cc90:	9ac020a5 	lsl	x5, x5, x0
    cc94:	9ac02046 	lsl	x6, x2, x0
    cc98:	9ac124e1 	lsr	x1, x7, x1
    cc9c:	aa050025 	orr	x5, x1, x5
    cca0:	9ac020e7 	lsl	x7, x7, x0
    cca4:	d360fcc8 	lsr	x8, x6, #32
    cca8:	92407cc2 	and	x2, x6, #0xffffffff
    ccac:	9ac808a3 	udiv	x3, x5, x8
    ccb0:	9b089465 	msub	x5, x3, x8, x5
    ccb4:	aa0303e0 	mov	x0, x3
    ccb8:	9b037c41 	mul	x1, x2, x3
    ccbc:	93c780a5 	extr	x5, x5, x7, #32
    ccc0:	eb05003f 	cmp	x1, x5
    ccc4:	540000a9 	b.ls	ccd8 <__divti3+0x88>  // b.plast
    ccc8:	ab0500c5 	adds	x5, x6, x5
    cccc:	d1000460 	sub	x0, x3, #0x1
    ccd0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ccd4:	540015a8 	b.hi	cf88 <__divti3+0x338>  // b.pmore
    ccd8:	cb0100a5 	sub	x5, x5, x1
    ccdc:	9ac808a3 	udiv	x3, x5, x8
    cce0:	9b089465 	msub	x5, x3, x8, x5
    cce4:	aa0303e1 	mov	x1, x3
    cce8:	9b037c42 	mul	x2, x2, x3
    ccec:	aa0703e3 	mov	x3, x7
    ccf0:	b3607ca3 	bfi	x3, x5, #32, #32
    ccf4:	eb03005f 	cmp	x2, x3
    ccf8:	540000c9 	b.ls	cd10 <__divti3+0xc0>  // b.plast
    ccfc:	ab0300c3 	adds	x3, x6, x3
    cd00:	d1000425 	sub	x5, x1, #0x1
    cd04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cd08:	d1000821 	sub	x1, x1, #0x2
    cd0c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    cd10:	aa008020 	orr	x0, x1, x0, lsl #32
    cd14:	d2800001 	mov	x1, #0x0                   	// #0
    cd18:	b4000064 	cbz	x4, cd24 <__divti3+0xd4>
    cd1c:	eb0003e0 	negs	x0, x0
    cd20:	da0103e1 	ngc	x1, x1
    cd24:	d65f03c0 	ret
    cd28:	eb01007f 	cmp	x3, x1
    cd2c:	54000109 	b.ls	cd4c <__divti3+0xfc>  // b.plast
    cd30:	d2800001 	mov	x1, #0x0                   	// #0
    cd34:	d2800000 	mov	x0, #0x0                   	// #0
    cd38:	17fffff8 	b	cd18 <__divti3+0xc8>
    cd3c:	eb0003e0 	negs	x0, x0
    cd40:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cd44:	da0103e1 	ngc	x1, x1
    cd48:	17ffffc5 	b	cc5c <__divti3+0xc>
    cd4c:	dac01067 	clz	x7, x3
    cd50:	b40010e7 	cbz	x7, cf6c <__divti3+0x31c>
    cd54:	d2800805 	mov	x5, #0x40                  	// #64
    cd58:	cb0700a5 	sub	x5, x5, x7
    cd5c:	9ac72063 	lsl	x3, x3, x7
    cd60:	9ac52448 	lsr	x8, x2, x5
    cd64:	aa030108 	orr	x8, x8, x3
    cd68:	9ac52426 	lsr	x6, x1, x5
    cd6c:	92407d0a 	and	x10, x8, #0xffffffff
    cd70:	d360fd09 	lsr	x9, x8, #32
    cd74:	9ac52403 	lsr	x3, x0, x5
    cd78:	9ac72021 	lsl	x1, x1, x7
    cd7c:	aa010063 	orr	x3, x3, x1
    cd80:	9ac72042 	lsl	x2, x2, x7
    cd84:	9ac908cb 	udiv	x11, x6, x9
    cd88:	9b099965 	msub	x5, x11, x9, x6
    cd8c:	aa0b03e1 	mov	x1, x11
    cd90:	9b0b7d46 	mul	x6, x10, x11
    cd94:	93c380a5 	extr	x5, x5, x3, #32
    cd98:	eb0500df 	cmp	x6, x5
    cd9c:	540000a9 	b.ls	cdb0 <__divti3+0x160>  // b.plast
    cda0:	ab050105 	adds	x5, x8, x5
    cda4:	d1000561 	sub	x1, x11, #0x1
    cda8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cdac:	54000f48 	b.hi	cf94 <__divti3+0x344>  // b.pmore
    cdb0:	cb0600a6 	sub	x6, x5, x6
    cdb4:	9ac908cb 	udiv	x11, x6, x9
    cdb8:	9b099969 	msub	x9, x11, x9, x6
    cdbc:	aa0b03e5 	mov	x5, x11
    cdc0:	9b0b7d4a 	mul	x10, x10, x11
    cdc4:	b3607d23 	bfi	x3, x9, #32, #32
    cdc8:	eb03015f 	cmp	x10, x3
    cdcc:	540000a9 	b.ls	cde0 <__divti3+0x190>  // b.plast
    cdd0:	ab030103 	adds	x3, x8, x3
    cdd4:	d1000565 	sub	x5, x11, #0x1
    cdd8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cddc:	54000e28 	b.hi	cfa0 <__divti3+0x350>  // b.pmore
    cde0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cde4:	92407c48 	and	x8, x2, #0xffffffff
    cde8:	2a0503e5 	mov	w5, w5
    cdec:	d360fc42 	lsr	x2, x2, #32
    cdf0:	d360fc26 	lsr	x6, x1, #32
    cdf4:	cb0a0063 	sub	x3, x3, x10
    cdf8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cdfc:	9b087caa 	mul	x10, x5, x8
    ce00:	9b087cc8 	mul	x8, x6, x8
    ce04:	9b0220a5 	madd	x5, x5, x2, x8
    ce08:	9b027cc6 	mul	x6, x6, x2
    ce0c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    ce10:	8b0900c5 	add	x5, x6, x9
    ce14:	eb02011f 	cmp	x8, x2
    ce18:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    ce1c:	8b4280c6 	add	x6, x6, x2, lsr #32
    ce20:	eb06007f 	cmp	x3, x6
    ce24:	540000e3 	b.cc	ce40 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    ce28:	92407d4a 	and	x10, x10, #0xffffffff
    ce2c:	9ac72000 	lsl	x0, x0, x7
    ce30:	8b028142 	add	x2, x10, x2, lsl #32
    ce34:	eb02001f 	cmp	x0, x2
    ce38:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    ce3c:	54000a01 	b.ne	cf7c <__divti3+0x32c>  // b.any
    ce40:	d1000420 	sub	x0, x1, #0x1
    ce44:	d2800001 	mov	x1, #0x0                   	// #0
    ce48:	17ffffb4 	b	cd18 <__divti3+0xc8>
    ce4c:	b5000062 	cbnz	x2, ce58 <__divti3+0x208>
    ce50:	d2800022 	mov	x2, #0x1                   	// #1
    ce54:	9ac30846 	udiv	x6, x2, x3
    ce58:	dac010c8 	clz	x8, x6
    ce5c:	b5000408 	cbnz	x8, cedc <__divti3+0x28c>
    ce60:	d360fcc9 	lsr	x9, x6, #32
    ce64:	92407cc5 	and	x5, x6, #0xffffffff
    ce68:	cb060023 	sub	x3, x1, x6
    ce6c:	d2800021 	mov	x1, #0x1                   	// #1
    ce70:	9ac90868 	udiv	x8, x3, x9
    ce74:	9b098d03 	msub	x3, x8, x9, x3
    ce78:	aa0803e0 	mov	x0, x8
    ce7c:	9b057d02 	mul	x2, x8, x5
    ce80:	93c78063 	extr	x3, x3, x7, #32
    ce84:	eb03005f 	cmp	x2, x3
    ce88:	540000a9 	b.ls	ce9c <__divti3+0x24c>  // b.plast
    ce8c:	ab0300c3 	adds	x3, x6, x3
    ce90:	d1000500 	sub	x0, x8, #0x1
    ce94:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ce98:	54000968 	b.hi	cfc4 <__divti3+0x374>  // b.pmore
    ce9c:	cb020063 	sub	x3, x3, x2
    cea0:	9ac90862 	udiv	x2, x3, x9
    cea4:	aa0203e8 	mov	x8, x2
    cea8:	9b098c42 	msub	x2, x2, x9, x3
    ceac:	aa0703e3 	mov	x3, x7
    ceb0:	9b057d05 	mul	x5, x8, x5
    ceb4:	b3607c43 	bfi	x3, x2, #32, #32
    ceb8:	eb0300bf 	cmp	x5, x3
    cebc:	540000c9 	b.ls	ced4 <__divti3+0x284>  // b.plast
    cec0:	ab0300c2 	adds	x2, x6, x3
    cec4:	d1000503 	sub	x3, x8, #0x1
    cec8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cecc:	d1000908 	sub	x8, x8, #0x2
    ced0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ced4:	aa008100 	orr	x0, x8, x0, lsl #32
    ced8:	17ffff90 	b	cd18 <__divti3+0xc8>
    cedc:	9ac820c6 	lsl	x6, x6, x8
    cee0:	d2800803 	mov	x3, #0x40                  	// #64
    cee4:	cb080063 	sub	x3, x3, x8
    cee8:	d360fcc9 	lsr	x9, x6, #32
    ceec:	9ac82027 	lsl	x7, x1, x8
    cef0:	92407cc5 	and	x5, x6, #0xffffffff
    cef4:	9ac32422 	lsr	x2, x1, x3
    cef8:	9ac32403 	lsr	x3, x0, x3
    cefc:	aa070063 	orr	x3, x3, x7
    cf00:	9ac9084a 	udiv	x10, x2, x9
    cf04:	9ac82007 	lsl	x7, x0, x8
    cf08:	9b098940 	msub	x0, x10, x9, x2
    cf0c:	aa0a03e1 	mov	x1, x10
    cf10:	9b0a7ca2 	mul	x2, x5, x10
    cf14:	93c38000 	extr	x0, x0, x3, #32
    cf18:	eb00005f 	cmp	x2, x0
    cf1c:	540000a9 	b.ls	cf30 <__divti3+0x2e0>  // b.plast
    cf20:	ab0000c0 	adds	x0, x6, x0
    cf24:	d1000541 	sub	x1, x10, #0x1
    cf28:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cf2c:	54000468 	b.hi	cfb8 <__divti3+0x368>  // b.pmore
    cf30:	cb020000 	sub	x0, x0, x2
    cf34:	9ac9080a 	udiv	x10, x0, x9
    cf38:	9b098140 	msub	x0, x10, x9, x0
    cf3c:	aa0a03e2 	mov	x2, x10
    cf40:	9b0a7ca8 	mul	x8, x5, x10
    cf44:	b3607c03 	bfi	x3, x0, #32, #32
    cf48:	eb03011f 	cmp	x8, x3
    cf4c:	540000a9 	b.ls	cf60 <__divti3+0x310>  // b.plast
    cf50:	ab0300c3 	adds	x3, x6, x3
    cf54:	d1000542 	sub	x2, x10, #0x1
    cf58:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cf5c:	54000288 	b.hi	cfac <__divti3+0x35c>  // b.pmore
    cf60:	cb080063 	sub	x3, x3, x8
    cf64:	aa018041 	orr	x1, x2, x1, lsl #32
    cf68:	17ffffc2 	b	ce70 <__divti3+0x220>
    cf6c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cf70:	d2800001 	mov	x1, #0x0                   	// #0
    cf74:	9a9f87e0 	cset	x0, ls	// ls = plast
    cf78:	17ffff68 	b	cd18 <__divti3+0xc8>
    cf7c:	aa0103e0 	mov	x0, x1
    cf80:	d2800001 	mov	x1, #0x0                   	// #0
    cf84:	17ffff65 	b	cd18 <__divti3+0xc8>
    cf88:	d1000860 	sub	x0, x3, #0x2
    cf8c:	8b0600a5 	add	x5, x5, x6
    cf90:	17ffff52 	b	ccd8 <__divti3+0x88>
    cf94:	d1000961 	sub	x1, x11, #0x2
    cf98:	8b0800a5 	add	x5, x5, x8
    cf9c:	17ffff85 	b	cdb0 <__divti3+0x160>
    cfa0:	d1000965 	sub	x5, x11, #0x2
    cfa4:	8b080063 	add	x3, x3, x8
    cfa8:	17ffff8e 	b	cde0 <__divti3+0x190>
    cfac:	d1000942 	sub	x2, x10, #0x2
    cfb0:	8b060063 	add	x3, x3, x6
    cfb4:	17ffffeb 	b	cf60 <__divti3+0x310>
    cfb8:	d1000941 	sub	x1, x10, #0x2
    cfbc:	8b060000 	add	x0, x0, x6
    cfc0:	17ffffdc 	b	cf30 <__divti3+0x2e0>
    cfc4:	d1000900 	sub	x0, x8, #0x2
    cfc8:	8b060063 	add	x3, x3, x6
    cfcc:	17ffffb4 	b	ce9c <__divti3+0x24c>

000000000000cfd0 <__modti3>:
    cfd0:	d503245f 	bti	c
    cfd4:	d2800004 	mov	x4, #0x0                   	// #0
    cfd8:	b6f80081 	tbz	x1, #63, cfe8 <__modti3+0x18>
    cfdc:	eb0003e0 	negs	x0, x0
    cfe0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cfe4:	da0103e1 	ngc	x1, x1
    cfe8:	f100007f 	cmp	x3, #0x0
    cfec:	5400128b 	b.lt	d23c <__modti3+0x26c>  // b.tstop
    cff0:	aa0003e7 	mov	x7, x0
    cff4:	aa0103e6 	mov	x6, x1
    cff8:	540004e1 	b.ne	d094 <__modti3+0xc4>  // b.any
    cffc:	eb02003f 	cmp	x1, x2
    d000:	54000dc2 	b.cs	d1b8 <__modti3+0x1e8>  // b.hs, b.nlast
    d004:	dac01043 	clz	x3, x2
    d008:	aa0303e5 	mov	x5, x3
    d00c:	b40000e3 	cbz	x3, d028 <__modti3+0x58>
    d010:	4b0303e6 	neg	w6, w3
    d014:	9ac32021 	lsl	x1, x1, x3
    d018:	9ac32042 	lsl	x2, x2, x3
    d01c:	9ac62406 	lsr	x6, x0, x6
    d020:	aa0100c6 	orr	x6, x6, x1
    d024:	9ac32007 	lsl	x7, x0, x3
    d028:	d360fc40 	lsr	x0, x2, #32
    d02c:	92407c43 	and	x3, x2, #0xffffffff
    d030:	9ac008c1 	udiv	x1, x6, x0
    d034:	9b009826 	msub	x6, x1, x0, x6
    d038:	9b017c61 	mul	x1, x3, x1
    d03c:	93c780c6 	extr	x6, x6, x7, #32
    d040:	eb06003f 	cmp	x1, x6
    d044:	540000a9 	b.ls	d058 <__modti3+0x88>  // b.plast
    d048:	ab060046 	adds	x6, x2, x6
    d04c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d050:	8b0200c8 	add	x8, x6, x2
    d054:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d058:	cb0100c6 	sub	x6, x6, x1
    d05c:	9ac008c8 	udiv	x8, x6, x0
    d060:	9b009901 	msub	x1, x8, x0, x6
    d064:	aa0703e0 	mov	x0, x7
    d068:	9b087c63 	mul	x3, x3, x8
    d06c:	b3607c20 	bfi	x0, x1, #32, #32
    d070:	eb00007f 	cmp	x3, x0
    d074:	54001088 	b.hi	d284 <__modti3+0x2b4>  // b.pmore
    d078:	cb030000 	sub	x0, x0, x3
    d07c:	9ac52400 	lsr	x0, x0, x5
    d080:	d2800001 	mov	x1, #0x0                   	// #0
    d084:	b4000064 	cbz	x4, d090 <__modti3+0xc0>
    d088:	eb0003e0 	negs	x0, x0
    d08c:	da0103e1 	ngc	x1, x1
    d090:	d65f03c0 	ret
    d094:	dac01066 	clz	x6, x3
    d098:	eb03003f 	cmp	x1, x3
    d09c:	54ffff43 	b.cc	d084 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d0a0:	93407cc5 	sxtw	x5, w6
    d0a4:	d2800808 	mov	x8, #0x40                  	// #64
    d0a8:	cb050108 	sub	x8, x8, x5
    d0ac:	9ac62063 	lsl	x3, x3, x6
    d0b0:	9ac62025 	lsl	x5, x1, x6
    d0b4:	9ac82447 	lsr	x7, x2, x8
    d0b8:	aa0300e7 	orr	x7, x7, x3
    d0bc:	9ac82423 	lsr	x3, x1, x8
    d0c0:	92407cec 	and	x12, x7, #0xffffffff
    d0c4:	d360fcea 	lsr	x10, x7, #32
    d0c8:	9ac82401 	lsr	x1, x0, x8
    d0cc:	aa050021 	orr	x1, x1, x5
    d0d0:	9ac62042 	lsl	x2, x2, x6
    d0d4:	9ac62000 	lsl	x0, x0, x6
    d0d8:	9aca086b 	udiv	x11, x3, x10
    d0dc:	9b0a8d63 	msub	x3, x11, x10, x3
    d0e0:	aa0b03e5 	mov	x5, x11
    d0e4:	9b0b7d89 	mul	x9, x12, x11
    d0e8:	93c18063 	extr	x3, x3, x1, #32
    d0ec:	eb03013f 	cmp	x9, x3
    d0f0:	540000a9 	b.ls	d104 <__modti3+0x134>  // b.plast
    d0f4:	ab0300e3 	adds	x3, x7, x3
    d0f8:	d1000565 	sub	x5, x11, #0x1
    d0fc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d100:	54001168 	b.hi	d32c <__modti3+0x35c>  // b.pmore
    d104:	cb090063 	sub	x3, x3, x9
    d108:	9aca086b 	udiv	x11, x3, x10
    d10c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d110:	aa0b03e9 	mov	x9, x11
    d114:	9b0b7d8c 	mul	x12, x12, x11
    d118:	b3607d41 	bfi	x1, x10, #32, #32
    d11c:	eb01019f 	cmp	x12, x1
    d120:	540000a9 	b.ls	d134 <__modti3+0x164>  // b.plast
    d124:	ab0100e1 	adds	x1, x7, x1
    d128:	d1000569 	sub	x9, x11, #0x1
    d12c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d130:	54000f88 	b.hi	d320 <__modti3+0x350>  // b.pmore
    d134:	aa058123 	orr	x3, x9, x5, lsl #32
    d138:	92407c4b 	and	x11, x2, #0xffffffff
    d13c:	2a0903e9 	mov	w9, w9
    d140:	d360fc4a 	lsr	x10, x2, #32
    d144:	d360fc63 	lsr	x3, x3, #32
    d148:	cb0c0021 	sub	x1, x1, x12
    d14c:	aa0a03ec 	mov	x12, x10
    d150:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d154:	9b0b7d25 	mul	x5, x9, x11
    d158:	9b0b7c6b 	mul	x11, x3, x11
    d15c:	9b0a2d29 	madd	x9, x9, x10, x11
    d160:	92407caa 	and	x10, x5, #0xffffffff
    d164:	9b0c7c63 	mul	x3, x3, x12
    d168:	8b458125 	add	x5, x9, x5, lsr #32
    d16c:	8b0d0069 	add	x9, x3, x13
    d170:	eb05017f 	cmp	x11, x5
    d174:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d178:	8b058149 	add	x9, x10, x5, lsl #32
    d17c:	8b458063 	add	x3, x3, x5, lsr #32
    d180:	eb03003f 	cmp	x1, x3
    d184:	54000063 	b.cc	d190 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d188:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d18c:	54000082 	b.cs	d19c <__modti3+0x1cc>  // b.hs, b.nlast
    d190:	eb020129 	subs	x9, x9, x2
    d194:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d198:	cb070063 	sub	x3, x3, x7
    d19c:	eb090000 	subs	x0, x0, x9
    d1a0:	da030021 	sbc	x1, x1, x3
    d1a4:	9ac62400 	lsr	x0, x0, x6
    d1a8:	9ac82028 	lsl	x8, x1, x8
    d1ac:	aa000100 	orr	x0, x8, x0
    d1b0:	9ac62421 	lsr	x1, x1, x6
    d1b4:	17ffffb4 	b	d084 <__modti3+0xb4>
    d1b8:	b5000062 	cbnz	x2, d1c4 <__modti3+0x1f4>
    d1bc:	d2800023 	mov	x3, #0x1                   	// #1
    d1c0:	9ac20862 	udiv	x2, x3, x2
    d1c4:	dac01048 	clz	x8, x2
    d1c8:	aa0803e5 	mov	x5, x8
    d1cc:	b5000668 	cbnz	x8, d298 <__modti3+0x2c8>
    d1d0:	cb020020 	sub	x0, x1, x2
    d1d4:	d360fc49 	lsr	x9, x2, #32
    d1d8:	92407c4a 	and	x10, x2, #0xffffffff
    d1dc:	9ac90801 	udiv	x1, x0, x9
    d1e0:	9b098020 	msub	x0, x1, x9, x0
    d1e4:	9b0a7c21 	mul	x1, x1, x10
    d1e8:	93c78000 	extr	x0, x0, x7, #32
    d1ec:	eb00003f 	cmp	x1, x0
    d1f0:	540000a9 	b.ls	d204 <__modti3+0x234>  // b.plast
    d1f4:	ab000040 	adds	x0, x2, x0
    d1f8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d1fc:	8b020003 	add	x3, x0, x2
    d200:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d204:	cb010001 	sub	x1, x0, x1
    d208:	9ac90820 	udiv	x0, x1, x9
    d20c:	9b098403 	msub	x3, x0, x9, x1
    d210:	aa0703e1 	mov	x1, x7
    d214:	9b0a7c00 	mul	x0, x0, x10
    d218:	b3607c61 	bfi	x1, x3, #32, #32
    d21c:	eb01001f 	cmp	x0, x1
    d220:	540000a9 	b.ls	d234 <__modti3+0x264>  // b.plast
    d224:	ab010041 	adds	x1, x2, x1
    d228:	8b020022 	add	x2, x1, x2
    d22c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d230:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d234:	cb000020 	sub	x0, x1, x0
    d238:	17ffff91 	b	d07c <__modti3+0xac>
    d23c:	eb0203e5 	negs	x5, x2
    d240:	aa0003e7 	mov	x7, x0
    d244:	da0303e8 	ngc	x8, x3
    d248:	aa0503e2 	mov	x2, x5
    d24c:	aa0803e3 	mov	x3, x8
    d250:	aa0103e6 	mov	x6, x1
    d254:	b4ffed48 	cbz	x8, cffc <__modti3+0x2c>
    d258:	eb01011f 	cmp	x8, x1
    d25c:	54fff148 	b.hi	d084 <__modti3+0xb4>  // b.pmore
    d260:	dac01109 	clz	x9, x8
    d264:	2a0903e6 	mov	w6, w9
    d268:	b5fff1c9 	cbnz	x9, d0a0 <__modti3+0xd0>
    d26c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d270:	54000068 	b.hi	d27c <__modti3+0x2ac>  // b.pmore
    d274:	eb050007 	subs	x7, x0, x5
    d278:	da080021 	sbc	x1, x1, x8
    d27c:	aa0703e0 	mov	x0, x7
    d280:	17ffff81 	b	d084 <__modti3+0xb4>
    d284:	ab000040 	adds	x0, x2, x0
    d288:	8b020002 	add	x2, x0, x2
    d28c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d290:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d294:	17ffff79 	b	d078 <__modti3+0xa8>
    d298:	9ac82042 	lsl	x2, x2, x8
    d29c:	d2800803 	mov	x3, #0x40                  	// #64
    d2a0:	cb080063 	sub	x3, x3, x8
    d2a4:	d360fc49 	lsr	x9, x2, #32
    d2a8:	9ac82027 	lsl	x7, x1, x8
    d2ac:	92407c4a 	and	x10, x2, #0xffffffff
    d2b0:	9ac32426 	lsr	x6, x1, x3
    d2b4:	9ac32403 	lsr	x3, x0, x3
    d2b8:	aa070063 	orr	x3, x3, x7
    d2bc:	9ac908c1 	udiv	x1, x6, x9
    d2c0:	9ac82007 	lsl	x7, x0, x8
    d2c4:	9b099820 	msub	x0, x1, x9, x6
    d2c8:	9b017d41 	mul	x1, x10, x1
    d2cc:	93c38000 	extr	x0, x0, x3, #32
    d2d0:	eb00003f 	cmp	x1, x0
    d2d4:	540000a9 	b.ls	d2e8 <__modti3+0x318>  // b.plast
    d2d8:	ab000040 	adds	x0, x2, x0
    d2dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d2e0:	8b020006 	add	x6, x0, x2
    d2e4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d2e8:	cb010000 	sub	x0, x0, x1
    d2ec:	9ac90801 	udiv	x1, x0, x9
    d2f0:	9b098026 	msub	x6, x1, x9, x0
    d2f4:	aa0303e0 	mov	x0, x3
    d2f8:	9b017d41 	mul	x1, x10, x1
    d2fc:	b3607cc0 	bfi	x0, x6, #32, #32
    d300:	eb00003f 	cmp	x1, x0
    d304:	540000a9 	b.ls	d318 <__modti3+0x348>  // b.plast
    d308:	ab000040 	adds	x0, x2, x0
    d30c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d310:	8b020003 	add	x3, x0, x2
    d314:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d318:	cb010000 	sub	x0, x0, x1
    d31c:	17ffffb0 	b	d1dc <__modti3+0x20c>
    d320:	d1000969 	sub	x9, x11, #0x2
    d324:	8b070021 	add	x1, x1, x7
    d328:	17ffff83 	b	d134 <__modti3+0x164>
    d32c:	d1000965 	sub	x5, x11, #0x2
    d330:	8b070063 	add	x3, x3, x7
    d334:	17ffff74 	b	d104 <__modti3+0x134>
    d338:	d503201f 	nop
    d33c:	d503201f 	nop

000000000000d340 <atexit>:
    d340:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d344:	f0000082 	adrp	x2, 20000 <__data_start>
    d348:	d2800001 	mov	x1, #0x0                   	// #0
    d34c:	910003fd 	mov	x29, sp
    d350:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d354:	f9400442 	ldr	x2, [x2, #8]
    d358:	17ffd512 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d35c <_fini>:
    d35c:	d503201f 	nop
    d360:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d364:	910003fd 	mov	x29, sp
    d368:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d36c:	d65f03c0 	ret
