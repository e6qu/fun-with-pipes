
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__modti3+0xf0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911820a5 	add	x5, x5, #0x608
    2aa0:	f0000044 	adrp	x4, d000 <__modti3+0xf0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91184084 	add	x4, x4, #0x610
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	91014261 	add	x1, x19, #0x50
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe9b0>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9006820 	str	x0, [x1, #208]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__modti3+0xf0>
    2b34:	912d6000 	add	x0, x0, #0xb58
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x2090>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91175042 	add	x2, x2, #0x5d4
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	91014273 	add	x19, x19, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943da60 	ldr	w0, [x19, #984]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff50 	bl	2990 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <__modti3+0xf0>
    2c7c:	912da000 	add	x0, x0, #0xb68
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97ffff07 	bl	28a0 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <__modti3+0xf0>
    2c8c:	91302000 	add	x0, x0, #0xc08
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffeee 	bl	2850 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <__modti3+0xf0>
    2ca4:	912f8000 	add	x0, x0, #0xbe0
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <__modti3+0xf0>
    2cb0:	912ec000 	add	x0, x0, #0xbb0
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <__modti3+0xf0>
    2cbc:	912e2000 	add	x0, x0, #0xb88
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91010000 	add	x0, x0, #0x40
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91010021 	add	x1, x1, #0x40
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91010000 	add	x0, x0, #0x40
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91010021 	add	x1, x1, #0x40
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xd50>
    2eb4:	91098021 	add	x1, x1, #0x260
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xd50>
    3158:	91090021 	add	x1, x1, #0x240
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    3190:	910ae000 	add	x0, x0, #0x2b8
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    31c4:	9118c2a1 	add	x1, x21, #0x630
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    31d8:	912880a5 	add	x5, x5, #0xa20
    31dc:	9118c2a1 	add	x1, x21, #0x630
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	9118c2b7 	add	x23, x21, #0x630
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	9118c2b5 	add	x21, x21, #0x630
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	9118c2b5 	add	x21, x21, #0x630
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    3368:	912860a5 	add	x5, x5, #0xa18
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000042 	adrp	x2, d000 <__modti3+0xf0>
    339c:	910b4042 	add	x2, x2, #0x2d0
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000042 	adrp	x2, d000 <__modti3+0xf0>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	910ca042 	add	x2, x2, #0x328
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000059 	adrp	x25, d000 <__modti3+0xf0>
    3428:	d000005a 	adrp	x26, d000 <__modti3+0xf0>
    342c:	910e2339 	add	x25, x25, #0x388
    3430:	910bc35a 	add	x26, x26, #0x2f0
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000005b 	adrp	x27, d000 <__modti3+0xf0>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	910be377 	add	x23, x27, #0x2f8
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	910f2000 	add	x0, x0, #0x3c8
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbb0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbb0>
    34fc:	d0000043 	adrp	x3, d000 <__modti3+0xf0>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000055 	adrp	x21, d000 <__modti3+0xf0>
    3508:	f9422824 	ldr	x4, [x1, #1104]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f9422ca5 	ldr	x5, [x5, #1112]
    3514:	91114033 	add	x19, x1, #0x450
    3518:	f9423046 	ldr	x6, [x2, #1120]
    351c:	910bc063 	add	x3, x3, #0x2f0
    3520:	910f82b5 	add	x21, x21, #0x3e0
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	91108000 	add	x0, x0, #0x420
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    35ac:	910c0000 	add	x0, x0, #0x300
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    366c:	910ae000 	add	x0, x0, #0x2b8
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <__modti3+0xf0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9110a021 	add	x1, x1, #0x428
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <__modti3+0xf0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	9110c021 	add	x1, x1, #0x430
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <__modti3+0xf0>
    37e0:	9110e021 	add	x1, x1, #0x438
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffe12 	bl	3074 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000042 	adrp	x2, d000 <__modti3+0xf0>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91110042 	add	x2, x2, #0x440
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc33 	bl	2910 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc60 	bl	29d0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc6e 	bl	2a10 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbbc 	bl	2750 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbdc 	bl	2840 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbbf 	bl	27f0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc17 	bl	2960 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    3950:	910ae000 	add	x0, x0, #0x2b8
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc12 	bl	29a0 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc1c 	bl	29d0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc2a 	bl	2a10 <_Exit@plt>
    396c:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    3970:	91114000 	add	x0, x0, #0x450
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb8a 	bl	27d0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    3a08:	9111c000 	add	x0, x0, #0x470
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffba4 	bl	28a0 <__stack_chk_fail@plt>
    3a14:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    3a18:	91124000 	add	x0, x0, #0x490
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xd50>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc09c20 	ldr	q0, [x1, #624]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	910142b5 	add	x21, x21, #0x50
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f9406aa2 	ldr	x2, [x21, #208]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb9f 	bl	2960 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    3b18:	9112e000 	add	x0, x0, #0x4b8
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb5f 	bl	28a0 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b3c:	91014063 	add	x3, x3, #0x50
    3b40:	9350fc01 	asr	x1, x0, #16
    3b44:	d1000440 	sub	x0, x2, #0x1
    3b48:	f9406c62 	ldr	x2, [x3, #216]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9404463 	ldr	x3, [x3, #136]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    3b88:	9113a000 	add	x0, x0, #0x4e8
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000044 	adrp	x4, d000 <__modti3+0xf0>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	9114e084 	add	x4, x4, #0x538
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffb06 	bl	2810 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb5f 	bl	2980 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb4a 	bl	2940 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa93 	bl	26f0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffacb 	bl	27f0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffabc 	bl	27f0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa74 	bl	26f0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa80 	bl	2730 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb10 	bl	2980 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000044 	adrp	x4, d000 <__modti3+0xf0>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	91154084 	add	x4, x4, #0x550
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa90 	bl	2810 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa7f 	bl	27f0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffadf 	bl	2980 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000044 	adrp	x4, d000 <__modti3+0xf0>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	91150084 	add	x4, x4, #0x540
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa68 	bl	2810 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa52 	bl	27f0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa26 	bl	27f0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa42 	bl	28a0 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    3fa8:	9118c042 	add	x2, x2, #0x630
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000041 	adrp	x1, d000 <__modti3+0xf0>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000040 	adrp	x0, d000 <__modti3+0xf0>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	91156021 	add	x1, x1, #0x558
    4004:	91158000 	add	x0, x0, #0x560
    4008:	97fffa0a 	bl	2830 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa87 	bl	2a50 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa35 	bl	2940 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa74 	bl	2a50 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9e5 	bl	2820 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000042 	adrp	x2, d000 <__modti3+0xf0>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	91160042 	add	x2, x2, #0x580
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa08 	b	2910 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9d0>
    410c:	9114c061 	add	x1, x3, #0x530
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    411c:	9118c262 	add	x2, x19, #0x630
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0xd50>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9d0>
    414c:	9115c021 	add	x1, x1, #0x570
    4150:	3dc0a043 	ldr	q3, [x2, #640]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9d0>
    417c:	9114c063 	add	x3, x3, #0x530
    4180:	91174084 	add	x4, x4, #0x5d0
    4184:	9118c266 	add	x6, x19, #0x630
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9cd 	bl	2930 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	9118c275 	add	x21, x19, #0x630
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9b7 	bl	2930 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    4268:	9118c000 	add	x0, x0, #0x630
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9f0 	bl	2a30 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	9118c273 	add	x19, x19, #0x630
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffbac 	bl	3170 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	91014122 	add	x2, x9, #0x50
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9406046 	ldr	x6, [x2, #192]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	91014120 	add	x0, x9, #0x50
    4354:	f900640b 	str	x11, [x0, #200]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	91014129 	add	x9, x9, #0x50
    4360:	f9006126 	str	x6, [x9, #192]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <ad_raw_free.part.0>:
    4380:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbb0>
    4384:	d2800001 	mov	x1, #0x0                   	// #0
    4388:	91114082 	add	x2, x4, #0x450
    438c:	14000005 	b	43a0 <ad_raw_free.part.0+0x20>
    4390:	91000421 	add	x1, x1, #0x1
    4394:	91006042 	add	x2, x2, #0x18
    4398:	f140043f 	cmp	x1, #0x1, lsl #12
    439c:	54000220 	b.eq	43e0 <ad_raw_free.part.0+0x60>  // b.none
    43a0:	f9400043 	ldr	x3, [x2]
    43a4:	eb03001f 	cmp	x0, x3
    43a8:	54ffff41 	b.ne	4390 <ad_raw_free.part.0+0x10>  // b.any
    43ac:	8b010421 	add	x1, x1, x1, lsl #1
    43b0:	91114084 	add	x4, x4, #0x450
    43b4:	900000e2 	adrp	x2, 20000 <__data_start>
    43b8:	91014042 	add	x2, x2, #0x50
    43bc:	8b010c81 	add	x1, x4, x1, lsl #3
    43c0:	b9401024 	ldr	w4, [x1, #16]
    43c4:	f9400425 	ldr	x5, [x1, #8]
    43c8:	a9007c3f 	stp	xzr, xzr, [x1]
    43cc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    43d0:	f900083f 	str	xzr, [x1, #16]
    43d4:	cb050061 	sub	x1, x3, x5
    43d8:	f8247841 	str	x1, [x2, x4, lsl #3]
    43dc:	17fff961 	b	2960 <free@plt>
    43e0:	f100001f 	cmp	x0, #0x0
    43e4:	b0000041 	adrp	x1, d000 <__modti3+0xf0>
    43e8:	91196021 	add	x1, x1, #0x658
    43ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    43f0:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    43f4:	91190000 	add	x0, x0, #0x640
    43f8:	910003fd 	mov	x29, sp
    43fc:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4400:	97fffbe0 	bl	3380 <ad_raw_fail>

0000000000004404 <fwp_tape_buffers_dispose>:
    4404:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4408:	910003fd 	mov	x29, sp
    440c:	f9000bf3 	str	x19, [sp, #16]
    4410:	aa0003f3 	mov	x19, x0
    4414:	f9400000 	ldr	x0, [x0]
    4418:	b4000040 	cbz	x0, 4420 <fwp_tape_buffers_dispose+0x1c>
    441c:	97ffffd9 	bl	4380 <ad_raw_free.part.0>
    4420:	f9400a60 	ldr	x0, [x19, #16]
    4424:	b4000040 	cbz	x0, 442c <fwp_tape_buffers_dispose+0x28>
    4428:	97ffffd6 	bl	4380 <ad_raw_free.part.0>
    442c:	f9401260 	ldr	x0, [x19, #32]
    4430:	b4000040 	cbz	x0, 4438 <fwp_tape_buffers_dispose+0x34>
    4434:	97ffffd3 	bl	4380 <ad_raw_free.part.0>
    4438:	4f000400 	movi	v0.4s, #0x0
    443c:	f9001a7f 	str	xzr, [x19, #48]
    4440:	ad000260 	stp	q0, q0, [x19]
    4444:	3d800a60 	str	q0, [x19, #32]
    4448:	f9400bf3 	ldr	x19, [sp, #16]
    444c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4450:	d65f03c0 	ret

0000000000004454 <ad_raw_realloc>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	f90013f5 	str	x21, [sp, #32]
    4464:	b40005a1 	cbz	x1, 4518 <ad_raw_realloc+0xc4>
    4468:	aa0103f4 	mov	x20, x1
    446c:	2a0203f5 	mov	w21, w2
    4470:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbb0>
    4474:	d2800004 	mov	x4, #0x0                   	// #0
    4478:	91114025 	add	x5, x1, #0x450
    447c:	14000005 	b	4490 <ad_raw_realloc+0x3c>
    4480:	91000484 	add	x4, x4, #0x1
    4484:	910060a5 	add	x5, x5, #0x18
    4488:	f140049f 	cmp	x4, #0x1, lsl #12
    448c:	54000320 	b.eq	44f0 <ad_raw_realloc+0x9c>  // b.none
    4490:	f94000a6 	ldr	x6, [x5]
    4494:	eb06001f 	cmp	x0, x6
    4498:	54ffff41 	b.ne	4480 <ad_raw_realloc+0x2c>  // b.any
    449c:	8b040484 	add	x4, x4, x4, lsl #1
    44a0:	91114021 	add	x1, x1, #0x450
    44a4:	8b040c33 	add	x19, x1, x4, lsl #3
    44a8:	b4000080 	cbz	x0, 44b8 <ad_raw_realloc+0x64>
    44ac:	b9401261 	ldr	w1, [x19, #16]
    44b0:	6b15003f 	cmp	w1, w21
    44b4:	540002c1 	b.ne	450c <ad_raw_realloc+0xb8>  // b.any
    44b8:	aa1403e1 	mov	x1, x20
    44bc:	97fff8f5 	bl	2890 <realloc@plt>
    44c0:	aa0003ed 	mov	x13, x0
    44c4:	b40000c0 	cbz	x0, 44dc <ad_raw_realloc+0x88>
    44c8:	2a1503e3 	mov	w3, w21
    44cc:	aa1403e2 	mov	x2, x20
    44d0:	aa1303e0 	mov	x0, x19
    44d4:	aa0d03e1 	mov	x1, x13
    44d8:	97fffaae 	bl	2f90 <ad_raw_record>
    44dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e0:	aa0d03e0 	mov	x0, x13
    44e4:	f94013f5 	ldr	x21, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	f100001f 	cmp	x0, #0x0
    44f4:	b0000041 	adrp	x1, d000 <__modti3+0xf0>
    44f8:	91196021 	add	x1, x1, #0x658
    44fc:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    4500:	91190000 	add	x0, x0, #0x640
    4504:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4508:	97fffb9e 	bl	3380 <ad_raw_fail>
    450c:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    4510:	911a6000 	add	x0, x0, #0x698
    4514:	97fffb9b 	bl	3380 <ad_raw_fail>
    4518:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    451c:	9119e000 	add	x0, x0, #0x678
    4520:	97fffb98 	bl	3380 <ad_raw_fail>

0000000000004524 <fwp_tape_buffers_release>:
    4524:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4528:	910003fd 	mov	x29, sp
    452c:	a90153f3 	stp	x19, x20, [sp, #16]
    4530:	aa0003f4 	mov	x20, x0
    4534:	f9401400 	ldr	x0, [x0, #40]
    4538:	a9025bf5 	stp	x21, x22, [sp, #32]
    453c:	b7f80560 	tbnz	x0, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4540:	f9401a93 	ldr	x19, [x20, #48]
    4544:	b7f80533 	tbnz	x19, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4548:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    454c:	eb01001f 	cmp	x0, x1
    4550:	540004c8 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4554:	8b000400 	add	x0, x0, x0, lsl #1
    4558:	d2a00101 	mov	x1, #0x80000               	// #524288
    455c:	d37df000 	lsl	x0, x0, #3
    4560:	cb000021 	sub	x1, x1, x0
    4564:	eb410e7f 	cmp	x19, x1, lsr #3
    4568:	54000408 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    456c:	8b130c13 	add	x19, x0, x19, lsl #3
    4570:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    4574:	911ac000 	add	x0, x0, #0x6b0
    4578:	97fff92e 	bl	2a30 <getenv@plt>
    457c:	b4000080 	cbz	x0, 458c <fwp_tape_buffers_release+0x68>
    4580:	39400001 	ldrb	w1, [x0]
    4584:	7100c03f 	cmp	w1, #0x30
    4588:	54000880 	b.eq	4698 <fwp_tape_buffers_release+0x174>  // b.none
    458c:	d1000661 	sub	x1, x19, #0x1
    4590:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4594:	eb00003f 	cmp	x1, x0
    4598:	54000328 	b.hi	45fc <fwp_tape_buffers_release+0xd8>  // b.pmore
    459c:	900000f5 	adrp	x21, 20000 <__data_start>
    45a0:	f9001bf7 	str	x23, [sp, #48]
    45a4:	910142b7 	add	x23, x21, #0x50
    45a8:	910382f6 	add	x22, x23, #0xe0
    45ac:	aa1603e0 	mov	x0, x22
    45b0:	97ffff95 	bl	4404 <fwp_tape_buffers_dispose>
    45b4:	ad400a81 	ldp	q1, q2, [x20]
    45b8:	f9008ef3 	str	x19, [x23, #280]
    45bc:	4f000400 	movi	v0.4s, #0x0
    45c0:	ad000ac1 	stp	q1, q2, [x22]
    45c4:	3dc00a81 	ldr	q1, [x20, #32]
    45c8:	3d800ac1 	str	q1, [x22, #32]
    45cc:	f9401a80 	ldr	x0, [x20, #48]
    45d0:	f9001ac0 	str	x0, [x22, #48]
    45d4:	f9001a9f 	str	xzr, [x20, #48]
    45d8:	ad000280 	stp	q0, q0, [x20]
    45dc:	3d800a80 	str	q0, [x20, #32]
    45e0:	f9401bf7 	ldr	x23, [sp, #48]
    45e4:	1400000b 	b	4610 <fwp_tape_buffers_release+0xec>
    45e8:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    45ec:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    45f0:	911ac000 	add	x0, x0, #0x6b0
    45f4:	97fff90f 	bl	2a30 <getenv@plt>
    45f8:	b5fffc40 	cbnz	x0, 4580 <fwp_tape_buffers_release+0x5c>
    45fc:	aa1403e0 	mov	x0, x20
    4600:	97ffff81 	bl	4404 <fwp_tape_buffers_dispose>
    4604:	900000f5 	adrp	x21, 20000 <__data_start>
    4608:	910142a0 	add	x0, x21, #0x50
    460c:	f9408c13 	ldr	x19, [x0, #280]
    4610:	910142a2 	add	x2, x21, #0x50
    4614:	f9409044 	ldr	x4, [x2, #288]
    4618:	a9400c45 	ldp	x5, x3, [x2]
    461c:	8b040481 	add	x1, x4, x4, lsl #1
    4620:	f9400840 	ldr	x0, [x2, #16]
    4624:	8b010881 	add	x1, x4, x1, lsl #2
    4628:	f9400c44 	ldr	x4, [x2, #24]
    462c:	8b0300a3 	add	x3, x5, x3
    4630:	d37df021 	lsl	x1, x1, #3
    4634:	8b040000 	add	x0, x0, x4
    4638:	8b030000 	add	x0, x0, x3
    463c:	eb05003f 	cmp	x1, x5
    4640:	54000321 	b.ne	46a4 <fwp_tape_buffers_release+0x180>  // b.any
    4644:	8b130023 	add	x3, x1, x19
    4648:	eb00007f 	cmp	x3, x0
    464c:	540002c8 	b.hi	46a4 <fwp_tape_buffers_release+0x180>  // b.pmore
    4650:	f9405c43 	ldr	x3, [x2, #184]
    4654:	f140087f 	cmp	x3, #0x2, lsl #12
    4658:	540002e0 	b.eq	46b4 <fwp_tape_buffers_release+0x190>  // b.none
    465c:	8b030464 	add	x4, x3, x3, lsl #1
    4660:	90000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    4664:	911140a5 	add	x5, x5, #0x450
    4668:	cb010000 	sub	x0, x0, x1
    466c:	d37df084 	lsl	x4, x4, #3
    4670:	cb130000 	sub	x0, x0, x19
    4674:	8b0400a6 	add	x6, x5, x4
    4678:	91000463 	add	x3, x3, #0x1
    467c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4680:	f82468a1 	str	x1, [x5, x4]
    4684:	a90080d3 	stp	x19, x0, [x6, #8]
    4688:	f9005c43 	str	x3, [x2, #184]
    468c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4690:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4694:	d65f03c0 	ret
    4698:	39400400 	ldrb	w0, [x0, #1]
    469c:	34fffb00 	cbz	w0, 45fc <fwp_tape_buffers_release+0xd8>
    46a0:	17ffffbb 	b	458c <fwp_tape_buffers_release+0x68>
    46a4:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    46a8:	911b2000 	add	x0, x0, #0x6c8
    46ac:	f9001bf7 	str	x23, [sp, #48]
    46b0:	97fffb34 	bl	3380 <ad_raw_fail>
    46b4:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    46b8:	911be000 	add	x0, x0, #0x6f8
    46bc:	f9001bf7 	str	x23, [sp, #48]
    46c0:	97fffb30 	bl	3380 <ad_raw_fail>

00000000000046c4 <fwp_poll_events>:
    46c4:	d10103ff 	sub	sp, sp, #0x40
    46c8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    46cc:	f947f400 	ldr	x0, [x0, #4072]
    46d0:	a9027bfd 	stp	x29, x30, [sp, #32]
    46d4:	910083fd 	add	x29, sp, #0x20
    46d8:	a90353f3 	stp	x19, x20, [sp, #48]
    46dc:	900000f4 	adrp	x20, 20000 <__data_start>
    46e0:	f9400001 	ldr	x1, [x0]
    46e4:	f9000fe1 	str	x1, [sp, #24]
    46e8:	d2800001 	mov	x1, #0x0                   	// #0
    46ec:	97fffca5 	bl	3980 <fwp_now_ns>
    46f0:	91014281 	add	x1, x20, #0x50
    46f4:	f9409433 	ldr	x19, [x1, #296]
    46f8:	b4000e73 	cbz	x19, 48c4 <fwp_poll_events+0x200>
    46fc:	aa1303e1 	mov	x1, x19
    4700:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4704:	14000005 	b	4718 <fwp_poll_events+0x54>
    4708:	f9408821 	ldr	x1, [x1, #272]
    470c:	eb03005f 	cmp	x2, x3
    4710:	9a83d042 	csel	x2, x2, x3, le
    4714:	b40000c1 	cbz	x1, 472c <fwp_poll_events+0x68>
    4718:	f9403423 	ldr	x3, [x1, #104]
    471c:	b6ffff62 	tbz	x2, #63, 4708 <fwp_poll_events+0x44>
    4720:	f9408821 	ldr	x1, [x1, #272]
    4724:	aa0303e2 	mov	x2, x3
    4728:	b5ffff81 	cbnz	x1, 4718 <fwp_poll_events+0x54>
    472c:	b7f80cc2 	tbnz	x2, #63, 48c4 <fwp_poll_events+0x200>
    4730:	cb000042 	sub	x2, x2, x0
    4734:	f100005f 	cmp	x2, #0x0
    4738:	540005ad 	b.le	47ec <fwp_poll_events+0x128>
    473c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4740:	d2884801 	mov	x1, #0x4240                	// #16960
    4744:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4748:	f2a001e1 	movk	x1, #0xf, lsl #16
    474c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4750:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4754:	f2e86360 	movk	x0, #0x431b, lsl #48
    4758:	9b407c40 	smulh	x0, x2, x0
    475c:	9352fc00 	asr	x0, x0, #18
    4760:	cb82fc00 	sub	x0, x0, x2, asr #63
    4764:	9b018802 	msub	x2, x0, x1, x2
    4768:	f100005f 	cmp	x2, #0x0
    476c:	9a800400 	cinc	x0, x0, ne	// ne = any
    4770:	eb03001f 	cmp	x0, x3
    4774:	540009ec 	b.gt	48b0 <fwp_poll_events+0x1ec>
    4778:	340003a0 	cbz	w0, 47ec <fwp_poll_events+0x128>
    477c:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4780:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4784:	72a20c42 	movk	w2, #0x1062, lsl #16
    4788:	9ba27c02 	umull	x2, w0, w2
    478c:	d366fc43 	lsr	x3, x2, #38
    4790:	aa0303e2 	mov	x2, x3
    4794:	1b048063 	msub	w3, w3, w4, w0
    4798:	9b217c63 	smull	x3, w3, w1
    479c:	d2800001 	mov	x1, #0x0                   	// #0
    47a0:	910023e0 	add	x0, sp, #0x8
    47a4:	a9008fe2 	stp	x2, x3, [sp, #8]
    47a8:	97fff872 	bl	2970 <nanosleep@plt>
    47ac:	91014280 	add	x0, x20, #0x50
    47b0:	f9409413 	ldr	x19, [x0, #296]
    47b4:	97fffc73 	bl	3980 <fwp_now_ns>
    47b8:	aa0003e6 	mov	x6, x0
    47bc:	b50001d3 	cbnz	x19, 47f4 <fwp_poll_events+0x130>
    47c0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    47c4:	f947f400 	ldr	x0, [x0, #4072]
    47c8:	f9400fe2 	ldr	x2, [sp, #24]
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	eb010042 	subs	x2, x2, x1
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	540008c1 	b.ne	48f0 <fwp_poll_events+0x22c>  // b.any
    47dc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    47e0:	a94353f3 	ldp	x19, x20, [sp, #48]
    47e4:	910103ff 	add	sp, sp, #0x40
    47e8:	d65f03c0 	ret
    47ec:	97fffc65 	bl	3980 <fwp_now_ns>
    47f0:	aa0003e6 	mov	x6, x0
    47f4:	4f000400 	movi	v0.4s, #0x0
    47f8:	91014288 	add	x8, x20, #0x50
    47fc:	52800027 	mov	w7, #0x1                   	// #1
    4800:	f9403661 	ldr	x1, [x19, #104]
    4804:	aa1303e5 	mov	x5, x19
    4808:	f9408a73 	ldr	x19, [x19, #272]
    480c:	eb06003f 	cmp	x1, x6
    4810:	5400032c 	b.gt	4874 <fwp_poll_events+0x1b0>
    4814:	394154a0 	ldrb	w0, [x5, #85]
    4818:	36000120 	tbz	w0, #0, 483c <fwp_poll_events+0x178>
    481c:	f94084a0 	ldr	x0, [x5, #264]
    4820:	b40003c0 	cbz	x0, 4898 <fwp_poll_events+0x1d4>
    4824:	f9008813 	str	x19, [x0, #272]
    4828:	b4000053 	cbz	x19, 4830 <fwp_poll_events+0x16c>
    482c:	f9008660 	str	x0, [x19, #264]
    4830:	910800a0 	add	x0, x5, #0x200
    4834:	390154bf 	strb	wzr, [x5, #85]
    4838:	3c908000 	stur	q0, [x0, #-248]
    483c:	f94030a0 	ldr	x0, [x5, #96]
    4840:	390158a7 	strb	w7, [x5, #86]
    4844:	f100001f 	cmp	x0, #0x0
    4848:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    484c:	5400018d 	b.le	487c <fwp_poll_events+0x1b8>
    4850:	f94028a0 	ldr	x0, [x5, #80]
    4854:	f2001c1f 	tst	x0, #0xff000000ff
    4858:	540000e1 	b.ne	4874 <fwp_poll_events+0x1b0>  // b.any
    485c:	f9406100 	ldr	x0, [x8, #192]
    4860:	390150a7 	strb	w7, [x5, #84]
    4864:	f90080bf 	str	xzr, [x5, #256]
    4868:	b40001e0 	cbz	x0, 48a4 <fwp_poll_events+0x1e0>
    486c:	f9006105 	str	x5, [x8, #192]
    4870:	f9008005 	str	x5, [x0, #256]
    4874:	b5fffc73 	cbnz	x19, 4800 <fwp_poll_events+0x13c>
    4878:	17ffffd2 	b	47c0 <fwp_poll_events+0xfc>
    487c:	394144a0 	ldrb	w0, [x5, #81]
    4880:	3707fe80 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    4884:	394140a0 	ldrb	w0, [x5, #80]
    4888:	3707fe40 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    488c:	aa0503e0 	mov	x0, x5
    4890:	97fffb98 	bl	36f0 <fwp_cancel_tree.part.0>
    4894:	17ffffef 	b	4850 <fwp_poll_events+0x18c>
    4898:	91014281 	add	x1, x20, #0x50
    489c:	f9009433 	str	x19, [x1, #296]
    48a0:	17ffffe2 	b	4828 <fwp_poll_events+0x164>
    48a4:	f9006105 	str	x5, [x8, #192]
    48a8:	f9006505 	str	x5, [x8, #200]
    48ac:	17fffff2 	b	4874 <fwp_poll_events+0x1b0>
    48b0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    48b4:	d2989362 	mov	x2, #0xc49b                	// #50331
    48b8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    48bc:	f2a00402 	movk	x2, #0x20, lsl #16
    48c0:	17ffffb7 	b	479c <fwp_poll_events+0xd8>
    48c4:	97fff9ec 	bl	3074 <fwp_flush>
    48c8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    48cc:	f947e863 	ldr	x3, [x3, #4048]
    48d0:	d2800562 	mov	x2, #0x2b                  	// #43
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    48dc:	911c6000 	add	x0, x0, #0x718
    48e0:	f9400063 	ldr	x3, [x3]
    48e4:	97fff82f 	bl	29a0 <fwrite@plt>
    48e8:	52800ca0 	mov	w0, #0x65                  	// #101
    48ec:	97fff799 	bl	2750 <exit@plt>
    48f0:	97fff7ec 	bl	28a0 <__stack_chk_fail@plt>

00000000000048f4 <fwp_rc_wide_dup>:
    48f4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48f8:	910003fd 	mov	x29, sp
    48fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4900:	aa0003f3 	mov	x19, x0
    4904:	ca404400 	eor	x0, x0, x0, lsr #17
    4908:	f90013f5 	str	x21, [sp, #32]
    490c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4910:	ca402400 	eor	x0, x0, x0, lsr #9
    4914:	9118c2a2 	add	x2, x21, #0x630
    4918:	92401c00 	and	x0, x0, #0xff
    491c:	910a2403 	add	x3, x0, #0x289
    4920:	8b000c40 	add	x0, x2, x0, lsl #3
    4924:	8b030c54 	add	x20, x2, x3, lsl #3
    4928:	f94a2401 	ldr	x1, [x0, #5192]
    492c:	b50000a1 	cbnz	x1, 4940 <fwp_rc_wide_dup+0x4c>
    4930:	1400002d 	b	49e4 <fwp_rc_wide_dup+0xf0>
    4934:	91004034 	add	x20, x1, #0x10
    4938:	f9400821 	ldr	x1, [x1, #16]
    493c:	b4000241 	cbz	x1, 4984 <fwp_rc_wide_dup+0x90>
    4940:	f9400022 	ldr	x2, [x1]
    4944:	eb02027f 	cmp	x19, x2
    4948:	54ffff61 	b.ne	4934 <fwp_rc_wide_dup+0x40>  // b.any
    494c:	f9400281 	ldr	x1, [x20]
    4950:	39400260 	ldrb	w0, [x19]
    4954:	7103f81f 	cmp	w0, #0xfe
    4958:	54000220 	b.eq	499c <fwp_rc_wide_dup+0xa8>  // b.none
    495c:	b40001a1 	cbz	x1, 4990 <fwp_rc_wide_dup+0x9c>
    4960:	f9400420 	ldr	x0, [x1, #8]
    4964:	b100041f 	cmn	x0, #0x1
    4968:	540004a0 	b.eq	49fc <fwp_rc_wide_dup+0x108>  // b.none
    496c:	91000400 	add	x0, x0, #0x1
    4970:	f9000420 	str	x0, [x1, #8]
    4974:	a94153f3 	ldp	x19, x20, [sp, #16]
    4978:	f94013f5 	ldr	x21, [sp, #32]
    497c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4980:	d65f03c0 	ret
    4984:	39400260 	ldrb	w0, [x19]
    4988:	7103f81f 	cmp	w0, #0xfe
    498c:	540000a0 	b.eq	49a0 <fwp_rc_wide_dup+0xac>  // b.none
    4990:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    4994:	911dc000 	add	x0, x0, #0x770
    4998:	97fffb9a 	bl	3800 <fwp_trap>
    499c:	b5000281 	cbnz	x1, 49ec <fwp_rc_wide_dup+0xf8>
    49a0:	d2800300 	mov	x0, #0x18                  	// #24
    49a4:	97fff7a7 	bl	2840 <malloc@plt>
    49a8:	b4000280 	cbz	x0, 49f8 <fwp_rc_wide_dup+0x104>
    49ac:	d2801fe1 	mov	x1, #0xff                  	// #255
    49b0:	a9000413 	stp	x19, x1, [x0]
    49b4:	9118c2b5 	add	x21, x21, #0x630
    49b8:	f900081f 	str	xzr, [x0, #16]
    49bc:	12800001 	mov	w1, #0xffffffff            	// #-1
    49c0:	f9000280 	str	x0, [x20]
    49c4:	39000261 	strb	w1, [x19]
    49c8:	f94e26a0 	ldr	x0, [x21, #7240]
    49cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    49d0:	91000400 	add	x0, x0, #0x1
    49d4:	f90e26a0 	str	x0, [x21, #7240]
    49d8:	f94013f5 	ldr	x21, [sp, #32]
    49dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49e0:	d65f03c0 	ret
    49e4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    49e8:	17ffffda 	b	4950 <fwp_rc_wide_dup+0x5c>
    49ec:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    49f0:	911d2000 	add	x0, x0, #0x748
    49f4:	97fffb83 	bl	3800 <fwp_trap>
    49f8:	97fff9de 	bl	3170 <fwp_heap_oom>
    49fc:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    4a00:	911e6000 	add	x0, x0, #0x798
    4a04:	97fffb7f 	bl	3800 <fwp_trap>
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_rc_forget_slot>:
    4a10:	aa0003e1 	mov	x1, x0
    4a14:	39400000 	ldrb	w0, [x0]
    4a18:	7103fc1f 	cmp	w0, #0xff
    4a1c:	54000040 	b.eq	4a24 <fwp_rc_forget_slot+0x14>  // b.none
    4a20:	d65f03c0 	ret
    4a24:	ca414420 	eor	x0, x1, x1, lsr #17
    4a28:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4a2c:	ca402400 	eor	x0, x0, x0, lsr #9
    4a30:	910003fd 	mov	x29, sp
    4a34:	92401c00 	and	x0, x0, #0xff
    4a38:	f9000bf3 	str	x19, [sp, #16]
    4a3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4a40:	9118c262 	add	x2, x19, #0x630
    4a44:	910a2403 	add	x3, x0, #0x289
    4a48:	8b000c40 	add	x0, x2, x0, lsl #3
    4a4c:	8b030c43 	add	x3, x2, x3, lsl #3
    4a50:	f94a2400 	ldr	x0, [x0, #5192]
    4a54:	b50000a0 	cbnz	x0, 4a68 <fwp_rc_forget_slot+0x58>
    4a58:	14000011 	b	4a9c <fwp_rc_forget_slot+0x8c>
    4a5c:	91004003 	add	x3, x0, #0x10
    4a60:	f9400800 	ldr	x0, [x0, #16]
    4a64:	b40001c0 	cbz	x0, 4a9c <fwp_rc_forget_slot+0x8c>
    4a68:	f9400002 	ldr	x2, [x0]
    4a6c:	eb02003f 	cmp	x1, x2
    4a70:	54ffff61 	b.ne	4a5c <fwp_rc_forget_slot+0x4c>  // b.any
    4a74:	f9400801 	ldr	x1, [x0, #16]
    4a78:	9118c273 	add	x19, x19, #0x630
    4a7c:	f9000061 	str	x1, [x3]
    4a80:	97fff7b8 	bl	2960 <free@plt>
    4a84:	f94e2660 	ldr	x0, [x19, #7240]
    4a88:	d1000400 	sub	x0, x0, #0x1
    4a8c:	f90e2660 	str	x0, [x19, #7240]
    4a90:	f9400bf3 	ldr	x19, [sp, #16]
    4a94:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a98:	d65f03c0 	ret
    4a9c:	b0000040 	adrp	x0, d000 <__modti3+0xf0>
    4aa0:	911dc000 	add	x0, x0, #0x770
    4aa4:	97fffb57 	bl	3800 <fwp_trap>
    4aa8:	d503201f 	nop
    4aac:	d503201f 	nop

0000000000004ab0 <fwp_rc_prepare_chunk>:
    4ab0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ab4:	910003fd 	mov	x29, sp
    4ab8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4abc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    4ac0:	9118c2c2 	add	x2, x22, #0x630
    4ac4:	b9401c03 	ldr	w3, [x0, #28]
    4ac8:	aa0103f5 	mov	x21, x1
    4acc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ad0:	aa0003f4 	mov	x20, x0
    4ad4:	f94e2440 	ldr	x0, [x2, #7240]
    4ad8:	b4000440 	cbz	x0, 4b60 <fwp_rc_prepare_chunk+0xb0>
    4adc:	d2800013 	mov	x19, #0x0                   	// #0
    4ae0:	35000203 	cbnz	w3, 4b20 <fwp_rc_prepare_chunk+0x70>
    4ae4:	b4000361 	cbz	x1, 4b50 <fwp_rc_prepare_chunk+0xa0>
    4ae8:	f9401280 	ldr	x0, [x20, #32]
    4aec:	97fff79d 	bl	2960 <free@plt>
    4af0:	aa1503e0 	mov	x0, x21
    4af4:	d2800021 	mov	x1, #0x1                   	// #1
    4af8:	97fff762 	bl	2880 <calloc@plt>
    4afc:	f9001280 	str	x0, [x20, #32]
    4b00:	b5000460 	cbnz	x0, 4b8c <fwp_rc_prepare_chunk+0xdc>
    4b04:	97fff99b 	bl	3170 <fwp_heap_oom>
    4b08:	97ffffc2 	bl	4a10 <fwp_rc_forget_slot>
    4b0c:	91000673 	add	x19, x19, #0x1
    4b10:	b9401e83 	ldr	w3, [x20, #28]
    4b14:	eb13007f 	cmp	x3, x19
    4b18:	54000169 	b.ls	4b44 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4b1c:	d503201f 	nop
    4b20:	f9401283 	ldr	x3, [x20, #32]
    4b24:	8b130060 	add	x0, x3, x19
    4b28:	38736863 	ldrb	w3, [x3, x19]
    4b2c:	7103fc7f 	cmp	w3, #0xff
    4b30:	54fffec0 	b.eq	4b08 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b34:	b9401e83 	ldr	w3, [x20, #28]
    4b38:	91000673 	add	x19, x19, #0x1
    4b3c:	eb13007f 	cmp	x3, x19
    4b40:	54ffff08 	b.hi	4b20 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b44:	eb0302bf 	cmp	x21, x3
    4b48:	54000121 	b.ne	4b6c <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b4c:	b5000335 	cbnz	x21, 4bb0 <fwp_rc_prepare_chunk+0x100>
    4b50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b5c:	d65f03c0 	ret
    4b60:	2a0303e3 	mov	w3, w3
    4b64:	eb0302bf 	cmp	x21, x3
    4b68:	54ffff20 	b.eq	4b4c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4b6c:	9118c2c2 	add	x2, x22, #0x630
    4b70:	f9401280 	ldr	x0, [x20, #32]
    4b74:	f94e2841 	ldr	x1, [x2, #7248]
    4b78:	cb030021 	sub	x1, x1, x3
    4b7c:	f90e2841 	str	x1, [x2, #7248]
    4b80:	97fff778 	bl	2960 <free@plt>
    4b84:	b5fffb75 	cbnz	x21, 4af0 <fwp_rc_prepare_chunk+0x40>
    4b88:	f900129f 	str	xzr, [x20, #32]
    4b8c:	9118c2d6 	add	x22, x22, #0x630
    4b90:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b94:	b9001e95 	str	w21, [x20, #28]
    4b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b9c:	8b150000 	add	x0, x0, x21
    4ba0:	f90e2ac0 	str	x0, [x22, #7248]
    4ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bac:	d65f03c0 	ret
    4bb0:	f9401280 	ldr	x0, [x20, #32]
    4bb4:	aa1503e2 	mov	x2, x21
    4bb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bbc:	52800001 	mov	w1, #0x0                   	// #0
    4bc0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bc8:	17fff72a 	b	2870 <memset@plt>
    4bcc:	d503201f 	nop

0000000000004bd0 <fwp_heap_refill>:
    4bd0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4bd4:	910003fd 	mov	x29, sp
    4bd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4bdc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4be0:	9118c2b5 	add	x21, x21, #0x630
    4be4:	aa0003f6 	mov	x22, x0
    4be8:	d2800020 	mov	x0, #0x1                   	// #1
    4bec:	a90153f3 	stp	x19, x20, [sp, #16]
    4bf0:	a90363f7 	stp	x23, x24, [sp, #48]
    4bf4:	2a0103f7 	mov	w23, w1
    4bf8:	2a0203f8 	mov	w24, w2
    4bfc:	97fff96d 	bl	31b0 <fwp_heap_chunks>
    4c00:	aa0003f3 	mov	x19, x0
    4c04:	f949fea2 	ldr	x2, [x21, #5112]
    4c08:	8b000800 	add	x0, x0, x0, lsl #2
    4c0c:	2a1703e1 	mov	w1, w23
    4c10:	52800025 	mov	w5, #0x1                   	// #1
    4c14:	d37df000 	lsl	x0, x0, #3
    4c18:	910f0021 	add	x1, x1, #0x3c0
    4c1c:	8b000054 	add	x20, x2, x0
    4c20:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4c24:	52a00024 	mov	w4, #0x10000               	// #65536
    4c28:	38206845 	strb	w5, [x2, x0]
    4c2c:	aa1403e0 	mov	x0, x20
    4c30:	39000698 	strb	w24, [x20, #1]
    4c34:	39000a97 	strb	w23, [x20, #2]
    4c38:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c3c:	b9000681 	str	w1, [x20, #4]
    4c40:	2a0103e5 	mov	w5, w1
    4c44:	8b0300a2 	add	x2, x5, x3
    4c48:	1ac10881 	udiv	w1, w4, w1
    4c4c:	9ac50842 	udiv	x2, x2, x5
    4c50:	b9000a81 	str	w1, [x20, #8]
    4c54:	92404021 	and	x1, x1, #0x1ffff
    4c58:	b9001a82 	str	w2, [x20, #24]
    4c5c:	97ffff95 	bl	4ab0 <fwp_rc_prepare_chunk>
    4c60:	f949daa0 	ldr	x0, [x21, #5040]
    4c64:	29408a81 	ldp	w1, w2, [x20, #4]
    4c68:	8b134000 	add	x0, x0, x19, lsl #16
    4c6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c70:	8b214003 	add	x3, x0, w1, uxtw
    4c74:	9ba20021 	umaddl	x1, w1, w2, x0
    4c78:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c7c:	a90086c3 	stp	x3, x1, [x22, #8]
    4c80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c84:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c88:	d65f03c0 	ret
    4c8c:	d503201f 	nop

0000000000004c90 <fwp_mem_free>:
    4c90:	b40003c0 	cbz	x0, 4d08 <fwp_mem_free+0x78>
    4c94:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c98:	910003fd 	mov	x29, sp
    4c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ca0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4ca4:	9118c2a1 	add	x1, x21, #0x630
    4ca8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cac:	aa0003f3 	mov	x19, x0
    4cb0:	f949d823 	ldr	x3, [x1, #5040]
    4cb4:	f949ec22 	ldr	x2, [x1, #5080]
    4cb8:	cb030000 	sub	x0, x0, x3
    4cbc:	eb02401f 	cmp	x0, x2, lsl #16
    4cc0:	540001c2 	b.cs	4cf8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4cc4:	d350fc16 	lsr	x22, x0, #16
    4cc8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ccc:	f949fc22 	ldr	x2, [x1, #5112]
    4cd0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4cd4:	d37df294 	lsl	x20, x20, #3
    4cd8:	ab140057 	adds	x23, x2, x20
    4cdc:	540000c0 	b.eq	4cf4 <fwp_mem_free+0x64>  // b.none
    4ce0:	38746842 	ldrb	w2, [x2, x20]
    4ce4:	7100045f 	cmp	w2, #0x1
    4ce8:	54000120 	b.eq	4d0c <fwp_mem_free+0x7c>  // b.none
    4cec:	7100085f 	cmp	w2, #0x2
    4cf0:	540005e0 	b.eq	4dac <fwp_mem_free+0x11c>  // b.none
    4cf4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d00:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d04:	d65f03c0 	ret
    4d08:	d65f03c0 	ret
    4d0c:	f94012f8 	ldr	x24, [x23, #32]
    4d10:	b94006e1 	ldr	w1, [x23, #4]
    4d14:	f90023f9 	str	x25, [sp, #64]
    4d18:	2a0103e2 	mov	w2, w1
    4d1c:	394006f9 	ldrb	w25, [x23, #1]
    4d20:	39400af4 	ldrb	w20, [x23, #2]
    4d24:	b4000158 	cbz	x24, 4d4c <fwp_mem_free+0xbc>
    4d28:	92403e76 	and	x22, x19, #0xffff
    4d2c:	9ac20ad6 	udiv	x22, x22, x2
    4d30:	38766b01 	ldrb	w1, [x24, x22]
    4d34:	8b160300 	add	x0, x24, x22
    4d38:	7103fc3f 	cmp	w1, #0xff
    4d3c:	54000980 	b.eq	4e6c <fwp_mem_free+0x1dc>  // b.none
    4d40:	38366b1f 	strb	wzr, [x24, x22]
    4d44:	b94006e1 	ldr	w1, [x23, #4]
    4d48:	2a0103e2 	mov	w2, w1
    4d4c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4d50:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4d54:	cb390000 	sub	x0, x0, w25, uxtb
    4d58:	8b340074 	add	x20, x3, w20, uxtb
    4d5c:	9118c2b5 	add	x21, x21, #0x630
    4d60:	1e630021 	ucvtf	d1, w1
    4d64:	d37ae400 	lsl	x0, x0, #6
    4d68:	8b140c14 	add	x20, x0, x20, lsl #3
    4d6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d70:	f8746aa0 	ldr	x0, [x21, x20]
    4d74:	f94023f9 	ldr	x25, [sp, #64]
    4d78:	aa2003e0 	mvn	x0, x0
    4d7c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d80:	f9000260 	str	x0, [x19]
    4d84:	f8346ab3 	str	x19, [x21, x20]
    4d88:	f94a12a0 	ldr	x0, [x21, #5152]
    4d8c:	1e612800 	fadd	d0, d0, d1
    4d90:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d94:	cb020000 	sub	x0, x0, x2
    4d98:	f90a12a0 	str	x0, [x21, #5152]
    4d9c:	fd0a22a0 	str	d0, [x21, #5184]
    4da0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4da4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4da8:	d65f03c0 	ret
    4dac:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4db0:	8b000063 	add	x3, x3, x0
    4db4:	eb03027f 	cmp	x19, x3
    4db8:	54fff9e1 	b.ne	4cf4 <fwp_mem_free+0x64>  // b.any
    4dbc:	fd400ae1 	ldr	d1, [x23, #16]
    4dc0:	fd4a2020 	ldr	d0, [x1, #5184]
    4dc4:	f9400ae0 	ldr	x0, [x23, #16]
    4dc8:	7e61d821 	ucvtf	d1, d1
    4dcc:	f94a1022 	ldr	x2, [x1, #5152]
    4dd0:	f94012f3 	ldr	x19, [x23, #32]
    4dd4:	1e612800 	fadd	d0, d0, d1
    4dd8:	cb000042 	sub	x2, x2, x0
    4ddc:	f90a1022 	str	x2, [x1, #5152]
    4de0:	fd0a2020 	str	d0, [x1, #5184]
    4de4:	b40000b3 	cbz	x19, 4df8 <fwp_mem_free+0x168>
    4de8:	39400260 	ldrb	w0, [x19]
    4dec:	7103fc1f 	cmp	w0, #0xff
    4df0:	54000380 	b.eq	4e60 <fwp_mem_free+0x1d0>  // b.none
    4df4:	3900027f 	strb	wzr, [x19]
    4df8:	b9400ee2 	ldr	w2, [x23, #12]
    4dfc:	b4000142 	cbz	x2, 4e24 <fwp_mem_free+0x194>
    4e00:	9118c2a1 	add	x1, x21, #0x630
    4e04:	8b160040 	add	x0, x2, x22
    4e08:	8b000800 	add	x0, x0, x0, lsl #2
    4e0c:	f949fc21 	ldr	x1, [x1, #5112]
    4e10:	8b140034 	add	x20, x1, x20
    4e14:	8b000c20 	add	x0, x1, x0, lsl #3
    4e18:	3802869f 	strb	wzr, [x20], #40
    4e1c:	eb00029f 	cmp	x20, x0
    4e20:	54ffffc1 	b.ne	4e18 <fwp_mem_free+0x188>  // b.any
    4e24:	9118c2a0 	add	x0, x21, #0x630
    4e28:	f94a1801 	ldr	x1, [x0, #5168]
    4e2c:	f949f803 	ldr	x3, [x0, #5104]
    4e30:	8b020021 	add	x1, x1, x2
    4e34:	f90a1801 	str	x1, [x0, #5168]
    4e38:	eb16007f 	cmp	x3, x22
    4e3c:	54000049 	b.ls	4e44 <fwp_mem_free+0x1b4>  // b.plast
    4e40:	f909f816 	str	x22, [x0, #5104]
    4e44:	9118c2b5 	add	x21, x21, #0x630
    4e48:	f949f6a0 	ldr	x0, [x21, #5096]
    4e4c:	eb16001f 	cmp	x0, x22
    4e50:	54fff529 	b.ls	4cf4 <fwp_mem_free+0x64>  // b.plast
    4e54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e58:	f909f6b6 	str	x22, [x21, #5096]
    4e5c:	17ffffa7 	b	4cf8 <fwp_mem_free+0x68>
    4e60:	aa1303e0 	mov	x0, x19
    4e64:	97fffeeb 	bl	4a10 <fwp_rc_forget_slot>
    4e68:	17ffffe3 	b	4df4 <fwp_mem_free+0x164>
    4e6c:	97fffee9 	bl	4a10 <fwp_rc_forget_slot>
    4e70:	17ffffb4 	b	4d40 <fwp_mem_free+0xb0>

0000000000004e74 <fwp_heap_alloc_big>:
    4e74:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e78:	910003fd 	mov	x29, sp
    4e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4e80:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e84:	a90363f7 	stp	x23, x24, [sp, #48]
    4e88:	aa0003f7 	mov	x23, x0
    4e8c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e90:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e94:	eb0002ff 	cmp	x23, x0
    4e98:	54000888 	b.hi	4fa8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e9c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4ea0:	8b0002f4 	add	x20, x23, x0
    4ea4:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbb0>
    4ea8:	9118c359 	add	x25, x26, #0x630
    4eac:	d350fe94 	lsr	x20, x20, #16
    4eb0:	2a0103f5 	mov	w21, w1
    4eb4:	aa1403e0 	mov	x0, x20
    4eb8:	97fff8be 	bl	31b0 <fwp_heap_chunks>
    4ebc:	f949ff22 	ldr	x2, [x25, #5112]
    4ec0:	8b000813 	add	x19, x0, x0, lsl #2
    4ec4:	aa0003f8 	mov	x24, x0
    4ec8:	52800043 	mov	w3, #0x2                   	// #2
    4ecc:	d37df273 	lsl	x19, x19, #3
    4ed0:	d2800021 	mov	x1, #0x1                   	// #1
    4ed4:	8b130040 	add	x0, x2, x19
    4ed8:	38336843 	strb	w3, [x2, x19]
    4edc:	39000415 	strb	w21, [x0, #1]
    4ee0:	b9000c14 	str	w20, [x0, #12]
    4ee4:	f9000817 	str	x23, [x0, #16]
    4ee8:	97fffef2 	bl	4ab0 <fwp_rc_prepare_chunk>
    4eec:	f100069f 	cmp	x20, #0x1
    4ef0:	54000269 	b.ls	4f3c <fwp_heap_alloc_big+0xc8>  // b.plast
    4ef4:	8b180294 	add	x20, x20, x24
    4ef8:	9100a273 	add	x19, x19, #0x28
    4efc:	a90573fb 	stp	x27, x28, [sp, #80]
    4f00:	5280007b 	mov	w27, #0x3                   	// #3
    4f04:	8b140a94 	add	x20, x20, x20, lsl #2
    4f08:	2a1803fc 	mov	w28, w24
    4f0c:	9adb2296 	lsl	x22, x20, x27
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffee4 	bl	4ab0 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0x9c>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	9118c353 	add	x19, x26, #0x630
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x104>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118c35a 	add	x26, x26, #0x630
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4fc0:	9118c262 	add	x2, x19, #0x630
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	9118c262 	add	x2, x19, #0x630
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	9118c260 	add	x0, x19, #0x630
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	9118c273 	add	x19, x19, #0x630
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffc1c 	bl	4104 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff70 	b	4e74 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	9118c260 	add	x0, x19, #0x630
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffeb5 	bl	4bd0 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	54000861 	b.ne	5244 <fwp_heap_alloc+0x134>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    5140:	9118c2f3 	add	x19, x23, #0x630
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	540006e2 	b.cs	5290 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	9118c2e0 	add	x0, x23, #0x630
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	9118c2e1 	add	x1, x23, #0x630
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	540002cc 	b.gt	5258 <fwp_heap_alloc+0x148>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000209 	b.ls	5274 <fwp_heap_alloc+0x164>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	17ffffe8 	b	51e0 <fwp_heap_alloc+0xd0>
    5244:	a9538c44 	ldp	x4, x3, [x2, #312]
    5248:	91000484 	add	x4, x4, #0x1
    524c:	8b000063 	add	x3, x3, x0
    5250:	a9138c44 	stp	x4, x3, [x2, #312]
    5254:	17ffffba 	b	513c <fwp_heap_alloc+0x2c>
    5258:	a94153f3 	ldp	x19, x20, [sp, #16]
    525c:	fd00a800 	str	d0, [x0, #336]
    5260:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5264:	aa0403e0 	mov	x0, x4
    5268:	a94363f7 	ldp	x23, x24, [sp, #48]
    526c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5270:	d65f03c0 	ret
    5274:	7100043f 	cmp	w1, #0x1
    5278:	8b140085 	add	x5, x4, x20
    527c:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5280:	52800001 	mov	w1, #0x0                   	// #0
    5284:	aa0403e0 	mov	x0, x4
    5288:	f9000465 	str	x5, [x3, #8]
    528c:	17ffffc6 	b	51a4 <fwp_heap_alloc+0x94>
    5290:	97fff7b8 	bl	3170 <fwp_heap_oom>

0000000000005294 <fwp_data.part.0.constprop.0>:
    5294:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5298:	910003fd 	mov	x29, sp
    529c:	a9025bf5 	stp	x21, x22, [sp, #32]
    52a0:	f00000d6 	adrp	x22, 20000 <__data_start>
    52a4:	910142c2 	add	x2, x22, #0x50
    52a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52ac:	b9413059 	ldr	w25, [x2, #304]
    52b0:	a90153f3 	stp	x19, x20, [sp, #16]
    52b4:	aa0103f4 	mov	x20, x1
    52b8:	a90363f7 	stp	x23, x24, [sp, #48]
    52bc:	2a0003f7 	mov	w23, w0
    52c0:	340000b9 	cbz	w25, 52d4 <fwp_data.part.0.constprop.0+0x40>
    52c4:	a9538041 	ldp	x1, x0, [x2, #312]
    52c8:	91000421 	add	x1, x1, #0x1
    52cc:	91006000 	add	x0, x0, #0x18
    52d0:	a9138041 	stp	x1, x0, [x2, #312]
    52d4:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    52d8:	9118c2a3 	add	x3, x21, #0x630
    52dc:	b953a460 	ldr	w0, [x3, #5028]
    52e0:	34000840 	cbz	w0, 53e8 <fwp_data.part.0.constprop.0+0x154>
    52e4:	397e8862 	ldrb	w2, [x3, #4002]
    52e8:	910f0040 	add	x0, x2, #0x3c0
    52ec:	8b020442 	add	x2, x2, x2, lsl #1
    52f0:	d37df042 	lsl	x2, x2, #3
    52f4:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    52f8:	2a1a03f8 	mov	w24, w26
    52fc:	f8626873 	ldr	x19, [x3, x2]
    5300:	b4000613 	cbz	x19, 53c0 <fwp_data.part.0.constprop.0+0x12c>
    5304:	f9400260 	ldr	x0, [x19]
    5308:	aa2003e0 	mvn	x0, x0
    530c:	f8226860 	str	x0, [x3, x2]
    5310:	f100631f 	cmp	x24, #0x18
    5314:	540000e9 	b.ls	5330 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5318:	d1006702 	sub	x2, x24, #0x19
    531c:	91006260 	add	x0, x19, #0x18
    5320:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5324:	52800001 	mov	w1, #0x0                   	// #0
    5328:	91002042 	add	x2, x2, #0x8
    532c:	97fff551 	bl	2870 <memset@plt>
    5330:	9118c2a0 	add	x0, x21, #0x630
    5334:	f94a1001 	ldr	x1, [x0, #5152]
    5338:	ab180021 	adds	x1, x1, x24
    533c:	54000642 	b.cs	5404 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5340:	f94a1402 	ldr	x2, [x0, #5160]
    5344:	f90a1001 	str	x1, [x0, #5152]
    5348:	eb02003f 	cmp	x1, x2
    534c:	54000049 	b.ls	5354 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5350:	f90a1401 	str	x1, [x0, #5160]
    5354:	9118c2a0 	add	x0, x21, #0x630
    5358:	1e630341 	ucvtf	d1, w26
    535c:	fd4a1c00 	ldr	d0, [x0, #5176]
    5360:	1e612800 	fadd	d0, d0, d1
    5364:	fd0a1c00 	str	d0, [x0, #5176]
    5368:	34000139 	cbz	w25, 538c <fwp_data.part.0.constprop.0+0xf8>
    536c:	9118c2b5 	add	x21, x21, #0x630
    5370:	910142d6 	add	x22, x22, #0x50
    5374:	fd4a12a0 	ldr	d0, [x21, #5152]
    5378:	6d5486c2 	ldp	d2, d1, [x22, #328]
    537c:	7e61d800 	ucvtf	d0, d0
    5380:	1e623800 	fsub	d0, d0, d2
    5384:	1e612010 	fcmpe	d0, d1
    5388:	540003ac 	b.gt	53fc <fwp_data.part.0.constprop.0+0x168>
    538c:	52800040 	mov	w0, #0x2                   	// #2
    5390:	29000277 	stp	w23, w0, [x19]
    5394:	aa1303e0 	mov	x0, x19
    5398:	f9400281 	ldr	x1, [x20]
    539c:	f9000661 	str	x1, [x19, #8]
    53a0:	f9400681 	ldr	x1, [x20, #8]
    53a4:	f9000a61 	str	x1, [x19, #16]
    53a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    53ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53b4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53bc:	d65f03c0 	ret
    53c0:	8b020063 	add	x3, x3, x2
    53c4:	f9400473 	ldr	x19, [x3, #8]
    53c8:	b4000113 	cbz	x19, 53e8 <fwp_data.part.0.constprop.0+0x154>
    53cc:	f9400860 	ldr	x0, [x3, #16]
    53d0:	cb130000 	sub	x0, x0, x19
    53d4:	eb00031f 	cmp	x24, x0
    53d8:	54000088 	b.hi	53e8 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53dc:	8b180260 	add	x0, x19, x24
    53e0:	f9000460 	str	x0, [x3, #8]
    53e4:	17ffffcb 	b	5310 <fwp_data.part.0.constprop.0+0x7c>
    53e8:	52800001 	mov	w1, #0x0                   	// #0
    53ec:	d2800300 	mov	x0, #0x18                  	// #24
    53f0:	97ffff48 	bl	5110 <fwp_heap_alloc>
    53f4:	aa0003f3 	mov	x19, x0
    53f8:	17ffffdc 	b	5368 <fwp_data.part.0.constprop.0+0xd4>
    53fc:	fd00aac0 	str	d0, [x22, #336]
    5400:	17ffffe3 	b	538c <fwp_data.part.0.constprop.0+0xf8>
    5404:	97fff75b 	bl	3170 <fwp_heap_oom>
    5408:	d503201f 	nop
    540c:	d503201f 	nop

0000000000005410 <fwp_p_ad_push>:
    5410:	f100001f 	cmp	x0, #0x0
    5414:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    5418:	54000eab 	b.lt	55ec <fwp_p_ad_push+0x1dc>  // b.tstop
    541c:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5420:	aa0003e4 	mov	x4, x0
    5424:	910003fd 	mov	x29, sp
    5428:	a9025bf5 	stp	x21, x22, [sp, #32]
    542c:	aa0003f5 	mov	x21, x0
    5430:	aa020000 	orr	x0, x0, x2
    5434:	a90363f7 	stp	x23, x24, [sp, #48]
    5438:	aa0203f7 	mov	x23, x2
    543c:	6d0627e8 	stp	d8, d9, [sp, #96]
    5440:	9e670029 	fmov	d9, x1
    5444:	9e670068 	fmov	d8, x3
    5448:	b6f80920 	tbz	x0, #63, 556c <fwp_p_ad_push+0x15c>
    544c:	a90153f3 	stp	x19, x20, [sp, #16]
    5450:	9360fc80 	asr	x0, x4, #32
    5454:	b6f800c4 	tbz	x4, #63, 546c <fwp_p_ad_push+0x5c>
    5458:	1e604109 	fmov	d9, d8
    545c:	2f00e408 	movi	d8, #0x0
    5460:	9360fc40 	asr	x0, x2, #32
    5464:	aa0203f5 	mov	x21, x2
    5468:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    546c:	97fff9b1 	bl	3b30 <fwp_tape_of>
    5470:	aa0003f3 	mov	x19, x0
    5474:	f9403000 	ldr	x0, [x0, #96]
    5478:	b5001240 	cbnz	x0, 56c0 <fwp_p_ad_push+0x2b0>
    547c:	f9400a76 	ldr	x22, [x19, #16]
    5480:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5484:	eb0002df 	cmp	x22, x0
    5488:	54000d8c 	b.gt	5638 <fwp_p_ad_push+0x228>
    548c:	eb3542df 	cmp	x22, w21, uxtw
    5490:	54000cad 	b.le	5624 <fwp_p_ad_push+0x214>
    5494:	b7f80077 	tbnz	x23, #63, 54a0 <fwp_p_ad_push+0x90>
    5498:	eb3742df 	cmp	x22, w23, uxtw
    549c:	54000c4d 	b.le	5624 <fwp_p_ad_push+0x214>
    54a0:	f9400678 	ldr	x24, [x19, #8]
    54a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54a8:	cb1802d8 	sub	x24, x22, x24
    54ac:	91000701 	add	x1, x24, #0x1
    54b0:	eb00003f 	cmp	x1, x0
    54b4:	54000c28 	b.hi	5638 <fwp_p_ad_push+0x228>  // b.pmore
    54b8:	a9418274 	ldp	x20, x0, [x19, #24]
    54bc:	a90573fb 	stp	x27, x28, [sp, #80]
    54c0:	eb14003f 	cmp	x1, x20
    54c4:	540006ad 	b.le	5598 <fwp_p_ad_push+0x188>
    54c8:	f100029f 	cmp	x20, #0x0
    54cc:	d2800803 	mov	x3, #0x40                  	// #64
    54d0:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54d4:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54d8:	a9046bf9 	stp	x25, x26, [sp, #64]
    54dc:	eb14003f 	cmp	x1, x20
    54e0:	5400008d 	b.le	54f0 <fwp_p_ad_push+0xe0>
    54e4:	eb02029f 	cmp	x20, x2
    54e8:	5400054d 	b.le	5590 <fwp_p_ad_push+0x180>
    54ec:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    54f0:	d37df299 	lsl	x25, x20, #3
    54f4:	52800022 	mov	w2, #0x1                   	// #1
    54f8:	aa1903e1 	mov	x1, x25
    54fc:	97fffbd6 	bl	4454 <ad_raw_realloc>
    5500:	aa0003e1 	mov	x1, x0
    5504:	b4000a40 	cbz	x0, 564c <fwp_p_ad_push+0x23c>
    5508:	f9400e63 	ldr	x3, [x19, #24]
    550c:	f9001261 	str	x1, [x19, #32]
    5510:	f9401a60 	ldr	x0, [x19, #48]
    5514:	52800042 	mov	w2, #0x2                   	// #2
    5518:	8b030821 	add	x1, x1, x3, lsl #2
    551c:	f9001661 	str	x1, [x19, #40]
    5520:	d37cee81 	lsl	x1, x20, #4
    5524:	97fffbcc 	bl	4454 <ad_raw_realloc>
    5528:	aa0003e2 	mov	x2, x0
    552c:	b4000900 	cbz	x0, 564c <fwp_p_ad_push+0x23c>
    5530:	f9400e61 	ldr	x1, [x19, #24]
    5534:	d37df31b 	lsl	x27, x24, #3
    5538:	d37ef69a 	lsl	x26, x20, #2
    553c:	d37ef71c 	lsl	x28, x24, #2
    5540:	8b190003 	add	x3, x0, x25
    5544:	8b010c01 	add	x1, x0, x1, lsl #3
    5548:	a9030660 	stp	x0, x1, [x19, #48]
    554c:	b5000558 	cbnz	x24, 55f4 <fwp_p_ad_push+0x1e4>
    5550:	f9001e63 	str	x3, [x19, #56]
    5554:	f9401260 	ldr	x0, [x19, #32]
    5558:	8b1a0001 	add	x1, x0, x26
    555c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5560:	f9000e74 	str	x20, [x19, #24]
    5564:	f9001661 	str	x1, [x19, #40]
    5568:	14000010 	b	55a8 <fwp_p_ad_push+0x198>
    556c:	9360fc40 	asr	x0, x2, #32
    5570:	a90153f3 	stp	x19, x20, [sp, #16]
    5574:	eb84801f 	cmp	x0, x4, asr #32
    5578:	54fff7a0 	b.eq	546c <fwp_p_ad_push+0x5c>  // b.none
    557c:	90000040 	adrp	x0, d000 <__modti3+0xf0>
    5580:	911ee000 	add	x0, x0, #0x7b8
    5584:	a9046bf9 	stp	x25, x26, [sp, #64]
    5588:	a90573fb 	stp	x27, x28, [sp, #80]
    558c:	97fff89d 	bl	3800 <fwp_trap>
    5590:	d37ffa94 	lsl	x20, x20, #1
    5594:	17ffffd2 	b	54dc <fwp_p_ad_push+0xcc>
    5598:	a9428a61 	ldp	x1, x2, [x19, #40]
    559c:	d37ef71c 	lsl	x28, x24, #2
    55a0:	f9401e63 	ldr	x3, [x19, #56]
    55a4:	d37df31b 	lsl	x27, x24, #3
    55a8:	b83c6815 	str	w21, [x0, x28]
    55ac:	f10002ff 	cmp	x23, #0x0
    55b0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    55b4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55b8:	fc3b6849 	str	d9, [x2, x27]
    55bc:	aa1602a0 	orr	x0, x21, x22
    55c0:	b83c6837 	str	w23, [x1, x28]
    55c4:	910006d6 	add	x22, x22, #0x1
    55c8:	a94363f7 	ldp	x23, x24, [sp, #48]
    55cc:	fc3b6868 	str	d8, [x3, x27]
    55d0:	a94573fb 	ldp	x27, x28, [sp, #80]
    55d4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55d8:	f9000a76 	str	x22, [x19, #16]
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    55e8:	d65f03c0 	ret
    55ec:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55f0:	d65f03c0 	ret
    55f4:	aa0303e0 	mov	x0, x3
    55f8:	aa1b03e2 	mov	x2, x27
    55fc:	97fff445 	bl	2710 <memmove@plt>
    5600:	a9420660 	ldp	x0, x1, [x19, #32]
    5604:	aa1c03e2 	mov	x2, x28
    5608:	f9401a63 	ldr	x3, [x19, #48]
    560c:	8b190063 	add	x3, x3, x25
    5610:	f9001e63 	str	x3, [x19, #56]
    5614:	8b1a0000 	add	x0, x0, x26
    5618:	97fff43e 	bl	2710 <memmove@plt>
    561c:	a9430e62 	ldp	x2, x3, [x19, #48]
    5620:	17ffffcd 	b	5554 <fwp_p_ad_push+0x144>
    5624:	90000040 	adrp	x0, d000 <__modti3+0xf0>
    5628:	91214000 	add	x0, x0, #0x850
    562c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5630:	a90573fb 	stp	x27, x28, [sp, #80]
    5634:	97fff873 	bl	3800 <fwp_trap>
    5638:	90000040 	adrp	x0, d000 <__modti3+0xf0>
    563c:	9120c000 	add	x0, x0, #0x830
    5640:	a9046bf9 	stp	x25, x26, [sp, #64]
    5644:	a90573fb 	stp	x27, x28, [sp, #80]
    5648:	97fff86e 	bl	3800 <fwp_trap>
    564c:	aa1303e0 	mov	x0, x19
    5650:	97fff671 	bl	3014 <fwp_tape_unlink_scope>
    5654:	f9401260 	ldr	x0, [x19, #32]
    5658:	b4000040 	cbz	x0, 5660 <fwp_p_ad_push+0x250>
    565c:	97fffb49 	bl	4380 <ad_raw_free.part.0>
    5660:	f9401a60 	ldr	x0, [x19, #48]
    5664:	b4000040 	cbz	x0, 566c <fwp_p_ad_push+0x25c>
    5668:	97fffb46 	bl	4380 <ad_raw_free.part.0>
    566c:	f9402260 	ldr	x0, [x19, #64]
    5670:	b4000040 	cbz	x0, 5678 <fwp_p_ad_push+0x268>
    5674:	97fffb43 	bl	4380 <ad_raw_free.part.0>
    5678:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    567c:	f947e821 	ldr	x1, [x1, #4048]
    5680:	f9000e7f 	str	xzr, [x19, #24]
    5684:	4f000400 	movi	v0.4s, #0x0
    5688:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    568c:	d2800262 	mov	x2, #0x13                  	// #19
    5690:	f9400023 	ldr	x3, [x1]
    5694:	b900067f 	str	wzr, [x19, #4]
    5698:	d2800021 	mov	x1, #0x1                   	// #1
    569c:	90000040 	adrp	x0, d000 <__modti3+0xf0>
    56a0:	910ae000 	add	x0, x0, #0x2b8
    56a4:	3c808260 	stur	q0, [x19, #8]
    56a8:	ad010260 	stp	q0, q0, [x19, #32]
    56ac:	97fff4bd 	bl	29a0 <fwrite@plt>
    56b0:	d2800000 	mov	x0, #0x0                   	// #0
    56b4:	97fff4c7 	bl	29d0 <fflush@plt>
    56b8:	52800cc0 	mov	w0, #0x66                  	// #102
    56bc:	97fff4d5 	bl	2a10 <_Exit@plt>
    56c0:	90000040 	adrp	x0, d000 <__modti3+0xf0>
    56c4:	91200000 	add	x0, x0, #0x800
    56c8:	a9046bf9 	stp	x25, x26, [sp, #64]
    56cc:	a90573fb 	stp	x27, x28, [sp, #80]
    56d0:	97fff84c 	bl	3800 <fwp_trap>

00000000000056d4 <w120>:
    56d4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    56d8:	9e660003 	fmov	x3, d0
    56dc:	aa0003e2 	mov	x2, x0
    56e0:	910003fd 	mov	x29, sp
    56e4:	6d0327e8 	stp	d8, d9, [sp, #48]
    56e8:	1e604028 	fmov	d8, d1
    56ec:	1e600809 	fmul	d9, d0, d0
    56f0:	fd0023ea 	str	d10, [sp, #64]
    56f4:	1e60400a 	fmov	d10, d0
    56f8:	a90153f3 	stp	x19, x20, [sp, #16]
    56fc:	aa0003f3 	mov	x19, x0
    5700:	aa0103f4 	mov	x20, x1
    5704:	aa0303e1 	mov	x1, x3
    5708:	a9025bf5 	stp	x21, x22, [sp, #32]
    570c:	97ffff41 	bl	5410 <fwp_p_ad_push>
    5710:	1e693908 	fsub	d8, d8, d9
    5714:	aa1403e2 	mov	x2, x20
    5718:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    571c:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5720:	9e660116 	fmov	x22, d8
    5724:	97ffff3b 	bl	5410 <fwp_p_ad_push>
    5728:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    572c:	aa0003e1 	mov	x1, x0
    5730:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5734:	aa1303e0 	mov	x0, x19
    5738:	1e6a3929 	fsub	d9, d9, d10
    573c:	aa0103f3 	mov	x19, x1
    5740:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5744:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5748:	9e660135 	fmov	x21, d9
    574c:	97ffff31 	bl	5410 <fwp_p_ad_push>
    5750:	1e680908 	fmul	d8, d8, d8
    5754:	aa0003f4 	mov	x20, x0
    5758:	aa1603e3 	mov	x3, x22
    575c:	aa1603e1 	mov	x1, x22
    5760:	aa1303e2 	mov	x2, x19
    5764:	aa1303e0 	mov	x0, x19
    5768:	97ffff2a 	bl	5410 <fwp_p_ad_push>
    576c:	aa0003e2 	mov	x2, x0
    5770:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5774:	9e670020 	fmov	d0, x1
    5778:	9e660101 	fmov	x1, d8
    577c:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5780:	1e600908 	fmul	d8, d8, d0
    5784:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5788:	97ffff22 	bl	5410 <fwp_p_ad_push>
    578c:	1e690929 	fmul	d9, d9, d9
    5790:	aa0003f3 	mov	x19, x0
    5794:	aa1503e3 	mov	x3, x21
    5798:	aa1503e1 	mov	x1, x21
    579c:	aa1403e2 	mov	x2, x20
    57a0:	aa1403e0 	mov	x0, x20
    57a4:	97ffff1b 	bl	5410 <fwp_p_ad_push>
    57a8:	1e692908 	fadd	d8, d8, d9
    57ac:	aa1303e2 	mov	x2, x19
    57b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    57b4:	aa0303e1 	mov	x1, x3
    57b8:	97ffff16 	bl	5410 <fwp_p_ad_push>
    57bc:	aa0003e1 	mov	x1, x0
    57c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c4:	9e660100 	fmov	x0, d8
    57c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57cc:	6d4327e8 	ldp	d8, d9, [sp, #48]
    57d0:	fd4023ea 	ldr	d10, [sp, #64]
    57d4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    57d8:	d65f03c0 	ret
    57dc:	d503201f 	nop

00000000000057e0 <fwp_rc_share>:
    57e0:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    57e4:	9118c042 	add	x2, x2, #0x630
    57e8:	f949d843 	ldr	x3, [x2, #5040]
    57ec:	f949ec41 	ldr	x1, [x2, #5080]
    57f0:	cb030000 	sub	x0, x0, x3
    57f4:	eb01401f 	cmp	x0, x1, lsl #16
    57f8:	540002c2 	b.cs	5850 <fwp_rc_share+0x70>  // b.hs, b.nlast
    57fc:	d350fc01 	lsr	x1, x0, #16
    5800:	f949fc44 	ldr	x4, [x2, #5112]
    5804:	8b010821 	add	x1, x1, x1, lsl #2
    5808:	d37df021 	lsl	x1, x1, #3
    580c:	8b010083 	add	x3, x4, x1
    5810:	f9401062 	ldr	x2, [x3, #32]
    5814:	b40001e2 	cbz	x2, 5850 <fwp_rc_share+0x70>
    5818:	38616881 	ldrb	w1, [x4, x1]
    581c:	7100083f 	cmp	w1, #0x2
    5820:	540001a0 	b.eq	5854 <fwp_rc_share+0x74>  // b.none
    5824:	7100043f 	cmp	w1, #0x1
    5828:	54000141 	b.ne	5850 <fwp_rc_share+0x70>  // b.any
    582c:	29430464 	ldp	w4, w1, [x3, #24]
    5830:	92403c00 	and	x0, x0, #0xffff
    5834:	9b047c00 	mul	x0, x0, x4
    5838:	d360fc00 	lsr	x0, x0, #32
    583c:	eb01001f 	cmp	x0, x1
    5840:	54000082 	b.cs	5850 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5844:	8b000042 	add	x2, x2, x0
    5848:	39400040 	ldrb	w0, [x2]
    584c:	350000a0 	cbnz	w0, 5860 <fwp_rc_share+0x80>
    5850:	d65f03c0 	ret
    5854:	72003c1f 	tst	w0, #0xffff
    5858:	54ffff80 	b.eq	5848 <fwp_rc_share+0x68>  // b.none
    585c:	d65f03c0 	ret
    5860:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5864:	90000040 	adrp	x0, d000 <__modti3+0xf0>
    5868:	9121c000 	add	x0, x0, #0x870
    586c:	910003fd 	mov	x29, sp
    5870:	97fff7e4 	bl	3800 <fwp_trap>

0000000000005874 <fwp_rc_fresh>:
    5874:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5878:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    587c:	9118c063 	add	x3, x3, #0x630
    5880:	910003fd 	mov	x29, sp
    5884:	a90153f3 	stp	x19, x20, [sp, #16]
    5888:	aa0003f3 	mov	x19, x0
    588c:	f949d861 	ldr	x1, [x3, #5040]
    5890:	f949ec60 	ldr	x0, [x3, #5080]
    5894:	cb010261 	sub	x1, x19, x1
    5898:	eb00403f 	cmp	x1, x0, lsl #16
    589c:	54000322 	b.cs	5900 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    58a0:	d350fc22 	lsr	x2, x1, #16
    58a4:	f949fc63 	ldr	x3, [x3, #5112]
    58a8:	8b020842 	add	x2, x2, x2, lsl #2
    58ac:	d37df042 	lsl	x2, x2, #3
    58b0:	8b020060 	add	x0, x3, x2
    58b4:	f9401014 	ldr	x20, [x0, #32]
    58b8:	b4000254 	cbz	x20, 5900 <fwp_rc_fresh+0x8c>
    58bc:	38626862 	ldrb	w2, [x3, x2]
    58c0:	7100085f 	cmp	w2, #0x2
    58c4:	54000260 	b.eq	5910 <fwp_rc_fresh+0x9c>  // b.none
    58c8:	7100045f 	cmp	w2, #0x1
    58cc:	540001a1 	b.ne	5900 <fwp_rc_fresh+0x8c>  // b.any
    58d0:	29430002 	ldp	w2, w0, [x0, #24]
    58d4:	92403c21 	and	x1, x1, #0xffff
    58d8:	9b027c21 	mul	x1, x1, x2
    58dc:	d360fc21 	lsr	x1, x1, #32
    58e0:	eb00003f 	cmp	x1, x0
    58e4:	540000e2 	b.cs	5900 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    58e8:	8b010294 	add	x20, x20, x1
    58ec:	39400280 	ldrb	w0, [x20]
    58f0:	7103fc1f 	cmp	w0, #0xff
    58f4:	540001a0 	b.eq	5928 <fwp_rc_fresh+0xb4>  // b.none
    58f8:	52800020 	mov	w0, #0x1                   	// #1
    58fc:	39000280 	strb	w0, [x20]
    5900:	aa1303e0 	mov	x0, x19
    5904:	a94153f3 	ldp	x19, x20, [sp, #16]
    5908:	a8c27bfd 	ldp	x29, x30, [sp], #32
    590c:	d65f03c0 	ret
    5910:	72003c3f 	tst	w1, #0xffff
    5914:	54fffec0 	b.eq	58ec <fwp_rc_fresh+0x78>  // b.none
    5918:	aa1303e0 	mov	x0, x19
    591c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5920:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5924:	d65f03c0 	ret
    5928:	aa1403e0 	mov	x0, x20
    592c:	97fffc39 	bl	4a10 <fwp_rc_forget_slot>
    5930:	17fffff2 	b	58f8 <fwp_rc_fresh+0x84>

0000000000005934 <fwp_rc_free_arr>:
    5934:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5938:	9118c063 	add	x3, x3, #0x630
    593c:	f949d861 	ldr	x1, [x3, #5040]
    5940:	f949ec62 	ldr	x2, [x3, #5080]
    5944:	cb010001 	sub	x1, x0, x1
    5948:	eb02403f 	cmp	x1, x2, lsl #16
    594c:	54000342 	b.cs	59b4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5950:	d350fc22 	lsr	x2, x1, #16
    5954:	f949fc65 	ldr	x5, [x3, #5112]
    5958:	8b020842 	add	x2, x2, x2, lsl #2
    595c:	d37df042 	lsl	x2, x2, #3
    5960:	8b0200a4 	add	x4, x5, x2
    5964:	f9401083 	ldr	x3, [x4, #32]
    5968:	b4000263 	cbz	x3, 59b4 <fwp_rc_free_arr+0x80>
    596c:	386268a2 	ldrb	w2, [x5, x2]
    5970:	7100085f 	cmp	w2, #0x2
    5974:	540001c0 	b.eq	59ac <fwp_rc_free_arr+0x78>  // b.none
    5978:	7100045f 	cmp	w2, #0x1
    597c:	540001c1 	b.ne	59b4 <fwp_rc_free_arr+0x80>  // b.any
    5980:	29430885 	ldp	w5, w2, [x4, #24]
    5984:	92403c21 	and	x1, x1, #0xffff
    5988:	9b057c21 	mul	x1, x1, x5
    598c:	d360fc21 	lsr	x1, x1, #32
    5990:	eb02003f 	cmp	x1, x2
    5994:	54000102 	b.cs	59b4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5998:	8b010063 	add	x3, x3, x1
    599c:	39400061 	ldrb	w1, [x3]
    59a0:	7100043f 	cmp	w1, #0x1
    59a4:	54000081 	b.ne	59b4 <fwp_rc_free_arr+0x80>  // b.any
    59a8:	17fffcba 	b	4c90 <fwp_mem_free>
    59ac:	72003c3f 	tst	w1, #0xffff
    59b0:	54ffff60 	b.eq	599c <fwp_rc_free_arr+0x68>  // b.none
    59b4:	d65f03c0 	ret
    59b8:	d503201f 	nop
    59bc:	d503201f 	nop

00000000000059c0 <fwp_rc_dup>:
    59c0:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    59c4:	9118c042 	add	x2, x2, #0x630
    59c8:	f949d841 	ldr	x1, [x2, #5040]
    59cc:	f949ec43 	ldr	x3, [x2, #5080]
    59d0:	cb010001 	sub	x1, x0, x1
    59d4:	eb03403f 	cmp	x1, x3, lsl #16
    59d8:	540003c2 	b.cs	5a50 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    59dc:	d350fc20 	lsr	x0, x1, #16
    59e0:	f949fc44 	ldr	x4, [x2, #5112]
    59e4:	8b000800 	add	x0, x0, x0, lsl #2
    59e8:	d37df002 	lsl	x2, x0, #3
    59ec:	8b020083 	add	x3, x4, x2
    59f0:	f9401060 	ldr	x0, [x3, #32]
    59f4:	b40002e0 	cbz	x0, 5a50 <fwp_rc_dup+0x90>
    59f8:	38626882 	ldrb	w2, [x4, x2]
    59fc:	7100085f 	cmp	w2, #0x2
    5a00:	540002a0 	b.eq	5a54 <fwp_rc_dup+0x94>  // b.none
    5a04:	7100045f 	cmp	w2, #0x1
    5a08:	54000241 	b.ne	5a50 <fwp_rc_dup+0x90>  // b.any
    5a0c:	29430864 	ldp	w4, w2, [x3, #24]
    5a10:	92403c21 	and	x1, x1, #0xffff
    5a14:	9b047c21 	mul	x1, x1, x4
    5a18:	d360fc21 	lsr	x1, x1, #32
    5a1c:	eb02003f 	cmp	x1, x2
    5a20:	54000182 	b.cs	5a50 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5a24:	8b010000 	add	x0, x0, x1
    5a28:	39400001 	ldrb	w1, [x0]
    5a2c:	34000121 	cbz	w1, 5a50 <fwp_rc_dup+0x90>
    5a30:	f00000c2 	adrp	x2, 20000 <__data_start>
    5a34:	91014042 	add	x2, x2, #0x50
    5a38:	b9413043 	ldr	w3, [x2, #304]
    5a3c:	35000123 	cbnz	w3, 5a60 <fwp_rc_dup+0xa0>
    5a40:	7103f43f 	cmp	w1, #0xfd
    5a44:	54000168 	b.hi	5a70 <fwp_rc_dup+0xb0>  // b.pmore
    5a48:	11000421 	add	w1, w1, #0x1
    5a4c:	39000001 	strb	w1, [x0]
    5a50:	d65f03c0 	ret
    5a54:	72003c3f 	tst	w1, #0xffff
    5a58:	54fffe80 	b.eq	5a28 <fwp_rc_dup+0x68>  // b.none
    5a5c:	d65f03c0 	ret
    5a60:	f940ac43 	ldr	x3, [x2, #344]
    5a64:	91000463 	add	x3, x3, #0x1
    5a68:	f900ac43 	str	x3, [x2, #344]
    5a6c:	17fffff5 	b	5a40 <fwp_rc_dup+0x80>
    5a70:	17fffba1 	b	48f4 <fwp_rc_wide_dup>

0000000000005a74 <fwp_owned_entry173>:
    5a74:	d10103ff 	sub	sp, sp, #0x40
    5a78:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5a7c:	f947f442 	ldr	x2, [x2, #4072]
    5a80:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a84:	910083fd 	add	x29, sp, #0x20
    5a88:	a90353f3 	stp	x19, x20, [sp, #48]
    5a8c:	f9400043 	ldr	x3, [x2]
    5a90:	f9000fe3 	str	x3, [sp, #24]
    5a94:	d2800003 	mov	x3, #0x0                   	// #0
    5a98:	a9400c01 	ldp	x1, x3, [x0]
    5a9c:	f9400802 	ldr	x2, [x0, #16]
    5aa0:	ab020022 	adds	x2, x1, x2
    5aa4:	540006e6 	b.vs	5b80 <fwp_owned_entry173+0x10c>
    5aa8:	910023e1 	add	x1, sp, #0x8
    5aac:	52800000 	mov	w0, #0x0                   	// #0
    5ab0:	a9008be3 	stp	x3, x2, [sp, #8]
    5ab4:	97fffdf8 	bl	5294 <fwp_data.part.0.constprop.0>
    5ab8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5abc:	9118c063 	add	x3, x3, #0x630
    5ac0:	aa0003f3 	mov	x19, x0
    5ac4:	f949d861 	ldr	x1, [x3, #5040]
    5ac8:	f949ec60 	ldr	x0, [x3, #5080]
    5acc:	cb010261 	sub	x1, x19, x1
    5ad0:	eb00403f 	cmp	x1, x0, lsl #16
    5ad4:	54000322 	b.cs	5b38 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5ad8:	d350fc22 	lsr	x2, x1, #16
    5adc:	f949fc63 	ldr	x3, [x3, #5112]
    5ae0:	8b020842 	add	x2, x2, x2, lsl #2
    5ae4:	d37df042 	lsl	x2, x2, #3
    5ae8:	8b020060 	add	x0, x3, x2
    5aec:	f9401014 	ldr	x20, [x0, #32]
    5af0:	b4000254 	cbz	x20, 5b38 <fwp_owned_entry173+0xc4>
    5af4:	38626862 	ldrb	w2, [x3, x2]
    5af8:	7100085f 	cmp	w2, #0x2
    5afc:	54000360 	b.eq	5b68 <fwp_owned_entry173+0xf4>  // b.none
    5b00:	7100045f 	cmp	w2, #0x1
    5b04:	540001a1 	b.ne	5b38 <fwp_owned_entry173+0xc4>  // b.any
    5b08:	29430002 	ldp	w2, w0, [x0, #24]
    5b0c:	92403c21 	and	x1, x1, #0xffff
    5b10:	9b027c21 	mul	x1, x1, x2
    5b14:	d360fc21 	lsr	x1, x1, #32
    5b18:	eb00003f 	cmp	x1, x0
    5b1c:	540000e2 	b.cs	5b38 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5b20:	8b010294 	add	x20, x20, x1
    5b24:	39400280 	ldrb	w0, [x20]
    5b28:	7103fc1f 	cmp	w0, #0xff
    5b2c:	54000240 	b.eq	5b74 <fwp_owned_entry173+0x100>  // b.none
    5b30:	52800020 	mov	w0, #0x1                   	// #1
    5b34:	39000280 	strb	w0, [x20]
    5b38:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5b3c:	f947f400 	ldr	x0, [x0, #4072]
    5b40:	f9400fe2 	ldr	x2, [sp, #24]
    5b44:	f9400001 	ldr	x1, [x0]
    5b48:	eb010042 	subs	x2, x2, x1
    5b4c:	d2800001 	mov	x1, #0x0                   	// #0
    5b50:	540001a1 	b.ne	5b84 <fwp_owned_entry173+0x110>  // b.any
    5b54:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5b58:	aa1303e0 	mov	x0, x19
    5b5c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5b60:	910103ff 	add	sp, sp, #0x40
    5b64:	d65f03c0 	ret
    5b68:	72003c3f 	tst	w1, #0xffff
    5b6c:	54fffe61 	b.ne	5b38 <fwp_owned_entry173+0xc4>  // b.any
    5b70:	17ffffed 	b	5b24 <fwp_owned_entry173+0xb0>
    5b74:	aa1403e0 	mov	x0, x20
    5b78:	97fffba6 	bl	4a10 <fwp_rc_forget_slot>
    5b7c:	17ffffed 	b	5b30 <fwp_owned_entry173+0xbc>
    5b80:	97fff3c0 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5b84:	97fff347 	bl	28a0 <__stack_chk_fail@plt>
    5b88:	d503201f 	nop
    5b8c:	d503201f 	nop

0000000000005b90 <e173>:
    5b90:	d10103ff 	sub	sp, sp, #0x40
    5b94:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5b98:	f947f442 	ldr	x2, [x2, #4072]
    5b9c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ba0:	910083fd 	add	x29, sp, #0x20
    5ba4:	a90353f3 	stp	x19, x20, [sp, #48]
    5ba8:	f9400043 	ldr	x3, [x2]
    5bac:	f9000fe3 	str	x3, [sp, #24]
    5bb0:	d2800003 	mov	x3, #0x0                   	// #0
    5bb4:	a9400c01 	ldp	x1, x3, [x0]
    5bb8:	f9400802 	ldr	x2, [x0, #16]
    5bbc:	ab020022 	adds	x2, x1, x2
    5bc0:	54000726 	b.vs	5ca4 <e173+0x114>
    5bc4:	910023e1 	add	x1, sp, #0x8
    5bc8:	52800000 	mov	w0, #0x0                   	// #0
    5bcc:	a9008be3 	stp	x3, x2, [sp, #8]
    5bd0:	97fffdb1 	bl	5294 <fwp_data.part.0.constprop.0>
    5bd4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5bd8:	9118c063 	add	x3, x3, #0x630
    5bdc:	aa0003f3 	mov	x19, x0
    5be0:	f949d861 	ldr	x1, [x3, #5040]
    5be4:	f949ec60 	ldr	x0, [x3, #5080]
    5be8:	cb010261 	sub	x1, x19, x1
    5bec:	eb00403f 	cmp	x1, x0, lsl #16
    5bf0:	54000322 	b.cs	5c54 <e173+0xc4>  // b.hs, b.nlast
    5bf4:	d350fc22 	lsr	x2, x1, #16
    5bf8:	f949fc63 	ldr	x3, [x3, #5112]
    5bfc:	8b020842 	add	x2, x2, x2, lsl #2
    5c00:	d37df042 	lsl	x2, x2, #3
    5c04:	8b020060 	add	x0, x3, x2
    5c08:	f9401014 	ldr	x20, [x0, #32]
    5c0c:	b4000254 	cbz	x20, 5c54 <e173+0xc4>
    5c10:	38626862 	ldrb	w2, [x3, x2]
    5c14:	7100085f 	cmp	w2, #0x2
    5c18:	540003a0 	b.eq	5c8c <e173+0xfc>  // b.none
    5c1c:	7100045f 	cmp	w2, #0x1
    5c20:	540001a1 	b.ne	5c54 <e173+0xc4>  // b.any
    5c24:	29430002 	ldp	w2, w0, [x0, #24]
    5c28:	92403c21 	and	x1, x1, #0xffff
    5c2c:	9b027c21 	mul	x1, x1, x2
    5c30:	d360fc21 	lsr	x1, x1, #32
    5c34:	eb00003f 	cmp	x1, x0
    5c38:	540000e2 	b.cs	5c54 <e173+0xc4>  // b.hs, b.nlast
    5c3c:	8b010294 	add	x20, x20, x1
    5c40:	39400280 	ldrb	w0, [x20]
    5c44:	7103fc1f 	cmp	w0, #0xff
    5c48:	54000280 	b.eq	5c98 <e173+0x108>  // b.none
    5c4c:	52800020 	mov	w0, #0x1                   	// #1
    5c50:	39000280 	strb	w0, [x20]
    5c54:	aa1303e0 	mov	x0, x19
    5c58:	97fffee2 	bl	57e0 <fwp_rc_share>
    5c5c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5c60:	f947f400 	ldr	x0, [x0, #4072]
    5c64:	f9400fe2 	ldr	x2, [sp, #24]
    5c68:	f9400001 	ldr	x1, [x0]
    5c6c:	eb010042 	subs	x2, x2, x1
    5c70:	d2800001 	mov	x1, #0x0                   	// #0
    5c74:	540001a1 	b.ne	5ca8 <e173+0x118>  // b.any
    5c78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c7c:	aa1303e0 	mov	x0, x19
    5c80:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c84:	910103ff 	add	sp, sp, #0x40
    5c88:	d65f03c0 	ret
    5c8c:	72003c3f 	tst	w1, #0xffff
    5c90:	54fffe21 	b.ne	5c54 <e173+0xc4>  // b.any
    5c94:	17ffffeb 	b	5c40 <e173+0xb0>
    5c98:	aa1403e0 	mov	x0, x20
    5c9c:	97fffb5d 	bl	4a10 <fwp_rc_forget_slot>
    5ca0:	17ffffeb 	b	5c4c <e173+0xbc>
    5ca4:	97fff377 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5ca8:	97fff2fe 	bl	28a0 <__stack_chk_fail@plt>
    5cac:	d503201f 	nop

0000000000005cb0 <fwp_drop0>:
    5cb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5cb4:	910003fd 	mov	x29, sp
    5cb8:	a90153f3 	stp	x19, x20, [sp, #16]
    5cbc:	f90013f5 	str	x21, [sp, #32]
    5cc0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5cc4:	9118c2b4 	add	x20, x21, #0x630
    5cc8:	f949da81 	ldr	x1, [x20, #5040]
    5ccc:	f949ee82 	ldr	x2, [x20, #5080]
    5cd0:	cb010001 	sub	x1, x0, x1
    5cd4:	eb02403f 	cmp	x1, x2, lsl #16
    5cd8:	54000382 	b.cs	5d48 <fwp_drop0+0x98>  // b.hs, b.nlast
    5cdc:	d350fc22 	lsr	x2, x1, #16
    5ce0:	f949fe84 	ldr	x4, [x20, #5112]
    5ce4:	8b020842 	add	x2, x2, x2, lsl #2
    5ce8:	d37df042 	lsl	x2, x2, #3
    5cec:	8b020083 	add	x3, x4, x2
    5cf0:	f9401073 	ldr	x19, [x3, #32]
    5cf4:	b40002b3 	cbz	x19, 5d48 <fwp_drop0+0x98>
    5cf8:	38626882 	ldrb	w2, [x4, x2]
    5cfc:	7100085f 	cmp	w2, #0x2
    5d00:	540002c0 	b.eq	5d58 <fwp_drop0+0xa8>  // b.none
    5d04:	7100045f 	cmp	w2, #0x1
    5d08:	54000201 	b.ne	5d48 <fwp_drop0+0x98>  // b.any
    5d0c:	29430864 	ldp	w4, w2, [x3, #24]
    5d10:	92403c21 	and	x1, x1, #0xffff
    5d14:	9b047c21 	mul	x1, x1, x4
    5d18:	d360fc21 	lsr	x1, x1, #32
    5d1c:	eb02003f 	cmp	x1, x2
    5d20:	54000142 	b.cs	5d48 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d24:	8b010273 	add	x19, x19, x1
    5d28:	39400261 	ldrb	w1, [x19]
    5d2c:	340000e1 	cbz	w1, 5d48 <fwp_drop0+0x98>
    5d30:	7100043f 	cmp	w1, #0x1
    5d34:	540001e0 	b.eq	5d70 <fwp_drop0+0xc0>  // b.none
    5d38:	7103fc3f 	cmp	w1, #0xff
    5d3c:	540002e0 	b.eq	5d98 <fwp_drop0+0xe8>  // b.none
    5d40:	51000421 	sub	w1, w1, #0x1
    5d44:	39000261 	strb	w1, [x19]
    5d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d4c:	f94013f5 	ldr	x21, [sp, #32]
    5d50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d54:	d65f03c0 	ret
    5d58:	72003c3f 	tst	w1, #0xffff
    5d5c:	54fffe60 	b.eq	5d28 <fwp_drop0+0x78>  // b.none
    5d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d64:	f94013f5 	ldr	x21, [sp, #32]
    5d68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d6c:	d65f03c0 	ret
    5d70:	f9400813 	ldr	x19, [x0, #16]
    5d74:	97fffef0 	bl	5934 <fwp_rc_free_arr>
    5d78:	9118c2a0 	add	x0, x21, #0x630
    5d7c:	f949d801 	ldr	x1, [x0, #5040]
    5d80:	f949ec00 	ldr	x0, [x0, #5080]
    5d84:	cb010261 	sub	x1, x19, x1
    5d88:	eb00403f 	cmp	x1, x0, lsl #16
    5d8c:	54fffde2 	b.cs	5d48 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d90:	aa1303e0 	mov	x0, x19
    5d94:	17ffffd2 	b	5cdc <fwp_drop0+0x2c>
    5d98:	ca534660 	eor	x0, x19, x19, lsr #17
    5d9c:	9118c2b5 	add	x21, x21, #0x630
    5da0:	ca402400 	eor	x0, x0, x0, lsr #9
    5da4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5da8:	f94a2400 	ldr	x0, [x0, #5192]
    5dac:	b5000080 	cbnz	x0, 5dbc <fwp_drop0+0x10c>
    5db0:	14000010 	b	5df0 <fwp_drop0+0x140>
    5db4:	f9400800 	ldr	x0, [x0, #16]
    5db8:	b40001c0 	cbz	x0, 5df0 <fwp_drop0+0x140>
    5dbc:	f9400001 	ldr	x1, [x0]
    5dc0:	eb13003f 	cmp	x1, x19
    5dc4:	54ffff81 	b.ne	5db4 <fwp_drop0+0x104>  // b.any
    5dc8:	f9400401 	ldr	x1, [x0, #8]
    5dcc:	d1000421 	sub	x1, x1, #0x1
    5dd0:	f9000401 	str	x1, [x0, #8]
    5dd4:	f103f83f 	cmp	x1, #0xfe
    5dd8:	54fffb81 	b.ne	5d48 <fwp_drop0+0x98>  // b.any
    5ddc:	aa1303e0 	mov	x0, x19
    5de0:	97fffb0c 	bl	4a10 <fwp_rc_forget_slot>
    5de4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5de8:	39000260 	strb	w0, [x19]
    5dec:	17ffffd7 	b	5d48 <fwp_drop0+0x98>
    5df0:	90000040 	adrp	x0, d000 <__modti3+0xf0>
    5df4:	911dc000 	add	x0, x0, #0x770
    5df8:	97fff682 	bl	3800 <fwp_trap>
    5dfc:	d503201f 	nop

0000000000005e00 <fwp_drop1>:
    5e00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e04:	910003fd 	mov	x29, sp
    5e08:	a90153f3 	stp	x19, x20, [sp, #16]
    5e0c:	f90013f5 	str	x21, [sp, #32]
    5e10:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5e14:	9118c2b4 	add	x20, x21, #0x630
    5e18:	f949da81 	ldr	x1, [x20, #5040]
    5e1c:	f949ee82 	ldr	x2, [x20, #5080]
    5e20:	cb010001 	sub	x1, x0, x1
    5e24:	eb02403f 	cmp	x1, x2, lsl #16
    5e28:	54000382 	b.cs	5e98 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e2c:	d350fc22 	lsr	x2, x1, #16
    5e30:	f949fe84 	ldr	x4, [x20, #5112]
    5e34:	8b020842 	add	x2, x2, x2, lsl #2
    5e38:	d37df042 	lsl	x2, x2, #3
    5e3c:	8b020083 	add	x3, x4, x2
    5e40:	f9401073 	ldr	x19, [x3, #32]
    5e44:	b40002b3 	cbz	x19, 5e98 <fwp_drop1+0x98>
    5e48:	38626882 	ldrb	w2, [x4, x2]
    5e4c:	7100085f 	cmp	w2, #0x2
    5e50:	540002c0 	b.eq	5ea8 <fwp_drop1+0xa8>  // b.none
    5e54:	7100045f 	cmp	w2, #0x1
    5e58:	54000201 	b.ne	5e98 <fwp_drop1+0x98>  // b.any
    5e5c:	29430864 	ldp	w4, w2, [x3, #24]
    5e60:	92403c21 	and	x1, x1, #0xffff
    5e64:	9b047c21 	mul	x1, x1, x4
    5e68:	d360fc21 	lsr	x1, x1, #32
    5e6c:	eb02003f 	cmp	x1, x2
    5e70:	54000142 	b.cs	5e98 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e74:	8b010273 	add	x19, x19, x1
    5e78:	39400261 	ldrb	w1, [x19]
    5e7c:	340000e1 	cbz	w1, 5e98 <fwp_drop1+0x98>
    5e80:	7100043f 	cmp	w1, #0x1
    5e84:	540001e0 	b.eq	5ec0 <fwp_drop1+0xc0>  // b.none
    5e88:	7103fc3f 	cmp	w1, #0xff
    5e8c:	540002e0 	b.eq	5ee8 <fwp_drop1+0xe8>  // b.none
    5e90:	51000421 	sub	w1, w1, #0x1
    5e94:	39000261 	strb	w1, [x19]
    5e98:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e9c:	f94013f5 	ldr	x21, [sp, #32]
    5ea0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ea4:	d65f03c0 	ret
    5ea8:	72003c3f 	tst	w1, #0xffff
    5eac:	54fffe60 	b.eq	5e78 <fwp_drop1+0x78>  // b.none
    5eb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5eb4:	f94013f5 	ldr	x21, [sp, #32]
    5eb8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ebc:	d65f03c0 	ret
    5ec0:	f9400813 	ldr	x19, [x0, #16]
    5ec4:	97fffe9c 	bl	5934 <fwp_rc_free_arr>
    5ec8:	9118c2a0 	add	x0, x21, #0x630
    5ecc:	f949d801 	ldr	x1, [x0, #5040]
    5ed0:	f949ec00 	ldr	x0, [x0, #5080]
    5ed4:	cb010261 	sub	x1, x19, x1
    5ed8:	eb00403f 	cmp	x1, x0, lsl #16
    5edc:	54fffde2 	b.cs	5e98 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ee0:	aa1303e0 	mov	x0, x19
    5ee4:	17ffffd2 	b	5e2c <fwp_drop1+0x2c>
    5ee8:	ca534660 	eor	x0, x19, x19, lsr #17
    5eec:	9118c2b5 	add	x21, x21, #0x630
    5ef0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ef4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5ef8:	f94a2400 	ldr	x0, [x0, #5192]
    5efc:	b5000080 	cbnz	x0, 5f0c <fwp_drop1+0x10c>
    5f00:	14000010 	b	5f40 <fwp_drop1+0x140>
    5f04:	f9400800 	ldr	x0, [x0, #16]
    5f08:	b40001c0 	cbz	x0, 5f40 <fwp_drop1+0x140>
    5f0c:	f9400001 	ldr	x1, [x0]
    5f10:	eb13003f 	cmp	x1, x19
    5f14:	54ffff81 	b.ne	5f04 <fwp_drop1+0x104>  // b.any
    5f18:	f9400401 	ldr	x1, [x0, #8]
    5f1c:	d1000421 	sub	x1, x1, #0x1
    5f20:	f9000401 	str	x1, [x0, #8]
    5f24:	f103f83f 	cmp	x1, #0xfe
    5f28:	54fffb81 	b.ne	5e98 <fwp_drop1+0x98>  // b.any
    5f2c:	aa1303e0 	mov	x0, x19
    5f30:	97fffab8 	bl	4a10 <fwp_rc_forget_slot>
    5f34:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f38:	39000260 	strb	w0, [x19]
    5f3c:	17ffffd7 	b	5e98 <fwp_drop1+0x98>
    5f40:	90000040 	adrp	x0, d000 <__modti3+0xf0>
    5f44:	911dc000 	add	x0, x0, #0x770
    5f48:	97fff62e 	bl	3800 <fwp_trap>
    5f4c:	d503201f 	nop

0000000000005f50 <fwp_closure_drop>:
    5f50:	900003a5 	adrp	x5, 79000 <fwp_root_context+0xbb0>
    5f54:	9118c0a4 	add	x4, x5, #0x630
    5f58:	aa0003e1 	mov	x1, x0
    5f5c:	f949d882 	ldr	x2, [x4, #5040]
    5f60:	f949ec80 	ldr	x0, [x4, #5080]
    5f64:	cb020022 	sub	x2, x1, x2
    5f68:	eb00405f 	cmp	x2, x0, lsl #16
    5f6c:	54000662 	b.cs	6038 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5f70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5f74:	d350fc43 	lsr	x3, x2, #16
    5f78:	910003fd 	mov	x29, sp
    5f7c:	8b030863 	add	x3, x3, x3, lsl #2
    5f80:	f949fc84 	ldr	x4, [x4, #5112]
    5f84:	d37df063 	lsl	x3, x3, #3
    5f88:	f9000bf3 	str	x19, [sp, #16]
    5f8c:	8b030080 	add	x0, x4, x3
    5f90:	f9401013 	ldr	x19, [x0, #32]
    5f94:	b40002b3 	cbz	x19, 5fe8 <fwp_closure_drop+0x98>
    5f98:	38636883 	ldrb	w3, [x4, x3]
    5f9c:	7100087f 	cmp	w3, #0x2
    5fa0:	54000420 	b.eq	6024 <fwp_closure_drop+0xd4>  // b.none
    5fa4:	7100047f 	cmp	w3, #0x1
    5fa8:	54000201 	b.ne	5fe8 <fwp_closure_drop+0x98>  // b.any
    5fac:	29430003 	ldp	w3, w0, [x0, #24]
    5fb0:	92403c42 	and	x2, x2, #0xffff
    5fb4:	9b037c42 	mul	x2, x2, x3
    5fb8:	d360fc42 	lsr	x2, x2, #32
    5fbc:	eb00005f 	cmp	x2, x0
    5fc0:	54000142 	b.cs	5fe8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5fc4:	8b020273 	add	x19, x19, x2
    5fc8:	39400260 	ldrb	w0, [x19]
    5fcc:	340000e0 	cbz	w0, 5fe8 <fwp_closure_drop+0x98>
    5fd0:	7100041f 	cmp	w0, #0x1
    5fd4:	54000100 	b.eq	5ff4 <fwp_closure_drop+0xa4>  // b.none
    5fd8:	7103fc1f 	cmp	w0, #0xff
    5fdc:	54000300 	b.eq	603c <fwp_closure_drop+0xec>  // b.none
    5fe0:	51000400 	sub	w0, w0, #0x1
    5fe4:	39000260 	strb	w0, [x19]
    5fe8:	f9400bf3 	ldr	x19, [sp, #16]
    5fec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ff0:	d65f03c0 	ret
    5ff4:	d53bd040 	mrs	x0, tpidr_el0
    5ff8:	91400000 	add	x0, x0, #0x0, lsl #12
    5ffc:	91004000 	add	x0, x0, #0x10
    6000:	f9400000 	ldr	x0, [x0]
    6004:	b4000080 	cbz	x0, 6014 <fwp_closure_drop+0xc4>
    6008:	f9400bf3 	ldr	x19, [sp, #16]
    600c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6010:	17fff615 	b	3864 <fwp_closure_drop_push>
    6014:	f9400bf3 	ldr	x19, [sp, #16]
    6018:	aa0103e0 	mov	x0, x1
    601c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6020:	17fff680 	b	3a20 <fwp_closure_drop.part.0>
    6024:	72003c5f 	tst	w2, #0xffff
    6028:	54fffd00 	b.eq	5fc8 <fwp_closure_drop+0x78>  // b.none
    602c:	f9400bf3 	ldr	x19, [sp, #16]
    6030:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6034:	d65f03c0 	ret
    6038:	d65f03c0 	ret
    603c:	ca534660 	eor	x0, x19, x19, lsr #17
    6040:	9118c0a5 	add	x5, x5, #0x630
    6044:	ca402400 	eor	x0, x0, x0, lsr #9
    6048:	8b200ca0 	add	x0, x5, w0, uxtb #3
    604c:	f94a2400 	ldr	x0, [x0, #5192]
    6050:	b5000080 	cbnz	x0, 6060 <fwp_closure_drop+0x110>
    6054:	14000010 	b	6094 <fwp_closure_drop+0x144>
    6058:	f9400800 	ldr	x0, [x0, #16]
    605c:	b40001c0 	cbz	x0, 6094 <fwp_closure_drop+0x144>
    6060:	f9400001 	ldr	x1, [x0]
    6064:	eb13003f 	cmp	x1, x19
    6068:	54ffff81 	b.ne	6058 <fwp_closure_drop+0x108>  // b.any
    606c:	f9400401 	ldr	x1, [x0, #8]
    6070:	d1000421 	sub	x1, x1, #0x1
    6074:	f9000401 	str	x1, [x0, #8]
    6078:	f103f83f 	cmp	x1, #0xfe
    607c:	54fffb61 	b.ne	5fe8 <fwp_closure_drop+0x98>  // b.any
    6080:	aa1303e0 	mov	x0, x19
    6084:	97fffa63 	bl	4a10 <fwp_rc_forget_slot>
    6088:	12800020 	mov	w0, #0xfffffffe            	// #-2
    608c:	39000260 	strb	w0, [x19]
    6090:	17ffffd6 	b	5fe8 <fwp_closure_drop+0x98>
    6094:	f0000020 	adrp	x0, d000 <__modti3+0xf0>
    6098:	911dc000 	add	x0, x0, #0x770
    609c:	97fff5d9 	bl	3800 <fwp_trap>

00000000000060a0 <fwp_owned_tape_release>:
    60a0:	b4000940 	cbz	x0, 61c8 <fwp_owned_tape_release+0x128>
    60a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    60a8:	910003fd 	mov	x29, sp
    60ac:	a90153f3 	stp	x19, x20, [sp, #16]
    60b0:	aa0003f3 	mov	x19, x0
    60b4:	f9400000 	ldr	x0, [x0]
    60b8:	b4000060 	cbz	x0, 60c4 <fwp_owned_tape_release+0x24>
    60bc:	f9400661 	ldr	x1, [x19, #8]
    60c0:	f9000401 	str	x1, [x0, #8]
    60c4:	f9400661 	ldr	x1, [x19, #8]
    60c8:	b4000041 	cbz	x1, 60d0 <fwp_owned_tape_release+0x30>
    60cc:	f9000020 	str	x0, [x1]
    60d0:	f9400a60 	ldr	x0, [x19, #16]
    60d4:	f9403401 	ldr	x1, [x0, #104]
    60d8:	b40005c1 	cbz	x1, 6190 <fwp_owned_tape_release+0xf0>
    60dc:	a9450a60 	ldp	x0, x2, [x19, #80]
    60e0:	eb00005f 	cmp	x2, x0
    60e4:	540002ed 	b.le	6140 <fwp_owned_tape_release+0xa0>
    60e8:	d2800014 	mov	x20, #0x0                   	// #0
    60ec:	f90013f5 	str	x21, [sp, #32]
    60f0:	d2800015 	mov	x21, #0x0                   	// #0
    60f4:	d503201f 	nop
    60f8:	f9402260 	ldr	x0, [x19, #64]
    60fc:	910006b5 	add	x21, x21, #0x1
    6100:	f8746800 	ldr	x0, [x0, x20]
    6104:	d63f0020 	blr	x1
    6108:	f9402260 	ldr	x0, [x19, #64]
    610c:	f9400a61 	ldr	x1, [x19, #16]
    6110:	8b140000 	add	x0, x0, x20
    6114:	91004294 	add	x20, x20, #0x10
    6118:	f9400400 	ldr	x0, [x0, #8]
    611c:	f9403421 	ldr	x1, [x1, #104]
    6120:	d63f0020 	blr	x1
    6124:	a9450261 	ldp	x1, x0, [x19, #80]
    6128:	cb010000 	sub	x0, x0, x1
    612c:	eb15001f 	cmp	x0, x21
    6130:	f9400a60 	ldr	x0, [x19, #16]
    6134:	f9403401 	ldr	x1, [x0, #104]
    6138:	54fffe0c 	b.gt	60f8 <fwp_owned_tape_release+0x58>
    613c:	f94013f5 	ldr	x21, [sp, #32]
    6140:	f9403663 	ldr	x3, [x19, #104]
    6144:	f9401262 	ldr	x2, [x19, #32]
    6148:	f100007f 	cmp	x3, #0x0
    614c:	540001ed 	b.le	6188 <fwp_owned_tape_release+0xe8>
    6150:	d2800014 	mov	x20, #0x0                   	// #0
    6154:	d503201f 	nop
    6158:	f9402660 	ldr	x0, [x19, #72]
    615c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6160:	eb02001f 	cmp	x0, x2
    6164:	540000c0 	b.eq	617c <fwp_owned_tape_release+0xdc>  // b.none
    6168:	d63f0020 	blr	x1
    616c:	f9400a60 	ldr	x0, [x19, #16]
    6170:	f9401262 	ldr	x2, [x19, #32]
    6174:	f9403663 	ldr	x3, [x19, #104]
    6178:	f9403401 	ldr	x1, [x0, #104]
    617c:	91000694 	add	x20, x20, #0x1
    6180:	eb14007f 	cmp	x3, x20
    6184:	54fffeac 	b.gt	6158 <fwp_owned_tape_release+0xb8>
    6188:	aa0203e0 	mov	x0, x2
    618c:	d63f0020 	blr	x1
    6190:	f9401660 	ldr	x0, [x19, #40]
    6194:	97ffff6f 	bl	5f50 <fwp_closure_drop>
    6198:	f9401a60 	ldr	x0, [x19, #48]
    619c:	97ffff6d 	bl	5f50 <fwp_closure_drop>
    61a0:	f9401e60 	ldr	x0, [x19, #56]
    61a4:	97ffff6b 	bl	5f50 <fwp_closure_drop>
    61a8:	f9402260 	ldr	x0, [x19, #64]
    61ac:	97fffab9 	bl	4c90 <fwp_mem_free>
    61b0:	f9402660 	ldr	x0, [x19, #72]
    61b4:	97fffab7 	bl	4c90 <fwp_mem_free>
    61b8:	aa1303e0 	mov	x0, x19
    61bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    61c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    61c4:	17fffab3 	b	4c90 <fwp_mem_free>
    61c8:	d65f03c0 	ret
    61cc:	d503201f 	nop

00000000000061d0 <fwp_tape_finish>:
    61d0:	d10203ff 	sub	sp, sp, #0x80
    61d4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    61d8:	f947f421 	ldr	x1, [x1, #4072]
    61dc:	a9047bfd 	stp	x29, x30, [sp, #64]
    61e0:	910103fd 	add	x29, sp, #0x40
    61e4:	a9065bf5 	stp	x21, x22, [sp, #96]
    61e8:	a90763f7 	stp	x23, x24, [sp, #112]
    61ec:	d00000d7 	adrp	x23, 20000 <__data_start>
    61f0:	910142f6 	add	x22, x23, #0x50
    61f4:	f9400022 	ldr	x2, [x1]
    61f8:	f9001fe2 	str	x2, [sp, #56]
    61fc:	d2800002 	mov	x2, #0x0                   	// #0
    6200:	910382c0 	add	x0, x22, #0xe0
    6204:	97fff880 	bl	4404 <fwp_tape_buffers_dispose>
    6208:	f9008edf 	str	xzr, [x22, #280]
    620c:	f9406ec0 	ldr	x0, [x22, #216]
    6210:	f100001f 	cmp	x0, #0x0
    6214:	5400034d 	b.le	627c <fwp_tape_finish+0xac>
    6218:	910003f8 	mov	x24, sp
    621c:	d2800015 	mov	x21, #0x0                   	// #0
    6220:	a90553f3 	stp	x19, x20, [sp, #80]
    6224:	d2800014 	mov	x20, #0x0                   	// #0
    6228:	91000694 	add	x20, x20, #0x1
    622c:	f94046d3 	ldr	x19, [x22, #136]
    6230:	8b150273 	add	x19, x19, x21
    6234:	9101a2b5 	add	x21, x21, #0x68
    6238:	aa1303e0 	mov	x0, x19
    623c:	97fff376 	bl	3014 <fwp_tape_unlink_scope>
    6240:	aa1803e0 	mov	x0, x24
    6244:	a9440663 	ldp	x3, x1, [x19, #64]
    6248:	f9001be1 	str	x1, [sp, #48]
    624c:	f9400e62 	ldr	x2, [x19, #24]
    6250:	a9020be3 	stp	x3, x2, [sp, #32]
    6254:	ad410261 	ldp	q1, q0, [x19, #32]
    6258:	ad0003e1 	stp	q1, q0, [sp]
    625c:	97fff86a 	bl	4404 <fwp_tape_buffers_dispose>
    6260:	f9403260 	ldr	x0, [x19, #96]
    6264:	97ffff8f 	bl	60a0 <fwp_owned_tape_release>
    6268:	f900327f 	str	xzr, [x19, #96]
    626c:	f9406ec0 	ldr	x0, [x22, #216]
    6270:	eb14001f 	cmp	x0, x20
    6274:	54fffdac 	b.gt	6228 <fwp_tape_finish+0x58>
    6278:	a94553f3 	ldp	x19, x20, [sp, #80]
    627c:	910142e0 	add	x0, x23, #0x50
    6280:	f9404400 	ldr	x0, [x0, #136]
    6284:	b4000040 	cbz	x0, 628c <fwp_tape_finish+0xbc>
    6288:	97fff83e 	bl	4380 <ad_raw_free.part.0>
    628c:	910142f7 	add	x23, x23, #0x50
    6290:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6294:	f947f400 	ldr	x0, [x0, #4072]
    6298:	f90046ff 	str	xzr, [x23, #136]
    629c:	f9006eff 	str	xzr, [x23, #216]
    62a0:	f90092ff 	str	xzr, [x23, #288]
    62a4:	f900b2ff 	str	xzr, [x23, #352]
    62a8:	f9401fe2 	ldr	x2, [sp, #56]
    62ac:	f9400001 	ldr	x1, [x0]
    62b0:	eb010042 	subs	x2, x2, x1
    62b4:	d2800001 	mov	x1, #0x0                   	// #0
    62b8:	540000c1 	b.ne	62d0 <fwp_tape_finish+0x100>  // b.any
    62bc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    62c0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    62c4:	a94763f7 	ldp	x23, x24, [sp, #112]
    62c8:	910203ff 	add	sp, sp, #0x80
    62cc:	d65f03c0 	ret
    62d0:	a90553f3 	stp	x19, x20, [sp, #80]
    62d4:	97fff173 	bl	28a0 <__stack_chk_fail@plt>
    62d8:	d503201f 	nop
    62dc:	d503201f 	nop

00000000000062e0 <fwp_tape_scope_release>:
    62e0:	d10243ff 	sub	sp, sp, #0x90
    62e4:	a9047bfd 	stp	x29, x30, [sp, #64]
    62e8:	910103fd 	add	x29, sp, #0x40
    62ec:	a90553f3 	stp	x19, x20, [sp, #80]
    62f0:	aa0003f4 	mov	x20, x0
    62f4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    62f8:	f947f400 	ldr	x0, [x0, #4072]
    62fc:	b9400285 	ldr	w5, [x20]
    6300:	f9400001 	ldr	x1, [x0]
    6304:	f9001fe1 	str	x1, [sp, #56]
    6308:	d2800001 	mov	x1, #0x0                   	// #0
    630c:	37f806c5 	tbnz	w5, #31, 63e4 <fwp_tape_scope_release+0x104>
    6310:	a90763f7 	stp	x23, x24, [sp, #112]
    6314:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6318:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    631c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6320:	d00000d3 	adrp	x19, 20000 <__data_start>
    6324:	910003f7 	mov	x23, sp
    6328:	91014273 	add	x19, x19, #0x50
    632c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6330:	a9065bf5 	stp	x21, x22, [sp, #96]
    6334:	52800d16 	mov	w22, #0x68                  	// #104
    6338:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    633c:	f90043f9 	str	x25, [sp, #128]
    6340:	14000006 	b	6358 <fwp_tape_scope_release+0x78>
    6344:	97fff830 	bl	4404 <fwp_tape_buffers_dispose>
    6348:	aa1903e0 	mov	x0, x25
    634c:	97ffff55 	bl	60a0 <fwp_owned_tape_release>
    6350:	b9400285 	ldr	w5, [x20]
    6354:	37f80425 	tbnz	w5, #31, 63d8 <fwp_tape_scope_release+0xf8>
    6358:	f9404666 	ldr	x6, [x19, #136]
    635c:	9b367ca5 	smull	x5, w5, w22
    6360:	8b0500c0 	add	x0, x6, x5
    6364:	97fff32c 	bl	3014 <fwp_tape_unlink_scope>
    6368:	ad410001 	ldp	q1, q0, [x0, #32]
    636c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6370:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6374:	f9400c03 	ldr	x3, [x0, #24]
    6378:	ad0003e1 	stp	q1, q0, [sp]
    637c:	b86568c1 	ldr	w1, [x6, x5]
    6380:	a9440804 	ldp	x4, x2, [x0, #64]
    6384:	b900041f 	str	wzr, [x0, #4]
    6388:	f9403019 	ldr	x25, [x0, #96]
    638c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6390:	f9000c1f 	str	xzr, [x0, #24]
    6394:	a9020fe4 	stp	x4, x3, [sp, #32]
    6398:	f9001be2 	str	x2, [sp, #48]
    639c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    63a0:	f900301f 	str	xzr, [x0, #96]
    63a4:	6b15003f 	cmp	w1, w21
    63a8:	540000e8 	b.hi	63c4 <fwp_tape_scope_release+0xe4>  // b.pmore
    63ac:	9343fca5 	asr	x5, x5, #3
    63b0:	f940b260 	ldr	x0, [x19, #352]
    63b4:	9b187ca5 	mul	x5, x5, x24
    63b8:	eb0000bf 	cmp	x5, x0
    63bc:	5400004a 	b.ge	63c4 <fwp_tape_scope_release+0xe4>  // b.tcont
    63c0:	f900b265 	str	x5, [x19, #352]
    63c4:	aa1703e0 	mov	x0, x23
    63c8:	b5fffbf9 	cbnz	x25, 6344 <fwp_tape_scope_release+0x64>
    63cc:	97fff856 	bl	4524 <fwp_tape_buffers_release>
    63d0:	b9400285 	ldr	w5, [x20]
    63d4:	36fffc25 	tbz	w5, #31, 6358 <fwp_tape_scope_release+0x78>
    63d8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    63dc:	a94763f7 	ldp	x23, x24, [sp, #112]
    63e0:	f94043f9 	ldr	x25, [sp, #128]
    63e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    63e8:	f947f400 	ldr	x0, [x0, #4072]
    63ec:	f9401fe2 	ldr	x2, [sp, #56]
    63f0:	f9400001 	ldr	x1, [x0]
    63f4:	eb010042 	subs	x2, x2, x1
    63f8:	d2800001 	mov	x1, #0x0                   	// #0
    63fc:	540000a1 	b.ne	6410 <fwp_tape_scope_release+0x130>  // b.any
    6400:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6404:	a94553f3 	ldp	x19, x20, [sp, #80]
    6408:	910243ff 	add	sp, sp, #0x90
    640c:	d65f03c0 	ret
    6410:	a9065bf5 	stp	x21, x22, [sp, #96]
    6414:	a90763f7 	stp	x23, x24, [sp, #112]
    6418:	f90043f9 	str	x25, [sp, #128]
    641c:	97fff121 	bl	28a0 <__stack_chk_fail@plt>

0000000000006420 <fwp_drop4>:
    6420:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6424:	910003fd 	mov	x29, sp
    6428:	a9025bf5 	stp	x21, x22, [sp, #32]
    642c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    6430:	9118c2d5 	add	x21, x22, #0x630
    6434:	a90153f3 	stp	x19, x20, [sp, #16]
    6438:	aa0003f3 	mov	x19, x0
    643c:	f949daa1 	ldr	x1, [x21, #5040]
    6440:	f949eea0 	ldr	x0, [x21, #5080]
    6444:	cb010261 	sub	x1, x19, x1
    6448:	eb00403f 	cmp	x1, x0, lsl #16
    644c:	54000382 	b.cs	64bc <fwp_drop4+0x9c>  // b.hs, b.nlast
    6450:	d350fc22 	lsr	x2, x1, #16
    6454:	f949fea3 	ldr	x3, [x21, #5112]
    6458:	8b020842 	add	x2, x2, x2, lsl #2
    645c:	d37df042 	lsl	x2, x2, #3
    6460:	8b020060 	add	x0, x3, x2
    6464:	f9401014 	ldr	x20, [x0, #32]
    6468:	b40002b4 	cbz	x20, 64bc <fwp_drop4+0x9c>
    646c:	38626862 	ldrb	w2, [x3, x2]
    6470:	7100085f 	cmp	w2, #0x2
    6474:	540002c0 	b.eq	64cc <fwp_drop4+0xac>  // b.none
    6478:	7100045f 	cmp	w2, #0x1
    647c:	54000201 	b.ne	64bc <fwp_drop4+0x9c>  // b.any
    6480:	29430002 	ldp	w2, w0, [x0, #24]
    6484:	92403c21 	and	x1, x1, #0xffff
    6488:	9b027c21 	mul	x1, x1, x2
    648c:	d360fc21 	lsr	x1, x1, #32
    6490:	eb00003f 	cmp	x1, x0
    6494:	54000142 	b.cs	64bc <fwp_drop4+0x9c>  // b.hs, b.nlast
    6498:	8b010294 	add	x20, x20, x1
    649c:	39400280 	ldrb	w0, [x20]
    64a0:	340000e0 	cbz	w0, 64bc <fwp_drop4+0x9c>
    64a4:	7100041f 	cmp	w0, #0x1
    64a8:	540001e0 	b.eq	64e4 <fwp_drop4+0xc4>  // b.none
    64ac:	7103fc1f 	cmp	w0, #0xff
    64b0:	540007c0 	b.eq	65a8 <fwp_drop4+0x188>  // b.none
    64b4:	51000400 	sub	w0, w0, #0x1
    64b8:	39000280 	strb	w0, [x20]
    64bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    64c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    64c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    64c8:	d65f03c0 	ret
    64cc:	72003c3f 	tst	w1, #0xffff
    64d0:	54fffe60 	b.eq	649c <fwp_drop4+0x7c>  // b.none
    64d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    64d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    64dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    64e0:	d65f03c0 	ret
    64e4:	9118c2c2 	add	x2, x22, #0x630
    64e8:	f9400660 	ldr	x0, [x19, #8]
    64ec:	f949d841 	ldr	x1, [x2, #5040]
    64f0:	f949ec42 	ldr	x2, [x2, #5080]
    64f4:	cb010001 	sub	x1, x0, x1
    64f8:	eb02403f 	cmp	x1, x2, lsl #16
    64fc:	54000362 	b.cs	6568 <fwp_drop4+0x148>  // b.hs, b.nlast
    6500:	d350fc22 	lsr	x2, x1, #16
    6504:	8b020842 	add	x2, x2, x2, lsl #2
    6508:	d37df042 	lsl	x2, x2, #3
    650c:	8b020064 	add	x4, x3, x2
    6510:	f9401094 	ldr	x20, [x4, #32]
    6514:	b40002b4 	cbz	x20, 6568 <fwp_drop4+0x148>
    6518:	38626862 	ldrb	w2, [x3, x2]
    651c:	7100085f 	cmp	w2, #0x2
    6520:	540003e0 	b.eq	659c <fwp_drop4+0x17c>  // b.none
    6524:	7100045f 	cmp	w2, #0x1
    6528:	54000201 	b.ne	6568 <fwp_drop4+0x148>  // b.any
    652c:	29430883 	ldp	w3, w2, [x4, #24]
    6530:	92403c21 	and	x1, x1, #0xffff
    6534:	9b037c21 	mul	x1, x1, x3
    6538:	d360fc21 	lsr	x1, x1, #32
    653c:	eb02003f 	cmp	x1, x2
    6540:	54000142 	b.cs	6568 <fwp_drop4+0x148>  // b.hs, b.nlast
    6544:	8b010294 	add	x20, x20, x1
    6548:	39400281 	ldrb	w1, [x20]
    654c:	340000e1 	cbz	w1, 6568 <fwp_drop4+0x148>
    6550:	7100043f 	cmp	w1, #0x1
    6554:	54000200 	b.eq	6594 <fwp_drop4+0x174>  // b.none
    6558:	7103fc3f 	cmp	w1, #0xff
    655c:	54000580 	b.eq	660c <fwp_drop4+0x1ec>  // b.none
    6560:	51000421 	sub	w1, w1, #0x1
    6564:	39000281 	strb	w1, [x20]
    6568:	f9400a74 	ldr	x20, [x19, #16]
    656c:	aa1303e0 	mov	x0, x19
    6570:	97fffcf1 	bl	5934 <fwp_rc_free_arr>
    6574:	9118c2c0 	add	x0, x22, #0x630
    6578:	f949d801 	ldr	x1, [x0, #5040]
    657c:	f949ec00 	ldr	x0, [x0, #5080]
    6580:	cb010281 	sub	x1, x20, x1
    6584:	eb00403f 	cmp	x1, x0, lsl #16
    6588:	54fff9a2 	b.cs	64bc <fwp_drop4+0x9c>  // b.hs, b.nlast
    658c:	aa1403f3 	mov	x19, x20
    6590:	17ffffb0 	b	6450 <fwp_drop4+0x30>
    6594:	97fffce8 	bl	5934 <fwp_rc_free_arr>
    6598:	17fffff4 	b	6568 <fwp_drop4+0x148>
    659c:	72003c3f 	tst	w1, #0xffff
    65a0:	54fffe41 	b.ne	6568 <fwp_drop4+0x148>  // b.any
    65a4:	17ffffe9 	b	6548 <fwp_drop4+0x128>
    65a8:	ca544681 	eor	x1, x20, x20, lsr #17
    65ac:	9118c2c0 	add	x0, x22, #0x630
    65b0:	ca412421 	eor	x1, x1, x1, lsr #9
    65b4:	8b210c01 	add	x1, x0, w1, uxtb #3
    65b8:	f94a2420 	ldr	x0, [x1, #5192]
    65bc:	b5000080 	cbnz	x0, 65cc <fwp_drop4+0x1ac>
    65c0:	14000010 	b	6600 <fwp_drop4+0x1e0>
    65c4:	f9400800 	ldr	x0, [x0, #16]
    65c8:	b40001c0 	cbz	x0, 6600 <fwp_drop4+0x1e0>
    65cc:	f9400001 	ldr	x1, [x0]
    65d0:	eb14003f 	cmp	x1, x20
    65d4:	54ffff81 	b.ne	65c4 <fwp_drop4+0x1a4>  // b.any
    65d8:	f9400401 	ldr	x1, [x0, #8]
    65dc:	d1000421 	sub	x1, x1, #0x1
    65e0:	f9000401 	str	x1, [x0, #8]
    65e4:	f103f83f 	cmp	x1, #0xfe
    65e8:	54fff6a1 	b.ne	64bc <fwp_drop4+0x9c>  // b.any
    65ec:	aa1403e0 	mov	x0, x20
    65f0:	97fff908 	bl	4a10 <fwp_rc_forget_slot>
    65f4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65f8:	39000280 	strb	w0, [x20]
    65fc:	17ffffb0 	b	64bc <fwp_drop4+0x9c>
    6600:	f0000020 	adrp	x0, d000 <__modti3+0xf0>
    6604:	911dc000 	add	x0, x0, #0x770
    6608:	97fff47e 	bl	3800 <fwp_trap>
    660c:	ca544680 	eor	x0, x20, x20, lsr #17
    6610:	9118c2c1 	add	x1, x22, #0x630
    6614:	ca402400 	eor	x0, x0, x0, lsr #9
    6618:	8b200c20 	add	x0, x1, w0, uxtb #3
    661c:	f94a2400 	ldr	x0, [x0, #5192]
    6620:	b5000080 	cbnz	x0, 6630 <fwp_drop4+0x210>
    6624:	17fffff7 	b	6600 <fwp_drop4+0x1e0>
    6628:	f9400800 	ldr	x0, [x0, #16]
    662c:	b4fffea0 	cbz	x0, 6600 <fwp_drop4+0x1e0>
    6630:	f9400001 	ldr	x1, [x0]
    6634:	eb14003f 	cmp	x1, x20
    6638:	54ffff81 	b.ne	6628 <fwp_drop4+0x208>  // b.any
    663c:	f9400401 	ldr	x1, [x0, #8]
    6640:	d1000421 	sub	x1, x1, #0x1
    6644:	f9000401 	str	x1, [x0, #8]
    6648:	f103f83f 	cmp	x1, #0xfe
    664c:	54fff8e1 	b.ne	6568 <fwp_drop4+0x148>  // b.any
    6650:	aa1403e0 	mov	x0, x20
    6654:	97fff8ef 	bl	4a10 <fwp_rc_forget_slot>
    6658:	12800020 	mov	w0, #0xfffffffe            	// #-2
    665c:	39000280 	strb	w0, [x20]
    6660:	17ffffc2 	b	6568 <fwp_drop4+0x148>

0000000000006664 <fwp_arg_drop37>:
    6664:	7100003f 	cmp	w1, #0x0
    6668:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    666c:	54000041 	b.ne	6674 <fwp_arg_drop37+0x10>  // b.any
    6670:	d65f03c0 	ret
    6674:	f9400000 	ldr	x0, [x0]
    6678:	17ffff6a 	b	6420 <fwp_drop4>
    667c:	d503201f 	nop

0000000000006680 <fwp_task_dispose>:
    6680:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6684:	910003fd 	mov	x29, sp
    6688:	f9000bf3 	str	x19, [sp, #16]
    668c:	aa0003f3 	mov	x19, x0
    6690:	39414000 	ldrb	w0, [x0, #80]
    6694:	36000720 	tbz	w0, #0, 6778 <fwp_task_dispose+0xf8>
    6698:	f9400a60 	ldr	x0, [x19, #16]
    669c:	b50006e0 	cbnz	x0, 6778 <fwp_task_dispose+0xf8>
    66a0:	a9478660 	ldp	x0, x1, [x19, #120]
    66a4:	39014e7f 	strb	wzr, [x19, #83]
    66a8:	f9003e7f 	str	xzr, [x19, #120]
    66ac:	f100003f 	cmp	x1, #0x0
    66b0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    66b4:	54000040 	b.eq	66bc <fwp_task_dispose+0x3c>  // b.none
    66b8:	d63f0020 	blr	x1
    66bc:	f9405660 	ldr	x0, [x19, #168]
    66c0:	97fff974 	bl	4c90 <fwp_mem_free>
    66c4:	f900567f 	str	xzr, [x19, #168]
    66c8:	b9405e60 	ldr	w0, [x19, #92]
    66cc:	7100041f 	cmp	w0, #0x1
    66d0:	54000420 	b.eq	6754 <fwp_task_dispose+0xd4>  // b.none
    66d4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    66d8:	9118c042 	add	x2, x2, #0x630
    66dc:	f949d840 	ldr	x0, [x2, #5040]
    66e0:	f949ec41 	ldr	x1, [x2, #5080]
    66e4:	cb000260 	sub	x0, x19, x0
    66e8:	eb01401f 	cmp	x0, x1, lsl #16
    66ec:	540002e2 	b.cs	6748 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    66f0:	d350fc01 	lsr	x1, x0, #16
    66f4:	f949fc44 	ldr	x4, [x2, #5112]
    66f8:	8b010821 	add	x1, x1, x1, lsl #2
    66fc:	d37df021 	lsl	x1, x1, #3
    6700:	8b010083 	add	x3, x4, x1
    6704:	f9401062 	ldr	x2, [x3, #32]
    6708:	b4000202 	cbz	x2, 6748 <fwp_task_dispose+0xc8>
    670c:	38616881 	ldrb	w1, [x4, x1]
    6710:	7100083f 	cmp	w1, #0x2
    6714:	54000280 	b.eq	6764 <fwp_task_dispose+0xe4>  // b.none
    6718:	7100043f 	cmp	w1, #0x1
    671c:	54000161 	b.ne	6748 <fwp_task_dispose+0xc8>  // b.any
    6720:	29430464 	ldp	w4, w1, [x3, #24]
    6724:	92403c00 	and	x0, x0, #0xffff
    6728:	9b047c00 	mul	x0, x0, x4
    672c:	d360fc00 	lsr	x0, x0, #32
    6730:	eb01001f 	cmp	x0, x1
    6734:	540000a2 	b.cs	6748 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6738:	8b000042 	add	x2, x2, x0
    673c:	39400040 	ldrb	w0, [x2]
    6740:	7100041f 	cmp	w0, #0x1
    6744:	54000080 	b.eq	6754 <fwp_task_dispose+0xd4>  // b.none
    6748:	f9400bf3 	ldr	x19, [sp, #16]
    674c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6750:	d65f03c0 	ret
    6754:	aa1303e0 	mov	x0, x19
    6758:	f9400bf3 	ldr	x19, [sp, #16]
    675c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6760:	17fff94c 	b	4c90 <fwp_mem_free>
    6764:	72003c1f 	tst	w0, #0xffff
    6768:	54fffea0 	b.eq	673c <fwp_task_dispose+0xbc>  // b.none
    676c:	f9400bf3 	ldr	x19, [sp, #16]
    6770:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6774:	d65f03c0 	ret
    6778:	97fff05e 	bl	28f0 <abort@plt>
    677c:	d503201f 	nop

0000000000006780 <fwp_free_zombie>:
    6780:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6784:	910003fd 	mov	x29, sp
    6788:	a90153f3 	stp	x19, x20, [sp, #16]
    678c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6790:	91014281 	add	x1, x20, #0x50
    6794:	f940b433 	ldr	x19, [x1, #360]
    6798:	b4000333 	cbz	x19, 67fc <fwp_free_zombie+0x7c>
    679c:	f9404c20 	ldr	x0, [x1, #152]
    67a0:	eb00027f 	cmp	x19, x0
    67a4:	540002c0 	b.eq	67fc <fwp_free_zombie+0x7c>  // b.none
    67a8:	b9417022 	ldr	w2, [x1, #368]
    67ac:	f9400a60 	ldr	x0, [x19, #16]
    67b0:	7100fc5f 	cmp	w2, #0x3f
    67b4:	5400078c 	b.gt	68a4 <fwp_free_zombie+0x124>
    67b8:	91060023 	add	x3, x1, #0x180
    67bc:	11000444 	add	w4, w2, #0x1
    67c0:	b9017024 	str	w4, [x1, #368]
    67c4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67c8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    67cc:	a9530261 	ldp	x1, x0, [x19, #304]
    67d0:	b4000741 	cbz	x1, 68b8 <fwp_free_zombie+0x138>
    67d4:	f9009c20 	str	x0, [x1, #312]
    67d8:	b4000040 	cbz	x0, 67e0 <fwp_free_zombie+0x60>
    67dc:	f9009801 	str	x1, [x0, #304]
    67e0:	91014294 	add	x20, x20, #0x50
    67e4:	b9405e60 	ldr	w0, [x19, #92]
    67e8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    67ec:	f900b69f 	str	xzr, [x20, #360]
    67f0:	34000140 	cbz	w0, 6818 <fwp_free_zombie+0x98>
    67f4:	7100041f 	cmp	w0, #0x1
    67f8:	54000080 	b.eq	6808 <fwp_free_zombie+0x88>  // b.none
    67fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6800:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6804:	d65f03c0 	ret
    6808:	aa1303e0 	mov	x0, x19
    680c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6810:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6814:	17ffff9b 	b	6680 <fwp_task_dispose>
    6818:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbb0>
    681c:	9118c082 	add	x2, x4, #0x630
    6820:	f949d841 	ldr	x1, [x2, #5040]
    6824:	f949ec40 	ldr	x0, [x2, #5080]
    6828:	cb010261 	sub	x1, x19, x1
    682c:	eb00403f 	cmp	x1, x0, lsl #16
    6830:	54fffe62 	b.cs	67fc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6834:	d350fc20 	lsr	x0, x1, #16
    6838:	f949fc43 	ldr	x3, [x2, #5112]
    683c:	8b000800 	add	x0, x0, x0, lsl #2
    6840:	d37df000 	lsl	x0, x0, #3
    6844:	8b000062 	add	x2, x3, x0
    6848:	f9401054 	ldr	x20, [x2, #32]
    684c:	b4fffd94 	cbz	x20, 67fc <fwp_free_zombie+0x7c>
    6850:	38606860 	ldrb	w0, [x3, x0]
    6854:	7100081f 	cmp	w0, #0x2
    6858:	54000360 	b.eq	68c4 <fwp_free_zombie+0x144>  // b.none
    685c:	7100041f 	cmp	w0, #0x1
    6860:	54fffce1 	b.ne	67fc <fwp_free_zombie+0x7c>  // b.any
    6864:	29430043 	ldp	w3, w0, [x2, #24]
    6868:	92403c21 	and	x1, x1, #0xffff
    686c:	9b037c21 	mul	x1, x1, x3
    6870:	d360fc21 	lsr	x1, x1, #32
    6874:	eb00003f 	cmp	x1, x0
    6878:	54fffc22 	b.cs	67fc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    687c:	8b010294 	add	x20, x20, x1
    6880:	39400280 	ldrb	w0, [x20]
    6884:	34fffbc0 	cbz	w0, 67fc <fwp_free_zombie+0x7c>
    6888:	7100041f 	cmp	w0, #0x1
    688c:	54fffbe0 	b.eq	6808 <fwp_free_zombie+0x88>  // b.none
    6890:	7103fc1f 	cmp	w0, #0xff
    6894:	540001e0 	b.eq	68d0 <fwp_free_zombie+0x150>  // b.none
    6898:	51000400 	sub	w0, w0, #0x1
    689c:	39000280 	strb	w0, [x20]
    68a0:	17ffffd7 	b	67fc <fwp_free_zombie+0x7c>
    68a4:	f9400e61 	ldr	x1, [x19, #24]
    68a8:	97fff046 	bl	29c0 <munmap@plt>
    68ac:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    68b0:	a9530261 	ldp	x1, x0, [x19, #304]
    68b4:	b5fff901 	cbnz	x1, 67d4 <fwp_free_zombie+0x54>
    68b8:	91014282 	add	x2, x20, #0x50
    68bc:	f901c040 	str	x0, [x2, #896]
    68c0:	17ffffc6 	b	67d8 <fwp_free_zombie+0x58>
    68c4:	72003c3f 	tst	w1, #0xffff
    68c8:	54fff9a1 	b.ne	67fc <fwp_free_zombie+0x7c>  // b.any
    68cc:	17ffffed 	b	6880 <fwp_free_zombie+0x100>
    68d0:	ca544680 	eor	x0, x20, x20, lsr #17
    68d4:	9118c084 	add	x4, x4, #0x630
    68d8:	ca402400 	eor	x0, x0, x0, lsr #9
    68dc:	8b200c80 	add	x0, x4, w0, uxtb #3
    68e0:	f94a2400 	ldr	x0, [x0, #5192]
    68e4:	b5000080 	cbnz	x0, 68f4 <fwp_free_zombie+0x174>
    68e8:	14000010 	b	6928 <fwp_free_zombie+0x1a8>
    68ec:	f9400800 	ldr	x0, [x0, #16]
    68f0:	b40001c0 	cbz	x0, 6928 <fwp_free_zombie+0x1a8>
    68f4:	f9400001 	ldr	x1, [x0]
    68f8:	eb14003f 	cmp	x1, x20
    68fc:	54ffff81 	b.ne	68ec <fwp_free_zombie+0x16c>  // b.any
    6900:	f9400401 	ldr	x1, [x0, #8]
    6904:	d1000421 	sub	x1, x1, #0x1
    6908:	f9000401 	str	x1, [x0, #8]
    690c:	f103f83f 	cmp	x1, #0xfe
    6910:	54fff761 	b.ne	67fc <fwp_free_zombie+0x7c>  // b.any
    6914:	aa1403e0 	mov	x0, x20
    6918:	97fff83e 	bl	4a10 <fwp_rc_forget_slot>
    691c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6920:	39000280 	strb	w0, [x20]
    6924:	17ffffb6 	b	67fc <fwp_free_zombie+0x7c>
    6928:	f0000020 	adrp	x0, d000 <__modti3+0xf0>
    692c:	911dc000 	add	x0, x0, #0x770
    6930:	97fff3b4 	bl	3800 <fwp_trap>

0000000000006934 <fwp_block>:
    6934:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6938:	910003fd 	mov	x29, sp
    693c:	a90153f3 	stp	x19, x20, [sp, #16]
    6940:	d00000d3 	adrp	x19, 20000 <__data_start>
    6944:	91014274 	add	x20, x19, #0x50
    6948:	f9406682 	ldr	x2, [x20, #200]
    694c:	b4000622 	cbz	x2, 6a10 <fwp_block+0xdc>
    6950:	91014261 	add	x1, x19, #0x50
    6954:	f9408040 	ldr	x0, [x2, #256]
    6958:	f9006420 	str	x0, [x1, #200]
    695c:	b4000680 	cbz	x0, 6a2c <fwp_block+0xf8>
    6960:	91014263 	add	x3, x19, #0x50
    6964:	3901505f 	strb	wzr, [x2, #84]
    6968:	f9404c64 	ldr	x4, [x3, #152]
    696c:	eb02009f 	cmp	x4, x2
    6970:	54000440 	b.eq	69f8 <fwp_block+0xc4>  // b.none
    6974:	f941c465 	ldr	x5, [x3, #904]
    6978:	f9004c62 	str	x2, [x3, #152]
    697c:	f9400441 	ldr	x1, [x2, #8]
    6980:	f9004885 	str	x5, [x4, #144]
    6984:	f941c865 	ldr	x5, [x3, #912]
    6988:	f9004c85 	str	x5, [x4, #152]
    698c:	f941cc65 	ldr	x5, [x3, #920]
    6990:	f9005085 	str	x5, [x4, #160]
    6994:	f941d065 	ldr	x5, [x3, #928]
    6998:	f9005485 	str	x5, [x4, #168]
    699c:	f941d465 	ldr	x5, [x3, #936]
    69a0:	f9005885 	str	x5, [x4, #176]
    69a4:	f941d865 	ldr	x5, [x3, #944]
    69a8:	f9005c85 	str	x5, [x4, #184]
    69ac:	f941dc65 	ldr	x5, [x3, #952]
    69b0:	f9006085 	str	x5, [x4, #192]
    69b4:	f9400480 	ldr	x0, [x4, #8]
    69b8:	f9404844 	ldr	x4, [x2, #144]
    69bc:	f901c464 	str	x4, [x3, #904]
    69c0:	f9404c44 	ldr	x4, [x2, #152]
    69c4:	f901c864 	str	x4, [x3, #912]
    69c8:	f9405044 	ldr	x4, [x2, #160]
    69cc:	f901cc64 	str	x4, [x3, #920]
    69d0:	f9405444 	ldr	x4, [x2, #168]
    69d4:	f901d064 	str	x4, [x3, #928]
    69d8:	f9405844 	ldr	x4, [x2, #176]
    69dc:	f901d464 	str	x4, [x3, #936]
    69e0:	a94b8844 	ldp	x4, x2, [x2, #184]
    69e4:	f901d864 	str	x4, [x3, #944]
    69e8:	f901dc62 	str	x2, [x3, #952]
    69ec:	97ffefc5 	bl	2900 <swapcontext@plt>
    69f0:	97ffff64 	bl	6780 <fwp_free_zombie>
    69f4:	d503201f 	nop
    69f8:	91014260 	add	x0, x19, #0x50
    69fc:	b943c000 	ldr	w0, [x0, #960]
    6a00:	340001a0 	cbz	w0, 6a34 <fwp_block+0x100>
    6a04:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a0c:	d65f03c0 	ret
    6a10:	97fff72d 	bl	46c4 <fwp_poll_events>
    6a14:	f9406682 	ldr	x2, [x20, #200]
    6a18:	b4ffffc2 	cbz	x2, 6a10 <fwp_block+0xdc>
    6a1c:	91014261 	add	x1, x19, #0x50
    6a20:	f9408040 	ldr	x0, [x2, #256]
    6a24:	f9006420 	str	x0, [x1, #200]
    6a28:	b5fff9c0 	cbnz	x0, 6960 <fwp_block+0x2c>
    6a2c:	f900603f 	str	xzr, [x1, #192]
    6a30:	17ffffcc 	b	6960 <fwp_block+0x2c>
    6a34:	f0000020 	adrp	x0, d000 <__modti3+0xf0>
    6a38:	91228000 	add	x0, x0, #0x8a0
    6a3c:	97ffeffd 	bl	2a30 <getenv@plt>
    6a40:	5284e202 	mov	w2, #0x2710                	// #10000
    6a44:	b4000060 	cbz	x0, 6a50 <fwp_block+0x11c>
    6a48:	39400001 	ldrb	w1, [x0]
    6a4c:	350000c1 	cbnz	w1, 6a64 <fwp_block+0x130>
    6a50:	91014273 	add	x19, x19, #0x50
    6a54:	b903c262 	str	w2, [x19, #960]
    6a58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a60:	d65f03c0 	ret
    6a64:	52800142 	mov	w2, #0xa                   	// #10
    6a68:	d2800001 	mov	x1, #0x0                   	// #0
    6a6c:	97ffef41 	bl	2770 <strtoll@plt>
    6a70:	d1000403 	sub	x3, x0, #0x1
    6a74:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6a78:	eb02007f 	cmp	x3, x2
    6a7c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6a80:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6a84:	17fffff3 	b	6a50 <fwp_block+0x11c>
    6a88:	d503201f 	nop
    6a8c:	d503201f 	nop

0000000000006a90 <fwp_drop10>:
    6a90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6a94:	910003fd 	mov	x29, sp
    6a98:	a90153f3 	stp	x19, x20, [sp, #16]
    6a9c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    6aa0:	f90013f5 	str	x21, [sp, #32]
    6aa4:	9118c275 	add	x21, x19, #0x630
    6aa8:	f949daa1 	ldr	x1, [x21, #5040]
    6aac:	f949eea2 	ldr	x2, [x21, #5080]
    6ab0:	cb010001 	sub	x1, x0, x1
    6ab4:	eb02403f 	cmp	x1, x2, lsl #16
    6ab8:	54000382 	b.cs	6b28 <fwp_drop10+0x98>  // b.hs, b.nlast
    6abc:	d350fc22 	lsr	x2, x1, #16
    6ac0:	f949fea3 	ldr	x3, [x21, #5112]
    6ac4:	8b020842 	add	x2, x2, x2, lsl #2
    6ac8:	d37df042 	lsl	x2, x2, #3
    6acc:	8b020064 	add	x4, x3, x2
    6ad0:	f9401094 	ldr	x20, [x4, #32]
    6ad4:	b40002b4 	cbz	x20, 6b28 <fwp_drop10+0x98>
    6ad8:	38626862 	ldrb	w2, [x3, x2]
    6adc:	7100085f 	cmp	w2, #0x2
    6ae0:	540007a0 	b.eq	6bd4 <fwp_drop10+0x144>  // b.none
    6ae4:	7100045f 	cmp	w2, #0x1
    6ae8:	54000201 	b.ne	6b28 <fwp_drop10+0x98>  // b.any
    6aec:	29430885 	ldp	w5, w2, [x4, #24]
    6af0:	92403c21 	and	x1, x1, #0xffff
    6af4:	9b057c21 	mul	x1, x1, x5
    6af8:	d360fc21 	lsr	x1, x1, #32
    6afc:	eb02003f 	cmp	x1, x2
    6b00:	54000142 	b.cs	6b28 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b04:	8b010294 	add	x20, x20, x1
    6b08:	39400281 	ldrb	w1, [x20]
    6b0c:	340000e1 	cbz	w1, 6b28 <fwp_drop10+0x98>
    6b10:	7100043f 	cmp	w1, #0x1
    6b14:	54000120 	b.eq	6b38 <fwp_drop10+0xa8>  // b.none
    6b18:	7103fc3f 	cmp	w1, #0xff
    6b1c:	540007c0 	b.eq	6c14 <fwp_drop10+0x184>  // b.none
    6b20:	51000421 	sub	w1, w1, #0x1
    6b24:	39000281 	strb	w1, [x20]
    6b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b2c:	f94013f5 	ldr	x21, [sp, #32]
    6b30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b34:	d65f03c0 	ret
    6b38:	f9400001 	ldr	x1, [x0]
    6b3c:	b7f80581 	tbnz	x1, #63, 6bec <fwp_drop10+0x15c>
    6b40:	9118c273 	add	x19, x19, #0x630
    6b44:	f949da61 	ldr	x1, [x19, #5040]
    6b48:	f949ee62 	ldr	x2, [x19, #5080]
    6b4c:	cb010001 	sub	x1, x0, x1
    6b50:	eb02403f 	cmp	x1, x2, lsl #16
    6b54:	54fffea2 	b.cs	6b28 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b58:	d350fc22 	lsr	x2, x1, #16
    6b5c:	8b020842 	add	x2, x2, x2, lsl #2
    6b60:	d37df042 	lsl	x2, x2, #3
    6b64:	8b020065 	add	x5, x3, x2
    6b68:	f94010a4 	ldr	x4, [x5, #32]
    6b6c:	b4fffde4 	cbz	x4, 6b28 <fwp_drop10+0x98>
    6b70:	38626862 	ldrb	w2, [x3, x2]
    6b74:	7100085f 	cmp	w2, #0x2
    6b78:	54000220 	b.eq	6bbc <fwp_drop10+0x12c>  // b.none
    6b7c:	7100045f 	cmp	w2, #0x1
    6b80:	54fffd41 	b.ne	6b28 <fwp_drop10+0x98>  // b.any
    6b84:	294308a3 	ldp	w3, w2, [x5, #24]
    6b88:	92403c21 	and	x1, x1, #0xffff
    6b8c:	9b037c21 	mul	x1, x1, x3
    6b90:	d360fc21 	lsr	x1, x1, #32
    6b94:	eb02003f 	cmp	x1, x2
    6b98:	54fffc82 	b.cs	6b28 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b9c:	8b010084 	add	x4, x4, x1
    6ba0:	39400081 	ldrb	w1, [x4]
    6ba4:	7100043f 	cmp	w1, #0x1
    6ba8:	54fffc01 	b.ne	6b28 <fwp_drop10+0x98>  // b.any
    6bac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bb0:	f94013f5 	ldr	x21, [sp, #32]
    6bb4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bb8:	17fff836 	b	4c90 <fwp_mem_free>
    6bbc:	72003c3f 	tst	w1, #0xffff
    6bc0:	54ffff00 	b.eq	6ba0 <fwp_drop10+0x110>  // b.none
    6bc4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bc8:	f94013f5 	ldr	x21, [sp, #32]
    6bcc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bd0:	d65f03c0 	ret
    6bd4:	72003c3f 	tst	w1, #0xffff
    6bd8:	54fff980 	b.eq	6b08 <fwp_drop10+0x78>  // b.none
    6bdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6be0:	f94013f5 	ldr	x21, [sp, #32]
    6be4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6be8:	d65f03c0 	ret
    6bec:	f9400414 	ldr	x20, [x0, #8]
    6bf0:	97fffb51 	bl	5934 <fwp_rc_free_arr>
    6bf4:	9118c260 	add	x0, x19, #0x630
    6bf8:	f949d801 	ldr	x1, [x0, #5040]
    6bfc:	f949ec00 	ldr	x0, [x0, #5080]
    6c00:	cb010281 	sub	x1, x20, x1
    6c04:	eb00403f 	cmp	x1, x0, lsl #16
    6c08:	54fff902 	b.cs	6b28 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c0c:	aa1403e0 	mov	x0, x20
    6c10:	17ffffab 	b	6abc <fwp_drop10+0x2c>
    6c14:	ca544680 	eor	x0, x20, x20, lsr #17
    6c18:	9118c273 	add	x19, x19, #0x630
    6c1c:	ca402400 	eor	x0, x0, x0, lsr #9
    6c20:	8b200e60 	add	x0, x19, w0, uxtb #3
    6c24:	f94a2400 	ldr	x0, [x0, #5192]
    6c28:	b5000080 	cbnz	x0, 6c38 <fwp_drop10+0x1a8>
    6c2c:	14000010 	b	6c6c <fwp_drop10+0x1dc>
    6c30:	f9400800 	ldr	x0, [x0, #16]
    6c34:	b40001c0 	cbz	x0, 6c6c <fwp_drop10+0x1dc>
    6c38:	f9400001 	ldr	x1, [x0]
    6c3c:	eb14003f 	cmp	x1, x20
    6c40:	54ffff81 	b.ne	6c30 <fwp_drop10+0x1a0>  // b.any
    6c44:	f9400401 	ldr	x1, [x0, #8]
    6c48:	d1000421 	sub	x1, x1, #0x1
    6c4c:	f9000401 	str	x1, [x0, #8]
    6c50:	f103f83f 	cmp	x1, #0xfe
    6c54:	54fff6a1 	b.ne	6b28 <fwp_drop10+0x98>  // b.any
    6c58:	aa1403e0 	mov	x0, x20
    6c5c:	97fff76d 	bl	4a10 <fwp_rc_forget_slot>
    6c60:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c64:	39000280 	strb	w0, [x20]
    6c68:	17ffffb0 	b	6b28 <fwp_drop10+0x98>
    6c6c:	f0000020 	adrp	x0, d000 <__modti3+0xf0>
    6c70:	911dc000 	add	x0, x0, #0x770
    6c74:	97fff2e3 	bl	3800 <fwp_trap>
    6c78:	d503201f 	nop
    6c7c:	d503201f 	nop

0000000000006c80 <fwp_caps173>:
    6c80:	34000041 	cbz	w1, 6c88 <fwp_caps173+0x8>
    6c84:	d65f03c0 	ret
    6c88:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    6c8c:	9118c063 	add	x3, x3, #0x630
    6c90:	f949d861 	ldr	x1, [x3, #5040]
    6c94:	f949ec62 	ldr	x2, [x3, #5080]
    6c98:	cb010001 	sub	x1, x0, x1
    6c9c:	eb02403f 	cmp	x1, x2, lsl #16
    6ca0:	54ffff22 	b.cs	6c84 <fwp_caps173+0x4>  // b.hs, b.nlast
    6ca4:	d350fc22 	lsr	x2, x1, #16
    6ca8:	f949fc65 	ldr	x5, [x3, #5112]
    6cac:	8b020842 	add	x2, x2, x2, lsl #2
    6cb0:	d37df042 	lsl	x2, x2, #3
    6cb4:	8b0200a4 	add	x4, x5, x2
    6cb8:	f9401083 	ldr	x3, [x4, #32]
    6cbc:	b4fffe43 	cbz	x3, 6c84 <fwp_caps173+0x4>
    6cc0:	386268a2 	ldrb	w2, [x5, x2]
    6cc4:	7100085f 	cmp	w2, #0x2
    6cc8:	540001c0 	b.eq	6d00 <fwp_caps173+0x80>  // b.none
    6ccc:	7100045f 	cmp	w2, #0x1
    6cd0:	54fffda1 	b.ne	6c84 <fwp_caps173+0x4>  // b.any
    6cd4:	29430885 	ldp	w5, w2, [x4, #24]
    6cd8:	92403c21 	and	x1, x1, #0xffff
    6cdc:	9b057c21 	mul	x1, x1, x5
    6ce0:	d360fc21 	lsr	x1, x1, #32
    6ce4:	eb02003f 	cmp	x1, x2
    6ce8:	54fffce2 	b.cs	6c84 <fwp_caps173+0x4>  // b.hs, b.nlast
    6cec:	8b010063 	add	x3, x3, x1
    6cf0:	39400061 	ldrb	w1, [x3]
    6cf4:	7100043f 	cmp	w1, #0x1
    6cf8:	54fffc61 	b.ne	6c84 <fwp_caps173+0x4>  // b.any
    6cfc:	17fff7e5 	b	4c90 <fwp_mem_free>
    6d00:	72003c3f 	tst	w1, #0xffff
    6d04:	54ffff60 	b.eq	6cf0 <fwp_caps173+0x70>  // b.none
    6d08:	d65f03c0 	ret
    6d0c:	d503201f 	nop

0000000000006d10 <fwp_args37>:
    6d10:	7100003f 	cmp	w1, #0x0
    6d14:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6d18:	54000041 	b.ne	6d20 <fwp_args37+0x10>  // b.any
    6d1c:	d65f03c0 	ret
    6d20:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6d24:	9118c042 	add	x2, x2, #0x630
    6d28:	f9400001 	ldr	x1, [x0]
    6d2c:	f949d843 	ldr	x3, [x2, #5040]
    6d30:	f949ec40 	ldr	x0, [x2, #5080]
    6d34:	cb030021 	sub	x1, x1, x3
    6d38:	eb00403f 	cmp	x1, x0, lsl #16
    6d3c:	54ffff02 	b.cs	6d1c <fwp_args37+0xc>  // b.hs, b.nlast
    6d40:	d350fc20 	lsr	x0, x1, #16
    6d44:	f949fc44 	ldr	x4, [x2, #5112]
    6d48:	8b000800 	add	x0, x0, x0, lsl #2
    6d4c:	d37df002 	lsl	x2, x0, #3
    6d50:	8b020083 	add	x3, x4, x2
    6d54:	f9401060 	ldr	x0, [x3, #32]
    6d58:	b4fffe20 	cbz	x0, 6d1c <fwp_args37+0xc>
    6d5c:	38626882 	ldrb	w2, [x4, x2]
    6d60:	7100085f 	cmp	w2, #0x2
    6d64:	54000320 	b.eq	6dc8 <fwp_args37+0xb8>  // b.none
    6d68:	7100045f 	cmp	w2, #0x1
    6d6c:	54fffd81 	b.ne	6d1c <fwp_args37+0xc>  // b.any
    6d70:	29430864 	ldp	w4, w2, [x3, #24]
    6d74:	92403c21 	and	x1, x1, #0xffff
    6d78:	9b047c21 	mul	x1, x1, x4
    6d7c:	d360fc21 	lsr	x1, x1, #32
    6d80:	eb02003f 	cmp	x1, x2
    6d84:	54fffcc2 	b.cs	6d1c <fwp_args37+0xc>  // b.hs, b.nlast
    6d88:	8b010000 	add	x0, x0, x1
    6d8c:	39400001 	ldrb	w1, [x0]
    6d90:	34fffc61 	cbz	w1, 6d1c <fwp_args37+0xc>
    6d94:	d00000c2 	adrp	x2, 20000 <__data_start>
    6d98:	91014042 	add	x2, x2, #0x50
    6d9c:	b9413043 	ldr	w3, [x2, #304]
    6da0:	350000c3 	cbnz	w3, 6db8 <fwp_args37+0xa8>
    6da4:	7103f43f 	cmp	w1, #0xfd
    6da8:	54000168 	b.hi	6dd4 <fwp_args37+0xc4>  // b.pmore
    6dac:	11000421 	add	w1, w1, #0x1
    6db0:	39000001 	strb	w1, [x0]
    6db4:	d65f03c0 	ret
    6db8:	f940ac43 	ldr	x3, [x2, #344]
    6dbc:	91000463 	add	x3, x3, #0x1
    6dc0:	f900ac43 	str	x3, [x2, #344]
    6dc4:	17fffff8 	b	6da4 <fwp_args37+0x94>
    6dc8:	72003c3f 	tst	w1, #0xffff
    6dcc:	54fffe00 	b.eq	6d8c <fwp_args37+0x7c>  // b.none
    6dd0:	d65f03c0 	ret
    6dd4:	17fff6c8 	b	48f4 <fwp_rc_wide_dup>
    6dd8:	d503201f 	nop
    6ddc:	d503201f 	nop

0000000000006de0 <fwp_caps37>:
    6de0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6de4:	910003fd 	mov	x29, sp
    6de8:	f9000bf3 	str	x19, [sp, #16]
    6dec:	aa0003f3 	mov	x19, x0
    6df0:	b9400400 	ldr	w0, [x0, #4]
    6df4:	340004a0 	cbz	w0, 6e88 <fwp_caps37+0xa8>
    6df8:	f9400660 	ldr	x0, [x19, #8]
    6dfc:	350004e1 	cbnz	w1, 6e98 <fwp_caps37+0xb8>
    6e00:	97fffd88 	bl	6420 <fwp_drop4>
    6e04:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6e08:	9118c042 	add	x2, x2, #0x630
    6e0c:	f949d840 	ldr	x0, [x2, #5040]
    6e10:	f949ec41 	ldr	x1, [x2, #5080]
    6e14:	cb000260 	sub	x0, x19, x0
    6e18:	eb01401f 	cmp	x0, x1, lsl #16
    6e1c:	54000382 	b.cs	6e8c <fwp_caps37+0xac>  // b.hs, b.nlast
    6e20:	d350fc01 	lsr	x1, x0, #16
    6e24:	f949fc44 	ldr	x4, [x2, #5112]
    6e28:	8b010821 	add	x1, x1, x1, lsl #2
    6e2c:	d37df021 	lsl	x1, x1, #3
    6e30:	8b010083 	add	x3, x4, x1
    6e34:	f9401062 	ldr	x2, [x3, #32]
    6e38:	b40002a2 	cbz	x2, 6e8c <fwp_caps37+0xac>
    6e3c:	38616881 	ldrb	w1, [x4, x1]
    6e40:	7100083f 	cmp	w1, #0x2
    6e44:	54000740 	b.eq	6f2c <fwp_caps37+0x14c>  // b.none
    6e48:	7100043f 	cmp	w1, #0x1
    6e4c:	54000201 	b.ne	6e8c <fwp_caps37+0xac>  // b.any
    6e50:	29430464 	ldp	w4, w1, [x3, #24]
    6e54:	92403c00 	and	x0, x0, #0xffff
    6e58:	9b047c00 	mul	x0, x0, x4
    6e5c:	d360fc00 	lsr	x0, x0, #32
    6e60:	eb01001f 	cmp	x0, x1
    6e64:	54000142 	b.cs	6e8c <fwp_caps37+0xac>  // b.hs, b.nlast
    6e68:	8b000042 	add	x2, x2, x0
    6e6c:	39400040 	ldrb	w0, [x2]
    6e70:	7100041f 	cmp	w0, #0x1
    6e74:	540000c1 	b.ne	6e8c <fwp_caps37+0xac>  // b.any
    6e78:	aa1303e0 	mov	x0, x19
    6e7c:	f9400bf3 	ldr	x19, [sp, #16]
    6e80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e84:	17fff783 	b	4c90 <fwp_mem_free>
    6e88:	34fffbe1 	cbz	w1, 6e04 <fwp_caps37+0x24>
    6e8c:	f9400bf3 	ldr	x19, [sp, #16]
    6e90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e94:	d65f03c0 	ret
    6e98:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6e9c:	9118c042 	add	x2, x2, #0x630
    6ea0:	f949d843 	ldr	x3, [x2, #5040]
    6ea4:	f949ec41 	ldr	x1, [x2, #5080]
    6ea8:	cb030000 	sub	x0, x0, x3
    6eac:	eb01401f 	cmp	x0, x1, lsl #16
    6eb0:	54fffee2 	b.cs	6e8c <fwp_caps37+0xac>  // b.hs, b.nlast
    6eb4:	d350fc01 	lsr	x1, x0, #16
    6eb8:	f949fc44 	ldr	x4, [x2, #5112]
    6ebc:	8b010821 	add	x1, x1, x1, lsl #2
    6ec0:	d37df021 	lsl	x1, x1, #3
    6ec4:	8b010083 	add	x3, x4, x1
    6ec8:	f9401062 	ldr	x2, [x3, #32]
    6ecc:	b4fffe02 	cbz	x2, 6e8c <fwp_caps37+0xac>
    6ed0:	38616881 	ldrb	w1, [x4, x1]
    6ed4:	7100083f 	cmp	w1, #0x2
    6ed8:	54000300 	b.eq	6f38 <fwp_caps37+0x158>  // b.none
    6edc:	7100043f 	cmp	w1, #0x1
    6ee0:	54fffd61 	b.ne	6e8c <fwp_caps37+0xac>  // b.any
    6ee4:	92403c01 	and	x1, x0, #0xffff
    6ee8:	29430064 	ldp	w4, w0, [x3, #24]
    6eec:	9b047c21 	mul	x1, x1, x4
    6ef0:	d360fc21 	lsr	x1, x1, #32
    6ef4:	eb00003f 	cmp	x1, x0
    6ef8:	54fffca2 	b.cs	6e8c <fwp_caps37+0xac>  // b.hs, b.nlast
    6efc:	8b010042 	add	x2, x2, x1
    6f00:	39400040 	ldrb	w0, [x2]
    6f04:	34fffc40 	cbz	w0, 6e8c <fwp_caps37+0xac>
    6f08:	d00000c1 	adrp	x1, 20000 <__data_start>
    6f0c:	91014021 	add	x1, x1, #0x50
    6f10:	b9413023 	ldr	w3, [x1, #304]
    6f14:	35000183 	cbnz	w3, 6f44 <fwp_caps37+0x164>
    6f18:	7103f41f 	cmp	w0, #0xfd
    6f1c:	540001c8 	b.hi	6f54 <fwp_caps37+0x174>  // b.pmore
    6f20:	11000400 	add	w0, w0, #0x1
    6f24:	39000040 	strb	w0, [x2]
    6f28:	17ffffd9 	b	6e8c <fwp_caps37+0xac>
    6f2c:	72003c1f 	tst	w0, #0xffff
    6f30:	54fffae1 	b.ne	6e8c <fwp_caps37+0xac>  // b.any
    6f34:	17ffffce 	b	6e6c <fwp_caps37+0x8c>
    6f38:	72003c1f 	tst	w0, #0xffff
    6f3c:	54fffa81 	b.ne	6e8c <fwp_caps37+0xac>  // b.any
    6f40:	17fffff0 	b	6f00 <fwp_caps37+0x120>
    6f44:	f940ac23 	ldr	x3, [x1, #344]
    6f48:	91000463 	add	x3, x3, #0x1
    6f4c:	f900ac23 	str	x3, [x1, #344]
    6f50:	17fffff2 	b	6f18 <fwp_caps37+0x138>
    6f54:	f9400bf3 	ldr	x19, [sp, #16]
    6f58:	aa0203e0 	mov	x0, x2
    6f5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f60:	17fff665 	b	48f4 <fwp_rc_wide_dup>

0000000000006f64 <f37>:
    6f64:	d10203ff 	sub	sp, sp, #0x80
    6f68:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6f6c:	f947f421 	ldr	x1, [x1, #4072]
    6f70:	a9027bfd 	stp	x29, x30, [sp, #32]
    6f74:	910083fd 	add	x29, sp, #0x20
    6f78:	a9045bf5 	stp	x21, x22, [sp, #64]
    6f7c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    6f80:	9118c2c3 	add	x3, x22, #0x630
    6f84:	a90353f3 	stp	x19, x20, [sp, #48]
    6f88:	a90563f7 	stp	x23, x24, [sp, #80]
    6f8c:	aa0003f8 	mov	x24, x0
    6f90:	a9066bf9 	stp	x25, x26, [sp, #96]
    6f94:	f949ec62 	ldr	x2, [x3, #5080]
    6f98:	f9400024 	ldr	x4, [x1]
    6f9c:	f9000fe4 	str	x4, [sp, #24]
    6fa0:	d2800004 	mov	x4, #0x0                   	// #0
    6fa4:	f949d861 	ldr	x1, [x3, #5040]
    6fa8:	d370bc42 	lsl	x2, x2, #16
    6fac:	b40018c0 	cbz	x0, 72c4 <f37+0x360>
    6fb0:	f9400819 	ldr	x25, [x0, #16]
    6fb4:	cb010321 	sub	x1, x25, x1
    6fb8:	eb02003f 	cmp	x1, x2
    6fbc:	540003e2 	b.cs	7038 <f37+0xd4>  // b.hs, b.nlast
    6fc0:	f949fc60 	ldr	x0, [x3, #5112]
    6fc4:	d350fc22 	lsr	x2, x1, #16
    6fc8:	8b020842 	add	x2, x2, x2, lsl #2
    6fcc:	8b020c02 	add	x2, x0, x2, lsl #3
    6fd0:	f9401040 	ldr	x0, [x2, #32]
    6fd4:	b4000320 	cbz	x0, 7038 <f37+0xd4>
    6fd8:	39400043 	ldrb	w3, [x2]
    6fdc:	7100087f 	cmp	w3, #0x2
    6fe0:	54001640 	b.eq	72a8 <f37+0x344>  // b.none
    6fe4:	7100047f 	cmp	w3, #0x1
    6fe8:	54000241 	b.ne	7030 <f37+0xcc>  // b.any
    6fec:	29430843 	ldp	w3, w2, [x2, #24]
    6ff0:	92403c21 	and	x1, x1, #0xffff
    6ff4:	9b037c21 	mul	x1, x1, x3
    6ff8:	d360fc21 	lsr	x1, x1, #32
    6ffc:	eb02003f 	cmp	x1, x2
    7000:	54000182 	b.cs	7030 <f37+0xcc>  // b.hs, b.nlast
    7004:	8b010000 	add	x0, x0, x1
    7008:	39400001 	ldrb	w1, [x0]
    700c:	34000121 	cbz	w1, 7030 <f37+0xcc>
    7010:	b00000c2 	adrp	x2, 20000 <__data_start>
    7014:	91014042 	add	x2, x2, #0x50
    7018:	b9413043 	ldr	w3, [x2, #304]
    701c:	350014c3 	cbnz	w3, 72b4 <f37+0x350>
    7020:	7103f43f 	cmp	w1, #0xfd
    7024:	540018e8 	b.hi	7340 <f37+0x3dc>  // b.pmore
    7028:	11000421 	add	w1, w1, #0x1
    702c:	39000001 	strb	w1, [x0]
    7030:	d2800000 	mov	x0, #0x0                   	// #0
    7034:	b40000d8 	cbz	x24, 704c <f37+0xe8>
    7038:	aa1803e1 	mov	x1, x24
    703c:	d2800000 	mov	x0, #0x0                   	// #0
    7040:	f9400821 	ldr	x1, [x1, #16]
    7044:	91000400 	add	x0, x0, #0x1
    7048:	b5ffffc1 	cbnz	x1, 7040 <f37+0xdc>
    704c:	b4001439 	cbz	x25, 72d0 <f37+0x36c>
    7050:	aa1903e1 	mov	x1, x25
    7054:	d2800002 	mov	x2, #0x0                   	// #0
    7058:	f9400821 	ldr	x1, [x1, #16]
    705c:	91000442 	add	x2, x2, #0x1
    7060:	b5ffffc1 	cbnz	x1, 7058 <f37+0xf4>
    7064:	eb00005f 	cmp	x2, x0
    7068:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    706c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    7070:	eb01035f 	cmp	x26, x1
    7074:	540016e8 	b.hi	7350 <f37+0x3ec>  // b.pmore
    7078:	d37ffb53 	lsl	x19, x26, #1
    707c:	52800041 	mov	w1, #0x2                   	// #2
    7080:	91000660 	add	x0, x19, #0x1
    7084:	d37df000 	lsl	x0, x0, #3
    7088:	97fff822 	bl	5110 <fwp_heap_alloc>
    708c:	aa0003f7 	mov	x23, x0
    7090:	9118c2c1 	add	x1, x22, #0x630
    7094:	aa0103e0 	mov	x0, x1
    7098:	f90002f3 	str	x19, [x23]
    709c:	f949d821 	ldr	x1, [x1, #5040]
    70a0:	f949ec00 	ldr	x0, [x0, #5080]
    70a4:	cb0102e1 	sub	x1, x23, x1
    70a8:	eb00403f 	cmp	x1, x0, lsl #16
    70ac:	54000342 	b.cs	7114 <f37+0x1b0>  // b.hs, b.nlast
    70b0:	9118c2c2 	add	x2, x22, #0x630
    70b4:	d350fc20 	lsr	x0, x1, #16
    70b8:	8b000800 	add	x0, x0, x0, lsl #2
    70bc:	f949fc43 	ldr	x3, [x2, #5112]
    70c0:	d37df002 	lsl	x2, x0, #3
    70c4:	8b020060 	add	x0, x3, x2
    70c8:	f9401013 	ldr	x19, [x0, #32]
    70cc:	b4000253 	cbz	x19, 7114 <f37+0x1b0>
    70d0:	38626862 	ldrb	w2, [x3, x2]
    70d4:	7100085f 	cmp	w2, #0x2
    70d8:	54000e20 	b.eq	729c <f37+0x338>  // b.none
    70dc:	7100045f 	cmp	w2, #0x1
    70e0:	540001a1 	b.ne	7114 <f37+0x1b0>  // b.any
    70e4:	29430002 	ldp	w2, w0, [x0, #24]
    70e8:	92403c21 	and	x1, x1, #0xffff
    70ec:	9b027c21 	mul	x1, x1, x2
    70f0:	d360fc21 	lsr	x1, x1, #32
    70f4:	eb00003f 	cmp	x1, x0
    70f8:	540000e2 	b.cs	7114 <f37+0x1b0>  // b.hs, b.nlast
    70fc:	8b010273 	add	x19, x19, x1
    7100:	39400260 	ldrb	w0, [x19]
    7104:	7103fc1f 	cmp	w0, #0xff
    7108:	54001060 	b.eq	7314 <f37+0x3b0>  // b.none
    710c:	52800020 	mov	w0, #0x1                   	// #1
    7110:	39000260 	strb	w0, [x19]
    7114:	b400025a 	cbz	x26, 715c <f37+0x1f8>
    7118:	8b1a12fa 	add	x26, x23, x26, lsl #4
    711c:	aa1703f3 	mov	x19, x23
    7120:	aa1803f5 	mov	x21, x24
    7124:	aa1903f4 	mov	x20, x25
    7128:	f9400683 	ldr	x3, [x20, #8]
    712c:	f94006a2 	ldr	x2, [x21, #8]
    7130:	f9400861 	ldr	x1, [x3, #16]
    7134:	f9400840 	ldr	x0, [x2, #16]
    7138:	fd400461 	ldr	d1, [x3, #8]
    713c:	fd400440 	ldr	d0, [x2, #8]
    7140:	97fff965 	bl	56d4 <w120>
    7144:	f9000660 	str	x0, [x19, #8]
    7148:	f8010e61 	str	x1, [x19, #16]!
    714c:	f9400a94 	ldr	x20, [x20, #16]
    7150:	f9400ab5 	ldr	x21, [x21, #16]
    7154:	eb13035f 	cmp	x26, x19
    7158:	54fffe81 	b.ne	7128 <f37+0x1c4>  // b.any
    715c:	aa1903e0 	mov	x0, x25
    7160:	97fffcb0 	bl	6420 <fwp_drop4>
    7164:	aa1803e0 	mov	x0, x24
    7168:	97fffcae 	bl	6420 <fwp_drop4>
    716c:	f94002f5 	ldr	x21, [x23]
    7170:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7174:	b4000275 	cbz	x21, 71c0 <f37+0x25c>
    7178:	fd003be8 	str	d8, [sp, #112]
    717c:	2f00e408 	movi	d8, #0x0
    7180:	910022f9 	add	x25, x23, #0x8
    7184:	910042f8 	add	x24, x23, #0x10
    7188:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    718c:	d2800013 	mov	x19, #0x0                   	// #0
    7190:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7194:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    7198:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    719c:	aa0303e1 	mov	x1, x3
    71a0:	1e602908 	fadd	d8, d8, d0
    71a4:	91000a73 	add	x19, x19, #0x2
    71a8:	97fff89a 	bl	5410 <fwp_p_ad_push>
    71ac:	aa0003f4 	mov	x20, x0
    71b0:	eb1302bf 	cmp	x21, x19
    71b4:	54fffee8 	b.hi	7190 <f37+0x22c>  // b.pmore
    71b8:	9e660115 	fmov	x21, d8
    71bc:	fd403be8 	ldr	d8, [sp, #112]
    71c0:	9118c2d6 	add	x22, x22, #0x630
    71c4:	aa1703e0 	mov	x0, x23
    71c8:	97fffe32 	bl	6a90 <fwp_drop10>
    71cc:	a900d3f5 	stp	x21, x20, [sp, #8]
    71d0:	910023e1 	add	x1, sp, #0x8
    71d4:	52800000 	mov	w0, #0x0                   	// #0
    71d8:	97fff82f 	bl	5294 <fwp_data.part.0.constprop.0>
    71dc:	f949dac1 	ldr	x1, [x22, #5040]
    71e0:	aa0003f3 	mov	x19, x0
    71e4:	f949eec0 	ldr	x0, [x22, #5080]
    71e8:	cb010261 	sub	x1, x19, x1
    71ec:	eb00403f 	cmp	x1, x0, lsl #16
    71f0:	54000322 	b.cs	7254 <f37+0x2f0>  // b.hs, b.nlast
    71f4:	d350fc22 	lsr	x2, x1, #16
    71f8:	f949fec3 	ldr	x3, [x22, #5112]
    71fc:	8b020842 	add	x2, x2, x2, lsl #2
    7200:	d37df042 	lsl	x2, x2, #3
    7204:	8b020060 	add	x0, x3, x2
    7208:	f9401014 	ldr	x20, [x0, #32]
    720c:	b4000254 	cbz	x20, 7254 <f37+0x2f0>
    7210:	38626862 	ldrb	w2, [x3, x2]
    7214:	7100085f 	cmp	w2, #0x2
    7218:	540003c0 	b.eq	7290 <f37+0x32c>  // b.none
    721c:	7100045f 	cmp	w2, #0x1
    7220:	540001a1 	b.ne	7254 <f37+0x2f0>  // b.any
    7224:	29430002 	ldp	w2, w0, [x0, #24]
    7228:	92403c21 	and	x1, x1, #0xffff
    722c:	9b027c21 	mul	x1, x1, x2
    7230:	d360fc21 	lsr	x1, x1, #32
    7234:	eb00003f 	cmp	x1, x0
    7238:	540000e2 	b.cs	7254 <f37+0x2f0>  // b.hs, b.nlast
    723c:	8b010294 	add	x20, x20, x1
    7240:	39400280 	ldrb	w0, [x20]
    7244:	7103fc1f 	cmp	w0, #0xff
    7248:	54000600 	b.eq	7308 <f37+0x3a4>  // b.none
    724c:	52800020 	mov	w0, #0x1                   	// #1
    7250:	39000280 	strb	w0, [x20]
    7254:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7258:	f947f400 	ldr	x0, [x0, #4072]
    725c:	f9400fe2 	ldr	x2, [sp, #24]
    7260:	f9400001 	ldr	x1, [x0]
    7264:	eb010042 	subs	x2, x2, x1
    7268:	d2800001 	mov	x1, #0x0                   	// #0
    726c:	540007a1 	b.ne	7360 <f37+0x3fc>  // b.any
    7270:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7274:	aa1303e0 	mov	x0, x19
    7278:	a94353f3 	ldp	x19, x20, [sp, #48]
    727c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7280:	a94563f7 	ldp	x23, x24, [sp, #80]
    7284:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7288:	910203ff 	add	sp, sp, #0x80
    728c:	d65f03c0 	ret
    7290:	72003c3f 	tst	w1, #0xffff
    7294:	54fffe01 	b.ne	7254 <f37+0x2f0>  // b.any
    7298:	17ffffea 	b	7240 <f37+0x2dc>
    729c:	72003c3f 	tst	w1, #0xffff
    72a0:	54fff3a1 	b.ne	7114 <f37+0x1b0>  // b.any
    72a4:	17ffff97 	b	7100 <f37+0x19c>
    72a8:	72003c3f 	tst	w1, #0xffff
    72ac:	54ffec21 	b.ne	7030 <f37+0xcc>  // b.any
    72b0:	17ffff56 	b	7008 <f37+0xa4>
    72b4:	f940ac43 	ldr	x3, [x2, #344]
    72b8:	91000463 	add	x3, x3, #0x1
    72bc:	f900ac43 	str	x3, [x2, #344]
    72c0:	17ffff58 	b	7020 <f37+0xbc>
    72c4:	cb0103e1 	neg	x1, x1
    72c8:	eb02003f 	cmp	x1, x2
    72cc:	540002a3 	b.cc	7320 <f37+0x3bc>  // b.lo, b.ul, b.last
    72d0:	52800041 	mov	w1, #0x2                   	// #2
    72d4:	d2800100 	mov	x0, #0x8                   	// #8
    72d8:	97fff78e 	bl	5110 <fwp_heap_alloc>
    72dc:	aa0003f7 	mov	x23, x0
    72e0:	9118c2c0 	add	x0, x22, #0x630
    72e4:	f90002ff 	str	xzr, [x23]
    72e8:	f949d801 	ldr	x1, [x0, #5040]
    72ec:	f949ec00 	ldr	x0, [x0, #5080]
    72f0:	cb0102e1 	sub	x1, x23, x1
    72f4:	eb00403f 	cmp	x1, x0, lsl #16
    72f8:	54000282 	b.cs	7348 <f37+0x3e4>  // b.hs, b.nlast
    72fc:	d280001a 	mov	x26, #0x0                   	// #0
    7300:	d2800019 	mov	x25, #0x0                   	// #0
    7304:	17ffff6b 	b	70b0 <f37+0x14c>
    7308:	aa1403e0 	mov	x0, x20
    730c:	97fff5c1 	bl	4a10 <fwp_rc_forget_slot>
    7310:	17ffffcf 	b	724c <f37+0x2e8>
    7314:	aa1303e0 	mov	x0, x19
    7318:	97fff5be 	bl	4a10 <fwp_rc_forget_slot>
    731c:	17ffff7c 	b	710c <f37+0x1a8>
    7320:	f949fc62 	ldr	x2, [x3, #5112]
    7324:	d350fc20 	lsr	x0, x1, #16
    7328:	8b000800 	add	x0, x0, x0, lsl #2
    732c:	8b000c42 	add	x2, x2, x0, lsl #3
    7330:	f9401040 	ldr	x0, [x2, #32]
    7334:	b4fffce0 	cbz	x0, 72d0 <f37+0x36c>
    7338:	d2800019 	mov	x25, #0x0                   	// #0
    733c:	17ffff27 	b	6fd8 <f37+0x74>
    7340:	97fff56d 	bl	48f4 <fwp_rc_wide_dup>
    7344:	17ffff3b 	b	7030 <f37+0xcc>
    7348:	d2800019 	mov	x25, #0x0                   	// #0
    734c:	17ffff84 	b	715c <f37+0x1f8>
    7350:	d0000020 	adrp	x0, d000 <__modti3+0xf0>
    7354:	9122c000 	add	x0, x0, #0x8b0
    7358:	fd003be8 	str	d8, [sp, #112]
    735c:	97fff129 	bl	3800 <fwp_trap>
    7360:	fd003be8 	str	d8, [sp, #112]
    7364:	97ffed4f 	bl	28a0 <__stack_chk_fail@plt>
    7368:	d503201f 	nop
    736c:	d503201f 	nop

0000000000007370 <fwp_owned_entry37>:
    7370:	f9400000 	ldr	x0, [x0]
    7374:	17fffefc 	b	6f64 <f37>
    7378:	d503201f 	nop
    737c:	d503201f 	nop

0000000000007380 <e37>:
    7380:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7384:	910003fd 	mov	x29, sp
    7388:	f9000bf3 	str	x19, [sp, #16]
    738c:	f9400013 	ldr	x19, [x0]
    7390:	aa1303e0 	mov	x0, x19
    7394:	97fff913 	bl	57e0 <fwp_rc_share>
    7398:	aa1303e0 	mov	x0, x19
    739c:	97fffef2 	bl	6f64 <f37>
    73a0:	aa0003f3 	mov	x19, x0
    73a4:	97fff90f 	bl	57e0 <fwp_rc_share>
    73a8:	aa1303e0 	mov	x0, x19
    73ac:	f9400bf3 	ldr	x19, [sp, #16]
    73b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    73b4:	d65f03c0 	ret
    73b8:	d503201f 	nop
    73bc:	d503201f 	nop

00000000000073c0 <fwp_write>:
    73c0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    73c4:	910003fd 	mov	x29, sp
    73c8:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    73cc:	f947f484 	ldr	x4, [x4, #4072]
    73d0:	a90153f3 	stp	x19, x20, [sp, #16]
    73d4:	d10943ff 	sub	sp, sp, #0x250
    73d8:	b9400045 	ldr	w5, [x2]
    73dc:	aa0003f4 	mov	x20, x0
    73e0:	f9400080 	ldr	x0, [x4]
    73e4:	f90127e0 	str	x0, [sp, #584]
    73e8:	d2800000 	mov	x0, #0x0                   	// #0
    73ec:	710064bf 	cmp	w5, #0x19
    73f0:	54000408 	b.hi	7470 <fwp_write+0xb0>  // b.pmore
    73f4:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0xd50>
    73f8:	aa0103f3 	mov	x19, x1
    73fc:	91080000 	add	x0, x0, #0x200
    7400:	f9013bf5 	str	x21, [sp, #624]
    7404:	f9013ff6 	str	x22, [sp, #632]
    7408:	f90153fb 	str	x27, [sp, #672]
    740c:	f90157fc 	str	x28, [sp, #680]
    7410:	aa0203fc 	mov	x28, x2
    7414:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7418:	10000061 	adr	x1, 7424 <fwp_write+0x64>
    741c:	8b20a820 	add	x0, x1, w0, sxth #2
    7420:	d61f0000 	br	x0
    7424:	910123e0 	add	x0, sp, #0x48
    7428:	aa1303e5 	mov	x5, x19
    742c:	d0000024 	adrp	x4, d000 <__modti3+0xf0>
    7430:	aa0003f3 	mov	x19, x0
    7434:	9123e084 	add	x4, x4, #0x8f8
    7438:	d2804003 	mov	x3, #0x200                 	// #512
    743c:	aa0303e1 	mov	x1, x3
    7440:	52800042 	mov	w2, #0x2                   	// #2
    7444:	97ffecf3 	bl	2810 <__snprintf_chk@plt>
    7448:	aa1303e0 	mov	x0, x19
    744c:	97ffecb9 	bl	2730 <strlen@plt>
    7450:	aa1303e1 	mov	x1, x19
    7454:	aa0003e2 	mov	x2, x0
    7458:	aa1403e0 	mov	x0, x20
    745c:	97fff08d 	bl	3690 <buf_put>
    7460:	f9413bf5 	ldr	x21, [sp, #624]
    7464:	f9413ff6 	ldr	x22, [sp, #632]
    7468:	f94153fb 	ldr	x27, [sp, #672]
    746c:	f94157fc 	ldr	x28, [sp, #680]
    7470:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7474:	f947f400 	ldr	x0, [x0, #4072]
    7478:	f94127e2 	ldr	x2, [sp, #584]
    747c:	f9400001 	ldr	x1, [x0]
    7480:	eb010042 	subs	x2, x2, x1
    7484:	d2800001 	mov	x1, #0x0                   	// #0
    7488:	540077c1 	b.ne	8380 <fwp_write+0xfc0>  // b.any
    748c:	910943ff 	add	sp, sp, #0x250
    7490:	a94153f3 	ldp	x19, x20, [sp, #16]
    7494:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7498:	d65f03c0 	ret
    749c:	910123e0 	add	x0, sp, #0x48
    74a0:	aa1303e5 	mov	x5, x19
    74a4:	d0000024 	adrp	x4, d000 <__modti3+0xf0>
    74a8:	aa0003f3 	mov	x19, x0
    74ac:	9123c084 	add	x4, x4, #0x8f0
    74b0:	d2804003 	mov	x3, #0x200                 	// #512
    74b4:	17ffffe2 	b	743c <fwp_write+0x7c>
    74b8:	71004cbf 	cmp	w5, #0x13
    74bc:	d0000020 	adrp	x0, d000 <__modti3+0xf0>
    74c0:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    74c4:	91238000 	add	x0, x0, #0x8e0
    74c8:	9123a021 	add	x1, x1, #0x8e8
    74cc:	d2800082 	mov	x2, #0x4                   	// #4
    74d0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    74d4:	aa1403e0 	mov	x0, x20
    74d8:	f90143f7 	str	x23, [sp, #640]
    74dc:	d2800016 	mov	x22, #0x0                   	// #0
    74e0:	f90147f8 	str	x24, [sp, #648]
    74e4:	97fff06b 	bl	3690 <buf_put>
    74e8:	f9400260 	ldr	x0, [x19]
    74ec:	d0000037 	adrp	x23, d000 <__modti3+0xf0>
    74f0:	d2800015 	mov	x21, #0x0                   	// #0
    74f4:	9125a2f7 	add	x23, x23, #0x968
    74f8:	b40047a0 	cbz	x0, 7dec <fwp_write+0xa2c>
    74fc:	b9400380 	ldr	w0, [x28]
    7500:	52800003 	mov	w3, #0x0                   	// #0
    7504:	f9401f82 	ldr	x2, [x28, #56]
    7508:	71004c1f 	cmp	w0, #0x13
    750c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7510:	aa1403e0 	mov	x0, x20
    7514:	8b010e61 	add	x1, x19, x1, lsl #3
    7518:	f9400421 	ldr	x1, [x1, #8]
    751c:	97ffffa9 	bl	73c0 <fwp_write>
    7520:	b9400380 	ldr	w0, [x28]
    7524:	7100481f 	cmp	w0, #0x12
    7528:	54004b40 	b.eq	7e90 <fwp_write+0xad0>  // b.none
    752c:	f9400260 	ldr	x0, [x19]
    7530:	910006b5 	add	x21, x21, #0x1
    7534:	91000ad6 	add	x22, x22, #0x2
    7538:	eb15001f 	cmp	x0, x21
    753c:	54004589 	b.ls	7dec <fwp_write+0xa2c>  // b.plast
    7540:	aa1703e1 	mov	x1, x23
    7544:	aa1403e0 	mov	x0, x20
    7548:	d2800042 	mov	x2, #0x2                   	// #2
    754c:	97fff051 	bl	3690 <buf_put>
    7550:	17ffffeb 	b	74fc <fwp_write+0x13c>
    7554:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7558:	91248021 	add	x1, x1, #0x920
    755c:	d28000c2 	mov	x2, #0x6                   	// #6
    7560:	aa1403e0 	mov	x0, x20
    7564:	91004273 	add	x19, x19, #0x10
    7568:	97fff04a 	bl	3690 <buf_put>
    756c:	aa1303e0 	mov	x0, x19
    7570:	97ffec70 	bl	2730 <strlen@plt>
    7574:	aa1303e1 	mov	x1, x19
    7578:	aa0003e2 	mov	x2, x0
    757c:	aa1403e0 	mov	x0, x20
    7580:	97fff044 	bl	3690 <buf_put>
    7584:	528007c3 	mov	w3, #0x3e                  	// #62
    7588:	aa1403e0 	mov	x0, x20
    758c:	91001fe1 	add	x1, sp, #0x7
    7590:	d2800022 	mov	x2, #0x1                   	// #1
    7594:	39001fe3 	strb	w3, [sp, #7]
    7598:	17ffffb1 	b	745c <fwp_write+0x9c>
    759c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    75a0:	f947f400 	ldr	x0, [x0, #4072]
    75a4:	f94127e2 	ldr	x2, [sp, #584]
    75a8:	f9400001 	ldr	x1, [x0]
    75ac:	eb010042 	subs	x2, x2, x1
    75b0:	d2800001 	mov	x1, #0x0                   	// #0
    75b4:	540034e1 	b.ne	7c50 <fwp_write+0x890>  // b.any
    75b8:	f9413bf5 	ldr	x21, [sp, #624]
    75bc:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    75c0:	f9413ff6 	ldr	x22, [sp, #632]
    75c4:	aa1403e0 	mov	x0, x20
    75c8:	91240021 	add	x1, x1, #0x900
    75cc:	d2800142 	mov	x2, #0xa                   	// #10
    75d0:	f94153fb 	ldr	x27, [sp, #672]
    75d4:	f94157fc 	ldr	x28, [sp, #680]
    75d8:	910943ff 	add	sp, sp, #0x250
    75dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    75e0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    75e4:	17fff02b 	b	3690 <buf_put>
    75e8:	f9400456 	ldr	x22, [x2, #8]
    75ec:	f90143f7 	str	x23, [sp, #640]
    75f0:	f90147f8 	str	x24, [sp, #648]
    75f4:	b4005b16 	cbz	x22, 8154 <fwp_write+0xd94>
    75f8:	aa1603e0 	mov	x0, x22
    75fc:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7600:	91260021 	add	x1, x1, #0x980
    7604:	97ffecc7 	bl	2920 <strcmp@plt>
    7608:	2a0003f5 	mov	w21, w0
    760c:	34005fe0 	cbz	w0, 8208 <fwp_write+0xe48>
    7610:	aa1603e0 	mov	x0, x22
    7614:	97ffec47 	bl	2730 <strlen@plt>
    7618:	aa1603e1 	mov	x1, x22
    761c:	aa0003e2 	mov	x2, x0
    7620:	aa1403e0 	mov	x0, x20
    7624:	97fff01b 	bl	3690 <buf_put>
    7628:	52800403 	mov	w3, #0x20                  	// #32
    762c:	91001ff5 	add	x21, sp, #0x7
    7630:	aa1503e1 	mov	x1, x21
    7634:	aa1403e0 	mov	x0, x20
    7638:	d2800022 	mov	x2, #0x1                   	// #1
    763c:	39001fe3 	strb	w3, [sp, #7]
    7640:	97fff014 	bl	3690 <buf_put>
    7644:	52800f63 	mov	w3, #0x7b                  	// #123
    7648:	aa1403e0 	mov	x0, x20
    764c:	aa1503e1 	mov	x1, x21
    7650:	d2800022 	mov	x2, #0x1                   	// #1
    7654:	39001fe3 	strb	w3, [sp, #7]
    7658:	97fff00e 	bl	3690 <buf_put>
    765c:	b9401380 	ldr	w0, [x28, #16]
    7660:	52800018 	mov	w24, #0x0                   	// #0
    7664:	7100001f 	cmp	w0, #0x0
    7668:	54003aad 	b.le	7dbc <fwp_write+0x9fc>
    766c:	f9014bf9 	str	x25, [sp, #656]
    7670:	d0000039 	adrp	x25, d000 <__modti3+0xf0>
    7674:	9126a339 	add	x25, x25, #0x9a8
    7678:	f9014ffa 	str	x26, [sp, #664]
    767c:	d000003a 	adrp	x26, d000 <__modti3+0xf0>
    7680:	9125a35a 	add	x26, x26, #0x968
    7684:	91002276 	add	x22, x19, #0x8
    7688:	d2800013 	mov	x19, #0x0                   	// #0
    768c:	b5003e93 	cbnz	x19, 7e5c <fwp_write+0xa9c>
    7690:	d37df277 	lsl	x23, x19, #3
    7694:	34003cb8 	cbz	w24, 7e28 <fwp_write+0xa68>
    7698:	f9401382 	ldr	x2, [x28, #32]
    769c:	aa1403e0 	mov	x0, x20
    76a0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    76a4:	52800003 	mov	w3, #0x0                   	// #0
    76a8:	f8776842 	ldr	x2, [x2, x23]
    76ac:	91000673 	add	x19, x19, #0x1
    76b0:	97ffff44 	bl	73c0 <fwp_write>
    76b4:	b9401380 	ldr	w0, [x28, #16]
    76b8:	6b13001f 	cmp	w0, w19
    76bc:	54fffe8c 	b.gt	768c <fwp_write+0x2cc>
    76c0:	f9414bf9 	ldr	x25, [sp, #656]
    76c4:	f9414ffa 	ldr	x26, [sp, #664]
    76c8:	340037b8 	cbz	w24, 7dbc <fwp_write+0x9fc>
    76cc:	52800523 	mov	w3, #0x29                  	// #41
    76d0:	aa1503e1 	mov	x1, x21
    76d4:	aa1403e0 	mov	x0, x20
    76d8:	d2800022 	mov	x2, #0x1                   	// #1
    76dc:	39001fe3 	strb	w3, [sp, #7]
    76e0:	97ffefec 	bl	3690 <buf_put>
    76e4:	f9413bf5 	ldr	x21, [sp, #624]
    76e8:	f9413ff6 	ldr	x22, [sp, #632]
    76ec:	f94143f7 	ldr	x23, [sp, #640]
    76f0:	f94147f8 	ldr	x24, [sp, #648]
    76f4:	f94153fb 	ldr	x27, [sp, #672]
    76f8:	f94157fc 	ldr	x28, [sp, #680]
    76fc:	17ffff5d 	b	7470 <fwp_write+0xb0>
    7700:	b9404855 	ldr	w21, [x2, #72]
    7704:	aa1403e0 	mov	x0, x20
    7708:	93407eb6 	sxtw	x22, w21
    770c:	91000ac1 	add	x1, x22, #0x2
    7710:	97ffefac 	bl	35c0 <buf_grow>
    7714:	a9400281 	ldp	x1, x0, [x20]
    7718:	528e8603 	mov	w3, #0x7430                	// #29744
    771c:	78206823 	strh	w3, [x1, x0]
    7720:	8b000022 	add	x2, x1, x0
    7724:	710002bf 	cmp	w21, #0x0
    7728:	540036cd 	b.le	7e00 <fwp_write+0xa40>
    772c:	110006a3 	add	w3, w21, #0x1
    7730:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7734:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7738:	91000449 	add	x9, x2, #0x1
    773c:	8b23c043 	add	x3, x2, w3, sxtw
    7740:	f28aaac6 	movk	x6, #0x5556
    7744:	f2955568 	movk	x8, #0xaaab
    7748:	1400000d 	b	777c <fwp_write+0x3bc>
    774c:	d2800021 	mov	x1, #0x1                   	// #1
    7750:	528005a5 	mov	w5, #0x2d                  	// #45
    7754:	f100001f 	cmp	x0, #0x0
    7758:	9b467e60 	smulh	x0, x19, x6
    775c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7760:	381ff465 	strb	w5, [x3], #-1
    7764:	cb040000 	sub	x0, x0, x4
    7768:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    776c:	cb020000 	sub	x0, x0, x2
    7770:	8b010013 	add	x19, x0, x1
    7774:	eb03013f 	cmp	x9, x3
    7778:	54003440 	b.eq	7e00 <fwp_write+0xa40>  // b.none
    777c:	9b467e60 	smulh	x0, x19, x6
    7780:	937ffe64 	asr	x4, x19, #63
    7784:	52800605 	mov	w5, #0x30                  	// #48
    7788:	cb040000 	sub	x0, x0, x4
    778c:	8b000400 	add	x0, x0, x0, lsl #1
    7790:	cb000260 	sub	x0, x19, x0
    7794:	91000c01 	add	x1, x0, #0x3
    7798:	9bc87c22 	umulh	x2, x1, x8
    779c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    77a0:	8b4204e2 	add	x2, x7, x2, lsr #1
    77a4:	eb020021 	subs	x1, x1, x2
    77a8:	54fffd60 	b.eq	7754 <fwp_write+0x394>  // b.none
    77ac:	f100043f 	cmp	x1, #0x1
    77b0:	54fffce1 	b.ne	774c <fwp_write+0x38c>  // b.any
    77b4:	d2800001 	mov	x1, #0x0                   	// #0
    77b8:	52800565 	mov	w5, #0x2b                  	// #43
    77bc:	17ffffe6 	b	7754 <fwp_write+0x394>
    77c0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    77c4:	f947f400 	ldr	x0, [x0, #4072]
    77c8:	f94127e2 	ldr	x2, [sp, #584]
    77cc:	f9400001 	ldr	x1, [x0]
    77d0:	eb010042 	subs	x2, x2, x1
    77d4:	d2800001 	mov	x1, #0x0                   	// #0
    77d8:	540023c1 	b.ne	7c50 <fwp_write+0x890>  // b.any
    77dc:	f9413bf5 	ldr	x21, [sp, #624]
    77e0:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    77e4:	f9413ff6 	ldr	x22, [sp, #632]
    77e8:	aa1403e0 	mov	x0, x20
    77ec:	91244021 	add	x1, x1, #0x910
    77f0:	d2800102 	mov	x2, #0x8                   	// #8
    77f4:	17ffff77 	b	75d0 <fwp_write+0x210>
    77f8:	aa1403e0 	mov	x0, x20
    77fc:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7800:	d28000c2 	mov	x2, #0x6                   	// #6
    7804:	9125c021 	add	x1, x1, #0x970
    7808:	97ffefa2 	bl	3690 <buf_put>
    780c:	d2800015 	mov	x21, #0x0                   	// #0
    7810:	f9400263 	ldr	x3, [x19]
    7814:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7818:	54002c60 	b.eq	7da4 <fwp_write+0x9e4>  // b.none
    781c:	f9401f82 	ldr	x2, [x28, #56]
    7820:	f90143f7 	str	x23, [sp, #640]
    7824:	f90147f8 	str	x24, [sp, #648]
    7828:	d2800857 	mov	x23, #0x42                  	// #66
    782c:	f9014bf9 	str	x25, [sp, #656]
    7830:	d0000036 	adrp	x22, d000 <__modti3+0xf0>
    7834:	f9014ffa 	str	x26, [sp, #664]
    7838:	9125a2d6 	add	x22, x22, #0x968
    783c:	d2800038 	mov	x24, #0x1                   	// #1
    7840:	f2a18017 	movk	x23, #0xc00, lsl #16
    7844:	d2809099 	mov	x25, #0x484                 	// #1156
    7848:	b40004a2 	cbz	x2, 78dc <fwp_write+0x51c>
    784c:	b9400040 	ldr	w0, [x2]
    7850:	7100701f 	cmp	w0, #0x1c
    7854:	540042c0 	b.eq	80ac <fwp_write+0xcec>  // b.none
    7858:	71006c1f 	cmp	w0, #0x1b
    785c:	54000408 	b.hi	78dc <fwp_write+0x51c>  // b.pmore
    7860:	9ac02301 	lsl	x1, x24, x0
    7864:	ea17003f 	tst	x1, x23
    7868:	540036a1 	b.ne	7f3c <fwp_write+0xb7c>  // b.any
    786c:	ea19003f 	tst	x1, x25
    7870:	54003521 	b.ne	7f14 <fwp_write+0xb54>  // b.any
    7874:	d2800424 	mov	x4, #0x21                  	// #33
    7878:	ea04003f 	tst	x1, x4
    787c:	54000300 	b.eq	78dc <fwp_write+0x51c>  // b.none
    7880:	b7f849c3 	tbnz	x3, #63, 81b8 <fwp_write+0xdf8>
    7884:	91002261 	add	x1, x19, #0x8
    7888:	8b150021 	add	x1, x1, x21
    788c:	39400021 	ldrb	w1, [x1]
    7890:	7100001f 	cmp	w0, #0x0
    7894:	93401c23 	sxtb	x3, w1
    7898:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    789c:	d503201f 	nop
    78a0:	aa1403e0 	mov	x0, x20
    78a4:	52800003 	mov	w3, #0x0                   	// #0
    78a8:	97fffec6 	bl	73c0 <fwp_write>
    78ac:	910006b5 	add	x21, x21, #0x1
    78b0:	f9400260 	ldr	x0, [x19]
    78b4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    78b8:	eb0002bf 	cmp	x21, x0
    78bc:	540026c2 	b.cs	7d94 <fwp_write+0x9d4>  // b.hs, b.nlast
    78c0:	d2800042 	mov	x2, #0x2                   	// #2
    78c4:	aa1603e1 	mov	x1, x22
    78c8:	aa1403e0 	mov	x0, x20
    78cc:	97ffef71 	bl	3690 <buf_put>
    78d0:	f9401f82 	ldr	x2, [x28, #56]
    78d4:	f9400263 	ldr	x3, [x19]
    78d8:	b5fffba2 	cbnz	x2, 784c <fwp_write+0x48c>
    78dc:	d37df2a0 	lsl	x0, x21, #3
    78e0:	b7f83f03 	tbnz	x3, #63, 80c0 <fwp_write+0xd00>
    78e4:	91002261 	add	x1, x19, #0x8
    78e8:	8b000020 	add	x0, x1, x0
    78ec:	f9400001 	ldr	x1, [x0]
    78f0:	17ffffec 	b	78a0 <fwp_write+0x4e0>
    78f4:	a9400e62 	ldp	x2, x3, [x19]
    78f8:	b7f83ca3 	tbnz	x3, #63, 808c <fwp_write+0xccc>
    78fc:	910123f5 	add	x21, sp, #0x48
    7900:	aa1503e0 	mov	x0, x21
    7904:	97ffed47 	bl	2e20 <fwp_fmt_u128>
    7908:	aa1503e0 	mov	x0, x21
    790c:	97ffeb89 	bl	2730 <strlen@plt>
    7910:	aa1503e1 	mov	x1, x21
    7914:	aa0003e2 	mov	x2, x0
    7918:	17fffed0 	b	7458 <fwp_write+0x98>
    791c:	fd015be8 	str	d8, [sp, #688]
    7920:	1e270268 	fmov	s8, w19
    7924:	fd015fe9 	str	d9, [sp, #696]
    7928:	1e282100 	fcmp	s8, s8
    792c:	54004d26 	b.vs	82d0 <fwp_write+0xf10>
    7930:	1e20c101 	fabs	s1, s8
    7934:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7938:	1e270000 	fmov	s0, w0
    793c:	1e202020 	fcmp	s1, s0
    7940:	54002c0d 	b.le	7ec0 <fwp_write+0xb00>
    7944:	1e202118 	fcmpe	s8, #0.0
    7948:	d0000022 	adrp	x2, d000 <__modti3+0xf0>
    794c:	9110a042 	add	x2, x2, #0x428
    7950:	910123f5 	add	x21, sp, #0x48
    7954:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7958:	91230021 	add	x1, x1, #0x8c0
    795c:	aa1503e0 	mov	x0, x21
    7960:	9a81c041 	csel	x1, x2, x1, gt
    7964:	97ffec1f 	bl	29e0 <strcpy@plt>
    7968:	aa1503e0 	mov	x0, x21
    796c:	97ffeb71 	bl	2730 <strlen@plt>
    7970:	aa1503e1 	mov	x1, x21
    7974:	aa0003e2 	mov	x2, x0
    7978:	aa1403e0 	mov	x0, x20
    797c:	97ffef45 	bl	3690 <buf_put>
    7980:	f9413bf5 	ldr	x21, [sp, #624]
    7984:	f9413ff6 	ldr	x22, [sp, #632]
    7988:	f94153fb 	ldr	x27, [sp, #672]
    798c:	f94157fc 	ldr	x28, [sp, #680]
    7990:	fd415be8 	ldr	d8, [sp, #688]
    7994:	fd415fe9 	ldr	d9, [sp, #696]
    7998:	17fffeb6 	b	7470 <fwp_write+0xb0>
    799c:	f9400276 	ldr	x22, [x19]
    79a0:	34002e03 	cbz	w3, 7f60 <fwp_write+0xba0>
    79a4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    79a8:	f947f400 	ldr	x0, [x0, #4072]
    79ac:	f94127e2 	ldr	x2, [sp, #584]
    79b0:	f9400001 	ldr	x1, [x0]
    79b4:	eb010042 	subs	x2, x2, x1
    79b8:	d2800001 	mov	x1, #0x0                   	// #0
    79bc:	540014a1 	b.ne	7c50 <fwp_write+0x890>  // b.any
    79c0:	aa1603e2 	mov	x2, x22
    79c4:	91002261 	add	x1, x19, #0x8
    79c8:	f9413bf5 	ldr	x21, [sp, #624]
    79cc:	aa1403e0 	mov	x0, x20
    79d0:	f9413ff6 	ldr	x22, [sp, #632]
    79d4:	17fffeff 	b	75d0 <fwp_write+0x210>
    79d8:	fd015be8 	str	d8, [sp, #688]
    79dc:	9e670268 	fmov	d8, x19
    79e0:	fd015fe9 	str	d9, [sp, #696]
    79e4:	1e682100 	fcmp	d8, d8
    79e8:	54004746 	b.vs	82d0 <fwp_write+0xf10>
    79ec:	1e60c101 	fabs	d1, d8
    79f0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    79f4:	9e670000 	fmov	d0, x0
    79f8:	910123f5 	add	x21, sp, #0x48
    79fc:	52800033 	mov	w19, #0x1                   	// #1
    7a00:	1e602020 	fcmp	d1, d0
    7a04:	540001ad 	b.le	7a38 <fwp_write+0x678>
    7a08:	1e602118 	fcmpe	d8, #0.0
    7a0c:	d0000022 	adrp	x2, d000 <__modti3+0xf0>
    7a10:	9110a042 	add	x2, x2, #0x428
    7a14:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7a18:	91230021 	add	x1, x1, #0x8c0
    7a1c:	aa1503e0 	mov	x0, x21
    7a20:	9a81c041 	csel	x1, x2, x1, gt
    7a24:	97ffebef 	bl	29e0 <strcpy@plt>
    7a28:	17ffffd0 	b	7968 <fwp_write+0x5a8>
    7a2c:	11000673 	add	w19, w19, #0x1
    7a30:	71004a7f 	cmp	w19, #0x12
    7a34:	54003860 	b.eq	8140 <fwp_write+0xd80>  // b.none
    7a38:	1e604100 	fmov	d0, d8
    7a3c:	2a1303e1 	mov	w1, w19
    7a40:	aa1503e0 	mov	x0, x21
    7a44:	97fff054 	bl	3b94 <fwp_format_g.constprop.0>
    7a48:	aa1503e0 	mov	x0, x21
    7a4c:	d2800001 	mov	x1, #0x0                   	// #0
    7a50:	97ffeb4c 	bl	2780 <strtod@plt>
    7a54:	1e602100 	fcmp	d8, d0
    7a58:	54fffea1 	b.ne	7a2c <fwp_write+0x66c>  // b.any
    7a5c:	aa1503e0 	mov	x0, x21
    7a60:	97ffef45 	bl	3774 <fwp_finish_float>
    7a64:	17ffffc1 	b	7968 <fwp_write+0x5a8>
    7a68:	a9400e62 	ldp	x2, x3, [x19]
    7a6c:	910123f3 	add	x19, sp, #0x48
    7a70:	aa1303e0 	mov	x0, x19
    7a74:	97ffeceb 	bl	2e20 <fwp_fmt_u128>
    7a78:	17fffe74 	b	7448 <fwp_write+0x88>
    7a7c:	f90143f7 	str	x23, [sp, #640]
    7a80:	f90147f8 	str	x24, [sp, #648]
    7a84:	2a1303f8 	mov	w24, w19
    7a88:	f9014bf9 	str	x25, [sp, #656]
    7a8c:	f9014ffa 	str	x26, [sp, #664]
    7a90:	f13ffe7f 	cmp	x19, #0xfff
    7a94:	54000049 	b.ls	7a9c <fwp_write+0x6dc>  // b.plast
    7a98:	b9400278 	ldr	w24, [x19]
    7a9c:	f9400f80 	ldr	x0, [x28, #24]
    7aa0:	2a1803f5 	mov	w21, w24
    7aa4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7aa8:	d37ef6b9 	lsl	x25, x21, #2
    7aac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7ab0:	aa1603e0 	mov	x0, x22
    7ab4:	97ffeb1f 	bl	2730 <strlen@plt>
    7ab8:	aa1603e1 	mov	x1, x22
    7abc:	aa0003e2 	mov	x2, x0
    7ac0:	aa1403e0 	mov	x0, x20
    7ac4:	97ffeef3 	bl	3690 <buf_put>
    7ac8:	f9401780 	ldr	x0, [x28, #40]
    7acc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7ad0:	7100001f 	cmp	w0, #0x0
    7ad4:	5400068d 	b.le	7ba4 <fwp_write+0x7e4>
    7ad8:	91002276 	add	x22, x19, #0x8
    7adc:	91001ff5 	add	x21, sp, #0x7
    7ae0:	d280001b 	mov	x27, #0x0                   	// #0
    7ae4:	5280041a 	mov	w26, #0x20                  	// #32
    7ae8:	f9401b80 	ldr	x0, [x28, #48]
    7aec:	aa1503e1 	mov	x1, x21
    7af0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7af4:	d2800022 	mov	x2, #0x1                   	// #1
    7af8:	f8786803 	ldr	x3, [x0, x24]
    7afc:	aa1403e0 	mov	x0, x20
    7b00:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7b04:	39001ffa 	strb	w26, [sp, #7]
    7b08:	97ffeee2 	bl	3690 <buf_put>
    7b0c:	f13ffeff 	cmp	x23, #0xfff
    7b10:	b9400261 	ldr	w1, [x19]
    7b14:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7b18:	7100383f 	cmp	w1, #0xe
    7b1c:	54000160 	b.eq	7b48 <fwp_write+0x788>  // b.none
    7b20:	7100403f 	cmp	w1, #0x10
    7b24:	54001a60 	b.eq	7e70 <fwp_write+0xab0>  // b.none
    7b28:	7100283f 	cmp	w1, #0xa
    7b2c:	54002aa0 	b.eq	8080 <fwp_write+0xcc0>  // b.none
    7b30:	540014ac 	b.gt	7dc4 <fwp_write+0xa04>
    7b34:	71000c3f 	cmp	w1, #0x3
    7b38:	540029ac 	b.gt	806c <fwp_write+0xcac>
    7b3c:	d37ffee0 	lsr	x0, x23, #63
    7b40:	37f814a1 	tbnz	w1, #31, 7dd4 <fwp_write+0xa14>
    7b44:	d503201f 	nop
    7b48:	34001460 	cbz	w0, 7dd4 <fwp_write+0xa14>
    7b4c:	52800503 	mov	w3, #0x28                  	// #40
    7b50:	aa1503e1 	mov	x1, x21
    7b54:	aa1403e0 	mov	x0, x20
    7b58:	d2800022 	mov	x2, #0x1                   	// #1
    7b5c:	39001fe3 	strb	w3, [sp, #7]
    7b60:	97ffeecc 	bl	3690 <buf_put>
    7b64:	aa1303e2 	mov	x2, x19
    7b68:	aa1703e1 	mov	x1, x23
    7b6c:	aa1403e0 	mov	x0, x20
    7b70:	52800003 	mov	w3, #0x0                   	// #0
    7b74:	97fffe13 	bl	73c0 <fwp_write>
    7b78:	52800523 	mov	w3, #0x29                  	// #41
    7b7c:	aa1503e1 	mov	x1, x21
    7b80:	aa1403e0 	mov	x0, x20
    7b84:	d2800022 	mov	x2, #0x1                   	// #1
    7b88:	39001fe3 	strb	w3, [sp, #7]
    7b8c:	97ffeec1 	bl	3690 <buf_put>
    7b90:	f9401780 	ldr	x0, [x28, #40]
    7b94:	9100077b 	add	x27, x27, #0x1
    7b98:	b8796800 	ldr	w0, [x0, x25]
    7b9c:	6b1b001f 	cmp	w0, w27
    7ba0:	54fffa4c 	b.gt	7ae8 <fwp_write+0x728>
    7ba4:	f9413bf5 	ldr	x21, [sp, #624]
    7ba8:	f9413ff6 	ldr	x22, [sp, #632]
    7bac:	f94143f7 	ldr	x23, [sp, #640]
    7bb0:	f94147f8 	ldr	x24, [sp, #648]
    7bb4:	f9414bf9 	ldr	x25, [sp, #656]
    7bb8:	f9414ffa 	ldr	x26, [sp, #664]
    7bbc:	f94153fb 	ldr	x27, [sp, #672]
    7bc0:	f94157fc 	ldr	x28, [sp, #680]
    7bc4:	17fffe2b 	b	7470 <fwp_write+0xb0>
    7bc8:	52800783 	mov	w3, #0x3c                  	// #60
    7bcc:	91001ff3 	add	x19, sp, #0x7
    7bd0:	aa1303e1 	mov	x1, x19
    7bd4:	d2800022 	mov	x2, #0x1                   	// #1
    7bd8:	aa1403e0 	mov	x0, x20
    7bdc:	39001fe3 	strb	w3, [sp, #7]
    7be0:	97ffeeac 	bl	3690 <buf_put>
    7be4:	f9400795 	ldr	x21, [x28, #8]
    7be8:	aa1503e0 	mov	x0, x21
    7bec:	97ffead1 	bl	2730 <strlen@plt>
    7bf0:	aa1503e1 	mov	x1, x21
    7bf4:	aa0003e2 	mov	x2, x0
    7bf8:	aa1403e0 	mov	x0, x20
    7bfc:	97ffeea5 	bl	3690 <buf_put>
    7c00:	528007c3 	mov	w3, #0x3e                  	// #62
    7c04:	aa1303e1 	mov	x1, x19
    7c08:	aa1403e0 	mov	x0, x20
    7c0c:	d2800022 	mov	x2, #0x1                   	// #1
    7c10:	39001fe3 	strb	w3, [sp, #7]
    7c14:	17fffe12 	b	745c <fwp_write+0x9c>
    7c18:	f100067f 	cmp	x19, #0x1
    7c1c:	540025a0 	b.eq	80d0 <fwp_write+0xd10>  // b.none
    7c20:	b100067f 	cmn	x19, #0x1
    7c24:	54002bc0 	b.eq	819c <fwp_write+0xddc>  // b.none
    7c28:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7c2c:	91232021 	add	x1, x1, #0x8c8
    7c30:	d2800022 	mov	x2, #0x1                   	// #1
    7c34:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7c38:	f947f400 	ldr	x0, [x0, #4072]
    7c3c:	f94127e4 	ldr	x4, [sp, #584]
    7c40:	f9400003 	ldr	x3, [x0]
    7c44:	eb030084 	subs	x4, x4, x3
    7c48:	d2800003 	mov	x3, #0x0                   	// #0
    7c4c:	54ffebe0 	b.eq	79c8 <fwp_write+0x608>  // b.none
    7c50:	f90143f7 	str	x23, [sp, #640]
    7c54:	f90147f8 	str	x24, [sp, #648]
    7c58:	f9014bf9 	str	x25, [sp, #656]
    7c5c:	f9014ffa 	str	x26, [sp, #664]
    7c60:	fd015be8 	str	d8, [sp, #688]
    7c64:	fd015fe9 	str	d9, [sp, #696]
    7c68:	97ffeb0e 	bl	28a0 <__stack_chk_fail@plt>
    7c6c:	52800b63 	mov	w3, #0x5b                  	// #91
    7c70:	91001ff5 	add	x21, sp, #0x7
    7c74:	aa1503e1 	mov	x1, x21
    7c78:	aa1403e0 	mov	x0, x20
    7c7c:	d2800022 	mov	x2, #0x1                   	// #1
    7c80:	d0000036 	adrp	x22, d000 <__modti3+0xf0>
    7c84:	9125a2d6 	add	x22, x22, #0x968
    7c88:	39001fe3 	strb	w3, [sp, #7]
    7c8c:	97ffee81 	bl	3690 <buf_put>
    7c90:	b4000273 	cbz	x19, 7cdc <fwp_write+0x91c>
    7c94:	f9400661 	ldr	x1, [x19, #8]
    7c98:	aa1403e0 	mov	x0, x20
    7c9c:	f9401f82 	ldr	x2, [x28, #56]
    7ca0:	52800003 	mov	w3, #0x0                   	// #0
    7ca4:	97fffdc7 	bl	73c0 <fwp_write>
    7ca8:	f9400a73 	ldr	x19, [x19, #16]
    7cac:	b4000193 	cbz	x19, 7cdc <fwp_write+0x91c>
    7cb0:	aa1603e1 	mov	x1, x22
    7cb4:	aa1403e0 	mov	x0, x20
    7cb8:	d2800042 	mov	x2, #0x2                   	// #2
    7cbc:	97ffee75 	bl	3690 <buf_put>
    7cc0:	f9400661 	ldr	x1, [x19, #8]
    7cc4:	aa1403e0 	mov	x0, x20
    7cc8:	f9401f82 	ldr	x2, [x28, #56]
    7ccc:	52800003 	mov	w3, #0x0                   	// #0
    7cd0:	97fffdbc 	bl	73c0 <fwp_write>
    7cd4:	f9400a73 	ldr	x19, [x19, #16]
    7cd8:	b5fffed3 	cbnz	x19, 7cb0 <fwp_write+0x8f0>
    7cdc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ce0:	aa1503e1 	mov	x1, x21
    7ce4:	aa1403e0 	mov	x0, x20
    7ce8:	d2800022 	mov	x2, #0x1                   	// #1
    7cec:	39001fe3 	strb	w3, [sp, #7]
    7cf0:	17fffddb 	b	745c <fwp_write+0x9c>
    7cf4:	aa1403e0 	mov	x0, x20
    7cf8:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7cfc:	d28000c2 	mov	x2, #0x6                   	// #6
    7d00:	91256021 	add	x1, x1, #0x958
    7d04:	97ffee63 	bl	3690 <buf_put>
    7d08:	f9400260 	ldr	x0, [x19]
    7d0c:	b40004c0 	cbz	x0, 7da4 <fwp_write+0x9e4>
    7d10:	910123f5 	add	x21, sp, #0x48
    7d14:	91002276 	add	x22, x19, #0x8
    7d18:	f90143f7 	str	x23, [sp, #640]
    7d1c:	d2800017 	mov	x23, #0x0                   	// #0
    7d20:	f90147f8 	str	x24, [sp, #648]
    7d24:	d0000038 	adrp	x24, d000 <__modti3+0xf0>
    7d28:	91258318 	add	x24, x24, #0x960
    7d2c:	f9014bf9 	str	x25, [sp, #656]
    7d30:	d0000039 	adrp	x25, d000 <__modti3+0xf0>
    7d34:	9125a339 	add	x25, x25, #0x968
    7d38:	f9014ffa 	str	x26, [sp, #664]
    7d3c:	14000005 	b	7d50 <fwp_write+0x990>
    7d40:	aa1903e1 	mov	x1, x25
    7d44:	aa1403e0 	mov	x0, x20
    7d48:	d2800042 	mov	x2, #0x2                   	// #2
    7d4c:	97ffee51 	bl	3690 <buf_put>
    7d50:	38776ac5 	ldrb	w5, [x22, x23]
    7d54:	d2804003 	mov	x3, #0x200                 	// #512
    7d58:	aa1803e4 	mov	x4, x24
    7d5c:	aa0303e1 	mov	x1, x3
    7d60:	52800042 	mov	w2, #0x2                   	// #2
    7d64:	aa1503e0 	mov	x0, x21
    7d68:	910006f7 	add	x23, x23, #0x1
    7d6c:	97ffeaa9 	bl	2810 <__snprintf_chk@plt>
    7d70:	aa1503e0 	mov	x0, x21
    7d74:	97ffea6f 	bl	2730 <strlen@plt>
    7d78:	aa1503e1 	mov	x1, x21
    7d7c:	aa0003e2 	mov	x2, x0
    7d80:	aa1403e0 	mov	x0, x20
    7d84:	97ffee43 	bl	3690 <buf_put>
    7d88:	f9400260 	ldr	x0, [x19]
    7d8c:	eb17001f 	cmp	x0, x23
    7d90:	54fffd88 	b.hi	7d40 <fwp_write+0x980>  // b.pmore
    7d94:	f94143f7 	ldr	x23, [sp, #640]
    7d98:	f94147f8 	ldr	x24, [sp, #648]
    7d9c:	f9414bf9 	ldr	x25, [sp, #656]
    7da0:	f9414ffa 	ldr	x26, [sp, #664]
    7da4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7da8:	aa1403e0 	mov	x0, x20
    7dac:	91001fe1 	add	x1, sp, #0x7
    7db0:	d2800022 	mov	x2, #0x1                   	// #1
    7db4:	39001fe3 	strb	w3, [sp, #7]
    7db8:	17fffda9 	b	745c <fwp_write+0x9c>
    7dbc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7dc0:	17fffe44 	b	76d0 <fwp_write+0x310>
    7dc4:	f10002ff 	cmp	x23, #0x0
    7dc8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7dcc:	71002c3f 	cmp	w1, #0xb
    7dd0:	54ffebc0 	b.eq	7b48 <fwp_write+0x788>  // b.none
    7dd4:	aa1303e2 	mov	x2, x19
    7dd8:	aa1703e1 	mov	x1, x23
    7ddc:	aa1403e0 	mov	x0, x20
    7de0:	52800003 	mov	w3, #0x0                   	// #0
    7de4:	97fffd77 	bl	73c0 <fwp_write>
    7de8:	17ffff6a 	b	7b90 <fwp_write+0x7d0>
    7dec:	aa1403e0 	mov	x0, x20
    7df0:	91001fe1 	add	x1, sp, #0x7
    7df4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7df8:	d2800022 	mov	x2, #0x1                   	// #1
    7dfc:	17fffe38 	b	76dc <fwp_write+0x31c>
    7e00:	a9400281 	ldp	x1, x0, [x20]
    7e04:	91000800 	add	x0, x0, #0x2
    7e08:	8b160000 	add	x0, x0, x22
    7e0c:	f9000680 	str	x0, [x20, #8]
    7e10:	3820683f 	strb	wzr, [x1, x0]
    7e14:	f9413bf5 	ldr	x21, [sp, #624]
    7e18:	f9413ff6 	ldr	x22, [sp, #632]
    7e1c:	f94153fb 	ldr	x27, [sp, #672]
    7e20:	f94157fc 	ldr	x28, [sp, #680]
    7e24:	17fffd93 	b	7470 <fwp_write+0xb0>
    7e28:	f9400f80 	ldr	x0, [x28, #24]
    7e2c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7e30:	aa1b03e0 	mov	x0, x27
    7e34:	97ffea3f 	bl	2730 <strlen@plt>
    7e38:	aa1b03e1 	mov	x1, x27
    7e3c:	aa0003e2 	mov	x2, x0
    7e40:	aa1403e0 	mov	x0, x20
    7e44:	97ffee13 	bl	3690 <buf_put>
    7e48:	aa1903e1 	mov	x1, x25
    7e4c:	aa1403e0 	mov	x0, x20
    7e50:	d2800062 	mov	x2, #0x3                   	// #3
    7e54:	97ffee0f 	bl	3690 <buf_put>
    7e58:	17fffe10 	b	7698 <fwp_write+0x2d8>
    7e5c:	aa1a03e1 	mov	x1, x26
    7e60:	aa1403e0 	mov	x0, x20
    7e64:	d2800042 	mov	x2, #0x2                   	// #2
    7e68:	97ffee0a 	bl	3690 <buf_put>
    7e6c:	17fffe09 	b	7690 <fwp_write+0x2d0>
    7e70:	f9400660 	ldr	x0, [x19, #8]
    7e74:	b4fffb00 	cbz	x0, 7dd4 <fwp_write+0xa14>
    7e78:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7e7c:	91260021 	add	x1, x1, #0x980
    7e80:	97ffeaa8 	bl	2920 <strcmp@plt>
    7e84:	7100001f 	cmp	w0, #0x0
    7e88:	1a9f07e0 	cset	w0, ne	// ne = any
    7e8c:	17ffff2f 	b	7b48 <fwp_write+0x788>
    7e90:	aa1403e0 	mov	x0, x20
    7e94:	d2800042 	mov	x2, #0x2                   	// #2
    7e98:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7e9c:	9125e021 	add	x1, x1, #0x978
    7ea0:	97ffedfc 	bl	3690 <buf_put>
    7ea4:	91004261 	add	x1, x19, #0x10
    7ea8:	aa1403e0 	mov	x0, x20
    7eac:	f9402382 	ldr	x2, [x28, #64]
    7eb0:	52800003 	mov	w3, #0x0                   	// #0
    7eb4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7eb8:	97fffd42 	bl	73c0 <fwp_write>
    7ebc:	17fffd9c 	b	752c <fwp_write+0x16c>
    7ec0:	1e22c109 	fcvt	d9, s8
    7ec4:	910123f5 	add	x21, sp, #0x48
    7ec8:	52800033 	mov	w19, #0x1                   	// #1
    7ecc:	d503201f 	nop
    7ed0:	1e604120 	fmov	d0, d9
    7ed4:	2a1303e1 	mov	w1, w19
    7ed8:	aa1503e0 	mov	x0, x21
    7edc:	97ffef2e 	bl	3b94 <fwp_format_g.constprop.0>
    7ee0:	aa1503e0 	mov	x0, x21
    7ee4:	d2800001 	mov	x1, #0x0                   	// #0
    7ee8:	97ffea9a 	bl	2950 <strtof@plt>
    7eec:	1e202100 	fcmp	s8, s0
    7ef0:	54ffdb60 	b.eq	7a5c <fwp_write+0x69c>  // b.none
    7ef4:	11000673 	add	w19, w19, #0x1
    7ef8:	71002a7f 	cmp	w19, #0xa
    7efc:	54fffea1 	b.ne	7ed0 <fwp_write+0xb10>  // b.any
    7f00:	1e604120 	fmov	d0, d9
    7f04:	aa1503e0 	mov	x0, x21
    7f08:	52800121 	mov	w1, #0x9                   	// #9
    7f0c:	97ffef22 	bl	3b94 <fwp_format_g.constprop.0>
    7f10:	17fffed3 	b	7a5c <fwp_write+0x69c>
    7f14:	d37ef6a1 	lsl	x1, x21, #2
    7f18:	b7f81563 	tbnz	x3, #63, 81c4 <fwp_write+0xe04>
    7f1c:	91002263 	add	x3, x19, #0x8
    7f20:	8b010061 	add	x1, x3, x1
    7f24:	b9400023 	ldr	w3, [x1]
    7f28:	7100081f 	cmp	w0, #0x2
    7f2c:	2a0303e1 	mov	w1, w3
    7f30:	93407c63 	sxtw	x3, w3
    7f34:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7f38:	17fffe5a 	b	78a0 <fwp_write+0x4e0>
    7f3c:	d37ffaa1 	lsl	x1, x21, #1
    7f40:	b7f81363 	tbnz	x3, #63, 81ac <fwp_write+0xdec>
    7f44:	91002263 	add	x3, x19, #0x8
    7f48:	8b010061 	add	x1, x3, x1
    7f4c:	79400021 	ldrh	w1, [x1]
    7f50:	7100041f 	cmp	w0, #0x1
    7f54:	93403c23 	sxth	x3, w1
    7f58:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7f5c:	17fffe51 	b	78a0 <fwp_write+0x4e0>
    7f60:	52800443 	mov	w3, #0x22                  	// #34
    7f64:	91001ff5 	add	x21, sp, #0x7
    7f68:	91002273 	add	x19, x19, #0x8
    7f6c:	aa1503e1 	mov	x1, x21
    7f70:	aa1403e0 	mov	x0, x20
    7f74:	d2800022 	mov	x2, #0x1                   	// #1
    7f78:	39001fe3 	strb	w3, [sp, #7]
    7f7c:	f90143f7 	str	x23, [sp, #640]
    7f80:	8b160277 	add	x23, x19, x22
    7f84:	f90147f8 	str	x24, [sp, #648]
    7f88:	97ffedc2 	bl	3690 <buf_put>
    7f8c:	b4000696 	cbz	x22, 805c <fwp_write+0xc9c>
    7f90:	d0000038 	adrp	x24, d000 <__modti3+0xf0>
    7f94:	9124a318 	add	x24, x24, #0x928
    7f98:	f9014bf9 	str	x25, [sp, #656]
    7f9c:	d0000039 	adrp	x25, d000 <__modti3+0xf0>
    7fa0:	91252339 	add	x25, x25, #0x948
    7fa4:	f9014ffa 	str	x26, [sp, #664]
    7fa8:	1400000d 	b	7fdc <fwp_write+0xc1c>
    7fac:	710024bf 	cmp	w5, #0x9
    7fb0:	54000460 	b.eq	803c <fwp_write+0xc7c>  // b.none
    7fb4:	710028bf 	cmp	w5, #0xa
    7fb8:	54000a61 	b.ne	8104 <fwp_write+0xd44>  // b.any
    7fbc:	d0000021 	adrp	x1, d000 <__modti3+0xf0>
    7fc0:	aa1403e0 	mov	x0, x20
    7fc4:	9124e021 	add	x1, x1, #0x938
    7fc8:	d2800042 	mov	x2, #0x2                   	// #2
    7fcc:	97ffedb1 	bl	3690 <buf_put>
    7fd0:	91000673 	add	x19, x19, #0x1
    7fd4:	eb17027f 	cmp	x19, x23
    7fd8:	540003e0 	b.eq	8054 <fwp_write+0xc94>  // b.none
    7fdc:	39400265 	ldrb	w5, [x19]
    7fe0:	710034bf 	cmp	w5, #0xd
    7fe4:	54000180 	b.eq	8014 <fwp_write+0xc54>  // b.none
    7fe8:	54fffe29 	b.ls	7fac <fwp_write+0xbec>  // b.plast
    7fec:	710088bf 	cmp	w5, #0x22
    7ff0:	540001c0 	b.eq	8028 <fwp_write+0xc68>  // b.none
    7ff4:	710170bf 	cmp	w5, #0x5c
    7ff8:	54000741 	b.ne	80e0 <fwp_write+0xd20>  // b.any
    7ffc:	aa1403e0 	mov	x0, x20
    8000:	b0000021 	adrp	x1, d000 <__modti3+0xf0>
    8004:	d2800042 	mov	x2, #0x2                   	// #2
    8008:	9124c021 	add	x1, x1, #0x930
    800c:	97ffeda1 	bl	3690 <buf_put>
    8010:	17fffff0 	b	7fd0 <fwp_write+0xc10>
    8014:	aa1903e1 	mov	x1, x25
    8018:	aa1403e0 	mov	x0, x20
    801c:	d2800042 	mov	x2, #0x2                   	// #2
    8020:	97ffed9c 	bl	3690 <buf_put>
    8024:	17ffffeb 	b	7fd0 <fwp_write+0xc10>
    8028:	aa1803e1 	mov	x1, x24
    802c:	aa1403e0 	mov	x0, x20
    8030:	d2800042 	mov	x2, #0x2                   	// #2
    8034:	97ffed97 	bl	3690 <buf_put>
    8038:	17ffffe6 	b	7fd0 <fwp_write+0xc10>
    803c:	aa1403e0 	mov	x0, x20
    8040:	b0000021 	adrp	x1, d000 <__modti3+0xf0>
    8044:	d2800042 	mov	x2, #0x2                   	// #2
    8048:	91250021 	add	x1, x1, #0x940
    804c:	97ffed91 	bl	3690 <buf_put>
    8050:	17ffffe0 	b	7fd0 <fwp_write+0xc10>
    8054:	f9414bf9 	ldr	x25, [sp, #656]
    8058:	f9414ffa 	ldr	x26, [sp, #664]
    805c:	aa1503e1 	mov	x1, x21
    8060:	aa1403e0 	mov	x0, x20
    8064:	52800443 	mov	w3, #0x22                  	// #34
    8068:	17fffd9c 	b	76d8 <fwp_write+0x318>
    806c:	7100103f 	cmp	w1, #0x4
    8070:	54ffeb21 	b.ne	7dd4 <fwp_write+0xa14>  // b.any
    8074:	f94006e0 	ldr	x0, [x23, #8]
    8078:	d37ffc00 	lsr	x0, x0, #63
    807c:	17fffeb3 	b	7b48 <fwp_write+0x788>
    8080:	710002ff 	cmp	w23, #0x0
    8084:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8088:	17fffeb0 	b	7b48 <fwp_write+0x788>
    808c:	528005a1 	mov	w1, #0x2d                  	// #45
    8090:	eb0203e2 	negs	x2, x2
    8094:	da0303e3 	ngc	x3, x3
    8098:	910127e0 	add	x0, sp, #0x49
    809c:	910123f5 	add	x21, sp, #0x48
    80a0:	390123e1 	strb	w1, [sp, #72]
    80a4:	97ffeb5f 	bl	2e20 <fwp_fmt_u128>
    80a8:	17fffe18 	b	7908 <fwp_write+0x548>
    80ac:	d37ceea1 	lsl	x1, x21, #4
    80b0:	b7f810a3 	tbnz	x3, #63, 82c4 <fwp_write+0xf04>
    80b4:	91002260 	add	x0, x19, #0x8
    80b8:	8b010001 	add	x1, x0, x1
    80bc:	17fffdf9 	b	78a0 <fwp_write+0x4e0>
    80c0:	f9400a61 	ldr	x1, [x19, #16]
    80c4:	8b010000 	add	x0, x0, x1
    80c8:	f9400001 	ldr	x1, [x0]
    80cc:	17fffdf5 	b	78a0 <fwp_write+0x4e0>
    80d0:	b0000021 	adrp	x1, d000 <__modti3+0xf0>
    80d4:	d2800042 	mov	x2, #0x2                   	// #2
    80d8:	91234021 	add	x1, x1, #0x8d0
    80dc:	17fffed6 	b	7c34 <fwp_write+0x874>
    80e0:	7101fcbf 	cmp	w5, #0x7f
    80e4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    80e8:	540000e9 	b.ls	8104 <fwp_write+0xd44>  // b.plast
    80ec:	aa1503e1 	mov	x1, x21
    80f0:	aa1403e0 	mov	x0, x20
    80f4:	d2800022 	mov	x2, #0x1                   	// #1
    80f8:	39001fe5 	strb	w5, [sp, #7]
    80fc:	97ffed65 	bl	3690 <buf_put>
    8100:	17ffffb4 	b	7fd0 <fwp_write+0xc10>
    8104:	d2800203 	mov	x3, #0x10                  	// #16
    8108:	b0000024 	adrp	x4, d000 <__modti3+0xf0>
    810c:	aa0303e1 	mov	x1, x3
    8110:	91254084 	add	x4, x4, #0x950
    8114:	910123f6 	add	x22, sp, #0x48
    8118:	52800042 	mov	w2, #0x2                   	// #2
    811c:	aa1603e0 	mov	x0, x22
    8120:	97ffe9bc 	bl	2810 <__snprintf_chk@plt>
    8124:	aa1603e0 	mov	x0, x22
    8128:	97ffe982 	bl	2730 <strlen@plt>
    812c:	aa1603e1 	mov	x1, x22
    8130:	aa0003e2 	mov	x2, x0
    8134:	aa1403e0 	mov	x0, x20
    8138:	97ffed56 	bl	3690 <buf_put>
    813c:	17ffffa5 	b	7fd0 <fwp_write+0xc10>
    8140:	1e604100 	fmov	d0, d8
    8144:	aa1503e0 	mov	x0, x21
    8148:	52800221 	mov	w1, #0x11                  	// #17
    814c:	97ffee92 	bl	3b94 <fwp_format_g.constprop.0>
    8150:	17fffe43 	b	7a5c <fwp_write+0x69c>
    8154:	b9401040 	ldr	w0, [x2, #16]
    8158:	350003c0 	cbnz	w0, 81d0 <fwp_write+0xe10>
    815c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8160:	f947f400 	ldr	x0, [x0, #4072]
    8164:	f94127e2 	ldr	x2, [sp, #584]
    8168:	f9400001 	ldr	x1, [x0]
    816c:	eb010042 	subs	x2, x2, x1
    8170:	d2800001 	mov	x1, #0x0                   	// #0
    8174:	54ffd721 	b.ne	7c58 <fwp_write+0x898>  // b.any
    8178:	f9413bf5 	ldr	x21, [sp, #624]
    817c:	b0000021 	adrp	x1, d000 <__modti3+0xf0>
    8180:	f9413ff6 	ldr	x22, [sp, #632]
    8184:	aa1403e0 	mov	x0, x20
    8188:	f94143f7 	ldr	x23, [sp, #640]
    818c:	91268021 	add	x1, x1, #0x9a0
    8190:	f94147f8 	ldr	x24, [sp, #648]
    8194:	d2800042 	mov	x2, #0x2                   	// #2
    8198:	17fffd0e 	b	75d0 <fwp_write+0x210>
    819c:	b0000021 	adrp	x1, d000 <__modti3+0xf0>
    81a0:	d2800042 	mov	x2, #0x2                   	// #2
    81a4:	91236021 	add	x1, x1, #0x8d8
    81a8:	17fffea3 	b	7c34 <fwp_write+0x874>
    81ac:	f9400a63 	ldr	x3, [x19, #16]
    81b0:	8b030021 	add	x1, x1, x3
    81b4:	17ffff66 	b	7f4c <fwp_write+0xb8c>
    81b8:	f9400a61 	ldr	x1, [x19, #16]
    81bc:	8b0102a1 	add	x1, x21, x1
    81c0:	17fffdb3 	b	788c <fwp_write+0x4cc>
    81c4:	f9400a63 	ldr	x3, [x19, #16]
    81c8:	8b030021 	add	x1, x1, x3
    81cc:	17ffff56 	b	7f24 <fwp_write+0xb64>
    81d0:	b9404840 	ldr	w0, [x2, #72]
    81d4:	91001ff5 	add	x21, sp, #0x7
    81d8:	34ffa360 	cbz	w0, 7644 <fwp_write+0x284>
    81dc:	52800503 	mov	w3, #0x28                  	// #40
    81e0:	aa1403e0 	mov	x0, x20
    81e4:	aa1503e1 	mov	x1, x21
    81e8:	d2800022 	mov	x2, #0x1                   	// #1
    81ec:	39001fe3 	strb	w3, [sp, #7]
    81f0:	97ffed28 	bl	3690 <buf_put>
    81f4:	b9401380 	ldr	w0, [x28, #16]
    81f8:	52800038 	mov	w24, #0x1                   	// #1
    81fc:	7100001f 	cmp	w0, #0x0
    8200:	54ffa36c 	b.gt	766c <fwp_write+0x2ac>
    8204:	17fffd32 	b	76cc <fwp_write+0x30c>
    8208:	f9014bf9 	str	x25, [sp, #656]
    820c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe9b0>
    8210:	f9014ffa 	str	x26, [sp, #664]
    8214:	f9400676 	ldr	x22, [x19, #8]
    8218:	910ac333 	add	x19, x25, #0x2b0
    821c:	91002273 	add	x19, x19, #0x8
    8220:	937ffed8 	asr	x24, x22, #63
    8224:	aa1802c0 	orr	x0, x22, x24
    8228:	b5000320 	cbnz	x0, 828c <fwp_write+0xecc>
    822c:	110006b5 	add	w21, w21, #0x1
    8230:	710016bf 	cmp	w21, #0x5
    8234:	54ffffc1 	b.ne	822c <fwp_write+0xe6c>  // b.any
    8238:	b7f80578 	tbnz	x24, #63, 82e4 <fwp_write+0xf24>
    823c:	910023f3 	add	x19, sp, #0x8
    8240:	aa1603e2 	mov	x2, x22
    8244:	aa1303e0 	mov	x0, x19
    8248:	d2800003 	mov	x3, #0x0                   	// #0
    824c:	97ffeaf5 	bl	2e20 <fwp_fmt_u128>
    8250:	910123f5 	add	x21, sp, #0x48
    8254:	b0000023 	adrp	x3, d000 <__modti3+0xf0>
    8258:	aa1303e4 	mov	x4, x19
    825c:	aa1503e0 	mov	x0, x21
    8260:	91266063 	add	x3, x3, #0x998
    8264:	d2804002 	mov	x2, #0x200                 	// #512
    8268:	52800041 	mov	w1, #0x2                   	// #2
    826c:	97ffe935 	bl	2740 <__sprintf_chk@plt>
    8270:	aa1503e0 	mov	x0, x21
    8274:	97ffe92f 	bl	2730 <strlen@plt>
    8278:	aa1503e1 	mov	x1, x21
    827c:	aa0003e2 	mov	x2, x0
    8280:	aa1403e0 	mov	x0, x20
    8284:	97ffed03 	bl	3690 <buf_put>
    8288:	17fffe47 	b	7ba4 <fwp_write+0x7e4>
    828c:	f9400277 	ldr	x23, [x19]
    8290:	aa1603e0 	mov	x0, x22
    8294:	aa1803e1 	mov	x1, x24
    8298:	aa1703e2 	mov	x2, x23
    829c:	937ffefa 	asr	x26, x23, #63
    82a0:	aa1a03e3 	mov	x3, x26
    82a4:	9400131b 	bl	cf10 <__modti3>
    82a8:	aa010000 	orr	x0, x0, x1
    82ac:	b40002c0 	cbz	x0, 8304 <fwp_write+0xf44>
    82b0:	110006b5 	add	w21, w21, #0x1
    82b4:	91004273 	add	x19, x19, #0x10
    82b8:	710016bf 	cmp	w21, #0x5
    82bc:	54fffe81 	b.ne	828c <fwp_write+0xecc>  // b.any
    82c0:	17ffffde 	b	8238 <fwp_write+0xe78>
    82c4:	f9400a60 	ldr	x0, [x19, #16]
    82c8:	8b000021 	add	x1, x1, x0
    82cc:	17fffd75 	b	78a0 <fwp_write+0x4e0>
    82d0:	528c29c0 	mov	w0, #0x614e                	// #24910
    82d4:	910123f5 	add	x21, sp, #0x48
    82d8:	72a009c0 	movk	w0, #0x4e, lsl #16
    82dc:	b9004be0 	str	w0, [sp, #72]
    82e0:	17fffda2 	b	7968 <fwp_write+0x5a8>
    82e4:	528005a1 	mov	w1, #0x2d                  	// #45
    82e8:	eb1603e2 	negs	x2, x22
    82ec:	da1803e3 	ngc	x3, x24
    82f0:	910027e0 	add	x0, sp, #0x9
    82f4:	910023f3 	add	x19, sp, #0x8
    82f8:	390023e1 	strb	w1, [sp, #8]
    82fc:	97ffeac9 	bl	2e20 <fwp_fmt_u128>
    8300:	17ffffd4 	b	8250 <fwp_write+0xe90>
    8304:	aa1703e2 	mov	x2, x23
    8308:	aa1a03e3 	mov	x3, x26
    830c:	aa1603e0 	mov	x0, x22
    8310:	aa1803e1 	mov	x1, x24
    8314:	9400121f 	bl	cb90 <__divti3>
    8318:	aa0003e2 	mov	x2, x0
    831c:	aa0103e3 	mov	x3, x1
    8320:	b7f80201 	tbnz	x1, #63, 8360 <fwp_write+0xfa0>
    8324:	910023f3 	add	x19, sp, #0x8
    8328:	aa1303e0 	mov	x0, x19
    832c:	97ffeabd 	bl	2e20 <fwp_fmt_u128>
    8330:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8334:	910ac339 	add	x25, x25, #0x2b0
    8338:	910123f5 	add	x21, sp, #0x48
    833c:	aa1303e4 	mov	x4, x19
    8340:	aa1503e0 	mov	x0, x21
    8344:	b0000023 	adrp	x3, d000 <__modti3+0xf0>
    8348:	f8616b25 	ldr	x5, [x25, x1]
    834c:	91264063 	add	x3, x3, #0x990
    8350:	d2804002 	mov	x2, #0x200                 	// #512
    8354:	52800041 	mov	w1, #0x2                   	// #2
    8358:	97ffe8fa 	bl	2740 <__sprintf_chk@plt>
    835c:	17ffffc5 	b	8270 <fwp_write+0xeb0>
    8360:	528005a4 	mov	w4, #0x2d                  	// #45
    8364:	eb0003e2 	negs	x2, x0
    8368:	da0103e3 	ngc	x3, x1
    836c:	910027e0 	add	x0, sp, #0x9
    8370:	910023f3 	add	x19, sp, #0x8
    8374:	390023e4 	strb	w4, [sp, #8]
    8378:	97ffeaaa 	bl	2e20 <fwp_fmt_u128>
    837c:	17ffffed 	b	8330 <fwp_write+0xf70>
    8380:	f9013bf5 	str	x21, [sp, #624]
    8384:	f9013ff6 	str	x22, [sp, #632]
    8388:	f90143f7 	str	x23, [sp, #640]
    838c:	f90147f8 	str	x24, [sp, #648]
    8390:	f9014bf9 	str	x25, [sp, #656]
    8394:	f9014ffa 	str	x26, [sp, #664]
    8398:	f90153fb 	str	x27, [sp, #672]
    839c:	f90157fc 	str	x28, [sp, #680]
    83a0:	fd015be8 	str	d8, [sp, #688]
    83a4:	fd015fe9 	str	d9, [sp, #696]
    83a8:	97ffe93e 	bl	28a0 <__stack_chk_fail@plt>
    83ac:	d503201f 	nop

00000000000083b0 <fwp_hof0.constprop.0>:
    83b0:	d10543ff 	sub	sp, sp, #0x150
    83b4:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    83b8:	f947f442 	ldr	x2, [x2, #4072]
    83bc:	a90e7bfd 	stp	x29, x30, [sp, #224]
    83c0:	910383fd 	add	x29, sp, #0xe0
    83c4:	f90023e0 	str	x0, [sp, #64]
    83c8:	f9400040 	ldr	x0, [x2]
    83cc:	f9006fe0 	str	x0, [sp, #216]
    83d0:	d2800000 	mov	x0, #0x0                   	// #0
    83d4:	f90027e1 	str	x1, [sp, #72]
    83d8:	b400a701 	cbz	x1, 98b8 <fwp_hof0.constprop.0+0x1508>
    83dc:	900000c0 	adrp	x0, 20000 <__data_start>
    83e0:	91004000 	add	x0, x0, #0x10
    83e4:	91008000 	add	x0, x0, #0x20
    83e8:	f90017e0 	str	x0, [sp, #40]
    83ec:	910163e0 	add	x0, sp, #0x58
    83f0:	f9000fe0 	str	x0, [sp, #24]
    83f4:	910183e0 	add	x0, sp, #0x60
    83f8:	f90013e0 	str	x0, [sp, #32]
    83fc:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0xd50>
    8400:	fd00a3e8 	str	d8, [sp, #320]
    8404:	a90f53f3 	stp	x19, x20, [sp, #240]
    8408:	b0000394 	adrp	x20, 79000 <fwp_root_context+0xbb0>
    840c:	fd415008 	ldr	d8, [x0, #672]
    8410:	a9105bf5 	stp	x21, x22, [sp, #256]
    8414:	a91163f7 	stp	x23, x24, [sp, #272]
    8418:	a9126bf9 	stp	x25, x26, [sp, #288]
    841c:	a91373fb 	stp	x27, x28, [sp, #304]
    8420:	9118c282 	add	x2, x20, #0x630
    8424:	f94023e0 	ldr	x0, [sp, #64]
    8428:	f949ec43 	ldr	x3, [x2, #5080]
    842c:	f949d841 	ldr	x1, [x2, #5040]
    8430:	d370bc63 	lsl	x3, x3, #16
    8434:	cb010004 	sub	x4, x0, x1
    8438:	eb03009f 	cmp	x4, x3
    843c:	540004c2 	b.cs	84d4 <fwp_hof0.constprop.0+0x124>  // b.hs, b.nlast
    8440:	d350fc80 	lsr	x0, x4, #16
    8444:	f949fc46 	ldr	x6, [x2, #5112]
    8448:	8b000800 	add	x0, x0, x0, lsl #2
    844c:	d37df002 	lsl	x2, x0, #3
    8450:	8b0200c5 	add	x5, x6, x2
    8454:	f94010a0 	ldr	x0, [x5, #32]
    8458:	b40003e0 	cbz	x0, 84d4 <fwp_hof0.constprop.0+0x124>
    845c:	386268c2 	ldrb	w2, [x6, x2]
    8460:	7100085f 	cmp	w2, #0x2
    8464:	5400c000 	b.eq	9c64 <fwp_hof0.constprop.0+0x18b4>  // b.none
    8468:	7100045f 	cmp	w2, #0x1
    846c:	54000341 	b.ne	84d4 <fwp_hof0.constprop.0+0x124>  // b.any
    8470:	92403c82 	and	x2, x4, #0xffff
    8474:	294310a6 	ldp	w6, w4, [x5, #24]
    8478:	9b067c42 	mul	x2, x2, x6
    847c:	d360fc42 	lsr	x2, x2, #32
    8480:	eb04005f 	cmp	x2, x4
    8484:	54000282 	b.cs	84d4 <fwp_hof0.constprop.0+0x124>  // b.hs, b.nlast
    8488:	8b020000 	add	x0, x0, x2
    848c:	39400002 	ldrb	w2, [x0]
    8490:	34000222 	cbz	w2, 84d4 <fwp_hof0.constprop.0+0x124>
    8494:	900000c1 	adrp	x1, 20000 <__data_start>
    8498:	91014021 	add	x1, x1, #0x50
    849c:	b9413023 	ldr	w3, [x1, #304]
    84a0:	34000083 	cbz	w3, 84b0 <fwp_hof0.constprop.0+0x100>
    84a4:	f940ac23 	ldr	x3, [x1, #344]
    84a8:	91000463 	add	x3, x3, #0x1
    84ac:	f900ac23 	str	x3, [x1, #344]
    84b0:	7103f45f 	cmp	w2, #0xfd
    84b4:	5400cd48 	b.hi	9e5c <fwp_hof0.constprop.0+0x1aac>  // b.pmore
    84b8:	9118c281 	add	x1, x20, #0x630
    84bc:	11000442 	add	w2, w2, #0x1
    84c0:	39000002 	strb	w2, [x0]
    84c4:	aa0103e0 	mov	x0, x1
    84c8:	f949d821 	ldr	x1, [x1, #5040]
    84cc:	f949ec03 	ldr	x3, [x0, #5080]
    84d0:	d370bc63 	lsl	x3, x3, #16
    84d4:	f94023f5 	ldr	x21, [sp, #64]
    84d8:	d28018c0 	mov	x0, #0xc6                  	// #198
    84dc:	f90007e0 	str	x0, [sp, #8]
    84e0:	900000c0 	adrp	x0, 20000 <__data_start>
    84e4:	91014002 	add	x2, x0, #0x50
    84e8:	f94017e0 	ldr	x0, [sp, #40]
    84ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    84f0:	b9005be4 	str	w4, [sp, #88]
    84f4:	cb010001 	sub	x1, x0, x1
    84f8:	d0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0xb0>
    84fc:	910b8000 	add	x0, x0, #0x2e0
    8500:	f90037e0 	str	x0, [sp, #104]
    8504:	f941c840 	ldr	x0, [x2, #912]
    8508:	f90033e0 	str	x0, [sp, #96]
    850c:	f9400fe0 	ldr	x0, [sp, #24]
    8510:	f9003be0 	str	x0, [sp, #112]
    8514:	f94013e0 	ldr	x0, [sp, #32]
    8518:	f901c840 	str	x0, [x2, #912]
    851c:	eb03003f 	cmp	x1, x3
    8520:	54000882 	b.cs	8630 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    8524:	9118c282 	add	x2, x20, #0x630
    8528:	d350fc20 	lsr	x0, x1, #16
    852c:	8b000800 	add	x0, x0, x0, lsl #2
    8530:	f949fc44 	ldr	x4, [x2, #5112]
    8534:	d37df003 	lsl	x3, x0, #3
    8538:	8b030082 	add	x2, x4, x3
    853c:	f9401053 	ldr	x19, [x2, #32]
    8540:	b4000793 	cbz	x19, 8630 <fwp_hof0.constprop.0+0x280>
    8544:	38636880 	ldrb	w0, [x4, x3]
    8548:	7100081f 	cmp	w0, #0x2
    854c:	5400a700 	b.eq	9a2c <fwp_hof0.constprop.0+0x167c>  // b.none
    8550:	7100041f 	cmp	w0, #0x1
    8554:	540006e1 	b.ne	8630 <fwp_hof0.constprop.0+0x280>  // b.any
    8558:	29430c44 	ldp	w4, w3, [x2, #24]
    855c:	92403c20 	and	x0, x1, #0xffff
    8560:	9b047c00 	mul	x0, x0, x4
    8564:	d360fc00 	lsr	x0, x0, #32
    8568:	eb03001f 	cmp	x0, x3
    856c:	54000382 	b.cs	85dc <fwp_hof0.constprop.0+0x22c>  // b.hs, b.nlast
    8570:	8b000260 	add	x0, x19, x0
    8574:	39400003 	ldrb	w3, [x0]
    8578:	34000323 	cbz	w3, 85dc <fwp_hof0.constprop.0+0x22c>
    857c:	900000c1 	adrp	x1, 20000 <__data_start>
    8580:	91014021 	add	x1, x1, #0x50
    8584:	b9413022 	ldr	w2, [x1, #304]
    8588:	34000082 	cbz	w2, 8598 <fwp_hof0.constprop.0+0x1e8>
    858c:	f940ac22 	ldr	x2, [x1, #344]
    8590:	91000442 	add	x2, x2, #0x1
    8594:	f900ac22 	str	x2, [x1, #344]
    8598:	7103f47f 	cmp	w3, #0xfd
    859c:	5400c208 	b.hi	9ddc <fwp_hof0.constprop.0+0x1a2c>  // b.pmore
    85a0:	11000463 	add	w3, w3, #0x1
    85a4:	39000003 	strb	w3, [x0]
    85a8:	9118c280 	add	x0, x20, #0x630
    85ac:	f94017e3 	ldr	x3, [sp, #40]
    85b0:	f949d801 	ldr	x1, [x0, #5040]
    85b4:	f949ec02 	ldr	x2, [x0, #5080]
    85b8:	cb010061 	sub	x1, x3, x1
    85bc:	eb02403f 	cmp	x1, x2, lsl #16
    85c0:	54000382 	b.cs	8630 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    85c4:	f949fc00 	ldr	x0, [x0, #5112]
    85c8:	d350fc22 	lsr	x2, x1, #16
    85cc:	8b020842 	add	x2, x2, x2, lsl #2
    85d0:	8b020c02 	add	x2, x0, x2, lsl #3
    85d4:	f9401053 	ldr	x19, [x2, #32]
    85d8:	b40002d3 	cbz	x19, 8630 <fwp_hof0.constprop.0+0x280>
    85dc:	39400040 	ldrb	w0, [x2]
    85e0:	7100081f 	cmp	w0, #0x2
    85e4:	5400a2c0 	b.eq	9a3c <fwp_hof0.constprop.0+0x168c>  // b.none
    85e8:	7100041f 	cmp	w0, #0x1
    85ec:	54000221 	b.ne	8630 <fwp_hof0.constprop.0+0x280>  // b.any
    85f0:	29430043 	ldp	w3, w0, [x2, #24]
    85f4:	92403c21 	and	x1, x1, #0xffff
    85f8:	9b037c21 	mul	x1, x1, x3
    85fc:	d360fc21 	lsr	x1, x1, #32
    8600:	eb00003f 	cmp	x1, x0
    8604:	54000162 	b.cs	8630 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    8608:	8b010273 	add	x19, x19, x1
    860c:	39400261 	ldrb	w1, [x19]
    8610:	34000101 	cbz	w1, 8630 <fwp_hof0.constprop.0+0x280>
    8614:	7100043f 	cmp	w1, #0x1
    8618:	540076a0 	b.eq	94ec <fwp_hof0.constprop.0+0x113c>  // b.none
    861c:	7103fc3f 	cmp	w1, #0xff
    8620:	5400be20 	b.eq	9de4 <fwp_hof0.constprop.0+0x1a34>  // b.none
    8624:	51000421 	sub	w1, w1, #0x1
    8628:	39000261 	strb	w1, [x19]
    862c:	d503201f 	nop
    8630:	b40076f5 	cbz	x21, 950c <fwp_hof0.constprop.0+0x115c>
    8634:	aa1503e0 	mov	x0, x21
    8638:	d2800001 	mov	x1, #0x0                   	// #0
    863c:	d503201f 	nop
    8640:	f9400800 	ldr	x0, [x0, #16]
    8644:	91000421 	add	x1, x1, #0x1
    8648:	b5ffffc0 	cbnz	x0, 8640 <fwp_hof0.constprop.0+0x290>
    864c:	aa0103f7 	mov	x23, x1
    8650:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8654:	eb00003f 	cmp	x1, x0
    8658:	5400c608 	b.hi	9f18 <fwp_hof0.constprop.0+0x1b68>  // b.pmore
    865c:	900000c0 	adrp	x0, 20000 <__data_start>
    8660:	91014013 	add	x19, x0, #0x50
    8664:	b943c660 	ldr	w0, [x19, #964]
    8668:	340075c0 	cbz	w0, 9520 <fwp_hof0.constprop.0+0x1170>
    866c:	900000c0 	adrp	x0, 20000 <__data_start>
    8670:	91014000 	add	x0, x0, #0x50
    8674:	f9406c13 	ldr	x19, [x0, #216]
    8678:	f940b016 	ldr	x22, [x0, #352]
    867c:	eb1302df 	cmp	x22, x19
    8680:	5400768a 	b.ge	9550 <fwp_hof0.constprop.0+0x11a0>  // b.tcont
    8684:	f9404401 	ldr	x1, [x0, #136]
    8688:	8b1606c0 	add	x0, x22, x22, lsl #1
    868c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8690:	8b000ac0 	add	x0, x22, x0, lsl #2
    8694:	8b000c20 	add	x0, x1, x0, lsl #3
    8698:	b9400401 	ldr	w1, [x0, #4]
    869c:	35000081 	cbnz	w1, 86ac <fwp_hof0.constprop.0+0x2fc>
    86a0:	b9400001 	ldr	w1, [x0]
    86a4:	6b02003f 	cmp	w1, w2
    86a8:	54007549 	b.ls	9550 <fwp_hof0.constprop.0+0x11a0>  // b.plast
    86ac:	910006d6 	add	x22, x22, #0x1
    86b0:	9101a000 	add	x0, x0, #0x68
    86b4:	eb1302df 	cmp	x22, x19
    86b8:	54ffff01 	b.ne	8698 <fwp_hof0.constprop.0+0x2e8>  // b.any
    86bc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    86c0:	eb00027f 	cmp	x19, x0
    86c4:	5400c30c 	b.gt	9f24 <fwp_hof0.constprop.0+0x1b74>
    86c8:	900000c0 	adrp	x0, 20000 <__data_start>
    86cc:	91014000 	add	x0, x0, #0x50
    86d0:	f9409001 	ldr	x1, [x0, #288]
    86d4:	f940441c 	ldr	x28, [x0, #136]
    86d8:	eb13003f 	cmp	x1, x19
    86dc:	54000241 	b.ne	8724 <fwp_hof0.constprop.0+0x374>  // b.any
    86e0:	b400a9d3 	cbz	x19, 9c18 <fwp_hof0.constprop.0+0x1868>
    86e4:	d37ffa76 	lsl	x22, x19, #1
    86e8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    86ec:	eb0002df 	cmp	x22, x0
    86f0:	9a80d2d6 	csel	x22, x22, x0, le
    86f4:	8b1606c1 	add	x1, x22, x22, lsl #1
    86f8:	8b010ac1 	add	x1, x22, x1, lsl #2
    86fc:	d37df021 	lsl	x1, x1, #3
    8700:	aa1c03e0 	mov	x0, x28
    8704:	52800002 	mov	w2, #0x0                   	// #0
    8708:	97ffef53 	bl	4454 <ad_raw_realloc>
    870c:	aa0003fc 	mov	x28, x0
    8710:	b4003900 	cbz	x0, 8e30 <fwp_hof0.constprop.0+0xa80>
    8714:	900000c0 	adrp	x0, 20000 <__data_start>
    8718:	91014000 	add	x0, x0, #0x50
    871c:	f900441c 	str	x28, [x0, #136]
    8720:	f9009016 	str	x22, [x0, #288]
    8724:	aa1303f6 	mov	x22, x19
    8728:	8b130660 	add	x0, x19, x19, lsl #1
    872c:	4f000400 	movi	v0.4s, #0x0
    8730:	900000c1 	adrp	x1, 20000 <__data_start>
    8734:	8b1606d8 	add	x24, x22, x22, lsl #1
    8738:	8b000a60 	add	x0, x19, x0, lsl #2
    873c:	91014021 	add	x1, x1, #0x50
    8740:	91000673 	add	x19, x19, #0x1
    8744:	8b180ad8 	add	x24, x22, x24, lsl #2
    8748:	8b000f80 	add	x0, x28, x0, lsl #3
    874c:	8b180f98 	add	x24, x28, x24, lsl #3
    8750:	f9006c33 	str	x19, [x1, #216]
    8754:	ad000000 	stp	q0, q0, [x0]
    8758:	ad010000 	stp	q0, q0, [x0, #32]
    875c:	ad020000 	stp	q0, q0, [x0, #64]
    8760:	f900301f 	str	xzr, [x0, #96]
    8764:	b0000020 	adrp	x0, d000 <__modti3+0xf0>
    8768:	f900331f 	str	xzr, [x24, #96]
    876c:	911ac000 	add	x0, x0, #0x6b0
    8770:	97ffe8b0 	bl	2a30 <getenv@plt>
    8774:	b4007080 	cbz	x0, 9584 <fwp_hof0.constprop.0+0x11d4>
    8778:	39400001 	ldrb	w1, [x0]
    877c:	7100c03f 	cmp	w1, #0x30
    8780:	54007021 	b.ne	9584 <fwp_hof0.constprop.0+0x11d4>  // b.any
    8784:	39400400 	ldrb	w0, [x0, #1]
    8788:	35006fe0 	cbnz	w0, 9584 <fwp_hof0.constprop.0+0x11d4>
    878c:	900000c0 	adrp	x0, 20000 <__data_start>
    8790:	91014000 	add	x0, x0, #0x50
    8794:	2f000400 	mvni	v0.2s, #0x0
    8798:	b9400313 	ldr	w19, [x24]
    879c:	52800022 	mov	w2, #0x1                   	// #1
    87a0:	910006c4 	add	x4, x22, #0x1
    87a4:	f941c801 	ldr	x1, [x0, #912]
    87a8:	0b020273 	add	w19, w19, w2
    87ac:	29000b13 	stp	w19, w2, [x24]
    87b0:	a900df17 	stp	x23, x23, [x24, #8]
    87b4:	f9002b1f 	str	xzr, [x24, #80]
    87b8:	f900b004 	str	x4, [x0, #352]
    87bc:	fd002f00 	str	d0, [x24, #88]
    87c0:	b400bb81 	cbz	x1, 9f30 <fwp_hof0.constprop.0+0x1b80>
    87c4:	d0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0xb0>
    87c8:	910b8003 	add	x3, x0, #0x2e0
    87cc:	14000003 	b	87d8 <fwp_hof0.constprop.0+0x428>
    87d0:	f9400021 	ldr	x1, [x1]
    87d4:	b400bae1 	cbz	x1, 9f30 <fwp_hof0.constprop.0+0x1b80>
    87d8:	f9400422 	ldr	x2, [x1, #8]
    87dc:	eb03005f 	cmp	x2, x3
    87e0:	54ffff81 	b.ne	87d0 <fwp_hof0.constprop.0+0x420>  // b.any
    87e4:	f9400820 	ldr	x0, [x1, #16]
    87e8:	2a1603e2 	mov	w2, w22
    87ec:	b9400001 	ldr	w1, [x0]
    87f0:	f9002b00 	str	x0, [x24, #80]
    87f4:	b9005f01 	str	w1, [x24, #92]
    87f8:	37f80081 	tbnz	w1, #31, 8808 <fwp_hof0.constprop.0+0x458>
    87fc:	52800d03 	mov	w3, #0x68                  	// #104
    8800:	9b237021 	smaddl	x1, w1, w3, x28
    8804:	b9005836 	str	w22, [x1, #88]
    8808:	b9000002 	str	w2, [x0]
    880c:	d3707e73 	ubfiz	x19, x19, #16, #32
    8810:	aa040273 	orr	x19, x19, x4
    8814:	aa1503e0 	mov	x0, x21
    8818:	d2800002 	mov	x2, #0x0                   	// #0
    881c:	b4007395 	cbz	x21, 968c <fwp_hof0.constprop.0+0x12dc>
    8820:	f9400800 	ldr	x0, [x0, #16]
    8824:	91000442 	add	x2, x2, #0x1
    8828:	b5ffffc0 	cbnz	x0, 8820 <fwp_hof0.constprop.0+0x470>
    882c:	aa1503e1 	mov	x1, x21
    8830:	f9400821 	ldr	x1, [x1, #16]
    8834:	91000400 	add	x0, x0, #0x1
    8838:	b5ffffc1 	cbnz	x1, 8830 <fwp_hof0.constprop.0+0x480>
    883c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8840:	eb01001f 	cmp	x0, x1
    8844:	5400b508 	b.hi	9ee4 <fwp_hof0.constprop.0+0x1b34>  // b.pmore
    8848:	f100005f 	cmp	x2, #0x0
    884c:	5400720d 	b.le	968c <fwp_hof0.constprop.0+0x12dc>
    8850:	eb00005f 	cmp	x2, x0
    8854:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8858:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    885c:	eb0102df 	cmp	x22, x1
    8860:	5400b428 	b.hi	9ee4 <fwp_hof0.constprop.0+0x1b34>  // b.pmore
    8864:	d37ffad7 	lsl	x23, x22, #1
    8868:	52800041 	mov	w1, #0x2                   	// #2
    886c:	910006e0 	add	x0, x23, #0x1
    8870:	d37df000 	lsl	x0, x0, #3
    8874:	97fff227 	bl	5110 <fwp_heap_alloc>
    8878:	aa0003f8 	mov	x24, x0
    887c:	9118c281 	add	x1, x20, #0x630
    8880:	aa0003fc 	mov	x28, x0
    8884:	aa0103e0 	mov	x0, x1
    8888:	f9000317 	str	x23, [x24]
    888c:	f949d821 	ldr	x1, [x1, #5040]
    8890:	f949ec00 	ldr	x0, [x0, #5080]
    8894:	cb010301 	sub	x1, x24, x1
    8898:	eb00403f 	cmp	x1, x0, lsl #16
    889c:	54008242 	b.cs	98e4 <fwp_hof0.constprop.0+0x1534>  // b.hs, b.nlast
    88a0:	9118c282 	add	x2, x20, #0x630
    88a4:	d350fc20 	lsr	x0, x1, #16
    88a8:	8b000800 	add	x0, x0, x0, lsl #2
    88ac:	f949fc43 	ldr	x3, [x2, #5112]
    88b0:	d37df002 	lsl	x2, x0, #3
    88b4:	8b020060 	add	x0, x3, x2
    88b8:	f9401017 	ldr	x23, [x0, #32]
    88bc:	b4000257 	cbz	x23, 8904 <fwp_hof0.constprop.0+0x554>
    88c0:	38626862 	ldrb	w2, [x3, x2]
    88c4:	7100085f 	cmp	w2, #0x2
    88c8:	54008c00 	b.eq	9a48 <fwp_hof0.constprop.0+0x1698>  // b.none
    88cc:	7100045f 	cmp	w2, #0x1
    88d0:	540001a1 	b.ne	8904 <fwp_hof0.constprop.0+0x554>  // b.any
    88d4:	29430002 	ldp	w2, w0, [x0, #24]
    88d8:	92403c21 	and	x1, x1, #0xffff
    88dc:	9b027c21 	mul	x1, x1, x2
    88e0:	d360fc21 	lsr	x1, x1, #32
    88e4:	eb00003f 	cmp	x1, x0
    88e8:	540000e2 	b.cs	8904 <fwp_hof0.constprop.0+0x554>  // b.hs, b.nlast
    88ec:	8b0102f7 	add	x23, x23, x1
    88f0:	394002e0 	ldrb	w0, [x23]
    88f4:	7103fc1f 	cmp	w0, #0xff
    88f8:	54008b20 	b.eq	9a5c <fwp_hof0.constprop.0+0x16ac>  // b.none
    88fc:	52800020 	mov	w0, #0x1                   	// #1
    8900:	390002e0 	strb	w0, [x23]
    8904:	b4000236 	cbz	x22, 8948 <fwp_hof0.constprop.0+0x598>
    8908:	d3607e64 	lsl	x4, x19, #32
    890c:	aa1503e1 	mov	x1, x21
    8910:	f94006a5 	ldr	x5, [x21, #8]
    8914:	aa0403e3 	mov	x3, x4
    8918:	91002302 	add	x2, x24, #0x8
    891c:	d2800000 	mov	x0, #0x0                   	// #0
    8920:	14000005 	b	8934 <fwp_hof0.constprop.0+0x584>
    8924:	f9400425 	ldr	x5, [x1, #8]
    8928:	ab000083 	adds	x3, x4, x0
    892c:	91004042 	add	x2, x2, #0x10
    8930:	5400b1a6 	b.vs	9f64 <fwp_hof0.constprop.0+0x1bb4>
    8934:	a9000c45 	stp	x5, x3, [x2]
    8938:	91000400 	add	x0, x0, #0x1
    893c:	f9400821 	ldr	x1, [x1, #16]
    8940:	eb0002df 	cmp	x22, x0
    8944:	54ffff08 	b.hi	8924 <fwp_hof0.constprop.0+0x574>  // b.pmore
    8948:	f9400300 	ldr	x0, [x24]
    894c:	f100041f 	cmp	x0, #0x1
    8950:	54007cc9 	b.ls	98e8 <fwp_hof0.constprop.0+0x1538>  // b.plast
    8954:	d341fc00 	lsr	x0, x0, #1
    8958:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    895c:	d1000417 	sub	x23, x0, #0x1
    8960:	eb0102ff 	cmp	x23, x1
    8964:	5400ac08 	b.hi	9ee4 <fwp_hof0.constprop.0+0x1b34>  // b.pmore
    8968:	b4007c17 	cbz	x23, 98e8 <fwp_hof0.constprop.0+0x1538>
    896c:	d1002301 	sub	x1, x24, #0x8
    8970:	91002319 	add	x25, x24, #0x8
    8974:	8b001036 	add	x22, x1, x0, lsl #4
    8978:	f9400720 	ldr	x0, [x25, #8]
    897c:	f9400f21 	ldr	x1, [x25, #24]
    8980:	fd400320 	ldr	d0, [x25]
    8984:	fd400b21 	ldr	d1, [x25, #16]
    8988:	97fff353 	bl	56d4 <w120>
    898c:	a9000720 	stp	x0, x1, [x25]
    8990:	91004339 	add	x25, x25, #0x10
    8994:	eb16033f 	cmp	x25, x22
    8998:	54ffff01 	b.ne	8978 <fwp_hof0.constprop.0+0x5c8>  // b.any
    899c:	aa1803f6 	mov	x22, x24
    89a0:	d37ffaf7 	lsl	x23, x23, #1
    89a4:	9280001b 	mov	x27, #0xffffffffffffffff    	// #-1
    89a8:	d2800019 	mov	x25, #0x0                   	// #0
    89ac:	f80106d7 	str	x23, [x22], #16
    89b0:	f8797ac2 	ldr	x2, [x22, x25, lsl #3]
    89b4:	aa1b03e0 	mov	x0, x27
    89b8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    89bc:	91000b39 	add	x25, x25, #0x2
    89c0:	aa0303e1 	mov	x1, x3
    89c4:	97fff293 	bl	5410 <fwp_p_ad_push>
    89c8:	aa0003fb 	mov	x27, x0
    89cc:	eb17033f 	cmp	x25, x23
    89d0:	54ffff03 	b.cc	89b0 <fwp_hof0.constprop.0+0x600>  // b.lo, b.ul, b.last
    89d4:	9118c296 	add	x22, x20, #0x630
    89d8:	f949dac1 	ldr	x1, [x22, #5040]
    89dc:	f949eec0 	ldr	x0, [x22, #5080]
    89e0:	cb010301 	sub	x1, x24, x1
    89e4:	eb00403f 	cmp	x1, x0, lsl #16
    89e8:	54000382 	b.cs	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.hs, b.nlast
    89ec:	d350fc20 	lsr	x0, x1, #16
    89f0:	f949fec5 	ldr	x5, [x22, #5112]
    89f4:	8b000800 	add	x0, x0, x0, lsl #2
    89f8:	d37df000 	lsl	x0, x0, #3
    89fc:	8b0000a2 	add	x2, x5, x0
    8a00:	f9401057 	ldr	x23, [x2, #32]
    8a04:	b40002b7 	cbz	x23, 8a58 <fwp_hof0.constprop.0+0x6a8>
    8a08:	386068a0 	ldrb	w0, [x5, x0]
    8a0c:	7100081f 	cmp	w0, #0x2
    8a10:	54007720 	b.eq	98f4 <fwp_hof0.constprop.0+0x1544>  // b.none
    8a14:	7100041f 	cmp	w0, #0x1
    8a18:	54000201 	b.ne	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.any
    8a1c:	29430043 	ldp	w3, w0, [x2, #24]
    8a20:	92403c21 	and	x1, x1, #0xffff
    8a24:	9b037c21 	mul	x1, x1, x3
    8a28:	d360fc21 	lsr	x1, x1, #32
    8a2c:	eb00003f 	cmp	x1, x0
    8a30:	54000142 	b.cs	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.hs, b.nlast
    8a34:	8b0102f7 	add	x23, x23, x1
    8a38:	394002e0 	ldrb	w0, [x23]
    8a3c:	340000e0 	cbz	w0, 8a58 <fwp_hof0.constprop.0+0x6a8>
    8a40:	7100041f 	cmp	w0, #0x1
    8a44:	540020e0 	b.eq	8e60 <fwp_hof0.constprop.0+0xab0>  // b.none
    8a48:	7103fc1f 	cmp	w0, #0xff
    8a4c:	54009120 	b.eq	9c70 <fwp_hof0.constprop.0+0x18c0>  // b.none
    8a50:	51000400 	sub	w0, w0, #0x1
    8a54:	390002e0 	strb	w0, [x23]
    8a58:	93407e73 	sxtw	x19, w19
    8a5c:	aa1303e0 	mov	x0, x19
    8a60:	97ffec34 	bl	3b30 <fwp_tape_of>
    8a64:	f9403001 	ldr	x1, [x0, #96]
    8a68:	aa0003ea 	mov	x10, x0
    8a6c:	b500a501 	cbnz	x1, 9f0c <fwp_hof0.constprop.0+0x1b5c>
    8a70:	97ffe969 	bl	3014 <fwp_tape_unlink_scope>
    8a74:	b9400002 	ldr	w2, [x0]
    8a78:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    8a7c:	a940801c 	ldp	x28, x0, [x0, #8]
    8a80:	b900055f 	str	wzr, [x10, #4]
    8a84:	a941e54b 	ldp	x11, x25, [x10, #24]
    8a88:	a942955a 	ldp	x26, x5, [x10, #40]
    8a8c:	a943e149 	ldp	x9, x24, [x10, #56]
    8a90:	f9402557 	ldr	x23, [x10, #72]
    8a94:	6b01005f 	cmp	w2, w1
    8a98:	54000128 	b.hi	8abc <fwp_hof0.constprop.0+0x70c>  // b.pmore
    8a9c:	900000c1 	adrp	x1, 20000 <__data_start>
    8aa0:	91014022 	add	x2, x1, #0x50
    8aa4:	92403e61 	and	x1, x19, #0xffff
    8aa8:	d1000421 	sub	x1, x1, #0x1
    8aac:	f940b043 	ldr	x3, [x2, #352]
    8ab0:	eb03003f 	cmp	x1, x3
    8ab4:	5400004a 	b.ge	8abc <fwp_hof0.constprop.0+0x70c>  // b.tcont
    8ab8:	f900b041 	str	x1, [x2, #352]
    8abc:	4f000400 	movi	v0.4s, #0x0
    8ac0:	900000c1 	adrp	x1, 20000 <__data_start>
    8ac4:	91014023 	add	x3, x1, #0x50
    8ac8:	f9000d5f 	str	xzr, [x10, #24]
    8acc:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    8ad0:	910243e4 	add	x4, sp, #0x90
    8ad4:	9101e3e1 	add	x1, sp, #0x78
    8ad8:	f941c86c 	ldr	x12, [x3, #912]
    8adc:	3c808140 	stur	q0, [x10, #8]
    8ae0:	90ffffe2 	adrp	x2, 4000 <fwp_heap_report+0x60>
    8ae4:	ad010140 	stp	q0, q0, [x10, #32]
    8ae8:	91149042 	add	x2, x2, #0x524
    8aec:	f9000be4 	str	x4, [sp, #16]
    8af0:	a9078bec 	stp	x12, x2, [sp, #120]
    8af4:	a908e7e4 	stp	x4, x25, [sp, #136]
    8af8:	a90997fa 	stp	x26, x5, [sp, #152]
    8afc:	a90ae3e9 	stp	x9, x24, [sp, #168]
    8b00:	a90bdfeb 	stp	x11, x23, [sp, #184]
    8b04:	f901c861 	str	x1, [x3, #912]
    8b08:	b7f87b1b 	tbnz	x27, #63, 9a68 <fwp_hof0.constprop.0+0x16b8>
    8b0c:	eb9b827f 	cmp	x19, x27, asr #32
    8b10:	54009b21 	b.ne	9e74 <fwp_hof0.constprop.0+0x1ac4>  // b.any
    8b14:	92407f76 	and	x22, x27, #0xffffffff
    8b18:	eb3b401f 	cmp	x0, w27, uxtw
    8b1c:	540099ad 	b.le	9e50 <fwp_hof0.constprop.0+0x1aa0>
    8b20:	eb16039f 	cmp	x28, x22
    8b24:	9a96c796 	csinc	x22, x28, x22, gt
    8b28:	eb1602ff 	cmp	x23, x22
    8b2c:	540016ca 	b.ge	8e04 <fwp_hof0.constprop.0+0xa54>  // b.tcont
    8b30:	f10002ff 	cmp	x23, #0x0
    8b34:	9a9612f7 	csel	x23, x23, x22, ne	// ne = any
    8b38:	14000005 	b	8b4c <fwp_hof0.constprop.0+0x79c>
    8b3c:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8b40:	eb0002ff 	cmp	x23, x0
    8b44:	d37ffaf7 	lsl	x23, x23, #1
    8b48:	9a96d2f7 	csel	x23, x23, x22, le
    8b4c:	eb1602ff 	cmp	x23, x22
    8b50:	54ffff6b 	b.lt	8b3c <fwp_hof0.constprop.0+0x78c>  // b.tstop
    8b54:	b40080f8 	cbz	x24, 9b70 <fwp_hof0.constprop.0+0x17c0>
    8b58:	aa1803e0 	mov	x0, x24
    8b5c:	d37df2e1 	lsl	x1, x23, #3
    8b60:	52800062 	mov	w2, #0x3                   	// #3
    8b64:	a90327e5 	stp	x5, x9, [sp, #48]
    8b68:	97ffee3b 	bl	4454 <ad_raw_realloc>
    8b6c:	a94327e5 	ldp	x5, x9, [sp, #48]
    8b70:	aa0003f8 	mov	x24, x0
    8b74:	b4007ea0 	cbz	x0, 9b48 <fwp_hof0.constprop.0+0x1798>
    8b78:	f9005bf8 	str	x24, [sp, #176]
    8b7c:	f90063f7 	str	x23, [sp, #192]
    8b80:	b5001356 	cbnz	x22, 8de8 <fwp_hof0.constprop.0+0xa38>
    8b84:	b7f800db 	tbnz	x27, #63, 8b9c <fwp_hof0.constprop.0+0x7ec>
    8b88:	92407f60 	and	x0, x27, #0xffffffff
    8b8c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8b90:	fc607b00 	ldr	d0, [x24, x0, lsl #3]
    8b94:	1e612800 	fadd	d0, d0, d1
    8b98:	fc207b00 	str	d0, [x24, x0, lsl #3]
    8b9c:	d10006d6 	sub	x22, x22, #0x1
    8ba0:	d1000783 	sub	x3, x28, #0x1
    8ba4:	eb16039f 	cmp	x28, x22
    8ba8:	540003ac 	b.gt	8c1c <fwp_hof0.constprop.0+0x86c>
    8bac:	fc767b00 	ldr	d0, [x24, x22, lsl #3]
    8bb0:	1e602008 	fcmp	d0, #0.0
    8bb4:	540002e0 	b.eq	8c10 <fwp_hof0.constprop.0+0x860>  // b.none
    8bb8:	cb1c0be0 	neg	x0, x28, lsl #2
    8bbc:	cb1c03e2 	neg	x2, x28
    8bc0:	8b000321 	add	x1, x25, x0
    8bc4:	b8767821 	ldr	w1, [x1, x22, lsl #2]
    8bc8:	37f80101 	tbnz	w1, #31, 8be8 <fwp_hof0.constprop.0+0x838>
    8bcc:	8b020ca4 	add	x4, x5, x2, lsl #3
    8bd0:	93407c21 	sxtw	x1, w1
    8bd4:	fc767882 	ldr	d2, [x4, x22, lsl #3]
    8bd8:	fc617b01 	ldr	d1, [x24, x1, lsl #3]
    8bdc:	1e620802 	fmul	d2, d0, d2
    8be0:	1e622821 	fadd	d1, d1, d2
    8be4:	fc217b01 	str	d1, [x24, x1, lsl #3]
    8be8:	8b000340 	add	x0, x26, x0
    8bec:	b8767800 	ldr	w0, [x0, x22, lsl #2]
    8bf0:	37f80100 	tbnz	w0, #31, 8c10 <fwp_hof0.constprop.0+0x860>
    8bf4:	8b020d22 	add	x2, x9, x2, lsl #3
    8bf8:	93407c00 	sxtw	x0, w0
    8bfc:	fc767842 	ldr	d2, [x2, x22, lsl #3]
    8c00:	fc607b01 	ldr	d1, [x24, x0, lsl #3]
    8c04:	1e620800 	fmul	d0, d0, d2
    8c08:	1e602820 	fadd	d0, d1, d0
    8c0c:	fc207b00 	str	d0, [x24, x0, lsl #3]
    8c10:	d10006d6 	sub	x22, x22, #0x1
    8c14:	eb16007f 	cmp	x3, x22
    8c18:	54fffca1 	b.ne	8bac <fwp_hof0.constprop.0+0x7fc>  // b.any
    8c1c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8c20:	eb00039f 	cmp	x28, x0
    8c24:	54009928 	b.hi	9f48 <fwp_hof0.constprop.0+0x1b98>  // b.pmore
    8c28:	91000780 	add	x0, x28, #0x1
    8c2c:	52800041 	mov	w1, #0x2                   	// #2
    8c30:	d37df000 	lsl	x0, x0, #3
    8c34:	97fff137 	bl	5110 <fwp_heap_alloc>
    8c38:	aa0003e2 	mov	x2, x0
    8c3c:	aa0003f3 	mov	x19, x0
    8c40:	d2800001 	mov	x1, #0x0                   	// #0
    8c44:	f800845c 	str	x28, [x2], #8
    8c48:	b40000fc 	cbz	x28, 8c64 <fwp_hof0.constprop.0+0x8b4>
    8c4c:	d503201f 	nop
    8c50:	f8617b00 	ldr	x0, [x24, x1, lsl #3]
    8c54:	f8217840 	str	x0, [x2, x1, lsl #3]
    8c58:	91000421 	add	x1, x1, #0x1
    8c5c:	eb01039f 	cmp	x28, x1
    8c60:	54ffff81 	b.ne	8c50 <fwp_hof0.constprop.0+0x8a0>  // b.any
    8c64:	900000c0 	adrp	x0, 20000 <__data_start>
    8c68:	91014001 	add	x1, x0, #0x50
    8c6c:	f9400be0 	ldr	x0, [sp, #16]
    8c70:	f9403ff7 	ldr	x23, [sp, #120]
    8c74:	f901c837 	str	x23, [x1, #912]
    8c78:	97ffee2b 	bl	4524 <fwp_tape_buffers_release>
    8c7c:	9118c282 	add	x2, x20, #0x630
    8c80:	f949d841 	ldr	x1, [x2, #5040]
    8c84:	f949ec40 	ldr	x0, [x2, #5080]
    8c88:	cb010261 	sub	x1, x19, x1
    8c8c:	eb00403f 	cmp	x1, x0, lsl #16
    8c90:	54000322 	b.cs	8cf4 <fwp_hof0.constprop.0+0x944>  // b.hs, b.nlast
    8c94:	d350fc20 	lsr	x0, x1, #16
    8c98:	f949fc43 	ldr	x3, [x2, #5112]
    8c9c:	8b000800 	add	x0, x0, x0, lsl #2
    8ca0:	d37df002 	lsl	x2, x0, #3
    8ca4:	8b020060 	add	x0, x3, x2
    8ca8:	f9401016 	ldr	x22, [x0, #32]
    8cac:	b4000256 	cbz	x22, 8cf4 <fwp_hof0.constprop.0+0x944>
    8cb0:	38626862 	ldrb	w2, [x3, x2]
    8cb4:	7100085f 	cmp	w2, #0x2
    8cb8:	54006dc0 	b.eq	9a70 <fwp_hof0.constprop.0+0x16c0>  // b.none
    8cbc:	7100045f 	cmp	w2, #0x1
    8cc0:	540001a1 	b.ne	8cf4 <fwp_hof0.constprop.0+0x944>  // b.any
    8cc4:	29430002 	ldp	w2, w0, [x0, #24]
    8cc8:	92403c21 	and	x1, x1, #0xffff
    8ccc:	9b027c21 	mul	x1, x1, x2
    8cd0:	d360fc21 	lsr	x1, x1, #32
    8cd4:	eb00003f 	cmp	x1, x0
    8cd8:	540000e2 	b.cs	8cf4 <fwp_hof0.constprop.0+0x944>  // b.hs, b.nlast
    8cdc:	8b0102d6 	add	x22, x22, x1
    8ce0:	394002c0 	ldrb	w0, [x22]
    8ce4:	7103fc1f 	cmp	w0, #0xff
    8ce8:	54006ce0 	b.eq	9a84 <fwp_hof0.constprop.0+0x16d4>  // b.none
    8cec:	52800020 	mov	w0, #0x1                   	// #1
    8cf0:	390002c0 	strb	w0, [x22]
    8cf4:	f94013e0 	ldr	x0, [sp, #32]
    8cf8:	eb0002ff 	cmp	x23, x0
    8cfc:	54009321 	b.ne	9f60 <fwp_hof0.constprop.0+0x1bb0>  // b.any
    8d00:	900000c0 	adrp	x0, 20000 <__data_start>
    8d04:	91014001 	add	x1, x0, #0x50
    8d08:	f9400fe0 	ldr	x0, [sp, #24]
    8d0c:	f94033e2 	ldr	x2, [sp, #96]
    8d10:	f901c822 	str	x2, [x1, #912]
    8d14:	97fff573 	bl	62e0 <fwp_tape_scope_release>
    8d18:	f9400260 	ldr	x0, [x19]
    8d1c:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    8d20:	b7f845c0 	tbnz	x0, #63, 95d8 <fwp_hof0.constprop.0+0x1228>
    8d24:	9118c282 	add	x2, x20, #0x630
    8d28:	f949d840 	ldr	x0, [x2, #5040]
    8d2c:	f949ec41 	ldr	x1, [x2, #5080]
    8d30:	cb000260 	sub	x0, x19, x0
    8d34:	eb01401f 	cmp	x0, x1, lsl #16
    8d38:	54004502 	b.cs	95d8 <fwp_hof0.constprop.0+0x1228>  // b.hs, b.nlast
    8d3c:	d350fc01 	lsr	x1, x0, #16
    8d40:	f949fc44 	ldr	x4, [x2, #5112]
    8d44:	8b010821 	add	x1, x1, x1, lsl #2
    8d48:	d37df021 	lsl	x1, x1, #3
    8d4c:	8b010083 	add	x3, x4, x1
    8d50:	f9401062 	ldr	x2, [x3, #32]
    8d54:	b4004422 	cbz	x2, 95d8 <fwp_hof0.constprop.0+0x1228>
    8d58:	38616881 	ldrb	w1, [x4, x1]
    8d5c:	7100083f 	cmp	w1, #0x2
    8d60:	54004360 	b.eq	95cc <fwp_hof0.constprop.0+0x121c>  // b.none
    8d64:	7100043f 	cmp	w1, #0x1
    8d68:	54004381 	b.ne	95d8 <fwp_hof0.constprop.0+0x1228>  // b.any
    8d6c:	29430464 	ldp	w4, w1, [x3, #24]
    8d70:	92403c00 	and	x0, x0, #0xffff
    8d74:	9b047c00 	mul	x0, x0, x4
    8d78:	d360fc00 	lsr	x0, x0, #32
    8d7c:	eb01001f 	cmp	x0, x1
    8d80:	540042c2 	b.cs	95d8 <fwp_hof0.constprop.0+0x1228>  // b.hs, b.nlast
    8d84:	8b000042 	add	x2, x2, x0
    8d88:	39400040 	ldrb	w0, [x2]
    8d8c:	7100041f 	cmp	w0, #0x1
    8d90:	54004241 	b.ne	95d8 <fwp_hof0.constprop.0+0x1228>  // b.any
    8d94:	aa1303fc 	mov	x28, x19
    8d98:	aa1303f6 	mov	x22, x19
    8d9c:	d2800000 	mov	x0, #0x0                   	// #0
    8da0:	910022c3 	add	x3, x22, #0x8
    8da4:	91002265 	add	x5, x19, #0x8
    8da8:	d2800001 	mov	x1, #0x0                   	// #0
    8dac:	b5000157 	cbnz	x23, 8dd4 <fwp_hof0.constprop.0+0xa24>
    8db0:	1400004d 	b	8ee4 <fwp_hof0.constprop.0+0xb34>
    8db4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8db8:	f9400382 	ldr	x2, [x28]
    8dbc:	1e600900 	fmul	d0, d8, d0
    8dc0:	b7f888c2 	tbnz	x2, #63, 9ed8 <fwp_hof0.constprop.0+0x1b28>
    8dc4:	91000421 	add	x1, x1, #0x1
    8dc8:	fc008460 	str	d0, [x3], #8
    8dcc:	eb0102ff 	cmp	x23, x1
    8dd0:	540008a0 	b.eq	8ee4 <fwp_hof0.constprop.0+0xb34>  // b.none
    8dd4:	f9400264 	ldr	x4, [x19]
    8dd8:	aa0503e2 	mov	x2, x5
    8ddc:	b6fffec4 	tbz	x4, #63, 8db4 <fwp_hof0.constprop.0+0xa04>
    8de0:	f9400a62 	ldr	x2, [x19, #16]
    8de4:	17fffff4 	b	8db4 <fwp_hof0.constprop.0+0xa04>
    8de8:	d37df2c2 	lsl	x2, x22, #3
    8dec:	aa1803e0 	mov	x0, x24
    8df0:	52800001 	mov	w1, #0x0                   	// #0
    8df4:	a90327e5 	stp	x5, x9, [sp, #48]
    8df8:	97ffe69e 	bl	2870 <memset@plt>
    8dfc:	a94327e5 	ldp	x5, x9, [sp, #48]
    8e00:	17ffff61 	b	8b84 <fwp_hof0.constprop.0+0x7d4>
    8e04:	f100031f 	cmp	x24, #0x0
    8e08:	1a9f17e0 	cset	w0, eq	// eq = none
    8e0c:	f10002df 	cmp	x22, #0x0
    8e10:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8e14:	54ffeb60 	b.eq	8b80 <fwp_hof0.constprop.0+0x7d0>  // b.none
    8e18:	900000c0 	adrp	x0, 20000 <__data_start>
    8e1c:	91014019 	add	x25, x0, #0x50
    8e20:	f9400be0 	ldr	x0, [sp, #16]
    8e24:	f9403fe1 	ldr	x1, [sp, #120]
    8e28:	f901cb21 	str	x1, [x25, #912]
    8e2c:	97ffedbe 	bl	4524 <fwp_tape_buffers_release>
    8e30:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    8e34:	f947e863 	ldr	x3, [x3, #4048]
    8e38:	d2800262 	mov	x2, #0x13                  	// #19
    8e3c:	d2800021 	mov	x1, #0x1                   	// #1
    8e40:	b0000020 	adrp	x0, d000 <__modti3+0xf0>
    8e44:	910ae000 	add	x0, x0, #0x2b8
    8e48:	f9400063 	ldr	x3, [x3]
    8e4c:	97ffe6d5 	bl	29a0 <fwrite@plt>
    8e50:	d2800000 	mov	x0, #0x0                   	// #0
    8e54:	97ffe6df 	bl	29d0 <fflush@plt>
    8e58:	52800cc0 	mov	w0, #0x66                  	// #102
    8e5c:	97ffe6ed 	bl	2a10 <_Exit@plt>
    8e60:	f9400386 	ldr	x6, [x28]
    8e64:	aa1c03e0 	mov	x0, x28
    8e68:	f949eec3 	ldr	x3, [x22, #5080]
    8e6c:	f949dac1 	ldr	x1, [x22, #5040]
    8e70:	d370bc63 	lsl	x3, x3, #16
    8e74:	cb010382 	sub	x2, x28, x1
    8e78:	b7f854a6 	tbnz	x6, #63, 990c <fwp_hof0.constprop.0+0x155c>
    8e7c:	eb02007f 	cmp	x3, x2
    8e80:	54ffdec9 	b.ls	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.plast
    8e84:	d350fc40 	lsr	x0, x2, #16
    8e88:	8b000800 	add	x0, x0, x0, lsl #2
    8e8c:	d37df000 	lsl	x0, x0, #3
    8e90:	8b0000a3 	add	x3, x5, x0
    8e94:	f9401061 	ldr	x1, [x3, #32]
    8e98:	b4ffde01 	cbz	x1, 8a58 <fwp_hof0.constprop.0+0x6a8>
    8e9c:	386068a0 	ldrb	w0, [x5, x0]
    8ea0:	7100081f 	cmp	w0, #0x2
    8ea4:	54005f60 	b.eq	9a90 <fwp_hof0.constprop.0+0x16e0>  // b.none
    8ea8:	7100041f 	cmp	w0, #0x1
    8eac:	54ffdd61 	b.ne	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.any
    8eb0:	92403c40 	and	x0, x2, #0xffff
    8eb4:	29430865 	ldp	w5, w2, [x3, #24]
    8eb8:	9b057c00 	mul	x0, x0, x5
    8ebc:	d360fc00 	lsr	x0, x0, #32
    8ec0:	eb02001f 	cmp	x0, x2
    8ec4:	54ffdca2 	b.cs	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.hs, b.nlast
    8ec8:	8b000021 	add	x1, x1, x0
    8ecc:	39400020 	ldrb	w0, [x1]
    8ed0:	7100041f 	cmp	w0, #0x1
    8ed4:	54ffdc21 	b.ne	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.any
    8ed8:	aa1c03e0 	mov	x0, x28
    8edc:	97ffef6d 	bl	4c90 <fwp_mem_free>
    8ee0:	17fffede 	b	8a58 <fwp_hof0.constprop.0+0x6a8>
    8ee4:	97fff6eb 	bl	6a90 <fwp_drop10>
    8ee8:	aa1503e1 	mov	x1, x21
    8eec:	d2800002 	mov	x2, #0x0                   	// #0
    8ef0:	b4006815 	cbz	x21, 9bf0 <fwp_hof0.constprop.0+0x1840>
    8ef4:	d503201f 	nop
    8ef8:	f9400821 	ldr	x1, [x1, #16]
    8efc:	91000442 	add	x2, x2, #0x1
    8f00:	b5ffffc1 	cbnz	x1, 8ef8 <fwp_hof0.constprop.0+0xb48>
    8f04:	f9400385 	ldr	x5, [x28]
    8f08:	9240f8a4 	and	x4, x5, #0x7fffffffffffffff
    8f0c:	b7f82b65 	tbnz	x5, #63, 9478 <fwp_hof0.constprop.0+0x10c8>
    8f10:	9118c281 	add	x1, x20, #0x630
    8f14:	f949d820 	ldr	x0, [x1, #5040]
    8f18:	f949ec21 	ldr	x1, [x1, #5080]
    8f1c:	cb0002c0 	sub	x0, x22, x0
    8f20:	eb01401f 	cmp	x0, x1, lsl #16
    8f24:	54002aa2 	b.cs	9478 <fwp_hof0.constprop.0+0x10c8>  // b.hs, b.nlast
    8f28:	9118c283 	add	x3, x20, #0x630
    8f2c:	d350fc01 	lsr	x1, x0, #16
    8f30:	8b010821 	add	x1, x1, x1, lsl #2
    8f34:	f949fc67 	ldr	x7, [x3, #5112]
    8f38:	d37df021 	lsl	x1, x1, #3
    8f3c:	8b0100e6 	add	x6, x7, x1
    8f40:	f94010c3 	ldr	x3, [x6, #32]
    8f44:	b4002983 	cbz	x3, 9474 <fwp_hof0.constprop.0+0x10c4>
    8f48:	386168e1 	ldrb	w1, [x7, x1]
    8f4c:	7100083f 	cmp	w1, #0x2
    8f50:	540028e0 	b.eq	946c <fwp_hof0.constprop.0+0x10bc>  // b.none
    8f54:	7100043f 	cmp	w1, #0x1
    8f58:	540028e1 	b.ne	9474 <fwp_hof0.constprop.0+0x10c4>  // b.any
    8f5c:	294304c7 	ldp	w7, w1, [x6, #24]
    8f60:	92403c00 	and	x0, x0, #0xffff
    8f64:	9b077c00 	mul	x0, x0, x7
    8f68:	d360fc00 	lsr	x0, x0, #32
    8f6c:	eb01001f 	cmp	x0, x1
    8f70:	54002822 	b.cs	9474 <fwp_hof0.constprop.0+0x10c4>  // b.hs, b.nlast
    8f74:	8b000063 	add	x3, x3, x0
    8f78:	39400060 	ldrb	w0, [x3]
    8f7c:	7100041f 	cmp	w0, #0x1
    8f80:	540027a1 	b.ne	9474 <fwp_hof0.constprop.0+0x10c4>  // b.any
    8f84:	b90033e0 	str	w0, [sp, #48]
    8f88:	eb04005f 	cmp	x2, x4
    8f8c:	9a849044 	csel	x4, x2, x4, ls	// ls = plast
    8f90:	91002398 	add	x24, x28, #0x8
    8f94:	b40071e4 	cbz	x4, 9dd0 <fwp_hof0.constprop.0+0x1a20>
    8f98:	d37df087 	lsl	x7, x4, #3
    8f9c:	aa1503e2 	mov	x2, x21
    8fa0:	910022c0 	add	x0, x22, #0x8
    8fa4:	d2800001 	mov	x1, #0x0                   	// #0
    8fa8:	1400000a 	b	8fd0 <fwp_hof0.constprop.0+0xc20>
    8fac:	fc6168c1 	ldr	d1, [x6, x1]
    8fb0:	fd400440 	ldr	d0, [x2, #8]
    8fb4:	1e613800 	fsub	d0, d0, d1
    8fb8:	fc216b00 	str	d0, [x24, x1]
    8fbc:	91002021 	add	x1, x1, #0x8
    8fc0:	f9400842 	ldr	x2, [x2, #16]
    8fc4:	eb07003f 	cmp	x1, x7
    8fc8:	540001a0 	b.eq	8ffc <fwp_hof0.constprop.0+0xc4c>  // b.none
    8fcc:	f9400385 	ldr	x5, [x28]
    8fd0:	aa0003e6 	mov	x6, x0
    8fd4:	b6fffec5 	tbz	x5, #63, 8fac <fwp_hof0.constprop.0+0xbfc>
    8fd8:	f9400ac6 	ldr	x6, [x22, #16]
    8fdc:	fd400440 	ldr	d0, [x2, #8]
    8fe0:	fc6168c1 	ldr	d1, [x6, x1]
    8fe4:	1e613800 	fsub	d0, d0, d1
    8fe8:	fc216b00 	str	d0, [x24, x1]
    8fec:	91002021 	add	x1, x1, #0x8
    8ff0:	f9400842 	ldr	x2, [x2, #16]
    8ff4:	eb07003f 	cmp	x1, x7
    8ff8:	54fffea1 	b.ne	8fcc <fwp_hof0.constprop.0+0xc1c>  // b.any
    8ffc:	b4007275 	cbz	x21, 9e48 <fwp_hof0.constprop.0+0x1a98>
    9000:	9118c280 	add	x0, x20, #0x630
    9004:	aa1503e7 	mov	x7, x21
    9008:	d2800017 	mov	x23, #0x0                   	// #0
    900c:	f949ec09 	ldr	x9, [x0, #5080]
    9010:	f949d80a 	ldr	x10, [x0, #5040]
    9014:	f949fc08 	ldr	x8, [x0, #5112]
    9018:	d370bd29 	lsl	x9, x9, #16
    901c:	14000006 	b	9034 <fwp_hof0.constprop.0+0xc84>
    9020:	f94008e7 	ldr	x7, [x7, #16]
    9024:	910006f7 	add	x23, x23, #0x1
    9028:	f10000ff 	cmp	x7, #0x0
    902c:	fa571080 	ccmp	x4, x23, #0x0, ne	// ne = any
    9030:	54003289 	b.ls	9680 <fwp_hof0.constprop.0+0x12d0>  // b.plast
    9034:	cb0a00e0 	sub	x0, x7, x10
    9038:	eb09001f 	cmp	x0, x9
    903c:	540002c2 	b.cs	9094 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    9040:	d350fc01 	lsr	x1, x0, #16
    9044:	8b010821 	add	x1, x1, x1, lsl #2
    9048:	d37df021 	lsl	x1, x1, #3
    904c:	8b010106 	add	x6, x8, x1
    9050:	f94010c2 	ldr	x2, [x6, #32]
    9054:	b4000202 	cbz	x2, 9094 <fwp_hof0.constprop.0+0xce4>
    9058:	38616901 	ldrb	w1, [x8, x1]
    905c:	7100083f 	cmp	w1, #0x2
    9060:	54000e00 	b.eq	9220 <fwp_hof0.constprop.0+0xe70>  // b.none
    9064:	7100043f 	cmp	w1, #0x1
    9068:	54000161 	b.ne	9094 <fwp_hof0.constprop.0+0xce4>  // b.any
    906c:	294304cb 	ldp	w11, w1, [x6, #24]
    9070:	92403c00 	and	x0, x0, #0xffff
    9074:	9b0b7c00 	mul	x0, x0, x11
    9078:	d360fc00 	lsr	x0, x0, #32
    907c:	eb01001f 	cmp	x0, x1
    9080:	540000a2 	b.cs	9094 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    9084:	8b000042 	add	x2, x2, x0
    9088:	39400040 	ldrb	w0, [x2]
    908c:	7100041f 	cmp	w0, #0x1
    9090:	54fffc80 	b.eq	9020 <fwp_hof0.constprop.0+0xc70>  // b.none
    9094:	eb0402ff 	cmp	x23, x4
    9098:	54000cc2 	b.cs	9230 <fwp_hof0.constprop.0+0xe80>  // b.hs, b.nlast
    909c:	aa0403f9 	mov	x25, x4
    90a0:	d100231a 	sub	x26, x24, #0x8
    90a4:	910323f3 	add	x19, sp, #0xc8
    90a8:	9118c29b 	add	x27, x20, #0x630
    90ac:	d280001c 	mov	x28, #0x0                   	// #0
    90b0:	14000012 	b	90f8 <fwp_hof0.constprop.0+0xd48>
    90b4:	7100045f 	cmp	w2, #0x1
    90b8:	540001a1 	b.ne	90ec <fwp_hof0.constprop.0+0xd3c>  // b.any
    90bc:	29430909 	ldp	w9, w2, [x8, #24]
    90c0:	92403c21 	and	x1, x1, #0xffff
    90c4:	9b097c21 	mul	x1, x1, x9
    90c8:	d360fc21 	lsr	x1, x1, #32
    90cc:	eb02003f 	cmp	x1, x2
    90d0:	540000e2 	b.cs	90ec <fwp_hof0.constprop.0+0xd3c>  // b.hs, b.nlast
    90d4:	8b010000 	add	x0, x0, x1
    90d8:	39400001 	ldrb	w1, [x0]
    90dc:	7103fc3f 	cmp	w1, #0xff
    90e0:	54002fe0 	b.eq	96dc <fwp_hof0.constprop.0+0x132c>  // b.none
    90e4:	52800021 	mov	w1, #0x1                   	// #1
    90e8:	39000001 	strb	w1, [x0]
    90ec:	d1000739 	sub	x25, x25, #0x1
    90f0:	eb1902ff 	cmp	x23, x25
    90f4:	54000362 	b.cs	9160 <fwp_hof0.constprop.0+0xdb0>  // b.hs, b.nlast
    90f8:	f8797b42 	ldr	x2, [x26, x25, lsl #3]
    90fc:	aa1303e1 	mov	x1, x19
    9100:	52800020 	mov	w0, #0x1                   	// #1
    9104:	a90cf3e2 	stp	x2, x28, [sp, #200]
    9108:	97fff063 	bl	5294 <fwp_data.part.0.constprop.0>
    910c:	aa0003fc 	mov	x28, x0
    9110:	f949db61 	ldr	x1, [x27, #5040]
    9114:	f949ef60 	ldr	x0, [x27, #5080]
    9118:	cb010381 	sub	x1, x28, x1
    911c:	eb00403f 	cmp	x1, x0, lsl #16
    9120:	54fffe62 	b.cs	90ec <fwp_hof0.constprop.0+0xd3c>  // b.hs, b.nlast
    9124:	d350fc20 	lsr	x0, x1, #16
    9128:	f949ff69 	ldr	x9, [x27, #5112]
    912c:	8b000800 	add	x0, x0, x0, lsl #2
    9130:	d37df002 	lsl	x2, x0, #3
    9134:	8b020128 	add	x8, x9, x2
    9138:	f9401100 	ldr	x0, [x8, #32]
    913c:	b4fffd80 	cbz	x0, 90ec <fwp_hof0.constprop.0+0xd3c>
    9140:	38626922 	ldrb	w2, [x9, x2]
    9144:	7100085f 	cmp	w2, #0x2
    9148:	54fffb61 	b.ne	90b4 <fwp_hof0.constprop.0+0xd04>  // b.any
    914c:	72003c3f 	tst	w1, #0xffff
    9150:	54fffc40 	b.eq	90d8 <fwp_hof0.constprop.0+0xd28>  // b.none
    9154:	d1000739 	sub	x25, x25, #0x1
    9158:	eb1902ff 	cmp	x23, x25
    915c:	54fffce3 	b.cc	90f8 <fwp_hof0.constprop.0+0xd48>  // b.lo, b.ul, b.last
    9160:	b50006b7 	cbnz	x23, 9234 <fwp_hof0.constprop.0+0xe84>
    9164:	b94033e0 	ldr	w0, [sp, #48]
    9168:	d2800004 	mov	x4, #0x0                   	// #0
    916c:	7100001f 	cmp	w0, #0x0
    9170:	d2800020 	mov	x0, #0x1                   	// #1
    9174:	9a9f0318 	csel	x24, x24, xzr, eq	// eq = none
    9178:	b40007c4 	cbz	x4, 9270 <fwp_hof0.constprop.0+0xec0>
    917c:	d1000497 	sub	x23, x4, #0x1
    9180:	2a0003fa 	mov	w26, w0
    9184:	9118c29b 	add	x27, x20, #0x630
    9188:	f8777b02 	ldr	x2, [x24, x23, lsl #3]
    918c:	aa1303e1 	mov	x1, x19
    9190:	52800020 	mov	w0, #0x1                   	// #1
    9194:	a90cf3e2 	stp	x2, x28, [sp, #200]
    9198:	97fff03f 	bl	5294 <fwp_data.part.0.constprop.0>
    919c:	aa0003fc 	mov	x28, x0
    91a0:	f949db61 	ldr	x1, [x27, #5040]
    91a4:	f949ef60 	ldr	x0, [x27, #5080]
    91a8:	cb010381 	sub	x1, x28, x1
    91ac:	eb00403f 	cmp	x1, x0, lsl #16
    91b0:	54000302 	b.cs	9210 <fwp_hof0.constprop.0+0xe60>  // b.hs, b.nlast
    91b4:	d350fc22 	lsr	x2, x1, #16
    91b8:	f949ff67 	ldr	x7, [x27, #5112]
    91bc:	8b020842 	add	x2, x2, x2, lsl #2
    91c0:	d37df042 	lsl	x2, x2, #3
    91c4:	8b0200e5 	add	x5, x7, x2
    91c8:	f94010b9 	ldr	x25, [x5, #32]
    91cc:	b4000239 	cbz	x25, 9210 <fwp_hof0.constprop.0+0xe60>
    91d0:	386268e2 	ldrb	w2, [x7, x2]
    91d4:	7100085f 	cmp	w2, #0x2
    91d8:	54001440 	b.eq	9460 <fwp_hof0.constprop.0+0x10b0>  // b.none
    91dc:	7100045f 	cmp	w2, #0x1
    91e0:	54000181 	b.ne	9210 <fwp_hof0.constprop.0+0xe60>  // b.any
    91e4:	294308a7 	ldp	w7, w2, [x5, #24]
    91e8:	92403c21 	and	x1, x1, #0xffff
    91ec:	9b077c21 	mul	x1, x1, x7
    91f0:	d360fc21 	lsr	x1, x1, #32
    91f4:	eb02003f 	cmp	x1, x2
    91f8:	540000c2 	b.cs	9210 <fwp_hof0.constprop.0+0xe60>  // b.hs, b.nlast
    91fc:	8b010339 	add	x25, x25, x1
    9200:	39400321 	ldrb	w1, [x25]
    9204:	7103fc3f 	cmp	w1, #0xff
    9208:	54001260 	b.eq	9454 <fwp_hof0.constprop.0+0x10a4>  // b.none
    920c:	3900033a 	strb	w26, [x25]
    9210:	d10006f7 	sub	x23, x23, #0x1
    9214:	b10006ff 	cmn	x23, #0x1
    9218:	54fffb81 	b.ne	9188 <fwp_hof0.constprop.0+0xdd8>  // b.any
    921c:	14000015 	b	9270 <fwp_hof0.constprop.0+0xec0>
    9220:	72003c1f 	tst	w0, #0xffff
    9224:	54fff320 	b.eq	9088 <fwp_hof0.constprop.0+0xcd8>  // b.none
    9228:	eb0402ff 	cmp	x23, x4
    922c:	54fff383 	b.cc	909c <fwp_hof0.constprop.0+0xcec>  // b.lo, b.ul, b.last
    9230:	d280001c 	mov	x28, #0x0                   	// #0
    9234:	8b170f05 	add	x5, x24, x23, lsl #3
    9238:	aa1803e1 	mov	x1, x24
    923c:	aa1503e0 	mov	x0, x21
    9240:	f8408422 	ldr	x2, [x1], #8
    9244:	f9000402 	str	x2, [x0, #8]
    9248:	aa0003e2 	mov	x2, x0
    924c:	f9400800 	ldr	x0, [x0, #16]
    9250:	eb05003f 	cmp	x1, x5
    9254:	54ffff61 	b.ne	9240 <fwp_hof0.constprop.0+0xe90>  // b.any
    9258:	b94033e1 	ldr	w1, [sp, #48]
    925c:	f900085c 	str	x28, [x2, #16]
    9260:	aa1503fc 	mov	x28, x21
    9264:	aa0003f5 	mov	x21, x0
    9268:	34000041 	cbz	w1, 9270 <fwp_hof0.constprop.0+0xec0>
    926c:	d2800018 	mov	x24, #0x0                   	// #0
    9270:	9118c293 	add	x19, x20, #0x630
    9274:	aa1803e0 	mov	x0, x24
    9278:	97ffee86 	bl	4c90 <fwp_mem_free>
    927c:	f949ee62 	ldr	x2, [x19, #5080]
    9280:	f949da61 	ldr	x1, [x19, #5040]
    9284:	d370bc42 	lsl	x2, x2, #16
    9288:	cb0102c3 	sub	x3, x22, x1
    928c:	eb02007f 	cmp	x3, x2
    9290:	54000402 	b.cs	9310 <fwp_hof0.constprop.0+0xf60>  // b.hs, b.nlast
    9294:	d350fc60 	lsr	x0, x3, #16
    9298:	f949fe65 	ldr	x5, [x19, #5112]
    929c:	8b000800 	add	x0, x0, x0, lsl #2
    92a0:	d37df000 	lsl	x0, x0, #3
    92a4:	8b0000a2 	add	x2, x5, x0
    92a8:	f9401057 	ldr	x23, [x2, #32]
    92ac:	b4000cb7 	cbz	x23, 9440 <fwp_hof0.constprop.0+0x1090>
    92b0:	386068a1 	ldrb	w1, [x5, x0]
    92b4:	7100083f 	cmp	w1, #0x2
    92b8:	54003240 	b.eq	9900 <fwp_hof0.constprop.0+0x1550>  // b.none
    92bc:	7100043f 	cmp	w1, #0x1
    92c0:	54000c01 	b.ne	9440 <fwp_hof0.constprop.0+0x1090>  // b.any
    92c4:	29430844 	ldp	w4, w2, [x2, #24]
    92c8:	92403c61 	and	x1, x3, #0xffff
    92cc:	9b047c21 	mul	x1, x1, x4
    92d0:	d360fc21 	lsr	x1, x1, #32
    92d4:	eb02003f 	cmp	x1, x2
    92d8:	54000b42 	b.cs	9440 <fwp_hof0.constprop.0+0x1090>  // b.hs, b.nlast
    92dc:	8b0102f7 	add	x23, x23, x1
    92e0:	394002e1 	ldrb	w1, [x23]
    92e4:	34000ae1 	cbz	w1, 9440 <fwp_hof0.constprop.0+0x1090>
    92e8:	7100043f 	cmp	w1, #0x1
    92ec:	540006a0 	b.eq	93c0 <fwp_hof0.constprop.0+0x1010>  // b.none
    92f0:	7103fc3f 	cmp	w1, #0xff
    92f4:	540051c0 	b.eq	9d2c <fwp_hof0.constprop.0+0x197c>  // b.none
    92f8:	9118c280 	add	x0, x20, #0x630
    92fc:	51000421 	sub	w1, w1, #0x1
    9300:	390002e1 	strb	w1, [x23]
    9304:	f949ec02 	ldr	x2, [x0, #5080]
    9308:	f949d801 	ldr	x1, [x0, #5040]
    930c:	d370bc42 	lsl	x2, x2, #16
    9310:	cb0102a1 	sub	x1, x21, x1
    9314:	eb02003f 	cmp	x1, x2
    9318:	540003c2 	b.cs	9390 <fwp_hof0.constprop.0+0xfe0>  // b.hs, b.nlast
    931c:	9118c296 	add	x22, x20, #0x630
    9320:	d350fc20 	lsr	x0, x1, #16
    9324:	f949fec3 	ldr	x3, [x22, #5112]
    9328:	8b000800 	add	x0, x0, x0, lsl #2
    932c:	d37df000 	lsl	x0, x0, #3
    9330:	8b000062 	add	x2, x3, x0
    9334:	f9401053 	ldr	x19, [x2, #32]
    9338:	b40002d3 	cbz	x19, 9390 <fwp_hof0.constprop.0+0xfe0>
    933c:	38606860 	ldrb	w0, [x3, x0]
    9340:	7100081f 	cmp	w0, #0x2
    9344:	54003260 	b.eq	9990 <fwp_hof0.constprop.0+0x15e0>  // b.none
    9348:	7100041f 	cmp	w0, #0x1
    934c:	54000221 	b.ne	9390 <fwp_hof0.constprop.0+0xfe0>  // b.any
    9350:	29430044 	ldp	w4, w0, [x2, #24]
    9354:	92403c21 	and	x1, x1, #0xffff
    9358:	9b047c21 	mul	x1, x1, x4
    935c:	d360fc21 	lsr	x1, x1, #32
    9360:	eb00003f 	cmp	x1, x0
    9364:	54000162 	b.cs	9390 <fwp_hof0.constprop.0+0xfe0>  // b.hs, b.nlast
    9368:	8b010273 	add	x19, x19, x1
    936c:	39400260 	ldrb	w0, [x19]
    9370:	34000100 	cbz	w0, 9390 <fwp_hof0.constprop.0+0xfe0>
    9374:	7100041f 	cmp	w0, #0x1
    9378:	54003920 	b.eq	9a9c <fwp_hof0.constprop.0+0x16ec>  // b.none
    937c:	7103fc1f 	cmp	w0, #0xff
    9380:	54004aa0 	b.eq	9cd4 <fwp_hof0.constprop.0+0x1924>  // b.none
    9384:	51000400 	sub	w0, w0, #0x1
    9388:	39000260 	strb	w0, [x19]
    938c:	d503201f 	nop
    9390:	f94007e0 	ldr	x0, [sp, #8]
    9394:	b4001ac0 	cbz	x0, 96ec <fwp_hof0.constprop.0+0x133c>
    9398:	f94007e0 	ldr	x0, [sp, #8]
    939c:	f100041b 	subs	x27, x0, #0x1
    93a0:	f90007fb 	str	x27, [sp, #8]
    93a4:	54005e06 	b.vs	9f64 <fwp_hof0.constprop.0+0x1bb4>
    93a8:	9118c280 	add	x0, x20, #0x630
    93ac:	aa1c03f5 	mov	x21, x28
    93b0:	f949ec03 	ldr	x3, [x0, #5080]
    93b4:	f949d801 	ldr	x1, [x0, #5040]
    93b8:	d370bc63 	lsl	x3, x3, #16
    93bc:	17fffc49 	b	84e0 <fwp_hof0.constprop.0+0x130>
    93c0:	f94002c3 	ldr	x3, [x22]
    93c4:	aa1603e0 	mov	x0, x22
    93c8:	f949ee62 	ldr	x2, [x19, #5080]
    93cc:	f949da61 	ldr	x1, [x19, #5040]
    93d0:	d370bc42 	lsl	x2, x2, #16
    93d4:	cb0102c7 	sub	x7, x22, x1
    93d8:	b7f82e23 	tbnz	x3, #63, 999c <fwp_hof0.constprop.0+0x15ec>
    93dc:	eb07005f 	cmp	x2, x7
    93e0:	54fff989 	b.ls	9310 <fwp_hof0.constprop.0+0xf60>  // b.plast
    93e4:	d350fce3 	lsr	x3, x7, #16
    93e8:	8b030863 	add	x3, x3, x3, lsl #2
    93ec:	d37df063 	lsl	x3, x3, #3
    93f0:	8b0300a6 	add	x6, x5, x3
    93f4:	f94010c4 	ldr	x4, [x6, #32]
    93f8:	b4fff8c4 	cbz	x4, 9310 <fwp_hof0.constprop.0+0xf60>
    93fc:	386368a3 	ldrb	w3, [x5, x3]
    9400:	7100087f 	cmp	w3, #0x2
    9404:	540039c0 	b.eq	9b3c <fwp_hof0.constprop.0+0x178c>  // b.none
    9408:	7100047f 	cmp	w3, #0x1
    940c:	54fff821 	b.ne	9310 <fwp_hof0.constprop.0+0xf60>  // b.any
    9410:	29430cc5 	ldp	w5, w3, [x6, #24]
    9414:	92403ce0 	and	x0, x7, #0xffff
    9418:	9b057c00 	mul	x0, x0, x5
    941c:	d360fc00 	lsr	x0, x0, #32
    9420:	eb03001f 	cmp	x0, x3
    9424:	54fff762 	b.cs	9310 <fwp_hof0.constprop.0+0xf60>  // b.hs, b.nlast
    9428:	8b000084 	add	x4, x4, x0
    942c:	39400080 	ldrb	w0, [x4]
    9430:	7100041f 	cmp	w0, #0x1
    9434:	54fff6e1 	b.ne	9310 <fwp_hof0.constprop.0+0xf60>  // b.any
    9438:	aa1603e0 	mov	x0, x22
    943c:	97ffee15 	bl	4c90 <fwp_mem_free>
    9440:	9118c280 	add	x0, x20, #0x630
    9444:	f949ec02 	ldr	x2, [x0, #5080]
    9448:	f949d801 	ldr	x1, [x0, #5040]
    944c:	d370bc42 	lsl	x2, x2, #16
    9450:	17ffffb0 	b	9310 <fwp_hof0.constprop.0+0xf60>
    9454:	aa1903e0 	mov	x0, x25
    9458:	97ffed6e 	bl	4a10 <fwp_rc_forget_slot>
    945c:	17ffff6c 	b	920c <fwp_hof0.constprop.0+0xe5c>
    9460:	72003c3f 	tst	w1, #0xffff
    9464:	54ffed61 	b.ne	9210 <fwp_hof0.constprop.0+0xe60>  // b.any
    9468:	17ffff66 	b	9200 <fwp_hof0.constprop.0+0xe50>
    946c:	72003c1f 	tst	w0, #0xffff
    9470:	54ffd840 	b.eq	8f78 <fwp_hof0.constprop.0+0xbc8>  // b.none
    9474:	b4001295 	cbz	x21, 96c4 <fwp_hof0.constprop.0+0x1314>
    9478:	aa1503f3 	mov	x19, x21
    947c:	d2800017 	mov	x23, #0x0                   	// #0
    9480:	f9400a73 	ldr	x19, [x19, #16]
    9484:	aa1703e0 	mov	x0, x23
    9488:	910006f7 	add	x23, x23, #0x1
    948c:	b5ffffb3 	cbnz	x19, 9480 <fwp_hof0.constprop.0+0x10d0>
    9490:	f9001be4 	str	x4, [sp, #48]
    9494:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9498:	eb0102ff 	cmp	x23, x1
    949c:	54005248 	b.hi	9ee4 <fwp_hof0.constprop.0+0x1b34>  // b.pmore
    94a0:	91000800 	add	x0, x0, #0x2
    94a4:	52800041 	mov	w1, #0x2                   	// #2
    94a8:	d37df000 	lsl	x0, x0, #3
    94ac:	97ffef19 	bl	5110 <fwp_heap_alloc>
    94b0:	f9401be4 	ldr	x4, [sp, #48]
    94b4:	aa0003f8 	mov	x24, x0
    94b8:	aa1503e1 	mov	x1, x21
    94bc:	eb0402ff 	cmp	x23, x4
    94c0:	9a8492e4 	csel	x4, x23, x4, ls	// ls = plast
    94c4:	d503201f 	nop
    94c8:	f9400420 	ldr	x0, [x1, #8]
    94cc:	f8337b00 	str	x0, [x24, x19, lsl #3]
    94d0:	91000673 	add	x19, x19, #0x1
    94d4:	f9400821 	ldr	x1, [x1, #16]
    94d8:	b5ffff81 	cbnz	x1, 94c8 <fwp_hof0.constprop.0+0x1118>
    94dc:	b4000fc4 	cbz	x4, 96d4 <fwp_hof0.constprop.0+0x1324>
    94e0:	f9400385 	ldr	x5, [x28]
    94e4:	b90033ff 	str	wzr, [sp, #48]
    94e8:	17fffeac 	b	8f98 <fwp_hof0.constprop.0+0xbe8>
    94ec:	d53bd040 	mrs	x0, tpidr_el0
    94f0:	91400000 	add	x0, x0, #0x0, lsl #12
    94f4:	91004000 	add	x0, x0, #0x10
    94f8:	f9400000 	ldr	x0, [x0]
    94fc:	b4002920 	cbz	x0, 9a20 <fwp_hof0.constprop.0+0x1670>
    9500:	f94017e1 	ldr	x1, [sp, #40]
    9504:	97ffe8d8 	bl	3864 <fwp_closure_drop_push>
    9508:	b5ff8975 	cbnz	x21, 8634 <fwp_hof0.constprop.0+0x284>
    950c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9510:	91014013 	add	x19, x0, #0x50
    9514:	d2800017 	mov	x23, #0x0                   	// #0
    9518:	b943c660 	ldr	w0, [x19, #964]
    951c:	35ff8a80 	cbnz	w0, 866c <fwp_hof0.constprop.0+0x2bc>
    9520:	b0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0xb0>
    9524:	91074000 	add	x0, x0, #0x1d0
    9528:	94000f56 	bl	d280 <atexit>
    952c:	35ffc820 	cbnz	w0, 8e30 <fwp_hof0.constprop.0+0xa80>
    9530:	52800020 	mov	w0, #0x1                   	// #1
    9534:	b903c660 	str	w0, [x19, #964]
    9538:	f00000a0 	adrp	x0, 20000 <__data_start>
    953c:	91014000 	add	x0, x0, #0x50
    9540:	f9406c13 	ldr	x19, [x0, #216]
    9544:	f940b016 	ldr	x22, [x0, #352]
    9548:	eb1302df 	cmp	x22, x19
    954c:	54ff89cb 	b.lt	8684 <fwp_hof0.constprop.0+0x2d4>  // b.tstop
    9550:	eb16027f 	cmp	x19, x22
    9554:	54ff8b40 	b.eq	86bc <fwp_hof0.constprop.0+0x30c>  // b.none
    9558:	f00000a0 	adrp	x0, 20000 <__data_start>
    955c:	91014000 	add	x0, x0, #0x50
    9560:	8b1606d8 	add	x24, x22, x22, lsl #1
    9564:	f940441c 	ldr	x28, [x0, #136]
    9568:	8b180ad8 	add	x24, x22, x24, lsl #2
    956c:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9570:	911ac000 	add	x0, x0, #0x6b0
    9574:	8b180f98 	add	x24, x28, x24, lsl #3
    9578:	f900331f 	str	xzr, [x24, #96]
    957c:	97ffe52d 	bl	2a30 <getenv@plt>
    9580:	b5ff8fc0 	cbnz	x0, 8778 <fwp_hof0.constprop.0+0x3c8>
    9584:	f00000a0 	adrp	x0, 20000 <__data_start>
    9588:	91014000 	add	x0, x0, #0x50
    958c:	f9408c01 	ldr	x1, [x0, #280]
    9590:	b4ff8fe1 	cbz	x1, 878c <fwp_hof0.constprop.0+0x3dc>
    9594:	ad470402 	ldp	q2, q1, [x0, #224]
    9598:	91038001 	add	x1, x0, #0xe0
    959c:	4f000400 	movi	v0.4s, #0x0
    95a0:	f9008c1f 	str	xzr, [x0, #280]
    95a4:	ad010702 	stp	q2, q1, [x24, #32]
    95a8:	a9500002 	ldp	x2, x0, [x0, #256]
    95ac:	f9000f00 	str	x0, [x24, #24]
    95b0:	f9401820 	ldr	x0, [x1, #48]
    95b4:	f9002302 	str	x2, [x24, #64]
    95b8:	f9002700 	str	x0, [x24, #72]
    95bc:	ad000020 	stp	q0, q0, [x1]
    95c0:	3d800820 	str	q0, [x1, #32]
    95c4:	f900183f 	str	xzr, [x1, #48]
    95c8:	17fffc71 	b	878c <fwp_hof0.constprop.0+0x3dc>
    95cc:	72003c1f 	tst	w0, #0xffff
    95d0:	54ffbdc0 	b.eq	8d88 <fwp_hof0.constprop.0+0x9d8>  // b.none
    95d4:	d503201f 	nop
    95d8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    95dc:	eb0002ff 	cmp	x23, x0
    95e0:	54004b48 	b.hi	9f48 <fwp_hof0.constprop.0+0x1b98>  // b.pmore
    95e4:	910006e0 	add	x0, x23, #0x1
    95e8:	52800021 	mov	w1, #0x1                   	// #1
    95ec:	d37df000 	lsl	x0, x0, #3
    95f0:	97ffeec8 	bl	5110 <fwp_heap_alloc>
    95f4:	9118c282 	add	x2, x20, #0x630
    95f8:	f9000017 	str	x23, [x0]
    95fc:	aa0003fc 	mov	x28, x0
    9600:	aa0003f6 	mov	x22, x0
    9604:	f949d841 	ldr	x1, [x2, #5040]
    9608:	f949ec40 	ldr	x0, [x2, #5080]
    960c:	cb010381 	sub	x1, x28, x1
    9610:	eb00403f 	cmp	x1, x0, lsl #16
    9614:	54000322 	b.cs	9678 <fwp_hof0.constprop.0+0x12c8>  // b.hs, b.nlast
    9618:	d350fc20 	lsr	x0, x1, #16
    961c:	f949fc44 	ldr	x4, [x2, #5112]
    9620:	8b000800 	add	x0, x0, x0, lsl #2
    9624:	d37df002 	lsl	x2, x0, #3
    9628:	8b020083 	add	x3, x4, x2
    962c:	f9401078 	ldr	x24, [x3, #32]
    9630:	b4000258 	cbz	x24, 9678 <fwp_hof0.constprop.0+0x12c8>
    9634:	38626882 	ldrb	w2, [x4, x2]
    9638:	7100085f 	cmp	w2, #0x2
    963c:	540028c0 	b.eq	9b54 <fwp_hof0.constprop.0+0x17a4>  // b.none
    9640:	7100045f 	cmp	w2, #0x1
    9644:	540001a1 	b.ne	9678 <fwp_hof0.constprop.0+0x12c8>  // b.any
    9648:	29430864 	ldp	w4, w2, [x3, #24]
    964c:	92403c21 	and	x1, x1, #0xffff
    9650:	9b047c21 	mul	x1, x1, x4
    9654:	d360fc21 	lsr	x1, x1, #32
    9658:	eb02003f 	cmp	x1, x2
    965c:	540000e2 	b.cs	9678 <fwp_hof0.constprop.0+0x12c8>  // b.hs, b.nlast
    9660:	8b010318 	add	x24, x24, x1
    9664:	39400301 	ldrb	w1, [x24]
    9668:	7103fc3f 	cmp	w1, #0xff
    966c:	540027c0 	b.eq	9b64 <fwp_hof0.constprop.0+0x17b4>  // b.none
    9670:	52800021 	mov	w1, #0x1                   	// #1
    9674:	39000301 	strb	w1, [x24]
    9678:	aa1303e0 	mov	x0, x19
    967c:	17fffdc9 	b	8da0 <fwp_hof0.constprop.0+0x9f0>
    9680:	eb17009f 	cmp	x4, x23
    9684:	54ffd0c8 	b.hi	909c <fwp_hof0.constprop.0+0xcec>  // b.pmore
    9688:	17fffeea 	b	9230 <fwp_hof0.constprop.0+0xe80>
    968c:	52800041 	mov	w1, #0x2                   	// #2
    9690:	d2800100 	mov	x0, #0x8                   	// #8
    9694:	97ffee9f 	bl	5110 <fwp_heap_alloc>
    9698:	aa0003f8 	mov	x24, x0
    969c:	9118c280 	add	x0, x20, #0x630
    96a0:	aa1803fc 	mov	x28, x24
    96a4:	f900031f 	str	xzr, [x24]
    96a8:	f949d801 	ldr	x1, [x0, #5040]
    96ac:	f949ec00 	ldr	x0, [x0, #5080]
    96b0:	cb010301 	sub	x1, x24, x1
    96b4:	eb00403f 	cmp	x1, x0, lsl #16
    96b8:	54001182 	b.cs	98e8 <fwp_hof0.constprop.0+0x1538>  // b.hs, b.nlast
    96bc:	d2800016 	mov	x22, #0x0                   	// #0
    96c0:	17fffc78 	b	88a0 <fwp_hof0.constprop.0+0x4f0>
    96c4:	52800041 	mov	w1, #0x2                   	// #2
    96c8:	d2800100 	mov	x0, #0x8                   	// #8
    96cc:	97ffee91 	bl	5110 <fwp_heap_alloc>
    96d0:	aa0003f8 	mov	x24, x0
    96d4:	d280001c 	mov	x28, #0x0                   	// #0
    96d8:	17fffee6 	b	9270 <fwp_hof0.constprop.0+0xec0>
    96dc:	f9001fe0 	str	x0, [sp, #56]
    96e0:	97ffeccc 	bl	4a10 <fwp_rc_forget_slot>
    96e4:	f9401fe0 	ldr	x0, [sp, #56]
    96e8:	17fffe7f 	b	90e4 <fwp_hof0.constprop.0+0xd34>
    96ec:	f9400be0 	ldr	x0, [sp, #16]
    96f0:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe9b0>
    96f4:	910ac042 	add	x2, x2, #0x2b0
    96f8:	aa1c03e1 	mov	x1, x28
    96fc:	91014042 	add	x2, x2, #0x50
    9700:	52800023 	mov	w3, #0x1                   	// #1
    9704:	a9097fff 	stp	xzr, xzr, [sp, #144]
    9708:	f90053ff 	str	xzr, [sp, #160]
    970c:	97fff72d 	bl	73c0 <fwp_write>
    9710:	a9495bf5 	ldp	x21, x22, [sp, #144]
    9714:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9718:	910bc000 	add	x0, x0, #0x2f0
    971c:	f10002bf 	cmp	x21, #0x0
    9720:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    9724:	b1002adf 	cmn	x22, #0xa
    9728:	54004168 	b.hi	9f54 <fwp_hof0.constprop.0+0x1ba4>  // b.pmore
    972c:	910026c0 	add	x0, x22, #0x9
    9730:	52800021 	mov	w1, #0x1                   	// #1
    9734:	97ffee77 	bl	5110 <fwp_heap_alloc>
    9738:	aa0003f7 	mov	x23, x0
    973c:	aa0003f3 	mov	x19, x0
    9740:	aa1603e2 	mov	x2, x22
    9744:	aa1503e1 	mov	x1, x21
    9748:	f80086f6 	str	x22, [x23], #8
    974c:	8b160276 	add	x22, x19, x22
    9750:	aa1703e0 	mov	x0, x23
    9754:	97ffe3e7 	bl	26f0 <memcpy@plt>
    9758:	390022df 	strb	wzr, [x22, #8]
    975c:	f9404be0 	ldr	x0, [sp, #144]
    9760:	97ffe480 	bl	2960 <free@plt>
    9764:	9118c281 	add	x1, x20, #0x630
    9768:	f949d822 	ldr	x2, [x1, #5040]
    976c:	f949ec20 	ldr	x0, [x1, #5080]
    9770:	cb020262 	sub	x2, x19, x2
    9774:	eb00405f 	cmp	x2, x0, lsl #16
    9778:	54000322 	b.cs	97dc <fwp_hof0.constprop.0+0x142c>  // b.hs, b.nlast
    977c:	d350fc40 	lsr	x0, x2, #16
    9780:	f949fc23 	ldr	x3, [x1, #5112]
    9784:	8b000800 	add	x0, x0, x0, lsl #2
    9788:	d37df001 	lsl	x1, x0, #3
    978c:	8b010060 	add	x0, x3, x1
    9790:	f9401015 	ldr	x21, [x0, #32]
    9794:	b4000255 	cbz	x21, 97dc <fwp_hof0.constprop.0+0x142c>
    9798:	38616861 	ldrb	w1, [x3, x1]
    979c:	7100083f 	cmp	w1, #0x2
    97a0:	54003080 	b.eq	9db0 <fwp_hof0.constprop.0+0x1a00>  // b.none
    97a4:	7100043f 	cmp	w1, #0x1
    97a8:	540001a1 	b.ne	97dc <fwp_hof0.constprop.0+0x142c>  // b.any
    97ac:	29430003 	ldp	w3, w0, [x0, #24]
    97b0:	92403c41 	and	x1, x2, #0xffff
    97b4:	9b037c21 	mul	x1, x1, x3
    97b8:	d360fc21 	lsr	x1, x1, #32
    97bc:	eb00003f 	cmp	x1, x0
    97c0:	540000e2 	b.cs	97dc <fwp_hof0.constprop.0+0x142c>  // b.hs, b.nlast
    97c4:	8b0102b5 	add	x21, x21, x1
    97c8:	394002a0 	ldrb	w0, [x21]
    97cc:	7103fc1f 	cmp	w0, #0xff
    97d0:	54002fa0 	b.eq	9dc4 <fwp_hof0.constprop.0+0x1a14>  // b.none
    97d4:	52800020 	mov	w0, #0x1                   	// #1
    97d8:	390002a0 	strb	w0, [x21]
    97dc:	aa1c03e0 	mov	x0, x28
    97e0:	97fff134 	bl	5cb0 <fwp_drop0>
    97e4:	f00000a0 	adrp	x0, 20000 <__data_start>
    97e8:	91014015 	add	x21, x0, #0x50
    97ec:	f9400262 	ldr	x2, [x19]
    97f0:	d2800021 	mov	x1, #0x1                   	// #1
    97f4:	f9404aa3 	ldr	x3, [x21, #144]
    97f8:	aa1703e0 	mov	x0, x23
    97fc:	97ffe469 	bl	29a0 <fwrite@plt>
    9800:	f9404aa1 	ldr	x1, [x21, #144]
    9804:	52800140 	mov	w0, #0xa                   	// #10
    9808:	97ffe3ee 	bl	27c0 <fputc@plt>
    980c:	9118c281 	add	x1, x20, #0x630
    9810:	f949d822 	ldr	x2, [x1, #5040]
    9814:	f949ec20 	ldr	x0, [x1, #5080]
    9818:	cb020262 	sub	x2, x19, x2
    981c:	eb00405f 	cmp	x2, x0, lsl #16
    9820:	54000382 	b.cs	9890 <fwp_hof0.constprop.0+0x14e0>  // b.hs, b.nlast
    9824:	d350fc40 	lsr	x0, x2, #16
    9828:	f949fc23 	ldr	x3, [x1, #5112]
    982c:	8b000800 	add	x0, x0, x0, lsl #2
    9830:	d37df001 	lsl	x1, x0, #3
    9834:	8b010060 	add	x0, x3, x1
    9838:	f9401015 	ldr	x21, [x0, #32]
    983c:	b40002b5 	cbz	x21, 9890 <fwp_hof0.constprop.0+0x14e0>
    9840:	38616861 	ldrb	w1, [x3, x1]
    9844:	7100083f 	cmp	w1, #0x2
    9848:	54002a60 	b.eq	9d94 <fwp_hof0.constprop.0+0x19e4>  // b.none
    984c:	7100043f 	cmp	w1, #0x1
    9850:	54000201 	b.ne	9890 <fwp_hof0.constprop.0+0x14e0>  // b.any
    9854:	29430003 	ldp	w3, w0, [x0, #24]
    9858:	92403c41 	and	x1, x2, #0xffff
    985c:	9b037c21 	mul	x1, x1, x3
    9860:	d360fc21 	lsr	x1, x1, #32
    9864:	eb00003f 	cmp	x1, x0
    9868:	54000142 	b.cs	9890 <fwp_hof0.constprop.0+0x14e0>  // b.hs, b.nlast
    986c:	8b0102b5 	add	x21, x21, x1
    9870:	394002a0 	ldrb	w0, [x21]
    9874:	340000e0 	cbz	w0, 9890 <fwp_hof0.constprop.0+0x14e0>
    9878:	7100041f 	cmp	w0, #0x1
    987c:	54001da0 	b.eq	9c30 <fwp_hof0.constprop.0+0x1880>  // b.none
    9880:	7103fc1f 	cmp	w0, #0xff
    9884:	54002fe0 	b.eq	9e80 <fwp_hof0.constprop.0+0x1ad0>  // b.none
    9888:	51000400 	sub	w0, w0, #0x1
    988c:	390002a0 	strb	w0, [x21]
    9890:	f94027e0 	ldr	x0, [sp, #72]
    9894:	f9400800 	ldr	x0, [x0, #16]
    9898:	f90027e0 	str	x0, [sp, #72]
    989c:	b5ff5c20 	cbnz	x0, 8420 <fwp_hof0.constprop.0+0x70>
    98a0:	a94f53f3 	ldp	x19, x20, [sp, #240]
    98a4:	a9505bf5 	ldp	x21, x22, [sp, #256]
    98a8:	a95163f7 	ldp	x23, x24, [sp, #272]
    98ac:	a9526bf9 	ldp	x25, x26, [sp, #288]
    98b0:	a95373fb 	ldp	x27, x28, [sp, #304]
    98b4:	fd40a3e8 	ldr	d8, [sp, #320]
    98b8:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    98bc:	f947f400 	ldr	x0, [x0, #4072]
    98c0:	f9406fe2 	ldr	x2, [sp, #216]
    98c4:	f9400001 	ldr	x1, [x0]
    98c8:	eb010042 	subs	x2, x2, x1
    98cc:	d2800001 	mov	x1, #0x0                   	// #0
    98d0:	54003101 	b.ne	9ef0 <fwp_hof0.constprop.0+0x1b40>  // b.any
    98d4:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    98d8:	d2800000 	mov	x0, #0x0                   	// #0
    98dc:	910543ff 	add	sp, sp, #0x150
    98e0:	d65f03c0 	ret
    98e4:	b5ff8136 	cbnz	x22, 8908 <fwp_hof0.constprop.0+0x558>
    98e8:	9280001b 	mov	x27, #0xffffffffffffffff    	// #-1
    98ec:	f900031f 	str	xzr, [x24]
    98f0:	17fffc39 	b	89d4 <fwp_hof0.constprop.0+0x624>
    98f4:	72003c3f 	tst	w1, #0xffff
    98f8:	54ff8b01 	b.ne	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.any
    98fc:	17fffc4f 	b	8a38 <fwp_hof0.constprop.0+0x688>
    9900:	72003c7f 	tst	w3, #0xffff
    9904:	54ffd9e1 	b.ne	9440 <fwp_hof0.constprop.0+0x1090>  // b.any
    9908:	17fffe76 	b	92e0 <fwp_hof0.constprop.0+0xf30>
    990c:	f940079c 	ldr	x28, [x28, #8]
    9910:	eb02007f 	cmp	x3, x2
    9914:	54000369 	b.ls	9980 <fwp_hof0.constprop.0+0x15d0>  // b.plast
    9918:	d350fc46 	lsr	x6, x2, #16
    991c:	8b0608c6 	add	x6, x6, x6, lsl #2
    9920:	d37df0c6 	lsl	x6, x6, #3
    9924:	8b0600a8 	add	x8, x5, x6
    9928:	f9401107 	ldr	x7, [x8, #32]
    992c:	b40002a7 	cbz	x7, 9980 <fwp_hof0.constprop.0+0x15d0>
    9930:	386668a5 	ldrb	w5, [x5, x6]
    9934:	710008bf 	cmp	w5, #0x2
    9938:	54001760 	b.eq	9c24 <fwp_hof0.constprop.0+0x1874>  // b.none
    993c:	710004bf 	cmp	w5, #0x1
    9940:	54000201 	b.ne	9980 <fwp_hof0.constprop.0+0x15d0>  // b.any
    9944:	29431506 	ldp	w6, w5, [x8, #24]
    9948:	92403c42 	and	x2, x2, #0xffff
    994c:	9b067c42 	mul	x2, x2, x6
    9950:	d360fc42 	lsr	x2, x2, #32
    9954:	eb05005f 	cmp	x2, x5
    9958:	54000142 	b.cs	9980 <fwp_hof0.constprop.0+0x15d0>  // b.hs, b.nlast
    995c:	8b0200e7 	add	x7, x7, x2
    9960:	394000e2 	ldrb	w2, [x7]
    9964:	7100045f 	cmp	w2, #0x1
    9968:	540000c1 	b.ne	9980 <fwp_hof0.constprop.0+0x15d0>  // b.any
    996c:	97ffecc9 	bl	4c90 <fwp_mem_free>
    9970:	9118c280 	add	x0, x20, #0x630
    9974:	f949ec03 	ldr	x3, [x0, #5080]
    9978:	f949d801 	ldr	x1, [x0, #5040]
    997c:	d370bc63 	lsl	x3, x3, #16
    9980:	cb010381 	sub	x1, x28, x1
    9984:	eb03003f 	cmp	x1, x3
    9988:	54ff8323 	b.cc	89ec <fwp_hof0.constprop.0+0x63c>  // b.lo, b.ul, b.last
    998c:	17fffc33 	b	8a58 <fwp_hof0.constprop.0+0x6a8>
    9990:	72003c3f 	tst	w1, #0xffff
    9994:	54ffcfe1 	b.ne	9390 <fwp_hof0.constprop.0+0xfe0>  // b.any
    9998:	17fffe75 	b	936c <fwp_hof0.constprop.0+0xfbc>
    999c:	f94006d6 	ldr	x22, [x22, #8]
    99a0:	eb07005f 	cmp	x2, x7
    99a4:	54000369 	b.ls	9a10 <fwp_hof0.constprop.0+0x1660>  // b.plast
    99a8:	d350fce3 	lsr	x3, x7, #16
    99ac:	8b030863 	add	x3, x3, x3, lsl #2
    99b0:	d37df063 	lsl	x3, x3, #3
    99b4:	8b0300a6 	add	x6, x5, x3
    99b8:	f94010c4 	ldr	x4, [x6, #32]
    99bc:	b40002a4 	cbz	x4, 9a10 <fwp_hof0.constprop.0+0x1660>
    99c0:	386368a3 	ldrb	w3, [x5, x3]
    99c4:	7100087f 	cmp	w3, #0x2
    99c8:	54001420 	b.eq	9c4c <fwp_hof0.constprop.0+0x189c>  // b.none
    99cc:	7100047f 	cmp	w3, #0x1
    99d0:	54000201 	b.ne	9a10 <fwp_hof0.constprop.0+0x1660>  // b.any
    99d4:	294314c8 	ldp	w8, w5, [x6, #24]
    99d8:	92403ce3 	and	x3, x7, #0xffff
    99dc:	9b087c63 	mul	x3, x3, x8
    99e0:	d360fc63 	lsr	x3, x3, #32
    99e4:	eb05007f 	cmp	x3, x5
    99e8:	54000142 	b.cs	9a10 <fwp_hof0.constprop.0+0x1660>  // b.hs, b.nlast
    99ec:	8b030084 	add	x4, x4, x3
    99f0:	39400083 	ldrb	w3, [x4]
    99f4:	7100047f 	cmp	w3, #0x1
    99f8:	540000c1 	b.ne	9a10 <fwp_hof0.constprop.0+0x1660>  // b.any
    99fc:	97ffeca5 	bl	4c90 <fwp_mem_free>
    9a00:	9118c280 	add	x0, x20, #0x630
    9a04:	f949ec02 	ldr	x2, [x0, #5080]
    9a08:	f949d801 	ldr	x1, [x0, #5040]
    9a0c:	d370bc42 	lsl	x2, x2, #16
    9a10:	cb0102c3 	sub	x3, x22, x1
    9a14:	eb03005f 	cmp	x2, x3
    9a18:	54ffc3e8 	b.hi	9294 <fwp_hof0.constprop.0+0xee4>  // b.pmore
    9a1c:	17fffe3d 	b	9310 <fwp_hof0.constprop.0+0xf60>
    9a20:	f94017e0 	ldr	x0, [sp, #40]
    9a24:	97ffe7ff 	bl	3a20 <fwp_closure_drop.part.0>
    9a28:	17fffb02 	b	8630 <fwp_hof0.constprop.0+0x280>
    9a2c:	72003c3f 	tst	w1, #0xffff
    9a30:	54ff5d61 	b.ne	85dc <fwp_hof0.constprop.0+0x22c>  // b.any
    9a34:	aa1303e0 	mov	x0, x19
    9a38:	17fffacf 	b	8574 <fwp_hof0.constprop.0+0x1c4>
    9a3c:	72003c3f 	tst	w1, #0xffff
    9a40:	54ff5f81 	b.ne	8630 <fwp_hof0.constprop.0+0x280>  // b.any
    9a44:	17fffaf2 	b	860c <fwp_hof0.constprop.0+0x25c>
    9a48:	72003c3f 	tst	w1, #0xffff
    9a4c:	54ff75c1 	b.ne	8904 <fwp_hof0.constprop.0+0x554>  // b.any
    9a50:	394002e0 	ldrb	w0, [x23]
    9a54:	7103fc1f 	cmp	w0, #0xff
    9a58:	54ff7521 	b.ne	88fc <fwp_hof0.constprop.0+0x54c>  // b.any
    9a5c:	aa1703e0 	mov	x0, x23
    9a60:	97ffebec 	bl	4a10 <fwp_rc_forget_slot>
    9a64:	17fffba6 	b	88fc <fwp_hof0.constprop.0+0x54c>
    9a68:	aa1c03f6 	mov	x22, x28
    9a6c:	17fffc2f 	b	8b28 <fwp_hof0.constprop.0+0x778>
    9a70:	72003c3f 	tst	w1, #0xffff
    9a74:	54ff9401 	b.ne	8cf4 <fwp_hof0.constprop.0+0x944>  // b.any
    9a78:	394002c0 	ldrb	w0, [x22]
    9a7c:	7103fc1f 	cmp	w0, #0xff
    9a80:	54ff9361 	b.ne	8cec <fwp_hof0.constprop.0+0x93c>  // b.any
    9a84:	aa1603e0 	mov	x0, x22
    9a88:	97ffebe2 	bl	4a10 <fwp_rc_forget_slot>
    9a8c:	17fffc98 	b	8cec <fwp_hof0.constprop.0+0x93c>
    9a90:	72003c5f 	tst	w2, #0xffff
    9a94:	54ff7e21 	b.ne	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.any
    9a98:	17fffd0d 	b	8ecc <fwp_hof0.constprop.0+0xb1c>
    9a9c:	9118c280 	add	x0, x20, #0x630
    9aa0:	f9400ab3 	ldr	x19, [x21, #16]
    9aa4:	f949ec04 	ldr	x4, [x0, #5080]
    9aa8:	f949d801 	ldr	x1, [x0, #5040]
    9aac:	d370bc84 	lsl	x4, x4, #16
    9ab0:	cb0102a0 	sub	x0, x21, x1
    9ab4:	eb04001f 	cmp	x0, x4
    9ab8:	54000382 	b.cs	9b28 <fwp_hof0.constprop.0+0x1778>  // b.hs, b.nlast
    9abc:	d350fc02 	lsr	x2, x0, #16
    9ac0:	8b020842 	add	x2, x2, x2, lsl #2
    9ac4:	d37df042 	lsl	x2, x2, #3
    9ac8:	8b020066 	add	x6, x3, x2
    9acc:	f94010c5 	ldr	x5, [x6, #32]
    9ad0:	b40002c5 	cbz	x5, 9b28 <fwp_hof0.constprop.0+0x1778>
    9ad4:	38626862 	ldrb	w2, [x3, x2]
    9ad8:	7100085f 	cmp	w2, #0x2
    9adc:	54000be0 	b.eq	9c58 <fwp_hof0.constprop.0+0x18a8>  // b.none
    9ae0:	7100045f 	cmp	w2, #0x1
    9ae4:	54000221 	b.ne	9b28 <fwp_hof0.constprop.0+0x1778>  // b.any
    9ae8:	294308c3 	ldp	w3, w2, [x6, #24]
    9aec:	92403c00 	and	x0, x0, #0xffff
    9af0:	9b037c00 	mul	x0, x0, x3
    9af4:	d360fc00 	lsr	x0, x0, #32
    9af8:	eb02001f 	cmp	x0, x2
    9afc:	54000162 	b.cs	9b28 <fwp_hof0.constprop.0+0x1778>  // b.hs, b.nlast
    9b00:	8b0000a5 	add	x5, x5, x0
    9b04:	394000a0 	ldrb	w0, [x5]
    9b08:	7100041f 	cmp	w0, #0x1
    9b0c:	540000e1 	b.ne	9b28 <fwp_hof0.constprop.0+0x1778>  // b.any
    9b10:	aa1503e0 	mov	x0, x21
    9b14:	97ffec5f 	bl	4c90 <fwp_mem_free>
    9b18:	9118c280 	add	x0, x20, #0x630
    9b1c:	f949ec04 	ldr	x4, [x0, #5080]
    9b20:	f949d801 	ldr	x1, [x0, #5040]
    9b24:	d370bc84 	lsl	x4, x4, #16
    9b28:	cb010261 	sub	x1, x19, x1
    9b2c:	eb01009f 	cmp	x4, x1
    9b30:	54ffc309 	b.ls	9390 <fwp_hof0.constprop.0+0xfe0>  // b.plast
    9b34:	aa1303f5 	mov	x21, x19
    9b38:	17fffdfa 	b	9320 <fwp_hof0.constprop.0+0xf70>
    9b3c:	72003cff 	tst	w7, #0xffff
    9b40:	54ffbe81 	b.ne	9310 <fwp_hof0.constprop.0+0xf60>  // b.any
    9b44:	17fffe3a 	b	942c <fwp_hof0.constprop.0+0x107c>
    9b48:	d2800018 	mov	x24, #0x0                   	// #0
    9b4c:	52800020 	mov	w0, #0x1                   	// #1
    9b50:	17fffcaf 	b	8e0c <fwp_hof0.constprop.0+0xa5c>
    9b54:	72003c3f 	tst	w1, #0xffff
    9b58:	54ffd860 	b.eq	9664 <fwp_hof0.constprop.0+0x12b4>  // b.none
    9b5c:	aa1303e0 	mov	x0, x19
    9b60:	17fffc90 	b	8da0 <fwp_hof0.constprop.0+0x9f0>
    9b64:	aa1803e0 	mov	x0, x24
    9b68:	97ffebaa 	bl	4a10 <fwp_rc_forget_slot>
    9b6c:	17fffec1 	b	9670 <fwp_hof0.constprop.0+0x12c0>
    9b70:	d10006e1 	sub	x1, x23, #0x1
    9b74:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9b78:	eb00003f 	cmp	x1, x0
    9b7c:	54001e08 	b.hi	9f3c <fwp_hof0.constprop.0+0x1b8c>  // b.pmore
    9b80:	f00002a3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fbb0>
    9b84:	d2800000 	mov	x0, #0x0                   	// #0
    9b88:	91114061 	add	x1, x3, #0x450
    9b8c:	14000005 	b	9ba0 <fwp_hof0.constprop.0+0x17f0>
    9b90:	91000400 	add	x0, x0, #0x1
    9b94:	91006021 	add	x1, x1, #0x18
    9b98:	f140041f 	cmp	x0, #0x1, lsl #12
    9b9c:	54001500 	b.eq	9e3c <fwp_hof0.constprop.0+0x1a8c>  // b.none
    9ba0:	f9400022 	ldr	x2, [x1]
    9ba4:	b5ffff62 	cbnz	x2, 9b90 <fwp_hof0.constprop.0+0x17e0>
    9ba8:	8b000402 	add	x2, x0, x0, lsl #1
    9bac:	91114063 	add	x3, x3, #0x450
    9bb0:	aa1703e0 	mov	x0, x23
    9bb4:	d2800101 	mov	x1, #0x8                   	// #8
    9bb8:	8b020c73 	add	x19, x3, x2, lsl #3
    9bbc:	a90327e5 	stp	x5, x9, [sp, #48]
    9bc0:	97ffe330 	bl	2880 <calloc@plt>
    9bc4:	a94327e5 	ldp	x5, x9, [sp, #48]
    9bc8:	aa0003f8 	mov	x24, x0
    9bcc:	b4fffbe0 	cbz	x0, 9b48 <fwp_hof0.constprop.0+0x1798>
    9bd0:	aa1303e0 	mov	x0, x19
    9bd4:	d37df2e2 	lsl	x2, x23, #3
    9bd8:	aa1803e1 	mov	x1, x24
    9bdc:	52800063 	mov	w3, #0x3                   	// #3
    9be0:	a90327e5 	stp	x5, x9, [sp, #48]
    9be4:	97ffe4eb 	bl	2f90 <ad_raw_record>
    9be8:	a94327e5 	ldp	x5, x9, [sp, #48]
    9bec:	17fffbe3 	b	8b78 <fwp_hof0.constprop.0+0x7c8>
    9bf0:	f9400385 	ldr	x5, [x28]
    9bf4:	b7ffd685 	tbnz	x5, #63, 96c4 <fwp_hof0.constprop.0+0x1314>
    9bf8:	9118c281 	add	x1, x20, #0x630
    9bfc:	f949d820 	ldr	x0, [x1, #5040]
    9c00:	f949ec21 	ldr	x1, [x1, #5080]
    9c04:	cb0002c0 	sub	x0, x22, x0
    9c08:	eb01401f 	cmp	x0, x1, lsl #16
    9c0c:	54ffd5c2 	b.cs	96c4 <fwp_hof0.constprop.0+0x1314>  // b.hs, b.nlast
    9c10:	9240f8a4 	and	x4, x5, #0x7fffffffffffffff
    9c14:	17fffcc5 	b	8f28 <fwp_hof0.constprop.0+0xb78>
    9c18:	d2800d01 	mov	x1, #0x68                  	// #104
    9c1c:	d2800036 	mov	x22, #0x1                   	// #1
    9c20:	17fffab8 	b	8700 <fwp_hof0.constprop.0+0x350>
    9c24:	72003c5f 	tst	w2, #0xffff
    9c28:	54ffeac1 	b.ne	9980 <fwp_hof0.constprop.0+0x15d0>  // b.any
    9c2c:	17ffff4d 	b	9960 <fwp_hof0.constprop.0+0x15b0>
    9c30:	aa1303e0 	mov	x0, x19
    9c34:	97ffef40 	bl	5934 <fwp_rc_free_arr>
    9c38:	f94027e0 	ldr	x0, [sp, #72]
    9c3c:	f9400800 	ldr	x0, [x0, #16]
    9c40:	f90027e0 	str	x0, [sp, #72]
    9c44:	b5ff3ee0 	cbnz	x0, 8420 <fwp_hof0.constprop.0+0x70>
    9c48:	17ffff16 	b	98a0 <fwp_hof0.constprop.0+0x14f0>
    9c4c:	72003cff 	tst	w7, #0xffff
    9c50:	54ffee01 	b.ne	9a10 <fwp_hof0.constprop.0+0x1660>  // b.any
    9c54:	17ffff67 	b	99f0 <fwp_hof0.constprop.0+0x1640>
    9c58:	72003c1f 	tst	w0, #0xffff
    9c5c:	54fff661 	b.ne	9b28 <fwp_hof0.constprop.0+0x1778>  // b.any
    9c60:	17ffffa9 	b	9b04 <fwp_hof0.constprop.0+0x1754>
    9c64:	72003c9f 	tst	w4, #0xffff
    9c68:	54ff4361 	b.ne	84d4 <fwp_hof0.constprop.0+0x124>  // b.any
    9c6c:	17fffa08 	b	848c <fwp_hof0.constprop.0+0xdc>
    9c70:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9c74:	9118c281 	add	x1, x20, #0x630
    9c78:	ca402400 	eor	x0, x0, x0, lsr #9
    9c7c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9c80:	f94a2400 	ldr	x0, [x0, #5192]
    9c84:	b5000080 	cbnz	x0, 9c94 <fwp_hof0.constprop.0+0x18e4>
    9c88:	14000010 	b	9cc8 <fwp_hof0.constprop.0+0x1918>
    9c8c:	f9400800 	ldr	x0, [x0, #16]
    9c90:	b40001c0 	cbz	x0, 9cc8 <fwp_hof0.constprop.0+0x1918>
    9c94:	f9400001 	ldr	x1, [x0]
    9c98:	eb17003f 	cmp	x1, x23
    9c9c:	54ffff81 	b.ne	9c8c <fwp_hof0.constprop.0+0x18dc>  // b.any
    9ca0:	f9400401 	ldr	x1, [x0, #8]
    9ca4:	d1000421 	sub	x1, x1, #0x1
    9ca8:	f9000401 	str	x1, [x0, #8]
    9cac:	f103f83f 	cmp	x1, #0xfe
    9cb0:	54ff6d41 	b.ne	8a58 <fwp_hof0.constprop.0+0x6a8>  // b.any
    9cb4:	aa1703e0 	mov	x0, x23
    9cb8:	97ffeb56 	bl	4a10 <fwp_rc_forget_slot>
    9cbc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9cc0:	390002e0 	strb	w0, [x23]
    9cc4:	17fffb65 	b	8a58 <fwp_hof0.constprop.0+0x6a8>
    9cc8:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9ccc:	911dc000 	add	x0, x0, #0x770
    9cd0:	97ffe6cc 	bl	3800 <fwp_trap>
    9cd4:	ca534660 	eor	x0, x19, x19, lsr #17
    9cd8:	9118c281 	add	x1, x20, #0x630
    9cdc:	ca402400 	eor	x0, x0, x0, lsr #9
    9ce0:	8b200c20 	add	x0, x1, w0, uxtb #3
    9ce4:	f94a2400 	ldr	x0, [x0, #5192]
    9ce8:	b5000080 	cbnz	x0, 9cf8 <fwp_hof0.constprop.0+0x1948>
    9cec:	17fffff7 	b	9cc8 <fwp_hof0.constprop.0+0x1918>
    9cf0:	f9400800 	ldr	x0, [x0, #16]
    9cf4:	b4fffea0 	cbz	x0, 9cc8 <fwp_hof0.constprop.0+0x1918>
    9cf8:	f9400001 	ldr	x1, [x0]
    9cfc:	eb13003f 	cmp	x1, x19
    9d00:	54ffff81 	b.ne	9cf0 <fwp_hof0.constprop.0+0x1940>  // b.any
    9d04:	f9400401 	ldr	x1, [x0, #8]
    9d08:	d1000421 	sub	x1, x1, #0x1
    9d0c:	f9000401 	str	x1, [x0, #8]
    9d10:	f103f83f 	cmp	x1, #0xfe
    9d14:	54ffb3e1 	b.ne	9390 <fwp_hof0.constprop.0+0xfe0>  // b.any
    9d18:	aa1303e0 	mov	x0, x19
    9d1c:	97ffeb3d 	bl	4a10 <fwp_rc_forget_slot>
    9d20:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9d24:	39000260 	strb	w0, [x19]
    9d28:	17fffd9a 	b	9390 <fwp_hof0.constprop.0+0xfe0>
    9d2c:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9d30:	9118c281 	add	x1, x20, #0x630
    9d34:	ca402400 	eor	x0, x0, x0, lsr #9
    9d38:	8b200c20 	add	x0, x1, w0, uxtb #3
    9d3c:	f94a2401 	ldr	x1, [x0, #5192]
    9d40:	b5000081 	cbnz	x1, 9d50 <fwp_hof0.constprop.0+0x19a0>
    9d44:	17ffffe1 	b	9cc8 <fwp_hof0.constprop.0+0x1918>
    9d48:	f9400821 	ldr	x1, [x1, #16]
    9d4c:	b4fffbe1 	cbz	x1, 9cc8 <fwp_hof0.constprop.0+0x1918>
    9d50:	f9400020 	ldr	x0, [x1]
    9d54:	eb17001f 	cmp	x0, x23
    9d58:	54ffff81 	b.ne	9d48 <fwp_hof0.constprop.0+0x1998>  // b.any
    9d5c:	f9400420 	ldr	x0, [x1, #8]
    9d60:	d1000400 	sub	x0, x0, #0x1
    9d64:	f9000420 	str	x0, [x1, #8]
    9d68:	f103f81f 	cmp	x0, #0xfe
    9d6c:	54ffb6a1 	b.ne	9440 <fwp_hof0.constprop.0+0x1090>  // b.any
    9d70:	aa1703e0 	mov	x0, x23
    9d74:	97ffeb27 	bl	4a10 <fwp_rc_forget_slot>
    9d78:	9118c280 	add	x0, x20, #0x630
    9d7c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9d80:	390002e1 	strb	w1, [x23]
    9d84:	f949ec02 	ldr	x2, [x0, #5080]
    9d88:	f949d801 	ldr	x1, [x0, #5040]
    9d8c:	d370bc42 	lsl	x2, x2, #16
    9d90:	17fffd60 	b	9310 <fwp_hof0.constprop.0+0xf60>
    9d94:	72003c5f 	tst	w2, #0xffff
    9d98:	54ffd6c0 	b.eq	9870 <fwp_hof0.constprop.0+0x14c0>  // b.none
    9d9c:	f94027e0 	ldr	x0, [sp, #72]
    9da0:	f9400800 	ldr	x0, [x0, #16]
    9da4:	f90027e0 	str	x0, [sp, #72]
    9da8:	b5ff33c0 	cbnz	x0, 8420 <fwp_hof0.constprop.0+0x70>
    9dac:	17fffebd 	b	98a0 <fwp_hof0.constprop.0+0x14f0>
    9db0:	72003c5f 	tst	w2, #0xffff
    9db4:	54ffd141 	b.ne	97dc <fwp_hof0.constprop.0+0x142c>  // b.any
    9db8:	394002a0 	ldrb	w0, [x21]
    9dbc:	7103fc1f 	cmp	w0, #0xff
    9dc0:	54ffd0a1 	b.ne	97d4 <fwp_hof0.constprop.0+0x1424>  // b.any
    9dc4:	aa1503e0 	mov	x0, x21
    9dc8:	97ffeb12 	bl	4a10 <fwp_rc_forget_slot>
    9dcc:	17fffe82 	b	97d4 <fwp_hof0.constprop.0+0x1424>
    9dd0:	d2800018 	mov	x24, #0x0                   	// #0
    9dd4:	d280001c 	mov	x28, #0x0                   	// #0
    9dd8:	17fffd26 	b	9270 <fwp_hof0.constprop.0+0xec0>
    9ddc:	97ffeac6 	bl	48f4 <fwp_rc_wide_dup>
    9de0:	17fff9f2 	b	85a8 <fwp_hof0.constprop.0+0x1f8>
    9de4:	ca534660 	eor	x0, x19, x19, lsr #17
    9de8:	9118c281 	add	x1, x20, #0x630
    9dec:	ca402400 	eor	x0, x0, x0, lsr #9
    9df0:	8b200c20 	add	x0, x1, w0, uxtb #3
    9df4:	f94a2400 	ldr	x0, [x0, #5192]
    9df8:	b5000080 	cbnz	x0, 9e08 <fwp_hof0.constprop.0+0x1a58>
    9dfc:	17ffffb3 	b	9cc8 <fwp_hof0.constprop.0+0x1918>
    9e00:	f9400800 	ldr	x0, [x0, #16]
    9e04:	b4fff620 	cbz	x0, 9cc8 <fwp_hof0.constprop.0+0x1918>
    9e08:	f9400001 	ldr	x1, [x0]
    9e0c:	eb13003f 	cmp	x1, x19
    9e10:	54ffff81 	b.ne	9e00 <fwp_hof0.constprop.0+0x1a50>  // b.any
    9e14:	f9400401 	ldr	x1, [x0, #8]
    9e18:	d1000421 	sub	x1, x1, #0x1
    9e1c:	f9000401 	str	x1, [x0, #8]
    9e20:	f103f83f 	cmp	x1, #0xfe
    9e24:	54ff4061 	b.ne	8630 <fwp_hof0.constprop.0+0x280>  // b.any
    9e28:	aa1303e0 	mov	x0, x19
    9e2c:	97ffeaf9 	bl	4a10 <fwp_rc_forget_slot>
    9e30:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e34:	39000260 	strb	w0, [x19]
    9e38:	17fff9fe 	b	8630 <fwp_hof0.constprop.0+0x280>
    9e3c:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9e40:	91196000 	add	x0, x0, #0x658
    9e44:	97ffe54f 	bl	3380 <ad_raw_fail>
    9e48:	d2800017 	mov	x23, #0x0                   	// #0
    9e4c:	17fffc94 	b	909c <fwp_hof0.constprop.0+0xcec>
    9e50:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9e54:	91214000 	add	x0, x0, #0x850
    9e58:	97ffe66a 	bl	3800 <fwp_trap>
    9e5c:	97ffeaa6 	bl	48f4 <fwp_rc_wide_dup>
    9e60:	9118c280 	add	x0, x20, #0x630
    9e64:	f949ec03 	ldr	x3, [x0, #5080]
    9e68:	f949d801 	ldr	x1, [x0, #5040]
    9e6c:	d370bc63 	lsl	x3, x3, #16
    9e70:	17fff999 	b	84d4 <fwp_hof0.constprop.0+0x124>
    9e74:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9e78:	911ee000 	add	x0, x0, #0x7b8
    9e7c:	97ffe661 	bl	3800 <fwp_trap>
    9e80:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9e84:	9118c281 	add	x1, x20, #0x630
    9e88:	ca402400 	eor	x0, x0, x0, lsr #9
    9e8c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9e90:	f94a2400 	ldr	x0, [x0, #5192]
    9e94:	b5000080 	cbnz	x0, 9ea4 <fwp_hof0.constprop.0+0x1af4>
    9e98:	17ffff8c 	b	9cc8 <fwp_hof0.constprop.0+0x1918>
    9e9c:	f9400800 	ldr	x0, [x0, #16]
    9ea0:	b4fff140 	cbz	x0, 9cc8 <fwp_hof0.constprop.0+0x1918>
    9ea4:	f9400001 	ldr	x1, [x0]
    9ea8:	eb0102bf 	cmp	x21, x1
    9eac:	54ffff81 	b.ne	9e9c <fwp_hof0.constprop.0+0x1aec>  // b.any
    9eb0:	f9400401 	ldr	x1, [x0, #8]
    9eb4:	d1000421 	sub	x1, x1, #0x1
    9eb8:	f9000401 	str	x1, [x0, #8]
    9ebc:	f103f83f 	cmp	x1, #0xfe
    9ec0:	54ffce81 	b.ne	9890 <fwp_hof0.constprop.0+0x14e0>  // b.any
    9ec4:	aa1503e0 	mov	x0, x21
    9ec8:	97ffead2 	bl	4a10 <fwp_rc_forget_slot>
    9ecc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9ed0:	390002a0 	strb	w0, [x21]
    9ed4:	17fffe6f 	b	9890 <fwp_hof0.constprop.0+0x14e0>
    9ed8:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9edc:	9128c000 	add	x0, x0, #0xa30
    9ee0:	97ffe648 	bl	3800 <fwp_trap>
    9ee4:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9ee8:	9122c000 	add	x0, x0, #0x8b0
    9eec:	97ffe645 	bl	3800 <fwp_trap>
    9ef0:	a90f53f3 	stp	x19, x20, [sp, #240]
    9ef4:	a9105bf5 	stp	x21, x22, [sp, #256]
    9ef8:	a91163f7 	stp	x23, x24, [sp, #272]
    9efc:	a9126bf9 	stp	x25, x26, [sp, #288]
    9f00:	a91373fb 	stp	x27, x28, [sp, #304]
    9f04:	fd00a3e8 	str	d8, [sp, #320]
    9f08:	97ffe266 	bl	28a0 <__stack_chk_fail@plt>
    9f0c:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9f10:	91200000 	add	x0, x0, #0x800
    9f14:	97ffe63b 	bl	3800 <fwp_trap>
    9f18:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9f1c:	9126c000 	add	x0, x0, #0x9b0
    9f20:	97ffe638 	bl	3800 <fwp_trap>
    9f24:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9f28:	91274000 	add	x0, x0, #0x9d0
    9f2c:	97ffe635 	bl	3800 <fwp_trap>
    9f30:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9f34:	9129c000 	add	x0, x0, #0xa70
    9f38:	97ffe632 	bl	3800 <fwp_trap>
    9f3c:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9f40:	91280000 	add	x0, x0, #0xa00
    9f44:	97ffe50f 	bl	3380 <ad_raw_fail>
    9f48:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9f4c:	91288000 	add	x0, x0, #0xa20
    9f50:	97ffe62c 	bl	3800 <fwp_trap>
    9f54:	90000020 	adrp	x0, d000 <__modti3+0xf0>
    9f58:	91296000 	add	x0, x0, #0xa58
    9f5c:	97ffe629 	bl	3800 <fwp_trap>
    9f60:	97ffe264 	bl	28f0 <abort@plt>
    9f64:	97ffe2c7 	bl	2a80 <fwp_trap_overflow.constprop.0>
    9f68:	d503201f 	nop
    9f6c:	d503201f 	nop

0000000000009f70 <f0>:
    9f70:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9f74:	910003fd 	mov	x29, sp
    9f78:	a90153f3 	stp	x19, x20, [sp, #16]
    9f7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9f80:	a90363f7 	stp	x23, x24, [sp, #48]
    9f84:	a9046bf9 	stp	x25, x26, [sp, #64]
    9f88:	a90573fb 	stp	x27, x28, [sp, #80]
    9f8c:	d12183ff 	sub	sp, sp, #0x860
    9f90:	f90203ff 	str	xzr, [sp, #1024]
    9f94:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f98:	91014005 	add	x5, x0, #0x50
    9f9c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    9fa0:	f947f400 	ldr	x0, [x0, #4072]
    9fa4:	90000394 	adrp	x20, 79000 <fwp_root_context+0xbb0>
    9fa8:	f941c8a6 	ldr	x6, [x5, #912]
    9fac:	f9400001 	ldr	x1, [x0]
    9fb0:	f9042fe1 	str	x1, [sp, #2136]
    9fb4:	d2800001 	mov	x1, #0x0                   	// #0
    9fb8:	9118c298 	add	x24, x20, #0x630
    9fbc:	912123f6 	add	x22, sp, #0x848
    9fc0:	910023e0 	add	x0, sp, #0x8
    9fc4:	910083e2 	add	x2, sp, #0x20
    9fc8:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc_slow+0x50>
    9fcc:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9fd0:	91380021 	add	x1, x1, #0xe00
    9fd4:	913d4084 	add	x4, x4, #0xf50
    9fd8:	d2800013 	mov	x19, #0x0                   	// #0
    9fdc:	d2800119 	mov	x25, #0x8                   	// #8
    9fe0:	d2800015 	mov	x21, #0x0                   	// #0
    9fe4:	52800037 	mov	w23, #0x1                   	// #1
    9fe8:	a90093e6 	stp	x6, x4, [sp, #8]
    9fec:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9ff0:	a90307ff 	stp	xzr, x1, [sp, #48]
    9ff4:	f901c8a0 	str	x0, [x5, #912]
    9ff8:	f100073a 	subs	x26, x25, #0x1
    9ffc:	aa1603e1 	mov	x1, x22
    a000:	da1f02bc 	sbc	x28, x21, xzr
    a004:	52800020 	mov	w0, #0x1                   	// #1
    a008:	f90017fa 	str	x26, [sp, #40]
    a00c:	aa1a03f9 	mov	x25, x26
    a010:	f90427fa 	str	x26, [sp, #2120]
    a014:	aa1c03f5 	mov	x21, x28
    a018:	f9042bf3 	str	x19, [sp, #2128]
    a01c:	97ffec9e 	bl	5294 <fwp_data.part.0.constprop.0>
    a020:	f949db02 	ldr	x2, [x24, #5040]
    a024:	aa0003f3 	mov	x19, x0
    a028:	f949ef00 	ldr	x0, [x24, #5080]
    a02c:	cb020262 	sub	x2, x19, x2
    a030:	eb00405f 	cmp	x2, x0, lsl #16
    a034:	54000302 	b.cs	a094 <f0+0x124>  // b.hs, b.nlast
    a038:	d350fc40 	lsr	x0, x2, #16
    a03c:	f949ff04 	ldr	x4, [x24, #5112]
    a040:	8b000800 	add	x0, x0, x0, lsl #2
    a044:	d37df001 	lsl	x1, x0, #3
    a048:	8b010080 	add	x0, x4, x1
    a04c:	f940101b 	ldr	x27, [x0, #32]
    a050:	b400023b 	cbz	x27, a094 <f0+0x124>
    a054:	38616881 	ldrb	w1, [x4, x1]
    a058:	7100083f 	cmp	w1, #0x2
    a05c:	54010e00 	b.eq	c21c <f0+0x22ac>  // b.none
    a060:	7100043f 	cmp	w1, #0x1
    a064:	54000181 	b.ne	a094 <f0+0x124>  // b.any
    a068:	29430001 	ldp	w1, w0, [x0, #24]
    a06c:	92403c42 	and	x2, x2, #0xffff
    a070:	9b017c42 	mul	x2, x2, x1
    a074:	d360fc42 	lsr	x2, x2, #32
    a078:	eb00005f 	cmp	x2, x0
    a07c:	540000c2 	b.cs	a094 <f0+0x124>  // b.hs, b.nlast
    a080:	8b02037b 	add	x27, x27, x2
    a084:	39400360 	ldrb	w0, [x27]
    a088:	7103fc1f 	cmp	w0, #0xff
    a08c:	54010c20 	b.eq	c210 <f0+0x22a0>  // b.none
    a090:	39000377 	strb	w23, [x27]
    a094:	f90013f3 	str	x19, [sp, #32]
    a098:	aa1c035a 	orr	x26, x26, x28
    a09c:	b5fffafa 	cbnz	x26, 9ff8 <f0+0x88>
    a0a0:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xd50>
    a0a4:	910103e1 	add	x1, sp, #0x40
    a0a8:	f94007e2 	ldr	x2, [sp, #8]
    a0ac:	d00000a0 	adrp	x0, 20000 <__data_start>
    a0b0:	3dc0a460 	ldr	q0, [x3, #656]
    a0b4:	91014018 	add	x24, x0, #0x50
    a0b8:	52800020 	mov	w0, #0x1                   	// #1
    a0bc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a0c0:	3d8013e0 	str	q0, [sp, #64]
    a0c4:	f901cb02 	str	x2, [x24, #912]
    a0c8:	97ffec73 	bl	5294 <fwp_data.part.0.constprop.0>
    a0cc:	97ffedea 	bl	5874 <fwp_rc_fresh>
    a0d0:	aa0003e2 	mov	x2, x0
    a0d4:	910163e1 	add	x1, sp, #0x58
    a0d8:	52800020 	mov	w0, #0x1                   	// #1
    a0dc:	a9058bf5 	stp	x21, x2, [sp, #88]
    a0e0:	97ffec6d 	bl	5294 <fwp_data.part.0.constprop.0>
    a0e4:	97ffede4 	bl	5874 <fwp_rc_fresh>
    a0e8:	aa0003e2 	mov	x2, x0
    a0ec:	9101a3e1 	add	x1, sp, #0x68
    a0f0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a0f4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a0f8:	52800020 	mov	w0, #0x1                   	// #1
    a0fc:	a9068be3 	stp	x3, x2, [sp, #104]
    a100:	97ffec65 	bl	5294 <fwp_data.part.0.constprop.0>
    a104:	97ffeddc 	bl	5874 <fwp_rc_fresh>
    a108:	aa0003e2 	mov	x2, x0
    a10c:	9101e3e1 	add	x1, sp, #0x78
    a110:	52800020 	mov	w0, #0x1                   	// #1
    a114:	a9078bf5 	stp	x21, x2, [sp, #120]
    a118:	97ffec5f 	bl	5294 <fwp_data.part.0.constprop.0>
    a11c:	97ffedd6 	bl	5874 <fwp_rc_fresh>
    a120:	aa0003e2 	mov	x2, x0
    a124:	910223e1 	add	x1, sp, #0x88
    a128:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a12c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a130:	52800020 	mov	w0, #0x1                   	// #1
    a134:	a9088be3 	stp	x3, x2, [sp, #136]
    a138:	97ffec57 	bl	5294 <fwp_data.part.0.constprop.0>
    a13c:	97ffedce 	bl	5874 <fwp_rc_fresh>
    a140:	aa0003e2 	mov	x2, x0
    a144:	910263e1 	add	x1, sp, #0x98
    a148:	52800020 	mov	w0, #0x1                   	// #1
    a14c:	a9098bf5 	stp	x21, x2, [sp, #152]
    a150:	97ffec51 	bl	5294 <fwp_data.part.0.constprop.0>
    a154:	97ffedc8 	bl	5874 <fwp_rc_fresh>
    a158:	aa0003e2 	mov	x2, x0
    a15c:	9102a3e1 	add	x1, sp, #0xa8
    a160:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a164:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a168:	52800020 	mov	w0, #0x1                   	// #1
    a16c:	a90a8be3 	stp	x3, x2, [sp, #168]
    a170:	97ffec49 	bl	5294 <fwp_data.part.0.constprop.0>
    a174:	97ffedc0 	bl	5874 <fwp_rc_fresh>
    a178:	aa0003e2 	mov	x2, x0
    a17c:	9102e3e1 	add	x1, sp, #0xb8
    a180:	52800020 	mov	w0, #0x1                   	// #1
    a184:	a90b8bf5 	stp	x21, x2, [sp, #184]
    a188:	97ffec43 	bl	5294 <fwp_data.part.0.constprop.0>
    a18c:	97ffedba 	bl	5874 <fwp_rc_fresh>
    a190:	aa0003e2 	mov	x2, x0
    a194:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a198:	910323e1 	add	x1, sp, #0xc8
    a19c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a1a0:	52800020 	mov	w0, #0x1                   	// #1
    a1a4:	a90c8be3 	stp	x3, x2, [sp, #200]
    a1a8:	97ffec3b 	bl	5294 <fwp_data.part.0.constprop.0>
    a1ac:	9118c283 	add	x3, x20, #0x630
    a1b0:	aa0003f5 	mov	x21, x0
    a1b4:	f949d861 	ldr	x1, [x3, #5040]
    a1b8:	f949ec60 	ldr	x0, [x3, #5080]
    a1bc:	cb0102a1 	sub	x1, x21, x1
    a1c0:	eb00403f 	cmp	x1, x0, lsl #16
    a1c4:	54000322 	b.cs	a228 <f0+0x2b8>  // b.hs, b.nlast
    a1c8:	d350fc22 	lsr	x2, x1, #16
    a1cc:	f949fc63 	ldr	x3, [x3, #5112]
    a1d0:	8b020842 	add	x2, x2, x2, lsl #2
    a1d4:	d37df042 	lsl	x2, x2, #3
    a1d8:	8b020060 	add	x0, x3, x2
    a1dc:	f9401017 	ldr	x23, [x0, #32]
    a1e0:	b4000257 	cbz	x23, a228 <f0+0x2b8>
    a1e4:	38626862 	ldrb	w2, [x3, x2]
    a1e8:	7100085f 	cmp	w2, #0x2
    a1ec:	540105a0 	b.eq	c2a0 <f0+0x2330>  // b.none
    a1f0:	7100045f 	cmp	w2, #0x1
    a1f4:	540001a1 	b.ne	a228 <f0+0x2b8>  // b.any
    a1f8:	29430002 	ldp	w2, w0, [x0, #24]
    a1fc:	92403c21 	and	x1, x1, #0xffff
    a200:	9b027c21 	mul	x1, x1, x2
    a204:	d360fc21 	lsr	x1, x1, #32
    a208:	eb00003f 	cmp	x1, x0
    a20c:	540000e2 	b.cs	a228 <f0+0x2b8>  // b.hs, b.nlast
    a210:	8b0102f7 	add	x23, x23, x1
    a214:	394002e0 	ldrb	w0, [x23]
    a218:	7103fc1f 	cmp	w0, #0xff
    a21c:	54010f60 	b.eq	c408 <f0+0x2498>  // b.none
    a220:	52800020 	mov	w0, #0x1                   	// #1
    a224:	390002e0 	strb	w0, [x23]
    a228:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a22c:	910363e1 	add	x1, sp, #0xd8
    a230:	52800020 	mov	w0, #0x1                   	// #1
    a234:	a90dd7e2 	stp	x2, x21, [sp, #216]
    a238:	97ffec17 	bl	5294 <fwp_data.part.0.constprop.0>
    a23c:	9118c283 	add	x3, x20, #0x630
    a240:	aa0003f7 	mov	x23, x0
    a244:	f949d861 	ldr	x1, [x3, #5040]
    a248:	f949ec60 	ldr	x0, [x3, #5080]
    a24c:	cb0102e1 	sub	x1, x23, x1
    a250:	eb00403f 	cmp	x1, x0, lsl #16
    a254:	54000322 	b.cs	a2b8 <f0+0x348>  // b.hs, b.nlast
    a258:	d350fc22 	lsr	x2, x1, #16
    a25c:	f949fc63 	ldr	x3, [x3, #5112]
    a260:	8b020842 	add	x2, x2, x2, lsl #2
    a264:	d37df042 	lsl	x2, x2, #3
    a268:	8b020060 	add	x0, x3, x2
    a26c:	f9401015 	ldr	x21, [x0, #32]
    a270:	b4000255 	cbz	x21, a2b8 <f0+0x348>
    a274:	38626862 	ldrb	w2, [x3, x2]
    a278:	7100085f 	cmp	w2, #0x2
    a27c:	540100c0 	b.eq	c294 <f0+0x2324>  // b.none
    a280:	7100045f 	cmp	w2, #0x1
    a284:	540001a1 	b.ne	a2b8 <f0+0x348>  // b.any
    a288:	29430002 	ldp	w2, w0, [x0, #24]
    a28c:	92403c21 	and	x1, x1, #0xffff
    a290:	9b027c21 	mul	x1, x1, x2
    a294:	d360fc21 	lsr	x1, x1, #32
    a298:	eb00003f 	cmp	x1, x0
    a29c:	540000e2 	b.cs	a2b8 <f0+0x348>  // b.hs, b.nlast
    a2a0:	8b0102b5 	add	x21, x21, x1
    a2a4:	394002a0 	ldrb	w0, [x21]
    a2a8:	7103fc1f 	cmp	w0, #0xff
    a2ac:	54010b40 	b.eq	c414 <f0+0x24a4>  // b.none
    a2b0:	52800020 	mov	w0, #0x1                   	// #1
    a2b4:	390002a0 	strb	w0, [x21]
    a2b8:	9103a3e1 	add	x1, sp, #0xe8
    a2bc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a2c0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a2c4:	52800020 	mov	w0, #0x1                   	// #1
    a2c8:	a90edff5 	stp	x21, x23, [sp, #232]
    a2cc:	97ffebf2 	bl	5294 <fwp_data.part.0.constprop.0>
    a2d0:	97ffed69 	bl	5874 <fwp_rc_fresh>
    a2d4:	aa0003e2 	mov	x2, x0
    a2d8:	9103e3e1 	add	x1, sp, #0xf8
    a2dc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a2e0:	52800020 	mov	w0, #0x1                   	// #1
    a2e4:	a90f8bf7 	stp	x23, x2, [sp, #248]
    a2e8:	97ffebeb 	bl	5294 <fwp_data.part.0.constprop.0>
    a2ec:	97ffed62 	bl	5874 <fwp_rc_fresh>
    a2f0:	aa0003e2 	mov	x2, x0
    a2f4:	910423e1 	add	x1, sp, #0x108
    a2f8:	52800020 	mov	w0, #0x1                   	// #1
    a2fc:	a9108bf5 	stp	x21, x2, [sp, #264]
    a300:	97ffebe5 	bl	5294 <fwp_data.part.0.constprop.0>
    a304:	97ffed5c 	bl	5874 <fwp_rc_fresh>
    a308:	aa0003e2 	mov	x2, x0
    a30c:	910463e1 	add	x1, sp, #0x118
    a310:	52800020 	mov	w0, #0x1                   	// #1
    a314:	a9118bf7 	stp	x23, x2, [sp, #280]
    a318:	97ffebdf 	bl	5294 <fwp_data.part.0.constprop.0>
    a31c:	97ffed56 	bl	5874 <fwp_rc_fresh>
    a320:	aa0003e2 	mov	x2, x0
    a324:	9104a3e1 	add	x1, sp, #0x128
    a328:	52800020 	mov	w0, #0x1                   	// #1
    a32c:	a9128bf5 	stp	x21, x2, [sp, #296]
    a330:	97ffebd9 	bl	5294 <fwp_data.part.0.constprop.0>
    a334:	97ffed50 	bl	5874 <fwp_rc_fresh>
    a338:	aa0003e2 	mov	x2, x0
    a33c:	9104e3e1 	add	x1, sp, #0x138
    a340:	52800020 	mov	w0, #0x1                   	// #1
    a344:	a9138bf7 	stp	x23, x2, [sp, #312]
    a348:	97ffebd3 	bl	5294 <fwp_data.part.0.constprop.0>
    a34c:	97ffed4a 	bl	5874 <fwp_rc_fresh>
    a350:	aa0003e2 	mov	x2, x0
    a354:	910523e1 	add	x1, sp, #0x148
    a358:	52800020 	mov	w0, #0x1                   	// #1
    a35c:	a9148bf5 	stp	x21, x2, [sp, #328]
    a360:	97ffebcd 	bl	5294 <fwp_data.part.0.constprop.0>
    a364:	97ffed44 	bl	5874 <fwp_rc_fresh>
    a368:	aa0003e2 	mov	x2, x0
    a36c:	910563e1 	add	x1, sp, #0x158
    a370:	52800020 	mov	w0, #0x1                   	// #1
    a374:	a9158bf7 	stp	x23, x2, [sp, #344]
    a378:	97ffebc7 	bl	5294 <fwp_data.part.0.constprop.0>
    a37c:	97ffed3e 	bl	5874 <fwp_rc_fresh>
    a380:	aa0003e2 	mov	x2, x0
    a384:	9105a3e1 	add	x1, sp, #0x168
    a388:	52800020 	mov	w0, #0x1                   	// #1
    a38c:	a9168bf5 	stp	x21, x2, [sp, #360]
    a390:	97ffebc1 	bl	5294 <fwp_data.part.0.constprop.0>
    a394:	97ffed38 	bl	5874 <fwp_rc_fresh>
    a398:	aa0003e2 	mov	x2, x0
    a39c:	9105e3e1 	add	x1, sp, #0x178
    a3a0:	52800020 	mov	w0, #0x1                   	// #1
    a3a4:	a9178bf7 	stp	x23, x2, [sp, #376]
    a3a8:	97ffebbb 	bl	5294 <fwp_data.part.0.constprop.0>
    a3ac:	97ffed32 	bl	5874 <fwp_rc_fresh>
    a3b0:	aa0003e2 	mov	x2, x0
    a3b4:	910623e1 	add	x1, sp, #0x188
    a3b8:	52800020 	mov	w0, #0x1                   	// #1
    a3bc:	a9188bf5 	stp	x21, x2, [sp, #392]
    a3c0:	97ffebb5 	bl	5294 <fwp_data.part.0.constprop.0>
    a3c4:	97ffed2c 	bl	5874 <fwp_rc_fresh>
    a3c8:	aa0003e2 	mov	x2, x0
    a3cc:	910663e1 	add	x1, sp, #0x198
    a3d0:	52800020 	mov	w0, #0x1                   	// #1
    a3d4:	a9198bf7 	stp	x23, x2, [sp, #408]
    a3d8:	97ffebaf 	bl	5294 <fwp_data.part.0.constprop.0>
    a3dc:	97ffed26 	bl	5874 <fwp_rc_fresh>
    a3e0:	aa0003e2 	mov	x2, x0
    a3e4:	9106a3e1 	add	x1, sp, #0x1a8
    a3e8:	52800020 	mov	w0, #0x1                   	// #1
    a3ec:	a91a8bf5 	stp	x21, x2, [sp, #424]
    a3f0:	97ffeba9 	bl	5294 <fwp_data.part.0.constprop.0>
    a3f4:	97ffed20 	bl	5874 <fwp_rc_fresh>
    a3f8:	aa0003e2 	mov	x2, x0
    a3fc:	9106e3e1 	add	x1, sp, #0x1b8
    a400:	52800020 	mov	w0, #0x1                   	// #1
    a404:	a91b8bf7 	stp	x23, x2, [sp, #440]
    a408:	97ffeba3 	bl	5294 <fwp_data.part.0.constprop.0>
    a40c:	97ffed1a 	bl	5874 <fwp_rc_fresh>
    a410:	aa0003e2 	mov	x2, x0
    a414:	910723e1 	add	x1, sp, #0x1c8
    a418:	52800020 	mov	w0, #0x1                   	// #1
    a41c:	a91c8bf5 	stp	x21, x2, [sp, #456]
    a420:	97ffeb9d 	bl	5294 <fwp_data.part.0.constprop.0>
    a424:	97ffed14 	bl	5874 <fwp_rc_fresh>
    a428:	aa0003e2 	mov	x2, x0
    a42c:	910763e1 	add	x1, sp, #0x1d8
    a430:	52800020 	mov	w0, #0x1                   	// #1
    a434:	a91d8bf7 	stp	x23, x2, [sp, #472]
    a438:	97ffeb97 	bl	5294 <fwp_data.part.0.constprop.0>
    a43c:	97ffed0e 	bl	5874 <fwp_rc_fresh>
    a440:	aa0003e2 	mov	x2, x0
    a444:	9107a3e1 	add	x1, sp, #0x1e8
    a448:	52800020 	mov	w0, #0x1                   	// #1
    a44c:	a91e8bf5 	stp	x21, x2, [sp, #488]
    a450:	97ffeb91 	bl	5294 <fwp_data.part.0.constprop.0>
    a454:	97ffed08 	bl	5874 <fwp_rc_fresh>
    a458:	aa0003e2 	mov	x2, x0
    a45c:	9107e3e1 	add	x1, sp, #0x1f8
    a460:	52800020 	mov	w0, #0x1                   	// #1
    a464:	a91f8bf7 	stp	x23, x2, [sp, #504]
    a468:	97ffeb8b 	bl	5294 <fwp_data.part.0.constprop.0>
    a46c:	97ffed02 	bl	5874 <fwp_rc_fresh>
    a470:	aa0003e2 	mov	x2, x0
    a474:	910823e1 	add	x1, sp, #0x208
    a478:	52800020 	mov	w0, #0x1                   	// #1
    a47c:	f90107f5 	str	x21, [sp, #520]
    a480:	f9010be2 	str	x2, [sp, #528]
    a484:	97ffeb84 	bl	5294 <fwp_data.part.0.constprop.0>
    a488:	97ffecfb 	bl	5874 <fwp_rc_fresh>
    a48c:	aa0003e2 	mov	x2, x0
    a490:	910863e1 	add	x1, sp, #0x218
    a494:	52800020 	mov	w0, #0x1                   	// #1
    a498:	f9010ff7 	str	x23, [sp, #536]
    a49c:	f90113e2 	str	x2, [sp, #544]
    a4a0:	97ffeb7d 	bl	5294 <fwp_data.part.0.constprop.0>
    a4a4:	97ffecf4 	bl	5874 <fwp_rc_fresh>
    a4a8:	aa0003e2 	mov	x2, x0
    a4ac:	9108a3e1 	add	x1, sp, #0x228
    a4b0:	52800020 	mov	w0, #0x1                   	// #1
    a4b4:	f90117f5 	str	x21, [sp, #552]
    a4b8:	f9011be2 	str	x2, [sp, #560]
    a4bc:	97ffeb76 	bl	5294 <fwp_data.part.0.constprop.0>
    a4c0:	9118c283 	add	x3, x20, #0x630
    a4c4:	aa0003f5 	mov	x21, x0
    a4c8:	f949d861 	ldr	x1, [x3, #5040]
    a4cc:	f949ec60 	ldr	x0, [x3, #5080]
    a4d0:	cb0102a1 	sub	x1, x21, x1
    a4d4:	eb00403f 	cmp	x1, x0, lsl #16
    a4d8:	54000322 	b.cs	a53c <f0+0x5cc>  // b.hs, b.nlast
    a4dc:	d350fc22 	lsr	x2, x1, #16
    a4e0:	f949fc63 	ldr	x3, [x3, #5112]
    a4e4:	8b020842 	add	x2, x2, x2, lsl #2
    a4e8:	d37df042 	lsl	x2, x2, #3
    a4ec:	8b020060 	add	x0, x3, x2
    a4f0:	f9401017 	ldr	x23, [x0, #32]
    a4f4:	b4000257 	cbz	x23, a53c <f0+0x5cc>
    a4f8:	38626862 	ldrb	w2, [x3, x2]
    a4fc:	7100085f 	cmp	w2, #0x2
    a500:	5400ec40 	b.eq	c288 <f0+0x2318>  // b.none
    a504:	7100045f 	cmp	w2, #0x1
    a508:	540001a1 	b.ne	a53c <f0+0x5cc>  // b.any
    a50c:	29430002 	ldp	w2, w0, [x0, #24]
    a510:	92403c21 	and	x1, x1, #0xffff
    a514:	9b027c21 	mul	x1, x1, x2
    a518:	d360fc21 	lsr	x1, x1, #32
    a51c:	eb00003f 	cmp	x1, x0
    a520:	540000e2 	b.cs	a53c <f0+0x5cc>  // b.hs, b.nlast
    a524:	8b0102f7 	add	x23, x23, x1
    a528:	394002e0 	ldrb	w0, [x23]
    a52c:	7103fc1f 	cmp	w0, #0xff
    a530:	5400f780 	b.eq	c420 <f0+0x24b0>  // b.none
    a534:	52800020 	mov	w0, #0x1                   	// #1
    a538:	390002e0 	strb	w0, [x23]
    a53c:	9108e3e1 	add	x1, sp, #0x238
    a540:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a544:	52800020 	mov	w0, #0x1                   	// #1
    a548:	f9011ff7 	str	x23, [sp, #568]
    a54c:	f90123f5 	str	x21, [sp, #576]
    a550:	97ffeb51 	bl	5294 <fwp_data.part.0.constprop.0>
    a554:	97ffecc8 	bl	5874 <fwp_rc_fresh>
    a558:	aa0003e2 	mov	x2, x0
    a55c:	910923e1 	add	x1, sp, #0x248
    a560:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a564:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a568:	52800020 	mov	w0, #0x1                   	// #1
    a56c:	f90127f5 	str	x21, [sp, #584]
    a570:	f9012be2 	str	x2, [sp, #592]
    a574:	97ffeb48 	bl	5294 <fwp_data.part.0.constprop.0>
    a578:	97ffecbf 	bl	5874 <fwp_rc_fresh>
    a57c:	aa0003e2 	mov	x2, x0
    a580:	910963e1 	add	x1, sp, #0x258
    a584:	52800020 	mov	w0, #0x1                   	// #1
    a588:	f9012ff7 	str	x23, [sp, #600]
    a58c:	f90133e2 	str	x2, [sp, #608]
    a590:	97ffeb41 	bl	5294 <fwp_data.part.0.constprop.0>
    a594:	97ffecb8 	bl	5874 <fwp_rc_fresh>
    a598:	aa0003e2 	mov	x2, x0
    a59c:	9109a3e1 	add	x1, sp, #0x268
    a5a0:	52800020 	mov	w0, #0x1                   	// #1
    a5a4:	f90137f5 	str	x21, [sp, #616]
    a5a8:	f9013be2 	str	x2, [sp, #624]
    a5ac:	97ffeb3a 	bl	5294 <fwp_data.part.0.constprop.0>
    a5b0:	97ffecb1 	bl	5874 <fwp_rc_fresh>
    a5b4:	aa0003e2 	mov	x2, x0
    a5b8:	9109e3e1 	add	x1, sp, #0x278
    a5bc:	52800020 	mov	w0, #0x1                   	// #1
    a5c0:	f9013ff7 	str	x23, [sp, #632]
    a5c4:	f90143e2 	str	x2, [sp, #640]
    a5c8:	97ffeb33 	bl	5294 <fwp_data.part.0.constprop.0>
    a5cc:	97ffecaa 	bl	5874 <fwp_rc_fresh>
    a5d0:	aa0003e2 	mov	x2, x0
    a5d4:	910a23e1 	add	x1, sp, #0x288
    a5d8:	52800020 	mov	w0, #0x1                   	// #1
    a5dc:	f90147f5 	str	x21, [sp, #648]
    a5e0:	f9014be2 	str	x2, [sp, #656]
    a5e4:	97ffeb2c 	bl	5294 <fwp_data.part.0.constprop.0>
    a5e8:	9118c283 	add	x3, x20, #0x630
    a5ec:	aa0003f5 	mov	x21, x0
    a5f0:	f949d861 	ldr	x1, [x3, #5040]
    a5f4:	f949ec60 	ldr	x0, [x3, #5080]
    a5f8:	cb0102a1 	sub	x1, x21, x1
    a5fc:	eb00403f 	cmp	x1, x0, lsl #16
    a600:	54000322 	b.cs	a664 <f0+0x6f4>  // b.hs, b.nlast
    a604:	d350fc22 	lsr	x2, x1, #16
    a608:	f949fc63 	ldr	x3, [x3, #5112]
    a60c:	8b020842 	add	x2, x2, x2, lsl #2
    a610:	d37df042 	lsl	x2, x2, #3
    a614:	8b020060 	add	x0, x3, x2
    a618:	f9401017 	ldr	x23, [x0, #32]
    a61c:	b4000257 	cbz	x23, a664 <f0+0x6f4>
    a620:	38626862 	ldrb	w2, [x3, x2]
    a624:	7100085f 	cmp	w2, #0x2
    a628:	5400e540 	b.eq	c2d0 <f0+0x2360>  // b.none
    a62c:	7100045f 	cmp	w2, #0x1
    a630:	540001a1 	b.ne	a664 <f0+0x6f4>  // b.any
    a634:	29430002 	ldp	w2, w0, [x0, #24]
    a638:	92403c21 	and	x1, x1, #0xffff
    a63c:	9b027c21 	mul	x1, x1, x2
    a640:	d360fc21 	lsr	x1, x1, #32
    a644:	eb00003f 	cmp	x1, x0
    a648:	540000e2 	b.cs	a664 <f0+0x6f4>  // b.hs, b.nlast
    a64c:	8b0102f7 	add	x23, x23, x1
    a650:	394002e0 	ldrb	w0, [x23]
    a654:	7103fc1f 	cmp	w0, #0xff
    a658:	5400eea0 	b.eq	c42c <f0+0x24bc>  // b.none
    a65c:	52800020 	mov	w0, #0x1                   	// #1
    a660:	390002e0 	strb	w0, [x23]
    a664:	910a63e1 	add	x1, sp, #0x298
    a668:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a66c:	52800020 	mov	w0, #0x1                   	// #1
    a670:	f9014fe2 	str	x2, [sp, #664]
    a674:	f90153f5 	str	x21, [sp, #672]
    a678:	97ffeb07 	bl	5294 <fwp_data.part.0.constprop.0>
    a67c:	97ffec7e 	bl	5874 <fwp_rc_fresh>
    a680:	aa0003e2 	mov	x2, x0
    a684:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a688:	910aa3e1 	add	x1, sp, #0x2a8
    a68c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a690:	52800020 	mov	w0, #0x1                   	// #1
    a694:	f90157e3 	str	x3, [sp, #680]
    a698:	f9015be2 	str	x2, [sp, #688]
    a69c:	97ffeafe 	bl	5294 <fwp_data.part.0.constprop.0>
    a6a0:	9118c283 	add	x3, x20, #0x630
    a6a4:	aa0003f5 	mov	x21, x0
    a6a8:	f949d861 	ldr	x1, [x3, #5040]
    a6ac:	f949ec60 	ldr	x0, [x3, #5080]
    a6b0:	cb0102a1 	sub	x1, x21, x1
    a6b4:	eb00403f 	cmp	x1, x0, lsl #16
    a6b8:	54000322 	b.cs	a71c <f0+0x7ac>  // b.hs, b.nlast
    a6bc:	d350fc22 	lsr	x2, x1, #16
    a6c0:	f949fc63 	ldr	x3, [x3, #5112]
    a6c4:	8b020842 	add	x2, x2, x2, lsl #2
    a6c8:	d37df042 	lsl	x2, x2, #3
    a6cc:	8b020060 	add	x0, x3, x2
    a6d0:	f9401017 	ldr	x23, [x0, #32]
    a6d4:	b4000257 	cbz	x23, a71c <f0+0x7ac>
    a6d8:	38626862 	ldrb	w2, [x3, x2]
    a6dc:	7100085f 	cmp	w2, #0x2
    a6e0:	5400df20 	b.eq	c2c4 <f0+0x2354>  // b.none
    a6e4:	7100045f 	cmp	w2, #0x1
    a6e8:	540001a1 	b.ne	a71c <f0+0x7ac>  // b.any
    a6ec:	29430002 	ldp	w2, w0, [x0, #24]
    a6f0:	92403c21 	and	x1, x1, #0xffff
    a6f4:	9b027c21 	mul	x1, x1, x2
    a6f8:	d360fc21 	lsr	x1, x1, #32
    a6fc:	eb00003f 	cmp	x1, x0
    a700:	540000e2 	b.cs	a71c <f0+0x7ac>  // b.hs, b.nlast
    a704:	8b0102f7 	add	x23, x23, x1
    a708:	394002e0 	ldrb	w0, [x23]
    a70c:	7103fc1f 	cmp	w0, #0xff
    a710:	5400e940 	b.eq	c438 <f0+0x24c8>  // b.none
    a714:	52800020 	mov	w0, #0x1                   	// #1
    a718:	390002e0 	strb	w0, [x23]
    a71c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a720:	910ae3e1 	add	x1, sp, #0x2b8
    a724:	52800020 	mov	w0, #0x1                   	// #1
    a728:	f9015fe2 	str	x2, [sp, #696]
    a72c:	f90163f5 	str	x21, [sp, #704]
    a730:	97ffead9 	bl	5294 <fwp_data.part.0.constprop.0>
    a734:	9118c283 	add	x3, x20, #0x630
    a738:	aa0003f5 	mov	x21, x0
    a73c:	f949d861 	ldr	x1, [x3, #5040]
    a740:	f949ec60 	ldr	x0, [x3, #5080]
    a744:	cb0102a1 	sub	x1, x21, x1
    a748:	eb00403f 	cmp	x1, x0, lsl #16
    a74c:	54000322 	b.cs	a7b0 <f0+0x840>  // b.hs, b.nlast
    a750:	d350fc22 	lsr	x2, x1, #16
    a754:	f949fc63 	ldr	x3, [x3, #5112]
    a758:	8b020842 	add	x2, x2, x2, lsl #2
    a75c:	d37df042 	lsl	x2, x2, #3
    a760:	8b020060 	add	x0, x3, x2
    a764:	f9401017 	ldr	x23, [x0, #32]
    a768:	b4000257 	cbz	x23, a7b0 <f0+0x840>
    a76c:	38626862 	ldrb	w2, [x3, x2]
    a770:	7100085f 	cmp	w2, #0x2
    a774:	5400da20 	b.eq	c2b8 <f0+0x2348>  // b.none
    a778:	7100045f 	cmp	w2, #0x1
    a77c:	540001a1 	b.ne	a7b0 <f0+0x840>  // b.any
    a780:	29430002 	ldp	w2, w0, [x0, #24]
    a784:	92403c21 	and	x1, x1, #0xffff
    a788:	9b027c21 	mul	x1, x1, x2
    a78c:	d360fc21 	lsr	x1, x1, #32
    a790:	eb00003f 	cmp	x1, x0
    a794:	540000e2 	b.cs	a7b0 <f0+0x840>  // b.hs, b.nlast
    a798:	8b0102f7 	add	x23, x23, x1
    a79c:	394002e0 	ldrb	w0, [x23]
    a7a0:	7103fc1f 	cmp	w0, #0xff
    a7a4:	5400e500 	b.eq	c444 <f0+0x24d4>  // b.none
    a7a8:	52800020 	mov	w0, #0x1                   	// #1
    a7ac:	390002e0 	strb	w0, [x23]
    a7b0:	910b23e1 	add	x1, sp, #0x2c8
    a7b4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a7b8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a7bc:	52800020 	mov	w0, #0x1                   	// #1
    a7c0:	f90167f7 	str	x23, [sp, #712]
    a7c4:	f9016bf5 	str	x21, [sp, #720]
    a7c8:	97ffeab3 	bl	5294 <fwp_data.part.0.constprop.0>
    a7cc:	97ffec2a 	bl	5874 <fwp_rc_fresh>
    a7d0:	aa0003e2 	mov	x2, x0
    a7d4:	910b63e1 	add	x1, sp, #0x2d8
    a7d8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a7dc:	52800020 	mov	w0, #0x1                   	// #1
    a7e0:	f9016ff5 	str	x21, [sp, #728]
    a7e4:	f90173e2 	str	x2, [sp, #736]
    a7e8:	97ffeaab 	bl	5294 <fwp_data.part.0.constprop.0>
    a7ec:	97ffec22 	bl	5874 <fwp_rc_fresh>
    a7f0:	aa0003e2 	mov	x2, x0
    a7f4:	910ba3e1 	add	x1, sp, #0x2e8
    a7f8:	52800020 	mov	w0, #0x1                   	// #1
    a7fc:	f90177f7 	str	x23, [sp, #744]
    a800:	f9017be2 	str	x2, [sp, #752]
    a804:	97ffeaa4 	bl	5294 <fwp_data.part.0.constprop.0>
    a808:	97ffec1b 	bl	5874 <fwp_rc_fresh>
    a80c:	aa0003e2 	mov	x2, x0
    a810:	910be3e1 	add	x1, sp, #0x2f8
    a814:	52800020 	mov	w0, #0x1                   	// #1
    a818:	f9017ff5 	str	x21, [sp, #760]
    a81c:	f90183e2 	str	x2, [sp, #768]
    a820:	97ffea9d 	bl	5294 <fwp_data.part.0.constprop.0>
    a824:	9118c283 	add	x3, x20, #0x630
    a828:	aa0003f5 	mov	x21, x0
    a82c:	f949d861 	ldr	x1, [x3, #5040]
    a830:	f949ec60 	ldr	x0, [x3, #5080]
    a834:	cb0102a1 	sub	x1, x21, x1
    a838:	eb00403f 	cmp	x1, x0, lsl #16
    a83c:	54000322 	b.cs	a8a0 <f0+0x930>  // b.hs, b.nlast
    a840:	d350fc22 	lsr	x2, x1, #16
    a844:	f949fc63 	ldr	x3, [x3, #5112]
    a848:	8b020842 	add	x2, x2, x2, lsl #2
    a84c:	d37df042 	lsl	x2, x2, #3
    a850:	8b020060 	add	x0, x3, x2
    a854:	f9401017 	ldr	x23, [x0, #32]
    a858:	b4000257 	cbz	x23, a8a0 <f0+0x930>
    a85c:	38626862 	ldrb	w2, [x3, x2]
    a860:	7100085f 	cmp	w2, #0x2
    a864:	5400d240 	b.eq	c2ac <f0+0x233c>  // b.none
    a868:	7100045f 	cmp	w2, #0x1
    a86c:	540001a1 	b.ne	a8a0 <f0+0x930>  // b.any
    a870:	29430002 	ldp	w2, w0, [x0, #24]
    a874:	92403c21 	and	x1, x1, #0xffff
    a878:	9b027c21 	mul	x1, x1, x2
    a87c:	d360fc21 	lsr	x1, x1, #32
    a880:	eb00003f 	cmp	x1, x0
    a884:	540000e2 	b.cs	a8a0 <f0+0x930>  // b.hs, b.nlast
    a888:	8b0102f7 	add	x23, x23, x1
    a88c:	394002e0 	ldrb	w0, [x23]
    a890:	7103fc1f 	cmp	w0, #0xff
    a894:	5400dde0 	b.eq	c450 <f0+0x24e0>  // b.none
    a898:	52800020 	mov	w0, #0x1                   	// #1
    a89c:	390002e0 	strb	w0, [x23]
    a8a0:	910c23e1 	add	x1, sp, #0x308
    a8a4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a8a8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a8ac:	52800020 	mov	w0, #0x1                   	// #1
    a8b0:	f90187f7 	str	x23, [sp, #776]
    a8b4:	f9018bf5 	str	x21, [sp, #784]
    a8b8:	97ffea77 	bl	5294 <fwp_data.part.0.constprop.0>
    a8bc:	97ffebee 	bl	5874 <fwp_rc_fresh>
    a8c0:	aa0003e2 	mov	x2, x0
    a8c4:	910c63e1 	add	x1, sp, #0x318
    a8c8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a8cc:	52800020 	mov	w0, #0x1                   	// #1
    a8d0:	f9018ff5 	str	x21, [sp, #792]
    a8d4:	f90193e2 	str	x2, [sp, #800]
    a8d8:	97ffea6f 	bl	5294 <fwp_data.part.0.constprop.0>
    a8dc:	97ffebe6 	bl	5874 <fwp_rc_fresh>
    a8e0:	aa0003e2 	mov	x2, x0
    a8e4:	910ca3e1 	add	x1, sp, #0x328
    a8e8:	52800020 	mov	w0, #0x1                   	// #1
    a8ec:	f90197f7 	str	x23, [sp, #808]
    a8f0:	f9019be2 	str	x2, [sp, #816]
    a8f4:	97ffea68 	bl	5294 <fwp_data.part.0.constprop.0>
    a8f8:	97ffebdf 	bl	5874 <fwp_rc_fresh>
    a8fc:	aa0003e2 	mov	x2, x0
    a900:	910ce3e1 	add	x1, sp, #0x338
    a904:	52800020 	mov	w0, #0x1                   	// #1
    a908:	f9019ff5 	str	x21, [sp, #824]
    a90c:	f901a3e2 	str	x2, [sp, #832]
    a910:	97ffea61 	bl	5294 <fwp_data.part.0.constprop.0>
    a914:	97ffebd8 	bl	5874 <fwp_rc_fresh>
    a918:	aa0003e2 	mov	x2, x0
    a91c:	910d23e1 	add	x1, sp, #0x348
    a920:	52800020 	mov	w0, #0x1                   	// #1
    a924:	f901a7f7 	str	x23, [sp, #840]
    a928:	f901abe2 	str	x2, [sp, #848]
    a92c:	97ffea5a 	bl	5294 <fwp_data.part.0.constprop.0>
    a930:	97ffebd1 	bl	5874 <fwp_rc_fresh>
    a934:	aa0003e2 	mov	x2, x0
    a938:	910d63e1 	add	x1, sp, #0x358
    a93c:	52800020 	mov	w0, #0x1                   	// #1
    a940:	f901aff5 	str	x21, [sp, #856]
    a944:	f901b3e2 	str	x2, [sp, #864]
    a948:	97ffea53 	bl	5294 <fwp_data.part.0.constprop.0>
    a94c:	97ffebca 	bl	5874 <fwp_rc_fresh>
    a950:	aa0003e2 	mov	x2, x0
    a954:	910da3e1 	add	x1, sp, #0x368
    a958:	52800020 	mov	w0, #0x1                   	// #1
    a95c:	f901b7f7 	str	x23, [sp, #872]
    a960:	f901bbe2 	str	x2, [sp, #880]
    a964:	97ffea4c 	bl	5294 <fwp_data.part.0.constprop.0>
    a968:	97ffebc3 	bl	5874 <fwp_rc_fresh>
    a96c:	aa0003e2 	mov	x2, x0
    a970:	910de3e1 	add	x1, sp, #0x378
    a974:	52800020 	mov	w0, #0x1                   	// #1
    a978:	f901bff5 	str	x21, [sp, #888]
    a97c:	f901c3e2 	str	x2, [sp, #896]
    a980:	97ffea45 	bl	5294 <fwp_data.part.0.constprop.0>
    a984:	97ffebbc 	bl	5874 <fwp_rc_fresh>
    a988:	aa0003e2 	mov	x2, x0
    a98c:	910e23e1 	add	x1, sp, #0x388
    a990:	52800020 	mov	w0, #0x1                   	// #1
    a994:	f901c7f7 	str	x23, [sp, #904]
    a998:	f901cbe2 	str	x2, [sp, #912]
    a99c:	97ffea3e 	bl	5294 <fwp_data.part.0.constprop.0>
    a9a0:	97ffebb5 	bl	5874 <fwp_rc_fresh>
    a9a4:	aa0003e2 	mov	x2, x0
    a9a8:	910e63e1 	add	x1, sp, #0x398
    a9ac:	52800020 	mov	w0, #0x1                   	// #1
    a9b0:	f901cff5 	str	x21, [sp, #920]
    a9b4:	f901d3e2 	str	x2, [sp, #928]
    a9b8:	97ffea37 	bl	5294 <fwp_data.part.0.constprop.0>
    a9bc:	9118c283 	add	x3, x20, #0x630
    a9c0:	aa0003f5 	mov	x21, x0
    a9c4:	f949d861 	ldr	x1, [x3, #5040]
    a9c8:	f949ec60 	ldr	x0, [x3, #5080]
    a9cc:	cb0102a1 	sub	x1, x21, x1
    a9d0:	eb00403f 	cmp	x1, x0, lsl #16
    a9d4:	54000322 	b.cs	aa38 <f0+0xac8>  // b.hs, b.nlast
    a9d8:	d350fc22 	lsr	x2, x1, #16
    a9dc:	f949fc63 	ldr	x3, [x3, #5112]
    a9e0:	8b020842 	add	x2, x2, x2, lsl #2
    a9e4:	d37df042 	lsl	x2, x2, #3
    a9e8:	8b020060 	add	x0, x3, x2
    a9ec:	f9401017 	ldr	x23, [x0, #32]
    a9f0:	b4000257 	cbz	x23, aa38 <f0+0xac8>
    a9f4:	38626862 	ldrb	w2, [x3, x2]
    a9f8:	7100085f 	cmp	w2, #0x2
    a9fc:	5400c9a0 	b.eq	c330 <f0+0x23c0>  // b.none
    aa00:	7100045f 	cmp	w2, #0x1
    aa04:	540001a1 	b.ne	aa38 <f0+0xac8>  // b.any
    aa08:	29430002 	ldp	w2, w0, [x0, #24]
    aa0c:	92403c21 	and	x1, x1, #0xffff
    aa10:	9b027c21 	mul	x1, x1, x2
    aa14:	d360fc21 	lsr	x1, x1, #32
    aa18:	eb00003f 	cmp	x1, x0
    aa1c:	540000e2 	b.cs	aa38 <f0+0xac8>  // b.hs, b.nlast
    aa20:	8b0102f7 	add	x23, x23, x1
    aa24:	394002e0 	ldrb	w0, [x23]
    aa28:	7103fc1f 	cmp	w0, #0xff
    aa2c:	5400d180 	b.eq	c45c <f0+0x24ec>  // b.none
    aa30:	52800020 	mov	w0, #0x1                   	// #1
    aa34:	390002e0 	strb	w0, [x23]
    aa38:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aa3c:	910ea3e1 	add	x1, sp, #0x3a8
    aa40:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aa44:	52800020 	mov	w0, #0x1                   	// #1
    aa48:	f901d7e2 	str	x2, [sp, #936]
    aa4c:	f901dbf5 	str	x21, [sp, #944]
    aa50:	97ffea11 	bl	5294 <fwp_data.part.0.constprop.0>
    aa54:	97ffeb88 	bl	5874 <fwp_rc_fresh>
    aa58:	aa0003e2 	mov	x2, x0
    aa5c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aa60:	910ee3e1 	add	x1, sp, #0x3b8
    aa64:	52800020 	mov	w0, #0x1                   	// #1
    aa68:	f901dfe3 	str	x3, [sp, #952]
    aa6c:	f901e3e2 	str	x2, [sp, #960]
    aa70:	97ffea09 	bl	5294 <fwp_data.part.0.constprop.0>
    aa74:	9118c283 	add	x3, x20, #0x630
    aa78:	aa0003f5 	mov	x21, x0
    aa7c:	f949d861 	ldr	x1, [x3, #5040]
    aa80:	f949ec60 	ldr	x0, [x3, #5080]
    aa84:	cb0102a1 	sub	x1, x21, x1
    aa88:	eb00403f 	cmp	x1, x0, lsl #16
    aa8c:	54000322 	b.cs	aaf0 <f0+0xb80>  // b.hs, b.nlast
    aa90:	d350fc22 	lsr	x2, x1, #16
    aa94:	f949fc63 	ldr	x3, [x3, #5112]
    aa98:	8b020842 	add	x2, x2, x2, lsl #2
    aa9c:	d37df042 	lsl	x2, x2, #3
    aaa0:	8b020060 	add	x0, x3, x2
    aaa4:	f9401017 	ldr	x23, [x0, #32]
    aaa8:	b4000257 	cbz	x23, aaf0 <f0+0xb80>
    aaac:	38626862 	ldrb	w2, [x3, x2]
    aab0:	7100085f 	cmp	w2, #0x2
    aab4:	5400c380 	b.eq	c324 <f0+0x23b4>  // b.none
    aab8:	7100045f 	cmp	w2, #0x1
    aabc:	540001a1 	b.ne	aaf0 <f0+0xb80>  // b.any
    aac0:	29430002 	ldp	w2, w0, [x0, #24]
    aac4:	92403c21 	and	x1, x1, #0xffff
    aac8:	9b027c21 	mul	x1, x1, x2
    aacc:	d360fc21 	lsr	x1, x1, #32
    aad0:	eb00003f 	cmp	x1, x0
    aad4:	540000e2 	b.cs	aaf0 <f0+0xb80>  // b.hs, b.nlast
    aad8:	8b0102f7 	add	x23, x23, x1
    aadc:	394002e0 	ldrb	w0, [x23]
    aae0:	7103fc1f 	cmp	w0, #0xff
    aae4:	5400cc20 	b.eq	c468 <f0+0x24f8>  // b.none
    aae8:	52800020 	mov	w0, #0x1                   	// #1
    aaec:	390002e0 	strb	w0, [x23]
    aaf0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aaf4:	910f23e1 	add	x1, sp, #0x3c8
    aaf8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aafc:	52800020 	mov	w0, #0x1                   	// #1
    ab00:	f901e7e2 	str	x2, [sp, #968]
    ab04:	f901ebf5 	str	x21, [sp, #976]
    ab08:	97ffe9e3 	bl	5294 <fwp_data.part.0.constprop.0>
    ab0c:	97ffeb5a 	bl	5874 <fwp_rc_fresh>
    ab10:	aa0003e2 	mov	x2, x0
    ab14:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ab18:	910f63e1 	add	x1, sp, #0x3d8
    ab1c:	52800020 	mov	w0, #0x1                   	// #1
    ab20:	f901efe3 	str	x3, [sp, #984]
    ab24:	f901f3e2 	str	x2, [sp, #992]
    ab28:	97ffe9db 	bl	5294 <fwp_data.part.0.constprop.0>
    ab2c:	9118c283 	add	x3, x20, #0x630
    ab30:	aa0003f7 	mov	x23, x0
    ab34:	f949d861 	ldr	x1, [x3, #5040]
    ab38:	f949ec60 	ldr	x0, [x3, #5080]
    ab3c:	cb0102e1 	sub	x1, x23, x1
    ab40:	eb00403f 	cmp	x1, x0, lsl #16
    ab44:	54000322 	b.cs	aba8 <f0+0xc38>  // b.hs, b.nlast
    ab48:	d350fc22 	lsr	x2, x1, #16
    ab4c:	f949fc63 	ldr	x3, [x3, #5112]
    ab50:	8b020842 	add	x2, x2, x2, lsl #2
    ab54:	d37df042 	lsl	x2, x2, #3
    ab58:	8b020060 	add	x0, x3, x2
    ab5c:	f9401015 	ldr	x21, [x0, #32]
    ab60:	b4000255 	cbz	x21, aba8 <f0+0xc38>
    ab64:	38626862 	ldrb	w2, [x3, x2]
    ab68:	7100085f 	cmp	w2, #0x2
    ab6c:	5400bd60 	b.eq	c318 <f0+0x23a8>  // b.none
    ab70:	7100045f 	cmp	w2, #0x1
    ab74:	540001a1 	b.ne	aba8 <f0+0xc38>  // b.any
    ab78:	29430002 	ldp	w2, w0, [x0, #24]
    ab7c:	92403c21 	and	x1, x1, #0xffff
    ab80:	9b027c21 	mul	x1, x1, x2
    ab84:	d360fc21 	lsr	x1, x1, #32
    ab88:	eb00003f 	cmp	x1, x0
    ab8c:	540000e2 	b.cs	aba8 <f0+0xc38>  // b.hs, b.nlast
    ab90:	8b0102b5 	add	x21, x21, x1
    ab94:	394002a0 	ldrb	w0, [x21]
    ab98:	7103fc1f 	cmp	w0, #0xff
    ab9c:	5400c6c0 	b.eq	c474 <f0+0x2504>  // b.none
    aba0:	52800020 	mov	w0, #0x1                   	// #1
    aba4:	390002a0 	strb	w0, [x21]
    aba8:	910fa3e1 	add	x1, sp, #0x3e8
    abac:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    abb0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    abb4:	52800020 	mov	w0, #0x1                   	// #1
    abb8:	f901f7f5 	str	x21, [sp, #1000]
    abbc:	f901fbf7 	str	x23, [sp, #1008]
    abc0:	97ffe9b5 	bl	5294 <fwp_data.part.0.constprop.0>
    abc4:	97ffeb2c 	bl	5874 <fwp_rc_fresh>
    abc8:	aa0003e2 	mov	x2, x0
    abcc:	910fe3e1 	add	x1, sp, #0x3f8
    abd0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    abd4:	52800020 	mov	w0, #0x1                   	// #1
    abd8:	f901fff7 	str	x23, [sp, #1016]
    abdc:	f90203e2 	str	x2, [sp, #1024]
    abe0:	97ffe9ad 	bl	5294 <fwp_data.part.0.constprop.0>
    abe4:	97ffeb24 	bl	5874 <fwp_rc_fresh>
    abe8:	aa0003e2 	mov	x2, x0
    abec:	911023e1 	add	x1, sp, #0x408
    abf0:	52800020 	mov	w0, #0x1                   	// #1
    abf4:	f90207f5 	str	x21, [sp, #1032]
    abf8:	f9020be2 	str	x2, [sp, #1040]
    abfc:	97ffe9a6 	bl	5294 <fwp_data.part.0.constprop.0>
    ac00:	97ffeb1d 	bl	5874 <fwp_rc_fresh>
    ac04:	aa0003e2 	mov	x2, x0
    ac08:	911063e1 	add	x1, sp, #0x418
    ac0c:	52800020 	mov	w0, #0x1                   	// #1
    ac10:	f9020ff7 	str	x23, [sp, #1048]
    ac14:	f90213e2 	str	x2, [sp, #1056]
    ac18:	97ffe99f 	bl	5294 <fwp_data.part.0.constprop.0>
    ac1c:	97ffeb16 	bl	5874 <fwp_rc_fresh>
    ac20:	aa0003e2 	mov	x2, x0
    ac24:	9110a3e1 	add	x1, sp, #0x428
    ac28:	52800020 	mov	w0, #0x1                   	// #1
    ac2c:	f90217f5 	str	x21, [sp, #1064]
    ac30:	f9021be2 	str	x2, [sp, #1072]
    ac34:	97ffe998 	bl	5294 <fwp_data.part.0.constprop.0>
    ac38:	97ffeb0f 	bl	5874 <fwp_rc_fresh>
    ac3c:	aa0003e2 	mov	x2, x0
    ac40:	9110e3e1 	add	x1, sp, #0x438
    ac44:	52800020 	mov	w0, #0x1                   	// #1
    ac48:	f9021ff7 	str	x23, [sp, #1080]
    ac4c:	f90223e2 	str	x2, [sp, #1088]
    ac50:	97ffe991 	bl	5294 <fwp_data.part.0.constprop.0>
    ac54:	97ffeb08 	bl	5874 <fwp_rc_fresh>
    ac58:	aa0003e2 	mov	x2, x0
    ac5c:	911123e1 	add	x1, sp, #0x448
    ac60:	52800020 	mov	w0, #0x1                   	// #1
    ac64:	f90227f5 	str	x21, [sp, #1096]
    ac68:	f9022be2 	str	x2, [sp, #1104]
    ac6c:	97ffe98a 	bl	5294 <fwp_data.part.0.constprop.0>
    ac70:	9118c283 	add	x3, x20, #0x630
    ac74:	aa0003f5 	mov	x21, x0
    ac78:	f949d861 	ldr	x1, [x3, #5040]
    ac7c:	f949ec60 	ldr	x0, [x3, #5080]
    ac80:	cb0102a1 	sub	x1, x21, x1
    ac84:	eb00403f 	cmp	x1, x0, lsl #16
    ac88:	54000322 	b.cs	acec <f0+0xd7c>  // b.hs, b.nlast
    ac8c:	d350fc22 	lsr	x2, x1, #16
    ac90:	f949fc63 	ldr	x3, [x3, #5112]
    ac94:	8b020842 	add	x2, x2, x2, lsl #2
    ac98:	d37df042 	lsl	x2, x2, #3
    ac9c:	8b020060 	add	x0, x3, x2
    aca0:	f9401017 	ldr	x23, [x0, #32]
    aca4:	b4000257 	cbz	x23, acec <f0+0xd7c>
    aca8:	38626862 	ldrb	w2, [x3, x2]
    acac:	7100085f 	cmp	w2, #0x2
    acb0:	5400b2e0 	b.eq	c30c <f0+0x239c>  // b.none
    acb4:	7100045f 	cmp	w2, #0x1
    acb8:	540001a1 	b.ne	acec <f0+0xd7c>  // b.any
    acbc:	29430002 	ldp	w2, w0, [x0, #24]
    acc0:	92403c21 	and	x1, x1, #0xffff
    acc4:	9b027c21 	mul	x1, x1, x2
    acc8:	d360fc21 	lsr	x1, x1, #32
    accc:	eb00003f 	cmp	x1, x0
    acd0:	540000e2 	b.cs	acec <f0+0xd7c>  // b.hs, b.nlast
    acd4:	8b0102f7 	add	x23, x23, x1
    acd8:	394002e0 	ldrb	w0, [x23]
    acdc:	7103fc1f 	cmp	w0, #0xff
    ace0:	5400bd00 	b.eq	c480 <f0+0x2510>  // b.none
    ace4:	52800020 	mov	w0, #0x1                   	// #1
    ace8:	390002e0 	strb	w0, [x23]
    acec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    acf0:	911163e1 	add	x1, sp, #0x458
    acf4:	52800020 	mov	w0, #0x1                   	// #1
    acf8:	f9022fe2 	str	x2, [sp, #1112]
    acfc:	f90233f5 	str	x21, [sp, #1120]
    ad00:	97ffe965 	bl	5294 <fwp_data.part.0.constprop.0>
    ad04:	9118c283 	add	x3, x20, #0x630
    ad08:	aa0003f5 	mov	x21, x0
    ad0c:	f949d861 	ldr	x1, [x3, #5040]
    ad10:	f949ec60 	ldr	x0, [x3, #5080]
    ad14:	cb0102a1 	sub	x1, x21, x1
    ad18:	eb00403f 	cmp	x1, x0, lsl #16
    ad1c:	54000322 	b.cs	ad80 <f0+0xe10>  // b.hs, b.nlast
    ad20:	d350fc22 	lsr	x2, x1, #16
    ad24:	f949fc63 	ldr	x3, [x3, #5112]
    ad28:	8b020842 	add	x2, x2, x2, lsl #2
    ad2c:	d37df042 	lsl	x2, x2, #3
    ad30:	8b020060 	add	x0, x3, x2
    ad34:	f9401017 	ldr	x23, [x0, #32]
    ad38:	b4000257 	cbz	x23, ad80 <f0+0xe10>
    ad3c:	38626862 	ldrb	w2, [x3, x2]
    ad40:	7100085f 	cmp	w2, #0x2
    ad44:	5400ade0 	b.eq	c300 <f0+0x2390>  // b.none
    ad48:	7100045f 	cmp	w2, #0x1
    ad4c:	540001a1 	b.ne	ad80 <f0+0xe10>  // b.any
    ad50:	29430002 	ldp	w2, w0, [x0, #24]
    ad54:	92403c21 	and	x1, x1, #0xffff
    ad58:	9b027c21 	mul	x1, x1, x2
    ad5c:	d360fc21 	lsr	x1, x1, #32
    ad60:	eb00003f 	cmp	x1, x0
    ad64:	540000e2 	b.cs	ad80 <f0+0xe10>  // b.hs, b.nlast
    ad68:	8b0102f7 	add	x23, x23, x1
    ad6c:	394002e0 	ldrb	w0, [x23]
    ad70:	7103fc1f 	cmp	w0, #0xff
    ad74:	5400b8c0 	b.eq	c48c <f0+0x251c>  // b.none
    ad78:	52800020 	mov	w0, #0x1                   	// #1
    ad7c:	390002e0 	strb	w0, [x23]
    ad80:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ad84:	9111a3e1 	add	x1, sp, #0x468
    ad88:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ad8c:	52800020 	mov	w0, #0x1                   	// #1
    ad90:	f90237e2 	str	x2, [sp, #1128]
    ad94:	f9023bf5 	str	x21, [sp, #1136]
    ad98:	97ffe93f 	bl	5294 <fwp_data.part.0.constprop.0>
    ad9c:	97ffeab6 	bl	5874 <fwp_rc_fresh>
    ada0:	aa0003e2 	mov	x2, x0
    ada4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ada8:	9111e3e1 	add	x1, sp, #0x478
    adac:	52800020 	mov	w0, #0x1                   	// #1
    adb0:	f9023fe3 	str	x3, [sp, #1144]
    adb4:	f90243e2 	str	x2, [sp, #1152]
    adb8:	97ffe937 	bl	5294 <fwp_data.part.0.constprop.0>
    adbc:	9118c283 	add	x3, x20, #0x630
    adc0:	aa0003f5 	mov	x21, x0
    adc4:	f949d861 	ldr	x1, [x3, #5040]
    adc8:	f949ec60 	ldr	x0, [x3, #5080]
    adcc:	cb0102a1 	sub	x1, x21, x1
    add0:	eb00403f 	cmp	x1, x0, lsl #16
    add4:	54000322 	b.cs	ae38 <f0+0xec8>  // b.hs, b.nlast
    add8:	d350fc22 	lsr	x2, x1, #16
    addc:	f949fc63 	ldr	x3, [x3, #5112]
    ade0:	8b020842 	add	x2, x2, x2, lsl #2
    ade4:	d37df042 	lsl	x2, x2, #3
    ade8:	8b020060 	add	x0, x3, x2
    adec:	f9401017 	ldr	x23, [x0, #32]
    adf0:	b4000257 	cbz	x23, ae38 <f0+0xec8>
    adf4:	38626862 	ldrb	w2, [x3, x2]
    adf8:	7100085f 	cmp	w2, #0x2
    adfc:	5400a7c0 	b.eq	c2f4 <f0+0x2384>  // b.none
    ae00:	7100045f 	cmp	w2, #0x1
    ae04:	540001a1 	b.ne	ae38 <f0+0xec8>  // b.any
    ae08:	29430002 	ldp	w2, w0, [x0, #24]
    ae0c:	92403c21 	and	x1, x1, #0xffff
    ae10:	9b027c21 	mul	x1, x1, x2
    ae14:	d360fc21 	lsr	x1, x1, #32
    ae18:	eb00003f 	cmp	x1, x0
    ae1c:	540000e2 	b.cs	ae38 <f0+0xec8>  // b.hs, b.nlast
    ae20:	8b0102f7 	add	x23, x23, x1
    ae24:	394002e0 	ldrb	w0, [x23]
    ae28:	7103fc1f 	cmp	w0, #0xff
    ae2c:	5400b360 	b.eq	c498 <f0+0x2528>  // b.none
    ae30:	52800020 	mov	w0, #0x1                   	// #1
    ae34:	390002e0 	strb	w0, [x23]
    ae38:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ae3c:	911223e1 	add	x1, sp, #0x488
    ae40:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ae44:	52800020 	mov	w0, #0x1                   	// #1
    ae48:	f90247e2 	str	x2, [sp, #1160]
    ae4c:	f9024bf5 	str	x21, [sp, #1168]
    ae50:	97ffe911 	bl	5294 <fwp_data.part.0.constprop.0>
    ae54:	97ffea88 	bl	5874 <fwp_rc_fresh>
    ae58:	aa0003e2 	mov	x2, x0
    ae5c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ae60:	911263e1 	add	x1, sp, #0x498
    ae64:	52800020 	mov	w0, #0x1                   	// #1
    ae68:	f9024fe3 	str	x3, [sp, #1176]
    ae6c:	f90253e2 	str	x2, [sp, #1184]
    ae70:	97ffe909 	bl	5294 <fwp_data.part.0.constprop.0>
    ae74:	9118c283 	add	x3, x20, #0x630
    ae78:	aa0003f5 	mov	x21, x0
    ae7c:	f949d861 	ldr	x1, [x3, #5040]
    ae80:	f949ec60 	ldr	x0, [x3, #5080]
    ae84:	cb0102a1 	sub	x1, x21, x1
    ae88:	eb00403f 	cmp	x1, x0, lsl #16
    ae8c:	54000322 	b.cs	aef0 <f0+0xf80>  // b.hs, b.nlast
    ae90:	d350fc22 	lsr	x2, x1, #16
    ae94:	f949fc63 	ldr	x3, [x3, #5112]
    ae98:	8b020842 	add	x2, x2, x2, lsl #2
    ae9c:	d37df042 	lsl	x2, x2, #3
    aea0:	8b020060 	add	x0, x3, x2
    aea4:	f9401017 	ldr	x23, [x0, #32]
    aea8:	b4000257 	cbz	x23, aef0 <f0+0xf80>
    aeac:	38626862 	ldrb	w2, [x3, x2]
    aeb0:	7100085f 	cmp	w2, #0x2
    aeb4:	5400a1a0 	b.eq	c2e8 <f0+0x2378>  // b.none
    aeb8:	7100045f 	cmp	w2, #0x1
    aebc:	540001a1 	b.ne	aef0 <f0+0xf80>  // b.any
    aec0:	29430002 	ldp	w2, w0, [x0, #24]
    aec4:	92403c21 	and	x1, x1, #0xffff
    aec8:	9b027c21 	mul	x1, x1, x2
    aecc:	d360fc21 	lsr	x1, x1, #32
    aed0:	eb00003f 	cmp	x1, x0
    aed4:	540000e2 	b.cs	aef0 <f0+0xf80>  // b.hs, b.nlast
    aed8:	8b0102f7 	add	x23, x23, x1
    aedc:	394002e0 	ldrb	w0, [x23]
    aee0:	7103fc1f 	cmp	w0, #0xff
    aee4:	5400ae00 	b.eq	c4a4 <f0+0x2534>  // b.none
    aee8:	52800020 	mov	w0, #0x1                   	// #1
    aeec:	390002e0 	strb	w0, [x23]
    aef0:	9112a3e1 	add	x1, sp, #0x4a8
    aef4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aef8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    aefc:	52800020 	mov	w0, #0x1                   	// #1
    af00:	f90257f7 	str	x23, [sp, #1192]
    af04:	f9025bf5 	str	x21, [sp, #1200]
    af08:	97ffe8e3 	bl	5294 <fwp_data.part.0.constprop.0>
    af0c:	97ffea5a 	bl	5874 <fwp_rc_fresh>
    af10:	aa0003e2 	mov	x2, x0
    af14:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    af18:	9112e3e1 	add	x1, sp, #0x4b8
    af1c:	52800020 	mov	w0, #0x1                   	// #1
    af20:	f9025fe3 	str	x3, [sp, #1208]
    af24:	f90263e2 	str	x2, [sp, #1216]
    af28:	97ffe8db 	bl	5294 <fwp_data.part.0.constprop.0>
    af2c:	97ffea52 	bl	5874 <fwp_rc_fresh>
    af30:	aa0003e2 	mov	x2, x0
    af34:	911323e1 	add	x1, sp, #0x4c8
    af38:	52800020 	mov	w0, #0x1                   	// #1
    af3c:	f90267f7 	str	x23, [sp, #1224]
    af40:	f9026be2 	str	x2, [sp, #1232]
    af44:	97ffe8d4 	bl	5294 <fwp_data.part.0.constprop.0>
    af48:	9118c283 	add	x3, x20, #0x630
    af4c:	aa0003f5 	mov	x21, x0
    af50:	f949d861 	ldr	x1, [x3, #5040]
    af54:	f949ec60 	ldr	x0, [x3, #5080]
    af58:	cb0102a1 	sub	x1, x21, x1
    af5c:	eb00403f 	cmp	x1, x0, lsl #16
    af60:	54000322 	b.cs	afc4 <f0+0x1054>  // b.hs, b.nlast
    af64:	d350fc22 	lsr	x2, x1, #16
    af68:	f949fc63 	ldr	x3, [x3, #5112]
    af6c:	8b020842 	add	x2, x2, x2, lsl #2
    af70:	d37df042 	lsl	x2, x2, #3
    af74:	8b020060 	add	x0, x3, x2
    af78:	f9401017 	ldr	x23, [x0, #32]
    af7c:	b4000257 	cbz	x23, afc4 <f0+0x1054>
    af80:	38626862 	ldrb	w2, [x3, x2]
    af84:	7100085f 	cmp	w2, #0x2
    af88:	54009aa0 	b.eq	c2dc <f0+0x236c>  // b.none
    af8c:	7100045f 	cmp	w2, #0x1
    af90:	540001a1 	b.ne	afc4 <f0+0x1054>  // b.any
    af94:	29430002 	ldp	w2, w0, [x0, #24]
    af98:	92403c21 	and	x1, x1, #0xffff
    af9c:	9b027c21 	mul	x1, x1, x2
    afa0:	d360fc21 	lsr	x1, x1, #32
    afa4:	eb00003f 	cmp	x1, x0
    afa8:	540000e2 	b.cs	afc4 <f0+0x1054>  // b.hs, b.nlast
    afac:	8b0102f7 	add	x23, x23, x1
    afb0:	394002e0 	ldrb	w0, [x23]
    afb4:	7103fc1f 	cmp	w0, #0xff
    afb8:	5400a7c0 	b.eq	c4b0 <f0+0x2540>  // b.none
    afbc:	52800020 	mov	w0, #0x1                   	// #1
    afc0:	390002e0 	strb	w0, [x23]
    afc4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    afc8:	911363e1 	add	x1, sp, #0x4d8
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f9026fe2 	str	x2, [sp, #1240]
    afd4:	f90273f5 	str	x21, [sp, #1248]
    afd8:	97ffe8af 	bl	5294 <fwp_data.part.0.constprop.0>
    afdc:	9118c283 	add	x3, x20, #0x630
    afe0:	aa0003f5 	mov	x21, x0
    afe4:	f949d861 	ldr	x1, [x3, #5040]
    afe8:	f949ec60 	ldr	x0, [x3, #5080]
    afec:	cb0102a1 	sub	x1, x21, x1
    aff0:	eb00403f 	cmp	x1, x0, lsl #16
    aff4:	54000322 	b.cs	b058 <f0+0x10e8>  // b.hs, b.nlast
    aff8:	d350fc22 	lsr	x2, x1, #16
    affc:	f949fc63 	ldr	x3, [x3, #5112]
    b000:	8b020842 	add	x2, x2, x2, lsl #2
    b004:	d37df042 	lsl	x2, x2, #3
    b008:	8b020060 	add	x0, x3, x2
    b00c:	f9401017 	ldr	x23, [x0, #32]
    b010:	b4000257 	cbz	x23, b058 <f0+0x10e8>
    b014:	38626862 	ldrb	w2, [x3, x2]
    b018:	7100085f 	cmp	w2, #0x2
    b01c:	54009300 	b.eq	c27c <f0+0x230c>  // b.none
    b020:	7100045f 	cmp	w2, #0x1
    b024:	540001a1 	b.ne	b058 <f0+0x10e8>  // b.any
    b028:	29430002 	ldp	w2, w0, [x0, #24]
    b02c:	92403c21 	and	x1, x1, #0xffff
    b030:	9b027c21 	mul	x1, x1, x2
    b034:	d360fc21 	lsr	x1, x1, #32
    b038:	eb00003f 	cmp	x1, x0
    b03c:	540000e2 	b.cs	b058 <f0+0x10e8>  // b.hs, b.nlast
    b040:	8b0102f7 	add	x23, x23, x1
    b044:	394002e0 	ldrb	w0, [x23]
    b048:	7103fc1f 	cmp	w0, #0xff
    b04c:	5400a380 	b.eq	c4bc <f0+0x254c>  // b.none
    b050:	52800020 	mov	w0, #0x1                   	// #1
    b054:	390002e0 	strb	w0, [x23]
    b058:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b05c:	9113a3e1 	add	x1, sp, #0x4e8
    b060:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b064:	52800020 	mov	w0, #0x1                   	// #1
    b068:	f90277e2 	str	x2, [sp, #1256]
    b06c:	f9027bf5 	str	x21, [sp, #1264]
    b070:	97ffe889 	bl	5294 <fwp_data.part.0.constprop.0>
    b074:	97ffea00 	bl	5874 <fwp_rc_fresh>
    b078:	aa0003e2 	mov	x2, x0
    b07c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b080:	9113e3e1 	add	x1, sp, #0x4f8
    b084:	52800020 	mov	w0, #0x1                   	// #1
    b088:	f9027fe3 	str	x3, [sp, #1272]
    b08c:	f90283e2 	str	x2, [sp, #1280]
    b090:	97ffe881 	bl	5294 <fwp_data.part.0.constprop.0>
    b094:	9118c283 	add	x3, x20, #0x630
    b098:	aa0003f5 	mov	x21, x0
    b09c:	f949d861 	ldr	x1, [x3, #5040]
    b0a0:	f949ec60 	ldr	x0, [x3, #5080]
    b0a4:	cb0102a1 	sub	x1, x21, x1
    b0a8:	eb00403f 	cmp	x1, x0, lsl #16
    b0ac:	54000322 	b.cs	b110 <f0+0x11a0>  // b.hs, b.nlast
    b0b0:	d350fc22 	lsr	x2, x1, #16
    b0b4:	f949fc63 	ldr	x3, [x3, #5112]
    b0b8:	8b020842 	add	x2, x2, x2, lsl #2
    b0bc:	d37df042 	lsl	x2, x2, #3
    b0c0:	8b020060 	add	x0, x3, x2
    b0c4:	f9401017 	ldr	x23, [x0, #32]
    b0c8:	b4000257 	cbz	x23, b110 <f0+0x11a0>
    b0cc:	38626862 	ldrb	w2, [x3, x2]
    b0d0:	7100085f 	cmp	w2, #0x2
    b0d4:	54008ce0 	b.eq	c270 <f0+0x2300>  // b.none
    b0d8:	7100045f 	cmp	w2, #0x1
    b0dc:	540001a1 	b.ne	b110 <f0+0x11a0>  // b.any
    b0e0:	29430002 	ldp	w2, w0, [x0, #24]
    b0e4:	92403c21 	and	x1, x1, #0xffff
    b0e8:	9b027c21 	mul	x1, x1, x2
    b0ec:	d360fc21 	lsr	x1, x1, #32
    b0f0:	eb00003f 	cmp	x1, x0
    b0f4:	540000e2 	b.cs	b110 <f0+0x11a0>  // b.hs, b.nlast
    b0f8:	8b0102f7 	add	x23, x23, x1
    b0fc:	394002e0 	ldrb	w0, [x23]
    b100:	7103fc1f 	cmp	w0, #0xff
    b104:	54009e20 	b.eq	c4c8 <f0+0x2558>  // b.none
    b108:	52800020 	mov	w0, #0x1                   	// #1
    b10c:	390002e0 	strb	w0, [x23]
    b110:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b114:	911423e1 	add	x1, sp, #0x508
    b118:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b11c:	52800020 	mov	w0, #0x1                   	// #1
    b120:	f90287e2 	str	x2, [sp, #1288]
    b124:	f9028bf5 	str	x21, [sp, #1296]
    b128:	97ffe85b 	bl	5294 <fwp_data.part.0.constprop.0>
    b12c:	97ffe9d2 	bl	5874 <fwp_rc_fresh>
    b130:	aa0003e2 	mov	x2, x0
    b134:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b138:	911463e1 	add	x1, sp, #0x518
    b13c:	52800020 	mov	w0, #0x1                   	// #1
    b140:	f9028fe3 	str	x3, [sp, #1304]
    b144:	f90293e2 	str	x2, [sp, #1312]
    b148:	97ffe853 	bl	5294 <fwp_data.part.0.constprop.0>
    b14c:	9118c283 	add	x3, x20, #0x630
    b150:	aa0003f5 	mov	x21, x0
    b154:	f949d861 	ldr	x1, [x3, #5040]
    b158:	f949ec60 	ldr	x0, [x3, #5080]
    b15c:	cb0102a1 	sub	x1, x21, x1
    b160:	eb00403f 	cmp	x1, x0, lsl #16
    b164:	54000322 	b.cs	b1c8 <f0+0x1258>  // b.hs, b.nlast
    b168:	d350fc22 	lsr	x2, x1, #16
    b16c:	f949fc63 	ldr	x3, [x3, #5112]
    b170:	8b020842 	add	x2, x2, x2, lsl #2
    b174:	d37df042 	lsl	x2, x2, #3
    b178:	8b020060 	add	x0, x3, x2
    b17c:	f9401017 	ldr	x23, [x0, #32]
    b180:	b4000257 	cbz	x23, b1c8 <f0+0x1258>
    b184:	38626862 	ldrb	w2, [x3, x2]
    b188:	7100085f 	cmp	w2, #0x2
    b18c:	540086c0 	b.eq	c264 <f0+0x22f4>  // b.none
    b190:	7100045f 	cmp	w2, #0x1
    b194:	540001a1 	b.ne	b1c8 <f0+0x1258>  // b.any
    b198:	29430002 	ldp	w2, w0, [x0, #24]
    b19c:	92403c21 	and	x1, x1, #0xffff
    b1a0:	9b027c21 	mul	x1, x1, x2
    b1a4:	d360fc21 	lsr	x1, x1, #32
    b1a8:	eb00003f 	cmp	x1, x0
    b1ac:	540000e2 	b.cs	b1c8 <f0+0x1258>  // b.hs, b.nlast
    b1b0:	8b0102f7 	add	x23, x23, x1
    b1b4:	394002e0 	ldrb	w0, [x23]
    b1b8:	7103fc1f 	cmp	w0, #0xff
    b1bc:	540098c0 	b.eq	c4d4 <f0+0x2564>  // b.none
    b1c0:	52800020 	mov	w0, #0x1                   	// #1
    b1c4:	390002e0 	strb	w0, [x23]
    b1c8:	9114a3e1 	add	x1, sp, #0x528
    b1cc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b1d0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b1d4:	52800020 	mov	w0, #0x1                   	// #1
    b1d8:	f90297f7 	str	x23, [sp, #1320]
    b1dc:	f9029bf5 	str	x21, [sp, #1328]
    b1e0:	97ffe82d 	bl	5294 <fwp_data.part.0.constprop.0>
    b1e4:	97ffe9a4 	bl	5874 <fwp_rc_fresh>
    b1e8:	aa0003e2 	mov	x2, x0
    b1ec:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b1f0:	9114e3e1 	add	x1, sp, #0x538
    b1f4:	52800020 	mov	w0, #0x1                   	// #1
    b1f8:	f9029fe3 	str	x3, [sp, #1336]
    b1fc:	f902a3e2 	str	x2, [sp, #1344]
    b200:	97ffe825 	bl	5294 <fwp_data.part.0.constprop.0>
    b204:	97ffe99c 	bl	5874 <fwp_rc_fresh>
    b208:	aa0003e2 	mov	x2, x0
    b20c:	911523e1 	add	x1, sp, #0x548
    b210:	52800020 	mov	w0, #0x1                   	// #1
    b214:	f902a7f7 	str	x23, [sp, #1352]
    b218:	f902abe2 	str	x2, [sp, #1360]
    b21c:	97ffe81e 	bl	5294 <fwp_data.part.0.constprop.0>
    b220:	9118c283 	add	x3, x20, #0x630
    b224:	aa0003f5 	mov	x21, x0
    b228:	f949d861 	ldr	x1, [x3, #5040]
    b22c:	f949ec60 	ldr	x0, [x3, #5080]
    b230:	cb0102a1 	sub	x1, x21, x1
    b234:	eb00403f 	cmp	x1, x0, lsl #16
    b238:	54000322 	b.cs	b29c <f0+0x132c>  // b.hs, b.nlast
    b23c:	d350fc22 	lsr	x2, x1, #16
    b240:	f949fc63 	ldr	x3, [x3, #5112]
    b244:	8b020842 	add	x2, x2, x2, lsl #2
    b248:	d37df042 	lsl	x2, x2, #3
    b24c:	8b020060 	add	x0, x3, x2
    b250:	f9401017 	ldr	x23, [x0, #32]
    b254:	b4000257 	cbz	x23, b29c <f0+0x132c>
    b258:	38626862 	ldrb	w2, [x3, x2]
    b25c:	7100085f 	cmp	w2, #0x2
    b260:	54007fc0 	b.eq	c258 <f0+0x22e8>  // b.none
    b264:	7100045f 	cmp	w2, #0x1
    b268:	540001a1 	b.ne	b29c <f0+0x132c>  // b.any
    b26c:	29430002 	ldp	w2, w0, [x0, #24]
    b270:	92403c21 	and	x1, x1, #0xffff
    b274:	9b027c21 	mul	x1, x1, x2
    b278:	d360fc21 	lsr	x1, x1, #32
    b27c:	eb00003f 	cmp	x1, x0
    b280:	540000e2 	b.cs	b29c <f0+0x132c>  // b.hs, b.nlast
    b284:	8b0102f7 	add	x23, x23, x1
    b288:	394002e0 	ldrb	w0, [x23]
    b28c:	7103fc1f 	cmp	w0, #0xff
    b290:	54009280 	b.eq	c4e0 <f0+0x2570>  // b.none
    b294:	52800020 	mov	w0, #0x1                   	// #1
    b298:	390002e0 	strb	w0, [x23]
    b29c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b2a0:	911563e1 	add	x1, sp, #0x558
    b2a4:	52800020 	mov	w0, #0x1                   	// #1
    b2a8:	f902afe2 	str	x2, [sp, #1368]
    b2ac:	f902b3f5 	str	x21, [sp, #1376]
    b2b0:	97ffe7f9 	bl	5294 <fwp_data.part.0.constprop.0>
    b2b4:	9118c283 	add	x3, x20, #0x630
    b2b8:	aa0003f5 	mov	x21, x0
    b2bc:	f949d861 	ldr	x1, [x3, #5040]
    b2c0:	f949ec60 	ldr	x0, [x3, #5080]
    b2c4:	cb0102a1 	sub	x1, x21, x1
    b2c8:	eb00403f 	cmp	x1, x0, lsl #16
    b2cc:	54000322 	b.cs	b330 <f0+0x13c0>  // b.hs, b.nlast
    b2d0:	d350fc22 	lsr	x2, x1, #16
    b2d4:	f949fc63 	ldr	x3, [x3, #5112]
    b2d8:	8b020842 	add	x2, x2, x2, lsl #2
    b2dc:	d37df042 	lsl	x2, x2, #3
    b2e0:	8b020060 	add	x0, x3, x2
    b2e4:	f9401017 	ldr	x23, [x0, #32]
    b2e8:	b4000257 	cbz	x23, b330 <f0+0x13c0>
    b2ec:	38626862 	ldrb	w2, [x3, x2]
    b2f0:	7100085f 	cmp	w2, #0x2
    b2f4:	54007ac0 	b.eq	c24c <f0+0x22dc>  // b.none
    b2f8:	7100045f 	cmp	w2, #0x1
    b2fc:	540001a1 	b.ne	b330 <f0+0x13c0>  // b.any
    b300:	29430002 	ldp	w2, w0, [x0, #24]
    b304:	92403c21 	and	x1, x1, #0xffff
    b308:	9b027c21 	mul	x1, x1, x2
    b30c:	d360fc21 	lsr	x1, x1, #32
    b310:	eb00003f 	cmp	x1, x0
    b314:	540000e2 	b.cs	b330 <f0+0x13c0>  // b.hs, b.nlast
    b318:	8b0102f7 	add	x23, x23, x1
    b31c:	394002e0 	ldrb	w0, [x23]
    b320:	7103fc1f 	cmp	w0, #0xff
    b324:	54008e40 	b.eq	c4ec <f0+0x257c>  // b.none
    b328:	52800020 	mov	w0, #0x1                   	// #1
    b32c:	390002e0 	strb	w0, [x23]
    b330:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b334:	9115a3e1 	add	x1, sp, #0x568
    b338:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b33c:	52800020 	mov	w0, #0x1                   	// #1
    b340:	f902b7e2 	str	x2, [sp, #1384]
    b344:	f902bbf5 	str	x21, [sp, #1392]
    b348:	97ffe7d3 	bl	5294 <fwp_data.part.0.constprop.0>
    b34c:	97ffe94a 	bl	5874 <fwp_rc_fresh>
    b350:	aa0003e2 	mov	x2, x0
    b354:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b358:	9115e3e1 	add	x1, sp, #0x578
    b35c:	52800020 	mov	w0, #0x1                   	// #1
    b360:	f902bfe3 	str	x3, [sp, #1400]
    b364:	f902c3e2 	str	x2, [sp, #1408]
    b368:	97ffe7cb 	bl	5294 <fwp_data.part.0.constprop.0>
    b36c:	9118c283 	add	x3, x20, #0x630
    b370:	aa0003f5 	mov	x21, x0
    b374:	f949d861 	ldr	x1, [x3, #5040]
    b378:	f949ec60 	ldr	x0, [x3, #5080]
    b37c:	cb0102a1 	sub	x1, x21, x1
    b380:	eb00403f 	cmp	x1, x0, lsl #16
    b384:	54000322 	b.cs	b3e8 <f0+0x1478>  // b.hs, b.nlast
    b388:	d350fc22 	lsr	x2, x1, #16
    b38c:	f949fc63 	ldr	x3, [x3, #5112]
    b390:	8b020842 	add	x2, x2, x2, lsl #2
    b394:	d37df042 	lsl	x2, x2, #3
    b398:	8b020060 	add	x0, x3, x2
    b39c:	f9401017 	ldr	x23, [x0, #32]
    b3a0:	b4000257 	cbz	x23, b3e8 <f0+0x1478>
    b3a4:	38626862 	ldrb	w2, [x3, x2]
    b3a8:	7100085f 	cmp	w2, #0x2
    b3ac:	540074a0 	b.eq	c240 <f0+0x22d0>  // b.none
    b3b0:	7100045f 	cmp	w2, #0x1
    b3b4:	540001a1 	b.ne	b3e8 <f0+0x1478>  // b.any
    b3b8:	29430002 	ldp	w2, w0, [x0, #24]
    b3bc:	92403c21 	and	x1, x1, #0xffff
    b3c0:	9b027c21 	mul	x1, x1, x2
    b3c4:	d360fc21 	lsr	x1, x1, #32
    b3c8:	eb00003f 	cmp	x1, x0
    b3cc:	540000e2 	b.cs	b3e8 <f0+0x1478>  // b.hs, b.nlast
    b3d0:	8b0102f7 	add	x23, x23, x1
    b3d4:	394002e0 	ldrb	w0, [x23]
    b3d8:	7103fc1f 	cmp	w0, #0xff
    b3dc:	540088e0 	b.eq	c4f8 <f0+0x2588>  // b.none
    b3e0:	52800020 	mov	w0, #0x1                   	// #1
    b3e4:	390002e0 	strb	w0, [x23]
    b3e8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b3ec:	911623e1 	add	x1, sp, #0x588
    b3f0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b3f4:	52800020 	mov	w0, #0x1                   	// #1
    b3f8:	f902c7e2 	str	x2, [sp, #1416]
    b3fc:	f902cbf5 	str	x21, [sp, #1424]
    b400:	97ffe7a5 	bl	5294 <fwp_data.part.0.constprop.0>
    b404:	97ffe91c 	bl	5874 <fwp_rc_fresh>
    b408:	aa0003e2 	mov	x2, x0
    b40c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b410:	911663e1 	add	x1, sp, #0x598
    b414:	52800020 	mov	w0, #0x1                   	// #1
    b418:	f902cfe3 	str	x3, [sp, #1432]
    b41c:	f902d3e2 	str	x2, [sp, #1440]
    b420:	97ffe79d 	bl	5294 <fwp_data.part.0.constprop.0>
    b424:	9118c283 	add	x3, x20, #0x630
    b428:	aa0003f5 	mov	x21, x0
    b42c:	f949d861 	ldr	x1, [x3, #5040]
    b430:	f949ec60 	ldr	x0, [x3, #5080]
    b434:	cb0102a1 	sub	x1, x21, x1
    b438:	eb00403f 	cmp	x1, x0, lsl #16
    b43c:	54000322 	b.cs	b4a0 <f0+0x1530>  // b.hs, b.nlast
    b440:	d350fc22 	lsr	x2, x1, #16
    b444:	f949fc63 	ldr	x3, [x3, #5112]
    b448:	8b020842 	add	x2, x2, x2, lsl #2
    b44c:	d37df042 	lsl	x2, x2, #3
    b450:	8b020060 	add	x0, x3, x2
    b454:	f9401017 	ldr	x23, [x0, #32]
    b458:	b4000257 	cbz	x23, b4a0 <f0+0x1530>
    b45c:	38626862 	ldrb	w2, [x3, x2]
    b460:	7100085f 	cmp	w2, #0x2
    b464:	54006e80 	b.eq	c234 <f0+0x22c4>  // b.none
    b468:	7100045f 	cmp	w2, #0x1
    b46c:	540001a1 	b.ne	b4a0 <f0+0x1530>  // b.any
    b470:	29430002 	ldp	w2, w0, [x0, #24]
    b474:	92403c21 	and	x1, x1, #0xffff
    b478:	9b027c21 	mul	x1, x1, x2
    b47c:	d360fc21 	lsr	x1, x1, #32
    b480:	eb00003f 	cmp	x1, x0
    b484:	540000e2 	b.cs	b4a0 <f0+0x1530>  // b.hs, b.nlast
    b488:	8b0102f7 	add	x23, x23, x1
    b48c:	394002e0 	ldrb	w0, [x23]
    b490:	7103fc1f 	cmp	w0, #0xff
    b494:	54008380 	b.eq	c504 <f0+0x2594>  // b.none
    b498:	52800020 	mov	w0, #0x1                   	// #1
    b49c:	390002e0 	strb	w0, [x23]
    b4a0:	9116a3e1 	add	x1, sp, #0x5a8
    b4a4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b4a8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b4ac:	52800020 	mov	w0, #0x1                   	// #1
    b4b0:	f902d7f7 	str	x23, [sp, #1448]
    b4b4:	f902dbf5 	str	x21, [sp, #1456]
    b4b8:	97ffe777 	bl	5294 <fwp_data.part.0.constprop.0>
    b4bc:	97ffe8ee 	bl	5874 <fwp_rc_fresh>
    b4c0:	aa0003e2 	mov	x2, x0
    b4c4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b4c8:	9116e3e1 	add	x1, sp, #0x5b8
    b4cc:	52800020 	mov	w0, #0x1                   	// #1
    b4d0:	f902dfe3 	str	x3, [sp, #1464]
    b4d4:	f902e3e2 	str	x2, [sp, #1472]
    b4d8:	97ffe76f 	bl	5294 <fwp_data.part.0.constprop.0>
    b4dc:	97ffe8e6 	bl	5874 <fwp_rc_fresh>
    b4e0:	aa0003e2 	mov	x2, x0
    b4e4:	911723e1 	add	x1, sp, #0x5c8
    b4e8:	52800020 	mov	w0, #0x1                   	// #1
    b4ec:	f902e7f7 	str	x23, [sp, #1480]
    b4f0:	f902ebe2 	str	x2, [sp, #1488]
    b4f4:	97ffe768 	bl	5294 <fwp_data.part.0.constprop.0>
    b4f8:	9118c283 	add	x3, x20, #0x630
    b4fc:	aa0003f5 	mov	x21, x0
    b500:	f949d861 	ldr	x1, [x3, #5040]
    b504:	f949ec60 	ldr	x0, [x3, #5080]
    b508:	cb0102a1 	sub	x1, x21, x1
    b50c:	eb00403f 	cmp	x1, x0, lsl #16
    b510:	54000322 	b.cs	b574 <f0+0x1604>  // b.hs, b.nlast
    b514:	d350fc22 	lsr	x2, x1, #16
    b518:	f949fc63 	ldr	x3, [x3, #5112]
    b51c:	8b020842 	add	x2, x2, x2, lsl #2
    b520:	d37df042 	lsl	x2, x2, #3
    b524:	8b020060 	add	x0, x3, x2
    b528:	f9401017 	ldr	x23, [x0, #32]
    b52c:	b4000257 	cbz	x23, b574 <f0+0x1604>
    b530:	38626862 	ldrb	w2, [x3, x2]
    b534:	7100085f 	cmp	w2, #0x2
    b538:	54006780 	b.eq	c228 <f0+0x22b8>  // b.none
    b53c:	7100045f 	cmp	w2, #0x1
    b540:	540001a1 	b.ne	b574 <f0+0x1604>  // b.any
    b544:	29430002 	ldp	w2, w0, [x0, #24]
    b548:	92403c21 	and	x1, x1, #0xffff
    b54c:	9b027c21 	mul	x1, x1, x2
    b550:	d360fc21 	lsr	x1, x1, #32
    b554:	eb00003f 	cmp	x1, x0
    b558:	540000e2 	b.cs	b574 <f0+0x1604>  // b.hs, b.nlast
    b55c:	8b0102f7 	add	x23, x23, x1
    b560:	394002e0 	ldrb	w0, [x23]
    b564:	7103fc1f 	cmp	w0, #0xff
    b568:	54007d40 	b.eq	c510 <f0+0x25a0>  // b.none
    b56c:	52800020 	mov	w0, #0x1                   	// #1
    b570:	390002e0 	strb	w0, [x23]
    b574:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b578:	911763e1 	add	x1, sp, #0x5d8
    b57c:	52800020 	mov	w0, #0x1                   	// #1
    b580:	f902efe2 	str	x2, [sp, #1496]
    b584:	f902f3f5 	str	x21, [sp, #1504]
    b588:	97ffe743 	bl	5294 <fwp_data.part.0.constprop.0>
    b58c:	9118c283 	add	x3, x20, #0x630
    b590:	aa0003f5 	mov	x21, x0
    b594:	f949d861 	ldr	x1, [x3, #5040]
    b598:	f949ec60 	ldr	x0, [x3, #5080]
    b59c:	cb0102a1 	sub	x1, x21, x1
    b5a0:	eb00403f 	cmp	x1, x0, lsl #16
    b5a4:	54000322 	b.cs	b608 <f0+0x1698>  // b.hs, b.nlast
    b5a8:	d350fc22 	lsr	x2, x1, #16
    b5ac:	f949fc63 	ldr	x3, [x3, #5112]
    b5b0:	8b020842 	add	x2, x2, x2, lsl #2
    b5b4:	d37df042 	lsl	x2, x2, #3
    b5b8:	8b020060 	add	x0, x3, x2
    b5bc:	f9401017 	ldr	x23, [x0, #32]
    b5c0:	b4000257 	cbz	x23, b608 <f0+0x1698>
    b5c4:	38626862 	ldrb	w2, [x3, x2]
    b5c8:	7100085f 	cmp	w2, #0x2
    b5cc:	54007120 	b.eq	c3f0 <f0+0x2480>  // b.none
    b5d0:	7100045f 	cmp	w2, #0x1
    b5d4:	540001a1 	b.ne	b608 <f0+0x1698>  // b.any
    b5d8:	29430002 	ldp	w2, w0, [x0, #24]
    b5dc:	92403c21 	and	x1, x1, #0xffff
    b5e0:	9b027c21 	mul	x1, x1, x2
    b5e4:	d360fc21 	lsr	x1, x1, #32
    b5e8:	eb00003f 	cmp	x1, x0
    b5ec:	540000e2 	b.cs	b608 <f0+0x1698>  // b.hs, b.nlast
    b5f0:	8b0102f7 	add	x23, x23, x1
    b5f4:	394002e0 	ldrb	w0, [x23]
    b5f8:	7103fc1f 	cmp	w0, #0xff
    b5fc:	54007900 	b.eq	c51c <f0+0x25ac>  // b.none
    b600:	52800020 	mov	w0, #0x1                   	// #1
    b604:	390002e0 	strb	w0, [x23]
    b608:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b60c:	9117a3e1 	add	x1, sp, #0x5e8
    b610:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b614:	52800020 	mov	w0, #0x1                   	// #1
    b618:	f902f7e2 	str	x2, [sp, #1512]
    b61c:	f902fbf5 	str	x21, [sp, #1520]
    b620:	97ffe71d 	bl	5294 <fwp_data.part.0.constprop.0>
    b624:	97ffe894 	bl	5874 <fwp_rc_fresh>
    b628:	aa0003e2 	mov	x2, x0
    b62c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b630:	9117e3e1 	add	x1, sp, #0x5f8
    b634:	52800020 	mov	w0, #0x1                   	// #1
    b638:	f902ffe3 	str	x3, [sp, #1528]
    b63c:	f90303e2 	str	x2, [sp, #1536]
    b640:	97ffe715 	bl	5294 <fwp_data.part.0.constprop.0>
    b644:	9118c283 	add	x3, x20, #0x630
    b648:	aa0003f5 	mov	x21, x0
    b64c:	f949d861 	ldr	x1, [x3, #5040]
    b650:	f949ec60 	ldr	x0, [x3, #5080]
    b654:	cb0102a1 	sub	x1, x21, x1
    b658:	eb00403f 	cmp	x1, x0, lsl #16
    b65c:	54000322 	b.cs	b6c0 <f0+0x1750>  // b.hs, b.nlast
    b660:	d350fc22 	lsr	x2, x1, #16
    b664:	f949fc63 	ldr	x3, [x3, #5112]
    b668:	8b020842 	add	x2, x2, x2, lsl #2
    b66c:	d37df042 	lsl	x2, x2, #3
    b670:	8b020060 	add	x0, x3, x2
    b674:	f9401017 	ldr	x23, [x0, #32]
    b678:	b4000257 	cbz	x23, b6c0 <f0+0x1750>
    b67c:	38626862 	ldrb	w2, [x3, x2]
    b680:	7100085f 	cmp	w2, #0x2
    b684:	54006b00 	b.eq	c3e4 <f0+0x2474>  // b.none
    b688:	7100045f 	cmp	w2, #0x1
    b68c:	540001a1 	b.ne	b6c0 <f0+0x1750>  // b.any
    b690:	29430002 	ldp	w2, w0, [x0, #24]
    b694:	92403c21 	and	x1, x1, #0xffff
    b698:	9b027c21 	mul	x1, x1, x2
    b69c:	d360fc21 	lsr	x1, x1, #32
    b6a0:	eb00003f 	cmp	x1, x0
    b6a4:	540000e2 	b.cs	b6c0 <f0+0x1750>  // b.hs, b.nlast
    b6a8:	8b0102f7 	add	x23, x23, x1
    b6ac:	394002e0 	ldrb	w0, [x23]
    b6b0:	7103fc1f 	cmp	w0, #0xff
    b6b4:	540073a0 	b.eq	c528 <f0+0x25b8>  // b.none
    b6b8:	52800020 	mov	w0, #0x1                   	// #1
    b6bc:	390002e0 	strb	w0, [x23]
    b6c0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b6c4:	911823e1 	add	x1, sp, #0x608
    b6c8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b6cc:	52800020 	mov	w0, #0x1                   	// #1
    b6d0:	f90307e2 	str	x2, [sp, #1544]
    b6d4:	f9030bf5 	str	x21, [sp, #1552]
    b6d8:	97ffe6ef 	bl	5294 <fwp_data.part.0.constprop.0>
    b6dc:	97ffe866 	bl	5874 <fwp_rc_fresh>
    b6e0:	aa0003e2 	mov	x2, x0
    b6e4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b6e8:	911863e1 	add	x1, sp, #0x618
    b6ec:	52800020 	mov	w0, #0x1                   	// #1
    b6f0:	f9030fe3 	str	x3, [sp, #1560]
    b6f4:	f90313e2 	str	x2, [sp, #1568]
    b6f8:	97ffe6e7 	bl	5294 <fwp_data.part.0.constprop.0>
    b6fc:	9118c283 	add	x3, x20, #0x630
    b700:	aa0003f5 	mov	x21, x0
    b704:	f949d861 	ldr	x1, [x3, #5040]
    b708:	f949ec60 	ldr	x0, [x3, #5080]
    b70c:	cb0102a1 	sub	x1, x21, x1
    b710:	eb00403f 	cmp	x1, x0, lsl #16
    b714:	54000322 	b.cs	b778 <f0+0x1808>  // b.hs, b.nlast
    b718:	d350fc22 	lsr	x2, x1, #16
    b71c:	f949fc63 	ldr	x3, [x3, #5112]
    b720:	8b020842 	add	x2, x2, x2, lsl #2
    b724:	d37df042 	lsl	x2, x2, #3
    b728:	8b020060 	add	x0, x3, x2
    b72c:	f9401017 	ldr	x23, [x0, #32]
    b730:	b4000257 	cbz	x23, b778 <f0+0x1808>
    b734:	38626862 	ldrb	w2, [x3, x2]
    b738:	7100085f 	cmp	w2, #0x2
    b73c:	540064e0 	b.eq	c3d8 <f0+0x2468>  // b.none
    b740:	7100045f 	cmp	w2, #0x1
    b744:	540001a1 	b.ne	b778 <f0+0x1808>  // b.any
    b748:	29430002 	ldp	w2, w0, [x0, #24]
    b74c:	92403c21 	and	x1, x1, #0xffff
    b750:	9b027c21 	mul	x1, x1, x2
    b754:	d360fc21 	lsr	x1, x1, #32
    b758:	eb00003f 	cmp	x1, x0
    b75c:	540000e2 	b.cs	b778 <f0+0x1808>  // b.hs, b.nlast
    b760:	8b0102f7 	add	x23, x23, x1
    b764:	394002e0 	ldrb	w0, [x23]
    b768:	7103fc1f 	cmp	w0, #0xff
    b76c:	54006e40 	b.eq	c534 <f0+0x25c4>  // b.none
    b770:	52800020 	mov	w0, #0x1                   	// #1
    b774:	390002e0 	strb	w0, [x23]
    b778:	9118a3e1 	add	x1, sp, #0x628
    b77c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b780:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b784:	52800020 	mov	w0, #0x1                   	// #1
    b788:	f90317f7 	str	x23, [sp, #1576]
    b78c:	f9031bf5 	str	x21, [sp, #1584]
    b790:	97ffe6c1 	bl	5294 <fwp_data.part.0.constprop.0>
    b794:	97ffe838 	bl	5874 <fwp_rc_fresh>
    b798:	aa0003e2 	mov	x2, x0
    b79c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b7a0:	9118e3e1 	add	x1, sp, #0x638
    b7a4:	52800020 	mov	w0, #0x1                   	// #1
    b7a8:	f9031fe3 	str	x3, [sp, #1592]
    b7ac:	f90323e2 	str	x2, [sp, #1600]
    b7b0:	97ffe6b9 	bl	5294 <fwp_data.part.0.constprop.0>
    b7b4:	97ffe830 	bl	5874 <fwp_rc_fresh>
    b7b8:	aa0003e2 	mov	x2, x0
    b7bc:	911923e1 	add	x1, sp, #0x648
    b7c0:	52800020 	mov	w0, #0x1                   	// #1
    b7c4:	f90327f7 	str	x23, [sp, #1608]
    b7c8:	f9032be2 	str	x2, [sp, #1616]
    b7cc:	97ffe6b2 	bl	5294 <fwp_data.part.0.constprop.0>
    b7d0:	9118c283 	add	x3, x20, #0x630
    b7d4:	aa0003f5 	mov	x21, x0
    b7d8:	f949d861 	ldr	x1, [x3, #5040]
    b7dc:	f949ec60 	ldr	x0, [x3, #5080]
    b7e0:	cb0102a1 	sub	x1, x21, x1
    b7e4:	eb00403f 	cmp	x1, x0, lsl #16
    b7e8:	54000322 	b.cs	b84c <f0+0x18dc>  // b.hs, b.nlast
    b7ec:	d350fc22 	lsr	x2, x1, #16
    b7f0:	f949fc63 	ldr	x3, [x3, #5112]
    b7f4:	8b020842 	add	x2, x2, x2, lsl #2
    b7f8:	d37df042 	lsl	x2, x2, #3
    b7fc:	8b020060 	add	x0, x3, x2
    b800:	f9401017 	ldr	x23, [x0, #32]
    b804:	b4000257 	cbz	x23, b84c <f0+0x18dc>
    b808:	38626862 	ldrb	w2, [x3, x2]
    b80c:	7100085f 	cmp	w2, #0x2
    b810:	54005de0 	b.eq	c3cc <f0+0x245c>  // b.none
    b814:	7100045f 	cmp	w2, #0x1
    b818:	540001a1 	b.ne	b84c <f0+0x18dc>  // b.any
    b81c:	29430002 	ldp	w2, w0, [x0, #24]
    b820:	92403c21 	and	x1, x1, #0xffff
    b824:	9b027c21 	mul	x1, x1, x2
    b828:	d360fc21 	lsr	x1, x1, #32
    b82c:	eb00003f 	cmp	x1, x0
    b830:	540000e2 	b.cs	b84c <f0+0x18dc>  // b.hs, b.nlast
    b834:	8b0102f7 	add	x23, x23, x1
    b838:	394002e0 	ldrb	w0, [x23]
    b83c:	7103fc1f 	cmp	w0, #0xff
    b840:	54006800 	b.eq	c540 <f0+0x25d0>  // b.none
    b844:	52800020 	mov	w0, #0x1                   	// #1
    b848:	390002e0 	strb	w0, [x23]
    b84c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b850:	911963e1 	add	x1, sp, #0x658
    b854:	52800020 	mov	w0, #0x1                   	// #1
    b858:	f9032fe2 	str	x2, [sp, #1624]
    b85c:	f90333f5 	str	x21, [sp, #1632]
    b860:	97ffe68d 	bl	5294 <fwp_data.part.0.constprop.0>
    b864:	9118c283 	add	x3, x20, #0x630
    b868:	aa0003f5 	mov	x21, x0
    b86c:	f949d861 	ldr	x1, [x3, #5040]
    b870:	f949ec60 	ldr	x0, [x3, #5080]
    b874:	cb0102a1 	sub	x1, x21, x1
    b878:	eb00403f 	cmp	x1, x0, lsl #16
    b87c:	54000322 	b.cs	b8e0 <f0+0x1970>  // b.hs, b.nlast
    b880:	d350fc22 	lsr	x2, x1, #16
    b884:	f949fc63 	ldr	x3, [x3, #5112]
    b888:	8b020842 	add	x2, x2, x2, lsl #2
    b88c:	d37df042 	lsl	x2, x2, #3
    b890:	8b020060 	add	x0, x3, x2
    b894:	f9401017 	ldr	x23, [x0, #32]
    b898:	b4000257 	cbz	x23, b8e0 <f0+0x1970>
    b89c:	38626862 	ldrb	w2, [x3, x2]
    b8a0:	7100085f 	cmp	w2, #0x2
    b8a4:	540058e0 	b.eq	c3c0 <f0+0x2450>  // b.none
    b8a8:	7100045f 	cmp	w2, #0x1
    b8ac:	540001a1 	b.ne	b8e0 <f0+0x1970>  // b.any
    b8b0:	29430002 	ldp	w2, w0, [x0, #24]
    b8b4:	92403c21 	and	x1, x1, #0xffff
    b8b8:	9b027c21 	mul	x1, x1, x2
    b8bc:	d360fc21 	lsr	x1, x1, #32
    b8c0:	eb00003f 	cmp	x1, x0
    b8c4:	540000e2 	b.cs	b8e0 <f0+0x1970>  // b.hs, b.nlast
    b8c8:	8b0102f7 	add	x23, x23, x1
    b8cc:	394002e0 	ldrb	w0, [x23]
    b8d0:	7103fc1f 	cmp	w0, #0xff
    b8d4:	540063c0 	b.eq	c54c <f0+0x25dc>  // b.none
    b8d8:	52800020 	mov	w0, #0x1                   	// #1
    b8dc:	390002e0 	strb	w0, [x23]
    b8e0:	9119a3e1 	add	x1, sp, #0x668
    b8e4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b8e8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b8ec:	52800020 	mov	w0, #0x1                   	// #1
    b8f0:	f90337f7 	str	x23, [sp, #1640]
    b8f4:	f9033bf5 	str	x21, [sp, #1648]
    b8f8:	97ffe667 	bl	5294 <fwp_data.part.0.constprop.0>
    b8fc:	97ffe7de 	bl	5874 <fwp_rc_fresh>
    b900:	aa0003e2 	mov	x2, x0
    b904:	9119e3e1 	add	x1, sp, #0x678
    b908:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b90c:	52800020 	mov	w0, #0x1                   	// #1
    b910:	f9033ff5 	str	x21, [sp, #1656]
    b914:	f90343e2 	str	x2, [sp, #1664]
    b918:	97ffe65f 	bl	5294 <fwp_data.part.0.constprop.0>
    b91c:	97ffe7d6 	bl	5874 <fwp_rc_fresh>
    b920:	aa0003e2 	mov	x2, x0
    b924:	911a23e1 	add	x1, sp, #0x688
    b928:	52800020 	mov	w0, #0x1                   	// #1
    b92c:	f90347f7 	str	x23, [sp, #1672]
    b930:	f9034be2 	str	x2, [sp, #1680]
    b934:	97ffe658 	bl	5294 <fwp_data.part.0.constprop.0>
    b938:	97ffe7cf 	bl	5874 <fwp_rc_fresh>
    b93c:	aa0003e2 	mov	x2, x0
    b940:	911a63e1 	add	x1, sp, #0x698
    b944:	52800020 	mov	w0, #0x1                   	// #1
    b948:	f9034ff5 	str	x21, [sp, #1688]
    b94c:	f90353e2 	str	x2, [sp, #1696]
    b950:	97ffe651 	bl	5294 <fwp_data.part.0.constprop.0>
    b954:	9118c283 	add	x3, x20, #0x630
    b958:	aa0003f5 	mov	x21, x0
    b95c:	f949d861 	ldr	x1, [x3, #5040]
    b960:	f949ec60 	ldr	x0, [x3, #5080]
    b964:	cb0102a1 	sub	x1, x21, x1
    b968:	eb00403f 	cmp	x1, x0, lsl #16
    b96c:	54000322 	b.cs	b9d0 <f0+0x1a60>  // b.hs, b.nlast
    b970:	d350fc22 	lsr	x2, x1, #16
    b974:	f949fc63 	ldr	x3, [x3, #5112]
    b978:	8b020842 	add	x2, x2, x2, lsl #2
    b97c:	d37df042 	lsl	x2, x2, #3
    b980:	8b020060 	add	x0, x3, x2
    b984:	f9401017 	ldr	x23, [x0, #32]
    b988:	b4000257 	cbz	x23, b9d0 <f0+0x1a60>
    b98c:	38626862 	ldrb	w2, [x3, x2]
    b990:	7100085f 	cmp	w2, #0x2
    b994:	54005100 	b.eq	c3b4 <f0+0x2444>  // b.none
    b998:	7100045f 	cmp	w2, #0x1
    b99c:	540001a1 	b.ne	b9d0 <f0+0x1a60>  // b.any
    b9a0:	29430002 	ldp	w2, w0, [x0, #24]
    b9a4:	92403c21 	and	x1, x1, #0xffff
    b9a8:	9b027c21 	mul	x1, x1, x2
    b9ac:	d360fc21 	lsr	x1, x1, #32
    b9b0:	eb00003f 	cmp	x1, x0
    b9b4:	540000e2 	b.cs	b9d0 <f0+0x1a60>  // b.hs, b.nlast
    b9b8:	8b0102f7 	add	x23, x23, x1
    b9bc:	394002e0 	ldrb	w0, [x23]
    b9c0:	7103fc1f 	cmp	w0, #0xff
    b9c4:	54005ca0 	b.eq	c558 <f0+0x25e8>  // b.none
    b9c8:	52800020 	mov	w0, #0x1                   	// #1
    b9cc:	390002e0 	strb	w0, [x23]
    b9d0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b9d4:	911aa3e1 	add	x1, sp, #0x6a8
    b9d8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b9dc:	52800020 	mov	w0, #0x1                   	// #1
    b9e0:	f90357e2 	str	x2, [sp, #1704]
    b9e4:	f9035bf5 	str	x21, [sp, #1712]
    b9e8:	97ffe62b 	bl	5294 <fwp_data.part.0.constprop.0>
    b9ec:	9118c283 	add	x3, x20, #0x630
    b9f0:	aa0003f5 	mov	x21, x0
    b9f4:	f949d861 	ldr	x1, [x3, #5040]
    b9f8:	f949ec60 	ldr	x0, [x3, #5080]
    b9fc:	cb0102a1 	sub	x1, x21, x1
    ba00:	eb00403f 	cmp	x1, x0, lsl #16
    ba04:	54000322 	b.cs	ba68 <f0+0x1af8>  // b.hs, b.nlast
    ba08:	d350fc22 	lsr	x2, x1, #16
    ba0c:	f949fc63 	ldr	x3, [x3, #5112]
    ba10:	8b020842 	add	x2, x2, x2, lsl #2
    ba14:	d37df042 	lsl	x2, x2, #3
    ba18:	8b020060 	add	x0, x3, x2
    ba1c:	f9401017 	ldr	x23, [x0, #32]
    ba20:	b4000257 	cbz	x23, ba68 <f0+0x1af8>
    ba24:	38626862 	ldrb	w2, [x3, x2]
    ba28:	7100085f 	cmp	w2, #0x2
    ba2c:	54004be0 	b.eq	c3a8 <f0+0x2438>  // b.none
    ba30:	7100045f 	cmp	w2, #0x1
    ba34:	540001a1 	b.ne	ba68 <f0+0x1af8>  // b.any
    ba38:	29430002 	ldp	w2, w0, [x0, #24]
    ba3c:	92403c21 	and	x1, x1, #0xffff
    ba40:	9b027c21 	mul	x1, x1, x2
    ba44:	d360fc21 	lsr	x1, x1, #32
    ba48:	eb00003f 	cmp	x1, x0
    ba4c:	540000e2 	b.cs	ba68 <f0+0x1af8>  // b.hs, b.nlast
    ba50:	8b0102f7 	add	x23, x23, x1
    ba54:	394002e0 	ldrb	w0, [x23]
    ba58:	7103fc1f 	cmp	w0, #0xff
    ba5c:	54005840 	b.eq	c564 <f0+0x25f4>  // b.none
    ba60:	52800020 	mov	w0, #0x1                   	// #1
    ba64:	390002e0 	strb	w0, [x23]
    ba68:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba6c:	911ae3e1 	add	x1, sp, #0x6b8
    ba70:	52800020 	mov	w0, #0x1                   	// #1
    ba74:	f9035fe2 	str	x2, [sp, #1720]
    ba78:	f90363f5 	str	x21, [sp, #1728]
    ba7c:	97ffe606 	bl	5294 <fwp_data.part.0.constprop.0>
    ba80:	9118c283 	add	x3, x20, #0x630
    ba84:	aa0003f5 	mov	x21, x0
    ba88:	f949d861 	ldr	x1, [x3, #5040]
    ba8c:	f949ec60 	ldr	x0, [x3, #5080]
    ba90:	cb0102a1 	sub	x1, x21, x1
    ba94:	eb00403f 	cmp	x1, x0, lsl #16
    ba98:	54000322 	b.cs	bafc <f0+0x1b8c>  // b.hs, b.nlast
    ba9c:	d350fc22 	lsr	x2, x1, #16
    baa0:	f949fc63 	ldr	x3, [x3, #5112]
    baa4:	8b020842 	add	x2, x2, x2, lsl #2
    baa8:	d37df042 	lsl	x2, x2, #3
    baac:	8b020060 	add	x0, x3, x2
    bab0:	f9401017 	ldr	x23, [x0, #32]
    bab4:	b4000257 	cbz	x23, bafc <f0+0x1b8c>
    bab8:	38626862 	ldrb	w2, [x3, x2]
    babc:	7100085f 	cmp	w2, #0x2
    bac0:	540046e0 	b.eq	c39c <f0+0x242c>  // b.none
    bac4:	7100045f 	cmp	w2, #0x1
    bac8:	540001a1 	b.ne	bafc <f0+0x1b8c>  // b.any
    bacc:	29430002 	ldp	w2, w0, [x0, #24]
    bad0:	92403c21 	and	x1, x1, #0xffff
    bad4:	9b027c21 	mul	x1, x1, x2
    bad8:	d360fc21 	lsr	x1, x1, #32
    badc:	eb00003f 	cmp	x1, x0
    bae0:	540000e2 	b.cs	bafc <f0+0x1b8c>  // b.hs, b.nlast
    bae4:	8b0102f7 	add	x23, x23, x1
    bae8:	394002e0 	ldrb	w0, [x23]
    baec:	7103fc1f 	cmp	w0, #0xff
    baf0:	54005400 	b.eq	c570 <f0+0x2600>  // b.none
    baf4:	52800020 	mov	w0, #0x1                   	// #1
    baf8:	390002e0 	strb	w0, [x23]
    bafc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bb00:	911b23e1 	add	x1, sp, #0x6c8
    bb04:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bb08:	52800020 	mov	w0, #0x1                   	// #1
    bb0c:	f90367e2 	str	x2, [sp, #1736]
    bb10:	f9036bf5 	str	x21, [sp, #1744]
    bb14:	97ffe5e0 	bl	5294 <fwp_data.part.0.constprop.0>
    bb18:	9118c283 	add	x3, x20, #0x630
    bb1c:	aa0003f5 	mov	x21, x0
    bb20:	f949d861 	ldr	x1, [x3, #5040]
    bb24:	f949ec60 	ldr	x0, [x3, #5080]
    bb28:	cb0102a1 	sub	x1, x21, x1
    bb2c:	eb00403f 	cmp	x1, x0, lsl #16
    bb30:	54000322 	b.cs	bb94 <f0+0x1c24>  // b.hs, b.nlast
    bb34:	d350fc22 	lsr	x2, x1, #16
    bb38:	f949fc63 	ldr	x3, [x3, #5112]
    bb3c:	8b020842 	add	x2, x2, x2, lsl #2
    bb40:	d37df042 	lsl	x2, x2, #3
    bb44:	8b020060 	add	x0, x3, x2
    bb48:	f9401017 	ldr	x23, [x0, #32]
    bb4c:	b4000257 	cbz	x23, bb94 <f0+0x1c24>
    bb50:	38626862 	ldrb	w2, [x3, x2]
    bb54:	7100085f 	cmp	w2, #0x2
    bb58:	540041c0 	b.eq	c390 <f0+0x2420>  // b.none
    bb5c:	7100045f 	cmp	w2, #0x1
    bb60:	540001a1 	b.ne	bb94 <f0+0x1c24>  // b.any
    bb64:	29430002 	ldp	w2, w0, [x0, #24]
    bb68:	92403c21 	and	x1, x1, #0xffff
    bb6c:	9b027c21 	mul	x1, x1, x2
    bb70:	d360fc21 	lsr	x1, x1, #32
    bb74:	eb00003f 	cmp	x1, x0
    bb78:	540000e2 	b.cs	bb94 <f0+0x1c24>  // b.hs, b.nlast
    bb7c:	8b0102f7 	add	x23, x23, x1
    bb80:	394002e0 	ldrb	w0, [x23]
    bb84:	7103fc1f 	cmp	w0, #0xff
    bb88:	54004fa0 	b.eq	c57c <f0+0x260c>  // b.none
    bb8c:	52800020 	mov	w0, #0x1                   	// #1
    bb90:	390002e0 	strb	w0, [x23]
    bb94:	911b63e1 	add	x1, sp, #0x6d8
    bb98:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bb9c:	52800020 	mov	w0, #0x1                   	// #1
    bba0:	f9036ff7 	str	x23, [sp, #1752]
    bba4:	f90373f5 	str	x21, [sp, #1760]
    bba8:	97ffe5bb 	bl	5294 <fwp_data.part.0.constprop.0>
    bbac:	97ffe732 	bl	5874 <fwp_rc_fresh>
    bbb0:	aa0003e2 	mov	x2, x0
    bbb4:	911ba3e1 	add	x1, sp, #0x6e8
    bbb8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bbbc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bbc0:	52800020 	mov	w0, #0x1                   	// #1
    bbc4:	f90377f5 	str	x21, [sp, #1768]
    bbc8:	f9037be2 	str	x2, [sp, #1776]
    bbcc:	97ffe5b2 	bl	5294 <fwp_data.part.0.constprop.0>
    bbd0:	97ffe729 	bl	5874 <fwp_rc_fresh>
    bbd4:	aa0003e2 	mov	x2, x0
    bbd8:	911be3e1 	add	x1, sp, #0x6f8
    bbdc:	52800020 	mov	w0, #0x1                   	// #1
    bbe0:	f9037ff7 	str	x23, [sp, #1784]
    bbe4:	f90383e2 	str	x2, [sp, #1792]
    bbe8:	97ffe5ab 	bl	5294 <fwp_data.part.0.constprop.0>
    bbec:	97ffe722 	bl	5874 <fwp_rc_fresh>
    bbf0:	aa0003e2 	mov	x2, x0
    bbf4:	911c23e1 	add	x1, sp, #0x708
    bbf8:	52800020 	mov	w0, #0x1                   	// #1
    bbfc:	f90387f5 	str	x21, [sp, #1800]
    bc00:	f9038be2 	str	x2, [sp, #1808]
    bc04:	97ffe5a4 	bl	5294 <fwp_data.part.0.constprop.0>
    bc08:	97ffe71b 	bl	5874 <fwp_rc_fresh>
    bc0c:	aa0003e2 	mov	x2, x0
    bc10:	911c63e1 	add	x1, sp, #0x718
    bc14:	52800020 	mov	w0, #0x1                   	// #1
    bc18:	f9038ff7 	str	x23, [sp, #1816]
    bc1c:	f90393e2 	str	x2, [sp, #1824]
    bc20:	97ffe59d 	bl	5294 <fwp_data.part.0.constprop.0>
    bc24:	9118c283 	add	x3, x20, #0x630
    bc28:	aa0003f5 	mov	x21, x0
    bc2c:	f949d861 	ldr	x1, [x3, #5040]
    bc30:	f949ec60 	ldr	x0, [x3, #5080]
    bc34:	cb0102a1 	sub	x1, x21, x1
    bc38:	eb00403f 	cmp	x1, x0, lsl #16
    bc3c:	54000322 	b.cs	bca0 <f0+0x1d30>  // b.hs, b.nlast
    bc40:	d350fc22 	lsr	x2, x1, #16
    bc44:	f949fc63 	ldr	x3, [x3, #5112]
    bc48:	8b020842 	add	x2, x2, x2, lsl #2
    bc4c:	d37df042 	lsl	x2, x2, #3
    bc50:	8b020060 	add	x0, x3, x2
    bc54:	f9401017 	ldr	x23, [x0, #32]
    bc58:	b4000257 	cbz	x23, bca0 <f0+0x1d30>
    bc5c:	38626862 	ldrb	w2, [x3, x2]
    bc60:	7100085f 	cmp	w2, #0x2
    bc64:	54003900 	b.eq	c384 <f0+0x2414>  // b.none
    bc68:	7100045f 	cmp	w2, #0x1
    bc6c:	540001a1 	b.ne	bca0 <f0+0x1d30>  // b.any
    bc70:	29430002 	ldp	w2, w0, [x0, #24]
    bc74:	92403c21 	and	x1, x1, #0xffff
    bc78:	9b027c21 	mul	x1, x1, x2
    bc7c:	d360fc21 	lsr	x1, x1, #32
    bc80:	eb00003f 	cmp	x1, x0
    bc84:	540000e2 	b.cs	bca0 <f0+0x1d30>  // b.hs, b.nlast
    bc88:	8b0102f7 	add	x23, x23, x1
    bc8c:	394002e0 	ldrb	w0, [x23]
    bc90:	7103fc1f 	cmp	w0, #0xff
    bc94:	540047a0 	b.eq	c588 <f0+0x2618>  // b.none
    bc98:	52800020 	mov	w0, #0x1                   	// #1
    bc9c:	390002e0 	strb	w0, [x23]
    bca0:	911ca3e1 	add	x1, sp, #0x728
    bca4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bca8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bcac:	52800020 	mov	w0, #0x1                   	// #1
    bcb0:	f90397f7 	str	x23, [sp, #1832]
    bcb4:	f9039bf5 	str	x21, [sp, #1840]
    bcb8:	97ffe577 	bl	5294 <fwp_data.part.0.constprop.0>
    bcbc:	97ffe6ee 	bl	5874 <fwp_rc_fresh>
    bcc0:	aa0003e2 	mov	x2, x0
    bcc4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bcc8:	911ce3e1 	add	x1, sp, #0x738
    bccc:	52800020 	mov	w0, #0x1                   	// #1
    bcd0:	f9039fe3 	str	x3, [sp, #1848]
    bcd4:	f903a3e2 	str	x2, [sp, #1856]
    bcd8:	97ffe56f 	bl	5294 <fwp_data.part.0.constprop.0>
    bcdc:	97ffe6e6 	bl	5874 <fwp_rc_fresh>
    bce0:	aa0003e2 	mov	x2, x0
    bce4:	911d23e1 	add	x1, sp, #0x748
    bce8:	52800020 	mov	w0, #0x1                   	// #1
    bcec:	f903a7f7 	str	x23, [sp, #1864]
    bcf0:	f903abe2 	str	x2, [sp, #1872]
    bcf4:	97ffe568 	bl	5294 <fwp_data.part.0.constprop.0>
    bcf8:	9118c283 	add	x3, x20, #0x630
    bcfc:	aa0003f5 	mov	x21, x0
    bd00:	f949d861 	ldr	x1, [x3, #5040]
    bd04:	f949ec60 	ldr	x0, [x3, #5080]
    bd08:	cb0102a1 	sub	x1, x21, x1
    bd0c:	eb00403f 	cmp	x1, x0, lsl #16
    bd10:	54000322 	b.cs	bd74 <f0+0x1e04>  // b.hs, b.nlast
    bd14:	d350fc22 	lsr	x2, x1, #16
    bd18:	f949fc63 	ldr	x3, [x3, #5112]
    bd1c:	8b020842 	add	x2, x2, x2, lsl #2
    bd20:	d37df042 	lsl	x2, x2, #3
    bd24:	8b020060 	add	x0, x3, x2
    bd28:	f9401017 	ldr	x23, [x0, #32]
    bd2c:	b4000257 	cbz	x23, bd74 <f0+0x1e04>
    bd30:	38626862 	ldrb	w2, [x3, x2]
    bd34:	7100085f 	cmp	w2, #0x2
    bd38:	54003200 	b.eq	c378 <f0+0x2408>  // b.none
    bd3c:	7100045f 	cmp	w2, #0x1
    bd40:	540001a1 	b.ne	bd74 <f0+0x1e04>  // b.any
    bd44:	29430002 	ldp	w2, w0, [x0, #24]
    bd48:	92403c21 	and	x1, x1, #0xffff
    bd4c:	9b027c21 	mul	x1, x1, x2
    bd50:	d360fc21 	lsr	x1, x1, #32
    bd54:	eb00003f 	cmp	x1, x0
    bd58:	540000e2 	b.cs	bd74 <f0+0x1e04>  // b.hs, b.nlast
    bd5c:	8b0102f7 	add	x23, x23, x1
    bd60:	394002e0 	ldrb	w0, [x23]
    bd64:	7103fc1f 	cmp	w0, #0xff
    bd68:	54004160 	b.eq	c594 <f0+0x2624>  // b.none
    bd6c:	52800020 	mov	w0, #0x1                   	// #1
    bd70:	390002e0 	strb	w0, [x23]
    bd74:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bd78:	911d63e1 	add	x1, sp, #0x758
    bd7c:	52800020 	mov	w0, #0x1                   	// #1
    bd80:	f903afe2 	str	x2, [sp, #1880]
    bd84:	f903b3f5 	str	x21, [sp, #1888]
    bd88:	97ffe543 	bl	5294 <fwp_data.part.0.constprop.0>
    bd8c:	9118c283 	add	x3, x20, #0x630
    bd90:	aa0003f5 	mov	x21, x0
    bd94:	f949d861 	ldr	x1, [x3, #5040]
    bd98:	f949ec60 	ldr	x0, [x3, #5080]
    bd9c:	cb0102a1 	sub	x1, x21, x1
    bda0:	eb00403f 	cmp	x1, x0, lsl #16
    bda4:	54000322 	b.cs	be08 <f0+0x1e98>  // b.hs, b.nlast
    bda8:	d350fc22 	lsr	x2, x1, #16
    bdac:	f949fc63 	ldr	x3, [x3, #5112]
    bdb0:	8b020842 	add	x2, x2, x2, lsl #2
    bdb4:	d37df042 	lsl	x2, x2, #3
    bdb8:	8b020060 	add	x0, x3, x2
    bdbc:	f9401017 	ldr	x23, [x0, #32]
    bdc0:	b4000257 	cbz	x23, be08 <f0+0x1e98>
    bdc4:	38626862 	ldrb	w2, [x3, x2]
    bdc8:	7100085f 	cmp	w2, #0x2
    bdcc:	54002d00 	b.eq	c36c <f0+0x23fc>  // b.none
    bdd0:	7100045f 	cmp	w2, #0x1
    bdd4:	540001a1 	b.ne	be08 <f0+0x1e98>  // b.any
    bdd8:	29430002 	ldp	w2, w0, [x0, #24]
    bddc:	92403c21 	and	x1, x1, #0xffff
    bde0:	9b027c21 	mul	x1, x1, x2
    bde4:	d360fc21 	lsr	x1, x1, #32
    bde8:	eb00003f 	cmp	x1, x0
    bdec:	540000e2 	b.cs	be08 <f0+0x1e98>  // b.hs, b.nlast
    bdf0:	8b0102f7 	add	x23, x23, x1
    bdf4:	394002e0 	ldrb	w0, [x23]
    bdf8:	7103fc1f 	cmp	w0, #0xff
    bdfc:	54003d20 	b.eq	c5a0 <f0+0x2630>  // b.none
    be00:	52800020 	mov	w0, #0x1                   	// #1
    be04:	390002e0 	strb	w0, [x23]
    be08:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be0c:	911da3e1 	add	x1, sp, #0x768
    be10:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be14:	52800020 	mov	w0, #0x1                   	// #1
    be18:	f903b7e2 	str	x2, [sp, #1896]
    be1c:	f903bbf5 	str	x21, [sp, #1904]
    be20:	97ffe51d 	bl	5294 <fwp_data.part.0.constprop.0>
    be24:	97ffe694 	bl	5874 <fwp_rc_fresh>
    be28:	aa0003e2 	mov	x2, x0
    be2c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    be30:	911de3e1 	add	x1, sp, #0x778
    be34:	52800020 	mov	w0, #0x1                   	// #1
    be38:	f903bfe3 	str	x3, [sp, #1912]
    be3c:	f903c3e2 	str	x2, [sp, #1920]
    be40:	97ffe515 	bl	5294 <fwp_data.part.0.constprop.0>
    be44:	9118c283 	add	x3, x20, #0x630
    be48:	aa0003f5 	mov	x21, x0
    be4c:	f949d861 	ldr	x1, [x3, #5040]
    be50:	f949ec60 	ldr	x0, [x3, #5080]
    be54:	cb0102a1 	sub	x1, x21, x1
    be58:	eb00403f 	cmp	x1, x0, lsl #16
    be5c:	54000322 	b.cs	bec0 <f0+0x1f50>  // b.hs, b.nlast
    be60:	d350fc22 	lsr	x2, x1, #16
    be64:	f949fc63 	ldr	x3, [x3, #5112]
    be68:	8b020842 	add	x2, x2, x2, lsl #2
    be6c:	d37df042 	lsl	x2, x2, #3
    be70:	8b020060 	add	x0, x3, x2
    be74:	f9401017 	ldr	x23, [x0, #32]
    be78:	b4000257 	cbz	x23, bec0 <f0+0x1f50>
    be7c:	38626862 	ldrb	w2, [x3, x2]
    be80:	7100085f 	cmp	w2, #0x2
    be84:	540026e0 	b.eq	c360 <f0+0x23f0>  // b.none
    be88:	7100045f 	cmp	w2, #0x1
    be8c:	540001a1 	b.ne	bec0 <f0+0x1f50>  // b.any
    be90:	29430002 	ldp	w2, w0, [x0, #24]
    be94:	92403c21 	and	x1, x1, #0xffff
    be98:	9b027c21 	mul	x1, x1, x2
    be9c:	d360fc21 	lsr	x1, x1, #32
    bea0:	eb00003f 	cmp	x1, x0
    bea4:	540000e2 	b.cs	bec0 <f0+0x1f50>  // b.hs, b.nlast
    bea8:	8b0102f7 	add	x23, x23, x1
    beac:	394002e0 	ldrb	w0, [x23]
    beb0:	7103fc1f 	cmp	w0, #0xff
    beb4:	540037c0 	b.eq	c5ac <f0+0x263c>  // b.none
    beb8:	52800020 	mov	w0, #0x1                   	// #1
    bebc:	390002e0 	strb	w0, [x23]
    bec0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bec4:	911e23e1 	add	x1, sp, #0x788
    bec8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    becc:	52800020 	mov	w0, #0x1                   	// #1
    bed0:	f903c7e2 	str	x2, [sp, #1928]
    bed4:	f903cbf5 	str	x21, [sp, #1936]
    bed8:	97ffe4ef 	bl	5294 <fwp_data.part.0.constprop.0>
    bedc:	97ffe666 	bl	5874 <fwp_rc_fresh>
    bee0:	aa0003e2 	mov	x2, x0
    bee4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bee8:	911e63e1 	add	x1, sp, #0x798
    beec:	52800020 	mov	w0, #0x1                   	// #1
    bef0:	f903cfe3 	str	x3, [sp, #1944]
    bef4:	f903d3e2 	str	x2, [sp, #1952]
    bef8:	97ffe4e7 	bl	5294 <fwp_data.part.0.constprop.0>
    befc:	9118c283 	add	x3, x20, #0x630
    bf00:	aa0003f5 	mov	x21, x0
    bf04:	f949d861 	ldr	x1, [x3, #5040]
    bf08:	f949ec60 	ldr	x0, [x3, #5080]
    bf0c:	cb0102a1 	sub	x1, x21, x1
    bf10:	eb00403f 	cmp	x1, x0, lsl #16
    bf14:	54000322 	b.cs	bf78 <f0+0x2008>  // b.hs, b.nlast
    bf18:	d350fc22 	lsr	x2, x1, #16
    bf1c:	f949fc63 	ldr	x3, [x3, #5112]
    bf20:	8b020842 	add	x2, x2, x2, lsl #2
    bf24:	d37df042 	lsl	x2, x2, #3
    bf28:	8b020060 	add	x0, x3, x2
    bf2c:	f9401017 	ldr	x23, [x0, #32]
    bf30:	b4000257 	cbz	x23, bf78 <f0+0x2008>
    bf34:	38626862 	ldrb	w2, [x3, x2]
    bf38:	7100085f 	cmp	w2, #0x2
    bf3c:	540020c0 	b.eq	c354 <f0+0x23e4>  // b.none
    bf40:	7100045f 	cmp	w2, #0x1
    bf44:	540001a1 	b.ne	bf78 <f0+0x2008>  // b.any
    bf48:	29430002 	ldp	w2, w0, [x0, #24]
    bf4c:	92403c21 	and	x1, x1, #0xffff
    bf50:	9b027c21 	mul	x1, x1, x2
    bf54:	d360fc21 	lsr	x1, x1, #32
    bf58:	eb00003f 	cmp	x1, x0
    bf5c:	540000e2 	b.cs	bf78 <f0+0x2008>  // b.hs, b.nlast
    bf60:	8b0102f7 	add	x23, x23, x1
    bf64:	394002e0 	ldrb	w0, [x23]
    bf68:	7103fc1f 	cmp	w0, #0xff
    bf6c:	54003260 	b.eq	c5b8 <f0+0x2648>  // b.none
    bf70:	52800020 	mov	w0, #0x1                   	// #1
    bf74:	390002e0 	strb	w0, [x23]
    bf78:	911ea3e1 	add	x1, sp, #0x7a8
    bf7c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bf80:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bf84:	52800020 	mov	w0, #0x1                   	// #1
    bf88:	f903d7f7 	str	x23, [sp, #1960]
    bf8c:	f903dbf5 	str	x21, [sp, #1968]
    bf90:	97ffe4c1 	bl	5294 <fwp_data.part.0.constprop.0>
    bf94:	97ffe638 	bl	5874 <fwp_rc_fresh>
    bf98:	aa0003e2 	mov	x2, x0
    bf9c:	911ee3e1 	add	x1, sp, #0x7b8
    bfa0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bfa4:	52800020 	mov	w0, #0x1                   	// #1
    bfa8:	f903dff5 	str	x21, [sp, #1976]
    bfac:	f903e3e2 	str	x2, [sp, #1984]
    bfb0:	97ffe4b9 	bl	5294 <fwp_data.part.0.constprop.0>
    bfb4:	97ffe630 	bl	5874 <fwp_rc_fresh>
    bfb8:	aa0003e2 	mov	x2, x0
    bfbc:	911f23e1 	add	x1, sp, #0x7c8
    bfc0:	52800020 	mov	w0, #0x1                   	// #1
    bfc4:	f903e7f7 	str	x23, [sp, #1992]
    bfc8:	f903ebe2 	str	x2, [sp, #2000]
    bfcc:	97ffe4b2 	bl	5294 <fwp_data.part.0.constprop.0>
    bfd0:	97ffe629 	bl	5874 <fwp_rc_fresh>
    bfd4:	aa0003e2 	mov	x2, x0
    bfd8:	911f63e1 	add	x1, sp, #0x7d8
    bfdc:	52800020 	mov	w0, #0x1                   	// #1
    bfe0:	f903eff5 	str	x21, [sp, #2008]
    bfe4:	f903f3e2 	str	x2, [sp, #2016]
    bfe8:	97ffe4ab 	bl	5294 <fwp_data.part.0.constprop.0>
    bfec:	9118c283 	add	x3, x20, #0x630
    bff0:	aa0003f5 	mov	x21, x0
    bff4:	f949d861 	ldr	x1, [x3, #5040]
    bff8:	f949ec60 	ldr	x0, [x3, #5080]
    bffc:	cb0102a1 	sub	x1, x21, x1
    c000:	eb00403f 	cmp	x1, x0, lsl #16
    c004:	54000322 	b.cs	c068 <f0+0x20f8>  // b.hs, b.nlast
    c008:	d350fc22 	lsr	x2, x1, #16
    c00c:	f949fc63 	ldr	x3, [x3, #5112]
    c010:	8b020842 	add	x2, x2, x2, lsl #2
    c014:	d37df042 	lsl	x2, x2, #3
    c018:	8b020060 	add	x0, x3, x2
    c01c:	f9401017 	ldr	x23, [x0, #32]
    c020:	b4000257 	cbz	x23, c068 <f0+0x20f8>
    c024:	38626862 	ldrb	w2, [x3, x2]
    c028:	7100085f 	cmp	w2, #0x2
    c02c:	540018e0 	b.eq	c348 <f0+0x23d8>  // b.none
    c030:	7100045f 	cmp	w2, #0x1
    c034:	540001a1 	b.ne	c068 <f0+0x20f8>  // b.any
    c038:	29430002 	ldp	w2, w0, [x0, #24]
    c03c:	92403c21 	and	x1, x1, #0xffff
    c040:	9b027c21 	mul	x1, x1, x2
    c044:	d360fc21 	lsr	x1, x1, #32
    c048:	eb00003f 	cmp	x1, x0
    c04c:	540000e2 	b.cs	c068 <f0+0x20f8>  // b.hs, b.nlast
    c050:	8b0102f7 	add	x23, x23, x1
    c054:	394002e0 	ldrb	w0, [x23]
    c058:	7103fc1f 	cmp	w0, #0xff
    c05c:	54002b40 	b.eq	c5c4 <f0+0x2654>  // b.none
    c060:	52800020 	mov	w0, #0x1                   	// #1
    c064:	390002e0 	strb	w0, [x23]
    c068:	911fa3e1 	add	x1, sp, #0x7e8
    c06c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c070:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c074:	52800020 	mov	w0, #0x1                   	// #1
    c078:	f903f7f7 	str	x23, [sp, #2024]
    c07c:	9118c294 	add	x20, x20, #0x630
    c080:	f903fbf5 	str	x21, [sp, #2032]
    c084:	97ffe484 	bl	5294 <fwp_data.part.0.constprop.0>
    c088:	97ffe5fb 	bl	5874 <fwp_rc_fresh>
    c08c:	aa0003e2 	mov	x2, x0
    c090:	911fe3e1 	add	x1, sp, #0x7f8
    c094:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c098:	52800020 	mov	w0, #0x1                   	// #1
    c09c:	f903fff5 	str	x21, [sp, #2040]
    c0a0:	f90403e2 	str	x2, [sp, #2048]
    c0a4:	97ffe47c 	bl	5294 <fwp_data.part.0.constprop.0>
    c0a8:	97ffe5f3 	bl	5874 <fwp_rc_fresh>
    c0ac:	aa0003e2 	mov	x2, x0
    c0b0:	912023e1 	add	x1, sp, #0x808
    c0b4:	52800020 	mov	w0, #0x1                   	// #1
    c0b8:	f90407f7 	str	x23, [sp, #2056]
    c0bc:	f9040be2 	str	x2, [sp, #2064]
    c0c0:	97ffe475 	bl	5294 <fwp_data.part.0.constprop.0>
    c0c4:	97ffe5ec 	bl	5874 <fwp_rc_fresh>
    c0c8:	aa0003e2 	mov	x2, x0
    c0cc:	912063e1 	add	x1, sp, #0x818
    c0d0:	52800020 	mov	w0, #0x1                   	// #1
    c0d4:	f9040ff5 	str	x21, [sp, #2072]
    c0d8:	f90413e2 	str	x2, [sp, #2080]
    c0dc:	97ffe46e 	bl	5294 <fwp_data.part.0.constprop.0>
    c0e0:	97ffe5e5 	bl	5874 <fwp_rc_fresh>
    c0e4:	aa0003e2 	mov	x2, x0
    c0e8:	9120a3e1 	add	x1, sp, #0x828
    c0ec:	52800020 	mov	w0, #0x1                   	// #1
    c0f0:	f90417f7 	str	x23, [sp, #2088]
    c0f4:	f9041be2 	str	x2, [sp, #2096]
    c0f8:	97ffe467 	bl	5294 <fwp_data.part.0.constprop.0>
    c0fc:	97ffe5de 	bl	5874 <fwp_rc_fresh>
    c100:	aa0003e2 	mov	x2, x0
    c104:	9120e3e1 	add	x1, sp, #0x838
    c108:	52800020 	mov	w0, #0x1                   	// #1
    c10c:	f9041ff5 	str	x21, [sp, #2104]
    c110:	f90423e2 	str	x2, [sp, #2112]
    c114:	97ffe460 	bl	5294 <fwp_data.part.0.constprop.0>
    c118:	f949da81 	ldr	x1, [x20, #5040]
    c11c:	aa0003f5 	mov	x21, x0
    c120:	f949ee80 	ldr	x0, [x20, #5080]
    c124:	cb0102a1 	sub	x1, x21, x1
    c128:	eb00403f 	cmp	x1, x0, lsl #16
    c12c:	54000322 	b.cs	c190 <f0+0x2220>  // b.hs, b.nlast
    c130:	d350fc22 	lsr	x2, x1, #16
    c134:	f949fe83 	ldr	x3, [x20, #5112]
    c138:	8b020842 	add	x2, x2, x2, lsl #2
    c13c:	d37df042 	lsl	x2, x2, #3
    c140:	8b020060 	add	x0, x3, x2
    c144:	f9401014 	ldr	x20, [x0, #32]
    c148:	b4000254 	cbz	x20, c190 <f0+0x2220>
    c14c:	38626862 	ldrb	w2, [x3, x2]
    c150:	7100085f 	cmp	w2, #0x2
    c154:	54000f40 	b.eq	c33c <f0+0x23cc>  // b.none
    c158:	7100045f 	cmp	w2, #0x1
    c15c:	540001a1 	b.ne	c190 <f0+0x2220>  // b.any
    c160:	29430002 	ldp	w2, w0, [x0, #24]
    c164:	92403c21 	and	x1, x1, #0xffff
    c168:	9b027c21 	mul	x1, x1, x2
    c16c:	d360fc21 	lsr	x1, x1, #32
    c170:	eb00003f 	cmp	x1, x0
    c174:	540000e2 	b.cs	c190 <f0+0x2220>  // b.hs, b.nlast
    c178:	8b010294 	add	x20, x20, x1
    c17c:	39400280 	ldrb	w0, [x20]
    c180:	7103fc1f 	cmp	w0, #0xff
    c184:	540013c0 	b.eq	c3fc <f0+0x248c>  // b.none
    c188:	52800020 	mov	w0, #0x1                   	// #1
    c18c:	39000280 	strb	w0, [x20]
    c190:	aa1603e1 	mov	x1, x22
    c194:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c198:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c19c:	52800020 	mov	w0, #0x1                   	// #1
    c1a0:	f90427e2 	str	x2, [sp, #2120]
    c1a4:	f9042bf5 	str	x21, [sp, #2128]
    c1a8:	97ffe43b 	bl	5294 <fwp_data.part.0.constprop.0>
    c1ac:	97ffe5b2 	bl	5874 <fwp_rc_fresh>
    c1b0:	aa0003f5 	mov	x21, x0
    c1b4:	aa1303e1 	mov	x1, x19
    c1b8:	97fff07e 	bl	83b0 <fwp_hof0.constprop.0>
    c1bc:	aa0003f4 	mov	x20, x0
    c1c0:	aa1503e0 	mov	x0, x21
    c1c4:	97ffe6bb 	bl	5cb0 <fwp_drop0>
    c1c8:	aa1303e0 	mov	x0, x19
    c1cc:	97ffe6b9 	bl	5cb0 <fwp_drop0>
    c1d0:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    c1d4:	f947f400 	ldr	x0, [x0, #4072]
    c1d8:	f9442fe2 	ldr	x2, [sp, #2136]
    c1dc:	f9400001 	ldr	x1, [x0]
    c1e0:	eb010042 	subs	x2, x2, x1
    c1e4:	d2800001 	mov	x1, #0x0                   	// #0
    c1e8:	54001f41 	b.ne	c5d0 <f0+0x2660>  // b.any
    c1ec:	912183ff 	add	sp, sp, #0x860
    c1f0:	aa1403e0 	mov	x0, x20
    c1f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    c1f8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c1fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    c200:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c204:	a94573fb 	ldp	x27, x28, [sp, #80]
    c208:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c20c:	d65f03c0 	ret
    c210:	aa1b03e0 	mov	x0, x27
    c214:	97ffe1ff 	bl	4a10 <fwp_rc_forget_slot>
    c218:	17fff79e 	b	a090 <f0+0x120>
    c21c:	72003c5f 	tst	w2, #0xffff
    c220:	54fef3a1 	b.ne	a094 <f0+0x124>  // b.any
    c224:	17fff798 	b	a084 <f0+0x114>
    c228:	72003c3f 	tst	w1, #0xffff
    c22c:	54ff9a41 	b.ne	b574 <f0+0x1604>  // b.any
    c230:	17fffccc 	b	b560 <f0+0x15f0>
    c234:	72003c3f 	tst	w1, #0xffff
    c238:	54ff9341 	b.ne	b4a0 <f0+0x1530>  // b.any
    c23c:	17fffc94 	b	b48c <f0+0x151c>
    c240:	72003c3f 	tst	w1, #0xffff
    c244:	54ff8d21 	b.ne	b3e8 <f0+0x1478>  // b.any
    c248:	17fffc63 	b	b3d4 <f0+0x1464>
    c24c:	72003c3f 	tst	w1, #0xffff
    c250:	54ff8701 	b.ne	b330 <f0+0x13c0>  // b.any
    c254:	17fffc32 	b	b31c <f0+0x13ac>
    c258:	72003c3f 	tst	w1, #0xffff
    c25c:	54ff8201 	b.ne	b29c <f0+0x132c>  // b.any
    c260:	17fffc0a 	b	b288 <f0+0x1318>
    c264:	72003c3f 	tst	w1, #0xffff
    c268:	54ff7b01 	b.ne	b1c8 <f0+0x1258>  // b.any
    c26c:	17fffbd2 	b	b1b4 <f0+0x1244>
    c270:	72003c3f 	tst	w1, #0xffff
    c274:	54ff74e1 	b.ne	b110 <f0+0x11a0>  // b.any
    c278:	17fffba1 	b	b0fc <f0+0x118c>
    c27c:	72003c3f 	tst	w1, #0xffff
    c280:	54ff6ec1 	b.ne	b058 <f0+0x10e8>  // b.any
    c284:	17fffb70 	b	b044 <f0+0x10d4>
    c288:	72003c3f 	tst	w1, #0xffff
    c28c:	54ff1581 	b.ne	a53c <f0+0x5cc>  // b.any
    c290:	17fff8a6 	b	a528 <f0+0x5b8>
    c294:	72003c3f 	tst	w1, #0xffff
    c298:	54ff0101 	b.ne	a2b8 <f0+0x348>  // b.any
    c29c:	17fff802 	b	a2a4 <f0+0x334>
    c2a0:	72003c3f 	tst	w1, #0xffff
    c2a4:	54fefc21 	b.ne	a228 <f0+0x2b8>  // b.any
    c2a8:	17fff7db 	b	a214 <f0+0x2a4>
    c2ac:	72003c3f 	tst	w1, #0xffff
    c2b0:	54ff2f81 	b.ne	a8a0 <f0+0x930>  // b.any
    c2b4:	17fff976 	b	a88c <f0+0x91c>
    c2b8:	72003c3f 	tst	w1, #0xffff
    c2bc:	54ff27a1 	b.ne	a7b0 <f0+0x840>  // b.any
    c2c0:	17fff937 	b	a79c <f0+0x82c>
    c2c4:	72003c3f 	tst	w1, #0xffff
    c2c8:	54ff22a1 	b.ne	a71c <f0+0x7ac>  // b.any
    c2cc:	17fff90f 	b	a708 <f0+0x798>
    c2d0:	72003c3f 	tst	w1, #0xffff
    c2d4:	54ff1c81 	b.ne	a664 <f0+0x6f4>  // b.any
    c2d8:	17fff8de 	b	a650 <f0+0x6e0>
    c2dc:	72003c3f 	tst	w1, #0xffff
    c2e0:	54ff6721 	b.ne	afc4 <f0+0x1054>  // b.any
    c2e4:	17fffb33 	b	afb0 <f0+0x1040>
    c2e8:	72003c3f 	tst	w1, #0xffff
    c2ec:	54ff6021 	b.ne	aef0 <f0+0xf80>  // b.any
    c2f0:	17fffafb 	b	aedc <f0+0xf6c>
    c2f4:	72003c3f 	tst	w1, #0xffff
    c2f8:	54ff5a01 	b.ne	ae38 <f0+0xec8>  // b.any
    c2fc:	17fffaca 	b	ae24 <f0+0xeb4>
    c300:	72003c3f 	tst	w1, #0xffff
    c304:	54ff53e1 	b.ne	ad80 <f0+0xe10>  // b.any
    c308:	17fffa99 	b	ad6c <f0+0xdfc>
    c30c:	72003c3f 	tst	w1, #0xffff
    c310:	54ff4ee1 	b.ne	acec <f0+0xd7c>  // b.any
    c314:	17fffa71 	b	acd8 <f0+0xd68>
    c318:	72003c3f 	tst	w1, #0xffff
    c31c:	54ff4461 	b.ne	aba8 <f0+0xc38>  // b.any
    c320:	17fffa1d 	b	ab94 <f0+0xc24>
    c324:	72003c3f 	tst	w1, #0xffff
    c328:	54ff3e41 	b.ne	aaf0 <f0+0xb80>  // b.any
    c32c:	17fff9ec 	b	aadc <f0+0xb6c>
    c330:	72003c3f 	tst	w1, #0xffff
    c334:	54ff3821 	b.ne	aa38 <f0+0xac8>  // b.any
    c338:	17fff9bb 	b	aa24 <f0+0xab4>
    c33c:	72003c3f 	tst	w1, #0xffff
    c340:	54fff281 	b.ne	c190 <f0+0x2220>  // b.any
    c344:	17ffff8e 	b	c17c <f0+0x220c>
    c348:	72003c3f 	tst	w1, #0xffff
    c34c:	54ffe8e1 	b.ne	c068 <f0+0x20f8>  // b.any
    c350:	17ffff41 	b	c054 <f0+0x20e4>
    c354:	72003c3f 	tst	w1, #0xffff
    c358:	54ffe101 	b.ne	bf78 <f0+0x2008>  // b.any
    c35c:	17ffff02 	b	bf64 <f0+0x1ff4>
    c360:	72003c3f 	tst	w1, #0xffff
    c364:	54ffdae1 	b.ne	bec0 <f0+0x1f50>  // b.any
    c368:	17fffed1 	b	beac <f0+0x1f3c>
    c36c:	72003c3f 	tst	w1, #0xffff
    c370:	54ffd4c1 	b.ne	be08 <f0+0x1e98>  // b.any
    c374:	17fffea0 	b	bdf4 <f0+0x1e84>
    c378:	72003c3f 	tst	w1, #0xffff
    c37c:	54ffcfc1 	b.ne	bd74 <f0+0x1e04>  // b.any
    c380:	17fffe78 	b	bd60 <f0+0x1df0>
    c384:	72003c3f 	tst	w1, #0xffff
    c388:	54ffc8c1 	b.ne	bca0 <f0+0x1d30>  // b.any
    c38c:	17fffe40 	b	bc8c <f0+0x1d1c>
    c390:	72003c3f 	tst	w1, #0xffff
    c394:	54ffc001 	b.ne	bb94 <f0+0x1c24>  // b.any
    c398:	17fffdfa 	b	bb80 <f0+0x1c10>
    c39c:	72003c3f 	tst	w1, #0xffff
    c3a0:	54ffbae1 	b.ne	bafc <f0+0x1b8c>  // b.any
    c3a4:	17fffdd1 	b	bae8 <f0+0x1b78>
    c3a8:	72003c3f 	tst	w1, #0xffff
    c3ac:	54ffb5e1 	b.ne	ba68 <f0+0x1af8>  // b.any
    c3b0:	17fffda9 	b	ba54 <f0+0x1ae4>
    c3b4:	72003c3f 	tst	w1, #0xffff
    c3b8:	54ffb0c1 	b.ne	b9d0 <f0+0x1a60>  // b.any
    c3bc:	17fffd80 	b	b9bc <f0+0x1a4c>
    c3c0:	72003c3f 	tst	w1, #0xffff
    c3c4:	54ffa8e1 	b.ne	b8e0 <f0+0x1970>  // b.any
    c3c8:	17fffd41 	b	b8cc <f0+0x195c>
    c3cc:	72003c3f 	tst	w1, #0xffff
    c3d0:	54ffa3e1 	b.ne	b84c <f0+0x18dc>  // b.any
    c3d4:	17fffd19 	b	b838 <f0+0x18c8>
    c3d8:	72003c3f 	tst	w1, #0xffff
    c3dc:	54ff9ce1 	b.ne	b778 <f0+0x1808>  // b.any
    c3e0:	17fffce1 	b	b764 <f0+0x17f4>
    c3e4:	72003c3f 	tst	w1, #0xffff
    c3e8:	54ff96c1 	b.ne	b6c0 <f0+0x1750>  // b.any
    c3ec:	17fffcb0 	b	b6ac <f0+0x173c>
    c3f0:	72003c3f 	tst	w1, #0xffff
    c3f4:	54ff90a1 	b.ne	b608 <f0+0x1698>  // b.any
    c3f8:	17fffc7f 	b	b5f4 <f0+0x1684>
    c3fc:	aa1403e0 	mov	x0, x20
    c400:	97ffe184 	bl	4a10 <fwp_rc_forget_slot>
    c404:	17ffff61 	b	c188 <f0+0x2218>
    c408:	aa1703e0 	mov	x0, x23
    c40c:	97ffe181 	bl	4a10 <fwp_rc_forget_slot>
    c410:	17fff784 	b	a220 <f0+0x2b0>
    c414:	aa1503e0 	mov	x0, x21
    c418:	97ffe17e 	bl	4a10 <fwp_rc_forget_slot>
    c41c:	17fff7a5 	b	a2b0 <f0+0x340>
    c420:	aa1703e0 	mov	x0, x23
    c424:	97ffe17b 	bl	4a10 <fwp_rc_forget_slot>
    c428:	17fff843 	b	a534 <f0+0x5c4>
    c42c:	aa1703e0 	mov	x0, x23
    c430:	97ffe178 	bl	4a10 <fwp_rc_forget_slot>
    c434:	17fff88a 	b	a65c <f0+0x6ec>
    c438:	aa1703e0 	mov	x0, x23
    c43c:	97ffe175 	bl	4a10 <fwp_rc_forget_slot>
    c440:	17fff8b5 	b	a714 <f0+0x7a4>
    c444:	aa1703e0 	mov	x0, x23
    c448:	97ffe172 	bl	4a10 <fwp_rc_forget_slot>
    c44c:	17fff8d7 	b	a7a8 <f0+0x838>
    c450:	aa1703e0 	mov	x0, x23
    c454:	97ffe16f 	bl	4a10 <fwp_rc_forget_slot>
    c458:	17fff910 	b	a898 <f0+0x928>
    c45c:	aa1703e0 	mov	x0, x23
    c460:	97ffe16c 	bl	4a10 <fwp_rc_forget_slot>
    c464:	17fff973 	b	aa30 <f0+0xac0>
    c468:	aa1703e0 	mov	x0, x23
    c46c:	97ffe169 	bl	4a10 <fwp_rc_forget_slot>
    c470:	17fff99e 	b	aae8 <f0+0xb78>
    c474:	aa1503e0 	mov	x0, x21
    c478:	97ffe166 	bl	4a10 <fwp_rc_forget_slot>
    c47c:	17fff9c9 	b	aba0 <f0+0xc30>
    c480:	aa1703e0 	mov	x0, x23
    c484:	97ffe163 	bl	4a10 <fwp_rc_forget_slot>
    c488:	17fffa17 	b	ace4 <f0+0xd74>
    c48c:	aa1703e0 	mov	x0, x23
    c490:	97ffe160 	bl	4a10 <fwp_rc_forget_slot>
    c494:	17fffa39 	b	ad78 <f0+0xe08>
    c498:	aa1703e0 	mov	x0, x23
    c49c:	97ffe15d 	bl	4a10 <fwp_rc_forget_slot>
    c4a0:	17fffa64 	b	ae30 <f0+0xec0>
    c4a4:	aa1703e0 	mov	x0, x23
    c4a8:	97ffe15a 	bl	4a10 <fwp_rc_forget_slot>
    c4ac:	17fffa8f 	b	aee8 <f0+0xf78>
    c4b0:	aa1703e0 	mov	x0, x23
    c4b4:	97ffe157 	bl	4a10 <fwp_rc_forget_slot>
    c4b8:	17fffac1 	b	afbc <f0+0x104c>
    c4bc:	aa1703e0 	mov	x0, x23
    c4c0:	97ffe154 	bl	4a10 <fwp_rc_forget_slot>
    c4c4:	17fffae3 	b	b050 <f0+0x10e0>
    c4c8:	aa1703e0 	mov	x0, x23
    c4cc:	97ffe151 	bl	4a10 <fwp_rc_forget_slot>
    c4d0:	17fffb0e 	b	b108 <f0+0x1198>
    c4d4:	aa1703e0 	mov	x0, x23
    c4d8:	97ffe14e 	bl	4a10 <fwp_rc_forget_slot>
    c4dc:	17fffb39 	b	b1c0 <f0+0x1250>
    c4e0:	aa1703e0 	mov	x0, x23
    c4e4:	97ffe14b 	bl	4a10 <fwp_rc_forget_slot>
    c4e8:	17fffb6b 	b	b294 <f0+0x1324>
    c4ec:	aa1703e0 	mov	x0, x23
    c4f0:	97ffe148 	bl	4a10 <fwp_rc_forget_slot>
    c4f4:	17fffb8d 	b	b328 <f0+0x13b8>
    c4f8:	aa1703e0 	mov	x0, x23
    c4fc:	97ffe145 	bl	4a10 <fwp_rc_forget_slot>
    c500:	17fffbb8 	b	b3e0 <f0+0x1470>
    c504:	aa1703e0 	mov	x0, x23
    c508:	97ffe142 	bl	4a10 <fwp_rc_forget_slot>
    c50c:	17fffbe3 	b	b498 <f0+0x1528>
    c510:	aa1703e0 	mov	x0, x23
    c514:	97ffe13f 	bl	4a10 <fwp_rc_forget_slot>
    c518:	17fffc15 	b	b56c <f0+0x15fc>
    c51c:	aa1703e0 	mov	x0, x23
    c520:	97ffe13c 	bl	4a10 <fwp_rc_forget_slot>
    c524:	17fffc37 	b	b600 <f0+0x1690>
    c528:	aa1703e0 	mov	x0, x23
    c52c:	97ffe139 	bl	4a10 <fwp_rc_forget_slot>
    c530:	17fffc62 	b	b6b8 <f0+0x1748>
    c534:	aa1703e0 	mov	x0, x23
    c538:	97ffe136 	bl	4a10 <fwp_rc_forget_slot>
    c53c:	17fffc8d 	b	b770 <f0+0x1800>
    c540:	aa1703e0 	mov	x0, x23
    c544:	97ffe133 	bl	4a10 <fwp_rc_forget_slot>
    c548:	17fffcbf 	b	b844 <f0+0x18d4>
    c54c:	aa1703e0 	mov	x0, x23
    c550:	97ffe130 	bl	4a10 <fwp_rc_forget_slot>
    c554:	17fffce1 	b	b8d8 <f0+0x1968>
    c558:	aa1703e0 	mov	x0, x23
    c55c:	97ffe12d 	bl	4a10 <fwp_rc_forget_slot>
    c560:	17fffd1a 	b	b9c8 <f0+0x1a58>
    c564:	aa1703e0 	mov	x0, x23
    c568:	97ffe12a 	bl	4a10 <fwp_rc_forget_slot>
    c56c:	17fffd3d 	b	ba60 <f0+0x1af0>
    c570:	aa1703e0 	mov	x0, x23
    c574:	97ffe127 	bl	4a10 <fwp_rc_forget_slot>
    c578:	17fffd5f 	b	baf4 <f0+0x1b84>
    c57c:	aa1703e0 	mov	x0, x23
    c580:	97ffe124 	bl	4a10 <fwp_rc_forget_slot>
    c584:	17fffd82 	b	bb8c <f0+0x1c1c>
    c588:	aa1703e0 	mov	x0, x23
    c58c:	97ffe121 	bl	4a10 <fwp_rc_forget_slot>
    c590:	17fffdc2 	b	bc98 <f0+0x1d28>
    c594:	aa1703e0 	mov	x0, x23
    c598:	97ffe11e 	bl	4a10 <fwp_rc_forget_slot>
    c59c:	17fffdf4 	b	bd6c <f0+0x1dfc>
    c5a0:	aa1703e0 	mov	x0, x23
    c5a4:	97ffe11b 	bl	4a10 <fwp_rc_forget_slot>
    c5a8:	17fffe16 	b	be00 <f0+0x1e90>
    c5ac:	aa1703e0 	mov	x0, x23
    c5b0:	97ffe118 	bl	4a10 <fwp_rc_forget_slot>
    c5b4:	17fffe41 	b	beb8 <f0+0x1f48>
    c5b8:	aa1703e0 	mov	x0, x23
    c5bc:	97ffe115 	bl	4a10 <fwp_rc_forget_slot>
    c5c0:	17fffe6c 	b	bf70 <f0+0x2000>
    c5c4:	aa1703e0 	mov	x0, x23
    c5c8:	97ffe112 	bl	4a10 <fwp_rc_forget_slot>
    c5cc:	17fffea5 	b	c060 <f0+0x20f0>
    c5d0:	97ffd8b4 	bl	28a0 <__stack_chk_fail@plt>

000000000000c5d4 <fwp_main_thread>:
    c5d4:	d10443ff 	sub	sp, sp, #0x110
    c5d8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    c5dc:	f947f400 	ldr	x0, [x0, #4072]
    c5e0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c5e4:	910303fd 	add	x29, sp, #0xc0
    c5e8:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c5ec:	b0000376 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    c5f0:	9118c2c1 	add	x1, x22, #0x630
    c5f4:	a90d53f3 	stp	x19, x20, [sp, #208]
    c5f8:	a90f63f7 	stp	x23, x24, [sp, #240]
    c5fc:	b953a421 	ldr	w1, [x1, #5028]
    c600:	a9106bf9 	stp	x25, x26, [sp, #256]
    c604:	f9400002 	ldr	x2, [x0]
    c608:	f9005fe2 	str	x2, [sp, #184]
    c60c:	d2800002 	mov	x2, #0x0                   	// #0
    c610:	34002941 	cbz	w1, cb38 <fwp_main_thread+0x564>
    c614:	9118c2c0 	add	x0, x22, #0x630
    c618:	b953a800 	ldr	w0, [x0, #5032]
    c61c:	35002860 	cbnz	w0, cb28 <fwp_main_thread+0x554>
    c620:	91001fe2 	add	x2, sp, #0x7
    c624:	900000b5 	adrp	x21, 20000 <__data_start>
    c628:	900000a3 	adrp	x3, 20000 <__data_start>
    c62c:	910142b3 	add	x19, x21, #0x50
    c630:	91114063 	add	x3, x3, #0x450
    c634:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c638:	d2a00025 	mov	x5, #0x10000               	// #65536
    c63c:	910023e0 	add	x0, sp, #0x8
    c640:	d2800001 	mov	x1, #0x0                   	// #0
    c644:	f90007e3 	str	x3, [sp, #8]
    c648:	b90013ff 	str	wzr, [sp, #16]
    c64c:	f9000fe5 	str	x5, [sp, #24]
    c650:	a90a1262 	stp	x2, x4, [x19, #160]
    c654:	97ffd82b 	bl	2700 <sigaltstack@plt>
    c658:	35002880 	cbnz	w0, cb68 <fwp_main_thread+0x594>
    c65c:	4f000400 	movi	v0.4s, #0x0
    c660:	9100a3e0 	add	x0, sp, #0x28
    c664:	f0ffffa1 	adrp	x1, 3000 <ad_raw_record+0x70>
    c668:	52800082 	mov	w2, #0x4                   	// #4
    c66c:	9102c021 	add	x1, x1, #0xb0
    c670:	72a10002 	movk	w2, #0x800, lsl #16
    c674:	910083f4 	add	x20, sp, #0x20
    c678:	f90013e1 	str	x1, [sp, #32]
    c67c:	3d802000 	str	q0, [x0, #128]
    c680:	b900abe2 	str	w2, [sp, #168]
    c684:	ad000000 	stp	q0, q0, [x0]
    c688:	ad010000 	stp	q0, q0, [x0, #32]
    c68c:	ad020000 	stp	q0, q0, [x0, #64]
    c690:	ad030000 	stp	q0, q0, [x0, #96]
    c694:	97ffd873 	bl	2860 <sigemptyset@plt>
    c698:	35002680 	cbnz	w0, cb68 <fwp_main_thread+0x594>
    c69c:	aa1403e1 	mov	x1, x20
    c6a0:	d2800002 	mov	x2, #0x0                   	// #0
    c6a4:	52800160 	mov	w0, #0xb                   	// #11
    c6a8:	97ffd886 	bl	28c0 <sigaction@plt>
    c6ac:	350025e0 	cbnz	w0, cb68 <fwp_main_thread+0x594>
    c6b0:	aa1403e1 	mov	x1, x20
    c6b4:	d2800002 	mov	x2, #0x0                   	// #0
    c6b8:	528000e0 	mov	w0, #0x7                   	// #7
    c6bc:	97ffd881 	bl	28c0 <sigaction@plt>
    c6c0:	35002540 	cbnz	w0, cb68 <fwp_main_thread+0x594>
    c6c4:	9118c2c1 	add	x1, x22, #0x630
    c6c8:	52800034 	mov	w20, #0x1                   	// #1
    c6cc:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    c6d0:	910ec000 	add	x0, x0, #0x3b0
    c6d4:	b9013274 	str	w20, [x19, #304]
    c6d8:	fd4a1020 	ldr	d0, [x1, #5152]
    c6dc:	7e61d800 	ucvtf	d0, d0
    c6e0:	fd00a660 	str	d0, [x19, #328]
    c6e4:	940002e7 	bl	d280 <atexit>
    c6e8:	35002460 	cbnz	w0, cb74 <fwp_main_thread+0x5a0>
    c6ec:	b943ca60 	ldr	w0, [x19, #968]
    c6f0:	34002280 	cbz	w0, cb40 <fwp_main_thread+0x56c>
    c6f4:	910142ba 	add	x26, x21, #0x50
    c6f8:	f9404f54 	ldr	x20, [x26, #152]
    c6fc:	b4001094 	cbz	x20, c90c <fwp_main_thread+0x338>
    c700:	aa1403f3 	mov	x19, x20
    c704:	91010297 	add	x23, x20, #0x40
    c708:	39414a99 	ldrb	w25, [x20, #82]
    c70c:	52800038 	mov	w24, #0x1                   	// #1
    c710:	39014a98 	strb	w24, [x20, #82]
    c714:	f9401680 	ldr	x0, [x20, #40]
    c718:	b4000620 	cbz	x0, c7dc <fwp_main_thread+0x208>
    c71c:	f9403281 	ldr	x1, [x20, #96]
    c720:	39414680 	ldrb	w0, [x20, #81]
    c724:	b4000b21 	cbz	x1, c888 <fwp_main_thread+0x2b4>
    c728:	36000a60 	tbz	w0, #0, c874 <fwp_main_thread+0x2a0>
    c72c:	39414a62 	ldrb	w2, [x19, #82]
    c730:	f9402280 	ldr	x0, [x20, #64]
    c734:	37000d42 	tbnz	w2, #0, c8dc <fwp_main_thread+0x308>
    c738:	f9403261 	ldr	x1, [x19, #96]
    c73c:	a911fe77 	stp	x23, xzr, [x19, #280]
    c740:	f9009660 	str	x0, [x19, #296]
    c744:	b4000040 	cbz	x0, c74c <fwp_main_thread+0x178>
    c748:	f9009013 	str	x19, [x0, #288]
    c74c:	f9002293 	str	x19, [x20, #64]
    c750:	b4000101 	cbz	x1, c770 <fwp_main_thread+0x19c>
    c754:	f9409740 	ldr	x0, [x26, #296]
    c758:	39015678 	strb	w24, [x19, #85]
    c75c:	f9003661 	str	x1, [x19, #104]
    c760:	a910827f 	stp	xzr, x0, [x19, #264]
    c764:	b4000040 	cbz	x0, c76c <fwp_main_thread+0x198>
    c768:	f9008413 	str	x19, [x0, #264]
    c76c:	f9009753 	str	x19, [x26, #296]
    c770:	39015a7f 	strb	wzr, [x19, #86]
    c774:	97ffe870 	bl	6934 <fwp_block>
    c778:	f9408e62 	ldr	x2, [x19, #280]
    c77c:	b4000142 	cbz	x2, c7a4 <fwp_main_thread+0x1d0>
    c780:	a9520261 	ldp	x1, x0, [x19, #288]
    c784:	b4000b81 	cbz	x1, c8f4 <fwp_main_thread+0x320>
    c788:	f9009420 	str	x0, [x1, #296]
    c78c:	f9409660 	ldr	x0, [x19, #296]
    c790:	b4000040 	cbz	x0, c798 <fwp_main_thread+0x1c4>
    c794:	f9009001 	str	x1, [x0, #288]
    c798:	91080260 	add	x0, x19, #0x200
    c79c:	f900967f 	str	xzr, [x19, #296]
    c7a0:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c7a4:	39415660 	ldrb	w0, [x19, #85]
    c7a8:	f9404f42 	ldr	x2, [x26, #152]
    c7ac:	36000940 	tbz	w0, #0, c8d4 <fwp_main_thread+0x300>
    c7b0:	a9508261 	ldp	x1, x0, [x19, #264]
    c7b4:	b4000a41 	cbz	x1, c8fc <fwp_main_thread+0x328>
    c7b8:	f9008820 	str	x0, [x1, #272]
    c7bc:	b4000040 	cbz	x0, c7c4 <fwp_main_thread+0x1f0>
    c7c0:	f9008401 	str	x1, [x0, #264]
    c7c4:	91080260 	add	x0, x19, #0x200
    c7c8:	3901567f 	strb	wzr, [x19, #85]
    c7cc:	aa0203f3 	mov	x19, x2
    c7d0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c7d4:	f9401680 	ldr	x0, [x20, #40]
    c7d8:	b5fffa20 	cbnz	x0, c71c <fwp_main_thread+0x148>
    c7dc:	910142a0 	add	x0, x21, #0x50
    c7e0:	39014a99 	strb	w25, [x20, #82]
    c7e4:	f941d400 	ldr	x0, [x0, #936]
    c7e8:	b4001820 	cbz	x0, caec <fwp_main_thread+0x518>
    c7ec:	910142a0 	add	x0, x21, #0x50
    c7f0:	f941f001 	ldr	x1, [x0, #992]
    c7f4:	b903d81f 	str	wzr, [x0, #984]
    c7f8:	eb13003f 	cmp	x1, x19
    c7fc:	54001941 	b.ne	cb24 <fwp_main_thread+0x550>  // b.any
    c800:	b4000913 	cbz	x19, c920 <fwp_main_thread+0x34c>
    c804:	910142a0 	add	x0, x21, #0x50
    c808:	52800021 	mov	w1, #0x1                   	// #1
    c80c:	39014a61 	strb	w1, [x19, #82]
    c810:	f941c005 	ldr	x5, [x0, #896]
    c814:	b4000865 	cbz	x5, c920 <fwp_main_thread+0x34c>
    c818:	394140a0 	ldrb	w0, [x5, #80]
    c81c:	37000060 	tbnz	w0, #0, c828 <fwp_main_thread+0x254>
    c820:	aa0503e0 	mov	x0, x5
    c824:	97ffdbb3 	bl	36f0 <fwp_cancel_tree.part.0>
    c828:	f9409ca5 	ldr	x5, [x5, #312]
    c82c:	b5ffff65 	cbnz	x5, c818 <fwp_main_thread+0x244>
    c830:	910142b4 	add	x20, x21, #0x50
    c834:	52800037 	mov	w23, #0x1                   	// #1
    c838:	f9402a60 	ldr	x0, [x19, #80]
    c83c:	f2001c1f 	tst	x0, #0xff000000ff
    c840:	540000e1 	b.ne	c85c <fwp_main_thread+0x288>  // b.any
    c844:	f9406280 	ldr	x0, [x20, #192]
    c848:	39015277 	strb	w23, [x19, #84]
    c84c:	f900827f 	str	xzr, [x19, #256]
    c850:	b40005a0 	cbz	x0, c904 <fwp_main_thread+0x330>
    c854:	f9008013 	str	x19, [x0, #256]
    c858:	f9006293 	str	x19, [x20, #192]
    c85c:	97ffe836 	bl	6934 <fwp_block>
    c860:	97ffe7c8 	bl	6780 <fwp_free_zombie>
    c864:	f941c280 	ldr	x0, [x20, #896]
    c868:	b40005c0 	cbz	x0, c920 <fwp_main_thread+0x34c>
    c86c:	f941f293 	ldr	x19, [x20, #992]
    c870:	17fffff2 	b	c838 <fwp_main_thread+0x264>
    c874:	97ffdc43 	bl	3980 <fwp_now_ns>
    c878:	f9403281 	ldr	x1, [x20, #96]
    c87c:	eb01001f 	cmp	x0, x1
    c880:	5400128a 	b.ge	cad0 <fwp_main_thread+0x4fc>  // b.tcont
    c884:	39414680 	ldrb	w0, [x20, #81]
    c888:	39414a62 	ldrb	w2, [x19, #82]
    c88c:	3707f520 	tbnz	w0, #0, c730 <fwp_main_thread+0x15c>
    c890:	f9403281 	ldr	x1, [x20, #96]
    c894:	370001c2 	tbnz	w2, #0, c8cc <fwp_main_thread+0x2f8>
    c898:	f9403260 	ldr	x0, [x19, #96]
    c89c:	b4000180 	cbz	x0, c8cc <fwp_main_thread+0x2f8>
    c8a0:	b4000061 	cbz	x1, c8ac <fwp_main_thread+0x2d8>
    c8a4:	eb01001f 	cmp	x0, x1
    c8a8:	9a81d000 	csel	x0, x0, x1, le
    c8ac:	f9402281 	ldr	x1, [x20, #64]
    c8b0:	a911fe77 	stp	x23, xzr, [x19, #280]
    c8b4:	f9009661 	str	x1, [x19, #296]
    c8b8:	b40014c1 	cbz	x1, cb50 <fwp_main_thread+0x57c>
    c8bc:	f9009033 	str	x19, [x1, #288]
    c8c0:	aa0003e1 	mov	x1, x0
    c8c4:	f9002293 	str	x19, [x20, #64]
    c8c8:	17ffffa3 	b	c754 <fwp_main_thread+0x180>
    c8cc:	f9402280 	ldr	x0, [x20, #64]
    c8d0:	17ffff9b 	b	c73c <fwp_main_thread+0x168>
    c8d4:	aa0203f3 	mov	x19, x2
    c8d8:	17ffff8f 	b	c714 <fwp_main_thread+0x140>
    c8dc:	a911fe77 	stp	x23, xzr, [x19, #280]
    c8e0:	f9009660 	str	x0, [x19, #296]
    c8e4:	b4000040 	cbz	x0, c8ec <fwp_main_thread+0x318>
    c8e8:	f9009013 	str	x19, [x0, #288]
    c8ec:	f9002293 	str	x19, [x20, #64]
    c8f0:	17ffffa0 	b	c770 <fwp_main_thread+0x19c>
    c8f4:	f9000040 	str	x0, [x2]
    c8f8:	17ffffa6 	b	c790 <fwp_main_thread+0x1bc>
    c8fc:	f9009740 	str	x0, [x26, #296]
    c900:	17ffffaf 	b	c7bc <fwp_main_thread+0x1e8>
    c904:	f9006693 	str	x19, [x20, #200]
    c908:	17ffffd4 	b	c858 <fwp_main_thread+0x284>
    c90c:	f941d740 	ldr	x0, [x26, #936]
    c910:	b4000ec0 	cbz	x0, cae8 <fwp_main_thread+0x514>
    c914:	f941f340 	ldr	x0, [x26, #992]
    c918:	b903db5f 	str	wzr, [x26, #984]
    c91c:	b5001040 	cbnz	x0, cb24 <fwp_main_thread+0x550>
    c920:	910142b4 	add	x20, x21, #0x50
    c924:	97ffe797 	bl	6780 <fwp_free_zombie>
    c928:	f9406680 	ldr	x0, [x20, #200]
    c92c:	b5000fc0 	cbnz	x0, cb24 <fwp_main_thread+0x550>
    c930:	f9409680 	ldr	x0, [x20, #296]
    c934:	b5000f80 	cbnz	x0, cb24 <fwp_main_thread+0x550>
    c938:	b9417293 	ldr	w19, [x20, #368]
    c93c:	340001d3 	cbz	w19, c974 <fwp_main_thread+0x3a0>
    c940:	93407e77 	sxtw	x23, w19
    c944:	51000673 	sub	w19, w19, #0x1
    c948:	d1000af7 	sub	x23, x23, #0x2
    c94c:	91060298 	add	x24, x20, #0x180
    c950:	cb3342f7 	sub	x23, x23, w19, uxtw
    c954:	93407e73 	sxtw	x19, w19
    c958:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    c95c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c960:	b9017293 	str	w19, [x20, #368]
    c964:	d1000673 	sub	x19, x19, #0x1
    c968:	97ffd816 	bl	29c0 <munmap@plt>
    c96c:	eb1302ff 	cmp	x23, x19
    c970:	54ffff41 	b.ne	c958 <fwp_main_thread+0x384>  // b.any
    c974:	900000b3 	adrp	x19, 20000 <__data_start>
    c978:	91004260 	add	x0, x19, #0x10
    c97c:	b9402800 	ldr	w0, [x0, #40]
    c980:	37f80040 	tbnz	w0, #31, c988 <fwp_main_thread+0x3b4>
    c984:	97ffd7cb 	bl	28b0 <close@plt>
    c988:	910142a0 	add	x0, x21, #0x50
    c98c:	91004261 	add	x1, x19, #0x10
    c990:	12800002 	mov	w2, #0xffffffff            	// #-1
    c994:	d2800013 	mov	x19, #0x0                   	// #0
    c998:	f941f417 	ldr	x23, [x0, #1000]
    c99c:	b9002822 	str	w2, [x1, #40]
    c9a0:	f941f814 	ldr	x20, [x0, #1008]
    c9a4:	b4000177 	cbz	x23, c9d0 <fwp_main_thread+0x3fc>
    c9a8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c9ac:	b40000c0 	cbz	x0, c9c4 <fwp_main_thread+0x3f0>
    c9b0:	f9400001 	ldr	x1, [x0]
    c9b4:	b5000b81 	cbnz	x1, cb24 <fwp_main_thread+0x550>
    c9b8:	f9400401 	ldr	x1, [x0, #8]
    c9bc:	b5000b41 	cbnz	x1, cb24 <fwp_main_thread+0x550>
    c9c0:	97ffe0b4 	bl	4c90 <fwp_mem_free>
    c9c4:	91000673 	add	x19, x19, #0x1
    c9c8:	eb1302ff 	cmp	x23, x19
    c9cc:	54fffee1 	b.ne	c9a8 <fwp_main_thread+0x3d4>  // b.any
    c9d0:	aa1403e0 	mov	x0, x20
    c9d4:	97ffe0af 	bl	4c90 <fwp_mem_free>
    c9d8:	910142a0 	add	x0, x21, #0x50
    c9dc:	f941f013 	ldr	x19, [x0, #992]
    c9e0:	f901f41f 	str	xzr, [x0, #1000]
    c9e4:	f901f81f 	str	xzr, [x0, #1008]
    c9e8:	b40001f3 	cbz	x19, ca24 <fwp_main_thread+0x450>
    c9ec:	f9401661 	ldr	x1, [x19, #40]
    c9f0:	b50009a1 	cbnz	x1, cb24 <fwp_main_thread+0x550>
    c9f4:	f9405661 	ldr	x1, [x19, #168]
    c9f8:	b5000961 	cbnz	x1, cb24 <fwp_main_thread+0x550>
    c9fc:	f941d401 	ldr	x1, [x0, #936]
    ca00:	b5000921 	cbnz	x1, cb24 <fwp_main_thread+0x550>
    ca04:	f941dc00 	ldr	x0, [x0, #952]
    ca08:	b50008e0 	cbnz	x0, cb24 <fwp_main_thread+0x550>
    ca0c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    ca10:	90000360 	adrp	x0, 78000 <ad_raw_blocks+0x17bb0>
    ca14:	91114000 	add	x0, x0, #0x450
    ca18:	97ffd796 	bl	2870 <memset@plt>
    ca1c:	aa1303e0 	mov	x0, x19
    ca20:	97ffe09c 	bl	4c90 <fwp_mem_free>
    ca24:	910142a6 	add	x6, x21, #0x50
    ca28:	9118c2d6 	add	x22, x22, #0x630
    ca2c:	3dc016a1 	ldr	q1, [x21, #80]
    ca30:	52800041 	mov	w1, #0x2                   	// #2
    ca34:	3dc004c2 	ldr	q2, [x6, #16]
    ca38:	b0000002 	adrp	x2, d000 <__modti3+0xf0>
    ca3c:	fd4a12c0 	ldr	d0, [x22, #5152]
    ca40:	912ba042 	add	x2, x2, #0xae8
    ca44:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    ca48:	fd40a4c1 	ldr	d1, [x6, #328]
    ca4c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    ca50:	f947e800 	ldr	x0, [x0, #4048]
    ca54:	7e61d800 	ucvtf	d0, d0
    ca58:	a95390c3 	ldp	x3, x4, [x6, #312]
    ca5c:	f9004cdf 	str	xzr, [x6, #152]
    ca60:	f9400000 	ldr	x0, [x0]
    ca64:	1e613801 	fsub	d1, d0, d1
    ca68:	f940acc5 	ldr	x5, [x6, #344]
    ca6c:	b90130df 	str	wzr, [x6, #304]
    ca70:	5ef1b842 	addp	d2, v2.2d
    ca74:	fd40a8c0 	ldr	d0, [x6, #336]
    ca78:	f901f0df 	str	xzr, [x6, #992]
    ca7c:	fd0058c2 	str	d2, [x6, #176]
    ca80:	97ffd7a4 	bl	2910 <__fprintf_chk@plt>
    ca84:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    ca88:	f947ec00 	ldr	x0, [x0, #4056]
    ca8c:	f9400000 	ldr	x0, [x0]
    ca90:	97ffd7d0 	bl	29d0 <fflush@plt>
    ca94:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    ca98:	f947f400 	ldr	x0, [x0, #4072]
    ca9c:	f9405fe2 	ldr	x2, [sp, #184]
    caa0:	f9400001 	ldr	x1, [x0]
    caa4:	eb010042 	subs	x2, x2, x1
    caa8:	d2800001 	mov	x1, #0x0                   	// #0
    caac:	540006a1 	b.ne	cb80 <fwp_main_thread+0x5ac>  // b.any
    cab0:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cab4:	d2800000 	mov	x0, #0x0                   	// #0
    cab8:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cabc:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cac0:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cac4:	a9506bf9 	ldp	x25, x26, [sp, #256]
    cac8:	910443ff 	add	sp, sp, #0x110
    cacc:	d65f03c0 	ret
    cad0:	39414280 	ldrb	w0, [x20, #80]
    cad4:	3707ed80 	tbnz	w0, #0, c884 <fwp_main_thread+0x2b0>
    cad8:	aa1403e0 	mov	x0, x20
    cadc:	97ffdb05 	bl	36f0 <fwp_cancel_tree.part.0>
    cae0:	39414680 	ldrb	w0, [x20, #81]
    cae4:	17ffff69 	b	c888 <fwp_main_thread+0x2b4>
    cae8:	d2800013 	mov	x19, #0x0                   	// #0
    caec:	910142b4 	add	x20, x21, #0x50
    caf0:	f941de80 	ldr	x0, [x20, #952]
    caf4:	b5ffe7c0 	cbnz	x0, c7ec <fwp_main_thread+0x218>
    caf8:	f941d280 	ldr	x0, [x20, #928]
    cafc:	97ffe065 	bl	4c90 <fwp_mem_free>
    cb00:	f901d29f 	str	xzr, [x20, #928]
    cb04:	f901da9f 	str	xzr, [x20, #944]
    cb08:	f941f280 	ldr	x0, [x20, #992]
    cb0c:	b4000293 	cbz	x19, cb5c <fwp_main_thread+0x588>
    cb10:	f900567f 	str	xzr, [x19, #168]
    cb14:	f9005e7f 	str	xzr, [x19, #184]
    cb18:	b903da9f 	str	wzr, [x20, #984]
    cb1c:	eb13001f 	cmp	x0, x19
    cb20:	54ffe720 	b.eq	c804 <fwp_main_thread+0x230>  // b.none
    cb24:	97ffd773 	bl	28f0 <abort@plt>
    cb28:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    cb2c:	913e8000 	add	x0, x0, #0xfa0
    cb30:	940001d4 	bl	d280 <atexit>
    cb34:	17fffebb 	b	c620 <fwp_main_thread+0x4c>
    cb38:	97ffdd73 	bl	4104 <fwp_heap_init>
    cb3c:	17fffeb6 	b	c614 <fwp_main_thread+0x40>
    cb40:	97fff50c 	bl	9f70 <f0>
    cb44:	b903ca74 	str	w20, [x19, #968]
    cb48:	f901ea60 	str	x0, [x19, #976]
    cb4c:	17fffeea 	b	c6f4 <fwp_main_thread+0x120>
    cb50:	aa0003e1 	mov	x1, x0
    cb54:	f9002293 	str	x19, [x20, #64]
    cb58:	17fffeff 	b	c754 <fwp_main_thread+0x180>
    cb5c:	b903da9f 	str	wzr, [x20, #984]
    cb60:	b4ffee00 	cbz	x0, c920 <fwp_main_thread+0x34c>
    cb64:	97ffd763 	bl	28f0 <abort@plt>
    cb68:	b0000000 	adrp	x0, d000 <__modti3+0xf0>
    cb6c:	912a8000 	add	x0, x0, #0xaa0
    cb70:	97ffdb24 	bl	3800 <fwp_trap>
    cb74:	b0000000 	adrp	x0, d000 <__modti3+0xf0>
    cb78:	912b2000 	add	x0, x0, #0xac8
    cb7c:	97ffda01 	bl	3380 <ad_raw_fail>
    cb80:	97ffd748 	bl	28a0 <__stack_chk_fail@plt>
    cb84:	d503201f 	nop
    cb88:	d503201f 	nop
    cb8c:	d503201f 	nop

000000000000cb90 <__divti3>:
    cb90:	d503245f 	bti	c
    cb94:	d2800004 	mov	x4, #0x0                   	// #0
    cb98:	b7f80721 	tbnz	x1, #63, cc7c <__divti3+0xec>
    cb9c:	b6f80083 	tbz	x3, #63, cbac <__divti3+0x1c>
    cba0:	eb0203e2 	negs	x2, x2
    cba4:	aa2403e4 	mvn	x4, x4
    cba8:	da0303e3 	ngc	x3, x3
    cbac:	aa0203e6 	mov	x6, x2
    cbb0:	aa0003e7 	mov	x7, x0
    cbb4:	aa0103e5 	mov	x5, x1
    cbb8:	b5000583 	cbnz	x3, cc68 <__divti3+0xd8>
    cbbc:	eb01005f 	cmp	x2, x1
    cbc0:	54000e69 	b.ls	cd8c <__divti3+0x1fc>  // b.plast
    cbc4:	dac01040 	clz	x0, x2
    cbc8:	b40000e0 	cbz	x0, cbe4 <__divti3+0x54>
    cbcc:	4b0003e1 	neg	w1, w0
    cbd0:	9ac020a5 	lsl	x5, x5, x0
    cbd4:	9ac02046 	lsl	x6, x2, x0
    cbd8:	9ac124e1 	lsr	x1, x7, x1
    cbdc:	aa050025 	orr	x5, x1, x5
    cbe0:	9ac020e7 	lsl	x7, x7, x0
    cbe4:	d360fcc8 	lsr	x8, x6, #32
    cbe8:	92407cc2 	and	x2, x6, #0xffffffff
    cbec:	9ac808a3 	udiv	x3, x5, x8
    cbf0:	9b089465 	msub	x5, x3, x8, x5
    cbf4:	aa0303e0 	mov	x0, x3
    cbf8:	9b037c41 	mul	x1, x2, x3
    cbfc:	93c780a5 	extr	x5, x5, x7, #32
    cc00:	eb05003f 	cmp	x1, x5
    cc04:	540000a9 	b.ls	cc18 <__divti3+0x88>  // b.plast
    cc08:	ab0500c5 	adds	x5, x6, x5
    cc0c:	d1000460 	sub	x0, x3, #0x1
    cc10:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    cc14:	540015a8 	b.hi	cec8 <__divti3+0x338>  // b.pmore
    cc18:	cb0100a5 	sub	x5, x5, x1
    cc1c:	9ac808a3 	udiv	x3, x5, x8
    cc20:	9b089465 	msub	x5, x3, x8, x5
    cc24:	aa0303e1 	mov	x1, x3
    cc28:	9b037c42 	mul	x2, x2, x3
    cc2c:	aa0703e3 	mov	x3, x7
    cc30:	b3607ca3 	bfi	x3, x5, #32, #32
    cc34:	eb03005f 	cmp	x2, x3
    cc38:	540000c9 	b.ls	cc50 <__divti3+0xc0>  // b.plast
    cc3c:	ab0300c3 	adds	x3, x6, x3
    cc40:	d1000425 	sub	x5, x1, #0x1
    cc44:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cc48:	d1000821 	sub	x1, x1, #0x2
    cc4c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    cc50:	aa008020 	orr	x0, x1, x0, lsl #32
    cc54:	d2800001 	mov	x1, #0x0                   	// #0
    cc58:	b4000064 	cbz	x4, cc64 <__divti3+0xd4>
    cc5c:	eb0003e0 	negs	x0, x0
    cc60:	da0103e1 	ngc	x1, x1
    cc64:	d65f03c0 	ret
    cc68:	eb01007f 	cmp	x3, x1
    cc6c:	54000109 	b.ls	cc8c <__divti3+0xfc>  // b.plast
    cc70:	d2800001 	mov	x1, #0x0                   	// #0
    cc74:	d2800000 	mov	x0, #0x0                   	// #0
    cc78:	17fffff8 	b	cc58 <__divti3+0xc8>
    cc7c:	eb0003e0 	negs	x0, x0
    cc80:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cc84:	da0103e1 	ngc	x1, x1
    cc88:	17ffffc5 	b	cb9c <__divti3+0xc>
    cc8c:	dac01067 	clz	x7, x3
    cc90:	b40010e7 	cbz	x7, ceac <__divti3+0x31c>
    cc94:	d2800805 	mov	x5, #0x40                  	// #64
    cc98:	cb0700a5 	sub	x5, x5, x7
    cc9c:	9ac72063 	lsl	x3, x3, x7
    cca0:	9ac52448 	lsr	x8, x2, x5
    cca4:	aa030108 	orr	x8, x8, x3
    cca8:	9ac52426 	lsr	x6, x1, x5
    ccac:	92407d0a 	and	x10, x8, #0xffffffff
    ccb0:	d360fd09 	lsr	x9, x8, #32
    ccb4:	9ac52403 	lsr	x3, x0, x5
    ccb8:	9ac72021 	lsl	x1, x1, x7
    ccbc:	aa010063 	orr	x3, x3, x1
    ccc0:	9ac72042 	lsl	x2, x2, x7
    ccc4:	9ac908cb 	udiv	x11, x6, x9
    ccc8:	9b099965 	msub	x5, x11, x9, x6
    cccc:	aa0b03e1 	mov	x1, x11
    ccd0:	9b0b7d46 	mul	x6, x10, x11
    ccd4:	93c380a5 	extr	x5, x5, x3, #32
    ccd8:	eb0500df 	cmp	x6, x5
    ccdc:	540000a9 	b.ls	ccf0 <__divti3+0x160>  // b.plast
    cce0:	ab050105 	adds	x5, x8, x5
    cce4:	d1000561 	sub	x1, x11, #0x1
    cce8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ccec:	54000f48 	b.hi	ced4 <__divti3+0x344>  // b.pmore
    ccf0:	cb0600a6 	sub	x6, x5, x6
    ccf4:	9ac908cb 	udiv	x11, x6, x9
    ccf8:	9b099969 	msub	x9, x11, x9, x6
    ccfc:	aa0b03e5 	mov	x5, x11
    cd00:	9b0b7d4a 	mul	x10, x10, x11
    cd04:	b3607d23 	bfi	x3, x9, #32, #32
    cd08:	eb03015f 	cmp	x10, x3
    cd0c:	540000a9 	b.ls	cd20 <__divti3+0x190>  // b.plast
    cd10:	ab030103 	adds	x3, x8, x3
    cd14:	d1000565 	sub	x5, x11, #0x1
    cd18:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cd1c:	54000e28 	b.hi	cee0 <__divti3+0x350>  // b.pmore
    cd20:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cd24:	92407c48 	and	x8, x2, #0xffffffff
    cd28:	2a0503e5 	mov	w5, w5
    cd2c:	d360fc42 	lsr	x2, x2, #32
    cd30:	d360fc26 	lsr	x6, x1, #32
    cd34:	cb0a0063 	sub	x3, x3, x10
    cd38:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cd3c:	9b087caa 	mul	x10, x5, x8
    cd40:	9b087cc8 	mul	x8, x6, x8
    cd44:	9b0220a5 	madd	x5, x5, x2, x8
    cd48:	9b027cc6 	mul	x6, x6, x2
    cd4c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cd50:	8b0900c5 	add	x5, x6, x9
    cd54:	eb02011f 	cmp	x8, x2
    cd58:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cd5c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cd60:	eb06007f 	cmp	x3, x6
    cd64:	540000e3 	b.cc	cd80 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cd68:	92407d4a 	and	x10, x10, #0xffffffff
    cd6c:	9ac72000 	lsl	x0, x0, x7
    cd70:	8b028142 	add	x2, x10, x2, lsl #32
    cd74:	eb02001f 	cmp	x0, x2
    cd78:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cd7c:	54000a01 	b.ne	cebc <__divti3+0x32c>  // b.any
    cd80:	d1000420 	sub	x0, x1, #0x1
    cd84:	d2800001 	mov	x1, #0x0                   	// #0
    cd88:	17ffffb4 	b	cc58 <__divti3+0xc8>
    cd8c:	b5000062 	cbnz	x2, cd98 <__divti3+0x208>
    cd90:	d2800022 	mov	x2, #0x1                   	// #1
    cd94:	9ac30846 	udiv	x6, x2, x3
    cd98:	dac010c8 	clz	x8, x6
    cd9c:	b5000408 	cbnz	x8, ce1c <__divti3+0x28c>
    cda0:	d360fcc9 	lsr	x9, x6, #32
    cda4:	92407cc5 	and	x5, x6, #0xffffffff
    cda8:	cb060023 	sub	x3, x1, x6
    cdac:	d2800021 	mov	x1, #0x1                   	// #1
    cdb0:	9ac90868 	udiv	x8, x3, x9
    cdb4:	9b098d03 	msub	x3, x8, x9, x3
    cdb8:	aa0803e0 	mov	x0, x8
    cdbc:	9b057d02 	mul	x2, x8, x5
    cdc0:	93c78063 	extr	x3, x3, x7, #32
    cdc4:	eb03005f 	cmp	x2, x3
    cdc8:	540000a9 	b.ls	cddc <__divti3+0x24c>  // b.plast
    cdcc:	ab0300c3 	adds	x3, x6, x3
    cdd0:	d1000500 	sub	x0, x8, #0x1
    cdd4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cdd8:	54000968 	b.hi	cf04 <__divti3+0x374>  // b.pmore
    cddc:	cb020063 	sub	x3, x3, x2
    cde0:	9ac90862 	udiv	x2, x3, x9
    cde4:	aa0203e8 	mov	x8, x2
    cde8:	9b098c42 	msub	x2, x2, x9, x3
    cdec:	aa0703e3 	mov	x3, x7
    cdf0:	9b057d05 	mul	x5, x8, x5
    cdf4:	b3607c43 	bfi	x3, x2, #32, #32
    cdf8:	eb0300bf 	cmp	x5, x3
    cdfc:	540000c9 	b.ls	ce14 <__divti3+0x284>  // b.plast
    ce00:	ab0300c2 	adds	x2, x6, x3
    ce04:	d1000503 	sub	x3, x8, #0x1
    ce08:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ce0c:	d1000908 	sub	x8, x8, #0x2
    ce10:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ce14:	aa008100 	orr	x0, x8, x0, lsl #32
    ce18:	17ffff90 	b	cc58 <__divti3+0xc8>
    ce1c:	9ac820c6 	lsl	x6, x6, x8
    ce20:	d2800803 	mov	x3, #0x40                  	// #64
    ce24:	cb080063 	sub	x3, x3, x8
    ce28:	d360fcc9 	lsr	x9, x6, #32
    ce2c:	9ac82027 	lsl	x7, x1, x8
    ce30:	92407cc5 	and	x5, x6, #0xffffffff
    ce34:	9ac32422 	lsr	x2, x1, x3
    ce38:	9ac32403 	lsr	x3, x0, x3
    ce3c:	aa070063 	orr	x3, x3, x7
    ce40:	9ac9084a 	udiv	x10, x2, x9
    ce44:	9ac82007 	lsl	x7, x0, x8
    ce48:	9b098940 	msub	x0, x10, x9, x2
    ce4c:	aa0a03e1 	mov	x1, x10
    ce50:	9b0a7ca2 	mul	x2, x5, x10
    ce54:	93c38000 	extr	x0, x0, x3, #32
    ce58:	eb00005f 	cmp	x2, x0
    ce5c:	540000a9 	b.ls	ce70 <__divti3+0x2e0>  // b.plast
    ce60:	ab0000c0 	adds	x0, x6, x0
    ce64:	d1000541 	sub	x1, x10, #0x1
    ce68:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    ce6c:	54000468 	b.hi	cef8 <__divti3+0x368>  // b.pmore
    ce70:	cb020000 	sub	x0, x0, x2
    ce74:	9ac9080a 	udiv	x10, x0, x9
    ce78:	9b098140 	msub	x0, x10, x9, x0
    ce7c:	aa0a03e2 	mov	x2, x10
    ce80:	9b0a7ca8 	mul	x8, x5, x10
    ce84:	b3607c03 	bfi	x3, x0, #32, #32
    ce88:	eb03011f 	cmp	x8, x3
    ce8c:	540000a9 	b.ls	cea0 <__divti3+0x310>  // b.plast
    ce90:	ab0300c3 	adds	x3, x6, x3
    ce94:	d1000542 	sub	x2, x10, #0x1
    ce98:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    ce9c:	54000288 	b.hi	ceec <__divti3+0x35c>  // b.pmore
    cea0:	cb080063 	sub	x3, x3, x8
    cea4:	aa018041 	orr	x1, x2, x1, lsl #32
    cea8:	17ffffc2 	b	cdb0 <__divti3+0x220>
    ceac:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    ceb0:	d2800001 	mov	x1, #0x0                   	// #0
    ceb4:	9a9f87e0 	cset	x0, ls	// ls = plast
    ceb8:	17ffff68 	b	cc58 <__divti3+0xc8>
    cebc:	aa0103e0 	mov	x0, x1
    cec0:	d2800001 	mov	x1, #0x0                   	// #0
    cec4:	17ffff65 	b	cc58 <__divti3+0xc8>
    cec8:	d1000860 	sub	x0, x3, #0x2
    cecc:	8b0600a5 	add	x5, x5, x6
    ced0:	17ffff52 	b	cc18 <__divti3+0x88>
    ced4:	d1000961 	sub	x1, x11, #0x2
    ced8:	8b0800a5 	add	x5, x5, x8
    cedc:	17ffff85 	b	ccf0 <__divti3+0x160>
    cee0:	d1000965 	sub	x5, x11, #0x2
    cee4:	8b080063 	add	x3, x3, x8
    cee8:	17ffff8e 	b	cd20 <__divti3+0x190>
    ceec:	d1000942 	sub	x2, x10, #0x2
    cef0:	8b060063 	add	x3, x3, x6
    cef4:	17ffffeb 	b	cea0 <__divti3+0x310>
    cef8:	d1000941 	sub	x1, x10, #0x2
    cefc:	8b060000 	add	x0, x0, x6
    cf00:	17ffffdc 	b	ce70 <__divti3+0x2e0>
    cf04:	d1000900 	sub	x0, x8, #0x2
    cf08:	8b060063 	add	x3, x3, x6
    cf0c:	17ffffb4 	b	cddc <__divti3+0x24c>

000000000000cf10 <__modti3>:
    cf10:	d503245f 	bti	c
    cf14:	d2800004 	mov	x4, #0x0                   	// #0
    cf18:	b6f80081 	tbz	x1, #63, cf28 <__modti3+0x18>
    cf1c:	eb0003e0 	negs	x0, x0
    cf20:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cf24:	da0103e1 	ngc	x1, x1
    cf28:	f100007f 	cmp	x3, #0x0
    cf2c:	5400128b 	b.lt	d17c <__modti3+0x26c>  // b.tstop
    cf30:	aa0003e7 	mov	x7, x0
    cf34:	aa0103e6 	mov	x6, x1
    cf38:	540004e1 	b.ne	cfd4 <__modti3+0xc4>  // b.any
    cf3c:	eb02003f 	cmp	x1, x2
    cf40:	54000dc2 	b.cs	d0f8 <__modti3+0x1e8>  // b.hs, b.nlast
    cf44:	dac01043 	clz	x3, x2
    cf48:	aa0303e5 	mov	x5, x3
    cf4c:	b40000e3 	cbz	x3, cf68 <__modti3+0x58>
    cf50:	4b0303e6 	neg	w6, w3
    cf54:	9ac32021 	lsl	x1, x1, x3
    cf58:	9ac32042 	lsl	x2, x2, x3
    cf5c:	9ac62406 	lsr	x6, x0, x6
    cf60:	aa0100c6 	orr	x6, x6, x1
    cf64:	9ac32007 	lsl	x7, x0, x3
    cf68:	d360fc40 	lsr	x0, x2, #32
    cf6c:	92407c43 	and	x3, x2, #0xffffffff
    cf70:	9ac008c1 	udiv	x1, x6, x0
    cf74:	9b009826 	msub	x6, x1, x0, x6
    cf78:	9b017c61 	mul	x1, x3, x1
    cf7c:	93c780c6 	extr	x6, x6, x7, #32
    cf80:	eb06003f 	cmp	x1, x6
    cf84:	540000a9 	b.ls	cf98 <__modti3+0x88>  // b.plast
    cf88:	ab060046 	adds	x6, x2, x6
    cf8c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    cf90:	8b0200c8 	add	x8, x6, x2
    cf94:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    cf98:	cb0100c6 	sub	x6, x6, x1
    cf9c:	9ac008c8 	udiv	x8, x6, x0
    cfa0:	9b009901 	msub	x1, x8, x0, x6
    cfa4:	aa0703e0 	mov	x0, x7
    cfa8:	9b087c63 	mul	x3, x3, x8
    cfac:	b3607c20 	bfi	x0, x1, #32, #32
    cfb0:	eb00007f 	cmp	x3, x0
    cfb4:	54001088 	b.hi	d1c4 <__modti3+0x2b4>  // b.pmore
    cfb8:	cb030000 	sub	x0, x0, x3
    cfbc:	9ac52400 	lsr	x0, x0, x5
    cfc0:	d2800001 	mov	x1, #0x0                   	// #0
    cfc4:	b4000064 	cbz	x4, cfd0 <__modti3+0xc0>
    cfc8:	eb0003e0 	negs	x0, x0
    cfcc:	da0103e1 	ngc	x1, x1
    cfd0:	d65f03c0 	ret
    cfd4:	dac01066 	clz	x6, x3
    cfd8:	eb03003f 	cmp	x1, x3
    cfdc:	54ffff43 	b.cc	cfc4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cfe0:	93407cc5 	sxtw	x5, w6
    cfe4:	d2800808 	mov	x8, #0x40                  	// #64
    cfe8:	cb050108 	sub	x8, x8, x5
    cfec:	9ac62063 	lsl	x3, x3, x6
    cff0:	9ac62025 	lsl	x5, x1, x6
    cff4:	9ac82447 	lsr	x7, x2, x8
    cff8:	aa0300e7 	orr	x7, x7, x3
    cffc:	9ac82423 	lsr	x3, x1, x8
    d000:	92407cec 	and	x12, x7, #0xffffffff
    d004:	d360fcea 	lsr	x10, x7, #32
    d008:	9ac82401 	lsr	x1, x0, x8
    d00c:	aa050021 	orr	x1, x1, x5
    d010:	9ac62042 	lsl	x2, x2, x6
    d014:	9ac62000 	lsl	x0, x0, x6
    d018:	9aca086b 	udiv	x11, x3, x10
    d01c:	9b0a8d63 	msub	x3, x11, x10, x3
    d020:	aa0b03e5 	mov	x5, x11
    d024:	9b0b7d89 	mul	x9, x12, x11
    d028:	93c18063 	extr	x3, x3, x1, #32
    d02c:	eb03013f 	cmp	x9, x3
    d030:	540000a9 	b.ls	d044 <__modti3+0x134>  // b.plast
    d034:	ab0300e3 	adds	x3, x7, x3
    d038:	d1000565 	sub	x5, x11, #0x1
    d03c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d040:	54001168 	b.hi	d26c <__modti3+0x35c>  // b.pmore
    d044:	cb090063 	sub	x3, x3, x9
    d048:	9aca086b 	udiv	x11, x3, x10
    d04c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d050:	aa0b03e9 	mov	x9, x11
    d054:	9b0b7d8c 	mul	x12, x12, x11
    d058:	b3607d41 	bfi	x1, x10, #32, #32
    d05c:	eb01019f 	cmp	x12, x1
    d060:	540000a9 	b.ls	d074 <__modti3+0x164>  // b.plast
    d064:	ab0100e1 	adds	x1, x7, x1
    d068:	d1000569 	sub	x9, x11, #0x1
    d06c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d070:	54000f88 	b.hi	d260 <__modti3+0x350>  // b.pmore
    d074:	aa058123 	orr	x3, x9, x5, lsl #32
    d078:	92407c4b 	and	x11, x2, #0xffffffff
    d07c:	2a0903e9 	mov	w9, w9
    d080:	d360fc4a 	lsr	x10, x2, #32
    d084:	d360fc63 	lsr	x3, x3, #32
    d088:	cb0c0021 	sub	x1, x1, x12
    d08c:	aa0a03ec 	mov	x12, x10
    d090:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d094:	9b0b7d25 	mul	x5, x9, x11
    d098:	9b0b7c6b 	mul	x11, x3, x11
    d09c:	9b0a2d29 	madd	x9, x9, x10, x11
    d0a0:	92407caa 	and	x10, x5, #0xffffffff
    d0a4:	9b0c7c63 	mul	x3, x3, x12
    d0a8:	8b458125 	add	x5, x9, x5, lsr #32
    d0ac:	8b0d0069 	add	x9, x3, x13
    d0b0:	eb05017f 	cmp	x11, x5
    d0b4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d0b8:	8b058149 	add	x9, x10, x5, lsl #32
    d0bc:	8b458063 	add	x3, x3, x5, lsr #32
    d0c0:	eb03003f 	cmp	x1, x3
    d0c4:	54000063 	b.cc	d0d0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d0c8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d0cc:	54000082 	b.cs	d0dc <__modti3+0x1cc>  // b.hs, b.nlast
    d0d0:	eb020129 	subs	x9, x9, x2
    d0d4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d0d8:	cb070063 	sub	x3, x3, x7
    d0dc:	eb090000 	subs	x0, x0, x9
    d0e0:	da030021 	sbc	x1, x1, x3
    d0e4:	9ac62400 	lsr	x0, x0, x6
    d0e8:	9ac82028 	lsl	x8, x1, x8
    d0ec:	aa000100 	orr	x0, x8, x0
    d0f0:	9ac62421 	lsr	x1, x1, x6
    d0f4:	17ffffb4 	b	cfc4 <__modti3+0xb4>
    d0f8:	b5000062 	cbnz	x2, d104 <__modti3+0x1f4>
    d0fc:	d2800023 	mov	x3, #0x1                   	// #1
    d100:	9ac20862 	udiv	x2, x3, x2
    d104:	dac01048 	clz	x8, x2
    d108:	aa0803e5 	mov	x5, x8
    d10c:	b5000668 	cbnz	x8, d1d8 <__modti3+0x2c8>
    d110:	cb020020 	sub	x0, x1, x2
    d114:	d360fc49 	lsr	x9, x2, #32
    d118:	92407c4a 	and	x10, x2, #0xffffffff
    d11c:	9ac90801 	udiv	x1, x0, x9
    d120:	9b098020 	msub	x0, x1, x9, x0
    d124:	9b0a7c21 	mul	x1, x1, x10
    d128:	93c78000 	extr	x0, x0, x7, #32
    d12c:	eb00003f 	cmp	x1, x0
    d130:	540000a9 	b.ls	d144 <__modti3+0x234>  // b.plast
    d134:	ab000040 	adds	x0, x2, x0
    d138:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d13c:	8b020003 	add	x3, x0, x2
    d140:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d144:	cb010001 	sub	x1, x0, x1
    d148:	9ac90820 	udiv	x0, x1, x9
    d14c:	9b098403 	msub	x3, x0, x9, x1
    d150:	aa0703e1 	mov	x1, x7
    d154:	9b0a7c00 	mul	x0, x0, x10
    d158:	b3607c61 	bfi	x1, x3, #32, #32
    d15c:	eb01001f 	cmp	x0, x1
    d160:	540000a9 	b.ls	d174 <__modti3+0x264>  // b.plast
    d164:	ab010041 	adds	x1, x2, x1
    d168:	8b020022 	add	x2, x1, x2
    d16c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d170:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d174:	cb000020 	sub	x0, x1, x0
    d178:	17ffff91 	b	cfbc <__modti3+0xac>
    d17c:	eb0203e5 	negs	x5, x2
    d180:	aa0003e7 	mov	x7, x0
    d184:	da0303e8 	ngc	x8, x3
    d188:	aa0503e2 	mov	x2, x5
    d18c:	aa0803e3 	mov	x3, x8
    d190:	aa0103e6 	mov	x6, x1
    d194:	b4ffed48 	cbz	x8, cf3c <__modti3+0x2c>
    d198:	eb01011f 	cmp	x8, x1
    d19c:	54fff148 	b.hi	cfc4 <__modti3+0xb4>  // b.pmore
    d1a0:	dac01109 	clz	x9, x8
    d1a4:	2a0903e6 	mov	w6, w9
    d1a8:	b5fff1c9 	cbnz	x9, cfe0 <__modti3+0xd0>
    d1ac:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d1b0:	54000068 	b.hi	d1bc <__modti3+0x2ac>  // b.pmore
    d1b4:	eb050007 	subs	x7, x0, x5
    d1b8:	da080021 	sbc	x1, x1, x8
    d1bc:	aa0703e0 	mov	x0, x7
    d1c0:	17ffff81 	b	cfc4 <__modti3+0xb4>
    d1c4:	ab000040 	adds	x0, x2, x0
    d1c8:	8b020002 	add	x2, x0, x2
    d1cc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d1d0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d1d4:	17ffff79 	b	cfb8 <__modti3+0xa8>
    d1d8:	9ac82042 	lsl	x2, x2, x8
    d1dc:	d2800803 	mov	x3, #0x40                  	// #64
    d1e0:	cb080063 	sub	x3, x3, x8
    d1e4:	d360fc49 	lsr	x9, x2, #32
    d1e8:	9ac82027 	lsl	x7, x1, x8
    d1ec:	92407c4a 	and	x10, x2, #0xffffffff
    d1f0:	9ac32426 	lsr	x6, x1, x3
    d1f4:	9ac32403 	lsr	x3, x0, x3
    d1f8:	aa070063 	orr	x3, x3, x7
    d1fc:	9ac908c1 	udiv	x1, x6, x9
    d200:	9ac82007 	lsl	x7, x0, x8
    d204:	9b099820 	msub	x0, x1, x9, x6
    d208:	9b017d41 	mul	x1, x10, x1
    d20c:	93c38000 	extr	x0, x0, x3, #32
    d210:	eb00003f 	cmp	x1, x0
    d214:	540000a9 	b.ls	d228 <__modti3+0x318>  // b.plast
    d218:	ab000040 	adds	x0, x2, x0
    d21c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d220:	8b020006 	add	x6, x0, x2
    d224:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d228:	cb010000 	sub	x0, x0, x1
    d22c:	9ac90801 	udiv	x1, x0, x9
    d230:	9b098026 	msub	x6, x1, x9, x0
    d234:	aa0303e0 	mov	x0, x3
    d238:	9b017d41 	mul	x1, x10, x1
    d23c:	b3607cc0 	bfi	x0, x6, #32, #32
    d240:	eb00003f 	cmp	x1, x0
    d244:	540000a9 	b.ls	d258 <__modti3+0x348>  // b.plast
    d248:	ab000040 	adds	x0, x2, x0
    d24c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d250:	8b020003 	add	x3, x0, x2
    d254:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d258:	cb010000 	sub	x0, x0, x1
    d25c:	17ffffb0 	b	d11c <__modti3+0x20c>
    d260:	d1000969 	sub	x9, x11, #0x2
    d264:	8b070021 	add	x1, x1, x7
    d268:	17ffff83 	b	d074 <__modti3+0x164>
    d26c:	d1000965 	sub	x5, x11, #0x2
    d270:	8b070063 	add	x3, x3, x7
    d274:	17ffff74 	b	d044 <__modti3+0x134>
    d278:	d503201f 	nop
    d27c:	d503201f 	nop

000000000000d280 <atexit>:
    d280:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d284:	f0000082 	adrp	x2, 20000 <__data_start>
    d288:	d2800001 	mov	x1, #0x0                   	// #0
    d28c:	910003fd 	mov	x29, sp
    d290:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d294:	f9400442 	ldr	x2, [x2, #8]
    d298:	17ffd542 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d29c <_fini>:
    d29c:	d503201f 	nop
    d2a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d2a4:	910003fd 	mov	x29, sp
    d2a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d2ac:	d65f03c0 	ret
