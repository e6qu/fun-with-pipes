
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000045 	adrp	x5, d000 <_IO_stdin_used+0x20>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	910a60a5 	add	x5, x5, #0x298
    2b20:	f0000044 	adrp	x4, d000 <_IO_stdin_used+0x20>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	910a8084 	add	x4, x4, #0x2a0
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	9101c261 	add	x1, x19, #0x70
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xedf8>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    2bb4:	9119e000 	add	x0, x0, #0x678
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000042 	adrp	x2, c000 <f0+0x232c>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	910d0042 	add	x2, x2, #0x340
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c273 	add	x19, x19, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9437a60 	ldr	w0, [x19, #888]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    2cfc:	911a2000 	add	x0, x0, #0x688
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    2d0c:	911ca000 	add	x0, x0, #0x728
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    2d24:	911c0000 	add	x0, x0, #0x700
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    2d30:	911b4000 	add	x0, x0, #0x6d0
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    2d3c:	911aa000 	add	x0, x0, #0x6a8
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	f0000041 	adrp	x1, d000 <_IO_stdin_used+0x20>
    2f34:	9136c021 	add	x1, x1, #0xdb0
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	b0000040 	adrp	x0, c000 <f0+0x232c>
    30d0:	913fa000 	add	x0, x0, #0xfe8
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x20>
    3198:	91364021 	add	x1, x1, #0xd90
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    31d0:	91000000 	add	x0, x0, #0x0
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	d0000042 	adrp	x2, d000 <_IO_stdin_used+0x20>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	d0000056 	adrp	x22, d000 <_IO_stdin_used+0x20>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	d0000058 	adrp	x24, d000 <_IO_stdin_used+0x20>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	91012042 	add	x2, x2, #0x48
    3260:	910282d6 	add	x22, x22, #0xa0
    3264:	912cc318 	add	x24, x24, #0xb30
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	d0000059 	adrp	x25, d000 <_IO_stdin_used+0x20>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	91026323 	add	x3, x25, #0x98
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	9102c000 	add	x0, x0, #0xb0
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    3344:	9117c2a1 	add	x1, x21, #0x5f0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa10>
    3358:	912780a5 	add	x5, x5, #0x9e0
    335c:	9117c2a1 	add	x1, x21, #0x5f0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	9117c2b7 	add	x23, x21, #0x5f0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	9117c2b5 	add	x21, x21, #0x5f0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	9117c2b5 	add	x21, x21, #0x5f0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa10>
    34e8:	912760a5 	add	x5, x5, #0x9d8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	b0000040 	adrp	x0, c000 <f0+0x232c>
    35f0:	913fa000 	add	x0, x0, #0xfe8
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x20>
    3830:	aa1303e0 	mov	x0, x19
    3834:	9102e021 	add	x1, x1, #0xb8
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x20>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91030021 	add	x1, x1, #0xc0
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x20>
    3860:	91032021 	add	x1, x1, #0xc8
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	d0000042 	adrp	x2, d000 <_IO_stdin_used+0x20>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	91034042 	add	x2, x2, #0xd0
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	b0000040 	adrp	x0, c000 <f0+0x232c>
    39d0:	913fa000 	add	x0, x0, #0xfe8
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    39f0:	91038000 	add	x0, x0, #0xe0
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    3a88:	91040000 	add	x0, x0, #0x100
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    3a98:	91048000 	add	x0, x0, #0x120
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x20>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc37020 	ldr	q0, [x1, #3520]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	9101c2b5 	add	x21, x21, #0x70
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    3b98:	91052000 	add	x0, x0, #0x148
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	9101c062 	add	x2, x3, #0x70
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403863 	ldr	x3, [x3, #112]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    3c08:	9105e000 	add	x0, x0, #0x178
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	d0000044 	adrp	x4, d000 <_IO_stdin_used+0x20>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	91072084 	add	x4, x4, #0x1c8
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	d0000044 	adrp	x4, d000 <_IO_stdin_used+0x20>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	91078084 	add	x4, x4, #0x1e0
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	d0000044 	adrp	x4, d000 <_IO_stdin_used+0x20>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	91074084 	add	x4, x4, #0x1d0
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    4028:	9117c042 	add	x2, x2, #0x5f0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	b0000041 	adrp	x1, d000 <_IO_stdin_used+0x20>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	9107a021 	add	x1, x1, #0x1e8
    4084:	9107c000 	add	x0, x0, #0x1f0
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	b0000042 	adrp	x2, d000 <_IO_stdin_used+0x20>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	91084042 	add	x2, x2, #0x210
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa10>
    418c:	9113c061 	add	x1, x3, #0x4f0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    419c:	9117c262 	add	x2, x19, #0x5f0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	b0000042 	adrp	x2, d000 <_IO_stdin_used+0x20>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa10>
    41cc:	9114c021 	add	x1, x1, #0x530
    41d0:	3dc37443 	ldr	q3, [x2, #3536]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa10>
    41fc:	9113c063 	add	x3, x3, #0x4f0
    4200:	91164084 	add	x4, x4, #0x590
    4204:	9117c266 	add	x6, x19, #0x5f0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	9117c275 	add	x21, x19, #0x5f0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    42e8:	910b0000 	add	x0, x0, #0x2c0
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	9117c273 	add	x19, x19, #0x5f0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <caf75>:
    4344:	900000e2 	adrp	x2, 20000 <__data_start>
    4348:	9101c041 	add	x1, x2, #0x70
    434c:	b9409820 	ldr	w0, [x1, #152]
    4350:	34000060 	cbz	w0, 435c <caf75+0x18>
    4354:	f9405020 	ldr	x0, [x1, #160]
    4358:	d65f03c0 	ret
    435c:	b940a820 	ldr	w0, [x1, #168]
    4360:	340000e0 	cbz	w0, 437c <caf75+0x38>
    4364:	f9405820 	ldr	x0, [x1, #176]
    4368:	9101c042 	add	x2, x2, #0x70
    436c:	52800021 	mov	w1, #0x1                   	// #1
    4370:	b9009841 	str	w1, [x2, #152]
    4374:	f9005040 	str	x0, [x2, #160]
    4378:	d65f03c0 	ret
    437c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4380:	52800024 	mov	w4, #0x1                   	// #1
    4384:	aa0303e0 	mov	x0, x3
    4388:	b900a824 	str	w4, [x1, #168]
    438c:	f9005823 	str	x3, [x1, #176]
    4390:	17fffff6 	b	4368 <caf75+0x24>

0000000000004394 <fwp_wake_io>:
    4394:	900000e9 	adrp	x9, 20000 <__data_start>
    4398:	9101c122 	add	x2, x9, #0x70
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	5280000a 	mov	w10, #0x0                   	// #0
    43a4:	f9403c46 	ldr	x6, [x2, #120]
    43a8:	52800008 	mov	w8, #0x0                   	// #0
    43ac:	4f000400 	movi	v0.4s, #0x0
    43b0:	52800027 	mov	w7, #0x1                   	// #1
    43b4:	aa0103e2 	mov	x2, x1
    43b8:	b4000321 	cbz	x1, 441c <fwp_wake_io+0x88>
    43bc:	f9408c25 	ldr	x5, [x1, #280]
    43c0:	39015c27 	strb	w7, [x1, #87]
    43c4:	b4000165 	cbz	x5, 43f0 <fwp_wake_io+0x5c>
    43c8:	a9520c24 	ldp	x4, x3, [x1, #288]
    43cc:	b4000364 	cbz	x4, 4438 <fwp_wake_io+0xa4>
    43d0:	f9009483 	str	x3, [x4, #296]
    43d4:	f9409423 	ldr	x3, [x1, #296]
    43d8:	b4000043 	cbz	x3, 43e0 <fwp_wake_io+0x4c>
    43dc:	f9009064 	str	x4, [x3, #288]
    43e0:	91080023 	add	x3, x1, #0x200
    43e4:	f900943f 	str	xzr, [x1, #296]
    43e8:	3c918060 	stur	q0, [x3, #-232]
    43ec:	f9400001 	ldr	x1, [x0]
    43f0:	f9402843 	ldr	x3, [x2, #80]
    43f4:	f2001c7f 	tst	x3, #0xff000000ff
    43f8:	54fffde1 	b.ne	43b4 <fwp_wake_io+0x20>  // b.any
    43fc:	39015047 	strb	w7, [x2, #84]
    4400:	f900805f 	str	xzr, [x2, #256]
    4404:	b40001e6 	cbz	x6, 4440 <fwp_wake_io+0xac>
    4408:	f90080c2 	str	x2, [x6, #256]
    440c:	aa0203e6 	mov	x6, x2
    4410:	52800028 	mov	w8, #0x1                   	// #1
    4414:	aa0103e2 	mov	x2, x1
    4418:	b5fffd21 	cbnz	x1, 43bc <fwp_wake_io+0x28>
    441c:	3400006a 	cbz	w10, 4428 <fwp_wake_io+0x94>
    4420:	9101c120 	add	x0, x9, #0x70
    4424:	f900400b 	str	x11, [x0, #128]
    4428:	34000068 	cbz	w8, 4434 <fwp_wake_io+0xa0>
    442c:	9101c129 	add	x9, x9, #0x70
    4430:	f9003d26 	str	x6, [x9, #120]
    4434:	d65f03c0 	ret
    4438:	f90000a3 	str	x3, [x5]
    443c:	17ffffe7 	b	43d8 <fwp_wake_io+0x44>
    4440:	aa0203eb 	mov	x11, x2
    4444:	5280002a 	mov	w10, #0x1                   	// #1
    4448:	17fffff1 	b	440c <fwp_wake_io+0x78>
    444c:	d503201f 	nop

0000000000004450 <fwp_tape_buffers_release>:
    4450:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4454:	910003fd 	mov	x29, sp
    4458:	a90153f3 	stp	x19, x20, [sp, #16]
    445c:	aa0003f3 	mov	x19, x0
    4460:	f9401400 	ldr	x0, [x0, #40]
    4464:	b7f80760 	tbnz	x0, #63, 4550 <fwp_tape_buffers_release+0x100>
    4468:	f9401a61 	ldr	x1, [x19, #48]
    446c:	b7f80301 	tbnz	x1, #63, 44cc <fwp_tape_buffers_release+0x7c>
    4470:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4474:	eb02001f 	cmp	x0, x2
    4478:	540002a8 	b.hi	44cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    447c:	8b000400 	add	x0, x0, x0, lsl #1
    4480:	d2a00102 	mov	x2, #0x80000               	// #524288
    4484:	d37df000 	lsl	x0, x0, #3
    4488:	cb000042 	sub	x2, x2, x0
    448c:	eb420c3f 	cmp	x1, x2, lsr #3
    4490:	540001e8 	b.hi	44cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    4494:	8b010c14 	add	x20, x0, x1, lsl #3
    4498:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    449c:	910b4000 	add	x0, x0, #0x2d0
    44a0:	97fff980 	bl	2aa0 <getenv@plt>
    44a4:	b4000240 	cbz	x0, 44ec <fwp_tape_buffers_release+0x9c>
    44a8:	39400001 	ldrb	w1, [x0]
    44ac:	7100c03f 	cmp	w1, #0x30
    44b0:	540001e1 	b.ne	44ec <fwp_tape_buffers_release+0x9c>  // b.any
    44b4:	39400400 	ldrb	w0, [x0, #1]
    44b8:	350001a0 	cbnz	w0, 44ec <fwp_tape_buffers_release+0x9c>
    44bc:	aa1303e0 	mov	x0, x19
    44c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44c8:	17fffc0e 	b	3500 <fwp_tape_buffers_dispose>
    44cc:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    44d0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    44d4:	910b4000 	add	x0, x0, #0x2d0
    44d8:	97fff972 	bl	2aa0 <getenv@plt>
    44dc:	b4ffff00 	cbz	x0, 44bc <fwp_tape_buffers_release+0x6c>
    44e0:	39400001 	ldrb	w1, [x0]
    44e4:	7100c03f 	cmp	w1, #0x30
    44e8:	54fffe60 	b.eq	44b4 <fwp_tape_buffers_release+0x64>  // b.none
    44ec:	d1000681 	sub	x1, x20, #0x1
    44f0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44f4:	eb00003f 	cmp	x1, x0
    44f8:	54fffe28 	b.hi	44bc <fwp_tape_buffers_release+0x6c>  // b.pmore
    44fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4500:	900000f6 	adrp	x22, 20000 <__data_start>
    4504:	9101c2d6 	add	x22, x22, #0x70
    4508:	9102e2d5 	add	x21, x22, #0xb8
    450c:	aa1503e0 	mov	x0, x21
    4510:	97fffbfc 	bl	3500 <fwp_tape_buffers_dispose>
    4514:	ad400a61 	ldp	q1, q2, [x19]
    4518:	f9007ad4 	str	x20, [x22, #240]
    451c:	4f000400 	movi	v0.4s, #0x0
    4520:	ad000aa1 	stp	q1, q2, [x21]
    4524:	3dc00a61 	ldr	q1, [x19, #32]
    4528:	3d800aa1 	str	q1, [x21, #32]
    452c:	f9401a60 	ldr	x0, [x19, #48]
    4530:	f9001aa0 	str	x0, [x21, #48]
    4534:	f9001a7f 	str	xzr, [x19, #48]
    4538:	ad000260 	stp	q0, q0, [x19]
    453c:	3d800a60 	str	q0, [x19, #32]
    4540:	a94153f3 	ldp	x19, x20, [sp, #16]
    4544:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4548:	a8c37bfd 	ldp	x29, x30, [sp], #48
    454c:	d65f03c0 	ret
    4550:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    4554:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4558:	910b4000 	add	x0, x0, #0x2d0
    455c:	97fff951 	bl	2aa0 <getenv@plt>
    4560:	b5fffa40 	cbnz	x0, 44a8 <fwp_tape_buffers_release+0x58>
    4564:	17ffffd6 	b	44bc <fwp_tape_buffers_release+0x6c>
    4568:	d503201f 	nop
    456c:	d503201f 	nop

0000000000004570 <fwp_poll_events>:
    4570:	d10103ff 	sub	sp, sp, #0x40
    4574:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4578:	f947f400 	ldr	x0, [x0, #4072]
    457c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4580:	910083fd 	add	x29, sp, #0x20
    4584:	a90353f3 	stp	x19, x20, [sp, #48]
    4588:	900000f4 	adrp	x20, 20000 <__data_start>
    458c:	f9400001 	ldr	x1, [x0]
    4590:	f9000fe1 	str	x1, [sp, #24]
    4594:	d2800001 	mov	x1, #0x0                   	// #0
    4598:	97fffd1a 	bl	3a00 <fwp_now_ns>
    459c:	9101c281 	add	x1, x20, #0x70
    45a0:	f9407c33 	ldr	x19, [x1, #248]
    45a4:	b4000e93 	cbz	x19, 4774 <fwp_poll_events+0x204>
    45a8:	aa1303e1 	mov	x1, x19
    45ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    45b0:	14000005 	b	45c4 <fwp_poll_events+0x54>
    45b4:	f9408821 	ldr	x1, [x1, #272]
    45b8:	eb03005f 	cmp	x2, x3
    45bc:	9a83d042 	csel	x2, x2, x3, le
    45c0:	b40000c1 	cbz	x1, 45d8 <fwp_poll_events+0x68>
    45c4:	f9403423 	ldr	x3, [x1, #104]
    45c8:	b6ffff62 	tbz	x2, #63, 45b4 <fwp_poll_events+0x44>
    45cc:	f9408821 	ldr	x1, [x1, #272]
    45d0:	aa0303e2 	mov	x2, x3
    45d4:	b5ffff81 	cbnz	x1, 45c4 <fwp_poll_events+0x54>
    45d8:	b7f80ce2 	tbnz	x2, #63, 4774 <fwp_poll_events+0x204>
    45dc:	cb000042 	sub	x2, x2, x0
    45e0:	f100005f 	cmp	x2, #0x0
    45e4:	540005cd 	b.le	469c <fwp_poll_events+0x12c>
    45e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    45ec:	d2884801 	mov	x1, #0x4240                	// #16960
    45f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4600:	f2e86360 	movk	x0, #0x431b, lsl #48
    4604:	9b407c40 	smulh	x0, x2, x0
    4608:	9352fc00 	asr	x0, x0, #18
    460c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4610:	9b018802 	msub	x2, x0, x1, x2
    4614:	f100005f 	cmp	x2, #0x0
    4618:	9a800400 	cinc	x0, x0, ne	// ne = any
    461c:	eb03001f 	cmp	x0, x3
    4620:	54000a0c 	b.gt	4760 <fwp_poll_events+0x1f0>
    4624:	340003c0 	cbz	w0, 469c <fwp_poll_events+0x12c>
    4628:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    462c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4630:	72a20c42 	movk	w2, #0x1062, lsl #16
    4634:	9ba27c02 	umull	x2, w0, w2
    4638:	d366fc43 	lsr	x3, x2, #38
    463c:	aa0303e2 	mov	x2, x3
    4640:	1b048063 	msub	w3, w3, w4, w0
    4644:	9b217c63 	smull	x3, w3, w1
    4648:	d2800001 	mov	x1, #0x0                   	// #0
    464c:	910023e0 	add	x0, sp, #0x8
    4650:	a9008fe2 	stp	x2, x3, [sp, #8]
    4654:	97fff8e3 	bl	29e0 <nanosleep@plt>
    4658:	9101c280 	add	x0, x20, #0x70
    465c:	f9407c13 	ldr	x19, [x0, #248]
    4660:	97fffce8 	bl	3a00 <fwp_now_ns>
    4664:	aa0003e6 	mov	x6, x0
    4668:	b50001f3 	cbnz	x19, 46a4 <fwp_poll_events+0x134>
    466c:	d503201f 	nop
    4670:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4674:	f947f400 	ldr	x0, [x0, #4072]
    4678:	f9400fe2 	ldr	x2, [sp, #24]
    467c:	f9400001 	ldr	x1, [x0]
    4680:	eb010042 	subs	x2, x2, x1
    4684:	d2800001 	mov	x1, #0x0                   	// #0
    4688:	540008c1 	b.ne	47a0 <fwp_poll_events+0x230>  // b.any
    468c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4690:	a94353f3 	ldp	x19, x20, [sp, #48]
    4694:	910103ff 	add	sp, sp, #0x40
    4698:	d65f03c0 	ret
    469c:	97fffcd9 	bl	3a00 <fwp_now_ns>
    46a0:	aa0003e6 	mov	x6, x0
    46a4:	4f000400 	movi	v0.4s, #0x0
    46a8:	9101c288 	add	x8, x20, #0x70
    46ac:	52800027 	mov	w7, #0x1                   	// #1
    46b0:	f9403661 	ldr	x1, [x19, #104]
    46b4:	aa1303e5 	mov	x5, x19
    46b8:	f9408a73 	ldr	x19, [x19, #272]
    46bc:	eb06003f 	cmp	x1, x6
    46c0:	5400032c 	b.gt	4724 <fwp_poll_events+0x1b4>
    46c4:	394154a0 	ldrb	w0, [x5, #85]
    46c8:	36000120 	tbz	w0, #0, 46ec <fwp_poll_events+0x17c>
    46cc:	f94084a0 	ldr	x0, [x5, #264]
    46d0:	b40003c0 	cbz	x0, 4748 <fwp_poll_events+0x1d8>
    46d4:	f9008813 	str	x19, [x0, #272]
    46d8:	b4000053 	cbz	x19, 46e0 <fwp_poll_events+0x170>
    46dc:	f9008660 	str	x0, [x19, #264]
    46e0:	910800a0 	add	x0, x5, #0x200
    46e4:	390154bf 	strb	wzr, [x5, #85]
    46e8:	3c908000 	stur	q0, [x0, #-248]
    46ec:	f94030a0 	ldr	x0, [x5, #96]
    46f0:	390158a7 	strb	w7, [x5, #86]
    46f4:	f100001f 	cmp	x0, #0x0
    46f8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46fc:	5400018d 	b.le	472c <fwp_poll_events+0x1bc>
    4700:	f94028a0 	ldr	x0, [x5, #80]
    4704:	f2001c1f 	tst	x0, #0xff000000ff
    4708:	540000e1 	b.ne	4724 <fwp_poll_events+0x1b4>  // b.any
    470c:	f9403d00 	ldr	x0, [x8, #120]
    4710:	390150a7 	strb	w7, [x5, #84]
    4714:	f90080bf 	str	xzr, [x5, #256]
    4718:	b40001e0 	cbz	x0, 4754 <fwp_poll_events+0x1e4>
    471c:	f9003d05 	str	x5, [x8, #120]
    4720:	f9008005 	str	x5, [x0, #256]
    4724:	b5fffc73 	cbnz	x19, 46b0 <fwp_poll_events+0x140>
    4728:	17ffffd2 	b	4670 <fwp_poll_events+0x100>
    472c:	394144a0 	ldrb	w0, [x5, #81]
    4730:	3707fe80 	tbnz	w0, #0, 4700 <fwp_poll_events+0x190>
    4734:	394140a0 	ldrb	w0, [x5, #80]
    4738:	3707fe40 	tbnz	w0, #0, 4700 <fwp_poll_events+0x190>
    473c:	aa0503e0 	mov	x0, x5
    4740:	97fffc0c 	bl	3770 <fwp_cancel_tree.part.0>
    4744:	17ffffef 	b	4700 <fwp_poll_events+0x190>
    4748:	9101c281 	add	x1, x20, #0x70
    474c:	f9007c33 	str	x19, [x1, #248]
    4750:	17ffffe2 	b	46d8 <fwp_poll_events+0x168>
    4754:	f9003d05 	str	x5, [x8, #120]
    4758:	f9004105 	str	x5, [x8, #128]
    475c:	17fffff2 	b	4724 <fwp_poll_events+0x1b4>
    4760:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4764:	d2989362 	mov	x2, #0xc49b                	// #50331
    4768:	f2a4d203 	movk	x3, #0x2690, lsl #16
    476c:	f2a00402 	movk	x2, #0x20, lsl #16
    4770:	17ffffb6 	b	4648 <fwp_poll_events+0xd8>
    4774:	97fffa3f 	bl	3070 <fwp_flush>
    4778:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    477c:	f947e863 	ldr	x3, [x3, #4048]
    4780:	d2800562 	mov	x2, #0x2b                  	// #43
    4784:	d2800021 	mov	x1, #0x1                   	// #1
    4788:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    478c:	910ba000 	add	x0, x0, #0x2e8
    4790:	f9400063 	ldr	x3, [x3]
    4794:	97fff89f 	bl	2a10 <fwrite@plt>
    4798:	52800ca0 	mov	w0, #0x65                  	// #101
    479c:	97fff809 	bl	27c0 <exit@plt>
    47a0:	97fff85c 	bl	2910 <__stack_chk_fail@plt>

00000000000047a4 <fwp_rc_wide_dup>:
    47a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    47a8:	910003fd 	mov	x29, sp
    47ac:	a90153f3 	stp	x19, x20, [sp, #16]
    47b0:	aa0003f3 	mov	x19, x0
    47b4:	ca404400 	eor	x0, x0, x0, lsr #17
    47b8:	f90013f5 	str	x21, [sp, #32]
    47bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    47c0:	ca402400 	eor	x0, x0, x0, lsr #9
    47c4:	9117c2a2 	add	x2, x21, #0x5f0
    47c8:	92401c00 	and	x0, x0, #0xff
    47cc:	910a2403 	add	x3, x0, #0x289
    47d0:	8b000c40 	add	x0, x2, x0, lsl #3
    47d4:	8b030c54 	add	x20, x2, x3, lsl #3
    47d8:	f94a2401 	ldr	x1, [x0, #5192]
    47dc:	b50000a1 	cbnz	x1, 47f0 <fwp_rc_wide_dup+0x4c>
    47e0:	1400002d 	b	4894 <fwp_rc_wide_dup+0xf0>
    47e4:	91004034 	add	x20, x1, #0x10
    47e8:	f9400821 	ldr	x1, [x1, #16]
    47ec:	b4000241 	cbz	x1, 4834 <fwp_rc_wide_dup+0x90>
    47f0:	f9400022 	ldr	x2, [x1]
    47f4:	eb02027f 	cmp	x19, x2
    47f8:	54ffff61 	b.ne	47e4 <fwp_rc_wide_dup+0x40>  // b.any
    47fc:	f9400281 	ldr	x1, [x20]
    4800:	39400260 	ldrb	w0, [x19]
    4804:	7103f81f 	cmp	w0, #0xfe
    4808:	54000220 	b.eq	484c <fwp_rc_wide_dup+0xa8>  // b.none
    480c:	b40001a1 	cbz	x1, 4840 <fwp_rc_wide_dup+0x9c>
    4810:	f9400420 	ldr	x0, [x1, #8]
    4814:	b100041f 	cmn	x0, #0x1
    4818:	540004a0 	b.eq	48ac <fwp_rc_wide_dup+0x108>  // b.none
    481c:	91000400 	add	x0, x0, #0x1
    4820:	f9000420 	str	x0, [x1, #8]
    4824:	a94153f3 	ldp	x19, x20, [sp, #16]
    4828:	f94013f5 	ldr	x21, [sp, #32]
    482c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4830:	d65f03c0 	ret
    4834:	39400260 	ldrb	w0, [x19]
    4838:	7103f81f 	cmp	w0, #0xfe
    483c:	540000a0 	b.eq	4850 <fwp_rc_wide_dup+0xac>  // b.none
    4840:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    4844:	910d0000 	add	x0, x0, #0x340
    4848:	97fffc0e 	bl	3880 <fwp_trap>
    484c:	b5000281 	cbnz	x1, 489c <fwp_rc_wide_dup+0xf8>
    4850:	d2800300 	mov	x0, #0x18                  	// #24
    4854:	97fff817 	bl	28b0 <malloc@plt>
    4858:	b4000280 	cbz	x0, 48a8 <fwp_rc_wide_dup+0x104>
    485c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4860:	a9000413 	stp	x19, x1, [x0]
    4864:	9117c2b5 	add	x21, x21, #0x5f0
    4868:	f900081f 	str	xzr, [x0, #16]
    486c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4870:	f9000280 	str	x0, [x20]
    4874:	39000261 	strb	w1, [x19]
    4878:	f94e26a0 	ldr	x0, [x21, #7240]
    487c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4880:	91000400 	add	x0, x0, #0x1
    4884:	f90e26a0 	str	x0, [x21, #7240]
    4888:	f94013f5 	ldr	x21, [sp, #32]
    488c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4890:	d65f03c0 	ret
    4894:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4898:	17ffffda 	b	4800 <fwp_rc_wide_dup+0x5c>
    489c:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    48a0:	910c6000 	add	x0, x0, #0x318
    48a4:	97fffbf7 	bl	3880 <fwp_trap>
    48a8:	97fffa02 	bl	30b0 <fwp_heap_oom>
    48ac:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    48b0:	910da000 	add	x0, x0, #0x368
    48b4:	97fffbf3 	bl	3880 <fwp_trap>
    48b8:	d503201f 	nop
    48bc:	d503201f 	nop

00000000000048c0 <fwp_rc_forget_slot>:
    48c0:	aa0003e1 	mov	x1, x0
    48c4:	39400000 	ldrb	w0, [x0]
    48c8:	7103fc1f 	cmp	w0, #0xff
    48cc:	54000040 	b.eq	48d4 <fwp_rc_forget_slot+0x14>  // b.none
    48d0:	d65f03c0 	ret
    48d4:	ca414420 	eor	x0, x1, x1, lsr #17
    48d8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    48dc:	ca402400 	eor	x0, x0, x0, lsr #9
    48e0:	910003fd 	mov	x29, sp
    48e4:	92401c00 	and	x0, x0, #0xff
    48e8:	f9000bf3 	str	x19, [sp, #16]
    48ec:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    48f0:	9117c262 	add	x2, x19, #0x5f0
    48f4:	910a2403 	add	x3, x0, #0x289
    48f8:	8b000c40 	add	x0, x2, x0, lsl #3
    48fc:	8b030c43 	add	x3, x2, x3, lsl #3
    4900:	f94a2400 	ldr	x0, [x0, #5192]
    4904:	b50000a0 	cbnz	x0, 4918 <fwp_rc_forget_slot+0x58>
    4908:	14000011 	b	494c <fwp_rc_forget_slot+0x8c>
    490c:	91004003 	add	x3, x0, #0x10
    4910:	f9400800 	ldr	x0, [x0, #16]
    4914:	b40001c0 	cbz	x0, 494c <fwp_rc_forget_slot+0x8c>
    4918:	f9400002 	ldr	x2, [x0]
    491c:	eb02003f 	cmp	x1, x2
    4920:	54ffff61 	b.ne	490c <fwp_rc_forget_slot+0x4c>  // b.any
    4924:	f9400801 	ldr	x1, [x0, #16]
    4928:	9117c273 	add	x19, x19, #0x5f0
    492c:	f9000061 	str	x1, [x3]
    4930:	97fff828 	bl	29d0 <free@plt>
    4934:	f94e2660 	ldr	x0, [x19, #7240]
    4938:	d1000400 	sub	x0, x0, #0x1
    493c:	f90e2660 	str	x0, [x19, #7240]
    4940:	f9400bf3 	ldr	x19, [sp, #16]
    4944:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4948:	d65f03c0 	ret
    494c:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    4950:	910d0000 	add	x0, x0, #0x340
    4954:	97fffbcb 	bl	3880 <fwp_trap>
    4958:	d503201f 	nop
    495c:	d503201f 	nop

0000000000004960 <fwp_rc_prepare_chunk>:
    4960:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4964:	910003fd 	mov	x29, sp
    4968:	a9025bf5 	stp	x21, x22, [sp, #32]
    496c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xbf0>
    4970:	9117c2c2 	add	x2, x22, #0x5f0
    4974:	b9401c03 	ldr	w3, [x0, #28]
    4978:	aa0103f5 	mov	x21, x1
    497c:	a90153f3 	stp	x19, x20, [sp, #16]
    4980:	aa0003f4 	mov	x20, x0
    4984:	f94e2440 	ldr	x0, [x2, #7240]
    4988:	b4000440 	cbz	x0, 4a10 <fwp_rc_prepare_chunk+0xb0>
    498c:	d2800013 	mov	x19, #0x0                   	// #0
    4990:	35000203 	cbnz	w3, 49d0 <fwp_rc_prepare_chunk+0x70>
    4994:	b4000361 	cbz	x1, 4a00 <fwp_rc_prepare_chunk+0xa0>
    4998:	f9401280 	ldr	x0, [x20, #32]
    499c:	97fff80d 	bl	29d0 <free@plt>
    49a0:	aa1503e0 	mov	x0, x21
    49a4:	d2800021 	mov	x1, #0x1                   	// #1
    49a8:	97fff7d2 	bl	28f0 <calloc@plt>
    49ac:	f9001280 	str	x0, [x20, #32]
    49b0:	b5000460 	cbnz	x0, 4a3c <fwp_rc_prepare_chunk+0xdc>
    49b4:	97fff9bf 	bl	30b0 <fwp_heap_oom>
    49b8:	97ffffc2 	bl	48c0 <fwp_rc_forget_slot>
    49bc:	91000673 	add	x19, x19, #0x1
    49c0:	b9401e83 	ldr	w3, [x20, #28]
    49c4:	eb13007f 	cmp	x3, x19
    49c8:	54000169 	b.ls	49f4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    49cc:	d503201f 	nop
    49d0:	f9401283 	ldr	x3, [x20, #32]
    49d4:	8b130060 	add	x0, x3, x19
    49d8:	38736863 	ldrb	w3, [x3, x19]
    49dc:	7103fc7f 	cmp	w3, #0xff
    49e0:	54fffec0 	b.eq	49b8 <fwp_rc_prepare_chunk+0x58>  // b.none
    49e4:	b9401e83 	ldr	w3, [x20, #28]
    49e8:	91000673 	add	x19, x19, #0x1
    49ec:	eb13007f 	cmp	x3, x19
    49f0:	54ffff08 	b.hi	49d0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49f4:	eb0302bf 	cmp	x21, x3
    49f8:	54000121 	b.ne	4a1c <fwp_rc_prepare_chunk+0xbc>  // b.any
    49fc:	b5000335 	cbnz	x21, 4a60 <fwp_rc_prepare_chunk+0x100>
    4a00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	2a0303e3 	mov	w3, w3
    4a14:	eb0302bf 	cmp	x21, x3
    4a18:	54ffff20 	b.eq	49fc <fwp_rc_prepare_chunk+0x9c>  // b.none
    4a1c:	9117c2c2 	add	x2, x22, #0x5f0
    4a20:	f9401280 	ldr	x0, [x20, #32]
    4a24:	f94e2841 	ldr	x1, [x2, #7248]
    4a28:	cb030021 	sub	x1, x1, x3
    4a2c:	f90e2841 	str	x1, [x2, #7248]
    4a30:	97fff7e8 	bl	29d0 <free@plt>
    4a34:	b5fffb75 	cbnz	x21, 49a0 <fwp_rc_prepare_chunk+0x40>
    4a38:	f900129f 	str	xzr, [x20, #32]
    4a3c:	9117c2d6 	add	x22, x22, #0x5f0
    4a40:	f94e2ac0 	ldr	x0, [x22, #7248]
    4a44:	b9001e95 	str	w21, [x20, #28]
    4a48:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a4c:	8b150000 	add	x0, x0, x21
    4a50:	f90e2ac0 	str	x0, [x22, #7248]
    4a54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a5c:	d65f03c0 	ret
    4a60:	f9401280 	ldr	x0, [x20, #32]
    4a64:	aa1503e2 	mov	x2, x21
    4a68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a6c:	52800001 	mov	w1, #0x0                   	// #0
    4a70:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a74:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a78:	17fff79a 	b	28e0 <memset@plt>
    4a7c:	d503201f 	nop

0000000000004a80 <fwp_heap_refill>:
    4a80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a84:	910003fd 	mov	x29, sp
    4a88:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a8c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4a90:	9117c2b5 	add	x21, x21, #0x5f0
    4a94:	aa0003f6 	mov	x22, x0
    4a98:	d2800020 	mov	x0, #0x1                   	// #1
    4a9c:	a90153f3 	stp	x19, x20, [sp, #16]
    4aa0:	a90363f7 	stp	x23, x24, [sp, #48]
    4aa4:	2a0103f7 	mov	w23, w1
    4aa8:	2a0203f8 	mov	w24, w2
    4aac:	97fffa21 	bl	3330 <fwp_heap_chunks>
    4ab0:	aa0003f3 	mov	x19, x0
    4ab4:	f949fea2 	ldr	x2, [x21, #5112]
    4ab8:	8b000800 	add	x0, x0, x0, lsl #2
    4abc:	2a1703e1 	mov	w1, w23
    4ac0:	52800025 	mov	w5, #0x1                   	// #1
    4ac4:	d37df000 	lsl	x0, x0, #3
    4ac8:	910f0021 	add	x1, x1, #0x3c0
    4acc:	8b000054 	add	x20, x2, x0
    4ad0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4ad4:	52a00024 	mov	w4, #0x10000               	// #65536
    4ad8:	38206845 	strb	w5, [x2, x0]
    4adc:	aa1403e0 	mov	x0, x20
    4ae0:	39000698 	strb	w24, [x20, #1]
    4ae4:	39000a97 	strb	w23, [x20, #2]
    4ae8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4aec:	b9000681 	str	w1, [x20, #4]
    4af0:	2a0103e5 	mov	w5, w1
    4af4:	8b0300a2 	add	x2, x5, x3
    4af8:	1ac10881 	udiv	w1, w4, w1
    4afc:	9ac50842 	udiv	x2, x2, x5
    4b00:	b9000a81 	str	w1, [x20, #8]
    4b04:	92404021 	and	x1, x1, #0x1ffff
    4b08:	b9001a82 	str	w2, [x20, #24]
    4b0c:	97ffff95 	bl	4960 <fwp_rc_prepare_chunk>
    4b10:	f949daa0 	ldr	x0, [x21, #5040]
    4b14:	29408a81 	ldp	w1, w2, [x20, #4]
    4b18:	8b134000 	add	x0, x0, x19, lsl #16
    4b1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b20:	8b214003 	add	x3, x0, w1, uxtw
    4b24:	9ba20021 	umaddl	x1, w1, w2, x0
    4b28:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b2c:	a90086c3 	stp	x3, x1, [x22, #8]
    4b30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b34:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b38:	d65f03c0 	ret
    4b3c:	d503201f 	nop

0000000000004b40 <fwp_mem_free>:
    4b40:	b40003c0 	cbz	x0, 4bb8 <fwp_mem_free+0x78>
    4b44:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4b48:	910003fd 	mov	x29, sp
    4b4c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b50:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4b54:	9117c2a1 	add	x1, x21, #0x5f0
    4b58:	a90153f3 	stp	x19, x20, [sp, #16]
    4b5c:	aa0003f3 	mov	x19, x0
    4b60:	f949d823 	ldr	x3, [x1, #5040]
    4b64:	f949ec22 	ldr	x2, [x1, #5080]
    4b68:	cb030000 	sub	x0, x0, x3
    4b6c:	eb02401f 	cmp	x0, x2, lsl #16
    4b70:	540001c2 	b.cs	4ba8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b74:	d350fc16 	lsr	x22, x0, #16
    4b78:	a90363f7 	stp	x23, x24, [sp, #48]
    4b7c:	f949fc22 	ldr	x2, [x1, #5112]
    4b80:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b84:	d37df294 	lsl	x20, x20, #3
    4b88:	ab140057 	adds	x23, x2, x20
    4b8c:	540000c0 	b.eq	4ba4 <fwp_mem_free+0x64>  // b.none
    4b90:	38746842 	ldrb	w2, [x2, x20]
    4b94:	7100045f 	cmp	w2, #0x1
    4b98:	54000120 	b.eq	4bbc <fwp_mem_free+0x7c>  // b.none
    4b9c:	7100085f 	cmp	w2, #0x2
    4ba0:	540005e0 	b.eq	4c5c <fwp_mem_free+0x11c>  // b.none
    4ba4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ba8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bb0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4bb4:	d65f03c0 	ret
    4bb8:	d65f03c0 	ret
    4bbc:	f94012f8 	ldr	x24, [x23, #32]
    4bc0:	b94006e1 	ldr	w1, [x23, #4]
    4bc4:	f90023f9 	str	x25, [sp, #64]
    4bc8:	2a0103e2 	mov	w2, w1
    4bcc:	394006f9 	ldrb	w25, [x23, #1]
    4bd0:	39400af4 	ldrb	w20, [x23, #2]
    4bd4:	b4000158 	cbz	x24, 4bfc <fwp_mem_free+0xbc>
    4bd8:	92403e76 	and	x22, x19, #0xffff
    4bdc:	9ac20ad6 	udiv	x22, x22, x2
    4be0:	38766b01 	ldrb	w1, [x24, x22]
    4be4:	8b160300 	add	x0, x24, x22
    4be8:	7103fc3f 	cmp	w1, #0xff
    4bec:	54000980 	b.eq	4d1c <fwp_mem_free+0x1dc>  // b.none
    4bf0:	38366b1f 	strb	wzr, [x24, x22]
    4bf4:	b94006e1 	ldr	w1, [x23, #4]
    4bf8:	2a0103e2 	mov	w2, w1
    4bfc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4c00:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4c04:	cb390000 	sub	x0, x0, w25, uxtb
    4c08:	8b340074 	add	x20, x3, w20, uxtb
    4c0c:	9117c2b5 	add	x21, x21, #0x5f0
    4c10:	1e630021 	ucvtf	d1, w1
    4c14:	d37ae400 	lsl	x0, x0, #6
    4c18:	8b140c14 	add	x20, x0, x20, lsl #3
    4c1c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c20:	f8746aa0 	ldr	x0, [x21, x20]
    4c24:	f94023f9 	ldr	x25, [sp, #64]
    4c28:	aa2003e0 	mvn	x0, x0
    4c2c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4c30:	f9000260 	str	x0, [x19]
    4c34:	f8346ab3 	str	x19, [x21, x20]
    4c38:	f94a12a0 	ldr	x0, [x21, #5152]
    4c3c:	1e612800 	fadd	d0, d0, d1
    4c40:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c44:	cb020000 	sub	x0, x0, x2
    4c48:	f90a12a0 	str	x0, [x21, #5152]
    4c4c:	fd0a22a0 	str	d0, [x21, #5184]
    4c50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c54:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c58:	d65f03c0 	ret
    4c5c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c60:	8b000063 	add	x3, x3, x0
    4c64:	eb03027f 	cmp	x19, x3
    4c68:	54fff9e1 	b.ne	4ba4 <fwp_mem_free+0x64>  // b.any
    4c6c:	fd400ae1 	ldr	d1, [x23, #16]
    4c70:	fd4a2020 	ldr	d0, [x1, #5184]
    4c74:	f9400ae0 	ldr	x0, [x23, #16]
    4c78:	7e61d821 	ucvtf	d1, d1
    4c7c:	f94a1022 	ldr	x2, [x1, #5152]
    4c80:	f94012f3 	ldr	x19, [x23, #32]
    4c84:	1e612800 	fadd	d0, d0, d1
    4c88:	cb000042 	sub	x2, x2, x0
    4c8c:	f90a1022 	str	x2, [x1, #5152]
    4c90:	fd0a2020 	str	d0, [x1, #5184]
    4c94:	b40000b3 	cbz	x19, 4ca8 <fwp_mem_free+0x168>
    4c98:	39400260 	ldrb	w0, [x19]
    4c9c:	7103fc1f 	cmp	w0, #0xff
    4ca0:	54000380 	b.eq	4d10 <fwp_mem_free+0x1d0>  // b.none
    4ca4:	3900027f 	strb	wzr, [x19]
    4ca8:	b9400ee2 	ldr	w2, [x23, #12]
    4cac:	b4000142 	cbz	x2, 4cd4 <fwp_mem_free+0x194>
    4cb0:	9117c2a1 	add	x1, x21, #0x5f0
    4cb4:	8b160040 	add	x0, x2, x22
    4cb8:	8b000800 	add	x0, x0, x0, lsl #2
    4cbc:	f949fc21 	ldr	x1, [x1, #5112]
    4cc0:	8b140034 	add	x20, x1, x20
    4cc4:	8b000c20 	add	x0, x1, x0, lsl #3
    4cc8:	3802869f 	strb	wzr, [x20], #40
    4ccc:	eb00029f 	cmp	x20, x0
    4cd0:	54ffffc1 	b.ne	4cc8 <fwp_mem_free+0x188>  // b.any
    4cd4:	9117c2a0 	add	x0, x21, #0x5f0
    4cd8:	f94a1801 	ldr	x1, [x0, #5168]
    4cdc:	f949f803 	ldr	x3, [x0, #5104]
    4ce0:	8b020021 	add	x1, x1, x2
    4ce4:	f90a1801 	str	x1, [x0, #5168]
    4ce8:	eb16007f 	cmp	x3, x22
    4cec:	54000049 	b.ls	4cf4 <fwp_mem_free+0x1b4>  // b.plast
    4cf0:	f909f816 	str	x22, [x0, #5104]
    4cf4:	9117c2b5 	add	x21, x21, #0x5f0
    4cf8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cfc:	eb16001f 	cmp	x0, x22
    4d00:	54fff529 	b.ls	4ba4 <fwp_mem_free+0x64>  // b.plast
    4d04:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d08:	f909f6b6 	str	x22, [x21, #5096]
    4d0c:	17ffffa7 	b	4ba8 <fwp_mem_free+0x68>
    4d10:	aa1303e0 	mov	x0, x19
    4d14:	97fffeeb 	bl	48c0 <fwp_rc_forget_slot>
    4d18:	17ffffe3 	b	4ca4 <fwp_mem_free+0x164>
    4d1c:	97fffee9 	bl	48c0 <fwp_rc_forget_slot>
    4d20:	17ffffb4 	b	4bf0 <fwp_mem_free+0xb0>

0000000000004d24 <fwp_heap_alloc_big>:
    4d24:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4d28:	910003fd 	mov	x29, sp
    4d2c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d30:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d34:	a90363f7 	stp	x23, x24, [sp, #48]
    4d38:	aa0003f7 	mov	x23, x0
    4d3c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4d40:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d44:	eb0002ff 	cmp	x23, x0
    4d48:	54000888 	b.hi	4e58 <fwp_heap_alloc_big+0x134>  // b.pmore
    4d4c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d50:	8b0002f4 	add	x20, x23, x0
    4d54:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xbf0>
    4d58:	9117c359 	add	x25, x26, #0x5f0
    4d5c:	d350fe94 	lsr	x20, x20, #16
    4d60:	2a0103f5 	mov	w21, w1
    4d64:	aa1403e0 	mov	x0, x20
    4d68:	97fff972 	bl	3330 <fwp_heap_chunks>
    4d6c:	f949ff22 	ldr	x2, [x25, #5112]
    4d70:	8b000813 	add	x19, x0, x0, lsl #2
    4d74:	aa0003f8 	mov	x24, x0
    4d78:	52800043 	mov	w3, #0x2                   	// #2
    4d7c:	d37df273 	lsl	x19, x19, #3
    4d80:	d2800021 	mov	x1, #0x1                   	// #1
    4d84:	8b130040 	add	x0, x2, x19
    4d88:	38336843 	strb	w3, [x2, x19]
    4d8c:	39000415 	strb	w21, [x0, #1]
    4d90:	b9000c14 	str	w20, [x0, #12]
    4d94:	f9000817 	str	x23, [x0, #16]
    4d98:	97fffef2 	bl	4960 <fwp_rc_prepare_chunk>
    4d9c:	f100069f 	cmp	x20, #0x1
    4da0:	54000269 	b.ls	4dec <fwp_heap_alloc_big+0xc8>  // b.plast
    4da4:	8b180294 	add	x20, x20, x24
    4da8:	9100a273 	add	x19, x19, #0x28
    4dac:	a90573fb 	stp	x27, x28, [sp, #80]
    4db0:	5280007b 	mov	w27, #0x3                   	// #3
    4db4:	8b140a94 	add	x20, x20, x20, lsl #2
    4db8:	2a1803fc 	mov	w28, w24
    4dbc:	9adb2296 	lsl	x22, x20, x27
    4dc0:	f949ff35 	ldr	x21, [x25, #5112]
    4dc4:	d2800001 	mov	x1, #0x0                   	// #0
    4dc8:	8b1302b4 	add	x20, x21, x19
    4dcc:	aa1403e0 	mov	x0, x20
    4dd0:	97fffee4 	bl	4960 <fwp_rc_prepare_chunk>
    4dd4:	38336abb 	strb	w27, [x21, x19]
    4dd8:	9100a273 	add	x19, x19, #0x28
    4ddc:	b9000e9c 	str	w28, [x20, #12]
    4de0:	eb1302df 	cmp	x22, x19
    4de4:	54fffee1 	b.ne	4dc0 <fwp_heap_alloc_big+0x9c>  // b.any
    4de8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4dec:	9117c353 	add	x19, x26, #0x5f0
    4df0:	aa1703e2 	mov	x2, x23
    4df4:	52800001 	mov	w1, #0x0                   	// #0
    4df8:	f949da60 	ldr	x0, [x19, #5040]
    4dfc:	8b184018 	add	x24, x0, x24, lsl #16
    4e00:	aa1803e0 	mov	x0, x24
    4e04:	97fff6b7 	bl	28e0 <memset@plt>
    4e08:	f94a1260 	ldr	x0, [x19, #5152]
    4e0c:	ab170000 	adds	x0, x0, x23
    4e10:	54000242 	b.cs	4e58 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4e14:	f94a1661 	ldr	x1, [x19, #5160]
    4e18:	f90a1260 	str	x0, [x19, #5152]
    4e1c:	eb01001f 	cmp	x0, x1
    4e20:	54000049 	b.ls	4e28 <fwp_heap_alloc_big+0x104>  // b.plast
    4e24:	f90a1660 	str	x0, [x19, #5160]
    4e28:	9117c35a 	add	x26, x26, #0x5f0
    4e2c:	9e6202e0 	scvtf	d0, x23
    4e30:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e34:	aa1803e0 	mov	x0, x24
    4e38:	fd4a1f41 	ldr	d1, [x26, #5176]
    4e3c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e40:	1e602820 	fadd	d0, d1, d0
    4e44:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e48:	fd0a1f40 	str	d0, [x26, #5176]
    4e4c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e50:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e54:	d65f03c0 	ret
    4e58:	a90573fb 	stp	x27, x28, [sp, #80]
    4e5c:	97fff895 	bl	30b0 <fwp_heap_oom>

0000000000004e60 <fwp_heap_alloc_slow>:
    4e60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e64:	910003fd 	mov	x29, sp
    4e68:	a90153f3 	stp	x19, x20, [sp, #16]
    4e6c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    4e70:	9117c262 	add	x2, x19, #0x5f0
    4e74:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e78:	aa0003f5 	mov	x21, x0
    4e7c:	2a0103f4 	mov	w20, w1
    4e80:	b953a440 	ldr	w0, [x2, #5028]
    4e84:	34000600 	cbz	w0, 4f44 <fwp_heap_alloc_slow+0xe4>
    4e88:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e8c:	54000628 	b.hi	4f50 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e90:	91003ea0 	add	x0, x21, #0xf
    4e94:	9117c262 	add	x2, x19, #0x5f0
    4e98:	f9001bf7 	str	x23, [sp, #48]
    4e9c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ea0:	8b401040 	add	x0, x2, x0, lsr #4
    4ea4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ea8:	d37ae484 	lsl	x4, x4, #6
    4eac:	397e8003 	ldrb	w3, [x0, #4000]
    4eb0:	910f0060 	add	x0, x3, #0x3c0
    4eb4:	aa0303e1 	mov	x1, x3
    4eb8:	8b030463 	add	x3, x3, x3, lsl #1
    4ebc:	8b030c83 	add	x3, x4, x3, lsl #3
    4ec0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4ec4:	2a1703f6 	mov	w22, w23
    4ec8:	f8636844 	ldr	x4, [x2, x3]
    4ecc:	b40004e4 	cbz	x4, 4f68 <fwp_heap_alloc_slow+0x108>
    4ed0:	f9400080 	ldr	x0, [x4]
    4ed4:	aa2003e0 	mvn	x0, x0
    4ed8:	f8236840 	str	x0, [x2, x3]
    4edc:	7100069f 	cmp	w20, #0x1
    4ee0:	aa0403e0 	mov	x0, x4
    4ee4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4ee8:	52800001 	mov	w1, #0x0                   	// #0
    4eec:	97fff67d 	bl	28e0 <memset@plt>
    4ef0:	aa0003e4 	mov	x4, x0
    4ef4:	9117c260 	add	x0, x19, #0x5f0
    4ef8:	f94a1001 	ldr	x1, [x0, #5152]
    4efc:	ab160021 	adds	x1, x1, x22
    4f00:	540005c2 	b.cs	4fb8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4f04:	f94a1402 	ldr	x2, [x0, #5160]
    4f08:	f90a1001 	str	x1, [x0, #5152]
    4f0c:	eb02003f 	cmp	x1, x2
    4f10:	54000049 	b.ls	4f18 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4f14:	f90a1401 	str	x1, [x0, #5160]
    4f18:	9117c273 	add	x19, x19, #0x5f0
    4f1c:	1e6302e1 	ucvtf	d1, w23
    4f20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f24:	aa0403e0 	mov	x0, x4
    4f28:	fd4a1e60 	ldr	d0, [x19, #5176]
    4f2c:	f9401bf7 	ldr	x23, [sp, #48]
    4f30:	1e612800 	fadd	d0, d0, d1
    4f34:	fd0a1e60 	str	d0, [x19, #5176]
    4f38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f3c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f40:	d65f03c0 	ret
    4f44:	97fffc90 	bl	4184 <fwp_heap_init>
    4f48:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f4c:	54fffa29 	b.ls	4e90 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f50:	2a1403e1 	mov	w1, w20
    4f54:	aa1503e0 	mov	x0, x21
    4f58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f60:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f64:	17ffff70 	b	4d24 <fwp_heap_alloc_big>
    4f68:	8b030042 	add	x2, x2, x3
    4f6c:	f9400444 	ldr	x4, [x2, #8]
    4f70:	b4000104 	cbz	x4, 4f90 <fwp_heap_alloc_slow+0x130>
    4f74:	f9400840 	ldr	x0, [x2, #16]
    4f78:	cb040000 	sub	x0, x0, x4
    4f7c:	eb16001f 	cmp	x0, x22
    4f80:	54000083 	b.cc	4f90 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f84:	8b160080 	add	x0, x4, x22
    4f88:	f9000440 	str	x0, [x2, #8]
    4f8c:	17ffffd4 	b	4edc <fwp_heap_alloc_slow+0x7c>
    4f90:	52800302 	mov	w2, #0x18                  	// #24
    4f94:	52807804 	mov	w4, #0x3c0                 	// #960
    4f98:	9117c260 	add	x0, x19, #0x5f0
    4f9c:	9ba27c23 	umull	x3, w1, w2
    4fa0:	2a1403e2 	mov	w2, w20
    4fa4:	9b240e84 	smaddl	x4, w20, w4, x3
    4fa8:	8b040000 	add	x0, x0, x4
    4fac:	97fffeb5 	bl	4a80 <fwp_heap_refill>
    4fb0:	aa0003e4 	mov	x4, x0
    4fb4:	17ffffca 	b	4edc <fwp_heap_alloc_slow+0x7c>
    4fb8:	97fff83e 	bl	30b0 <fwp_heap_oom>
    4fbc:	d503201f 	nop

0000000000004fc0 <fwp_heap_alloc>:
    4fc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4fc4:	f140101f 	cmp	x0, #0x4, lsl #12
    4fc8:	910003fd 	mov	x29, sp
    4fcc:	a90153f3 	stp	x19, x20, [sp, #16]
    4fd0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    4fd4:	9117c293 	add	x19, x20, #0x5f0
    4fd8:	b953a662 	ldr	w2, [x19, #5028]
    4fdc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4fe0:	54000640 	b.eq	50a8 <fwp_heap_alloc+0xe8>  // b.none
    4fe4:	91003c03 	add	x3, x0, #0xf
    4fe8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fec:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ff0:	8b431263 	add	x3, x19, x3, lsr #4
    4ff4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ff8:	d37ae442 	lsl	x2, x2, #6
    4ffc:	397e8063 	ldrb	w3, [x3, #4000]
    5000:	910f0064 	add	x4, x3, #0x3c0
    5004:	8b030463 	add	x3, x3, x3, lsl #1
    5008:	8b030c43 	add	x3, x2, x3, lsl #3
    500c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    5010:	2a1603f5 	mov	w21, w22
    5014:	f8636a64 	ldr	x4, [x19, x3]
    5018:	b4000384 	cbz	x4, 5088 <fwp_heap_alloc+0xc8>
    501c:	f9400085 	ldr	x5, [x4]
    5020:	7100043f 	cmp	w1, #0x1
    5024:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5028:	aa0403e0 	mov	x0, x4
    502c:	aa2503e5 	mvn	x5, x5
    5030:	52800001 	mov	w1, #0x0                   	// #0
    5034:	f8236a65 	str	x5, [x19, x3]
    5038:	97fff62a 	bl	28e0 <memset@plt>
    503c:	aa0003e4 	mov	x4, x0
    5040:	f94a1260 	ldr	x0, [x19, #5152]
    5044:	ab150000 	adds	x0, x0, x21
    5048:	54000442 	b.cs	50d0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    504c:	f94a1661 	ldr	x1, [x19, #5160]
    5050:	f90a1260 	str	x0, [x19, #5152]
    5054:	eb01001f 	cmp	x0, x1
    5058:	54000049 	b.ls	5060 <fwp_heap_alloc+0xa0>  // b.plast
    505c:	f90a1660 	str	x0, [x19, #5160]
    5060:	9117c294 	add	x20, x20, #0x5f0
    5064:	1e6302c1 	ucvtf	d1, w22
    5068:	a9425bf5 	ldp	x21, x22, [sp, #32]
    506c:	aa0403e0 	mov	x0, x4
    5070:	fd4a1e80 	ldr	d0, [x20, #5176]
    5074:	1e612800 	fadd	d0, d0, d1
    5078:	fd0a1e80 	str	d0, [x20, #5176]
    507c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5080:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5084:	d65f03c0 	ret
    5088:	8b030263 	add	x3, x19, x3
    508c:	f9400464 	ldr	x4, [x3, #8]
    5090:	b40000a4 	cbz	x4, 50a4 <fwp_heap_alloc+0xe4>
    5094:	f9400862 	ldr	x2, [x3, #16]
    5098:	cb040042 	sub	x2, x2, x4
    509c:	eb15005f 	cmp	x2, x21
    50a0:	540000a2 	b.cs	50b4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    50a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    50b0:	17ffff6c 	b	4e60 <fwp_heap_alloc_slow>
    50b4:	7100043f 	cmp	w1, #0x1
    50b8:	8b150085 	add	x5, x4, x21
    50bc:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    50c0:	52800001 	mov	w1, #0x0                   	// #0
    50c4:	aa0403e0 	mov	x0, x4
    50c8:	f9000465 	str	x5, [x3, #8]
    50cc:	17ffffdb 	b	5038 <fwp_heap_alloc+0x78>
    50d0:	97fff7f8 	bl	30b0 <fwp_heap_oom>

00000000000050d4 <fwp_data.part.0.constprop.0>:
    50d4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    50d8:	910003fd 	mov	x29, sp
    50dc:	a90153f3 	stp	x19, x20, [sp, #16]
    50e0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    50e4:	9117c283 	add	x3, x20, #0x5f0
    50e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    50ec:	aa0103f5 	mov	x21, x1
    50f0:	b953a461 	ldr	w1, [x3, #5028]
    50f4:	a90363f7 	stp	x23, x24, [sp, #48]
    50f8:	2a0003f8 	mov	w24, w0
    50fc:	34000701 	cbz	w1, 51dc <fwp_data.part.0.constprop.0+0x108>
    5100:	397e8862 	ldrb	w2, [x3, #4002]
    5104:	910f0040 	add	x0, x2, #0x3c0
    5108:	8b020442 	add	x2, x2, x2, lsl #1
    510c:	d37df042 	lsl	x2, x2, #3
    5110:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5114:	2a1703f6 	mov	w22, w23
    5118:	f8626873 	ldr	x19, [x3, x2]
    511c:	b40004d3 	cbz	x19, 51b4 <fwp_data.part.0.constprop.0+0xe0>
    5120:	f9400260 	ldr	x0, [x19]
    5124:	aa2003e0 	mvn	x0, x0
    5128:	f8226860 	str	x0, [x3, x2]
    512c:	f10062df 	cmp	x22, #0x18
    5130:	540000e9 	b.ls	514c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5134:	d10066c2 	sub	x2, x22, #0x19
    5138:	91006260 	add	x0, x19, #0x18
    513c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5140:	52800001 	mov	w1, #0x0                   	// #0
    5144:	91002042 	add	x2, x2, #0x8
    5148:	97fff5e6 	bl	28e0 <memset@plt>
    514c:	9117c282 	add	x2, x20, #0x5f0
    5150:	f94a1041 	ldr	x1, [x2, #5152]
    5154:	ab160021 	adds	x1, x1, x22
    5158:	540004c2 	b.cs	51f0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    515c:	f94a1440 	ldr	x0, [x2, #5160]
    5160:	f90a1041 	str	x1, [x2, #5152]
    5164:	eb00003f 	cmp	x1, x0
    5168:	54000049 	b.ls	5170 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    516c:	f90a1441 	str	x1, [x2, #5160]
    5170:	9117c294 	add	x20, x20, #0x5f0
    5174:	1e6302e1 	ucvtf	d1, w23
    5178:	fd4a1e80 	ldr	d0, [x20, #5176]
    517c:	1e612800 	fadd	d0, d0, d1
    5180:	fd0a1e80 	str	d0, [x20, #5176]
    5184:	52800041 	mov	w1, #0x2                   	// #2
    5188:	29000678 	stp	w24, w1, [x19]
    518c:	aa1303e0 	mov	x0, x19
    5190:	f94002a1 	ldr	x1, [x21]
    5194:	f9000661 	str	x1, [x19, #8]
    5198:	f94006a1 	ldr	x1, [x21, #8]
    519c:	f9000a61 	str	x1, [x19, #16]
    51a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    51a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    51ac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51b0:	d65f03c0 	ret
    51b4:	8b020063 	add	x3, x3, x2
    51b8:	f9400473 	ldr	x19, [x3, #8]
    51bc:	b4000113 	cbz	x19, 51dc <fwp_data.part.0.constprop.0+0x108>
    51c0:	f9400860 	ldr	x0, [x3, #16]
    51c4:	cb130000 	sub	x0, x0, x19
    51c8:	eb0002df 	cmp	x22, x0
    51cc:	54000088 	b.hi	51dc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    51d0:	8b160260 	add	x0, x19, x22
    51d4:	f9000460 	str	x0, [x3, #8]
    51d8:	17ffffd5 	b	512c <fwp_data.part.0.constprop.0+0x58>
    51dc:	52800001 	mov	w1, #0x0                   	// #0
    51e0:	d2800300 	mov	x0, #0x18                  	// #24
    51e4:	97ffff77 	bl	4fc0 <fwp_heap_alloc>
    51e8:	aa0003f3 	mov	x19, x0
    51ec:	17ffffe6 	b	5184 <fwp_data.part.0.constprop.0+0xb0>
    51f0:	97fff7b0 	bl	30b0 <fwp_heap_oom>

00000000000051f4 <fwp_p_ad_push>:
    51f4:	f100001f 	cmp	x0, #0x0
    51f8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51fc:	54000e8b 	b.lt	53cc <fwp_p_ad_push+0x1d8>  // b.tstop
    5200:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5204:	aa0003e4 	mov	x4, x0
    5208:	910003fd 	mov	x29, sp
    520c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5210:	aa0003f5 	mov	x21, x0
    5214:	aa020000 	orr	x0, x0, x2
    5218:	a90363f7 	stp	x23, x24, [sp, #48]
    521c:	aa0203f7 	mov	x23, x2
    5220:	6d0627e8 	stp	d8, d9, [sp, #96]
    5224:	9e670029 	fmov	d9, x1
    5228:	9e670068 	fmov	d8, x3
    522c:	b6f80900 	tbz	x0, #63, 534c <fwp_p_ad_push+0x158>
    5230:	a90153f3 	stp	x19, x20, [sp, #16]
    5234:	9360fc80 	asr	x0, x4, #32
    5238:	b6f800c4 	tbz	x4, #63, 5250 <fwp_p_ad_push+0x5c>
    523c:	1e604109 	fmov	d9, d8
    5240:	2f00e408 	movi	d8, #0x0
    5244:	9360fc40 	asr	x0, x2, #32
    5248:	aa0203f5 	mov	x21, x2
    524c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5250:	97fffa58 	bl	3bb0 <fwp_tape_of>
    5254:	aa0003f3 	mov	x19, x0
    5258:	f9403000 	ldr	x0, [x0, #96]
    525c:	b5001280 	cbnz	x0, 54ac <fwp_p_ad_push+0x2b8>
    5260:	f9400a76 	ldr	x22, [x19, #16]
    5264:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5268:	eb0002df 	cmp	x22, x0
    526c:	54000e2c 	b.gt	5430 <fwp_p_ad_push+0x23c>
    5270:	eb3542df 	cmp	x22, w21, uxtw
    5274:	54000d4d 	b.le	541c <fwp_p_ad_push+0x228>
    5278:	b7f80077 	tbnz	x23, #63, 5284 <fwp_p_ad_push+0x90>
    527c:	eb3742df 	cmp	x22, w23, uxtw
    5280:	54000ced 	b.le	541c <fwp_p_ad_push+0x228>
    5284:	f9400678 	ldr	x24, [x19, #8]
    5288:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    528c:	cb1802d8 	sub	x24, x22, x24
    5290:	91000701 	add	x1, x24, #0x1
    5294:	eb00003f 	cmp	x1, x0
    5298:	54000cc8 	b.hi	5430 <fwp_p_ad_push+0x23c>  // b.pmore
    529c:	a9418274 	ldp	x20, x0, [x19, #24]
    52a0:	a90573fb 	stp	x27, x28, [sp, #80]
    52a4:	eb14003f 	cmp	x1, x20
    52a8:	5400068d 	b.le	5378 <fwp_p_ad_push+0x184>
    52ac:	f100029f 	cmp	x20, #0x0
    52b0:	d2800803 	mov	x3, #0x40                  	// #64
    52b4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    52b8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    52bc:	a9046bf9 	stp	x25, x26, [sp, #64]
    52c0:	eb14003f 	cmp	x1, x20
    52c4:	5400008d 	b.le	52d4 <fwp_p_ad_push+0xe0>
    52c8:	eb02029f 	cmp	x20, x2
    52cc:	5400052d 	b.le	5370 <fwp_p_ad_push+0x17c>
    52d0:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    52d4:	d37df299 	lsl	x25, x20, #3
    52d8:	aa1903e1 	mov	x1, x25
    52dc:	97fff589 	bl	2900 <realloc@plt>
    52e0:	aa0003e1 	mov	x1, x0
    52e4:	b4000b00 	cbz	x0, 5444 <fwp_p_ad_push+0x250>
    52e8:	f9400e62 	ldr	x2, [x19, #24]
    52ec:	f9001261 	str	x1, [x19, #32]
    52f0:	f9401a60 	ldr	x0, [x19, #48]
    52f4:	d37cee9a 	lsl	x26, x20, #4
    52f8:	8b020821 	add	x1, x1, x2, lsl #2
    52fc:	f9001661 	str	x1, [x19, #40]
    5300:	aa1a03e1 	mov	x1, x26
    5304:	97fff57f 	bl	2900 <realloc@plt>
    5308:	aa0003e2 	mov	x2, x0
    530c:	b40009c0 	cbz	x0, 5444 <fwp_p_ad_push+0x250>
    5310:	f9400e61 	ldr	x1, [x19, #24]
    5314:	d37df31b 	lsl	x27, x24, #3
    5318:	d37ef685 	lsl	x5, x20, #2
    531c:	d37ef71c 	lsl	x28, x24, #2
    5320:	8b190004 	add	x4, x0, x25
    5324:	8b010c01 	add	x1, x0, x1, lsl #3
    5328:	a9030660 	stp	x0, x1, [x19, #48]
    532c:	b5000558 	cbnz	x24, 53d4 <fwp_p_ad_push+0x1e0>
    5330:	f9001e64 	str	x4, [x19, #56]
    5334:	f9401260 	ldr	x0, [x19, #32]
    5338:	a9446bf9 	ldp	x25, x26, [sp, #64]
    533c:	8b050001 	add	x1, x0, x5
    5340:	f9000e74 	str	x20, [x19, #24]
    5344:	f9001661 	str	x1, [x19, #40]
    5348:	14000010 	b	5388 <fwp_p_ad_push+0x194>
    534c:	9360fc40 	asr	x0, x2, #32
    5350:	a90153f3 	stp	x19, x20, [sp, #16]
    5354:	eb84801f 	cmp	x0, x4, asr #32
    5358:	54fff7c0 	b.eq	5250 <fwp_p_ad_push+0x5c>  // b.none
    535c:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    5360:	910e2000 	add	x0, x0, #0x388
    5364:	a9046bf9 	stp	x25, x26, [sp, #64]
    5368:	a90573fb 	stp	x27, x28, [sp, #80]
    536c:	97fff945 	bl	3880 <fwp_trap>
    5370:	d37ffa94 	lsl	x20, x20, #1
    5374:	17ffffd3 	b	52c0 <fwp_p_ad_push+0xcc>
    5378:	a9428a61 	ldp	x1, x2, [x19, #40]
    537c:	d37ef71c 	lsl	x28, x24, #2
    5380:	f9401e64 	ldr	x4, [x19, #56]
    5384:	d37df31b 	lsl	x27, x24, #3
    5388:	b83c6815 	str	w21, [x0, x28]
    538c:	f10002ff 	cmp	x23, #0x0
    5390:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5394:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5398:	fc3b6849 	str	d9, [x2, x27]
    539c:	aa1602a0 	orr	x0, x21, x22
    53a0:	b83c6837 	str	w23, [x1, x28]
    53a4:	910006d6 	add	x22, x22, #0x1
    53a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    53ac:	fc3b6888 	str	d8, [x4, x27]
    53b0:	a94573fb 	ldp	x27, x28, [sp, #80]
    53b4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    53b8:	f9000a76 	str	x22, [x19, #16]
    53bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    53c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53c4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    53c8:	d65f03c0 	ret
    53cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53d0:	d65f03c0 	ret
    53d4:	eb1a033f 	cmp	x25, x26
    53d8:	aa0403e0 	mov	x0, x4
    53dc:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    53e0:	aa1b03e2 	mov	x2, x27
    53e4:	cb190063 	sub	x3, x3, x25
    53e8:	f9003fe5 	str	x5, [sp, #120]
    53ec:	97fff5b1 	bl	2ab0 <__memmove_chk@plt>
    53f0:	a9420660 	ldp	x0, x1, [x19, #32]
    53f4:	aa1c03e2 	mov	x2, x28
    53f8:	f9401a63 	ldr	x3, [x19, #48]
    53fc:	f9403fe5 	ldr	x5, [sp, #120]
    5400:	8b190063 	add	x3, x3, x25
    5404:	f9001e63 	str	x3, [x19, #56]
    5408:	8b050000 	add	x0, x0, x5
    540c:	97fff4dd 	bl	2780 <memmove@plt>
    5410:	a9431262 	ldp	x2, x4, [x19, #48]
    5414:	f9403fe5 	ldr	x5, [sp, #120]
    5418:	17ffffc7 	b	5334 <fwp_p_ad_push+0x140>
    541c:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    5420:	91108000 	add	x0, x0, #0x420
    5424:	a9046bf9 	stp	x25, x26, [sp, #64]
    5428:	a90573fb 	stp	x27, x28, [sp, #80]
    542c:	97fff915 	bl	3880 <fwp_trap>
    5430:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    5434:	91100000 	add	x0, x0, #0x400
    5438:	a9046bf9 	stp	x25, x26, [sp, #64]
    543c:	a90573fb 	stp	x27, x28, [sp, #80]
    5440:	97fff910 	bl	3880 <fwp_trap>
    5444:	aa1303e0 	mov	x0, x19
    5448:	97fff6f2 	bl	3010 <fwp_tape_unlink_scope>
    544c:	f9401260 	ldr	x0, [x19, #32]
    5450:	97fff560 	bl	29d0 <free@plt>
    5454:	f9401a60 	ldr	x0, [x19, #48]
    5458:	97fff55e 	bl	29d0 <free@plt>
    545c:	f9402260 	ldr	x0, [x19, #64]
    5460:	97fff55c 	bl	29d0 <free@plt>
    5464:	f9000e7f 	str	xzr, [x19, #24]
    5468:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    546c:	f947e821 	ldr	x1, [x1, #4048]
    5470:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5474:	d2800262 	mov	x2, #0x13                  	// #19
    5478:	4f000400 	movi	v0.4s, #0x0
    547c:	f0000020 	adrp	x0, c000 <f0+0x232c>
    5480:	f9400023 	ldr	x3, [x1]
    5484:	b900067f 	str	wzr, [x19, #4]
    5488:	d2800021 	mov	x1, #0x1                   	// #1
    548c:	913fa000 	add	x0, x0, #0xfe8
    5490:	3c808260 	stur	q0, [x19, #8]
    5494:	ad010260 	stp	q0, q0, [x19, #32]
    5498:	97fff55e 	bl	2a10 <fwrite@plt>
    549c:	d2800000 	mov	x0, #0x0                   	// #0
    54a0:	97fff568 	bl	2a40 <fflush@plt>
    54a4:	52800cc0 	mov	w0, #0x66                  	// #102
    54a8:	97fff576 	bl	2a80 <_Exit@plt>
    54ac:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    54b0:	910f4000 	add	x0, x0, #0x3d0
    54b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54b8:	a90573fb 	stp	x27, x28, [sp, #80]
    54bc:	97fff8f1 	bl	3880 <fwp_trap>

00000000000054c0 <w120>:
    54c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    54c4:	9e660003 	fmov	x3, d0
    54c8:	aa0003e2 	mov	x2, x0
    54cc:	910003fd 	mov	x29, sp
    54d0:	fd001fea 	str	d10, [sp, #56]
    54d4:	1e60400a 	fmov	d10, d0
    54d8:	6d0427e8 	stp	d8, d9, [sp, #64]
    54dc:	1e604028 	fmov	d8, d1
    54e0:	1e600809 	fmul	d9, d0, d0
    54e4:	a90153f3 	stp	x19, x20, [sp, #16]
    54e8:	aa0103f4 	mov	x20, x1
    54ec:	aa0303e1 	mov	x1, x3
    54f0:	aa0003f3 	mov	x19, x0
    54f4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54f8:	f9001bf7 	str	x23, [sp, #48]
    54fc:	97ffff3e 	bl	51f4 <fwp_p_ad_push>
    5500:	aa0003e5 	mov	x5, x0
    5504:	97fffb90 	bl	4344 <caf75>
    5508:	9e670000 	fmov	d0, x0
    550c:	97fffb8e 	bl	4344 <caf75>
    5510:	1e693908 	fsub	d8, d8, d9
    5514:	aa1403e2 	mov	x2, x20
    5518:	1e614000 	fneg	d0, d0
    551c:	aa0003e3 	mov	x3, x0
    5520:	aa0503e0 	mov	x0, x5
    5524:	9e660117 	fmov	x23, d8
    5528:	9e660001 	fmov	x1, d0
    552c:	97ffff32 	bl	51f4 <fwp_p_ad_push>
    5530:	aa0003f5 	mov	x21, x0
    5534:	97fffb84 	bl	4344 <caf75>
    5538:	9e670000 	fmov	d0, x0
    553c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5540:	97fffb81 	bl	4344 <caf75>
    5544:	1e614000 	fneg	d0, d0
    5548:	aa0003e3 	mov	x3, x0
    554c:	1e6a3929 	fsub	d9, d9, d10
    5550:	aa1303e0 	mov	x0, x19
    5554:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5558:	9e660001 	fmov	x1, d0
    555c:	9e660136 	fmov	x22, d9
    5560:	97ffff25 	bl	51f4 <fwp_p_ad_push>
    5564:	1e680908 	fmul	d8, d8, d8
    5568:	aa0003f4 	mov	x20, x0
    556c:	aa1703e3 	mov	x3, x23
    5570:	aa1703e1 	mov	x1, x23
    5574:	aa1503e2 	mov	x2, x21
    5578:	aa1503e0 	mov	x0, x21
    557c:	97ffff1e 	bl	51f4 <fwp_p_ad_push>
    5580:	aa0003e2 	mov	x2, x0
    5584:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5588:	9e670020 	fmov	d0, x1
    558c:	9e660101 	fmov	x1, d8
    5590:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5594:	1e600908 	fmul	d8, d8, d0
    5598:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    559c:	97ffff16 	bl	51f4 <fwp_p_ad_push>
    55a0:	1e690929 	fmul	d9, d9, d9
    55a4:	aa1603e3 	mov	x3, x22
    55a8:	aa1603e1 	mov	x1, x22
    55ac:	aa1403e2 	mov	x2, x20
    55b0:	aa0003f3 	mov	x19, x0
    55b4:	aa1403e0 	mov	x0, x20
    55b8:	97ffff0f 	bl	51f4 <fwp_p_ad_push>
    55bc:	aa0003e5 	mov	x5, x0
    55c0:	97fffb61 	bl	4344 <caf75>
    55c4:	aa0003e6 	mov	x6, x0
    55c8:	97fffb5f 	bl	4344 <caf75>
    55cc:	1e692908 	fadd	d8, d8, d9
    55d0:	aa1303e2 	mov	x2, x19
    55d4:	aa0603e1 	mov	x1, x6
    55d8:	aa0003e3 	mov	x3, x0
    55dc:	aa0503e0 	mov	x0, x5
    55e0:	97ffff05 	bl	51f4 <fwp_p_ad_push>
    55e4:	aa0003e1 	mov	x1, x0
    55e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    55ec:	9e660100 	fmov	x0, d8
    55f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55f4:	f9401bf7 	ldr	x23, [sp, #48]
    55f8:	fd401fea 	ldr	d10, [sp, #56]
    55fc:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5600:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5604:	d65f03c0 	ret
    5608:	d503201f 	nop
    560c:	d503201f 	nop

0000000000005610 <w176.constprop.0>:
    5610:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5614:	910003fd 	mov	x29, sp
    5618:	a9025bf5 	stp	x21, x22, [sp, #32]
    561c:	fd001be8 	str	d8, [sp, #48]
    5620:	f9400015 	ldr	x21, [x0]
    5624:	b40003b5 	cbz	x21, 5698 <w176.constprop.0+0x88>
    5628:	2f00e408 	movi	d8, #0x0
    562c:	91002016 	add	x22, x0, #0x8
    5630:	a90153f3 	stp	x19, x20, [sp, #16]
    5634:	91004014 	add	x20, x0, #0x10
    5638:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    563c:	d2800013 	mov	x19, #0x0                   	// #0
    5640:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5644:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    5648:	97fffb3f 	bl	4344 <caf75>
    564c:	aa0003e6 	mov	x6, x0
    5650:	97fffb3d 	bl	4344 <caf75>
    5654:	1e602908 	fadd	d8, d8, d0
    5658:	aa0003e3 	mov	x3, x0
    565c:	aa0703e2 	mov	x2, x7
    5660:	aa0503e0 	mov	x0, x5
    5664:	aa0603e1 	mov	x1, x6
    5668:	91000a73 	add	x19, x19, #0x2
    566c:	97fffee2 	bl	51f4 <fwp_p_ad_push>
    5670:	aa0003e5 	mov	x5, x0
    5674:	eb1302bf 	cmp	x21, x19
    5678:	54fffe48 	b.hi	5640 <w176.constprop.0+0x30>  // b.pmore
    567c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5680:	9e660100 	fmov	x0, d8
    5684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5688:	aa0503e1 	mov	x1, x5
    568c:	fd401be8 	ldr	d8, [sp, #48]
    5690:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5694:	d65f03c0 	ret
    5698:	2f00e408 	movi	d8, #0x0
    569c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    56a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56a4:	aa0503e1 	mov	x1, x5
    56a8:	9e660100 	fmov	x0, d8
    56ac:	fd401be8 	ldr	d8, [sp, #48]
    56b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    56b4:	d65f03c0 	ret
    56b8:	d503201f 	nop
    56bc:	d503201f 	nop

00000000000056c0 <fwp_rc_share>:
    56c0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    56c4:	9117c042 	add	x2, x2, #0x5f0
    56c8:	f949d843 	ldr	x3, [x2, #5040]
    56cc:	f949ec41 	ldr	x1, [x2, #5080]
    56d0:	cb030000 	sub	x0, x0, x3
    56d4:	eb01401f 	cmp	x0, x1, lsl #16
    56d8:	540002c2 	b.cs	5730 <fwp_rc_share+0x70>  // b.hs, b.nlast
    56dc:	d350fc01 	lsr	x1, x0, #16
    56e0:	f949fc44 	ldr	x4, [x2, #5112]
    56e4:	8b010821 	add	x1, x1, x1, lsl #2
    56e8:	d37df021 	lsl	x1, x1, #3
    56ec:	8b010083 	add	x3, x4, x1
    56f0:	f9401062 	ldr	x2, [x3, #32]
    56f4:	b40001e2 	cbz	x2, 5730 <fwp_rc_share+0x70>
    56f8:	38616881 	ldrb	w1, [x4, x1]
    56fc:	7100083f 	cmp	w1, #0x2
    5700:	540001a0 	b.eq	5734 <fwp_rc_share+0x74>  // b.none
    5704:	7100043f 	cmp	w1, #0x1
    5708:	54000141 	b.ne	5730 <fwp_rc_share+0x70>  // b.any
    570c:	29430464 	ldp	w4, w1, [x3, #24]
    5710:	92403c00 	and	x0, x0, #0xffff
    5714:	9b047c00 	mul	x0, x0, x4
    5718:	d360fc00 	lsr	x0, x0, #32
    571c:	eb01001f 	cmp	x0, x1
    5720:	54000082 	b.cs	5730 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5724:	8b000042 	add	x2, x2, x0
    5728:	39400040 	ldrb	w0, [x2]
    572c:	350000a0 	cbnz	w0, 5740 <fwp_rc_share+0x80>
    5730:	d65f03c0 	ret
    5734:	72003c1f 	tst	w0, #0xffff
    5738:	54ffff80 	b.eq	5728 <fwp_rc_share+0x68>  // b.none
    573c:	d65f03c0 	ret
    5740:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5744:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    5748:	91110000 	add	x0, x0, #0x440
    574c:	910003fd 	mov	x29, sp
    5750:	97fff84c 	bl	3880 <fwp_trap>

0000000000005754 <fwp_rc_fresh>:
    5754:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5758:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    575c:	9117c063 	add	x3, x3, #0x5f0
    5760:	910003fd 	mov	x29, sp
    5764:	a90153f3 	stp	x19, x20, [sp, #16]
    5768:	aa0003f3 	mov	x19, x0
    576c:	f949d861 	ldr	x1, [x3, #5040]
    5770:	f949ec60 	ldr	x0, [x3, #5080]
    5774:	cb010261 	sub	x1, x19, x1
    5778:	eb00403f 	cmp	x1, x0, lsl #16
    577c:	54000322 	b.cs	57e0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5780:	d350fc22 	lsr	x2, x1, #16
    5784:	f949fc63 	ldr	x3, [x3, #5112]
    5788:	8b020842 	add	x2, x2, x2, lsl #2
    578c:	d37df042 	lsl	x2, x2, #3
    5790:	8b020060 	add	x0, x3, x2
    5794:	f9401014 	ldr	x20, [x0, #32]
    5798:	b4000254 	cbz	x20, 57e0 <fwp_rc_fresh+0x8c>
    579c:	38626862 	ldrb	w2, [x3, x2]
    57a0:	7100085f 	cmp	w2, #0x2
    57a4:	54000260 	b.eq	57f0 <fwp_rc_fresh+0x9c>  // b.none
    57a8:	7100045f 	cmp	w2, #0x1
    57ac:	540001a1 	b.ne	57e0 <fwp_rc_fresh+0x8c>  // b.any
    57b0:	29430002 	ldp	w2, w0, [x0, #24]
    57b4:	92403c21 	and	x1, x1, #0xffff
    57b8:	9b027c21 	mul	x1, x1, x2
    57bc:	d360fc21 	lsr	x1, x1, #32
    57c0:	eb00003f 	cmp	x1, x0
    57c4:	540000e2 	b.cs	57e0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    57c8:	8b010294 	add	x20, x20, x1
    57cc:	39400280 	ldrb	w0, [x20]
    57d0:	7103fc1f 	cmp	w0, #0xff
    57d4:	540001a0 	b.eq	5808 <fwp_rc_fresh+0xb4>  // b.none
    57d8:	52800020 	mov	w0, #0x1                   	// #1
    57dc:	39000280 	strb	w0, [x20]
    57e0:	aa1303e0 	mov	x0, x19
    57e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    57e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    57ec:	d65f03c0 	ret
    57f0:	72003c3f 	tst	w1, #0xffff
    57f4:	54fffec0 	b.eq	57cc <fwp_rc_fresh+0x78>  // b.none
    57f8:	aa1303e0 	mov	x0, x19
    57fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5800:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5804:	d65f03c0 	ret
    5808:	aa1403e0 	mov	x0, x20
    580c:	97fffc2d 	bl	48c0 <fwp_rc_forget_slot>
    5810:	17fffff2 	b	57d8 <fwp_rc_fresh+0x84>

0000000000005814 <fwp_rc_free_arr>:
    5814:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    5818:	9117c063 	add	x3, x3, #0x5f0
    581c:	f949d861 	ldr	x1, [x3, #5040]
    5820:	f949ec62 	ldr	x2, [x3, #5080]
    5824:	cb010001 	sub	x1, x0, x1
    5828:	eb02403f 	cmp	x1, x2, lsl #16
    582c:	54000342 	b.cs	5894 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5830:	d350fc22 	lsr	x2, x1, #16
    5834:	f949fc65 	ldr	x5, [x3, #5112]
    5838:	8b020842 	add	x2, x2, x2, lsl #2
    583c:	d37df042 	lsl	x2, x2, #3
    5840:	8b0200a4 	add	x4, x5, x2
    5844:	f9401083 	ldr	x3, [x4, #32]
    5848:	b4000263 	cbz	x3, 5894 <fwp_rc_free_arr+0x80>
    584c:	386268a2 	ldrb	w2, [x5, x2]
    5850:	7100085f 	cmp	w2, #0x2
    5854:	540001c0 	b.eq	588c <fwp_rc_free_arr+0x78>  // b.none
    5858:	7100045f 	cmp	w2, #0x1
    585c:	540001c1 	b.ne	5894 <fwp_rc_free_arr+0x80>  // b.any
    5860:	29430885 	ldp	w5, w2, [x4, #24]
    5864:	92403c21 	and	x1, x1, #0xffff
    5868:	9b057c21 	mul	x1, x1, x5
    586c:	d360fc21 	lsr	x1, x1, #32
    5870:	eb02003f 	cmp	x1, x2
    5874:	54000102 	b.cs	5894 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5878:	8b010063 	add	x3, x3, x1
    587c:	39400061 	ldrb	w1, [x3]
    5880:	7100043f 	cmp	w1, #0x1
    5884:	54000081 	b.ne	5894 <fwp_rc_free_arr+0x80>  // b.any
    5888:	17fffcae 	b	4b40 <fwp_mem_free>
    588c:	72003c3f 	tst	w1, #0xffff
    5890:	54ffff60 	b.eq	587c <fwp_rc_free_arr+0x68>  // b.none
    5894:	d65f03c0 	ret
    5898:	d503201f 	nop
    589c:	d503201f 	nop

00000000000058a0 <fwp_rc_dup>:
    58a0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    58a4:	9117c042 	add	x2, x2, #0x5f0
    58a8:	f949d841 	ldr	x1, [x2, #5040]
    58ac:	f949ec43 	ldr	x3, [x2, #5080]
    58b0:	cb010001 	sub	x1, x0, x1
    58b4:	eb03403f 	cmp	x1, x3, lsl #16
    58b8:	54000342 	b.cs	5920 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    58bc:	d350fc20 	lsr	x0, x1, #16
    58c0:	f949fc44 	ldr	x4, [x2, #5112]
    58c4:	8b000800 	add	x0, x0, x0, lsl #2
    58c8:	d37df002 	lsl	x2, x0, #3
    58cc:	8b020083 	add	x3, x4, x2
    58d0:	f9401060 	ldr	x0, [x3, #32]
    58d4:	b4000260 	cbz	x0, 5920 <fwp_rc_dup+0x80>
    58d8:	38626882 	ldrb	w2, [x4, x2]
    58dc:	7100085f 	cmp	w2, #0x2
    58e0:	54000220 	b.eq	5924 <fwp_rc_dup+0x84>  // b.none
    58e4:	7100045f 	cmp	w2, #0x1
    58e8:	540001c1 	b.ne	5920 <fwp_rc_dup+0x80>  // b.any
    58ec:	29430864 	ldp	w4, w2, [x3, #24]
    58f0:	92403c21 	and	x1, x1, #0xffff
    58f4:	9b047c21 	mul	x1, x1, x4
    58f8:	d360fc21 	lsr	x1, x1, #32
    58fc:	eb02003f 	cmp	x1, x2
    5900:	54000102 	b.cs	5920 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5904:	8b010000 	add	x0, x0, x1
    5908:	39400001 	ldrb	w1, [x0]
    590c:	340000a1 	cbz	w1, 5920 <fwp_rc_dup+0x80>
    5910:	7103f43f 	cmp	w1, #0xfd
    5914:	540000e8 	b.hi	5930 <fwp_rc_dup+0x90>  // b.pmore
    5918:	11000421 	add	w1, w1, #0x1
    591c:	39000001 	strb	w1, [x0]
    5920:	d65f03c0 	ret
    5924:	72003c3f 	tst	w1, #0xffff
    5928:	54ffff00 	b.eq	5908 <fwp_rc_dup+0x68>  // b.none
    592c:	d65f03c0 	ret
    5930:	17fffb9d 	b	47a4 <fwp_rc_wide_dup>

0000000000005934 <fwp_owned_entry173>:
    5934:	d10103ff 	sub	sp, sp, #0x40
    5938:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    593c:	f947f442 	ldr	x2, [x2, #4072]
    5940:	a9027bfd 	stp	x29, x30, [sp, #32]
    5944:	910083fd 	add	x29, sp, #0x20
    5948:	a90353f3 	stp	x19, x20, [sp, #48]
    594c:	f9400043 	ldr	x3, [x2]
    5950:	f9000fe3 	str	x3, [sp, #24]
    5954:	d2800003 	mov	x3, #0x0                   	// #0
    5958:	a9400c01 	ldp	x1, x3, [x0]
    595c:	f9400802 	ldr	x2, [x0, #16]
    5960:	ab020022 	adds	x2, x1, x2
    5964:	540006e6 	b.vs	5a40 <fwp_owned_entry173+0x10c>
    5968:	910023e1 	add	x1, sp, #0x8
    596c:	52800000 	mov	w0, #0x0                   	// #0
    5970:	a9008be3 	stp	x3, x2, [sp, #8]
    5974:	97fffdd8 	bl	50d4 <fwp_data.part.0.constprop.0>
    5978:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    597c:	9117c063 	add	x3, x3, #0x5f0
    5980:	aa0003f3 	mov	x19, x0
    5984:	f949d861 	ldr	x1, [x3, #5040]
    5988:	f949ec60 	ldr	x0, [x3, #5080]
    598c:	cb010261 	sub	x1, x19, x1
    5990:	eb00403f 	cmp	x1, x0, lsl #16
    5994:	54000322 	b.cs	59f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5998:	d350fc22 	lsr	x2, x1, #16
    599c:	f949fc63 	ldr	x3, [x3, #5112]
    59a0:	8b020842 	add	x2, x2, x2, lsl #2
    59a4:	d37df042 	lsl	x2, x2, #3
    59a8:	8b020060 	add	x0, x3, x2
    59ac:	f9401014 	ldr	x20, [x0, #32]
    59b0:	b4000254 	cbz	x20, 59f8 <fwp_owned_entry173+0xc4>
    59b4:	38626862 	ldrb	w2, [x3, x2]
    59b8:	7100085f 	cmp	w2, #0x2
    59bc:	54000360 	b.eq	5a28 <fwp_owned_entry173+0xf4>  // b.none
    59c0:	7100045f 	cmp	w2, #0x1
    59c4:	540001a1 	b.ne	59f8 <fwp_owned_entry173+0xc4>  // b.any
    59c8:	29430002 	ldp	w2, w0, [x0, #24]
    59cc:	92403c21 	and	x1, x1, #0xffff
    59d0:	9b027c21 	mul	x1, x1, x2
    59d4:	d360fc21 	lsr	x1, x1, #32
    59d8:	eb00003f 	cmp	x1, x0
    59dc:	540000e2 	b.cs	59f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    59e0:	8b010294 	add	x20, x20, x1
    59e4:	39400280 	ldrb	w0, [x20]
    59e8:	7103fc1f 	cmp	w0, #0xff
    59ec:	54000240 	b.eq	5a34 <fwp_owned_entry173+0x100>  // b.none
    59f0:	52800020 	mov	w0, #0x1                   	// #1
    59f4:	39000280 	strb	w0, [x20]
    59f8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    59fc:	f947f400 	ldr	x0, [x0, #4072]
    5a00:	f9400fe2 	ldr	x2, [sp, #24]
    5a04:	f9400001 	ldr	x1, [x0]
    5a08:	eb010042 	subs	x2, x2, x1
    5a0c:	d2800001 	mov	x1, #0x0                   	// #0
    5a10:	540001a1 	b.ne	5a44 <fwp_owned_entry173+0x110>  // b.any
    5a14:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a18:	aa1303e0 	mov	x0, x19
    5a1c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a20:	910103ff 	add	sp, sp, #0x40
    5a24:	d65f03c0 	ret
    5a28:	72003c3f 	tst	w1, #0xffff
    5a2c:	54fffe61 	b.ne	59f8 <fwp_owned_entry173+0xc4>  // b.any
    5a30:	17ffffed 	b	59e4 <fwp_owned_entry173+0xb0>
    5a34:	aa1403e0 	mov	x0, x20
    5a38:	97fffba2 	bl	48c0 <fwp_rc_forget_slot>
    5a3c:	17ffffed 	b	59f0 <fwp_owned_entry173+0xbc>
    5a40:	97fff430 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5a44:	97fff3b3 	bl	2910 <__stack_chk_fail@plt>
    5a48:	d503201f 	nop
    5a4c:	d503201f 	nop

0000000000005a50 <e173>:
    5a50:	d10103ff 	sub	sp, sp, #0x40
    5a54:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5a58:	f947f442 	ldr	x2, [x2, #4072]
    5a5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a60:	910083fd 	add	x29, sp, #0x20
    5a64:	a90353f3 	stp	x19, x20, [sp, #48]
    5a68:	f9400043 	ldr	x3, [x2]
    5a6c:	f9000fe3 	str	x3, [sp, #24]
    5a70:	d2800003 	mov	x3, #0x0                   	// #0
    5a74:	a9400c01 	ldp	x1, x3, [x0]
    5a78:	f9400802 	ldr	x2, [x0, #16]
    5a7c:	ab020022 	adds	x2, x1, x2
    5a80:	54000726 	b.vs	5b64 <e173+0x114>
    5a84:	910023e1 	add	x1, sp, #0x8
    5a88:	52800000 	mov	w0, #0x0                   	// #0
    5a8c:	a9008be3 	stp	x3, x2, [sp, #8]
    5a90:	97fffd91 	bl	50d4 <fwp_data.part.0.constprop.0>
    5a94:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    5a98:	9117c063 	add	x3, x3, #0x5f0
    5a9c:	aa0003f3 	mov	x19, x0
    5aa0:	f949d861 	ldr	x1, [x3, #5040]
    5aa4:	f949ec60 	ldr	x0, [x3, #5080]
    5aa8:	cb010261 	sub	x1, x19, x1
    5aac:	eb00403f 	cmp	x1, x0, lsl #16
    5ab0:	54000322 	b.cs	5b14 <e173+0xc4>  // b.hs, b.nlast
    5ab4:	d350fc22 	lsr	x2, x1, #16
    5ab8:	f949fc63 	ldr	x3, [x3, #5112]
    5abc:	8b020842 	add	x2, x2, x2, lsl #2
    5ac0:	d37df042 	lsl	x2, x2, #3
    5ac4:	8b020060 	add	x0, x3, x2
    5ac8:	f9401014 	ldr	x20, [x0, #32]
    5acc:	b4000254 	cbz	x20, 5b14 <e173+0xc4>
    5ad0:	38626862 	ldrb	w2, [x3, x2]
    5ad4:	7100085f 	cmp	w2, #0x2
    5ad8:	540003a0 	b.eq	5b4c <e173+0xfc>  // b.none
    5adc:	7100045f 	cmp	w2, #0x1
    5ae0:	540001a1 	b.ne	5b14 <e173+0xc4>  // b.any
    5ae4:	29430002 	ldp	w2, w0, [x0, #24]
    5ae8:	92403c21 	and	x1, x1, #0xffff
    5aec:	9b027c21 	mul	x1, x1, x2
    5af0:	d360fc21 	lsr	x1, x1, #32
    5af4:	eb00003f 	cmp	x1, x0
    5af8:	540000e2 	b.cs	5b14 <e173+0xc4>  // b.hs, b.nlast
    5afc:	8b010294 	add	x20, x20, x1
    5b00:	39400280 	ldrb	w0, [x20]
    5b04:	7103fc1f 	cmp	w0, #0xff
    5b08:	54000280 	b.eq	5b58 <e173+0x108>  // b.none
    5b0c:	52800020 	mov	w0, #0x1                   	// #1
    5b10:	39000280 	strb	w0, [x20]
    5b14:	aa1303e0 	mov	x0, x19
    5b18:	97fffeea 	bl	56c0 <fwp_rc_share>
    5b1c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5b20:	f947f400 	ldr	x0, [x0, #4072]
    5b24:	f9400fe2 	ldr	x2, [sp, #24]
    5b28:	f9400001 	ldr	x1, [x0]
    5b2c:	eb010042 	subs	x2, x2, x1
    5b30:	d2800001 	mov	x1, #0x0                   	// #0
    5b34:	540001a1 	b.ne	5b68 <e173+0x118>  // b.any
    5b38:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5b3c:	aa1303e0 	mov	x0, x19
    5b40:	a94353f3 	ldp	x19, x20, [sp, #48]
    5b44:	910103ff 	add	sp, sp, #0x40
    5b48:	d65f03c0 	ret
    5b4c:	72003c3f 	tst	w1, #0xffff
    5b50:	54fffe21 	b.ne	5b14 <e173+0xc4>  // b.any
    5b54:	17ffffeb 	b	5b00 <e173+0xb0>
    5b58:	aa1403e0 	mov	x0, x20
    5b5c:	97fffb59 	bl	48c0 <fwp_rc_forget_slot>
    5b60:	17ffffeb 	b	5b0c <e173+0xbc>
    5b64:	97fff3e7 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5b68:	97fff36a 	bl	2910 <__stack_chk_fail@plt>
    5b6c:	d503201f 	nop

0000000000005b70 <fwp_drop1>:
    5b70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b74:	910003fd 	mov	x29, sp
    5b78:	a90153f3 	stp	x19, x20, [sp, #16]
    5b7c:	f90013f5 	str	x21, [sp, #32]
    5b80:	90000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    5b84:	9117c2b4 	add	x20, x21, #0x5f0
    5b88:	f949da81 	ldr	x1, [x20, #5040]
    5b8c:	f949ee82 	ldr	x2, [x20, #5080]
    5b90:	cb010001 	sub	x1, x0, x1
    5b94:	eb02403f 	cmp	x1, x2, lsl #16
    5b98:	54000382 	b.cs	5c08 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b9c:	d350fc22 	lsr	x2, x1, #16
    5ba0:	f949fe84 	ldr	x4, [x20, #5112]
    5ba4:	8b020842 	add	x2, x2, x2, lsl #2
    5ba8:	d37df042 	lsl	x2, x2, #3
    5bac:	8b020083 	add	x3, x4, x2
    5bb0:	f9401073 	ldr	x19, [x3, #32]
    5bb4:	b40002b3 	cbz	x19, 5c08 <fwp_drop1+0x98>
    5bb8:	38626882 	ldrb	w2, [x4, x2]
    5bbc:	7100085f 	cmp	w2, #0x2
    5bc0:	540002c0 	b.eq	5c18 <fwp_drop1+0xa8>  // b.none
    5bc4:	7100045f 	cmp	w2, #0x1
    5bc8:	54000201 	b.ne	5c08 <fwp_drop1+0x98>  // b.any
    5bcc:	29430864 	ldp	w4, w2, [x3, #24]
    5bd0:	92403c21 	and	x1, x1, #0xffff
    5bd4:	9b047c21 	mul	x1, x1, x4
    5bd8:	d360fc21 	lsr	x1, x1, #32
    5bdc:	eb02003f 	cmp	x1, x2
    5be0:	54000142 	b.cs	5c08 <fwp_drop1+0x98>  // b.hs, b.nlast
    5be4:	8b010273 	add	x19, x19, x1
    5be8:	39400261 	ldrb	w1, [x19]
    5bec:	340000e1 	cbz	w1, 5c08 <fwp_drop1+0x98>
    5bf0:	7100043f 	cmp	w1, #0x1
    5bf4:	540001e0 	b.eq	5c30 <fwp_drop1+0xc0>  // b.none
    5bf8:	7103fc3f 	cmp	w1, #0xff
    5bfc:	540002e0 	b.eq	5c58 <fwp_drop1+0xe8>  // b.none
    5c00:	51000421 	sub	w1, w1, #0x1
    5c04:	39000261 	strb	w1, [x19]
    5c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c0c:	f94013f5 	ldr	x21, [sp, #32]
    5c10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c14:	d65f03c0 	ret
    5c18:	72003c3f 	tst	w1, #0xffff
    5c1c:	54fffe60 	b.eq	5be8 <fwp_drop1+0x78>  // b.none
    5c20:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c24:	f94013f5 	ldr	x21, [sp, #32]
    5c28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c2c:	d65f03c0 	ret
    5c30:	f9400813 	ldr	x19, [x0, #16]
    5c34:	97fffef8 	bl	5814 <fwp_rc_free_arr>
    5c38:	9117c2a0 	add	x0, x21, #0x5f0
    5c3c:	f949d801 	ldr	x1, [x0, #5040]
    5c40:	f949ec00 	ldr	x0, [x0, #5080]
    5c44:	cb010261 	sub	x1, x19, x1
    5c48:	eb00403f 	cmp	x1, x0, lsl #16
    5c4c:	54fffde2 	b.cs	5c08 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c50:	aa1303e0 	mov	x0, x19
    5c54:	17ffffd2 	b	5b9c <fwp_drop1+0x2c>
    5c58:	ca534660 	eor	x0, x19, x19, lsr #17
    5c5c:	9117c2b5 	add	x21, x21, #0x5f0
    5c60:	ca402400 	eor	x0, x0, x0, lsr #9
    5c64:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5c68:	f94a2400 	ldr	x0, [x0, #5192]
    5c6c:	b5000080 	cbnz	x0, 5c7c <fwp_drop1+0x10c>
    5c70:	14000010 	b	5cb0 <fwp_drop1+0x140>
    5c74:	f9400800 	ldr	x0, [x0, #16]
    5c78:	b40001c0 	cbz	x0, 5cb0 <fwp_drop1+0x140>
    5c7c:	f9400001 	ldr	x1, [x0]
    5c80:	eb13003f 	cmp	x1, x19
    5c84:	54ffff81 	b.ne	5c74 <fwp_drop1+0x104>  // b.any
    5c88:	f9400401 	ldr	x1, [x0, #8]
    5c8c:	d1000421 	sub	x1, x1, #0x1
    5c90:	f9000401 	str	x1, [x0, #8]
    5c94:	f103f83f 	cmp	x1, #0xfe
    5c98:	54fffb81 	b.ne	5c08 <fwp_drop1+0x98>  // b.any
    5c9c:	aa1303e0 	mov	x0, x19
    5ca0:	97fffb08 	bl	48c0 <fwp_rc_forget_slot>
    5ca4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ca8:	39000260 	strb	w0, [x19]
    5cac:	17ffffd7 	b	5c08 <fwp_drop1+0x98>
    5cb0:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    5cb4:	910d0000 	add	x0, x0, #0x340
    5cb8:	97fff6f2 	bl	3880 <fwp_trap>
    5cbc:	d503201f 	nop

0000000000005cc0 <fwp_drop0>:
    5cc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5cc4:	910003fd 	mov	x29, sp
    5cc8:	a90153f3 	stp	x19, x20, [sp, #16]
    5ccc:	f90013f5 	str	x21, [sp, #32]
    5cd0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    5cd4:	9117c2b4 	add	x20, x21, #0x5f0
    5cd8:	f949da81 	ldr	x1, [x20, #5040]
    5cdc:	f949ee82 	ldr	x2, [x20, #5080]
    5ce0:	cb010001 	sub	x1, x0, x1
    5ce4:	eb02403f 	cmp	x1, x2, lsl #16
    5ce8:	54000382 	b.cs	5d58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5cec:	d350fc22 	lsr	x2, x1, #16
    5cf0:	f949fe84 	ldr	x4, [x20, #5112]
    5cf4:	8b020842 	add	x2, x2, x2, lsl #2
    5cf8:	d37df042 	lsl	x2, x2, #3
    5cfc:	8b020083 	add	x3, x4, x2
    5d00:	f9401073 	ldr	x19, [x3, #32]
    5d04:	b40002b3 	cbz	x19, 5d58 <fwp_drop0+0x98>
    5d08:	38626882 	ldrb	w2, [x4, x2]
    5d0c:	7100085f 	cmp	w2, #0x2
    5d10:	540002c0 	b.eq	5d68 <fwp_drop0+0xa8>  // b.none
    5d14:	7100045f 	cmp	w2, #0x1
    5d18:	54000201 	b.ne	5d58 <fwp_drop0+0x98>  // b.any
    5d1c:	29430864 	ldp	w4, w2, [x3, #24]
    5d20:	92403c21 	and	x1, x1, #0xffff
    5d24:	9b047c21 	mul	x1, x1, x4
    5d28:	d360fc21 	lsr	x1, x1, #32
    5d2c:	eb02003f 	cmp	x1, x2
    5d30:	54000142 	b.cs	5d58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d34:	8b010273 	add	x19, x19, x1
    5d38:	39400261 	ldrb	w1, [x19]
    5d3c:	340000e1 	cbz	w1, 5d58 <fwp_drop0+0x98>
    5d40:	7100043f 	cmp	w1, #0x1
    5d44:	540001e0 	b.eq	5d80 <fwp_drop0+0xc0>  // b.none
    5d48:	7103fc3f 	cmp	w1, #0xff
    5d4c:	540002e0 	b.eq	5da8 <fwp_drop0+0xe8>  // b.none
    5d50:	51000421 	sub	w1, w1, #0x1
    5d54:	39000261 	strb	w1, [x19]
    5d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d5c:	f94013f5 	ldr	x21, [sp, #32]
    5d60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d64:	d65f03c0 	ret
    5d68:	72003c3f 	tst	w1, #0xffff
    5d6c:	54fffe60 	b.eq	5d38 <fwp_drop0+0x78>  // b.none
    5d70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d74:	f94013f5 	ldr	x21, [sp, #32]
    5d78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d7c:	d65f03c0 	ret
    5d80:	f9400813 	ldr	x19, [x0, #16]
    5d84:	97fffea4 	bl	5814 <fwp_rc_free_arr>
    5d88:	9117c2a0 	add	x0, x21, #0x5f0
    5d8c:	f949d801 	ldr	x1, [x0, #5040]
    5d90:	f949ec00 	ldr	x0, [x0, #5080]
    5d94:	cb010261 	sub	x1, x19, x1
    5d98:	eb00403f 	cmp	x1, x0, lsl #16
    5d9c:	54fffde2 	b.cs	5d58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5da0:	aa1303e0 	mov	x0, x19
    5da4:	17ffffd2 	b	5cec <fwp_drop0+0x2c>
    5da8:	ca534660 	eor	x0, x19, x19, lsr #17
    5dac:	9117c2b5 	add	x21, x21, #0x5f0
    5db0:	ca402400 	eor	x0, x0, x0, lsr #9
    5db4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5db8:	f94a2400 	ldr	x0, [x0, #5192]
    5dbc:	b5000080 	cbnz	x0, 5dcc <fwp_drop0+0x10c>
    5dc0:	14000010 	b	5e00 <fwp_drop0+0x140>
    5dc4:	f9400800 	ldr	x0, [x0, #16]
    5dc8:	b40001c0 	cbz	x0, 5e00 <fwp_drop0+0x140>
    5dcc:	f9400001 	ldr	x1, [x0]
    5dd0:	eb13003f 	cmp	x1, x19
    5dd4:	54ffff81 	b.ne	5dc4 <fwp_drop0+0x104>  // b.any
    5dd8:	f9400401 	ldr	x1, [x0, #8]
    5ddc:	d1000421 	sub	x1, x1, #0x1
    5de0:	f9000401 	str	x1, [x0, #8]
    5de4:	f103f83f 	cmp	x1, #0xfe
    5de8:	54fffb81 	b.ne	5d58 <fwp_drop0+0x98>  // b.any
    5dec:	aa1303e0 	mov	x0, x19
    5df0:	97fffab4 	bl	48c0 <fwp_rc_forget_slot>
    5df4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5df8:	39000260 	strb	w0, [x19]
    5dfc:	17ffffd7 	b	5d58 <fwp_drop0+0x98>
    5e00:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    5e04:	910d0000 	add	x0, x0, #0x340
    5e08:	97fff69e 	bl	3880 <fwp_trap>
    5e0c:	d503201f 	nop

0000000000005e10 <fwp_closure_drop>:
    5e10:	90000165 	adrp	x5, 31000 <fwp_root_context+0xbf0>
    5e14:	9117c0a4 	add	x4, x5, #0x5f0
    5e18:	aa0003e1 	mov	x1, x0
    5e1c:	f949d882 	ldr	x2, [x4, #5040]
    5e20:	f949ec80 	ldr	x0, [x4, #5080]
    5e24:	cb020022 	sub	x2, x1, x2
    5e28:	eb00405f 	cmp	x2, x0, lsl #16
    5e2c:	54000662 	b.cs	5ef8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5e30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5e34:	d350fc43 	lsr	x3, x2, #16
    5e38:	910003fd 	mov	x29, sp
    5e3c:	8b030863 	add	x3, x3, x3, lsl #2
    5e40:	f949fc84 	ldr	x4, [x4, #5112]
    5e44:	d37df063 	lsl	x3, x3, #3
    5e48:	f9000bf3 	str	x19, [sp, #16]
    5e4c:	8b030080 	add	x0, x4, x3
    5e50:	f9401013 	ldr	x19, [x0, #32]
    5e54:	b40002b3 	cbz	x19, 5ea8 <fwp_closure_drop+0x98>
    5e58:	38636883 	ldrb	w3, [x4, x3]
    5e5c:	7100087f 	cmp	w3, #0x2
    5e60:	54000420 	b.eq	5ee4 <fwp_closure_drop+0xd4>  // b.none
    5e64:	7100047f 	cmp	w3, #0x1
    5e68:	54000201 	b.ne	5ea8 <fwp_closure_drop+0x98>  // b.any
    5e6c:	29430003 	ldp	w3, w0, [x0, #24]
    5e70:	92403c42 	and	x2, x2, #0xffff
    5e74:	9b037c42 	mul	x2, x2, x3
    5e78:	d360fc42 	lsr	x2, x2, #32
    5e7c:	eb00005f 	cmp	x2, x0
    5e80:	54000142 	b.cs	5ea8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5e84:	8b020273 	add	x19, x19, x2
    5e88:	39400260 	ldrb	w0, [x19]
    5e8c:	340000e0 	cbz	w0, 5ea8 <fwp_closure_drop+0x98>
    5e90:	7100041f 	cmp	w0, #0x1
    5e94:	54000100 	b.eq	5eb4 <fwp_closure_drop+0xa4>  // b.none
    5e98:	7103fc1f 	cmp	w0, #0xff
    5e9c:	54000300 	b.eq	5efc <fwp_closure_drop+0xec>  // b.none
    5ea0:	51000400 	sub	w0, w0, #0x1
    5ea4:	39000260 	strb	w0, [x19]
    5ea8:	f9400bf3 	ldr	x19, [sp, #16]
    5eac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5eb0:	d65f03c0 	ret
    5eb4:	d53bd040 	mrs	x0, tpidr_el0
    5eb8:	91400000 	add	x0, x0, #0x0, lsl #12
    5ebc:	91004000 	add	x0, x0, #0x10
    5ec0:	f9400000 	ldr	x0, [x0]
    5ec4:	b4000080 	cbz	x0, 5ed4 <fwp_closure_drop+0xc4>
    5ec8:	f9400bf3 	ldr	x19, [sp, #16]
    5ecc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ed0:	17fff685 	b	38e4 <fwp_closure_drop_push>
    5ed4:	f9400bf3 	ldr	x19, [sp, #16]
    5ed8:	aa0103e0 	mov	x0, x1
    5edc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ee0:	17fff6f0 	b	3aa0 <fwp_closure_drop.part.0>
    5ee4:	72003c5f 	tst	w2, #0xffff
    5ee8:	54fffd00 	b.eq	5e88 <fwp_closure_drop+0x78>  // b.none
    5eec:	f9400bf3 	ldr	x19, [sp, #16]
    5ef0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ef4:	d65f03c0 	ret
    5ef8:	d65f03c0 	ret
    5efc:	ca534660 	eor	x0, x19, x19, lsr #17
    5f00:	9117c0a5 	add	x5, x5, #0x5f0
    5f04:	ca402400 	eor	x0, x0, x0, lsr #9
    5f08:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5f0c:	f94a2400 	ldr	x0, [x0, #5192]
    5f10:	b5000080 	cbnz	x0, 5f20 <fwp_closure_drop+0x110>
    5f14:	14000010 	b	5f54 <fwp_closure_drop+0x144>
    5f18:	f9400800 	ldr	x0, [x0, #16]
    5f1c:	b40001c0 	cbz	x0, 5f54 <fwp_closure_drop+0x144>
    5f20:	f9400001 	ldr	x1, [x0]
    5f24:	eb13003f 	cmp	x1, x19
    5f28:	54ffff81 	b.ne	5f18 <fwp_closure_drop+0x108>  // b.any
    5f2c:	f9400401 	ldr	x1, [x0, #8]
    5f30:	d1000421 	sub	x1, x1, #0x1
    5f34:	f9000401 	str	x1, [x0, #8]
    5f38:	f103f83f 	cmp	x1, #0xfe
    5f3c:	54fffb61 	b.ne	5ea8 <fwp_closure_drop+0x98>  // b.any
    5f40:	aa1303e0 	mov	x0, x19
    5f44:	97fffa5f 	bl	48c0 <fwp_rc_forget_slot>
    5f48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f4c:	39000260 	strb	w0, [x19]
    5f50:	17ffffd6 	b	5ea8 <fwp_closure_drop+0x98>
    5f54:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x20>
    5f58:	910d0000 	add	x0, x0, #0x340
    5f5c:	97fff649 	bl	3880 <fwp_trap>

0000000000005f60 <fwp_owned_tape_release>:
    5f60:	b4000940 	cbz	x0, 6088 <fwp_owned_tape_release+0x128>
    5f64:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f68:	910003fd 	mov	x29, sp
    5f6c:	a90153f3 	stp	x19, x20, [sp, #16]
    5f70:	aa0003f3 	mov	x19, x0
    5f74:	f9400000 	ldr	x0, [x0]
    5f78:	b4000060 	cbz	x0, 5f84 <fwp_owned_tape_release+0x24>
    5f7c:	f9400661 	ldr	x1, [x19, #8]
    5f80:	f9000401 	str	x1, [x0, #8]
    5f84:	f9400661 	ldr	x1, [x19, #8]
    5f88:	b4000041 	cbz	x1, 5f90 <fwp_owned_tape_release+0x30>
    5f8c:	f9000020 	str	x0, [x1]
    5f90:	f9400a60 	ldr	x0, [x19, #16]
    5f94:	f9403401 	ldr	x1, [x0, #104]
    5f98:	b40005c1 	cbz	x1, 6050 <fwp_owned_tape_release+0xf0>
    5f9c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5fa0:	eb00005f 	cmp	x2, x0
    5fa4:	540002ed 	b.le	6000 <fwp_owned_tape_release+0xa0>
    5fa8:	d2800014 	mov	x20, #0x0                   	// #0
    5fac:	f90013f5 	str	x21, [sp, #32]
    5fb0:	d2800015 	mov	x21, #0x0                   	// #0
    5fb4:	d503201f 	nop
    5fb8:	f9402260 	ldr	x0, [x19, #64]
    5fbc:	910006b5 	add	x21, x21, #0x1
    5fc0:	f8746800 	ldr	x0, [x0, x20]
    5fc4:	d63f0020 	blr	x1
    5fc8:	f9402260 	ldr	x0, [x19, #64]
    5fcc:	f9400a61 	ldr	x1, [x19, #16]
    5fd0:	8b140000 	add	x0, x0, x20
    5fd4:	91004294 	add	x20, x20, #0x10
    5fd8:	f9400400 	ldr	x0, [x0, #8]
    5fdc:	f9403421 	ldr	x1, [x1, #104]
    5fe0:	d63f0020 	blr	x1
    5fe4:	a9450261 	ldp	x1, x0, [x19, #80]
    5fe8:	cb010000 	sub	x0, x0, x1
    5fec:	eb15001f 	cmp	x0, x21
    5ff0:	f9400a60 	ldr	x0, [x19, #16]
    5ff4:	f9403401 	ldr	x1, [x0, #104]
    5ff8:	54fffe0c 	b.gt	5fb8 <fwp_owned_tape_release+0x58>
    5ffc:	f94013f5 	ldr	x21, [sp, #32]
    6000:	f9403663 	ldr	x3, [x19, #104]
    6004:	f9401262 	ldr	x2, [x19, #32]
    6008:	f100007f 	cmp	x3, #0x0
    600c:	540001ed 	b.le	6048 <fwp_owned_tape_release+0xe8>
    6010:	d2800014 	mov	x20, #0x0                   	// #0
    6014:	d503201f 	nop
    6018:	f9402660 	ldr	x0, [x19, #72]
    601c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6020:	eb02001f 	cmp	x0, x2
    6024:	540000c0 	b.eq	603c <fwp_owned_tape_release+0xdc>  // b.none
    6028:	d63f0020 	blr	x1
    602c:	f9400a60 	ldr	x0, [x19, #16]
    6030:	f9401262 	ldr	x2, [x19, #32]
    6034:	f9403663 	ldr	x3, [x19, #104]
    6038:	f9403401 	ldr	x1, [x0, #104]
    603c:	91000694 	add	x20, x20, #0x1
    6040:	eb14007f 	cmp	x3, x20
    6044:	54fffeac 	b.gt	6018 <fwp_owned_tape_release+0xb8>
    6048:	aa0203e0 	mov	x0, x2
    604c:	d63f0020 	blr	x1
    6050:	f9401660 	ldr	x0, [x19, #40]
    6054:	97ffff6f 	bl	5e10 <fwp_closure_drop>
    6058:	f9401a60 	ldr	x0, [x19, #48]
    605c:	97ffff6d 	bl	5e10 <fwp_closure_drop>
    6060:	f9401e60 	ldr	x0, [x19, #56]
    6064:	97ffff6b 	bl	5e10 <fwp_closure_drop>
    6068:	f9402260 	ldr	x0, [x19, #64]
    606c:	97fffab5 	bl	4b40 <fwp_mem_free>
    6070:	f9402660 	ldr	x0, [x19, #72]
    6074:	97fffab3 	bl	4b40 <fwp_mem_free>
    6078:	aa1303e0 	mov	x0, x19
    607c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6080:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6084:	17fffaaf 	b	4b40 <fwp_mem_free>
    6088:	d65f03c0 	ret
    608c:	d503201f 	nop

0000000000006090 <fwp_tape_finish>:
    6090:	d10203ff 	sub	sp, sp, #0x80
    6094:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6098:	f947f421 	ldr	x1, [x1, #4072]
    609c:	a9047bfd 	stp	x29, x30, [sp, #64]
    60a0:	910103fd 	add	x29, sp, #0x40
    60a4:	a90553f3 	stp	x19, x20, [sp, #80]
    60a8:	a9065bf5 	stp	x21, x22, [sp, #96]
    60ac:	a90763f7 	stp	x23, x24, [sp, #112]
    60b0:	d00000d8 	adrp	x24, 20000 <__data_start>
    60b4:	9101c316 	add	x22, x24, #0x70
    60b8:	f9400022 	ldr	x2, [x1]
    60bc:	f9001fe2 	str	x2, [sp, #56]
    60c0:	d2800002 	mov	x2, #0x0                   	// #0
    60c4:	9102e2c0 	add	x0, x22, #0xb8
    60c8:	97fff50e 	bl	3500 <fwp_tape_buffers_dispose>
    60cc:	f9007adf 	str	xzr, [x22, #240]
    60d0:	f9404ac0 	ldr	x0, [x22, #144]
    60d4:	f100001f 	cmp	x0, #0x0
    60d8:	5400030d 	b.le	6138 <fwp_tape_finish+0xa8>
    60dc:	910003f7 	mov	x23, sp
    60e0:	d2800015 	mov	x21, #0x0                   	// #0
    60e4:	d2800014 	mov	x20, #0x0                   	// #0
    60e8:	f94002d3 	ldr	x19, [x22]
    60ec:	91000694 	add	x20, x20, #0x1
    60f0:	8b150273 	add	x19, x19, x21
    60f4:	9101a2b5 	add	x21, x21, #0x68
    60f8:	aa1303e0 	mov	x0, x19
    60fc:	97fff3c5 	bl	3010 <fwp_tape_unlink_scope>
    6100:	aa1703e0 	mov	x0, x23
    6104:	f9401261 	ldr	x1, [x19, #32]
    6108:	f90003e1 	str	x1, [sp]
    610c:	f9401a62 	ldr	x2, [x19, #48]
    6110:	f9000be2 	str	x2, [sp, #16]
    6114:	f9402261 	ldr	x1, [x19, #64]
    6118:	f90013e1 	str	x1, [sp, #32]
    611c:	97fff4f9 	bl	3500 <fwp_tape_buffers_dispose>
    6120:	f9403260 	ldr	x0, [x19, #96]
    6124:	97ffff8f 	bl	5f60 <fwp_owned_tape_release>
    6128:	f900327f 	str	xzr, [x19, #96]
    612c:	f9404ac0 	ldr	x0, [x22, #144]
    6130:	eb14001f 	cmp	x0, x20
    6134:	54fffdac 	b.gt	60e8 <fwp_tape_finish+0x58>
    6138:	f9403b00 	ldr	x0, [x24, #112]
    613c:	9101c313 	add	x19, x24, #0x70
    6140:	97fff224 	bl	29d0 <free@plt>
    6144:	f9003b1f 	str	xzr, [x24, #112]
    6148:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    614c:	f947f400 	ldr	x0, [x0, #4072]
    6150:	f9004a7f 	str	xzr, [x19, #144]
    6154:	a9107e7f 	stp	xzr, xzr, [x19, #256]
    6158:	f9401fe2 	ldr	x2, [sp, #56]
    615c:	f9400001 	ldr	x1, [x0]
    6160:	eb010042 	subs	x2, x2, x1
    6164:	d2800001 	mov	x1, #0x0                   	// #0
    6168:	540000e1 	b.ne	6184 <fwp_tape_finish+0xf4>  // b.any
    616c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6170:	a94553f3 	ldp	x19, x20, [sp, #80]
    6174:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6178:	a94763f7 	ldp	x23, x24, [sp, #112]
    617c:	910203ff 	add	sp, sp, #0x80
    6180:	d65f03c0 	ret
    6184:	97fff1e3 	bl	2910 <__stack_chk_fail@plt>
    6188:	d503201f 	nop
    618c:	d503201f 	nop

0000000000006190 <fwp_tape_scope_release>:
    6190:	d10243ff 	sub	sp, sp, #0x90
    6194:	a9047bfd 	stp	x29, x30, [sp, #64]
    6198:	910103fd 	add	x29, sp, #0x40
    619c:	a90553f3 	stp	x19, x20, [sp, #80]
    61a0:	aa0003f4 	mov	x20, x0
    61a4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    61a8:	f947f400 	ldr	x0, [x0, #4072]
    61ac:	b9400285 	ldr	w5, [x20]
    61b0:	f9400001 	ldr	x1, [x0]
    61b4:	f9001fe1 	str	x1, [sp, #56]
    61b8:	d2800001 	mov	x1, #0x0                   	// #0
    61bc:	37f806c5 	tbnz	w5, #31, 6294 <fwp_tape_scope_release+0x104>
    61c0:	a90763f7 	stp	x23, x24, [sp, #112]
    61c4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    61c8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    61cc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    61d0:	d00000d3 	adrp	x19, 20000 <__data_start>
    61d4:	910003f7 	mov	x23, sp
    61d8:	9101c273 	add	x19, x19, #0x70
    61dc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    61e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    61e4:	52800d16 	mov	w22, #0x68                  	// #104
    61e8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    61ec:	f90043f9 	str	x25, [sp, #128]
    61f0:	14000006 	b	6208 <fwp_tape_scope_release+0x78>
    61f4:	97fff4c3 	bl	3500 <fwp_tape_buffers_dispose>
    61f8:	aa1903e0 	mov	x0, x25
    61fc:	97ffff59 	bl	5f60 <fwp_owned_tape_release>
    6200:	b9400285 	ldr	w5, [x20]
    6204:	37f80425 	tbnz	w5, #31, 6288 <fwp_tape_scope_release+0xf8>
    6208:	f9400266 	ldr	x6, [x19]
    620c:	9b367ca5 	smull	x5, w5, w22
    6210:	8b0500c0 	add	x0, x6, x5
    6214:	97fff37f 	bl	3010 <fwp_tape_unlink_scope>
    6218:	ad410001 	ldp	q1, q0, [x0, #32]
    621c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6220:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6224:	f9400c03 	ldr	x3, [x0, #24]
    6228:	ad0003e1 	stp	q1, q0, [sp]
    622c:	b86568c1 	ldr	w1, [x6, x5]
    6230:	a9440804 	ldp	x4, x2, [x0, #64]
    6234:	b900041f 	str	wzr, [x0, #4]
    6238:	f9403019 	ldr	x25, [x0, #96]
    623c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6240:	f9000c1f 	str	xzr, [x0, #24]
    6244:	a9020fe4 	stp	x4, x3, [sp, #32]
    6248:	f9001be2 	str	x2, [sp, #48]
    624c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6250:	f900301f 	str	xzr, [x0, #96]
    6254:	6b15003f 	cmp	w1, w21
    6258:	540000e8 	b.hi	6274 <fwp_tape_scope_release+0xe4>  // b.pmore
    625c:	9343fca5 	asr	x5, x5, #3
    6260:	f9408660 	ldr	x0, [x19, #264]
    6264:	9b187ca5 	mul	x5, x5, x24
    6268:	eb0000bf 	cmp	x5, x0
    626c:	5400004a 	b.ge	6274 <fwp_tape_scope_release+0xe4>  // b.tcont
    6270:	f9008665 	str	x5, [x19, #264]
    6274:	aa1703e0 	mov	x0, x23
    6278:	b5fffbf9 	cbnz	x25, 61f4 <fwp_tape_scope_release+0x64>
    627c:	97fff875 	bl	4450 <fwp_tape_buffers_release>
    6280:	b9400285 	ldr	w5, [x20]
    6284:	36fffc25 	tbz	w5, #31, 6208 <fwp_tape_scope_release+0x78>
    6288:	a9465bf5 	ldp	x21, x22, [sp, #96]
    628c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6290:	f94043f9 	ldr	x25, [sp, #128]
    6294:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6298:	f947f400 	ldr	x0, [x0, #4072]
    629c:	f9401fe2 	ldr	x2, [sp, #56]
    62a0:	f9400001 	ldr	x1, [x0]
    62a4:	eb010042 	subs	x2, x2, x1
    62a8:	d2800001 	mov	x1, #0x0                   	// #0
    62ac:	540000a1 	b.ne	62c0 <fwp_tape_scope_release+0x130>  // b.any
    62b0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    62b4:	a94553f3 	ldp	x19, x20, [sp, #80]
    62b8:	910243ff 	add	sp, sp, #0x90
    62bc:	d65f03c0 	ret
    62c0:	a9065bf5 	stp	x21, x22, [sp, #96]
    62c4:	a90763f7 	stp	x23, x24, [sp, #112]
    62c8:	f90043f9 	str	x25, [sp, #128]
    62cc:	97fff191 	bl	2910 <__stack_chk_fail@plt>

00000000000062d0 <fwp_drop4>:
    62d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    62d4:	910003fd 	mov	x29, sp
    62d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    62dc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xbf0>
    62e0:	9117c2d5 	add	x21, x22, #0x5f0
    62e4:	a90153f3 	stp	x19, x20, [sp, #16]
    62e8:	aa0003f3 	mov	x19, x0
    62ec:	f949daa1 	ldr	x1, [x21, #5040]
    62f0:	f949eea0 	ldr	x0, [x21, #5080]
    62f4:	cb010261 	sub	x1, x19, x1
    62f8:	eb00403f 	cmp	x1, x0, lsl #16
    62fc:	54000382 	b.cs	636c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6300:	d350fc22 	lsr	x2, x1, #16
    6304:	f949fea3 	ldr	x3, [x21, #5112]
    6308:	8b020842 	add	x2, x2, x2, lsl #2
    630c:	d37df042 	lsl	x2, x2, #3
    6310:	8b020060 	add	x0, x3, x2
    6314:	f9401014 	ldr	x20, [x0, #32]
    6318:	b40002b4 	cbz	x20, 636c <fwp_drop4+0x9c>
    631c:	38626862 	ldrb	w2, [x3, x2]
    6320:	7100085f 	cmp	w2, #0x2
    6324:	540002c0 	b.eq	637c <fwp_drop4+0xac>  // b.none
    6328:	7100045f 	cmp	w2, #0x1
    632c:	54000201 	b.ne	636c <fwp_drop4+0x9c>  // b.any
    6330:	29430002 	ldp	w2, w0, [x0, #24]
    6334:	92403c21 	and	x1, x1, #0xffff
    6338:	9b027c21 	mul	x1, x1, x2
    633c:	d360fc21 	lsr	x1, x1, #32
    6340:	eb00003f 	cmp	x1, x0
    6344:	54000142 	b.cs	636c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6348:	8b010294 	add	x20, x20, x1
    634c:	39400280 	ldrb	w0, [x20]
    6350:	340000e0 	cbz	w0, 636c <fwp_drop4+0x9c>
    6354:	7100041f 	cmp	w0, #0x1
    6358:	540001e0 	b.eq	6394 <fwp_drop4+0xc4>  // b.none
    635c:	7103fc1f 	cmp	w0, #0xff
    6360:	540007c0 	b.eq	6458 <fwp_drop4+0x188>  // b.none
    6364:	51000400 	sub	w0, w0, #0x1
    6368:	39000280 	strb	w0, [x20]
    636c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6370:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6374:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6378:	d65f03c0 	ret
    637c:	72003c3f 	tst	w1, #0xffff
    6380:	54fffe60 	b.eq	634c <fwp_drop4+0x7c>  // b.none
    6384:	a94153f3 	ldp	x19, x20, [sp, #16]
    6388:	a9425bf5 	ldp	x21, x22, [sp, #32]
    638c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6390:	d65f03c0 	ret
    6394:	9117c2c2 	add	x2, x22, #0x5f0
    6398:	f9400660 	ldr	x0, [x19, #8]
    639c:	f949d841 	ldr	x1, [x2, #5040]
    63a0:	f949ec42 	ldr	x2, [x2, #5080]
    63a4:	cb010001 	sub	x1, x0, x1
    63a8:	eb02403f 	cmp	x1, x2, lsl #16
    63ac:	54000362 	b.cs	6418 <fwp_drop4+0x148>  // b.hs, b.nlast
    63b0:	d350fc22 	lsr	x2, x1, #16
    63b4:	8b020842 	add	x2, x2, x2, lsl #2
    63b8:	d37df042 	lsl	x2, x2, #3
    63bc:	8b020064 	add	x4, x3, x2
    63c0:	f9401094 	ldr	x20, [x4, #32]
    63c4:	b40002b4 	cbz	x20, 6418 <fwp_drop4+0x148>
    63c8:	38626862 	ldrb	w2, [x3, x2]
    63cc:	7100085f 	cmp	w2, #0x2
    63d0:	540003e0 	b.eq	644c <fwp_drop4+0x17c>  // b.none
    63d4:	7100045f 	cmp	w2, #0x1
    63d8:	54000201 	b.ne	6418 <fwp_drop4+0x148>  // b.any
    63dc:	29430883 	ldp	w3, w2, [x4, #24]
    63e0:	92403c21 	and	x1, x1, #0xffff
    63e4:	9b037c21 	mul	x1, x1, x3
    63e8:	d360fc21 	lsr	x1, x1, #32
    63ec:	eb02003f 	cmp	x1, x2
    63f0:	54000142 	b.cs	6418 <fwp_drop4+0x148>  // b.hs, b.nlast
    63f4:	8b010294 	add	x20, x20, x1
    63f8:	39400281 	ldrb	w1, [x20]
    63fc:	340000e1 	cbz	w1, 6418 <fwp_drop4+0x148>
    6400:	7100043f 	cmp	w1, #0x1
    6404:	54000200 	b.eq	6444 <fwp_drop4+0x174>  // b.none
    6408:	7103fc3f 	cmp	w1, #0xff
    640c:	54000580 	b.eq	64bc <fwp_drop4+0x1ec>  // b.none
    6410:	51000421 	sub	w1, w1, #0x1
    6414:	39000281 	strb	w1, [x20]
    6418:	f9400a74 	ldr	x20, [x19, #16]
    641c:	aa1303e0 	mov	x0, x19
    6420:	97fffcfd 	bl	5814 <fwp_rc_free_arr>
    6424:	9117c2c0 	add	x0, x22, #0x5f0
    6428:	f949d801 	ldr	x1, [x0, #5040]
    642c:	f949ec00 	ldr	x0, [x0, #5080]
    6430:	cb010281 	sub	x1, x20, x1
    6434:	eb00403f 	cmp	x1, x0, lsl #16
    6438:	54fff9a2 	b.cs	636c <fwp_drop4+0x9c>  // b.hs, b.nlast
    643c:	aa1403f3 	mov	x19, x20
    6440:	17ffffb0 	b	6300 <fwp_drop4+0x30>
    6444:	97fffcf4 	bl	5814 <fwp_rc_free_arr>
    6448:	17fffff4 	b	6418 <fwp_drop4+0x148>
    644c:	72003c3f 	tst	w1, #0xffff
    6450:	54fffe41 	b.ne	6418 <fwp_drop4+0x148>  // b.any
    6454:	17ffffe9 	b	63f8 <fwp_drop4+0x128>
    6458:	ca544681 	eor	x1, x20, x20, lsr #17
    645c:	9117c2c0 	add	x0, x22, #0x5f0
    6460:	ca412421 	eor	x1, x1, x1, lsr #9
    6464:	8b210c01 	add	x1, x0, w1, uxtb #3
    6468:	f94a2420 	ldr	x0, [x1, #5192]
    646c:	b5000080 	cbnz	x0, 647c <fwp_drop4+0x1ac>
    6470:	14000010 	b	64b0 <fwp_drop4+0x1e0>
    6474:	f9400800 	ldr	x0, [x0, #16]
    6478:	b40001c0 	cbz	x0, 64b0 <fwp_drop4+0x1e0>
    647c:	f9400001 	ldr	x1, [x0]
    6480:	eb14003f 	cmp	x1, x20
    6484:	54ffff81 	b.ne	6474 <fwp_drop4+0x1a4>  // b.any
    6488:	f9400401 	ldr	x1, [x0, #8]
    648c:	d1000421 	sub	x1, x1, #0x1
    6490:	f9000401 	str	x1, [x0, #8]
    6494:	f103f83f 	cmp	x1, #0xfe
    6498:	54fff6a1 	b.ne	636c <fwp_drop4+0x9c>  // b.any
    649c:	aa1403e0 	mov	x0, x20
    64a0:	97fff908 	bl	48c0 <fwp_rc_forget_slot>
    64a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64a8:	39000280 	strb	w0, [x20]
    64ac:	17ffffb0 	b	636c <fwp_drop4+0x9c>
    64b0:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    64b4:	910d0000 	add	x0, x0, #0x340
    64b8:	97fff4f2 	bl	3880 <fwp_trap>
    64bc:	ca544680 	eor	x0, x20, x20, lsr #17
    64c0:	9117c2c1 	add	x1, x22, #0x5f0
    64c4:	ca402400 	eor	x0, x0, x0, lsr #9
    64c8:	8b200c20 	add	x0, x1, w0, uxtb #3
    64cc:	f94a2400 	ldr	x0, [x0, #5192]
    64d0:	b5000080 	cbnz	x0, 64e0 <fwp_drop4+0x210>
    64d4:	17fffff7 	b	64b0 <fwp_drop4+0x1e0>
    64d8:	f9400800 	ldr	x0, [x0, #16]
    64dc:	b4fffea0 	cbz	x0, 64b0 <fwp_drop4+0x1e0>
    64e0:	f9400001 	ldr	x1, [x0]
    64e4:	eb14003f 	cmp	x1, x20
    64e8:	54ffff81 	b.ne	64d8 <fwp_drop4+0x208>  // b.any
    64ec:	f9400401 	ldr	x1, [x0, #8]
    64f0:	d1000421 	sub	x1, x1, #0x1
    64f4:	f9000401 	str	x1, [x0, #8]
    64f8:	f103f83f 	cmp	x1, #0xfe
    64fc:	54fff8e1 	b.ne	6418 <fwp_drop4+0x148>  // b.any
    6500:	aa1403e0 	mov	x0, x20
    6504:	97fff8ef 	bl	48c0 <fwp_rc_forget_slot>
    6508:	12800020 	mov	w0, #0xfffffffe            	// #-2
    650c:	39000280 	strb	w0, [x20]
    6510:	17ffffc2 	b	6418 <fwp_drop4+0x148>

0000000000006514 <fwp_arg_drop37>:
    6514:	7100003f 	cmp	w1, #0x0
    6518:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    651c:	54000041 	b.ne	6524 <fwp_arg_drop37+0x10>  // b.any
    6520:	d65f03c0 	ret
    6524:	f9400000 	ldr	x0, [x0]
    6528:	17ffff6a 	b	62d0 <fwp_drop4>
    652c:	d503201f 	nop

0000000000006530 <fwp_task_dispose>:
    6530:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6534:	910003fd 	mov	x29, sp
    6538:	f9000bf3 	str	x19, [sp, #16]
    653c:	aa0003f3 	mov	x19, x0
    6540:	39414000 	ldrb	w0, [x0, #80]
    6544:	36000720 	tbz	w0, #0, 6628 <fwp_task_dispose+0xf8>
    6548:	f9400a60 	ldr	x0, [x19, #16]
    654c:	b50006e0 	cbnz	x0, 6628 <fwp_task_dispose+0xf8>
    6550:	a9478660 	ldp	x0, x1, [x19, #120]
    6554:	39014e7f 	strb	wzr, [x19, #83]
    6558:	f9003e7f 	str	xzr, [x19, #120]
    655c:	f100003f 	cmp	x1, #0x0
    6560:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6564:	54000040 	b.eq	656c <fwp_task_dispose+0x3c>  // b.none
    6568:	d63f0020 	blr	x1
    656c:	f9405660 	ldr	x0, [x19, #168]
    6570:	97fff974 	bl	4b40 <fwp_mem_free>
    6574:	f900567f 	str	xzr, [x19, #168]
    6578:	b9405e60 	ldr	w0, [x19, #92]
    657c:	7100041f 	cmp	w0, #0x1
    6580:	54000420 	b.eq	6604 <fwp_task_dispose+0xd4>  // b.none
    6584:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6588:	9117c042 	add	x2, x2, #0x5f0
    658c:	f949d840 	ldr	x0, [x2, #5040]
    6590:	f949ec41 	ldr	x1, [x2, #5080]
    6594:	cb000260 	sub	x0, x19, x0
    6598:	eb01401f 	cmp	x0, x1, lsl #16
    659c:	540002e2 	b.cs	65f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    65a0:	d350fc01 	lsr	x1, x0, #16
    65a4:	f949fc44 	ldr	x4, [x2, #5112]
    65a8:	8b010821 	add	x1, x1, x1, lsl #2
    65ac:	d37df021 	lsl	x1, x1, #3
    65b0:	8b010083 	add	x3, x4, x1
    65b4:	f9401062 	ldr	x2, [x3, #32]
    65b8:	b4000202 	cbz	x2, 65f8 <fwp_task_dispose+0xc8>
    65bc:	38616881 	ldrb	w1, [x4, x1]
    65c0:	7100083f 	cmp	w1, #0x2
    65c4:	54000280 	b.eq	6614 <fwp_task_dispose+0xe4>  // b.none
    65c8:	7100043f 	cmp	w1, #0x1
    65cc:	54000161 	b.ne	65f8 <fwp_task_dispose+0xc8>  // b.any
    65d0:	29430464 	ldp	w4, w1, [x3, #24]
    65d4:	92403c00 	and	x0, x0, #0xffff
    65d8:	9b047c00 	mul	x0, x0, x4
    65dc:	d360fc00 	lsr	x0, x0, #32
    65e0:	eb01001f 	cmp	x0, x1
    65e4:	540000a2 	b.cs	65f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    65e8:	8b000042 	add	x2, x2, x0
    65ec:	39400040 	ldrb	w0, [x2]
    65f0:	7100041f 	cmp	w0, #0x1
    65f4:	54000080 	b.eq	6604 <fwp_task_dispose+0xd4>  // b.none
    65f8:	f9400bf3 	ldr	x19, [sp, #16]
    65fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6600:	d65f03c0 	ret
    6604:	aa1303e0 	mov	x0, x19
    6608:	f9400bf3 	ldr	x19, [sp, #16]
    660c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6610:	17fff94c 	b	4b40 <fwp_mem_free>
    6614:	72003c1f 	tst	w0, #0xffff
    6618:	54fffea0 	b.eq	65ec <fwp_task_dispose+0xbc>  // b.none
    661c:	f9400bf3 	ldr	x19, [sp, #16]
    6620:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6624:	d65f03c0 	ret
    6628:	97fff0ce 	bl	2960 <abort@plt>
    662c:	d503201f 	nop

0000000000006630 <fwp_free_zombie>:
    6630:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6634:	910003fd 	mov	x29, sp
    6638:	a90153f3 	stp	x19, x20, [sp, #16]
    663c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6640:	9101c281 	add	x1, x20, #0x70
    6644:	f9408833 	ldr	x19, [x1, #272]
    6648:	b4000333 	cbz	x19, 66ac <fwp_free_zombie+0x7c>
    664c:	f9400820 	ldr	x0, [x1, #16]
    6650:	eb00027f 	cmp	x19, x0
    6654:	540002c0 	b.eq	66ac <fwp_free_zombie+0x7c>  // b.none
    6658:	b9411822 	ldr	w2, [x1, #280]
    665c:	f9400a60 	ldr	x0, [x19, #16]
    6660:	7100fc5f 	cmp	w2, #0x3f
    6664:	5400078c 	b.gt	6754 <fwp_free_zombie+0x124>
    6668:	91048023 	add	x3, x1, #0x120
    666c:	11000444 	add	w4, w2, #0x1
    6670:	b9011824 	str	w4, [x1, #280]
    6674:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6678:	f822d860 	str	x0, [x3, w2, sxtw #3]
    667c:	a9530261 	ldp	x1, x0, [x19, #304]
    6680:	b4000741 	cbz	x1, 6768 <fwp_free_zombie+0x138>
    6684:	f9009c20 	str	x0, [x1, #312]
    6688:	b4000040 	cbz	x0, 6690 <fwp_free_zombie+0x60>
    668c:	f9009801 	str	x1, [x0, #304]
    6690:	9101c294 	add	x20, x20, #0x70
    6694:	b9405e60 	ldr	w0, [x19, #92]
    6698:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    669c:	f9008a9f 	str	xzr, [x20, #272]
    66a0:	34000140 	cbz	w0, 66c8 <fwp_free_zombie+0x98>
    66a4:	7100041f 	cmp	w0, #0x1
    66a8:	54000080 	b.eq	66b8 <fwp_free_zombie+0x88>  // b.none
    66ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    66b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66b4:	d65f03c0 	ret
    66b8:	aa1303e0 	mov	x0, x19
    66bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    66c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66c4:	17ffff9b 	b	6530 <fwp_task_dispose>
    66c8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xbf0>
    66cc:	9117c082 	add	x2, x4, #0x5f0
    66d0:	f949d841 	ldr	x1, [x2, #5040]
    66d4:	f949ec40 	ldr	x0, [x2, #5080]
    66d8:	cb010261 	sub	x1, x19, x1
    66dc:	eb00403f 	cmp	x1, x0, lsl #16
    66e0:	54fffe62 	b.cs	66ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    66e4:	d350fc20 	lsr	x0, x1, #16
    66e8:	f949fc43 	ldr	x3, [x2, #5112]
    66ec:	8b000800 	add	x0, x0, x0, lsl #2
    66f0:	d37df000 	lsl	x0, x0, #3
    66f4:	8b000062 	add	x2, x3, x0
    66f8:	f9401054 	ldr	x20, [x2, #32]
    66fc:	b4fffd94 	cbz	x20, 66ac <fwp_free_zombie+0x7c>
    6700:	38606860 	ldrb	w0, [x3, x0]
    6704:	7100081f 	cmp	w0, #0x2
    6708:	54000360 	b.eq	6774 <fwp_free_zombie+0x144>  // b.none
    670c:	7100041f 	cmp	w0, #0x1
    6710:	54fffce1 	b.ne	66ac <fwp_free_zombie+0x7c>  // b.any
    6714:	29430043 	ldp	w3, w0, [x2, #24]
    6718:	92403c21 	and	x1, x1, #0xffff
    671c:	9b037c21 	mul	x1, x1, x3
    6720:	d360fc21 	lsr	x1, x1, #32
    6724:	eb00003f 	cmp	x1, x0
    6728:	54fffc22 	b.cs	66ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    672c:	8b010294 	add	x20, x20, x1
    6730:	39400280 	ldrb	w0, [x20]
    6734:	34fffbc0 	cbz	w0, 66ac <fwp_free_zombie+0x7c>
    6738:	7100041f 	cmp	w0, #0x1
    673c:	54fffbe0 	b.eq	66b8 <fwp_free_zombie+0x88>  // b.none
    6740:	7103fc1f 	cmp	w0, #0xff
    6744:	540001e0 	b.eq	6780 <fwp_free_zombie+0x150>  // b.none
    6748:	51000400 	sub	w0, w0, #0x1
    674c:	39000280 	strb	w0, [x20]
    6750:	17ffffd7 	b	66ac <fwp_free_zombie+0x7c>
    6754:	f9400e61 	ldr	x1, [x19, #24]
    6758:	97fff0b6 	bl	2a30 <munmap@plt>
    675c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6760:	a9530261 	ldp	x1, x0, [x19, #304]
    6764:	b5fff901 	cbnz	x1, 6684 <fwp_free_zombie+0x54>
    6768:	9101c282 	add	x2, x20, #0x70
    676c:	f9019040 	str	x0, [x2, #800]
    6770:	17ffffc6 	b	6688 <fwp_free_zombie+0x58>
    6774:	72003c3f 	tst	w1, #0xffff
    6778:	54fff9a1 	b.ne	66ac <fwp_free_zombie+0x7c>  // b.any
    677c:	17ffffed 	b	6730 <fwp_free_zombie+0x100>
    6780:	ca544680 	eor	x0, x20, x20, lsr #17
    6784:	9117c084 	add	x4, x4, #0x5f0
    6788:	ca402400 	eor	x0, x0, x0, lsr #9
    678c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6790:	f94a2400 	ldr	x0, [x0, #5192]
    6794:	b5000080 	cbnz	x0, 67a4 <fwp_free_zombie+0x174>
    6798:	14000010 	b	67d8 <fwp_free_zombie+0x1a8>
    679c:	f9400800 	ldr	x0, [x0, #16]
    67a0:	b40001c0 	cbz	x0, 67d8 <fwp_free_zombie+0x1a8>
    67a4:	f9400001 	ldr	x1, [x0]
    67a8:	eb14003f 	cmp	x1, x20
    67ac:	54ffff81 	b.ne	679c <fwp_free_zombie+0x16c>  // b.any
    67b0:	f9400401 	ldr	x1, [x0, #8]
    67b4:	d1000421 	sub	x1, x1, #0x1
    67b8:	f9000401 	str	x1, [x0, #8]
    67bc:	f103f83f 	cmp	x1, #0xfe
    67c0:	54fff761 	b.ne	66ac <fwp_free_zombie+0x7c>  // b.any
    67c4:	aa1403e0 	mov	x0, x20
    67c8:	97fff83e 	bl	48c0 <fwp_rc_forget_slot>
    67cc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67d0:	39000280 	strb	w0, [x20]
    67d4:	17ffffb6 	b	66ac <fwp_free_zombie+0x7c>
    67d8:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    67dc:	910d0000 	add	x0, x0, #0x340
    67e0:	97fff428 	bl	3880 <fwp_trap>

00000000000067e4 <fwp_block>:
    67e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67e8:	910003fd 	mov	x29, sp
    67ec:	a90153f3 	stp	x19, x20, [sp, #16]
    67f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    67f4:	9101c274 	add	x20, x19, #0x70
    67f8:	f9404282 	ldr	x2, [x20, #128]
    67fc:	b4000622 	cbz	x2, 68c0 <fwp_block+0xdc>
    6800:	9101c261 	add	x1, x19, #0x70
    6804:	f9408040 	ldr	x0, [x2, #256]
    6808:	f9004020 	str	x0, [x1, #128]
    680c:	b4000680 	cbz	x0, 68dc <fwp_block+0xf8>
    6810:	9101c263 	add	x3, x19, #0x70
    6814:	3901505f 	strb	wzr, [x2, #84]
    6818:	f9400864 	ldr	x4, [x3, #16]
    681c:	eb02009f 	cmp	x4, x2
    6820:	54000440 	b.eq	68a8 <fwp_block+0xc4>  // b.none
    6824:	f9419465 	ldr	x5, [x3, #808]
    6828:	f9000862 	str	x2, [x3, #16]
    682c:	f9400441 	ldr	x1, [x2, #8]
    6830:	f9004885 	str	x5, [x4, #144]
    6834:	f9419865 	ldr	x5, [x3, #816]
    6838:	f9004c85 	str	x5, [x4, #152]
    683c:	f9419c65 	ldr	x5, [x3, #824]
    6840:	f9005085 	str	x5, [x4, #160]
    6844:	f941a065 	ldr	x5, [x3, #832]
    6848:	f9005485 	str	x5, [x4, #168]
    684c:	f941a465 	ldr	x5, [x3, #840]
    6850:	f9005885 	str	x5, [x4, #176]
    6854:	f941a865 	ldr	x5, [x3, #848]
    6858:	f9005c85 	str	x5, [x4, #184]
    685c:	f941ac65 	ldr	x5, [x3, #856]
    6860:	f9006085 	str	x5, [x4, #192]
    6864:	f9400480 	ldr	x0, [x4, #8]
    6868:	f9404844 	ldr	x4, [x2, #144]
    686c:	f9019464 	str	x4, [x3, #808]
    6870:	f9404c44 	ldr	x4, [x2, #152]
    6874:	f9019864 	str	x4, [x3, #816]
    6878:	f9405044 	ldr	x4, [x2, #160]
    687c:	f9019c64 	str	x4, [x3, #824]
    6880:	f9405444 	ldr	x4, [x2, #168]
    6884:	f901a064 	str	x4, [x3, #832]
    6888:	f9405844 	ldr	x4, [x2, #176]
    688c:	f901a464 	str	x4, [x3, #840]
    6890:	a94b8844 	ldp	x4, x2, [x2, #184]
    6894:	f901a864 	str	x4, [x3, #848]
    6898:	f901ac62 	str	x2, [x3, #856]
    689c:	97fff035 	bl	2970 <swapcontext@plt>
    68a0:	97ffff64 	bl	6630 <fwp_free_zombie>
    68a4:	d503201f 	nop
    68a8:	9101c260 	add	x0, x19, #0x70
    68ac:	b9436000 	ldr	w0, [x0, #864]
    68b0:	340001a0 	cbz	w0, 68e4 <fwp_block+0x100>
    68b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    68b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68bc:	d65f03c0 	ret
    68c0:	97fff72c 	bl	4570 <fwp_poll_events>
    68c4:	f9404282 	ldr	x2, [x20, #128]
    68c8:	b4ffffc2 	cbz	x2, 68c0 <fwp_block+0xdc>
    68cc:	9101c261 	add	x1, x19, #0x70
    68d0:	f9408040 	ldr	x0, [x2, #256]
    68d4:	f9004020 	str	x0, [x1, #128]
    68d8:	b5fff9c0 	cbnz	x0, 6810 <fwp_block+0x2c>
    68dc:	f9003c3f 	str	xzr, [x1, #120]
    68e0:	17ffffcc 	b	6810 <fwp_block+0x2c>
    68e4:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    68e8:	9111c000 	add	x0, x0, #0x470
    68ec:	97fff06d 	bl	2aa0 <getenv@plt>
    68f0:	5284e202 	mov	w2, #0x2710                	// #10000
    68f4:	b4000060 	cbz	x0, 6900 <fwp_block+0x11c>
    68f8:	39400001 	ldrb	w1, [x0]
    68fc:	350000c1 	cbnz	w1, 6914 <fwp_block+0x130>
    6900:	9101c273 	add	x19, x19, #0x70
    6904:	b9036262 	str	w2, [x19, #864]
    6908:	a94153f3 	ldp	x19, x20, [sp, #16]
    690c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6910:	d65f03c0 	ret
    6914:	52800142 	mov	w2, #0xa                   	// #10
    6918:	d2800001 	mov	x1, #0x0                   	// #0
    691c:	97ffefb1 	bl	27e0 <strtoll@plt>
    6920:	d1000403 	sub	x3, x0, #0x1
    6924:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6928:	eb02007f 	cmp	x3, x2
    692c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6930:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6934:	17fffff3 	b	6900 <fwp_block+0x11c>
    6938:	d503201f 	nop
    693c:	d503201f 	nop

0000000000006940 <fwp_drop10>:
    6940:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6944:	910003fd 	mov	x29, sp
    6948:	a90153f3 	stp	x19, x20, [sp, #16]
    694c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    6950:	f90013f5 	str	x21, [sp, #32]
    6954:	9117c275 	add	x21, x19, #0x5f0
    6958:	f949daa1 	ldr	x1, [x21, #5040]
    695c:	f949eea2 	ldr	x2, [x21, #5080]
    6960:	cb010001 	sub	x1, x0, x1
    6964:	eb02403f 	cmp	x1, x2, lsl #16
    6968:	54000382 	b.cs	69d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    696c:	d350fc22 	lsr	x2, x1, #16
    6970:	f949fea3 	ldr	x3, [x21, #5112]
    6974:	8b020842 	add	x2, x2, x2, lsl #2
    6978:	d37df042 	lsl	x2, x2, #3
    697c:	8b020064 	add	x4, x3, x2
    6980:	f9401094 	ldr	x20, [x4, #32]
    6984:	b40002b4 	cbz	x20, 69d8 <fwp_drop10+0x98>
    6988:	38626862 	ldrb	w2, [x3, x2]
    698c:	7100085f 	cmp	w2, #0x2
    6990:	540007a0 	b.eq	6a84 <fwp_drop10+0x144>  // b.none
    6994:	7100045f 	cmp	w2, #0x1
    6998:	54000201 	b.ne	69d8 <fwp_drop10+0x98>  // b.any
    699c:	29430885 	ldp	w5, w2, [x4, #24]
    69a0:	92403c21 	and	x1, x1, #0xffff
    69a4:	9b057c21 	mul	x1, x1, x5
    69a8:	d360fc21 	lsr	x1, x1, #32
    69ac:	eb02003f 	cmp	x1, x2
    69b0:	54000142 	b.cs	69d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    69b4:	8b010294 	add	x20, x20, x1
    69b8:	39400281 	ldrb	w1, [x20]
    69bc:	340000e1 	cbz	w1, 69d8 <fwp_drop10+0x98>
    69c0:	7100043f 	cmp	w1, #0x1
    69c4:	54000120 	b.eq	69e8 <fwp_drop10+0xa8>  // b.none
    69c8:	7103fc3f 	cmp	w1, #0xff
    69cc:	540007c0 	b.eq	6ac4 <fwp_drop10+0x184>  // b.none
    69d0:	51000421 	sub	w1, w1, #0x1
    69d4:	39000281 	strb	w1, [x20]
    69d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    69dc:	f94013f5 	ldr	x21, [sp, #32]
    69e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69e4:	d65f03c0 	ret
    69e8:	f9400001 	ldr	x1, [x0]
    69ec:	b7f80581 	tbnz	x1, #63, 6a9c <fwp_drop10+0x15c>
    69f0:	9117c273 	add	x19, x19, #0x5f0
    69f4:	f949da61 	ldr	x1, [x19, #5040]
    69f8:	f949ee62 	ldr	x2, [x19, #5080]
    69fc:	cb010001 	sub	x1, x0, x1
    6a00:	eb02403f 	cmp	x1, x2, lsl #16
    6a04:	54fffea2 	b.cs	69d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a08:	d350fc22 	lsr	x2, x1, #16
    6a0c:	8b020842 	add	x2, x2, x2, lsl #2
    6a10:	d37df042 	lsl	x2, x2, #3
    6a14:	8b020065 	add	x5, x3, x2
    6a18:	f94010a4 	ldr	x4, [x5, #32]
    6a1c:	b4fffde4 	cbz	x4, 69d8 <fwp_drop10+0x98>
    6a20:	38626862 	ldrb	w2, [x3, x2]
    6a24:	7100085f 	cmp	w2, #0x2
    6a28:	54000220 	b.eq	6a6c <fwp_drop10+0x12c>  // b.none
    6a2c:	7100045f 	cmp	w2, #0x1
    6a30:	54fffd41 	b.ne	69d8 <fwp_drop10+0x98>  // b.any
    6a34:	294308a3 	ldp	w3, w2, [x5, #24]
    6a38:	92403c21 	and	x1, x1, #0xffff
    6a3c:	9b037c21 	mul	x1, x1, x3
    6a40:	d360fc21 	lsr	x1, x1, #32
    6a44:	eb02003f 	cmp	x1, x2
    6a48:	54fffc82 	b.cs	69d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a4c:	8b010084 	add	x4, x4, x1
    6a50:	39400081 	ldrb	w1, [x4]
    6a54:	7100043f 	cmp	w1, #0x1
    6a58:	54fffc01 	b.ne	69d8 <fwp_drop10+0x98>  // b.any
    6a5c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a60:	f94013f5 	ldr	x21, [sp, #32]
    6a64:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a68:	17fff836 	b	4b40 <fwp_mem_free>
    6a6c:	72003c3f 	tst	w1, #0xffff
    6a70:	54ffff00 	b.eq	6a50 <fwp_drop10+0x110>  // b.none
    6a74:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a78:	f94013f5 	ldr	x21, [sp, #32]
    6a7c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a80:	d65f03c0 	ret
    6a84:	72003c3f 	tst	w1, #0xffff
    6a88:	54fff980 	b.eq	69b8 <fwp_drop10+0x78>  // b.none
    6a8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a90:	f94013f5 	ldr	x21, [sp, #32]
    6a94:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a98:	d65f03c0 	ret
    6a9c:	f9400414 	ldr	x20, [x0, #8]
    6aa0:	97fffb5d 	bl	5814 <fwp_rc_free_arr>
    6aa4:	9117c260 	add	x0, x19, #0x5f0
    6aa8:	f949d801 	ldr	x1, [x0, #5040]
    6aac:	f949ec00 	ldr	x0, [x0, #5080]
    6ab0:	cb010281 	sub	x1, x20, x1
    6ab4:	eb00403f 	cmp	x1, x0, lsl #16
    6ab8:	54fff902 	b.cs	69d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6abc:	aa1403e0 	mov	x0, x20
    6ac0:	17ffffab 	b	696c <fwp_drop10+0x2c>
    6ac4:	ca544680 	eor	x0, x20, x20, lsr #17
    6ac8:	9117c273 	add	x19, x19, #0x5f0
    6acc:	ca402400 	eor	x0, x0, x0, lsr #9
    6ad0:	8b200e60 	add	x0, x19, w0, uxtb #3
    6ad4:	f94a2400 	ldr	x0, [x0, #5192]
    6ad8:	b5000080 	cbnz	x0, 6ae8 <fwp_drop10+0x1a8>
    6adc:	14000010 	b	6b1c <fwp_drop10+0x1dc>
    6ae0:	f9400800 	ldr	x0, [x0, #16]
    6ae4:	b40001c0 	cbz	x0, 6b1c <fwp_drop10+0x1dc>
    6ae8:	f9400001 	ldr	x1, [x0]
    6aec:	eb14003f 	cmp	x1, x20
    6af0:	54ffff81 	b.ne	6ae0 <fwp_drop10+0x1a0>  // b.any
    6af4:	f9400401 	ldr	x1, [x0, #8]
    6af8:	d1000421 	sub	x1, x1, #0x1
    6afc:	f9000401 	str	x1, [x0, #8]
    6b00:	f103f83f 	cmp	x1, #0xfe
    6b04:	54fff6a1 	b.ne	69d8 <fwp_drop10+0x98>  // b.any
    6b08:	aa1403e0 	mov	x0, x20
    6b0c:	97fff76d 	bl	48c0 <fwp_rc_forget_slot>
    6b10:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b14:	39000280 	strb	w0, [x20]
    6b18:	17ffffb0 	b	69d8 <fwp_drop10+0x98>
    6b1c:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    6b20:	910d0000 	add	x0, x0, #0x340
    6b24:	97fff357 	bl	3880 <fwp_trap>
    6b28:	d503201f 	nop
    6b2c:	d503201f 	nop

0000000000006b30 <fwp_caps173>:
    6b30:	34000041 	cbz	w1, 6b38 <fwp_caps173+0x8>
    6b34:	d65f03c0 	ret
    6b38:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    6b3c:	9117c063 	add	x3, x3, #0x5f0
    6b40:	f949d861 	ldr	x1, [x3, #5040]
    6b44:	f949ec62 	ldr	x2, [x3, #5080]
    6b48:	cb010001 	sub	x1, x0, x1
    6b4c:	eb02403f 	cmp	x1, x2, lsl #16
    6b50:	54ffff22 	b.cs	6b34 <fwp_caps173+0x4>  // b.hs, b.nlast
    6b54:	d350fc22 	lsr	x2, x1, #16
    6b58:	f949fc65 	ldr	x5, [x3, #5112]
    6b5c:	8b020842 	add	x2, x2, x2, lsl #2
    6b60:	d37df042 	lsl	x2, x2, #3
    6b64:	8b0200a4 	add	x4, x5, x2
    6b68:	f9401083 	ldr	x3, [x4, #32]
    6b6c:	b4fffe43 	cbz	x3, 6b34 <fwp_caps173+0x4>
    6b70:	386268a2 	ldrb	w2, [x5, x2]
    6b74:	7100085f 	cmp	w2, #0x2
    6b78:	540001c0 	b.eq	6bb0 <fwp_caps173+0x80>  // b.none
    6b7c:	7100045f 	cmp	w2, #0x1
    6b80:	54fffda1 	b.ne	6b34 <fwp_caps173+0x4>  // b.any
    6b84:	29430885 	ldp	w5, w2, [x4, #24]
    6b88:	92403c21 	and	x1, x1, #0xffff
    6b8c:	9b057c21 	mul	x1, x1, x5
    6b90:	d360fc21 	lsr	x1, x1, #32
    6b94:	eb02003f 	cmp	x1, x2
    6b98:	54fffce2 	b.cs	6b34 <fwp_caps173+0x4>  // b.hs, b.nlast
    6b9c:	8b010063 	add	x3, x3, x1
    6ba0:	39400061 	ldrb	w1, [x3]
    6ba4:	7100043f 	cmp	w1, #0x1
    6ba8:	54fffc61 	b.ne	6b34 <fwp_caps173+0x4>  // b.any
    6bac:	17fff7e5 	b	4b40 <fwp_mem_free>
    6bb0:	72003c3f 	tst	w1, #0xffff
    6bb4:	54ffff60 	b.eq	6ba0 <fwp_caps173+0x70>  // b.none
    6bb8:	d65f03c0 	ret
    6bbc:	d503201f 	nop

0000000000006bc0 <fwp_args37>:
    6bc0:	7100003f 	cmp	w1, #0x0
    6bc4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6bc8:	54000041 	b.ne	6bd0 <fwp_args37+0x10>  // b.any
    6bcc:	d65f03c0 	ret
    6bd0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6bd4:	9117c042 	add	x2, x2, #0x5f0
    6bd8:	f9400001 	ldr	x1, [x0]
    6bdc:	f949d843 	ldr	x3, [x2, #5040]
    6be0:	f949ec40 	ldr	x0, [x2, #5080]
    6be4:	cb030021 	sub	x1, x1, x3
    6be8:	eb00403f 	cmp	x1, x0, lsl #16
    6bec:	54ffff02 	b.cs	6bcc <fwp_args37+0xc>  // b.hs, b.nlast
    6bf0:	d350fc20 	lsr	x0, x1, #16
    6bf4:	f949fc44 	ldr	x4, [x2, #5112]
    6bf8:	8b000800 	add	x0, x0, x0, lsl #2
    6bfc:	d37df002 	lsl	x2, x0, #3
    6c00:	8b020083 	add	x3, x4, x2
    6c04:	f9401060 	ldr	x0, [x3, #32]
    6c08:	b4fffe20 	cbz	x0, 6bcc <fwp_args37+0xc>
    6c0c:	38626882 	ldrb	w2, [x4, x2]
    6c10:	7100085f 	cmp	w2, #0x2
    6c14:	54000220 	b.eq	6c58 <fwp_args37+0x98>  // b.none
    6c18:	7100045f 	cmp	w2, #0x1
    6c1c:	54fffd81 	b.ne	6bcc <fwp_args37+0xc>  // b.any
    6c20:	29430864 	ldp	w4, w2, [x3, #24]
    6c24:	92403c21 	and	x1, x1, #0xffff
    6c28:	9b047c21 	mul	x1, x1, x4
    6c2c:	d360fc21 	lsr	x1, x1, #32
    6c30:	eb02003f 	cmp	x1, x2
    6c34:	54fffcc2 	b.cs	6bcc <fwp_args37+0xc>  // b.hs, b.nlast
    6c38:	8b010000 	add	x0, x0, x1
    6c3c:	39400001 	ldrb	w1, [x0]
    6c40:	34fffc61 	cbz	w1, 6bcc <fwp_args37+0xc>
    6c44:	7103f43f 	cmp	w1, #0xfd
    6c48:	540000e8 	b.hi	6c64 <fwp_args37+0xa4>  // b.pmore
    6c4c:	11000421 	add	w1, w1, #0x1
    6c50:	39000001 	strb	w1, [x0]
    6c54:	d65f03c0 	ret
    6c58:	72003c3f 	tst	w1, #0xffff
    6c5c:	54ffff00 	b.eq	6c3c <fwp_args37+0x7c>  // b.none
    6c60:	d65f03c0 	ret
    6c64:	17fff6d0 	b	47a4 <fwp_rc_wide_dup>
    6c68:	d503201f 	nop
    6c6c:	d503201f 	nop

0000000000006c70 <fwp_caps37>:
    6c70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c74:	910003fd 	mov	x29, sp
    6c78:	f9000bf3 	str	x19, [sp, #16]
    6c7c:	aa0003f3 	mov	x19, x0
    6c80:	b9400400 	ldr	w0, [x0, #4]
    6c84:	340004a0 	cbz	w0, 6d18 <fwp_caps37+0xa8>
    6c88:	f9400660 	ldr	x0, [x19, #8]
    6c8c:	350004e1 	cbnz	w1, 6d28 <fwp_caps37+0xb8>
    6c90:	97fffd90 	bl	62d0 <fwp_drop4>
    6c94:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6c98:	9117c042 	add	x2, x2, #0x5f0
    6c9c:	f949d840 	ldr	x0, [x2, #5040]
    6ca0:	f949ec41 	ldr	x1, [x2, #5080]
    6ca4:	cb000260 	sub	x0, x19, x0
    6ca8:	eb01401f 	cmp	x0, x1, lsl #16
    6cac:	54000382 	b.cs	6d1c <fwp_caps37+0xac>  // b.hs, b.nlast
    6cb0:	d350fc01 	lsr	x1, x0, #16
    6cb4:	f949fc44 	ldr	x4, [x2, #5112]
    6cb8:	8b010821 	add	x1, x1, x1, lsl #2
    6cbc:	d37df021 	lsl	x1, x1, #3
    6cc0:	8b010083 	add	x3, x4, x1
    6cc4:	f9401062 	ldr	x2, [x3, #32]
    6cc8:	b40002a2 	cbz	x2, 6d1c <fwp_caps37+0xac>
    6ccc:	38616881 	ldrb	w1, [x4, x1]
    6cd0:	7100083f 	cmp	w1, #0x2
    6cd4:	540006c0 	b.eq	6dac <fwp_caps37+0x13c>  // b.none
    6cd8:	7100043f 	cmp	w1, #0x1
    6cdc:	54000201 	b.ne	6d1c <fwp_caps37+0xac>  // b.any
    6ce0:	29430464 	ldp	w4, w1, [x3, #24]
    6ce4:	92403c00 	and	x0, x0, #0xffff
    6ce8:	9b047c00 	mul	x0, x0, x4
    6cec:	d360fc00 	lsr	x0, x0, #32
    6cf0:	eb01001f 	cmp	x0, x1
    6cf4:	54000142 	b.cs	6d1c <fwp_caps37+0xac>  // b.hs, b.nlast
    6cf8:	8b000042 	add	x2, x2, x0
    6cfc:	39400040 	ldrb	w0, [x2]
    6d00:	7100041f 	cmp	w0, #0x1
    6d04:	540000c1 	b.ne	6d1c <fwp_caps37+0xac>  // b.any
    6d08:	aa1303e0 	mov	x0, x19
    6d0c:	f9400bf3 	ldr	x19, [sp, #16]
    6d10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d14:	17fff78b 	b	4b40 <fwp_mem_free>
    6d18:	34fffbe1 	cbz	w1, 6c94 <fwp_caps37+0x24>
    6d1c:	f9400bf3 	ldr	x19, [sp, #16]
    6d20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d24:	d65f03c0 	ret
    6d28:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6d2c:	9117c042 	add	x2, x2, #0x5f0
    6d30:	f949d843 	ldr	x3, [x2, #5040]
    6d34:	f949ec41 	ldr	x1, [x2, #5080]
    6d38:	cb030000 	sub	x0, x0, x3
    6d3c:	eb01401f 	cmp	x0, x1, lsl #16
    6d40:	54fffee2 	b.cs	6d1c <fwp_caps37+0xac>  // b.hs, b.nlast
    6d44:	d350fc01 	lsr	x1, x0, #16
    6d48:	f949fc44 	ldr	x4, [x2, #5112]
    6d4c:	8b010821 	add	x1, x1, x1, lsl #2
    6d50:	d37df021 	lsl	x1, x1, #3
    6d54:	8b010083 	add	x3, x4, x1
    6d58:	f9401062 	ldr	x2, [x3, #32]
    6d5c:	b4fffe02 	cbz	x2, 6d1c <fwp_caps37+0xac>
    6d60:	38616881 	ldrb	w1, [x4, x1]
    6d64:	7100083f 	cmp	w1, #0x2
    6d68:	54000280 	b.eq	6db8 <fwp_caps37+0x148>  // b.none
    6d6c:	7100043f 	cmp	w1, #0x1
    6d70:	54fffd61 	b.ne	6d1c <fwp_caps37+0xac>  // b.any
    6d74:	92403c01 	and	x1, x0, #0xffff
    6d78:	29430064 	ldp	w4, w0, [x3, #24]
    6d7c:	9b047c21 	mul	x1, x1, x4
    6d80:	d360fc21 	lsr	x1, x1, #32
    6d84:	eb00003f 	cmp	x1, x0
    6d88:	54fffca2 	b.cs	6d1c <fwp_caps37+0xac>  // b.hs, b.nlast
    6d8c:	8b010042 	add	x2, x2, x1
    6d90:	39400040 	ldrb	w0, [x2]
    6d94:	34fffc40 	cbz	w0, 6d1c <fwp_caps37+0xac>
    6d98:	7103f41f 	cmp	w0, #0xfd
    6d9c:	54000148 	b.hi	6dc4 <fwp_caps37+0x154>  // b.pmore
    6da0:	11000400 	add	w0, w0, #0x1
    6da4:	39000040 	strb	w0, [x2]
    6da8:	17ffffdd 	b	6d1c <fwp_caps37+0xac>
    6dac:	72003c1f 	tst	w0, #0xffff
    6db0:	54fffb61 	b.ne	6d1c <fwp_caps37+0xac>  // b.any
    6db4:	17ffffd2 	b	6cfc <fwp_caps37+0x8c>
    6db8:	72003c1f 	tst	w0, #0xffff
    6dbc:	54fffb01 	b.ne	6d1c <fwp_caps37+0xac>  // b.any
    6dc0:	17fffff4 	b	6d90 <fwp_caps37+0x120>
    6dc4:	f9400bf3 	ldr	x19, [sp, #16]
    6dc8:	aa0203e0 	mov	x0, x2
    6dcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6dd0:	17fff675 	b	47a4 <fwp_rc_wide_dup>

0000000000006dd4 <f37>:
    6dd4:	d101c3ff 	sub	sp, sp, #0x70
    6dd8:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6ddc:	f947f421 	ldr	x1, [x1, #4072]
    6de0:	a9027bfd 	stp	x29, x30, [sp, #32]
    6de4:	910083fd 	add	x29, sp, #0x20
    6de8:	a90563f7 	stp	x23, x24, [sp, #80]
    6dec:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xbf0>
    6df0:	9117c2e3 	add	x3, x23, #0x5f0
    6df4:	a90353f3 	stp	x19, x20, [sp, #48]
    6df8:	a9045bf5 	stp	x21, x22, [sp, #64]
    6dfc:	aa0003f6 	mov	x22, x0
    6e00:	a9066bf9 	stp	x25, x26, [sp, #96]
    6e04:	f949ec62 	ldr	x2, [x3, #5080]
    6e08:	f9400024 	ldr	x4, [x1]
    6e0c:	f9000fe4 	str	x4, [sp, #24]
    6e10:	d2800004 	mov	x4, #0x0                   	// #0
    6e14:	f949d861 	ldr	x1, [x3, #5040]
    6e18:	d370bc42 	lsl	x2, x2, #16
    6e1c:	b40015a0 	cbz	x0, 70d0 <f37+0x2fc>
    6e20:	f9400818 	ldr	x24, [x0, #16]
    6e24:	cb010301 	sub	x1, x24, x1
    6e28:	eb02003f 	cmp	x1, x2
    6e2c:	54000362 	b.cs	6e98 <f37+0xc4>  // b.hs, b.nlast
    6e30:	f949fc60 	ldr	x0, [x3, #5112]
    6e34:	d350fc22 	lsr	x2, x1, #16
    6e38:	8b020842 	add	x2, x2, x2, lsl #2
    6e3c:	8b020c02 	add	x2, x0, x2, lsl #3
    6e40:	f9401040 	ldr	x0, [x2, #32]
    6e44:	b40002a0 	cbz	x0, 6e98 <f37+0xc4>
    6e48:	39400043 	ldrb	w3, [x2]
    6e4c:	7100087f 	cmp	w3, #0x2
    6e50:	540013a0 	b.eq	70c4 <f37+0x2f0>  // b.none
    6e54:	7100047f 	cmp	w3, #0x1
    6e58:	540001c1 	b.ne	6e90 <f37+0xbc>  // b.any
    6e5c:	29430843 	ldp	w3, w2, [x2, #24]
    6e60:	92403c21 	and	x1, x1, #0xffff
    6e64:	9b037c21 	mul	x1, x1, x3
    6e68:	d360fc21 	lsr	x1, x1, #32
    6e6c:	eb02003f 	cmp	x1, x2
    6e70:	54000102 	b.cs	6e90 <f37+0xbc>  // b.hs, b.nlast
    6e74:	8b010000 	add	x0, x0, x1
    6e78:	39400001 	ldrb	w1, [x0]
    6e7c:	340000a1 	cbz	w1, 6e90 <f37+0xbc>
    6e80:	7103f43f 	cmp	w1, #0xfd
    6e84:	54001688 	b.hi	7154 <f37+0x380>  // b.pmore
    6e88:	11000421 	add	w1, w1, #0x1
    6e8c:	39000001 	strb	w1, [x0]
    6e90:	d2800000 	mov	x0, #0x0                   	// #0
    6e94:	b40000d6 	cbz	x22, 6eac <f37+0xd8>
    6e98:	aa1603e1 	mov	x1, x22
    6e9c:	d2800000 	mov	x0, #0x0                   	// #0
    6ea0:	f9400821 	ldr	x1, [x1, #16]
    6ea4:	91000400 	add	x0, x0, #0x1
    6ea8:	b5ffffc1 	cbnz	x1, 6ea0 <f37+0xcc>
    6eac:	b40011b8 	cbz	x24, 70e0 <f37+0x30c>
    6eb0:	aa1803e1 	mov	x1, x24
    6eb4:	d2800002 	mov	x2, #0x0                   	// #0
    6eb8:	f9400821 	ldr	x1, [x1, #16]
    6ebc:	91000442 	add	x2, x2, #0x1
    6ec0:	b5ffffc1 	cbnz	x1, 6eb8 <f37+0xe4>
    6ec4:	eb00005f 	cmp	x2, x0
    6ec8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6ecc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6ed0:	eb01033f 	cmp	x25, x1
    6ed4:	54001468 	b.hi	7160 <f37+0x38c>  // b.pmore
    6ed8:	d37ffb33 	lsl	x19, x25, #1
    6edc:	52800041 	mov	w1, #0x2                   	// #2
    6ee0:	91000660 	add	x0, x19, #0x1
    6ee4:	d37df000 	lsl	x0, x0, #3
    6ee8:	97fff836 	bl	4fc0 <fwp_heap_alloc>
    6eec:	9117c2e1 	add	x1, x23, #0x5f0
    6ef0:	aa0003fa 	mov	x26, x0
    6ef4:	f9000013 	str	x19, [x0]
    6ef8:	aa0103e0 	mov	x0, x1
    6efc:	f949d821 	ldr	x1, [x1, #5040]
    6f00:	f949ec00 	ldr	x0, [x0, #5080]
    6f04:	cb010341 	sub	x1, x26, x1
    6f08:	eb00403f 	cmp	x1, x0, lsl #16
    6f0c:	54000342 	b.cs	6f74 <f37+0x1a0>  // b.hs, b.nlast
    6f10:	9117c2e2 	add	x2, x23, #0x5f0
    6f14:	d350fc20 	lsr	x0, x1, #16
    6f18:	8b000800 	add	x0, x0, x0, lsl #2
    6f1c:	f949fc43 	ldr	x3, [x2, #5112]
    6f20:	d37df002 	lsl	x2, x0, #3
    6f24:	8b020060 	add	x0, x3, x2
    6f28:	f9401013 	ldr	x19, [x0, #32]
    6f2c:	b4000253 	cbz	x19, 6f74 <f37+0x1a0>
    6f30:	38626862 	ldrb	w2, [x3, x2]
    6f34:	7100085f 	cmp	w2, #0x2
    6f38:	54000c00 	b.eq	70b8 <f37+0x2e4>  // b.none
    6f3c:	7100045f 	cmp	w2, #0x1
    6f40:	540001a1 	b.ne	6f74 <f37+0x1a0>  // b.any
    6f44:	29430002 	ldp	w2, w0, [x0, #24]
    6f48:	92403c21 	and	x1, x1, #0xffff
    6f4c:	9b027c21 	mul	x1, x1, x2
    6f50:	d360fc21 	lsr	x1, x1, #32
    6f54:	eb00003f 	cmp	x1, x0
    6f58:	540000e2 	b.cs	6f74 <f37+0x1a0>  // b.hs, b.nlast
    6f5c:	8b010273 	add	x19, x19, x1
    6f60:	39400260 	ldrb	w0, [x19]
    6f64:	7103fc1f 	cmp	w0, #0xff
    6f68:	54000da0 	b.eq	711c <f37+0x348>  // b.none
    6f6c:	52800020 	mov	w0, #0x1                   	// #1
    6f70:	39000260 	strb	w0, [x19]
    6f74:	b4000259 	cbz	x25, 6fbc <f37+0x1e8>
    6f78:	8b191359 	add	x25, x26, x25, lsl #4
    6f7c:	aa1a03f3 	mov	x19, x26
    6f80:	aa1603f5 	mov	x21, x22
    6f84:	aa1803f4 	mov	x20, x24
    6f88:	f9400683 	ldr	x3, [x20, #8]
    6f8c:	f94006a2 	ldr	x2, [x21, #8]
    6f90:	f9400861 	ldr	x1, [x3, #16]
    6f94:	f9400840 	ldr	x0, [x2, #16]
    6f98:	fd400461 	ldr	d1, [x3, #8]
    6f9c:	fd400440 	ldr	d0, [x2, #8]
    6fa0:	97fff948 	bl	54c0 <w120>
    6fa4:	f9000660 	str	x0, [x19, #8]
    6fa8:	f8010e61 	str	x1, [x19, #16]!
    6fac:	f9400a94 	ldr	x20, [x20, #16]
    6fb0:	f9400ab5 	ldr	x21, [x21, #16]
    6fb4:	eb13033f 	cmp	x25, x19
    6fb8:	54fffe81 	b.ne	6f88 <f37+0x1b4>  // b.any
    6fbc:	aa1803e0 	mov	x0, x24
    6fc0:	97fffcc4 	bl	62d0 <fwp_drop4>
    6fc4:	aa1603e0 	mov	x0, x22
    6fc8:	97fffcc2 	bl	62d0 <fwp_drop4>
    6fcc:	9117c2f7 	add	x23, x23, #0x5f0
    6fd0:	aa1a03e0 	mov	x0, x26
    6fd4:	97fff98f 	bl	5610 <w176.constprop.0>
    6fd8:	aa0103f3 	mov	x19, x1
    6fdc:	aa0003f4 	mov	x20, x0
    6fe0:	aa1a03e0 	mov	x0, x26
    6fe4:	97fffe57 	bl	6940 <fwp_drop10>
    6fe8:	a900cff4 	stp	x20, x19, [sp, #8]
    6fec:	910023e1 	add	x1, sp, #0x8
    6ff0:	52800000 	mov	w0, #0x0                   	// #0
    6ff4:	97fff838 	bl	50d4 <fwp_data.part.0.constprop.0>
    6ff8:	f949dae1 	ldr	x1, [x23, #5040]
    6ffc:	aa0003f3 	mov	x19, x0
    7000:	f949eee0 	ldr	x0, [x23, #5080]
    7004:	cb010261 	sub	x1, x19, x1
    7008:	eb00403f 	cmp	x1, x0, lsl #16
    700c:	54000322 	b.cs	7070 <f37+0x29c>  // b.hs, b.nlast
    7010:	d350fc22 	lsr	x2, x1, #16
    7014:	f949fee3 	ldr	x3, [x23, #5112]
    7018:	8b020842 	add	x2, x2, x2, lsl #2
    701c:	d37df042 	lsl	x2, x2, #3
    7020:	8b020060 	add	x0, x3, x2
    7024:	f9401014 	ldr	x20, [x0, #32]
    7028:	b4000254 	cbz	x20, 7070 <f37+0x29c>
    702c:	38626862 	ldrb	w2, [x3, x2]
    7030:	7100085f 	cmp	w2, #0x2
    7034:	540003c0 	b.eq	70ac <f37+0x2d8>  // b.none
    7038:	7100045f 	cmp	w2, #0x1
    703c:	540001a1 	b.ne	7070 <f37+0x29c>  // b.any
    7040:	29430002 	ldp	w2, w0, [x0, #24]
    7044:	92403c21 	and	x1, x1, #0xffff
    7048:	9b027c21 	mul	x1, x1, x2
    704c:	d360fc21 	lsr	x1, x1, #32
    7050:	eb00003f 	cmp	x1, x0
    7054:	540000e2 	b.cs	7070 <f37+0x29c>  // b.hs, b.nlast
    7058:	8b010294 	add	x20, x20, x1
    705c:	39400280 	ldrb	w0, [x20]
    7060:	7103fc1f 	cmp	w0, #0xff
    7064:	54000620 	b.eq	7128 <f37+0x354>  // b.none
    7068:	52800020 	mov	w0, #0x1                   	// #1
    706c:	39000280 	strb	w0, [x20]
    7070:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7074:	f947f400 	ldr	x0, [x0, #4072]
    7078:	f9400fe2 	ldr	x2, [sp, #24]
    707c:	f9400001 	ldr	x1, [x0]
    7080:	eb010042 	subs	x2, x2, x1
    7084:	d2800001 	mov	x1, #0x0                   	// #0
    7088:	540006a1 	b.ne	715c <f37+0x388>  // b.any
    708c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7090:	aa1303e0 	mov	x0, x19
    7094:	a94353f3 	ldp	x19, x20, [sp, #48]
    7098:	a9445bf5 	ldp	x21, x22, [sp, #64]
    709c:	a94563f7 	ldp	x23, x24, [sp, #80]
    70a0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    70a4:	9101c3ff 	add	sp, sp, #0x70
    70a8:	d65f03c0 	ret
    70ac:	72003c3f 	tst	w1, #0xffff
    70b0:	54fffe01 	b.ne	7070 <f37+0x29c>  // b.any
    70b4:	17ffffea 	b	705c <f37+0x288>
    70b8:	72003c3f 	tst	w1, #0xffff
    70bc:	54fff5c1 	b.ne	6f74 <f37+0x1a0>  // b.any
    70c0:	17ffffa8 	b	6f60 <f37+0x18c>
    70c4:	72003c3f 	tst	w1, #0xffff
    70c8:	54ffee41 	b.ne	6e90 <f37+0xbc>  // b.any
    70cc:	17ffff6b 	b	6e78 <f37+0xa4>
    70d0:	cb0103e1 	neg	x1, x1
    70d4:	eb02003f 	cmp	x1, x2
    70d8:	540002e3 	b.cc	7134 <f37+0x360>  // b.lo, b.ul, b.last
    70dc:	d503201f 	nop
    70e0:	52800041 	mov	w1, #0x2                   	// #2
    70e4:	d2800100 	mov	x0, #0x8                   	// #8
    70e8:	97fff7b6 	bl	4fc0 <fwp_heap_alloc>
    70ec:	aa0003e1 	mov	x1, x0
    70f0:	9117c2e0 	add	x0, x23, #0x5f0
    70f4:	aa0103fa 	mov	x26, x1
    70f8:	d2800018 	mov	x24, #0x0                   	// #0
    70fc:	f900003f 	str	xzr, [x1]
    7100:	f949d801 	ldr	x1, [x0, #5040]
    7104:	f949ec00 	ldr	x0, [x0, #5080]
    7108:	cb010341 	sub	x1, x26, x1
    710c:	eb00403f 	cmp	x1, x0, lsl #16
    7110:	54fff562 	b.cs	6fbc <f37+0x1e8>  // b.hs, b.nlast
    7114:	d2800019 	mov	x25, #0x0                   	// #0
    7118:	17ffff7e 	b	6f10 <f37+0x13c>
    711c:	aa1303e0 	mov	x0, x19
    7120:	97fff5e8 	bl	48c0 <fwp_rc_forget_slot>
    7124:	17ffff92 	b	6f6c <f37+0x198>
    7128:	aa1403e0 	mov	x0, x20
    712c:	97fff5e5 	bl	48c0 <fwp_rc_forget_slot>
    7130:	17ffffce 	b	7068 <f37+0x294>
    7134:	f949fc62 	ldr	x2, [x3, #5112]
    7138:	d350fc20 	lsr	x0, x1, #16
    713c:	8b000800 	add	x0, x0, x0, lsl #2
    7140:	8b000c42 	add	x2, x2, x0, lsl #3
    7144:	f9401040 	ldr	x0, [x2, #32]
    7148:	b4fffcc0 	cbz	x0, 70e0 <f37+0x30c>
    714c:	d2800018 	mov	x24, #0x0                   	// #0
    7150:	17ffff3e 	b	6e48 <f37+0x74>
    7154:	97fff594 	bl	47a4 <fwp_rc_wide_dup>
    7158:	17ffff4e 	b	6e90 <f37+0xbc>
    715c:	97ffeded 	bl	2910 <__stack_chk_fail@plt>
    7160:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    7164:	91120000 	add	x0, x0, #0x480
    7168:	97fff1c6 	bl	3880 <fwp_trap>
    716c:	d503201f 	nop

0000000000007170 <fwp_owned_entry37>:
    7170:	f9400000 	ldr	x0, [x0]
    7174:	17ffff18 	b	6dd4 <f37>
    7178:	d503201f 	nop
    717c:	d503201f 	nop

0000000000007180 <e37>:
    7180:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7184:	910003fd 	mov	x29, sp
    7188:	f9000bf3 	str	x19, [sp, #16]
    718c:	f9400013 	ldr	x19, [x0]
    7190:	aa1303e0 	mov	x0, x19
    7194:	97fff94b 	bl	56c0 <fwp_rc_share>
    7198:	aa1303e0 	mov	x0, x19
    719c:	97ffff0e 	bl	6dd4 <f37>
    71a0:	aa0003f3 	mov	x19, x0
    71a4:	97fff947 	bl	56c0 <fwp_rc_share>
    71a8:	aa1303e0 	mov	x0, x19
    71ac:	f9400bf3 	ldr	x19, [sp, #16]
    71b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71b4:	d65f03c0 	ret
    71b8:	d503201f 	nop
    71bc:	d503201f 	nop

00000000000071c0 <fwp_write>:
    71c0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    71c4:	910003fd 	mov	x29, sp
    71c8:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    71cc:	f947f484 	ldr	x4, [x4, #4072]
    71d0:	a90153f3 	stp	x19, x20, [sp, #16]
    71d4:	d10943ff 	sub	sp, sp, #0x250
    71d8:	b9400045 	ldr	w5, [x2]
    71dc:	aa0003f4 	mov	x20, x0
    71e0:	f9400080 	ldr	x0, [x4]
    71e4:	f90127e0 	str	x0, [sp, #584]
    71e8:	d2800000 	mov	x0, #0x0                   	// #0
    71ec:	710064bf 	cmp	w5, #0x19
    71f0:	54000408 	b.hi	7270 <fwp_write+0xb0>  // b.pmore
    71f4:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    71f8:	aa0103f3 	mov	x19, x1
    71fc:	91354000 	add	x0, x0, #0xd50
    7200:	f9013bf5 	str	x21, [sp, #624]
    7204:	f9013ff6 	str	x22, [sp, #632]
    7208:	f90153fb 	str	x27, [sp, #672]
    720c:	f90157fc 	str	x28, [sp, #680]
    7210:	aa0203fc 	mov	x28, x2
    7214:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7218:	10000061 	adr	x1, 7224 <fwp_write+0x64>
    721c:	8b20a820 	add	x0, x1, w0, sxth #2
    7220:	d61f0000 	br	x0
    7224:	910123e0 	add	x0, sp, #0x48
    7228:	aa1303e5 	mov	x5, x19
    722c:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0x20>
    7230:	aa0003f3 	mov	x19, x0
    7234:	91132084 	add	x4, x4, #0x4c8
    7238:	d2804003 	mov	x3, #0x200                 	// #512
    723c:	aa0303e1 	mov	x1, x3
    7240:	52800042 	mov	w2, #0x2                   	// #2
    7244:	97ffed8f 	bl	2880 <__snprintf_chk@plt>
    7248:	aa1303e0 	mov	x0, x19
    724c:	97ffed55 	bl	27a0 <strlen@plt>
    7250:	aa1303e1 	mov	x1, x19
    7254:	aa0003e2 	mov	x2, x0
    7258:	aa1403e0 	mov	x0, x20
    725c:	97fff0ed 	bl	3610 <buf_put>
    7260:	f9413bf5 	ldr	x21, [sp, #624]
    7264:	f9413ff6 	ldr	x22, [sp, #632]
    7268:	f94153fb 	ldr	x27, [sp, #672]
    726c:	f94157fc 	ldr	x28, [sp, #680]
    7270:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7274:	f947f400 	ldr	x0, [x0, #4072]
    7278:	f94127e2 	ldr	x2, [sp, #584]
    727c:	f9400001 	ldr	x1, [x0]
    7280:	eb010042 	subs	x2, x2, x1
    7284:	d2800001 	mov	x1, #0x0                   	// #0
    7288:	540077c1 	b.ne	8180 <fwp_write+0xfc0>  // b.any
    728c:	910943ff 	add	sp, sp, #0x250
    7290:	a94153f3 	ldp	x19, x20, [sp, #16]
    7294:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7298:	d65f03c0 	ret
    729c:	910123e0 	add	x0, sp, #0x48
    72a0:	aa1303e5 	mov	x5, x19
    72a4:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0x20>
    72a8:	aa0003f3 	mov	x19, x0
    72ac:	91130084 	add	x4, x4, #0x4c0
    72b0:	d2804003 	mov	x3, #0x200                 	// #512
    72b4:	17ffffe2 	b	723c <fwp_write+0x7c>
    72b8:	71004cbf 	cmp	w5, #0x13
    72bc:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    72c0:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    72c4:	9112c000 	add	x0, x0, #0x4b0
    72c8:	9112e021 	add	x1, x1, #0x4b8
    72cc:	d2800082 	mov	x2, #0x4                   	// #4
    72d0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    72d4:	aa1403e0 	mov	x0, x20
    72d8:	f90143f7 	str	x23, [sp, #640]
    72dc:	d2800016 	mov	x22, #0x0                   	// #0
    72e0:	f90147f8 	str	x24, [sp, #648]
    72e4:	97fff0cb 	bl	3610 <buf_put>
    72e8:	f9400260 	ldr	x0, [x19]
    72ec:	d0000037 	adrp	x23, d000 <_IO_stdin_used+0x20>
    72f0:	d2800015 	mov	x21, #0x0                   	// #0
    72f4:	9114e2f7 	add	x23, x23, #0x538
    72f8:	b40047a0 	cbz	x0, 7bec <fwp_write+0xa2c>
    72fc:	b9400380 	ldr	w0, [x28]
    7300:	52800003 	mov	w3, #0x0                   	// #0
    7304:	f9401f82 	ldr	x2, [x28, #56]
    7308:	71004c1f 	cmp	w0, #0x13
    730c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7310:	aa1403e0 	mov	x0, x20
    7314:	8b010e61 	add	x1, x19, x1, lsl #3
    7318:	f9400421 	ldr	x1, [x1, #8]
    731c:	97ffffa9 	bl	71c0 <fwp_write>
    7320:	b9400380 	ldr	w0, [x28]
    7324:	7100481f 	cmp	w0, #0x12
    7328:	54004b40 	b.eq	7c90 <fwp_write+0xad0>  // b.none
    732c:	f9400260 	ldr	x0, [x19]
    7330:	910006b5 	add	x21, x21, #0x1
    7334:	91000ad6 	add	x22, x22, #0x2
    7338:	eb15001f 	cmp	x0, x21
    733c:	54004589 	b.ls	7bec <fwp_write+0xa2c>  // b.plast
    7340:	aa1703e1 	mov	x1, x23
    7344:	aa1403e0 	mov	x0, x20
    7348:	d2800042 	mov	x2, #0x2                   	// #2
    734c:	97fff0b1 	bl	3610 <buf_put>
    7350:	17ffffeb 	b	72fc <fwp_write+0x13c>
    7354:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7358:	9113c021 	add	x1, x1, #0x4f0
    735c:	d28000c2 	mov	x2, #0x6                   	// #6
    7360:	aa1403e0 	mov	x0, x20
    7364:	91004273 	add	x19, x19, #0x10
    7368:	97fff0aa 	bl	3610 <buf_put>
    736c:	aa1303e0 	mov	x0, x19
    7370:	97ffed0c 	bl	27a0 <strlen@plt>
    7374:	aa1303e1 	mov	x1, x19
    7378:	aa0003e2 	mov	x2, x0
    737c:	aa1403e0 	mov	x0, x20
    7380:	97fff0a4 	bl	3610 <buf_put>
    7384:	528007c3 	mov	w3, #0x3e                  	// #62
    7388:	aa1403e0 	mov	x0, x20
    738c:	91001fe1 	add	x1, sp, #0x7
    7390:	d2800022 	mov	x2, #0x1                   	// #1
    7394:	39001fe3 	strb	w3, [sp, #7]
    7398:	17ffffb1 	b	725c <fwp_write+0x9c>
    739c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    73a0:	f947f400 	ldr	x0, [x0, #4072]
    73a4:	f94127e2 	ldr	x2, [sp, #584]
    73a8:	f9400001 	ldr	x1, [x0]
    73ac:	eb010042 	subs	x2, x2, x1
    73b0:	d2800001 	mov	x1, #0x0                   	// #0
    73b4:	540034e1 	b.ne	7a50 <fwp_write+0x890>  // b.any
    73b8:	f9413bf5 	ldr	x21, [sp, #624]
    73bc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    73c0:	f9413ff6 	ldr	x22, [sp, #632]
    73c4:	aa1403e0 	mov	x0, x20
    73c8:	91134021 	add	x1, x1, #0x4d0
    73cc:	d2800142 	mov	x2, #0xa                   	// #10
    73d0:	f94153fb 	ldr	x27, [sp, #672]
    73d4:	f94157fc 	ldr	x28, [sp, #680]
    73d8:	910943ff 	add	sp, sp, #0x250
    73dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    73e0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    73e4:	17fff08b 	b	3610 <buf_put>
    73e8:	f9400456 	ldr	x22, [x2, #8]
    73ec:	f90143f7 	str	x23, [sp, #640]
    73f0:	f90147f8 	str	x24, [sp, #648]
    73f4:	b4005b16 	cbz	x22, 7f54 <fwp_write+0xd94>
    73f8:	aa1603e0 	mov	x0, x22
    73fc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7400:	91154021 	add	x1, x1, #0x550
    7404:	97ffed63 	bl	2990 <strcmp@plt>
    7408:	2a0003f5 	mov	w21, w0
    740c:	34005fe0 	cbz	w0, 8008 <fwp_write+0xe48>
    7410:	aa1603e0 	mov	x0, x22
    7414:	97ffece3 	bl	27a0 <strlen@plt>
    7418:	aa1603e1 	mov	x1, x22
    741c:	aa0003e2 	mov	x2, x0
    7420:	aa1403e0 	mov	x0, x20
    7424:	97fff07b 	bl	3610 <buf_put>
    7428:	52800403 	mov	w3, #0x20                  	// #32
    742c:	91001ff5 	add	x21, sp, #0x7
    7430:	aa1503e1 	mov	x1, x21
    7434:	aa1403e0 	mov	x0, x20
    7438:	d2800022 	mov	x2, #0x1                   	// #1
    743c:	39001fe3 	strb	w3, [sp, #7]
    7440:	97fff074 	bl	3610 <buf_put>
    7444:	52800f63 	mov	w3, #0x7b                  	// #123
    7448:	aa1403e0 	mov	x0, x20
    744c:	aa1503e1 	mov	x1, x21
    7450:	d2800022 	mov	x2, #0x1                   	// #1
    7454:	39001fe3 	strb	w3, [sp, #7]
    7458:	97fff06e 	bl	3610 <buf_put>
    745c:	b9401380 	ldr	w0, [x28, #16]
    7460:	52800018 	mov	w24, #0x0                   	// #0
    7464:	7100001f 	cmp	w0, #0x0
    7468:	54003aad 	b.le	7bbc <fwp_write+0x9fc>
    746c:	f9014bf9 	str	x25, [sp, #656]
    7470:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x20>
    7474:	9115e339 	add	x25, x25, #0x578
    7478:	f9014ffa 	str	x26, [sp, #664]
    747c:	d000003a 	adrp	x26, d000 <_IO_stdin_used+0x20>
    7480:	9114e35a 	add	x26, x26, #0x538
    7484:	91002276 	add	x22, x19, #0x8
    7488:	d2800013 	mov	x19, #0x0                   	// #0
    748c:	b5003e93 	cbnz	x19, 7c5c <fwp_write+0xa9c>
    7490:	d37df277 	lsl	x23, x19, #3
    7494:	34003cb8 	cbz	w24, 7c28 <fwp_write+0xa68>
    7498:	f9401382 	ldr	x2, [x28, #32]
    749c:	aa1403e0 	mov	x0, x20
    74a0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    74a4:	52800003 	mov	w3, #0x0                   	// #0
    74a8:	f8776842 	ldr	x2, [x2, x23]
    74ac:	91000673 	add	x19, x19, #0x1
    74b0:	97ffff44 	bl	71c0 <fwp_write>
    74b4:	b9401380 	ldr	w0, [x28, #16]
    74b8:	6b13001f 	cmp	w0, w19
    74bc:	54fffe8c 	b.gt	748c <fwp_write+0x2cc>
    74c0:	f9414bf9 	ldr	x25, [sp, #656]
    74c4:	f9414ffa 	ldr	x26, [sp, #664]
    74c8:	340037b8 	cbz	w24, 7bbc <fwp_write+0x9fc>
    74cc:	52800523 	mov	w3, #0x29                  	// #41
    74d0:	aa1503e1 	mov	x1, x21
    74d4:	aa1403e0 	mov	x0, x20
    74d8:	d2800022 	mov	x2, #0x1                   	// #1
    74dc:	39001fe3 	strb	w3, [sp, #7]
    74e0:	97fff04c 	bl	3610 <buf_put>
    74e4:	f9413bf5 	ldr	x21, [sp, #624]
    74e8:	f9413ff6 	ldr	x22, [sp, #632]
    74ec:	f94143f7 	ldr	x23, [sp, #640]
    74f0:	f94147f8 	ldr	x24, [sp, #648]
    74f4:	f94153fb 	ldr	x27, [sp, #672]
    74f8:	f94157fc 	ldr	x28, [sp, #680]
    74fc:	17ffff5d 	b	7270 <fwp_write+0xb0>
    7500:	b9404855 	ldr	w21, [x2, #72]
    7504:	aa1403e0 	mov	x0, x20
    7508:	93407eb6 	sxtw	x22, w21
    750c:	91000ac1 	add	x1, x22, #0x2
    7510:	97fff00d 	bl	3544 <buf_grow>
    7514:	a9400281 	ldp	x1, x0, [x20]
    7518:	528e8603 	mov	w3, #0x7430                	// #29744
    751c:	78206823 	strh	w3, [x1, x0]
    7520:	8b000022 	add	x2, x1, x0
    7524:	710002bf 	cmp	w21, #0x0
    7528:	540036cd 	b.le	7c00 <fwp_write+0xa40>
    752c:	110006a3 	add	w3, w21, #0x1
    7530:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7534:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7538:	91000449 	add	x9, x2, #0x1
    753c:	8b23c043 	add	x3, x2, w3, sxtw
    7540:	f28aaac6 	movk	x6, #0x5556
    7544:	f2955568 	movk	x8, #0xaaab
    7548:	1400000d 	b	757c <fwp_write+0x3bc>
    754c:	d2800021 	mov	x1, #0x1                   	// #1
    7550:	528005a5 	mov	w5, #0x2d                  	// #45
    7554:	f100001f 	cmp	x0, #0x0
    7558:	9b467e60 	smulh	x0, x19, x6
    755c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7560:	381ff465 	strb	w5, [x3], #-1
    7564:	cb040000 	sub	x0, x0, x4
    7568:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    756c:	cb020000 	sub	x0, x0, x2
    7570:	8b010013 	add	x19, x0, x1
    7574:	eb03013f 	cmp	x9, x3
    7578:	54003440 	b.eq	7c00 <fwp_write+0xa40>  // b.none
    757c:	9b467e60 	smulh	x0, x19, x6
    7580:	937ffe64 	asr	x4, x19, #63
    7584:	52800605 	mov	w5, #0x30                  	// #48
    7588:	cb040000 	sub	x0, x0, x4
    758c:	8b000400 	add	x0, x0, x0, lsl #1
    7590:	cb000260 	sub	x0, x19, x0
    7594:	91000c01 	add	x1, x0, #0x3
    7598:	9bc87c22 	umulh	x2, x1, x8
    759c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    75a0:	8b4204e2 	add	x2, x7, x2, lsr #1
    75a4:	eb020021 	subs	x1, x1, x2
    75a8:	54fffd60 	b.eq	7554 <fwp_write+0x394>  // b.none
    75ac:	f100043f 	cmp	x1, #0x1
    75b0:	54fffce1 	b.ne	754c <fwp_write+0x38c>  // b.any
    75b4:	d2800001 	mov	x1, #0x0                   	// #0
    75b8:	52800565 	mov	w5, #0x2b                  	// #43
    75bc:	17ffffe6 	b	7554 <fwp_write+0x394>
    75c0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    75c4:	f947f400 	ldr	x0, [x0, #4072]
    75c8:	f94127e2 	ldr	x2, [sp, #584]
    75cc:	f9400001 	ldr	x1, [x0]
    75d0:	eb010042 	subs	x2, x2, x1
    75d4:	d2800001 	mov	x1, #0x0                   	// #0
    75d8:	540023c1 	b.ne	7a50 <fwp_write+0x890>  // b.any
    75dc:	f9413bf5 	ldr	x21, [sp, #624]
    75e0:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    75e4:	f9413ff6 	ldr	x22, [sp, #632]
    75e8:	aa1403e0 	mov	x0, x20
    75ec:	91138021 	add	x1, x1, #0x4e0
    75f0:	d2800102 	mov	x2, #0x8                   	// #8
    75f4:	17ffff77 	b	73d0 <fwp_write+0x210>
    75f8:	aa1403e0 	mov	x0, x20
    75fc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7600:	d28000c2 	mov	x2, #0x6                   	// #6
    7604:	91150021 	add	x1, x1, #0x540
    7608:	97fff002 	bl	3610 <buf_put>
    760c:	d2800015 	mov	x21, #0x0                   	// #0
    7610:	f9400263 	ldr	x3, [x19]
    7614:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7618:	54002c60 	b.eq	7ba4 <fwp_write+0x9e4>  // b.none
    761c:	f9401f82 	ldr	x2, [x28, #56]
    7620:	f90143f7 	str	x23, [sp, #640]
    7624:	f90147f8 	str	x24, [sp, #648]
    7628:	d2800857 	mov	x23, #0x42                  	// #66
    762c:	f9014bf9 	str	x25, [sp, #656]
    7630:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0x20>
    7634:	f9014ffa 	str	x26, [sp, #664]
    7638:	9114e2d6 	add	x22, x22, #0x538
    763c:	d2800038 	mov	x24, #0x1                   	// #1
    7640:	f2a18017 	movk	x23, #0xc00, lsl #16
    7644:	d2809099 	mov	x25, #0x484                 	// #1156
    7648:	b40004a2 	cbz	x2, 76dc <fwp_write+0x51c>
    764c:	b9400040 	ldr	w0, [x2]
    7650:	7100701f 	cmp	w0, #0x1c
    7654:	540042c0 	b.eq	7eac <fwp_write+0xcec>  // b.none
    7658:	71006c1f 	cmp	w0, #0x1b
    765c:	54000408 	b.hi	76dc <fwp_write+0x51c>  // b.pmore
    7660:	9ac02301 	lsl	x1, x24, x0
    7664:	ea17003f 	tst	x1, x23
    7668:	540036a1 	b.ne	7d3c <fwp_write+0xb7c>  // b.any
    766c:	ea19003f 	tst	x1, x25
    7670:	54003521 	b.ne	7d14 <fwp_write+0xb54>  // b.any
    7674:	d2800424 	mov	x4, #0x21                  	// #33
    7678:	ea04003f 	tst	x1, x4
    767c:	54000300 	b.eq	76dc <fwp_write+0x51c>  // b.none
    7680:	b7f849c3 	tbnz	x3, #63, 7fb8 <fwp_write+0xdf8>
    7684:	91002261 	add	x1, x19, #0x8
    7688:	8b150021 	add	x1, x1, x21
    768c:	39400021 	ldrb	w1, [x1]
    7690:	7100001f 	cmp	w0, #0x0
    7694:	93401c23 	sxtb	x3, w1
    7698:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    769c:	d503201f 	nop
    76a0:	aa1403e0 	mov	x0, x20
    76a4:	52800003 	mov	w3, #0x0                   	// #0
    76a8:	97fffec6 	bl	71c0 <fwp_write>
    76ac:	910006b5 	add	x21, x21, #0x1
    76b0:	f9400260 	ldr	x0, [x19]
    76b4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    76b8:	eb0002bf 	cmp	x21, x0
    76bc:	540026c2 	b.cs	7b94 <fwp_write+0x9d4>  // b.hs, b.nlast
    76c0:	d2800042 	mov	x2, #0x2                   	// #2
    76c4:	aa1603e1 	mov	x1, x22
    76c8:	aa1403e0 	mov	x0, x20
    76cc:	97ffefd1 	bl	3610 <buf_put>
    76d0:	f9401f82 	ldr	x2, [x28, #56]
    76d4:	f9400263 	ldr	x3, [x19]
    76d8:	b5fffba2 	cbnz	x2, 764c <fwp_write+0x48c>
    76dc:	d37df2a0 	lsl	x0, x21, #3
    76e0:	b7f83f03 	tbnz	x3, #63, 7ec0 <fwp_write+0xd00>
    76e4:	91002261 	add	x1, x19, #0x8
    76e8:	8b000020 	add	x0, x1, x0
    76ec:	f9400001 	ldr	x1, [x0]
    76f0:	17ffffec 	b	76a0 <fwp_write+0x4e0>
    76f4:	a9400e62 	ldp	x2, x3, [x19]
    76f8:	b7f83ca3 	tbnz	x3, #63, 7e8c <fwp_write+0xccc>
    76fc:	910123f5 	add	x21, sp, #0x48
    7700:	aa1503e0 	mov	x0, x21
    7704:	97ffede7 	bl	2ea0 <fwp_fmt_u128>
    7708:	aa1503e0 	mov	x0, x21
    770c:	97ffec25 	bl	27a0 <strlen@plt>
    7710:	aa1503e1 	mov	x1, x21
    7714:	aa0003e2 	mov	x2, x0
    7718:	17fffed0 	b	7258 <fwp_write+0x98>
    771c:	fd015be8 	str	d8, [sp, #688]
    7720:	1e270268 	fmov	s8, w19
    7724:	fd015fe9 	str	d9, [sp, #696]
    7728:	1e282100 	fcmp	s8, s8
    772c:	54004d26 	b.vs	80d0 <fwp_write+0xf10>
    7730:	1e20c101 	fabs	s1, s8
    7734:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7738:	1e270000 	fmov	s0, w0
    773c:	1e202020 	fcmp	s1, s0
    7740:	54002c0d 	b.le	7cc0 <fwp_write+0xb00>
    7744:	1e202118 	fcmpe	s8, #0.0
    7748:	d0000022 	adrp	x2, d000 <_IO_stdin_used+0x20>
    774c:	9102e042 	add	x2, x2, #0xb8
    7750:	910123f5 	add	x21, sp, #0x48
    7754:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7758:	91124021 	add	x1, x1, #0x490
    775c:	aa1503e0 	mov	x0, x21
    7760:	9a81c041 	csel	x1, x2, x1, gt
    7764:	97ffecbb 	bl	2a50 <strcpy@plt>
    7768:	aa1503e0 	mov	x0, x21
    776c:	97ffec0d 	bl	27a0 <strlen@plt>
    7770:	aa1503e1 	mov	x1, x21
    7774:	aa0003e2 	mov	x2, x0
    7778:	aa1403e0 	mov	x0, x20
    777c:	97ffefa5 	bl	3610 <buf_put>
    7780:	f9413bf5 	ldr	x21, [sp, #624]
    7784:	f9413ff6 	ldr	x22, [sp, #632]
    7788:	f94153fb 	ldr	x27, [sp, #672]
    778c:	f94157fc 	ldr	x28, [sp, #680]
    7790:	fd415be8 	ldr	d8, [sp, #688]
    7794:	fd415fe9 	ldr	d9, [sp, #696]
    7798:	17fffeb6 	b	7270 <fwp_write+0xb0>
    779c:	f9400276 	ldr	x22, [x19]
    77a0:	34002e03 	cbz	w3, 7d60 <fwp_write+0xba0>
    77a4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    77a8:	f947f400 	ldr	x0, [x0, #4072]
    77ac:	f94127e2 	ldr	x2, [sp, #584]
    77b0:	f9400001 	ldr	x1, [x0]
    77b4:	eb010042 	subs	x2, x2, x1
    77b8:	d2800001 	mov	x1, #0x0                   	// #0
    77bc:	540014a1 	b.ne	7a50 <fwp_write+0x890>  // b.any
    77c0:	aa1603e2 	mov	x2, x22
    77c4:	91002261 	add	x1, x19, #0x8
    77c8:	f9413bf5 	ldr	x21, [sp, #624]
    77cc:	aa1403e0 	mov	x0, x20
    77d0:	f9413ff6 	ldr	x22, [sp, #632]
    77d4:	17fffeff 	b	73d0 <fwp_write+0x210>
    77d8:	fd015be8 	str	d8, [sp, #688]
    77dc:	9e670268 	fmov	d8, x19
    77e0:	fd015fe9 	str	d9, [sp, #696]
    77e4:	1e682100 	fcmp	d8, d8
    77e8:	54004746 	b.vs	80d0 <fwp_write+0xf10>
    77ec:	1e60c101 	fabs	d1, d8
    77f0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    77f4:	9e670000 	fmov	d0, x0
    77f8:	910123f5 	add	x21, sp, #0x48
    77fc:	52800033 	mov	w19, #0x1                   	// #1
    7800:	1e602020 	fcmp	d1, d0
    7804:	540001ad 	b.le	7838 <fwp_write+0x678>
    7808:	1e602118 	fcmpe	d8, #0.0
    780c:	d0000022 	adrp	x2, d000 <_IO_stdin_used+0x20>
    7810:	9102e042 	add	x2, x2, #0xb8
    7814:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7818:	91124021 	add	x1, x1, #0x490
    781c:	aa1503e0 	mov	x0, x21
    7820:	9a81c041 	csel	x1, x2, x1, gt
    7824:	97ffec8b 	bl	2a50 <strcpy@plt>
    7828:	17ffffd0 	b	7768 <fwp_write+0x5a8>
    782c:	11000673 	add	w19, w19, #0x1
    7830:	71004a7f 	cmp	w19, #0x12
    7834:	54003860 	b.eq	7f40 <fwp_write+0xd80>  // b.none
    7838:	1e604100 	fmov	d0, d8
    783c:	2a1303e1 	mov	w1, w19
    7840:	aa1503e0 	mov	x0, x21
    7844:	97fff0f4 	bl	3c14 <fwp_format_g.constprop.0>
    7848:	aa1503e0 	mov	x0, x21
    784c:	d2800001 	mov	x1, #0x0                   	// #0
    7850:	97ffebe8 	bl	27f0 <strtod@plt>
    7854:	1e602100 	fcmp	d8, d0
    7858:	54fffea1 	b.ne	782c <fwp_write+0x66c>  // b.any
    785c:	aa1503e0 	mov	x0, x21
    7860:	97ffefe5 	bl	37f4 <fwp_finish_float>
    7864:	17ffffc1 	b	7768 <fwp_write+0x5a8>
    7868:	a9400e62 	ldp	x2, x3, [x19]
    786c:	910123f3 	add	x19, sp, #0x48
    7870:	aa1303e0 	mov	x0, x19
    7874:	97ffed8b 	bl	2ea0 <fwp_fmt_u128>
    7878:	17fffe74 	b	7248 <fwp_write+0x88>
    787c:	f90143f7 	str	x23, [sp, #640]
    7880:	f90147f8 	str	x24, [sp, #648]
    7884:	2a1303f8 	mov	w24, w19
    7888:	f9014bf9 	str	x25, [sp, #656]
    788c:	f9014ffa 	str	x26, [sp, #664]
    7890:	f13ffe7f 	cmp	x19, #0xfff
    7894:	54000049 	b.ls	789c <fwp_write+0x6dc>  // b.plast
    7898:	b9400278 	ldr	w24, [x19]
    789c:	f9400f80 	ldr	x0, [x28, #24]
    78a0:	2a1803f5 	mov	w21, w24
    78a4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    78a8:	d37ef6b9 	lsl	x25, x21, #2
    78ac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    78b0:	aa1603e0 	mov	x0, x22
    78b4:	97ffebbb 	bl	27a0 <strlen@plt>
    78b8:	aa1603e1 	mov	x1, x22
    78bc:	aa0003e2 	mov	x2, x0
    78c0:	aa1403e0 	mov	x0, x20
    78c4:	97ffef53 	bl	3610 <buf_put>
    78c8:	f9401780 	ldr	x0, [x28, #40]
    78cc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    78d0:	7100001f 	cmp	w0, #0x0
    78d4:	5400068d 	b.le	79a4 <fwp_write+0x7e4>
    78d8:	91002276 	add	x22, x19, #0x8
    78dc:	91001ff5 	add	x21, sp, #0x7
    78e0:	d280001b 	mov	x27, #0x0                   	// #0
    78e4:	5280041a 	mov	w26, #0x20                  	// #32
    78e8:	f9401b80 	ldr	x0, [x28, #48]
    78ec:	aa1503e1 	mov	x1, x21
    78f0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    78f4:	d2800022 	mov	x2, #0x1                   	// #1
    78f8:	f8786803 	ldr	x3, [x0, x24]
    78fc:	aa1403e0 	mov	x0, x20
    7900:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7904:	39001ffa 	strb	w26, [sp, #7]
    7908:	97ffef42 	bl	3610 <buf_put>
    790c:	f13ffeff 	cmp	x23, #0xfff
    7910:	b9400261 	ldr	w1, [x19]
    7914:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7918:	7100383f 	cmp	w1, #0xe
    791c:	54000160 	b.eq	7948 <fwp_write+0x788>  // b.none
    7920:	7100403f 	cmp	w1, #0x10
    7924:	54001a60 	b.eq	7c70 <fwp_write+0xab0>  // b.none
    7928:	7100283f 	cmp	w1, #0xa
    792c:	54002aa0 	b.eq	7e80 <fwp_write+0xcc0>  // b.none
    7930:	540014ac 	b.gt	7bc4 <fwp_write+0xa04>
    7934:	71000c3f 	cmp	w1, #0x3
    7938:	540029ac 	b.gt	7e6c <fwp_write+0xcac>
    793c:	d37ffee0 	lsr	x0, x23, #63
    7940:	37f814a1 	tbnz	w1, #31, 7bd4 <fwp_write+0xa14>
    7944:	d503201f 	nop
    7948:	34001460 	cbz	w0, 7bd4 <fwp_write+0xa14>
    794c:	52800503 	mov	w3, #0x28                  	// #40
    7950:	aa1503e1 	mov	x1, x21
    7954:	aa1403e0 	mov	x0, x20
    7958:	d2800022 	mov	x2, #0x1                   	// #1
    795c:	39001fe3 	strb	w3, [sp, #7]
    7960:	97ffef2c 	bl	3610 <buf_put>
    7964:	aa1303e2 	mov	x2, x19
    7968:	aa1703e1 	mov	x1, x23
    796c:	aa1403e0 	mov	x0, x20
    7970:	52800003 	mov	w3, #0x0                   	// #0
    7974:	97fffe13 	bl	71c0 <fwp_write>
    7978:	52800523 	mov	w3, #0x29                  	// #41
    797c:	aa1503e1 	mov	x1, x21
    7980:	aa1403e0 	mov	x0, x20
    7984:	d2800022 	mov	x2, #0x1                   	// #1
    7988:	39001fe3 	strb	w3, [sp, #7]
    798c:	97ffef21 	bl	3610 <buf_put>
    7990:	f9401780 	ldr	x0, [x28, #40]
    7994:	9100077b 	add	x27, x27, #0x1
    7998:	b8796800 	ldr	w0, [x0, x25]
    799c:	6b1b001f 	cmp	w0, w27
    79a0:	54fffa4c 	b.gt	78e8 <fwp_write+0x728>
    79a4:	f9413bf5 	ldr	x21, [sp, #624]
    79a8:	f9413ff6 	ldr	x22, [sp, #632]
    79ac:	f94143f7 	ldr	x23, [sp, #640]
    79b0:	f94147f8 	ldr	x24, [sp, #648]
    79b4:	f9414bf9 	ldr	x25, [sp, #656]
    79b8:	f9414ffa 	ldr	x26, [sp, #664]
    79bc:	f94153fb 	ldr	x27, [sp, #672]
    79c0:	f94157fc 	ldr	x28, [sp, #680]
    79c4:	17fffe2b 	b	7270 <fwp_write+0xb0>
    79c8:	52800783 	mov	w3, #0x3c                  	// #60
    79cc:	91001ff3 	add	x19, sp, #0x7
    79d0:	aa1303e1 	mov	x1, x19
    79d4:	d2800022 	mov	x2, #0x1                   	// #1
    79d8:	aa1403e0 	mov	x0, x20
    79dc:	39001fe3 	strb	w3, [sp, #7]
    79e0:	97ffef0c 	bl	3610 <buf_put>
    79e4:	f9400795 	ldr	x21, [x28, #8]
    79e8:	aa1503e0 	mov	x0, x21
    79ec:	97ffeb6d 	bl	27a0 <strlen@plt>
    79f0:	aa1503e1 	mov	x1, x21
    79f4:	aa0003e2 	mov	x2, x0
    79f8:	aa1403e0 	mov	x0, x20
    79fc:	97ffef05 	bl	3610 <buf_put>
    7a00:	528007c3 	mov	w3, #0x3e                  	// #62
    7a04:	aa1303e1 	mov	x1, x19
    7a08:	aa1403e0 	mov	x0, x20
    7a0c:	d2800022 	mov	x2, #0x1                   	// #1
    7a10:	39001fe3 	strb	w3, [sp, #7]
    7a14:	17fffe12 	b	725c <fwp_write+0x9c>
    7a18:	f100067f 	cmp	x19, #0x1
    7a1c:	540025a0 	b.eq	7ed0 <fwp_write+0xd10>  // b.none
    7a20:	b100067f 	cmn	x19, #0x1
    7a24:	54002bc0 	b.eq	7f9c <fwp_write+0xddc>  // b.none
    7a28:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7a2c:	91126021 	add	x1, x1, #0x498
    7a30:	d2800022 	mov	x2, #0x1                   	// #1
    7a34:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7a38:	f947f400 	ldr	x0, [x0, #4072]
    7a3c:	f94127e4 	ldr	x4, [sp, #584]
    7a40:	f9400003 	ldr	x3, [x0]
    7a44:	eb030084 	subs	x4, x4, x3
    7a48:	d2800003 	mov	x3, #0x0                   	// #0
    7a4c:	54ffebe0 	b.eq	77c8 <fwp_write+0x608>  // b.none
    7a50:	f90143f7 	str	x23, [sp, #640]
    7a54:	f90147f8 	str	x24, [sp, #648]
    7a58:	f9014bf9 	str	x25, [sp, #656]
    7a5c:	f9014ffa 	str	x26, [sp, #664]
    7a60:	fd015be8 	str	d8, [sp, #688]
    7a64:	fd015fe9 	str	d9, [sp, #696]
    7a68:	97ffebaa 	bl	2910 <__stack_chk_fail@plt>
    7a6c:	52800b63 	mov	w3, #0x5b                  	// #91
    7a70:	91001ff5 	add	x21, sp, #0x7
    7a74:	aa1503e1 	mov	x1, x21
    7a78:	aa1403e0 	mov	x0, x20
    7a7c:	d2800022 	mov	x2, #0x1                   	// #1
    7a80:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0x20>
    7a84:	9114e2d6 	add	x22, x22, #0x538
    7a88:	39001fe3 	strb	w3, [sp, #7]
    7a8c:	97ffeee1 	bl	3610 <buf_put>
    7a90:	b4000273 	cbz	x19, 7adc <fwp_write+0x91c>
    7a94:	f9400661 	ldr	x1, [x19, #8]
    7a98:	aa1403e0 	mov	x0, x20
    7a9c:	f9401f82 	ldr	x2, [x28, #56]
    7aa0:	52800003 	mov	w3, #0x0                   	// #0
    7aa4:	97fffdc7 	bl	71c0 <fwp_write>
    7aa8:	f9400a73 	ldr	x19, [x19, #16]
    7aac:	b4000193 	cbz	x19, 7adc <fwp_write+0x91c>
    7ab0:	aa1603e1 	mov	x1, x22
    7ab4:	aa1403e0 	mov	x0, x20
    7ab8:	d2800042 	mov	x2, #0x2                   	// #2
    7abc:	97ffeed5 	bl	3610 <buf_put>
    7ac0:	f9400661 	ldr	x1, [x19, #8]
    7ac4:	aa1403e0 	mov	x0, x20
    7ac8:	f9401f82 	ldr	x2, [x28, #56]
    7acc:	52800003 	mov	w3, #0x0                   	// #0
    7ad0:	97fffdbc 	bl	71c0 <fwp_write>
    7ad4:	f9400a73 	ldr	x19, [x19, #16]
    7ad8:	b5fffed3 	cbnz	x19, 7ab0 <fwp_write+0x8f0>
    7adc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ae0:	aa1503e1 	mov	x1, x21
    7ae4:	aa1403e0 	mov	x0, x20
    7ae8:	d2800022 	mov	x2, #0x1                   	// #1
    7aec:	39001fe3 	strb	w3, [sp, #7]
    7af0:	17fffddb 	b	725c <fwp_write+0x9c>
    7af4:	aa1403e0 	mov	x0, x20
    7af8:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7afc:	d28000c2 	mov	x2, #0x6                   	// #6
    7b00:	9114a021 	add	x1, x1, #0x528
    7b04:	97ffeec3 	bl	3610 <buf_put>
    7b08:	f9400260 	ldr	x0, [x19]
    7b0c:	b40004c0 	cbz	x0, 7ba4 <fwp_write+0x9e4>
    7b10:	910123f5 	add	x21, sp, #0x48
    7b14:	91002276 	add	x22, x19, #0x8
    7b18:	f90143f7 	str	x23, [sp, #640]
    7b1c:	d2800017 	mov	x23, #0x0                   	// #0
    7b20:	f90147f8 	str	x24, [sp, #648]
    7b24:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0x20>
    7b28:	9114c318 	add	x24, x24, #0x530
    7b2c:	f9014bf9 	str	x25, [sp, #656]
    7b30:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x20>
    7b34:	9114e339 	add	x25, x25, #0x538
    7b38:	f9014ffa 	str	x26, [sp, #664]
    7b3c:	14000005 	b	7b50 <fwp_write+0x990>
    7b40:	aa1903e1 	mov	x1, x25
    7b44:	aa1403e0 	mov	x0, x20
    7b48:	d2800042 	mov	x2, #0x2                   	// #2
    7b4c:	97ffeeb1 	bl	3610 <buf_put>
    7b50:	38776ac5 	ldrb	w5, [x22, x23]
    7b54:	d2804003 	mov	x3, #0x200                 	// #512
    7b58:	aa1803e4 	mov	x4, x24
    7b5c:	aa0303e1 	mov	x1, x3
    7b60:	52800042 	mov	w2, #0x2                   	// #2
    7b64:	aa1503e0 	mov	x0, x21
    7b68:	910006f7 	add	x23, x23, #0x1
    7b6c:	97ffeb45 	bl	2880 <__snprintf_chk@plt>
    7b70:	aa1503e0 	mov	x0, x21
    7b74:	97ffeb0b 	bl	27a0 <strlen@plt>
    7b78:	aa1503e1 	mov	x1, x21
    7b7c:	aa0003e2 	mov	x2, x0
    7b80:	aa1403e0 	mov	x0, x20
    7b84:	97ffeea3 	bl	3610 <buf_put>
    7b88:	f9400260 	ldr	x0, [x19]
    7b8c:	eb17001f 	cmp	x0, x23
    7b90:	54fffd88 	b.hi	7b40 <fwp_write+0x980>  // b.pmore
    7b94:	f94143f7 	ldr	x23, [sp, #640]
    7b98:	f94147f8 	ldr	x24, [sp, #648]
    7b9c:	f9414bf9 	ldr	x25, [sp, #656]
    7ba0:	f9414ffa 	ldr	x26, [sp, #664]
    7ba4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ba8:	aa1403e0 	mov	x0, x20
    7bac:	91001fe1 	add	x1, sp, #0x7
    7bb0:	d2800022 	mov	x2, #0x1                   	// #1
    7bb4:	39001fe3 	strb	w3, [sp, #7]
    7bb8:	17fffda9 	b	725c <fwp_write+0x9c>
    7bbc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7bc0:	17fffe44 	b	74d0 <fwp_write+0x310>
    7bc4:	f10002ff 	cmp	x23, #0x0
    7bc8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7bcc:	71002c3f 	cmp	w1, #0xb
    7bd0:	54ffebc0 	b.eq	7948 <fwp_write+0x788>  // b.none
    7bd4:	aa1303e2 	mov	x2, x19
    7bd8:	aa1703e1 	mov	x1, x23
    7bdc:	aa1403e0 	mov	x0, x20
    7be0:	52800003 	mov	w3, #0x0                   	// #0
    7be4:	97fffd77 	bl	71c0 <fwp_write>
    7be8:	17ffff6a 	b	7990 <fwp_write+0x7d0>
    7bec:	aa1403e0 	mov	x0, x20
    7bf0:	91001fe1 	add	x1, sp, #0x7
    7bf4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7bf8:	d2800022 	mov	x2, #0x1                   	// #1
    7bfc:	17fffe38 	b	74dc <fwp_write+0x31c>
    7c00:	a9400281 	ldp	x1, x0, [x20]
    7c04:	91000800 	add	x0, x0, #0x2
    7c08:	8b160000 	add	x0, x0, x22
    7c0c:	f9000680 	str	x0, [x20, #8]
    7c10:	3820683f 	strb	wzr, [x1, x0]
    7c14:	f9413bf5 	ldr	x21, [sp, #624]
    7c18:	f9413ff6 	ldr	x22, [sp, #632]
    7c1c:	f94153fb 	ldr	x27, [sp, #672]
    7c20:	f94157fc 	ldr	x28, [sp, #680]
    7c24:	17fffd93 	b	7270 <fwp_write+0xb0>
    7c28:	f9400f80 	ldr	x0, [x28, #24]
    7c2c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7c30:	aa1b03e0 	mov	x0, x27
    7c34:	97ffeadb 	bl	27a0 <strlen@plt>
    7c38:	aa1b03e1 	mov	x1, x27
    7c3c:	aa0003e2 	mov	x2, x0
    7c40:	aa1403e0 	mov	x0, x20
    7c44:	97ffee73 	bl	3610 <buf_put>
    7c48:	aa1903e1 	mov	x1, x25
    7c4c:	aa1403e0 	mov	x0, x20
    7c50:	d2800062 	mov	x2, #0x3                   	// #3
    7c54:	97ffee6f 	bl	3610 <buf_put>
    7c58:	17fffe10 	b	7498 <fwp_write+0x2d8>
    7c5c:	aa1a03e1 	mov	x1, x26
    7c60:	aa1403e0 	mov	x0, x20
    7c64:	d2800042 	mov	x2, #0x2                   	// #2
    7c68:	97ffee6a 	bl	3610 <buf_put>
    7c6c:	17fffe09 	b	7490 <fwp_write+0x2d0>
    7c70:	f9400660 	ldr	x0, [x19, #8]
    7c74:	b4fffb00 	cbz	x0, 7bd4 <fwp_write+0xa14>
    7c78:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7c7c:	91154021 	add	x1, x1, #0x550
    7c80:	97ffeb44 	bl	2990 <strcmp@plt>
    7c84:	7100001f 	cmp	w0, #0x0
    7c88:	1a9f07e0 	cset	w0, ne	// ne = any
    7c8c:	17ffff2f 	b	7948 <fwp_write+0x788>
    7c90:	aa1403e0 	mov	x0, x20
    7c94:	d2800042 	mov	x2, #0x2                   	// #2
    7c98:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7c9c:	91152021 	add	x1, x1, #0x548
    7ca0:	97ffee5c 	bl	3610 <buf_put>
    7ca4:	91004261 	add	x1, x19, #0x10
    7ca8:	aa1403e0 	mov	x0, x20
    7cac:	f9402382 	ldr	x2, [x28, #64]
    7cb0:	52800003 	mov	w3, #0x0                   	// #0
    7cb4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7cb8:	97fffd42 	bl	71c0 <fwp_write>
    7cbc:	17fffd9c 	b	732c <fwp_write+0x16c>
    7cc0:	1e22c109 	fcvt	d9, s8
    7cc4:	910123f5 	add	x21, sp, #0x48
    7cc8:	52800033 	mov	w19, #0x1                   	// #1
    7ccc:	d503201f 	nop
    7cd0:	1e604120 	fmov	d0, d9
    7cd4:	2a1303e1 	mov	w1, w19
    7cd8:	aa1503e0 	mov	x0, x21
    7cdc:	97ffefce 	bl	3c14 <fwp_format_g.constprop.0>
    7ce0:	aa1503e0 	mov	x0, x21
    7ce4:	d2800001 	mov	x1, #0x0                   	// #0
    7ce8:	97ffeb36 	bl	29c0 <strtof@plt>
    7cec:	1e202100 	fcmp	s8, s0
    7cf0:	54ffdb60 	b.eq	785c <fwp_write+0x69c>  // b.none
    7cf4:	11000673 	add	w19, w19, #0x1
    7cf8:	71002a7f 	cmp	w19, #0xa
    7cfc:	54fffea1 	b.ne	7cd0 <fwp_write+0xb10>  // b.any
    7d00:	1e604120 	fmov	d0, d9
    7d04:	aa1503e0 	mov	x0, x21
    7d08:	52800121 	mov	w1, #0x9                   	// #9
    7d0c:	97ffefc2 	bl	3c14 <fwp_format_g.constprop.0>
    7d10:	17fffed3 	b	785c <fwp_write+0x69c>
    7d14:	d37ef6a1 	lsl	x1, x21, #2
    7d18:	b7f81563 	tbnz	x3, #63, 7fc4 <fwp_write+0xe04>
    7d1c:	91002263 	add	x3, x19, #0x8
    7d20:	8b010061 	add	x1, x3, x1
    7d24:	b9400023 	ldr	w3, [x1]
    7d28:	7100081f 	cmp	w0, #0x2
    7d2c:	2a0303e1 	mov	w1, w3
    7d30:	93407c63 	sxtw	x3, w3
    7d34:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7d38:	17fffe5a 	b	76a0 <fwp_write+0x4e0>
    7d3c:	d37ffaa1 	lsl	x1, x21, #1
    7d40:	b7f81363 	tbnz	x3, #63, 7fac <fwp_write+0xdec>
    7d44:	91002263 	add	x3, x19, #0x8
    7d48:	8b010061 	add	x1, x3, x1
    7d4c:	79400021 	ldrh	w1, [x1]
    7d50:	7100041f 	cmp	w0, #0x1
    7d54:	93403c23 	sxth	x3, w1
    7d58:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7d5c:	17fffe51 	b	76a0 <fwp_write+0x4e0>
    7d60:	52800443 	mov	w3, #0x22                  	// #34
    7d64:	91001ff5 	add	x21, sp, #0x7
    7d68:	91002273 	add	x19, x19, #0x8
    7d6c:	aa1503e1 	mov	x1, x21
    7d70:	aa1403e0 	mov	x0, x20
    7d74:	d2800022 	mov	x2, #0x1                   	// #1
    7d78:	39001fe3 	strb	w3, [sp, #7]
    7d7c:	f90143f7 	str	x23, [sp, #640]
    7d80:	8b160277 	add	x23, x19, x22
    7d84:	f90147f8 	str	x24, [sp, #648]
    7d88:	97ffee22 	bl	3610 <buf_put>
    7d8c:	b4000696 	cbz	x22, 7e5c <fwp_write+0xc9c>
    7d90:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0x20>
    7d94:	9113e318 	add	x24, x24, #0x4f8
    7d98:	f9014bf9 	str	x25, [sp, #656]
    7d9c:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x20>
    7da0:	91146339 	add	x25, x25, #0x518
    7da4:	f9014ffa 	str	x26, [sp, #664]
    7da8:	1400000d 	b	7ddc <fwp_write+0xc1c>
    7dac:	710024bf 	cmp	w5, #0x9
    7db0:	54000460 	b.eq	7e3c <fwp_write+0xc7c>  // b.none
    7db4:	710028bf 	cmp	w5, #0xa
    7db8:	54000a61 	b.ne	7f04 <fwp_write+0xd44>  // b.any
    7dbc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7dc0:	aa1403e0 	mov	x0, x20
    7dc4:	91142021 	add	x1, x1, #0x508
    7dc8:	d2800042 	mov	x2, #0x2                   	// #2
    7dcc:	97ffee11 	bl	3610 <buf_put>
    7dd0:	91000673 	add	x19, x19, #0x1
    7dd4:	eb17027f 	cmp	x19, x23
    7dd8:	540003e0 	b.eq	7e54 <fwp_write+0xc94>  // b.none
    7ddc:	39400265 	ldrb	w5, [x19]
    7de0:	710034bf 	cmp	w5, #0xd
    7de4:	54000180 	b.eq	7e14 <fwp_write+0xc54>  // b.none
    7de8:	54fffe29 	b.ls	7dac <fwp_write+0xbec>  // b.plast
    7dec:	710088bf 	cmp	w5, #0x22
    7df0:	540001c0 	b.eq	7e28 <fwp_write+0xc68>  // b.none
    7df4:	710170bf 	cmp	w5, #0x5c
    7df8:	54000741 	b.ne	7ee0 <fwp_write+0xd20>  // b.any
    7dfc:	aa1403e0 	mov	x0, x20
    7e00:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7e04:	d2800042 	mov	x2, #0x2                   	// #2
    7e08:	91140021 	add	x1, x1, #0x500
    7e0c:	97ffee01 	bl	3610 <buf_put>
    7e10:	17fffff0 	b	7dd0 <fwp_write+0xc10>
    7e14:	aa1903e1 	mov	x1, x25
    7e18:	aa1403e0 	mov	x0, x20
    7e1c:	d2800042 	mov	x2, #0x2                   	// #2
    7e20:	97ffedfc 	bl	3610 <buf_put>
    7e24:	17ffffeb 	b	7dd0 <fwp_write+0xc10>
    7e28:	aa1803e1 	mov	x1, x24
    7e2c:	aa1403e0 	mov	x0, x20
    7e30:	d2800042 	mov	x2, #0x2                   	// #2
    7e34:	97ffedf7 	bl	3610 <buf_put>
    7e38:	17ffffe6 	b	7dd0 <fwp_write+0xc10>
    7e3c:	aa1403e0 	mov	x0, x20
    7e40:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7e44:	d2800042 	mov	x2, #0x2                   	// #2
    7e48:	91144021 	add	x1, x1, #0x510
    7e4c:	97ffedf1 	bl	3610 <buf_put>
    7e50:	17ffffe0 	b	7dd0 <fwp_write+0xc10>
    7e54:	f9414bf9 	ldr	x25, [sp, #656]
    7e58:	f9414ffa 	ldr	x26, [sp, #664]
    7e5c:	aa1503e1 	mov	x1, x21
    7e60:	aa1403e0 	mov	x0, x20
    7e64:	52800443 	mov	w3, #0x22                  	// #34
    7e68:	17fffd9c 	b	74d8 <fwp_write+0x318>
    7e6c:	7100103f 	cmp	w1, #0x4
    7e70:	54ffeb21 	b.ne	7bd4 <fwp_write+0xa14>  // b.any
    7e74:	f94006e0 	ldr	x0, [x23, #8]
    7e78:	d37ffc00 	lsr	x0, x0, #63
    7e7c:	17fffeb3 	b	7948 <fwp_write+0x788>
    7e80:	710002ff 	cmp	w23, #0x0
    7e84:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7e88:	17fffeb0 	b	7948 <fwp_write+0x788>
    7e8c:	528005a1 	mov	w1, #0x2d                  	// #45
    7e90:	eb0203e2 	negs	x2, x2
    7e94:	da0303e3 	ngc	x3, x3
    7e98:	910127e0 	add	x0, sp, #0x49
    7e9c:	910123f5 	add	x21, sp, #0x48
    7ea0:	390123e1 	strb	w1, [sp, #72]
    7ea4:	97ffebff 	bl	2ea0 <fwp_fmt_u128>
    7ea8:	17fffe18 	b	7708 <fwp_write+0x548>
    7eac:	d37ceea1 	lsl	x1, x21, #4
    7eb0:	b7f810a3 	tbnz	x3, #63, 80c4 <fwp_write+0xf04>
    7eb4:	91002260 	add	x0, x19, #0x8
    7eb8:	8b010001 	add	x1, x0, x1
    7ebc:	17fffdf9 	b	76a0 <fwp_write+0x4e0>
    7ec0:	f9400a61 	ldr	x1, [x19, #16]
    7ec4:	8b010000 	add	x0, x0, x1
    7ec8:	f9400001 	ldr	x1, [x0]
    7ecc:	17fffdf5 	b	76a0 <fwp_write+0x4e0>
    7ed0:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7ed4:	d2800042 	mov	x2, #0x2                   	// #2
    7ed8:	91128021 	add	x1, x1, #0x4a0
    7edc:	17fffed6 	b	7a34 <fwp_write+0x874>
    7ee0:	7101fcbf 	cmp	w5, #0x7f
    7ee4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7ee8:	540000e9 	b.ls	7f04 <fwp_write+0xd44>  // b.plast
    7eec:	aa1503e1 	mov	x1, x21
    7ef0:	aa1403e0 	mov	x0, x20
    7ef4:	d2800022 	mov	x2, #0x1                   	// #1
    7ef8:	39001fe5 	strb	w5, [sp, #7]
    7efc:	97ffedc5 	bl	3610 <buf_put>
    7f00:	17ffffb4 	b	7dd0 <fwp_write+0xc10>
    7f04:	d2800203 	mov	x3, #0x10                  	// #16
    7f08:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0x20>
    7f0c:	aa0303e1 	mov	x1, x3
    7f10:	91148084 	add	x4, x4, #0x520
    7f14:	910123f6 	add	x22, sp, #0x48
    7f18:	52800042 	mov	w2, #0x2                   	// #2
    7f1c:	aa1603e0 	mov	x0, x22
    7f20:	97ffea58 	bl	2880 <__snprintf_chk@plt>
    7f24:	aa1603e0 	mov	x0, x22
    7f28:	97ffea1e 	bl	27a0 <strlen@plt>
    7f2c:	aa1603e1 	mov	x1, x22
    7f30:	aa0003e2 	mov	x2, x0
    7f34:	aa1403e0 	mov	x0, x20
    7f38:	97ffedb6 	bl	3610 <buf_put>
    7f3c:	17ffffa5 	b	7dd0 <fwp_write+0xc10>
    7f40:	1e604100 	fmov	d0, d8
    7f44:	aa1503e0 	mov	x0, x21
    7f48:	52800221 	mov	w1, #0x11                  	// #17
    7f4c:	97ffef32 	bl	3c14 <fwp_format_g.constprop.0>
    7f50:	17fffe43 	b	785c <fwp_write+0x69c>
    7f54:	b9401040 	ldr	w0, [x2, #16]
    7f58:	350003c0 	cbnz	w0, 7fd0 <fwp_write+0xe10>
    7f5c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7f60:	f947f400 	ldr	x0, [x0, #4072]
    7f64:	f94127e2 	ldr	x2, [sp, #584]
    7f68:	f9400001 	ldr	x1, [x0]
    7f6c:	eb010042 	subs	x2, x2, x1
    7f70:	d2800001 	mov	x1, #0x0                   	// #0
    7f74:	54ffd721 	b.ne	7a58 <fwp_write+0x898>  // b.any
    7f78:	f9413bf5 	ldr	x21, [sp, #624]
    7f7c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7f80:	f9413ff6 	ldr	x22, [sp, #632]
    7f84:	aa1403e0 	mov	x0, x20
    7f88:	f94143f7 	ldr	x23, [sp, #640]
    7f8c:	9115c021 	add	x1, x1, #0x570
    7f90:	f94147f8 	ldr	x24, [sp, #648]
    7f94:	d2800042 	mov	x2, #0x2                   	// #2
    7f98:	17fffd0e 	b	73d0 <fwp_write+0x210>
    7f9c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x20>
    7fa0:	d2800042 	mov	x2, #0x2                   	// #2
    7fa4:	9112a021 	add	x1, x1, #0x4a8
    7fa8:	17fffea3 	b	7a34 <fwp_write+0x874>
    7fac:	f9400a63 	ldr	x3, [x19, #16]
    7fb0:	8b030021 	add	x1, x1, x3
    7fb4:	17ffff66 	b	7d4c <fwp_write+0xb8c>
    7fb8:	f9400a61 	ldr	x1, [x19, #16]
    7fbc:	8b0102a1 	add	x1, x21, x1
    7fc0:	17fffdb3 	b	768c <fwp_write+0x4cc>
    7fc4:	f9400a63 	ldr	x3, [x19, #16]
    7fc8:	8b030021 	add	x1, x1, x3
    7fcc:	17ffff56 	b	7d24 <fwp_write+0xb64>
    7fd0:	b9404840 	ldr	w0, [x2, #72]
    7fd4:	91001ff5 	add	x21, sp, #0x7
    7fd8:	34ffa360 	cbz	w0, 7444 <fwp_write+0x284>
    7fdc:	52800503 	mov	w3, #0x28                  	// #40
    7fe0:	aa1403e0 	mov	x0, x20
    7fe4:	aa1503e1 	mov	x1, x21
    7fe8:	d2800022 	mov	x2, #0x1                   	// #1
    7fec:	39001fe3 	strb	w3, [sp, #7]
    7ff0:	97ffed88 	bl	3610 <buf_put>
    7ff4:	b9401380 	ldr	w0, [x28, #16]
    7ff8:	52800038 	mov	w24, #0x1                   	// #1
    7ffc:	7100001f 	cmp	w0, #0x0
    8000:	54ffa36c 	b.gt	746c <fwp_write+0x2ac>
    8004:	17fffd32 	b	74cc <fwp_write+0x30c>
    8008:	f9014bf9 	str	x25, [sp, #656]
    800c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xedf8>
    8010:	f9014ffa 	str	x26, [sp, #664]
    8014:	f9400676 	ldr	x22, [x19, #8]
    8018:	910aa333 	add	x19, x25, #0x2a8
    801c:	91002273 	add	x19, x19, #0x8
    8020:	937ffed8 	asr	x24, x22, #63
    8024:	aa1802c0 	orr	x0, x22, x24
    8028:	b5000320 	cbnz	x0, 808c <fwp_write+0xecc>
    802c:	110006b5 	add	w21, w21, #0x1
    8030:	710016bf 	cmp	w21, #0x5
    8034:	54ffffc1 	b.ne	802c <fwp_write+0xe6c>  // b.any
    8038:	b7f80578 	tbnz	x24, #63, 80e4 <fwp_write+0xf24>
    803c:	910023f3 	add	x19, sp, #0x8
    8040:	aa1603e2 	mov	x2, x22
    8044:	aa1303e0 	mov	x0, x19
    8048:	d2800003 	mov	x3, #0x0                   	// #0
    804c:	97ffeb95 	bl	2ea0 <fwp_fmt_u128>
    8050:	910123f5 	add	x21, sp, #0x48
    8054:	b0000023 	adrp	x3, d000 <_IO_stdin_used+0x20>
    8058:	aa1303e4 	mov	x4, x19
    805c:	aa1503e0 	mov	x0, x21
    8060:	9115a063 	add	x3, x3, #0x568
    8064:	d2804002 	mov	x2, #0x200                 	// #512
    8068:	52800041 	mov	w1, #0x2                   	// #2
    806c:	97ffe9d1 	bl	27b0 <__sprintf_chk@plt>
    8070:	aa1503e0 	mov	x0, x21
    8074:	97ffe9cb 	bl	27a0 <strlen@plt>
    8078:	aa1503e1 	mov	x1, x21
    807c:	aa0003e2 	mov	x2, x0
    8080:	aa1403e0 	mov	x0, x20
    8084:	97ffed63 	bl	3610 <buf_put>
    8088:	17fffe47 	b	79a4 <fwp_write+0x7e4>
    808c:	f9400277 	ldr	x23, [x19]
    8090:	aa1603e0 	mov	x0, x22
    8094:	aa1803e1 	mov	x1, x24
    8098:	aa1703e2 	mov	x2, x23
    809c:	937ffefa 	asr	x26, x23, #63
    80a0:	aa1a03e3 	mov	x3, x26
    80a4:	940012e7 	bl	cc40 <__modti3>
    80a8:	aa010000 	orr	x0, x0, x1
    80ac:	b40002c0 	cbz	x0, 8104 <fwp_write+0xf44>
    80b0:	110006b5 	add	w21, w21, #0x1
    80b4:	91004273 	add	x19, x19, #0x10
    80b8:	710016bf 	cmp	w21, #0x5
    80bc:	54fffe81 	b.ne	808c <fwp_write+0xecc>  // b.any
    80c0:	17ffffde 	b	8038 <fwp_write+0xe78>
    80c4:	f9400a60 	ldr	x0, [x19, #16]
    80c8:	8b000021 	add	x1, x1, x0
    80cc:	17fffd75 	b	76a0 <fwp_write+0x4e0>
    80d0:	528c29c0 	mov	w0, #0x614e                	// #24910
    80d4:	910123f5 	add	x21, sp, #0x48
    80d8:	72a009c0 	movk	w0, #0x4e, lsl #16
    80dc:	b9004be0 	str	w0, [sp, #72]
    80e0:	17fffda2 	b	7768 <fwp_write+0x5a8>
    80e4:	528005a1 	mov	w1, #0x2d                  	// #45
    80e8:	eb1603e2 	negs	x2, x22
    80ec:	da1803e3 	ngc	x3, x24
    80f0:	910027e0 	add	x0, sp, #0x9
    80f4:	910023f3 	add	x19, sp, #0x8
    80f8:	390023e1 	strb	w1, [sp, #8]
    80fc:	97ffeb69 	bl	2ea0 <fwp_fmt_u128>
    8100:	17ffffd4 	b	8050 <fwp_write+0xe90>
    8104:	aa1703e2 	mov	x2, x23
    8108:	aa1a03e3 	mov	x3, x26
    810c:	aa1603e0 	mov	x0, x22
    8110:	aa1803e1 	mov	x1, x24
    8114:	940011eb 	bl	c8c0 <__divti3>
    8118:	aa0003e2 	mov	x2, x0
    811c:	aa0103e3 	mov	x3, x1
    8120:	b7f80201 	tbnz	x1, #63, 8160 <fwp_write+0xfa0>
    8124:	910023f3 	add	x19, sp, #0x8
    8128:	aa1303e0 	mov	x0, x19
    812c:	97ffeb5d 	bl	2ea0 <fwp_fmt_u128>
    8130:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8134:	910aa339 	add	x25, x25, #0x2a8
    8138:	910123f5 	add	x21, sp, #0x48
    813c:	aa1303e4 	mov	x4, x19
    8140:	aa1503e0 	mov	x0, x21
    8144:	b0000023 	adrp	x3, d000 <_IO_stdin_used+0x20>
    8148:	f8616b25 	ldr	x5, [x25, x1]
    814c:	91158063 	add	x3, x3, #0x560
    8150:	d2804002 	mov	x2, #0x200                 	// #512
    8154:	52800041 	mov	w1, #0x2                   	// #2
    8158:	97ffe996 	bl	27b0 <__sprintf_chk@plt>
    815c:	17ffffc5 	b	8070 <fwp_write+0xeb0>
    8160:	528005a4 	mov	w4, #0x2d                  	// #45
    8164:	eb0003e2 	negs	x2, x0
    8168:	da0103e3 	ngc	x3, x1
    816c:	910027e0 	add	x0, sp, #0x9
    8170:	910023f3 	add	x19, sp, #0x8
    8174:	390023e4 	strb	w4, [sp, #8]
    8178:	97ffeb4a 	bl	2ea0 <fwp_fmt_u128>
    817c:	17ffffed 	b	8130 <fwp_write+0xf70>
    8180:	f9013bf5 	str	x21, [sp, #624]
    8184:	f9013ff6 	str	x22, [sp, #632]
    8188:	f90143f7 	str	x23, [sp, #640]
    818c:	f90147f8 	str	x24, [sp, #648]
    8190:	f9014bf9 	str	x25, [sp, #656]
    8194:	f9014ffa 	str	x26, [sp, #664]
    8198:	f90153fb 	str	x27, [sp, #672]
    819c:	f90157fc 	str	x28, [sp, #680]
    81a0:	fd015be8 	str	d8, [sp, #688]
    81a4:	fd015fe9 	str	d9, [sp, #696]
    81a8:	97ffe9da 	bl	2910 <__stack_chk_fail@plt>
    81ac:	d503201f 	nop

00000000000081b0 <fwp_hof0.constprop.0>:
    81b0:	d10543ff 	sub	sp, sp, #0x150
    81b4:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    81b8:	f947f442 	ldr	x2, [x2, #4072]
    81bc:	a90e7bfd 	stp	x29, x30, [sp, #224]
    81c0:	910383fd 	add	x29, sp, #0xe0
    81c4:	f90023e0 	str	x0, [sp, #64]
    81c8:	f9400040 	ldr	x0, [x2]
    81cc:	f9006fe0 	str	x0, [sp, #216]
    81d0:	d2800000 	mov	x0, #0x0                   	// #0
    81d4:	f90027e1 	str	x1, [sp, #72]
    81d8:	b400a681 	cbz	x1, 96a8 <fwp_hof0.constprop.0+0x14f8>
    81dc:	900000c0 	adrp	x0, 20000 <__data_start>
    81e0:	91004000 	add	x0, x0, #0x10
    81e4:	9100e000 	add	x0, x0, #0x38
    81e8:	f90017e0 	str	x0, [sp, #40]
    81ec:	910163e0 	add	x0, sp, #0x58
    81f0:	f9000fe0 	str	x0, [sp, #24]
    81f4:	910183e0 	add	x0, sp, #0x60
    81f8:	f90013e0 	str	x0, [sp, #32]
    81fc:	b0000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    8200:	6d1427e8 	stp	d8, d9, [sp, #320]
    8204:	fd46f808 	ldr	d8, [x0, #3568]
    8208:	a90f53f3 	stp	x19, x20, [sp, #240]
    820c:	b0000154 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    8210:	a9105bf5 	stp	x21, x22, [sp, #256]
    8214:	900000d5 	adrp	x21, 20000 <__data_start>
    8218:	a91163f7 	stp	x23, x24, [sp, #272]
    821c:	a9126bf9 	stp	x25, x26, [sp, #288]
    8220:	a91373fb 	stp	x27, x28, [sp, #304]
    8224:	9117c282 	add	x2, x20, #0x5f0
    8228:	f94023e0 	ldr	x0, [sp, #64]
    822c:	f949ec43 	ldr	x3, [x2, #5080]
    8230:	f949d841 	ldr	x1, [x2, #5040]
    8234:	d370bc63 	lsl	x3, x3, #16
    8238:	cb010004 	sub	x4, x0, x1
    823c:	eb03009f 	cmp	x4, x3
    8240:	540003e2 	b.cs	82bc <fwp_hof0.constprop.0+0x10c>  // b.hs, b.nlast
    8244:	d350fc80 	lsr	x0, x4, #16
    8248:	f949fc46 	ldr	x6, [x2, #5112]
    824c:	8b000800 	add	x0, x0, x0, lsl #2
    8250:	d37df002 	lsl	x2, x0, #3
    8254:	8b0200c5 	add	x5, x6, x2
    8258:	f94010a0 	ldr	x0, [x5, #32]
    825c:	b4000300 	cbz	x0, 82bc <fwp_hof0.constprop.0+0x10c>
    8260:	386268c2 	ldrb	w2, [x6, x2]
    8264:	7100085f 	cmp	w2, #0x2
    8268:	5400bc00 	b.eq	99e8 <fwp_hof0.constprop.0+0x1838>  // b.none
    826c:	7100045f 	cmp	w2, #0x1
    8270:	54000261 	b.ne	82bc <fwp_hof0.constprop.0+0x10c>  // b.any
    8274:	92403c82 	and	x2, x4, #0xffff
    8278:	294310a6 	ldp	w6, w4, [x5, #24]
    827c:	9b067c42 	mul	x2, x2, x6
    8280:	d360fc42 	lsr	x2, x2, #32
    8284:	eb04005f 	cmp	x2, x4
    8288:	540001a2 	b.cs	82bc <fwp_hof0.constprop.0+0x10c>  // b.hs, b.nlast
    828c:	8b020000 	add	x0, x0, x2
    8290:	39400002 	ldrb	w2, [x0]
    8294:	34000142 	cbz	w2, 82bc <fwp_hof0.constprop.0+0x10c>
    8298:	7103f45f 	cmp	w2, #0xfd
    829c:	5400cca8 	b.hi	9c30 <fwp_hof0.constprop.0+0x1a80>  // b.pmore
    82a0:	9117c281 	add	x1, x20, #0x5f0
    82a4:	11000442 	add	w2, w2, #0x1
    82a8:	39000002 	strb	w2, [x0]
    82ac:	aa0103e0 	mov	x0, x1
    82b0:	f949d821 	ldr	x1, [x1, #5040]
    82b4:	f949ec03 	ldr	x3, [x0, #5080]
    82b8:	d370bc63 	lsl	x3, x3, #16
    82bc:	f94023f6 	ldr	x22, [sp, #64]
    82c0:	d28018c0 	mov	x0, #0xc6                  	// #198
    82c4:	f90007e0 	str	x0, [sp, #8]
    82c8:	f94017e0 	ldr	x0, [sp, #40]
    82cc:	9101c2a2 	add	x2, x21, #0x70
    82d0:	12800004 	mov	w4, #0xffffffff            	// #-1
    82d4:	b9005be4 	str	w4, [sp, #88]
    82d8:	cb010001 	sub	x1, x0, x1
    82dc:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0xa0>
    82e0:	91064000 	add	x0, x0, #0x190
    82e4:	f90037e0 	str	x0, [sp, #104]
    82e8:	f9419840 	ldr	x0, [x2, #816]
    82ec:	f90033e0 	str	x0, [sp, #96]
    82f0:	f9400fe0 	ldr	x0, [sp, #24]
    82f4:	f9003be0 	str	x0, [sp, #112]
    82f8:	f94013e0 	ldr	x0, [sp, #32]
    82fc:	f9019840 	str	x0, [x2, #816]
    8300:	eb03003f 	cmp	x1, x3
    8304:	540007a2 	b.cs	83f8 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8308:	9117c282 	add	x2, x20, #0x5f0
    830c:	d350fc20 	lsr	x0, x1, #16
    8310:	8b000800 	add	x0, x0, x0, lsl #2
    8314:	f949fc44 	ldr	x4, [x2, #5112]
    8318:	d37df003 	lsl	x3, x0, #3
    831c:	8b030082 	add	x2, x4, x3
    8320:	f9401053 	ldr	x19, [x2, #32]
    8324:	b40006b3 	cbz	x19, 83f8 <fwp_hof0.constprop.0+0x248>
    8328:	38636880 	ldrb	w0, [x4, x3]
    832c:	7100081f 	cmp	w0, #0x2
    8330:	5400a8c0 	b.eq	9848 <fwp_hof0.constprop.0+0x1698>  // b.none
    8334:	7100041f 	cmp	w0, #0x1
    8338:	54000601 	b.ne	83f8 <fwp_hof0.constprop.0+0x248>  // b.any
    833c:	29430c44 	ldp	w4, w3, [x2, #24]
    8340:	92403c20 	and	x0, x1, #0xffff
    8344:	9b047c00 	mul	x0, x0, x4
    8348:	d360fc00 	lsr	x0, x0, #32
    834c:	eb03001f 	cmp	x0, x3
    8350:	540002a2 	b.cs	83a4 <fwp_hof0.constprop.0+0x1f4>  // b.hs, b.nlast
    8354:	8b000260 	add	x0, x19, x0
    8358:	39400003 	ldrb	w3, [x0]
    835c:	34000243 	cbz	w3, 83a4 <fwp_hof0.constprop.0+0x1f4>
    8360:	7103f47f 	cmp	w3, #0xfd
    8364:	5400c268 	b.hi	9bb0 <fwp_hof0.constprop.0+0x1a00>  // b.pmore
    8368:	11000463 	add	w3, w3, #0x1
    836c:	39000003 	strb	w3, [x0]
    8370:	9117c280 	add	x0, x20, #0x5f0
    8374:	f94017e3 	ldr	x3, [sp, #40]
    8378:	f949d801 	ldr	x1, [x0, #5040]
    837c:	f949ec02 	ldr	x2, [x0, #5080]
    8380:	cb010061 	sub	x1, x3, x1
    8384:	eb02403f 	cmp	x1, x2, lsl #16
    8388:	54000382 	b.cs	83f8 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    838c:	f949fc00 	ldr	x0, [x0, #5112]
    8390:	d350fc22 	lsr	x2, x1, #16
    8394:	8b020842 	add	x2, x2, x2, lsl #2
    8398:	8b020c02 	add	x2, x0, x2, lsl #3
    839c:	f9401053 	ldr	x19, [x2, #32]
    83a0:	b40002d3 	cbz	x19, 83f8 <fwp_hof0.constprop.0+0x248>
    83a4:	39400040 	ldrb	w0, [x2]
    83a8:	7100081f 	cmp	w0, #0x2
    83ac:	5400a560 	b.eq	9858 <fwp_hof0.constprop.0+0x16a8>  // b.none
    83b0:	7100041f 	cmp	w0, #0x1
    83b4:	54000221 	b.ne	83f8 <fwp_hof0.constprop.0+0x248>  // b.any
    83b8:	29430043 	ldp	w3, w0, [x2, #24]
    83bc:	92403c21 	and	x1, x1, #0xffff
    83c0:	9b037c21 	mul	x1, x1, x3
    83c4:	d360fc21 	lsr	x1, x1, #32
    83c8:	eb00003f 	cmp	x1, x0
    83cc:	54000162 	b.cs	83f8 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    83d0:	8b010273 	add	x19, x19, x1
    83d4:	39400261 	ldrb	w1, [x19]
    83d8:	34000101 	cbz	w1, 83f8 <fwp_hof0.constprop.0+0x248>
    83dc:	7100043f 	cmp	w1, #0x1
    83e0:	54007860 	b.eq	92ec <fwp_hof0.constprop.0+0x113c>  // b.none
    83e4:	7103fc3f 	cmp	w1, #0xff
    83e8:	5400bb80 	b.eq	9b58 <fwp_hof0.constprop.0+0x19a8>  // b.none
    83ec:	51000421 	sub	w1, w1, #0x1
    83f0:	39000261 	strb	w1, [x19]
    83f4:	d503201f 	nop
    83f8:	b40078b6 	cbz	x22, 930c <fwp_hof0.constprop.0+0x115c>
    83fc:	aa1603e0 	mov	x0, x22
    8400:	d2800013 	mov	x19, #0x0                   	// #0
    8404:	d503201f 	nop
    8408:	f9400800 	ldr	x0, [x0, #16]
    840c:	91000673 	add	x19, x19, #0x1
    8410:	b5ffffc0 	cbnz	x0, 8408 <fwp_hof0.constprop.0+0x258>
    8414:	52800000 	mov	w0, #0x0                   	// #0
    8418:	97ffec96 	bl	3670 <descent_phase_step>
    841c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8420:	eb00027f 	cmp	x19, x0
    8424:	5400c3a8 	b.hi	9c98 <fwp_hof0.constprop.0+0x1ae8>  // b.pmore
    8428:	9101c2b7 	add	x23, x21, #0x70
    842c:	b94366e0 	ldr	w0, [x23, #868]
    8430:	340077c0 	cbz	w0, 9328 <fwp_hof0.constprop.0+0x1178>
    8434:	9101c2a0 	add	x0, x21, #0x70
    8438:	f9404817 	ldr	x23, [x0, #144]
    843c:	f9408418 	ldr	x24, [x0, #264]
    8440:	eb17031f 	cmp	x24, x23
    8444:	540078aa 	b.ge	9358 <fwp_hof0.constprop.0+0x11a8>  // b.tcont
    8448:	f9403aa1 	ldr	x1, [x21, #112]
    844c:	8b180700 	add	x0, x24, x24, lsl #1
    8450:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8454:	8b000b00 	add	x0, x24, x0, lsl #2
    8458:	8b000c20 	add	x0, x1, x0, lsl #3
    845c:	d503201f 	nop
    8460:	b9400401 	ldr	w1, [x0, #4]
    8464:	35000081 	cbnz	w1, 8474 <fwp_hof0.constprop.0+0x2c4>
    8468:	b9400001 	ldr	w1, [x0]
    846c:	6b02003f 	cmp	w1, w2
    8470:	54007749 	b.ls	9358 <fwp_hof0.constprop.0+0x11a8>  // b.plast
    8474:	91000718 	add	x24, x24, #0x1
    8478:	9101a000 	add	x0, x0, #0x68
    847c:	eb17031f 	cmp	x24, x23
    8480:	54ffff01 	b.ne	8460 <fwp_hof0.constprop.0+0x2b0>  // b.any
    8484:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8488:	eb0002ff 	cmp	x23, x0
    848c:	5400c00c 	b.gt	9c8c <fwp_hof0.constprop.0+0x1adc>
    8490:	9101c2a0 	add	x0, x21, #0x70
    8494:	f9403abb 	ldr	x27, [x21, #112]
    8498:	f9408000 	ldr	x0, [x0, #256]
    849c:	eb17001f 	cmp	x0, x23
    84a0:	54000201 	b.ne	84e0 <fwp_hof0.constprop.0+0x330>  // b.any
    84a4:	b400a6f7 	cbz	x23, 9980 <fwp_hof0.constprop.0+0x17d0>
    84a8:	d37ffafc 	lsl	x28, x23, #1
    84ac:	d29fffe0 	mov	x0, #0xffff                	// #65535
    84b0:	eb00039f 	cmp	x28, x0
    84b4:	9a80d39c 	csel	x28, x28, x0, le
    84b8:	8b1c0781 	add	x1, x28, x28, lsl #1
    84bc:	8b010b81 	add	x1, x28, x1, lsl #2
    84c0:	d37df021 	lsl	x1, x1, #3
    84c4:	aa1b03e0 	mov	x0, x27
    84c8:	97ffe90e 	bl	2900 <realloc@plt>
    84cc:	aa0003fb 	mov	x27, x0
    84d0:	b40039c0 	cbz	x0, 8c08 <fwp_hof0.constprop.0+0xa58>
    84d4:	9101c2a0 	add	x0, x21, #0x70
    84d8:	f9003abb 	str	x27, [x21, #112]
    84dc:	f900801c 	str	x28, [x0, #256]
    84e0:	8b1706e1 	add	x1, x23, x23, lsl #1
    84e4:	910006e2 	add	x2, x23, #0x1
    84e8:	4f000400 	movi	v0.4s, #0x0
    84ec:	9101c2a0 	add	x0, x21, #0x70
    84f0:	8b010ae1 	add	x1, x23, x1, lsl #2
    84f4:	8b180717 	add	x23, x24, x24, lsl #1
    84f8:	8b170b17 	add	x23, x24, x23, lsl #2
    84fc:	8b010f61 	add	x1, x27, x1, lsl #3
    8500:	f9004802 	str	x2, [x0, #144]
    8504:	b0000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    8508:	8b170f77 	add	x23, x27, x23, lsl #3
    850c:	910b4000 	add	x0, x0, #0x2d0
    8510:	ad000020 	stp	q0, q0, [x1]
    8514:	ad010020 	stp	q0, q0, [x1, #32]
    8518:	ad020020 	stp	q0, q0, [x1, #64]
    851c:	f900303f 	str	xzr, [x1, #96]
    8520:	f90032ff 	str	xzr, [x23, #96]
    8524:	97ffe95f 	bl	2aa0 <getenv@plt>
    8528:	b40072e0 	cbz	x0, 9384 <fwp_hof0.constprop.0+0x11d4>
    852c:	39400001 	ldrb	w1, [x0]
    8530:	7100c03f 	cmp	w1, #0x30
    8534:	54007281 	b.ne	9384 <fwp_hof0.constprop.0+0x11d4>  // b.any
    8538:	39400400 	ldrb	w0, [x0, #1]
    853c:	35007240 	cbnz	w0, 9384 <fwp_hof0.constprop.0+0x11d4>
    8540:	9101c2a0 	add	x0, x21, #0x70
    8544:	2f000400 	mvni	v0.2s, #0x0
    8548:	b94002e4 	ldr	w4, [x23]
    854c:	52800022 	mov	w2, #0x1                   	// #1
    8550:	91000705 	add	x5, x24, #0x1
    8554:	a900cef3 	stp	x19, x19, [x23, #8]
    8558:	0b020084 	add	w4, w4, w2
    855c:	f9419801 	ldr	x1, [x0, #816]
    8560:	29000ae4 	stp	w4, w2, [x23]
    8564:	f9002aff 	str	xzr, [x23, #80]
    8568:	f9008405 	str	x5, [x0, #264]
    856c:	fd002ee0 	str	d0, [x23, #88]
    8570:	b400b9a1 	cbz	x1, 9ca4 <fwp_hof0.constprop.0+0x1af4>
    8574:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0xa0>
    8578:	91064003 	add	x3, x0, #0x190
    857c:	14000003 	b	8588 <fwp_hof0.constprop.0+0x3d8>
    8580:	f9400021 	ldr	x1, [x1]
    8584:	b400b901 	cbz	x1, 9ca4 <fwp_hof0.constprop.0+0x1af4>
    8588:	f9400422 	ldr	x2, [x1, #8]
    858c:	eb03005f 	cmp	x2, x3
    8590:	54ffff81 	b.ne	8580 <fwp_hof0.constprop.0+0x3d0>  // b.any
    8594:	f9400820 	ldr	x0, [x1, #16]
    8598:	2a1803e2 	mov	w2, w24
    859c:	b9400001 	ldr	w1, [x0]
    85a0:	f9002ae0 	str	x0, [x23, #80]
    85a4:	b9005ee1 	str	w1, [x23, #92]
    85a8:	37f80081 	tbnz	w1, #31, 85b8 <fwp_hof0.constprop.0+0x408>
    85ac:	52800d03 	mov	w3, #0x68                  	// #104
    85b0:	9b236c21 	smaddl	x1, w1, w3, x27
    85b4:	b9005838 	str	w24, [x1, #88]
    85b8:	b9000002 	str	w2, [x0]
    85bc:	d3707c93 	ubfiz	x19, x4, #16, #32
    85c0:	52800020 	mov	w0, #0x1                   	// #1
    85c4:	aa050273 	orr	x19, x19, x5
    85c8:	97ffec2a 	bl	3670 <descent_phase_step>
    85cc:	aa1603e0 	mov	x0, x22
    85d0:	d2800002 	mov	x2, #0x0                   	// #0
    85d4:	b4007636 	cbz	x22, 9498 <fwp_hof0.constprop.0+0x12e8>
    85d8:	f9400800 	ldr	x0, [x0, #16]
    85dc:	91000442 	add	x2, x2, #0x1
    85e0:	b5ffffc0 	cbnz	x0, 85d8 <fwp_hof0.constprop.0+0x428>
    85e4:	aa1603e1 	mov	x1, x22
    85e8:	f9400821 	ldr	x1, [x1, #16]
    85ec:	91000400 	add	x0, x0, #0x1
    85f0:	b5ffffc1 	cbnz	x1, 85e8 <fwp_hof0.constprop.0+0x438>
    85f4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    85f8:	eb01001f 	cmp	x0, x1
    85fc:	5400b2c8 	b.hi	9c54 <fwp_hof0.constprop.0+0x1aa4>  // b.pmore
    8600:	f100005f 	cmp	x2, #0x0
    8604:	540074ad 	b.le	9498 <fwp_hof0.constprop.0+0x12e8>
    8608:	eb00005f 	cmp	x2, x0
    860c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8610:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8614:	eb0102ff 	cmp	x23, x1
    8618:	5400b1e8 	b.hi	9c54 <fwp_hof0.constprop.0+0x1aa4>  // b.pmore
    861c:	d37ffafc 	lsl	x28, x23, #1
    8620:	52800041 	mov	w1, #0x2                   	// #2
    8624:	91000780 	add	x0, x28, #0x1
    8628:	d37df000 	lsl	x0, x0, #3
    862c:	97fff265 	bl	4fc0 <fwp_heap_alloc>
    8630:	aa0003f8 	mov	x24, x0
    8634:	9117c281 	add	x1, x20, #0x5f0
    8638:	aa0003fb 	mov	x27, x0
    863c:	aa0103e0 	mov	x0, x1
    8640:	f900031c 	str	x28, [x24]
    8644:	f949d821 	ldr	x1, [x1, #5040]
    8648:	f949ec00 	ldr	x0, [x0, #5080]
    864c:	cb010301 	sub	x1, x24, x1
    8650:	eb00403f 	cmp	x1, x0, lsl #16
    8654:	54008402 	b.cs	96d4 <fwp_hof0.constprop.0+0x1524>  // b.hs, b.nlast
    8658:	9117c282 	add	x2, x20, #0x5f0
    865c:	d350fc20 	lsr	x0, x1, #16
    8660:	8b000800 	add	x0, x0, x0, lsl #2
    8664:	f949fc43 	ldr	x3, [x2, #5112]
    8668:	d37df002 	lsl	x2, x0, #3
    866c:	8b020060 	add	x0, x3, x2
    8670:	f940101c 	ldr	x28, [x0, #32]
    8674:	b400025c 	cbz	x28, 86bc <fwp_hof0.constprop.0+0x50c>
    8678:	38626862 	ldrb	w2, [x3, x2]
    867c:	7100085f 	cmp	w2, #0x2
    8680:	54008d40 	b.eq	9828 <fwp_hof0.constprop.0+0x1678>  // b.none
    8684:	7100045f 	cmp	w2, #0x1
    8688:	540001a1 	b.ne	86bc <fwp_hof0.constprop.0+0x50c>  // b.any
    868c:	29430002 	ldp	w2, w0, [x0, #24]
    8690:	92403c21 	and	x1, x1, #0xffff
    8694:	9b027c21 	mul	x1, x1, x2
    8698:	d360fc21 	lsr	x1, x1, #32
    869c:	eb00003f 	cmp	x1, x0
    86a0:	540000e2 	b.cs	86bc <fwp_hof0.constprop.0+0x50c>  // b.hs, b.nlast
    86a4:	8b01039c 	add	x28, x28, x1
    86a8:	39400380 	ldrb	w0, [x28]
    86ac:	7103fc1f 	cmp	w0, #0xff
    86b0:	54008c60 	b.eq	983c <fwp_hof0.constprop.0+0x168c>  // b.none
    86b4:	52800020 	mov	w0, #0x1                   	// #1
    86b8:	39000380 	strb	w0, [x28]
    86bc:	b4000237 	cbz	x23, 8700 <fwp_hof0.constprop.0+0x550>
    86c0:	d3607e64 	lsl	x4, x19, #32
    86c4:	aa1603e1 	mov	x1, x22
    86c8:	f94006c5 	ldr	x5, [x22, #8]
    86cc:	aa0403e3 	mov	x3, x4
    86d0:	91002302 	add	x2, x24, #0x8
    86d4:	d2800000 	mov	x0, #0x0                   	// #0
    86d8:	14000005 	b	86ec <fwp_hof0.constprop.0+0x53c>
    86dc:	f9400425 	ldr	x5, [x1, #8]
    86e0:	ab000083 	adds	x3, x4, x0
    86e4:	91004042 	add	x2, x2, #0x10
    86e8:	5400af26 	b.vs	9ccc <fwp_hof0.constprop.0+0x1b1c>
    86ec:	a9000c45 	stp	x5, x3, [x2]
    86f0:	91000400 	add	x0, x0, #0x1
    86f4:	f9400821 	ldr	x1, [x1, #16]
    86f8:	eb17001f 	cmp	x0, x23
    86fc:	54ffff03 	b.cc	86dc <fwp_hof0.constprop.0+0x52c>  // b.lo, b.ul, b.last
    8700:	f9400300 	ldr	x0, [x24]
    8704:	f100041f 	cmp	x0, #0x1
    8708:	54007e89 	b.ls	96d8 <fwp_hof0.constprop.0+0x1528>  // b.plast
    870c:	d341fc00 	lsr	x0, x0, #1
    8710:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8714:	d1000401 	sub	x1, x0, #0x1
    8718:	eb02003f 	cmp	x1, x2
    871c:	5400a9c8 	b.hi	9c54 <fwp_hof0.constprop.0+0x1aa4>  // b.pmore
    8720:	d37ff83c 	lsl	x28, x1, #1
    8724:	b4007da1 	cbz	x1, 96d8 <fwp_hof0.constprop.0+0x1528>
    8728:	d1002301 	sub	x1, x24, #0x8
    872c:	91002319 	add	x25, x24, #0x8
    8730:	8b001037 	add	x23, x1, x0, lsl #4
    8734:	d503201f 	nop
    8738:	f9400720 	ldr	x0, [x25, #8]
    873c:	f9400f21 	ldr	x1, [x25, #24]
    8740:	fd400320 	ldr	d0, [x25]
    8744:	fd400b21 	ldr	d1, [x25, #16]
    8748:	97fff35e 	bl	54c0 <w120>
    874c:	a9000720 	stp	x0, x1, [x25]
    8750:	91004339 	add	x25, x25, #0x10
    8754:	eb17033f 	cmp	x25, x23
    8758:	54ffff01 	b.ne	8738 <fwp_hof0.constprop.0+0x588>  // b.any
    875c:	9117c297 	add	x23, x20, #0x5f0
    8760:	f900031c 	str	x28, [x24]
    8764:	aa1803e0 	mov	x0, x24
    8768:	97fff3aa 	bl	5610 <w176.constprop.0>
    876c:	aa0103e5 	mov	x5, x1
    8770:	f949dae1 	ldr	x1, [x23, #5040]
    8774:	f949eee0 	ldr	x0, [x23, #5080]
    8778:	cb010301 	sub	x1, x24, x1
    877c:	eb00403f 	cmp	x1, x0, lsl #16
    8780:	54000382 	b.cs	87f0 <fwp_hof0.constprop.0+0x640>  // b.hs, b.nlast
    8784:	d350fc20 	lsr	x0, x1, #16
    8788:	f949fee4 	ldr	x4, [x23, #5112]
    878c:	8b000800 	add	x0, x0, x0, lsl #2
    8790:	d37df000 	lsl	x0, x0, #3
    8794:	8b000082 	add	x2, x4, x0
    8798:	f9401058 	ldr	x24, [x2, #32]
    879c:	b40002b8 	cbz	x24, 87f0 <fwp_hof0.constprop.0+0x640>
    87a0:	38606880 	ldrb	w0, [x4, x0]
    87a4:	7100081f 	cmp	w0, #0x2
    87a8:	540079c0 	b.eq	96e0 <fwp_hof0.constprop.0+0x1530>  // b.none
    87ac:	7100041f 	cmp	w0, #0x1
    87b0:	54000201 	b.ne	87f0 <fwp_hof0.constprop.0+0x640>  // b.any
    87b4:	29430043 	ldp	w3, w0, [x2, #24]
    87b8:	92403c21 	and	x1, x1, #0xffff
    87bc:	9b037c21 	mul	x1, x1, x3
    87c0:	d360fc21 	lsr	x1, x1, #32
    87c4:	eb00003f 	cmp	x1, x0
    87c8:	54000142 	b.cs	87f0 <fwp_hof0.constprop.0+0x640>  // b.hs, b.nlast
    87cc:	8b010318 	add	x24, x24, x1
    87d0:	39400300 	ldrb	w0, [x24]
    87d4:	340000e0 	cbz	w0, 87f0 <fwp_hof0.constprop.0+0x640>
    87d8:	7100041f 	cmp	w0, #0x1
    87dc:	540022e0 	b.eq	8c38 <fwp_hof0.constprop.0+0xa88>  // b.none
    87e0:	7103fc1f 	cmp	w0, #0xff
    87e4:	54009080 	b.eq	99f4 <fwp_hof0.constprop.0+0x1844>  // b.none
    87e8:	51000400 	sub	w0, w0, #0x1
    87ec:	39000300 	strb	w0, [x24]
    87f0:	f90003e5 	str	x5, [sp]
    87f4:	97ffeed4 	bl	4344 <caf75>
    87f8:	9e670009 	fmov	d9, x0
    87fc:	93407e7c 	sxtw	x28, w19
    8800:	52800040 	mov	w0, #0x2                   	// #2
    8804:	97ffeb9b 	bl	3670 <descent_phase_step>
    8808:	aa1c03e0 	mov	x0, x28
    880c:	97ffece9 	bl	3bb0 <fwp_tape_of>
    8810:	f9403002 	ldr	x2, [x0, #96]
    8814:	aa0003e7 	mov	x7, x0
    8818:	f94003e5 	ldr	x5, [sp]
    881c:	b500a222 	cbnz	x2, 9c60 <fwp_hof0.constprop.0+0x1ab0>
    8820:	97ffe9fc 	bl	3010 <fwp_tape_unlink_scope>
    8824:	b9400008 	ldr	w8, [x0]
    8828:	a9408019 	ldp	x25, x0, [x0, #8]
    882c:	b90004ff 	str	wzr, [x7, #4]
    8830:	a941dcea 	ldp	x10, x23, [x7, #24]
    8834:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    8838:	a942ecf8 	ldp	x24, x27, [x7, #40]
    883c:	a943e8f3 	ldp	x19, x26, [x7, #56]
    8840:	f94024e2 	ldr	x2, [x7, #72]
    8844:	6b03011f 	cmp	w8, w3
    8848:	54000108 	b.hi	8868 <fwp_hof0.constprop.0+0x6b8>  // b.pmore
    884c:	9101c2a8 	add	x8, x21, #0x70
    8850:	92403f83 	and	x3, x28, #0xffff
    8854:	d1000463 	sub	x3, x3, #0x1
    8858:	f9408509 	ldr	x9, [x8, #264]
    885c:	eb09007f 	cmp	x3, x9
    8860:	5400004a 	b.ge	8868 <fwp_hof0.constprop.0+0x6b8>  // b.tcont
    8864:	f9008503 	str	x3, [x8, #264]
    8868:	4f000400 	movi	v0.4s, #0x0
    886c:	9101c2a9 	add	x9, x21, #0x70
    8870:	f9000cff 	str	xzr, [x7, #24]
    8874:	910243e1 	add	x1, sp, #0x90
    8878:	a9047cff 	stp	xzr, xzr, [x7, #64]
    887c:	9101e3e3 	add	x3, sp, #0x78
    8880:	90ffffe8 	adrp	x8, 4000 <fwp_format_g.constprop.0+0x3ec>
    8884:	f941992b 	ldr	x11, [x9, #816]
    8888:	3c8080e0 	stur	q0, [x7, #8]
    888c:	91114108 	add	x8, x8, #0x450
    8890:	ad0100e0 	stp	q0, q0, [x7, #32]
    8894:	f9000be1 	str	x1, [sp, #16]
    8898:	a907a3eb 	stp	x11, x8, [sp, #120]
    889c:	a908dfe1 	stp	x1, x23, [sp, #136]
    88a0:	a909eff8 	stp	x24, x27, [sp, #152]
    88a4:	a90aebf3 	stp	x19, x26, [sp, #168]
    88a8:	a90b8bea 	stp	x10, x2, [sp, #184]
    88ac:	f9019923 	str	x3, [x9, #816]
    88b0:	b7f87da5 	tbnz	x5, #63, 9864 <fwp_hof0.constprop.0+0x16b4>
    88b4:	eb85839f 	cmp	x28, x5, asr #32
    88b8:	540098a1 	b.ne	9bcc <fwp_hof0.constprop.0+0x1a1c>  // b.any
    88bc:	92407ca3 	and	x3, x5, #0xffffffff
    88c0:	eb25401f 	cmp	x0, w5, uxtw
    88c4:	540097ed 	b.le	9bc0 <fwp_hof0.constprop.0+0x1a10>
    88c8:	eb03033f 	cmp	x25, x3
    88cc:	9a83c73c 	csinc	x28, x25, x3, gt
    88d0:	eb1c005f 	cmp	x2, x28
    88d4:	5400186a 	b.ge	8be0 <fwp_hof0.constprop.0+0xa30>  // b.tcont
    88d8:	f100005f 	cmp	x2, #0x0
    88dc:	9a9c1042 	csel	x2, x2, x28, ne	// ne = any
    88e0:	14000005 	b	88f4 <fwp_hof0.constprop.0+0x744>
    88e4:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    88e8:	eb00005f 	cmp	x2, x0
    88ec:	d37ff842 	lsl	x2, x2, #1
    88f0:	9a9cd042 	csel	x2, x2, x28, le
    88f4:	eb1c005f 	cmp	x2, x28
    88f8:	54ffff6b 	b.lt	88e4 <fwp_hof0.constprop.0+0x734>  // b.tstop
    88fc:	f9001be5 	str	x5, [sp, #48]
    8900:	b400831a 	cbz	x26, 9960 <fwp_hof0.constprop.0+0x17b0>
    8904:	aa1a03e0 	mov	x0, x26
    8908:	d37df041 	lsl	x1, x2, #3
    890c:	f90003e2 	str	x2, [sp]
    8910:	97ffe7fc 	bl	2900 <realloc@plt>
    8914:	f94003e2 	ldr	x2, [sp]
    8918:	aa0003fa 	mov	x26, x0
    891c:	f9401be5 	ldr	x5, [sp, #48]
    8920:	b4009b3a 	cbz	x26, 9c84 <fwp_hof0.constprop.0+0x1ad4>
    8924:	f9005bfa 	str	x26, [sp, #176]
    8928:	f90063e2 	str	x2, [sp, #192]
    892c:	b50014dc 	cbnz	x28, 8bc4 <fwp_hof0.constprop.0+0xa14>
    8930:	b7f800a5 	tbnz	x5, #63, 8944 <fwp_hof0.constprop.0+0x794>
    8934:	92407ca1 	and	x1, x5, #0xffffffff
    8938:	fc617b40 	ldr	d0, [x26, x1, lsl #3]
    893c:	1e692800 	fadd	d0, d0, d9
    8940:	fc217b40 	str	d0, [x26, x1, lsl #3]
    8944:	9101c2a1 	add	x1, x21, #0x70
    8948:	cb190385 	sub	x5, x28, x25
    894c:	52800060 	mov	w0, #0x3                   	// #3
    8950:	a9428827 	ldp	x7, x2, [x1, #40]
    8954:	8b0700a5 	add	x5, x5, x7
    8958:	8b190042 	add	x2, x2, x25
    895c:	a9028825 	stp	x5, x2, [x1, #40]
    8960:	97ffeb44 	bl	3670 <descent_phase_step>
    8964:	d1000783 	sub	x3, x28, #0x1
    8968:	d1000725 	sub	x5, x25, #0x1
    896c:	eb03033f 	cmp	x25, x3
    8970:	540003ac 	b.gt	89e4 <fwp_hof0.constprop.0+0x834>
    8974:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    8978:	1e602008 	fcmp	d0, #0.0
    897c:	540002e0 	b.eq	89d8 <fwp_hof0.constprop.0+0x828>  // b.none
    8980:	cb190be0 	neg	x0, x25, lsl #2
    8984:	cb1903e2 	neg	x2, x25
    8988:	8b0002e1 	add	x1, x23, x0
    898c:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    8990:	37f80101 	tbnz	w1, #31, 89b0 <fwp_hof0.constprop.0+0x800>
    8994:	8b020f67 	add	x7, x27, x2, lsl #3
    8998:	93407c21 	sxtw	x1, w1
    899c:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    89a0:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    89a4:	1e620802 	fmul	d2, d0, d2
    89a8:	1e622821 	fadd	d1, d1, d2
    89ac:	fc217b41 	str	d1, [x26, x1, lsl #3]
    89b0:	8b000300 	add	x0, x24, x0
    89b4:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    89b8:	37f80100 	tbnz	w0, #31, 89d8 <fwp_hof0.constprop.0+0x828>
    89bc:	8b020e62 	add	x2, x19, x2, lsl #3
    89c0:	93407c00 	sxtw	x0, w0
    89c4:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    89c8:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    89cc:	1e620800 	fmul	d0, d0, d2
    89d0:	1e602820 	fadd	d0, d1, d0
    89d4:	fc207b40 	str	d0, [x26, x0, lsl #3]
    89d8:	d1000463 	sub	x3, x3, #0x1
    89dc:	eb0300bf 	cmp	x5, x3
    89e0:	54fffca1 	b.ne	8974 <fwp_hof0.constprop.0+0x7c4>  // b.any
    89e4:	52800080 	mov	w0, #0x4                   	// #4
    89e8:	97ffeb22 	bl	3670 <descent_phase_step>
    89ec:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    89f0:	eb00033f 	cmp	x25, x0
    89f4:	54009428 	b.hi	9c78 <fwp_hof0.constprop.0+0x1ac8>  // b.pmore
    89f8:	91000720 	add	x0, x25, #0x1
    89fc:	52800041 	mov	w1, #0x2                   	// #2
    8a00:	d37df000 	lsl	x0, x0, #3
    8a04:	97fff16f 	bl	4fc0 <fwp_heap_alloc>
    8a08:	aa0003e2 	mov	x2, x0
    8a0c:	aa0003f3 	mov	x19, x0
    8a10:	d2800001 	mov	x1, #0x0                   	// #0
    8a14:	f8008459 	str	x25, [x2], #8
    8a18:	b40000f9 	cbz	x25, 8a34 <fwp_hof0.constprop.0+0x884>
    8a1c:	d503201f 	nop
    8a20:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    8a24:	f8217840 	str	x0, [x2, x1, lsl #3]
    8a28:	91000421 	add	x1, x1, #0x1
    8a2c:	eb01033f 	cmp	x25, x1
    8a30:	54ffff81 	b.ne	8a20 <fwp_hof0.constprop.0+0x870>  // b.any
    8a34:	528000a0 	mov	w0, #0x5                   	// #5
    8a38:	97ffeb0e 	bl	3670 <descent_phase_step>
    8a3c:	f9400be0 	ldr	x0, [sp, #16]
    8a40:	9101c2a1 	add	x1, x21, #0x70
    8a44:	f9403ff8 	ldr	x24, [sp, #120]
    8a48:	f9019838 	str	x24, [x1, #816]
    8a4c:	97ffee81 	bl	4450 <fwp_tape_buffers_release>
    8a50:	528000c0 	mov	w0, #0x6                   	// #6
    8a54:	97ffeb07 	bl	3670 <descent_phase_step>
    8a58:	9117c282 	add	x2, x20, #0x5f0
    8a5c:	f949d841 	ldr	x1, [x2, #5040]
    8a60:	f949ec40 	ldr	x0, [x2, #5080]
    8a64:	cb010261 	sub	x1, x19, x1
    8a68:	eb00403f 	cmp	x1, x0, lsl #16
    8a6c:	54000322 	b.cs	8ad0 <fwp_hof0.constprop.0+0x920>  // b.hs, b.nlast
    8a70:	d350fc20 	lsr	x0, x1, #16
    8a74:	f949fc43 	ldr	x3, [x2, #5112]
    8a78:	8b000800 	add	x0, x0, x0, lsl #2
    8a7c:	d37df002 	lsl	x2, x0, #3
    8a80:	8b020060 	add	x0, x3, x2
    8a84:	f9401017 	ldr	x23, [x0, #32]
    8a88:	b4000257 	cbz	x23, 8ad0 <fwp_hof0.constprop.0+0x920>
    8a8c:	38626862 	ldrb	w2, [x3, x2]
    8a90:	7100085f 	cmp	w2, #0x2
    8a94:	54006ec0 	b.eq	986c <fwp_hof0.constprop.0+0x16bc>  // b.none
    8a98:	7100045f 	cmp	w2, #0x1
    8a9c:	540001a1 	b.ne	8ad0 <fwp_hof0.constprop.0+0x920>  // b.any
    8aa0:	29430002 	ldp	w2, w0, [x0, #24]
    8aa4:	92403c21 	and	x1, x1, #0xffff
    8aa8:	9b027c21 	mul	x1, x1, x2
    8aac:	d360fc21 	lsr	x1, x1, #32
    8ab0:	eb00003f 	cmp	x1, x0
    8ab4:	540000e2 	b.cs	8ad0 <fwp_hof0.constprop.0+0x920>  // b.hs, b.nlast
    8ab8:	8b0102f7 	add	x23, x23, x1
    8abc:	394002e0 	ldrb	w0, [x23]
    8ac0:	7103fc1f 	cmp	w0, #0xff
    8ac4:	54006de0 	b.eq	9880 <fwp_hof0.constprop.0+0x16d0>  // b.none
    8ac8:	52800020 	mov	w0, #0x1                   	// #1
    8acc:	390002e0 	strb	w0, [x23]
    8ad0:	f94013e0 	ldr	x0, [sp, #32]
    8ad4:	eb00031f 	cmp	x24, x0
    8ad8:	54008fc1 	b.ne	9cd0 <fwp_hof0.constprop.0+0x1b20>  // b.any
    8adc:	f9400fe0 	ldr	x0, [sp, #24]
    8ae0:	9101c2a1 	add	x1, x21, #0x70
    8ae4:	f94033e2 	ldr	x2, [sp, #96]
    8ae8:	f9019822 	str	x2, [x1, #816]
    8aec:	97fff5a9 	bl	6190 <fwp_tape_scope_release>
    8af0:	f9400260 	ldr	x0, [x19]
    8af4:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    8af8:	b7f84700 	tbnz	x0, #63, 93d8 <fwp_hof0.constprop.0+0x1228>
    8afc:	9117c282 	add	x2, x20, #0x5f0
    8b00:	f949d840 	ldr	x0, [x2, #5040]
    8b04:	f949ec41 	ldr	x1, [x2, #5080]
    8b08:	cb000260 	sub	x0, x19, x0
    8b0c:	eb01401f 	cmp	x0, x1, lsl #16
    8b10:	54004642 	b.cs	93d8 <fwp_hof0.constprop.0+0x1228>  // b.hs, b.nlast
    8b14:	d350fc01 	lsr	x1, x0, #16
    8b18:	f949fc44 	ldr	x4, [x2, #5112]
    8b1c:	8b010821 	add	x1, x1, x1, lsl #2
    8b20:	d37df021 	lsl	x1, x1, #3
    8b24:	8b010083 	add	x3, x4, x1
    8b28:	f9401062 	ldr	x2, [x3, #32]
    8b2c:	b4004562 	cbz	x2, 93d8 <fwp_hof0.constprop.0+0x1228>
    8b30:	38616881 	ldrb	w1, [x4, x1]
    8b34:	7100083f 	cmp	w1, #0x2
    8b38:	540044a0 	b.eq	93cc <fwp_hof0.constprop.0+0x121c>  // b.none
    8b3c:	7100043f 	cmp	w1, #0x1
    8b40:	540044c1 	b.ne	93d8 <fwp_hof0.constprop.0+0x1228>  // b.any
    8b44:	29430464 	ldp	w4, w1, [x3, #24]
    8b48:	92403c00 	and	x0, x0, #0xffff
    8b4c:	9b047c00 	mul	x0, x0, x4
    8b50:	d360fc00 	lsr	x0, x0, #32
    8b54:	eb01001f 	cmp	x0, x1
    8b58:	54004402 	b.cs	93d8 <fwp_hof0.constprop.0+0x1228>  // b.hs, b.nlast
    8b5c:	8b000042 	add	x2, x2, x0
    8b60:	39400040 	ldrb	w0, [x2]
    8b64:	7100041f 	cmp	w0, #0x1
    8b68:	54004381 	b.ne	93d8 <fwp_hof0.constprop.0+0x1228>  // b.any
    8b6c:	aa1303fb 	mov	x27, x19
    8b70:	d2800000 	mov	x0, #0x0                   	// #0
    8b74:	f90003f3 	str	x19, [sp]
    8b78:	f94003e1 	ldr	x1, [sp]
    8b7c:	91002265 	add	x5, x19, #0x8
    8b80:	91002023 	add	x3, x1, #0x8
    8b84:	d2800001 	mov	x1, #0x0                   	// #0
    8b88:	b5000158 	cbnz	x24, 8bb0 <fwp_hof0.constprop.0+0xa00>
    8b8c:	1400004e 	b	8cc4 <fwp_hof0.constprop.0+0xb14>
    8b90:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8b94:	f9400362 	ldr	x2, [x27]
    8b98:	1e600900 	fmul	d0, d8, d0
    8b9c:	b7f88562 	tbnz	x2, #63, 9c48 <fwp_hof0.constprop.0+0x1a98>
    8ba0:	91000421 	add	x1, x1, #0x1
    8ba4:	fc008460 	str	d0, [x3], #8
    8ba8:	eb01031f 	cmp	x24, x1
    8bac:	540008c0 	b.eq	8cc4 <fwp_hof0.constprop.0+0xb14>  // b.none
    8bb0:	f9400264 	ldr	x4, [x19]
    8bb4:	aa0503e2 	mov	x2, x5
    8bb8:	b6fffec4 	tbz	x4, #63, 8b90 <fwp_hof0.constprop.0+0x9e0>
    8bbc:	f9400a62 	ldr	x2, [x19, #16]
    8bc0:	17fffff4 	b	8b90 <fwp_hof0.constprop.0+0x9e0>
    8bc4:	d37df382 	lsl	x2, x28, #3
    8bc8:	aa1a03e0 	mov	x0, x26
    8bcc:	52800001 	mov	w1, #0x0                   	// #0
    8bd0:	f90003e5 	str	x5, [sp]
    8bd4:	97ffe743 	bl	28e0 <memset@plt>
    8bd8:	f94003e5 	ldr	x5, [sp]
    8bdc:	17ffff55 	b	8930 <fwp_hof0.constprop.0+0x780>
    8be0:	f100035f 	cmp	x26, #0x0
    8be4:	1a9f17e0 	cset	w0, eq	// eq = none
    8be8:	f100039f 	cmp	x28, #0x0
    8bec:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8bf0:	54ffe9e0 	b.eq	892c <fwp_hof0.constprop.0+0x77c>  // b.none
    8bf4:	f9400be0 	ldr	x0, [sp, #16]
    8bf8:	9101c2b5 	add	x21, x21, #0x70
    8bfc:	f9403fe1 	ldr	x1, [sp, #120]
    8c00:	f9019aa1 	str	x1, [x21, #816]
    8c04:	97ffee13 	bl	4450 <fwp_tape_buffers_release>
    8c08:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    8c0c:	f947e863 	ldr	x3, [x3, #4048]
    8c10:	d2800262 	mov	x2, #0x13                  	// #19
    8c14:	d2800021 	mov	x1, #0x1                   	// #1
    8c18:	90000020 	adrp	x0, c000 <f0+0x232c>
    8c1c:	913fa000 	add	x0, x0, #0xfe8
    8c20:	f9400063 	ldr	x3, [x3]
    8c24:	97ffe77b 	bl	2a10 <fwrite@plt>
    8c28:	d2800000 	mov	x0, #0x0                   	// #0
    8c2c:	97ffe785 	bl	2a40 <fflush@plt>
    8c30:	52800cc0 	mov	w0, #0x66                  	// #102
    8c34:	97ffe793 	bl	2a80 <_Exit@plt>
    8c38:	f9400366 	ldr	x6, [x27]
    8c3c:	aa1b03e0 	mov	x0, x27
    8c40:	f949eee3 	ldr	x3, [x23, #5080]
    8c44:	f949dae1 	ldr	x1, [x23, #5040]
    8c48:	d370bc63 	lsl	x3, x3, #16
    8c4c:	cb010362 	sub	x2, x27, x1
    8c50:	b7f85546 	tbnz	x6, #63, 96f8 <fwp_hof0.constprop.0+0x1548>
    8c54:	eb02007f 	cmp	x3, x2
    8c58:	54ffdcc9 	b.ls	87f0 <fwp_hof0.constprop.0+0x640>  // b.plast
    8c5c:	d350fc40 	lsr	x0, x2, #16
    8c60:	8b000800 	add	x0, x0, x0, lsl #2
    8c64:	d37df000 	lsl	x0, x0, #3
    8c68:	8b000083 	add	x3, x4, x0
    8c6c:	f9401061 	ldr	x1, [x3, #32]
    8c70:	b4ffdc01 	cbz	x1, 87f0 <fwp_hof0.constprop.0+0x640>
    8c74:	38606880 	ldrb	w0, [x4, x0]
    8c78:	7100081f 	cmp	w0, #0x2
    8c7c:	54006080 	b.eq	988c <fwp_hof0.constprop.0+0x16dc>  // b.none
    8c80:	7100041f 	cmp	w0, #0x1
    8c84:	54ffdb61 	b.ne	87f0 <fwp_hof0.constprop.0+0x640>  // b.any
    8c88:	92403c40 	and	x0, x2, #0xffff
    8c8c:	29430864 	ldp	w4, w2, [x3, #24]
    8c90:	9b047c00 	mul	x0, x0, x4
    8c94:	d360fc00 	lsr	x0, x0, #32
    8c98:	eb02001f 	cmp	x0, x2
    8c9c:	54ffdaa2 	b.cs	87f0 <fwp_hof0.constprop.0+0x640>  // b.hs, b.nlast
    8ca0:	8b000021 	add	x1, x1, x0
    8ca4:	39400020 	ldrb	w0, [x1]
    8ca8:	7100041f 	cmp	w0, #0x1
    8cac:	54ffda21 	b.ne	87f0 <fwp_hof0.constprop.0+0x640>  // b.any
    8cb0:	aa1b03e0 	mov	x0, x27
    8cb4:	f90003e5 	str	x5, [sp]
    8cb8:	97ffefa2 	bl	4b40 <fwp_mem_free>
    8cbc:	f94003e5 	ldr	x5, [sp]
    8cc0:	17fffecc 	b	87f0 <fwp_hof0.constprop.0+0x640>
    8cc4:	97fff71f 	bl	6940 <fwp_drop10>
    8cc8:	aa1603e1 	mov	x1, x22
    8ccc:	d2800002 	mov	x2, #0x0                   	// #0
    8cd0:	b40065f6 	cbz	x22, 998c <fwp_hof0.constprop.0+0x17dc>
    8cd4:	d503201f 	nop
    8cd8:	f9400821 	ldr	x1, [x1, #16]
    8cdc:	91000442 	add	x2, x2, #0x1
    8ce0:	b5ffffc1 	cbnz	x1, 8cd8 <fwp_hof0.constprop.0+0xb28>
    8ce4:	f9400360 	ldr	x0, [x27]
    8ce8:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    8cec:	b7f82c40 	tbnz	x0, #63, 9274 <fwp_hof0.constprop.0+0x10c4>
    8cf0:	9117c283 	add	x3, x20, #0x5f0
    8cf4:	f94003e4 	ldr	x4, [sp]
    8cf8:	f949d861 	ldr	x1, [x3, #5040]
    8cfc:	f949ec63 	ldr	x3, [x3, #5080]
    8d00:	cb010081 	sub	x1, x4, x1
    8d04:	eb03403f 	cmp	x1, x3, lsl #16
    8d08:	54002b62 	b.cs	9274 <fwp_hof0.constprop.0+0x10c4>  // b.hs, b.nlast
    8d0c:	9117c284 	add	x4, x20, #0x5f0
    8d10:	d350fc23 	lsr	x3, x1, #16
    8d14:	8b030863 	add	x3, x3, x3, lsl #2
    8d18:	f949fc87 	ldr	x7, [x4, #5112]
    8d1c:	d37df063 	lsl	x3, x3, #3
    8d20:	8b0300e6 	add	x6, x7, x3
    8d24:	f94010c4 	ldr	x4, [x6, #32]
    8d28:	b4002a44 	cbz	x4, 9270 <fwp_hof0.constprop.0+0x10c0>
    8d2c:	386368e3 	ldrb	w3, [x7, x3]
    8d30:	7100087f 	cmp	w3, #0x2
    8d34:	540029a0 	b.eq	9268 <fwp_hof0.constprop.0+0x10b8>  // b.none
    8d38:	7100047f 	cmp	w3, #0x1
    8d3c:	540029a1 	b.ne	9270 <fwp_hof0.constprop.0+0x10c0>  // b.any
    8d40:	29430cc7 	ldp	w7, w3, [x6, #24]
    8d44:	92403c21 	and	x1, x1, #0xffff
    8d48:	9b077c21 	mul	x1, x1, x7
    8d4c:	d360fc21 	lsr	x1, x1, #32
    8d50:	eb03003f 	cmp	x1, x3
    8d54:	540028e2 	b.cs	9270 <fwp_hof0.constprop.0+0x10c0>  // b.hs, b.nlast
    8d58:	8b010084 	add	x4, x4, x1
    8d5c:	39400081 	ldrb	w1, [x4]
    8d60:	7100043f 	cmp	w1, #0x1
    8d64:	54002861 	b.ne	9270 <fwp_hof0.constprop.0+0x10c0>  // b.any
    8d68:	b90033e1 	str	w1, [sp, #48]
    8d6c:	eb05005f 	cmp	x2, x5
    8d70:	9a859045 	csel	x5, x2, x5, ls	// ls = plast
    8d74:	9100237c 	add	x28, x27, #0x8
    8d78:	b4006ea5 	cbz	x5, 9b4c <fwp_hof0.constprop.0+0x199c>
    8d7c:	f94003e1 	ldr	x1, [sp]
    8d80:	d37df0a7 	lsl	x7, x5, #3
    8d84:	aa1603e2 	mov	x2, x22
    8d88:	91002026 	add	x6, x1, #0x8
    8d8c:	d2800001 	mov	x1, #0x0                   	// #0
    8d90:	1400000a 	b	8db8 <fwp_hof0.constprop.0+0xc08>
    8d94:	fc616881 	ldr	d1, [x4, x1]
    8d98:	fd400440 	ldr	d0, [x2, #8]
    8d9c:	1e613800 	fsub	d0, d0, d1
    8da0:	fc216b80 	str	d0, [x28, x1]
    8da4:	91002021 	add	x1, x1, #0x8
    8da8:	f9400842 	ldr	x2, [x2, #16]
    8dac:	eb07003f 	cmp	x1, x7
    8db0:	540001c0 	b.eq	8de8 <fwp_hof0.constprop.0+0xc38>  // b.none
    8db4:	f9400360 	ldr	x0, [x27]
    8db8:	aa0603e4 	mov	x4, x6
    8dbc:	b6fffec0 	tbz	x0, #63, 8d94 <fwp_hof0.constprop.0+0xbe4>
    8dc0:	f94003e0 	ldr	x0, [sp]
    8dc4:	fd400440 	ldr	d0, [x2, #8]
    8dc8:	f9400804 	ldr	x4, [x0, #16]
    8dcc:	fc616881 	ldr	d1, [x4, x1]
    8dd0:	1e613800 	fsub	d0, d0, d1
    8dd4:	fc216b80 	str	d0, [x28, x1]
    8dd8:	91002021 	add	x1, x1, #0x8
    8ddc:	f9400842 	ldr	x2, [x2, #16]
    8de0:	eb07003f 	cmp	x1, x7
    8de4:	54fffe81 	b.ne	8db4 <fwp_hof0.constprop.0+0xc04>  // b.any
    8de8:	b4006e96 	cbz	x22, 9bb8 <fwp_hof0.constprop.0+0x1a08>
    8dec:	9117c280 	add	x0, x20, #0x5f0
    8df0:	aa1603e7 	mov	x7, x22
    8df4:	d2800018 	mov	x24, #0x0                   	// #0
    8df8:	f949ec09 	ldr	x9, [x0, #5080]
    8dfc:	f949d80a 	ldr	x10, [x0, #5040]
    8e00:	f949fc08 	ldr	x8, [x0, #5112]
    8e04:	d370bd29 	lsl	x9, x9, #16
    8e08:	14000006 	b	8e20 <fwp_hof0.constprop.0+0xc70>
    8e0c:	f94008e7 	ldr	x7, [x7, #16]
    8e10:	91000718 	add	x24, x24, #0x1
    8e14:	f10000ff 	cmp	x7, #0x0
    8e18:	fa5810a0 	ccmp	x5, x24, #0x0, ne	// ne = any
    8e1c:	54000329 	b.ls	8e80 <fwp_hof0.constprop.0+0xcd0>  // b.plast
    8e20:	cb0a00e0 	sub	x0, x7, x10
    8e24:	eb09001f 	cmp	x0, x9
    8e28:	540002c2 	b.cs	8e80 <fwp_hof0.constprop.0+0xcd0>  // b.hs, b.nlast
    8e2c:	d350fc01 	lsr	x1, x0, #16
    8e30:	8b010821 	add	x1, x1, x1, lsl #2
    8e34:	d37df021 	lsl	x1, x1, #3
    8e38:	8b010106 	add	x6, x8, x1
    8e3c:	f94010c2 	ldr	x2, [x6, #32]
    8e40:	b4000202 	cbz	x2, 8e80 <fwp_hof0.constprop.0+0xcd0>
    8e44:	38616901 	ldrb	w1, [x8, x1]
    8e48:	7100083f 	cmp	w1, #0x2
    8e4c:	54000e20 	b.eq	9010 <fwp_hof0.constprop.0+0xe60>  // b.none
    8e50:	7100043f 	cmp	w1, #0x1
    8e54:	54000161 	b.ne	8e80 <fwp_hof0.constprop.0+0xcd0>  // b.any
    8e58:	294304cb 	ldp	w11, w1, [x6, #24]
    8e5c:	92403c00 	and	x0, x0, #0xffff
    8e60:	9b0b7c00 	mul	x0, x0, x11
    8e64:	d360fc00 	lsr	x0, x0, #32
    8e68:	eb01001f 	cmp	x0, x1
    8e6c:	540000a2 	b.cs	8e80 <fwp_hof0.constprop.0+0xcd0>  // b.hs, b.nlast
    8e70:	8b000042 	add	x2, x2, x0
    8e74:	39400040 	ldrb	w0, [x2]
    8e78:	7100041f 	cmp	w0, #0x1
    8e7c:	54fffc80 	b.eq	8e0c <fwp_hof0.constprop.0+0xc5c>  // b.none
    8e80:	eb1800bf 	cmp	x5, x24
    8e84:	54000ce9 	b.ls	9020 <fwp_hof0.constprop.0+0xe70>  // b.plast
    8e88:	aa0503f7 	mov	x23, x5
    8e8c:	d1002399 	sub	x25, x28, #0x8
    8e90:	910323f3 	add	x19, sp, #0xc8
    8e94:	9117c29a 	add	x26, x20, #0x5f0
    8e98:	d280001b 	mov	x27, #0x0                   	// #0
    8e9c:	14000012 	b	8ee4 <fwp_hof0.constprop.0+0xd34>
    8ea0:	7100045f 	cmp	w2, #0x1
    8ea4:	540001a1 	b.ne	8ed8 <fwp_hof0.constprop.0+0xd28>  // b.any
    8ea8:	29430909 	ldp	w9, w2, [x8, #24]
    8eac:	92403c21 	and	x1, x1, #0xffff
    8eb0:	9b097c21 	mul	x1, x1, x9
    8eb4:	d360fc21 	lsr	x1, x1, #32
    8eb8:	eb02003f 	cmp	x1, x2
    8ebc:	540000e2 	b.cs	8ed8 <fwp_hof0.constprop.0+0xd28>  // b.hs, b.nlast
    8ec0:	8b010000 	add	x0, x0, x1
    8ec4:	39400001 	ldrb	w1, [x0]
    8ec8:	7103fc3f 	cmp	w1, #0xff
    8ecc:	54003020 	b.eq	94d0 <fwp_hof0.constprop.0+0x1320>  // b.none
    8ed0:	52800021 	mov	w1, #0x1                   	// #1
    8ed4:	39000001 	strb	w1, [x0]
    8ed8:	d10006f7 	sub	x23, x23, #0x1
    8edc:	eb1802ff 	cmp	x23, x24
    8ee0:	54000389 	b.ls	8f50 <fwp_hof0.constprop.0+0xda0>  // b.plast
    8ee4:	f8777b22 	ldr	x2, [x25, x23, lsl #3]
    8ee8:	aa1303e1 	mov	x1, x19
    8eec:	52800020 	mov	w0, #0x1                   	// #1
    8ef0:	a90cefe2 	stp	x2, x27, [sp, #200]
    8ef4:	97fff078 	bl	50d4 <fwp_data.part.0.constprop.0>
    8ef8:	aa0003fb 	mov	x27, x0
    8efc:	f949db41 	ldr	x1, [x26, #5040]
    8f00:	f949ef40 	ldr	x0, [x26, #5080]
    8f04:	cb010361 	sub	x1, x27, x1
    8f08:	eb00403f 	cmp	x1, x0, lsl #16
    8f0c:	54fffe62 	b.cs	8ed8 <fwp_hof0.constprop.0+0xd28>  // b.hs, b.nlast
    8f10:	d350fc20 	lsr	x0, x1, #16
    8f14:	f949ff49 	ldr	x9, [x26, #5112]
    8f18:	8b000800 	add	x0, x0, x0, lsl #2
    8f1c:	d37df002 	lsl	x2, x0, #3
    8f20:	8b020128 	add	x8, x9, x2
    8f24:	f9401100 	ldr	x0, [x8, #32]
    8f28:	b4fffd80 	cbz	x0, 8ed8 <fwp_hof0.constprop.0+0xd28>
    8f2c:	38626922 	ldrb	w2, [x9, x2]
    8f30:	7100085f 	cmp	w2, #0x2
    8f34:	54fffb61 	b.ne	8ea0 <fwp_hof0.constprop.0+0xcf0>  // b.any
    8f38:	72003c3f 	tst	w1, #0xffff
    8f3c:	54fffc40 	b.eq	8ec4 <fwp_hof0.constprop.0+0xd14>  // b.none
    8f40:	d10006f7 	sub	x23, x23, #0x1
    8f44:	eb1802ff 	cmp	x23, x24
    8f48:	54fffce8 	b.hi	8ee4 <fwp_hof0.constprop.0+0xd34>  // b.pmore
    8f4c:	d503201f 	nop
    8f50:	b50006b8 	cbnz	x24, 9024 <fwp_hof0.constprop.0+0xe74>
    8f54:	b94033e0 	ldr	w0, [sp, #48]
    8f58:	d2800004 	mov	x4, #0x0                   	// #0
    8f5c:	7100001f 	cmp	w0, #0x0
    8f60:	d2800020 	mov	x0, #0x1                   	// #1
    8f64:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    8f68:	b40007c4 	cbz	x4, 9060 <fwp_hof0.constprop.0+0xeb0>
    8f6c:	d1000498 	sub	x24, x4, #0x1
    8f70:	2a0003f9 	mov	w25, w0
    8f74:	9117c29a 	add	x26, x20, #0x5f0
    8f78:	f8787b82 	ldr	x2, [x28, x24, lsl #3]
    8f7c:	aa1303e1 	mov	x1, x19
    8f80:	52800020 	mov	w0, #0x1                   	// #1
    8f84:	a90cefe2 	stp	x2, x27, [sp, #200]
    8f88:	97fff053 	bl	50d4 <fwp_data.part.0.constprop.0>
    8f8c:	aa0003fb 	mov	x27, x0
    8f90:	f949db41 	ldr	x1, [x26, #5040]
    8f94:	f949ef40 	ldr	x0, [x26, #5080]
    8f98:	cb010361 	sub	x1, x27, x1
    8f9c:	eb00403f 	cmp	x1, x0, lsl #16
    8fa0:	54000302 	b.cs	9000 <fwp_hof0.constprop.0+0xe50>  // b.hs, b.nlast
    8fa4:	d350fc22 	lsr	x2, x1, #16
    8fa8:	f949ff47 	ldr	x7, [x26, #5112]
    8fac:	8b020842 	add	x2, x2, x2, lsl #2
    8fb0:	d37df042 	lsl	x2, x2, #3
    8fb4:	8b0200e6 	add	x6, x7, x2
    8fb8:	f94010d7 	ldr	x23, [x6, #32]
    8fbc:	b4000237 	cbz	x23, 9000 <fwp_hof0.constprop.0+0xe50>
    8fc0:	386268e2 	ldrb	w2, [x7, x2]
    8fc4:	7100085f 	cmp	w2, #0x2
    8fc8:	540014a0 	b.eq	925c <fwp_hof0.constprop.0+0x10ac>  // b.none
    8fcc:	7100045f 	cmp	w2, #0x1
    8fd0:	54000181 	b.ne	9000 <fwp_hof0.constprop.0+0xe50>  // b.any
    8fd4:	294308c7 	ldp	w7, w2, [x6, #24]
    8fd8:	92403c21 	and	x1, x1, #0xffff
    8fdc:	9b077c21 	mul	x1, x1, x7
    8fe0:	d360fc21 	lsr	x1, x1, #32
    8fe4:	eb02003f 	cmp	x1, x2
    8fe8:	540000c2 	b.cs	9000 <fwp_hof0.constprop.0+0xe50>  // b.hs, b.nlast
    8fec:	8b0102f7 	add	x23, x23, x1
    8ff0:	394002e1 	ldrb	w1, [x23]
    8ff4:	7103fc3f 	cmp	w1, #0xff
    8ff8:	540012c0 	b.eq	9250 <fwp_hof0.constprop.0+0x10a0>  // b.none
    8ffc:	390002f9 	strb	w25, [x23]
    9000:	d1000718 	sub	x24, x24, #0x1
    9004:	b100071f 	cmn	x24, #0x1
    9008:	54fffb81 	b.ne	8f78 <fwp_hof0.constprop.0+0xdc8>  // b.any
    900c:	14000015 	b	9060 <fwp_hof0.constprop.0+0xeb0>
    9010:	72003c1f 	tst	w0, #0xffff
    9014:	54fff300 	b.eq	8e74 <fwp_hof0.constprop.0+0xcc4>  // b.none
    9018:	eb1800bf 	cmp	x5, x24
    901c:	54fff368 	b.hi	8e88 <fwp_hof0.constprop.0+0xcd8>  // b.pmore
    9020:	d280001b 	mov	x27, #0x0                   	// #0
    9024:	8b180f84 	add	x4, x28, x24, lsl #3
    9028:	aa1c03e1 	mov	x1, x28
    902c:	aa1603e0 	mov	x0, x22
    9030:	f8408422 	ldr	x2, [x1], #8
    9034:	f9000402 	str	x2, [x0, #8]
    9038:	aa0003e2 	mov	x2, x0
    903c:	f9400800 	ldr	x0, [x0, #16]
    9040:	eb04003f 	cmp	x1, x4
    9044:	54ffff61 	b.ne	9030 <fwp_hof0.constprop.0+0xe80>  // b.any
    9048:	b94033e1 	ldr	w1, [sp, #48]
    904c:	f900085b 	str	x27, [x2, #16]
    9050:	aa1603fb 	mov	x27, x22
    9054:	aa0003f6 	mov	x22, x0
    9058:	34000041 	cbz	w1, 9060 <fwp_hof0.constprop.0+0xeb0>
    905c:	d280001c 	mov	x28, #0x0                   	// #0
    9060:	9117c293 	add	x19, x20, #0x5f0
    9064:	aa1c03e0 	mov	x0, x28
    9068:	97ffeeb6 	bl	4b40 <fwp_mem_free>
    906c:	f94003e0 	ldr	x0, [sp]
    9070:	f949ee62 	ldr	x2, [x19, #5080]
    9074:	f949da61 	ldr	x1, [x19, #5040]
    9078:	d370bc42 	lsl	x2, x2, #16
    907c:	cb010003 	sub	x3, x0, x1
    9080:	eb02007f 	cmp	x3, x2
    9084:	54000422 	b.cs	9108 <fwp_hof0.constprop.0+0xf58>  // b.hs, b.nlast
    9088:	d350fc60 	lsr	x0, x3, #16
    908c:	f949fe65 	ldr	x5, [x19, #5112]
    9090:	8b000800 	add	x0, x0, x0, lsl #2
    9094:	d37df000 	lsl	x0, x0, #3
    9098:	8b0000a2 	add	x2, x5, x0
    909c:	f9401058 	ldr	x24, [x2, #32]
    90a0:	b4000cf8 	cbz	x24, 923c <fwp_hof0.constprop.0+0x108c>
    90a4:	386068a1 	ldrb	w1, [x5, x0]
    90a8:	7100083f 	cmp	w1, #0x2
    90ac:	54003200 	b.eq	96ec <fwp_hof0.constprop.0+0x153c>  // b.none
    90b0:	7100043f 	cmp	w1, #0x1
    90b4:	54000c41 	b.ne	923c <fwp_hof0.constprop.0+0x108c>  // b.any
    90b8:	29430844 	ldp	w4, w2, [x2, #24]
    90bc:	92403c61 	and	x1, x3, #0xffff
    90c0:	9b047c21 	mul	x1, x1, x4
    90c4:	d360fc21 	lsr	x1, x1, #32
    90c8:	eb02003f 	cmp	x1, x2
    90cc:	54000b82 	b.cs	923c <fwp_hof0.constprop.0+0x108c>  // b.hs, b.nlast
    90d0:	8b010318 	add	x24, x24, x1
    90d4:	39400301 	ldrb	w1, [x24]
    90d8:	34000b21 	cbz	w1, 923c <fwp_hof0.constprop.0+0x108c>
    90dc:	7100043f 	cmp	w1, #0x1
    90e0:	540006c0 	b.eq	91b8 <fwp_hof0.constprop.0+0x1008>  // b.none
    90e4:	7103fc3f 	cmp	w1, #0xff
    90e8:	54004bc0 	b.eq	9a60 <fwp_hof0.constprop.0+0x18b0>  // b.none
    90ec:	9117c280 	add	x0, x20, #0x5f0
    90f0:	51000421 	sub	w1, w1, #0x1
    90f4:	39000301 	strb	w1, [x24]
    90f8:	f949ec02 	ldr	x2, [x0, #5080]
    90fc:	f949d801 	ldr	x1, [x0, #5040]
    9100:	d370bc42 	lsl	x2, x2, #16
    9104:	d503201f 	nop
    9108:	cb0102c1 	sub	x1, x22, x1
    910c:	eb02003f 	cmp	x1, x2
    9110:	540003c2 	b.cs	9188 <fwp_hof0.constprop.0+0xfd8>  // b.hs, b.nlast
    9114:	9117c297 	add	x23, x20, #0x5f0
    9118:	d350fc20 	lsr	x0, x1, #16
    911c:	f949fee3 	ldr	x3, [x23, #5112]
    9120:	8b000800 	add	x0, x0, x0, lsl #2
    9124:	d37df000 	lsl	x0, x0, #3
    9128:	8b000062 	add	x2, x3, x0
    912c:	f9401053 	ldr	x19, [x2, #32]
    9130:	b40002d3 	cbz	x19, 9188 <fwp_hof0.constprop.0+0xfd8>
    9134:	38606860 	ldrb	w0, [x3, x0]
    9138:	7100081f 	cmp	w0, #0x2
    913c:	54003240 	b.eq	9784 <fwp_hof0.constprop.0+0x15d4>  // b.none
    9140:	7100041f 	cmp	w0, #0x1
    9144:	54000221 	b.ne	9188 <fwp_hof0.constprop.0+0xfd8>  // b.any
    9148:	29430044 	ldp	w4, w0, [x2, #24]
    914c:	92403c21 	and	x1, x1, #0xffff
    9150:	9b047c21 	mul	x1, x1, x4
    9154:	d360fc21 	lsr	x1, x1, #32
    9158:	eb00003f 	cmp	x1, x0
    915c:	54000162 	b.cs	9188 <fwp_hof0.constprop.0+0xfd8>  // b.hs, b.nlast
    9160:	8b010273 	add	x19, x19, x1
    9164:	39400260 	ldrb	w0, [x19]
    9168:	34000100 	cbz	w0, 9188 <fwp_hof0.constprop.0+0xfd8>
    916c:	7100041f 	cmp	w0, #0x1
    9170:	54003940 	b.eq	9898 <fwp_hof0.constprop.0+0x16e8>  // b.none
    9174:	7103fc1f 	cmp	w0, #0xff
    9178:	54004a80 	b.eq	9ac8 <fwp_hof0.constprop.0+0x1918>  // b.none
    917c:	51000400 	sub	w0, w0, #0x1
    9180:	39000260 	strb	w0, [x19]
    9184:	d503201f 	nop
    9188:	f94007e0 	ldr	x0, [sp, #8]
    918c:	b4001aa0 	cbz	x0, 94e0 <fwp_hof0.constprop.0+0x1330>
    9190:	f94007e0 	ldr	x0, [sp, #8]
    9194:	f100041a 	subs	x26, x0, #0x1
    9198:	f90007fa 	str	x26, [sp, #8]
    919c:	54005986 	b.vs	9ccc <fwp_hof0.constprop.0+0x1b1c>
    91a0:	9117c280 	add	x0, x20, #0x5f0
    91a4:	aa1b03f6 	mov	x22, x27
    91a8:	f949ec03 	ldr	x3, [x0, #5080]
    91ac:	f949d801 	ldr	x1, [x0, #5040]
    91b0:	d370bc63 	lsl	x3, x3, #16
    91b4:	17fffc45 	b	82c8 <fwp_hof0.constprop.0+0x118>
    91b8:	f94003e4 	ldr	x4, [sp]
    91bc:	f949ee62 	ldr	x2, [x19, #5080]
    91c0:	aa0403e0 	mov	x0, x4
    91c4:	f9400083 	ldr	x3, [x4]
    91c8:	f949da61 	ldr	x1, [x19, #5040]
    91cc:	d370bc42 	lsl	x2, x2, #16
    91d0:	cb010087 	sub	x7, x4, x1
    91d4:	b7f82de3 	tbnz	x3, #63, 9790 <fwp_hof0.constprop.0+0x15e0>
    91d8:	eb07005f 	cmp	x2, x7
    91dc:	54fff969 	b.ls	9108 <fwp_hof0.constprop.0+0xf58>  // b.plast
    91e0:	d350fce3 	lsr	x3, x7, #16
    91e4:	8b030863 	add	x3, x3, x3, lsl #2
    91e8:	d37df063 	lsl	x3, x3, #3
    91ec:	8b0300a6 	add	x6, x5, x3
    91f0:	f94010c4 	ldr	x4, [x6, #32]
    91f4:	b4fff8a4 	cbz	x4, 9108 <fwp_hof0.constprop.0+0xf58>
    91f8:	386368a3 	ldrb	w3, [x5, x3]
    91fc:	7100087f 	cmp	w3, #0x2
    9200:	540039c0 	b.eq	9938 <fwp_hof0.constprop.0+0x1788>  // b.none
    9204:	7100047f 	cmp	w3, #0x1
    9208:	54fff801 	b.ne	9108 <fwp_hof0.constprop.0+0xf58>  // b.any
    920c:	29430cc5 	ldp	w5, w3, [x6, #24]
    9210:	92403ce0 	and	x0, x7, #0xffff
    9214:	9b057c00 	mul	x0, x0, x5
    9218:	d360fc00 	lsr	x0, x0, #32
    921c:	eb03001f 	cmp	x0, x3
    9220:	54fff742 	b.cs	9108 <fwp_hof0.constprop.0+0xf58>  // b.hs, b.nlast
    9224:	8b000084 	add	x4, x4, x0
    9228:	39400080 	ldrb	w0, [x4]
    922c:	7100041f 	cmp	w0, #0x1
    9230:	54fff6c1 	b.ne	9108 <fwp_hof0.constprop.0+0xf58>  // b.any
    9234:	f94003e0 	ldr	x0, [sp]
    9238:	97ffee42 	bl	4b40 <fwp_mem_free>
    923c:	9117c280 	add	x0, x20, #0x5f0
    9240:	f949ec02 	ldr	x2, [x0, #5080]
    9244:	f949d801 	ldr	x1, [x0, #5040]
    9248:	d370bc42 	lsl	x2, x2, #16
    924c:	17ffffaf 	b	9108 <fwp_hof0.constprop.0+0xf58>
    9250:	aa1703e0 	mov	x0, x23
    9254:	97ffed9b 	bl	48c0 <fwp_rc_forget_slot>
    9258:	17ffff69 	b	8ffc <fwp_hof0.constprop.0+0xe4c>
    925c:	72003c3f 	tst	w1, #0xffff
    9260:	54ffed01 	b.ne	9000 <fwp_hof0.constprop.0+0xe50>  // b.any
    9264:	17ffff63 	b	8ff0 <fwp_hof0.constprop.0+0xe40>
    9268:	72003c3f 	tst	w1, #0xffff
    926c:	54ffd780 	b.eq	8d5c <fwp_hof0.constprop.0+0xbac>  // b.none
    9270:	b4001096 	cbz	x22, 9480 <fwp_hof0.constprop.0+0x12d0>
    9274:	aa1603f3 	mov	x19, x22
    9278:	d2800018 	mov	x24, #0x0                   	// #0
    927c:	d503201f 	nop
    9280:	f9400a73 	ldr	x19, [x19, #16]
    9284:	aa1803e0 	mov	x0, x24
    9288:	91000718 	add	x24, x24, #0x1
    928c:	b5ffffb3 	cbnz	x19, 9280 <fwp_hof0.constprop.0+0x10d0>
    9290:	f9001be5 	str	x5, [sp, #48]
    9294:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9298:	eb01031f 	cmp	x24, x1
    929c:	54004dc8 	b.hi	9c54 <fwp_hof0.constprop.0+0x1aa4>  // b.pmore
    92a0:	91000800 	add	x0, x0, #0x2
    92a4:	52800041 	mov	w1, #0x2                   	// #2
    92a8:	d37df000 	lsl	x0, x0, #3
    92ac:	97ffef45 	bl	4fc0 <fwp_heap_alloc>
    92b0:	f9401be5 	ldr	x5, [sp, #48]
    92b4:	aa0003fc 	mov	x28, x0
    92b8:	aa1603e1 	mov	x1, x22
    92bc:	eb05031f 	cmp	x24, x5
    92c0:	9a859305 	csel	x5, x24, x5, ls	// ls = plast
    92c4:	d503201f 	nop
    92c8:	f9400420 	ldr	x0, [x1, #8]
    92cc:	f8337b80 	str	x0, [x28, x19, lsl #3]
    92d0:	91000673 	add	x19, x19, #0x1
    92d4:	f9400821 	ldr	x1, [x1, #16]
    92d8:	b5ffff81 	cbnz	x1, 92c8 <fwp_hof0.constprop.0+0x1118>
    92dc:	b4000da5 	cbz	x5, 9490 <fwp_hof0.constprop.0+0x12e0>
    92e0:	f9400360 	ldr	x0, [x27]
    92e4:	b90033ff 	str	wzr, [sp, #48]
    92e8:	17fffea5 	b	8d7c <fwp_hof0.constprop.0+0xbcc>
    92ec:	d53bd040 	mrs	x0, tpidr_el0
    92f0:	91400000 	add	x0, x0, #0x0, lsl #12
    92f4:	91004000 	add	x0, x0, #0x10
    92f8:	f9400000 	ldr	x0, [x0]
    92fc:	b4002900 	cbz	x0, 981c <fwp_hof0.constprop.0+0x166c>
    9300:	f94017e1 	ldr	x1, [sp, #40]
    9304:	97ffe978 	bl	38e4 <fwp_closure_drop_push>
    9308:	b5ff87b6 	cbnz	x22, 83fc <fwp_hof0.constprop.0+0x24c>
    930c:	9101c2b7 	add	x23, x21, #0x70
    9310:	52800000 	mov	w0, #0x0                   	// #0
    9314:	97ffe8d7 	bl	3670 <descent_phase_step>
    9318:	d2800013 	mov	x19, #0x0                   	// #0
    931c:	b94366e0 	ldr	w0, [x23, #868]
    9320:	35ff88a0 	cbnz	w0, 8434 <fwp_hof0.constprop.0+0x284>
    9324:	d503201f 	nop
    9328:	b0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0xa0>
    932c:	91024000 	add	x0, x0, #0x90
    9330:	94000f20 	bl	cfb0 <atexit>
    9334:	35ffc6a0 	cbnz	w0, 8c08 <fwp_hof0.constprop.0+0xa58>
    9338:	52800020 	mov	w0, #0x1                   	// #1
    933c:	b90366e0 	str	w0, [x23, #868]
    9340:	9101c2a0 	add	x0, x21, #0x70
    9344:	f9404817 	ldr	x23, [x0, #144]
    9348:	f9408418 	ldr	x24, [x0, #264]
    934c:	eb17031f 	cmp	x24, x23
    9350:	54ff87cb 	b.lt	8448 <fwp_hof0.constprop.0+0x298>  // b.tstop
    9354:	d503201f 	nop
    9358:	eb17031f 	cmp	x24, x23
    935c:	54ff8940 	b.eq	8484 <fwp_hof0.constprop.0+0x2d4>  // b.none
    9360:	f9403abb 	ldr	x27, [x21, #112]
    9364:	8b180717 	add	x23, x24, x24, lsl #1
    9368:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    936c:	910b4000 	add	x0, x0, #0x2d0
    9370:	8b170b17 	add	x23, x24, x23, lsl #2
    9374:	8b170f77 	add	x23, x27, x23, lsl #3
    9378:	f90032ff 	str	xzr, [x23, #96]
    937c:	97ffe5c9 	bl	2aa0 <getenv@plt>
    9380:	b5ff8d60 	cbnz	x0, 852c <fwp_hof0.constprop.0+0x37c>
    9384:	9101c2a0 	add	x0, x21, #0x70
    9388:	f9407801 	ldr	x1, [x0, #240]
    938c:	b4ff8da1 	cbz	x1, 8540 <fwp_hof0.constprop.0+0x390>
    9390:	3ccb8002 	ldur	q2, [x0, #184]
    9394:	9102e001 	add	x1, x0, #0xb8
    9398:	3ccc8001 	ldur	q1, [x0, #200]
    939c:	f900781f 	str	xzr, [x0, #240]
    93a0:	4f000400 	movi	v0.4s, #0x0
    93a4:	ad0106e2 	stp	q2, q1, [x23, #32]
    93a8:	a94d8002 	ldp	x2, x0, [x0, #216]
    93ac:	f9000ee0 	str	x0, [x23, #24]
    93b0:	f9401820 	ldr	x0, [x1, #48]
    93b4:	f90022e2 	str	x2, [x23, #64]
    93b8:	f90026e0 	str	x0, [x23, #72]
    93bc:	ad000020 	stp	q0, q0, [x1]
    93c0:	3d800820 	str	q0, [x1, #32]
    93c4:	f900183f 	str	xzr, [x1, #48]
    93c8:	17fffc5e 	b	8540 <fwp_hof0.constprop.0+0x390>
    93cc:	72003c1f 	tst	w0, #0xffff
    93d0:	54ffbc80 	b.eq	8b60 <fwp_hof0.constprop.0+0x9b0>  // b.none
    93d4:	d503201f 	nop
    93d8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    93dc:	eb00031f 	cmp	x24, x0
    93e0:	540044c8 	b.hi	9c78 <fwp_hof0.constprop.0+0x1ac8>  // b.pmore
    93e4:	91000700 	add	x0, x24, #0x1
    93e8:	52800021 	mov	w1, #0x1                   	// #1
    93ec:	d37df000 	lsl	x0, x0, #3
    93f0:	97ffeef4 	bl	4fc0 <fwp_heap_alloc>
    93f4:	9117c282 	add	x2, x20, #0x5f0
    93f8:	f9000018 	str	x24, [x0]
    93fc:	aa0003fb 	mov	x27, x0
    9400:	f90003fb 	str	x27, [sp]
    9404:	f949d841 	ldr	x1, [x2, #5040]
    9408:	f949ec40 	ldr	x0, [x2, #5080]
    940c:	cb010361 	sub	x1, x27, x1
    9410:	eb00403f 	cmp	x1, x0, lsl #16
    9414:	54000322 	b.cs	9478 <fwp_hof0.constprop.0+0x12c8>  // b.hs, b.nlast
    9418:	d350fc20 	lsr	x0, x1, #16
    941c:	f949fc44 	ldr	x4, [x2, #5112]
    9420:	8b000800 	add	x0, x0, x0, lsl #2
    9424:	d37df002 	lsl	x2, x0, #3
    9428:	8b020083 	add	x3, x4, x2
    942c:	f9401077 	ldr	x23, [x3, #32]
    9430:	b4000257 	cbz	x23, 9478 <fwp_hof0.constprop.0+0x12c8>
    9434:	38626882 	ldrb	w2, [x4, x2]
    9438:	7100085f 	cmp	w2, #0x2
    943c:	54002840 	b.eq	9944 <fwp_hof0.constprop.0+0x1794>  // b.none
    9440:	7100045f 	cmp	w2, #0x1
    9444:	540001a1 	b.ne	9478 <fwp_hof0.constprop.0+0x12c8>  // b.any
    9448:	29430864 	ldp	w4, w2, [x3, #24]
    944c:	92403c21 	and	x1, x1, #0xffff
    9450:	9b047c21 	mul	x1, x1, x4
    9454:	d360fc21 	lsr	x1, x1, #32
    9458:	eb02003f 	cmp	x1, x2
    945c:	540000e2 	b.cs	9478 <fwp_hof0.constprop.0+0x12c8>  // b.hs, b.nlast
    9460:	8b0102f7 	add	x23, x23, x1
    9464:	394002e1 	ldrb	w1, [x23]
    9468:	7103fc3f 	cmp	w1, #0xff
    946c:	54002740 	b.eq	9954 <fwp_hof0.constprop.0+0x17a4>  // b.none
    9470:	52800021 	mov	w1, #0x1                   	// #1
    9474:	390002e1 	strb	w1, [x23]
    9478:	aa1303e0 	mov	x0, x19
    947c:	17fffdbf 	b	8b78 <fwp_hof0.constprop.0+0x9c8>
    9480:	52800041 	mov	w1, #0x2                   	// #2
    9484:	d2800100 	mov	x0, #0x8                   	// #8
    9488:	97ffeece 	bl	4fc0 <fwp_heap_alloc>
    948c:	aa0003fc 	mov	x28, x0
    9490:	d280001b 	mov	x27, #0x0                   	// #0
    9494:	17fffef3 	b	9060 <fwp_hof0.constprop.0+0xeb0>
    9498:	52800041 	mov	w1, #0x2                   	// #2
    949c:	d2800100 	mov	x0, #0x8                   	// #8
    94a0:	97ffeec8 	bl	4fc0 <fwp_heap_alloc>
    94a4:	aa0003f8 	mov	x24, x0
    94a8:	9117c280 	add	x0, x20, #0x5f0
    94ac:	aa1803fb 	mov	x27, x24
    94b0:	f900031f 	str	xzr, [x24]
    94b4:	f949d801 	ldr	x1, [x0, #5040]
    94b8:	f949ec00 	ldr	x0, [x0, #5080]
    94bc:	cb010301 	sub	x1, x24, x1
    94c0:	eb00403f 	cmp	x1, x0, lsl #16
    94c4:	540010a2 	b.cs	96d8 <fwp_hof0.constprop.0+0x1528>  // b.hs, b.nlast
    94c8:	d2800017 	mov	x23, #0x0                   	// #0
    94cc:	17fffc63 	b	8658 <fwp_hof0.constprop.0+0x4a8>
    94d0:	f9001fe0 	str	x0, [sp, #56]
    94d4:	97ffecfb 	bl	48c0 <fwp_rc_forget_slot>
    94d8:	f9401fe0 	ldr	x0, [sp, #56]
    94dc:	17fffe7d 	b	8ed0 <fwp_hof0.constprop.0+0xd20>
    94e0:	f9400be0 	ldr	x0, [sp, #16]
    94e4:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xedf8>
    94e8:	910aa042 	add	x2, x2, #0x2a8
    94ec:	aa1b03e1 	mov	x1, x27
    94f0:	91014042 	add	x2, x2, #0x50
    94f4:	52800023 	mov	w3, #0x1                   	// #1
    94f8:	a9097fff 	stp	xzr, xzr, [sp, #144]
    94fc:	f90053ff 	str	xzr, [sp, #160]
    9500:	97fff730 	bl	71c0 <fwp_write>
    9504:	a9495ff6 	ldp	x22, x23, [sp, #144]
    9508:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    950c:	912cc000 	add	x0, x0, #0xb30
    9510:	f10002df 	cmp	x22, #0x0
    9514:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9518:	b1002aff 	cmn	x23, #0xa
    951c:	54003a88 	b.hi	9c6c <fwp_hof0.constprop.0+0x1abc>  // b.pmore
    9520:	910026e0 	add	x0, x23, #0x9
    9524:	52800021 	mov	w1, #0x1                   	// #1
    9528:	97ffeea6 	bl	4fc0 <fwp_heap_alloc>
    952c:	aa0003f8 	mov	x24, x0
    9530:	aa0003f3 	mov	x19, x0
    9534:	aa1703e2 	mov	x2, x23
    9538:	aa1603e1 	mov	x1, x22
    953c:	f8008717 	str	x23, [x24], #8
    9540:	8b170277 	add	x23, x19, x23
    9544:	aa1803e0 	mov	x0, x24
    9548:	97ffe486 	bl	2760 <memcpy@plt>
    954c:	390022ff 	strb	wzr, [x23, #8]
    9550:	f9404be0 	ldr	x0, [sp, #144]
    9554:	97ffe51f 	bl	29d0 <free@plt>
    9558:	9117c281 	add	x1, x20, #0x5f0
    955c:	f949d822 	ldr	x2, [x1, #5040]
    9560:	f949ec20 	ldr	x0, [x1, #5080]
    9564:	cb020262 	sub	x2, x19, x2
    9568:	eb00405f 	cmp	x2, x0, lsl #16
    956c:	54000322 	b.cs	95d0 <fwp_hof0.constprop.0+0x1420>  // b.hs, b.nlast
    9570:	d350fc40 	lsr	x0, x2, #16
    9574:	f949fc23 	ldr	x3, [x1, #5112]
    9578:	8b000800 	add	x0, x0, x0, lsl #2
    957c:	d37df001 	lsl	x1, x0, #3
    9580:	8b010060 	add	x0, x3, x1
    9584:	f9401016 	ldr	x22, [x0, #32]
    9588:	b4000256 	cbz	x22, 95d0 <fwp_hof0.constprop.0+0x1420>
    958c:	38616861 	ldrb	w1, [x3, x1]
    9590:	7100083f 	cmp	w1, #0x2
    9594:	54002cc0 	b.eq	9b2c <fwp_hof0.constprop.0+0x197c>  // b.none
    9598:	7100043f 	cmp	w1, #0x1
    959c:	540001a1 	b.ne	95d0 <fwp_hof0.constprop.0+0x1420>  // b.any
    95a0:	29430003 	ldp	w3, w0, [x0, #24]
    95a4:	92403c41 	and	x1, x2, #0xffff
    95a8:	9b037c21 	mul	x1, x1, x3
    95ac:	d360fc21 	lsr	x1, x1, #32
    95b0:	eb00003f 	cmp	x1, x0
    95b4:	540000e2 	b.cs	95d0 <fwp_hof0.constprop.0+0x1420>  // b.hs, b.nlast
    95b8:	8b0102d6 	add	x22, x22, x1
    95bc:	394002c0 	ldrb	w0, [x22]
    95c0:	7103fc1f 	cmp	w0, #0xff
    95c4:	54002be0 	b.eq	9b40 <fwp_hof0.constprop.0+0x1990>  // b.none
    95c8:	52800020 	mov	w0, #0x1                   	// #1
    95cc:	390002c0 	strb	w0, [x22]
    95d0:	9101c2b6 	add	x22, x21, #0x70
    95d4:	aa1b03e0 	mov	x0, x27
    95d8:	97fff1ba 	bl	5cc0 <fwp_drop0>
    95dc:	f9400262 	ldr	x2, [x19]
    95e0:	d2800021 	mov	x1, #0x1                   	// #1
    95e4:	f94006c3 	ldr	x3, [x22, #8]
    95e8:	aa1803e0 	mov	x0, x24
    95ec:	97ffe509 	bl	2a10 <fwrite@plt>
    95f0:	f94006c1 	ldr	x1, [x22, #8]
    95f4:	52800140 	mov	w0, #0xa                   	// #10
    95f8:	97ffe48e 	bl	2830 <fputc@plt>
    95fc:	9117c281 	add	x1, x20, #0x5f0
    9600:	f949d822 	ldr	x2, [x1, #5040]
    9604:	f949ec20 	ldr	x0, [x1, #5080]
    9608:	cb020262 	sub	x2, x19, x2
    960c:	eb00405f 	cmp	x2, x0, lsl #16
    9610:	54000382 	b.cs	9680 <fwp_hof0.constprop.0+0x14d0>  // b.hs, b.nlast
    9614:	d350fc40 	lsr	x0, x2, #16
    9618:	f949fc23 	ldr	x3, [x1, #5112]
    961c:	8b000800 	add	x0, x0, x0, lsl #2
    9620:	d37df001 	lsl	x1, x0, #3
    9624:	8b010060 	add	x0, x3, x1
    9628:	f9401016 	ldr	x22, [x0, #32]
    962c:	b40002b6 	cbz	x22, 9680 <fwp_hof0.constprop.0+0x14d0>
    9630:	38616861 	ldrb	w1, [x3, x1]
    9634:	7100083f 	cmp	w1, #0x2
    9638:	54002740 	b.eq	9b20 <fwp_hof0.constprop.0+0x1970>  // b.none
    963c:	7100043f 	cmp	w1, #0x1
    9640:	54000201 	b.ne	9680 <fwp_hof0.constprop.0+0x14d0>  // b.any
    9644:	29430003 	ldp	w3, w0, [x0, #24]
    9648:	92403c41 	and	x1, x2, #0xffff
    964c:	9b037c21 	mul	x1, x1, x3
    9650:	d360fc21 	lsr	x1, x1, #32
    9654:	eb00003f 	cmp	x1, x0
    9658:	54000142 	b.cs	9680 <fwp_hof0.constprop.0+0x14d0>  // b.hs, b.nlast
    965c:	8b0102d6 	add	x22, x22, x1
    9660:	394002c0 	ldrb	w0, [x22]
    9664:	340000e0 	cbz	w0, 9680 <fwp_hof0.constprop.0+0x14d0>
    9668:	7100041f 	cmp	w0, #0x1
    966c:	54001b20 	b.eq	99d0 <fwp_hof0.constprop.0+0x1820>  // b.none
    9670:	7103fc1f 	cmp	w0, #0xff
    9674:	54002b20 	b.eq	9bd8 <fwp_hof0.constprop.0+0x1a28>  // b.none
    9678:	51000400 	sub	w0, w0, #0x1
    967c:	390002c0 	strb	w0, [x22]
    9680:	f94027e0 	ldr	x0, [sp, #72]
    9684:	f9400800 	ldr	x0, [x0, #16]
    9688:	f90027e0 	str	x0, [sp, #72]
    968c:	b5ff5cc0 	cbnz	x0, 8224 <fwp_hof0.constprop.0+0x74>
    9690:	a94f53f3 	ldp	x19, x20, [sp, #240]
    9694:	a9505bf5 	ldp	x21, x22, [sp, #256]
    9698:	a95163f7 	ldp	x23, x24, [sp, #272]
    969c:	a9526bf9 	ldp	x25, x26, [sp, #288]
    96a0:	a95373fb 	ldp	x27, x28, [sp, #304]
    96a4:	6d5427e8 	ldp	d8, d9, [sp, #320]
    96a8:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    96ac:	f947f400 	ldr	x0, [x0, #4072]
    96b0:	f9406fe2 	ldr	x2, [sp, #216]
    96b4:	f9400001 	ldr	x1, [x0]
    96b8:	eb010042 	subs	x2, x2, x1
    96bc:	d2800001 	mov	x1, #0x0                   	// #0
    96c0:	54002f81 	b.ne	9cb0 <fwp_hof0.constprop.0+0x1b00>  // b.any
    96c4:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    96c8:	d2800000 	mov	x0, #0x0                   	// #0
    96cc:	910543ff 	add	sp, sp, #0x150
    96d0:	d65f03c0 	ret
    96d4:	b5ff7f77 	cbnz	x23, 86c0 <fwp_hof0.constprop.0+0x510>
    96d8:	d280001c 	mov	x28, #0x0                   	// #0
    96dc:	17fffc20 	b	875c <fwp_hof0.constprop.0+0x5ac>
    96e0:	72003c3f 	tst	w1, #0xffff
    96e4:	54ff8861 	b.ne	87f0 <fwp_hof0.constprop.0+0x640>  // b.any
    96e8:	17fffc3a 	b	87d0 <fwp_hof0.constprop.0+0x620>
    96ec:	72003c7f 	tst	w3, #0xffff
    96f0:	54ffda61 	b.ne	923c <fwp_hof0.constprop.0+0x108c>  // b.any
    96f4:	17fffe78 	b	90d4 <fwp_hof0.constprop.0+0xf24>
    96f8:	f940077b 	ldr	x27, [x27, #8]
    96fc:	eb02007f 	cmp	x3, x2
    9700:	540003a9 	b.ls	9774 <fwp_hof0.constprop.0+0x15c4>  // b.plast
    9704:	d350fc46 	lsr	x6, x2, #16
    9708:	8b0608c6 	add	x6, x6, x6, lsl #2
    970c:	d37df0c6 	lsl	x6, x6, #3
    9710:	8b060088 	add	x8, x4, x6
    9714:	f9401107 	ldr	x7, [x8, #32]
    9718:	b40002e7 	cbz	x7, 9774 <fwp_hof0.constprop.0+0x15c4>
    971c:	38666884 	ldrb	w4, [x4, x6]
    9720:	7100089f 	cmp	w4, #0x2
    9724:	540014a0 	b.eq	99b8 <fwp_hof0.constprop.0+0x1808>  // b.none
    9728:	7100049f 	cmp	w4, #0x1
    972c:	54000241 	b.ne	9774 <fwp_hof0.constprop.0+0x15c4>  // b.any
    9730:	29431106 	ldp	w6, w4, [x8, #24]
    9734:	92403c42 	and	x2, x2, #0xffff
    9738:	9b067c42 	mul	x2, x2, x6
    973c:	d360fc42 	lsr	x2, x2, #32
    9740:	eb04005f 	cmp	x2, x4
    9744:	54000182 	b.cs	9774 <fwp_hof0.constprop.0+0x15c4>  // b.hs, b.nlast
    9748:	8b0200e7 	add	x7, x7, x2
    974c:	394000e2 	ldrb	w2, [x7]
    9750:	7100045f 	cmp	w2, #0x1
    9754:	54000101 	b.ne	9774 <fwp_hof0.constprop.0+0x15c4>  // b.any
    9758:	f90003e5 	str	x5, [sp]
    975c:	97ffecf9 	bl	4b40 <fwp_mem_free>
    9760:	9117c280 	add	x0, x20, #0x5f0
    9764:	f94003e5 	ldr	x5, [sp]
    9768:	f949ec03 	ldr	x3, [x0, #5080]
    976c:	f949d801 	ldr	x1, [x0, #5040]
    9770:	d370bc63 	lsl	x3, x3, #16
    9774:	cb010361 	sub	x1, x27, x1
    9778:	eb03003f 	cmp	x1, x3
    977c:	54ff8043 	b.cc	8784 <fwp_hof0.constprop.0+0x5d4>  // b.lo, b.ul, b.last
    9780:	17fffc1c 	b	87f0 <fwp_hof0.constprop.0+0x640>
    9784:	72003c3f 	tst	w1, #0xffff
    9788:	54ffd001 	b.ne	9188 <fwp_hof0.constprop.0+0xfd8>  // b.any
    978c:	17fffe76 	b	9164 <fwp_hof0.constprop.0+0xfb4>
    9790:	f9400483 	ldr	x3, [x4, #8]
    9794:	f90003e3 	str	x3, [sp]
    9798:	eb07005f 	cmp	x2, x7
    979c:	54000369 	b.ls	9808 <fwp_hof0.constprop.0+0x1658>  // b.plast
    97a0:	d350fce3 	lsr	x3, x7, #16
    97a4:	8b030863 	add	x3, x3, x3, lsl #2
    97a8:	d37df063 	lsl	x3, x3, #3
    97ac:	8b0300a6 	add	x6, x5, x3
    97b0:	f94010c4 	ldr	x4, [x6, #32]
    97b4:	b40002a4 	cbz	x4, 9808 <fwp_hof0.constprop.0+0x1658>
    97b8:	386368a3 	ldrb	w3, [x5, x3]
    97bc:	7100087f 	cmp	w3, #0x2
    97c0:	54001020 	b.eq	99c4 <fwp_hof0.constprop.0+0x1814>  // b.none
    97c4:	7100047f 	cmp	w3, #0x1
    97c8:	54000201 	b.ne	9808 <fwp_hof0.constprop.0+0x1658>  // b.any
    97cc:	294314c8 	ldp	w8, w5, [x6, #24]
    97d0:	92403ce3 	and	x3, x7, #0xffff
    97d4:	9b087c63 	mul	x3, x3, x8
    97d8:	d360fc63 	lsr	x3, x3, #32
    97dc:	eb05007f 	cmp	x3, x5
    97e0:	54000142 	b.cs	9808 <fwp_hof0.constprop.0+0x1658>  // b.hs, b.nlast
    97e4:	8b030084 	add	x4, x4, x3
    97e8:	39400083 	ldrb	w3, [x4]
    97ec:	7100047f 	cmp	w3, #0x1
    97f0:	540000c1 	b.ne	9808 <fwp_hof0.constprop.0+0x1658>  // b.any
    97f4:	97ffecd3 	bl	4b40 <fwp_mem_free>
    97f8:	9117c280 	add	x0, x20, #0x5f0
    97fc:	f949ec02 	ldr	x2, [x0, #5080]
    9800:	f949d801 	ldr	x1, [x0, #5040]
    9804:	d370bc42 	lsl	x2, x2, #16
    9808:	f94003e0 	ldr	x0, [sp]
    980c:	cb010003 	sub	x3, x0, x1
    9810:	eb02007f 	cmp	x3, x2
    9814:	54ffc3a3 	b.cc	9088 <fwp_hof0.constprop.0+0xed8>  // b.lo, b.ul, b.last
    9818:	17fffe3c 	b	9108 <fwp_hof0.constprop.0+0xf58>
    981c:	f94017e0 	ldr	x0, [sp, #40]
    9820:	97ffe8a0 	bl	3aa0 <fwp_closure_drop.part.0>
    9824:	17fffaf5 	b	83f8 <fwp_hof0.constprop.0+0x248>
    9828:	72003c3f 	tst	w1, #0xffff
    982c:	54ff7481 	b.ne	86bc <fwp_hof0.constprop.0+0x50c>  // b.any
    9830:	39400380 	ldrb	w0, [x28]
    9834:	7103fc1f 	cmp	w0, #0xff
    9838:	54ff73e1 	b.ne	86b4 <fwp_hof0.constprop.0+0x504>  // b.any
    983c:	aa1c03e0 	mov	x0, x28
    9840:	97ffec20 	bl	48c0 <fwp_rc_forget_slot>
    9844:	17fffb9c 	b	86b4 <fwp_hof0.constprop.0+0x504>
    9848:	72003c3f 	tst	w1, #0xffff
    984c:	54ff5ac1 	b.ne	83a4 <fwp_hof0.constprop.0+0x1f4>  // b.any
    9850:	aa1303e0 	mov	x0, x19
    9854:	17fffac1 	b	8358 <fwp_hof0.constprop.0+0x1a8>
    9858:	72003c3f 	tst	w1, #0xffff
    985c:	54ff5ce1 	b.ne	83f8 <fwp_hof0.constprop.0+0x248>  // b.any
    9860:	17fffadd 	b	83d4 <fwp_hof0.constprop.0+0x224>
    9864:	aa1903fc 	mov	x28, x25
    9868:	17fffc1a 	b	88d0 <fwp_hof0.constprop.0+0x720>
    986c:	72003c3f 	tst	w1, #0xffff
    9870:	54ff9301 	b.ne	8ad0 <fwp_hof0.constprop.0+0x920>  // b.any
    9874:	394002e0 	ldrb	w0, [x23]
    9878:	7103fc1f 	cmp	w0, #0xff
    987c:	54ff9261 	b.ne	8ac8 <fwp_hof0.constprop.0+0x918>  // b.any
    9880:	aa1703e0 	mov	x0, x23
    9884:	97ffec0f 	bl	48c0 <fwp_rc_forget_slot>
    9888:	17fffc90 	b	8ac8 <fwp_hof0.constprop.0+0x918>
    988c:	72003c5f 	tst	w2, #0xffff
    9890:	54ff7b01 	b.ne	87f0 <fwp_hof0.constprop.0+0x640>  // b.any
    9894:	17fffd04 	b	8ca4 <fwp_hof0.constprop.0+0xaf4>
    9898:	9117c280 	add	x0, x20, #0x5f0
    989c:	f9400ad3 	ldr	x19, [x22, #16]
    98a0:	f949ec04 	ldr	x4, [x0, #5080]
    98a4:	f949d801 	ldr	x1, [x0, #5040]
    98a8:	d370bc84 	lsl	x4, x4, #16
    98ac:	cb0102c0 	sub	x0, x22, x1
    98b0:	eb04001f 	cmp	x0, x4
    98b4:	54000382 	b.cs	9924 <fwp_hof0.constprop.0+0x1774>  // b.hs, b.nlast
    98b8:	d350fc02 	lsr	x2, x0, #16
    98bc:	8b020842 	add	x2, x2, x2, lsl #2
    98c0:	d37df042 	lsl	x2, x2, #3
    98c4:	8b020066 	add	x6, x3, x2
    98c8:	f94010c5 	ldr	x5, [x6, #32]
    98cc:	b40002c5 	cbz	x5, 9924 <fwp_hof0.constprop.0+0x1774>
    98d0:	38626862 	ldrb	w2, [x3, x2]
    98d4:	7100085f 	cmp	w2, #0x2
    98d8:	54000820 	b.eq	99dc <fwp_hof0.constprop.0+0x182c>  // b.none
    98dc:	7100045f 	cmp	w2, #0x1
    98e0:	54000221 	b.ne	9924 <fwp_hof0.constprop.0+0x1774>  // b.any
    98e4:	294308c3 	ldp	w3, w2, [x6, #24]
    98e8:	92403c00 	and	x0, x0, #0xffff
    98ec:	9b037c00 	mul	x0, x0, x3
    98f0:	d360fc00 	lsr	x0, x0, #32
    98f4:	eb02001f 	cmp	x0, x2
    98f8:	54000162 	b.cs	9924 <fwp_hof0.constprop.0+0x1774>  // b.hs, b.nlast
    98fc:	8b0000a5 	add	x5, x5, x0
    9900:	394000a0 	ldrb	w0, [x5]
    9904:	7100041f 	cmp	w0, #0x1
    9908:	540000e1 	b.ne	9924 <fwp_hof0.constprop.0+0x1774>  // b.any
    990c:	aa1603e0 	mov	x0, x22
    9910:	97ffec8c 	bl	4b40 <fwp_mem_free>
    9914:	9117c280 	add	x0, x20, #0x5f0
    9918:	f949ec04 	ldr	x4, [x0, #5080]
    991c:	f949d801 	ldr	x1, [x0, #5040]
    9920:	d370bc84 	lsl	x4, x4, #16
    9924:	cb010261 	sub	x1, x19, x1
    9928:	eb04003f 	cmp	x1, x4
    992c:	54ffc2e2 	b.cs	9188 <fwp_hof0.constprop.0+0xfd8>  // b.hs, b.nlast
    9930:	aa1303f6 	mov	x22, x19
    9934:	17fffdf9 	b	9118 <fwp_hof0.constprop.0+0xf68>
    9938:	72003cff 	tst	w7, #0xffff
    993c:	54ffbe61 	b.ne	9108 <fwp_hof0.constprop.0+0xf58>  // b.any
    9940:	17fffe3a 	b	9228 <fwp_hof0.constprop.0+0x1078>
    9944:	72003c3f 	tst	w1, #0xffff
    9948:	54ffd8e0 	b.eq	9464 <fwp_hof0.constprop.0+0x12b4>  // b.none
    994c:	aa1303e0 	mov	x0, x19
    9950:	17fffc8a 	b	8b78 <fwp_hof0.constprop.0+0x9c8>
    9954:	aa1703e0 	mov	x0, x23
    9958:	97ffebda 	bl	48c0 <fwp_rc_forget_slot>
    995c:	17fffec5 	b	9470 <fwp_hof0.constprop.0+0x12c0>
    9960:	aa0203e0 	mov	x0, x2
    9964:	d2800101 	mov	x1, #0x8                   	// #8
    9968:	f90003e2 	str	x2, [sp]
    996c:	97ffe3e1 	bl	28f0 <calloc@plt>
    9970:	f94003e2 	ldr	x2, [sp]
    9974:	aa0003fa 	mov	x26, x0
    9978:	f9401be5 	ldr	x5, [sp, #48]
    997c:	17fffbe9 	b	8920 <fwp_hof0.constprop.0+0x770>
    9980:	d2800d01 	mov	x1, #0x68                  	// #104
    9984:	d280003c 	mov	x28, #0x1                   	// #1
    9988:	17fffacf 	b	84c4 <fwp_hof0.constprop.0+0x314>
    998c:	f9400360 	ldr	x0, [x27]
    9990:	b7ffd780 	tbnz	x0, #63, 9480 <fwp_hof0.constprop.0+0x12d0>
    9994:	9117c283 	add	x3, x20, #0x5f0
    9998:	f94003e4 	ldr	x4, [sp]
    999c:	f949d861 	ldr	x1, [x3, #5040]
    99a0:	f949ec63 	ldr	x3, [x3, #5080]
    99a4:	cb010081 	sub	x1, x4, x1
    99a8:	eb03403f 	cmp	x1, x3, lsl #16
    99ac:	54ffd6a2 	b.cs	9480 <fwp_hof0.constprop.0+0x12d0>  // b.hs, b.nlast
    99b0:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    99b4:	17fffcd6 	b	8d0c <fwp_hof0.constprop.0+0xb5c>
    99b8:	72003c5f 	tst	w2, #0xffff
    99bc:	54ffedc1 	b.ne	9774 <fwp_hof0.constprop.0+0x15c4>  // b.any
    99c0:	17ffff63 	b	974c <fwp_hof0.constprop.0+0x159c>
    99c4:	72003cff 	tst	w7, #0xffff
    99c8:	54fff201 	b.ne	9808 <fwp_hof0.constprop.0+0x1658>  // b.any
    99cc:	17ffff87 	b	97e8 <fwp_hof0.constprop.0+0x1638>
    99d0:	aa1303e0 	mov	x0, x19
    99d4:	97ffef90 	bl	5814 <fwp_rc_free_arr>
    99d8:	17ffff2a 	b	9680 <fwp_hof0.constprop.0+0x14d0>
    99dc:	72003c1f 	tst	w0, #0xffff
    99e0:	54fffa21 	b.ne	9924 <fwp_hof0.constprop.0+0x1774>  // b.any
    99e4:	17ffffc7 	b	9900 <fwp_hof0.constprop.0+0x1750>
    99e8:	72003c9f 	tst	w4, #0xffff
    99ec:	54ff4681 	b.ne	82bc <fwp_hof0.constprop.0+0x10c>  // b.any
    99f0:	17fffa28 	b	8290 <fwp_hof0.constprop.0+0xe0>
    99f4:	ca584700 	eor	x0, x24, x24, lsr #17
    99f8:	9117c281 	add	x1, x20, #0x5f0
    99fc:	ca402400 	eor	x0, x0, x0, lsr #9
    9a00:	8b200c20 	add	x0, x1, w0, uxtb #3
    9a04:	f94a2400 	ldr	x0, [x0, #5192]
    9a08:	b5000080 	cbnz	x0, 9a18 <fwp_hof0.constprop.0+0x1868>
    9a0c:	14000012 	b	9a54 <fwp_hof0.constprop.0+0x18a4>
    9a10:	f9400800 	ldr	x0, [x0, #16]
    9a14:	b4000200 	cbz	x0, 9a54 <fwp_hof0.constprop.0+0x18a4>
    9a18:	f9400001 	ldr	x1, [x0]
    9a1c:	eb18003f 	cmp	x1, x24
    9a20:	54ffff81 	b.ne	9a10 <fwp_hof0.constprop.0+0x1860>  // b.any
    9a24:	f9400401 	ldr	x1, [x0, #8]
    9a28:	d1000421 	sub	x1, x1, #0x1
    9a2c:	f9000401 	str	x1, [x0, #8]
    9a30:	f103f83f 	cmp	x1, #0xfe
    9a34:	54ff6de1 	b.ne	87f0 <fwp_hof0.constprop.0+0x640>  // b.any
    9a38:	aa1803e0 	mov	x0, x24
    9a3c:	f90003e5 	str	x5, [sp]
    9a40:	97ffeba0 	bl	48c0 <fwp_rc_forget_slot>
    9a44:	f94003e5 	ldr	x5, [sp]
    9a48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9a4c:	39000300 	strb	w0, [x24]
    9a50:	17fffb68 	b	87f0 <fwp_hof0.constprop.0+0x640>
    9a54:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9a58:	910d0000 	add	x0, x0, #0x340
    9a5c:	97ffe789 	bl	3880 <fwp_trap>
    9a60:	ca584700 	eor	x0, x24, x24, lsr #17
    9a64:	9117c281 	add	x1, x20, #0x5f0
    9a68:	ca402400 	eor	x0, x0, x0, lsr #9
    9a6c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9a70:	f94a2401 	ldr	x1, [x0, #5192]
    9a74:	b5000081 	cbnz	x1, 9a84 <fwp_hof0.constprop.0+0x18d4>
    9a78:	17fffff7 	b	9a54 <fwp_hof0.constprop.0+0x18a4>
    9a7c:	f9400821 	ldr	x1, [x1, #16]
    9a80:	b4fffea1 	cbz	x1, 9a54 <fwp_hof0.constprop.0+0x18a4>
    9a84:	f9400020 	ldr	x0, [x1]
    9a88:	eb18001f 	cmp	x0, x24
    9a8c:	54ffff81 	b.ne	9a7c <fwp_hof0.constprop.0+0x18cc>  // b.any
    9a90:	f9400420 	ldr	x0, [x1, #8]
    9a94:	d1000400 	sub	x0, x0, #0x1
    9a98:	f9000420 	str	x0, [x1, #8]
    9a9c:	f103f81f 	cmp	x0, #0xfe
    9aa0:	54ffbce1 	b.ne	923c <fwp_hof0.constprop.0+0x108c>  // b.any
    9aa4:	aa1803e0 	mov	x0, x24
    9aa8:	97ffeb86 	bl	48c0 <fwp_rc_forget_slot>
    9aac:	9117c280 	add	x0, x20, #0x5f0
    9ab0:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9ab4:	39000301 	strb	w1, [x24]
    9ab8:	f949ec02 	ldr	x2, [x0, #5080]
    9abc:	f949d801 	ldr	x1, [x0, #5040]
    9ac0:	d370bc42 	lsl	x2, x2, #16
    9ac4:	17fffd91 	b	9108 <fwp_hof0.constprop.0+0xf58>
    9ac8:	ca534660 	eor	x0, x19, x19, lsr #17
    9acc:	9117c281 	add	x1, x20, #0x5f0
    9ad0:	ca402400 	eor	x0, x0, x0, lsr #9
    9ad4:	8b200c20 	add	x0, x1, w0, uxtb #3
    9ad8:	f94a2400 	ldr	x0, [x0, #5192]
    9adc:	b5000080 	cbnz	x0, 9aec <fwp_hof0.constprop.0+0x193c>
    9ae0:	17ffffdd 	b	9a54 <fwp_hof0.constprop.0+0x18a4>
    9ae4:	f9400800 	ldr	x0, [x0, #16]
    9ae8:	b4fffb60 	cbz	x0, 9a54 <fwp_hof0.constprop.0+0x18a4>
    9aec:	f9400001 	ldr	x1, [x0]
    9af0:	eb01027f 	cmp	x19, x1
    9af4:	54ffff81 	b.ne	9ae4 <fwp_hof0.constprop.0+0x1934>  // b.any
    9af8:	f9400401 	ldr	x1, [x0, #8]
    9afc:	d1000421 	sub	x1, x1, #0x1
    9b00:	f9000401 	str	x1, [x0, #8]
    9b04:	f103f83f 	cmp	x1, #0xfe
    9b08:	54ffb401 	b.ne	9188 <fwp_hof0.constprop.0+0xfd8>  // b.any
    9b0c:	aa1303e0 	mov	x0, x19
    9b10:	97ffeb6c 	bl	48c0 <fwp_rc_forget_slot>
    9b14:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9b18:	39000260 	strb	w0, [x19]
    9b1c:	17fffd9b 	b	9188 <fwp_hof0.constprop.0+0xfd8>
    9b20:	72003c5f 	tst	w2, #0xffff
    9b24:	54ffdae1 	b.ne	9680 <fwp_hof0.constprop.0+0x14d0>  // b.any
    9b28:	17fffece 	b	9660 <fwp_hof0.constprop.0+0x14b0>
    9b2c:	72003c5f 	tst	w2, #0xffff
    9b30:	54ffd501 	b.ne	95d0 <fwp_hof0.constprop.0+0x1420>  // b.any
    9b34:	394002c0 	ldrb	w0, [x22]
    9b38:	7103fc1f 	cmp	w0, #0xff
    9b3c:	54ffd461 	b.ne	95c8 <fwp_hof0.constprop.0+0x1418>  // b.any
    9b40:	aa1603e0 	mov	x0, x22
    9b44:	97ffeb5f 	bl	48c0 <fwp_rc_forget_slot>
    9b48:	17fffea0 	b	95c8 <fwp_hof0.constprop.0+0x1418>
    9b4c:	d280001c 	mov	x28, #0x0                   	// #0
    9b50:	d280001b 	mov	x27, #0x0                   	// #0
    9b54:	17fffd43 	b	9060 <fwp_hof0.constprop.0+0xeb0>
    9b58:	ca534660 	eor	x0, x19, x19, lsr #17
    9b5c:	9117c281 	add	x1, x20, #0x5f0
    9b60:	ca402400 	eor	x0, x0, x0, lsr #9
    9b64:	8b200c20 	add	x0, x1, w0, uxtb #3
    9b68:	f94a2400 	ldr	x0, [x0, #5192]
    9b6c:	b5000080 	cbnz	x0, 9b7c <fwp_hof0.constprop.0+0x19cc>
    9b70:	17ffffb9 	b	9a54 <fwp_hof0.constprop.0+0x18a4>
    9b74:	f9400800 	ldr	x0, [x0, #16]
    9b78:	b4fff6e0 	cbz	x0, 9a54 <fwp_hof0.constprop.0+0x18a4>
    9b7c:	f9400001 	ldr	x1, [x0]
    9b80:	eb13003f 	cmp	x1, x19
    9b84:	54ffff81 	b.ne	9b74 <fwp_hof0.constprop.0+0x19c4>  // b.any
    9b88:	f9400401 	ldr	x1, [x0, #8]
    9b8c:	d1000421 	sub	x1, x1, #0x1
    9b90:	f9000401 	str	x1, [x0, #8]
    9b94:	f103f83f 	cmp	x1, #0xfe
    9b98:	54ff4301 	b.ne	83f8 <fwp_hof0.constprop.0+0x248>  // b.any
    9b9c:	aa1303e0 	mov	x0, x19
    9ba0:	97ffeb48 	bl	48c0 <fwp_rc_forget_slot>
    9ba4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9ba8:	39000260 	strb	w0, [x19]
    9bac:	17fffa13 	b	83f8 <fwp_hof0.constprop.0+0x248>
    9bb0:	97ffeafd 	bl	47a4 <fwp_rc_wide_dup>
    9bb4:	17fff9ef 	b	8370 <fwp_hof0.constprop.0+0x1c0>
    9bb8:	d2800018 	mov	x24, #0x0                   	// #0
    9bbc:	17fffcb3 	b	8e88 <fwp_hof0.constprop.0+0xcd8>
    9bc0:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9bc4:	91108000 	add	x0, x0, #0x420
    9bc8:	97ffe72e 	bl	3880 <fwp_trap>
    9bcc:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9bd0:	910e2000 	add	x0, x0, #0x388
    9bd4:	97ffe72b 	bl	3880 <fwp_trap>
    9bd8:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9bdc:	9117c281 	add	x1, x20, #0x5f0
    9be0:	ca402400 	eor	x0, x0, x0, lsr #9
    9be4:	8b200c20 	add	x0, x1, w0, uxtb #3
    9be8:	f94a2400 	ldr	x0, [x0, #5192]
    9bec:	b5000080 	cbnz	x0, 9bfc <fwp_hof0.constprop.0+0x1a4c>
    9bf0:	17ffff99 	b	9a54 <fwp_hof0.constprop.0+0x18a4>
    9bf4:	f9400800 	ldr	x0, [x0, #16]
    9bf8:	b4fff2e0 	cbz	x0, 9a54 <fwp_hof0.constprop.0+0x18a4>
    9bfc:	f9400001 	ldr	x1, [x0]
    9c00:	eb16003f 	cmp	x1, x22
    9c04:	54ffff81 	b.ne	9bf4 <fwp_hof0.constprop.0+0x1a44>  // b.any
    9c08:	f9400401 	ldr	x1, [x0, #8]
    9c0c:	d1000421 	sub	x1, x1, #0x1
    9c10:	f9000401 	str	x1, [x0, #8]
    9c14:	f103f83f 	cmp	x1, #0xfe
    9c18:	54ffd341 	b.ne	9680 <fwp_hof0.constprop.0+0x14d0>  // b.any
    9c1c:	aa1603e0 	mov	x0, x22
    9c20:	97ffeb28 	bl	48c0 <fwp_rc_forget_slot>
    9c24:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9c28:	390002c0 	strb	w0, [x22]
    9c2c:	17fffe95 	b	9680 <fwp_hof0.constprop.0+0x14d0>
    9c30:	97ffeadd 	bl	47a4 <fwp_rc_wide_dup>
    9c34:	9117c280 	add	x0, x20, #0x5f0
    9c38:	f949ec03 	ldr	x3, [x0, #5080]
    9c3c:	f949d801 	ldr	x1, [x0, #5040]
    9c40:	d370bc63 	lsl	x3, x3, #16
    9c44:	17fff99e 	b	82bc <fwp_hof0.constprop.0+0x10c>
    9c48:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9c4c:	91178000 	add	x0, x0, #0x5e0
    9c50:	97ffe70c 	bl	3880 <fwp_trap>
    9c54:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9c58:	91120000 	add	x0, x0, #0x480
    9c5c:	97ffe709 	bl	3880 <fwp_trap>
    9c60:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9c64:	910f4000 	add	x0, x0, #0x3d0
    9c68:	97ffe706 	bl	3880 <fwp_trap>
    9c6c:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9c70:	91182000 	add	x0, x0, #0x608
    9c74:	97ffe703 	bl	3880 <fwp_trap>
    9c78:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9c7c:	91174000 	add	x0, x0, #0x5d0
    9c80:	97ffe700 	bl	3880 <fwp_trap>
    9c84:	52800020 	mov	w0, #0x1                   	// #1
    9c88:	17fffbd8 	b	8be8 <fwp_hof0.constprop.0+0xa38>
    9c8c:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9c90:	91168000 	add	x0, x0, #0x5a0
    9c94:	97ffe6fb 	bl	3880 <fwp_trap>
    9c98:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9c9c:	91160000 	add	x0, x0, #0x580
    9ca0:	97ffe6f8 	bl	3880 <fwp_trap>
    9ca4:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9ca8:	91188000 	add	x0, x0, #0x620
    9cac:	97ffe6f5 	bl	3880 <fwp_trap>
    9cb0:	a90f53f3 	stp	x19, x20, [sp, #240]
    9cb4:	a9105bf5 	stp	x21, x22, [sp, #256]
    9cb8:	a91163f7 	stp	x23, x24, [sp, #272]
    9cbc:	a9126bf9 	stp	x25, x26, [sp, #288]
    9cc0:	a91373fb 	stp	x27, x28, [sp, #304]
    9cc4:	6d1427e8 	stp	d8, d9, [sp, #320]
    9cc8:	97ffe312 	bl	2910 <__stack_chk_fail@plt>
    9ccc:	97ffe38d 	bl	2b00 <fwp_trap_overflow.constprop.0>
    9cd0:	97ffe324 	bl	2960 <abort@plt>

0000000000009cd4 <f0>:
    9cd4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9cd8:	910003fd 	mov	x29, sp
    9cdc:	a90153f3 	stp	x19, x20, [sp, #16]
    9ce0:	a9025bf5 	stp	x21, x22, [sp, #32]
    9ce4:	a90363f7 	stp	x23, x24, [sp, #48]
    9ce8:	a9046bf9 	stp	x25, x26, [sp, #64]
    9cec:	a90573fb 	stp	x27, x28, [sp, #80]
    9cf0:	d12183ff 	sub	sp, sp, #0x860
    9cf4:	f90203ff 	str	xzr, [sp, #1024]
    9cf8:	f00000a0 	adrp	x0, 20000 <__data_start>
    9cfc:	9101c005 	add	x5, x0, #0x70
    9d00:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9d04:	f947f400 	ldr	x0, [x0, #4072]
    9d08:	90000154 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    9d0c:	f94198a6 	ldr	x6, [x5, #816]
    9d10:	f9400001 	ldr	x1, [x0]
    9d14:	f9042fe1 	str	x1, [sp, #2136]
    9d18:	d2800001 	mov	x1, #0x0                   	// #0
    9d1c:	9117c298 	add	x24, x20, #0x5f0
    9d20:	912123f6 	add	x22, sp, #0x848
    9d24:	910023e0 	add	x0, sp, #0x8
    9d28:	910083e2 	add	x2, sp, #0x20
    9d2c:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x40>
    9d30:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9d34:	912dc021 	add	x1, x1, #0xb70
    9d38:	913f4084 	add	x4, x4, #0xfd0
    9d3c:	d2800013 	mov	x19, #0x0                   	// #0
    9d40:	d2800119 	mov	x25, #0x8                   	// #8
    9d44:	d2800015 	mov	x21, #0x0                   	// #0
    9d48:	52800037 	mov	w23, #0x1                   	// #1
    9d4c:	a90093e6 	stp	x6, x4, [sp, #8]
    9d50:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9d54:	a90307ff 	stp	xzr, x1, [sp, #48]
    9d58:	f90198a0 	str	x0, [x5, #816]
    9d5c:	d503201f 	nop
    9d60:	f100073a 	subs	x26, x25, #0x1
    9d64:	aa1603e1 	mov	x1, x22
    9d68:	da1f02bc 	sbc	x28, x21, xzr
    9d6c:	52800020 	mov	w0, #0x1                   	// #1
    9d70:	f90017fa 	str	x26, [sp, #40]
    9d74:	aa1a03f9 	mov	x25, x26
    9d78:	f90427fa 	str	x26, [sp, #2120]
    9d7c:	aa1c03f5 	mov	x21, x28
    9d80:	f9042bf3 	str	x19, [sp, #2128]
    9d84:	97ffecd4 	bl	50d4 <fwp_data.part.0.constprop.0>
    9d88:	f949db02 	ldr	x2, [x24, #5040]
    9d8c:	aa0003f3 	mov	x19, x0
    9d90:	f949ef00 	ldr	x0, [x24, #5080]
    9d94:	cb020262 	sub	x2, x19, x2
    9d98:	eb00405f 	cmp	x2, x0, lsl #16
    9d9c:	54000302 	b.cs	9dfc <f0+0x128>  // b.hs, b.nlast
    9da0:	d350fc40 	lsr	x0, x2, #16
    9da4:	f949ff04 	ldr	x4, [x24, #5112]
    9da8:	8b000800 	add	x0, x0, x0, lsl #2
    9dac:	d37df001 	lsl	x1, x0, #3
    9db0:	8b010080 	add	x0, x4, x1
    9db4:	f940101b 	ldr	x27, [x0, #32]
    9db8:	b400023b 	cbz	x27, 9dfc <f0+0x128>
    9dbc:	38616881 	ldrb	w1, [x4, x1]
    9dc0:	7100083f 	cmp	w1, #0x2
    9dc4:	54010e00 	b.eq	bf84 <f0+0x22b0>  // b.none
    9dc8:	7100043f 	cmp	w1, #0x1
    9dcc:	54000181 	b.ne	9dfc <f0+0x128>  // b.any
    9dd0:	29430001 	ldp	w1, w0, [x0, #24]
    9dd4:	92403c42 	and	x2, x2, #0xffff
    9dd8:	9b017c42 	mul	x2, x2, x1
    9ddc:	d360fc42 	lsr	x2, x2, #32
    9de0:	eb00005f 	cmp	x2, x0
    9de4:	540000c2 	b.cs	9dfc <f0+0x128>  // b.hs, b.nlast
    9de8:	8b02037b 	add	x27, x27, x2
    9dec:	39400360 	ldrb	w0, [x27]
    9df0:	7103fc1f 	cmp	w0, #0xff
    9df4:	54010c20 	b.eq	bf78 <f0+0x22a4>  // b.none
    9df8:	39000377 	strb	w23, [x27]
    9dfc:	f90013f3 	str	x19, [sp, #32]
    9e00:	aa1c035a 	orr	x26, x26, x28
    9e04:	b5fffafa 	cbnz	x26, 9d60 <f0+0x8c>
    9e08:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x20>
    9e0c:	910103e1 	add	x1, sp, #0x40
    9e10:	f94007e2 	ldr	x2, [sp, #8]
    9e14:	3dc37800 	ldr	q0, [x0, #3552]
    9e18:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e1c:	9101c018 	add	x24, x0, #0x70
    9e20:	52800020 	mov	w0, #0x1                   	// #1
    9e24:	3d8013e0 	str	q0, [sp, #64]
    9e28:	f9019b02 	str	x2, [x24, #816]
    9e2c:	97ffecaa 	bl	50d4 <fwp_data.part.0.constprop.0>
    9e30:	9117c283 	add	x3, x20, #0x5f0
    9e34:	aa0003f5 	mov	x21, x0
    9e38:	f949d861 	ldr	x1, [x3, #5040]
    9e3c:	f949ec60 	ldr	x0, [x3, #5080]
    9e40:	cb0102a1 	sub	x1, x21, x1
    9e44:	eb00403f 	cmp	x1, x0, lsl #16
    9e48:	54000322 	b.cs	9eac <f0+0x1d8>  // b.hs, b.nlast
    9e4c:	d350fc22 	lsr	x2, x1, #16
    9e50:	f949fc63 	ldr	x3, [x3, #5112]
    9e54:	8b020842 	add	x2, x2, x2, lsl #2
    9e58:	d37df042 	lsl	x2, x2, #3
    9e5c:	8b020060 	add	x0, x3, x2
    9e60:	f9401017 	ldr	x23, [x0, #32]
    9e64:	b4000257 	cbz	x23, 9eac <f0+0x1d8>
    9e68:	38626862 	ldrb	w2, [x3, x2]
    9e6c:	7100085f 	cmp	w2, #0x2
    9e70:	54010cc0 	b.eq	c008 <f0+0x2334>  // b.none
    9e74:	7100045f 	cmp	w2, #0x1
    9e78:	540001a1 	b.ne	9eac <f0+0x1d8>  // b.any
    9e7c:	29430002 	ldp	w2, w0, [x0, #24]
    9e80:	92403c21 	and	x1, x1, #0xffff
    9e84:	9b027c21 	mul	x1, x1, x2
    9e88:	d360fc21 	lsr	x1, x1, #32
    9e8c:	eb00003f 	cmp	x1, x0
    9e90:	540000e2 	b.cs	9eac <f0+0x1d8>  // b.hs, b.nlast
    9e94:	8b0102f7 	add	x23, x23, x1
    9e98:	394002e0 	ldrb	w0, [x23]
    9e9c:	7103fc1f 	cmp	w0, #0xff
    9ea0:	54011680 	b.eq	c170 <f0+0x249c>  // b.none
    9ea4:	52800020 	mov	w0, #0x1                   	// #1
    9ea8:	390002e0 	strb	w0, [x23]
    9eac:	910163e1 	add	x1, sp, #0x58
    9eb0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    9eb4:	52800020 	mov	w0, #0x1                   	// #1
    9eb8:	a905d7f7 	stp	x23, x21, [sp, #88]
    9ebc:	97ffec86 	bl	50d4 <fwp_data.part.0.constprop.0>
    9ec0:	97ffee25 	bl	5754 <fwp_rc_fresh>
    9ec4:	aa0003e2 	mov	x2, x0
    9ec8:	9101a3e1 	add	x1, sp, #0x68
    9ecc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    9ed0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    9ed4:	52800020 	mov	w0, #0x1                   	// #1
    9ed8:	a9068bf5 	stp	x21, x2, [sp, #104]
    9edc:	97ffec7e 	bl	50d4 <fwp_data.part.0.constprop.0>
    9ee0:	97ffee1d 	bl	5754 <fwp_rc_fresh>
    9ee4:	aa0003e2 	mov	x2, x0
    9ee8:	9101e3e1 	add	x1, sp, #0x78
    9eec:	52800020 	mov	w0, #0x1                   	// #1
    9ef0:	a9078bf7 	stp	x23, x2, [sp, #120]
    9ef4:	97ffec78 	bl	50d4 <fwp_data.part.0.constprop.0>
    9ef8:	97ffee17 	bl	5754 <fwp_rc_fresh>
    9efc:	aa0003e2 	mov	x2, x0
    9f00:	910223e1 	add	x1, sp, #0x88
    9f04:	52800020 	mov	w0, #0x1                   	// #1
    9f08:	a9088bf5 	stp	x21, x2, [sp, #136]
    9f0c:	97ffec72 	bl	50d4 <fwp_data.part.0.constprop.0>
    9f10:	97ffee11 	bl	5754 <fwp_rc_fresh>
    9f14:	aa0003e2 	mov	x2, x0
    9f18:	910263e1 	add	x1, sp, #0x98
    9f1c:	52800020 	mov	w0, #0x1                   	// #1
    9f20:	a9098bf7 	stp	x23, x2, [sp, #152]
    9f24:	97ffec6c 	bl	50d4 <fwp_data.part.0.constprop.0>
    9f28:	97ffee0b 	bl	5754 <fwp_rc_fresh>
    9f2c:	aa0003e2 	mov	x2, x0
    9f30:	9102a3e1 	add	x1, sp, #0xa8
    9f34:	52800020 	mov	w0, #0x1                   	// #1
    9f38:	a90a8bf5 	stp	x21, x2, [sp, #168]
    9f3c:	97ffec66 	bl	50d4 <fwp_data.part.0.constprop.0>
    9f40:	97ffee05 	bl	5754 <fwp_rc_fresh>
    9f44:	aa0003e2 	mov	x2, x0
    9f48:	9102e3e1 	add	x1, sp, #0xb8
    9f4c:	52800020 	mov	w0, #0x1                   	// #1
    9f50:	a90b8bf7 	stp	x23, x2, [sp, #184]
    9f54:	97ffec60 	bl	50d4 <fwp_data.part.0.constprop.0>
    9f58:	97ffedff 	bl	5754 <fwp_rc_fresh>
    9f5c:	aa0003e2 	mov	x2, x0
    9f60:	910323e1 	add	x1, sp, #0xc8
    9f64:	52800020 	mov	w0, #0x1                   	// #1
    9f68:	a90c8bf5 	stp	x21, x2, [sp, #200]
    9f6c:	97ffec5a 	bl	50d4 <fwp_data.part.0.constprop.0>
    9f70:	97ffedf9 	bl	5754 <fwp_rc_fresh>
    9f74:	aa0003e2 	mov	x2, x0
    9f78:	910363e1 	add	x1, sp, #0xd8
    9f7c:	52800020 	mov	w0, #0x1                   	// #1
    9f80:	a90d8bf7 	stp	x23, x2, [sp, #216]
    9f84:	97ffec54 	bl	50d4 <fwp_data.part.0.constprop.0>
    9f88:	97ffedf3 	bl	5754 <fwp_rc_fresh>
    9f8c:	aa0003e2 	mov	x2, x0
    9f90:	9103a3e1 	add	x1, sp, #0xe8
    9f94:	52800020 	mov	w0, #0x1                   	// #1
    9f98:	a90e8bf5 	stp	x21, x2, [sp, #232]
    9f9c:	97ffec4e 	bl	50d4 <fwp_data.part.0.constprop.0>
    9fa0:	97ffeded 	bl	5754 <fwp_rc_fresh>
    9fa4:	aa0003e2 	mov	x2, x0
    9fa8:	9103e3e1 	add	x1, sp, #0xf8
    9fac:	52800020 	mov	w0, #0x1                   	// #1
    9fb0:	a90f8bf7 	stp	x23, x2, [sp, #248]
    9fb4:	97ffec48 	bl	50d4 <fwp_data.part.0.constprop.0>
    9fb8:	97ffede7 	bl	5754 <fwp_rc_fresh>
    9fbc:	aa0003e2 	mov	x2, x0
    9fc0:	910423e1 	add	x1, sp, #0x108
    9fc4:	52800020 	mov	w0, #0x1                   	// #1
    9fc8:	a9108bf5 	stp	x21, x2, [sp, #264]
    9fcc:	97ffec42 	bl	50d4 <fwp_data.part.0.constprop.0>
    9fd0:	97ffede1 	bl	5754 <fwp_rc_fresh>
    9fd4:	aa0003e2 	mov	x2, x0
    9fd8:	910463e1 	add	x1, sp, #0x118
    9fdc:	52800020 	mov	w0, #0x1                   	// #1
    9fe0:	a9118bf7 	stp	x23, x2, [sp, #280]
    9fe4:	97ffec3c 	bl	50d4 <fwp_data.part.0.constprop.0>
    9fe8:	97ffeddb 	bl	5754 <fwp_rc_fresh>
    9fec:	aa0003e2 	mov	x2, x0
    9ff0:	9104a3e1 	add	x1, sp, #0x128
    9ff4:	52800020 	mov	w0, #0x1                   	// #1
    9ff8:	a9128bf5 	stp	x21, x2, [sp, #296]
    9ffc:	97ffec36 	bl	50d4 <fwp_data.part.0.constprop.0>
    a000:	97ffedd5 	bl	5754 <fwp_rc_fresh>
    a004:	aa0003e2 	mov	x2, x0
    a008:	9104e3e1 	add	x1, sp, #0x138
    a00c:	52800020 	mov	w0, #0x1                   	// #1
    a010:	a9138bf7 	stp	x23, x2, [sp, #312]
    a014:	97ffec30 	bl	50d4 <fwp_data.part.0.constprop.0>
    a018:	97ffedcf 	bl	5754 <fwp_rc_fresh>
    a01c:	aa0003e2 	mov	x2, x0
    a020:	910523e1 	add	x1, sp, #0x148
    a024:	52800020 	mov	w0, #0x1                   	// #1
    a028:	a9148bf5 	stp	x21, x2, [sp, #328]
    a02c:	97ffec2a 	bl	50d4 <fwp_data.part.0.constprop.0>
    a030:	97ffedc9 	bl	5754 <fwp_rc_fresh>
    a034:	aa0003e2 	mov	x2, x0
    a038:	910563e1 	add	x1, sp, #0x158
    a03c:	52800020 	mov	w0, #0x1                   	// #1
    a040:	a9158bf7 	stp	x23, x2, [sp, #344]
    a044:	97ffec24 	bl	50d4 <fwp_data.part.0.constprop.0>
    a048:	97ffedc3 	bl	5754 <fwp_rc_fresh>
    a04c:	aa0003e2 	mov	x2, x0
    a050:	9105a3e1 	add	x1, sp, #0x168
    a054:	52800020 	mov	w0, #0x1                   	// #1
    a058:	a9168bf5 	stp	x21, x2, [sp, #360]
    a05c:	97ffec1e 	bl	50d4 <fwp_data.part.0.constprop.0>
    a060:	97ffedbd 	bl	5754 <fwp_rc_fresh>
    a064:	aa0003e2 	mov	x2, x0
    a068:	9105e3e1 	add	x1, sp, #0x178
    a06c:	52800020 	mov	w0, #0x1                   	// #1
    a070:	a9178bf7 	stp	x23, x2, [sp, #376]
    a074:	97ffec18 	bl	50d4 <fwp_data.part.0.constprop.0>
    a078:	97ffedb7 	bl	5754 <fwp_rc_fresh>
    a07c:	aa0003e2 	mov	x2, x0
    a080:	910623e1 	add	x1, sp, #0x188
    a084:	52800020 	mov	w0, #0x1                   	// #1
    a088:	a9188bf5 	stp	x21, x2, [sp, #392]
    a08c:	97ffec12 	bl	50d4 <fwp_data.part.0.constprop.0>
    a090:	9117c283 	add	x3, x20, #0x5f0
    a094:	aa0003f5 	mov	x21, x0
    a098:	f949d861 	ldr	x1, [x3, #5040]
    a09c:	f949ec60 	ldr	x0, [x3, #5080]
    a0a0:	cb0102a1 	sub	x1, x21, x1
    a0a4:	eb00403f 	cmp	x1, x0, lsl #16
    a0a8:	54000322 	b.cs	a10c <f0+0x438>  // b.hs, b.nlast
    a0ac:	d350fc22 	lsr	x2, x1, #16
    a0b0:	f949fc63 	ldr	x3, [x3, #5112]
    a0b4:	8b020842 	add	x2, x2, x2, lsl #2
    a0b8:	d37df042 	lsl	x2, x2, #3
    a0bc:	8b020060 	add	x0, x3, x2
    a0c0:	f9401017 	ldr	x23, [x0, #32]
    a0c4:	b4000257 	cbz	x23, a10c <f0+0x438>
    a0c8:	38626862 	ldrb	w2, [x3, x2]
    a0cc:	7100085f 	cmp	w2, #0x2
    a0d0:	5400f960 	b.eq	bffc <f0+0x2328>  // b.none
    a0d4:	7100045f 	cmp	w2, #0x1
    a0d8:	540001a1 	b.ne	a10c <f0+0x438>  // b.any
    a0dc:	29430002 	ldp	w2, w0, [x0, #24]
    a0e0:	92403c21 	and	x1, x1, #0xffff
    a0e4:	9b027c21 	mul	x1, x1, x2
    a0e8:	d360fc21 	lsr	x1, x1, #32
    a0ec:	eb00003f 	cmp	x1, x0
    a0f0:	540000e2 	b.cs	a10c <f0+0x438>  // b.hs, b.nlast
    a0f4:	8b0102f7 	add	x23, x23, x1
    a0f8:	394002e0 	ldrb	w0, [x23]
    a0fc:	7103fc1f 	cmp	w0, #0xff
    a100:	540103e0 	b.eq	c17c <f0+0x24a8>  // b.none
    a104:	52800020 	mov	w0, #0x1                   	// #1
    a108:	390002e0 	strb	w0, [x23]
    a10c:	910663e1 	add	x1, sp, #0x198
    a110:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a114:	52800020 	mov	w0, #0x1                   	// #1
    a118:	a919d7f7 	stp	x23, x21, [sp, #408]
    a11c:	97ffebee 	bl	50d4 <fwp_data.part.0.constprop.0>
    a120:	97ffed8d 	bl	5754 <fwp_rc_fresh>
    a124:	aa0003e2 	mov	x2, x0
    a128:	9106a3e1 	add	x1, sp, #0x1a8
    a12c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a130:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a134:	52800020 	mov	w0, #0x1                   	// #1
    a138:	a91a8bf5 	stp	x21, x2, [sp, #424]
    a13c:	97ffebe6 	bl	50d4 <fwp_data.part.0.constprop.0>
    a140:	97ffed85 	bl	5754 <fwp_rc_fresh>
    a144:	aa0003e2 	mov	x2, x0
    a148:	9106e3e1 	add	x1, sp, #0x1b8
    a14c:	52800020 	mov	w0, #0x1                   	// #1
    a150:	a91b8bf7 	stp	x23, x2, [sp, #440]
    a154:	97ffebe0 	bl	50d4 <fwp_data.part.0.constprop.0>
    a158:	97ffed7f 	bl	5754 <fwp_rc_fresh>
    a15c:	aa0003e2 	mov	x2, x0
    a160:	910723e1 	add	x1, sp, #0x1c8
    a164:	52800020 	mov	w0, #0x1                   	// #1
    a168:	a91c8bf5 	stp	x21, x2, [sp, #456]
    a16c:	97ffebda 	bl	50d4 <fwp_data.part.0.constprop.0>
    a170:	9117c283 	add	x3, x20, #0x5f0
    a174:	aa0003f7 	mov	x23, x0
    a178:	f949d861 	ldr	x1, [x3, #5040]
    a17c:	f949ec60 	ldr	x0, [x3, #5080]
    a180:	cb0102e1 	sub	x1, x23, x1
    a184:	eb00403f 	cmp	x1, x0, lsl #16
    a188:	54000322 	b.cs	a1ec <f0+0x518>  // b.hs, b.nlast
    a18c:	d350fc22 	lsr	x2, x1, #16
    a190:	f949fc63 	ldr	x3, [x3, #5112]
    a194:	8b020842 	add	x2, x2, x2, lsl #2
    a198:	d37df042 	lsl	x2, x2, #3
    a19c:	8b020060 	add	x0, x3, x2
    a1a0:	f9401015 	ldr	x21, [x0, #32]
    a1a4:	b4000255 	cbz	x21, a1ec <f0+0x518>
    a1a8:	38626862 	ldrb	w2, [x3, x2]
    a1ac:	7100085f 	cmp	w2, #0x2
    a1b0:	5400f200 	b.eq	bff0 <f0+0x231c>  // b.none
    a1b4:	7100045f 	cmp	w2, #0x1
    a1b8:	540001a1 	b.ne	a1ec <f0+0x518>  // b.any
    a1bc:	29430002 	ldp	w2, w0, [x0, #24]
    a1c0:	92403c21 	and	x1, x1, #0xffff
    a1c4:	9b027c21 	mul	x1, x1, x2
    a1c8:	d360fc21 	lsr	x1, x1, #32
    a1cc:	eb00003f 	cmp	x1, x0
    a1d0:	540000e2 	b.cs	a1ec <f0+0x518>  // b.hs, b.nlast
    a1d4:	8b0102b5 	add	x21, x21, x1
    a1d8:	394002a0 	ldrb	w0, [x21]
    a1dc:	7103fc1f 	cmp	w0, #0xff
    a1e0:	5400fd40 	b.eq	c188 <f0+0x24b4>  // b.none
    a1e4:	52800020 	mov	w0, #0x1                   	// #1
    a1e8:	390002a0 	strb	w0, [x21]
    a1ec:	910763e1 	add	x1, sp, #0x1d8
    a1f0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a1f4:	52800020 	mov	w0, #0x1                   	// #1
    a1f8:	a91ddff5 	stp	x21, x23, [sp, #472]
    a1fc:	97ffebb6 	bl	50d4 <fwp_data.part.0.constprop.0>
    a200:	97ffed55 	bl	5754 <fwp_rc_fresh>
    a204:	aa0003e2 	mov	x2, x0
    a208:	9107a3e1 	add	x1, sp, #0x1e8
    a20c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a210:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a214:	52800020 	mov	w0, #0x1                   	// #1
    a218:	a91e8bf7 	stp	x23, x2, [sp, #488]
    a21c:	97ffebae 	bl	50d4 <fwp_data.part.0.constprop.0>
    a220:	97ffed4d 	bl	5754 <fwp_rc_fresh>
    a224:	aa0003e2 	mov	x2, x0
    a228:	9107e3e1 	add	x1, sp, #0x1f8
    a22c:	52800020 	mov	w0, #0x1                   	// #1
    a230:	a91f8bf5 	stp	x21, x2, [sp, #504]
    a234:	97ffeba8 	bl	50d4 <fwp_data.part.0.constprop.0>
    a238:	97ffed47 	bl	5754 <fwp_rc_fresh>
    a23c:	aa0003e2 	mov	x2, x0
    a240:	910823e1 	add	x1, sp, #0x208
    a244:	52800020 	mov	w0, #0x1                   	// #1
    a248:	f90107f7 	str	x23, [sp, #520]
    a24c:	f9010be2 	str	x2, [sp, #528]
    a250:	97ffeba1 	bl	50d4 <fwp_data.part.0.constprop.0>
    a254:	97ffed40 	bl	5754 <fwp_rc_fresh>
    a258:	aa0003e2 	mov	x2, x0
    a25c:	910863e1 	add	x1, sp, #0x218
    a260:	52800020 	mov	w0, #0x1                   	// #1
    a264:	f9010ff5 	str	x21, [sp, #536]
    a268:	f90113e2 	str	x2, [sp, #544]
    a26c:	97ffeb9a 	bl	50d4 <fwp_data.part.0.constprop.0>
    a270:	97ffed39 	bl	5754 <fwp_rc_fresh>
    a274:	aa0003e2 	mov	x2, x0
    a278:	9108a3e1 	add	x1, sp, #0x228
    a27c:	52800020 	mov	w0, #0x1                   	// #1
    a280:	f90117f7 	str	x23, [sp, #552]
    a284:	f9011be2 	str	x2, [sp, #560]
    a288:	97ffeb93 	bl	50d4 <fwp_data.part.0.constprop.0>
    a28c:	97ffed32 	bl	5754 <fwp_rc_fresh>
    a290:	aa0003e2 	mov	x2, x0
    a294:	9108e3e1 	add	x1, sp, #0x238
    a298:	52800020 	mov	w0, #0x1                   	// #1
    a29c:	f9011ff5 	str	x21, [sp, #568]
    a2a0:	f90123e2 	str	x2, [sp, #576]
    a2a4:	97ffeb8c 	bl	50d4 <fwp_data.part.0.constprop.0>
    a2a8:	9117c283 	add	x3, x20, #0x5f0
    a2ac:	aa0003f5 	mov	x21, x0
    a2b0:	f949d861 	ldr	x1, [x3, #5040]
    a2b4:	f949ec60 	ldr	x0, [x3, #5080]
    a2b8:	cb0102a1 	sub	x1, x21, x1
    a2bc:	eb00403f 	cmp	x1, x0, lsl #16
    a2c0:	54000322 	b.cs	a324 <f0+0x650>  // b.hs, b.nlast
    a2c4:	d350fc22 	lsr	x2, x1, #16
    a2c8:	f949fc63 	ldr	x3, [x3, #5112]
    a2cc:	8b020842 	add	x2, x2, x2, lsl #2
    a2d0:	d37df042 	lsl	x2, x2, #3
    a2d4:	8b020060 	add	x0, x3, x2
    a2d8:	f9401017 	ldr	x23, [x0, #32]
    a2dc:	b4000257 	cbz	x23, a324 <f0+0x650>
    a2e0:	38626862 	ldrb	w2, [x3, x2]
    a2e4:	7100085f 	cmp	w2, #0x2
    a2e8:	5400ea80 	b.eq	c038 <f0+0x2364>  // b.none
    a2ec:	7100045f 	cmp	w2, #0x1
    a2f0:	540001a1 	b.ne	a324 <f0+0x650>  // b.any
    a2f4:	29430002 	ldp	w2, w0, [x0, #24]
    a2f8:	92403c21 	and	x1, x1, #0xffff
    a2fc:	9b027c21 	mul	x1, x1, x2
    a300:	d360fc21 	lsr	x1, x1, #32
    a304:	eb00003f 	cmp	x1, x0
    a308:	540000e2 	b.cs	a324 <f0+0x650>  // b.hs, b.nlast
    a30c:	8b0102f7 	add	x23, x23, x1
    a310:	394002e0 	ldrb	w0, [x23]
    a314:	7103fc1f 	cmp	w0, #0xff
    a318:	5400f3e0 	b.eq	c194 <f0+0x24c0>  // b.none
    a31c:	52800020 	mov	w0, #0x1                   	// #1
    a320:	390002e0 	strb	w0, [x23]
    a324:	910923e1 	add	x1, sp, #0x248
    a328:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a32c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a330:	52800020 	mov	w0, #0x1                   	// #1
    a334:	f90127f7 	str	x23, [sp, #584]
    a338:	f9012bf5 	str	x21, [sp, #592]
    a33c:	97ffeb66 	bl	50d4 <fwp_data.part.0.constprop.0>
    a340:	97ffed05 	bl	5754 <fwp_rc_fresh>
    a344:	aa0003e2 	mov	x2, x0
    a348:	910963e1 	add	x1, sp, #0x258
    a34c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a350:	52800020 	mov	w0, #0x1                   	// #1
    a354:	f9012ff5 	str	x21, [sp, #600]
    a358:	f90133e2 	str	x2, [sp, #608]
    a35c:	97ffeb5e 	bl	50d4 <fwp_data.part.0.constprop.0>
    a360:	97ffecfd 	bl	5754 <fwp_rc_fresh>
    a364:	aa0003e2 	mov	x2, x0
    a368:	9109a3e1 	add	x1, sp, #0x268
    a36c:	52800020 	mov	w0, #0x1                   	// #1
    a370:	f90137f7 	str	x23, [sp, #616]
    a374:	f9013be2 	str	x2, [sp, #624]
    a378:	97ffeb57 	bl	50d4 <fwp_data.part.0.constprop.0>
    a37c:	97ffecf6 	bl	5754 <fwp_rc_fresh>
    a380:	aa0003e2 	mov	x2, x0
    a384:	9109e3e1 	add	x1, sp, #0x278
    a388:	52800020 	mov	w0, #0x1                   	// #1
    a38c:	f9013ff5 	str	x21, [sp, #632]
    a390:	f90143e2 	str	x2, [sp, #640]
    a394:	97ffeb50 	bl	50d4 <fwp_data.part.0.constprop.0>
    a398:	97ffecef 	bl	5754 <fwp_rc_fresh>
    a39c:	aa0003e2 	mov	x2, x0
    a3a0:	910a23e1 	add	x1, sp, #0x288
    a3a4:	52800020 	mov	w0, #0x1                   	// #1
    a3a8:	f90147f7 	str	x23, [sp, #648]
    a3ac:	f9014be2 	str	x2, [sp, #656]
    a3b0:	97ffeb49 	bl	50d4 <fwp_data.part.0.constprop.0>
    a3b4:	97ffece8 	bl	5754 <fwp_rc_fresh>
    a3b8:	aa0003e2 	mov	x2, x0
    a3bc:	910a63e1 	add	x1, sp, #0x298
    a3c0:	52800020 	mov	w0, #0x1                   	// #1
    a3c4:	f9014ff5 	str	x21, [sp, #664]
    a3c8:	f90153e2 	str	x2, [sp, #672]
    a3cc:	97ffeb42 	bl	50d4 <fwp_data.part.0.constprop.0>
    a3d0:	97ffece1 	bl	5754 <fwp_rc_fresh>
    a3d4:	aa0003e2 	mov	x2, x0
    a3d8:	910aa3e1 	add	x1, sp, #0x2a8
    a3dc:	52800020 	mov	w0, #0x1                   	// #1
    a3e0:	f90157f7 	str	x23, [sp, #680]
    a3e4:	f9015be2 	str	x2, [sp, #688]
    a3e8:	97ffeb3b 	bl	50d4 <fwp_data.part.0.constprop.0>
    a3ec:	97ffecda 	bl	5754 <fwp_rc_fresh>
    a3f0:	aa0003e2 	mov	x2, x0
    a3f4:	910ae3e1 	add	x1, sp, #0x2b8
    a3f8:	52800020 	mov	w0, #0x1                   	// #1
    a3fc:	f9015ff5 	str	x21, [sp, #696]
    a400:	f90163e2 	str	x2, [sp, #704]
    a404:	97ffeb34 	bl	50d4 <fwp_data.part.0.constprop.0>
    a408:	9117c283 	add	x3, x20, #0x5f0
    a40c:	aa0003f5 	mov	x21, x0
    a410:	f949d861 	ldr	x1, [x3, #5040]
    a414:	f949ec60 	ldr	x0, [x3, #5080]
    a418:	cb0102a1 	sub	x1, x21, x1
    a41c:	eb00403f 	cmp	x1, x0, lsl #16
    a420:	54000322 	b.cs	a484 <f0+0x7b0>  // b.hs, b.nlast
    a424:	d350fc22 	lsr	x2, x1, #16
    a428:	f949fc63 	ldr	x3, [x3, #5112]
    a42c:	8b020842 	add	x2, x2, x2, lsl #2
    a430:	d37df042 	lsl	x2, x2, #3
    a434:	8b020060 	add	x0, x3, x2
    a438:	f9401017 	ldr	x23, [x0, #32]
    a43c:	b4000257 	cbz	x23, a484 <f0+0x7b0>
    a440:	38626862 	ldrb	w2, [x3, x2]
    a444:	7100085f 	cmp	w2, #0x2
    a448:	5400df20 	b.eq	c02c <f0+0x2358>  // b.none
    a44c:	7100045f 	cmp	w2, #0x1
    a450:	540001a1 	b.ne	a484 <f0+0x7b0>  // b.any
    a454:	29430002 	ldp	w2, w0, [x0, #24]
    a458:	92403c21 	and	x1, x1, #0xffff
    a45c:	9b027c21 	mul	x1, x1, x2
    a460:	d360fc21 	lsr	x1, x1, #32
    a464:	eb00003f 	cmp	x1, x0
    a468:	540000e2 	b.cs	a484 <f0+0x7b0>  // b.hs, b.nlast
    a46c:	8b0102f7 	add	x23, x23, x1
    a470:	394002e0 	ldrb	w0, [x23]
    a474:	7103fc1f 	cmp	w0, #0xff
    a478:	5400e940 	b.eq	c1a0 <f0+0x24cc>  // b.none
    a47c:	52800020 	mov	w0, #0x1                   	// #1
    a480:	390002e0 	strb	w0, [x23]
    a484:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a488:	910b23e1 	add	x1, sp, #0x2c8
    a48c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a490:	52800020 	mov	w0, #0x1                   	// #1
    a494:	f90167e2 	str	x2, [sp, #712]
    a498:	f9016bf5 	str	x21, [sp, #720]
    a49c:	97ffeb0e 	bl	50d4 <fwp_data.part.0.constprop.0>
    a4a0:	9117c283 	add	x3, x20, #0x5f0
    a4a4:	aa0003f5 	mov	x21, x0
    a4a8:	f949d861 	ldr	x1, [x3, #5040]
    a4ac:	f949ec60 	ldr	x0, [x3, #5080]
    a4b0:	cb0102a1 	sub	x1, x21, x1
    a4b4:	eb00403f 	cmp	x1, x0, lsl #16
    a4b8:	54000322 	b.cs	a51c <f0+0x848>  // b.hs, b.nlast
    a4bc:	d350fc22 	lsr	x2, x1, #16
    a4c0:	f949fc63 	ldr	x3, [x3, #5112]
    a4c4:	8b020842 	add	x2, x2, x2, lsl #2
    a4c8:	d37df042 	lsl	x2, x2, #3
    a4cc:	8b020060 	add	x0, x3, x2
    a4d0:	f9401017 	ldr	x23, [x0, #32]
    a4d4:	b4000257 	cbz	x23, a51c <f0+0x848>
    a4d8:	38626862 	ldrb	w2, [x3, x2]
    a4dc:	7100085f 	cmp	w2, #0x2
    a4e0:	5400da00 	b.eq	c020 <f0+0x234c>  // b.none
    a4e4:	7100045f 	cmp	w2, #0x1
    a4e8:	540001a1 	b.ne	a51c <f0+0x848>  // b.any
    a4ec:	29430002 	ldp	w2, w0, [x0, #24]
    a4f0:	92403c21 	and	x1, x1, #0xffff
    a4f4:	9b027c21 	mul	x1, x1, x2
    a4f8:	d360fc21 	lsr	x1, x1, #32
    a4fc:	eb00003f 	cmp	x1, x0
    a500:	540000e2 	b.cs	a51c <f0+0x848>  // b.hs, b.nlast
    a504:	8b0102f7 	add	x23, x23, x1
    a508:	394002e0 	ldrb	w0, [x23]
    a50c:	7103fc1f 	cmp	w0, #0xff
    a510:	5400e4e0 	b.eq	c1ac <f0+0x24d8>  // b.none
    a514:	52800020 	mov	w0, #0x1                   	// #1
    a518:	390002e0 	strb	w0, [x23]
    a51c:	910b63e1 	add	x1, sp, #0x2d8
    a520:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a524:	52800020 	mov	w0, #0x1                   	// #1
    a528:	f9016ff7 	str	x23, [sp, #728]
    a52c:	f90173f5 	str	x21, [sp, #736]
    a530:	97ffeae9 	bl	50d4 <fwp_data.part.0.constprop.0>
    a534:	97ffec88 	bl	5754 <fwp_rc_fresh>
    a538:	aa0003e2 	mov	x2, x0
    a53c:	910ba3e1 	add	x1, sp, #0x2e8
    a540:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a544:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a548:	52800020 	mov	w0, #0x1                   	// #1
    a54c:	f90177f5 	str	x21, [sp, #744]
    a550:	f9017be2 	str	x2, [sp, #752]
    a554:	97ffeae0 	bl	50d4 <fwp_data.part.0.constprop.0>
    a558:	97ffec7f 	bl	5754 <fwp_rc_fresh>
    a55c:	aa0003e2 	mov	x2, x0
    a560:	910be3e1 	add	x1, sp, #0x2f8
    a564:	52800020 	mov	w0, #0x1                   	// #1
    a568:	f9017ff7 	str	x23, [sp, #760]
    a56c:	f90183e2 	str	x2, [sp, #768]
    a570:	97ffead9 	bl	50d4 <fwp_data.part.0.constprop.0>
    a574:	97ffec78 	bl	5754 <fwp_rc_fresh>
    a578:	aa0003e2 	mov	x2, x0
    a57c:	910c23e1 	add	x1, sp, #0x308
    a580:	52800020 	mov	w0, #0x1                   	// #1
    a584:	f90187f5 	str	x21, [sp, #776]
    a588:	f9018be2 	str	x2, [sp, #784]
    a58c:	97ffead2 	bl	50d4 <fwp_data.part.0.constprop.0>
    a590:	9117c283 	add	x3, x20, #0x5f0
    a594:	aa0003f5 	mov	x21, x0
    a598:	f949d861 	ldr	x1, [x3, #5040]
    a59c:	f949ec60 	ldr	x0, [x3, #5080]
    a5a0:	cb0102a1 	sub	x1, x21, x1
    a5a4:	eb00403f 	cmp	x1, x0, lsl #16
    a5a8:	54000322 	b.cs	a60c <f0+0x938>  // b.hs, b.nlast
    a5ac:	d350fc22 	lsr	x2, x1, #16
    a5b0:	f949fc63 	ldr	x3, [x3, #5112]
    a5b4:	8b020842 	add	x2, x2, x2, lsl #2
    a5b8:	d37df042 	lsl	x2, x2, #3
    a5bc:	8b020060 	add	x0, x3, x2
    a5c0:	f9401017 	ldr	x23, [x0, #32]
    a5c4:	b4000257 	cbz	x23, a60c <f0+0x938>
    a5c8:	38626862 	ldrb	w2, [x3, x2]
    a5cc:	7100085f 	cmp	w2, #0x2
    a5d0:	5400d220 	b.eq	c014 <f0+0x2340>  // b.none
    a5d4:	7100045f 	cmp	w2, #0x1
    a5d8:	540001a1 	b.ne	a60c <f0+0x938>  // b.any
    a5dc:	29430002 	ldp	w2, w0, [x0, #24]
    a5e0:	92403c21 	and	x1, x1, #0xffff
    a5e4:	9b027c21 	mul	x1, x1, x2
    a5e8:	d360fc21 	lsr	x1, x1, #32
    a5ec:	eb00003f 	cmp	x1, x0
    a5f0:	540000e2 	b.cs	a60c <f0+0x938>  // b.hs, b.nlast
    a5f4:	8b0102f7 	add	x23, x23, x1
    a5f8:	394002e0 	ldrb	w0, [x23]
    a5fc:	7103fc1f 	cmp	w0, #0xff
    a600:	5400ddc0 	b.eq	c1b8 <f0+0x24e4>  // b.none
    a604:	52800020 	mov	w0, #0x1                   	// #1
    a608:	390002e0 	strb	w0, [x23]
    a60c:	910c63e1 	add	x1, sp, #0x318
    a610:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a614:	52800020 	mov	w0, #0x1                   	// #1
    a618:	f9018fe2 	str	x2, [sp, #792]
    a61c:	f90193f5 	str	x21, [sp, #800]
    a620:	97ffeaad 	bl	50d4 <fwp_data.part.0.constprop.0>
    a624:	97ffec4c 	bl	5754 <fwp_rc_fresh>
    a628:	aa0003e2 	mov	x2, x0
    a62c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a630:	910ca3e1 	add	x1, sp, #0x328
    a634:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a638:	52800020 	mov	w0, #0x1                   	// #1
    a63c:	f90197e3 	str	x3, [sp, #808]
    a640:	f9019be2 	str	x2, [sp, #816]
    a644:	97ffeaa4 	bl	50d4 <fwp_data.part.0.constprop.0>
    a648:	9117c283 	add	x3, x20, #0x5f0
    a64c:	aa0003f5 	mov	x21, x0
    a650:	f949d861 	ldr	x1, [x3, #5040]
    a654:	f949ec60 	ldr	x0, [x3, #5080]
    a658:	cb0102a1 	sub	x1, x21, x1
    a65c:	eb00403f 	cmp	x1, x0, lsl #16
    a660:	54000322 	b.cs	a6c4 <f0+0x9f0>  // b.hs, b.nlast
    a664:	d350fc22 	lsr	x2, x1, #16
    a668:	f949fc63 	ldr	x3, [x3, #5112]
    a66c:	8b020842 	add	x2, x2, x2, lsl #2
    a670:	d37df042 	lsl	x2, x2, #3
    a674:	8b020060 	add	x0, x3, x2
    a678:	f9401017 	ldr	x23, [x0, #32]
    a67c:	b4000257 	cbz	x23, a6c4 <f0+0x9f0>
    a680:	38626862 	ldrb	w2, [x3, x2]
    a684:	7100085f 	cmp	w2, #0x2
    a688:	5400d080 	b.eq	c098 <f0+0x23c4>  // b.none
    a68c:	7100045f 	cmp	w2, #0x1
    a690:	540001a1 	b.ne	a6c4 <f0+0x9f0>  // b.any
    a694:	29430002 	ldp	w2, w0, [x0, #24]
    a698:	92403c21 	and	x1, x1, #0xffff
    a69c:	9b027c21 	mul	x1, x1, x2
    a6a0:	d360fc21 	lsr	x1, x1, #32
    a6a4:	eb00003f 	cmp	x1, x0
    a6a8:	540000e2 	b.cs	a6c4 <f0+0x9f0>  // b.hs, b.nlast
    a6ac:	8b0102f7 	add	x23, x23, x1
    a6b0:	394002e0 	ldrb	w0, [x23]
    a6b4:	7103fc1f 	cmp	w0, #0xff
    a6b8:	5400d860 	b.eq	c1c4 <f0+0x24f0>  // b.none
    a6bc:	52800020 	mov	w0, #0x1                   	// #1
    a6c0:	390002e0 	strb	w0, [x23]
    a6c4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a6c8:	910ce3e1 	add	x1, sp, #0x338
    a6cc:	52800020 	mov	w0, #0x1                   	// #1
    a6d0:	f9019fe2 	str	x2, [sp, #824]
    a6d4:	f901a3f5 	str	x21, [sp, #832]
    a6d8:	97ffea7f 	bl	50d4 <fwp_data.part.0.constprop.0>
    a6dc:	9117c283 	add	x3, x20, #0x5f0
    a6e0:	aa0003f5 	mov	x21, x0
    a6e4:	f949d861 	ldr	x1, [x3, #5040]
    a6e8:	f949ec60 	ldr	x0, [x3, #5080]
    a6ec:	cb0102a1 	sub	x1, x21, x1
    a6f0:	eb00403f 	cmp	x1, x0, lsl #16
    a6f4:	54000322 	b.cs	a758 <f0+0xa84>  // b.hs, b.nlast
    a6f8:	d350fc22 	lsr	x2, x1, #16
    a6fc:	f949fc63 	ldr	x3, [x3, #5112]
    a700:	8b020842 	add	x2, x2, x2, lsl #2
    a704:	d37df042 	lsl	x2, x2, #3
    a708:	8b020060 	add	x0, x3, x2
    a70c:	f9401017 	ldr	x23, [x0, #32]
    a710:	b4000257 	cbz	x23, a758 <f0+0xa84>
    a714:	38626862 	ldrb	w2, [x3, x2]
    a718:	7100085f 	cmp	w2, #0x2
    a71c:	5400cb80 	b.eq	c08c <f0+0x23b8>  // b.none
    a720:	7100045f 	cmp	w2, #0x1
    a724:	540001a1 	b.ne	a758 <f0+0xa84>  // b.any
    a728:	29430002 	ldp	w2, w0, [x0, #24]
    a72c:	92403c21 	and	x1, x1, #0xffff
    a730:	9b027c21 	mul	x1, x1, x2
    a734:	d360fc21 	lsr	x1, x1, #32
    a738:	eb00003f 	cmp	x1, x0
    a73c:	540000e2 	b.cs	a758 <f0+0xa84>  // b.hs, b.nlast
    a740:	8b0102f7 	add	x23, x23, x1
    a744:	394002e0 	ldrb	w0, [x23]
    a748:	7103fc1f 	cmp	w0, #0xff
    a74c:	5400d420 	b.eq	c1d0 <f0+0x24fc>  // b.none
    a750:	52800020 	mov	w0, #0x1                   	// #1
    a754:	390002e0 	strb	w0, [x23]
    a758:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a75c:	910d23e1 	add	x1, sp, #0x348
    a760:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a764:	52800020 	mov	w0, #0x1                   	// #1
    a768:	f901a7e2 	str	x2, [sp, #840]
    a76c:	f901abf5 	str	x21, [sp, #848]
    a770:	97ffea59 	bl	50d4 <fwp_data.part.0.constprop.0>
    a774:	9117c283 	add	x3, x20, #0x5f0
    a778:	aa0003f5 	mov	x21, x0
    a77c:	f949d861 	ldr	x1, [x3, #5040]
    a780:	f949ec60 	ldr	x0, [x3, #5080]
    a784:	cb0102a1 	sub	x1, x21, x1
    a788:	eb00403f 	cmp	x1, x0, lsl #16
    a78c:	54000322 	b.cs	a7f0 <f0+0xb1c>  // b.hs, b.nlast
    a790:	d350fc22 	lsr	x2, x1, #16
    a794:	f949fc63 	ldr	x3, [x3, #5112]
    a798:	8b020842 	add	x2, x2, x2, lsl #2
    a79c:	d37df042 	lsl	x2, x2, #3
    a7a0:	8b020060 	add	x0, x3, x2
    a7a4:	f9401017 	ldr	x23, [x0, #32]
    a7a8:	b4000257 	cbz	x23, a7f0 <f0+0xb1c>
    a7ac:	38626862 	ldrb	w2, [x3, x2]
    a7b0:	7100085f 	cmp	w2, #0x2
    a7b4:	5400c660 	b.eq	c080 <f0+0x23ac>  // b.none
    a7b8:	7100045f 	cmp	w2, #0x1
    a7bc:	540001a1 	b.ne	a7f0 <f0+0xb1c>  // b.any
    a7c0:	29430002 	ldp	w2, w0, [x0, #24]
    a7c4:	92403c21 	and	x1, x1, #0xffff
    a7c8:	9b027c21 	mul	x1, x1, x2
    a7cc:	d360fc21 	lsr	x1, x1, #32
    a7d0:	eb00003f 	cmp	x1, x0
    a7d4:	540000e2 	b.cs	a7f0 <f0+0xb1c>  // b.hs, b.nlast
    a7d8:	8b0102f7 	add	x23, x23, x1
    a7dc:	394002e0 	ldrb	w0, [x23]
    a7e0:	7103fc1f 	cmp	w0, #0xff
    a7e4:	5400cfc0 	b.eq	c1dc <f0+0x2508>  // b.none
    a7e8:	52800020 	mov	w0, #0x1                   	// #1
    a7ec:	390002e0 	strb	w0, [x23]
    a7f0:	910d63e1 	add	x1, sp, #0x358
    a7f4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a7f8:	52800020 	mov	w0, #0x1                   	// #1
    a7fc:	f901afe2 	str	x2, [sp, #856]
    a800:	f901b3f5 	str	x21, [sp, #864]
    a804:	97ffea34 	bl	50d4 <fwp_data.part.0.constprop.0>
    a808:	97ffebd3 	bl	5754 <fwp_rc_fresh>
    a80c:	aa0003e2 	mov	x2, x0
    a810:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a814:	910da3e1 	add	x1, sp, #0x368
    a818:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a81c:	52800020 	mov	w0, #0x1                   	// #1
    a820:	f901b7e3 	str	x3, [sp, #872]
    a824:	f901bbe2 	str	x2, [sp, #880]
    a828:	97ffea2b 	bl	50d4 <fwp_data.part.0.constprop.0>
    a82c:	9117c283 	add	x3, x20, #0x5f0
    a830:	aa0003f5 	mov	x21, x0
    a834:	f949d861 	ldr	x1, [x3, #5040]
    a838:	f949ec60 	ldr	x0, [x3, #5080]
    a83c:	cb0102a1 	sub	x1, x21, x1
    a840:	eb00403f 	cmp	x1, x0, lsl #16
    a844:	54000322 	b.cs	a8a8 <f0+0xbd4>  // b.hs, b.nlast
    a848:	d350fc22 	lsr	x2, x1, #16
    a84c:	f949fc63 	ldr	x3, [x3, #5112]
    a850:	8b020842 	add	x2, x2, x2, lsl #2
    a854:	d37df042 	lsl	x2, x2, #3
    a858:	8b020060 	add	x0, x3, x2
    a85c:	f9401017 	ldr	x23, [x0, #32]
    a860:	b4000257 	cbz	x23, a8a8 <f0+0xbd4>
    a864:	38626862 	ldrb	w2, [x3, x2]
    a868:	7100085f 	cmp	w2, #0x2
    a86c:	5400c040 	b.eq	c074 <f0+0x23a0>  // b.none
    a870:	7100045f 	cmp	w2, #0x1
    a874:	540001a1 	b.ne	a8a8 <f0+0xbd4>  // b.any
    a878:	29430002 	ldp	w2, w0, [x0, #24]
    a87c:	92403c21 	and	x1, x1, #0xffff
    a880:	9b027c21 	mul	x1, x1, x2
    a884:	d360fc21 	lsr	x1, x1, #32
    a888:	eb00003f 	cmp	x1, x0
    a88c:	540000e2 	b.cs	a8a8 <f0+0xbd4>  // b.hs, b.nlast
    a890:	8b0102f7 	add	x23, x23, x1
    a894:	394002e0 	ldrb	w0, [x23]
    a898:	7103fc1f 	cmp	w0, #0xff
    a89c:	5400ca60 	b.eq	c1e8 <f0+0x2514>  // b.none
    a8a0:	52800020 	mov	w0, #0x1                   	// #1
    a8a4:	390002e0 	strb	w0, [x23]
    a8a8:	910de3e1 	add	x1, sp, #0x378
    a8ac:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a8b0:	52800020 	mov	w0, #0x1                   	// #1
    a8b4:	f901bff7 	str	x23, [sp, #888]
    a8b8:	f901c3f5 	str	x21, [sp, #896]
    a8bc:	97ffea06 	bl	50d4 <fwp_data.part.0.constprop.0>
    a8c0:	97ffeba5 	bl	5754 <fwp_rc_fresh>
    a8c4:	aa0003e2 	mov	x2, x0
    a8c8:	910e23e1 	add	x1, sp, #0x388
    a8cc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a8d0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a8d4:	52800020 	mov	w0, #0x1                   	// #1
    a8d8:	f901c7f5 	str	x21, [sp, #904]
    a8dc:	f901cbe2 	str	x2, [sp, #912]
    a8e0:	97ffe9fd 	bl	50d4 <fwp_data.part.0.constprop.0>
    a8e4:	97ffeb9c 	bl	5754 <fwp_rc_fresh>
    a8e8:	aa0003e2 	mov	x2, x0
    a8ec:	910e63e1 	add	x1, sp, #0x398
    a8f0:	52800020 	mov	w0, #0x1                   	// #1
    a8f4:	f901cff7 	str	x23, [sp, #920]
    a8f8:	f901d3e2 	str	x2, [sp, #928]
    a8fc:	97ffe9f6 	bl	50d4 <fwp_data.part.0.constprop.0>
    a900:	97ffeb95 	bl	5754 <fwp_rc_fresh>
    a904:	aa0003e2 	mov	x2, x0
    a908:	910ea3e1 	add	x1, sp, #0x3a8
    a90c:	52800020 	mov	w0, #0x1                   	// #1
    a910:	f901d7f5 	str	x21, [sp, #936]
    a914:	f901dbe2 	str	x2, [sp, #944]
    a918:	97ffe9ef 	bl	50d4 <fwp_data.part.0.constprop.0>
    a91c:	97ffeb8e 	bl	5754 <fwp_rc_fresh>
    a920:	aa0003e2 	mov	x2, x0
    a924:	910ee3e1 	add	x1, sp, #0x3b8
    a928:	52800020 	mov	w0, #0x1                   	// #1
    a92c:	f901dff7 	str	x23, [sp, #952]
    a930:	f901e3e2 	str	x2, [sp, #960]
    a934:	97ffe9e8 	bl	50d4 <fwp_data.part.0.constprop.0>
    a938:	97ffeb87 	bl	5754 <fwp_rc_fresh>
    a93c:	aa0003e2 	mov	x2, x0
    a940:	910f23e1 	add	x1, sp, #0x3c8
    a944:	52800020 	mov	w0, #0x1                   	// #1
    a948:	f901e7f5 	str	x21, [sp, #968]
    a94c:	f901ebe2 	str	x2, [sp, #976]
    a950:	97ffe9e1 	bl	50d4 <fwp_data.part.0.constprop.0>
    a954:	97ffeb80 	bl	5754 <fwp_rc_fresh>
    a958:	aa0003e2 	mov	x2, x0
    a95c:	910f63e1 	add	x1, sp, #0x3d8
    a960:	52800020 	mov	w0, #0x1                   	// #1
    a964:	f901eff7 	str	x23, [sp, #984]
    a968:	f901f3e2 	str	x2, [sp, #992]
    a96c:	97ffe9da 	bl	50d4 <fwp_data.part.0.constprop.0>
    a970:	97ffeb79 	bl	5754 <fwp_rc_fresh>
    a974:	aa0003e2 	mov	x2, x0
    a978:	910fa3e1 	add	x1, sp, #0x3e8
    a97c:	52800020 	mov	w0, #0x1                   	// #1
    a980:	f901f7f5 	str	x21, [sp, #1000]
    a984:	f901fbe2 	str	x2, [sp, #1008]
    a988:	97ffe9d3 	bl	50d4 <fwp_data.part.0.constprop.0>
    a98c:	97ffeb72 	bl	5754 <fwp_rc_fresh>
    a990:	aa0003e2 	mov	x2, x0
    a994:	910fe3e1 	add	x1, sp, #0x3f8
    a998:	52800020 	mov	w0, #0x1                   	// #1
    a99c:	f901fff7 	str	x23, [sp, #1016]
    a9a0:	f90203e2 	str	x2, [sp, #1024]
    a9a4:	97ffe9cc 	bl	50d4 <fwp_data.part.0.constprop.0>
    a9a8:	97ffeb6b 	bl	5754 <fwp_rc_fresh>
    a9ac:	aa0003e2 	mov	x2, x0
    a9b0:	911023e1 	add	x1, sp, #0x408
    a9b4:	52800020 	mov	w0, #0x1                   	// #1
    a9b8:	f90207f5 	str	x21, [sp, #1032]
    a9bc:	f9020be2 	str	x2, [sp, #1040]
    a9c0:	97ffe9c5 	bl	50d4 <fwp_data.part.0.constprop.0>
    a9c4:	9117c283 	add	x3, x20, #0x5f0
    a9c8:	aa0003f5 	mov	x21, x0
    a9cc:	f949d861 	ldr	x1, [x3, #5040]
    a9d0:	f949ec60 	ldr	x0, [x3, #5080]
    a9d4:	cb0102a1 	sub	x1, x21, x1
    a9d8:	eb00403f 	cmp	x1, x0, lsl #16
    a9dc:	54000322 	b.cs	aa40 <f0+0xd6c>  // b.hs, b.nlast
    a9e0:	d350fc22 	lsr	x2, x1, #16
    a9e4:	f949fc63 	ldr	x3, [x3, #5112]
    a9e8:	8b020842 	add	x2, x2, x2, lsl #2
    a9ec:	d37df042 	lsl	x2, x2, #3
    a9f0:	8b020060 	add	x0, x3, x2
    a9f4:	f9401017 	ldr	x23, [x0, #32]
    a9f8:	b4000257 	cbz	x23, aa40 <f0+0xd6c>
    a9fc:	38626862 	ldrb	w2, [x3, x2]
    aa00:	7100085f 	cmp	w2, #0x2
    aa04:	5400b320 	b.eq	c068 <f0+0x2394>  // b.none
    aa08:	7100045f 	cmp	w2, #0x1
    aa0c:	540001a1 	b.ne	aa40 <f0+0xd6c>  // b.any
    aa10:	29430002 	ldp	w2, w0, [x0, #24]
    aa14:	92403c21 	and	x1, x1, #0xffff
    aa18:	9b027c21 	mul	x1, x1, x2
    aa1c:	d360fc21 	lsr	x1, x1, #32
    aa20:	eb00003f 	cmp	x1, x0
    aa24:	540000e2 	b.cs	aa40 <f0+0xd6c>  // b.hs, b.nlast
    aa28:	8b0102f7 	add	x23, x23, x1
    aa2c:	394002e0 	ldrb	w0, [x23]
    aa30:	7103fc1f 	cmp	w0, #0xff
    aa34:	5400be00 	b.eq	c1f4 <f0+0x2520>  // b.none
    aa38:	52800020 	mov	w0, #0x1                   	// #1
    aa3c:	390002e0 	strb	w0, [x23]
    aa40:	911063e1 	add	x1, sp, #0x418
    aa44:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aa48:	52800020 	mov	w0, #0x1                   	// #1
    aa4c:	f9020fe2 	str	x2, [sp, #1048]
    aa50:	f90213f5 	str	x21, [sp, #1056]
    aa54:	97ffe9a0 	bl	50d4 <fwp_data.part.0.constprop.0>
    aa58:	97ffeb3f 	bl	5754 <fwp_rc_fresh>
    aa5c:	aa0003e2 	mov	x2, x0
    aa60:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aa64:	9110a3e1 	add	x1, sp, #0x428
    aa68:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aa6c:	52800020 	mov	w0, #0x1                   	// #1
    aa70:	f90217e3 	str	x3, [sp, #1064]
    aa74:	f9021be2 	str	x2, [sp, #1072]
    aa78:	97ffe997 	bl	50d4 <fwp_data.part.0.constprop.0>
    aa7c:	9117c283 	add	x3, x20, #0x5f0
    aa80:	aa0003f5 	mov	x21, x0
    aa84:	f949d861 	ldr	x1, [x3, #5040]
    aa88:	f949ec60 	ldr	x0, [x3, #5080]
    aa8c:	cb0102a1 	sub	x1, x21, x1
    aa90:	eb00403f 	cmp	x1, x0, lsl #16
    aa94:	54000322 	b.cs	aaf8 <f0+0xe24>  // b.hs, b.nlast
    aa98:	d350fc22 	lsr	x2, x1, #16
    aa9c:	f949fc63 	ldr	x3, [x3, #5112]
    aaa0:	8b020842 	add	x2, x2, x2, lsl #2
    aaa4:	d37df042 	lsl	x2, x2, #3
    aaa8:	8b020060 	add	x0, x3, x2
    aaac:	f9401017 	ldr	x23, [x0, #32]
    aab0:	b4000257 	cbz	x23, aaf8 <f0+0xe24>
    aab4:	38626862 	ldrb	w2, [x3, x2]
    aab8:	7100085f 	cmp	w2, #0x2
    aabc:	5400ad00 	b.eq	c05c <f0+0x2388>  // b.none
    aac0:	7100045f 	cmp	w2, #0x1
    aac4:	540001a1 	b.ne	aaf8 <f0+0xe24>  // b.any
    aac8:	29430002 	ldp	w2, w0, [x0, #24]
    aacc:	92403c21 	and	x1, x1, #0xffff
    aad0:	9b027c21 	mul	x1, x1, x2
    aad4:	d360fc21 	lsr	x1, x1, #32
    aad8:	eb00003f 	cmp	x1, x0
    aadc:	540000e2 	b.cs	aaf8 <f0+0xe24>  // b.hs, b.nlast
    aae0:	8b0102f7 	add	x23, x23, x1
    aae4:	394002e0 	ldrb	w0, [x23]
    aae8:	7103fc1f 	cmp	w0, #0xff
    aaec:	5400b8a0 	b.eq	c200 <f0+0x252c>  // b.none
    aaf0:	52800020 	mov	w0, #0x1                   	// #1
    aaf4:	390002e0 	strb	w0, [x23]
    aaf8:	9110e3e1 	add	x1, sp, #0x438
    aafc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab00:	52800020 	mov	w0, #0x1                   	// #1
    ab04:	f9021fe2 	str	x2, [sp, #1080]
    ab08:	f90223f5 	str	x21, [sp, #1088]
    ab0c:	97ffe972 	bl	50d4 <fwp_data.part.0.constprop.0>
    ab10:	97ffeb11 	bl	5754 <fwp_rc_fresh>
    ab14:	aa0003e2 	mov	x2, x0
    ab18:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ab1c:	911123e1 	add	x1, sp, #0x448
    ab20:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ab24:	52800020 	mov	w0, #0x1                   	// #1
    ab28:	f90227e3 	str	x3, [sp, #1096]
    ab2c:	f9022be2 	str	x2, [sp, #1104]
    ab30:	97ffe969 	bl	50d4 <fwp_data.part.0.constprop.0>
    ab34:	9117c283 	add	x3, x20, #0x5f0
    ab38:	aa0003f5 	mov	x21, x0
    ab3c:	f949d861 	ldr	x1, [x3, #5040]
    ab40:	f949ec60 	ldr	x0, [x3, #5080]
    ab44:	cb0102a1 	sub	x1, x21, x1
    ab48:	eb00403f 	cmp	x1, x0, lsl #16
    ab4c:	54000322 	b.cs	abb0 <f0+0xedc>  // b.hs, b.nlast
    ab50:	d350fc22 	lsr	x2, x1, #16
    ab54:	f949fc63 	ldr	x3, [x3, #5112]
    ab58:	8b020842 	add	x2, x2, x2, lsl #2
    ab5c:	d37df042 	lsl	x2, x2, #3
    ab60:	8b020060 	add	x0, x3, x2
    ab64:	f9401017 	ldr	x23, [x0, #32]
    ab68:	b4000257 	cbz	x23, abb0 <f0+0xedc>
    ab6c:	38626862 	ldrb	w2, [x3, x2]
    ab70:	7100085f 	cmp	w2, #0x2
    ab74:	5400a6e0 	b.eq	c050 <f0+0x237c>  // b.none
    ab78:	7100045f 	cmp	w2, #0x1
    ab7c:	540001a1 	b.ne	abb0 <f0+0xedc>  // b.any
    ab80:	29430002 	ldp	w2, w0, [x0, #24]
    ab84:	92403c21 	and	x1, x1, #0xffff
    ab88:	9b027c21 	mul	x1, x1, x2
    ab8c:	d360fc21 	lsr	x1, x1, #32
    ab90:	eb00003f 	cmp	x1, x0
    ab94:	540000e2 	b.cs	abb0 <f0+0xedc>  // b.hs, b.nlast
    ab98:	8b0102f7 	add	x23, x23, x1
    ab9c:	394002e0 	ldrb	w0, [x23]
    aba0:	7103fc1f 	cmp	w0, #0xff
    aba4:	5400b340 	b.eq	c20c <f0+0x2538>  // b.none
    aba8:	52800020 	mov	w0, #0x1                   	// #1
    abac:	390002e0 	strb	w0, [x23]
    abb0:	911163e1 	add	x1, sp, #0x458
    abb4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    abb8:	52800020 	mov	w0, #0x1                   	// #1
    abbc:	f9022fe2 	str	x2, [sp, #1112]
    abc0:	f90233f5 	str	x21, [sp, #1120]
    abc4:	97ffe944 	bl	50d4 <fwp_data.part.0.constprop.0>
    abc8:	97ffeae3 	bl	5754 <fwp_rc_fresh>
    abcc:	aa0003e2 	mov	x2, x0
    abd0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    abd4:	9111a3e1 	add	x1, sp, #0x468
    abd8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    abdc:	52800020 	mov	w0, #0x1                   	// #1
    abe0:	f90237e3 	str	x3, [sp, #1128]
    abe4:	f9023be2 	str	x2, [sp, #1136]
    abe8:	97ffe93b 	bl	50d4 <fwp_data.part.0.constprop.0>
    abec:	9117c283 	add	x3, x20, #0x5f0
    abf0:	aa0003f5 	mov	x21, x0
    abf4:	f949d861 	ldr	x1, [x3, #5040]
    abf8:	f949ec60 	ldr	x0, [x3, #5080]
    abfc:	cb0102a1 	sub	x1, x21, x1
    ac00:	eb00403f 	cmp	x1, x0, lsl #16
    ac04:	54000322 	b.cs	ac68 <f0+0xf94>  // b.hs, b.nlast
    ac08:	d350fc22 	lsr	x2, x1, #16
    ac0c:	f949fc63 	ldr	x3, [x3, #5112]
    ac10:	8b020842 	add	x2, x2, x2, lsl #2
    ac14:	d37df042 	lsl	x2, x2, #3
    ac18:	8b020060 	add	x0, x3, x2
    ac1c:	f9401017 	ldr	x23, [x0, #32]
    ac20:	b4000257 	cbz	x23, ac68 <f0+0xf94>
    ac24:	38626862 	ldrb	w2, [x3, x2]
    ac28:	7100085f 	cmp	w2, #0x2
    ac2c:	5400a0c0 	b.eq	c044 <f0+0x2370>  // b.none
    ac30:	7100045f 	cmp	w2, #0x1
    ac34:	540001a1 	b.ne	ac68 <f0+0xf94>  // b.any
    ac38:	29430002 	ldp	w2, w0, [x0, #24]
    ac3c:	92403c21 	and	x1, x1, #0xffff
    ac40:	9b027c21 	mul	x1, x1, x2
    ac44:	d360fc21 	lsr	x1, x1, #32
    ac48:	eb00003f 	cmp	x1, x0
    ac4c:	540000e2 	b.cs	ac68 <f0+0xf94>  // b.hs, b.nlast
    ac50:	8b0102f7 	add	x23, x23, x1
    ac54:	394002e0 	ldrb	w0, [x23]
    ac58:	7103fc1f 	cmp	w0, #0xff
    ac5c:	5400ade0 	b.eq	c218 <f0+0x2544>  // b.none
    ac60:	52800020 	mov	w0, #0x1                   	// #1
    ac64:	390002e0 	strb	w0, [x23]
    ac68:	9111e3e1 	add	x1, sp, #0x478
    ac6c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ac70:	52800020 	mov	w0, #0x1                   	// #1
    ac74:	f9023ff7 	str	x23, [sp, #1144]
    ac78:	f90243f5 	str	x21, [sp, #1152]
    ac7c:	97ffe916 	bl	50d4 <fwp_data.part.0.constprop.0>
    ac80:	97ffeab5 	bl	5754 <fwp_rc_fresh>
    ac84:	aa0003e2 	mov	x2, x0
    ac88:	911223e1 	add	x1, sp, #0x488
    ac8c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ac90:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ac94:	52800020 	mov	w0, #0x1                   	// #1
    ac98:	f90247f5 	str	x21, [sp, #1160]
    ac9c:	f9024be2 	str	x2, [sp, #1168]
    aca0:	97ffe90d 	bl	50d4 <fwp_data.part.0.constprop.0>
    aca4:	97ffeaac 	bl	5754 <fwp_rc_fresh>
    aca8:	aa0003e2 	mov	x2, x0
    acac:	911263e1 	add	x1, sp, #0x498
    acb0:	52800020 	mov	w0, #0x1                   	// #1
    acb4:	f9024ff7 	str	x23, [sp, #1176]
    acb8:	f90253e2 	str	x2, [sp, #1184]
    acbc:	97ffe906 	bl	50d4 <fwp_data.part.0.constprop.0>
    acc0:	97ffeaa5 	bl	5754 <fwp_rc_fresh>
    acc4:	aa0003e2 	mov	x2, x0
    acc8:	9112a3e1 	add	x1, sp, #0x4a8
    accc:	52800020 	mov	w0, #0x1                   	// #1
    acd0:	f90257f5 	str	x21, [sp, #1192]
    acd4:	f9025be2 	str	x2, [sp, #1200]
    acd8:	97ffe8ff 	bl	50d4 <fwp_data.part.0.constprop.0>
    acdc:	97ffea9e 	bl	5754 <fwp_rc_fresh>
    ace0:	aa0003e2 	mov	x2, x0
    ace4:	9112e3e1 	add	x1, sp, #0x4b8
    ace8:	52800020 	mov	w0, #0x1                   	// #1
    acec:	f9025ff7 	str	x23, [sp, #1208]
    acf0:	f90263e2 	str	x2, [sp, #1216]
    acf4:	97ffe8f8 	bl	50d4 <fwp_data.part.0.constprop.0>
    acf8:	9117c283 	add	x3, x20, #0x5f0
    acfc:	aa0003f5 	mov	x21, x0
    ad00:	f949d861 	ldr	x1, [x3, #5040]
    ad04:	f949ec60 	ldr	x0, [x3, #5080]
    ad08:	cb0102a1 	sub	x1, x21, x1
    ad0c:	eb00403f 	cmp	x1, x0, lsl #16
    ad10:	54000322 	b.cs	ad74 <f0+0x10a0>  // b.hs, b.nlast
    ad14:	d350fc22 	lsr	x2, x1, #16
    ad18:	f949fc63 	ldr	x3, [x3, #5112]
    ad1c:	8b020842 	add	x2, x2, x2, lsl #2
    ad20:	d37df042 	lsl	x2, x2, #3
    ad24:	8b020060 	add	x0, x3, x2
    ad28:	f9401017 	ldr	x23, [x0, #32]
    ad2c:	b4000257 	cbz	x23, ad74 <f0+0x10a0>
    ad30:	38626862 	ldrb	w2, [x3, x2]
    ad34:	7100085f 	cmp	w2, #0x2
    ad38:	54009560 	b.eq	bfe4 <f0+0x2310>  // b.none
    ad3c:	7100045f 	cmp	w2, #0x1
    ad40:	540001a1 	b.ne	ad74 <f0+0x10a0>  // b.any
    ad44:	29430002 	ldp	w2, w0, [x0, #24]
    ad48:	92403c21 	and	x1, x1, #0xffff
    ad4c:	9b027c21 	mul	x1, x1, x2
    ad50:	d360fc21 	lsr	x1, x1, #32
    ad54:	eb00003f 	cmp	x1, x0
    ad58:	540000e2 	b.cs	ad74 <f0+0x10a0>  // b.hs, b.nlast
    ad5c:	8b0102f7 	add	x23, x23, x1
    ad60:	394002e0 	ldrb	w0, [x23]
    ad64:	7103fc1f 	cmp	w0, #0xff
    ad68:	5400a5e0 	b.eq	c224 <f0+0x2550>  // b.none
    ad6c:	52800020 	mov	w0, #0x1                   	// #1
    ad70:	390002e0 	strb	w0, [x23]
    ad74:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ad78:	911323e1 	add	x1, sp, #0x4c8
    ad7c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ad80:	52800020 	mov	w0, #0x1                   	// #1
    ad84:	f90267e2 	str	x2, [sp, #1224]
    ad88:	f9026bf5 	str	x21, [sp, #1232]
    ad8c:	97ffe8d2 	bl	50d4 <fwp_data.part.0.constprop.0>
    ad90:	9117c283 	add	x3, x20, #0x5f0
    ad94:	aa0003f5 	mov	x21, x0
    ad98:	f949d861 	ldr	x1, [x3, #5040]
    ad9c:	f949ec60 	ldr	x0, [x3, #5080]
    ada0:	cb0102a1 	sub	x1, x21, x1
    ada4:	eb00403f 	cmp	x1, x0, lsl #16
    ada8:	54000322 	b.cs	ae0c <f0+0x1138>  // b.hs, b.nlast
    adac:	d350fc22 	lsr	x2, x1, #16
    adb0:	f949fc63 	ldr	x3, [x3, #5112]
    adb4:	8b020842 	add	x2, x2, x2, lsl #2
    adb8:	d37df042 	lsl	x2, x2, #3
    adbc:	8b020060 	add	x0, x3, x2
    adc0:	f9401017 	ldr	x23, [x0, #32]
    adc4:	b4000257 	cbz	x23, ae0c <f0+0x1138>
    adc8:	38626862 	ldrb	w2, [x3, x2]
    adcc:	7100085f 	cmp	w2, #0x2
    add0:	54009040 	b.eq	bfd8 <f0+0x2304>  // b.none
    add4:	7100045f 	cmp	w2, #0x1
    add8:	540001a1 	b.ne	ae0c <f0+0x1138>  // b.any
    addc:	29430002 	ldp	w2, w0, [x0, #24]
    ade0:	92403c21 	and	x1, x1, #0xffff
    ade4:	9b027c21 	mul	x1, x1, x2
    ade8:	d360fc21 	lsr	x1, x1, #32
    adec:	eb00003f 	cmp	x1, x0
    adf0:	540000e2 	b.cs	ae0c <f0+0x1138>  // b.hs, b.nlast
    adf4:	8b0102f7 	add	x23, x23, x1
    adf8:	394002e0 	ldrb	w0, [x23]
    adfc:	7103fc1f 	cmp	w0, #0xff
    ae00:	5400a180 	b.eq	c230 <f0+0x255c>  // b.none
    ae04:	52800020 	mov	w0, #0x1                   	// #1
    ae08:	390002e0 	strb	w0, [x23]
    ae0c:	911363e1 	add	x1, sp, #0x4d8
    ae10:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae14:	52800020 	mov	w0, #0x1                   	// #1
    ae18:	f9026fe2 	str	x2, [sp, #1240]
    ae1c:	f90273f5 	str	x21, [sp, #1248]
    ae20:	97ffe8ad 	bl	50d4 <fwp_data.part.0.constprop.0>
    ae24:	97ffea4c 	bl	5754 <fwp_rc_fresh>
    ae28:	aa0003e2 	mov	x2, x0
    ae2c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae30:	9113a3e1 	add	x1, sp, #0x4e8
    ae34:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae38:	52800020 	mov	w0, #0x1                   	// #1
    ae3c:	f90277e3 	str	x3, [sp, #1256]
    ae40:	f9027be2 	str	x2, [sp, #1264]
    ae44:	97ffe8a4 	bl	50d4 <fwp_data.part.0.constprop.0>
    ae48:	9117c283 	add	x3, x20, #0x5f0
    ae4c:	aa0003f5 	mov	x21, x0
    ae50:	f949d861 	ldr	x1, [x3, #5040]
    ae54:	f949ec60 	ldr	x0, [x3, #5080]
    ae58:	cb0102a1 	sub	x1, x21, x1
    ae5c:	eb00403f 	cmp	x1, x0, lsl #16
    ae60:	54000322 	b.cs	aec4 <f0+0x11f0>  // b.hs, b.nlast
    ae64:	d350fc22 	lsr	x2, x1, #16
    ae68:	f949fc63 	ldr	x3, [x3, #5112]
    ae6c:	8b020842 	add	x2, x2, x2, lsl #2
    ae70:	d37df042 	lsl	x2, x2, #3
    ae74:	8b020060 	add	x0, x3, x2
    ae78:	f9401017 	ldr	x23, [x0, #32]
    ae7c:	b4000257 	cbz	x23, aec4 <f0+0x11f0>
    ae80:	38626862 	ldrb	w2, [x3, x2]
    ae84:	7100085f 	cmp	w2, #0x2
    ae88:	54008a20 	b.eq	bfcc <f0+0x22f8>  // b.none
    ae8c:	7100045f 	cmp	w2, #0x1
    ae90:	540001a1 	b.ne	aec4 <f0+0x11f0>  // b.any
    ae94:	29430002 	ldp	w2, w0, [x0, #24]
    ae98:	92403c21 	and	x1, x1, #0xffff
    ae9c:	9b027c21 	mul	x1, x1, x2
    aea0:	d360fc21 	lsr	x1, x1, #32
    aea4:	eb00003f 	cmp	x1, x0
    aea8:	540000e2 	b.cs	aec4 <f0+0x11f0>  // b.hs, b.nlast
    aeac:	8b0102f7 	add	x23, x23, x1
    aeb0:	394002e0 	ldrb	w0, [x23]
    aeb4:	7103fc1f 	cmp	w0, #0xff
    aeb8:	54009c20 	b.eq	c23c <f0+0x2568>  // b.none
    aebc:	52800020 	mov	w0, #0x1                   	// #1
    aec0:	390002e0 	strb	w0, [x23]
    aec4:	9113e3e1 	add	x1, sp, #0x4f8
    aec8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aecc:	52800020 	mov	w0, #0x1                   	// #1
    aed0:	f9027fe2 	str	x2, [sp, #1272]
    aed4:	f90283f5 	str	x21, [sp, #1280]
    aed8:	97ffe87f 	bl	50d4 <fwp_data.part.0.constprop.0>
    aedc:	97ffea1e 	bl	5754 <fwp_rc_fresh>
    aee0:	aa0003e2 	mov	x2, x0
    aee4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aee8:	911423e1 	add	x1, sp, #0x508
    aeec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aef0:	52800020 	mov	w0, #0x1                   	// #1
    aef4:	f90287e3 	str	x3, [sp, #1288]
    aef8:	f9028be2 	str	x2, [sp, #1296]
    aefc:	97ffe876 	bl	50d4 <fwp_data.part.0.constprop.0>
    af00:	9117c283 	add	x3, x20, #0x5f0
    af04:	aa0003f5 	mov	x21, x0
    af08:	f949d861 	ldr	x1, [x3, #5040]
    af0c:	f949ec60 	ldr	x0, [x3, #5080]
    af10:	cb0102a1 	sub	x1, x21, x1
    af14:	eb00403f 	cmp	x1, x0, lsl #16
    af18:	54000322 	b.cs	af7c <f0+0x12a8>  // b.hs, b.nlast
    af1c:	d350fc22 	lsr	x2, x1, #16
    af20:	f949fc63 	ldr	x3, [x3, #5112]
    af24:	8b020842 	add	x2, x2, x2, lsl #2
    af28:	d37df042 	lsl	x2, x2, #3
    af2c:	8b020060 	add	x0, x3, x2
    af30:	f9401017 	ldr	x23, [x0, #32]
    af34:	b4000257 	cbz	x23, af7c <f0+0x12a8>
    af38:	38626862 	ldrb	w2, [x3, x2]
    af3c:	7100085f 	cmp	w2, #0x2
    af40:	54008400 	b.eq	bfc0 <f0+0x22ec>  // b.none
    af44:	7100045f 	cmp	w2, #0x1
    af48:	540001a1 	b.ne	af7c <f0+0x12a8>  // b.any
    af4c:	29430002 	ldp	w2, w0, [x0, #24]
    af50:	92403c21 	and	x1, x1, #0xffff
    af54:	9b027c21 	mul	x1, x1, x2
    af58:	d360fc21 	lsr	x1, x1, #32
    af5c:	eb00003f 	cmp	x1, x0
    af60:	540000e2 	b.cs	af7c <f0+0x12a8>  // b.hs, b.nlast
    af64:	8b0102f7 	add	x23, x23, x1
    af68:	394002e0 	ldrb	w0, [x23]
    af6c:	7103fc1f 	cmp	w0, #0xff
    af70:	540096c0 	b.eq	c248 <f0+0x2574>  // b.none
    af74:	52800020 	mov	w0, #0x1                   	// #1
    af78:	390002e0 	strb	w0, [x23]
    af7c:	911463e1 	add	x1, sp, #0x518
    af80:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af84:	52800020 	mov	w0, #0x1                   	// #1
    af88:	f9028ff7 	str	x23, [sp, #1304]
    af8c:	f90293f5 	str	x21, [sp, #1312]
    af90:	97ffe851 	bl	50d4 <fwp_data.part.0.constprop.0>
    af94:	97ffe9f0 	bl	5754 <fwp_rc_fresh>
    af98:	aa0003e2 	mov	x2, x0
    af9c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    afa0:	9114a3e1 	add	x1, sp, #0x528
    afa4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    afa8:	52800020 	mov	w0, #0x1                   	// #1
    afac:	f90297e3 	str	x3, [sp, #1320]
    afb0:	f9029be2 	str	x2, [sp, #1328]
    afb4:	97ffe848 	bl	50d4 <fwp_data.part.0.constprop.0>
    afb8:	97ffe9e7 	bl	5754 <fwp_rc_fresh>
    afbc:	aa0003e2 	mov	x2, x0
    afc0:	9114e3e1 	add	x1, sp, #0x538
    afc4:	52800020 	mov	w0, #0x1                   	// #1
    afc8:	f9029ff7 	str	x23, [sp, #1336]
    afcc:	f902a3e2 	str	x2, [sp, #1344]
    afd0:	97ffe841 	bl	50d4 <fwp_data.part.0.constprop.0>
    afd4:	9117c283 	add	x3, x20, #0x5f0
    afd8:	aa0003f5 	mov	x21, x0
    afdc:	f949d861 	ldr	x1, [x3, #5040]
    afe0:	f949ec60 	ldr	x0, [x3, #5080]
    afe4:	cb0102a1 	sub	x1, x21, x1
    afe8:	eb00403f 	cmp	x1, x0, lsl #16
    afec:	54000322 	b.cs	b050 <f0+0x137c>  // b.hs, b.nlast
    aff0:	d350fc22 	lsr	x2, x1, #16
    aff4:	f949fc63 	ldr	x3, [x3, #5112]
    aff8:	8b020842 	add	x2, x2, x2, lsl #2
    affc:	d37df042 	lsl	x2, x2, #3
    b000:	8b020060 	add	x0, x3, x2
    b004:	f9401017 	ldr	x23, [x0, #32]
    b008:	b4000257 	cbz	x23, b050 <f0+0x137c>
    b00c:	38626862 	ldrb	w2, [x3, x2]
    b010:	7100085f 	cmp	w2, #0x2
    b014:	54007d00 	b.eq	bfb4 <f0+0x22e0>  // b.none
    b018:	7100045f 	cmp	w2, #0x1
    b01c:	540001a1 	b.ne	b050 <f0+0x137c>  // b.any
    b020:	29430002 	ldp	w2, w0, [x0, #24]
    b024:	92403c21 	and	x1, x1, #0xffff
    b028:	9b027c21 	mul	x1, x1, x2
    b02c:	d360fc21 	lsr	x1, x1, #32
    b030:	eb00003f 	cmp	x1, x0
    b034:	540000e2 	b.cs	b050 <f0+0x137c>  // b.hs, b.nlast
    b038:	8b0102f7 	add	x23, x23, x1
    b03c:	394002e0 	ldrb	w0, [x23]
    b040:	7103fc1f 	cmp	w0, #0xff
    b044:	54009080 	b.eq	c254 <f0+0x2580>  // b.none
    b048:	52800020 	mov	w0, #0x1                   	// #1
    b04c:	390002e0 	strb	w0, [x23]
    b050:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b054:	911523e1 	add	x1, sp, #0x548
    b058:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b05c:	52800020 	mov	w0, #0x1                   	// #1
    b060:	f902a7e2 	str	x2, [sp, #1352]
    b064:	f902abf5 	str	x21, [sp, #1360]
    b068:	97ffe81b 	bl	50d4 <fwp_data.part.0.constprop.0>
    b06c:	9117c283 	add	x3, x20, #0x5f0
    b070:	aa0003f5 	mov	x21, x0
    b074:	f949d861 	ldr	x1, [x3, #5040]
    b078:	f949ec60 	ldr	x0, [x3, #5080]
    b07c:	cb0102a1 	sub	x1, x21, x1
    b080:	eb00403f 	cmp	x1, x0, lsl #16
    b084:	54000322 	b.cs	b0e8 <f0+0x1414>  // b.hs, b.nlast
    b088:	d350fc22 	lsr	x2, x1, #16
    b08c:	f949fc63 	ldr	x3, [x3, #5112]
    b090:	8b020842 	add	x2, x2, x2, lsl #2
    b094:	d37df042 	lsl	x2, x2, #3
    b098:	8b020060 	add	x0, x3, x2
    b09c:	f9401017 	ldr	x23, [x0, #32]
    b0a0:	b4000257 	cbz	x23, b0e8 <f0+0x1414>
    b0a4:	38626862 	ldrb	w2, [x3, x2]
    b0a8:	7100085f 	cmp	w2, #0x2
    b0ac:	540077e0 	b.eq	bfa8 <f0+0x22d4>  // b.none
    b0b0:	7100045f 	cmp	w2, #0x1
    b0b4:	540001a1 	b.ne	b0e8 <f0+0x1414>  // b.any
    b0b8:	29430002 	ldp	w2, w0, [x0, #24]
    b0bc:	92403c21 	and	x1, x1, #0xffff
    b0c0:	9b027c21 	mul	x1, x1, x2
    b0c4:	d360fc21 	lsr	x1, x1, #32
    b0c8:	eb00003f 	cmp	x1, x0
    b0cc:	540000e2 	b.cs	b0e8 <f0+0x1414>  // b.hs, b.nlast
    b0d0:	8b0102f7 	add	x23, x23, x1
    b0d4:	394002e0 	ldrb	w0, [x23]
    b0d8:	7103fc1f 	cmp	w0, #0xff
    b0dc:	54008c20 	b.eq	c260 <f0+0x258c>  // b.none
    b0e0:	52800020 	mov	w0, #0x1                   	// #1
    b0e4:	390002e0 	strb	w0, [x23]
    b0e8:	911563e1 	add	x1, sp, #0x558
    b0ec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b0f0:	52800020 	mov	w0, #0x1                   	// #1
    b0f4:	f902afe2 	str	x2, [sp, #1368]
    b0f8:	f902b3f5 	str	x21, [sp, #1376]
    b0fc:	97ffe7f6 	bl	50d4 <fwp_data.part.0.constprop.0>
    b100:	97ffe995 	bl	5754 <fwp_rc_fresh>
    b104:	aa0003e2 	mov	x2, x0
    b108:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b10c:	9115a3e1 	add	x1, sp, #0x568
    b110:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b114:	52800020 	mov	w0, #0x1                   	// #1
    b118:	f902b7e3 	str	x3, [sp, #1384]
    b11c:	f902bbe2 	str	x2, [sp, #1392]
    b120:	97ffe7ed 	bl	50d4 <fwp_data.part.0.constprop.0>
    b124:	9117c283 	add	x3, x20, #0x5f0
    b128:	aa0003f5 	mov	x21, x0
    b12c:	f949d861 	ldr	x1, [x3, #5040]
    b130:	f949ec60 	ldr	x0, [x3, #5080]
    b134:	cb0102a1 	sub	x1, x21, x1
    b138:	eb00403f 	cmp	x1, x0, lsl #16
    b13c:	54000322 	b.cs	b1a0 <f0+0x14cc>  // b.hs, b.nlast
    b140:	d350fc22 	lsr	x2, x1, #16
    b144:	f949fc63 	ldr	x3, [x3, #5112]
    b148:	8b020842 	add	x2, x2, x2, lsl #2
    b14c:	d37df042 	lsl	x2, x2, #3
    b150:	8b020060 	add	x0, x3, x2
    b154:	f9401017 	ldr	x23, [x0, #32]
    b158:	b4000257 	cbz	x23, b1a0 <f0+0x14cc>
    b15c:	38626862 	ldrb	w2, [x3, x2]
    b160:	7100085f 	cmp	w2, #0x2
    b164:	540071c0 	b.eq	bf9c <f0+0x22c8>  // b.none
    b168:	7100045f 	cmp	w2, #0x1
    b16c:	540001a1 	b.ne	b1a0 <f0+0x14cc>  // b.any
    b170:	29430002 	ldp	w2, w0, [x0, #24]
    b174:	92403c21 	and	x1, x1, #0xffff
    b178:	9b027c21 	mul	x1, x1, x2
    b17c:	d360fc21 	lsr	x1, x1, #32
    b180:	eb00003f 	cmp	x1, x0
    b184:	540000e2 	b.cs	b1a0 <f0+0x14cc>  // b.hs, b.nlast
    b188:	8b0102f7 	add	x23, x23, x1
    b18c:	394002e0 	ldrb	w0, [x23]
    b190:	7103fc1f 	cmp	w0, #0xff
    b194:	540086c0 	b.eq	c26c <f0+0x2598>  // b.none
    b198:	52800020 	mov	w0, #0x1                   	// #1
    b19c:	390002e0 	strb	w0, [x23]
    b1a0:	9115e3e1 	add	x1, sp, #0x578
    b1a4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b1a8:	52800020 	mov	w0, #0x1                   	// #1
    b1ac:	f902bfe2 	str	x2, [sp, #1400]
    b1b0:	f902c3f5 	str	x21, [sp, #1408]
    b1b4:	97ffe7c8 	bl	50d4 <fwp_data.part.0.constprop.0>
    b1b8:	97ffe967 	bl	5754 <fwp_rc_fresh>
    b1bc:	aa0003e2 	mov	x2, x0
    b1c0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b1c4:	911623e1 	add	x1, sp, #0x588
    b1c8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b1cc:	52800020 	mov	w0, #0x1                   	// #1
    b1d0:	f902c7e3 	str	x3, [sp, #1416]
    b1d4:	f902cbe2 	str	x2, [sp, #1424]
    b1d8:	97ffe7bf 	bl	50d4 <fwp_data.part.0.constprop.0>
    b1dc:	9117c283 	add	x3, x20, #0x5f0
    b1e0:	aa0003f5 	mov	x21, x0
    b1e4:	f949d861 	ldr	x1, [x3, #5040]
    b1e8:	f949ec60 	ldr	x0, [x3, #5080]
    b1ec:	cb0102a1 	sub	x1, x21, x1
    b1f0:	eb00403f 	cmp	x1, x0, lsl #16
    b1f4:	54000322 	b.cs	b258 <f0+0x1584>  // b.hs, b.nlast
    b1f8:	d350fc22 	lsr	x2, x1, #16
    b1fc:	f949fc63 	ldr	x3, [x3, #5112]
    b200:	8b020842 	add	x2, x2, x2, lsl #2
    b204:	d37df042 	lsl	x2, x2, #3
    b208:	8b020060 	add	x0, x3, x2
    b20c:	f9401017 	ldr	x23, [x0, #32]
    b210:	b4000257 	cbz	x23, b258 <f0+0x1584>
    b214:	38626862 	ldrb	w2, [x3, x2]
    b218:	7100085f 	cmp	w2, #0x2
    b21c:	54006ba0 	b.eq	bf90 <f0+0x22bc>  // b.none
    b220:	7100045f 	cmp	w2, #0x1
    b224:	540001a1 	b.ne	b258 <f0+0x1584>  // b.any
    b228:	29430002 	ldp	w2, w0, [x0, #24]
    b22c:	92403c21 	and	x1, x1, #0xffff
    b230:	9b027c21 	mul	x1, x1, x2
    b234:	d360fc21 	lsr	x1, x1, #32
    b238:	eb00003f 	cmp	x1, x0
    b23c:	540000e2 	b.cs	b258 <f0+0x1584>  // b.hs, b.nlast
    b240:	8b0102f7 	add	x23, x23, x1
    b244:	394002e0 	ldrb	w0, [x23]
    b248:	7103fc1f 	cmp	w0, #0xff
    b24c:	54008160 	b.eq	c278 <f0+0x25a4>  // b.none
    b250:	52800020 	mov	w0, #0x1                   	// #1
    b254:	390002e0 	strb	w0, [x23]
    b258:	911663e1 	add	x1, sp, #0x598
    b25c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b260:	52800020 	mov	w0, #0x1                   	// #1
    b264:	f902cff7 	str	x23, [sp, #1432]
    b268:	f902d3f5 	str	x21, [sp, #1440]
    b26c:	97ffe79a 	bl	50d4 <fwp_data.part.0.constprop.0>
    b270:	97ffe939 	bl	5754 <fwp_rc_fresh>
    b274:	aa0003e2 	mov	x2, x0
    b278:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b27c:	9116a3e1 	add	x1, sp, #0x5a8
    b280:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b284:	52800020 	mov	w0, #0x1                   	// #1
    b288:	f902d7e3 	str	x3, [sp, #1448]
    b28c:	f902dbe2 	str	x2, [sp, #1456]
    b290:	97ffe791 	bl	50d4 <fwp_data.part.0.constprop.0>
    b294:	97ffe930 	bl	5754 <fwp_rc_fresh>
    b298:	aa0003e2 	mov	x2, x0
    b29c:	9116e3e1 	add	x1, sp, #0x5b8
    b2a0:	52800020 	mov	w0, #0x1                   	// #1
    b2a4:	f902dff7 	str	x23, [sp, #1464]
    b2a8:	f902e3e2 	str	x2, [sp, #1472]
    b2ac:	97ffe78a 	bl	50d4 <fwp_data.part.0.constprop.0>
    b2b0:	9117c283 	add	x3, x20, #0x5f0
    b2b4:	aa0003f5 	mov	x21, x0
    b2b8:	f949d861 	ldr	x1, [x3, #5040]
    b2bc:	f949ec60 	ldr	x0, [x3, #5080]
    b2c0:	cb0102a1 	sub	x1, x21, x1
    b2c4:	eb00403f 	cmp	x1, x0, lsl #16
    b2c8:	54000322 	b.cs	b32c <f0+0x1658>  // b.hs, b.nlast
    b2cc:	d350fc22 	lsr	x2, x1, #16
    b2d0:	f949fc63 	ldr	x3, [x3, #5112]
    b2d4:	8b020842 	add	x2, x2, x2, lsl #2
    b2d8:	d37df042 	lsl	x2, x2, #3
    b2dc:	8b020060 	add	x0, x3, x2
    b2e0:	f9401017 	ldr	x23, [x0, #32]
    b2e4:	b4000257 	cbz	x23, b32c <f0+0x1658>
    b2e8:	38626862 	ldrb	w2, [x3, x2]
    b2ec:	7100085f 	cmp	w2, #0x2
    b2f0:	54007340 	b.eq	c158 <f0+0x2484>  // b.none
    b2f4:	7100045f 	cmp	w2, #0x1
    b2f8:	540001a1 	b.ne	b32c <f0+0x1658>  // b.any
    b2fc:	29430002 	ldp	w2, w0, [x0, #24]
    b300:	92403c21 	and	x1, x1, #0xffff
    b304:	9b027c21 	mul	x1, x1, x2
    b308:	d360fc21 	lsr	x1, x1, #32
    b30c:	eb00003f 	cmp	x1, x0
    b310:	540000e2 	b.cs	b32c <f0+0x1658>  // b.hs, b.nlast
    b314:	8b0102f7 	add	x23, x23, x1
    b318:	394002e0 	ldrb	w0, [x23]
    b31c:	7103fc1f 	cmp	w0, #0xff
    b320:	54007b20 	b.eq	c284 <f0+0x25b0>  // b.none
    b324:	52800020 	mov	w0, #0x1                   	// #1
    b328:	390002e0 	strb	w0, [x23]
    b32c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b330:	911723e1 	add	x1, sp, #0x5c8
    b334:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b338:	52800020 	mov	w0, #0x1                   	// #1
    b33c:	f902e7e2 	str	x2, [sp, #1480]
    b340:	f902ebf5 	str	x21, [sp, #1488]
    b344:	97ffe764 	bl	50d4 <fwp_data.part.0.constprop.0>
    b348:	9117c283 	add	x3, x20, #0x5f0
    b34c:	aa0003f5 	mov	x21, x0
    b350:	f949d861 	ldr	x1, [x3, #5040]
    b354:	f949ec60 	ldr	x0, [x3, #5080]
    b358:	cb0102a1 	sub	x1, x21, x1
    b35c:	eb00403f 	cmp	x1, x0, lsl #16
    b360:	54000322 	b.cs	b3c4 <f0+0x16f0>  // b.hs, b.nlast
    b364:	d350fc22 	lsr	x2, x1, #16
    b368:	f949fc63 	ldr	x3, [x3, #5112]
    b36c:	8b020842 	add	x2, x2, x2, lsl #2
    b370:	d37df042 	lsl	x2, x2, #3
    b374:	8b020060 	add	x0, x3, x2
    b378:	f9401017 	ldr	x23, [x0, #32]
    b37c:	b4000257 	cbz	x23, b3c4 <f0+0x16f0>
    b380:	38626862 	ldrb	w2, [x3, x2]
    b384:	7100085f 	cmp	w2, #0x2
    b388:	54006e20 	b.eq	c14c <f0+0x2478>  // b.none
    b38c:	7100045f 	cmp	w2, #0x1
    b390:	540001a1 	b.ne	b3c4 <f0+0x16f0>  // b.any
    b394:	29430002 	ldp	w2, w0, [x0, #24]
    b398:	92403c21 	and	x1, x1, #0xffff
    b39c:	9b027c21 	mul	x1, x1, x2
    b3a0:	d360fc21 	lsr	x1, x1, #32
    b3a4:	eb00003f 	cmp	x1, x0
    b3a8:	540000e2 	b.cs	b3c4 <f0+0x16f0>  // b.hs, b.nlast
    b3ac:	8b0102f7 	add	x23, x23, x1
    b3b0:	394002e0 	ldrb	w0, [x23]
    b3b4:	7103fc1f 	cmp	w0, #0xff
    b3b8:	540076c0 	b.eq	c290 <f0+0x25bc>  // b.none
    b3bc:	52800020 	mov	w0, #0x1                   	// #1
    b3c0:	390002e0 	strb	w0, [x23]
    b3c4:	911763e1 	add	x1, sp, #0x5d8
    b3c8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b3cc:	52800020 	mov	w0, #0x1                   	// #1
    b3d0:	f902eff7 	str	x23, [sp, #1496]
    b3d4:	f902f3f5 	str	x21, [sp, #1504]
    b3d8:	97ffe73f 	bl	50d4 <fwp_data.part.0.constprop.0>
    b3dc:	97ffe8de 	bl	5754 <fwp_rc_fresh>
    b3e0:	aa0003e2 	mov	x2, x0
    b3e4:	9117a3e1 	add	x1, sp, #0x5e8
    b3e8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b3ec:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b3f0:	52800020 	mov	w0, #0x1                   	// #1
    b3f4:	f902f7f5 	str	x21, [sp, #1512]
    b3f8:	f902fbe2 	str	x2, [sp, #1520]
    b3fc:	97ffe736 	bl	50d4 <fwp_data.part.0.constprop.0>
    b400:	97ffe8d5 	bl	5754 <fwp_rc_fresh>
    b404:	aa0003e2 	mov	x2, x0
    b408:	9117e3e1 	add	x1, sp, #0x5f8
    b40c:	52800020 	mov	w0, #0x1                   	// #1
    b410:	f902fff7 	str	x23, [sp, #1528]
    b414:	f90303e2 	str	x2, [sp, #1536]
    b418:	97ffe72f 	bl	50d4 <fwp_data.part.0.constprop.0>
    b41c:	97ffe8ce 	bl	5754 <fwp_rc_fresh>
    b420:	aa0003e2 	mov	x2, x0
    b424:	911823e1 	add	x1, sp, #0x608
    b428:	52800020 	mov	w0, #0x1                   	// #1
    b42c:	f90307f5 	str	x21, [sp, #1544]
    b430:	f9030be2 	str	x2, [sp, #1552]
    b434:	97ffe728 	bl	50d4 <fwp_data.part.0.constprop.0>
    b438:	9117c283 	add	x3, x20, #0x5f0
    b43c:	aa0003f5 	mov	x21, x0
    b440:	f949d861 	ldr	x1, [x3, #5040]
    b444:	f949ec60 	ldr	x0, [x3, #5080]
    b448:	cb0102a1 	sub	x1, x21, x1
    b44c:	eb00403f 	cmp	x1, x0, lsl #16
    b450:	54000322 	b.cs	b4b4 <f0+0x17e0>  // b.hs, b.nlast
    b454:	d350fc22 	lsr	x2, x1, #16
    b458:	f949fc63 	ldr	x3, [x3, #5112]
    b45c:	8b020842 	add	x2, x2, x2, lsl #2
    b460:	d37df042 	lsl	x2, x2, #3
    b464:	8b020060 	add	x0, x3, x2
    b468:	f9401017 	ldr	x23, [x0, #32]
    b46c:	b4000257 	cbz	x23, b4b4 <f0+0x17e0>
    b470:	38626862 	ldrb	w2, [x3, x2]
    b474:	7100085f 	cmp	w2, #0x2
    b478:	54006640 	b.eq	c140 <f0+0x246c>  // b.none
    b47c:	7100045f 	cmp	w2, #0x1
    b480:	540001a1 	b.ne	b4b4 <f0+0x17e0>  // b.any
    b484:	29430002 	ldp	w2, w0, [x0, #24]
    b488:	92403c21 	and	x1, x1, #0xffff
    b48c:	9b027c21 	mul	x1, x1, x2
    b490:	d360fc21 	lsr	x1, x1, #32
    b494:	eb00003f 	cmp	x1, x0
    b498:	540000e2 	b.cs	b4b4 <f0+0x17e0>  // b.hs, b.nlast
    b49c:	8b0102f7 	add	x23, x23, x1
    b4a0:	394002e0 	ldrb	w0, [x23]
    b4a4:	7103fc1f 	cmp	w0, #0xff
    b4a8:	54006fa0 	b.eq	c29c <f0+0x25c8>  // b.none
    b4ac:	52800020 	mov	w0, #0x1                   	// #1
    b4b0:	390002e0 	strb	w0, [x23]
    b4b4:	911863e1 	add	x1, sp, #0x618
    b4b8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b4bc:	52800020 	mov	w0, #0x1                   	// #1
    b4c0:	f9030ff7 	str	x23, [sp, #1560]
    b4c4:	f90313f5 	str	x21, [sp, #1568]
    b4c8:	97ffe703 	bl	50d4 <fwp_data.part.0.constprop.0>
    b4cc:	97ffe8a2 	bl	5754 <fwp_rc_fresh>
    b4d0:	aa0003e2 	mov	x2, x0
    b4d4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b4d8:	9118a3e1 	add	x1, sp, #0x628
    b4dc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b4e0:	52800020 	mov	w0, #0x1                   	// #1
    b4e4:	f90317e3 	str	x3, [sp, #1576]
    b4e8:	f9031be2 	str	x2, [sp, #1584]
    b4ec:	97ffe6fa 	bl	50d4 <fwp_data.part.0.constprop.0>
    b4f0:	97ffe899 	bl	5754 <fwp_rc_fresh>
    b4f4:	aa0003e2 	mov	x2, x0
    b4f8:	9118e3e1 	add	x1, sp, #0x638
    b4fc:	52800020 	mov	w0, #0x1                   	// #1
    b500:	f9031ff7 	str	x23, [sp, #1592]
    b504:	f90323e2 	str	x2, [sp, #1600]
    b508:	97ffe6f3 	bl	50d4 <fwp_data.part.0.constprop.0>
    b50c:	9117c283 	add	x3, x20, #0x5f0
    b510:	aa0003f5 	mov	x21, x0
    b514:	f949d861 	ldr	x1, [x3, #5040]
    b518:	f949ec60 	ldr	x0, [x3, #5080]
    b51c:	cb0102a1 	sub	x1, x21, x1
    b520:	eb00403f 	cmp	x1, x0, lsl #16
    b524:	54000322 	b.cs	b588 <f0+0x18b4>  // b.hs, b.nlast
    b528:	d350fc22 	lsr	x2, x1, #16
    b52c:	f949fc63 	ldr	x3, [x3, #5112]
    b530:	8b020842 	add	x2, x2, x2, lsl #2
    b534:	d37df042 	lsl	x2, x2, #3
    b538:	8b020060 	add	x0, x3, x2
    b53c:	f9401017 	ldr	x23, [x0, #32]
    b540:	b4000257 	cbz	x23, b588 <f0+0x18b4>
    b544:	38626862 	ldrb	w2, [x3, x2]
    b548:	7100085f 	cmp	w2, #0x2
    b54c:	54005f40 	b.eq	c134 <f0+0x2460>  // b.none
    b550:	7100045f 	cmp	w2, #0x1
    b554:	540001a1 	b.ne	b588 <f0+0x18b4>  // b.any
    b558:	29430002 	ldp	w2, w0, [x0, #24]
    b55c:	92403c21 	and	x1, x1, #0xffff
    b560:	9b027c21 	mul	x1, x1, x2
    b564:	d360fc21 	lsr	x1, x1, #32
    b568:	eb00003f 	cmp	x1, x0
    b56c:	540000e2 	b.cs	b588 <f0+0x18b4>  // b.hs, b.nlast
    b570:	8b0102f7 	add	x23, x23, x1
    b574:	394002e0 	ldrb	w0, [x23]
    b578:	7103fc1f 	cmp	w0, #0xff
    b57c:	54006960 	b.eq	c2a8 <f0+0x25d4>  // b.none
    b580:	52800020 	mov	w0, #0x1                   	// #1
    b584:	390002e0 	strb	w0, [x23]
    b588:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b58c:	911923e1 	add	x1, sp, #0x648
    b590:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b594:	52800020 	mov	w0, #0x1                   	// #1
    b598:	f90327e2 	str	x2, [sp, #1608]
    b59c:	f9032bf5 	str	x21, [sp, #1616]
    b5a0:	97ffe6cd 	bl	50d4 <fwp_data.part.0.constprop.0>
    b5a4:	9117c283 	add	x3, x20, #0x5f0
    b5a8:	aa0003f5 	mov	x21, x0
    b5ac:	f949d861 	ldr	x1, [x3, #5040]
    b5b0:	f949ec60 	ldr	x0, [x3, #5080]
    b5b4:	cb0102a1 	sub	x1, x21, x1
    b5b8:	eb00403f 	cmp	x1, x0, lsl #16
    b5bc:	54000322 	b.cs	b620 <f0+0x194c>  // b.hs, b.nlast
    b5c0:	d350fc22 	lsr	x2, x1, #16
    b5c4:	f949fc63 	ldr	x3, [x3, #5112]
    b5c8:	8b020842 	add	x2, x2, x2, lsl #2
    b5cc:	d37df042 	lsl	x2, x2, #3
    b5d0:	8b020060 	add	x0, x3, x2
    b5d4:	f9401017 	ldr	x23, [x0, #32]
    b5d8:	b4000257 	cbz	x23, b620 <f0+0x194c>
    b5dc:	38626862 	ldrb	w2, [x3, x2]
    b5e0:	7100085f 	cmp	w2, #0x2
    b5e4:	54005a20 	b.eq	c128 <f0+0x2454>  // b.none
    b5e8:	7100045f 	cmp	w2, #0x1
    b5ec:	540001a1 	b.ne	b620 <f0+0x194c>  // b.any
    b5f0:	29430002 	ldp	w2, w0, [x0, #24]
    b5f4:	92403c21 	and	x1, x1, #0xffff
    b5f8:	9b027c21 	mul	x1, x1, x2
    b5fc:	d360fc21 	lsr	x1, x1, #32
    b600:	eb00003f 	cmp	x1, x0
    b604:	540000e2 	b.cs	b620 <f0+0x194c>  // b.hs, b.nlast
    b608:	8b0102f7 	add	x23, x23, x1
    b60c:	394002e0 	ldrb	w0, [x23]
    b610:	7103fc1f 	cmp	w0, #0xff
    b614:	54006500 	b.eq	c2b4 <f0+0x25e0>  // b.none
    b618:	52800020 	mov	w0, #0x1                   	// #1
    b61c:	390002e0 	strb	w0, [x23]
    b620:	911963e1 	add	x1, sp, #0x658
    b624:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b628:	52800020 	mov	w0, #0x1                   	// #1
    b62c:	f9032fe2 	str	x2, [sp, #1624]
    b630:	f90333f5 	str	x21, [sp, #1632]
    b634:	97ffe6a8 	bl	50d4 <fwp_data.part.0.constprop.0>
    b638:	97ffe847 	bl	5754 <fwp_rc_fresh>
    b63c:	aa0003e2 	mov	x2, x0
    b640:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b644:	9119a3e1 	add	x1, sp, #0x668
    b648:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b64c:	52800020 	mov	w0, #0x1                   	// #1
    b650:	f90337e3 	str	x3, [sp, #1640]
    b654:	f9033be2 	str	x2, [sp, #1648]
    b658:	97ffe69f 	bl	50d4 <fwp_data.part.0.constprop.0>
    b65c:	9117c283 	add	x3, x20, #0x5f0
    b660:	aa0003f5 	mov	x21, x0
    b664:	f949d861 	ldr	x1, [x3, #5040]
    b668:	f949ec60 	ldr	x0, [x3, #5080]
    b66c:	cb0102a1 	sub	x1, x21, x1
    b670:	eb00403f 	cmp	x1, x0, lsl #16
    b674:	54000322 	b.cs	b6d8 <f0+0x1a04>  // b.hs, b.nlast
    b678:	d350fc22 	lsr	x2, x1, #16
    b67c:	f949fc63 	ldr	x3, [x3, #5112]
    b680:	8b020842 	add	x2, x2, x2, lsl #2
    b684:	d37df042 	lsl	x2, x2, #3
    b688:	8b020060 	add	x0, x3, x2
    b68c:	f9401017 	ldr	x23, [x0, #32]
    b690:	b4000257 	cbz	x23, b6d8 <f0+0x1a04>
    b694:	38626862 	ldrb	w2, [x3, x2]
    b698:	7100085f 	cmp	w2, #0x2
    b69c:	54005400 	b.eq	c11c <f0+0x2448>  // b.none
    b6a0:	7100045f 	cmp	w2, #0x1
    b6a4:	540001a1 	b.ne	b6d8 <f0+0x1a04>  // b.any
    b6a8:	29430002 	ldp	w2, w0, [x0, #24]
    b6ac:	92403c21 	and	x1, x1, #0xffff
    b6b0:	9b027c21 	mul	x1, x1, x2
    b6b4:	d360fc21 	lsr	x1, x1, #32
    b6b8:	eb00003f 	cmp	x1, x0
    b6bc:	540000e2 	b.cs	b6d8 <f0+0x1a04>  // b.hs, b.nlast
    b6c0:	8b0102f7 	add	x23, x23, x1
    b6c4:	394002e0 	ldrb	w0, [x23]
    b6c8:	7103fc1f 	cmp	w0, #0xff
    b6cc:	54005fa0 	b.eq	c2c0 <f0+0x25ec>  // b.none
    b6d0:	52800020 	mov	w0, #0x1                   	// #1
    b6d4:	390002e0 	strb	w0, [x23]
    b6d8:	9119e3e1 	add	x1, sp, #0x678
    b6dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b6e0:	52800020 	mov	w0, #0x1                   	// #1
    b6e4:	f9033fe2 	str	x2, [sp, #1656]
    b6e8:	f90343f5 	str	x21, [sp, #1664]
    b6ec:	97ffe67a 	bl	50d4 <fwp_data.part.0.constprop.0>
    b6f0:	97ffe819 	bl	5754 <fwp_rc_fresh>
    b6f4:	aa0003e2 	mov	x2, x0
    b6f8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b6fc:	911a23e1 	add	x1, sp, #0x688
    b700:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b704:	52800020 	mov	w0, #0x1                   	// #1
    b708:	f90347e3 	str	x3, [sp, #1672]
    b70c:	f9034be2 	str	x2, [sp, #1680]
    b710:	97ffe671 	bl	50d4 <fwp_data.part.0.constprop.0>
    b714:	9117c283 	add	x3, x20, #0x5f0
    b718:	aa0003f5 	mov	x21, x0
    b71c:	f949d861 	ldr	x1, [x3, #5040]
    b720:	f949ec60 	ldr	x0, [x3, #5080]
    b724:	cb0102a1 	sub	x1, x21, x1
    b728:	eb00403f 	cmp	x1, x0, lsl #16
    b72c:	54000322 	b.cs	b790 <f0+0x1abc>  // b.hs, b.nlast
    b730:	d350fc22 	lsr	x2, x1, #16
    b734:	f949fc63 	ldr	x3, [x3, #5112]
    b738:	8b020842 	add	x2, x2, x2, lsl #2
    b73c:	d37df042 	lsl	x2, x2, #3
    b740:	8b020060 	add	x0, x3, x2
    b744:	f9401017 	ldr	x23, [x0, #32]
    b748:	b4000257 	cbz	x23, b790 <f0+0x1abc>
    b74c:	38626862 	ldrb	w2, [x3, x2]
    b750:	7100085f 	cmp	w2, #0x2
    b754:	54004de0 	b.eq	c110 <f0+0x243c>  // b.none
    b758:	7100045f 	cmp	w2, #0x1
    b75c:	540001a1 	b.ne	b790 <f0+0x1abc>  // b.any
    b760:	29430002 	ldp	w2, w0, [x0, #24]
    b764:	92403c21 	and	x1, x1, #0xffff
    b768:	9b027c21 	mul	x1, x1, x2
    b76c:	d360fc21 	lsr	x1, x1, #32
    b770:	eb00003f 	cmp	x1, x0
    b774:	540000e2 	b.cs	b790 <f0+0x1abc>  // b.hs, b.nlast
    b778:	8b0102f7 	add	x23, x23, x1
    b77c:	394002e0 	ldrb	w0, [x23]
    b780:	7103fc1f 	cmp	w0, #0xff
    b784:	54005a40 	b.eq	c2cc <f0+0x25f8>  // b.none
    b788:	52800020 	mov	w0, #0x1                   	// #1
    b78c:	390002e0 	strb	w0, [x23]
    b790:	911a63e1 	add	x1, sp, #0x698
    b794:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b798:	52800020 	mov	w0, #0x1                   	// #1
    b79c:	f9034ff7 	str	x23, [sp, #1688]
    b7a0:	f90353f5 	str	x21, [sp, #1696]
    b7a4:	97ffe64c 	bl	50d4 <fwp_data.part.0.constprop.0>
    b7a8:	97ffe7eb 	bl	5754 <fwp_rc_fresh>
    b7ac:	aa0003e2 	mov	x2, x0
    b7b0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b7b4:	911aa3e1 	add	x1, sp, #0x6a8
    b7b8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b7bc:	52800020 	mov	w0, #0x1                   	// #1
    b7c0:	f90357e3 	str	x3, [sp, #1704]
    b7c4:	f9035be2 	str	x2, [sp, #1712]
    b7c8:	97ffe643 	bl	50d4 <fwp_data.part.0.constprop.0>
    b7cc:	97ffe7e2 	bl	5754 <fwp_rc_fresh>
    b7d0:	aa0003e2 	mov	x2, x0
    b7d4:	911ae3e1 	add	x1, sp, #0x6b8
    b7d8:	52800020 	mov	w0, #0x1                   	// #1
    b7dc:	f9035ff7 	str	x23, [sp, #1720]
    b7e0:	f90363e2 	str	x2, [sp, #1728]
    b7e4:	97ffe63c 	bl	50d4 <fwp_data.part.0.constprop.0>
    b7e8:	9117c283 	add	x3, x20, #0x5f0
    b7ec:	aa0003f5 	mov	x21, x0
    b7f0:	f949d861 	ldr	x1, [x3, #5040]
    b7f4:	f949ec60 	ldr	x0, [x3, #5080]
    b7f8:	cb0102a1 	sub	x1, x21, x1
    b7fc:	eb00403f 	cmp	x1, x0, lsl #16
    b800:	54000322 	b.cs	b864 <f0+0x1b90>  // b.hs, b.nlast
    b804:	d350fc22 	lsr	x2, x1, #16
    b808:	f949fc63 	ldr	x3, [x3, #5112]
    b80c:	8b020842 	add	x2, x2, x2, lsl #2
    b810:	d37df042 	lsl	x2, x2, #3
    b814:	8b020060 	add	x0, x3, x2
    b818:	f9401017 	ldr	x23, [x0, #32]
    b81c:	b4000257 	cbz	x23, b864 <f0+0x1b90>
    b820:	38626862 	ldrb	w2, [x3, x2]
    b824:	7100085f 	cmp	w2, #0x2
    b828:	540046e0 	b.eq	c104 <f0+0x2430>  // b.none
    b82c:	7100045f 	cmp	w2, #0x1
    b830:	540001a1 	b.ne	b864 <f0+0x1b90>  // b.any
    b834:	29430002 	ldp	w2, w0, [x0, #24]
    b838:	92403c21 	and	x1, x1, #0xffff
    b83c:	9b027c21 	mul	x1, x1, x2
    b840:	d360fc21 	lsr	x1, x1, #32
    b844:	eb00003f 	cmp	x1, x0
    b848:	540000e2 	b.cs	b864 <f0+0x1b90>  // b.hs, b.nlast
    b84c:	8b0102f7 	add	x23, x23, x1
    b850:	394002e0 	ldrb	w0, [x23]
    b854:	7103fc1f 	cmp	w0, #0xff
    b858:	54005400 	b.eq	c2d8 <f0+0x2604>  // b.none
    b85c:	52800020 	mov	w0, #0x1                   	// #1
    b860:	390002e0 	strb	w0, [x23]
    b864:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b868:	911b23e1 	add	x1, sp, #0x6c8
    b86c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b870:	52800020 	mov	w0, #0x1                   	// #1
    b874:	f90367e2 	str	x2, [sp, #1736]
    b878:	f9036bf5 	str	x21, [sp, #1744]
    b87c:	97ffe616 	bl	50d4 <fwp_data.part.0.constprop.0>
    b880:	9117c283 	add	x3, x20, #0x5f0
    b884:	aa0003f5 	mov	x21, x0
    b888:	f949d861 	ldr	x1, [x3, #5040]
    b88c:	f949ec60 	ldr	x0, [x3, #5080]
    b890:	cb0102a1 	sub	x1, x21, x1
    b894:	eb00403f 	cmp	x1, x0, lsl #16
    b898:	54000322 	b.cs	b8fc <f0+0x1c28>  // b.hs, b.nlast
    b89c:	d350fc22 	lsr	x2, x1, #16
    b8a0:	f949fc63 	ldr	x3, [x3, #5112]
    b8a4:	8b020842 	add	x2, x2, x2, lsl #2
    b8a8:	d37df042 	lsl	x2, x2, #3
    b8ac:	8b020060 	add	x0, x3, x2
    b8b0:	f9401017 	ldr	x23, [x0, #32]
    b8b4:	b4000257 	cbz	x23, b8fc <f0+0x1c28>
    b8b8:	38626862 	ldrb	w2, [x3, x2]
    b8bc:	7100085f 	cmp	w2, #0x2
    b8c0:	540041c0 	b.eq	c0f8 <f0+0x2424>  // b.none
    b8c4:	7100045f 	cmp	w2, #0x1
    b8c8:	540001a1 	b.ne	b8fc <f0+0x1c28>  // b.any
    b8cc:	29430002 	ldp	w2, w0, [x0, #24]
    b8d0:	92403c21 	and	x1, x1, #0xffff
    b8d4:	9b027c21 	mul	x1, x1, x2
    b8d8:	d360fc21 	lsr	x1, x1, #32
    b8dc:	eb00003f 	cmp	x1, x0
    b8e0:	540000e2 	b.cs	b8fc <f0+0x1c28>  // b.hs, b.nlast
    b8e4:	8b0102f7 	add	x23, x23, x1
    b8e8:	394002e0 	ldrb	w0, [x23]
    b8ec:	7103fc1f 	cmp	w0, #0xff
    b8f0:	54004fa0 	b.eq	c2e4 <f0+0x2610>  // b.none
    b8f4:	52800020 	mov	w0, #0x1                   	// #1
    b8f8:	390002e0 	strb	w0, [x23]
    b8fc:	911b63e1 	add	x1, sp, #0x6d8
    b900:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	f9036ff7 	str	x23, [sp, #1752]
    b90c:	f90373f5 	str	x21, [sp, #1760]
    b910:	97ffe5f1 	bl	50d4 <fwp_data.part.0.constprop.0>
    b914:	97ffe790 	bl	5754 <fwp_rc_fresh>
    b918:	aa0003e2 	mov	x2, x0
    b91c:	911ba3e1 	add	x1, sp, #0x6e8
    b920:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b924:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b928:	52800020 	mov	w0, #0x1                   	// #1
    b92c:	f90377f5 	str	x21, [sp, #1768]
    b930:	f9037be2 	str	x2, [sp, #1776]
    b934:	97ffe5e8 	bl	50d4 <fwp_data.part.0.constprop.0>
    b938:	97ffe787 	bl	5754 <fwp_rc_fresh>
    b93c:	aa0003e2 	mov	x2, x0
    b940:	911be3e1 	add	x1, sp, #0x6f8
    b944:	52800020 	mov	w0, #0x1                   	// #1
    b948:	f9037ff7 	str	x23, [sp, #1784]
    b94c:	f90383e2 	str	x2, [sp, #1792]
    b950:	97ffe5e1 	bl	50d4 <fwp_data.part.0.constprop.0>
    b954:	97ffe780 	bl	5754 <fwp_rc_fresh>
    b958:	aa0003e2 	mov	x2, x0
    b95c:	911c23e1 	add	x1, sp, #0x708
    b960:	52800020 	mov	w0, #0x1                   	// #1
    b964:	f90387f5 	str	x21, [sp, #1800]
    b968:	f9038be2 	str	x2, [sp, #1808]
    b96c:	97ffe5da 	bl	50d4 <fwp_data.part.0.constprop.0>
    b970:	9117c283 	add	x3, x20, #0x5f0
    b974:	aa0003f5 	mov	x21, x0
    b978:	f949d861 	ldr	x1, [x3, #5040]
    b97c:	f949ec60 	ldr	x0, [x3, #5080]
    b980:	cb0102a1 	sub	x1, x21, x1
    b984:	eb00403f 	cmp	x1, x0, lsl #16
    b988:	54000322 	b.cs	b9ec <f0+0x1d18>  // b.hs, b.nlast
    b98c:	d350fc22 	lsr	x2, x1, #16
    b990:	f949fc63 	ldr	x3, [x3, #5112]
    b994:	8b020842 	add	x2, x2, x2, lsl #2
    b998:	d37df042 	lsl	x2, x2, #3
    b99c:	8b020060 	add	x0, x3, x2
    b9a0:	f9401017 	ldr	x23, [x0, #32]
    b9a4:	b4000257 	cbz	x23, b9ec <f0+0x1d18>
    b9a8:	38626862 	ldrb	w2, [x3, x2]
    b9ac:	7100085f 	cmp	w2, #0x2
    b9b0:	540039e0 	b.eq	c0ec <f0+0x2418>  // b.none
    b9b4:	7100045f 	cmp	w2, #0x1
    b9b8:	540001a1 	b.ne	b9ec <f0+0x1d18>  // b.any
    b9bc:	29430002 	ldp	w2, w0, [x0, #24]
    b9c0:	92403c21 	and	x1, x1, #0xffff
    b9c4:	9b027c21 	mul	x1, x1, x2
    b9c8:	d360fc21 	lsr	x1, x1, #32
    b9cc:	eb00003f 	cmp	x1, x0
    b9d0:	540000e2 	b.cs	b9ec <f0+0x1d18>  // b.hs, b.nlast
    b9d4:	8b0102f7 	add	x23, x23, x1
    b9d8:	394002e0 	ldrb	w0, [x23]
    b9dc:	7103fc1f 	cmp	w0, #0xff
    b9e0:	54004880 	b.eq	c2f0 <f0+0x261c>  // b.none
    b9e4:	52800020 	mov	w0, #0x1                   	// #1
    b9e8:	390002e0 	strb	w0, [x23]
    b9ec:	911c63e1 	add	x1, sp, #0x718
    b9f0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b9f4:	52800020 	mov	w0, #0x1                   	// #1
    b9f8:	f9038fe2 	str	x2, [sp, #1816]
    b9fc:	f90393f5 	str	x21, [sp, #1824]
    ba00:	97ffe5b5 	bl	50d4 <fwp_data.part.0.constprop.0>
    ba04:	97ffe754 	bl	5754 <fwp_rc_fresh>
    ba08:	aa0003e2 	mov	x2, x0
    ba0c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ba10:	911ca3e1 	add	x1, sp, #0x728
    ba14:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ba18:	52800020 	mov	w0, #0x1                   	// #1
    ba1c:	f90397e3 	str	x3, [sp, #1832]
    ba20:	f9039be2 	str	x2, [sp, #1840]
    ba24:	97ffe5ac 	bl	50d4 <fwp_data.part.0.constprop.0>
    ba28:	9117c283 	add	x3, x20, #0x5f0
    ba2c:	aa0003f5 	mov	x21, x0
    ba30:	f949d861 	ldr	x1, [x3, #5040]
    ba34:	f949ec60 	ldr	x0, [x3, #5080]
    ba38:	cb0102a1 	sub	x1, x21, x1
    ba3c:	eb00403f 	cmp	x1, x0, lsl #16
    ba40:	54000322 	b.cs	baa4 <f0+0x1dd0>  // b.hs, b.nlast
    ba44:	d350fc22 	lsr	x2, x1, #16
    ba48:	f949fc63 	ldr	x3, [x3, #5112]
    ba4c:	8b020842 	add	x2, x2, x2, lsl #2
    ba50:	d37df042 	lsl	x2, x2, #3
    ba54:	8b020060 	add	x0, x3, x2
    ba58:	f9401017 	ldr	x23, [x0, #32]
    ba5c:	b4000257 	cbz	x23, baa4 <f0+0x1dd0>
    ba60:	38626862 	ldrb	w2, [x3, x2]
    ba64:	7100085f 	cmp	w2, #0x2
    ba68:	540033c0 	b.eq	c0e0 <f0+0x240c>  // b.none
    ba6c:	7100045f 	cmp	w2, #0x1
    ba70:	540001a1 	b.ne	baa4 <f0+0x1dd0>  // b.any
    ba74:	29430002 	ldp	w2, w0, [x0, #24]
    ba78:	92403c21 	and	x1, x1, #0xffff
    ba7c:	9b027c21 	mul	x1, x1, x2
    ba80:	d360fc21 	lsr	x1, x1, #32
    ba84:	eb00003f 	cmp	x1, x0
    ba88:	540000e2 	b.cs	baa4 <f0+0x1dd0>  // b.hs, b.nlast
    ba8c:	8b0102f7 	add	x23, x23, x1
    ba90:	394002e0 	ldrb	w0, [x23]
    ba94:	7103fc1f 	cmp	w0, #0xff
    ba98:	54004320 	b.eq	c2fc <f0+0x2628>  // b.none
    ba9c:	52800020 	mov	w0, #0x1                   	// #1
    baa0:	390002e0 	strb	w0, [x23]
    baa4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    baa8:	911ce3e1 	add	x1, sp, #0x738
    baac:	52800020 	mov	w0, #0x1                   	// #1
    bab0:	f9039fe2 	str	x2, [sp, #1848]
    bab4:	f903a3f5 	str	x21, [sp, #1856]
    bab8:	97ffe587 	bl	50d4 <fwp_data.part.0.constprop.0>
    babc:	9117c283 	add	x3, x20, #0x5f0
    bac0:	aa0003f5 	mov	x21, x0
    bac4:	f949d861 	ldr	x1, [x3, #5040]
    bac8:	f949ec60 	ldr	x0, [x3, #5080]
    bacc:	cb0102a1 	sub	x1, x21, x1
    bad0:	eb00403f 	cmp	x1, x0, lsl #16
    bad4:	54000322 	b.cs	bb38 <f0+0x1e64>  // b.hs, b.nlast
    bad8:	d350fc22 	lsr	x2, x1, #16
    badc:	f949fc63 	ldr	x3, [x3, #5112]
    bae0:	8b020842 	add	x2, x2, x2, lsl #2
    bae4:	d37df042 	lsl	x2, x2, #3
    bae8:	8b020060 	add	x0, x3, x2
    baec:	f9401017 	ldr	x23, [x0, #32]
    baf0:	b4000257 	cbz	x23, bb38 <f0+0x1e64>
    baf4:	38626862 	ldrb	w2, [x3, x2]
    baf8:	7100085f 	cmp	w2, #0x2
    bafc:	54002ec0 	b.eq	c0d4 <f0+0x2400>  // b.none
    bb00:	7100045f 	cmp	w2, #0x1
    bb04:	540001a1 	b.ne	bb38 <f0+0x1e64>  // b.any
    bb08:	29430002 	ldp	w2, w0, [x0, #24]
    bb0c:	92403c21 	and	x1, x1, #0xffff
    bb10:	9b027c21 	mul	x1, x1, x2
    bb14:	d360fc21 	lsr	x1, x1, #32
    bb18:	eb00003f 	cmp	x1, x0
    bb1c:	540000e2 	b.cs	bb38 <f0+0x1e64>  // b.hs, b.nlast
    bb20:	8b0102f7 	add	x23, x23, x1
    bb24:	394002e0 	ldrb	w0, [x23]
    bb28:	7103fc1f 	cmp	w0, #0xff
    bb2c:	54003ee0 	b.eq	c308 <f0+0x2634>  // b.none
    bb30:	52800020 	mov	w0, #0x1                   	// #1
    bb34:	390002e0 	strb	w0, [x23]
    bb38:	911d23e1 	add	x1, sp, #0x748
    bb3c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bb40:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bb44:	52800020 	mov	w0, #0x1                   	// #1
    bb48:	f903a7f7 	str	x23, [sp, #1864]
    bb4c:	f903abf5 	str	x21, [sp, #1872]
    bb50:	97ffe561 	bl	50d4 <fwp_data.part.0.constprop.0>
    bb54:	97ffe700 	bl	5754 <fwp_rc_fresh>
    bb58:	aa0003e2 	mov	x2, x0
    bb5c:	911d63e1 	add	x1, sp, #0x758
    bb60:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bb64:	52800020 	mov	w0, #0x1                   	// #1
    bb68:	f903aff5 	str	x21, [sp, #1880]
    bb6c:	f903b3e2 	str	x2, [sp, #1888]
    bb70:	97ffe559 	bl	50d4 <fwp_data.part.0.constprop.0>
    bb74:	97ffe6f8 	bl	5754 <fwp_rc_fresh>
    bb78:	aa0003e2 	mov	x2, x0
    bb7c:	911da3e1 	add	x1, sp, #0x768
    bb80:	52800020 	mov	w0, #0x1                   	// #1
    bb84:	f903b7f7 	str	x23, [sp, #1896]
    bb88:	f903bbe2 	str	x2, [sp, #1904]
    bb8c:	97ffe552 	bl	50d4 <fwp_data.part.0.constprop.0>
    bb90:	97ffe6f1 	bl	5754 <fwp_rc_fresh>
    bb94:	aa0003e2 	mov	x2, x0
    bb98:	911de3e1 	add	x1, sp, #0x778
    bb9c:	52800020 	mov	w0, #0x1                   	// #1
    bba0:	f903bff5 	str	x21, [sp, #1912]
    bba4:	f903c3e2 	str	x2, [sp, #1920]
    bba8:	97ffe54b 	bl	50d4 <fwp_data.part.0.constprop.0>
    bbac:	9117c283 	add	x3, x20, #0x5f0
    bbb0:	aa0003f5 	mov	x21, x0
    bbb4:	f949d861 	ldr	x1, [x3, #5040]
    bbb8:	f949ec60 	ldr	x0, [x3, #5080]
    bbbc:	cb0102a1 	sub	x1, x21, x1
    bbc0:	eb00403f 	cmp	x1, x0, lsl #16
    bbc4:	54000322 	b.cs	bc28 <f0+0x1f54>  // b.hs, b.nlast
    bbc8:	d350fc22 	lsr	x2, x1, #16
    bbcc:	f949fc63 	ldr	x3, [x3, #5112]
    bbd0:	8b020842 	add	x2, x2, x2, lsl #2
    bbd4:	d37df042 	lsl	x2, x2, #3
    bbd8:	8b020060 	add	x0, x3, x2
    bbdc:	f9401017 	ldr	x23, [x0, #32]
    bbe0:	b4000257 	cbz	x23, bc28 <f0+0x1f54>
    bbe4:	38626862 	ldrb	w2, [x3, x2]
    bbe8:	7100085f 	cmp	w2, #0x2
    bbec:	540026e0 	b.eq	c0c8 <f0+0x23f4>  // b.none
    bbf0:	7100045f 	cmp	w2, #0x1
    bbf4:	540001a1 	b.ne	bc28 <f0+0x1f54>  // b.any
    bbf8:	29430002 	ldp	w2, w0, [x0, #24]
    bbfc:	92403c21 	and	x1, x1, #0xffff
    bc00:	9b027c21 	mul	x1, x1, x2
    bc04:	d360fc21 	lsr	x1, x1, #32
    bc08:	eb00003f 	cmp	x1, x0
    bc0c:	540000e2 	b.cs	bc28 <f0+0x1f54>  // b.hs, b.nlast
    bc10:	8b0102f7 	add	x23, x23, x1
    bc14:	394002e0 	ldrb	w0, [x23]
    bc18:	7103fc1f 	cmp	w0, #0xff
    bc1c:	540037c0 	b.eq	c314 <f0+0x2640>  // b.none
    bc20:	52800020 	mov	w0, #0x1                   	// #1
    bc24:	390002e0 	strb	w0, [x23]
    bc28:	911e23e1 	add	x1, sp, #0x788
    bc2c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bc30:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bc34:	52800020 	mov	w0, #0x1                   	// #1
    bc38:	f903c7f7 	str	x23, [sp, #1928]
    bc3c:	f903cbf5 	str	x21, [sp, #1936]
    bc40:	97ffe525 	bl	50d4 <fwp_data.part.0.constprop.0>
    bc44:	97ffe6c4 	bl	5754 <fwp_rc_fresh>
    bc48:	aa0003e2 	mov	x2, x0
    bc4c:	911e63e1 	add	x1, sp, #0x798
    bc50:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bc54:	52800020 	mov	w0, #0x1                   	// #1
    bc58:	f903cff5 	str	x21, [sp, #1944]
    bc5c:	f903d3e2 	str	x2, [sp, #1952]
    bc60:	97ffe51d 	bl	50d4 <fwp_data.part.0.constprop.0>
    bc64:	97ffe6bc 	bl	5754 <fwp_rc_fresh>
    bc68:	aa0003e2 	mov	x2, x0
    bc6c:	911ea3e1 	add	x1, sp, #0x7a8
    bc70:	52800020 	mov	w0, #0x1                   	// #1
    bc74:	f903d7f7 	str	x23, [sp, #1960]
    bc78:	f903dbe2 	str	x2, [sp, #1968]
    bc7c:	97ffe516 	bl	50d4 <fwp_data.part.0.constprop.0>
    bc80:	97ffe6b5 	bl	5754 <fwp_rc_fresh>
    bc84:	aa0003e2 	mov	x2, x0
    bc88:	911ee3e1 	add	x1, sp, #0x7b8
    bc8c:	52800020 	mov	w0, #0x1                   	// #1
    bc90:	f903dff5 	str	x21, [sp, #1976]
    bc94:	f903e3e2 	str	x2, [sp, #1984]
    bc98:	97ffe50f 	bl	50d4 <fwp_data.part.0.constprop.0>
    bc9c:	97ffe6ae 	bl	5754 <fwp_rc_fresh>
    bca0:	aa0003e2 	mov	x2, x0
    bca4:	911f23e1 	add	x1, sp, #0x7c8
    bca8:	52800020 	mov	w0, #0x1                   	// #1
    bcac:	f903e7f7 	str	x23, [sp, #1992]
    bcb0:	f903ebe2 	str	x2, [sp, #2000]
    bcb4:	97ffe508 	bl	50d4 <fwp_data.part.0.constprop.0>
    bcb8:	97ffe6a7 	bl	5754 <fwp_rc_fresh>
    bcbc:	aa0003e2 	mov	x2, x0
    bcc0:	911f63e1 	add	x1, sp, #0x7d8
    bcc4:	52800020 	mov	w0, #0x1                   	// #1
    bcc8:	f903eff5 	str	x21, [sp, #2008]
    bccc:	f903f3e2 	str	x2, [sp, #2016]
    bcd0:	97ffe501 	bl	50d4 <fwp_data.part.0.constprop.0>
    bcd4:	97ffe6a0 	bl	5754 <fwp_rc_fresh>
    bcd8:	aa0003e2 	mov	x2, x0
    bcdc:	911fa3e1 	add	x1, sp, #0x7e8
    bce0:	52800020 	mov	w0, #0x1                   	// #1
    bce4:	f903f7f7 	str	x23, [sp, #2024]
    bce8:	f903fbe2 	str	x2, [sp, #2032]
    bcec:	97ffe4fa 	bl	50d4 <fwp_data.part.0.constprop.0>
    bcf0:	97ffe699 	bl	5754 <fwp_rc_fresh>
    bcf4:	aa0003e2 	mov	x2, x0
    bcf8:	911fe3e1 	add	x1, sp, #0x7f8
    bcfc:	52800020 	mov	w0, #0x1                   	// #1
    bd00:	f903fff5 	str	x21, [sp, #2040]
    bd04:	f90403e2 	str	x2, [sp, #2048]
    bd08:	97ffe4f3 	bl	50d4 <fwp_data.part.0.constprop.0>
    bd0c:	9117c283 	add	x3, x20, #0x5f0
    bd10:	aa0003f5 	mov	x21, x0
    bd14:	f949d861 	ldr	x1, [x3, #5040]
    bd18:	f949ec60 	ldr	x0, [x3, #5080]
    bd1c:	cb0102a1 	sub	x1, x21, x1
    bd20:	eb00403f 	cmp	x1, x0, lsl #16
    bd24:	54000322 	b.cs	bd88 <f0+0x20b4>  // b.hs, b.nlast
    bd28:	d350fc22 	lsr	x2, x1, #16
    bd2c:	f949fc63 	ldr	x3, [x3, #5112]
    bd30:	8b020842 	add	x2, x2, x2, lsl #2
    bd34:	d37df042 	lsl	x2, x2, #3
    bd38:	8b020060 	add	x0, x3, x2
    bd3c:	f9401017 	ldr	x23, [x0, #32]
    bd40:	b4000257 	cbz	x23, bd88 <f0+0x20b4>
    bd44:	38626862 	ldrb	w2, [x3, x2]
    bd48:	7100085f 	cmp	w2, #0x2
    bd4c:	54001b80 	b.eq	c0bc <f0+0x23e8>  // b.none
    bd50:	7100045f 	cmp	w2, #0x1
    bd54:	540001a1 	b.ne	bd88 <f0+0x20b4>  // b.any
    bd58:	29430002 	ldp	w2, w0, [x0, #24]
    bd5c:	92403c21 	and	x1, x1, #0xffff
    bd60:	9b027c21 	mul	x1, x1, x2
    bd64:	d360fc21 	lsr	x1, x1, #32
    bd68:	eb00003f 	cmp	x1, x0
    bd6c:	540000e2 	b.cs	bd88 <f0+0x20b4>  // b.hs, b.nlast
    bd70:	8b0102f7 	add	x23, x23, x1
    bd74:	394002e0 	ldrb	w0, [x23]
    bd78:	7103fc1f 	cmp	w0, #0xff
    bd7c:	54002d20 	b.eq	c320 <f0+0x264c>  // b.none
    bd80:	52800020 	mov	w0, #0x1                   	// #1
    bd84:	390002e0 	strb	w0, [x23]
    bd88:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bd8c:	912023e1 	add	x1, sp, #0x808
    bd90:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bd94:	52800020 	mov	w0, #0x1                   	// #1
    bd98:	f90407e2 	str	x2, [sp, #2056]
    bd9c:	f9040bf5 	str	x21, [sp, #2064]
    bda0:	97ffe4cd 	bl	50d4 <fwp_data.part.0.constprop.0>
    bda4:	97ffe66c 	bl	5754 <fwp_rc_fresh>
    bda8:	aa0003e2 	mov	x2, x0
    bdac:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bdb0:	912063e1 	add	x1, sp, #0x818
    bdb4:	52800020 	mov	w0, #0x1                   	// #1
    bdb8:	f9040fe3 	str	x3, [sp, #2072]
    bdbc:	f90413e2 	str	x2, [sp, #2080]
    bdc0:	97ffe4c5 	bl	50d4 <fwp_data.part.0.constprop.0>
    bdc4:	9117c283 	add	x3, x20, #0x5f0
    bdc8:	aa0003f5 	mov	x21, x0
    bdcc:	f949d861 	ldr	x1, [x3, #5040]
    bdd0:	f949ec60 	ldr	x0, [x3, #5080]
    bdd4:	cb0102a1 	sub	x1, x21, x1
    bdd8:	eb00403f 	cmp	x1, x0, lsl #16
    bddc:	54000322 	b.cs	be40 <f0+0x216c>  // b.hs, b.nlast
    bde0:	d350fc22 	lsr	x2, x1, #16
    bde4:	f949fc63 	ldr	x3, [x3, #5112]
    bde8:	8b020842 	add	x2, x2, x2, lsl #2
    bdec:	d37df042 	lsl	x2, x2, #3
    bdf0:	8b020060 	add	x0, x3, x2
    bdf4:	f9401017 	ldr	x23, [x0, #32]
    bdf8:	b4000257 	cbz	x23, be40 <f0+0x216c>
    bdfc:	38626862 	ldrb	w2, [x3, x2]
    be00:	7100085f 	cmp	w2, #0x2
    be04:	54001560 	b.eq	c0b0 <f0+0x23dc>  // b.none
    be08:	7100045f 	cmp	w2, #0x1
    be0c:	540001a1 	b.ne	be40 <f0+0x216c>  // b.any
    be10:	29430002 	ldp	w2, w0, [x0, #24]
    be14:	92403c21 	and	x1, x1, #0xffff
    be18:	9b027c21 	mul	x1, x1, x2
    be1c:	d360fc21 	lsr	x1, x1, #32
    be20:	eb00003f 	cmp	x1, x0
    be24:	540000e2 	b.cs	be40 <f0+0x216c>  // b.hs, b.nlast
    be28:	8b0102f7 	add	x23, x23, x1
    be2c:	394002e0 	ldrb	w0, [x23]
    be30:	7103fc1f 	cmp	w0, #0xff
    be34:	540027c0 	b.eq	c32c <f0+0x2658>  // b.none
    be38:	52800020 	mov	w0, #0x1                   	// #1
    be3c:	390002e0 	strb	w0, [x23]
    be40:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be44:	9117c294 	add	x20, x20, #0x5f0
    be48:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be4c:	9120a3e1 	add	x1, sp, #0x828
    be50:	52800020 	mov	w0, #0x1                   	// #1
    be54:	f90417e2 	str	x2, [sp, #2088]
    be58:	f9041bf5 	str	x21, [sp, #2096]
    be5c:	97ffe49e 	bl	50d4 <fwp_data.part.0.constprop.0>
    be60:	f949da81 	ldr	x1, [x20, #5040]
    be64:	aa0003f5 	mov	x21, x0
    be68:	f949ee80 	ldr	x0, [x20, #5080]
    be6c:	cb0102a1 	sub	x1, x21, x1
    be70:	eb00403f 	cmp	x1, x0, lsl #16
    be74:	54000322 	b.cs	bed8 <f0+0x2204>  // b.hs, b.nlast
    be78:	d350fc22 	lsr	x2, x1, #16
    be7c:	f949fe83 	ldr	x3, [x20, #5112]
    be80:	8b020842 	add	x2, x2, x2, lsl #2
    be84:	d37df042 	lsl	x2, x2, #3
    be88:	8b020060 	add	x0, x3, x2
    be8c:	f9401014 	ldr	x20, [x0, #32]
    be90:	b4000254 	cbz	x20, bed8 <f0+0x2204>
    be94:	38626862 	ldrb	w2, [x3, x2]
    be98:	7100085f 	cmp	w2, #0x2
    be9c:	54001040 	b.eq	c0a4 <f0+0x23d0>  // b.none
    bea0:	7100045f 	cmp	w2, #0x1
    bea4:	540001a1 	b.ne	bed8 <f0+0x2204>  // b.any
    bea8:	29430002 	ldp	w2, w0, [x0, #24]
    beac:	92403c21 	and	x1, x1, #0xffff
    beb0:	9b027c21 	mul	x1, x1, x2
    beb4:	d360fc21 	lsr	x1, x1, #32
    beb8:	eb00003f 	cmp	x1, x0
    bebc:	540000e2 	b.cs	bed8 <f0+0x2204>  // b.hs, b.nlast
    bec0:	8b010294 	add	x20, x20, x1
    bec4:	39400280 	ldrb	w0, [x20]
    bec8:	7103fc1f 	cmp	w0, #0xff
    becc:	540014c0 	b.eq	c164 <f0+0x2490>  // b.none
    bed0:	52800020 	mov	w0, #0x1                   	// #1
    bed4:	39000280 	strb	w0, [x20]
    bed8:	9120e3e1 	add	x1, sp, #0x838
    bedc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bee0:	52800020 	mov	w0, #0x1                   	// #1
    bee4:	f9041fe2 	str	x2, [sp, #2104]
    bee8:	f90423f5 	str	x21, [sp, #2112]
    beec:	97ffe47a 	bl	50d4 <fwp_data.part.0.constprop.0>
    bef0:	97ffe619 	bl	5754 <fwp_rc_fresh>
    bef4:	aa0003e2 	mov	x2, x0
    bef8:	aa1603e1 	mov	x1, x22
    befc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bf00:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bf04:	52800020 	mov	w0, #0x1                   	// #1
    bf08:	f90427e3 	str	x3, [sp, #2120]
    bf0c:	f9042be2 	str	x2, [sp, #2128]
    bf10:	97ffe471 	bl	50d4 <fwp_data.part.0.constprop.0>
    bf14:	97ffe610 	bl	5754 <fwp_rc_fresh>
    bf18:	aa0003f5 	mov	x21, x0
    bf1c:	aa1303e1 	mov	x1, x19
    bf20:	97fff0a4 	bl	81b0 <fwp_hof0.constprop.0>
    bf24:	aa0003f4 	mov	x20, x0
    bf28:	aa1503e0 	mov	x0, x21
    bf2c:	97ffe765 	bl	5cc0 <fwp_drop0>
    bf30:	aa1303e0 	mov	x0, x19
    bf34:	97ffe763 	bl	5cc0 <fwp_drop0>
    bf38:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bf3c:	f947f400 	ldr	x0, [x0, #4072]
    bf40:	f9442fe2 	ldr	x2, [sp, #2136]
    bf44:	f9400001 	ldr	x1, [x0]
    bf48:	eb010042 	subs	x2, x2, x1
    bf4c:	d2800001 	mov	x1, #0x0                   	// #0
    bf50:	54001f41 	b.ne	c338 <f0+0x2664>  // b.any
    bf54:	912183ff 	add	sp, sp, #0x860
    bf58:	aa1403e0 	mov	x0, x20
    bf5c:	a94153f3 	ldp	x19, x20, [sp, #16]
    bf60:	a9425bf5 	ldp	x21, x22, [sp, #32]
    bf64:	a94363f7 	ldp	x23, x24, [sp, #48]
    bf68:	a9446bf9 	ldp	x25, x26, [sp, #64]
    bf6c:	a94573fb 	ldp	x27, x28, [sp, #80]
    bf70:	a8c67bfd 	ldp	x29, x30, [sp], #96
    bf74:	d65f03c0 	ret
    bf78:	aa1b03e0 	mov	x0, x27
    bf7c:	97ffe251 	bl	48c0 <fwp_rc_forget_slot>
    bf80:	17fff79e 	b	9df8 <f0+0x124>
    bf84:	72003c5f 	tst	w2, #0xffff
    bf88:	54fef3a1 	b.ne	9dfc <f0+0x128>  // b.any
    bf8c:	17fff798 	b	9dec <f0+0x118>
    bf90:	72003c3f 	tst	w1, #0xffff
    bf94:	54ff9621 	b.ne	b258 <f0+0x1584>  // b.any
    bf98:	17fffcab 	b	b244 <f0+0x1570>
    bf9c:	72003c3f 	tst	w1, #0xffff
    bfa0:	54ff9001 	b.ne	b1a0 <f0+0x14cc>  // b.any
    bfa4:	17fffc7a 	b	b18c <f0+0x14b8>
    bfa8:	72003c3f 	tst	w1, #0xffff
    bfac:	54ff89e1 	b.ne	b0e8 <f0+0x1414>  // b.any
    bfb0:	17fffc49 	b	b0d4 <f0+0x1400>
    bfb4:	72003c3f 	tst	w1, #0xffff
    bfb8:	54ff84c1 	b.ne	b050 <f0+0x137c>  // b.any
    bfbc:	17fffc20 	b	b03c <f0+0x1368>
    bfc0:	72003c3f 	tst	w1, #0xffff
    bfc4:	54ff7dc1 	b.ne	af7c <f0+0x12a8>  // b.any
    bfc8:	17fffbe8 	b	af68 <f0+0x1294>
    bfcc:	72003c3f 	tst	w1, #0xffff
    bfd0:	54ff77a1 	b.ne	aec4 <f0+0x11f0>  // b.any
    bfd4:	17fffbb7 	b	aeb0 <f0+0x11dc>
    bfd8:	72003c3f 	tst	w1, #0xffff
    bfdc:	54ff7181 	b.ne	ae0c <f0+0x1138>  // b.any
    bfe0:	17fffb86 	b	adf8 <f0+0x1124>
    bfe4:	72003c3f 	tst	w1, #0xffff
    bfe8:	54ff6c61 	b.ne	ad74 <f0+0x10a0>  // b.any
    bfec:	17fffb5d 	b	ad60 <f0+0x108c>
    bff0:	72003c3f 	tst	w1, #0xffff
    bff4:	54ff0fc1 	b.ne	a1ec <f0+0x518>  // b.any
    bff8:	17fff878 	b	a1d8 <f0+0x504>
    bffc:	72003c3f 	tst	w1, #0xffff
    c000:	54ff0861 	b.ne	a10c <f0+0x438>  // b.any
    c004:	17fff83d 	b	a0f8 <f0+0x424>
    c008:	72003c3f 	tst	w1, #0xffff
    c00c:	54fef501 	b.ne	9eac <f0+0x1d8>  // b.any
    c010:	17fff7a2 	b	9e98 <f0+0x1c4>
    c014:	72003c3f 	tst	w1, #0xffff
    c018:	54ff2fa1 	b.ne	a60c <f0+0x938>  // b.any
    c01c:	17fff977 	b	a5f8 <f0+0x924>
    c020:	72003c3f 	tst	w1, #0xffff
    c024:	54ff27c1 	b.ne	a51c <f0+0x848>  // b.any
    c028:	17fff938 	b	a508 <f0+0x834>
    c02c:	72003c3f 	tst	w1, #0xffff
    c030:	54ff22a1 	b.ne	a484 <f0+0x7b0>  // b.any
    c034:	17fff90f 	b	a470 <f0+0x79c>
    c038:	72003c3f 	tst	w1, #0xffff
    c03c:	54ff1741 	b.ne	a324 <f0+0x650>  // b.any
    c040:	17fff8b4 	b	a310 <f0+0x63c>
    c044:	72003c3f 	tst	w1, #0xffff
    c048:	54ff6101 	b.ne	ac68 <f0+0xf94>  // b.any
    c04c:	17fffb02 	b	ac54 <f0+0xf80>
    c050:	72003c3f 	tst	w1, #0xffff
    c054:	54ff5ae1 	b.ne	abb0 <f0+0xedc>  // b.any
    c058:	17fffad1 	b	ab9c <f0+0xec8>
    c05c:	72003c3f 	tst	w1, #0xffff
    c060:	54ff54c1 	b.ne	aaf8 <f0+0xe24>  // b.any
    c064:	17fffaa0 	b	aae4 <f0+0xe10>
    c068:	72003c3f 	tst	w1, #0xffff
    c06c:	54ff4ea1 	b.ne	aa40 <f0+0xd6c>  // b.any
    c070:	17fffa6f 	b	aa2c <f0+0xd58>
    c074:	72003c3f 	tst	w1, #0xffff
    c078:	54ff4181 	b.ne	a8a8 <f0+0xbd4>  // b.any
    c07c:	17fffa06 	b	a894 <f0+0xbc0>
    c080:	72003c3f 	tst	w1, #0xffff
    c084:	54ff3b61 	b.ne	a7f0 <f0+0xb1c>  // b.any
    c088:	17fff9d5 	b	a7dc <f0+0xb08>
    c08c:	72003c3f 	tst	w1, #0xffff
    c090:	54ff3641 	b.ne	a758 <f0+0xa84>  // b.any
    c094:	17fff9ac 	b	a744 <f0+0xa70>
    c098:	72003c3f 	tst	w1, #0xffff
    c09c:	54ff3141 	b.ne	a6c4 <f0+0x9f0>  // b.any
    c0a0:	17fff984 	b	a6b0 <f0+0x9dc>
    c0a4:	72003c3f 	tst	w1, #0xffff
    c0a8:	54fff181 	b.ne	bed8 <f0+0x2204>  // b.any
    c0ac:	17ffff86 	b	bec4 <f0+0x21f0>
    c0b0:	72003c3f 	tst	w1, #0xffff
    c0b4:	54ffec61 	b.ne	be40 <f0+0x216c>  // b.any
    c0b8:	17ffff5d 	b	be2c <f0+0x2158>
    c0bc:	72003c3f 	tst	w1, #0xffff
    c0c0:	54ffe641 	b.ne	bd88 <f0+0x20b4>  // b.any
    c0c4:	17ffff2c 	b	bd74 <f0+0x20a0>
    c0c8:	72003c3f 	tst	w1, #0xffff
    c0cc:	54ffdae1 	b.ne	bc28 <f0+0x1f54>  // b.any
    c0d0:	17fffed1 	b	bc14 <f0+0x1f40>
    c0d4:	72003c3f 	tst	w1, #0xffff
    c0d8:	54ffd301 	b.ne	bb38 <f0+0x1e64>  // b.any
    c0dc:	17fffe92 	b	bb24 <f0+0x1e50>
    c0e0:	72003c3f 	tst	w1, #0xffff
    c0e4:	54ffce01 	b.ne	baa4 <f0+0x1dd0>  // b.any
    c0e8:	17fffe6a 	b	ba90 <f0+0x1dbc>
    c0ec:	72003c3f 	tst	w1, #0xffff
    c0f0:	54ffc7e1 	b.ne	b9ec <f0+0x1d18>  // b.any
    c0f4:	17fffe39 	b	b9d8 <f0+0x1d04>
    c0f8:	72003c3f 	tst	w1, #0xffff
    c0fc:	54ffc001 	b.ne	b8fc <f0+0x1c28>  // b.any
    c100:	17fffdfa 	b	b8e8 <f0+0x1c14>
    c104:	72003c3f 	tst	w1, #0xffff
    c108:	54ffbae1 	b.ne	b864 <f0+0x1b90>  // b.any
    c10c:	17fffdd1 	b	b850 <f0+0x1b7c>
    c110:	72003c3f 	tst	w1, #0xffff
    c114:	54ffb3e1 	b.ne	b790 <f0+0x1abc>  // b.any
    c118:	17fffd99 	b	b77c <f0+0x1aa8>
    c11c:	72003c3f 	tst	w1, #0xffff
    c120:	54ffadc1 	b.ne	b6d8 <f0+0x1a04>  // b.any
    c124:	17fffd68 	b	b6c4 <f0+0x19f0>
    c128:	72003c3f 	tst	w1, #0xffff
    c12c:	54ffa7a1 	b.ne	b620 <f0+0x194c>  // b.any
    c130:	17fffd37 	b	b60c <f0+0x1938>
    c134:	72003c3f 	tst	w1, #0xffff
    c138:	54ffa281 	b.ne	b588 <f0+0x18b4>  // b.any
    c13c:	17fffd0e 	b	b574 <f0+0x18a0>
    c140:	72003c3f 	tst	w1, #0xffff
    c144:	54ff9b81 	b.ne	b4b4 <f0+0x17e0>  // b.any
    c148:	17fffcd6 	b	b4a0 <f0+0x17cc>
    c14c:	72003c3f 	tst	w1, #0xffff
    c150:	54ff93a1 	b.ne	b3c4 <f0+0x16f0>  // b.any
    c154:	17fffc97 	b	b3b0 <f0+0x16dc>
    c158:	72003c3f 	tst	w1, #0xffff
    c15c:	54ff8e81 	b.ne	b32c <f0+0x1658>  // b.any
    c160:	17fffc6e 	b	b318 <f0+0x1644>
    c164:	aa1403e0 	mov	x0, x20
    c168:	97ffe1d6 	bl	48c0 <fwp_rc_forget_slot>
    c16c:	17ffff59 	b	bed0 <f0+0x21fc>
    c170:	aa1703e0 	mov	x0, x23
    c174:	97ffe1d3 	bl	48c0 <fwp_rc_forget_slot>
    c178:	17fff74b 	b	9ea4 <f0+0x1d0>
    c17c:	aa1703e0 	mov	x0, x23
    c180:	97ffe1d0 	bl	48c0 <fwp_rc_forget_slot>
    c184:	17fff7e0 	b	a104 <f0+0x430>
    c188:	aa1503e0 	mov	x0, x21
    c18c:	97ffe1cd 	bl	48c0 <fwp_rc_forget_slot>
    c190:	17fff815 	b	a1e4 <f0+0x510>
    c194:	aa1703e0 	mov	x0, x23
    c198:	97ffe1ca 	bl	48c0 <fwp_rc_forget_slot>
    c19c:	17fff860 	b	a31c <f0+0x648>
    c1a0:	aa1703e0 	mov	x0, x23
    c1a4:	97ffe1c7 	bl	48c0 <fwp_rc_forget_slot>
    c1a8:	17fff8b5 	b	a47c <f0+0x7a8>
    c1ac:	aa1703e0 	mov	x0, x23
    c1b0:	97ffe1c4 	bl	48c0 <fwp_rc_forget_slot>
    c1b4:	17fff8d8 	b	a514 <f0+0x840>
    c1b8:	aa1703e0 	mov	x0, x23
    c1bc:	97ffe1c1 	bl	48c0 <fwp_rc_forget_slot>
    c1c0:	17fff911 	b	a604 <f0+0x930>
    c1c4:	aa1703e0 	mov	x0, x23
    c1c8:	97ffe1be 	bl	48c0 <fwp_rc_forget_slot>
    c1cc:	17fff93c 	b	a6bc <f0+0x9e8>
    c1d0:	aa1703e0 	mov	x0, x23
    c1d4:	97ffe1bb 	bl	48c0 <fwp_rc_forget_slot>
    c1d8:	17fff95e 	b	a750 <f0+0xa7c>
    c1dc:	aa1703e0 	mov	x0, x23
    c1e0:	97ffe1b8 	bl	48c0 <fwp_rc_forget_slot>
    c1e4:	17fff981 	b	a7e8 <f0+0xb14>
    c1e8:	aa1703e0 	mov	x0, x23
    c1ec:	97ffe1b5 	bl	48c0 <fwp_rc_forget_slot>
    c1f0:	17fff9ac 	b	a8a0 <f0+0xbcc>
    c1f4:	aa1703e0 	mov	x0, x23
    c1f8:	97ffe1b2 	bl	48c0 <fwp_rc_forget_slot>
    c1fc:	17fffa0f 	b	aa38 <f0+0xd64>
    c200:	aa1703e0 	mov	x0, x23
    c204:	97ffe1af 	bl	48c0 <fwp_rc_forget_slot>
    c208:	17fffa3a 	b	aaf0 <f0+0xe1c>
    c20c:	aa1703e0 	mov	x0, x23
    c210:	97ffe1ac 	bl	48c0 <fwp_rc_forget_slot>
    c214:	17fffa65 	b	aba8 <f0+0xed4>
    c218:	aa1703e0 	mov	x0, x23
    c21c:	97ffe1a9 	bl	48c0 <fwp_rc_forget_slot>
    c220:	17fffa90 	b	ac60 <f0+0xf8c>
    c224:	aa1703e0 	mov	x0, x23
    c228:	97ffe1a6 	bl	48c0 <fwp_rc_forget_slot>
    c22c:	17fffad0 	b	ad6c <f0+0x1098>
    c230:	aa1703e0 	mov	x0, x23
    c234:	97ffe1a3 	bl	48c0 <fwp_rc_forget_slot>
    c238:	17fffaf3 	b	ae04 <f0+0x1130>
    c23c:	aa1703e0 	mov	x0, x23
    c240:	97ffe1a0 	bl	48c0 <fwp_rc_forget_slot>
    c244:	17fffb1e 	b	aebc <f0+0x11e8>
    c248:	aa1703e0 	mov	x0, x23
    c24c:	97ffe19d 	bl	48c0 <fwp_rc_forget_slot>
    c250:	17fffb49 	b	af74 <f0+0x12a0>
    c254:	aa1703e0 	mov	x0, x23
    c258:	97ffe19a 	bl	48c0 <fwp_rc_forget_slot>
    c25c:	17fffb7b 	b	b048 <f0+0x1374>
    c260:	aa1703e0 	mov	x0, x23
    c264:	97ffe197 	bl	48c0 <fwp_rc_forget_slot>
    c268:	17fffb9e 	b	b0e0 <f0+0x140c>
    c26c:	aa1703e0 	mov	x0, x23
    c270:	97ffe194 	bl	48c0 <fwp_rc_forget_slot>
    c274:	17fffbc9 	b	b198 <f0+0x14c4>
    c278:	aa1703e0 	mov	x0, x23
    c27c:	97ffe191 	bl	48c0 <fwp_rc_forget_slot>
    c280:	17fffbf4 	b	b250 <f0+0x157c>
    c284:	aa1703e0 	mov	x0, x23
    c288:	97ffe18e 	bl	48c0 <fwp_rc_forget_slot>
    c28c:	17fffc26 	b	b324 <f0+0x1650>
    c290:	aa1703e0 	mov	x0, x23
    c294:	97ffe18b 	bl	48c0 <fwp_rc_forget_slot>
    c298:	17fffc49 	b	b3bc <f0+0x16e8>
    c29c:	aa1703e0 	mov	x0, x23
    c2a0:	97ffe188 	bl	48c0 <fwp_rc_forget_slot>
    c2a4:	17fffc82 	b	b4ac <f0+0x17d8>
    c2a8:	aa1703e0 	mov	x0, x23
    c2ac:	97ffe185 	bl	48c0 <fwp_rc_forget_slot>
    c2b0:	17fffcb4 	b	b580 <f0+0x18ac>
    c2b4:	aa1703e0 	mov	x0, x23
    c2b8:	97ffe182 	bl	48c0 <fwp_rc_forget_slot>
    c2bc:	17fffcd7 	b	b618 <f0+0x1944>
    c2c0:	aa1703e0 	mov	x0, x23
    c2c4:	97ffe17f 	bl	48c0 <fwp_rc_forget_slot>
    c2c8:	17fffd02 	b	b6d0 <f0+0x19fc>
    c2cc:	aa1703e0 	mov	x0, x23
    c2d0:	97ffe17c 	bl	48c0 <fwp_rc_forget_slot>
    c2d4:	17fffd2d 	b	b788 <f0+0x1ab4>
    c2d8:	aa1703e0 	mov	x0, x23
    c2dc:	97ffe179 	bl	48c0 <fwp_rc_forget_slot>
    c2e0:	17fffd5f 	b	b85c <f0+0x1b88>
    c2e4:	aa1703e0 	mov	x0, x23
    c2e8:	97ffe176 	bl	48c0 <fwp_rc_forget_slot>
    c2ec:	17fffd82 	b	b8f4 <f0+0x1c20>
    c2f0:	aa1703e0 	mov	x0, x23
    c2f4:	97ffe173 	bl	48c0 <fwp_rc_forget_slot>
    c2f8:	17fffdbb 	b	b9e4 <f0+0x1d10>
    c2fc:	aa1703e0 	mov	x0, x23
    c300:	97ffe170 	bl	48c0 <fwp_rc_forget_slot>
    c304:	17fffde6 	b	ba9c <f0+0x1dc8>
    c308:	aa1703e0 	mov	x0, x23
    c30c:	97ffe16d 	bl	48c0 <fwp_rc_forget_slot>
    c310:	17fffe08 	b	bb30 <f0+0x1e5c>
    c314:	aa1703e0 	mov	x0, x23
    c318:	97ffe16a 	bl	48c0 <fwp_rc_forget_slot>
    c31c:	17fffe41 	b	bc20 <f0+0x1f4c>
    c320:	aa1703e0 	mov	x0, x23
    c324:	97ffe167 	bl	48c0 <fwp_rc_forget_slot>
    c328:	17fffe96 	b	bd80 <f0+0x20ac>
    c32c:	aa1703e0 	mov	x0, x23
    c330:	97ffe164 	bl	48c0 <fwp_rc_forget_slot>
    c334:	17fffec1 	b	be38 <f0+0x2164>
    c338:	97ffd976 	bl	2910 <__stack_chk_fail@plt>
    c33c:	d503201f 	nop

000000000000c340 <fwp_main_thread>:
    c340:	d10443ff 	sub	sp, sp, #0x110
    c344:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c348:	f947f400 	ldr	x0, [x0, #4072]
    c34c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c350:	910303fd 	add	x29, sp, #0xc0
    c354:	a90d53f3 	stp	x19, x20, [sp, #208]
    c358:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    c35c:	9117c261 	add	x1, x19, #0x5f0
    c360:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c364:	b953a421 	ldr	w1, [x1, #5028]
    c368:	f9400002 	ldr	x2, [x0]
    c36c:	f9005fe2 	str	x2, [sp, #184]
    c370:	d2800002 	mov	x2, #0x0                   	// #0
    c374:	34002821 	cbz	w1, c878 <fwp_main_thread+0x538>
    c378:	9117c273 	add	x19, x19, #0x5f0
    c37c:	b953aa60 	ldr	w0, [x19, #5032]
    c380:	35002740 	cbnz	w0, c868 <fwp_main_thread+0x528>
    c384:	91001fe2 	add	x2, sp, #0x7
    c388:	900000b5 	adrp	x21, 20000 <__data_start>
    c38c:	900000a3 	adrp	x3, 20000 <__data_start>
    c390:	9101c2b3 	add	x19, x21, #0x70
    c394:	91104063 	add	x3, x3, #0x410
    c398:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c39c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c3a0:	910023e0 	add	x0, sp, #0x8
    c3a4:	d2800001 	mov	x1, #0x0                   	// #0
    c3a8:	f90007e3 	str	x3, [sp, #8]
    c3ac:	b90013ff 	str	wzr, [sp, #16]
    c3b0:	a9019262 	stp	x2, x4, [x19, #24]
    c3b4:	f9000fe5 	str	x5, [sp, #24]
    c3b8:	97ffd8ee 	bl	2770 <sigaltstack@plt>
    c3bc:	350026e0 	cbnz	w0, c898 <fwp_main_thread+0x558>
    c3c0:	4f000400 	movi	v0.4s, #0x0
    c3c4:	9100a3e0 	add	x0, sp, #0x28
    c3c8:	f0ffffa1 	adrp	x1, 3000 <fwp_range_release+0x30>
    c3cc:	52800082 	mov	w2, #0x4                   	// #4
    c3d0:	9103c021 	add	x1, x1, #0xf0
    c3d4:	72a10002 	movk	w2, #0x800, lsl #16
    c3d8:	910083f4 	add	x20, sp, #0x20
    c3dc:	f90013e1 	str	x1, [sp, #32]
    c3e0:	3d802000 	str	q0, [x0, #128]
    c3e4:	b900abe2 	str	w2, [sp, #168]
    c3e8:	ad000000 	stp	q0, q0, [x0]
    c3ec:	ad010000 	stp	q0, q0, [x0, #32]
    c3f0:	ad020000 	stp	q0, q0, [x0, #64]
    c3f4:	ad030000 	stp	q0, q0, [x0, #96]
    c3f8:	97ffd936 	bl	28d0 <sigemptyset@plt>
    c3fc:	350024e0 	cbnz	w0, c898 <fwp_main_thread+0x558>
    c400:	aa1403e1 	mov	x1, x20
    c404:	d2800002 	mov	x2, #0x0                   	// #0
    c408:	52800160 	mov	w0, #0xb                   	// #11
    c40c:	97ffd949 	bl	2930 <sigaction@plt>
    c410:	35002440 	cbnz	w0, c898 <fwp_main_thread+0x558>
    c414:	aa1403e1 	mov	x1, x20
    c418:	d2800002 	mov	x2, #0x0                   	// #0
    c41c:	528000e0 	mov	w0, #0x7                   	// #7
    c420:	97ffd944 	bl	2930 <sigaction@plt>
    c424:	350023a0 	cbnz	w0, c898 <fwp_main_thread+0x558>
    c428:	b9436a60 	ldr	w0, [x19, #872]
    c42c:	34002000 	cbz	w0, c82c <fwp_main_thread+0x4ec>
    c430:	9101c2b3 	add	x19, x21, #0x70
    c434:	a90f63f7 	stp	x23, x24, [sp, #240]
    c438:	b9436e60 	ldr	w0, [x19, #876]
    c43c:	340020c0 	cbz	w0, c854 <fwp_main_thread+0x514>
    c440:	9101c2b6 	add	x22, x21, #0x70
    c444:	f9400ad4 	ldr	x20, [x22, #16]
    c448:	b40010f4 	cbz	x20, c664 <fwp_main_thread+0x324>
    c44c:	aa1403f3 	mov	x19, x20
    c450:	91010297 	add	x23, x20, #0x40
    c454:	f90083f9 	str	x25, [sp, #256]
    c458:	52800038 	mov	w24, #0x1                   	// #1
    c45c:	39414a99 	ldrb	w25, [x20, #82]
    c460:	39014a98 	strb	w24, [x20, #82]
    c464:	f9401680 	ldr	x0, [x20, #40]
    c468:	b4000620 	cbz	x0, c52c <fwp_main_thread+0x1ec>
    c46c:	f9403281 	ldr	x1, [x20, #96]
    c470:	39414680 	ldrb	w0, [x20, #81]
    c474:	b4000b61 	cbz	x1, c5e0 <fwp_main_thread+0x2a0>
    c478:	36000aa0 	tbz	w0, #0, c5cc <fwp_main_thread+0x28c>
    c47c:	39414a62 	ldrb	w2, [x19, #82]
    c480:	f9402280 	ldr	x0, [x20, #64]
    c484:	37000d82 	tbnz	w2, #0, c634 <fwp_main_thread+0x2f4>
    c488:	f9403261 	ldr	x1, [x19, #96]
    c48c:	a911fe77 	stp	x23, xzr, [x19, #280]
    c490:	f9009660 	str	x0, [x19, #296]
    c494:	b4000040 	cbz	x0, c49c <fwp_main_thread+0x15c>
    c498:	f9009013 	str	x19, [x0, #288]
    c49c:	f9002293 	str	x19, [x20, #64]
    c4a0:	b4000101 	cbz	x1, c4c0 <fwp_main_thread+0x180>
    c4a4:	f9407ec0 	ldr	x0, [x22, #248]
    c4a8:	39015678 	strb	w24, [x19, #85]
    c4ac:	f9003661 	str	x1, [x19, #104]
    c4b0:	a910827f 	stp	xzr, x0, [x19, #264]
    c4b4:	b4000040 	cbz	x0, c4bc <fwp_main_thread+0x17c>
    c4b8:	f9008413 	str	x19, [x0, #264]
    c4bc:	f9007ed3 	str	x19, [x22, #248]
    c4c0:	39015a7f 	strb	wzr, [x19, #86]
    c4c4:	97ffe8c8 	bl	67e4 <fwp_block>
    c4c8:	f9408e62 	ldr	x2, [x19, #280]
    c4cc:	b4000142 	cbz	x2, c4f4 <fwp_main_thread+0x1b4>
    c4d0:	a9520261 	ldp	x1, x0, [x19, #288]
    c4d4:	b4000bc1 	cbz	x1, c64c <fwp_main_thread+0x30c>
    c4d8:	f9009420 	str	x0, [x1, #296]
    c4dc:	f9409660 	ldr	x0, [x19, #296]
    c4e0:	b4000040 	cbz	x0, c4e8 <fwp_main_thread+0x1a8>
    c4e4:	f9009001 	str	x1, [x0, #288]
    c4e8:	91080260 	add	x0, x19, #0x200
    c4ec:	f900967f 	str	xzr, [x19, #296]
    c4f0:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c4f4:	39415660 	ldrb	w0, [x19, #85]
    c4f8:	f9400ac2 	ldr	x2, [x22, #16]
    c4fc:	36000980 	tbz	w0, #0, c62c <fwp_main_thread+0x2ec>
    c500:	a9508261 	ldp	x1, x0, [x19, #264]
    c504:	b4000a81 	cbz	x1, c654 <fwp_main_thread+0x314>
    c508:	f9008820 	str	x0, [x1, #272]
    c50c:	b4000040 	cbz	x0, c514 <fwp_main_thread+0x1d4>
    c510:	f9008401 	str	x1, [x0, #264]
    c514:	91080260 	add	x0, x19, #0x200
    c518:	3901567f 	strb	wzr, [x19, #85]
    c51c:	aa0203f3 	mov	x19, x2
    c520:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c524:	f9401680 	ldr	x0, [x20, #40]
    c528:	b5fffa20 	cbnz	x0, c46c <fwp_main_thread+0x12c>
    c52c:	9101c2a0 	add	x0, x21, #0x70
    c530:	39014a99 	strb	w25, [x20, #82]
    c534:	f94083f9 	ldr	x25, [sp, #256]
    c538:	f941a400 	ldr	x0, [x0, #840]
    c53c:	b4001580 	cbz	x0, c7ec <fwp_main_thread+0x4ac>
    c540:	9101c2a0 	add	x0, x21, #0x70
    c544:	f941c001 	ldr	x1, [x0, #896]
    c548:	b903781f 	str	wzr, [x0, #888]
    c54c:	eb13003f 	cmp	x1, x19
    c550:	540016a1 	b.ne	c824 <fwp_main_thread+0x4e4>  // b.any
    c554:	b4000933 	cbz	x19, c678 <fwp_main_thread+0x338>
    c558:	9101c2a0 	add	x0, x21, #0x70
    c55c:	52800021 	mov	w1, #0x1                   	// #1
    c560:	39014a61 	strb	w1, [x19, #82]
    c564:	f9419005 	ldr	x5, [x0, #800]
    c568:	b4000885 	cbz	x5, c678 <fwp_main_thread+0x338>
    c56c:	d503201f 	nop
    c570:	394140a0 	ldrb	w0, [x5, #80]
    c574:	37000060 	tbnz	w0, #0, c580 <fwp_main_thread+0x240>
    c578:	aa0503e0 	mov	x0, x5
    c57c:	97ffdc7d 	bl	3770 <fwp_cancel_tree.part.0>
    c580:	f9409ca5 	ldr	x5, [x5, #312]
    c584:	b5ffff65 	cbnz	x5, c570 <fwp_main_thread+0x230>
    c588:	9101c2b4 	add	x20, x21, #0x70
    c58c:	52800036 	mov	w22, #0x1                   	// #1
    c590:	f9402a60 	ldr	x0, [x19, #80]
    c594:	f2001c1f 	tst	x0, #0xff000000ff
    c598:	540000e1 	b.ne	c5b4 <fwp_main_thread+0x274>  // b.any
    c59c:	f9403e80 	ldr	x0, [x20, #120]
    c5a0:	39015276 	strb	w22, [x19, #84]
    c5a4:	f900827f 	str	xzr, [x19, #256]
    c5a8:	b40005a0 	cbz	x0, c65c <fwp_main_thread+0x31c>
    c5ac:	f9008013 	str	x19, [x0, #256]
    c5b0:	f9003e93 	str	x19, [x20, #120]
    c5b4:	97ffe88c 	bl	67e4 <fwp_block>
    c5b8:	97ffe81e 	bl	6630 <fwp_free_zombie>
    c5bc:	f9419280 	ldr	x0, [x20, #800]
    c5c0:	b40005c0 	cbz	x0, c678 <fwp_main_thread+0x338>
    c5c4:	f941c293 	ldr	x19, [x20, #896]
    c5c8:	17fffff2 	b	c590 <fwp_main_thread+0x250>
    c5cc:	97ffdd0d 	bl	3a00 <fwp_now_ns>
    c5d0:	f9403281 	ldr	x1, [x20, #96]
    c5d4:	eb01001f 	cmp	x0, x1
    c5d8:	54000fca 	b.ge	c7d0 <fwp_main_thread+0x490>  // b.tcont
    c5dc:	39414680 	ldrb	w0, [x20, #81]
    c5e0:	39414a62 	ldrb	w2, [x19, #82]
    c5e4:	3707f4e0 	tbnz	w0, #0, c480 <fwp_main_thread+0x140>
    c5e8:	f9403281 	ldr	x1, [x20, #96]
    c5ec:	370001c2 	tbnz	w2, #0, c624 <fwp_main_thread+0x2e4>
    c5f0:	f9403260 	ldr	x0, [x19, #96]
    c5f4:	b4000180 	cbz	x0, c624 <fwp_main_thread+0x2e4>
    c5f8:	b4000061 	cbz	x1, c604 <fwp_main_thread+0x2c4>
    c5fc:	eb01001f 	cmp	x0, x1
    c600:	9a81d000 	csel	x0, x0, x1, le
    c604:	f9402281 	ldr	x1, [x20, #64]
    c608:	a911fe77 	stp	x23, xzr, [x19, #280]
    c60c:	f9009661 	str	x1, [x19, #296]
    c610:	b4001381 	cbz	x1, c880 <fwp_main_thread+0x540>
    c614:	f9009033 	str	x19, [x1, #288]
    c618:	aa0003e1 	mov	x1, x0
    c61c:	f9002293 	str	x19, [x20, #64]
    c620:	17ffffa1 	b	c4a4 <fwp_main_thread+0x164>
    c624:	f9402280 	ldr	x0, [x20, #64]
    c628:	17ffff99 	b	c48c <fwp_main_thread+0x14c>
    c62c:	aa0203f3 	mov	x19, x2
    c630:	17ffff8d 	b	c464 <fwp_main_thread+0x124>
    c634:	a911fe77 	stp	x23, xzr, [x19, #280]
    c638:	f9009660 	str	x0, [x19, #296]
    c63c:	b4000040 	cbz	x0, c644 <fwp_main_thread+0x304>
    c640:	f9009013 	str	x19, [x0, #288]
    c644:	f9002293 	str	x19, [x20, #64]
    c648:	17ffff9e 	b	c4c0 <fwp_main_thread+0x180>
    c64c:	f9000040 	str	x0, [x2]
    c650:	17ffffa4 	b	c4e0 <fwp_main_thread+0x1a0>
    c654:	f9007ec0 	str	x0, [x22, #248]
    c658:	17ffffad 	b	c50c <fwp_main_thread+0x1cc>
    c65c:	f9004293 	str	x19, [x20, #128]
    c660:	17ffffd4 	b	c5b0 <fwp_main_thread+0x270>
    c664:	f941a6c0 	ldr	x0, [x22, #840]
    c668:	b4000c00 	cbz	x0, c7e8 <fwp_main_thread+0x4a8>
    c66c:	f941c2c0 	ldr	x0, [x22, #896]
    c670:	b9037adf 	str	wzr, [x22, #888]
    c674:	b5000d80 	cbnz	x0, c824 <fwp_main_thread+0x4e4>
    c678:	9101c2b4 	add	x20, x21, #0x70
    c67c:	97ffe7ed 	bl	6630 <fwp_free_zombie>
    c680:	f9404280 	ldr	x0, [x20, #128]
    c684:	b5000d00 	cbnz	x0, c824 <fwp_main_thread+0x4e4>
    c688:	f9407e80 	ldr	x0, [x20, #248]
    c68c:	b5000cc0 	cbnz	x0, c824 <fwp_main_thread+0x4e4>
    c690:	b9411a93 	ldr	w19, [x20, #280]
    c694:	340001d3 	cbz	w19, c6cc <fwp_main_thread+0x38c>
    c698:	93407e76 	sxtw	x22, w19
    c69c:	51000673 	sub	w19, w19, #0x1
    c6a0:	d1000ad6 	sub	x22, x22, #0x2
    c6a4:	91048297 	add	x23, x20, #0x120
    c6a8:	cb3342d6 	sub	x22, x22, w19, uxtw
    c6ac:	93407e73 	sxtw	x19, w19
    c6b0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c6b4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c6b8:	b9011a93 	str	w19, [x20, #280]
    c6bc:	d1000673 	sub	x19, x19, #0x1
    c6c0:	97ffd8dc 	bl	2a30 <munmap@plt>
    c6c4:	eb16027f 	cmp	x19, x22
    c6c8:	54ffff41 	b.ne	c6b0 <fwp_main_thread+0x370>  // b.any
    c6cc:	900000b3 	adrp	x19, 20000 <__data_start>
    c6d0:	91004260 	add	x0, x19, #0x10
    c6d4:	b9404000 	ldr	w0, [x0, #64]
    c6d8:	37f80040 	tbnz	w0, #31, c6e0 <fwp_main_thread+0x3a0>
    c6dc:	97ffd891 	bl	2920 <close@plt>
    c6e0:	9101c2a0 	add	x0, x21, #0x70
    c6e4:	91004261 	add	x1, x19, #0x10
    c6e8:	12800002 	mov	w2, #0xffffffff            	// #-1
    c6ec:	d2800013 	mov	x19, #0x0                   	// #0
    c6f0:	f941c416 	ldr	x22, [x0, #904]
    c6f4:	b9004022 	str	w2, [x1, #64]
    c6f8:	f941c814 	ldr	x20, [x0, #912]
    c6fc:	b4000176 	cbz	x22, c728 <fwp_main_thread+0x3e8>
    c700:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c704:	b40000c0 	cbz	x0, c71c <fwp_main_thread+0x3dc>
    c708:	f9400001 	ldr	x1, [x0]
    c70c:	b50008c1 	cbnz	x1, c824 <fwp_main_thread+0x4e4>
    c710:	f9400401 	ldr	x1, [x0, #8]
    c714:	b5000881 	cbnz	x1, c824 <fwp_main_thread+0x4e4>
    c718:	97ffe10a 	bl	4b40 <fwp_mem_free>
    c71c:	91000673 	add	x19, x19, #0x1
    c720:	eb16027f 	cmp	x19, x22
    c724:	54fffee1 	b.ne	c700 <fwp_main_thread+0x3c0>  // b.any
    c728:	aa1403e0 	mov	x0, x20
    c72c:	97ffe105 	bl	4b40 <fwp_mem_free>
    c730:	9101c2a0 	add	x0, x21, #0x70
    c734:	f941c013 	ldr	x19, [x0, #896]
    c738:	f901c41f 	str	xzr, [x0, #904]
    c73c:	f901c81f 	str	xzr, [x0, #912]
    c740:	b40001f3 	cbz	x19, c77c <fwp_main_thread+0x43c>
    c744:	f9401661 	ldr	x1, [x19, #40]
    c748:	b50006e1 	cbnz	x1, c824 <fwp_main_thread+0x4e4>
    c74c:	f9405661 	ldr	x1, [x19, #168]
    c750:	b50006a1 	cbnz	x1, c824 <fwp_main_thread+0x4e4>
    c754:	f941a401 	ldr	x1, [x0, #840]
    c758:	b5000661 	cbnz	x1, c824 <fwp_main_thread+0x4e4>
    c75c:	f941ac00 	ldr	x0, [x0, #856]
    c760:	b5000620 	cbnz	x0, c824 <fwp_main_thread+0x4e4>
    c764:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c768:	90000120 	adrp	x0, 30000 <alt.9+0xfbf0>
    c76c:	91104000 	add	x0, x0, #0x410
    c770:	97ffd85c 	bl	28e0 <memset@plt>
    c774:	aa1303e0 	mov	x0, x19
    c778:	97ffe0f2 	bl	4b40 <fwp_mem_free>
    c77c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c780:	f947ec00 	ldr	x0, [x0, #4056]
    c784:	9101c2b5 	add	x21, x21, #0x70
    c788:	f9400000 	ldr	x0, [x0]
    c78c:	f9000abf 	str	xzr, [x21, #16]
    c790:	f901c2bf 	str	xzr, [x21, #896]
    c794:	97ffd8ab 	bl	2a40 <fflush@plt>
    c798:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c79c:	f947f400 	ldr	x0, [x0, #4072]
    c7a0:	f9405fe2 	ldr	x2, [sp, #184]
    c7a4:	f9400001 	ldr	x1, [x0]
    c7a8:	eb010042 	subs	x2, x2, x1
    c7ac:	d2800001 	mov	x1, #0x0                   	// #0
    c7b0:	54000821 	b.ne	c8b4 <fwp_main_thread+0x574>  // b.any
    c7b4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c7b8:	d2800000 	mov	x0, #0x0                   	// #0
    c7bc:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c7c0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c7c4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c7c8:	910443ff 	add	sp, sp, #0x110
    c7cc:	d65f03c0 	ret
    c7d0:	39414280 	ldrb	w0, [x20, #80]
    c7d4:	3707f040 	tbnz	w0, #0, c5dc <fwp_main_thread+0x29c>
    c7d8:	aa1403e0 	mov	x0, x20
    c7dc:	97ffdbe5 	bl	3770 <fwp_cancel_tree.part.0>
    c7e0:	39414680 	ldrb	w0, [x20, #81]
    c7e4:	17ffff7f 	b	c5e0 <fwp_main_thread+0x2a0>
    c7e8:	d2800013 	mov	x19, #0x0                   	// #0
    c7ec:	9101c2b4 	add	x20, x21, #0x70
    c7f0:	f941ae80 	ldr	x0, [x20, #856]
    c7f4:	b5ffea60 	cbnz	x0, c540 <fwp_main_thread+0x200>
    c7f8:	f941a280 	ldr	x0, [x20, #832]
    c7fc:	97ffe0d1 	bl	4b40 <fwp_mem_free>
    c800:	f901a29f 	str	xzr, [x20, #832]
    c804:	f901aa9f 	str	xzr, [x20, #848]
    c808:	f941c280 	ldr	x0, [x20, #896]
    c80c:	b4000413 	cbz	x19, c88c <fwp_main_thread+0x54c>
    c810:	f900567f 	str	xzr, [x19, #168]
    c814:	f9005e7f 	str	xzr, [x19, #184]
    c818:	b9037a9f 	str	wzr, [x20, #888]
    c81c:	eb00027f 	cmp	x19, x0
    c820:	54ffe9c0 	b.eq	c558 <fwp_main_thread+0x218>  // b.none
    c824:	f90083f9 	str	x25, [sp, #256]
    c828:	97ffd84e 	bl	2960 <abort@plt>
    c82c:	f0ffffa0 	adrp	x0, 3000 <fwp_range_release+0x30>
    c830:	91078000 	add	x0, x0, #0x1e0
    c834:	940001df 	bl	cfb0 <atexit>
    c838:	a90f63f7 	stp	x23, x24, [sp, #240]
    c83c:	35000380 	cbnz	w0, c8ac <fwp_main_thread+0x56c>
    c840:	52800020 	mov	w0, #0x1                   	// #1
    c844:	b9036a60 	str	w0, [x19, #872]
    c848:	9101c2b3 	add	x19, x21, #0x70
    c84c:	b9436e60 	ldr	w0, [x19, #876]
    c850:	35ffdf80 	cbnz	w0, c440 <fwp_main_thread+0x100>
    c854:	97fff520 	bl	9cd4 <f0>
    c858:	f901ba60 	str	x0, [x19, #880]
    c85c:	52800021 	mov	w1, #0x1                   	// #1
    c860:	b9036e61 	str	w1, [x19, #876]
    c864:	17fffef7 	b	c440 <fwp_main_thread+0x100>
    c868:	90ffffc0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    c86c:	91008000 	add	x0, x0, #0x20
    c870:	940001d0 	bl	cfb0 <atexit>
    c874:	17fffec4 	b	c384 <fwp_main_thread+0x44>
    c878:	97ffde43 	bl	4184 <fwp_heap_init>
    c87c:	17fffebf 	b	c378 <fwp_main_thread+0x38>
    c880:	aa0003e1 	mov	x1, x0
    c884:	f9002293 	str	x19, [x20, #64]
    c888:	17ffff07 	b	c4a4 <fwp_main_thread+0x164>
    c88c:	b9037a9f 	str	wzr, [x20, #888]
    c890:	b4ffef40 	cbz	x0, c678 <fwp_main_thread+0x338>
    c894:	17ffffe4 	b	c824 <fwp_main_thread+0x4e4>
    c898:	b0000000 	adrp	x0, d000 <_IO_stdin_used+0x20>
    c89c:	91194000 	add	x0, x0, #0x650
    c8a0:	a90f63f7 	stp	x23, x24, [sp, #240]
    c8a4:	f90083f9 	str	x25, [sp, #256]
    c8a8:	97ffdbf6 	bl	3880 <fwp_trap>
    c8ac:	f90083f9 	str	x25, [sp, #256]
    c8b0:	97ffda40 	bl	31b0 <descent_phase_fail>
    c8b4:	f90083f9 	str	x25, [sp, #256]
    c8b8:	97ffd816 	bl	2910 <__stack_chk_fail@plt>
    c8bc:	d503201f 	nop

000000000000c8c0 <__divti3>:
    c8c0:	d503245f 	bti	c
    c8c4:	d2800004 	mov	x4, #0x0                   	// #0
    c8c8:	b7f80721 	tbnz	x1, #63, c9ac <__divti3+0xec>
    c8cc:	b6f80083 	tbz	x3, #63, c8dc <__divti3+0x1c>
    c8d0:	eb0203e2 	negs	x2, x2
    c8d4:	aa2403e4 	mvn	x4, x4
    c8d8:	da0303e3 	ngc	x3, x3
    c8dc:	aa0203e6 	mov	x6, x2
    c8e0:	aa0003e7 	mov	x7, x0
    c8e4:	aa0103e5 	mov	x5, x1
    c8e8:	b5000583 	cbnz	x3, c998 <__divti3+0xd8>
    c8ec:	eb01005f 	cmp	x2, x1
    c8f0:	54000e69 	b.ls	cabc <__divti3+0x1fc>  // b.plast
    c8f4:	dac01040 	clz	x0, x2
    c8f8:	b40000e0 	cbz	x0, c914 <__divti3+0x54>
    c8fc:	4b0003e1 	neg	w1, w0
    c900:	9ac020a5 	lsl	x5, x5, x0
    c904:	9ac02046 	lsl	x6, x2, x0
    c908:	9ac124e1 	lsr	x1, x7, x1
    c90c:	aa050025 	orr	x5, x1, x5
    c910:	9ac020e7 	lsl	x7, x7, x0
    c914:	d360fcc8 	lsr	x8, x6, #32
    c918:	92407cc2 	and	x2, x6, #0xffffffff
    c91c:	9ac808a3 	udiv	x3, x5, x8
    c920:	9b089465 	msub	x5, x3, x8, x5
    c924:	aa0303e0 	mov	x0, x3
    c928:	9b037c41 	mul	x1, x2, x3
    c92c:	93c780a5 	extr	x5, x5, x7, #32
    c930:	eb05003f 	cmp	x1, x5
    c934:	540000a9 	b.ls	c948 <__divti3+0x88>  // b.plast
    c938:	ab0500c5 	adds	x5, x6, x5
    c93c:	d1000460 	sub	x0, x3, #0x1
    c940:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c944:	540015a8 	b.hi	cbf8 <__divti3+0x338>  // b.pmore
    c948:	cb0100a5 	sub	x5, x5, x1
    c94c:	9ac808a3 	udiv	x3, x5, x8
    c950:	9b089465 	msub	x5, x3, x8, x5
    c954:	aa0303e1 	mov	x1, x3
    c958:	9b037c42 	mul	x2, x2, x3
    c95c:	aa0703e3 	mov	x3, x7
    c960:	b3607ca3 	bfi	x3, x5, #32, #32
    c964:	eb03005f 	cmp	x2, x3
    c968:	540000c9 	b.ls	c980 <__divti3+0xc0>  // b.plast
    c96c:	ab0300c3 	adds	x3, x6, x3
    c970:	d1000425 	sub	x5, x1, #0x1
    c974:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c978:	d1000821 	sub	x1, x1, #0x2
    c97c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    c980:	aa008020 	orr	x0, x1, x0, lsl #32
    c984:	d2800001 	mov	x1, #0x0                   	// #0
    c988:	b4000064 	cbz	x4, c994 <__divti3+0xd4>
    c98c:	eb0003e0 	negs	x0, x0
    c990:	da0103e1 	ngc	x1, x1
    c994:	d65f03c0 	ret
    c998:	eb01007f 	cmp	x3, x1
    c99c:	54000109 	b.ls	c9bc <__divti3+0xfc>  // b.plast
    c9a0:	d2800001 	mov	x1, #0x0                   	// #0
    c9a4:	d2800000 	mov	x0, #0x0                   	// #0
    c9a8:	17fffff8 	b	c988 <__divti3+0xc8>
    c9ac:	eb0003e0 	negs	x0, x0
    c9b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c9b4:	da0103e1 	ngc	x1, x1
    c9b8:	17ffffc5 	b	c8cc <__divti3+0xc>
    c9bc:	dac01067 	clz	x7, x3
    c9c0:	b40010e7 	cbz	x7, cbdc <__divti3+0x31c>
    c9c4:	d2800805 	mov	x5, #0x40                  	// #64
    c9c8:	cb0700a5 	sub	x5, x5, x7
    c9cc:	9ac72063 	lsl	x3, x3, x7
    c9d0:	9ac52448 	lsr	x8, x2, x5
    c9d4:	aa030108 	orr	x8, x8, x3
    c9d8:	9ac52426 	lsr	x6, x1, x5
    c9dc:	92407d0a 	and	x10, x8, #0xffffffff
    c9e0:	d360fd09 	lsr	x9, x8, #32
    c9e4:	9ac52403 	lsr	x3, x0, x5
    c9e8:	9ac72021 	lsl	x1, x1, x7
    c9ec:	aa010063 	orr	x3, x3, x1
    c9f0:	9ac72042 	lsl	x2, x2, x7
    c9f4:	9ac908cb 	udiv	x11, x6, x9
    c9f8:	9b099965 	msub	x5, x11, x9, x6
    c9fc:	aa0b03e1 	mov	x1, x11
    ca00:	9b0b7d46 	mul	x6, x10, x11
    ca04:	93c380a5 	extr	x5, x5, x3, #32
    ca08:	eb0500df 	cmp	x6, x5
    ca0c:	540000a9 	b.ls	ca20 <__divti3+0x160>  // b.plast
    ca10:	ab050105 	adds	x5, x8, x5
    ca14:	d1000561 	sub	x1, x11, #0x1
    ca18:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ca1c:	54000f48 	b.hi	cc04 <__divti3+0x344>  // b.pmore
    ca20:	cb0600a6 	sub	x6, x5, x6
    ca24:	9ac908cb 	udiv	x11, x6, x9
    ca28:	9b099969 	msub	x9, x11, x9, x6
    ca2c:	aa0b03e5 	mov	x5, x11
    ca30:	9b0b7d4a 	mul	x10, x10, x11
    ca34:	b3607d23 	bfi	x3, x9, #32, #32
    ca38:	eb03015f 	cmp	x10, x3
    ca3c:	540000a9 	b.ls	ca50 <__divti3+0x190>  // b.plast
    ca40:	ab030103 	adds	x3, x8, x3
    ca44:	d1000565 	sub	x5, x11, #0x1
    ca48:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ca4c:	54000e28 	b.hi	cc10 <__divti3+0x350>  // b.pmore
    ca50:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ca54:	92407c48 	and	x8, x2, #0xffffffff
    ca58:	2a0503e5 	mov	w5, w5
    ca5c:	d360fc42 	lsr	x2, x2, #32
    ca60:	d360fc26 	lsr	x6, x1, #32
    ca64:	cb0a0063 	sub	x3, x3, x10
    ca68:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    ca6c:	9b087caa 	mul	x10, x5, x8
    ca70:	9b087cc8 	mul	x8, x6, x8
    ca74:	9b0220a5 	madd	x5, x5, x2, x8
    ca78:	9b027cc6 	mul	x6, x6, x2
    ca7c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    ca80:	8b0900c5 	add	x5, x6, x9
    ca84:	eb02011f 	cmp	x8, x2
    ca88:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    ca8c:	8b4280c6 	add	x6, x6, x2, lsr #32
    ca90:	eb06007f 	cmp	x3, x6
    ca94:	540000e3 	b.cc	cab0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    ca98:	92407d4a 	and	x10, x10, #0xffffffff
    ca9c:	9ac72000 	lsl	x0, x0, x7
    caa0:	8b028142 	add	x2, x10, x2, lsl #32
    caa4:	eb02001f 	cmp	x0, x2
    caa8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    caac:	54000a01 	b.ne	cbec <__divti3+0x32c>  // b.any
    cab0:	d1000420 	sub	x0, x1, #0x1
    cab4:	d2800001 	mov	x1, #0x0                   	// #0
    cab8:	17ffffb4 	b	c988 <__divti3+0xc8>
    cabc:	b5000062 	cbnz	x2, cac8 <__divti3+0x208>
    cac0:	d2800022 	mov	x2, #0x1                   	// #1
    cac4:	9ac30846 	udiv	x6, x2, x3
    cac8:	dac010c8 	clz	x8, x6
    cacc:	b5000408 	cbnz	x8, cb4c <__divti3+0x28c>
    cad0:	d360fcc9 	lsr	x9, x6, #32
    cad4:	92407cc5 	and	x5, x6, #0xffffffff
    cad8:	cb060023 	sub	x3, x1, x6
    cadc:	d2800021 	mov	x1, #0x1                   	// #1
    cae0:	9ac90868 	udiv	x8, x3, x9
    cae4:	9b098d03 	msub	x3, x8, x9, x3
    cae8:	aa0803e0 	mov	x0, x8
    caec:	9b057d02 	mul	x2, x8, x5
    caf0:	93c78063 	extr	x3, x3, x7, #32
    caf4:	eb03005f 	cmp	x2, x3
    caf8:	540000a9 	b.ls	cb0c <__divti3+0x24c>  // b.plast
    cafc:	ab0300c3 	adds	x3, x6, x3
    cb00:	d1000500 	sub	x0, x8, #0x1
    cb04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cb08:	54000968 	b.hi	cc34 <__divti3+0x374>  // b.pmore
    cb0c:	cb020063 	sub	x3, x3, x2
    cb10:	9ac90862 	udiv	x2, x3, x9
    cb14:	aa0203e8 	mov	x8, x2
    cb18:	9b098c42 	msub	x2, x2, x9, x3
    cb1c:	aa0703e3 	mov	x3, x7
    cb20:	9b057d05 	mul	x5, x8, x5
    cb24:	b3607c43 	bfi	x3, x2, #32, #32
    cb28:	eb0300bf 	cmp	x5, x3
    cb2c:	540000c9 	b.ls	cb44 <__divti3+0x284>  // b.plast
    cb30:	ab0300c2 	adds	x2, x6, x3
    cb34:	d1000503 	sub	x3, x8, #0x1
    cb38:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cb3c:	d1000908 	sub	x8, x8, #0x2
    cb40:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cb44:	aa008100 	orr	x0, x8, x0, lsl #32
    cb48:	17ffff90 	b	c988 <__divti3+0xc8>
    cb4c:	9ac820c6 	lsl	x6, x6, x8
    cb50:	d2800803 	mov	x3, #0x40                  	// #64
    cb54:	cb080063 	sub	x3, x3, x8
    cb58:	d360fcc9 	lsr	x9, x6, #32
    cb5c:	9ac82027 	lsl	x7, x1, x8
    cb60:	92407cc5 	and	x5, x6, #0xffffffff
    cb64:	9ac32422 	lsr	x2, x1, x3
    cb68:	9ac32403 	lsr	x3, x0, x3
    cb6c:	aa070063 	orr	x3, x3, x7
    cb70:	9ac9084a 	udiv	x10, x2, x9
    cb74:	9ac82007 	lsl	x7, x0, x8
    cb78:	9b098940 	msub	x0, x10, x9, x2
    cb7c:	aa0a03e1 	mov	x1, x10
    cb80:	9b0a7ca2 	mul	x2, x5, x10
    cb84:	93c38000 	extr	x0, x0, x3, #32
    cb88:	eb00005f 	cmp	x2, x0
    cb8c:	540000a9 	b.ls	cba0 <__divti3+0x2e0>  // b.plast
    cb90:	ab0000c0 	adds	x0, x6, x0
    cb94:	d1000541 	sub	x1, x10, #0x1
    cb98:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cb9c:	54000468 	b.hi	cc28 <__divti3+0x368>  // b.pmore
    cba0:	cb020000 	sub	x0, x0, x2
    cba4:	9ac9080a 	udiv	x10, x0, x9
    cba8:	9b098140 	msub	x0, x10, x9, x0
    cbac:	aa0a03e2 	mov	x2, x10
    cbb0:	9b0a7ca8 	mul	x8, x5, x10
    cbb4:	b3607c03 	bfi	x3, x0, #32, #32
    cbb8:	eb03011f 	cmp	x8, x3
    cbbc:	540000a9 	b.ls	cbd0 <__divti3+0x310>  // b.plast
    cbc0:	ab0300c3 	adds	x3, x6, x3
    cbc4:	d1000542 	sub	x2, x10, #0x1
    cbc8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cbcc:	54000288 	b.hi	cc1c <__divti3+0x35c>  // b.pmore
    cbd0:	cb080063 	sub	x3, x3, x8
    cbd4:	aa018041 	orr	x1, x2, x1, lsl #32
    cbd8:	17ffffc2 	b	cae0 <__divti3+0x220>
    cbdc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cbe0:	d2800001 	mov	x1, #0x0                   	// #0
    cbe4:	9a9f87e0 	cset	x0, ls	// ls = plast
    cbe8:	17ffff68 	b	c988 <__divti3+0xc8>
    cbec:	aa0103e0 	mov	x0, x1
    cbf0:	d2800001 	mov	x1, #0x0                   	// #0
    cbf4:	17ffff65 	b	c988 <__divti3+0xc8>
    cbf8:	d1000860 	sub	x0, x3, #0x2
    cbfc:	8b0600a5 	add	x5, x5, x6
    cc00:	17ffff52 	b	c948 <__divti3+0x88>
    cc04:	d1000961 	sub	x1, x11, #0x2
    cc08:	8b0800a5 	add	x5, x5, x8
    cc0c:	17ffff85 	b	ca20 <__divti3+0x160>
    cc10:	d1000965 	sub	x5, x11, #0x2
    cc14:	8b080063 	add	x3, x3, x8
    cc18:	17ffff8e 	b	ca50 <__divti3+0x190>
    cc1c:	d1000942 	sub	x2, x10, #0x2
    cc20:	8b060063 	add	x3, x3, x6
    cc24:	17ffffeb 	b	cbd0 <__divti3+0x310>
    cc28:	d1000941 	sub	x1, x10, #0x2
    cc2c:	8b060000 	add	x0, x0, x6
    cc30:	17ffffdc 	b	cba0 <__divti3+0x2e0>
    cc34:	d1000900 	sub	x0, x8, #0x2
    cc38:	8b060063 	add	x3, x3, x6
    cc3c:	17ffffb4 	b	cb0c <__divti3+0x24c>

000000000000cc40 <__modti3>:
    cc40:	d503245f 	bti	c
    cc44:	d2800004 	mov	x4, #0x0                   	// #0
    cc48:	b6f80081 	tbz	x1, #63, cc58 <__modti3+0x18>
    cc4c:	eb0003e0 	negs	x0, x0
    cc50:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cc54:	da0103e1 	ngc	x1, x1
    cc58:	f100007f 	cmp	x3, #0x0
    cc5c:	5400128b 	b.lt	ceac <__modti3+0x26c>  // b.tstop
    cc60:	aa0003e7 	mov	x7, x0
    cc64:	aa0103e6 	mov	x6, x1
    cc68:	540004e1 	b.ne	cd04 <__modti3+0xc4>  // b.any
    cc6c:	eb02003f 	cmp	x1, x2
    cc70:	54000dc2 	b.cs	ce28 <__modti3+0x1e8>  // b.hs, b.nlast
    cc74:	dac01043 	clz	x3, x2
    cc78:	aa0303e5 	mov	x5, x3
    cc7c:	b40000e3 	cbz	x3, cc98 <__modti3+0x58>
    cc80:	4b0303e6 	neg	w6, w3
    cc84:	9ac32021 	lsl	x1, x1, x3
    cc88:	9ac32042 	lsl	x2, x2, x3
    cc8c:	9ac62406 	lsr	x6, x0, x6
    cc90:	aa0100c6 	orr	x6, x6, x1
    cc94:	9ac32007 	lsl	x7, x0, x3
    cc98:	d360fc40 	lsr	x0, x2, #32
    cc9c:	92407c43 	and	x3, x2, #0xffffffff
    cca0:	9ac008c1 	udiv	x1, x6, x0
    cca4:	9b009826 	msub	x6, x1, x0, x6
    cca8:	9b017c61 	mul	x1, x3, x1
    ccac:	93c780c6 	extr	x6, x6, x7, #32
    ccb0:	eb06003f 	cmp	x1, x6
    ccb4:	540000a9 	b.ls	ccc8 <__modti3+0x88>  // b.plast
    ccb8:	ab060046 	adds	x6, x2, x6
    ccbc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    ccc0:	8b0200c8 	add	x8, x6, x2
    ccc4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    ccc8:	cb0100c6 	sub	x6, x6, x1
    cccc:	9ac008c8 	udiv	x8, x6, x0
    ccd0:	9b009901 	msub	x1, x8, x0, x6
    ccd4:	aa0703e0 	mov	x0, x7
    ccd8:	9b087c63 	mul	x3, x3, x8
    ccdc:	b3607c20 	bfi	x0, x1, #32, #32
    cce0:	eb00007f 	cmp	x3, x0
    cce4:	54001088 	b.hi	cef4 <__modti3+0x2b4>  // b.pmore
    cce8:	cb030000 	sub	x0, x0, x3
    ccec:	9ac52400 	lsr	x0, x0, x5
    ccf0:	d2800001 	mov	x1, #0x0                   	// #0
    ccf4:	b4000064 	cbz	x4, cd00 <__modti3+0xc0>
    ccf8:	eb0003e0 	negs	x0, x0
    ccfc:	da0103e1 	ngc	x1, x1
    cd00:	d65f03c0 	ret
    cd04:	dac01066 	clz	x6, x3
    cd08:	eb03003f 	cmp	x1, x3
    cd0c:	54ffff43 	b.cc	ccf4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cd10:	93407cc5 	sxtw	x5, w6
    cd14:	d2800808 	mov	x8, #0x40                  	// #64
    cd18:	cb050108 	sub	x8, x8, x5
    cd1c:	9ac62063 	lsl	x3, x3, x6
    cd20:	9ac62025 	lsl	x5, x1, x6
    cd24:	9ac82447 	lsr	x7, x2, x8
    cd28:	aa0300e7 	orr	x7, x7, x3
    cd2c:	9ac82423 	lsr	x3, x1, x8
    cd30:	92407cec 	and	x12, x7, #0xffffffff
    cd34:	d360fcea 	lsr	x10, x7, #32
    cd38:	9ac82401 	lsr	x1, x0, x8
    cd3c:	aa050021 	orr	x1, x1, x5
    cd40:	9ac62042 	lsl	x2, x2, x6
    cd44:	9ac62000 	lsl	x0, x0, x6
    cd48:	9aca086b 	udiv	x11, x3, x10
    cd4c:	9b0a8d63 	msub	x3, x11, x10, x3
    cd50:	aa0b03e5 	mov	x5, x11
    cd54:	9b0b7d89 	mul	x9, x12, x11
    cd58:	93c18063 	extr	x3, x3, x1, #32
    cd5c:	eb03013f 	cmp	x9, x3
    cd60:	540000a9 	b.ls	cd74 <__modti3+0x134>  // b.plast
    cd64:	ab0300e3 	adds	x3, x7, x3
    cd68:	d1000565 	sub	x5, x11, #0x1
    cd6c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    cd70:	54001168 	b.hi	cf9c <__modti3+0x35c>  // b.pmore
    cd74:	cb090063 	sub	x3, x3, x9
    cd78:	9aca086b 	udiv	x11, x3, x10
    cd7c:	9b0a8d6a 	msub	x10, x11, x10, x3
    cd80:	aa0b03e9 	mov	x9, x11
    cd84:	9b0b7d8c 	mul	x12, x12, x11
    cd88:	b3607d41 	bfi	x1, x10, #32, #32
    cd8c:	eb01019f 	cmp	x12, x1
    cd90:	540000a9 	b.ls	cda4 <__modti3+0x164>  // b.plast
    cd94:	ab0100e1 	adds	x1, x7, x1
    cd98:	d1000569 	sub	x9, x11, #0x1
    cd9c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    cda0:	54000f88 	b.hi	cf90 <__modti3+0x350>  // b.pmore
    cda4:	aa058123 	orr	x3, x9, x5, lsl #32
    cda8:	92407c4b 	and	x11, x2, #0xffffffff
    cdac:	2a0903e9 	mov	w9, w9
    cdb0:	d360fc4a 	lsr	x10, x2, #32
    cdb4:	d360fc63 	lsr	x3, x3, #32
    cdb8:	cb0c0021 	sub	x1, x1, x12
    cdbc:	aa0a03ec 	mov	x12, x10
    cdc0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    cdc4:	9b0b7d25 	mul	x5, x9, x11
    cdc8:	9b0b7c6b 	mul	x11, x3, x11
    cdcc:	9b0a2d29 	madd	x9, x9, x10, x11
    cdd0:	92407caa 	and	x10, x5, #0xffffffff
    cdd4:	9b0c7c63 	mul	x3, x3, x12
    cdd8:	8b458125 	add	x5, x9, x5, lsr #32
    cddc:	8b0d0069 	add	x9, x3, x13
    cde0:	eb05017f 	cmp	x11, x5
    cde4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    cde8:	8b058149 	add	x9, x10, x5, lsl #32
    cdec:	8b458063 	add	x3, x3, x5, lsr #32
    cdf0:	eb03003f 	cmp	x1, x3
    cdf4:	54000063 	b.cc	ce00 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    cdf8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    cdfc:	54000082 	b.cs	ce0c <__modti3+0x1cc>  // b.hs, b.nlast
    ce00:	eb020129 	subs	x9, x9, x2
    ce04:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    ce08:	cb070063 	sub	x3, x3, x7
    ce0c:	eb090000 	subs	x0, x0, x9
    ce10:	da030021 	sbc	x1, x1, x3
    ce14:	9ac62400 	lsr	x0, x0, x6
    ce18:	9ac82028 	lsl	x8, x1, x8
    ce1c:	aa000100 	orr	x0, x8, x0
    ce20:	9ac62421 	lsr	x1, x1, x6
    ce24:	17ffffb4 	b	ccf4 <__modti3+0xb4>
    ce28:	b5000062 	cbnz	x2, ce34 <__modti3+0x1f4>
    ce2c:	d2800023 	mov	x3, #0x1                   	// #1
    ce30:	9ac20862 	udiv	x2, x3, x2
    ce34:	dac01048 	clz	x8, x2
    ce38:	aa0803e5 	mov	x5, x8
    ce3c:	b5000668 	cbnz	x8, cf08 <__modti3+0x2c8>
    ce40:	cb020020 	sub	x0, x1, x2
    ce44:	d360fc49 	lsr	x9, x2, #32
    ce48:	92407c4a 	and	x10, x2, #0xffffffff
    ce4c:	9ac90801 	udiv	x1, x0, x9
    ce50:	9b098020 	msub	x0, x1, x9, x0
    ce54:	9b0a7c21 	mul	x1, x1, x10
    ce58:	93c78000 	extr	x0, x0, x7, #32
    ce5c:	eb00003f 	cmp	x1, x0
    ce60:	540000a9 	b.ls	ce74 <__modti3+0x234>  // b.plast
    ce64:	ab000040 	adds	x0, x2, x0
    ce68:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ce6c:	8b020003 	add	x3, x0, x2
    ce70:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ce74:	cb010001 	sub	x1, x0, x1
    ce78:	9ac90820 	udiv	x0, x1, x9
    ce7c:	9b098403 	msub	x3, x0, x9, x1
    ce80:	aa0703e1 	mov	x1, x7
    ce84:	9b0a7c00 	mul	x0, x0, x10
    ce88:	b3607c61 	bfi	x1, x3, #32, #32
    ce8c:	eb01001f 	cmp	x0, x1
    ce90:	540000a9 	b.ls	cea4 <__modti3+0x264>  // b.plast
    ce94:	ab010041 	adds	x1, x2, x1
    ce98:	8b020022 	add	x2, x1, x2
    ce9c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cea0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cea4:	cb000020 	sub	x0, x1, x0
    cea8:	17ffff91 	b	ccec <__modti3+0xac>
    ceac:	eb0203e5 	negs	x5, x2
    ceb0:	aa0003e7 	mov	x7, x0
    ceb4:	da0303e8 	ngc	x8, x3
    ceb8:	aa0503e2 	mov	x2, x5
    cebc:	aa0803e3 	mov	x3, x8
    cec0:	aa0103e6 	mov	x6, x1
    cec4:	b4ffed48 	cbz	x8, cc6c <__modti3+0x2c>
    cec8:	eb01011f 	cmp	x8, x1
    cecc:	54fff148 	b.hi	ccf4 <__modti3+0xb4>  // b.pmore
    ced0:	dac01109 	clz	x9, x8
    ced4:	2a0903e6 	mov	w6, w9
    ced8:	b5fff1c9 	cbnz	x9, cd10 <__modti3+0xd0>
    cedc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    cee0:	54000068 	b.hi	ceec <__modti3+0x2ac>  // b.pmore
    cee4:	eb050007 	subs	x7, x0, x5
    cee8:	da080021 	sbc	x1, x1, x8
    ceec:	aa0703e0 	mov	x0, x7
    cef0:	17ffff81 	b	ccf4 <__modti3+0xb4>
    cef4:	ab000040 	adds	x0, x2, x0
    cef8:	8b020002 	add	x2, x0, x2
    cefc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    cf00:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    cf04:	17ffff79 	b	cce8 <__modti3+0xa8>
    cf08:	9ac82042 	lsl	x2, x2, x8
    cf0c:	d2800803 	mov	x3, #0x40                  	// #64
    cf10:	cb080063 	sub	x3, x3, x8
    cf14:	d360fc49 	lsr	x9, x2, #32
    cf18:	9ac82027 	lsl	x7, x1, x8
    cf1c:	92407c4a 	and	x10, x2, #0xffffffff
    cf20:	9ac32426 	lsr	x6, x1, x3
    cf24:	9ac32403 	lsr	x3, x0, x3
    cf28:	aa070063 	orr	x3, x3, x7
    cf2c:	9ac908c1 	udiv	x1, x6, x9
    cf30:	9ac82007 	lsl	x7, x0, x8
    cf34:	9b099820 	msub	x0, x1, x9, x6
    cf38:	9b017d41 	mul	x1, x10, x1
    cf3c:	93c38000 	extr	x0, x0, x3, #32
    cf40:	eb00003f 	cmp	x1, x0
    cf44:	540000a9 	b.ls	cf58 <__modti3+0x318>  // b.plast
    cf48:	ab000040 	adds	x0, x2, x0
    cf4c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cf50:	8b020006 	add	x6, x0, x2
    cf54:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    cf58:	cb010000 	sub	x0, x0, x1
    cf5c:	9ac90801 	udiv	x1, x0, x9
    cf60:	9b098026 	msub	x6, x1, x9, x0
    cf64:	aa0303e0 	mov	x0, x3
    cf68:	9b017d41 	mul	x1, x10, x1
    cf6c:	b3607cc0 	bfi	x0, x6, #32, #32
    cf70:	eb00003f 	cmp	x1, x0
    cf74:	540000a9 	b.ls	cf88 <__modti3+0x348>  // b.plast
    cf78:	ab000040 	adds	x0, x2, x0
    cf7c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cf80:	8b020003 	add	x3, x0, x2
    cf84:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cf88:	cb010000 	sub	x0, x0, x1
    cf8c:	17ffffb0 	b	ce4c <__modti3+0x20c>
    cf90:	d1000969 	sub	x9, x11, #0x2
    cf94:	8b070021 	add	x1, x1, x7
    cf98:	17ffff83 	b	cda4 <__modti3+0x164>
    cf9c:	d1000965 	sub	x5, x11, #0x2
    cfa0:	8b070063 	add	x3, x3, x7
    cfa4:	17ffff74 	b	cd74 <__modti3+0x134>
    cfa8:	d503201f 	nop
    cfac:	d503201f 	nop

000000000000cfb0 <atexit>:
    cfb0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cfb4:	900000a2 	adrp	x2, 20000 <__data_start>
    cfb8:	d2800001 	mov	x1, #0x0                   	// #0
    cfbc:	910003fd 	mov	x29, sp
    cfc0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cfc4:	f9400442 	ldr	x2, [x2, #8]
    cfc8:	17ffd612 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000cfcc <_fini>:
    cfcc:	d503201f 	nop
    cfd0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cfd4:	910003fd 	mov	x29, sp
    cfd8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cfdc:	d65f03c0 	ret
