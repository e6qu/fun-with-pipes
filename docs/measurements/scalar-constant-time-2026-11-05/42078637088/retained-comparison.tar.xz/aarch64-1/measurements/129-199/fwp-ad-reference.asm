
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	d0000045 	adrp	x5, c000 <fwp_main_thread+0x70>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	9137c0a5 	add	x5, x5, #0xdf0
    2aa0:	d0000044 	adrp	x4, c000 <fwp_main_thread+0x70>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	9137e084 	add	x4, x4, #0xdf8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940002ac 	bl	3580 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9100c261 	add	x1, x19, #0x30
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xf3a8>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9001c20 	str	x0, [x1, #56]
    2b2c:	940002f5 	bl	3700 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x410>
    2b34:	91074000 	add	x0, x0, #0x1d0
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	b0000042 	adrp	x2, b000 <f0+0x16b0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	913e4042 	add	x2, x2, #0xf90
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c273 	add	x19, x19, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9432a60 	ldr	w0, [x19, #808]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x410>
    2c7c:	91078000 	add	x0, x0, #0x1e0
    2c80:	94000240 	bl	3580 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x410>
    2c8c:	910a0000 	add	x0, x0, #0x280
    2c90:	9400023c 	bl	3580 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x410>
    2ca4:	91096000 	add	x0, x0, #0x258
    2ca8:	94000236 	bl	3580 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x410>
    2cb0:	9108a000 	add	x0, x0, #0x228
    2cb4:	94000233 	bl	3580 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x410>
    2cbc:	91080000 	add	x0, x0, #0x200
    2cc0:	94000230 	bl	3580 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91008000 	add	x0, x0, #0x20
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91008021 	add	x1, x1, #0x20
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91008000 	add	x0, x0, #0x20
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91008021 	add	x1, x1, #0x20
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	f0000041 	adrp	x1, d000 <_IO_stdin_used+0x410>
    2eb4:	91228021 	add	x1, x1, #0x8a0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    3050:	912fe000 	add	x0, x0, #0xbf8
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x410>
    3118:	91220021 	add	x1, x1, #0x880
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    3144:	911582a1 	add	x1, x21, #0x560
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xaa0>
    3158:	912540a5 	add	x5, x5, #0x950
    315c:	911582a1 	add	x1, x21, #0x560
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911582b7 	add	x23, x21, #0x560
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911582b5 	add	x21, x21, #0x560
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911582b5 	add	x21, x21, #0x560
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xaa0>
    32e8:	912520a5 	add	x5, x5, #0x948
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    33f0:	912fe000 	add	x0, x0, #0xbf8
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	b0000041 	adrp	x1, c000 <fwp_main_thread+0x70>
    3530:	aa1303e0 	mov	x0, x19
    3534:	91304021 	add	x1, x1, #0xc10
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	b0000041 	adrp	x1, c000 <fwp_main_thread+0x70>
    3544:	aa1303e0 	mov	x0, x19
    3548:	91306021 	add	x1, x1, #0xc18
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	b0000041 	adrp	x1, c000 <fwp_main_thread+0x70>
    3560:	91308021 	add	x1, x1, #0xc20
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_trap>:
    3580:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3584:	d53bd041 	mrs	x1, tpidr_el0
    3588:	91400021 	add	x1, x1, #0x0, lsl #12
    358c:	91004021 	add	x1, x1, #0x10
    3590:	910003fd 	mov	x29, sp
    3594:	a90153f3 	stp	x19, x20, [sp, #16]
    3598:	aa0003f3 	mov	x19, x0
    359c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    35a0:	f947ea94 	ldr	x20, [x20, #4048]
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	f9400035 	ldr	x21, [x1]
    35ac:	97fffe91 	bl	2ff0 <fwp_flush>
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	b0000042 	adrp	x2, c000 <fwp_main_thread+0x70>
    35b8:	aa1303e3 	mov	x3, x19
    35bc:	9130a042 	add	x2, x2, #0xc28
    35c0:	52800041 	mov	w1, #0x2                   	// #2
    35c4:	97fffccb 	bl	28f0 <__fprintf_chk@plt>
    35c8:	b40000b5 	cbz	x21, 35dc <fwp_trap+0x5c>
    35cc:	f9400280 	ldr	x0, [x20]
    35d0:	97fffcf8 	bl	29b0 <fflush@plt>
    35d4:	52800ca0 	mov	w0, #0x65                  	// #101
    35d8:	97fffd06 	bl	29f0 <_Exit@plt>
    35dc:	52800ca0 	mov	w0, #0x65                  	// #101
    35e0:	97fffc54 	bl	2730 <exit@plt>

00000000000035e4 <fwp_closure_drop_push>:
    35e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    35e8:	910003fd 	mov	x29, sp
    35ec:	a90153f3 	stp	x19, x20, [sp, #16]
    35f0:	aa0003f3 	mov	x19, x0
    35f4:	a9408014 	ldp	x20, x0, [x0, #8]
    35f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    35fc:	aa0103f5 	mov	x21, x1
    3600:	a90363f7 	stp	x23, x24, [sp, #48]
    3604:	eb00029f 	cmp	x20, x0
    3608:	54000160 	b.eq	3634 <fwp_closure_drop_push+0x50>  // b.none
    360c:	f9400276 	ldr	x22, [x19]
    3610:	d37df297 	lsl	x23, x20, #3
    3614:	91000694 	add	x20, x20, #0x1
    3618:	f9000674 	str	x20, [x19, #8]
    361c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3620:	f8376ad5 	str	x21, [x22, x23]
    3624:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3628:	a94363f7 	ldp	x23, x24, [sp, #48]
    362c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3630:	d65f03c0 	ret
    3634:	a9046bf9 	stp	x25, x26, [sp, #64]
    3638:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    363c:	eb00029f 	cmp	x20, x0
    3640:	54000568 	b.hi	36ec <fwp_closure_drop_push+0x108>  // b.pmore
    3644:	d37cee99 	lsl	x25, x20, #4
    3648:	d37ffa9a 	lsl	x26, x20, #1
    364c:	aa1903e0 	mov	x0, x25
    3650:	97fffc74 	bl	2820 <malloc@plt>
    3654:	aa0003f6 	mov	x22, x0
    3658:	b4000320 	cbz	x0, 36bc <fwp_closure_drop_push+0xd8>
    365c:	aa1303f8 	mov	x24, x19
    3660:	aa1903e3 	mov	x3, x25
    3664:	d37df297 	lsl	x23, x20, #3
    3668:	aa1703e2 	mov	x2, x23
    366c:	f8418719 	ldr	x25, [x24], #24
    3670:	aa1903e1 	mov	x1, x25
    3674:	97fffc57 	bl	27d0 <__memcpy_chk@plt>
    3678:	eb18033f 	cmp	x25, x24
    367c:	540000a0 	b.eq	3690 <fwp_closure_drop_push+0xac>  // b.none
    3680:	aa1903e0 	mov	x0, x25
    3684:	97fffcaf 	bl	2940 <free@plt>
    3688:	f9400674 	ldr	x20, [x19, #8]
    368c:	d37df297 	lsl	x23, x20, #3
    3690:	91000694 	add	x20, x20, #0x1
    3694:	f9000276 	str	x22, [x19]
    3698:	f9000a7a 	str	x26, [x19, #16]
    369c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    36a0:	f9000674 	str	x20, [x19, #8]
    36a4:	f8376ad5 	str	x21, [x22, x23]
    36a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    36b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    36b8:	d65f03c0 	ret
    36bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    36c0:	f947e863 	ldr	x3, [x3, #4048]
    36c4:	d2800262 	mov	x2, #0x13                  	// #19
    36c8:	d2800021 	mov	x1, #0x1                   	// #1
    36cc:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    36d0:	912fe000 	add	x0, x0, #0xbf8
    36d4:	f9400063 	ldr	x3, [x3]
    36d8:	97fffcaa 	bl	2980 <fwrite@plt>
    36dc:	d2800000 	mov	x0, #0x0                   	// #0
    36e0:	97fffcb4 	bl	29b0 <fflush@plt>
    36e4:	52800cc0 	mov	w0, #0x66                  	// #102
    36e8:	97fffcc2 	bl	29f0 <_Exit@plt>
    36ec:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    36f0:	9130e000 	add	x0, x0, #0xc38
    36f4:	97ffffa3 	bl	3580 <fwp_trap>
    36f8:	d503201f 	nop
    36fc:	d503201f 	nop

0000000000003700 <fwp_now_ns>:
    3700:	d100c3ff 	sub	sp, sp, #0x30
    3704:	52800020 	mov	w0, #0x1                   	// #1
    3708:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    370c:	f947f442 	ldr	x2, [x2, #4072]
    3710:	910023e1 	add	x1, sp, #0x8
    3714:	a9027bfd 	stp	x29, x30, [sp, #32]
    3718:	910083fd 	add	x29, sp, #0x20
    371c:	f9400043 	ldr	x3, [x2]
    3720:	f9000fe3 	str	x3, [sp, #24]
    3724:	d2800003 	mov	x3, #0x0                   	// #0
    3728:	97fffc22 	bl	27b0 <clock_gettime@plt>
    372c:	350002c0 	cbnz	w0, 3784 <fwp_now_ns+0x84>
    3730:	a9408be1 	ldp	x1, x2, [sp, #8]
    3734:	d2994003 	mov	x3, #0xca00                	// #51712
    3738:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    373c:	9b037c20 	mul	x0, x1, x3
    3740:	9b437c21 	smulh	x1, x1, x3
    3744:	ab020000 	adds	x0, x0, x2
    3748:	937ffc42 	asr	x2, x2, #63
    374c:	9a020021 	adc	x1, x1, x2
    3750:	f100001f 	cmp	x0, #0x0
    3754:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3758:	b50001e1 	cbnz	x1, 3794 <fwp_now_ns+0x94>
    375c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3760:	f947f421 	ldr	x1, [x1, #4072]
    3764:	f9400fe3 	ldr	x3, [sp, #24]
    3768:	f9400022 	ldr	x2, [x1]
    376c:	eb020063 	subs	x3, x3, x2
    3770:	d2800002 	mov	x2, #0x0                   	// #0
    3774:	540000e1 	b.ne	3790 <fwp_now_ns+0x90>  // b.any
    3778:	a9427bfd 	ldp	x29, x30, [sp, #32]
    377c:	9100c3ff 	add	sp, sp, #0x30
    3780:	d65f03c0 	ret
    3784:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    3788:	91316000 	add	x0, x0, #0xc58
    378c:	97ffff7d 	bl	3580 <fwp_trap>
    3790:	97fffc3c 	bl	2880 <__stack_chk_fail@plt>
    3794:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    3798:	9131e000 	add	x0, x0, #0xc78
    379c:	97ffff79 	bl	3580 <fwp_trap>

00000000000037a0 <fwp_closure_drop.part.0>:
    37a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37a4:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x410>
    37a8:	910003fd 	mov	x29, sp
    37ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    37b0:	f947f463 	ldr	x3, [x3, #4072]
    37b4:	a90153f3 	stp	x19, x20, [sp, #16]
    37b8:	d10883ff 	sub	sp, sp, #0x220
    37bc:	910003e2 	mov	x2, sp
    37c0:	d53bd053 	mrs	x19, tpidr_el0
    37c4:	910063f4 	add	x20, sp, #0x18
    37c8:	3dc22c20 	ldr	q0, [x1, #2224]
    37cc:	91400264 	add	x4, x19, #0x0, lsl #12
    37d0:	91004084 	add	x4, x4, #0x10
    37d4:	aa0003e1 	mov	x1, x0
    37d8:	aa0203e0 	mov	x0, x2
    37dc:	f9400062 	ldr	x2, [x3]
    37e0:	f9010fe2 	str	x2, [sp, #536]
    37e4:	d2800002 	mov	x2, #0x0                   	// #0
    37e8:	f90003f4 	str	x20, [sp]
    37ec:	f9000080 	str	x0, [x4]
    37f0:	3c8083e0 	stur	q0, [sp, #8]
    37f4:	97ffff7c 	bl	35e4 <fwp_closure_drop_push>
    37f8:	f94007e0 	ldr	x0, [sp, #8]
    37fc:	b4000280 	cbz	x0, 384c <fwp_closure_drop.part.0+0xac>
    3800:	f90123f5 	str	x21, [sp, #576]
    3804:	b00000f5 	adrp	x21, 20000 <__data_start>
    3808:	9100c2b5 	add	x21, x21, #0x30
    380c:	d503201f 	nop
    3810:	f94003e1 	ldr	x1, [sp]
    3814:	d1000400 	sub	x0, x0, #0x1
    3818:	f90007e0 	str	x0, [sp, #8]
    381c:	f9401ea2 	ldr	x2, [x21, #56]
    3820:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3824:	b9400001 	ldr	w1, [x0]
    3828:	8b011441 	add	x1, x2, x1, lsl #5
    382c:	f9400c21 	ldr	x1, [x1, #24]
    3830:	b4000321 	cbz	x1, 3894 <fwp_closure_drop.part.0+0xf4>
    3834:	f9400422 	ldr	x2, [x1, #8]
    3838:	52800001 	mov	w1, #0x0                   	// #0
    383c:	d63f0040 	blr	x2
    3840:	f94007e0 	ldr	x0, [sp, #8]
    3844:	b5fffe60 	cbnz	x0, 3810 <fwp_closure_drop.part.0+0x70>
    3848:	f94123f5 	ldr	x21, [sp, #576]
    384c:	91400273 	add	x19, x19, #0x0, lsl #12
    3850:	91004273 	add	x19, x19, #0x10
    3854:	f94003e0 	ldr	x0, [sp]
    3858:	f900027f 	str	xzr, [x19]
    385c:	eb14001f 	cmp	x0, x20
    3860:	54000040 	b.eq	3868 <fwp_closure_drop.part.0+0xc8>  // b.none
    3864:	97fffc37 	bl	2940 <free@plt>
    3868:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    386c:	f947f400 	ldr	x0, [x0, #4072]
    3870:	f9410fe2 	ldr	x2, [sp, #536]
    3874:	f9400001 	ldr	x1, [x0]
    3878:	eb010042 	subs	x2, x2, x1
    387c:	d2800001 	mov	x1, #0x0                   	// #0
    3880:	54000101 	b.ne	38a0 <fwp_closure_drop.part.0+0x100>  // b.any
    3884:	910883ff 	add	sp, sp, #0x220
    3888:	a94153f3 	ldp	x19, x20, [sp, #16]
    388c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3890:	d65f03c0 	ret
    3894:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    3898:	91328000 	add	x0, x0, #0xca0
    389c:	97ffff39 	bl	3580 <fwp_trap>
    38a0:	f90123f5 	str	x21, [sp, #576]
    38a4:	97fffbf7 	bl	2880 <__stack_chk_fail@plt>
    38a8:	d503201f 	nop
    38ac:	d503201f 	nop

00000000000038b0 <fwp_tape_of>:
    38b0:	92403c02 	and	x2, x0, #0xffff
    38b4:	b4000262 	cbz	x2, 3900 <fwp_tape_of+0x50>
    38b8:	9350fc01 	asr	x1, x0, #16
    38bc:	b00000e3 	adrp	x3, 20000 <__data_start>
    38c0:	d1000440 	sub	x0, x2, #0x1
    38c4:	9100c062 	add	x2, x3, #0x30
    38c8:	f9402042 	ldr	x2, [x2, #64]
    38cc:	eb00005f 	cmp	x2, x0
    38d0:	5400018d 	b.le	3900 <fwp_tape_of+0x50>
    38d4:	8b000402 	add	x2, x0, x0, lsl #1
    38d8:	f9401863 	ldr	x3, [x3, #48]
    38dc:	8b020802 	add	x2, x0, x2, lsl #2
    38e0:	d37df042 	lsl	x2, x2, #3
    38e4:	8b020060 	add	x0, x3, x2
    38e8:	b9400404 	ldr	w4, [x0, #4]
    38ec:	340000a4 	cbz	w4, 3900 <fwp_tape_of+0x50>
    38f0:	b8626862 	ldr	w2, [x3, x2]
    38f4:	6b01005f 	cmp	w2, w1
    38f8:	54000041 	b.ne	3900 <fwp_tape_of+0x50>  // b.any
    38fc:	d65f03c0 	ret
    3900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3904:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    3908:	91334000 	add	x0, x0, #0xcd0
    390c:	910003fd 	mov	x29, sp
    3910:	97ffff1c 	bl	3580 <fwp_trap>

0000000000003914 <fwp_format_g.constprop.0>:
    3914:	d10483ff 	sub	sp, sp, #0x120
    3918:	b0000044 	adrp	x4, c000 <fwp_main_thread+0x70>
    391c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3920:	f947f442 	ldr	x2, [x2, #4072]
    3924:	91348084 	add	x4, x4, #0xd20
    3928:	a90b7bfd 	stp	x29, x30, [sp, #176]
    392c:	9102c3fd 	add	x29, sp, #0xb0
    3930:	d2800803 	mov	x3, #0x40                  	// #64
    3934:	a90e63f7 	stp	x23, x24, [sp, #224]
    3938:	93407c38 	sxtw	x24, w1
    393c:	aa0303e1 	mov	x1, x3
    3940:	fd008be8 	str	d8, [sp, #272]
    3944:	1e604008 	fmov	d8, d0
    3948:	a90c53f3 	stp	x19, x20, [sp, #192]
    394c:	910083f4 	add	x20, sp, #0x20
    3950:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3954:	aa0003f5 	mov	x21, x0
    3958:	a91073fb 	stp	x27, x28, [sp, #256]
    395c:	5100071c 	sub	w28, w24, #0x1
    3960:	2a1c03e5 	mov	w5, w28
    3964:	f9400040 	ldr	x0, [x2]
    3968:	f90057e0 	str	x0, [sp, #168]
    396c:	d2800000 	mov	x0, #0x0                   	// #0
    3970:	52800042 	mov	w2, #0x2                   	// #2
    3974:	aa1403e0 	mov	x0, x20
    3978:	97fffb9e 	bl	27f0 <__snprintf_chk@plt>
    397c:	52800ca1 	mov	w1, #0x65                  	// #101
    3980:	aa1403e0 	mov	x0, x20
    3984:	97fffbf7 	bl	2960 <strchr@plt>
    3988:	aa0003f3 	mov	x19, x0
    398c:	52800142 	mov	w2, #0xa                   	// #10
    3990:	91000400 	add	x0, x0, #0x1
    3994:	d2800001 	mov	x1, #0x0                   	// #0
    3998:	97fffbe2 	bl	2920 <strtol@plt>
    399c:	aa0003f7 	mov	x23, x0
    39a0:	11001400 	add	w0, w0, #0x5
    39a4:	7100541f 	cmp	w0, #0x15
    39a8:	54000d88 	b.hi	3b58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    39ac:	4b170385 	sub	w5, w28, w23
    39b0:	710000bf 	cmp	w5, #0x0
    39b4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    39b8:	54000ba0 	b.eq	3b2c <fwp_format_g.constprop.0+0x218>  // b.none
    39bc:	394083e0 	ldrb	w0, [sp, #32]
    39c0:	cb180273 	sub	x19, x19, x24
    39c4:	91000673 	add	x19, x19, #0x1
    39c8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39cc:	7100b41f 	cmp	w0, #0x2d
    39d0:	9a941681 	cinc	x1, x20, eq	// eq = none
    39d4:	1a9f17e4 	cset	w4, eq	// eq = none
    39d8:	cb010266 	sub	x6, x19, x1
    39dc:	d10004da 	sub	x26, x6, #0x1
    39e0:	540018c0 	b.eq	3cf8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    39e4:	910183f9 	add	x25, sp, #0x60
    39e8:	d280091b 	mov	x27, #0x48                  	// #72
    39ec:	aa1903e7 	mov	x7, x25
    39f0:	91000423 	add	x3, x1, #0x1
    39f4:	91011cc6 	add	x6, x6, #0x47
    39f8:	910004f6 	add	x22, x7, #0x1
    39fc:	37f81017 	tbnz	w23, #31, 3bfc <fwp_format_g.constprop.0+0x2e8>
    3a00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3a04:	93407ef7 	sxtw	x23, w23
    3a08:	390000e4 	strb	w4, [x7]
    3a0c:	aa1303e1 	mov	x1, x19
    3a10:	aa1703e2 	mov	x2, x23
    3a14:	aa1603e0 	mov	x0, x22
    3a18:	b9000be5 	str	w5, [sp, #8]
    3a1c:	cb170374 	sub	x20, x27, x23
    3a20:	a9011be3 	stp	x3, x6, [sp, #16]
    3a24:	97fffb2b 	bl	26d0 <memcpy@plt>
    3a28:	d1000694 	sub	x20, x20, #0x1
    3a2c:	f9400be3 	ldr	x3, [sp, #16]
    3a30:	8b1702d6 	add	x22, x22, x23
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	aa1a03e2 	mov	x2, x26
    3a3c:	aa0303e1 	mov	x1, x3
    3a40:	aa1403e3 	mov	x3, x20
    3a44:	97fffb63 	bl	27d0 <__memcpy_chk@plt>
    3a48:	8b1a02d6 	add	x22, x22, x26
    3a4c:	f9400fe6 	ldr	x6, [sp, #24]
    3a50:	d2800900 	mov	x0, #0x48                  	// #72
    3a54:	b9400be5 	ldr	w5, [sp, #8]
    3a58:	8b170261 	add	x1, x19, x23
    3a5c:	cb1400c3 	sub	x3, x6, x20
    3a60:	cb060294 	sub	x20, x20, x6
    3a64:	f101207f 	cmp	x3, #0x48
    3a68:	93407cb8 	sxtw	x24, w5
    3a6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3a70:	aa1803e2 	mov	x2, x24
    3a74:	8b1802d3 	add	x19, x22, x24
    3a78:	8b140063 	add	x3, x3, x20
    3a7c:	aa1603e0 	mov	x0, x22
    3a80:	97fffb54 	bl	27d0 <__memcpy_chk@plt>
    3a84:	cb190273 	sub	x19, x19, x25
    3a88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a8c:	eb00027f 	cmp	x19, x0
    3a90:	aa1903e1 	mov	x1, x25
    3a94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a98:	aa1503e0 	mov	x0, x21
    3a9c:	aa1303e2 	mov	x2, x19
    3aa0:	97fffb0c 	bl	26d0 <memcpy@plt>
    3aa4:	38336abf 	strb	wzr, [x21, x19]
    3aa8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aac:	aa1503e0 	mov	x0, x21
    3ab0:	97fffb18 	bl	2710 <strlen@plt>
    3ab4:	aa0003f3 	mov	x19, x0
    3ab8:	528005c1 	mov	w1, #0x2e                  	// #46
    3abc:	aa1503e0 	mov	x0, x21
    3ac0:	97fffba8 	bl	2960 <strchr@plt>
    3ac4:	b4000160 	cbz	x0, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3ac8:	b4000153 	cbz	x19, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3acc:	d503201f 	nop
    3ad0:	aa1303e1 	mov	x1, x19
    3ad4:	d1000673 	sub	x19, x19, #0x1
    3ad8:	38736aa0 	ldrb	w0, [x21, x19]
    3adc:	7100c01f 	cmp	w0, #0x30
    3ae0:	54001001 	b.ne	3ce0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ae4:	38336abf 	strb	wzr, [x21, x19]
    3ae8:	b5ffff53 	cbnz	x19, 3ad0 <fwp_format_g.constprop.0+0x1bc>
    3aec:	d503201f 	nop
    3af0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3af4:	f947f400 	ldr	x0, [x0, #4072]
    3af8:	f94057e2 	ldr	x2, [sp, #168]
    3afc:	f9400001 	ldr	x1, [x0]
    3b00:	eb010042 	subs	x2, x2, x1
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	54001061 	b.ne	3d14 <fwp_format_g.constprop.0+0x400>  // b.any
    3b0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3b10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3b14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3b18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3b1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3b20:	fd408be8 	ldr	d8, [sp, #272]
    3b24:	910483ff 	add	sp, sp, #0x120
    3b28:	d65f03c0 	ret
    3b2c:	1e604100 	fmov	d0, d8
    3b30:	710000bf 	cmp	w5, #0x0
    3b34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	b0000044 	adrp	x4, c000 <fwp_main_thread+0x70>
    3b40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b44:	9134e084 	add	x4, x4, #0xd38
    3b48:	52800042 	mov	w2, #0x2                   	// #2
    3b4c:	d2803201 	mov	x1, #0x190                 	// #400
    3b50:	97fffb28 	bl	27f0 <__snprintf_chk@plt>
    3b54:	17ffffd6 	b	3aac <fwp_format_g.constprop.0+0x198>
    3b58:	cb140273 	sub	x19, x19, x20
    3b5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b60:	910183f9 	add	x25, sp, #0x60
    3b64:	aa1303e2 	mov	x2, x19
    3b68:	aa1403e1 	mov	x1, x20
    3b6c:	aa1903e0 	mov	x0, x25
    3b70:	d2800803 	mov	x3, #0x40                  	// #64
    3b74:	97fffb17 	bl	27d0 <__memcpy_chk@plt>
    3b78:	38336b3f 	strb	wzr, [x25, x19]
    3b7c:	aa1903e0 	mov	x0, x25
    3b80:	528005c1 	mov	w1, #0x2e                  	// #46
    3b84:	97fffb77 	bl	2960 <strchr@plt>
    3b88:	b40001c0 	cbz	x0, 3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b8c:	b50000b3 	cbnz	x19, 3ba0 <fwp_format_g.constprop.0+0x28c>
    3b90:	1400000c 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b94:	381ff01f 	sturb	wzr, [x0, #-1]
    3b98:	f1000673 	subs	x19, x19, #0x1
    3b9c:	54000120 	b.eq	3bc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ba0:	8b130320 	add	x0, x25, x19
    3ba4:	385ff001 	ldurb	w1, [x0, #-1]
    3ba8:	7100c03f 	cmp	w1, #0x30
    3bac:	54ffff40 	b.eq	3b94 <fwp_format_g.constprop.0+0x280>  // b.none
    3bb0:	d1000673 	sub	x19, x19, #0x1
    3bb4:	38736b20 	ldrb	w0, [x25, x19]
    3bb8:	7100b81f 	cmp	w0, #0x2e
    3bbc:	54000a80 	b.eq	3d0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3bc0:	710002ff 	cmp	w23, #0x0
    3bc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3bc8:	aa1903e5 	mov	x5, x25
    3bcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3bd0:	aa1503e0 	mov	x0, x21
    3bd4:	52800566 	mov	w6, #0x2b                  	// #43
    3bd8:	b0000044 	adrp	x4, c000 <fwp_main_thread+0x70>
    3bdc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3be0:	9134a084 	add	x4, x4, #0xd28
    3be4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3be8:	52800042 	mov	w2, #0x2                   	// #2
    3bec:	d2803201 	mov	x1, #0x190                 	// #400
    3bf0:	97fffb00 	bl	27f0 <__snprintf_chk@plt>
    3bf4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3bf8:	17ffffbe 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3bfc:	52800605 	mov	w5, #0x30                  	// #48
    3c00:	390000e5 	strb	w5, [x7]
    3c04:	d100077b 	sub	x27, x27, #0x1
    3c08:	aa0303e1 	mov	x1, x3
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	aa1b03e3 	mov	x3, x27
    3c14:	aa1a03e2 	mov	x2, x26
    3c18:	f90007e6 	str	x6, [sp, #8]
    3c1c:	b90013e4 	str	w4, [sp, #16]
    3c20:	8b1a02d6 	add	x22, x22, x26
    3c24:	b9001be5 	str	w5, [sp, #24]
    3c28:	97fffaea 	bl	27d0 <__memcpy_chk@plt>
    3c2c:	f94007e6 	ldr	x6, [sp, #8]
    3c30:	2a3703e7 	mvn	w7, w23
    3c34:	b94013e4 	ldr	w4, [sp, #16]
    3c38:	cb1b00c1 	sub	x1, x6, x27
    3c3c:	cb06037b 	sub	x27, x27, x6
    3c40:	f101203f 	cmp	x1, #0x48
    3c44:	d2800906 	mov	x6, #0x48                  	// #72
    3c48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3c4c:	8b1b0023 	add	x3, x1, x27
    3c50:	310006ff 	cmn	w23, #0x1
    3c54:	54000220 	b.eq	3c98 <fwp_format_g.constprop.0+0x384>  // b.none
    3c58:	b9401be5 	ldr	w5, [sp, #24]
    3c5c:	d2800001 	mov	x1, #0x0                   	// #0
    3c60:	f101207f 	cmp	x3, #0x48
    3c64:	d1000462 	sub	x2, x3, #0x1
    3c68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3c6c:	38216ac5 	strb	w5, [x22, x1]
    3c70:	cb030003 	sub	x3, x0, x3
    3c74:	91000421 	add	x1, x1, #0x1
    3c78:	91000463 	add	x3, x3, #0x1
    3c7c:	eb00007f 	cmp	x3, x0
    3c80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c84:	cb000063 	sub	x3, x3, x0
    3c88:	8b020063 	add	x3, x3, x2
    3c8c:	6b0100ff 	cmp	w7, w1
    3c90:	54fffe8c 	b.gt	3c60 <fwp_format_g.constprop.0+0x34c>
    3c94:	8b2742d6 	add	x22, x22, w7, uxtw
    3c98:	f101207f 	cmp	x3, #0x48
    3c9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ca0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ca4:	aa1603e0 	mov	x0, x22
    3ca8:	cb0300a1 	sub	x1, x5, x3
    3cac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3cb0:	91000421 	add	x1, x1, #0x1
    3cb4:	d1000463 	sub	x3, x3, #0x1
    3cb8:	eb05003f 	cmp	x1, x5
    3cbc:	38001402 	strb	w2, [x0], #1
    3cc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3cc4:	93407f82 	sxtw	x2, w28
    3cc8:	cb050025 	sub	x5, x1, x5
    3ccc:	aa1303e1 	mov	x1, x19
    3cd0:	8b0300a3 	add	x3, x5, x3
    3cd4:	8b1802d3 	add	x19, x22, x24
    3cd8:	97fffabe 	bl	27d0 <__memcpy_chk@plt>
    3cdc:	17ffff6a 	b	3a84 <fwp_format_g.constprop.0+0x170>
    3ce0:	d1000421 	sub	x1, x1, #0x1
    3ce4:	38616aa0 	ldrb	w0, [x21, x1]
    3ce8:	7100b81f 	cmp	w0, #0x2e
    3cec:	54fff021 	b.ne	3af0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3cf0:	38216abf 	strb	wzr, [x21, x1]
    3cf4:	17ffff7f 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3cf8:	910187e7 	add	x7, sp, #0x61
    3cfc:	910183f9 	add	x25, sp, #0x60
    3d00:	d28008fb 	mov	x27, #0x47                  	// #71
    3d04:	390183e0 	strb	w0, [sp, #96]
    3d08:	17ffff3a 	b	39f0 <fwp_format_g.constprop.0+0xdc>
    3d0c:	38336b3f 	strb	wzr, [x25, x19]
    3d10:	17ffffac 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3d14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d18:	97fffada 	bl	2880 <__stack_chk_fail@plt>
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_heap_report>:
    3d20:	d105c3ff 	sub	sp, sp, #0x170
    3d24:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc80>
    3d28:	91158042 	add	x2, x2, #0x560
    3d2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3d30:	f947e821 	ldr	x1, [x1, #4048]
    3d34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3d38:	910443fd 	add	x29, sp, #0x110
    3d3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d40:	f947f400 	ldr	x0, [x0, #4072]
    3d44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3d48:	a91463f7 	stp	x23, x24, [sp, #320]
    3d4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3d50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3d54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3d58:	fd4a2049 	ldr	d9, [x2, #5184]
    3d5c:	f9400036 	ldr	x22, [x1]
    3d60:	f9400001 	ldr	x1, [x0]
    3d64:	f90087e1 	str	x1, [sp, #264]
    3d68:	d2800001 	mov	x1, #0x0                   	// #0
    3d6c:	f949e459 	ldr	x25, [x2, #5064]
    3d70:	b0000041 	adrp	x1, c000 <fwp_main_thread+0x70>
    3d74:	f94a1057 	ldr	x23, [x2, #5152]
    3d78:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    3d7c:	f94a1458 	ldr	x24, [x2, #5160]
    3d80:	91350021 	add	x1, x1, #0xd40
    3d84:	91352000 	add	x0, x0, #0xd48
    3d88:	97fffaa2 	bl	2810 <fopen@plt>
    3d8c:	b4000740 	cbz	x0, 3e74 <fwp_heap_report+0x154>
    3d90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d94:	a91253f3 	stp	x19, x20, [sp, #288]
    3d98:	aa0003f4 	mov	x20, x0
    3d9c:	910023f3 	add	x19, sp, #0x8
    3da0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3da4:	72aae915 	movk	w21, #0x5748, lsl #16
    3da8:	aa1403e2 	mov	x2, x20
    3dac:	aa1303e0 	mov	x0, x19
    3db0:	52802001 	mov	w1, #0x100                 	// #256
    3db4:	97fffb23 	bl	2a40 <fgets@plt>
    3db8:	b4000280 	cbz	x0, 3e08 <fwp_heap_report+0xe8>
    3dbc:	b9400261 	ldr	w1, [x19]
    3dc0:	6b15003f 	cmp	w1, w21
    3dc4:	54ffff21 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dc8:	39401260 	ldrb	w0, [x19, #4]
    3dcc:	7101341f 	cmp	w0, #0x4d
    3dd0:	54fffec1 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dd4:	394037e0 	ldrb	w0, [sp, #13]
    3dd8:	7100e81f 	cmp	w0, #0x3a
    3ddc:	54fffe61 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3de0:	52800142 	mov	w2, #0xa                   	// #10
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	91003be0 	add	x0, sp, #0xe
    3dec:	97fffacd 	bl	2920 <strtol@plt>
    3df0:	aa1403e2 	mov	x2, x20
    3df4:	aa0003fa 	mov	x26, x0
    3df8:	52802001 	mov	w1, #0x100                 	// #256
    3dfc:	aa1303e0 	mov	x0, x19
    3e00:	97fffb10 	bl	2a40 <fgets@plt>
    3e04:	b5fffdc0 	cbnz	x0, 3dbc <fwp_heap_report+0x9c>
    3e08:	aa1403e0 	mov	x0, x20
    3e0c:	97fffa7d 	bl	2800 <fclose@plt>
    3e10:	a95253f3 	ldp	x19, x20, [sp, #288]
    3e14:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3e18:	f947f400 	ldr	x0, [x0, #4072]
    3e1c:	f94087e2 	ldr	x2, [sp, #264]
    3e20:	f9400001 	ldr	x1, [x0]
    3e24:	eb010042 	subs	x2, x2, x1
    3e28:	d2800001 	mov	x1, #0x0                   	// #0
    3e2c:	54000281 	b.ne	3e7c <fwp_heap_report+0x15c>  // b.any
    3e30:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3e34:	aa1a03e6 	mov	x6, x26
    3e38:	aa1903e5 	mov	x5, x25
    3e3c:	aa1803e4 	mov	x4, x24
    3e40:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3e44:	aa1703e3 	mov	x3, x23
    3e48:	a95463f7 	ldp	x23, x24, [sp, #320]
    3e4c:	aa1603e0 	mov	x0, x22
    3e50:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3e54:	1e604121 	fmov	d1, d9
    3e58:	1e604100 	fmov	d0, d8
    3e5c:	b0000042 	adrp	x2, c000 <fwp_main_thread+0x70>
    3e60:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3e64:	9135a042 	add	x2, x2, #0xd68
    3e68:	9105c3ff 	add	sp, sp, #0x170
    3e6c:	52800041 	mov	w1, #0x2                   	// #2
    3e70:	17fffaa0 	b	28f0 <__fprintf_chk@plt>
    3e74:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3e78:	17ffffe7 	b	3e14 <fwp_heap_report+0xf4>
    3e7c:	a91253f3 	stp	x19, x20, [sp, #288]
    3e80:	97fffa80 	bl	2880 <__stack_chk_fail@plt>

0000000000003e84 <fwp_heap_init>:
    3e84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e88:	f0000163 	adrp	x3, 32000 <fwp_heap+0xaa0>
    3e8c:	91118061 	add	x1, x3, #0x460
    3e90:	910003fd 	mov	x29, sp
    3e94:	a90153f3 	stp	x19, x20, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc80>
    3e9c:	91158262 	add	x2, x19, #0x560
    3ea0:	a9025bf5 	stp	x21, x22, [sp, #32]
    3ea4:	52800024 	mov	w4, #0x1                   	// #1
    3ea8:	52800200 	mov	w0, #0x10                  	// #16
    3eac:	b913a444 	str	w4, [x2, #5028]
    3eb0:	b8004420 	str	w0, [x1], #4
    3eb4:	11004000 	add	w0, w0, #0x10
    3eb8:	7104401f 	cmp	w0, #0x110
    3ebc:	54ffffa1 	b.ne	3eb0 <fwp_heap_init+0x2c>  // b.any
    3ec0:	d0000042 	adrp	x2, d000 <_IO_stdin_used+0x410>
    3ec4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ec8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xaa0>
    3ecc:	91128021 	add	x1, x1, #0x4a0
    3ed0:	3dc23043 	ldr	q3, [x2, #2240]
    3ed4:	d2800000 	mov	x0, #0x0                   	// #0
    3ed8:	4e040401 	dup	v1.4s, v0.s[0]
    3edc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ee0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ee4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ee8:	3ca06821 	str	q1, [x1, x0]
    3eec:	91004000 	add	x0, x0, #0x10
    3ef0:	f101801f 	cmp	x0, #0x60
    3ef4:	54ffff21 	b.ne	3ed8 <fwp_heap_init+0x54>  // b.any
    3ef8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xaa0>
    3efc:	91118063 	add	x3, x3, #0x460
    3f00:	91140084 	add	x4, x4, #0x500
    3f04:	91158266 	add	x6, x19, #0x560
    3f08:	d2800002 	mov	x2, #0x0                   	// #0
    3f0c:	d2800000 	mov	x0, #0x0                   	// #0
    3f10:	d2880205 	mov	x5, #0x4010                	// #16400
    3f14:	d503201f 	nop
    3f18:	910f0001 	add	x1, x0, #0x3c0
    3f1c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3f20:	eb02003f 	cmp	x1, x2
    3f24:	540000a2 	b.cs	3f38 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3f28:	91000400 	add	x0, x0, #0x1
    3f2c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3f30:	eb02003f 	cmp	x1, x2
    3f34:	54ffffa3 	b.cc	3f28 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3f38:	91004042 	add	x2, x2, #0x10
    3f3c:	38001480 	strb	w0, [x4], #1
    3f40:	eb05005f 	cmp	x2, x5
    3f44:	54fffea1 	b.ne	3f18 <fwp_heap_init+0x94>  // b.any
    3f48:	528000b5 	mov	w21, #0x5                   	// #5
    3f4c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3f50:	14000004 	b	3f60 <fwp_heap_init+0xdc>
    3f54:	d342fe94 	lsr	x20, x20, #2
    3f58:	710006b5 	subs	w21, w21, #0x1
    3f5c:	54000720 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3f60:	91404296 	add	x22, x20, #0x10, lsl #12
    3f64:	d2800005 	mov	x5, #0x0                   	// #0
    3f68:	aa1603e1 	mov	x1, x22
    3f6c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f70:	52880443 	mov	w3, #0x4022                	// #16418
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	d2800000 	mov	x0, #0x0                   	// #0
    3f7c:	97fffa65 	bl	2910 <mmap@plt>
    3f80:	aa0003e6 	mov	x6, x0
    3f84:	b100041f 	cmn	x0, #0x1
    3f88:	54fffe60 	b.eq	3f54 <fwp_heap_init+0xd0>  // b.none
    3f8c:	b40005a0 	cbz	x0, 4040 <fwp_heap_init+0x1bc>
    3f90:	d350fe94 	lsr	x20, x20, #16
    3f94:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f98:	8b0000c7 	add	x7, x6, x0
    3f9c:	91158275 	add	x21, x19, #0x560
    3fa0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3fa4:	8b140a81 	add	x1, x20, x20, lsl #2
    3fa8:	d2800005 	mov	x5, #0x0                   	// #0
    3fac:	12800004 	mov	w4, #0xffffffff            	// #-1
    3fb0:	d37df021 	lsl	x1, x1, #3
    3fb4:	52880443 	mov	w3, #0x4022                	// #16418
    3fb8:	52800002 	mov	w2, #0x0                   	// #0
    3fbc:	d2800000 	mov	x0, #0x0                   	// #0
    3fc0:	f909daa7 	str	x7, [x21, #5040]
    3fc4:	f909dea6 	str	x6, [x21, #5048]
    3fc8:	f909e2b6 	str	x22, [x21, #5056]
    3fcc:	f909eab4 	str	x20, [x21, #5072]
    3fd0:	f90a02a1 	str	x1, [x21, #5120]
    3fd4:	97fffa4f 	bl	2910 <mmap@plt>
    3fd8:	aa0003e1 	mov	x1, x0
    3fdc:	b100041f 	cmn	x0, #0x1
    3fe0:	54000300 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3fe4:	b0000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    3fe8:	91386000 	add	x0, x0, #0xe18
    3fec:	f909fea1 	str	x1, [x21, #5112]
    3ff0:	97fffa88 	bl	2a10 <getenv@plt>
    3ff4:	52800002 	mov	w2, #0x0                   	// #0
    3ff8:	aa0003e1 	mov	x1, x0
    3ffc:	b40000e0 	cbz	x0, 4018 <fwp_heap_init+0x194>
    4000:	39400000 	ldrb	w0, [x0]
    4004:	340000a0 	cbz	w0, 4018 <fwp_heap_init+0x194>
    4008:	7100c000 	subs	w0, w0, #0x30
    400c:	54000120 	b.eq	4030 <fwp_heap_init+0x1ac>  // b.none
    4010:	7100001f 	cmp	w0, #0x0
    4014:	1a9f07e2 	cset	w2, ne	// ne = any
    4018:	91158273 	add	x19, x19, #0x560
    401c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4020:	b913aa62 	str	w2, [x19, #5032]
    4024:	a94153f3 	ldp	x19, x20, [sp, #16]
    4028:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402c:	d65f03c0 	ret
    4030:	39400420 	ldrb	w0, [x1, #1]
    4034:	7100001f 	cmp	w0, #0x0
    4038:	1a9f07e2 	cset	w2, ne	// ne = any
    403c:	17fffff7 	b	4018 <fwp_heap_init+0x194>
    4040:	97fffbfc 	bl	3030 <fwp_heap_oom>

0000000000004044 <caf75>:
    4044:	900000e2 	adrp	x2, 20000 <__data_start>
    4048:	9100c041 	add	x1, x2, #0x30
    404c:	b9404820 	ldr	w0, [x1, #72]
    4050:	34000060 	cbz	w0, 405c <caf75+0x18>
    4054:	f9402820 	ldr	x0, [x1, #80]
    4058:	d65f03c0 	ret
    405c:	b9405820 	ldr	w0, [x1, #88]
    4060:	340000e0 	cbz	w0, 407c <caf75+0x38>
    4064:	f9403020 	ldr	x0, [x1, #96]
    4068:	9100c042 	add	x2, x2, #0x30
    406c:	52800021 	mov	w1, #0x1                   	// #1
    4070:	b9004841 	str	w1, [x2, #72]
    4074:	f9002840 	str	x0, [x2, #80]
    4078:	d65f03c0 	ret
    407c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4080:	52800024 	mov	w4, #0x1                   	// #1
    4084:	aa0303e0 	mov	x0, x3
    4088:	b9005824 	str	w4, [x1, #88]
    408c:	f9003023 	str	x3, [x1, #96]
    4090:	17fffff6 	b	4068 <caf75+0x24>

0000000000004094 <fwp_wake_io>:
    4094:	900000e9 	adrp	x9, 20000 <__data_start>
    4098:	9100c122 	add	x2, x9, #0x30
    409c:	f9400001 	ldr	x1, [x0]
    40a0:	5280000a 	mov	w10, #0x0                   	// #0
    40a4:	f9401446 	ldr	x6, [x2, #40]
    40a8:	52800008 	mov	w8, #0x0                   	// #0
    40ac:	4f000400 	movi	v0.4s, #0x0
    40b0:	52800027 	mov	w7, #0x1                   	// #1
    40b4:	aa0103e2 	mov	x2, x1
    40b8:	b4000321 	cbz	x1, 411c <fwp_wake_io+0x88>
    40bc:	f9408c25 	ldr	x5, [x1, #280]
    40c0:	39015c27 	strb	w7, [x1, #87]
    40c4:	b4000165 	cbz	x5, 40f0 <fwp_wake_io+0x5c>
    40c8:	a9520c24 	ldp	x4, x3, [x1, #288]
    40cc:	b4000364 	cbz	x4, 4138 <fwp_wake_io+0xa4>
    40d0:	f9009483 	str	x3, [x4, #296]
    40d4:	f9409423 	ldr	x3, [x1, #296]
    40d8:	b4000043 	cbz	x3, 40e0 <fwp_wake_io+0x4c>
    40dc:	f9009064 	str	x4, [x3, #288]
    40e0:	91080023 	add	x3, x1, #0x200
    40e4:	f900943f 	str	xzr, [x1, #296]
    40e8:	3c918060 	stur	q0, [x3, #-232]
    40ec:	f9400001 	ldr	x1, [x0]
    40f0:	f9402843 	ldr	x3, [x2, #80]
    40f4:	f2001c7f 	tst	x3, #0xff000000ff
    40f8:	54fffde1 	b.ne	40b4 <fwp_wake_io+0x20>  // b.any
    40fc:	39015047 	strb	w7, [x2, #84]
    4100:	f900805f 	str	xzr, [x2, #256]
    4104:	b40001e6 	cbz	x6, 4140 <fwp_wake_io+0xac>
    4108:	f90080c2 	str	x2, [x6, #256]
    410c:	aa0203e6 	mov	x6, x2
    4110:	52800028 	mov	w8, #0x1                   	// #1
    4114:	aa0103e2 	mov	x2, x1
    4118:	b5fffd21 	cbnz	x1, 40bc <fwp_wake_io+0x28>
    411c:	3400006a 	cbz	w10, 4128 <fwp_wake_io+0x94>
    4120:	9100c120 	add	x0, x9, #0x30
    4124:	f900180b 	str	x11, [x0, #48]
    4128:	34000068 	cbz	w8, 4134 <fwp_wake_io+0xa0>
    412c:	9100c129 	add	x9, x9, #0x30
    4130:	f9001526 	str	x6, [x9, #40]
    4134:	d65f03c0 	ret
    4138:	f90000a3 	str	x3, [x5]
    413c:	17ffffe7 	b	40d8 <fwp_wake_io+0x44>
    4140:	aa0203eb 	mov	x11, x2
    4144:	5280002a 	mov	w10, #0x1                   	// #1
    4148:	17fffff1 	b	410c <fwp_wake_io+0x78>
    414c:	d503201f 	nop

0000000000004150 <fwp_tape_buffers_release>:
    4150:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4154:	910003fd 	mov	x29, sp
    4158:	a90153f3 	stp	x19, x20, [sp, #16]
    415c:	aa0003f3 	mov	x19, x0
    4160:	f9401400 	ldr	x0, [x0, #40]
    4164:	b7f80760 	tbnz	x0, #63, 4250 <fwp_tape_buffers_release+0x100>
    4168:	f9401a61 	ldr	x1, [x19, #48]
    416c:	b7f80301 	tbnz	x1, #63, 41cc <fwp_tape_buffers_release+0x7c>
    4170:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4174:	eb02001f 	cmp	x0, x2
    4178:	540002a8 	b.hi	41cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    417c:	8b000400 	add	x0, x0, x0, lsl #1
    4180:	d2a00102 	mov	x2, #0x80000               	// #524288
    4184:	d37df000 	lsl	x0, x0, #3
    4188:	cb000042 	sub	x2, x2, x0
    418c:	eb420c3f 	cmp	x1, x2, lsr #3
    4190:	540001e8 	b.hi	41cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    4194:	8b010c14 	add	x20, x0, x1, lsl #3
    4198:	90000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    419c:	9138a000 	add	x0, x0, #0xe28
    41a0:	97fffa1c 	bl	2a10 <getenv@plt>
    41a4:	b4000240 	cbz	x0, 41ec <fwp_tape_buffers_release+0x9c>
    41a8:	39400001 	ldrb	w1, [x0]
    41ac:	7100c03f 	cmp	w1, #0x30
    41b0:	540001e1 	b.ne	41ec <fwp_tape_buffers_release+0x9c>  // b.any
    41b4:	39400400 	ldrb	w0, [x0, #1]
    41b8:	350001a0 	cbnz	w0, 41ec <fwp_tape_buffers_release+0x9c>
    41bc:	aa1303e0 	mov	x0, x19
    41c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41c8:	17fffc4e 	b	3300 <fwp_tape_buffers_dispose>
    41cc:	90000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    41d0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    41d4:	9138a000 	add	x0, x0, #0xe28
    41d8:	97fffa0e 	bl	2a10 <getenv@plt>
    41dc:	b4ffff00 	cbz	x0, 41bc <fwp_tape_buffers_release+0x6c>
    41e0:	39400001 	ldrb	w1, [x0]
    41e4:	7100c03f 	cmp	w1, #0x30
    41e8:	54fffe60 	b.eq	41b4 <fwp_tape_buffers_release+0x64>  // b.none
    41ec:	d1000681 	sub	x1, x20, #0x1
    41f0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41f4:	eb00003f 	cmp	x1, x0
    41f8:	54fffe28 	b.hi	41bc <fwp_tape_buffers_release+0x6c>  // b.pmore
    41fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4200:	900000f6 	adrp	x22, 20000 <__data_start>
    4204:	9100c2d6 	add	x22, x22, #0x30
    4208:	9101a2d5 	add	x21, x22, #0x68
    420c:	aa1503e0 	mov	x0, x21
    4210:	97fffc3c 	bl	3300 <fwp_tape_buffers_dispose>
    4214:	ad400a61 	ldp	q1, q2, [x19]
    4218:	f90052d4 	str	x20, [x22, #160]
    421c:	4f000400 	movi	v0.4s, #0x0
    4220:	ad000aa1 	stp	q1, q2, [x21]
    4224:	3dc00a61 	ldr	q1, [x19, #32]
    4228:	3d800aa1 	str	q1, [x21, #32]
    422c:	f9401a60 	ldr	x0, [x19, #48]
    4230:	f9001aa0 	str	x0, [x21, #48]
    4234:	f9001a7f 	str	xzr, [x19, #48]
    4238:	ad000260 	stp	q0, q0, [x19]
    423c:	3d800a60 	str	q0, [x19, #32]
    4240:	a94153f3 	ldp	x19, x20, [sp, #16]
    4244:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4248:	a8c37bfd 	ldp	x29, x30, [sp], #48
    424c:	d65f03c0 	ret
    4250:	90000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    4254:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4258:	9138a000 	add	x0, x0, #0xe28
    425c:	97fff9ed 	bl	2a10 <getenv@plt>
    4260:	b5fffa40 	cbnz	x0, 41a8 <fwp_tape_buffers_release+0x58>
    4264:	17ffffd6 	b	41bc <fwp_tape_buffers_release+0x6c>
    4268:	d503201f 	nop
    426c:	d503201f 	nop

0000000000004270 <fwp_poll_events>:
    4270:	d10103ff 	sub	sp, sp, #0x40
    4274:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4278:	f947f400 	ldr	x0, [x0, #4072]
    427c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4280:	910083fd 	add	x29, sp, #0x20
    4284:	a90353f3 	stp	x19, x20, [sp, #48]
    4288:	900000f4 	adrp	x20, 20000 <__data_start>
    428c:	f9400001 	ldr	x1, [x0]
    4290:	f9000fe1 	str	x1, [sp, #24]
    4294:	d2800001 	mov	x1, #0x0                   	// #0
    4298:	97fffd1a 	bl	3700 <fwp_now_ns>
    429c:	9100c281 	add	x1, x20, #0x30
    42a0:	f9405433 	ldr	x19, [x1, #168]
    42a4:	b4000e93 	cbz	x19, 4474 <fwp_poll_events+0x204>
    42a8:	aa1303e1 	mov	x1, x19
    42ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    42b0:	14000005 	b	42c4 <fwp_poll_events+0x54>
    42b4:	f9408821 	ldr	x1, [x1, #272]
    42b8:	eb03005f 	cmp	x2, x3
    42bc:	9a83d042 	csel	x2, x2, x3, le
    42c0:	b40000c1 	cbz	x1, 42d8 <fwp_poll_events+0x68>
    42c4:	f9403423 	ldr	x3, [x1, #104]
    42c8:	b6ffff62 	tbz	x2, #63, 42b4 <fwp_poll_events+0x44>
    42cc:	f9408821 	ldr	x1, [x1, #272]
    42d0:	aa0303e2 	mov	x2, x3
    42d4:	b5ffff81 	cbnz	x1, 42c4 <fwp_poll_events+0x54>
    42d8:	b7f80ce2 	tbnz	x2, #63, 4474 <fwp_poll_events+0x204>
    42dc:	cb000042 	sub	x2, x2, x0
    42e0:	f100005f 	cmp	x2, #0x0
    42e4:	540005cd 	b.le	439c <fwp_poll_events+0x12c>
    42e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    42ec:	d2884801 	mov	x1, #0x4240                	// #16960
    42f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    42f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    42f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    42fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4300:	f2e86360 	movk	x0, #0x431b, lsl #48
    4304:	9b407c40 	smulh	x0, x2, x0
    4308:	9352fc00 	asr	x0, x0, #18
    430c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4310:	9b018802 	msub	x2, x0, x1, x2
    4314:	f100005f 	cmp	x2, #0x0
    4318:	9a800400 	cinc	x0, x0, ne	// ne = any
    431c:	eb03001f 	cmp	x0, x3
    4320:	54000a0c 	b.gt	4460 <fwp_poll_events+0x1f0>
    4324:	340003c0 	cbz	w0, 439c <fwp_poll_events+0x12c>
    4328:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    432c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4330:	72a20c42 	movk	w2, #0x1062, lsl #16
    4334:	9ba27c02 	umull	x2, w0, w2
    4338:	d366fc43 	lsr	x3, x2, #38
    433c:	aa0303e2 	mov	x2, x3
    4340:	1b048063 	msub	w3, w3, w4, w0
    4344:	9b217c63 	smull	x3, w3, w1
    4348:	d2800001 	mov	x1, #0x0                   	// #0
    434c:	910023e0 	add	x0, sp, #0x8
    4350:	a9008fe2 	stp	x2, x3, [sp, #8]
    4354:	97fff97f 	bl	2950 <nanosleep@plt>
    4358:	9100c280 	add	x0, x20, #0x30
    435c:	f9405413 	ldr	x19, [x0, #168]
    4360:	97fffce8 	bl	3700 <fwp_now_ns>
    4364:	aa0003e6 	mov	x6, x0
    4368:	b50001f3 	cbnz	x19, 43a4 <fwp_poll_events+0x134>
    436c:	d503201f 	nop
    4370:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4374:	f947f400 	ldr	x0, [x0, #4072]
    4378:	f9400fe2 	ldr	x2, [sp, #24]
    437c:	f9400001 	ldr	x1, [x0]
    4380:	eb010042 	subs	x2, x2, x1
    4384:	d2800001 	mov	x1, #0x0                   	// #0
    4388:	540008c1 	b.ne	44a0 <fwp_poll_events+0x230>  // b.any
    438c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4390:	a94353f3 	ldp	x19, x20, [sp, #48]
    4394:	910103ff 	add	sp, sp, #0x40
    4398:	d65f03c0 	ret
    439c:	97fffcd9 	bl	3700 <fwp_now_ns>
    43a0:	aa0003e6 	mov	x6, x0
    43a4:	4f000400 	movi	v0.4s, #0x0
    43a8:	9100c288 	add	x8, x20, #0x30
    43ac:	52800027 	mov	w7, #0x1                   	// #1
    43b0:	f9403661 	ldr	x1, [x19, #104]
    43b4:	aa1303e5 	mov	x5, x19
    43b8:	f9408a73 	ldr	x19, [x19, #272]
    43bc:	eb06003f 	cmp	x1, x6
    43c0:	5400032c 	b.gt	4424 <fwp_poll_events+0x1b4>
    43c4:	394154a0 	ldrb	w0, [x5, #85]
    43c8:	36000120 	tbz	w0, #0, 43ec <fwp_poll_events+0x17c>
    43cc:	f94084a0 	ldr	x0, [x5, #264]
    43d0:	b40003c0 	cbz	x0, 4448 <fwp_poll_events+0x1d8>
    43d4:	f9008813 	str	x19, [x0, #272]
    43d8:	b4000053 	cbz	x19, 43e0 <fwp_poll_events+0x170>
    43dc:	f9008660 	str	x0, [x19, #264]
    43e0:	910800a0 	add	x0, x5, #0x200
    43e4:	390154bf 	strb	wzr, [x5, #85]
    43e8:	3c908000 	stur	q0, [x0, #-248]
    43ec:	f94030a0 	ldr	x0, [x5, #96]
    43f0:	390158a7 	strb	w7, [x5, #86]
    43f4:	f100001f 	cmp	x0, #0x0
    43f8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    43fc:	5400018d 	b.le	442c <fwp_poll_events+0x1bc>
    4400:	f94028a0 	ldr	x0, [x5, #80]
    4404:	f2001c1f 	tst	x0, #0xff000000ff
    4408:	540000e1 	b.ne	4424 <fwp_poll_events+0x1b4>  // b.any
    440c:	f9401500 	ldr	x0, [x8, #40]
    4410:	390150a7 	strb	w7, [x5, #84]
    4414:	f90080bf 	str	xzr, [x5, #256]
    4418:	b40001e0 	cbz	x0, 4454 <fwp_poll_events+0x1e4>
    441c:	f9001505 	str	x5, [x8, #40]
    4420:	f9008005 	str	x5, [x0, #256]
    4424:	b5fffc73 	cbnz	x19, 43b0 <fwp_poll_events+0x140>
    4428:	17ffffd2 	b	4370 <fwp_poll_events+0x100>
    442c:	394144a0 	ldrb	w0, [x5, #81]
    4430:	3707fe80 	tbnz	w0, #0, 4400 <fwp_poll_events+0x190>
    4434:	394140a0 	ldrb	w0, [x5, #80]
    4438:	3707fe40 	tbnz	w0, #0, 4400 <fwp_poll_events+0x190>
    443c:	aa0503e0 	mov	x0, x5
    4440:	97fffc0c 	bl	3470 <fwp_cancel_tree.part.0>
    4444:	17ffffef 	b	4400 <fwp_poll_events+0x190>
    4448:	9100c281 	add	x1, x20, #0x30
    444c:	f9005433 	str	x19, [x1, #168]
    4450:	17ffffe2 	b	43d8 <fwp_poll_events+0x168>
    4454:	f9001505 	str	x5, [x8, #40]
    4458:	f9001905 	str	x5, [x8, #48]
    445c:	17fffff2 	b	4424 <fwp_poll_events+0x1b4>
    4460:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4464:	d2989362 	mov	x2, #0xc49b                	// #50331
    4468:	f2a4d203 	movk	x3, #0x2690, lsl #16
    446c:	f2a00402 	movk	x2, #0x20, lsl #16
    4470:	17ffffb6 	b	4348 <fwp_poll_events+0xd8>
    4474:	97fffadf 	bl	2ff0 <fwp_flush>
    4478:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    447c:	f947e863 	ldr	x3, [x3, #4048]
    4480:	d2800562 	mov	x2, #0x2b                  	// #43
    4484:	d2800021 	mov	x1, #0x1                   	// #1
    4488:	90000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    448c:	91390000 	add	x0, x0, #0xe40
    4490:	f9400063 	ldr	x3, [x3]
    4494:	97fff93b 	bl	2980 <fwrite@plt>
    4498:	52800ca0 	mov	w0, #0x65                  	// #101
    449c:	97fff8a5 	bl	2730 <exit@plt>
    44a0:	97fff8f8 	bl	2880 <__stack_chk_fail@plt>

00000000000044a4 <fwp_rc_wide_dup>:
    44a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	aa0003f3 	mov	x19, x0
    44b4:	ca404400 	eor	x0, x0, x0, lsr #17
    44b8:	f90013f5 	str	x21, [sp, #32]
    44bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    44c0:	ca402400 	eor	x0, x0, x0, lsr #9
    44c4:	911582a2 	add	x2, x21, #0x560
    44c8:	92401c00 	and	x0, x0, #0xff
    44cc:	910a2403 	add	x3, x0, #0x289
    44d0:	8b000c40 	add	x0, x2, x0, lsl #3
    44d4:	8b030c54 	add	x20, x2, x3, lsl #3
    44d8:	f94a2401 	ldr	x1, [x0, #5192]
    44dc:	b50000a1 	cbnz	x1, 44f0 <fwp_rc_wide_dup+0x4c>
    44e0:	1400002d 	b	4594 <fwp_rc_wide_dup+0xf0>
    44e4:	91004034 	add	x20, x1, #0x10
    44e8:	f9400821 	ldr	x1, [x1, #16]
    44ec:	b4000241 	cbz	x1, 4534 <fwp_rc_wide_dup+0x90>
    44f0:	f9400022 	ldr	x2, [x1]
    44f4:	eb02027f 	cmp	x19, x2
    44f8:	54ffff61 	b.ne	44e4 <fwp_rc_wide_dup+0x40>  // b.any
    44fc:	f9400281 	ldr	x1, [x20]
    4500:	39400260 	ldrb	w0, [x19]
    4504:	7103f81f 	cmp	w0, #0xfe
    4508:	54000220 	b.eq	454c <fwp_rc_wide_dup+0xa8>  // b.none
    450c:	b40001a1 	cbz	x1, 4540 <fwp_rc_wide_dup+0x9c>
    4510:	f9400420 	ldr	x0, [x1, #8]
    4514:	b100041f 	cmn	x0, #0x1
    4518:	540004a0 	b.eq	45ac <fwp_rc_wide_dup+0x108>  // b.none
    451c:	91000400 	add	x0, x0, #0x1
    4520:	f9000420 	str	x0, [x1, #8]
    4524:	a94153f3 	ldp	x19, x20, [sp, #16]
    4528:	f94013f5 	ldr	x21, [sp, #32]
    452c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4530:	d65f03c0 	ret
    4534:	39400260 	ldrb	w0, [x19]
    4538:	7103f81f 	cmp	w0, #0xfe
    453c:	540000a0 	b.eq	4550 <fwp_rc_wide_dup+0xac>  // b.none
    4540:	90000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    4544:	913a6000 	add	x0, x0, #0xe98
    4548:	97fffc0e 	bl	3580 <fwp_trap>
    454c:	b5000281 	cbnz	x1, 459c <fwp_rc_wide_dup+0xf8>
    4550:	d2800300 	mov	x0, #0x18                  	// #24
    4554:	97fff8b3 	bl	2820 <malloc@plt>
    4558:	b4000280 	cbz	x0, 45a8 <fwp_rc_wide_dup+0x104>
    455c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4560:	a9000413 	stp	x19, x1, [x0]
    4564:	911582b5 	add	x21, x21, #0x560
    4568:	f900081f 	str	xzr, [x0, #16]
    456c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4570:	f9000280 	str	x0, [x20]
    4574:	39000261 	strb	w1, [x19]
    4578:	f94e26a0 	ldr	x0, [x21, #7240]
    457c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4580:	91000400 	add	x0, x0, #0x1
    4584:	f90e26a0 	str	x0, [x21, #7240]
    4588:	f94013f5 	ldr	x21, [sp, #32]
    458c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4590:	d65f03c0 	ret
    4594:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4598:	17ffffda 	b	4500 <fwp_rc_wide_dup+0x5c>
    459c:	90000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    45a0:	9139c000 	add	x0, x0, #0xe70
    45a4:	97fffbf7 	bl	3580 <fwp_trap>
    45a8:	97fffaa2 	bl	3030 <fwp_heap_oom>
    45ac:	90000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    45b0:	913b0000 	add	x0, x0, #0xec0
    45b4:	97fffbf3 	bl	3580 <fwp_trap>
    45b8:	d503201f 	nop
    45bc:	d503201f 	nop

00000000000045c0 <fwp_rc_forget_slot>:
    45c0:	aa0003e1 	mov	x1, x0
    45c4:	39400000 	ldrb	w0, [x0]
    45c8:	7103fc1f 	cmp	w0, #0xff
    45cc:	54000040 	b.eq	45d4 <fwp_rc_forget_slot+0x14>  // b.none
    45d0:	d65f03c0 	ret
    45d4:	ca414420 	eor	x0, x1, x1, lsr #17
    45d8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    45dc:	ca402400 	eor	x0, x0, x0, lsr #9
    45e0:	910003fd 	mov	x29, sp
    45e4:	92401c00 	and	x0, x0, #0xff
    45e8:	f9000bf3 	str	x19, [sp, #16]
    45ec:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc80>
    45f0:	91158262 	add	x2, x19, #0x560
    45f4:	910a2403 	add	x3, x0, #0x289
    45f8:	8b000c40 	add	x0, x2, x0, lsl #3
    45fc:	8b030c43 	add	x3, x2, x3, lsl #3
    4600:	f94a2400 	ldr	x0, [x0, #5192]
    4604:	b50000a0 	cbnz	x0, 4618 <fwp_rc_forget_slot+0x58>
    4608:	14000011 	b	464c <fwp_rc_forget_slot+0x8c>
    460c:	91004003 	add	x3, x0, #0x10
    4610:	f9400800 	ldr	x0, [x0, #16]
    4614:	b40001c0 	cbz	x0, 464c <fwp_rc_forget_slot+0x8c>
    4618:	f9400002 	ldr	x2, [x0]
    461c:	eb02003f 	cmp	x1, x2
    4620:	54ffff61 	b.ne	460c <fwp_rc_forget_slot+0x4c>  // b.any
    4624:	f9400801 	ldr	x1, [x0, #16]
    4628:	91158273 	add	x19, x19, #0x560
    462c:	f9000061 	str	x1, [x3]
    4630:	97fff8c4 	bl	2940 <free@plt>
    4634:	f94e2660 	ldr	x0, [x19, #7240]
    4638:	d1000400 	sub	x0, x0, #0x1
    463c:	f90e2660 	str	x0, [x19, #7240]
    4640:	f9400bf3 	ldr	x19, [sp, #16]
    4644:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4648:	d65f03c0 	ret
    464c:	90000040 	adrp	x0, c000 <fwp_main_thread+0x70>
    4650:	913a6000 	add	x0, x0, #0xe98
    4654:	97fffbcb 	bl	3580 <fwp_trap>
    4658:	d503201f 	nop
    465c:	d503201f 	nop

0000000000004660 <fwp_rc_prepare_chunk>:
    4660:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4664:	910003fd 	mov	x29, sp
    4668:	a9025bf5 	stp	x21, x22, [sp, #32]
    466c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc80>
    4670:	911582c2 	add	x2, x22, #0x560
    4674:	b9401c03 	ldr	w3, [x0, #28]
    4678:	aa0103f5 	mov	x21, x1
    467c:	a90153f3 	stp	x19, x20, [sp, #16]
    4680:	aa0003f4 	mov	x20, x0
    4684:	f94e2440 	ldr	x0, [x2, #7240]
    4688:	b4000440 	cbz	x0, 4710 <fwp_rc_prepare_chunk+0xb0>
    468c:	d2800013 	mov	x19, #0x0                   	// #0
    4690:	35000203 	cbnz	w3, 46d0 <fwp_rc_prepare_chunk+0x70>
    4694:	b4000361 	cbz	x1, 4700 <fwp_rc_prepare_chunk+0xa0>
    4698:	f9401280 	ldr	x0, [x20, #32]
    469c:	97fff8a9 	bl	2940 <free@plt>
    46a0:	aa1503e0 	mov	x0, x21
    46a4:	d2800021 	mov	x1, #0x1                   	// #1
    46a8:	97fff86e 	bl	2860 <calloc@plt>
    46ac:	f9001280 	str	x0, [x20, #32]
    46b0:	b5000460 	cbnz	x0, 473c <fwp_rc_prepare_chunk+0xdc>
    46b4:	97fffa5f 	bl	3030 <fwp_heap_oom>
    46b8:	97ffffc2 	bl	45c0 <fwp_rc_forget_slot>
    46bc:	91000673 	add	x19, x19, #0x1
    46c0:	b9401e83 	ldr	w3, [x20, #28]
    46c4:	eb13007f 	cmp	x3, x19
    46c8:	54000169 	b.ls	46f4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    46cc:	d503201f 	nop
    46d0:	f9401283 	ldr	x3, [x20, #32]
    46d4:	8b130060 	add	x0, x3, x19
    46d8:	38736863 	ldrb	w3, [x3, x19]
    46dc:	7103fc7f 	cmp	w3, #0xff
    46e0:	54fffec0 	b.eq	46b8 <fwp_rc_prepare_chunk+0x58>  // b.none
    46e4:	b9401e83 	ldr	w3, [x20, #28]
    46e8:	91000673 	add	x19, x19, #0x1
    46ec:	eb13007f 	cmp	x3, x19
    46f0:	54ffff08 	b.hi	46d0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    46f4:	eb0302bf 	cmp	x21, x3
    46f8:	54000121 	b.ne	471c <fwp_rc_prepare_chunk+0xbc>  // b.any
    46fc:	b5000335 	cbnz	x21, 4760 <fwp_rc_prepare_chunk+0x100>
    4700:	a94153f3 	ldp	x19, x20, [sp, #16]
    4704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4708:	a8c37bfd 	ldp	x29, x30, [sp], #48
    470c:	d65f03c0 	ret
    4710:	2a0303e3 	mov	w3, w3
    4714:	eb0302bf 	cmp	x21, x3
    4718:	54ffff20 	b.eq	46fc <fwp_rc_prepare_chunk+0x9c>  // b.none
    471c:	911582c2 	add	x2, x22, #0x560
    4720:	f9401280 	ldr	x0, [x20, #32]
    4724:	f94e2841 	ldr	x1, [x2, #7248]
    4728:	cb030021 	sub	x1, x1, x3
    472c:	f90e2841 	str	x1, [x2, #7248]
    4730:	97fff884 	bl	2940 <free@plt>
    4734:	b5fffb75 	cbnz	x21, 46a0 <fwp_rc_prepare_chunk+0x40>
    4738:	f900129f 	str	xzr, [x20, #32]
    473c:	911582d6 	add	x22, x22, #0x560
    4740:	f94e2ac0 	ldr	x0, [x22, #7248]
    4744:	b9001e95 	str	w21, [x20, #28]
    4748:	a94153f3 	ldp	x19, x20, [sp, #16]
    474c:	8b150000 	add	x0, x0, x21
    4750:	f90e2ac0 	str	x0, [x22, #7248]
    4754:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4758:	a8c37bfd 	ldp	x29, x30, [sp], #48
    475c:	d65f03c0 	ret
    4760:	f9401280 	ldr	x0, [x20, #32]
    4764:	aa1503e2 	mov	x2, x21
    4768:	a94153f3 	ldp	x19, x20, [sp, #16]
    476c:	52800001 	mov	w1, #0x0                   	// #0
    4770:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4774:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4778:	17fff836 	b	2850 <memset@plt>
    477c:	d503201f 	nop

0000000000004780 <fwp_heap_refill>:
    4780:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4784:	910003fd 	mov	x29, sp
    4788:	a9025bf5 	stp	x21, x22, [sp, #32]
    478c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    4790:	911582b5 	add	x21, x21, #0x560
    4794:	aa0003f6 	mov	x22, x0
    4798:	d2800020 	mov	x0, #0x1                   	// #1
    479c:	a90153f3 	stp	x19, x20, [sp, #16]
    47a0:	a90363f7 	stp	x23, x24, [sp, #48]
    47a4:	2a0103f7 	mov	w23, w1
    47a8:	2a0203f8 	mov	w24, w2
    47ac:	97fffa61 	bl	3130 <fwp_heap_chunks>
    47b0:	aa0003f3 	mov	x19, x0
    47b4:	f949fea2 	ldr	x2, [x21, #5112]
    47b8:	8b000800 	add	x0, x0, x0, lsl #2
    47bc:	2a1703e1 	mov	w1, w23
    47c0:	52800025 	mov	w5, #0x1                   	// #1
    47c4:	d37df000 	lsl	x0, x0, #3
    47c8:	910f0021 	add	x1, x1, #0x3c0
    47cc:	8b000054 	add	x20, x2, x0
    47d0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    47d4:	52a00024 	mov	w4, #0x10000               	// #65536
    47d8:	38206845 	strb	w5, [x2, x0]
    47dc:	aa1403e0 	mov	x0, x20
    47e0:	39000698 	strb	w24, [x20, #1]
    47e4:	39000a97 	strb	w23, [x20, #2]
    47e8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    47ec:	b9000681 	str	w1, [x20, #4]
    47f0:	2a0103e5 	mov	w5, w1
    47f4:	8b0300a2 	add	x2, x5, x3
    47f8:	1ac10881 	udiv	w1, w4, w1
    47fc:	9ac50842 	udiv	x2, x2, x5
    4800:	b9000a81 	str	w1, [x20, #8]
    4804:	92404021 	and	x1, x1, #0x1ffff
    4808:	b9001a82 	str	w2, [x20, #24]
    480c:	97ffff95 	bl	4660 <fwp_rc_prepare_chunk>
    4810:	f949daa0 	ldr	x0, [x21, #5040]
    4814:	29408a81 	ldp	w1, w2, [x20, #4]
    4818:	8b134000 	add	x0, x0, x19, lsl #16
    481c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4820:	8b214003 	add	x3, x0, w1, uxtw
    4824:	9ba20021 	umaddl	x1, w1, w2, x0
    4828:	a94363f7 	ldp	x23, x24, [sp, #48]
    482c:	a90086c3 	stp	x3, x1, [x22, #8]
    4830:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4834:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4838:	d65f03c0 	ret
    483c:	d503201f 	nop

0000000000004840 <fwp_mem_free>:
    4840:	b40003c0 	cbz	x0, 48b8 <fwp_mem_free+0x78>
    4844:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4848:	910003fd 	mov	x29, sp
    484c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4850:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    4854:	911582a1 	add	x1, x21, #0x560
    4858:	a90153f3 	stp	x19, x20, [sp, #16]
    485c:	aa0003f3 	mov	x19, x0
    4860:	f949d823 	ldr	x3, [x1, #5040]
    4864:	f949ec22 	ldr	x2, [x1, #5080]
    4868:	cb030000 	sub	x0, x0, x3
    486c:	eb02401f 	cmp	x0, x2, lsl #16
    4870:	540001c2 	b.cs	48a8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4874:	d350fc16 	lsr	x22, x0, #16
    4878:	a90363f7 	stp	x23, x24, [sp, #48]
    487c:	f949fc22 	ldr	x2, [x1, #5112]
    4880:	8b160ad4 	add	x20, x22, x22, lsl #2
    4884:	d37df294 	lsl	x20, x20, #3
    4888:	ab140057 	adds	x23, x2, x20
    488c:	540000c0 	b.eq	48a4 <fwp_mem_free+0x64>  // b.none
    4890:	38746842 	ldrb	w2, [x2, x20]
    4894:	7100045f 	cmp	w2, #0x1
    4898:	54000120 	b.eq	48bc <fwp_mem_free+0x7c>  // b.none
    489c:	7100085f 	cmp	w2, #0x2
    48a0:	540005e0 	b.eq	495c <fwp_mem_free+0x11c>  // b.none
    48a4:	a94363f7 	ldp	x23, x24, [sp, #48]
    48a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    48b0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    48b4:	d65f03c0 	ret
    48b8:	d65f03c0 	ret
    48bc:	f94012f8 	ldr	x24, [x23, #32]
    48c0:	b94006e1 	ldr	w1, [x23, #4]
    48c4:	f90023f9 	str	x25, [sp, #64]
    48c8:	2a0103e2 	mov	w2, w1
    48cc:	394006f9 	ldrb	w25, [x23, #1]
    48d0:	39400af4 	ldrb	w20, [x23, #2]
    48d4:	b4000158 	cbz	x24, 48fc <fwp_mem_free+0xbc>
    48d8:	92403e76 	and	x22, x19, #0xffff
    48dc:	9ac20ad6 	udiv	x22, x22, x2
    48e0:	38766b01 	ldrb	w1, [x24, x22]
    48e4:	8b160300 	add	x0, x24, x22
    48e8:	7103fc3f 	cmp	w1, #0xff
    48ec:	54000980 	b.eq	4a1c <fwp_mem_free+0x1dc>  // b.none
    48f0:	38366b1f 	strb	wzr, [x24, x22]
    48f4:	b94006e1 	ldr	w1, [x23, #4]
    48f8:	2a0103e2 	mov	w2, w1
    48fc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4900:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4904:	cb390000 	sub	x0, x0, w25, uxtb
    4908:	8b340074 	add	x20, x3, w20, uxtb
    490c:	911582b5 	add	x21, x21, #0x560
    4910:	1e630021 	ucvtf	d1, w1
    4914:	d37ae400 	lsl	x0, x0, #6
    4918:	8b140c14 	add	x20, x0, x20, lsl #3
    491c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4920:	f8746aa0 	ldr	x0, [x21, x20]
    4924:	f94023f9 	ldr	x25, [sp, #64]
    4928:	aa2003e0 	mvn	x0, x0
    492c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4930:	f9000260 	str	x0, [x19]
    4934:	f8346ab3 	str	x19, [x21, x20]
    4938:	f94a12a0 	ldr	x0, [x21, #5152]
    493c:	1e612800 	fadd	d0, d0, d1
    4940:	a94153f3 	ldp	x19, x20, [sp, #16]
    4944:	cb020000 	sub	x0, x0, x2
    4948:	f90a12a0 	str	x0, [x21, #5152]
    494c:	fd0a22a0 	str	d0, [x21, #5184]
    4950:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4954:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4958:	d65f03c0 	ret
    495c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4960:	8b000063 	add	x3, x3, x0
    4964:	eb03027f 	cmp	x19, x3
    4968:	54fff9e1 	b.ne	48a4 <fwp_mem_free+0x64>  // b.any
    496c:	fd400ae1 	ldr	d1, [x23, #16]
    4970:	fd4a2020 	ldr	d0, [x1, #5184]
    4974:	f9400ae0 	ldr	x0, [x23, #16]
    4978:	7e61d821 	ucvtf	d1, d1
    497c:	f94a1022 	ldr	x2, [x1, #5152]
    4980:	f94012f3 	ldr	x19, [x23, #32]
    4984:	1e612800 	fadd	d0, d0, d1
    4988:	cb000042 	sub	x2, x2, x0
    498c:	f90a1022 	str	x2, [x1, #5152]
    4990:	fd0a2020 	str	d0, [x1, #5184]
    4994:	b40000b3 	cbz	x19, 49a8 <fwp_mem_free+0x168>
    4998:	39400260 	ldrb	w0, [x19]
    499c:	7103fc1f 	cmp	w0, #0xff
    49a0:	54000380 	b.eq	4a10 <fwp_mem_free+0x1d0>  // b.none
    49a4:	3900027f 	strb	wzr, [x19]
    49a8:	b9400ee2 	ldr	w2, [x23, #12]
    49ac:	b4000142 	cbz	x2, 49d4 <fwp_mem_free+0x194>
    49b0:	911582a1 	add	x1, x21, #0x560
    49b4:	8b160040 	add	x0, x2, x22
    49b8:	8b000800 	add	x0, x0, x0, lsl #2
    49bc:	f949fc21 	ldr	x1, [x1, #5112]
    49c0:	8b140034 	add	x20, x1, x20
    49c4:	8b000c20 	add	x0, x1, x0, lsl #3
    49c8:	3802869f 	strb	wzr, [x20], #40
    49cc:	eb00029f 	cmp	x20, x0
    49d0:	54ffffc1 	b.ne	49c8 <fwp_mem_free+0x188>  // b.any
    49d4:	911582a0 	add	x0, x21, #0x560
    49d8:	f94a1801 	ldr	x1, [x0, #5168]
    49dc:	f949f803 	ldr	x3, [x0, #5104]
    49e0:	8b020021 	add	x1, x1, x2
    49e4:	f90a1801 	str	x1, [x0, #5168]
    49e8:	eb16007f 	cmp	x3, x22
    49ec:	54000049 	b.ls	49f4 <fwp_mem_free+0x1b4>  // b.plast
    49f0:	f909f816 	str	x22, [x0, #5104]
    49f4:	911582b5 	add	x21, x21, #0x560
    49f8:	f949f6a0 	ldr	x0, [x21, #5096]
    49fc:	eb16001f 	cmp	x0, x22
    4a00:	54fff529 	b.ls	48a4 <fwp_mem_free+0x64>  // b.plast
    4a04:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a08:	f909f6b6 	str	x22, [x21, #5096]
    4a0c:	17ffffa7 	b	48a8 <fwp_mem_free+0x68>
    4a10:	aa1303e0 	mov	x0, x19
    4a14:	97fffeeb 	bl	45c0 <fwp_rc_forget_slot>
    4a18:	17ffffe3 	b	49a4 <fwp_mem_free+0x164>
    4a1c:	97fffee9 	bl	45c0 <fwp_rc_forget_slot>
    4a20:	17ffffb4 	b	48f0 <fwp_mem_free+0xb0>

0000000000004a24 <fwp_heap_alloc_big>:
    4a24:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4a28:	910003fd 	mov	x29, sp
    4a2c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a30:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a34:	a90363f7 	stp	x23, x24, [sp, #48]
    4a38:	aa0003f7 	mov	x23, x0
    4a3c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4a40:	a9046bf9 	stp	x25, x26, [sp, #64]
    4a44:	eb0002ff 	cmp	x23, x0
    4a48:	54000888 	b.hi	4b58 <fwp_heap_alloc_big+0x134>  // b.pmore
    4a4c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4a50:	8b0002f4 	add	x20, x23, x0
    4a54:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc80>
    4a58:	91158359 	add	x25, x26, #0x560
    4a5c:	d350fe94 	lsr	x20, x20, #16
    4a60:	2a0103f5 	mov	w21, w1
    4a64:	aa1403e0 	mov	x0, x20
    4a68:	97fff9b2 	bl	3130 <fwp_heap_chunks>
    4a6c:	f949ff22 	ldr	x2, [x25, #5112]
    4a70:	8b000813 	add	x19, x0, x0, lsl #2
    4a74:	aa0003f8 	mov	x24, x0
    4a78:	52800043 	mov	w3, #0x2                   	// #2
    4a7c:	d37df273 	lsl	x19, x19, #3
    4a80:	d2800021 	mov	x1, #0x1                   	// #1
    4a84:	8b130040 	add	x0, x2, x19
    4a88:	38336843 	strb	w3, [x2, x19]
    4a8c:	39000415 	strb	w21, [x0, #1]
    4a90:	b9000c14 	str	w20, [x0, #12]
    4a94:	f9000817 	str	x23, [x0, #16]
    4a98:	97fffef2 	bl	4660 <fwp_rc_prepare_chunk>
    4a9c:	f100069f 	cmp	x20, #0x1
    4aa0:	54000269 	b.ls	4aec <fwp_heap_alloc_big+0xc8>  // b.plast
    4aa4:	8b180294 	add	x20, x20, x24
    4aa8:	9100a273 	add	x19, x19, #0x28
    4aac:	a90573fb 	stp	x27, x28, [sp, #80]
    4ab0:	5280007b 	mov	w27, #0x3                   	// #3
    4ab4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ab8:	2a1803fc 	mov	w28, w24
    4abc:	9adb2296 	lsl	x22, x20, x27
    4ac0:	f949ff35 	ldr	x21, [x25, #5112]
    4ac4:	d2800001 	mov	x1, #0x0                   	// #0
    4ac8:	8b1302b4 	add	x20, x21, x19
    4acc:	aa1403e0 	mov	x0, x20
    4ad0:	97fffee4 	bl	4660 <fwp_rc_prepare_chunk>
    4ad4:	38336abb 	strb	w27, [x21, x19]
    4ad8:	9100a273 	add	x19, x19, #0x28
    4adc:	b9000e9c 	str	w28, [x20, #12]
    4ae0:	eb1302df 	cmp	x22, x19
    4ae4:	54fffee1 	b.ne	4ac0 <fwp_heap_alloc_big+0x9c>  // b.any
    4ae8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4aec:	91158353 	add	x19, x26, #0x560
    4af0:	aa1703e2 	mov	x2, x23
    4af4:	52800001 	mov	w1, #0x0                   	// #0
    4af8:	f949da60 	ldr	x0, [x19, #5040]
    4afc:	8b184018 	add	x24, x0, x24, lsl #16
    4b00:	aa1803e0 	mov	x0, x24
    4b04:	97fff753 	bl	2850 <memset@plt>
    4b08:	f94a1260 	ldr	x0, [x19, #5152]
    4b0c:	ab170000 	adds	x0, x0, x23
    4b10:	54000242 	b.cs	4b58 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4b14:	f94a1661 	ldr	x1, [x19, #5160]
    4b18:	f90a1260 	str	x0, [x19, #5152]
    4b1c:	eb01001f 	cmp	x0, x1
    4b20:	54000049 	b.ls	4b28 <fwp_heap_alloc_big+0x104>  // b.plast
    4b24:	f90a1660 	str	x0, [x19, #5160]
    4b28:	9115835a 	add	x26, x26, #0x560
    4b2c:	9e6202e0 	scvtf	d0, x23
    4b30:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b34:	aa1803e0 	mov	x0, x24
    4b38:	fd4a1f41 	ldr	d1, [x26, #5176]
    4b3c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b40:	1e602820 	fadd	d0, d1, d0
    4b44:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b48:	fd0a1f40 	str	d0, [x26, #5176]
    4b4c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b50:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b54:	d65f03c0 	ret
    4b58:	a90573fb 	stp	x27, x28, [sp, #80]
    4b5c:	97fff935 	bl	3030 <fwp_heap_oom>

0000000000004b60 <fwp_heap_alloc_slow>:
    4b60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b64:	910003fd 	mov	x29, sp
    4b68:	a90153f3 	stp	x19, x20, [sp, #16]
    4b6c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc80>
    4b70:	91158262 	add	x2, x19, #0x560
    4b74:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b78:	aa0003f5 	mov	x21, x0
    4b7c:	2a0103f4 	mov	w20, w1
    4b80:	b953a440 	ldr	w0, [x2, #5028]
    4b84:	34000600 	cbz	w0, 4c44 <fwp_heap_alloc_slow+0xe4>
    4b88:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b8c:	54000628 	b.hi	4c50 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b90:	91003ea0 	add	x0, x21, #0xf
    4b94:	91158262 	add	x2, x19, #0x560
    4b98:	f9001bf7 	str	x23, [sp, #48]
    4b9c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ba0:	8b401040 	add	x0, x2, x0, lsr #4
    4ba4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ba8:	d37ae484 	lsl	x4, x4, #6
    4bac:	397e8003 	ldrb	w3, [x0, #4000]
    4bb0:	910f0060 	add	x0, x3, #0x3c0
    4bb4:	aa0303e1 	mov	x1, x3
    4bb8:	8b030463 	add	x3, x3, x3, lsl #1
    4bbc:	8b030c83 	add	x3, x4, x3, lsl #3
    4bc0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4bc4:	2a1703f6 	mov	w22, w23
    4bc8:	f8636844 	ldr	x4, [x2, x3]
    4bcc:	b40004e4 	cbz	x4, 4c68 <fwp_heap_alloc_slow+0x108>
    4bd0:	f9400080 	ldr	x0, [x4]
    4bd4:	aa2003e0 	mvn	x0, x0
    4bd8:	f8236840 	str	x0, [x2, x3]
    4bdc:	7100069f 	cmp	w20, #0x1
    4be0:	aa0403e0 	mov	x0, x4
    4be4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4be8:	52800001 	mov	w1, #0x0                   	// #0
    4bec:	97fff719 	bl	2850 <memset@plt>
    4bf0:	aa0003e4 	mov	x4, x0
    4bf4:	91158260 	add	x0, x19, #0x560
    4bf8:	f94a1001 	ldr	x1, [x0, #5152]
    4bfc:	ab160021 	adds	x1, x1, x22
    4c00:	540005c2 	b.cs	4cb8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4c04:	f94a1402 	ldr	x2, [x0, #5160]
    4c08:	f90a1001 	str	x1, [x0, #5152]
    4c0c:	eb02003f 	cmp	x1, x2
    4c10:	54000049 	b.ls	4c18 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4c14:	f90a1401 	str	x1, [x0, #5160]
    4c18:	91158273 	add	x19, x19, #0x560
    4c1c:	1e6302e1 	ucvtf	d1, w23
    4c20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c24:	aa0403e0 	mov	x0, x4
    4c28:	fd4a1e60 	ldr	d0, [x19, #5176]
    4c2c:	f9401bf7 	ldr	x23, [sp, #48]
    4c30:	1e612800 	fadd	d0, d0, d1
    4c34:	fd0a1e60 	str	d0, [x19, #5176]
    4c38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c3c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c40:	d65f03c0 	ret
    4c44:	97fffc90 	bl	3e84 <fwp_heap_init>
    4c48:	f14012bf 	cmp	x21, #0x4, lsl #12
    4c4c:	54fffa29 	b.ls	4b90 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c50:	2a1403e1 	mov	w1, w20
    4c54:	aa1503e0 	mov	x0, x21
    4c58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c60:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c64:	17ffff70 	b	4a24 <fwp_heap_alloc_big>
    4c68:	8b030042 	add	x2, x2, x3
    4c6c:	f9400444 	ldr	x4, [x2, #8]
    4c70:	b4000104 	cbz	x4, 4c90 <fwp_heap_alloc_slow+0x130>
    4c74:	f9400840 	ldr	x0, [x2, #16]
    4c78:	cb040000 	sub	x0, x0, x4
    4c7c:	eb16001f 	cmp	x0, x22
    4c80:	54000083 	b.cc	4c90 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c84:	8b160080 	add	x0, x4, x22
    4c88:	f9000440 	str	x0, [x2, #8]
    4c8c:	17ffffd4 	b	4bdc <fwp_heap_alloc_slow+0x7c>
    4c90:	52800302 	mov	w2, #0x18                  	// #24
    4c94:	52807804 	mov	w4, #0x3c0                 	// #960
    4c98:	91158260 	add	x0, x19, #0x560
    4c9c:	9ba27c23 	umull	x3, w1, w2
    4ca0:	2a1403e2 	mov	w2, w20
    4ca4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ca8:	8b040000 	add	x0, x0, x4
    4cac:	97fffeb5 	bl	4780 <fwp_heap_refill>
    4cb0:	aa0003e4 	mov	x4, x0
    4cb4:	17ffffca 	b	4bdc <fwp_heap_alloc_slow+0x7c>
    4cb8:	97fff8de 	bl	3030 <fwp_heap_oom>
    4cbc:	d503201f 	nop

0000000000004cc0 <fwp_heap_alloc>:
    4cc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4cc4:	f140101f 	cmp	x0, #0x4, lsl #12
    4cc8:	910003fd 	mov	x29, sp
    4ccc:	a90153f3 	stp	x19, x20, [sp, #16]
    4cd0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc80>
    4cd4:	91158293 	add	x19, x20, #0x560
    4cd8:	b953a662 	ldr	w2, [x19, #5028]
    4cdc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4ce0:	54000640 	b.eq	4da8 <fwp_heap_alloc+0xe8>  // b.none
    4ce4:	91003c03 	add	x3, x0, #0xf
    4ce8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4cec:	937c7c22 	sbfiz	x2, x1, #4, #32
    4cf0:	8b431263 	add	x3, x19, x3, lsr #4
    4cf4:	cb21c042 	sub	x2, x2, w1, sxtw
    4cf8:	d37ae442 	lsl	x2, x2, #6
    4cfc:	397e8063 	ldrb	w3, [x3, #4000]
    4d00:	910f0064 	add	x4, x3, #0x3c0
    4d04:	8b030463 	add	x3, x3, x3, lsl #1
    4d08:	8b030c43 	add	x3, x2, x3, lsl #3
    4d0c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4d10:	2a1603f5 	mov	w21, w22
    4d14:	f8636a64 	ldr	x4, [x19, x3]
    4d18:	b4000384 	cbz	x4, 4d88 <fwp_heap_alloc+0xc8>
    4d1c:	f9400085 	ldr	x5, [x4]
    4d20:	7100043f 	cmp	w1, #0x1
    4d24:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d28:	aa0403e0 	mov	x0, x4
    4d2c:	aa2503e5 	mvn	x5, x5
    4d30:	52800001 	mov	w1, #0x0                   	// #0
    4d34:	f8236a65 	str	x5, [x19, x3]
    4d38:	97fff6c6 	bl	2850 <memset@plt>
    4d3c:	aa0003e4 	mov	x4, x0
    4d40:	f94a1260 	ldr	x0, [x19, #5152]
    4d44:	ab150000 	adds	x0, x0, x21
    4d48:	54000442 	b.cs	4dd0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4d4c:	f94a1661 	ldr	x1, [x19, #5160]
    4d50:	f90a1260 	str	x0, [x19, #5152]
    4d54:	eb01001f 	cmp	x0, x1
    4d58:	54000049 	b.ls	4d60 <fwp_heap_alloc+0xa0>  // b.plast
    4d5c:	f90a1660 	str	x0, [x19, #5160]
    4d60:	91158294 	add	x20, x20, #0x560
    4d64:	1e6302c1 	ucvtf	d1, w22
    4d68:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d6c:	aa0403e0 	mov	x0, x4
    4d70:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d74:	1e612800 	fadd	d0, d0, d1
    4d78:	fd0a1e80 	str	d0, [x20, #5176]
    4d7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d84:	d65f03c0 	ret
    4d88:	8b030263 	add	x3, x19, x3
    4d8c:	f9400464 	ldr	x4, [x3, #8]
    4d90:	b40000a4 	cbz	x4, 4da4 <fwp_heap_alloc+0xe4>
    4d94:	f9400862 	ldr	x2, [x3, #16]
    4d98:	cb040042 	sub	x2, x2, x4
    4d9c:	eb15005f 	cmp	x2, x21
    4da0:	540000a2 	b.cs	4db4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4da4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4da8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4dac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4db0:	17ffff6c 	b	4b60 <fwp_heap_alloc_slow>
    4db4:	7100043f 	cmp	w1, #0x1
    4db8:	8b150085 	add	x5, x4, x21
    4dbc:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4dc0:	52800001 	mov	w1, #0x0                   	// #0
    4dc4:	aa0403e0 	mov	x0, x4
    4dc8:	f9000465 	str	x5, [x3, #8]
    4dcc:	17ffffdb 	b	4d38 <fwp_heap_alloc+0x78>
    4dd0:	97fff898 	bl	3030 <fwp_heap_oom>

0000000000004dd4 <fwp_data.part.0.constprop.0>:
    4dd4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4dd8:	910003fd 	mov	x29, sp
    4ddc:	a90153f3 	stp	x19, x20, [sp, #16]
    4de0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc80>
    4de4:	91158283 	add	x3, x20, #0x560
    4de8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4dec:	aa0103f5 	mov	x21, x1
    4df0:	b953a461 	ldr	w1, [x3, #5028]
    4df4:	a90363f7 	stp	x23, x24, [sp, #48]
    4df8:	2a0003f8 	mov	w24, w0
    4dfc:	34000701 	cbz	w1, 4edc <fwp_data.part.0.constprop.0+0x108>
    4e00:	397e8862 	ldrb	w2, [x3, #4002]
    4e04:	910f0040 	add	x0, x2, #0x3c0
    4e08:	8b020442 	add	x2, x2, x2, lsl #1
    4e0c:	d37df042 	lsl	x2, x2, #3
    4e10:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4e14:	2a1703f6 	mov	w22, w23
    4e18:	f8626873 	ldr	x19, [x3, x2]
    4e1c:	b40004d3 	cbz	x19, 4eb4 <fwp_data.part.0.constprop.0+0xe0>
    4e20:	f9400260 	ldr	x0, [x19]
    4e24:	aa2003e0 	mvn	x0, x0
    4e28:	f8226860 	str	x0, [x3, x2]
    4e2c:	f10062df 	cmp	x22, #0x18
    4e30:	540000e9 	b.ls	4e4c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4e34:	d10066c2 	sub	x2, x22, #0x19
    4e38:	91006260 	add	x0, x19, #0x18
    4e3c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4e40:	52800001 	mov	w1, #0x0                   	// #0
    4e44:	91002042 	add	x2, x2, #0x8
    4e48:	97fff682 	bl	2850 <memset@plt>
    4e4c:	91158282 	add	x2, x20, #0x560
    4e50:	f94a1041 	ldr	x1, [x2, #5152]
    4e54:	ab160021 	adds	x1, x1, x22
    4e58:	540004c2 	b.cs	4ef0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e5c:	f94a1440 	ldr	x0, [x2, #5160]
    4e60:	f90a1041 	str	x1, [x2, #5152]
    4e64:	eb00003f 	cmp	x1, x0
    4e68:	54000049 	b.ls	4e70 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e6c:	f90a1441 	str	x1, [x2, #5160]
    4e70:	91158294 	add	x20, x20, #0x560
    4e74:	1e6302e1 	ucvtf	d1, w23
    4e78:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e7c:	1e612800 	fadd	d0, d0, d1
    4e80:	fd0a1e80 	str	d0, [x20, #5176]
    4e84:	52800041 	mov	w1, #0x2                   	// #2
    4e88:	29000678 	stp	w24, w1, [x19]
    4e8c:	aa1303e0 	mov	x0, x19
    4e90:	f94002a1 	ldr	x1, [x21]
    4e94:	f9000661 	str	x1, [x19, #8]
    4e98:	f94006a1 	ldr	x1, [x21, #8]
    4e9c:	f9000a61 	str	x1, [x19, #16]
    4ea0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ea4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ea8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4eac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4eb0:	d65f03c0 	ret
    4eb4:	8b020063 	add	x3, x3, x2
    4eb8:	f9400473 	ldr	x19, [x3, #8]
    4ebc:	b4000113 	cbz	x19, 4edc <fwp_data.part.0.constprop.0+0x108>
    4ec0:	f9400860 	ldr	x0, [x3, #16]
    4ec4:	cb130000 	sub	x0, x0, x19
    4ec8:	eb0002df 	cmp	x22, x0
    4ecc:	54000088 	b.hi	4edc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4ed0:	8b160260 	add	x0, x19, x22
    4ed4:	f9000460 	str	x0, [x3, #8]
    4ed8:	17ffffd5 	b	4e2c <fwp_data.part.0.constprop.0+0x58>
    4edc:	52800001 	mov	w1, #0x0                   	// #0
    4ee0:	d2800300 	mov	x0, #0x18                  	// #24
    4ee4:	97ffff77 	bl	4cc0 <fwp_heap_alloc>
    4ee8:	aa0003f3 	mov	x19, x0
    4eec:	17ffffe6 	b	4e84 <fwp_data.part.0.constprop.0+0xb0>
    4ef0:	97fff850 	bl	3030 <fwp_heap_oom>

0000000000004ef4 <fwp_p_ad_push>:
    4ef4:	f100001f 	cmp	x0, #0x0
    4ef8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4efc:	54000e8b 	b.lt	50cc <fwp_p_ad_push+0x1d8>  // b.tstop
    4f00:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f04:	aa0003e4 	mov	x4, x0
    4f08:	910003fd 	mov	x29, sp
    4f0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f10:	aa0003f5 	mov	x21, x0
    4f14:	aa020000 	orr	x0, x0, x2
    4f18:	a90363f7 	stp	x23, x24, [sp, #48]
    4f1c:	aa0203f7 	mov	x23, x2
    4f20:	6d0627e8 	stp	d8, d9, [sp, #96]
    4f24:	9e670029 	fmov	d9, x1
    4f28:	9e670068 	fmov	d8, x3
    4f2c:	b6f80900 	tbz	x0, #63, 504c <fwp_p_ad_push+0x158>
    4f30:	a90153f3 	stp	x19, x20, [sp, #16]
    4f34:	9360fc80 	asr	x0, x4, #32
    4f38:	b6f800c4 	tbz	x4, #63, 4f50 <fwp_p_ad_push+0x5c>
    4f3c:	1e604109 	fmov	d9, d8
    4f40:	2f00e408 	movi	d8, #0x0
    4f44:	9360fc40 	asr	x0, x2, #32
    4f48:	aa0203f5 	mov	x21, x2
    4f4c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f50:	97fffa58 	bl	38b0 <fwp_tape_of>
    4f54:	aa0003f3 	mov	x19, x0
    4f58:	f9403000 	ldr	x0, [x0, #96]
    4f5c:	b5001280 	cbnz	x0, 51ac <fwp_p_ad_push+0x2b8>
    4f60:	f9400a76 	ldr	x22, [x19, #16]
    4f64:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f68:	eb0002df 	cmp	x22, x0
    4f6c:	54000e2c 	b.gt	5130 <fwp_p_ad_push+0x23c>
    4f70:	eb3542df 	cmp	x22, w21, uxtw
    4f74:	54000d4d 	b.le	511c <fwp_p_ad_push+0x228>
    4f78:	b7f80077 	tbnz	x23, #63, 4f84 <fwp_p_ad_push+0x90>
    4f7c:	eb3742df 	cmp	x22, w23, uxtw
    4f80:	54000ced 	b.le	511c <fwp_p_ad_push+0x228>
    4f84:	f9400678 	ldr	x24, [x19, #8]
    4f88:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f8c:	cb1802d8 	sub	x24, x22, x24
    4f90:	91000701 	add	x1, x24, #0x1
    4f94:	eb00003f 	cmp	x1, x0
    4f98:	54000cc8 	b.hi	5130 <fwp_p_ad_push+0x23c>  // b.pmore
    4f9c:	a9418274 	ldp	x20, x0, [x19, #24]
    4fa0:	a90573fb 	stp	x27, x28, [sp, #80]
    4fa4:	eb14003f 	cmp	x1, x20
    4fa8:	5400068d 	b.le	5078 <fwp_p_ad_push+0x184>
    4fac:	f100029f 	cmp	x20, #0x0
    4fb0:	d2800803 	mov	x3, #0x40                  	// #64
    4fb4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4fb8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4fbc:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fc0:	eb14003f 	cmp	x1, x20
    4fc4:	5400008d 	b.le	4fd4 <fwp_p_ad_push+0xe0>
    4fc8:	eb02029f 	cmp	x20, x2
    4fcc:	5400052d 	b.le	5070 <fwp_p_ad_push+0x17c>
    4fd0:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4fd4:	d37df299 	lsl	x25, x20, #3
    4fd8:	aa1903e1 	mov	x1, x25
    4fdc:	97fff625 	bl	2870 <realloc@plt>
    4fe0:	aa0003e1 	mov	x1, x0
    4fe4:	b4000b00 	cbz	x0, 5144 <fwp_p_ad_push+0x250>
    4fe8:	f9400e62 	ldr	x2, [x19, #24]
    4fec:	f9001261 	str	x1, [x19, #32]
    4ff0:	f9401a60 	ldr	x0, [x19, #48]
    4ff4:	d37cee9a 	lsl	x26, x20, #4
    4ff8:	8b020821 	add	x1, x1, x2, lsl #2
    4ffc:	f9001661 	str	x1, [x19, #40]
    5000:	aa1a03e1 	mov	x1, x26
    5004:	97fff61b 	bl	2870 <realloc@plt>
    5008:	aa0003e2 	mov	x2, x0
    500c:	b40009c0 	cbz	x0, 5144 <fwp_p_ad_push+0x250>
    5010:	f9400e61 	ldr	x1, [x19, #24]
    5014:	d37df31b 	lsl	x27, x24, #3
    5018:	d37ef685 	lsl	x5, x20, #2
    501c:	d37ef71c 	lsl	x28, x24, #2
    5020:	8b190004 	add	x4, x0, x25
    5024:	8b010c01 	add	x1, x0, x1, lsl #3
    5028:	a9030660 	stp	x0, x1, [x19, #48]
    502c:	b5000558 	cbnz	x24, 50d4 <fwp_p_ad_push+0x1e0>
    5030:	f9001e64 	str	x4, [x19, #56]
    5034:	f9401260 	ldr	x0, [x19, #32]
    5038:	a9446bf9 	ldp	x25, x26, [sp, #64]
    503c:	8b050001 	add	x1, x0, x5
    5040:	f9000e74 	str	x20, [x19, #24]
    5044:	f9001661 	str	x1, [x19, #40]
    5048:	14000010 	b	5088 <fwp_p_ad_push+0x194>
    504c:	9360fc40 	asr	x0, x2, #32
    5050:	a90153f3 	stp	x19, x20, [sp, #16]
    5054:	eb84801f 	cmp	x0, x4, asr #32
    5058:	54fff7c0 	b.eq	4f50 <fwp_p_ad_push+0x5c>  // b.none
    505c:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    5060:	913b8000 	add	x0, x0, #0xee0
    5064:	a9046bf9 	stp	x25, x26, [sp, #64]
    5068:	a90573fb 	stp	x27, x28, [sp, #80]
    506c:	97fff945 	bl	3580 <fwp_trap>
    5070:	d37ffa94 	lsl	x20, x20, #1
    5074:	17ffffd3 	b	4fc0 <fwp_p_ad_push+0xcc>
    5078:	a9428a61 	ldp	x1, x2, [x19, #40]
    507c:	d37ef71c 	lsl	x28, x24, #2
    5080:	f9401e64 	ldr	x4, [x19, #56]
    5084:	d37df31b 	lsl	x27, x24, #3
    5088:	b83c6815 	str	w21, [x0, x28]
    508c:	f10002ff 	cmp	x23, #0x0
    5090:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5094:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5098:	fc3b6849 	str	d9, [x2, x27]
    509c:	aa1602a0 	orr	x0, x21, x22
    50a0:	b83c6837 	str	w23, [x1, x28]
    50a4:	910006d6 	add	x22, x22, #0x1
    50a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50ac:	fc3b6888 	str	d8, [x4, x27]
    50b0:	a94573fb 	ldp	x27, x28, [sp, #80]
    50b4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    50b8:	f9000a76 	str	x22, [x19, #16]
    50bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    50c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50c4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    50c8:	d65f03c0 	ret
    50cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    50d0:	d65f03c0 	ret
    50d4:	eb1a033f 	cmp	x25, x26
    50d8:	aa0403e0 	mov	x0, x4
    50dc:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    50e0:	aa1b03e2 	mov	x2, x27
    50e4:	cb190063 	sub	x3, x3, x25
    50e8:	f9003fe5 	str	x5, [sp, #120]
    50ec:	97fff64d 	bl	2a20 <__memmove_chk@plt>
    50f0:	a9420660 	ldp	x0, x1, [x19, #32]
    50f4:	aa1c03e2 	mov	x2, x28
    50f8:	f9401a63 	ldr	x3, [x19, #48]
    50fc:	f9403fe5 	ldr	x5, [sp, #120]
    5100:	8b190063 	add	x3, x3, x25
    5104:	f9001e63 	str	x3, [x19, #56]
    5108:	8b050000 	add	x0, x0, x5
    510c:	97fff579 	bl	26f0 <memmove@plt>
    5110:	a9431262 	ldp	x2, x4, [x19, #48]
    5114:	f9403fe5 	ldr	x5, [sp, #120]
    5118:	17ffffc7 	b	5034 <fwp_p_ad_push+0x140>
    511c:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    5120:	913de000 	add	x0, x0, #0xf78
    5124:	a9046bf9 	stp	x25, x26, [sp, #64]
    5128:	a90573fb 	stp	x27, x28, [sp, #80]
    512c:	97fff915 	bl	3580 <fwp_trap>
    5130:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    5134:	913d6000 	add	x0, x0, #0xf58
    5138:	a9046bf9 	stp	x25, x26, [sp, #64]
    513c:	a90573fb 	stp	x27, x28, [sp, #80]
    5140:	97fff910 	bl	3580 <fwp_trap>
    5144:	aa1303e0 	mov	x0, x19
    5148:	97fff792 	bl	2f90 <fwp_tape_unlink_scope>
    514c:	f9401260 	ldr	x0, [x19, #32]
    5150:	97fff5fc 	bl	2940 <free@plt>
    5154:	f9401a60 	ldr	x0, [x19, #48]
    5158:	97fff5fa 	bl	2940 <free@plt>
    515c:	f9402260 	ldr	x0, [x19, #64]
    5160:	97fff5f8 	bl	2940 <free@plt>
    5164:	f9000e7f 	str	xzr, [x19, #24]
    5168:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    516c:	f947e821 	ldr	x1, [x1, #4048]
    5170:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5174:	d2800262 	mov	x2, #0x13                  	// #19
    5178:	4f000400 	movi	v0.4s, #0x0
    517c:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    5180:	f9400023 	ldr	x3, [x1]
    5184:	b900067f 	str	wzr, [x19, #4]
    5188:	d2800021 	mov	x1, #0x1                   	// #1
    518c:	912fe000 	add	x0, x0, #0xbf8
    5190:	3c808260 	stur	q0, [x19, #8]
    5194:	ad010260 	stp	q0, q0, [x19, #32]
    5198:	97fff5fa 	bl	2980 <fwrite@plt>
    519c:	d2800000 	mov	x0, #0x0                   	// #0
    51a0:	97fff604 	bl	29b0 <fflush@plt>
    51a4:	52800cc0 	mov	w0, #0x66                  	// #102
    51a8:	97fff612 	bl	29f0 <_Exit@plt>
    51ac:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    51b0:	913ca000 	add	x0, x0, #0xf28
    51b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    51b8:	a90573fb 	stp	x27, x28, [sp, #80]
    51bc:	97fff8f1 	bl	3580 <fwp_trap>

00000000000051c0 <w120>:
    51c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51c4:	9e660003 	fmov	x3, d0
    51c8:	aa0003e2 	mov	x2, x0
    51cc:	910003fd 	mov	x29, sp
    51d0:	fd001fea 	str	d10, [sp, #56]
    51d4:	1e60400a 	fmov	d10, d0
    51d8:	6d0427e8 	stp	d8, d9, [sp, #64]
    51dc:	1e604028 	fmov	d8, d1
    51e0:	1e600809 	fmul	d9, d0, d0
    51e4:	a90153f3 	stp	x19, x20, [sp, #16]
    51e8:	aa0103f4 	mov	x20, x1
    51ec:	aa0303e1 	mov	x1, x3
    51f0:	aa0003f3 	mov	x19, x0
    51f4:	a9025bf5 	stp	x21, x22, [sp, #32]
    51f8:	f9001bf7 	str	x23, [sp, #48]
    51fc:	97ffff3e 	bl	4ef4 <fwp_p_ad_push>
    5200:	aa0003e5 	mov	x5, x0
    5204:	97fffb90 	bl	4044 <caf75>
    5208:	9e670000 	fmov	d0, x0
    520c:	97fffb8e 	bl	4044 <caf75>
    5210:	1e693908 	fsub	d8, d8, d9
    5214:	aa1403e2 	mov	x2, x20
    5218:	1e614000 	fneg	d0, d0
    521c:	aa0003e3 	mov	x3, x0
    5220:	aa0503e0 	mov	x0, x5
    5224:	9e660117 	fmov	x23, d8
    5228:	9e660001 	fmov	x1, d0
    522c:	97ffff32 	bl	4ef4 <fwp_p_ad_push>
    5230:	aa0003f5 	mov	x21, x0
    5234:	97fffb84 	bl	4044 <caf75>
    5238:	9e670000 	fmov	d0, x0
    523c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5240:	97fffb81 	bl	4044 <caf75>
    5244:	1e614000 	fneg	d0, d0
    5248:	aa0003e3 	mov	x3, x0
    524c:	1e6a3929 	fsub	d9, d9, d10
    5250:	aa1303e0 	mov	x0, x19
    5254:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5258:	9e660001 	fmov	x1, d0
    525c:	9e660136 	fmov	x22, d9
    5260:	97ffff25 	bl	4ef4 <fwp_p_ad_push>
    5264:	1e680908 	fmul	d8, d8, d8
    5268:	aa0003f4 	mov	x20, x0
    526c:	aa1703e3 	mov	x3, x23
    5270:	aa1703e1 	mov	x1, x23
    5274:	aa1503e2 	mov	x2, x21
    5278:	aa1503e0 	mov	x0, x21
    527c:	97ffff1e 	bl	4ef4 <fwp_p_ad_push>
    5280:	aa0003e2 	mov	x2, x0
    5284:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5288:	9e670020 	fmov	d0, x1
    528c:	9e660101 	fmov	x1, d8
    5290:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5294:	1e600908 	fmul	d8, d8, d0
    5298:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    529c:	97ffff16 	bl	4ef4 <fwp_p_ad_push>
    52a0:	1e690929 	fmul	d9, d9, d9
    52a4:	aa1603e3 	mov	x3, x22
    52a8:	aa1603e1 	mov	x1, x22
    52ac:	aa1403e2 	mov	x2, x20
    52b0:	aa0003f3 	mov	x19, x0
    52b4:	aa1403e0 	mov	x0, x20
    52b8:	97ffff0f 	bl	4ef4 <fwp_p_ad_push>
    52bc:	aa0003e5 	mov	x5, x0
    52c0:	97fffb61 	bl	4044 <caf75>
    52c4:	aa0003e6 	mov	x6, x0
    52c8:	97fffb5f 	bl	4044 <caf75>
    52cc:	1e692908 	fadd	d8, d8, d9
    52d0:	aa1303e2 	mov	x2, x19
    52d4:	aa0603e1 	mov	x1, x6
    52d8:	aa0003e3 	mov	x3, x0
    52dc:	aa0503e0 	mov	x0, x5
    52e0:	97ffff05 	bl	4ef4 <fwp_p_ad_push>
    52e4:	aa0003e1 	mov	x1, x0
    52e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    52ec:	9e660100 	fmov	x0, d8
    52f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52f4:	f9401bf7 	ldr	x23, [sp, #48]
    52f8:	fd401fea 	ldr	d10, [sp, #56]
    52fc:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5300:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5304:	d65f03c0 	ret
    5308:	d503201f 	nop
    530c:	d503201f 	nop

0000000000005310 <w176.constprop.0>:
    5310:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5314:	910003fd 	mov	x29, sp
    5318:	a9025bf5 	stp	x21, x22, [sp, #32]
    531c:	fd001be8 	str	d8, [sp, #48]
    5320:	f9400015 	ldr	x21, [x0]
    5324:	b40003b5 	cbz	x21, 5398 <w176.constprop.0+0x88>
    5328:	2f00e408 	movi	d8, #0x0
    532c:	91002016 	add	x22, x0, #0x8
    5330:	a90153f3 	stp	x19, x20, [sp, #16]
    5334:	91004014 	add	x20, x0, #0x10
    5338:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    533c:	d2800013 	mov	x19, #0x0                   	// #0
    5340:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5344:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    5348:	97fffb3f 	bl	4044 <caf75>
    534c:	aa0003e6 	mov	x6, x0
    5350:	97fffb3d 	bl	4044 <caf75>
    5354:	1e602908 	fadd	d8, d8, d0
    5358:	aa0003e3 	mov	x3, x0
    535c:	aa0703e2 	mov	x2, x7
    5360:	aa0503e0 	mov	x0, x5
    5364:	aa0603e1 	mov	x1, x6
    5368:	91000a73 	add	x19, x19, #0x2
    536c:	97fffee2 	bl	4ef4 <fwp_p_ad_push>
    5370:	aa0003e5 	mov	x5, x0
    5374:	eb1302bf 	cmp	x21, x19
    5378:	54fffe48 	b.hi	5340 <w176.constprop.0+0x30>  // b.pmore
    537c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5380:	9e660100 	fmov	x0, d8
    5384:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5388:	aa0503e1 	mov	x1, x5
    538c:	fd401be8 	ldr	d8, [sp, #48]
    5390:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5394:	d65f03c0 	ret
    5398:	2f00e408 	movi	d8, #0x0
    539c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    53a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53a4:	aa0503e1 	mov	x1, x5
    53a8:	9e660100 	fmov	x0, d8
    53ac:	fd401be8 	ldr	d8, [sp, #48]
    53b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    53b4:	d65f03c0 	ret
    53b8:	d503201f 	nop
    53bc:	d503201f 	nop

00000000000053c0 <fwp_rc_share>:
    53c0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc80>
    53c4:	91158042 	add	x2, x2, #0x560
    53c8:	f949d843 	ldr	x3, [x2, #5040]
    53cc:	f949ec41 	ldr	x1, [x2, #5080]
    53d0:	cb030000 	sub	x0, x0, x3
    53d4:	eb01401f 	cmp	x0, x1, lsl #16
    53d8:	540002c2 	b.cs	5430 <fwp_rc_share+0x70>  // b.hs, b.nlast
    53dc:	d350fc01 	lsr	x1, x0, #16
    53e0:	f949fc44 	ldr	x4, [x2, #5112]
    53e4:	8b010821 	add	x1, x1, x1, lsl #2
    53e8:	d37df021 	lsl	x1, x1, #3
    53ec:	8b010083 	add	x3, x4, x1
    53f0:	f9401062 	ldr	x2, [x3, #32]
    53f4:	b40001e2 	cbz	x2, 5430 <fwp_rc_share+0x70>
    53f8:	38616881 	ldrb	w1, [x4, x1]
    53fc:	7100083f 	cmp	w1, #0x2
    5400:	540001a0 	b.eq	5434 <fwp_rc_share+0x74>  // b.none
    5404:	7100043f 	cmp	w1, #0x1
    5408:	54000141 	b.ne	5430 <fwp_rc_share+0x70>  // b.any
    540c:	29430464 	ldp	w4, w1, [x3, #24]
    5410:	92403c00 	and	x0, x0, #0xffff
    5414:	9b047c00 	mul	x0, x0, x4
    5418:	d360fc00 	lsr	x0, x0, #32
    541c:	eb01001f 	cmp	x0, x1
    5420:	54000082 	b.cs	5430 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5424:	8b000042 	add	x2, x2, x0
    5428:	39400040 	ldrb	w0, [x2]
    542c:	350000a0 	cbnz	w0, 5440 <fwp_rc_share+0x80>
    5430:	d65f03c0 	ret
    5434:	72003c1f 	tst	w0, #0xffff
    5438:	54ffff80 	b.eq	5428 <fwp_rc_share+0x68>  // b.none
    543c:	d65f03c0 	ret
    5440:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5444:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    5448:	913e6000 	add	x0, x0, #0xf98
    544c:	910003fd 	mov	x29, sp
    5450:	97fff84c 	bl	3580 <fwp_trap>

0000000000005454 <fwp_rc_fresh>:
    5454:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5458:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc80>
    545c:	91158063 	add	x3, x3, #0x560
    5460:	910003fd 	mov	x29, sp
    5464:	a90153f3 	stp	x19, x20, [sp, #16]
    5468:	aa0003f3 	mov	x19, x0
    546c:	f949d861 	ldr	x1, [x3, #5040]
    5470:	f949ec60 	ldr	x0, [x3, #5080]
    5474:	cb010261 	sub	x1, x19, x1
    5478:	eb00403f 	cmp	x1, x0, lsl #16
    547c:	54000322 	b.cs	54e0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5480:	d350fc22 	lsr	x2, x1, #16
    5484:	f949fc63 	ldr	x3, [x3, #5112]
    5488:	8b020842 	add	x2, x2, x2, lsl #2
    548c:	d37df042 	lsl	x2, x2, #3
    5490:	8b020060 	add	x0, x3, x2
    5494:	f9401014 	ldr	x20, [x0, #32]
    5498:	b4000254 	cbz	x20, 54e0 <fwp_rc_fresh+0x8c>
    549c:	38626862 	ldrb	w2, [x3, x2]
    54a0:	7100085f 	cmp	w2, #0x2
    54a4:	54000260 	b.eq	54f0 <fwp_rc_fresh+0x9c>  // b.none
    54a8:	7100045f 	cmp	w2, #0x1
    54ac:	540001a1 	b.ne	54e0 <fwp_rc_fresh+0x8c>  // b.any
    54b0:	29430002 	ldp	w2, w0, [x0, #24]
    54b4:	92403c21 	and	x1, x1, #0xffff
    54b8:	9b027c21 	mul	x1, x1, x2
    54bc:	d360fc21 	lsr	x1, x1, #32
    54c0:	eb00003f 	cmp	x1, x0
    54c4:	540000e2 	b.cs	54e0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    54c8:	8b010294 	add	x20, x20, x1
    54cc:	39400280 	ldrb	w0, [x20]
    54d0:	7103fc1f 	cmp	w0, #0xff
    54d4:	540001a0 	b.eq	5508 <fwp_rc_fresh+0xb4>  // b.none
    54d8:	52800020 	mov	w0, #0x1                   	// #1
    54dc:	39000280 	strb	w0, [x20]
    54e0:	aa1303e0 	mov	x0, x19
    54e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    54e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    54ec:	d65f03c0 	ret
    54f0:	72003c3f 	tst	w1, #0xffff
    54f4:	54fffec0 	b.eq	54cc <fwp_rc_fresh+0x78>  // b.none
    54f8:	aa1303e0 	mov	x0, x19
    54fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5500:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5504:	d65f03c0 	ret
    5508:	aa1403e0 	mov	x0, x20
    550c:	97fffc2d 	bl	45c0 <fwp_rc_forget_slot>
    5510:	17fffff2 	b	54d8 <fwp_rc_fresh+0x84>

0000000000005514 <fwp_rc_free_arr>:
    5514:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc80>
    5518:	91158063 	add	x3, x3, #0x560
    551c:	f949d861 	ldr	x1, [x3, #5040]
    5520:	f949ec62 	ldr	x2, [x3, #5080]
    5524:	cb010001 	sub	x1, x0, x1
    5528:	eb02403f 	cmp	x1, x2, lsl #16
    552c:	54000342 	b.cs	5594 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5530:	d350fc22 	lsr	x2, x1, #16
    5534:	f949fc65 	ldr	x5, [x3, #5112]
    5538:	8b020842 	add	x2, x2, x2, lsl #2
    553c:	d37df042 	lsl	x2, x2, #3
    5540:	8b0200a4 	add	x4, x5, x2
    5544:	f9401083 	ldr	x3, [x4, #32]
    5548:	b4000263 	cbz	x3, 5594 <fwp_rc_free_arr+0x80>
    554c:	386268a2 	ldrb	w2, [x5, x2]
    5550:	7100085f 	cmp	w2, #0x2
    5554:	540001c0 	b.eq	558c <fwp_rc_free_arr+0x78>  // b.none
    5558:	7100045f 	cmp	w2, #0x1
    555c:	540001c1 	b.ne	5594 <fwp_rc_free_arr+0x80>  // b.any
    5560:	29430885 	ldp	w5, w2, [x4, #24]
    5564:	92403c21 	and	x1, x1, #0xffff
    5568:	9b057c21 	mul	x1, x1, x5
    556c:	d360fc21 	lsr	x1, x1, #32
    5570:	eb02003f 	cmp	x1, x2
    5574:	54000102 	b.cs	5594 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5578:	8b010063 	add	x3, x3, x1
    557c:	39400061 	ldrb	w1, [x3]
    5580:	7100043f 	cmp	w1, #0x1
    5584:	54000081 	b.ne	5594 <fwp_rc_free_arr+0x80>  // b.any
    5588:	17fffcae 	b	4840 <fwp_mem_free>
    558c:	72003c3f 	tst	w1, #0xffff
    5590:	54ffff60 	b.eq	557c <fwp_rc_free_arr+0x68>  // b.none
    5594:	d65f03c0 	ret
    5598:	d503201f 	nop
    559c:	d503201f 	nop

00000000000055a0 <fwp_rc_dup>:
    55a0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc80>
    55a4:	91158042 	add	x2, x2, #0x560
    55a8:	f949d841 	ldr	x1, [x2, #5040]
    55ac:	f949ec43 	ldr	x3, [x2, #5080]
    55b0:	cb010001 	sub	x1, x0, x1
    55b4:	eb03403f 	cmp	x1, x3, lsl #16
    55b8:	54000342 	b.cs	5620 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    55bc:	d350fc20 	lsr	x0, x1, #16
    55c0:	f949fc44 	ldr	x4, [x2, #5112]
    55c4:	8b000800 	add	x0, x0, x0, lsl #2
    55c8:	d37df002 	lsl	x2, x0, #3
    55cc:	8b020083 	add	x3, x4, x2
    55d0:	f9401060 	ldr	x0, [x3, #32]
    55d4:	b4000260 	cbz	x0, 5620 <fwp_rc_dup+0x80>
    55d8:	38626882 	ldrb	w2, [x4, x2]
    55dc:	7100085f 	cmp	w2, #0x2
    55e0:	54000220 	b.eq	5624 <fwp_rc_dup+0x84>  // b.none
    55e4:	7100045f 	cmp	w2, #0x1
    55e8:	540001c1 	b.ne	5620 <fwp_rc_dup+0x80>  // b.any
    55ec:	29430864 	ldp	w4, w2, [x3, #24]
    55f0:	92403c21 	and	x1, x1, #0xffff
    55f4:	9b047c21 	mul	x1, x1, x4
    55f8:	d360fc21 	lsr	x1, x1, #32
    55fc:	eb02003f 	cmp	x1, x2
    5600:	54000102 	b.cs	5620 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5604:	8b010000 	add	x0, x0, x1
    5608:	39400001 	ldrb	w1, [x0]
    560c:	340000a1 	cbz	w1, 5620 <fwp_rc_dup+0x80>
    5610:	7103f43f 	cmp	w1, #0xfd
    5614:	540000e8 	b.hi	5630 <fwp_rc_dup+0x90>  // b.pmore
    5618:	11000421 	add	w1, w1, #0x1
    561c:	39000001 	strb	w1, [x0]
    5620:	d65f03c0 	ret
    5624:	72003c3f 	tst	w1, #0xffff
    5628:	54ffff00 	b.eq	5608 <fwp_rc_dup+0x68>  // b.none
    562c:	d65f03c0 	ret
    5630:	17fffb9d 	b	44a4 <fwp_rc_wide_dup>

0000000000005634 <fwp_owned_entry173>:
    5634:	d10103ff 	sub	sp, sp, #0x40
    5638:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    563c:	f947f442 	ldr	x2, [x2, #4072]
    5640:	a9027bfd 	stp	x29, x30, [sp, #32]
    5644:	910083fd 	add	x29, sp, #0x20
    5648:	a90353f3 	stp	x19, x20, [sp, #48]
    564c:	f9400043 	ldr	x3, [x2]
    5650:	f9000fe3 	str	x3, [sp, #24]
    5654:	d2800003 	mov	x3, #0x0                   	// #0
    5658:	a9400c01 	ldp	x1, x3, [x0]
    565c:	f9400802 	ldr	x2, [x0, #16]
    5660:	ab020022 	adds	x2, x1, x2
    5664:	540006e6 	b.vs	5740 <fwp_owned_entry173+0x10c>
    5668:	910023e1 	add	x1, sp, #0x8
    566c:	52800000 	mov	w0, #0x0                   	// #0
    5670:	a9008be3 	stp	x3, x2, [sp, #8]
    5674:	97fffdd8 	bl	4dd4 <fwp_data.part.0.constprop.0>
    5678:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc80>
    567c:	91158063 	add	x3, x3, #0x560
    5680:	aa0003f3 	mov	x19, x0
    5684:	f949d861 	ldr	x1, [x3, #5040]
    5688:	f949ec60 	ldr	x0, [x3, #5080]
    568c:	cb010261 	sub	x1, x19, x1
    5690:	eb00403f 	cmp	x1, x0, lsl #16
    5694:	54000322 	b.cs	56f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5698:	d350fc22 	lsr	x2, x1, #16
    569c:	f949fc63 	ldr	x3, [x3, #5112]
    56a0:	8b020842 	add	x2, x2, x2, lsl #2
    56a4:	d37df042 	lsl	x2, x2, #3
    56a8:	8b020060 	add	x0, x3, x2
    56ac:	f9401014 	ldr	x20, [x0, #32]
    56b0:	b4000254 	cbz	x20, 56f8 <fwp_owned_entry173+0xc4>
    56b4:	38626862 	ldrb	w2, [x3, x2]
    56b8:	7100085f 	cmp	w2, #0x2
    56bc:	54000360 	b.eq	5728 <fwp_owned_entry173+0xf4>  // b.none
    56c0:	7100045f 	cmp	w2, #0x1
    56c4:	540001a1 	b.ne	56f8 <fwp_owned_entry173+0xc4>  // b.any
    56c8:	29430002 	ldp	w2, w0, [x0, #24]
    56cc:	92403c21 	and	x1, x1, #0xffff
    56d0:	9b027c21 	mul	x1, x1, x2
    56d4:	d360fc21 	lsr	x1, x1, #32
    56d8:	eb00003f 	cmp	x1, x0
    56dc:	540000e2 	b.cs	56f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    56e0:	8b010294 	add	x20, x20, x1
    56e4:	39400280 	ldrb	w0, [x20]
    56e8:	7103fc1f 	cmp	w0, #0xff
    56ec:	54000240 	b.eq	5734 <fwp_owned_entry173+0x100>  // b.none
    56f0:	52800020 	mov	w0, #0x1                   	// #1
    56f4:	39000280 	strb	w0, [x20]
    56f8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    56fc:	f947f400 	ldr	x0, [x0, #4072]
    5700:	f9400fe2 	ldr	x2, [sp, #24]
    5704:	f9400001 	ldr	x1, [x0]
    5708:	eb010042 	subs	x2, x2, x1
    570c:	d2800001 	mov	x1, #0x0                   	// #0
    5710:	540001a1 	b.ne	5744 <fwp_owned_entry173+0x110>  // b.any
    5714:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5718:	aa1303e0 	mov	x0, x19
    571c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5720:	910103ff 	add	sp, sp, #0x40
    5724:	d65f03c0 	ret
    5728:	72003c3f 	tst	w1, #0xffff
    572c:	54fffe61 	b.ne	56f8 <fwp_owned_entry173+0xc4>  // b.any
    5730:	17ffffed 	b	56e4 <fwp_owned_entry173+0xb0>
    5734:	aa1403e0 	mov	x0, x20
    5738:	97fffba2 	bl	45c0 <fwp_rc_forget_slot>
    573c:	17ffffed 	b	56f0 <fwp_owned_entry173+0xbc>
    5740:	97fff4d0 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5744:	97fff44f 	bl	2880 <__stack_chk_fail@plt>
    5748:	d503201f 	nop
    574c:	d503201f 	nop

0000000000005750 <e173>:
    5750:	d10103ff 	sub	sp, sp, #0x40
    5754:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5758:	f947f442 	ldr	x2, [x2, #4072]
    575c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5760:	910083fd 	add	x29, sp, #0x20
    5764:	a90353f3 	stp	x19, x20, [sp, #48]
    5768:	f9400043 	ldr	x3, [x2]
    576c:	f9000fe3 	str	x3, [sp, #24]
    5770:	d2800003 	mov	x3, #0x0                   	// #0
    5774:	a9400c01 	ldp	x1, x3, [x0]
    5778:	f9400802 	ldr	x2, [x0, #16]
    577c:	ab020022 	adds	x2, x1, x2
    5780:	54000726 	b.vs	5864 <e173+0x114>
    5784:	910023e1 	add	x1, sp, #0x8
    5788:	52800000 	mov	w0, #0x0                   	// #0
    578c:	a9008be3 	stp	x3, x2, [sp, #8]
    5790:	97fffd91 	bl	4dd4 <fwp_data.part.0.constprop.0>
    5794:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc80>
    5798:	91158063 	add	x3, x3, #0x560
    579c:	aa0003f3 	mov	x19, x0
    57a0:	f949d861 	ldr	x1, [x3, #5040]
    57a4:	f949ec60 	ldr	x0, [x3, #5080]
    57a8:	cb010261 	sub	x1, x19, x1
    57ac:	eb00403f 	cmp	x1, x0, lsl #16
    57b0:	54000322 	b.cs	5814 <e173+0xc4>  // b.hs, b.nlast
    57b4:	d350fc22 	lsr	x2, x1, #16
    57b8:	f949fc63 	ldr	x3, [x3, #5112]
    57bc:	8b020842 	add	x2, x2, x2, lsl #2
    57c0:	d37df042 	lsl	x2, x2, #3
    57c4:	8b020060 	add	x0, x3, x2
    57c8:	f9401014 	ldr	x20, [x0, #32]
    57cc:	b4000254 	cbz	x20, 5814 <e173+0xc4>
    57d0:	38626862 	ldrb	w2, [x3, x2]
    57d4:	7100085f 	cmp	w2, #0x2
    57d8:	540003a0 	b.eq	584c <e173+0xfc>  // b.none
    57dc:	7100045f 	cmp	w2, #0x1
    57e0:	540001a1 	b.ne	5814 <e173+0xc4>  // b.any
    57e4:	29430002 	ldp	w2, w0, [x0, #24]
    57e8:	92403c21 	and	x1, x1, #0xffff
    57ec:	9b027c21 	mul	x1, x1, x2
    57f0:	d360fc21 	lsr	x1, x1, #32
    57f4:	eb00003f 	cmp	x1, x0
    57f8:	540000e2 	b.cs	5814 <e173+0xc4>  // b.hs, b.nlast
    57fc:	8b010294 	add	x20, x20, x1
    5800:	39400280 	ldrb	w0, [x20]
    5804:	7103fc1f 	cmp	w0, #0xff
    5808:	54000280 	b.eq	5858 <e173+0x108>  // b.none
    580c:	52800020 	mov	w0, #0x1                   	// #1
    5810:	39000280 	strb	w0, [x20]
    5814:	aa1303e0 	mov	x0, x19
    5818:	97fffeea 	bl	53c0 <fwp_rc_share>
    581c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5820:	f947f400 	ldr	x0, [x0, #4072]
    5824:	f9400fe2 	ldr	x2, [sp, #24]
    5828:	f9400001 	ldr	x1, [x0]
    582c:	eb010042 	subs	x2, x2, x1
    5830:	d2800001 	mov	x1, #0x0                   	// #0
    5834:	540001a1 	b.ne	5868 <e173+0x118>  // b.any
    5838:	a9427bfd 	ldp	x29, x30, [sp, #32]
    583c:	aa1303e0 	mov	x0, x19
    5840:	a94353f3 	ldp	x19, x20, [sp, #48]
    5844:	910103ff 	add	sp, sp, #0x40
    5848:	d65f03c0 	ret
    584c:	72003c3f 	tst	w1, #0xffff
    5850:	54fffe21 	b.ne	5814 <e173+0xc4>  // b.any
    5854:	17ffffeb 	b	5800 <e173+0xb0>
    5858:	aa1403e0 	mov	x0, x20
    585c:	97fffb59 	bl	45c0 <fwp_rc_forget_slot>
    5860:	17ffffeb 	b	580c <e173+0xbc>
    5864:	97fff487 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5868:	97fff406 	bl	2880 <__stack_chk_fail@plt>
    586c:	d503201f 	nop

0000000000005870 <fwp_drop1>:
    5870:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5874:	910003fd 	mov	x29, sp
    5878:	a90153f3 	stp	x19, x20, [sp, #16]
    587c:	f90013f5 	str	x21, [sp, #32]
    5880:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    5884:	911582b4 	add	x20, x21, #0x560
    5888:	f949da81 	ldr	x1, [x20, #5040]
    588c:	f949ee82 	ldr	x2, [x20, #5080]
    5890:	cb010001 	sub	x1, x0, x1
    5894:	eb02403f 	cmp	x1, x2, lsl #16
    5898:	54000382 	b.cs	5908 <fwp_drop1+0x98>  // b.hs, b.nlast
    589c:	d350fc22 	lsr	x2, x1, #16
    58a0:	f949fe84 	ldr	x4, [x20, #5112]
    58a4:	8b020842 	add	x2, x2, x2, lsl #2
    58a8:	d37df042 	lsl	x2, x2, #3
    58ac:	8b020083 	add	x3, x4, x2
    58b0:	f9401073 	ldr	x19, [x3, #32]
    58b4:	b40002b3 	cbz	x19, 5908 <fwp_drop1+0x98>
    58b8:	38626882 	ldrb	w2, [x4, x2]
    58bc:	7100085f 	cmp	w2, #0x2
    58c0:	540002c0 	b.eq	5918 <fwp_drop1+0xa8>  // b.none
    58c4:	7100045f 	cmp	w2, #0x1
    58c8:	54000201 	b.ne	5908 <fwp_drop1+0x98>  // b.any
    58cc:	29430864 	ldp	w4, w2, [x3, #24]
    58d0:	92403c21 	and	x1, x1, #0xffff
    58d4:	9b047c21 	mul	x1, x1, x4
    58d8:	d360fc21 	lsr	x1, x1, #32
    58dc:	eb02003f 	cmp	x1, x2
    58e0:	54000142 	b.cs	5908 <fwp_drop1+0x98>  // b.hs, b.nlast
    58e4:	8b010273 	add	x19, x19, x1
    58e8:	39400261 	ldrb	w1, [x19]
    58ec:	340000e1 	cbz	w1, 5908 <fwp_drop1+0x98>
    58f0:	7100043f 	cmp	w1, #0x1
    58f4:	540001e0 	b.eq	5930 <fwp_drop1+0xc0>  // b.none
    58f8:	7103fc3f 	cmp	w1, #0xff
    58fc:	540002e0 	b.eq	5958 <fwp_drop1+0xe8>  // b.none
    5900:	51000421 	sub	w1, w1, #0x1
    5904:	39000261 	strb	w1, [x19]
    5908:	a94153f3 	ldp	x19, x20, [sp, #16]
    590c:	f94013f5 	ldr	x21, [sp, #32]
    5910:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5914:	d65f03c0 	ret
    5918:	72003c3f 	tst	w1, #0xffff
    591c:	54fffe60 	b.eq	58e8 <fwp_drop1+0x78>  // b.none
    5920:	a94153f3 	ldp	x19, x20, [sp, #16]
    5924:	f94013f5 	ldr	x21, [sp, #32]
    5928:	a8c37bfd 	ldp	x29, x30, [sp], #48
    592c:	d65f03c0 	ret
    5930:	f9400813 	ldr	x19, [x0, #16]
    5934:	97fffef8 	bl	5514 <fwp_rc_free_arr>
    5938:	911582a0 	add	x0, x21, #0x560
    593c:	f949d801 	ldr	x1, [x0, #5040]
    5940:	f949ec00 	ldr	x0, [x0, #5080]
    5944:	cb010261 	sub	x1, x19, x1
    5948:	eb00403f 	cmp	x1, x0, lsl #16
    594c:	54fffde2 	b.cs	5908 <fwp_drop1+0x98>  // b.hs, b.nlast
    5950:	aa1303e0 	mov	x0, x19
    5954:	17ffffd2 	b	589c <fwp_drop1+0x2c>
    5958:	ca534660 	eor	x0, x19, x19, lsr #17
    595c:	911582b5 	add	x21, x21, #0x560
    5960:	ca402400 	eor	x0, x0, x0, lsr #9
    5964:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5968:	f94a2400 	ldr	x0, [x0, #5192]
    596c:	b5000080 	cbnz	x0, 597c <fwp_drop1+0x10c>
    5970:	14000010 	b	59b0 <fwp_drop1+0x140>
    5974:	f9400800 	ldr	x0, [x0, #16]
    5978:	b40001c0 	cbz	x0, 59b0 <fwp_drop1+0x140>
    597c:	f9400001 	ldr	x1, [x0]
    5980:	eb13003f 	cmp	x1, x19
    5984:	54ffff81 	b.ne	5974 <fwp_drop1+0x104>  // b.any
    5988:	f9400401 	ldr	x1, [x0, #8]
    598c:	d1000421 	sub	x1, x1, #0x1
    5990:	f9000401 	str	x1, [x0, #8]
    5994:	f103f83f 	cmp	x1, #0xfe
    5998:	54fffb81 	b.ne	5908 <fwp_drop1+0x98>  // b.any
    599c:	aa1303e0 	mov	x0, x19
    59a0:	97fffb08 	bl	45c0 <fwp_rc_forget_slot>
    59a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    59a8:	39000260 	strb	w0, [x19]
    59ac:	17ffffd7 	b	5908 <fwp_drop1+0x98>
    59b0:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    59b4:	913a6000 	add	x0, x0, #0xe98
    59b8:	97fff6f2 	bl	3580 <fwp_trap>
    59bc:	d503201f 	nop

00000000000059c0 <fwp_drop0>:
    59c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    59c4:	910003fd 	mov	x29, sp
    59c8:	a90153f3 	stp	x19, x20, [sp, #16]
    59cc:	f90013f5 	str	x21, [sp, #32]
    59d0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    59d4:	911582b4 	add	x20, x21, #0x560
    59d8:	f949da81 	ldr	x1, [x20, #5040]
    59dc:	f949ee82 	ldr	x2, [x20, #5080]
    59e0:	cb010001 	sub	x1, x0, x1
    59e4:	eb02403f 	cmp	x1, x2, lsl #16
    59e8:	54000382 	b.cs	5a58 <fwp_drop0+0x98>  // b.hs, b.nlast
    59ec:	d350fc22 	lsr	x2, x1, #16
    59f0:	f949fe84 	ldr	x4, [x20, #5112]
    59f4:	8b020842 	add	x2, x2, x2, lsl #2
    59f8:	d37df042 	lsl	x2, x2, #3
    59fc:	8b020083 	add	x3, x4, x2
    5a00:	f9401073 	ldr	x19, [x3, #32]
    5a04:	b40002b3 	cbz	x19, 5a58 <fwp_drop0+0x98>
    5a08:	38626882 	ldrb	w2, [x4, x2]
    5a0c:	7100085f 	cmp	w2, #0x2
    5a10:	540002c0 	b.eq	5a68 <fwp_drop0+0xa8>  // b.none
    5a14:	7100045f 	cmp	w2, #0x1
    5a18:	54000201 	b.ne	5a58 <fwp_drop0+0x98>  // b.any
    5a1c:	29430864 	ldp	w4, w2, [x3, #24]
    5a20:	92403c21 	and	x1, x1, #0xffff
    5a24:	9b047c21 	mul	x1, x1, x4
    5a28:	d360fc21 	lsr	x1, x1, #32
    5a2c:	eb02003f 	cmp	x1, x2
    5a30:	54000142 	b.cs	5a58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5a34:	8b010273 	add	x19, x19, x1
    5a38:	39400261 	ldrb	w1, [x19]
    5a3c:	340000e1 	cbz	w1, 5a58 <fwp_drop0+0x98>
    5a40:	7100043f 	cmp	w1, #0x1
    5a44:	540001e0 	b.eq	5a80 <fwp_drop0+0xc0>  // b.none
    5a48:	7103fc3f 	cmp	w1, #0xff
    5a4c:	540002e0 	b.eq	5aa8 <fwp_drop0+0xe8>  // b.none
    5a50:	51000421 	sub	w1, w1, #0x1
    5a54:	39000261 	strb	w1, [x19]
    5a58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a5c:	f94013f5 	ldr	x21, [sp, #32]
    5a60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a64:	d65f03c0 	ret
    5a68:	72003c3f 	tst	w1, #0xffff
    5a6c:	54fffe60 	b.eq	5a38 <fwp_drop0+0x78>  // b.none
    5a70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a74:	f94013f5 	ldr	x21, [sp, #32]
    5a78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a7c:	d65f03c0 	ret
    5a80:	f9400813 	ldr	x19, [x0, #16]
    5a84:	97fffea4 	bl	5514 <fwp_rc_free_arr>
    5a88:	911582a0 	add	x0, x21, #0x560
    5a8c:	f949d801 	ldr	x1, [x0, #5040]
    5a90:	f949ec00 	ldr	x0, [x0, #5080]
    5a94:	cb010261 	sub	x1, x19, x1
    5a98:	eb00403f 	cmp	x1, x0, lsl #16
    5a9c:	54fffde2 	b.cs	5a58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5aa0:	aa1303e0 	mov	x0, x19
    5aa4:	17ffffd2 	b	59ec <fwp_drop0+0x2c>
    5aa8:	ca534660 	eor	x0, x19, x19, lsr #17
    5aac:	911582b5 	add	x21, x21, #0x560
    5ab0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ab4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5ab8:	f94a2400 	ldr	x0, [x0, #5192]
    5abc:	b5000080 	cbnz	x0, 5acc <fwp_drop0+0x10c>
    5ac0:	14000010 	b	5b00 <fwp_drop0+0x140>
    5ac4:	f9400800 	ldr	x0, [x0, #16]
    5ac8:	b40001c0 	cbz	x0, 5b00 <fwp_drop0+0x140>
    5acc:	f9400001 	ldr	x1, [x0]
    5ad0:	eb13003f 	cmp	x1, x19
    5ad4:	54ffff81 	b.ne	5ac4 <fwp_drop0+0x104>  // b.any
    5ad8:	f9400401 	ldr	x1, [x0, #8]
    5adc:	d1000421 	sub	x1, x1, #0x1
    5ae0:	f9000401 	str	x1, [x0, #8]
    5ae4:	f103f83f 	cmp	x1, #0xfe
    5ae8:	54fffb81 	b.ne	5a58 <fwp_drop0+0x98>  // b.any
    5aec:	aa1303e0 	mov	x0, x19
    5af0:	97fffab4 	bl	45c0 <fwp_rc_forget_slot>
    5af4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5af8:	39000260 	strb	w0, [x19]
    5afc:	17ffffd7 	b	5a58 <fwp_drop0+0x98>
    5b00:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    5b04:	913a6000 	add	x0, x0, #0xe98
    5b08:	97fff69e 	bl	3580 <fwp_trap>
    5b0c:	d503201f 	nop

0000000000005b10 <fwp_closure_drop>:
    5b10:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc80>
    5b14:	911580a4 	add	x4, x5, #0x560
    5b18:	aa0003e1 	mov	x1, x0
    5b1c:	f949d882 	ldr	x2, [x4, #5040]
    5b20:	f949ec80 	ldr	x0, [x4, #5080]
    5b24:	cb020022 	sub	x2, x1, x2
    5b28:	eb00405f 	cmp	x2, x0, lsl #16
    5b2c:	54000662 	b.cs	5bf8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5b30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5b34:	d350fc43 	lsr	x3, x2, #16
    5b38:	910003fd 	mov	x29, sp
    5b3c:	8b030863 	add	x3, x3, x3, lsl #2
    5b40:	f949fc84 	ldr	x4, [x4, #5112]
    5b44:	d37df063 	lsl	x3, x3, #3
    5b48:	f9000bf3 	str	x19, [sp, #16]
    5b4c:	8b030080 	add	x0, x4, x3
    5b50:	f9401013 	ldr	x19, [x0, #32]
    5b54:	b40002b3 	cbz	x19, 5ba8 <fwp_closure_drop+0x98>
    5b58:	38636883 	ldrb	w3, [x4, x3]
    5b5c:	7100087f 	cmp	w3, #0x2
    5b60:	54000420 	b.eq	5be4 <fwp_closure_drop+0xd4>  // b.none
    5b64:	7100047f 	cmp	w3, #0x1
    5b68:	54000201 	b.ne	5ba8 <fwp_closure_drop+0x98>  // b.any
    5b6c:	29430003 	ldp	w3, w0, [x0, #24]
    5b70:	92403c42 	and	x2, x2, #0xffff
    5b74:	9b037c42 	mul	x2, x2, x3
    5b78:	d360fc42 	lsr	x2, x2, #32
    5b7c:	eb00005f 	cmp	x2, x0
    5b80:	54000142 	b.cs	5ba8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5b84:	8b020273 	add	x19, x19, x2
    5b88:	39400260 	ldrb	w0, [x19]
    5b8c:	340000e0 	cbz	w0, 5ba8 <fwp_closure_drop+0x98>
    5b90:	7100041f 	cmp	w0, #0x1
    5b94:	54000100 	b.eq	5bb4 <fwp_closure_drop+0xa4>  // b.none
    5b98:	7103fc1f 	cmp	w0, #0xff
    5b9c:	54000300 	b.eq	5bfc <fwp_closure_drop+0xec>  // b.none
    5ba0:	51000400 	sub	w0, w0, #0x1
    5ba4:	39000260 	strb	w0, [x19]
    5ba8:	f9400bf3 	ldr	x19, [sp, #16]
    5bac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5bb0:	d65f03c0 	ret
    5bb4:	d53bd040 	mrs	x0, tpidr_el0
    5bb8:	91400000 	add	x0, x0, #0x0, lsl #12
    5bbc:	91004000 	add	x0, x0, #0x10
    5bc0:	f9400000 	ldr	x0, [x0]
    5bc4:	b4000080 	cbz	x0, 5bd4 <fwp_closure_drop+0xc4>
    5bc8:	f9400bf3 	ldr	x19, [sp, #16]
    5bcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5bd0:	17fff685 	b	35e4 <fwp_closure_drop_push>
    5bd4:	f9400bf3 	ldr	x19, [sp, #16]
    5bd8:	aa0103e0 	mov	x0, x1
    5bdc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5be0:	17fff6f0 	b	37a0 <fwp_closure_drop.part.0>
    5be4:	72003c5f 	tst	w2, #0xffff
    5be8:	54fffd00 	b.eq	5b88 <fwp_closure_drop+0x78>  // b.none
    5bec:	f9400bf3 	ldr	x19, [sp, #16]
    5bf0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5bf4:	d65f03c0 	ret
    5bf8:	d65f03c0 	ret
    5bfc:	ca534660 	eor	x0, x19, x19, lsr #17
    5c00:	911580a5 	add	x5, x5, #0x560
    5c04:	ca402400 	eor	x0, x0, x0, lsr #9
    5c08:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5c0c:	f94a2400 	ldr	x0, [x0, #5192]
    5c10:	b5000080 	cbnz	x0, 5c20 <fwp_closure_drop+0x110>
    5c14:	14000010 	b	5c54 <fwp_closure_drop+0x144>
    5c18:	f9400800 	ldr	x0, [x0, #16]
    5c1c:	b40001c0 	cbz	x0, 5c54 <fwp_closure_drop+0x144>
    5c20:	f9400001 	ldr	x1, [x0]
    5c24:	eb13003f 	cmp	x1, x19
    5c28:	54ffff81 	b.ne	5c18 <fwp_closure_drop+0x108>  // b.any
    5c2c:	f9400401 	ldr	x1, [x0, #8]
    5c30:	d1000421 	sub	x1, x1, #0x1
    5c34:	f9000401 	str	x1, [x0, #8]
    5c38:	f103f83f 	cmp	x1, #0xfe
    5c3c:	54fffb61 	b.ne	5ba8 <fwp_closure_drop+0x98>  // b.any
    5c40:	aa1303e0 	mov	x0, x19
    5c44:	97fffa5f 	bl	45c0 <fwp_rc_forget_slot>
    5c48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c4c:	39000260 	strb	w0, [x19]
    5c50:	17ffffd6 	b	5ba8 <fwp_closure_drop+0x98>
    5c54:	f0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    5c58:	913a6000 	add	x0, x0, #0xe98
    5c5c:	97fff649 	bl	3580 <fwp_trap>

0000000000005c60 <fwp_owned_tape_release>:
    5c60:	b4000940 	cbz	x0, 5d88 <fwp_owned_tape_release+0x128>
    5c64:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c68:	910003fd 	mov	x29, sp
    5c6c:	a90153f3 	stp	x19, x20, [sp, #16]
    5c70:	aa0003f3 	mov	x19, x0
    5c74:	f9400000 	ldr	x0, [x0]
    5c78:	b4000060 	cbz	x0, 5c84 <fwp_owned_tape_release+0x24>
    5c7c:	f9400661 	ldr	x1, [x19, #8]
    5c80:	f9000401 	str	x1, [x0, #8]
    5c84:	f9400661 	ldr	x1, [x19, #8]
    5c88:	b4000041 	cbz	x1, 5c90 <fwp_owned_tape_release+0x30>
    5c8c:	f9000020 	str	x0, [x1]
    5c90:	f9400a60 	ldr	x0, [x19, #16]
    5c94:	f9403401 	ldr	x1, [x0, #104]
    5c98:	b40005c1 	cbz	x1, 5d50 <fwp_owned_tape_release+0xf0>
    5c9c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5ca0:	eb00005f 	cmp	x2, x0
    5ca4:	540002ed 	b.le	5d00 <fwp_owned_tape_release+0xa0>
    5ca8:	d2800014 	mov	x20, #0x0                   	// #0
    5cac:	f90013f5 	str	x21, [sp, #32]
    5cb0:	d2800015 	mov	x21, #0x0                   	// #0
    5cb4:	d503201f 	nop
    5cb8:	f9402260 	ldr	x0, [x19, #64]
    5cbc:	910006b5 	add	x21, x21, #0x1
    5cc0:	f8746800 	ldr	x0, [x0, x20]
    5cc4:	d63f0020 	blr	x1
    5cc8:	f9402260 	ldr	x0, [x19, #64]
    5ccc:	f9400a61 	ldr	x1, [x19, #16]
    5cd0:	8b140000 	add	x0, x0, x20
    5cd4:	91004294 	add	x20, x20, #0x10
    5cd8:	f9400400 	ldr	x0, [x0, #8]
    5cdc:	f9403421 	ldr	x1, [x1, #104]
    5ce0:	d63f0020 	blr	x1
    5ce4:	a9450261 	ldp	x1, x0, [x19, #80]
    5ce8:	cb010000 	sub	x0, x0, x1
    5cec:	eb15001f 	cmp	x0, x21
    5cf0:	f9400a60 	ldr	x0, [x19, #16]
    5cf4:	f9403401 	ldr	x1, [x0, #104]
    5cf8:	54fffe0c 	b.gt	5cb8 <fwp_owned_tape_release+0x58>
    5cfc:	f94013f5 	ldr	x21, [sp, #32]
    5d00:	f9403663 	ldr	x3, [x19, #104]
    5d04:	f9401262 	ldr	x2, [x19, #32]
    5d08:	f100007f 	cmp	x3, #0x0
    5d0c:	540001ed 	b.le	5d48 <fwp_owned_tape_release+0xe8>
    5d10:	d2800014 	mov	x20, #0x0                   	// #0
    5d14:	d503201f 	nop
    5d18:	f9402660 	ldr	x0, [x19, #72]
    5d1c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5d20:	eb02001f 	cmp	x0, x2
    5d24:	540000c0 	b.eq	5d3c <fwp_owned_tape_release+0xdc>  // b.none
    5d28:	d63f0020 	blr	x1
    5d2c:	f9400a60 	ldr	x0, [x19, #16]
    5d30:	f9401262 	ldr	x2, [x19, #32]
    5d34:	f9403663 	ldr	x3, [x19, #104]
    5d38:	f9403401 	ldr	x1, [x0, #104]
    5d3c:	91000694 	add	x20, x20, #0x1
    5d40:	eb14007f 	cmp	x3, x20
    5d44:	54fffeac 	b.gt	5d18 <fwp_owned_tape_release+0xb8>
    5d48:	aa0203e0 	mov	x0, x2
    5d4c:	d63f0020 	blr	x1
    5d50:	f9401660 	ldr	x0, [x19, #40]
    5d54:	97ffff6f 	bl	5b10 <fwp_closure_drop>
    5d58:	f9401a60 	ldr	x0, [x19, #48]
    5d5c:	97ffff6d 	bl	5b10 <fwp_closure_drop>
    5d60:	f9401e60 	ldr	x0, [x19, #56]
    5d64:	97ffff6b 	bl	5b10 <fwp_closure_drop>
    5d68:	f9402260 	ldr	x0, [x19, #64]
    5d6c:	97fffab5 	bl	4840 <fwp_mem_free>
    5d70:	f9402660 	ldr	x0, [x19, #72]
    5d74:	97fffab3 	bl	4840 <fwp_mem_free>
    5d78:	aa1303e0 	mov	x0, x19
    5d7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d84:	17fffaaf 	b	4840 <fwp_mem_free>
    5d88:	d65f03c0 	ret
    5d8c:	d503201f 	nop

0000000000005d90 <fwp_tape_finish>:
    5d90:	d10203ff 	sub	sp, sp, #0x80
    5d94:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5d98:	f947f421 	ldr	x1, [x1, #4072]
    5d9c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5da0:	910103fd 	add	x29, sp, #0x40
    5da4:	a90553f3 	stp	x19, x20, [sp, #80]
    5da8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5dac:	a90763f7 	stp	x23, x24, [sp, #112]
    5db0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5db4:	9100c316 	add	x22, x24, #0x30
    5db8:	f9400022 	ldr	x2, [x1]
    5dbc:	f9001fe2 	str	x2, [sp, #56]
    5dc0:	d2800002 	mov	x2, #0x0                   	// #0
    5dc4:	9101a2c0 	add	x0, x22, #0x68
    5dc8:	97fff54e 	bl	3300 <fwp_tape_buffers_dispose>
    5dcc:	f90052df 	str	xzr, [x22, #160]
    5dd0:	f94022c0 	ldr	x0, [x22, #64]
    5dd4:	f100001f 	cmp	x0, #0x0
    5dd8:	5400030d 	b.le	5e38 <fwp_tape_finish+0xa8>
    5ddc:	910003f7 	mov	x23, sp
    5de0:	d2800015 	mov	x21, #0x0                   	// #0
    5de4:	d2800014 	mov	x20, #0x0                   	// #0
    5de8:	f94002d3 	ldr	x19, [x22]
    5dec:	91000694 	add	x20, x20, #0x1
    5df0:	8b150273 	add	x19, x19, x21
    5df4:	9101a2b5 	add	x21, x21, #0x68
    5df8:	aa1303e0 	mov	x0, x19
    5dfc:	97fff465 	bl	2f90 <fwp_tape_unlink_scope>
    5e00:	aa1703e0 	mov	x0, x23
    5e04:	f9401261 	ldr	x1, [x19, #32]
    5e08:	f90003e1 	str	x1, [sp]
    5e0c:	f9401a62 	ldr	x2, [x19, #48]
    5e10:	f9000be2 	str	x2, [sp, #16]
    5e14:	f9402261 	ldr	x1, [x19, #64]
    5e18:	f90013e1 	str	x1, [sp, #32]
    5e1c:	97fff539 	bl	3300 <fwp_tape_buffers_dispose>
    5e20:	f9403260 	ldr	x0, [x19, #96]
    5e24:	97ffff8f 	bl	5c60 <fwp_owned_tape_release>
    5e28:	f900327f 	str	xzr, [x19, #96]
    5e2c:	f94022c0 	ldr	x0, [x22, #64]
    5e30:	eb14001f 	cmp	x0, x20
    5e34:	54fffdac 	b.gt	5de8 <fwp_tape_finish+0x58>
    5e38:	f9401b00 	ldr	x0, [x24, #48]
    5e3c:	9100c313 	add	x19, x24, #0x30
    5e40:	97fff2c0 	bl	2940 <free@plt>
    5e44:	f9001b1f 	str	xzr, [x24, #48]
    5e48:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5e4c:	f947f400 	ldr	x0, [x0, #4072]
    5e50:	f900227f 	str	xzr, [x19, #64]
    5e54:	a90b7e7f 	stp	xzr, xzr, [x19, #176]
    5e58:	f9401fe2 	ldr	x2, [sp, #56]
    5e5c:	f9400001 	ldr	x1, [x0]
    5e60:	eb010042 	subs	x2, x2, x1
    5e64:	d2800001 	mov	x1, #0x0                   	// #0
    5e68:	540000e1 	b.ne	5e84 <fwp_tape_finish+0xf4>  // b.any
    5e6c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5e70:	a94553f3 	ldp	x19, x20, [sp, #80]
    5e74:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5e78:	a94763f7 	ldp	x23, x24, [sp, #112]
    5e7c:	910203ff 	add	sp, sp, #0x80
    5e80:	d65f03c0 	ret
    5e84:	97fff27f 	bl	2880 <__stack_chk_fail@plt>
    5e88:	d503201f 	nop
    5e8c:	d503201f 	nop

0000000000005e90 <fwp_tape_scope_release>:
    5e90:	d10243ff 	sub	sp, sp, #0x90
    5e94:	a9047bfd 	stp	x29, x30, [sp, #64]
    5e98:	910103fd 	add	x29, sp, #0x40
    5e9c:	a90553f3 	stp	x19, x20, [sp, #80]
    5ea0:	aa0003f4 	mov	x20, x0
    5ea4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ea8:	f947f400 	ldr	x0, [x0, #4072]
    5eac:	b9400285 	ldr	w5, [x20]
    5eb0:	f9400001 	ldr	x1, [x0]
    5eb4:	f9001fe1 	str	x1, [sp, #56]
    5eb8:	d2800001 	mov	x1, #0x0                   	// #0
    5ebc:	37f806c5 	tbnz	w5, #31, 5f94 <fwp_tape_scope_release+0x104>
    5ec0:	a90763f7 	stp	x23, x24, [sp, #112]
    5ec4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5ec8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5ecc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5ed0:	f00000d3 	adrp	x19, 20000 <__data_start>
    5ed4:	910003f7 	mov	x23, sp
    5ed8:	9100c273 	add	x19, x19, #0x30
    5edc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5ee0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5ee4:	52800d16 	mov	w22, #0x68                  	// #104
    5ee8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5eec:	f90043f9 	str	x25, [sp, #128]
    5ef0:	14000006 	b	5f08 <fwp_tape_scope_release+0x78>
    5ef4:	97fff503 	bl	3300 <fwp_tape_buffers_dispose>
    5ef8:	aa1903e0 	mov	x0, x25
    5efc:	97ffff59 	bl	5c60 <fwp_owned_tape_release>
    5f00:	b9400285 	ldr	w5, [x20]
    5f04:	37f80425 	tbnz	w5, #31, 5f88 <fwp_tape_scope_release+0xf8>
    5f08:	f9400266 	ldr	x6, [x19]
    5f0c:	9b367ca5 	smull	x5, w5, w22
    5f10:	8b0500c0 	add	x0, x6, x5
    5f14:	97fff41f 	bl	2f90 <fwp_tape_unlink_scope>
    5f18:	ad410001 	ldp	q1, q0, [x0, #32]
    5f1c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5f20:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5f24:	f9400c03 	ldr	x3, [x0, #24]
    5f28:	ad0003e1 	stp	q1, q0, [sp]
    5f2c:	b86568c1 	ldr	w1, [x6, x5]
    5f30:	a9440804 	ldp	x4, x2, [x0, #64]
    5f34:	b900041f 	str	wzr, [x0, #4]
    5f38:	f9403019 	ldr	x25, [x0, #96]
    5f3c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5f40:	f9000c1f 	str	xzr, [x0, #24]
    5f44:	a9020fe4 	stp	x4, x3, [sp, #32]
    5f48:	f9001be2 	str	x2, [sp, #48]
    5f4c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5f50:	f900301f 	str	xzr, [x0, #96]
    5f54:	6b15003f 	cmp	w1, w21
    5f58:	540000e8 	b.hi	5f74 <fwp_tape_scope_release+0xe4>  // b.pmore
    5f5c:	9343fca5 	asr	x5, x5, #3
    5f60:	f9405e60 	ldr	x0, [x19, #184]
    5f64:	9b187ca5 	mul	x5, x5, x24
    5f68:	eb0000bf 	cmp	x5, x0
    5f6c:	5400004a 	b.ge	5f74 <fwp_tape_scope_release+0xe4>  // b.tcont
    5f70:	f9005e65 	str	x5, [x19, #184]
    5f74:	aa1703e0 	mov	x0, x23
    5f78:	b5fffbf9 	cbnz	x25, 5ef4 <fwp_tape_scope_release+0x64>
    5f7c:	97fff875 	bl	4150 <fwp_tape_buffers_release>
    5f80:	b9400285 	ldr	w5, [x20]
    5f84:	36fffc25 	tbz	w5, #31, 5f08 <fwp_tape_scope_release+0x78>
    5f88:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5f8c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5f90:	f94043f9 	ldr	x25, [sp, #128]
    5f94:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5f98:	f947f400 	ldr	x0, [x0, #4072]
    5f9c:	f9401fe2 	ldr	x2, [sp, #56]
    5fa0:	f9400001 	ldr	x1, [x0]
    5fa4:	eb010042 	subs	x2, x2, x1
    5fa8:	d2800001 	mov	x1, #0x0                   	// #0
    5fac:	540000a1 	b.ne	5fc0 <fwp_tape_scope_release+0x130>  // b.any
    5fb0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5fb4:	a94553f3 	ldp	x19, x20, [sp, #80]
    5fb8:	910243ff 	add	sp, sp, #0x90
    5fbc:	d65f03c0 	ret
    5fc0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5fc4:	a90763f7 	stp	x23, x24, [sp, #112]
    5fc8:	f90043f9 	str	x25, [sp, #128]
    5fcc:	97fff22d 	bl	2880 <__stack_chk_fail@plt>

0000000000005fd0 <fwp_drop4>:
    5fd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fd4:	910003fd 	mov	x29, sp
    5fd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    5fdc:	90000176 	adrp	x22, 31000 <fwp_root_context+0xc80>
    5fe0:	911582d5 	add	x21, x22, #0x560
    5fe4:	a90153f3 	stp	x19, x20, [sp, #16]
    5fe8:	aa0003f3 	mov	x19, x0
    5fec:	f949daa1 	ldr	x1, [x21, #5040]
    5ff0:	f949eea0 	ldr	x0, [x21, #5080]
    5ff4:	cb010261 	sub	x1, x19, x1
    5ff8:	eb00403f 	cmp	x1, x0, lsl #16
    5ffc:	54000382 	b.cs	606c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6000:	d350fc22 	lsr	x2, x1, #16
    6004:	f949fea3 	ldr	x3, [x21, #5112]
    6008:	8b020842 	add	x2, x2, x2, lsl #2
    600c:	d37df042 	lsl	x2, x2, #3
    6010:	8b020060 	add	x0, x3, x2
    6014:	f9401014 	ldr	x20, [x0, #32]
    6018:	b40002b4 	cbz	x20, 606c <fwp_drop4+0x9c>
    601c:	38626862 	ldrb	w2, [x3, x2]
    6020:	7100085f 	cmp	w2, #0x2
    6024:	540002c0 	b.eq	607c <fwp_drop4+0xac>  // b.none
    6028:	7100045f 	cmp	w2, #0x1
    602c:	54000201 	b.ne	606c <fwp_drop4+0x9c>  // b.any
    6030:	29430002 	ldp	w2, w0, [x0, #24]
    6034:	92403c21 	and	x1, x1, #0xffff
    6038:	9b027c21 	mul	x1, x1, x2
    603c:	d360fc21 	lsr	x1, x1, #32
    6040:	eb00003f 	cmp	x1, x0
    6044:	54000142 	b.cs	606c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6048:	8b010294 	add	x20, x20, x1
    604c:	39400280 	ldrb	w0, [x20]
    6050:	340000e0 	cbz	w0, 606c <fwp_drop4+0x9c>
    6054:	7100041f 	cmp	w0, #0x1
    6058:	540001e0 	b.eq	6094 <fwp_drop4+0xc4>  // b.none
    605c:	7103fc1f 	cmp	w0, #0xff
    6060:	540007c0 	b.eq	6158 <fwp_drop4+0x188>  // b.none
    6064:	51000400 	sub	w0, w0, #0x1
    6068:	39000280 	strb	w0, [x20]
    606c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6074:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6078:	d65f03c0 	ret
    607c:	72003c3f 	tst	w1, #0xffff
    6080:	54fffe60 	b.eq	604c <fwp_drop4+0x7c>  // b.none
    6084:	a94153f3 	ldp	x19, x20, [sp, #16]
    6088:	a9425bf5 	ldp	x21, x22, [sp, #32]
    608c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6090:	d65f03c0 	ret
    6094:	911582c2 	add	x2, x22, #0x560
    6098:	f9400660 	ldr	x0, [x19, #8]
    609c:	f949d841 	ldr	x1, [x2, #5040]
    60a0:	f949ec42 	ldr	x2, [x2, #5080]
    60a4:	cb010001 	sub	x1, x0, x1
    60a8:	eb02403f 	cmp	x1, x2, lsl #16
    60ac:	54000362 	b.cs	6118 <fwp_drop4+0x148>  // b.hs, b.nlast
    60b0:	d350fc22 	lsr	x2, x1, #16
    60b4:	8b020842 	add	x2, x2, x2, lsl #2
    60b8:	d37df042 	lsl	x2, x2, #3
    60bc:	8b020064 	add	x4, x3, x2
    60c0:	f9401094 	ldr	x20, [x4, #32]
    60c4:	b40002b4 	cbz	x20, 6118 <fwp_drop4+0x148>
    60c8:	38626862 	ldrb	w2, [x3, x2]
    60cc:	7100085f 	cmp	w2, #0x2
    60d0:	540003e0 	b.eq	614c <fwp_drop4+0x17c>  // b.none
    60d4:	7100045f 	cmp	w2, #0x1
    60d8:	54000201 	b.ne	6118 <fwp_drop4+0x148>  // b.any
    60dc:	29430883 	ldp	w3, w2, [x4, #24]
    60e0:	92403c21 	and	x1, x1, #0xffff
    60e4:	9b037c21 	mul	x1, x1, x3
    60e8:	d360fc21 	lsr	x1, x1, #32
    60ec:	eb02003f 	cmp	x1, x2
    60f0:	54000142 	b.cs	6118 <fwp_drop4+0x148>  // b.hs, b.nlast
    60f4:	8b010294 	add	x20, x20, x1
    60f8:	39400281 	ldrb	w1, [x20]
    60fc:	340000e1 	cbz	w1, 6118 <fwp_drop4+0x148>
    6100:	7100043f 	cmp	w1, #0x1
    6104:	54000200 	b.eq	6144 <fwp_drop4+0x174>  // b.none
    6108:	7103fc3f 	cmp	w1, #0xff
    610c:	54000580 	b.eq	61bc <fwp_drop4+0x1ec>  // b.none
    6110:	51000421 	sub	w1, w1, #0x1
    6114:	39000281 	strb	w1, [x20]
    6118:	f9400a74 	ldr	x20, [x19, #16]
    611c:	aa1303e0 	mov	x0, x19
    6120:	97fffcfd 	bl	5514 <fwp_rc_free_arr>
    6124:	911582c0 	add	x0, x22, #0x560
    6128:	f949d801 	ldr	x1, [x0, #5040]
    612c:	f949ec00 	ldr	x0, [x0, #5080]
    6130:	cb010281 	sub	x1, x20, x1
    6134:	eb00403f 	cmp	x1, x0, lsl #16
    6138:	54fff9a2 	b.cs	606c <fwp_drop4+0x9c>  // b.hs, b.nlast
    613c:	aa1403f3 	mov	x19, x20
    6140:	17ffffb0 	b	6000 <fwp_drop4+0x30>
    6144:	97fffcf4 	bl	5514 <fwp_rc_free_arr>
    6148:	17fffff4 	b	6118 <fwp_drop4+0x148>
    614c:	72003c3f 	tst	w1, #0xffff
    6150:	54fffe41 	b.ne	6118 <fwp_drop4+0x148>  // b.any
    6154:	17ffffe9 	b	60f8 <fwp_drop4+0x128>
    6158:	ca544681 	eor	x1, x20, x20, lsr #17
    615c:	911582c0 	add	x0, x22, #0x560
    6160:	ca412421 	eor	x1, x1, x1, lsr #9
    6164:	8b210c01 	add	x1, x0, w1, uxtb #3
    6168:	f94a2420 	ldr	x0, [x1, #5192]
    616c:	b5000080 	cbnz	x0, 617c <fwp_drop4+0x1ac>
    6170:	14000010 	b	61b0 <fwp_drop4+0x1e0>
    6174:	f9400800 	ldr	x0, [x0, #16]
    6178:	b40001c0 	cbz	x0, 61b0 <fwp_drop4+0x1e0>
    617c:	f9400001 	ldr	x1, [x0]
    6180:	eb14003f 	cmp	x1, x20
    6184:	54ffff81 	b.ne	6174 <fwp_drop4+0x1a4>  // b.any
    6188:	f9400401 	ldr	x1, [x0, #8]
    618c:	d1000421 	sub	x1, x1, #0x1
    6190:	f9000401 	str	x1, [x0, #8]
    6194:	f103f83f 	cmp	x1, #0xfe
    6198:	54fff6a1 	b.ne	606c <fwp_drop4+0x9c>  // b.any
    619c:	aa1403e0 	mov	x0, x20
    61a0:	97fff908 	bl	45c0 <fwp_rc_forget_slot>
    61a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    61a8:	39000280 	strb	w0, [x20]
    61ac:	17ffffb0 	b	606c <fwp_drop4+0x9c>
    61b0:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    61b4:	913a6000 	add	x0, x0, #0xe98
    61b8:	97fff4f2 	bl	3580 <fwp_trap>
    61bc:	ca544680 	eor	x0, x20, x20, lsr #17
    61c0:	911582c1 	add	x1, x22, #0x560
    61c4:	ca402400 	eor	x0, x0, x0, lsr #9
    61c8:	8b200c20 	add	x0, x1, w0, uxtb #3
    61cc:	f94a2400 	ldr	x0, [x0, #5192]
    61d0:	b5000080 	cbnz	x0, 61e0 <fwp_drop4+0x210>
    61d4:	17fffff7 	b	61b0 <fwp_drop4+0x1e0>
    61d8:	f9400800 	ldr	x0, [x0, #16]
    61dc:	b4fffea0 	cbz	x0, 61b0 <fwp_drop4+0x1e0>
    61e0:	f9400001 	ldr	x1, [x0]
    61e4:	eb14003f 	cmp	x1, x20
    61e8:	54ffff81 	b.ne	61d8 <fwp_drop4+0x208>  // b.any
    61ec:	f9400401 	ldr	x1, [x0, #8]
    61f0:	d1000421 	sub	x1, x1, #0x1
    61f4:	f9000401 	str	x1, [x0, #8]
    61f8:	f103f83f 	cmp	x1, #0xfe
    61fc:	54fff8e1 	b.ne	6118 <fwp_drop4+0x148>  // b.any
    6200:	aa1403e0 	mov	x0, x20
    6204:	97fff8ef 	bl	45c0 <fwp_rc_forget_slot>
    6208:	12800020 	mov	w0, #0xfffffffe            	// #-2
    620c:	39000280 	strb	w0, [x20]
    6210:	17ffffc2 	b	6118 <fwp_drop4+0x148>

0000000000006214 <fwp_arg_drop37>:
    6214:	7100003f 	cmp	w1, #0x0
    6218:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    621c:	54000041 	b.ne	6224 <fwp_arg_drop37+0x10>  // b.any
    6220:	d65f03c0 	ret
    6224:	f9400000 	ldr	x0, [x0]
    6228:	17ffff6a 	b	5fd0 <fwp_drop4>
    622c:	d503201f 	nop

0000000000006230 <fwp_task_dispose>:
    6230:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6234:	910003fd 	mov	x29, sp
    6238:	f9000bf3 	str	x19, [sp, #16]
    623c:	aa0003f3 	mov	x19, x0
    6240:	39414000 	ldrb	w0, [x0, #80]
    6244:	36000720 	tbz	w0, #0, 6328 <fwp_task_dispose+0xf8>
    6248:	f9400a60 	ldr	x0, [x19, #16]
    624c:	b50006e0 	cbnz	x0, 6328 <fwp_task_dispose+0xf8>
    6250:	a9478660 	ldp	x0, x1, [x19, #120]
    6254:	39014e7f 	strb	wzr, [x19, #83]
    6258:	f9003e7f 	str	xzr, [x19, #120]
    625c:	f100003f 	cmp	x1, #0x0
    6260:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6264:	54000040 	b.eq	626c <fwp_task_dispose+0x3c>  // b.none
    6268:	d63f0020 	blr	x1
    626c:	f9405660 	ldr	x0, [x19, #168]
    6270:	97fff974 	bl	4840 <fwp_mem_free>
    6274:	f900567f 	str	xzr, [x19, #168]
    6278:	b9405e60 	ldr	w0, [x19, #92]
    627c:	7100041f 	cmp	w0, #0x1
    6280:	54000420 	b.eq	6304 <fwp_task_dispose+0xd4>  // b.none
    6284:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc80>
    6288:	91158042 	add	x2, x2, #0x560
    628c:	f949d840 	ldr	x0, [x2, #5040]
    6290:	f949ec41 	ldr	x1, [x2, #5080]
    6294:	cb000260 	sub	x0, x19, x0
    6298:	eb01401f 	cmp	x0, x1, lsl #16
    629c:	540002e2 	b.cs	62f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    62a0:	d350fc01 	lsr	x1, x0, #16
    62a4:	f949fc44 	ldr	x4, [x2, #5112]
    62a8:	8b010821 	add	x1, x1, x1, lsl #2
    62ac:	d37df021 	lsl	x1, x1, #3
    62b0:	8b010083 	add	x3, x4, x1
    62b4:	f9401062 	ldr	x2, [x3, #32]
    62b8:	b4000202 	cbz	x2, 62f8 <fwp_task_dispose+0xc8>
    62bc:	38616881 	ldrb	w1, [x4, x1]
    62c0:	7100083f 	cmp	w1, #0x2
    62c4:	54000280 	b.eq	6314 <fwp_task_dispose+0xe4>  // b.none
    62c8:	7100043f 	cmp	w1, #0x1
    62cc:	54000161 	b.ne	62f8 <fwp_task_dispose+0xc8>  // b.any
    62d0:	29430464 	ldp	w4, w1, [x3, #24]
    62d4:	92403c00 	and	x0, x0, #0xffff
    62d8:	9b047c00 	mul	x0, x0, x4
    62dc:	d360fc00 	lsr	x0, x0, #32
    62e0:	eb01001f 	cmp	x0, x1
    62e4:	540000a2 	b.cs	62f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    62e8:	8b000042 	add	x2, x2, x0
    62ec:	39400040 	ldrb	w0, [x2]
    62f0:	7100041f 	cmp	w0, #0x1
    62f4:	54000080 	b.eq	6304 <fwp_task_dispose+0xd4>  // b.none
    62f8:	f9400bf3 	ldr	x19, [sp, #16]
    62fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6300:	d65f03c0 	ret
    6304:	aa1303e0 	mov	x0, x19
    6308:	f9400bf3 	ldr	x19, [sp, #16]
    630c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6310:	17fff94c 	b	4840 <fwp_mem_free>
    6314:	72003c1f 	tst	w0, #0xffff
    6318:	54fffea0 	b.eq	62ec <fwp_task_dispose+0xbc>  // b.none
    631c:	f9400bf3 	ldr	x19, [sp, #16]
    6320:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6324:	d65f03c0 	ret
    6328:	97fff16a 	bl	28d0 <abort@plt>
    632c:	d503201f 	nop

0000000000006330 <fwp_free_zombie>:
    6330:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6334:	910003fd 	mov	x29, sp
    6338:	a90153f3 	stp	x19, x20, [sp, #16]
    633c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6340:	9100c281 	add	x1, x20, #0x30
    6344:	f9406033 	ldr	x19, [x1, #192]
    6348:	b4000333 	cbz	x19, 63ac <fwp_free_zombie+0x7c>
    634c:	f9400820 	ldr	x0, [x1, #16]
    6350:	eb00027f 	cmp	x19, x0
    6354:	540002c0 	b.eq	63ac <fwp_free_zombie+0x7c>  // b.none
    6358:	b940c822 	ldr	w2, [x1, #200]
    635c:	f9400a60 	ldr	x0, [x19, #16]
    6360:	7100fc5f 	cmp	w2, #0x3f
    6364:	5400078c 	b.gt	6454 <fwp_free_zombie+0x124>
    6368:	91034023 	add	x3, x1, #0xd0
    636c:	11000444 	add	w4, w2, #0x1
    6370:	b900c824 	str	w4, [x1, #200]
    6374:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6378:	f822d860 	str	x0, [x3, w2, sxtw #3]
    637c:	a9530261 	ldp	x1, x0, [x19, #304]
    6380:	b4000741 	cbz	x1, 6468 <fwp_free_zombie+0x138>
    6384:	f9009c20 	str	x0, [x1, #312]
    6388:	b4000040 	cbz	x0, 6390 <fwp_free_zombie+0x60>
    638c:	f9009801 	str	x1, [x0, #304]
    6390:	9100c294 	add	x20, x20, #0x30
    6394:	b9405e60 	ldr	w0, [x19, #92]
    6398:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    639c:	f900629f 	str	xzr, [x20, #192]
    63a0:	34000140 	cbz	w0, 63c8 <fwp_free_zombie+0x98>
    63a4:	7100041f 	cmp	w0, #0x1
    63a8:	54000080 	b.eq	63b8 <fwp_free_zombie+0x88>  // b.none
    63ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    63b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63b4:	d65f03c0 	ret
    63b8:	aa1303e0 	mov	x0, x19
    63bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    63c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63c4:	17ffff9b 	b	6230 <fwp_task_dispose>
    63c8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc80>
    63cc:	91158082 	add	x2, x4, #0x560
    63d0:	f949d841 	ldr	x1, [x2, #5040]
    63d4:	f949ec40 	ldr	x0, [x2, #5080]
    63d8:	cb010261 	sub	x1, x19, x1
    63dc:	eb00403f 	cmp	x1, x0, lsl #16
    63e0:	54fffe62 	b.cs	63ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    63e4:	d350fc20 	lsr	x0, x1, #16
    63e8:	f949fc43 	ldr	x3, [x2, #5112]
    63ec:	8b000800 	add	x0, x0, x0, lsl #2
    63f0:	d37df000 	lsl	x0, x0, #3
    63f4:	8b000062 	add	x2, x3, x0
    63f8:	f9401054 	ldr	x20, [x2, #32]
    63fc:	b4fffd94 	cbz	x20, 63ac <fwp_free_zombie+0x7c>
    6400:	38606860 	ldrb	w0, [x3, x0]
    6404:	7100081f 	cmp	w0, #0x2
    6408:	54000360 	b.eq	6474 <fwp_free_zombie+0x144>  // b.none
    640c:	7100041f 	cmp	w0, #0x1
    6410:	54fffce1 	b.ne	63ac <fwp_free_zombie+0x7c>  // b.any
    6414:	29430043 	ldp	w3, w0, [x2, #24]
    6418:	92403c21 	and	x1, x1, #0xffff
    641c:	9b037c21 	mul	x1, x1, x3
    6420:	d360fc21 	lsr	x1, x1, #32
    6424:	eb00003f 	cmp	x1, x0
    6428:	54fffc22 	b.cs	63ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    642c:	8b010294 	add	x20, x20, x1
    6430:	39400280 	ldrb	w0, [x20]
    6434:	34fffbc0 	cbz	w0, 63ac <fwp_free_zombie+0x7c>
    6438:	7100041f 	cmp	w0, #0x1
    643c:	54fffbe0 	b.eq	63b8 <fwp_free_zombie+0x88>  // b.none
    6440:	7103fc1f 	cmp	w0, #0xff
    6444:	540001e0 	b.eq	6480 <fwp_free_zombie+0x150>  // b.none
    6448:	51000400 	sub	w0, w0, #0x1
    644c:	39000280 	strb	w0, [x20]
    6450:	17ffffd7 	b	63ac <fwp_free_zombie+0x7c>
    6454:	f9400e61 	ldr	x1, [x19, #24]
    6458:	97fff152 	bl	29a0 <munmap@plt>
    645c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6460:	a9530261 	ldp	x1, x0, [x19, #304]
    6464:	b5fff901 	cbnz	x1, 6384 <fwp_free_zombie+0x54>
    6468:	9100c282 	add	x2, x20, #0x30
    646c:	f9016840 	str	x0, [x2, #720]
    6470:	17ffffc6 	b	6388 <fwp_free_zombie+0x58>
    6474:	72003c3f 	tst	w1, #0xffff
    6478:	54fff9a1 	b.ne	63ac <fwp_free_zombie+0x7c>  // b.any
    647c:	17ffffed 	b	6430 <fwp_free_zombie+0x100>
    6480:	ca544680 	eor	x0, x20, x20, lsr #17
    6484:	91158084 	add	x4, x4, #0x560
    6488:	ca402400 	eor	x0, x0, x0, lsr #9
    648c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6490:	f94a2400 	ldr	x0, [x0, #5192]
    6494:	b5000080 	cbnz	x0, 64a4 <fwp_free_zombie+0x174>
    6498:	14000010 	b	64d8 <fwp_free_zombie+0x1a8>
    649c:	f9400800 	ldr	x0, [x0, #16]
    64a0:	b40001c0 	cbz	x0, 64d8 <fwp_free_zombie+0x1a8>
    64a4:	f9400001 	ldr	x1, [x0]
    64a8:	eb14003f 	cmp	x1, x20
    64ac:	54ffff81 	b.ne	649c <fwp_free_zombie+0x16c>  // b.any
    64b0:	f9400401 	ldr	x1, [x0, #8]
    64b4:	d1000421 	sub	x1, x1, #0x1
    64b8:	f9000401 	str	x1, [x0, #8]
    64bc:	f103f83f 	cmp	x1, #0xfe
    64c0:	54fff761 	b.ne	63ac <fwp_free_zombie+0x7c>  // b.any
    64c4:	aa1403e0 	mov	x0, x20
    64c8:	97fff83e 	bl	45c0 <fwp_rc_forget_slot>
    64cc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64d0:	39000280 	strb	w0, [x20]
    64d4:	17ffffb6 	b	63ac <fwp_free_zombie+0x7c>
    64d8:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    64dc:	913a6000 	add	x0, x0, #0xe98
    64e0:	97fff428 	bl	3580 <fwp_trap>

00000000000064e4 <fwp_block>:
    64e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64e8:	910003fd 	mov	x29, sp
    64ec:	a90153f3 	stp	x19, x20, [sp, #16]
    64f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    64f4:	9100c274 	add	x20, x19, #0x30
    64f8:	f9401a82 	ldr	x2, [x20, #48]
    64fc:	b4000622 	cbz	x2, 65c0 <fwp_block+0xdc>
    6500:	9100c261 	add	x1, x19, #0x30
    6504:	f9408040 	ldr	x0, [x2, #256]
    6508:	f9001820 	str	x0, [x1, #48]
    650c:	b4000680 	cbz	x0, 65dc <fwp_block+0xf8>
    6510:	9100c263 	add	x3, x19, #0x30
    6514:	3901505f 	strb	wzr, [x2, #84]
    6518:	f9400864 	ldr	x4, [x3, #16]
    651c:	eb02009f 	cmp	x4, x2
    6520:	54000440 	b.eq	65a8 <fwp_block+0xc4>  // b.none
    6524:	f9416c65 	ldr	x5, [x3, #728]
    6528:	f9000862 	str	x2, [x3, #16]
    652c:	f9400441 	ldr	x1, [x2, #8]
    6530:	f9004885 	str	x5, [x4, #144]
    6534:	f9417065 	ldr	x5, [x3, #736]
    6538:	f9004c85 	str	x5, [x4, #152]
    653c:	f9417465 	ldr	x5, [x3, #744]
    6540:	f9005085 	str	x5, [x4, #160]
    6544:	f9417865 	ldr	x5, [x3, #752]
    6548:	f9005485 	str	x5, [x4, #168]
    654c:	f9417c65 	ldr	x5, [x3, #760]
    6550:	f9005885 	str	x5, [x4, #176]
    6554:	f9418065 	ldr	x5, [x3, #768]
    6558:	f9005c85 	str	x5, [x4, #184]
    655c:	f9418465 	ldr	x5, [x3, #776]
    6560:	f9006085 	str	x5, [x4, #192]
    6564:	f9400480 	ldr	x0, [x4, #8]
    6568:	f9404844 	ldr	x4, [x2, #144]
    656c:	f9016c64 	str	x4, [x3, #728]
    6570:	f9404c44 	ldr	x4, [x2, #152]
    6574:	f9017064 	str	x4, [x3, #736]
    6578:	f9405044 	ldr	x4, [x2, #160]
    657c:	f9017464 	str	x4, [x3, #744]
    6580:	f9405444 	ldr	x4, [x2, #168]
    6584:	f9017864 	str	x4, [x3, #752]
    6588:	f9405844 	ldr	x4, [x2, #176]
    658c:	f9017c64 	str	x4, [x3, #760]
    6590:	a94b8844 	ldp	x4, x2, [x2, #184]
    6594:	f9018064 	str	x4, [x3, #768]
    6598:	f9018462 	str	x2, [x3, #776]
    659c:	97fff0d1 	bl	28e0 <swapcontext@plt>
    65a0:	97ffff64 	bl	6330 <fwp_free_zombie>
    65a4:	d503201f 	nop
    65a8:	9100c260 	add	x0, x19, #0x30
    65ac:	b9431000 	ldr	w0, [x0, #784]
    65b0:	340001a0 	cbz	w0, 65e4 <fwp_block+0x100>
    65b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    65b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65bc:	d65f03c0 	ret
    65c0:	97fff72c 	bl	4270 <fwp_poll_events>
    65c4:	f9401a82 	ldr	x2, [x20, #48]
    65c8:	b4ffffc2 	cbz	x2, 65c0 <fwp_block+0xdc>
    65cc:	9100c261 	add	x1, x19, #0x30
    65d0:	f9408040 	ldr	x0, [x2, #256]
    65d4:	f9001820 	str	x0, [x1, #48]
    65d8:	b5fff9c0 	cbnz	x0, 6510 <fwp_block+0x2c>
    65dc:	f900143f 	str	xzr, [x1, #40]
    65e0:	17ffffcc 	b	6510 <fwp_block+0x2c>
    65e4:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    65e8:	913f2000 	add	x0, x0, #0xfc8
    65ec:	97fff109 	bl	2a10 <getenv@plt>
    65f0:	5284e202 	mov	w2, #0x2710                	// #10000
    65f4:	b4000060 	cbz	x0, 6600 <fwp_block+0x11c>
    65f8:	39400001 	ldrb	w1, [x0]
    65fc:	350000c1 	cbnz	w1, 6614 <fwp_block+0x130>
    6600:	9100c273 	add	x19, x19, #0x30
    6604:	b9031262 	str	w2, [x19, #784]
    6608:	a94153f3 	ldp	x19, x20, [sp, #16]
    660c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6610:	d65f03c0 	ret
    6614:	52800142 	mov	w2, #0xa                   	// #10
    6618:	d2800001 	mov	x1, #0x0                   	// #0
    661c:	97fff04d 	bl	2750 <strtoll@plt>
    6620:	d1000403 	sub	x3, x0, #0x1
    6624:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6628:	eb02007f 	cmp	x3, x2
    662c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6630:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6634:	17fffff3 	b	6600 <fwp_block+0x11c>
    6638:	d503201f 	nop
    663c:	d503201f 	nop

0000000000006640 <fwp_drop10>:
    6640:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6644:	910003fd 	mov	x29, sp
    6648:	a90153f3 	stp	x19, x20, [sp, #16]
    664c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc80>
    6650:	f90013f5 	str	x21, [sp, #32]
    6654:	91158275 	add	x21, x19, #0x560
    6658:	f949daa1 	ldr	x1, [x21, #5040]
    665c:	f949eea2 	ldr	x2, [x21, #5080]
    6660:	cb010001 	sub	x1, x0, x1
    6664:	eb02403f 	cmp	x1, x2, lsl #16
    6668:	54000382 	b.cs	66d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    666c:	d350fc22 	lsr	x2, x1, #16
    6670:	f949fea3 	ldr	x3, [x21, #5112]
    6674:	8b020842 	add	x2, x2, x2, lsl #2
    6678:	d37df042 	lsl	x2, x2, #3
    667c:	8b020064 	add	x4, x3, x2
    6680:	f9401094 	ldr	x20, [x4, #32]
    6684:	b40002b4 	cbz	x20, 66d8 <fwp_drop10+0x98>
    6688:	38626862 	ldrb	w2, [x3, x2]
    668c:	7100085f 	cmp	w2, #0x2
    6690:	540007a0 	b.eq	6784 <fwp_drop10+0x144>  // b.none
    6694:	7100045f 	cmp	w2, #0x1
    6698:	54000201 	b.ne	66d8 <fwp_drop10+0x98>  // b.any
    669c:	29430885 	ldp	w5, w2, [x4, #24]
    66a0:	92403c21 	and	x1, x1, #0xffff
    66a4:	9b057c21 	mul	x1, x1, x5
    66a8:	d360fc21 	lsr	x1, x1, #32
    66ac:	eb02003f 	cmp	x1, x2
    66b0:	54000142 	b.cs	66d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    66b4:	8b010294 	add	x20, x20, x1
    66b8:	39400281 	ldrb	w1, [x20]
    66bc:	340000e1 	cbz	w1, 66d8 <fwp_drop10+0x98>
    66c0:	7100043f 	cmp	w1, #0x1
    66c4:	54000120 	b.eq	66e8 <fwp_drop10+0xa8>  // b.none
    66c8:	7103fc3f 	cmp	w1, #0xff
    66cc:	540007c0 	b.eq	67c4 <fwp_drop10+0x184>  // b.none
    66d0:	51000421 	sub	w1, w1, #0x1
    66d4:	39000281 	strb	w1, [x20]
    66d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    66dc:	f94013f5 	ldr	x21, [sp, #32]
    66e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66e4:	d65f03c0 	ret
    66e8:	f9400001 	ldr	x1, [x0]
    66ec:	b7f80581 	tbnz	x1, #63, 679c <fwp_drop10+0x15c>
    66f0:	91158273 	add	x19, x19, #0x560
    66f4:	f949da61 	ldr	x1, [x19, #5040]
    66f8:	f949ee62 	ldr	x2, [x19, #5080]
    66fc:	cb010001 	sub	x1, x0, x1
    6700:	eb02403f 	cmp	x1, x2, lsl #16
    6704:	54fffea2 	b.cs	66d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6708:	d350fc22 	lsr	x2, x1, #16
    670c:	8b020842 	add	x2, x2, x2, lsl #2
    6710:	d37df042 	lsl	x2, x2, #3
    6714:	8b020065 	add	x5, x3, x2
    6718:	f94010a4 	ldr	x4, [x5, #32]
    671c:	b4fffde4 	cbz	x4, 66d8 <fwp_drop10+0x98>
    6720:	38626862 	ldrb	w2, [x3, x2]
    6724:	7100085f 	cmp	w2, #0x2
    6728:	54000220 	b.eq	676c <fwp_drop10+0x12c>  // b.none
    672c:	7100045f 	cmp	w2, #0x1
    6730:	54fffd41 	b.ne	66d8 <fwp_drop10+0x98>  // b.any
    6734:	294308a3 	ldp	w3, w2, [x5, #24]
    6738:	92403c21 	and	x1, x1, #0xffff
    673c:	9b037c21 	mul	x1, x1, x3
    6740:	d360fc21 	lsr	x1, x1, #32
    6744:	eb02003f 	cmp	x1, x2
    6748:	54fffc82 	b.cs	66d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    674c:	8b010084 	add	x4, x4, x1
    6750:	39400081 	ldrb	w1, [x4]
    6754:	7100043f 	cmp	w1, #0x1
    6758:	54fffc01 	b.ne	66d8 <fwp_drop10+0x98>  // b.any
    675c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6760:	f94013f5 	ldr	x21, [sp, #32]
    6764:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6768:	17fff836 	b	4840 <fwp_mem_free>
    676c:	72003c3f 	tst	w1, #0xffff
    6770:	54ffff00 	b.eq	6750 <fwp_drop10+0x110>  // b.none
    6774:	a94153f3 	ldp	x19, x20, [sp, #16]
    6778:	f94013f5 	ldr	x21, [sp, #32]
    677c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6780:	d65f03c0 	ret
    6784:	72003c3f 	tst	w1, #0xffff
    6788:	54fff980 	b.eq	66b8 <fwp_drop10+0x78>  // b.none
    678c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6790:	f94013f5 	ldr	x21, [sp, #32]
    6794:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6798:	d65f03c0 	ret
    679c:	f9400414 	ldr	x20, [x0, #8]
    67a0:	97fffb5d 	bl	5514 <fwp_rc_free_arr>
    67a4:	91158260 	add	x0, x19, #0x560
    67a8:	f949d801 	ldr	x1, [x0, #5040]
    67ac:	f949ec00 	ldr	x0, [x0, #5080]
    67b0:	cb010281 	sub	x1, x20, x1
    67b4:	eb00403f 	cmp	x1, x0, lsl #16
    67b8:	54fff902 	b.cs	66d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    67bc:	aa1403e0 	mov	x0, x20
    67c0:	17ffffab 	b	666c <fwp_drop10+0x2c>
    67c4:	ca544680 	eor	x0, x20, x20, lsr #17
    67c8:	91158273 	add	x19, x19, #0x560
    67cc:	ca402400 	eor	x0, x0, x0, lsr #9
    67d0:	8b200e60 	add	x0, x19, w0, uxtb #3
    67d4:	f94a2400 	ldr	x0, [x0, #5192]
    67d8:	b5000080 	cbnz	x0, 67e8 <fwp_drop10+0x1a8>
    67dc:	14000010 	b	681c <fwp_drop10+0x1dc>
    67e0:	f9400800 	ldr	x0, [x0, #16]
    67e4:	b40001c0 	cbz	x0, 681c <fwp_drop10+0x1dc>
    67e8:	f9400001 	ldr	x1, [x0]
    67ec:	eb14003f 	cmp	x1, x20
    67f0:	54ffff81 	b.ne	67e0 <fwp_drop10+0x1a0>  // b.any
    67f4:	f9400401 	ldr	x1, [x0, #8]
    67f8:	d1000421 	sub	x1, x1, #0x1
    67fc:	f9000401 	str	x1, [x0, #8]
    6800:	f103f83f 	cmp	x1, #0xfe
    6804:	54fff6a1 	b.ne	66d8 <fwp_drop10+0x98>  // b.any
    6808:	aa1403e0 	mov	x0, x20
    680c:	97fff76d 	bl	45c0 <fwp_rc_forget_slot>
    6810:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6814:	39000280 	strb	w0, [x20]
    6818:	17ffffb0 	b	66d8 <fwp_drop10+0x98>
    681c:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    6820:	913a6000 	add	x0, x0, #0xe98
    6824:	97fff357 	bl	3580 <fwp_trap>
    6828:	d503201f 	nop
    682c:	d503201f 	nop

0000000000006830 <fwp_caps173>:
    6830:	34000041 	cbz	w1, 6838 <fwp_caps173+0x8>
    6834:	d65f03c0 	ret
    6838:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc80>
    683c:	91158063 	add	x3, x3, #0x560
    6840:	f949d861 	ldr	x1, [x3, #5040]
    6844:	f949ec62 	ldr	x2, [x3, #5080]
    6848:	cb010001 	sub	x1, x0, x1
    684c:	eb02403f 	cmp	x1, x2, lsl #16
    6850:	54ffff22 	b.cs	6834 <fwp_caps173+0x4>  // b.hs, b.nlast
    6854:	d350fc22 	lsr	x2, x1, #16
    6858:	f949fc65 	ldr	x5, [x3, #5112]
    685c:	8b020842 	add	x2, x2, x2, lsl #2
    6860:	d37df042 	lsl	x2, x2, #3
    6864:	8b0200a4 	add	x4, x5, x2
    6868:	f9401083 	ldr	x3, [x4, #32]
    686c:	b4fffe43 	cbz	x3, 6834 <fwp_caps173+0x4>
    6870:	386268a2 	ldrb	w2, [x5, x2]
    6874:	7100085f 	cmp	w2, #0x2
    6878:	540001c0 	b.eq	68b0 <fwp_caps173+0x80>  // b.none
    687c:	7100045f 	cmp	w2, #0x1
    6880:	54fffda1 	b.ne	6834 <fwp_caps173+0x4>  // b.any
    6884:	29430885 	ldp	w5, w2, [x4, #24]
    6888:	92403c21 	and	x1, x1, #0xffff
    688c:	9b057c21 	mul	x1, x1, x5
    6890:	d360fc21 	lsr	x1, x1, #32
    6894:	eb02003f 	cmp	x1, x2
    6898:	54fffce2 	b.cs	6834 <fwp_caps173+0x4>  // b.hs, b.nlast
    689c:	8b010063 	add	x3, x3, x1
    68a0:	39400061 	ldrb	w1, [x3]
    68a4:	7100043f 	cmp	w1, #0x1
    68a8:	54fffc61 	b.ne	6834 <fwp_caps173+0x4>  // b.any
    68ac:	17fff7e5 	b	4840 <fwp_mem_free>
    68b0:	72003c3f 	tst	w1, #0xffff
    68b4:	54ffff60 	b.eq	68a0 <fwp_caps173+0x70>  // b.none
    68b8:	d65f03c0 	ret
    68bc:	d503201f 	nop

00000000000068c0 <fwp_args37>:
    68c0:	7100003f 	cmp	w1, #0x0
    68c4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    68c8:	54000041 	b.ne	68d0 <fwp_args37+0x10>  // b.any
    68cc:	d65f03c0 	ret
    68d0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc80>
    68d4:	91158042 	add	x2, x2, #0x560
    68d8:	f9400001 	ldr	x1, [x0]
    68dc:	f949d843 	ldr	x3, [x2, #5040]
    68e0:	f949ec40 	ldr	x0, [x2, #5080]
    68e4:	cb030021 	sub	x1, x1, x3
    68e8:	eb00403f 	cmp	x1, x0, lsl #16
    68ec:	54ffff02 	b.cs	68cc <fwp_args37+0xc>  // b.hs, b.nlast
    68f0:	d350fc20 	lsr	x0, x1, #16
    68f4:	f949fc44 	ldr	x4, [x2, #5112]
    68f8:	8b000800 	add	x0, x0, x0, lsl #2
    68fc:	d37df002 	lsl	x2, x0, #3
    6900:	8b020083 	add	x3, x4, x2
    6904:	f9401060 	ldr	x0, [x3, #32]
    6908:	b4fffe20 	cbz	x0, 68cc <fwp_args37+0xc>
    690c:	38626882 	ldrb	w2, [x4, x2]
    6910:	7100085f 	cmp	w2, #0x2
    6914:	54000220 	b.eq	6958 <fwp_args37+0x98>  // b.none
    6918:	7100045f 	cmp	w2, #0x1
    691c:	54fffd81 	b.ne	68cc <fwp_args37+0xc>  // b.any
    6920:	29430864 	ldp	w4, w2, [x3, #24]
    6924:	92403c21 	and	x1, x1, #0xffff
    6928:	9b047c21 	mul	x1, x1, x4
    692c:	d360fc21 	lsr	x1, x1, #32
    6930:	eb02003f 	cmp	x1, x2
    6934:	54fffcc2 	b.cs	68cc <fwp_args37+0xc>  // b.hs, b.nlast
    6938:	8b010000 	add	x0, x0, x1
    693c:	39400001 	ldrb	w1, [x0]
    6940:	34fffc61 	cbz	w1, 68cc <fwp_args37+0xc>
    6944:	7103f43f 	cmp	w1, #0xfd
    6948:	540000e8 	b.hi	6964 <fwp_args37+0xa4>  // b.pmore
    694c:	11000421 	add	w1, w1, #0x1
    6950:	39000001 	strb	w1, [x0]
    6954:	d65f03c0 	ret
    6958:	72003c3f 	tst	w1, #0xffff
    695c:	54ffff00 	b.eq	693c <fwp_args37+0x7c>  // b.none
    6960:	d65f03c0 	ret
    6964:	17fff6d0 	b	44a4 <fwp_rc_wide_dup>
    6968:	d503201f 	nop
    696c:	d503201f 	nop

0000000000006970 <fwp_caps37>:
    6970:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6974:	910003fd 	mov	x29, sp
    6978:	f9000bf3 	str	x19, [sp, #16]
    697c:	aa0003f3 	mov	x19, x0
    6980:	b9400400 	ldr	w0, [x0, #4]
    6984:	340004a0 	cbz	w0, 6a18 <fwp_caps37+0xa8>
    6988:	f9400660 	ldr	x0, [x19, #8]
    698c:	350004e1 	cbnz	w1, 6a28 <fwp_caps37+0xb8>
    6990:	97fffd90 	bl	5fd0 <fwp_drop4>
    6994:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc80>
    6998:	91158042 	add	x2, x2, #0x560
    699c:	f949d840 	ldr	x0, [x2, #5040]
    69a0:	f949ec41 	ldr	x1, [x2, #5080]
    69a4:	cb000260 	sub	x0, x19, x0
    69a8:	eb01401f 	cmp	x0, x1, lsl #16
    69ac:	54000382 	b.cs	6a1c <fwp_caps37+0xac>  // b.hs, b.nlast
    69b0:	d350fc01 	lsr	x1, x0, #16
    69b4:	f949fc44 	ldr	x4, [x2, #5112]
    69b8:	8b010821 	add	x1, x1, x1, lsl #2
    69bc:	d37df021 	lsl	x1, x1, #3
    69c0:	8b010083 	add	x3, x4, x1
    69c4:	f9401062 	ldr	x2, [x3, #32]
    69c8:	b40002a2 	cbz	x2, 6a1c <fwp_caps37+0xac>
    69cc:	38616881 	ldrb	w1, [x4, x1]
    69d0:	7100083f 	cmp	w1, #0x2
    69d4:	540006c0 	b.eq	6aac <fwp_caps37+0x13c>  // b.none
    69d8:	7100043f 	cmp	w1, #0x1
    69dc:	54000201 	b.ne	6a1c <fwp_caps37+0xac>  // b.any
    69e0:	29430464 	ldp	w4, w1, [x3, #24]
    69e4:	92403c00 	and	x0, x0, #0xffff
    69e8:	9b047c00 	mul	x0, x0, x4
    69ec:	d360fc00 	lsr	x0, x0, #32
    69f0:	eb01001f 	cmp	x0, x1
    69f4:	54000142 	b.cs	6a1c <fwp_caps37+0xac>  // b.hs, b.nlast
    69f8:	8b000042 	add	x2, x2, x0
    69fc:	39400040 	ldrb	w0, [x2]
    6a00:	7100041f 	cmp	w0, #0x1
    6a04:	540000c1 	b.ne	6a1c <fwp_caps37+0xac>  // b.any
    6a08:	aa1303e0 	mov	x0, x19
    6a0c:	f9400bf3 	ldr	x19, [sp, #16]
    6a10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a14:	17fff78b 	b	4840 <fwp_mem_free>
    6a18:	34fffbe1 	cbz	w1, 6994 <fwp_caps37+0x24>
    6a1c:	f9400bf3 	ldr	x19, [sp, #16]
    6a20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a24:	d65f03c0 	ret
    6a28:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc80>
    6a2c:	91158042 	add	x2, x2, #0x560
    6a30:	f949d843 	ldr	x3, [x2, #5040]
    6a34:	f949ec41 	ldr	x1, [x2, #5080]
    6a38:	cb030000 	sub	x0, x0, x3
    6a3c:	eb01401f 	cmp	x0, x1, lsl #16
    6a40:	54fffee2 	b.cs	6a1c <fwp_caps37+0xac>  // b.hs, b.nlast
    6a44:	d350fc01 	lsr	x1, x0, #16
    6a48:	f949fc44 	ldr	x4, [x2, #5112]
    6a4c:	8b010821 	add	x1, x1, x1, lsl #2
    6a50:	d37df021 	lsl	x1, x1, #3
    6a54:	8b010083 	add	x3, x4, x1
    6a58:	f9401062 	ldr	x2, [x3, #32]
    6a5c:	b4fffe02 	cbz	x2, 6a1c <fwp_caps37+0xac>
    6a60:	38616881 	ldrb	w1, [x4, x1]
    6a64:	7100083f 	cmp	w1, #0x2
    6a68:	54000280 	b.eq	6ab8 <fwp_caps37+0x148>  // b.none
    6a6c:	7100043f 	cmp	w1, #0x1
    6a70:	54fffd61 	b.ne	6a1c <fwp_caps37+0xac>  // b.any
    6a74:	92403c01 	and	x1, x0, #0xffff
    6a78:	29430064 	ldp	w4, w0, [x3, #24]
    6a7c:	9b047c21 	mul	x1, x1, x4
    6a80:	d360fc21 	lsr	x1, x1, #32
    6a84:	eb00003f 	cmp	x1, x0
    6a88:	54fffca2 	b.cs	6a1c <fwp_caps37+0xac>  // b.hs, b.nlast
    6a8c:	8b010042 	add	x2, x2, x1
    6a90:	39400040 	ldrb	w0, [x2]
    6a94:	34fffc40 	cbz	w0, 6a1c <fwp_caps37+0xac>
    6a98:	7103f41f 	cmp	w0, #0xfd
    6a9c:	54000148 	b.hi	6ac4 <fwp_caps37+0x154>  // b.pmore
    6aa0:	11000400 	add	w0, w0, #0x1
    6aa4:	39000040 	strb	w0, [x2]
    6aa8:	17ffffdd 	b	6a1c <fwp_caps37+0xac>
    6aac:	72003c1f 	tst	w0, #0xffff
    6ab0:	54fffb61 	b.ne	6a1c <fwp_caps37+0xac>  // b.any
    6ab4:	17ffffd2 	b	69fc <fwp_caps37+0x8c>
    6ab8:	72003c1f 	tst	w0, #0xffff
    6abc:	54fffb01 	b.ne	6a1c <fwp_caps37+0xac>  // b.any
    6ac0:	17fffff4 	b	6a90 <fwp_caps37+0x120>
    6ac4:	f9400bf3 	ldr	x19, [sp, #16]
    6ac8:	aa0203e0 	mov	x0, x2
    6acc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ad0:	17fff675 	b	44a4 <fwp_rc_wide_dup>

0000000000006ad4 <f37>:
    6ad4:	d101c3ff 	sub	sp, sp, #0x70
    6ad8:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6adc:	f947f421 	ldr	x1, [x1, #4072]
    6ae0:	a9027bfd 	stp	x29, x30, [sp, #32]
    6ae4:	910083fd 	add	x29, sp, #0x20
    6ae8:	a90563f7 	stp	x23, x24, [sp, #80]
    6aec:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc80>
    6af0:	911582e3 	add	x3, x23, #0x560
    6af4:	a90353f3 	stp	x19, x20, [sp, #48]
    6af8:	a9045bf5 	stp	x21, x22, [sp, #64]
    6afc:	aa0003f6 	mov	x22, x0
    6b00:	a9066bf9 	stp	x25, x26, [sp, #96]
    6b04:	f949ec62 	ldr	x2, [x3, #5080]
    6b08:	f9400024 	ldr	x4, [x1]
    6b0c:	f9000fe4 	str	x4, [sp, #24]
    6b10:	d2800004 	mov	x4, #0x0                   	// #0
    6b14:	f949d861 	ldr	x1, [x3, #5040]
    6b18:	d370bc42 	lsl	x2, x2, #16
    6b1c:	b40015a0 	cbz	x0, 6dd0 <f37+0x2fc>
    6b20:	f9400818 	ldr	x24, [x0, #16]
    6b24:	cb010301 	sub	x1, x24, x1
    6b28:	eb02003f 	cmp	x1, x2
    6b2c:	54000362 	b.cs	6b98 <f37+0xc4>  // b.hs, b.nlast
    6b30:	f949fc60 	ldr	x0, [x3, #5112]
    6b34:	d350fc22 	lsr	x2, x1, #16
    6b38:	8b020842 	add	x2, x2, x2, lsl #2
    6b3c:	8b020c02 	add	x2, x0, x2, lsl #3
    6b40:	f9401040 	ldr	x0, [x2, #32]
    6b44:	b40002a0 	cbz	x0, 6b98 <f37+0xc4>
    6b48:	39400043 	ldrb	w3, [x2]
    6b4c:	7100087f 	cmp	w3, #0x2
    6b50:	540013a0 	b.eq	6dc4 <f37+0x2f0>  // b.none
    6b54:	7100047f 	cmp	w3, #0x1
    6b58:	540001c1 	b.ne	6b90 <f37+0xbc>  // b.any
    6b5c:	29430843 	ldp	w3, w2, [x2, #24]
    6b60:	92403c21 	and	x1, x1, #0xffff
    6b64:	9b037c21 	mul	x1, x1, x3
    6b68:	d360fc21 	lsr	x1, x1, #32
    6b6c:	eb02003f 	cmp	x1, x2
    6b70:	54000102 	b.cs	6b90 <f37+0xbc>  // b.hs, b.nlast
    6b74:	8b010000 	add	x0, x0, x1
    6b78:	39400001 	ldrb	w1, [x0]
    6b7c:	340000a1 	cbz	w1, 6b90 <f37+0xbc>
    6b80:	7103f43f 	cmp	w1, #0xfd
    6b84:	54001688 	b.hi	6e54 <f37+0x380>  // b.pmore
    6b88:	11000421 	add	w1, w1, #0x1
    6b8c:	39000001 	strb	w1, [x0]
    6b90:	d2800000 	mov	x0, #0x0                   	// #0
    6b94:	b40000d6 	cbz	x22, 6bac <f37+0xd8>
    6b98:	aa1603e1 	mov	x1, x22
    6b9c:	d2800000 	mov	x0, #0x0                   	// #0
    6ba0:	f9400821 	ldr	x1, [x1, #16]
    6ba4:	91000400 	add	x0, x0, #0x1
    6ba8:	b5ffffc1 	cbnz	x1, 6ba0 <f37+0xcc>
    6bac:	b40011b8 	cbz	x24, 6de0 <f37+0x30c>
    6bb0:	aa1803e1 	mov	x1, x24
    6bb4:	d2800002 	mov	x2, #0x0                   	// #0
    6bb8:	f9400821 	ldr	x1, [x1, #16]
    6bbc:	91000442 	add	x2, x2, #0x1
    6bc0:	b5ffffc1 	cbnz	x1, 6bb8 <f37+0xe4>
    6bc4:	eb00005f 	cmp	x2, x0
    6bc8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6bcc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6bd0:	eb01033f 	cmp	x25, x1
    6bd4:	54001468 	b.hi	6e60 <f37+0x38c>  // b.pmore
    6bd8:	d37ffb33 	lsl	x19, x25, #1
    6bdc:	52800041 	mov	w1, #0x2                   	// #2
    6be0:	91000660 	add	x0, x19, #0x1
    6be4:	d37df000 	lsl	x0, x0, #3
    6be8:	97fff836 	bl	4cc0 <fwp_heap_alloc>
    6bec:	911582e1 	add	x1, x23, #0x560
    6bf0:	aa0003fa 	mov	x26, x0
    6bf4:	f9000013 	str	x19, [x0]
    6bf8:	aa0103e0 	mov	x0, x1
    6bfc:	f949d821 	ldr	x1, [x1, #5040]
    6c00:	f949ec00 	ldr	x0, [x0, #5080]
    6c04:	cb010341 	sub	x1, x26, x1
    6c08:	eb00403f 	cmp	x1, x0, lsl #16
    6c0c:	54000342 	b.cs	6c74 <f37+0x1a0>  // b.hs, b.nlast
    6c10:	911582e2 	add	x2, x23, #0x560
    6c14:	d350fc20 	lsr	x0, x1, #16
    6c18:	8b000800 	add	x0, x0, x0, lsl #2
    6c1c:	f949fc43 	ldr	x3, [x2, #5112]
    6c20:	d37df002 	lsl	x2, x0, #3
    6c24:	8b020060 	add	x0, x3, x2
    6c28:	f9401013 	ldr	x19, [x0, #32]
    6c2c:	b4000253 	cbz	x19, 6c74 <f37+0x1a0>
    6c30:	38626862 	ldrb	w2, [x3, x2]
    6c34:	7100085f 	cmp	w2, #0x2
    6c38:	54000c00 	b.eq	6db8 <f37+0x2e4>  // b.none
    6c3c:	7100045f 	cmp	w2, #0x1
    6c40:	540001a1 	b.ne	6c74 <f37+0x1a0>  // b.any
    6c44:	29430002 	ldp	w2, w0, [x0, #24]
    6c48:	92403c21 	and	x1, x1, #0xffff
    6c4c:	9b027c21 	mul	x1, x1, x2
    6c50:	d360fc21 	lsr	x1, x1, #32
    6c54:	eb00003f 	cmp	x1, x0
    6c58:	540000e2 	b.cs	6c74 <f37+0x1a0>  // b.hs, b.nlast
    6c5c:	8b010273 	add	x19, x19, x1
    6c60:	39400260 	ldrb	w0, [x19]
    6c64:	7103fc1f 	cmp	w0, #0xff
    6c68:	54000da0 	b.eq	6e1c <f37+0x348>  // b.none
    6c6c:	52800020 	mov	w0, #0x1                   	// #1
    6c70:	39000260 	strb	w0, [x19]
    6c74:	b4000259 	cbz	x25, 6cbc <f37+0x1e8>
    6c78:	8b191359 	add	x25, x26, x25, lsl #4
    6c7c:	aa1a03f3 	mov	x19, x26
    6c80:	aa1603f5 	mov	x21, x22
    6c84:	aa1803f4 	mov	x20, x24
    6c88:	f9400683 	ldr	x3, [x20, #8]
    6c8c:	f94006a2 	ldr	x2, [x21, #8]
    6c90:	f9400861 	ldr	x1, [x3, #16]
    6c94:	f9400840 	ldr	x0, [x2, #16]
    6c98:	fd400461 	ldr	d1, [x3, #8]
    6c9c:	fd400440 	ldr	d0, [x2, #8]
    6ca0:	97fff948 	bl	51c0 <w120>
    6ca4:	f9000660 	str	x0, [x19, #8]
    6ca8:	f8010e61 	str	x1, [x19, #16]!
    6cac:	f9400a94 	ldr	x20, [x20, #16]
    6cb0:	f9400ab5 	ldr	x21, [x21, #16]
    6cb4:	eb13033f 	cmp	x25, x19
    6cb8:	54fffe81 	b.ne	6c88 <f37+0x1b4>  // b.any
    6cbc:	aa1803e0 	mov	x0, x24
    6cc0:	97fffcc4 	bl	5fd0 <fwp_drop4>
    6cc4:	aa1603e0 	mov	x0, x22
    6cc8:	97fffcc2 	bl	5fd0 <fwp_drop4>
    6ccc:	911582f7 	add	x23, x23, #0x560
    6cd0:	aa1a03e0 	mov	x0, x26
    6cd4:	97fff98f 	bl	5310 <w176.constprop.0>
    6cd8:	aa0103f3 	mov	x19, x1
    6cdc:	aa0003f4 	mov	x20, x0
    6ce0:	aa1a03e0 	mov	x0, x26
    6ce4:	97fffe57 	bl	6640 <fwp_drop10>
    6ce8:	a900cff4 	stp	x20, x19, [sp, #8]
    6cec:	910023e1 	add	x1, sp, #0x8
    6cf0:	52800000 	mov	w0, #0x0                   	// #0
    6cf4:	97fff838 	bl	4dd4 <fwp_data.part.0.constprop.0>
    6cf8:	f949dae1 	ldr	x1, [x23, #5040]
    6cfc:	aa0003f3 	mov	x19, x0
    6d00:	f949eee0 	ldr	x0, [x23, #5080]
    6d04:	cb010261 	sub	x1, x19, x1
    6d08:	eb00403f 	cmp	x1, x0, lsl #16
    6d0c:	54000322 	b.cs	6d70 <f37+0x29c>  // b.hs, b.nlast
    6d10:	d350fc22 	lsr	x2, x1, #16
    6d14:	f949fee3 	ldr	x3, [x23, #5112]
    6d18:	8b020842 	add	x2, x2, x2, lsl #2
    6d1c:	d37df042 	lsl	x2, x2, #3
    6d20:	8b020060 	add	x0, x3, x2
    6d24:	f9401014 	ldr	x20, [x0, #32]
    6d28:	b4000254 	cbz	x20, 6d70 <f37+0x29c>
    6d2c:	38626862 	ldrb	w2, [x3, x2]
    6d30:	7100085f 	cmp	w2, #0x2
    6d34:	540003c0 	b.eq	6dac <f37+0x2d8>  // b.none
    6d38:	7100045f 	cmp	w2, #0x1
    6d3c:	540001a1 	b.ne	6d70 <f37+0x29c>  // b.any
    6d40:	29430002 	ldp	w2, w0, [x0, #24]
    6d44:	92403c21 	and	x1, x1, #0xffff
    6d48:	9b027c21 	mul	x1, x1, x2
    6d4c:	d360fc21 	lsr	x1, x1, #32
    6d50:	eb00003f 	cmp	x1, x0
    6d54:	540000e2 	b.cs	6d70 <f37+0x29c>  // b.hs, b.nlast
    6d58:	8b010294 	add	x20, x20, x1
    6d5c:	39400280 	ldrb	w0, [x20]
    6d60:	7103fc1f 	cmp	w0, #0xff
    6d64:	54000620 	b.eq	6e28 <f37+0x354>  // b.none
    6d68:	52800020 	mov	w0, #0x1                   	// #1
    6d6c:	39000280 	strb	w0, [x20]
    6d70:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6d74:	f947f400 	ldr	x0, [x0, #4072]
    6d78:	f9400fe2 	ldr	x2, [sp, #24]
    6d7c:	f9400001 	ldr	x1, [x0]
    6d80:	eb010042 	subs	x2, x2, x1
    6d84:	d2800001 	mov	x1, #0x0                   	// #0
    6d88:	540006a1 	b.ne	6e5c <f37+0x388>  // b.any
    6d8c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6d90:	aa1303e0 	mov	x0, x19
    6d94:	a94353f3 	ldp	x19, x20, [sp, #48]
    6d98:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6d9c:	a94563f7 	ldp	x23, x24, [sp, #80]
    6da0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6da4:	9101c3ff 	add	sp, sp, #0x70
    6da8:	d65f03c0 	ret
    6dac:	72003c3f 	tst	w1, #0xffff
    6db0:	54fffe01 	b.ne	6d70 <f37+0x29c>  // b.any
    6db4:	17ffffea 	b	6d5c <f37+0x288>
    6db8:	72003c3f 	tst	w1, #0xffff
    6dbc:	54fff5c1 	b.ne	6c74 <f37+0x1a0>  // b.any
    6dc0:	17ffffa8 	b	6c60 <f37+0x18c>
    6dc4:	72003c3f 	tst	w1, #0xffff
    6dc8:	54ffee41 	b.ne	6b90 <f37+0xbc>  // b.any
    6dcc:	17ffff6b 	b	6b78 <f37+0xa4>
    6dd0:	cb0103e1 	neg	x1, x1
    6dd4:	eb02003f 	cmp	x1, x2
    6dd8:	540002e3 	b.cc	6e34 <f37+0x360>  // b.lo, b.ul, b.last
    6ddc:	d503201f 	nop
    6de0:	52800041 	mov	w1, #0x2                   	// #2
    6de4:	d2800100 	mov	x0, #0x8                   	// #8
    6de8:	97fff7b6 	bl	4cc0 <fwp_heap_alloc>
    6dec:	aa0003e1 	mov	x1, x0
    6df0:	911582e0 	add	x0, x23, #0x560
    6df4:	aa0103fa 	mov	x26, x1
    6df8:	d2800018 	mov	x24, #0x0                   	// #0
    6dfc:	f900003f 	str	xzr, [x1]
    6e00:	f949d801 	ldr	x1, [x0, #5040]
    6e04:	f949ec00 	ldr	x0, [x0, #5080]
    6e08:	cb010341 	sub	x1, x26, x1
    6e0c:	eb00403f 	cmp	x1, x0, lsl #16
    6e10:	54fff562 	b.cs	6cbc <f37+0x1e8>  // b.hs, b.nlast
    6e14:	d2800019 	mov	x25, #0x0                   	// #0
    6e18:	17ffff7e 	b	6c10 <f37+0x13c>
    6e1c:	aa1303e0 	mov	x0, x19
    6e20:	97fff5e8 	bl	45c0 <fwp_rc_forget_slot>
    6e24:	17ffff92 	b	6c6c <f37+0x198>
    6e28:	aa1403e0 	mov	x0, x20
    6e2c:	97fff5e5 	bl	45c0 <fwp_rc_forget_slot>
    6e30:	17ffffce 	b	6d68 <f37+0x294>
    6e34:	f949fc62 	ldr	x2, [x3, #5112]
    6e38:	d350fc20 	lsr	x0, x1, #16
    6e3c:	8b000800 	add	x0, x0, x0, lsl #2
    6e40:	8b000c42 	add	x2, x2, x0, lsl #3
    6e44:	f9401040 	ldr	x0, [x2, #32]
    6e48:	b4fffcc0 	cbz	x0, 6de0 <f37+0x30c>
    6e4c:	d2800018 	mov	x24, #0x0                   	// #0
    6e50:	17ffff3e 	b	6b48 <f37+0x74>
    6e54:	97fff594 	bl	44a4 <fwp_rc_wide_dup>
    6e58:	17ffff4e 	b	6b90 <f37+0xbc>
    6e5c:	97ffee89 	bl	2880 <__stack_chk_fail@plt>
    6e60:	d0000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    6e64:	913f6000 	add	x0, x0, #0xfd8
    6e68:	97fff1c6 	bl	3580 <fwp_trap>
    6e6c:	d503201f 	nop

0000000000006e70 <fwp_owned_entry37>:
    6e70:	f9400000 	ldr	x0, [x0]
    6e74:	17ffff18 	b	6ad4 <f37>
    6e78:	d503201f 	nop
    6e7c:	d503201f 	nop

0000000000006e80 <e37>:
    6e80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6e84:	910003fd 	mov	x29, sp
    6e88:	f9000bf3 	str	x19, [sp, #16]
    6e8c:	f9400013 	ldr	x19, [x0]
    6e90:	aa1303e0 	mov	x0, x19
    6e94:	97fff94b 	bl	53c0 <fwp_rc_share>
    6e98:	aa1303e0 	mov	x0, x19
    6e9c:	97ffff0e 	bl	6ad4 <f37>
    6ea0:	aa0003f3 	mov	x19, x0
    6ea4:	97fff947 	bl	53c0 <fwp_rc_share>
    6ea8:	aa1303e0 	mov	x0, x19
    6eac:	f9400bf3 	ldr	x19, [sp, #16]
    6eb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6eb4:	d65f03c0 	ret
    6eb8:	d503201f 	nop
    6ebc:	d503201f 	nop

0000000000006ec0 <fwp_write>:
    6ec0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    6ec4:	910003fd 	mov	x29, sp
    6ec8:	b00000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    6ecc:	f947f484 	ldr	x4, [x4, #4072]
    6ed0:	a90153f3 	stp	x19, x20, [sp, #16]
    6ed4:	d10943ff 	sub	sp, sp, #0x250
    6ed8:	b9400045 	ldr	w5, [x2]
    6edc:	aa0003f4 	mov	x20, x0
    6ee0:	f9400080 	ldr	x0, [x4]
    6ee4:	f90127e0 	str	x0, [sp, #584]
    6ee8:	d2800000 	mov	x0, #0x0                   	// #0
    6eec:	710064bf 	cmp	w5, #0x19
    6ef0:	54000408 	b.hi	6f70 <fwp_write+0xb0>  // b.pmore
    6ef4:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    6ef8:	aa0103f3 	mov	x19, x1
    6efc:	91210000 	add	x0, x0, #0x840
    6f00:	f9013bf5 	str	x21, [sp, #624]
    6f04:	f9013ff6 	str	x22, [sp, #632]
    6f08:	f90153fb 	str	x27, [sp, #672]
    6f0c:	f90157fc 	str	x28, [sp, #680]
    6f10:	aa0203fc 	mov	x28, x2
    6f14:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    6f18:	10000061 	adr	x1, 6f24 <fwp_write+0x64>
    6f1c:	8b20a820 	add	x0, x1, w0, sxth #2
    6f20:	d61f0000 	br	x0
    6f24:	910123e0 	add	x0, sp, #0x48
    6f28:	aa1303e5 	mov	x5, x19
    6f2c:	f0000024 	adrp	x4, d000 <_IO_stdin_used+0x410>
    6f30:	aa0003f3 	mov	x19, x0
    6f34:	91008084 	add	x4, x4, #0x20
    6f38:	d2804003 	mov	x3, #0x200                 	// #512
    6f3c:	aa0303e1 	mov	x1, x3
    6f40:	52800042 	mov	w2, #0x2                   	// #2
    6f44:	97ffee2b 	bl	27f0 <__snprintf_chk@plt>
    6f48:	aa1303e0 	mov	x0, x19
    6f4c:	97ffedf1 	bl	2710 <strlen@plt>
    6f50:	aa1303e1 	mov	x1, x19
    6f54:	aa0003e2 	mov	x2, x0
    6f58:	aa1403e0 	mov	x0, x20
    6f5c:	97fff12d 	bl	3410 <buf_put>
    6f60:	f9413bf5 	ldr	x21, [sp, #624]
    6f64:	f9413ff6 	ldr	x22, [sp, #632]
    6f68:	f94153fb 	ldr	x27, [sp, #672]
    6f6c:	f94157fc 	ldr	x28, [sp, #680]
    6f70:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6f74:	f947f400 	ldr	x0, [x0, #4072]
    6f78:	f94127e2 	ldr	x2, [sp, #584]
    6f7c:	f9400001 	ldr	x1, [x0]
    6f80:	eb010042 	subs	x2, x2, x1
    6f84:	d2800001 	mov	x1, #0x0                   	// #0
    6f88:	540077c1 	b.ne	7e80 <fwp_write+0xfc0>  // b.any
    6f8c:	910943ff 	add	sp, sp, #0x250
    6f90:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f94:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6f98:	d65f03c0 	ret
    6f9c:	910123e0 	add	x0, sp, #0x48
    6fa0:	aa1303e5 	mov	x5, x19
    6fa4:	f0000024 	adrp	x4, d000 <_IO_stdin_used+0x410>
    6fa8:	aa0003f3 	mov	x19, x0
    6fac:	91006084 	add	x4, x4, #0x18
    6fb0:	d2804003 	mov	x3, #0x200                 	// #512
    6fb4:	17ffffe2 	b	6f3c <fwp_write+0x7c>
    6fb8:	71004cbf 	cmp	w5, #0x13
    6fbc:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    6fc0:	f0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    6fc4:	91002000 	add	x0, x0, #0x8
    6fc8:	91004021 	add	x1, x1, #0x10
    6fcc:	d2800082 	mov	x2, #0x4                   	// #4
    6fd0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    6fd4:	aa1403e0 	mov	x0, x20
    6fd8:	f90143f7 	str	x23, [sp, #640]
    6fdc:	d2800016 	mov	x22, #0x0                   	// #0
    6fe0:	f90147f8 	str	x24, [sp, #648]
    6fe4:	97fff10b 	bl	3410 <buf_put>
    6fe8:	f9400260 	ldr	x0, [x19]
    6fec:	f0000037 	adrp	x23, d000 <_IO_stdin_used+0x410>
    6ff0:	d2800015 	mov	x21, #0x0                   	// #0
    6ff4:	910242f7 	add	x23, x23, #0x90
    6ff8:	b40047a0 	cbz	x0, 78ec <fwp_write+0xa2c>
    6ffc:	b9400380 	ldr	w0, [x28]
    7000:	52800003 	mov	w3, #0x0                   	// #0
    7004:	f9401f82 	ldr	x2, [x28, #56]
    7008:	71004c1f 	cmp	w0, #0x13
    700c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7010:	aa1403e0 	mov	x0, x20
    7014:	8b010e61 	add	x1, x19, x1, lsl #3
    7018:	f9400421 	ldr	x1, [x1, #8]
    701c:	97ffffa9 	bl	6ec0 <fwp_write>
    7020:	b9400380 	ldr	w0, [x28]
    7024:	7100481f 	cmp	w0, #0x12
    7028:	54004b40 	b.eq	7990 <fwp_write+0xad0>  // b.none
    702c:	f9400260 	ldr	x0, [x19]
    7030:	910006b5 	add	x21, x21, #0x1
    7034:	91000ad6 	add	x22, x22, #0x2
    7038:	eb15001f 	cmp	x0, x21
    703c:	54004589 	b.ls	78ec <fwp_write+0xa2c>  // b.plast
    7040:	aa1703e1 	mov	x1, x23
    7044:	aa1403e0 	mov	x0, x20
    7048:	d2800042 	mov	x2, #0x2                   	// #2
    704c:	97fff0f1 	bl	3410 <buf_put>
    7050:	17ffffeb 	b	6ffc <fwp_write+0x13c>
    7054:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    7058:	91012021 	add	x1, x1, #0x48
    705c:	d28000c2 	mov	x2, #0x6                   	// #6
    7060:	aa1403e0 	mov	x0, x20
    7064:	91004273 	add	x19, x19, #0x10
    7068:	97fff0ea 	bl	3410 <buf_put>
    706c:	aa1303e0 	mov	x0, x19
    7070:	97ffeda8 	bl	2710 <strlen@plt>
    7074:	aa1303e1 	mov	x1, x19
    7078:	aa0003e2 	mov	x2, x0
    707c:	aa1403e0 	mov	x0, x20
    7080:	97fff0e4 	bl	3410 <buf_put>
    7084:	528007c3 	mov	w3, #0x3e                  	// #62
    7088:	aa1403e0 	mov	x0, x20
    708c:	91001fe1 	add	x1, sp, #0x7
    7090:	d2800022 	mov	x2, #0x1                   	// #1
    7094:	39001fe3 	strb	w3, [sp, #7]
    7098:	17ffffb1 	b	6f5c <fwp_write+0x9c>
    709c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    70a0:	f947f400 	ldr	x0, [x0, #4072]
    70a4:	f94127e2 	ldr	x2, [sp, #584]
    70a8:	f9400001 	ldr	x1, [x0]
    70ac:	eb010042 	subs	x2, x2, x1
    70b0:	d2800001 	mov	x1, #0x0                   	// #0
    70b4:	540034e1 	b.ne	7750 <fwp_write+0x890>  // b.any
    70b8:	f9413bf5 	ldr	x21, [sp, #624]
    70bc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    70c0:	f9413ff6 	ldr	x22, [sp, #632]
    70c4:	aa1403e0 	mov	x0, x20
    70c8:	9100a021 	add	x1, x1, #0x28
    70cc:	d2800142 	mov	x2, #0xa                   	// #10
    70d0:	f94153fb 	ldr	x27, [sp, #672]
    70d4:	f94157fc 	ldr	x28, [sp, #680]
    70d8:	910943ff 	add	sp, sp, #0x250
    70dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    70e0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    70e4:	17fff0cb 	b	3410 <buf_put>
    70e8:	f9400456 	ldr	x22, [x2, #8]
    70ec:	f90143f7 	str	x23, [sp, #640]
    70f0:	f90147f8 	str	x24, [sp, #648]
    70f4:	b4005b16 	cbz	x22, 7c54 <fwp_write+0xd94>
    70f8:	aa1603e0 	mov	x0, x22
    70fc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    7100:	9102a021 	add	x1, x1, #0xa8
    7104:	97ffedff 	bl	2900 <strcmp@plt>
    7108:	2a0003f5 	mov	w21, w0
    710c:	34005fe0 	cbz	w0, 7d08 <fwp_write+0xe48>
    7110:	aa1603e0 	mov	x0, x22
    7114:	97ffed7f 	bl	2710 <strlen@plt>
    7118:	aa1603e1 	mov	x1, x22
    711c:	aa0003e2 	mov	x2, x0
    7120:	aa1403e0 	mov	x0, x20
    7124:	97fff0bb 	bl	3410 <buf_put>
    7128:	52800403 	mov	w3, #0x20                  	// #32
    712c:	91001ff5 	add	x21, sp, #0x7
    7130:	aa1503e1 	mov	x1, x21
    7134:	aa1403e0 	mov	x0, x20
    7138:	d2800022 	mov	x2, #0x1                   	// #1
    713c:	39001fe3 	strb	w3, [sp, #7]
    7140:	97fff0b4 	bl	3410 <buf_put>
    7144:	52800f63 	mov	w3, #0x7b                  	// #123
    7148:	aa1403e0 	mov	x0, x20
    714c:	aa1503e1 	mov	x1, x21
    7150:	d2800022 	mov	x2, #0x1                   	// #1
    7154:	39001fe3 	strb	w3, [sp, #7]
    7158:	97fff0ae 	bl	3410 <buf_put>
    715c:	b9401380 	ldr	w0, [x28, #16]
    7160:	52800018 	mov	w24, #0x0                   	// #0
    7164:	7100001f 	cmp	w0, #0x0
    7168:	54003aad 	b.le	78bc <fwp_write+0x9fc>
    716c:	f9014bf9 	str	x25, [sp, #656]
    7170:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x410>
    7174:	91034339 	add	x25, x25, #0xd0
    7178:	f9014ffa 	str	x26, [sp, #664]
    717c:	d000003a 	adrp	x26, d000 <_IO_stdin_used+0x410>
    7180:	9102435a 	add	x26, x26, #0x90
    7184:	91002276 	add	x22, x19, #0x8
    7188:	d2800013 	mov	x19, #0x0                   	// #0
    718c:	b5003e93 	cbnz	x19, 795c <fwp_write+0xa9c>
    7190:	d37df277 	lsl	x23, x19, #3
    7194:	34003cb8 	cbz	w24, 7928 <fwp_write+0xa68>
    7198:	f9401382 	ldr	x2, [x28, #32]
    719c:	aa1403e0 	mov	x0, x20
    71a0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    71a4:	52800003 	mov	w3, #0x0                   	// #0
    71a8:	f8776842 	ldr	x2, [x2, x23]
    71ac:	91000673 	add	x19, x19, #0x1
    71b0:	97ffff44 	bl	6ec0 <fwp_write>
    71b4:	b9401380 	ldr	w0, [x28, #16]
    71b8:	6b13001f 	cmp	w0, w19
    71bc:	54fffe8c 	b.gt	718c <fwp_write+0x2cc>
    71c0:	f9414bf9 	ldr	x25, [sp, #656]
    71c4:	f9414ffa 	ldr	x26, [sp, #664]
    71c8:	340037b8 	cbz	w24, 78bc <fwp_write+0x9fc>
    71cc:	52800523 	mov	w3, #0x29                  	// #41
    71d0:	aa1503e1 	mov	x1, x21
    71d4:	aa1403e0 	mov	x0, x20
    71d8:	d2800022 	mov	x2, #0x1                   	// #1
    71dc:	39001fe3 	strb	w3, [sp, #7]
    71e0:	97fff08c 	bl	3410 <buf_put>
    71e4:	f9413bf5 	ldr	x21, [sp, #624]
    71e8:	f9413ff6 	ldr	x22, [sp, #632]
    71ec:	f94143f7 	ldr	x23, [sp, #640]
    71f0:	f94147f8 	ldr	x24, [sp, #648]
    71f4:	f94153fb 	ldr	x27, [sp, #672]
    71f8:	f94157fc 	ldr	x28, [sp, #680]
    71fc:	17ffff5d 	b	6f70 <fwp_write+0xb0>
    7200:	b9404855 	ldr	w21, [x2, #72]
    7204:	aa1403e0 	mov	x0, x20
    7208:	93407eb6 	sxtw	x22, w21
    720c:	91000ac1 	add	x1, x22, #0x2
    7210:	97fff04d 	bl	3344 <buf_grow>
    7214:	a9400281 	ldp	x1, x0, [x20]
    7218:	528e8603 	mov	w3, #0x7430                	// #29744
    721c:	78206823 	strh	w3, [x1, x0]
    7220:	8b000022 	add	x2, x1, x0
    7224:	710002bf 	cmp	w21, #0x0
    7228:	540036cd 	b.le	7900 <fwp_write+0xa40>
    722c:	110006a3 	add	w3, w21, #0x1
    7230:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7234:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7238:	91000449 	add	x9, x2, #0x1
    723c:	8b23c043 	add	x3, x2, w3, sxtw
    7240:	f28aaac6 	movk	x6, #0x5556
    7244:	f2955568 	movk	x8, #0xaaab
    7248:	1400000d 	b	727c <fwp_write+0x3bc>
    724c:	d2800021 	mov	x1, #0x1                   	// #1
    7250:	528005a5 	mov	w5, #0x2d                  	// #45
    7254:	f100001f 	cmp	x0, #0x0
    7258:	9b467e60 	smulh	x0, x19, x6
    725c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7260:	381ff465 	strb	w5, [x3], #-1
    7264:	cb040000 	sub	x0, x0, x4
    7268:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    726c:	cb020000 	sub	x0, x0, x2
    7270:	8b010013 	add	x19, x0, x1
    7274:	eb03013f 	cmp	x9, x3
    7278:	54003440 	b.eq	7900 <fwp_write+0xa40>  // b.none
    727c:	9b467e60 	smulh	x0, x19, x6
    7280:	937ffe64 	asr	x4, x19, #63
    7284:	52800605 	mov	w5, #0x30                  	// #48
    7288:	cb040000 	sub	x0, x0, x4
    728c:	8b000400 	add	x0, x0, x0, lsl #1
    7290:	cb000260 	sub	x0, x19, x0
    7294:	91000c01 	add	x1, x0, #0x3
    7298:	9bc87c22 	umulh	x2, x1, x8
    729c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    72a0:	8b4204e2 	add	x2, x7, x2, lsr #1
    72a4:	eb020021 	subs	x1, x1, x2
    72a8:	54fffd60 	b.eq	7254 <fwp_write+0x394>  // b.none
    72ac:	f100043f 	cmp	x1, #0x1
    72b0:	54fffce1 	b.ne	724c <fwp_write+0x38c>  // b.any
    72b4:	d2800001 	mov	x1, #0x0                   	// #0
    72b8:	52800565 	mov	w5, #0x2b                  	// #43
    72bc:	17ffffe6 	b	7254 <fwp_write+0x394>
    72c0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    72c4:	f947f400 	ldr	x0, [x0, #4072]
    72c8:	f94127e2 	ldr	x2, [sp, #584]
    72cc:	f9400001 	ldr	x1, [x0]
    72d0:	eb010042 	subs	x2, x2, x1
    72d4:	d2800001 	mov	x1, #0x0                   	// #0
    72d8:	540023c1 	b.ne	7750 <fwp_write+0x890>  // b.any
    72dc:	f9413bf5 	ldr	x21, [sp, #624]
    72e0:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    72e4:	f9413ff6 	ldr	x22, [sp, #632]
    72e8:	aa1403e0 	mov	x0, x20
    72ec:	9100e021 	add	x1, x1, #0x38
    72f0:	d2800102 	mov	x2, #0x8                   	// #8
    72f4:	17ffff77 	b	70d0 <fwp_write+0x210>
    72f8:	aa1403e0 	mov	x0, x20
    72fc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    7300:	d28000c2 	mov	x2, #0x6                   	// #6
    7304:	91026021 	add	x1, x1, #0x98
    7308:	97fff042 	bl	3410 <buf_put>
    730c:	d2800015 	mov	x21, #0x0                   	// #0
    7310:	f9400263 	ldr	x3, [x19]
    7314:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7318:	54002c60 	b.eq	78a4 <fwp_write+0x9e4>  // b.none
    731c:	f9401f82 	ldr	x2, [x28, #56]
    7320:	f90143f7 	str	x23, [sp, #640]
    7324:	f90147f8 	str	x24, [sp, #648]
    7328:	d2800857 	mov	x23, #0x42                  	// #66
    732c:	f9014bf9 	str	x25, [sp, #656]
    7330:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0x410>
    7334:	f9014ffa 	str	x26, [sp, #664]
    7338:	910242d6 	add	x22, x22, #0x90
    733c:	d2800038 	mov	x24, #0x1                   	// #1
    7340:	f2a18017 	movk	x23, #0xc00, lsl #16
    7344:	d2809099 	mov	x25, #0x484                 	// #1156
    7348:	b40004a2 	cbz	x2, 73dc <fwp_write+0x51c>
    734c:	b9400040 	ldr	w0, [x2]
    7350:	7100701f 	cmp	w0, #0x1c
    7354:	540042c0 	b.eq	7bac <fwp_write+0xcec>  // b.none
    7358:	71006c1f 	cmp	w0, #0x1b
    735c:	54000408 	b.hi	73dc <fwp_write+0x51c>  // b.pmore
    7360:	9ac02301 	lsl	x1, x24, x0
    7364:	ea17003f 	tst	x1, x23
    7368:	540036a1 	b.ne	7a3c <fwp_write+0xb7c>  // b.any
    736c:	ea19003f 	tst	x1, x25
    7370:	54003521 	b.ne	7a14 <fwp_write+0xb54>  // b.any
    7374:	d2800424 	mov	x4, #0x21                  	// #33
    7378:	ea04003f 	tst	x1, x4
    737c:	54000300 	b.eq	73dc <fwp_write+0x51c>  // b.none
    7380:	b7f849c3 	tbnz	x3, #63, 7cb8 <fwp_write+0xdf8>
    7384:	91002261 	add	x1, x19, #0x8
    7388:	8b150021 	add	x1, x1, x21
    738c:	39400021 	ldrb	w1, [x1]
    7390:	7100001f 	cmp	w0, #0x0
    7394:	93401c23 	sxtb	x3, w1
    7398:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    739c:	d503201f 	nop
    73a0:	aa1403e0 	mov	x0, x20
    73a4:	52800003 	mov	w3, #0x0                   	// #0
    73a8:	97fffec6 	bl	6ec0 <fwp_write>
    73ac:	910006b5 	add	x21, x21, #0x1
    73b0:	f9400260 	ldr	x0, [x19]
    73b4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    73b8:	eb0002bf 	cmp	x21, x0
    73bc:	540026c2 	b.cs	7894 <fwp_write+0x9d4>  // b.hs, b.nlast
    73c0:	d2800042 	mov	x2, #0x2                   	// #2
    73c4:	aa1603e1 	mov	x1, x22
    73c8:	aa1403e0 	mov	x0, x20
    73cc:	97fff011 	bl	3410 <buf_put>
    73d0:	f9401f82 	ldr	x2, [x28, #56]
    73d4:	f9400263 	ldr	x3, [x19]
    73d8:	b5fffba2 	cbnz	x2, 734c <fwp_write+0x48c>
    73dc:	d37df2a0 	lsl	x0, x21, #3
    73e0:	b7f83f03 	tbnz	x3, #63, 7bc0 <fwp_write+0xd00>
    73e4:	91002261 	add	x1, x19, #0x8
    73e8:	8b000020 	add	x0, x1, x0
    73ec:	f9400001 	ldr	x1, [x0]
    73f0:	17ffffec 	b	73a0 <fwp_write+0x4e0>
    73f4:	a9400e62 	ldp	x2, x3, [x19]
    73f8:	b7f83ca3 	tbnz	x3, #63, 7b8c <fwp_write+0xccc>
    73fc:	910123f5 	add	x21, sp, #0x48
    7400:	aa1503e0 	mov	x0, x21
    7404:	97ffee87 	bl	2e20 <fwp_fmt_u128>
    7408:	aa1503e0 	mov	x0, x21
    740c:	97ffecc1 	bl	2710 <strlen@plt>
    7410:	aa1503e1 	mov	x1, x21
    7414:	aa0003e2 	mov	x2, x0
    7418:	17fffed0 	b	6f58 <fwp_write+0x98>
    741c:	fd015be8 	str	d8, [sp, #688]
    7420:	1e270268 	fmov	s8, w19
    7424:	fd015fe9 	str	d9, [sp, #696]
    7428:	1e282100 	fcmp	s8, s8
    742c:	54004d26 	b.vs	7dd0 <fwp_write+0xf10>
    7430:	1e20c101 	fabs	s1, s8
    7434:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7438:	1e270000 	fmov	s0, w0
    743c:	1e202020 	fcmp	s1, s0
    7440:	54002c0d 	b.le	79c0 <fwp_write+0xb00>
    7444:	1e202118 	fcmpe	s8, #0.0
    7448:	b0000022 	adrp	x2, c000 <fwp_main_thread+0x70>
    744c:	91304042 	add	x2, x2, #0xc10
    7450:	910123f5 	add	x21, sp, #0x48
    7454:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x70>
    7458:	913fa021 	add	x1, x1, #0xfe8
    745c:	aa1503e0 	mov	x0, x21
    7460:	9a81c041 	csel	x1, x2, x1, gt
    7464:	97ffed57 	bl	29c0 <strcpy@plt>
    7468:	aa1503e0 	mov	x0, x21
    746c:	97ffeca9 	bl	2710 <strlen@plt>
    7470:	aa1503e1 	mov	x1, x21
    7474:	aa0003e2 	mov	x2, x0
    7478:	aa1403e0 	mov	x0, x20
    747c:	97ffefe5 	bl	3410 <buf_put>
    7480:	f9413bf5 	ldr	x21, [sp, #624]
    7484:	f9413ff6 	ldr	x22, [sp, #632]
    7488:	f94153fb 	ldr	x27, [sp, #672]
    748c:	f94157fc 	ldr	x28, [sp, #680]
    7490:	fd415be8 	ldr	d8, [sp, #688]
    7494:	fd415fe9 	ldr	d9, [sp, #696]
    7498:	17fffeb6 	b	6f70 <fwp_write+0xb0>
    749c:	f9400276 	ldr	x22, [x19]
    74a0:	34002e03 	cbz	w3, 7a60 <fwp_write+0xba0>
    74a4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    74a8:	f947f400 	ldr	x0, [x0, #4072]
    74ac:	f94127e2 	ldr	x2, [sp, #584]
    74b0:	f9400001 	ldr	x1, [x0]
    74b4:	eb010042 	subs	x2, x2, x1
    74b8:	d2800001 	mov	x1, #0x0                   	// #0
    74bc:	540014a1 	b.ne	7750 <fwp_write+0x890>  // b.any
    74c0:	aa1603e2 	mov	x2, x22
    74c4:	91002261 	add	x1, x19, #0x8
    74c8:	f9413bf5 	ldr	x21, [sp, #624]
    74cc:	aa1403e0 	mov	x0, x20
    74d0:	f9413ff6 	ldr	x22, [sp, #632]
    74d4:	17fffeff 	b	70d0 <fwp_write+0x210>
    74d8:	fd015be8 	str	d8, [sp, #688]
    74dc:	9e670268 	fmov	d8, x19
    74e0:	fd015fe9 	str	d9, [sp, #696]
    74e4:	1e682100 	fcmp	d8, d8
    74e8:	54004746 	b.vs	7dd0 <fwp_write+0xf10>
    74ec:	1e60c101 	fabs	d1, d8
    74f0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    74f4:	9e670000 	fmov	d0, x0
    74f8:	910123f5 	add	x21, sp, #0x48
    74fc:	52800033 	mov	w19, #0x1                   	// #1
    7500:	1e602020 	fcmp	d1, d0
    7504:	540001ad 	b.le	7538 <fwp_write+0x678>
    7508:	1e602118 	fcmpe	d8, #0.0
    750c:	b0000022 	adrp	x2, c000 <fwp_main_thread+0x70>
    7510:	91304042 	add	x2, x2, #0xc10
    7514:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x70>
    7518:	913fa021 	add	x1, x1, #0xfe8
    751c:	aa1503e0 	mov	x0, x21
    7520:	9a81c041 	csel	x1, x2, x1, gt
    7524:	97ffed27 	bl	29c0 <strcpy@plt>
    7528:	17ffffd0 	b	7468 <fwp_write+0x5a8>
    752c:	11000673 	add	w19, w19, #0x1
    7530:	71004a7f 	cmp	w19, #0x12
    7534:	54003860 	b.eq	7c40 <fwp_write+0xd80>  // b.none
    7538:	1e604100 	fmov	d0, d8
    753c:	2a1303e1 	mov	w1, w19
    7540:	aa1503e0 	mov	x0, x21
    7544:	97fff0f4 	bl	3914 <fwp_format_g.constprop.0>
    7548:	aa1503e0 	mov	x0, x21
    754c:	d2800001 	mov	x1, #0x0                   	// #0
    7550:	97ffec84 	bl	2760 <strtod@plt>
    7554:	1e602100 	fcmp	d8, d0
    7558:	54fffea1 	b.ne	752c <fwp_write+0x66c>  // b.any
    755c:	aa1503e0 	mov	x0, x21
    7560:	97ffefe5 	bl	34f4 <fwp_finish_float>
    7564:	17ffffc1 	b	7468 <fwp_write+0x5a8>
    7568:	a9400e62 	ldp	x2, x3, [x19]
    756c:	910123f3 	add	x19, sp, #0x48
    7570:	aa1303e0 	mov	x0, x19
    7574:	97ffee2b 	bl	2e20 <fwp_fmt_u128>
    7578:	17fffe74 	b	6f48 <fwp_write+0x88>
    757c:	f90143f7 	str	x23, [sp, #640]
    7580:	f90147f8 	str	x24, [sp, #648]
    7584:	2a1303f8 	mov	w24, w19
    7588:	f9014bf9 	str	x25, [sp, #656]
    758c:	f9014ffa 	str	x26, [sp, #664]
    7590:	f13ffe7f 	cmp	x19, #0xfff
    7594:	54000049 	b.ls	759c <fwp_write+0x6dc>  // b.plast
    7598:	b9400278 	ldr	w24, [x19]
    759c:	f9400f80 	ldr	x0, [x28, #24]
    75a0:	2a1803f5 	mov	w21, w24
    75a4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    75a8:	d37ef6b9 	lsl	x25, x21, #2
    75ac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    75b0:	aa1603e0 	mov	x0, x22
    75b4:	97ffec57 	bl	2710 <strlen@plt>
    75b8:	aa1603e1 	mov	x1, x22
    75bc:	aa0003e2 	mov	x2, x0
    75c0:	aa1403e0 	mov	x0, x20
    75c4:	97ffef93 	bl	3410 <buf_put>
    75c8:	f9401780 	ldr	x0, [x28, #40]
    75cc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    75d0:	7100001f 	cmp	w0, #0x0
    75d4:	5400068d 	b.le	76a4 <fwp_write+0x7e4>
    75d8:	91002276 	add	x22, x19, #0x8
    75dc:	91001ff5 	add	x21, sp, #0x7
    75e0:	d280001b 	mov	x27, #0x0                   	// #0
    75e4:	5280041a 	mov	w26, #0x20                  	// #32
    75e8:	f9401b80 	ldr	x0, [x28, #48]
    75ec:	aa1503e1 	mov	x1, x21
    75f0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    75f4:	d2800022 	mov	x2, #0x1                   	// #1
    75f8:	f8786803 	ldr	x3, [x0, x24]
    75fc:	aa1403e0 	mov	x0, x20
    7600:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7604:	39001ffa 	strb	w26, [sp, #7]
    7608:	97ffef82 	bl	3410 <buf_put>
    760c:	f13ffeff 	cmp	x23, #0xfff
    7610:	b9400261 	ldr	w1, [x19]
    7614:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7618:	7100383f 	cmp	w1, #0xe
    761c:	54000160 	b.eq	7648 <fwp_write+0x788>  // b.none
    7620:	7100403f 	cmp	w1, #0x10
    7624:	54001a60 	b.eq	7970 <fwp_write+0xab0>  // b.none
    7628:	7100283f 	cmp	w1, #0xa
    762c:	54002aa0 	b.eq	7b80 <fwp_write+0xcc0>  // b.none
    7630:	540014ac 	b.gt	78c4 <fwp_write+0xa04>
    7634:	71000c3f 	cmp	w1, #0x3
    7638:	540029ac 	b.gt	7b6c <fwp_write+0xcac>
    763c:	d37ffee0 	lsr	x0, x23, #63
    7640:	37f814a1 	tbnz	w1, #31, 78d4 <fwp_write+0xa14>
    7644:	d503201f 	nop
    7648:	34001460 	cbz	w0, 78d4 <fwp_write+0xa14>
    764c:	52800503 	mov	w3, #0x28                  	// #40
    7650:	aa1503e1 	mov	x1, x21
    7654:	aa1403e0 	mov	x0, x20
    7658:	d2800022 	mov	x2, #0x1                   	// #1
    765c:	39001fe3 	strb	w3, [sp, #7]
    7660:	97ffef6c 	bl	3410 <buf_put>
    7664:	aa1303e2 	mov	x2, x19
    7668:	aa1703e1 	mov	x1, x23
    766c:	aa1403e0 	mov	x0, x20
    7670:	52800003 	mov	w3, #0x0                   	// #0
    7674:	97fffe13 	bl	6ec0 <fwp_write>
    7678:	52800523 	mov	w3, #0x29                  	// #41
    767c:	aa1503e1 	mov	x1, x21
    7680:	aa1403e0 	mov	x0, x20
    7684:	d2800022 	mov	x2, #0x1                   	// #1
    7688:	39001fe3 	strb	w3, [sp, #7]
    768c:	97ffef61 	bl	3410 <buf_put>
    7690:	f9401780 	ldr	x0, [x28, #40]
    7694:	9100077b 	add	x27, x27, #0x1
    7698:	b8796800 	ldr	w0, [x0, x25]
    769c:	6b1b001f 	cmp	w0, w27
    76a0:	54fffa4c 	b.gt	75e8 <fwp_write+0x728>
    76a4:	f9413bf5 	ldr	x21, [sp, #624]
    76a8:	f9413ff6 	ldr	x22, [sp, #632]
    76ac:	f94143f7 	ldr	x23, [sp, #640]
    76b0:	f94147f8 	ldr	x24, [sp, #648]
    76b4:	f9414bf9 	ldr	x25, [sp, #656]
    76b8:	f9414ffa 	ldr	x26, [sp, #664]
    76bc:	f94153fb 	ldr	x27, [sp, #672]
    76c0:	f94157fc 	ldr	x28, [sp, #680]
    76c4:	17fffe2b 	b	6f70 <fwp_write+0xb0>
    76c8:	52800783 	mov	w3, #0x3c                  	// #60
    76cc:	91001ff3 	add	x19, sp, #0x7
    76d0:	aa1303e1 	mov	x1, x19
    76d4:	d2800022 	mov	x2, #0x1                   	// #1
    76d8:	aa1403e0 	mov	x0, x20
    76dc:	39001fe3 	strb	w3, [sp, #7]
    76e0:	97ffef4c 	bl	3410 <buf_put>
    76e4:	f9400795 	ldr	x21, [x28, #8]
    76e8:	aa1503e0 	mov	x0, x21
    76ec:	97ffec09 	bl	2710 <strlen@plt>
    76f0:	aa1503e1 	mov	x1, x21
    76f4:	aa0003e2 	mov	x2, x0
    76f8:	aa1403e0 	mov	x0, x20
    76fc:	97ffef45 	bl	3410 <buf_put>
    7700:	528007c3 	mov	w3, #0x3e                  	// #62
    7704:	aa1303e1 	mov	x1, x19
    7708:	aa1403e0 	mov	x0, x20
    770c:	d2800022 	mov	x2, #0x1                   	// #1
    7710:	39001fe3 	strb	w3, [sp, #7]
    7714:	17fffe12 	b	6f5c <fwp_write+0x9c>
    7718:	f100067f 	cmp	x19, #0x1
    771c:	540025a0 	b.eq	7bd0 <fwp_write+0xd10>  // b.none
    7720:	b100067f 	cmn	x19, #0x1
    7724:	54002bc0 	b.eq	7c9c <fwp_write+0xddc>  // b.none
    7728:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x70>
    772c:	913fc021 	add	x1, x1, #0xff0
    7730:	d2800022 	mov	x2, #0x1                   	// #1
    7734:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7738:	f947f400 	ldr	x0, [x0, #4072]
    773c:	f94127e4 	ldr	x4, [sp, #584]
    7740:	f9400003 	ldr	x3, [x0]
    7744:	eb030084 	subs	x4, x4, x3
    7748:	d2800003 	mov	x3, #0x0                   	// #0
    774c:	54ffebe0 	b.eq	74c8 <fwp_write+0x608>  // b.none
    7750:	f90143f7 	str	x23, [sp, #640]
    7754:	f90147f8 	str	x24, [sp, #648]
    7758:	f9014bf9 	str	x25, [sp, #656]
    775c:	f9014ffa 	str	x26, [sp, #664]
    7760:	fd015be8 	str	d8, [sp, #688]
    7764:	fd015fe9 	str	d9, [sp, #696]
    7768:	97ffec46 	bl	2880 <__stack_chk_fail@plt>
    776c:	52800b63 	mov	w3, #0x5b                  	// #91
    7770:	91001ff5 	add	x21, sp, #0x7
    7774:	aa1503e1 	mov	x1, x21
    7778:	aa1403e0 	mov	x0, x20
    777c:	d2800022 	mov	x2, #0x1                   	// #1
    7780:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0x410>
    7784:	910242d6 	add	x22, x22, #0x90
    7788:	39001fe3 	strb	w3, [sp, #7]
    778c:	97ffef21 	bl	3410 <buf_put>
    7790:	b4000273 	cbz	x19, 77dc <fwp_write+0x91c>
    7794:	f9400661 	ldr	x1, [x19, #8]
    7798:	aa1403e0 	mov	x0, x20
    779c:	f9401f82 	ldr	x2, [x28, #56]
    77a0:	52800003 	mov	w3, #0x0                   	// #0
    77a4:	97fffdc7 	bl	6ec0 <fwp_write>
    77a8:	f9400a73 	ldr	x19, [x19, #16]
    77ac:	b4000193 	cbz	x19, 77dc <fwp_write+0x91c>
    77b0:	aa1603e1 	mov	x1, x22
    77b4:	aa1403e0 	mov	x0, x20
    77b8:	d2800042 	mov	x2, #0x2                   	// #2
    77bc:	97ffef15 	bl	3410 <buf_put>
    77c0:	f9400661 	ldr	x1, [x19, #8]
    77c4:	aa1403e0 	mov	x0, x20
    77c8:	f9401f82 	ldr	x2, [x28, #56]
    77cc:	52800003 	mov	w3, #0x0                   	// #0
    77d0:	97fffdbc 	bl	6ec0 <fwp_write>
    77d4:	f9400a73 	ldr	x19, [x19, #16]
    77d8:	b5fffed3 	cbnz	x19, 77b0 <fwp_write+0x8f0>
    77dc:	52800ba3 	mov	w3, #0x5d                  	// #93
    77e0:	aa1503e1 	mov	x1, x21
    77e4:	aa1403e0 	mov	x0, x20
    77e8:	d2800022 	mov	x2, #0x1                   	// #1
    77ec:	39001fe3 	strb	w3, [sp, #7]
    77f0:	17fffddb 	b	6f5c <fwp_write+0x9c>
    77f4:	aa1403e0 	mov	x0, x20
    77f8:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    77fc:	d28000c2 	mov	x2, #0x6                   	// #6
    7800:	91020021 	add	x1, x1, #0x80
    7804:	97ffef03 	bl	3410 <buf_put>
    7808:	f9400260 	ldr	x0, [x19]
    780c:	b40004c0 	cbz	x0, 78a4 <fwp_write+0x9e4>
    7810:	910123f5 	add	x21, sp, #0x48
    7814:	91002276 	add	x22, x19, #0x8
    7818:	f90143f7 	str	x23, [sp, #640]
    781c:	d2800017 	mov	x23, #0x0                   	// #0
    7820:	f90147f8 	str	x24, [sp, #648]
    7824:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0x410>
    7828:	91022318 	add	x24, x24, #0x88
    782c:	f9014bf9 	str	x25, [sp, #656]
    7830:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x410>
    7834:	91024339 	add	x25, x25, #0x90
    7838:	f9014ffa 	str	x26, [sp, #664]
    783c:	14000005 	b	7850 <fwp_write+0x990>
    7840:	aa1903e1 	mov	x1, x25
    7844:	aa1403e0 	mov	x0, x20
    7848:	d2800042 	mov	x2, #0x2                   	// #2
    784c:	97ffeef1 	bl	3410 <buf_put>
    7850:	38776ac5 	ldrb	w5, [x22, x23]
    7854:	d2804003 	mov	x3, #0x200                 	// #512
    7858:	aa1803e4 	mov	x4, x24
    785c:	aa0303e1 	mov	x1, x3
    7860:	52800042 	mov	w2, #0x2                   	// #2
    7864:	aa1503e0 	mov	x0, x21
    7868:	910006f7 	add	x23, x23, #0x1
    786c:	97ffebe1 	bl	27f0 <__snprintf_chk@plt>
    7870:	aa1503e0 	mov	x0, x21
    7874:	97ffeba7 	bl	2710 <strlen@plt>
    7878:	aa1503e1 	mov	x1, x21
    787c:	aa0003e2 	mov	x2, x0
    7880:	aa1403e0 	mov	x0, x20
    7884:	97ffeee3 	bl	3410 <buf_put>
    7888:	f9400260 	ldr	x0, [x19]
    788c:	eb17001f 	cmp	x0, x23
    7890:	54fffd88 	b.hi	7840 <fwp_write+0x980>  // b.pmore
    7894:	f94143f7 	ldr	x23, [sp, #640]
    7898:	f94147f8 	ldr	x24, [sp, #648]
    789c:	f9414bf9 	ldr	x25, [sp, #656]
    78a0:	f9414ffa 	ldr	x26, [sp, #664]
    78a4:	52800ba3 	mov	w3, #0x5d                  	// #93
    78a8:	aa1403e0 	mov	x0, x20
    78ac:	91001fe1 	add	x1, sp, #0x7
    78b0:	d2800022 	mov	x2, #0x1                   	// #1
    78b4:	39001fe3 	strb	w3, [sp, #7]
    78b8:	17fffda9 	b	6f5c <fwp_write+0x9c>
    78bc:	52800fa3 	mov	w3, #0x7d                  	// #125
    78c0:	17fffe44 	b	71d0 <fwp_write+0x310>
    78c4:	f10002ff 	cmp	x23, #0x0
    78c8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    78cc:	71002c3f 	cmp	w1, #0xb
    78d0:	54ffebc0 	b.eq	7648 <fwp_write+0x788>  // b.none
    78d4:	aa1303e2 	mov	x2, x19
    78d8:	aa1703e1 	mov	x1, x23
    78dc:	aa1403e0 	mov	x0, x20
    78e0:	52800003 	mov	w3, #0x0                   	// #0
    78e4:	97fffd77 	bl	6ec0 <fwp_write>
    78e8:	17ffff6a 	b	7690 <fwp_write+0x7d0>
    78ec:	aa1403e0 	mov	x0, x20
    78f0:	91001fe1 	add	x1, sp, #0x7
    78f4:	52800fa3 	mov	w3, #0x7d                  	// #125
    78f8:	d2800022 	mov	x2, #0x1                   	// #1
    78fc:	17fffe38 	b	71dc <fwp_write+0x31c>
    7900:	a9400281 	ldp	x1, x0, [x20]
    7904:	91000800 	add	x0, x0, #0x2
    7908:	8b160000 	add	x0, x0, x22
    790c:	f9000680 	str	x0, [x20, #8]
    7910:	3820683f 	strb	wzr, [x1, x0]
    7914:	f9413bf5 	ldr	x21, [sp, #624]
    7918:	f9413ff6 	ldr	x22, [sp, #632]
    791c:	f94153fb 	ldr	x27, [sp, #672]
    7920:	f94157fc 	ldr	x28, [sp, #680]
    7924:	17fffd93 	b	6f70 <fwp_write+0xb0>
    7928:	f9400f80 	ldr	x0, [x28, #24]
    792c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7930:	aa1b03e0 	mov	x0, x27
    7934:	97ffeb77 	bl	2710 <strlen@plt>
    7938:	aa1b03e1 	mov	x1, x27
    793c:	aa0003e2 	mov	x2, x0
    7940:	aa1403e0 	mov	x0, x20
    7944:	97ffeeb3 	bl	3410 <buf_put>
    7948:	aa1903e1 	mov	x1, x25
    794c:	aa1403e0 	mov	x0, x20
    7950:	d2800062 	mov	x2, #0x3                   	// #3
    7954:	97ffeeaf 	bl	3410 <buf_put>
    7958:	17fffe10 	b	7198 <fwp_write+0x2d8>
    795c:	aa1a03e1 	mov	x1, x26
    7960:	aa1403e0 	mov	x0, x20
    7964:	d2800042 	mov	x2, #0x2                   	// #2
    7968:	97ffeeaa 	bl	3410 <buf_put>
    796c:	17fffe09 	b	7190 <fwp_write+0x2d0>
    7970:	f9400660 	ldr	x0, [x19, #8]
    7974:	b4fffb00 	cbz	x0, 78d4 <fwp_write+0xa14>
    7978:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    797c:	9102a021 	add	x1, x1, #0xa8
    7980:	97ffebe0 	bl	2900 <strcmp@plt>
    7984:	7100001f 	cmp	w0, #0x0
    7988:	1a9f07e0 	cset	w0, ne	// ne = any
    798c:	17ffff2f 	b	7648 <fwp_write+0x788>
    7990:	aa1403e0 	mov	x0, x20
    7994:	d2800042 	mov	x2, #0x2                   	// #2
    7998:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    799c:	91028021 	add	x1, x1, #0xa0
    79a0:	97ffee9c 	bl	3410 <buf_put>
    79a4:	91004261 	add	x1, x19, #0x10
    79a8:	aa1403e0 	mov	x0, x20
    79ac:	f9402382 	ldr	x2, [x28, #64]
    79b0:	52800003 	mov	w3, #0x0                   	// #0
    79b4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    79b8:	97fffd42 	bl	6ec0 <fwp_write>
    79bc:	17fffd9c 	b	702c <fwp_write+0x16c>
    79c0:	1e22c109 	fcvt	d9, s8
    79c4:	910123f5 	add	x21, sp, #0x48
    79c8:	52800033 	mov	w19, #0x1                   	// #1
    79cc:	d503201f 	nop
    79d0:	1e604120 	fmov	d0, d9
    79d4:	2a1303e1 	mov	w1, w19
    79d8:	aa1503e0 	mov	x0, x21
    79dc:	97ffefce 	bl	3914 <fwp_format_g.constprop.0>
    79e0:	aa1503e0 	mov	x0, x21
    79e4:	d2800001 	mov	x1, #0x0                   	// #0
    79e8:	97ffebd2 	bl	2930 <strtof@plt>
    79ec:	1e202100 	fcmp	s8, s0
    79f0:	54ffdb60 	b.eq	755c <fwp_write+0x69c>  // b.none
    79f4:	11000673 	add	w19, w19, #0x1
    79f8:	71002a7f 	cmp	w19, #0xa
    79fc:	54fffea1 	b.ne	79d0 <fwp_write+0xb10>  // b.any
    7a00:	1e604120 	fmov	d0, d9
    7a04:	aa1503e0 	mov	x0, x21
    7a08:	52800121 	mov	w1, #0x9                   	// #9
    7a0c:	97ffefc2 	bl	3914 <fwp_format_g.constprop.0>
    7a10:	17fffed3 	b	755c <fwp_write+0x69c>
    7a14:	d37ef6a1 	lsl	x1, x21, #2
    7a18:	b7f81563 	tbnz	x3, #63, 7cc4 <fwp_write+0xe04>
    7a1c:	91002263 	add	x3, x19, #0x8
    7a20:	8b010061 	add	x1, x3, x1
    7a24:	b9400023 	ldr	w3, [x1]
    7a28:	7100081f 	cmp	w0, #0x2
    7a2c:	2a0303e1 	mov	w1, w3
    7a30:	93407c63 	sxtw	x3, w3
    7a34:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7a38:	17fffe5a 	b	73a0 <fwp_write+0x4e0>
    7a3c:	d37ffaa1 	lsl	x1, x21, #1
    7a40:	b7f81363 	tbnz	x3, #63, 7cac <fwp_write+0xdec>
    7a44:	91002263 	add	x3, x19, #0x8
    7a48:	8b010061 	add	x1, x3, x1
    7a4c:	79400021 	ldrh	w1, [x1]
    7a50:	7100041f 	cmp	w0, #0x1
    7a54:	93403c23 	sxth	x3, w1
    7a58:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7a5c:	17fffe51 	b	73a0 <fwp_write+0x4e0>
    7a60:	52800443 	mov	w3, #0x22                  	// #34
    7a64:	91001ff5 	add	x21, sp, #0x7
    7a68:	91002273 	add	x19, x19, #0x8
    7a6c:	aa1503e1 	mov	x1, x21
    7a70:	aa1403e0 	mov	x0, x20
    7a74:	d2800022 	mov	x2, #0x1                   	// #1
    7a78:	39001fe3 	strb	w3, [sp, #7]
    7a7c:	f90143f7 	str	x23, [sp, #640]
    7a80:	8b160277 	add	x23, x19, x22
    7a84:	f90147f8 	str	x24, [sp, #648]
    7a88:	97ffee62 	bl	3410 <buf_put>
    7a8c:	b4000696 	cbz	x22, 7b5c <fwp_write+0xc9c>
    7a90:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0x410>
    7a94:	91014318 	add	x24, x24, #0x50
    7a98:	f9014bf9 	str	x25, [sp, #656]
    7a9c:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x410>
    7aa0:	9101c339 	add	x25, x25, #0x70
    7aa4:	f9014ffa 	str	x26, [sp, #664]
    7aa8:	1400000d 	b	7adc <fwp_write+0xc1c>
    7aac:	710024bf 	cmp	w5, #0x9
    7ab0:	54000460 	b.eq	7b3c <fwp_write+0xc7c>  // b.none
    7ab4:	710028bf 	cmp	w5, #0xa
    7ab8:	54000a61 	b.ne	7c04 <fwp_write+0xd44>  // b.any
    7abc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    7ac0:	aa1403e0 	mov	x0, x20
    7ac4:	91018021 	add	x1, x1, #0x60
    7ac8:	d2800042 	mov	x2, #0x2                   	// #2
    7acc:	97ffee51 	bl	3410 <buf_put>
    7ad0:	91000673 	add	x19, x19, #0x1
    7ad4:	eb17027f 	cmp	x19, x23
    7ad8:	540003e0 	b.eq	7b54 <fwp_write+0xc94>  // b.none
    7adc:	39400265 	ldrb	w5, [x19]
    7ae0:	710034bf 	cmp	w5, #0xd
    7ae4:	54000180 	b.eq	7b14 <fwp_write+0xc54>  // b.none
    7ae8:	54fffe29 	b.ls	7aac <fwp_write+0xbec>  // b.plast
    7aec:	710088bf 	cmp	w5, #0x22
    7af0:	540001c0 	b.eq	7b28 <fwp_write+0xc68>  // b.none
    7af4:	710170bf 	cmp	w5, #0x5c
    7af8:	54000741 	b.ne	7be0 <fwp_write+0xd20>  // b.any
    7afc:	aa1403e0 	mov	x0, x20
    7b00:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    7b04:	d2800042 	mov	x2, #0x2                   	// #2
    7b08:	91016021 	add	x1, x1, #0x58
    7b0c:	97ffee41 	bl	3410 <buf_put>
    7b10:	17fffff0 	b	7ad0 <fwp_write+0xc10>
    7b14:	aa1903e1 	mov	x1, x25
    7b18:	aa1403e0 	mov	x0, x20
    7b1c:	d2800042 	mov	x2, #0x2                   	// #2
    7b20:	97ffee3c 	bl	3410 <buf_put>
    7b24:	17ffffeb 	b	7ad0 <fwp_write+0xc10>
    7b28:	aa1803e1 	mov	x1, x24
    7b2c:	aa1403e0 	mov	x0, x20
    7b30:	d2800042 	mov	x2, #0x2                   	// #2
    7b34:	97ffee37 	bl	3410 <buf_put>
    7b38:	17ffffe6 	b	7ad0 <fwp_write+0xc10>
    7b3c:	aa1403e0 	mov	x0, x20
    7b40:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    7b44:	d2800042 	mov	x2, #0x2                   	// #2
    7b48:	9101a021 	add	x1, x1, #0x68
    7b4c:	97ffee31 	bl	3410 <buf_put>
    7b50:	17ffffe0 	b	7ad0 <fwp_write+0xc10>
    7b54:	f9414bf9 	ldr	x25, [sp, #656]
    7b58:	f9414ffa 	ldr	x26, [sp, #664]
    7b5c:	aa1503e1 	mov	x1, x21
    7b60:	aa1403e0 	mov	x0, x20
    7b64:	52800443 	mov	w3, #0x22                  	// #34
    7b68:	17fffd9c 	b	71d8 <fwp_write+0x318>
    7b6c:	7100103f 	cmp	w1, #0x4
    7b70:	54ffeb21 	b.ne	78d4 <fwp_write+0xa14>  // b.any
    7b74:	f94006e0 	ldr	x0, [x23, #8]
    7b78:	d37ffc00 	lsr	x0, x0, #63
    7b7c:	17fffeb3 	b	7648 <fwp_write+0x788>
    7b80:	710002ff 	cmp	w23, #0x0
    7b84:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7b88:	17fffeb0 	b	7648 <fwp_write+0x788>
    7b8c:	528005a1 	mov	w1, #0x2d                  	// #45
    7b90:	eb0203e2 	negs	x2, x2
    7b94:	da0303e3 	ngc	x3, x3
    7b98:	910127e0 	add	x0, sp, #0x49
    7b9c:	910123f5 	add	x21, sp, #0x48
    7ba0:	390123e1 	strb	w1, [sp, #72]
    7ba4:	97ffec9f 	bl	2e20 <fwp_fmt_u128>
    7ba8:	17fffe18 	b	7408 <fwp_write+0x548>
    7bac:	d37ceea1 	lsl	x1, x21, #4
    7bb0:	b7f810a3 	tbnz	x3, #63, 7dc4 <fwp_write+0xf04>
    7bb4:	91002260 	add	x0, x19, #0x8
    7bb8:	8b010001 	add	x1, x0, x1
    7bbc:	17fffdf9 	b	73a0 <fwp_write+0x4e0>
    7bc0:	f9400a61 	ldr	x1, [x19, #16]
    7bc4:	8b010000 	add	x0, x0, x1
    7bc8:	f9400001 	ldr	x1, [x0]
    7bcc:	17fffdf5 	b	73a0 <fwp_write+0x4e0>
    7bd0:	b0000021 	adrp	x1, c000 <fwp_main_thread+0x70>
    7bd4:	d2800042 	mov	x2, #0x2                   	// #2
    7bd8:	913fe021 	add	x1, x1, #0xff8
    7bdc:	17fffed6 	b	7734 <fwp_write+0x874>
    7be0:	7101fcbf 	cmp	w5, #0x7f
    7be4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7be8:	540000e9 	b.ls	7c04 <fwp_write+0xd44>  // b.plast
    7bec:	aa1503e1 	mov	x1, x21
    7bf0:	aa1403e0 	mov	x0, x20
    7bf4:	d2800022 	mov	x2, #0x1                   	// #1
    7bf8:	39001fe5 	strb	w5, [sp, #7]
    7bfc:	97ffee05 	bl	3410 <buf_put>
    7c00:	17ffffb4 	b	7ad0 <fwp_write+0xc10>
    7c04:	d2800203 	mov	x3, #0x10                  	// #16
    7c08:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0x410>
    7c0c:	aa0303e1 	mov	x1, x3
    7c10:	9101e084 	add	x4, x4, #0x78
    7c14:	910123f6 	add	x22, sp, #0x48
    7c18:	52800042 	mov	w2, #0x2                   	// #2
    7c1c:	aa1603e0 	mov	x0, x22
    7c20:	97ffeaf4 	bl	27f0 <__snprintf_chk@plt>
    7c24:	aa1603e0 	mov	x0, x22
    7c28:	97ffeaba 	bl	2710 <strlen@plt>
    7c2c:	aa1603e1 	mov	x1, x22
    7c30:	aa0003e2 	mov	x2, x0
    7c34:	aa1403e0 	mov	x0, x20
    7c38:	97ffedf6 	bl	3410 <buf_put>
    7c3c:	17ffffa5 	b	7ad0 <fwp_write+0xc10>
    7c40:	1e604100 	fmov	d0, d8
    7c44:	aa1503e0 	mov	x0, x21
    7c48:	52800221 	mov	w1, #0x11                  	// #17
    7c4c:	97ffef32 	bl	3914 <fwp_format_g.constprop.0>
    7c50:	17fffe43 	b	755c <fwp_write+0x69c>
    7c54:	b9401040 	ldr	w0, [x2, #16]
    7c58:	350003c0 	cbnz	w0, 7cd0 <fwp_write+0xe10>
    7c5c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7c60:	f947f400 	ldr	x0, [x0, #4072]
    7c64:	f94127e2 	ldr	x2, [sp, #584]
    7c68:	f9400001 	ldr	x1, [x0]
    7c6c:	eb010042 	subs	x2, x2, x1
    7c70:	d2800001 	mov	x1, #0x0                   	// #0
    7c74:	54ffd721 	b.ne	7758 <fwp_write+0x898>  // b.any
    7c78:	f9413bf5 	ldr	x21, [sp, #624]
    7c7c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    7c80:	f9413ff6 	ldr	x22, [sp, #632]
    7c84:	aa1403e0 	mov	x0, x20
    7c88:	f94143f7 	ldr	x23, [sp, #640]
    7c8c:	91032021 	add	x1, x1, #0xc8
    7c90:	f94147f8 	ldr	x24, [sp, #648]
    7c94:	d2800042 	mov	x2, #0x2                   	// #2
    7c98:	17fffd0e 	b	70d0 <fwp_write+0x210>
    7c9c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x410>
    7ca0:	d2800042 	mov	x2, #0x2                   	// #2
    7ca4:	91000021 	add	x1, x1, #0x0
    7ca8:	17fffea3 	b	7734 <fwp_write+0x874>
    7cac:	f9400a63 	ldr	x3, [x19, #16]
    7cb0:	8b030021 	add	x1, x1, x3
    7cb4:	17ffff66 	b	7a4c <fwp_write+0xb8c>
    7cb8:	f9400a61 	ldr	x1, [x19, #16]
    7cbc:	8b0102a1 	add	x1, x21, x1
    7cc0:	17fffdb3 	b	738c <fwp_write+0x4cc>
    7cc4:	f9400a63 	ldr	x3, [x19, #16]
    7cc8:	8b030021 	add	x1, x1, x3
    7ccc:	17ffff56 	b	7a24 <fwp_write+0xb64>
    7cd0:	b9404840 	ldr	w0, [x2, #72]
    7cd4:	91001ff5 	add	x21, sp, #0x7
    7cd8:	34ffa360 	cbz	w0, 7144 <fwp_write+0x284>
    7cdc:	52800503 	mov	w3, #0x28                  	// #40
    7ce0:	aa1403e0 	mov	x0, x20
    7ce4:	aa1503e1 	mov	x1, x21
    7ce8:	d2800022 	mov	x2, #0x1                   	// #1
    7cec:	39001fe3 	strb	w3, [sp, #7]
    7cf0:	97ffedc8 	bl	3410 <buf_put>
    7cf4:	b9401380 	ldr	w0, [x28, #16]
    7cf8:	52800038 	mov	w24, #0x1                   	// #1
    7cfc:	7100001f 	cmp	w0, #0x0
    7d00:	54ffa36c 	b.gt	716c <fwp_write+0x2ac>
    7d04:	17fffd32 	b	71cc <fwp_write+0x30c>
    7d08:	f9014bf9 	str	x25, [sp, #656]
    7d0c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xf3a8>
    7d10:	f9014ffa 	str	x26, [sp, #664]
    7d14:	f9400676 	ldr	x22, [x19, #8]
    7d18:	910aa333 	add	x19, x25, #0x2a8
    7d1c:	91002273 	add	x19, x19, #0x8
    7d20:	937ffed8 	asr	x24, x22, #63
    7d24:	aa1802c0 	orr	x0, x22, x24
    7d28:	b5000320 	cbnz	x0, 7d8c <fwp_write+0xecc>
    7d2c:	110006b5 	add	w21, w21, #0x1
    7d30:	710016bf 	cmp	w21, #0x5
    7d34:	54ffffc1 	b.ne	7d2c <fwp_write+0xe6c>  // b.any
    7d38:	b7f80578 	tbnz	x24, #63, 7de4 <fwp_write+0xf24>
    7d3c:	910023f3 	add	x19, sp, #0x8
    7d40:	aa1603e2 	mov	x2, x22
    7d44:	aa1303e0 	mov	x0, x19
    7d48:	d2800003 	mov	x3, #0x0                   	// #0
    7d4c:	97ffec35 	bl	2e20 <fwp_fmt_u128>
    7d50:	910123f5 	add	x21, sp, #0x48
    7d54:	d0000023 	adrp	x3, d000 <_IO_stdin_used+0x410>
    7d58:	aa1303e4 	mov	x4, x19
    7d5c:	aa1503e0 	mov	x0, x21
    7d60:	91030063 	add	x3, x3, #0xc0
    7d64:	d2804002 	mov	x2, #0x200                 	// #512
    7d68:	52800041 	mov	w1, #0x2                   	// #2
    7d6c:	97ffea6d 	bl	2720 <__sprintf_chk@plt>
    7d70:	aa1503e0 	mov	x0, x21
    7d74:	97ffea67 	bl	2710 <strlen@plt>
    7d78:	aa1503e1 	mov	x1, x21
    7d7c:	aa0003e2 	mov	x2, x0
    7d80:	aa1403e0 	mov	x0, x20
    7d84:	97ffeda3 	bl	3410 <buf_put>
    7d88:	17fffe47 	b	76a4 <fwp_write+0x7e4>
    7d8c:	f9400277 	ldr	x23, [x19]
    7d90:	aa1603e0 	mov	x0, x22
    7d94:	aa1803e1 	mov	x1, x24
    7d98:	aa1703e2 	mov	x2, x23
    7d9c:	937ffefa 	asr	x26, x23, #63
    7da0:	aa1a03e3 	mov	x3, x26
    7da4:	940012ab 	bl	c850 <__modti3>
    7da8:	aa010000 	orr	x0, x0, x1
    7dac:	b40002c0 	cbz	x0, 7e04 <fwp_write+0xf44>
    7db0:	110006b5 	add	w21, w21, #0x1
    7db4:	91004273 	add	x19, x19, #0x10
    7db8:	710016bf 	cmp	w21, #0x5
    7dbc:	54fffe81 	b.ne	7d8c <fwp_write+0xecc>  // b.any
    7dc0:	17ffffde 	b	7d38 <fwp_write+0xe78>
    7dc4:	f9400a60 	ldr	x0, [x19, #16]
    7dc8:	8b000021 	add	x1, x1, x0
    7dcc:	17fffd75 	b	73a0 <fwp_write+0x4e0>
    7dd0:	528c29c0 	mov	w0, #0x614e                	// #24910
    7dd4:	910123f5 	add	x21, sp, #0x48
    7dd8:	72a009c0 	movk	w0, #0x4e, lsl #16
    7ddc:	b9004be0 	str	w0, [sp, #72]
    7de0:	17fffda2 	b	7468 <fwp_write+0x5a8>
    7de4:	528005a1 	mov	w1, #0x2d                  	// #45
    7de8:	eb1603e2 	negs	x2, x22
    7dec:	da1803e3 	ngc	x3, x24
    7df0:	910027e0 	add	x0, sp, #0x9
    7df4:	910023f3 	add	x19, sp, #0x8
    7df8:	390023e1 	strb	w1, [sp, #8]
    7dfc:	97ffec09 	bl	2e20 <fwp_fmt_u128>
    7e00:	17ffffd4 	b	7d50 <fwp_write+0xe90>
    7e04:	aa1703e2 	mov	x2, x23
    7e08:	aa1a03e3 	mov	x3, x26
    7e0c:	aa1603e0 	mov	x0, x22
    7e10:	aa1803e1 	mov	x1, x24
    7e14:	940011af 	bl	c4d0 <__divti3>
    7e18:	aa0003e2 	mov	x2, x0
    7e1c:	aa0103e3 	mov	x3, x1
    7e20:	b7f80201 	tbnz	x1, #63, 7e60 <fwp_write+0xfa0>
    7e24:	910023f3 	add	x19, sp, #0x8
    7e28:	aa1303e0 	mov	x0, x19
    7e2c:	97ffebfd 	bl	2e20 <fwp_fmt_u128>
    7e30:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7e34:	910aa339 	add	x25, x25, #0x2a8
    7e38:	910123f5 	add	x21, sp, #0x48
    7e3c:	aa1303e4 	mov	x4, x19
    7e40:	aa1503e0 	mov	x0, x21
    7e44:	d0000023 	adrp	x3, d000 <_IO_stdin_used+0x410>
    7e48:	f8616b25 	ldr	x5, [x25, x1]
    7e4c:	9102e063 	add	x3, x3, #0xb8
    7e50:	d2804002 	mov	x2, #0x200                 	// #512
    7e54:	52800041 	mov	w1, #0x2                   	// #2
    7e58:	97ffea32 	bl	2720 <__sprintf_chk@plt>
    7e5c:	17ffffc5 	b	7d70 <fwp_write+0xeb0>
    7e60:	528005a4 	mov	w4, #0x2d                  	// #45
    7e64:	eb0003e2 	negs	x2, x0
    7e68:	da0103e3 	ngc	x3, x1
    7e6c:	910027e0 	add	x0, sp, #0x9
    7e70:	910023f3 	add	x19, sp, #0x8
    7e74:	390023e4 	strb	w4, [sp, #8]
    7e78:	97ffebea 	bl	2e20 <fwp_fmt_u128>
    7e7c:	17ffffed 	b	7e30 <fwp_write+0xf70>
    7e80:	f9013bf5 	str	x21, [sp, #624]
    7e84:	f9013ff6 	str	x22, [sp, #632]
    7e88:	f90143f7 	str	x23, [sp, #640]
    7e8c:	f90147f8 	str	x24, [sp, #648]
    7e90:	f9014bf9 	str	x25, [sp, #656]
    7e94:	f9014ffa 	str	x26, [sp, #664]
    7e98:	f90153fb 	str	x27, [sp, #672]
    7e9c:	f90157fc 	str	x28, [sp, #680]
    7ea0:	fd015be8 	str	d8, [sp, #688]
    7ea4:	fd015fe9 	str	d9, [sp, #696]
    7ea8:	97ffea76 	bl	2880 <__stack_chk_fail@plt>
    7eac:	d503201f 	nop

0000000000007eb0 <fwp_hof0.constprop.0>:
    7eb0:	d10543ff 	sub	sp, sp, #0x150
    7eb4:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    7eb8:	f947f442 	ldr	x2, [x2, #4072]
    7ebc:	a90e7bfd 	stp	x29, x30, [sp, #224]
    7ec0:	910383fd 	add	x29, sp, #0xe0
    7ec4:	f90023e0 	str	x0, [sp, #64]
    7ec8:	f9400040 	ldr	x0, [x2]
    7ecc:	f9006fe0 	str	x0, [sp, #216]
    7ed0:	d2800000 	mov	x0, #0x0                   	// #0
    7ed4:	f90027e1 	str	x1, [sp, #72]
    7ed8:	b400a361 	cbz	x1, 9344 <fwp_hof0.constprop.0+0x1494>
    7edc:	b00000c0 	adrp	x0, 20000 <__data_start>
    7ee0:	91004000 	add	x0, x0, #0x10
    7ee4:	f90017e0 	str	x0, [sp, #40]
    7ee8:	910183e0 	add	x0, sp, #0x60
    7eec:	f90013e0 	str	x0, [sp, #32]
    7ef0:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    7ef4:	6d1427e8 	stp	d8, d9, [sp, #320]
    7ef8:	910163e1 	add	x1, sp, #0x58
    7efc:	fd447008 	ldr	d8, [x0, #2272]
    7f00:	f9000fe1 	str	x1, [sp, #24]
    7f04:	a90f53f3 	stp	x19, x20, [sp, #240]
    7f08:	d0000154 	adrp	x20, 31000 <fwp_root_context+0xc80>
    7f0c:	a9105bf5 	stp	x21, x22, [sp, #256]
    7f10:	a91163f7 	stp	x23, x24, [sp, #272]
    7f14:	a9126bf9 	stp	x25, x26, [sp, #288]
    7f18:	a91373fb 	stp	x27, x28, [sp, #304]
    7f1c:	91158282 	add	x2, x20, #0x560
    7f20:	f94023e0 	ldr	x0, [sp, #64]
    7f24:	f949ec43 	ldr	x3, [x2, #5080]
    7f28:	f949d841 	ldr	x1, [x2, #5040]
    7f2c:	d370bc63 	lsl	x3, x3, #16
    7f30:	cb010004 	sub	x4, x0, x1
    7f34:	eb03009f 	cmp	x4, x3
    7f38:	540003e2 	b.cs	7fb4 <fwp_hof0.constprop.0+0x104>  // b.hs, b.nlast
    7f3c:	d350fc80 	lsr	x0, x4, #16
    7f40:	f949fc46 	ldr	x6, [x2, #5112]
    7f44:	8b000800 	add	x0, x0, x0, lsl #2
    7f48:	d37df002 	lsl	x2, x0, #3
    7f4c:	8b0200c5 	add	x5, x6, x2
    7f50:	f94010a0 	ldr	x0, [x5, #32]
    7f54:	b4000300 	cbz	x0, 7fb4 <fwp_hof0.constprop.0+0x104>
    7f58:	386268c2 	ldrb	w2, [x6, x2]
    7f5c:	7100085f 	cmp	w2, #0x2
    7f60:	5400b860 	b.eq	966c <fwp_hof0.constprop.0+0x17bc>  // b.none
    7f64:	7100045f 	cmp	w2, #0x1
    7f68:	54000261 	b.ne	7fb4 <fwp_hof0.constprop.0+0x104>  // b.any
    7f6c:	92403c82 	and	x2, x4, #0xffff
    7f70:	294310a6 	ldp	w6, w4, [x5, #24]
    7f74:	9b067c42 	mul	x2, x2, x6
    7f78:	d360fc42 	lsr	x2, x2, #32
    7f7c:	eb04005f 	cmp	x2, x4
    7f80:	540001a2 	b.cs	7fb4 <fwp_hof0.constprop.0+0x104>  // b.hs, b.nlast
    7f84:	8b020000 	add	x0, x0, x2
    7f88:	39400002 	ldrb	w2, [x0]
    7f8c:	34000142 	cbz	w2, 7fb4 <fwp_hof0.constprop.0+0x104>
    7f90:	7103f45f 	cmp	w2, #0xfd
    7f94:	5400c608 	b.hi	9854 <fwp_hof0.constprop.0+0x19a4>  // b.pmore
    7f98:	91158281 	add	x1, x20, #0x560
    7f9c:	11000442 	add	w2, w2, #0x1
    7fa0:	39000002 	strb	w2, [x0]
    7fa4:	aa0103e0 	mov	x0, x1
    7fa8:	f949d821 	ldr	x1, [x1, #5040]
    7fac:	f949ec03 	ldr	x3, [x0, #5080]
    7fb0:	d370bc63 	lsl	x3, x3, #16
    7fb4:	f94023f5 	ldr	x21, [sp, #64]
    7fb8:	d28018c0 	mov	x0, #0xc6                  	// #198
    7fbc:	f90007e0 	str	x0, [sp, #8]
    7fc0:	b00000c0 	adrp	x0, 20000 <__data_start>
    7fc4:	9100c002 	add	x2, x0, #0x30
    7fc8:	f94017e0 	ldr	x0, [sp, #40]
    7fcc:	12800004 	mov	w4, #0xffffffff            	// #-1
    7fd0:	b9005be4 	str	w4, [sp, #88]
    7fd4:	cb010001 	sub	x1, x0, x1
    7fd8:	d0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x10c>
    7fdc:	913a4000 	add	x0, x0, #0xe90
    7fe0:	f90037e0 	str	x0, [sp, #104]
    7fe4:	f9417040 	ldr	x0, [x2, #736]
    7fe8:	f90033e0 	str	x0, [sp, #96]
    7fec:	f9400fe0 	ldr	x0, [sp, #24]
    7ff0:	f9003be0 	str	x0, [sp, #112]
    7ff4:	f94013e0 	ldr	x0, [sp, #32]
    7ff8:	f9017040 	str	x0, [x2, #736]
    7ffc:	eb03003f 	cmp	x1, x3
    8000:	54000782 	b.cs	80f0 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    8004:	91158282 	add	x2, x20, #0x560
    8008:	d350fc20 	lsr	x0, x1, #16
    800c:	8b000800 	add	x0, x0, x0, lsl #2
    8010:	f949fc44 	ldr	x4, [x2, #5112]
    8014:	d37df003 	lsl	x3, x0, #3
    8018:	8b030082 	add	x2, x4, x3
    801c:	f9401053 	ldr	x19, [x2, #32]
    8020:	b4000693 	cbz	x19, 80f0 <fwp_hof0.constprop.0+0x240>
    8024:	38636880 	ldrb	w0, [x4, x3]
    8028:	7100081f 	cmp	w0, #0x2
    802c:	5400a5c0 	b.eq	94e4 <fwp_hof0.constprop.0+0x1634>  // b.none
    8030:	7100041f 	cmp	w0, #0x1
    8034:	540005e1 	b.ne	80f0 <fwp_hof0.constprop.0+0x240>  // b.any
    8038:	29430c44 	ldp	w4, w3, [x2, #24]
    803c:	92403c20 	and	x0, x1, #0xffff
    8040:	9b047c00 	mul	x0, x0, x4
    8044:	d360fc00 	lsr	x0, x0, #32
    8048:	eb03001f 	cmp	x0, x3
    804c:	540002a2 	b.cs	80a0 <fwp_hof0.constprop.0+0x1f0>  // b.hs, b.nlast
    8050:	8b000260 	add	x0, x19, x0
    8054:	39400003 	ldrb	w3, [x0]
    8058:	34000243 	cbz	w3, 80a0 <fwp_hof0.constprop.0+0x1f0>
    805c:	7103f47f 	cmp	w3, #0xfd
    8060:	5400bba8 	b.hi	97d4 <fwp_hof0.constprop.0+0x1924>  // b.pmore
    8064:	11000463 	add	w3, w3, #0x1
    8068:	39000003 	strb	w3, [x0]
    806c:	91158280 	add	x0, x20, #0x560
    8070:	f94017e3 	ldr	x3, [sp, #40]
    8074:	f949d801 	ldr	x1, [x0, #5040]
    8078:	f949ec02 	ldr	x2, [x0, #5080]
    807c:	cb010061 	sub	x1, x3, x1
    8080:	eb02403f 	cmp	x1, x2, lsl #16
    8084:	54000362 	b.cs	80f0 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    8088:	f949fc00 	ldr	x0, [x0, #5112]
    808c:	d350fc22 	lsr	x2, x1, #16
    8090:	8b020842 	add	x2, x2, x2, lsl #2
    8094:	8b020c02 	add	x2, x0, x2, lsl #3
    8098:	f9401053 	ldr	x19, [x2, #32]
    809c:	b40002b3 	cbz	x19, 80f0 <fwp_hof0.constprop.0+0x240>
    80a0:	39400040 	ldrb	w0, [x2]
    80a4:	7100081f 	cmp	w0, #0x2
    80a8:	5400a180 	b.eq	94d8 <fwp_hof0.constprop.0+0x1628>  // b.none
    80ac:	7100041f 	cmp	w0, #0x1
    80b0:	54000201 	b.ne	80f0 <fwp_hof0.constprop.0+0x240>  // b.any
    80b4:	29430043 	ldp	w3, w0, [x2, #24]
    80b8:	92403c21 	and	x1, x1, #0xffff
    80bc:	9b037c21 	mul	x1, x1, x3
    80c0:	d360fc21 	lsr	x1, x1, #32
    80c4:	eb00003f 	cmp	x1, x0
    80c8:	54000142 	b.cs	80f0 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    80cc:	8b010273 	add	x19, x19, x1
    80d0:	39400261 	ldrb	w1, [x19]
    80d4:	340000e1 	cbz	w1, 80f0 <fwp_hof0.constprop.0+0x240>
    80d8:	7100043f 	cmp	w1, #0x1
    80dc:	540079a0 	b.eq	9010 <fwp_hof0.constprop.0+0x1160>  // b.none
    80e0:	7103fc3f 	cmp	w1, #0xff
    80e4:	5400b7c0 	b.eq	97dc <fwp_hof0.constprop.0+0x192c>  // b.none
    80e8:	51000421 	sub	w1, w1, #0x1
    80ec:	39000261 	strb	w1, [x19]
    80f0:	b4007a15 	cbz	x21, 9030 <fwp_hof0.constprop.0+0x1180>
    80f4:	aa1503e0 	mov	x0, x21
    80f8:	d2800001 	mov	x1, #0x0                   	// #0
    80fc:	d503201f 	nop
    8100:	f9400800 	ldr	x0, [x0, #16]
    8104:	91000421 	add	x1, x1, #0x1
    8108:	b5ffffc0 	cbnz	x0, 8100 <fwp_hof0.constprop.0+0x250>
    810c:	aa0103f7 	mov	x23, x1
    8110:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8114:	eb00003f 	cmp	x1, x0
    8118:	5400bee8 	b.hi	98f4 <fwp_hof0.constprop.0+0x1a44>  // b.pmore
    811c:	900000c0 	adrp	x0, 20000 <__data_start>
    8120:	9100c013 	add	x19, x0, #0x30
    8124:	b9431660 	ldr	w0, [x19, #788]
    8128:	34007900 	cbz	w0, 9048 <fwp_hof0.constprop.0+0x1198>
    812c:	900000c0 	adrp	x0, 20000 <__data_start>
    8130:	9100c000 	add	x0, x0, #0x30
    8134:	f9402013 	ldr	x19, [x0, #64]
    8138:	f9405c16 	ldr	x22, [x0, #184]
    813c:	eb1302df 	cmp	x22, x19
    8140:	540072aa 	b.ge	8f94 <fwp_hof0.constprop.0+0x10e4>  // b.tcont
    8144:	900000c1 	adrp	x1, 20000 <__data_start>
    8148:	8b1606c0 	add	x0, x22, x22, lsl #1
    814c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8150:	f9401821 	ldr	x1, [x1, #48]
    8154:	8b000ac0 	add	x0, x22, x0, lsl #2
    8158:	8b000c20 	add	x0, x1, x0, lsl #3
    815c:	d503201f 	nop
    8160:	b9400401 	ldr	w1, [x0, #4]
    8164:	35000081 	cbnz	w1, 8174 <fwp_hof0.constprop.0+0x2c4>
    8168:	b9400001 	ldr	w1, [x0]
    816c:	6b02003f 	cmp	w1, w2
    8170:	54007129 	b.ls	8f94 <fwp_hof0.constprop.0+0x10e4>  // b.plast
    8174:	910006d6 	add	x22, x22, #0x1
    8178:	9101a000 	add	x0, x0, #0x68
    817c:	eb1302df 	cmp	x22, x19
    8180:	54ffff01 	b.ne	8160 <fwp_hof0.constprop.0+0x2b0>  // b.any
    8184:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8188:	eb00027f 	cmp	x19, x0
    818c:	5400baec 	b.gt	98e8 <fwp_hof0.constprop.0+0x1a38>
    8190:	900000c0 	adrp	x0, 20000 <__data_start>
    8194:	9100c000 	add	x0, x0, #0x30
    8198:	900000c1 	adrp	x1, 20000 <__data_start>
    819c:	f9405800 	ldr	x0, [x0, #176]
    81a0:	f940183c 	ldr	x28, [x1, #48]
    81a4:	eb13001f 	cmp	x0, x19
    81a8:	54000241 	b.ne	81f0 <fwp_hof0.constprop.0+0x340>  // b.any
    81ac:	b400a433 	cbz	x19, 9630 <fwp_hof0.constprop.0+0x1780>
    81b0:	d37ffa7b 	lsl	x27, x19, #1
    81b4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    81b8:	eb00037f 	cmp	x27, x0
    81bc:	9a80d37b 	csel	x27, x27, x0, le
    81c0:	8b1b0761 	add	x1, x27, x27, lsl #1
    81c4:	8b010b61 	add	x1, x27, x1, lsl #2
    81c8:	d37df021 	lsl	x1, x1, #3
    81cc:	aa1c03e0 	mov	x0, x28
    81d0:	97ffe9a8 	bl	2870 <realloc@plt>
    81d4:	aa0003fc 	mov	x28, x0
    81d8:	b4003800 	cbz	x0, 88d8 <fwp_hof0.constprop.0+0xa28>
    81dc:	900000c0 	adrp	x0, 20000 <__data_start>
    81e0:	9100c000 	add	x0, x0, #0x30
    81e4:	900000c1 	adrp	x1, 20000 <__data_start>
    81e8:	f900183c 	str	x28, [x1, #48]
    81ec:	f900581b 	str	x27, [x0, #176]
    81f0:	8b130660 	add	x0, x19, x19, lsl #1
    81f4:	8b1606db 	add	x27, x22, x22, lsl #1
    81f8:	4f000400 	movi	v0.4s, #0x0
    81fc:	91000662 	add	x2, x19, #0x1
    8200:	8b000a60 	add	x0, x19, x0, lsl #2
    8204:	8b1b0adb 	add	x27, x22, x27, lsl #2
    8208:	900000c1 	adrp	x1, 20000 <__data_start>
    820c:	9100c021 	add	x1, x1, #0x30
    8210:	8b000f80 	add	x0, x28, x0, lsl #3
    8214:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    8218:	f9002022 	str	x2, [x1, #64]
    821c:	ad000000 	stp	q0, q0, [x0]
    8220:	ad010000 	stp	q0, q0, [x0, #32]
    8224:	ad020000 	stp	q0, q0, [x0, #64]
    8228:	f900301f 	str	xzr, [x0, #96]
    822c:	90000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    8230:	f900337f 	str	xzr, [x27, #96]
    8234:	9138a000 	add	x0, x0, #0xe28
    8238:	97ffe9f6 	bl	2a10 <getenv@plt>
    823c:	b4006c40 	cbz	x0, 8fc4 <fwp_hof0.constprop.0+0x1114>
    8240:	39400001 	ldrb	w1, [x0]
    8244:	7100c03f 	cmp	w1, #0x30
    8248:	54006be1 	b.ne	8fc4 <fwp_hof0.constprop.0+0x1114>  // b.any
    824c:	39400400 	ldrb	w0, [x0, #1]
    8250:	35006ba0 	cbnz	w0, 8fc4 <fwp_hof0.constprop.0+0x1114>
    8254:	900000c0 	adrp	x0, 20000 <__data_start>
    8258:	9100c000 	add	x0, x0, #0x30
    825c:	2f000400 	mvni	v0.2s, #0x0
    8260:	b9400373 	ldr	w19, [x27]
    8264:	52800022 	mov	w2, #0x1                   	// #1
    8268:	910006c4 	add	x4, x22, #0x1
    826c:	f9417001 	ldr	x1, [x0, #736]
    8270:	0b020273 	add	w19, w19, w2
    8274:	29000b73 	stp	w19, w2, [x27]
    8278:	a900df77 	stp	x23, x23, [x27, #8]
    827c:	f9002b7f 	str	xzr, [x27, #80]
    8280:	f9005c04 	str	x4, [x0, #184]
    8284:	fd002f60 	str	d0, [x27, #88]
    8288:	b400b2a1 	cbz	x1, 98dc <fwp_hof0.constprop.0+0x1a2c>
    828c:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x10c>
    8290:	913a4003 	add	x3, x0, #0xe90
    8294:	14000003 	b	82a0 <fwp_hof0.constprop.0+0x3f0>
    8298:	f9400021 	ldr	x1, [x1]
    829c:	b400b201 	cbz	x1, 98dc <fwp_hof0.constprop.0+0x1a2c>
    82a0:	f9400422 	ldr	x2, [x1, #8]
    82a4:	eb03005f 	cmp	x2, x3
    82a8:	54ffff81 	b.ne	8298 <fwp_hof0.constprop.0+0x3e8>  // b.any
    82ac:	f9400820 	ldr	x0, [x1, #16]
    82b0:	2a1603e2 	mov	w2, w22
    82b4:	b9400001 	ldr	w1, [x0]
    82b8:	f9002b60 	str	x0, [x27, #80]
    82bc:	b9005f61 	str	w1, [x27, #92]
    82c0:	37f80081 	tbnz	w1, #31, 82d0 <fwp_hof0.constprop.0+0x420>
    82c4:	52800d03 	mov	w3, #0x68                  	// #104
    82c8:	9b237021 	smaddl	x1, w1, w3, x28
    82cc:	b9005836 	str	w22, [x1, #88]
    82d0:	b9000002 	str	w2, [x0]
    82d4:	d3707e73 	ubfiz	x19, x19, #16, #32
    82d8:	aa040273 	orr	x19, x19, x4
    82dc:	aa1503e0 	mov	x0, x21
    82e0:	d2800002 	mov	x2, #0x0                   	// #0
    82e4:	b4007275 	cbz	x21, 9130 <fwp_hof0.constprop.0+0x1280>
    82e8:	f9400800 	ldr	x0, [x0, #16]
    82ec:	91000442 	add	x2, x2, #0x1
    82f0:	b5ffffc0 	cbnz	x0, 82e8 <fwp_hof0.constprop.0+0x438>
    82f4:	aa1503e1 	mov	x1, x21
    82f8:	f9400821 	ldr	x1, [x1, #16]
    82fc:	91000400 	add	x0, x0, #0x1
    8300:	b5ffffc1 	cbnz	x1, 82f8 <fwp_hof0.constprop.0+0x448>
    8304:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8308:	eb01001f 	cmp	x0, x1
    830c:	5400ae28 	b.hi	98d0 <fwp_hof0.constprop.0+0x1a20>  // b.pmore
    8310:	f100005f 	cmp	x2, #0x0
    8314:	540070ed 	b.le	9130 <fwp_hof0.constprop.0+0x1280>
    8318:	eb00005f 	cmp	x2, x0
    831c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8320:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    8324:	eb0102df 	cmp	x22, x1
    8328:	5400ad48 	b.hi	98d0 <fwp_hof0.constprop.0+0x1a20>  // b.pmore
    832c:	d37ffadc 	lsl	x28, x22, #1
    8330:	52800041 	mov	w1, #0x2                   	// #2
    8334:	91000780 	add	x0, x28, #0x1
    8338:	d37df000 	lsl	x0, x0, #3
    833c:	97fff261 	bl	4cc0 <fwp_heap_alloc>
    8340:	aa0003f7 	mov	x23, x0
    8344:	91158281 	add	x1, x20, #0x560
    8348:	aa0003fb 	mov	x27, x0
    834c:	aa0103e0 	mov	x0, x1
    8350:	f90002fc 	str	x28, [x23]
    8354:	f949d821 	ldr	x1, [x1, #5040]
    8358:	f949ec00 	ldr	x0, [x0, #5080]
    835c:	cb0102e1 	sub	x1, x23, x1
    8360:	eb00403f 	cmp	x1, x0, lsl #16
    8364:	54008062 	b.cs	9370 <fwp_hof0.constprop.0+0x14c0>  // b.hs, b.nlast
    8368:	91158282 	add	x2, x20, #0x560
    836c:	d350fc20 	lsr	x0, x1, #16
    8370:	8b000800 	add	x0, x0, x0, lsl #2
    8374:	f949fc43 	ldr	x3, [x2, #5112]
    8378:	d37df002 	lsl	x2, x0, #3
    837c:	8b020060 	add	x0, x3, x2
    8380:	f940101c 	ldr	x28, [x0, #32]
    8384:	b400025c 	cbz	x28, 83cc <fwp_hof0.constprop.0+0x51c>
    8388:	38626862 	ldrb	w2, [x3, x2]
    838c:	7100085f 	cmp	w2, #0x2
    8390:	54008940 	b.eq	94b8 <fwp_hof0.constprop.0+0x1608>  // b.none
    8394:	7100045f 	cmp	w2, #0x1
    8398:	540001a1 	b.ne	83cc <fwp_hof0.constprop.0+0x51c>  // b.any
    839c:	29430002 	ldp	w2, w0, [x0, #24]
    83a0:	92403c21 	and	x1, x1, #0xffff
    83a4:	9b027c21 	mul	x1, x1, x2
    83a8:	d360fc21 	lsr	x1, x1, #32
    83ac:	eb00003f 	cmp	x1, x0
    83b0:	540000e2 	b.cs	83cc <fwp_hof0.constprop.0+0x51c>  // b.hs, b.nlast
    83b4:	8b01039c 	add	x28, x28, x1
    83b8:	39400380 	ldrb	w0, [x28]
    83bc:	7103fc1f 	cmp	w0, #0xff
    83c0:	54008860 	b.eq	94cc <fwp_hof0.constprop.0+0x161c>  // b.none
    83c4:	52800020 	mov	w0, #0x1                   	// #1
    83c8:	39000380 	strb	w0, [x28]
    83cc:	b4000236 	cbz	x22, 8410 <fwp_hof0.constprop.0+0x560>
    83d0:	d3607e64 	lsl	x4, x19, #32
    83d4:	aa1503e1 	mov	x1, x21
    83d8:	f94006a5 	ldr	x5, [x21, #8]
    83dc:	aa0403e3 	mov	x3, x4
    83e0:	910022e2 	add	x2, x23, #0x8
    83e4:	d2800000 	mov	x0, #0x0                   	// #0
    83e8:	14000005 	b	83fc <fwp_hof0.constprop.0+0x54c>
    83ec:	f9400425 	ldr	x5, [x1, #8]
    83f0:	ab000083 	adds	x3, x4, x0
    83f4:	91004042 	add	x2, x2, #0x10
    83f8:	5400aa86 	b.vs	9948 <fwp_hof0.constprop.0+0x1a98>
    83fc:	a9000c45 	stp	x5, x3, [x2]
    8400:	91000400 	add	x0, x0, #0x1
    8404:	f9400821 	ldr	x1, [x1, #16]
    8408:	eb0002df 	cmp	x22, x0
    840c:	54ffff08 	b.hi	83ec <fwp_hof0.constprop.0+0x53c>  // b.pmore
    8410:	f94002e0 	ldr	x0, [x23]
    8414:	f100041f 	cmp	x0, #0x1
    8418:	54007b09 	b.ls	9378 <fwp_hof0.constprop.0+0x14c8>  // b.plast
    841c:	d341fc00 	lsr	x0, x0, #1
    8420:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8424:	d1000401 	sub	x1, x0, #0x1
    8428:	eb02003f 	cmp	x1, x2
    842c:	5400a528 	b.hi	98d0 <fwp_hof0.constprop.0+0x1a20>  // b.pmore
    8430:	d37ff83c 	lsl	x28, x1, #1
    8434:	b4007a21 	cbz	x1, 9378 <fwp_hof0.constprop.0+0x14c8>
    8438:	d10022e1 	sub	x1, x23, #0x8
    843c:	910022f8 	add	x24, x23, #0x8
    8440:	8b001036 	add	x22, x1, x0, lsl #4
    8444:	d503201f 	nop
    8448:	f9400700 	ldr	x0, [x24, #8]
    844c:	f9400f01 	ldr	x1, [x24, #24]
    8450:	fd400300 	ldr	d0, [x24]
    8454:	fd400b01 	ldr	d1, [x24, #16]
    8458:	97fff35a 	bl	51c0 <w120>
    845c:	a9000700 	stp	x0, x1, [x24]
    8460:	91004318 	add	x24, x24, #0x10
    8464:	eb16031f 	cmp	x24, x22
    8468:	54ffff01 	b.ne	8448 <fwp_hof0.constprop.0+0x598>  // b.any
    846c:	f90002fc 	str	x28, [x23]
    8470:	9115829c 	add	x28, x20, #0x560
    8474:	aa1703e0 	mov	x0, x23
    8478:	97fff3a6 	bl	5310 <w176.constprop.0>
    847c:	aa0103f6 	mov	x22, x1
    8480:	f949db81 	ldr	x1, [x28, #5040]
    8484:	f949ef80 	ldr	x0, [x28, #5080]
    8488:	cb0102e1 	sub	x1, x23, x1
    848c:	eb00403f 	cmp	x1, x0, lsl #16
    8490:	54000382 	b.cs	8500 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    8494:	d350fc20 	lsr	x0, x1, #16
    8498:	f949ff84 	ldr	x4, [x28, #5112]
    849c:	8b000800 	add	x0, x0, x0, lsl #2
    84a0:	d37df000 	lsl	x0, x0, #3
    84a4:	8b000082 	add	x2, x4, x0
    84a8:	f9401057 	ldr	x23, [x2, #32]
    84ac:	b40002b7 	cbz	x23, 8500 <fwp_hof0.constprop.0+0x650>
    84b0:	38606880 	ldrb	w0, [x4, x0]
    84b4:	7100081f 	cmp	w0, #0x2
    84b8:	54007640 	b.eq	9380 <fwp_hof0.constprop.0+0x14d0>  // b.none
    84bc:	7100041f 	cmp	w0, #0x1
    84c0:	54000201 	b.ne	8500 <fwp_hof0.constprop.0+0x650>  // b.any
    84c4:	29430043 	ldp	w3, w0, [x2, #24]
    84c8:	92403c21 	and	x1, x1, #0xffff
    84cc:	9b037c21 	mul	x1, x1, x3
    84d0:	d360fc21 	lsr	x1, x1, #32
    84d4:	eb00003f 	cmp	x1, x0
    84d8:	54000142 	b.cs	8500 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    84dc:	8b0102f7 	add	x23, x23, x1
    84e0:	394002e0 	ldrb	w0, [x23]
    84e4:	340000e0 	cbz	w0, 8500 <fwp_hof0.constprop.0+0x650>
    84e8:	7100041f 	cmp	w0, #0x1
    84ec:	540020e0 	b.eq	8908 <fwp_hof0.constprop.0+0xa58>  // b.none
    84f0:	7103fc1f 	cmp	w0, #0xff
    84f4:	54008c20 	b.eq	9678 <fwp_hof0.constprop.0+0x17c8>  // b.none
    84f8:	51000400 	sub	w0, w0, #0x1
    84fc:	390002e0 	strb	w0, [x23]
    8500:	97ffeed1 	bl	4044 <caf75>
    8504:	9e670009 	fmov	d9, x0
    8508:	93407e73 	sxtw	x19, w19
    850c:	aa1303e0 	mov	x0, x19
    8510:	97ffece8 	bl	38b0 <fwp_tape_of>
    8514:	f9403001 	ldr	x1, [x0, #96]
    8518:	aa0003e8 	mov	x8, x0
    851c:	b5009f21 	cbnz	x1, 9900 <fwp_hof0.constprop.0+0x1a50>
    8520:	97ffea9c 	bl	2f90 <fwp_tape_unlink_scope>
    8524:	b9400002 	ldr	w2, [x0]
    8528:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    852c:	a940801c 	ldp	x28, x0, [x0, #8]
    8530:	b900051f 	str	wzr, [x8, #4]
    8534:	a941e50a 	ldp	x10, x25, [x8, #24]
    8538:	a942ed1a 	ldp	x26, x27, [x8, #40]
    853c:	a943e107 	ldp	x7, x24, [x8, #56]
    8540:	f9402517 	ldr	x23, [x8, #72]
    8544:	6b01005f 	cmp	w2, w1
    8548:	54000128 	b.hi	856c <fwp_hof0.constprop.0+0x6bc>  // b.pmore
    854c:	900000c1 	adrp	x1, 20000 <__data_start>
    8550:	9100c022 	add	x2, x1, #0x30
    8554:	92403e61 	and	x1, x19, #0xffff
    8558:	d1000421 	sub	x1, x1, #0x1
    855c:	f9405c49 	ldr	x9, [x2, #184]
    8560:	eb09003f 	cmp	x1, x9
    8564:	5400004a 	b.ge	856c <fwp_hof0.constprop.0+0x6bc>  // b.tcont
    8568:	f9005c41 	str	x1, [x2, #184]
    856c:	4f000400 	movi	v0.4s, #0x0
    8570:	900000c1 	adrp	x1, 20000 <__data_start>
    8574:	9100c029 	add	x9, x1, #0x30
    8578:	f9000d1f 	str	xzr, [x8, #24]
    857c:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    8580:	910243e3 	add	x3, sp, #0x90
    8584:	9101e3e1 	add	x1, sp, #0x78
    8588:	f941712b 	ldr	x11, [x9, #736]
    858c:	3c808100 	stur	q0, [x8, #8]
    8590:	90ffffe2 	adrp	x2, 4000 <fwp_heap_init+0x17c>
    8594:	ad010100 	stp	q0, q0, [x8, #32]
    8598:	91054042 	add	x2, x2, #0x150
    859c:	f9000be3 	str	x3, [sp, #16]
    85a0:	a9078beb 	stp	x11, x2, [sp, #120]
    85a4:	a908e7e3 	stp	x3, x25, [sp, #136]
    85a8:	a909effa 	stp	x26, x27, [sp, #152]
    85ac:	a90ae3e7 	stp	x7, x24, [sp, #168]
    85b0:	a90bdfea 	stp	x10, x23, [sp, #184]
    85b4:	f9017121 	str	x1, [x9, #736]
    85b8:	b7f879f6 	tbnz	x22, #63, 94f4 <fwp_hof0.constprop.0+0x1644>
    85bc:	eb96827f 	cmp	x19, x22, asr #32
    85c0:	540093e1 	b.ne	983c <fwp_hof0.constprop.0+0x198c>  // b.any
    85c4:	92407ed3 	and	x19, x22, #0xffffffff
    85c8:	eb36401f 	cmp	x0, w22, uxtw
    85cc:	540093ed 	b.le	9848 <fwp_hof0.constprop.0+0x1998>
    85d0:	eb1c027f 	cmp	x19, x28
    85d4:	9a93b793 	csinc	x19, x28, x19, lt	// lt = tstop
    85d8:	eb1302ff 	cmp	x23, x19
    85dc:	5400168a 	b.ge	88ac <fwp_hof0.constprop.0+0x9fc>  // b.tcont
    85e0:	f10002ff 	cmp	x23, #0x0
    85e4:	9a9312f7 	csel	x23, x23, x19, ne	// ne = any
    85e8:	14000005 	b	85fc <fwp_hof0.constprop.0+0x74c>
    85ec:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    85f0:	eb0002ff 	cmp	x23, x0
    85f4:	d37ffaf7 	lsl	x23, x23, #1
    85f8:	9a93d2f7 	csel	x23, x23, x19, le
    85fc:	eb1302ff 	cmp	x23, x19
    8600:	54ffff6b 	b.lt	85ec <fwp_hof0.constprop.0+0x73c>  // b.tstop
    8604:	f9001be7 	str	x7, [sp, #48]
    8608:	b4007f58 	cbz	x24, 95f0 <fwp_hof0.constprop.0+0x1740>
    860c:	aa1803e0 	mov	x0, x24
    8610:	d37df2e1 	lsl	x1, x23, #3
    8614:	97ffe897 	bl	2870 <realloc@plt>
    8618:	aa0003f8 	mov	x24, x0
    861c:	f9401be7 	ldr	x7, [sp, #48]
    8620:	b4009838 	cbz	x24, 9924 <fwp_hof0.constprop.0+0x1a74>
    8624:	f9005bf8 	str	x24, [sp, #176]
    8628:	f90063f7 	str	x23, [sp, #192]
    862c:	b5001333 	cbnz	x19, 8890 <fwp_hof0.constprop.0+0x9e0>
    8630:	b7f800b6 	tbnz	x22, #63, 8644 <fwp_hof0.constprop.0+0x794>
    8634:	92407ec1 	and	x1, x22, #0xffffffff
    8638:	fc617b00 	ldr	d0, [x24, x1, lsl #3]
    863c:	1e692800 	fadd	d0, d0, d9
    8640:	fc217b00 	str	d0, [x24, x1, lsl #3]
    8644:	d1000673 	sub	x19, x19, #0x1
    8648:	d1000788 	sub	x8, x28, #0x1
    864c:	eb13039f 	cmp	x28, x19
    8650:	540003ac 	b.gt	86c4 <fwp_hof0.constprop.0+0x814>
    8654:	fc737b00 	ldr	d0, [x24, x19, lsl #3]
    8658:	1e602008 	fcmp	d0, #0.0
    865c:	540002e0 	b.eq	86b8 <fwp_hof0.constprop.0+0x808>  // b.none
    8660:	cb1c0be0 	neg	x0, x28, lsl #2
    8664:	cb1c03e2 	neg	x2, x28
    8668:	8b000321 	add	x1, x25, x0
    866c:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    8670:	37f80101 	tbnz	w1, #31, 8690 <fwp_hof0.constprop.0+0x7e0>
    8674:	8b020f69 	add	x9, x27, x2, lsl #3
    8678:	93407c21 	sxtw	x1, w1
    867c:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    8680:	fc617b01 	ldr	d1, [x24, x1, lsl #3]
    8684:	1e620802 	fmul	d2, d0, d2
    8688:	1e622821 	fadd	d1, d1, d2
    868c:	fc217b01 	str	d1, [x24, x1, lsl #3]
    8690:	8b000340 	add	x0, x26, x0
    8694:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    8698:	37f80100 	tbnz	w0, #31, 86b8 <fwp_hof0.constprop.0+0x808>
    869c:	8b020ce2 	add	x2, x7, x2, lsl #3
    86a0:	93407c00 	sxtw	x0, w0
    86a4:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    86a8:	fc607b01 	ldr	d1, [x24, x0, lsl #3]
    86ac:	1e620800 	fmul	d0, d0, d2
    86b0:	1e602820 	fadd	d0, d1, d0
    86b4:	fc207b00 	str	d0, [x24, x0, lsl #3]
    86b8:	d1000673 	sub	x19, x19, #0x1
    86bc:	eb13011f 	cmp	x8, x19
    86c0:	54fffca1 	b.ne	8654 <fwp_hof0.constprop.0+0x7a4>  // b.any
    86c4:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    86c8:	eb00039f 	cmp	x28, x0
    86cc:	54009268 	b.hi	9918 <fwp_hof0.constprop.0+0x1a68>  // b.pmore
    86d0:	91000780 	add	x0, x28, #0x1
    86d4:	52800041 	mov	w1, #0x2                   	// #2
    86d8:	d37df000 	lsl	x0, x0, #3
    86dc:	97fff179 	bl	4cc0 <fwp_heap_alloc>
    86e0:	aa0003e2 	mov	x2, x0
    86e4:	aa0003f3 	mov	x19, x0
    86e8:	d2800001 	mov	x1, #0x0                   	// #0
    86ec:	f800845c 	str	x28, [x2], #8
    86f0:	b40000fc 	cbz	x28, 870c <fwp_hof0.constprop.0+0x85c>
    86f4:	d503201f 	nop
    86f8:	f8617b00 	ldr	x0, [x24, x1, lsl #3]
    86fc:	f8217840 	str	x0, [x2, x1, lsl #3]
    8700:	91000421 	add	x1, x1, #0x1
    8704:	eb01039f 	cmp	x28, x1
    8708:	54ffff81 	b.ne	86f8 <fwp_hof0.constprop.0+0x848>  // b.any
    870c:	900000c0 	adrp	x0, 20000 <__data_start>
    8710:	9100c001 	add	x1, x0, #0x30
    8714:	f9400be0 	ldr	x0, [sp, #16]
    8718:	f9403ff7 	ldr	x23, [sp, #120]
    871c:	f9017037 	str	x23, [x1, #736]
    8720:	97ffee8c 	bl	4150 <fwp_tape_buffers_release>
    8724:	91158282 	add	x2, x20, #0x560
    8728:	f949d841 	ldr	x1, [x2, #5040]
    872c:	f949ec40 	ldr	x0, [x2, #5080]
    8730:	cb010261 	sub	x1, x19, x1
    8734:	eb00403f 	cmp	x1, x0, lsl #16
    8738:	54000322 	b.cs	879c <fwp_hof0.constprop.0+0x8ec>  // b.hs, b.nlast
    873c:	d350fc20 	lsr	x0, x1, #16
    8740:	f949fc43 	ldr	x3, [x2, #5112]
    8744:	8b000800 	add	x0, x0, x0, lsl #2
    8748:	d37df002 	lsl	x2, x0, #3
    874c:	8b020060 	add	x0, x3, x2
    8750:	f9401016 	ldr	x22, [x0, #32]
    8754:	b4000256 	cbz	x22, 879c <fwp_hof0.constprop.0+0x8ec>
    8758:	38626862 	ldrb	w2, [x3, x2]
    875c:	7100085f 	cmp	w2, #0x2
    8760:	54006ce0 	b.eq	94fc <fwp_hof0.constprop.0+0x164c>  // b.none
    8764:	7100045f 	cmp	w2, #0x1
    8768:	540001a1 	b.ne	879c <fwp_hof0.constprop.0+0x8ec>  // b.any
    876c:	29430002 	ldp	w2, w0, [x0, #24]
    8770:	92403c21 	and	x1, x1, #0xffff
    8774:	9b027c21 	mul	x1, x1, x2
    8778:	d360fc21 	lsr	x1, x1, #32
    877c:	eb00003f 	cmp	x1, x0
    8780:	540000e2 	b.cs	879c <fwp_hof0.constprop.0+0x8ec>  // b.hs, b.nlast
    8784:	8b0102d6 	add	x22, x22, x1
    8788:	394002c0 	ldrb	w0, [x22]
    878c:	7103fc1f 	cmp	w0, #0xff
    8790:	54006c00 	b.eq	9510 <fwp_hof0.constprop.0+0x1660>  // b.none
    8794:	52800020 	mov	w0, #0x1                   	// #1
    8798:	390002c0 	strb	w0, [x22]
    879c:	f94013e0 	ldr	x0, [sp, #32]
    87a0:	eb0002ff 	cmp	x23, x0
    87a4:	54008d41 	b.ne	994c <fwp_hof0.constprop.0+0x1a9c>  // b.any
    87a8:	900000c0 	adrp	x0, 20000 <__data_start>
    87ac:	9100c001 	add	x1, x0, #0x30
    87b0:	f9400fe0 	ldr	x0, [sp, #24]
    87b4:	f94033e2 	ldr	x2, [sp, #96]
    87b8:	f9017022 	str	x2, [x1, #736]
    87bc:	97fff5b5 	bl	5e90 <fwp_tape_scope_release>
    87c0:	f9400260 	ldr	x0, [x19]
    87c4:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    87c8:	b7f84540 	tbnz	x0, #63, 9070 <fwp_hof0.constprop.0+0x11c0>
    87cc:	91158282 	add	x2, x20, #0x560
    87d0:	f949d840 	ldr	x0, [x2, #5040]
    87d4:	f949ec41 	ldr	x1, [x2, #5080]
    87d8:	cb000260 	sub	x0, x19, x0
    87dc:	eb01401f 	cmp	x0, x1, lsl #16
    87e0:	54004482 	b.cs	9070 <fwp_hof0.constprop.0+0x11c0>  // b.hs, b.nlast
    87e4:	d350fc01 	lsr	x1, x0, #16
    87e8:	f949fc44 	ldr	x4, [x2, #5112]
    87ec:	8b010821 	add	x1, x1, x1, lsl #2
    87f0:	d37df021 	lsl	x1, x1, #3
    87f4:	8b010083 	add	x3, x4, x1
    87f8:	f9401062 	ldr	x2, [x3, #32]
    87fc:	b40043a2 	cbz	x2, 9070 <fwp_hof0.constprop.0+0x11c0>
    8800:	38616881 	ldrb	w1, [x4, x1]
    8804:	7100083f 	cmp	w1, #0x2
    8808:	540042e0 	b.eq	9064 <fwp_hof0.constprop.0+0x11b4>  // b.none
    880c:	7100043f 	cmp	w1, #0x1
    8810:	54004301 	b.ne	9070 <fwp_hof0.constprop.0+0x11c0>  // b.any
    8814:	29430464 	ldp	w4, w1, [x3, #24]
    8818:	92403c00 	and	x0, x0, #0xffff
    881c:	9b047c00 	mul	x0, x0, x4
    8820:	d360fc00 	lsr	x0, x0, #32
    8824:	eb01001f 	cmp	x0, x1
    8828:	54004242 	b.cs	9070 <fwp_hof0.constprop.0+0x11c0>  // b.hs, b.nlast
    882c:	8b000042 	add	x2, x2, x0
    8830:	39400040 	ldrb	w0, [x2]
    8834:	7100041f 	cmp	w0, #0x1
    8838:	540041c1 	b.ne	9070 <fwp_hof0.constprop.0+0x11c0>  // b.any
    883c:	aa1303fc 	mov	x28, x19
    8840:	aa1303f6 	mov	x22, x19
    8844:	d2800000 	mov	x0, #0x0                   	// #0
    8848:	910022c3 	add	x3, x22, #0x8
    884c:	91002265 	add	x5, x19, #0x8
    8850:	d2800001 	mov	x1, #0x0                   	// #0
    8854:	b5000157 	cbnz	x23, 887c <fwp_hof0.constprop.0+0x9cc>
    8858:	1400004d 	b	898c <fwp_hof0.constprop.0+0xadc>
    885c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8860:	f9400382 	ldr	x2, [x28]
    8864:	1e600900 	fmul	d0, d8, d0
    8868:	b7f882e2 	tbnz	x2, #63, 98c4 <fwp_hof0.constprop.0+0x1a14>
    886c:	91000421 	add	x1, x1, #0x1
    8870:	fc008460 	str	d0, [x3], #8
    8874:	eb0102ff 	cmp	x23, x1
    8878:	540008a0 	b.eq	898c <fwp_hof0.constprop.0+0xadc>  // b.none
    887c:	f9400264 	ldr	x4, [x19]
    8880:	aa0503e2 	mov	x2, x5
    8884:	b6fffec4 	tbz	x4, #63, 885c <fwp_hof0.constprop.0+0x9ac>
    8888:	f9400a62 	ldr	x2, [x19, #16]
    888c:	17fffff4 	b	885c <fwp_hof0.constprop.0+0x9ac>
    8890:	d37df262 	lsl	x2, x19, #3
    8894:	aa1803e0 	mov	x0, x24
    8898:	52800001 	mov	w1, #0x0                   	// #0
    889c:	f9001be7 	str	x7, [sp, #48]
    88a0:	97ffe7ec 	bl	2850 <memset@plt>
    88a4:	f9401be7 	ldr	x7, [sp, #48]
    88a8:	17ffff62 	b	8630 <fwp_hof0.constprop.0+0x780>
    88ac:	f100031f 	cmp	x24, #0x0
    88b0:	1a9f17e0 	cset	w0, eq	// eq = none
    88b4:	f100027f 	cmp	x19, #0x0
    88b8:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    88bc:	54ffeb80 	b.eq	862c <fwp_hof0.constprop.0+0x77c>  // b.none
    88c0:	900000c0 	adrp	x0, 20000 <__data_start>
    88c4:	9100c018 	add	x24, x0, #0x30
    88c8:	f9400be0 	ldr	x0, [sp, #16]
    88cc:	f9403fe1 	ldr	x1, [sp, #120]
    88d0:	f9017301 	str	x1, [x24, #736]
    88d4:	97ffee1f 	bl	4150 <fwp_tape_buffers_release>
    88d8:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    88dc:	f947e863 	ldr	x3, [x3, #4048]
    88e0:	d2800262 	mov	x2, #0x13                  	// #19
    88e4:	d2800021 	mov	x1, #0x1                   	// #1
    88e8:	90000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    88ec:	912fe000 	add	x0, x0, #0xbf8
    88f0:	f9400063 	ldr	x3, [x3]
    88f4:	97ffe823 	bl	2980 <fwrite@plt>
    88f8:	d2800000 	mov	x0, #0x0                   	// #0
    88fc:	97ffe82d 	bl	29b0 <fflush@plt>
    8900:	52800cc0 	mov	w0, #0x66                  	// #102
    8904:	97ffe83b 	bl	29f0 <_Exit@plt>
    8908:	f9400365 	ldr	x5, [x27]
    890c:	aa1b03e0 	mov	x0, x27
    8910:	f949ef83 	ldr	x3, [x28, #5080]
    8914:	f949db81 	ldr	x1, [x28, #5040]
    8918:	d370bc63 	lsl	x3, x3, #16
    891c:	cb010362 	sub	x2, x27, x1
    8920:	b7f853c5 	tbnz	x5, #63, 9398 <fwp_hof0.constprop.0+0x14e8>
    8924:	eb02007f 	cmp	x3, x2
    8928:	54ffdec9 	b.ls	8500 <fwp_hof0.constprop.0+0x650>  // b.plast
    892c:	d350fc40 	lsr	x0, x2, #16
    8930:	8b000800 	add	x0, x0, x0, lsl #2
    8934:	d37df000 	lsl	x0, x0, #3
    8938:	8b000083 	add	x3, x4, x0
    893c:	f9401061 	ldr	x1, [x3, #32]
    8940:	b4ffde01 	cbz	x1, 8500 <fwp_hof0.constprop.0+0x650>
    8944:	38606880 	ldrb	w0, [x4, x0]
    8948:	7100081f 	cmp	w0, #0x2
    894c:	54005e80 	b.eq	951c <fwp_hof0.constprop.0+0x166c>  // b.none
    8950:	7100041f 	cmp	w0, #0x1
    8954:	54ffdd61 	b.ne	8500 <fwp_hof0.constprop.0+0x650>  // b.any
    8958:	92403c40 	and	x0, x2, #0xffff
    895c:	29430864 	ldp	w4, w2, [x3, #24]
    8960:	9b047c00 	mul	x0, x0, x4
    8964:	d360fc00 	lsr	x0, x0, #32
    8968:	eb02001f 	cmp	x0, x2
    896c:	54ffdca2 	b.cs	8500 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    8970:	8b000021 	add	x1, x1, x0
    8974:	39400020 	ldrb	w0, [x1]
    8978:	7100041f 	cmp	w0, #0x1
    897c:	54ffdc21 	b.ne	8500 <fwp_hof0.constprop.0+0x650>  // b.any
    8980:	aa1b03e0 	mov	x0, x27
    8984:	97ffefaf 	bl	4840 <fwp_mem_free>
    8988:	17fffede 	b	8500 <fwp_hof0.constprop.0+0x650>
    898c:	97fff72d 	bl	6640 <fwp_drop10>
    8990:	aa1503e1 	mov	x1, x21
    8994:	d2800002 	mov	x2, #0x0                   	// #0
    8998:	b4006395 	cbz	x21, 9608 <fwp_hof0.constprop.0+0x1758>
    899c:	d503201f 	nop
    89a0:	f9400821 	ldr	x1, [x1, #16]
    89a4:	91000442 	add	x2, x2, #0x1
    89a8:	b5ffffc1 	cbnz	x1, 89a0 <fwp_hof0.constprop.0+0xaf0>
    89ac:	f9400384 	ldr	x4, [x28]
    89b0:	9240f885 	and	x5, x4, #0x7fffffffffffffff
    89b4:	b7f82b64 	tbnz	x4, #63, 8f20 <fwp_hof0.constprop.0+0x1070>
    89b8:	91158281 	add	x1, x20, #0x560
    89bc:	f949d820 	ldr	x0, [x1, #5040]
    89c0:	f949ec21 	ldr	x1, [x1, #5080]
    89c4:	cb0002c0 	sub	x0, x22, x0
    89c8:	eb01401f 	cmp	x0, x1, lsl #16
    89cc:	54002aa2 	b.cs	8f20 <fwp_hof0.constprop.0+0x1070>  // b.hs, b.nlast
    89d0:	91158283 	add	x3, x20, #0x560
    89d4:	d350fc01 	lsr	x1, x0, #16
    89d8:	8b010821 	add	x1, x1, x1, lsl #2
    89dc:	f949fc67 	ldr	x7, [x3, #5112]
    89e0:	d37df021 	lsl	x1, x1, #3
    89e4:	8b0100e6 	add	x6, x7, x1
    89e8:	f94010c3 	ldr	x3, [x6, #32]
    89ec:	b4002983 	cbz	x3, 8f1c <fwp_hof0.constprop.0+0x106c>
    89f0:	386168e1 	ldrb	w1, [x7, x1]
    89f4:	7100083f 	cmp	w1, #0x2
    89f8:	540028e0 	b.eq	8f14 <fwp_hof0.constprop.0+0x1064>  // b.none
    89fc:	7100043f 	cmp	w1, #0x1
    8a00:	540028e1 	b.ne	8f1c <fwp_hof0.constprop.0+0x106c>  // b.any
    8a04:	294304c7 	ldp	w7, w1, [x6, #24]
    8a08:	92403c00 	and	x0, x0, #0xffff
    8a0c:	9b077c00 	mul	x0, x0, x7
    8a10:	d360fc00 	lsr	x0, x0, #32
    8a14:	eb01001f 	cmp	x0, x1
    8a18:	54002822 	b.cs	8f1c <fwp_hof0.constprop.0+0x106c>  // b.hs, b.nlast
    8a1c:	8b000063 	add	x3, x3, x0
    8a20:	39400060 	ldrb	w0, [x3]
    8a24:	7100041f 	cmp	w0, #0x1
    8a28:	540027a1 	b.ne	8f1c <fwp_hof0.constprop.0+0x106c>  // b.any
    8a2c:	b90033e0 	str	w0, [sp, #48]
    8a30:	eb05005f 	cmp	x2, x5
    8a34:	9a859045 	csel	x5, x2, x5, ls	// ls = plast
    8a38:	9100239b 	add	x27, x28, #0x8
    8a3c:	b4006c65 	cbz	x5, 97c8 <fwp_hof0.constprop.0+0x1918>
    8a40:	d37df0a7 	lsl	x7, x5, #3
    8a44:	aa1503e2 	mov	x2, x21
    8a48:	910022c0 	add	x0, x22, #0x8
    8a4c:	d2800001 	mov	x1, #0x0                   	// #0
    8a50:	1400000a 	b	8a78 <fwp_hof0.constprop.0+0xbc8>
    8a54:	fc6168c1 	ldr	d1, [x6, x1]
    8a58:	fd400440 	ldr	d0, [x2, #8]
    8a5c:	1e613800 	fsub	d0, d0, d1
    8a60:	fc216b60 	str	d0, [x27, x1]
    8a64:	91002021 	add	x1, x1, #0x8
    8a68:	f9400842 	ldr	x2, [x2, #16]
    8a6c:	eb07003f 	cmp	x1, x7
    8a70:	540001a0 	b.eq	8aa4 <fwp_hof0.constprop.0+0xbf4>  // b.none
    8a74:	f9400384 	ldr	x4, [x28]
    8a78:	aa0003e6 	mov	x6, x0
    8a7c:	b6fffec4 	tbz	x4, #63, 8a54 <fwp_hof0.constprop.0+0xba4>
    8a80:	f9400ac6 	ldr	x6, [x22, #16]
    8a84:	fd400440 	ldr	d0, [x2, #8]
    8a88:	fc6168c1 	ldr	d1, [x6, x1]
    8a8c:	1e613800 	fsub	d0, d0, d1
    8a90:	fc216b60 	str	d0, [x27, x1]
    8a94:	91002021 	add	x1, x1, #0x8
    8a98:	f9400842 	ldr	x2, [x2, #16]
    8a9c:	eb07003f 	cmp	x1, x7
    8aa0:	54fffea1 	b.ne	8a74 <fwp_hof0.constprop.0+0xbc4>  // b.any
    8aa4:	b4006c95 	cbz	x21, 9834 <fwp_hof0.constprop.0+0x1984>
    8aa8:	91158280 	add	x0, x20, #0x560
    8aac:	aa1503e7 	mov	x7, x21
    8ab0:	d2800017 	mov	x23, #0x0                   	// #0
    8ab4:	f949ec09 	ldr	x9, [x0, #5080]
    8ab8:	f949d80a 	ldr	x10, [x0, #5040]
    8abc:	f949fc08 	ldr	x8, [x0, #5112]
    8ac0:	d370bd29 	lsl	x9, x9, #16
    8ac4:	14000006 	b	8adc <fwp_hof0.constprop.0+0xc2c>
    8ac8:	f94008e7 	ldr	x7, [x7, #16]
    8acc:	910006f7 	add	x23, x23, #0x1
    8ad0:	f10000ff 	cmp	x7, #0x0
    8ad4:	fa5710a0 	ccmp	x5, x23, #0x0, ne	// ne = any
    8ad8:	54000329 	b.ls	8b3c <fwp_hof0.constprop.0+0xc8c>  // b.plast
    8adc:	cb0a00e0 	sub	x0, x7, x10
    8ae0:	eb09001f 	cmp	x0, x9
    8ae4:	540002c2 	b.cs	8b3c <fwp_hof0.constprop.0+0xc8c>  // b.hs, b.nlast
    8ae8:	d350fc01 	lsr	x1, x0, #16
    8aec:	8b010821 	add	x1, x1, x1, lsl #2
    8af0:	d37df021 	lsl	x1, x1, #3
    8af4:	8b010106 	add	x6, x8, x1
    8af8:	f94010c2 	ldr	x2, [x6, #32]
    8afc:	b4000202 	cbz	x2, 8b3c <fwp_hof0.constprop.0+0xc8c>
    8b00:	38616901 	ldrb	w1, [x8, x1]
    8b04:	7100083f 	cmp	w1, #0x2
    8b08:	54000e00 	b.eq	8cc8 <fwp_hof0.constprop.0+0xe18>  // b.none
    8b0c:	7100043f 	cmp	w1, #0x1
    8b10:	54000161 	b.ne	8b3c <fwp_hof0.constprop.0+0xc8c>  // b.any
    8b14:	294304cb 	ldp	w11, w1, [x6, #24]
    8b18:	92403c00 	and	x0, x0, #0xffff
    8b1c:	9b0b7c00 	mul	x0, x0, x11
    8b20:	d360fc00 	lsr	x0, x0, #32
    8b24:	eb01001f 	cmp	x0, x1
    8b28:	540000a2 	b.cs	8b3c <fwp_hof0.constprop.0+0xc8c>  // b.hs, b.nlast
    8b2c:	8b000042 	add	x2, x2, x0
    8b30:	39400040 	ldrb	w0, [x2]
    8b34:	7100041f 	cmp	w0, #0x1
    8b38:	54fffc80 	b.eq	8ac8 <fwp_hof0.constprop.0+0xc18>  // b.none
    8b3c:	eb1700bf 	cmp	x5, x23
    8b40:	54000cc9 	b.ls	8cd8 <fwp_hof0.constprop.0+0xe28>  // b.plast
    8b44:	aa0503f8 	mov	x24, x5
    8b48:	d1002379 	sub	x25, x27, #0x8
    8b4c:	910323f3 	add	x19, sp, #0xc8
    8b50:	9115829a 	add	x26, x20, #0x560
    8b54:	d280001c 	mov	x28, #0x0                   	// #0
    8b58:	14000012 	b	8ba0 <fwp_hof0.constprop.0+0xcf0>
    8b5c:	7100045f 	cmp	w2, #0x1
    8b60:	540001a1 	b.ne	8b94 <fwp_hof0.constprop.0+0xce4>  // b.any
    8b64:	29430909 	ldp	w9, w2, [x8, #24]
    8b68:	92403c21 	and	x1, x1, #0xffff
    8b6c:	9b097c21 	mul	x1, x1, x9
    8b70:	d360fc21 	lsr	x1, x1, #32
    8b74:	eb02003f 	cmp	x1, x2
    8b78:	540000e2 	b.cs	8b94 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    8b7c:	8b010000 	add	x0, x0, x1
    8b80:	39400001 	ldrb	w1, [x0]
    8b84:	7103fc3f 	cmp	w1, #0xff
    8b88:	54002f00 	b.eq	9168 <fwp_hof0.constprop.0+0x12b8>  // b.none
    8b8c:	52800021 	mov	w1, #0x1                   	// #1
    8b90:	39000001 	strb	w1, [x0]
    8b94:	d1000718 	sub	x24, x24, #0x1
    8b98:	eb17031f 	cmp	x24, x23
    8b9c:	54000369 	b.ls	8c08 <fwp_hof0.constprop.0+0xd58>  // b.plast
    8ba0:	f8787b22 	ldr	x2, [x25, x24, lsl #3]
    8ba4:	aa1303e1 	mov	x1, x19
    8ba8:	52800020 	mov	w0, #0x1                   	// #1
    8bac:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8bb0:	97fff089 	bl	4dd4 <fwp_data.part.0.constprop.0>
    8bb4:	aa0003fc 	mov	x28, x0
    8bb8:	f949db41 	ldr	x1, [x26, #5040]
    8bbc:	f949ef40 	ldr	x0, [x26, #5080]
    8bc0:	cb010381 	sub	x1, x28, x1
    8bc4:	eb00403f 	cmp	x1, x0, lsl #16
    8bc8:	54fffe62 	b.cs	8b94 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    8bcc:	d350fc20 	lsr	x0, x1, #16
    8bd0:	f949ff49 	ldr	x9, [x26, #5112]
    8bd4:	8b000800 	add	x0, x0, x0, lsl #2
    8bd8:	d37df002 	lsl	x2, x0, #3
    8bdc:	8b020128 	add	x8, x9, x2
    8be0:	f9401100 	ldr	x0, [x8, #32]
    8be4:	b4fffd80 	cbz	x0, 8b94 <fwp_hof0.constprop.0+0xce4>
    8be8:	38626922 	ldrb	w2, [x9, x2]
    8bec:	7100085f 	cmp	w2, #0x2
    8bf0:	54fffb61 	b.ne	8b5c <fwp_hof0.constprop.0+0xcac>  // b.any
    8bf4:	72003c3f 	tst	w1, #0xffff
    8bf8:	54fffc40 	b.eq	8b80 <fwp_hof0.constprop.0+0xcd0>  // b.none
    8bfc:	d1000718 	sub	x24, x24, #0x1
    8c00:	eb17031f 	cmp	x24, x23
    8c04:	54fffce8 	b.hi	8ba0 <fwp_hof0.constprop.0+0xcf0>  // b.pmore
    8c08:	b50006b7 	cbnz	x23, 8cdc <fwp_hof0.constprop.0+0xe2c>
    8c0c:	b94033e0 	ldr	w0, [sp, #48]
    8c10:	d2800004 	mov	x4, #0x0                   	// #0
    8c14:	7100001f 	cmp	w0, #0x0
    8c18:	d2800020 	mov	x0, #0x1                   	// #1
    8c1c:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    8c20:	b40007c4 	cbz	x4, 8d18 <fwp_hof0.constprop.0+0xe68>
    8c24:	d1000497 	sub	x23, x4, #0x1
    8c28:	2a0003f9 	mov	w25, w0
    8c2c:	9115829a 	add	x26, x20, #0x560
    8c30:	f8777b62 	ldr	x2, [x27, x23, lsl #3]
    8c34:	aa1303e1 	mov	x1, x19
    8c38:	52800020 	mov	w0, #0x1                   	// #1
    8c3c:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8c40:	97fff065 	bl	4dd4 <fwp_data.part.0.constprop.0>
    8c44:	aa0003fc 	mov	x28, x0
    8c48:	f949db41 	ldr	x1, [x26, #5040]
    8c4c:	f949ef40 	ldr	x0, [x26, #5080]
    8c50:	cb010381 	sub	x1, x28, x1
    8c54:	eb00403f 	cmp	x1, x0, lsl #16
    8c58:	54000302 	b.cs	8cb8 <fwp_hof0.constprop.0+0xe08>  // b.hs, b.nlast
    8c5c:	d350fc22 	lsr	x2, x1, #16
    8c60:	f949ff47 	ldr	x7, [x26, #5112]
    8c64:	8b020842 	add	x2, x2, x2, lsl #2
    8c68:	d37df042 	lsl	x2, x2, #3
    8c6c:	8b0200e6 	add	x6, x7, x2
    8c70:	f94010d8 	ldr	x24, [x6, #32]
    8c74:	b4000238 	cbz	x24, 8cb8 <fwp_hof0.constprop.0+0xe08>
    8c78:	386268e2 	ldrb	w2, [x7, x2]
    8c7c:	7100085f 	cmp	w2, #0x2
    8c80:	54001440 	b.eq	8f08 <fwp_hof0.constprop.0+0x1058>  // b.none
    8c84:	7100045f 	cmp	w2, #0x1
    8c88:	54000181 	b.ne	8cb8 <fwp_hof0.constprop.0+0xe08>  // b.any
    8c8c:	294308c7 	ldp	w7, w2, [x6, #24]
    8c90:	92403c21 	and	x1, x1, #0xffff
    8c94:	9b077c21 	mul	x1, x1, x7
    8c98:	d360fc21 	lsr	x1, x1, #32
    8c9c:	eb02003f 	cmp	x1, x2
    8ca0:	540000c2 	b.cs	8cb8 <fwp_hof0.constprop.0+0xe08>  // b.hs, b.nlast
    8ca4:	8b010318 	add	x24, x24, x1
    8ca8:	39400301 	ldrb	w1, [x24]
    8cac:	7103fc3f 	cmp	w1, #0xff
    8cb0:	54001260 	b.eq	8efc <fwp_hof0.constprop.0+0x104c>  // b.none
    8cb4:	39000319 	strb	w25, [x24]
    8cb8:	d10006f7 	sub	x23, x23, #0x1
    8cbc:	b10006ff 	cmn	x23, #0x1
    8cc0:	54fffb81 	b.ne	8c30 <fwp_hof0.constprop.0+0xd80>  // b.any
    8cc4:	14000015 	b	8d18 <fwp_hof0.constprop.0+0xe68>
    8cc8:	72003c1f 	tst	w0, #0xffff
    8ccc:	54fff320 	b.eq	8b30 <fwp_hof0.constprop.0+0xc80>  // b.none
    8cd0:	eb1700bf 	cmp	x5, x23
    8cd4:	54fff388 	b.hi	8b44 <fwp_hof0.constprop.0+0xc94>  // b.pmore
    8cd8:	d280001c 	mov	x28, #0x0                   	// #0
    8cdc:	8b170f64 	add	x4, x27, x23, lsl #3
    8ce0:	aa1b03e1 	mov	x1, x27
    8ce4:	aa1503e0 	mov	x0, x21
    8ce8:	f8408422 	ldr	x2, [x1], #8
    8cec:	f9000402 	str	x2, [x0, #8]
    8cf0:	aa0003e2 	mov	x2, x0
    8cf4:	f9400800 	ldr	x0, [x0, #16]
    8cf8:	eb04003f 	cmp	x1, x4
    8cfc:	54ffff61 	b.ne	8ce8 <fwp_hof0.constprop.0+0xe38>  // b.any
    8d00:	b94033e1 	ldr	w1, [sp, #48]
    8d04:	f900085c 	str	x28, [x2, #16]
    8d08:	aa1503fc 	mov	x28, x21
    8d0c:	aa0003f5 	mov	x21, x0
    8d10:	34000041 	cbz	w1, 8d18 <fwp_hof0.constprop.0+0xe68>
    8d14:	d280001b 	mov	x27, #0x0                   	// #0
    8d18:	91158293 	add	x19, x20, #0x560
    8d1c:	aa1b03e0 	mov	x0, x27
    8d20:	97ffeec8 	bl	4840 <fwp_mem_free>
    8d24:	f949ee62 	ldr	x2, [x19, #5080]
    8d28:	f949da61 	ldr	x1, [x19, #5040]
    8d2c:	d370bc42 	lsl	x2, x2, #16
    8d30:	cb0102c3 	sub	x3, x22, x1
    8d34:	eb02007f 	cmp	x3, x2
    8d38:	54000402 	b.cs	8db8 <fwp_hof0.constprop.0+0xf08>  // b.hs, b.nlast
    8d3c:	d350fc60 	lsr	x0, x3, #16
    8d40:	f949fe65 	ldr	x5, [x19, #5112]
    8d44:	8b000800 	add	x0, x0, x0, lsl #2
    8d48:	d37df000 	lsl	x0, x0, #3
    8d4c:	8b0000a2 	add	x2, x5, x0
    8d50:	f9401057 	ldr	x23, [x2, #32]
    8d54:	b4000cb7 	cbz	x23, 8ee8 <fwp_hof0.constprop.0+0x1038>
    8d58:	386068a1 	ldrb	w1, [x5, x0]
    8d5c:	7100083f 	cmp	w1, #0x2
    8d60:	54003160 	b.eq	938c <fwp_hof0.constprop.0+0x14dc>  // b.none
    8d64:	7100043f 	cmp	w1, #0x1
    8d68:	54000c01 	b.ne	8ee8 <fwp_hof0.constprop.0+0x1038>  // b.any
    8d6c:	29430844 	ldp	w4, w2, [x2, #24]
    8d70:	92403c61 	and	x1, x3, #0xffff
    8d74:	9b047c21 	mul	x1, x1, x4
    8d78:	d360fc21 	lsr	x1, x1, #32
    8d7c:	eb02003f 	cmp	x1, x2
    8d80:	54000b42 	b.cs	8ee8 <fwp_hof0.constprop.0+0x1038>  // b.hs, b.nlast
    8d84:	8b0102f7 	add	x23, x23, x1
    8d88:	394002e1 	ldrb	w1, [x23]
    8d8c:	34000ae1 	cbz	w1, 8ee8 <fwp_hof0.constprop.0+0x1038>
    8d90:	7100043f 	cmp	w1, #0x1
    8d94:	540006a0 	b.eq	8e68 <fwp_hof0.constprop.0+0xfb8>  // b.none
    8d98:	7103fc3f 	cmp	w1, #0xff
    8d9c:	54004a00 	b.eq	96dc <fwp_hof0.constprop.0+0x182c>  // b.none
    8da0:	91158280 	add	x0, x20, #0x560
    8da4:	51000421 	sub	w1, w1, #0x1
    8da8:	390002e1 	strb	w1, [x23]
    8dac:	f949ec02 	ldr	x2, [x0, #5080]
    8db0:	f949d801 	ldr	x1, [x0, #5040]
    8db4:	d370bc42 	lsl	x2, x2, #16
    8db8:	cb0102a1 	sub	x1, x21, x1
    8dbc:	eb02003f 	cmp	x1, x2
    8dc0:	540003c2 	b.cs	8e38 <fwp_hof0.constprop.0+0xf88>  // b.hs, b.nlast
    8dc4:	91158296 	add	x22, x20, #0x560
    8dc8:	d350fc20 	lsr	x0, x1, #16
    8dcc:	f949fec3 	ldr	x3, [x22, #5112]
    8dd0:	8b000800 	add	x0, x0, x0, lsl #2
    8dd4:	d37df000 	lsl	x0, x0, #3
    8dd8:	8b000062 	add	x2, x3, x0
    8ddc:	f9401053 	ldr	x19, [x2, #32]
    8de0:	b40002d3 	cbz	x19, 8e38 <fwp_hof0.constprop.0+0xf88>
    8de4:	38606860 	ldrb	w0, [x3, x0]
    8de8:	7100081f 	cmp	w0, #0x2
    8dec:	54003180 	b.eq	941c <fwp_hof0.constprop.0+0x156c>  // b.none
    8df0:	7100041f 	cmp	w0, #0x1
    8df4:	54000221 	b.ne	8e38 <fwp_hof0.constprop.0+0xf88>  // b.any
    8df8:	29430044 	ldp	w4, w0, [x2, #24]
    8dfc:	92403c21 	and	x1, x1, #0xffff
    8e00:	9b047c21 	mul	x1, x1, x4
    8e04:	d360fc21 	lsr	x1, x1, #32
    8e08:	eb00003f 	cmp	x1, x0
    8e0c:	54000162 	b.cs	8e38 <fwp_hof0.constprop.0+0xf88>  // b.hs, b.nlast
    8e10:	8b010273 	add	x19, x19, x1
    8e14:	39400260 	ldrb	w0, [x19]
    8e18:	34000100 	cbz	w0, 8e38 <fwp_hof0.constprop.0+0xf88>
    8e1c:	7100041f 	cmp	w0, #0x1
    8e20:	54003840 	b.eq	9528 <fwp_hof0.constprop.0+0x1678>  // b.none
    8e24:	7103fc1f 	cmp	w0, #0xff
    8e28:	54004940 	b.eq	9750 <fwp_hof0.constprop.0+0x18a0>  // b.none
    8e2c:	51000400 	sub	w0, w0, #0x1
    8e30:	39000260 	strb	w0, [x19]
    8e34:	d503201f 	nop
    8e38:	f94007e0 	ldr	x0, [sp, #8]
    8e3c:	b40019e0 	cbz	x0, 9178 <fwp_hof0.constprop.0+0x12c8>
    8e40:	f94007e0 	ldr	x0, [sp, #8]
    8e44:	f100041a 	subs	x26, x0, #0x1
    8e48:	f90007fa 	str	x26, [sp, #8]
    8e4c:	540057e6 	b.vs	9948 <fwp_hof0.constprop.0+0x1a98>
    8e50:	91158280 	add	x0, x20, #0x560
    8e54:	aa1c03f5 	mov	x21, x28
    8e58:	f949ec03 	ldr	x3, [x0, #5080]
    8e5c:	f949d801 	ldr	x1, [x0, #5040]
    8e60:	d370bc63 	lsl	x3, x3, #16
    8e64:	17fffc57 	b	7fc0 <fwp_hof0.constprop.0+0x110>
    8e68:	f94002c3 	ldr	x3, [x22]
    8e6c:	aa1603e0 	mov	x0, x22
    8e70:	f949ee62 	ldr	x2, [x19, #5080]
    8e74:	f949da61 	ldr	x1, [x19, #5040]
    8e78:	d370bc42 	lsl	x2, x2, #16
    8e7c:	cb0102c7 	sub	x7, x22, x1
    8e80:	b7f82d43 	tbnz	x3, #63, 9428 <fwp_hof0.constprop.0+0x1578>
    8e84:	eb07005f 	cmp	x2, x7
    8e88:	54fff989 	b.ls	8db8 <fwp_hof0.constprop.0+0xf08>  // b.plast
    8e8c:	d350fce3 	lsr	x3, x7, #16
    8e90:	8b030863 	add	x3, x3, x3, lsl #2
    8e94:	d37df063 	lsl	x3, x3, #3
    8e98:	8b0300a6 	add	x6, x5, x3
    8e9c:	f94010c4 	ldr	x4, [x6, #32]
    8ea0:	b4fff8c4 	cbz	x4, 8db8 <fwp_hof0.constprop.0+0xf08>
    8ea4:	386368a3 	ldrb	w3, [x5, x3]
    8ea8:	7100087f 	cmp	w3, #0x2
    8eac:	540038e0 	b.eq	95c8 <fwp_hof0.constprop.0+0x1718>  // b.none
    8eb0:	7100047f 	cmp	w3, #0x1
    8eb4:	54fff821 	b.ne	8db8 <fwp_hof0.constprop.0+0xf08>  // b.any
    8eb8:	29430cc5 	ldp	w5, w3, [x6, #24]
    8ebc:	92403ce0 	and	x0, x7, #0xffff
    8ec0:	9b057c00 	mul	x0, x0, x5
    8ec4:	d360fc00 	lsr	x0, x0, #32
    8ec8:	eb03001f 	cmp	x0, x3
    8ecc:	54fff762 	b.cs	8db8 <fwp_hof0.constprop.0+0xf08>  // b.hs, b.nlast
    8ed0:	8b000084 	add	x4, x4, x0
    8ed4:	39400080 	ldrb	w0, [x4]
    8ed8:	7100041f 	cmp	w0, #0x1
    8edc:	54fff6e1 	b.ne	8db8 <fwp_hof0.constprop.0+0xf08>  // b.any
    8ee0:	aa1603e0 	mov	x0, x22
    8ee4:	97ffee57 	bl	4840 <fwp_mem_free>
    8ee8:	91158280 	add	x0, x20, #0x560
    8eec:	f949ec02 	ldr	x2, [x0, #5080]
    8ef0:	f949d801 	ldr	x1, [x0, #5040]
    8ef4:	d370bc42 	lsl	x2, x2, #16
    8ef8:	17ffffb0 	b	8db8 <fwp_hof0.constprop.0+0xf08>
    8efc:	aa1803e0 	mov	x0, x24
    8f00:	97ffedb0 	bl	45c0 <fwp_rc_forget_slot>
    8f04:	17ffff6c 	b	8cb4 <fwp_hof0.constprop.0+0xe04>
    8f08:	72003c3f 	tst	w1, #0xffff
    8f0c:	54ffed61 	b.ne	8cb8 <fwp_hof0.constprop.0+0xe08>  // b.any
    8f10:	17ffff66 	b	8ca8 <fwp_hof0.constprop.0+0xdf8>
    8f14:	72003c1f 	tst	w0, #0xffff
    8f18:	54ffd840 	b.eq	8a20 <fwp_hof0.constprop.0+0xb70>  // b.none
    8f1c:	b4000ff5 	cbz	x21, 9118 <fwp_hof0.constprop.0+0x1268>
    8f20:	aa1503f3 	mov	x19, x21
    8f24:	d2800017 	mov	x23, #0x0                   	// #0
    8f28:	f9400a73 	ldr	x19, [x19, #16]
    8f2c:	aa1703e0 	mov	x0, x23
    8f30:	910006f7 	add	x23, x23, #0x1
    8f34:	b5ffffb3 	cbnz	x19, 8f28 <fwp_hof0.constprop.0+0x1078>
    8f38:	f9001be5 	str	x5, [sp, #48]
    8f3c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8f40:	eb0102ff 	cmp	x23, x1
    8f44:	54004c68 	b.hi	98d0 <fwp_hof0.constprop.0+0x1a20>  // b.pmore
    8f48:	91000800 	add	x0, x0, #0x2
    8f4c:	52800041 	mov	w1, #0x2                   	// #2
    8f50:	d37df000 	lsl	x0, x0, #3
    8f54:	97ffef5b 	bl	4cc0 <fwp_heap_alloc>
    8f58:	f9401be5 	ldr	x5, [sp, #48]
    8f5c:	aa0003fb 	mov	x27, x0
    8f60:	aa1503e1 	mov	x1, x21
    8f64:	eb0502ff 	cmp	x23, x5
    8f68:	9a8592e5 	csel	x5, x23, x5, ls	// ls = plast
    8f6c:	d503201f 	nop
    8f70:	f9400420 	ldr	x0, [x1, #8]
    8f74:	f8337b60 	str	x0, [x27, x19, lsl #3]
    8f78:	91000673 	add	x19, x19, #0x1
    8f7c:	f9400821 	ldr	x1, [x1, #16]
    8f80:	b5ffff81 	cbnz	x1, 8f70 <fwp_hof0.constprop.0+0x10c0>
    8f84:	b4000d25 	cbz	x5, 9128 <fwp_hof0.constprop.0+0x1278>
    8f88:	f9400384 	ldr	x4, [x28]
    8f8c:	b90033ff 	str	wzr, [sp, #48]
    8f90:	17fffeac 	b	8a40 <fwp_hof0.constprop.0+0xb90>
    8f94:	eb1302df 	cmp	x22, x19
    8f98:	54ff8f60 	b.eq	8184 <fwp_hof0.constprop.0+0x2d4>  // b.none
    8f9c:	900000c0 	adrp	x0, 20000 <__data_start>
    8fa0:	8b1606db 	add	x27, x22, x22, lsl #1
    8fa4:	f940181c 	ldr	x28, [x0, #48]
    8fa8:	8b1b0adb 	add	x27, x22, x27, lsl #2
    8fac:	90000020 	adrp	x0, c000 <fwp_main_thread+0x70>
    8fb0:	9138a000 	add	x0, x0, #0xe28
    8fb4:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    8fb8:	f900337f 	str	xzr, [x27, #96]
    8fbc:	97ffe695 	bl	2a10 <getenv@plt>
    8fc0:	b5ff9400 	cbnz	x0, 8240 <fwp_hof0.constprop.0+0x390>
    8fc4:	900000c0 	adrp	x0, 20000 <__data_start>
    8fc8:	9100c000 	add	x0, x0, #0x30
    8fcc:	f9405001 	ldr	x1, [x0, #160]
    8fd0:	b4ff9421 	cbz	x1, 8254 <fwp_hof0.constprop.0+0x3a4>
    8fd4:	3cc68002 	ldur	q2, [x0, #104]
    8fd8:	9101a001 	add	x1, x0, #0x68
    8fdc:	3cc78001 	ldur	q1, [x0, #120]
    8fe0:	f900501f 	str	xzr, [x0, #160]
    8fe4:	4f000400 	movi	v0.4s, #0x0
    8fe8:	ad010762 	stp	q2, q1, [x27, #32]
    8fec:	a9488002 	ldp	x2, x0, [x0, #136]
    8ff0:	f9000f60 	str	x0, [x27, #24]
    8ff4:	f9401820 	ldr	x0, [x1, #48]
    8ff8:	f9002362 	str	x2, [x27, #64]
    8ffc:	f9002760 	str	x0, [x27, #72]
    9000:	ad000020 	stp	q0, q0, [x1]
    9004:	3d800820 	str	q0, [x1, #32]
    9008:	f900183f 	str	xzr, [x1, #48]
    900c:	17fffc92 	b	8254 <fwp_hof0.constprop.0+0x3a4>
    9010:	d53bd040 	mrs	x0, tpidr_el0
    9014:	91400000 	add	x0, x0, #0x0, lsl #12
    9018:	91004000 	add	x0, x0, #0x10
    901c:	f9400000 	ldr	x0, [x0]
    9020:	b4002460 	cbz	x0, 94ac <fwp_hof0.constprop.0+0x15fc>
    9024:	f94017e1 	ldr	x1, [sp, #40]
    9028:	97ffe96f 	bl	35e4 <fwp_closure_drop_push>
    902c:	b5ff8655 	cbnz	x21, 80f4 <fwp_hof0.constprop.0+0x244>
    9030:	f00000a0 	adrp	x0, 20000 <__data_start>
    9034:	9100c013 	add	x19, x0, #0x30
    9038:	d2800017 	mov	x23, #0x0                   	// #0
    903c:	b9431660 	ldr	w0, [x19, #788]
    9040:	35ff8760 	cbnz	w0, 812c <fwp_hof0.constprop.0+0x27c>
    9044:	d503201f 	nop
    9048:	90ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x10c>
    904c:	91364000 	add	x0, x0, #0xd90
    9050:	94000edc 	bl	cbc0 <atexit>
    9054:	35ffc420 	cbnz	w0, 88d8 <fwp_hof0.constprop.0+0xa28>
    9058:	52800020 	mov	w0, #0x1                   	// #1
    905c:	b9031660 	str	w0, [x19, #788]
    9060:	17fffc33 	b	812c <fwp_hof0.constprop.0+0x27c>
    9064:	72003c1f 	tst	w0, #0xffff
    9068:	54ffbe40 	b.eq	8830 <fwp_hof0.constprop.0+0x980>  // b.none
    906c:	d503201f 	nop
    9070:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9074:	eb0002ff 	cmp	x23, x0
    9078:	54004508 	b.hi	9918 <fwp_hof0.constprop.0+0x1a68>  // b.pmore
    907c:	910006e0 	add	x0, x23, #0x1
    9080:	52800021 	mov	w1, #0x1                   	// #1
    9084:	d37df000 	lsl	x0, x0, #3
    9088:	97ffef0e 	bl	4cc0 <fwp_heap_alloc>
    908c:	91158282 	add	x2, x20, #0x560
    9090:	f9000017 	str	x23, [x0]
    9094:	aa0003fc 	mov	x28, x0
    9098:	aa0003f6 	mov	x22, x0
    909c:	f949d841 	ldr	x1, [x2, #5040]
    90a0:	f949ec40 	ldr	x0, [x2, #5080]
    90a4:	cb010381 	sub	x1, x28, x1
    90a8:	eb00403f 	cmp	x1, x0, lsl #16
    90ac:	54000322 	b.cs	9110 <fwp_hof0.constprop.0+0x1260>  // b.hs, b.nlast
    90b0:	d350fc20 	lsr	x0, x1, #16
    90b4:	f949fc44 	ldr	x4, [x2, #5112]
    90b8:	8b000800 	add	x0, x0, x0, lsl #2
    90bc:	d37df002 	lsl	x2, x0, #3
    90c0:	8b020083 	add	x3, x4, x2
    90c4:	f9401078 	ldr	x24, [x3, #32]
    90c8:	b4000258 	cbz	x24, 9110 <fwp_hof0.constprop.0+0x1260>
    90cc:	38626882 	ldrb	w2, [x4, x2]
    90d0:	7100085f 	cmp	w2, #0x2
    90d4:	54002800 	b.eq	95d4 <fwp_hof0.constprop.0+0x1724>  // b.none
    90d8:	7100045f 	cmp	w2, #0x1
    90dc:	540001a1 	b.ne	9110 <fwp_hof0.constprop.0+0x1260>  // b.any
    90e0:	29430864 	ldp	w4, w2, [x3, #24]
    90e4:	92403c21 	and	x1, x1, #0xffff
    90e8:	9b047c21 	mul	x1, x1, x4
    90ec:	d360fc21 	lsr	x1, x1, #32
    90f0:	eb02003f 	cmp	x1, x2
    90f4:	540000e2 	b.cs	9110 <fwp_hof0.constprop.0+0x1260>  // b.hs, b.nlast
    90f8:	8b010318 	add	x24, x24, x1
    90fc:	39400301 	ldrb	w1, [x24]
    9100:	7103fc3f 	cmp	w1, #0xff
    9104:	54002700 	b.eq	95e4 <fwp_hof0.constprop.0+0x1734>  // b.none
    9108:	52800021 	mov	w1, #0x1                   	// #1
    910c:	39000301 	strb	w1, [x24]
    9110:	aa1303e0 	mov	x0, x19
    9114:	17fffdcd 	b	8848 <fwp_hof0.constprop.0+0x998>
    9118:	52800041 	mov	w1, #0x2                   	// #2
    911c:	d2800100 	mov	x0, #0x8                   	// #8
    9120:	97ffeee8 	bl	4cc0 <fwp_heap_alloc>
    9124:	aa0003fb 	mov	x27, x0
    9128:	d280001c 	mov	x28, #0x0                   	// #0
    912c:	17fffefb 	b	8d18 <fwp_hof0.constprop.0+0xe68>
    9130:	52800041 	mov	w1, #0x2                   	// #2
    9134:	d2800100 	mov	x0, #0x8                   	// #8
    9138:	97ffeee2 	bl	4cc0 <fwp_heap_alloc>
    913c:	aa0003f7 	mov	x23, x0
    9140:	91158280 	add	x0, x20, #0x560
    9144:	aa1703fb 	mov	x27, x23
    9148:	f90002ff 	str	xzr, [x23]
    914c:	f949d801 	ldr	x1, [x0, #5040]
    9150:	f949ec00 	ldr	x0, [x0, #5080]
    9154:	cb0102e1 	sub	x1, x23, x1
    9158:	eb00403f 	cmp	x1, x0, lsl #16
    915c:	540010e2 	b.cs	9378 <fwp_hof0.constprop.0+0x14c8>  // b.hs, b.nlast
    9160:	d2800016 	mov	x22, #0x0                   	// #0
    9164:	17fffc81 	b	8368 <fwp_hof0.constprop.0+0x4b8>
    9168:	f9001fe0 	str	x0, [sp, #56]
    916c:	97ffed15 	bl	45c0 <fwp_rc_forget_slot>
    9170:	f9401fe0 	ldr	x0, [sp, #56]
    9174:	17fffe86 	b	8b8c <fwp_hof0.constprop.0+0xcdc>
    9178:	f9400be0 	ldr	x0, [sp, #16]
    917c:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xf3a8>
    9180:	910aa042 	add	x2, x2, #0x2a8
    9184:	aa1c03e1 	mov	x1, x28
    9188:	91014042 	add	x2, x2, #0x50
    918c:	52800023 	mov	w3, #0x1                   	// #1
    9190:	a9097fff 	stp	xzr, xzr, [sp, #144]
    9194:	f90053ff 	str	xzr, [sp, #160]
    9198:	97fff74a 	bl	6ec0 <fwp_write>
    919c:	a9495bf5 	ldp	x21, x22, [sp, #144]
    91a0:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    91a4:	91188000 	add	x0, x0, #0x620
    91a8:	f10002bf 	cmp	x21, #0x0
    91ac:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    91b0:	b1002adf 	cmn	x22, #0xa
    91b4:	54003ac8 	b.hi	990c <fwp_hof0.constprop.0+0x1a5c>  // b.pmore
    91b8:	910026c0 	add	x0, x22, #0x9
    91bc:	52800021 	mov	w1, #0x1                   	// #1
    91c0:	97ffeec0 	bl	4cc0 <fwp_heap_alloc>
    91c4:	aa0003f7 	mov	x23, x0
    91c8:	aa0003f3 	mov	x19, x0
    91cc:	aa1603e2 	mov	x2, x22
    91d0:	aa1503e1 	mov	x1, x21
    91d4:	f80086f6 	str	x22, [x23], #8
    91d8:	8b160276 	add	x22, x19, x22
    91dc:	aa1703e0 	mov	x0, x23
    91e0:	97ffe53c 	bl	26d0 <memcpy@plt>
    91e4:	390022df 	strb	wzr, [x22, #8]
    91e8:	f9404be0 	ldr	x0, [sp, #144]
    91ec:	97ffe5d5 	bl	2940 <free@plt>
    91f0:	91158281 	add	x1, x20, #0x560
    91f4:	f949d822 	ldr	x2, [x1, #5040]
    91f8:	f949ec20 	ldr	x0, [x1, #5080]
    91fc:	cb020262 	sub	x2, x19, x2
    9200:	eb00405f 	cmp	x2, x0, lsl #16
    9204:	54000322 	b.cs	9268 <fwp_hof0.constprop.0+0x13b8>  // b.hs, b.nlast
    9208:	d350fc40 	lsr	x0, x2, #16
    920c:	f949fc23 	ldr	x3, [x1, #5112]
    9210:	8b000800 	add	x0, x0, x0, lsl #2
    9214:	d37df001 	lsl	x1, x0, #3
    9218:	8b010060 	add	x0, x3, x1
    921c:	f9401015 	ldr	x21, [x0, #32]
    9220:	b4000255 	cbz	x21, 9268 <fwp_hof0.constprop.0+0x13b8>
    9224:	38616861 	ldrb	w1, [x3, x1]
    9228:	7100083f 	cmp	w1, #0x2
    922c:	54002be0 	b.eq	97a8 <fwp_hof0.constprop.0+0x18f8>  // b.none
    9230:	7100043f 	cmp	w1, #0x1
    9234:	540001a1 	b.ne	9268 <fwp_hof0.constprop.0+0x13b8>  // b.any
    9238:	29430003 	ldp	w3, w0, [x0, #24]
    923c:	92403c41 	and	x1, x2, #0xffff
    9240:	9b037c21 	mul	x1, x1, x3
    9244:	d360fc21 	lsr	x1, x1, #32
    9248:	eb00003f 	cmp	x1, x0
    924c:	540000e2 	b.cs	9268 <fwp_hof0.constprop.0+0x13b8>  // b.hs, b.nlast
    9250:	8b0102b5 	add	x21, x21, x1
    9254:	394002a0 	ldrb	w0, [x21]
    9258:	7103fc1f 	cmp	w0, #0xff
    925c:	54002b00 	b.eq	97bc <fwp_hof0.constprop.0+0x190c>  // b.none
    9260:	52800020 	mov	w0, #0x1                   	// #1
    9264:	390002a0 	strb	w0, [x21]
    9268:	aa1c03e0 	mov	x0, x28
    926c:	97fff1d5 	bl	59c0 <fwp_drop0>
    9270:	f00000a0 	adrp	x0, 20000 <__data_start>
    9274:	9100c015 	add	x21, x0, #0x30
    9278:	f9400262 	ldr	x2, [x19]
    927c:	d2800021 	mov	x1, #0x1                   	// #1
    9280:	f94006a3 	ldr	x3, [x21, #8]
    9284:	aa1703e0 	mov	x0, x23
    9288:	97ffe5be 	bl	2980 <fwrite@plt>
    928c:	f94006a1 	ldr	x1, [x21, #8]
    9290:	52800140 	mov	w0, #0xa                   	// #10
    9294:	97ffe543 	bl	27a0 <fputc@plt>
    9298:	91158281 	add	x1, x20, #0x560
    929c:	f949d822 	ldr	x2, [x1, #5040]
    92a0:	f949ec20 	ldr	x0, [x1, #5080]
    92a4:	cb020262 	sub	x2, x19, x2
    92a8:	eb00405f 	cmp	x2, x0, lsl #16
    92ac:	54000382 	b.cs	931c <fwp_hof0.constprop.0+0x146c>  // b.hs, b.nlast
    92b0:	d350fc40 	lsr	x0, x2, #16
    92b4:	f949fc23 	ldr	x3, [x1, #5112]
    92b8:	8b000800 	add	x0, x0, x0, lsl #2
    92bc:	d37df001 	lsl	x1, x0, #3
    92c0:	8b010060 	add	x0, x3, x1
    92c4:	f9401015 	ldr	x21, [x0, #32]
    92c8:	b40002b5 	cbz	x21, 931c <fwp_hof0.constprop.0+0x146c>
    92cc:	38616861 	ldrb	w1, [x3, x1]
    92d0:	7100083f 	cmp	w1, #0x2
    92d4:	54002380 	b.eq	9744 <fwp_hof0.constprop.0+0x1894>  // b.none
    92d8:	7100043f 	cmp	w1, #0x1
    92dc:	54000201 	b.ne	931c <fwp_hof0.constprop.0+0x146c>  // b.any
    92e0:	29430003 	ldp	w3, w0, [x0, #24]
    92e4:	92403c41 	and	x1, x2, #0xffff
    92e8:	9b037c21 	mul	x1, x1, x3
    92ec:	d360fc21 	lsr	x1, x1, #32
    92f0:	eb00003f 	cmp	x1, x0
    92f4:	54000142 	b.cs	931c <fwp_hof0.constprop.0+0x146c>  // b.hs, b.nlast
    92f8:	8b0102b5 	add	x21, x21, x1
    92fc:	394002a0 	ldrb	w0, [x21]
    9300:	340000e0 	cbz	w0, 931c <fwp_hof0.constprop.0+0x146c>
    9304:	7100041f 	cmp	w0, #0x1
    9308:	54001a60 	b.eq	9654 <fwp_hof0.constprop.0+0x17a4>  // b.none
    930c:	7103fc1f 	cmp	w0, #0xff
    9310:	54002ae0 	b.eq	986c <fwp_hof0.constprop.0+0x19bc>  // b.none
    9314:	51000400 	sub	w0, w0, #0x1
    9318:	390002a0 	strb	w0, [x21]
    931c:	f94027e0 	ldr	x0, [sp, #72]
    9320:	f9400800 	ldr	x0, [x0, #16]
    9324:	f90027e0 	str	x0, [sp, #72]
    9328:	b5ff5fa0 	cbnz	x0, 7f1c <fwp_hof0.constprop.0+0x6c>
    932c:	a94f53f3 	ldp	x19, x20, [sp, #240]
    9330:	a9505bf5 	ldp	x21, x22, [sp, #256]
    9334:	a95163f7 	ldp	x23, x24, [sp, #272]
    9338:	a9526bf9 	ldp	x25, x26, [sp, #288]
    933c:	a95373fb 	ldp	x27, x28, [sp, #304]
    9340:	6d5427e8 	ldp	d8, d9, [sp, #320]
    9344:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9348:	f947f400 	ldr	x0, [x0, #4072]
    934c:	f9406fe2 	ldr	x2, [sp, #216]
    9350:	f9400001 	ldr	x1, [x0]
    9354:	eb010042 	subs	x2, x2, x1
    9358:	d2800001 	mov	x1, #0x0                   	// #0
    935c:	54002e81 	b.ne	992c <fwp_hof0.constprop.0+0x1a7c>  // b.any
    9360:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    9364:	d2800000 	mov	x0, #0x0                   	// #0
    9368:	910543ff 	add	sp, sp, #0x150
    936c:	d65f03c0 	ret
    9370:	b5ff8316 	cbnz	x22, 83d0 <fwp_hof0.constprop.0+0x520>
    9374:	d503201f 	nop
    9378:	d280001c 	mov	x28, #0x0                   	// #0
    937c:	17fffc3c 	b	846c <fwp_hof0.constprop.0+0x5bc>
    9380:	72003c3f 	tst	w1, #0xffff
    9384:	54ff8be1 	b.ne	8500 <fwp_hof0.constprop.0+0x650>  // b.any
    9388:	17fffc56 	b	84e0 <fwp_hof0.constprop.0+0x630>
    938c:	72003c7f 	tst	w3, #0xffff
    9390:	54ffdac1 	b.ne	8ee8 <fwp_hof0.constprop.0+0x1038>  // b.any
    9394:	17fffe7d 	b	8d88 <fwp_hof0.constprop.0+0xed8>
    9398:	f940077b 	ldr	x27, [x27, #8]
    939c:	eb02007f 	cmp	x3, x2
    93a0:	54000369 	b.ls	940c <fwp_hof0.constprop.0+0x155c>  // b.plast
    93a4:	d350fc45 	lsr	x5, x2, #16
    93a8:	8b0508a5 	add	x5, x5, x5, lsl #2
    93ac:	d37df0a5 	lsl	x5, x5, #3
    93b0:	8b050087 	add	x7, x4, x5
    93b4:	f94010e6 	ldr	x6, [x7, #32]
    93b8:	b40002a6 	cbz	x6, 940c <fwp_hof0.constprop.0+0x155c>
    93bc:	38656884 	ldrb	w4, [x4, x5]
    93c0:	7100089f 	cmp	w4, #0x2
    93c4:	540013c0 	b.eq	963c <fwp_hof0.constprop.0+0x178c>  // b.none
    93c8:	7100049f 	cmp	w4, #0x1
    93cc:	54000201 	b.ne	940c <fwp_hof0.constprop.0+0x155c>  // b.any
    93d0:	294310e5 	ldp	w5, w4, [x7, #24]
    93d4:	92403c42 	and	x2, x2, #0xffff
    93d8:	9b057c42 	mul	x2, x2, x5
    93dc:	d360fc42 	lsr	x2, x2, #32
    93e0:	eb04005f 	cmp	x2, x4
    93e4:	54000142 	b.cs	940c <fwp_hof0.constprop.0+0x155c>  // b.hs, b.nlast
    93e8:	8b0200c6 	add	x6, x6, x2
    93ec:	394000c2 	ldrb	w2, [x6]
    93f0:	7100045f 	cmp	w2, #0x1
    93f4:	540000c1 	b.ne	940c <fwp_hof0.constprop.0+0x155c>  // b.any
    93f8:	97ffed12 	bl	4840 <fwp_mem_free>
    93fc:	91158280 	add	x0, x20, #0x560
    9400:	f949ec03 	ldr	x3, [x0, #5080]
    9404:	f949d801 	ldr	x1, [x0, #5040]
    9408:	d370bc63 	lsl	x3, x3, #16
    940c:	cb010361 	sub	x1, x27, x1
    9410:	eb03003f 	cmp	x1, x3
    9414:	54ff8403 	b.cc	8494 <fwp_hof0.constprop.0+0x5e4>  // b.lo, b.ul, b.last
    9418:	17fffc3a 	b	8500 <fwp_hof0.constprop.0+0x650>
    941c:	72003c3f 	tst	w1, #0xffff
    9420:	54ffd0c1 	b.ne	8e38 <fwp_hof0.constprop.0+0xf88>  // b.any
    9424:	17fffe7c 	b	8e14 <fwp_hof0.constprop.0+0xf64>
    9428:	f94006d6 	ldr	x22, [x22, #8]
    942c:	eb07005f 	cmp	x2, x7
    9430:	54000369 	b.ls	949c <fwp_hof0.constprop.0+0x15ec>  // b.plast
    9434:	d350fce3 	lsr	x3, x7, #16
    9438:	8b030863 	add	x3, x3, x3, lsl #2
    943c:	d37df063 	lsl	x3, x3, #3
    9440:	8b0300a6 	add	x6, x5, x3
    9444:	f94010c4 	ldr	x4, [x6, #32]
    9448:	b40002a4 	cbz	x4, 949c <fwp_hof0.constprop.0+0x15ec>
    944c:	386368a3 	ldrb	w3, [x5, x3]
    9450:	7100087f 	cmp	w3, #0x2
    9454:	54000fa0 	b.eq	9648 <fwp_hof0.constprop.0+0x1798>  // b.none
    9458:	7100047f 	cmp	w3, #0x1
    945c:	54000201 	b.ne	949c <fwp_hof0.constprop.0+0x15ec>  // b.any
    9460:	294314c8 	ldp	w8, w5, [x6, #24]
    9464:	92403ce3 	and	x3, x7, #0xffff
    9468:	9b087c63 	mul	x3, x3, x8
    946c:	d360fc63 	lsr	x3, x3, #32
    9470:	eb05007f 	cmp	x3, x5
    9474:	54000142 	b.cs	949c <fwp_hof0.constprop.0+0x15ec>  // b.hs, b.nlast
    9478:	8b030084 	add	x4, x4, x3
    947c:	39400083 	ldrb	w3, [x4]
    9480:	7100047f 	cmp	w3, #0x1
    9484:	540000c1 	b.ne	949c <fwp_hof0.constprop.0+0x15ec>  // b.any
    9488:	97ffecee 	bl	4840 <fwp_mem_free>
    948c:	91158280 	add	x0, x20, #0x560
    9490:	f949ec02 	ldr	x2, [x0, #5080]
    9494:	f949d801 	ldr	x1, [x0, #5040]
    9498:	d370bc42 	lsl	x2, x2, #16
    949c:	cb0102c3 	sub	x3, x22, x1
    94a0:	eb02007f 	cmp	x3, x2
    94a4:	54ffc4c3 	b.cc	8d3c <fwp_hof0.constprop.0+0xe8c>  // b.lo, b.ul, b.last
    94a8:	17fffe44 	b	8db8 <fwp_hof0.constprop.0+0xf08>
    94ac:	f94017e0 	ldr	x0, [sp, #40]
    94b0:	97ffe8bc 	bl	37a0 <fwp_closure_drop.part.0>
    94b4:	17fffb0f 	b	80f0 <fwp_hof0.constprop.0+0x240>
    94b8:	72003c3f 	tst	w1, #0xffff
    94bc:	54ff7881 	b.ne	83cc <fwp_hof0.constprop.0+0x51c>  // b.any
    94c0:	39400380 	ldrb	w0, [x28]
    94c4:	7103fc1f 	cmp	w0, #0xff
    94c8:	54ff77e1 	b.ne	83c4 <fwp_hof0.constprop.0+0x514>  // b.any
    94cc:	aa1c03e0 	mov	x0, x28
    94d0:	97ffec3c 	bl	45c0 <fwp_rc_forget_slot>
    94d4:	17fffbbc 	b	83c4 <fwp_hof0.constprop.0+0x514>
    94d8:	72003c3f 	tst	w1, #0xffff
    94dc:	54ff60a1 	b.ne	80f0 <fwp_hof0.constprop.0+0x240>  // b.any
    94e0:	17fffafc 	b	80d0 <fwp_hof0.constprop.0+0x220>
    94e4:	72003c3f 	tst	w1, #0xffff
    94e8:	54ff5dc1 	b.ne	80a0 <fwp_hof0.constprop.0+0x1f0>  // b.any
    94ec:	aa1303e0 	mov	x0, x19
    94f0:	17fffad9 	b	8054 <fwp_hof0.constprop.0+0x1a4>
    94f4:	aa1c03f3 	mov	x19, x28
    94f8:	17fffc38 	b	85d8 <fwp_hof0.constprop.0+0x728>
    94fc:	72003c3f 	tst	w1, #0xffff
    9500:	54ff94e1 	b.ne	879c <fwp_hof0.constprop.0+0x8ec>  // b.any
    9504:	394002c0 	ldrb	w0, [x22]
    9508:	7103fc1f 	cmp	w0, #0xff
    950c:	54ff9441 	b.ne	8794 <fwp_hof0.constprop.0+0x8e4>  // b.any
    9510:	aa1603e0 	mov	x0, x22
    9514:	97ffec2b 	bl	45c0 <fwp_rc_forget_slot>
    9518:	17fffc9f 	b	8794 <fwp_hof0.constprop.0+0x8e4>
    951c:	72003c5f 	tst	w2, #0xffff
    9520:	54ff7f01 	b.ne	8500 <fwp_hof0.constprop.0+0x650>  // b.any
    9524:	17fffd14 	b	8974 <fwp_hof0.constprop.0+0xac4>
    9528:	91158280 	add	x0, x20, #0x560
    952c:	f9400ab3 	ldr	x19, [x21, #16]
    9530:	f949ec04 	ldr	x4, [x0, #5080]
    9534:	f949d801 	ldr	x1, [x0, #5040]
    9538:	d370bc84 	lsl	x4, x4, #16
    953c:	cb0102a0 	sub	x0, x21, x1
    9540:	eb04001f 	cmp	x0, x4
    9544:	54000382 	b.cs	95b4 <fwp_hof0.constprop.0+0x1704>  // b.hs, b.nlast
    9548:	d350fc02 	lsr	x2, x0, #16
    954c:	8b020842 	add	x2, x2, x2, lsl #2
    9550:	d37df042 	lsl	x2, x2, #3
    9554:	8b020066 	add	x6, x3, x2
    9558:	f94010c5 	ldr	x5, [x6, #32]
    955c:	b40002c5 	cbz	x5, 95b4 <fwp_hof0.constprop.0+0x1704>
    9560:	38626862 	ldrb	w2, [x3, x2]
    9564:	7100085f 	cmp	w2, #0x2
    9568:	540007c0 	b.eq	9660 <fwp_hof0.constprop.0+0x17b0>  // b.none
    956c:	7100045f 	cmp	w2, #0x1
    9570:	54000221 	b.ne	95b4 <fwp_hof0.constprop.0+0x1704>  // b.any
    9574:	294308c3 	ldp	w3, w2, [x6, #24]
    9578:	92403c00 	and	x0, x0, #0xffff
    957c:	9b037c00 	mul	x0, x0, x3
    9580:	d360fc00 	lsr	x0, x0, #32
    9584:	eb02001f 	cmp	x0, x2
    9588:	54000162 	b.cs	95b4 <fwp_hof0.constprop.0+0x1704>  // b.hs, b.nlast
    958c:	8b0000a5 	add	x5, x5, x0
    9590:	394000a0 	ldrb	w0, [x5]
    9594:	7100041f 	cmp	w0, #0x1
    9598:	540000e1 	b.ne	95b4 <fwp_hof0.constprop.0+0x1704>  // b.any
    959c:	aa1503e0 	mov	x0, x21
    95a0:	97ffeca8 	bl	4840 <fwp_mem_free>
    95a4:	91158280 	add	x0, x20, #0x560
    95a8:	f949ec04 	ldr	x4, [x0, #5080]
    95ac:	f949d801 	ldr	x1, [x0, #5040]
    95b0:	d370bc84 	lsl	x4, x4, #16
    95b4:	cb010261 	sub	x1, x19, x1
    95b8:	eb01009f 	cmp	x4, x1
    95bc:	54ffc3e9 	b.ls	8e38 <fwp_hof0.constprop.0+0xf88>  // b.plast
    95c0:	aa1303f5 	mov	x21, x19
    95c4:	17fffe01 	b	8dc8 <fwp_hof0.constprop.0+0xf18>
    95c8:	72003cff 	tst	w7, #0xffff
    95cc:	54ffbf61 	b.ne	8db8 <fwp_hof0.constprop.0+0xf08>  // b.any
    95d0:	17fffe41 	b	8ed4 <fwp_hof0.constprop.0+0x1024>
    95d4:	72003c3f 	tst	w1, #0xffff
    95d8:	54ffd920 	b.eq	90fc <fwp_hof0.constprop.0+0x124c>  // b.none
    95dc:	aa1303e0 	mov	x0, x19
    95e0:	17fffc9a 	b	8848 <fwp_hof0.constprop.0+0x998>
    95e4:	aa1803e0 	mov	x0, x24
    95e8:	97ffebf6 	bl	45c0 <fwp_rc_forget_slot>
    95ec:	17fffec7 	b	9108 <fwp_hof0.constprop.0+0x1258>
    95f0:	aa1703e0 	mov	x0, x23
    95f4:	d2800101 	mov	x1, #0x8                   	// #8
    95f8:	97ffe49a 	bl	2860 <calloc@plt>
    95fc:	aa0003f8 	mov	x24, x0
    9600:	f9401be7 	ldr	x7, [sp, #48]
    9604:	17fffc07 	b	8620 <fwp_hof0.constprop.0+0x770>
    9608:	f9400384 	ldr	x4, [x28]
    960c:	b7ffd864 	tbnz	x4, #63, 9118 <fwp_hof0.constprop.0+0x1268>
    9610:	91158281 	add	x1, x20, #0x560
    9614:	f949d820 	ldr	x0, [x1, #5040]
    9618:	f949ec21 	ldr	x1, [x1, #5080]
    961c:	cb0002c0 	sub	x0, x22, x0
    9620:	eb01401f 	cmp	x0, x1, lsl #16
    9624:	54ffd7a2 	b.cs	9118 <fwp_hof0.constprop.0+0x1268>  // b.hs, b.nlast
    9628:	9240f885 	and	x5, x4, #0x7fffffffffffffff
    962c:	17fffce9 	b	89d0 <fwp_hof0.constprop.0+0xb20>
    9630:	d2800d01 	mov	x1, #0x68                  	// #104
    9634:	d280003b 	mov	x27, #0x1                   	// #1
    9638:	17fffae5 	b	81cc <fwp_hof0.constprop.0+0x31c>
    963c:	72003c5f 	tst	w2, #0xffff
    9640:	54ffee61 	b.ne	940c <fwp_hof0.constprop.0+0x155c>  // b.any
    9644:	17ffff6a 	b	93ec <fwp_hof0.constprop.0+0x153c>
    9648:	72003cff 	tst	w7, #0xffff
    964c:	54fff281 	b.ne	949c <fwp_hof0.constprop.0+0x15ec>  // b.any
    9650:	17ffff8b 	b	947c <fwp_hof0.constprop.0+0x15cc>
    9654:	aa1303e0 	mov	x0, x19
    9658:	97ffefaf 	bl	5514 <fwp_rc_free_arr>
    965c:	17ffff30 	b	931c <fwp_hof0.constprop.0+0x146c>
    9660:	72003c1f 	tst	w0, #0xffff
    9664:	54fffa81 	b.ne	95b4 <fwp_hof0.constprop.0+0x1704>  // b.any
    9668:	17ffffca 	b	9590 <fwp_hof0.constprop.0+0x16e0>
    966c:	72003c9f 	tst	w4, #0xffff
    9670:	54ff4a21 	b.ne	7fb4 <fwp_hof0.constprop.0+0x104>  // b.any
    9674:	17fffa45 	b	7f88 <fwp_hof0.constprop.0+0xd8>
    9678:	ca5746e0 	eor	x0, x23, x23, lsr #17
    967c:	91158281 	add	x1, x20, #0x560
    9680:	ca402400 	eor	x0, x0, x0, lsr #9
    9684:	8b200c20 	add	x0, x1, w0, uxtb #3
    9688:	f94a2400 	ldr	x0, [x0, #5192]
    968c:	b5000080 	cbnz	x0, 969c <fwp_hof0.constprop.0+0x17ec>
    9690:	14000010 	b	96d0 <fwp_hof0.constprop.0+0x1820>
    9694:	f9400800 	ldr	x0, [x0, #16]
    9698:	b40001c0 	cbz	x0, 96d0 <fwp_hof0.constprop.0+0x1820>
    969c:	f9400001 	ldr	x1, [x0]
    96a0:	eb17003f 	cmp	x1, x23
    96a4:	54ffff81 	b.ne	9694 <fwp_hof0.constprop.0+0x17e4>  // b.any
    96a8:	f9400401 	ldr	x1, [x0, #8]
    96ac:	d1000421 	sub	x1, x1, #0x1
    96b0:	f9000401 	str	x1, [x0, #8]
    96b4:	f103f83f 	cmp	x1, #0xfe
    96b8:	54ff7241 	b.ne	8500 <fwp_hof0.constprop.0+0x650>  // b.any
    96bc:	aa1703e0 	mov	x0, x23
    96c0:	97ffebc0 	bl	45c0 <fwp_rc_forget_slot>
    96c4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    96c8:	390002e0 	strb	w0, [x23]
    96cc:	17fffb8d 	b	8500 <fwp_hof0.constprop.0+0x650>
    96d0:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x70>
    96d4:	913a6000 	add	x0, x0, #0xe98
    96d8:	97ffe7aa 	bl	3580 <fwp_trap>
    96dc:	ca5746e0 	eor	x0, x23, x23, lsr #17
    96e0:	91158281 	add	x1, x20, #0x560
    96e4:	ca402400 	eor	x0, x0, x0, lsr #9
    96e8:	8b200c20 	add	x0, x1, w0, uxtb #3
    96ec:	f94a2401 	ldr	x1, [x0, #5192]
    96f0:	b5000081 	cbnz	x1, 9700 <fwp_hof0.constprop.0+0x1850>
    96f4:	17fffff7 	b	96d0 <fwp_hof0.constprop.0+0x1820>
    96f8:	f9400821 	ldr	x1, [x1, #16]
    96fc:	b4fffea1 	cbz	x1, 96d0 <fwp_hof0.constprop.0+0x1820>
    9700:	f9400020 	ldr	x0, [x1]
    9704:	eb17001f 	cmp	x0, x23
    9708:	54ffff81 	b.ne	96f8 <fwp_hof0.constprop.0+0x1848>  // b.any
    970c:	f9400420 	ldr	x0, [x1, #8]
    9710:	d1000400 	sub	x0, x0, #0x1
    9714:	f9000420 	str	x0, [x1, #8]
    9718:	f103f81f 	cmp	x0, #0xfe
    971c:	54ffbe61 	b.ne	8ee8 <fwp_hof0.constprop.0+0x1038>  // b.any
    9720:	aa1703e0 	mov	x0, x23
    9724:	97ffeba7 	bl	45c0 <fwp_rc_forget_slot>
    9728:	91158280 	add	x0, x20, #0x560
    972c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9730:	390002e1 	strb	w1, [x23]
    9734:	f949ec02 	ldr	x2, [x0, #5080]
    9738:	f949d801 	ldr	x1, [x0, #5040]
    973c:	d370bc42 	lsl	x2, x2, #16
    9740:	17fffd9e 	b	8db8 <fwp_hof0.constprop.0+0xf08>
    9744:	72003c5f 	tst	w2, #0xffff
    9748:	54ffdea1 	b.ne	931c <fwp_hof0.constprop.0+0x146c>  // b.any
    974c:	17fffeec 	b	92fc <fwp_hof0.constprop.0+0x144c>
    9750:	ca534660 	eor	x0, x19, x19, lsr #17
    9754:	91158281 	add	x1, x20, #0x560
    9758:	ca402400 	eor	x0, x0, x0, lsr #9
    975c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9760:	f94a2400 	ldr	x0, [x0, #5192]
    9764:	b5000080 	cbnz	x0, 9774 <fwp_hof0.constprop.0+0x18c4>
    9768:	17ffffda 	b	96d0 <fwp_hof0.constprop.0+0x1820>
    976c:	f9400800 	ldr	x0, [x0, #16]
    9770:	b4fffb00 	cbz	x0, 96d0 <fwp_hof0.constprop.0+0x1820>
    9774:	f9400001 	ldr	x1, [x0]
    9778:	eb01027f 	cmp	x19, x1
    977c:	54ffff81 	b.ne	976c <fwp_hof0.constprop.0+0x18bc>  // b.any
    9780:	f9400401 	ldr	x1, [x0, #8]
    9784:	d1000421 	sub	x1, x1, #0x1
    9788:	f9000401 	str	x1, [x0, #8]
    978c:	f103f83f 	cmp	x1, #0xfe
    9790:	54ffb541 	b.ne	8e38 <fwp_hof0.constprop.0+0xf88>  // b.any
    9794:	aa1303e0 	mov	x0, x19
    9798:	97ffeb8a 	bl	45c0 <fwp_rc_forget_slot>
    979c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    97a0:	39000260 	strb	w0, [x19]
    97a4:	17fffda5 	b	8e38 <fwp_hof0.constprop.0+0xf88>
    97a8:	72003c5f 	tst	w2, #0xffff
    97ac:	54ffd5e1 	b.ne	9268 <fwp_hof0.constprop.0+0x13b8>  // b.any
    97b0:	394002a0 	ldrb	w0, [x21]
    97b4:	7103fc1f 	cmp	w0, #0xff
    97b8:	54ffd541 	b.ne	9260 <fwp_hof0.constprop.0+0x13b0>  // b.any
    97bc:	aa1503e0 	mov	x0, x21
    97c0:	97ffeb80 	bl	45c0 <fwp_rc_forget_slot>
    97c4:	17fffea7 	b	9260 <fwp_hof0.constprop.0+0x13b0>
    97c8:	d280001b 	mov	x27, #0x0                   	// #0
    97cc:	d280001c 	mov	x28, #0x0                   	// #0
    97d0:	17fffd52 	b	8d18 <fwp_hof0.constprop.0+0xe68>
    97d4:	97ffeb34 	bl	44a4 <fwp_rc_wide_dup>
    97d8:	17fffa25 	b	806c <fwp_hof0.constprop.0+0x1bc>
    97dc:	ca534660 	eor	x0, x19, x19, lsr #17
    97e0:	91158281 	add	x1, x20, #0x560
    97e4:	ca402400 	eor	x0, x0, x0, lsr #9
    97e8:	8b200c20 	add	x0, x1, w0, uxtb #3
    97ec:	f94a2400 	ldr	x0, [x0, #5192]
    97f0:	b5000080 	cbnz	x0, 9800 <fwp_hof0.constprop.0+0x1950>
    97f4:	17ffffb7 	b	96d0 <fwp_hof0.constprop.0+0x1820>
    97f8:	f9400800 	ldr	x0, [x0, #16]
    97fc:	b4fff6a0 	cbz	x0, 96d0 <fwp_hof0.constprop.0+0x1820>
    9800:	f9400001 	ldr	x1, [x0]
    9804:	eb13003f 	cmp	x1, x19
    9808:	54ffff81 	b.ne	97f8 <fwp_hof0.constprop.0+0x1948>  // b.any
    980c:	f9400401 	ldr	x1, [x0, #8]
    9810:	d1000421 	sub	x1, x1, #0x1
    9814:	f9000401 	str	x1, [x0, #8]
    9818:	f103f83f 	cmp	x1, #0xfe
    981c:	54ff46a1 	b.ne	80f0 <fwp_hof0.constprop.0+0x240>  // b.any
    9820:	aa1303e0 	mov	x0, x19
    9824:	97ffeb67 	bl	45c0 <fwp_rc_forget_slot>
    9828:	12800020 	mov	w0, #0xfffffffe            	// #-2
    982c:	39000260 	strb	w0, [x19]
    9830:	17fffa30 	b	80f0 <fwp_hof0.constprop.0+0x240>
    9834:	d2800017 	mov	x23, #0x0                   	// #0
    9838:	17fffcc3 	b	8b44 <fwp_hof0.constprop.0+0xc94>
    983c:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x70>
    9840:	913b8000 	add	x0, x0, #0xee0
    9844:	97ffe74f 	bl	3580 <fwp_trap>
    9848:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x70>
    984c:	913de000 	add	x0, x0, #0xf78
    9850:	97ffe74c 	bl	3580 <fwp_trap>
    9854:	97ffeb14 	bl	44a4 <fwp_rc_wide_dup>
    9858:	91158280 	add	x0, x20, #0x560
    985c:	f949ec03 	ldr	x3, [x0, #5080]
    9860:	f949d801 	ldr	x1, [x0, #5040]
    9864:	d370bc63 	lsl	x3, x3, #16
    9868:	17fff9d3 	b	7fb4 <fwp_hof0.constprop.0+0x104>
    986c:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9870:	91158281 	add	x1, x20, #0x560
    9874:	ca402400 	eor	x0, x0, x0, lsr #9
    9878:	8b200c20 	add	x0, x1, w0, uxtb #3
    987c:	f94a2400 	ldr	x0, [x0, #5192]
    9880:	b5000080 	cbnz	x0, 9890 <fwp_hof0.constprop.0+0x19e0>
    9884:	17ffff93 	b	96d0 <fwp_hof0.constprop.0+0x1820>
    9888:	f9400800 	ldr	x0, [x0, #16]
    988c:	b4fff220 	cbz	x0, 96d0 <fwp_hof0.constprop.0+0x1820>
    9890:	f9400001 	ldr	x1, [x0]
    9894:	eb15003f 	cmp	x1, x21
    9898:	54ffff81 	b.ne	9888 <fwp_hof0.constprop.0+0x19d8>  // b.any
    989c:	f9400401 	ldr	x1, [x0, #8]
    98a0:	d1000421 	sub	x1, x1, #0x1
    98a4:	f9000401 	str	x1, [x0, #8]
    98a8:	f103f83f 	cmp	x1, #0xfe
    98ac:	54ffd381 	b.ne	931c <fwp_hof0.constprop.0+0x146c>  // b.any
    98b0:	aa1503e0 	mov	x0, x21
    98b4:	97ffeb43 	bl	45c0 <fwp_rc_forget_slot>
    98b8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    98bc:	390002a0 	strb	w0, [x21]
    98c0:	17fffe97 	b	931c <fwp_hof0.constprop.0+0x146c>
    98c4:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    98c8:	9104e000 	add	x0, x0, #0x138
    98cc:	97ffe72d 	bl	3580 <fwp_trap>
    98d0:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x70>
    98d4:	913f6000 	add	x0, x0, #0xfd8
    98d8:	97ffe72a 	bl	3580 <fwp_trap>
    98dc:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    98e0:	9105e000 	add	x0, x0, #0x178
    98e4:	97ffe727 	bl	3580 <fwp_trap>
    98e8:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    98ec:	9103e000 	add	x0, x0, #0xf8
    98f0:	97ffe724 	bl	3580 <fwp_trap>
    98f4:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    98f8:	91036000 	add	x0, x0, #0xd8
    98fc:	97ffe721 	bl	3580 <fwp_trap>
    9900:	f0000000 	adrp	x0, c000 <fwp_main_thread+0x70>
    9904:	913ca000 	add	x0, x0, #0xf28
    9908:	97ffe71e 	bl	3580 <fwp_trap>
    990c:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    9910:	91058000 	add	x0, x0, #0x160
    9914:	97ffe71b 	bl	3580 <fwp_trap>
    9918:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    991c:	9104a000 	add	x0, x0, #0x128
    9920:	97ffe718 	bl	3580 <fwp_trap>
    9924:	52800020 	mov	w0, #0x1                   	// #1
    9928:	17fffbe3 	b	88b4 <fwp_hof0.constprop.0+0xa04>
    992c:	a90f53f3 	stp	x19, x20, [sp, #240]
    9930:	a9105bf5 	stp	x21, x22, [sp, #256]
    9934:	a91163f7 	stp	x23, x24, [sp, #272]
    9938:	a9126bf9 	stp	x25, x26, [sp, #288]
    993c:	a91373fb 	stp	x27, x28, [sp, #304]
    9940:	6d1427e8 	stp	d8, d9, [sp, #320]
    9944:	97ffe3cf 	bl	2880 <__stack_chk_fail@plt>
    9948:	97ffe44e 	bl	2a80 <fwp_trap_overflow.constprop.0>
    994c:	97ffe3e1 	bl	28d0 <abort@plt>

0000000000009950 <f0>:
    9950:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9954:	910003fd 	mov	x29, sp
    9958:	a90153f3 	stp	x19, x20, [sp, #16]
    995c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9960:	a90363f7 	stp	x23, x24, [sp, #48]
    9964:	a9046bf9 	stp	x25, x26, [sp, #64]
    9968:	a90573fb 	stp	x27, x28, [sp, #80]
    996c:	d12183ff 	sub	sp, sp, #0x860
    9970:	f90203ff 	str	xzr, [sp, #1024]
    9974:	f00000a0 	adrp	x0, 20000 <__data_start>
    9978:	9100c005 	add	x5, x0, #0x30
    997c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9980:	f947f400 	ldr	x0, [x0, #4072]
    9984:	90000154 	adrp	x20, 31000 <fwp_root_context+0xc80>
    9988:	f94170a6 	ldr	x6, [x5, #736]
    998c:	f9400001 	ldr	x1, [x0]
    9990:	f9042fe1 	str	x1, [sp, #2136]
    9994:	d2800001 	mov	x1, #0x0                   	// #0
    9998:	91158298 	add	x24, x20, #0x560
    999c:	912123f6 	add	x22, sp, #0x848
    99a0:	910023e0 	add	x0, sp, #0x8
    99a4:	910083e2 	add	x2, sp, #0x20
    99a8:	90ffffe1 	adrp	x1, 5000 <fwp_p_ad_push+0x10c>
    99ac:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    99b0:	9121c021 	add	x1, x1, #0x870
    99b4:	913d4084 	add	x4, x4, #0xf50
    99b8:	d2800013 	mov	x19, #0x0                   	// #0
    99bc:	d2800119 	mov	x25, #0x8                   	// #8
    99c0:	d2800015 	mov	x21, #0x0                   	// #0
    99c4:	52800037 	mov	w23, #0x1                   	// #1
    99c8:	a90093e6 	stp	x6, x4, [sp, #8]
    99cc:	a901ffe2 	stp	x2, xzr, [sp, #24]
    99d0:	a90307ff 	stp	xzr, x1, [sp, #48]
    99d4:	f90170a0 	str	x0, [x5, #736]
    99d8:	f100073a 	subs	x26, x25, #0x1
    99dc:	aa1603e1 	mov	x1, x22
    99e0:	da1f02bc 	sbc	x28, x21, xzr
    99e4:	52800020 	mov	w0, #0x1                   	// #1
    99e8:	f90017fa 	str	x26, [sp, #40]
    99ec:	aa1a03f9 	mov	x25, x26
    99f0:	f90427fa 	str	x26, [sp, #2120]
    99f4:	aa1c03f5 	mov	x21, x28
    99f8:	f9042bf3 	str	x19, [sp, #2128]
    99fc:	97ffecf6 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9a00:	f949db02 	ldr	x2, [x24, #5040]
    9a04:	aa0003f3 	mov	x19, x0
    9a08:	f949ef00 	ldr	x0, [x24, #5080]
    9a0c:	cb020262 	sub	x2, x19, x2
    9a10:	eb00405f 	cmp	x2, x0, lsl #16
    9a14:	54000302 	b.cs	9a74 <f0+0x124>  // b.hs, b.nlast
    9a18:	d350fc40 	lsr	x0, x2, #16
    9a1c:	f949ff04 	ldr	x4, [x24, #5112]
    9a20:	8b000800 	add	x0, x0, x0, lsl #2
    9a24:	d37df001 	lsl	x1, x0, #3
    9a28:	8b010080 	add	x0, x4, x1
    9a2c:	f940101b 	ldr	x27, [x0, #32]
    9a30:	b400023b 	cbz	x27, 9a74 <f0+0x124>
    9a34:	38616881 	ldrb	w1, [x4, x1]
    9a38:	7100083f 	cmp	w1, #0x2
    9a3c:	54010ca0 	b.eq	bbd0 <f0+0x2280>  // b.none
    9a40:	7100043f 	cmp	w1, #0x1
    9a44:	54000181 	b.ne	9a74 <f0+0x124>  // b.any
    9a48:	29430001 	ldp	w1, w0, [x0, #24]
    9a4c:	92403c42 	and	x2, x2, #0xffff
    9a50:	9b017c42 	mul	x2, x2, x1
    9a54:	d360fc42 	lsr	x2, x2, #32
    9a58:	eb00005f 	cmp	x2, x0
    9a5c:	540000c2 	b.cs	9a74 <f0+0x124>  // b.hs, b.nlast
    9a60:	8b02037b 	add	x27, x27, x2
    9a64:	39400360 	ldrb	w0, [x27]
    9a68:	7103fc1f 	cmp	w0, #0xff
    9a6c:	54010ac0 	b.eq	bbc4 <f0+0x2274>  // b.none
    9a70:	39000377 	strb	w23, [x27]
    9a74:	f90013f3 	str	x19, [sp, #32]
    9a78:	aa1c035a 	orr	x26, x26, x28
    9a7c:	b5fffafa 	cbnz	x26, 99d8 <f0+0x88>
    9a80:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x410>
    9a84:	910103e1 	add	x1, sp, #0x40
    9a88:	f94007e2 	ldr	x2, [sp, #8]
    9a8c:	3dc23400 	ldr	q0, [x0, #2256]
    9a90:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a94:	9100c018 	add	x24, x0, #0x30
    9a98:	52800020 	mov	w0, #0x1                   	// #1
    9a9c:	3d8013e0 	str	q0, [sp, #64]
    9aa0:	f9017302 	str	x2, [x24, #736]
    9aa4:	97ffeccc 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9aa8:	91158283 	add	x3, x20, #0x560
    9aac:	aa0003f5 	mov	x21, x0
    9ab0:	f949d861 	ldr	x1, [x3, #5040]
    9ab4:	f949ec60 	ldr	x0, [x3, #5080]
    9ab8:	cb0102a1 	sub	x1, x21, x1
    9abc:	eb00403f 	cmp	x1, x0, lsl #16
    9ac0:	54000322 	b.cs	9b24 <f0+0x1d4>  // b.hs, b.nlast
    9ac4:	d350fc22 	lsr	x2, x1, #16
    9ac8:	f949fc63 	ldr	x3, [x3, #5112]
    9acc:	8b020842 	add	x2, x2, x2, lsl #2
    9ad0:	d37df042 	lsl	x2, x2, #3
    9ad4:	8b020060 	add	x0, x3, x2
    9ad8:	f9401017 	ldr	x23, [x0, #32]
    9adc:	b4000257 	cbz	x23, 9b24 <f0+0x1d4>
    9ae0:	38626862 	ldrb	w2, [x3, x2]
    9ae4:	7100085f 	cmp	w2, #0x2
    9ae8:	54010b60 	b.eq	bc54 <f0+0x2304>  // b.none
    9aec:	7100045f 	cmp	w2, #0x1
    9af0:	540001a1 	b.ne	9b24 <f0+0x1d4>  // b.any
    9af4:	29430002 	ldp	w2, w0, [x0, #24]
    9af8:	92403c21 	and	x1, x1, #0xffff
    9afc:	9b027c21 	mul	x1, x1, x2
    9b00:	d360fc21 	lsr	x1, x1, #32
    9b04:	eb00003f 	cmp	x1, x0
    9b08:	540000e2 	b.cs	9b24 <f0+0x1d4>  // b.hs, b.nlast
    9b0c:	8b0102f7 	add	x23, x23, x1
    9b10:	394002e0 	ldrb	w0, [x23]
    9b14:	7103fc1f 	cmp	w0, #0xff
    9b18:	54011520 	b.eq	bdbc <f0+0x246c>  // b.none
    9b1c:	52800020 	mov	w0, #0x1                   	// #1
    9b20:	390002e0 	strb	w0, [x23]
    9b24:	910163e1 	add	x1, sp, #0x58
    9b28:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    9b2c:	52800020 	mov	w0, #0x1                   	// #1
    9b30:	a905d7f7 	stp	x23, x21, [sp, #88]
    9b34:	97ffeca8 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9b38:	97ffee47 	bl	5454 <fwp_rc_fresh>
    9b3c:	aa0003e2 	mov	x2, x0
    9b40:	9101a3e1 	add	x1, sp, #0x68
    9b44:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    9b48:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    9b4c:	52800020 	mov	w0, #0x1                   	// #1
    9b50:	a9068bf5 	stp	x21, x2, [sp, #104]
    9b54:	97ffeca0 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9b58:	97ffee3f 	bl	5454 <fwp_rc_fresh>
    9b5c:	aa0003e2 	mov	x2, x0
    9b60:	9101e3e1 	add	x1, sp, #0x78
    9b64:	52800020 	mov	w0, #0x1                   	// #1
    9b68:	a9078bf7 	stp	x23, x2, [sp, #120]
    9b6c:	97ffec9a 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9b70:	97ffee39 	bl	5454 <fwp_rc_fresh>
    9b74:	aa0003e2 	mov	x2, x0
    9b78:	910223e1 	add	x1, sp, #0x88
    9b7c:	52800020 	mov	w0, #0x1                   	// #1
    9b80:	a9088bf5 	stp	x21, x2, [sp, #136]
    9b84:	97ffec94 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9b88:	97ffee33 	bl	5454 <fwp_rc_fresh>
    9b8c:	aa0003e2 	mov	x2, x0
    9b90:	910263e1 	add	x1, sp, #0x98
    9b94:	52800020 	mov	w0, #0x1                   	// #1
    9b98:	a9098bf7 	stp	x23, x2, [sp, #152]
    9b9c:	97ffec8e 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9ba0:	97ffee2d 	bl	5454 <fwp_rc_fresh>
    9ba4:	aa0003e2 	mov	x2, x0
    9ba8:	9102a3e1 	add	x1, sp, #0xa8
    9bac:	52800020 	mov	w0, #0x1                   	// #1
    9bb0:	a90a8bf5 	stp	x21, x2, [sp, #168]
    9bb4:	97ffec88 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9bb8:	97ffee27 	bl	5454 <fwp_rc_fresh>
    9bbc:	aa0003e2 	mov	x2, x0
    9bc0:	9102e3e1 	add	x1, sp, #0xb8
    9bc4:	52800020 	mov	w0, #0x1                   	// #1
    9bc8:	a90b8bf7 	stp	x23, x2, [sp, #184]
    9bcc:	97ffec82 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9bd0:	97ffee21 	bl	5454 <fwp_rc_fresh>
    9bd4:	aa0003e2 	mov	x2, x0
    9bd8:	910323e1 	add	x1, sp, #0xc8
    9bdc:	52800020 	mov	w0, #0x1                   	// #1
    9be0:	a90c8bf5 	stp	x21, x2, [sp, #200]
    9be4:	97ffec7c 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9be8:	97ffee1b 	bl	5454 <fwp_rc_fresh>
    9bec:	aa0003e2 	mov	x2, x0
    9bf0:	910363e1 	add	x1, sp, #0xd8
    9bf4:	52800020 	mov	w0, #0x1                   	// #1
    9bf8:	a90d8bf7 	stp	x23, x2, [sp, #216]
    9bfc:	97ffec76 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9c00:	97ffee15 	bl	5454 <fwp_rc_fresh>
    9c04:	aa0003e2 	mov	x2, x0
    9c08:	9103a3e1 	add	x1, sp, #0xe8
    9c0c:	52800020 	mov	w0, #0x1                   	// #1
    9c10:	a90e8bf5 	stp	x21, x2, [sp, #232]
    9c14:	97ffec70 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9c18:	97ffee0f 	bl	5454 <fwp_rc_fresh>
    9c1c:	aa0003e2 	mov	x2, x0
    9c20:	9103e3e1 	add	x1, sp, #0xf8
    9c24:	52800020 	mov	w0, #0x1                   	// #1
    9c28:	a90f8bf7 	stp	x23, x2, [sp, #248]
    9c2c:	97ffec6a 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9c30:	97ffee09 	bl	5454 <fwp_rc_fresh>
    9c34:	aa0003e2 	mov	x2, x0
    9c38:	910423e1 	add	x1, sp, #0x108
    9c3c:	52800020 	mov	w0, #0x1                   	// #1
    9c40:	a9108bf5 	stp	x21, x2, [sp, #264]
    9c44:	97ffec64 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9c48:	97ffee03 	bl	5454 <fwp_rc_fresh>
    9c4c:	aa0003e2 	mov	x2, x0
    9c50:	910463e1 	add	x1, sp, #0x118
    9c54:	52800020 	mov	w0, #0x1                   	// #1
    9c58:	a9118bf7 	stp	x23, x2, [sp, #280]
    9c5c:	97ffec5e 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9c60:	97ffedfd 	bl	5454 <fwp_rc_fresh>
    9c64:	aa0003e2 	mov	x2, x0
    9c68:	9104a3e1 	add	x1, sp, #0x128
    9c6c:	52800020 	mov	w0, #0x1                   	// #1
    9c70:	a9128bf5 	stp	x21, x2, [sp, #296]
    9c74:	97ffec58 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9c78:	97ffedf7 	bl	5454 <fwp_rc_fresh>
    9c7c:	aa0003e2 	mov	x2, x0
    9c80:	9104e3e1 	add	x1, sp, #0x138
    9c84:	52800020 	mov	w0, #0x1                   	// #1
    9c88:	a9138bf7 	stp	x23, x2, [sp, #312]
    9c8c:	97ffec52 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9c90:	97ffedf1 	bl	5454 <fwp_rc_fresh>
    9c94:	aa0003e2 	mov	x2, x0
    9c98:	910523e1 	add	x1, sp, #0x148
    9c9c:	52800020 	mov	w0, #0x1                   	// #1
    9ca0:	a9148bf5 	stp	x21, x2, [sp, #328]
    9ca4:	97ffec4c 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9ca8:	97ffedeb 	bl	5454 <fwp_rc_fresh>
    9cac:	aa0003e2 	mov	x2, x0
    9cb0:	910563e1 	add	x1, sp, #0x158
    9cb4:	52800020 	mov	w0, #0x1                   	// #1
    9cb8:	a9158bf7 	stp	x23, x2, [sp, #344]
    9cbc:	97ffec46 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9cc0:	97ffede5 	bl	5454 <fwp_rc_fresh>
    9cc4:	aa0003e2 	mov	x2, x0
    9cc8:	9105a3e1 	add	x1, sp, #0x168
    9ccc:	52800020 	mov	w0, #0x1                   	// #1
    9cd0:	a9168bf5 	stp	x21, x2, [sp, #360]
    9cd4:	97ffec40 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9cd8:	97ffeddf 	bl	5454 <fwp_rc_fresh>
    9cdc:	aa0003e2 	mov	x2, x0
    9ce0:	9105e3e1 	add	x1, sp, #0x178
    9ce4:	52800020 	mov	w0, #0x1                   	// #1
    9ce8:	a9178bf7 	stp	x23, x2, [sp, #376]
    9cec:	97ffec3a 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9cf0:	97ffedd9 	bl	5454 <fwp_rc_fresh>
    9cf4:	aa0003e2 	mov	x2, x0
    9cf8:	910623e1 	add	x1, sp, #0x188
    9cfc:	52800020 	mov	w0, #0x1                   	// #1
    9d00:	a9188bf5 	stp	x21, x2, [sp, #392]
    9d04:	97ffec34 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9d08:	97ffedd3 	bl	5454 <fwp_rc_fresh>
    9d0c:	aa0003e2 	mov	x2, x0
    9d10:	910663e1 	add	x1, sp, #0x198
    9d14:	52800020 	mov	w0, #0x1                   	// #1
    9d18:	a9198bf7 	stp	x23, x2, [sp, #408]
    9d1c:	97ffec2e 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9d20:	97ffedcd 	bl	5454 <fwp_rc_fresh>
    9d24:	aa0003e2 	mov	x2, x0
    9d28:	9106a3e1 	add	x1, sp, #0x1a8
    9d2c:	52800020 	mov	w0, #0x1                   	// #1
    9d30:	a91a8bf5 	stp	x21, x2, [sp, #424]
    9d34:	97ffec28 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9d38:	91158283 	add	x3, x20, #0x560
    9d3c:	aa0003f5 	mov	x21, x0
    9d40:	f949d861 	ldr	x1, [x3, #5040]
    9d44:	f949ec60 	ldr	x0, [x3, #5080]
    9d48:	cb0102a1 	sub	x1, x21, x1
    9d4c:	eb00403f 	cmp	x1, x0, lsl #16
    9d50:	54000322 	b.cs	9db4 <f0+0x464>  // b.hs, b.nlast
    9d54:	d350fc22 	lsr	x2, x1, #16
    9d58:	f949fc63 	ldr	x3, [x3, #5112]
    9d5c:	8b020842 	add	x2, x2, x2, lsl #2
    9d60:	d37df042 	lsl	x2, x2, #3
    9d64:	8b020060 	add	x0, x3, x2
    9d68:	f9401017 	ldr	x23, [x0, #32]
    9d6c:	b4000257 	cbz	x23, 9db4 <f0+0x464>
    9d70:	38626862 	ldrb	w2, [x3, x2]
    9d74:	7100085f 	cmp	w2, #0x2
    9d78:	5400f680 	b.eq	bc48 <f0+0x22f8>  // b.none
    9d7c:	7100045f 	cmp	w2, #0x1
    9d80:	540001a1 	b.ne	9db4 <f0+0x464>  // b.any
    9d84:	29430002 	ldp	w2, w0, [x0, #24]
    9d88:	92403c21 	and	x1, x1, #0xffff
    9d8c:	9b027c21 	mul	x1, x1, x2
    9d90:	d360fc21 	lsr	x1, x1, #32
    9d94:	eb00003f 	cmp	x1, x0
    9d98:	540000e2 	b.cs	9db4 <f0+0x464>  // b.hs, b.nlast
    9d9c:	8b0102f7 	add	x23, x23, x1
    9da0:	394002e0 	ldrb	w0, [x23]
    9da4:	7103fc1f 	cmp	w0, #0xff
    9da8:	54010100 	b.eq	bdc8 <f0+0x2478>  // b.none
    9dac:	52800020 	mov	w0, #0x1                   	// #1
    9db0:	390002e0 	strb	w0, [x23]
    9db4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9db8:	9106e3e1 	add	x1, sp, #0x1b8
    9dbc:	52800020 	mov	w0, #0x1                   	// #1
    9dc0:	a91bd7e2 	stp	x2, x21, [sp, #440]
    9dc4:	97ffec04 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9dc8:	91158283 	add	x3, x20, #0x560
    9dcc:	aa0003f5 	mov	x21, x0
    9dd0:	f949d861 	ldr	x1, [x3, #5040]
    9dd4:	f949ec60 	ldr	x0, [x3, #5080]
    9dd8:	cb0102a1 	sub	x1, x21, x1
    9ddc:	eb00403f 	cmp	x1, x0, lsl #16
    9de0:	54000322 	b.cs	9e44 <f0+0x4f4>  // b.hs, b.nlast
    9de4:	d350fc22 	lsr	x2, x1, #16
    9de8:	f949fc63 	ldr	x3, [x3, #5112]
    9dec:	8b020842 	add	x2, x2, x2, lsl #2
    9df0:	d37df042 	lsl	x2, x2, #3
    9df4:	8b020060 	add	x0, x3, x2
    9df8:	f9401017 	ldr	x23, [x0, #32]
    9dfc:	b4000257 	cbz	x23, 9e44 <f0+0x4f4>
    9e00:	38626862 	ldrb	w2, [x3, x2]
    9e04:	7100085f 	cmp	w2, #0x2
    9e08:	5400f1a0 	b.eq	bc3c <f0+0x22ec>  // b.none
    9e0c:	7100045f 	cmp	w2, #0x1
    9e10:	540001a1 	b.ne	9e44 <f0+0x4f4>  // b.any
    9e14:	29430002 	ldp	w2, w0, [x0, #24]
    9e18:	92403c21 	and	x1, x1, #0xffff
    9e1c:	9b027c21 	mul	x1, x1, x2
    9e20:	d360fc21 	lsr	x1, x1, #32
    9e24:	eb00003f 	cmp	x1, x0
    9e28:	540000e2 	b.cs	9e44 <f0+0x4f4>  // b.hs, b.nlast
    9e2c:	8b0102f7 	add	x23, x23, x1
    9e30:	394002e0 	ldrb	w0, [x23]
    9e34:	7103fc1f 	cmp	w0, #0xff
    9e38:	5400fce0 	b.eq	bdd4 <f0+0x2484>  // b.none
    9e3c:	52800020 	mov	w0, #0x1                   	// #1
    9e40:	390002e0 	strb	w0, [x23]
    9e44:	910723e1 	add	x1, sp, #0x1c8
    9e48:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9e4c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9e50:	52800020 	mov	w0, #0x1                   	// #1
    9e54:	a91cd7f7 	stp	x23, x21, [sp, #456]
    9e58:	97ffebdf 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9e5c:	97ffed7e 	bl	5454 <fwp_rc_fresh>
    9e60:	aa0003e2 	mov	x2, x0
    9e64:	910763e1 	add	x1, sp, #0x1d8
    9e68:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9e6c:	52800020 	mov	w0, #0x1                   	// #1
    9e70:	a91d8bf5 	stp	x21, x2, [sp, #472]
    9e74:	97ffebd8 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9e78:	97ffed77 	bl	5454 <fwp_rc_fresh>
    9e7c:	aa0003e2 	mov	x2, x0
    9e80:	9107a3e1 	add	x1, sp, #0x1e8
    9e84:	52800020 	mov	w0, #0x1                   	// #1
    9e88:	a91e8bf7 	stp	x23, x2, [sp, #488]
    9e8c:	97ffebd2 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9e90:	97ffed71 	bl	5454 <fwp_rc_fresh>
    9e94:	aa0003e2 	mov	x2, x0
    9e98:	9107e3e1 	add	x1, sp, #0x1f8
    9e9c:	52800020 	mov	w0, #0x1                   	// #1
    9ea0:	a91f8bf5 	stp	x21, x2, [sp, #504]
    9ea4:	97ffebcc 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9ea8:	91158283 	add	x3, x20, #0x560
    9eac:	aa0003f5 	mov	x21, x0
    9eb0:	f949d861 	ldr	x1, [x3, #5040]
    9eb4:	f949ec60 	ldr	x0, [x3, #5080]
    9eb8:	cb0102a1 	sub	x1, x21, x1
    9ebc:	eb00403f 	cmp	x1, x0, lsl #16
    9ec0:	54000322 	b.cs	9f24 <f0+0x5d4>  // b.hs, b.nlast
    9ec4:	d350fc22 	lsr	x2, x1, #16
    9ec8:	f949fc63 	ldr	x3, [x3, #5112]
    9ecc:	8b020842 	add	x2, x2, x2, lsl #2
    9ed0:	d37df042 	lsl	x2, x2, #3
    9ed4:	8b020060 	add	x0, x3, x2
    9ed8:	f9401017 	ldr	x23, [x0, #32]
    9edc:	b4000257 	cbz	x23, 9f24 <f0+0x5d4>
    9ee0:	38626862 	ldrb	w2, [x3, x2]
    9ee4:	7100085f 	cmp	w2, #0x2
    9ee8:	5400ece0 	b.eq	bc84 <f0+0x2334>  // b.none
    9eec:	7100045f 	cmp	w2, #0x1
    9ef0:	540001a1 	b.ne	9f24 <f0+0x5d4>  // b.any
    9ef4:	29430002 	ldp	w2, w0, [x0, #24]
    9ef8:	92403c21 	and	x1, x1, #0xffff
    9efc:	9b027c21 	mul	x1, x1, x2
    9f00:	d360fc21 	lsr	x1, x1, #32
    9f04:	eb00003f 	cmp	x1, x0
    9f08:	540000e2 	b.cs	9f24 <f0+0x5d4>  // b.hs, b.nlast
    9f0c:	8b0102f7 	add	x23, x23, x1
    9f10:	394002e0 	ldrb	w0, [x23]
    9f14:	7103fc1f 	cmp	w0, #0xff
    9f18:	5400f640 	b.eq	bde0 <f0+0x2490>  // b.none
    9f1c:	52800020 	mov	w0, #0x1                   	// #1
    9f20:	390002e0 	strb	w0, [x23]
    9f24:	910823e1 	add	x1, sp, #0x208
    9f28:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9f2c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9f30:	52800020 	mov	w0, #0x1                   	// #1
    9f34:	f90107f7 	str	x23, [sp, #520]
    9f38:	f9010bf5 	str	x21, [sp, #528]
    9f3c:	97ffeba6 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9f40:	97ffed45 	bl	5454 <fwp_rc_fresh>
    9f44:	aa0003e2 	mov	x2, x0
    9f48:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9f4c:	910863e1 	add	x1, sp, #0x218
    9f50:	52800020 	mov	w0, #0x1                   	// #1
    9f54:	f9010fe3 	str	x3, [sp, #536]
    9f58:	f90113e2 	str	x2, [sp, #544]
    9f5c:	97ffeb9e 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9f60:	97ffed3d 	bl	5454 <fwp_rc_fresh>
    9f64:	aa0003e2 	mov	x2, x0
    9f68:	9108a3e1 	add	x1, sp, #0x228
    9f6c:	52800020 	mov	w0, #0x1                   	// #1
    9f70:	f90117f7 	str	x23, [sp, #552]
    9f74:	f9011be2 	str	x2, [sp, #560]
    9f78:	97ffeb97 	bl	4dd4 <fwp_data.part.0.constprop.0>
    9f7c:	91158283 	add	x3, x20, #0x560
    9f80:	aa0003f5 	mov	x21, x0
    9f84:	f949d861 	ldr	x1, [x3, #5040]
    9f88:	f949ec60 	ldr	x0, [x3, #5080]
    9f8c:	cb0102a1 	sub	x1, x21, x1
    9f90:	eb00403f 	cmp	x1, x0, lsl #16
    9f94:	54000322 	b.cs	9ff8 <f0+0x6a8>  // b.hs, b.nlast
    9f98:	d350fc22 	lsr	x2, x1, #16
    9f9c:	f949fc63 	ldr	x3, [x3, #5112]
    9fa0:	8b020842 	add	x2, x2, x2, lsl #2
    9fa4:	d37df042 	lsl	x2, x2, #3
    9fa8:	8b020060 	add	x0, x3, x2
    9fac:	f9401017 	ldr	x23, [x0, #32]
    9fb0:	b4000257 	cbz	x23, 9ff8 <f0+0x6a8>
    9fb4:	38626862 	ldrb	w2, [x3, x2]
    9fb8:	7100085f 	cmp	w2, #0x2
    9fbc:	5400e5e0 	b.eq	bc78 <f0+0x2328>  // b.none
    9fc0:	7100045f 	cmp	w2, #0x1
    9fc4:	540001a1 	b.ne	9ff8 <f0+0x6a8>  // b.any
    9fc8:	29430002 	ldp	w2, w0, [x0, #24]
    9fcc:	92403c21 	and	x1, x1, #0xffff
    9fd0:	9b027c21 	mul	x1, x1, x2
    9fd4:	d360fc21 	lsr	x1, x1, #32
    9fd8:	eb00003f 	cmp	x1, x0
    9fdc:	540000e2 	b.cs	9ff8 <f0+0x6a8>  // b.hs, b.nlast
    9fe0:	8b0102f7 	add	x23, x23, x1
    9fe4:	394002e0 	ldrb	w0, [x23]
    9fe8:	7103fc1f 	cmp	w0, #0xff
    9fec:	5400f000 	b.eq	bdec <f0+0x249c>  // b.none
    9ff0:	52800020 	mov	w0, #0x1                   	// #1
    9ff4:	390002e0 	strb	w0, [x23]
    9ff8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9ffc:	9108e3e1 	add	x1, sp, #0x238
    a000:	52800020 	mov	w0, #0x1                   	// #1
    a004:	f9011fe2 	str	x2, [sp, #568]
    a008:	f90123f5 	str	x21, [sp, #576]
    a00c:	97ffeb72 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a010:	91158283 	add	x3, x20, #0x560
    a014:	aa0003f5 	mov	x21, x0
    a018:	f949d861 	ldr	x1, [x3, #5040]
    a01c:	f949ec60 	ldr	x0, [x3, #5080]
    a020:	cb0102a1 	sub	x1, x21, x1
    a024:	eb00403f 	cmp	x1, x0, lsl #16
    a028:	54000322 	b.cs	a08c <f0+0x73c>  // b.hs, b.nlast
    a02c:	d350fc22 	lsr	x2, x1, #16
    a030:	f949fc63 	ldr	x3, [x3, #5112]
    a034:	8b020842 	add	x2, x2, x2, lsl #2
    a038:	d37df042 	lsl	x2, x2, #3
    a03c:	8b020060 	add	x0, x3, x2
    a040:	f9401017 	ldr	x23, [x0, #32]
    a044:	b4000257 	cbz	x23, a08c <f0+0x73c>
    a048:	38626862 	ldrb	w2, [x3, x2]
    a04c:	7100085f 	cmp	w2, #0x2
    a050:	5400e0e0 	b.eq	bc6c <f0+0x231c>  // b.none
    a054:	7100045f 	cmp	w2, #0x1
    a058:	540001a1 	b.ne	a08c <f0+0x73c>  // b.any
    a05c:	29430002 	ldp	w2, w0, [x0, #24]
    a060:	92403c21 	and	x1, x1, #0xffff
    a064:	9b027c21 	mul	x1, x1, x2
    a068:	d360fc21 	lsr	x1, x1, #32
    a06c:	eb00003f 	cmp	x1, x0
    a070:	540000e2 	b.cs	a08c <f0+0x73c>  // b.hs, b.nlast
    a074:	8b0102f7 	add	x23, x23, x1
    a078:	394002e0 	ldrb	w0, [x23]
    a07c:	7103fc1f 	cmp	w0, #0xff
    a080:	5400ebc0 	b.eq	bdf8 <f0+0x24a8>  // b.none
    a084:	52800020 	mov	w0, #0x1                   	// #1
    a088:	390002e0 	strb	w0, [x23]
    a08c:	910923e1 	add	x1, sp, #0x248
    a090:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a094:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a098:	52800020 	mov	w0, #0x1                   	// #1
    a09c:	f90127f7 	str	x23, [sp, #584]
    a0a0:	f9012bf5 	str	x21, [sp, #592]
    a0a4:	97ffeb4c 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a0a8:	97ffeceb 	bl	5454 <fwp_rc_fresh>
    a0ac:	aa0003e2 	mov	x2, x0
    a0b0:	910963e1 	add	x1, sp, #0x258
    a0b4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a0b8:	52800020 	mov	w0, #0x1                   	// #1
    a0bc:	f9012ff5 	str	x21, [sp, #600]
    a0c0:	f90133e2 	str	x2, [sp, #608]
    a0c4:	97ffeb44 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a0c8:	97ffece3 	bl	5454 <fwp_rc_fresh>
    a0cc:	aa0003e2 	mov	x2, x0
    a0d0:	9109a3e1 	add	x1, sp, #0x268
    a0d4:	52800020 	mov	w0, #0x1                   	// #1
    a0d8:	f90137f7 	str	x23, [sp, #616]
    a0dc:	f9013be2 	str	x2, [sp, #624]
    a0e0:	97ffeb3d 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a0e4:	97ffecdc 	bl	5454 <fwp_rc_fresh>
    a0e8:	aa0003e2 	mov	x2, x0
    a0ec:	9109e3e1 	add	x1, sp, #0x278
    a0f0:	52800020 	mov	w0, #0x1                   	// #1
    a0f4:	f9013ff5 	str	x21, [sp, #632]
    a0f8:	f90143e2 	str	x2, [sp, #640]
    a0fc:	97ffeb36 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a100:	91158283 	add	x3, x20, #0x560
    a104:	aa0003f5 	mov	x21, x0
    a108:	f949d861 	ldr	x1, [x3, #5040]
    a10c:	f949ec60 	ldr	x0, [x3, #5080]
    a110:	cb0102a1 	sub	x1, x21, x1
    a114:	eb00403f 	cmp	x1, x0, lsl #16
    a118:	54000322 	b.cs	a17c <f0+0x82c>  // b.hs, b.nlast
    a11c:	d350fc22 	lsr	x2, x1, #16
    a120:	f949fc63 	ldr	x3, [x3, #5112]
    a124:	8b020842 	add	x2, x2, x2, lsl #2
    a128:	d37df042 	lsl	x2, x2, #3
    a12c:	8b020060 	add	x0, x3, x2
    a130:	f9401017 	ldr	x23, [x0, #32]
    a134:	b4000257 	cbz	x23, a17c <f0+0x82c>
    a138:	38626862 	ldrb	w2, [x3, x2]
    a13c:	7100085f 	cmp	w2, #0x2
    a140:	5400d900 	b.eq	bc60 <f0+0x2310>  // b.none
    a144:	7100045f 	cmp	w2, #0x1
    a148:	540001a1 	b.ne	a17c <f0+0x82c>  // b.any
    a14c:	29430002 	ldp	w2, w0, [x0, #24]
    a150:	92403c21 	and	x1, x1, #0xffff
    a154:	9b027c21 	mul	x1, x1, x2
    a158:	d360fc21 	lsr	x1, x1, #32
    a15c:	eb00003f 	cmp	x1, x0
    a160:	540000e2 	b.cs	a17c <f0+0x82c>  // b.hs, b.nlast
    a164:	8b0102f7 	add	x23, x23, x1
    a168:	394002e0 	ldrb	w0, [x23]
    a16c:	7103fc1f 	cmp	w0, #0xff
    a170:	5400e4a0 	b.eq	be04 <f0+0x24b4>  // b.none
    a174:	52800020 	mov	w0, #0x1                   	// #1
    a178:	390002e0 	strb	w0, [x23]
    a17c:	910a23e1 	add	x1, sp, #0x288
    a180:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a184:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a188:	52800020 	mov	w0, #0x1                   	// #1
    a18c:	f90147f7 	str	x23, [sp, #648]
    a190:	f9014bf5 	str	x21, [sp, #656]
    a194:	97ffeb10 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a198:	97ffecaf 	bl	5454 <fwp_rc_fresh>
    a19c:	aa0003e2 	mov	x2, x0
    a1a0:	910a63e1 	add	x1, sp, #0x298
    a1a4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a1a8:	52800020 	mov	w0, #0x1                   	// #1
    a1ac:	f9014ff5 	str	x21, [sp, #664]
    a1b0:	f90153e2 	str	x2, [sp, #672]
    a1b4:	97ffeb08 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a1b8:	97ffeca7 	bl	5454 <fwp_rc_fresh>
    a1bc:	aa0003e2 	mov	x2, x0
    a1c0:	910aa3e1 	add	x1, sp, #0x2a8
    a1c4:	52800020 	mov	w0, #0x1                   	// #1
    a1c8:	f90157f7 	str	x23, [sp, #680]
    a1cc:	f9015be2 	str	x2, [sp, #688]
    a1d0:	97ffeb01 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a1d4:	97ffeca0 	bl	5454 <fwp_rc_fresh>
    a1d8:	aa0003e2 	mov	x2, x0
    a1dc:	910ae3e1 	add	x1, sp, #0x2b8
    a1e0:	52800020 	mov	w0, #0x1                   	// #1
    a1e4:	f9015ff5 	str	x21, [sp, #696]
    a1e8:	f90163e2 	str	x2, [sp, #704]
    a1ec:	97ffeafa 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a1f0:	97ffec99 	bl	5454 <fwp_rc_fresh>
    a1f4:	aa0003e2 	mov	x2, x0
    a1f8:	910b23e1 	add	x1, sp, #0x2c8
    a1fc:	52800020 	mov	w0, #0x1                   	// #1
    a200:	f90167f7 	str	x23, [sp, #712]
    a204:	f9016be2 	str	x2, [sp, #720]
    a208:	97ffeaf3 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a20c:	97ffec92 	bl	5454 <fwp_rc_fresh>
    a210:	aa0003e2 	mov	x2, x0
    a214:	910b63e1 	add	x1, sp, #0x2d8
    a218:	52800020 	mov	w0, #0x1                   	// #1
    a21c:	f9016ff5 	str	x21, [sp, #728]
    a220:	f90173e2 	str	x2, [sp, #736]
    a224:	97ffeaec 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a228:	97ffec8b 	bl	5454 <fwp_rc_fresh>
    a22c:	aa0003e2 	mov	x2, x0
    a230:	910ba3e1 	add	x1, sp, #0x2e8
    a234:	52800020 	mov	w0, #0x1                   	// #1
    a238:	f90177f7 	str	x23, [sp, #744]
    a23c:	f9017be2 	str	x2, [sp, #752]
    a240:	97ffeae5 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a244:	97ffec84 	bl	5454 <fwp_rc_fresh>
    a248:	aa0003e2 	mov	x2, x0
    a24c:	910be3e1 	add	x1, sp, #0x2f8
    a250:	52800020 	mov	w0, #0x1                   	// #1
    a254:	f9017ff5 	str	x21, [sp, #760]
    a258:	f90183e2 	str	x2, [sp, #768]
    a25c:	97ffeade 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a260:	91158283 	add	x3, x20, #0x560
    a264:	aa0003f5 	mov	x21, x0
    a268:	f949d861 	ldr	x1, [x3, #5040]
    a26c:	f949ec60 	ldr	x0, [x3, #5080]
    a270:	cb0102a1 	sub	x1, x21, x1
    a274:	eb00403f 	cmp	x1, x0, lsl #16
    a278:	54000322 	b.cs	a2dc <f0+0x98c>  // b.hs, b.nlast
    a27c:	d350fc22 	lsr	x2, x1, #16
    a280:	f949fc63 	ldr	x3, [x3, #5112]
    a284:	8b020842 	add	x2, x2, x2, lsl #2
    a288:	d37df042 	lsl	x2, x2, #3
    a28c:	8b020060 	add	x0, x3, x2
    a290:	f9401017 	ldr	x23, [x0, #32]
    a294:	b4000257 	cbz	x23, a2dc <f0+0x98c>
    a298:	38626862 	ldrb	w2, [x3, x2]
    a29c:	7100085f 	cmp	w2, #0x2
    a2a0:	5400d220 	b.eq	bce4 <f0+0x2394>  // b.none
    a2a4:	7100045f 	cmp	w2, #0x1
    a2a8:	540001a1 	b.ne	a2dc <f0+0x98c>  // b.any
    a2ac:	29430002 	ldp	w2, w0, [x0, #24]
    a2b0:	92403c21 	and	x1, x1, #0xffff
    a2b4:	9b027c21 	mul	x1, x1, x2
    a2b8:	d360fc21 	lsr	x1, x1, #32
    a2bc:	eb00003f 	cmp	x1, x0
    a2c0:	540000e2 	b.cs	a2dc <f0+0x98c>  // b.hs, b.nlast
    a2c4:	8b0102f7 	add	x23, x23, x1
    a2c8:	394002e0 	ldrb	w0, [x23]
    a2cc:	7103fc1f 	cmp	w0, #0xff
    a2d0:	5400da00 	b.eq	be10 <f0+0x24c0>  // b.none
    a2d4:	52800020 	mov	w0, #0x1                   	// #1
    a2d8:	390002e0 	strb	w0, [x23]
    a2dc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a2e0:	910c23e1 	add	x1, sp, #0x308
    a2e4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a2e8:	52800020 	mov	w0, #0x1                   	// #1
    a2ec:	f90187e2 	str	x2, [sp, #776]
    a2f0:	f9018bf5 	str	x21, [sp, #784]
    a2f4:	97ffeab8 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a2f8:	97ffec57 	bl	5454 <fwp_rc_fresh>
    a2fc:	aa0003e2 	mov	x2, x0
    a300:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a304:	910c63e1 	add	x1, sp, #0x318
    a308:	52800020 	mov	w0, #0x1                   	// #1
    a30c:	f9018fe3 	str	x3, [sp, #792]
    a310:	f90193e2 	str	x2, [sp, #800]
    a314:	97ffeab0 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a318:	91158283 	add	x3, x20, #0x560
    a31c:	aa0003f5 	mov	x21, x0
    a320:	f949d861 	ldr	x1, [x3, #5040]
    a324:	f949ec60 	ldr	x0, [x3, #5080]
    a328:	cb0102a1 	sub	x1, x21, x1
    a32c:	eb00403f 	cmp	x1, x0, lsl #16
    a330:	54000322 	b.cs	a394 <f0+0xa44>  // b.hs, b.nlast
    a334:	d350fc22 	lsr	x2, x1, #16
    a338:	f949fc63 	ldr	x3, [x3, #5112]
    a33c:	8b020842 	add	x2, x2, x2, lsl #2
    a340:	d37df042 	lsl	x2, x2, #3
    a344:	8b020060 	add	x0, x3, x2
    a348:	f9401017 	ldr	x23, [x0, #32]
    a34c:	b4000257 	cbz	x23, a394 <f0+0xa44>
    a350:	38626862 	ldrb	w2, [x3, x2]
    a354:	7100085f 	cmp	w2, #0x2
    a358:	5400cc00 	b.eq	bcd8 <f0+0x2388>  // b.none
    a35c:	7100045f 	cmp	w2, #0x1
    a360:	540001a1 	b.ne	a394 <f0+0xa44>  // b.any
    a364:	29430002 	ldp	w2, w0, [x0, #24]
    a368:	92403c21 	and	x1, x1, #0xffff
    a36c:	9b027c21 	mul	x1, x1, x2
    a370:	d360fc21 	lsr	x1, x1, #32
    a374:	eb00003f 	cmp	x1, x0
    a378:	540000e2 	b.cs	a394 <f0+0xa44>  // b.hs, b.nlast
    a37c:	8b0102f7 	add	x23, x23, x1
    a380:	394002e0 	ldrb	w0, [x23]
    a384:	7103fc1f 	cmp	w0, #0xff
    a388:	5400d4a0 	b.eq	be1c <f0+0x24cc>  // b.none
    a38c:	52800020 	mov	w0, #0x1                   	// #1
    a390:	390002e0 	strb	w0, [x23]
    a394:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a398:	910ca3e1 	add	x1, sp, #0x328
    a39c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a3a0:	52800020 	mov	w0, #0x1                   	// #1
    a3a4:	f90197e2 	str	x2, [sp, #808]
    a3a8:	f9019bf5 	str	x21, [sp, #816]
    a3ac:	97ffea8a 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a3b0:	91158283 	add	x3, x20, #0x560
    a3b4:	aa0003f5 	mov	x21, x0
    a3b8:	f949d861 	ldr	x1, [x3, #5040]
    a3bc:	f949ec60 	ldr	x0, [x3, #5080]
    a3c0:	cb0102a1 	sub	x1, x21, x1
    a3c4:	eb00403f 	cmp	x1, x0, lsl #16
    a3c8:	54000322 	b.cs	a42c <f0+0xadc>  // b.hs, b.nlast
    a3cc:	d350fc22 	lsr	x2, x1, #16
    a3d0:	f949fc63 	ldr	x3, [x3, #5112]
    a3d4:	8b020842 	add	x2, x2, x2, lsl #2
    a3d8:	d37df042 	lsl	x2, x2, #3
    a3dc:	8b020060 	add	x0, x3, x2
    a3e0:	f9401017 	ldr	x23, [x0, #32]
    a3e4:	b4000257 	cbz	x23, a42c <f0+0xadc>
    a3e8:	38626862 	ldrb	w2, [x3, x2]
    a3ec:	7100085f 	cmp	w2, #0x2
    a3f0:	5400c6e0 	b.eq	bccc <f0+0x237c>  // b.none
    a3f4:	7100045f 	cmp	w2, #0x1
    a3f8:	540001a1 	b.ne	a42c <f0+0xadc>  // b.any
    a3fc:	29430002 	ldp	w2, w0, [x0, #24]
    a400:	92403c21 	and	x1, x1, #0xffff
    a404:	9b027c21 	mul	x1, x1, x2
    a408:	d360fc21 	lsr	x1, x1, #32
    a40c:	eb00003f 	cmp	x1, x0
    a410:	540000e2 	b.cs	a42c <f0+0xadc>  // b.hs, b.nlast
    a414:	8b0102f7 	add	x23, x23, x1
    a418:	394002e0 	ldrb	w0, [x23]
    a41c:	7103fc1f 	cmp	w0, #0xff
    a420:	5400d040 	b.eq	be28 <f0+0x24d8>  // b.none
    a424:	52800020 	mov	w0, #0x1                   	// #1
    a428:	390002e0 	strb	w0, [x23]
    a42c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a430:	910ce3e1 	add	x1, sp, #0x338
    a434:	52800020 	mov	w0, #0x1                   	// #1
    a438:	f9019fe2 	str	x2, [sp, #824]
    a43c:	f901a3f5 	str	x21, [sp, #832]
    a440:	97ffea65 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a444:	91158283 	add	x3, x20, #0x560
    a448:	aa0003f5 	mov	x21, x0
    a44c:	f949d861 	ldr	x1, [x3, #5040]
    a450:	f949ec60 	ldr	x0, [x3, #5080]
    a454:	cb0102a1 	sub	x1, x21, x1
    a458:	eb00403f 	cmp	x1, x0, lsl #16
    a45c:	54000322 	b.cs	a4c0 <f0+0xb70>  // b.hs, b.nlast
    a460:	d350fc22 	lsr	x2, x1, #16
    a464:	f949fc63 	ldr	x3, [x3, #5112]
    a468:	8b020842 	add	x2, x2, x2, lsl #2
    a46c:	d37df042 	lsl	x2, x2, #3
    a470:	8b020060 	add	x0, x3, x2
    a474:	f9401017 	ldr	x23, [x0, #32]
    a478:	b4000257 	cbz	x23, a4c0 <f0+0xb70>
    a47c:	38626862 	ldrb	w2, [x3, x2]
    a480:	7100085f 	cmp	w2, #0x2
    a484:	5400c1e0 	b.eq	bcc0 <f0+0x2370>  // b.none
    a488:	7100045f 	cmp	w2, #0x1
    a48c:	540001a1 	b.ne	a4c0 <f0+0xb70>  // b.any
    a490:	29430002 	ldp	w2, w0, [x0, #24]
    a494:	92403c21 	and	x1, x1, #0xffff
    a498:	9b027c21 	mul	x1, x1, x2
    a49c:	d360fc21 	lsr	x1, x1, #32
    a4a0:	eb00003f 	cmp	x1, x0
    a4a4:	540000e2 	b.cs	a4c0 <f0+0xb70>  // b.hs, b.nlast
    a4a8:	8b0102f7 	add	x23, x23, x1
    a4ac:	394002e0 	ldrb	w0, [x23]
    a4b0:	7103fc1f 	cmp	w0, #0xff
    a4b4:	5400cc00 	b.eq	be34 <f0+0x24e4>  // b.none
    a4b8:	52800020 	mov	w0, #0x1                   	// #1
    a4bc:	390002e0 	strb	w0, [x23]
    a4c0:	910d23e1 	add	x1, sp, #0x348
    a4c4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a4c8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a4cc:	52800020 	mov	w0, #0x1                   	// #1
    a4d0:	f901a7f7 	str	x23, [sp, #840]
    a4d4:	f901abf5 	str	x21, [sp, #848]
    a4d8:	97ffea3f 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a4dc:	97ffebde 	bl	5454 <fwp_rc_fresh>
    a4e0:	aa0003e2 	mov	x2, x0
    a4e4:	910d63e1 	add	x1, sp, #0x358
    a4e8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a4ec:	52800020 	mov	w0, #0x1                   	// #1
    a4f0:	f901aff5 	str	x21, [sp, #856]
    a4f4:	f901b3e2 	str	x2, [sp, #864]
    a4f8:	97ffea37 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a4fc:	97ffebd6 	bl	5454 <fwp_rc_fresh>
    a500:	aa0003e2 	mov	x2, x0
    a504:	910da3e1 	add	x1, sp, #0x368
    a508:	52800020 	mov	w0, #0x1                   	// #1
    a50c:	f901b7f7 	str	x23, [sp, #872]
    a510:	f901bbe2 	str	x2, [sp, #880]
    a514:	97ffea30 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a518:	97ffebcf 	bl	5454 <fwp_rc_fresh>
    a51c:	aa0003e2 	mov	x2, x0
    a520:	910de3e1 	add	x1, sp, #0x378
    a524:	52800020 	mov	w0, #0x1                   	// #1
    a528:	f901bff5 	str	x21, [sp, #888]
    a52c:	f901c3e2 	str	x2, [sp, #896]
    a530:	97ffea29 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a534:	97ffebc8 	bl	5454 <fwp_rc_fresh>
    a538:	aa0003e2 	mov	x2, x0
    a53c:	910e23e1 	add	x1, sp, #0x388
    a540:	52800020 	mov	w0, #0x1                   	// #1
    a544:	f901c7f7 	str	x23, [sp, #904]
    a548:	f901cbe2 	str	x2, [sp, #912]
    a54c:	97ffea22 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a550:	97ffebc1 	bl	5454 <fwp_rc_fresh>
    a554:	aa0003e2 	mov	x2, x0
    a558:	910e63e1 	add	x1, sp, #0x398
    a55c:	52800020 	mov	w0, #0x1                   	// #1
    a560:	f901cff5 	str	x21, [sp, #920]
    a564:	f901d3e2 	str	x2, [sp, #928]
    a568:	97ffea1b 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a56c:	97ffebba 	bl	5454 <fwp_rc_fresh>
    a570:	aa0003e2 	mov	x2, x0
    a574:	910ea3e1 	add	x1, sp, #0x3a8
    a578:	52800020 	mov	w0, #0x1                   	// #1
    a57c:	f901d7f7 	str	x23, [sp, #936]
    a580:	f901dbe2 	str	x2, [sp, #944]
    a584:	97ffea14 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a588:	97ffebb3 	bl	5454 <fwp_rc_fresh>
    a58c:	aa0003e2 	mov	x2, x0
    a590:	910ee3e1 	add	x1, sp, #0x3b8
    a594:	52800020 	mov	w0, #0x1                   	// #1
    a598:	f901dff5 	str	x21, [sp, #952]
    a59c:	f901e3e2 	str	x2, [sp, #960]
    a5a0:	97ffea0d 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a5a4:	97ffebac 	bl	5454 <fwp_rc_fresh>
    a5a8:	aa0003e2 	mov	x2, x0
    a5ac:	910f23e1 	add	x1, sp, #0x3c8
    a5b0:	52800020 	mov	w0, #0x1                   	// #1
    a5b4:	f901e7f7 	str	x23, [sp, #968]
    a5b8:	f901ebe2 	str	x2, [sp, #976]
    a5bc:	97ffea06 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a5c0:	97ffeba5 	bl	5454 <fwp_rc_fresh>
    a5c4:	aa0003e2 	mov	x2, x0
    a5c8:	910f63e1 	add	x1, sp, #0x3d8
    a5cc:	52800020 	mov	w0, #0x1                   	// #1
    a5d0:	f901eff5 	str	x21, [sp, #984]
    a5d4:	f901f3e2 	str	x2, [sp, #992]
    a5d8:	97ffe9ff 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a5dc:	97ffeb9e 	bl	5454 <fwp_rc_fresh>
    a5e0:	aa0003e2 	mov	x2, x0
    a5e4:	910fa3e1 	add	x1, sp, #0x3e8
    a5e8:	52800020 	mov	w0, #0x1                   	// #1
    a5ec:	f901f7f7 	str	x23, [sp, #1000]
    a5f0:	f901fbe2 	str	x2, [sp, #1008]
    a5f4:	97ffe9f8 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a5f8:	97ffeb97 	bl	5454 <fwp_rc_fresh>
    a5fc:	aa0003e2 	mov	x2, x0
    a600:	910fe3e1 	add	x1, sp, #0x3f8
    a604:	52800020 	mov	w0, #0x1                   	// #1
    a608:	f901fff5 	str	x21, [sp, #1016]
    a60c:	f90203e2 	str	x2, [sp, #1024]
    a610:	97ffe9f1 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a614:	91158283 	add	x3, x20, #0x560
    a618:	aa0003f5 	mov	x21, x0
    a61c:	f949d861 	ldr	x1, [x3, #5040]
    a620:	f949ec60 	ldr	x0, [x3, #5080]
    a624:	cb0102a1 	sub	x1, x21, x1
    a628:	eb00403f 	cmp	x1, x0, lsl #16
    a62c:	54000322 	b.cs	a690 <f0+0xd40>  // b.hs, b.nlast
    a630:	d350fc22 	lsr	x2, x1, #16
    a634:	f949fc63 	ldr	x3, [x3, #5112]
    a638:	8b020842 	add	x2, x2, x2, lsl #2
    a63c:	d37df042 	lsl	x2, x2, #3
    a640:	8b020060 	add	x0, x3, x2
    a644:	f9401017 	ldr	x23, [x0, #32]
    a648:	b4000257 	cbz	x23, a690 <f0+0xd40>
    a64c:	38626862 	ldrb	w2, [x3, x2]
    a650:	7100085f 	cmp	w2, #0x2
    a654:	5400b300 	b.eq	bcb4 <f0+0x2364>  // b.none
    a658:	7100045f 	cmp	w2, #0x1
    a65c:	540001a1 	b.ne	a690 <f0+0xd40>  // b.any
    a660:	29430002 	ldp	w2, w0, [x0, #24]
    a664:	92403c21 	and	x1, x1, #0xffff
    a668:	9b027c21 	mul	x1, x1, x2
    a66c:	d360fc21 	lsr	x1, x1, #32
    a670:	eb00003f 	cmp	x1, x0
    a674:	540000e2 	b.cs	a690 <f0+0xd40>  // b.hs, b.nlast
    a678:	8b0102f7 	add	x23, x23, x1
    a67c:	394002e0 	ldrb	w0, [x23]
    a680:	7103fc1f 	cmp	w0, #0xff
    a684:	5400bde0 	b.eq	be40 <f0+0x24f0>  // b.none
    a688:	52800020 	mov	w0, #0x1                   	// #1
    a68c:	390002e0 	strb	w0, [x23]
    a690:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a694:	911023e1 	add	x1, sp, #0x408
    a698:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a69c:	52800020 	mov	w0, #0x1                   	// #1
    a6a0:	f90207e2 	str	x2, [sp, #1032]
    a6a4:	f9020bf5 	str	x21, [sp, #1040]
    a6a8:	97ffe9cb 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a6ac:	97ffeb6a 	bl	5454 <fwp_rc_fresh>
    a6b0:	aa0003e2 	mov	x2, x0
    a6b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a6b8:	911063e1 	add	x1, sp, #0x418
    a6bc:	52800020 	mov	w0, #0x1                   	// #1
    a6c0:	f9020fe3 	str	x3, [sp, #1048]
    a6c4:	f90213e2 	str	x2, [sp, #1056]
    a6c8:	97ffe9c3 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a6cc:	91158283 	add	x3, x20, #0x560
    a6d0:	aa0003f5 	mov	x21, x0
    a6d4:	f949d861 	ldr	x1, [x3, #5040]
    a6d8:	f949ec60 	ldr	x0, [x3, #5080]
    a6dc:	cb0102a1 	sub	x1, x21, x1
    a6e0:	eb00403f 	cmp	x1, x0, lsl #16
    a6e4:	54000322 	b.cs	a748 <f0+0xdf8>  // b.hs, b.nlast
    a6e8:	d350fc22 	lsr	x2, x1, #16
    a6ec:	f949fc63 	ldr	x3, [x3, #5112]
    a6f0:	8b020842 	add	x2, x2, x2, lsl #2
    a6f4:	d37df042 	lsl	x2, x2, #3
    a6f8:	8b020060 	add	x0, x3, x2
    a6fc:	f9401017 	ldr	x23, [x0, #32]
    a700:	b4000257 	cbz	x23, a748 <f0+0xdf8>
    a704:	38626862 	ldrb	w2, [x3, x2]
    a708:	7100085f 	cmp	w2, #0x2
    a70c:	5400ace0 	b.eq	bca8 <f0+0x2358>  // b.none
    a710:	7100045f 	cmp	w2, #0x1
    a714:	540001a1 	b.ne	a748 <f0+0xdf8>  // b.any
    a718:	29430002 	ldp	w2, w0, [x0, #24]
    a71c:	92403c21 	and	x1, x1, #0xffff
    a720:	9b027c21 	mul	x1, x1, x2
    a724:	d360fc21 	lsr	x1, x1, #32
    a728:	eb00003f 	cmp	x1, x0
    a72c:	540000e2 	b.cs	a748 <f0+0xdf8>  // b.hs, b.nlast
    a730:	8b0102f7 	add	x23, x23, x1
    a734:	394002e0 	ldrb	w0, [x23]
    a738:	7103fc1f 	cmp	w0, #0xff
    a73c:	5400b880 	b.eq	be4c <f0+0x24fc>  // b.none
    a740:	52800020 	mov	w0, #0x1                   	// #1
    a744:	390002e0 	strb	w0, [x23]
    a748:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a74c:	9110a3e1 	add	x1, sp, #0x428
    a750:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a754:	52800020 	mov	w0, #0x1                   	// #1
    a758:	f90217e2 	str	x2, [sp, #1064]
    a75c:	f9021bf5 	str	x21, [sp, #1072]
    a760:	97ffe99d 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a764:	97ffeb3c 	bl	5454 <fwp_rc_fresh>
    a768:	aa0003e2 	mov	x2, x0
    a76c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a770:	9110e3e1 	add	x1, sp, #0x438
    a774:	52800020 	mov	w0, #0x1                   	// #1
    a778:	f9021fe3 	str	x3, [sp, #1080]
    a77c:	f90223e2 	str	x2, [sp, #1088]
    a780:	97ffe995 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a784:	91158283 	add	x3, x20, #0x560
    a788:	aa0003f7 	mov	x23, x0
    a78c:	f949d861 	ldr	x1, [x3, #5040]
    a790:	f949ec60 	ldr	x0, [x3, #5080]
    a794:	cb0102e1 	sub	x1, x23, x1
    a798:	eb00403f 	cmp	x1, x0, lsl #16
    a79c:	54000322 	b.cs	a800 <f0+0xeb0>  // b.hs, b.nlast
    a7a0:	d350fc22 	lsr	x2, x1, #16
    a7a4:	f949fc63 	ldr	x3, [x3, #5112]
    a7a8:	8b020842 	add	x2, x2, x2, lsl #2
    a7ac:	d37df042 	lsl	x2, x2, #3
    a7b0:	8b020060 	add	x0, x3, x2
    a7b4:	f9401015 	ldr	x21, [x0, #32]
    a7b8:	b4000255 	cbz	x21, a800 <f0+0xeb0>
    a7bc:	38626862 	ldrb	w2, [x3, x2]
    a7c0:	7100085f 	cmp	w2, #0x2
    a7c4:	5400a6c0 	b.eq	bc9c <f0+0x234c>  // b.none
    a7c8:	7100045f 	cmp	w2, #0x1
    a7cc:	540001a1 	b.ne	a800 <f0+0xeb0>  // b.any
    a7d0:	29430002 	ldp	w2, w0, [x0, #24]
    a7d4:	92403c21 	and	x1, x1, #0xffff
    a7d8:	9b027c21 	mul	x1, x1, x2
    a7dc:	d360fc21 	lsr	x1, x1, #32
    a7e0:	eb00003f 	cmp	x1, x0
    a7e4:	540000e2 	b.cs	a800 <f0+0xeb0>  // b.hs, b.nlast
    a7e8:	8b0102b5 	add	x21, x21, x1
    a7ec:	394002a0 	ldrb	w0, [x21]
    a7f0:	7103fc1f 	cmp	w0, #0xff
    a7f4:	5400b320 	b.eq	be58 <f0+0x2508>  // b.none
    a7f8:	52800020 	mov	w0, #0x1                   	// #1
    a7fc:	390002a0 	strb	w0, [x21]
    a800:	911123e1 	add	x1, sp, #0x448
    a804:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a808:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a80c:	52800020 	mov	w0, #0x1                   	// #1
    a810:	f90227f5 	str	x21, [sp, #1096]
    a814:	f9022bf7 	str	x23, [sp, #1104]
    a818:	97ffe96f 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a81c:	97ffeb0e 	bl	5454 <fwp_rc_fresh>
    a820:	aa0003e2 	mov	x2, x0
    a824:	911163e1 	add	x1, sp, #0x458
    a828:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a82c:	52800020 	mov	w0, #0x1                   	// #1
    a830:	f9022ff7 	str	x23, [sp, #1112]
    a834:	f90233e2 	str	x2, [sp, #1120]
    a838:	97ffe967 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a83c:	97ffeb06 	bl	5454 <fwp_rc_fresh>
    a840:	aa0003e2 	mov	x2, x0
    a844:	9111a3e1 	add	x1, sp, #0x468
    a848:	52800020 	mov	w0, #0x1                   	// #1
    a84c:	f90237f5 	str	x21, [sp, #1128]
    a850:	f9023be2 	str	x2, [sp, #1136]
    a854:	97ffe960 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a858:	97ffeaff 	bl	5454 <fwp_rc_fresh>
    a85c:	aa0003e2 	mov	x2, x0
    a860:	9111e3e1 	add	x1, sp, #0x478
    a864:	52800020 	mov	w0, #0x1                   	// #1
    a868:	f9023ff7 	str	x23, [sp, #1144]
    a86c:	f90243e2 	str	x2, [sp, #1152]
    a870:	97ffe959 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a874:	97ffeaf8 	bl	5454 <fwp_rc_fresh>
    a878:	aa0003e2 	mov	x2, x0
    a87c:	911223e1 	add	x1, sp, #0x488
    a880:	52800020 	mov	w0, #0x1                   	// #1
    a884:	f90247f5 	str	x21, [sp, #1160]
    a888:	f9024be2 	str	x2, [sp, #1168]
    a88c:	97ffe952 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a890:	97ffeaf1 	bl	5454 <fwp_rc_fresh>
    a894:	aa0003e2 	mov	x2, x0
    a898:	911263e1 	add	x1, sp, #0x498
    a89c:	52800020 	mov	w0, #0x1                   	// #1
    a8a0:	f9024ff7 	str	x23, [sp, #1176]
    a8a4:	f90253e2 	str	x2, [sp, #1184]
    a8a8:	97ffe94b 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a8ac:	97ffeaea 	bl	5454 <fwp_rc_fresh>
    a8b0:	aa0003e2 	mov	x2, x0
    a8b4:	9112a3e1 	add	x1, sp, #0x4a8
    a8b8:	52800020 	mov	w0, #0x1                   	// #1
    a8bc:	f90257f5 	str	x21, [sp, #1192]
    a8c0:	f9025be2 	str	x2, [sp, #1200]
    a8c4:	97ffe944 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a8c8:	91158283 	add	x3, x20, #0x560
    a8cc:	aa0003f5 	mov	x21, x0
    a8d0:	f949d861 	ldr	x1, [x3, #5040]
    a8d4:	f949ec60 	ldr	x0, [x3, #5080]
    a8d8:	cb0102a1 	sub	x1, x21, x1
    a8dc:	eb00403f 	cmp	x1, x0, lsl #16
    a8e0:	54000322 	b.cs	a944 <f0+0xff4>  // b.hs, b.nlast
    a8e4:	d350fc22 	lsr	x2, x1, #16
    a8e8:	f949fc63 	ldr	x3, [x3, #5112]
    a8ec:	8b020842 	add	x2, x2, x2, lsl #2
    a8f0:	d37df042 	lsl	x2, x2, #3
    a8f4:	8b020060 	add	x0, x3, x2
    a8f8:	f9401017 	ldr	x23, [x0, #32]
    a8fc:	b4000257 	cbz	x23, a944 <f0+0xff4>
    a900:	38626862 	ldrb	w2, [x3, x2]
    a904:	7100085f 	cmp	w2, #0x2
    a908:	54009c40 	b.eq	bc90 <f0+0x2340>  // b.none
    a90c:	7100045f 	cmp	w2, #0x1
    a910:	540001a1 	b.ne	a944 <f0+0xff4>  // b.any
    a914:	29430002 	ldp	w2, w0, [x0, #24]
    a918:	92403c21 	and	x1, x1, #0xffff
    a91c:	9b027c21 	mul	x1, x1, x2
    a920:	d360fc21 	lsr	x1, x1, #32
    a924:	eb00003f 	cmp	x1, x0
    a928:	540000e2 	b.cs	a944 <f0+0xff4>  // b.hs, b.nlast
    a92c:	8b0102f7 	add	x23, x23, x1
    a930:	394002e0 	ldrb	w0, [x23]
    a934:	7103fc1f 	cmp	w0, #0xff
    a938:	5400a960 	b.eq	be64 <f0+0x2514>  // b.none
    a93c:	52800020 	mov	w0, #0x1                   	// #1
    a940:	390002e0 	strb	w0, [x23]
    a944:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a948:	9112e3e1 	add	x1, sp, #0x4b8
    a94c:	52800020 	mov	w0, #0x1                   	// #1
    a950:	f9025fe2 	str	x2, [sp, #1208]
    a954:	f90263f5 	str	x21, [sp, #1216]
    a958:	97ffe91f 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a95c:	91158283 	add	x3, x20, #0x560
    a960:	aa0003f5 	mov	x21, x0
    a964:	f949d861 	ldr	x1, [x3, #5040]
    a968:	f949ec60 	ldr	x0, [x3, #5080]
    a96c:	cb0102a1 	sub	x1, x21, x1
    a970:	eb00403f 	cmp	x1, x0, lsl #16
    a974:	54000322 	b.cs	a9d8 <f0+0x1088>  // b.hs, b.nlast
    a978:	d350fc22 	lsr	x2, x1, #16
    a97c:	f949fc63 	ldr	x3, [x3, #5112]
    a980:	8b020842 	add	x2, x2, x2, lsl #2
    a984:	d37df042 	lsl	x2, x2, #3
    a988:	8b020060 	add	x0, x3, x2
    a98c:	f9401017 	ldr	x23, [x0, #32]
    a990:	b4000257 	cbz	x23, a9d8 <f0+0x1088>
    a994:	38626862 	ldrb	w2, [x3, x2]
    a998:	7100085f 	cmp	w2, #0x2
    a99c:	540094a0 	b.eq	bc30 <f0+0x22e0>  // b.none
    a9a0:	7100045f 	cmp	w2, #0x1
    a9a4:	540001a1 	b.ne	a9d8 <f0+0x1088>  // b.any
    a9a8:	29430002 	ldp	w2, w0, [x0, #24]
    a9ac:	92403c21 	and	x1, x1, #0xffff
    a9b0:	9b027c21 	mul	x1, x1, x2
    a9b4:	d360fc21 	lsr	x1, x1, #32
    a9b8:	eb00003f 	cmp	x1, x0
    a9bc:	540000e2 	b.cs	a9d8 <f0+0x1088>  // b.hs, b.nlast
    a9c0:	8b0102f7 	add	x23, x23, x1
    a9c4:	394002e0 	ldrb	w0, [x23]
    a9c8:	7103fc1f 	cmp	w0, #0xff
    a9cc:	5400a520 	b.eq	be70 <f0+0x2520>  // b.none
    a9d0:	52800020 	mov	w0, #0x1                   	// #1
    a9d4:	390002e0 	strb	w0, [x23]
    a9d8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a9dc:	911323e1 	add	x1, sp, #0x4c8
    a9e0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a9e4:	52800020 	mov	w0, #0x1                   	// #1
    a9e8:	f90267e2 	str	x2, [sp, #1224]
    a9ec:	f9026bf5 	str	x21, [sp, #1232]
    a9f0:	97ffe8f9 	bl	4dd4 <fwp_data.part.0.constprop.0>
    a9f4:	97ffea98 	bl	5454 <fwp_rc_fresh>
    a9f8:	aa0003e2 	mov	x2, x0
    a9fc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aa00:	911363e1 	add	x1, sp, #0x4d8
    aa04:	52800020 	mov	w0, #0x1                   	// #1
    aa08:	f9026fe3 	str	x3, [sp, #1240]
    aa0c:	f90273e2 	str	x2, [sp, #1248]
    aa10:	97ffe8f1 	bl	4dd4 <fwp_data.part.0.constprop.0>
    aa14:	91158283 	add	x3, x20, #0x560
    aa18:	aa0003f5 	mov	x21, x0
    aa1c:	f949d861 	ldr	x1, [x3, #5040]
    aa20:	f949ec60 	ldr	x0, [x3, #5080]
    aa24:	cb0102a1 	sub	x1, x21, x1
    aa28:	eb00403f 	cmp	x1, x0, lsl #16
    aa2c:	54000322 	b.cs	aa90 <f0+0x1140>  // b.hs, b.nlast
    aa30:	d350fc22 	lsr	x2, x1, #16
    aa34:	f949fc63 	ldr	x3, [x3, #5112]
    aa38:	8b020842 	add	x2, x2, x2, lsl #2
    aa3c:	d37df042 	lsl	x2, x2, #3
    aa40:	8b020060 	add	x0, x3, x2
    aa44:	f9401017 	ldr	x23, [x0, #32]
    aa48:	b4000257 	cbz	x23, aa90 <f0+0x1140>
    aa4c:	38626862 	ldrb	w2, [x3, x2]
    aa50:	7100085f 	cmp	w2, #0x2
    aa54:	54008e80 	b.eq	bc24 <f0+0x22d4>  // b.none
    aa58:	7100045f 	cmp	w2, #0x1
    aa5c:	540001a1 	b.ne	aa90 <f0+0x1140>  // b.any
    aa60:	29430002 	ldp	w2, w0, [x0, #24]
    aa64:	92403c21 	and	x1, x1, #0xffff
    aa68:	9b027c21 	mul	x1, x1, x2
    aa6c:	d360fc21 	lsr	x1, x1, #32
    aa70:	eb00003f 	cmp	x1, x0
    aa74:	540000e2 	b.cs	aa90 <f0+0x1140>  // b.hs, b.nlast
    aa78:	8b0102f7 	add	x23, x23, x1
    aa7c:	394002e0 	ldrb	w0, [x23]
    aa80:	7103fc1f 	cmp	w0, #0xff
    aa84:	54009fc0 	b.eq	be7c <f0+0x252c>  // b.none
    aa88:	52800020 	mov	w0, #0x1                   	// #1
    aa8c:	390002e0 	strb	w0, [x23]
    aa90:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aa94:	9113a3e1 	add	x1, sp, #0x4e8
    aa98:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aa9c:	52800020 	mov	w0, #0x1                   	// #1
    aaa0:	f90277e2 	str	x2, [sp, #1256]
    aaa4:	f9027bf5 	str	x21, [sp, #1264]
    aaa8:	97ffe8cb 	bl	4dd4 <fwp_data.part.0.constprop.0>
    aaac:	97ffea6a 	bl	5454 <fwp_rc_fresh>
    aab0:	aa0003e2 	mov	x2, x0
    aab4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aab8:	9113e3e1 	add	x1, sp, #0x4f8
    aabc:	52800020 	mov	w0, #0x1                   	// #1
    aac0:	f9027fe3 	str	x3, [sp, #1272]
    aac4:	f90283e2 	str	x2, [sp, #1280]
    aac8:	97ffe8c3 	bl	4dd4 <fwp_data.part.0.constprop.0>
    aacc:	91158283 	add	x3, x20, #0x560
    aad0:	aa0003f5 	mov	x21, x0
    aad4:	f949d861 	ldr	x1, [x3, #5040]
    aad8:	f949ec60 	ldr	x0, [x3, #5080]
    aadc:	cb0102a1 	sub	x1, x21, x1
    aae0:	eb00403f 	cmp	x1, x0, lsl #16
    aae4:	54000322 	b.cs	ab48 <f0+0x11f8>  // b.hs, b.nlast
    aae8:	d350fc22 	lsr	x2, x1, #16
    aaec:	f949fc63 	ldr	x3, [x3, #5112]
    aaf0:	8b020842 	add	x2, x2, x2, lsl #2
    aaf4:	d37df042 	lsl	x2, x2, #3
    aaf8:	8b020060 	add	x0, x3, x2
    aafc:	f9401017 	ldr	x23, [x0, #32]
    ab00:	b4000257 	cbz	x23, ab48 <f0+0x11f8>
    ab04:	38626862 	ldrb	w2, [x3, x2]
    ab08:	7100085f 	cmp	w2, #0x2
    ab0c:	54008860 	b.eq	bc18 <f0+0x22c8>  // b.none
    ab10:	7100045f 	cmp	w2, #0x1
    ab14:	540001a1 	b.ne	ab48 <f0+0x11f8>  // b.any
    ab18:	29430002 	ldp	w2, w0, [x0, #24]
    ab1c:	92403c21 	and	x1, x1, #0xffff
    ab20:	9b027c21 	mul	x1, x1, x2
    ab24:	d360fc21 	lsr	x1, x1, #32
    ab28:	eb00003f 	cmp	x1, x0
    ab2c:	540000e2 	b.cs	ab48 <f0+0x11f8>  // b.hs, b.nlast
    ab30:	8b0102f7 	add	x23, x23, x1
    ab34:	394002e0 	ldrb	w0, [x23]
    ab38:	7103fc1f 	cmp	w0, #0xff
    ab3c:	54009a60 	b.eq	be88 <f0+0x2538>  // b.none
    ab40:	52800020 	mov	w0, #0x1                   	// #1
    ab44:	390002e0 	strb	w0, [x23]
    ab48:	911423e1 	add	x1, sp, #0x508
    ab4c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ab50:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ab54:	52800020 	mov	w0, #0x1                   	// #1
    ab58:	f90287f7 	str	x23, [sp, #1288]
    ab5c:	f9028bf5 	str	x21, [sp, #1296]
    ab60:	97ffe89d 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ab64:	97ffea3c 	bl	5454 <fwp_rc_fresh>
    ab68:	aa0003e2 	mov	x2, x0
    ab6c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ab70:	911463e1 	add	x1, sp, #0x518
    ab74:	52800020 	mov	w0, #0x1                   	// #1
    ab78:	f9028fe3 	str	x3, [sp, #1304]
    ab7c:	f90293e2 	str	x2, [sp, #1312]
    ab80:	97ffe895 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ab84:	97ffea34 	bl	5454 <fwp_rc_fresh>
    ab88:	aa0003e2 	mov	x2, x0
    ab8c:	9114a3e1 	add	x1, sp, #0x528
    ab90:	52800020 	mov	w0, #0x1                   	// #1
    ab94:	f90297f7 	str	x23, [sp, #1320]
    ab98:	f9029be2 	str	x2, [sp, #1328]
    ab9c:	97ffe88e 	bl	4dd4 <fwp_data.part.0.constprop.0>
    aba0:	91158283 	add	x3, x20, #0x560
    aba4:	aa0003f5 	mov	x21, x0
    aba8:	f949d861 	ldr	x1, [x3, #5040]
    abac:	f949ec60 	ldr	x0, [x3, #5080]
    abb0:	cb0102a1 	sub	x1, x21, x1
    abb4:	eb00403f 	cmp	x1, x0, lsl #16
    abb8:	54000322 	b.cs	ac1c <f0+0x12cc>  // b.hs, b.nlast
    abbc:	d350fc22 	lsr	x2, x1, #16
    abc0:	f949fc63 	ldr	x3, [x3, #5112]
    abc4:	8b020842 	add	x2, x2, x2, lsl #2
    abc8:	d37df042 	lsl	x2, x2, #3
    abcc:	8b020060 	add	x0, x3, x2
    abd0:	f9401017 	ldr	x23, [x0, #32]
    abd4:	b4000257 	cbz	x23, ac1c <f0+0x12cc>
    abd8:	38626862 	ldrb	w2, [x3, x2]
    abdc:	7100085f 	cmp	w2, #0x2
    abe0:	54008160 	b.eq	bc0c <f0+0x22bc>  // b.none
    abe4:	7100045f 	cmp	w2, #0x1
    abe8:	540001a1 	b.ne	ac1c <f0+0x12cc>  // b.any
    abec:	29430002 	ldp	w2, w0, [x0, #24]
    abf0:	92403c21 	and	x1, x1, #0xffff
    abf4:	9b027c21 	mul	x1, x1, x2
    abf8:	d360fc21 	lsr	x1, x1, #32
    abfc:	eb00003f 	cmp	x1, x0
    ac00:	540000e2 	b.cs	ac1c <f0+0x12cc>  // b.hs, b.nlast
    ac04:	8b0102f7 	add	x23, x23, x1
    ac08:	394002e0 	ldrb	w0, [x23]
    ac0c:	7103fc1f 	cmp	w0, #0xff
    ac10:	54009420 	b.eq	be94 <f0+0x2544>  // b.none
    ac14:	52800020 	mov	w0, #0x1                   	// #1
    ac18:	390002e0 	strb	w0, [x23]
    ac1c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ac20:	9114e3e1 	add	x1, sp, #0x538
    ac24:	52800020 	mov	w0, #0x1                   	// #1
    ac28:	f9029fe2 	str	x2, [sp, #1336]
    ac2c:	f902a3f5 	str	x21, [sp, #1344]
    ac30:	97ffe869 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ac34:	91158283 	add	x3, x20, #0x560
    ac38:	aa0003f5 	mov	x21, x0
    ac3c:	f949d861 	ldr	x1, [x3, #5040]
    ac40:	f949ec60 	ldr	x0, [x3, #5080]
    ac44:	cb0102a1 	sub	x1, x21, x1
    ac48:	eb00403f 	cmp	x1, x0, lsl #16
    ac4c:	54000322 	b.cs	acb0 <f0+0x1360>  // b.hs, b.nlast
    ac50:	d350fc22 	lsr	x2, x1, #16
    ac54:	f949fc63 	ldr	x3, [x3, #5112]
    ac58:	8b020842 	add	x2, x2, x2, lsl #2
    ac5c:	d37df042 	lsl	x2, x2, #3
    ac60:	8b020060 	add	x0, x3, x2
    ac64:	f9401017 	ldr	x23, [x0, #32]
    ac68:	b4000257 	cbz	x23, acb0 <f0+0x1360>
    ac6c:	38626862 	ldrb	w2, [x3, x2]
    ac70:	7100085f 	cmp	w2, #0x2
    ac74:	54007c60 	b.eq	bc00 <f0+0x22b0>  // b.none
    ac78:	7100045f 	cmp	w2, #0x1
    ac7c:	540001a1 	b.ne	acb0 <f0+0x1360>  // b.any
    ac80:	29430002 	ldp	w2, w0, [x0, #24]
    ac84:	92403c21 	and	x1, x1, #0xffff
    ac88:	9b027c21 	mul	x1, x1, x2
    ac8c:	d360fc21 	lsr	x1, x1, #32
    ac90:	eb00003f 	cmp	x1, x0
    ac94:	540000e2 	b.cs	acb0 <f0+0x1360>  // b.hs, b.nlast
    ac98:	8b0102f7 	add	x23, x23, x1
    ac9c:	394002e0 	ldrb	w0, [x23]
    aca0:	7103fc1f 	cmp	w0, #0xff
    aca4:	54008fe0 	b.eq	bea0 <f0+0x2550>  // b.none
    aca8:	52800020 	mov	w0, #0x1                   	// #1
    acac:	390002e0 	strb	w0, [x23]
    acb0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    acb4:	911523e1 	add	x1, sp, #0x548
    acb8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    acbc:	52800020 	mov	w0, #0x1                   	// #1
    acc0:	f902a7e2 	str	x2, [sp, #1352]
    acc4:	f902abf5 	str	x21, [sp, #1360]
    acc8:	97ffe843 	bl	4dd4 <fwp_data.part.0.constprop.0>
    accc:	97ffe9e2 	bl	5454 <fwp_rc_fresh>
    acd0:	aa0003e2 	mov	x2, x0
    acd4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    acd8:	911563e1 	add	x1, sp, #0x558
    acdc:	52800020 	mov	w0, #0x1                   	// #1
    ace0:	f902afe3 	str	x3, [sp, #1368]
    ace4:	f902b3e2 	str	x2, [sp, #1376]
    ace8:	97ffe83b 	bl	4dd4 <fwp_data.part.0.constprop.0>
    acec:	91158283 	add	x3, x20, #0x560
    acf0:	aa0003f5 	mov	x21, x0
    acf4:	f949d861 	ldr	x1, [x3, #5040]
    acf8:	f949ec60 	ldr	x0, [x3, #5080]
    acfc:	cb0102a1 	sub	x1, x21, x1
    ad00:	eb00403f 	cmp	x1, x0, lsl #16
    ad04:	54000322 	b.cs	ad68 <f0+0x1418>  // b.hs, b.nlast
    ad08:	d350fc22 	lsr	x2, x1, #16
    ad0c:	f949fc63 	ldr	x3, [x3, #5112]
    ad10:	8b020842 	add	x2, x2, x2, lsl #2
    ad14:	d37df042 	lsl	x2, x2, #3
    ad18:	8b020060 	add	x0, x3, x2
    ad1c:	f9401017 	ldr	x23, [x0, #32]
    ad20:	b4000257 	cbz	x23, ad68 <f0+0x1418>
    ad24:	38626862 	ldrb	w2, [x3, x2]
    ad28:	7100085f 	cmp	w2, #0x2
    ad2c:	54007640 	b.eq	bbf4 <f0+0x22a4>  // b.none
    ad30:	7100045f 	cmp	w2, #0x1
    ad34:	540001a1 	b.ne	ad68 <f0+0x1418>  // b.any
    ad38:	29430002 	ldp	w2, w0, [x0, #24]
    ad3c:	92403c21 	and	x1, x1, #0xffff
    ad40:	9b027c21 	mul	x1, x1, x2
    ad44:	d360fc21 	lsr	x1, x1, #32
    ad48:	eb00003f 	cmp	x1, x0
    ad4c:	540000e2 	b.cs	ad68 <f0+0x1418>  // b.hs, b.nlast
    ad50:	8b0102f7 	add	x23, x23, x1
    ad54:	394002e0 	ldrb	w0, [x23]
    ad58:	7103fc1f 	cmp	w0, #0xff
    ad5c:	54008a80 	b.eq	beac <f0+0x255c>  // b.none
    ad60:	52800020 	mov	w0, #0x1                   	// #1
    ad64:	390002e0 	strb	w0, [x23]
    ad68:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ad6c:	9115a3e1 	add	x1, sp, #0x568
    ad70:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ad74:	52800020 	mov	w0, #0x1                   	// #1
    ad78:	f902b7e2 	str	x2, [sp, #1384]
    ad7c:	f902bbf5 	str	x21, [sp, #1392]
    ad80:	97ffe815 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ad84:	97ffe9b4 	bl	5454 <fwp_rc_fresh>
    ad88:	aa0003e2 	mov	x2, x0
    ad8c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ad90:	9115e3e1 	add	x1, sp, #0x578
    ad94:	52800020 	mov	w0, #0x1                   	// #1
    ad98:	f902bfe3 	str	x3, [sp, #1400]
    ad9c:	f902c3e2 	str	x2, [sp, #1408]
    ada0:	97ffe80d 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ada4:	91158283 	add	x3, x20, #0x560
    ada8:	aa0003f5 	mov	x21, x0
    adac:	f949d861 	ldr	x1, [x3, #5040]
    adb0:	f949ec60 	ldr	x0, [x3, #5080]
    adb4:	cb0102a1 	sub	x1, x21, x1
    adb8:	eb00403f 	cmp	x1, x0, lsl #16
    adbc:	54000322 	b.cs	ae20 <f0+0x14d0>  // b.hs, b.nlast
    adc0:	d350fc22 	lsr	x2, x1, #16
    adc4:	f949fc63 	ldr	x3, [x3, #5112]
    adc8:	8b020842 	add	x2, x2, x2, lsl #2
    adcc:	d37df042 	lsl	x2, x2, #3
    add0:	8b020060 	add	x0, x3, x2
    add4:	f9401017 	ldr	x23, [x0, #32]
    add8:	b4000257 	cbz	x23, ae20 <f0+0x14d0>
    addc:	38626862 	ldrb	w2, [x3, x2]
    ade0:	7100085f 	cmp	w2, #0x2
    ade4:	54007020 	b.eq	bbe8 <f0+0x2298>  // b.none
    ade8:	7100045f 	cmp	w2, #0x1
    adec:	540001a1 	b.ne	ae20 <f0+0x14d0>  // b.any
    adf0:	29430002 	ldp	w2, w0, [x0, #24]
    adf4:	92403c21 	and	x1, x1, #0xffff
    adf8:	9b027c21 	mul	x1, x1, x2
    adfc:	d360fc21 	lsr	x1, x1, #32
    ae00:	eb00003f 	cmp	x1, x0
    ae04:	540000e2 	b.cs	ae20 <f0+0x14d0>  // b.hs, b.nlast
    ae08:	8b0102f7 	add	x23, x23, x1
    ae0c:	394002e0 	ldrb	w0, [x23]
    ae10:	7103fc1f 	cmp	w0, #0xff
    ae14:	54008520 	b.eq	beb8 <f0+0x2568>  // b.none
    ae18:	52800020 	mov	w0, #0x1                   	// #1
    ae1c:	390002e0 	strb	w0, [x23]
    ae20:	911623e1 	add	x1, sp, #0x588
    ae24:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ae28:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ae2c:	52800020 	mov	w0, #0x1                   	// #1
    ae30:	f902c7f7 	str	x23, [sp, #1416]
    ae34:	f902cbf5 	str	x21, [sp, #1424]
    ae38:	97ffe7e7 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ae3c:	97ffe986 	bl	5454 <fwp_rc_fresh>
    ae40:	aa0003e2 	mov	x2, x0
    ae44:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ae48:	911663e1 	add	x1, sp, #0x598
    ae4c:	52800020 	mov	w0, #0x1                   	// #1
    ae50:	f902cfe3 	str	x3, [sp, #1432]
    ae54:	f902d3e2 	str	x2, [sp, #1440]
    ae58:	97ffe7df 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ae5c:	97ffe97e 	bl	5454 <fwp_rc_fresh>
    ae60:	aa0003e2 	mov	x2, x0
    ae64:	9116a3e1 	add	x1, sp, #0x5a8
    ae68:	52800020 	mov	w0, #0x1                   	// #1
    ae6c:	f902d7f7 	str	x23, [sp, #1448]
    ae70:	f902dbe2 	str	x2, [sp, #1456]
    ae74:	97ffe7d8 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ae78:	91158283 	add	x3, x20, #0x560
    ae7c:	aa0003f5 	mov	x21, x0
    ae80:	f949d861 	ldr	x1, [x3, #5040]
    ae84:	f949ec60 	ldr	x0, [x3, #5080]
    ae88:	cb0102a1 	sub	x1, x21, x1
    ae8c:	eb00403f 	cmp	x1, x0, lsl #16
    ae90:	54000322 	b.cs	aef4 <f0+0x15a4>  // b.hs, b.nlast
    ae94:	d350fc22 	lsr	x2, x1, #16
    ae98:	f949fc63 	ldr	x3, [x3, #5112]
    ae9c:	8b020842 	add	x2, x2, x2, lsl #2
    aea0:	d37df042 	lsl	x2, x2, #3
    aea4:	8b020060 	add	x0, x3, x2
    aea8:	f9401017 	ldr	x23, [x0, #32]
    aeac:	b4000257 	cbz	x23, aef4 <f0+0x15a4>
    aeb0:	38626862 	ldrb	w2, [x3, x2]
    aeb4:	7100085f 	cmp	w2, #0x2
    aeb8:	54006920 	b.eq	bbdc <f0+0x228c>  // b.none
    aebc:	7100045f 	cmp	w2, #0x1
    aec0:	540001a1 	b.ne	aef4 <f0+0x15a4>  // b.any
    aec4:	29430002 	ldp	w2, w0, [x0, #24]
    aec8:	92403c21 	and	x1, x1, #0xffff
    aecc:	9b027c21 	mul	x1, x1, x2
    aed0:	d360fc21 	lsr	x1, x1, #32
    aed4:	eb00003f 	cmp	x1, x0
    aed8:	540000e2 	b.cs	aef4 <f0+0x15a4>  // b.hs, b.nlast
    aedc:	8b0102f7 	add	x23, x23, x1
    aee0:	394002e0 	ldrb	w0, [x23]
    aee4:	7103fc1f 	cmp	w0, #0xff
    aee8:	54007ee0 	b.eq	bec4 <f0+0x2574>  // b.none
    aeec:	52800020 	mov	w0, #0x1                   	// #1
    aef0:	390002e0 	strb	w0, [x23]
    aef4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aef8:	9116e3e1 	add	x1, sp, #0x5b8
    aefc:	52800020 	mov	w0, #0x1                   	// #1
    af00:	f902dfe2 	str	x2, [sp, #1464]
    af04:	f902e3f5 	str	x21, [sp, #1472]
    af08:	97ffe7b3 	bl	4dd4 <fwp_data.part.0.constprop.0>
    af0c:	91158283 	add	x3, x20, #0x560
    af10:	aa0003f5 	mov	x21, x0
    af14:	f949d861 	ldr	x1, [x3, #5040]
    af18:	f949ec60 	ldr	x0, [x3, #5080]
    af1c:	cb0102a1 	sub	x1, x21, x1
    af20:	eb00403f 	cmp	x1, x0, lsl #16
    af24:	54000322 	b.cs	af88 <f0+0x1638>  // b.hs, b.nlast
    af28:	d350fc22 	lsr	x2, x1, #16
    af2c:	f949fc63 	ldr	x3, [x3, #5112]
    af30:	8b020842 	add	x2, x2, x2, lsl #2
    af34:	d37df042 	lsl	x2, x2, #3
    af38:	8b020060 	add	x0, x3, x2
    af3c:	f9401017 	ldr	x23, [x0, #32]
    af40:	b4000257 	cbz	x23, af88 <f0+0x1638>
    af44:	38626862 	ldrb	w2, [x3, x2]
    af48:	7100085f 	cmp	w2, #0x2
    af4c:	540072c0 	b.eq	bda4 <f0+0x2454>  // b.none
    af50:	7100045f 	cmp	w2, #0x1
    af54:	540001a1 	b.ne	af88 <f0+0x1638>  // b.any
    af58:	29430002 	ldp	w2, w0, [x0, #24]
    af5c:	92403c21 	and	x1, x1, #0xffff
    af60:	9b027c21 	mul	x1, x1, x2
    af64:	d360fc21 	lsr	x1, x1, #32
    af68:	eb00003f 	cmp	x1, x0
    af6c:	540000e2 	b.cs	af88 <f0+0x1638>  // b.hs, b.nlast
    af70:	8b0102f7 	add	x23, x23, x1
    af74:	394002e0 	ldrb	w0, [x23]
    af78:	7103fc1f 	cmp	w0, #0xff
    af7c:	54007aa0 	b.eq	bed0 <f0+0x2580>  // b.none
    af80:	52800020 	mov	w0, #0x1                   	// #1
    af84:	390002e0 	strb	w0, [x23]
    af88:	911723e1 	add	x1, sp, #0x5c8
    af8c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    af90:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    af94:	52800020 	mov	w0, #0x1                   	// #1
    af98:	f902e7f7 	str	x23, [sp, #1480]
    af9c:	f902ebf5 	str	x21, [sp, #1488]
    afa0:	97ffe78d 	bl	4dd4 <fwp_data.part.0.constprop.0>
    afa4:	97ffe92c 	bl	5454 <fwp_rc_fresh>
    afa8:	aa0003e2 	mov	x2, x0
    afac:	911763e1 	add	x1, sp, #0x5d8
    afb0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    afb4:	52800020 	mov	w0, #0x1                   	// #1
    afb8:	f902eff5 	str	x21, [sp, #1496]
    afbc:	f902f3e2 	str	x2, [sp, #1504]
    afc0:	97ffe785 	bl	4dd4 <fwp_data.part.0.constprop.0>
    afc4:	97ffe924 	bl	5454 <fwp_rc_fresh>
    afc8:	aa0003e2 	mov	x2, x0
    afcc:	9117a3e1 	add	x1, sp, #0x5e8
    afd0:	52800020 	mov	w0, #0x1                   	// #1
    afd4:	f902f7f7 	str	x23, [sp, #1512]
    afd8:	f902fbe2 	str	x2, [sp, #1520]
    afdc:	97ffe77e 	bl	4dd4 <fwp_data.part.0.constprop.0>
    afe0:	97ffe91d 	bl	5454 <fwp_rc_fresh>
    afe4:	aa0003e2 	mov	x2, x0
    afe8:	9117e3e1 	add	x1, sp, #0x5f8
    afec:	52800020 	mov	w0, #0x1                   	// #1
    aff0:	f902fff5 	str	x21, [sp, #1528]
    aff4:	f90303e2 	str	x2, [sp, #1536]
    aff8:	97ffe777 	bl	4dd4 <fwp_data.part.0.constprop.0>
    affc:	91158283 	add	x3, x20, #0x560
    b000:	aa0003f5 	mov	x21, x0
    b004:	f949d861 	ldr	x1, [x3, #5040]
    b008:	f949ec60 	ldr	x0, [x3, #5080]
    b00c:	cb0102a1 	sub	x1, x21, x1
    b010:	eb00403f 	cmp	x1, x0, lsl #16
    b014:	54000322 	b.cs	b078 <f0+0x1728>  // b.hs, b.nlast
    b018:	d350fc22 	lsr	x2, x1, #16
    b01c:	f949fc63 	ldr	x3, [x3, #5112]
    b020:	8b020842 	add	x2, x2, x2, lsl #2
    b024:	d37df042 	lsl	x2, x2, #3
    b028:	8b020060 	add	x0, x3, x2
    b02c:	f9401017 	ldr	x23, [x0, #32]
    b030:	b4000257 	cbz	x23, b078 <f0+0x1728>
    b034:	38626862 	ldrb	w2, [x3, x2]
    b038:	7100085f 	cmp	w2, #0x2
    b03c:	54006ae0 	b.eq	bd98 <f0+0x2448>  // b.none
    b040:	7100045f 	cmp	w2, #0x1
    b044:	540001a1 	b.ne	b078 <f0+0x1728>  // b.any
    b048:	29430002 	ldp	w2, w0, [x0, #24]
    b04c:	92403c21 	and	x1, x1, #0xffff
    b050:	9b027c21 	mul	x1, x1, x2
    b054:	d360fc21 	lsr	x1, x1, #32
    b058:	eb00003f 	cmp	x1, x0
    b05c:	540000e2 	b.cs	b078 <f0+0x1728>  // b.hs, b.nlast
    b060:	8b0102f7 	add	x23, x23, x1
    b064:	394002e0 	ldrb	w0, [x23]
    b068:	7103fc1f 	cmp	w0, #0xff
    b06c:	54007380 	b.eq	bedc <f0+0x258c>  // b.none
    b070:	52800020 	mov	w0, #0x1                   	// #1
    b074:	390002e0 	strb	w0, [x23]
    b078:	911823e1 	add	x1, sp, #0x608
    b07c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b080:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b084:	52800020 	mov	w0, #0x1                   	// #1
    b088:	f90307f7 	str	x23, [sp, #1544]
    b08c:	f9030bf5 	str	x21, [sp, #1552]
    b090:	97ffe751 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b094:	97ffe8f0 	bl	5454 <fwp_rc_fresh>
    b098:	aa0003e2 	mov	x2, x0
    b09c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b0a0:	911863e1 	add	x1, sp, #0x618
    b0a4:	52800020 	mov	w0, #0x1                   	// #1
    b0a8:	f9030fe3 	str	x3, [sp, #1560]
    b0ac:	f90313e2 	str	x2, [sp, #1568]
    b0b0:	97ffe749 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b0b4:	97ffe8e8 	bl	5454 <fwp_rc_fresh>
    b0b8:	aa0003e2 	mov	x2, x0
    b0bc:	9118a3e1 	add	x1, sp, #0x628
    b0c0:	52800020 	mov	w0, #0x1                   	// #1
    b0c4:	f90317f7 	str	x23, [sp, #1576]
    b0c8:	f9031be2 	str	x2, [sp, #1584]
    b0cc:	97ffe742 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b0d0:	91158283 	add	x3, x20, #0x560
    b0d4:	aa0003f5 	mov	x21, x0
    b0d8:	f949d861 	ldr	x1, [x3, #5040]
    b0dc:	f949ec60 	ldr	x0, [x3, #5080]
    b0e0:	cb0102a1 	sub	x1, x21, x1
    b0e4:	eb00403f 	cmp	x1, x0, lsl #16
    b0e8:	54000322 	b.cs	b14c <f0+0x17fc>  // b.hs, b.nlast
    b0ec:	d350fc22 	lsr	x2, x1, #16
    b0f0:	f949fc63 	ldr	x3, [x3, #5112]
    b0f4:	8b020842 	add	x2, x2, x2, lsl #2
    b0f8:	d37df042 	lsl	x2, x2, #3
    b0fc:	8b020060 	add	x0, x3, x2
    b100:	f9401017 	ldr	x23, [x0, #32]
    b104:	b4000257 	cbz	x23, b14c <f0+0x17fc>
    b108:	38626862 	ldrb	w2, [x3, x2]
    b10c:	7100085f 	cmp	w2, #0x2
    b110:	540063e0 	b.eq	bd8c <f0+0x243c>  // b.none
    b114:	7100045f 	cmp	w2, #0x1
    b118:	540001a1 	b.ne	b14c <f0+0x17fc>  // b.any
    b11c:	29430002 	ldp	w2, w0, [x0, #24]
    b120:	92403c21 	and	x1, x1, #0xffff
    b124:	9b027c21 	mul	x1, x1, x2
    b128:	d360fc21 	lsr	x1, x1, #32
    b12c:	eb00003f 	cmp	x1, x0
    b130:	540000e2 	b.cs	b14c <f0+0x17fc>  // b.hs, b.nlast
    b134:	8b0102f7 	add	x23, x23, x1
    b138:	394002e0 	ldrb	w0, [x23]
    b13c:	7103fc1f 	cmp	w0, #0xff
    b140:	54006d40 	b.eq	bee8 <f0+0x2598>  // b.none
    b144:	52800020 	mov	w0, #0x1                   	// #1
    b148:	390002e0 	strb	w0, [x23]
    b14c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b150:	9118e3e1 	add	x1, sp, #0x638
    b154:	52800020 	mov	w0, #0x1                   	// #1
    b158:	f9031fe2 	str	x2, [sp, #1592]
    b15c:	f90323f5 	str	x21, [sp, #1600]
    b160:	97ffe71d 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b164:	91158283 	add	x3, x20, #0x560
    b168:	aa0003f5 	mov	x21, x0
    b16c:	f949d861 	ldr	x1, [x3, #5040]
    b170:	f949ec60 	ldr	x0, [x3, #5080]
    b174:	cb0102a1 	sub	x1, x21, x1
    b178:	eb00403f 	cmp	x1, x0, lsl #16
    b17c:	54000322 	b.cs	b1e0 <f0+0x1890>  // b.hs, b.nlast
    b180:	d350fc22 	lsr	x2, x1, #16
    b184:	f949fc63 	ldr	x3, [x3, #5112]
    b188:	8b020842 	add	x2, x2, x2, lsl #2
    b18c:	d37df042 	lsl	x2, x2, #3
    b190:	8b020060 	add	x0, x3, x2
    b194:	f9401017 	ldr	x23, [x0, #32]
    b198:	b4000257 	cbz	x23, b1e0 <f0+0x1890>
    b19c:	38626862 	ldrb	w2, [x3, x2]
    b1a0:	7100085f 	cmp	w2, #0x2
    b1a4:	54005ee0 	b.eq	bd80 <f0+0x2430>  // b.none
    b1a8:	7100045f 	cmp	w2, #0x1
    b1ac:	540001a1 	b.ne	b1e0 <f0+0x1890>  // b.any
    b1b0:	29430002 	ldp	w2, w0, [x0, #24]
    b1b4:	92403c21 	and	x1, x1, #0xffff
    b1b8:	9b027c21 	mul	x1, x1, x2
    b1bc:	d360fc21 	lsr	x1, x1, #32
    b1c0:	eb00003f 	cmp	x1, x0
    b1c4:	540000e2 	b.cs	b1e0 <f0+0x1890>  // b.hs, b.nlast
    b1c8:	8b0102f7 	add	x23, x23, x1
    b1cc:	394002e0 	ldrb	w0, [x23]
    b1d0:	7103fc1f 	cmp	w0, #0xff
    b1d4:	54006900 	b.eq	bef4 <f0+0x25a4>  // b.none
    b1d8:	52800020 	mov	w0, #0x1                   	// #1
    b1dc:	390002e0 	strb	w0, [x23]
    b1e0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b1e4:	911923e1 	add	x1, sp, #0x648
    b1e8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b1ec:	52800020 	mov	w0, #0x1                   	// #1
    b1f0:	f90327e2 	str	x2, [sp, #1608]
    b1f4:	f9032bf5 	str	x21, [sp, #1616]
    b1f8:	97ffe6f7 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b1fc:	97ffe896 	bl	5454 <fwp_rc_fresh>
    b200:	aa0003e2 	mov	x2, x0
    b204:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b208:	911963e1 	add	x1, sp, #0x658
    b20c:	52800020 	mov	w0, #0x1                   	// #1
    b210:	f9032fe3 	str	x3, [sp, #1624]
    b214:	f90333e2 	str	x2, [sp, #1632]
    b218:	97ffe6ef 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b21c:	91158283 	add	x3, x20, #0x560
    b220:	aa0003f5 	mov	x21, x0
    b224:	f949d861 	ldr	x1, [x3, #5040]
    b228:	f949ec60 	ldr	x0, [x3, #5080]
    b22c:	cb0102a1 	sub	x1, x21, x1
    b230:	eb00403f 	cmp	x1, x0, lsl #16
    b234:	54000322 	b.cs	b298 <f0+0x1948>  // b.hs, b.nlast
    b238:	d350fc22 	lsr	x2, x1, #16
    b23c:	f949fc63 	ldr	x3, [x3, #5112]
    b240:	8b020842 	add	x2, x2, x2, lsl #2
    b244:	d37df042 	lsl	x2, x2, #3
    b248:	8b020060 	add	x0, x3, x2
    b24c:	f9401017 	ldr	x23, [x0, #32]
    b250:	b4000257 	cbz	x23, b298 <f0+0x1948>
    b254:	38626862 	ldrb	w2, [x3, x2]
    b258:	7100085f 	cmp	w2, #0x2
    b25c:	540058c0 	b.eq	bd74 <f0+0x2424>  // b.none
    b260:	7100045f 	cmp	w2, #0x1
    b264:	540001a1 	b.ne	b298 <f0+0x1948>  // b.any
    b268:	29430002 	ldp	w2, w0, [x0, #24]
    b26c:	92403c21 	and	x1, x1, #0xffff
    b270:	9b027c21 	mul	x1, x1, x2
    b274:	d360fc21 	lsr	x1, x1, #32
    b278:	eb00003f 	cmp	x1, x0
    b27c:	540000e2 	b.cs	b298 <f0+0x1948>  // b.hs, b.nlast
    b280:	8b0102f7 	add	x23, x23, x1
    b284:	394002e0 	ldrb	w0, [x23]
    b288:	7103fc1f 	cmp	w0, #0xff
    b28c:	540063a0 	b.eq	bf00 <f0+0x25b0>  // b.none
    b290:	52800020 	mov	w0, #0x1                   	// #1
    b294:	390002e0 	strb	w0, [x23]
    b298:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b29c:	9119a3e1 	add	x1, sp, #0x668
    b2a0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b2a4:	52800020 	mov	w0, #0x1                   	// #1
    b2a8:	f90337e2 	str	x2, [sp, #1640]
    b2ac:	f9033bf5 	str	x21, [sp, #1648]
    b2b0:	97ffe6c9 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b2b4:	97ffe868 	bl	5454 <fwp_rc_fresh>
    b2b8:	aa0003e2 	mov	x2, x0
    b2bc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b2c0:	9119e3e1 	add	x1, sp, #0x678
    b2c4:	52800020 	mov	w0, #0x1                   	// #1
    b2c8:	f9033fe3 	str	x3, [sp, #1656]
    b2cc:	f90343e2 	str	x2, [sp, #1664]
    b2d0:	97ffe6c1 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b2d4:	91158283 	add	x3, x20, #0x560
    b2d8:	aa0003f5 	mov	x21, x0
    b2dc:	f949d861 	ldr	x1, [x3, #5040]
    b2e0:	f949ec60 	ldr	x0, [x3, #5080]
    b2e4:	cb0102a1 	sub	x1, x21, x1
    b2e8:	eb00403f 	cmp	x1, x0, lsl #16
    b2ec:	54000322 	b.cs	b350 <f0+0x1a00>  // b.hs, b.nlast
    b2f0:	d350fc22 	lsr	x2, x1, #16
    b2f4:	f949fc63 	ldr	x3, [x3, #5112]
    b2f8:	8b020842 	add	x2, x2, x2, lsl #2
    b2fc:	d37df042 	lsl	x2, x2, #3
    b300:	8b020060 	add	x0, x3, x2
    b304:	f9401017 	ldr	x23, [x0, #32]
    b308:	b4000257 	cbz	x23, b350 <f0+0x1a00>
    b30c:	38626862 	ldrb	w2, [x3, x2]
    b310:	7100085f 	cmp	w2, #0x2
    b314:	540052a0 	b.eq	bd68 <f0+0x2418>  // b.none
    b318:	7100045f 	cmp	w2, #0x1
    b31c:	540001a1 	b.ne	b350 <f0+0x1a00>  // b.any
    b320:	29430002 	ldp	w2, w0, [x0, #24]
    b324:	92403c21 	and	x1, x1, #0xffff
    b328:	9b027c21 	mul	x1, x1, x2
    b32c:	d360fc21 	lsr	x1, x1, #32
    b330:	eb00003f 	cmp	x1, x0
    b334:	540000e2 	b.cs	b350 <f0+0x1a00>  // b.hs, b.nlast
    b338:	8b0102f7 	add	x23, x23, x1
    b33c:	394002e0 	ldrb	w0, [x23]
    b340:	7103fc1f 	cmp	w0, #0xff
    b344:	54005e40 	b.eq	bf0c <f0+0x25bc>  // b.none
    b348:	52800020 	mov	w0, #0x1                   	// #1
    b34c:	390002e0 	strb	w0, [x23]
    b350:	911a23e1 	add	x1, sp, #0x688
    b354:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b358:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b35c:	52800020 	mov	w0, #0x1                   	// #1
    b360:	f90347f7 	str	x23, [sp, #1672]
    b364:	f9034bf5 	str	x21, [sp, #1680]
    b368:	97ffe69b 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b36c:	97ffe83a 	bl	5454 <fwp_rc_fresh>
    b370:	aa0003e2 	mov	x2, x0
    b374:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b378:	911a63e1 	add	x1, sp, #0x698
    b37c:	52800020 	mov	w0, #0x1                   	// #1
    b380:	f9034fe3 	str	x3, [sp, #1688]
    b384:	f90353e2 	str	x2, [sp, #1696]
    b388:	97ffe693 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b38c:	97ffe832 	bl	5454 <fwp_rc_fresh>
    b390:	aa0003e2 	mov	x2, x0
    b394:	911aa3e1 	add	x1, sp, #0x6a8
    b398:	52800020 	mov	w0, #0x1                   	// #1
    b39c:	f90357f7 	str	x23, [sp, #1704]
    b3a0:	f9035be2 	str	x2, [sp, #1712]
    b3a4:	97ffe68c 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b3a8:	91158283 	add	x3, x20, #0x560
    b3ac:	aa0003f5 	mov	x21, x0
    b3b0:	f949d861 	ldr	x1, [x3, #5040]
    b3b4:	f949ec60 	ldr	x0, [x3, #5080]
    b3b8:	cb0102a1 	sub	x1, x21, x1
    b3bc:	eb00403f 	cmp	x1, x0, lsl #16
    b3c0:	54000322 	b.cs	b424 <f0+0x1ad4>  // b.hs, b.nlast
    b3c4:	d350fc22 	lsr	x2, x1, #16
    b3c8:	f949fc63 	ldr	x3, [x3, #5112]
    b3cc:	8b020842 	add	x2, x2, x2, lsl #2
    b3d0:	d37df042 	lsl	x2, x2, #3
    b3d4:	8b020060 	add	x0, x3, x2
    b3d8:	f9401017 	ldr	x23, [x0, #32]
    b3dc:	b4000257 	cbz	x23, b424 <f0+0x1ad4>
    b3e0:	38626862 	ldrb	w2, [x3, x2]
    b3e4:	7100085f 	cmp	w2, #0x2
    b3e8:	54004ba0 	b.eq	bd5c <f0+0x240c>  // b.none
    b3ec:	7100045f 	cmp	w2, #0x1
    b3f0:	540001a1 	b.ne	b424 <f0+0x1ad4>  // b.any
    b3f4:	29430002 	ldp	w2, w0, [x0, #24]
    b3f8:	92403c21 	and	x1, x1, #0xffff
    b3fc:	9b027c21 	mul	x1, x1, x2
    b400:	d360fc21 	lsr	x1, x1, #32
    b404:	eb00003f 	cmp	x1, x0
    b408:	540000e2 	b.cs	b424 <f0+0x1ad4>  // b.hs, b.nlast
    b40c:	8b0102f7 	add	x23, x23, x1
    b410:	394002e0 	ldrb	w0, [x23]
    b414:	7103fc1f 	cmp	w0, #0xff
    b418:	54005800 	b.eq	bf18 <f0+0x25c8>  // b.none
    b41c:	52800020 	mov	w0, #0x1                   	// #1
    b420:	390002e0 	strb	w0, [x23]
    b424:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b428:	911ae3e1 	add	x1, sp, #0x6b8
    b42c:	52800020 	mov	w0, #0x1                   	// #1
    b430:	f9035fe2 	str	x2, [sp, #1720]
    b434:	f90363f5 	str	x21, [sp, #1728]
    b438:	97ffe667 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b43c:	91158283 	add	x3, x20, #0x560
    b440:	aa0003f5 	mov	x21, x0
    b444:	f949d861 	ldr	x1, [x3, #5040]
    b448:	f949ec60 	ldr	x0, [x3, #5080]
    b44c:	cb0102a1 	sub	x1, x21, x1
    b450:	eb00403f 	cmp	x1, x0, lsl #16
    b454:	54000322 	b.cs	b4b8 <f0+0x1b68>  // b.hs, b.nlast
    b458:	d350fc22 	lsr	x2, x1, #16
    b45c:	f949fc63 	ldr	x3, [x3, #5112]
    b460:	8b020842 	add	x2, x2, x2, lsl #2
    b464:	d37df042 	lsl	x2, x2, #3
    b468:	8b020060 	add	x0, x3, x2
    b46c:	f9401017 	ldr	x23, [x0, #32]
    b470:	b4000257 	cbz	x23, b4b8 <f0+0x1b68>
    b474:	38626862 	ldrb	w2, [x3, x2]
    b478:	7100085f 	cmp	w2, #0x2
    b47c:	540046a0 	b.eq	bd50 <f0+0x2400>  // b.none
    b480:	7100045f 	cmp	w2, #0x1
    b484:	540001a1 	b.ne	b4b8 <f0+0x1b68>  // b.any
    b488:	29430002 	ldp	w2, w0, [x0, #24]
    b48c:	92403c21 	and	x1, x1, #0xffff
    b490:	9b027c21 	mul	x1, x1, x2
    b494:	d360fc21 	lsr	x1, x1, #32
    b498:	eb00003f 	cmp	x1, x0
    b49c:	540000e2 	b.cs	b4b8 <f0+0x1b68>  // b.hs, b.nlast
    b4a0:	8b0102f7 	add	x23, x23, x1
    b4a4:	394002e0 	ldrb	w0, [x23]
    b4a8:	7103fc1f 	cmp	w0, #0xff
    b4ac:	540053c0 	b.eq	bf24 <f0+0x25d4>  // b.none
    b4b0:	52800020 	mov	w0, #0x1                   	// #1
    b4b4:	390002e0 	strb	w0, [x23]
    b4b8:	911b23e1 	add	x1, sp, #0x6c8
    b4bc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b4c0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b4c4:	52800020 	mov	w0, #0x1                   	// #1
    b4c8:	f90367f7 	str	x23, [sp, #1736]
    b4cc:	f9036bf5 	str	x21, [sp, #1744]
    b4d0:	97ffe641 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b4d4:	97ffe7e0 	bl	5454 <fwp_rc_fresh>
    b4d8:	aa0003e2 	mov	x2, x0
    b4dc:	911b63e1 	add	x1, sp, #0x6d8
    b4e0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b4e4:	52800020 	mov	w0, #0x1                   	// #1
    b4e8:	f9036ff5 	str	x21, [sp, #1752]
    b4ec:	f90373e2 	str	x2, [sp, #1760]
    b4f0:	97ffe639 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b4f4:	97ffe7d8 	bl	5454 <fwp_rc_fresh>
    b4f8:	aa0003e2 	mov	x2, x0
    b4fc:	911ba3e1 	add	x1, sp, #0x6e8
    b500:	52800020 	mov	w0, #0x1                   	// #1
    b504:	f90377f7 	str	x23, [sp, #1768]
    b508:	f9037be2 	str	x2, [sp, #1776]
    b50c:	97ffe632 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b510:	97ffe7d1 	bl	5454 <fwp_rc_fresh>
    b514:	aa0003e2 	mov	x2, x0
    b518:	911be3e1 	add	x1, sp, #0x6f8
    b51c:	52800020 	mov	w0, #0x1                   	// #1
    b520:	f9037ff5 	str	x21, [sp, #1784]
    b524:	f90383e2 	str	x2, [sp, #1792]
    b528:	97ffe62b 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b52c:	91158283 	add	x3, x20, #0x560
    b530:	aa0003f5 	mov	x21, x0
    b534:	f949d861 	ldr	x1, [x3, #5040]
    b538:	f949ec60 	ldr	x0, [x3, #5080]
    b53c:	cb0102a1 	sub	x1, x21, x1
    b540:	eb00403f 	cmp	x1, x0, lsl #16
    b544:	54000322 	b.cs	b5a8 <f0+0x1c58>  // b.hs, b.nlast
    b548:	d350fc22 	lsr	x2, x1, #16
    b54c:	f949fc63 	ldr	x3, [x3, #5112]
    b550:	8b020842 	add	x2, x2, x2, lsl #2
    b554:	d37df042 	lsl	x2, x2, #3
    b558:	8b020060 	add	x0, x3, x2
    b55c:	f9401017 	ldr	x23, [x0, #32]
    b560:	b4000257 	cbz	x23, b5a8 <f0+0x1c58>
    b564:	38626862 	ldrb	w2, [x3, x2]
    b568:	7100085f 	cmp	w2, #0x2
    b56c:	54003ec0 	b.eq	bd44 <f0+0x23f4>  // b.none
    b570:	7100045f 	cmp	w2, #0x1
    b574:	540001a1 	b.ne	b5a8 <f0+0x1c58>  // b.any
    b578:	29430002 	ldp	w2, w0, [x0, #24]
    b57c:	92403c21 	and	x1, x1, #0xffff
    b580:	9b027c21 	mul	x1, x1, x2
    b584:	d360fc21 	lsr	x1, x1, #32
    b588:	eb00003f 	cmp	x1, x0
    b58c:	540000e2 	b.cs	b5a8 <f0+0x1c58>  // b.hs, b.nlast
    b590:	8b0102f7 	add	x23, x23, x1
    b594:	394002e0 	ldrb	w0, [x23]
    b598:	7103fc1f 	cmp	w0, #0xff
    b59c:	54004ca0 	b.eq	bf30 <f0+0x25e0>  // b.none
    b5a0:	52800020 	mov	w0, #0x1                   	// #1
    b5a4:	390002e0 	strb	w0, [x23]
    b5a8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b5ac:	911c23e1 	add	x1, sp, #0x708
    b5b0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b5b4:	52800020 	mov	w0, #0x1                   	// #1
    b5b8:	f90387e2 	str	x2, [sp, #1800]
    b5bc:	f9038bf5 	str	x21, [sp, #1808]
    b5c0:	97ffe605 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b5c4:	91158283 	add	x3, x20, #0x560
    b5c8:	aa0003f5 	mov	x21, x0
    b5cc:	f949d861 	ldr	x1, [x3, #5040]
    b5d0:	f949ec60 	ldr	x0, [x3, #5080]
    b5d4:	cb0102a1 	sub	x1, x21, x1
    b5d8:	eb00403f 	cmp	x1, x0, lsl #16
    b5dc:	54000322 	b.cs	b640 <f0+0x1cf0>  // b.hs, b.nlast
    b5e0:	d350fc22 	lsr	x2, x1, #16
    b5e4:	f949fc63 	ldr	x3, [x3, #5112]
    b5e8:	8b020842 	add	x2, x2, x2, lsl #2
    b5ec:	d37df042 	lsl	x2, x2, #3
    b5f0:	8b020060 	add	x0, x3, x2
    b5f4:	f9401017 	ldr	x23, [x0, #32]
    b5f8:	b4000257 	cbz	x23, b640 <f0+0x1cf0>
    b5fc:	38626862 	ldrb	w2, [x3, x2]
    b600:	7100085f 	cmp	w2, #0x2
    b604:	540039a0 	b.eq	bd38 <f0+0x23e8>  // b.none
    b608:	7100045f 	cmp	w2, #0x1
    b60c:	540001a1 	b.ne	b640 <f0+0x1cf0>  // b.any
    b610:	29430002 	ldp	w2, w0, [x0, #24]
    b614:	92403c21 	and	x1, x1, #0xffff
    b618:	9b027c21 	mul	x1, x1, x2
    b61c:	d360fc21 	lsr	x1, x1, #32
    b620:	eb00003f 	cmp	x1, x0
    b624:	540000e2 	b.cs	b640 <f0+0x1cf0>  // b.hs, b.nlast
    b628:	8b0102f7 	add	x23, x23, x1
    b62c:	394002e0 	ldrb	w0, [x23]
    b630:	7103fc1f 	cmp	w0, #0xff
    b634:	54004840 	b.eq	bf3c <f0+0x25ec>  // b.none
    b638:	52800020 	mov	w0, #0x1                   	// #1
    b63c:	390002e0 	strb	w0, [x23]
    b640:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b644:	911c63e1 	add	x1, sp, #0x718
    b648:	52800020 	mov	w0, #0x1                   	// #1
    b64c:	f9038fe2 	str	x2, [sp, #1816]
    b650:	f90393f5 	str	x21, [sp, #1824]
    b654:	97ffe5e0 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b658:	91158283 	add	x3, x20, #0x560
    b65c:	aa0003f5 	mov	x21, x0
    b660:	f949d861 	ldr	x1, [x3, #5040]
    b664:	f949ec60 	ldr	x0, [x3, #5080]
    b668:	cb0102a1 	sub	x1, x21, x1
    b66c:	eb00403f 	cmp	x1, x0, lsl #16
    b670:	54000322 	b.cs	b6d4 <f0+0x1d84>  // b.hs, b.nlast
    b674:	d350fc22 	lsr	x2, x1, #16
    b678:	f949fc63 	ldr	x3, [x3, #5112]
    b67c:	8b020842 	add	x2, x2, x2, lsl #2
    b680:	d37df042 	lsl	x2, x2, #3
    b684:	8b020060 	add	x0, x3, x2
    b688:	f9401017 	ldr	x23, [x0, #32]
    b68c:	b4000257 	cbz	x23, b6d4 <f0+0x1d84>
    b690:	38626862 	ldrb	w2, [x3, x2]
    b694:	7100085f 	cmp	w2, #0x2
    b698:	540034a0 	b.eq	bd2c <f0+0x23dc>  // b.none
    b69c:	7100045f 	cmp	w2, #0x1
    b6a0:	540001a1 	b.ne	b6d4 <f0+0x1d84>  // b.any
    b6a4:	29430002 	ldp	w2, w0, [x0, #24]
    b6a8:	92403c21 	and	x1, x1, #0xffff
    b6ac:	9b027c21 	mul	x1, x1, x2
    b6b0:	d360fc21 	lsr	x1, x1, #32
    b6b4:	eb00003f 	cmp	x1, x0
    b6b8:	540000e2 	b.cs	b6d4 <f0+0x1d84>  // b.hs, b.nlast
    b6bc:	8b0102f7 	add	x23, x23, x1
    b6c0:	394002e0 	ldrb	w0, [x23]
    b6c4:	7103fc1f 	cmp	w0, #0xff
    b6c8:	54004400 	b.eq	bf48 <f0+0x25f8>  // b.none
    b6cc:	52800020 	mov	w0, #0x1                   	// #1
    b6d0:	390002e0 	strb	w0, [x23]
    b6d4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b6d8:	911ca3e1 	add	x1, sp, #0x728
    b6dc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b6e0:	52800020 	mov	w0, #0x1                   	// #1
    b6e4:	f90397e2 	str	x2, [sp, #1832]
    b6e8:	f9039bf5 	str	x21, [sp, #1840]
    b6ec:	97ffe5ba 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b6f0:	91158283 	add	x3, x20, #0x560
    b6f4:	aa0003f5 	mov	x21, x0
    b6f8:	f949d861 	ldr	x1, [x3, #5040]
    b6fc:	f949ec60 	ldr	x0, [x3, #5080]
    b700:	cb0102a1 	sub	x1, x21, x1
    b704:	eb00403f 	cmp	x1, x0, lsl #16
    b708:	54000322 	b.cs	b76c <f0+0x1e1c>  // b.hs, b.nlast
    b70c:	d350fc22 	lsr	x2, x1, #16
    b710:	f949fc63 	ldr	x3, [x3, #5112]
    b714:	8b020842 	add	x2, x2, x2, lsl #2
    b718:	d37df042 	lsl	x2, x2, #3
    b71c:	8b020060 	add	x0, x3, x2
    b720:	f9401017 	ldr	x23, [x0, #32]
    b724:	b4000257 	cbz	x23, b76c <f0+0x1e1c>
    b728:	38626862 	ldrb	w2, [x3, x2]
    b72c:	7100085f 	cmp	w2, #0x2
    b730:	54002f80 	b.eq	bd20 <f0+0x23d0>  // b.none
    b734:	7100045f 	cmp	w2, #0x1
    b738:	540001a1 	b.ne	b76c <f0+0x1e1c>  // b.any
    b73c:	29430002 	ldp	w2, w0, [x0, #24]
    b740:	92403c21 	and	x1, x1, #0xffff
    b744:	9b027c21 	mul	x1, x1, x2
    b748:	d360fc21 	lsr	x1, x1, #32
    b74c:	eb00003f 	cmp	x1, x0
    b750:	540000e2 	b.cs	b76c <f0+0x1e1c>  // b.hs, b.nlast
    b754:	8b0102f7 	add	x23, x23, x1
    b758:	394002e0 	ldrb	w0, [x23]
    b75c:	7103fc1f 	cmp	w0, #0xff
    b760:	54003fa0 	b.eq	bf54 <f0+0x2604>  // b.none
    b764:	52800020 	mov	w0, #0x1                   	// #1
    b768:	390002e0 	strb	w0, [x23]
    b76c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b770:	911ce3e1 	add	x1, sp, #0x738
    b774:	52800020 	mov	w0, #0x1                   	// #1
    b778:	f9039fe2 	str	x2, [sp, #1848]
    b77c:	f903a3f5 	str	x21, [sp, #1856]
    b780:	97ffe595 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b784:	91158283 	add	x3, x20, #0x560
    b788:	aa0003f5 	mov	x21, x0
    b78c:	f949d861 	ldr	x1, [x3, #5040]
    b790:	f949ec60 	ldr	x0, [x3, #5080]
    b794:	cb0102a1 	sub	x1, x21, x1
    b798:	eb00403f 	cmp	x1, x0, lsl #16
    b79c:	54000322 	b.cs	b800 <f0+0x1eb0>  // b.hs, b.nlast
    b7a0:	d350fc22 	lsr	x2, x1, #16
    b7a4:	f949fc63 	ldr	x3, [x3, #5112]
    b7a8:	8b020842 	add	x2, x2, x2, lsl #2
    b7ac:	d37df042 	lsl	x2, x2, #3
    b7b0:	8b020060 	add	x0, x3, x2
    b7b4:	f9401017 	ldr	x23, [x0, #32]
    b7b8:	b4000257 	cbz	x23, b800 <f0+0x1eb0>
    b7bc:	38626862 	ldrb	w2, [x3, x2]
    b7c0:	7100085f 	cmp	w2, #0x2
    b7c4:	54002a80 	b.eq	bd14 <f0+0x23c4>  // b.none
    b7c8:	7100045f 	cmp	w2, #0x1
    b7cc:	540001a1 	b.ne	b800 <f0+0x1eb0>  // b.any
    b7d0:	29430002 	ldp	w2, w0, [x0, #24]
    b7d4:	92403c21 	and	x1, x1, #0xffff
    b7d8:	9b027c21 	mul	x1, x1, x2
    b7dc:	d360fc21 	lsr	x1, x1, #32
    b7e0:	eb00003f 	cmp	x1, x0
    b7e4:	540000e2 	b.cs	b800 <f0+0x1eb0>  // b.hs, b.nlast
    b7e8:	8b0102f7 	add	x23, x23, x1
    b7ec:	394002e0 	ldrb	w0, [x23]
    b7f0:	7103fc1f 	cmp	w0, #0xff
    b7f4:	54003b60 	b.eq	bf60 <f0+0x2610>  // b.none
    b7f8:	52800020 	mov	w0, #0x1                   	// #1
    b7fc:	390002e0 	strb	w0, [x23]
    b800:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b804:	911d23e1 	add	x1, sp, #0x748
    b808:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b80c:	52800020 	mov	w0, #0x1                   	// #1
    b810:	f903a7e2 	str	x2, [sp, #1864]
    b814:	f903abf5 	str	x21, [sp, #1872]
    b818:	97ffe56f 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b81c:	97ffe70e 	bl	5454 <fwp_rc_fresh>
    b820:	aa0003e2 	mov	x2, x0
    b824:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b828:	911d63e1 	add	x1, sp, #0x758
    b82c:	52800020 	mov	w0, #0x1                   	// #1
    b830:	f903afe3 	str	x3, [sp, #1880]
    b834:	f903b3e2 	str	x2, [sp, #1888]
    b838:	97ffe567 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b83c:	91158283 	add	x3, x20, #0x560
    b840:	aa0003f5 	mov	x21, x0
    b844:	f949d861 	ldr	x1, [x3, #5040]
    b848:	f949ec60 	ldr	x0, [x3, #5080]
    b84c:	cb0102a1 	sub	x1, x21, x1
    b850:	eb00403f 	cmp	x1, x0, lsl #16
    b854:	54000322 	b.cs	b8b8 <f0+0x1f68>  // b.hs, b.nlast
    b858:	d350fc22 	lsr	x2, x1, #16
    b85c:	f949fc63 	ldr	x3, [x3, #5112]
    b860:	8b020842 	add	x2, x2, x2, lsl #2
    b864:	d37df042 	lsl	x2, x2, #3
    b868:	8b020060 	add	x0, x3, x2
    b86c:	f9401017 	ldr	x23, [x0, #32]
    b870:	b4000257 	cbz	x23, b8b8 <f0+0x1f68>
    b874:	38626862 	ldrb	w2, [x3, x2]
    b878:	7100085f 	cmp	w2, #0x2
    b87c:	54002460 	b.eq	bd08 <f0+0x23b8>  // b.none
    b880:	7100045f 	cmp	w2, #0x1
    b884:	540001a1 	b.ne	b8b8 <f0+0x1f68>  // b.any
    b888:	29430002 	ldp	w2, w0, [x0, #24]
    b88c:	92403c21 	and	x1, x1, #0xffff
    b890:	9b027c21 	mul	x1, x1, x2
    b894:	d360fc21 	lsr	x1, x1, #32
    b898:	eb00003f 	cmp	x1, x0
    b89c:	540000e2 	b.cs	b8b8 <f0+0x1f68>  // b.hs, b.nlast
    b8a0:	8b0102f7 	add	x23, x23, x1
    b8a4:	394002e0 	ldrb	w0, [x23]
    b8a8:	7103fc1f 	cmp	w0, #0xff
    b8ac:	54003600 	b.eq	bf6c <f0+0x261c>  // b.none
    b8b0:	52800020 	mov	w0, #0x1                   	// #1
    b8b4:	390002e0 	strb	w0, [x23]
    b8b8:	911da3e1 	add	x1, sp, #0x768
    b8bc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b8c0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b8c4:	52800020 	mov	w0, #0x1                   	// #1
    b8c8:	f903b7f7 	str	x23, [sp, #1896]
    b8cc:	f903bbf5 	str	x21, [sp, #1904]
    b8d0:	97ffe541 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b8d4:	97ffe6e0 	bl	5454 <fwp_rc_fresh>
    b8d8:	aa0003e2 	mov	x2, x0
    b8dc:	911de3e1 	add	x1, sp, #0x778
    b8e0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b8e4:	52800020 	mov	w0, #0x1                   	// #1
    b8e8:	f903bff5 	str	x21, [sp, #1912]
    b8ec:	f903c3e2 	str	x2, [sp, #1920]
    b8f0:	97ffe539 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b8f4:	97ffe6d8 	bl	5454 <fwp_rc_fresh>
    b8f8:	aa0003e2 	mov	x2, x0
    b8fc:	911e23e1 	add	x1, sp, #0x788
    b900:	52800020 	mov	w0, #0x1                   	// #1
    b904:	f903c7f7 	str	x23, [sp, #1928]
    b908:	f903cbe2 	str	x2, [sp, #1936]
    b90c:	97ffe532 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b910:	97ffe6d1 	bl	5454 <fwp_rc_fresh>
    b914:	aa0003e2 	mov	x2, x0
    b918:	911e63e1 	add	x1, sp, #0x798
    b91c:	52800020 	mov	w0, #0x1                   	// #1
    b920:	f903cff5 	str	x21, [sp, #1944]
    b924:	f903d3e2 	str	x2, [sp, #1952]
    b928:	97ffe52b 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b92c:	91158283 	add	x3, x20, #0x560
    b930:	aa0003f5 	mov	x21, x0
    b934:	f949d861 	ldr	x1, [x3, #5040]
    b938:	f949ec60 	ldr	x0, [x3, #5080]
    b93c:	cb0102a1 	sub	x1, x21, x1
    b940:	eb00403f 	cmp	x1, x0, lsl #16
    b944:	54000322 	b.cs	b9a8 <f0+0x2058>  // b.hs, b.nlast
    b948:	d350fc22 	lsr	x2, x1, #16
    b94c:	f949fc63 	ldr	x3, [x3, #5112]
    b950:	8b020842 	add	x2, x2, x2, lsl #2
    b954:	d37df042 	lsl	x2, x2, #3
    b958:	8b020060 	add	x0, x3, x2
    b95c:	f9401017 	ldr	x23, [x0, #32]
    b960:	b4000257 	cbz	x23, b9a8 <f0+0x2058>
    b964:	38626862 	ldrb	w2, [x3, x2]
    b968:	7100085f 	cmp	w2, #0x2
    b96c:	54001c80 	b.eq	bcfc <f0+0x23ac>  // b.none
    b970:	7100045f 	cmp	w2, #0x1
    b974:	540001a1 	b.ne	b9a8 <f0+0x2058>  // b.any
    b978:	29430002 	ldp	w2, w0, [x0, #24]
    b97c:	92403c21 	and	x1, x1, #0xffff
    b980:	9b027c21 	mul	x1, x1, x2
    b984:	d360fc21 	lsr	x1, x1, #32
    b988:	eb00003f 	cmp	x1, x0
    b98c:	540000e2 	b.cs	b9a8 <f0+0x2058>  // b.hs, b.nlast
    b990:	8b0102f7 	add	x23, x23, x1
    b994:	394002e0 	ldrb	w0, [x23]
    b998:	7103fc1f 	cmp	w0, #0xff
    b99c:	54002ee0 	b.eq	bf78 <f0+0x2628>  // b.none
    b9a0:	52800020 	mov	w0, #0x1                   	// #1
    b9a4:	390002e0 	strb	w0, [x23]
    b9a8:	911ea3e1 	add	x1, sp, #0x7a8
    b9ac:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b9b0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b9b4:	52800020 	mov	w0, #0x1                   	// #1
    b9b8:	f903d7f7 	str	x23, [sp, #1960]
    b9bc:	91158294 	add	x20, x20, #0x560
    b9c0:	f903dbf5 	str	x21, [sp, #1968]
    b9c4:	97ffe504 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b9c8:	97ffe6a3 	bl	5454 <fwp_rc_fresh>
    b9cc:	aa0003e2 	mov	x2, x0
    b9d0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b9d4:	911ee3e1 	add	x1, sp, #0x7b8
    b9d8:	52800020 	mov	w0, #0x1                   	// #1
    b9dc:	f903dfe3 	str	x3, [sp, #1976]
    b9e0:	f903e3e2 	str	x2, [sp, #1984]
    b9e4:	97ffe4fc 	bl	4dd4 <fwp_data.part.0.constprop.0>
    b9e8:	97ffe69b 	bl	5454 <fwp_rc_fresh>
    b9ec:	aa0003e2 	mov	x2, x0
    b9f0:	911f23e1 	add	x1, sp, #0x7c8
    b9f4:	52800020 	mov	w0, #0x1                   	// #1
    b9f8:	f903e7f7 	str	x23, [sp, #1992]
    b9fc:	f903ebe2 	str	x2, [sp, #2000]
    ba00:	97ffe4f5 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ba04:	f949da81 	ldr	x1, [x20, #5040]
    ba08:	aa0003f7 	mov	x23, x0
    ba0c:	f949ee80 	ldr	x0, [x20, #5080]
    ba10:	cb0102e1 	sub	x1, x23, x1
    ba14:	eb00403f 	cmp	x1, x0, lsl #16
    ba18:	54000322 	b.cs	ba7c <f0+0x212c>  // b.hs, b.nlast
    ba1c:	d350fc22 	lsr	x2, x1, #16
    ba20:	f949fe83 	ldr	x3, [x20, #5112]
    ba24:	8b020842 	add	x2, x2, x2, lsl #2
    ba28:	d37df042 	lsl	x2, x2, #3
    ba2c:	8b020060 	add	x0, x3, x2
    ba30:	f9401014 	ldr	x20, [x0, #32]
    ba34:	b4000254 	cbz	x20, ba7c <f0+0x212c>
    ba38:	38626862 	ldrb	w2, [x3, x2]
    ba3c:	7100085f 	cmp	w2, #0x2
    ba40:	54001580 	b.eq	bcf0 <f0+0x23a0>  // b.none
    ba44:	7100045f 	cmp	w2, #0x1
    ba48:	540001a1 	b.ne	ba7c <f0+0x212c>  // b.any
    ba4c:	29430002 	ldp	w2, w0, [x0, #24]
    ba50:	92403c21 	and	x1, x1, #0xffff
    ba54:	9b027c21 	mul	x1, x1, x2
    ba58:	d360fc21 	lsr	x1, x1, #32
    ba5c:	eb00003f 	cmp	x1, x0
    ba60:	540000e2 	b.cs	ba7c <f0+0x212c>  // b.hs, b.nlast
    ba64:	8b010294 	add	x20, x20, x1
    ba68:	39400280 	ldrb	w0, [x20]
    ba6c:	7103fc1f 	cmp	w0, #0xff
    ba70:	54001a00 	b.eq	bdb0 <f0+0x2460>  // b.none
    ba74:	52800020 	mov	w0, #0x1                   	// #1
    ba78:	39000280 	strb	w0, [x20]
    ba7c:	911f63e1 	add	x1, sp, #0x7d8
    ba80:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ba84:	52800020 	mov	w0, #0x1                   	// #1
    ba88:	f903eff5 	str	x21, [sp, #2008]
    ba8c:	f903f3f7 	str	x23, [sp, #2016]
    ba90:	97ffe4d1 	bl	4dd4 <fwp_data.part.0.constprop.0>
    ba94:	97ffe670 	bl	5454 <fwp_rc_fresh>
    ba98:	aa0003e2 	mov	x2, x0
    ba9c:	911fa3e1 	add	x1, sp, #0x7e8
    baa0:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    baa4:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    baa8:	52800020 	mov	w0, #0x1                   	// #1
    baac:	f903f7f4 	str	x20, [sp, #2024]
    bab0:	f903fbe2 	str	x2, [sp, #2032]
    bab4:	97ffe4c8 	bl	4dd4 <fwp_data.part.0.constprop.0>
    bab8:	97ffe667 	bl	5454 <fwp_rc_fresh>
    babc:	aa0003e2 	mov	x2, x0
    bac0:	911fe3e1 	add	x1, sp, #0x7f8
    bac4:	52800020 	mov	w0, #0x1                   	// #1
    bac8:	f903fff5 	str	x21, [sp, #2040]
    bacc:	f90403e2 	str	x2, [sp, #2048]
    bad0:	97ffe4c1 	bl	4dd4 <fwp_data.part.0.constprop.0>
    bad4:	97ffe660 	bl	5454 <fwp_rc_fresh>
    bad8:	aa0003e2 	mov	x2, x0
    badc:	912023e1 	add	x1, sp, #0x808
    bae0:	52800020 	mov	w0, #0x1                   	// #1
    bae4:	f90407f4 	str	x20, [sp, #2056]
    bae8:	f9040be2 	str	x2, [sp, #2064]
    baec:	97ffe4ba 	bl	4dd4 <fwp_data.part.0.constprop.0>
    baf0:	97ffe659 	bl	5454 <fwp_rc_fresh>
    baf4:	aa0003e2 	mov	x2, x0
    baf8:	912063e1 	add	x1, sp, #0x818
    bafc:	52800020 	mov	w0, #0x1                   	// #1
    bb00:	f9040ff5 	str	x21, [sp, #2072]
    bb04:	f90413e2 	str	x2, [sp, #2080]
    bb08:	97ffe4b3 	bl	4dd4 <fwp_data.part.0.constprop.0>
    bb0c:	97ffe652 	bl	5454 <fwp_rc_fresh>
    bb10:	aa0003e2 	mov	x2, x0
    bb14:	9120a3e1 	add	x1, sp, #0x828
    bb18:	52800020 	mov	w0, #0x1                   	// #1
    bb1c:	f90417f4 	str	x20, [sp, #2088]
    bb20:	f9041be2 	str	x2, [sp, #2096]
    bb24:	97ffe4ac 	bl	4dd4 <fwp_data.part.0.constprop.0>
    bb28:	97ffe64b 	bl	5454 <fwp_rc_fresh>
    bb2c:	aa0003e2 	mov	x2, x0
    bb30:	9120e3e1 	add	x1, sp, #0x838
    bb34:	52800020 	mov	w0, #0x1                   	// #1
    bb38:	f9041ff5 	str	x21, [sp, #2104]
    bb3c:	f90423e2 	str	x2, [sp, #2112]
    bb40:	97ffe4a5 	bl	4dd4 <fwp_data.part.0.constprop.0>
    bb44:	97ffe644 	bl	5454 <fwp_rc_fresh>
    bb48:	aa0003e2 	mov	x2, x0
    bb4c:	aa1603e1 	mov	x1, x22
    bb50:	52800020 	mov	w0, #0x1                   	// #1
    bb54:	f90427f4 	str	x20, [sp, #2120]
    bb58:	f9042be2 	str	x2, [sp, #2128]
    bb5c:	97ffe49e 	bl	4dd4 <fwp_data.part.0.constprop.0>
    bb60:	97ffe63d 	bl	5454 <fwp_rc_fresh>
    bb64:	aa0003f5 	mov	x21, x0
    bb68:	aa1303e1 	mov	x1, x19
    bb6c:	97fff0d1 	bl	7eb0 <fwp_hof0.constprop.0>
    bb70:	aa0003f4 	mov	x20, x0
    bb74:	aa1503e0 	mov	x0, x21
    bb78:	97ffe792 	bl	59c0 <fwp_drop0>
    bb7c:	aa1303e0 	mov	x0, x19
    bb80:	97ffe790 	bl	59c0 <fwp_drop0>
    bb84:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bb88:	f947f400 	ldr	x0, [x0, #4072]
    bb8c:	f9442fe2 	ldr	x2, [sp, #2136]
    bb90:	f9400001 	ldr	x1, [x0]
    bb94:	eb010042 	subs	x2, x2, x1
    bb98:	d2800001 	mov	x1, #0x0                   	// #0
    bb9c:	54001f41 	b.ne	bf84 <f0+0x2634>  // b.any
    bba0:	912183ff 	add	sp, sp, #0x860
    bba4:	aa1403e0 	mov	x0, x20
    bba8:	a94153f3 	ldp	x19, x20, [sp, #16]
    bbac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    bbb0:	a94363f7 	ldp	x23, x24, [sp, #48]
    bbb4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    bbb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    bbbc:	a8c67bfd 	ldp	x29, x30, [sp], #96
    bbc0:	d65f03c0 	ret
    bbc4:	aa1b03e0 	mov	x0, x27
    bbc8:	97ffe27e 	bl	45c0 <fwp_rc_forget_slot>
    bbcc:	17fff7a9 	b	9a70 <f0+0x120>
    bbd0:	72003c5f 	tst	w2, #0xffff
    bbd4:	54fef501 	b.ne	9a74 <f0+0x124>  // b.any
    bbd8:	17fff7a3 	b	9a64 <f0+0x114>
    bbdc:	72003c3f 	tst	w1, #0xffff
    bbe0:	54ff98a1 	b.ne	aef4 <f0+0x15a4>  // b.any
    bbe4:	17fffcbf 	b	aee0 <f0+0x1590>
    bbe8:	72003c3f 	tst	w1, #0xffff
    bbec:	54ff91a1 	b.ne	ae20 <f0+0x14d0>  // b.any
    bbf0:	17fffc87 	b	ae0c <f0+0x14bc>
    bbf4:	72003c3f 	tst	w1, #0xffff
    bbf8:	54ff8b81 	b.ne	ad68 <f0+0x1418>  // b.any
    bbfc:	17fffc56 	b	ad54 <f0+0x1404>
    bc00:	72003c3f 	tst	w1, #0xffff
    bc04:	54ff8561 	b.ne	acb0 <f0+0x1360>  // b.any
    bc08:	17fffc25 	b	ac9c <f0+0x134c>
    bc0c:	72003c3f 	tst	w1, #0xffff
    bc10:	54ff8061 	b.ne	ac1c <f0+0x12cc>  // b.any
    bc14:	17fffbfd 	b	ac08 <f0+0x12b8>
    bc18:	72003c3f 	tst	w1, #0xffff
    bc1c:	54ff7961 	b.ne	ab48 <f0+0x11f8>  // b.any
    bc20:	17fffbc5 	b	ab34 <f0+0x11e4>
    bc24:	72003c3f 	tst	w1, #0xffff
    bc28:	54ff7341 	b.ne	aa90 <f0+0x1140>  // b.any
    bc2c:	17fffb94 	b	aa7c <f0+0x112c>
    bc30:	72003c3f 	tst	w1, #0xffff
    bc34:	54ff6d21 	b.ne	a9d8 <f0+0x1088>  // b.any
    bc38:	17fffb63 	b	a9c4 <f0+0x1074>
    bc3c:	72003c3f 	tst	w1, #0xffff
    bc40:	54ff1021 	b.ne	9e44 <f0+0x4f4>  // b.any
    bc44:	17fff87b 	b	9e30 <f0+0x4e0>
    bc48:	72003c3f 	tst	w1, #0xffff
    bc4c:	54ff0b41 	b.ne	9db4 <f0+0x464>  // b.any
    bc50:	17fff854 	b	9da0 <f0+0x450>
    bc54:	72003c3f 	tst	w1, #0xffff
    bc58:	54fef661 	b.ne	9b24 <f0+0x1d4>  // b.any
    bc5c:	17fff7ad 	b	9b10 <f0+0x1c0>
    bc60:	72003c3f 	tst	w1, #0xffff
    bc64:	54ff28c1 	b.ne	a17c <f0+0x82c>  // b.any
    bc68:	17fff940 	b	a168 <f0+0x818>
    bc6c:	72003c3f 	tst	w1, #0xffff
    bc70:	54ff20e1 	b.ne	a08c <f0+0x73c>  // b.any
    bc74:	17fff901 	b	a078 <f0+0x728>
    bc78:	72003c3f 	tst	w1, #0xffff
    bc7c:	54ff1be1 	b.ne	9ff8 <f0+0x6a8>  // b.any
    bc80:	17fff8d9 	b	9fe4 <f0+0x694>
    bc84:	72003c3f 	tst	w1, #0xffff
    bc88:	54ff14e1 	b.ne	9f24 <f0+0x5d4>  // b.any
    bc8c:	17fff8a1 	b	9f10 <f0+0x5c0>
    bc90:	72003c3f 	tst	w1, #0xffff
    bc94:	54ff6581 	b.ne	a944 <f0+0xff4>  // b.any
    bc98:	17fffb26 	b	a930 <f0+0xfe0>
    bc9c:	72003c3f 	tst	w1, #0xffff
    bca0:	54ff5b01 	b.ne	a800 <f0+0xeb0>  // b.any
    bca4:	17fffad2 	b	a7ec <f0+0xe9c>
    bca8:	72003c3f 	tst	w1, #0xffff
    bcac:	54ff54e1 	b.ne	a748 <f0+0xdf8>  // b.any
    bcb0:	17fffaa1 	b	a734 <f0+0xde4>
    bcb4:	72003c3f 	tst	w1, #0xffff
    bcb8:	54ff4ec1 	b.ne	a690 <f0+0xd40>  // b.any
    bcbc:	17fffa70 	b	a67c <f0+0xd2c>
    bcc0:	72003c3f 	tst	w1, #0xffff
    bcc4:	54ff3fe1 	b.ne	a4c0 <f0+0xb70>  // b.any
    bcc8:	17fff9f9 	b	a4ac <f0+0xb5c>
    bccc:	72003c3f 	tst	w1, #0xffff
    bcd0:	54ff3ae1 	b.ne	a42c <f0+0xadc>  // b.any
    bcd4:	17fff9d1 	b	a418 <f0+0xac8>
    bcd8:	72003c3f 	tst	w1, #0xffff
    bcdc:	54ff35c1 	b.ne	a394 <f0+0xa44>  // b.any
    bce0:	17fff9a8 	b	a380 <f0+0xa30>
    bce4:	72003c3f 	tst	w1, #0xffff
    bce8:	54ff2fa1 	b.ne	a2dc <f0+0x98c>  // b.any
    bcec:	17fff977 	b	a2c8 <f0+0x978>
    bcf0:	72003c3f 	tst	w1, #0xffff
    bcf4:	54ffec41 	b.ne	ba7c <f0+0x212c>  // b.any
    bcf8:	17ffff5c 	b	ba68 <f0+0x2118>
    bcfc:	72003c3f 	tst	w1, #0xffff
    bd00:	54ffe541 	b.ne	b9a8 <f0+0x2058>  // b.any
    bd04:	17ffff24 	b	b994 <f0+0x2044>
    bd08:	72003c3f 	tst	w1, #0xffff
    bd0c:	54ffdd61 	b.ne	b8b8 <f0+0x1f68>  // b.any
    bd10:	17fffee5 	b	b8a4 <f0+0x1f54>
    bd14:	72003c3f 	tst	w1, #0xffff
    bd18:	54ffd741 	b.ne	b800 <f0+0x1eb0>  // b.any
    bd1c:	17fffeb4 	b	b7ec <f0+0x1e9c>
    bd20:	72003c3f 	tst	w1, #0xffff
    bd24:	54ffd241 	b.ne	b76c <f0+0x1e1c>  // b.any
    bd28:	17fffe8c 	b	b758 <f0+0x1e08>
    bd2c:	72003c3f 	tst	w1, #0xffff
    bd30:	54ffcd21 	b.ne	b6d4 <f0+0x1d84>  // b.any
    bd34:	17fffe63 	b	b6c0 <f0+0x1d70>
    bd38:	72003c3f 	tst	w1, #0xffff
    bd3c:	54ffc821 	b.ne	b640 <f0+0x1cf0>  // b.any
    bd40:	17fffe3b 	b	b62c <f0+0x1cdc>
    bd44:	72003c3f 	tst	w1, #0xffff
    bd48:	54ffc301 	b.ne	b5a8 <f0+0x1c58>  // b.any
    bd4c:	17fffe12 	b	b594 <f0+0x1c44>
    bd50:	72003c3f 	tst	w1, #0xffff
    bd54:	54ffbb21 	b.ne	b4b8 <f0+0x1b68>  // b.any
    bd58:	17fffdd3 	b	b4a4 <f0+0x1b54>
    bd5c:	72003c3f 	tst	w1, #0xffff
    bd60:	54ffb621 	b.ne	b424 <f0+0x1ad4>  // b.any
    bd64:	17fffdab 	b	b410 <f0+0x1ac0>
    bd68:	72003c3f 	tst	w1, #0xffff
    bd6c:	54ffaf21 	b.ne	b350 <f0+0x1a00>  // b.any
    bd70:	17fffd73 	b	b33c <f0+0x19ec>
    bd74:	72003c3f 	tst	w1, #0xffff
    bd78:	54ffa901 	b.ne	b298 <f0+0x1948>  // b.any
    bd7c:	17fffd42 	b	b284 <f0+0x1934>
    bd80:	72003c3f 	tst	w1, #0xffff
    bd84:	54ffa2e1 	b.ne	b1e0 <f0+0x1890>  // b.any
    bd88:	17fffd11 	b	b1cc <f0+0x187c>
    bd8c:	72003c3f 	tst	w1, #0xffff
    bd90:	54ff9de1 	b.ne	b14c <f0+0x17fc>  // b.any
    bd94:	17fffce9 	b	b138 <f0+0x17e8>
    bd98:	72003c3f 	tst	w1, #0xffff
    bd9c:	54ff96e1 	b.ne	b078 <f0+0x1728>  // b.any
    bda0:	17fffcb1 	b	b064 <f0+0x1714>
    bda4:	72003c3f 	tst	w1, #0xffff
    bda8:	54ff8f01 	b.ne	af88 <f0+0x1638>  // b.any
    bdac:	17fffc72 	b	af74 <f0+0x1624>
    bdb0:	aa1403e0 	mov	x0, x20
    bdb4:	97ffe203 	bl	45c0 <fwp_rc_forget_slot>
    bdb8:	17ffff2f 	b	ba74 <f0+0x2124>
    bdbc:	aa1703e0 	mov	x0, x23
    bdc0:	97ffe200 	bl	45c0 <fwp_rc_forget_slot>
    bdc4:	17fff756 	b	9b1c <f0+0x1cc>
    bdc8:	aa1703e0 	mov	x0, x23
    bdcc:	97ffe1fd 	bl	45c0 <fwp_rc_forget_slot>
    bdd0:	17fff7f7 	b	9dac <f0+0x45c>
    bdd4:	aa1703e0 	mov	x0, x23
    bdd8:	97ffe1fa 	bl	45c0 <fwp_rc_forget_slot>
    bddc:	17fff818 	b	9e3c <f0+0x4ec>
    bde0:	aa1703e0 	mov	x0, x23
    bde4:	97ffe1f7 	bl	45c0 <fwp_rc_forget_slot>
    bde8:	17fff84d 	b	9f1c <f0+0x5cc>
    bdec:	aa1703e0 	mov	x0, x23
    bdf0:	97ffe1f4 	bl	45c0 <fwp_rc_forget_slot>
    bdf4:	17fff87f 	b	9ff0 <f0+0x6a0>
    bdf8:	aa1703e0 	mov	x0, x23
    bdfc:	97ffe1f1 	bl	45c0 <fwp_rc_forget_slot>
    be00:	17fff8a1 	b	a084 <f0+0x734>
    be04:	aa1703e0 	mov	x0, x23
    be08:	97ffe1ee 	bl	45c0 <fwp_rc_forget_slot>
    be0c:	17fff8da 	b	a174 <f0+0x824>
    be10:	aa1703e0 	mov	x0, x23
    be14:	97ffe1eb 	bl	45c0 <fwp_rc_forget_slot>
    be18:	17fff92f 	b	a2d4 <f0+0x984>
    be1c:	aa1703e0 	mov	x0, x23
    be20:	97ffe1e8 	bl	45c0 <fwp_rc_forget_slot>
    be24:	17fff95a 	b	a38c <f0+0xa3c>
    be28:	aa1703e0 	mov	x0, x23
    be2c:	97ffe1e5 	bl	45c0 <fwp_rc_forget_slot>
    be30:	17fff97d 	b	a424 <f0+0xad4>
    be34:	aa1703e0 	mov	x0, x23
    be38:	97ffe1e2 	bl	45c0 <fwp_rc_forget_slot>
    be3c:	17fff99f 	b	a4b8 <f0+0xb68>
    be40:	aa1703e0 	mov	x0, x23
    be44:	97ffe1df 	bl	45c0 <fwp_rc_forget_slot>
    be48:	17fffa10 	b	a688 <f0+0xd38>
    be4c:	aa1703e0 	mov	x0, x23
    be50:	97ffe1dc 	bl	45c0 <fwp_rc_forget_slot>
    be54:	17fffa3b 	b	a740 <f0+0xdf0>
    be58:	aa1503e0 	mov	x0, x21
    be5c:	97ffe1d9 	bl	45c0 <fwp_rc_forget_slot>
    be60:	17fffa66 	b	a7f8 <f0+0xea8>
    be64:	aa1703e0 	mov	x0, x23
    be68:	97ffe1d6 	bl	45c0 <fwp_rc_forget_slot>
    be6c:	17fffab4 	b	a93c <f0+0xfec>
    be70:	aa1703e0 	mov	x0, x23
    be74:	97ffe1d3 	bl	45c0 <fwp_rc_forget_slot>
    be78:	17fffad6 	b	a9d0 <f0+0x1080>
    be7c:	aa1703e0 	mov	x0, x23
    be80:	97ffe1d0 	bl	45c0 <fwp_rc_forget_slot>
    be84:	17fffb01 	b	aa88 <f0+0x1138>
    be88:	aa1703e0 	mov	x0, x23
    be8c:	97ffe1cd 	bl	45c0 <fwp_rc_forget_slot>
    be90:	17fffb2c 	b	ab40 <f0+0x11f0>
    be94:	aa1703e0 	mov	x0, x23
    be98:	97ffe1ca 	bl	45c0 <fwp_rc_forget_slot>
    be9c:	17fffb5e 	b	ac14 <f0+0x12c4>
    bea0:	aa1703e0 	mov	x0, x23
    bea4:	97ffe1c7 	bl	45c0 <fwp_rc_forget_slot>
    bea8:	17fffb80 	b	aca8 <f0+0x1358>
    beac:	aa1703e0 	mov	x0, x23
    beb0:	97ffe1c4 	bl	45c0 <fwp_rc_forget_slot>
    beb4:	17fffbab 	b	ad60 <f0+0x1410>
    beb8:	aa1703e0 	mov	x0, x23
    bebc:	97ffe1c1 	bl	45c0 <fwp_rc_forget_slot>
    bec0:	17fffbd6 	b	ae18 <f0+0x14c8>
    bec4:	aa1703e0 	mov	x0, x23
    bec8:	97ffe1be 	bl	45c0 <fwp_rc_forget_slot>
    becc:	17fffc08 	b	aeec <f0+0x159c>
    bed0:	aa1703e0 	mov	x0, x23
    bed4:	97ffe1bb 	bl	45c0 <fwp_rc_forget_slot>
    bed8:	17fffc2a 	b	af80 <f0+0x1630>
    bedc:	aa1703e0 	mov	x0, x23
    bee0:	97ffe1b8 	bl	45c0 <fwp_rc_forget_slot>
    bee4:	17fffc63 	b	b070 <f0+0x1720>
    bee8:	aa1703e0 	mov	x0, x23
    beec:	97ffe1b5 	bl	45c0 <fwp_rc_forget_slot>
    bef0:	17fffc95 	b	b144 <f0+0x17f4>
    bef4:	aa1703e0 	mov	x0, x23
    bef8:	97ffe1b2 	bl	45c0 <fwp_rc_forget_slot>
    befc:	17fffcb7 	b	b1d8 <f0+0x1888>
    bf00:	aa1703e0 	mov	x0, x23
    bf04:	97ffe1af 	bl	45c0 <fwp_rc_forget_slot>
    bf08:	17fffce2 	b	b290 <f0+0x1940>
    bf0c:	aa1703e0 	mov	x0, x23
    bf10:	97ffe1ac 	bl	45c0 <fwp_rc_forget_slot>
    bf14:	17fffd0d 	b	b348 <f0+0x19f8>
    bf18:	aa1703e0 	mov	x0, x23
    bf1c:	97ffe1a9 	bl	45c0 <fwp_rc_forget_slot>
    bf20:	17fffd3f 	b	b41c <f0+0x1acc>
    bf24:	aa1703e0 	mov	x0, x23
    bf28:	97ffe1a6 	bl	45c0 <fwp_rc_forget_slot>
    bf2c:	17fffd61 	b	b4b0 <f0+0x1b60>
    bf30:	aa1703e0 	mov	x0, x23
    bf34:	97ffe1a3 	bl	45c0 <fwp_rc_forget_slot>
    bf38:	17fffd9a 	b	b5a0 <f0+0x1c50>
    bf3c:	aa1703e0 	mov	x0, x23
    bf40:	97ffe1a0 	bl	45c0 <fwp_rc_forget_slot>
    bf44:	17fffdbd 	b	b638 <f0+0x1ce8>
    bf48:	aa1703e0 	mov	x0, x23
    bf4c:	97ffe19d 	bl	45c0 <fwp_rc_forget_slot>
    bf50:	17fffddf 	b	b6cc <f0+0x1d7c>
    bf54:	aa1703e0 	mov	x0, x23
    bf58:	97ffe19a 	bl	45c0 <fwp_rc_forget_slot>
    bf5c:	17fffe02 	b	b764 <f0+0x1e14>
    bf60:	aa1703e0 	mov	x0, x23
    bf64:	97ffe197 	bl	45c0 <fwp_rc_forget_slot>
    bf68:	17fffe24 	b	b7f8 <f0+0x1ea8>
    bf6c:	aa1703e0 	mov	x0, x23
    bf70:	97ffe194 	bl	45c0 <fwp_rc_forget_slot>
    bf74:	17fffe4f 	b	b8b0 <f0+0x1f60>
    bf78:	aa1703e0 	mov	x0, x23
    bf7c:	97ffe191 	bl	45c0 <fwp_rc_forget_slot>
    bf80:	17fffe88 	b	b9a0 <f0+0x2050>
    bf84:	97ffda3f 	bl	2880 <__stack_chk_fail@plt>
    bf88:	d503201f 	nop
    bf8c:	d503201f 	nop

000000000000bf90 <fwp_main_thread>:
    bf90:	d10443ff 	sub	sp, sp, #0x110
    bf94:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bf98:	f947f400 	ldr	x0, [x0, #4072]
    bf9c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    bfa0:	910303fd 	add	x29, sp, #0xc0
    bfa4:	a90d53f3 	stp	x19, x20, [sp, #208]
    bfa8:	d0000133 	adrp	x19, 31000 <fwp_root_context+0xc80>
    bfac:	91158261 	add	x1, x19, #0x560
    bfb0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    bfb4:	b953a421 	ldr	w1, [x1, #5028]
    bfb8:	f9400002 	ldr	x2, [x0]
    bfbc:	f9005fe2 	str	x2, [sp, #184]
    bfc0:	d2800002 	mov	x2, #0x0                   	// #0
    bfc4:	340025c1 	cbz	w1, c47c <fwp_main_thread+0x4ec>
    bfc8:	91158273 	add	x19, x19, #0x560
    bfcc:	b953aa60 	ldr	w0, [x19, #5032]
    bfd0:	350024e0 	cbnz	w0, c46c <fwp_main_thread+0x4dc>
    bfd4:	91001fe2 	add	x2, sp, #0x7
    bfd8:	b00000b5 	adrp	x21, 20000 <__data_start>
    bfdc:	b00000a3 	adrp	x3, 20000 <__data_start>
    bfe0:	9100c2b3 	add	x19, x21, #0x30
    bfe4:	910e0063 	add	x3, x3, #0x380
    bfe8:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    bfec:	d2a00025 	mov	x5, #0x10000               	// #65536
    bff0:	910023e0 	add	x0, sp, #0x8
    bff4:	d2800001 	mov	x1, #0x0                   	// #0
    bff8:	f90007e3 	str	x3, [sp, #8]
    bffc:	b90013ff 	str	wzr, [sp, #16]
    c000:	a9019262 	stp	x2, x4, [x19, #24]
    c004:	f9000fe5 	str	x5, [sp, #24]
    c008:	97ffd9b6 	bl	26e0 <sigaltstack@plt>
    c00c:	35002520 	cbnz	w0, c4b0 <fwp_main_thread+0x520>
    c010:	4f000400 	movi	v0.4s, #0x0
    c014:	9100a3e0 	add	x0, sp, #0x28
    c018:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    c01c:	52800082 	mov	w2, #0x4                   	// #4
    c020:	9101c021 	add	x1, x1, #0x70
    c024:	72a10002 	movk	w2, #0x800, lsl #16
    c028:	910083f4 	add	x20, sp, #0x20
    c02c:	f90013e1 	str	x1, [sp, #32]
    c030:	3d802000 	str	q0, [x0, #128]
    c034:	b900abe2 	str	w2, [sp, #168]
    c038:	ad000000 	stp	q0, q0, [x0]
    c03c:	ad010000 	stp	q0, q0, [x0, #32]
    c040:	ad020000 	stp	q0, q0, [x0, #64]
    c044:	ad030000 	stp	q0, q0, [x0, #96]
    c048:	97ffd9fe 	bl	2840 <sigemptyset@plt>
    c04c:	35002320 	cbnz	w0, c4b0 <fwp_main_thread+0x520>
    c050:	aa1403e1 	mov	x1, x20
    c054:	d2800002 	mov	x2, #0x0                   	// #0
    c058:	52800160 	mov	w0, #0xb                   	// #11
    c05c:	97ffda11 	bl	28a0 <sigaction@plt>
    c060:	35002280 	cbnz	w0, c4b0 <fwp_main_thread+0x520>
    c064:	aa1403e1 	mov	x1, x20
    c068:	d2800002 	mov	x2, #0x0                   	// #0
    c06c:	528000e0 	mov	w0, #0x7                   	// #7
    c070:	97ffda0c 	bl	28a0 <sigaction@plt>
    c074:	350021e0 	cbnz	w0, c4b0 <fwp_main_thread+0x520>
    c078:	b9431a60 	ldr	w0, [x19, #792]
    c07c:	a90f63f7 	stp	x23, x24, [sp, #240]
    c080:	34002020 	cbz	w0, c484 <fwp_main_thread+0x4f4>
    c084:	9100c2b6 	add	x22, x21, #0x30
    c088:	f9400ad4 	ldr	x20, [x22, #16]
    c08c:	b40010d4 	cbz	x20, c2a4 <fwp_main_thread+0x314>
    c090:	aa1403f3 	mov	x19, x20
    c094:	91010297 	add	x23, x20, #0x40
    c098:	f90083f9 	str	x25, [sp, #256]
    c09c:	52800038 	mov	w24, #0x1                   	// #1
    c0a0:	39414a99 	ldrb	w25, [x20, #82]
    c0a4:	39014a98 	strb	w24, [x20, #82]
    c0a8:	f9401680 	ldr	x0, [x20, #40]
    c0ac:	b4000620 	cbz	x0, c170 <fwp_main_thread+0x1e0>
    c0b0:	f9403281 	ldr	x1, [x20, #96]
    c0b4:	39414680 	ldrb	w0, [x20, #81]
    c0b8:	b4000b41 	cbz	x1, c220 <fwp_main_thread+0x290>
    c0bc:	36000a80 	tbz	w0, #0, c20c <fwp_main_thread+0x27c>
    c0c0:	39414a62 	ldrb	w2, [x19, #82]
    c0c4:	f9402280 	ldr	x0, [x20, #64]
    c0c8:	37000d62 	tbnz	w2, #0, c274 <fwp_main_thread+0x2e4>
    c0cc:	f9403261 	ldr	x1, [x19, #96]
    c0d0:	a911fe77 	stp	x23, xzr, [x19, #280]
    c0d4:	f9009660 	str	x0, [x19, #296]
    c0d8:	b4000040 	cbz	x0, c0e0 <fwp_main_thread+0x150>
    c0dc:	f9009013 	str	x19, [x0, #288]
    c0e0:	f9002293 	str	x19, [x20, #64]
    c0e4:	b4000101 	cbz	x1, c104 <fwp_main_thread+0x174>
    c0e8:	f94056c0 	ldr	x0, [x22, #168]
    c0ec:	39015678 	strb	w24, [x19, #85]
    c0f0:	f9003661 	str	x1, [x19, #104]
    c0f4:	a910827f 	stp	xzr, x0, [x19, #264]
    c0f8:	b4000040 	cbz	x0, c100 <fwp_main_thread+0x170>
    c0fc:	f9008413 	str	x19, [x0, #264]
    c100:	f90056d3 	str	x19, [x22, #168]
    c104:	39015a7f 	strb	wzr, [x19, #86]
    c108:	97ffe8f7 	bl	64e4 <fwp_block>
    c10c:	f9408e62 	ldr	x2, [x19, #280]
    c110:	b4000142 	cbz	x2, c138 <fwp_main_thread+0x1a8>
    c114:	a9520261 	ldp	x1, x0, [x19, #288]
    c118:	b4000ba1 	cbz	x1, c28c <fwp_main_thread+0x2fc>
    c11c:	f9009420 	str	x0, [x1, #296]
    c120:	f9409660 	ldr	x0, [x19, #296]
    c124:	b4000040 	cbz	x0, c12c <fwp_main_thread+0x19c>
    c128:	f9009001 	str	x1, [x0, #288]
    c12c:	91080260 	add	x0, x19, #0x200
    c130:	f900967f 	str	xzr, [x19, #296]
    c134:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c138:	39415660 	ldrb	w0, [x19, #85]
    c13c:	f9400ac2 	ldr	x2, [x22, #16]
    c140:	36000960 	tbz	w0, #0, c26c <fwp_main_thread+0x2dc>
    c144:	a9508261 	ldp	x1, x0, [x19, #264]
    c148:	b4000a61 	cbz	x1, c294 <fwp_main_thread+0x304>
    c14c:	f9008820 	str	x0, [x1, #272]
    c150:	b4000040 	cbz	x0, c158 <fwp_main_thread+0x1c8>
    c154:	f9008401 	str	x1, [x0, #264]
    c158:	91080260 	add	x0, x19, #0x200
    c15c:	3901567f 	strb	wzr, [x19, #85]
    c160:	aa0203f3 	mov	x19, x2
    c164:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c168:	f9401680 	ldr	x0, [x20, #40]
    c16c:	b5fffa20 	cbnz	x0, c0b0 <fwp_main_thread+0x120>
    c170:	9100c2a0 	add	x0, x21, #0x30
    c174:	39014a99 	strb	w25, [x20, #82]
    c178:	f94083f9 	ldr	x25, [sp, #256]
    c17c:	f9417c00 	ldr	x0, [x0, #760]
    c180:	b4001560 	cbz	x0, c42c <fwp_main_thread+0x49c>
    c184:	9100c2a0 	add	x0, x21, #0x30
    c188:	f9419801 	ldr	x1, [x0, #816]
    c18c:	b903281f 	str	wzr, [x0, #808]
    c190:	eb13003f 	cmp	x1, x19
    c194:	54001681 	b.ne	c464 <fwp_main_thread+0x4d4>  // b.any
    c198:	b4000913 	cbz	x19, c2b8 <fwp_main_thread+0x328>
    c19c:	9100c2a0 	add	x0, x21, #0x30
    c1a0:	52800021 	mov	w1, #0x1                   	// #1
    c1a4:	39014a61 	strb	w1, [x19, #82]
    c1a8:	f9416805 	ldr	x5, [x0, #720]
    c1ac:	b4000865 	cbz	x5, c2b8 <fwp_main_thread+0x328>
    c1b0:	394140a0 	ldrb	w0, [x5, #80]
    c1b4:	37000060 	tbnz	w0, #0, c1c0 <fwp_main_thread+0x230>
    c1b8:	aa0503e0 	mov	x0, x5
    c1bc:	97ffdcad 	bl	3470 <fwp_cancel_tree.part.0>
    c1c0:	f9409ca5 	ldr	x5, [x5, #312]
    c1c4:	b5ffff65 	cbnz	x5, c1b0 <fwp_main_thread+0x220>
    c1c8:	9100c2b4 	add	x20, x21, #0x30
    c1cc:	52800036 	mov	w22, #0x1                   	// #1
    c1d0:	f9402a60 	ldr	x0, [x19, #80]
    c1d4:	f2001c1f 	tst	x0, #0xff000000ff
    c1d8:	540000e1 	b.ne	c1f4 <fwp_main_thread+0x264>  // b.any
    c1dc:	f9401680 	ldr	x0, [x20, #40]
    c1e0:	39015276 	strb	w22, [x19, #84]
    c1e4:	f900827f 	str	xzr, [x19, #256]
    c1e8:	b40005a0 	cbz	x0, c29c <fwp_main_thread+0x30c>
    c1ec:	f9008013 	str	x19, [x0, #256]
    c1f0:	f9001693 	str	x19, [x20, #40]
    c1f4:	97ffe8bc 	bl	64e4 <fwp_block>
    c1f8:	97ffe84e 	bl	6330 <fwp_free_zombie>
    c1fc:	f9416a80 	ldr	x0, [x20, #720]
    c200:	b40005c0 	cbz	x0, c2b8 <fwp_main_thread+0x328>
    c204:	f9419a93 	ldr	x19, [x20, #816]
    c208:	17fffff2 	b	c1d0 <fwp_main_thread+0x240>
    c20c:	97ffdd3d 	bl	3700 <fwp_now_ns>
    c210:	f9403281 	ldr	x1, [x20, #96]
    c214:	eb01001f 	cmp	x0, x1
    c218:	54000fca 	b.ge	c410 <fwp_main_thread+0x480>  // b.tcont
    c21c:	39414680 	ldrb	w0, [x20, #81]
    c220:	39414a62 	ldrb	w2, [x19, #82]
    c224:	3707f500 	tbnz	w0, #0, c0c4 <fwp_main_thread+0x134>
    c228:	f9403281 	ldr	x1, [x20, #96]
    c22c:	370001c2 	tbnz	w2, #0, c264 <fwp_main_thread+0x2d4>
    c230:	f9403260 	ldr	x0, [x19, #96]
    c234:	b4000180 	cbz	x0, c264 <fwp_main_thread+0x2d4>
    c238:	b4000061 	cbz	x1, c244 <fwp_main_thread+0x2b4>
    c23c:	eb01001f 	cmp	x0, x1
    c240:	9a81d000 	csel	x0, x0, x1, le
    c244:	f9402281 	ldr	x1, [x20, #64]
    c248:	a911fe77 	stp	x23, xzr, [x19, #280]
    c24c:	f9009661 	str	x1, [x19, #296]
    c250:	b4001241 	cbz	x1, c498 <fwp_main_thread+0x508>
    c254:	f9009033 	str	x19, [x1, #288]
    c258:	aa0003e1 	mov	x1, x0
    c25c:	f9002293 	str	x19, [x20, #64]
    c260:	17ffffa2 	b	c0e8 <fwp_main_thread+0x158>
    c264:	f9402280 	ldr	x0, [x20, #64]
    c268:	17ffff9a 	b	c0d0 <fwp_main_thread+0x140>
    c26c:	aa0203f3 	mov	x19, x2
    c270:	17ffff8e 	b	c0a8 <fwp_main_thread+0x118>
    c274:	a911fe77 	stp	x23, xzr, [x19, #280]
    c278:	f9009660 	str	x0, [x19, #296]
    c27c:	b4000040 	cbz	x0, c284 <fwp_main_thread+0x2f4>
    c280:	f9009013 	str	x19, [x0, #288]
    c284:	f9002293 	str	x19, [x20, #64]
    c288:	17ffff9f 	b	c104 <fwp_main_thread+0x174>
    c28c:	f9000040 	str	x0, [x2]
    c290:	17ffffa5 	b	c124 <fwp_main_thread+0x194>
    c294:	f90056c0 	str	x0, [x22, #168]
    c298:	17ffffae 	b	c150 <fwp_main_thread+0x1c0>
    c29c:	f9001a93 	str	x19, [x20, #48]
    c2a0:	17ffffd4 	b	c1f0 <fwp_main_thread+0x260>
    c2a4:	f9417ec0 	ldr	x0, [x22, #760]
    c2a8:	b4000c00 	cbz	x0, c428 <fwp_main_thread+0x498>
    c2ac:	f9419ac0 	ldr	x0, [x22, #816]
    c2b0:	b9032adf 	str	wzr, [x22, #808]
    c2b4:	b5000d80 	cbnz	x0, c464 <fwp_main_thread+0x4d4>
    c2b8:	9100c2b4 	add	x20, x21, #0x30
    c2bc:	97ffe81d 	bl	6330 <fwp_free_zombie>
    c2c0:	f9401a80 	ldr	x0, [x20, #48]
    c2c4:	b5000d00 	cbnz	x0, c464 <fwp_main_thread+0x4d4>
    c2c8:	f9405680 	ldr	x0, [x20, #168]
    c2cc:	b5000cc0 	cbnz	x0, c464 <fwp_main_thread+0x4d4>
    c2d0:	b940ca93 	ldr	w19, [x20, #200]
    c2d4:	340001d3 	cbz	w19, c30c <fwp_main_thread+0x37c>
    c2d8:	93407e76 	sxtw	x22, w19
    c2dc:	51000673 	sub	w19, w19, #0x1
    c2e0:	d1000ad6 	sub	x22, x22, #0x2
    c2e4:	91034297 	add	x23, x20, #0xd0
    c2e8:	cb3342d6 	sub	x22, x22, w19, uxtw
    c2ec:	93407e73 	sxtw	x19, w19
    c2f0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c2f4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c2f8:	b900ca93 	str	w19, [x20, #200]
    c2fc:	d1000673 	sub	x19, x19, #0x1
    c300:	97ffd9a8 	bl	29a0 <munmap@plt>
    c304:	eb16027f 	cmp	x19, x22
    c308:	54ffff41 	b.ne	c2f0 <fwp_main_thread+0x360>  // b.any
    c30c:	900000b3 	adrp	x19, 20000 <__data_start>
    c310:	91004260 	add	x0, x19, #0x10
    c314:	b9400800 	ldr	w0, [x0, #8]
    c318:	37f80040 	tbnz	w0, #31, c320 <fwp_main_thread+0x390>
    c31c:	97ffd95d 	bl	2890 <close@plt>
    c320:	9100c2a0 	add	x0, x21, #0x30
    c324:	91004261 	add	x1, x19, #0x10
    c328:	12800002 	mov	w2, #0xffffffff            	// #-1
    c32c:	d2800013 	mov	x19, #0x0                   	// #0
    c330:	f9419c16 	ldr	x22, [x0, #824]
    c334:	b9000822 	str	w2, [x1, #8]
    c338:	f941a014 	ldr	x20, [x0, #832]
    c33c:	b4000176 	cbz	x22, c368 <fwp_main_thread+0x3d8>
    c340:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c344:	b40000c0 	cbz	x0, c35c <fwp_main_thread+0x3cc>
    c348:	f9400001 	ldr	x1, [x0]
    c34c:	b50008c1 	cbnz	x1, c464 <fwp_main_thread+0x4d4>
    c350:	f9400401 	ldr	x1, [x0, #8]
    c354:	b5000881 	cbnz	x1, c464 <fwp_main_thread+0x4d4>
    c358:	97ffe13a 	bl	4840 <fwp_mem_free>
    c35c:	91000673 	add	x19, x19, #0x1
    c360:	eb16027f 	cmp	x19, x22
    c364:	54fffee1 	b.ne	c340 <fwp_main_thread+0x3b0>  // b.any
    c368:	aa1403e0 	mov	x0, x20
    c36c:	97ffe135 	bl	4840 <fwp_mem_free>
    c370:	9100c2a0 	add	x0, x21, #0x30
    c374:	f9419813 	ldr	x19, [x0, #816]
    c378:	f9019c1f 	str	xzr, [x0, #824]
    c37c:	f901a01f 	str	xzr, [x0, #832]
    c380:	b40001f3 	cbz	x19, c3bc <fwp_main_thread+0x42c>
    c384:	f9401661 	ldr	x1, [x19, #40]
    c388:	b50006e1 	cbnz	x1, c464 <fwp_main_thread+0x4d4>
    c38c:	f9405661 	ldr	x1, [x19, #168]
    c390:	b50006a1 	cbnz	x1, c464 <fwp_main_thread+0x4d4>
    c394:	f9417c01 	ldr	x1, [x0, #760]
    c398:	b5000661 	cbnz	x1, c464 <fwp_main_thread+0x4d4>
    c39c:	f9418400 	ldr	x0, [x0, #776]
    c3a0:	b5000620 	cbnz	x0, c464 <fwp_main_thread+0x4d4>
    c3a4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c3a8:	90000120 	adrp	x0, 30000 <alt.9+0xfc80>
    c3ac:	910e0000 	add	x0, x0, #0x380
    c3b0:	97ffd928 	bl	2850 <memset@plt>
    c3b4:	aa1303e0 	mov	x0, x19
    c3b8:	97ffe122 	bl	4840 <fwp_mem_free>
    c3bc:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c3c0:	f947ec00 	ldr	x0, [x0, #4056]
    c3c4:	9100c2b5 	add	x21, x21, #0x30
    c3c8:	f9400000 	ldr	x0, [x0]
    c3cc:	f9000abf 	str	xzr, [x21, #16]
    c3d0:	f9019abf 	str	xzr, [x21, #816]
    c3d4:	97ffd977 	bl	29b0 <fflush@plt>
    c3d8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c3dc:	f947f400 	ldr	x0, [x0, #4072]
    c3e0:	f9405fe2 	ldr	x2, [sp, #184]
    c3e4:	f9400001 	ldr	x1, [x0]
    c3e8:	eb010042 	subs	x2, x2, x1
    c3ec:	d2800001 	mov	x1, #0x0                   	// #0
    c3f0:	540006a1 	b.ne	c4c4 <fwp_main_thread+0x534>  // b.any
    c3f4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c3f8:	d2800000 	mov	x0, #0x0                   	// #0
    c3fc:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c400:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c404:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c408:	910443ff 	add	sp, sp, #0x110
    c40c:	d65f03c0 	ret
    c410:	39414280 	ldrb	w0, [x20, #80]
    c414:	3707f040 	tbnz	w0, #0, c21c <fwp_main_thread+0x28c>
    c418:	aa1403e0 	mov	x0, x20
    c41c:	97ffdc15 	bl	3470 <fwp_cancel_tree.part.0>
    c420:	39414680 	ldrb	w0, [x20, #81]
    c424:	17ffff7f 	b	c220 <fwp_main_thread+0x290>
    c428:	d2800013 	mov	x19, #0x0                   	// #0
    c42c:	9100c2b4 	add	x20, x21, #0x30
    c430:	f9418680 	ldr	x0, [x20, #776]
    c434:	b5ffea80 	cbnz	x0, c184 <fwp_main_thread+0x1f4>
    c438:	f9417a80 	ldr	x0, [x20, #752]
    c43c:	97ffe101 	bl	4840 <fwp_mem_free>
    c440:	f9017a9f 	str	xzr, [x20, #752]
    c444:	f901829f 	str	xzr, [x20, #768]
    c448:	f9419a80 	ldr	x0, [x20, #816]
    c44c:	b40002d3 	cbz	x19, c4a4 <fwp_main_thread+0x514>
    c450:	f900567f 	str	xzr, [x19, #168]
    c454:	f9005e7f 	str	xzr, [x19, #184]
    c458:	b9032a9f 	str	wzr, [x20, #808]
    c45c:	eb00027f 	cmp	x19, x0
    c460:	54ffe9e0 	b.eq	c19c <fwp_main_thread+0x20c>  // b.none
    c464:	f90083f9 	str	x25, [sp, #256]
    c468:	97ffd91a 	bl	28d0 <abort@plt>
    c46c:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    c470:	91348000 	add	x0, x0, #0xd20
    c474:	940001d3 	bl	cbc0 <atexit>
    c478:	17fffed7 	b	bfd4 <fwp_main_thread+0x44>
    c47c:	97ffde82 	bl	3e84 <fwp_heap_init>
    c480:	17fffed2 	b	bfc8 <fwp_main_thread+0x38>
    c484:	97fff533 	bl	9950 <f0>
    c488:	f9019260 	str	x0, [x19, #800]
    c48c:	52800021 	mov	w1, #0x1                   	// #1
    c490:	b9031a61 	str	w1, [x19, #792]
    c494:	17fffefc 	b	c084 <fwp_main_thread+0xf4>
    c498:	aa0003e1 	mov	x1, x0
    c49c:	f9002293 	str	x19, [x20, #64]
    c4a0:	17ffff12 	b	c0e8 <fwp_main_thread+0x158>
    c4a4:	b9032a9f 	str	wzr, [x20, #808]
    c4a8:	b4fff080 	cbz	x0, c2b8 <fwp_main_thread+0x328>
    c4ac:	17ffffee 	b	c464 <fwp_main_thread+0x4d4>
    c4b0:	b0000000 	adrp	x0, d000 <_IO_stdin_used+0x410>
    c4b4:	9106a000 	add	x0, x0, #0x1a8
    c4b8:	a90f63f7 	stp	x23, x24, [sp, #240]
    c4bc:	f90083f9 	str	x25, [sp, #256]
    c4c0:	97ffdc30 	bl	3580 <fwp_trap>
    c4c4:	f90083f9 	str	x25, [sp, #256]
    c4c8:	97ffd8ee 	bl	2880 <__stack_chk_fail@plt>
    c4cc:	d503201f 	nop

000000000000c4d0 <__divti3>:
    c4d0:	d503245f 	bti	c
    c4d4:	d2800004 	mov	x4, #0x0                   	// #0
    c4d8:	b7f80721 	tbnz	x1, #63, c5bc <__divti3+0xec>
    c4dc:	b6f80083 	tbz	x3, #63, c4ec <__divti3+0x1c>
    c4e0:	eb0203e2 	negs	x2, x2
    c4e4:	aa2403e4 	mvn	x4, x4
    c4e8:	da0303e3 	ngc	x3, x3
    c4ec:	aa0203e6 	mov	x6, x2
    c4f0:	aa0003e7 	mov	x7, x0
    c4f4:	aa0103e5 	mov	x5, x1
    c4f8:	b5000583 	cbnz	x3, c5a8 <__divti3+0xd8>
    c4fc:	eb01005f 	cmp	x2, x1
    c500:	54000e69 	b.ls	c6cc <__divti3+0x1fc>  // b.plast
    c504:	dac01040 	clz	x0, x2
    c508:	b40000e0 	cbz	x0, c524 <__divti3+0x54>
    c50c:	4b0003e1 	neg	w1, w0
    c510:	9ac020a5 	lsl	x5, x5, x0
    c514:	9ac02046 	lsl	x6, x2, x0
    c518:	9ac124e1 	lsr	x1, x7, x1
    c51c:	aa050025 	orr	x5, x1, x5
    c520:	9ac020e7 	lsl	x7, x7, x0
    c524:	d360fcc8 	lsr	x8, x6, #32
    c528:	92407cc2 	and	x2, x6, #0xffffffff
    c52c:	9ac808a3 	udiv	x3, x5, x8
    c530:	9b089465 	msub	x5, x3, x8, x5
    c534:	aa0303e0 	mov	x0, x3
    c538:	9b037c41 	mul	x1, x2, x3
    c53c:	93c780a5 	extr	x5, x5, x7, #32
    c540:	eb05003f 	cmp	x1, x5
    c544:	540000a9 	b.ls	c558 <__divti3+0x88>  // b.plast
    c548:	ab0500c5 	adds	x5, x6, x5
    c54c:	d1000460 	sub	x0, x3, #0x1
    c550:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c554:	540015a8 	b.hi	c808 <__divti3+0x338>  // b.pmore
    c558:	cb0100a5 	sub	x5, x5, x1
    c55c:	9ac808a3 	udiv	x3, x5, x8
    c560:	9b089465 	msub	x5, x3, x8, x5
    c564:	aa0303e1 	mov	x1, x3
    c568:	9b037c42 	mul	x2, x2, x3
    c56c:	aa0703e3 	mov	x3, x7
    c570:	b3607ca3 	bfi	x3, x5, #32, #32
    c574:	eb03005f 	cmp	x2, x3
    c578:	540000c9 	b.ls	c590 <__divti3+0xc0>  // b.plast
    c57c:	ab0300c3 	adds	x3, x6, x3
    c580:	d1000425 	sub	x5, x1, #0x1
    c584:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c588:	d1000821 	sub	x1, x1, #0x2
    c58c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    c590:	aa008020 	orr	x0, x1, x0, lsl #32
    c594:	d2800001 	mov	x1, #0x0                   	// #0
    c598:	b4000064 	cbz	x4, c5a4 <__divti3+0xd4>
    c59c:	eb0003e0 	negs	x0, x0
    c5a0:	da0103e1 	ngc	x1, x1
    c5a4:	d65f03c0 	ret
    c5a8:	eb01007f 	cmp	x3, x1
    c5ac:	54000109 	b.ls	c5cc <__divti3+0xfc>  // b.plast
    c5b0:	d2800001 	mov	x1, #0x0                   	// #0
    c5b4:	d2800000 	mov	x0, #0x0                   	// #0
    c5b8:	17fffff8 	b	c598 <__divti3+0xc8>
    c5bc:	eb0003e0 	negs	x0, x0
    c5c0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c5c4:	da0103e1 	ngc	x1, x1
    c5c8:	17ffffc5 	b	c4dc <__divti3+0xc>
    c5cc:	dac01067 	clz	x7, x3
    c5d0:	b40010e7 	cbz	x7, c7ec <__divti3+0x31c>
    c5d4:	d2800805 	mov	x5, #0x40                  	// #64
    c5d8:	cb0700a5 	sub	x5, x5, x7
    c5dc:	9ac72063 	lsl	x3, x3, x7
    c5e0:	9ac52448 	lsr	x8, x2, x5
    c5e4:	aa030108 	orr	x8, x8, x3
    c5e8:	9ac52426 	lsr	x6, x1, x5
    c5ec:	92407d0a 	and	x10, x8, #0xffffffff
    c5f0:	d360fd09 	lsr	x9, x8, #32
    c5f4:	9ac52403 	lsr	x3, x0, x5
    c5f8:	9ac72021 	lsl	x1, x1, x7
    c5fc:	aa010063 	orr	x3, x3, x1
    c600:	9ac72042 	lsl	x2, x2, x7
    c604:	9ac908cb 	udiv	x11, x6, x9
    c608:	9b099965 	msub	x5, x11, x9, x6
    c60c:	aa0b03e1 	mov	x1, x11
    c610:	9b0b7d46 	mul	x6, x10, x11
    c614:	93c380a5 	extr	x5, x5, x3, #32
    c618:	eb0500df 	cmp	x6, x5
    c61c:	540000a9 	b.ls	c630 <__divti3+0x160>  // b.plast
    c620:	ab050105 	adds	x5, x8, x5
    c624:	d1000561 	sub	x1, x11, #0x1
    c628:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    c62c:	54000f48 	b.hi	c814 <__divti3+0x344>  // b.pmore
    c630:	cb0600a6 	sub	x6, x5, x6
    c634:	9ac908cb 	udiv	x11, x6, x9
    c638:	9b099969 	msub	x9, x11, x9, x6
    c63c:	aa0b03e5 	mov	x5, x11
    c640:	9b0b7d4a 	mul	x10, x10, x11
    c644:	b3607d23 	bfi	x3, x9, #32, #32
    c648:	eb03015f 	cmp	x10, x3
    c64c:	540000a9 	b.ls	c660 <__divti3+0x190>  // b.plast
    c650:	ab030103 	adds	x3, x8, x3
    c654:	d1000565 	sub	x5, x11, #0x1
    c658:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    c65c:	54000e28 	b.hi	c820 <__divti3+0x350>  // b.pmore
    c660:	aa0180a1 	orr	x1, x5, x1, lsl #32
    c664:	92407c48 	and	x8, x2, #0xffffffff
    c668:	2a0503e5 	mov	w5, w5
    c66c:	d360fc42 	lsr	x2, x2, #32
    c670:	d360fc26 	lsr	x6, x1, #32
    c674:	cb0a0063 	sub	x3, x3, x10
    c678:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    c67c:	9b087caa 	mul	x10, x5, x8
    c680:	9b087cc8 	mul	x8, x6, x8
    c684:	9b0220a5 	madd	x5, x5, x2, x8
    c688:	9b027cc6 	mul	x6, x6, x2
    c68c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    c690:	8b0900c5 	add	x5, x6, x9
    c694:	eb02011f 	cmp	x8, x2
    c698:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    c69c:	8b4280c6 	add	x6, x6, x2, lsr #32
    c6a0:	eb06007f 	cmp	x3, x6
    c6a4:	540000e3 	b.cc	c6c0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    c6a8:	92407d4a 	and	x10, x10, #0xffffffff
    c6ac:	9ac72000 	lsl	x0, x0, x7
    c6b0:	8b028142 	add	x2, x10, x2, lsl #32
    c6b4:	eb02001f 	cmp	x0, x2
    c6b8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    c6bc:	54000a01 	b.ne	c7fc <__divti3+0x32c>  // b.any
    c6c0:	d1000420 	sub	x0, x1, #0x1
    c6c4:	d2800001 	mov	x1, #0x0                   	// #0
    c6c8:	17ffffb4 	b	c598 <__divti3+0xc8>
    c6cc:	b5000062 	cbnz	x2, c6d8 <__divti3+0x208>
    c6d0:	d2800022 	mov	x2, #0x1                   	// #1
    c6d4:	9ac30846 	udiv	x6, x2, x3
    c6d8:	dac010c8 	clz	x8, x6
    c6dc:	b5000408 	cbnz	x8, c75c <__divti3+0x28c>
    c6e0:	d360fcc9 	lsr	x9, x6, #32
    c6e4:	92407cc5 	and	x5, x6, #0xffffffff
    c6e8:	cb060023 	sub	x3, x1, x6
    c6ec:	d2800021 	mov	x1, #0x1                   	// #1
    c6f0:	9ac90868 	udiv	x8, x3, x9
    c6f4:	9b098d03 	msub	x3, x8, x9, x3
    c6f8:	aa0803e0 	mov	x0, x8
    c6fc:	9b057d02 	mul	x2, x8, x5
    c700:	93c78063 	extr	x3, x3, x7, #32
    c704:	eb03005f 	cmp	x2, x3
    c708:	540000a9 	b.ls	c71c <__divti3+0x24c>  // b.plast
    c70c:	ab0300c3 	adds	x3, x6, x3
    c710:	d1000500 	sub	x0, x8, #0x1
    c714:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c718:	54000968 	b.hi	c844 <__divti3+0x374>  // b.pmore
    c71c:	cb020063 	sub	x3, x3, x2
    c720:	9ac90862 	udiv	x2, x3, x9
    c724:	aa0203e8 	mov	x8, x2
    c728:	9b098c42 	msub	x2, x2, x9, x3
    c72c:	aa0703e3 	mov	x3, x7
    c730:	9b057d05 	mul	x5, x8, x5
    c734:	b3607c43 	bfi	x3, x2, #32, #32
    c738:	eb0300bf 	cmp	x5, x3
    c73c:	540000c9 	b.ls	c754 <__divti3+0x284>  // b.plast
    c740:	ab0300c2 	adds	x2, x6, x3
    c744:	d1000503 	sub	x3, x8, #0x1
    c748:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    c74c:	d1000908 	sub	x8, x8, #0x2
    c750:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    c754:	aa008100 	orr	x0, x8, x0, lsl #32
    c758:	17ffff90 	b	c598 <__divti3+0xc8>
    c75c:	9ac820c6 	lsl	x6, x6, x8
    c760:	d2800803 	mov	x3, #0x40                  	// #64
    c764:	cb080063 	sub	x3, x3, x8
    c768:	d360fcc9 	lsr	x9, x6, #32
    c76c:	9ac82027 	lsl	x7, x1, x8
    c770:	92407cc5 	and	x5, x6, #0xffffffff
    c774:	9ac32422 	lsr	x2, x1, x3
    c778:	9ac32403 	lsr	x3, x0, x3
    c77c:	aa070063 	orr	x3, x3, x7
    c780:	9ac9084a 	udiv	x10, x2, x9
    c784:	9ac82007 	lsl	x7, x0, x8
    c788:	9b098940 	msub	x0, x10, x9, x2
    c78c:	aa0a03e1 	mov	x1, x10
    c790:	9b0a7ca2 	mul	x2, x5, x10
    c794:	93c38000 	extr	x0, x0, x3, #32
    c798:	eb00005f 	cmp	x2, x0
    c79c:	540000a9 	b.ls	c7b0 <__divti3+0x2e0>  // b.plast
    c7a0:	ab0000c0 	adds	x0, x6, x0
    c7a4:	d1000541 	sub	x1, x10, #0x1
    c7a8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    c7ac:	54000468 	b.hi	c838 <__divti3+0x368>  // b.pmore
    c7b0:	cb020000 	sub	x0, x0, x2
    c7b4:	9ac9080a 	udiv	x10, x0, x9
    c7b8:	9b098140 	msub	x0, x10, x9, x0
    c7bc:	aa0a03e2 	mov	x2, x10
    c7c0:	9b0a7ca8 	mul	x8, x5, x10
    c7c4:	b3607c03 	bfi	x3, x0, #32, #32
    c7c8:	eb03011f 	cmp	x8, x3
    c7cc:	540000a9 	b.ls	c7e0 <__divti3+0x310>  // b.plast
    c7d0:	ab0300c3 	adds	x3, x6, x3
    c7d4:	d1000542 	sub	x2, x10, #0x1
    c7d8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    c7dc:	54000288 	b.hi	c82c <__divti3+0x35c>  // b.pmore
    c7e0:	cb080063 	sub	x3, x3, x8
    c7e4:	aa018041 	orr	x1, x2, x1, lsl #32
    c7e8:	17ffffc2 	b	c6f0 <__divti3+0x220>
    c7ec:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    c7f0:	d2800001 	mov	x1, #0x0                   	// #0
    c7f4:	9a9f87e0 	cset	x0, ls	// ls = plast
    c7f8:	17ffff68 	b	c598 <__divti3+0xc8>
    c7fc:	aa0103e0 	mov	x0, x1
    c800:	d2800001 	mov	x1, #0x0                   	// #0
    c804:	17ffff65 	b	c598 <__divti3+0xc8>
    c808:	d1000860 	sub	x0, x3, #0x2
    c80c:	8b0600a5 	add	x5, x5, x6
    c810:	17ffff52 	b	c558 <__divti3+0x88>
    c814:	d1000961 	sub	x1, x11, #0x2
    c818:	8b0800a5 	add	x5, x5, x8
    c81c:	17ffff85 	b	c630 <__divti3+0x160>
    c820:	d1000965 	sub	x5, x11, #0x2
    c824:	8b080063 	add	x3, x3, x8
    c828:	17ffff8e 	b	c660 <__divti3+0x190>
    c82c:	d1000942 	sub	x2, x10, #0x2
    c830:	8b060063 	add	x3, x3, x6
    c834:	17ffffeb 	b	c7e0 <__divti3+0x310>
    c838:	d1000941 	sub	x1, x10, #0x2
    c83c:	8b060000 	add	x0, x0, x6
    c840:	17ffffdc 	b	c7b0 <__divti3+0x2e0>
    c844:	d1000900 	sub	x0, x8, #0x2
    c848:	8b060063 	add	x3, x3, x6
    c84c:	17ffffb4 	b	c71c <__divti3+0x24c>

000000000000c850 <__modti3>:
    c850:	d503245f 	bti	c
    c854:	d2800004 	mov	x4, #0x0                   	// #0
    c858:	b6f80081 	tbz	x1, #63, c868 <__modti3+0x18>
    c85c:	eb0003e0 	negs	x0, x0
    c860:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c864:	da0103e1 	ngc	x1, x1
    c868:	f100007f 	cmp	x3, #0x0
    c86c:	5400128b 	b.lt	cabc <__modti3+0x26c>  // b.tstop
    c870:	aa0003e7 	mov	x7, x0
    c874:	aa0103e6 	mov	x6, x1
    c878:	540004e1 	b.ne	c914 <__modti3+0xc4>  // b.any
    c87c:	eb02003f 	cmp	x1, x2
    c880:	54000dc2 	b.cs	ca38 <__modti3+0x1e8>  // b.hs, b.nlast
    c884:	dac01043 	clz	x3, x2
    c888:	aa0303e5 	mov	x5, x3
    c88c:	b40000e3 	cbz	x3, c8a8 <__modti3+0x58>
    c890:	4b0303e6 	neg	w6, w3
    c894:	9ac32021 	lsl	x1, x1, x3
    c898:	9ac32042 	lsl	x2, x2, x3
    c89c:	9ac62406 	lsr	x6, x0, x6
    c8a0:	aa0100c6 	orr	x6, x6, x1
    c8a4:	9ac32007 	lsl	x7, x0, x3
    c8a8:	d360fc40 	lsr	x0, x2, #32
    c8ac:	92407c43 	and	x3, x2, #0xffffffff
    c8b0:	9ac008c1 	udiv	x1, x6, x0
    c8b4:	9b009826 	msub	x6, x1, x0, x6
    c8b8:	9b017c61 	mul	x1, x3, x1
    c8bc:	93c780c6 	extr	x6, x6, x7, #32
    c8c0:	eb06003f 	cmp	x1, x6
    c8c4:	540000a9 	b.ls	c8d8 <__modti3+0x88>  // b.plast
    c8c8:	ab060046 	adds	x6, x2, x6
    c8cc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    c8d0:	8b0200c8 	add	x8, x6, x2
    c8d4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    c8d8:	cb0100c6 	sub	x6, x6, x1
    c8dc:	9ac008c8 	udiv	x8, x6, x0
    c8e0:	9b009901 	msub	x1, x8, x0, x6
    c8e4:	aa0703e0 	mov	x0, x7
    c8e8:	9b087c63 	mul	x3, x3, x8
    c8ec:	b3607c20 	bfi	x0, x1, #32, #32
    c8f0:	eb00007f 	cmp	x3, x0
    c8f4:	54001088 	b.hi	cb04 <__modti3+0x2b4>  // b.pmore
    c8f8:	cb030000 	sub	x0, x0, x3
    c8fc:	9ac52400 	lsr	x0, x0, x5
    c900:	d2800001 	mov	x1, #0x0                   	// #0
    c904:	b4000064 	cbz	x4, c910 <__modti3+0xc0>
    c908:	eb0003e0 	negs	x0, x0
    c90c:	da0103e1 	ngc	x1, x1
    c910:	d65f03c0 	ret
    c914:	dac01066 	clz	x6, x3
    c918:	eb03003f 	cmp	x1, x3
    c91c:	54ffff43 	b.cc	c904 <__modti3+0xb4>  // b.lo, b.ul, b.last
    c920:	93407cc5 	sxtw	x5, w6
    c924:	d2800808 	mov	x8, #0x40                  	// #64
    c928:	cb050108 	sub	x8, x8, x5
    c92c:	9ac62063 	lsl	x3, x3, x6
    c930:	9ac62025 	lsl	x5, x1, x6
    c934:	9ac82447 	lsr	x7, x2, x8
    c938:	aa0300e7 	orr	x7, x7, x3
    c93c:	9ac82423 	lsr	x3, x1, x8
    c940:	92407cec 	and	x12, x7, #0xffffffff
    c944:	d360fcea 	lsr	x10, x7, #32
    c948:	9ac82401 	lsr	x1, x0, x8
    c94c:	aa050021 	orr	x1, x1, x5
    c950:	9ac62042 	lsl	x2, x2, x6
    c954:	9ac62000 	lsl	x0, x0, x6
    c958:	9aca086b 	udiv	x11, x3, x10
    c95c:	9b0a8d63 	msub	x3, x11, x10, x3
    c960:	aa0b03e5 	mov	x5, x11
    c964:	9b0b7d89 	mul	x9, x12, x11
    c968:	93c18063 	extr	x3, x3, x1, #32
    c96c:	eb03013f 	cmp	x9, x3
    c970:	540000a9 	b.ls	c984 <__modti3+0x134>  // b.plast
    c974:	ab0300e3 	adds	x3, x7, x3
    c978:	d1000565 	sub	x5, x11, #0x1
    c97c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    c980:	54001168 	b.hi	cbac <__modti3+0x35c>  // b.pmore
    c984:	cb090063 	sub	x3, x3, x9
    c988:	9aca086b 	udiv	x11, x3, x10
    c98c:	9b0a8d6a 	msub	x10, x11, x10, x3
    c990:	aa0b03e9 	mov	x9, x11
    c994:	9b0b7d8c 	mul	x12, x12, x11
    c998:	b3607d41 	bfi	x1, x10, #32, #32
    c99c:	eb01019f 	cmp	x12, x1
    c9a0:	540000a9 	b.ls	c9b4 <__modti3+0x164>  // b.plast
    c9a4:	ab0100e1 	adds	x1, x7, x1
    c9a8:	d1000569 	sub	x9, x11, #0x1
    c9ac:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    c9b0:	54000f88 	b.hi	cba0 <__modti3+0x350>  // b.pmore
    c9b4:	aa058123 	orr	x3, x9, x5, lsl #32
    c9b8:	92407c4b 	and	x11, x2, #0xffffffff
    c9bc:	2a0903e9 	mov	w9, w9
    c9c0:	d360fc4a 	lsr	x10, x2, #32
    c9c4:	d360fc63 	lsr	x3, x3, #32
    c9c8:	cb0c0021 	sub	x1, x1, x12
    c9cc:	aa0a03ec 	mov	x12, x10
    c9d0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    c9d4:	9b0b7d25 	mul	x5, x9, x11
    c9d8:	9b0b7c6b 	mul	x11, x3, x11
    c9dc:	9b0a2d29 	madd	x9, x9, x10, x11
    c9e0:	92407caa 	and	x10, x5, #0xffffffff
    c9e4:	9b0c7c63 	mul	x3, x3, x12
    c9e8:	8b458125 	add	x5, x9, x5, lsr #32
    c9ec:	8b0d0069 	add	x9, x3, x13
    c9f0:	eb05017f 	cmp	x11, x5
    c9f4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    c9f8:	8b058149 	add	x9, x10, x5, lsl #32
    c9fc:	8b458063 	add	x3, x3, x5, lsr #32
    ca00:	eb03003f 	cmp	x1, x3
    ca04:	54000063 	b.cc	ca10 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    ca08:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    ca0c:	54000082 	b.cs	ca1c <__modti3+0x1cc>  // b.hs, b.nlast
    ca10:	eb020129 	subs	x9, x9, x2
    ca14:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    ca18:	cb070063 	sub	x3, x3, x7
    ca1c:	eb090000 	subs	x0, x0, x9
    ca20:	da030021 	sbc	x1, x1, x3
    ca24:	9ac62400 	lsr	x0, x0, x6
    ca28:	9ac82028 	lsl	x8, x1, x8
    ca2c:	aa000100 	orr	x0, x8, x0
    ca30:	9ac62421 	lsr	x1, x1, x6
    ca34:	17ffffb4 	b	c904 <__modti3+0xb4>
    ca38:	b5000062 	cbnz	x2, ca44 <__modti3+0x1f4>
    ca3c:	d2800023 	mov	x3, #0x1                   	// #1
    ca40:	9ac20862 	udiv	x2, x3, x2
    ca44:	dac01048 	clz	x8, x2
    ca48:	aa0803e5 	mov	x5, x8
    ca4c:	b5000668 	cbnz	x8, cb18 <__modti3+0x2c8>
    ca50:	cb020020 	sub	x0, x1, x2
    ca54:	d360fc49 	lsr	x9, x2, #32
    ca58:	92407c4a 	and	x10, x2, #0xffffffff
    ca5c:	9ac90801 	udiv	x1, x0, x9
    ca60:	9b098020 	msub	x0, x1, x9, x0
    ca64:	9b0a7c21 	mul	x1, x1, x10
    ca68:	93c78000 	extr	x0, x0, x7, #32
    ca6c:	eb00003f 	cmp	x1, x0
    ca70:	540000a9 	b.ls	ca84 <__modti3+0x234>  // b.plast
    ca74:	ab000040 	adds	x0, x2, x0
    ca78:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ca7c:	8b020003 	add	x3, x0, x2
    ca80:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ca84:	cb010001 	sub	x1, x0, x1
    ca88:	9ac90820 	udiv	x0, x1, x9
    ca8c:	9b098403 	msub	x3, x0, x9, x1
    ca90:	aa0703e1 	mov	x1, x7
    ca94:	9b0a7c00 	mul	x0, x0, x10
    ca98:	b3607c61 	bfi	x1, x3, #32, #32
    ca9c:	eb01001f 	cmp	x0, x1
    caa0:	540000a9 	b.ls	cab4 <__modti3+0x264>  // b.plast
    caa4:	ab010041 	adds	x1, x2, x1
    caa8:	8b020022 	add	x2, x1, x2
    caac:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cab0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cab4:	cb000020 	sub	x0, x1, x0
    cab8:	17ffff91 	b	c8fc <__modti3+0xac>
    cabc:	eb0203e5 	negs	x5, x2
    cac0:	aa0003e7 	mov	x7, x0
    cac4:	da0303e8 	ngc	x8, x3
    cac8:	aa0503e2 	mov	x2, x5
    cacc:	aa0803e3 	mov	x3, x8
    cad0:	aa0103e6 	mov	x6, x1
    cad4:	b4ffed48 	cbz	x8, c87c <__modti3+0x2c>
    cad8:	eb01011f 	cmp	x8, x1
    cadc:	54fff148 	b.hi	c904 <__modti3+0xb4>  // b.pmore
    cae0:	dac01109 	clz	x9, x8
    cae4:	2a0903e6 	mov	w6, w9
    cae8:	b5fff1c9 	cbnz	x9, c920 <__modti3+0xd0>
    caec:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    caf0:	54000068 	b.hi	cafc <__modti3+0x2ac>  // b.pmore
    caf4:	eb050007 	subs	x7, x0, x5
    caf8:	da080021 	sbc	x1, x1, x8
    cafc:	aa0703e0 	mov	x0, x7
    cb00:	17ffff81 	b	c904 <__modti3+0xb4>
    cb04:	ab000040 	adds	x0, x2, x0
    cb08:	8b020002 	add	x2, x0, x2
    cb0c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    cb10:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    cb14:	17ffff79 	b	c8f8 <__modti3+0xa8>
    cb18:	9ac82042 	lsl	x2, x2, x8
    cb1c:	d2800803 	mov	x3, #0x40                  	// #64
    cb20:	cb080063 	sub	x3, x3, x8
    cb24:	d360fc49 	lsr	x9, x2, #32
    cb28:	9ac82027 	lsl	x7, x1, x8
    cb2c:	92407c4a 	and	x10, x2, #0xffffffff
    cb30:	9ac32426 	lsr	x6, x1, x3
    cb34:	9ac32403 	lsr	x3, x0, x3
    cb38:	aa070063 	orr	x3, x3, x7
    cb3c:	9ac908c1 	udiv	x1, x6, x9
    cb40:	9ac82007 	lsl	x7, x0, x8
    cb44:	9b099820 	msub	x0, x1, x9, x6
    cb48:	9b017d41 	mul	x1, x10, x1
    cb4c:	93c38000 	extr	x0, x0, x3, #32
    cb50:	eb00003f 	cmp	x1, x0
    cb54:	540000a9 	b.ls	cb68 <__modti3+0x318>  // b.plast
    cb58:	ab000040 	adds	x0, x2, x0
    cb5c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cb60:	8b020006 	add	x6, x0, x2
    cb64:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    cb68:	cb010000 	sub	x0, x0, x1
    cb6c:	9ac90801 	udiv	x1, x0, x9
    cb70:	9b098026 	msub	x6, x1, x9, x0
    cb74:	aa0303e0 	mov	x0, x3
    cb78:	9b017d41 	mul	x1, x10, x1
    cb7c:	b3607cc0 	bfi	x0, x6, #32, #32
    cb80:	eb00003f 	cmp	x1, x0
    cb84:	540000a9 	b.ls	cb98 <__modti3+0x348>  // b.plast
    cb88:	ab000040 	adds	x0, x2, x0
    cb8c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cb90:	8b020003 	add	x3, x0, x2
    cb94:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cb98:	cb010000 	sub	x0, x0, x1
    cb9c:	17ffffb0 	b	ca5c <__modti3+0x20c>
    cba0:	d1000969 	sub	x9, x11, #0x2
    cba4:	8b070021 	add	x1, x1, x7
    cba8:	17ffff83 	b	c9b4 <__modti3+0x164>
    cbac:	d1000965 	sub	x5, x11, #0x2
    cbb0:	8b070063 	add	x3, x3, x7
    cbb4:	17ffff74 	b	c984 <__modti3+0x134>
    cbb8:	d503201f 	nop
    cbbc:	d503201f 	nop

000000000000cbc0 <atexit>:
    cbc0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cbc4:	900000a2 	adrp	x2, 20000 <__data_start>
    cbc8:	d2800001 	mov	x1, #0x0                   	// #0
    cbcc:	910003fd 	mov	x29, sp
    cbd0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cbd4:	f9400442 	ldr	x2, [x2, #8]
    cbd8:	17ffd6ea 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000cbdc <_fini>:
    cbdc:	d503201f 	nop
    cbe0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cbe4:	910003fd 	mov	x29, sp
    cbe8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cbec:	d65f03c0 	ret
